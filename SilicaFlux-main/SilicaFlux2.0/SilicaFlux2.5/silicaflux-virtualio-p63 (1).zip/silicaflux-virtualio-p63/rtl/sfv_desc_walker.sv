// =============================================================================
// VirtualIO :: sfv_desc_walker -- split-virtqueue DESCRIPTOR CHAIN WALKER and validator (spec 2.7.5 / 2.7.4)
//
// Given the head index taken from the available ring, fetch descriptors one at a time through the guest-DMA unit
// (every fetch is domain-checked there) and validate the chain BEFORE anything is executed:
//
//   index        head and every `next` must be < queue size                         FC_BAD_HEAD / FC_BAD_NEXT
//   cycle        a descriptor may appear only once in a chain (visited bitmap)       FC_CYCLE
//   length       at most MAX_CHAIN descriptors (also bounds any chain that does not cycle)   FC_CHAIN_TOO_LONG
//   flags        only NEXT and WRITE may be set; any other bit is reserved           FC_BAD_FLAGS
//   indirect     VIRTQ_DESC_F_INDIRECT is refused (VIRTIO_F_RING_INDIRECT_DESC is not offered)   FC_INDIRECT
//   ordering     device-readable descriptors must precede device-writable ones (2.7.4.2)    FC_ORDER
//   fetch        a refused or failed descriptor fetch                                 FC_DMA_DENIED / FC_GUEST_BUS
//
// Zero-length descriptors are legal: they are counted and checked but contribute no segment.  The accepted chain is
// stored on chip (segment address / length / writable flag, in chain order, readable segments first) together with the
// totals of readable and writable bytes; the executor interprets it.  No bus access except the descriptor fetches is made
// here.  The descriptor table address plus 16 * index cannot wrap: the geometry was validated when the queue was enabled.
// Descriptor fields are little endian (le64 addr, le32 len, le16 flags, le16 next).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfv_desc_walker #(
  parameter int MAX_QSZ   = 64,
  parameter int MAX_CHAIN = 8
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              kill,
  input  wire logic              go,              // pulse
  input  wire logic [15:0]       head,
  input  wire logic [15:0]       qsize,
  input  wire logic [63:0]       desc_base,
  // guest-DMA command (owner of the port while the walker runs)
  output logic                   g_valid,
  output logic [63:0]            g_addr,
  input  wire logic              g_ready,
  input  wire logic              g_done,
  input  wire logic              g_err,
  input  wire logic [7:0]        g_code,
  input  wire logic [127:0]      pk_data,         // stage[0..15]: the fetched descriptor
  // result
  output logic                   done,            // pulse
  output logic                   err,             // with done
  output logic [7:0]             errcode,
  output logic [15:0]            ndesc,           // descriptors walked (valid at done)
  output logic [15:0]            walk_cycles,     // cycles from go to done
  // accepted chain
  output logic [7:0]             nseg,
  output logic [7:0]             nrd,
  output logic [MAX_CHAIN*64-1:0] seg_addr,
  output logic [MAX_CHAIN*32-1:0] seg_len,
  output logic [39:0]            tot_rd,
  output logic [39:0]            tot_wr
);
  localparam logic [2:0] W_IDLE = 3'd0, W_CHK = 3'd1, W_ISSUE = 3'd2, W_WAIT = 3'd3, W_PARSE = 3'd4, W_FIN = 3'd5;

  logic [2:0]            st_q;
  logic [15:0]           idx_q, cnt_q;
  logic                  first_q, seen_wr_q;
  logic [MAX_QSZ-1:0]    visited_q;
  logic [7:0]            errcode_q;
  logic                  err_q;
  logic [7:0]            nseg_q, nrd_q;
  logic [39:0]           tot_rd_q, tot_wr_q;
  logic [15:0]           cyc_q;
  logic [63:0]           seg_addr_q [0:MAX_CHAIN-1];
  logic [31:0]           seg_len_q  [0:MAX_CHAIN-1];

  // descriptor fields (little endian, from the stage)
  wire [63:0] d_addr  = pk_data[63:0];
  wire [31:0] d_len   = pk_data[95:64];
  wire [15:0] d_flags = pk_data[111:96];
  wire [15:0] d_next  = pk_data[127:112];
  wire        d_next_f  = d_flags[0];
  wire        d_write_f = d_flags[1];

  assign g_valid = (st_q == W_ISSUE);
  assign g_addr  = desc_base + {44'd0, idx_q, 4'd0};      // 16-byte descriptors

  assign done        = (st_q == W_FIN);
  assign err         = err_q;
  assign errcode     = errcode_q;
  assign ndesc       = cnt_q;
  assign walk_cycles = cyc_q;
  assign nseg        = nseg_q;
  assign nrd         = nrd_q;
  assign tot_rd      = tot_rd_q;
  assign tot_wr      = tot_wr_q;

  genvar s;
  generate
    for (s = 0; s < MAX_CHAIN; s++) begin : g_seg
      assign seg_addr[s*64 +: 64] = seg_addr_q[s];
      assign seg_len [s*32 +: 32] = seg_len_q[s];
    end
  endgenerate

  always_ff @(posedge clk or negedge rst_n) begin
    integer i;
    if (!rst_n) begin
      st_q      <= W_IDLE;
      idx_q     <= 16'd0;
      cnt_q     <= 16'd0;
      first_q   <= 1'b0;
      seen_wr_q <= 1'b0;
      visited_q <= '0;
      errcode_q <= silicaflux_virtio_pkg::FC_NONE;
      err_q     <= 1'b0;
      nseg_q    <= 8'd0;
      nrd_q     <= 8'd0;
      tot_rd_q  <= 40'd0;
      tot_wr_q  <= 40'd0;
      cyc_q     <= 16'd0;
      for (i = 0; i < MAX_CHAIN; i++) begin
        seg_addr_q[i] <= 64'd0;
        seg_len_q[i]  <= 32'd0;
      end
    end else if (kill) begin
      st_q <= W_IDLE;
    end else begin
      if (st_q != W_IDLE && st_q != W_FIN) cyc_q <= cyc_q + 16'd1;
      case (st_q)
        W_IDLE: begin
          if (go) begin
            idx_q     <= head;
            cnt_q     <= 16'd0;
            first_q   <= 1'b1;
            seen_wr_q <= 1'b0;
            visited_q <= '0;
            errcode_q <= silicaflux_virtio_pkg::FC_NONE;
            err_q     <= 1'b0;
            nseg_q    <= 8'd0;
            nrd_q     <= 8'd0;
            tot_rd_q  <= 40'd0;
            tot_wr_q  <= 40'd0;
            cyc_q     <= 16'd0;
            st_q      <= W_CHK;
          end
        end
        W_CHK: begin
          if (idx_q >= qsize) begin
            err_q     <= 1'b1;
            errcode_q <= first_q ? silicaflux_virtio_pkg::FC_BAD_HEAD : silicaflux_virtio_pkg::FC_BAD_NEXT;
            st_q      <= W_FIN;
          end else if (visited_q[idx_q[$clog2(MAX_QSZ)-1:0]]) begin
            err_q     <= 1'b1;
            errcode_q <= silicaflux_virtio_pkg::FC_CYCLE;
            st_q      <= W_FIN;
          end else if (cnt_q >= 16'(MAX_CHAIN)) begin
            err_q     <= 1'b1;
            errcode_q <= silicaflux_virtio_pkg::FC_CHAIN_TOO_LONG;
            st_q      <= W_FIN;
          end else begin
            st_q <= W_ISSUE;
          end
        end
        W_ISSUE: begin
          if (g_ready) st_q <= W_WAIT;
        end
        W_WAIT: begin
          if (g_done) begin
            if (g_err) begin
              err_q     <= 1'b1;
              errcode_q <= silicaflux_virtio_pkg::gd_is_violation(g_code) ? silicaflux_virtio_pkg::FC_DMA_DENIED
                                                                          : silicaflux_virtio_pkg::FC_GUEST_BUS;
              st_q      <= W_FIN;
            end else begin
              st_q <= W_PARSE;
            end
          end
        end
        W_PARSE: begin
          visited_q[idx_q[$clog2(MAX_QSZ)-1:0]] <= 1'b1;
          cnt_q   <= cnt_q + 16'd1;
          first_q <= 1'b0;
          if ((d_flags & ~silicaflux_virtio_pkg::DESC_F_KNOWN) != 16'd0) begin
            err_q <= 1'b1; errcode_q <= silicaflux_virtio_pkg::FC_BAD_FLAGS; st_q <= W_FIN;
          end else if ((d_flags & silicaflux_virtio_pkg::DESC_F_INDIRECT) != 16'd0) begin
            err_q <= 1'b1; errcode_q <= silicaflux_virtio_pkg::FC_INDIRECT; st_q <= W_FIN;
          end else if (!d_write_f && seen_wr_q) begin
            err_q <= 1'b1; errcode_q <= silicaflux_virtio_pkg::FC_ORDER; st_q <= W_FIN;
          end else begin
            if (d_write_f) seen_wr_q <= 1'b1;
            if (d_len != 32'd0) begin
              seg_addr_q[nseg_q[$clog2(MAX_CHAIN)-1:0]] <= d_addr;
              seg_len_q [nseg_q[$clog2(MAX_CHAIN)-1:0]] <= d_len;
              nseg_q <= nseg_q + 8'd1;
              if (d_write_f) tot_wr_q <= tot_wr_q + {8'd0, d_len};
              else begin
                tot_rd_q <= tot_rd_q + {8'd0, d_len};
                nrd_q    <= nrd_q + 8'd1;
              end
            end
            if (d_next_f) begin
              idx_q <= d_next;
              st_q  <= W_CHK;
            end else begin
              st_q <= W_FIN;
            end
          end
        end
        W_FIN: st_q <= W_IDLE;
        default: st_q <= W_IDLE;
      endcase
    end
  end
endmodule

`default_nettype wire
