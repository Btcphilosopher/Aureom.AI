// =============================================================================
// VirtualIO :: sfv_beat_mover -- byte-exact transfer between an on-chip stage buffer and an SFB2-style port
//
// Moves `len` bytes (1 .. 2^SAW) between stage[soff .. soff+len) and a memory port at an ARBITRARY byte address.  The
// port is one-beat-at-a-time ready/valid (SFB2: one outstanding request, response never in the acceptance cycle):
//   * the first and last beat are partial -- their byte strobes cover only the bytes that belong to the transfer, so a
//     write NEVER touches a byte outside [addr, addr+len);
//   * every beat is presented to a combinational guard (g_lo / g_len / g_ok) BEFORE it is issued: if the guard refuses,
//     the beat is not issued and the transfer ends with res = 1;
//   * the request payload is registered and held until req_ready (SFB2 R2/R3); the response is accepted in M_RSP only.
// abort_i is sampled at beat boundaries: the beat in flight is always completed (a valid request cannot be withdrawn),
// no further beat is issued, and the transfer ends with res = 3.
//   res: 0 ok | 1 guard refused a beat | 2 the port answered with an error | 3 aborted
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfv_beat_mover #(
  parameter int AW  = 48,
  parameter int DW  = 64,
  parameter int SAW = 6                       // log2(stage bytes)
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              start,       // pulse, only while !busy
  input  wire logic              wr,          // 1: stage -> port   0: port -> stage
  input  wire logic [AW-1:0]     addr,
  input  wire logic [15:0]       len,
  input  wire logic [SAW-1:0]    soff,
  input  wire logic              abort_i,
  output logic                   busy,
  output logic                   done,        // one-cycle pulse, res valid
  output logic [2:0]             res,
  // memory port (master)
  output logic                   req_valid,
  input  wire logic              req_ready,
  output logic                   req_write,
  output logic [AW-1:0]          req_addr,
  output logic [DW-1:0]          req_wdata,
  output logic [DW/8-1:0]        req_wstrb,
  input  wire logic              rsp_valid,
  output logic                   rsp_ready,
  input  wire logic [DW-1:0]     rsp_rdata,
  input  wire logic              rsp_error,
  // beat guard (combinational verdict for the beat about to be issued)
  output logic [AW-1:0]          g_lo,
  output logic [15:0]            g_len,
  input  wire logic              g_ok,
  // stage buffer, byte lanes
  output logic [DW/8-1:0]        st_we,
  output logic [(DW/8)*SAW-1:0]  st_widx,
  output logic [DW-1:0]          st_wdata,
  output logic [(DW/8)*SAW-1:0]  st_ridx,
  input  wire logic [DW-1:0]     st_rdata
);
  localparam int BW  = DW / 8;
  localparam int BWB = $clog2(BW);

  localparam logic [2:0] M_IDLE = 3'd0, M_PREP = 3'd1, M_REQ = 3'd2, M_RSP = 3'd3, M_FIN = 3'd4;

  logic [2:0]       st_q;
  logic             wr_q;
  logic [AW-1:0]    addr_q;
  logic [15:0]      len_q, k_q, nb_q;
  logic [SAW-1:0]   soff_q;
  logic [2:0]       res_q;

  // ------------------------------------------------------------------ lane geometry of the current beat (combinational)
  logic [BW-1:0]    lane_v;
  logic [SAW-1:0]   lane_idx [0:BW-1];
  logic [AW-1:0]    beat_base;
  logic [15:0]      nvalid;

  always_comb begin
    integer j, p, off0, bpos;
    off0 = {{(32-BWB){1'b0}}, addr_q[BWB-1:0]};
    bpos = $signed({16'd0, k_q}) * BW - off0;
    nvalid = 16'd0;
    for (j = 0; j < BW; j++) begin
      p = bpos + j;                                              // byte position relative to the first byte of the transfer (negative before it)
      lane_v[j]   = (p >= 0) && (p < $signed({16'd0, len_q}));
      lane_idx[j] = SAW'($signed({{(32-SAW){1'b0}}, soff_q}) + p);
      if (lane_v[j]) nvalid = nvalid + 16'd1;
    end
    beat_base = addr_q + AW'(k_q) * AW'(BW) - AW'(addr_q[BWB-1:0]);   // aligned base of beat k
    g_lo  = (k_q == 16'd0) ? addr_q : beat_base;
    g_len = nvalid;
  end

  // stage lane indices for reads of the stage (write beats) and writes into it (read beats)
  always_comb begin
    integer j;
    for (j = 0; j < BW; j++) begin
      st_ridx[j*SAW +: SAW] = lane_idx[j];
      st_widx[j*SAW +: SAW] = lane_idx[j];
      st_wdata[j*8 +: 8]    = rsp_rdata[j*8 +: 8];
      st_we[j]              = (st_q == M_RSP) && rsp_valid && !rsp_error && !wr_q && lane_v[j];
    end
  end

  assign busy      = (st_q != M_IDLE);
  assign done      = (st_q == M_FIN);
  assign res       = res_q;
  assign rsp_ready = (st_q == M_RSP);

  logic [DW-1:0]   wdata_n;
  logic [BW-1:0]   wstrb_n;
  always_comb begin
    integer j;
    wdata_n = '0;
    wstrb_n = '0;
    for (j = 0; j < BW; j++) begin
      if (wr_q && lane_v[j]) begin
        wdata_n[j*8 +: 8] = st_rdata[j*8 +: 8];
        wstrb_n[j]        = 1'b1;
      end
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q      <= M_IDLE;
      wr_q      <= 1'b0;
      addr_q    <= '0;
      len_q     <= '0;
      k_q       <= '0;
      nb_q      <= '0;
      soff_q    <= '0;
      res_q     <= 3'd0;
      req_valid <= 1'b0;
      req_write <= 1'b0;
      req_addr  <= '0;
      req_wdata <= '0;
      req_wstrb <= '0;
    end else begin
      case (st_q)
        M_IDLE: begin
          if (start) begin
            wr_q   <= wr;
            addr_q <= addr;
            len_q  <= len;
            soff_q <= soff;
            k_q    <= 16'd0;
            nb_q   <= (16'(addr[BWB-1:0]) + len + 16'(BW - 1)) >> BWB;
            res_q  <= 3'd0;
            st_q   <= M_PREP;
          end
        end
        M_PREP: begin
          if (abort_i) begin
            res_q <= 3'd3;
            st_q  <= M_FIN;
          end else if (!g_ok) begin
            res_q <= 3'd1;
            st_q  <= M_FIN;
          end else begin
            req_valid <= 1'b1;
            req_write <= wr_q;
            req_addr  <= beat_base;
            req_wdata <= wdata_n;
            req_wstrb <= wstrb_n;
            st_q      <= M_REQ;
          end
        end
        M_REQ: begin
          if (req_ready) begin
            req_valid <= 1'b0;
            st_q      <= M_RSP;
          end
        end
        M_RSP: begin
          if (rsp_valid) begin
            if (rsp_error) begin
              res_q <= 3'd2;
              st_q  <= M_FIN;
            end else if ((k_q + 16'd1) == nb_q) begin
              res_q <= 3'd0;
              st_q  <= M_FIN;
            end else if (abort_i) begin
              res_q <= 3'd3;
              st_q  <= M_FIN;
            end else begin
              k_q  <= k_q + 16'd1;
              st_q <= M_PREP;
            end
          end
        end
        M_FIN: st_q <= M_IDLE;
        default: st_q <= M_IDLE;
      endcase
    end
  end
endmodule

`default_nettype wire
