// =============================================================================
// VirtualIO :: sfv_ramdisk -- PROTECTED BACKEND: per-domain partitions of a volatile block store (RAM disk)
//
// This is the "protected backend" the virtio-blk requests are executed against.  It is NOT flash, NOT the StorageCore
// FTL and NOT persistent: it is a word-organised RAM whose bytes are divided into per-domain partitions.  Why this and
// not a network / storage backend: docs/AUDIT.md (no NetworkCore exists; StorageFabric is blocked; P51 needs firmware
// and a NAND model).
//
// PROTECTION (independent of the engine -- the engine cannot name an absolute store address):
//   * a request carries {domain, partition-RELATIVE byte address}; the store adds the domain's partition base;
//   * a beat is served only if the domain is enabled, not being scrubbed, and the whole beat lies inside the domain's
//     partition AND inside the store; otherwise the beat is answered with an error and NOTHING is read or written;
//   * partitions of enabled domains never overlap (checked at commit); base and size are multiples of 512 bytes;
//   * a partition is ZEROED (scrub) when it is committed with scrub = 1, so a new owner cannot read the previous
//     owner's bytes; while it scrubs the store serves no request at all (documented limitation: one scrubber, the
//     shared store port stalls).
// SFB2 slave: one outstanding request; the response comes the cycle after acceptance and is held until rsp_ready;
// error and write responses carry rdata == 0.
// Classification: SYNTHESIZABLE (the RAM maps to a memory macro / block RAM)
// =============================================================================
`default_nettype none

module sfv_ramdisk #(
  parameter int DW          = 64,
  parameter int AW          = 32,
  parameter int STORE_BYTES = 65536,
  parameter int ND          = 2,
  parameter int DOMW        = 1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // SFB2 slave
  input  wire logic              s_req_valid,
  output logic                   s_req_ready,
  input  wire logic              s_req_write,
  input  wire logic [AW-1:0]     s_req_addr,
  input  wire logic [DW-1:0]     s_req_wdata,
  input  wire logic [DW/8-1:0]   s_req_wstrb,
  input  wire logic [DOMW-1:0]   s_req_dom,
  output logic                   s_rsp_valid,
  input  wire logic              s_rsp_ready,
  output logic [DW-1:0]          s_rsp_rdata,
  output logic                   s_rsp_error,
  // partition configuration (management plane)
  input  wire logic              pc_valid,       // commit request (sampled when pc_ok)
  input  wire logic [DOMW-1:0]   pc_dom,
  input  wire logic [31:0]       pc_base,
  input  wire logic [31:0]       pc_size,
  input  wire logic              pc_en,
  input  wire logic              pc_scrub,
  output logic                   pc_ok,          // combinational: would this commit be accepted right now?
  output logic [ND-1:0]          part_en_o,
  output logic [ND-1:0]          part_busy_o,
  output logic [ND*32-1:0]       part_size_o
);
  localparam int BW    = DW / 8;
  localparam int WORDS = STORE_BYTES / BW;
  localparam int WAW   = $clog2(WORDS);

  logic [DW-1:0]   mem [0:WORDS-1];
`ifndef SYNTHESIS
  initial begin : init_mem
    integer i;
    for (i = 0; i < WORDS; i++) mem[i] = '0;
  end
`endif

  logic [31:0]     pbase [0:ND-1];
  logic [31:0]     psize [0:ND-1];
  logic [ND-1:0]   pen;

  // scrub engine
  logic            scr_busy;
  logic [DOMW-1:0] scr_dom;
  logic [WAW:0]    scr_idx, scr_end;
  logic            scr_en_after;   // value of `enable` to apply when the scrub finishes

  // ------------------------------------------------------------------ commit validation (combinational)
  logic ovl;
  always_comb begin
    integer d;
    ovl = 1'b0;
    for (d = 0; d < ND; d++)
      if ((d != 32'(pc_dom)) && pen[d] && (pbase[d] < (pc_base + pc_size)) && (pc_base < (pbase[d] + psize[d])))
        ovl = 1'b1;
  end
  wire [32:0] pc_end   = {1'b0, pc_base} + {1'b0, pc_size};
  wire        geo_ok   = (pc_size != 32'd0) && (pc_base[8:0] == 9'd0) && (pc_size[8:0] == 9'd0) &&
                         (pc_end <= 33'(STORE_BYTES));
  wire        dom_ok   = (32'(pc_dom) < ND);
  // disabling is always allowed (when the scrubber is free); enabling needs a sane, non-overlapping partition
  assign pc_ok = dom_ok && !scr_busy && (!pc_en || (geo_ok && !ovl));

  // ------------------------------------------------------------------ SFB2 slave
  logic              rsp_v_q, rsp_e_q;
  logic [DW-1:0]     rsp_d_q;
  assign s_rsp_valid = rsp_v_q;
  assign s_rsp_error = rsp_e_q;
  assign s_rsp_rdata = rsp_d_q;
  assign s_req_ready = !rsp_v_q && !scr_busy;

  wire [32:0] a_end  = {1'b0, 32'(s_req_addr)} + 33'(BW);
  logic [32:0] sel_base, sel_size;
  logic        sel_ok_dom;
  always_comb begin
    sel_ok_dom = (32'(s_req_dom) < ND) && pen[(32'(s_req_dom) < ND) ? 32'(s_req_dom) : 0];
    sel_base   = {1'b0, pbase[(32'(s_req_dom) < ND) ? 32'(s_req_dom) : 0]};
    sel_size   = {1'b0, psize[(32'(s_req_dom) < ND) ? 32'(s_req_dom) : 0]};
  end
  wire [32:0] abs_a   = sel_base + {1'b0, 32'(s_req_addr)};
  wire        acc_ok  = sel_ok_dom && (a_end <= sel_size) && ((abs_a + 33'(BW)) <= 33'(STORE_BYTES)) &&
                        (s_req_addr[$clog2(BW)-1:0] == '0);
  wire [WAW-1:0] widx = WAW'(abs_a[31:0] / BW);

  always_ff @(posedge clk) begin
    integer b;
    if (scr_busy) begin
      mem[scr_idx[WAW-1:0]] <= '0;
    end else if (s_req_valid && s_req_ready && acc_ok && s_req_write) begin
      for (b = 0; b < BW; b++)
        if (s_req_wstrb[b]) mem[widx][b*8 +: 8] <= s_req_wdata[b*8 +: 8];
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rsp_v_q <= 1'b0;
      rsp_e_q <= 1'b0;
      rsp_d_q <= '0;
    end else begin
      if (rsp_v_q && s_rsp_ready) rsp_v_q <= 1'b0;
      if (s_req_valid && s_req_ready) begin
        rsp_v_q <= 1'b1;
        rsp_e_q <= !acc_ok;
        rsp_d_q <= (acc_ok && !s_req_write) ? mem[widx] : '0;
      end
    end
  end

  // ------------------------------------------------------------------ partition table + scrubber
  genvar g;
  generate
    for (g = 0; g < ND; g++) begin : g_out
      assign part_en_o[g]   = pen[g];
      assign part_busy_o[g] = scr_busy && (32'(scr_dom) == g);
      assign part_size_o[g*32 +: 32] = psize[g];
    end
  endgenerate

  always_ff @(posedge clk or negedge rst_n) begin
    integer d;
    if (!rst_n) begin
      for (d = 0; d < ND; d++) begin
        pbase[d] <= 32'd0;
        psize[d] <= 32'd0;
      end
      pen          <= '0;
      scr_busy     <= 1'b0;
      scr_dom      <= '0;
      scr_idx      <= '0;
      scr_end      <= '0;
      scr_en_after <= 1'b0;
    end else begin
      if (scr_busy) begin
        if (scr_idx + 1 >= scr_end) begin
          scr_busy <= 1'b0;
          pen[scr_dom] <= scr_en_after;
        end else begin
          scr_idx <= scr_idx + 1;
        end
      end else if (pc_valid && pc_ok) begin
        if (pc_en) begin
          pbase[pc_dom] <= pc_base;
          psize[pc_dom] <= pc_size;
          if (pc_scrub) begin
            pen[pc_dom]  <= 1'b0;                       // not usable until zeroed
            scr_busy     <= 1'b1;
            scr_dom      <= pc_dom;
            scr_idx      <= (WAW+1)'(pc_base / BW);
            scr_end      <= (WAW+1)'((pc_base + pc_size) / BW);
            scr_en_after <= 1'b1;
          end else begin
            pen[pc_dom] <= 1'b1;
          end
        end else begin
          pen[pc_dom] <= 1'b0;                          // disabled at once, scrubbed afterwards if asked
          if (pc_scrub && (psize[pc_dom] != 32'd0)) begin
            scr_busy     <= 1'b1;
            scr_dom      <= pc_dom;
            scr_idx      <= (WAW+1)'(pbase[pc_dom] / BW);
            scr_end      <= (WAW+1)'((pbase[pc_dom] + psize[pc_dom]) / BW);
            scr_en_after <= 1'b0;
          end
        end
      end
    end
  end
endmodule

`default_nettype wire
