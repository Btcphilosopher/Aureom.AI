// =============================================================================
// VirtualIO :: sfv_engine_core -- virtio-blk acceleration engine core (everything except the backend memory)
//
// Ports (all SFB2-shaped ready/valid, single clock):
//   mmio_*   guest-visible virtio-mmio v2 windows, one 4 KiB window per function (address bits [15:12] select the
//            function).  Request accepted every cycle (ready tied high); response one cycle later.  32-bit accesses.
//   irq_o    one level interrupt line per function = |InterruptStatus (virtio-mmio semantics)
//   mg_*     management port (hypervisor): windows, partitions, function binding, fault log, counters
//   gm_*     guest-memory MASTER (SFB2, `AW` address bits, `DW` data bits): the only way to guest memory.  Attach a PCIe
//            endpoint / AXI interconnect through sfd_sfb2_to_axi4 (CloudDPU P61 integration/).
//   bk_*     backend MASTER (SFB2 + domain sideband): partition-relative byte addresses; sfv_ramdisk is the shipped backend
//   pc_* / part_*   backend partition control (to / from the backend)
//   iommu_*  optional external IOMMU (EXT_IOMMU = 1; otherwise tied off)
//
// Architecture: sfv_func_regs (xNF) -> sfv_queue_ctrl {sfv_desc_walker, sfv_blk_exec} -> sfv_gdma {sfv_domain_adapter,
// sfv_beat_mover, stage buffer} -> gm_* / bk_*.   NF functions share one engine; each function is one virtio-blk device
// with ONE split request virtqueue, bound by management to one DMA domain.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfv_engine_core #(
  parameter int NF          = 1,       // functions (1..8): the multi-tenant option; 1 = the first version
  parameter int ND          = 2,       // DMA domains (1..8)
  parameter int NW          = 4,       // windows per domain
  parameter int MAX_QSZ     = 64,      // QueueNumMax (power of two, 2..32768)
  parameter int MAX_CHAIN   = 8,       // descriptors per chain (>= 3)  -> seg_max = MAX_CHAIN - 2
  parameter int STAGE       = 64,      // stage buffer bytes (power of two, 16..4096)
  parameter int AW          = 48,      // guest address width
  parameter int DW          = 64,      // guest / backend data width (32, 64 or 128)
  parameter int BKAW        = 32,      // backend address width
  parameter int EXT_IOMMU   = 0,
  parameter int STORE_BYTES = 65536    // reported in the capability register
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // guest MMIO
  input  wire logic              mmio_req_valid,
  output logic                   mmio_req_ready,
  input  wire logic              mmio_req_write,
  input  wire logic [15:0]       mmio_req_addr,
  input  wire logic [31:0]       mmio_req_wdata,
  output logic                   mmio_rsp_valid,
  output logic [31:0]            mmio_rsp_rdata,
  output logic                   mmio_rsp_err,
  output logic [NF-1:0]          irq_o,
  // management
  input  wire logic              mg_req_valid,
  output logic                   mg_req_ready,
  input  wire logic              mg_req_write,
  input  wire logic [11:0]       mg_req_addr,
  input  wire logic [31:0]       mg_req_wdata,
  output logic                   mg_rsp_valid,
  output logic [31:0]            mg_rsp_rdata,
  output logic                   mg_rsp_err,
  output logic                   mgmt_irq_o,
  // guest memory master
  output logic                   gm_req_valid,
  input  wire logic              gm_req_ready,
  output logic                   gm_req_write,
  output logic [AW-1:0]          gm_req_addr,
  output logic [DW-1:0]          gm_req_wdata,
  output logic [DW/8-1:0]        gm_req_wstrb,
  input  wire logic              gm_rsp_valid,
  output logic                   gm_rsp_ready,
  input  wire logic [DW-1:0]     gm_rsp_rdata,
  input  wire logic              gm_rsp_error,
  // backend master
  output logic                   bk_req_valid,
  input  wire logic              bk_req_ready,
  output logic                   bk_req_write,
  output logic [BKAW-1:0]        bk_req_addr,
  output logic [DW-1:0]          bk_req_wdata,
  output logic [DW/8-1:0]        bk_req_wstrb,
  output logic [$clog2(ND > 1 ? ND : 2)-1:0] bk_req_dom,
  input  wire logic              bk_rsp_valid,
  output logic                   bk_rsp_ready,
  input  wire logic [DW-1:0]     bk_rsp_rdata,
  input  wire logic              bk_rsp_error,
  // backend partition control
  output logic                   pc_valid,
  output logic [$clog2(ND > 1 ? ND : 2)-1:0] pc_dom,
  output logic [31:0]            pc_base,
  output logic [31:0]            pc_size,
  output logic                   pc_en,
  output logic                   pc_scrub,
  input  wire logic              pc_ok,
  input  wire logic [ND-1:0]     part_en_i,
  input  wire logic [ND-1:0]     part_busy_i,
  input  wire logic [ND*32-1:0]  part_size_i,
  // external IOMMU
  output logic                   iommu_req_valid,
  input  wire logic              iommu_req_ready,
  output logic [$clog2(ND > 1 ? ND : 2)-1:0] iommu_req_dom,
  output logic [63:0]            iommu_req_iova,
  output logic [31:0]            iommu_req_len,
  output logic                   iommu_req_write,
  input  wire logic              iommu_rsp_valid,
  input  wire logic              iommu_rsp_ok,
  input  wire logic [AW-1:0]     iommu_rsp_pa
);
  // ---- illegal parameter sets are REFUSED at elaboration (an unknown module is instantiated; the generate-block name says why)
  generate
    if (NF < 1 || NF > 8)                         begin : ERR_NUM_FUNCS_MUST_BE_1_TO_8                  sfv_illegal_parameter_set u_err (); end
    if (ND < 1 || ND > 8)                         begin : ERR_NUM_DOMAINS_MUST_BE_1_TO_8                sfv_illegal_parameter_set u_err (); end
    if (NW < 1 || NW > 8)                         begin : ERR_NUM_WIN_MUST_BE_1_TO_8                    sfv_illegal_parameter_set u_err (); end
    if (MAX_QSZ < 2 || MAX_QSZ > 4096 || (MAX_QSZ & (MAX_QSZ - 1)) != 0)
                                                  begin : ERR_MAX_QSZ_MUST_BE_POWER_OF_TWO_2_TO_4096    sfv_illegal_parameter_set u_err (); end
    if (MAX_CHAIN < 3 || MAX_CHAIN > 32)          begin : ERR_MAX_CHAIN_MUST_BE_3_TO_32                 sfv_illegal_parameter_set u_err (); end
    if (STAGE < 16 || STAGE > 4096 || (STAGE & (STAGE - 1)) != 0)
                                                  begin : ERR_STAGE_MUST_BE_POWER_OF_TWO_16_TO_4096     sfv_illegal_parameter_set u_err (); end
    if (DW != 32 && DW != 64 && DW != 128)        begin : ERR_DATA_WIDTH_MUST_BE_32_64_OR_128           sfv_illegal_parameter_set u_err (); end
    if (AW < 32 || AW > 64)                       begin : ERR_ADDRESS_WIDTH_MUST_BE_32_TO_64            sfv_illegal_parameter_set u_err (); end
    if (BKAW != 32)                               begin : ERR_BACKEND_ADDRESS_WIDTH_MUST_BE_32          sfv_illegal_parameter_set u_err (); end
  endgenerate

  localparam int FW   = (NF > 1) ? $clog2(NF) : 1;
  localparam int DOMW = (ND > 1) ? $clog2(ND) : 1;
  localparam int SAW  = $clog2(STAGE);

  // ------------------------------------------------------------------ management block
  logic [ND-1:0]        dom_en;
  logic [ND*NW*64-1:0]  win_base, win_size;
  logic [ND*NW*3-1:0]   win_ctl;
  logic [NF-1:0]        f_en, f_ro, f_quar;
  logic [NF*DOMW-1:0]   f_dom;
  logic [NF*64-1:0]     f_cap;
  logic [NF*8-1:0]      f_status;
  logic [NF-1:0]        f_inuse, f_qready, f_running, f_kick, f_drv_ok, f_rst_req, f_rst_ack, f_fatal, f_irq_set;
  logic [NF*16-1:0]     f_qnum, o_la, o_ui;
  logic [NF*64-1:0]     f_desc, f_avail, f_used;
  logic [NF-1:0]        o_pend;
  logic                 flt_v;
  logic [FW-1:0]        flt_f;
  logic [7:0]           flt_code, flt_detail;
  logic [FW-1:0]        perf_func;
  logic [7:0]           perf_ctr;
  logic                 perf_clr;
  logic [31:0]          perf_data;

  sfv_mgmt #(.NF(NF), .FW(FW), .ND(ND), .DOMW(DOMW), .NW(NW), .MAX_QSZ(MAX_QSZ), .MAX_CHAIN(MAX_CHAIN), .STAGE(STAGE),
             .GM_AW(AW), .DW(DW), .EXT_IOMMU(EXT_IOMMU), .STORE_BYTES(STORE_BYTES)) u_mgmt (
    .clk, .rst_n,
    .mg_req_valid, .mg_req_ready, .mg_req_write, .mg_req_addr, .mg_req_wdata,
    .mg_rsp_valid, .mg_rsp_rdata, .mg_rsp_err, .irq_o(mgmt_irq_o),
    .dom_en_o(dom_en), .win_base_o(win_base), .win_size_o(win_size), .win_ctl_o(win_ctl),
    .pc_valid, .pc_dom, .pc_base, .pc_size, .pc_en, .pc_scrub, .pc_ok, .part_en_i, .part_busy_i, .part_size_i,
    .f_en_o(f_en), .f_ro_o(f_ro), .f_quar_o(f_quar), .f_dom_o(f_dom), .f_cap_o(f_cap),
    .f_status_i(f_status), .f_inuse_i(f_inuse), .f_qready_i(f_qready), .f_pend_i(o_pend), .f_la_i(o_la), .f_ui_i(o_ui),
    .flt_v, .flt_f, .flt_code, .flt_detail,
    .perf_func, .perf_ctr, .perf_clr, .perf_data);

  // ------------------------------------------------------------------ guest MMIO decode
  wire [3:0]  m_fidx   = mmio_req_addr[15:12];
  wire        m_fok    = (32'(m_fidx) < NF) && (mmio_req_addr[1:0] == 2'b00);
  logic [NF-1:0] fr_wr;
  logic [31:0]   fr_rdata [0:NF-1];
  logic [31:0]   m_rd;
  always_comb begin
    integer f;
    m_rd = 32'd0;
    for (f = 0; f < NF; f++) begin
      fr_wr[f] = mmio_req_valid && mmio_req_write && m_fok && (32'(m_fidx) == f);
      if (m_fok && 32'(m_fidx) == f) m_rd = fr_rdata[f];
    end
  end
  assign mmio_req_ready = 1'b1;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mmio_rsp_valid <= 1'b0;
      mmio_rsp_rdata <= 32'd0;
      mmio_rsp_err   <= 1'b0;
    end else begin
      mmio_rsp_valid <= mmio_req_valid;
      mmio_rsp_rdata <= (mmio_req_valid && !mmio_req_write && m_fok) ? m_rd : 32'd0;
      mmio_rsp_err   <= mmio_req_valid && !m_fok;
    end
  end

  genvar f;
  generate
    for (f = 0; f < NF; f++) begin : g_fn
      sfv_func_regs #(.MAX_QSZ(MAX_QSZ), .MAX_CHAIN(MAX_CHAIN), .GM_AW(AW), .EXT_IOMMU(EXT_IOMMU)) u_regs (
        .clk, .rst_n,
        .rd_en(mmio_req_valid && !mmio_req_write), .wr_en(fr_wr[f]), .addr(mmio_req_addr[11:0]), .wdata(mmio_req_wdata),
        .rdata(fr_rdata[f]),
        .cfg_en(f_en[f]), .cfg_ro(f_ro[f]), .cfg_cap(f_cap[f*64 +: 64]),
        .running(f_running[f]), .qready(f_qready[f]), .qnum(f_qnum[f*16 +: 16]),
        .q_desc(f_desc[f*64 +: 64]), .q_avail(f_avail[f*64 +: 64]), .q_used(f_used[f*64 +: 64]),
        .kick(f_kick[f]), .drv_ok_evt(f_drv_ok[f]), .rst_req(f_rst_req[f]), .rst_ack(f_rst_ack[f]),
        .fatal_set(f_fatal[f]), .irq_set(f_irq_set[f]), .status_o(f_status[f*8 +: 8]), .irq_o(irq_o[f]),
        .in_use(f_inuse[f]));
    end
  endgenerate

  // ------------------------------------------------------------------ queue controller + guest DMA
  logic                c_valid, c_ready, c_tgt, c_wr, c_data, c_done, c_err, abort, ld_en, c_busy;
  logic [DOMW-1:0]     c_dom;
  logic [63:0]         c_addr;
  logic [15:0]         c_len;
  logic [SAW-1:0]      c_soff;
  logic [7:0]          c_code, c_detail;
  logic [127:0]        ld_data, pk_data;
  logic [15:0]         ld_mask;
  logic                gd_ev_ok, gd_ev_tgt, gd_ev_wr, gd_ev_data, gd_ev_viol, gd_stall;
  logic [15:0]         gd_ev_len;

  logic [FW-1:0]       o_cf;
  logic                o_busy, p_req_done, p_req_err, p_walk_v, p_irq, p_irq_supp, p_viol, p_fatal, p_util_v;
  logic [31:0]         p_lat;
  logic [15:0]         p_walk, p_ndesc, p_util;
  logic [NF-1:0]       p_wait;

  sfv_queue_ctrl #(.NF(NF), .FW(FW), .DOMW(DOMW), .MAX_QSZ(MAX_QSZ), .MAX_CHAIN(MAX_CHAIN), .STAGE(STAGE)) u_qc (
    .clk, .rst_n,
    .f_running, .f_kick, .f_drv_ok_evt(f_drv_ok), .f_rst_req, .f_qnum, .f_desc, .f_avail, .f_used,
    .f_dom, .f_cap, .f_ro, .f_quar, .f_rst_ack, .f_fatal_set(f_fatal), .f_irq_set,
    .cmd_valid(c_valid), .cmd_tgt(c_tgt), .cmd_wr(c_wr), .cmd_data(c_data), .cmd_dom(c_dom), .cmd_addr(c_addr),
    .cmd_len(c_len), .cmd_soff(c_soff), .cmd_ready(c_ready), .cmd_done(c_done), .cmd_err(c_err), .cmd_code(c_code),
    .cmd_detail(c_detail), .abort_o(abort), .ld_en, .ld_data, .ld_mask, .pk_data,
    .flt_v, .flt_f, .flt_code, .flt_detail,
    .o_last_avail(o_la), .o_used_idx(o_ui), .o_pend, .o_cf, .o_busy,
    .p_req_done, .p_req_err, .p_lat, .p_walk_v, .p_walk, .p_ndesc, .p_irq, .p_irq_supp, .p_viol, .p_fatal,
    .p_util_v, .p_util, .p_wait);

  sfv_gdma #(.AW(AW), .DW(DW), .BKAW(BKAW), .STAGE(STAGE), .ND(ND), .NW(NW), .DOMW(DOMW), .EXT_IOMMU(EXT_IOMMU)) u_gdma (
    .clk, .rst_n,
    .c_valid, .c_ready, .c_tgt, .c_wr, .c_data, .c_dom, .c_addr, .c_len, .c_soff, .abort_i(abort),
    .c_done, .c_err, .c_code, .c_detail, .busy_o(c_busy),
    .ld_en, .ld_data, .ld_mask, .pk_data,
    .ev_ok(gd_ev_ok), .ev_len(gd_ev_len), .ev_tgt(gd_ev_tgt), .ev_wr(gd_ev_wr), .ev_data(gd_ev_data),
    .ev_viol(gd_ev_viol), .stall_o(gd_stall),
    .gm_req_valid, .gm_req_ready, .gm_req_write, .gm_req_addr, .gm_req_wdata, .gm_req_wstrb,
    .gm_rsp_valid, .gm_rsp_ready, .gm_rsp_rdata, .gm_rsp_error,
    .bk_req_valid, .bk_req_ready, .bk_req_write, .bk_req_addr, .bk_req_wdata, .bk_req_wstrb, .bk_req_dom,
    .bk_rsp_valid, .bk_rsp_ready, .bk_rsp_rdata, .bk_rsp_error,
    .dom_en, .win_base, .win_size, .win_ctl,
    .iommu_req_valid, .iommu_req_ready, .iommu_req_dom, .iommu_req_iova, .iommu_req_len, .iommu_req_write,
    .iommu_rsp_valid, .iommu_rsp_ok, .iommu_rsp_pa);

  // ------------------------------------------------------------------ counters
  sfv_perf #(.NF(NF), .FW(FW)) u_perf (
    .clk, .rst_n, .clr(perf_clr), .rd_func(perf_func), .rd_ctr(perf_ctr), .rd_data(perf_data),
    .ev_cf(o_cf), .ev_busy(o_busy), .ev_bus_stall(gd_stall && o_busy),
    .ev_req_done(p_req_done), .ev_req_err(p_req_err), .ev_lat(p_lat),
    .ev_walk_v(p_walk_v), .ev_walk(p_walk), .ev_ndesc(p_ndesc),
    .ev_irq(p_irq), .ev_irq_supp(p_irq_supp), .ev_viol(p_viol), .ev_fatal(p_fatal),
    .ev_util_v(p_util_v), .ev_util(p_util),
    .ev_rd_data_v(gd_ev_ok && !gd_ev_tgt && !gd_ev_wr &&  gd_ev_data),
    .ev_wr_data_v(gd_ev_ok && !gd_ev_tgt &&  gd_ev_wr &&  gd_ev_data),
    .ev_meta_v   (gd_ev_ok && !gd_ev_tgt && !gd_ev_data),
    .ev_bytes(gd_ev_len),
    .kick_v(f_kick), .wait_v(p_wait));

  wire unused_core = &{1'b0, c_busy, gd_ev_viol};
endmodule

`default_nettype wire
