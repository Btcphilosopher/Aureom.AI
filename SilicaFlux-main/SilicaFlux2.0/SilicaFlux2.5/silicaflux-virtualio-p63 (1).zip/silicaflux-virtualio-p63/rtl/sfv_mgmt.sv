// =============================================================================
// VirtualIO :: sfv_mgmt -- MANAGEMENT-PLANE register block (hypervisor / ControlCore side; NEVER reachable by a guest)
//
// Everything that decides what a guest may touch is programmed here, through a port the guest cannot address:
//   * per-domain DMA windows {base, size, R, W, valid}   -> sfv_domain_adapter     (WIN_* then WIN_CTL commits atomically)
//   * per-domain backend partition + enable + scrub        -> sfv_ramdisk            (DOM_PBASE/PSIZE then DOM_CTL commits)
//   * per-function binding {enable, domain, capacity, read-only, quarantine}         (FUNC_* then FUNC_CTL commits)
// plus the fault log, the performance-counter readout and the capability registers.
//
// Rules enforced here:
//   * a function can be (re)configured only while its device status is 0 and no reset is pending (guest cannot be
//     surprised mid-session; the write is answered with an error otherwise);
//   * a function can be enabled only if its domain's partition is configured and holds the whole capacity;
//   * a domain commit is accepted only if the backend accepts the partition (aligned, inside the store, no overlap with
//     another enabled domain, scrubber free);
//   * the domain enable seen by the DMA adapter is (enabled AND partition usable): it falls while a scrub runs.
// Window updates take effect immediately (revocation): the per-beat guard consults the live table.
// Port: one request at a time (mg_req_ready = 1 whenever no response is pending); the response follows one cycle later.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfv_mgmt #(
  parameter int NF          = 1,
  parameter int FW          = 1,
  parameter int ND          = 2,
  parameter int DOMW        = 1,
  parameter int NW          = 4,
  parameter int MAX_QSZ     = 64,
  parameter int MAX_CHAIN   = 8,
  parameter int STAGE       = 64,
  parameter int GM_AW       = 48,
  parameter int DW          = 64,
  parameter int EXT_IOMMU   = 0,
  parameter int STORE_BYTES = 32768
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // management register port
  input  wire logic                mg_req_valid,
  output logic                     mg_req_ready,
  input  wire logic                mg_req_write,
  input  wire logic [11:0]         mg_req_addr,
  input  wire logic [31:0]         mg_req_wdata,
  output logic                     mg_rsp_valid,
  output logic [31:0]              mg_rsp_rdata,
  output logic                     mg_rsp_err,
  output logic                     irq_o,
  // domain tables -> adapter
  output logic [ND-1:0]            dom_en_o,
  output logic [ND*NW*64-1:0]      win_base_o,
  output logic [ND*NW*64-1:0]      win_size_o,
  output logic [ND*NW*3-1:0]       win_ctl_o,
  // backend partition control
  output logic                     pc_valid,
  output logic [DOMW-1:0]          pc_dom,
  output logic [31:0]              pc_base,
  output logic [31:0]              pc_size,
  output logic                     pc_en,
  output logic                     pc_scrub,
  input  wire logic                pc_ok,
  input  wire logic [ND-1:0]       part_en_i,
  input  wire logic [ND-1:0]       part_busy_i,
  input  wire logic [ND*32-1:0]    part_size_i,
  // per-function configuration -> function blocks / queue controller
  output logic [NF-1:0]            f_en_o,
  output logic [NF-1:0]            f_ro_o,
  output logic [NF-1:0]            f_quar_o,
  output logic [NF*DOMW-1:0]       f_dom_o,
  output logic [NF*64-1:0]         f_cap_o,
  // per-function state
  input  wire logic [NF*8-1:0]     f_status_i,
  input  wire logic [NF-1:0]       f_inuse_i,
  input  wire logic [NF-1:0]       f_qready_i,
  input  wire logic [NF-1:0]       f_pend_i,
  input  wire logic [NF*16-1:0]    f_la_i,
  input  wire logic [NF*16-1:0]    f_ui_i,
  // fault log
  input  wire logic                flt_v,
  input  wire logic [FW-1:0]       flt_f,
  input  wire logic [7:0]          flt_code,
  input  wire logic [7:0]          flt_detail,
  // performance counters
  output logic [FW-1:0]            perf_func,
  output logic [7:0]               perf_ctr,
  output logic                     perf_clr,
  input  wire logic [31:0]         perf_data
);
  localparam int NWT = ND * NW;
  localparam int WIW = (NWT > 1) ? $clog2(NWT) : 1;
  logic [7:0]      dsel_q;                // selector registers keep all 8 bits so an out-of-range value is REJECTED, never aliased
  logic [7:0]      wsel_q;
  logic [7:0]      fsel_q;
  logic [31:0]     wb_lo_q, wb_hi_q, ws_lo_q, ws_hi_q;
  logic [31:0]     pbase_sh_q, psize_sh_q;
  logic [7:0]      fdom_sh_q;
  logic [31:0]     fcap_lo_q, fcap_hi_q;
  logic [ND-1:0]   den_q;
  logic [63:0]     wb_q [0:ND*NW-1];
  logic [63:0]     ws_q [0:ND*NW-1];
  logic [2:0]      wc_q [0:ND*NW-1];
  logic [NF-1:0]   fen_q, fro_q, fquar_q;
  logic [DOMW-1:0] fdom_q [0:NF-1];
  logic [63:0]     fcap_q [0:NF-1];
  logic [NF-1:0]   fault_q, fie_q;
  logic [7:0]      lcode_q [0:NF-1];
  logic [7:0]      ldet_q  [0:NF-1];
  logic [31:0]     fcnt_q  [0:NF-1];
  logic [7:0]      psel_ctr_q;
  logic [7:0]      psel_func_q;

  logic            rsp_pend_q;
  assign mg_req_ready = !rsp_pend_q;
  assign irq_o        = |(fault_q & fie_q);
  assign dom_en_o     = den_q & part_en_i;
  assign perf_func    = psel_func_q[FW-1:0];
  assign perf_ctr     = psel_ctr_q;

  assign f_en_o   = fen_q;
  assign f_ro_o   = fro_q;
  assign f_quar_o = fquar_q;

  genvar g;
  generate
    for (g = 0; g < ND*NW; g++) begin : g_win
      assign win_base_o[g*64 +: 64] = wb_q[g];
      assign win_size_o[g*64 +: 64] = ws_q[g];
      assign win_ctl_o [g*3  +: 3]  = wc_q[g];
    end
    for (g = 0; g < NF; g++) begin : g_fn
      assign f_dom_o[g*DOMW +: DOMW] = fdom_q[g];
      assign f_cap_o[g*64 +: 64]     = fcap_q[g];
    end
  endgenerate

  // ------------------------------------------------------------------ request decode
  wire acc      = mg_req_valid && mg_req_ready;
  wire wr       = acc && mg_req_write;
  wire dsel_ok  = (32'(dsel_q) < ND);
  wire [DOMW-1:0] dsel_i = dsel_q[DOMW-1:0];      // valid index only when dsel_ok
  wire wsel_ok  = (32'(wsel_q) < NW);
  wire fsel_ok  = (32'(fsel_q) < NF);
  wire [31:0] widx = 32'(dsel_ok ? 32'(dsel_q) : 0) * 32'(NW) + 32'(wsel_ok ? 32'(wsel_q) : 0);
  wire [FW-1:0] fs = fsel_ok ? fsel_q[FW-1:0] : '0;

  // a valid window must be non-empty and aligned to the bus beat, so that every beat touching a granted byte lies wholly inside the window
  localparam int BWB = $clog2(DW / 8);
  wire [63:0] wbs = {wb_hi_q, wb_lo_q};
  wire [63:0] wss = {ws_hi_q, ws_lo_q};
  wire win_geo_ok = !mg_req_wdata[silicaflux_virtio_pkg::WC_V] ||
                    ((wss != 64'd0) && (wbs[BWB-1:0] == '0) && (wss[BWB-1:0] == '0) && ({1'b0, wbs} + {1'b0, wss} <= (65'd1 << GM_AW)));
  wire do_win  = wr && (mg_req_addr == silicaflux_virtio_pkg::M_WIN_CTL);
  wire do_dom  = wr && (mg_req_addr == silicaflux_virtio_pkg::M_DOM_CTL);
  wire do_func = wr && (mg_req_addr == silicaflux_virtio_pkg::M_FUNC_CTL);

  // domain commit -> backend
  assign pc_valid = do_dom && dsel_ok;
  assign pc_dom   = dsel_i;
  assign pc_base  = pbase_sh_q;
  assign pc_size  = psize_sh_q;
  assign pc_en    = mg_req_wdata[0];
  assign pc_scrub = mg_req_wdata[1];

  // function commit checks
  wire [63:0] fcap_sh   = {fcap_hi_q, fcap_lo_q};
  wire [95:0] cap_bytes = {32'd0, fcap_sh} << 9;               // capacity in bytes, 96 bits: no overflow for 64-bit sectors
  wire        fdom_ok   = (32'(fdom_sh_q) < ND);
  wire [DOMW-1:0] fdom_i = fdom_sh_q[DOMW-1:0];
  wire [31:0] part_sz   = part_size_i[(fdom_ok ? 32'(fdom_i) : 0)*32 +: 32];
  wire        fpart_ok  = fdom_ok && part_en_i[fdom_ok ? 32'(fdom_i) : 0] && (cap_bytes <= {64'd0, part_sz}) && (fcap_sh != 64'd0);
  wire        fbusy     = f_inuse_i[fs];
  wire        func_ok   = fsel_ok && !fbusy && (!mg_req_wdata[0] || fpart_ok);

  // ------------------------------------------------------------------ read multiplexer
  logic [31:0] rd;
  logic        rd_err;
  always_comb begin
    rd     = 32'd0;
    rd_err = 1'b0;
    case (mg_req_addr)
      silicaflux_virtio_pkg::M_ID:          rd = silicaflux_virtio_pkg::SFV_ID_MAGIC;
      silicaflux_virtio_pkg::M_ABI:         rd = {silicaflux_virtio_pkg::SFV_ABI_MAJOR, silicaflux_virtio_pkg::SFV_ABI_MINOR};
      silicaflux_virtio_pkg::M_CAPS0:       rd = {7'd0, EXT_IOMMU[0], 8'(NW), 8'(ND), 8'(NF)};
      silicaflux_virtio_pkg::M_CAPS1:       rd = {8'($clog2(STAGE)), 8'(MAX_CHAIN), 16'(MAX_QSZ)};
      silicaflux_virtio_pkg::M_STORE:       rd = 32'(STORE_BYTES);
      silicaflux_virtio_pkg::M_BUS:         rd = {16'd0, 8'(DW), 8'(GM_AW)};
      silicaflux_virtio_pkg::M_FAULT:       rd = 32'(fault_q);
      silicaflux_virtio_pkg::M_FAULT_IE:    rd = 32'(fie_q);
      silicaflux_virtio_pkg::M_DOM_SEL:     rd = {24'd0, dsel_q};
      silicaflux_virtio_pkg::M_WIN_SEL:     rd = {24'd0, wsel_q};
      silicaflux_virtio_pkg::M_WIN_BASE_LO: rd = wb_lo_q;
      silicaflux_virtio_pkg::M_WIN_BASE_HI: rd = wb_hi_q;
      silicaflux_virtio_pkg::M_WIN_SIZE_LO: rd = ws_lo_q;
      silicaflux_virtio_pkg::M_WIN_SIZE_HI: rd = ws_hi_q;
      silicaflux_virtio_pkg::M_WIN_CTL:     rd = (dsel_ok && wsel_ok) ? {29'd0, wc_q[widx[WIW-1:0]]} : 32'd0;
      silicaflux_virtio_pkg::M_DOM_CTL:     rd = dsel_ok ? {31'd0, den_q[dsel_i]} : 32'd0;
      silicaflux_virtio_pkg::M_DOM_PBASE:   rd = pbase_sh_q;
      silicaflux_virtio_pkg::M_DOM_PSIZE:   rd = psize_sh_q;
      silicaflux_virtio_pkg::M_DOM_STATUS:  rd = dsel_ok ? {30'd0, part_busy_i[dsel_i], part_en_i[dsel_i] && den_q[dsel_i]} : 32'd0;
      silicaflux_virtio_pkg::M_FUNC_SEL:    rd = {24'd0, fsel_q};
      silicaflux_virtio_pkg::M_FUNC_DOMAIN: rd = {24'd0, fdom_sh_q};
      silicaflux_virtio_pkg::M_FUNC_CAP_LO: rd = fcap_lo_q;
      silicaflux_virtio_pkg::M_FUNC_CAP_HI: rd = fcap_hi_q;
      silicaflux_virtio_pkg::M_FUNC_CTL:    rd = fsel_ok ? {29'd0, fquar_q[fs], fro_q[fs], fen_q[fs]} : 32'd0;
      silicaflux_virtio_pkg::M_FUNC_STATUS: rd = fsel_ok ? {6'd0, f_pend_i[fs], f_qready_i[fs], ldet_q[fs], lcode_q[fs], f_status_i[fs*8 +: 8]} : 32'd0;
      silicaflux_virtio_pkg::M_FUNC_FCNT:   rd = fsel_ok ? fcnt_q[fs] : 32'd0;
      silicaflux_virtio_pkg::M_FUNC_QSTATE: rd = fsel_ok ? {f_ui_i[fs*16 +: 16], f_la_i[fs*16 +: 16]} : 32'd0;
      silicaflux_virtio_pkg::M_PERF_SEL:    rd = {16'd0, psel_func_q, psel_ctr_q};
      silicaflux_virtio_pkg::M_PERF_DATA:   rd = (32'(psel_func_q) < NF) ? perf_data : 32'd0;
      default:                              rd_err = 1'b1;
    endcase
  end

  // ------------------------------------------------------------------ write handling
  logic wr_err;
  always_comb begin
    wr_err = 1'b0;
    if (wr) begin
      case (mg_req_addr)
        silicaflux_virtio_pkg::M_FAULT, silicaflux_virtio_pkg::M_FAULT_IE, silicaflux_virtio_pkg::M_DOM_SEL,
        silicaflux_virtio_pkg::M_WIN_SEL, silicaflux_virtio_pkg::M_WIN_BASE_LO, silicaflux_virtio_pkg::M_WIN_BASE_HI,
        silicaflux_virtio_pkg::M_WIN_SIZE_LO, silicaflux_virtio_pkg::M_WIN_SIZE_HI, silicaflux_virtio_pkg::M_DOM_PBASE,
        silicaflux_virtio_pkg::M_DOM_PSIZE, silicaflux_virtio_pkg::M_FUNC_SEL, silicaflux_virtio_pkg::M_FUNC_DOMAIN,
        silicaflux_virtio_pkg::M_FUNC_CAP_LO, silicaflux_virtio_pkg::M_FUNC_CAP_HI, silicaflux_virtio_pkg::M_PERF_SEL,
        silicaflux_virtio_pkg::M_PERF_CTL: wr_err = 1'b0;
        silicaflux_virtio_pkg::M_WIN_CTL:  wr_err = !(dsel_ok && wsel_ok && win_geo_ok);
        silicaflux_virtio_pkg::M_DOM_CTL:  wr_err = !(dsel_ok && pc_ok);
        silicaflux_virtio_pkg::M_FUNC_CTL: wr_err = !func_ok;
        default:                           wr_err = 1'b1;                     // read-only or unknown register
      endcase
    end
  end
  assign perf_clr = wr && (mg_req_addr == silicaflux_virtio_pkg::M_PERF_CTL) && mg_req_wdata[0];

  always_ff @(posedge clk or negedge rst_n) begin
    integer i;
    if (!rst_n) begin
      dsel_q <= 8'd0; wsel_q <= 8'd0; fsel_q <= 8'd0;
      wb_lo_q <= 32'd0; wb_hi_q <= 32'd0; ws_lo_q <= 32'd0; ws_hi_q <= 32'd0;
      pbase_sh_q <= 32'd0; psize_sh_q <= 32'd0; fdom_sh_q <= 8'd0; fcap_lo_q <= 32'd0; fcap_hi_q <= 32'd0;
      den_q <= '0; fen_q <= '0; fro_q <= '0; fquar_q <= '0; fault_q <= '0; fie_q <= '0;
      psel_ctr_q <= 8'd0; psel_func_q <= 8'd0;
      rsp_pend_q <= 1'b0; mg_rsp_valid <= 1'b0; mg_rsp_rdata <= 32'd0; mg_rsp_err <= 1'b0;
      for (i = 0; i < ND*NW; i++) begin wb_q[i] <= 64'd0; ws_q[i] <= 64'd0; wc_q[i] <= 3'd0; end
      for (i = 0; i < NF; i++) begin
        fdom_q[i] <= '0; fcap_q[i] <= 64'd0; lcode_q[i] <= 8'd0; ldet_q[i] <= 8'd0; fcnt_q[i] <= 32'd0;
      end
    end else begin
      mg_rsp_valid <= 1'b0;
      rsp_pend_q   <= 1'b0;

      // fault log (from the queue controller)
      if (flt_v && (32'(flt_f) < NF)) begin
        fault_q[flt_f] <= 1'b1;
        lcode_q[flt_f] <= flt_code;
        ldet_q[flt_f]  <= flt_detail;
        fcnt_q[flt_f]  <= fcnt_q[flt_f] + 32'd1;
      end

      if (acc) begin
        mg_rsp_valid <= 1'b1;
        rsp_pend_q   <= 1'b1;
        mg_rsp_rdata <= mg_req_write ? 32'd0 : rd;
        mg_rsp_err   <= mg_req_write ? wr_err : rd_err;
        if (mg_req_write) begin
          case (mg_req_addr)
            silicaflux_virtio_pkg::M_FAULT:       begin for (i = 0; i < NF; i++) if (mg_req_wdata[i]) fault_q[i] <= 1'b0; end
            silicaflux_virtio_pkg::M_FAULT_IE:    fie_q <= mg_req_wdata[NF-1:0];
            silicaflux_virtio_pkg::M_DOM_SEL:     dsel_q <= mg_req_wdata[7:0];
            silicaflux_virtio_pkg::M_WIN_SEL:     wsel_q <= mg_req_wdata[7:0];
            silicaflux_virtio_pkg::M_WIN_BASE_LO: wb_lo_q <= mg_req_wdata;
            silicaflux_virtio_pkg::M_WIN_BASE_HI: wb_hi_q <= mg_req_wdata;
            silicaflux_virtio_pkg::M_WIN_SIZE_LO: ws_lo_q <= mg_req_wdata;
            silicaflux_virtio_pkg::M_WIN_SIZE_HI: ws_hi_q <= mg_req_wdata;
            silicaflux_virtio_pkg::M_WIN_CTL: begin
              if (do_win && dsel_ok && wsel_ok && win_geo_ok) begin
                wb_q[widx[WIW-1:0]] <= {wb_hi_q, wb_lo_q};
                ws_q[widx[WIW-1:0]] <= {ws_hi_q, ws_lo_q};
                wc_q[widx[WIW-1:0]] <= mg_req_wdata[2:0];
              end
            end
            silicaflux_virtio_pkg::M_DOM_CTL:     if (do_dom && dsel_ok && pc_ok) den_q[dsel_i] <= mg_req_wdata[0];
            silicaflux_virtio_pkg::M_DOM_PBASE:   pbase_sh_q <= mg_req_wdata;
            silicaflux_virtio_pkg::M_DOM_PSIZE:   psize_sh_q <= mg_req_wdata;
            silicaflux_virtio_pkg::M_FUNC_SEL:    fsel_q <= mg_req_wdata[7:0];
            silicaflux_virtio_pkg::M_FUNC_DOMAIN: fdom_sh_q <= mg_req_wdata[7:0];
            silicaflux_virtio_pkg::M_FUNC_CAP_LO: fcap_lo_q <= mg_req_wdata;
            silicaflux_virtio_pkg::M_FUNC_CAP_HI: fcap_hi_q <= mg_req_wdata;
            silicaflux_virtio_pkg::M_FUNC_CTL: begin
              if (do_func && func_ok) begin
                fen_q[fs]   <= mg_req_wdata[0];
                fro_q[fs]   <= mg_req_wdata[1];
                fquar_q[fs] <= mg_req_wdata[2];
                fdom_q[fs]  <= fdom_i;
                fcap_q[fs]  <= fcap_sh;
              end
            end
            silicaflux_virtio_pkg::M_PERF_SEL: begin psel_ctr_q <= mg_req_wdata[7:0]; psel_func_q <= mg_req_wdata[15:8]; end
            default: ;
          endcase
        end
      end
    end
  end

  wire unused_mg = &{1'b0, widx[31:WIW], mg_req_wdata[31:3], wbs[63:BWB], wss[63:BWB]};
endmodule

`default_nettype wire
