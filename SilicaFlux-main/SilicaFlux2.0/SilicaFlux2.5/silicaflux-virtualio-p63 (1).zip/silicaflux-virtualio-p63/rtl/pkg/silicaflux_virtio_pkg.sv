// =============================================================================
// SilicaFlux VirtualIO (Project 63) :: silicaflux_virtio_pkg -- VirtIO protocol package
//
// SINGLE SOURCE OF TRUTH for every VirtIO constant, field position and engine error code used by the RTL,
// the testbenches and (through scripts/gen_abi.py) the host library.
//
// NORMATIVE REFERENCE: the OASIS VirtIO specification (1.x), non-legacy interface:
//   2.1  Device Status Field             2.2  Feature Bits               2.7  Split Virtqueues
//   3.1  Device Initialization           4.2  Virtio Over MMIO (Version 2)   5.2  Block Device
// !! The OASIS site (docs.oasis-open.org) was NOT reachable from the build environment (network policy), so the spec
// !! text itself was not re-read while writing this file.  Every numeric constant below was instead cross-checked
// !! against the Linux UAPI headers <linux/virtio_{config,ring,mmio,blk,ids}.h> installed on the build host
// !! (make check-abi), which mirror the specification.  Normative *behaviour* (not just numbers) is listed, clause by
// !! clause and with its verification status, in docs/CONFORMANCE.md -- re-verify those clauses against the OASIS text.
//
// Byte order: VirtIO 1.x split rings, descriptors and the block-request header are LITTLE ENDIAN.  All guest-memory
// structures in this project are handled as little-endian byte lanes (byte i of a word = bits [8i+7:8i]).
//
// Coding rules (shared with Project 61, baseline flow = Yosys 0.33): synthesizable RTL uses ONLY the localparams and
// functions of this package, fully qualified (silicaflux_virtio_pkg::NAME), on flat vectors -- no struct, no `import`,
// no `return`.
// Classification: SYNTHESIZABLE (constants / functions)
// =============================================================================
package silicaflux_virtio_pkg;

  // ---------------------------------------------------------------- identification (engine, not VirtIO)
  localparam logic [31:0] SFV_ID_MAGIC  = 32'h5346_5645;   // "SFVE" -- management-port ID register
  localparam logic [15:0] SFV_ABI_MAJOR = 16'd1;
  localparam logic [15:0] SFV_ABI_MINOR = 16'd0;

  // ---------------------------------------------------------------- virtio-mmio, Version 2 (spec 4.2.2)
  localparam logic [31:0] MMIO_MAGIC    = 32'h7472_6976;   // "virt" little endian
  localparam logic [31:0] MMIO_VERSION  = 32'd2;           // non-legacy register layout
  localparam logic [31:0] VENDOR_ID     = 32'h5346_4C58;   // "SFLX" -- PLACEHOLDER, not a registered vendor id
  localparam logic [31:0] DEVICE_ID_NONE  = 32'd0;         // "no device behind this window yet" (spec 4.2.2: DeviceID 0)
  localparam logic [31:0] DEVICE_ID_NET   = 32'd1;         // reserved for a later virtio-net front end (NOT implemented)
  localparam logic [31:0] DEVICE_ID_BLOCK = 32'd2;

  localparam int MMIO_WINDOW_SHIFT = 12;                   // one 4 KiB register window per function

  localparam logic [11:0] R_MAGIC          = 12'h000;  // R
  localparam logic [11:0] R_VERSION        = 12'h004;  // R
  localparam logic [11:0] R_DEVICE_ID      = 12'h008;  // R
  localparam logic [11:0] R_VENDOR_ID      = 12'h00c;  // R
  localparam logic [11:0] R_DEV_FEATURES   = 12'h010;  // R   (window selected by DeviceFeaturesSel)
  localparam logic [11:0] R_DEV_FEAT_SEL   = 12'h014;  // W
  localparam logic [11:0] R_DRV_FEATURES   = 12'h020;  // W   (window selected by DriverFeaturesSel)
  localparam logic [11:0] R_DRV_FEAT_SEL   = 12'h024;  // W
  localparam logic [11:0] R_QUEUE_SEL      = 12'h030;  // W
  localparam logic [11:0] R_QUEUE_NUM_MAX  = 12'h034;  // R
  localparam logic [11:0] R_QUEUE_NUM      = 12'h038;  // W
  localparam logic [11:0] R_QUEUE_READY    = 12'h044;  // RW
  localparam logic [11:0] R_QUEUE_NOTIFY   = 12'h050;  // W
  localparam logic [11:0] R_INT_STATUS     = 12'h060;  // R
  localparam logic [11:0] R_INT_ACK        = 12'h064;  // W
  localparam logic [11:0] R_STATUS         = 12'h070;  // RW
  localparam logic [11:0] R_QUEUE_DESC_LO  = 12'h080;  // W
  localparam logic [11:0] R_QUEUE_DESC_HI  = 12'h084;  // W
  localparam logic [11:0] R_QUEUE_DRV_LO   = 12'h090;  // W   (spec name: QueueDriverLow = available ring)
  localparam logic [11:0] R_QUEUE_DRV_HI   = 12'h094;  // W
  localparam logic [11:0] R_QUEUE_DEV_LO   = 12'h0a0;  // W   (spec name: QueueDeviceLow = used ring)
  localparam logic [11:0] R_QUEUE_DEV_HI   = 12'h0a4;  // W
  localparam logic [11:0] R_CONFIG_GEN     = 12'h0fc;  // R
  localparam logic [11:0] R_CONFIG         = 12'h100;  // device-specific configuration space

  localparam logic [31:0] INT_VRING  = 32'd1;          // InterruptStatus bit 0: used buffer notification
  localparam logic [31:0] INT_CONFIG = 32'd2;          // InterruptStatus bit 1: configuration change notification

  // ---------------------------------------------------------------- device status field (spec 2.1)
  localparam logic [7:0] ST_ACKNOWLEDGE  = 8'h01;
  localparam logic [7:0] ST_DRIVER       = 8'h02;
  localparam logic [7:0] ST_DRIVER_OK    = 8'h04;
  localparam logic [7:0] ST_FEATURES_OK  = 8'h08;
  localparam logic [7:0] ST_NEEDS_RESET  = 8'h40;
  localparam logic [7:0] ST_FAILED       = 8'h80;
  localparam logic [7:0] ST_DRIVER_BITS  = 8'h8F;      // bits a driver may set: ACK|DRIVER|DRIVER_OK|FEATURES_OK|FAILED
                                                       // (0x40 NEEDS_RESET is device-owned; 0x10 and 0x20 are reserved)

  // ---------------------------------------------------------------- feature bits (spec 2.2 / 6)
  localparam int F_RING_INDIRECT_DESC = 28;   // NOT offered (indirect descriptors unsupported)
  localparam int F_RING_EVENT_IDX     = 29;   // NOT offered
  localparam int F_VERSION_1          = 32;   // offered, mandatory
  localparam int F_ACCESS_PLATFORM    = 33;   // offered only when the engine is built with EXT_IOMMU = 1
  localparam int F_RING_PACKED        = 34;   // NOT offered (packed rings: later extension)
  localparam int F_IN_ORDER           = 35;   // NOT offered
  localparam int F_ORDER_PLATFORM     = 36;   // NOT offered
  localparam int F_SR_IOV             = 37;   // NOT offered
  localparam int F_NOTIFICATION_DATA  = 38;   // NOT offered
  localparam int F_RING_RESET         = 40;   // NOT offered
  // virtio-blk (spec 5.2.3)
  localparam int BLK_F_SIZE_MAX   = 1;        // NOT offered
  localparam int BLK_F_SEG_MAX    = 2;        // offered
  localparam int BLK_F_GEOMETRY   = 4;        // NOT offered
  localparam int BLK_F_RO         = 5;        // offered when the function is configured read-only
  localparam int BLK_F_BLK_SIZE   = 6;        // offered (blk_size = 512)
  localparam int BLK_F_FLUSH      = 9;        // NOT offered (no write cache: every write is complete when its used entry appears)
  localparam int BLK_F_TOPOLOGY   = 10;       // NOT offered
  localparam int BLK_F_CONFIG_WCE = 11;       // NOT offered
  localparam int BLK_F_MQ         = 12;       // NOT offered (one request virtqueue)
  localparam int BLK_F_DISCARD    = 13;       // NOT offered
  localparam int BLK_F_WRITE_ZEROES = 14;     // NOT offered

  // The complete feature vector the device offers (64 bits).  Nothing else is ever advertised.
  function automatic logic [63:0] device_features(input logic ro, input logic ext_iommu);
    logic [63:0] f;
    f = 64'd0;
    f[F_VERSION_1]       = 1'b1;
    f[BLK_F_SEG_MAX]     = 1'b1;
    f[BLK_F_BLK_SIZE]    = 1'b1;
    f[BLK_F_RO]          = ro;
    f[F_ACCESS_PLATFORM] = ext_iommu;
    device_features = f;
  endfunction

  // ---------------------------------------------------------------- split virtqueue layout (spec 2.7)
  localparam int DESC_BYTES        = 16;      // le64 addr; le32 len; le16 flags; le16 next
  localparam int DESC_ALIGN        = 16;      // descriptor table alignment
  localparam int AVAIL_ALIGN       = 2;       // available ring alignment
  localparam int USED_ALIGN        = 4;       // used ring alignment
  localparam int USED_ELEM_BYTES   = 8;       // le32 id; le32 len
  localparam logic [15:0] DESC_F_NEXT     = 16'h0001;
  localparam logic [15:0] DESC_F_WRITE    = 16'h0002;   // buffer is device-writable
  localparam logic [15:0] DESC_F_INDIRECT = 16'h0004;   // unsupported
  localparam logic [15:0] DESC_F_KNOWN    = 16'h0007;   // any other flag bit is reserved in a split ring
  localparam logic [15:0] AVAIL_F_NO_INTERRUPT = 16'h0001;
  localparam logic [15:0] USED_F_NO_NOTIFY     = 16'h0001;   // never written by this device
  // byte offsets of the fields (relative to the ring base)
  localparam int AVAIL_OFF_FLAGS = 0;
  localparam int AVAIL_OFF_IDX   = 2;
  localparam int AVAIL_OFF_RING  = 4;
  localparam int USED_OFF_FLAGS  = 0;
  localparam int USED_OFF_IDX    = 2;
  localparam int USED_OFF_RING   = 4;

  // ---------------------------------------------------------------- virtio-blk (spec 5.2)
  localparam int SECTOR_BYTES = 512;
  localparam int BLK_HDR_BYTES = 16;          // le32 type; le32 reserved/ioprio; le64 sector
  localparam logic [31:0] BLK_T_IN    = 32'd0;
  localparam logic [31:0] BLK_T_OUT   = 32'd1;
  localparam logic [31:0] BLK_T_FLUSH = 32'd4;   // answered VIRTIO_BLK_S_UNSUPP (feature not offered)
  localparam logic [31:0] BLK_T_GET_ID = 32'd8;  // answered VIRTIO_BLK_S_UNSUPP
  localparam logic [7:0]  BLK_S_OK     = 8'd0;
  localparam logic [7:0]  BLK_S_IOERR  = 8'd1;
  localparam logic [7:0]  BLK_S_UNSUPP = 8'd2;
  // device configuration space, byte offsets from R_CONFIG (spec 5.2.4)
  localparam logic [11:0] CFG_CAPACITY_LO = 12'h100;  // le64 capacity, in 512-byte sectors
  localparam logic [11:0] CFG_CAPACITY_HI = 12'h104;
  localparam logic [11:0] CFG_SIZE_MAX    = 12'h108;  // valid only with BLK_F_SIZE_MAX: not offered -> reads 0
  localparam logic [11:0] CFG_SEG_MAX     = 12'h10c;
  localparam logic [11:0] CFG_GEOMETRY    = 12'h110;  // not offered -> 0
  localparam logic [11:0] CFG_BLK_SIZE    = 12'h114;

  // ---------------------------------------------------------------- engine fault codes (FATAL: function -> NEEDS_RESET)
  // A fatal fault is a driver-side structural violation or an isolation violation on a ring / descriptor / status
  // access.  The request is NOT completed (no used entry is written): the device does not trust the ring any more.
  localparam logic [7:0] FC_NONE           = 8'h00;
  localparam logic [7:0] FC_AVAIL_OVERRUN  = 8'h01;  // avail.idx - last_avail > queue size
  localparam logic [7:0] FC_BAD_HEAD       = 8'h02;  // available-ring entry >= queue size
  localparam logic [7:0] FC_BAD_NEXT       = 8'h03;  // descriptor `next` >= queue size
  localparam logic [7:0] FC_CYCLE          = 8'h04;  // a descriptor appears twice in one chain
  localparam logic [7:0] FC_CHAIN_TOO_LONG = 8'h05;  // more descriptors than MAX_CHAIN
  localparam logic [7:0] FC_BAD_FLAGS      = 8'h06;  // reserved descriptor flag bits set
  localparam logic [7:0] FC_INDIRECT       = 8'h07;  // VIRTQ_DESC_F_INDIRECT (feature not negotiable)
  localparam logic [7:0] FC_ORDER          = 8'h08;  // device-readable descriptor after a device-writable one
  localparam logic [7:0] FC_SHORT_HDR      = 8'h09;  // fewer than 16 device-readable bytes: no virtio-blk header
  localparam logic [7:0] FC_NO_STATUS      = 8'h0A;  // no device-writable byte: nowhere to put the status
  localparam logic [7:0] FC_DMA_DENIED     = 8'h10;  // permission check refused a ring/descriptor/status access (violation)
  localparam logic [7:0] FC_GUEST_BUS      = 8'h11;  // guest memory answered a ring/descriptor/status access with an error
  localparam logic [7:0] FC_INTERNAL       = 8'h1F;
  function automatic logic fc_is_violation(input logic [7:0] c);
    fc_is_violation = (c == FC_DMA_DENIED);
  endfunction

  // ---------------------------------------------------------------- guest-DMA unit result codes (gdma c_code)
  localparam logic [7:0] GD_OK     = 8'h00;
  localparam logic [7:0] GD_DENIED = 8'h01;  // domain adapter refused the range (no byte moved)
  localparam logic [7:0] GD_GUARD  = 8'h02;  // per-beat guard refused a beat (defence in depth)
  localparam logic [7:0] GD_BUS    = 8'h03;  // guest memory returned an error response
  localparam logic [7:0] GD_BKERR  = 8'h04;  // backend returned an error response
  localparam logic [7:0] GD_ABORT  = 8'h05;  // cancelled (function reset)
  function automatic logic gd_is_violation(input logic [7:0] c);
    gd_is_violation = (c == GD_DENIED) || (c == GD_GUARD);
  endfunction

  // ---------------------------------------------------------------- domain adapter detail codes (why a range was refused)
  localparam logic [7:0] DD_OK        = 8'h00;
  localparam logic [7:0] DD_DISABLED  = 8'h01;  // domain not enabled (default deny)
  localparam logic [7:0] DD_ZERO_LEN  = 8'h02;
  localparam logic [7:0] DD_RANGE     = 8'h03;  // beyond the guest address width, or wraps
  localparam logic [7:0] DD_NO_WINDOW = 8'h04;  // no single window contains the whole range
  localparam logic [7:0] DD_PERM      = 8'h05;  // a window contains it, but without the needed permission
  localparam logic [7:0] DD_IOMMU     = 8'h06;  // the external IOMMU refused the translation

  // ---------------------------------------------------------------- window control (WIN_CTL, per window)
  localparam int WC_R = 0;
  localparam int WC_W = 1;
  localparam int WC_V = 2;

  // ---------------------------------------------------------------- management register map (byte offsets, 32-bit regs)
  localparam logic [11:0] M_ID          = 12'h000;  // RO  "SFVE"
  localparam logic [11:0] M_ABI         = 12'h004;  // RO  {major16, minor16}
  localparam logic [11:0] M_CAPS0       = 12'h008;  // RO  [7:0] NUM_FUNCS [15:8] NUM_DOMAINS [23:16] NUM_WIN [24] EXT_IOMMU
  localparam logic [11:0] M_CAPS1       = 12'h00c;  // RO  [15:0] MAX_QSZ [23:16] MAX_CHAIN [31:24] log2(STAGE_BYTES)
  localparam logic [11:0] M_STORE       = 12'h010;  // RO  backend store size in bytes
  localparam logic [11:0] M_BUS         = 12'h014;  // RO  [7:0] GM_AW [15:8] DW bits
  localparam logic [11:0] M_FAULT       = 12'h020;  // RW1C bit f = function f took a fatal fault (NEEDS_RESET)
  localparam logic [11:0] M_FAULT_IE    = 12'h024;  // RW
  localparam logic [11:0] M_DOM_SEL     = 12'h040;  // RW
  localparam logic [11:0] M_WIN_SEL     = 12'h044;  // RW
  localparam logic [11:0] M_WIN_BASE_LO = 12'h048;  // RW  (shadow)
  localparam logic [11:0] M_WIN_BASE_HI = 12'h04c;
  localparam logic [11:0] M_WIN_SIZE_LO = 12'h050;  // RW  (shadow)
  localparam logic [11:0] M_WIN_SIZE_HI = 12'h054;
  localparam logic [11:0] M_WIN_CTL     = 12'h058;  // RW  write commits {shadow base, shadow size, ctl} atomically
  localparam logic [11:0] M_DOM_CTL     = 12'h060;  // RW  [0] enable  [1] scrub partition   write commits enable + partition
  localparam logic [11:0] M_DOM_PBASE   = 12'h064;  // RW  (shadow) backend partition base (bytes)
  localparam logic [11:0] M_DOM_PSIZE   = 12'h068;  // RW  (shadow) backend partition size (bytes)
  localparam logic [11:0] M_DOM_STATUS  = 12'h06c;  // RO  [0] enabled [1] scrub busy
  localparam logic [11:0] M_FUNC_SEL    = 12'h080;  // RW
  localparam logic [11:0] M_FUNC_DOMAIN = 12'h084;  // RW  (shadow)
  localparam logic [11:0] M_FUNC_CAP_LO = 12'h088;  // RW  (shadow) capacity in sectors
  localparam logic [11:0] M_FUNC_CAP_HI = 12'h08c;
  localparam logic [11:0] M_FUNC_CTL    = 12'h090;  // RW  [0] enable [1] read-only [2] quarantine-on-violation; write commits (refused while in use)
  localparam logic [11:0] M_FUNC_STATUS = 12'h094;  // RO  [7:0] device status [15:8] last fault [23:16] last domain detail [24] queue ready [25] work pending
  localparam logic [11:0] M_FUNC_FCNT   = 12'h098;  // RO  fatal fault count
  localparam logic [11:0] M_FUNC_QSTATE = 12'h0a0;  // RO  [15:0] last_avail [31:16] used_idx
  localparam logic [11:0] M_PERF_SEL    = 12'h0c0;  // RW  [7:0] counter id [15:8] function
  localparam logic [11:0] M_PERF_DATA   = 12'h0c4;  // RO
  localparam logic [11:0] M_PERF_CTL    = 12'h0c8;  // WO  [0] clear all counters
  localparam logic [31:0] MG_ERR_BUSY   = 32'd1;

  // ---------------------------------------------------------------- performance counter ids (per function, 32 bit)
  localparam int PC_REQ_DONE      = 0;   // requests completed (used entry published)
  localparam int PC_DESC          = 1;   // descriptors walked
  localparam int PC_DMA_RD_DATA   = 2;   // request-data bytes read from guest memory
  localparam int PC_DMA_WR_DATA   = 3;   // request-data bytes written to guest memory
  localparam int PC_DMA_META      = 4;   // ring / descriptor / header / status / used bytes moved (both directions)
  localparam int PC_IRQ_RAISED    = 5;   // used-buffer notifications raised
  localparam int PC_IRQ_SUPPRESSED = 6;  // notifications skipped because avail.flags had NO_INTERRUPT
  localparam int PC_VIOLATIONS    = 7;   // permission violations (descriptor/ring/status/data)
  localparam int PC_FATAL         = 8;   // fatal faults (NEEDS_RESET)
  localparam int PC_REQ_ERR       = 9;   // requests completed with a non-OK virtio-blk status
  localparam int PC_KICKS         = 10;  // QueueNotify writes
  localparam int PC_QSTALL        = 11;  // cycles with work pending while the engine served another function
  localparam int PC_BUS_STALL     = 12;  // cycles this function's request waited for guest/backend req_ready
  localparam int PC_UTIL_SUM      = 13;  // sum of queue occupancy (avail.idx - last_avail) sampled at every ring poll
  localparam int PC_UTIL_SAMPLES  = 14;
  localparam int PC_UTIL_MAX      = 15;  // high-water mark of queue occupancy
  localparam int PC_LAT_SUM       = 16;  // completion latency: cycles from head fetch to used.idx write complete
  localparam int PC_LAT_MAX       = 17;
  localparam int PC_LAT_MIN       = 18;  // 0xFFFFFFFF until the first completion
  localparam int PC_WALK_SUM      = 19;  // descriptor-walk latency: cycles from walk start to chain accepted
  localparam int PC_WALK_MAX      = 20;
  localparam int PC_WALK_COUNT    = 21;
  localparam int PC_BUSY          = 22;  // cycles this function owned the engine
  localparam int PC_N             = 23;

  // ---------------------------------------------------------------- hardware limits used by the generic parts
  localparam int MAX_FUNCS   = 8;
  localparam int MAX_DOMAINS = 8;
  localparam int PAGE_BYTES  = 4096;       // a DMA chunk never crosses a 4 KiB boundary (IOMMU granule)

endpackage
