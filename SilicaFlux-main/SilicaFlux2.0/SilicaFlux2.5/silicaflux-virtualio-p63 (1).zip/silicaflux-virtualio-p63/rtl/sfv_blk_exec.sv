// =============================================================================
// VirtualIO :: sfv_blk_exec -- virtio-blk request EXECUTOR (spec 5.2.6) over the validated descriptor chain
//
// The chain is two byte streams: RS = the device-readable segments concatenated, WS = the device-writable segments.
// Descriptor framing is NOT assumed (spec 2.7.4: a header may be split over descriptors, header and data may share one):
//   header  = the first 16 bytes of RS  {le32 type, le32 reserved, le64 sector}
//   status  = the LAST byte of WS
//   T_IN    RS must be exactly the header; the data is WS minus its last byte (device-writable);
//   T_OUT   WS must be exactly the status byte; the data is RS after the header (device-readable);
//   any other type: answered VIRTIO_BLK_S_UNSUPP, nothing moved.
// A segment is only ever WRITTEN if it is device-writable (the data of T_IN and the status byte): a device-readable
// buffer is never written.
//
// Request-level errors are answered through the status byte (the device can still complete the request):
//   VIRTIO_BLK_S_IOERR   data length 0 or not a multiple of 512, wrong framing for the type, write on a read-only
//                        function, sector range beyond capacity (64-bit exact), a refused or failed data/header access
//   VIRTIO_BLK_S_UNSUPP  request type not implemented
// Structural errors (no header bytes / no status byte) and a failed status write are FATAL: nothing can be reported.
//
// used.len = number of bytes actually written to device-writable buffers: data written + the status byte.
// ORDER: every data chunk is complete (guest read -> backend write acknowledged for T_OUT; backend read -> guest write
// acknowledged for T_IN) before the status byte is written, and the used entry is written only after the status (queue
// controller).  Data is moved in chunks of at most one stage buffer, never across a 4 KiB boundary of the guest address.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfv_blk_exec #(
  parameter int MAX_CHAIN = 8,
  parameter int STAGE     = 64
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              kill,
  input  wire logic              go,
  input  wire logic [63:0]       cap_sectors,
  input  wire logic              ro,
  // chain from the walker
  input  wire logic [7:0]        nseg,
  input  wire logic [7:0]        nrd,
  input  wire logic [MAX_CHAIN*64-1:0] seg_addr,
  input  wire logic [MAX_CHAIN*32-1:0] seg_len,
  input  wire logic [39:0]       tot_rd,
  input  wire logic [39:0]       tot_wr,
  // guest-DMA / backend command
  output logic                   g_valid,
  output logic                   g_tgt,
  output logic                   g_wr,
  output logic                   g_data,
  output logic [63:0]            g_addr,
  output logic [15:0]            g_len,
  output logic [$clog2(STAGE)-1:0] g_soff,
  input  wire logic              g_ready,
  input  wire logic              g_done,
  input  wire logic              g_err,
  input  wire logic [7:0]        g_code,
  output logic                   ld_en,
  output logic [127:0]           ld_data,
  output logic [15:0]            ld_mask,
  input  wire logic [127:0]      pk_data,
  // result
  output logic                   done,
  output logic                   fatal,
  output logic [7:0]             fatal_code,
  output logic [31:0]            used_len,
  output logic                   viol,
  output logic [7:0]             status
);
  localparam int SAW = $clog2(STAGE);
  localparam int CW  = $clog2(MAX_CHAIN);
  localparam logic [3:0] X_IDLE = 4'd0, X_PRE = 4'd1, X_HDR_CMD = 4'd2, X_HDR_WAIT = 4'd3, X_DECODE = 4'd4,
                         X_PREP = 4'd5, X_A = 4'd6, X_A_WAIT = 4'd7, X_B = 4'd8, X_B_WAIT = 4'd9, X_ADV = 4'd10,
                         X_ST_LD = 4'd11, X_ST_CMD = 4'd12, X_ST_WAIT = 4'd13, X_FIN = 4'd14;

  logic [3:0]    st_q;
  logic [7:0]    cur_q;                // current segment
  logic [31:0]   off_q;                // offset inside it
  logic [4:0]    hgot_q;               // header bytes fetched
  logic [15:0]   n_q;                  // chunk length
  logic          is_in_q;
  logic [39:0]   dtot_q, p_q, wrb_q;
  logic [30:0]   sector_q;                // capacity <= 4 GiB, so a valid sector fits 31 bits
  logic [7:0]    status_q;
  logic          viol_q, fatal_q;
  logic [7:0]    fcode_q;
  logic [63:0]   st_addr_q;

  // ------------------------------------------------------------------ segment access
  wire  [CW-1:0] last_i = CW'(nseg - 8'd1);        // index of the last stored segment
  logic [63:0] cur_addr;
  logic [31:0] cur_len;
  logic [63:0] lst_addr;
  logic [31:0] lst_len;
  always_comb begin
    cur_addr = seg_addr[32'(cur_q[CW-1:0])*64 +: 64];
    cur_len  = seg_len [32'(cur_q[CW-1:0])*32 +: 32];
    lst_addr = seg_addr[32'(last_i)*64 +: 64];
    lst_len  = seg_len [32'(last_i)*32 +: 32];
  end
  wire [63:0] cur_ea  = cur_addr + {32'd0, off_q};         // guest address of the cursor
  wire [31:0] seg_rem = cur_len - off_q;

  // chunk length for the data phase: min(stage, bytes left in segment, bytes left in request, bytes to the 4 KiB boundary)
  logic [39:0] rem_d;
  logic [15:0] n_c;
  always_comb begin
    rem_d = dtot_q - p_q;
    n_c   = 16'(STAGE);
    if ({8'd0, seg_rem} < {24'd0, n_c}) n_c = seg_rem[15:0];
    if (rem_d < {24'd0, n_c})           n_c = rem_d[15:0];
    if ((16'd4096 - {4'd0, cur_ea[11:0]}) < n_c) n_c = 16'd4096 - {4'd0, cur_ea[11:0]};
  end
  // header chunk: min(16 - got, bytes left in segment)
  wire [4:0]  h_left = 5'd16 - hgot_q;
  wire [15:0] h_n    = (seg_rem < {27'd0, h_left}) ? seg_rem[15:0] : {11'd0, h_left};

  // ------------------------------------------------------------------ request decode (from the header in stage[0..15])
  wire [31:0] h_type   = pk_data[31:0];
  wire [63:0] h_sector = pk_data[127:64];
  wire        t_in     = (h_type == silicaflux_virtio_pkg::BLK_T_IN);
  wire        t_out    = (h_type == silicaflux_virtio_pkg::BLK_T_OUT);
  wire [39:0] d_len_c  = t_in ? (tot_wr - 40'd1) : (tot_rd - 40'd16);
  wire        layout_c = t_in ? (tot_rd == 40'd16) : (tot_wr == 40'd1);
  wire        len_bad  = (d_len_c[8:0] != 9'd0) || (d_len_c == 40'd0);
  wire [63:0] nsect    = {33'd0, d_len_c[39:9]};
  wire        rng_bad  = (h_sector > cap_sectors) || (nsect > (cap_sectors - h_sector));

  // ------------------------------------------------------------------ command outputs
  always_comb begin
    g_valid = 1'b0;
    g_tgt   = 1'b0;
    g_wr    = 1'b0;
    g_data  = 1'b0;
    g_addr  = 64'd0;
    g_len   = 16'd0;
    g_soff  = '0;
    ld_en   = 1'b0;
    ld_data = 128'd0;
    ld_mask = 16'd0;
    case (st_q)
      X_HDR_CMD: begin                                  // guest read of header bytes into stage[hgot ..]
        g_valid = 1'b1; g_addr = cur_ea; g_len = h_n; g_soff = SAW'(hgot_q);
      end
      X_A: begin
        g_valid = 1'b1; g_data = 1'b1; g_len = n_q; g_soff = '0;
        if (is_in_q) begin g_tgt = 1'b1; g_wr = 1'b0; g_addr = {24'd0, sector_q, 9'd0} + {24'd0, p_q}; end   // backend read
        else         begin g_tgt = 1'b0; g_wr = 1'b0; g_addr = cur_ea; end                                  // guest read
      end
      X_B: begin
        g_valid = 1'b1; g_data = 1'b1; g_len = n_q; g_soff = '0;
        if (is_in_q) begin g_tgt = 1'b0; g_wr = 1'b1; g_addr = cur_ea; end                                  // guest write
        else         begin g_tgt = 1'b1; g_wr = 1'b1; g_addr = {24'd0, sector_q, 9'd0} + {24'd0, p_q}; end  // backend write
      end
      X_ST_LD: begin
        ld_en = 1'b1; ld_data = {120'd0, status_q}; ld_mask = 16'h0001;
      end
      X_ST_CMD: begin
        g_valid = 1'b1; g_wr = 1'b1; g_addr = st_addr_q; g_len = 16'd1; g_soff = '0;
      end
      default: ;
    endcase
  end

  wire unused_ex = &{1'b0, nseg[7:CW], pk_data[63:32]};
  assign done       = (st_q == X_FIN);
  assign fatal      = fatal_q;
  assign fatal_code = fcode_q;
  assign used_len   = wrb_q[31:0] + 32'd1;
  assign viol       = viol_q;
  assign status     = status_q;

  // ------------------------------------------------------------------ sequencing
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q      <= X_IDLE;
      cur_q     <= 8'd0;
      off_q     <= 32'd0;
      hgot_q    <= 5'd0;
      n_q       <= 16'd0;
      is_in_q   <= 1'b0;
      dtot_q    <= 40'd0;
      p_q       <= 40'd0;
      wrb_q     <= 40'd0;
      sector_q  <= 31'd0;
      status_q  <= silicaflux_virtio_pkg::BLK_S_OK;
      viol_q    <= 1'b0;
      fatal_q   <= 1'b0;
      fcode_q   <= silicaflux_virtio_pkg::FC_NONE;
      st_addr_q <= 64'd0;
    end else if (kill) begin
      st_q <= X_IDLE;
    end else begin
      case (st_q)
        X_IDLE: begin
          if (go) begin
            viol_q   <= 1'b0;
            fatal_q  <= 1'b0;
            fcode_q  <= silicaflux_virtio_pkg::FC_NONE;
            status_q <= silicaflux_virtio_pkg::BLK_S_OK;
            wrb_q    <= 40'd0;
            p_q      <= 40'd0;
            cur_q    <= 8'd0;
            off_q    <= 32'd0;
            hgot_q   <= 5'd0;
            st_q     <= X_PRE;
          end
        end
        X_PRE: begin
          if (tot_wr == 40'd0) begin
            fatal_q <= 1'b1; fcode_q <= silicaflux_virtio_pkg::FC_NO_STATUS; st_q <= X_FIN;
          end else if (tot_rd < 40'd16) begin
            fatal_q <= 1'b1; fcode_q <= silicaflux_virtio_pkg::FC_SHORT_HDR; st_q <= X_FIN;
          end else begin
            st_addr_q <= lst_addr + {32'd0, lst_len} - 64'd1;     // last byte of the writable stream
            st_q      <= X_HDR_CMD;
          end
        end
        X_HDR_CMD: begin
          if (g_ready) st_q <= X_HDR_WAIT;
        end
        X_HDR_WAIT: begin
          if (g_done) begin
            if (g_err) begin
              status_q <= silicaflux_virtio_pkg::BLK_S_IOERR;
              viol_q   <= viol_q | silicaflux_virtio_pkg::gd_is_violation(g_code);
              st_q     <= X_ST_LD;
            end else begin
              hgot_q <= hgot_q + h_n[4:0];
              if ((off_q + {16'd0, h_n}) >= cur_len) begin cur_q <= cur_q + 8'd1; off_q <= 32'd0; end
              else off_q <= off_q + {16'd0, h_n};
              st_q   <= ((hgot_q + h_n[4:0]) == 5'd16) ? X_DECODE : X_HDR_CMD;
            end
          end
        end
        X_DECODE: begin
          sector_q <= h_sector[30:0];
          is_in_q  <= t_in;
          if (!t_in && !t_out) begin
            status_q <= silicaflux_virtio_pkg::BLK_S_UNSUPP;
            st_q     <= X_ST_LD;
          end else if (!layout_c || len_bad || (t_out && ro) || rng_bad) begin
            status_q <= silicaflux_virtio_pkg::BLK_S_IOERR;
            st_q     <= X_ST_LD;
          end else begin
            dtot_q <= d_len_c;
            p_q    <= 40'd0;
            if (t_in) begin cur_q <= nrd; off_q <= 32'd0; end   // data of T_IN = the writable stream
            st_q   <= X_PREP;
          end
        end
        X_PREP: begin
          n_q  <= n_c;
          st_q <= X_A;
        end
        X_A:      if (g_ready) st_q <= X_A_WAIT;
        X_A_WAIT: begin
          if (g_done) begin
            if (g_err) begin
              status_q <= silicaflux_virtio_pkg::BLK_S_IOERR;
              viol_q   <= viol_q | silicaflux_virtio_pkg::gd_is_violation(g_code);
              st_q     <= X_ST_LD;
            end else st_q <= X_B;
          end
        end
        X_B:      if (g_ready) st_q <= X_B_WAIT;
        X_B_WAIT: begin
          if (g_done) begin
            if (g_err) begin
              status_q <= silicaflux_virtio_pkg::BLK_S_IOERR;
              viol_q   <= viol_q | silicaflux_virtio_pkg::gd_is_violation(g_code);
              st_q     <= X_ST_LD;
            end else begin
              if (is_in_q) wrb_q <= wrb_q + {24'd0, n_q};          // bytes delivered into device-writable buffers
              st_q <= X_ADV;
            end
          end
        end
        X_ADV: begin
          p_q <= p_q + {24'd0, n_q};
          if ((off_q + {16'd0, n_q}) >= cur_len) begin cur_q <= cur_q + 8'd1; off_q <= 32'd0; end
          else off_q <= off_q + {16'd0, n_q};
          st_q <= ((p_q + {24'd0, n_q}) >= dtot_q) ? X_ST_LD : X_PREP;
        end
        X_ST_LD:  st_q <= X_ST_CMD;
        X_ST_CMD: if (g_ready) st_q <= X_ST_WAIT;
        X_ST_WAIT: begin
          if (g_done) begin
            if (g_err) begin
              fatal_q <= 1'b1;
              fcode_q <= silicaflux_virtio_pkg::gd_is_violation(g_code) ? silicaflux_virtio_pkg::FC_DMA_DENIED
                                                                        : silicaflux_virtio_pkg::FC_GUEST_BUS;
              viol_q  <= viol_q | silicaflux_virtio_pkg::gd_is_violation(g_code);
            end
            st_q <= X_FIN;
          end
        end
        X_FIN: st_q <= X_IDLE;
        default: st_q <= X_IDLE;
      endcase
    end
  end
endmodule

`default_nettype wire
