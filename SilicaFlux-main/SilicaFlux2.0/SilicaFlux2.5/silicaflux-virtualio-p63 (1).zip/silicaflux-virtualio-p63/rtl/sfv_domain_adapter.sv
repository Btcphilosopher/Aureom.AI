// =============================================================================
// VirtualIO :: sfv_domain_adapter -- DOMAIN PERMISSION ADAPTER (all guest-memory DMA is validated here)
//
// Every guest-memory access the engine makes is checked twice:
//   1. CHUNK CHECK  (chk_*): before a transfer of up to one stage buffer is started, the whole range
//      [chk_addr, chk_addr+chk_len) is checked for the needed permission (R for a read, W for a write).  If the range is
//      refused, no byte of it is moved.  Result one cycle later (table model) or when the IOMMU answers (EXT_IOMMU = 1).
//   2. BEAT GUARD   (g_*):  every individual bus beat must lie inside the range granted in step 1 (same domain, same
//      direction) -- and, in table mode, ALSO inside a window of the LIVE table.  So a window that the hypervisor
//      revokes while a transfer runs stops the transfer at the next beat, and a bug in the engine's sequencing cannot
//      move a byte outside what was granted.
//
// A DOMAIN ID NEVER REPLACES A PERMISSION CHECK: the domain only selects WHICH table is consulted.  Default deny: a
// domain that is not enabled, or has no valid window, grants nothing.  The domain of an access is chosen by the
// engine from the management-programmed function->domain binding; no guest-writable register can alter it.
//
// MODES
//   EXT_IOMMU = 0  verified permission-table model: NUM_DOM domains x NUM_WIN windows {base, size, R, W, valid} in IOVA
//                  space, identity translation (pa = addr).  A range must lie inside ONE window.
//   EXT_IOMMU = 1  the table is not used for the grant: the chunk is forwarded to an external IOMMU
//                  (iommu_req_* / iommu_rsp_*), which checks permission and returns the translated address.  The
//                  engine never asks about a range that crosses a 4 KiB boundary, so one answer covers one page and the
//                  translated range is contiguous.  The beat guard enforces the granted PA range.  Domain-enable,
//                  zero-length and address-range checks stay in this module in both modes.
//   iommu protocol: iommu_req_valid is held until iommu_req_ready; exactly one iommu_rsp_valid pulse follows, at least
//   one cycle after the request was accepted; iommu_rsp_ok = 0 refuses.  One request outstanding.
//
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfv_domain_adapter #(
  parameter int ND        = 2,
  parameter int NW        = 4,
  parameter int AW        = 48,
  parameter int DOMW      = 1,
  parameter int EXT_IOMMU = 0
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // live tables (management plane)
  input  wire logic [ND-1:0]          dom_en,
  input  wire logic [ND*NW*64-1:0]    win_base,
  input  wire logic [ND*NW*64-1:0]    win_size,
  input  wire logic [ND*NW*3-1:0]     win_ctl,
  // chunk check
  input  wire logic                   chk_valid,        // one-cycle pulse
  input  wire logic [DOMW-1:0]        chk_dom,
  input  wire logic [63:0]            chk_addr,
  input  wire logic [31:0]            chk_len,
  input  wire logic                   chk_write,
  output logic                        chk_done,         // one-cycle pulse, results valid in that cycle
  output logic                        chk_ok,
  output logic [AW-1:0]               chk_pa,
  output logic [7:0]                  chk_detail,
  // beat guard
  input  wire logic [DOMW-1:0]        g_dom,
  input  wire logic [AW-1:0]          g_lo,
  input  wire logic [15:0]            g_len,
  input  wire logic                   g_write,
  output logic                        g_ok,
  input  wire logic                   grant_clear,
  // external IOMMU (used only when EXT_IOMMU = 1)
  output logic                        iommu_req_valid,
  input  wire logic                   iommu_req_ready,
  output logic [DOMW-1:0]             iommu_req_dom,
  output logic [63:0]                 iommu_req_iova,
  output logic [31:0]                 iommu_req_len,
  output logic                        iommu_req_write,
  input  wire logic                   iommu_rsp_valid,
  input  wire logic                   iommu_rsp_ok,
  input  wire logic [AW-1:0]          iommu_rsp_pa
);
  localparam logic [1:0] A_IDLE = 2'd0, A_EVAL = 2'd1, A_REQ = 2'd2, A_WAIT = 2'd3;

  logic [1:0]       st_q;
  logic [DOMW-1:0]  q_dom;
  logic [63:0]      q_addr;
  logic [31:0]      q_len;
  logic             q_write;

  // grant register: what the chunk check allowed
  logic             gr_v;
  logic [DOMW-1:0]  gr_dom;
  logic [AW-1:0]    gr_lo;
  logic [AW:0]      gr_hi;
  logic             gr_wr;

  // ------------------------------------------------------------------ window selection by domain
  function automatic int dsel(input logic [DOMW-1:0] d);
    dsel = (32'(d) < ND) ? 32'(d) : 0;
  endfunction

  logic [NW*64-1:0] q_wbase, q_wsize, g_wbase, g_wsize;
  logic [NW*3-1:0]  q_wctl, g_wctl;
  logic             q_den, q_dvalid, g_den, g_dvalid;
  always_comb begin
    q_dvalid = (32'(q_dom) < ND);
    g_dvalid = (32'(g_dom) < ND);
    q_wbase  = win_base[dsel(q_dom)*NW*64 +: NW*64];
    q_wsize  = win_size[dsel(q_dom)*NW*64 +: NW*64];
    q_wctl   = win_ctl [dsel(q_dom)*NW*3  +: NW*3];
    q_den    = q_dvalid && dom_en[dsel(q_dom)];
    g_wbase  = win_base[dsel(g_dom)*NW*64 +: NW*64];
    g_wsize  = win_size[dsel(g_dom)*NW*64 +: NW*64];
    g_wctl   = win_ctl [dsel(g_dom)*NW*3  +: NW*3];
    g_den    = g_dvalid && dom_en[dsel(g_dom)];
  end

  // ------------------------------------------------------------------ chunk check on the latched request
  logic q_contained, q_tok;
  sfv_win_check #(.NW(NW)) u_qchk (
    .base(q_wbase), .size(q_wsize), .ctl(q_wctl), .addr(q_addr), .len(q_len),
    .need_r(!q_write), .need_w(q_write), .contained(q_contained), .ok(q_tok));

  wire [64:0] q_end     = {1'b0, q_addr} + {33'd0, q_len};
  wire        q_range   = (q_end <= (65'd1 << AW));
  wire        pre_fail  = !q_den || (q_len == 32'd0) || !q_range;
  wire [7:0]  pre_code  = !q_den ? silicaflux_virtio_pkg::DD_DISABLED :
                          (q_len == 32'd0) ? silicaflux_virtio_pkg::DD_ZERO_LEN :
                                             silicaflux_virtio_pkg::DD_RANGE;
  wire [7:0]  tab_code  = pre_fail ? pre_code :
                          !q_contained ? silicaflux_virtio_pkg::DD_NO_WINDOW :
                          !q_tok ? silicaflux_virtio_pkg::DD_PERM : silicaflux_virtio_pkg::DD_OK;

  generate
    if (EXT_IOMMU == 0) begin : g_tab
      assign chk_done   = (st_q == A_EVAL);
      assign chk_ok     = (tab_code == silicaflux_virtio_pkg::DD_OK);
      assign chk_detail = tab_code;
      assign chk_pa     = q_addr[AW-1:0];
      assign iommu_req_valid = 1'b0;
      assign iommu_req_dom   = '0;
      assign iommu_req_iova  = 64'd0;
      assign iommu_req_len   = 32'd0;
      assign iommu_req_write = 1'b0;
    end else begin : g_ext
      assign chk_done   = ((st_q == A_EVAL) && pre_fail) || ((st_q == A_WAIT) && iommu_rsp_valid);
      assign chk_ok     = (st_q == A_WAIT) && iommu_rsp_valid && iommu_rsp_ok;
      assign chk_detail = (st_q == A_EVAL) ? pre_code :
                          (iommu_rsp_ok ? silicaflux_virtio_pkg::DD_OK : silicaflux_virtio_pkg::DD_IOMMU);
      assign chk_pa     = iommu_rsp_pa;
      assign iommu_req_valid = (st_q == A_REQ);
      assign iommu_req_dom   = q_dom;
      assign iommu_req_iova  = q_addr;
      assign iommu_req_len   = q_len;
      assign iommu_req_write = q_write;
    end
  endgenerate

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q    <= A_IDLE;
      q_dom   <= '0;
      q_addr  <= 64'd0;
      q_len   <= 32'd0;
      q_write <= 1'b0;
      gr_v    <= 1'b0;
      gr_dom  <= '0;
      gr_lo   <= '0;
      gr_hi   <= '0;
      gr_wr   <= 1'b0;
    end else begin
      if (grant_clear) gr_v <= 1'b0;
      case (st_q)
        A_IDLE: begin
          if (chk_valid) begin
            q_dom   <= chk_dom;
            q_addr  <= chk_addr;
            q_len   <= chk_len;
            q_write <= chk_write;
            gr_v    <= 1'b0;
            st_q    <= A_EVAL;
          end
        end
        A_EVAL: begin
          if (EXT_IOMMU == 0) begin
            if (tab_code == silicaflux_virtio_pkg::DD_OK) begin
              gr_v   <= 1'b1;
              gr_dom <= q_dom;
              gr_lo  <= q_addr[AW-1:0];
              gr_hi  <= {1'b0, q_addr[AW-1:0]} + (AW+1)'(q_len);
              gr_wr  <= q_write;
            end
            st_q <= A_IDLE;
          end else begin
            st_q <= pre_fail ? A_IDLE : A_REQ;
          end
        end
        A_REQ: begin
          if (iommu_req_ready) st_q <= A_WAIT;
        end
        A_WAIT: begin
          if (iommu_rsp_valid) begin
            if (iommu_rsp_ok) begin
              gr_v   <= 1'b1;
              gr_dom <= q_dom;
              gr_lo  <= iommu_rsp_pa;
              gr_hi  <= {1'b0, iommu_rsp_pa} + (AW+1)'(q_len);
              gr_wr  <= q_write;
            end
            st_q <= A_IDLE;
          end
        end
        default: st_q <= A_IDLE;
      endcase
    end
  end

  // ------------------------------------------------------------------ per-beat guard
  logic g_contained, g_tok;
  sfv_win_check #(.NW(NW)) u_gchk (
    .base(g_wbase), .size(g_wsize), .ctl(g_wctl), .addr({{(64-AW){1'b0}}, g_lo}), .len({16'd0, g_len}),
    .need_r(!g_write), .need_w(g_write), .contained(g_contained), .ok(g_tok));

  wire [AW:0] g_end    = {1'b0, g_lo} + (AW+1)'(g_len);
  wire        in_grant = gr_v && (gr_dom == g_dom) && (gr_wr == g_write) && (g_len != 16'd0) &&
                         (g_lo >= gr_lo) && (g_end <= gr_hi);
  generate
    if (EXT_IOMMU == 0) begin : g_gtab
      assign g_ok = in_grant && g_den && g_tok;
    end else begin : g_gext
      assign g_ok = in_grant && g_den;
    end
  endgenerate

  // unused in EXT mode / table mode respectively (keeps -Wall quiet)
  wire unused_ok = &{1'b0, g_contained, g_tok, EXT_IOMMU[0]};
endmodule

`default_nettype wire
