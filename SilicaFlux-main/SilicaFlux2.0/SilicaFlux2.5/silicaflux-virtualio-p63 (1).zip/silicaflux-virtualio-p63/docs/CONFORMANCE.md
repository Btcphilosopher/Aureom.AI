# 02 — VirtIO conformance checklist

> **Read this first — what "normative reference" means here.** The brief names the OASIS VirtIO specification as the normative
> reference. In this build environment `docs.oasis-open.org` was **denied by the network policy** (HTTP 403 on CONNECT, recorded by the
> proxy), so the specification text itself **was not re-read** while implementing. What was done instead, and what that does and does
> not prove:
>
> * every **numeric constant** (register offsets, status bits, feature-bit numbers, descriptor/used-element layouts, descriptor and
>   available/used flags, virtio-blk feature bits, request types, status values, config-space field offsets, device IDs) was
>   **cross-checked mechanically** against the Linux UAPI headers `<linux/virtio_{config,ring,mmio,blk,ids}.h>` installed on the
>   build host, which mirror the specification: `make check-abi` compiles 77 `_Static_assert`s (all pass). That is an independent
>   source for the *numbers*;
> * the **behaviour** below (which side may do what, what the device must do on a driver error, …) is written from the author's knowledge
>   of VirtIO 1.1/1.2 and is **not independently confirmed**. Sub-clause numbers are deliberately **not quoted** (they could not be
>   verified); top-level section numbers (2.1, 2.2, 2.4, 2.7, 3.1, 4.2, 5.2) are given.
>
> **Therefore this is a self-assessment, not a certificate.** Every row marked **RECHECK** must be compared with the OASIS text by
> someone who can reach it before any "VirtIO compliant" claim is made. No claim of compliance is made here; the project claims only
> that it *implements a documented subset of VirtIO 1.x with the official register layout and ring formats, and does not invent a
> competing protocol.* No conformance suite (e.g. the Linux `virtio_blk` driver against this device) was run: **no real VirtIO driver
> has been exercised against it** — only the project's own driver library and testbench driver.

Legend — **V** implemented and verified in simulation (test named) · **R** implemented with a documented restriction · **N** not offered /
not implemented (and rejected or never advertised) · **RECHECK** behaviour not confirmed against the OASIS text.

## A. Transport: virtio-mmio, version 2 (spec 4.2)

| # | requirement | implementation | evidence | status |
|---|---|---|---|---|
| A1 | `MagicValue` = 0x74726976 ("virt"), `Version` = 2 (non-legacy) | `sfv_func_regs` | `t_basic`, `t_disabled_fn`; UAPI check | **V** |
| A2 | `DeviceID` 2 = block; 0 means "no device here yet" | DeviceID 0 until management enables the function | `t_disabled_fn` | **V** / RECHECK (DeviceID 0 usage) |
| A3 | `VendorID` | `0x53464C58` ("SFLX") — **placeholder, not a registered vendor** | `t_basic` | **R** |
| A4 | `DeviceFeatures`/`DeviceFeaturesSel`, `DriverFeatures`/`DriverFeaturesSel` (two 32-bit windows; window ≥ 2 reads 0) | as stated | `t_features` | **V** |
| A5 | `QueueSel`, `QueueNumMax` (0 = queue not available), `QueueNum`, `QueueReady`, address register pairs (Desc / Driver / Device) | queue 0 only; queue ≥ 1 reads NumMax 0 | `t_features` | **V** |
| A6 | queue setup order: select, check not ready, read max, write size, write addresses, `QueueReady` | `QueueReady`=1 refused for bad geometry (size 0 / not power of two / > max, alignment 16/2/4, area beyond the address space) | `t_features` (11 negative cases), host lib follows the order | **V** (the refusal rule is a device choice) / RECHECK |
| A7 | config writes while the queue is ready must not happen; device ignores them | ignored | `t_features` | **V** |
| A8 | `QueueNotify` write = doorbell for the queue number written | queue 0 only; other values ignored | `t_basic`, `t_doorbell` | **V** |
| A9 | `InterruptStatus` (bit 0 used-buffer, bit 1 configuration change) / `InterruptACK` | as stated; line = OR of the InterruptStatus bits | `t_irq`, `t_malformed` | **V** |
| A10 | `Status` register; write 0 = reset | see C | `t_reset` | **V** |
| A11 | `ConfigGeneration` and the generation-checked config read | register present, always 0 (the configuration cannot change while a function is in use: management reconfigures only at status 0) | `t_features`; host library implements the retry protocol | **R** / RECHECK |
| A12 | configuration-space access widths (1/2/4 bytes) | **32-bit accesses only** at the port; a bus bridge must widen sub-word config reads | — | **R** (documented) |
| A13 | shared-memory regions (`SHMSel`…), `QueueReset` | not implemented (read 0) | — | **N** |
| A14 | legacy interface (Version 1) | **not provided**; `VERSION_1` is mandatory | `t_features` (legacy accept refused) | **N** |

## B. Device status, features, initialisation (spec 2.1, 2.2, 2.4, 3.1)

| # | requirement | implementation | evidence | status |
|---|---|---|---|---|
| B1 | status bits ACKNOWLEDGE 1, DRIVER 2, DRIVER_OK 4, FEATURES_OK 8, DEVICE_NEEDS_RESET 0x40, FAILED 0x80 | as UAPI | UAPI check | **V** |
| B2 | the driver only sets bits; a device must not let status bits be cleared except by reset | monotonic status | `t_reset` | **V** / RECHECK |
| B3 | FEATURES_OK: device must not accept a feature set it does not support; driver re-reads status to see whether the device kept the bit | granted only if accepted ⊆ offered and VERSION_1 ∈ accepted | `t_features` (7 negative cases) | **V** |
| B4 | features cannot change after FEATURES_OK | frozen | `t_features` | **V** |
| B5 | the device must not consume buffers or notify before DRIVER_OK | `running` requires DRIVER_OK | `t_doorbell`, `t_reset` | **V** |
| B6 | DRIVER_OK only after FEATURES_OK | enforced | `t_reset` | **V** |
| B7 | **only genuinely supported features are offered** | exactly VERSION_1, SEG_MAX, BLK_SIZE, RO (when configured), ACCESS_PLATFORM (IOMMU build) | `t_features` checks that no other of the 64 bits is offered | **V** |
| B8 | VIRTIO_F_RING_PACKED, INDIRECT_DESC, EVENT_IDX, IN_ORDER, ORDER_PLATFORM, SR_IOV, NOTIFICATION_DATA, RING_RESET | **not offered**, accepting them makes FEATURES_OK refuse | `t_features` | **N** |
| B9 | reset: device resets all state; the driver treats the reset as complete when it reads 0 | status keeps its old value until the engine has stopped and acknowledged | `t_reset` (no guest access after Status reads 0) | **V** / RECHECK |
| B10 | on an unrecoverable device error: set DEVICE_NEEDS_RESET and, if DRIVER_OK is set, send a configuration-change notification | NEEDS_RESET + `INT_CONFIG` on every fatal fault | `t_malformed`, `t_full_empty` | **V** / RECHECK |
| B11 | initialisation sequence (reset, ACK, DRIVER, features, FEATURES_OK, re-read, queues, DRIVER_OK) | implemented by `sfv_dev_init` / `sfv_queue_create` / `sfv_dev_start` and the testbench BFM | demo, `t_basic` | **V** |

## C. Split virtqueue (spec 2.7)

| # | requirement | implementation | evidence | status |
|---|---|---|---|---|
| C1 | descriptor = `le64 addr; le32 len; le16 flags; le16 next`, table aligned to 16, size 16·N | as stated | UAPI check, every test | **V** |
| C2 | flags NEXT 1, WRITE 2, INDIRECT 4; other bits are not defined for a split ring | NEXT and WRITE only; other bits → fault `BAD_FLAGS`; INDIRECT → `INDIRECT` | `t_malformed` (5 cases) | **V** |
| C3 | queue size is a power of two ≤ 32768 | power of two ≤ `MAX_QSZ` (default 64; **at most 4096** — larger values are refused at elaboration because the cycle-detection bitmap has `MAX_QSZ` flops; regression up to 256) | `t_features`, matrix `big`, lint negative tests | **R** |
| C4 | available ring `le16 flags; le16 idx; le16 ring[N]` (+ `used_event`), aligned to 2; `idx` free-running | as stated; `idx` handled mod 2^16 | `t_wrap` (explicit 0xFFFF→0 wrap) | **V** |
| C5 | used ring `le16 flags; le16 idx; {le32 id; le32 len}[N]` (+ `avail_event`), aligned to 4 | as stated | UAPI check, every test | **V** |
| C6 | descriptor chain: NEXT links; chain is not circular; a chain is at most queue-size long | visited bitmap (`CYCLE`), `MAX_CHAIN` limit, index range checks | `t_malformed`, `t_invalid` (exactly `MAX_CHAIN` accepted) | **V** |
| C7 | device-writable descriptors follow all device-readable ones (driver requirement; a device may rely on it) | violation → fault `ORDER` | `t_malformed` | **V** / RECHECK (device behaviour on violation) |
| C8 | the device must not assume any particular descriptor framing | header may be split / merged; data in any number of segments; zero-length descriptors | `t_layouts` (5 layouts), `t_invalid` | **V** |
| C9 | the device must not write to a device-readable buffer | the executor writes only the data of `T_IN` and the status byte, both from the writable stream; `T_OUT` with a writable data buffer is `IOERR` and nothing is written | `t_invalid`, bus monitor, model compare | **V** |
| C10 | used element `id` = head of the chain; `len` = number of bytes written into the device-writable buffers | as stated (see D5) | `t_basic`, `t_perf`, every test | **V** / RECHECK (len for failed requests) |
| C11 | the device writes the used element **before** `used.idx`, and the buffer contents before the element | element write acknowledged, then index written; data and status acknowledged before the element | monitor (`h_order_viol` == 0 in every run), `t_basic` | **V** |
| C12 | notification suppression: `avail.flags` NO_INTERRUPT (driver → device) | honoured (only bit 0); EVENT_IDX not offered | `t_irq` | **V** |
| C13 | `used.flags` NO_NOTIFY (device → driver) | never written (the device polls on each doorbell); the host library honours it if present | — | **R** |
| C14 | indirect descriptors only if `VIRTIO_F_RING_INDIRECT_DESC` negotiated | not offered; a descriptor with INDIRECT is a driver error → fatal | `t_malformed` | **N** |
| C15 | packed virtqueues | **not implemented** | — | **N** |
| C16 | queue full/empty: the driver must not make more buffers available than the queue size | `avail.idx − last_avail > size` → fatal `AVAIL_OVERRUN`; exactly `size` outstanding is legal | `t_full_empty` | **V** |

## D. Block device (spec 5.2)

| # | requirement | implementation | evidence | status |
|---|---|---|---|---|
| D1 | device ID 2; one request virtqueue unless `VIRTIO_BLK_F_MQ` | one request queue | `t_basic` | **V** |
| D2 | config: `le64 capacity` (512-byte sectors), `seg_max`, `blk_size`; each valid only with its feature | capacity, `seg_max = MAX_CHAIN − 2`, `blk_size = 512`; unoffered fields read 0 | `t_basic`, UAPI offsets | **V** / RECHECK (seg_max counting) |
| D3 | request = `le32 type; le32 reserved; le64 sector; data…; u8 status` | header = first 16 readable bytes (any framing), status = last writable byte | `t_layouts`, `t_invalid` | **V** |
| D4 | types IN 0, OUT 1 (others: FLUSH 4, GET_ID 8, …) | IN, OUT; **every other type → `VIRTIO_BLK_S_UNSUPP`**, nothing moved | `t_invalid` (11 types incl. `BARRIER|OUT`) | **V** |
| D5 | status OK 0 / IOERR 1 / UNSUPP 2 | as stated | `t_invalid` | **V** |
| D6 | data length of IN/OUT is a multiple of the block size; the driver must not read/write beyond capacity | violation → `IOERR` (length 0, not a multiple of 512, beyond capacity — exact 64-bit arithmetic incl. sector 2^64−1) | `t_invalid` (15 range/length cases) | **V** / RECHECK (device response to a driver violation) |
| D7 | `VIRTIO_BLK_F_RO`: a write must get `IOERR` and no data is written | offered when configured; enforced regardless of acceptance | `t_readonly` | **V** |
| D8 | without `VIRTIO_BLK_F_FLUSH` the device is write-through | **FLUSH not offered**; every write is complete (in the backend) before its used entry is visible | `t_basic`, monitor | **V** |
| D9 | `seg_max`: the driver must not submit more segments than advertised | enforced by `MAX_CHAIN` (longer chain → fatal) | `t_malformed`, `t_invalid` | **V** |

## E. Self-imposed rules that are *not* in VirtIO (device policy, documented in `ARCHITECTURE.md`)
Fatal-fault handling (NEEDS_RESET, no used entry), one-window rule per DMA chunk, beat-aligned windows, quarantine flag, scrub,
partitions, per-beat guard, counters, the management port. They constrain what a guest can do; they add nothing to the guest-visible
protocol beyond the NEEDS_RESET signalling VirtIO already defines.

## F. Known gaps (do not claim compliance until closed)
1. Re-verify every **RECHECK** row against the OASIS text.
2. Run a real driver (e.g. Linux `virtio_mmio` + `virtio_blk` against the Verilated device through a QEMU/kvmtool-style transport) —
   **not done**; the project's own driver and BFM only prove self-consistency with the author's reading of the spec.
3. Sub-word configuration-space access, `ConfigGeneration` semantics, `VendorID`.
4. Packed virtqueues, indirect descriptors, multiqueue, EVENT_IDX, FLUSH, DISCARD/WRITE_ZEROES: not implemented (and not advertised).
