# 05 — Verification

All evidence is **simulation, a mutation campaign, one exhaustive SAT proof and generic synthesis**. Nothing ran on hardware.

## 1. Strategy: independent references, not self-checking

| layer | what it is | independent of the RTL because… |
|---|---|---|
| **SV golden device model** (`tb/tb_ref.svh`) | a transaction-level re-execution of the whole queue on a *copy* of guest memory and disk: avail poll → head → chain walk (`seen[]` array) → request streams addressed by **byte position** → data chunks → status → used element → used idx; permissions from the testbench's own window table | no shared code, state machine or data layout with the RTL (the RTL is a cursor-based multi-state FSM, the model straight-line code). After **every scenario the whole guest-memory image, the whole disk image and each function's state must equal the model's.** |
| **Directed tests with hard-coded expectations** | status bytes, `used.len`, fault codes, register values, window-edge cases (one byte either side), range arithmetic at 2^32/2^63/2^64 | do not depend on the model at all |
| **Bus monitors** | every guest beat must lie in a window of the domain being served with the right permission (testbench's own table); completion-ordering monitor (status byte and used element must already be in memory when `used.idx` is written); the vendored DataFabric **SFB2 protocol checker** on both master ports | observe the ports only |
| **C software device** (`host/src/sfv_softdev.c`) + differential harness | a *third* implementation (C, written from the contract) driven by the same host library; identical random operation streams on it and on the **Verilated RTL**, every observable compared after every operation (return codes, status byte, used length, device status, fault code, queue indices, the full VM-window memory digest, nine functional counters) | different language, different author-context, black-box driver view |
| **Exhaustive equivalence proof** (`formal/`) | the window permission check (`sfv_win_check`) vs a separately written 128-bit reference, for all 64-bit addresses, 32-bit lengths, window bases/sizes and permission bits (1, 2 and 4 windows); the proof is shown to find counterexamples for three planted bugs, including 64-bit wrap | exhaustive, not sampled |
| **UAPI cross-check** (`make check-abi`) | 77 constants / layouts vs the Linux `virtio_*` headers | independent source for the spec's numbers |

**Icarus caveat:** the vendored SFB2 protocol checker does not count transactions under Icarus Verilog 12 (it reports `1 req / 0 req`), so the Icarus cross-check run (8 scenarios, 20 558
checks) validates the *functional* behaviour — every data, memory-image, disk-image and state comparison — but **not** the SFB2 protocol rules; those are checked only in the Verilator
runs (`gm: 12784 req 12784 rsp, 0 violations` in the base configuration) and in the co-simulation harness's own R2/R5 monitor.

**Limit of independence** (stated plainly): the model, the C device and the RTL share an *author and a behaviour contract* — they are independent
*implementations*, not independent *specifications*. The directed tests and the mutation campaign exist to reduce that risk; they do not remove it.

## 2. Scenario catalogue (`tb/tb_tests.svh`) and the brief's list

| brief item | scenario(s) |
|---|---|
| Single descriptor | `malformed` (the four possible single-descriptor shapes — readable-only, writable-only, header-only, zero-length — are all **rejected**; a virtio-blk request cannot be valid with one descriptor because header and status need opposite directions), `invalid`/`layouts` (the minimal *valid* chain: 2 descriptors) |
| Chained descriptors | `layouts` (5 layouts × 6 sizes, unaligned buffers, header split 4+12, header+data merged, data in 2–4 segments, 4 KiB straddle), `invalid` (exactly `MAX_CHAIN` descriptors accepted, zero-length descriptors) |
| Ring wraparound | `wrap` (queue size 4: ring index and descriptor slots wrap 14×; **16-bit index wrap 0xFFFB → 0x0005** via preset) |
| Queue full / empty | `full_empty` (spurious doorbell on an empty ring; ring with exactly `size` outstanding; `size + 9` → fatal `AVAIL_OVERRUN`) |
| Invalid flags | `malformed` (reserved bits ×3, INDIRECT ×2, order violation) |
| Invalid lengths | `invalid` (0, 100, 256, 513, 1023, beyond capacity, crossing the end, sector 2^32 / 2^63 / 2^64−1, unsupported types) |
| Malformed chains | `malformed` (self loop, 0→1→0, MAXCH+1, `next`/head out of range, no status, short header) |
| DMA permission failure | `perm` (R/W per window, edges incl. ±1 byte, outside, cross-domain, straddle, 2^48, wrap, 2^63, header), `perm_fatal` (status / desc table / avail ring / used ring / disabled domain), `revoke` (8 offsets inside a running transfer) |
| Reset | `reset` (idle, **mid-transfer**, FAILED, NEEDS_RESET, status protocol, latency ≤ 2 beats, no guest access after Status reads 0) |
| Backpressure | `stall` (15 % acceptance, ≤ 12 cycles latency), `random` (random level per batch), matrix configs `stall1/stall2`, differential co-simulation at three levels |
| Completion ordering | monitor in every run; `wrap`/`layouts` check used ids in order |
| Multiple tenant domains | `multi` (concurrent traffic, write- and read-attacks on another tenant, foreign descriptor table, quarantine, scrub-on-re-ownership, partition overlap), matrix `nf2`, `nf3` |
| Features / registers | `features` (negative negotiation of 7 feature sets, 10 refused queue geometries), `disabled_fn` (≥ 15 refused management commands), `irq`, `perf` |
| Notification / suppression | `irq` (NO_INTERRUPT, ACK, counters), `doorbell` |
| Doorbell races | `doorbell` (kick 0…15 cycles after DRIVER_OK; a second request published at ≈ 67 different offsets while the first runs) — regression of a real bug (§4) |
| External IOMMU | `t_ext` (build `EXT=1`): translation, read-only mapping, unmapped IOVA, unmapped status → fatal |
| Backend isolation | `tb_ramdisk` unit bench (58 checks on Icarus and on Verilator; the protocol checker counts only under Verilator): partitions, error responses, strobes, overlap/geometry refusal, scrub, store stalls during scrub |

## 3. Results

| check | result | evidence |
|---|---|---|
| System regression, 12 configurations (Verilator ×11 + Icarus ×1) | **12 / 12 pass**, 536,264 checks | `reports/regression.md` |
| **Definition of done** — C VM driver on the Verilated RTL (demo, also under heavy back-pressure) | **PASS** | `reports/cosim_demo_rtl*.log` |
| Differential run: software device vs RTL, identical random op streams (2400 ops, 4 seeds, 3 back-pressure levels) | **0 mismatches**; SFB2 protocol violations 0 | `reports/cosim_diff_*.log` |
| Mutation campaign (planted RTL bugs) | **30 / 30 killed** | `reports/mutation.md` |
| Exhaustive SAT proof: window permission check vs 128-bit reference (1, 2, 4 windows) | **proved** (and finds 3 planted bugs) | `reports/formal.log` |
| Protected-backend unit bench (Icarus + Verilator) | 58 checks, 0 errors; 58 checks, 0 errors | `reports/unit.log` |
| Verilator `-Wall` lint | 8 configurations clean, 16 / 16 illegal parameter sets refused | `reports/lint.md` |
| Constants vs Linux UAPI virtio headers | 77 package constants / layouts agree | `reports/check_abi.log` |
| Software device + diff self-check; Rust wrapper | demo PASS, 500 ops / 0 mismatches, 500 ops / 0 mismatches; 5 Rust tests pass | `reports/host_softdev.log`, `reports/rust_tests.log` |
| Yosys 0.33 generic synthesis (default core) | 48461 cells, 5361 flops, `check -assert` clean, latches 0; xc7 estimate 13560 LUT / 5372 FF (**no P&R, no timing, no area claim**) | `reports/synth/SUMMARY.md` |

### Regression matrix (`scripts/regress.py`)

| config | simulator | what | tests | checks | errors | guest-port requests | result |
|---|---|---|---|---|---|---|---|
| base | Verilator 5.020 | 1 function, 2 domains, 64-bit bus, defaults | 19 | 49554 | 0 | 12784 | **PASS** |
| stall1 | Verilator 5.020 | moderate back-pressure on both ports | 19 | 49580 | 0 | 12699 | **PASS** |
| stall2 | Verilator 5.020 | heavy back-pressure on both ports | 19 | 49482 | 0 | 12745 | **PASS** |
| nf2 | Verilator 5.020 | 2 functions / 2 domains (multi-tenant) | 19 | 53112 | 0 | 12749 | **PASS** |
| nf3 | Verilator 5.020 | 3 functions / 3 domains | 19 | 74504 | 0 | 12808 | **PASS** |
| dw32 | Verilator 5.020 | 32-bit data bus | 19 | 87372 | 0 | 23533 | **PASS** |
| dw128 | Verilator 5.020 | 128-bit data bus | 19 | 30513 | 0 | 7337 | **PASS** |
| small | Verilator 5.020 | 16-byte stage, chains of 4, queue max 32 | 19 | 49492 | 0 | 16163 | **PASS** |
| big | Verilator 5.020 | 128-byte stage, chains of 16, queue max 256 | 19 | 49407 | 0 | 12292 | **PASS** |
| seeds | Verilator 5.020 | random regression, 800 batches, other seed (+ doorbell sweep, stall, multi) | 4 | 20566 | 0 | 12799 | **PASS** |
| ext | Verilator 5.020 | external IOMMU mode | 1 | 2124 | 0 | 178 | **PASS** |
| icarus | Icarus 12 | Icarus Verilog 12 cross-check (tests 0-6,11) | 8 | 20558 | 0 | n/a (the vendored protocol checker does not count under Icarus 12) | **PASS** |
Total checks: 536264.  Logs: reports/sim/<config>.log

Latency figures (zero wait states; `reports/sim/base.log`): LATENCY (cycles, head fetch -> used.idx acknowledged; 8-byte bus, 64-byte stage, zero wait states): OUT 512 B = 755, IN 512 B = 755, OUT 4 KiB = 5251, IN 4 KiB = 5251; 3-descriptor walk = 48 / 48


## 4. Defects found (and what each was)

| # | what | kind | how found | fix / evidence |
|---|---|---|---|---|
| 1 | **Lost doorbell**: the controller cleared `pend` when a poll finished empty, so a doorbell that landed while the poll was in flight was discarded; the first request after DRIVER_OK could wait 225 000 cycles | **RTL** | the C-driver **co-simulation** (the SV testbench's kicks never raced a poll) | `pend` is cleared when a poll *starts*, and a set in the same cycle wins; `doorbell` scenario sweeps the race; mutant M23 reintroduces it and is killed |
| 2 | management selector registers truncated to `DOMW`/`FW` bits: with 2 domains, `DOM_SEL = 2` silently selected domain 0 (an out-of-range value was *aliased*, not rejected) | **RTL** | `disabled_fn` (expected refusal) | selectors keep 8 bits and are range-checked |
| 3 | beats could read bytes beyond an unaligned window edge | RTL hardening | while writing the bus monitor | management refuses windows that are empty or not beat-aligned; edge tests ±1 byte; formal proof of the check |
| 4 | RTL used `int'()` casts that the baseline Yosys 0.33 flow rejects | RTL portability | first synthesis attempt | ported to `N'()`; synthesizes in 20 configurations |
| 5 | package constant `ST_DRIVER_BITS` typed 0xAF instead of 0x8F | RTL (package) | review before first use | fixed; the UAPI cross-check would also catch such slips |
| 6 | `MAX_QSZ = 32768` would need a 32 Kbit visited-descriptor bitmap | design limit | lint | documented limit 4096, illegal sets refused at elaboration (16 negative tests) |
| 7 | **test hole**: the revocation and in-flight-reset scenarios waited on a *global* beat counter, so they fired before any data moved and tested nothing; the mutant "per-beat guard bypassed" **survived** | **testbench** | the mutation campaign | counters made relative; mutants M06/M07/M21 killed; added the reset-latency check (M22) |
| 8 | stale model snapshot after a driver reset; first doorbell must follow all publishes; injected faults clobbered in-flight descriptors; straddle test assumed 64-byte chunks; max-chain test arithmetic broke for `MAX_CHAIN > 10`; fault tests assumed queue size 16 ≥ `MAX_CHAIN + 1`; monitor flagged a beat that had been presented before a revocation | **testbench** | matrix runs (`small`, `big`, `seeds`) | fixed; the matrix now passes in all 12 configurations |
| 9 | software device counted descriptors of rejected chains; differential snapshots raced the notification / index update under back-pressure | harness / model | co-simulation diff | counters harmonised; snapshots let the device settle |

## 5. Mutation campaign (`scripts/mutate.py`)
One planted bug at a time (30 mutants: permission, window bounds, default-deny, per-beat guard, descriptor validation, framing, range checks,
`used.len`, element contents, interrupts, ring overrun, feature negotiation, queue geometry, reset, the lost-doorbell race, ring head check,
function→domain binding, management rules, backend bounds / base / scrub). **Killed** = the suite reports a failure.

**30 / 30 killed.**

| id | planted bug | status | first failure message |
|---|---|---|---|
| M01 | window WRITE permission ignored | **KILLED** | [MON] t=3269295000 forbidden guest beat: func 0 dom 0 WRITE addr 0x14010 strb 0xff |
| M02 | window READ permission ignored | **KILLED** | [MON] t=3315105000 forbidden guest beat: func 0 dom 0  READ addr 0x16010 strb 0x0 |
| M03 | window end check off by one byte | **KILLED** | [MON] t=3311265000 forbidden guest beat: func 0 dom 0  READ addr 0x15000 strb 0x0 |
| M04 | window start check off by one byte | **KILLED** | [MON] t=3313185000 forbidden guest beat: func 0 dom 0  READ addr 0x13ff8 strb 0x0 |
| M05 | domain-enable check dropped (default deny lost) | **KILLED** | [FAIL] t=3440836000  DMA permissions (fatal): status byte, descriptor table, available ring, used ring, disabled domain: adapter detail = DD_DISABLED: got 0x0 expected 0x1 |
| M06 | per-beat guard bypassed | **KILLED** | [MON] t=3504465000 forbidden guest beat: func 0 dom 0  READ addr 0x51d0 strb 0x0 |
| M07 | per-beat guard ignores the live table (grant only) | **KILLED** | [MON] t=3504465000 forbidden guest beat: func 0 dom 0  READ addr 0x51d0 strb 0x0 |
| M08 | descriptor cycle detection removed | **KILLED** | [FAIL] t=2992476000  malformed chains: cycles, length, flags, indirect, order, framing, indices: cycle: self loop: fault code matches the model: got 0x5 expected 0x4 |
| M09 | chain length limit off by one | **KILLED** | [MON] t=3019205000 func 0: used.idx advanced before the status byte of request 1 was written (head 3, status addr 0x5448, qsz 16) |
| M10 | indirect descriptors accepted | **KILLED** | [FAIL] t=3125246000  malformed chains: cycles, length, flags, indirect, order, framing, indices: indirect descriptor: fault code matches the model: got 0xa expected 0x7 |
| M11 | device-readable-after-writable allowed | **KILLED** | [MON] t=3158015000 func 0: used.idx advanced before the status byte of request 1 was written (head 3, status addr 0x5458, qsz 16) |
| M12 | reserved descriptor flags accepted | **KILLED** | [FAIL] t=3085376000  malformed chains: cycles, length, flags, indirect, order, framing, indices: reserved flag bits: fault code matches the model: got 0xa expected 0x6 |
| M13 | read-only function accepts writes | **KILLED** | [FAIL] t=2945405000  read-only function: VIRTIO_BLK_F_RO offered, writes refused with IOERR, reads work: OUT on read-only disk: status byte: got 0x0 expected 0x1 |
| M14 | sector range check lets a request cross the end of the disk | **KILLED** | [FAIL] t=2841225000  invalid lengths / ranges / types / framing: answered through the status byte: OUT crossing the end: disk image equals the model |
| M15 | used.len omits the status byte | **KILLED** | [FAIL] t=50015000  basic: init, write 1 sector, read it back: OUT: used.len: got 0x0 expected 0x1 |
| M16 | used element written without its length | **KILLED** | [FAIL] t=50015000  basic: init, write 1 sector, read it back: OUT: used.len: got 0x5b32029f expected 0x1 |
| M17 | NO_INTERRUPT ignored | **KILLED** | [FAIL] t=3871636000  notifications: InterruptStatus / ACK, avail.flags NO_INTERRUPT suppression: NO_INTERRUPT: no interrupt raised |
| M18 | a full ring (outstanding == queue size) treated as overrun | **KILLED** | [FAIL] t=6733395000  queue empty / full / over-full: completion appears in the used ring (no hang) |
| M19 | FEATURES_OK granted for features not offered | **KILLED** | [FAIL] t=3785956000  feature negotiation, status protocol, queue-setup validation, register map: accepting INDIRECT_DESC (not offered) -> FEATURES_OK refused |
| M20 | queue address alignment not validated | **KILLED** | [FAIL] t=3789816000  feature negotiation, status protocol, queue-setup validation, register map: descriptor table not 16-byte aligned -> refused: got 0x1 expected 0x0 |
| M21 | Status reads 0 before the engine has stopped (reset completes early) | **KILLED** | [FAIL] t=3709726000  reset: idle, in flight, after a fault, FAILED, NEEDS_RESET rules: Status keeps reading its old non-zero value until the engine has stopped (a poll for 0 cannot |
| M22 | in-flight transfer ignores a reset (abort lost) | **KILLED** | [FAIL] t=3710006000  reset: idle, in flight, after a fault, FAILED, NEEDS_RESET rules: reset latency: the abort takes effect at the next beat boundary (at most 2 further guest beat |
| M23 | LOST DOORBELL (the bug found by co-simulation): pend cleared at the end of an empty poll | **KILLED** | [FAIL] t=6645285000  doorbell races: kick right after DRIVER_OK, and kick while a request is running (sweep of the gap): completion appears in the used ring (no hang) |
| M24 | available-ring head NOT range checked anywhere (the check exists twice: controller and walker; both removed) | **KILLED** | [FAIL] t=3032686000  malformed chains: cycles, length, flags, indirect, order, framing, indices: next = queue size: fault code matches the model: got 0x6 expected 0x3 |
| M25 | function-to-domain binding ignored: every function uses domain 0 | **KILLED** | [FAIL] t=4136485000  multi-tenant: concurrent functions, isolation attacks, quarantine, scrub on re-ownership: completion appears in the used ring (no hang) |
| M26 | management lets an IN-USE function be reconfigured | **KILLED** | [FAIL] t=3812846000  a function that is not enabled by management: DeviceID 0, writes ignored: mgmt write: error flag |
| M27 | management accepts windows that are not beat-aligned | **KILLED** | [FAIL] t=3790786000  a function that is not enabled by management: DeviceID 0, writes ignored: mgmt write: error flag |
| M28 | backend partition upper bound not enforced (UNIT: tb_ramdisk) | **KILLED** | [FAIL] first beat beyond dom0's partition -> error |
| M29 | backend uses domain 0's partition base for every domain (UNIT: tb_ramdisk) | **KILLED** | [FAIL] dom0 reads its own data |
| M30 | scrub does not zero the partition (UNIT: tb_ramdisk) | **KILLED** | [FAIL] after teardown scrub the next owner reads zeros |

### What the campaign taught (kept honest: first run vs final)

The campaign was developed iteratively, and the order matters. The **first run (testbench v1)** was stopped after six results because **M06** survived; it pointed at a test hole, not at RTL. After the fix, a targeted re-run of M06, M07, M21, M22 killed three of four and left **M22** standing, which led to one more check. The **complete second run (testbench v2)** then killed 29 of 30 with **M24** surviving as an equivalent mutant (below); M24 was redefined and re-run alone. The three observations:

* **M06 / M07** (per-beat guard bypassed / ignoring the live table) survived because the revocation scenario waited on a *global* beat counter that already stood in the thousands — the "revocation" fired before any data moved and tested nothing. **M21** (Status reads 0 too early) and **M22** (abort ignored in the mover) survived for the same reason in the in-flight-reset scenario. Fix: beat counts are taken relative to the start of the request; the revocation test now revokes at eight different points inside a running transfer and requires that at most one further guest beat is issued; the reset test asserts the reset hits mid-request, that `Status` keeps reading non-zero until the engine has stopped, that at most two further beats follow the reset write, and that an aborted request changed only bytes inside its own extent. M06, M07, M21 were then killed; M22 was killed once the reset-latency check existed (without it M22 is a pure *latency* mutant: the safety property "no access after Status reads 0" still holds because Status stays non-zero until the chunk in flight finishes).
* **M24** was first written as "head check `>=` → `>`" and survived, correctly: the available-ring head is range-checked **twice** (controller and walker), so weakening one copy is an *equivalent mutant* (same fault code, same behaviour). It was redefined as "both checks removed" and is killed (the walker's index check also guards every `next`: with it gone the device fetches a descriptor beyond the table and reports `BAD_FLAGS` instead of `BAD_NEXT`).

**Final run (testbench v2): 30 / 30 killed, 0 survivors.** M28–M30 (backend bounds / base / scrub) are killed by the unit bench `tb_ramdisk`, because the engine's own capacity check keeps requests inside the partition and the backend's guard cannot be reached through the engine — which is exactly why it needs its own bench.

**What a kill proves, and does not:** an injected bug in one of 30 places was noticed; it says nothing about bugs elsewhere or of other shapes. One mutant (M23) reintroduces a real bug that had escaped the system testbench and was found by the C-driver co-simulation. The mutants are listed in `scripts/mutate.py`; known equivalent mutations (for example removing the *grant direction* check of the per-beat guard, or the 4 KiB chunk rule in table mode) were not counted because no port can observe them.


## 6. How to reproduce
```bash
make check-abi lint host rust unit formal      # a few minutes
make regress                                   # 12 configurations, about 25 minutes on 4 cores
make cosim                                     # the C VM driver on the RTL, demo + differential runs
make mutate                                    # about 45 minutes
make synth                                     # about 30 minutes
```
Tool versions: `reports/tools.txt` (Verilator 5.020, Icarus 12, Yosys 0.33, GCC 13, Python 3.13; Rust 1.97 for the wrapper).
