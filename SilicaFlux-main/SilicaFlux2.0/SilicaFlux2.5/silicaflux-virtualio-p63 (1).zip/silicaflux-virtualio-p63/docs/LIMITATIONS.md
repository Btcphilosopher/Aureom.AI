# 07 — Limitations — what this is **not**

**Evidence is simulation and generic synthesis only.** There is no FPGA build, no silicon, no timing, no area/power claim, no PCIe.

## Protocol / standard
* **Not certified VirtIO-compliant**, and not tested with a real VirtIO driver (see `CONFORMANCE.md`). The OASIS text was not reachable;
  constants are cross-checked against the Linux UAPI headers, behaviour is the author's reading of the spec ("RECHECK" rows).
* virtio-mmio **version 2 only** (no legacy); 32-bit register accesses; `VendorID` is a placeholder; `ConfigGeneration` is constant.
* **Not implemented / not offered:** packed rings, indirect descriptors, EVENT_IDX, IN_ORDER, multiqueue (`VIRTIO_BLK_F_MQ`), FLUSH,
  DISCARD, WRITE_ZEROES, SIZE_MAX, notification data, ring reset, shared-memory regions, virtio-net.
* One request in flight per engine (functions are time-multiplexed, requests are completed strictly in order) — correct but **slow, and no
  throughput claim is made**: measured in simulation with zero wait states on both ports (64-bit bus, 64-byte stage), a 512-byte request takes
  **755 cycles** head-fetch → used.idx acknowledged and a 4 KiB request **5251 cycles (≈ 0.78 byte/cycle)**; 32-bit bus: 1299 / 9379; 128-bit bus:
  479 / 3183. The cost is dominated by one-beat-at-a-time SFB2 (≈ 3 cycles per beat) and the stage-buffer round trip per 64-byte chunk.
* Only the device-side notification suppression of `NO_INTERRUPT` is implemented; `used.flags` NO_NOTIFY is never written.

## Backend and platform
* The backend is a **volatile RAM disk** with per-domain partitions — not flash, not the StorageCore FTL, not persistent. A reset of the
  engine keeps the RAM contents (no reset on the memory) but loses the partition table (the hypervisor must re-commit; scrub if needed).
* **No PCIe, no SR-IOV, no real IOMMU.** The external-IOMMU mode is an *interface* verified against a behavioural model; it assumes the IOMMU
  returns a contiguous translation per 4 KiB page and answers exactly once.
* **Not integrated into `silicaflux_cloud_dpu`** (P61); its `vio_*` queue ports are a different (command-queue) interface. VirtualIO attaches
  to the same SFB2 conventions but a full integration (shared `hm_*` port, tenant context sharing, ControlCore firmware) was not attempted.

## Protection
* Protection is **functional**: no side-channel isolation (shared stage buffer, shared bus timing and arbitration are observable), no
  DoS fairness beyond round robin per request, no confidential-computing claims.
* A range must lie inside **one** window **per chunk** (≤ stage bytes, never across a 4 KiB boundary); adjacent windows should be merged by
  management. A window revoked mid-transfer stops the engine at the next beat it *presents*; a beat already presented completes (SFB2 R2).
* On a permission fault in the middle of a multi-chunk request, earlier chunks may already have been moved (always inside granted ranges);
  the request then completes with IOERR.
* The trusted computing base includes the management plane and the memory system behind `gm_*` (an IOMMU there must honour the same windows).

## Verification
* The golden model, the C software device and the RTL were written by the same author from the same contract; they are *independent
  implementations*, not independent *specifications*. The directed tests with hard-coded expectations and the mutation campaign exist to
  reduce that risk, not remove it.
* Formal evidence is limited to an **equivalence proof of the window permission check** (all inputs); the sequential RTL is verified by simulation
  (two simulators for a subset) and mutation testing — **not** formally verified.
* Verilator 5.020 / Icarus 12 / Yosys 0.33 only; no commercial simulator, no lint beyond Verilator `-Wall`.
