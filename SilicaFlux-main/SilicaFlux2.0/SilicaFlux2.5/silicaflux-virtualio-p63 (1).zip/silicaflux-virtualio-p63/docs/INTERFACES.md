# 03 — Interfaces, register maps, integration

## 1. Ports of `silicaflux_virtio_engine` (parameters: `ARCHITECTURE.md` §4)

| group | signals | protocol |
|---|---|---|
| clock / reset | `clk`, `rst_n` | one clock; `rst_n` active low, asynchronous assert (release synchronised outside) |
| guest MMIO | `mmio_req_valid/ready/write/addr[15:0]/wdata[31:0]`, `mmio_rsp_valid/rdata/err`, `irq_o[NUM_FUNCS-1:0]` | request accepted **every cycle** (`ready` tied high); response **one cycle later**; address bits `[15:12]` select the function (4 KiB window each), `[11:0]` the virtio-mmio register; 32-bit aligned accesses only — anything else gets `rsp_err` |
| management | `mg_req_valid/ready/write/addr[11:0]/wdata`, `mg_rsp_valid/rdata/err`, `mgmt_irq_o` | one request at a time (`ready` low for the cycle after an accept); response one cycle later; **a guest cannot reach it** |
| guest memory | `gm_req_valid/ready/write/addr[ADDR_WIDTH-1:0]/wdata/wstrb`, `gm_rsp_valid/ready/rdata/error` | **SFB2** (DataFabric): one outstanding request; valid/payload held until ready; the response is never in the acceptance cycle; error and write responses carry `rdata = 0`. Attach to AXI4 / a PCIe endpoint with CloudDPU P61's `sfd_sfb2_to_axi4` |
| external IOMMU | `iommu_req_valid/ready/dom/iova/len/write`, `iommu_rsp_valid/ok/pa` | only with `EXT_IOMMU = 1`: request held until ready; exactly one `iommu_rsp_valid` pulse, ≥ 1 cycle after the request was accepted; `ok = 0` refuses; one request outstanding. Tie inputs low otherwise |

`sfv_engine_core` (no RAM disk) exposes in place of the internal store: `bk_req_*`/`bk_rsp_*` (SFB2 + `bk_req_dom`) and the partition-control
port `pc_valid/dom/base/size/en/scrub`, `pc_ok` (combinational "would this commit be accepted"), `part_en_i`, `part_busy_i`, `part_size_i`.
That is the seam for replacing `sfv_ramdisk` with an adapter to the CloudDPU's tenant SRAM partitions.

## 2. Guest registers — virtio-mmio version 2 (offsets within a function's 4 KiB window)

| offset | name | access | notes |
|---|---|---|---|
| 0x000 | MagicValue | R | 0x74726976 |
| 0x004 | Version | R | 2 |
| 0x008 | DeviceID | R | 2 (block); 0 while management has not enabled the function |
| 0x00c | VendorID | R | 0x53464C58 (placeholder) |
| 0x010 | DeviceFeatures | R | window chosen by DeviceFeaturesSel (0 → bits 31:0, 1 → bits 63:32, else 0) |
| 0x014 | DeviceFeaturesSel | W | |
| 0x020 | DriverFeatures | W | window chosen by DriverFeaturesSel; frozen after FEATURES_OK |
| 0x024 | DriverFeaturesSel | W | |
| 0x030 | QueueSel | W | only 0 exists |
| 0x034 | QueueNumMax | R | `MAX_QSZ` for queue 0, else 0 |
| 0x038 | QueueNum | W | ignored while the queue is ready |
| 0x044 | QueueReady | RW | write 1 accepted only for a legal geometry; writing 0 is ignored |
| 0x050 | QueueNotify | W | 0 = doorbell for queue 0 |
| 0x060 | InterruptStatus | R | bit 0 used buffer, bit 1 configuration change |
| 0x064 | InterruptACK | W | |
| 0x070 | Status | RW | monotonic; 0 resets; NEEDS_RESET device-owned |
| 0x080/84 | QueueDescLow/High | W | descriptor table |
| 0x090/94 | QueueDriverLow/High | W | available ring |
| 0x0a0/a4 | QueueDeviceLow/High | W | used ring |
| 0x0fc | ConfigGeneration | R | 0 |
| 0x100 / 0x104 | capacity (le64) | R | 512-byte sectors |
| 0x10c | seg_max | R | `MAX_CHAIN − 2` |
| 0x114 | blk_size | R | 512 |

Write-only registers read 0; unknown offsets read 0.

## 3. Management registers (`mg_*`, 12-bit word addresses, 32-bit)

| offset | name | access | meaning |
|---|---|---|---|
| 0x000 | ID | R | `0x53465645` ("SFVE") |
| 0x004 | ABI | R | `{major, minor}` = `{1, 0}` |
| 0x008 | CAPS0 | R | `[7:0]` NF, `[15:8]` ND, `[23:16]` NW, `[24]` EXT_IOMMU |
| 0x00c | CAPS1 | R | `[15:0]` MAX_QSZ, `[23:16]` MAX_CHAIN, `[31:24]` log2(stage bytes) |
| 0x010 | STORE | R | backend store bytes |
| 0x014 | BUS | R | `[7:0]` address width, `[15:8]` data width |
| 0x020 / 0x024 | FAULT / FAULT_IE | RW1C / RW | bit *f* = function *f* took a fatal fault; `mgmt_irq_o` = `FAULT & FAULT_IE` |
| 0x040 | DOM_SEL | RW | selector (8 bit; an out-of-range value is **rejected**, never aliased) |
| 0x044 | WIN_SEL | RW | |
| 0x048–0x054 | WIN_BASE_LO/HI, WIN_SIZE_LO/HI | RW | shadow registers |
| 0x058 | WIN_CTL | RW | `[0]` R, `[1]` W, `[2]` valid; **a write commits {shadow base, shadow size, ctl} atomically** for (DOM_SEL, WIN_SEL). Refused if valid and the window is empty, not beat-aligned, or beyond `2^ADDR_WIDTH` |
| 0x060 | DOM_CTL | RW | `[0]` enable, `[1]` scrub; a write commits enable + the shadow partition; refused if the backend refuses |
| 0x064 / 0x068 | DOM_PBASE / DOM_PSIZE | RW | shadow partition (bytes; 512-aligned, non-empty, inside the store, no overlap with an enabled partition) |
| 0x06c | DOM_STATUS | R | `[0]` enabled and usable, `[1]` scrubbing |
| 0x080 | FUNC_SEL | RW | |
| 0x084 / 0x088 / 0x08c | FUNC_DOMAIN, FUNC_CAP_LO/HI | RW | shadows (capacity in sectors) |
| 0x090 | FUNC_CTL | RW | `[0]` enable, `[1]` read-only, `[2]` quarantine-on-violation; a write commits; **refused while the function's status is non-zero**, if the domain is invalid, or (when enabling) if the partition is not configured / is smaller than the capacity / capacity is 0 |
| 0x094 | FUNC_STATUS | R | `[7:0]` device status, `[15:8]` last fault code, `[23:16]` last domain-adapter detail, `[24]` queue ready, `[25]` work pending |
| 0x098 | FUNC_FCNT | R | fatal-fault count |
| 0x0a0 | FUNC_QSTATE | R | `[15:0]` last_avail, `[31:16]` used_idx |
| 0x0c0 / 0x0c4 / 0x0c8 | PERF_SEL / PERF_DATA / PERF_CTL | RW / R / W | `PERF_SEL = {function[15:8], counter[7:0]}`; `PERF_CTL[0]` clears every counter |

Fault codes (`FUNC_STATUS[15:8]`): `01` AVAIL_OVERRUN, `02` BAD_HEAD, `03` BAD_NEXT, `04` CYCLE, `05` CHAIN_TOO_LONG, `06` BAD_FLAGS, `07` INDIRECT,
`08` ORDER, `09` SHORT_HDR, `0A` NO_STATUS, `10` DMA_DENIED, `11` GUEST_BUS. Adapter detail: `01` domain disabled, `02` zero length, `03` range / wrap,
`04` no window, `05` permission, `06` IOMMU refused. Counter ids: `rtl/pkg/silicaflux_virtio_pkg.sv` (`PC_*`).

**Programming order** (the hypervisor): windows → domain (partition, scrub) → function (capacity ≤ partition). The guest then sees a device.

## 4. Backend port (`bk_*`, SFB2 + sideband) and the RAM disk
`bk_req_addr[31:0]` is a **partition-relative byte address**, `bk_req_dom` the domain. `sfv_ramdisk` adds the partition base and answers
an error (no read, no write, `rdata = 0`) for: an unconfigured/disabled domain, a beat not wholly inside the partition or the store, a
beat address not aligned to the bus width, or any request during a scrub. Scrub (`DOM_CTL[1]`) zeroes the partition one word per cycle;
the store accepts no request meanwhile and no second commit is accepted.

## 5. Integration with the CloudDPU (P61) — what is real and what is not
Real: the **SFB2** shape of `gm_*` and `bk_*`; `sfd_sfb2_to_axi4` converts `gm_*` to an AXI4 master (single-beat) for a PCIe endpoint /
interconnect; the management port is a plain register port that the ControlCore's accelerator register pages can carry; `irq_o` /
`mgmt_irq_o` are levels for the ControlCore's interrupt controller.
**Not done:** instantiating VirtualIO inside `silicaflux_cloud_dpu`, multiplexing `gm_*` with CloudDMA's `hm_*` port, replacing the RAM disk
by the DPU SRAM partitions, a PCIe endpoint. These are integration tasks, listed in `LIMITATIONS.md`; none was attempted.
