# 04 — Host integration library and examples

`host/` is a minimal, dependency-free C99 library (no allocation, no OS calls) that plays two roles:
the **guest driver** (device initialisation, queue creation, descriptor submission, notification, completion polling, error handling,
recovery) and the **hypervisor** (windows, partitions, function binding, fault state, counters). It talks to the device only through
`sfv_transport_t` / `sfv_mgmt_ops_t` (function-pointer tables), so the same code runs on every backend.

| backend | where | what it is |
|---|---|---|
| **software device** (`sfv_softdev`) | `host/src/sfv_softdev.c` | the **simulated transport** for when no PCIe exists: a software VirtIO-blk device with the same behaviour contract as the RTL; also an independent C reference model |
| **Verilated RTL** (`sfv_cosim`) | `cosim/sfv_cosim.cpp` | the real RTL, driven cycle by cycle; guest memory is a C++ array served by an SFB2 slave model (random back-pressure / latency) |
| PCIe / VFIO | — | **not provided** (no PCIe endpoint exists in the repository) |

## API summary (`include/sfv_host.h`)
```c
sfv_dev_init(&dev, &transport, func, arena_base, arena_len, want_optional);   // probe, reset, ACK, DRIVER, features, FEATURES_OK
sfv_queue_create(&dev, 16);                                                    // rings laid out in the arena, QueueReady
sfv_dev_start(&dev);                                                           // DRIVER_OK
sfv_blk_config(&dev, &cfg);                                                    // capacity / blk_size / seg_max (generation-checked)
sfv_submit(&dev, segs, n, cookie, &head);  sfv_notify(&dev);                   // generic chain + doorbell
sfv_poll(&dev, &cpl);  sfv_wait_completion(&dev, &cpl, budget);                // reap completions from the used ring
sfv_blk_submit / sfv_blk_rw(&dev, is_write, sector, buf, nbytes, &status, &used_len);
sfv_check_health(&dev);  sfv_recover(&dev);                                    // NEEDS_RESET -> reset + re-initialise + re-create the queue
sfv_irq_pending / sfv_irq_ack / sfv_set_no_interrupt                           // notifications
sfv_hv_set_window / sfv_hv_set_domain / sfv_hv_set_function / sfv_hv_func_state / sfv_hv_perf   // hypervisor
```
Error codes are negative `SFV_E_*` (`sfv_strerror`). A request that completes with a non-OK block status returns `SFV_E_IO` and the status byte
is returned separately. A malformed chain / isolation violation shows up as `SFV_E_NEEDS_RESET` from `sfv_poll` / `sfv_check_health`;
`sfv_recover` brings the function back (in-flight work is dropped — the device never completed it).

## Build and run
```bash
make -C host                        # builds the library + examples, runs the software-device demo (needs only a C compiler)
scripts/cosim.sh demo               # the SAME demo on the Verilated RTL (needs Verilator 5.x)
scripts/cosim.sh demo --stall 2     # ... with heavy back-pressure on the guest-memory port
scripts/cosim.sh diff 400 7         # software device vs RTL: identical random op stream, every observable compared
```

## The demonstration (`host/examples/vm_blk_demo.c`) — the definition of done
Hypervisor grants the VM a memory window and a scrubbed 16 KiB disk partition and enables function 0. The guest driver initialises the
device, creates a 16-entry queue, writes eight chained sector groups, reads them back and verifies every byte (used lengths 1 and
n+1 as the spec defines), shows request errors reported through the status byte, a DMA buffer outside the granted window being
refused (nothing delivered), a malformed (cyclic) descriptor chain stopping the device with `NEEDS_RESET`, recovery, and finally prints
the engine's counters. Last run on the RTL: `reports/cosim_demo_rtl.log`.

## Rust wrapper (`host/rust`)
A thin, memory-safe wrapper (`SoftDevice` → `Hypervisor` + `Driver<'a>`, typed `Error`, lifetimes so a driver cannot outlive its device) over the C library through a small handle-based C shim; no external crates. `make rust` runs 5 integration tests (init and refusals, 40 randomised write/read round trips, request errors as answers, a DMA violation, a cyclic chain + recovery) against the software device. The protocol logic stays in C.

## Using it on real hardware (not done)
Implement `sfv_transport_t` over your MMIO/DMA mapping (`mmio_*` = BAR accesses, `mem_*` = access to the DMA-coherent buffer, `wait` =
`usleep`/cpu_relax, `irq_level` = eventfd or NULL). The library already issues the status/feature/queue protocol in the spec's order; ring
writes are performed element-then-index; add the platform's write barrier in `mem_write` where ordering needs it.
