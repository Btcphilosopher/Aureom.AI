# 01 — Architecture and behaviour contract

Primary RTL: `rtl/silicaflux_virtio_engine.sv` (wrapper = `sfv_engine_core` + `sfv_ramdisk`).
Normative reference: the OASIS VirtIO specification (1.x, non-legacy). **Read `CONFORMANCE.md` first for what that means here** —
the OASIS site was not reachable from the build environment, so constants are cross-checked against the Linux UAPI headers and
behaviour is stated clause by clause with its verification status.

## 1. What it is

A synthesizable **virtual-machine I/O acceleration engine** for the SilicaFlux CloudDPU. To a guest VM it is a **virtio-blk**
device on a **virtio-mmio (version 2)** register window with **one split virtqueue** (VIRTIO_F_VERSION_1). The DPU fetches the
guest's requests from guest memory, validates every descriptor, executes them against a **protected backend** (per-domain
partitions of a volatile block store) and publishes completions — with every guest-memory access checked against the permission
table of the function's DMA domain.

```
                    guest (VM driver)                          hypervisor / ControlCore (management plane)
                         │ virtio-mmio v2 (32-bit, 4 KiB / function)        │ mg_* register port
                         ▼                                                  ▼
 ┌──────────────────────────────────────────────────────────────────────────────────────────────────────┐
 │ sfv_engine_core                                                                                      │
 │  sfv_func_regs ×NF   ─ status / features / queue setup / interrupts   ┌──────────── sfv_mgmt ───────┐ │
 │        │ running, queue addrs, kick, reset, irq                       │ windows · partitions · bind │ │
 │        ▼                                                              │ faults · counters · caps    │ │
 │  sfv_queue_ctrl  (round-robin over functions, ONE request at a time)  └───────────┬─────────────────┘ │
 │    ├ poll avail / read head / write used elem + idx / notify                      │ live tables       │
 │    ├ sfv_desc_walker  (chain fetch + validation)                                  ▼                   │
 │    └ sfv_blk_exec     (virtio-blk header / data / status)                                             │
 │        │ one command at a time {target, dir, domain, addr, len}                                       │
 │        ▼                                                                                              │
 │  sfv_gdma  ── stage buffer (64 B) ── sfv_beat_mover (byte-exact, unaligned, partial beats)            │
 │        │ chunk check ──► sfv_domain_adapter  (table model | external IOMMU)  ◄── per-beat guard      │
 └────────┼──────────────────────────────────────────────┼───────────────────────────────────────────────┘
          │ gm_*  SFB2 master (guest memory)             │ bk_* SFB2 master + domain sideband
          ▼ (PCIe endpoint / AXI via sfd_sfb2_to_axi4)   ▼
                                                  sfv_ramdisk  (protected backend: partition per domain)
```

## 2. Modules

| module | job |
|---|---|
| `silicaflux_virtio_pkg` | every VirtIO constant, layout offset, fault code and register offset; single source of truth (host ABI is generated from it) |
| `sfv_func_regs` | virtio-mmio v2 register block of one function: status protocol, features, queue setup validation, interrupts, reset handshake |
| `sfv_queue_ctrl` | the split-virtqueue controller: poll, head, complete, notify, ownership, fatal handling, arbitration, counters' events |
| `sfv_desc_walker` | descriptor-chain walker/validator (index, cycle, length, flags, indirect, order, fetch faults) |
| `sfv_blk_exec` | virtio-blk executor over the accepted chain (header, framing, data movement, status byte) |
| `sfv_gdma` | the single path to guest memory and backend; stage buffer; chunk check + per-beat guard |
| `sfv_beat_mover` | byte-exact transfer between stage and a port at any byte address (partial first/last beat strobes) |
| `sfv_domain_adapter`, `sfv_win_check` | **domain permission adapter**: window-table model or external IOMMU interface |
| `sfv_mgmt` | management register block (hypervisor only) |
| `sfv_perf` | per-function performance counters |
| `sfv_ramdisk` | the protected backend |

## 3. Protocol decisions (the behaviour contract)

Every line below is a **deliberate decision**, implemented in the RTL, mirrored in the independent testbench model and in the
software device, and exercised by a test (see `VERIFICATION.md`).

### 3.1 Registers and negotiation
* MagicValue `0x74726976`, Version **2**, DeviceID **2** (block) — or **0** while management has not enabled the function.
* Offered features, exactly: `VIRTIO_F_VERSION_1`, `VIRTIO_BLK_F_SEG_MAX`, `VIRTIO_BLK_F_BLK_SIZE`, `VIRTIO_BLK_F_RO` (only when
  the function is configured read-only), `VIRTIO_F_ACCESS_PLATFORM` (only in the external-IOMMU build). **Nothing else, ever.**
  Not offered and not implemented: packed rings, indirect descriptors, EVENT_IDX, IN_ORDER, multiqueue, FLUSH, DISCARD,
  WRITE_ZEROES, SIZE_MAX, notification data, ring reset.
* `FEATURES_OK` is granted only if the driver's accepted set ⊆ offered set **and** contains `VERSION_1`; otherwise the bit reads
  back clear (spec 3.1.1 step 6). Features are frozen once FEATURES_OK is set.
* Status is monotonic (a driver can only set bits; clearing is a reset). `DRIVER_OK` needs `FEATURES_OK`. `NEEDS_RESET` (0x40) is
  set by the device only; after it, only `FAILED` can still be set. A write of 0 resets.
* **Reset** stops the function at once, aborts any work for it at the next beat boundary, and clears everything when the engine
  acknowledges. `Status` keeps reading its **old non-zero value until then**, so a driver polling for 0 cannot observe "reset done"
  while a DMA beat of the function is still in flight.
* **Queue setup**: `QueueNum`/address registers are accepted only while the queue is not ready. `QueueReady = 1` is accepted only
  for a legal geometry: power-of-two size ≤ QueueNumMax, desc table 16-byte, available ring 2-byte, used ring 4-byte aligned, each
  area wholly inside the guest address space (`2^ADDR_WIDTH`). Otherwise it reads back 0.
* Interrupts: `InterruptStatus` bit 0 = used-buffer notification, bit 1 = configuration change (set with NEEDS_RESET);
  `InterruptACK` clears the written bits; the line is `|InterruptStatus`.

### 3.2 Queue processing (one request at a time, per function round robin)
1. **Poll** `avail {flags, idx}` (4 bytes). `outstanding = (idx − last_avail) mod 2^16`. `> queue size` → **fatal** `AVAIL_OVERRUN`;
   `0` → nothing to do. A *full* ring (`outstanding == size`) is legal.
2. **Head** = `ring[last_avail mod size]`; `≥ size` → fatal `BAD_HEAD`.
3. **Walk** (see 3.3). 4. **Execute** (see 3.4).
5. **Complete**: write `used.ring[used_idx mod size] = {id = head, len}`, **wait for the write to be acknowledged**, *then* write
   `used.idx = used_idx + 1` and wait for that too. A used entry is therefore never visible before the request (data **and**
   status) is complete, and the index never advances before its entry is in memory.
6. **Notify**: re-poll the available ring (the next iteration's step 1); if `avail.flags & NO_INTERRUPT` the interrupt for the
   completion just published is suppressed, otherwise `INT_VRING` is raised. `used.flags` (NO_NOTIFY) is never written; EVENT_IDX is
   not offered.
* **Ownership**: exactly one head is owned by the device between steps 2 and 5; the used id is always that head. (A deep
  multi-outstanding ownership bitmap belongs with out-of-order execution — a later extension.)
* Nothing is consumed or notified before DRIVER_OK; a doorbell that arrives while a poll is in flight is **never lost** (pend is
  cleared when a poll *starts*; this was a real bug, found by the co-simulation — `VERIFICATION.md` §5).

### 3.3 Descriptor validation (before anything is executed)
| check | fault |
|---|---|
| head / `next` ≥ queue size | `BAD_HEAD` / `BAD_NEXT` |
| a descriptor visited twice in one chain (bitmap) | `CYCLE` |
| more than `MAX_CHAIN` descriptors | `CHAIN_TOO_LONG` |
| any flag bit other than NEXT / WRITE | `BAD_FLAGS` |
| `VIRTQ_DESC_F_INDIRECT` | `INDIRECT` |
| device-readable descriptor after a device-writable one | `ORDER` |
| descriptor fetch refused / failed | `DMA_DENIED` / `GUEST_BUS` |
| no device-writable byte; fewer than 16 device-readable bytes | `NO_STATUS`; `SHORT_HDR` |

A **fatal** fault completes **nothing**: no used entry is written, the function gets `NEEDS_RESET` + a configuration-change
interrupt and is not served again until the driver resets it. The fault code and count are visible to management. Zero-length
descriptors are legal (counted, checked, no segment); descriptor framing is not assumed (a header may be split, header and data may
share a descriptor).

### 3.4 The virtio-blk executor
Streams: RS = device-readable segments concatenated, WS = device-writable ones. Header = first 16 bytes of RS; **status = last byte
of WS**. `T_IN`: RS must be exactly the header, data = WS minus the status byte. `T_OUT`: WS must be exactly the status byte, data =
RS after the header. A **device-readable buffer is never written.** Request-level errors are answered through the status byte
(`IOERR`: data length 0 or not a multiple of 512, wrong framing for the type, write on a read-only function, sector range beyond
capacity — exact 64-bit arithmetic, any refused/failed header or data access; `UNSUPP`: any other request type) and the request
completes normally. **`used.len` = bytes actually written into device-writable buffers** = data delivered + the status byte
(`1` for OUT and for every error before data moved). A refused/failed **status write** or **used-ring write** is fatal.
Data moves in chunks of `min(stage, bytes left in segment, bytes left in request, bytes to the next 4 KiB)`; each chunk is complete
before the next starts and before the status byte is written.

### 3.5 Tenant and DMA protection
* A **domain ID never replaces a permission check.** The function→domain binding is set by management; the guest cannot write it.
  The domain only selects which table is consulted; **default deny** (domain disabled / no window → nothing granted).
* Every guest-memory access is checked **twice**: a *chunk check* before the chunk starts (whole range inside **one** window with the
  right permission — R for a read, W for a write; no wrap, inside `2^ADDR_WIDTH`) and a *per-beat guard* on every bus beat (inside the
  range granted for the chunk **and** inside a window of the **live** table). A window revoked mid-transfer stops it at the next beat
  the engine presents (a beat already presented cannot be withdrawn — SFB2 R2).
* Windows must be beat-aligned and non-empty (management refuses otherwise), so every beat that touches a granted byte lies wholly
  inside the window: a read never reaches a byte outside it.
* **Isolation violations** are counted; with the per-function `quarantine` flag the function is stopped (published IOERR, then
  NEEDS_RESET) after the first one. A data-path violation otherwise completes with IOERR and the function keeps running.
* **Backend**: the engine never names an absolute store address — it sends `{domain, partition-relative address}`; the store adds
  the base and refuses (error response, no side effect) anything outside the domain's partition, for a disabled domain, or while the
  partition is being scrubbed. Partitions of enabled domains never overlap; a partition is **zeroed (scrub)** on request so a new
  owner cannot read the previous owner's bytes.
* **Optional external IOMMU** (`EXT_IOMMU = 1`): chunk checks are forwarded to an IOMMU (`iommu_req_*`/`iommu_rsp_*`), which checks
  permission and translates; the engine never asks about a range crossing a 4 KiB boundary, so one answer covers one page. The
  per-beat guard enforces the translated range. `VIRTIO_F_ACCESS_PLATFORM` is offered only in this build.

### 3.6 Counters (per function, 32 bit)
Descriptors walked (accepted chains), requests completed, request-data bytes read/written, metadata bytes, interrupts raised /
suppressed, violations, fatal faults, request errors, doorbells, queue-stall cycles, bus-stall cycles, queue occupancy (sum, samples,
max), completion latency (sum/min/max: head fetch → used.idx write acknowledged), descriptor-walk latency (sum/max/count), busy
cycles. Defined precisely in `rtl/pkg/silicaflux_virtio_pkg.sv` (`PC_*`).

## 4. Parameters

| parameter | default | meaning |
|---|---|---|
| `NUM_FUNCS` / `NF` | 1 | virtio-blk functions (1…8), one request virtqueue each — the multi-tenant option |
| `NUM_DOMAINS` / `ND` | 2 | DMA domains (1…8) |
| `NUM_WIN` / `NW` | 4 | windows per domain |
| `MAX_QSZ` | 64 | QueueNumMax (power of two, 2…4096; the spec allows 32768, but the cycle-detection bitmap has `MAX_QSZ` flops — larger queues are refused at elaboration) |
| `MAX_CHAIN` | 8 | descriptors per chain (≥ 3); `seg_max = MAX_CHAIN − 2` |
| `STAGE_BYTES` | 64 | stage buffer (power of two, 16…4096) |
| `ADDR_WIDTH` / `DATA_WIDTH` | 48 / 64 | guest address width / SFB2 data width (32, 64, 128) |
| `STORE_BYTES` | 65536 | RAM-disk size |
| `EXT_IOMMU` | 0 | table model (0) or external IOMMU (1) |

## 5. Ports and timing conventions
All SFB2-shaped ready/valid, single clock `clk`, active-low asynchronous `rst_n`. `gm_*`/`bk_*`: one outstanding request, payload held
until accepted, response never in the acceptance cycle, error and write responses carry `rdata = 0` (the vendored DataFabric protocol
checker is attached to both ports in every simulation). Full tables in `INTERFACES.md`.
