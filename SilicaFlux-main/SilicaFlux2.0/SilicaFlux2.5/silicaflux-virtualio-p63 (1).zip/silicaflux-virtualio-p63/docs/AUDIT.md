# 00 — Repository audit (Project 63, VirtualIO)

Audited: `btcphilosopher/Aureom.AI`, branch `claude/clever-hamilton-3q6laj`. As in earlier SilicaFlux projects the RTL lives almost
entirely inside zip archives under `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`. The archives relevant to this brief were
extracted read-only into a scratch directory and read; nothing in them was modified or vendored except one verification module (below).

## 1. What exists

| Area named in the brief | Found | What it means for VirtualIO |
|---|---|---|
| **CloudDPU** | `silicaflux-clouddpu-p61.zip` — synthesizable DPU: command queues + processor, CloudDMA, per-tenant windows and SRAM partitions, per-beat guards, counters, telemetry, firmware on the ControlCore. README: *"VirtualIO … interfaces are real; the host side is a testbench model"* — **no virtio ring parsing, no IOMMU, no SR-IOV, no PCIe**. | the integration target. Its host-memory port is **SFB2** (`hm_*`), single outstanding, with a ready-made SFB2→AXI4 bridge (`integration/sfd_sfb2_to_axi4.sv`). VirtualIO's guest-memory master uses the **same SFB2 shape**, so the same bridge attaches it to AXI / a PCIe endpoint. |
| **ControlCore** | `silicaflux-controlcore.zip` — RV32IM_Zicsr management CPU, mailbox, SFB2 crossbar, 8 KiB boot ROM, "accelerator register port" pages. | the natural owner of the `mg_*` management port (hypervisor role). Not instantiated here. |
| **DMA** | no standalone cloud DMA besides P61's `sfd_clouddma` (host↔SRAM with guards, one outstanding); `hpc_dma_adapter` (needs the M04 scratchpad protocol), StorageCore `sfs_dma`, DataFabric DMA engines. | VirtualIO needs a *byte-exact, unaligned, partial-beat* mover with a guard on every beat and a stage buffer shared with the ring logic. P61's CloudDMA moves whole jobs host↔SRAM and cannot read a descriptor or a 2-byte ring index. A new mover (`sfv_beat_mover`) was written; P61's `sfd_win_check` window semantics (`{base,size,R,W}`, one-window rule, 65-bit arithmetic, len 0 never matches) are mirrored. |
| **Memory management** | P61 tenant context (SRAM partitions, scrub-on-assignment, overlap check); DataFabric SFB2 protocol rules R1–R12; the SRAM wrapper library. | the model for the backend's partitioning, scrub and overlap rules (`sfv_ramdisk`). |
| **PCIe interfaces** | HostLink P25 (`silicaflux-hostlink-project25.zip`): BAR ABI, NVMe-style queues, AXI endpoint boundary, **simulated PCIe host backend with a C driver library**; *"no PCIe protocol logic, physical PCIe blocked"*. NVMe HostCore P57: NVMe front end with a transaction-level PCIe model. | the **existing host runtime pattern** this project follows: a C driver library with interchangeable backends (simulation / hardware) and a Verilator co-simulation. No PCIe endpoint exists, so the transport here is simulated (software device + Verilated RTL). |
| **StorageCore** | P51 (storage SoC: firmware FTL on the ControlCore, ECC SRAM, ONFI-style NAND model; *not NVMe/ONFI-compliant, no GC*), P55 BufferCore, P56 FlashMap, P59 SecureStore. | **not a usable backend**: it needs firmware, a NAND model and a PCIe model, and P61 lists `ENABLE_STORAGE` as BLOCKED. |
| **NetworkCore** | **does not exist.** P61 has only `sfd_packetcore_tadapter`, a *test adapter* (PASS / XOR32 / BSWAP32 + CRC) that "parses no packets". No MAC/PHY. | no real virtio-net backend is possible. |
| **Existing host runtime** | HostLink's `sfh_driver.c` + `sfh_sim.cpp` (Verilator co-simulation). | reused as a *pattern*, not as code (its ABI is NVMe-style queues, not VirtIO). |
| **IOMMU / SR-IOV / virtio** | HostLink and NVMe contain a *simulated* IOMMU in the PCIe model; no RTL IOMMU; no SR-IOV; **no VirtIO anywhere** (grep over all extracted trees). | the permission-table model is implemented here; the external IOMMU is an *interface* with a behavioural model in the testbench. |

## 2. Decisions

1. **Device = virtio-blk (device ID 2), not virtio-net.** The brief says to pick by the *actual available backend*. There is no
   network backend at all and the storage fabric is blocked, so neither "real" device is possible. What *can* be real and protected is a
   **block store carved into per-domain partitions** (the P61 tenant-partition idea). virtio-blk over it exercises the full split-ring
   feature set the brief lists — descriptor chains, device-writable buffers, used length, status byte, request framing — with a backend
   whose semantics (read-after-write) an independent model can check exactly. It is **volatile** and says so everywhere.
2. **"One queue pair"** is implemented as **one request virtqueue** (one available/used ring pair): virtio-blk has exactly one queue
   without `VIRTIO_BLK_F_MQ`. Multi-tenant operation is provided as **NF functions** (each one virtio device with one queue, bound to
   one DMA domain), enabled by a parameter and regression-tested only *after* the single-function suite passed. Multi-queue per device
   and packed rings are **not** implemented (the brief says: only after formal/regression testing — and they are not needed for v1).
3. **Register interface = the official virtio-mmio version 2 layout** (spec 4.2), not an invented one. Its `Version` register is the
   "versioned feature register interface". A separate **management port** carries what a guest must never touch.
4. **Guest-memory port = SFB2** (the DPU's own bus), single outstanding.
5. **Backend interface = SFB2 + domain sideband**, so the RAM disk can later be replaced by an adapter to the DPU's SRAM fabric.

## 3. What was reused, what is new

* **Vendored unmodified (verification only):** `vendor/sfb_protocol_checker.sv`, the DataFabric SFB2 port monitor (SHA-256
  `de6bd74c…a324980`), attached to both master ports in every simulation.
* **Reused as a design reference (not copied):** P61 window semantics, tenant-partition/scrub/overlap rules, SFB2 port rules.
* **Everything else is new:** package, register block, queue controller, descriptor walker, executor, domain adapter, mover, RAM disk,
  management block, counters; the C host library; the software device; the SV system testbench, golden model, unit bench; the
  co-simulation harness; the scripts.

## 4. Gaps found in the repository that this project does not close
* No PCIe endpoint / IOMMU / SR-IOV / NetworkCore / FPGA board or silicon result anywhere in the repository — none here either.
* The OASIS VirtIO text could not be fetched in this session (host denied by the network policy); see `CONFORMANCE.md`.
* No licence file in the repository (same finding as P61): an owner must add one before external distribution.
