// =============================================================================
// tb_model.svh -- testbench view of the management configuration, bus monitors, management tasks (VERIFICATION ONLY)
// Included inside module tb_virtio.
// =============================================================================

  // ------------------------------------------------------------------ the testbench's OWN copy of what management configured
  reg        t_dom_en  [0:7];
  reg [31:0] t_pbase   [0:7];
  reg [31:0] t_psize   [0:7];
  reg [63:0] t_wbase   [0:63];
  reg [63:0] t_wsize   [0:63];
  reg        t_wr_r    [0:63];
  reg        t_wr_w    [0:63];
  reg        t_wr_v    [0:63];
  reg        t_fen     [0:7];
  reg        t_fro     [0:7];
  reg        t_fquar   [0:7];
  int        t_fdom    [0:7];
  reg [63:0] t_fcap    [0:7];

  task automatic tb_model_reset;
    integer i;
    begin
      for (i = 0; i < 8; i++) begin
        t_dom_en[i] = 0; t_pbase[i] = 0; t_psize[i] = 0;
        t_fen[i] = 0; t_fro[i] = 0; t_fquar[i] = 0; t_fdom[i] = 0; t_fcap[i] = 0;
      end
      for (i = 0; i < 64; i++) begin t_wbase[i] = 0; t_wsize[i] = 0; t_wr_r[i] = 0; t_wr_w[i] = 0; t_wr_v[i] = 0; end
    end
  endtask

  // ------------------------------------------------------------------ independent permission oracle (byte ranges, 65-bit safe)
  function automatic bit tb_perm(input int d, input [63:0] a, input [63:0] n, input bit wr);
    integer w;
    reg [64:0] aend, wend;
    bit ok;
    begin
      ok = 1'b0;
      aend = {1'b0, a} + {1'b0, n};
      if (t_dom_en[d] && n != 0 && aend <= (65'd1 << AW)) begin
        for (w = 0; w < NW; w++) begin
          wend = {1'b0, t_wbase[d*NW + w]} + {1'b0, t_wsize[d*NW + w]};
          if (t_wr_v[d*NW + w] && a >= t_wbase[d*NW + w] && aend <= wend && (wr ? t_wr_w[d*NW + w] : t_wr_r[d*NW + w]))
            ok = 1'b1;
        end
      end
      tb_perm = ok;
    end
  endfunction

  // ------------------------------------------------------------------ bus monitor: every guest beat must be permitted
  int  mon_viol = 0;
  int  mon_beats = 0;
  reg  mon_enable = 1'b1;

  // per-function history of submitted requests, used to check completion ordering (see tb_driver.svh)
  reg        h_v    [0:2047];          // [f*256 + seq%256]
  reg [15:0] h_head [0:2047];
  reg [63:0] h_sta  [0:2047];          // address of the status byte
  reg [63:0] h_used_idx_addr [0:7];
  reg [63:0] h_used_ring_addr[0:7];
  int        h_qsz  [0:7];
  reg        h_armed [0:7];
  int        h_order_viol = 0;
  int        h_idx_writes = 0;

  task automatic mon_beat(input [63:0] a, input bit wr, input [DW/8-1:0] strb);
    int cf, d, f, seq;
    reg [63:0] ia, ra;
    reg [31:0] id32;
    integer i;
    bit any;
    begin
      mon_beats++;
      if (mon_enable && EXT == 0) begin
        cf = int'(dut.u_qc.cf_q);
        d  = t_fdom[cf];
        any = 1'b0;
        for (i = 0; i < BW; i++) if (!wr || strb[i]) any = 1'b1;
        if (any && !tb_perm(d, a, BW, wr)) begin
          mon_viol++;
          if (mon_viol <= 20) $display("  [MON] t=%0t forbidden guest beat: func %0d dom %0d %s addr 0x%0h strb 0x%0h", $time, cf, d, wr ? "WRITE" : "READ", a, strb);
        end
      end
      // completion ordering: when the used.idx word is written, the request's status byte and used element must already be in memory
      if (wr) begin
        for (f = 0; f < NF; f++) begin
          if (h_armed[f]) begin
            ia = h_used_idx_addr[f];
            if (a == {ia[63:3], 3'b000} && strb[ia[2:0]]) begin   // the beat that carries used.idx[7:0]
              h_idx_writes++;
              seq = int'(gm_get16(ia));                          // old idx value (the beat has not been applied yet in the memory model)
              if (h_v[f*256 + (seq % 256)]) begin
                // the status byte must have left its 0xFF pre-fill
                if (gmem[h_sta[f*256 + (seq % 256)]] === 8'hFF) begin
                  h_order_viol++;
                  if (h_order_viol <= 10) $display("  [MON] t=%0t func %0d: used.idx advanced before the status byte of request %0d was written (head %0d, status addr 0x%0h, qsz %0d)",
                                                    $time, f, seq, h_head[f*256 + (seq % 256)], h_sta[f*256 + (seq % 256)], h_qsz[f]);
                end
                // the used element must be complete (id = head, no poison left)
                ra = h_used_ring_addr[f] + 8 * (seq % h_qsz[f]);
                id32 = {gmem[ra+3], gmem[ra+2], gmem[ra+1], gmem[ra]};
                if (id32 !== {16'd0, h_head[f*256 + (seq % 256)]} || {gmem[ra+7], gmem[ra+6], gmem[ra+5], gmem[ra+4]} === 32'hFFFF_FFFF) begin
                  h_order_viol++;
                  if (h_order_viol <= 10) $display("  [MON] t=%0t used.idx advanced before used element %0d was complete (id=0x%0h)", $time, seq, id32);
                end
              end
            end
          end
        end
      end
    end
  endtask

  function automatic [15:0] gm_get16(input [63:0] a);
    begin gm_get16 = {gmem[a+1], gmem[a]}; end
  endfunction
  function automatic [31:0] gm_get32(input [63:0] a);
    begin gm_get32 = {gmem[a+3], gmem[a+2], gmem[a+1], gmem[a]}; end
  endfunction
  task automatic gm_put16(input [63:0] a, input [15:0] v);
    begin gmem[a] = v[7:0]; gmem[a+1] = v[15:8]; end
  endtask
  task automatic gm_put32(input [63:0] a, input [31:0] v);
    begin gmem[a] = v[7:0]; gmem[a+1] = v[15:8]; gmem[a+2] = v[23:16]; gmem[a+3] = v[31:24]; end
  endtask
  task automatic gm_put64(input [63:0] a, input [63:0] v);
    begin gm_put32(a, v[31:0]); gm_put32(a+4, v[63:32]); end
  endtask

  // ------------------------------------------------------------------ management programming (updates DUT and the TB's own copy)
  // register offsets are re-stated here on purpose (independent of the package); make check-abi compares them with the package
  localparam [11:0] M_FAULT = 12'h020, M_FAULT_IE = 12'h024, M_DOM_SEL = 12'h040, M_WIN_SEL = 12'h044,
                    M_WIN_BASE_LO = 12'h048, M_WIN_BASE_HI = 12'h04c, M_WIN_SIZE_LO = 12'h050, M_WIN_SIZE_HI = 12'h054,
                    M_WIN_CTL = 12'h058, M_DOM_CTL = 12'h060, M_DOM_PBASE = 12'h064, M_DOM_PSIZE = 12'h068,
                    M_DOM_STATUS = 12'h06c, M_FUNC_SEL = 12'h080, M_FUNC_DOMAIN = 12'h084, M_FUNC_CAP_LO = 12'h088,
                    M_FUNC_CAP_HI = 12'h08c, M_FUNC_CTL = 12'h090, M_FUNC_STATUS = 12'h094, M_FUNC_FCNT = 12'h098,
                    M_FUNC_QSTATE = 12'h0a0, M_PERF_SEL = 12'h0c0, M_PERF_DATA = 12'h0c4, M_PERF_CTL = 12'h0c8;

  // window: r/w permission, v = valid.  expect_err: the management port must refuse
  task automatic cfg_win(input int d, input int w, input [63:0] base, input [63:0] size, input bit r, input bit wp, input bit v, input bit expect_err);
    begin
      mg_wr(M_DOM_SEL, d, 1'b0);
      mg_wr(M_WIN_SEL, w, 1'b0);
      mg_wr(M_WIN_BASE_LO, base[31:0], 1'b0);
      mg_wr(M_WIN_BASE_HI, base[63:32], 1'b0);
      mg_wr(M_WIN_SIZE_LO, size[31:0], 1'b0);
      mg_wr(M_WIN_SIZE_HI, size[63:32], 1'b0);
      mg_wr(M_WIN_CTL, {29'd0, v, wp, r}, expect_err);
      if (!expect_err) begin
        t_wbase[d*NW + w] = base; t_wsize[d*NW + w] = size; t_wr_r[d*NW + w] = r; t_wr_w[d*NW + w] = wp; t_wr_v[d*NW + w] = v;
      end
    end
  endtask

  task automatic wait_scrub(input int d);
    reg [31:0] v;
    int guard;
    begin
      guard = 0;
      mg_wr(M_DOM_SEL, d, 1'b0);
      mg_rd(M_DOM_STATUS, v);
      while (v[1] && guard < 100000) begin mg_rd(M_DOM_STATUS, v); guard++; end
      check(guard < 100000, "scrub finishes");
    end
  endtask

  // domain: enable + backend partition (+ scrub).  Waits for a scrub to finish.
  task automatic cfg_dom(input int d, input bit en, input [31:0] pbase, input [31:0] psize, input bit scrub, input bit expect_err);
    begin
      mg_wr(M_DOM_SEL, d, 1'b0);
      mg_wr(M_DOM_PBASE, pbase, 1'b0);
      mg_wr(M_DOM_PSIZE, psize, 1'b0);
      mg_wr(M_DOM_CTL, {30'd0, scrub, en}, expect_err);
      if (!expect_err) begin
        if (scrub) begin
          if (en) ref_zero_disk(pbase, psize);                  // the new partition is zeroed before it is enabled
          else    ref_zero_disk(t_pbase[d], t_psize[d]);        // teardown: the old partition is zeroed
          wait_scrub(d);
        end
        t_dom_en[d] = en;
        if (en) begin t_pbase[d] = pbase; t_psize[d] = psize; end
      end
    end
  endtask

  task automatic cfg_func(input int f, input bit en, input int dom, input [63:0] cap, input bit ro, input bit quar, input bit expect_err);
    begin
      mg_wr(M_FUNC_SEL, f, 1'b0);
      mg_wr(M_FUNC_DOMAIN, dom, 1'b0);
      mg_wr(M_FUNC_CAP_LO, cap[31:0], 1'b0);
      mg_wr(M_FUNC_CAP_HI, cap[63:32], 1'b0);
      mg_wr(M_FUNC_CTL, {29'd0, quar, ro, en}, expect_err);
      if (!expect_err) begin
        t_fen[f] = en; t_fro[f] = ro; t_fquar[f] = quar; t_fdom[f] = dom; t_fcap[f] = cap;
      end
    end
  endtask

  // standard layout: domain d owns guest window `dom_base(d)` .. +0x10000 (read/write), partition d of the store
  function automatic [63:0] dom_base(input int d);
    begin dom_base = (d == 0) ? 64'h0000_1000 : (d == 1) ? 64'h0002_0000 : 64'h0003_0000; end
  endfunction
  localparam [63:0] DOM_SIZE = 64'h0000_F000;

  // standard configuration: ND domains with one RW window and one partition; NF functions bound round-robin to domains
  task automatic cfg_standard(input bit ro_f0, input bit quar);
    integer d, f;
    begin
      for (d = 0; d < ND && d < 3; d++) begin
        cfg_win(d, 0, dom_base(d), DOM_SIZE, 1'b1, 1'b1, 1'b1, 1'b0);
        cfg_dom(d, 1'b1, d * PART, PART, 1'b1, 1'b0);
      end
      for (f = 0; f < NF; f++)
        cfg_func(f, 1'b1, f % ((ND < 3) ? ND : 3), CAPSEC, (f == 0) ? ro_f0 : 1'b0, quar, 1'b0);
    end
  endtask

  // ------------------------------------------------------------------ disk reference and idle detection
  reg [7:0] refdisk [0:STORE-1];
  function automatic [7:0] dut_disk_byte(input int a);
    reg [DW-1:0] w;
    begin
      w = store.mem[a / BW];
      dut_disk_byte = w[(a % BW)*8 +: 8];
    end
  endfunction

  // quiescent: queue controller idle, no work pending, guest DMA idle, for a number of consecutive cycles
  task automatic wait_idle(input int max_cycles);
    int quiet, n;
    begin
      quiet = 0; n = 0;
      while (quiet < 40 && n < max_cycles) begin
        @(posedge clk);
        n++;
        if (dut.u_qc.st_q == 5'd0 && dut.u_qc.pend_q == '0 && !dut.u_gdma.busy_o && !gm_pend_v && !gm_rsp_v_q) quiet++;
        else quiet = 0;
      end
      check(n < max_cycles, "device reaches quiescence (no hang)");
    end
  endtask
