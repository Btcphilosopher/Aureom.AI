// =============================================================================
// tb_tests.svh -- test scenarios (VERIFICATION ONLY).  Included inside module tb_virtio.
// Every scenario starts from a hardware reset, a freshly randomised guest memory and a fresh management configuration.
// =============================================================================

  int t_qs = 16;                          // queue size used by the fault-injection scenarios
  reg [7:0] out_copy [0:16383];          // what the driver wrote with the last OUT request(s): expected disk contents (independent of the model)

  task automatic hw_reset;
    begin
      rst_n = 1'b0;
      mmio_req_valid = 1'b0; mg_req_valid = 1'b0;
      repeat (4) @(posedge clk);
      #1 rst_n = 1'b1;
      repeat (3) @(posedge clk);
    end
  endtask

  task automatic init_arrays;
    integer f, i;
    begin
      tb_model_reset;
      for (f = 0; f < 8; f++) begin
        q_up[f] = 0; r_dead[f] = 0; r_fault[f] = 0; r_kick[f] = 0; r_la[f] = 0; r_ui[f] = 0;
        r_nreq[f] = 0; r_ndesc[f] = 0; r_nviol[f] = 0;
        d_irq_rises[f] = 0; h_armed[f] = 0; d_up[f] = 0;
        h_used_idx_addr[f] = 0; h_used_ring_addr[f] = 0; h_qsz[f] = 1;
        drv_state_reset_safe(f);
      end
      for (i = 0; i < 2048; i++) begin h_v[i] = 0; h_head[i] = 0; h_sta[i] = 0; h_nd[i] = 0; end
      for (i = 0; i < STORE; i++) refdisk[i] = 8'h00;
      irq_prev = '0;
    end
  endtask
  task automatic drv_state_reset_safe(input int f);
    begin
      d_aidx[f] = 0; d_seq[f] = 0; d_reaped[f] = 0; d_slot[f] = 0; d_outd[f] = 0; d_up[f] = 0; d_buf[f] = 0; d_qsz[f] = 1;
      d_desc[f] = 0; d_avail[f] = 0; d_used[f] = 0;
    end
  endtask

  task automatic fill_gmem_random;
    integer i;
    begin
      for (i = 0; i < GM_BYTES; i++) gmem[i] = rnd32(0);
    end
  endtask

  task automatic begin_test(input string name);
    integer f;
    begin
      test_no++;
      cur_test = name;
      $display("[%0d] %s", test_no, name);
      gate_gm_pct = 8'd100; dly_gm_max = 8'd0; gate_bk_pct = 8'd100; dly_bk_max = 8'd0;
      err_lo = 0; err_hi = 0;
      hw_reset;
      init_arrays;
      ref_snap_taken = 1'b0;
      fill_gmem_random;
      // the disk survives a hardware reset (no reset on the RAM), so mirror it
      for (f = 0; f < STORE; f++) refdisk[f] = dut_disk_byte(f);
      apply_stall(STALL);
    end
  endtask

  task automatic apply_stall(input int level);
    begin
      case (level)
        0: begin gate_gm_pct = 100; dly_gm_max = 0; gate_bk_pct = 100; dly_bk_max = 0; end
        1: begin gate_gm_pct = 60;  dly_gm_max = 3; gate_bk_pct = 70;  dly_bk_max = 2; end
        default: begin gate_gm_pct = 25; dly_gm_max = 9; gate_bk_pct = 35; dly_bk_max = 7; end
      endcase
    end
  endtask

  // direct expectation helpers (do not use the model)
  task automatic expect_used(input int f, input int k, input int id, input int len, input string what);
    begin
      check_eq(used_id(f, k), id, {what, ": used.id"});
      check_eq(used_len(f, k), len, {what, ": used.len"});
    end
  endtask

  task automatic std_up(input int f, input int qsz);
    begin
      drv_init(f, qsz, 64'd0, 64'd0);
      check(init_ok, "driver init reaches DRIVER_OK");
    end
  endtask

  // ==================================================================== T1: basic
  task automatic t_basic;
    reg [31:0] v;
    integer i;
    begin
      begin_test("basic: init, write 1 sector, read it back");
      cfg_standard(1'b0, 1'b0);
      std_up(0, 16);
      // register readbacks of the finished initialisation
      mmio_rd(0, R_VENDOR_ID, v);     check_eq(v, 32'h53464C58, "VendorID placeholder");
      mmio_rd(0, R_CFG_CAP_LO, v);    check_eq(v, CAPSEC, "capacity (sectors) low word");
      mmio_rd(0, R_CFG_CAP_HI, v);    check_eq(v, 0, "capacity high word");
      mmio_rd(0, R_CFG_SEG_MAX, v);   check_eq(v, MAXCH - 2, "seg_max");
      mmio_rd(0, R_CFG_BLK_SIZE, v);  check_eq(v, 512, "blk_size");
      mmio_rd(0, R_STATUS, v);        check_eq(v, 32'h0F, "status = ACK|DRIVER|FEATURES_OK|DRIVER_OK");
      submit_blk(0, 32'd1, 64'd3, 512, 0, 1'b1);                 // OUT sector 3
      for (i = 0; i < 512; i++) out_copy[i] = gmem[last_data + i];
      drv_wait_used(0, 1, 40000);
      expect_used(0, 0, last_head, 1, "OUT");
      check_eq(gmem[last_sta], 0, "OUT status OK");
      check_eq(used_idx_mem(0), 1, "used.idx");
      ref_finish("basic/OUT", 20000);
      for (i = 0; i < 512; i++) check_eq(dut_disk_byte(3*512 + i), out_copy[i], "disk holds the written sector");
      submit_blk(0, 32'd0, 64'd3, 512, 0, 1'b1);                 // IN sector 3
      drv_wait_used(0, 2, 40000);
      expect_used(0, 1, last_head, 513, "IN");
      check_eq(gmem[last_sta], 0, "IN status OK");
      for (i = 0; i < 512; i++) check_eq(gmem[last_data + i], out_copy[i], "read back equals what was written");
      ref_finish("basic/IN", 20000);
      check(d_irq_rises[0] >= 1, "interrupt raised for completions");
    end
  endtask


  // ---- helpers shared by the scenarios ------------------------------------------------------------------------------
  task automatic put_hdr(input [63:0] a, input [31:0] typ, input [63:0] sector);
    begin gm_put32(a, typ); gm_put32(a + 4, 32'd0); gm_put64(a + 8, sector); end
  endtask

  // build one custom chain from explicit descriptors, commit it, publish it (head = first slot); optional history entry
  task automatic req_custom(input int f, input bit hist, input [63:0] sta);
    int head;
    begin
      head = c_slot[0];
      chain_commit(f);
      publish_head(f, head);
      if (hist) hist_add(f, head, sta, c_n);
      last_head = head;
    end
  endtask

  // standard 3-descriptor block request with an explicit expectation; returns after the completion
  task automatic run_blk(input int f, input [31:0] typ, input [63:0] sector, input int nbytes, input int lay,
                         input int exp_status, input int exp_len, input string name);
    int k;
    begin
      k = d_seq[f] + 1;
      submit_blk(f, typ, sector, nbytes, lay, 1'b1);
      drv_wait_used(f, k, 200000);
      check_eq(gmem[last_sta], exp_status, {name, ": status byte"});
      check_eq(used_id(f, k - 1), last_head, {name, ": used.id = head"});
      check_eq(used_len(f, k - 1), exp_len, {name, ": used.len"});
      ref_finish(name, 100000);
    end
  endtask

  task automatic get_fstate(input int f, output [31:0] st);
    begin mg_wr(M_FUNC_SEL, f, 1'b0); mg_rd(M_FUNC_STATUS, st); end
  endtask

  // ==================================================================== T2: layouts and data integrity
  task automatic t_layouts;
    int lay, si, n, sec, k, i;
    int sizes [0:5];
    reg [7:0] exp_b;
    begin
      begin_test("layouts: 5 descriptor layouts x sizes, unaligned buffers, 4 KiB straddle, read-back");
      cfg_standard(1'b0, 1'b0);
      std_up(0, 32);
      sizes[0] = 512; sizes[1] = 1024; sizes[2] = 1536; sizes[3] = 2048; sizes[4] = 4096; sizes[5] = 8192;
      for (lay = 0; lay < 5; lay++) begin
        for (si = 0; si < 6; si++) begin
          n = sizes[si];
          sec = rndr(0, CAPSEC - n / 512);
          k = d_seq[0] + 1;
          submit_blk(0, 32'd1, sec, n, lay, 1'b1);
          for (i = 0; i < n; i++) out_copy[i] = gmem[last_data + i];
          drv_wait_used(0, k, 400000);
          check_eq(gmem[last_sta], 0, "OUT status");
          check_eq(used_len(0, k - 1), 1, "OUT used.len = status byte only");
          ref_finish("layouts/OUT", 100000);
          for (i = 0; i < n; i++) if (dut_disk_byte(sec * 512 + i) !== out_copy[i]) begin check(1'b0, "disk content after OUT"); i = n; end
          k = d_seq[0] + 1;
          submit_blk(0, 32'd0, sec, n, (lay + 1) % 5, 1'b1);
          drv_wait_used(0, k, 400000);
          check_eq(gmem[last_sta], 0, "IN status");
          check_eq(used_len(0, k - 1), n + 1, "IN used.len = data + status");
          for (i = 0; i < n; i++) if (gmem[last_data + i] !== out_copy[i]) begin check(1'b0, "IN data equals written data"); i = n; end
          ref_finish("layouts/IN", 100000);
        end
      end
    end
  endtask

  // ==================================================================== T3: ring wraparound (descriptor slots, ring index, 16-bit index)
  task automatic drv_preset_idx(input int f, input [15:0] v);
    begin
      wait_idle(20000);
      dut.u_qc.la_q[f] = v; dut.u_qc.ui_q[f] = v;
      d_aidx[f] = v; d_seq[f] = int'(v); d_reaped[f] = int'(v);
      gm_put16(d_avail[f] + 2, v); gm_put16(d_used[f] + 2, v);
      r_la[f] = v; r_ui[f] = v;
    end
  endtask

  task automatic t_wrap;
    int b, j, k0;
    begin
      begin_test("wraparound: qsize 4 (ring + descriptor slots), then 16-bit index wrap");
      cfg_standard(1'b0, 1'b0);
      std_up(0, 4);
      for (b = 0; b < 14; b++) begin
        k0 = d_seq[0];
        submit_blk(0, (b % 2) ? 32'd1 : 32'd0, rndr(0, CAPSEC - 1), 512, 1, 1'b0);   // 2 descriptors each, 2 requests fill the table
        submit_blk(0, 32'd1, rndr(0, CAPSEC - 1), 512, 1, 1'b1);
        drv_wait_used(0, k0 + 2, 200000);
        check_eq(used_id(0, k0),     h_head[0*256 + (k0 % 256)],     "wrap: used id of first request");
        check_eq(used_id(0, k0 + 1), h_head[0*256 + ((k0+1) % 256)], "wrap: used id of second request");
        ref_finish("wrap/ring", 200000);
      end
      // 16-bit index wrap: preset all indices to 0xFFFB, then run 10 requests across 0xFFFF -> 0x0000
      drv_preset_idx(0, 16'hFFFB);
      for (b = 0; b < 5; b++) begin
        k0 = d_seq[0];
        submit_blk(0, 32'd1, rndr(0, CAPSEC - 1), 512, 1, 1'b0);
        submit_blk(0, 32'd0, rndr(0, CAPSEC - 1), 512, 1, 1'b1);
        drv_wait_used(0, k0 + 2, 200000);
        ref_finish("wrap/idx16", 200000);
      end
      check_eq(used_idx_mem(0), 16'h0005, "used.idx wrapped through 0xFFFF to 5");
      check_eq(d_aidx[0], 16'h0005, "avail.idx wrapped");
    end
  endtask

  // ==================================================================== T4: queue full / empty / overrun
  task automatic t_full_empty;
    int i, base_irq;
    reg [31:0] st;
    begin
      begin_test("queue empty / full / over-full");
      cfg_standard(1'b0, 1'b0);
      std_up(0, 8);
      // empty: spurious doorbell, nothing may happen
      base_irq = d_irq_rises[0];
      kick(0);
      wait_idle(20000);
      ref_finish("empty", 20000);
      check_eq(used_idx_mem(0), 0, "empty ring: no completion");
      check(d_irq_rises[0] == base_irq, "empty ring: no interrupt");
      get_fstate(0, st);
      check(st[6] == 1'b0, "empty ring: not faulted");
      // full: 8 available entries (= queue size), the same 2-descriptor FLUSH-type request published 8 times (head reuse stress)
      chain_reset;
      begin : build_flush
        reg [63:0] h, sa;
        h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1);
        put_hdr(h, 32'd4, 64'd0); gmem[sa] = 8'hFF;
        chain_add(0, h, 16, 1'b0, 1'b1); chain_add(0, sa, 1, 1'b1, 1'b0);
        chain_commit(0);
        for (i = 0; i < 8; i++) begin publish_head(0, c_slot[0]); h_v[0*256 + (d_seq[0] % 256)] = 1'b0; d_seq[0] = d_seq[0] + 1; d_outd[0] = 0; end
        last_sta = sa;
      end
      kick(0);
      drv_wait_used(0, 8, 400000);
      for (i = 0; i < 8; i++) begin check_eq(used_id(0, i), c_slot[0], "full ring: id"); check_eq(used_len(0, i), 1, "full ring: len"); end
      check_eq(gmem[last_sta], 2, "FLUSH is answered UNSUPP");
      check_eq(used_idx_mem(0), 8, "full ring: 8 completions");
      ref_finish("full", 200000);
      // over-full: avail.idx claims 9 entries more than consumed (> queue size)
      gm_put16(d_avail[0] + 2, d_aidx[0] + 16'd9);
      kick(0);
      wait_idle(100000);
      ref_finish("overrun", 100000);
      get_fstate(0, st);
      check(st[6] == 1'b1, "over-full ring: function stopped (NEEDS_RESET)");
      check_eq(st[15:8], 8'h01, "over-full ring: fault = AVAIL_OVERRUN");
      mmio_rd(0, R_INT_STATUS, st);
      check(st[1] == 1'b1, "NEEDS_RESET raises a configuration-change interrupt");
      check_eq(used_idx_mem(0), 8, "over-full ring: nothing consumed");
    end
  endtask

  // ==================================================================== T5: request-level errors (status byte answers)
  task automatic t_invalid;
    reg [31:0] v;
    reg [63:0] h, d, sa, zr;
    int k, i;
    int tvals [0:7];
    begin
      begin_test("invalid lengths / ranges / types / framing: answered through the status byte");
      cfg_standard(1'b0, 1'b0);
      std_up(0, 32);
      // seed disk with a known pattern so that "unchanged" is meaningful
      run_blk(0, 32'd1, 0, 1024, 0, 0, 1, "seed");
      // invalid data lengths -> IOERR, used.len = 1 (status byte only), disk untouched
      run_blk(0, 32'd1, 1, 100,  0, 1, 1, "OUT len 100");
      run_blk(0, 32'd1, 1, 513,  0, 1, 1, "OUT len 513");
      run_blk(0, 32'd0, 1, 256,  0, 1, 1, "IN len 256");
      run_blk(0, 32'd0, 1, 1023, 0, 1, 1, "IN len 1023");
      run_blk(0, 32'd1, 1, 0,    0, 1, 1, "OUT no data");
      run_blk(0, 32'd0, 1, 0,    0, 1, 1, "IN no data");
      // sector ranges (capacity = CAPSEC sectors)
      run_blk(0, 32'd1, CAPSEC,     512,  0, 1, 1, "OUT sector = capacity");
      run_blk(0, 32'd0, CAPSEC,     512,  0, 1, 1, "IN sector = capacity");
      run_blk(0, 32'd1, CAPSEC - 1, 512,  0, 0, 1, "OUT last sector");
      run_blk(0, 32'd0, CAPSEC - 1, 512,  0, 0, 513, "IN last sector");
      run_blk(0, 32'd1, CAPSEC - 1, 1024, 0, 1, 1, "OUT crossing the end");
      run_blk(0, 32'd0, CAPSEC - 2, 1024, 0, 0, 1025, "IN exactly to the end");
      run_blk(0, 32'd0, CAPSEC - 1, 1024, 0, 1, 1, "IN crossing the end");
      run_blk(0, 32'd1, 64'hFFFF_FFFF_FFFF_FFFF, 512, 0, 1, 1, "OUT sector 2^64-1");
      run_blk(0, 32'd0, 64'h8000_0000_0000_0000, 512, 0, 1, 1, "IN sector 2^63");
      run_blk(0, 32'd0, 64'h0000_0001_0000_0000, 512, 0, 1, 1, "IN sector 2^32");
      // unsupported request types -> UNSUPP, nothing moved
      tvals[0] = 4; tvals[1] = 8; tvals[2] = 2; tvals[3] = 3; tvals[4] = 5; tvals[5] = 11; tvals[6] = 13; tvals[7] = 32'h80000000;
      for (i = 0; i < 8; i++) run_blk(0, tvals[i], 0, 0, 0, 2, 1, "unsupported type");
      run_blk(0, 32'h8000_0001, 0, 512, 0, 2, 1, "BARRIER|OUT is not OUT");
      // GET_ID with a 20-byte writable buffer + status: UNSUPP, buffer untouched
      begin
        k = d_seq[0] + 1;
        submit_blk(0, 32'd8, 0, 20, 0, 1'b1);
        drv_wait_used(0, k, 100000);
        check_eq(gmem[last_sta], 2, "GET_ID -> UNSUPP");
        check_eq(gmem[last_data], 8'hEE, "GET_ID leaves the buffer untouched");
        ref_finish("get_id", 100000);
      end
      // framing violations: data in the wrong direction
      k = d_seq[0] + 1;
      h = alloc_buf(0, 16, 16); d = alloc_buf(0, 512, 8); sa = alloc_buf(0, 1, 1);
      put_hdr(h, 32'd0, 0); gmem[sa] = 8'hFF;                       // IN, but the data is in a DEVICE-READABLE descriptor
      chain_reset; chain_add(0, h, 16, 1'b0, 1'b1); chain_add(0, d, 512, 1'b0, 1'b1); chain_add(0, sa, 1, 1'b1, 1'b0);
      req_custom(0, 1'b1, sa); kick(0);
      drv_wait_used(0, k, 100000);
      check_eq(gmem[sa], 1, "IN with readable data buffer -> IOERR"); check_eq(used_len(0, k - 1), 1, "len 1");
      ref_finish("framing/IN-readable", 100000);
      k = d_seq[0] + 1;
      h = alloc_buf(0, 16, 16); d = alloc_buf(0, 512, 8); sa = alloc_buf(0, 1, 1);
      put_hdr(h, 32'd1, 0); gmem[sa] = 8'hFF;                       // OUT, but the data is DEVICE-WRITABLE (a device must never write it for OUT)
      chain_reset; chain_add(0, h, 16, 1'b0, 1'b1); chain_add(0, d, 512, 1'b1, 1'b1); chain_add(0, sa, 1, 1'b1, 1'b0);
      req_custom(0, 1'b1, sa); kick(0);
      drv_wait_used(0, k, 100000);
      check_eq(gmem[sa], 1, "OUT with writable data buffer -> IOERR"); check_eq(used_len(0, k - 1), 1, "len 1");
      ref_finish("framing/OUT-writable", 100000);
      // zero-length descriptors are legal and contribute nothing (even with a forbidden address: no memory is touched)
      k = d_seq[0] + 1;
      h = alloc_buf(0, 16, 16); d = alloc_buf(0, 512, 8); sa = alloc_buf(0, 1, 1);
      put_hdr(h, 32'd1, 5); gmem[sa] = 8'hFF;
      chain_reset; chain_add(0, h, 16, 1'b0, 1'b1); chain_add(0, 64'h0004_0000, 0, 1'b0, 1'b1); chain_add(0, d, 512, 1'b0, 1'b1);
      if (MAXCH >= 5) chain_add(0, 64'h0004_0000, 0, 1'b1, 1'b1);     // (a 5-descriptor chain needs MAX_CHAIN >= 5)
      chain_add(0, sa, 1, 1'b1, 1'b0);
      req_custom(0, 1'b1, sa); kick(0);
      drv_wait_used(0, k, 100000);
      check_eq(gmem[sa], 0, "OUT with zero-length descriptors -> OK"); check_eq(used_len(0, k - 1), 1, "len 1");
      ref_finish("zero-length", 100000);
      // chain with exactly MAX_CHAIN descriptors is accepted (boundary): hdr + (MAXCH-2) data segments + status
      k = d_seq[0] + 1;
      h = alloc_buf(0, 16, 16); d = alloc_buf(0, 512, 8); sa = alloc_buf(0, 1, 1);
      put_hdr(h, 32'd1, 9); gmem[sa] = 8'hFF;
      chain_reset; chain_add(0, h, 16, 1'b0, 1'b1);
      for (i = 0; i < MAXCH - 2; i++) chain_add(0, d + i * (512 / (MAXCH - 2)), (i == MAXCH - 3) ? 512 - (512 / (MAXCH - 2)) * (MAXCH - 3) : (512 / (MAXCH - 2)), 1'b0, 1'b1);
      chain_add(0, sa, 1, 1'b1, 1'b0);
      check_eq(c_n, MAXCH, "chain has MAX_CHAIN descriptors");
      req_custom(0, 1'b1, sa); kick(0);
      drv_wait_used(0, k, 200000);
      check_eq(gmem[sa], 0, "MAX_CHAIN-descriptor request accepted");
      ref_finish("max-chain", 100000);
      // read-only function
      drv_reset(0);
    end
  endtask

  task automatic t_readonly;
    reg [31:0] v;
    begin
      begin_test("read-only function: VIRTIO_BLK_F_RO offered, writes refused with IOERR, reads work");
      cfg_standard(1'b1, 1'b0);
      std_up(0, 16);
      mmio_wr(0, R_DEV_FEAT_SEL, 0); mmio_rd(0, R_DEV_FEATURES, v);
      check(v[5] == 1'b1, "VIRTIO_BLK_F_RO offered");
      run_blk(0, 32'd1, 0, 512, 0, 1, 1, "OUT on read-only disk");
      run_blk(0, 32'd0, 0, 512, 0, 0, 513, "IN on read-only disk");
    end
  endtask

  // ==================================================================== T6: malformed chains (FATAL: NEEDS_RESET, no completion)
  task automatic fatal_check(input int f, input int code, input string name);
    reg [31:0] st;
    int k;
    begin
      wait_idle(200000);
      ref_finish(name, 100000);
      get_fstate(f, st);
      check(st[6] == 1'b1, {name, ": NEEDS_RESET set"});
      check_eq(st[15:8], code, {name, ": fault code"});
      check_eq(used_idx_mem(f), d_reaped[f] % 65536, {name, ": no used entry written"});
      mmio_rd(f, R_STATUS, st);
      check(st[6] == 1'b1, {name, ": Status reads NEEDS_RESET"});
      mmio_rd(f, R_INT_STATUS, st);
      check(st[1] == 1'b1, {name, ": configuration-change interrupt pending"});
      check(irq[f] == 1'b1, {name, ": interrupt line high"});
      // a stopped function does not serve a further valid request
      submit_blk(f, 32'd1, 0, 512, 0, 1'b1);
      repeat (300) @(posedge clk);
      check_eq(used_idx_mem(f), d_reaped[f] % 65536, {name, ": stopped function consumes nothing"});
      // a driver reset brings it back
      drv_reset(f);
      std_up(f, t_qs);
      run_blk(f, 32'd1, 0, 512, 0, 0, 1, {name, ": works again after reset"});
    end
  endtask

  task automatic t_malformed;
    reg [63:0] h, d, sa;
    int i;
    begin
      begin_test("malformed chains: cycles, length, flags, indirect, order, framing, indices");
      cfg_standard(1'b0, 1'b0);
      t_qs = (MAXCH + 1 > 16) ? 32 : 16;              // a chain of MAX_CHAIN+1 descriptors needs a queue of at least that many slots
      std_up(0, t_qs);
      // helper layout: header at h, data at d, status at sa
      // a) self loop
      h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); put_hdr(h, 32'd1, 0); gmem[sa] = 8'hFF;
      chain_reset; chain_add(0, h, 16, 1'b0, 1'b1); c_slot[0] = 0;
      chain_commit(0); desc_put(0, 0, h, 16, 16'h0001, 16'd0);          // next = itself
      publish_head(0, 0); kick(0);
      fatal_check(0, 8'h04, "cycle: self loop");
      // b) two-descriptor cycle
      h = alloc_buf(0, 16, 16); put_hdr(h, 32'd1, 0);
      desc_put(0, 0, h, 16, 16'h0001, 16'd1); desc_put(0, 1, h, 16, 16'h0001, 16'd0);
      publish_head(0, 0); kick(0);
      fatal_check(0, 8'h04, "cycle: 0 -> 1 -> 0");
      // c) chain longer than MAX_CHAIN (MAXCH + 1 descriptors, otherwise valid)
      h = alloc_buf(0, 16, 16); d = alloc_buf(0, 512, 8); sa = alloc_buf(0, 1, 1); put_hdr(h, 32'd1, 0); gmem[sa] = 8'hFF;
      chain_reset; chain_add(0, h, 16, 1'b0, 1'b1);
      for (i = 0; i < MAXCH - 1; i++) chain_add(0, d + i * 8, 8, 1'b0, 1'b1);
      chain_add(0, sa, 1, 1'b1, 1'b0);
      check_eq(c_n, MAXCH + 1, "built MAXCH+1 descriptors");
      req_custom(0, 1'b0, sa); kick(0);
      fatal_check(0, 8'h05, "too long");
      // d) next index out of range
      h = alloc_buf(0, 16, 16); put_hdr(h, 32'd1, 0);
      desc_put(0, 0, h, 16, 16'h0001, t_qs[15:0]);                      // index = queue size: out of range
      publish_head(0, 0); kick(0);
      fatal_check(0, 8'h03, "next = queue size");
      h = alloc_buf(0, 16, 16); put_hdr(h, 32'd1, 0);
      desc_put(0, 0, h, 16, 16'h0001, 16'hFFFF);
      publish_head(0, 0); kick(0);
      fatal_check(0, 8'h03, "next = 0xFFFF");
      // e) head index out of range
      publish_head(0, t_qs); kick(0);
      fatal_check(0, 8'h02, "head = queue size");
      publish_head(0, 16'hFFFF); kick(0);
      fatal_check(0, 8'h02, "head = 0xFFFF");
      // f) reserved flag bits
      for (i = 0; i < 3; i++) begin
        h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); put_hdr(h, 32'd1, 0);
        desc_put(0, 0, h, 16, (i == 0) ? 16'h0008 : (i == 1) ? 16'h8000 : 16'h0101, 16'd1);
        desc_put(0, 1, sa, 1, 16'h0002, 16'd0);
        publish_head(0, 0); kick(0);
        fatal_check(0, 8'h06, "reserved flag bits");
      end
      // g) indirect descriptors are refused (feature not offered)
      for (i = 0; i < 2; i++) begin
        h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); put_hdr(h, 32'd1, 0);
        desc_put(0, 0, h, 16, (i == 0) ? 16'h0004 : 16'h0005, 16'd1);
        desc_put(0, 1, sa, 1, 16'h0002, 16'd0);
        publish_head(0, 0); kick(0);
        fatal_check(0, 8'h07, "indirect descriptor");
      end
      // h) device-readable descriptor after a device-writable one
      h = alloc_buf(0, 16, 16); d = alloc_buf(0, 512, 8); sa = alloc_buf(0, 1, 1); put_hdr(h, 32'd1, 0);
      desc_put(0, 0, h, 16, 16'h0001, 16'd1);
      desc_put(0, 1, sa, 1, 16'h0003, 16'd2);                            // writable + NEXT
      desc_put(0, 2, d, 512, 16'h0000, 16'd0);                           // readable after writable
      publish_head(0, 0); kick(0);
      fatal_check(0, 8'h08, "readable after writable");
      // i) no device-writable byte at all
      h = alloc_buf(0, 16, 16); put_hdr(h, 32'd1, 0);
      desc_put(0, 0, h, 16, 16'h0000, 16'd0);
      publish_head(0, 0); kick(0);
      fatal_check(0, 8'h0A, "no status byte");
      // j) header shorter than 16 bytes
      h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); put_hdr(h, 32'd1, 0);
      desc_put(0, 0, h, 8, 16'h0001, 16'd1); desc_put(0, 1, sa, 1, 16'h0002, 16'd0);
      publish_head(0, 0); kick(0);
      fatal_check(0, 8'h09, "short header");
      // k) only a writable descriptor (nothing to read a header from)
      sa = alloc_buf(0, 1, 1);
      desc_put(0, 0, sa, 1, 16'h0002, 16'd0);
      publish_head(0, 0); kick(0);
      fatal_check(0, 8'h09, "writable only");
      // l) a single zero-length descriptor
      desc_put(0, 0, 64'h1000, 0, 16'h0000, 16'd0);
      publish_head(0, 0); kick(0);
      fatal_check(0, 8'h0A, "zero-length only");
    end
  endtask

  // ==================================================================== T7: DMA permission failures
  task automatic cfg_perm_layout;
    begin
      cfg_standard(1'b0, 1'b0);
      cfg_win(0, 0, 64'h1000,  64'hF020, 1'b1, 1'b1, 1'b1, 1'b0);   // main window now ends at 0x10020 ...
      cfg_win(0, 3, 64'h10020, 64'h0FE0, 1'b1, 1'b1, 1'b1, 1'b0);   // ... and an adjacent RW window continues it (no merging)
      cfg_win(0, 1, 64'h14000, 64'h1000, 1'b1, 1'b0, 1'b1, 1'b0);   // read-only window
      cfg_win(0, 2, 64'h16000, 64'h1000, 1'b0, 1'b1, 1'b1, 1'b0);   // write-only window
    end
  endtask

  // one data request with the data buffer at an explicit address
  task automatic req_at(input int f, input [31:0] typ, input [63:0] daddr, input int n, input [63:0] haddr, input [63:0] saddr, input bit hist);
    begin
      put_hdr(haddr, typ, 64'd2);
      gmem[saddr] = 8'hFF;
      chain_reset;
      chain_add(f, haddr, 16, 1'b0, 1'b1);
      chain_add(f, daddr, n, typ == 32'd0, 1'b1);
      chain_add(f, saddr, 1, 1'b1, 1'b0);
      req_custom(f, hist, saddr);
    end
  endtask

  task automatic t_perm;
    reg [63:0] h, sa, d;
    reg [31:0] st;
    int k, i;
    begin
      begin_test("DMA permissions: R/W per window, outside, straddle, wrap, high address, disabled domain, domain isolation");
      cfg_perm_layout;
      std_up(0, 16);
      run_blk(0, 32'd1, 2, 512, 0, 0, 1, "seed disk sector 2");
      // --- data buffer in a READ-ONLY window: IN needs W -> refused
      h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); k = d_seq[0] + 1;
      req_at(0, 32'd0, 64'h14010, 512, h, sa, 1'b1); kick(0); drv_wait_used(0, k, 100000);
      check_eq(gmem[sa], 1, "IN into read-only window -> IOERR"); check_eq(used_len(0, k - 1), 1, "no data delivered");
      ref_finish("perm/IN->RO", 100000);
      // --- OUT from a READ-ONLY window is fine
      h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); k = d_seq[0] + 1;
      for (i = 0; i < 512; i++) gmem[64'h14100 + i] = rnd32(0);
      req_at(0, 32'd1, 64'h14100, 512, h, sa, 1'b1); kick(0); drv_wait_used(0, k, 100000);
      check_eq(gmem[sa], 0, "OUT from read-only window -> OK");
      ref_finish("perm/OUT<-RO", 100000);
      // --- window EDGES (read-only window [0x14000, 0x15000)): first and last byte are inside, one beat outside is not
      begin : edges
        reg [63:0] eaddr [0:5];
        int exp_st [0:5];
        int e;
        eaddr[0] = 64'h14000; exp_st[0] = 0;            // starts exactly at the window base
        eaddr[1] = 64'h14E00; exp_st[1] = 0;            // ends exactly at the window end (0x15000)
        eaddr[2] = 64'h14E08; exp_st[2] = 1;            // ends 8 bytes past the end
        eaddr[3] = 64'h13FF8; exp_st[3] = 1;            // starts 8 bytes before the base
        eaddr[4] = 64'h14E01; exp_st[4] = 1;            // ends ONE BYTE past the end (0x15001)
        eaddr[5] = 64'h13FFF; exp_st[5] = 1;            // starts ONE BYTE before the base
        for (e = 0; e < 6; e++) begin
          h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); k = d_seq[0] + 1;
          req_at(0, 32'd1, eaddr[e], 512, h, sa, 1'b1); kick(0); drv_wait_used(0, k, 100000);
          check_eq(gmem[sa], exp_st[e], "OUT at a window edge");
          ref_finish("perm/edge", 100000);
        end
      end
      // --- OUT from a WRITE-ONLY window: needs R -> refused
      h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); k = d_seq[0] + 1;
      req_at(0, 32'd1, 64'h16010, 512, h, sa, 1'b1); kick(0); drv_wait_used(0, k, 100000);
      check_eq(gmem[sa], 1, "OUT from write-only window -> IOERR");
      ref_finish("perm/OUT<-WO", 100000);
      // --- IN into a WRITE-ONLY window is fine
      h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); k = d_seq[0] + 1;
      req_at(0, 32'd0, 64'h16100, 512, h, sa, 1'b1); kick(0); drv_wait_used(0, k, 100000);
      check_eq(gmem[sa], 0, "IN into write-only window -> OK");
      ref_finish("perm/IN->WO", 100000);
      // --- outside every window
      h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); k = d_seq[0] + 1;
      req_at(0, 32'd0, 64'h18000, 512, h, sa, 1'b1); kick(0); drv_wait_used(0, k, 100000);
      check_eq(gmem[sa], 1, "IN outside every window -> IOERR");
      ref_finish("perm/IN->outside", 100000);
      h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); k = d_seq[0] + 1;
      req_at(0, 32'd1, 64'h18000, 512, h, sa, 1'b1); kick(0); drv_wait_used(0, k, 100000);
      check_eq(gmem[sa], 1, "OUT outside every window -> IOERR");
      ref_finish("perm/OUT<-outside", 100000);
      // --- another domain's memory (domain 1 window is 0x20000..) must be unreachable from function 0
      if (ND > 1) begin
        cfg_win(1, 0, 64'h20000, 64'hF000, 1'b1, 1'b1, 1'b1, 1'b0);
        h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); k = d_seq[0] + 1;
        req_at(0, 32'd0, 64'h20100, 512, h, sa, 1'b1); kick(0); drv_wait_used(0, k, 100000);
        check_eq(gmem[sa], 1, "IN into another domain's window -> IOERR");
        ref_finish("perm/cross-domain", 100000);
      end
      // --- straddling the end of a window / two adjacent windows (a range must lie inside ONE window)
      h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); k = d_seq[0] + 1;
      req_at(0, 32'd0, 64'h10018, 512, h, sa, 1'b1);                // the first chunk [0x10018, 0x10018+min(STAGE,..)) crosses the window boundary at 0x10020
      kick(0); drv_wait_used(0, k, 100000);
      check_eq(gmem[sa], 1, "a chunk across two adjacent windows -> IOERR (each chunk must lie inside ONE window)");
      ref_finish("perm/straddle", 100000);
      // the same two windows are usable when no chunk straddles the boundary: data starting exactly at 0x10020 (inside the second window)
      h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); k = d_seq[0] + 1;
      req_at(0, 32'd0, 64'h10020, 512, h, sa, 1'b1); kick(0); drv_wait_used(0, k, 100000);
      check_eq(gmem[sa], 0, "buffer inside the adjacent window -> OK");
      ref_finish("perm/adjacent-ok", 100000);
      // --- addresses beyond the address width and wrap-around
      h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); k = d_seq[0] + 1;
      req_at(0, 32'd0, 64'h0001_0000_0000_0000, 512, h, sa, 1'b1); kick(0); drv_wait_used(0, k, 100000);
      check_eq(gmem[sa], 1, "address 2^48 -> IOERR");
      ref_finish("perm/2^48", 100000);
      h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); k = d_seq[0] + 1;
      req_at(0, 32'd0, 64'hFFFF_FFFF_FFFF_FFF8, 512, h, sa, 1'b1); kick(0); drv_wait_used(0, k, 100000);
      check_eq(gmem[sa], 1, "address 2^64-8 (+512 wraps) -> IOERR");
      ref_finish("perm/wrap", 100000);
      h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1); k = d_seq[0] + 1;
      req_at(0, 32'd1, 64'h8000_0000_0000_0000, 512, h, sa, 1'b1); kick(0); drv_wait_used(0, k, 100000);
      check_eq(gmem[sa], 1, "address 2^63 -> IOERR");
      ref_finish("perm/2^63", 100000);
      // --- header in a write-only window: header read refused -> IOERR (status is in the main window)
      h = 64'h16200; sa = alloc_buf(0, 1, 1); d = alloc_buf(0, 512, 8); k = d_seq[0] + 1;
      req_at(0, 32'd1, d, 512, h, sa, 1'b1); kick(0); drv_wait_used(0, k, 100000);
      check_eq(gmem[sa], 1, "header in write-only window -> IOERR");
      ref_finish("perm/header", 100000);
      // --- the function survived all of the above (quarantine is off): a normal request still works
      run_blk(0, 32'd0, 2, 512, 0, 0, 513, "still alive after violations");
      begin : viol_count
        reg [31:0] v;
        mg_wr(M_PERF_SEL, 7, 1'b0); mg_rd(M_PERF_DATA, v);
        check(v >= 8, "violation counter counted the refusals");
        check_eq(v, r_nviol[0], "violation counter equals the model's count");
      end
    end
  endtask

  // fatal permission cases: refused ring / descriptor-table / status accesses
  task automatic t_perm_fatal;
    reg [63:0] h, sa;
    reg [31:0] st;
    int k;
    begin
      begin_test("DMA permissions (fatal): status byte, descriptor table, available ring, used ring, disabled domain");
      cfg_perm_layout;
      // status byte outside every window -> the request cannot be answered: fatal, no used entry
      std_up(0, 16);
      h = alloc_buf(0, 16, 16); d_buf[0] = d_buf[0];
      put_hdr(h, 32'd1, 0);
      chain_reset; chain_add(0, h, 16, 1'b0, 1'b1); chain_add(0, 64'h18000, 1, 1'b1, 1'b0);
      req_custom(0, 1'b0, 64'h18000); kick(0);
      fatal_check(0, 8'h10, "status outside windows");
      // status byte in a read-only window (W missing)
      h = alloc_buf(0, 16, 16); put_hdr(h, 32'd1, 0);
      chain_reset; chain_add(0, h, 16, 1'b0, 1'b1); chain_add(0, 64'h14200, 1, 1'b1, 1'b0);
      req_custom(0, 1'b0, 64'h14200); kick(0);
      fatal_check(0, 8'h10, "status in read-only window");
      // descriptor table outside the windows
      ov_desc = 64'h18000; ov_avail = 0; ov_used = 0;
      std_up(0, 16);
      h = alloc_buf(0, 16, 16);
      publish_head(0, 0); kick(0);
      wait_idle(100000); ref_finish("desc table outside", 100000);
      get_fstate(0, st); check(st[6] && st[15:8] == 8'h10, "descriptor table outside -> fatal DMA_DENIED");
      ov_desc = 0;
      // available ring outside the windows: refused at the first poll (DRIVER_OK arms it)
      ov_avail = 64'h18000;
      drv_init(0, 16, 64'd0, 64'd0);
      wait_idle(100000);
      get_fstate(0, st); check(st[6] && st[15:8] == 8'h10, "available ring outside -> fatal DMA_DENIED at the first poll");
      ov_avail = 0;
      // used ring in a read-only window: the completion cannot be published -> fatal
      ov_used = 64'h14400;
      std_up(0, 16);
      submit_blk(0, 32'd0, 0, 512, 0, 1'b1);
      wait_idle(100000); ref_finish("used ring read-only", 100000);
      get_fstate(0, st); check(st[6] && st[15:8] == 8'h10, "used ring unwritable -> fatal DMA_DENIED");
      ov_used = 0;
      // domain disabled by management while the driver is up: everything is refused from the next access
      std_up(0, 16);
      cfg_dom(0, 1'b0, 0, 0, 1'b0, 1'b0);
      submit_blk(0, 32'd1, 0, 512, 0, 1'b1);
      wait_idle(100000); ref_finish("domain disabled", 100000);
      get_fstate(0, st);
      check(st[6] && st[15:8] == 8'h10, "disabled domain -> fatal DMA_DENIED");
      check_eq(st[23:16], 8'h01, "adapter detail = DD_DISABLED");
    end
  endtask

  // revocation while a transfer is running: the per-beat guard stops it WITHIN THE CHUNK, not only at the next chunk check
  task automatic t_revoke;
    reg [31:0] st;
    int it, b0, b1, kk;
    begin
      begin_test("revocation: the window is removed while a transfer runs -> the per-beat guard stops it (at most 2 further beats)");
      cfg_standard(1'b0, 1'b0);
      for (it = 0; it < 8; it++) begin
        cfg_win(0, 0, dom_base(0), DOM_SIZE, 1'b1, 1'b1, 1'b1, 1'b0);          // (re-)grant
        drv_reset(0);
        std_up(0, 16);
        gate_gm_pct = 8'd30; dly_gm_max = 8'd6;                               // slow bus: a 64-byte chunk lasts ~100 cycles
        b0 = n_gm_beats_rd;                                                   // the beat counters are GLOBAL: always measure relative to the start of the request
        submit_blk(0, 32'd1, 0, 8192, 0, 1'b1);
        kk = 40 + it * 23 + rndr(0, 30);
        while (n_gm_beats_rd < b0 + kk) @(posedge clk);                       // somewhere inside the data phase, at a different point each time
        mon_enable = 1'b0;
        mg_wr(M_DOM_SEL, 0, 1'b0); mg_wr(M_WIN_SEL, 0, 1'b0);
        mg_wr(M_WIN_BASE_LO, dom_base(0), 1'b0); mg_wr(M_WIN_BASE_HI, 0, 1'b0);
        mg_wr(M_WIN_SIZE_LO, DOM_SIZE, 1'b0);    mg_wr(M_WIN_SIZE_HI, 0, 1'b0);
        mg_wr(M_WIN_CTL, 32'h3, 1'b0);                                         // commit: valid = 0 -> revoked (takes effect at this write)
        t_wr_v[0*NW + 0] = 1'b0;
        // A request that was ALREADY PRESENTED (valid up) when the window was revoked cannot be withdrawn (SFB2 R2: it is held until
        // accepted) and may be accepted several cycles later under back-pressure.  The property is: no NEW beat is presented after it.
        kk = 0; while (gm_req_valid && kk < 2000) begin @(posedge clk); kk++; end
        b0 = n_gm_beats_rd + n_gm_beats_wr;
        mon_enable = 1'b1;
        wait_idle(600000);
        b1 = n_gm_beats_rd + n_gm_beats_wr;
        check(b1 - b0 <= 1, "after the commit that revokes the window (and the beat already presented) no further guest beat is issued");
        get_fstate(0, st);
        check(st[6], "the request could not be completed: function stopped");
        check_eq(mon_viol, 0, "monitor: no forbidden beat");
        gate_gm_pct = 8'd100; dly_gm_max = 8'd0;
        ref_snap_taken = 1'b0; r_kick[0] = 1'b0;
      end
    end
  endtask

  // ==================================================================== T8: reset
  task automatic t_reset;
    reg [31:0] st, v;
    int k, n0, n1, bb;
    begin
      begin_test("reset: idle, in flight, after a fault, FAILED, NEEDS_RESET rules");
      cfg_standard(1'b0, 1'b0);
      std_up(0, 16);
      run_blk(0, 32'd1, 1, 512, 0, 0, 1, "request before reset");
      // reset of an idle function clears the queue state
      drv_reset(0);
      mmio_rd(0, R_QUEUE_READY, v); check_eq(v, 0, "QueueReady cleared by reset");
      mmio_rd(0, R_INT_STATUS, v);  check_eq(v, 0, "InterruptStatus cleared by reset");
      get_fstate(0, st); check_eq(st[7:0], 0, "device status 0");
      mg_rd(M_FUNC_QSTATE, v); check_eq(v, 0, "last_avail / used_idx cleared");
      r_note_reset(0);
      // DRIVER_OK only after FEATURES_OK; NEEDS_RESET blocks everything but FAILED
      mmio_wr(0, R_STATUS, 32'h01); mmio_wr(0, R_STATUS, 32'h07);
      mmio_rd(0, R_STATUS, v); check_eq(v, 32'h03, "DRIVER_OK without FEATURES_OK is not granted");
      drv_reset(0);
      // in-flight reset: slow bus, long request, reset in the middle
      std_up(0, 16);
      gate_gm_pct = 8'd40; dly_gm_max = 8'd4;
      n0 = n_gm_beats_rd;
      submit_blk(0, 32'd1, 0, 8192, 0, 1'b0);
      submit_blk(0, 32'd0, 0, 8192, 0, 1'b0);
      kick(0);
      while (n_gm_beats_rd < n0 + 60) @(posedge clk);                         // 60 beats into the first request (relative: the counter is global)
      check(used_idx_mem(0) == 0, "the reset hits while the first request is still in flight (nothing completed yet)");
      mmio_wr(0, R_STATUS, 32'd0);
      bb = n_gm_beats_rd + n_gm_beats_wr;
      mmio_rd(0, R_STATUS, v);
      check(v != 0, "Status keeps reading its old non-zero value until the engine has stopped (a poll for 0 cannot see 'reset done' early)");
      drv_wait_status0(0);
      check(n_gm_beats_rd + n_gm_beats_wr - bb <= 2, "reset latency: the abort takes effect at the next beat boundary (at most 2 further guest beats)");
      n0 = n_gm_beats_rd + n_gm_beats_wr;
      repeat (400) @(posedge clk);
      n1 = n_gm_beats_rd + n_gm_beats_wr;
      check_eq(n1, n0, "no guest-memory access after Status reads 0");
      check_eq(used_idx_mem(0), 0, "aborted request left no used entry");
      ref_adopt_disk_after_abort(t_pbase[0], 8192);                           // the aborted OUT may have written some chunks of sectors 0..15 (and only those)
      mg_wr(M_FUNC_SEL, 0, 1'b0); mg_rd(M_FUNC_QSTATE, v); check_eq(v, 0, "queue state cleared after in-flight reset");
      r_note_reset(0);
      gate_gm_pct = 8'd100; dly_gm_max = 8'd0;
      // the function works again from scratch
      begin : after
        int i; reg [7:0] pat;
        std_up(0, 16);
        run_blk(0, 32'd1, 4, 512, 0, 0, 1, "after in-flight reset: OUT");
        run_blk(0, 32'd0, 4, 512, 0, 0, 513, "after in-flight reset: IN");
      end
      // FAILED stops the function without a reset
      mmio_wr(0, R_STATUS, 32'h8F);
      submit_blk(0, 32'd1, 5, 512, 0, 1'b1);
      repeat (300) @(posedge clk);
      check_eq(used_idx_mem(0), 2, "FAILED: nothing more is consumed");
      // reset after FAILED
      drv_reset(0);
      std_up(0, 16);
      run_blk(0, 32'd0, 4, 512, 0, 0, 513, "after FAILED + reset");
      // NEEDS_RESET cannot be cleared by writing the status; DRIVER_OK/FEATURES_OK cannot be re-set; reset clears it
      put_hdr(alloc_buf(0, 16, 16), 32'd1, 0);
      desc_put(0, 0, 64'h1000, 16, 16'h0000, 16'd0);                 // a head with no status: fatal
      publish_head(0, 0); kick(0);
      wait_idle(100000);
      mmio_wr(0, R_STATUS, 32'h0F);
      mmio_rd(0, R_STATUS, v); check(v[6] == 1'b1, "NEEDS_RESET is not clearable by a status write");
      drv_reset(0);
      mmio_rd(0, R_STATUS, v); check_eq(v, 0, "reset clears NEEDS_RESET");
    end
  endtask

  // ==================================================================== T9: feature negotiation and register rules
  task automatic t_features;
    reg [31:0] v;
    reg [63:0] offered;
    int i;
    begin
      begin_test("feature negotiation, status protocol, queue-setup validation, register map");
      cfg_standard(1'b0, 1'b0);
      // offered set: exactly VERSION_1 | SEG_MAX | BLK_SIZE (RO not set for this function)
      mmio_wr(0, R_STATUS, 0); mmio_wr(0, R_STATUS, 1); mmio_wr(0, R_STATUS, 3);
      mmio_wr(0, R_DEV_FEAT_SEL, 0); mmio_rd(0, R_DEV_FEATURES, v); offered[31:0] = v;
      mmio_wr(0, R_DEV_FEAT_SEL, 1); mmio_rd(0, R_DEV_FEATURES, v); offered[63:32] = v;
      check_eq(offered, (64'd1 << 32) | (64'd1 << 2) | (64'd1 << 6), "device offers exactly VERSION_1, BLK_F_SEG_MAX, BLK_F_BLK_SIZE");
      mmio_wr(0, R_DEV_FEAT_SEL, 2); mmio_rd(0, R_DEV_FEATURES, v); check_eq(v, 0, "feature window 2 reads 0");
      // none of the unimplemented features is offered
      for (i = 0; i < 64; i++) if (i != 32 && i != 2 && i != 6) check(offered[i] == 1'b0, "feature bit not offered");
      // accepting an un-offered feature: FEATURES_OK is refused (reads back clear)
      drv_init(0, 16, 64'd1 << 28, 64'd0);   check(!init_ok && !init_status[3], "accepting INDIRECT_DESC (not offered) -> FEATURES_OK refused");
      drv_init(0, 16, 64'd1 << 34, 64'd0);   check(!init_ok && !init_status[3], "accepting RING_PACKED (not offered) -> refused");
      drv_init(0, 16, 64'd1 << 29, 64'd0);   check(!init_ok && !init_status[3], "accepting EVENT_IDX (not offered) -> refused");
      drv_init(0, 16, 64'd1 << 9,  64'd0);   check(!init_ok && !init_status[3], "accepting BLK_F_FLUSH (not offered) -> refused");
      drv_init(0, 16, 64'd1 << 12, 64'd0);   check(!init_ok && !init_status[3], "accepting BLK_F_MQ (not offered) -> refused");
      drv_init(0, 16, 64'd1 << 35, 64'd0);   check(!init_ok && !init_status[3], "accepting IN_ORDER (not offered) -> refused");
      drv_init(0, 16, 64'd0, 64'd1 << 32);   check(!init_ok && !init_status[3], "not accepting VERSION_1 (legacy) -> refused");
      // accepting only VERSION_1 (dropping the optional features) is fine
      drv_init(0, 16, 64'd0, (64'd1 << 2) | (64'd1 << 6)); check(init_ok, "VERSION_1 alone is accepted");
      // features are frozen after FEATURES_OK
      mmio_wr(0, R_DRV_FEAT_SEL, 0); mmio_wr(0, R_DRV_FEATURES, 32'hFFFF_FFFF);
      mmio_rd(0, R_STATUS, v); check(v[3] == 1'b1, "late feature writes do not disturb FEATURES_OK");
      // queue-setup validation
      drv_reset(0);
      mmio_wr(0, R_STATUS, 1); mmio_wr(0, R_STATUS, 3);
      mmio_wr(0, R_DRV_FEAT_SEL, 1); mmio_wr(0, R_DRV_FEATURES, 32'd1);
      mmio_wr(0, R_STATUS, 32'h0B);
      mmio_wr(0, R_QUEUE_SEL, 1); mmio_rd(0, R_QUEUE_NUM_MAX, v); check_eq(v, 0, "queue 1 does not exist (QueueNumMax 0)");
      mmio_wr(0, R_QUEUE_SEL, 0); mmio_rd(0, R_QUEUE_NUM_MAX, v); check_eq(v, MAXQ, "QueueNumMax");
      begin : qsetup
        int tries;
        reg [31:0] qn [0:5];
        qn[0] = 0; qn[1] = 3; qn[2] = 24; qn[3] = MAXQ * 2; qn[4] = 65535; qn[5] = 1000;
        for (tries = 0; tries < 6; tries++) begin
          mmio_wr(0, R_QUEUE_NUM, qn[tries]);
          mmio_wr(0, R_DESC_LO, 32'h1000); mmio_wr(0, R_DESC_HI, 0);
          mmio_wr(0, R_DRV_LO, 32'h2000); mmio_wr(0, R_DRV_HI, 0);
          mmio_wr(0, R_DEV_LO, 32'h3000); mmio_wr(0, R_DEV_HI, 0);
          mmio_wr(0, R_QUEUE_READY, 1);
          mmio_rd(0, R_QUEUE_READY, v);
          check_eq(v, 0, "queue size not a power of two / zero / above QueueNumMax -> QueueReady stays 0");
        end
        // misaligned areas
        mmio_wr(0, R_QUEUE_NUM, 16);
        mmio_wr(0, R_DESC_LO, 32'h1008);  mmio_wr(0, R_QUEUE_READY, 1); mmio_rd(0, R_QUEUE_READY, v); check_eq(v, 0, "descriptor table not 16-byte aligned -> refused");
        mmio_wr(0, R_DESC_LO, 32'h1000);
        mmio_wr(0, R_DRV_LO, 32'h2001);   mmio_wr(0, R_QUEUE_READY, 1); mmio_rd(0, R_QUEUE_READY, v); check_eq(v, 0, "available ring not 2-byte aligned -> refused");
        mmio_wr(0, R_DRV_LO, 32'h2000);
        mmio_wr(0, R_DEV_LO, 32'h3002);   mmio_wr(0, R_QUEUE_READY, 1); mmio_rd(0, R_QUEUE_READY, v); check_eq(v, 0, "used ring not 4-byte aligned -> refused");
        mmio_wr(0, R_DEV_LO, 32'h3000);
        // an area that does not fit the guest address space
        mmio_wr(0, R_DESC_LO, 32'hFFFF_FFF0); mmio_wr(0, R_DESC_HI, 32'h0000_FFFF);
        mmio_wr(0, R_QUEUE_READY, 1); mmio_rd(0, R_QUEUE_READY, v); check_eq(v, 0, "descriptor table beyond the address space -> refused");
        mmio_wr(0, R_DESC_LO, 32'h1000); mmio_wr(0, R_DESC_HI, 0);
        mmio_wr(0, R_QUEUE_READY, 1); mmio_rd(0, R_QUEUE_READY, v); check_eq(v, 1, "legal geometry accepted");
        // once ready: configuration writes are ignored
        mmio_wr(0, R_QUEUE_NUM, 4); mmio_wr(0, R_DESC_LO, 32'h8000);
        mmio_wr(0, R_QUEUE_READY, 0); mmio_rd(0, R_QUEUE_READY, v); check_eq(v, 1, "QueueReady cannot be cleared (no RING_RESET)");
        check_eq(dut.u_qc.f_qnum[15:0], 16, "QueueNum unchanged while ready");
      end
      // register map: write-only registers read 0, unknown offsets read 0, config space
      mmio_rd(0, R_DRV_FEATURES, v);  check_eq(v, 0, "write-only register reads 0");
      mmio_rd(0, 12'h2f0, v);         check_eq(v, 0, "unknown offset reads 0");
      mmio_rd(0, R_CONFIG_GEN, v);    check_eq(v, 0, "ConfigGeneration");
      // a function that management did not enable is a placeholder device
      if (NF > 1) begin
        mmio_rd(1, R_DEVICE_ID, v);   check_eq(v, 2, "second function present when configured");
      end
      // out-of-range window / unaligned access answer with an error
      @(posedge clk); #1 mmio_req_valid = 1; mmio_req_write = 0; mmio_req_addr = 16'hF000;
      @(posedge clk); #1 mmio_req_valid = 0; check(mmio_rsp_err, "window of a non-existent function -> error response");
      @(posedge clk); #1 mmio_req_valid = 1; mmio_req_write = 0; mmio_req_addr = 16'h0002;
      @(posedge clk); #1 mmio_req_valid = 0; check(mmio_rsp_err, "unaligned MMIO access -> error response");
    end
  endtask

  task automatic t_disabled_fn;
    reg [31:0] v;
    begin
      begin_test("a function that is not enabled by management: DeviceID 0, writes ignored");
      mmio_rd(0, R_MAGIC, v);     check_eq(v, 32'h74726976, "magic readable");
      mmio_rd(0, R_DEVICE_ID, v); check_eq(v, 0, "DeviceID 0 = no device");
      mmio_wr(0, R_STATUS, 32'h03); mmio_rd(0, R_STATUS, v); check_eq(v, 0, "status writes ignored");
      mmio_rd(0, R_DEV_FEATURES, v); check_eq(v, 0, "no features");
      // management rules
      cfg_win(0, 0, 64'h1000, 64'h100, 1'b1, 1'b1, 1'b1, 1'b0);
      cfg_win(0, 1, 64'h1001, 64'h100, 1'b1, 1'b1, 1'b1, 1'b1);       // base not beat-aligned: refused
      cfg_win(0, 1, 64'h1000, 64'h0F0 + 64'd1, 1'b1, 1'b1, 1'b1, 1'b1); // size not beat-aligned: refused
      cfg_win(0, 1, 64'h1000, 64'd0, 1'b1, 1'b1, 1'b1, 1'b1);         // empty: refused
      cfg_win(0, NW, 64'h1000, 64'h100, 1'b1, 1'b1, 1'b1, 1'b1);      // window index out of range: refused
      cfg_win(ND, 0, 64'h1000, 64'h100, 1'b1, 1'b1, 1'b1, 1'b1);      // domain out of range: refused
      cfg_dom(0, 1'b1, 0, PART, 1'b1, 1'b0);
      cfg_dom(0, 1'b1, 100, PART, 1'b0, 1'b1);                        // partition base not 512-aligned
      cfg_dom(0, 1'b1, 0, PART + 100, 1'b0, 1'b1);                    // size not 512-aligned
      cfg_dom(0, 1'b1, 0, 0, 1'b0, 1'b1);                             // empty partition
      cfg_dom(0, 1'b1, STORE - 512, 1024, 1'b0, 1'b1);                // beyond the store
      if (ND > 1) cfg_dom(1, 1'b1, PART / 2, PART, 1'b0, 1'b1);       // overlaps domain 0's partition
      cfg_func(0, 1'b1, 0, 64'd0, 1'b0, 1'b0, 1'b1);                  // zero capacity: refused
      cfg_func(0, 1'b1, 0, (PART / 512) + 1, 1'b0, 1'b0, 1'b1);       // capacity larger than the partition: refused
      cfg_func(0, 1'b1, ND, 64'd8, 1'b0, 1'b0, 1'b1);                 // domain out of range: refused
      cfg_func(0, 1'b1, 0, 64'd8, 1'b0, 1'b0, 1'b0);                  // accepted
      // reconfiguring a function while its driver is up is refused
      mmio_wr(0, R_STATUS, 1);
      cfg_func(0, 1'b1, 0, 64'd16, 1'b0, 1'b0, 1'b1);
      mmio_wr(0, R_STATUS, 0); drv_wait_status0(0);
      cfg_func(0, 1'b1, 0, 64'd16, 1'b0, 1'b0, 1'b0);
      // management registers
      mg_rd(12'h000, v); check_eq(v, 32'h53465645, "mgmt ID");
      mg_rd(12'h004, v); check_eq(v, 32'h0001_0000, "mgmt ABI 1.0");
      mg_rd(12'h008, v); check_eq(v, {7'd0, 1'(EXT), 8'(NW), 8'(ND), 8'(NF)}, "mgmt CAPS0");
      mg_rd(12'h00c, v); check_eq(v, {8'($clog2(STAGE)), 8'(MAXCH), 16'(MAXQ)}, "mgmt CAPS1");
      mg_rd(12'h010, v); check_eq(v, STORE, "mgmt STORE");
      mg_wr(12'h000, 32'd0, 1'b1);                                     // read-only
      mg_rd(12'h3f0, v); check(last_mg_err, "unknown management register -> error");
    end
  endtask

  // ==================================================================== T10: interrupts and notification suppression
  task automatic t_irq;
    reg [31:0] v;
    int k, r0;
    begin
      begin_test("notifications: InterruptStatus / ACK, avail.flags NO_INTERRUPT suppression");
      cfg_standard(1'b0, 1'b0);
      std_up(0, 16);
      check(irq[0] == 1'b0, "no interrupt before any completion");
      mmio_rd(0, R_INT_STATUS, v); check_eq(v, 0, "InterruptStatus 0");
      run_blk(0, 32'd1, 0, 512, 0, 0, 1, "request");
      check(irq[0] == 1'b1, "used-buffer notification raises the line");
      mmio_rd(0, R_INT_STATUS, v); check_eq(v, 1, "InterruptStatus bit 0");
      mmio_wr(0, R_INT_ACK, 32'd2); mmio_rd(0, R_INT_STATUS, v); check_eq(v, 1, "ACK of another bit changes nothing");
      mmio_wr(0, R_INT_ACK, 32'd1); mmio_rd(0, R_INT_STATUS, v); check_eq(v, 0, "ACK clears bit 0");
      check(irq[0] == 1'b0, "line low after ACK");
      // suppression: avail.flags = NO_INTERRUPT -> completion without interrupt (and the ring is still updated)
      r0 = d_irq_rises[0];
      gm_put16(d_avail[0], 16'h0001);
      run_blk(0, 32'd1, 1, 512, 0, 0, 1, "suppressed request");
      check(d_irq_rises[0] == r0, "NO_INTERRUPT: no interrupt raised");
      check_eq(used_idx_mem(0), 2, "NO_INTERRUPT: the completion is still published");
      mg_wr(M_PERF_SEL, 6, 1'b0); mg_rd(M_PERF_DATA, v); check_eq(v, 1, "PC_IRQ_SUPPRESSED counted");
      mg_wr(M_PERF_SEL, 5, 1'b0); mg_rd(M_PERF_DATA, v); check_eq(v, 1, "PC_IRQ_RAISED counted");
      // only bit 0 of avail.flags matters; other bits are ignored
      gm_put16(d_avail[0], 16'hFFFE);
      run_blk(0, 32'd1, 1, 512, 0, 0, 1, "other flag bits");
      check(d_irq_rises[0] == r0 + 1, "avail.flags bits other than NO_INTERRUPT are ignored");
      mmio_wr(0, R_INT_ACK, 32'd3);
    end
  endtask

  // ==================================================================== T11: performance counters
  task automatic t_perf;
    reg [31:0] v, lmin, lmax, lsum, lcnt;
    int i;
    begin
      begin_test("performance counters match the workload");
      cfg_standard(1'b0, 1'b0);
      std_up(0, 16);
      mg_wr(M_PERF_CTL, 1, 1'b0);
      for (i = 0; i < 4; i++) run_blk(0, 32'd1, i, 512, 0, 0, 1, "perf OUT");
      for (i = 0; i < 3; i++) run_blk(0, 32'd0, i, 1024, 0, 0, 1025, "perf IN");
      run_blk(0, 32'd1, 0, 100, 0, 1, 1, "perf error request");
      mg_wr(M_FUNC_SEL, 0, 1'b0);
      mg_wr(M_PERF_SEL, 0, 1'b0);  mg_rd(M_PERF_DATA, v); check_eq(v, 8, "PC_REQ_DONE");
      mg_wr(M_PERF_SEL, 1, 1'b0);  mg_rd(M_PERF_DATA, v); check_eq(v, 24, "PC_DESC = 8 requests x 3 descriptors");
      mg_wr(M_PERF_SEL, 2, 1'b0);  mg_rd(M_PERF_DATA, v); check_eq(v, 4*512, "PC_DMA_RD_DATA = request-data bytes read from guest memory (the 4 OUTs; the refused 100-byte OUT moved nothing)");
      mg_wr(M_PERF_SEL, 3, 1'b0);  mg_rd(M_PERF_DATA, v); check_eq(v, 3*1024, "PC_DMA_WR_DATA = bytes written to guest data buffers");
      mg_wr(M_PERF_SEL, 9, 1'b0);  mg_rd(M_PERF_DATA, v); check_eq(v, 1, "PC_REQ_ERR");
      mg_wr(M_PERF_SEL, 7, 1'b0);  mg_rd(M_PERF_DATA, v); check_eq(v, 0, "PC_VIOLATIONS");
      mg_wr(M_PERF_SEL, 8, 1'b0);  mg_rd(M_PERF_DATA, v); check_eq(v, 0, "PC_FATAL");
      mg_wr(M_PERF_SEL, 10, 1'b0); mg_rd(M_PERF_DATA, v); check_eq(v, 8, "PC_KICKS");
      mg_wr(M_PERF_SEL, 21, 1'b0); mg_rd(M_PERF_DATA, lcnt); check_eq(lcnt, 8, "PC_WALK_COUNT");
      mg_wr(M_PERF_SEL, 19, 1'b0); mg_rd(M_PERF_DATA, v);    check(v >= 8 * 3 * 4, "PC_WALK_SUM: each descriptor fetch takes several cycles");
      mg_wr(M_PERF_SEL, 16, 1'b0); mg_rd(M_PERF_DATA, lsum);
      mg_wr(M_PERF_SEL, 17, 1'b0); mg_rd(M_PERF_DATA, lmax);
      mg_wr(M_PERF_SEL, 18, 1'b0); mg_rd(M_PERF_DATA, lmin);
      check(lmin > 0 && lmin <= lmax && lsum >= lmin * 8 && lsum <= lmax * 8, "latency min <= mean <= max");
      mg_wr(M_PERF_SEL, 14, 1'b0); mg_rd(M_PERF_DATA, v); check(v >= 8, "PC_UTIL_SAMPLES: every ring poll is sampled");
      mg_wr(M_PERF_SEL, 15, 1'b0); mg_rd(M_PERF_DATA, v); check(v >= 1, "PC_UTIL_MAX");
      mg_wr(M_PERF_SEL, 22, 1'b0); mg_rd(M_PERF_DATA, v); check(v > 0, "PC_BUSY");
      $display("      counters: latency min/mean/max = %0d / %0d / %0d cycles (8 requests); walk sum = %0d cycles", lmin, lsum / 8, lmax, v);
      mg_wr(M_PERF_CTL, 1, 1'b0);
      mg_wr(M_PERF_SEL, 0, 1'b0); mg_rd(M_PERF_DATA, v); check_eq(v, 0, "counters cleared");
      mg_wr(M_PERF_SEL, 18, 1'b0); mg_rd(M_PERF_DATA, v); check_eq(v, 32'hFFFF_FFFF, "latency minimum re-armed");
      // single-request latency figures (zero wait states on both ports) for the report
      begin : lat
        reg [31:0] wlat, rlat, wwalk, rwalk, w4k, r4k;
        run_blk(0, 32'd1, 0, 512, 0, 0, 1, "latency OUT 512");
        mg_wr(M_PERF_SEL, 16, 1'b0); mg_rd(M_PERF_DATA, wlat);
        mg_wr(M_PERF_SEL, 19, 1'b0); mg_rd(M_PERF_DATA, wwalk);
        mg_wr(M_PERF_CTL, 1, 1'b0);
        run_blk(0, 32'd0, 0, 512, 0, 0, 513, "latency IN 512");
        mg_wr(M_PERF_SEL, 16, 1'b0); mg_rd(M_PERF_DATA, rlat);
        mg_wr(M_PERF_SEL, 19, 1'b0); mg_rd(M_PERF_DATA, rwalk);
        mg_wr(M_PERF_CTL, 1, 1'b0);
        run_blk(0, 32'd1, 0, 4096, 0, 0, 1, "latency OUT 4096");
        mg_wr(M_PERF_SEL, 16, 1'b0); mg_rd(M_PERF_DATA, w4k);
        mg_wr(M_PERF_CTL, 1, 1'b0);
        run_blk(0, 32'd0, 0, 4096, 0, 0, 4097, "latency IN 4096");
        mg_wr(M_PERF_SEL, 16, 1'b0); mg_rd(M_PERF_DATA, r4k);
        $display("      LATENCY (cycles, head fetch -> used.idx acknowledged; %0d-byte bus, %0d-byte stage, zero wait states): OUT 512 B = %0d, IN 512 B = %0d, OUT 4 KiB = %0d, IN 4 KiB = %0d; 3-descriptor walk = %0d / %0d",
                 DW / 8, STAGE, wlat, rlat, w4k, r4k, wwalk, rwalk);
      end
    end
  endtask


  // ==================================================================== T12: multi-tenant (NF >= 2)
  task automatic submit_rand_valid(input int f, input bit kick_it);
    int nsec, sec, lay;
    begin
      nsec = rndr(1, 3);
      sec  = rndr(0, CAPSEC - nsec);
      lay  = rndr(0, 4);
      if (lay == 3 && MAXCH < 4) lay = 0;
      submit_blk(f, rndr(0, 1) ? 32'd1 : 32'd0, sec, 512 * nsec, lay, kick_it);
    end
  endtask

  task automatic t_multi;
    int r, f, i, n0, n1;
    reg [31:0] st, v;
    reg [63:0] h, sa;
    bit zero;
    begin
      begin_test("multi-tenant: concurrent functions, isolation attacks, quarantine, scrub on re-ownership");
      cfg_standard(1'b0, 1'b0);
      for (f = 0; f < NF; f++) std_up(f, 16);
      // A: concurrent traffic from every function, arbitrated round-robin
      for (r = 0; r < 8; r++) begin
        for (f = 0; f < NF; f++) begin submit_rand_valid(f, 1'b0); submit_rand_valid(f, 1'b0); end
        for (f = 0; f < NF; f++) kick(f);
        for (f = 0; f < NF; f++) drv_wait_used(f, d_seq[f], 400000);
        ref_finish("multi/concurrent", 400000);
      end
      if (NF >= 2 && ND >= 2) begin
        // B: function 0 attacks domain 1's memory while function 1 runs legitimate traffic
        for (i = 0; i < 512; i++) gmem[64'h20200 + i] = 8'h5A;            // canary inside domain 1's window
        h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1);
        req_at(0, 32'd0, 64'h20200, 512, h, sa, 1'b1);                    // IN into the other tenant's memory
        submit_rand_valid(1, 1'b0);
        kick(0); kick(1);
        for (f = 0; f < 2; f++) drv_wait_used(f, d_seq[f], 400000);
        check_eq(gmem[sa], 1, "attack: IN into the other tenant's window -> IOERR");
        for (i = 0; i < 512; i++) if (gmem[64'h20200 + i] !== 8'h5A) begin check(1'b0, "attack: the other tenant's canary is intact"); i = 512; end
        ref_finish("multi/attack-write", 400000);
        h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1);
        req_at(0, 32'd1, 64'h20200, 512, h, sa, 1'b1);                    // OUT: try to read the other tenant's memory onto our disk
        submit_rand_valid(1, 1'b0);
        kick(0); kick(1);
        for (f = 0; f < 2; f++) drv_wait_used(f, d_seq[f], 400000);
        check_eq(gmem[sa], 1, "attack: OUT from the other tenant's window -> IOERR");
        ref_finish("multi/attack-read", 400000);
        mg_wr(M_PERF_SEL, 7 | (0 << 8), 1'b0); mg_rd(M_PERF_DATA, v); check(v >= 2, "function 0 violations counted");
        mg_wr(M_PERF_SEL, 7 | (1 << 8), 1'b0); mg_rd(M_PERF_DATA, v); check_eq(v, 0, "function 1 has no violations");
        // the partitions are separate: function 1's disk is untouched by function 0's work
        // C: function 0's descriptor table inside domain 1's window -> function 0 stops, function 1 keeps working
        drv_reset(0);
        ov_desc = 64'h21000;
        std_up(0, 16);
        ov_desc = 0;
        publish_head(0, 0);
        submit_rand_valid(1, 1'b0);                                        // everything is queued BEFORE the first doorbell (model snapshot)
        kick(0); kick(1);
        drv_wait_used(1, d_seq[1], 400000);
        ref_finish("multi/desc-in-other-domain", 400000);
        get_fstate(0, st); check(st[6] && st[15:8] == 8'h10, "function 0 with a foreign descriptor table: fatal DMA_DENIED");
        get_fstate(1, st); check(!st[6], "function 1 unaffected");
        // D: quarantine on violation (management flag): the violating request is answered, then the function stops
        drv_reset(0);
        cfg_func(0, 1'b1, 0, CAPSEC, 1'b0, 1'b1, 1'b0);
        std_up(0, 16);
        h = alloc_buf(0, 16, 16); sa = alloc_buf(0, 1, 1);
        req_at(0, 32'd0, 64'h20200, 512, h, sa, 1'b1);
        submit_rand_valid(0, 1'b0);                                        // queued behind it: must NOT be served after quarantine
        kick(0);
        wait_idle(400000);
        ref_finish("multi/quarantine", 400000);
        check_eq(gmem[sa], 1, "quarantine: the violating request was still answered (IOERR)");
        check_eq(used_idx_mem(0), 1, "quarantine: exactly one completion, the next request is not served");
        get_fstate(0, st); check(st[6], "quarantine: function stopped (NEEDS_RESET)");
        submit_rand_valid(1, 1'b1); drv_wait_used(1, d_seq[1], 400000); ref_finish("multi/other-still-ok", 400000);   // single kick: snapshot precedes it
        // E: re-ownership: tear domain 0 down with scrub, the new owner of the partition reads zeros
        drv_reset(0);
        run_dummy_data(0);
        drv_reset(0);
        cfg_func(0, 1'b0, 0, CAPSEC, 1'b0, 1'b0, 1'b0);                    // function 0 withdrawn
        n0 = 0; for (i = 0; i < PART; i++) if (dut_disk_byte(0 * PART + i) !== 8'h00) n0++;
        check(n0 > 0, "before teardown the partition holds the previous owner's data");
        cfg_dom(0, 1'b0, 0, 0, 1'b1, 1'b0);                                // disable + scrub
        n1 = 0; for (i = 0; i < PART; i++) if (dut_disk_byte(0 * PART + i) !== 8'h00) n1++;
        check_eq(n1, 0, "scrub: the partition is zeroed");
        cfg_dom(0, 1'b1, 0, PART, 1'b0, 1'b0);                              // new owner, no scrub needed
        cfg_func(0, 1'b1, 0, CAPSEC, 1'b0, 1'b0, 1'b0);
        std_up(0, 16);
        run_blk(0, 32'd0, 0, 512, 0, 0, 513, "new owner reads");
        zero = 1'b1; for (i = 0; i < 512; i++) if (gmem[last_data + i] !== 8'h00) zero = 1'b0;
        check(zero, "the new owner reads zeros, not the previous owner's bytes");
        // F: partitions may not overlap, and a disabled domain's backend refuses requests
        cfg_dom(1, 1'b1, PART / 2, PART, 1'b0, 1'b1);
      end
    end
  endtask

  task automatic run_dummy_data(input int f);
    begin
      std_up(f, 16);
      run_blk(f, 32'd1, 0, 2048, 0, 0, 1, "dummy data");
    end
  endtask

  // ==================================================================== T13: random regression against the model
  task automatic gen_fatal(input int f);
    int kind, qs, s0, s1, s2;
    reg [63:0] h, sa;
    begin
      qs = d_qsz[f];
      kind = rndr(0, 8);
      h = alloc_buf(f, 16, 16); sa = alloc_buf(f, 1, 1); put_hdr(h, 32'd1, 0);
      s0 = d_slot[f] % qs; s1 = (s0 + 1) % qs; s2 = (s0 + 2) % qs;     // fresh slots: never clobber a chain that is already queued
      d_slot[f] = d_slot[f] + 3;
      case (kind)
        0: begin desc_put(f, s0, h, 16, 16'h0001, s0[15:0]); end                                                       // self loop
        1: begin desc_put(f, s0, h, 16, 16'h0001, qs[15:0]); end                                                       // next out of range
        2: begin publish_head(f, qs + rndr(0, 100)); end                                                               // head out of range (no descriptor)
        3: begin desc_put(f, s0, h, 16, 16'h0001 | (16'h0008 << rndr(0, 12)), s1[15:0]); desc_put(f, s1, sa, 1, 16'h0002, 16'd0); end   // reserved flag
        4: begin desc_put(f, s0, h, 16, 16'h0005, s1[15:0]); desc_put(f, s1, sa, 1, 16'h0002, 16'd0); end              // indirect
        5: begin desc_put(f, s0, h, 16, 16'h0001, s1[15:0]); desc_put(f, s1, sa, 1, 16'h0003, s2[15:0]); desc_put(f, s2, h, 16, 16'h0000, 16'd0); end  // readable after writable
        6: begin desc_put(f, s0, h, 16, 16'h0000, 16'd0); end                                                          // no status byte
        7: begin desc_put(f, s0, h, 8, 16'h0001, s1[15:0]); desc_put(f, s1, sa, 1, 16'h0002, 16'd0); end              // short header
        default: begin desc_put(f, s0, h, 16, 16'h0001, s1[15:0]); desc_put(f, s1, 64'h18000, 1, 16'h0002, 16'd0); end  // status outside the windows
      endcase
      if (kind != 2) publish_head(f, s0);
    end
  endtask

  task automatic gen_other(input int f, input int kind);
    int n, sec;
    reg [63:0] h, sa, da;
    int region;
    begin
      case (kind)
        0: begin   // length / range errors
             case (rndr(0, 4))
               0: submit_blk(f, 32'd1, rndr(0, CAPSEC - 1), 100, 0, 1'b0);
               1: submit_blk(f, 32'd0, rndr(0, CAPSEC - 1), 513, 0, 1'b0);
               2: submit_blk(f, rndr(0, 1) ? 32'd1 : 32'd0, CAPSEC - rndr(0, 1), 512 * rndr(1, 2), 0, 1'b0);
               3: submit_blk(f, 32'd0, 64'hFFFF_FFFF_FFFF_FFF0 + rndr(0, 15), 512, 0, 1'b0);
               default: submit_blk(f, rndr(0, 1) ? 32'd1 : 32'd0, 0, 0, 0, 1'b0);
             endcase
           end
        1: begin   // unsupported types
             case (rndr(0, 3)) 0: n = 4; 1: n = 8; 2: n = 5; default: n = 11; endcase
             submit_blk(f, n, 0, (n == 8) ? 20 : 0, 0, 1'b0);
           end
        default: begin   // permission-denied data buffer (RO / WO / outside / foreign domain), data fully inside the chosen region
             region = rndr(0, (ND > 1) ? 3 : 2);
             case (region)
               0: da = 64'h14000 + 8 * rndr(0, 100);
               1: da = 64'h16000 + 8 * rndr(0, 100);
               2: da = 64'h18000 + 8 * rndr(0, 500);
               default: da = 64'h20400 + 8 * rndr(0, 500);
             endcase
             h = alloc_buf(f, 16, 16); sa = alloc_buf(f, 1, 1);
             req_at(f, rndr(0, 1) ? 32'd1 : 32'd0, da, 512, h, sa, 1'b1);
           end
      endcase
    end
  endtask

  task automatic t_random;
    int it, nb, b, f, r, k;
    bit fatal_added;
    begin
      begin_test("random regression: mixed valid / invalid / refused / malformed requests, random back-pressure, against the model");
      cfg_perm_layout;
      if (ND > 1) cfg_win(1, 0, 64'h20000, 64'hF000, 1'b1, 1'b1, 1'b1, 1'b0);
      for (f = 0; f < NF; f++) std_up(f, 16);
      for (it = 0; it < NRAND; it = it + 1) begin
        f = rndr(0, NF - 1);
        apply_stall(rndr(0, 2));
        if (!d_up[f]) begin drv_reset(f); std_up(f, 16); end
        nb = rndr(1, 3);
        fatal_added = 1'b0;
        for (b = 0; b < nb && !fatal_added; b++) begin
          if (d_outd[f] + 7 > d_qsz[f]) b = nb;
          else begin
            r = rndr(0, 99);
            if (r < 62)      submit_rand_valid(f, 1'b0);
            else if (r < 72) gen_other(f, 0);
            else if (r < 78) gen_other(f, 1);
            else if (r < 92) gen_other(f, 2);
            else begin gen_fatal(f); fatal_added = 1'b1; end
          end
        end
        kick(f);
        drv_wait_used_or_idle(f);
        ref_finish("random", 400000);
        if (r_dead[f]) begin drv_reset(f); std_up(f, 16); end
      end
      mg_rd(12'h000, k);                                                  // management port still healthy
      check_eq(k, 32'h53465645, "mgmt ID after the random run");
    end
  endtask

  // wait for the completions the driver expects, or for quiescence if the batch ended in a fault
  task automatic drv_wait_used_or_idle(input int f);
    int c;
    begin
      c = 0;
      wait_idle(400000);
      drv_reap(f);
    end
  endtask

  // ==================================================================== T14: heavy back-pressure on structured traffic
  task automatic t_stall;
    int i;
    reg [31:0] v;
    begin
      begin_test("back-pressure: 15% request acceptance, up to 12 cycles response latency on both ports");
      cfg_standard(1'b0, 1'b0);
      std_up(0, 16);
      gate_gm_pct = 8'd15; dly_gm_max = 8'd12; gate_bk_pct = 8'd20; dly_bk_max = 8'd10;
      for (i = 0; i < 12; i++) begin
        submit_rand_valid(0, 1'b0);
        if (i % 3 == 2) begin kick(0); wait_idle(2000000); drv_reap(0); ref_finish("stall", 2000000); end
      end
      mg_wr(M_PERF_SEL, 12, 1'b0); mg_rd(M_PERF_DATA, v);
      check(v > 0, "PC_BUS_STALL counts the cycles spent waiting for ready");
      $display("      bus-stall cycles under heavy back-pressure: %0d", v);
    end
  endtask

  // ==================================================================== T15: external IOMMU mode (EXT = 1 builds only)
  task automatic t_ext;
    reg [63:0] h, sa, d, v64;
    reg [31:0] v, st;
    int k, i, n0;
    begin
      begin_test("external IOMMU: translation, permission and page-chunking through the IOMMU interface");
      cfg_standard(1'b0, 1'b0);                                           // domain enable + partition (windows are not used in this mode)
      // the driver works in IOVA space: rings and buffers sit at IOVA = PA + 0x100000
      ov_desc = 64'h101000 + 64'h0; ov_avail = 64'h102000; ov_used = 64'h103000;
      mmio_wr(0, R_STATUS, 0); drv_wait_status0(0);
      d_qsz[0] = 16; d_desc[0] = ov_desc; d_avail[0] = ov_avail; d_used[0] = ov_used;
      begin : bringup
        reg [63:0] off;
        // rings live at PA = IOVA - 0x100000: zero them there
        for (i = 0; i < 16 * 16; i++) gmem[64'h1000 + i] = 0;
        for (i = 0; i < 6 + 2 * 16; i++) gmem[64'h2000 + i] = 0;
        for (i = 0; i < 6 + 8 * 16; i++) gmem[64'h3000 + i] = (i < 4) ? 8'h00 : 8'hFF;
      end
      mmio_wr(0, R_STATUS, 1); mmio_wr(0, R_STATUS, 3);
      mmio_wr(0, R_DEV_FEAT_SEL, 1); mmio_rd(0, R_DEV_FEATURES, v);
      check(v[1] == 1'b1, "VIRTIO_F_ACCESS_PLATFORM (bit 33) is offered in IOMMU mode");
      check(v[0] == 1'b1, "VIRTIO_F_VERSION_1 offered");
      mmio_wr(0, R_DEV_FEAT_SEL, 0); mmio_rd(0, R_DEV_FEATURES, v);
      mmio_wr(0, R_DRV_FEAT_SEL, 0); mmio_wr(0, R_DRV_FEATURES, v);
      mmio_wr(0, R_DRV_FEAT_SEL, 1); mmio_wr(0, R_DRV_FEATURES, 32'h3);   // VERSION_1 + ACCESS_PLATFORM
      mmio_wr(0, R_STATUS, 32'h0B); mmio_rd(0, R_STATUS, v); check(v[3], "FEATURES_OK with ACCESS_PLATFORM");
      mmio_wr(0, R_QUEUE_SEL, 0); mmio_wr(0, R_QUEUE_NUM, 16);
      mmio_wr(0, R_DESC_LO, ov_desc[31:0]); mmio_wr(0, R_DESC_HI, 0);
      mmio_wr(0, R_DRV_LO, ov_avail[31:0]); mmio_wr(0, R_DRV_HI, 0);
      mmio_wr(0, R_DEV_LO, ov_used[31:0]);  mmio_wr(0, R_DEV_HI, 0);
      mmio_wr(0, R_QUEUE_READY, 1); mmio_wr(0, R_STATUS, 32'h0F);
      ov_desc = 0; ov_avail = 0; ov_used = 0;
      d_up[0] = 1; d_aidx[0] = 0; d_seq[0] = 0; d_reaped[0] = 0; d_slot[0] = 0; d_outd[0] = 0;
      // OUT 1 sector: header, data, status at IOVAs; the data crosses a 4 KiB boundary of the IOVA space (two translations)
      // d_desc/avail/used hold IOVAs, the backdoor writes below use PAs (= IOVA - 0x100000)
      begin : out_req
        reg [63:0] hdr_pa, data_pa, sta_pa;
        hdr_pa = 64'h4000; data_pa = 64'h5E00; sta_pa = 64'h4100;       // data [0x5E00, 0x6000+0x00) .. crosses 0x6000
        put_hdr(hdr_pa, 32'd1, 64'd1); gmem[sta_pa] = 8'hFF;
        for (i = 0; i < 1024; i++) gmem[data_pa + i] = rnd32(0);        // 1024 bytes: 0x5E00..0x6200 crosses 0x6000
        for (i = 0; i < 1024; i++) out_copy[i] = gmem[data_pa + i];
        n0 = iommu_nreq;
        desc_put_pa(0, 0, hdr_pa + IOVA_OFF, 16, 16'h0001, 16'd1);
        desc_put_pa(0, 1, data_pa + IOVA_OFF, 1024, 16'h0001, 16'd2);
        desc_put_pa(0, 2, sta_pa + IOVA_OFF, 1, 16'h0002, 16'd0);
        gm_put16(64'h2000 + 4, 16'd0); gm_put16(64'h2000 + 2, 16'd1);   // avail.ring[0] = 0, avail.idx = 1 (PA of the avail ring)
        mmio_wr(0, R_QUEUE_NOTIFY, 0);
        k = 0;
        while (gm_get16(64'h3002) != 16'd1 && k < 200000) begin @(posedge clk); k++; end
        check(k < 200000, "IOMMU mode: completion appears");
        check_eq(gmem[sta_pa], 0, "OUT through the IOMMU: status OK");
        for (i = 0; i < 1024; i++) if (dut_disk_byte(512 + i) !== out_copy[i]) begin check(1'b0, "IOMMU mode: disk holds the data read through the translation"); i = 1024; end
        check(iommu_nreq - n0 >= 7, "IOMMU was consulted for ring, descriptors, header, status and for each 4 KiB piece of the buffer");
      end
      // IN into the read-only mapping (IOVA 0x114000): refused by the IOMMU -> IOERR; unmapped IOVA == a raw PA -> refused
      begin : in_ro
        reg [63:0] hdr_pa, sta_pa;
        hdr_pa = 64'h4200; sta_pa = 64'h4300;
        put_hdr(hdr_pa, 32'd0, 64'd1); gmem[sta_pa] = 8'hFF;
        desc_put_pa(0, 4, hdr_pa + IOVA_OFF, 16, 16'h0001, 16'd5);
        desc_put_pa(0, 5, 64'h114100, 512, 16'h0003, 16'd6);              // read-only mapping, device-writable buffer
        desc_put_pa(0, 6, sta_pa + IOVA_OFF, 1, 16'h0002, 16'd0);
        gm_put16(64'h2000 + 4 + 2, 16'd4); gm_put16(64'h2000 + 2, 16'd2);
        mmio_wr(0, R_QUEUE_NOTIFY, 0);
        k = 0; while (gm_get16(64'h3002) != 16'd2 && k < 200000) begin @(posedge clk); k++; end
        check_eq(gmem[sta_pa], 1, "IN into a read-only IOMMU mapping -> IOERR");
        for (i = 0; i < 512; i++) if (gmem[64'h14100 + i] === 8'h00 && 1'b0) check(1'b0, "unreachable");
        hdr_pa = 64'h4400; sta_pa = 64'h4500;
        put_hdr(hdr_pa, 32'd0, 64'd1); gmem[sta_pa] = 8'hFF;
        desc_put_pa(0, 8, hdr_pa + IOVA_OFF, 16, 16'h0001, 16'd9);
        desc_put_pa(0, 9, 64'h6000, 512, 16'h0003, 16'd10);               // an IOVA that is not mapped (a raw PA used as IOVA)
        desc_put_pa(0, 10, sta_pa + IOVA_OFF, 1, 16'h0002, 16'd0);
        gm_put16(64'h2000 + 4 + 4, 16'd8); gm_put16(64'h2000 + 2, 16'd3);
        mmio_wr(0, R_QUEUE_NOTIFY, 0);
        k = 0; while (gm_get16(64'h3002) != 16'd3 && k < 200000) begin @(posedge clk); k++; end
        check_eq(gmem[sta_pa], 1, "IN to an unmapped IOVA -> IOERR");
        check(iommu_nbad >= 2, "the IOMMU model refused the requests");
        // status byte unmapped -> fatal
        hdr_pa = 64'h4600;
        put_hdr(hdr_pa, 32'd1, 64'd1);
        desc_put_pa(0, 12, hdr_pa + IOVA_OFF, 16, 16'h0001, 16'd13);
        desc_put_pa(0, 13, 64'h7000, 1, 16'h0002, 16'd0);
        gm_put16(64'h2000 + 4 + 6, 16'd12); gm_put16(64'h2000 + 2, 16'd4);
        mmio_wr(0, R_QUEUE_NOTIFY, 0);
        wait_idle(100000);
        get_fstate(0, st);
        check(st[6] && st[15:8] == 8'h10, "unmapped status byte -> fatal DMA_DENIED");
        check_eq(st[23:16], 8'h06, "adapter detail = DD_IOMMU");
      end
    end
  endtask
  task automatic desc_put_pa(input int f, input int slot, input [63:0] iova, input [31:0] len, input [15:0] flags, input [15:0] nxt);
    reg [63:0] da;
    begin
      da = 64'h1000 + 16 * slot;                       // descriptor table PA (IOVA 0x101000)
      gm_put64(da, iova); gm_put32(da + 8, len); gm_put16(da + 12, flags); gm_put16(da + 14, nxt);
    end
  endtask


  // ==================================================================== T16: doorbell races (regression of a bug found by the co-simulation)
  // A doorbell that lands while a ring poll is in flight must never be lost: the poll's data is already stale.
  task automatic t_doorbell;
    int k, st, n;
    reg [31:0] v;
    begin
      begin_test("doorbell races: kick right after DRIVER_OK, and kick while a request is running (sweep of the gap)");
      cfg_standard(1'b0, 1'b0);
      std_up(0, 16);
      // (a) the gap between DRIVER_OK and the first doorbell, 0 .. 15 cycles
      for (k = 0; k < 16; k++) begin
        drv_reset(0);
        drv_fast = 1'b1; drv_init(0, 16, 64'd0, 64'd0); drv_fast = 1'b0;
        repeat (k) @(posedge clk);
        submit_blk(0, 32'd1, k, 512, 0, 1'b1);
        drv_wait_used(0, d_seq[0], 20000);
        check_eq(gmem[last_sta], 0, "request issued shortly after DRIVER_OK completes");
        ref_finish("doorbell/a", 20000);
      end
      // (b) a second request published while the first is being served, at every offset 0 .. 900 cycles
      drv_reset(0); std_up(0, 16);
      for (k = 0; k < 900; k = k + ((k < 120) ? 3 : 29)) begin
        n = d_seq[0];
        submit_blk(0, 32'd1, 0, 512, 0, 1'b1);
        repeat (k) @(posedge clk);
        submit_blk(0, 32'd1, 1, 512, 0, 1'b1);
        drv_wait_used(0, n + 2, 30000);
        check_eq(used_idx_mem(0), (n + 2) % 65536, "both requests completed (no lost doorbell)");
        check_eq(gmem[h_sta[0*256 + (n % 256)]], 0, "first status OK");
        check_eq(gmem[h_sta[0*256 + ((n+1) % 256)]], 0, "second status OK");
        wait_idle(20000);
        ref_snap_taken = 1'b0;                      // this test checks outcomes directly; the model snapshot cannot cover a late publish
        r_kick[0] = 1'b0;
      end
      get_fstate(0, v);
      check(!v[6], "no fault");
    end
  endtask

  // ==================================================================== run
  task automatic run_all;
    begin
      if (EXT == 0) begin
        if (TESTMASK[0])  t_basic;
        if (TESTMASK[1])  t_layouts;
        if (TESTMASK[2])  t_wrap;
        if (TESTMASK[3])  t_full_empty;
        if (TESTMASK[4])  t_invalid;
        if (TESTMASK[5])  t_readonly;
        if (TESTMASK[6])  t_malformed;
        if (TESTMASK[7])  t_perm;
        if (TESTMASK[8])  t_perm_fatal;
        if (TESTMASK[9])  t_revoke;
        if (TESTMASK[10]) t_reset;
        if (TESTMASK[11]) t_features;
        if (TESTMASK[12]) t_disabled_fn;
        if (TESTMASK[13]) t_irq;
        if (TESTMASK[14]) t_perf;
        if (TESTMASK[15]) t_multi;
        if (TESTMASK[16]) t_stall;
        if (TESTMASK[17]) t_random;
        if (TESTMASK[18]) t_doorbell;
        check_eq(mon_viol, 0, "bus monitor: no forbidden guest beat in the whole run");
        check_eq(h_order_viol, 0, "completion order: used.idx never advanced before status + element were written");
      end else begin
        if (TESTMASK[0])  t_ext;
      end
    end
  endtask
