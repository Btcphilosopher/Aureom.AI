// =============================================================================
// tb_ref.svh -- INDEPENDENT GOLDEN DEVICE MODEL (descriptor + ring + virtio-blk reference), VERIFICATION ONLY
//
// A transaction-level re-implementation of what a correct device does, written from the specification text and from the
// behaviour contract in docs/ARCHITECTURE.md -- not from the RTL.  It shares no code, no state machine and no data layout
// with the RTL: the queue is processed as a straight-line program on a COPY of the guest memory (refmem) and of the disk
// (refdisk); the chain is walked with a `seen[]` array; the request streams are addressed by byte position (not by a
// segment cursor); permissions come from the testbench's own window table.
// After a scenario the DUT's whole guest memory, whole disk and per-function state must equal the model's.
//
// Behaviour contract mirrored here (every line is a deliberate, documented device decision):
//   * poll: outstanding = (avail.idx - last_avail) mod 2^16; > queue size -> fatal AVAIL_OVERRUN; 0 -> stop
//   * head >= queue size -> fatal BAD_HEAD
//   * chain faults (index, cycle, length, flags, indirect, ordering, refused fetch) -> fatal, no used entry
//   * request faults after the chain is accepted (bad header read, length, range, read-only, refused data access) -> status
//     byte IOERR + used entry; a refused/failed STATUS write or used-ring write -> fatal
//   * data moves in chunks of min(STAGE, bytes left in the segment, bytes left in the request, bytes to the next 4 KiB)
//   * used.len = bytes written into device-writable buffers (data written + status byte)
// =============================================================================

  localparam [7:0] FC_AVAIL_OVERRUN = 8'h01, FC_BAD_HEAD = 8'h02, FC_BAD_NEXT = 8'h03, FC_CYCLE = 8'h04,
                   FC_CHAIN_TOO_LONG = 8'h05, FC_BAD_FLAGS = 8'h06, FC_INDIRECT = 8'h07, FC_ORDER = 8'h08,
                   FC_SHORT_HDR = 8'h09, FC_NO_STATUS = 8'h0A, FC_DMA_DENIED = 8'h10, FC_GUEST_BUS = 8'h11;

  reg [7:0]  refmem [0:GM_BYTES-1];
  bit        q_up    [0:7];
  int        q_sz    [0:7];
  reg [63:0] q_desc  [0:7];
  reg [63:0] q_avail [0:7];
  reg [63:0] q_used  [0:7];
  reg [15:0] r_la    [0:7];
  reg [15:0] r_ui    [0:7];
  bit        r_dead  [0:7];
  reg [7:0]  r_fault [0:7];
  bit        r_kick  [0:7];
  int        r_nreq  [0:7];       // requests the model completed (for counter cross-checks)
  int        r_ndesc [0:7];
  int        r_nviol [0:7];

  task automatic r_note_init(input int f, input int qsz);
    begin
      r_nreq[f] = 0; r_ndesc[f] = 0; r_nviol[f] = 0;
      ref_snap_taken = 1'b0;                      // the copy of guest memory predates the re-initialisation
      q_up[f] = 1; q_sz[f] = qsz; q_desc[f] = d_desc[f]; q_avail[f] = d_avail[f]; q_used[f] = d_used[f];
      r_la[f] = 0; r_ui[f] = 0; r_dead[f] = 0; r_fault[f] = 0; r_kick[f] = 0;
    end
  endtask
  task automatic r_note_kick(input int f);
    begin r_kick[f] = 1; end
  endtask
  task automatic r_note_reset(input int f);
    begin q_up[f] = 0; r_la[f] = 0; r_ui[f] = 0; r_dead[f] = 0; r_fault[f] = 0; r_kick[f] = 0; ref_snap_taken = 1'b0; end
  endtask

  // ---- model memory access helpers
  function automatic [15:0] rm16(input [63:0] a);  begin rm16 = {refmem[a+1], refmem[a]}; end endfunction
  function automatic [31:0] rm32(input [63:0] a);  begin rm32 = {refmem[a+3], refmem[a+2], refmem[a+1], refmem[a]}; end endfunction
  function automatic [63:0] rm64(input [63:0] a);  begin rm64 = {rm32(a+4), rm32(a)}; end endfunction
  task automatic rw16(input [63:0] a, input [15:0] v); begin refmem[a] = v[7:0]; refmem[a+1] = v[15:8]; end endtask
  task automatic rw32(input [63:0] a, input [31:0] v); begin rw16(a, v[15:0]); rw16(a+2, v[31:16]); end endtask
  function automatic bit rbus(input [63:0] a, input [63:0] n);     // guest memory answers this access with an error
    begin rbus = (a + n > GM_BYTES) || ((err_hi != 0) && (a < err_hi) && (a + n > err_lo)); end
  endfunction

  task automatic ref_fatal(input int f, input [7:0] code);
    begin r_dead[f] = 1; r_fault[f] = code; end
  endtask

  // ---- accepted chain
  int        rc_n;
  reg [63:0] rc_addr [0:31];
  reg [31:0] rc_len  [0:31];
  bit        rc_wr   [0:31];
  reg [63:0] rc_tot_rd, rc_tot_wr;
  int        rc_ndesc;
  reg [7:0]  rw_err;

  task automatic ref_walk(input int f, input int head);
    bit seen [0:511];
    int idx, cnt, i;
    bit first, seen_wr, done;
    reg [63:0] da, a;
    reg [31:0] l;
    reg [15:0] fl, nx;
    begin
      for (i = 0; i < 512; i++) seen[i] = 0;
      idx = head; cnt = 0; first = 1; seen_wr = 0; done = 0;
      rc_n = 0; rc_tot_rd = 0; rc_tot_wr = 0; rw_err = 0; rc_ndesc = 0;
      while (!done) begin
        if (idx >= q_sz[f])        begin rw_err = first ? FC_BAD_HEAD : FC_BAD_NEXT; done = 1; end
        else if (seen[idx])        begin rw_err = FC_CYCLE; done = 1; end
        else if (cnt >= MAXCH)     begin rw_err = FC_CHAIN_TOO_LONG; done = 1; end
        else begin
          da = q_desc[f] + 16 * idx;
          if (!tb_perm(t_fdom[f], da, 16, 1'b0))  begin rw_err = FC_DMA_DENIED; done = 1; end
          else if (rbus(da, 16))                  begin rw_err = FC_GUEST_BUS; done = 1; end
          else begin
            a = rm64(da); l = rm32(da + 8); fl = rm16(da + 12); nx = rm16(da + 14);
            seen[idx] = 1; cnt++; rc_ndesc = cnt; first = 0;
            if ((fl & ~16'h0007) != 0)             begin rw_err = FC_BAD_FLAGS; done = 1; end
            else if ((fl & 16'h0004) != 0)         begin rw_err = FC_INDIRECT; done = 1; end
            else if (!fl[1] && seen_wr)            begin rw_err = FC_ORDER; done = 1; end
            else begin
              if (fl[1]) seen_wr = 1;
              if (l != 0) begin
                rc_addr[rc_n] = a; rc_len[rc_n] = l; rc_wr[rc_n] = fl[1]; rc_n++;
                if (fl[1]) rc_tot_wr = rc_tot_wr + l; else rc_tot_rd = rc_tot_rd + l;
              end
              if (fl[0]) idx = nx; else done = 1;
            end
          end
        end
      end
    end
  endtask

  // ---- byte-position addressing of the two request streams: RS (readable segments) and WS (writable segments)
  reg [63:0] sa_addr;
  reg [63:0] sa_rem;
  task automatic stream_at(input bit writable, input [63:0] pos);
    int i;
    reg [63:0] acc;
    bit found;
    begin
      acc = 0; found = 0; sa_addr = 0; sa_rem = 0;
      for (i = 0; i < rc_n; i++) begin
        if (rc_wr[i] == writable && !found) begin
          if (pos < acc + rc_len[i]) begin
            sa_addr = rc_addr[i] + (pos - acc);
            sa_rem  = acc + rc_len[i] - pos;
            found = 1;
          end
          acc = acc + rc_len[i];
        end
      end
    end
  endtask

  reg [7:0] rx_status;
  reg [31:0] rx_ulen;
  bit       rx_viol, rx_fatal;
  reg [7:0] rx_fcode;

  function automatic [63:0] umin(input [63:0] a, input [63:0] b);
    begin umin = (a < b) ? a : b; end
  endfunction

  reg [7:0] rtmp [0:8191];
  reg [7:0] rhdr [0:15];

  task automatic ref_exec(input int f);
    int d, i;
    reg [63:0] got, n, p, dtot, ea, sector, nsect, wrb, st_addr, chunk, lim;
    reg [31:0] typ;
    bit fail, isin, isout, layout_ok, bad;
    begin
      d = t_fdom[f];
      rx_status = 8'd0; rx_viol = 0; rx_fatal = 0; rx_fcode = 0; wrb = 0; fail = 0;
      if (rc_tot_wr == 0)      begin rx_fatal = 1; rx_fcode = FC_NO_STATUS; end
      else if (rc_tot_rd < 16) begin rx_fatal = 1; rx_fcode = FC_SHORT_HDR; end
      else begin
        // status byte = last byte of WS
        stream_at(1'b1, rc_tot_wr - 1);
        st_addr = sa_addr;
        // header = first 16 bytes of RS
        got = 0;
        while (got < 16 && !fail) begin
          stream_at(1'b0, got);
          n = umin(16 - got, sa_rem);
          if (!tb_perm(d, sa_addr, n, 1'b0))   begin fail = 1; rx_viol = 1; end
          else if (rbus(sa_addr, n))           begin fail = 1; end
          else begin for (i = 0; i < n; i++) rhdr[got + i] = refmem[sa_addr + i]; got = got + n; end
        end
        if (fail) rx_status = 8'd1;
        else begin
          typ = {rhdr[3], rhdr[2], rhdr[1], rhdr[0]};
          sector = {rhdr[15], rhdr[14], rhdr[13], rhdr[12], rhdr[11], rhdr[10], rhdr[9], rhdr[8]};
          isin = (typ == 0); isout = (typ == 1);
          if (!isin && !isout) rx_status = 8'd2;
          else begin
            dtot = isin ? (rc_tot_wr - 1) : (rc_tot_rd - 16);
            layout_ok = isin ? (rc_tot_rd == 16) : (rc_tot_wr == 1);
            nsect = dtot / 512;
            bad = !layout_ok || (dtot == 0) || (dtot % 512 != 0) || (isout && t_fro[f]) ||
                  (sector > t_fcap[f]) || (nsect > t_fcap[f] - sector);
            if (bad) rx_status = 8'd1;
            else begin
              p = 0;
              while (p < dtot && !fail) begin
                if (isin) stream_at(1'b1, p); else stream_at(1'b0, 16 + p);
                ea = sa_addr;
                chunk = umin(STAGE, umin(sa_rem, umin(dtot - p, 4096 - (ea % 4096))));
                if (isin) begin
                  // backend read first, then the guest write
                  if (t_pbase[d] + sector * 512 + p + chunk > t_pbase[d] + t_psize[d]) begin fail = 1; end
                  else begin
                    for (i = 0; i < chunk; i++) rtmp[i] = refdisk[t_pbase[d] + sector * 512 + p + i];
                    if (!tb_perm(d, ea, chunk, 1'b1))   begin fail = 1; rx_viol = 1; end
                    else if (rbus(ea, chunk))           begin fail = 1; end
                    else begin
                      for (i = 0; i < chunk; i++) refmem[ea + i] = rtmp[i];
                      wrb = wrb + chunk;
                    end
                  end
                end else begin
                  if (!tb_perm(d, ea, chunk, 1'b0))     begin fail = 1; rx_viol = 1; end
                  else if (rbus(ea, chunk))             begin fail = 1; end
                  else begin
                    for (i = 0; i < chunk; i++) rtmp[i] = refmem[ea + i];
                    if (t_pbase[d] + sector * 512 + p + chunk > t_pbase[d] + t_psize[d]) fail = 1;
                    else for (i = 0; i < chunk; i++) refdisk[t_pbase[d] + sector * 512 + p + i] = rtmp[i];
                  end
                end
                if (!fail) p = p + chunk;
              end
              if (fail) rx_status = 8'd1;
            end
          end
        end
        // status byte
        if (!rx_fatal) begin
          if (!tb_perm(d, st_addr, 1, 1'b1))  begin rx_fatal = 1; rx_fcode = FC_DMA_DENIED; rx_viol = 1; end
          else if (rbus(st_addr, 1))          begin rx_fatal = 1; rx_fcode = FC_GUEST_BUS; end
          else refmem[st_addr] = rx_status;
        end
        rx_ulen = wrb[31:0] + 1;
      end
    end
  endtask

  task automatic ref_serve(input int f);
    int d, qsz, n;
    reg [15:0] idx, head;
    reg [63:0] ua, ha;
    bit stop;
    begin
      d = t_fdom[f]; qsz = q_sz[f]; stop = 0;
      while (!stop) begin
        if (r_dead[f]) stop = 1;
        else if (!tb_perm(d, q_avail[f], 4, 1'b0))   begin ref_fatal(f, FC_DMA_DENIED); stop = 1; end
        else if (rbus(q_avail[f], 4))                begin ref_fatal(f, FC_GUEST_BUS); stop = 1; end
        else begin
          idx = rm16(q_avail[f] + 2);
          n = int'((idx - r_la[f]) & 16'hFFFF);
          if (n > qsz)       begin ref_fatal(f, FC_AVAIL_OVERRUN); stop = 1; end
          else if (n == 0)   stop = 1;
          else begin
            ha = q_avail[f] + 4 + 2 * (r_la[f] % qsz);
            if (!tb_perm(d, ha, 2, 1'b0))       begin ref_fatal(f, FC_DMA_DENIED); stop = 1; end
            else if (rbus(ha, 2))               begin ref_fatal(f, FC_GUEST_BUS); stop = 1; end
            else begin
              head = rm16(ha);
              if (head >= qsz) begin ref_fatal(f, FC_BAD_HEAD); stop = 1; end
              else begin
                ref_walk(f, head);
                if (rw_err != 0) begin ref_fatal(f, rw_err); stop = 1; end
                else begin
                  ref_exec(f);
                  if (rx_fatal) begin ref_fatal(f, rx_fcode); stop = 1; if (rx_fcode == FC_DMA_DENIED) r_nviol[f]++; end
                  else begin
                    ua = q_used[f] + 4 + 8 * (r_ui[f] % qsz);
                    if (!tb_perm(d, ua, 8, 1'b1)) begin
                      ref_fatal(f, FC_DMA_DENIED); stop = 1; r_nviol[f]++;                  // nothing written
                    end else begin
                      rw32(ua, {16'd0, head}); rw32(ua + 4, rx_ulen);                       // element first ...
                      if (!tb_perm(d, q_used[f] + 2, 2, 1'b1)) begin
                        ref_fatal(f, FC_DMA_DENIED); stop = 1; r_nviol[f]++;                // ... the index write is refused
                      end else begin
                        rw16(q_used[f] + 2, r_ui[f] + 16'd1);
                        r_ui[f] = r_ui[f] + 16'd1; r_la[f] = r_la[f] + 16'd1;
                        r_nreq[f]++; r_ndesc[f] = r_ndesc[f] + rc_ndesc;
                        if (rx_viol) r_nviol[f]++;
                        if (rx_viol && t_fquar[f]) begin ref_fatal(f, FC_DMA_DENIED); stop = 1; end
                      end
                    end
                  end
                end
              end
            end
          end
        end
      end
      r_kick[f] = 0;
    end
  endtask

  // ---- scenario control
  bit ref_snap_taken = 1'b0;
  task automatic ref_begin;
    integer i;
    begin
      for (i = 0; i < GM_BYTES; i++) refmem[i] = gmem[i];
    end
  endtask

  task automatic ref_zero_disk(input [31:0] base, input [31:0] size);
    integer i;
    begin for (i = 0; i < size; i++) refdisk[base + i] = 8'd0; end
  endtask

  // An aborted request (function reset in flight) may have moved some chunks to the disk before it stopped.  The model does not track the
  // partial progress of a request that never completes, so the testbench (a) requires that ONLY bytes inside the request's own extent
  // changed and (b) adopts the DUT's disk as the new baseline.
  task automatic ref_adopt_disk_after_abort(input int lo, input int len);
    integer i;
    int bad;
    begin
      bad = 0;
      for (i = 0; i < STORE; i++) begin
        if ((i < lo || i >= lo + len) && dut_disk_byte(i) !== refdisk[i]) bad++;
        refdisk[i] = dut_disk_byte(i);
      end
      check(bad == 0, "an aborted request changed only bytes inside its own extent");
    end
  endtask

  // whole-image comparison + per-function state
  int cmp_mem_bad, cmp_disk_bad;
  task automatic ref_compare(input string tag);
    integer i, f;
    reg [31:0] v;
    begin
      cmp_mem_bad = 0; cmp_disk_bad = 0;
      for (i = 0; i < GM_BYTES; i++)
        if (gmem[i] !== refmem[i]) begin
          cmp_mem_bad++;
          if (cmp_mem_bad <= 6) $display("  [CMP] %s guest memory differs at 0x%0h: dut=0x%0h model=0x%0h", tag, i, gmem[i], refmem[i]);
        end
      for (i = 0; i < STORE; i++)
        if (dut_disk_byte(i) !== refdisk[i]) begin
          cmp_disk_bad++;
          if (cmp_disk_bad <= 6) $display("  [CMP] %s disk differs at 0x%0h: dut=0x%0h model=0x%0h", tag, i, dut_disk_byte(i), refdisk[i]);
        end
      check(cmp_mem_bad == 0, {tag, ": guest memory image equals the model"});
      check(cmp_disk_bad == 0, {tag, ": disk image equals the model"});
      for (f = 0; f < NF; f++) if (q_up[f]) begin
        mg_wr(M_FUNC_SEL, f, 1'b0);
        mg_rd(M_FUNC_STATUS, v);
        check(v[6] == r_dead[f], {tag, ": NEEDS_RESET matches the model"});
        if (r_dead[f]) check_eq(v[15:8], r_fault[f], {tag, ": fault code matches the model"});
        mg_rd(M_FUNC_QSTATE, v);
        check_eq(v[15:0], r_la[f], {tag, ": last_avail matches the model"});
        check_eq(v[31:16], r_ui[f], {tag, ": used_idx matches the model"});
      end
    end
  endtask

  // run the model for every kicked function, wait for the DUT, compare
  task automatic ref_finish(input string tag, input int max_cycles);
    integer f;
    begin
      wait_idle(max_cycles);
      for (f = 0; f < NF; f++) if (q_up[f] && r_kick[f]) ref_serve(f);
      ref_compare(tag);
      ref_snap_taken = 1'b0;
    end
  endtask
