// =============================================================================
// Unit testbench :: sfv_ramdisk -- the PROTECTED BACKEND in isolation (VERIFICATION ONLY)
// The engine never names an absolute store address, and its capacity check keeps requests inside the partition -- so the
// backend's own guard cannot be reached through the engine.  This bench drives the backend port directly and requires:
//   * a beat is served only for an ENABLED domain, only inside ITS partition (base added by the store), only inside the store;
//   * everything else is answered with an error, rdata = 0 (SFB2 R8), and changes NOTHING;
//   * a domain can never read or write another domain's partition, whatever address it presents;
//   * partition commits are validated (aligned to 512, non-empty, inside the store, no overlap with an enabled partition);
//   * scrub zeroes the partition, the domain is unusable while it scrubs and the store serves no request during a scrub.
// Run: iverilog / verilator (scripts/unit.sh).
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_ramdisk;
  localparam int DW = 64, AW = 32, STORE = 8192, ND = 3, DOMW = 2, BW = DW / 8;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic              s_req_valid = 0, s_req_ready, s_req_write = 0, s_rsp_valid, s_rsp_ready = 1, s_rsp_error;
  logic [AW-1:0]     s_req_addr = 0;
  logic [DW-1:0]     s_req_wdata = 0, s_rsp_rdata;
  logic [BW-1:0]     s_req_wstrb = 0;
  logic [DOMW-1:0]   s_req_dom = 0;
  logic              pc_valid = 0, pc_en = 0, pc_scrub = 0, pc_ok;
  logic [DOMW-1:0]   pc_dom = 0;
  logic [31:0]       pc_base = 0, pc_size = 0;
  logic [ND-1:0]     part_en, part_busy;
  logic [ND*32-1:0]  part_size;

  sfv_ramdisk #(.DW(DW), .AW(AW), .STORE_BYTES(STORE), .ND(ND), .DOMW(DOMW)) dut (
    .clk, .rst_n, .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb, .s_req_dom,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error, .pc_valid, .pc_dom, .pc_base, .pc_size, .pc_en, .pc_scrub,
    .pc_ok, .part_en_o(part_en), .part_busy_o(part_busy), .part_size_o(part_size));

  logic [31:0] v1, n1, r1, v2, n2, r2;
  sfb_protocol_checker #(.AW(AW), .DW(DW), .MAX_OUT(1), .NAME("rd")) u_chk (
    .clk, .rst_n, .req_valid(s_req_valid), .req_ready(s_req_ready), .req_write(s_req_write), .req_addr(s_req_addr),
    .req_wdata(s_req_wdata), .req_wstrb(s_req_wstrb), .rsp_valid(s_rsp_valid), .rsp_ready(s_rsp_ready),
    .rsp_rdata(s_rsp_rdata), .rsp_error(s_rsp_error), .violations(v1), .n_req(n1), .n_rsp(n2), .outstanding(r1));

  int errors = 0, checks = 0;
  task automatic check(input bit c, input string m);
    begin checks++; if (!c) begin errors++; $display("  [FAIL] %s", m); end end
  endtask

  // one access; returns the response
  logic [DW-1:0] got_d;
  logic          got_e;
  task automatic access(input int dom, input bit wr, input [AW-1:0] a, input [DW-1:0] wd, input [BW-1:0] st);
    int n;
    begin
      @(posedge clk); #1;
      s_req_valid = 1; s_req_write = wr; s_req_addr = a; s_req_wdata = wd; s_req_wstrb = st; s_req_dom = dom;
      n = 0;
      while (!(s_req_valid && s_req_ready) && n < 100000) begin @(posedge clk); #1; n++; end
      @(posedge clk); #1;
      s_req_valid = 0;
      n = 0;
      while (!s_rsp_valid && n < 100) begin @(posedge clk); #1; n++; end
      got_d = s_rsp_rdata; got_e = s_rsp_error;
      if (wr || got_e) check(got_d == '0, "write / error responses carry rdata == 0 (SFB2 R8)");
    end
  endtask

  task automatic commit(input int dom, input bit en, input [31:0] base, input [31:0] size, input bit scrub, input bit expect_ok);
    int n;
    begin
      @(posedge clk); #1;
      pc_dom = dom; pc_base = base; pc_size = size; pc_en = en; pc_scrub = scrub; pc_valid = 1;
      #1 check(pc_ok == expect_ok, "partition commit verdict");
      @(posedge clk); #1;
      pc_valid = 0;
      n = 0;
      while (part_busy != 0 && n < 100000) begin @(posedge clk); n++; end
    end
  endtask

  initial begin
    repeat (4) @(posedge clk);
    #1 rst_n = 1;
    repeat (2) @(posedge clk);
    // ---- commit validation
    commit(0, 1, 0, 2048, 0, 1);                       // domain 0: [0, 2048)
    commit(1, 1, 2048, 2048, 0, 1);                    // domain 1: [2048, 4096)
    commit(2, 1, 1024, 1024, 0, 0);                    // overlaps domain 0 -> refused
    commit(2, 1, 2048, 512, 0, 0);                     // overlaps domain 1 -> refused
    commit(2, 1, 100, 512, 0, 0);                      // base not 512-aligned
    commit(2, 1, 4096, 100, 0, 0);                     // size not 512-aligned
    commit(2, 1, 4096, 0, 0, 0);                       // empty
    commit(2, 1, 8192 - 512, 1024, 0, 0);              // beyond the store
    commit(2, 1, 4096, 4096, 0, 1);                    // domain 2: [4096, 8192) accepted
    check(part_en == 3'b111, "three partitions enabled");
    // ---- data in each partition (relative addresses)
    access(0, 1, 32'h000, 64'h1111_1111_1111_1111, 8'hFF); check(!got_e, "dom0 write at its offset 0");
    access(1, 1, 32'h000, 64'h2222_2222_2222_2222, 8'hFF); check(!got_e, "dom1 write at its offset 0");
    access(2, 1, 32'h000, 64'h3333_3333_3333_3333, 8'hFF); check(!got_e, "dom2 write at its offset 0");
    access(0, 0, 32'h000, 0, 0); check(!got_e && got_d == 64'h1111_1111_1111_1111, "dom0 reads its own data");
    access(1, 0, 32'h000, 0, 0); check(!got_e && got_d == 64'h2222_2222_2222_2222, "dom1 reads its own data (not dom0's)");
    access(2, 0, 32'h000, 0, 0); check(!got_e && got_d == 64'h3333_3333_3333_3333, "dom2 reads its own data");
    // ---- byte strobes: only the strobed bytes change
    access(0, 1, 32'h008, 64'hAABB_CCDD_EEFF_0011, 8'b0000_1010);
    access(0, 0, 32'h008, 0, 0); check(!got_e && got_d == 64'h0000_0000_EE00_0000, "only the strobed bytes (1 and 3) were written");
    // ---- the last beat of the partition is served, the first beat beyond it is refused and changes nothing
    access(0, 1, 32'h7F8, 64'hDEAD_BEEF_DEAD_BEEF, 8'hFF); check(!got_e, "last beat of dom0's partition");
    access(0, 1, 32'h800, 64'hBAD0_BAD0_BAD0_BAD0, 8'hFF); check(got_e, "first beat beyond dom0's partition -> error");
    access(1, 0, 32'h000, 0, 0); check(!got_e && got_d == 64'h2222_2222_2222_2222, "dom1's first word was NOT overwritten by dom0's out-of-range write");
    access(0, 0, 32'h800, 0, 0); check(got_e && got_d == '0, "out-of-range read -> error, rdata 0");
    access(0, 0, 32'h4000_0000, 0, 0); check(got_e, "far out-of-range address -> error");
    access(0, 0, 32'hFFFF_FFF8, 0, 0); check(got_e, "address near 2^32 -> error (no wrap into the store)");
    access(1, 1, 32'h7F8, 64'h4444_4444_4444_4444, 8'hFF); check(!got_e, "dom1 last beat");
    access(1, 1, 32'h800, 64'h5555_5555_5555_5555, 8'hFF); check(got_e, "dom1 beyond its partition -> error");
    access(2, 0, 32'h000, 0, 0); check(got_d == 64'h3333_3333_3333_3333, "dom2 data intact");
    // ---- unaligned beat address and an unconfigured domain
    access(0, 0, 32'h004, 0, 0); check(got_e, "beat address not aligned to the bus width -> error");
    // ---- disabled domain: nothing is served (and its data stays)
    commit(1, 0, 0, 0, 0, 1);
    access(1, 0, 32'h000, 0, 0); check(got_e, "disabled domain -> error");
    access(1, 1, 32'h000, 64'h6666_6666_6666_6666, 8'hFF); check(got_e, "disabled domain write -> error");
    commit(1, 1, 2048, 2048, 0, 1);                     // re-enable without scrub: previous content visible (scrub is explicit)
    access(1, 0, 32'h000, 0, 0); check(!got_e && got_d == 64'h2222_2222_2222_2222, "re-enable without scrub keeps the data");
    // ---- scrub on re-ownership: the partition is zeroed, nothing is served meanwhile
    commit(1, 0, 0, 0, 1, 1);                           // disable + scrub the old partition
    commit(1, 1, 2048, 2048, 0, 1);
    access(1, 0, 32'h000, 0, 0); check(!got_e && got_d == '0, "after teardown scrub the next owner reads zeros");
    access(1, 0, 32'h7F8, 0, 0); check(!got_e && got_d == '0, "... in the whole partition");
    access(0, 0, 32'h000, 0, 0); check(!got_e && got_d == 64'h1111_1111_1111_1111, "the scrub did not touch domain 0");
    // enable with scrub: busy is visible, a second commit is refused while the scrubber runs
    begin : scr
      int n, busy_seen;
      @(posedge clk); #1; pc_dom = 2; pc_base = 4096; pc_size = 4096; pc_en = 1; pc_scrub = 1; pc_valid = 1;
      @(posedge clk); #1; pc_valid = 0;
      busy_seen = 0; n = 0;
      #1;
      check(part_busy[2] == 1'b1, "domain is busy while it scrubs");
      check(s_req_ready == 1'b0, "the store accepts no request during a scrub");
      pc_dom = 0; pc_base = 0; pc_size = 2048; pc_en = 1;
      #1 check(pc_ok == 1'b0, "a second commit is refused while the scrubber runs");
      while (part_busy != 0 && n < 100000) begin @(posedge clk); n++; end
      check(n > 100, "the scrub takes time proportional to the partition");
    end
    access(2, 0, 32'h000, 0, 0); check(!got_e && got_d == '0, "scrubbed partition reads zero");
    access(2, 0, 32'h7F8, 0, 0); check(!got_e && got_d == '0, "scrubbed partition reads zero (last word)");
    check(v1 == 0, "SFB2 protocol checker: no violation");
    $display("TB SUMMARY(ramdisk): checks=%0d errors=%0d protocol-violations=%0d", checks, errors, v1);
    if (errors == 0 && v1 == 0) $display("TB RESULT PASS"); else $display("TB RESULT FAIL");
    $finish;
  end
  initial begin #50000000; $display("TB RESULT FAIL (watchdog)"); $finish; end
endmodule

`default_nettype wire
