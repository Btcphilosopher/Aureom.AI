// =============================================================================
// tb_driver.svh -- the simulated VM driver (BFM): virtio-mmio initialisation, split-virtqueue submission, completion
// polling (VERIFICATION ONLY).  Included inside module tb_virtio.
// =============================================================================

  // virtio-mmio offsets, re-stated independently of the package
  localparam [11:0] R_MAGIC = 12'h000, R_VERSION = 12'h004, R_DEVICE_ID = 12'h008, R_VENDOR_ID = 12'h00c,
                    R_DEV_FEATURES = 12'h010, R_DEV_FEAT_SEL = 12'h014, R_DRV_FEATURES = 12'h020, R_DRV_FEAT_SEL = 12'h024,
                    R_QUEUE_SEL = 12'h030, R_QUEUE_NUM_MAX = 12'h034, R_QUEUE_NUM = 12'h038, R_QUEUE_READY = 12'h044,
                    R_QUEUE_NOTIFY = 12'h050, R_INT_STATUS = 12'h060, R_INT_ACK = 12'h064, R_STATUS = 12'h070,
                    R_DESC_LO = 12'h080, R_DESC_HI = 12'h084, R_DRV_LO = 12'h090, R_DRV_HI = 12'h094,
                    R_DEV_LO = 12'h0a0, R_DEV_HI = 12'h0a4, R_CONFIG_GEN = 12'h0fc, R_CFG_CAP_LO = 12'h100,
                    R_CFG_CAP_HI = 12'h104, R_CFG_SEG_MAX = 12'h10c, R_CFG_BLK_SIZE = 12'h114;

  // ---- per-function driver state
  int        d_qsz   [0:7];
  reg [63:0] d_desc  [0:7];
  reg [63:0] d_avail [0:7];
  reg [63:0] d_used  [0:7];
  reg [15:0] d_aidx  [0:7];
  int        d_seq   [0:7];        // requests submitted
  int        d_reaped[0:7];        // completions observed by the driver
  int        d_slot  [0:7];        // next descriptor slot
  int        d_outd  [0:7];        // descriptors currently owned by the device
  int        h_nd    [0:2047];     // descriptors used by each request (for reaping)
  reg [63:0] d_buf   [0:7];        // buffer bump allocator
  bit        d_up    [0:7];
  int        d_irq_rises [0:7];
  reg [NF-1:0] irq_prev;

  always @(posedge clk) begin
    integer f;
    for (f = 0; f < NF; f++) if (irq[f] && !irq_prev[f]) d_irq_rises[f] = d_irq_rises[f] + 1;
    irq_prev <= irq;
  end

  function automatic [63:0] f_base(input int f);
    begin f_base = dom_base(t_fdom[f]) + 64'(f / ((ND < 3) ? ND : 3)) * 64'h7000; end
  endfunction

  task automatic drv_state_reset(input int f);
    begin
      d_aidx[f] = 0; d_seq[f] = 0; d_reaped[f] = 0; d_slot[f] = 0; d_outd[f] = 0; d_up[f] = 0;
      d_buf[f] = f_base(f) + 64'h4000;
      h_armed[f] = 1'b0;
    end
  endtask

  task automatic drv_wait_status0(input int f);
    reg [31:0] v;
    int n;
    begin
      n = 0; v = 32'hFFFF;
      while (v != 0 && n < 4000) begin mmio_rd(f, R_STATUS, v); n++; end
      check(v == 0, "status reads 0 after reset");
    end
  endtask

  task automatic drv_reset(input int f);
    begin
      mmio_wr(f, R_STATUS, 32'd0);
      drv_wait_status0(f);
      drv_state_reset(f);
      r_note_reset(f);
    end
  endtask

  task automatic drv_zero_rings(input int f, input int qsz);
    integer i;
    begin
      for (i = 0; i < qsz * 16; i++) gmem[d_desc[f] + i] = 8'h00;
      for (i = 0; i < 6 + 2 * qsz; i++) gmem[d_avail[f] + i] = 8'h00;
      for (i = 0; i < 6 + 8 * qsz; i++) gmem[d_used[f] + i] = (i < 4) ? 8'h00 : 8'hFF;    // flags/idx zero; used elements poisoned
    end
  endtask

  // full initialisation sequence of spec 3.1 / 4.2.3; ok = device reached DRIVER_OK with the queue ready
  bit drv_fast = 1'b0;
  reg [63:0] ov_desc = 64'd0, ov_avail = 64'd0, ov_used = 64'd0;     // non-zero: place that ring somewhere else
  bit init_ok;
  reg [31:0] init_status;
  reg [63:0] init_offered;
  task automatic drv_init(input int f, input int qsz, input [63:0] extra_feat, input [63:0] drop_feat);
    reg [31:0] v;
    reg [63:0] accept;
    begin
      init_ok = 1'b0;
      drv_reset(f);
      d_desc[f]  = (ov_desc  != 0) ? ov_desc  : f_base(f);
      d_avail[f] = (ov_avail != 0) ? ov_avail : f_base(f) + 64'h1000;
      d_used[f]  = (ov_used  != 0) ? ov_used  : f_base(f) + 64'h2000;
      d_qsz[f] = qsz;
      mmio_rd(f, R_MAGIC, v);    check_eq(v, MAGIC, "MagicValue");
      mmio_rd(f, R_VERSION, v);  check_eq(v, 32'd2, "Version");
      mmio_rd(f, R_DEVICE_ID, v); check_eq(v, 32'd2, "DeviceID = block");
      mmio_wr(f, R_STATUS, 32'h01);
      mmio_wr(f, R_STATUS, 32'h03);
      mmio_wr(f, R_DEV_FEAT_SEL, 0); mmio_rd(f, R_DEV_FEATURES, v); init_offered[31:0] = v;
      mmio_wr(f, R_DEV_FEAT_SEL, 1); mmio_rd(f, R_DEV_FEATURES, v); init_offered[63:32] = v;
      accept = (init_offered & ~drop_feat) | extra_feat;
      mmio_wr(f, R_DRV_FEAT_SEL, 0); mmio_wr(f, R_DRV_FEATURES, accept[31:0]);
      mmio_wr(f, R_DRV_FEAT_SEL, 1); mmio_wr(f, R_DRV_FEATURES, accept[63:32]);
      mmio_wr(f, R_STATUS, 32'h0B);
      mmio_rd(f, R_STATUS, v);
      init_status = v;
      if (v[3]) begin
        mmio_wr(f, R_QUEUE_SEL, 0);
        mmio_rd(f, R_QUEUE_READY, v); check_eq(v, 0, "QueueReady is 0 before setup");
        mmio_rd(f, R_QUEUE_NUM_MAX, v); check(v >= qsz, "QueueNumMax >= wanted size");
        drv_zero_rings(f, qsz);
        mmio_wr(f, R_QUEUE_NUM, qsz);
        mmio_wr(f, R_DESC_LO, d_desc[f][31:0]);  mmio_wr(f, R_DESC_HI, d_desc[f][63:32]);
        mmio_wr(f, R_DRV_LO,  d_avail[f][31:0]); mmio_wr(f, R_DRV_HI,  d_avail[f][63:32]);
        mmio_wr(f, R_DEV_LO,  d_used[f][31:0]);  mmio_wr(f, R_DEV_HI,  d_used[f][63:32]);
        mmio_wr(f, R_QUEUE_READY, 1);
        mmio_rd(f, R_QUEUE_READY, v);
        if (v[0]) begin
          mmio_wr(f, R_STATUS, 32'h0F);
          if (drv_fast) init_ok = 1'b1;               // return at once: the doorbell race tests need the shortest DRIVER_OK -> kick gap
          else begin mmio_rd(f, R_STATUS, v); init_ok = v[2]; end
        end
      end
      if (init_ok) begin
        d_up[f] = 1'b1;
        h_armed[f] = 1'b1;
        h_used_idx_addr[f] = d_used[f] + 2;
        h_used_ring_addr[f] = d_used[f] + 4;
        h_qsz[f] = qsz;
        r_note_init(f, qsz);
      end
    end
  endtask

  // ---- descriptor chain under construction
  int        c_n;
  int        c_slot  [0:31];
  reg [63:0] c_addr  [0:31];
  reg [31:0] c_len   [0:31];
  reg [15:0] c_flags [0:31];
  reg [15:0] c_next  [0:31];

  // allocate `n` bytes (aligned to `al`) from the function's buffer area; wraps to the start of the area when exhausted
  function automatic [63:0] alloc_buf(input int f, input int n, input int al);
    reg [63:0] a;
    begin
      a = (d_buf[f] + al - 1) & ~(64'(al) - 64'd1);
      if (a + n > f_base(f) + 64'hF000) a = (f_base(f) + 64'h4000 + al - 1) & ~(64'(al) - 64'd1);
      d_buf[f] = a + n;
      alloc_buf = a;
    end
  endfunction

  task automatic chain_reset;
    begin c_n = 0; end
  endtask
  task automatic chain_add(input int f, input [63:0] addr, input [31:0] len, input bit wrf, input bit nextf);
    begin
      c_slot[c_n]  = d_slot[f] % d_qsz[f];
      d_slot[f]    = d_slot[f] + 1;
      c_addr[c_n]  = addr;
      c_len[c_n]   = len;
      c_flags[c_n] = {14'd0, wrf, nextf};
      c_n++;
    end
  endtask
  // link consecutive descriptors, write the table
  task automatic chain_commit(input int f);
    integer i;
    reg [63:0] da;
    begin
      for (i = 0; i < c_n; i++) begin
        c_next[i] = (i + 1 < c_n) ? c_slot[i+1] : 16'd0;
        c_flags[i][0] = (i + 1 < c_n);
      end
      for (i = 0; i < c_n; i++) begin
        da = d_desc[f] + 16 * c_slot[i];
        gm_put64(da, c_addr[i]);
        gm_put32(da + 8, c_len[i]);
        gm_put16(da + 12, c_flags[i]);
        gm_put16(da + 14, c_next[i]);
      end
    end
  endtask
  // explicit descriptor write (for malformed chains): slot, addr, len, flags, next
  task automatic desc_put(input int f, input int slot, input [63:0] addr, input [31:0] len, input [15:0] flags, input [15:0] nxt);
    reg [63:0] da;
    begin
      da = d_desc[f] + 16 * slot;
      gm_put64(da, addr); gm_put32(da + 8, len); gm_put16(da + 12, flags); gm_put16(da + 14, nxt);
    end
  endtask

  // publish `head` in the available ring and advance avail.idx
  task automatic publish_head(input int f, input int head);
    begin
      gm_put16(d_avail[f] + 4 + 2 * (d_aidx[f] % d_qsz[f]), head[15:0]);
      d_aidx[f] = d_aidx[f] + 16'd1;
      gm_put16(d_avail[f] + 2, d_aidx[f]);
    end
  endtask
  // the doorbell.  The first kick of a scenario freezes the model's copy of guest memory (the DUT only starts working on a kick)
  task automatic kick(input int f);
    begin
      if (!ref_snap_taken) begin ref_begin; ref_snap_taken = 1'b1; end
      r_note_kick(f);
      mmio_wr(f, R_QUEUE_NOTIFY, 32'd0);
    end
  endtask

  // ---- completion handling (driver side): poll the USED RING IN GUEST MEMORY, not the interrupt
  function automatic [15:0] used_idx_mem(input int f);
    begin used_idx_mem = gm_get16(d_used[f] + 2); end
  endfunction
  function automatic [31:0] used_id(input int f, input int k);
    begin used_id = gm_get32(d_used[f] + 4 + 8 * (k % d_qsz[f])); end
  endfunction
  function automatic [31:0] used_len(input int f, input int k);
    begin used_len = gm_get32(d_used[f] + 4 + 8 * (k % d_qsz[f]) + 4); end
  endfunction

  task automatic drv_reap(input int f);
    begin
      while (d_reaped[f] < d_seq[f] && int'(used_idx_mem(f)) != (d_reaped[f] % 65536)) begin
        d_outd[f] = d_outd[f] - h_nd[f*256 + (d_reaped[f] % 256)];
        d_reaped[f] = d_reaped[f] + 1;
      end
    end
  endtask
  // wait until `n` total completions are visible in the used ring (or time out); returns after reaping
  task automatic drv_wait_used(input int f, input int n, input int max_cycles);
    int c;
    begin
      c = 0;
      while (((int'(used_idx_mem(f)) - (d_reaped[f] % 65536) + 65536) % 65536 + d_reaped[f]) < n && c < max_cycles) begin
        @(posedge clk); c++;
      end
      check(c < max_cycles, "completion appears in the used ring (no hang)");
      drv_reap(f);
    end
  endtask
  // ensure `n` free descriptors before building another chain
  task automatic drv_reserve(input int f, input int n);
    int c;
    begin
      drv_reap(f);
      c = 0;
      while (d_outd[f] + n > d_qsz[f] && c < 2000000) begin @(posedge clk); c++; drv_reap(f); end
      check(c < 2000000, "descriptor space becomes free");
    end
  endtask

  // register the request that was just published (history for the ordering monitor and for reaping)
  task automatic hist_add(input int f, input int head, input [63:0] sta, input int nd);
    begin
      h_v[f*256 + (d_seq[f] % 256)]    = 1'b1;
      h_head[f*256 + (d_seq[f] % 256)] = head[15:0];
      h_sta[f*256 + (d_seq[f] % 256)]  = sta;
      h_nd[f*256 + (d_seq[f] % 256)]   = nd;
      d_seq[f] = d_seq[f] + 1;
      d_outd[f] = d_outd[f] + nd;
    end
  endtask

  // ---- virtio-blk request builder.  lay: 0 hdr|data|status   1 hdr+data (OUT) / data+status (IN) merged
  //      2 header split 4+12   3 data in k random segments   4 data buffer split exactly at a 4 KiB boundary
  // last_* describe what was built (for directed expectations)
  reg [63:0] last_hdr, last_data, last_sta;
  int        last_head, last_nbytes;
  reg [7:0]  fill_pat;
  task automatic submit_blk(input int f, input [31:0] typ, input [63:0] sector, input int nbytes, input int lay, input bit do_kick);
    reg [63:0] hdr, data, sta, buf0;
    int need, k, rem, seg, i, off;
    bit is_out;
    int head;
    begin
      is_out = (typ == 32'd1);
      need = (lay == 3) ? 6 : (lay == 2) ? 4 : (lay == 1) ? 2 : 3;
      drv_reserve(f, need);
      off = rndr(0, 7);
      case (lay)
        1: begin
             buf0 = alloc_buf(f, 16 + nbytes + 8 + 1 + 16, 16);
             hdr = buf0; data = buf0 + 16; sta = is_out ? alloc_buf(f, 1, 1) : data + nbytes;
           end
        4: begin
             hdr = alloc_buf(f, 16, 16);
             buf0 = alloc_buf(f, 4096 + nbytes + 16, 4096);
             data = buf0 + 4096 - (nbytes / 2);          // straddles a 4 KiB boundary
             sta = alloc_buf(f, 1, 1);
           end
        default: begin
             hdr = alloc_buf(f, 16, 16);
             data = alloc_buf(f, nbytes + 8, 8) + off;
             sta = alloc_buf(f, 1, 1);
           end
      endcase
      gm_put32(hdr, typ); gm_put32(hdr + 4, 32'd0); gm_put64(hdr + 8, sector);
      gmem[sta] = 8'hFF;
      for (i = 0; i < nbytes; i++) gmem[data + i] = is_out ? rnd32(0) : 8'hEE;
      chain_reset;
      case (lay)
        1: begin
             if (is_out) begin chain_add(f, hdr, 16 + nbytes, 1'b0, 1'b1); chain_add(f, sta, 1, 1'b1, 1'b0); end
             else        begin chain_add(f, hdr, 16, 1'b0, 1'b1); chain_add(f, data, nbytes + 1, 1'b1, 1'b0); end
           end
        2: begin
             chain_add(f, hdr, 4, 1'b0, 1'b1); chain_add(f, hdr + 4, 12, 1'b0, 1'b1);
             chain_add(f, data, nbytes, !is_out, 1'b1); chain_add(f, sta, 1, 1'b1, 1'b0);
           end
        3: begin
             chain_add(f, hdr, 16, 1'b0, 1'b1);
             k = rndr(2, ((MAXCH - 2) < 4) ? (MAXCH - 2) : 4);
             rem = nbytes;
             for (i = 0; i < k; i++) begin
               seg = (i == k - 1) ? rem : rndr(1, rem - (k - 1 - i));
               chain_add(f, data + (nbytes - rem), seg, !is_out, 1'b1);
               rem = rem - seg;
             end
             chain_add(f, sta, 1, 1'b1, 1'b0);
           end
        default: begin
             chain_add(f, hdr, 16, 1'b0, 1'b1);
             if (nbytes > 0) chain_add(f, data, nbytes, !is_out, 1'b1);
             chain_add(f, sta, 1, 1'b1, 1'b0);
           end
      endcase
      head = c_slot[0];
      chain_commit(f);
      publish_head(f, head);
      hist_add(f, head, sta, c_n);
      last_hdr = hdr; last_data = data; last_sta = sta; last_head = head; last_nbytes = nbytes;
      if (do_kick) kick(f);
    end
  endtask
