// =============================================================================
// VirtualIO testbench :: tb_sfb2_delay -- SFB2 back-pressure / latency injector (VERIFICATION ONLY)
// Sits between a master and a slave.  Request path: a request is passed to the slave only in cycles where a pseudo-random
// gate is open (probability gate_pct %).  Response path: a one-deep buffer releases the slave's response after a random
// extra delay (0 .. rsp_delay_max cycles) and holds it until the master takes it (SFB2 R4).  The protocol itself is
// preserved: one outstanding request, payload/valid held until ready, responses never in the acceptance cycle.
// =============================================================================
`default_nettype none

module tb_sfb2_delay #(
  parameter int AW   = 32,
  parameter int DW   = 64,
  parameter int DOMW = 1,
  parameter int SEED = 1
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic [7:0]      gate_pct,
  input  wire logic [7:0]      rsp_delay_max,
  input  wire logic            m_req_valid,
  output logic                 m_req_ready,
  input  wire logic            m_req_write,
  input  wire logic [AW-1:0]   m_req_addr,
  input  wire logic [DW-1:0]   m_req_wdata,
  input  wire logic [DW/8-1:0] m_req_wstrb,
  input  wire logic [DOMW-1:0] m_req_dom,
  output logic                 m_rsp_valid,
  input  wire logic            m_rsp_ready,
  output logic [DW-1:0]        m_rsp_rdata,
  output logic                 m_rsp_error,
  output logic                 s_req_valid,
  input  wire logic            s_req_ready,
  output logic                 s_req_write,
  output logic [AW-1:0]        s_req_addr,
  output logic [DW-1:0]        s_req_wdata,
  output logic [DW/8-1:0]      s_req_wstrb,
  output logic [DOMW-1:0]      s_req_dom,
  input  wire logic            s_rsp_valid,
  output logic                 s_rsp_ready,
  input  wire logic [DW-1:0]   s_rsp_rdata,
  input  wire logic            s_rsp_error
);
  logic [31:0] lfsr_q;
  logic        gate_q;
  logic        buf_v;
  logic [DW-1:0] buf_d;
  logic        buf_e;
  logic [7:0]  dly_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      lfsr_q <= 32'hACE1_0000 ^ 32'(SEED);
      gate_q <= 1'b0;
      buf_v  <= 1'b0;
      buf_d  <= '0;
      buf_e  <= 1'b0;
      dly_q  <= 8'd0;
    end else begin
      lfsr_q <= {lfsr_q[30:0], lfsr_q[31] ^ lfsr_q[21] ^ lfsr_q[1] ^ lfsr_q[0]};
      gate_q <= (gate_pct >= 8'd100) ? 1'b1 : ((lfsr_q[15:8] % 8'd100) < gate_pct);
      if (s_rsp_valid && s_rsp_ready) begin
        buf_v <= 1'b1;
        buf_d <= s_rsp_rdata;
        buf_e <= s_rsp_error;
        dly_q <= (rsp_delay_max == 8'd0) ? 8'd0 : (lfsr_q[23:16] % (rsp_delay_max + 8'd1));
      end else if (buf_v && dly_q != 8'd0) begin
        dly_q <= dly_q - 8'd1;
      end
      if (m_rsp_valid && m_rsp_ready) buf_v <= 1'b0;
    end
  end

  assign s_req_valid = m_req_valid && gate_q && !buf_v;
  assign m_req_ready = s_req_ready && gate_q && !buf_v;
  assign s_req_write = m_req_write;
  assign s_req_addr  = m_req_addr;
  assign s_req_wdata = m_req_wdata;
  assign s_req_wstrb = m_req_wstrb;
  assign s_req_dom   = m_req_dom;
  assign s_rsp_ready = !buf_v;
  assign m_rsp_valid = buf_v && (dly_q == 8'd0);
  assign m_rsp_rdata = buf_d;
  assign m_rsp_error = buf_e;
endmodule

`default_nettype wire
