// =============================================================================
// VirtualIO testbench :: tb_virtio -- system testbench for sfv_engine_core + sfv_ramdisk (VERIFICATION ONLY)
//
// A simulated VM driver (BFM) initialises virtio-blk functions over the guest MMIO port, builds split-virtqueue
// descriptors in a simulated guest memory, kicks the device and checks the results.  Checking is done four ways:
//   1. an INDEPENDENT GOLDEN DEVICE MODEL (tb_ref.svh) re-executes the same queue on a copy of the guest memory and disk
//      at transaction level (written from the specification text, sharing no code with the RTL); after every scenario the
//      WHOLE guest memory image, the whole disk image and the function state must equal the model's;
//   2. directed tests with hard-coded expected values (status bytes, used lengths, fault codes) that do not depend on the
//      model;
//   3. bus monitors: every guest-memory beat must lie inside a window of the domain being served and carry the right
//      permission (independent permission table); the vendored SFB2 protocol checker watches both ports; the used-ring
//      writes are checked for ordering (completion semantics);
//   4. performance counters are compared with values computed from the workload.
// Hierarchical references into the DUT are used only for observation (idle detection, active function) and, in one
// test, to preset the ring indices close to 2^16.
// Everything is deterministic: one xorshift generator, seed = SEED.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_virtio;
  // ------------------------------------------------------------------ configuration (override with -P / -G)
  parameter int NF       = 1;
  parameter int ND       = 2;
  parameter int NW       = 4;
  parameter int MAXQ     = 64;
  parameter int MAXCH    = 8;
  parameter int STAGE    = 64;
  parameter int AW       = 48;
  parameter int DW       = 64;
  parameter int STORE    = 65536;
  parameter int EXT      = 0;          // 1: external IOMMU mode (translation + permission by tb_iommu)
  parameter int SEED     = 1;
  parameter int STALL    = 0;          // 0 none, 1 moderate back-pressure, 2 heavy
  parameter int NRAND    = 300;        // random-regression requests
  parameter int TESTMASK = 32'hFFFF_FFFF;

  localparam int GM_BYTES = 262144;
  localparam int PART     = 16384;     // backend partition per domain
  localparam int CAPSEC   = PART / 512;
  localparam int BW       = DW / 8;
  localparam int DOMW     = (ND > 1) ? $clog2(ND) : 1;
  localparam int FW       = (NF > 1) ? $clog2(NF) : 1;

  // protocol constants used by the BFM (independent re-statement, checked against the package by make check-abi)
  localparam [31:0] MAGIC = 32'h74726976;

  // ------------------------------------------------------------------ clock / reset
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  // ------------------------------------------------------------------ DUT wiring
  logic                 mmio_req_valid = 1'b0, mmio_req_ready, mmio_req_write = 1'b0, mmio_rsp_valid, mmio_rsp_err;
  logic [15:0]          mmio_req_addr = 16'd0;
  logic [31:0]          mmio_req_wdata = 32'd0, mmio_rsp_rdata;
  logic [NF-1:0]        irq;
  logic                 mg_req_valid = 1'b0, mg_req_ready, mg_req_write = 1'b0, mg_rsp_valid, mg_rsp_err, mgmt_irq;
  logic [11:0]          mg_req_addr = 12'd0;
  logic [31:0]          mg_req_wdata = 32'd0, mg_rsp_rdata;

  logic                 gm_req_valid, gm_req_ready, gm_req_write, gm_rsp_valid, gm_rsp_ready, gm_rsp_error;
  logic [AW-1:0]        gm_req_addr;
  logic [DW-1:0]        gm_req_wdata, gm_rsp_rdata;
  logic [DW/8-1:0]      gm_req_wstrb;

  logic                 bk_req_valid, bk_req_ready, bk_req_write, bk_rsp_valid, bk_rsp_ready, bk_rsp_error;
  logic [31:0]          bk_req_addr;
  logic [DW-1:0]        bk_req_wdata, bk_rsp_rdata;
  logic [DW/8-1:0]      bk_req_wstrb;
  logic [DOMW-1:0]      bk_req_dom;
  logic                 sk_req_valid, sk_req_ready, sk_req_write, sk_rsp_valid, sk_rsp_ready, sk_rsp_error;
  logic [31:0]          sk_req_addr;
  logic [DW-1:0]        sk_req_wdata, sk_rsp_rdata;
  logic [DW/8-1:0]      sk_req_wstrb;
  logic [DOMW-1:0]      sk_req_dom;

  logic                 pc_valid, pc_en, pc_scrub, pc_ok;
  logic [DOMW-1:0]      pc_dom;
  logic [31:0]          pc_base, pc_size;
  logic [ND-1:0]        part_en, part_busy;
  logic [ND*32-1:0]     part_size;

  logic                 iommu_req_valid, iommu_req_ready, iommu_req_write, iommu_rsp_valid, iommu_rsp_ok;
  logic [DOMW-1:0]      iommu_req_dom;
  logic [63:0]          iommu_req_iova;
  logic [31:0]          iommu_req_len;
  logic [AW-1:0]        iommu_rsp_pa;

  reg [7:0]             gate_gm_pct = 8'd100, dly_gm_max = 8'd0, gate_bk_pct = 8'd100, dly_bk_max = 8'd0;

  sfv_engine_core #(.NF(NF), .ND(ND), .NW(NW), .MAX_QSZ(MAXQ), .MAX_CHAIN(MAXCH), .STAGE(STAGE), .AW(AW), .DW(DW),
                    .BKAW(32), .EXT_IOMMU(EXT), .STORE_BYTES(STORE)) dut (
    .clk, .rst_n,
    .mmio_req_valid, .mmio_req_ready, .mmio_req_write, .mmio_req_addr, .mmio_req_wdata,
    .mmio_rsp_valid, .mmio_rsp_rdata, .mmio_rsp_err, .irq_o(irq),
    .mg_req_valid, .mg_req_ready, .mg_req_write, .mg_req_addr, .mg_req_wdata,
    .mg_rsp_valid, .mg_rsp_rdata, .mg_rsp_err, .mgmt_irq_o(mgmt_irq),
    .gm_req_valid, .gm_req_ready, .gm_req_write, .gm_req_addr, .gm_req_wdata, .gm_req_wstrb,
    .gm_rsp_valid, .gm_rsp_ready, .gm_rsp_rdata, .gm_rsp_error,
    .bk_req_valid, .bk_req_ready, .bk_req_write, .bk_req_addr, .bk_req_wdata, .bk_req_wstrb, .bk_req_dom,
    .bk_rsp_valid, .bk_rsp_ready, .bk_rsp_rdata, .bk_rsp_error,
    .pc_valid, .pc_dom, .pc_base, .pc_size, .pc_en, .pc_scrub, .pc_ok,
    .part_en_i(part_en), .part_busy_i(part_busy), .part_size_i(part_size),
    .iommu_req_valid, .iommu_req_ready, .iommu_req_dom, .iommu_req_iova, .iommu_req_len, .iommu_req_write,
    .iommu_rsp_valid, .iommu_rsp_ok, .iommu_rsp_pa);

  tb_sfb2_delay #(.AW(32), .DW(DW), .DOMW(DOMW), .SEED(SEED + 11)) u_bkdly (
    .clk, .rst_n, .gate_pct(gate_bk_pct), .rsp_delay_max(dly_bk_max),
    .m_req_valid(bk_req_valid), .m_req_ready(bk_req_ready), .m_req_write(bk_req_write), .m_req_addr(bk_req_addr),
    .m_req_wdata(bk_req_wdata), .m_req_wstrb(bk_req_wstrb), .m_req_dom(bk_req_dom),
    .m_rsp_valid(bk_rsp_valid), .m_rsp_ready(bk_rsp_ready), .m_rsp_rdata(bk_rsp_rdata), .m_rsp_error(bk_rsp_error),
    .s_req_valid(sk_req_valid), .s_req_ready(sk_req_ready), .s_req_write(sk_req_write), .s_req_addr(sk_req_addr),
    .s_req_wdata(sk_req_wdata), .s_req_wstrb(sk_req_wstrb), .s_req_dom(sk_req_dom),
    .s_rsp_valid(sk_rsp_valid), .s_rsp_ready(sk_rsp_ready), .s_rsp_rdata(sk_rsp_rdata), .s_rsp_error(sk_rsp_error));

  sfv_ramdisk #(.DW(DW), .AW(32), .STORE_BYTES(STORE), .ND(ND), .DOMW(DOMW)) store (
    .clk, .rst_n,
    .s_req_valid(sk_req_valid), .s_req_ready(sk_req_ready), .s_req_write(sk_req_write), .s_req_addr(sk_req_addr),
    .s_req_wdata(sk_req_wdata), .s_req_wstrb(sk_req_wstrb), .s_req_dom(sk_req_dom),
    .s_rsp_valid(sk_rsp_valid), .s_rsp_ready(sk_rsp_ready), .s_rsp_rdata(sk_rsp_rdata), .s_rsp_error(sk_rsp_error),
    .pc_valid, .pc_dom, .pc_base, .pc_size, .pc_en, .pc_scrub, .pc_ok,
    .part_en_o(part_en), .part_busy_o(part_busy), .part_size_o(part_size));

  // SFB2 protocol checkers (vendored from DataFabric, unmodified) on both master ports of the DUT
  logic [31:0] gm_viol, gm_nreq, gm_nrsp, gm_outst, bk_viol, bk_nreq, bk_nrsp, bk_outst;
  sfb_protocol_checker #(.AW(AW), .DW(DW), .MAX_OUT(1), .NAME("gm")) u_chk_gm (
    .clk, .rst_n, .req_valid(gm_req_valid), .req_ready(gm_req_ready), .req_write(gm_req_write), .req_addr(gm_req_addr),
    .req_wdata(gm_req_wdata), .req_wstrb(gm_req_wstrb), .rsp_valid(gm_rsp_valid), .rsp_ready(gm_rsp_ready),
    .rsp_rdata(gm_rsp_rdata), .rsp_error(gm_rsp_error), .violations(gm_viol), .n_req(gm_nreq), .n_rsp(gm_nrsp), .outstanding(gm_outst));
  sfb_protocol_checker #(.AW(32), .DW(DW), .MAX_OUT(1), .NAME("bk")) u_chk_bk (
    .clk, .rst_n, .req_valid(bk_req_valid), .req_ready(bk_req_ready), .req_write(bk_req_write), .req_addr(bk_req_addr),
    .req_wdata(bk_req_wdata), .req_wstrb(bk_req_wstrb), .rsp_valid(bk_rsp_valid), .rsp_ready(bk_rsp_ready),
    .rsp_rdata(bk_rsp_rdata), .rsp_error(bk_rsp_error), .violations(bk_viol), .n_req(bk_nreq), .n_rsp(bk_nrsp), .outstanding(bk_outst));

  // ------------------------------------------------------------------ pseudo-random numbers (xorshift32, simulator independent)
  reg [31:0] rng_s;
  function automatic [31:0] rnd32(input int dummy);
    reg [31:0] x;
    begin
      x = rng_s;
      x = x ^ (x << 13);
      x = x ^ (x >> 17);
      x = x ^ (x << 5);
      rng_s = x;
      rnd32 = x;
    end
  endfunction
  function automatic int rndr(input int lo, input int hi);   // inclusive
    reg [31:0] r;
    begin
      r = rnd32(0);
      rndr = lo + int'(r % (hi - lo + 1));
    end
  endfunction

  // ------------------------------------------------------------------ result bookkeeping
  int errors = 0;
  int checks = 0;
  int test_no = 0;
  string cur_test = "";

  task automatic check(input bit cond, input string msg);
    begin
      checks++;
      if (!cond) begin
        errors++;
        if (errors <= 60) $display("  [FAIL] t=%0t  %s: %s", $time, cur_test, msg);
      end
    end
  endtask
  task automatic check_eq(input [63:0] got, input [63:0] exp, input string msg);
    begin
      checks++;
      if (got !== exp) begin
        errors++;
        if (errors <= 60) $display("  [FAIL] t=%0t  %s: %s: got 0x%0h expected 0x%0h", $time, cur_test, msg, got, exp);
      end
    end
  endtask

  // ------------------------------------------------------------------ guest memory (SFB2 slave) with back-pressure and latency
  reg [7:0] gmem [0:GM_BYTES-1];

  reg        gm_rdy_q;
  reg        gm_pend_v, gm_rsp_v_q, gm_rsp_e_q;
  int        gm_pend_cnt;
  reg [DW-1:0] gm_rsp_d_q;
  reg [DW-1:0] gm_pend_d;
  reg        gm_pend_e;
  reg [63:0] err_lo = 64'd0, err_hi = 64'd0;         // [err_lo, err_hi): guest memory answers with an error response (0,0 = none)
  int        n_gm_beats_wr = 0, n_gm_beats_rd = 0;

  assign gm_req_ready = gm_rdy_q && !gm_pend_v && !gm_rsp_v_q;
  assign gm_rsp_valid = gm_rsp_v_q;
  assign gm_rsp_error = gm_rsp_e_q;
  assign gm_rsp_rdata = gm_rsp_d_q;

  // used-ring completion-order monitor state (written by tests)
  reg [63:0] mon_used_idx_addr [0:7];                 // per function: address of used.idx
  reg        mon_used_armed [0:7];
  int        mon_ev_idx_writes = 0;

  always @(posedge clk or negedge rst_n) begin
    integer i, lat;
    reg [DW-1:0] rd;
    reg [63:0] a;
    if (!rst_n) begin
      gm_rdy_q <= 1'b0; gm_pend_v <= 1'b0; gm_rsp_v_q <= 1'b0; gm_rsp_e_q <= 1'b0; gm_rsp_d_q <= '0;
      gm_pend_cnt <= 0; gm_pend_d <= '0; gm_pend_e <= 1'b0;
    end else begin
      gm_rdy_q <= (gate_gm_pct >= 8'd100) ? 1'b1 : (rnd32(0) % 100 < gate_gm_pct);
      if (gm_rsp_v_q && gm_rsp_ready) gm_rsp_v_q <= 1'b0;
      if (gm_pend_v) begin
        if (gm_pend_cnt <= 1) begin
          gm_pend_v   <= 1'b0;
          gm_rsp_v_q  <= 1'b1;
          gm_rsp_d_q  <= gm_pend_d;
          gm_rsp_e_q  <= gm_pend_e;
        end else gm_pend_cnt <= gm_pend_cnt - 1;
      end
      if (gm_req_valid && gm_req_ready) begin
        a = {{(64-AW){1'b0}}, gm_req_addr};
        lat = 1 + ((dly_gm_max == 0) ? 0 : (rnd32(0) % (dly_gm_max + 1)));
        gm_pend_v   <= 1'b1;
        gm_pend_cnt <= lat;
        rd = '0;
        mon_beat(a, gm_req_write, gm_req_wstrb);               // monitor first: it must see the memory BEFORE this beat lands
        if ((a + BW > GM_BYTES) || ((err_hi != 0) && (a < err_hi) && (a + BW > err_lo))) begin
          gm_pend_e <= 1'b1;                                   // bus error: no side effect, rdata 0 (SFB2 R8)
          gm_pend_d <= '0;
        end else begin
          gm_pend_e <= 1'b0;
          if (gm_req_write) begin
            for (i = 0; i < BW; i++) if (gm_req_wstrb[i]) gmem[a + i] = gm_req_wdata[i*8 +: 8];
            gm_pend_d <= '0;                                    // write responses carry no data (R8)
            n_gm_beats_wr = n_gm_beats_wr + 1;
          end else begin
            for (i = 0; i < BW; i++) rd[i*8 +: 8] = gmem[a + i];
            gm_pend_d <= rd;
            n_gm_beats_rd = n_gm_beats_rd + 1;
          end
        end
      end
    end
  end

  // ------------------------------------------------------------------ behavioural external IOMMU (used when EXT = 1)
  // Mappings (IOVA -> PA = IOVA - 0x100000):  domain 0: [0x101000,0x110000) RW, [0x114000,0x115000) R only;  domain 1: [0x120000,0x130000) RW.
  // A request is granted only if the whole range lies inside ONE mapping with the needed permission (the engine never asks about
  // a range that crosses a 4 KiB boundary).  Answers one cycle after the request, or after a few random cycles.
  localparam [63:0] IOVA_OFF = 64'h0010_0000;
  int         iommu_nreq = 0;
  int         iommu_nbad = 0;
  reg         iommu_pend_v;
  int         iommu_cnt;
  reg         iommu_pend_ok;
  reg [AW-1:0] iommu_pend_pa;
  assign iommu_req_ready = !iommu_pend_v;
  always @(posedge clk or negedge rst_n) begin
    reg [63:0] lo, hi, a, n;
    bit ok;
    if (!rst_n) begin
      iommu_pend_v <= 1'b0; iommu_rsp_valid <= 1'b0; iommu_rsp_ok <= 1'b0; iommu_rsp_pa <= '0; iommu_cnt <= 0;
      iommu_pend_ok <= 1'b0; iommu_pend_pa <= '0;
    end else begin
      iommu_rsp_valid <= 1'b0;
      if (iommu_pend_v) begin
        if (iommu_cnt <= 1) begin
          iommu_pend_v <= 1'b0; iommu_rsp_valid <= 1'b1; iommu_rsp_ok <= iommu_pend_ok; iommu_rsp_pa <= iommu_pend_pa;
        end else iommu_cnt <= iommu_cnt - 1;
      end
      if (iommu_req_valid && iommu_req_ready) begin
        a = iommu_req_iova; n = {32'd0, iommu_req_len}; ok = 1'b0;
        iommu_nreq = iommu_nreq + 1;
        if (int'(iommu_req_dom) == 0) begin
          if (a >= 64'h101000 && a + n <= 64'h110000) ok = 1'b1;
          if (a >= 64'h114000 && a + n <= 64'h115000 && !iommu_req_write) ok = 1'b1;
        end else if (int'(iommu_req_dom) == 1) begin
          if (a >= 64'h120000 && a + n <= 64'h130000) ok = 1'b1;
        end
        if (!ok) iommu_nbad = iommu_nbad + 1;
        iommu_pend_v  <= 1'b1;
        iommu_cnt     <= 1 + (rnd32(0) % 3);
        iommu_pend_ok <= ok;
        iommu_pend_pa <= ok ? AW'(a - IOVA_OFF) : '0;
      end
    end
  end

  // ------------------------------------------------------------------ BFMs: guest MMIO and management port
  task automatic mmio_wr(input int f, input [11:0] off, input [31:0] v);
    begin
      @(posedge clk); #1;
      mmio_req_valid = 1'b1; mmio_req_write = 1'b1; mmio_req_addr = {f[3:0], off}; mmio_req_wdata = v;
      @(posedge clk); #1;
      mmio_req_valid = 1'b0; mmio_req_write = 1'b0;
    end
  endtask
  task automatic mmio_rd(input int f, input [11:0] off, output [31:0] v);
    begin
      @(posedge clk); #1;
      mmio_req_valid = 1'b1; mmio_req_write = 1'b0; mmio_req_addr = {f[3:0], off};
      @(posedge clk); #1;
      mmio_req_valid = 1'b0;
      // response is registered: valid in the cycle after the accept
      v = mmio_rsp_rdata;
      if (!mmio_rsp_valid) begin errors++; $display("  [FAIL] mmio_rd: no response"); end
    end
  endtask
  reg [31:0] last_mg_rdata;
  reg        last_mg_err;
  task automatic mg_wr(input [11:0] a, input [31:0] v, input bit expect_err);
    begin
      @(posedge clk); #1;
      mg_req_valid = 1'b1; mg_req_write = 1'b1; mg_req_addr = a; mg_req_wdata = v;
      @(posedge clk); #1;
      mg_req_valid = 1'b0; mg_req_write = 1'b0;
      check(mg_rsp_valid, "mgmt write: response");
      check(mg_rsp_err == expect_err, "mgmt write: error flag");
      last_mg_err = mg_rsp_err;
    end
  endtask
  task automatic mg_rd(input [11:0] a, output [31:0] v);
    begin
      @(posedge clk); #1;
      mg_req_valid = 1'b1; mg_req_write = 1'b0; mg_req_addr = a;
      @(posedge clk); #1;
      mg_req_valid = 1'b0;
      check(mg_rsp_valid, "mgmt read: response");
      v = mg_rsp_rdata;
      last_mg_err = mg_rsp_err;
    end
  endtask

  // convenience wrappers (tasks, because they consume time)
  reg [31:0] rv;
  task automatic rd32(input int f, input [11:0] off, output [31:0] v);
    begin mmio_rd(f, off, v); end
  endtask

  `include "tb_model.svh"
  `include "tb_driver.svh"
  `include "tb_ref.svh"
  `include "tb_tests.svh"

  // ------------------------------------------------------------------ main
  initial begin
    rng_s = 32'h1234_5678 ^ SEED;
    if (rng_s == 0) rng_s = 32'h1;
    run_all();
    $display("");
    $display("TB SUMMARY: tests=%0d checks=%0d errors=%0d  gm: %0d req %0d rsp %0d proto-violations  bk: %0d req %0d rsp %0d proto-violations",
             test_no, checks, errors, gm_nreq, gm_nrsp, gm_viol, bk_nreq, bk_nrsp, bk_viol);
    if (errors == 0 && gm_viol == 0 && bk_viol == 0) $display("TB RESULT PASS");
    else                                              $display("TB RESULT FAIL");
    $finish;
  end

  // global watchdog
  initial begin
    #2000000000;
    $display("TB RESULT FAIL (watchdog)");
    $finish;
  end
endmodule

`default_nettype wire
