// =============================================================================
// sfv_cosim -- Verilator co-simulation harness: the C host library (guest driver + hypervisor calls) runs against the
// Verilated silicaflux_virtio_engine (the primary RTL, wrapper = engine core + RAM-disk backend).
//
//   * guest MMIO and management registers are driven cycle by cycle through the RTL's ports;
//   * guest memory is a C++ array served by an SFB2 slave model (configurable random back-pressure and latency); the driver
//     reads/writes the same array directly (the CPU's view of RAM);
//   * SFB2 rules R2 (request held until accepted, payload stable) and R5/R8 (no response without a request, no data on error
//     or write responses) are checked every cycle on the DUT's guest-memory master port.
// Usage:  sfv_cosim demo [--stall N]
//         sfv_cosim diff <ops> <seed> [--stall N]      (software device  vs  RTL, identical op stream)
// =============================================================================
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <string>
#include "Vsilicaflux_virtio_engine.h"
#include "verilated.h"

extern "C" {
#include "sfv_host.h"
#include "sfv_softdev.h"
#include "sfv_examples.h"
}

static const uint64_t RAM_BYTES = 262144;

struct Cosim {
  Vsilicaflux_virtio_engine *d;
  uint64_t cycles = 0;
  std::vector<uint8_t> ram;
  // guest-memory slave
  uint32_t rng = 0x1234567;
  int gate_pct = 100, dly_max = 0;
  bool rdy_q = false, pend = false, rsp_v = false, rsp_e = false;
  int pend_cnt = 0;
  uint64_t rsp_d = 0, pend_d = 0;
  bool pend_e = false;
  // protocol monitor state
  bool prev_hold = false; uint64_t prev_addr = 0, prev_wdata = 0; unsigned prev_strb = 0; bool prev_wr = false;
  uint64_t n_req = 0, n_rsp = 0, proto_viol = 0, beats_rd = 0, beats_wr = 0, stall_cycles = 0;
  uint32_t mg_last_err = 0;
  bool trace_gm = false;

  Cosim() : ram(RAM_BYTES, 0) { d = new Vsilicaflux_virtio_engine; }
  ~Cosim() { d->final(); delete d; }

  uint32_t rnd32() { rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return rng; }

  void tick() {
    // ---- inputs for this cycle (slave side), then settle
    d->clk = 0;
    d->gm_req_ready = rdy_q && !pend && !rsp_v;
    d->gm_rsp_valid = rsp_v;
    d->gm_rsp_rdata = rsp_d;
    d->gm_rsp_error = rsp_e;
    d->iommu_req_ready = 1; d->iommu_rsp_valid = 0; d->iommu_rsp_ok = 0; d->iommu_rsp_pa = 0;
    d->eval();
    // ---- sample the master's request as it is presented at the clock edge
    bool v = d->gm_req_valid, rdy = d->gm_req_ready, wr = d->gm_req_write;
    uint64_t a = d->gm_req_addr, wd = d->gm_req_wdata; unsigned st = d->gm_req_wstrb;
    bool rrdy = d->gm_rsp_ready;
    if (prev_hold) {                                                         // SFB2 R2: a held request stays valid and unchanged
      if (!v || a != prev_addr || wr != prev_wr || (wr && (wd != prev_wdata || st != prev_strb))) proto_viol++;
    }
    prev_hold = v && !rdy; prev_addr = a; prev_wdata = wd; prev_strb = st; prev_wr = wr;
    if (v && !rdy) stall_cycles++;
    bool acc = v && rdy;
    // ---- rising edge
    d->clk = 1;
    d->eval();
    // ---- slave update (after the edge)
    rdy_q = (gate_pct >= 100) ? true : (int)(rnd32() % 100) < gate_pct;
    if (rsp_v && rrdy) rsp_v = false;
    if (pend) {
      if (pend_cnt <= 1) { pend = false; rsp_v = true; rsp_d = pend_d; rsp_e = pend_e; }
      else pend_cnt--;
    }
    if (acc) {
      if (trace_gm) printf("    [gm %s addr 0x%llx strb 0x%02x data 0x%016llx] cycle %llu\n", wr ? "WR" : "RD", (unsigned long long)a, st, (unsigned long long)wd, (unsigned long long)cycles);
      n_req++;
      pend = true;
      pend_cnt = 1 + (dly_max ? (int)(rnd32() % (dly_max + 1)) : 0);
      pend_e = (a + 8 > RAM_BYTES);
      pend_d = 0;
      if (!pend_e) {
        if (wr) { for (int i = 0; i < 8; i++) if (st & (1u << i)) ram[a + i] = (uint8_t)(wd >> (8 * i)); beats_wr++; }
        else { uint64_t r = 0; for (int i = 0; i < 8; i++) r |= (uint64_t)ram[a + i] << (8 * i); pend_d = r; beats_rd++; }
      }
    }
    if (rsp_v && !pend && n_rsp + 1 > n_req) proto_viol++;                   // a response without a request
    if (rsp_v && rrdy) n_rsp++;
    cycles++;
  }

  void reset() {
    d->rst_n = 0; d->mmio_req_valid = 0; d->mg_req_valid = 0; d->mmio_req_write = 0; d->mg_req_write = 0;
    for (int i = 0; i < 6; i++) tick();
    d->rst_n = 1;
    for (int i = 0; i < 4; i++) tick();
  }

  // ---- guest MMIO (32-bit accesses, one function window per 4 KiB)
  uint32_t mmio_read(unsigned f, uint32_t off) {
    d->mmio_req_valid = 1; d->mmio_req_write = 0; d->mmio_req_addr = (uint16_t)((f << 12) | off);
    tick();
    d->mmio_req_valid = 0;
    uint32_t v = d->mmio_rsp_valid ? d->mmio_rsp_rdata : 0xDEADBEEF;
    return v;
  }
  void mmio_write(unsigned f, uint32_t off, uint32_t val) {
    d->mmio_req_valid = 1; d->mmio_req_write = 1; d->mmio_req_addr = (uint16_t)((f << 12) | off); d->mmio_req_wdata = val;
    tick();
    d->mmio_req_valid = 0; d->mmio_req_write = 0;
    tick();
  }
  // ---- management port
  uint32_t mg_read(uint32_t off) {
    d->mg_req_valid = 1; d->mg_req_write = 0; d->mg_req_addr = off & 0xfff;
    tick();
    d->mg_req_valid = 0;
    uint32_t v = d->mg_rsp_rdata; mg_last_err = d->mg_rsp_err;
    tick();
    return v;
  }
  void mg_write(uint32_t off, uint32_t val) {
    d->mg_req_valid = 1; d->mg_req_write = 1; d->mg_req_addr = off & 0xfff; d->mg_req_wdata = val;
    tick();
    d->mg_req_valid = 0; d->mg_req_write = 0;
    mg_last_err = d->mg_rsp_err;
    tick();
  }
};

// ---- C callbacks
static bool g_trace = false;
static uint32_t t_rd(void *c, unsigned f, uint32_t off) { uint32_t v = ((Cosim *)c)->mmio_read(f, off); if (g_trace) printf("  [mmio rd f%u 0x%03x] = 0x%08x  (cycle %llu)\n", f, off, v, (unsigned long long)((Cosim *)c)->cycles); return v; }
static void t_wr(void *c, unsigned f, uint32_t off, uint32_t v) { if (g_trace) printf("  [mmio wr f%u 0x%03x] <= 0x%08x  (cycle %llu)\n", f, off, v, (unsigned long long)((Cosim *)c)->cycles); ((Cosim *)c)->mmio_write(f, off, v); }
static void t_mr(void *c, uint64_t a, void *dst, size_t n) { Cosim *s = (Cosim *)c; if (a + n <= RAM_BYTES) memcpy(dst, &s->ram[a], n); else memset(dst, 0xFF, n); }
static void t_mw(void *c, uint64_t a, const void *src, size_t n) { Cosim *s = (Cosim *)c; if (a + n <= RAM_BYTES) memcpy(&s->ram[a], src, n); }
static void t_wait(void *c, uint32_t u) { Cosim *s = (Cosim *)c; while (u--) s->tick(); }
static int t_irq(void *c, unsigned f) { Cosim *s = (Cosim *)c; return (s->d->irq_o >> f) & 1; }
static uint32_t m_rd(void *c, uint32_t off) { uint32_t v = ((Cosim *)c)->mg_read(off); if (g_trace) printf("  [mgmt rd 0x%03x] = 0x%08x err=%u\n", off, v, ((Cosim *)c)->mg_last_err); return v; }
static void m_wr(void *c, uint32_t off, uint32_t v) { ((Cosim *)c)->mg_write(off, v); if (g_trace) printf("  [mgmt wr 0x%03x] <= 0x%08x err=%u\n", off, v, ((Cosim *)c)->mg_last_err); }
static uint32_t m_err(void *c) { return ((Cosim *)c)->mg_last_err; }

int main(int argc, char **argv) {
  Verilated::commandArgs(argc, argv);
  std::string mode = argc > 1 ? argv[1] : "demo";
  int stall = 0;
  unsigned ops = 300; uint32_t seed = 1;
  int ai = 2;
  if (mode == "diff") { if (argc > 2) ops = (unsigned)atoi(argv[2]); if (argc > 3) seed = (uint32_t)atoi(argv[3]); ai = 4; }
  for (; ai < argc; ai++) if (!strcmp(argv[ai], "--stall") && ai + 1 < argc) stall = atoi(argv[++ai]);

  g_trace = getenv("SFV_TRACE") != nullptr;
  Cosim sim;
  sim.trace_gm = getenv("SFV_TRACE_GM") != nullptr;
  if (stall == 1) { sim.gate_pct = 60; sim.dly_max = 3; } else if (stall >= 2) { sim.gate_pct = 25; sim.dly_max = 9; }
  sim.reset();
  sfv_transport_t t; t.ctx = &sim; t.mmio_read32 = t_rd; t.mmio_write32 = t_wr; t.mem_read = t_mr; t.mem_write = t_mw; t.wait = t_wait; t.irq_level = t_irq;
  sfv_mgmt_ops_t m; m.ctx = &sim; m.read32 = m_rd; m.write32 = m_wr; m.last_error = m_err;

  int rc = 0;
  if (mode == "demo") {
    printf("vm_blk_demo on the Verilated RTL (silicaflux_virtio_engine), guest-memory back-pressure level %d\n", stall);
    rc = sfv_demo_run(&t, &m, stdout);
  } else if (mode == "diff") {
    sfv_soft_cfg_t cfg; sfv_soft_cfg_default(&cfg);
    sfv_soft_t *soft = sfv_soft_create(&cfg);
    sfv_transport_t ts; sfv_mgmt_ops_t ms;
    sfv_soft_transport(soft, &ts); sfv_soft_mgmt(soft, &ms);
    printf("differential run: software device vs Verilated RTL, %u operations, seed %u, back-pressure level %d\n", ops, seed, stall);
    rc = sfv_diff_run(&ts, &ms, &t, &m, ops, seed, stdout);
    sfv_soft_destroy(soft);
  } else { fprintf(stderr, "usage: sfv_cosim demo|diff ...\n"); return 2; }

  printf("co-simulation: %llu cycles, guest-memory beats: %llu read / %llu write, %llu cycles with a request waiting for ready, "
         "SFB2 protocol violations: %llu\n", (unsigned long long)sim.cycles, (unsigned long long)sim.beats_rd,
         (unsigned long long)sim.beats_wr, (unsigned long long)sim.stall_cycles, (unsigned long long)sim.proto_viol);
  if (sim.proto_viol) rc = rc ? rc : 1;
  printf("%s\n", rc ? "COSIM RESULT FAIL" : "COSIM RESULT PASS");
  return rc ? 1 : 0;
}
