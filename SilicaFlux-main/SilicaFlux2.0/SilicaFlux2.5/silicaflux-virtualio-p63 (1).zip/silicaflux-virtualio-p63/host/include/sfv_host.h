/*
 * SilicaFlux VirtualIO (Project 63) -- host integration library (guest-driver side + hypervisor side).
 *
 * A minimal VirtIO-blk driver for the SilicaFlux VirtIO engine (virtio-mmio version 2, split virtqueue, VIRTIO_F_VERSION_1):
 *   device initialisation (spec 3.1), queue creation (4.2.3.2), descriptor submission, notification, completion polling,
 *   interrupt acknowledge, error handling and recovery -- plus the management ("hypervisor") calls that program the DMA
 *   domains, the backend partitions and the function binding.
 *
 * The library never touches hardware directly: everything goes through an `sfv_transport_t`.  Backends shipped:
 *   - sfv_softdev     a pure-software device (host/src/sfv_softdev.c): the simulated transport used when no PCIe exists,
 *                     and an independent C reference model of the engine's behaviour;
 *   - sfv_cosim       the Verilator co-simulation of the RTL (cosim/sfv_cosim.cpp): the same driver code runs on the RTL.
 *   A real PCIe/VFIO backend is NOT provided (no PCIe endpoint exists in the repository).
 *
 * Memory model: guest memory is addressed by 64-bit guest-physical (bus) addresses through mem_read/mem_write.  The library
 * lays rings and buffers out in an ARENA [base, base+len) that the caller owns and that the hypervisor must have granted to
 * the function's DMA domain (read+write window).  All structures are little endian, as the VirtIO 1.x split ring requires.
 */
#ifndef SFV_HOST_H
#define SFV_HOST_H

#include <stdint.h>
#include <stddef.h>
#include "sfv_abi.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------ errors (negative return values) */
enum {
  SFV_OK              =  0,
  SFV_E_NO_DEVICE     = -1,   /* DeviceID 0 / bad magic: nothing behind this window */
  SFV_E_VERSION       = -2,   /* MMIO version is not 2 (legacy devices are not supported) */
  SFV_E_FEATURES      = -3,   /* FEATURES_OK refused / VIRTIO_F_VERSION_1 not offered */
  SFV_E_QUEUE         = -4,   /* queue unavailable or QueueReady refused */
  SFV_E_NEEDS_RESET   = -5,   /* the device set DEVICE_NEEDS_RESET: reset and re-initialise (sfv_recover) */
  SFV_E_FULL          = -6,   /* not enough free descriptors */
  SFV_E_INVAL         = -7,
  SFV_E_TIMEOUT       = -8,
  SFV_E_STATE         = -9,   /* call made in the wrong state (e.g. submit before DRIVER_OK) */
  SFV_E_NOMEM         = -10,  /* arena exhausted */
  SFV_E_IO            = -11   /* a block request completed with a status other than OK (see sfv_blk_result) */
};
const char *sfv_strerror(int err);

/* ------------------------------------------------------------------ transport */
typedef struct sfv_transport {
  void *ctx;
  /* guest MMIO window of one function (32-bit accesses) */
  uint32_t (*mmio_read32)(void *ctx, unsigned func, uint32_t off);
  void     (*mmio_write32)(void *ctx, unsigned func, uint32_t off, uint32_t val);
  /* guest memory as the CPU sees it (the device reads/writes the same memory by DMA) */
  void     (*mem_read)(void *ctx, uint64_t gpa, void *dst, size_t n);
  void     (*mem_write)(void *ctx, uint64_t gpa, const void *src, size_t n);
  /* let the device make progress: in simulation one unit = one device clock cycle; may be NULL on real hardware */
  void     (*wait)(void *ctx, uint32_t units);
  /* optional: level of the function's interrupt line (NULL: use polling only) */
  int      (*irq_level)(void *ctx, unsigned func);
} sfv_transport_t;

/* ------------------------------------------------------------------ driver */
#define SFV_MAX_QSZ 256u

typedef struct sfv_dev {
  const sfv_transport_t *t;
  unsigned func;
  /* negotiated */
  uint64_t offered, accepted;
  int      state;                    /* 0 none, 1 initialised (FEATURES_OK), 2 queue ready, 3 running (DRIVER_OK) */
  /* arena */
  uint64_t arena_base, arena_len, arena_next, ring_start;
  /* queue */
  uint16_t qsize;
  uint64_t desc_gpa, avail_gpa, used_gpa;
  uint16_t avail_idx, last_used;
  uint16_t free_head, nfree;
  uint16_t free_next[SFV_MAX_QSZ];
  uint16_t chain_len[SFV_MAX_QSZ];   /* descriptors owned by the chain whose head is the index */
  void    *cookie[SFV_MAX_QSZ];
  uint8_t  inflight[SFV_MAX_QSZ];
  uint32_t timeout_units;            /* wait budget for reset / polling helpers (device clocks) */
} sfv_dev_t;

typedef struct sfv_seg {
  uint64_t gpa;
  uint32_t len;
  int      device_writable;          /* 1: the device may write it (VIRTQ_DESC_F_WRITE) */
} sfv_seg_t;

typedef struct sfv_completion {
  void    *cookie;
  uint16_t head;
  uint32_t used_len;                 /* bytes the device wrote into the chain's device-writable buffers */
} sfv_completion_t;

typedef struct sfv_blk_config {
  uint64_t capacity_sectors;
  uint32_t seg_max, blk_size;
  int      read_only;
} sfv_blk_config_t;

/* Initialise function `func`: probe, reset, ACKNOWLEDGE, DRIVER, negotiate (VERSION_1 + the optional features in
 * `want_optional`, intersected with what is offered), FEATURES_OK.  The arena [arena_base, +arena_len) is where rings and
 * buffers will be placed. */
int  sfv_dev_init(sfv_dev_t *d, const sfv_transport_t *t, unsigned func, uint64_t arena_base, uint64_t arena_len,
                  uint64_t want_optional);
int  sfv_queue_create(sfv_dev_t *d, uint16_t qsize);       /* lay out rings in the arena, program the registers, QueueReady */
int  sfv_dev_start(sfv_dev_t *d);                          /* DRIVER_OK */
int  sfv_dev_reset(sfv_dev_t *d);                          /* write 0 to Status and wait for it to read 0 */
int  sfv_recover(sfv_dev_t *d);                            /* reset + re-initialise + re-create the queue + start (drops in-flight work) */
int  sfv_check_health(sfv_dev_t *d);                       /* SFV_E_NEEDS_RESET if the device flagged itself */
int  sfv_blk_config(sfv_dev_t *d, sfv_blk_config_t *cfg);  /* generation-checked read of the configuration space */

/* arena allocation (bump pointer; there is no free) */
int  sfv_alloc(sfv_dev_t *d, uint32_t size, uint32_t align, uint64_t *gpa);

/* generic submission: segments become one descriptor chain; returns the head index in *head */
int  sfv_submit(sfv_dev_t *d, const sfv_seg_t *segs, unsigned nsegs, void *cookie, uint16_t *head);
int  sfv_notify(sfv_dev_t *d);                             /* doorbell (honours used.flags NO_NOTIFY) */
int  sfv_poll(sfv_dev_t *d, sfv_completion_t *out);        /* 1 = one completion reaped, 0 = none, <0 = error */
int  sfv_wait_completion(sfv_dev_t *d, sfv_completion_t *out, uint32_t max_units);
uint32_t sfv_irq_pending(sfv_dev_t *d);                    /* InterruptStatus */
void sfv_irq_ack(sfv_dev_t *d, uint32_t bits);
void sfv_set_no_interrupt(sfv_dev_t *d, int suppress);     /* avail.flags NO_INTERRUPT */

/* virtio-blk convenience: build {header, data, status} and submit.  The caller supplies guest buffers. */
int  sfv_blk_submit(sfv_dev_t *d, int is_write, uint64_t sector, uint64_t data_gpa, uint32_t nbytes,
                    uint64_t hdr_gpa, uint64_t status_gpa, void *cookie, uint16_t *head);
int  sfv_blk_status(sfv_dev_t *d, uint64_t status_gpa);    /* the status byte (0 OK, 1 IOERR, 2 UNSUPP, 0xFF = not written) */
/* synchronous helper: allocate buffers in the arena, submit, notify, wait, return 0 or a negative SFV_E_* (IOERR -> SFV_E_IO) */
int  sfv_blk_rw(sfv_dev_t *d, int is_write, uint64_t sector, void *buf, uint32_t nbytes, int *blk_status, uint32_t *used_len);

/* ------------------------------------------------------------------ hypervisor / management plane */
typedef struct sfv_mgmt_ops {
  void *ctx;
  uint32_t (*read32)(void *ctx, uint32_t off);
  void     (*write32)(void *ctx, uint32_t off, uint32_t val);
  uint32_t (*last_error)(void *ctx);                       /* 1 if the last access was answered with an error */
} sfv_mgmt_ops_t;

typedef struct sfv_hv_caps { uint32_t nfuncs, ndomains, nwin, ext_iommu, max_qsz, max_chain, stage_log2, store_bytes; } sfv_hv_caps_t;
int  sfv_hv_probe(const sfv_mgmt_ops_t *m, sfv_hv_caps_t *caps);
int  sfv_hv_set_window(const sfv_mgmt_ops_t *m, unsigned dom, unsigned win, uint64_t base, uint64_t size, int r, int w, int valid);
int  sfv_hv_set_domain(const sfv_mgmt_ops_t *m, unsigned dom, int enable, uint32_t part_base, uint32_t part_size, int scrub);
int  sfv_hv_set_function(const sfv_mgmt_ops_t *m, unsigned func, int enable, unsigned dom, uint64_t cap_sectors, int ro, int quarantine);
int  sfv_hv_func_state(const sfv_mgmt_ops_t *m, unsigned func, uint32_t *status, uint32_t *fault_code, uint32_t *fault_detail,
                       uint32_t *last_avail, uint32_t *used_idx);
uint32_t sfv_hv_perf(const sfv_mgmt_ops_t *m, unsigned func, unsigned counter);
void sfv_hv_perf_clear(const sfv_mgmt_ops_t *m);

#ifdef __cplusplus
}
#endif
#endif
