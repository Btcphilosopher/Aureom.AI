/*
 * sfv_softdev -- a pure-software VirtIO-blk device implementing the SAME behaviour contract as the SilicaFlux VirtIO engine RTL
 * (docs/ARCHITECTURE.md): virtio-mmio v2 registers, split virtqueue, the descriptor-chain validation rules, the virtio-blk
 * executor, per-domain DMA windows, a partitioned RAM-disk, fault/NEEDS_RESET handling and the management plane.
 *
 * Two jobs:  (1) the SIMULATED TRANSPORT BACKEND for the host library when no PCIe/RTL is present;
 *            (2) an independent C reference model, used for differential testing against the Verilated RTL (examples/sfv_diff).
 * It is synchronous: queued work is executed when the driver rings the doorbell (and again on wait()).  It has no notion of
 * cycles: latency counters read 0.  It is a model, not hardware: it proves nothing about timing, only about behaviour.
 */
#ifndef SFV_SOFTDEV_H
#define SFV_SOFTDEV_H
#include "sfv_host.h"
#ifdef __cplusplus
extern "C" {
#endif

typedef struct sfv_soft sfv_soft_t;
typedef struct sfv_soft_cfg {
  unsigned nfuncs, ndomains, nwin;
  unsigned max_qsz, max_chain, stage_bytes, addr_bits, bus_bytes;   /* must match the RTL configuration being modelled */
  uint32_t store_bytes;
  uint64_t ram_bytes;                                               /* simulated guest memory */
} sfv_soft_cfg_t;

void sfv_soft_cfg_default(sfv_soft_cfg_t *c);                       /* the RTL defaults: 1 function, 2 domains, 4 windows, 64 / 8 / 64 / 48 / 8, 64 KiB store, 256 KiB RAM */
sfv_soft_t *sfv_soft_create(const sfv_soft_cfg_t *c);
void sfv_soft_destroy(sfv_soft_t *s);
void sfv_soft_transport(sfv_soft_t *s, sfv_transport_t *t);
void sfv_soft_mgmt(sfv_soft_t *s, sfv_mgmt_ops_t *m);
uint8_t *sfv_soft_ram(sfv_soft_t *s);
uint8_t *sfv_soft_disk(sfv_soft_t *s);

#ifdef __cplusplus
}
#endif
#endif
