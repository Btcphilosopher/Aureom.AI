/*
 * sfv_diff -- differential test of two device backends driven through the SAME host library.
 * Both sides receive an identical, deterministic stream of operations (valid requests with odd alignments and descriptor
 * layouts, request-level errors, permission-denied buffers, malformed chains with recovery, resets).  After every operation the
 * observable state of both sides must be identical: return codes, status byte, used length, device status / fault code /
 * queue indices (management plane), and a digest of the whole VM memory window.
 * Used with (software device, software device) as a self-check of the harness and with (software device, Verilated RTL) as an
 * independent C-level cross-check of the RTL.
 */
#include <stdio.h>
#include <string.h>
#include "sfv_examples.h"

#define VM_BASE   0x1000ull
#define VM_SIZE   0xF000ull
#define CAP       32u

typedef struct { const sfv_transport_t *t; const sfv_mgmt_ops_t *m; sfv_dev_t d; } side_t;
typedef struct { int rc, bst; uint32_t used, status, fcode, la, ui; uint64_t digest; uint32_t viol, fatal, req_done, desc, rd_data, wr_data, irq, irq_supp, req_err, kicks; } obs_t;

static uint32_t rng_s;
static uint32_t rnd(void) { rng_s ^= rng_s << 13; rng_s ^= rng_s >> 17; rng_s ^= rng_s << 5; return rng_s; }
static uint32_t rr(uint32_t lo, uint32_t hi) { return lo + rnd() % (hi - lo + 1); }

static uint64_t digest(const sfv_transport_t *t) {
  uint8_t buf[4096];
  uint64_t h = 1469598103934665603ull, a, i;
  for (a = VM_BASE; a < VM_BASE + VM_SIZE; a += sizeof buf) {
    uint64_t n = VM_BASE + VM_SIZE - a < sizeof buf ? VM_BASE + VM_SIZE - a : sizeof buf;
    t->mem_read(t->ctx, a, buf, (size_t)n);
    for (i = 0; i < n; i++) { h ^= buf[i]; h *= 1099511628211ull; }
  }
  return h;
}

static void fill(uint8_t *p, uint32_t n, uint32_t seed) { uint32_t i, x = seed * 2654435761u + 7; for (i = 0; i < n; i++) { x = x * 1664525u + 1013904223u; p[i] = (uint8_t)(x >> 24); } }

static int setup(side_t *s, const sfv_transport_t *t, const sfv_mgmt_ops_t *m) {
  int rc;
  s->t = t; s->m = m;
  if ((rc = sfv_hv_set_window(m, 0, 0, VM_BASE, VM_SIZE, 1, 1, 1))) return rc;
  if ((rc = sfv_hv_set_domain(m, 0, 1, 0, CAP * 512, 1))) return rc;
  if ((rc = sfv_hv_set_function(m, 0, 1, 0, CAP, 0, 0))) return rc;
  if ((rc = sfv_dev_init(&s->d, t, 0, VM_BASE, VM_SIZE, 0))) return rc;
  if ((rc = sfv_queue_create(&s->d, 16))) return rc;
  return sfv_dev_start(&s->d);
}

static void snap(side_t *s, obs_t *o) {
  /* let the device settle: the guest sees used.idx as soon as the write LANDS in memory, but the engine's internal indices and
   * the notification (a ring re-poll) follow after the write response returns -- several hundred cycles under heavy back-pressure */
  if (s->t->wait) s->t->wait(s->t->ctx, 3000);
  sfv_hv_func_state(s->m, 0, &o->status, &o->fcode, 0, &o->la, &o->ui);
  o->digest = digest(s->t);
  o->viol = sfv_hv_perf(s->m, 0, SFV_PC_VIOLATIONS);
  o->fatal = sfv_hv_perf(s->m, 0, SFV_PC_FATAL);
  o->req_done = sfv_hv_perf(s->m, 0, SFV_PC_REQ_DONE);  o->desc = sfv_hv_perf(s->m, 0, SFV_PC_DESC);
  o->rd_data = sfv_hv_perf(s->m, 0, SFV_PC_DMA_RD_DATA); o->wr_data = sfv_hv_perf(s->m, 0, SFV_PC_DMA_WR_DATA);
  o->irq = sfv_hv_perf(s->m, 0, SFV_PC_IRQ_RAISED);      o->irq_supp = sfv_hv_perf(s->m, 0, SFV_PC_IRQ_SUPPRESSED);
  o->req_err = sfv_hv_perf(s->m, 0, SFV_PC_REQ_ERR);     o->kicks = sfv_hv_perf(s->m, 0, SFV_PC_KICKS);
}

/* one request with an explicit segment layout; header written here */
typedef struct { uint32_t typ; uint64_t sector; uint32_t nbytes; int lay; uint64_t data_override; int data_override_set; } req_t;

static void run_req(side_t *s, const req_t *r, obs_t *o, const uint8_t *wdata) {
  sfv_dev_t *d = &s->d;
  uint64_t save = d->arena_next, hdr = 0, data = 0, sta = 0;
  sfv_seg_t sg[8];
  sfv_completion_t c;
  uint8_t h[16], ff = 0xFF;
  unsigned n = 0, i;
  int is_out = (r->typ == SFV_BLK_T_OUT);
  memset(o, 0, sizeof *o);
  sfv_alloc(d, 16, 16, &hdr); sfv_alloc(d, r->nbytes + 16, 8, &data); sfv_alloc(d, 1, 1, &sta);
  data += (r->lay >> 4) & 7;                                              /* unaligned data buffers */
  if (r->data_override_set) data = r->data_override;
  memset(h, 0, 16); h[0] = (uint8_t)r->typ; h[1] = (uint8_t)(r->typ >> 8); h[2] = (uint8_t)(r->typ >> 16); h[3] = (uint8_t)(r->typ >> 24);
  for (i = 0; i < 8; i++) h[8 + i] = (uint8_t)(r->sector >> (8 * i));
  s->t->mem_write(s->t->ctx, hdr, h, 16);
  s->t->mem_write(s->t->ctx, sta, &ff, 1);
  if (is_out && r->nbytes && !r->data_override_set) s->t->mem_write(s->t->ctx, data, wdata, r->nbytes);
  switch (r->lay & 15) {
    case 1:  sg[n].gpa = hdr; sg[n].len = 4; sg[n].device_writable = 0; n++;                         /* header split 4 + 12 */
             sg[n].gpa = hdr + 4; sg[n].len = 12; sg[n].device_writable = 0; n++; break;
    case 2:  sg[n].gpa = hdr; sg[n].len = 16; sg[n].device_writable = 0; n++;                         /* a zero-length readable seg */
             sg[n].gpa = 0x30000; sg[n].len = 0; sg[n].device_writable = 0; n++; break;
    default: sg[n].gpa = hdr; sg[n].len = 16; sg[n].device_writable = 0; n++; break;
  }
  if (r->nbytes) {
    if ((r->lay & 15) == 3 && r->nbytes >= 1024) {                                                   /* data in three segments */
      uint32_t a = 100, b = r->nbytes / 2;
      sg[n].gpa = data; sg[n].len = a; sg[n].device_writable = !is_out; n++;
      sg[n].gpa = data + a; sg[n].len = b - a; sg[n].device_writable = !is_out; n++;
      sg[n].gpa = data + b; sg[n].len = r->nbytes - b; sg[n].device_writable = !is_out; n++;
    } else { sg[n].gpa = data; sg[n].len = r->nbytes; sg[n].device_writable = !is_out; n++; }
  }
  sg[n].gpa = sta; sg[n].len = 1; sg[n].device_writable = 1; n++;
  o->rc = sfv_submit(d, sg, n, 0, 0);
  if (o->rc == SFV_OK) {
    sfv_notify(d);
    o->rc = sfv_wait_completion(d, &c, 400000);
    if (o->rc == SFV_OK) { o->bst = sfv_blk_status(d, sta); o->used = c.used_len; }
  }
  d->arena_next = save;
  snap(s, o);
}

static void raw_fatal(side_t *s, unsigned kind, obs_t *o) {
  sfv_dev_t *d = &s->d;
  uint8_t desc[16], ring[2], idx[2];
  uint64_t a;
  memset(o, 0, sizeof *o);
  memset(desc, 0, 16); desc[8] = 16;
  switch (kind) {
    case 0: desc[12] = 1; desc[14] = 0; break;                       /* self loop */
    case 1: desc[12] = 1; desc[14] = 16; break;                      /* next out of range (queue 16) */
    case 2: desc[12] = 8; break;                                     /* reserved flag */
    case 3: desc[12] = 4; break;                                     /* indirect */
    default: desc[12] = 0; break;                                    /* readable only: no status byte */
  }
  a = d->desc_gpa;
  s->t->mem_write(s->t->ctx, a, desc, 16);
  ring[0] = 0; ring[1] = 0;
  s->t->mem_write(s->t->ctx, d->avail_gpa + 4u + 2u * (d->avail_idx % d->qsize), ring, 2);
  d->avail_idx++; idx[0] = (uint8_t)d->avail_idx; idx[1] = (uint8_t)(d->avail_idx >> 8);
  s->t->mem_write(s->t->ctx, d->avail_gpa + 2u, idx, 2);
  sfv_notify(d);
  s->t->wait(s->t->ctx, 6000);
  o->rc = sfv_check_health(d);
  snap(s, o);
}

static int same(const obs_t *a, const obs_t *b) { return memcmp(a, b, sizeof *a) == 0; }

int sfv_diff_run(const sfv_transport_t *ta, const sfv_mgmt_ops_t *ma, const sfv_transport_t *tb, const sfv_mgmt_ops_t *mb,
                 unsigned nops, uint32_t seed, FILE *log) {
  side_t A, B;
  obs_t oa, ob;
  uint8_t wdata[4096];
  unsigned i, mism = 0, nfatal = 0, nerr = 0, nok = 0;
  int rc;
  rng_s = seed ? seed : 1;
  if ((rc = setup(&A, ta, ma)) || (rc = setup(&B, tb, mb))) { fprintf(log, "diff: setup failed: %s\n", sfv_strerror(rc)); return 1; }
  for (i = 0; i < nops; i++) {
    uint32_t kind = rr(0, 99), seedv = rnd(), arg1 = rnd(), arg2 = rnd(), arg3 = rnd();
    req_t r;
    const char *what;
    memset(&r, 0, sizeof r);
    fill(wdata, sizeof wdata, seedv);
    if (kind < 55) {                                                         /* valid request */
      uint32_t ns = 1 + arg1 % 3;
      r.typ = (arg2 & 1) ? SFV_BLK_T_OUT : SFV_BLK_T_IN; r.nbytes = 512 * ns; r.sector = arg3 % (CAP - ns + 1);
      r.lay = (int)(arg2 >> 8) % 4 | (int)((arg3 >> 10) % 8) << 4; what = "valid";
    } else if (kind < 65) {                                                  /* length / range errors */
      r.typ = (arg2 & 1) ? SFV_BLK_T_OUT : SFV_BLK_T_IN;
      switch (arg1 % 4) { case 0: r.nbytes = 100; r.sector = 1; break; case 1: r.nbytes = 512; r.sector = CAP - (arg3 & 1); break;
                          case 2: r.nbytes = 1024; r.sector = CAP - 1; break; default: r.nbytes = 513; r.sector = 0; }
      what = "request error";
    } else if (kind < 72) {                                                  /* unsupported types */
      r.typ = (arg1 & 1) ? 4u : (arg1 & 2) ? 8u : 5u; r.nbytes = (r.typ == 8) ? 20 : 0; what = "unsupported type";
    } else if (kind < 86) {                                                  /* permission-denied buffer */
      r.typ = (arg2 & 1) ? SFV_BLK_T_OUT : SFV_BLK_T_IN; r.nbytes = 512; r.sector = 2;
      r.data_override_set = 1; r.data_override = (arg1 & 1) ? 0x30000ull : 0x20000ull + 8 * (arg3 % 100); what = "permission denied";
    } else if (kind < 92) {                                                  /* malformed chain, then recovery */
      raw_fatal(&A, arg1 % 5, &oa); raw_fatal(&B, arg1 % 5, &ob);
      if (!same(&oa, &ob)) { mism++; fprintf(log, "  MISMATCH op %u (malformed chain kind %u)\n", i, arg1 % 5); }
      if (oa.rc != SFV_E_NEEDS_RESET) { mism++; fprintf(log, "  op %u: malformed chain did not stop the device\n", i); }
      nfatal++;
      rc = sfv_recover(&A.d); if (rc) { mism++; fprintf(log, "  recover A: %s\n", sfv_strerror(rc)); }
      rc = sfv_recover(&B.d); if (rc) { mism++; fprintf(log, "  recover B: %s\n", sfv_strerror(rc)); }
      continue;
    } else {                                                                 /* driver-initiated reset + re-init */
      rc = sfv_recover(&A.d); if (rc) mism++;
      rc = sfv_recover(&B.d); if (rc) mism++;
      continue;
    }
    run_req(&A, &r, &oa, wdata);
    run_req(&B, &r, &ob, wdata);
    if (!same(&oa, &ob)) {
      mism++;
      fprintf(log, "  MISMATCH op %u (%s): rc %d/%d status %d/%d used %u/%u dev %02x/%02x la %u/%u ui %u/%u viol %u/%u digest %016llx/%016llx\n"
                   "      counters done %u/%u desc %u/%u rd %u/%u wr %u/%u irq %u/%u supp %u/%u err %u/%u kicks %u/%u fatal %u/%u\n",
              i, what, oa.rc, ob.rc, oa.bst, ob.bst, oa.used, ob.used, oa.status, ob.status, oa.la, ob.la, oa.ui, ob.ui, oa.viol, ob.viol,
              (unsigned long long)oa.digest, (unsigned long long)ob.digest, oa.req_done, ob.req_done, oa.desc, ob.desc, oa.rd_data, ob.rd_data,
              oa.wr_data, ob.wr_data, oa.irq, ob.irq, oa.irq_supp, ob.irq_supp, oa.req_err, ob.req_err, oa.kicks, ob.kicks, oa.fatal, ob.fatal);
    }
    if (oa.rc == SFV_OK && oa.bst == 0) nok++; else nerr++;
  }
  fprintf(log, "diff: %u operations (%u ok, %u refused/errored, %u malformed-chain recoveries): %u mismatch(es)\n", nops, nok, nerr, nfatal, mism);
  return (int)mism;
}
