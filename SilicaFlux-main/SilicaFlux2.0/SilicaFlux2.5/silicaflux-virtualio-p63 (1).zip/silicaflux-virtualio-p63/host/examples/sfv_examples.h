/* Shared entry points of the host examples (each runs on ANY transport: the software device or the Verilated RTL). */
#ifndef SFV_EXAMPLES_H
#define SFV_EXAMPLES_H
#include <stdio.h>
#include "sfv_host.h"
#ifdef __cplusplus
extern "C" {
#endif

/* The simulated-VM demonstration (definition of done):
 *   hypervisor: grants the VM's memory window and a disk partition, enables the function;
 *   guest driver: initialises the device, creates the queue, writes sectors with chained descriptors, reads them back,
 *   shows request errors, a protected-memory violation, a malformed chain with NEEDS_RESET + recovery, then prints counters.
 * Returns 0 if every check passed, else the number of failed checks. */
int sfv_demo_run(const sfv_transport_t *t, const sfv_mgmt_ops_t *m, FILE *log);

/* Differential run: the same pseudo-random operation stream on two backends; returns the number of observable mismatches. */
int sfv_diff_run(const sfv_transport_t *ta, const sfv_mgmt_ops_t *ma, const sfv_transport_t *tb, const sfv_mgmt_ops_t *mb,
                 unsigned nops, uint32_t seed, FILE *log);

#ifdef __cplusplus
}
#endif
#endif
