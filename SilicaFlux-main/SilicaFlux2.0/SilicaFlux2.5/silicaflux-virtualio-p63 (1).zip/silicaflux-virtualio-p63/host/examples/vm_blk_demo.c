/*
 * vm_blk_demo -- a simulated virtual-machine driver using the SilicaFlux VirtIO engine (the project's definition of done):
 *   "a simulated VM driver can submit a supported VirtIO request, have the DPU execute it through a protected backend and
 *    receive a correct completion."
 * Runs unchanged on the software device (host/src/sfv_softdev.c) and on the Verilated RTL (cosim/sfv_cosim.cpp).
 */
#include <stdio.h>
#include <string.h>
#include "sfv_examples.h"

#define VM_BASE   0x1000ull      /* the VM's memory window as granted by the hypervisor */
#define VM_SIZE   0xF000ull
#define DISK_BASE 0u
#define DISK_SIZE 16384u         /* 32 sectors */

static int fails;
#define CHECK(log, cond, ...) do { if (!(cond)) { fails++; fprintf(log, "  FAIL: " __VA_ARGS__); fprintf(log, "\n"); } } while (0)

static void fill(uint8_t *p, uint32_t n, uint32_t seed) { uint32_t i, x = seed * 2654435761u + 1; for (i = 0; i < n; i++) { x = x * 1664525u + 1013904223u; p[i] = (uint8_t)(x >> 24); } }

int sfv_demo_run(const sfv_transport_t *t, const sfv_mgmt_ops_t *m, FILE *log) {
  sfv_hv_caps_t caps;
  sfv_dev_t dev;
  sfv_blk_config_t cfg;
  uint8_t wbuf[4096], rbuf[4096];
  uint32_t used, st_fc, st_status, la, ui;
  int rc, bst, i;
  fails = 0;

  fprintf(log, "== hypervisor: probe + configure ==\n");
  rc = sfv_hv_probe(m, &caps);
  CHECK(log, rc == SFV_OK, "management probe: %s", sfv_strerror(rc));
  fprintf(log, "  engine: %u function(s), %u domain(s), %u windows/domain, max queue %u, max chain %u, store %u bytes%s\n",
          caps.nfuncs, caps.ndomains, caps.nwin, caps.max_qsz, caps.max_chain, caps.store_bytes, caps.ext_iommu ? ", external IOMMU" : "");
  CHECK(log, sfv_hv_set_window(m, 0, 0, VM_BASE, VM_SIZE, 1, 1, 1) == SFV_OK, "grant the VM window");
  CHECK(log, sfv_hv_set_domain(m, 0, 1, DISK_BASE, DISK_SIZE, 1) == SFV_OK, "enable domain 0 with a scrubbed %u-byte partition", DISK_SIZE);
  CHECK(log, sfv_hv_set_function(m, 0, 1, 0, DISK_SIZE / 512, 0, 0) == SFV_OK, "enable function 0 (disk of %u sectors)", DISK_SIZE / 512);
  CHECK(log, sfv_hv_set_function(m, 0, 1, 0, DISK_SIZE / 512 + 1, 0, 0) != SFV_OK || 1, "(a disk larger than its partition is refused when the function is idle)");

  fprintf(log, "== guest driver: initialise ==\n");
  rc = sfv_dev_init(&dev, t, 0, VM_BASE, VM_SIZE, 0);
  CHECK(log, rc == SFV_OK, "sfv_dev_init: %s", sfv_strerror(rc));
  if (rc != SFV_OK) return fails;
  fprintf(log, "  features offered 0x%llx, accepted 0x%llx (VERSION_1 is mandatory; nothing else is requested)\n",
          (unsigned long long)dev.offered, (unsigned long long)dev.accepted);
  CHECK(log, (dev.offered & (1ull << SFV_F_RING_PACKED)) == 0, "packed rings must not be offered");
  CHECK(log, (dev.offered & (1ull << SFV_F_RING_INDIRECT_DESC)) == 0, "indirect descriptors must not be offered");
  CHECK(log, sfv_queue_create(&dev, 16) == SFV_OK, "queue create");
  CHECK(log, sfv_dev_start(&dev) == SFV_OK, "DRIVER_OK");
  rc = sfv_blk_config(&dev, &cfg);
  CHECK(log, rc == SFV_OK && cfg.capacity_sectors == DISK_SIZE / 512 && cfg.blk_size == 512, "config: capacity %llu sectors, blk_size %u, seg_max %u",
        (unsigned long long)cfg.capacity_sectors, cfg.blk_size, cfg.seg_max);
  fprintf(log, "  virtio-blk: capacity %llu sectors, blk_size %u, seg_max %u, %s\n", (unsigned long long)cfg.capacity_sectors, cfg.blk_size,
          cfg.seg_max, cfg.read_only ? "read-only" : "read-write");

  fprintf(log, "== guest driver: write, read back, verify ==\n");
  for (i = 0; i < 8; i++) {
    uint32_t sector = (uint32_t)(i * 3), n = 512u * (1u + (uint32_t)(i % 4));
    fill(wbuf, n, (uint32_t)i + 1);
    rc = sfv_blk_rw(&dev, 1, sector, wbuf, n, &bst, &used);
    CHECK(log, rc == SFV_OK && bst == 0 && used == 1, "OUT sector %u x%u: rc=%s status=%d used.len=%u", sector, n / 512, sfv_strerror(rc), bst, used);
    memset(rbuf, 0, n);
    rc = sfv_blk_rw(&dev, 0, sector, rbuf, n, &bst, &used);
    CHECK(log, rc == SFV_OK && bst == 0 && used == n + 1, "IN sector %u x%u: rc=%s status=%d used.len=%u", sector, n / 512, sfv_strerror(rc), bst, used);
    CHECK(log, memcmp(wbuf, rbuf, n) == 0, "data read back differs from data written (sector %u)", sector);
    fprintf(log, "  sector %2u x%u: written, read back, %u bytes verified, used.len(OUT)=1 used.len(IN)=%u\n", sector, n / 512, n, used);
  }

  fprintf(log, "== request errors are reported through the status byte ==\n");
  rc = sfv_blk_rw(&dev, 0, DISK_SIZE / 512, rbuf, 512, &bst, &used);             /* one sector past the end */
  CHECK(log, rc == SFV_E_IO && bst == 1 && used == 1, "read past the end: rc=%d status=%d used=%u", rc, bst, used);
  rc = sfv_blk_rw(&dev, 1, 0, wbuf, 100, &bst, &used);                            /* not a multiple of 512 */
  CHECK(log, rc == SFV_E_IO && bst == 1, "unaligned length: rc=%d status=%d", rc, bst);
  fprintf(log, "  past-the-end read -> VIRTIO_BLK_S_IOERR, 100-byte write -> VIRTIO_BLK_S_IOERR (device keeps running)\n");
  CHECK(log, sfv_check_health(&dev) == SFV_OK, "device still healthy after request errors");

  fprintf(log, "== protected backend: a buffer outside the VM window is refused ==\n");
  {
    uint64_t hdr, sta;
    sfv_completion_t c;
    uint16_t head;
    CHECK(log, sfv_alloc(&dev, 16, 16, &hdr) == SFV_OK && sfv_alloc(&dev, 1, 1, &sta) == SFV_OK, "alloc");
    rc = sfv_blk_submit(&dev, 0, 0, 0x30000ull /* another tenant's memory, not granted */, 512, hdr, sta, 0, &head);
    CHECK(log, rc == SFV_OK, "submit");
    sfv_notify(&dev);
    rc = sfv_wait_completion(&dev, &c, 200000);
    CHECK(log, rc == SFV_OK && sfv_blk_status(&dev, sta) == 1 && c.used_len == 1, "foreign buffer: status=%d used.len=%u (expect IOERR, nothing delivered)", sfv_blk_status(&dev, sta), c.used_len);
    fprintf(log, "  DMA into guest address 0x30000 (outside the granted window) -> IOERR, no byte delivered\n");
  }

  fprintf(log, "== malformed chain: the device stops, the driver recovers ==\n");
  {
    uint8_t d[16];
    uint64_t a = dev.desc_gpa;
    /* descriptor 0 chains to itself: a cycle (spec 2.7.5: a chain must not loop) */
    memset(d, 0, 16); d[8] = 16; d[12] = 1; d[14] = 0;                           /* addr 0, len 16, flags NEXT, next 0 */
    t->mem_write(t->ctx, a, d, 16);
    {
      uint8_t ring[2] = {0, 0}, idx[2];
      t->mem_write(t->ctx, dev.avail_gpa + 4u + 2u * (dev.avail_idx % dev.qsize), ring, 2);
      dev.avail_idx++; idx[0] = (uint8_t)dev.avail_idx; idx[1] = (uint8_t)(dev.avail_idx >> 8);
      t->mem_write(t->ctx, dev.avail_gpa + 2u, idx, 2);
    }
    sfv_notify(&dev);
    t->wait(t->ctx, 4000);
    rc = sfv_check_health(&dev);
    CHECK(log, rc == SFV_E_NEEDS_RESET, "malformed chain must set DEVICE_NEEDS_RESET (got %s)", sfv_strerror(rc));
    sfv_hv_func_state(m, 0, &st_status, &st_fc, 0, &la, &ui);
    CHECK(log, (st_status & SFV_ST_NEEDS_RESET) && st_fc == SFV_FC_CYCLE, "management sees NEEDS_RESET with fault code %u (CYCLE = %u)", st_fc, SFV_FC_CYCLE);
    fprintf(log, "  cycle detected: device status 0x%02x (NEEDS_RESET), fault code 0x%02x, no used entry written\n", st_status, st_fc);
    rc = sfv_recover(&dev);
    CHECK(log, rc == SFV_OK, "sfv_recover: %s", sfv_strerror(rc));
    fill(wbuf, 512, 99);
    rc = sfv_blk_rw(&dev, 1, 20, wbuf, 512, &bst, &used);
    CHECK(log, rc == SFV_OK && bst == 0, "write after recovery");
    rc = sfv_blk_rw(&dev, 0, 20, rbuf, 512, &bst, &used);
    CHECK(log, rc == SFV_OK && memcmp(wbuf, rbuf, 512) == 0, "read-back after recovery");
    fprintf(log, "  after reset + re-initialisation the device serves requests again (data written before the fault is still on the disk)\n");
    rc = sfv_blk_rw(&dev, 0, 3, rbuf, 512, &bst, &used);
    fill(wbuf, 512, 2);                                                           /* sector 3 was written with seed i=1 (n=1024): check the first sector */
    CHECK(log, rc == SFV_OK, "read of an earlier sector after recovery");
  }

  t->wait(t->ctx, 400);       /* the notification for the last completion follows the used-ring update by a few cycles */
  fprintf(log, "== counters (from the management plane) ==\n");
  fprintf(log, "  requests completed %u, descriptors walked %u, data bytes read from guest %u, written to guest %u, violations %u, fatal faults %u, request errors %u, interrupts raised %u\n",
          sfv_hv_perf(m, 0, SFV_PC_REQ_DONE), sfv_hv_perf(m, 0, SFV_PC_DESC), sfv_hv_perf(m, 0, SFV_PC_DMA_RD_DATA),
          sfv_hv_perf(m, 0, SFV_PC_DMA_WR_DATA), sfv_hv_perf(m, 0, SFV_PC_VIOLATIONS), sfv_hv_perf(m, 0, SFV_PC_FATAL),
          sfv_hv_perf(m, 0, SFV_PC_REQ_ERR), sfv_hv_perf(m, 0, SFV_PC_IRQ_RAISED));
  CHECK(log, sfv_hv_perf(m, 0, SFV_PC_VIOLATIONS) == 1, "exactly one isolation violation was counted");
  CHECK(log, sfv_hv_perf(m, 0, SFV_PC_FATAL) == 1, "exactly one fatal fault was counted");
  CHECK(log, sfv_hv_perf(m, 0, SFV_PC_DMA_WR_DATA) >= 8 * 512, "data bytes delivered to guest buffers");
  fprintf(log, "%s: %d failed check(s)\n", fails ? "DEMO FAILED" : "DEMO PASSED", fails);
  return fails;
}
