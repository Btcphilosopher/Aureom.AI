/* Self-check of the differential harness: the software device against a second instance of itself. */
#include <stdio.h>
#include <stdlib.h>
#include "sfv_softdev.h"
#include "sfv_examples.h"

int main(int argc, char **argv) {
  sfv_soft_cfg_t cfg;
  sfv_soft_t *a, *b;
  sfv_transport_t ta, tb;
  sfv_mgmt_ops_t ma, mb;
  unsigned n = argc > 1 ? (unsigned)atoi(argv[1]) : 400;
  uint32_t seed = argc > 2 ? (uint32_t)atoi(argv[2]) : 1;
  int mism;
  sfv_soft_cfg_default(&cfg);
  a = sfv_soft_create(&cfg); b = sfv_soft_create(&cfg);
  sfv_soft_transport(a, &ta); sfv_soft_mgmt(a, &ma); sfv_soft_transport(b, &tb); sfv_soft_mgmt(b, &mb);
  mism = sfv_diff_run(&ta, &ma, &tb, &mb, n, seed, stdout);
  sfv_soft_destroy(a); sfv_soft_destroy(b);
  return mism ? 1 : 0;
}
