/* vm_blk_demo on the SOFTWARE device (simulated transport; no RTL needed). */
#include <stdio.h>
#include "sfv_softdev.h"
#include "sfv_examples.h"

int main(void) {
  sfv_soft_cfg_t cfg;
  sfv_soft_t *s;
  sfv_transport_t t;
  sfv_mgmt_ops_t m;
  int fails;
  sfv_soft_cfg_default(&cfg);
  s = sfv_soft_create(&cfg);
  if (!s) { fprintf(stderr, "out of memory\n"); return 2; }
  sfv_soft_transport(s, &t);
  sfv_soft_mgmt(s, &m);
  printf("vm_blk_demo on the software device (simulated transport)\n");
  fails = sfv_demo_run(&t, &m, stdout);
  sfv_soft_destroy(s);
  return fails ? 1 : 0;
}
