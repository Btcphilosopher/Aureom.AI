/*
 * sfv_softdev -- software VirtIO-blk device with the behaviour contract of the SilicaFlux VirtIO engine.  See sfv_softdev.h.
 * Written from docs/ARCHITECTURE.md and the VirtIO split-ring rules, NOT by translating the RTL or the SystemVerilog model.
 */
#include <stdlib.h>
#include <string.h>
#include "sfv_softdev.h"

#define MAXF 8
#define MAXD 8
#define MAXW 8

typedef struct { uint64_t base, size; int r, w, v; } win_t;
typedef struct { int en; win_t w[MAXW]; uint32_t pbase, psize; int pen; } dom_t;

typedef struct {
  int en, ro, quar; unsigned dom; uint64_t cap;
  uint8_t status; uint32_t dsel, hsel, qsel; uint64_t dfeat; uint32_t qnum; int qready;
  uint64_t desc, avail, used; uint32_t intst;
  int pend; uint16_t la, ui; uint8_t fcode, fdet; uint32_t fcnt;
  uint64_t ctr[SFV_PC_N];
} fn_t;

struct sfv_soft {
  sfv_soft_cfg_t c;
  uint8_t *ram, *disk;
  fn_t f[MAXF];
  dom_t d[MAXD];
  /* management shadows */
  uint32_t dsel, wsel, fsel, wb_lo, wb_hi, ws_lo, ws_hi, pb_sh, ps_sh, fdom_sh, fcap_lo, fcap_hi, psel_ctr, psel_func, fault, fie;
  uint32_t mg_err;
};

void sfv_soft_cfg_default(sfv_soft_cfg_t *c) {
  c->nfuncs = 1; c->ndomains = 2; c->nwin = 4; c->max_qsz = 64; c->max_chain = 8; c->stage_bytes = 64; c->addr_bits = 48;
  c->bus_bytes = 8; c->store_bytes = 65536; c->ram_bytes = 262144;
}

sfv_soft_t *sfv_soft_create(const sfv_soft_cfg_t *c) {
  sfv_soft_t *s = (sfv_soft_t *)calloc(1, sizeof *s);
  if (!s) return 0;
  s->c = *c;
  s->ram = (uint8_t *)calloc(1, c->ram_bytes);
  s->disk = (uint8_t *)calloc(1, c->store_bytes);
  if (!s->ram || !s->disk) { free(s->ram); free(s->disk); free(s); return 0; }
  return s;
}
void sfv_soft_destroy(sfv_soft_t *s) { if (s) { free(s->ram); free(s->disk); free(s); } }
uint8_t *sfv_soft_ram(sfv_soft_t *s) { return s->ram; }
uint8_t *sfv_soft_disk(sfv_soft_t *s) { return s->disk; }

/* ---------------------------------------------------------------- guest access with the domain permission check */
enum { A_OK = 0, A_DENIED = 1, A_BUS = 2 };

static int dom_usable(const sfv_soft_t *s, unsigned dom) { return dom < s->c.ndomains && s->d[dom].en && s->d[dom].pen; }

static int perm_ok(const sfv_soft_t *s, unsigned dom, uint64_t a, uint64_t n, int wr) {
  unsigned w;
  uint64_t lim = 1ull << s->c.addr_bits;                 /* addr_bits <= 63; every comparison below is overflow-free */
  if (!dom_usable(s, dom) || n == 0) return 0;
  if (a > lim || n > lim - a) return 0;                  /* beyond the address width or wrapping */
  for (w = 0; w < s->c.nwin; w++) {
    const win_t *x = &s->d[dom].w[w];
    if (x->v && a >= x->base && n <= x->size && (a - x->base) <= (x->size - n) && (wr ? x->w : x->r)) return 1;
  }
  return 0;
}

static int g_read(sfv_soft_t *s, const fn_t *f, uint64_t a, uint64_t n, uint8_t *out) {
  if (!perm_ok(s, f->dom, a, n, 0)) return A_DENIED;
  if (a + n > s->c.ram_bytes) return A_BUS;
  memcpy(out, s->ram + a, n);
  return A_OK;
}
static int g_write(sfv_soft_t *s, const fn_t *f, uint64_t a, uint64_t n, const uint8_t *in) {
  if (!perm_ok(s, f->dom, a, n, 1)) return A_DENIED;
  if (a + n > s->c.ram_bytes) return A_BUS;
  memcpy(s->ram + a, in, n);
  return A_OK;
}

static uint16_t L16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static uint32_t L32(const uint8_t *p) { return (uint32_t)L16(p) | ((uint32_t)L16(p + 2) << 16); }
static uint64_t L64(const uint8_t *p) { return (uint64_t)L32(p) | ((uint64_t)L32(p + 4) << 32); }
static void S16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void S32(uint8_t *p, uint32_t v) { S16(p, (uint16_t)v); S16(p + 2, (uint16_t)(v >> 16)); }

/* ---------------------------------------------------------------- device processing */
static void fatal(sfv_soft_t *s, fn_t *f, unsigned idx, uint8_t code) {
  f->status |= SFV_ST_NEEDS_RESET;
  f->intst |= SFV_INT_CONFIG;
  f->fcode = code; f->fcnt++;
  f->ctr[SFV_PC_FATAL]++;
  f->pend = 0;
  s->fault |= 1u << idx;
}

typedef struct { uint64_t a; uint32_t l; int w; } seg_t;

static uint64_t umin64(uint64_t a, uint64_t b) { return a < b ? a : b; }

/* position -> (address, bytes left in that segment) in the readable or writable stream */
static int stream_at(const seg_t *sg, unsigned n, int writable, uint64_t pos, uint64_t *addr, uint64_t *rem) {
  uint64_t acc = 0;
  unsigned i;
  for (i = 0; i < n; i++) {
    if ((sg[i].w != 0) != (writable != 0)) continue;
    if (pos < acc + sg[i].l) { *addr = sg[i].a + (pos - acc); *rem = acc + sg[i].l - pos; return 1; }
    acc += sg[i].l;
  }
  return 0;
}

static void process(sfv_soft_t *s, unsigned fi) {
  fn_t *f = &s->f[fi];
  unsigned qsz = f->qnum;
  int due = 0;
  uint8_t b[16];
  while (1) {
    uint16_t idx, flags, head, n_av;
    int rc;
    if (!(f->status & SFV_ST_DRIVER_OK) || (f->status & (SFV_ST_NEEDS_RESET | SFV_ST_FAILED)) || !f->qready) return;
    if ((rc = g_read(s, f, f->avail, 4, b)) != A_OK) { fatal(s, f, fi, rc == A_DENIED ? SFV_FC_DMA_DENIED : SFV_FC_GUEST_BUS); if (rc == A_DENIED) f->ctr[SFV_PC_VIOLATIONS]++; return; }
    f->ctr[SFV_PC_DMA_META] += 4;
    flags = L16(b); idx = L16(b + 2);
    if (due) { if (flags & SFV_AVAIL_F_NO_INTERRUPT) f->ctr[SFV_PC_IRQ_SUPPRESSED]++; else { f->intst |= SFV_INT_VRING; f->ctr[SFV_PC_IRQ_RAISED]++; } due = 0; }
    n_av = (uint16_t)(idx - f->la);
    f->ctr[SFV_PC_UTIL_SUM] += n_av; f->ctr[SFV_PC_UTIL_SAMPLES]++; if (n_av > f->ctr[SFV_PC_UTIL_MAX]) f->ctr[SFV_PC_UTIL_MAX] = n_av;
    if (n_av > qsz) { fatal(s, f, fi, SFV_FC_AVAIL_OVERRUN); return; }
    if (n_av == 0) { f->pend = 0; return; }
    /* head */
    if ((rc = g_read(s, f, f->avail + 4 + 2ull * (f->la % qsz), 2, b)) != A_OK) { fatal(s, f, fi, rc == A_DENIED ? SFV_FC_DMA_DENIED : SFV_FC_GUEST_BUS); if (rc == A_DENIED) f->ctr[SFV_PC_VIOLATIONS]++; return; }
    f->ctr[SFV_PC_DMA_META] += 2;
    head = L16(b);
    if (head >= qsz) { fatal(s, f, fi, SFV_FC_BAD_HEAD); return; }
    /* walk */
    {
      seg_t sg[MAXW * 4 + 64];
      unsigned nsg = 0, cnt = 0, i;
      uint8_t seen[SFV_MAX_QSZ + 1];
      uint64_t tot_rd = 0, tot_wr = 0;
      unsigned cur = head;
      int first = 1, seen_wr = 0, done = 0;
      uint8_t werr = 0;
      memset(seen, 0, sizeof seen);
      while (!done) {
        uint64_t da; uint64_t a; uint32_t l; uint16_t fl, nx;
        if (cur >= qsz) { werr = first ? SFV_FC_BAD_HEAD : SFV_FC_BAD_NEXT; break; }
        if (seen[cur]) { werr = SFV_FC_CYCLE; break; }
        if (cnt >= s->c.max_chain) { werr = SFV_FC_CHAIN_TOO_LONG; break; }
        da = f->desc + 16ull * cur;
        if ((rc = g_read(s, f, da, 16, b)) != A_OK) { werr = (rc == A_DENIED) ? SFV_FC_DMA_DENIED : SFV_FC_GUEST_BUS; break; }
        f->ctr[SFV_PC_DMA_META] += 16;
        a = L64(b); l = L32(b + 8); fl = L16(b + 12); nx = L16(b + 14);
        seen[cur] = 1; cnt++; first = 0;
        if (fl & ~SFV_DESC_F_KNOWN) { werr = SFV_FC_BAD_FLAGS; break; }
        if (fl & SFV_DESC_F_INDIRECT) { werr = SFV_FC_INDIRECT; break; }
        if (!(fl & SFV_DESC_F_WRITE) && seen_wr) { werr = SFV_FC_ORDER; break; }
        if (fl & SFV_DESC_F_WRITE) seen_wr = 1;
        if (l) {
          sg[nsg].a = a; sg[nsg].l = l; sg[nsg].w = (fl & SFV_DESC_F_WRITE) != 0; nsg++;
          if (fl & SFV_DESC_F_WRITE) tot_wr += l; else tot_rd += l;
        }
        if (fl & SFV_DESC_F_NEXT) cur = nx; else done = 1;
      }
      if (werr) { if (werr == SFV_FC_DMA_DENIED) f->ctr[SFV_PC_VIOLATIONS]++; fatal(s, f, fi, werr); return; }
      f->ctr[SFV_PC_DESC] += cnt; f->ctr[SFV_PC_WALK_COUNT]++;          /* counted for ACCEPTED chains only (as the RTL does) */
      /* execute */
      {
        uint8_t status = SFV_BLK_S_OK, hdr[16], tmp[4096];
        uint64_t wrb = 0, st_addr, ad, rem, p, got, dtot, sector, nsect;
        int viol = 0, fail = 0, isin, isout;
        uint32_t typ;
        uint64_t part_base = s->d[f->dom].pbase, part_size = s->d[f->dom].psize;
        if (tot_wr == 0) { fatal(s, f, fi, SFV_FC_NO_STATUS); return; }
        if (tot_rd < 16) { fatal(s, f, fi, SFV_FC_SHORT_HDR); return; }
        stream_at(sg, nsg, 1, tot_wr - 1, &st_addr, &rem);
        got = 0;
        while (got < 16 && !fail) {
          stream_at(sg, nsg, 0, got, &ad, &rem);
          i = (unsigned)umin64(16 - got, rem);
          rc = g_read(s, f, ad, i, hdr + got);
          if (rc != A_OK) { fail = 1; viol = (rc == A_DENIED); } else { got += i; f->ctr[SFV_PC_DMA_META] += i; }
        }
        if (fail) status = SFV_BLK_S_IOERR;
        else {
          typ = L32(hdr); sector = L64(hdr + 8);
          isin = (typ == SFV_BLK_T_IN); isout = (typ == SFV_BLK_T_OUT);
          if (!isin && !isout) status = SFV_BLK_S_UNSUPP;
          else {
            dtot = isin ? tot_wr - 1 : tot_rd - 16;
            nsect = dtot / 512;
            if (!(isin ? tot_rd == 16 : tot_wr == 1) || dtot == 0 || (dtot % 512) || (isout && f->ro) || sector > f->cap || nsect > f->cap - sector)
              status = SFV_BLK_S_IOERR;
            else {
              p = 0;
              while (p < dtot && !fail) {
                uint64_t chunk;
                stream_at(sg, nsg, isin ? 1 : 0, isin ? p : 16 + p, &ad, &rem);
                chunk = umin64(s->c.stage_bytes, umin64(rem, umin64(dtot - p, 4096 - (ad % 4096))));
                if (isin) {
                  if (sector * 512 + p + chunk > part_size) { fail = 1; }
                  else {
                    memcpy(tmp, s->disk + part_base + sector * 512 + p, chunk);
                    rc = g_write(s, f, ad, chunk, tmp);
                    if (rc != A_OK) { fail = 1; viol = (rc == A_DENIED); } else { wrb += chunk; f->ctr[SFV_PC_DMA_WR_DATA] += chunk; }
                  }
                } else {
                  rc = g_read(s, f, ad, chunk, tmp);
                  if (rc != A_OK) { fail = 1; viol = (rc == A_DENIED); }
                  else if (sector * 512 + p + chunk > part_size) fail = 1;
                  else { memcpy(s->disk + part_base + sector * 512 + p, tmp, chunk); f->ctr[SFV_PC_DMA_RD_DATA] += chunk; }
                }
                if (!fail) p += chunk;
              }
              if (fail) status = SFV_BLK_S_IOERR;
            }
          }
        }
        rc = g_write(s, f, st_addr, 1, &status);
        if (rc != A_OK) { if (rc == A_DENIED) f->ctr[SFV_PC_VIOLATIONS]++; fatal(s, f, fi, rc == A_DENIED ? SFV_FC_DMA_DENIED : SFV_FC_GUEST_BUS); return; }
        f->ctr[SFV_PC_DMA_META] += 1;
        /* complete: element first, then the index */
        S32(b, head); S32(b + 4, (uint32_t)(wrb + 1));
        rc = g_write(s, f, f->used + 4 + 8ull * (f->ui % qsz), 8, b);
        if (rc != A_OK) { if (rc == A_DENIED) f->ctr[SFV_PC_VIOLATIONS]++; fatal(s, f, fi, rc == A_DENIED ? SFV_FC_DMA_DENIED : SFV_FC_GUEST_BUS); return; }
        f->ctr[SFV_PC_DMA_META] += 8;
        S16(b, (uint16_t)(f->ui + 1));
        rc = g_write(s, f, f->used + 2, 2, b);
        if (rc != A_OK) { if (rc == A_DENIED) f->ctr[SFV_PC_VIOLATIONS]++; fatal(s, f, fi, rc == A_DENIED ? SFV_FC_DMA_DENIED : SFV_FC_GUEST_BUS); return; }
        f->ctr[SFV_PC_DMA_META] += 2;
        f->ui++; f->la++; due = 1;
        f->ctr[SFV_PC_REQ_DONE]++;
        if (status != SFV_BLK_S_OK) f->ctr[SFV_PC_REQ_ERR]++;
        if (viol) f->ctr[SFV_PC_VIOLATIONS]++;
        if (viol && f->quar) { fatal(s, f, fi, SFV_FC_DMA_DENIED); return; }
      }
    }
  }
}

static void run_all(sfv_soft_t *s) {
  unsigned i;
  for (i = 0; i < s->c.nfuncs; i++) if (s->f[i].pend) process(s, i);
}

/* ---------------------------------------------------------------- virtio-mmio register block */
static uint64_t dev_features(const sfv_soft_t *s, const fn_t *f) {
  uint64_t v = (1ull << SFV_F_VERSION_1) | (1ull << SFV_BLK_F_SEG_MAX) | (1ull << SFV_BLK_F_BLK_SIZE);
  (void)s;
  if (f->ro) v |= 1ull << SFV_BLK_F_RO;
  return v;
}

static int queue_valid(const sfv_soft_t *s, const fn_t *f) {
  uint64_t lim = 1ull << s->c.addr_bits;
  uint32_t q = f->qnum;
  if (q == 0 || (q & (q - 1)) || q > s->c.max_qsz) return 0;
  if ((f->desc & 15) || (f->avail & 1) || (f->used & 3)) return 0;
  if (f->desc > lim || 16ull * q > lim - f->desc) return 0;
  if (f->avail > lim || 2ull * q + 6 > lim - f->avail) return 0;
  if (f->used > lim || 8ull * q + 6 > lim - f->used) return 0;
  return 1;
}

static void func_reset(fn_t *f) {
  uint64_t keep_ctr[SFV_PC_N];
  int en = f->en, ro = f->ro, quar = f->quar; unsigned dom = f->dom; uint64_t cap = f->cap;
  uint8_t fcode = f->fcode, fdet = f->fdet; uint32_t fcnt = f->fcnt;
  memcpy(keep_ctr, f->ctr, sizeof keep_ctr);
  memset(f, 0, sizeof *f);
  f->en = en; f->ro = ro; f->quar = quar; f->dom = dom; f->cap = cap; f->fcode = fcode; f->fdet = fdet; f->fcnt = fcnt;
  memcpy(f->ctr, keep_ctr, sizeof keep_ctr);
}

static uint32_t mmio_rd(sfv_soft_t *s, unsigned fi, uint32_t off) {
  fn_t *f;
  if (fi >= s->c.nfuncs) return 0;
  f = &s->f[fi];
  switch (off) {
    case SFV_R_MAGIC: return SFV_MMIO_MAGIC;
    case SFV_R_VERSION: return SFV_MMIO_VERSION;
    case SFV_R_DEVICE_ID: return f->en ? SFV_DEVICE_ID_BLOCK : 0;
    case SFV_R_VENDOR_ID: return SFV_VENDOR_ID;
    case SFV_R_DEV_FEATURES: if (!f->en) return 0; { uint64_t v = dev_features(s, f); return f->dsel == 0 ? (uint32_t)v : f->dsel == 1 ? (uint32_t)(v >> 32) : 0; }
    case SFV_R_QUEUE_NUM_MAX: return (f->en && f->qsel == 0) ? s->c.max_qsz : 0;
    case SFV_R_QUEUE_READY: return f->en && f->qsel == 0 && f->qready;
    case SFV_R_INT_STATUS: return f->en ? f->intst : 0;
    case SFV_R_STATUS: return f->en ? f->status : 0;
    case SFV_R_CONFIG_GEN: return 0;
    case SFV_CFG_CAPACITY_LO: return f->en ? (uint32_t)f->cap : 0;
    case SFV_CFG_CAPACITY_HI: return f->en ? (uint32_t)(f->cap >> 32) : 0;
    case SFV_CFG_SEG_MAX: return f->en ? s->c.max_chain - 2 : 0;
    case SFV_CFG_BLK_SIZE: return f->en ? 512 : 0;
    default: return 0;
  }
}

static void mmio_wr(sfv_soft_t *s, unsigned fi, uint32_t off, uint32_t v) {
  fn_t *f;
  if (fi >= s->c.nfuncs) return;
  f = &s->f[fi];
  if (!f->en) return;
  switch (off) {
    case SFV_R_DEV_FEAT_SEL: f->dsel = v; break;
    case SFV_R_DRV_FEAT_SEL: f->hsel = v; break;
    case SFV_R_DRV_FEATURES:
      if (!(f->status & SFV_ST_FEATURES_OK)) { if (f->hsel == 0) f->dfeat = (f->dfeat & ~0xffffffffull) | v; else if (f->hsel == 1) f->dfeat = (f->dfeat & 0xffffffffull) | ((uint64_t)v << 32); }
      break;
    case SFV_R_QUEUE_SEL: f->qsel = v; break;
    case SFV_R_QUEUE_NUM: if (f->qsel == 0 && !f->qready) f->qnum = v & 0xffff; break;
    case SFV_R_QUEUE_READY:
      if (f->qsel == 0 && (v & 1) && !f->qready && (f->status & SFV_ST_FEATURES_OK) && queue_valid(s, f)) f->qready = 1;
      break;
    case SFV_R_QUEUE_NOTIFY: if ((v & 0xffff) == 0) { f->ctr[SFV_PC_KICKS]++; f->pend = 1; run_all(s); } break;
    case SFV_R_INT_ACK: f->intst &= ~(v & 3); break;
    case SFV_R_STATUS:
      if (v & 0xff) {
        uint8_t nw = f->status;
        uint64_t dv = dev_features(s, f);
        if (f->status & SFV_ST_NEEDS_RESET) { nw |= (uint8_t)(v & SFV_ST_FAILED); }
        else {
          nw |= (uint8_t)(v & (SFV_ST_ACKNOWLEDGE | SFV_ST_DRIVER | SFV_ST_FAILED));
          if ((v & SFV_ST_FEATURES_OK) && !(f->dfeat & ~dv) && (f->dfeat >> SFV_F_VERSION_1 & 1) && (nw & SFV_ST_ACKNOWLEDGE) && (nw & SFV_ST_DRIVER)) nw |= SFV_ST_FEATURES_OK;
          if ((v & SFV_ST_DRIVER_OK) && (nw & SFV_ST_FEATURES_OK)) nw |= SFV_ST_DRIVER_OK;
        }
        if ((nw & SFV_ST_DRIVER_OK) && !(f->status & SFV_ST_DRIVER_OK)) f->pend = 1;
        f->status = nw;
        if ((nw & SFV_ST_DRIVER_OK)) run_all(s);
      } else func_reset(f);
      break;
    case SFV_R_QUEUE_DESC_LO: if (f->qsel == 0 && !f->qready) f->desc = (f->desc & ~0xffffffffull) | v; break;
    case SFV_R_QUEUE_DESC_HI: if (f->qsel == 0 && !f->qready) f->desc = (f->desc & 0xffffffffull) | ((uint64_t)v << 32); break;
    case SFV_R_QUEUE_DRV_LO:  if (f->qsel == 0 && !f->qready) f->avail = (f->avail & ~0xffffffffull) | v; break;
    case SFV_R_QUEUE_DRV_HI:  if (f->qsel == 0 && !f->qready) f->avail = (f->avail & 0xffffffffull) | ((uint64_t)v << 32); break;
    case SFV_R_QUEUE_DEV_LO:  if (f->qsel == 0 && !f->qready) f->used = (f->used & ~0xffffffffull) | v; break;
    case SFV_R_QUEUE_DEV_HI:  if (f->qsel == 0 && !f->qready) f->used = (f->used & 0xffffffffull) | ((uint64_t)v << 32); break;
    default: break;
  }
}

/* ---------------------------------------------------------------- management plane */
static uint32_t mg_rd(sfv_soft_t *s, uint32_t off) {
  unsigned fs = s->fsel < s->c.nfuncs ? s->fsel : 0;
  int fok = s->fsel < s->c.nfuncs;
  int dok = s->dsel < s->c.ndomains;
  s->mg_err = 0;
  switch (off) {
    case SFV_M_ID: return SFV_ID_MAGIC;
    case SFV_M_ABI: return (SFV_ABI_MAJOR << 16) | SFV_ABI_MINOR;
    case SFV_M_CAPS0: return s->c.nfuncs | (s->c.ndomains << 8) | (s->c.nwin << 16);
    case SFV_M_CAPS1: { unsigned lg = 0; while ((1u << lg) < s->c.stage_bytes) lg++; return s->c.max_qsz | (s->c.max_chain << 16) | (lg << 24); }
    case SFV_M_STORE: return s->c.store_bytes;
    case SFV_M_FAULT: return s->fault;
    case SFV_M_FAULT_IE: return s->fie;
    case SFV_M_DOM_SEL: return s->dsel;
    case SFV_M_DOM_STATUS: return dok ? (uint32_t)(s->d[s->dsel].pen && s->d[s->dsel].en) : 0;
    case SFV_M_FUNC_SEL: return s->fsel;
    case SFV_M_FUNC_STATUS: if (!fok) return 0; return s->f[fs].status | ((uint32_t)s->f[fs].fcode << 8) | ((uint32_t)s->f[fs].fdet << 16) | ((uint32_t)s->f[fs].qready << 24) | ((uint32_t)s->f[fs].pend << 25);
    case SFV_M_FUNC_FCNT: return fok ? s->f[fs].fcnt : 0;
    case SFV_M_FUNC_QSTATE: return fok ? (uint32_t)(s->f[fs].la | ((uint32_t)s->f[fs].ui << 16)) : 0;
    case SFV_M_PERF_SEL: return (s->psel_func << 8) | s->psel_ctr;
    case SFV_M_PERF_DATA:
      if (s->psel_func >= s->c.nfuncs || s->psel_ctr >= SFV_PC_N) return 0;
      if (s->psel_ctr == SFV_PC_LAT_MIN) return 0xFFFFFFFFu;
      return (uint32_t)s->f[s->psel_func].ctr[s->psel_ctr];
    default: s->mg_err = 1; return 0;
  }
}

static int in_use(const fn_t *f) { return f->status != 0; }

static void mg_wr(sfv_soft_t *s, uint32_t off, uint32_t v) {
  unsigned fs = s->fsel < s->c.nfuncs ? s->fsel : 0;
  int fok = s->fsel < s->c.nfuncs;
  int dok = s->dsel < s->c.ndomains;
  unsigned bw = s->c.bus_bytes;
  s->mg_err = 0;
  switch (off) {
    case SFV_M_FAULT: s->fault &= ~v; break;
    case SFV_M_FAULT_IE: s->fie = v; break;
    case SFV_M_DOM_SEL: s->dsel = v & 0xff; break;
    case SFV_M_WIN_SEL: s->wsel = v & 0xff; break;
    case SFV_M_WIN_BASE_LO: s->wb_lo = v; break;
    case SFV_M_WIN_BASE_HI: s->wb_hi = v; break;
    case SFV_M_WIN_SIZE_LO: s->ws_lo = v; break;
    case SFV_M_WIN_SIZE_HI: s->ws_hi = v; break;
    case SFV_M_WIN_CTL: {
      uint64_t base = ((uint64_t)s->wb_hi << 32) | s->wb_lo, size = ((uint64_t)s->ws_hi << 32) | s->ws_lo;
      if (!dok || s->wsel >= s->c.nwin) { s->mg_err = 1; break; }
      if ((v & 4) && (size == 0 || (base % bw) || (size % bw) || base > (1ull << s->c.addr_bits) || size > (1ull << s->c.addr_bits) - base)) { s->mg_err = 1; break; }
      s->d[s->dsel].w[s->wsel].base = base; s->d[s->dsel].w[s->wsel].size = size;
      s->d[s->dsel].w[s->wsel].r = v & 1; s->d[s->dsel].w[s->wsel].w = (v >> 1) & 1; s->d[s->dsel].w[s->wsel].v = (v >> 2) & 1;
      break;
    }
    case SFV_M_DOM_PBASE: s->pb_sh = v; break;
    case SFV_M_DOM_PSIZE: s->ps_sh = v; break;
    case SFV_M_DOM_CTL: {
      unsigned d;
      int en = v & 1, scrub = (v >> 1) & 1;
      if (!dok) { s->mg_err = 1; break; }
      if (en) {
        uint64_t end = (uint64_t)s->pb_sh + s->ps_sh;
        if (s->ps_sh == 0 || (s->pb_sh % 512) || (s->ps_sh % 512) || end > s->c.store_bytes) { s->mg_err = 1; break; }
        for (d = 0; d < s->c.ndomains; d++)
          if (d != s->dsel && s->d[d].pen && s->d[d].psize && s->d[d].pbase < end && s->pb_sh < (uint64_t)s->d[d].pbase + s->d[d].psize) { s->mg_err = 1; break; }
        if (s->mg_err) break;
        s->d[s->dsel].pbase = s->pb_sh; s->d[s->dsel].psize = s->ps_sh;
        if (scrub) memset(s->disk + s->pb_sh, 0, s->ps_sh);
        s->d[s->dsel].pen = 1; s->d[s->dsel].en = 1;
      } else {
        if (scrub && s->d[s->dsel].psize) memset(s->disk + s->d[s->dsel].pbase, 0, s->d[s->dsel].psize);
        s->d[s->dsel].pen = 0; s->d[s->dsel].en = 0;
      }
      break;
    }
    case SFV_M_FUNC_SEL: s->fsel = v & 0xff; break;
    case SFV_M_FUNC_DOMAIN: s->fdom_sh = v & 0xff; break;
    case SFV_M_FUNC_CAP_LO: s->fcap_lo = v; break;
    case SFV_M_FUNC_CAP_HI: s->fcap_hi = v; break;
    case SFV_M_FUNC_CTL: {
      uint64_t cap = ((uint64_t)s->fcap_hi << 32) | s->fcap_lo;
      int en = v & 1;
      if (!fok || in_use(&s->f[fs])) { s->mg_err = 1; break; }
      if (en) {
        if (s->fdom_sh >= s->c.ndomains || !s->d[s->fdom_sh].pen || cap == 0 || cap > (s->d[s->fdom_sh].psize >> 9)) { s->mg_err = 1; break; }
      }
      s->f[fs].en = en; s->f[fs].ro = (v >> 1) & 1; s->f[fs].quar = (v >> 2) & 1;
      s->f[fs].dom = s->fdom_sh < s->c.ndomains ? s->fdom_sh : 0; s->f[fs].cap = cap;
      break;
    }
    case SFV_M_PERF_SEL: s->psel_ctr = v & 0xff; s->psel_func = (v >> 8) & 0xff; break;
    case SFV_M_PERF_CTL: if (v & 1) { unsigned i; for (i = 0; i < s->c.nfuncs; i++) memset(s->f[i].ctr, 0, sizeof s->f[i].ctr); } break;
    default: s->mg_err = 1; break;
  }
}

/* ---------------------------------------------------------------- transport glue */
static uint32_t t_rd(void *c, unsigned f, uint32_t off) { return mmio_rd((sfv_soft_t *)c, f, off); }
static void     t_wr(void *c, unsigned f, uint32_t off, uint32_t v) { mmio_wr((sfv_soft_t *)c, f, off, v); }
static void     t_mr(void *c, uint64_t a, void *d, size_t n) { sfv_soft_t *s = (sfv_soft_t *)c; if (a + n <= s->c.ram_bytes) memcpy(d, s->ram + a, n); else memset(d, 0xFF, n); }
static void     t_mw(void *c, uint64_t a, const void *d, size_t n) { sfv_soft_t *s = (sfv_soft_t *)c; if (a + n <= s->c.ram_bytes) memcpy(s->ram + a, d, n); }
static void     t_wait(void *c, uint32_t u) { (void)u; run_all((sfv_soft_t *)c); }
static int      t_irq(void *c, unsigned f) { sfv_soft_t *s = (sfv_soft_t *)c; return f < s->c.nfuncs && s->f[f].intst != 0; }

void sfv_soft_transport(sfv_soft_t *s, sfv_transport_t *t) {
  t->ctx = s; t->mmio_read32 = t_rd; t->mmio_write32 = t_wr; t->mem_read = t_mr; t->mem_write = t_mw; t->wait = t_wait; t->irq_level = t_irq;
}
static uint32_t m_rd(void *c, uint32_t off) { return mg_rd((sfv_soft_t *)c, off); }
static void     m_wr(void *c, uint32_t off, uint32_t v) { mg_wr((sfv_soft_t *)c, off, v); }
static uint32_t m_err(void *c) { return ((sfv_soft_t *)c)->mg_err; }
void sfv_soft_mgmt(sfv_soft_t *s, sfv_mgmt_ops_t *m) { m->ctx = s; m->read32 = m_rd; m->write32 = m_wr; m->last_error = m_err; }
