/* Handle-based C shim for the Rust wrapper (host/rust): hides the large C structs behind opaque pointers so the Rust side needs no
 * #[repr(C)] mirrors.  The library logic stays in sfv_host.c / sfv_softdev.c. */
#include <stdlib.h>
#include <string.h>
#include "sfv_softdev.h"

typedef struct { sfv_soft_t *soft; sfv_transport_t t; sfv_mgmt_ops_t m; } rs_soft_t;
typedef struct { sfv_dev_t d; rs_soft_t *s; } rs_dev_t;

rs_soft_t *sfv_rs_soft_new(void) {
  sfv_soft_cfg_t c;
  rs_soft_t *s = (rs_soft_t *)calloc(1, sizeof *s);
  if (!s) return 0;
  sfv_soft_cfg_default(&c);
  s->soft = sfv_soft_create(&c);
  if (!s->soft) { free(s); return 0; }
  sfv_soft_transport(s->soft, &s->t);
  sfv_soft_mgmt(s->soft, &s->m);
  return s;
}
void sfv_rs_soft_free(rs_soft_t *s) { if (s) { sfv_soft_destroy(s->soft); free(s); } }

int sfv_rs_hv_set_window(rs_soft_t *s, unsigned dom, unsigned win, uint64_t base, uint64_t size, int r, int w, int v) { return sfv_hv_set_window(&s->m, dom, win, base, size, r, w, v); }
int sfv_rs_hv_set_domain(rs_soft_t *s, unsigned dom, int en, uint32_t pb, uint32_t ps, int scrub) { return sfv_hv_set_domain(&s->m, dom, en, pb, ps, scrub); }
int sfv_rs_hv_set_function(rs_soft_t *s, unsigned f, int en, unsigned dom, uint64_t cap, int ro, int quar) { return sfv_hv_set_function(&s->m, f, en, dom, cap, ro, quar); }
int sfv_rs_hv_func_state(rs_soft_t *s, unsigned f, uint32_t *st, uint32_t *fc, uint32_t *fd, uint32_t *la, uint32_t *ui) { return sfv_hv_func_state(&s->m, f, st, fc, fd, la, ui); }
uint32_t sfv_rs_hv_perf(rs_soft_t *s, unsigned f, unsigned c) { return sfv_hv_perf(&s->m, f, c); }
void sfv_rs_ram_write(rs_soft_t *s, uint64_t a, const uint8_t *p, size_t n) { s->t.mem_write(s->t.ctx, a, p, n); }
void sfv_rs_ram_read(rs_soft_t *s, uint64_t a, uint8_t *p, size_t n) { s->t.mem_read(s->t.ctx, a, p, n); }

rs_dev_t *sfv_rs_dev_new(rs_soft_t *s, unsigned func, uint64_t base, uint64_t len, uint64_t want, int *err) {
  rs_dev_t *d = (rs_dev_t *)calloc(1, sizeof *d);
  if (!d) { *err = SFV_E_NOMEM; return 0; }
  d->s = s;
  *err = sfv_dev_init(&d->d, &s->t, func, base, len, want);
  if (*err != SFV_OK) { free(d); return 0; }
  return d;
}
void sfv_rs_dev_free(rs_dev_t *d) { free(d); }
int sfv_rs_queue_create(rs_dev_t *d, uint16_t q) { return sfv_queue_create(&d->d, q); }
int sfv_rs_dev_start(rs_dev_t *d) { return sfv_dev_start(&d->d); }
int sfv_rs_check_health(rs_dev_t *d) { return sfv_check_health(&d->d); }
int sfv_rs_recover(rs_dev_t *d) { return sfv_recover(&d->d); }
int sfv_rs_blk_config(rs_dev_t *d, uint64_t *cap, uint32_t *seg_max, uint32_t *blk_size, int *ro) {
  sfv_blk_config_t c; int rc = sfv_blk_config(&d->d, &c);
  if (rc == SFV_OK) { *cap = c.capacity_sectors; *seg_max = c.seg_max; *blk_size = c.blk_size; *ro = c.read_only; }
  return rc;
}
int sfv_rs_blk_rw(rs_dev_t *d, int is_write, uint64_t sector, uint8_t *buf, uint32_t n, int *status, uint32_t *used) { return sfv_blk_rw(&d->d, is_write, sector, buf, n, status, used); }
uint64_t sfv_rs_offered(rs_dev_t *d) { return d->d.offered; }
uint64_t sfv_rs_accepted(rs_dev_t *d) { return d->d.accepted; }
uint64_t sfv_rs_arena_alloc(rs_dev_t *d, uint32_t size, uint32_t align, int *err) { uint64_t a = 0; *err = sfv_alloc(&d->d, size, align, &a); return a; }
int sfv_rs_blk_submit_wait(rs_dev_t *d, int is_write, uint64_t sector, uint64_t data_gpa, uint32_t n, uint64_t hdr, uint64_t sta, int *status, uint32_t *used) {
  sfv_completion_t c; uint16_t head; int rc;
  if ((rc = sfv_blk_submit(&d->d, is_write, sector, data_gpa, n, hdr, sta, 0, &head)) != SFV_OK) return rc;
  sfv_notify(&d->d);
  if ((rc = sfv_wait_completion(&d->d, &c, d->d.timeout_units)) != SFV_OK) return rc;
  *status = sfv_blk_status(&d->d, sta); *used = c.used_len;
  return SFV_OK;
}
const char *sfv_rs_strerror(int e) { return sfv_strerror(e); }

/* fault injection: guest address of the descriptor table, and publish an arbitrary head index (the caller planted the descriptors) */
uint64_t sfv_rs_desc_gpa(rs_dev_t *d) { return d->d.desc_gpa; }
int sfv_rs_publish_raw_head(rs_dev_t *d, uint16_t head) {
  uint8_t b[2];
  b[0] = (uint8_t)head; b[1] = (uint8_t)(head >> 8);
  d->s->t.mem_write(d->s->t.ctx, d->d.avail_gpa + 4u + 2u * (d->d.avail_idx % d->d.qsize), b, 2);
  d->d.avail_idx = (uint16_t)(d->d.avail_idx + 1);
  b[0] = (uint8_t)d->d.avail_idx; b[1] = (uint8_t)(d->d.avail_idx >> 8);
  d->s->t.mem_write(d->s->t.ctx, d->d.avail_gpa + 2u, b, 2);
  return sfv_notify(&d->d);
}
