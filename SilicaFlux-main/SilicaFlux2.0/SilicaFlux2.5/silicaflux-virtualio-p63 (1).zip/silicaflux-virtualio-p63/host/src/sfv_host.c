/*
 * SilicaFlux VirtualIO (Project 63) -- host integration library.  See include/sfv_host.h.
 * Pure C99, no dynamic allocation, no OS dependency.  All guest-memory structures are written little endian byte by byte,
 * so the library is correct on a big-endian host as well.
 */
#include <string.h>
#include "sfv_host.h"

const char *sfv_strerror(int e) {
  switch (e) {
    case SFV_OK: return "ok";
    case SFV_E_NO_DEVICE: return "no device behind this window";
    case SFV_E_VERSION: return "unsupported virtio-mmio version (only version 2)";
    case SFV_E_FEATURES: return "feature negotiation failed (FEATURES_OK refused or VERSION_1 not offered)";
    case SFV_E_QUEUE: return "queue unavailable or QueueReady refused";
    case SFV_E_NEEDS_RESET: return "device needs reset (DEVICE_NEEDS_RESET)";
    case SFV_E_FULL: return "no free descriptors";
    case SFV_E_INVAL: return "invalid argument";
    case SFV_E_TIMEOUT: return "timeout";
    case SFV_E_STATE: return "wrong driver state";
    case SFV_E_NOMEM: return "arena exhausted";
    case SFV_E_IO: return "block request failed (status != OK)";
    default: return "unknown error";
  }
}

/* ---------------------------------------------------------------- little-endian helpers */
static void le16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void le32(uint8_t *p, uint32_t v) { le16(p, (uint16_t)v); le16(p + 2, (uint16_t)(v >> 16)); }
static void le64(uint8_t *p, uint64_t v) { le32(p, (uint32_t)v); le32(p + 4, (uint32_t)(v >> 32)); }
static uint16_t rd16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static uint32_t rd32(const uint8_t *p) { return (uint32_t)rd16(p) | ((uint32_t)rd16(p + 2) << 16); }

static uint32_t rreg(const sfv_dev_t *d, uint32_t off) { return d->t->mmio_read32(d->t->ctx, d->func, off); }
static void     wreg(const sfv_dev_t *d, uint32_t off, uint32_t v) { d->t->mmio_write32(d->t->ctx, d->func, off, v); }
static void     mwr(const sfv_dev_t *d, uint64_t a, const void *s, size_t n) { d->t->mem_write(d->t->ctx, a, s, n); }
static void     mrd(const sfv_dev_t *d, uint64_t a, void *s, size_t n) { d->t->mem_read(d->t->ctx, a, s, n); }
static void     step(const sfv_dev_t *d, uint32_t u) { if (d->t->wait) d->t->wait(d->t->ctx, u); }

/* ---------------------------------------------------------------- initialisation (spec 3.1, 4.2.3.1) */
int sfv_dev_reset(sfv_dev_t *d) {
  uint32_t waited = 0;
  wreg(d, SFV_R_STATUS, 0);
  /* spec 2.4.1: the driver considers the reset complete when it reads 0 */
  while (rreg(d, SFV_R_STATUS) != 0) {
    if (waited > d->timeout_units) return SFV_E_TIMEOUT;
    step(d, 16); waited += 16;
  }
  d->state = 0; d->avail_idx = 0; d->last_used = 0; d->qsize = 0;
  memset(d->inflight, 0, sizeof d->inflight);
  return SFV_OK;
}

int sfv_dev_init(sfv_dev_t *d, const sfv_transport_t *t, unsigned func, uint64_t arena_base, uint64_t arena_len,
                 uint64_t want_optional) {
  uint32_t st, lo, hi;
  uint64_t accept;
  int rc;
  memset(d, 0, sizeof *d);
  d->t = t; d->func = func; d->arena_base = arena_base; d->arena_len = arena_len; d->arena_next = arena_base;
  d->timeout_units = 200000;
  if (rreg(d, SFV_R_MAGIC) != SFV_MMIO_MAGIC) return SFV_E_NO_DEVICE;
  if (rreg(d, SFV_R_VERSION) != SFV_MMIO_VERSION) return SFV_E_VERSION;
  if (rreg(d, SFV_R_DEVICE_ID) != SFV_DEVICE_ID_BLOCK) return SFV_E_NO_DEVICE;
  if ((rc = sfv_dev_reset(d)) != SFV_OK) return rc;
  wreg(d, SFV_R_STATUS, SFV_ST_ACKNOWLEDGE);
  wreg(d, SFV_R_STATUS, SFV_ST_ACKNOWLEDGE | SFV_ST_DRIVER);
  wreg(d, SFV_R_DEV_FEAT_SEL, 0); lo = rreg(d, SFV_R_DEV_FEATURES);
  wreg(d, SFV_R_DEV_FEAT_SEL, 1); hi = rreg(d, SFV_R_DEV_FEATURES);
  d->offered = ((uint64_t)hi << 32) | lo;
  if (!(d->offered & (1ull << SFV_F_VERSION_1))) {
    wreg(d, SFV_R_STATUS, SFV_ST_ACKNOWLEDGE | SFV_ST_DRIVER | SFV_ST_FAILED);
    return SFV_E_FEATURES;
  }
  accept = (1ull << SFV_F_VERSION_1) | (d->offered & want_optional);
  d->accepted = accept;
  wreg(d, SFV_R_DRV_FEAT_SEL, 0); wreg(d, SFV_R_DRV_FEATURES, (uint32_t)accept);
  wreg(d, SFV_R_DRV_FEAT_SEL, 1); wreg(d, SFV_R_DRV_FEATURES, (uint32_t)(accept >> 32));
  wreg(d, SFV_R_STATUS, SFV_ST_ACKNOWLEDGE | SFV_ST_DRIVER | SFV_ST_FEATURES_OK);
  st = rreg(d, SFV_R_STATUS);                      /* spec 3.1.1 step 6: is FEATURES_OK still set? */
  if (!(st & SFV_ST_FEATURES_OK)) {
    wreg(d, SFV_R_STATUS, SFV_ST_ACKNOWLEDGE | SFV_ST_DRIVER | SFV_ST_FAILED);
    return SFV_E_FEATURES;
  }
  d->state = 1;
  return SFV_OK;
}

int sfv_alloc(sfv_dev_t *d, uint32_t size, uint32_t align, uint64_t *gpa) {
  uint64_t a;
  if (!align || (align & (align - 1))) return SFV_E_INVAL;
  a = (d->arena_next + align - 1) & ~((uint64_t)align - 1);
  if (a + size > d->arena_base + d->arena_len) return SFV_E_NOMEM;
  d->arena_next = a + size;
  *gpa = a;
  return SFV_OK;
}

static void zero_guest(const sfv_dev_t *d, uint64_t gpa, uint32_t n) {
  uint8_t z[256];
  memset(z, 0, sizeof z);
  while (n) { uint32_t c = n > sizeof z ? (uint32_t)sizeof z : n; mwr(d, gpa, z, c); gpa += c; n -= c; }
}

int sfv_queue_create(sfv_dev_t *d, uint16_t qsize) {
  uint32_t maxq, i;
  int rc;
  if (d->state != 1) return SFV_E_STATE;
  if (qsize == 0 || (qsize & (qsize - 1)) || qsize > SFV_MAX_QSZ) return SFV_E_INVAL;
  wreg(d, SFV_R_QUEUE_SEL, 0);
  if (rreg(d, SFV_R_QUEUE_READY) != 0) return SFV_E_QUEUE;                /* spec 4.2.3.2 step 2 */
  maxq = rreg(d, SFV_R_QUEUE_NUM_MAX);                                    /* step 3 */
  if (maxq == 0) return SFV_E_QUEUE;
  if (qsize > maxq) return SFV_E_QUEUE;
  d->ring_start = d->arena_next;
  if ((rc = sfv_alloc(d, 16u * qsize, 16, &d->desc_gpa)) != SFV_OK) return rc;
  if ((rc = sfv_alloc(d, 6u + 2u * qsize, 8, &d->avail_gpa)) != SFV_OK) return rc;
  if ((rc = sfv_alloc(d, 6u + 8u * qsize, 8, &d->used_gpa)) != SFV_OK) return rc;
  zero_guest(d, d->desc_gpa, 16u * qsize);                                /* step 4: zeroed queue memory */
  zero_guest(d, d->avail_gpa, 6u + 2u * qsize);
  zero_guest(d, d->used_gpa, 6u + 8u * qsize);
  wreg(d, SFV_R_QUEUE_NUM, qsize);                                        /* step 5 */
  wreg(d, SFV_R_QUEUE_DESC_LO, (uint32_t)d->desc_gpa);   wreg(d, SFV_R_QUEUE_DESC_HI, (uint32_t)(d->desc_gpa >> 32));   /* step 6 */
  wreg(d, SFV_R_QUEUE_DRV_LO,  (uint32_t)d->avail_gpa);  wreg(d, SFV_R_QUEUE_DRV_HI,  (uint32_t)(d->avail_gpa >> 32));
  wreg(d, SFV_R_QUEUE_DEV_LO,  (uint32_t)d->used_gpa);   wreg(d, SFV_R_QUEUE_DEV_HI,  (uint32_t)(d->used_gpa >> 32));
  wreg(d, SFV_R_QUEUE_READY, 1);                                          /* step 7 */
  if (rreg(d, SFV_R_QUEUE_READY) != 1) return SFV_E_QUEUE;
  d->qsize = qsize; d->avail_idx = 0; d->last_used = 0; d->nfree = qsize; d->free_head = 0;
  for (i = 0; i < qsize; i++) { d->free_next[i] = (uint16_t)((i + 1) % qsize); d->chain_len[i] = 0; d->inflight[i] = 0; d->cookie[i] = 0; }
  d->state = 2;
  return SFV_OK;
}

int sfv_dev_start(sfv_dev_t *d) {
  uint32_t st;
  if (d->state != 2) return SFV_E_STATE;
  wreg(d, SFV_R_STATUS, SFV_ST_ACKNOWLEDGE | SFV_ST_DRIVER | SFV_ST_FEATURES_OK | SFV_ST_DRIVER_OK);
  st = rreg(d, SFV_R_STATUS);
  if (st & SFV_ST_NEEDS_RESET) return SFV_E_NEEDS_RESET;
  if (!(st & SFV_ST_DRIVER_OK)) return SFV_E_STATE;
  d->state = 3;
  return SFV_OK;
}

int sfv_check_health(sfv_dev_t *d) {
  return (rreg(d, SFV_R_STATUS) & SFV_ST_NEEDS_RESET) ? SFV_E_NEEDS_RESET : SFV_OK;
}

int sfv_recover(sfv_dev_t *d) {
  const sfv_transport_t *t = d->t;
  unsigned func = d->func;
  uint16_t q = d->qsize;
  uint64_t base = d->arena_base, len = d->arena_len, next = d->arena_next;
  uint64_t accepted = d->accepted, ring_start = d->ring_start;
  int rc;
  uint64_t save_next = next;
  if ((rc = sfv_dev_init(d, t, func, base, len, accepted)) != SFV_OK) return rc;   /* resets first: all in-flight work is dropped */
  if (q == 0) return SFV_OK;
  d->arena_next = ring_start;                                                       /* the rings go back where they were ... */
  if ((rc = sfv_queue_create(d, q)) != SFV_OK) return rc;
  if (d->arena_next < save_next) d->arena_next = save_next;                          /* ... and buffers handed out so far stay valid */
  return sfv_dev_start(d);
}

int sfv_blk_config(sfv_dev_t *d, sfv_blk_config_t *cfg) {
  uint32_t g0, g1, lo, hi;
  int tries = 0;
  do {                                                  /* spec 4.2.2.2: ConfigGeneration protocol */
    g0 = rreg(d, SFV_R_CONFIG_GEN);
    lo = rreg(d, SFV_CFG_CAPACITY_LO); hi = rreg(d, SFV_CFG_CAPACITY_HI);
    cfg->seg_max = rreg(d, SFV_CFG_SEG_MAX);
    cfg->blk_size = rreg(d, SFV_CFG_BLK_SIZE);
    g1 = rreg(d, SFV_R_CONFIG_GEN);
  } while (g0 != g1 && ++tries < 8);
  if (g0 != g1) return SFV_E_IO;
  cfg->capacity_sectors = ((uint64_t)hi << 32) | lo;
  cfg->read_only = (d->offered >> SFV_BLK_F_RO) & 1;
  return SFV_OK;
}

/* ---------------------------------------------------------------- submission */
int sfv_submit(sfv_dev_t *d, const sfv_seg_t *segs, unsigned nsegs, void *cookie, uint16_t *head) {
  uint16_t slot[SFV_MAX_QSZ], cur;
  uint8_t desc[16], ring[2], idx[2];
  unsigned i;
  if (d->state != 3) return SFV_E_STATE;
  if (nsegs == 0 || nsegs > d->qsize) return SFV_E_INVAL;
  if (nsegs > d->nfree) return SFV_E_FULL;
  /* spec 2.7.4.2: device-writable descriptors must follow all device-readable ones */
  for (i = 1; i < nsegs; i++) if (!segs[i].device_writable && segs[i - 1].device_writable) return SFV_E_INVAL;
  cur = d->free_head;
  for (i = 0; i < nsegs; i++) { slot[i] = cur; cur = d->free_next[cur]; }
  d->free_head = cur; d->nfree = (uint16_t)(d->nfree - nsegs);
  for (i = 0; i < nsegs; i++) {
    uint16_t flags = (uint16_t)((segs[i].device_writable ? SFV_DESC_F_WRITE : 0) | (i + 1 < nsegs ? SFV_DESC_F_NEXT : 0));
    le64(desc, segs[i].gpa); le32(desc + 8, segs[i].len); le16(desc + 12, flags);
    le16(desc + 14, (uint16_t)(i + 1 < nsegs ? slot[i + 1] : 0));
    mwr(d, d->desc_gpa + 16u * slot[i], desc, 16);
  }
  d->chain_len[slot[0]] = (uint16_t)nsegs; d->cookie[slot[0]] = cookie; d->inflight[slot[0]] = 1;
  le16(ring, slot[0]);                                          /* 1. the head goes into the available ring ...   */
  mwr(d, d->avail_gpa + 4u + 2u * (d->avail_idx % d->qsize), ring, 2);
  d->avail_idx = (uint16_t)(d->avail_idx + 1);
  le16(idx, d->avail_idx);                                      /* 2. ... and only then is avail.idx advanced      */
  mwr(d, d->avail_gpa + 2u, idx, 2);
  if (head) *head = slot[0];
  return SFV_OK;
}

void sfv_set_no_interrupt(sfv_dev_t *d, int suppress) {
  uint8_t f[2];
  le16(f, suppress ? SFV_AVAIL_F_NO_INTERRUPT : 0);
  mwr(d, d->avail_gpa, f, 2);
}

int sfv_notify(sfv_dev_t *d) {
  uint8_t f[2];
  if (d->state != 3) return SFV_E_STATE;
  mrd(d, d->used_gpa, f, 2);
  if (rd16(f) & SFV_USED_F_NO_NOTIFY) return SFV_OK;           /* the device asked not to be kicked */
  wreg(d, SFV_R_QUEUE_NOTIFY, 0);
  return SFV_OK;
}

int sfv_poll(sfv_dev_t *d, sfv_completion_t *out) {
  uint8_t b[8], idx[2];
  uint16_t used_idx, id;
  if (d->state != 3) return SFV_E_STATE;
  mrd(d, d->used_gpa + 2u, idx, 2);
  used_idx = rd16(idx);
  if (used_idx == d->last_used) return (rreg(d, SFV_R_STATUS) & SFV_ST_NEEDS_RESET) ? SFV_E_NEEDS_RESET : 0;
  mrd(d, d->used_gpa + 4u + 8u * (d->last_used % d->qsize), b, 8);
  id = (uint16_t)rd32(b);
  if (id >= d->qsize || !d->inflight[id]) return SFV_E_IO;     /* a used id we never submitted: protocol violation by the device */
  out->head = id; out->used_len = rd32(b + 4); out->cookie = d->cookie[id];
  d->inflight[id] = 0;
  /* return the chain's descriptors to the free list (walk it through the descriptor table to find the exact slots) */
  {
    uint16_t slot = id, n = d->chain_len[id], i;
    for (i = 0; i < n; i++) {
      uint8_t desc[16];
      uint16_t nxt, fl;
      mrd(d, d->desc_gpa + 16u * slot, desc, 16);
      fl = rd16(desc + 12); nxt = rd16(desc + 14);
      d->free_next[slot] = d->free_head; d->free_head = slot; d->nfree++;
      slot = nxt;
      if (!(fl & SFV_DESC_F_NEXT)) break;
    }
  }
  d->chain_len[id] = 0;
  d->last_used = (uint16_t)(d->last_used + 1);
  return 1;
}

int sfv_wait_completion(sfv_dev_t *d, sfv_completion_t *out, uint32_t max_units) {
  uint32_t waited = 0;
  int rc;
  while ((rc = sfv_poll(d, out)) == 0) {
    if (waited >= max_units) return SFV_E_TIMEOUT;
    step(d, 8); waited += 8;
  }
  return rc > 0 ? SFV_OK : rc;
}

uint32_t sfv_irq_pending(sfv_dev_t *d) { return rreg(d, SFV_R_INT_STATUS); }
void sfv_irq_ack(sfv_dev_t *d, uint32_t bits) { wreg(d, SFV_R_INT_ACK, bits); }

/* ---------------------------------------------------------------- virtio-blk */
int sfv_blk_submit(sfv_dev_t *d, int is_write, uint64_t sector, uint64_t data_gpa, uint32_t nbytes, uint64_t hdr_gpa,
                   uint64_t status_gpa, void *cookie, uint16_t *head) {
  uint8_t h[16], st = 0xFF;
  sfv_seg_t s[3];
  unsigned n = 0;
  le32(h, is_write ? SFV_BLK_T_OUT : SFV_BLK_T_IN); le32(h + 4, 0); le64(h + 8, sector);
  mwr(d, hdr_gpa, h, 16);
  mwr(d, status_gpa, &st, 1);
  s[n].gpa = hdr_gpa; s[n].len = 16; s[n].device_writable = 0; n++;
  if (nbytes) { s[n].gpa = data_gpa; s[n].len = nbytes; s[n].device_writable = !is_write; n++; }
  s[n].gpa = status_gpa; s[n].len = 1; s[n].device_writable = 1; n++;
  return sfv_submit(d, s, n, cookie, head);
}

int sfv_blk_status(sfv_dev_t *d, uint64_t status_gpa) {
  uint8_t st;
  mrd(d, status_gpa, &st, 1);
  return st;
}

int sfv_blk_rw(sfv_dev_t *d, int is_write, uint64_t sector, void *buf, uint32_t nbytes, int *blk_status, uint32_t *used_len) {
  uint64_t hdr, data, sta;
  sfv_completion_t c;
  uint16_t head;
  int rc, st;
  uint64_t save = d->arena_next;                       /* buffers are scratch: give them back afterwards */
  if ((rc = sfv_alloc(d, 16, 16, &hdr)) || (rc = sfv_alloc(d, nbytes ? nbytes : 1, 8, &data)) || (rc = sfv_alloc(d, 1, 1, &sta)))
    return rc;
  if (is_write && nbytes) mwr(d, data, buf, nbytes);
  if ((rc = sfv_blk_submit(d, is_write, sector, data, nbytes, hdr, sta, 0, &head)) != SFV_OK) { d->arena_next = save; return rc; }
  if ((rc = sfv_notify(d)) != SFV_OK) { d->arena_next = save; return rc; }
  if ((rc = sfv_wait_completion(d, &c, d->timeout_units)) != SFV_OK) { d->arena_next = save; return rc; }
  st = sfv_blk_status(d, sta);
  if (blk_status) *blk_status = st;
  if (used_len) *used_len = c.used_len;
  if (!is_write && nbytes && st == 0) mrd(d, data, buf, nbytes);
  d->arena_next = save;
  return st == 0 ? SFV_OK : SFV_E_IO;
}

/* ---------------------------------------------------------------- hypervisor / management */
static int mg_ok(const sfv_mgmt_ops_t *m) { return m->last_error(m->ctx) ? SFV_E_INVAL : SFV_OK; }
static void mw(const sfv_mgmt_ops_t *m, uint32_t off, uint32_t v) { m->write32(m->ctx, off, v); }
static uint32_t mr(const sfv_mgmt_ops_t *m, uint32_t off) { return m->read32(m->ctx, off); }

int sfv_hv_probe(const sfv_mgmt_ops_t *m, sfv_hv_caps_t *c) {
  uint32_t v;
  if (mr(m, SFV_M_ID) != SFV_ID_MAGIC) return SFV_E_NO_DEVICE;
  if ((mr(m, SFV_M_ABI) >> 16) != SFV_ABI_MAJOR) return SFV_E_VERSION;
  v = mr(m, SFV_M_CAPS0);
  c->nfuncs = v & 0xff; c->ndomains = (v >> 8) & 0xff; c->nwin = (v >> 16) & 0xff; c->ext_iommu = (v >> 24) & 1;
  v = mr(m, SFV_M_CAPS1);
  c->max_qsz = v & 0xffff; c->max_chain = (v >> 16) & 0xff; c->stage_log2 = (v >> 24) & 0xff;
  c->store_bytes = mr(m, SFV_M_STORE);
  return SFV_OK;
}

int sfv_hv_set_window(const sfv_mgmt_ops_t *m, unsigned dom, unsigned win, uint64_t base, uint64_t size, int r, int w, int valid) {
  mw(m, SFV_M_DOM_SEL, dom); mw(m, SFV_M_WIN_SEL, win);
  mw(m, SFV_M_WIN_BASE_LO, (uint32_t)base); mw(m, SFV_M_WIN_BASE_HI, (uint32_t)(base >> 32));
  mw(m, SFV_M_WIN_SIZE_LO, (uint32_t)size); mw(m, SFV_M_WIN_SIZE_HI, (uint32_t)(size >> 32));
  mw(m, SFV_M_WIN_CTL, (r ? 1u : 0u) | (w ? 2u : 0u) | (valid ? 4u : 0u));       /* atomic commit */
  return mg_ok(m);
}
int sfv_hv_set_domain(const sfv_mgmt_ops_t *m, unsigned dom, int enable, uint32_t part_base, uint32_t part_size, int scrub) {
  uint32_t guard = 0;
  mw(m, SFV_M_DOM_SEL, dom); mw(m, SFV_M_DOM_PBASE, part_base); mw(m, SFV_M_DOM_PSIZE, part_size);
  mw(m, SFV_M_DOM_CTL, (enable ? 1u : 0u) | (scrub ? 2u : 0u));
  if (mg_ok(m)) return SFV_E_INVAL;
  while ((mr(m, SFV_M_DOM_STATUS) & 2u) && guard++ < 1000000) { }                /* wait for the scrub to finish */
  return SFV_OK;
}
int sfv_hv_set_function(const sfv_mgmt_ops_t *m, unsigned func, int enable, unsigned dom, uint64_t cap, int ro, int quarantine) {
  mw(m, SFV_M_FUNC_SEL, func); mw(m, SFV_M_FUNC_DOMAIN, dom);
  mw(m, SFV_M_FUNC_CAP_LO, (uint32_t)cap); mw(m, SFV_M_FUNC_CAP_HI, (uint32_t)(cap >> 32));
  mw(m, SFV_M_FUNC_CTL, (enable ? 1u : 0u) | (ro ? 2u : 0u) | (quarantine ? 4u : 0u));
  return mg_ok(m);
}
int sfv_hv_func_state(const sfv_mgmt_ops_t *m, unsigned func, uint32_t *status, uint32_t *fcode, uint32_t *fdetail,
                      uint32_t *la, uint32_t *ui) {
  uint32_t v;
  mw(m, SFV_M_FUNC_SEL, func);
  v = mr(m, SFV_M_FUNC_STATUS);
  if (status) *status = v & 0xff;
  if (fcode) *fcode = (v >> 8) & 0xff;
  if (fdetail) *fdetail = (v >> 16) & 0xff;
  v = mr(m, SFV_M_FUNC_QSTATE);
  if (la) *la = v & 0xffff;
  if (ui) *ui = v >> 16;
  return SFV_OK;
}
uint32_t sfv_hv_perf(const sfv_mgmt_ops_t *m, unsigned func, unsigned counter) {
  mw(m, SFV_M_PERF_SEL, (func << 8) | counter);
  return mr(m, SFV_M_PERF_DATA);
}
void sfv_hv_perf_clear(const sfv_mgmt_ops_t *m) { mw(m, SFV_M_PERF_CTL, 1); }
