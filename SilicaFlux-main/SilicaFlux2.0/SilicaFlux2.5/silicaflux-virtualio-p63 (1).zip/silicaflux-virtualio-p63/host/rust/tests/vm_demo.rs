//! The VM-demo scenario through the safe Rust API, plus randomised round trips — against the software device.
use sfv_host::*;

const VM_BASE: u64 = 0x1000;
const VM_SIZE: u64 = 0xF000;
const SECTORS: u64 = 32;

fn xorshift(s: &mut u32) -> u32 { *s ^= *s << 13; *s ^= *s >> 17; *s ^= *s << 5; *s }

fn setup(soft: &SoftDevice) {
    let hv = soft.hypervisor();
    hv.set_window(0, 0, VM_BASE, VM_SIZE, true, true, true).unwrap();
    hv.set_domain(0, true, 0, (SECTORS * 512) as u32, true).unwrap();
    hv.set_function(0, true, 0, SECTORS, false, false).unwrap();
}

#[test]
fn init_negotiates_only_what_is_offered_and_rejects_bad_management() {
    let soft = SoftDevice::new();
    // a function that management has not enabled is "no device"
    assert_eq!(soft.driver(0, VM_BASE, VM_SIZE, 0).err(), Some(Error::NO_DEVICE));
    // management refuses a disk larger than its partition, and a misaligned window
    let hv = soft.hypervisor();
    hv.set_domain(0, true, 0, 16384, true).unwrap();
    assert!(hv.set_function(0, true, 0, 33, false, false).is_err());
    assert!(hv.set_window(0, 0, VM_BASE + 1, VM_SIZE, true, true, true).is_err());
    setup(&SoftDevice::new());
    let soft = SoftDevice::new();
    setup(&soft);
    let d = soft.driver(0, VM_BASE, VM_SIZE, u64::MAX).unwrap(); // the driver asks for everything; only offered bits are accepted
    assert_eq!(d.accepted_features() & !d.offered_features(), 0);
    assert!(d.offered_features() & (1 << 32) != 0, "VERSION_1");
    assert_eq!(d.offered_features() & (1 << 34), 0, "no packed rings");
    assert_eq!(d.offered_features() & (1 << 28), 0, "no indirect descriptors");
}

#[test]
fn write_read_verify_status_and_used_length() {
    let soft = SoftDevice::new();
    setup(&soft);
    let mut d = soft.driver(0, VM_BASE, VM_SIZE, 0).unwrap();
    d.create_queue(16).unwrap();
    d.start().unwrap();
    let cfg = d.config().unwrap();
    assert_eq!(cfg, BlkConfig { capacity_sectors: SECTORS, seg_max: 6, blk_size: 512, read_only: false });
    let mut seed = 7u32;
    for round in 0..40u64 {
        let n = 512 * (1 + (xorshift(&mut seed) % 4) as usize);
        let sector = xorshift(&mut seed) as u64 % (SECTORS - (n / 512) as u64 + 1);
        let data: Vec<u8> = (0..n).map(|_| xorshift(&mut seed) as u8).collect();
        let w = d.write(sector, &data).unwrap();
        assert_eq!(w, Completion { status: BlkStatus::Ok, used_len: 1 }, "round {}", round);
        let (r, back) = d.read(sector, n).unwrap();
        assert_eq!(r, Completion { status: BlkStatus::Ok, used_len: n as u32 + 1 });
        assert_eq!(back, data, "round {} read-back", round);
    }
}

#[test]
fn request_errors_are_answers_not_failures() {
    let soft = SoftDevice::new();
    setup(&soft);
    let mut d = soft.driver(0, VM_BASE, VM_SIZE, 0).unwrap();
    d.create_queue(16).unwrap();
    d.start().unwrap();
    assert_eq!(d.read(SECTORS, 512).unwrap().0, Completion { status: BlkStatus::IoErr, used_len: 1 });          // past the end
    assert_eq!(d.write(SECTORS - 1, &[0u8; 1024]).unwrap(), Completion { status: BlkStatus::IoErr, used_len: 1 }); // crosses the end
    assert_eq!(d.write(0, &[0u8; 100]).unwrap(), Completion { status: BlkStatus::IoErr, used_len: 1 });          // not a multiple of 512
    assert_eq!(d.write(u64::MAX, &[0u8; 512]).unwrap(), Completion { status: BlkStatus::IoErr, used_len: 1 });   // sector 2^64-1
    d.health().unwrap();                                                                                           // device still healthy
    assert_eq!(soft.hypervisor().perf(0, 9), 4, "PC_REQ_ERR");
}

#[test]
fn dma_outside_the_granted_window_is_refused_and_nothing_is_delivered() {
    let soft = SoftDevice::new();
    setup(&soft);
    let mut d = soft.driver(0, VM_BASE, VM_SIZE, 0).unwrap();
    d.create_queue(16).unwrap();
    d.start().unwrap();
    let canary = [0xA5u8; 512];
    soft.ram_write(0x30000, &canary);                                  // another tenant's memory (not granted)
    let c = d.read_into_guest_address(0, 512, 0x30000).unwrap();
    assert_eq!(c, Completion { status: BlkStatus::IoErr, used_len: 1 });
    let mut after = [0u8; 512];
    soft.ram_read(0x30000, &mut after);
    assert_eq!(after, canary, "the foreign memory is untouched");
    assert_eq!(soft.hypervisor().perf(0, 7), 1, "PC_VIOLATIONS");
}

#[test]
fn a_malformed_chain_stops_the_device_and_the_driver_recovers() {
    let soft = SoftDevice::new();
    setup(&soft);
    let mut d = soft.driver(0, VM_BASE, VM_SIZE, 0).unwrap();
    d.create_queue(16).unwrap();
    d.start().unwrap();
    let data = vec![0x5Au8; 512];
    d.write(20, &data).unwrap();
    // plant a cyclic chain: descriptor 3 (a free slot) has NEXT and points at itself; then publish it and ring the doorbell
    let mut desc = [0u8; 16];
    desc[8] = 16; desc[12] = 1; desc[14] = 3;                          // addr 0, len 16, flags NEXT, next = 3
    soft.ram_write(d.descriptor_table_gpa() + 16 * 3, &desc);
    d.publish_raw_head(3).unwrap();
    // the device must stop instead of completing; the next request therefore never completes either
    let r = d.write(21, &data);
    assert!(r.is_err(), "the device must stop instead of completing: {:?}", r);
    assert_eq!(d.health(), Err(Error::NEEDS_RESET));
    let st = soft.hypervisor().func_state(0);
    assert_ne!(st.status & 0x40, 0, "NEEDS_RESET");
    assert_eq!(st.fault_code, 4, "CYCLE");
    d.recover().unwrap();
    let (c, back) = d.read(20, 512).unwrap();
    assert_eq!(c.status, BlkStatus::Ok);
    assert_eq!(back, data, "data written before the fault survived");
}
