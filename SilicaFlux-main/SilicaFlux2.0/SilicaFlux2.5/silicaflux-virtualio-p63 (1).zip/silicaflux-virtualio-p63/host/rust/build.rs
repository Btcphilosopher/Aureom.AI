// Compiles the C host library + software device + shim with the system C compiler (no external crates) and links it statically.
use std::{env, path::PathBuf, process::Command};

fn main() {
    let out = PathBuf::from(env::var("OUT_DIR").unwrap());
    let here = PathBuf::from(env::var("CARGO_MANIFEST_DIR").unwrap());
    let host = here.parent().unwrap().to_path_buf(); // .../host
    let srcs = ["sfv_host.c", "sfv_softdev.c", "sfv_rs_shim.c"];
    let mut objs = Vec::new();
    for s in srcs {
        let o = out.join(s.replace(".c", ".o"));
        let st = Command::new(env::var("CC").unwrap_or_else(|_| "cc".into()))
            .args(["-std=c99", "-O2", "-Wall", "-Wextra", "-fPIC", "-I"])
            .arg(host.join("include"))
            .arg("-c")
            .arg(host.join("src").join(s))
            .arg("-o")
            .arg(&o)
            .status()
            .expect("cannot run the C compiler");
        assert!(st.success(), "compiling {} failed", s);
        objs.push(o);
        println!("cargo:rerun-if-changed={}", host.join("src").join(s).display());
    }
    let lib = out.join("libsfv_c.a");
    let st = Command::new("ar").arg("rcs").arg(&lib).args(&objs).status().expect("cannot run ar");
    assert!(st.success(), "ar failed");
    println!("cargo:rustc-link-search=native={}", out.display());
    println!("cargo:rustc-link-lib=static=sfv_c");
    println!("cargo:rerun-if-changed={}", host.join("include").display());
}
