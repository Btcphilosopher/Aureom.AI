//! Safe Rust wrapper over the SilicaFlux VirtualIO host library (guest driver + hypervisor calls) running on the software device.
//!
//! The protocol logic stays in C (`host/src/sfv_host.c`); this crate adds memory-safe ownership (`Drop`), typed errors and lifetimes so
//! a driver can never outlive the device it talks to.  It does **not** replace the C library and is tested only against the software
//! device (the Verilated RTL is driven by the C co-simulation harness).
use std::ffi::{c_char, c_int, c_void, CStr};
use std::marker::PhantomData;

#[allow(non_camel_case_types)]
type size_t = usize;

extern "C" {
    fn sfv_rs_soft_new() -> *mut c_void;
    fn sfv_rs_soft_free(s: *mut c_void);
    fn sfv_rs_hv_set_window(s: *mut c_void, dom: u32, win: u32, base: u64, size: u64, r: c_int, w: c_int, v: c_int) -> c_int;
    fn sfv_rs_hv_set_domain(s: *mut c_void, dom: u32, en: c_int, pb: u32, ps: u32, scrub: c_int) -> c_int;
    fn sfv_rs_hv_set_function(s: *mut c_void, f: u32, en: c_int, dom: u32, cap: u64, ro: c_int, quar: c_int) -> c_int;
    fn sfv_rs_hv_func_state(s: *mut c_void, f: u32, st: *mut u32, fc: *mut u32, fd: *mut u32, la: *mut u32, ui: *mut u32) -> c_int;
    fn sfv_rs_hv_perf(s: *mut c_void, f: u32, c: u32) -> u32;
    fn sfv_rs_ram_write(s: *mut c_void, a: u64, p: *const u8, n: size_t);
    fn sfv_rs_ram_read(s: *mut c_void, a: u64, p: *mut u8, n: size_t);
    fn sfv_rs_dev_new(s: *mut c_void, func: u32, base: u64, len: u64, want: u64, err: *mut c_int) -> *mut c_void;
    fn sfv_rs_dev_free(d: *mut c_void);
    fn sfv_rs_queue_create(d: *mut c_void, q: u16) -> c_int;
    fn sfv_rs_dev_start(d: *mut c_void) -> c_int;
    fn sfv_rs_check_health(d: *mut c_void) -> c_int;
    fn sfv_rs_recover(d: *mut c_void) -> c_int;
    fn sfv_rs_blk_config(d: *mut c_void, cap: *mut u64, seg: *mut u32, bs: *mut u32, ro: *mut c_int) -> c_int;
    fn sfv_rs_blk_rw(d: *mut c_void, w: c_int, sector: u64, buf: *mut u8, n: u32, st: *mut c_int, used: *mut u32) -> c_int;
    fn sfv_rs_offered(d: *mut c_void) -> u64;
    fn sfv_rs_accepted(d: *mut c_void) -> u64;
    fn sfv_rs_arena_alloc(d: *mut c_void, size: u32, align: u32, err: *mut c_int) -> u64;
    fn sfv_rs_blk_submit_wait(d: *mut c_void, w: c_int, sector: u64, data: u64, n: u32, hdr: u64, sta: u64, st: *mut c_int, used: *mut u32) -> c_int;
    fn sfv_rs_strerror(e: c_int) -> *const c_char;
    fn sfv_rs_desc_gpa(d: *mut c_void) -> u64;
    fn sfv_rs_publish_raw_head(d: *mut c_void, head: u16) -> c_int;
}

/// Library error (the C `SFV_E_*` codes).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Error(pub i32);
impl Error {
    pub const NO_DEVICE: Error = Error(-1);
    pub const FEATURES: Error = Error(-3);
    pub const NEEDS_RESET: Error = Error(-5);
    pub const IO: Error = Error(-11);
    pub fn message(&self) -> String {
        unsafe { CStr::from_ptr(sfv_rs_strerror(self.0)).to_string_lossy().into_owned() }
    }
}
impl std::fmt::Display for Error {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result { write!(f, "{} ({})", self.message(), self.0) }
}
impl std::error::Error for Error {}
fn check(rc: c_int) -> Result<(), Error> { if rc < 0 { Err(Error(rc)) } else { Ok(()) } }

/// virtio-blk status byte of a completed request.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BlkStatus { Ok, IoErr, Unsupported, NotWritten, Other(u8) }
impl From<i32> for BlkStatus {
    fn from(s: i32) -> Self { match s { 0 => BlkStatus::Ok, 1 => BlkStatus::IoErr, 2 => BlkStatus::Unsupported, 0xFF => BlkStatus::NotWritten, o => BlkStatus::Other(o as u8) } }
}
/// Outcome of one block request: the device's status byte and the used length it reported.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Completion { pub status: BlkStatus, pub used_len: u32 }

/// Device state as the hypervisor sees it.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct FuncState { pub status: u32, pub fault_code: u32, pub fault_detail: u32, pub last_avail: u32, pub used_idx: u32 }

/// The software VirtIO device (the simulated transport).  Owns the device model; dropping it frees everything.
pub struct SoftDevice { raw: *mut c_void }
impl SoftDevice {
    pub fn new() -> SoftDevice {
        let raw = unsafe { sfv_rs_soft_new() };
        assert!(!raw.is_null(), "out of memory");
        SoftDevice { raw }
    }
    pub fn hypervisor(&self) -> Hypervisor<'_> { Hypervisor { raw: self.raw, _p: PhantomData } }
    /// Raw guest-memory access (the CPU's view of RAM), e.g. for tests that plant malformed structures.
    pub fn ram_write(&self, addr: u64, data: &[u8]) { unsafe { sfv_rs_ram_write(self.raw, addr, data.as_ptr(), data.len()) } }
    pub fn ram_read(&self, addr: u64, out: &mut [u8]) { unsafe { sfv_rs_ram_read(self.raw, addr, out.as_mut_ptr(), out.len()) } }
    /// Initialise function `func` with a driver whose rings and buffers live in the arena `[base, base+len)`.
    pub fn driver(&self, func: u32, arena_base: u64, arena_len: u64, want_optional: u64) -> Result<Driver<'_>, Error> {
        let mut err: c_int = 0;
        let d = unsafe { sfv_rs_dev_new(self.raw, func, arena_base, arena_len, want_optional, &mut err) };
        if d.is_null() { Err(Error(err)) } else { Ok(Driver { raw: d, soft: self.raw, _p: PhantomData }) }
    }
}
impl Default for SoftDevice { fn default() -> Self { Self::new() } }
impl Drop for SoftDevice { fn drop(&mut self) { unsafe { sfv_rs_soft_free(self.raw) } } }

/// Management plane (windows, partitions, function binding, state, counters).
pub struct Hypervisor<'a> { raw: *mut c_void, _p: PhantomData<&'a SoftDevice> }
impl Hypervisor<'_> {
    pub fn set_window(&self, dom: u32, win: u32, base: u64, size: u64, read: bool, write: bool, valid: bool) -> Result<(), Error> {
        check(unsafe { sfv_rs_hv_set_window(self.raw, dom, win, base, size, read as c_int, write as c_int, valid as c_int) })
    }
    pub fn set_domain(&self, dom: u32, enable: bool, part_base: u32, part_size: u32, scrub: bool) -> Result<(), Error> {
        check(unsafe { sfv_rs_hv_set_domain(self.raw, dom, enable as c_int, part_base, part_size, scrub as c_int) })
    }
    pub fn set_function(&self, func: u32, enable: bool, dom: u32, cap_sectors: u64, read_only: bool, quarantine: bool) -> Result<(), Error> {
        check(unsafe { sfv_rs_hv_set_function(self.raw, func, enable as c_int, dom, cap_sectors, read_only as c_int, quarantine as c_int) })
    }
    pub fn func_state(&self, func: u32) -> FuncState {
        let mut s = FuncState::default();
        unsafe { sfv_rs_hv_func_state(self.raw, func, &mut s.status, &mut s.fault_code, &mut s.fault_detail, &mut s.last_avail, &mut s.used_idx) };
        s
    }
    pub fn perf(&self, func: u32, counter: u32) -> u32 { unsafe { sfv_rs_hv_perf(self.raw, func, counter) } }
}

/// A guest driver for one function.  Borrows the device: it cannot outlive it.
pub struct Driver<'a> { raw: *mut c_void, soft: *mut c_void, _p: PhantomData<&'a SoftDevice> }
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BlkConfig { pub capacity_sectors: u64, pub seg_max: u32, pub blk_size: u32, pub read_only: bool }
impl Driver<'_> {
    pub fn offered_features(&self) -> u64 { unsafe { sfv_rs_offered(self.raw) } }
    pub fn accepted_features(&self) -> u64 { unsafe { sfv_rs_accepted(self.raw) } }
    pub fn create_queue(&mut self, qsize: u16) -> Result<(), Error> { check(unsafe { sfv_rs_queue_create(self.raw, qsize) }) }
    pub fn start(&mut self) -> Result<(), Error> { check(unsafe { sfv_rs_dev_start(self.raw) }) }
    pub fn config(&self) -> Result<BlkConfig, Error> {
        let (mut cap, mut seg, mut bs, mut ro) = (0u64, 0u32, 0u32, 0 as c_int);
        check(unsafe { sfv_rs_blk_config(self.raw, &mut cap, &mut seg, &mut bs, &mut ro) })?;
        Ok(BlkConfig { capacity_sectors: cap, seg_max: seg, blk_size: bs, read_only: ro != 0 })
    }
    /// Synchronous request.  `Ok(Completion)` for every request the device completed (including IOERR / UNSUPP: they are
    /// answers, not transport failures); `Err` only if the device did not complete it (e.g. NEEDS_RESET, timeout).
    pub fn write(&mut self, sector: u64, data: &[u8]) -> Result<Completion, Error> { self.rw(true, sector, data.to_vec()).map(|(c, _)| c) }
    pub fn read(&mut self, sector: u64, len: usize) -> Result<(Completion, Vec<u8>), Error> { self.rw(false, sector, vec![0u8; len]) }
    fn rw(&mut self, is_write: bool, sector: u64, mut buf: Vec<u8>) -> Result<(Completion, Vec<u8>), Error> {
        let (mut st, mut used) = (0 as c_int, 0u32);
        let rc = unsafe { sfv_rs_blk_rw(self.raw, is_write as c_int, sector, buf.as_mut_ptr(), buf.len() as u32, &mut st, &mut used) };
        if rc == Error::IO.0 { return Ok((Completion { status: st.into(), used_len: used }, buf)); } // device answered with a non-OK status
        check(rc)?;
        Ok((Completion { status: st.into(), used_len: used }, buf))
    }
    /// A read whose data buffer is placed at an arbitrary guest address (to test the DMA protection).
    pub fn read_into_guest_address(&mut self, sector: u64, len: u32, data_gpa: u64) -> Result<Completion, Error> {
        let (mut e1, mut e2) = (0 as c_int, 0 as c_int);
        let hdr = unsafe { sfv_rs_arena_alloc(self.raw, 16, 16, &mut e1) };
        let sta = unsafe { sfv_rs_arena_alloc(self.raw, 1, 1, &mut e2) };
        check(e1)?; check(e2)?;
        let (mut st, mut used) = (0 as c_int, 0u32);
        check(unsafe { sfv_rs_blk_submit_wait(self.raw, 0, sector, data_gpa, len, hdr, sta, &mut st, &mut used) })?;
        Ok(Completion { status: st.into(), used_len: used })
    }
    pub fn health(&self) -> Result<(), Error> { check(unsafe { sfv_rs_check_health(self.raw) }) }
    pub fn recover(&mut self) -> Result<(), Error> { check(unsafe { sfv_rs_recover(self.raw) }) }
    /// Fault injection: guest address of the descriptor table, so a test can plant (malformed) descriptors.
    pub fn descriptor_table_gpa(&self) -> u64 { unsafe { sfv_rs_desc_gpa(self.raw) } }
    /// Fault injection: publish `head` in the available ring and ring the doorbell WITHOUT building a chain (the caller planted one).
    pub fn publish_raw_head(&mut self, head: u16) -> Result<(), Error> { check(unsafe { sfv_rs_publish_raw_head(self.raw, head) }) }
    #[doc(hidden)] pub fn soft_raw(&self) -> *mut c_void { self.soft }
}
impl Drop for Driver<'_> { fn drop(&mut self) { unsafe { sfv_rs_dev_free(self.raw) } } }
