// =============================================================================
//  sf_citadel_security.sv  --  SilicaFlux Albion "Citadel": cloud hardware
//                              security and reliability (top level)
// -----------------------------------------------------------------------------
//  Project 89.  Aureom.AI / SilicaFlux Albion.
//
//  Integrates
//    sf_citadel_domain_table    domain descriptors + privileged command interpreter
//    sf_citadel_permission x NP one hardware permission checker per master port
//                               (the physical port number is a structural constant
//                               of the instance: a master cannot choose its source)
//    sf_citadel_ras             reliability events, severity arbiter, audit counters
//    sf_citadel_fault_manager   containment policy
//  and provides: exact audit counters, privacy-scoped telemetry registers, the
//  containment outputs and the privileged configuration interface.
//
//  ENFORCEMENT MODEL.  Every master port is checked by sf_citadel_gate (ALP data
//  ports) or by a descriptor check point that presents {domain, op, attr, addr,
//  len, class, idx} on chk_* and honours chk_permit_o BEFORE any memory side effect
//  (DMA descriptor fetch, virtual-device descriptor, peripheral register access,
//  accelerator request, Meridian transaction).  Citadel decides; the check point
//  enforces.  The integration rule (docs/citadel/04): a master must reach memory or
//  devices ONLY through its check point.  An alternate path -- DFT / MBIST, JTAG, a
//  debug port -- is outside this module's control; dft_active_i makes Citadel deny
//  all data-plane traffic while test access is active, but it can neither police
//  the test accesses themselves nor secure an unlocked debug port.
//
//  PRIVILEGE.  Configuration is accepted only on the single command port and only
//  when cfg_en_i is high (boot authorised; see sf_citadel_secboot).  Telemetry:
//  the global registers need a privileged ROOT / MGMT requester ARRIVING ON A
//  MANAGEMENT-PLANE SOURCE PORT (TEL_PRIV_PORTS; the label alone is not trusted);
//  a tenant may read
//  ONLY its own per-domain registers, and only when its domain is verified for the
//  physical telemetry source port tel_src_i.  Any other read returns an explicit
//  error and ZERO data and is counted as an access violation: no cross-tenant
//  information is exposed.
//
//  HONEST STATUS.  Simulation + formal evidence only (docs/citadel/07).  This is
//  not a certified or validated security module; it contains no cryptography and
//  makes no tamper-resistance claim.
// =============================================================================
`default_nettype none

module sf_citadel_security #(
  parameter int unsigned NDOM  = 8,
  parameter int unsigned NW    = 4,
  parameter int unsigned NP    = 4,                      // master / check ports (1..8)
  parameter int unsigned NDEV  = 7,
  parameter int unsigned NQ    = 16,
  parameter int unsigned NKEY  = 8,
  parameter int unsigned AW    = 64,
  parameter int unsigned LEN_W = 32,
  parameter logic [NDEV*AW-1:0] DEV_BASE   = sf_citadel_pkg::SF_CIT_DEV_BASES_DEFAULT,
  parameter logic [NDEV*AW-1:0] DEV_MASK   = sf_citadel_pkg::SF_CIT_DEV_MASKS_DEFAULT,
  parameter logic [NDEV-1:0]    DEV_PRIV   = sf_citadel_pkg::SF_CIT_DEV_PRIV_DEFAULT,
  parameter logic [NDEV-1:0]    DEV_SECURE = sf_citadel_pkg::SF_CIT_DEV_SECURE_DEFAULT,
  parameter logic [NP-1:0]      DMA_PORTS  = '0,         // ports that carry DMA traffic (counted as invalid-DMA attempts)
  parameter logic [NP-1:0]      TEL_PRIV_PORTS = {{(NP-1){1'b0}}, 1'b1},   // telemetry source ports that are the MANAGEMENT plane (default: port 0)
  parameter bit          SECBOOT_EN   = 1'b0,        // an authenticated-boot block is wired to boot_* (see sf_citadel_secboot)
  parameter bit          ALLOW_UNAUTH = 1'b0,        // 1: with no root of trust, still open the configuration port (bring-up ONLY)
  parameter int unsigned BOOT_TIMEOUT = 0,
  parameter bit          CRYPTO_EN    = 1'b0,        // informational: a sf_citadel_crypto_adapter is instantiated by the integrator
  parameter int unsigned CNT_W    = 32,
  parameter int unsigned RST_HOLD = 0,
  parameter logic [15:0] LEVEL_MASK = 16'h0C08,
  localparam int unsigned SLOT_W = (NDOM > 1) ? $clog2(NDOM) : 1,
  localparam int unsigned WIN_W  = (NW   > 1) ? $clog2(NW)   : 1,
  localparam int unsigned PORT_W = (NP   > 1) ? $clog2(NP)   : 1
) (
  input  wire logic                   clk_i,
  input  wire logic                   rst_ni,
  // ---- platform --------------------------------------------------------------------
  input  wire logic                   cfg_en_i,           // privileged configuration enabled (boot authorised)
  input  wire logic                   dft_active_i,       // test / debug access to memory active
  // ---- authenticated-boot verdict (used only when SECBOOT_EN = 1) --------------------------------
  input  wire logic                   rot_present_i,      // platform tie-off: a real authenticated-boot block is integrated
  input  wire logic                   boot_done_i,
  input  wire logic                   boot_ok_i,
  input  wire logic [7:0]             boot_err_i,
  output logic                        fw_run_ok_o,        // authenticated firmware may execute
  output logic [2:0]                  boot_state_o,       // 0 ABSENT, 1 WAIT, 2 AUTH_OK, 3 FAILED
  output logic [7:0]                  boot_err_o,         // failure code for the PLATFORM (privileged telemetry is closed after a failed boot)
  // ---- privileged command port (management plane only) ---------------------------------
  input  wire logic                   cmd_valid_i,
  input  wire logic [3:0]             cmd_op_i,
  input  wire logic [7:0]             cmd_dom_i,
  input  wire logic                   cmd_priv_i,
  input  wire logic [SLOT_W-1:0]      cmd_slot_i,
  input  wire logic [WIN_W-1:0]       cmd_win_i,
  input  wire logic [PORT_W-1:0]      cmd_port_i,
  input  wire logic [7:0]             cmd_arg_dom_i,
  input  wire logic [7:0]             cmd_flags_i,
  input  wire logic [63:0]            cmd_data0_i,
  input  wire logic [63:0]            cmd_data1_i,
  output logic                        rsp_valid_o,
  output logic [3:0]                  rsp_status_o,
  // ---- check ports (one per master) -------------------------------------------------------
  input  wire logic [NP-1:0]          chk_valid_i,
  input  wire logic [NP-1:0]          chk_commit_i,       // the verdict is consumed this cycle (once per request)
  input  wire logic [NP*8-1:0]        chk_dom_i,
  input  wire logic [NP*4-1:0]        chk_op_i,
  input  wire logic [NP*8-1:0]        chk_attr_i,
  input  wire logic [NP*AW-1:0]       chk_addr_i,
  input  wire logic [NP*LEN_W-1:0]    chk_len_i,
  input  wire logic [NP*2-1:0]        chk_cls_i,
  input  wire logic [NP*8-1:0]        chk_idx_i,
  output logic [NP-1:0]               chk_permit_o,
  output logic [NP*4-1:0]             chk_status_o,       // requester-visible ALP status
  output logic [NP*4-1:0]             chk_reason_o,       // fine reason: PRIVILEGED AUDIT use only, never route to a requester
  // ---- reliability event inputs ---------------------------------------------------------------
  input  wire logic [15:0]            ev_i,               // sources 6 / 7 (access violations) are generated here and OR-ed in
  input  wire logic [15:0]            ev_dom_vld_i,
  input  wire logic [16*8-1:0]        ev_dom_i,
  input  wire logic [16*8-1:0]        ev_idx_i,
  input  wire logic [3:0]             ev_addr_vld_i,
  input  wire logic [4*AW-1:0]        ev_addr_i,
  // ---- containment outputs -----------------------------------------------------------------------
  output logic                        abort_valid_o,
  output logic [NQ-1:0]               abort_mask_o,
  output logic [NP-1:0]               eng_rst_o,
  input  wire logic [NP-1:0]          eng_rst_done_i,
  output logic [NQ-1:0]               qhold_o,
  output logic [NP-1:0]               port_isol_o,
  output logic                        lockdown_o,
  output logic                        safe_entry_o,       // pulse: the safe state was entered (notify / reset the platform)
  output logic                        irq_o,
  output logic                        zero_valid_o,       // key zeroise request (to sf_citadel_crypto_adapter)
  output logic [NKEY-1:0]             zero_mask_o,
  output logic                        zero_all_o,
  // ---- telemetry read port ---------------------------------------------------------------------------
  input  wire logic                   tel_valid_i,
  input  wire logic [7:0]             tel_addr_i,
  input  wire logic [7:0]             tel_dom_i,
  input  wire logic                   tel_priv_i,
  input  wire logic [PORT_W-1:0]      tel_src_i,
  output logic                        tel_rvalid_o,
  output logic [31:0]                 tel_rdata_o,
  output logic                        tel_err_o,
  // ---- exported domain state (for sf_citadel_crypto_adapter) ------------------------------------------
  output logic [NDOM*2-1:0]           slot_state_o,
  output logic [NDOM*8-1:0]           slot_id_o,
  output logic [NP*NDOM-1:0]          bind_o,
  output logic [NDOM*NKEY-1:0]        kmask_o,
  output logic                        cfg_lock_o
);

  if (NP < 1 || NP > 8 || NDOM > 32 || NQ > 32 || CNT_W < 8 || CNT_W > 32) begin : gen_param_check
    $error("sf_citadel_security: NP must be 1..8, NDOM <= 32, NQ <= 32, CNT_W 8..32");
  end

  // ---------------------------------------------------------------------------
  // authenticated-boot gate (policy only: no signature verification happens here)
  // ---------------------------------------------------------------------------
  logic        sb_cfg_open, sb_fail, sb_rot_active;
  logic [7:0]  sb_err;
  if (SECBOOT_EN) begin : gen_secboot
    sf_citadel_secboot #(.ALLOW_UNAUTH(ALLOW_UNAUTH), .BOOT_TIMEOUT(BOOT_TIMEOUT)) u_secboot (
      .clk_i(clk_i), .rst_ni(rst_ni), .rot_present_i(rot_present_i), .boot_done_i(boot_done_i), .boot_ok_i(boot_ok_i),
      .boot_err_i(boot_err_i), .state_o(boot_state_o), .cfg_open_o(sb_cfg_open), .fw_run_ok_o(fw_run_ok_o),
      .boot_fail_o(sb_fail), .err_o(sb_err), .rot_active_o(sb_rot_active));
  end else begin : gen_no_secboot
    // no authenticated boot is integrated: nothing is gated and nothing is claimed (telemetry reports state ABSENT)
    assign sb_cfg_open   = 1'b1;
    assign fw_run_ok_o   = 1'b1;
    assign boot_state_o  = 3'd0;
    assign sb_fail       = 1'b0;
    assign sb_err        = 8'd0;
    assign sb_rot_active = 1'b0;
    wire unused_boot = rot_present_i | boot_done_i | boot_ok_i | (|boot_err_i);
  end
  assign boot_err_o = sb_err;
  // the effective enable of every PRIVILEGED path: platform enable AND (when present) the authenticated-boot verdict
  wire cfg_en = cfg_en_i && sb_cfg_open;

  // ---------------------------------------------------------------------------
  // domain table + privileged command interpreter
  // ---------------------------------------------------------------------------
  logic                  cmd_deny, ctl_clr_safe, ctl_clr_cnt, ctl_thresh_we;
  logic [NQ-1:0]         ctl_clr_qhold;
  logic [NP-1:0]         ctl_clr_isol;
  logic [15:0]           ctl_thresh;
  logic                  qtn_valid;
  logic [SLOT_W-1:0]     qtn_slot;
  logic [NDOM-1:0]       slot_clr;
  logic [7:0]            look_dom;
  logic                  look_found, own_found;
  logic [SLOT_W-1:0]     look_slot, own_slot;
  logic [AW-1:0]         own_addr;
  logic [NDOM*2-1:0]     slot_state;
  logic [NDOM*8-1:0]     slot_id;
  logic [NDOM-1:0]       slot_priv, slot_secure;
  logic [NDOM*NW-1:0]    win_valid, win_r, win_w, win_x;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NDOM*NW-1:0]    win_excl;      // consumed inside the table (overlap guard, owner lookup); not needed here
  /* verilator lint_on UNUSEDSIGNAL */
  logic [NDOM*NW*AW-1:0] win_base, win_limit;
  logic [NDOM*NDEV-1:0]  devrd, devwr;
  logic [NDOM*NQ-1:0]    qmask;
  logic [NDOM*NKEY-1:0]  kmask;
  logic [NP*NDOM-1:0]    bind_v;
  logic                  cfg_lock;

  sf_citadel_domain_table #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(NDEV), .NQ(NQ), .NKEY(NKEY), .AW(AW),
                            .DEV_BASE(DEV_BASE), .DEV_MASK(DEV_MASK)) u_table (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .cfg_en_i(cfg_en), .cmd_valid_i(cmd_valid_i), .cmd_op_i(cmd_op_i), .cmd_dom_i(cmd_dom_i), .cmd_priv_i(cmd_priv_i),
    .cmd_slot_i(cmd_slot_i), .cmd_win_i(cmd_win_i), .cmd_port_i(cmd_port_i), .cmd_arg_dom_i(cmd_arg_dom_i),
    .cmd_flags_i(cmd_flags_i), .cmd_data0_i(cmd_data0_i), .cmd_data1_i(cmd_data1_i),
    .rsp_valid_o(rsp_valid_o), .rsp_status_o(rsp_status_o), .cmd_deny_o(cmd_deny),
    .ctl_clr_qhold_o(ctl_clr_qhold), .ctl_clr_isol_o(ctl_clr_isol), .ctl_clr_safe_o(ctl_clr_safe),
    .ctl_clr_cnt_o(ctl_clr_cnt), .ctl_thresh_we_o(ctl_thresh_we), .ctl_thresh_o(ctl_thresh),
    .qtn_valid_i(qtn_valid), .qtn_slot_i(qtn_slot),
    .zero_valid_o(zero_valid_o), .zero_mask_o(zero_mask_o), .slot_clr_o(slot_clr),
    .look_dom_i(look_dom), .look_found_o(look_found), .look_slot_o(look_slot),
    .own_addr_i(own_addr), .own_found_o(own_found), .own_slot_o(own_slot),
    .slot_state_o(slot_state), .slot_id_o(slot_id), .slot_priv_o(slot_priv), .slot_secure_o(slot_secure),
    .win_valid_o(win_valid), .win_base_o(win_base), .win_limit_o(win_limit), .win_r_o(win_r), .win_w_o(win_w),
    .win_x_o(win_x), .win_excl_o(win_excl), .devrd_o(devrd), .devwr_o(devwr), .qmask_o(qmask), .kmask_o(kmask),
    .bind_o(bind_v), .lock_o(cfg_lock));

  assign slot_state_o = slot_state;
  assign slot_id_o    = slot_id;
  assign bind_o       = bind_v;
  assign kmask_o      = kmask;
  assign cfg_lock_o   = cfg_lock;

  // ---------------------------------------------------------------------------
  // permission checkers: one per physical port
  // ---------------------------------------------------------------------------
  logic [NQ-1:0]   qhold;
  logic [NP-1:0]   port_isol;
  logic            lockdown;
  logic [NP-1:0]   chk_slot_vld;
  logic [NP*SLOT_W-1:0] chk_slot;

  for (genvar p = 0; p < NP; p++) begin : gen_port
    sf_citadel_permission #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(NDEV), .NQ(NQ), .AW(AW), .LEN_W(LEN_W),
                            .DEV_BASE(DEV_BASE), .DEV_MASK(DEV_MASK), .DEV_PRIV(DEV_PRIV), .DEV_SECURE(DEV_SECURE)) u_perm (
      .src_i(PORT_W'(p)),                                       // physical anchor: a structural constant
      .dom_i(chk_dom_i[p*8 +: 8]), .op_i(chk_op_i[p*4 +: 4]), .attr_i(chk_attr_i[p*8 +: 8]),
      .addr_i(chk_addr_i[p*AW +: AW]), .len_i(chk_len_i[p*LEN_W +: LEN_W]), .cls_i(chk_cls_i[p*2 +: 2]),
      .idx_i(chk_idx_i[p*8 +: 8]),
      .lockdown_i(lockdown), .dft_active_i(dft_active_i), .qhold_i(qhold), .port_isol_i(port_isol),
      .slot_state_i(slot_state), .slot_id_i(slot_id), .slot_priv_i(slot_priv), .slot_secure_i(slot_secure),
      .win_valid_i(win_valid), .win_base_i(win_base), .win_limit_i(win_limit), .win_r_i(win_r), .win_w_i(win_w),
      .win_x_i(win_x), .devrd_i(devrd), .devwr_i(devwr), .qmask_i(qmask), .bind_i(bind_v),
      .permit_o(chk_permit_o[p]), .reason_o(chk_reason_o[p*4 +: 4]), .status_o(chk_status_o[p*4 +: 4]),
      .slot_vld_o(chk_slot_vld[p]), .slot_o(chk_slot[p*SLOT_W +: SLOT_W]));
  end

  // ---------------------------------------------------------------------------
  // violation accounting (exact, per committed denial)
  // ---------------------------------------------------------------------------
  logic [NP-1:0] deny_c, deny_dma, deny_gen;
  always_comb begin
    for (int unsigned p = 0; p < NP; p++) deny_c[p] = chk_valid_i[p] && chk_commit_i[p] && !chk_permit_o[p];
    deny_dma = deny_c & DMA_PORTS;
    deny_gen = deny_c & ~DMA_PORTS;
  end

  // ---- telemetry privilege + decode (needed by the violation count) -------------------------------------
  // The ROOT / MGMT label is NOT trusted on its own here either: privileged telemetry is served only on a source port
  // wired to the management plane (TEL_PRIV_PORTS, a structural constant like the check-port index).  A tenant-facing
  // port that presents the ROOT label with priv = 1 is an access violation, exactly like a spoofed data-plane label.
  wire  [31:0]       tel_src_ext = {{(32-PORT_W){1'b0}}, tel_src_i};
  logic              tel_priv_port;
  always_comb begin
    tel_priv_port = 1'b0;
    for (int unsigned p = 0; p < NP; p++) if ((tel_src_ext == p) && TEL_PRIV_PORTS[p]) tel_priv_port = 1'b1;
  end
  wire tel_priv_ok = tel_priv_i && tel_priv_port &&
                     (tel_dom_i == sf_albion_pkg::SF_DOM_ROOT || tel_dom_i == sf_albion_pkg::SF_DOM_MGMT) && cfg_en;
  logic              tel_own_found;
  logic [SLOT_W-1:0] tel_own_slot;
  always_comb begin
    tel_own_found = 1'b0;
    tel_own_slot  = '0;
    for (int unsigned s = 0; s < NDOM; s++) begin
      if (!tel_own_found && (slot_state[s*2 +: 2] != sf_citadel_pkg::SF_CIT_DS_INVALID) && (slot_id[s*8 +: 8] == tel_dom_i)) begin
        for (int unsigned p = 0; p < NP; p++) begin
          if ((tel_src_ext == p) && bind_v[p*NDOM + s]) begin
            tel_own_found = 1'b1;
            tel_own_slot  = SLOT_W'(s);
          end
        end
      end
    end
  end
  wire tel_is_slot_reg = (tel_addr_i >= 8'h80);
  wire [7:0] tel_slot_ix = (tel_addr_i - 8'h80) >> 2;
  wire tel_own_access = tel_is_slot_reg && tel_own_found && !tel_priv_ok && (tel_slot_ix == {{(8-SLOT_W){1'b0}}, tel_own_slot});
  wire tel_slot_in_range = tel_is_slot_reg && (tel_slot_ix < 8'(NDOM));
  // AUTHORISATION is separate from register EXISTENCE: an unauthorised requester is an access violation (counted);
  // a privileged requester naming an undefined register just gets an error (no violation, no data)
  wire tel_allowed = tel_priv_ok || tel_own_access;
  wire tel_deny    = tel_valid_i && !tel_allowed;

  // ---- first denial attribution + counts -------------------------------------------------------------------------
  logic [3:0]  n_gen, n_dma;
  logic        gen_dvld, dma_dvld;
  logic [7:0]  gen_dom, dma_dom, gen_idx, dma_idx;
  always_comb begin
    n_gen = 4'd0; n_dma = 4'd0;
    gen_dvld = 1'b0; dma_dvld = 1'b0; gen_dom = 8'd0; dma_dom = 8'd0; gen_idx = 8'd0; dma_idx = 8'd0;
    for (int unsigned p = 0; p < NP; p++) begin
      if (deny_gen[p]) begin
        if (n_gen == 4'd0) begin
          gen_dvld = chk_slot_vld[p];               // attribute only a VERIFIED domain (never a spoofed label)
          gen_dom  = chk_dom_i[p*8 +: 8];
          gen_idx  = 8'(p);
        end
        n_gen = n_gen + 4'd1;
      end
      if (deny_dma[p]) begin
        if (n_dma == 4'd0) begin
          dma_dvld = chk_slot_vld[p];
          dma_dom  = chk_dom_i[p*8 +: 8];
          dma_idx  = 8'(p);
        end
        n_dma = n_dma + 4'd1;
      end
    end
    // privileged-command and telemetry denials count as access violations too
    n_gen = n_gen + {3'd0, cmd_deny} + {3'd0, tel_deny};
  end

  // ---------------------------------------------------------------------------
  // reliability events
  // ---------------------------------------------------------------------------
  logic [15:0]      ev_all, ev_dvld;
  logic [16*8-1:0]  ev_dom_all, ev_idx_all;
  logic [16*4-1:0]  ev_extra;
  always_comb begin
    ev_all     = ev_i;
    ev_dvld    = ev_dom_vld_i;
    ev_dom_all = ev_dom_i;
    ev_idx_all = ev_idx_i;
    ev_extra   = '0;
    ev_all[sf_citadel_pkg::SF_CIT_SRC_BOOT_FAIL]   = sb_fail || ev_i[sf_citadel_pkg::SF_CIT_SRC_BOOT_FAIL];   // FATAL: safe state + auth-failure counter
    ev_all[sf_citadel_pkg::SF_CIT_SRC_ILLEGAL]     = (n_gen != 4'd0) || ev_i[sf_citadel_pkg::SF_CIT_SRC_ILLEGAL];
    ev_all[sf_citadel_pkg::SF_CIT_SRC_INVALID_DMA] = (n_dma != 4'd0) || ev_i[sf_citadel_pkg::SF_CIT_SRC_INVALID_DMA];
    ev_dvld[sf_citadel_pkg::SF_CIT_SRC_ILLEGAL]     = (n_gen != 4'd0) ? gen_dvld : ev_dom_vld_i[sf_citadel_pkg::SF_CIT_SRC_ILLEGAL];
    ev_dvld[sf_citadel_pkg::SF_CIT_SRC_INVALID_DMA] = (n_dma != 4'd0) ? dma_dvld : ev_dom_vld_i[sf_citadel_pkg::SF_CIT_SRC_INVALID_DMA];
    if (n_gen != 4'd0) begin
      ev_dom_all[sf_citadel_pkg::SF_CIT_SRC_ILLEGAL*8 +: 8] = gen_dom;
      ev_idx_all[sf_citadel_pkg::SF_CIT_SRC_ILLEGAL*8 +: 8] = gen_idx;
      // n_gen internal occurrences, one of which is the pulse itself; an EXTERNAL pulse of the same source in the same
      // cycle is one more occurrence (counted exactly -- NP + 2 <= 10, so the 4-bit sum cannot overflow)
      ev_extra[sf_citadel_pkg::SF_CIT_SRC_ILLEGAL*4 +: 4]   = n_gen - 4'd1 + {3'd0, ev_i[sf_citadel_pkg::SF_CIT_SRC_ILLEGAL]};
    end
    if (n_dma != 4'd0) begin
      ev_dom_all[sf_citadel_pkg::SF_CIT_SRC_INVALID_DMA*8 +: 8] = dma_dom;
      ev_idx_all[sf_citadel_pkg::SF_CIT_SRC_INVALID_DMA*8 +: 8] = dma_idx;
      ev_extra[sf_citadel_pkg::SF_CIT_SRC_INVALID_DMA*4 +: 4]   = n_dma - 4'd1 + {3'd0, ev_i[sf_citadel_pkg::SF_CIT_SRC_INVALID_DMA]};
    end
  end

  // FATAL-severity LEVEL sources (from the fixed severity policy): while one is still asserted, CLR_SAFE has no effect
  function automatic logic [15:0] fatal_srcs(input logic [127:0] pol);
    logic [15:0] m;
    begin
      m = '0;
      for (int unsigned s = 0; s < 16; s++) m[s] = (pol[s*8 + 5 +: 2] == sf_citadel_pkg::SF_CIT_SEV_FATAL);
      fatal_srcs = m;
    end
  endfunction
  localparam logic [15:0] FATAL_SRCS = fatal_srcs(sf_citadel_pkg::SF_CIT_POLICY);
  wire lvl_fatal = |(ev_all & LEVEL_MASK & FATAL_SRCS);

  logic                sel_valid, sel_dom_vld, sel_addr_vld, sel_ack;
  logic [3:0]          sel_src;
  logic [1:0]          sel_sev;
  logic [7:0]          sel_dom, sel_idx;
  logic [AW-1:0]       sel_addr;
  logic [15:0]         pend, overrun;
  logic [16*CNT_W-1:0] src_cnt;
  logic [4*CNT_W-1:0]  sev_cnt;
  logic [CNT_W-1:0]    aud_viol, aud_dma, aud_auth, aud_ce, aud_uncorr, aud_queue, aud_reset;
  logic                rst_evt;

  sf_citadel_ras #(.AW(AW), .CNT_W(CNT_W), .LEVEL_MASK(LEVEL_MASK)) u_ras (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .ev_i(ev_all), .ev_extra_i(ev_extra), .ev_dom_vld_i(ev_dvld), .ev_dom_i(ev_dom_all), .ev_idx_i(ev_idx_all),
    .ev_addr_vld_i(ev_addr_vld_i), .ev_addr_i(ev_addr_i),
    .sel_valid_o(sel_valid), .sel_src_o(sel_src), .sel_sev_o(sel_sev), .sel_dom_vld_o(sel_dom_vld), .sel_dom_o(sel_dom),
    .sel_idx_o(sel_idx), .sel_addr_vld_o(sel_addr_vld), .sel_addr_o(sel_addr), .sel_ack_i(sel_ack),
    .clr_cnt_i(ctl_clr_cnt), .rst_evt_i(rst_evt),
    .pend_o(pend), .overrun_o(overrun), .src_cnt_o(src_cnt), .sev_cnt_o(sev_cnt),
    .aud_viol_o(aud_viol), .aud_dma_o(aud_dma), .aud_auth_o(aud_auth), .aud_ce_o(aud_ce),
    .aud_uncorr_o(aud_uncorr), .aud_queue_o(aud_queue), .aud_reset_o(aud_reset));

  logic        last_valid, last_dom_vld;
  logic [3:0]  last_src;
  logic [1:0]  last_sev, worst_sev;
  logic [7:0]  last_dom, last_idx;
  logic [4:0]  last_act;

  sf_citadel_fault_manager #(.NDOM(NDOM), .NP(NP), .NQ(NQ), .AW(AW), .RST_HOLD(RST_HOLD)) u_fm (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .sel_valid_i(sel_valid), .sel_src_i(sel_src), .sel_sev_i(sel_sev), .sel_dom_vld_i(sel_dom_vld), .sel_dom_i(sel_dom),
    .sel_idx_i(sel_idx), .sel_addr_vld_i(sel_addr_vld), .sel_addr_i(sel_addr), .sel_ack_o(sel_ack),
    .look_dom_o(look_dom), .look_found_i(look_found), .look_slot_i(look_slot),
    .own_addr_o(own_addr), .own_found_i(own_found), .own_slot_i(own_slot),
    .slot_id_i(slot_id), .qmask_i(qmask),
    .qtn_valid_o(qtn_valid), .qtn_slot_o(qtn_slot),
    .abort_valid_o(abort_valid_o), .abort_mask_o(abort_mask_o), .eng_rst_o(eng_rst_o),
    .qhold_o(qhold), .port_isol_o(port_isol), .lockdown_o(lockdown),
    .safe_entry_o(safe_entry_o), .zero_all_o(zero_all_o), .rst_evt_o(rst_evt),
    .clr_qhold_i(ctl_clr_qhold), .clr_isol_i(ctl_clr_isol), .clr_safe_i(ctl_clr_safe), .lvl_fatal_i(lvl_fatal), .clr_rep_i(ctl_clr_cnt),
    .eng_rst_done_i(eng_rst_done_i),
    .irq_o(irq_o), .last_valid_o(last_valid), .last_src_o(last_src), .last_sev_o(last_sev),
    .last_dom_vld_o(last_dom_vld), .last_dom_o(last_dom), .last_idx_o(last_idx), .last_act_o(last_act),
    .worst_sev_o(worst_sev));

  assign qhold_o     = qhold;
  assign port_isol_o = port_isol;
  assign lockdown_o  = lockdown;

  // ---------------------------------------------------------------------------
  // per-domain and per-port violation counters (saturating 16 bit)
  // ---------------------------------------------------------------------------
  logic [NDOM*16-1:0] dom_viol_q;
  logic [NDOM-1:0]    dom_alert_q;
  logic [NP*16-1:0]   port_viol_q;
  logic [15:0]        thresh_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni)              thresh_q <= 16'd0;
    else if (ctl_thresh_we)   thresh_q <= ctl_thresh;
  end

  for (genvar s = 0; s < NDOM; s++) begin : gen_dviol
    logic [3:0] inc;
    always_comb begin
      inc = 4'd0;
      for (int unsigned p = 0; p < NP; p++) begin
        // only a VERIFIED domain is charged (a spoofed label would let one tenant raise another's counter)
        if (deny_c[p] && chk_slot_vld[p] && (chk_slot[p*SLOT_W +: SLOT_W] == SLOT_W'(s))) inc = inc + 4'd1;
      end
    end
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        dom_viol_q[s*16 +: 16] <= 16'd0;
        dom_alert_q[s]         <= 1'b0;
      end else if (slot_clr[s] || ctl_clr_cnt) begin
        dom_viol_q[s*16 +: 16] <= 16'd0;                  // a new tenant never inherits a previous tenant's counters
        dom_alert_q[s]         <= 1'b0;
      end else begin
        if (({1'b0, dom_viol_q[s*16 +: 16]} + {13'd0, inc}) > 17'h0FFFF) dom_viol_q[s*16 +: 16] <= 16'hFFFF;
        else                                                              dom_viol_q[s*16 +: 16] <= dom_viol_q[s*16 +: 16] + {12'd0, inc};
        if ((thresh_q != 16'd0) && (({1'b0, dom_viol_q[s*16 +: 16]} + {13'd0, inc}) >= {1'b0, thresh_q})) dom_alert_q[s] <= 1'b1;
      end
    end
  end

  for (genvar p = 0; p < NP; p++) begin : gen_pviol
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni)                port_viol_q[p*16 +: 16] <= 16'd0;
      else if (ctl_clr_cnt)       port_viol_q[p*16 +: 16] <= 16'd0;
      else if (deny_c[p] && port_viol_q[p*16 +: 16] != 16'hFFFF) port_viol_q[p*16 +: 16] <= port_viol_q[p*16 +: 16] + 16'd1;
    end
  end

  // ---------------------------------------------------------------------------
  // telemetry registers (read-only, 1-cycle latency)
  // ---------------------------------------------------------------------------
  logic [31:0] rd_mux;
  logic        rd_ok;
  logic [31:0] caps_w;
  //  CAPS: [0] telemetry  [1] secure-boot INTERFACE wired (SECBOOT_EN)  [2] domain isolation  [3] RAS  [4] crypto adapter wired (CRYPTO_EN)
  //        [5] a root of trust is PRESENT (live platform tie-off, not a register)  [15:8] NDOM  [23:16] NP  [31:24] NQ
  assign caps_w = {8'(NQ), 8'(NP), 8'(NDOM), 2'b00, (SECBOOT_EN && rot_present_i), CRYPTO_EN, 1'b1 /* RAS */,
                   1'b1 /* domain isolation */, SECBOOT_EN, 1'b1 /* telemetry */};

  always_comb begin
    rd_mux = 32'd0;
    rd_ok  = 1'b1;
    if (tel_is_slot_reg) begin
      rd_ok = tel_slot_in_range;
      for (int unsigned s = 0; s < NDOM; s++) begin
        if (tel_slot_ix == 8'(s)) begin
          case (tel_addr_i[1:0])
            2'd0:    rd_mux = {slot_state[s*2 +: 2], 22'd0, slot_id[s*8 +: 8]};
            2'd1:    rd_mux = {15'd0, dom_alert_q[s], dom_viol_q[s*16 +: 16]};
            default: rd_mux = 32'd0;
          endcase
        end
      end
    end else begin
      case (tel_addr_i)
        8'h00: rd_mux = {16'hC17A, 8'(sf_citadel_pkg::SF_CIT_VERSION_MAJOR), 8'(sf_citadel_pkg::SF_CIT_VERSION_MINOR)};
        8'h01: rd_mux = caps_w;
        8'h02: rd_mux = {25'd0, sb_rot_active, 1'b0, cfg_en, dft_active_i, irq_o, cfg_lock, lockdown};
        8'h03: rd_mux = {11'd0, last_valid, last_sev, last_src, last_dom_vld, last_act, last_idx};
        8'h04: rd_mux = {24'd0, last_dom};
        8'h05: rd_mux = {30'd0, worst_sev};
        8'h06: rd_mux = {16'd0, thresh_q};
        8'h07: rd_mux = {19'd0, SECBOOT_EN, rot_present_i, boot_state_o, sb_err};          // boot status: what is actually true
        8'h10: rd_mux = aud_viol;
        8'h11: rd_mux = aud_dma;
        8'h12: rd_mux = aud_auth;
        8'h13: rd_mux = aud_ce;
        8'h14: rd_mux = aud_uncorr;
        8'h15: rd_mux = aud_queue;
        8'h16: rd_mux = aud_reset;
        8'h18: rd_mux = sev_cnt[0*CNT_W +: CNT_W];
        8'h19: rd_mux = sev_cnt[1*CNT_W +: CNT_W];
        8'h1A: rd_mux = sev_cnt[2*CNT_W +: CNT_W];
        8'h1B: rd_mux = sev_cnt[3*CNT_W +: CNT_W];
        8'h30: rd_mux = {overrun, pend};
        8'h31: rd_mux = 32'(qhold);
        8'h32: rd_mux = 32'(port_isol);
        default: begin
          rd_ok = 1'b0;
          if (tel_addr_i >= 8'h20 && tel_addr_i < 8'h30) begin
            rd_ok = 1'b1;
            for (int unsigned s = 0; s < 16; s++) if (tel_addr_i[3:0] == 4'(s)) rd_mux = src_cnt[s*CNT_W +: CNT_W];
          end else if (tel_addr_i >= 8'h40 && tel_addr_i < 8'h48) begin
            for (int unsigned p = 0; p < NP; p++) begin
              if (tel_addr_i[2:0] == 3'(p)) begin
                rd_ok = 1'b1;
                rd_mux = {16'd0, port_viol_q[p*16 +: 16]};
              end
            end
          end
        end
      endcase
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      tel_rvalid_o <= 1'b0;
      tel_rdata_o  <= 32'd0;
      tel_err_o    <= 1'b0;
    end else begin
      tel_rvalid_o <= tel_valid_i;
      // an unauthorised or undefined read returns an explicit error and ZERO data (no information leak)
      tel_rdata_o  <= (tel_valid_i && tel_allowed && rd_ok) ? rd_mux : 32'd0;
      tel_err_o    <= tel_valid_i && !(tel_allowed && rd_ok);
    end
  end

endmodule

`default_nettype wire
