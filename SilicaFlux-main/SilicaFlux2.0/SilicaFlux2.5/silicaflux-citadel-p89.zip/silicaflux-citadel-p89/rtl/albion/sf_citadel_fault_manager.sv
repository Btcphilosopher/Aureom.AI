// =============================================================================
//  sf_citadel_fault_manager.sv  --  Citadel fault containment policy
// -----------------------------------------------------------------------------
//  Takes ONE normalised event per cycle from sf_citadel_ras (most severe first)
//  and applies the SMALLEST containment that is sufficient, so that unrelated
//  domains, queues and engines keep their state:
//
//    event severity / source            action
//    ---------------------------------  ---------------------------------------
//    corrected                          count / log only
//    detected  (reject)                 the operation was already refused; log;
//                                       queue sources abort + hold THAT queue
//    uncorrectable, attributed to a     quarantine THAT domain (state kept for
//      TENANT domain                    forensics), abort its queues, request
//                                       zeroisation of its keys
//    uncorrectable, attributed to a     escalate to the SAFE STATE (platform
//      SYSTEM domain (0x00..0x0F)       memory is corrupt)
//    uncorrectable, NOT attributable    report only -- no victim is guessed
//    engine sources (watchdog,          isolate THAT engine / port, pulse its
//      compute error)                   reset; the port reopens on eng_rst_done_i
//                                       (or after RST_HOLD cycles when > 0, or on
//                                       a privileged CLR_ISOL)
//    fatal                              SAFE STATE
//
//  Attribution: an explicit domain id from the event source, else the owner of
//  the faulting address = the domain holding an EXCLUSIVE window over it (unique
//  by INV-EXCL).  An address owned by nobody is not attributed.
//
//  SAFE STATE (defined, sticky): (1) lockdown_o -- every data-plane request is
//  denied except those of verified ROOT / MGMT; (2) every queue is aborted and
//  held; (3) zero_all_o -- all keys are zeroised; (4) the fault is reported
//  (irq_o).  Engines are NOT reset automatically.  Released only by a privileged
//  ROOT CLR_SAFE (queue holds are cleared separately by CLR_QHOLD).
//
//  Set wins over clear when both happen in one cycle (fail closed).  Reset
//  clears every register: no containment state survives reset.
//
//  A "done" from the engine counts only if it is seen AFTER the cycle in which the
//  reset request was presented (a done that was already high is not an answer to
//  this reset).  A done tied permanently high therefore still ends the isolation
//  after two cycles: the engine's honesty about "done" is assumption A-ACT.
//
//  Telemetry record: last_* holds the last UNCORRECTABLE / FATAL event only; worst_sev_o is the maximum severity of
//  any event since the last acknowledge.
// =============================================================================
`default_nettype none

module sf_citadel_fault_manager #(
  parameter int unsigned NDOM     = 8,
  parameter int unsigned NP       = 4,
  parameter int unsigned NQ       = 16,
  parameter int unsigned AW       = 64,
  parameter int unsigned RST_HOLD = 0,                    // 0 = isolation ends only on done / CLR_ISOL (fail closed)
  parameter logic [127:0] POLICY  = sf_citadel_pkg::SF_CIT_POLICY,
  parameter logic [15:0] QUEUE_IDX_SRC = 16'h4030,        // sources whose ev idx is a QUEUE number: 4, 5, 14
  localparam int unsigned SLOT_W  = (NDOM > 1) ? $clog2(NDOM) : 1
) (
  input  wire logic                clk_i,
  input  wire logic                rst_ni,
  // ---- selected event (from sf_citadel_ras) ----------------------------------
  input  wire logic                sel_valid_i,
  input  wire logic [3:0]          sel_src_i,
  input  wire logic [1:0]          sel_sev_i,
  input  wire logic                sel_dom_vld_i,
  input  wire logic [7:0]          sel_dom_i,
  input  wire logic [7:0]          sel_idx_i,
  input  wire logic                sel_addr_vld_i,
  input  wire logic [AW-1:0]       sel_addr_i,
  output logic                     sel_ack_o,
  // ---- lookups into the domain table --------------------------------------------
  output logic [7:0]               look_dom_o,
  input  wire logic                look_found_i,
  input  wire logic [SLOT_W-1:0]   look_slot_i,
  output logic [AW-1:0]            own_addr_o,
  input  wire logic                own_found_i,
  input  wire logic [SLOT_W-1:0]   own_slot_i,
  input  wire logic [NDOM*8-1:0]   slot_id_i,
  input  wire logic [NDOM*NQ-1:0]  qmask_i,
  // ---- containment actions -----------------------------------------------------------
  output logic                     qtn_valid_o,            // -> domain table: quarantine this slot
  output logic [SLOT_W-1:0]        qtn_slot_o,
  output logic                     abort_valid_o,          // registered pulse
  output logic [NQ-1:0]            abort_mask_o,           // queues to abort (valid with abort_valid_o)
  output logic [NP-1:0]            eng_rst_o,              // registered one-cycle reset request per engine / port
  output logic [NQ-1:0]            qhold_o,                // state: queue use refused
  output logic [NP-1:0]            port_isol_o,            // state: source port refused
  output logic                     lockdown_o,             // state: safe state
  output logic                     safe_entry_o,           // pulse: safe state entered
  output logic                     zero_all_o,             // pulse: zeroise every key
  output logic                     rst_evt_o,              // pulse: engine reset or safe-state entry issued
  // ---- privileged controls (registered pulses from the table) ----------------------------
  input  wire logic [NQ-1:0]       clr_qhold_i,
  input  wire logic [NP-1:0]       clr_isol_i,
  input  wire logic                clr_safe_i,
  input  wire logic                lvl_fatal_i,            // a FATAL level condition (e.g. critical temperature) is STILL asserted
  input  wire logic                clr_rep_i,              // acknowledge: clear the report / worst-severity record
  input  wire logic [NP-1:0]       eng_rst_done_i,
  // ---- report / last-fault record -----------------------------------------------------------
  output logic                     irq_o,
  output logic                     last_valid_o,
  output logic [3:0]               last_src_o,
  output logic [1:0]               last_sev_o,
  output logic                     last_dom_vld_o,
  output logic [7:0]               last_dom_o,
  output logic [7:0]               last_idx_o,
  output logic [4:0]               last_act_o,
  output logic [1:0]               worst_sev_o
);

  // ---------------------------------------------------------------------------
  // attribution
  // ---------------------------------------------------------------------------
  assign look_dom_o = sel_dom_i;
  assign own_addr_o = sel_addr_i;

  logic              dom_found;
  logic [SLOT_W-1:0] dom_slot;
  logic [7:0]        dom_id;
  logic [NQ-1:0]     dom_qmask;
  always_comb begin
    dom_found = 1'b0;
    dom_slot  = '0;
    if (sel_dom_vld_i) begin
      dom_found = look_found_i;
      dom_slot  = look_slot_i;
    end else if (sel_addr_vld_i) begin
      dom_found = own_found_i;
      dom_slot  = own_slot_i;
    end
    dom_id    = 8'h00;
    dom_qmask = '0;
    for (int unsigned s = 0; s < NDOM; s++) begin
      if (dom_slot == SLOT_W'(s)) begin
        dom_id    = slot_id_i[s*8 +: 8];
        dom_qmask = qmask_i[s*NQ +: NQ];
      end
    end
  end
  wire dom_tenant = dom_found && (dom_id >= sf_albion_pkg::SF_DOM_TENANT_FIRST) &&
                    (dom_id <= sf_albion_pkg::SF_DOM_TENANT_LAST);
  wire dom_system = dom_found && !dom_tenant;

  // ---------------------------------------------------------------------------
  // effective actions
  // ---------------------------------------------------------------------------
  wire [4:0] act       = POLICY[sel_src_i*8 +: 5];        // base action mask of the source (severity is applied in the RAS)
  wire       queue_src = QUEUE_IDX_SRC[sel_src_i];
  wire [31:0] idx_ext  = {24'd0, sel_idx_i};
  wire       idx_is_q  = (idx_ext < NQ);
  wire       idx_is_p  = (idx_ext < NP);

  wire eff_qtn   = sel_valid_i && act[sf_citadel_pkg::SF_CIT_ACT_QUARANTINE] && dom_tenant;
  wire eff_safe  = sel_valid_i && (act[sf_citadel_pkg::SF_CIT_ACT_SAFE_STATE] ||
                                   (act[sf_citadel_pkg::SF_CIT_ACT_QUARANTINE] && dom_system));
  wire eff_rst   = sel_valid_i && act[sf_citadel_pkg::SF_CIT_ACT_RST_ENGINE] && !queue_src && idx_is_p;
  wire eff_rep   = sel_valid_i && (act[sf_citadel_pkg::SF_CIT_ACT_REPORT] || eff_safe);

  logic [NQ-1:0] abort_d;
  always_comb begin
    abort_d = '0;
    if (sel_valid_i && act[sf_citadel_pkg::SF_CIT_ACT_ABORT_Q]) begin
      if (queue_src && idx_is_q) begin
        for (int unsigned q = 0; q < NQ; q++) if (idx_ext == q) abort_d[q] = 1'b1;
      end else if (dom_found) begin
        abort_d = dom_qmask;
      end
    end
    if (eff_qtn) abort_d = abort_d | dom_qmask;
    if (eff_safe) abort_d = '1;
  end

  logic [NP-1:0] rst_d;
  always_comb begin
    rst_d = '0;
    if (eff_rst) begin
      for (int unsigned p = 0; p < NP; p++) if (idx_ext == p) rst_d[p] = 1'b1;
    end
  end

  assign sel_ack_o   = sel_valid_i;                 // one event per cycle, always consumed
  assign qtn_valid_o = eff_qtn;
  assign qtn_slot_o  = dom_slot;

  // ---------------------------------------------------------------------------
  // state
  // ---------------------------------------------------------------------------
  if (RST_HOLD > 65535) begin : gen_param_check
    $error("sf_citadel_fault_manager: RST_HOLD must be 0 .. 65535 (16-bit hold timer)");
  end

  // CLR_SAFE has no effect while a FATAL level condition persists: a level source raises its event only on the rising
  // edge, so releasing the safe state under a still-present condition would leave the device running with it and no
  // new event to re-enter.  The command is accepted by the table (status OK); the effect is visible on lockdown_o.
  wire clr_safe_eff = clr_safe_i && !lvl_fatal_i;

  logic [NQ-1:0] qhold_q;
  logic [NP-1:0] isol_q;
  logic          lock_q, rep_q;
  logic [NP*16-1:0] hold_cnt_q;
  assign qhold_o     = qhold_q;
  assign port_isol_o = isol_q;
  assign lockdown_o  = lock_q;
  assign irq_o       = rep_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      qhold_q <= '0; isol_q <= '0; lock_q <= 1'b0; rep_q <= 1'b0;
      abort_valid_o <= 1'b0; abort_mask_o <= '0; eng_rst_o <= '0;
      safe_entry_o <= 1'b0; zero_all_o <= 1'b0; rst_evt_o <= 1'b0;
      last_valid_o <= 1'b0; last_src_o <= 4'd0; last_sev_o <= 2'd0; last_dom_vld_o <= 1'b0; last_dom_o <= 8'd0;
      last_idx_o <= 8'd0; last_act_o <= 5'd0; worst_sev_o <= 2'd0;
    end else begin
      // queue holds: clear by privileged command, set wins
      qhold_q <= (qhold_q & ~clr_qhold_i) | abort_d;
      abort_valid_o <= (abort_d != '0);
      abort_mask_o  <= abort_d;
      // engine isolation
      eng_rst_o <= rst_d;
      for (int unsigned p = 0; p < NP; p++) begin
        if (rst_d[p]) begin
          isol_q[p] <= 1'b1;
        end else if (isol_q[p] && ((eng_rst_done_i[p] && !eng_rst_o[p]) || clr_isol_i[p] ||
                                   ((RST_HOLD != 0) && (hold_cnt_q[p*16 +: 16] >= 16'(RST_HOLD))))) begin
          isol_q[p] <= 1'b0;
        end
      end
      // safe state: set wins over CLR_SAFE
      if (eff_safe) lock_q <= 1'b1;
      else if (clr_safe_eff) lock_q <= 1'b0;
      safe_entry_o <= eff_safe && !lock_q;
      zero_all_o   <= eff_safe && !lock_q;
      rst_evt_o    <= (|rst_d) || (eff_safe && !lock_q);
      // report + last record
      if (eff_rep) rep_q <= 1'b1;
      else if (clr_rep_i) rep_q <= 1'b0;
      // The last-fault record holds only UNCORRECTABLE / FATAL events.  Corrected and detected events (in particular
      // the access violations a tenant can generate at will) are COUNTED exactly but never overwrite it, so no
      // tenant can hide a hardware fault from the management plane by generating denials.
      if (sel_valid_i && (sel_sev_i >= sf_citadel_pkg::SF_CIT_SEV_UNCORRECTABLE)) begin
        last_valid_o   <= 1'b1;
        last_src_o     <= sel_src_i;
        last_sev_o     <= sel_sev_i;
        last_dom_vld_o <= dom_found;
        last_dom_o     <= dom_found ? dom_id : 8'd0;
        last_idx_o     <= sel_idx_i;
        last_act_o     <= {eff_safe, eff_qtn, eff_rst, (abort_d != '0), eff_rep};
      end
      if (clr_rep_i) begin
        worst_sev_o <= 2'd0;
        last_valid_o <= 1'b0;
      end else if (sel_valid_i && (sel_sev_i > worst_sev_o)) begin
        worst_sev_o <= sel_sev_i;
      end
    end
  end

  // per-port isolation hold timers (only meaningful when RST_HOLD != 0)
  for (genvar p = 0; p < NP; p++) begin : gen_hold
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni)          hold_cnt_q[p*16 +: 16] <= 16'd0;
      else if (!isol_q[p] || rst_d[p]) hold_cnt_q[p*16 +: 16] <= 16'd0;
      else if (hold_cnt_q[p*16 +: 16] != 16'hFFFF) hold_cnt_q[p*16 +: 16] <= hold_cnt_q[p*16 +: 16] + 16'd1;
    end
  end

endmodule

`default_nettype wire
