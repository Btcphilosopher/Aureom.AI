// =============================================================================
//  sf_citadel_ras.sv  --  Citadel reliability event collection + audit counters
// -----------------------------------------------------------------------------
//  Collects the supported hardware failure indications of NSRC = 16 sources
//  (SRAM ECC corrected / uncorrectable / fatal, memory-test failure, DMA fault,
//  packet protocol error, illegal access, invalid DMA, watchdog, compute error,
//  thermal warning / critical, authentication failure, boot failure, queue
//  fault, external fatal) and
//    * counts EVERY occurrence of EVERY source in a saturating counter, even
//      when several occur in one cycle or the fault manager is busy
//      (ev_extra_i carries additional same-cycle occurrences, e.g. several
//      check ports denying together);
//    * keeps one sticky PENDING record per source with its attribution
//      (domain, queue / engine index, address); a second occurrence while the
//      record is still pending is counted and flagged OVERRUN -- never lost
//      from the audit trail, only coalesced for containment;
//    * presents ONE pending record per cycle to the fault manager, MOST SEVERE
//      FIRST (fatal > uncorrectable > detected > corrected), then ROUND-ROBIN
//      among the pending sources of that severity: a fatal event is never
//      queued behind corrected errors, and no source -- in particular none
//      that a tenant can trigger at will -- can starve another of its own
//      severity;
//    * keeps the seven audit counters of the Citadel brief (access violations,
//      invalid DMA attempts, authentication failures, ECC corrections,
//      uncorrectable errors, queue faults, reset events) and four severity
//      counters.
//
//  Severity per source is the fixed policy table sf_citadel_pkg::SF_CIT_POLICY
//  (corrected / detected / uncorrectable / fatal).  Level-type inputs (memory
//  test status, thermal) are edge-detected: LEVEL_MASK marks them.
//
//  Counters are cleared only by clr_cnt_i (privileged, ROOT) or reset; they
//  saturate, they never wrap.  Reset clears every pending record.
// =============================================================================
`default_nettype none

module sf_citadel_ras #(
  parameter int unsigned AW     = 64,
  parameter int unsigned CNT_W  = 32,
  parameter logic [15:0] LEVEL_MASK = 16'h0C08,        // sources 3 (MBIST), 10, 11 (thermal) are levels
  parameter logic [127:0] POLICY = sf_citadel_pkg::SF_CIT_POLICY
) (
  input  wire logic                   clk_i,
  input  wire logic                   rst_ni,
  // ---- event inputs (one record per source) --------------------------------
  input  wire logic [15:0]            ev_i,
  input  wire logic [16*4-1:0]        ev_extra_i,       // additional same-cycle occurrences (0..15)
  input  wire logic [15:0]            ev_dom_vld_i,
  input  wire logic [16*8-1:0]        ev_dom_i,
  input  wire logic [16*8-1:0]        ev_idx_i,
  input  wire logic [3:0]             ev_addr_vld_i,    // only sources 0..3 carry an address
  input  wire logic [4*AW-1:0]        ev_addr_i,
  // ---- selected record -> fault manager --------------------------------------
  output logic                        sel_valid_o,
  output logic [3:0]                  sel_src_o,
  output logic [1:0]                  sel_sev_o,
  output logic                        sel_dom_vld_o,
  output logic [7:0]                  sel_dom_o,
  output logic [7:0]                  sel_idx_o,
  output logic                        sel_addr_vld_o,
  output logic [AW-1:0]               sel_addr_o,
  input  wire logic                   sel_ack_i,
  // ---- control / feedback -------------------------------------------------------
  input  wire logic                   clr_cnt_i,
  input  wire logic                   rst_evt_i,        // an engine reset / safe-state entry was issued
  // ---- telemetry ------------------------------------------------------------------
  output logic [15:0]                 pend_o,
  output logic [15:0]                 overrun_o,
  output logic [16*CNT_W-1:0]         src_cnt_o,
  output logic [4*CNT_W-1:0]          sev_cnt_o,
  output logic [CNT_W-1:0]            aud_viol_o,
  output logic [CNT_W-1:0]            aud_dma_o,
  output logic [CNT_W-1:0]            aud_auth_o,
  output logic [CNT_W-1:0]            aud_ce_o,
  output logic [CNT_W-1:0]            aud_uncorr_o,
  output logic [CNT_W-1:0]            aud_queue_o,
  output logic [CNT_W-1:0]            aud_reset_o
);

  if (CNT_W < 8 || CNT_W > 32) begin : gen_param_check
    $error("sf_citadel_ras: CNT_W must be 8..32");
  end

  // ---------------------------------------------------------------------------
  // edge detection and per-cycle occurrence counts
  // ---------------------------------------------------------------------------
  logic [15:0] lvl_q;
  logic [15:0] ev_edge;
  logic [16*5-1:0] inc_v;                // occurrences this cycle per source (0..16), source s at [5*s +: 5]
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) lvl_q <= '0;
    else         lvl_q <= ev_i;
  end
  always_comb begin
    for (int unsigned s = 0; s < 16; s++) begin
      ev_edge[s] = LEVEL_MASK[s] ? (ev_i[s] && !lvl_q[s]) : ev_i[s];
      inc_v[s*5 +: 5] = ev_edge[s] ? (5'd1 + {1'b0, ev_extra_i[s*4 +: 4]}) : 5'd0;
    end
  end

  // ---------------------------------------------------------------------------
  // pending records
  // ---------------------------------------------------------------------------
  logic [15:0]     pend_q, ovr_q;
  logic [15:0]     dvld_q;
  logic [16*8-1:0] dom_q, idx_q;
  logic [3:0]      avld_q;
  logic [4*AW-1:0] addr_q;

  // ---- selection: most severe first; WITHIN a severity round-robin (the scan starts after the source granted last) ----
  // A fixed lowest-number-first order would let a source that a tenant can trigger at will (access violations,
  // authentication failures) starve every higher-numbered source of the same severity -- and with it that source's
  // containment action.  The rotating start bounds the wait of any pending source to 15 grants of its own severity.
  logic        sel_found;
  logic [3:0]  sel_s;
  logic [3:0]  rr_q;                                    // source granted last (reset: 15, so the first scan starts at 0)
  logic [3:0]  cand;
  always_comb begin
    sel_found = 1'b0;
    sel_s     = 4'd0;
    cand      = 4'd0;
    for (int sev = 3; sev >= 0; sev--) begin
      for (int k = 1; k <= 16; k++) begin
        cand = rr_q + 4'(k);                             // k = 16 wraps to rr_q itself (scanned last)
        if (!sel_found && pend_q[cand] && (POLICY[cand*8 + 5 +: 2] == 2'(sev))) begin
          sel_found = 1'b1;
          sel_s     = cand;
        end
      end
    end
  end
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni)                       rr_q <= 4'd15;
    else if (sel_ack_i && sel_found)   rr_q <= sel_s;
  end

  assign sel_valid_o    = sel_found;
  assign sel_src_o      = sel_s;
  assign sel_sev_o      = POLICY[sel_s*8 + 5 +: 2];
  assign sel_dom_vld_o  = sel_found && dvld_q[sel_s];
  assign sel_dom_o      = dom_q[sel_s*8 +: 8];
  assign sel_idx_o      = idx_q[sel_s*8 +: 8];
  assign sel_addr_vld_o = sel_found && (sel_s < 4'd4) && avld_q[sel_s[1:0]];
  assign sel_addr_o     = addr_q[sel_s[1:0]*AW +: AW];

  logic [15:0] ack_vec;
  always_comb begin
    ack_vec = '0;
    for (int unsigned s = 0; s < 16; s++) ack_vec[s] = sel_ack_i && sel_found && (sel_s == 4'(s));
  end

  for (genvar g = 0; g < 16; g++) begin : gen_src
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        pend_q[g] <= 1'b0;
        ovr_q[g]  <= 1'b0;
        dvld_q[g] <= 1'b0;
        dom_q[g*8 +: 8] <= 8'd0;
        idx_q[g*8 +: 8] <= 8'd0;
      end else begin
        if (clr_cnt_i) ovr_q[g] <= 1'b0;
        if (ack_vec[g]) pend_q[g] <= 1'b0;                       // consumed (a new occurrence below re-arms it)
        if (ev_edge[g]) begin
          if (pend_q[g] && !ack_vec[g]) begin
            ovr_q[g] <= 1'b1;                                    // coalesced: counted, first attribution kept
          end else begin
            pend_q[g]       <= 1'b1;
            dvld_q[g]       <= ev_dom_vld_i[g];
            dom_q[g*8 +: 8] <= ev_dom_i[g*8 +: 8];
            idx_q[g*8 +: 8] <= ev_idx_i[g*8 +: 8];
          end
        end
      end
    end
  end
  for (genvar g = 0; g < 4; g++) begin : gen_addr
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        avld_q[g]          <= 1'b0;
        addr_q[g*AW +: AW] <= '0;
      end else if (ev_edge[g] && !(pend_q[g] && !ack_vec[g])) begin
        avld_q[g]          <= ev_addr_vld_i[g];
        addr_q[g*AW +: AW] <= ev_addr_i[g*AW +: AW];
      end
    end
  end

  assign pend_o    = pend_q;
  assign overrun_o = ovr_q;

  // ---------------------------------------------------------------------------
  // saturating counters
  // ---------------------------------------------------------------------------
  function automatic logic [CNT_W-1:0] sat_add(input logic [CNT_W-1:0] a, input logic [8:0] n);
    logic [CNT_W:0] sum;
    begin
      sum = {1'b0, a} + {{(CNT_W+1-9){1'b0}}, n};
      sat_add = sum[CNT_W] ? {CNT_W{1'b1}} : sum[CNT_W-1:0];
    end
  endfunction

  logic [4*9-1:0] sev_inc_v;
  logic [8:0] a_viol, a_dma, a_auth, a_ce, a_unc, a_queue;
  always_comb begin
    sev_inc_v = '0;
    for (int unsigned s = 0; s < 16; s++) begin
      for (int k = 0; k < 4; k++) begin
        if (POLICY[s*8 + 5 +: 2] == 2'(k)) sev_inc_v[k*9 +: 9] = sev_inc_v[k*9 +: 9] + {4'd0, inc_v[s*5 +: 5]};
      end
    end
    a_viol  = {4'd0, inc_v[sf_citadel_pkg::SF_CIT_SRC_ILLEGAL*5 +: 5]} + {4'd0, inc_v[sf_citadel_pkg::SF_CIT_SRC_INVALID_DMA*5 +: 5]};
    a_dma   = {4'd0, inc_v[sf_citadel_pkg::SF_CIT_SRC_INVALID_DMA*5 +: 5]};
    a_auth  = {4'd0, inc_v[sf_citadel_pkg::SF_CIT_SRC_AUTH_FAIL*5 +: 5]} + {4'd0, inc_v[sf_citadel_pkg::SF_CIT_SRC_BOOT_FAIL*5 +: 5]};
    a_ce    = {4'd0, inc_v[sf_citadel_pkg::SF_CIT_SRC_ECC_CE*5 +: 5]};
    a_unc   = sev_inc_v[2*9 +: 9];
    a_queue = {4'd0, inc_v[sf_citadel_pkg::SF_CIT_SRC_DMA_FAULT*5 +: 5]} + {4'd0, inc_v[sf_citadel_pkg::SF_CIT_SRC_PKT_PROTO*5 +: 5]} +
              {4'd0, inc_v[sf_citadel_pkg::SF_CIT_SRC_QUEUE_FAULT*5 +: 5]};
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      src_cnt_o    <= '0;
      sev_cnt_o    <= '0;
      aud_viol_o   <= '0;
      aud_dma_o    <= '0;
      aud_auth_o   <= '0;
      aud_ce_o     <= '0;
      aud_uncorr_o <= '0;
      aud_queue_o  <= '0;
      aud_reset_o  <= '0;
    end else if (clr_cnt_i) begin
      src_cnt_o    <= '0;
      sev_cnt_o    <= '0;
      aud_viol_o   <= '0;
      aud_dma_o    <= '0;
      aud_auth_o   <= '0;
      aud_ce_o     <= '0;
      aud_uncorr_o <= '0;
      aud_queue_o  <= '0;
      aud_reset_o  <= '0;
    end else begin
      for (int unsigned s = 0; s < 16; s++) src_cnt_o[s*CNT_W +: CNT_W] <= sat_add(src_cnt_o[s*CNT_W +: CNT_W], {4'd0, inc_v[s*5 +: 5]});
      for (int k = 0; k < 4; k++)           sev_cnt_o[k*CNT_W +: CNT_W] <= sat_add(sev_cnt_o[k*CNT_W +: CNT_W], sev_inc_v[k*9 +: 9]);
      aud_viol_o   <= sat_add(aud_viol_o,   a_viol);
      aud_dma_o    <= sat_add(aud_dma_o,    a_dma);
      aud_auth_o   <= sat_add(aud_auth_o,   a_auth);
      aud_ce_o     <= sat_add(aud_ce_o,     a_ce);
      aud_uncorr_o <= sat_add(aud_uncorr_o, a_unc);
      aud_queue_o  <= sat_add(aud_queue_o,  a_queue);
      aud_reset_o  <= sat_add(aud_reset_o,  rst_evt_i ? 9'd1 : 9'd0);
    end
  end

endmodule

`default_nettype wire
