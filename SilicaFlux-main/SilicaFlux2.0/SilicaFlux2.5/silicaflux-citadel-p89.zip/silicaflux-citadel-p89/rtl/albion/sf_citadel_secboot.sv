// =============================================================================
//  sf_citadel_secboot.sv  --  Citadel authenticated-firmware gate
// -----------------------------------------------------------------------------
//  THIS MODULE DOES NOT VERIFY SIGNATURES AND IS NOT A ROOT OF TRUST.
//
//  It is the Citadel-side INTERFACE and FAIL-CLOSED POLICY around an external
//  authenticated-boot block.  A functional secure boot needs all of:
//     (1) a trusted, immutable boot ROM,
//     (2) an authorised public key held where software cannot alter it,
//     (3) a signature verification engine (vetted IP -- the repository's
//         Project 28 SecureSilicon provides Ed25519 + SHA-256 in hardware),
//     (4) controlled firmware loading (the verified image is the image that runs),
//     (5) explicit failure behaviour.
//  Citadel owns only (5) and the use of the verdict.  Items (1)-(4) live in the
//  external block, whose verdict arrives on boot_done_i / boot_ok_i / boot_err_i.
//  rot_present_i is a PLATFORM TIE-OFF that is 1 only when such a block is really
//  integrated; it is never a software-writable register, so ordinary registers
//  cannot make the device claim a secure root of trust.
//
//  Repository finding (docs/citadel/00_AUDIT.md): the P28 key / lifecycle / anti-
//  rollback state is a fuse MODEL (lost at power-off).  Until a real OTP/eFuse
//  macro backs it, a "secure boot" built on it provides authentication of the
//  image at boot but NOT rollback resistance or tamper-proof key storage; this
//  gate cannot change that.
//
//  States
//    ABSENT    rot_present_i = 0: no authenticated boot exists.  Privileged
//              configuration is opened only if ALLOW_UNAUTH = 1 (development
//              bring-up); the telemetry then reports "secure boot ABSENT".
//    WAIT      reset released, verdict pending.  Configuration CLOSED.  ABSENT is entered ONLY from reset (rot_present_i
//              never seen high): once a root of trust has been seen, losing rot_present_i is a FAILURE, never a downgrade.
//    AUTH_OK   verified: boot_done_i && boot_ok_i && boot_err_i == 0.  Opens the
//              privileged configuration and the firmware-run permission.
//    FAILED    explicit failure behaviour, STICKY UNTIL RESET: configuration and
//              firmware-run stay closed, one boot_fail_o pulse feeds the RAS
//              (source BOOT_FAIL: FATAL -> safe state + authentication-failure
//              counter).  Entered on: done without ok, ok with a non-zero error
//              code (contradiction fails closed), verdict timeout, loss of
//              boot_ok_i / rot_present_i after AUTH_OK, loss of rot_present_i
//              while waiting (after it had been seen).
//  A boot_ok_i without boot_done_i never opens anything.
//  Reset: asynchronous, returns to ABSENT / WAIT with everything closed.
// =============================================================================
`default_nettype none

module sf_citadel_secboot #(
  parameter bit          ALLOW_UNAUTH = 1'b0,         // 1: open configuration when NO root of trust is integrated (bring-up ONLY; default is fail closed)
  parameter int unsigned BOOT_TIMEOUT = 0             // cycles to wait for the verdict; 0 = wait forever (configuration stays closed)
) (
  input  wire logic        clk_i,
  input  wire logic        rst_ni,
  // ---- verdict from the external authenticated-boot block ---------------------
  input  wire logic        rot_present_i,             // platform tie-off: an authenticated-boot block is integrated
  input  wire logic        boot_done_i,               // verification finished
  input  wire logic        boot_ok_i,                 // firmware authentic (signature + measurement + anti-rollback)
  input  wire logic [7:0]  boot_err_i,                // verifier error code (0 = none)
  // ---- results ---------------------------------------------------------------------
  output logic [2:0]       state_o,                   // 0 ABSENT, 1 WAIT, 2 AUTH_OK, 3 FAILED
  output logic             cfg_open_o,                // privileged configuration may be accepted
  output logic             fw_run_ok_o,               // authenticated firmware may execute
  output logic             boot_fail_o,               // one-cycle pulse on entering FAILED
  output logic [7:0]       err_o,                     // latched verifier error code (0 if none / timeout code)
  output logic             rot_active_o               // "authenticated boot is in force": rot present AND AUTH_OK
);

  localparam logic [2:0] S_ABSENT = 3'd0, S_WAIT = 3'd1, S_AUTH = 3'd2, S_FAILED = 3'd3;
  localparam logic [7:0] ERR_TIMEOUT = 8'hF1, ERR_CONTRADICTION = 8'hF2, ERR_LOST = 8'hF3, ERR_NOT_OK = 8'hF4;

  logic [2:0]  st_q;
  logic [7:0]  err_q;
  logic [31:0] tmo_q;
  logic        fail_q;
  logic        rot_seen_q;                                          // rot_present_i has been high at some time since reset

  assign state_o     = st_q;
  assign err_o       = err_q;
  assign cfg_open_o  = (st_q == S_AUTH) || ((st_q == S_ABSENT) && ALLOW_UNAUTH);
  assign fw_run_ok_o = (st_q == S_AUTH) || ((st_q == S_ABSENT) && ALLOW_UNAUTH);
  assign rot_active_o = (st_q == S_AUTH);
  assign boot_fail_o = fail_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q   <= S_WAIT;
      err_q  <= 8'd0;
      tmo_q  <= 32'd0;
      fail_q <= 1'b0;
      rot_seen_q <= 1'b0;
    end else begin
      fail_q <= 1'b0;
      if (rot_present_i) rot_seen_q <= 1'b1;
      case (st_q)
        S_ABSENT: begin
          if (rot_present_i) st_q <= S_WAIT;                       // a block appeared: demand its verdict
        end
        S_WAIT: begin
          tmo_q <= tmo_q + 32'd1;
          if (!rot_present_i && rot_seen_q) begin
            st_q   <= S_FAILED;                                   // the block was integrated and has gone: fail closed
            err_q  <= ERR_LOST;
            fail_q <= 1'b1;
          end else if (!rot_present_i) begin
            st_q <= S_ABSENT;                                     // never integrated: only reachable straight from reset
            tmo_q <= 32'd0;
          end else if (boot_done_i) begin
            if (boot_ok_i && (boot_err_i == 8'd0)) begin
              st_q <= S_AUTH;
            end else begin
              st_q   <= S_FAILED;
              err_q  <= (boot_err_i != 8'd0) ? boot_err_i : (boot_ok_i ? ERR_CONTRADICTION : ERR_NOT_OK);
              fail_q <= 1'b1;
            end
          end else if ((BOOT_TIMEOUT != 0) && (tmo_q >= 32'(BOOT_TIMEOUT))) begin
            st_q   <= S_FAILED;
            err_q  <= ERR_TIMEOUT;
            fail_q <= 1'b1;
          end
        end
        S_AUTH: begin
          if (!boot_ok_i || !rot_present_i) begin                  // the attestation was withdrawn: fail closed
            st_q   <= S_FAILED;
            err_q  <= ERR_LOST;
            fail_q <= 1'b1;
          end
        end
        default: begin
          st_q <= S_FAILED;                                       // FAILED (and any unreachable encoding): sticky until reset
        end
      endcase
    end
  end

endmodule

`default_nettype wire
