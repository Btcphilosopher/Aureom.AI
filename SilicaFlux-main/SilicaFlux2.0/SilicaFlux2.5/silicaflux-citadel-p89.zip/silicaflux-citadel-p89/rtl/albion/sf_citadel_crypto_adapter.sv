// =============================================================================
//  sf_citadel_crypto_adapter.sv  --  protected interface to a replaceable
//                                    "CloudCrypto" engine (AES-GCM / SHA / ...)
// -----------------------------------------------------------------------------
//  THIS MODULE CONTAINS NO CRYPTOGRAPHY AND STORES NO KEY MATERIAL.
//
//  It sits between requesters and an external, VALIDATED crypto engine and
//  enforces, in hardware, who may use which key slot:
//
//    * the requester names a domain; the adapter verifies it exactly like the
//      permission checker does -- the domain must exist, be ACTIVE and be BOUND
//      to this adapter's physical port (SRC); safe state and DFT access deny;
//    * an algorithm is accepted only if the engine ADVERTISES it (cap_algo_i):
//      nothing is emulated, an unsupported algorithm is answered explicitly;
//    * a keyed algorithm needs the domain's permission for that key slot
//      (kmask of the domain table) and the slot must not be BLOCKED;
//    * the engine is told only {algorithm, KEY SLOT, domain, opaque context};
//      key material never passes through Citadel.
//
//  ZEROISATION reflects what the hardware can really do.  A zeroise request
//  (revoke / quarantine / safe state, from the domain table and fault manager)
//  becomes a one-cycle key_zero_o pulse per slot to the engine and BLOCKS the slot
//  until the engine confirms the wipe (key_zero_ack_i) or reports that a fresh key
//  was provisioned (key_provision_i).  An engine without the capability
//  (cap_zeroize_i = 0) can never confirm: the slot stays blocked (fail closed) and
//  zero_unsupported_o is raised -- the adapter never claims a wipe that did not
//  happen.  A zeroise of the key used by an operation IN FLIGHT turns that
//  operation's response into KEY_WIPED: no success is reported for a wiped key.
//
//  One request at a time.  Every request gets exactly one explicit response.
//  Reset abandons the in-flight request and clears the block flags (the platform
//  reset must also reset / zeroise the engine -- integration rule).
//
//  The data path (buffers) is NOT handled here: the engine fetches / stores
//  its data through its own master port, which is checked by a Citadel check
//  point like any other master.
// =============================================================================
`default_nettype none

module sf_citadel_crypto_adapter #(
  parameter int unsigned NDOM  = 8,
  parameter int unsigned NP    = 4,
  parameter int unsigned NKEY  = 8,
  parameter int unsigned CTX_W = 16,
  parameter int unsigned SRC   = 0,                       // physical port this request port is anchored to
  localparam int unsigned SLOT_W = (NDOM > 1) ? $clog2(NDOM) : 1
) (
  input  wire logic                  clk_i,
  input  wire logic                  rst_ni,
  // ---- requester ------------------------------------------------------------------
  input  wire logic                  req_valid_i,
  output logic                       req_ready_o,
  input  wire logic [7:0]            req_dom_i,
  input  wire logic [3:0]            req_algo_i,
  input  wire logic [7:0]            req_key_i,
  input  wire logic [CTX_W-1:0]      req_ctx_i,
  output logic                       rsp_valid_o,
  input  wire logic                  rsp_ready_i,
  output logic [3:0]                 rsp_status_o,
  output logic [CTX_W-1:0]           rsp_ctx_o,
  // ---- domain state (from sf_citadel_domain_table) ------------------------------------
  input  wire logic [NDOM*2-1:0]     slot_state_i,
  input  wire logic [NDOM*8-1:0]     slot_id_i,
  input  wire logic [NP*NDOM-1:0]    bind_i,
  input  wire logic [NDOM*NKEY-1:0]  kmask_i,
  input  wire logic                  lockdown_i,
  input  wire logic                  dft_active_i,
  // ---- zeroise requests ------------------------------------------------------------------
  input  wire logic                  zero_valid_i,
  input  wire logic [NKEY-1:0]       zero_mask_i,
  input  wire logic                  zero_all_i,
  // ---- the validated engine (replaceable) ----------------------------------------------------
  output logic                       eng_valid_o,
  input  wire logic                  eng_ready_i,
  output logic [3:0]                 eng_algo_o,
  output logic [7:0]                 eng_key_o,              // key SLOT index -- never key material
  output logic [7:0]                 eng_dom_o,
  output logic [CTX_W-1:0]           eng_ctx_o,
  input  wire logic                  eng_done_i,
  input  wire logic [1:0]            eng_status_i,           // 0 ok, 1 engine error, 2 authentication (tag / MAC) failure
  input  wire logic [15:0]           cap_algo_i,             // bit n = algorithm n implemented (static tie-off from the engine)
  input  wire logic                  cap_zeroize_i,          // the engine can wipe a key slot (static tie-off)
  output logic [NKEY-1:0]            key_zero_o,             // one-cycle wipe request per slot
  input  wire logic [NKEY-1:0]       key_zero_ack_i,         // the engine confirms the wipe
  input  wire logic [NKEY-1:0]       key_provision_i,        // a fresh key was loaded into the slot
  // ---- reporting ----------------------------------------------------------------------------------
  output logic                       auth_fail_o,            // pulse: authentication failure (RAS source AUTH_FAIL)
  output logic [7:0]                 auth_fail_dom_o,
  output logic [NKEY-1:0]            key_block_o,            // slots blocked until a zeroise is confirmed
  output logic                       zero_unsupported_o      // sticky: a wipe was requested but the engine cannot wipe
);

  if (NDOM < 1 || NDOM > 32 || NP < 1 || NKEY < 1 || NKEY > 32 || SRC >= NP || CTX_W < 1) begin : gen_param_check
    $error("sf_citadel_crypto_adapter: parameter out of range");
  end

  // ---------------------------------------------------------------------------
  // domain verification (same rules as sf_citadel_permission)
  // ---------------------------------------------------------------------------
  logic              dom_found, dom_bound;
  logic [SLOT_W-1:0] dom_slot;
  logic [1:0]        dom_state;
  always_comb begin
    dom_found = 1'b0;
    dom_bound = 1'b0;
    dom_slot  = '0;
    dom_state = sf_citadel_pkg::SF_CIT_DS_INVALID;
    for (int unsigned s = 0; s < NDOM; s++) begin
      if (!dom_found && (slot_state_i[s*2 +: 2] != sf_citadel_pkg::SF_CIT_DS_INVALID) && (slot_id_i[s*8 +: 8] == req_dom_i)) begin
        dom_found = 1'b1;
        dom_slot  = SLOT_W'(s);
        dom_state = slot_state_i[s*2 +: 2];
        dom_bound = bind_i[SRC*NDOM + s];
      end
    end
  end
  wire dom_ok = dom_found && dom_bound && (req_dom_i != sf_albion_pkg::SF_DOM_INVALID) &&
                (dom_state == sf_citadel_pkg::SF_CIT_DS_ACTIVE) && !dft_active_i &&
                !(lockdown_i && (req_dom_i != sf_albion_pkg::SF_DOM_ROOT) && (req_dom_i != sf_albion_pkg::SF_DOM_MGMT));

  // ---------------------------------------------------------------------------
  // algorithm and key checks
  // ---------------------------------------------------------------------------
  // a wipe requested THIS cycle already counts: a request accepted in the same cycle must not be sent to a slot being wiped
  wire [NKEY-1:0] zero_now = (zero_valid_i ? zero_mask_i : {NKEY{1'b0}}) | (zero_all_i ? {NKEY{1'b1}} : {NKEY{1'b0}});
  wire        algo_valid = (req_algo_i != sf_citadel_pkg::SF_CIT_ALGO_NONE) && (req_algo_i <= sf_citadel_pkg::SF_CIT_ALGO_MAX);
  wire        supported  = cap_algo_i[req_algo_i];
  wire        need_key   = (req_algo_i >= sf_citadel_pkg::SF_CIT_ALGO_AESGCM_ENC);
  wire [31:0] key_ext    = {24'd0, req_key_i};
  logic       key_perm, key_blk;
  logic [NKEY-1:0] zblk_q;
  always_comb begin
    key_perm = 1'b0;
    key_blk  = 1'b0;
    for (int unsigned k = 0; k < NKEY; k++) begin
      if (key_ext == k) begin
        key_blk = zblk_q[k] || zero_now[k];
        for (int unsigned s = 0; s < NDOM; s++) begin
          if (dom_slot == SLOT_W'(s)) key_perm = kmask_i[s*NKEY + k];
        end
      end
    end
  end

  logic [3:0] verdict;
  always_comb begin
    verdict = sf_citadel_pkg::SF_CIT_CE_OK;
    if (!algo_valid)                       verdict = sf_citadel_pkg::SF_CIT_CE_BAD_ALGO;
    else if (!dom_ok)                      verdict = sf_citadel_pkg::SF_CIT_CE_DENIED_DOMAIN;
    else if (!supported)                   verdict = sf_citadel_pkg::SF_CIT_CE_UNSUPPORTED;
    else if (need_key && (key_ext >= NKEY || !key_perm)) verdict = sf_citadel_pkg::SF_CIT_CE_DENIED_KEY;
    else if (need_key && key_blk)          verdict = sf_citadel_pkg::SF_CIT_CE_KEY_BLOCKED;
  end

  // ---------------------------------------------------------------------------
  // request FSM
  // ---------------------------------------------------------------------------
  localparam logic [1:0] S_IDLE = 2'd0, S_FWD = 2'd1, S_WAIT = 2'd2, S_RSP = 2'd3;
  logic [1:0]        st_q;
  logic [3:0]        algo_q, status_q;
  logic [7:0]        key_q, dom_q;
  logic [CTX_W-1:0]  ctx_q;
  logic              void_q;

  logic cur_key_zeroed;
  wire [31:0] keyq_ext = {24'd0, key_q};
  always_comb begin
    cur_key_zeroed = 1'b0;
    for (int unsigned k = 0; k < NKEY; k++) if (zero_now[k] && (keyq_ext == k)) cur_key_zeroed = 1'b1;
  end
  wire cur_needs_key = (algo_q >= sf_citadel_pkg::SF_CIT_ALGO_AESGCM_ENC);

  assign req_ready_o  = (st_q == S_IDLE);
  assign rsp_valid_o  = (st_q == S_RSP);
  assign rsp_status_o = status_q;
  assign rsp_ctx_o    = ctx_q;
  assign eng_valid_o  = (st_q == S_FWD);
  assign eng_algo_o   = algo_q;
  assign eng_key_o    = key_q;
  assign eng_dom_o    = dom_q;
  assign eng_ctx_o    = ctx_q;
  assign key_block_o  = zblk_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q <= S_IDLE; algo_q <= 4'd0; key_q <= 8'd0; dom_q <= 8'd0; ctx_q <= '0; status_q <= 4'd0; void_q <= 1'b0;
      auth_fail_o <= 1'b0; auth_fail_dom_o <= 8'd0;
    end else begin
      auth_fail_o <= 1'b0;
      case (st_q)
        S_IDLE: begin
          if (req_valid_i) begin
            algo_q <= req_algo_i; key_q <= req_key_i; dom_q <= req_dom_i; ctx_q <= req_ctx_i; void_q <= 1'b0;
            if (verdict == sf_citadel_pkg::SF_CIT_CE_OK) begin
              st_q <= S_FWD;
            end else begin
              status_q <= verdict;
              st_q     <= S_RSP;          // refused: the engine is never touched
            end
          end
        end
        S_FWD: begin
          if (cur_needs_key && cur_key_zeroed) void_q <= 1'b1;
          if (eng_ready_i) st_q <= S_WAIT;
        end
        S_WAIT: begin
          if (cur_needs_key && cur_key_zeroed) void_q <= 1'b1;
          if (eng_done_i) begin
            st_q <= S_RSP;
            if ((void_q || (cur_needs_key && cur_key_zeroed)) && cur_needs_key) begin
              status_q <= sf_citadel_pkg::SF_CIT_CE_KEY_WIPED;
            end else if (eng_status_i == 2'd0) begin
              status_q <= sf_citadel_pkg::SF_CIT_CE_OK;
            end else if (eng_status_i == 2'd2) begin
              status_q        <= sf_citadel_pkg::SF_CIT_CE_AUTH_FAIL;
              auth_fail_o     <= 1'b1;
              auth_fail_dom_o <= dom_q;
            end else begin
              status_q <= sf_citadel_pkg::SF_CIT_CE_ENGINE_ERR;
            end
          end
        end
        default: begin
          if (rsp_ready_i) st_q <= S_IDLE;
        end
      endcase
    end
  end

  // ---------------------------------------------------------------------------
  // zeroisation: pulse to the engine, block the slot until the wipe is CONFIRMED
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      key_zero_o <= '0;
      zblk_q     <= '0;
      zero_unsupported_o <= 1'b0;
    end else begin
      key_zero_o <= zero_now;
      // set wins over a simultaneous confirmation
      zblk_q <= (zblk_q & ~(key_zero_ack_i | key_provision_i)) | zero_now;
      if ((zero_now != '0) && !cap_zeroize_i) zero_unsupported_o <= 1'b1;
    end
  end

endmodule

`default_nettype wire
