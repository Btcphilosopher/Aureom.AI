# 06 — Secure-boot interface and CloudCrypto adapter

> **Read this first.**  Citadel contains **no cryptography**, **verifies no signature**, stores **no key material**, and makes **no
> claim of a secure root of trust**.  It owns the *policy and interface* around externally supplied, vetted blocks, and it reports what
> is physically true.  Both modules were built **after** the isolation proofs, as the brief requires.

## 1. Secure boot (`sf_citadel_secboot`)

A functional secure boot needs five things; only the last belongs to Citadel:

| Requirement | Provided by | In this repository |
|---|---|---|
| Trusted boot ROM | external | P28 `sb_bootrom` (mask-ROM image) — REAL in simulation |
| Authorised public key | external, must live where software cannot alter it | P28: test / dev keys derived from public labels; **real key storage = ABSENT** |
| Signature verification | external vetted IP | P28: Ed25519 (Monocypher 4.0.2) + SHA-256 (secworks) — REAL, validated in P28 |
| Controlled firmware loading (verified image = running image) | external | P28: IMEM sealed, SHA-256 of the sealed copy, execute window = measured range |
| **Explicit failure behaviour** | **Citadel** | `sf_citadel_secboot` + fault manager |

Interface (all from the external block; `rot_present_i` is a **platform tie-off**, not a register):

```
rot_present_i   an authenticated-boot block is really integrated        boot_done_i   verification finished
boot_ok_i       firmware authentic (signature + measurement + policy)   boot_err_i[7:0]  verifier error code
```

### States and behaviour (proved: `fv_cit_secboot`, 7 properties, unbounded)

| State | Entered | Privileged configuration | Firmware run |
|---|---|---|---|
| `ABSENT` (0) | `rot_present_i = 0` **since reset** (reachable only from reset) | open **only if** `ALLOW_UNAUTH = 1` (bring-up; **default 0**) — reported as ABSENT, never as authenticated | same |
| `WAIT` (1) | reset released | **closed** | no |
| `AUTH_OK` (2) | `boot_done ∧ boot_ok ∧ err = 0 ∧ rot_present` from WAIT | open | yes |
| `FAILED` (3) | done without ok · ok with an error code (contradiction fails closed) · verdict timeout (`BOOT_TIMEOUT`) · ok / rot withdrawn after AUTH_OK · **rot withdrawn while waiting after it had been seen** | **closed, sticky until reset** | no |

* `boot_ok` without `boot_done` never opens anything; a later "good" verdict never reopens a FAILED device.
* A root of trust that was seen can never be downgraded to ABSENT (review finding: `rot_present_i` dropping during `WAIT` used to fall
  back to ABSENT and, with `ALLOW_UNAUTH = 1`, open the configuration; proved `sb8_*`, mutants `B12`, `B14`; the default of
  `ALLOW_UNAUTH` was also flipped to the fail-closed 0, mutant `B13`).
* Failure raises one `boot_fail_o` pulse → RAS source `BOOT_FAIL` (**fatal**): safe state, key zeroise request, authentication-failure counter,
  the failure code on `boot_err_o` for the platform (privileged telemetry is closed after a failed boot, so software cannot read it).
* `fw_run_ok_o` is the permission for the ControlCore to execute; `cfg_open_o` gates the **command port and privileged telemetry**
  (`cfg_en = cfg_en_i ∧ cfg_open`).
* Reset returns to `WAIT` with everything closed.  Recovery is by reset only.

### What this proves and what it does not

Proved: the **policy** around the verdict is fail-closed.  **Not** proved, **not** provided: that the verdict is truthful (the verifier's
job), rollback resistance, tamper-proof keys, a secure lifecycle.  Repository finding: P28's fuses are a MODEL lost at power-off, so a
secure boot built on it authenticates the image at boot but gives **no genuine anti-rollback or revocation** until a real OTP / eFuse
macro backs it.

### Connecting P28 (not built here)

`boot_done_i`, `boot_ok_i`, `boot_err_i` ← the authentication result / error code of `silicaflux_secure_boot`; `rot_present_i` ← `1'b1`
only in builds that instantiate it; `fw_run_ok_o` → the ControlCore run / reset-release gate.  The ControlCore documents that it has no
firmware authentication of its own (`SECURITY.AUTH_HOOK` is reserved for P28).  This wiring was **not** exercised against the P28 RTL.

## 2. CloudCrypto adapter (`sf_citadel_crypto_adapter`)

```
requester ──{dom, algo, key slot, ctx}──► [ verify domain · algorithm · key permission · slot block ] ──► engine {algo, key SLOT, dom, ctx}
                                                  ▲ table: state, ids, bindings, kmask      ◄── done / status (ok · error · auth-fail)
zeroise requests (revoke / quarantine / safe state) ──► key_zero_o pulses ──► engine ──► key_zero_ack / key_provision ──► unblock
```

* **Domain** must exist, be ACTIVE and **bound to the adapter's physical port**; safe state and DFT access deny (as the checker does).
* **Algorithm**: `SHA256` (1), `AESGCM_ENC` (2), `AESGCM_DEC` (3, verifies the tag), `AESXTS_ENC/DEC` (4, 5), `CMAC` (6).  An algorithm is usable
  **only if the engine advertises it** (`cap_algo_i`).  Nothing is emulated.  The domain check comes first, so an unauthorised requester
  learns nothing about capabilities (test `T4`).
* **Key**: a keyed algorithm needs the domain's `kmask` permission for that **slot** and the slot not blocked; the engine is given only the
  slot number.  A hash needs no key (the requester-supplied slot number is still forwarded in the command for a keyless hash — a slot number,
  not key material, ignored by the hash engine; noted by the review, not changed).
* **Statuses**: `OK · BAD_ALGO · UNSUPPORTED · DENIED_DOMAIN · DENIED_KEY · ENGINE_ERR · AUTH_FAIL · KEY_WIPED · KEY_BLOCKED`; one request at a
  time, exactly one response each; authentication failures raise `auth_fail_o` (+ domain) for the RAS.

### Zeroisation reflects what the hardware can do

| Situation | Behaviour |
|---|---|
| Domain revoked / quarantined, safe state | `key_zero_o[k]` pulse for exactly those slots; slot **blocked** |
| Engine confirms the wipe (`key_zero_ack_i`) or reports a fresh key (`key_provision_i`) | slot unblocked |
| Engine **cannot** wipe (`cap_zeroize_i = 0`) | slot **stays blocked** (fail closed); `zero_unsupported_o` raised — the adapter never claims a wipe that did not happen |
| Wipe requested while the request is in flight | the response becomes `KEY_WIPED`; no success is reported for a wiped key |
| Wipe requested in the same cycle a request is accepted | counted as blocked (no request is sent to a slot being wiped) |
| Reset | request abandoned, block flags cleared — **integration rule**: the platform reset must also reset / zeroise the engine |

Real engines in the repository: **SHA-256** (secworks, validated in P28) — used by the adapter test; **AES-XTS / CMAC** (P59, NIST-validated)
— interface-compatible, not integrated here; **AES-GCM** — **does not exist** in the repository, so the adapter reports it `UNSUPPORTED`.
The keyed-algorithm tests run on a clearly labelled **bench engine model** that records the command it saw and answers on demand; it is not
cryptography.  The data path (buffers) is **not** handled by the adapter: the engine fetches and stores its data through its own master
port, which needs its own Citadel check point.

### Proved (`fv_cit_crypto`, unbounded; table state, levels, zeroise requests, engine capability and answers are free)

A command reaches the engine only if it was permitted when accepted (valid algorithm, domain verified / ACTIVE / bound, no safe state / DFT,
algorithm supported, key slot in range, permitted and not blocked or being wiped); the command carries exactly the accepted fields; a refused
request never touches the engine and gets an explicit non-OK status; OK only for a permitted request whose key was not wiped before
completion; one response per request; every zeroise request becomes a pulse on exactly those slots; the block flags equal an independent
model (set by a zeroise, cleared only by the engine's confirmation, set wins); reset clears them.
