# 00 — Repository audit (what exists, what was reused, what was found)

Scope requested by the brief: SecureSilicon, RAS, ECCMemory, TestCore, ControlCore, DataFabric, CloudDMA, firmware boot, key
storage, reset logic.  Everything below was read from the archives in
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/` and `SilicaFlux-main/` of the repository (each project is a zip there; the Albion
base is `albioncore-0.1.0.zip`).  File names are given so each statement can be checked.

> Convention used here: **REAL** = behaviour implemented in RTL and verified in that project's own reports; **MODEL** = a
> software-visible stand-in that does not have the hardware property its name suggests; **ABSENT** = not in the repository.

## 1. Inventory and verdict

| Block (archive) | What it provides | Status | Used by Citadel |
|---|---|---|---|
| **AlbionCore 0.1.0** (`albioncore-0.1.0.zip`) | ALP link protocol: 236-bit request / 148-bit response, domain id (8 bit), attribute byte, status codes, `sf_albion_pkg` request-legality and region-attribute functions, generated memory map, reset synchroniser, formal flow (Yosys + ABC `pdr`), style rules | REAL (Verilator 5.020 + Yosys 0.33) | **Reused verbatim** (vendored unmodified in `third_party/albion/`, SHA-256 in `SHA256SUMS`): code points, domain ranges, attribute bits, device map, house style, formal method |
| **Meridian P83** (`silicaflux-meridian-p83.zip`) | Cloud interconnect with a per-master-port check interface | REAL fabric; its Citadel is `sf_meridian_citadel_ref.sv` = **MODEL** ("REFERENCE model … NOT the Citadel") | Interface semantics adopted (§3 of `04_ENFORCEMENT.md`); the reference model is *replaced*, not reused |
| **CloudDMA P64** (`silicaflux-clouddma-p64.zip`) | Descriptor DMA with `sfdma_perm_checker` in front of every transaction | REAL; documents "a domain number is a label software can lie about" | Lessons reused: check before the transaction, range arithmetic wider than the address, translation result not trusted |
| **SecureSilicon P28** (`SilicaFlux-main/silicaflux-secureboot-p28.zip`) | Immutable boot ROM, firmware manifest, **Ed25519** (Monocypher 4.0.2) + **SHA-256** (secworks) verification, `sb_dma_guard`, `sb_access_policy` | Boot flow + DMA guard REAL in simulation; **OTP / lifecycle / anti-rollback = MODEL** (`sb_otp_model.sv`: "THIS IS NOT OTP / eFUSE HARDWARE … lost at power-off") | Verifier is the intended external block behind `sf_citadel_secboot`; `sb_dma_guard` informed the 33-bit/65-bit overflow handling |
| **SecureStore P59** (`silicaflux-securestore-p59.zip`) | AES-XTS (NIST CAVP validated), CMAC, KDF, `sfsec_keymgr` with key slots, zeroise (`INVALIDATE`, `kill_o`) | REAL; keys are **ordinary flip-flops** ("NOT tamper-resistant key storage"); no eFuse / OTP / secure NVM | Defines what "zeroisation" can honestly mean here; slot/zeroise/confirm interface adopted in `sf_citadel_crypto_adapter` |
| **ECCCore P54 / ECCMemory P77 / RAS P26** | SECDED SRAM codec (proved for 1-/2-bit errors), `sf_sram_ecc_ras` (`ev_ce/ev_ue`, `fatal_req_o`), `sfras_event_ctrl` (typed events, severity, log), watchdog / thermal / DMA / timeout monitors | REAL (simulation + SAT/bounded proofs) | Event vocabulary and severities reused; Citadel consumes these as `ev_*` inputs (§1 of `05_FAULT_CONTAINMENT.md`) |
| **TestCore P07** | MBIST, JTAG, DFT, `sftc_mem_owner` (test path to memory), `tc_mode_ctrl` (unlock token) | REAL; its own docs: the unlock key is "an interlock, **not security**"; no OTP / lifecycle / authenticated debug | Treated as an **alternate path to memory** (see §3) |
| **ControlCore P21** | RV32IM control core, boot ROM, SFB2 bus, `cc_secmon` (security *status* page), `cc_sfb_gate` | REAL; `docs/09_LIMITATIONS.md`: "**No firmware authentication, secure boot, root of trust, key storage or debug authentication**; CRC32 is an integrity check" | The management plane that will drive the command port; **not** a trust anchor on its own |
| **DataFabric / NoC v2** (`silicaflux-datafabric*.zip`) | 2×2 mesh NoC, DMA, memory controller | REAL; DMA doc: "**Region legality is not known to the DMA**" — no access control anywhere in the fabric (no hit for permission / firewall / isolation in the NoC docs) | The gap Citadel fills: enforcement must be added at each master port (`04_ENFORCEMENT.md`) |
| **Reset logic** | `sf_albion_reset_sync` (async assert / sync deassert, `STAGES ≥ 2`), TestCore `tc_rst_ctrl` (three reset domains, POR cell is analog IP outside the RTL), ControlCore `cc_sysctrl` (watchdog / software resets) | REAL | Citadel uses one active-low asynchronous-assert reset, expected synchronously de-asserted (ALP-RST-03); no always-on / POR domain exists (§4) |
| **AES-GCM** | — | **ABSENT** (no block anywhere; AES-XTS, CMAC and SHA-256 exist) | Reported as "unsupported" by capability, never emulated |
| **Real OTP / eFuse / secure NVM / TRNG / DRBG** | — | **ABSENT** | See `08_ASSUMPTIONS_AND_LIMITATIONS.md` |

## 2. Findings that changed the design

1. **No block named Citadel exists**; Meridian carries only a reference model whose own header says so.  The check interface
   (per-port query, same-cycle or registered verdict, default deny after reset, fail-closed on a silent checker) was kept and
   strengthened: Citadel adds physical-port **binding** of the domain label, exact range arithmetic, devices decoded from the
   address, and an explicit coarse status.
2. **A domain number is attacker-controlled** (CloudDMA's own documentation).  Hence the checker never trusts `dom` alone: it must
   be bound to the *physical source port* of the checker instance, and per-domain counters / escalation are charged only to a
   *verified* domain, never to a spoofed label (otherwise one tenant could inflate or quarantine another).
3. **Nothing in the fabric checks access** (DataFabric): the gate (`sf_citadel_gate`) is the only path from a master to its target.
4. **The only existing "root of trust" pieces are partly models.**  P28's verification is real, its fuses are not; ControlCore
   explicitly claims no authentication; TestCore's unlock is an interlock.  Citadel therefore implements only the *policy* around
   an external verdict, reads "root of trust present" from a **platform tie-off** (not a register), and its telemetry says
   what is true (`ABSENT` / `WAIT` / `AUTH_OK` / `FAILED`).
5. **Keys are flip-flops in the engine** (P59): Citadel stores no key material.  It authorises which domain may select which key
   *slot* and requests zeroise; a zeroise is not considered done until the engine confirms it, and a slot whose wipe cannot be
   confirmed stays blocked (fail closed).
6. **MBIST / JTAG is an alternate memory path** that bypasses any master-port policy.  Citadel cannot police it; it provides
   `dft_active_i` (all data-plane traffic denied while test access is active) and states the limit explicitly.
7. **No always-on reset domain**: counters and policy are cleared by `rst_ni`.  "Reset events" therefore counts *containment*
   resets issued by Citadel, not power cycles.
8. **Tooling facts that bound the verification**: Verilator 5.020 and Yosys 0.33 are the project's tools (reproduced here);
   `sf_albion_pkg.sv` does **not** parse under Icarus 12 (so Icarus cannot be the second simulator for Albion-based RTL);
   SymbiYosys is not available, the Albion Yosys → AIGER → ABC `pdr` flow is used instead.

## 3. Reuse summary

* **Reused unmodified:** `sf_albion_pkg.sv`, `sf_albion_memmap_pkg.sv` (vendored), the secworks SHA-256 core (vendored, BSD-2 headers
  kept, used only by a test), the Albion style rules, the Albion formal method and testbench rules.
* **Reused as design input (re-implemented, not copied):** Meridian's check interface, CloudDMA's check-before-transaction and
  range discipline, P28's overflow handling, RAS / ECC event vocabulary, P59's key-slot / zeroise / confirm interface.
* **New:** everything in `rtl/albion/sf_citadel_*.sv`.
