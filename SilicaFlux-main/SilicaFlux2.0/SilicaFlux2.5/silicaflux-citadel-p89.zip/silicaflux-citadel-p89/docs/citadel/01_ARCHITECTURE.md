# 01 — Architecture

```
                         management plane (ControlCore / secure monitor)  -- physically exclusive (assumption A-CFG)
                                │ command port                     │ telemetry port
   authenticated-boot ─verdict─►│ sf_citadel_secboot ─cfg_open──►  │
   block (external, P28)        │   (policy only)         │        │
                                ▼                         ▼        ▼
 master 0 ─► [gate/check pt] ─► chk port 0 ─┐        ┌──────────────────────────────┐
 master 1 ─► [gate/check pt] ─► chk port 1 ─┼─ src=p ►  sf_citadel_permission × NP    │ combinational verdict
 master n ─► [gate/check pt] ─► chk port n ─┘        └─────▲────────────▲───────────┘  (permit · reason · ALP status)
        ▲ only permitted requests reach the target          │ descriptor │ lockdown / qhold / port_isol / dft
        │ (denied → explicit error response)       ┌────────┴──────┐     │
   target / fabric                                 │ sf_citadel_   │◄────┴──── sf_citadel_fault_manager ◄── sf_citadel_ras ◄── event sources
                                                   │ domain_table  │ qtn(slot)   │  actions                    (ECC, MBIST, DMA, packet,
                                                   │ + privileged  │             ├─► abort_valid/mask → queues  watchdog, compute, thermal,
                                                   │   interpreter │             ├─► eng_rst[p]/done  → engines  auth, boot, queue, ext)
                                                   └───┬───────────┘             ├─► lockdown / safe_entry
                              zero_valid/mask/all ◄────┘                         └─► irq, last fault
                                   │
                                   ▼
                      sf_citadel_crypto_adapter ──{algo, key SLOT, dom, ctx}──► validated crypto engine (SHA-256 / AES-GCM / …)
```

`gate.flush_i` is wired to `port_isol_o[p]` of the same port (cancels a held request and clears the outstanding count while the port is isolated).

## Modules (`rtl/albion/`)

| File | Lines | Role |
|---|---|---|
| `sf_citadel_pkg.sv` | 243 | code points: check classes, reasons, domain states, command opcodes / statuses, RAS sources / severities / policy table, algorithm codes, default device map |
| `sf_citadel_domain_table.sv` | 643 | descriptors, port bindings, **privileged command interpreter**, exclusive-window guard, lookups, containment hook, key-zeroise request |
| `sf_citadel_permission.sv` | 301 | **the hardware permission checker** (combinational) |
| `sf_citadel_gate.sv` | 173 | ALP check point: hold register, latched verdict, explicit error responses, ordering |
| `sf_citadel_ras.sv` | 256 | event collection, pending records, severity arbiter, saturating audit counters |
| `sf_citadel_fault_manager.sv` | 268 | containment policy: quarantine / abort / isolate+reset / safe state / report |
| `sf_citadel_secboot.sv` | 135 | authenticated-boot gate (policy; verifies nothing) |
| `sf_citadel_crypto_adapter.sv` | 248 | CloudCrypto adapter: key-slot authorisation, capability, zeroise tracking |
| `sf_citadel_security.sv` | 546 | **top**: wires the above, one checker per port, exact violation counting, per-domain / per-port counters, privacy-scoped telemetry |

2,813 lines of RTL.  Default-configuration size of the top (NDOM 8, NW 4, NP 4, AW 64; Yosys 0.33, no PDK, **not an area claim**): 10,083 coarse
cells after `proc; flatten; opt -fast`, 157,756 generic gate cells after `synth -flatten`.  (An earlier draft of this file quoted "≈ 12.1 k"; its
method was not recorded and it could not be reproduced, so it was replaced by these two re-measured figures.)

## Design principles (each traces to a finding in `00_AUDIT.md`)

1. **Default deny.**  After reset no slot, window, binding or permission exists.
2. **The domain label is never trusted on its own**; it must be bound to the *physical* source port, a structural constant of the checker instance.
3. **Decide first, then enforce.**  The checker is stateless and combinational; the check point acts only on its verdict, and latches it.
4. **Explicit errors, coarse errors.**  Every denial is answered with a status ≠ OKAY; the requester sees only `OKAY / BAD_OPCODE / BAD_ATTR / ACCESS_DENIED`
   (no layout oracle); the fine reason is for privileged audit.
5. **Smallest sufficient containment**; no victim is guessed; no automatic action that one tenant can trigger against another.
6. **Fail closed**: unknown state, failed verdict, unconfirmed wipe, un-reported engine reset all leave the resource unusable until a privileged action.
7. **Say what is true**: capabilities, boot state and zeroise confirmation come from hardware inputs, never from software-writable flags.

## Conventions (Albion)

Yosys 0.33 subset, flat ports, `_i/_o/_ni`, `_q/_d`, no wildcard imports, no `initial` / assertions in RTL (assertions live in `formal/citadel/`
and `tests/citadel/`), `` `default_nettype none``, async-low `rst_ni`.  The one deliberate deviation from Albion's naming rules is the module prefix
`sf_citadel_` (mandated by the brief; Albion's rule is `sf_albion_`), checked by `tools/citadel/style_check.py`.

## Repository layout of this delivery

```
rtl/albion/            the nine RTL files above (primary: sf_citadel_security.sv)
third_party/albion/    sf_albion_pkg.sv, sf_albion_memmap_pkg.sv   (unmodified, SHA-256 in SHA256SUMS)
third_party/secworks_sha256/   real validated SHA-256 core (unmodified, BSD-2) -- used by one test only
tests/citadel/unit/    tb_citadel_vec (replay vs Python model), tb_citadel_ras, tb_citadel_secboot, tb_citadel_pkg
tests/citadel/system/  tb_citadel_system, tb_citadel_boot, tb_citadel_crypto
formal/citadel/        fv_cit_{perm,iso,table,gate,fm,secboot,crypto}.sv + jobs.json (generated by tools/citadel/gen_formal_jobs.py)
tools/citadel/         citadel_model.py (independent model), gen_vectors.py, run_vec.py, formal.py, mutate.py, run_all.py, style_check.py
docs/citadel/          this documentation          reports/citadel/   generated results
```
