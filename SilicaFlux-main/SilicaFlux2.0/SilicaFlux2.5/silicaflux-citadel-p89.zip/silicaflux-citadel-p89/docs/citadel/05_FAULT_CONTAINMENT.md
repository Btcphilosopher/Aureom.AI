# 05 — Reliability monitoring, fault containment and audit counters

`sf_citadel_ras` (collect + count + prioritise) → `sf_citadel_fault_manager` (contain) → table / checkers / engines.

## 1. Severity classes (the brief's four)

| Class | Meaning | Typical action |
|---|---|---|
| **CORRECTED** | repaired; data valid | count / log only |
| **DETECTED** | error detected, operation failed or discarded, data not consumed | reject (already done) · abort one queue |
| **UNCORRECTABLE** | data lost / corrupt in a resource that has an owner | quarantine the owner · reset one engine |
| **FATAL** | device-level integrity cannot be assumed | **safe state** |

## 2. Sources and fixed policy (`sf_citadel_pkg::SF_CIT_POLICY`, checked by `tb_citadel_pkg`)

| # | Source | Severity | Base actions | `ev_idx` is | Typical hardware feed |
|---|---|---|---|---|---|
| 0 | `ECC_CE` | corrected | — | — | `sf_sram_ecc_ras.ev_ce` |
| 1 | `ECC_UE` (+ address) | uncorrectable | report, quarantine-owner | — | `ev_ue`, `last_addr` |
| 2 | `ECC_FATAL` | fatal | safe state, report | — | `fatal_req_o` |
| 3 | `MBIST_FAIL` (level, +address) | uncorrectable | report, quarantine-owner | — | TestCore fail log |
| 4 | `DMA_FAULT` | detected | report, abort queue | **queue** | CloudDMA error / timeout |
| 5 | `PKT_PROTO` | detected | report, abort queue | **queue** | packet engine |
| 6 | `ILLEGAL` | detected | — (count) | port | generated inside (denials) |
| 7 | `INVALID_DMA` | detected | — (count) | port | generated inside (denials on DMA ports) |
| 8 | `WATCHDOG` | uncorrectable | report, reset engine | **engine / port** | engine watchdog |
| 9 | `COMPUTE_ERR` | uncorrectable | report, abort domain's queues, reset engine | **engine / port** | parity / result check |
| 10 | `THERM_WARN` (level) | detected | report | — | thermal monitor |
| 11 | `THERM_CRIT` (level) | fatal | safe state, report | — | thermal monitor |
| 12 | `AUTH_FAIL` | detected | report | — | crypto adapter `auth_fail_o` |
| 13 | `BOOT_FAIL` | fatal | safe state, report | — | `sf_citadel_secboot` |
| 14 | `QUEUE_FAULT` | detected | report, abort queue | **queue** | descriptor overflow, ring corruption |
| 15 | `EXT_FATAL` | fatal | safe state, report | — | e.g. ControlCore RAS |

Attribution inputs per source: an explicit **domain id** (`ev_dom_i`, `ev_dom_vld_i`), an **index** (`ev_idx_i`: queue number or engine /
port number as in the table), and for sources 0–3 an **address** (`ev_addr_i`).

## 3. RAS behaviour (`sf_citadel_ras`)

* **Every** occurrence of **every** source is counted, saturating at all-ones (never wraps), even when several arrive in one cycle
  (`ev_extra_i` carries same-cycle extras, e.g. several ports denying together) or the fault manager is busy.
* One **pending record** per source with its attribution.  A second occurrence while the record is pending is counted and flagged
  `overrun` (sticky until cleared); the first attribution is kept.  An occurrence in the same cycle as the acknowledge re-arms the record.
* One record per cycle goes to the fault manager, **most severe first** (fatal > uncorrectable > detected > corrected), then
  **round-robin among the pending sources of that severity**: a fatal event is never queued behind corrected errors (test `P5i`,
  mutant `R01`), and no source — in particular none a tenant can trigger at will (access violations, authentication failures) — can
  starve another of its own severity.  (Review finding: with lowest-number-first, an access-violation flood kept `QUEUE_FAULT` pending
  and un-served, so queue containment never happened; test `P9b`, mutants `R09`, `R10`.)  A source that is pending when a second
  occurrence arrives still coalesces (counted, flagged `overrun`, first attribution kept): the wait is now bounded by the other
  sources of its severity, but a burst of two queue faults for different queues inside that window contains only the first.
* Level inputs (`LEVEL_MASK`: sources 3, 10, 11) count **once per rising edge**; pulse inputs count every cycle they are high
  (`P5j`, mutant `R03`).

## 4. Audit counters (the brief's seven; privileged telemetry `0x10…0x16`)

| Counter | Counts | Source |
|---|---|---|
| Access violations | every denied check-port request (all ports), every refused privileged command (`BAD_PRIV`, `NOT_AUTH`, `LOCKED`), every denied telemetry read | sources 6 + 7 |
| Invalid DMA attempts | denials on ports flagged `DMA_PORTS` (a subset of the above) | source 7 |
| Authentication failures | crypto tag / MAC failures **and** boot failures | sources 12 + 13 |
| ECC corrections | corrected single-bit events | source 0 |
| Uncorrectable errors | all events whose policy severity is *uncorrectable* | sources 1, 3, 8, 9 |
| Queue faults | DMA, packet, queue faults | sources 4, 5, 14 |
| Reset events | containment resets issued (engine resets + safe-state entries) — **not** power cycles (no always-on domain) | fault manager |

Also: four severity counters (`0x18…0x1B`), 16 per-source counters (`0x20…0x2F`), per-port violation counters (`0x40…`), per-domain violation
counters (`0x80 + 4·slot + 1`, **charged only to a verified domain**; cleared when the slot is enrolled or revoked).

## 5. Containment policy (`sf_citadel_fault_manager`)

Attribution: an explicit domain id, else the **owner of the faulting address** = the domain holding an *exclusive* window over it (unique by
INV-EXCL).  An address owned by nobody is **not attributed** — no victim is guessed.

| Event | Action | Unrelated domains |
|---|---|---|
| corrected | none | untouched |
| detected, queue source | abort + **hold that one queue** (`abort_mask_o`, `qhold_o`); queue use refused until privileged `CLR_QHOLD` | other queues of the same domain and all other domains untouched (`P5e2`) |
| uncorrectable, attributed to a **tenant** | **quarantine that domain** (state kept), abort its queues, request zeroise of its keys, report | other tenants keep access and state (`P5b`; proved `F-QTN`) |
| uncorrectable, attributed to a **system** domain | **safe state** (platform memory is corrupt) | tenants denied, state kept |
| uncorrectable, **unattributed** | report only | untouched (`P5c`) |
| engine event (watchdog, compute error) | **isolate that port** (`port_isol_o`), pulse `eng_rst_o[p]`; reopens on `eng_rst_done_i[p]` (or after `RST_HOLD` cycles if configured, or a privileged `CLR_ISOL`) | other ports unaffected (`P5d`, `P5f`; proved `F-ENG`) |
| fatal | safe state | — |

`RST_HOLD = 0` (default) is **fail closed**: an isolated port stays isolated until the engine reports done or ROOT / MGMT clears it.
A `done` counts only if seen **after** the cycle in which the reset was requested (a level that was already high is not an answer; proved
`f_isol_pair`, mutant `F14`); an engine that ties `done` high still releases the port after two cycles — A-ACT.  `RST_HOLD` must be
0 … 65535 (16-bit timer; elaboration error otherwise — the review found that 65536 silently became 0).  Queue-source events carry the
queue number in `ev_idx`; it is taken as hardware wiring from the queue controller (not tenant-controlled) and is **not** checked against
the attributed domain's queue mask (assumption).

### Safe state (defined, sticky)

1. `lockdown_o`: every data-plane request is denied except those of **verified ROOT / MGMT** (needed for recovery);
2. every queue is aborted and held;
3. `zero_all_o`: every key slot is zeroised (crypto adapter);
4. the fault is reported (`irq_o`), `safe_entry_o` pulses once;
5. engines are **not** reset automatically.

Left only by a privileged **ROOT** `CLR_SAFE`; queue holds are cleared separately by `CLR_QHOLD`.  A set in the same cycle wins over a clear
(proved).  **`CLR_SAFE` has no effect while a FATAL *level* condition (critical temperature) is still asserted** — a level source raises
its event only on the rising edge, so releasing would leave the device running with the condition and no event to re-enter (proved
`f_safe`, mutant `F13`).  The command is accepted (status OK); the effect is visible on `lockdown_o`.  A second FATAL event while already in
the safe state does not re-pulse `zero_all_o`: keys provisioned by ROOT / MGMT during lock-down are not wiped again (accepted: lock-down
admits only ROOT / MGMT).

### Concurrency and reset

One event per cycle is processed; simultaneous events are all counted and processed in severity order (all 16 sources in one cycle: `P5h`).
Set wins over clear everywhere (queue hold, safe state; mutants `F06`, `F07`).  Reset clears every containment register: no
containment state survives reset (proved `F-RESET`).

### What is deliberately **not** automatic

Repeated access violations do **not** auto-quarantine a domain, and a spoofed label is never charged to the domain it names.
Otherwise a tenant could force the quarantine of another tenant, or of co-tenants sharing its port.  The management plane reads the
per-domain counters and alert flag (`SET_THRESH`) and decides (`SET_STATE`).

### Last-fault record

`0x03…0x05` hold the last **uncorrectable / fatal** event (source, severity, attribution, actions taken) and the worst severity since the
last acknowledge.  Corrected and detected events — in particular access violations a tenant can generate at will — are counted but never
overwrite it, so no tenant can hide a hardware fault from the management plane (mutant `F11`).
