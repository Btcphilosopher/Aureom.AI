# 09 — Telemetry registers, ports and parameters (`sf_citadel_security`)

## 1. Telemetry read port

`tel_valid_i, tel_addr_i[7:0] (word index), tel_dom_i, tel_priv_i, tel_src_i` → one cycle later `tel_rvalid_o, tel_rdata_o[31:0], tel_err_o`.
The response is a **one-cycle registered pulse**.

**Authorisation** (`tel_err_o = 1` and `tel_rdata_o = 0` otherwise; an unauthorised read is also an *access violation*):

* **Privileged**: `tel_priv_i` ∧ label ∈ {ROOT, MGMT} ∧ configuration enabled (`cfg_en_i ∧ secure-boot open`) ∧ **`tel_src_i` is a
  management-plane port (`TEL_PRIV_PORTS`, default port 0)** — may read everything.  The label alone is not trusted: a tenant-facing port
  that presents ROOT with `priv = 1` gets an error, zero data and is counted as an access violation (review finding; mutant `S18`).
* **Own domain**: a non-privileged requester may read **only its own per-domain registers**, and only if its domain id is *verified for the
  physical telemetry port* `tel_src_i` (known and bound there).
* A privileged read of an undefined register or a non-existent slot returns an error with zero data but is **not** a violation.

| Address | Register | Layout |
|---|---|---|
| `0x00` | ID | `[31:16]=0xC17A, [15:8]=major, [7:0]=minor` |
| `0x01` | CAPS | `[0]` telemetry · `[1]` secure-boot interface wired · `[2]` domain isolation · `[3]` RAS · `[4]` crypto adapter wired · `[5]` **a root of trust is present (live tie-off)** · `[15:8]` NDOM · `[23:16]` NP · `[31:24]` NQ |
| `0x02` | STATUS | `[0]` lockdown · `[1]` config locked · `[2]` irq · `[3]` DFT active · `[4]` config enabled · `[6]` authenticated boot in force |
| `0x03` | LAST_FAULT | `[20]` valid · `[19:18]` severity · `[17:14]` source · `[13]` domain attributed · `[12:8]` actions {safe, quarantine, reset, abort, report} · `[7:0]` index — **uncorrectable / fatal events only** |
| `0x04` | LAST_FAULT_DOM | `[7:0]` attributed domain id |
| `0x05` | WORST_SEV | `[1:0]` maximum severity since the last acknowledge |
| `0x06` | THRESH | `[15:0]` per-domain violation alert threshold |
| `0x07` | BOOT_STATUS | `[12]` secure-boot interface wired · `[11]` root of trust present · `[10:8]` state (0 ABSENT, 1 WAIT, 2 AUTH_OK, 3 FAILED) · `[7:0]` failure code |
| `0x10…0x16` | **audit counters** | access violations · invalid DMA · authentication failures · ECC corrections · uncorrectable · queue faults · reset events |
| `0x18…0x1B` | severity counters | corrected · detected · uncorrectable · fatal |
| `0x20…0x2F` | per-source counters | source 0…15 |
| `0x30` | PENDING / OVERRUN | `[15:0]` pending records · `[31:16]` overrun flags |
| `0x31` / `0x32` | QHOLD / PORT_ISOL | queue-hold mask / port-isolation mask |
| `0x40 + p` | per-port violation counter | `[15:0]` (all denials on port p, spoofs included) |
| `0x80 + 4·s + 0` | slot s descriptor summary | `[31:30]` state · `[7:0]` domain id |
| `0x80 + 4·s + 1` | slot s violation counter | `[16]` alert flag · `[15:0]` count (**verified domain only**) |

Counters are `CNT_W` bits (default 32), saturating, cleared only by ROOT `CLR_CNT` or reset.  Acknowledging with `CLR_CNT` also clears the report
(`irq_o`), the last-fault record and the worst severity.

## 2. Ports of `sf_citadel_security`

| Group | Ports |
|---|---|
| Clock / reset | `clk_i`, `rst_ni` (async assert; release synchronously, ALP-RST-03) |
| Platform | `cfg_en_i`, `dft_active_i` |
| Secure boot | in: `rot_present_i`, `boot_done_i`, `boot_ok_i`, `boot_err_i[7:0]` · out: `fw_run_ok_o`, `boot_state_o[2:0]`, `boot_err_o[7:0]` |
| Command | `cmd_valid_i, cmd_op_i, cmd_dom_i, cmd_priv_i, cmd_slot_i, cmd_win_i, cmd_port_i, cmd_arg_dom_i, cmd_flags_i, cmd_data0_i, cmd_data1_i` → `rsp_valid_o, rsp_status_o` |
| Check ports (×`NP`) | in: `chk_valid_i, chk_commit_i, chk_dom_i, chk_op_i, chk_attr_i, chk_addr_i, chk_len_i, chk_cls_i, chk_idx_i` · out: `chk_permit_o, chk_status_o, chk_reason_o` (**audit only**) |
| Events | `ev_i[16]`, `ev_dom_vld_i`, `ev_dom_i`, `ev_idx_i`, `ev_addr_vld_i[4]`, `ev_addr_i` (sources 6 / 7 / 13 are OR-ed with internal generation) |
| Containment | `abort_valid_o, abort_mask_o, eng_rst_o[NP], eng_rst_done_i[NP], qhold_o, port_isol_o, lockdown_o, safe_entry_o, irq_o` |
| Key hygiene | `zero_valid_o, zero_mask_o[NKEY], zero_all_o` (→ `sf_citadel_crypto_adapter`) |
| Telemetry | `tel_*` (§1) |
| Exports for the crypto adapter | `slot_state_o, slot_id_o, bind_o, kmask_o, cfg_lock_o` |

## 3. Parameters

| Parameter | Default | Note |
|---|---|---|
| `NDOM` / `NW` / `NP` / `NDEV` / `NQ` / `NKEY` | 8 / 4 / 4 / 7 / 16 / 8 | `NP` ≤ 8, `NDOM` ≤ 32, `NQ` ≤ 32 (32-bit telemetry masks) |
| `AW`, `LEN_W` | 64, 32 | `AW ≤ 64` |
| `DEV_BASE/MASK/PRIV/SECURE` | the Albion catalogue's 7 device regions | verified against `sf_albion_memmap_pkg` |
| `DMA_PORTS` | 0 | ports counted as DMA (invalid-DMA counter) |
| `TEL_PRIV_PORTS` | `NP'(1)` (port 0) | telemetry source ports wired to the management plane (privileged reads only there) |
| `SECBOOT_EN`, `ALLOW_UNAUTH`, `BOOT_TIMEOUT` | 0, **0**, 0 | `ALLOW_UNAUTH = 1` only for bring-up (default is fail closed) |
| `RST_HOLD` | 0 | 0 = fail closed; must be ≤ 65535 (elaboration error otherwise) |
| `CNT_W`, `LEVEL_MASK` | 32, `0x0C08` | |

Size at the default configuration (Yosys 0.33, **not** an area claim — no PDK, no timing): 10,083 coarse cells (`proc; flatten; opt -fast; stat`),
157,756 generic gates (`synth -flatten; stat`).
