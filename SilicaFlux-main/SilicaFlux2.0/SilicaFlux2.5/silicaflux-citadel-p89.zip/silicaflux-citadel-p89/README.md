# SilicaFlux Albion — Project 89 · Citadel: cloud hardware security and reliability

**Primary RTL:** [`rtl/albion/sf_citadel_security.sv`](rtl/albion/sf_citadel_security.sv) · Aureom.AI / SilicaFlux Albion · delivered as this archive — **nothing was committed to GitHub.**

Citadel is the common security and fault-containment block of the Albion cloud device.  It **enforces** memory-window, device, queue and
key permissions per domain at every master port, **refuses** cross-domain operations before any side effect, and **detects, classifies,
counts and contains** the supported hardware failures — so that one tenant's fault or attack costs the others no state.

> **Status — read this first.**  Evidence is RTL **simulation** (Verilator 5.020), an **independent Python model**, **formal proofs**
> (Yosys 0.33 → ABC `pdr`) and a **mutation campaign**.  No FPGA, no timing, no area, no power, no silicon; **no frequency / area / power is claimed**.
> Citadel contains **no cryptography**, verifies **no signature**, stores **no key material** and makes **no claim of a secure root of trust**: its secure-boot
> and crypto modules are the *interface and fail-closed policy* around externally supplied, vetted blocks.  The repository has **no real OTP / eFuse** and
> **no AES-GCM**; both are reported as absent.  This is **not** a security certification.  Read [`docs/citadel/08`](docs/citadel/08_ASSUMPTIONS_AND_LIMITATIONS.md).
> Known residual gaps the independent review surfaced and that hardware does **not** close: a permitted request already presented to a stalled target
> survives a quarantine (only port isolation withdraws it); MGMT can clear holds / isolation and port bindings persist across REVOKE/ENROLL (the
> management plane is trusted); two queue faults inside one arbitration window coalesce; an engine that ties `eng_rst_done_i` high defeats the
> reset handshake.  The Meridian / CloudDMA adapters and the P28 wiring were **not** built.

## Definition of done (from the brief)

> *The system reliably rejects unauthorised operations and reports supported faults without corrupting protected memory.*

| Claim | Evidence (details and exact numbers: [`docs/citadel/07_VERIFICATION.md`](docs/citadel/07_VERIFICATION.md), `reports/citadel/SUMMARY.md`) |
|---|---|
| Unauthorised requests are rejected before any side effect | permission checker **proved** equal to an independent reference and to a priority-free predicate for every table state and request (unbounded; AW = 8 / 12 / 16 / **64**); the gate is **proved** never to present a request that was not permitted at its first evaluation, and to leave the destination untouched when denied |
| One domain cannot reach another's protected region | **isolation theorem proved**: the table invariants (exclusive windows disjoint, unique ids, well-formed windows, no device overlap) are inductive over *every* command sequence and a permitted request never touches another domain's exclusive window |
| Every rejected request returns an explicit error | **proved** (`a_explicit`, `a_okay`, `a_status_set`); the requester sees only four statuses — no layout oracle |
| Invalid commands do not enable privileged operations | **proved**: refused commands change nothing, privilege is checked before opcode decode, MGMT can never touch system domains / bindings / lock / safe state; **ROOT-only** controls |
| Reset clears privileged in-flight control state | **proved** for the table (response, pulses, lock, bindings, windows) and the fault manager; simulated at system level incl. a command in flight |
| Key-access permissions are enforced | **proved** (`fv_cit_crypto`): a command reaches the engine only if permitted at acceptance (domain verified + bound + ACTIVE, algorithm advertised, key slot permitted and not blocked) |
| Faults are classified (corrected / detected / uncorrectable / fatal) and contained without hurting unrelated domains | **proved** (`fv_cit_fm`): quarantine only for an attributed tenant, engine reset only for the named engine, safe state exactly per policy, set-wins-over-clear; system test with simultaneous faults |
| Mutation check | 138 planted faults in the RTL, each caught by a formal counterexample or a failing simulation (`reports/citadel/mutation.json`) |
| Independent review | a separate agent attacked the finished design with its own testbenches: **10 confirmed findings (3 medium) + 3 suspected**; the confirmed ones were fixed or, where the cure would break the protocol or the trust model, documented as assumptions — table in [`docs/citadel/07`](docs/citadel/07_VERIFICATION.md) §6 |

## Quick start

```bash
make quick          # lint + style + all simulations + replay vectors + all formal jobs   (a few minutes)
make all            # the same with more replay seeds
make mutants        # + the full mutation campaign (tens of minutes)
python3 -I tools/citadel/formal.py --list        # the formal jobs
```
Requires Verilator 5.020, Yosys 0.33 (with `yosys-abc`), Python 3.  Reports land in `reports/citadel/`.

## Where to read

| Document | Content |
|---|---|
| [`00_AUDIT`](docs/citadel/00_AUDIT.md) | repository audit: what exists, REAL vs MODEL vs ABSENT, reuse, findings that shaped the design |
| [`01_ARCHITECTURE`](docs/citadel/01_ARCHITECTURE.md) | block diagram, modules, principles, layout |
| [`02_PERMISSION_CHECKER`](docs/citadel/02_PERMISSION_CHECKER.md) | the decision order, arithmetic, status mapping |
| [`03_DOMAIN_TABLE`](docs/citadel/03_DOMAIN_TABLE.md) | descriptors, privileged command set, privilege matrix, exclusive windows, invariants |
| [`04_ENFORCEMENT`](docs/citadel/04_ENFORCEMENT.md) | check points (DMA, Meridian, accelerator, virtual-device, peripheral), the gate, integration rules, bypass prevention |
| [`05_FAULT_CONTAINMENT`](docs/citadel/05_FAULT_CONTAINMENT.md) | sources, severities, policy, safe state, audit counters |
| [`06_SECURE_BOOT_AND_CRYPTO`](docs/citadel/06_SECURE_BOOT_AND_CRYPTO.md) | what the secure-boot gate and CloudCrypto adapter are — and are not |
| [`07_VERIFICATION`](docs/citadel/07_VERIFICATION.md) | evidence, formal bounds and assumptions, tool hazards found, how to reproduce |
| [`08_ASSUMPTIONS_AND_LIMITATIONS`](docs/citadel/08_ASSUMPTIONS_AND_LIMITATIONS.md) | integration assumptions, not-claimed list, limitations |
| [`09_REGISTERS_AND_PORTS`](docs/citadel/09_REGISTERS_AND_PORTS.md) | telemetry map, ports, parameters |

## Order of work (as requested)

1. Audit, then **the domain permission checker and table first; isolation proved** before anything else was integrated.
2. Gate, RAS, fault manager, counters, top level, telemetry.
3. Only then the secure-boot interface and the crypto adapter, built on the proven isolation base.
