# Citadel regression summary

Tools: verilator Verilator 5.020 2024-01-01 rev (Debian 5.020-1), yosys Yosys 0.33 (git sha1 2584903a060), python Python 3.13.18

Overall: **PASS** (808 s)

## lint (4 s)

| item | result | detail |
|---|---|---|
| sf_citadel_permission | PASS | verilator -Wall clean; yosys check clean |
| sf_citadel_domain_table | PASS | verilator -Wall clean; yosys check clean |
| sf_citadel_ras | PASS | verilator -Wall clean; yosys check clean |
| sf_citadel_fault_manager | PASS | verilator -Wall clean; yosys check clean |
| sf_citadel_gate | PASS | verilator -Wall clean; yosys check clean |
| sf_citadel_secboot | PASS | verilator -Wall clean; yosys check clean |
| sf_citadel_crypto_adapter | PASS | verilator -Wall clean; yosys check clean |
| sf_citadel_security | PASS | verilator -Wall clean; yosys check clean |
| fm_rst_hold_range (negative test) | PASS | RST_HOLD = 65536 is refused at elaboration |

## style (0 s)

| item | result | detail |
|---|---|---|
| style_check | PASS | style: 9 file(s), 0 with violations |

## sim (56 s)

| item | result | detail |
|---|---|---|
| pkg | PASS | tb_citadel_pkg PASS checks=100 |
| ras_unit | PASS | tb_citadel_ras PASS checks=39 |
| secboot_unit | PASS | tb_citadel_secboot PASS checks=55 |
| system | PASS | tb_citadel_system PASS checks=788 |
| system_O0 | PASS | tb_citadel_system PASS checks=788 |
| system_publicflatrw | PASS | tb_citadel_system PASS checks=788 |
| gate_e2e | PASS | tb_citadel_gate PASS checks=12896 requests=1500 permitted=407 denied=1093 target_writes=221 |
| boot_top | PASS | tb_citadel_boot PASS checks=37 |
| crypto | PASS | tb_citadel_crypto PASS checks=117 |

## vec (33 s)

| item | result | detail |
|---|---|---|
| vec_def64_s1 | PASS | PASS records=12637 checks=7505 commands=4805 state_compares=282 resets=45 |
| vec_def64_s2 | PASS | PASS records=12340 checks=7573 commands=4438 state_compares=281 resets=48 |
| vec_def64_s3 | PASS | PASS records=11126 checks=6177 commands=4626 state_compares=279 resets=44 |
| vec_def64_s4 | PASS | PASS records=12458 checks=7315 commands=4809 state_compares=286 resets=48 |
| vec_def64_s5 | PASS | PASS records=12111 checks=7307 commands=4495 state_compares=271 resets=38 |
| vec_def64_s6 | PASS | PASS records=11705 checks=7545 commands=3856 state_compares=264 resets=40 |
| vec_odd16_s1 | PASS | PASS records=9387 checks=5934 commands=3139 state_compares=275 resets=39 |
| vec_odd16_s2 | PASS | PASS records=9092 checks=5898 commands=2893 state_compares=263 resets=38 |
| vec_odd16_s3 | PASS | PASS records=9237 checks=5821 commands=3099 state_compares=275 resets=42 |
| vec_odd16_s4 | PASS | PASS records=9204 checks=5939 commands=2962 state_compares=266 resets=37 |
| vec_odd16_s5 | PASS | PASS records=9055 checks=5798 commands=2940 state_compares=273 resets=44 |
| vec_odd16_s6 | PASS | PASS records=9414 checks=5883 commands=3202 state_compares=283 resets=46 |
| vec_tiny8_s1 | PASS | PASS records=8785 checks=5729 commands=2725 state_compares=282 resets=49 |
| vec_tiny8_s2 | PASS | PASS records=8753 checks=5882 commands=2568 state_compares=266 resets=37 |
| vec_tiny8_s3 | PASS | PASS records=8803 checks=5744 commands=2737 state_compares=277 resets=45 |
| vec_tiny8_s4 | PASS | PASS records=8691 checks=5704 commands=2679 state_compares=269 resets=39 |
| vec_tiny8_s5 | PASS | PASS records=8730 checks=5839 commands=2597 state_compares=261 resets=33 |
| vec_tiny8_s6 | PASS | PASS records=8806 checks=5742 commands=2721 state_compares=288 resets=55 |
| vec_total | PASS | 113335 permission checks, 61291 commands, 4941 state compares |

## formal (61 s)

| item | result | detail |
|---|---|---|
| formal_perm_aw16 | PASS | unbounded proof (ABC pdr): PROVED; 16 cover bins all reachable |
| formal_perm_aw64 | PASS | unbounded proof (ABC pdr): PROVED; 6 cover bins all reachable |
| formal_perm_odd12 | PASS | unbounded proof (ABC pdr): PROVED; 11 cover bins all reachable |
| formal_perm_tiny8 | PASS | unbounded proof (ABC pdr): PROVED; 8 cover bins all reachable |
| formal_iso_aw5 | PASS | unbounded proof (ABC pdr): PROVED; 8 cover bins all reachable |
| formal_table_priv | PASS | unbounded proof (ABC pdr): PROVED; 12 cover bins all reachable |
| formal_gate_ok | PASS | unbounded proof (ABC pdr): PROVED; 9 cover bins all reachable |
| formal_gate_orphan | PASS | unbounded proof (ABC pdr): PROVED; 1 cover bins all reachable |
| formal_fm_scope | PASS | unbounded proof (ABC pdr): PROVED; 9 cover bins all reachable |
| formal_fm_hold | PASS | unbounded proof (ABC pdr): PROVED; 4 cover bins all reachable |
| formal_secboot | PASS | unbounded proof (ABC pdr): PROVED; 6 cover bins all reachable |
| formal_secboot_strict | PASS | unbounded proof (ABC pdr): PROVED; 2 cover bins all reachable |
| formal_crypto_key | PASS | unbounded proof (ABC pdr): PROVED; 8 cover bins all reachable |

## mutants (653 s)

| item | result | detail |
|---|---|---|
| mutation_campaign | PASS | mutation: 138 mutants, 138 killed, survivors=[], errors=[] |

