#!/usr/bin/env python3
"""Citadel formal runner: Yosys 0.33 front end + ABC (no SymbiYosys, no proprietary tool).

Same method as the Albion library (tools/albion/build/formal.py), re-implemented stand-alone:

  prove   the wrapper is flattened, async resets are modelled with async2sync, cover cells are removed and the
          design is written as an AIGER model whose bad-state outputs are the wrapper's assertions.  ABC's
          property-directed reachability (`pdr`, IC3) answering "Property proved" is an UNBOUNDED proof of every
          assertion for every input sequence the wrapper's assumptions allow.
  bmc     (jobs with "engine": "bmc") bounded model check to "depth" frames: a pass is "no counterexample within
          depth frames", reported as BOUNDED -- never as a proof.
  reach   each listed cover index re-runs the wrapper with COVER_IDX=i (the wrapper asserts the cover bin is
          unreachable) under `bmc3`: a counterexample is a WITNESS that the situation exists, so the proof is not
          vacuous.
  unreach the same, but the bin must NOT be reachable.

A result that is neither "proved" nor a counterexample (timeout / resource limit / unknown) is a FAILURE.
Jobs that carry "expect": "CEX" are mutation probes: the property MUST be disproved.

  formal.py [--job NAME ...] [--jobs N] [--override rel/path=other/path ...] [--list]
"""
import argparse
import json
import os
import re
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
PROVED = re.compile(r"Property proved")
CEX = re.compile(r"was asserted in frame (\d+)")
NONE = re.compile(r"No output asserted in (\d+) frames")
BADYS = re.compile(r"implicitly declared|has no driver|(?<!No )Latch inferred|^ERROR", re.M)


def run(cmd, log=None, timeout=900):
    try:
        p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
        out = p.stdout + p.stderr
        rc = p.returncode
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
        rc = 124
    if log:
        with open(log, "w") as f:
            f.write(out)
    return rc, out


def build_aig(job, files, workdir, extra_params=None):
    os.makedirs(workdir, exist_ok=True)
    ys = []
    for f in files:
        flag = "-sv -formal" if "/formal/" in f.replace(os.sep, "/") else "-sv"
        ys.append("read_verilog %s %s" % (flag, f))
    params = dict(job.get("params", {}))
    params.update(extra_params or {})
    for k, v in params.items():
        ys.append("chparam -set %s %s %s" % (k, v, job["top"]))
    ys += ["hierarchy -check -top %s" % job["top"], "proc", "flatten", "memory_map", "async2sync",
           "chformal -cover -remove", "dffunmap", "setundef -zero", "opt -fast -nodffe -nosdff", "techmap",
           "setundef -zero", "opt -fast -nodffe -nosdff", "aigmap", "opt_clean",
           "write_aiger -zinit -map %s/t.aim %s/t.aig" % (workdir, workdir)]
    rc, out = run(["yosys", "-p", "; ".join(ys)], log=os.path.join(workdir, "yosys.log"))
    if rc != 0:
        return None, "elaboration failed: " + " | ".join(out.strip().splitlines()[-3:])
    bad = BADYS.findall(out)
    if bad:
        return None, "elaboration problems: " + "; ".join(sorted(set(bad)))
    return os.path.join(workdir, "t.aig"), ""


def abc(aig, cmd, timeout):
    rc, out = run(["yosys-abc", "-c", "read_aiger %s; fold; strash; dretime; %s" % (aig, cmd)], timeout=timeout)
    if PROVED.search(out):
        return "PROVED", 0
    m = CEX.search(out)
    if m:
        return "CEX", int(m.group(1))
    m = NONE.search(out)
    if m:
        return "NONE", int(m.group(1))
    return "UNKNOWN", 0


def run_job(job, workroot, overrides, covers=True):
    name = job["name"]
    files = [overrides.get(f, f) for f in job["files"]]
    work = os.path.join(workroot, name)
    res = dict(name=name, top=job["top"], engine=job.get("engine", "pdr"), params=job.get("params", {}),
               status="PASS", checks=[], claim="")
    t0 = time.time()
    aig, err = build_aig(job, files, work)
    if not aig:
        res.update(status="FAIL", detail=err)
        return res
    engine = job.get("engine", "pdr")
    expect = job.get("expect", "PROVED" if engine == "pdr" else "NONE")
    timeout = job.get("timeout", 900)
    if engine == "pdr":
        verdict, frame = abc(aig, "pdr", timeout)
        res["claim"] = "unbounded proof (ABC pdr)"
    else:
        depth = job.get("depth", 20)
        verdict, frame = abc(aig, "bmc3 -F %d" % depth, timeout)
        res["claim"] = "bounded to %d frames (ABC bmc3)" % depth
    res["verdict"] = verdict
    res["checks"].append("%s: %s" % (res["claim"], verdict))
    if verdict != expect:
        res["status"] = "FAIL"
        res["detail"] = "expected %s, got %s%s" % (expect, verdict, (" (frame %d)" % frame) if verdict == "CEX" else "")
    if expect == "CEX" and verdict == "CEX":
        res["checks"][-1] += " (frame %d) -- mutation probe, disproof expected" % frame
    depth = job.get("cover_depth", 24)
    for kind, want_reach in (("reach", True), ("unreach", False)):
        for idx in (job.get(kind, []) or []) if covers else []:
            caig, err = build_aig(job, files, work + "_c%d" % idx, {"COVER_IDX": idx})
            if not caig:
                res.update(status="FAIL", detail=err)
                continue
            v, fr = abc(caig, "bmc3 -F %d" % depth, job.get("cover_timeout", 300))
            reached = (v == "CEX")
            ok = (reached == want_reach) and v in ("CEX", "NONE", "PROVED")
            res["checks"].append("cover %d %s: %s%s" % (idx, "reachable" if want_reach else "unreachable (<=%d frames)" % depth,
                                                       "ok" if ok else "FAILED", (" (frame %d)" % fr) if reached else ""))
            if not ok:
                res["status"] = "FAIL"
                res["detail"] = res.get("detail", "") + " cover %d %s;" % (idx, v)
    res["seconds"] = round(time.time() - t0, 1)
    return res


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--job", action="append")
    ap.add_argument("--jobs", type=int, default=int(os.environ.get("FORMAL_JOBS", "4")))
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--override", action="append", default=[], help="rel/path=replacement/path (mutation testing)")
    ap.add_argument("--workdir", default=os.path.join(ROOT, "build", "formal"))
    ap.add_argument("--summary", default=os.path.join(ROOT, "reports", "citadel", "formal_summary.json"))
    ap.add_argument("--jobfile", default=os.path.join(ROOT, "formal", "citadel", "jobs.json"))
    a = ap.parse_args()
    jobs = json.load(open(a.jobfile))["jobs"]
    if a.list:
        for j in jobs:
            print("%-28s %-22s %s" % (j["name"], j["top"], j.get("engine", "pdr")))
        return 0
    sel = [j for j in jobs if not a.job or j["name"] in a.job]
    overrides = dict(o.split("=", 1) for o in a.override)
    os.makedirs(a.workdir, exist_ok=True)
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        results = []
        for r in ex.map(lambda j: run_job(j, a.workdir, overrides), sel):
            results.append(r)
            print("formal: %-28s %-4s %s (%.0fs)" % (r["name"], r["status"], "; ".join(r["checks"][:1]), r.get("seconds", 0)),
                  flush=True)
            for c in r["checks"][1:]:
                print("          %s" % c)
            if r["status"] != "PASS":
                print("          " + r.get("detail", ""))
    os.makedirs(os.path.dirname(a.summary), exist_ok=True)
    json.dump(results, open(a.summary, "w"), indent=1)
    bad = sum(r["status"] != "PASS" for r in results)
    print("formal: %d job(s), %d failure(s)" % (len(results), bad))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
