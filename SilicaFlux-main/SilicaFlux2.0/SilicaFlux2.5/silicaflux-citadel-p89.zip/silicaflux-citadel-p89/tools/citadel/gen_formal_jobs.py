#!/usr/bin/env python3
"""Write formal/citadel/jobs.json (the single list of formal jobs).  Vector parameters are written as decimal
integers (chparam-safe); extend JOBS here, never edit jobs.json by hand."""
import json, os

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
PKG = ["third_party/albion/sf_albion_pkg.sv", "rtl/albion/sf_citadel_pkg.sv"]
PERM = PKG + ["rtl/albion/sf_citadel_permission.sv", "formal/citadel/fv_cit_perm.sv"]


def vec(vals, w):
    v = 0
    for i, x in enumerate(vals):
        v |= (x & ((1 << w) - 1)) << (i * w)
    return v


ALL_COVERS = list(range(16))
JOBS = []

# ---- permission checker: exact equivalence + corollaries at four parameter points ------------------------------
JOBS.append(dict(name="perm_aw16", top="fv_cit_perm", files=PERM, engine="pdr", timeout=1500,
                 params=dict(NDOM=2, NW=2, NP=2, NDEV=2, NQ=3, AW=16, LEN_W=8,
                             DEV_BASE=vec([0x4000, 0x8000], 16), DEV_MASK=vec([0xF000, 0xFF00], 16),
                             DEV_PRIV=0b01, DEV_SECURE=0b10),
                 reach=ALL_COVERS, cover_depth=3))
JOBS.append(dict(name="perm_aw64", top="fv_cit_perm", files=PERM, engine="pdr", timeout=3000,
                 params=dict(NDOM=2, NW=2, NP=2, NDEV=2, NQ=3, AW=64, LEN_W=32,
                             DEV_BASE=vec([0x120000000, 0x160000000], 64),
                             DEV_MASK=vec([0xFFFFFFFFFFF00000, 0xFFFFFFFFFFF00000], 64),
                             DEV_PRIV=0b11, DEV_SECURE=0b10),
                 reach=[0, 1, 2, 4, 9, 15], cover_depth=3))
JOBS.append(dict(name="perm_odd12", top="fv_cit_perm", files=PERM, engine="pdr", timeout=1500,
                 params=dict(NDOM=3, NW=2, NP=3, NDEV=2, NQ=5, AW=12, LEN_W=6,
                             DEV_BASE=vec([0x400, 0xC00], 12), DEV_MASK=vec([0xF00, 0xFC0], 12),
                             DEV_PRIV=0b10, DEV_SECURE=0b01),
                 reach=[0, 1, 2, 4, 5, 6, 7, 9, 12, 13, 15], cover_depth=3))
JOBS.append(dict(name="perm_tiny8", top="fv_cit_perm", files=PERM, engine="pdr", timeout=1500,
                 params=dict(NDOM=1, NW=1, NP=1, NDEV=1, NQ=1, AW=8, LEN_W=10,
                             DEV_BASE=0x80, DEV_MASK=0xE0, DEV_PRIV=0, DEV_SECURE=0),
                 reach=[0, 1, 2, 4, 5, 6, 9, 15], cover_depth=3))

TBL = PKG + ["rtl/albion/sf_citadel_domain_table.sv", "rtl/albion/sf_citadel_permission.sv", "formal/citadel/fv_cit_iso.sv"]
# ---- isolation theorem: table + checker composed, unconstrained command stream -------------------------------------
JOBS.append(dict(name="iso_aw5", top="fv_cit_iso", files=TBL, engine="pdr", timeout=3500,
                 params=dict(NDOM=2, NW=2, NP=2, NDEV=1, NQ=2, NKEY=1, AW=5, LEN_W=4, DEV_BASE=0x10, DEV_MASK=0x1C,
                             DEV_PRIV=0, DEV_SECURE=0),
                 reach=[0, 1, 2, 3, 4, 5, 6, 7], cover_depth=16, cover_timeout=900))

TPR = PKG + ["rtl/albion/sf_citadel_domain_table.sv", "formal/citadel/fv_cit_table.sv"]
# ---- privileged configuration: one-step transition properties, valid from EVERY state ------------------------------
JOBS.append(dict(name="table_priv", top="fv_cit_table", files=TPR, engine="pdr", timeout=3500,
                 params=dict(NDOM=3, NW=2, NP=2, NDEV=1, NQ=2, NKEY=2, AW=6, DEV_BASE=0x20, DEV_MASK=0x38),
                 reach=list(range(12)), cover_depth=14, cover_timeout=900))

GATE = PKG + ["rtl/albion/sf_citadel_gate.sv", "formal/citadel/fv_cit_gate.sv"]
# ---- enforcement point: verdict is a free input (may flip every cycle) ---------------------------------------------
JOBS.append(dict(name="gate_ok", top="fv_cit_gate", files=GATE, engine="pdr", timeout=3500,
                 params=dict(OUT_W=3, TGT_OK=1), reach=[0, 1, 2, 3, 4, 5, 7, 8, 9], cover_depth=16, cover_timeout=900))
JOBS.append(dict(name="gate_orphan", top="fv_cit_gate", files=GATE, engine="pdr", timeout=3500,
                 params=dict(OUT_W=3, TGT_OK=0), reach=[6], cover_depth=8, cover_timeout=600))

FMF = PKG + ["rtl/albion/sf_citadel_fault_manager.sv", "formal/citadel/fv_cit_fm.sv"]
# ---- fault containment scoping: the RAS is a free event source -------------------------------------------------------
JOBS.append(dict(name="fm_scope", top="fv_cit_fm", files=FMF, engine="pdr", timeout=3500,
                 params=dict(NDOM=2, NP=2, NQ=3, AW=4, RST_HOLD=0), reach=list(range(9)), cover_depth=10, cover_timeout=600))
JOBS.append(dict(name="fm_hold", top="fv_cit_fm", files=FMF, engine="pdr", timeout=3500,
                 params=dict(NDOM=2, NP=2, NQ=3, AW=4, RST_HOLD=3), reach=[0, 1, 2, 3], cover_depth=10, cover_timeout=600))

SBF = PKG + ["rtl/albion/sf_citadel_secboot.sv", "formal/citadel/fv_cit_secboot.sv"]
CRF = PKG + ["rtl/albion/sf_citadel_crypto_adapter.sv", "formal/citadel/fv_cit_crypto.sv"]
# ---- secure-boot fail-closed policy (the verdict is free) and key-access permissions of the crypto adapter ---------------
JOBS.append(dict(name="secboot", top="fv_cit_secboot", files=SBF, engine="pdr", timeout=1500,
                 params=dict(ALLOW_UNAUTH=1, BOOT_TIMEOUT=4), reach=list(range(6)), cover_depth=14, cover_timeout=300))
JOBS.append(dict(name="secboot_strict", top="fv_cit_secboot", files=SBF, engine="pdr", timeout=1500,
                 params=dict(ALLOW_UNAUTH=0, BOOT_TIMEOUT=0), reach=[0, 1], cover_depth=10, cover_timeout=300))
JOBS.append(dict(name="crypto_key", top="fv_cit_crypto", files=CRF, engine="pdr", timeout=3500,
                 params=dict(NDOM=2, NP=2, NKEY=2, CTX_W=2, SRC=1), reach=list(range(8)), cover_depth=14, cover_timeout=900))

if __name__ == "__main__":
    out = os.path.join(ROOT, "formal", "citadel", "jobs.json")
    json.dump(dict(jobs=JOBS), open(out, "w"), indent=1)
    print("wrote %d jobs to %s" % (len(JOBS), out))
