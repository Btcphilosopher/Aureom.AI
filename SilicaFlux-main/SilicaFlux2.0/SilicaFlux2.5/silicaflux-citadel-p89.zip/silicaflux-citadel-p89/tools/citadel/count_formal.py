#!/usr/bin/env python3
"""Counts the NAMED assertions in the formal wrappers and the cover witnesses recorded by the last formal run.

    count_formal.py

Assertions are the `name : assert (...)` statements of formal/citadel/fv_cit_*.sv (the cover probe is excluded); cover witnesses
are the "cover N reachable: ok" lines of reports/citadel/formal_summary.json.  Counts only -- it proves nothing."""
import glob
import json
import os
import re

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
total = 0
for f in sorted(glob.glob(os.path.join(ROOT, "formal", "citadel", "fv_cit_*.sv"))):
    names = set(re.findall(r"^\s*(?:if\s*\([^)]*\)\s*)?([A-Za-z_]\w*)\s*:\s*assert\b", open(f).read(), re.M)) - {"a_cover_probe"}
    print("%-22s %3d named assertions" % (os.path.basename(f), len(names)))
    total += len(names)
print("%-22s %3d" % ("total", total))
p = os.path.join(ROOT, "reports", "citadel", "formal_summary.json")
if os.path.exists(p):
    cov = sum(1 for r in json.load(open(p)) for c in r["checks"] if c.startswith("cover") and "reachable: ok" in c)
    print("cover witnesses recorded by the last formal run: %d" % cov)
