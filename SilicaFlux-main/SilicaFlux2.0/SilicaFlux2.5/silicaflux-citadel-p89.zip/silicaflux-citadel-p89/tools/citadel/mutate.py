#!/usr/bin/env python3
"""Mutation check for the Citadel RTL.

Each mutant plants ONE specific fault in a copy of an RTL file.  It is KILLED when
  (1) a formal job that reads the mutated file is DISPROVED (counterexample), or
  (2) the simulation replay against the independent Python model FAILS.
A SURVIVOR is analysed by hand (equivalent mutant, or a hole in the verification) -- see docs/citadel/07.

    mutate.py [--group table|perm|all] [--id M1 --id M2] [--jobs 4]

Mutations are literal text substitutions (old -> new, exactly one occurrence unless "count" is given); a pattern that
is not found is reported as an ERROR, never as a kill.
"""
import argparse
import json
import os
import re
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, HERE)
import formal  # noqa: E402

TABLE = "rtl/albion/sf_citadel_domain_table.sv"
PERM = "rtl/albion/sf_citadel_permission.sv"
FM = "rtl/albion/sf_citadel_fault_manager.sv"
RAS = "rtl/albion/sf_citadel_ras.sv"
GATE = "rtl/albion/sf_citadel_gate.sv"
TOP = "rtl/albion/sf_citadel_security.sv"
SB = "rtl/albion/sf_citadel_secboot.sv"
CR = "rtl/albion/sf_citadel_crypto_adapter.sv"

# (id, file, old, new, description)
MUTANTS = [
    # ---------------- domain table ----------------
    ("T01", TABLE, "end else if (conflict) begin", "end else if (1'b0) begin",
     "exclusive-window overlap guard removed"),
    ("T02", TABLE, "(new_excl || wex_q[j*NW+k])", "(new_excl)",
     "existing exclusive windows of other domains ignored"),
    ("T03", TABLE, "!d1_fits || (new_base > new_limit) ||", "!d1_fits ||",
     "inverted window (base > limit) accepted"),
    ("T04", TABLE, "tgt_st != sf_citadel_pkg::SF_CIT_DS_INVALID || dup_dom", "tgt_st != sf_citadel_pkg::SF_CIT_DS_INVALID",
     "duplicate domain id accepted"),
    ("T05", TABLE, "(new_excl && excl_dev_conflict)", "1'b0",
     "exclusive window may overlap a device region"),
    ("T06", TABLE, "end else if (!req_root && !(id_is_tenant(cmd_arg_dom_i)", "end else if (1'b0 && !(id_is_tenant(cmd_arg_dom_i)",
     "MGMT may enrol system domains / grant capabilities"),
    ("T07", TABLE, "sf_citadel_pkg::SF_CIT_OP_BIND_PORT: begin\n          if (!req_root) begin",
     "sf_citadel_pkg::SF_CIT_OP_BIND_PORT: begin\n          if (1'b0) begin", "MGMT may bind ports"),
    ("T08", TABLE, "end else if (lock_q) begin\n            st_d = sf_citadel_pkg::SF_CIT_CS_LOCKED;\n          end else if (port_oob) begin",
     "end else if (1'b0) begin\n            st_d = sf_citadel_pkg::SF_CIT_CS_LOCKED;\n          end else if (port_oob) begin",
     "lock does not freeze port bindings"),
    ("T09", TABLE, "new_state != sf_citadel_pkg::SF_CIT_DS_QUARANTINED && !req_root) begin",
     "new_state != sf_citadel_pkg::SF_CIT_DS_QUARANTINED && 1'b0) begin", "MGMT may release a quarantine"),
    ("T10", TABLE, "assign cmd_ok = cmd_valid_i && (st_d == sf_citadel_pkg::SF_CIT_CS_OK);", "assign cmd_ok = cmd_valid_i;",
     "refused commands still change state"),
    ("T11", TABLE, "end else if (!(req_root || req_mgmt)) begin", "end else if (1'b0) begin",
     "unprivileged requester accepted"),
    ("T12", TABLE, "if (!cfg_en_i) begin\n      st_d = sf_citadel_pkg::SF_CIT_CS_NOT_AUTH;", "if (1'b0) begin\n      st_d = sf_citadel_pkg::SF_CIT_CS_NOT_AUTH;",
     "cfg_en_i (boot authorisation) ignored"),
    ("T13", TABLE, "zero_cmd_mask = tgt_kmask;", "zero_cmd_mask = '0;",
     "REVOKE does not zeroise the slot's keys"),
    ("T14", TABLE, "qtn_kmask = we_kprm[s] ? cmd_data0_i[NKEY-1:0] : kmask_q[s*NKEY +: NKEY];", "qtn_kmask = kmask_q[s*NKEY +: NKEY];",
     "containment zeroises the OLD key mask (the bug found by the first replay)"),
    ("T15", TABLE, "      lock_q          <= 1'b0;\n", "",
     "reset does not clear the configuration lock"),
    ("T16", TABLE, "      rsp_valid_o     <= 1'b0;\n      rsp_status_o    <= sf_citadel_pkg::SF_CIT_CS_OK;\n      cmd_deny_o      <= 1'b0;",
     "      rsp_valid_o     <= rsp_valid_o;\n      rsp_status_o    <= sf_citadel_pkg::SF_CIT_CS_OK;\n      cmd_deny_o      <= 1'b0;",
     "reset does not clear the in-flight response"),
    ("T17", TABLE, "        if (we_state[s])  st_q[s*2 +: 2] <= new_state;",
     "        if (we_state[s])  begin st_q[s*2 +: 2] <= new_state; priv_q[s] <= cmd_flags_i[2]; end",
     "SET_STATE can rewrite the privilege capability"),
    ("T18", TABLE, "if (qtn_valid_i && (qtn_ext == s) &&", "if (1'b0 && (qtn_ext == s) &&",
     "containment hook ignored"),
    ("T19", TABLE, "      ctl_clr_safe_o  <= cmd_ok && (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_CLR_SAFE);",
     "      ctl_clr_safe_o  <= 1'b0;", "CLR_SAFE command has no effect"),
    ("T20", TABLE, "      end else if (we_bind && (port_ext == p)) begin\n        bind_q[p*NDOM +: NDOM] <= cmd_data0_i[NDOM-1:0];",
     "      end else if (we_bind) begin\n        bind_q[p*NDOM +: NDOM] <= cmd_data0_i[NDOM-1:0];",
     "BIND_PORT writes every port instead of the addressed one"),
    ("T21", TABLE, "end else if (tgt_st == sf_citadel_pkg::SF_CIT_DS_QUARANTINED) begin\n            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_STATE;\n          end else if (win_oob ||",
     "end else if (1'b0) begin\n            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_STATE;\n          end else if (win_oob ||",
     "windows of a quarantined domain can still be edited"),
    ("T22", TABLE, "st_q[s*2 +: 2]      <= sf_citadel_pkg::SF_CIT_DS_SUSPENDED;", "st_q[s*2 +: 2]      <= sf_citadel_pkg::SF_CIT_DS_ACTIVE;",
     "ENROLL activates the domain immediately"),
    ("T23", TABLE, "if (lock_q && !id_is_tenant(cmd_arg_dom_i)) begin", "if (1'b0) begin",
     "system domains can be enrolled after LOCK"),
    ("T24", TABLE, "(own_addr_i >= wbase_q[(s*NW+k)*AW +: AW]) &&", "(own_addr_i > wbase_q[(s*NW+k)*AW +: AW]) &&",
     "owner lookup misses the first byte of a window"),
    # ---------------- permission checker ----------------
    ("P01", PERM, "(last   <= win_limit_i[(s*NW+k)*AW +: AW])", "(addr_i <= win_limit_i[(s*NW+k)*AW +: AW])",
     "window containment ignores the END of the range (boundary-spanning)"),
    ("P02", PERM, "wire              ovf      = len_zero ? 1'b0 : (sum[SW-1:AW] != '0);", "wire              ovf      = 1'b0;",
     "address overflow not detected"),
    ("P03", PERM, "wire dom_ok = dom_found && dom_bound &&", "wire dom_ok = dom_found &&",
     "port binding ignored (domain spoofing)"),
    ("P04", PERM, "end else if (dom_state != sf_citadel_pkg::SF_CIT_DS_ACTIVE) begin", "end else if (1'b0) begin",
     "suspended / quarantined domains still served"),
    ("P05", PERM, "if (dev_multi || !dev_whole) begin", "if (dev_multi) begin",
     "device-boundary-spanning range not refused"),
    ("P06", PERM, "(op_rd ? win_r_i[s*NW+k] : win_w_i[s*NW+k])", "win_r_i[s*NW+k]",
     "writes allowed by a read-only window"),
    ("P07", PERM, "(!a_instr || win_x_i[s*NW+k])", "1'b1", "instruction fetch without execute right"),
    ("P08", PERM, "end else if (lockdown_i && (dom_i != sf_albion_pkg::SF_DOM_ROOT) && (dom_i != sf_albion_pkg::SF_DOM_MGMT)) begin",
     "end else if (1'b0) begin", "safe state does not deny tenants"),
    ("P09", PERM, "end else if ((a_priv && !dom_priv_cap) || (a_secure && !dom_secure_cap)) begin", "end else if (1'b0) begin",
     "privileged / secure attribute claims not bounded by the domain"),
    ("P10", PERM, "end else if (dft_active_i) begin", "end else if (1'b0) begin", "DFT access does not lock out functional traffic"),
    ("P11", PERM, "    if (port_isol) begin", "    if (1'b0) begin", "isolated port still served"),
    ("P12", PERM, "if ((idx_ext == q) && !qhold_i[q]) begin", "if ((idx_ext == q)) begin", "queue abort-hold ignored"),
    ("P13", PERM, "!(op_rd ? dev_rd_ok : dev_wr_ok)", "!dev_rd_ok", "device write needs only read permission"),
    ("P14", PERM, "(dev_need_priv && !a_priv) || ", "(1'b0) || ", "device privileged-only flag ignored"),
    ("P15", PERM, "end else if (len_zero) begin", "end else if (1'b0) begin", "zero-length request not refused"),
    ("P16", PERM, " ||\n                  (a_instr && op_wr);", ";", "instruction-fetch + WRITE not refused"),
    ("P17", PERM, "end else if (dev_any) begin", "end else if (dev_any && 1'b0) begin", "devices reachable through memory windows"),
    ("P18", PERM, "    else                                                    status_o = sf_albion_pkg::SF_ST_ACCESS_DENIED;",
     "    else if (reason_o == sf_citadel_pkg::SF_CIT_R_NOMAP)    status_o = sf_albion_pkg::SF_ST_DECODE_ERR;\n    else                                                    status_o = sf_albion_pkg::SF_ST_ACCESS_DENIED;",
     "NOMAP reported as DECODE_ERR (layout oracle)"),
    ("P19", PERM, "dev_ov[i] = (addr_i <= (DEV_BASE[i*AW +: AW] | ~DEV_MASK[i*AW +: AW])) &&",
     "dev_ov[i] = (addr_i < (DEV_BASE[i*AW +: AW] | ~DEV_MASK[i*AW +: AW])) &&", "device region misses its last byte"),
    ("P20", PERM, "wire [SW-1:0]     sum      = {{(SW-AW){1'b0}}, addr_i} + {{(SW-LEN_W){1'b0}}, len_m1};",
     "wire [SW-1:0]     sum      = {{(SW-AW){1'b0}}, addr_i} + {{(SW-LEN_W){1'b0}}, len_i};",
     "range end computed as addr+len (off by one)"),
    ("P21", PERM, "reason_o = sf_citadel_pkg::SF_CIT_R_BAD_DOM;\n    end else if (lockdown_i",
     "reason_o = sf_citadel_pkg::SF_CIT_R_BAD_ATTR;\n    end else if (lockdown_i", "spoof reported with the wrong reason"),
    # ---------------- gate (enforcement check point) ----------------
    ("G01", GATE, "wire       base_permit = dec_q ? permit_q : chk_permit_i;", "wire       base_permit = chk_permit_i;",
     "verdict not latched: a policy change can withdraw a presented valid"),
    ("G02", GATE, "assign t_req_valid_o = have_q && v_permit && !out_full;", "assign t_req_valid_o = have_q && !out_full;",
     "a DENIED request is forwarded to the target"),
    ("G03", GATE, "wire        loc_rsp_valid = have_q && !v_permit && out_zero;", "wire        loc_rsp_valid = have_q && !v_permit;",
     "error response overtakes earlier forwarded requests (order)"),
    ("G04", GATE, "{sf_albion_pkg::SF_DATA_W{1'b0}}};", "req_q[sf_albion_pkg::SF_DATA_W-1:0]};",
     "error response carries (leaks) the request's data"),
    ("G05", GATE, "assign chk_commit_o = have_q && !dec_q;", "assign chk_commit_o = have_q;",
     "commit pulse every cycle: a held denial is counted repeatedly"),
    ("G06", GATE, "wire pass_rsp = t_rsp_valid_i && !out_zero && !flush_i;", "wire pass_rsp = t_rsp_valid_i;",
     "orphan target response forwarded to the master"),
    ("G07", GATE, "assign t_req_o       = req_q;", "assign t_req_o       = {req_q[REQ_W-1:1], 1'b0};",
     "presented request differs from the accepted one"),
    ("G08", GATE, "wire [7:0]  req_tag       = req_q[sf_albion_pkg::SF_REQ_TAG_LSB +: sf_albion_pkg::SF_TAG_W];", "wire [7:0]  req_tag       = 8'd0;",
     "error response does not echo the tag"),
    ("G09", GATE, "else if (!fwd && rsp_take)  out_q <= out_q - 1'b1;", "else if (1'b0)  out_q <= out_q - 1'b1;",
     "outstanding counter never decrements"),
    ("G10", GATE, "      have_q   <= 1'b0;\n      dec_q    <= 1'b0;\n      permit_q <= 1'b0;", "      have_q   <= have_q;\n      dec_q    <= 1'b0;\n      permit_q <= 1'b0;",
     "reset does not drop a held request"),
    ("G11", GATE, "assign m_req_ready_o = !have_q || fwd || loc_done;", "assign m_req_ready_o = 1'b1;",
     "a new request overwrites the held one"),
    # ---------------- RAS ----------------
    ("R01", RAS, "for (int sev = 3; sev >= 0; sev--) begin", "for (int sev = 0; sev <= 3; sev++) begin",
     "severity order reversed: a fatal event waits behind corrected ones"),
    ("R02", RAS, "            ovr_q[g] <= 1'b1;                                    // coalesced: counted, first attribution kept",
     "            ovr_q[g] <= 1'b0;                                    // coalesced: counted, first attribution kept", "overrun never flagged"),
    ("R03", RAS, "ev_edge[s] = LEVEL_MASK[s] ? (ev_i[s] && !lvl_q[s]) : ev_i[s];", "ev_edge[s] = ev_i[s];",
     "level inputs not edge-detected"),
    ("R04", RAS, "inc_v[s*5 +: 5] = ev_edge[s] ? (5'd1 + {1'b0, ev_extra_i[s*4 +: 4]}) : 5'd0;", "inc_v[s*5 +: 5] = ev_edge[s] ? 5'd1 : 5'd0;",
     "same-cycle extra occurrences ignored"),
    ("R05", RAS, "sat_add = sum[CNT_W] ? {CNT_W{1'b1}} : sum[CNT_W-1:0];", "sat_add = sum[CNT_W-1:0];", "counters wrap instead of saturating"),
    ("R06", RAS, "            idx_q[g*8 +: 8] <= ev_idx_i[g*8 +: 8];", "            idx_q[g*8 +: 8] <= 8'd0;", "queue / engine index not captured"),
    ("R07", RAS, "aud_reset_o  <= sat_add(aud_reset_o,  rst_evt_i ? 9'd1 : 9'd0);", "aud_reset_o  <= sat_add(aud_reset_o,  9'd0);",
     "reset events not counted"),
    ("R08", RAS, "        if (ack_vec[g]) pend_q[g] <= 1'b0;                       // consumed (a new occurrence below re-arms it)",
     "        if (1'b0) pend_q[g] <= 1'b0;                       // consumed (a new occurrence below re-arms it)", "pending record never consumed"),
    # ---------------- fault manager ----------------
    ("F01", FM, "wire eff_qtn   = sel_valid_i && act[sf_citadel_pkg::SF_CIT_ACT_QUARANTINE] && dom_tenant;",
     "wire eff_qtn   = sel_valid_i && act[sf_citadel_pkg::SF_CIT_ACT_QUARANTINE] && 1'b0;", "tenant quarantine disabled"),
    ("F02", FM, "(act[sf_citadel_pkg::SF_CIT_ACT_QUARANTINE] && dom_system));", "1'b0);", "uncorrectable error in a system domain does not escalate"),
    ("F03", FM, "wire dom_tenant = dom_found && (dom_id >= sf_albion_pkg::SF_DOM_TENANT_FIRST) &&", "wire dom_tenant = dom_found && (dom_id >= 8'h00) &&",
     "system domains treated as quarantinable tenants"),
    ("F04", FM, "if (queue_src && idx_is_q) begin", "if (1'b0) begin", "a queue fault aborts every queue of the domain"),
    ("F05", FM, "((eng_rst_done_i[p] && !eng_rst_o[p]) || clr_isol_i[p] ||", "(clr_isol_i[p] ||", "port isolation not released by the engine's done"),
    ("F06", FM, "qhold_q <= (qhold_q & ~clr_qhold_i) | abort_d;", "qhold_q <= (qhold_q | abort_d) & ~clr_qhold_i;", "clear wins over a simultaneous queue abort"),
    ("F07", FM, "if (eff_safe) lock_q <= 1'b1;\n      else if (clr_safe_eff) lock_q <= 1'b0;", "if (clr_safe_eff) lock_q <= 1'b0;\n      else if (eff_safe) lock_q <= 1'b1;",
     "clear wins over a simultaneous safe-state entry"),
    ("F08", FM, "    if (eff_safe) abort_d = '1;", "    if (1'b0) abort_d = '1;", "safe state does not abort every queue"),
    ("F09", FM, "      zero_all_o   <= eff_safe && !lock_q;", "      zero_all_o   <= 1'b0;", "safe state does not request key zeroisation"),
    ("F10", FM, "      if (eff_rep) rep_q <= 1'b1;", "      if (1'b0) rep_q <= 1'b1;", "faults are not reported (irq)"),
    ("F11", FM, "if (sel_valid_i && (sel_sev_i >= sf_citadel_pkg::SF_CIT_SEV_UNCORRECTABLE)) begin", "if (sel_valid_i && (sel_sev_i != sf_citadel_pkg::SF_CIT_SEV_CORRECTED)) begin",
     "access violations overwrite the last-fault record"),
    ("F12", FM, "      rst_evt_o    <= (|rst_d) || (eff_safe && !lock_q);", "      rst_evt_o    <= 1'b0;", "reset events not signalled"),
    # ---------------- top ----------------
    ("S01", TOP, "if (deny_c[p] && chk_slot_vld[p] && (chk_slot[p*SLOT_W +: SLOT_W] == SLOT_W'(s))) inc = inc + 4'd1;",
     "if (deny_c[p] && (chk_slot[p*SLOT_W +: SLOT_W] == SLOT_W'(s))) inc = inc + 4'd1;", "a spoofed domain label charges the victim's counter"),
    ("S02", TOP, "(tel_slot_ix == {{(8-SLOT_W){1'b0}}, tel_own_slot})", "1'b1", "a tenant may read another tenant's telemetry"),
    ("S03", TOP, "(tel_dom_i == sf_albion_pkg::SF_DOM_ROOT || tel_dom_i == sf_albion_pkg::SF_DOM_MGMT) && cfg_en;",
     "(tel_dom_i == sf_albion_pkg::SF_DOM_ROOT || tel_dom_i == sf_albion_pkg::SF_DOM_MGMT);", "privileged telemetry ignores cfg_en"),
    ("S16", TOP, "wire cfg_en = cfg_en_i && sb_cfg_open;", "wire cfg_en = cfg_en_i;", "the secure-boot verdict does not gate privileged configuration"),
    ("S17", TOP, "ev_all[sf_citadel_pkg::SF_CIT_SRC_BOOT_FAIL]   = sb_fail || ev_i[sf_citadel_pkg::SF_CIT_SRC_BOOT_FAIL];",
     "ev_all[sf_citadel_pkg::SF_CIT_SRC_BOOT_FAIL]   = ev_i[sf_citadel_pkg::SF_CIT_SRC_BOOT_FAIL];", "a failed boot does not reach the RAS (no safe state)"),
    ("S04", TOP, "tel_rdata_o  <= (tel_valid_i && tel_allowed && rd_ok) ? rd_mux : 32'd0;", "tel_rdata_o  <= rd_mux;", "denied telemetry read returns data"),
    ("S05", TOP, "deny_dma = deny_c & DMA_PORTS;", "deny_dma = '0;", "DMA-port denials not counted as invalid DMA"),
    ("S06", TOP, "deny_c[p] = chk_valid_i[p] && chk_commit_i[p] && !chk_permit_o[p];", "deny_c[p] = chk_valid_i[p] && !chk_permit_o[p];", "commit ignored: held denials counted every cycle"),
    ("S07", TOP, ".lockdown_i(lockdown), .dft_active_i(dft_active_i)", ".lockdown_i(lockdown), .dft_active_i(1'b0)", "DFT access does not lock out traffic"),
    ("S08", TOP, "end else if (slot_clr[s] || ctl_clr_cnt) begin", "end else if (ctl_clr_cnt) begin", "a new tenant inherits the previous tenant's counters"),
    ("S09", TOP, "    if (!rst_ni)              thresh_q <= 16'd0;", "    if (!rst_ni)              thresh_q <= thresh_q;", "reset does not clear the alert threshold"),
    ("S10", TOP, ".lockdown_i(lockdown), .dft_active_i(dft_active_i)", ".lockdown_i(1'b0), .dft_active_i(dft_active_i)", "safe state not enforced by the checkers"),
    ("S11", TOP, "ev_extra[sf_citadel_pkg::SF_CIT_SRC_ILLEGAL*4 +: 4]   = n_gen - 4'd1 + {3'd0, ev_i[sf_citadel_pkg::SF_CIT_SRC_ILLEGAL]};", "ev_extra[sf_citadel_pkg::SF_CIT_SRC_ILLEGAL*4 +: 4]   = 4'd0;",
     "simultaneous denials counted once"),
    ("S12", TOP, "n_gen = n_gen + {3'd0, cmd_deny} + {3'd0, tel_deny};", "n_gen = n_gen + {3'd0, tel_deny};", "privileged-command denials not counted"),
    ("S13", TOP, ".qhold_i(qhold), .port_isol_i(port_isol)", ".qhold_i({NQ{1'b0}}), .port_isol_i(port_isol)", "queue holds not enforced by the checkers"),
    ("S14", TOP, ".qhold_i(qhold), .port_isol_i(port_isol)", ".qhold_i(qhold), .port_isol_i({NP{1'b0}})", "port isolation not enforced by the checkers"),
    ("S15", TOP, ".src_i(PORT_W'(p)),", ".src_i(PORT_W'(0)),", "every checker uses source port 0 (binding bypass)"),
    # ---------------- secure-boot gate ----------------
    ("B01", SB, "end else if (boot_done_i) begin\n            if (boot_ok_i && (boot_err_i == 8'd0)) begin", "end else if (boot_done_i || boot_ok_i) begin\n            if (boot_ok_i && (boot_err_i == 8'd0)) begin",
     "boot_ok without boot_done is taken as a verdict"),
    ("B02", SB, "if (boot_ok_i && (boot_err_i == 8'd0)) begin", "if (boot_ok_i) begin", "ok together with an error code accepted (contradiction)"),
    ("B03", SB, "          st_q <= S_FAILED;                                       // FAILED (and any unreachable encoding): sticky until reset",
     "          st_q <= S_WAIT;                                       // FAILED (and any unreachable encoding): sticky until reset", "FAILED is not sticky"),
    ("B04", SB, "if (!boot_ok_i || !rot_present_i) begin                  // the attestation was withdrawn: fail closed",
     "if (!rot_present_i) begin                  // the attestation was withdrawn: fail closed", "loss of boot_ok after AUTH_OK not detected"),
    ("B05", SB, "assign cfg_open_o  = (st_q == S_AUTH) || ((st_q == S_ABSENT) && ALLOW_UNAUTH);", "assign cfg_open_o  = (st_q == S_AUTH) || (st_q == S_WAIT) || ((st_q == S_ABSENT) && ALLOW_UNAUTH);",
     "configuration open while the verdict is pending"),
    ("B06", SB, "err_q  <= ERR_TIMEOUT;\n            fail_q <= 1'b1;", "err_q  <= ERR_TIMEOUT;\n            fail_q <= 1'b0;", "timeout failure raises no failure pulse"),
    ("B07", SB, "assign cfg_open_o  = (st_q == S_AUTH) || ((st_q == S_ABSENT) && ALLOW_UNAUTH);", "assign cfg_open_o  = (st_q == S_AUTH) || (st_q == S_ABSENT);",
     "configuration opens in ABSENT even when ALLOW_UNAUTH = 0"),
    ("B08", SB, "      st_q   <= S_WAIT;\n      err_q  <= 8'd0;\n      tmo_q  <= 32'd0;", "      st_q   <= S_AUTH;\n      err_q  <= 8'd0;\n      tmo_q  <= 32'd0;", "reset leaves the gate open"),
    ("B09", SB, "else if ((BOOT_TIMEOUT != 0) && (tmo_q >= 32'(BOOT_TIMEOUT))) begin", "else if (1'b0) begin", "verdict timeout disabled"),
    ("B10", SB, "fail_q <= 1'b1;\n            end\n          end else if ((BOOT_TIMEOUT", "fail_q <= 1'b0;\n            end\n          end else if ((BOOT_TIMEOUT", "failed verdict raises no failure pulse"),
    ("B11", SB, "assign fw_run_ok_o = (st_q == S_AUTH) || ((st_q == S_ABSENT) && ALLOW_UNAUTH);", "assign fw_run_ok_o = (st_q == S_AUTH) || (st_q == S_WAIT) || ((st_q == S_ABSENT) && ALLOW_UNAUTH);",
     "firmware may run before authentication"),
    # ---------------- crypto adapter ----------------
    ("C01", CR, "dom_bound = bind_i[SRC*NDOM + s];", "dom_bound = 1'b1;", "domain not bound to the adapter's port"),
    ("C02", CR, "(dom_state == sf_citadel_pkg::SF_CIT_DS_ACTIVE) && !dft_active_i &&", "1'b1 && !dft_active_i &&", "suspended / quarantined domain may use keys"),
    ("C03", CR, "key_perm = kmask_i[s*NKEY + k];", "key_perm = 1'b1;", "key-slot permission ignored"),
    ("C04", CR, "wire        supported  = cap_algo_i[req_algo_i];", "wire        supported  = 1'b1;", "engine capability ignored (unsupported algorithm forwarded)"),
    ("C05", CR, "key_blk = zblk_q[k] || zero_now[k];", "key_blk = 1'b0;", "blocked key slots are used"),
    ("C06", CR, "key_blk = zblk_q[k] || zero_now[k];", "key_blk = zblk_q[k];", "request accepted in the same cycle as a wipe of its key"),
    ("C07", CR, "status_q        <= sf_citadel_pkg::SF_CIT_CE_AUTH_FAIL;", "status_q        <= sf_citadel_pkg::SF_CIT_CE_OK;", "authentication failure reported as success"),
    ("C08", CR, "if ((void_q || (cur_needs_key && cur_key_zeroed)) && cur_needs_key) begin", "if (1'b0) begin", "a key wiped mid-operation is reported as success"),
    ("C09", CR, "zblk_q <= (zblk_q & ~(key_zero_ack_i | key_provision_i)) | zero_now;", "zblk_q <= (zblk_q & ~(key_zero_ack_i | key_provision_i));", "zeroised slot not blocked"),
    ("C10", CR, "zblk_q <= (zblk_q & ~(key_zero_ack_i | key_provision_i)) | zero_now;", "zblk_q <= ((zblk_q | zero_now) & ~(key_zero_ack_i | key_provision_i));", "a simultaneous confirmation clears a new zeroise"),
    ("C11", CR, "if ((zero_now != '0) && !cap_zeroize_i) zero_unsupported_o <= 1'b1;", "if (1'b0) zero_unsupported_o <= 1'b1;", "an impossible wipe is not reported"),
    ("C12", CR, "!(lockdown_i && (req_dom_i != sf_albion_pkg::SF_DOM_ROOT) && (req_dom_i != sf_albion_pkg::SF_DOM_MGMT));", "1'b1;", "safe state does not stop key use"),
    ("C13", CR, "assign rsp_ctx_o    = ctx_q;", "assign rsp_ctx_o    = '0;", "response context not echoed"),
    ("C14", CR, "      zblk_q     <= '0;\n      zero_unsupported_o <= 1'b0;", "      zblk_q     <= zblk_q;\n      zero_unsupported_o <= 1'b0;", "reset does not clear the block flags"),
    ("C15", CR, "if (!algo_valid)                       verdict = sf_citadel_pkg::SF_CIT_CE_BAD_ALGO;", "if (1'b0)                       verdict = sf_citadel_pkg::SF_CIT_CE_BAD_ALGO;", "undefined algorithm codes are not refused as such"),
    ("C16", CR, "      key_zero_o <= zero_now;", "      key_zero_o <= '0;", "no wipe pulse is sent to the engine"),
    # ---------------- faults that undo the fixes of the independent review (docs/citadel/07 section 6) ----------------
    ("T25", TABLE, "end else if (tgt_st == sf_citadel_pkg::SF_CIT_DS_QUARANTINED && !req_root) begin",
     "end else if (tgt_st == sf_citadel_pkg::SF_CIT_DS_QUARANTINED && 1'b0) begin",
     "MGMT may REVOKE a quarantined slot (and re-enrol it fresh: a quarantine released without ROOT)"),
    ("T26", TABLE, "zero_cmd_mask = zero_cmd_mask | (tgt_kmask & ~cmd_data0_i[NKEY-1:0]);", "zero_cmd_mask = zero_cmd_mask;",
     "a key slot removed by SET_KEYPRM is not zeroised"),
    ("T27", TABLE, "zero_cmd_mask = zero_cmd_mask | (tgt_kmask & ~cmd_data0_i[NKEY-1:0]);", "zero_cmd_mask = zero_cmd_mask | (cmd_data0_i[NKEY-1:0]);",
     "SET_KEYPRM zeroises the newly granted slots instead of the removed ones"),
    ("R09", RAS, "cand = rr_q + 4'(k);", "cand = 4'(k - 1);",
     "fixed lowest-source-first arbitration inside a severity (a tenant-triggered source starves the others)"),
    ("R10", RAS, "else if (sel_ack_i && sel_found)   rr_q <= sel_s;", "else if (1'b0)   rr_q <= sel_s;",
     "round-robin pointer never advances"),
    ("F13", FM, "wire clr_safe_eff = clr_safe_i && !lvl_fatal_i;", "wire clr_safe_eff = clr_safe_i;",
     "CLR_SAFE releases the safe state while a FATAL level condition persists"),
    ("F14", FM, "((eng_rst_done_i[p] && !eng_rst_o[p]) || clr_isol_i[p] ||", "((eng_rst_done_i[p]) || clr_isol_i[p] ||",
     "a done that was already high ends the isolation in the reset-request cycle"),
    ("G12", GATE, "if (flush_i)                out_q <= '0;", "if (1'b0)                out_q <= '0;",
     "a flush does not clear the outstanding count (a hung engine wedges the explicit-error path)"),
    ("G13", GATE, "wire       v_permit    = base_permit && !flush_i;", "wire       v_permit    = base_permit;",
     "a flush does not stop a held, permitted request"),
    ("G14", GATE, "wire [3:0] v_status    = (base_permit && flush_i) ? sf_albion_pkg::SF_ST_CANCELLED : base_status;", "wire [3:0] v_status    = base_status;",
     "a request cancelled by a flush is answered with status OKAY"),
    ("G15", GATE, "if (have_q && (flush_i || !dec_q) && !fwd && !loc_done) begin", "if (have_q && !dec_q && !fwd && !loc_done) begin",
     "the cancellation is not latched: the request reappears when the flush ends"),
    ("G16", GATE, "wire pass_rsp = t_rsp_valid_i && !out_zero && !flush_i;", "wire pass_rsp = t_rsp_valid_i && !out_zero;",
     "a target response is forwarded to the master during a flush"),
    ("S18", TOP, "wire tel_priv_ok = tel_priv_i && tel_priv_port &&", "wire tel_priv_ok = tel_priv_i &&",
     "privileged telemetry accepted on any port (ROOT label trusted on its own)"),
    ("S19", TOP, "= n_gen - 4'd1 + {3'd0, ev_i[sf_citadel_pkg::SF_CIT_SRC_ILLEGAL]};", "= n_gen - 4'd1;",
     "an external ILLEGAL pulse in the same cycle as an internal denial is not counted"),
    ("S20", TOP, "= n_dma - 4'd1 + {3'd0, ev_i[sf_citadel_pkg::SF_CIT_SRC_INVALID_DMA]};", "= n_dma - 4'd1;",
     "an external INVALID_DMA pulse in the same cycle as an internal denial is not counted"),
    ("B12", SB, "if (!rot_present_i && rot_seen_q) begin", "if (1'b0) begin",
     "a root of trust lost while waiting downgrades to ABSENT (opens with ALLOW_UNAUTH) instead of failing"),
    ("B13", SB, "parameter bit          ALLOW_UNAUTH = 1'b0,", "parameter bit          ALLOW_UNAUTH = 1'b1,",
     "the default of ALLOW_UNAUTH is fail-open"),
    ("B14", SB, "if (rot_present_i) rot_seen_q <= 1'b1;", "if (1'b0) rot_seen_q <= 1'b1;",
     "the 'root of trust was seen' flag is never set"),
]

FORMAL_ORDER = ["table_priv", "iso_aw5", "perm_aw16", "gate_ok", "gate_orphan", "fm_scope", "secboot", "crypto_key"]


def apply(m, outdir):
    mid, rel, old, new, desc = m
    src = open(os.path.join(ROOT, rel)).read()
    n = src.count(old)
    if n == 0:
        return None, "PATTERN NOT FOUND"
    if n > 1 and mid not in ("T13",):
        return None, "PATTERN NOT UNIQUE (%d)" % n
    mutated = src.replace(old, new, 1)
    if mutated == src:
        return None, "NO CHANGE"
    os.makedirs(outdir, exist_ok=True)
    path = os.path.join(outdir, os.path.basename(rel))
    open(path, "w").write(mutated)
    return path, ""



SYS_SRC = ["third_party/albion/sf_albion_pkg.sv", "rtl/albion/sf_citadel_pkg.sv", "rtl/albion/sf_citadel_domain_table.sv",
           "rtl/albion/sf_citadel_permission.sv", "rtl/albion/sf_citadel_ras.sv", "rtl/albion/sf_citadel_fault_manager.sv",
           "rtl/albion/sf_citadel_secboot.sv", "rtl/albion/sf_citadel_security.sv"]

SB_SRC = ["third_party/albion/sf_albion_pkg.sv", "rtl/albion/sf_citadel_pkg.sv", "rtl/albion/sf_citadel_secboot.sv"]
CR_SRC = ["third_party/albion/sf_albion_pkg.sv", "rtl/albion/sf_citadel_pkg.sv", "rtl/albion/sf_citadel_domain_table.sv",
          "rtl/albion/sf_citadel_crypto_adapter.sv", "third_party/secworks_sha256/sha256_k_constants.v",
          "third_party/secworks_sha256/sha256_w_mem.v", "third_party/secworks_sha256/sha256_core.v"]
BOOT_SRC = SYS_SRC
RAS_SRC = ["third_party/albion/sf_albion_pkg.sv", "rtl/albion/sf_citadel_pkg.sv", "rtl/albion/sf_citadel_ras.sv"]
VFLAGS = ["--binary", "--timing", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-WIDTH", "-Wno-UNUSED", "-Wno-DECLFILENAME",
          "-Wno-INITIALDLY", "-Wno-TIMESCALEMOD"]


def tb_kill(rel, mpath, outdir, tag, srcs, tb, top):
    """Build the testbench with the mutated file substituted; killed (-> tag) unless it prints ... PASS."""
    files = [mpath if r == rel else os.path.join(ROOT, r) for r in srcs] + [os.path.join(ROOT, tb)]
    bdir = os.path.join(outdir, "sim_" + tag)
    os.makedirs(bdir, exist_ok=True)
    p = subprocess.run(["verilator"] + VFLAGS + ["--top-module", top, "-Mdir", bdir, "-o", "sim"] + files, cwd=ROOT,
                       capture_output=True, text=True)
    if p.returncode != 0:
        return None, "mutant does not build under Verilator (%s)" % tag
    r = subprocess.run([os.path.join(bdir, "sim")], cwd=bdir, capture_output=True, text=True, timeout=900)
    res = [l for l in r.stdout.splitlines() if l.startswith("CITADEL_TB_RESULT")]
    if not res or " PASS" not in res[-1]:
        return tag, ""
    return None, ""

def sim_kill(mid, rel, mpath, outdir):
    rtl = ["third_party/albion/sf_albion_pkg.sv", "rtl/albion/sf_citadel_pkg.sv",
           "rtl/albion/sf_citadel_domain_table.sv", "rtl/albion/sf_citadel_permission.sv"]
    srcs = [mpath if r == rel else os.path.join(ROOT, r) for r in rtl] + [os.path.join(ROOT, "tests/citadel/unit/tb_citadel_vec.sv")]
    for cfg in ("def64_s1", "tiny8_s1", "odd16_s1"):
        vdir = os.path.join(ROOT, "build", "vec", cfg)
        if not os.path.isdir(vdir):
            return None, "vectors for %s missing" % cfg
        bdir = os.path.join(outdir, "sim_" + cfg)
        os.makedirs(bdir, exist_ok=True)
        cmd = ["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-WIDTH", "-Wno-UNUSED",
               "-Wno-DECLFILENAME", "-Wno-INITIALDLY", "-Wno-TIMESCALEMOD", "--top-module", "tb_citadel_vec",
               "-Mdir", bdir, "-I" + vdir, "-o", "sim"] + srcs
        p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
        if p.returncode != 0:
            return None, "mutant does not build under Verilator"
        r = subprocess.run([os.path.join(bdir, "sim")], cwd=vdir, capture_output=True, text=True, timeout=600)
        res = [l for l in r.stdout.splitlines() if l.startswith("CITADEL_TB_RESULT")]
        if not res or " PASS" not in res[-1]:
            return cfg, ""
    return None, ""


def run_mutant(m, jobs_by_name):
    mid, rel, old, new, desc = m
    outdir = os.path.join(ROOT, "build", "mut", mid)
    mpath, err = apply(m, outdir)
    if mpath is None:
        return dict(id=mid, desc=desc, result="ERROR", detail=err)
    overrides = {rel: mpath}
    for name in FORMAL_ORDER:
        job = jobs_by_name[name]
        if rel not in job["files"]:
            continue
        r = formal.run_job(job, os.path.join(outdir, "formal"), overrides, covers=False)
        if r.get("verdict") == "CEX" or r.get("detail", "").startswith("expected PROVED, got CEX"):
            return dict(id=mid, desc=desc, result="KILLED", by="formal:" + name)
        if r["status"] != "PASS" and "elaboration" in r.get("detail", ""):
            return dict(id=mid, desc=desc, result="ERROR", detail="mutant does not elaborate: " + r["detail"])
    if rel in ("rtl/albion/sf_citadel_domain_table.sv", "rtl/albion/sf_citadel_permission.sv"):
        cfg, err = sim_kill(mid, rel, mpath, outdir)
        if err:
            return dict(id=mid, desc=desc, result="ERROR", detail=err)
        if cfg:
            return dict(id=mid, desc=desc, result="KILLED", by="sim:" + cfg)
    if rel == "rtl/albion/sf_citadel_ras.sv":
        tag, err = tb_kill(rel, mpath, outdir, "ras_unit", RAS_SRC, "tests/citadel/unit/tb_citadel_ras.sv", "tb_citadel_ras")
        if err:
            return dict(id=mid, desc=desc, result="ERROR", detail=err)
        if tag:
            return dict(id=mid, desc=desc, result="KILLED", by="sim:ras_unit")
    if rel == "rtl/albion/sf_citadel_secboot.sv":
        tag, err = tb_kill(rel, mpath, outdir, "secboot_unit", SB_SRC, "tests/citadel/unit/tb_citadel_secboot.sv", "tb_citadel_secboot")
        if err:
            return dict(id=mid, desc=desc, result="ERROR", detail=err)
        if tag:
            return dict(id=mid, desc=desc, result="KILLED", by="sim:secboot_unit")
        tag, err = tb_kill(rel, mpath, outdir, "boot_top", SYS_SRC, "tests/citadel/system/tb_citadel_boot.sv", "tb_citadel_boot")
        if err:
            return dict(id=mid, desc=desc, result="ERROR", detail=err)
        if tag:
            return dict(id=mid, desc=desc, result="KILLED", by="sim:boot_top")
    if rel == "rtl/albion/sf_citadel_crypto_adapter.sv":
        tag, err = tb_kill(rel, mpath, outdir, "crypto", CR_SRC, "tests/citadel/system/tb_citadel_crypto.sv", "tb_citadel_crypto")
        if err:
            return dict(id=mid, desc=desc, result="ERROR", detail=err)
        if tag:
            return dict(id=mid, desc=desc, result="KILLED", by="sim:crypto")
    if rel in SYS_SRC:
        tag, err = tb_kill(rel, mpath, outdir, "system", SYS_SRC, "tests/citadel/system/tb_citadel_system.sv", "tb_citadel_system")
        if err:
            return dict(id=mid, desc=desc, result="ERROR", detail=err)
        if tag:
            return dict(id=mid, desc=desc, result="KILLED", by="sim:system")
    if rel == "rtl/albion/sf_citadel_security.sv":
        tag, err = tb_kill(rel, mpath, outdir, "boot_top", SYS_SRC, "tests/citadel/system/tb_citadel_boot.sv", "tb_citadel_boot")
        if err:
            return dict(id=mid, desc=desc, result="ERROR", detail=err)
        if tag:
            return dict(id=mid, desc=desc, result="KILLED", by="sim:boot_top")
    return dict(id=mid, desc=desc, result="SURVIVED")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--group", default="all")
    ap.add_argument("--id", action="append")
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--out", default=os.path.join(ROOT, "reports", "citadel", "mutation.json"))
    ap.add_argument("--merge", action="store_true", help="merge results into an existing --out file")
    a = ap.parse_args()
    jobs_by_name = {j["name"]: j for j in json.load(open(os.path.join(ROOT, "formal", "citadel", "jobs.json")))["jobs"]}
    sel = [m for m in MUTANTS if (not a.id or m[0] in a.id) and (a.group == "all" or m[0].startswith({"table": "T", "perm": "P", "fm": "F", "gate": "G", "ras": "R", "top": "S", "boot": "B", "crypto": "C"}.get(a.group, "?")))]
    results = []
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for r in ex.map(lambda m: run_mutant(m, jobs_by_name), sel):
            results.append(r)
            print("%-4s %-9s %-24s %s %s" % (r["id"], r["result"], r.get("by", ""), r["desc"], r.get("detail", "")), flush=True)
    if a.merge and os.path.exists(a.out):
        old = {r["id"]: r for r in json.load(open(a.out))}
        old.update({r["id"]: r for r in results})
        results = [old[k] for k in sorted(old)]
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    json.dump(results, open(a.out, "w"), indent=1)
    k = sum(r["result"] == "KILLED" for r in results)
    s = [r["id"] for r in results if r["result"] == "SURVIVED"]
    e = [r["id"] for r in results if r["result"] == "ERROR"]
    print("mutation: %d mutants, %d killed, survivors=%s, errors=%s" % (len(results), k, s, e))
    return 1 if (s or e) else 0


if __name__ == "__main__":
    sys.exit(main())
