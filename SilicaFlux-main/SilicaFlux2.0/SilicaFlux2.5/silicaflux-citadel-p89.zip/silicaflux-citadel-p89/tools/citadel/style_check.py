#!/usr/bin/env python3
"""Style / synthesizability-subset checker for the Citadel RTL (rules from docs/albion/NAMING_RULES.md).

  S01 file begins with a header comment block
  S02 `default_nettype none before the first module/package and `default_nettype wire at the end
  S03 one module or package per file, named like the file; modules are sf_citadel_<name> (the Citadel brief mandates this
      prefix; Albion's own rule S03 says sf_albion_<name> -- the ONLY deliberate deviation), packages end in _pkg
  S04 parameter / localparam / typedef-less constants are UPPER_SNAKE_CASE
  S05 every port name ends in _i / _o / _io / _ni / _no
  S06 no simulation constructs in RTL: initial, final, $display/$write/$finish/$random/$fatal/$stop, delays, force/release,
      assert/assume/cover (the single exception: $error inside a generate block named gen_param_check*)
  S07 no preprocessor other than `default_nettype
  S08 no `always @` (use always_ff / always_comb), no always_latch, no negative-edge clocks
  S09 no wildcard package import
  S10 file ends with a newline; no tab characters; no trailing whitespace
  S11 always_ff blocks use non-blocking assignments only (checked on the assignment operators at statement level)
Exit status 0 only if no rule fires.
"""
import glob
import os
import re
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def strip_comments(t):
    t = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), t, flags=re.S)
    return re.sub(r"//[^\n]*", "", t)


def check(path):
    errs = []
    raw = open(path).read()
    stem = os.path.basename(path)[:-3]
    lines = raw.split("\n")
    if not lines[0].startswith("// ====") and not lines[0].startswith("//"):
        errs.append("S01 no header comment")
    if not raw.endswith("\n"):
        errs.append("S10 no newline at end of file")
    if "\t" in raw:
        errs.append("S10 tab character")
    for i, l in enumerate(lines, 1):
        if l.rstrip() != l:
            errs.append("S10 trailing whitespace line %d" % i)
            break
    t = strip_comments(raw)
    first_decl = re.search(r"^\s*(module|package)\b", t, re.M)
    nn_none = t.find("`default_nettype none")
    nn_wire = t.rfind("`default_nettype wire")
    if nn_none < 0 or (first_decl and nn_none > first_decl.start()):
        errs.append("S02 `default_nettype none missing / after first declaration")
    if nn_wire < 0 or nn_wire < t.rfind("endmodule") and nn_wire < t.rfind("endpackage"):
        errs.append("S02 `default_nettype wire missing at end")
    decls = re.findall(r"^\s*(module|package)\s+(\w+)", t, re.M)
    if len(decls) != 1:
        errs.append("S03 %d module/package declarations (need exactly 1)" % len(decls))
    else:
        kind, name = decls[0]
        if name != stem:
            errs.append("S03 %s '%s' does not match file name" % (kind, name))
        if kind == "module" and not name.startswith("sf_citadel_"):
            errs.append("S03 module '%s' lacks the sf_citadel_ prefix" % name)
        if kind == "package" and not name.endswith("_pkg"):
            errs.append("S03 package '%s' does not end in _pkg" % name)
    for m in re.finditer(r"\b(parameter|localparam)\b(?:\s+(?:int unsigned|int|bit|logic\s*\[[^\]]*\]|string))?\s+(\w+)\s*=", t):
        if not re.fullmatch(r"[A-Z][A-Z0-9_]*", m.group(2)):
            errs.append("S04 constant '%s' not UPPER_SNAKE" % m.group(2))
    # ports: only inside the module header "( ... );" -- find ANSI port declarations
    hdr = re.search(r"\bmodule\b.*?\)\s*;", t, re.S)
    if hdr:
        body = hdr.group(0)
        # drop the parameter list "#( ... )"
        pm = re.search(r"#\s*\(", body)
        if pm:
            depth, i = 0, pm.end() - 1
            while i < len(body):
                depth += body[i] == "("
                depth -= body[i] == ")"
                i += 1
                if depth == 0:
                    break
            body = body[i:]
        for m in re.finditer(r"\b(input|output|inout)\b([^,;)]*?)(\w+)\s*(?=,|\)|$)", body, re.S):
            name = m.group(3)
            if not re.search(r"_(i|o|io|ni|no)$", name):
                errs.append("S05 port '%s' lacks _i/_o/_io/_ni/_no" % name)
    in_param_check = False
    for m in re.finditer(r"\b(initial|final)\b|\$(display|write|finish|random|fatal|stop|urandom)\b|(?<![\w`])#\s*\d|\b(force|release)\b|\b(assert|assume|cover)\b\s*(property)?\s*\(", t):
        errs.append("S06 simulation construct '%s'" % m.group(0).strip())
    for m in re.finditer(r"\$error", t):
        pre = t[: m.start()]
        gp = pre.rfind("gen_param_check")
        if gp < 0 or pre[gp:].count("end") > 1:
            errs.append("S06 $error outside gen_param_check")
    for m in re.finditer(r"`(\w+)", t):
        if m.group(1) not in ("default_nettype",):
            errs.append("S07 preprocessor directive `%s" % m.group(1))
    if re.search(r"\balways\s*@", t):
        errs.append("S08 'always @' (use always_ff / always_comb)")
    if re.search(r"\balways_latch\b|\bnegedge\s+clk", t):
        errs.append("S08 latch / negative-edge clock")
    if re.search(r"\bimport\s+\w+::\*", t):
        errs.append("S09 wildcard import")
    for m in re.finditer(r"\balways_ff\b", t):
        i = t.find("begin", m.end())
        if i < 0:
            continue
        depth, j = 0, i
        for tok in re.finditer(r"\b(begin|end)\b", t[i:]):
            depth += 1 if tok.group(1) == "begin" else -1
            if depth == 0:
                j = i + tok.end()
                break
        body = t[i:j]
        for a_ in re.finditer(r"(?<![<>=!])=(?![=])", re.sub(r"<=", "  ", body)):
            ctx = body[max(0, a_.start() - 40): a_.start() + 10].replace("\n", " ")
            if re.search(r"\bfor\s*\(", ctx) or re.search(r"\bint\b|\blogic\b", ctx):
                continue                        # loop header / local declaration, not a register assignment
            errs.append("S11 blocking assignment in always_ff near: ..." + ctx.strip()[-30:])
            break
    return errs


def main():
    files = sorted(glob.glob(os.path.join(ROOT, "rtl", "albion", "sf_citadel_*.sv")))
    bad = 0
    for f in files:
        e = check(f)
        print("style: %-34s %s" % (os.path.basename(f), "ok" if not e else "; ".join(sorted(set(e))[:6])))
        bad += bool(e)
    print("style: %d file(s), %d with violations" % (len(files), bad))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
