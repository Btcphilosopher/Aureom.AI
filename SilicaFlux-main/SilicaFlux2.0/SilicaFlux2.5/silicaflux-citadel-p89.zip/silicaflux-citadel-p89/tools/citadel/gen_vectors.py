#!/usr/bin/env python3
"""Generate replay vectors (+ a SystemVerilog config include) for the Citadel permission/table testbench.

    gen_vectors.py --cfg def64|odd16|tiny8 --seed N --steps N --out DIR

Writes  DIR/tb_cfg.svh   (localparams the testbench includes)
        DIR/vectors.txt  (one record per line, hex tokens; format documented in tb_citadel_vec.sv)
        DIR/coverage.json (what was exercised; generation FAILS if any reason code / command status / opcode
                           was never reached, so the stimulus cannot silently go stale)

Expected values come from citadel_model.Model, an independent implementation of the specification.
"""
import argparse
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import citadel_model as M  # noqa: E402


def make_cfg(name):
    if name == "def64":
        p = M.default_params()
    elif name == "odd16":      # non-power-of-two counts, 16-bit addresses, 2 custom devices, LEN_W < AW
        p = M.Params(NDOM=3, NW=3, NP=3, NDEV=2, NQ=5, NKEY=3, AW=16, LEN_W=8,
                     DEV_BASE=[0x4000, 0x8000], DEV_MASK=[0xF000, 0xFF00], DEV_PRIV=[1, 0], DEV_SECURE=[0, 1])
    elif name == "tiny8":      # 8-bit addresses, LEN_W > AW (wide sum), single port, one device
        p = M.Params(NDOM=2, NW=2, NP=1, NDEV=1, NQ=2, NKEY=1, AW=8, LEN_W=10,
                     DEV_BASE=[0x80], DEV_MASK=[0xE0], DEV_PRIV=[0], DEV_SECURE=[0])
    else:
        raise SystemExit("unknown cfg " + name)
    return p


def hexw(v, bits):
    return "%x" % (v & ((1 << bits) - 1))


class Gen:
    def __init__(self, p, seed, dense=False):
        self.dense = dense
        self.p = p
        self.r = random.Random(seed)
        self.m = M.Model(p)
        self.lines = []
        self.cov_reason = set()
        self.cov_cs = set()
        self.cov_op = set()
        self.n_check = 0
        self.n_cmd = 0
        self.n_state = 0
        self.slot_w = max(1, (p.NDOM - 1).bit_length())
        self.win_w = max(1, (p.NW - 1).bit_length())
        self.port_w = max(1, (p.NP - 1).bit_length())
        self.src_w = self.port_w
        self.anchors = [self.r.getrandbits(p.AW) for _ in range(6)] + [0, p.full]

    # ------------------------------------------------------------------ emit
    def emit_reset(self):
        self.m.reset()
        self.lines.append("0")

    def emit_state(self):
        e = self.m.exports()
        p = self.p
        order = [("slot_state", 2 * p.NDOM), ("slot_id", 8 * p.NDOM), ("slot_priv", p.NDOM), ("slot_secure", p.NDOM),
                 ("win_valid", p.NDOM * p.NW), ("win_base", p.NDOM * p.NW * p.AW),
                 ("win_limit", p.NDOM * p.NW * p.AW), ("win_r", p.NDOM * p.NW), ("win_w", p.NDOM * p.NW),
                 ("win_x", p.NDOM * p.NW), ("win_excl", p.NDOM * p.NW), ("devrd", p.NDOM * p.NDEV),
                 ("devwr", p.NDOM * p.NDEV), ("qmask", p.NDOM * p.NQ), ("kmask", p.NDOM * p.NKEY),
                 ("bind", p.NP * p.NDOM), ("lock", 1), ("thresh", 16)]
        self.lines.append("2 " + " ".join(hexw(e[k], w) for k, w in order))
        self.n_state += 1
        assert self.m.exclusive_invariant_holds(), "model violated INV-EXCL: model bug"

    def emit_cmd(self, cfg_en, op, rdom, rpriv, slot, win, port, argdom, flags, d0, d1, qv=0, qs=0, valid=1):
        res = self.m.command(cfg_en, op if valid else None, rdom, rpriv, slot, win, port, argdom, flags, d0, d1, qv, qs)
        p = self.p
        thr = self.m.thresh
        self.lines.append("1 " + " ".join([
            hexw(valid, 1), hexw(cfg_en, 1), hexw(op, 4), hexw(rdom, 8), hexw(rpriv, 1),
            hexw(slot, self.slot_w), hexw(win, self.win_w), hexw(port, self.port_w), hexw(argdom, 8),
            hexw(flags, 8), hexw(d0, 64), hexw(d1, 64), hexw(qv, 1), hexw(qs, self.slot_w),
            # expected
            hexw(valid, 1), hexw(res.status if valid else 0, 4), hexw(res.deny if valid else 0, 1),
            hexw(res.clr_qhold, p.NQ), hexw(res.clr_isol, p.NP), hexw(res.clr_safe, 1), hexw(res.clr_cnt, 1),
            hexw(res.thresh_we, 1), hexw(thr, 16), hexw(res.zero_mask != 0, 1), hexw(res.zero_mask, p.NKEY),
            hexw(res.slot_clr, p.NDOM)]))
        if valid:
            self.cov_cs.add(res.status)
            self.cov_op.add(op)
        self.n_cmd += 1
        if self.dense:
            self.emit_state()      # debugging aid: compare the full table after EVERY command
        return res

    def emit_check(self, src, dom, op, attr, addr, ln, cls, idx, lockdown, dft, qhold, isol):
        p = self.p
        permit, reason, status, svld, slot = self.m.check(src, dom, op, attr, addr, ln, cls, idx, lockdown, dft,
                                                         qhold, isol)
        self.cov_reason.add(reason)
        f_ = self.m.find(dom)
        lf, ls = int(f_ is not None), (f_ or 0)
        o_ = self.m.owner_of(addr)
        of, os_ = int(o_ is not None), (o_ or 0)
        self.lines.append("3 " + " ".join([
            hexw(src, self.src_w), hexw(dom, 8), hexw(op, 4), hexw(attr, 8), hexw(addr, p.AW), hexw(ln, p.LEN_W),
            hexw(cls, 2), hexw(idx, 8), hexw(lockdown, 1), hexw(dft, 1), hexw(qhold, p.NQ), hexw(isol, p.NP),
            hexw(permit, 1), hexw(reason, 4), hexw(status, 4), hexw(svld, 1), hexw(slot, self.slot_w),
            hexw(lf, 1), hexw(ls, self.slot_w), hexw(of, 1), hexw(os_, self.slot_w)]))
        self.n_check += 1
        return reason

    # ------------------------------------------------------------------ random pieces
    def rand_dom(self):
        r, m = self.r, self.m
        pool = [s.id for s in m.slots if s.state != M.DS_INVALID]
        c = r.random()
        if pool and c < 0.55:
            return r.choice(pool)
        if c < 0.70:
            return r.choice([0, 1, 2, 3, 0x0F])
        if c < 0.88:
            return r.choice([0x10, 0x11, 0x12, 0x20, 0x7F, 0xFE])
        if c < 0.93:
            return 0xFF
        return r.getrandbits(8)

    def rand_window(self):
        p, r = self.p, self.r
        a = r.choice(self.anchors)
        base = (a + r.getrandbits(max(1, p.AW // 3))) & p.full
        size = r.choice([0, 1, 15, 255, r.getrandbits(max(1, p.AW // 2)), r.getrandbits(p.AW)])
        limit = min(p.full, base + size)
        if r.random() < 0.05:
            base, limit = limit, base          # inverted -> BAD_ARG
        return base, limit

    def rand_cmd(self):
        p, r, m = self.p, self.r, self.m
        op = r.choices(range(16), weights=[1, 14, 22, 5, 8, 8, 8, 12, 5, 6, 2, 3, 3, 2, 2, 2])[0]
        c = r.random()
        if c < 0.55:
            rdom, rpriv = 0, 1
        elif c < 0.85:
            rdom, rpriv = 1, 1
        elif c < 0.90:
            rdom, rpriv = r.choice([0, 1]), 0
        else:
            rdom, rpriv = r.choice([2, 0x10, 0x33, 0xFF, r.getrandbits(8)]), 1
        cfg_en = 0 if r.random() < 0.03 else 1
        slot = r.randrange(0, 1 << self.slot_w) if r.random() < 0.15 else r.randrange(0, p.NDOM)
        win = r.randrange(0, 1 << self.win_w)
        port = r.randrange(0, 1 << self.port_w)
        flags = r.getrandbits(8) if r.random() < 0.1 else r.getrandbits(4)
        d0 = d1 = 0
        argdom = self.rand_dom() if r.random() < 0.5 else r.choice([0x10, 0x11, 0x12, 0x13, 0x20, 0x21, 0x30, 0x00, 0x01, 0x02])
        if op == M.OP_SET_WINDOW:
            d0, d1 = self.rand_window()
            if r.random() < 0.03:
                d0 |= 1 << min(63, p.AW)       # does not fit AW (matters only for AW < 64)
        elif op == M.OP_SET_STATE:
            flags = r.choice([1, 2, 2, 2, 3, 0, 4])
        elif op == M.OP_ENROLL:
            flags = r.choice([0, 0, 0, 1, 2, 3, 4, 0x80])
        elif op == M.OP_SET_DEVPRM:
            d0, d1 = r.getrandbits(p.NDEV + (1 if r.random() < 0.05 else 0)), r.getrandbits(p.NDEV)
        elif op == M.OP_SET_QPRM:
            d0 = r.getrandbits(p.NQ + (1 if r.random() < 0.05 else 0))
        elif op == M.OP_SET_KEYPRM:
            d0 = r.getrandbits(p.NKEY + (1 if r.random() < 0.05 else 0))
        elif op == M.OP_BIND_PORT:
            d0 = r.getrandbits(p.NDOM + (1 if r.random() < 0.05 else 0))
        elif op == M.OP_CLR_QHOLD:
            d0 = r.getrandbits(p.NQ + (1 if r.random() < 0.05 else 0))
        elif op == M.OP_CLR_ISOL:
            d0 = r.getrandbits(p.NP + (1 if r.random() < 0.05 else 0))
        elif op == M.OP_SET_THRESH:
            d0 = r.getrandbits(16 + (1 if r.random() < 0.05 else 0))
        qv = 1 if r.random() < 0.04 else 0
        qs = r.randrange(0, 1 << self.slot_w)
        valid = 0 if (r.random() < 0.02 and not qv) else 1
        return cfg_en, op, rdom, rpriv, slot, win, port, argdom, flags, d0, d1, qv, qs, valid

    def rand_check(self):
        p, r, m = self.p, self.r, self.m
        src = r.randrange(0, 1 << self.src_w)
        dom = self.rand_dom()
        # prefer a bound (src, dom) pair most of the time
        if r.random() < 0.7:
            cands = [(sidx, s.id) for sidx, s in enumerate(m.slots)
                     if s.state != M.DS_INVALID and src < p.NP and (m.bind[src] >> sidx) & 1]
            if cands:
                dom = r.choice(cands)[1]
        c = r.random()
        op = r.choice([1, 2]) if c < 0.96 else r.choice([0, 3, 4, 7, 8, 15])
        attr = r.choice([0, 0, 0, 0x04, 0x08, 0x0C, 0x10, 0x14, 0x01, 0x02, 0x03, 0x80, 0x60]) if r.random() < 0.8 else r.getrandbits(8)
        cls = 0 if r.random() < 0.9 else r.choice([1, 1, 1, 2, 3])
        idx = r.randrange(0, p.NQ + 3) if r.random() < 0.95 else r.getrandbits(8)
        lockdown = int(r.random() < 0.05)
        dft = int(r.random() < 0.03)
        qhold = r.getrandbits(p.NQ) if r.random() < 0.2 else 0
        isol = r.getrandbits(p.NP) if r.random() < 0.06 else 0
        slot = m.find(dom)
        wins = [w for w in m.slots[slot].win if w.v] if slot is not None else []
        mode = r.random()
        if mode < 0.45 and wins:
            w = r.choice(wins)
            span = w.limit - w.base + 1
            ln = r.choice([1, 2, 16, 4096, span, span + 1, max(1, span // 2), r.getrandbits(p.LEN_W)]) or 1
            addr = r.choice([w.base - 1, w.base, w.base + 1, w.limit, w.limit + 1, w.limit - ln + 1, w.limit - ln + 2,
                             w.base + r.getrandbits(max(1, p.AW // 2))])
        elif mode < 0.60:
            i = r.randrange(p.NDEV)
            lo = p.DEV_BASE[i] & p.full
            hi = lo | (~p.DEV_MASK[i] & p.full)
            ln = r.choice([1, 4, 16, 64, hi - lo + 1, hi - lo + 2, 2 * (hi - lo + 1), r.getrandbits(p.LEN_W)]) or 1
            addr = r.choice([lo - 1, lo, lo + 4, hi, hi + 1, hi - ln + 1, hi - ln + 2, lo - ln + 1, lo - ln])
        elif mode < 0.70:
            k = r.randrange(0, 40)
            ln = r.choice([k, k + 1, k + 2, 1, r.getrandbits(p.LEN_W)]) or 1
            addr = p.full - k
        else:
            addr = r.getrandbits(p.AW)
            ln = r.choice([0, 1, 16, r.getrandbits(p.LEN_W), (1 << p.LEN_W) - 1, 1 << (p.LEN_W - 1)])
        addr &= p.full
        ln &= (1 << p.LEN_W) - 1
        return src, dom, op, attr, addr, ln, cls, idx, lockdown, dft, qhold, isol

    # ------------------------------------------------------------------ scenario
    def bootstrap(self):
        p, r = self.p, self.r
        # ROOT binds every port to a random slot set, always including slots 0..1 on port 0
        for port in range(p.NP):
            mask = r.getrandbits(p.NDOM) | (0b11 if port == 0 else 0) | (r.getrandbits(p.NDOM) if r.random() < 0.5 else 0)
            mask &= (1 << p.NDOM) - 1
            self.emit_cmd(1, M.OP_BIND_PORT, 0, 1, 0, 0, port, 0, 0, mask, 0)
        ids = [0x00, 0x01, 0x02, 0x10, 0x11, 0x12, 0x20, 0x7F]
        r.shuffle(ids)
        for slot in range(p.NDOM):
            did = ids[slot % len(ids)] if slot < len(ids) else 0x30 + slot
            flags = 3 if slot == 0 else r.choice([0, 0, 1, 2, 3])    # slot 0 always holds both capabilities
            self.emit_cmd(1, M.OP_ENROLL, 0, 1, slot, 0, 0, did, flags, 0, 0)
            for k in range(p.NW):
                if r.random() < 0.8:
                    b, l = self.rand_window()
                    self.emit_cmd(1, M.OP_SET_WINDOW, 0, 1, slot, k, 0, 0, r.getrandbits(4), b, l)
            self.emit_cmd(1, M.OP_SET_DEVPRM, 0, 1, slot, 0, 0, 0, 0, r.getrandbits(p.NDEV), r.getrandbits(p.NDEV))
            self.emit_cmd(1, M.OP_SET_QPRM, 0, 1, slot, 0, 0, 0, 0, r.getrandbits(p.NQ), 0)
            self.emit_cmd(1, M.OP_SET_KEYPRM, 0, 1, slot, 0, 0, 0, 0, r.getrandbits(p.NKEY), 0)
            self.emit_cmd(1, M.OP_SET_STATE, 0, 1, slot, 0, 0, 0, M.DS_ACTIVE if r.random() < 0.85 else M.DS_SUSPENDED, 0, 0)
        self.emit_state()

    def run(self, steps):
        r = self.r
        self.emit_reset()
        self.emit_state()                 # reset state: everything empty
        # right after reset every request is denied (default deny): sample a few
        for _ in range(8):
            self.emit_check(*self.rand_check())
        self.bootstrap()
        for i in range(steps):
            c = r.random()
            if c < 0.28:
                self.emit_cmd(*self.rand_cmd())
            elif c < 0.995:
                self.emit_check(*self.rand_check())
            else:
                self.emit_reset()
                self.emit_state()
                if r.random() < 0.7:
                    self.bootstrap()
            if i % 40 == 0:
                self.emit_state()
        self.directed_sweep()
        self.directed_quarantine_keys()
        self.emit_state()

    def directed_sweep(self):
        """Systematic device-permission / privilege sweep so every device right combination is exercised
        regardless of what the random phase happened to reach."""
        p, m = self.p, self.m
        full = (1 << p.NDEV) - 1
        # make sure a domain holding BOTH capabilities exists, is bound to a port and can be activated: pick a slot
        # that is bound somewhere and is empty or tenant-owned (a locked configuration cannot change system slots)
        def capable(s_i):
            s = m.slots[s_i]
            return s.state != M.DS_INVALID and s.priv and s.sec and any((m.bind[pt] >> s_i) & 1 for pt in range(p.NP))
        if not any(capable(i) for i in range(p.NDOM)):
            for i, s in enumerate(m.slots):
                if not any((m.bind[pt] >> i) & 1 for pt in range(p.NP)):
                    continue
                if s.state != M.DS_INVALID and not M.is_tenant(s.id):
                    continue
                if s.state != M.DS_INVALID:
                    self.emit_cmd(1, M.OP_REVOKE, 0, 1, i, 0, 0, 0, 0, 0, 0)
                self.emit_cmd(1, M.OP_ENROLL, 0, 1, i, 0, 0, 0x44, 3, 0, 0)
                break
        for slot, s in enumerate(m.slots):
            if s.state == M.DS_INVALID:
                continue
            ports = [pt for pt in range(p.NP) if (m.bind[pt] >> slot) & 1]
            if not ports:
                continue
            # ROOT forces ACTIVE (a quarantined slot needs ROOT to release; a locked system slot may refuse: fine)
            self.emit_cmd(1, M.OP_SET_STATE, 0, 1, slot, 0, 0, 0, M.DS_ACTIVE, 0, 0)
            for rd, wr in ((0, 0), (full, 0), (0, full), (full, full)):
                self.emit_cmd(1, M.OP_SET_DEVPRM, 0, 1, slot, 0, 0, 0, 0, rd, wr)
                for i in range(p.NDEV):
                    lo = p.DEV_BASE[i] & p.full
                    for op in (M.OP_READ, M.OP_WRITE):
                        for attr in (0x00, 0x0C, 0x04, 0x08):          # none / priv+secure / priv / secure
                            self.emit_check(ports[0], s.id, op, attr, lo, 1, 0, 0, 0, 0, 0, 0)

    def directed_quarantine_keys(self):
        """A quarantined tenant slot: MGMT can neither release it nor REVOKE it (REVOKE + re-ENROLL would release it);
        ROOT can.  And a key-permission SHRINK must request zeroisation of the removed key slots."""
        p, m = self.p, self.m
        kfull = (1 << p.NKEY) - 1
        for slot, s in enumerate(m.slots):
            if s.state == M.DS_INVALID or not M.is_tenant(s.id):
                continue
            self.emit_cmd(1, M.OP_SET_KEYPRM, 0, 1, slot, 0, 0, 0, 0, kfull, 0)         # all key slots
            self.emit_cmd(1, M.OP_SET_KEYPRM, 1, 1, slot, 0, 0, 0, 0, kfull >> 1, 0)    # MGMT shrinks: the top slot is zeroised
            self.emit_cmd(1, M.OP_SET_KEYPRM, 0, 1, slot, 0, 0, 0, 0, 0, 0)             # ROOT removes all
            self.emit_cmd(1, M.OP_SET_KEYPRM, 0, 1, slot, 0, 0, 0, 0, kfull, 0)
            self.emit_cmd(1, M.OP_SET_STATE, 0, 1, slot, 0, 0, 0, M.DS_QUARANTINED, 0, 0)
            self.emit_cmd(1, M.OP_REVOKE, 1, 1, slot, 0, 0, 0, 0, 0, 0)                 # MGMT: refused
            self.emit_cmd(1, M.OP_SET_STATE, 1, 1, slot, 0, 0, 0, M.DS_ACTIVE, 0, 0)    # MGMT: refused
            self.emit_cmd(1, M.OP_SET_STATE, 0, 1, slot, 0, 0, 0, M.DS_ACTIVE, 0, 0)    # ROOT releases
            break

    def finish(self, outdir, name):
        p = self.p
        os.makedirs(outdir, exist_ok=True)
        with open(os.path.join(outdir, "vectors.txt"), "w") as f:
            f.write("\n".join(self.lines) + "\n")
        missing_r = sorted(set(range(14)) - self.cov_reason)
        missing_c = sorted(set(range(10)) - self.cov_cs)
        missing_o = sorted(set(range(16)) - self.cov_op)
        cov = dict(cfg=name, checks=self.n_check, commands=self.n_cmd, state_compares=self.n_state,
                   reasons_hit=sorted(self.cov_reason), cmd_status_hit=sorted(self.cov_cs), ops_hit=sorted(self.cov_op),
                   reasons_missing=[M.REASON_NAMES[i] for i in missing_r],
                   cmd_status_missing=[M.CS_NAMES[i] for i in missing_c],
                   ops_missing=[M.OP_NAMES[i] for i in missing_o])
        with open(os.path.join(outdir, "coverage.json"), "w") as f:
            json.dump(cov, f, indent=1)
        vec = lambda xs, w: "{%s}" % ", ".join("%d'h%x" % (w, x & ((1 << w) - 1)) for x in reversed(xs))
        with open(os.path.join(outdir, "tb_cfg.svh"), "w") as f:
            f.write("// generated by gen_vectors.py (cfg %s) -- do not edit\n" % name)
            for k, v in (("NDOM", p.NDOM), ("NW", p.NW), ("NP", p.NP), ("NDEV", p.NDEV), ("NQ", p.NQ),
                         ("NKEY", p.NKEY), ("AW", p.AW), ("LEN_W", p.LEN_W)):
                f.write("localparam int unsigned %s = %d;\n" % (k, v))
            f.write("localparam logic [%d:0] DEV_BASE_C   = %s;\n" % (p.NDEV * p.AW - 1, vec(p.DEV_BASE, p.AW)))
            f.write("localparam logic [%d:0] DEV_MASK_C   = %s;\n" % (p.NDEV * p.AW - 1, vec(p.DEV_MASK, p.AW)))
            f.write("localparam logic [%d:0] DEV_PRIV_C   = %s;\n" % (p.NDEV - 1, vec(p.DEV_PRIV, 1)))
            f.write("localparam logic [%d:0] DEV_SECURE_C = %s;\n" % (p.NDEV - 1, vec(p.DEV_SECURE, 1)))
        return cov, missing_r, missing_c, missing_o


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", required=True)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--steps", type=int, default=6000)
    ap.add_argument("--out", required=True)
    ap.add_argument("--dense", action="store_true", help="state compare after every command (debug)")
    a = ap.parse_args()
    p = make_cfg(a.cfg)
    g = Gen(p, a.seed, a.dense)
    g.run(a.steps)
    cov, mr, mc, mo = g.finish(a.out, a.cfg)
    print("%s seed=%d: %d checks, %d commands, %d state compares; reasons %d/14, cmd-status %d/10, opcodes %d/16" % (
        a.cfg, a.seed, cov["checks"], cov["commands"], cov["state_compares"], len(cov["reasons_hit"]),
        len(cov["cmd_status_hit"]), len(cov["ops_hit"])))
    if mr or mc or mo:
        print("COVERAGE HOLE: reasons=%s cmd_status=%s ops=%s" % (cov["reasons_missing"], cov["cmd_status_missing"],
                                                                  cov["ops_missing"]))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
