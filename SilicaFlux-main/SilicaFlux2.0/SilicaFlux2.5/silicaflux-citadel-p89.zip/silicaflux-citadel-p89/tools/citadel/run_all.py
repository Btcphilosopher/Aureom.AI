#!/usr/bin/env python3
"""Citadel master regression.

    run_all.py [--quick] [--no-formal] [--mutants] [--seeds N] [--jobs N]

Stages (every stage must pass; nothing is skipped silently -- a stage that cannot run is reported as FAIL):
  lint     Verilator -Wall (fatal) on every module; Yosys 0.33 elaboration + `check -assert` (no latch / undriven / multi-driver)
  style    tools/citadel/style_check.py
  sim      pkg drift guard, RAS unit, secure-boot unit, system test (3 Verilator build variants), end-to-end gate test
           (random ALP traffic + memory model + hung-engine containment), boot integration, crypto adapter incl. the real SHA-256 core
  vec      replay of the Python model vectors (def64 / odd16 / tiny8 x seeds) against sf_citadel_domain_table + permission
  formal   all jobs of formal/citadel/jobs.json (ABC pdr unbounded proofs + cover witnesses)
  mutants  (--mutants) mutation campaign (tools/citadel/mutate.py)
Writes reports/citadel/SUMMARY.md and reports/citadel/regression.json.
"""
import argparse
import json
import os
import re
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
PKG = ["third_party/albion/sf_albion_pkg.sv", "rtl/albion/sf_citadel_pkg.sv"]
R = "rtl/albion/"
CORE = PKG + [R + "sf_citadel_domain_table.sv", R + "sf_citadel_permission.sv", R + "sf_citadel_ras.sv",
              R + "sf_citadel_fault_manager.sv", R + "sf_citadel_secboot.sv", R + "sf_citadel_security.sv"]
SHA = ["third_party/secworks_sha256/sha256_k_constants.v", "third_party/secworks_sha256/sha256_w_mem.v",
       "third_party/secworks_sha256/sha256_core.v"]
VF = ["--binary", "--timing", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-WIDTH", "-Wno-UNUSED", "-Wno-DECLFILENAME",
      "-Wno-INITIALDLY", "-Wno-TIMESCALEMOD", "-Wno-PINMISSING", "-Wno-LATCH", "-Wno-CASEINCOMPLETE", "-Wno-UNOPTFLAT"]
LINT_TOPS = {  # top module -> files it needs
    "sf_citadel_permission": PKG + [R + "sf_citadel_permission.sv"],
    "sf_citadel_domain_table": PKG + [R + "sf_citadel_domain_table.sv"],
    "sf_citadel_ras": PKG + [R + "sf_citadel_ras.sv"],
    "sf_citadel_fault_manager": PKG + [R + "sf_citadel_fault_manager.sv"],
    "sf_citadel_gate": PKG + [R + "sf_citadel_gate.sv"],
    "sf_citadel_secboot": PKG + [R + "sf_citadel_secboot.sv"],
    "sf_citadel_crypto_adapter": PKG + [R + "sf_citadel_crypto_adapter.sv"],
    "sf_citadel_security": CORE,
}
SIMS = [  # name, files, top, extra flags, variants
    ("pkg", ["third_party/albion/sf_albion_pkg.sv", "third_party/albion/sf_albion_memmap_pkg.sv", R + "sf_citadel_pkg.sv",
             "tests/citadel/unit/tb_citadel_pkg.sv"], "tb_citadel_pkg", [], [[]]),
    ("ras_unit", PKG + [R + "sf_citadel_ras.sv", "tests/citadel/unit/tb_citadel_ras.sv"], "tb_citadel_ras", [], [[]]),
    ("secboot_unit", PKG + [R + "sf_citadel_secboot.sv", "tests/citadel/unit/tb_citadel_secboot.sv"], "tb_citadel_secboot", [], [[]]),
    ("system", CORE + ["tests/citadel/system/tb_citadel_system.sv"], "tb_citadel_system", [], [[], ["-O0"], ["--public-flat-rw"]]),
    ("gate_e2e", CORE + [R + "sf_citadel_gate.sv", "tests/citadel/system/tb_citadel_gate.sv"], "tb_citadel_gate", [], [[]]),
    ("boot_top", CORE + ["tests/citadel/system/tb_citadel_boot.sv"], "tb_citadel_boot", [], [[]]),
    ("crypto", PKG + [R + "sf_citadel_domain_table.sv", R + "sf_citadel_crypto_adapter.sv"] + SHA +
     ["tests/citadel/system/tb_citadel_crypto.sv"], "tb_citadel_crypto", [], [[]]),
]


def run(cmd, log=None, cwd=ROOT, timeout=3600):
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        out, rc = p.stdout + p.stderr, p.returncode
    except subprocess.TimeoutExpired:
        out, rc = "TIMEOUT", 124
    if log:
        os.makedirs(os.path.dirname(log), exist_ok=True)
        open(log, "w").write(out)
    return rc, out


def tool_versions():
    v = {}
    for name, cmd in (("verilator", ["verilator", "--version"]), ("yosys", ["yosys", "-V"]), ("python", [sys.executable, "--version"])):
        v[name] = run(cmd)[1].strip().splitlines()[0] if run(cmd)[0] == 0 else "missing"
    return v


def stage_lint(jobs):
    res = []

    def one(item):
        top, files = item
        rc, out = run(["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "--top-module", top] + files, log="build/lint/v_%s.log" % top)
        ok_v = (rc == 0)
        ys = "read_verilog -sv %s; hierarchy -check -top %s; proc; flatten; opt_clean; check -assert" % (" ".join(files), top)
        rc2, out2 = run(["yosys", "-p", ys], log="build/lint/y_%s.log" % top)
        bad = re.findall(r"implicitly declared|has no driver|Latch inferred|^ERROR", out2, re.M)
        ok_y = (rc2 == 0 and not bad)
        return dict(name=top, ok=ok_v and ok_y, detail="verilator -Wall %s; yosys check %s" % ("clean" if ok_v else "WARNINGS", "clean" if ok_y else "PROBLEMS"))
    with ThreadPoolExecutor(max_workers=jobs) as ex:
        res = list(ex.map(one, LINT_TOPS.items()))
    # negative elaboration check: an out-of-range RST_HOLD (16-bit hold timer) must be refused, not silently truncated
    files = LINT_TOPS["sf_citadel_fault_manager"]
    rc, out = run(["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "-GRST_HOLD=65536", "--top-module", "sf_citadel_fault_manager"] + files)
    res.append(dict(name="fm_rst_hold_range (negative test)", ok=(rc != 0 and "RST_HOLD must be" in out),
                    detail="RST_HOLD = 65536 is refused at elaboration" if (rc != 0 and "RST_HOLD must be" in out) else "RST_HOLD = 65536 was ACCEPTED"))
    return res


def stage_style():
    rc, out = run([sys.executable, "-I", "tools/citadel/style_check.py"])
    return [dict(name="style_check", ok=(rc == 0), detail=out.strip().splitlines()[-1])]


def stage_sim(jobs):
    tasks = []
    for name, files, top, extra, variants in SIMS:
        for var in variants:
            tasks.append((name, files, top, var))

    def one(t):
        name, files, top, var = t
        tag = name + ("_" + "".join(var).replace("-", "") if var else "")
        bdir = os.path.join("build", "reg_" + tag)
        rc, out = run(["verilator"] + VF + var + ["--top-module", top, "-Mdir", bdir, "-o", "sim"] + files, log="build/reg_%s.build.log" % tag)
        if rc != 0:
            return dict(name=tag, ok=False, detail="build failed")
        rc, out = run([os.path.join(bdir, "sim")], log="build/reg_%s.run.log" % tag, cwd=ROOT, timeout=1800)
        res = [l for l in out.splitlines() if l.startswith("CITADEL_TB_RESULT")]
        ok = bool(res) and " PASS" in res[-1]
        return dict(name=tag, ok=ok, detail=(res[-1].replace("CITADEL_TB_RESULT ", "") if res else "no result line"))
    with ThreadPoolExecutor(max_workers=jobs) as ex:
        return list(ex.map(one, tasks))


def stage_vec(seeds, steps):
    rc, out = run([sys.executable, "-I", "tools/citadel/run_vec.py"] + sum([["--seed", str(s)] for s in range(1, seeds + 1)], []) +
                  ["--steps", str(steps)], log="build/reg_vec.log")
    res = []
    tot = dict(checks=0, commands=0, states=0)
    for l in out.splitlines():
        m = re.search(r"^(\S+)\s+seed=(\d+)\s+\S+\s+(PASS|FAIL)\s+(.*)", l)
        if m:
            res.append(dict(name="vec_%s_s%s" % (m.group(1), m.group(2)), ok=(m.group(3) == "PASS"), detail=m.group(4)[:100]))
            x = re.search(r"checks=(\d+) commands=(\d+) state_compares=(\d+)", l)
            if x:
                tot["checks"] += int(x.group(1)); tot["commands"] += int(x.group(2)); tot["states"] += int(x.group(3))
    res.append(dict(name="vec_total", ok=(rc == 0 and res != []), detail="%(checks)d permission checks, %(commands)d commands, %(states)d state compares" % tot))
    return res


def stage_formal(jobs):
    rc, out = run([sys.executable, "-I", "tools/citadel/formal.py", "--jobs", str(jobs)], log="build/reg_formal.log")
    summ = json.load(open(os.path.join(ROOT, "reports", "citadel", "formal_summary.json"))) if os.path.exists(os.path.join(ROOT, "reports", "citadel", "formal_summary.json")) else []
    res = []
    for r in summ:
        covers = [c for c in r["checks"][1:] if c.startswith("cover")]
        res.append(dict(name="formal_" + r["name"], ok=(r["status"] == "PASS"),
                        detail="%s; %d cover bins %s" % (r["checks"][0] if r["checks"] else r.get("detail", ""), len(covers),
                                                         "all reachable" if all("ok" in c for c in covers) else "PROBLEM")))
    if not res:
        res.append(dict(name="formal", ok=False, detail="no summary produced"))
    return res


def stage_mutants(jobs):
    rc, out = run([sys.executable, "-I", "tools/citadel/mutate.py", "--jobs", str(min(jobs, 3)), "--out", "reports/citadel/mutation.json"],
                  log="build/reg_mutants.log", timeout=14400)
    last = [l for l in out.splitlines() if l.startswith("mutation:")]
    return [dict(name="mutation_campaign", ok=(rc == 0), detail=last[-1] if last else "no result")]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--no-formal", action="store_true")
    ap.add_argument("--mutants", action="store_true")
    ap.add_argument("--seeds", type=int, default=0)
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    seeds = a.seeds or (2 if a.quick else 6)
    t0 = time.time()
    stages = []
    for name, fn in (("lint", lambda: stage_lint(a.jobs)), ("style", stage_style), ("sim", lambda: stage_sim(a.jobs)),
                     ("vec", lambda: stage_vec(seeds, 4000 if a.quick else 8000))):
        t = time.time()
        r = fn()
        stages.append((name, r, round(time.time() - t, 1)))
        print("%-8s %s  (%.0fs)" % (name, "PASS" if all(x["ok"] for x in r) else "FAIL", time.time() - t), flush=True)
        for x in r:
            if not x["ok"]:
                print("   FAIL", x["name"], x["detail"])
    if not a.no_formal:
        t = time.time(); r = stage_formal(a.jobs); stages.append(("formal", r, round(time.time() - t, 1)))
        print("%-8s %s  (%.0fs)" % ("formal", "PASS" if all(x["ok"] for x in r) else "FAIL", time.time() - t), flush=True)
        for x in r:
            if not x["ok"]:
                print("   FAIL", x["name"], x["detail"])
    if a.mutants:
        t = time.time(); r = stage_mutants(a.jobs); stages.append(("mutants", r, round(time.time() - t, 1)))
        print("%-8s %s  (%.0fs)" % ("mutants", "PASS" if all(x["ok"] for x in r) else "FAIL", time.time() - t), flush=True)
    allok = all(x["ok"] for _, r, _ in stages for x in r)
    os.makedirs(os.path.join(ROOT, "reports", "citadel"), exist_ok=True)
    json.dump(dict(tools=tool_versions(), seconds=round(time.time() - t0), ok=allok,
                   stages=[dict(stage=n, seconds=s, results=r) for n, r, s in stages]),
              open(os.path.join(ROOT, "reports", "citadel", "regression.json"), "w"), indent=1)
    with open(os.path.join(ROOT, "reports", "citadel", "SUMMARY.md"), "w") as f:
        f.write("# Citadel regression summary\n\nTools: %s\n\nOverall: **%s** (%.0f s)\n\n" % (
            ", ".join("%s %s" % kv for kv in tool_versions().items()), "PASS" if allok else "FAIL", time.time() - t0))
        for n, r, s in stages:
            f.write("## %s (%.0f s)\n\n| item | result | detail |\n|---|---|---|\n" % (n, s))
            for x in r:
                f.write("| %s | %s | %s |\n" % (x["name"], "PASS" if x["ok"] else "**FAIL**", x["detail"].replace("|", "/")))
            f.write("\n")
    print("regression:", "PASS" if allok else "FAIL")
    return 0 if allok else 1


if __name__ == "__main__":
    sys.exit(main())
