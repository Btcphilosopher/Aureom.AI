#!/usr/bin/env python3
"""Independent golden model of the Citadel domain table + permission checker.

Written from the decision-order specification in docs/citadel/02_PERMISSION_CHECKER.md and
03_DOMAIN_TABLE.md -- NOT transliterated from the RTL.  Python integers are unbounded, so address
arithmetic cannot wrap by accident: the model computes addr+len-1 exactly and compares with 2**AW.

Everything here is pure Python 3 (no third-party packages).
"""
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

# ---- code points (mirror sf_citadel_pkg / sf_albion_pkg; checked by tb_citadel_pkg) -------------
R_OK, R_BAD_OP, R_BAD_ATTR, R_BAD_DOM, R_BAD_LEN, R_OVERFLOW, R_DOM_STATE, R_NOMAP, R_PERM, R_DEV, \
    R_QUEUE, R_PRIV, R_LOCKDOWN, R_ISOLATED = range(14)
REASON_NAMES = ["OK", "BAD_OP", "BAD_ATTR", "BAD_DOM", "BAD_LEN", "OVERFLOW", "DOM_STATE", "NOMAP", "PERM",
                "DEV", "QUEUE", "PRIV", "LOCKDOWN", "ISOLATED"]
DS_INVALID, DS_SUSPENDED, DS_ACTIVE, DS_QUARANTINED = range(4)
(OP_INVALID, OP_ENROLL, OP_SET_WINDOW, OP_CLR_WINDOW, OP_SET_DEVPRM, OP_SET_QPRM, OP_SET_KEYPRM, OP_SET_STATE,
 OP_REVOKE, OP_BIND_PORT, OP_LOCK, OP_CLR_QHOLD, OP_CLR_ISOL, OP_CLR_SAFE, OP_SET_THRESH, OP_CLR_CNT) = range(16)
(CS_OK, CS_BAD_CMD, CS_BAD_PRIV, CS_BAD_ARG, CS_BAD_SLOT, CS_EXISTS, CS_OVERLAP, CS_LOCKED, CS_BAD_STATE,
 CS_NOT_AUTH) = range(10)
CS_NAMES = ["OK", "BAD_CMD", "BAD_PRIV", "BAD_ARG", "BAD_SLOT", "EXISTS", "OVERLAP", "LOCKED", "BAD_STATE", "NOT_AUTH"]
OP_NAMES = ["INVALID", "ENROLL", "SET_WINDOW", "CLR_WINDOW", "SET_DEVPRM", "SET_QPRM", "SET_KEYPRM", "SET_STATE",
            "REVOKE", "BIND_PORT", "LOCK", "CLR_QHOLD", "CLR_ISOL", "CLR_SAFE", "SET_THRESH", "CLR_CNT"]
ST_OKAY, ST_ACCESS_DENIED, ST_BAD_OPCODE, ST_BAD_ATTR = 0, 2, 3, 6     # ALP status codes (sf_albion_pkg)
OP_READ, OP_WRITE = 1, 2
DOM_ROOT, DOM_MGMT, DOM_SYS_LAST, DOM_TEN_FIRST, DOM_TEN_LAST, DOM_INVALID = 0x00, 0x01, 0x0F, 0x10, 0xFE, 0xFF
CLS_ADDR, CLS_QUEUE = 0, 1


def is_tenant(d: int) -> bool:
    return DOM_TEN_FIRST <= d <= DOM_TEN_LAST


@dataclass
class Params:
    NDOM: int = 8
    NW: int = 4
    NP: int = 4
    NDEV: int = 7
    NQ: int = 16
    NKEY: int = 8
    AW: int = 64
    LEN_W: int = 32
    DEV_BASE: List[int] = field(default_factory=list)
    DEV_MASK: List[int] = field(default_factory=list)
    DEV_PRIV: List[int] = field(default_factory=list)
    DEV_SECURE: List[int] = field(default_factory=list)

    @property
    def full(self) -> int:
        return (1 << self.AW) - 1


DEFAULT_DEV_BASE = [0x100000000, 0x120000000, 0x130000000, 0x140000000, 0x150000000, 0x160000000, 0x170000000]
DEFAULT_DEV_MASK = [0xFFFFFFFFF0000000, 0xFFFFFFFFFFF00000, 0xFFFFFFFFFF000000, 0xFFFFFFFFFF000000,
                    0xFFFFFFFFF0000000, 0xFFFFFFFFFFF00000, 0xFFFFFFFFFFF00000]
DEFAULT_DEV_PRIV = [1, 1, 0, 0, 0, 1, 1]
DEFAULT_DEV_SECURE = [0, 0, 0, 0, 0, 1, 0]


def default_params() -> Params:
    return Params(DEV_BASE=list(DEFAULT_DEV_BASE), DEV_MASK=list(DEFAULT_DEV_MASK),
                  DEV_PRIV=list(DEFAULT_DEV_PRIV), DEV_SECURE=list(DEFAULT_DEV_SECURE))


@dataclass
class Window:
    v: int = 0
    base: int = 0
    limit: int = 0
    r: int = 0
    w: int = 0
    x: int = 0
    ex: int = 0


@dataclass
class Slot:
    state: int = DS_INVALID
    id: int = 0
    priv: int = 0
    sec: int = 0
    win: List[Window] = field(default_factory=list)
    devrd: int = 0
    devwr: int = 0
    qmask: int = 0
    kmask: int = 0


@dataclass
class CmdResult:
    status: int = CS_OK
    deny: int = 0
    clr_qhold: int = 0
    clr_isol: int = 0
    clr_safe: int = 0
    clr_cnt: int = 0
    thresh_we: int = 0
    zero_mask: int = 0
    slot_clr: int = 0


class Model:
    def __init__(self, p: Params):
        self.p = p
        self.reset()

    # ------------------------------------------------------------------ reset
    def reset(self):
        p = self.p
        self.slots = [Slot(win=[Window() for _ in range(p.NW)]) for _ in range(p.NDOM)]
        self.bind = [0] * p.NP
        self.lock = 0
        self.thresh = 0

    # ------------------------------------------------------------------ helpers
    def find(self, dom: int) -> Optional[int]:
        for i, s in enumerate(self.slots):
            if s.state != DS_INVALID and s.id == dom:
                return i
        return None

    def owner_of(self, addr: int) -> Optional[int]:
        for i, s in enumerate(self.slots):
            for w in s.win:
                if w.v and w.ex and w.base <= addr <= w.limit:
                    return i
        return None

    # ------------------------------------------------------------------ privileged command
    def command(self, cfg_en, op, rdom, rpriv, slot, win, port, argdom, flags, d0, d1,
                qtn_valid=0, qtn_slot=0) -> CmdResult:
        """One cycle: optional command (op is None for 'no command') plus the containment hook."""
        p = self.p
        res = CmdResult()
        we_revoke = -1
        we_enroll = -1
        # Containment is evaluated against the state at the START of the cycle: a fault attributed to a slot's
        # previous occupant must not quarantine a domain enrolled into that slot in this very cycle.
        pre_state = [s.state for s in self.slots]
        if op is not None:
            res.status = self._decide(cfg_en, op, rdom, rpriv, slot, win, port, argdom, flags, d0, d1)
            res.deny = int(res.status in (CS_NOT_AUTH, CS_BAD_PRIV, CS_LOCKED))
        ok = op is not None and res.status == CS_OK
        zero = 0
        if ok:
            s = self.slots[slot] if slot < p.NDOM else None
            if op == OP_ENROLL:
                s.state, s.id, s.priv, s.sec = DS_SUSPENDED, argdom, flags & 1, (flags >> 1) & 1
                we_enroll = slot
                res.slot_clr |= 1 << slot
            elif op == OP_SET_WINDOW:
                w = s.win[win]
                w.v, w.base, w.limit = 1, d0, d1
                w.r, w.w, w.x, w.ex = flags & 1, (flags >> 1) & 1, (flags >> 2) & 1, (flags >> 3) & 1
            elif op == OP_CLR_WINDOW:
                s.win[win] = Window()
            elif op == OP_SET_DEVPRM:
                s.devrd, s.devwr = d0 & ((1 << p.NDEV) - 1), d1 & ((1 << p.NDEV) - 1)
            elif op == OP_SET_QPRM:
                s.qmask = d0 & ((1 << p.NQ) - 1)
            elif op == OP_SET_KEYPRM:
                newk = d0 & ((1 << p.NKEY) - 1)
                zero |= s.kmask & ~newk          # key slots REMOVED from the domain are zeroised
                s.kmask = newk
            elif op == OP_SET_STATE:
                new = flags & 3
                if new == DS_QUARANTINED and s.state != DS_QUARANTINED:
                    zero |= s.kmask
                s.state = new
            elif op == OP_REVOKE:
                zero |= s.kmask
                self.slots[slot] = Slot(win=[Window() for _ in range(p.NW)])
                we_revoke = slot
                res.slot_clr |= 1 << slot
            elif op == OP_BIND_PORT:
                self.bind[port] = d0 & ((1 << p.NDOM) - 1)
            elif op == OP_LOCK:
                self.lock = 1
            elif op == OP_CLR_QHOLD:
                res.clr_qhold = d0 & ((1 << p.NQ) - 1)
            elif op == OP_CLR_ISOL:
                res.clr_isol = d0 & ((1 << p.NP) - 1)
            elif op == OP_CLR_SAFE:
                res.clr_safe = 1
            elif op == OP_CLR_CNT:
                res.clr_cnt = 1
            elif op == OP_SET_THRESH:
                res.thresh_we = 1
                self.thresh = d0 & 0xFFFF
        # containment hook (applied after the command; revoke of the same slot wins)
        if qtn_valid and qtn_slot < p.NDOM:
            q = self.slots[qtn_slot]
            if pre_state[qtn_slot] != DS_INVALID and we_revoke != qtn_slot:
                if pre_state[qtn_slot] != DS_QUARANTINED:
                    zero |= q.kmask            # the mask the slot holds AFTER this cycle's command
                q.state = DS_QUARANTINED       # containment wins over a same-cycle SET_STATE
        res.zero_mask = zero
        return res

    def _decide(self, cfg_en, op, rdom, rpriv, slot, win, port, argdom, flags, d0, d1) -> int:
        p = self.p
        req_root = rpriv and rdom == DOM_ROOT
        req_mgmt = rpriv and rdom == DOM_MGMT
        if not cfg_en:
            return CS_NOT_AUTH
        if not (req_root or req_mgmt):
            return CS_BAD_PRIV
        if op == OP_INVALID:
            return CS_BAD_CMD
        slot_oob = slot >= p.NDOM
        enrolled = (not slot_oob) and self.slots[slot].state != DS_INVALID
        tgt = self.slots[slot] if not slot_oob else None
        tgt_tenant = enrolled and is_tenant(tgt.id)
        tgt_system = enrolled and not is_tenant(tgt.id)

        def slot_cmd_gate(allow_quarantined=False):
            if not enrolled:
                return CS_BAD_SLOT
            if not req_root and not tgt_tenant:
                return CS_BAD_PRIV
            if self.lock and tgt_system:
                return CS_LOCKED
            return None

        if op == OP_ENROLL:
            if slot_oob:
                return CS_BAD_SLOT
            if not req_root and not (is_tenant(argdom) and not (flags & 1) and not (flags & 2)):
                return CS_BAD_PRIV
            if argdom == DOM_INVALID or (flags >> 2) != 0:
                return CS_BAD_ARG
            if self.lock and not is_tenant(argdom):
                return CS_LOCKED
            if self.slots[slot].state != DS_INVALID or self.find(argdom) is not None:
                return CS_EXISTS
            return CS_OK
        if op in (OP_SET_WINDOW, OP_CLR_WINDOW, OP_SET_DEVPRM, OP_SET_QPRM, OP_SET_KEYPRM):
            g = slot_cmd_gate()
            if g is not None:
                return g
            if tgt.state == DS_QUARANTINED:
                return CS_BAD_STATE
            if op == OP_SET_WINDOW:
                if win >= p.NW or (flags >> 4) != 0 or d0 >= (1 << p.AW) or d1 >= (1 << p.AW) or d0 > d1:
                    return CS_BAD_ARG
                new_ex = (flags >> 3) & 1
                if new_ex:
                    for i in range(p.NDEV):
                        m = p.DEV_MASK[i] & p.full
                        if m == 0:
                            continue
                        lo = p.DEV_BASE[i] & p.full
                        hi = lo | (~m & p.full)
                        if d0 <= hi and lo <= d1:
                            return CS_BAD_ARG        # exclusive windows may not touch a device region
                for j, s in enumerate(self.slots):
                    if j == slot:
                        continue
                    for w in s.win:
                        if w.v and (new_ex or w.ex) and d0 <= w.limit and w.base <= d1:
                            return CS_OVERLAP
            elif op == OP_CLR_WINDOW:
                if win >= p.NW:
                    return CS_BAD_ARG
            elif op == OP_SET_DEVPRM:
                if (d0 >> p.NDEV) or (d1 >> p.NDEV):
                    return CS_BAD_ARG
            elif op == OP_SET_QPRM:
                if d0 >> p.NQ:
                    return CS_BAD_ARG
            elif op == OP_SET_KEYPRM:
                if d0 >> p.NKEY:
                    return CS_BAD_ARG
            return CS_OK
        if op == OP_SET_STATE:
            g = slot_cmd_gate()
            if g is not None:
                return g
            new = flags & 3
            if new == DS_INVALID or (flags >> 2) != 0:
                return CS_BAD_ARG
            if tgt.state == DS_QUARANTINED and new != DS_QUARANTINED and not req_root:
                return CS_BAD_PRIV
            return CS_OK
        if op == OP_REVOKE:
            g = slot_cmd_gate()
            if g is not None:
                return g
            if tgt.state == DS_QUARANTINED and not req_root:
                return CS_BAD_PRIV                 # REVOKE + re-ENROLL would release a quarantine: ROOT only
            return CS_OK
        if op == OP_BIND_PORT:
            if not req_root:
                return CS_BAD_PRIV
            if self.lock:
                return CS_LOCKED
            if port >= p.NP:
                return CS_BAD_SLOT
            if d0 >> p.NDOM:
                return CS_BAD_ARG
            return CS_OK
        if op in (OP_LOCK, OP_CLR_SAFE, OP_CLR_CNT):
            return CS_OK if req_root else CS_BAD_PRIV
        if op == OP_CLR_QHOLD:
            return CS_BAD_ARG if (d0 >> p.NQ) else CS_OK
        if op == OP_CLR_ISOL:
            return CS_BAD_ARG if (d0 >> p.NP) else CS_OK
        if op == OP_SET_THRESH:
            if not req_root:
                return CS_BAD_PRIV
            return CS_BAD_ARG if (d0 >> 16) else CS_OK
        raise AssertionError("unreachable opcode %d" % op)

    # ------------------------------------------------------------------ permission check
    def check(self, src, dom, op, attr, addr, ln, cls, idx, lockdown, dft, qhold, isol
              ) -> Tuple[int, int, int, int, int]:
        """-> (permit, reason, status, slot_vld, slot)."""
        p = self.p
        slot = self.find(dom)
        bound = slot is not None and src < p.NP and ((self.bind[src] >> slot) & 1) == 1
        dom_ok = slot is not None and bound and dom != DOM_INVALID
        reason = self._reason(src, dom, op, attr, addr, ln, cls, idx, lockdown, dft, qhold, isol, slot, dom_ok)
        if reason == R_OK:
            status = ST_OKAY
        elif reason == R_BAD_OP:
            status = ST_BAD_OPCODE
        elif reason == R_BAD_ATTR:
            status = ST_BAD_ATTR
        else:
            status = ST_ACCESS_DENIED
        # slot output: RTL reports the first matching slot even if not bound; only slot_vld is meaningful
        return int(reason == R_OK), reason, status, int(dom_ok), (slot if slot is not None else 0)

    def _reason(self, src, dom, op, attr, addr, ln, cls, idx, lockdown, dft, qhold, isol, slot, dom_ok) -> int:
        p = self.p
        if src < p.NP and (isol >> src) & 1:
            return R_ISOLATED
        if dft:
            return R_LOCKDOWN
        if cls not in (CLS_ADDR, CLS_QUEUE):
            return R_BAD_ATTR
        if op not in (OP_READ, OP_WRITE):
            return R_BAD_OP
        a_priv, a_sec, a_instr = (attr >> 2) & 1, (attr >> 3) & 1, (attr >> 4) & 1
        if (attr >> 7) & 1 or (attr & 3) == 3 or (a_instr and op == OP_WRITE):
            return R_BAD_ATTR
        if not dom_ok:
            return R_BAD_DOM
        if lockdown and dom not in (DOM_ROOT, DOM_MGMT):
            return R_LOCKDOWN
        s = self.slots[slot]
        if s.state != DS_ACTIVE:
            return R_DOM_STATE
        if (a_priv and not s.priv) or (a_sec and not s.sec):
            return R_PRIV
        if cls == CLS_QUEUE:
            if idx < p.NQ and not ((qhold >> idx) & 1) and ((s.qmask >> idx) & 1):
                return R_OK
            return R_QUEUE
        if ln == 0:
            return R_BAD_LEN
        last = addr + ln - 1
        if last > p.full:
            return R_OVERFLOW
        ov = []
        for i in range(p.NDEV):
            m = p.DEV_MASK[i] & p.full
            if m == 0:
                continue
            lo = p.DEV_BASE[i] & p.full
            hi = lo | (~m & p.full)
            if addr <= hi and last >= lo:
                ov.append((i, addr >= lo and last <= hi))
        if ov:
            if len(ov) > 1 or not ov[0][1]:
                return R_NOMAP
            i = ov[0][0]
            if (p.DEV_PRIV[i] and not a_priv) or (p.DEV_SECURE[i] and not a_sec):
                return R_PRIV
            if a_instr:
                return R_PERM
            ok = (s.devrd >> i) & 1 if op == OP_READ else (s.devwr >> i) & 1
            return R_OK if ok else R_DEV
        contain = [w for w in s.win if w.v and w.base <= addr and last <= w.limit]
        if not contain:
            return R_NOMAP
        for w in contain:
            if (w.r if op == OP_READ else w.w) and (not a_instr or w.x):
                return R_OK
        return R_PERM

    # ------------------------------------------------------------------ exported state, packed like the RTL
    def exports(self):
        p = self.p

        def pack(vals, width):
            v = 0
            for i, x in enumerate(vals):
                v |= (x & ((1 << width) - 1)) << (i * width)
            return v
        S = self.slots
        wins = [(s, k) for s in range(p.NDOM) for k in range(p.NW)]
        return dict(
            slot_state=pack([s.state for s in S], 2), slot_id=pack([s.id for s in S], 8),
            slot_priv=pack([s.priv for s in S], 1), slot_secure=pack([s.sec for s in S], 1),
            win_valid=pack([S[s].win[k].v for s, k in wins], 1),
            win_base=pack([S[s].win[k].base for s, k in wins], p.AW),
            win_limit=pack([S[s].win[k].limit for s, k in wins], p.AW),
            win_r=pack([S[s].win[k].r for s, k in wins], 1), win_w=pack([S[s].win[k].w for s, k in wins], 1),
            win_x=pack([S[s].win[k].x for s, k in wins], 1), win_excl=pack([S[s].win[k].ex for s, k in wins], 1),
            devrd=pack([s.devrd for s in S], p.NDEV), devwr=pack([s.devwr for s in S], p.NDEV),
            qmask=pack([s.qmask for s in S], p.NQ), kmask=pack([s.kmask for s in S], p.NKEY),
            bind=pack(self.bind, p.NDOM), lock=self.lock, thresh=self.thresh)

    def exclusive_invariant_holds(self) -> bool:
        for i, a in enumerate(self.slots):
            for j, b in enumerate(self.slots):
                if i >= j:
                    continue
                for wa in a.win:
                    for wb in b.win:
                        if wa.v and wb.v and (wa.ex or wb.ex) and wa.base <= wb.limit and wb.base <= wa.limit:
                            return False
        return True
