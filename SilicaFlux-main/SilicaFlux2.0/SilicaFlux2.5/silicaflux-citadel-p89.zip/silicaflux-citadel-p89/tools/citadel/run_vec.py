#!/usr/bin/env python3
"""Build + run the permission/table replay testbench for one or more configs on Verilator and Icarus.

    run_vec.py [--cfg def64 --cfg odd16 ...] [--seed N] [--steps N] [--sim verilator --sim icarus]

Exit status 0 only if every (config, seed, simulator) prints CITADEL_TB_RESULT ... PASS.
"""
import argparse
import os
import subprocess
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
RTL = ["third_party/albion/sf_albion_pkg.sv", "rtl/albion/sf_citadel_pkg.sv",
       "rtl/albion/sf_citadel_domain_table.sv", "rtl/albion/sf_citadel_permission.sv"]
TB = "tests/citadel/unit/tb_citadel_vec.sv"


def sh(cmd, cwd, log):
    with open(log, "w") as f:
        return subprocess.run(cmd, cwd=cwd, stdout=f, stderr=subprocess.STDOUT, timeout=1800).returncode


def build(cfg, sim, vdir):
    bdir = os.path.join(ROOT, "build", "sim_%s_%s" % (sim, cfg))
    os.makedirs(bdir, exist_ok=True)
    srcs = [os.path.join(ROOT, f) for f in RTL + [TB]]
    if sim == "verilator":
        cmd = ["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-WIDTH", "-Wno-UNUSED",
               "-Wno-DECLFILENAME", "-Wno-INITIALDLY", "-Wno-TIMESCALEMOD", "--top-module", "tb_citadel_vec",
               "-Mdir", bdir, "-I" + vdir, "-o", "sim"] + srcs
        exe = [os.path.join(bdir, "sim")]
    else:
        cmd = ["iverilog", "-g2012", "-o", os.path.join(bdir, "sim.vvp"), "-I", vdir, "-s", "tb_citadel_vec"] + srcs
        exe = ["vvp", os.path.join(bdir, "sim.vvp")]
    if sh(cmd, ROOT, os.path.join(bdir, "build.log")) != 0:
        return None, "%s build failed (see %s/build.log)" % (sim, bdir)
    return exe, bdir


def gen(cfg, seed, steps):
    vdir = os.path.join(ROOT, "build", "vec", "%s_s%d" % (cfg, seed))
    rc = subprocess.run([sys.executable, "-I", os.path.join(ROOT, "tools/citadel/gen_vectors.py"), "--cfg", cfg,
                         "--seed", str(seed), "--steps", str(steps), "--out", vdir], capture_output=True, text=True)
    return vdir, rc.returncode, (rc.stdout.strip() + rc.stderr.strip())


def run_one(exe, bdir, vdir, seed):
    log = os.path.join(bdir, "run_s%d.log" % seed)
    sh(exe, vdir, log)
    out = open(log).read()
    res = [l for l in out.splitlines() if l.startswith("CITADEL_TB_RESULT")]
    ok = bool(res) and " PASS" in res[-1]
    detail = res[-1] if res else "no result line (see %s)" % log
    if not ok:
        detail += "\n" + "\n".join(l for l in out.splitlines() if l.startswith("MISMATCH"))[:2000]
    return ok, detail


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", action="append")
    ap.add_argument("--seed", type=int, action="append")
    ap.add_argument("--steps", type=int, default=6000)
    ap.add_argument("--sim", action="append", choices=["verilator", "icarus"])
    a = ap.parse_args()
    cfgs = a.cfg or ["def64", "odd16", "tiny8"]
    seeds = a.seed or [1]
    sims = a.sim or ["verilator"]      # Icarus 12 cannot parse the vendored Albion package (see docs/citadel/07_VERIFICATION.md)
    bad = 0
    tot = dict(checks=0, commands=0)
    for cfg in cfgs:
        for sim in sims:
            v0, rc, gl = gen(cfg, seeds[0], a.steps)
            if rc != 0:
                print("%-6s generation FAILED: %s" % (cfg, gl)); bad += 1; continue
            exe, bdir = build(cfg, sim, v0)
            if exe is None:
                print("%-6s %s" % (cfg, bdir)); bad += 1; continue
            for seed in seeds:
                vdir, rc, gl = gen(cfg, seed, a.steps)
                if rc != 0:
                    print("%-6s seed=%-3d generation FAILED: %s" % (cfg, seed, gl)); bad += 1; continue
                ok, detail = run_one(exe, bdir, vdir, seed)
                print("%-6s seed=%-3d %-9s %s  %s" % (cfg, seed, sim, "PASS" if ok else "FAIL", detail.replace("CITADEL_TB_RESULT tb_citadel_vec ", "")))
                bad += (not ok)
    print("run_vec: %d failure(s)" % bad)
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
