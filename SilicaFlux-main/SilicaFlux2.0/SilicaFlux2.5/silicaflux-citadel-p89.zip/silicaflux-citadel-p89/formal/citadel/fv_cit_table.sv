// =============================================================================
//  fv_cit_table.sv  --  privileged-configuration properties of
//                       sf_citadel_domain_table
// -----------------------------------------------------------------------------
//  One-step transition properties.  The wrapper snapshots the command that was
//  presented and the whole exported state in the previous cycle and checks what
//  the table did with it.  NO reset-state assumption is made: the properties
//  hold from EVERY state, reachable or not, hence for all time.
//
//  Proved:
//   T-REFUSED   a refused command (status != OK) changes NO state and emits NO
//               control pulse
//   T-IDLE      with no command and no containment, nothing changes
//   T-OKPRIV    status OK only for a privileged ROOT / MGMT requester with
//               cfg_en high and a valid opcode;  unprivileged -> BAD_PRIV,
//               cfg_en low -> NOT_AUTH,  opcode 0 -> BAD_CMD
//   T-MGMT      an accepted MGMT command never touches a system-domain slot,
//               the port bindings, the lock, the threshold, the safe-state or
//               counter-clear controls; never creates a capable domain; never
//               ends a quarantine (neither SET_STATE nor REVOKE-then-ENROLL)
//   T-LOCK      once locked: lock stays set, bindings and system slots are
//               frozen, no system slot can be created
//   T-POPULATE  a slot becomes populated only by an accepted ENROLL on it
//   T-CAPS      the priv / secure capabilities of a resident slot never change
//   T-RELEASE   a QUARANTINED slot leaves quarantine only by an accepted ROOT
//               SET_STATE or ROOT REVOKE on that slot
//   T-ZERO      REVOKE, entering QUARANTINED and a SET_KEYPRM that removes key
//               slots request zeroisation of the affected key slots
//   T-RESET     while reset is asserted, and in the cycle after it is
//               released, every register / response / control pulse reads
//               cleared  ("reset clears privileged in-flight control state")
//  COVER_IDX >= 0 selects reachability mode.
// =============================================================================
module fv_cit_table #(
  parameter NDOM  = 3,
  parameter NW    = 2,
  parameter NP    = 2,
  parameter NDEV  = 1,
  parameter NQ    = 2,
  parameter NKEY  = 2,
  parameter AW    = 6,
  parameter [NDEV*AW-1:0] DEV_BASE = 6'h20,
  parameter [NDEV*AW-1:0] DEV_MASK = 6'h38,
  parameter COVER_IDX = -1,
  localparam SLOT_W = (NDOM > 1) ? $clog2(NDOM) : 1,
  localparam WIN_W  = (NW   > 1) ? $clog2(NW)   : 1,
  localparam PORT_W = (NP   > 1) ? $clog2(NP)   : 1
) (
  input  wire                  clk_i,
  input  wire                  rst_ni,
  input  wire                  cfg_en_i,
  input  wire                  cmd_valid_i,
  input  wire [3:0]            cmd_op_i,
  input  wire [7:0]            cmd_dom_i,
  input  wire                  cmd_priv_i,
  input  wire [SLOT_W-1:0]     cmd_slot_i,
  input  wire [WIN_W-1:0]      cmd_win_i,
  input  wire [PORT_W-1:0]     cmd_port_i,
  input  wire [7:0]            cmd_arg_dom_i,
  input  wire [7:0]            cmd_flags_i,
  input  wire [63:0]           cmd_d0_i,
  input  wire [63:0]           cmd_d1_i,
  input  wire                  qtn_valid_i,
  input  wire [SLOT_W-1:0]     qtn_slot_i
);
  localparam PROVE = (COVER_IDX < 0);

  reg init_q = 1'b1;
  always @(posedge clk_i) init_q <= 1'b0;

  wire                    rsp_valid, cmd_deny, clr_safe, clr_cnt, thresh_we, zero_valid, own_found, look_found;
  wire [3:0]              rsp_status;
  wire [NQ-1:0]           clr_qhold;
  wire [NP-1:0]           clr_isol;
  wire [15:0]             thresh;
  wire [NKEY-1:0]         zero_mask;
  wire [NDOM-1:0]         slot_clr;
  wire [SLOT_W-1:0]       look_slot, own_slot;
  wire [NDOM*2-1:0]       slot_state;
  wire [NDOM*8-1:0]       slot_id;
  wire [NDOM-1:0]         slot_priv, slot_secure;
  wire [NDOM*NW-1:0]      win_valid, win_r, win_w, win_x, win_excl;
  wire [NDOM*NW*AW-1:0]   win_base, win_limit;
  wire [NDOM*NDEV-1:0]    devrd, devwr;
  wire [NDOM*NQ-1:0]      qmask;
  wire [NDOM*NKEY-1:0]    kmask;
  wire [NP*NDOM-1:0]      bindv;
  wire                    lockv;

  sf_citadel_domain_table #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(NDEV), .NQ(NQ), .NKEY(NKEY), .AW(AW),
                            .DEV_BASE(DEV_BASE), .DEV_MASK(DEV_MASK)) u_tbl (
    .clk_i(clk_i), .rst_ni(rst_ni), .cfg_en_i(cfg_en_i), .cmd_valid_i(cmd_valid_i), .cmd_op_i(cmd_op_i),
    .cmd_dom_i(cmd_dom_i), .cmd_priv_i(cmd_priv_i), .cmd_slot_i(cmd_slot_i), .cmd_win_i(cmd_win_i),
    .cmd_port_i(cmd_port_i), .cmd_arg_dom_i(cmd_arg_dom_i), .cmd_flags_i(cmd_flags_i), .cmd_data0_i(cmd_d0_i),
    .cmd_data1_i(cmd_d1_i), .rsp_valid_o(rsp_valid), .rsp_status_o(rsp_status), .cmd_deny_o(cmd_deny),
    .ctl_clr_qhold_o(clr_qhold), .ctl_clr_isol_o(clr_isol), .ctl_clr_safe_o(clr_safe), .ctl_clr_cnt_o(clr_cnt),
    .ctl_thresh_we_o(thresh_we), .ctl_thresh_o(thresh), .qtn_valid_i(qtn_valid_i), .qtn_slot_i(qtn_slot_i),
    .zero_valid_o(zero_valid), .zero_mask_o(zero_mask), .slot_clr_o(slot_clr),
    .look_dom_i(8'd0), .look_found_o(look_found), .look_slot_o(look_slot),
    .own_addr_i({AW{1'b0}}), .own_found_o(own_found), .own_slot_o(own_slot),
    .slot_state_o(slot_state), .slot_id_o(slot_id), .slot_priv_o(slot_priv), .slot_secure_o(slot_secure),
    .win_valid_o(win_valid), .win_base_o(win_base), .win_limit_o(win_limit), .win_r_o(win_r), .win_w_o(win_w),
    .win_x_o(win_x), .win_excl_o(win_excl), .devrd_o(devrd), .devwr_o(devwr), .qmask_o(qmask), .kmask_o(kmask),
    .bind_o(bindv), .lock_o(lockv));

  // ---- snapshot of the previous cycle -------------------------------------------------------------
  reg                    p_valid, p_cfg_en, p_priv, p_qtn, p_rstn, p_lock;
  reg [3:0]              p_op;
  reg [7:0]              p_dom, p_arg, p_flags;
  reg [SLOT_W-1:0]       p_slot;
  reg [NDOM*2-1:0]       p_state;
  reg [NDOM*8-1:0]       p_id;
  reg [NDOM-1:0]         p_priv_v, p_sec_v;
  reg [NDOM*NW-1:0]      p_wv, p_wr, p_ww, p_wx, p_wex;
  reg [NDOM*NW*AW-1:0]   p_wb, p_wl;
  reg [NDOM*NDEV-1:0]    p_devrd, p_devwr;
  reg [NDOM*NQ-1:0]      p_qmask;
  reg [NDOM*NKEY-1:0]    p_kmask;
  reg [NP*NDOM-1:0]      p_bind;
  reg [15:0]             p_thresh;
  always @(posedge clk_i) begin
    p_valid <= cmd_valid_i; p_cfg_en <= cfg_en_i; p_priv <= cmd_priv_i; p_qtn <= qtn_valid_i; p_rstn <= rst_ni;
    p_op <= cmd_op_i; p_dom <= cmd_dom_i; p_arg <= cmd_arg_dom_i; p_flags <= cmd_flags_i; p_slot <= cmd_slot_i;
    p_state <= slot_state; p_id <= slot_id; p_priv_v <= slot_priv; p_sec_v <= slot_secure;
    p_wv <= win_valid; p_wr <= win_r; p_ww <= win_w; p_wx <= win_x; p_wex <= win_excl;
    p_wb <= win_base; p_wl <= win_limit; p_devrd <= devrd; p_devwr <= devwr; p_qmask <= qmask; p_kmask <= kmask;
    p_bind <= bindv; p_lock <= lockv; p_thresh <= thresh;
  end

  wire step_ok  = !init_q && p_rstn && rst_ni;
  wire priv_ok  = p_priv && (p_dom == 8'd0 || p_dom == 8'd1);
  wire is_root  = p_priv && p_dom == 8'd0;
  wire accepted = p_valid && rsp_valid && (rsp_status == 4'd0);
  wire no_pulse = (clr_qhold == {NQ{1'b0}}) && (clr_isol == {NP{1'b0}}) && !clr_safe && !clr_cnt && !thresh_we &&
                  !zero_valid && (slot_clr == {NDOM{1'b0}});

  integer i, k;
  reg all_same, sys_same, new_ok, caps_same, quar_kept, zero_ok, pop_ok, rel_ok, clr_ok, rst_clear, sys_new_none;
  reg slot_same_i, was_sys;
  reg [NKEY-1:0] kn;
  always @(*) begin
    i = 0; k = 0; slot_same_i = 1'b0; was_sys = 1'b0; kn = {NKEY{1'b0}};
    all_same = (bindv == p_bind) && (lockv == p_lock) && (thresh == p_thresh);
    sys_same = 1'b1; new_ok = 1'b1; caps_same = 1'b1; quar_kept = 1'b1; zero_ok = 1'b1; pop_ok = 1'b1;
    rel_ok = 1'b1; clr_ok = 1'b1; sys_new_none = 1'b1;
    for (i = 0; i < NDOM; i = i + 1) begin
      slot_same_i = (slot_state[2*i +: 2] == p_state[2*i +: 2]) && (slot_id[8*i +: 8] == p_id[8*i +: 8]) &&
                    (slot_priv[i] == p_priv_v[i]) && (slot_secure[i] == p_sec_v[i]) &&
                    (devrd[i*NDEV +: NDEV] == p_devrd[i*NDEV +: NDEV]) && (devwr[i*NDEV +: NDEV] == p_devwr[i*NDEV +: NDEV]) &&
                    (qmask[i*NQ +: NQ] == p_qmask[i*NQ +: NQ]) && (kmask[i*NKEY +: NKEY] == p_kmask[i*NKEY +: NKEY]);
      for (k = 0; k < NW; k = k + 1)
        slot_same_i = slot_same_i && (win_valid[i*NW+k] == p_wv[i*NW+k]) && (win_r[i*NW+k] == p_wr[i*NW+k]) &&
                      (win_w[i*NW+k] == p_ww[i*NW+k]) && (win_x[i*NW+k] == p_wx[i*NW+k]) && (win_excl[i*NW+k] == p_wex[i*NW+k]) &&
                      (win_base[(i*NW+k)*AW +: AW] == p_wb[(i*NW+k)*AW +: AW]) &&
                      (win_limit[(i*NW+k)*AW +: AW] == p_wl[(i*NW+k)*AW +: AW]);
      all_same = all_same && slot_same_i;
      was_sys = (p_state[2*i +: 2] != 2'd0) && (p_id[8*i +: 8] <= 8'h0F);
      if (was_sys && !slot_same_i) sys_same = 1'b0;
      // newly populated slot: tenant id, no capability
      if (p_state[2*i +: 2] == 2'd0 && slot_state[2*i +: 2] != 2'd0) begin
        if (!(slot_id[8*i +: 8] >= 8'h10 && slot_id[8*i +: 8] <= 8'hFE) || slot_priv[i] || slot_secure[i]) new_ok = 1'b0;
        if (slot_id[8*i +: 8] <= 8'h0F) sys_new_none = 1'b0;
        if (!(accepted && p_op == 4'd1 && p_slot == i)) pop_ok = 1'b0;
      end
      // capabilities of a slot resident before and after
      if (p_state[2*i +: 2] != 2'd0 && slot_state[2*i +: 2] != 2'd0 &&
          (slot_priv[i] != p_priv_v[i] || slot_secure[i] != p_sec_v[i])) caps_same = 1'b0;
      // a quarantine ends -- by SET_STATE out of it, or by REVOKE (which would let the slot be re-enrolled fresh) -- only
      // by an accepted ROOT command on that slot
      if (p_state[2*i +: 2] == 2'd3 && slot_state[2*i +: 2] != 2'd3) begin
        quar_kept = 1'b0;
        if (!(accepted && is_root && (p_op == 4'd7 || p_op == 4'd8) && p_slot == i)) rel_ok = 1'b0;
      end
      // zeroisation on REVOKE (old mask) and on entering QUARANTINED (mask held afterwards)
      if (p_state[2*i +: 2] != 2'd0 && slot_state[2*i +: 2] == 2'd0)
        if ((zero_mask & p_kmask[i*NKEY +: NKEY]) != p_kmask[i*NKEY +: NKEY]) zero_ok = 1'b0;
      kn = kmask[i*NKEY +: NKEY];
      if (p_state[2*i +: 2] != 2'd0 && p_state[2*i +: 2] != 2'd3 && slot_state[2*i +: 2] == 2'd3)
        if ((zero_mask & kn) != kn) zero_ok = 1'b0;
      // a key slot REMOVED from a domain that stays enrolled (SET_KEYPRM shrink) is zeroised too
      if (p_state[2*i +: 2] != 2'd0 && slot_state[2*i +: 2] != 2'd0)
        if (((p_kmask[i*NKEY +: NKEY] & ~kn) & ~zero_mask) != {NKEY{1'b0}}) zero_ok = 1'b0;
      // slot_clr marks exactly the slots whose populated-ness changed
      if (slot_clr[i] != ((p_state[2*i +: 2] == 2'd0) != (slot_state[2*i +: 2] == 2'd0))) clr_ok = 1'b0;
    end
    rst_clear = (slot_state == {NDOM*2{1'b0}}) && (win_valid == {NDOM*NW{1'b0}}) && (bindv == {NP*NDOM{1'b0}}) &&
                !lockv && !rsp_valid && (rsp_status == 4'd0) && !cmd_deny && no_pulse && (thresh == 16'd0) &&
                (kmask == {NDOM*NKEY{1'b0}}) && (devrd == {NDOM*NDEV{1'b0}}) && (qmask == {NDOM*NQ{1'b0}});
  end

  always @(posedge clk_i) begin
    if (PROVE) begin
      if (step_ok) begin
        t_rsp_valid   : assert (rsp_valid == p_valid);
        t_noauth      : assert (!(p_valid && !p_cfg_en) || rsp_status == 4'd9);
        t_unpriv      : assert (!(p_valid && p_cfg_en && !priv_ok) || rsp_status == 4'd2);
        t_badcmd      : assert (!(p_valid && p_cfg_en && priv_ok && p_op == 4'd0) || rsp_status == 4'd1);
        t_okpriv      : assert (!accepted || (p_cfg_en && priv_ok && p_op != 4'd0));
        t_deny_pulse  : assert (!p_valid || (cmd_deny == (rsp_status == 4'd9 || rsp_status == 4'd2 || rsp_status == 4'd7)));
        t_refused     : assert (!(p_valid && rsp_status != 4'd0 && !p_qtn) || (all_same && no_pulse));
        t_idle        : assert (!(!p_valid && !p_qtn) || (all_same && no_pulse && !rsp_valid));
        t_mgmt        : assert (!(accepted && p_dom == 8'd1 && !p_qtn) ||
                                (sys_same && new_ok && caps_same && quar_kept && (bindv == p_bind) && (lockv == p_lock) &&
                                 !clr_safe && !clr_cnt && !thresh_we && (thresh == p_thresh)));
        t_lock        : assert (!(p_lock) || lockv);
        t_lock_frozen : assert (!(p_lock && !p_qtn) || ((bindv == p_bind) && sys_same && sys_new_none));
        t_populate    : assert (pop_ok);
        t_caps        : assert (caps_same);
        t_release     : assert (rel_ok);
        t_zero        : assert (zero_ok);
        t_slot_clr    : assert (clr_ok);
      end
      // reset: while asserted and in the cycle after release everything privileged reads cleared
      if (!init_q && !rst_ni)            t_reset_now   : assert (rst_clear);
      if (!init_q && !p_rstn && rst_ni)  t_reset_after : assert (rst_clear);
    end
  end

  // ---- cover bins ---------------------------------------------------------------------------------
  wire [11:0] cov_vec;
  assign cov_vec[0]  = step_ok && accepted && is_root && p_op == 4'd1;                 // ROOT enrols
  assign cov_vec[1]  = step_ok && accepted && p_dom == 8'd1 && p_op == 4'd2;           // MGMT sets a window
  assign cov_vec[2]  = step_ok && p_valid && p_dom == 8'd1 && rsp_status == 4'd2;      // MGMT refused
  assign cov_vec[3]  = step_ok && p_valid && rsp_status == 4'd7;                       // LOCKED
  assign cov_vec[4]  = step_ok && accepted && is_root && p_op == 4'd7 && (p_state[1:0] == 2'd3) && (slot_state[1:0] != 2'd3) && p_slot == 0;  // ROOT releases a quarantine
  assign cov_vec[5]  = step_ok && p_valid && rsp_status == 4'd5;                       // EXISTS
  assign cov_vec[6]  = step_ok && p_valid && rsp_status == 4'd6;                       // OVERLAP
  assign cov_vec[7]  = step_ok && p_valid && rsp_status == 4'd9;                       // NOT_AUTH
  assign cov_vec[8]  = step_ok && accepted && p_op == 4'd10;                           // LOCK accepted
  assign cov_vec[9]  = step_ok && zero_valid;                                          // zeroise requested
  assign cov_vec[10] = step_ok && p_valid && p_dom != 8'd0 && p_dom != 8'd1 && rsp_status == 4'd2;   // unprivileged refused
  assign cov_vec[11] = step_ok && p_valid && rsp_status == 4'd1;                       // invalid opcode refused
  always @(posedge clk_i) if (!PROVE) a_cover_probe: assert (!cov_vec[COVER_IDX]);
endmodule
