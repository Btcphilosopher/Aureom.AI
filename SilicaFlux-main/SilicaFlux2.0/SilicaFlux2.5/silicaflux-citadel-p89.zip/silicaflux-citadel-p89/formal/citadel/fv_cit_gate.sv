// =============================================================================
//  fv_cit_gate.sv  --  formal wrapper for sf_citadel_gate (the enforcement point)
// -----------------------------------------------------------------------------
//  The verdict (chk_permit_i / chk_status_i) is a FREE input that may change in
//  every cycle -- the proof therefore holds for any policy behaviour, including
//  a table update while a request is held.  The master, the target and the
//  response channel are free inputs obeying only the ALP handshake contract.
//
//  Environment assumptions (the ALP contract, ALP-REQ-02 / RSP-02):
//    A1  a request that is valid and not accepted stays valid with an unchanged
//        payload;
//    A2  (TGT_OK = 1) the target answers only requests it was given, one
//        response per request, and holds a response until it is accepted;
//    A3  chk_permit_i == (chk_status_i == OKAY): proved for the real checker
//        (fv_cit_perm: a_permit_iff, a_okay, a_explicit);
//    A4  reset is asserted in the first cycle.
//  With TGT_OK = 0 the target is unconstrained (it may answer unprompted); only
//  the orphan-response properties are asserted then.
//
//  Proved (unbounded):
//    G1  nothing is presented to the target unless the verdict taken in the FIRST
//        evaluation cycle of that request was PERMIT -- so a denied request never
//        reaches the destination (a denied write cannot update it);
//    G2  the presented request is bit-for-bit the accepted one;
//    G3  a denied request is answered with ONE explicit error response (status
//        != OKAY, tag echoed, data zero, last=1) and only after every request
//        forwarded earlier has been answered (response order);
//    G4  valid/payload stability on both outputs (ALP-REQ-02 / RSP-02);
//    G5  chk_commit_o fires exactly once per accepted request;
//    G6  outstanding_o equals (forwarded - answered) and never wraps;
//    G7  after reset: no request presented, no response, nothing outstanding;
//    G8  an orphan target response is never forwarded to the master;
//    G9  FLUSH (flush_i = port isolated / engine in reset): nothing is presented
//        and no target response is forwarded in a flush cycle, the outstanding
//        count is zero afterwards, and a held request that had not been
//        forwarded is answered with ONE explicit error (CANCELLED if it had been
//        permitted) -- never forwarded after the flush.  G4 stability holds
//        except across a flush (the downstream reset event, ALP-RST-02).
//  COVER_IDX >= 0 selects reachability mode.
// =============================================================================
module fv_cit_gate #(
  parameter OUT_W   = 3,
  parameter TGT_OK  = 1,
  parameter COVER_IDX = -1
) (
  input  wire         clk_i,
  input  wire         rst_ni,
  input  wire         m_req_valid_i,
  input  wire [235:0] m_req_i,
  input  wire         m_rsp_ready_i,
  input  wire         t_req_ready_i,
  input  wire         t_rsp_valid_i,
  input  wire [147:0] t_rsp_i,
  input  wire         flush_i,
  input  wire         chk_permit_i,
  input  wire [3:0]   chk_status_i
);
  localparam PROVE = (COVER_IDX < 0);

  wire         m_req_ready, m_rsp_valid, t_req_valid, t_rsp_ready, chk_valid, chk_commit, rsp_orphan;
  wire [147:0] m_rsp;
  wire [235:0] t_req;
  wire [7:0]   chk_dom, chk_attr, chk_idx;
  wire [3:0]   chk_op;
  wire [63:0]  chk_addr;
  wire [31:0]  chk_len;
  wire [1:0]   chk_cls;
  wire [OUT_W-1:0] outstanding;

  sf_citadel_gate #(.OUT_W(OUT_W)) dut (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .m_req_valid_i(m_req_valid_i), .m_req_ready_o(m_req_ready), .m_req_i(m_req_i),
    .m_rsp_valid_o(m_rsp_valid), .m_rsp_ready_i(m_rsp_ready_i), .m_rsp_o(m_rsp),
    .t_req_valid_o(t_req_valid), .t_req_ready_i(t_req_ready_i), .t_req_o(t_req),
    .t_rsp_valid_i(t_rsp_valid_i), .t_rsp_ready_o(t_rsp_ready), .t_rsp_i(t_rsp_i), .flush_i(flush_i),
    .chk_valid_o(chk_valid), .chk_dom_o(chk_dom), .chk_op_o(chk_op), .chk_attr_o(chk_attr), .chk_addr_o(chk_addr),
    .chk_len_o(chk_len), .chk_cls_o(chk_cls), .chk_idx_o(chk_idx), .chk_commit_o(chk_commit),
    .chk_permit_i(chk_permit_i), .chk_status_i(chk_status_i),
    .outstanding_o(outstanding), .rsp_orphan_o(rsp_orphan));

  reg init_q = 1'b1;
  always @(posedge clk_i) init_q <= 1'b0;
  always @(*) if (init_q) assume (!rst_ni);

  // ---- environment ----------------------------------------------------------------------------
  reg         p_rstn, p_mreq_valid, p_mreq_ready, p_treq_valid, p_treq_ready, p_mrsp_valid, p_mrsp_ready;
  reg         p_trsp_valid, p_trsp_ready, p_flush;
  reg [235:0] p_mreq, p_treq;
  reg [147:0] p_mrsp, p_trsp;
  always @(posedge clk_i) begin
    p_rstn <= rst_ni;
    p_mreq_valid <= m_req_valid_i; p_mreq_ready <= m_req_ready; p_mreq <= m_req_i;
    p_treq_valid <= t_req_valid; p_treq_ready <= t_req_ready_i; p_treq <= t_req;
    p_mrsp_valid <= m_rsp_valid; p_mrsp_ready <= m_rsp_ready_i; p_mrsp <= m_rsp;
    p_trsp_valid <= t_rsp_valid_i; p_trsp_ready <= t_rsp_ready; p_trsp <= t_rsp_i; p_flush <= flush_i;
  end
  wire step = !init_q && p_rstn && rst_ni;

  // reset clears the request / response state of the environment too: a held request is abandoned (ALP-RST-02)
  always @(*) if (!init_q && p_rstn && rst_ni) begin
    assume (!(p_mreq_valid && !p_mreq_ready) || (m_req_valid_i && m_req_i == p_mreq));            // A1
    if (TGT_OK != 0) assume (!(p_trsp_valid && !p_trsp_ready) || (t_rsp_valid_i && t_rsp_i == p_trsp));  // A2 hold
  end
  always @(*) assume (chk_permit_i == (chk_status_i == 4'd0));                                    // A3

  // reference counters of forwarded requests and target responses taken
  reg [OUT_W-1:0] fwd_n, rsp_n;
  wire fwd_hs = t_req_valid && t_req_ready_i;
  wire rsp_hs = t_rsp_valid_i && t_rsp_ready && (fwd_n != rsp_n);      // a response is taken only against an outstanding request
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin fwd_n <= {OUT_W{1'b0}}; rsp_n <= {OUT_W{1'b0}}; end
    else if (flush_i) begin fwd_n <= {OUT_W{1'b0}}; rsp_n <= {OUT_W{1'b0}}; end   // the flush abandons what was outstanding
    else begin
      if (fwd_hs) fwd_n <= fwd_n + 1'b1;
      if (rsp_hs) rsp_n <= rsp_n + 1'b1;
    end
  end
  // A2: a target only answers requests it was given
  always @(*) if (TGT_OK != 0) assume (!t_rsp_valid_i || (fwd_n != rsp_n));

  // accepted request capture
  reg [235:0] acc_q;
  reg         acc_v_q, commit_seen_q, first_permit_q;
  wire        accept = m_req_valid_i && m_req_ready;
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin acc_q <= 236'd0; acc_v_q <= 1'b0; commit_seen_q <= 1'b0; first_permit_q <= 1'b0; end
    else begin
      if (chk_commit) begin commit_seen_q <= 1'b1; first_permit_q <= chk_permit_i; end
      if (accept) begin acc_q <= m_req_i; acc_v_q <= 1'b1; commit_seen_q <= 1'b0; end     // the NEW request's commit has not happened yet
    end
  end
  // held (accepted, neither forwarded nor answered yet) and cancelled-by-flush tracking
  reg held_q, canc_q;
  wire local_done = m_rsp_valid && (fwd_n == rsp_n) && m_rsp_ready_i;
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin held_q <= 1'b0; canc_q <= 1'b0; end
    else begin
      if (fwd_hs || local_done) held_q <= 1'b0;
      if (flush_i && held_q && !fwd_hs) canc_q <= 1'b1;
      if (accept) begin held_q <= 1'b1; canc_q <= 1'b0; end
    end
  end
  wire cancel_now = canc_q || (flush_i && held_q);
  // the request currently held is acc_q once accepted; the first-cycle verdict is first_permit_q after commit
  wire [7:0] acc_tag  = acc_q[231:224];
  wire       acc_wr   = (acc_q[235:232] == 4'd2);
  reg [3:0] chk_status_latched;
  always @(posedge clk_i) if (chk_commit) chk_status_latched <= chk_status_i;
  wire [3:0] st_now = chk_commit ? chk_status_i : chk_status_latched;
  wire [147:0] exp_loc_now = {acc_tag, st_now, 8'b00000010 | {7'b0, acc_wr}, 128'd0};
  wire [147:0] exp_loc_cnc = {acc_tag, 4'd9, 8'b00000010 | {7'b0, acc_wr}, 128'd0};      // CANCELLED

  wire first_verdict = chk_commit ? chk_permit_i : first_permit_q;    // the verdict taken in the request's FIRST evaluation cycle
  wire local_rsp = m_rsp_valid && (fwd_n == rsp_n);          // a response while nothing is outstanding can only be the local error

  always @(posedge clk_i) begin
    if (PROVE && !init_q && rst_ni) begin
      // G1: presented only if the first-evaluation verdict was permit
      g1_first   : assert (!(t_req_valid && chk_commit) || chk_permit_i);
      g1_latched : assert (!(t_req_valid && !chk_commit) || first_permit_q);
      // G2: presented request == accepted request
      g2_payload : assert (!t_req_valid || t_req == acc_q);
      // G3: explicit error response for a denied request
      g3_err     : assert (!local_rsp || ((m_rsp == exp_loc_now && m_rsp[139:136] != 4'd0) || (cancel_now && m_rsp == exp_loc_cnc)));
      g3_denied  : assert (!local_rsp || !first_verdict || cancel_now);        // a local error answers only a DENIED (or flush-cancelled) request
      g3_order   : assert (!m_rsp_valid || (fwd_n == rsp_n) || t_rsp_valid_i);  // while requests are outstanding only target responses pass
      g3_pass    : assert (!(m_rsp_valid && (fwd_n != rsp_n)) || m_rsp == t_rsp_i);
      // G5: exactly one commit per accepted request
      g5_once    : assert (!(chk_commit && commit_seen_q && !accept));
      // G6: counter equals forwarded - answered
      g6_count   : assert (outstanding == fwd_n - rsp_n);
      // G8: orphan target response never forwarded
      g8_orphan  : assert (!(t_rsp_valid_i && (fwd_n == rsp_n) && m_rsp_valid) || m_rsp == exp_loc_now || m_rsp == exp_loc_cnc);
      // G9: a flush cycle presents nothing and forwards no target response; the count is cleared; a cancelled request is
      // never forwarded afterwards
      g9_quiet   : assert (!flush_i || !t_req_valid);
      g9_nopass  : assert (!flush_i || !(m_rsp_valid && (fwd_n != rsp_n)));
      g9_nofwd   : assert (!(canc_q && held_q) || !t_req_valid);
      g8_flag    : assert (!(t_rsp_valid_i && (fwd_n == rsp_n)) || rsp_orphan);
    end
    if (PROVE && step) begin
      // G4: stability
      g4_treq    : assert (!(p_treq_valid && !p_treq_ready && !flush_i) || (t_req_valid && t_req == p_treq));
      g4_mrsp    : assert (TGT_OK == 0 || !(p_mrsp_valid && !p_mrsp_ready && !flush_i) || (m_rsp_valid && m_rsp == p_mrsp));
      g9_clear   : assert (!p_flush || outstanding == {OUT_W{1'b0}});
    end
    // G7: reset state
    if (PROVE && !init_q && !rst_ni)
      g7_reset   : assert (!t_req_valid && !m_rsp_valid && outstanding == {OUT_W{1'b0}} && !chk_valid);
    if (PROVE && !init_q && !p_rstn && rst_ni)
      g7_after   : assert (!t_req_valid && !m_rsp_valid && outstanding == {OUT_W{1'b0}} && !chk_valid);
  end

  // ---- covers -----------------------------------------------------------------------------------------
  wire [9:0] cov_vec;
  assign cov_vec[0] = !init_q && fwd_hs;                                   // a request is forwarded
  assign cov_vec[1] = !init_q && local_rsp && m_rsp_ready_i;               // a local error response is delivered
  assign cov_vec[2] = !init_q && fwd_hs && chk_commit && rsp_hs;           // forward + response in one cycle
  assign cov_vec[3] = !init_q && (outstanding == {OUT_W{1'b1}});           // outstanding counter full
  assign cov_vec[4] = !init_q && chk_commit && !chk_permit_i && (fwd_n != rsp_n);   // denied while earlier requests are outstanding (ordering case)
  assign cov_vec[5] = !init_q && commit_seen_q && t_req_valid && !t_req_ready_i;     // permitted request waiting on a slow target
  assign cov_vec[6] = !init_q && rsp_orphan;                               // orphan response seen (TGT_OK = 0)
  assign cov_vec[7] = !init_q && t_req_valid && first_permit_q && !chk_permit_i;     // verdict flipped to deny while the request is presented
  assign cov_vec[8] = !init_q && flush_i && held_q && first_verdict && local_rsp;     // a permitted request is cancelled by a flush and answered
  assign cov_vec[9] = !init_q && flush_i && (fwd_n != rsp_n);                          // a flush abandons outstanding requests
  always @(posedge clk_i) if (!PROVE) a_cover_probe: assert (!cov_vec[COVER_IDX]);
endmodule
