// =============================================================================
//  fv_cit_crypto.sv  --  key-access permissions of sf_citadel_crypto_adapter
// -----------------------------------------------------------------------------
//  The domain table (state, ids, bindings, key masks), the safe-state / DFT
//  levels, the zeroise requests, the engine's capabilities and answers are FREE in
//  every cycle.  The requester obeys the request handshake; the engine answers only
//  commands it accepted.  An INDEPENDENT model of the permission rule and of the
//  slot-block flags (set on a zeroise request, cleared by the engine's confirmation,
//  set wins) is compared with the RTL.
//
//  Proved (unbounded):
//    K1  a command reaches the engine ONLY if it was permitted when accepted:
//        valid algorithm, domain existing + ACTIVE + BOUND to this port, no safe
//        state / DFT, the engine implements the algorithm, and -- for a keyed
//        algorithm -- the slot exists, the domain holds the permission for it and
//        the slot is not blocked (and not being wiped this very cycle)
//    K2  the command carries exactly the accepted algorithm / key slot / domain / context
//    K3  a refused request never touches the engine and is answered with an explicit
//        non-OK status
//    K4  OK is reported only for a permitted request whose key was not wiped between acceptance and
//        engine completion (a wipe after completion does not void a finished operation)
//    K5  exactly one response per accepted request
//    K6  every zeroise request becomes a one-cycle wipe pulse on exactly those slots
//    K7  key_block_o equals the model: a slot stays blocked until the engine confirms
//    K8  authentication failures are reported (once, for the right domain); a wipe the
//        engine cannot perform is reported (zero_unsupported_o)
//    K9  reset abandons the request and clears the blocks
//  COVER_IDX >= 0 selects reachability mode.
// =============================================================================
module fv_cit_crypto #(
  parameter NDOM = 2,
  parameter NP   = 2,
  parameter NKEY = 2,
  parameter CTX_W = 2,
  parameter SRC  = 1,
  parameter COVER_IDX = -1
) (
  input  wire                 clk_i,
  input  wire                 rst_ni,
  input  wire                 req_valid_i,
  input  wire [7:0]           req_dom_i,
  input  wire [3:0]           req_algo_i,
  input  wire [7:0]           req_key_i,
  input  wire [CTX_W-1:0]     req_ctx_i,
  input  wire                 rsp_ready_i,
  input  wire [NDOM*2-1:0]    slot_state_i,
  input  wire [NDOM*8-1:0]    slot_id_i,
  input  wire [NP*NDOM-1:0]   bind_i,
  input  wire [NDOM*NKEY-1:0] kmask_i,
  input  wire                 lockdown_i,
  input  wire                 dft_i,
  input  wire                 zero_valid_i,
  input  wire [NKEY-1:0]      zero_mask_i,
  input  wire                 zero_all_i,
  input  wire                 eng_ready_i,
  input  wire                 eng_done_i,
  input  wire [1:0]           eng_status_i,
  input  wire [15:0]          cap_algo_i,
  input  wire                 cap_zeroize_i,
  input  wire [NKEY-1:0]      key_zero_ack_i,
  input  wire [NKEY-1:0]      key_provision_i
);
  localparam PROVE = (COVER_IDX < 0);

  wire        req_ready, rsp_valid, eng_valid, auth_fail, zero_unsup;
  wire [3:0]  rsp_status, eng_algo;
  wire [CTX_W-1:0] rsp_ctx, eng_ctx;
  wire [7:0]  eng_key, eng_dom, auth_fail_dom;
  wire [NKEY-1:0] key_zero, key_block;

  sf_citadel_crypto_adapter #(.NDOM(NDOM), .NP(NP), .NKEY(NKEY), .CTX_W(CTX_W), .SRC(SRC)) dut (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .req_valid_i(req_valid_i), .req_ready_o(req_ready), .req_dom_i(req_dom_i), .req_algo_i(req_algo_i),
    .req_key_i(req_key_i), .req_ctx_i(req_ctx_i),
    .rsp_valid_o(rsp_valid), .rsp_ready_i(rsp_ready_i), .rsp_status_o(rsp_status), .rsp_ctx_o(rsp_ctx),
    .slot_state_i(slot_state_i), .slot_id_i(slot_id_i), .bind_i(bind_i), .kmask_i(kmask_i),
    .lockdown_i(lockdown_i), .dft_active_i(dft_i),
    .zero_valid_i(zero_valid_i), .zero_mask_i(zero_mask_i), .zero_all_i(zero_all_i),
    .eng_valid_o(eng_valid), .eng_ready_i(eng_ready_i), .eng_algo_o(eng_algo), .eng_key_o(eng_key), .eng_dom_o(eng_dom),
    .eng_ctx_o(eng_ctx), .eng_done_i(eng_done_i), .eng_status_i(eng_status_i), .cap_algo_i(cap_algo_i),
    .cap_zeroize_i(cap_zeroize_i), .key_zero_o(key_zero), .key_zero_ack_i(key_zero_ack_i), .key_provision_i(key_provision_i),
    .auth_fail_o(auth_fail), .auth_fail_dom_o(auth_fail_dom), .key_block_o(key_block), .zero_unsupported_o(zero_unsup));

  reg init_q = 1'b1;
  always @(posedge clk_i) init_q <= 1'b0;
  always @(*) if (init_q) assume (!rst_ni);

  // ---- environment ---------------------------------------------------------------------------------------------
  reg p_rstn, p_req_valid, p_req_ready; reg [7:0] p_dom, p_key; reg [3:0] p_algo; reg [CTX_W-1:0] p_ctx;
  always @(posedge clk_i) begin
    p_rstn <= rst_ni; p_req_valid <= req_valid_i; p_req_ready <= req_ready; p_dom <= req_dom_i; p_key <= req_key_i;
    p_algo <= req_algo_i; p_ctx <= req_ctx_i;
  end
  always @(*) if (!init_q && p_rstn && rst_ni && p_req_valid && !p_req_ready)
    assume (req_valid_i && req_dom_i == p_dom && req_algo_i == p_algo && req_key_i == p_key && req_ctx_i == p_ctx);   // A1: held until accepted
  // unique domain ids in the table (INV-UNIQ, proved for the real table in fv_cit_iso)
  integer a, b;
  reg uniq;
  always @(*) begin
    a = 0; b = 0; uniq = 1'b1;
    for (a = 0; a < NDOM; a = a + 1) for (b = a + 1; b < NDOM; b = b + 1)
      if (slot_state_i[2*a +: 2] != 2'd0 && slot_state_i[2*b +: 2] != 2'd0 && slot_id_i[8*a +: 8] == slot_id_i[8*b +: 8]) uniq = 1'b0;
    assume (uniq);
  end
  // A2: the engine answers only commands it accepted
  reg eng_busy_q;
  wire eng_acc = eng_valid && eng_ready_i;
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) eng_busy_q <= 1'b0;
    else begin if (eng_acc) eng_busy_q <= 1'b1; else if (eng_done_i) eng_busy_q <= 1'b0; end
  end
  always @(*) assume (!eng_done_i || eng_busy_q);

  // ---- independent model: slot blocks and the permission rule -----------------------------------------------------
  wire [NKEY-1:0] zero_now = (zero_valid_i ? zero_mask_i : {NKEY{1'b0}}) | (zero_all_i ? {NKEY{1'b1}} : {NKEY{1'b0}});
  reg [NKEY-1:0] zb_q;
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) zb_q <= {NKEY{1'b0}};
    else zb_q <= (zb_q & ~(key_zero_ack_i | key_provision_i)) | zero_now;
  end

  integer s, k;
  reg spec_ok, d_ok, k_ok, sup, needkey, algo_ok;
  always @(*) begin
    s = 0; k = 0;
    algo_ok = (req_algo_i != 4'd0) && (req_algo_i <= 4'd6);
    sup     = cap_algo_i[req_algo_i];
    needkey = (req_algo_i >= 4'd2);
    d_ok = 1'b0; k_ok = 1'b0;
    for (s = 0; s < NDOM; s = s + 1)
      if (slot_state_i[2*s +: 2] == 2'd2 && slot_id_i[8*s +: 8] == req_dom_i && req_dom_i != 8'hFF && bind_i[SRC*NDOM + s] && !dft_i &&
          !(lockdown_i && req_dom_i != 8'd0 && req_dom_i != 8'd1)) begin
        d_ok = 1'b1;
        for (k = 0; k < NKEY; k = k + 1)
          if (req_key_i == k && kmask_i[s*NKEY + k] && !zb_q[k] && !zero_now[k]) k_ok = 1'b1;
      end
    spec_ok = algo_ok && d_ok && sup && (!needkey || k_ok);
  end

  // ---- accepted-request capture ---------------------------------------------------------------------------------------
  wire accept = req_valid_i && req_ready;
  reg acc_ok_q; reg [7:0] acc_dom_q, acc_key_q; reg [3:0] acc_algo_q; reg [CTX_W-1:0] acc_ctx_q; reg acc_wiped_q; reg [1:0] acc_n, rsp_n;
  reg inflight_q;      // accepted but the engine has not completed it yet (the window in which a wipe voids the result)
  wire rsp_hs = rsp_valid && rsp_ready_i;
  wire acc_keyed = (acc_algo_q >= 4'd2);
  reg acc_zeroed;
  integer kk;
  always @(*) begin
    kk = 0; acc_zeroed = 1'b0;
    for (kk = 0; kk < NKEY; kk = kk + 1) if (zero_now[kk] && acc_key_q == kk) acc_zeroed = 1'b1;
  end
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin acc_ok_q <= 1'b0; acc_dom_q <= 8'd0; acc_key_q <= 8'd0; acc_algo_q <= 4'd0; acc_ctx_q <= {CTX_W{1'b0}};
                       acc_wiped_q <= 1'b0; acc_n <= 2'd0; rsp_n <= 2'd0; inflight_q <= 1'b0; end
    else begin
      if (accept) begin acc_ok_q <= spec_ok; acc_dom_q <= req_dom_i; acc_key_q <= req_key_i; acc_algo_q <= req_algo_i;
                        acc_ctx_q <= req_ctx_i; acc_wiped_q <= 1'b0; acc_n <= acc_n + 2'd1; inflight_q <= 1'b1; end
      else begin
        if (inflight_q && acc_zeroed) acc_wiped_q <= 1'b1;                      // a wipe between accept and engine-done (inclusive)
        if (eng_done_i) inflight_q <= 1'b0;
      end
      if (rsp_hs) rsp_n <= rsp_n + 2'd1;
    end
  end
  reg [NKEY-1:0] p_zero_now; reg p_unsup_cap_miss;
  always @(posedge clk_i) begin p_zero_now <= zero_now; end
  reg unsup_q;
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) unsup_q <= 1'b0; else if ((zero_now != {NKEY{1'b0}}) && !cap_zeroize_i) unsup_q <= 1'b1;
  end
  reg p_wait; reg [1:0] p_estat; reg [7:0] p_acc_dom;
  always @(posedge clk_i) begin p_wait <= eng_busy_q; p_estat <= eng_status_i; p_acc_dom <= acc_dom_q; end

  wire step = !init_q && p_rstn && rst_ni;
  always @(posedge clk_i) begin
    if (PROVE && !init_q && rst_ni) begin
      k1_perm    : assert (!eng_valid || acc_ok_q);
      k2_fields  : assert (!eng_valid || (eng_algo == acc_algo_q && eng_key == acc_key_q && eng_dom == acc_dom_q && eng_ctx == acc_ctx_q));
      k1_keyed   : assert (!(eng_valid && acc_keyed) || (acc_key_q < NKEY));
      k3_explicit: assert (!(rsp_valid && !acc_ok_q) || (rsp_status != 4'd0 && rsp_status != 4'd5 && rsp_status != 4'd6 && rsp_status != 4'd7));
      k3_none    : assert (!(rsp_valid && !acc_ok_q) || !eng_valid);
      k4_ok      : assert (!(rsp_valid && rsp_status == 4'd0) || (acc_ok_q && !(acc_keyed && (acc_wiped_q))));
      k5_one     : assert ((acc_n - rsp_n) <= 2'd1 && (!rsp_valid || (acc_n - rsp_n) == 2'd1));
      k5_ready   : assert (req_ready == (!rsp_valid && !eng_valid && !eng_busy_q && (acc_n == rsp_n)));
      k7_block   : assert (key_block == zb_q);
      k8_unsup   : assert (zero_unsup == unsup_q);
      k_ctx      : assert (!rsp_valid || rsp_ctx == acc_ctx_q);
    end
    if (PROVE && step) begin
      k6_zero    : assert (key_zero == p_zero_now);
      k8_auth    : assert (!auth_fail || (rsp_valid && rsp_status == 4'd6));      // an authentication failure is reported to the requester too
      k8_auth2   : assert (!auth_fail || auth_fail_dom == acc_dom_q);                // ... charged to the right domain
      k8_auth3   : assert (!(rsp_valid && rsp_status == 4'd6) || acc_ok_q);          // only a permitted request can fail authentication
    end
    if (PROVE && !init_q && !rst_ni)
      k9_reset   : assert (!eng_valid && !rsp_valid && key_block == {NKEY{1'b0}} && !auth_fail && !zero_unsup);
  end

  wire [7:0] cov_vec;
  assign cov_vec[0] = !init_q && eng_acc && acc_keyed;                            // a keyed command reaches the engine
  assign cov_vec[1] = !init_q && rsp_valid && rsp_status == 4'd6;                 // authentication failure reported
  assign cov_vec[2] = !init_q && rsp_valid && rsp_status == 4'd7;                 // key wiped in flight
  assign cov_vec[3] = !init_q && rsp_valid && rsp_status == 4'd8;                 // key blocked
  assign cov_vec[4] = !init_q && rsp_valid && rsp_status == 4'd4;                 // key permission denied
  assign cov_vec[5] = !init_q && rsp_valid && rsp_status == 4'd2;                 // algorithm unsupported
  assign cov_vec[6] = !init_q && step && key_zero != {NKEY{1'b0}};               // wipe pulse
  assign cov_vec[7] = !init_q && rsp_valid && rsp_status == 4'd0 && acc_keyed;    // success for a keyed operation
  always @(posedge clk_i) if (!PROVE) a_cover_probe: assert (!cov_vec[COVER_IDX]);
endmodule
