// =============================================================================
//  fv_cit_secboot.sv  --  fail-closed policy of sf_citadel_secboot
// -----------------------------------------------------------------------------
//  The external verdict (rot_present_i / boot_done_i / boot_ok_i / boot_err_i) is
//  FREE in every cycle.  Proved (unbounded):
//    SB1  privileged configuration / firmware-run open only in AUTH_OK (or in
//         ABSENT when ALLOW_UNAUTH, i.e. when no authenticated boot exists)
//    SB2  AUTH_OK is entered only from WAIT in a cycle with a root of trust present,
//         done, ok and error code 0 -- never from boot_ok alone
//    SB3  FAILED is sticky until reset: no later verdict re-opens anything
//    SB4  every entry into FAILED raises exactly one boot_fail_o pulse
//    SB5  AUTH_OK is left (fail closed) the cycle the attestation is withdrawn
//    SB6  a contradictory verdict (ok with an error code) fails closed
//    SB7  reset returns to WAIT with everything closed
//    SB8  ABSENT is entered only from reset: a root of trust that was seen and then lost fails closed, it never downgrades to ABSENT
//  This proves the POLICY around the verdict.  It proves nothing about whether the
//  verdict is truthful: that is the external verifier's property.
//  COVER_IDX >= 0 selects reachability mode.
// =============================================================================
module fv_cit_secboot #(
  parameter ALLOW_UNAUTH = 1,
  parameter BOOT_TIMEOUT = 4,
  parameter COVER_IDX = -1
) (
  input  wire        clk_i,
  input  wire        rst_ni,
  input  wire        rot_present_i,
  input  wire        boot_done_i,
  input  wire        boot_ok_i,
  input  wire [7:0]  boot_err_i
);
  localparam PROVE = (COVER_IDX < 0);
  wire [2:0] state;
  wire       cfg_open, fw_run, boot_fail, rot_active;
  wire [7:0] err;
  sf_citadel_secboot #(.ALLOW_UNAUTH(ALLOW_UNAUTH != 0), .BOOT_TIMEOUT(BOOT_TIMEOUT)) dut (
    .clk_i(clk_i), .rst_ni(rst_ni), .rot_present_i(rot_present_i), .boot_done_i(boot_done_i), .boot_ok_i(boot_ok_i),
    .boot_err_i(boot_err_i), .state_o(state), .cfg_open_o(cfg_open), .fw_run_ok_o(fw_run), .boot_fail_o(boot_fail),
    .err_o(err), .rot_active_o(rot_active));

  reg init_q = 1'b1;
  always @(posedge clk_i) init_q <= 1'b0;
  always @(*) if (init_q) assume (!rst_ni);

  reg [2:0] p_st; reg p_rot, p_done, p_ok, p_rstn; reg [7:0] p_err;
  always @(posedge clk_i) begin p_st <= state; p_rot <= rot_present_i; p_done <= boot_done_i; p_ok <= boot_ok_i; p_err <= boot_err_i; p_rstn <= rst_ni; end
  // shadow: rot_present_i has been high in some cycle since reset (same recurrence as the RTL's own flag, written independently)
  reg seen_b, p_seen;
  always @(posedge clk_i) begin
    if (!rst_ni) seen_b <= 1'b0; else if (rot_present_i) seen_b <= 1'b1;
    p_seen <= seen_b;
  end
  wire step = !init_q && p_rstn && rst_ni;
  localparam [2:0] S_ABSENT = 3'd0, S_WAIT = 3'd1, S_AUTH = 3'd2, S_FAILED = 3'd3;

  always @(posedge clk_i) begin
    if (PROVE && !init_q) begin
      sb1_open  : assert (cfg_open == ((state == S_AUTH) || (state == S_ABSENT && ALLOW_UNAUTH != 0)));
      sb1_run   : assert (fw_run == cfg_open);
      sb1_failed: assert (state != S_FAILED || (!cfg_open && !fw_run));
      sb_wait   : assert (state != S_WAIT || (!cfg_open && !fw_run));
      sb_active : assert (rot_active == (state == S_AUTH));
      sb_state  : assert (state <= S_FAILED);
    end
    if (PROVE && step) begin
      sb2_auth  : assert (!(state == S_AUTH && p_st != S_AUTH) || (p_st == S_WAIT && p_rot && p_done && p_ok && p_err == 8'd0));
      sb3_sticky: assert (p_st != S_FAILED || state == S_FAILED);
      sb4_pulse : assert (boot_fail == (state == S_FAILED && p_st != S_FAILED));
      sb5_lost  : assert (!(p_st == S_AUTH && !(p_ok && p_rot)) || state == S_FAILED);
      sb6_contra: assert (!(p_st == S_WAIT && p_rot && p_done && p_ok && p_err != 8'd0) || state == S_FAILED);
      sb6_notok : assert (!(p_st == S_WAIT && p_rot && p_done && !p_ok) || state == S_FAILED);
      sb7_okonly: assert (!(p_st == S_WAIT && p_rot && !p_done) || state != S_AUTH);
      sb_err    : assert (state != S_FAILED || err != 8'd0);
      // SB8: no downgrade -- once a root of trust has been seen, losing it while waiting is a FAILURE, never ABSENT
      sb8_lost  : assert (!(p_st == S_WAIT && !p_rot && p_seen) || state == S_FAILED);
    end
    if (PROVE && !init_q && rst_ni && p_rstn)
      sb8_nodown: assert (!(state == S_ABSENT && seen_b));
    if (PROVE && !init_q && !rst_ni)
      sb_reset  : assert (state == S_WAIT && !cfg_open && !fw_run && !boot_fail && err == 8'd0);
  end

  wire [5:0] cov_vec;
  assign cov_vec[0] = !init_q && state == S_AUTH;
  assign cov_vec[1] = !init_q && step && state == S_FAILED && p_st == S_WAIT && p_done;     // failure by verdict
  assign cov_vec[2] = !init_q && step && state == S_FAILED && p_st == S_WAIT && !p_done;    // failure by timeout
  assign cov_vec[3] = !init_q && state == S_ABSENT;
  assign cov_vec[4] = !init_q && step && p_st == S_AUTH && state == S_FAILED;               // attestation withdrawn
  assign cov_vec[5] = !init_q && step && state == S_FAILED && p_ok && p_done && p_rot;      // ok presented to a FAILED device: still closed
  always @(posedge clk_i) if (!PROVE) a_cover_probe: assert (!cov_vec[COVER_IDX]);
endmodule
