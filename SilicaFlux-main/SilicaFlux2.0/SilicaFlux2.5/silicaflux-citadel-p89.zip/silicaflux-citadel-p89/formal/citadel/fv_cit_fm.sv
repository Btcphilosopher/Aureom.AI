// =============================================================================
//  fv_cit_fm.sv  --  containment scoping of sf_citadel_fault_manager
// -----------------------------------------------------------------------------
//  The RAS is modelled as a FREE event source: in every cycle any source, any
//  attribution and any table lookup answer may appear (constrained only to be
//  well-formed: the severity matches the source's policy entry and slot numbers
//  are in range).  The privileged controls (clear queue hold / isolation / safe
//  state / report) and the engine "reset done" inputs are free too.
//
//  Proved (unbounded):
//    F-QTN     a quarantine request is raised ONLY for an event whose policy has the
//              QUARANTINE action AND that is attributed to a TENANT domain -- never
//              for an unattributed event and never for a system domain
//    F-SAFE    the safe state is entered exactly for a FATAL-policy event or an
//              uncorrectable event attributed to a SYSTEM domain; it is sticky until a
//              privileged clear, and a set in the same cycle wins over the clear
//    F-ENG     an engine reset pulse is exactly the one-hot engine of the event, only
//              for engine-type sources; that port (and only that port) becomes
//              isolated; isolation ends only on done / privileged clear / the optional
//              timeout (RST_HOLD)
//    F-QUEUE   queue holds only grow by the event's own queue (queue sources), the
//              attributed domain's queues, or everything in the safe state; they shrink
//              only through the privileged clear
//              an announced abort is always held (set wins over a simultaneous clear)
//    F-INERT   a corrected event changes nothing
//    F-RESET   reset clears every containment register
//  COVER_IDX >= 0 selects reachability mode.
// =============================================================================
module fv_cit_fm #(
  parameter NDOM = 2,
  parameter NP   = 2,
  parameter NQ   = 3,
  parameter AW   = 4,
  parameter RST_HOLD = 0,
  parameter COVER_IDX = -1,
  localparam SLOT_W = (NDOM > 1) ? $clog2(NDOM) : 1
) (
  input  wire                clk_i,
  input  wire                rst_ni,
  input  wire                sel_valid_i,
  input  wire [3:0]          sel_src_i,
  input  wire                sel_dom_vld_i,
  input  wire [7:0]          sel_dom_i,
  input  wire [7:0]          sel_idx_i,
  input  wire                sel_addr_vld_i,
  input  wire [AW-1:0]       sel_addr_i,
  input  wire                look_found_i,
  input  wire [SLOT_W-1:0]   look_slot_i,
  input  wire                own_found_i,
  input  wire [SLOT_W-1:0]   own_slot_i,
  input  wire [NDOM*8-1:0]   slot_id_i,
  input  wire [NDOM*NQ-1:0]  qmask_i,
  input  wire [NQ-1:0]       clr_qhold_i,
  input  wire [NP-1:0]       clr_isol_i,
  input  wire                clr_safe_i,
  input  wire                lvl_fatal_i,
  input  wire                clr_rep_i,
  input  wire [NP-1:0]       eng_rst_done_i
);
  localparam PROVE = (COVER_IDX < 0);
  localparam [127:0] POLICY = sf_citadel_pkg::SF_CIT_POLICY;

  reg init_q = 1'b1;
  always @(posedge clk_i) init_q <= 1'b0;
  always @(*) if (init_q) assume (!rst_ni);

  // ---- environment: a well-formed event source -----------------------------------------------------------
  wire [1:0] sel_sev = POLICY[sel_src_i*8 + 5 +: 2];
  always @(*) begin
    assume (look_slot_i < NDOM);
    assume (own_slot_i  < NDOM);
  end

  wire        sel_ack, qtn_valid, abort_valid, safe_entry, zero_all, rst_evt, irq, last_valid, last_dom_vld;
  wire [7:0]  look_dom, last_dom, last_idx;
  wire [AW-1:0] own_addr;
  wire [SLOT_W-1:0] qtn_slot;
  wire [NQ-1:0] abort_mask, qhold;
  wire [NP-1:0] eng_rst, port_isol;
  wire        lockdown;
  wire [3:0]  last_src;
  wire [1:0]  last_sev, worst_sev;
  wire [4:0]  last_act;

  sf_citadel_fault_manager #(.NDOM(NDOM), .NP(NP), .NQ(NQ), .AW(AW), .RST_HOLD(RST_HOLD)) dut (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .sel_valid_i(sel_valid_i), .sel_src_i(sel_src_i), .sel_sev_i(sel_sev), .sel_dom_vld_i(sel_dom_vld_i), .sel_dom_i(sel_dom_i),
    .sel_idx_i(sel_idx_i), .sel_addr_vld_i(sel_addr_vld_i), .sel_addr_i(sel_addr_i), .sel_ack_o(sel_ack),
    .look_dom_o(look_dom), .look_found_i(look_found_i), .look_slot_i(look_slot_i),
    .own_addr_o(own_addr), .own_found_i(own_found_i), .own_slot_i(own_slot_i),
    .slot_id_i(slot_id_i), .qmask_i(qmask_i),
    .qtn_valid_o(qtn_valid), .qtn_slot_o(qtn_slot), .abort_valid_o(abort_valid), .abort_mask_o(abort_mask),
    .eng_rst_o(eng_rst), .qhold_o(qhold), .port_isol_o(port_isol), .lockdown_o(lockdown),
    .safe_entry_o(safe_entry), .zero_all_o(zero_all), .rst_evt_o(rst_evt),
    .clr_qhold_i(clr_qhold_i), .clr_isol_i(clr_isol_i), .clr_safe_i(clr_safe_i), .lvl_fatal_i(lvl_fatal_i), .clr_rep_i(clr_rep_i),
    .eng_rst_done_i(eng_rst_done_i),
    .irq_o(irq), .last_valid_o(last_valid), .last_src_o(last_src), .last_sev_o(last_sev),
    .last_dom_vld_o(last_dom_vld), .last_dom_o(last_dom), .last_idx_o(last_idx), .last_act_o(last_act),
    .worst_sev_o(worst_sev));

  // ---- independent expectation of what an event should do ----------------------------------------------------
  wire [4:0]        act       = POLICY[sel_src_i*8 +: 5];
  wire              attributed = sel_dom_vld_i ? look_found_i : (sel_addr_vld_i && own_found_i);
  wire [SLOT_W-1:0] aslot     = sel_dom_vld_i ? look_slot_i : own_slot_i;
  integer s;
  reg [7:0]    aid;
  reg [NQ-1:0] aq;
  always @(*) begin
    s = 0; aid = 8'd0; aq = {NQ{1'b0}};
    for (s = 0; s < NDOM; s = s + 1)
      if (aslot == s) begin aid = slot_id_i[s*8 +: 8]; aq = qmask_i[s*NQ +: NQ]; end
  end
  wire tenant     = attributed && aid >= 8'h10 && aid <= 8'hFE;
  wire system     = attributed && !tenant;
  wire queue_src  = (sel_src_i == 4'd4) || (sel_src_i == 4'd5) || (sel_src_i == 4'd14);
  wire [31:0] idx = {24'd0, sel_idx_i};
  wire exp_qtn    = sel_valid_i && act[3] && tenant;
  wire exp_safe   = sel_valid_i && (act[4] || (act[3] && system));
  wire exp_rst    = sel_valid_i && act[2] && !queue_src && (idx < NP);
  reg [NP-1:0] exp_rst_vec;
  reg [NQ-1:0] abort_ub;                                   // upper bound of what this event may hold
  integer p, q;
  always @(*) begin
    p = 0; q = 0;
    exp_rst_vec = {NP{1'b0}};
    abort_ub    = {NQ{1'b0}};
    for (p = 0; p < NP; p = p + 1) if (exp_rst && idx == p) exp_rst_vec[p] = 1'b1;
    if (sel_valid_i && act[1]) begin
      if (queue_src && idx < NQ) begin
        for (q = 0; q < NQ; q = q + 1) if (idx == q) abort_ub[q] = 1'b1;
      end
      if (attributed) abort_ub = abort_ub | aq;
    end
    if (exp_qtn)  abort_ub = abort_ub | aq;
    if (exp_safe) abort_ub = {NQ{1'b1}};
  end

  // ---- previous-cycle snapshot ----------------------------------------------------------------------------
  reg                p_rstn, p_valid, p_exp_safe, p_lock;
  reg [1:0]          p_sev;
  reg [NP-1:0]       p_exp_rst, p_isol, p_clr_isol, p_done;
  reg [NQ-1:0]       p_abort_ub, p_qhold, p_clr_qhold;
  reg                p_clr_safe, p_lvl;
  reg [NP-1:0]       p_eng_rst;
  always @(posedge clk_i) begin
    p_rstn <= rst_ni; p_valid <= sel_valid_i; p_sev <= sel_sev; p_exp_safe <= exp_safe; p_lock <= lockdown;
    p_exp_rst <= exp_rst_vec; p_isol <= port_isol; p_clr_isol <= clr_isol_i; p_done <= eng_rst_done_i;
    p_abort_ub <= abort_ub; p_qhold <= qhold; p_clr_qhold <= clr_qhold_i; p_clr_safe <= clr_safe_i; p_lvl <= lvl_fatal_i; p_eng_rst <= eng_rst;
  end
  wire step = !init_q && p_rstn && rst_ni;

  always @(posedge clk_i) begin
    if (PROVE && !init_q) begin
      f_ack     : assert (sel_ack == sel_valid_i);
      f_qtn     : assert (qtn_valid == exp_qtn);
      f_qtn_slot: assert (!qtn_valid || qtn_slot == aslot);
      f_qtn_un  : assert (!qtn_valid || attributed);                            // never an unattributed victim
      f_qtn_ten : assert (!qtn_valid || (aid >= 8'h10 && aid <= 8'hFE));       // never a system domain
      f_corr    : assert (!(sel_valid_i && sel_sev == 2'd0) || (!qtn_valid && act == 5'd0));   // corrected events trigger nothing
    end
    if (PROVE && step) begin
      f_safe    : assert (lockdown == (p_exp_safe || (p_lock && !(p_clr_safe && !p_lvl))));   // enter / sticky / set wins over clear / no release under a persisting FATAL level
      f_entry   : assert (safe_entry == (p_exp_safe && !p_lock));
      f_zero    : assert (zero_all == (p_exp_safe && !p_lock));
      f_eng     : assert (eng_rst == p_exp_rst);                                    // exactly the named engine
      f_eng_one : assert ((eng_rst & (eng_rst - 1'b1)) == {NP{1'b0}});             // at most one engine per cycle
      f_isol_up : assert (((~p_isol) & port_isol) == ((~p_isol) & p_exp_rst));      // a port becomes isolated only through its own reset request
      f_queue_hi: assert ((qhold & ~(p_qhold & ~p_clr_qhold)) == (qhold & ~(p_qhold & ~p_clr_qhold) & p_abort_ub));   // new holds only inside the bound
      f_queue_lo: assert (((p_qhold & ~p_clr_qhold) & ~qhold) == {NQ{1'b0}});       // a hold is never dropped except by the privileged clear
      f_abort   : assert ((abort_mask & ~p_abort_ub) == {NQ{1'b0}} && abort_valid == (p_abort_ub != {NQ{1'b0}}));
      f_queue_set: assert ((abort_mask & ~qhold) == {NQ{1'b0}});                      // an announced abort is HELD in the same cycle: set wins over a simultaneous clear
      f_inert   : assert (!(p_valid && p_sev == 2'd0) || (abort_valid == 1'b0 && eng_rst == {NP{1'b0}} && !safe_entry));
    end
    if (PROVE && step && RST_HOLD == 0) begin
      f_isol_dn : assert (((p_isol & ~port_isol) & ~(p_done | p_clr_isol)) == {NP{1'b0}});   // isolation ends only on done / privileged clear
      f_isol_pair: assert (((p_isol & ~port_isol) & p_eng_rst & ~p_clr_isol) == {NP{1'b0}});  // a done in the reset-request cycle does not end it
    end
    if (PROVE && !init_q && !rst_ni)
      f_reset   : assert (!lockdown && qhold == {NQ{1'b0}} && port_isol == {NP{1'b0}} && !irq && !abort_valid &&
                          eng_rst == {NP{1'b0}} && !safe_entry && !zero_all && !rst_evt && !last_valid && worst_sev == 2'd0);
    if (PROVE && !init_q && !p_rstn && rst_ni)
      f_reset2  : assert (!lockdown && qhold == {NQ{1'b0}} && port_isol == {NP{1'b0}} && !irq && !abort_valid &&
                          eng_rst == {NP{1'b0}} && !safe_entry && !zero_all && !rst_evt && !last_valid && worst_sev == 2'd0);
  end

  // ---- covers -------------------------------------------------------------------------------------------------
  wire [8:0] cov_vec;
  assign cov_vec[0] = !init_q && qtn_valid;                                  // a tenant is quarantined
  assign cov_vec[1] = !init_q && step && lockdown && !p_lock;                // the safe state is entered
  assign cov_vec[2] = !init_q && step && eng_rst != {NP{1'b0}};              // an engine reset is issued
  assign cov_vec[3] = !init_q && step && port_isol != {NP{1'b0}} && p_isol == {NP{1'b0}};    // a port becomes isolated
  assign cov_vec[4] = !init_q && step && abort_valid && abort_mask != {NQ{1'b1}};            // a PARTIAL queue abort
  assign cov_vec[5] = !init_q && sel_valid_i && sel_sev == 2'd2 && attributed && system;     // uncorrectable on a system domain
  assign cov_vec[6] = !init_q && sel_valid_i && sel_sev == 2'd2 && !attributed;              // uncorrectable, unattributed
  assign cov_vec[7] = !init_q && step && p_lock && lockdown && p_exp_safe && p_clr_safe;     // set wins over clear
  assign cov_vec[8] = !init_q && step && p_lock && lockdown && !p_exp_safe && p_clr_safe && p_lvl;   // CLR_SAFE refused under a persisting FATAL level
  always @(posedge clk_i) if (!PROVE) a_cover_probe: assert (!cov_vec[COVER_IDX]);
endmodule
