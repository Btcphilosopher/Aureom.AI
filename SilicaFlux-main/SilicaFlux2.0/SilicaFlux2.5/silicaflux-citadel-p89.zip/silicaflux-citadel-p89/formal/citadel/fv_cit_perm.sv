// =============================================================================
//  fv_cit_perm.sv  --  formal wrapper for sf_citadel_permission
// -----------------------------------------------------------------------------
//  The descriptor state, the request and the safety levels are ALL free inputs:
//  the proof covers every table state and every request, reachable or not.
//
//  Three independent formulations are compared with the RTL:
//   REF   priority-ordered reference.  Exact arithmetic (130-bit integers, so
//         address arithmetic cannot wrap), device regions as [lo, lo+size-1]
//         (the RTL uses base | ~mask), per-window loops.  Proves reason_o and
//         status_o are EXACTLY what the decision order of
//         docs/citadel/02_PERMISSION_CHECKER.md defines.
//   SPEC  priority-FREE predicate "permit iff there is a slot that ... ".  It
//         states what a permit MEANS without any ordering.  Needs the table
//         invariant INV-UNIQ (distinct non-empty slots have distinct ids; proved
//         for the real table in fv_cit_iso), so it is asserted as an
//         implication under that hypothesis.
//   CORO  named corollaries, one per invariant of the Citadel brief.
//
//  Assumptions: only parameter well-formedness (device bases aligned to their
//  masks, contiguous masks) -- chosen by the job file, not assumed in logic.
//  COVER_IDX >= 0 selects reachability mode: the wrapper then asserts that
//  cov_vec[COVER_IDX] is never true, so a counterexample is a witness.
// =============================================================================
module fv_cit_perm #(
  parameter NDOM  = 2,
  parameter NW    = 2,
  parameter NP    = 2,
  parameter NDEV  = 2,
  parameter NQ    = 3,
  parameter AW    = 16,
  parameter LEN_W = 8,
  parameter [NDEV*AW-1:0] DEV_BASE   = 32'h80004000,
  parameter [NDEV*AW-1:0] DEV_MASK   = 32'hFF00F000,
  parameter [NDEV-1:0]    DEV_PRIV   = 2'b01,
  parameter [NDEV-1:0]    DEV_SECURE = 2'b10,
  parameter COVER_IDX = -1,
  localparam SRC_W  = (NP   > 1) ? $clog2(NP)   : 1,
  localparam SLOT_W = (NDOM > 1) ? $clog2(NDOM) : 1
) (
  input  wire                    clk_i,
  input  wire [SRC_W-1:0]        src_i,
  input  wire [7:0]              dom_i,
  input  wire [3:0]              op_i,
  input  wire [7:0]              attr_i,
  input  wire [AW-1:0]           addr_i,
  input  wire [LEN_W-1:0]        len_i,
  input  wire [1:0]              cls_i,
  input  wire [7:0]              idx_i,
  input  wire                    lockdown_i,
  input  wire                    dft_i,
  input  wire [NQ-1:0]           qhold_i,
  input  wire [NP-1:0]           isol_i,
  input  wire [NDOM*2-1:0]       slot_state_i,
  input  wire [NDOM*8-1:0]       slot_id_i,
  input  wire [NDOM-1:0]         slot_priv_i,
  input  wire [NDOM-1:0]         slot_secure_i,
  input  wire [NDOM*NW-1:0]      win_valid_i,
  input  wire [NDOM*NW*AW-1:0]   win_base_i,
  input  wire [NDOM*NW*AW-1:0]   win_limit_i,
  input  wire [NDOM*NW-1:0]      win_r_i,
  input  wire [NDOM*NW-1:0]      win_w_i,
  input  wire [NDOM*NW-1:0]      win_x_i,
  input  wire [NDOM*NDEV-1:0]    devrd_i,
  input  wire [NDOM*NDEV-1:0]    devwr_i,
  input  wire [NDOM*NQ-1:0]      qmask_i,
  input  wire [NP*NDOM-1:0]      bind_i
);
  localparam PROVE = (COVER_IDX < 0);
  localparam [129:0] FULL = ({130{1'b1}} >> (130 - AW));

  wire             permit, slot_vld;
  wire [3:0]       reason, status;
  wire [SLOT_W-1:0] slot_o;

  sf_citadel_permission #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(NDEV), .NQ(NQ), .AW(AW), .LEN_W(LEN_W),
                          .DEV_BASE(DEV_BASE), .DEV_MASK(DEV_MASK), .DEV_PRIV(DEV_PRIV), .DEV_SECURE(DEV_SECURE)) dut (
    .src_i(src_i), .dom_i(dom_i), .op_i(op_i), .attr_i(attr_i), .addr_i(addr_i), .len_i(len_i), .cls_i(cls_i),
    .idx_i(idx_i), .lockdown_i(lockdown_i), .dft_active_i(dft_i), .qhold_i(qhold_i), .port_isol_i(isol_i),
    .slot_state_i(slot_state_i), .slot_id_i(slot_id_i), .slot_priv_i(slot_priv_i), .slot_secure_i(slot_secure_i),
    .win_valid_i(win_valid_i), .win_base_i(win_base_i), .win_limit_i(win_limit_i), .win_r_i(win_r_i),
    .win_w_i(win_w_i), .win_x_i(win_x_i), .devrd_i(devrd_i), .devwr_i(devwr_i), .qmask_i(qmask_i), .bind_i(bind_i),
    .permit_o(permit), .reason_o(reason), .status_o(status), .slot_vld_o(slot_vld), .slot_o(slot_o));

  // ===========================================================================
  // REF: priority-ordered reference, exact integer arithmetic
  // ===========================================================================
  integer s, k, i;
  integer found, dev_n, dev_i;
  reg [129:0] A, L, E, LO, HI, WB, WL;
  reg [AW-1:0] inv_mask;
  reg         r_isol, r_bound, r_dom_ok, r_ovf, r_attr_bad, r_op_bad, r_cls_bad;
  reg         r_instr, r_apriv, r_asec, r_dev_in, r_win_contain, r_win_allow, r_q_ok;
  reg [3:0]   ref_reason, ref_status;
  reg [1:0]   f_state;
  reg         f_priv, f_sec;
  reg         dev_ov_any;

  always @(*) begin
    // defaults for every temporary: the block must be latch-free
    i = 0; k = 0; s = 0; LO = 130'd0; HI = 130'd0; WB = 130'd0; WL = 130'd0; inv_mask = {AW{1'b0}};
    A = {{(130-AW){1'b0}}, addr_i};
    L = {{(130-LEN_W){1'b0}}, len_i};
    E = A + L - 130'd1;
    r_ovf = (L != 130'd0) && (E > FULL);
    r_instr = attr_i[4];
    r_apriv = attr_i[2];
    r_asec  = attr_i[3];
    r_op_bad   = !(op_i == 4'd1 || op_i == 4'd2);
    r_cls_bad  = !(cls_i == 2'd0 || cls_i == 2'd1);
    r_attr_bad = attr_i[7] || (attr_i[1:0] == 2'd3) || (r_instr && op_i == 4'd2);
    r_isol = 1'b0;
    if (src_i < NP) r_isol = isol_i[src_i];
    // domain
    found = -1;
    for (s = 0; s < NDOM; s = s + 1)
      if (found < 0 && slot_state_i[2*s +: 2] != 2'd0 && slot_id_i[8*s +: 8] == dom_i) found = s;
    r_bound = 1'b0;
    f_state = 2'd0; f_priv = 1'b0; f_sec = 1'b0;
    if (found >= 0) begin
      f_state = slot_state_i[2*found +: 2];
      f_priv  = slot_priv_i[found];
      f_sec   = slot_secure_i[found];
      if (src_i < NP) r_bound = bind_i[src_i*NDOM + found];
    end
    r_dom_ok = (found >= 0) && r_bound && (dom_i != 8'hFF);
    // devices (regions as [lo, lo + size - 1])
    dev_n = 0; dev_i = -1; r_dev_in = 1'b0; dev_ov_any = 1'b0;
    for (i = 0; i < NDEV; i = i + 1) begin
      if (DEV_MASK[i*AW +: AW] != {AW{1'b0}}) begin
        inv_mask = ~DEV_MASK[i*AW +: AW];
        LO = {{(130-AW){1'b0}}, DEV_BASE[i*AW +: AW]};
        HI = LO + {{(130-AW){1'b0}}, inv_mask};
        if (A <= HI && E >= LO) begin
          dev_n = dev_n + 1;
          dev_i = i;
          dev_ov_any = 1'b1;
          r_dev_in = (A >= LO && E <= HI);
        end
      end
    end
    // windows of the found slot
    r_win_contain = 1'b0; r_win_allow = 1'b0;
    if (found >= 0) begin
      for (k = 0; k < NW; k = k + 1) begin
        WB = {{(130-AW){1'b0}}, win_base_i[(found*NW+k)*AW +: AW]};
        WL = {{(130-AW){1'b0}}, win_limit_i[(found*NW+k)*AW +: AW]};
        if (win_valid_i[found*NW+k] && A >= WB && E <= WL) begin
          r_win_contain = 1'b1;
          if (((op_i == 4'd1) ? win_r_i[found*NW+k] : win_w_i[found*NW+k]) && (!r_instr || win_x_i[found*NW+k]))
            r_win_allow = 1'b1;
        end
      end
    end
    // queue
    r_q_ok = 1'b0;
    if (found >= 0 && idx_i < NQ) r_q_ok = !qhold_i[idx_i] && qmask_i[found*NQ + idx_i];
    // decision order
    ref_reason = 4'd0;
    if (r_isol)                                          ref_reason = 4'd13;
    else if (dft_i)                                      ref_reason = 4'd12;
    else if (r_cls_bad)                                  ref_reason = 4'd2;
    else if (r_op_bad)                                   ref_reason = 4'd1;
    else if (r_attr_bad)                                 ref_reason = 4'd2;
    else if (!r_dom_ok)                                  ref_reason = 4'd3;
    else if (lockdown_i && dom_i != 8'd0 && dom_i != 8'd1) ref_reason = 4'd12;
    else if (f_state != 2'd2)                            ref_reason = 4'd6;
    else if ((r_apriv && !f_priv) || (r_asec && !f_sec)) ref_reason = 4'd11;
    else if (cls_i == 2'd1)                              ref_reason = r_q_ok ? 4'd0 : 4'd10;
    else if (L == 130'd0)                                ref_reason = 4'd4;
    else if (r_ovf)                                      ref_reason = 4'd5;
    else if (dev_ov_any) begin
      if (dev_n != 1 || !r_dev_in)                       ref_reason = 4'd7;
      else if ((DEV_PRIV[dev_i] && !r_apriv) || (DEV_SECURE[dev_i] && !r_asec)) ref_reason = 4'd11;
      else if (r_instr)                                  ref_reason = 4'd8;
      else if (!((op_i == 4'd1) ? devrd_i[found*NDEV + dev_i] : devwr_i[found*NDEV + dev_i])) ref_reason = 4'd9;
    end
    else if (!r_win_contain)                             ref_reason = 4'd7;
    else if (!r_win_allow)                               ref_reason = 4'd8;
    ref_status = (ref_reason == 4'd0) ? 4'd0 : (ref_reason == 4'd1) ? 4'd3 : (ref_reason == 4'd2) ? 4'd6 : 4'd2;
  end

  // ===========================================================================
  // SPEC: priority-free characterisation of "permit"
  // ===========================================================================
  reg spec, uniq_ok, slot_ok, win_ok_s, dev_ok_s, q_ok_s, any_dev_touch, dev_single_in, rd_s, wr_s;
  integer s2, k2, i2, sdev_n, sdev_i;
  reg [129:0] SLO, SHI, SWB, SWL;
  reg [AW-1:0] sinv;
  always @(*) begin
    s2 = 0; k2 = 0; i2 = 0; rd_s = 1'b0; wr_s = 1'b0; SLO = 130'd0; SHI = 130'd0; SWB = 130'd0; SWL = 130'd0;
    sinv = {AW{1'b0}};
    // INV-UNIQ hypothesis
    uniq_ok = 1'b1;
    for (s2 = 0; s2 < NDOM; s2 = s2 + 1)
      for (k2 = s2 + 1; k2 < NDOM; k2 = k2 + 1)
        if (slot_state_i[2*s2 +: 2] != 2'd0 && slot_state_i[2*k2 +: 2] != 2'd0 &&
            slot_id_i[8*s2 +: 8] == slot_id_i[8*k2 +: 8]) uniq_ok = 1'b0;
    // device touch (independent of the slot)
    sdev_n = 0; sdev_i = -1; dev_single_in = 1'b0;
    for (i2 = 0; i2 < NDEV; i2 = i2 + 1) begin
      if (DEV_MASK[i2*AW +: AW] != {AW{1'b0}}) begin
        sinv = ~DEV_MASK[i2*AW +: AW];
        SLO = {{(130-AW){1'b0}}, DEV_BASE[i2*AW +: AW]};
        SHI = SLO + {{(130-AW){1'b0}}, sinv};
        if (A <= SHI && E >= SLO) begin
          sdev_n = sdev_n + 1; sdev_i = i2;
          dev_single_in = (A >= SLO && E <= SHI);
        end
      end
    end
    any_dev_touch = (sdev_n != 0);
    spec = 1'b0;
    for (s2 = 0; s2 < NDOM; s2 = s2 + 1) begin
      slot_ok = (slot_state_i[2*s2 +: 2] == 2'd2) && (slot_id_i[8*s2 +: 8] == dom_i) && (dom_i != 8'hFF) &&
                (src_i < NP) && !(lockdown_i && dom_i != 8'd0 && dom_i != 8'd1) &&
                (!r_apriv || slot_priv_i[s2]) && (!r_asec || slot_secure_i[s2]);
      if (slot_ok && src_i < NP) slot_ok = bind_i[src_i*NDOM + s2];
      win_ok_s = 1'b0;
      for (k2 = 0; k2 < NW; k2 = k2 + 1) begin
        SWB = {{(130-AW){1'b0}}, win_base_i[(s2*NW+k2)*AW +: AW]};
        SWL = {{(130-AW){1'b0}}, win_limit_i[(s2*NW+k2)*AW +: AW]};
        if (win_valid_i[s2*NW+k2] && A >= SWB && E <= SWL &&
            ((op_i == 4'd1) ? win_r_i[s2*NW+k2] : win_w_i[s2*NW+k2]) && (!r_instr || win_x_i[s2*NW+k2]))
          win_ok_s = 1'b1;
      end
      dev_ok_s = 1'b0;
      if (sdev_n == 1 && dev_single_in) begin
        rd_s = devrd_i[s2*NDEV + sdev_i]; wr_s = devwr_i[s2*NDEV + sdev_i];
        dev_ok_s = ((op_i == 4'd1) ? rd_s : wr_s) && !r_instr &&
                   (!DEV_PRIV[sdev_i] || r_apriv) && (!DEV_SECURE[sdev_i] || r_asec);
      end
      q_ok_s = (idx_i < NQ) ? (!qhold_i[idx_i] && qmask_i[s2*NQ + idx_i]) : 1'b0;
      if (slot_ok &&
          ((cls_i == 2'd1) ? q_ok_s
                           : ((L != 130'd0) && !r_ovf && (any_dev_touch ? dev_ok_s : win_ok_s))))
        spec = 1'b1;
    end
    spec = spec && !r_isol && !dft_i && (cls_i == 2'd0 || cls_i == 2'd1) && !r_op_bad && !r_attr_bad;
  end

  // ===========================================================================
  // properties
  // ===========================================================================
  wire cls_addr = (cls_i == 2'd0);
  always @(posedge clk_i) begin
    if (PROVE) begin
      a_ref_reason  : assert (reason == ref_reason);
      a_ref_status  : assert (status == ref_status);
      a_permit_iff  : assert (permit == (reason == 4'd0));
      a_spec        : assert (!uniq_ok || (permit == spec));
      a_slotvld     : assert (slot_vld == r_dom_ok);
      a_reason_range: assert (reason <= 4'd13);
      // every denial is explicit; success is unambiguous
      a_explicit    : assert (permit || (reason != 4'd0 && status != 4'd0));
      a_okay        : assert (!permit || status == 4'd0);
      // requester-visible status is one of four values only (no layout oracle)
      a_status_set  : assert (status == 4'd0 || status == 4'd2 || status == 4'd3 || status == 4'd6);
      a_deny_coarse : assert (!(reason >= 4'd3) || status == 4'd2);
      // corollaries named after the brief
      c_dft         : assert (!dft_i || !permit);
      c_isolated    : assert (!r_isol || !permit);
      c_badop       : assert (!r_op_bad || !permit);
      c_badcls      : assert (!r_cls_bad || !permit);
      c_unbound     : assert (r_dom_ok || !permit);                        // domain context must be known AND bound to src
      c_inactive    : assert (!permit || found < 0 || f_state == 2'd2);   // domain must be ACTIVE
      c_lockdown    : assert (!(lockdown_i && dom_i != 8'd0 && dom_i != 8'd1) || !permit);
      c_nowrap      : assert (!(permit && cls_addr) || (L != 130'd0 && E <= FULL));      // overflow / zero length never permitted
      c_span_dev    : assert (!(cls_addr && dev_ov_any && (dev_n != 1 || !r_dev_in)) || !permit);    // device boundary-spanning denied (QUEUE class carries no address)
      c_dev_not_win : assert (!(permit && cls_addr && dev_ov_any) || (dev_n == 1 && r_dev_in && !r_instr));
      c_mem_in_win  : assert (!(permit && cls_addr && !dev_ov_any) || r_win_allow);      // range wholly inside ONE allowing window
      c_priv_claim  : assert (!(permit && r_apriv) || f_priv);                           // priv claim bounded by capability
      c_sec_claim   : assert (!(permit && r_asec)  || f_sec);
      c_queue_hold  : assert (!(permit && cls_i == 2'd1 && idx_i < NQ) || !qhold_i[idx_i]);
    end
  end

  // ===========================================================================
  // cover bins (non-vacuity witnesses)
  // ===========================================================================
  reg span_case;
  integer s3, k3, k4;
  reg [129:0] W3B, W3L, W4B, W4L;
  always @(*) begin
    k3 = 0; k4 = 0; s3 = 0; W3B = 130'd0; W3L = 130'd0; W4B = 130'd0; W4L = 130'd0;
    span_case = 1'b0;
    if (found >= 0 && cls_addr && !dev_ov_any && L != 130'd0 && !r_ovf)
      for (k3 = 0; k3 < NW; k3 = k3 + 1)
        for (k4 = 0; k4 < NW; k4 = k4 + 1) begin
          W3B = {{(130-AW){1'b0}}, win_base_i[(found*NW+k3)*AW +: AW]};
          W3L = {{(130-AW){1'b0}}, win_limit_i[(found*NW+k3)*AW +: AW]};
          W4B = {{(130-AW){1'b0}}, win_base_i[(found*NW+k4)*AW +: AW]};
          W4L = {{(130-AW){1'b0}}, win_limit_i[(found*NW+k4)*AW +: AW]};
          if (k3 != k4 && win_valid_i[found*NW+k3] && win_valid_i[found*NW+k4] && W3L + 130'd1 == W4B &&
              A >= W3B && A <= W3L && E >= W4B && E <= W4L && win_r_i[found*NW+k3] && win_r_i[found*NW+k4])
            span_case = 1'b1;     // two ADJACENT windows, both readable, range straddles them
        end
  end

  wire [15:0] cov_vec;
  assign cov_vec[0]  = permit && cls_addr && !dev_ov_any;                          // memory access permitted
  assign cov_vec[1]  = permit && cls_addr && dev_ov_any;                           // device access permitted
  assign cov_vec[2]  = permit && cls_i == 2'd1;                                    // queue use permitted
  assign cov_vec[3]  = span_case && op_i == 4'd1 && !attr_i[7] && attr_i[1:0] != 2'd3 &&
                       r_dom_ok && f_state == 2'd2 && !r_isol && !dft_i && !lockdown_i && !attr_i[2] && !attr_i[3] &&
                       reason == 4'd7;                                             // spanning two ALLOWING adjacent windows is still denied
  assign cov_vec[4]  = reason == 4'd5;                                             // overflow
  assign cov_vec[5]  = reason == 4'd8 && !dev_ov_any;                              // window found, right missing
  assign cov_vec[6]  = reason == 4'd9;                                             // device permission missing
  assign cov_vec[7]  = reason == 4'd13;                                            // isolated port
  assign cov_vec[8]  = permit && lockdown_i;                                       // ROOT/MGMT still served in safe state
  assign cov_vec[9]  = reason == 4'd3 && found >= 0 && !r_bound;                   // spoof: known domain, wrong port
  assign cov_vec[10] = reason == 4'd11;                                            // privilege claim above capability
  assign cov_vec[11] = reason == 4'd10;                                            // queue refused
  assign cov_vec[12] = reason == 4'd7 && dev_ov_any;                               // device boundary-spanning
  assign cov_vec[13] = reason == 4'd6;                                             // domain not ACTIVE
  assign cov_vec[14] = reason == 4'd12 && !dft_i;                                  // safe-state denial
  assign cov_vec[15] = permit && cls_addr && !dev_ov_any && E == FULL;             // permitted access ending on the last address byte
  always @(posedge clk_i) if (!PROVE) a_cover_probe: assert (!cov_vec[COVER_IDX]);
endmodule
