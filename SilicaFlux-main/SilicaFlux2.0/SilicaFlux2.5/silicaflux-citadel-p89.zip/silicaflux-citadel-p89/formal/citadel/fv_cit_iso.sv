// =============================================================================
//  fv_cit_iso.sv  --  domain isolation theorem: sf_citadel_domain_table +
//                     sf_citadel_permission composed
// -----------------------------------------------------------------------------
//  Environment: NOTHING is constrained except that the design starts in reset.
//  Every cycle the privileged command port (any opcode, any requester, any
//  argument, cfg_en high or low), the containment hook, the asynchronous
//  reset, the safety levels and the memory request are free inputs.
//
//  ASSERTED (all proved unboundedly by ABC pdr in the job "iso_*"):
//   Table invariants -- inductive over EVERY command sequence:
//     INV-EXCL    for distinct slots i != j and valid windows a (of i), b (of j):
//                 excl(a) or excl(b)  =>  a and b are disjoint
//     INV-UNIQ    two non-empty slots never share a domain id
//     INV-WF      every valid window has base <= limit; an empty slot holds no
//                 valid window
//     INV-NODEV   a valid exclusive window never touches a device region
//   Isolation theorem (derived from the invariants + the checker):
//     ISO-X       a PERMITTED ADDR request never touches ANY byte of an
//                 exclusive window held by a DIFFERENT domain
//     ISO-STATE   permit => the domain is ACTIVE and bound to the source port
//     ISO-DENY    a request that touches another domain's exclusive window
//                 and is not inside the requester's own allowing window is denied
//  ASSUMPTIONS: reset asserted in the first cycle (init_q).  Parameters:
//  small slot / window / port counts and a narrow AW so that IC3 closes; the
//  logic is width- and count-generic (see docs/citadel/07_VERIFICATION.md
//  "proof bounds"); the same wrapper runs at AW=64 as a bounded check.
//  COVER_IDX >= 0 selects reachability mode.
// =============================================================================
module fv_cit_iso #(
  parameter NDOM  = 2,
  parameter NW    = 2,
  parameter NP    = 2,
  parameter NDEV  = 1,
  parameter NQ    = 2,
  parameter NKEY  = 1,
  parameter AW    = 5,
  parameter LEN_W = 4,
  parameter [NDEV*AW-1:0] DEV_BASE   = 5'h10,
  parameter [NDEV*AW-1:0] DEV_MASK   = 5'h1C,
  parameter [NDEV-1:0]    DEV_PRIV   = 1'b0,
  parameter [NDEV-1:0]    DEV_SECURE = 1'b0,
  parameter COVER_IDX = -1,
  localparam SLOT_W = (NDOM > 1) ? $clog2(NDOM) : 1,
  localparam WIN_W  = (NW   > 1) ? $clog2(NW)   : 1,
  localparam PORT_W = (NP   > 1) ? $clog2(NP)   : 1
) (
  input  wire                  clk_i,
  input  wire                  rst_ni,
  // privileged command + containment
  input  wire                  cfg_en_i,
  input  wire                  cmd_valid_i,
  input  wire [3:0]            cmd_op_i,
  input  wire [7:0]            cmd_dom_i,
  input  wire                  cmd_priv_i,
  input  wire [SLOT_W-1:0]     cmd_slot_i,
  input  wire [WIN_W-1:0]      cmd_win_i,
  input  wire [PORT_W-1:0]     cmd_port_i,
  input  wire [7:0]            cmd_arg_dom_i,
  input  wire [7:0]            cmd_flags_i,
  input  wire [63:0]           cmd_d0_i,
  input  wire [63:0]           cmd_d1_i,
  input  wire                  qtn_valid_i,
  input  wire [SLOT_W-1:0]     qtn_slot_i,
  // memory request
  input  wire [PORT_W-1:0]     src_i,
  input  wire [7:0]            dom_i,
  input  wire [3:0]            op_i,
  input  wire [7:0]            attr_i,
  input  wire [AW-1:0]         addr_i,
  input  wire [LEN_W-1:0]      len_i,
  input  wire [1:0]            cls_i,
  input  wire [7:0]            idx_i,
  input  wire                  lockdown_i,
  input  wire                  dft_i,
  input  wire [NQ-1:0]         qhold_i,
  input  wire [NP-1:0]         isol_i
);
  localparam PROVE = (COVER_IDX < 0);

  reg init_q = 1'b1;
  always @(posedge clk_i) init_q <= 1'b0;
  always @(*) if (init_q) assume (!rst_ni);

  wire                    rsp_valid, cmd_deny, clr_safe, clr_cnt, thresh_we, zero_valid, own_found, look_found;
  wire [3:0]              rsp_status;
  wire [NQ-1:0]           clr_qhold;
  wire [NP-1:0]           clr_isol;
  wire [15:0]             thresh;
  wire [NKEY-1:0]         zero_mask;
  wire [NDOM-1:0]         slot_clr;
  wire [SLOT_W-1:0]       look_slot, own_slot;
  wire [NDOM*2-1:0]       slot_state;
  wire [NDOM*8-1:0]       slot_id;
  wire [NDOM-1:0]         slot_priv, slot_secure;
  wire [NDOM*NW-1:0]      win_valid, win_r, win_w, win_x, win_excl;
  wire [NDOM*NW*AW-1:0]   win_base, win_limit;
  wire [NDOM*NDEV-1:0]    devrd, devwr;
  wire [NDOM*NQ-1:0]      qmask;
  wire [NDOM*NKEY-1:0]    kmask;
  wire [NP*NDOM-1:0]      bindv;
  wire                    lockv;

  sf_citadel_domain_table #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(NDEV), .NQ(NQ), .NKEY(NKEY), .AW(AW),
                            .DEV_BASE(DEV_BASE), .DEV_MASK(DEV_MASK)) u_tbl (
    .clk_i(clk_i), .rst_ni(rst_ni), .cfg_en_i(cfg_en_i), .cmd_valid_i(cmd_valid_i), .cmd_op_i(cmd_op_i),
    .cmd_dom_i(cmd_dom_i), .cmd_priv_i(cmd_priv_i), .cmd_slot_i(cmd_slot_i), .cmd_win_i(cmd_win_i),
    .cmd_port_i(cmd_port_i), .cmd_arg_dom_i(cmd_arg_dom_i), .cmd_flags_i(cmd_flags_i), .cmd_data0_i(cmd_d0_i),
    .cmd_data1_i(cmd_d1_i), .rsp_valid_o(rsp_valid), .rsp_status_o(rsp_status), .cmd_deny_o(cmd_deny),
    .ctl_clr_qhold_o(clr_qhold), .ctl_clr_isol_o(clr_isol), .ctl_clr_safe_o(clr_safe), .ctl_clr_cnt_o(clr_cnt),
    .ctl_thresh_we_o(thresh_we), .ctl_thresh_o(thresh), .qtn_valid_i(qtn_valid_i), .qtn_slot_i(qtn_slot_i),
    .zero_valid_o(zero_valid), .zero_mask_o(zero_mask), .slot_clr_o(slot_clr),
    .look_dom_i(dom_i), .look_found_o(look_found), .look_slot_o(look_slot),
    .own_addr_i(addr_i), .own_found_o(own_found), .own_slot_o(own_slot),
    .slot_state_o(slot_state), .slot_id_o(slot_id), .slot_priv_o(slot_priv), .slot_secure_o(slot_secure),
    .win_valid_o(win_valid), .win_base_o(win_base), .win_limit_o(win_limit), .win_r_o(win_r), .win_w_o(win_w),
    .win_x_o(win_x), .win_excl_o(win_excl), .devrd_o(devrd), .devwr_o(devwr), .qmask_o(qmask), .kmask_o(kmask),
    .bind_o(bindv), .lock_o(lockv));

  wire              permit, slot_vld;
  wire [3:0]        reason, status;
  wire [SLOT_W-1:0] slot_o;
  sf_citadel_permission #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(NDEV), .NQ(NQ), .AW(AW), .LEN_W(LEN_W),
                          .DEV_BASE(DEV_BASE), .DEV_MASK(DEV_MASK), .DEV_PRIV(DEV_PRIV), .DEV_SECURE(DEV_SECURE)) u_perm (
    .src_i(src_i), .dom_i(dom_i), .op_i(op_i), .attr_i(attr_i), .addr_i(addr_i), .len_i(len_i), .cls_i(cls_i),
    .idx_i(idx_i), .lockdown_i(lockdown_i), .dft_active_i(dft_i), .qhold_i(qhold_i), .port_isol_i(isol_i),
    .slot_state_i(slot_state), .slot_id_i(slot_id), .slot_priv_i(slot_priv), .slot_secure_i(slot_secure),
    .win_valid_i(win_valid), .win_base_i(win_base), .win_limit_i(win_limit), .win_r_i(win_r), .win_w_i(win_w),
    .win_x_i(win_x), .devrd_i(devrd), .devwr_i(devwr), .qmask_i(qmask), .bind_i(bindv),
    .permit_o(permit), .reason_o(reason), .status_o(status), .slot_vld_o(slot_vld), .slot_o(slot_o));

  // ---------------------------------------------------------------------------
  // table invariants (exact integer arithmetic)
  // ---------------------------------------------------------------------------
  localparam [129:0] FULL = ({130{1'b1}} >> (130 - AW));
  integer a, b, wa, wb, d;
  reg [129:0] ABASE, ALIM, BBASE, BLIM, DLO, DHI;
  reg [AW-1:0] dinv;
  reg inv_excl, inv_uniq, inv_wf, inv_nowin, inv_nodev;
  always @(*) begin
    a = 0; b = 0; wa = 0; wb = 0; d = 0;
    ABASE = 130'd0; ALIM = 130'd0; BBASE = 130'd0; BLIM = 130'd0; DLO = 130'd0; DHI = 130'd0; dinv = {AW{1'b0}};
    inv_excl = 1'b1; inv_uniq = 1'b1; inv_wf = 1'b1; inv_nowin = 1'b1; inv_nodev = 1'b1;
    for (a = 0; a < NDOM; a = a + 1) begin
      for (b = a + 1; b < NDOM; b = b + 1)
        if (slot_state[2*a +: 2] != 2'd0 && slot_state[2*b +: 2] != 2'd0 && slot_id[8*a +: 8] == slot_id[8*b +: 8])
          inv_uniq = 1'b0;
      for (wa = 0; wa < NW; wa = wa + 1) begin
        ABASE = {{(130-AW){1'b0}}, win_base[(a*NW+wa)*AW +: AW]};
        ALIM  = {{(130-AW){1'b0}}, win_limit[(a*NW+wa)*AW +: AW]};
        if (win_valid[a*NW+wa]) begin
          if (ABASE > ALIM)            inv_wf = 1'b0;
          if (slot_state[2*a +: 2] == 2'd0) inv_nowin = 1'b0;
          if (win_excl[a*NW+wa])
            for (d = 0; d < NDEV; d = d + 1)
              if (DEV_MASK[d*AW +: AW] != {AW{1'b0}}) begin
                dinv = ~DEV_MASK[d*AW +: AW];
                DLO = {{(130-AW){1'b0}}, DEV_BASE[d*AW +: AW]};
                DHI = DLO + {{(130-AW){1'b0}}, dinv};
                if (ABASE <= DHI && DLO <= ALIM) inv_nodev = 1'b0;
              end
          for (b = 0; b < NDOM; b = b + 1)
            if (b != a)
              for (wb = 0; wb < NW; wb = wb + 1) begin
                BBASE = {{(130-AW){1'b0}}, win_base[(b*NW+wb)*AW +: AW]};
                BLIM  = {{(130-AW){1'b0}}, win_limit[(b*NW+wb)*AW +: AW]};
                if (win_valid[b*NW+wb] && (win_excl[a*NW+wa] || win_excl[b*NW+wb]) && ABASE <= BLIM && BBASE <= ALIM)
                  inv_excl = 1'b0;
              end
        end
      end
    end
  end

  // ---------------------------------------------------------------------------
  // isolation theorem
  // ---------------------------------------------------------------------------
  wire [129:0] RA = {{(130-AW){1'b0}}, addr_i};
  wire [129:0] RL = {{(130-LEN_W){1'b0}}, len_i};
  wire [129:0] RE = RA + RL - 130'd1;
  wire cls_addr = (cls_i == 2'd0);
  reg  iso_x, iso_deny_ok, other_excl_touch, own_allow;
  integer ob, owb, ok_;
  reg [129:0] OB, OL;
  always @(*) begin
    ob = 0; owb = 0; ok_ = 0; OB = 130'd0; OL = 130'd0;
    iso_x = 1'b1;
    other_excl_touch = 1'b0;
    for (ob = 0; ob < NDOM; ob = ob + 1)
      if (ob != slot_o)
        for (owb = 0; owb < NW; owb = owb + 1) begin
          OB = {{(130-AW){1'b0}}, win_base[(ob*NW+owb)*AW +: AW]};
          OL = {{(130-AW){1'b0}}, win_limit[(ob*NW+owb)*AW +: AW]};
          if (win_valid[ob*NW+owb] && win_excl[ob*NW+owb] && RA <= OL && OB <= RE) other_excl_touch = 1'b1;
        end
    // ISO-X: a permitted ADDR request never touches a different domain's exclusive window
    if (permit && cls_addr && other_excl_touch) iso_x = 1'b0;
  end

  always @(posedge clk_i) begin
    if (PROVE && !init_q) begin
      i_excl   : assert (inv_excl);
      i_uniq   : assert (inv_uniq);
      i_wf     : assert (inv_wf);
      i_nowin  : assert (inv_nowin);
      i_nodev  : assert (inv_nodev);
      iso_x_p  : assert (iso_x);
      iso_state: assert (!permit || (slot_vld && slot_state[2*slot_o +: 2] == 2'd2 &&
                                     (src_i < NP) && bindv[src_i*NDOM + slot_o]));
      // a request that touches someone else's exclusive window is denied unless the checker found the
      // requester's OWN allowing window containing it (which INV-EXCL forbids for an exclusive window)
      iso_deny : assert (!(cls_addr && other_excl_touch && slot_vld) || !permit);
    end
  end

  // ---------------------------------------------------------------------------
  // cover bins
  // ---------------------------------------------------------------------------
  integer cs, cw;
  reg two_active, excl_other_exists;
  always @(*) begin
    cs = 0; cw = 0;
    two_active = 1'b0; excl_other_exists = 1'b0;
    if (NDOM >= 2) two_active = (slot_state[1:0] == 2'd2) && (slot_state[3:2] == 2'd2);
    for (cs = 0; cs < NDOM; cs = cs + 1)
      if (cs != slot_o)
        for (cw = 0; cw < NW; cw = cw + 1)
          if (win_valid[cs*NW+cw] && win_excl[cs*NW+cw]) excl_other_exists = 1'b1;
  end
  wire [7:0] cov_vec;
  assign cov_vec[0] = permit && cls_addr;                                   // a memory access is permitted
  assign cov_vec[1] = permit && cls_addr && excl_other_exists;              // ... while another domain holds an exclusive window
  assign cov_vec[2] = rsp_valid && rsp_status == 4'd6;                      // CS_OVERLAP returned
  assign cov_vec[3] = two_active;                                           // two ACTIVE domains
  assign cov_vec[4] = !permit && cls_addr && other_excl_touch && slot_vld;  // the attack: probe into a foreign exclusive window, denied
  assign cov_vec[5] = slot_state[1:0] == 2'd3 || (NDOM > 1 && slot_state[3:2] == 2'd3);   // a quarantined domain exists
  assign cov_vec[6] = rsp_valid && rsp_status == 4'd0 && cmd_deny == 1'b0 && look_found; // an accepted command with a resident domain
  assign cov_vec[7] = permit && cls_addr && two_active && excl_other_exists;
  always @(posedge clk_i) if (!PROVE) a_cover_probe: assert (!cov_vec[COVER_IDX]);
endmodule
