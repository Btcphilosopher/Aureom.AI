# secworks SHA-256 core (vendored, unmodified)

`sha256_core.v`, `sha256_k_constants.v`, `sha256_w_mem.v` are the Secworks Sweden AB SHA-256 implementation
(BSD 2-clause; the licence is in every file header and must be kept).  They are copied **unmodified** from the repository's
Project 28 SecureSilicon (`SilicaFlux-main/silicaflux-secureboot-p28.zip`, `third_party/secworks-sha256/rtl/`), where they were
validated against NIST CAVP vectors (see that project's reports).  Checksums: `SHA256SUMS`.

Used ONLY by `tests/citadel/system/tb_citadel_crypto.sv` to show the CloudCrypto adapter gating a real, validated hash
core.  Citadel itself contains no cryptography and does not depend on this directory.
