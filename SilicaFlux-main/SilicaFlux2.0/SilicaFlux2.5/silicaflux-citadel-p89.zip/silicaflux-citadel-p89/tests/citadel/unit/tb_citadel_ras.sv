// =============================================================================
//  tb_citadel_ras.sv  --  unit test of sf_citadel_ras
//  Saturating counters, severity-first selection, overrun, attribution capture,
//  level edge detection, same-cycle extra occurrences.  DUT inputs are assigned
//  as whole vectors with non-blocking assignments (see docs/citadel/07).
// =============================================================================
`timescale 1ns/1ps
module tb_citadel_ras;
  localparam int unsigned AW = 16, CNT_W = 8;
  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;
  logic [15:0] ev = '0, ev_dvld = '0; logic [16*4-1:0] ev_extra = '0; logic [16*8-1:0] ev_dom = '0, ev_idx = '0;
  logic [3:0] ev_avld = '0; logic [4*AW-1:0] ev_addr = '0;
  logic sel_valid, sel_dom_vld, sel_addr_vld, sel_ack = 1'b0; logic [3:0] sel_src; logic [1:0] sel_sev;
  logic [7:0] sel_dom, sel_idx; logic [AW-1:0] sel_addr;
  logic clr_cnt = 1'b0, rst_evt = 1'b0; logic [15:0] pend, overrun;
  logic [16*CNT_W-1:0] src_cnt; logic [4*CNT_W-1:0] sev_cnt;
  logic [CNT_W-1:0] a_viol, a_dma, a_auth, a_ce, a_unc, a_queue, a_reset;

  sf_citadel_ras #(.AW(AW), .CNT_W(CNT_W)) dut (
    .clk_i(clk), .rst_ni(rst_n), .ev_i(ev), .ev_extra_i(ev_extra), .ev_dom_vld_i(ev_dvld), .ev_dom_i(ev_dom), .ev_idx_i(ev_idx),
    .ev_addr_vld_i(ev_avld), .ev_addr_i(ev_addr), .sel_valid_o(sel_valid), .sel_src_o(sel_src), .sel_sev_o(sel_sev),
    .sel_dom_vld_o(sel_dom_vld), .sel_dom_o(sel_dom), .sel_idx_o(sel_idx), .sel_addr_vld_o(sel_addr_vld), .sel_addr_o(sel_addr),
    .sel_ack_i(sel_ack), .clr_cnt_i(clr_cnt), .rst_evt_i(rst_evt), .pend_o(pend), .overrun_o(overrun), .src_cnt_o(src_cnt),
    .sev_cnt_o(sev_cnt), .aud_viol_o(a_viol), .aud_dma_o(a_dma), .aud_auth_o(a_auth), .aud_ce_o(a_ce), .aud_uncorr_o(a_unc),
    .aud_queue_o(a_queue), .aud_reset_o(a_reset));

  integer errors = 0, checks = 0;
  task automatic eq(input string what, input logic [63:0] got, input logic [63:0] exp);
    checks++;
    if (got !== exp) begin errors++; if (errors <= 20) $display("FAIL %s: got %0h expected %0h (t=%0t)", what, got, exp, $time); end
  endtask
  task automatic tick(input integer n); repeat (n) @(negedge clk); endtask

  logic [16*8-1:0] sh_dom = '0, sh_idx = '0; logic [15:0] sh_dvld = '0; logic [4*AW-1:0] sh_addr = '0; logic [3:0] sh_avld = '0;
  logic [16*4-1:0] sh_extra = '0;
  task automatic pulse(input [15:0] mask);
    @(negedge clk); ev <= mask; @(negedge clk); ev <= '0;
  endtask

  initial begin : main
    #1 rst_n = 1'b0; tick(3); rst_n = 1'b1; tick(2);

    // --- saturation: 300 corrected-ECC events on a CNT_W = 8 counter stop at 255 and never wrap
    @(negedge clk); ev <= 16'h0001;
    tick(300);
    @(negedge clk); ev <= '0; tick(3);
    eq("saturating per-source counter", src_cnt[0*CNT_W +: CNT_W], 8'd255);
    eq("saturating audit counter (ECC corrections)", a_ce, 8'd255);
    eq("saturating severity counter (corrected)", sev_cnt[0*CNT_W +: CNT_W], 8'd255);
    @(negedge clk); clr_cnt <= 1'b1; @(negedge clk); clr_cnt <= 1'b0; tick(2);
    eq("clear counters", src_cnt[0 +: CNT_W], 8'd0);
    eq("clear audit counter", a_ce, 8'd0);
    // the pending record of source 0 is still there: drain it
    @(negedge clk); sel_ack <= 1'b1; tick(3); sel_ack <= 1'b0; tick(2);
    eq("nothing pending after drain", pend, 16'd0);

    // --- most severe first: corrected (0), detected (4), uncorrectable (1), fatal (2) all pending together
    pulse(16'b0000_0000_0001_0111);        // sources 0,1,2,4
    tick(2);
    eq("selection: fatal first", sel_src, 4'd2);          eq("selection valid", sel_valid, 1'b1);  eq("selection severity", sel_sev, 2'd3);
    @(negedge clk); sel_ack <= 1'b1; @(negedge clk); sel_ack <= 1'b0; #1;
    eq("selection: then uncorrectable", sel_src, 4'd1);   eq("severity", sel_sev, 2'd2);
    @(negedge clk); sel_ack <= 1'b1; @(negedge clk); sel_ack <= 1'b0; #1;
    eq("selection: then detected", sel_src, 4'd4);        eq("severity", sel_sev, 2'd1);
    @(negedge clk); sel_ack <= 1'b1; @(negedge clk); sel_ack <= 1'b0; #1;
    eq("selection: corrected last", sel_src, 4'd0);       eq("severity", sel_sev, 2'd0);
    @(negedge clk); sel_ack <= 1'b1; @(negedge clk); sel_ack <= 1'b0; tick(2);
    eq("selection invalid when empty", sel_valid, 1'b0);
    eq("pending empty", pend, 16'd0);

    @(negedge clk); clr_cnt <= 1'b1; @(negedge clk); clr_cnt <= 1'b0; tick(2);       // start the next block from zero counters
    // --- attribution capture and overrun: source 1 (UE) with address / domain / index; a second occurrence is coalesced
    @(negedge clk);
    sh_dvld = '0; sh_dom = '0; sh_idx = '0; sh_avld = '0; sh_addr = '0;
    sh_dvld[1] = 1'b1; sh_dom[1*8 +: 8] = 8'h21; sh_idx[1*8 +: 8] = 8'd7; sh_avld[1] = 1'b1; sh_addr[1*AW +: AW] = 16'hBEEF;
    ev_dvld <= sh_dvld; ev_dom <= sh_dom; ev_idx <= sh_idx; ev_avld <= sh_avld; ev_addr <= sh_addr; ev <= 16'h0002;
    @(negedge clk);
    sh_dom[1*8 +: 8] = 8'h22; sh_addr[1*AW +: AW] = 16'h1234;                       // a DIFFERENT attribution for the second occurrence
    ev_dom <= sh_dom; ev_addr <= sh_addr; ev <= 16'h0002;
    @(negedge clk); ev <= '0; tick(2);
    eq("attribution: domain valid", sel_dom_vld, 1'b1);   eq("attribution: domain (first occurrence kept)", sel_dom, 8'h21);
    eq("attribution: index", sel_idx, 8'd7);              eq("attribution: address valid", sel_addr_vld, 1'b1);
    eq("attribution: address (first occurrence kept)", sel_addr, 16'hBEEF);
    eq("overrun flagged for the coalesced occurrence", overrun[1], 1'b1);
    eq("both occurrences are counted", src_cnt[1*CNT_W +: CNT_W], 8'd2);
    @(negedge clk); sel_ack <= 1'b1; @(negedge clk); sel_ack <= 1'b0; tick(2);
    eq("pending cleared by the acknowledge", pend[1], 1'b0);
    eq("overrun is sticky until cleared", overrun[1], 1'b1);
    @(negedge clk); clr_cnt <= 1'b1; @(negedge clk); clr_cnt <= 1'b0; tick(2);
    eq("overrun cleared with the counters", overrun[1], 1'b0);

    // --- an occurrence arriving in the SAME cycle as the acknowledge re-arms the record (nothing is lost)
    pulse(16'h0010); tick(2);                                   // source 4 pending
    @(negedge clk); sel_ack <= 1'b1; ev <= 16'h0010;            // acknowledge + a new occurrence together
    @(negedge clk); sel_ack <= 1'b0; ev <= '0; tick(2);
    eq("re-armed by an occurrence in the acknowledge cycle", pend[4], 1'b1);
    eq("no overrun for it", overrun[4], 1'b0);
    @(negedge clk); sel_ack <= 1'b1; @(negedge clk); sel_ack <= 1'b0; tick(2);
    @(negedge clk); clr_cnt <= 1'b1; @(negedge clk); clr_cnt <= 1'b0; tick(2);

    // --- level input (source 10, thermal warning): held high 5 cycles = ONE event; a second rising edge = another
    @(negedge clk); ev <= 16'h0400; tick(5); ev <= '0; tick(3);
    eq("level held 5 cycles counts once", src_cnt[10*CNT_W +: CNT_W], 8'd1);
    @(negedge clk); ev <= 16'h0400; @(negedge clk); ev <= '0; tick(2);
    eq("second rising edge counts again", src_cnt[10*CNT_W +: CNT_W], 8'd2);

    // --- several occurrences in one cycle (extra count): 4 simultaneous access violations on source 6, 3 invalid DMA on 7
    @(negedge clk);
    sh_extra = '0; sh_extra[6*4 +: 4] = 4'd3; sh_extra[7*4 +: 4] = 4'd2;
    ev_extra <= sh_extra; ev <= 16'h00C0;
    @(negedge clk); ev <= '0; ev_extra <= '0; tick(3);
    eq("same-cycle occurrences counted (source 6: 1+3)", src_cnt[6*CNT_W +: CNT_W], 8'd4);
    eq("same-cycle occurrences counted (source 7: 1+2)", src_cnt[7*CNT_W +: CNT_W], 8'd3);
    eq("access-violation audit counter = sources 6 + 7", a_viol, 8'd7);
    eq("invalid-DMA audit counter = source 7", a_dma, 8'd3);

    // --- reset events counter and reset clears pending records
    @(negedge clk); rst_evt <= 1'b1; @(negedge clk); rst_evt <= 1'b0; tick(2);
    eq("reset-event counter", a_reset, 8'd1);
    pulse(16'h8000); tick(2);
    eq("pending before reset", pend[15], 1'b1);
    @(negedge clk); rst_n = 1'b0; #3 rst_n = 1'b1; tick(2);
    eq("reset clears pending", pend, 16'd0);
    eq("reset clears counters", src_cnt, '0);

    tick(3);
    if (errors == 0) $display("CITADEL_TB_RESULT tb_citadel_ras PASS checks=%0d", checks);
    else             $display("CITADEL_TB_RESULT tb_citadel_ras FAIL errors=%0d checks=%0d", errors, checks);
    $finish;
  end
endmodule
