// =============================================================================
//  tb_citadel_pkg.sv  --  drift guard: Citadel's code points and device map vs the Albion packages
//  Fails if sf_citadel_pkg's COPY of the device map differs from the generated sf_albion_memmap_pkg,
//  if the ALP status / opcode / domain / attribute codes the Citadel logic relies on changed, or if the
//  RAS policy table is internally inconsistent.
// =============================================================================
`timescale 1ns/1ps
module tb_citadel_pkg;
  integer errors = 0, checks = 0;
  task automatic eq(input string what, input logic [127:0] got, input logic [127:0] exp);
    checks++; if (got !== exp) begin errors++; $display("FAIL %s: got %0h expected %0h", what, got, exp); end
  endtask

  // device i of the Citadel map <-> region index of the Albion catalogue
  localparam int unsigned IDX [7] = '{sf_albion_memmap_pkg::SF_MM_IDX_CONTROLCORE, sf_albion_memmap_pkg::SF_MM_IDX_DMA,
                                      sf_albion_memmap_pkg::SF_MM_IDX_NETWORK, sf_albion_memmap_pkg::SF_MM_IDX_VIRTIO,
                                      sf_albion_memmap_pkg::SF_MM_IDX_TENSOR_VECTOR, sf_albion_memmap_pkg::SF_MM_IDX_SECURITY,
                                      sf_albion_memmap_pkg::SF_MM_IDX_PERF};
  initial begin
    // ---- device map copy == generated Albion map
    for (int i = 0; i < 7; i++) begin
      eq($sformatf("device %0d base", i), sf_citadel_pkg::SF_CIT_DEV_BASES_DEFAULT[i*64 +: 64], sf_albion_memmap_pkg::SF_MM_BASES[IDX[i]*64 +: 64]);
      eq($sformatf("device %0d mask", i), sf_citadel_pkg::SF_CIT_DEV_MASKS_DEFAULT[i*64 +: 64], sf_albion_memmap_pkg::SF_MM_MASKS[IDX[i]*64 +: 64]);
      eq($sformatf("device %0d priv-only flag", i),   sf_citadel_pkg::SF_CIT_DEV_PRIV_DEFAULT[i],
         sf_albion_memmap_pkg::SF_MM_ATTRS[IDX[i]*8 + sf_albion_pkg::SF_RATTR_PRIV_ONLY_BIT]);
      eq($sformatf("device %0d secure-only flag", i), sf_citadel_pkg::SF_CIT_DEV_SECURE_DEFAULT[i],
         sf_albion_memmap_pkg::SF_MM_ATTRS[IDX[i]*8 + sf_albion_pkg::SF_RATTR_SECURE_ONLY_BIT]);
      eq($sformatf("device %0d is a device-type or config region", i), sf_albion_memmap_pkg::SF_MM_ASIDS[IDX[i]*4 +: 4] != sf_albion_pkg::SF_AS_EXTERNAL, 1'b1);
    end
    eq("number of device regions", sf_citadel_pkg::SF_CIT_NDEV_DEFAULT, 7);
    // the two memory regions of the catalogue are NOT devices (they are reached through domain windows)
    eq("sram is not in the device map", sf_albion_memmap_pkg::SF_MM_IDX_SRAM != IDX[0] && sf_albion_memmap_pkg::SF_MM_IDX_SRAM != IDX[6], 1'b1);

    // ---- ALP code points the logic and the Python model rely on
    eq("SF_OP_READ", sf_albion_pkg::SF_OP_READ, 1);   eq("SF_OP_WRITE", sf_albion_pkg::SF_OP_WRITE, 2);
    eq("SF_ST_OKAY", sf_albion_pkg::SF_ST_OKAY, 0);   eq("SF_ST_ACCESS_DENIED", sf_albion_pkg::SF_ST_ACCESS_DENIED, 2);
    eq("SF_ST_BAD_OPCODE", sf_albion_pkg::SF_ST_BAD_OPCODE, 3);  eq("SF_ST_BAD_ATTR", sf_albion_pkg::SF_ST_BAD_ATTR, 6);
    eq("SF_DOM_ROOT", sf_albion_pkg::SF_DOM_ROOT, 0);  eq("SF_DOM_MGMT", sf_albion_pkg::SF_DOM_MGMT, 1);
    eq("SF_DOM_SYSTEM_LAST", sf_albion_pkg::SF_DOM_SYSTEM_LAST, 8'h0F);
    eq("SF_DOM_TENANT_FIRST", sf_albion_pkg::SF_DOM_TENANT_FIRST, 8'h10);  eq("SF_DOM_TENANT_LAST", sf_albion_pkg::SF_DOM_TENANT_LAST, 8'hFE);
    eq("SF_DOM_INVALID", sf_albion_pkg::SF_DOM_INVALID, 8'hFF);
    eq("attr memtype lsb", sf_albion_pkg::SF_ATTR_MEMTYPE_LSB, 0);  eq("attr priv bit", sf_albion_pkg::SF_ATTR_PRIV_BIT, 2);
    eq("attr secure bit", sf_albion_pkg::SF_ATTR_SECURE_BIT, 3);    eq("attr instr bit", sf_albion_pkg::SF_ATTR_INSTR_BIT, 4);
    eq("attr rsvd bit", sf_albion_pkg::SF_ATTR_RSVD_BIT, 7);
    eq("ALP request width", sf_albion_pkg::SF_REQ_W, 236);  eq("ALP response width", sf_albion_pkg::SF_RSP_W, 148);
    eq("ALP request tag lsb", sf_albion_pkg::SF_REQ_TAG_LSB, 224);  eq("ALP request dom lsb", sf_albion_pkg::SF_REQ_DOM_LSB, 216);
    eq("ALP request addr lsb", sf_albion_pkg::SF_REQ_ADDR_LSB, 144);

    // ---- Citadel's own code points
    eq("R_MAX", sf_citadel_pkg::SF_CIT_R_MAX, 13);  eq("NSRC", sf_citadel_pkg::SF_CIT_NSRC, 16);
    eq("domain states are 0..3", {sf_citadel_pkg::SF_CIT_DS_INVALID, sf_citadel_pkg::SF_CIT_DS_SUSPENDED, sf_citadel_pkg::SF_CIT_DS_ACTIVE, sf_citadel_pkg::SF_CIT_DS_QUARANTINED}, 8'b00_01_10_11);

    // ---- policy table consistency: severity vs actions
    for (int s = 0; s < 16; s++) begin
      logic [1:0] sev; logic [4:0] act;
      sev = sf_citadel_pkg::SF_CIT_POLICY[s*8 + 5 +: 2];  act = sf_citadel_pkg::SF_CIT_POLICY[s*8 +: 5];
      eq($sformatf("policy %0d: reserved bit 7 is zero", s), sf_citadel_pkg::SF_CIT_POLICY[s*8 + 7], 0);
      if (sev == sf_citadel_pkg::SF_CIT_SEV_CORRECTED)     eq($sformatf("policy %0d corrected => no action", s), act, 0);
      if (sev == sf_citadel_pkg::SF_CIT_SEV_FATAL)         eq($sformatf("policy %0d fatal => safe state + report", s), act[sf_citadel_pkg::SF_CIT_ACT_SAFE_STATE] & act[sf_citadel_pkg::SF_CIT_ACT_REPORT], 1);
      if (sev != sf_citadel_pkg::SF_CIT_SEV_FATAL)         eq($sformatf("policy %0d non-fatal => no unconditional safe state", s), act[sf_citadel_pkg::SF_CIT_ACT_SAFE_STATE], 0);
      if (act[sf_citadel_pkg::SF_CIT_ACT_QUARANTINE])      eq($sformatf("policy %0d quarantine only for uncorrectable", s), sev, sf_citadel_pkg::SF_CIT_SEV_UNCORRECTABLE);
    end
    // the sources whose index is a queue number (fault manager QUEUE_IDX_SRC = 4, 5, 14) are exactly the abort-queue sources
    eq("queue sources 4,5,14 abort a queue", sf_citadel_pkg::SF_CIT_POLICY[4*8 + sf_citadel_pkg::SF_CIT_ACT_ABORT_Q] & sf_citadel_pkg::SF_CIT_POLICY[5*8 + sf_citadel_pkg::SF_CIT_ACT_ABORT_Q] & sf_citadel_pkg::SF_CIT_POLICY[14*8 + sf_citadel_pkg::SF_CIT_ACT_ABORT_Q], 1);
    eq("engine sources 8,9 reset an engine", sf_citadel_pkg::SF_CIT_POLICY[8*8 + sf_citadel_pkg::SF_CIT_ACT_RST_ENGINE] & sf_citadel_pkg::SF_CIT_POLICY[9*8 + sf_citadel_pkg::SF_CIT_ACT_RST_ENGINE], 1);
    eq("access violations (6,7) trigger no automatic containment", sf_citadel_pkg::SF_CIT_POLICY[6*8 +: 5] | sf_citadel_pkg::SF_CIT_POLICY[7*8 +: 5], 0);

    if (errors == 0) $display("CITADEL_TB_RESULT tb_citadel_pkg PASS checks=%0d", checks);
    else             $display("CITADEL_TB_RESULT tb_citadel_pkg FAIL errors=%0d checks=%0d", errors, checks);
    $finish;
  end
endmodule
