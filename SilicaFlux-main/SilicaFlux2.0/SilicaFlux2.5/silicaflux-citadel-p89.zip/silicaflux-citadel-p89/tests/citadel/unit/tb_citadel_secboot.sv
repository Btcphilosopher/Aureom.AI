// =============================================================================
//  tb_citadel_secboot.sv  --  unit test of the authenticated-boot gate
//  Two instances: DUT_S (strict: no configuration without an authenticated boot, 40-cycle verdict timeout)
//  and DUT_L (lenient: ALLOW_UNAUTH = 1, for bring-up).  This tests the POLICY around a verdict;
//  it says nothing about whether a verdict is truthful (that is the external verifier's job).
// =============================================================================
`timescale 1ns/1ps
module tb_citadel_secboot;
  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;
  logic rot = 1'b0, done = 1'b0, ok = 1'b0; logic [7:0] err = '0;
  logic [2:0] st_s, st_l; logic cfg_s, cfg_l, run_s, run_l, fail_s, fail_l, act_s, act_l; logic [7:0] err_s, err_l;
  sf_citadel_secboot #(.ALLOW_UNAUTH(1'b0), .BOOT_TIMEOUT(40)) dut_s (.clk_i(clk), .rst_ni(rst_n), .rot_present_i(rot), .boot_done_i(done), .boot_ok_i(ok),
    .boot_err_i(err), .state_o(st_s), .cfg_open_o(cfg_s), .fw_run_ok_o(run_s), .boot_fail_o(fail_s), .err_o(err_s), .rot_active_o(act_s));
  sf_citadel_secboot #(.ALLOW_UNAUTH(1'b1), .BOOT_TIMEOUT(0)) dut_l (.clk_i(clk), .rst_ni(rst_n), .rot_present_i(rot), .boot_done_i(done), .boot_ok_i(ok),
    .boot_err_i(err), .state_o(st_l), .cfg_open_o(cfg_l), .fw_run_ok_o(run_l), .boot_fail_o(fail_l), .err_o(err_l), .rot_active_o(act_l));
  // DUT_D: every parameter at its DEFAULT -- the default must be the fail-closed one (no configuration without authenticated boot)
  logic [2:0] st_d; logic cfg_d, run_d, fail_d, act_d; logic [7:0] err_d;
  sf_citadel_secboot dut_d (.clk_i(clk), .rst_ni(rst_n), .rot_present_i(rot), .boot_done_i(done), .boot_ok_i(ok),
    .boot_err_i(err), .state_o(st_d), .cfg_open_o(cfg_d), .fw_run_ok_o(run_d), .boot_fail_o(fail_d), .err_o(err_d), .rot_active_o(act_d));
  localparam logic [2:0] ABSENT = 0, WAIT = 1, AUTH = 2, FAILED = 3;
  integer errors = 0, checks = 0, pulses = 0;
  always @(negedge clk) if (fail_s) pulses <= pulses + 1;
  task automatic eq(input string what, input logic [63:0] got, input logic [63:0] exp);
    checks++; if (got !== exp) begin errors++; if (errors <= 20) $display("FAIL %s: got %0h expected %0h (t=%0t)", what, got, exp, $time); end
  endtask
  task automatic tick(input integer n); repeat (n) @(negedge clk); endtask
  task automatic reset(); @(negedge clk); rst_n <= 1'b0; #3 rst_n <= 1'b1; rot <= 1'b0; done <= 1'b0; ok <= 1'b0; err <= '0; tick(3); endtask

  initial begin : main
    #1 rst_n = 1'b0; tick(3); rst_n = 1'b1; tick(2);
    // ---- no authenticated boot integrated
    tick(3);
    eq("S: strict, no root of trust -> ABSENT", st_s, ABSENT);
    eq("S: strict ABSENT keeps configuration CLOSED", cfg_s, 1'b0);   eq("S: strict ABSENT: no firmware-run permission", run_s, 1'b0);
    eq("L: lenient ABSENT opens configuration (bring-up only)", cfg_l, 1'b1);  eq("L: ... and it is reported as ABSENT, not as authenticated", act_l, 1'b0);
    // ---- a root of trust appears: configuration closed until a verdict
    @(negedge clk); rot <= 1'b1; tick(3);
    eq("S: rot present -> WAIT", st_s, WAIT);   eq("S: WAIT keeps configuration closed", cfg_s, 1'b0);   eq("L: WAIT closes it again", cfg_l, 1'b0);
    @(negedge clk); ok <= 1'b1; tick(5);                                     // ok WITHOUT done: nothing opens
    eq("S: boot_ok without boot_done never opens anything", st_s, WAIT);  eq("S: ... configuration closed", cfg_s, 1'b0);
    // ---- genuine success
    @(negedge clk); done <= 1'b1; tick(3);
    eq("S: done+ok -> AUTH_OK", st_s, AUTH);  eq("S: configuration open", cfg_s, 1'b1);  eq("S: firmware may run", run_s, 1'b1);  eq("S: boot-in-force flag", act_s, 1'b1);
    eq("S: no failure pulse on success", pulses, 0);
    // ---- attestation withdrawn after AUTH_OK: fail closed
    @(negedge clk); ok <= 1'b0; tick(3);
    eq("S: loss of boot_ok after AUTH_OK -> FAILED", st_s, FAILED);  eq("S: configuration closed", cfg_s, 1'b0);  eq("S: firmware-run closed", run_s, 1'b0);
    eq("S: loss code", err_s, 8'hF3);  eq("S: exactly one failure pulse", pulses, 1);
    @(negedge clk); ok <= 1'b1; done <= 1'b1; tick(5);
    eq("S: FAILED is sticky: a later good verdict re-opens nothing", st_s, FAILED);  eq("S: ... still closed", cfg_s, 1'b0);  eq("S: ... still exactly one pulse", pulses, 1);
    // ---- recovery only by reset
    reset(); pulses = 0;
    @(negedge clk); rot <= 1'b1; tick(3);
    eq("S: after reset waits again", st_s, WAIT);
    @(negedge clk); done <= 1'b1; ok <= 1'b0; err <= 8'h42; tick(3);
    eq("S: done without ok -> FAILED", st_s, FAILED);  eq("S: verifier error code kept", err_s, 8'h42);  eq("S: one pulse", pulses, 1);
    reset(); pulses = 0;
    @(negedge clk); rot <= 1'b1; done <= 1'b1; ok <= 1'b1; err <= 8'h07; tick(3);
    eq("S: ok together with an error code is a contradiction -> FAILED", st_s, FAILED);  eq("S: error code kept", err_s, 8'h07);
    reset(); pulses = 0;
    @(negedge clk); rot <= 1'b1; done <= 1'b1; ok <= 1'b0; err <= 8'd0; tick(3);
    eq("S: done without ok and without code -> FAILED", st_s, FAILED);  eq("S: generic not-ok code", err_s, 8'hF4);
    // ---- verdict timeout
    reset(); pulses = 0;
    @(negedge clk); rot <= 1'b1; tick(30);
    eq("S: still waiting before the timeout", st_s, WAIT);
    tick(20);
    eq("S: verdict timeout -> FAILED", st_s, FAILED);  eq("S: timeout code", err_s, 8'hF1);  eq("S: one pulse", pulses, 1);
    // ---- lenient instance never times out and never opens on a missing verdict
    eq("L: no timeout configured: still waiting, configuration closed", {st_l, cfg_l}, {WAIT, 1'b0});
    // ---- a good boot end-to-end after a reset
    reset(); pulses = 0;
    @(negedge clk); rot <= 1'b1; tick(3);  @(negedge clk); done <= 1'b1; ok <= 1'b1; tick(3);
    eq("S: authenticated after reset", st_s, AUTH);  eq("S: lenient instance agrees", st_l, AUTH);
    // ---- reset closes everything immediately, even from AUTH_OK
    @(negedge clk); rst_n <= 1'b0; #2;
    eq("S: reset closes configuration", cfg_s, 1'b0);  eq("S: reset closes firmware-run", run_s, 1'b0);
    #3 rst_n <= 1'b1; tick(3);

    // ---- defaults are fail-closed
    reset();  tick(3);
    eq("D: default parameters, no root of trust: ABSENT", st_d, ABSENT);
    eq("D: default ALLOW_UNAUTH is 0: configuration stays CLOSED", cfg_d, 1'b0);   eq("D: ... and no firmware-run permission", run_d, 1'b0);

    // ---- NO DOWNGRADE: a root of trust that was seen and is then lost while waiting FAILS CLOSED, never ABSENT
    // (a) the block appears after reset, then disappears
    reset(); pulses = 0;
    @(negedge clk); rot <= 1'b1; tick(3);
    eq("S: (a) rot present -> WAIT", st_s, WAIT);
    @(negedge clk); rot <= 1'b0; tick(3);
    eq("S: (a) rot withdrawn while waiting -> FAILED (not ABSENT)", st_s, FAILED);   eq("S: (a) lost code", err_s, 8'hF3);
    eq("S: (a) exactly one failure pulse", pulses, 1);   eq("S: (a) configuration closed", cfg_s, 1'b0);
    eq("L: (a) the lenient instance fails closed too, it does NOT fall back to ABSENT and open",  {st_l, cfg_l, run_l}, {FAILED, 1'b0, 1'b0});
    eq("D: (a) the default instance fails closed too", {st_d, cfg_d, run_d}, {FAILED, 1'b0, 1'b0});
    // (b) the block is present from the very first cycle after reset, then disappears
    @(negedge clk); rst_n <= 1'b0; rot <= 1'b1; done <= 1'b0; ok <= 1'b0; err <= '0; #3 rst_n <= 1'b1; pulses = 0;
    tick(2);
    eq("S: (b) present from reset -> WAIT", st_s, WAIT);
    @(negedge clk); rot <= 1'b0; tick(3);
    eq("S: (b) withdrawn -> FAILED", st_s, FAILED);   eq("S: (b) lost code", err_s, 8'hF3);
    eq("L: (b) lenient instance: FAILED, closed", {st_l, cfg_l, run_l}, {FAILED, 1'b0, 1'b0});
    // (c) a block that was never present still gives ABSENT (the only way into ABSENT)
    reset(); tick(3);
    eq("S: (c) never present -> ABSENT", st_s, ABSENT);

    tick(3);
    if (errors == 0) $display("CITADEL_TB_RESULT tb_citadel_secboot PASS checks=%0d", checks);
    else             $display("CITADEL_TB_RESULT tb_citadel_secboot FAIL errors=%0d checks=%0d", errors, checks);
    $finish;
  end
endmodule
