// =============================================================================
//  tb_citadel_system.sv  --  directed system test of sf_citadel_security
// -----------------------------------------------------------------------------
//  Follows the verification list of the Citadel brief:
//    allowed accesses, denied accesses, boundary-spanning DMA, descriptor
//    overflow, incorrect domain context, privileged register writes, reset,
//    ECC errors, concurrent faults, engine isolation.
//  Plus: telemetry privacy, safe state, queue abort, key zeroisation requests,
//  DFT lockout.  Every expected value is written down in the test, not derived
//  from the DUT.  Prints exactly one CITADEL_TB_RESULT line.
// =============================================================================
`timescale 1ns/1ps

module tb_citadel_system;
  localparam int unsigned NDOM = 4, NW = 2, NP = 3, NDEV = 7, NQ = 8, NKEY = 4, AW = 64, LEN_W = 32;
  localparam int unsigned SLOT_W = 2, WIN_W = 1, PORT_W = 2;
  localparam int TELP = 2;     // the telemetry source port wired to the management plane (TEL_PRIV_PORTS = 3'b100)

  // reason codes (sf_citadel_pkg), ALP statuses (sf_albion_pkg) -- restated so a drift is a test failure
  localparam logic [3:0] R_OK = 0, R_BAD_OP = 1, R_BAD_ATTR = 2, R_BAD_DOM = 3, R_BAD_LEN = 4, R_OVERFLOW = 5,
                         R_DOM_STATE = 6, R_NOMAP = 7, R_PERM = 8, R_DEV = 9, R_QUEUE = 10, R_PRIV = 11,
                         R_LOCKDOWN = 12, R_ISOLATED = 13;
  localparam logic [3:0] CS_OK = 0, CS_BAD_CMD = 1, CS_BAD_PRIV = 2, CS_BAD_ARG = 3, CS_BAD_SLOT = 4, CS_EXISTS = 5,
                         CS_OVERLAP = 6, CS_LOCKED = 7, CS_BAD_STATE = 8, CS_NOT_AUTH = 9;
  localparam logic [3:0] OP_ENROLL = 1, OP_SET_WINDOW = 2, OP_CLR_WINDOW = 3, OP_SET_DEVPRM = 4, OP_SET_QPRM = 5,
                         OP_SET_KEYPRM = 6, OP_SET_STATE = 7, OP_REVOKE = 8, OP_BIND_PORT = 9, OP_LOCK = 10,
                         OP_CLR_QHOLD = 11, OP_CLR_ISOL = 12, OP_CLR_SAFE = 13, OP_SET_THRESH = 14, OP_CLR_CNT = 15;
  localparam logic [3:0] RD = 1, WR = 2;
  localparam logic [63:0] A0 = 64'h0000_0040_0000_0000;   // domain A window 0  (64 KiB)
  localparam logic [63:0] A1 = 64'h0000_0040_0001_0000;   // domain A window 1  (64 KiB, read-only, ADJACENT to window 0)
  localparam logic [63:0] B0 = 64'h0000_0040_0010_0000;   // domain B
  localparam logic [63:0] C0 = 64'h0000_0040_0020_0000;   // domain C
  localparam logic [63:0] M0 = 64'h0000_0050_0000_0000;   // MGMT
  localparam logic [63:0] DEV_NET = 64'h0000_0001_3000_0000, DEV_VIRTIO = 64'h0000_0001_4000_0000,
                          DEV_SEC = 64'h0000_0001_6000_0000, DEV_DMA = 64'h0000_0001_2000_0000;

  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;

  // ---- DUT ports
  logic cfg_en = 1'b1, dft = 1'b0, cmd_valid = 1'b0, cmd_priv = 1'b0;
  logic [3:0] cmd_op = '0;
  logic [7:0] cmd_dom = '0, cmd_arg = '0, cmd_flags = '0;
  logic [SLOT_W-1:0] cmd_slot = '0;
  logic [WIN_W-1:0] cmd_win = '0;
  logic [PORT_W-1:0] cmd_port = '0;
  logic [63:0] cmd_d0 = '0, cmd_d1 = '0;
  logic rsp_valid; logic [3:0] rsp_status;
  logic [NP-1:0] chk_valid = '0, chk_commit = '0;
  logic [NP*8-1:0] chk_dom = '0, chk_attr = '0, chk_idx = '0;
  logic [NP*4-1:0] chk_op = '0;
  logic [NP*AW-1:0] chk_addr = '0;
  logic [NP*LEN_W-1:0] chk_len = '0;
  logic [NP*2-1:0] chk_cls = '0;
  logic [NP-1:0] chk_permit;
  logic [NP*4-1:0] chk_status, chk_reason;
  logic [15:0] ev = '0, ev_dvld = '0;
  logic [16*8-1:0] ev_dom = '0, ev_idx = '0;
  logic [3:0] ev_avld = '0;
  logic [4*AW-1:0] ev_addr = '0;
  logic abort_valid; logic [NQ-1:0] abort_mask; logic [NP-1:0] eng_rst, eng_done = '0, port_isol; logic [NQ-1:0] qhold;
  logic lockdown, safe_entry, irq, zero_valid, zero_all; logic [NKEY-1:0] zero_mask;
  logic tel_valid = 1'b0, tel_priv = 1'b0; logic [7:0] tel_addr = '0, tel_dom = '0; logic [PORT_W-1:0] tel_src = '0;
  logic tel_rvalid, tel_err; logic [31:0] tel_rdata;
  logic [NDOM*2-1:0] slot_state; logic [NDOM*NKEY-1:0] kmask; logic cfg_lock;

  sf_citadel_security #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(NDEV), .NQ(NQ), .NKEY(NKEY), .AW(AW), .LEN_W(LEN_W),
                        .DMA_PORTS(3'b100), .TEL_PRIV_PORTS(3'b100)) dut (
    .clk_i(clk), .rst_ni(rst_n), .cfg_en_i(cfg_en), .dft_active_i(dft),
    .rot_present_i(1'b0), .boot_done_i(1'b0), .boot_ok_i(1'b0), .boot_err_i(8'd0), .fw_run_ok_o(), .boot_state_o(), .boot_err_o(),
    .cmd_valid_i(cmd_valid), .cmd_op_i(cmd_op), .cmd_dom_i(cmd_dom), .cmd_priv_i(cmd_priv), .cmd_slot_i(cmd_slot),
    .cmd_win_i(cmd_win), .cmd_port_i(cmd_port), .cmd_arg_dom_i(cmd_arg), .cmd_flags_i(cmd_flags),
    .cmd_data0_i(cmd_d0), .cmd_data1_i(cmd_d1), .rsp_valid_o(rsp_valid), .rsp_status_o(rsp_status),
    .chk_valid_i(chk_valid), .chk_commit_i(chk_commit), .chk_dom_i(chk_dom), .chk_op_i(chk_op), .chk_attr_i(chk_attr),
    .chk_addr_i(chk_addr), .chk_len_i(chk_len), .chk_cls_i(chk_cls), .chk_idx_i(chk_idx),
    .chk_permit_o(chk_permit), .chk_status_o(chk_status), .chk_reason_o(chk_reason),
    .ev_i(ev), .ev_dom_vld_i(ev_dvld), .ev_dom_i(ev_dom), .ev_idx_i(ev_idx), .ev_addr_vld_i(ev_avld), .ev_addr_i(ev_addr),
    .abort_valid_o(abort_valid), .abort_mask_o(abort_mask), .eng_rst_o(eng_rst), .eng_rst_done_i(eng_done),
    .qhold_o(qhold), .port_isol_o(port_isol), .lockdown_o(lockdown), .safe_entry_o(safe_entry), .irq_o(irq),
    .zero_valid_o(zero_valid), .zero_mask_o(zero_mask), .zero_all_o(zero_all),
    .tel_valid_i(tel_valid), .tel_addr_i(tel_addr), .tel_dom_i(tel_dom), .tel_priv_i(tel_priv), .tel_src_i(tel_src),
    .tel_rvalid_o(tel_rvalid), .tel_rdata_o(tel_rdata), .tel_err_o(tel_err),
    .slot_state_o(slot_state), .slot_id_o(), .bind_o(), .kmask_o(kmask), .cfg_lock_o(cfg_lock));

  // ---- bookkeeping
  integer errors = 0, checks = 0;
  integer exp_viol = 0, exp_dma = 0;          // independent tally of denials the counters must show
  task automatic expect_eq(input string what, input logic [63:0] got, input logic [63:0] exp);
    checks++;
    if (got !== exp) begin errors++; if (errors <= 40) $display("FAIL %s: got %0h expected %0h  (t=%0t)", what, got, exp, $time); end
  endtask

  // sticky pulse monitors.  The pulse outputs are registered (they change at the rising edge), so they are sampled
  // mid-cycle.  Every seen_* variable has exactly ONE driver (this process); clear_seen() only raises a request flag.
  logic [NQ-1:0] seen_abort = '0; logic [NP-1:0] seen_eng = '0; logic seen_zero = 1'b0, seen_zero_all = 1'b0, seen_safe = 1'b0;
  logic [NKEY-1:0] seen_zero_mask = '0;
  logic clr_seen_req = 1'b0;
  always @(negedge clk) begin
    if (clr_seen_req) begin
      seen_abort <= '0; seen_eng <= '0; seen_zero <= 1'b0; seen_zero_mask <= '0; seen_zero_all <= 1'b0; seen_safe <= 1'b0;
    end else begin
      if (abort_valid) seen_abort <= seen_abort | abort_mask;
      seen_eng <= seen_eng | eng_rst;
      if (zero_valid) begin seen_zero <= 1'b1; seen_zero_mask <= seen_zero_mask | zero_mask; end
      if (zero_all) seen_zero_all <= 1'b1;
      if (safe_entry) seen_safe <= 1'b1;
    end
  end
  task automatic clear_seen();
    @(negedge clk); clr_seen_req <= 1'b1;
    @(negedge clk); clr_seen_req <= 1'b0;      // the monitor clears at this edge; call it only while no event is in flight
    @(negedge clk);
  endtask

  // ---- driver tasks
  task automatic tick(input integer n);
    repeat (n) @(negedge clk);
  endtask

  task automatic cmd(input [3:0] op, input [7:0] rdom, input rpriv, input integer slot, input integer win, input integer port,
                     input [7:0] argdom, input [7:0] flags, input [63:0] d0, input [63:0] d1, input [3:0] exp);
    @(negedge clk);
    cmd_valid <= 1'b1; cmd_op <= op; cmd_dom <= rdom; cmd_priv <= rpriv; cmd_slot <= slot[SLOT_W-1:0]; cmd_win <= win[WIN_W-1:0];
    cmd_port <= port[PORT_W-1:0]; cmd_arg <= argdom; cmd_flags <= flags; cmd_d0 <= d0; cmd_d1 <= d1;
    @(negedge clk);
    expect_eq($sformatf("cmd op=%0d rsp_valid", op), rsp_valid, 1'b1);
    expect_eq($sformatf("cmd op=%0d status", op), rsp_status, exp);
    if (exp == CS_BAD_PRIV || exp == CS_NOT_AUTH || exp == CS_LOCKED) exp_viol++;     // privileged-command denials are access violations
    cmd_valid <= 1'b0;
  endtask
  task automatic root(input [3:0] op, input integer slot, input integer win, input integer port, input [7:0] argdom,
                      input [7:0] flags, input [63:0] d0, input [63:0] d1);
    cmd(op, 8'h00, 1'b1, slot, win, port, argdom, flags, d0, d1, CS_OK);
  endtask

  // permission query on port p (commit pulse: counted once).
  // DUT inputs are ALWAYS assigned as WHOLE vectors (from shadow copies).  Writing a variable-indexed slice of a DUT-input
  // vector from a task defeats Verilator 5.020's change detection for the combinational logic behind it (observed: the
  // checker kept evaluating stale inputs), so slices are only ever written in TB-private shadow variables.
  logic [NP*8-1:0]     sh_dom = '0, sh_attr = '0, sh_idx = '0;
  logic [NP*4-1:0]     sh_op = '0;
  logic [NP*AW-1:0]    sh_addr = '0;
  logic [NP*LEN_W-1:0] sh_len = '0;
  logic [NP*2-1:0]     sh_cls = '0;
  task automatic chk(input integer p, input [7:0] dom, input [3:0] op, input [7:0] attr, input [63:0] addr, input [31:0] len,
                     input [1:0] cls, input [7:0] idx, input [3:0] exp_reason, input string what);
    logic [3:0] exp_status;
    logic [NP-1:0] m;
    @(negedge clk);
    m = '0; m[p] = 1'b1;
    sh_dom[p*8 +: 8] = dom; sh_op[p*4 +: 4] = op; sh_attr[p*8 +: 8] = attr; sh_addr[p*AW +: AW] = addr;
    sh_len[p*LEN_W +: LEN_W] = len; sh_cls[p*2 +: 2] = cls; sh_idx[p*8 +: 8] = idx;
    chk_dom <= sh_dom; chk_op <= sh_op; chk_attr <= sh_attr; chk_addr <= sh_addr; chk_len <= sh_len; chk_cls <= sh_cls; chk_idx <= sh_idx;
    chk_valid <= m; chk_commit <= m;
    #1;
    exp_status = (exp_reason == R_OK) ? 4'd0 : (exp_reason == R_BAD_OP) ? 4'd3 : (exp_reason == R_BAD_ATTR) ? 4'd6 : 4'd2;
    expect_eq({what, " reason"}, chk_reason[p*4 +: 4], exp_reason);
    expect_eq({what, " permit"}, chk_permit[p], (exp_reason == R_OK));
    expect_eq({what, " status"}, chk_status[p*4 +: 4], exp_status);
    if (exp_reason != R_OK) begin exp_viol++; if (p == 2) exp_dma++; end
    @(negedge clk);
    chk_valid <= '0; chk_commit <= '0;
  endtask
  task automatic chkA(input integer p, input [7:0] dom, input [3:0] op, input [63:0] addr, input [31:0] len, input [3:0] exp, input string what);
    chk(p, dom, op, 8'h00, addr, len, 2'd0, 8'd0, exp, what);
  endtask

  logic [15:0]       sh_ev_dvld = '0;
  logic [16*8-1:0]   sh_ev_dom = '0, sh_ev_idx = '0;
  logic [3:0]        sh_ev_avld = '0;
  logic [4*AW-1:0]   sh_ev_addr = '0;
  task automatic evp(input integer src, input dvld, input [7:0] dom, input [7:0] idx, input avld, input [63:0] addr);
    logic [15:0] m;
    @(negedge clk);
    m = '0; m[src] = 1'b1;
    sh_ev_dvld = '0; sh_ev_dom = '0; sh_ev_idx = '0; sh_ev_avld = '0; sh_ev_addr = '0;
    sh_ev_dvld[src] = dvld; sh_ev_dom[src*8 +: 8] = dom; sh_ev_idx[src*8 +: 8] = idx;
    if (src < 4) begin sh_ev_avld[src] = avld; sh_ev_addr[src*AW +: AW] = addr; end
    ev <= m; ev_dvld <= sh_ev_dvld; ev_dom <= sh_ev_dom; ev_idx <= sh_ev_idx; ev_avld <= sh_ev_avld; ev_addr <= sh_ev_addr;
    @(negedge clk);
    ev <= '0; ev_dvld <= '0; ev_avld <= '0;
  endtask

  logic [31:0] tel_data; logic tel_error;
  task automatic tel(input [7:0] addr, input [7:0] dom, input priv, input integer src);
    @(negedge clk);
    tel_valid <= 1'b1; tel_addr <= addr; tel_dom <= dom; tel_priv <= priv; tel_src <= src[PORT_W-1:0];
    @(negedge clk);
    tel_valid <= 1'b0;
    tel_data = tel_rdata; tel_error = tel_err;
    expect_eq("tel rvalid", tel_rvalid, 1'b1);
    // an error never carries data
    if (tel_error) begin expect_eq("tel error => zero data", tel_data, 32'd0); exp_viol++; end   // a denied read is an access violation
  endtask

  // two ports present a request in the SAME cycle (both commit): both denials must be counted
  task automatic chk_pair(input integer pa, input [7:0] da, input [63:0] aa, input integer pb, input [7:0] db, input [63:0] ab, input integer ndma);
    logic [NP-1:0] m;
    @(negedge clk);
    m = '0; m[pa] = 1'b1; m[pb] = 1'b1;
    sh_dom[pa*8 +: 8] = da; sh_op[pa*4 +: 4] = RD; sh_attr[pa*8 +: 8] = 8'h00; sh_addr[pa*AW +: AW] = aa; sh_len[pa*LEN_W +: LEN_W] = 4; sh_cls[pa*2 +: 2] = 2'd0;
    sh_dom[pb*8 +: 8] = db; sh_op[pb*4 +: 4] = RD; sh_attr[pb*8 +: 8] = 8'h00; sh_addr[pb*AW +: AW] = ab; sh_len[pb*LEN_W +: LEN_W] = 4; sh_cls[pb*2 +: 2] = 2'd0;
    chk_dom <= sh_dom; chk_op <= sh_op; chk_attr <= sh_attr; chk_addr <= sh_addr; chk_len <= sh_len; chk_cls <= sh_cls;
    chk_valid <= m; chk_commit <= m;
    #1;
    expect_eq("pair: port a denied", chk_permit[pa], 1'b0);
    expect_eq("pair: port b denied", chk_permit[pb], 1'b0);
    exp_viol += 2; exp_dma += ndma;
    @(negedge clk);
    chk_valid <= '0; chk_commit <= '0;
  endtask
  // a denied request HELD for n cycles with ONE commit pulse is one violation
  task automatic chk_held(input integer p, input [7:0] dom, input [63:0] addr, input integer n);
    logic [NP-1:0] m;
    @(negedge clk);
    m = '0; m[p] = 1'b1;
    sh_dom[p*8 +: 8] = dom; sh_op[p*4 +: 4] = RD; sh_attr[p*8 +: 8] = 8'h00; sh_addr[p*AW +: AW] = addr; sh_len[p*LEN_W +: LEN_W] = 4; sh_cls[p*2 +: 2] = 2'd0;
    chk_dom <= sh_dom; chk_op <= sh_op; chk_attr <= sh_attr; chk_addr <= sh_addr; chk_len <= sh_len; chk_cls <= sh_cls;
    chk_valid <= m; chk_commit <= m;
    @(negedge clk);
    chk_commit <= '0;                         // still valid, no longer a commit
    repeat (n) @(negedge clk);
    chk_valid <= '0;
    exp_viol += 1; if (p == 2) exp_dma += 1;
  endtask

  task automatic evburst(input [15:0] mask, input dvld, input [7:0] dom, input [7:0] idx, input [63:0] addr);
    @(negedge clk);
    sh_ev_dvld = '0; sh_ev_dom = '0; sh_ev_idx = '0; sh_ev_avld = '0; sh_ev_addr = '0;
    for (int k = 0; k < 16; k++) begin sh_ev_dvld[k] = dvld; sh_ev_dom[k*8 +: 8] = dom; sh_ev_idx[k*8 +: 8] = idx; end
    for (int k = 0; k < 4; k++) begin sh_ev_avld[k] = 1'b1; sh_ev_addr[k*AW +: AW] = addr; end
    ev <= mask; ev_dvld <= sh_ev_dvld; ev_dom <= sh_ev_dom; ev_idx <= sh_ev_idx; ev_avld <= sh_ev_avld; ev_addr <= sh_ev_addr;
  endtask
  task automatic evstop();
    @(negedge clk); ev <= '0; ev_dvld <= '0; ev_avld <= '0;
  endtask

  task automatic reset_dut();
    @(negedge clk); rst_n <= 1'b0; cmd_valid <= 1'b0; chk_valid <= '0; chk_commit <= '0; ev <= '0; tel_valid <= 1'b0;
    #3; rst_n <= 1'b1; @(negedge clk);
  endtask

  // ---- configuration used by several phases
  task automatic configure();
    // bindings: port0 <- {MGMT, A}, port1 <- {MGMT, B}, port2 (DMA) <- all
    root(OP_BIND_PORT, 0, 0, 0, 0, 0, 64'b0011, 0);
    root(OP_BIND_PORT, 0, 0, 1, 0, 0, 64'b0101, 0);
    root(OP_BIND_PORT, 0, 0, 2, 0, 0, 64'b1111, 0);
    root(OP_ENROLL, 0, 0, 0, 8'h01, 8'h03, 0, 0);          // slot 0 = MGMT, may use priv + secure attributes
    root(OP_ENROLL, 1, 0, 0, 8'h10, 8'h00, 0, 0);          // slot 1 = tenant A
    root(OP_ENROLL, 2, 0, 0, 8'h11, 8'h00, 0, 0);          // slot 2 = tenant B
    root(OP_ENROLL, 3, 0, 0, 8'h12, 8'h00, 0, 0);          // slot 3 = tenant C
    // windows  (flags: R=1 W=2 X=4 EXCL=8)
    root(OP_SET_WINDOW, 1, 0, 0, 0, 8'b1011, A0, A0 + 64'hFFFF);   // A rw, exclusive
    root(OP_SET_WINDOW, 1, 1, 0, 0, 8'b1001, A1, A1 + 64'hFFFF);   // A r , exclusive, ADJACENT to window 0
    root(OP_SET_WINDOW, 2, 0, 0, 0, 8'b1011, B0, B0 + 64'hFFFF);
    root(OP_SET_WINDOW, 3, 0, 0, 0, 8'b1011, C0, C0 + 64'hFFFF);
    root(OP_SET_WINDOW, 0, 0, 0, 0, 8'b0111, M0, M0 + 64'hFFFF);   // MGMT rwx, shared
    // device / queue / key permissions
    root(OP_SET_DEVPRM, 1, 0, 0, 0, 0, 64'b0000100, 64'b0000100);   // A: network (dev 2) rd+wr
    root(OP_SET_DEVPRM, 2, 0, 0, 0, 0, 64'b0001000, 64'b0000000);   // B: virtio (dev 3) read-only
    root(OP_SET_DEVPRM, 0, 0, 0, 0, 0, 64'h7F, 64'h7F);             // MGMT: every device
    root(OP_SET_QPRM, 1, 0, 0, 0, 0, 64'b00000011, 0);              // A: queues 0,1
    root(OP_SET_QPRM, 2, 0, 0, 0, 0, 64'b00001100, 0);              // B: queues 2,3
    root(OP_SET_QPRM, 3, 0, 0, 0, 0, 64'b00010000, 0);              // C: queue 4
    root(OP_SET_QPRM, 0, 0, 0, 0, 0, 64'hFF, 0);
    root(OP_SET_KEYPRM, 1, 0, 0, 0, 0, 64'b0001, 0);                // A: key 0
    root(OP_SET_KEYPRM, 2, 0, 0, 0, 0, 64'b0010, 0);                // B: key 1
    root(OP_SET_KEYPRM, 3, 0, 0, 0, 0, 64'b0100, 0);                // C: key 2
    root(OP_SET_KEYPRM, 0, 0, 0, 0, 0, 64'b1000, 0);                // MGMT: key 3
    for (int s = 0; s < 4; s++) root(OP_SET_STATE, s, 0, 0, 0, 8'd2, 0, 0);   // all ACTIVE
    tick(2);
  endtask


  initial begin : main
    logic [31:0] v0, v1, d0v, d1v;
    #1 rst_n <= 1'b0; tick(3); rst_n <= 1'b1; tick(2);

    // =======================================================================
    // P0  DEFAULT DENY after reset
    // =======================================================================
    chkA(0, 8'h10, RD, A0, 16, R_BAD_DOM, "P0 default deny A");
    chkA(2, 8'h01, WR, M0, 16, R_BAD_DOM, "P0 default deny MGMT (DMA port)");
    tick(2);
    tel(8'h10, 8'h00, 1'b1, TELP);  expect_eq("P0 access-violation counter", tel_data, exp_viol); expect_eq("P0 tel ok", tel_error, 1'b0);
    tel(8'h11, 8'h00, 1'b1, TELP);  expect_eq("P0 invalid-DMA counter", tel_data, exp_dma);
    tel(8'h00, 8'h00, 1'b1, TELP);  expect_eq("P0 id register", tel_data[31:16], 16'hC17A);

    // =======================================================================
    // P1  PRIVILEGED CONFIGURATION: refusals, then provisioning
    // =======================================================================
    cmd(OP_ENROLL, 8'h10, 1'b1, 1, 0, 0, 8'h10, 8'h00, 0, 0, CS_BAD_PRIV);           // a tenant cannot configure
    cmd(OP_ENROLL, 8'h00, 1'b0, 1, 0, 0, 8'h10, 8'h00, 0, 0, CS_BAD_PRIV);           // ROOT label without the privilege attribute
    cmd(OP_ENROLL, 8'h77, 1'b1, 1, 0, 0, 8'h10, 8'h00, 0, 0, CS_BAD_PRIV);           // unknown requester label
    cmd(4'd0, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_BAD_CMD);                         // invalid opcode from a privileged requester
    cmd(4'd0, 8'h10, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_BAD_PRIV);                        // ... from an unprivileged one: reveals nothing about opcodes
    cmd(OP_SET_WINDOW, 8'h00, 1'b1, 1, 0, 0, 0, 8'b0011, A0, A0 + 1, CS_BAD_SLOT);   // slot not enrolled yet
    cfg_en <= 1'b0;
    cmd(OP_ENROLL, 8'h00, 1'b1, 1, 0, 0, 8'h10, 8'h00, 0, 0, CS_NOT_AUTH);           // boot not authorised: configuration port closed
    cfg_en <= 1'b1;
    chkA(0, 8'h10, RD, A0, 16, R_BAD_DOM, "P1 still default deny after refused commands");
    configure();
    cmd(OP_ENROLL, 8'h01, 1'b1, 0, 0, 0, 8'h05, 8'h00, 0, 0, CS_BAD_PRIV);          // MGMT cannot create system domains
    cmd(OP_BIND_PORT, 8'h01, 1'b1, 0, 0, 1, 0, 0, 64'hF, 0, CS_BAD_PRIV);            // ... nor bind ports
    cmd(OP_SET_WINDOW, 8'h01, 1'b1, 0, 0, 0, 0, 8'b0001, M0, M0 + 1, CS_BAD_PRIV);   // ... nor touch a system slot
    cmd(OP_CLR_SAFE, 8'h01, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_BAD_PRIV);
    cmd(OP_SET_WINDOW, 8'h01, 1'b1, 2, 1, 0, 0, 8'b0001, A0, A0 + 15, CS_OVERLAP);   // overlap with A's EXCLUSIVE window refused by hardware
    cmd(OP_SET_WINDOW, 8'h00, 1'b1, 2, 1, 0, 0, 8'b0011, A0 + 8, A0 + 15, CS_OVERLAP); // ... even for ROOT
    cmd(OP_SET_WINDOW, 8'h00, 1'b1, 2, 1, 0, 0, 8'b1011, DEV_NET, DEV_NET + 15, CS_BAD_ARG); // exclusive window over a device region
    cmd(OP_SET_WINDOW, 8'h00, 1'b1, 2, 1, 0, 0, 8'b0011, 64'h100, 64'h10, CS_BAD_ARG); // inverted window
    cmd(OP_ENROLL, 8'h00, 1'b1, 3, 0, 0, 8'h10, 8'h00, 0, 0, CS_EXISTS);            // occupied slot / duplicate id
    cmd(OP_SET_DEVPRM, 8'h00, 1'b1, 1, 0, 0, 0, 0, 64'h80, 0, CS_BAD_ARG);           // mask bit beyond NDEV

    // =======================================================================
    // P2  ALLOWED ACCESSES
    // =======================================================================
    chkA(0, 8'h10, RD, A0,               1,       R_OK, "P2 A first byte");
    chkA(0, 8'h10, WR, A0,               1,       R_OK, "P2 A write first byte");
    chkA(0, 8'h10, RD, A0 + 64'hFFF0,    16,      R_OK, "P2 A last 16 bytes");
    chkA(0, 8'h10, RD, A0,               32'h10000, R_OK, "P2 A whole window");
    chkA(0, 8'h10, RD, A1 + 64'hFFFF,    1,       R_OK, "P2 A last byte of window 1");
    chkA(1, 8'h11, WR, B0 + 64'h100,     64,      R_OK, "P2 B write");
    chkA(2, 8'h12, WR, C0,               4096,    R_OK, "P2 C DMA write (port 2)");
    chkA(2, 8'h10, RD, A0,               4096,    R_OK, "P2 A DMA read (port 2)");
    chkA(0, 8'h10, RD, DEV_NET,          4,       R_OK, "P2 A reads network device");
    chkA(0, 8'h10, WR, DEV_NET,          4,       R_OK, "P2 A writes network device");
    chkA(1, 8'h11, RD, DEV_VIRTIO,       4,       R_OK, "P2 B reads virtio");
    chk(0, 8'h01, RD, 8'h04, DEV_DMA, 4, 2'd0, 8'd0, R_OK, "P2 MGMT priv read of the DMA registers");
    chk(0, 8'h01, WR, 8'h0C, DEV_SEC, 4, 2'd0, 8'd0, R_OK, "P2 MGMT priv+secure write of the security registers");
    chk(0, 8'h10, RD, 8'h00, 64'd0, 32'd0, 2'd1, 8'd0, R_OK, "P2 A queue 0");
    chk(0, 8'h10, WR, 8'h00, 64'd0, 32'd0, 2'd1, 8'd1, R_OK, "P2 A queue 1");

    // =======================================================================
    // P3  DENIED ACCESSES (reason codes are the privileged audit view)
    // =======================================================================
    chkA(0, 8'h10, RD, B0, 4, R_NOMAP, "P3 A reads B's window");
    chkA(0, 8'h10, RD, C0, 4, R_NOMAP, "P3 A reads C's window");
    chkA(1, 8'h11, WR, A0, 4, R_NOMAP, "P3 B writes A's window");
    // boundary-spanning transfers: A0 and A1 are ADJACENT and both allow reads, yet a range across them is refused
    chkA(0, 8'h10, RD, A0 + 64'hFFFF, 2,        R_NOMAP, "P3 spans window0 -> window1");
    chkA(0, 8'h10, RD, A0 - 1,        2,        R_NOMAP, "P3 starts one byte below window");
    chkA(0, 8'h10, RD, A0 + 64'hFFF1, 16,       R_NOMAP, "P3 ends one byte past window0");
    chkA(0, 8'h10, RD, A1 + 64'hFFF8, 16,       R_NOMAP, "P3 runs past the end of window1");
    chkA(0, 8'h10, RD, A0,            32'h10001, R_NOMAP, "P3 one byte longer than window0");
    chkA(0, 8'h10, WR, A1,            4,        R_PERM,  "P3 write to the read-only window");
    // descriptor length / overflow
    chkA(0, 8'h10, RD, A0,            0,        R_BAD_LEN, "P3 zero length");
    chkA(0, 8'h10, RD, 64'hFFFF_FFFF_FFFF_FFF0, 32'h20, R_OVERFLOW, "P3 wraps the 64-bit space");
    chkA(0, 8'h10, RD, 64'hFFFF_FFFF_FFFF_FFFF, 2,      R_OVERFLOW, "P3 last byte + 1");
    chkA(0, 8'h10, RD, 64'hFFFF_FFFF_FFFF_FFFF, 1,      R_NOMAP,    "P3 last byte exactly (no wrap, no window)");
    chkA(0, 8'h10, RD, 64'hFFFF_FFFF_8000_0000, 32'hFFFF_FFFF, R_OVERFLOW, "P3 maximal length descriptor near the top");
    chkA(0, 8'h10, RD, 64'h10,        32'hFFFF_FFFF, R_NOMAP,   "P3 maximal length, no wrap, no window");
    // incorrect domain context: the label is initiator-supplied and is checked against the PHYSICAL port
    chkA(0, 8'h11, RD, B0,   4, R_BAD_DOM, "P3 B's label on A's port");
    chkA(1, 8'h10, RD, A0,   4, R_BAD_DOM, "P3 A's label on B's port");
    chkA(0, 8'h12, RD, C0,   4, R_BAD_DOM, "P3 C's label on a port C is not bound to");
    chkA(0, 8'h77, RD, A0,   4, R_BAD_DOM, "P3 unknown domain");
    chkA(0, 8'hFF, RD, A0,   4, R_BAD_DOM, "P3 invalid domain id");
    chkA(0, 8'h00, RD, A0,   4, R_BAD_DOM, "P3 ROOT label on the data plane (not enrolled)");
    // attributes and opcodes
    chk(0, 8'h10, RD, 8'h04, A0, 4, 2'd0, 8'd0, R_PRIV,     "P3 tenant claims privilege");
    chk(0, 8'h10, RD, 8'h08, A0, 4, 2'd0, 8'd0, R_PRIV,     "P3 tenant claims secure");
    chk(0, 8'h10, RD, 8'h80, A0, 4, 2'd0, 8'd0, R_BAD_ATTR, "P3 reserved attribute bit");
    chk(0, 8'h10, RD, 8'h03, A0, 4, 2'd0, 8'd0, R_BAD_ATTR, "P3 reserved memory type");
    chk(0, 8'h10, WR, 8'h10, A0, 4, 2'd0, 8'd0, R_BAD_ATTR, "P3 instruction fetch + write");
    chk(0, 8'h10, RD, 8'h10, A0, 4, 2'd0, 8'd0, R_PERM,     "P3 instruction fetch without execute right");
    chk(0, 8'h10, 4'd0, 8'h00, A0, 4, 2'd0, 8'd0, R_BAD_OP, "P3 opcode NONE");
    chk(0, 8'h10, 4'd4, 8'h00, A0, 4, 2'd0, 8'd0, R_BAD_OP, "P3 reserved (atomic) opcode");
    chk(0, 8'h10, RD, 8'h00, A0, 4, 2'd3, 8'd0, R_BAD_ATTR, "P3 reserved check class");
    // devices
    chkA(0, 8'h10, RD, DEV_VIRTIO, 4, R_DEV,  "P3 A has no virtio permission");
    chkA(1, 8'h11, WR, DEV_VIRTIO, 4, R_DEV,  "P3 B virtio is read-only");
    chkA(0, 8'h10, RD, DEV_DMA,    4, R_PRIV, "P3 DMA registers are privileged-only");
    chkA(0, 8'h10, RD, DEV_SEC,    4, R_PRIV, "P3 security registers are privileged+secure-only");
    chk(0, 8'h10, RD, 8'h10, DEV_NET, 4, 2'd0, 8'd0, R_PERM, "P3 instruction fetch from a device");
    chkA(0, 8'h10, RD, DEV_NET - 4, 8, R_NOMAP, "P3 range straddles the start of a device region");
    chkA(0, 8'h01, RD, DEV_DMA, 32'h1100_0000, R_NOMAP, "P3 range covers several device regions");
    // queues
    chk(0, 8'h10, RD, 8'h00, 64'd0, 32'd0, 2'd1, 8'd2, R_QUEUE, "P3 A uses B's queue");
    chk(0, 8'h10, RD, 8'h00, 64'd0, 32'd0, 2'd1, 8'd9, R_QUEUE, "P3 queue number out of range");
    chk(0, 8'h10, 4'd9, 8'h00, 64'd0, 32'd0, 2'd1, 8'd0, R_BAD_OP, "P3 queue use with an invalid opcode");
    // quarantine-free state check: a suspended domain is refused
    cmd(OP_SET_STATE, 8'h01, 1'b1, 3, 0, 0, 0, 8'd1, 0, 0, CS_OK);            // MGMT suspends tenant C
    chkA(2, 8'h12, RD, C0, 4, R_DOM_STATE, "P3 suspended domain");
    cmd(OP_SET_STATE, 8'h01, 1'b1, 3, 0, 0, 0, 8'd2, 0, 0, CS_OK);            // ... and resumes it
    chkA(2, 8'h12, RD, C0, 4, R_OK, "P3 resumed domain");

    // =======================================================================
    // P4  AUDIT COUNTERS agree with the independent tally
    // =======================================================================
    tick(3);
    tel(8'h10, 8'h00, 1'b1, TELP);  expect_eq("P4 access violations", tel_data, exp_viol);
    tel(8'h11, 8'h00, 1'b1, TELP);  expect_eq("P4 invalid DMA attempts (port 2 denials)", tel_data, exp_dma);
    tel(8'h13, 8'h00, 1'b1, TELP);  expect_eq("P4 ECC corrections", tel_data, 32'd0);
    tel(8'h14, 8'h00, 1'b1, TELP);  expect_eq("P4 uncorrectable", tel_data, 32'd0);
    expect_eq("P4 no containment from refusals: lockdown", lockdown, 1'b0);
    expect_eq("P4 no containment from refusals: irq", irq, 1'b0);

    // =======================================================================
    // P5  RELIABILITY EVENTS AND CONTAINMENT
    // =======================================================================
    // 5a corrected ECC: counted, nothing else
    evp(0, 1'b0, 8'd0, 8'd0, 1'b1, B0 + 64'h40);   tick(5);
    tel(8'h13, 8'h00, 1'b1, TELP);  expect_eq("P5a ECC corrections", tel_data, 32'd1);
    expect_eq("P5a no irq", irq, 1'b0);
    chkA(1, 8'h11, RD, B0, 4, R_OK, "P5a B unaffected by a corrected error");
    // 5b uncorrectable ECC inside B's exclusive window: THAT domain only
    clear_seen();
    evp(1, 1'b0, 8'd0, 8'd0, 1'b1, B0 + 64'h80);   tick(6);
    chkA(1, 8'h11, RD, B0, 4, R_DOM_STATE, "P5b B quarantined");
    chkA(0, 8'h10, RD, A0, 4, R_OK,        "P5b A unaffected");
    chkA(2, 8'h12, RD, C0, 4, R_OK,        "P5b C unaffected");
    expect_eq("P5b slot B state = QUARANTINED", slot_state[2*2 +: 2], 2'd3);
    expect_eq("P5b slot A state", slot_state[1*2 +: 2], 2'd2);
    expect_eq("P5b zeroise requested for B's key only", seen_zero_mask, 4'b0010);
    expect_eq("P5b B's queues aborted", seen_abort, 8'b0000_1100);
    expect_eq("P5b B's queues held", qhold, 8'b0000_1100);
    expect_eq("P5b irq", irq, 1'b1);
    expect_eq("P5b not the safe state", lockdown, 1'b0);
    expect_eq("P5b no engine reset", seen_eng, 3'b000);
    tel(8'h14, 8'h00, 1'b1, TELP);  expect_eq("P5b uncorrectable counter", tel_data, 32'd1);
    tel(8'h03, 8'h00, 1'b1, TELP);  expect_eq("P5b last-fault record: valid", tel_data[20], 1'b1);
                                 expect_eq("P5b last-fault record: severity = uncorrectable", tel_data[19:18], 2'd2);
                                 expect_eq("P5b last-fault record: source = ECC UE", tel_data[17:14], 4'd1);
                                 expect_eq("P5b last-fault record: domain attributed", tel_data[13], 1'b1);
                                 expect_eq("P5b last-fault record: actions = report+abort+quarantine", tel_data[12:8], 5'b01011);
    tel(8'h04, 8'h00, 1'b1, TELP);  expect_eq("P5b last-fault domain", tel_data[7:0], 8'h11);
    tel(8'h05, 8'h00, 1'b1, TELP);  expect_eq("P5b worst severity so far", tel_data[1:0], 2'd2);
    tel(8'h88, 8'h00, 1'b1, TELP);  expect_eq("P5b descriptor kept for forensics: state", tel_data[31:30], 2'd3);
                                 expect_eq("P5b descriptor kept: id", tel_data[7:0], 8'h11);
    cmd(OP_SET_STATE, 8'h01, 1'b1, 2, 0, 0, 0, 8'd2, 0, 0, CS_BAD_PRIV);       // MGMT may not release a quarantine
    cmd(OP_SET_WINDOW, 8'h00, 1'b1, 2, 1, 0, 0, 8'b0001, B0 + 64'h2000, B0 + 64'h2010, CS_BAD_STATE);   // forensic state is frozen
    cmd(OP_SET_STATE, 8'h00, 1'b1, 2, 0, 0, 0, 8'd2, 0, 0, CS_OK);             // ROOT releases
    chkA(1, 8'h11, RD, B0, 4, R_OK, "P5b B after ROOT release");
    chk(1, 8'h11, RD, 8'h00, 64'd0, 32'd0, 2'd1, 8'd2, R_QUEUE, "P5b B's queue still held until cleared");
    cmd(OP_CLR_QHOLD, 8'h01, 1'b1, 0, 0, 0, 0, 0, 64'b0000_1100, 0, CS_OK);   // MGMT clears the holds
    tick(2);
    chk(1, 8'h11, RD, 8'h00, 64'd0, 32'd0, 2'd1, 8'd2, R_OK, "P5b B's queue usable again");
    cmd(OP_CLR_CNT, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_OK);                  // ROOT acknowledges: report + counters cleared
    tick(2);
    expect_eq("P5b irq acknowledged", irq, 1'b0);
    // 5c uncorrectable error nobody owns: reported, no victim guessed
    evp(1, 1'b0, 8'd0, 8'd0, 1'b1, 64'h0000_0040_0800_0000);   tick(6);
    expect_eq("P5c irq", irq, 1'b1);
    for (int s = 0; s < 4; s++) expect_eq($sformatf("P5c slot %0d state untouched", s), slot_state[s*2 +: 2], 2'd2);
    expect_eq("P5c no lockdown", lockdown, 1'b0);
    cmd(OP_CLR_CNT, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_OK);  tick(2);
    // 5d watchdog of engine/port 1: only that engine
    clear_seen();
    evp(8, 1'b0, 8'd0, 8'd1, 1'b0, 64'd0);   tick(5);
    expect_eq("P5d reset pulse only for engine 1", seen_eng, 3'b010);
    expect_eq("P5d an engine event aborts no queue", seen_abort, 8'h00);
    expect_eq("P5d port 1 isolated", port_isol, 3'b010);
    tel(8'h16, 8'h00, 1'b1, TELP);  expect_eq("P5d reset-event audit counter", tel_data, 32'd1);
    chkA(1, 8'h11, RD, B0, 4, R_ISOLATED, "P5d B's port refuses");
    chkA(0, 8'h10, RD, A0, 4, R_OK,       "P5d A's port unaffected");
    chkA(2, 8'h12, RD, C0, 4, R_OK,       "P5d DMA port unaffected");
    expect_eq("P5d no domain quarantined", slot_state, 8'b10_10_10_10);
    @(negedge clk); eng_done <= 3'b010; @(negedge clk); eng_done <= '0; tick(2);
    expect_eq("P5d port reopened by the engine's done", port_isol, 3'b000);
    chkA(1, 8'h11, RD, B0, 4, R_OK, "P5d B served again");
    evp(8, 1'b0, 8'd0, 8'd2, 1'b0, 64'd0);   tick(5);                           // second watchdog, engine 2 this time
    expect_eq("P5d engine 2 isolated", port_isol, 3'b100);
    cmd(OP_CLR_ISOL, 8'h01, 1'b1, 0, 0, 0, 0, 0, 64'b100, 0, CS_OK); tick(2);   // privileged release without a done
    expect_eq("P5d privileged CLR_ISOL", port_isol, 3'b000);
    cmd(OP_CLR_CNT, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_OK);  tick(2);
    // 5e DMA fault on queue 4 of domain C: that queue only, domain stays active
    clear_seen();
    evp(4, 1'b1, 8'h12, 8'd4, 1'b0, 64'd0);   tick(5);
    expect_eq("P5e queue 4 aborted", seen_abort, 8'b0001_0000);
    expect_eq("P5e a queue fault resets no engine", seen_eng, 3'b000);
    expect_eq("P5e queue 4 held", qhold, 8'b0001_0000);
    chk(2, 8'h12, RD, 8'h00, 64'd0, 32'd0, 2'd1, 8'd4, R_QUEUE, "P5e C's queue refused");
    chkA(2, 8'h12, RD, C0, 4, R_OK, "P5e C's memory still reachable");
    chk(0, 8'h10, RD, 8'h00, 64'd0, 32'd0, 2'd1, 8'd0, R_OK, "P5e A's queue unaffected");
    cmd(OP_CLR_QHOLD, 8'h01, 1'b1, 0, 0, 0, 0, 0, 64'b0001_0000, 0, CS_OK);   tick(2);
    chk(2, 8'h12, RD, 8'h00, 64'd0, 32'd0, 2'd1, 8'd4, R_OK, "P5e C's queue usable again");
    tel(8'h15, 8'h00, 1'b1, TELP);  expect_eq("P5e queue-fault audit counter", tel_data, 32'd1);
    // 5e2 a queue fault in a domain that owns SEVERAL queues aborts only the faulty queue
    clear_seen();
    evp(4, 1'b1, 8'h10, 8'd1, 1'b0, 64'd0);   tick(5);
    expect_eq("P5e2 only the faulty queue is aborted (A owns queues 0 and 1)", seen_abort, 8'b0000_0010);
    expect_eq("P5e2 only that queue is held", qhold, 8'b0000_0010);
    chk(0, 8'h10, RD, 8'h00, 64'd0, 32'd0, 2'd1, 8'd0, R_OK,    "P5e2 A's other queue unaffected");
    chk(0, 8'h10, RD, 8'h00, 64'd0, 32'd0, 2'd1, 8'd1, R_QUEUE, "P5e2 the faulty queue is refused");
    tel(8'h15, 8'h00, 1'b1, TELP);  expect_eq("P5e2 queue-fault audit counter", tel_data, 32'd2);
    cmd(OP_CLR_QHOLD, 8'h01, 1'b1, 0, 0, 0, 0, 0, 64'b0000_0010, 0, CS_OK);   tick(2);
    cmd(OP_CLR_CNT, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_OK);  tick(2);
    // 5f compute error of domain A on engine 0: A's queues aborted + engine 0 reset, domain kept
    clear_seen();
    evp(9, 1'b1, 8'h10, 8'd0, 1'b0, 64'd0);   tick(5);
    expect_eq("P5f A's queues aborted", seen_abort, 8'b0000_0011);
    expect_eq("P5f engine 0 reset", seen_eng, 3'b001);
    chkA(0, 8'h10, RD, A0, 4, R_ISOLATED, "P5f A's engine isolated");
    chkA(2, 8'h10, RD, A0, 4, R_OK,       "P5f A reachable through another port");
    expect_eq("P5f A not quarantined", slot_state[1*2 +: 2], 2'd2);
    @(negedge clk); eng_done <= 3'b001; @(negedge clk); eng_done <= '0; tick(2);
    cmd(OP_CLR_QHOLD, 8'h01, 1'b1, 0, 0, 0, 0, 0, 64'b0000_0011, 0, CS_OK);   tick(2);
    cmd(OP_CLR_CNT, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_OK);  tick(2);
    // 5g uncorrectable error attributed to a SYSTEM domain -> safe state
    clear_seen();
    evp(1, 1'b1, 8'h01, 8'd0, 1'b0, 64'd0);   tick(6);
    expect_eq("P5g lockdown", lockdown, 1'b1);
    expect_eq("P5g safe-state entry pulse", seen_safe, 1'b1);
    expect_eq("P5g every key zeroised", seen_zero_all, 1'b1);
    expect_eq("P5g every queue aborted", seen_abort, 8'hFF);
    chkA(0, 8'h10, RD, A0, 4, R_LOCKDOWN, "P5g tenant refused in safe state");
    chkA(2, 8'h12, RD, C0, 4, R_LOCKDOWN, "P5g other tenant refused too");
    chk(0, 8'h01, RD, 8'h00, M0, 4, 2'd0, 8'd0, R_OK, "P5g MGMT still served for recovery");
    cmd(OP_CLR_SAFE, 8'h01, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_BAD_PRIV);          // MGMT cannot leave the safe state
    expect_eq("P5g still locked", lockdown, 1'b1);
    cmd(OP_CLR_SAFE, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_OK);   tick(2);
    expect_eq("P5g ROOT released", lockdown, 1'b0);
    chkA(0, 8'h10, RD, A0, 4, R_OK, "P5g tenant served after release");
    expect_eq("P5g queue holds survive until cleared explicitly", qhold, 8'hFF);
    cmd(OP_CLR_QHOLD, 8'h00, 1'b1, 0, 0, 0, 0, 0, 64'hFF, 0, CS_OK);   tick(2);
    expect_eq("P5g holds cleared", qhold, 8'h00);
    cmd(OP_CLR_CNT, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_OK);  tick(2);

    // =======================================================================
    // P5h  CONCURRENT FAULTS: all 16 sources in one cycle, then again
    // =======================================================================
    tel(8'h18, 8'h00, 1'b1, TELP);  v0 = tel_data;
    evburst(16'hFFFF, 1'b0, 8'd0, 8'd0, 64'd0);
    evstop();                                      tick(40);
    for (int s = 0; s < 16; s++) begin
      tel(8'h20 + s[7:0], 8'h00, 1'b1, TELP);
      expect_eq($sformatf("P5h source %0d counted once", s), tel_data, 32'd1);
    end
    tel(8'h18, 8'h00, 1'b1, TELP);  expect_eq("P5h corrected events", tel_data, 32'd1);
    tel(8'h19, 8'h00, 1'b1, TELP);  expect_eq("P5h detected events", tel_data, 32'd7);
    tel(8'h1A, 8'h00, 1'b1, TELP);  expect_eq("P5h uncorrectable events", tel_data, 32'd4);
    tel(8'h1B, 8'h00, 1'b1, TELP);  expect_eq("P5h fatal events", tel_data, 32'd4);
    tel(8'h10, 8'h00, 1'b1, TELP);  expect_eq("P5h access-violation counter (sources 6+7)", tel_data, 32'd2);
    tel(8'h12, 8'h00, 1'b1, TELP);  expect_eq("P5h authentication failures (12+13)", tel_data, 32'd2);
    tel(8'h15, 8'h00, 1'b1, TELP);  expect_eq("P5h queue faults (4+5+14)", tel_data, 32'd3);
    tel(8'h14, 8'h00, 1'b1, TELP);  expect_eq("P5h uncorrectable counter", tel_data, 32'd4);
    tel(8'h30, 8'h00, 1'b1, TELP);  expect_eq("P5h all records consumed (none pending)", tel_data[15:0], 16'd0);
    expect_eq("P5h a fatal source reached the safe state", lockdown, 1'b1);
    expect_eq("P5h reported", irq, 1'b1);
    // second burst twice in a row: the second occurrence of a still-pending source is counted and flagged OVERRUN
    cmd(OP_CLR_SAFE, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_OK);   tick(2);
    cmd(OP_CLR_CNT, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_OK);    tick(2);
    evburst(16'hFFFF, 1'b0, 8'd0, 8'd0, 64'd0);   evstop();     // one-cycle burst, one-cycle gap (level sources are edge-detected)
    evburst(16'hFFFF, 1'b0, 8'd0, 8'd0, 64'd0);   evstop();     tick(3);
    tel(8'h30, 8'h00, 1'b1, TELP);  expect_eq("P5h overrun recorded for coalesced sources", (tel_data[31:16] != 16'd0), 1'b1);
    tick(40);
    for (int s = 0; s < 16; s++) begin
      tel(8'h20 + s[7:0], 8'h00, 1'b1, TELP);
      expect_eq($sformatf("P5h source %0d counted twice (no lost occurrence)", s), tel_data, 32'd2);
    end
    cmd(OP_CLR_SAFE, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_OK);   tick(2);
    cmd(OP_CLR_QHOLD, 8'h00, 1'b1, 0, 0, 0, 0, 0, 64'hFF, 0, CS_OK);   tick(2);
    cmd(OP_CLR_ISOL, 8'h00, 1'b1, 0, 0, 0, 0, 0, 64'b111, 0, CS_OK);   tick(2);
    cmd(OP_CLR_CNT, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_OK);    tick(2);
    exp_viol = 0; exp_dma = 0;

    // =======================================================================
    // P5i  SEVERITY ORDER: a fatal event is handled before queued corrected / detected ones
    // =======================================================================
    clear_seen();
    evburst(16'b0100_0000_1111_0101, 1'b0, 8'd0, 8'd0, 64'd0);       // sources 0,2(FATAL),4,5,6,7,... all together
    evstop();
    tick(4);
    expect_eq("P5i fatal event handled first (safe state within 4 cycles, not after the corrected ones)", lockdown, 1'b1);
    tick(30);
    cmd(OP_CLR_SAFE, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_OK);   tick(2);
    cmd(OP_CLR_QHOLD, 8'h00, 1'b1, 0, 0, 0, 0, 0, 64'hFF, 0, CS_OK);   tick(2);
    cmd(OP_CLR_ISOL, 8'h00, 1'b1, 0, 0, 0, 0, 0, 64'b111, 0, CS_OK);   tick(2);
    cmd(OP_CLR_CNT, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_OK);    tick(2);
    exp_viol = 0; exp_dma = 0;
    // =======================================================================
    // P5j  LEVEL inputs are edge-detected, PULSE inputs count every cycle
    // =======================================================================
    evburst(16'b0000_0100_0000_0000, 1'b0, 8'd0, 8'd0, 64'd0);       // thermal warning (source 10, level): high for exactly 8 cycles
    tick(7);  evstop();  tick(6);
    tel(8'h2A, 8'h00, 1'b1, TELP);  expect_eq("P5j level source held for 8 cycles counts ONCE", tel_data, 32'd1);
    evburst(16'b0000_0000_0000_0001, 1'b0, 8'd0, 8'd0, 64'd0);       // ECC corrected (source 0, pulse): high for exactly 8 cycles
    tick(7);  evstop();  tick(6);
    tel(8'h20, 8'h00, 1'b1, TELP);  expect_eq("P5j pulse source held for 8 cycles counts 8 times", tel_data, 32'd8);
    cmd(OP_CLR_CNT, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_OK);    tick(2);
    // =======================================================================
    // P5k  EXACT violation counting: simultaneous denials, held verdicts
    // =======================================================================
    exp_viol = 0; exp_dma = 0;
    chk_pair(0, 8'h10, B0, 1, 8'h11, A0, 0);                          // two ports deny in the same cycle
    chk_pair(0, 8'h10, B0, 2, 8'h12, A0, 1);                          // ... one of them a DMA port
    chk_pair(1, 8'h11, A0, 2, 8'h12, A0, 1);
    chk_held(0, 8'h10, B0, 6);                                        // one request, verdict visible 7 cycles, ONE commit
    chk_held(2, 8'h12, A0, 3);
    tick(4);
    tel(8'h10, 8'h00, 1'b1, TELP);  expect_eq("P5k violations counted exactly (simultaneous + held)", tel_data, exp_viol);
    tel(8'h11, 8'h00, 1'b1, TELP);  expect_eq("P5k DMA violations counted exactly", tel_data, exp_dma);
    cmd(OP_CLR_CNT, 8'h00, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_OK);    tick(2);
    exp_viol = 0; exp_dma = 0;

    // =======================================================================
    // P6  TELEMETRY PRIVACY
    // =======================================================================
    // domain A reads its own slot registers (verified for the physical telemetry port 0)
    tel(8'h84, 8'h10, 1'b0, 0);  expect_eq("P6 A reads own state", tel_data[31:30], 2'd2);  expect_eq("P6 A reads own id", tel_data[7:0], 8'h10);
                                 expect_eq("P6 own read ok", tel_error, 1'b0);
    tel(8'h88, 8'h10, 1'b0, 0);  expect_eq("P6 A reads B's slot -> error", tel_error, 1'b1);
    tel(8'h10, 8'h10, 1'b0, 0);  expect_eq("P6 A reads a global counter -> error", tel_error, 1'b1);
    tel(8'h84, 8'h10, 1'b0, 1);  expect_eq("P6 A's label on the wrong telemetry port -> error", tel_error, 1'b1);
    tel(8'h88, 8'h11, 1'b0, 1);  expect_eq("P6 B reads own slot via its port", tel_error, 1'b0);
    tel(8'h10, 8'h00, 1'b0, 0);  expect_eq("P6 ROOT label without privilege -> error", tel_error, 1'b1);
    cfg_en <= 1'b0;
    tel(8'h10, 8'h00, 1'b1, TELP);  expect_eq("P6 privileged read while configuration is not authorised -> error", tel_error, 1'b1);
    cfg_en <= 1'b1;
    tel(8'h84, 8'h00, 1'b1, TELP);  expect_eq("P6 privileged read of any slot", tel_error, 1'b0);
    tel(8'hFC, 8'h00, 1'b1, TELP);  expect_eq("P6 privileged read of a slot that does not exist -> error (not a violation)", tel_error, 1'b1);
    exp_viol--;                  // that one error is not an access violation
    tel(8'hF0, 8'h00, 1'b1, TELP);  expect_eq("P6 undefined register -> error", tel_error, 1'b1);
    exp_viol--;
    tick(3);
    tel(8'h10, 8'h00, 1'b1, TELP);  expect_eq("P6 denied reads were counted as access violations", tel_data, exp_viol);
    // per-domain counters charge only VERIFIED domains: spoofing A's label cannot raise A's counter (no DoS lever)
    tel(8'h85, 8'h00, 1'b1, TELP);  v0 = tel_data;
    chkA(1, 8'h10, RD, A0, 4, R_BAD_DOM, "P6 spoof of A on port 1");
    chkA(1, 8'h10, RD, A0, 4, R_BAD_DOM, "P6 spoof of A on port 1");
    chkA(1, 8'h10, RD, A0, 4, R_BAD_DOM, "P6 spoof of A on port 1");
    tick(3);
    tel(8'h85, 8'h00, 1'b1, TELP);  expect_eq("P6 A's counter unchanged by others' spoofing", tel_data, v0);
    chkA(0, 8'h10, RD, B0, 4, R_NOMAP, "P6 genuine A violation");
    chkA(0, 8'h10, RD, C0, 4, R_NOMAP, "P6 genuine A violation");
    tick(3);
    tel(8'h85, 8'h00, 1'b1, TELP);  expect_eq("P6 A's own counter charged for its own violations", tel_data[15:0], v0[15:0] + 16'd2);
    tel(8'h40, 8'h00, 1'b1, TELP);  d0v = tel_data;
    tel(8'h41, 8'h00, 1'b1, TELP);  d1v = tel_data;
    expect_eq("P6 per-port counter sees the spoofs", d1v[15:0] >= 16'd3, 1'b1);
    // alert threshold (privileged): sticky flag for the management plane, no automatic containment
    cmd(OP_SET_THRESH, 8'h00, 1'b1, 0, 0, 0, 0, 0, 64'd4, 0, CS_OK);   tick(2);
    chkA(0, 8'h10, RD, B0, 4, R_NOMAP, "P6 genuine A violation");
    chkA(0, 8'h10, RD, B0, 4, R_NOMAP, "P6 genuine A violation");
    tick(3);
    tel(8'h85, 8'h00, 1'b1, TELP);  expect_eq("P6 alert flag set at the threshold", tel_data[16], 1'b1);
    expect_eq("P6 no automatic quarantine from violations", slot_state[1*2 +: 2], 2'd2);

    // =======================================================================
    // P7  KEY HYGIENE on REVOKE and no inheritance by the next tenant
    // =======================================================================
    // give tenant C a NON-ZERO violation count first, so that "the next tenant starts clean" is observable
    chkA(2, 8'h12, RD, A0, 4, R_NOMAP, "P7 C's own violation");
    chkA(2, 8'h12, RD, B0, 4, R_NOMAP, "P7 C's own violation");
    tick(3);
    tel(8'h8D, 8'h00, 1'b1, TELP);  expect_eq("P7 C's per-domain counter before revoke", tel_data[15:0], 16'd2);
    clear_seen();
    root(OP_REVOKE, 3, 0, 0, 0, 0, 0, 0);   tick(3);
    expect_eq("P7 revoke zeroises C's key", seen_zero_mask, 4'b0100);
    chkA(2, 8'h12, RD, C0, 4, R_BAD_DOM, "P7 revoked domain is gone");
    root(OP_ENROLL, 3, 0, 0, 8'h13, 8'h00, 0, 0);
    tel(8'h8D, 8'h00, 1'b1, TELP);  expect_eq("P7 new tenant in the slot starts with a clean counter", tel_data, 32'd0);
    tel(8'h8C, 8'h00, 1'b1, TELP);  expect_eq("P7 new tenant: suspended", tel_data[31:30], 2'd1);
    chkA(2, 8'h13, RD, C0, 4, R_DOM_STATE, "P7 enrolled but not activated: no access");
    root(OP_SET_WINDOW, 3, 0, 0, 0, 8'b1011, C0, C0 + 64'hFFFF);   // the exclusive range is free again
    root(OP_SET_STATE, 3, 0, 0, 0, 8'd2, 0, 0);
    chkA(2, 8'h13, RD, C0, 4, R_OK, "P7 new tenant: its own window works");
    chk(2, 8'h13, RD, 8'h00, 64'd0, 32'd0, 2'd1, 8'd4, R_QUEUE, "P7 new tenant inherits no queue permission");
    chkA(2, 8'h13, RD, DEV_NET, 4, R_DEV, "P7 new tenant inherits no device permission");
    expect_eq("P7 new tenant inherits no key permission", kmask[3*NKEY +: NKEY], 4'b0000);

    // =======================================================================
    // P8  CONFIGURATION LOCK
    // =======================================================================
    expect_eq("P8 not locked yet", cfg_lock, 1'b0);
    cmd(OP_LOCK, 8'h01, 1'b1, 0, 0, 0, 0, 0, 0, 0, CS_BAD_PRIV);               // only ROOT locks
    root(OP_LOCK, 0, 0, 0, 0, 0, 0, 0);                                         tick(1);
    expect_eq("P8 locked", cfg_lock, 1'b1);
    cmd(OP_BIND_PORT, 8'h00, 1'b1, 0, 0, 1, 0, 0, 64'hF, 0, CS_LOCKED);          // bindings frozen, even for ROOT
    cmd(OP_ENROLL, 8'h00, 1'b1, 3, 0, 0, 8'h05, 8'h00, 0, 0, CS_LOCKED);         // no new system domain
    cmd(OP_SET_WINDOW, 8'h00, 1'b1, 0, 1, 0, 0, 8'b0001, M0 + 64'h1000, M0 + 64'h1FFF, CS_LOCKED);   // system slot frozen
    root(OP_SET_WINDOW, 1, 1, 0, 0, 8'b1001, A1, A1 + 64'h1FFF);                 // tenant slots stay manageable
    chkA(0, 8'h10, RD, A1 + 64'h1FFF, 1, R_OK, "P8 tenant reconfiguration still works after lock");
    chkA(0, 8'h10, RD, A1 + 64'h2000, 1, R_NOMAP, "P8 ... and takes effect");

    // =======================================================================
    // P9  DFT / TEST ACCESS LOCKOUT
    // =======================================================================
    dft <= 1'b1;
    chkA(0, 8'h10, RD, A0, 4, R_LOCKDOWN, "P9 tenant refused while test access is active");
    chk(0, 8'h01, RD, 8'h00, M0, 4, 2'd0, 8'd0, R_LOCKDOWN, "P9 nobody is exempt (MGMT too)");
    dft <= 1'b0;
    chkA(0, 8'h10, RD, A0, 4, R_OK, "P9 served again");

    // =======================================================================
    // P9b  REGRESSIONS FOR THE INDEPENDENT REVIEW'S FINDINGS (each was a reproduced defect before its fix)
    // =======================================================================
    begin : p9b
      logic [31:0] va, vb;
      integer cnt;
      // --- F1: the ROOT label is not trusted on a tenant-facing telemetry port --------------------------------
      tel(8'h88, 8'h00, 1'b1, 0);   expect_eq("P9b ROOT label + priv on tenant-facing port 0 -> error", tel_error, 1'b1);
      tel(8'h02, 8'h00, 1'b1, 1);   expect_eq("P9b ... and on port 1 -> error", tel_error, 1'b1);
      tel(8'h88, 8'h00, 1'b1, TELP); expect_eq("P9b same read on the management port works", tel_error, 1'b0);
      tel(8'h88, 8'h00, 1'b1, 0);   expect_eq("P9b ... and returned no data on the tenant port", tel_data, 32'd0);

      // --- F10: an external ILLEGAL pulse in the same cycle as an internal denial is counted too -------------------
      tel(8'h26, 8'h00, 1'b1, TELP); va = tel_data;
      @(negedge clk);
      sh_dom[0*8 +: 8] = 8'h10; sh_op[0*4 +: 4] = RD; sh_attr[0*8 +: 8] = 8'h00; sh_addr[0*AW +: AW] = B0;
      sh_len[0*LEN_W +: LEN_W] = 4; sh_cls[0*2 +: 2] = 2'd0; sh_idx[0*8 +: 8] = 8'd0;
      chk_dom <= sh_dom; chk_op <= sh_op; chk_attr <= sh_attr; chk_addr <= sh_addr; chk_len <= sh_len; chk_cls <= sh_cls; chk_idx <= sh_idx;
      chk_valid <= 3'b001; chk_commit <= 3'b001; ev <= 16'h0040;
      @(negedge clk); chk_valid <= '0; chk_commit <= '0; ev <= '0;
      exp_viol += 2;
      tick(4);
      tel(8'h26, 8'h00, 1'b1, TELP);  expect_eq("P9b ILLEGAL: 1 external + 1 internal occurrence in one cycle counted as 2", tel_data, va + 32'd2);

      // same for INVALID_DMA (source 7): a denial on the DMA port (port 2) together with an external pulse
      tel(8'h11, 8'h00, 1'b1, TELP); va = tel_data;
      tel(8'h27, 8'h00, 1'b1, TELP); vb = tel_data;
      @(negedge clk);
      sh_dom[2*8 +: 8] = 8'h10; sh_op[2*4 +: 4] = RD; sh_attr[2*8 +: 8] = 8'h00; sh_addr[2*AW +: AW] = B0;
      sh_len[2*LEN_W +: LEN_W] = 4; sh_cls[2*2 +: 2] = 2'd0; sh_idx[2*8 +: 8] = 8'd0;
      chk_dom <= sh_dom; chk_op <= sh_op; chk_attr <= sh_attr; chk_addr <= sh_addr; chk_len <= sh_len; chk_cls <= sh_cls; chk_idx <= sh_idx;
      chk_valid <= 3'b100; chk_commit <= 3'b100; ev <= 16'h0080;
      @(negedge clk); chk_valid <= '0; chk_commit <= '0; ev <= '0;
      exp_viol += 2; exp_dma += 2;
      tick(4);
      tel(8'h11, 8'h00, 1'b1, TELP);  expect_eq("P9b invalid-DMA audit counter: 1 external + 1 internal in one cycle counted as 2", tel_data, va + 32'd2);
      tel(8'h27, 8'h00, 1'b1, TELP);  expect_eq("P9b INVALID_DMA per-source counter likewise", tel_data, vb + 32'd2);

      // --- F3: MGMT can neither release a quarantine nor REVOKE it (REVOKE + re-ENROLL would release it) ---------
      root(OP_SET_STATE, 3, 0, 0, 0, 8'd3, 0, 0);       tick(2);
      expect_eq("P9b slot 3 quarantined", slot_state[3*2 +: 2], 2'd3);
      cmd(OP_REVOKE,    8'h01, 1'b1, 3, 0, 0, 0, 0, 0, 0, CS_BAD_PRIV);
      cmd(OP_SET_STATE, 8'h01, 1'b1, 3, 0, 0, 0, 8'd2, 0, 0, CS_BAD_PRIV);
      tick(2);
      expect_eq("P9b ... and it is still quarantined", slot_state[3*2 +: 2], 2'd3);
      root(OP_SET_STATE, 3, 0, 0, 0, 8'd2, 0, 0);       tick(2);          // ROOT releases
      expect_eq("P9b ROOT released it", slot_state[3*2 +: 2], 2'd2);

      // --- F9: removing a key slot from a domain zeroises it (growth does not) -------------------------------------
      clear_seen();
      root(OP_SET_KEYPRM, 3, 0, 0, 0, 0, 64'b0110, 0);  tick(3);
      expect_eq("P9b granting key slots zeroises nothing", seen_zero, 1'b0);
      root(OP_SET_KEYPRM, 3, 0, 0, 0, 0, 64'b0100, 0);  tick(3);
      expect_eq("P9b removing key slot 1 zeroises exactly that slot", seen_zero_mask, 4'b0010);
      root(OP_SET_KEYPRM, 3, 0, 0, 0, 0, 64'b0000, 0);  tick(3);
      expect_eq("P9b removing the rest zeroises it too", seen_zero_mask, 4'b0110);

      // --- F2: an access-violation flood must not starve queue containment (round-robin within a severity) ------------
      sh_ev_dvld = '0; sh_ev_dom = '0; sh_ev_idx = '0; sh_ev_avld = '0; sh_ev_addr = '0;
      for (int i = 0; i < 40; i++) begin
        @(negedge clk);
        sh_dom[0*8 +: 8] = 8'h10; sh_op[0*4 +: 4] = RD; sh_attr[0*8 +: 8] = 8'h00; sh_addr[0*AW +: AW] = B0;
        sh_len[0*LEN_W +: LEN_W] = 4; sh_cls[0*2 +: 2] = 2'd0; sh_idx[0*8 +: 8] = 8'd0;
        chk_dom <= sh_dom; chk_op <= sh_op; chk_attr <= sh_attr; chk_addr <= sh_addr; chk_len <= sh_len; chk_cls <= sh_cls; chk_idx <= sh_idx;
        chk_valid <= 3'b001; chk_commit <= 3'b001;                       // a denial EVERY cycle
        sh_ev_idx = '0;
        if (i == 3)  begin sh_ev_idx[14*8 +: 8] = 8'd3; ev_idx <= sh_ev_idx; ev <= 16'h4000; end      // QUEUE_FAULT, queue 3
        else if (i == 20) begin sh_ev_idx[14*8 +: 8] = 8'd5; ev_idx <= sh_ev_idx; ev <= 16'h4000; end // QUEUE_FAULT, queue 5
        else ev <= '0;
        exp_viol++;
        if (i == 15) expect_eq("P9b queue 3 held DURING the flood", qhold[3], 1'b1);
      end
      @(negedge clk); chk_valid <= '0; chk_commit <= '0; ev <= '0;
      tick(3);
      expect_eq("P9b queue 5 held although the flood never stopped before it", qhold[5], 1'b1);
      expect_eq("P9b queue 3 still held", qhold[3], 1'b1);
      expect_eq("P9b only those two queues", qhold, 8'b0010_1000);
      root(OP_CLR_QHOLD, 0, 0, 0, 0, 0, 64'hFF, 0);   tick(2);

      // --- F6: CLR_SAFE has no effect while a FATAL level condition persists --------------------------------------
      ev <= 16'h0800;                                   // THERM_CRIT held high (level source 11)
      tick(6);
      expect_eq("P9b critical temperature: safe state entered", lockdown, 1'b1);
      root(OP_CLR_SAFE, 0, 0, 0, 0, 0, 0, 0);          tick(4);
      expect_eq("P9b CLR_SAFE under a persisting fatal level: still in safe state", lockdown, 1'b1);
      ev <= '0;                                         tick(3);
      root(OP_CLR_SAFE, 0, 0, 0, 0, 0, 0, 0);          tick(4);
      expect_eq("P9b CLR_SAFE after the condition is gone releases it", lockdown, 1'b0);
      root(OP_CLR_QHOLD, 0, 0, 0, 0, 0, 64'hFF, 0);   tick(2);

      // --- F8: a "done" that was already high does not answer this reset ------------------------------------------
      eng_done <= 3'b111;
      cnt = 0;
      evp(8, 1'b0, 8'd0, 8'd1, 1'b0, 64'd0);
      for (int i = 0; i < 8; i++) begin
        if (port_isol[1]) cnt++;
        @(negedge clk);
      end
      expect_eq("P9b port isolated for at least 2 cycles even with 'done' tied high", cnt >= 2, 1'b1);
      expect_eq("P9b ... and released afterwards (done honoured after the request cycle)", port_isol[1], 1'b0);
      eng_done <= 3'b000;
      tick(2);
    end

    // =======================================================================
    // P10  RESET clears all privileged and in-flight control state
    // =======================================================================
    evp(1, 1'b1, 8'h01, 8'd0, 1'b0, 64'd0);   tick(6);                             // safe state
    evp(8, 1'b0, 8'd0, 8'd1, 1'b0, 64'd0);     tick(5);                             // isolate port 1
    evp(4, 1'b1, 8'h12, 8'd4, 1'b0, 64'd0);    tick(5);                             // hold queue 4
    expect_eq("P10 pre-reset lockdown", lockdown, 1'b1);
    expect_eq("P10 pre-reset isolation", port_isol[1], 1'b1);
    expect_eq("P10 pre-reset hold", qhold[4], 1'b1);
    @(negedge clk);
    cmd_valid <= 1'b1; cmd_op <= OP_ENROLL; cmd_dom <= 8'h00; cmd_priv <= 1'b1; cmd_slot <= 2'd3; cmd_arg <= 8'h20; cmd_flags <= 8'h00;
    // reset is asserted mid-cycle and held ACROSS the next rising edge (the command is presented to that edge), then
    // released mid-cycle -- never at a clock edge (ALP-RST-03: synchronous deassertion; see sf_albion_reset_sync)
    #2 rst_n <= 1'b0;
    #6 rst_n <= 1'b1;
    @(negedge clk); cmd_valid <= 1'b0;
    tick(2);
    expect_eq("P10 reset: response register cleared", rsp_valid, 1'b0);
    expect_eq("P10 reset: lockdown cleared", lockdown, 1'b0);
    expect_eq("P10 reset: isolation cleared", port_isol, 3'b000);
    expect_eq("P10 reset: queue holds cleared", qhold, 8'h00);
    expect_eq("P10 reset: irq cleared", irq, 1'b0);
    expect_eq("P10 reset: lock cleared", cfg_lock, 1'b0);
    expect_eq("P10 reset: every domain slot empty (in-flight ENROLL did not survive)", slot_state, 8'h00);
    expect_eq("P10 reset: keys unassigned", kmask, 16'h0000);
    chkA(0, 8'h10, RD, A0, 4, R_BAD_DOM, "P10 reset: back to default deny");
    exp_viol = 1; exp_dma = 0;
    tel(8'h10, 8'h00, 1'b1, TELP);  expect_eq("P10 reset: counters restarted", tel_data, exp_viol);
    tel(8'h06, 8'h00, 1'b1, TELP);  expect_eq("P10 reset: alert threshold cleared", tel_data, 32'd0);
    root(OP_BIND_PORT, 0, 0, 0, 0, 0, 64'b0011, 0);                                 // not LOCKED any more

    tick(5);
    if (errors == 0 && checks > 0)
      $display("CITADEL_TB_RESULT tb_citadel_system PASS checks=%0d", checks);
    else
      $display("CITADEL_TB_RESULT tb_citadel_system FAIL errors=%0d checks=%0d", errors, checks);
    $finish;
  end
endmodule
