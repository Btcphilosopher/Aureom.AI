// =============================================================================
//  tb_citadel_crypto.sv  --  CloudCrypto adapter, integrated with the real domain table
// -----------------------------------------------------------------------------
//  * SHA-256 requests run on the REAL secworks SHA-256 core (third_party/secworks_sha256,
//    validated in Project 28) and its digest is compared with the NIST "abc" value.
//  * Keyed algorithms (AES-GCM, ...) run on a BENCH ENGINE MODEL: it only records the
//    command it saw and answers on demand.  It is NOT cryptography.  No AES-GCM block
//    exists in the repository; the adapter's capability handling is exercised by switching
//    the advertised capability bits.
//  DUT inputs are assigned as whole vectors / scalars with non-blocking assignments.
// =============================================================================
`timescale 1ns/1ps
module tb_citadel_crypto;
  localparam int unsigned NDOM = 4, NW = 2, NP = 2, NDEV = 7, NQ = 4, NKEY = 4, AW = 64, CTX_W = 8, SRC = 1;
  localparam logic [3:0] OK = 0, BAD_ALGO = 1, UNSUPPORTED = 2, DENIED_DOMAIN = 3, DENIED_KEY = 4, ENGINE_ERR = 5, AUTH_FAIL = 6,
                         KEY_WIPED = 7, KEY_BLOCKED = 8;
  localparam logic [3:0] A_SHA = 1, A_GCM_ENC = 2, A_GCM_DEC = 3, A_CMAC = 6;
  localparam logic [3:0] OP_ENROLL = 1, OP_SET_WINDOW = 2, OP_SET_KEYPRM = 6, OP_SET_STATE = 7, OP_REVOKE = 8, OP_BIND_PORT = 9;

  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;

  // ---- domain table (real) --------------------------------------------------------------------
  logic cmd_valid = 1'b0; logic [3:0] cmd_op = '0; logic [7:0] cmd_dom = 8'h00, cmd_arg = '0, cmd_flags = '0; logic cmd_priv = 1'b1;
  logic [1:0] cmd_slot = '0; logic cmd_win = 1'b0; logic cmd_port = 1'b0; logic [63:0] cmd_d0 = '0, cmd_d1 = '0;
  logic rsp_valid; logic [3:0] rsp_status;
  logic tz_valid; logic [NKEY-1:0] tz_mask; logic [NDOM-1:0] slot_clr;
  logic [NDOM*2-1:0] slot_state; logic [NDOM*8-1:0] slot_id; logic [NDOM-1:0] slot_priv, slot_secure;
  logic [NDOM*NW-1:0] win_valid, win_r, win_w, win_x, win_excl; logic [NDOM*NW*AW-1:0] win_base, win_limit;
  logic [NDOM*NDEV-1:0] devrd, devwr; logic [NDOM*NQ-1:0] qmask; logic [NDOM*NKEY-1:0] kmask; logic [NP*NDOM-1:0] bind_v; logic lockv;
  logic [NQ-1:0] clr_qhold; logic [NP-1:0] clr_isol; logic clr_safe, clr_cnt, thresh_we, cmd_deny; logic [15:0] thresh;
  logic look_found, own_found; logic [1:0] look_slot, own_slot;

  sf_citadel_domain_table #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(NDEV), .NQ(NQ), .NKEY(NKEY), .AW(AW)) u_tbl (
    .clk_i(clk), .rst_ni(rst_n), .cfg_en_i(1'b1), .cmd_valid_i(cmd_valid), .cmd_op_i(cmd_op), .cmd_dom_i(cmd_dom), .cmd_priv_i(cmd_priv),
    .cmd_slot_i(cmd_slot), .cmd_win_i(cmd_win), .cmd_port_i(cmd_port), .cmd_arg_dom_i(cmd_arg), .cmd_flags_i(cmd_flags),
    .cmd_data0_i(cmd_d0), .cmd_data1_i(cmd_d1), .rsp_valid_o(rsp_valid), .rsp_status_o(rsp_status), .cmd_deny_o(cmd_deny),
    .ctl_clr_qhold_o(clr_qhold), .ctl_clr_isol_o(clr_isol), .ctl_clr_safe_o(clr_safe), .ctl_clr_cnt_o(clr_cnt), .ctl_thresh_we_o(thresh_we),
    .ctl_thresh_o(thresh), .qtn_valid_i(1'b0), .qtn_slot_i(2'd0), .zero_valid_o(tz_valid), .zero_mask_o(tz_mask), .slot_clr_o(slot_clr),
    .look_dom_i(8'd0), .look_found_o(look_found), .look_slot_o(look_slot), .own_addr_i(64'd0), .own_found_o(own_found), .own_slot_o(own_slot),
    .slot_state_o(slot_state), .slot_id_o(slot_id), .slot_priv_o(slot_priv), .slot_secure_o(slot_secure), .win_valid_o(win_valid),
    .win_base_o(win_base), .win_limit_o(win_limit), .win_r_o(win_r), .win_w_o(win_w), .win_x_o(win_x), .win_excl_o(win_excl),
    .devrd_o(devrd), .devwr_o(devwr), .qmask_o(qmask), .kmask_o(kmask), .bind_o(bind_v), .lock_o(lockv));

  // ---- adapter ----------------------------------------------------------------------------------------
  logic req_valid = 1'b0, rsp_ready = 1'b1, lockdown = 1'b0, dft = 1'b0, zero_all = 1'b0;
  logic [7:0] req_dom = '0, req_key = '0; logic [3:0] req_algo = '0; logic [CTX_W-1:0] req_ctx = '0;
  logic req_ready, a_rsp_valid; logic [3:0] a_rsp_status; logic [CTX_W-1:0] a_rsp_ctx;
  logic eng_valid, eng_ready = 1'b1, eng_done = 1'b0; logic [3:0] eng_algo; logic [7:0] eng_key, eng_dom; logic [CTX_W-1:0] eng_ctx;
  logic [1:0] eng_status = '0; logic [15:0] cap_algo = 16'h0002; logic cap_zeroize = 1'b1;
  logic [NKEY-1:0] key_zero, key_zero_ack = '0, key_prov = '0, key_block; logic auth_fail, zero_unsup; logic [7:0] auth_fail_dom;
  logic [NKEY-1:0] zmask_in = '0; logic zvalid_in = 1'b0;

  sf_citadel_crypto_adapter #(.NDOM(NDOM), .NP(NP), .NKEY(NKEY), .CTX_W(CTX_W), .SRC(SRC)) dut (
    .clk_i(clk), .rst_ni(rst_n), .req_valid_i(req_valid), .req_ready_o(req_ready), .req_dom_i(req_dom), .req_algo_i(req_algo),
    .req_key_i(req_key), .req_ctx_i(req_ctx), .rsp_valid_o(a_rsp_valid), .rsp_ready_i(rsp_ready), .rsp_status_o(a_rsp_status), .rsp_ctx_o(a_rsp_ctx),
    .slot_state_i(slot_state), .slot_id_i(slot_id), .bind_i(bind_v), .kmask_i(kmask), .lockdown_i(lockdown), .dft_active_i(dft),
    .zero_valid_i(tz_valid | zvalid_in), .zero_mask_i(tz_mask | zmask_in), .zero_all_i(zero_all),
    .eng_valid_o(eng_valid), .eng_ready_i(eng_ready), .eng_algo_o(eng_algo), .eng_key_o(eng_key), .eng_dom_o(eng_dom), .eng_ctx_o(eng_ctx),
    .eng_done_i(eng_done), .eng_status_i(eng_status), .cap_algo_i(cap_algo), .cap_zeroize_i(cap_zeroize),
    .key_zero_o(key_zero), .key_zero_ack_i(key_zero_ack), .key_provision_i(key_prov),
    .auth_fail_o(auth_fail), .auth_fail_dom_o(auth_fail_dom), .key_block_o(key_block), .zero_unsupported_o(zero_unsup));

  // ---- REAL SHA-256 core behind the adapter ----------------------------------------------------------------------
  logic sha_init = 1'b0; logic sha_ready, sha_dv; logic [255:0] sha_digest;
  localparam logic [511:0] ABC_BLOCK = {32'h61626380, {14{32'd0}}, 32'h00000018};     // "abc" + 0x80 + zeros + bit length 24 = 16 words
  localparam logic [255:0] ABC_DIGEST = 256'hBA7816BF_8F01CFEA_414140DE_5DAE2223_B00361A3_96177A9C_B410FF61_F20015AD;
  sha256_core u_sha (.clk(clk), .reset_n(rst_n), .init(sha_init), .next(1'b0), .mode(1'b1), .block(ABC_BLOCK),
                     .ready(sha_ready), .digest(sha_digest), .digest_valid(sha_dv));

  // engine glue (TEST code, not part of Citadel): SHA -> real core; everything else -> bench model
  integer sha_started = 0, sha_ok = 0, bench_cmds = 0;
  logic [3:0] bench_algo; logic [7:0] bench_key, bench_dom;
  integer bench_lat = 2;
  logic [1:0] bench_status = '0;
  typedef enum logic [1:0] {G_IDLE, G_SHA, G_BENCH} gstate_e;
  gstate_e gs = G_IDLE;
  integer gcnt = 0;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin gs <= G_IDLE; eng_ready <= 1'b1; eng_done <= 1'b0; sha_init <= 1'b0; gcnt <= 0; end
    else begin
      eng_done <= 1'b0; sha_init <= 1'b0;
      case (gs)
        G_IDLE: if (eng_valid && eng_ready) begin
          eng_ready <= 1'b0;
          if (eng_algo == A_SHA) begin gs <= G_SHA; sha_init <= 1'b1; sha_started <= sha_started + 1; end
          else begin gs <= G_BENCH; gcnt <= bench_lat; bench_cmds <= bench_cmds + 1; bench_algo <= eng_algo; bench_key <= eng_key; bench_dom <= eng_dom; end
        end
        G_SHA: if (sha_dv) begin
          eng_done <= 1'b1; eng_ready <= 1'b1; gs <= G_IDLE;
          if (sha_digest == ABC_DIGEST) begin sha_ok <= sha_ok + 1; eng_status <= 2'd0; end else eng_status <= 2'd1;
        end
        G_BENCH: begin
          if (gcnt > 0) gcnt <= gcnt - 1;
          else begin eng_done <= 1'b1; eng_status <= bench_status; eng_ready <= 1'b1; gs <= G_IDLE; end
        end
        default: gs <= G_IDLE;
      endcase
    end
  end

  // ---- bookkeeping --------------------------------------------------------------------------------------------------------
  integer errors = 0, checks = 0;
  task automatic eq(input string what, input logic [63:0] got, input logic [63:0] exp);
    checks++;
    if (got !== exp) begin errors++; if (errors <= 30) $display("FAIL %s: got %0h expected %0h (t=%0t)", what, got, exp, $time); end
  endtask
  task automatic tick(input integer n); repeat (n) @(negedge clk); endtask

  logic [NKEY-1:0] seen_zero = '0; logic seen_auth = 1'b0; logic [7:0] seen_auth_dom = '0; logic clr_seen = 1'b0;
  always @(negedge clk) begin
    if (clr_seen) begin seen_zero <= '0; seen_auth <= 1'b0; end
    else begin
      seen_zero <= seen_zero | key_zero;
      if (auth_fail) begin seen_auth <= 1'b1; seen_auth_dom <= auth_fail_dom; end
    end
  end
  task automatic clear_seen(); @(negedge clk); clr_seen <= 1'b1; @(negedge clk); clr_seen <= 1'b0; @(negedge clk); endtask

  task automatic cmd(input [3:0] op, input integer slot, input integer port, input [7:0] argdom, input [7:0] flags, input [63:0] d0);
    @(negedge clk);
    cmd_valid <= 1'b1; cmd_op <= op; cmd_slot <= slot[1:0]; cmd_port <= port[0]; cmd_arg <= argdom; cmd_flags <= flags; cmd_d0 <= d0; cmd_d1 <= d0;
    @(negedge clk);
    eq($sformatf("cmd %0d status", op), rsp_status, 4'd0);
    cmd_valid <= 1'b0;
  endtask

  // one request; returns when the response was taken
  logic [3:0] got_status;
  task automatic request(input [7:0] dom, input [3:0] algo, input [7:0] key, input [CTX_W-1:0] ctx);
    @(negedge clk);
    req_valid <= 1'b1; req_dom <= dom; req_algo <= algo; req_key <= key; req_ctx <= ctx;
    @(negedge clk);                                   // accepted at the edge in between (req_ready was high)
    req_valid <= 1'b0;
    for (int w = 0; w < 400 && !a_rsp_valid; w++) @(negedge clk);
    eq("response arrives", a_rsp_valid, 1'b1);
    got_status = a_rsp_status;
    eq("response echoes the context", a_rsp_ctx, ctx);
    @(negedge clk);                                   // rsp_ready is high: taken at this edge
    @(negedge clk);
  endtask

  initial begin : main
    integer cmds0, sha0;
    #1 rst_n = 1'b0; tick(3); rst_n = 1'b1; tick(3);
    // -------- provisioning: port 1 (the adapter's port) is bound to MGMT, A, B only; C is NOT bound to it
    cmd(OP_BIND_PORT, 0, 1, 0, 0, 64'b0111);
    cmd(OP_ENROLL, 0, 0, 8'h01, 8'h03, 0);  cmd(OP_ENROLL, 1, 0, 8'h10, 8'h00, 0);  cmd(OP_ENROLL, 2, 0, 8'h11, 8'h00, 0);  cmd(OP_ENROLL, 3, 0, 8'h12, 8'h00, 0);
    cmd(OP_SET_KEYPRM, 0, 0, 0, 0, 64'b1000);  cmd(OP_SET_KEYPRM, 1, 0, 0, 0, 64'b0001);
    cmd(OP_SET_KEYPRM, 2, 0, 0, 0, 64'b0010);  cmd(OP_SET_KEYPRM, 3, 0, 0, 0, 64'b0100);
    for (int s = 0; s < 4; s++) cmd(OP_SET_STATE, s, 0, 0, 8'd2, 0);
    tick(2);

    // -------- SHA-256 on the REAL validated core
    request(8'h10, A_SHA, 8'd0, 8'hA1);   eq("T1 SHA by an authorised domain", got_status, OK);
    eq("T1 the real SHA-256 core ran once", sha_started, 1);
    eq("T1 its digest equals the NIST 'abc' value", sha_ok, 1);
    request(8'h12, A_SHA, 8'd0, 8'hA2);   eq("T2 domain not bound to the adapter's port", got_status, DENIED_DOMAIN);
    request(8'h77, A_SHA, 8'd0, 8'hA3);   eq("T2 unknown domain", got_status, DENIED_DOMAIN);
    request(8'hFF, A_SHA, 8'd0, 8'hA4);   eq("T2 invalid domain", got_status, DENIED_DOMAIN);
    eq("T2 a refused request never starts the hash core", sha_started, 1);
    request(8'h10, 4'd0, 8'd0, 8'hA5);    eq("T3 algorithm code 0", got_status, BAD_ALGO);
    request(8'h10, 4'd7, 8'd0, 8'hA6);    eq("T3 undefined algorithm code", got_status, BAD_ALGO);
    request(8'h10, 4'd15, 8'd0, 8'hA7);   eq("T3 undefined algorithm code 15", got_status, BAD_ALGO);
    // -------- capability reporting is honest: nothing is emulated
    request(8'h10, A_GCM_ENC, 8'd0, 8'hB1);  eq("T4 AES-GCM not implemented by the engine -> explicit UNSUPPORTED", got_status, UNSUPPORTED);
    request(8'h12, A_GCM_ENC, 8'd0, 8'hB2);  eq("T4 an unauthorised domain learns nothing about capabilities", got_status, DENIED_DOMAIN);
    eq("T4 nothing reached the engine", bench_cmds, 0);
    // -------- keyed algorithms on the bench engine (capability switched on for the test only)
    cap_algo <= 16'h004E;                                   // SHA is bit 1; bits 2,3,6 = GCM enc/dec, CMAC
    tick(1);
    request(8'h10, A_GCM_ENC, 8'd0, 8'hC1);  eq("T5 A uses its own key slot 0", got_status, OK);
    eq("T5 the engine saw slot 0 for domain A (a slot, never key material)", {bench_key, bench_dom}, {8'd0, 8'h10});
    request(8'h10, A_GCM_ENC, 8'd1, 8'hC2);  eq("T5 A may not use B's key slot", got_status, DENIED_KEY);
    request(8'h10, A_GCM_DEC, 8'd9, 8'hC3);  eq("T5 key slot out of range", got_status, DENIED_KEY);
    request(8'h11, A_CMAC, 8'd1, 8'hC4);     eq("T5 B uses its own key slot 1", got_status, OK);
    request(8'h11, A_CMAC, 8'd0, 8'hC5);     eq("T5 B may not use A's key slot", got_status, DENIED_KEY);
    cmds0 = bench_cmds;
    request(8'h10, A_SHA, 8'd3, 8'hC6);      eq("T5 a hash needs no key: the key field is ignored", got_status, OK);
    // -------- domain state
    cmd(OP_SET_STATE, 1, 0, 0, 8'd1, 0); tick(2);
    request(8'h10, A_GCM_ENC, 8'd0, 8'hD1);  eq("T6 suspended domain refused", got_status, DENIED_DOMAIN);
    cmd(OP_SET_STATE, 1, 0, 0, 8'd2, 0); tick(2);
    lockdown <= 1'b1; tick(1);
    request(8'h10, A_GCM_ENC, 8'd0, 8'hD2);  eq("T6 safe state refuses a tenant", got_status, DENIED_DOMAIN);
    request(8'h01, A_GCM_ENC, 8'd3, 8'hD3);  eq("T6 safe state still serves MGMT", got_status, OK);
    lockdown <= 1'b0; dft <= 1'b1; tick(1);
    request(8'h01, A_GCM_ENC, 8'd3, 8'hD4);  eq("T6 DFT access refuses everyone", got_status, DENIED_DOMAIN);
    dft <= 1'b0; tick(1);
    // -------- engine answers
    bench_status <= 2'd2; tick(1);
    clear_seen();
    request(8'h10, A_GCM_DEC, 8'd0, 8'hE1);  eq("T7 tag mismatch is reported", got_status, AUTH_FAIL);
    eq("T7 authentication failure pulse", seen_auth, 1'b1);  eq("T7 ... charged to the right domain", seen_auth_dom, 8'h10);
    bench_status <= 2'd1; tick(1);
    request(8'h10, A_GCM_DEC, 8'd0, 8'hE2);  eq("T7 engine error is reported", got_status, ENGINE_ERR);
    bench_status <= 2'd0; tick(1);
    // -------- zeroisation reflects what the engine really does
    clear_seen();
    cmd(OP_REVOKE, 2, 0, 0, 0, 0);          tick(4);
    eq("T8 revoke asks the engine to wipe exactly B's key slot", seen_zero, 4'b0010);
    eq("T8 the slot is blocked until the wipe is confirmed", key_block[1], 1'b1);
    cmd(OP_ENROLL, 2, 0, 8'h13, 8'h00, 0);  cmd(OP_SET_KEYPRM, 2, 0, 0, 0, 64'b0010);  cmd(OP_SET_STATE, 2, 0, 0, 8'd2, 0);  tick(2);
    request(8'h13, A_GCM_ENC, 8'd1, 8'hF1);  eq("T8 a new tenant cannot use a slot whose wipe is unconfirmed", got_status, KEY_BLOCKED);
    @(negedge clk); key_zero_ack <= 4'b0010; @(negedge clk); key_zero_ack <= '0; tick(2);
    eq("T8 the engine's confirmation unblocks the slot", key_block[1], 1'b0);
    request(8'h13, A_GCM_ENC, 8'd1, 8'hF2);  eq("T8 ... and the new tenant may use it", got_status, OK);
    // an engine that CANNOT wipe: the adapter never claims a wipe, the slot stays blocked
    cap_zeroize <= 1'b0; tick(1);
    cmd(OP_REVOKE, 1, 0, 0, 0, 0);          tick(4);
    eq("T9 unsupported wipe is reported", zero_unsup, 1'b1);
    eq("T9 slot stays blocked (fail closed)", key_block[0], 1'b1);
    cmd(OP_ENROLL, 1, 0, 8'h14, 8'h00, 0);  cmd(OP_SET_KEYPRM, 1, 0, 0, 0, 64'b0001);  cmd(OP_SET_STATE, 1, 0, 0, 8'd2, 0);  tick(2);
    request(8'h14, A_GCM_ENC, 8'd0, 8'hF3);  eq("T9 refused while the old key may still be present", got_status, KEY_BLOCKED);
    @(negedge clk); key_prov <= 4'b0001; @(negedge clk); key_prov <= '0; tick(2);
    request(8'h14, A_GCM_ENC, 8'd0, 8'hF4);  eq("T9 usable once the engine reports a freshly provisioned key", got_status, OK);
    cap_zeroize <= 1'b1; tick(1);
    // -------- a wipe while the operation is in flight
    bench_lat <= 12; tick(1);
    @(negedge clk); req_valid <= 1'b1; req_dom <= 8'h14; req_algo <= A_GCM_ENC; req_key <= 8'd0; req_ctx <= 8'h77;
    @(negedge clk); req_valid <= 1'b0;
    tick(4);
    zero_all <= 1'b1; @(negedge clk); zero_all <= 1'b0;                      // safe-state style wipe of every slot
    for (int w = 0; w < 100 && !a_rsp_valid; w++) @(negedge clk);
    eq("T10 a key wiped during the operation is never reported as success", a_rsp_status, KEY_WIPED);
    @(negedge clk); tick(2);
    eq("T10 every slot is now blocked until confirmed", key_block, 4'b1111);
    key_zero_ack <= 4'b1111; @(negedge clk); key_zero_ack <= '0; tick(2);
    bench_lat <= 2; tick(1);
    // -------- one request at a time, reset abandons the request
    @(negedge clk); req_valid <= 1'b1; req_dom <= 8'h14; req_algo <= A_GCM_ENC; req_key <= 8'd0; req_ctx <= 8'h55;
    @(negedge clk); req_valid <= 1'b0;
    eq("T11 busy: no second request accepted meanwhile", req_ready, 1'b0);
    @(negedge clk); rst_n <= 1'b0; #3 rst_n <= 1'b1; tick(3);
    eq("T11 reset abandons the request: idle", req_ready, 1'b1);
    eq("T11 reset: no command left at the engine", eng_valid, 1'b0);
    eq("T11 reset: no response", a_rsp_valid, 1'b0);
    eq("T11 reset: block flags cleared (the platform reset also wipes the engine)", key_block, 4'b0000);

    tick(5);
    if (errors == 0) $display("CITADEL_TB_RESULT tb_citadel_crypto PASS checks=%0d", checks);
    else             $display("CITADEL_TB_RESULT tb_citadel_crypto FAIL errors=%0d checks=%0d", errors, checks);
    $finish;
  end
endmodule
