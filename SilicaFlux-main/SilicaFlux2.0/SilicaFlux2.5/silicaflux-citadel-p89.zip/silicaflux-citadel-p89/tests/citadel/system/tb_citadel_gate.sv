// =============================================================================
//  tb_citadel_gate.sv  --  end-to-end enforcement: sf_citadel_gate + sf_citadel_security + a memory model
// -----------------------------------------------------------------------------
//  Random ALP traffic (reads / writes, in-window / out-of-window / boundary-spanning / foreign / spoofed-domain / invalid-op)
//  with random master and target backpressure.  A SHADOW MODEL predicts, per request, permit or deny and the read data.
//  Checked:
//   * a permitted request is answered OKAY (read data = shadow); a denied one is answered ACCESS_DENIED / BAD_OPCODE / BAD_ATTR
//     with the TAG echoed and ZERO data, in request order;
//   * NO DENIED REQUEST EVER REACHES THE TARGET (target request count == permitted request count);
//   * the target memory equals the shadow memory bit for bit -- a denied write changed nothing;
//   * the violation counter equals the number of denied requests (each counted once).
//  DUT inputs are assigned with non-blocking assignments, whole vectors only; every signal has one driver.
// =============================================================================
`timescale 1ns/1ps
module tb_citadel_gate;
  localparam int unsigned NDOM = 2, NW = 2, NP = 1, NDEV = 7, NQ = 2, NKEY = 1, AW = 64, LEN_W = 32;
  localparam int unsigned NREQ = 1500;
  localparam logic [63:0] W0 = 64'h1000, W0E = 64'h1FFF;       // 4 KiB window, read/write
  localparam logic [63:0] W1 = 64'h2000, W1E = 64'h2017;       // 24 bytes: the beat at 0x2010 spans the window end
  localparam logic [63:0] FOREIGN = 64'h4000;                   // another domain's exclusive window

  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;

  // ---- configuration port
  logic cmd_valid = 1'b0; logic [3:0] cmd_op = '0; logic [7:0] cmd_arg = '0, cmd_flags = '0; logic cmd_slot = 1'b0, cmd_win = 1'b0;
  logic [63:0] cmd_d0 = '0, cmd_d1 = '0; logic rsp_valid; logic [3:0] rsp_status;
  logic tel_valid = 1'b0; logic [7:0] tel_addr = '0; logic tel_rvalid, tel_err; logic [31:0] tel_rdata;

  // ---- gate wiring
  logic m_req_valid = 1'b0, m_req_ready, m_rsp_valid, m_rsp_ready = 1'b0, t_req_valid, t_req_ready = 1'b0, t_rsp_valid = 1'b0, t_rsp_ready;
  logic [235:0] m_req = '0, t_req; logic [147:0] m_rsp, t_rsp = '0;
  logic [15:0] ev = '0; logic [0:0] eng_done = 1'b0, eng_rst, port_isol; logic [3:0] unused4;
  logic t_mute = 1'b0, t_stall = 1'b0, special = 1'b0;
  logic chk_valid, chk_commit, chk_permit; logic [7:0] chk_dom, chk_attr, chk_idx; logic [3:0] chk_op, chk_status, chk_reason;
  logic [63:0] chk_addr; logic [31:0] chk_len; logic [1:0] chk_cls; logic [15:0] outstanding; logic orphan;

  sf_citadel_gate #(.OUT_W(16)) u_gate (
    .clk_i(clk), .rst_ni(rst_n), .m_req_valid_i(m_req_valid), .m_req_ready_o(m_req_ready), .m_req_i(m_req),
    .m_rsp_valid_o(m_rsp_valid), .m_rsp_ready_i(m_rsp_ready), .m_rsp_o(m_rsp),
    .t_req_valid_o(t_req_valid), .t_req_ready_i(t_req_ready), .t_req_o(t_req),
    .t_rsp_valid_i(t_rsp_valid), .t_rsp_ready_o(t_rsp_ready), .t_rsp_i(t_rsp), .flush_i(port_isol[0]),
    .chk_valid_o(chk_valid), .chk_dom_o(chk_dom), .chk_op_o(chk_op), .chk_attr_o(chk_attr), .chk_addr_o(chk_addr), .chk_len_o(chk_len),
    .chk_cls_o(chk_cls), .chk_idx_o(chk_idx), .chk_commit_o(chk_commit), .chk_permit_i(chk_permit), .chk_status_i(chk_status),
    .outstanding_o(outstanding), .rsp_orphan_o(orphan));

  sf_citadel_security #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(NDEV), .NQ(NQ), .NKEY(NKEY), .AW(AW), .LEN_W(LEN_W)) u_cit (
    .clk_i(clk), .rst_ni(rst_n), .cfg_en_i(1'b1), .dft_active_i(1'b0),
    .rot_present_i(1'b0), .boot_done_i(1'b0), .boot_ok_i(1'b0), .boot_err_i(8'd0), .fw_run_ok_o(), .boot_state_o(), .boot_err_o(),
    .cmd_valid_i(cmd_valid), .cmd_op_i(cmd_op), .cmd_dom_i(8'h00), .cmd_priv_i(1'b1), .cmd_slot_i(cmd_slot), .cmd_win_i(cmd_win), .cmd_port_i(1'b0),
    .cmd_arg_dom_i(cmd_arg), .cmd_flags_i(cmd_flags), .cmd_data0_i(cmd_d0), .cmd_data1_i(cmd_d1), .rsp_valid_o(rsp_valid), .rsp_status_o(rsp_status),
    .chk_valid_i(chk_valid), .chk_commit_i(chk_commit), .chk_dom_i(chk_dom), .chk_op_i(chk_op), .chk_attr_i(chk_attr), .chk_addr_i(chk_addr),
    .chk_len_i(chk_len), .chk_cls_i(chk_cls), .chk_idx_i(chk_idx), .chk_permit_o(chk_permit), .chk_status_o(chk_status), .chk_reason_o(chk_reason),
    .ev_i(ev), .ev_dom_vld_i(16'd0), .ev_dom_i(128'd0), .ev_idx_i(128'd0), .ev_addr_vld_i(4'd0), .ev_addr_i(256'd0),
    .abort_valid_o(), .abort_mask_o(), .eng_rst_o(eng_rst), .eng_rst_done_i(eng_done), .qhold_o(), .port_isol_o(port_isol), .lockdown_o(), .safe_entry_o(), .irq_o(),
    .zero_valid_o(), .zero_mask_o(), .zero_all_o(),
    .tel_valid_i(tel_valid), .tel_addr_i(tel_addr), .tel_dom_i(8'h00), .tel_priv_i(1'b1), .tel_src_i(1'b0), .tel_rvalid_o(tel_rvalid), .tel_rdata_o(tel_rdata), .tel_err_o(tel_err),
    .slot_state_o(), .slot_id_o(), .bind_o(), .kmask_o(), .cfg_lock_o());

  // ---- target: memory + in-order responses with latency and random backpressure ---------------------------
  logic [127:0] mem [logic [63:0]];
  integer t_reqs = 0, t_writes = 0, t_reads = 0;
  logic [147:0] rq [0:63]; integer rq_wr = 0, rq_rd = 0; integer rq_cnt = 0; integer lat_cnt = 0;
  logic [63:0] ta; logic [127:0] td; logic [3:0] top_; logic [7:0] ttag;
  always @(posedge clk) begin
    t_req_ready <= !t_stall && ($urandom_range(0, 9) < 7);
    if (t_req_valid && t_req_ready) begin
      t_reqs = t_reqs + 1;
      top_ = t_req[235:232]; ttag = t_req[231:224]; ta = t_req[207:144]; td = t_req[127:0];
      if (t_mute) begin
        // hung engine: the request is taken and never answered
      end else if (top_ == 4'd2) begin
        mem[ta] = td; t_writes = t_writes + 1;
        rq[rq_wr % 64] = {ttag, 4'd0, 8'b0000_0011, 128'd0};
      end else begin
        t_reads = t_reads + 1;
        rq[rq_wr % 64] = {ttag, 4'd0, 8'b0000_0010, mem.exists(ta) ? mem[ta] : 128'd0};
      end
      if (!t_mute) begin rq_wr = rq_wr + 1; rq_cnt = rq_cnt + 1; end
    end
    // response channel: valid held until accepted, random delay between responses
    if (t_rsp_valid && t_rsp_ready) begin t_rsp_valid <= 1'b0; rq_rd = rq_rd + 1; rq_cnt = rq_cnt - 1; lat_cnt = $urandom_range(0, 4); end
    else if (!t_rsp_valid && rq_cnt > 0) begin
      if (lat_cnt > 0) lat_cnt = lat_cnt - 1;
      else begin t_rsp <= rq[rq_rd % 64]; t_rsp_valid <= 1'b1; end
    end
  end

  // ---- scoreboard --------------------------------------------------------------------------------------------------------
  integer errors = 0, checks = 0;
  task automatic eq(input string what, input logic [255:0] got, input logic [255:0] exp);
    checks++; if (got !== exp) begin errors++; if (errors <= 25) $display("FAIL %s: got %0h expected %0h (t=%0t)", what, got, exp, $time); end
  endtask
  logic [127:0] shadow [logic [63:0]];
  logic [147:0] exp_rsp [0:NREQ-1];
  integer issued = 0, permitted = 0, denied = 0, perm_writes = 0, rsp_n = 0;
  logic [147:0] sp_rsp [0:7]; integer sp_n = 0;

  function automatic logic permitted_by_model(input logic [7:0] dom, input logic [3:0] op, input logic [7:0] attr, input logic [63:0] addr);
    logic [63:0] last;
    last = addr + 64'd15;
    permitted_by_model = 1'b0;
    if (dom == 8'h10 && (op == 4'd1 || op == 4'd2) && attr == 8'h00 && last >= addr) begin
      if (addr >= W0 && last <= W0E) permitted_by_model = 1'b1;
      if (addr >= W1 && last <= W1E) permitted_by_model = 1'b1;
    end
  endfunction

  // response monitor: in order, one check per response
  always @(negedge clk) begin
    if (m_rsp_valid && m_rsp_ready && special) begin
      sp_rsp[sp_n % 8] = m_rsp; sp_n = sp_n + 1;
    end else if (m_rsp_valid && m_rsp_ready) begin
      eq("response in request order: tag", m_rsp[147:140], exp_rsp[rsp_n][147:140]);
      eq("response status", m_rsp[139:136], exp_rsp[rsp_n][139:136]);
      eq("response meta (last, is_write)", m_rsp[135:128], exp_rsp[rsp_n][135:128]);
      eq("response data (read data / zero on error)", m_rsp[127:0], exp_rsp[rsp_n][127:0]);
      rsp_n = rsp_n + 1;
    end
    eq("no orphan target response", orphan, 1'b0);
  end
  // master-side response backpressure: changes right AFTER a clock edge, so the mid-cycle sample above is what the next edge sees
  always @(posedge clk) m_rsp_ready <= ($urandom_range(0, 9) < 6);

  // ---- configuration + traffic -----------------------------------------------------------------------------------------
  task automatic cfg(input [3:0] op, input integer slot, input integer win, input [7:0] arg, input [7:0] flags, input [63:0] d0, input [63:0] d1);
    @(negedge clk);
    cmd_valid <= 1'b1; cmd_op <= op; cmd_slot <= slot[0]; cmd_win <= win[0]; cmd_arg <= arg; cmd_flags <= flags; cmd_d0 <= d0; cmd_d1 <= d1;
    @(negedge clk); eq("configuration accepted", rsp_status, 4'd0); cmd_valid <= 1'b0;
  endtask

  // present one request and return as soon as the gate has ACCEPTED it (ready is sampled mid-cycle, i.e. it is the
  // value the next rising edge will see); the request may still be held inside the gate afterwards
  task automatic present(input [235:0] rqv);
    @(negedge clk);
    m_req <= rqv; m_req_valid <= 1'b1;
    #1;
    while (!m_req_ready) begin @(negedge clk); #1; end
    @(negedge clk);
    m_req_valid <= 1'b0;
  endtask

  // watchdog: a hang is a failure, not a timeout of the harness
  initial begin
    #40_000_000;
    $display("CITADEL_TB_RESULT tb_citadel_gate FAIL watchdog: simulation did not finish (phase=%0d)", phase);
    $finish;
  end
  integer phase = 0;

  logic [7:0] dom_sel, attr_sel; logic [3:0] op_sel; logic [63:0] addr_sel; logic [127:0] wdata; logic perm; logic [7:0] tag_v;
  logic [235:0] rq_v;
  initial begin : main
    #1 rst_n = 1'b0; repeat (3) @(negedge clk); rst_n = 1'b1; repeat (2) @(negedge clk);
    cfg(4'd9, 0, 0, 8'd0, 8'd0, 64'b01, 64'd0);                                   // bind port 0 to slot 0 ONLY: label 0x11 on this port is a spoof
    cfg(4'd1, 0, 0, 8'h10, 8'h00, 64'd0, 64'd0);   cfg(4'd1, 1, 0, 8'h11, 8'h00, 64'd0, 64'd0);
    cfg(4'd2, 0, 0, 8'd0, 8'b0011, W0, W0E);       cfg(4'd2, 0, 1, 8'd0, 8'b0011, W1, W1E);    // domain 0x10: RW windows
    cfg(4'd2, 1, 0, 8'd0, 8'b1011, FOREIGN, FOREIGN + 64'hFFF);                                    // domain 0x11: its own exclusive window
    cfg(4'd7, 0, 0, 8'd0, 8'd2, 64'd0, 64'd0);     cfg(4'd7, 1, 0, 8'd0, 8'd2, 64'd0, 64'd0);   // both ACTIVE
    repeat (3) @(negedge clk);

    for (int n = 0; n < NREQ; n++) begin
      // choose a request
      case ($urandom_range(0, 9))
        0, 1, 2, 3: addr_sel = W0 + 64'(16 * $urandom_range(0, 255));        // inside the 4 KiB window
        4:          addr_sel = W0 - 64'd16 + 64'(16 * $urandom_range(0, 1)) * 64'h1000;   // just below / at the end boundary region
        5:          addr_sel = W1 + 64'(16 * $urandom_range(0, 2));          // 0x2000 ok, 0x2010 SPANS the window end, 0x2020 outside
        6:          addr_sel = FOREIGN + 64'(16 * $urandom_range(0, 8));     // another domain's protected region
        7:          addr_sel = 64'hFFFF_FFFF_FFFF_FFF0;                       // top of the address space
        default:    addr_sel = {$urandom, $urandom} & 64'hFFFF_FFFF_FFFF_FFF0;
      endcase
      dom_sel  = ($urandom_range(0, 9) < 8) ? 8'h10 : (($urandom_range(0, 1) == 0) ? 8'h11 : 8'h77);   // 0x11 is bound to the port but is NOT this master's domain; 0x77 unknown
      op_sel   = ($urandom_range(0, 19) == 0) ? 4'd0 : (($urandom_range(0, 1) == 0) ? 4'd1 : 4'd2);
      attr_sel = ($urandom_range(0, 19) == 0) ? 8'h04 : 8'h00;                 // occasionally claims privilege
      wdata    = {$urandom, $urandom, $urandom, $urandom};
      tag_v    = issued[7:0];
      perm     = permitted_by_model(dom_sel, op_sel, attr_sel, addr_sel);
      // expected response (computed in ISSUE order == target order)
      if (perm) begin
        permitted++;
        if (op_sel == 4'd2) begin shadow[addr_sel] = wdata; perm_writes++; exp_rsp[issued] = {tag_v, 4'd0, 8'b0000_0011, 128'd0}; end
        else exp_rsp[issued] = {tag_v, 4'd0, 8'b0000_0010, shadow.exists(addr_sel) ? shadow[addr_sel] : 128'd0};
      end else begin
        denied++;
        // coarse requester status: BAD_OPCODE for an invalid op, otherwise ACCESS_DENIED (unknown / spoofed domain, privilege claim, no window)
        exp_rsp[issued] = {tag_v, (op_sel == 4'd0) ? 4'd3 : 4'd2, 4'b0000, 1'b0, 1'b0, 1'b1, (op_sel == 4'd2), 128'd0};
      end
      issued++;
      rq_v = {op_sel, tag_v, dom_sel, attr_sel, addr_sel, 16'hFFFF, wdata};
      // present it and hold until accepted
      @(negedge clk);
      m_req <= rq_v; m_req_valid <= 1'b1;
      while (1) begin
        @(posedge clk); #1;
        if (m_req_ready) break;
      end
      @(negedge clk);
      m_req_valid <= 1'b0;
      repeat ($urandom_range(0, 3)) @(negedge clk);
    end
    // drain
    for (int w = 0; w < 4000 && rsp_n < NREQ; w++) @(negedge clk);
    repeat (5) @(negedge clk);

    eq("every request answered exactly once", rsp_n, NREQ);
    eq("NO DENIED REQUEST REACHED THE TARGET: target saw exactly the permitted requests", t_reqs, permitted);
    eq("target writes == permitted writes", t_writes, perm_writes);
    eq("nothing left outstanding", outstanding, 0);
    // memory image == shadow image: a denied write changed nothing
    begin
      logic [63:0] k; integer diff = 0;
      if (shadow.first(k)) do begin if (!mem.exists(k) || mem[k] !== shadow[k]) diff++; end while (shadow.next(k));
      if (mem.first(k)) do begin if (!shadow.exists(k)) diff++; end while (mem.next(k));
      eq("target memory equals the shadow memory bit for bit (denied writes updated nothing)", diff, 0);
    end
    // each denied request counted exactly once
    @(negedge clk); tel_valid <= 1'b1; tel_addr <= 8'h10; @(negedge clk); tel_valid <= 1'b0;
    eq("violation counter == number of denied requests", tel_rdata, denied);
    eq("traffic mix sanity: at least 300 permitted, 300 denied", (permitted >= 300) && (denied >= 300), 1);
    eq("traffic mix sanity: boundary-spanning case exercised", denied >= 1, 1);
    // =====================================================================================================
    //  CONTAINMENT: a hung engine must not wedge the explicit-error path; a held request is cancelled, never forwarded
    // =====================================================================================================
    begin : flush_phase
      integer t_before;
      phase = 1; special = 1'b1; sp_n = 0;
      // (1) the target takes a permitted read and never answers (engine hung)
      t_mute = 1'b1;
      present({4'd1, 8'hA0, 8'h10, 8'h00, W0, 16'hFFFF, 128'd0});
      repeat (8) @(negedge clk);
      eq("flush: one request outstanding behind a hung engine", outstanding, 1);
      // a DENIED request (another domain's region) queues behind it: ordering holds the error back
      present({4'd1, 8'hA1, 8'h10, 8'h00, FOREIGN, 16'hFFFF, 128'd0});
      repeat (30) @(negedge clk);
      eq("flush: the denied request's error is ordered behind the unanswered request", sp_n, 0);
      // the fault manager isolates the port and resets the engine (WATCHDOG, engine 0)
      @(negedge clk); ev <= 16'h0100; @(negedge clk); ev <= 16'h0000;
      repeat (8) @(negedge clk);
      eq("flush: port isolated while the engine resets", port_isol[0], 1'b1);
      eq("flush: the outstanding count is cleared", outstanding, 0);
      eq("flush: the denied request now gets its explicit error (one response)", sp_n, 1);
      eq("flush: ... tag echoed", sp_rsp[0][147:140], 8'hA1);
      eq("flush: ... status ACCESS_DENIED", sp_rsp[0][139:136], 4'd2);
      eq("flush: ... zero data", sp_rsp[0][127:0], 128'd0);
      // a new request during the isolation is denied explicitly too
      present({4'd1, 8'hA2, 8'h10, 8'h00, W0, 16'hFFFF, 128'd0});
      repeat (8) @(negedge clk);
      eq("flush: request during isolation gets an explicit error", sp_n, 2);
      eq("flush: ... status ACCESS_DENIED", sp_rsp[1][139:136], 4'd2);
      // engine reports reset done: isolation ends
      @(negedge clk); eng_done <= 1'b1; repeat (3) @(negedge clk); eng_done <= 1'b0; repeat (3) @(negedge clk);
      eq("flush: isolation ended on done", port_isol[0], 1'b0);
      t_mute = 1'b0;

      phase = 2;
      // (2) a permitted request is HELD (target not ready) when the port is isolated: cancelled, never forwarded
      sp_n = 0; t_stall = 1'b1; t_before = t_reqs;
      present({4'd1, 8'hB0, 8'h10, 8'h00, W0, 16'hFFFF, 128'd0});
      repeat (4) @(negedge clk);
      eq("cancel: the permitted request is presented to the stalled target", t_req_valid, 1'b1);
      @(negedge clk); ev <= 16'h0100; @(negedge clk); ev <= 16'h0000;
      repeat (6) @(negedge clk);
      eq("cancel: nothing is presented once the port is isolated", t_req_valid, 1'b0);
      eq("cancel: one explicit response", sp_n, 1);
      eq("cancel: ... tag echoed", sp_rsp[0][147:140], 8'hB0);
      eq("cancel: ... status CANCELLED", sp_rsp[0][139:136], 4'd9);
      eq("cancel: ... zero data", sp_rsp[0][127:0], 128'd0);
      @(negedge clk); eng_done <= 1'b1; repeat (3) @(negedge clk); eng_done <= 1'b0; repeat (3) @(negedge clk);
      t_stall = 1'b0;
      repeat (12) @(negedge clk);
      eq("cancel: the cancelled request NEVER reached the target", t_reqs, t_before);
      eq("cancel: no second response", sp_n, 1);

      phase = 3;
      // (3) service resumes
      present({4'd2, 8'hC0, 8'h10, 8'h00, W0 + 64'h40, 16'hFFFF, 128'h1234_5678_9ABC_DEF0_0FED_CBA9_8765_4321});
      present({4'd1, 8'hC1, 8'h10, 8'h00, W0 + 64'h40, 16'hFFFF, 128'd0});
      repeat (30) @(negedge clk);
      eq("resume: both requests answered", sp_n, 3);
      eq("resume: write OKAY", sp_rsp[1][139:136], 4'd0);
      eq("resume: read OKAY with the written data", sp_rsp[2][139:136] == 4'd0 && sp_rsp[2][127:0] == 128'h1234_5678_9ABC_DEF0_0FED_CBA9_8765_4321, 1'b1);
      special = 1'b0;
    end

    if (errors == 0) $display("CITADEL_TB_RESULT tb_citadel_gate PASS checks=%0d requests=%0d permitted=%0d denied=%0d target_writes=%0d", checks, NREQ, permitted, denied, t_writes);
    else             $display("CITADEL_TB_RESULT tb_citadel_gate FAIL errors=%0d checks=%0d", errors, checks);
    $finish;
  end
endmodule
