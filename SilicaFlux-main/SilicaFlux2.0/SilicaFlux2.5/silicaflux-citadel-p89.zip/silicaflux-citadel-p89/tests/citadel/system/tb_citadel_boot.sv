// =============================================================================
//  tb_citadel_boot.sv  --  secure-boot gate wired into sf_citadel_security (SECBOOT_EN = 1, strict)
//  * privileged configuration and privileged telemetry are CLOSED until an authenticated verdict;
//  * a failed boot (every failure mode) drives the platform to the SAFE STATE, keeps the configuration
//    port closed, and reports the failure code on the platform output;
//  * recovery is by reset only.
//  This tests the integration of the policy.  No signature is verified anywhere in this repository's Citadel.
// =============================================================================
`timescale 1ns/1ps
module tb_citadel_boot;
  localparam int unsigned NDOM = 2, NW = 1, NP = 1, NDEV = 7, NQ = 2, NKEY = 2, AW = 64, LEN_W = 32;
  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;
  logic rot = 1'b0, done = 1'b0, ok = 1'b0; logic [7:0] berr = '0;
  logic fw_run; logic [2:0] bstate; logic [7:0] berr_o;
  logic cmd_valid = 1'b0; logic [3:0] cmd_op = '0; logic [7:0] cmd_dom = 8'h00, cmd_arg = '0, cmd_flags = '0; logic cmd_priv = 1'b1;
  logic cmd_slot = 1'b0; logic [63:0] cmd_d0 = '0, cmd_d1 = '0; logic rsp_valid; logic [3:0] rsp_status;
  logic [7:0] chk_dom = '0; logic [3:0] chk_op = '0; logic [63:0] chk_addr = '0; logic chk_valid = 1'b0, chk_permit;
  logic [3:0] chk_status, chk_reason;
  logic lockdown, irq, safe_entry, zero_all, zero_valid; logic [NKEY-1:0] zmask;
  logic tel_valid = 1'b0; logic [7:0] tel_addr = '0; logic tel_rvalid, tel_err; logic [31:0] tel_rdata;

  sf_citadel_security #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(NDEV), .NQ(NQ), .NKEY(NKEY), .AW(AW), .LEN_W(LEN_W),
                        .SECBOOT_EN(1'b1), .ALLOW_UNAUTH(1'b0), .BOOT_TIMEOUT(0)) dut (
    .clk_i(clk), .rst_ni(rst_n), .cfg_en_i(1'b1), .dft_active_i(1'b0),
    .rot_present_i(rot), .boot_done_i(done), .boot_ok_i(ok), .boot_err_i(berr), .fw_run_ok_o(fw_run), .boot_state_o(bstate), .boot_err_o(berr_o),
    .cmd_valid_i(cmd_valid), .cmd_op_i(cmd_op), .cmd_dom_i(cmd_dom), .cmd_priv_i(cmd_priv), .cmd_slot_i(cmd_slot), .cmd_win_i(1'b0), .cmd_port_i(1'b0),
    .cmd_arg_dom_i(cmd_arg), .cmd_flags_i(cmd_flags), .cmd_data0_i(cmd_d0), .cmd_data1_i(cmd_d1), .rsp_valid_o(rsp_valid), .rsp_status_o(rsp_status),
    .chk_valid_i(chk_valid), .chk_commit_i(chk_valid), .chk_dom_i(chk_dom), .chk_op_i(chk_op), .chk_attr_i(8'd0), .chk_addr_i(chk_addr),
    .chk_len_i(32'd4), .chk_cls_i(2'd0), .chk_idx_i(8'd0), .chk_permit_o(chk_permit), .chk_status_o(chk_status), .chk_reason_o(chk_reason),
    .ev_i(16'd0), .ev_dom_vld_i(16'd0), .ev_dom_i(128'd0), .ev_idx_i(128'd0), .ev_addr_vld_i(4'd0), .ev_addr_i(256'd0),
    .abort_valid_o(), .abort_mask_o(), .eng_rst_o(), .eng_rst_done_i(1'b0), .qhold_o(), .port_isol_o(), .lockdown_o(lockdown), .safe_entry_o(safe_entry),
    .irq_o(irq), .zero_valid_o(zero_valid), .zero_mask_o(zmask), .zero_all_o(zero_all),
    .tel_valid_i(tel_valid), .tel_addr_i(tel_addr), .tel_dom_i(8'h00), .tel_priv_i(1'b1), .tel_src_i(1'b0), .tel_rvalid_o(tel_rvalid), .tel_rdata_o(tel_rdata), .tel_err_o(tel_err),
    .slot_state_o(), .slot_id_o(), .bind_o(), .kmask_o(), .cfg_lock_o());

  integer errors = 0, checks = 0;
  logic seen_safe = 1'b0, seen_zall = 1'b0, clr_seen = 1'b0;
  always @(negedge clk) begin
    if (clr_seen) begin seen_safe <= 1'b0; seen_zall <= 1'b0; end
    else begin if (safe_entry) seen_safe <= 1'b1; if (zero_all) seen_zall <= 1'b1; end
  end
  task automatic eq(input string what, input logic [63:0] got, input logic [63:0] exp);
    checks++; if (got !== exp) begin errors++; if (errors <= 20) $display("FAIL %s: got %0h expected %0h (t=%0t)", what, got, exp, $time); end
  endtask
  task automatic tick(input integer n); repeat (n) @(negedge clk); endtask
  task automatic reset(); @(negedge clk); clr_seen <= 1'b1; rst_n <= 1'b0; #3 rst_n <= 1'b1; rot <= 1'b0; done <= 1'b0; ok <= 1'b0; berr <= '0; tick(2); clr_seen <= 1'b0; tick(2); endtask
  task automatic enroll(input [3:0] exp);
    @(negedge clk); cmd_valid <= 1'b1; cmd_op <= 4'd1; cmd_slot <= 1'b0; cmd_arg <= 8'h10; cmd_flags <= 8'h00;
    @(negedge clk); eq("ENROLL status", rsp_status, exp); cmd_valid <= 1'b0;
  endtask
  task automatic tel(input [7:0] addr);
    @(negedge clk); tel_valid <= 1'b1; tel_addr <= addr; @(negedge clk); tel_valid <= 1'b0;
  endtask
  task automatic query(input [3:0] exp_reason);
    @(negedge clk); chk_valid <= 1'b1; chk_dom <= 8'h10; chk_op <= 4'd1; chk_addr <= 64'h40_0000_0000;
    #1; eq("data-plane request is denied (default deny / safe state)", chk_permit, 1'b0);
    @(negedge clk); chk_valid <= 1'b0;
  endtask

  initial begin : main
    #1 rst_n = 1'b0; tick(3); rst_n = 1'b1; tick(2);
    // ---- 1. root of trust present, no verdict yet: everything privileged is closed
    @(negedge clk); rot <= 1'b1; tick(3);
    eq("1 state WAIT", bstate, 3'd1);  eq("1 firmware may not run", fw_run, 1'b0);
    enroll(4'd9);                                       // CS_NOT_AUTH
    tel(8'h07);  eq("1 privileged telemetry closed before authentication (error)", tel_err, 1'b1);  eq("1 ... with zero data", tel_rdata, 32'd0);
    eq("1 no containment: lockdown", lockdown, 1'b0);
    // ---- 2. authenticated
    @(negedge clk); done <= 1'b1; ok <= 1'b1; tick(3);
    eq("2 state AUTH_OK", bstate, 3'd2);  eq("2 firmware may run", fw_run, 1'b1);
    enroll(4'd0);
    tel(8'h07);  eq("2 boot-status register readable", tel_err, 1'b0);
    eq("2 boot status: interface wired", tel_rdata[12], 1'b1);  eq("2 boot status: root of trust present (live tie-off)", tel_rdata[11], 1'b1);
    eq("2 boot status: state AUTH_OK", tel_rdata[10:8], 3'd2);
    tel(8'h01);
    eq("2 CAPS: secure-boot interface wired", tel_rdata[1], 1'b1);  eq("2 CAPS: root of trust present", tel_rdata[5], 1'b1);
    // ---- 3. failed boot: safe state, closed configuration, failure code on the platform output
    reset();
    clear_all();
    @(negedge clk); rot <= 1'b1; done <= 1'b1; ok <= 1'b0; berr <= 8'h42; tick(8);
    eq("3 state FAILED", bstate, 3'd3);  eq("3 platform sees the failure code", berr_o, 8'h42);  eq("3 firmware may not run", fw_run, 1'b0);
    eq("3 BOOT_FAIL is FATAL: safe state (lockdown)", lockdown, 1'b1);  eq("3 safe-state entry pulse", seen_safe, 1'b1);
    eq("3 every key zeroised", seen_zall, 1'b1);  eq("3 reported (irq)", irq, 1'b1);
    enroll(4'd9);  eq("3 configuration stays closed", rsp_status, 4'd9);
    // a later 'good' verdict cannot reopen it
    @(negedge clk); done <= 1'b1; ok <= 1'b1; berr <= 8'd0; tick(5);
    eq("3 FAILED is sticky", bstate, 3'd3);  enroll(4'd9);
    // ---- 4. recovery only by reset
    reset();
    @(negedge clk); rot <= 1'b1; tick(3); @(negedge clk); done <= 1'b1; ok <= 1'b1; tick(3);
    eq("4 after reset a genuine boot authenticates", bstate, 3'd2);  eq("4 lockdown cleared by reset", lockdown, 1'b0);  enroll(4'd0);
    // ---- 5. attestation withdrawn at run time: fail closed
    clear_all();
    @(negedge clk); ok <= 1'b0; tick(8);
    eq("5 loss of boot_ok -> FAILED", bstate, 3'd3);  eq("5 loss code", berr_o, 8'hF3);  eq("5 safe state", lockdown, 1'b1);  enroll(4'd9);
    // ---- 6. no root of trust integrated: strict policy keeps the port closed and says so
    reset();
    tick(4);
    eq("6 ABSENT", bstate, 3'd0);  enroll(4'd9);  eq("6 ABSENT does not run firmware", fw_run, 1'b0);
    query(4'd3);

    tick(4);
    if (errors == 0) $display("CITADEL_TB_RESULT tb_citadel_boot PASS checks=%0d", checks);
    else             $display("CITADEL_TB_RESULT tb_citadel_boot FAIL errors=%0d checks=%0d", errors, checks);
    $finish;
  end
  task automatic clear_all(); @(negedge clk); clr_seen <= 1'b1; @(negedge clk); clr_seen <= 1'b0; endtask
endmodule
