/* =============================================================================
 * SilicaFlux TestCore - boot-time MBIST driver (CPU / boot-ROM path)
 *
 * Runs from ROM with no SRAM stack (call it before any SRAM use: SilicaFlux-V
 * start.S executes from ROM and keeps no stack in SRAM before the memory test).
 * The TestCore register block is reached through the system-bus port at
 * SFTC_BASE (SoC address-map decision; SFTC_BASE is a placeholder).
 * Status: compiled for the host with -Wall -Werror -std=c99 as a syntax/
 * type check only.  NOT executed on any target CPU (no SoC integration yet).
 * Behaviour mirrors the RTL-verified sequence in
 * python/tests/test_system_sim.py::test_boot_time_test_over_system_bus.
 * ========================================================================== */
#include <stdint.h>
#include "sftc_regs.h"

#ifndef SFTC_BASE
#define SFTC_BASE 0x10030000u          /* PLACEHOLDER: assign in the SoC memory map */
#endif

static inline void wr(uint32_t off, uint32_t v) { *(volatile uint32_t *)(uintptr_t)(SFTC_BASE + off) = v; }
static inline uint32_t rd(uint32_t off) { return *(volatile uint32_t *)(uintptr_t)(SFTC_BASE + off); }

/* returns SFTC_RES_* ; *first_fail_addr valid when FAIL */
uint32_t sftc_boot_mbist(uint32_t bank_mask, uint32_t algorithm, uint32_t *first_fail_addr, uint32_t max_polls)
{
    uint32_t n;
    if (rd(SFTC_R_REVISION) != SFTC_REVISION) return SFTC_RES_ERROR;            /* wrong / absent TestCore */
    wr(SFTC_R_TEST_CONTROL, 1u << 2);                                            /* CLEAR */
    wr(SFTC_R_ERROR_FLAGS, 0x7FFu);
    wr(SFTC_R_BANK_MASK, bank_mask);
    wr(SFTC_R_UNLOCK, SFTC_UNLOCK_KEY);                                          /* + hw_test_en strap/OTP */
    wr(SFTC_R_MODE_CTRL, SFTC_MODE_MBIST);
    for (n = 0; n < max_polls; n++) {                                          /* wait for ownership */
        uint32_t o = rd(SFTC_R_OWNER_STATUS), ok = 1, k;
        for (k = 0; k < 8; k++)
            if ((bank_mask >> k & 1u) && ((o >> (4 * k)) & 7u) != 4u) ok = 0;
        if (ok) break;
    }
    wr(SFTC_R_TEST_CONTROL, 1u | (algorithm << 4) | (1u << 10));                /* START, scrub on */
    if (rd(SFTC_R_ERROR_FLAGS) & SFTC_EF_ILLEGAL_START) { wr(SFTC_R_MODE_CTRL, SFTC_MODE_NORMAL); return SFTC_RES_NOT_RUN; }
    for (n = 0; n < max_polls; n++)
        if (rd(SFTC_R_TEST_STATUS) & 2u) break;                                  /* DONE */
    {
        uint32_t res = rd(SFTC_R_LAST_RESULT) & 7u;
        if (first_fail_addr) *first_fail_addr = rd(SFTC_R_FF_ADDR);
        wr(SFTC_R_MODE_CTRL, SFTC_MODE_NORMAL);                                   /* release + re-initialised */
        for (n = 0; n < max_polls; n++)
            if ((rd(SFTC_R_OWNER_STATUS) & 0x77777777u) == 0u) break;
        return (n == max_polls) ? SFTC_RES_ERROR : res;
    }
}
