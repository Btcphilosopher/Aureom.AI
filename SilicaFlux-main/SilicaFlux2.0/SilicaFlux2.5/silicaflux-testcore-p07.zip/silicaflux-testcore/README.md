# SilicaFlux TestCore r2 (Project 07)

Memory BIST, test-mode control, JTAG access, logic-DFT preparation, fault injection and silicon diagnostics for
SilicaFlux-V, MCU-I and later SilicaFlux devices.

**Status:** RTL plus verification. It is synthesizable and verified by simulation, formal proofs, synthesis, STA,
OpenROAD scan insertion and an ATPG experiment. **No silicon, FPGA, wafer-probe or packaged-part results exist.**
See `docs/testcore/limitations_and_blockers.md`.

## Start here

| Document | |
|---|---|
| `docs/testcore/final_answers.md` | answers to the 14 project questions, with evidence |
| `docs/testcore/repository_audit.md` | repository / memory inventory / DFT audit, legacy TestCore re-run, defects found |
| `docs/testcore/verification_report.md` | every evidence class, commands, results |
| `reports/testcore/REGRESSION.md` | the recorded regression run (tools, commands, durations, logs) |
| `docs/testcore/generated/` | tables rendered from tool output (coverage, cycles, area, timing, DFT, registers, opcodes) |

## Layout

```
rtl/testcore/            synthesizable RTL (sftc_consts.svh = single authoritative spec)
tb/testcore/             testbenches + models/ (simulation-only fault-injectable memory)
formal/testcore/         SymbiYosys harnesses (6) ; scripts/run_formal.py
python/testcore/         host library, golden model, transports, CLI, ATPG experiment
python/tests/            pytest: unit + RTL system tests
asic/synth|sta|dft|floorplan/  Yosys, OpenSTA, OpenROAD DFT and placement scripts
constraints/             per-test-mode SDC
firmware/testcore/       boot-time MBIST C driver + generated register header
tools/rbb_sim_bridge.py  OpenOCD remote_bitbang server backed by the RTL
third_party/             vendored, unmodified: SRAM Wrapper Library, SilicaFlux-V mem/debug RTL,
                         DataFabric slave; pdk/ (sky130hd views, fetched by scripts/fetch_pdk.sh)
docs/testcore/           design and verification documentation
reports/testcore/        generated evidence (logs, JSON, netlists, reports)
```

## Running

```bash
source scripts/env.sh
```

```bash
make testcore-regress
```

Individual targets: `testcore-lint`, `testcore-test`, `testcore-mbist-test` (also `testcore-fault-injection`),
`testcore-jtag-test`, `testcore-system-test`, `testcore-sfv`, `testcore-datafabric`, `testcore-formal`,
`testcore-synth`, `testcore-scan`, `testcore-atpg`, `testcore-timing`, `testcore-floorplan`, `testcore-openocd`,
`testcore-report`.

**Tools used:**

* Ubuntu: Icarus Verilog 12, Verilator 5.020, Yosys 0.33, z3, boolector, OpenOCD 0.12.
* nixpkgs binary cache: Yosys 0.70, SymbiYosys 0.70, OpenROAD 26Q3 (with OpenSTA).
* Python 3.13 with pydantic 2, pytest and z3-solver.

Steps whose tools are missing report **BLOCKED**, never PASS.

## Git

This directory is a local Git repository on branch `feature/silicaflux-testcore`. As requested, it was **not**
pushed or committed to GitHub.
