# sky130hd standard-cell views (third party)

`sky130_fd_sc_hd__tt_025C_1v80.lib`, `sky130_fd_sc_hd_merged.lef`, `sky130hd.tlef` are open SkyWater SKY130
PDK views (Apache License 2.0, SkyWater Technology / Google), copied from the OpenROAD repository test data
(`test/sky130hd/`, fetched 2026-11-06; hashes in `SHA256SUMS`).  `scripts/fetch_pdk.sh` re-downloads them.
They are open-source; no proprietary foundry data is included in this delivery.
