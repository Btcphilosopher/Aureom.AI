// =============================================================================
// SilicaFlux TestCore :: tb_sfv_integration          *** SIMULATION ONLY ***
// Integration of TestCore with the REAL SilicaFlux-V release-1 SRAM bank slave
// (third_party/silicaflux-v/rtl/mem/sfv_sram_slave, sfv_sram_sp, unmodified):
//   4 x sftc_sfv_bank_shim (DEPTH 8192 x 32 = the SFV main SRAM banks)
//   + sftc_testcore_top driven through its SYSTEM-BUS port by a boot-ROM-like
//     sequencer (the CPU path used for boot-time / POST memory test)
//   + one SFB crossbar-style functional master per bank with scoreboard,
//     honouring quiesce (stands in for CPU/JTAG-SBA traffic).
// Faults are injected with SilicaFlux-V's own simulation hook in sfv_sram_sp
// (fi_en/fi_addr/fi_bit/fi_val: read-path stuck-at).
// Prints TB_SFV lines parsed by python/tests/test_sfv_integration.py.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_sfv_integration;
  import sftc_pkg::*;
  localparam int NB = 4, D = 8192, AW = 13;

  logic clk = 0, rst_n = 1, trst_n = 1;
  always #5 clk = ~clk;
  logic s_req = 0, s_we = 0, s_gnt, s_err;
  logic [11:0] s_addr = 0;
  logic [31:0] s_wdata = 0, s_rdata;
  logic tdo, tdo_oe;
  logic [NB-1:0] b_req, b_gnt, b_rvalid, b_rerr, acq_req, scrub_done, owned, odirty, oev_fault, oev_intr, oev_reinit;
  logic b_we, mbist_busy, ofault_clr;
  logic [AW-1:0] b_addr;
  logic [31:0] b_wdata;
  logic [NB*32-1:0] b_rdata;
  logic [NB*3-1:0] ostate;
  logic [2:0] mode;
  logic scan_mode, scan_en, irq, tdone, tpass, tfail, jm, dm;

  sftc_testcore_top #(
    .BANK_COUNT(NB), .MAX_W(32), .MAX_DEPTH(D), .BANK_WIDTHS({NB{8'd32}}), .BANK_DEPTHS({NB{24'd8192}}),
    .BANK_FLAGS('0), .LOG_DEPTH(4), .TIMEOUT(1024)
  ) dut (
    .tck(1'b0), .trst_n, .tms(1'b1), .tdi(1'b0), .tdo, .tdo_oe, .clk, .rst_n, .hw_dbg_en(1'b1), .hw_test_en(1'b1),
    .cpu_halted(1'b0), .scan_mode_pin(1'b0), .scan_en_pin(1'b0), .s_req, .s_we, .s_addr, .s_wdata, .s_gnt,
    .s_rdata, .s_err, .b_req, .b_we, .b_addr, .b_wdata, .b_gnt, .b_rvalid, .b_rdata, .b_rerr, .acq_req,
    .scrub_done, .mbist_busy, .owner_fault_clear(ofault_clr), .owner_state(ostate), .owned, .owner_dirty(odirty),
    .owner_ev_fault(oev_fault), .owner_ev_intrusion(oev_intr), .owner_ev_reinit(oev_reinit), .mode, .scan_mode,
    .scan_en, .irq, .test_done_o(tdone), .test_pass_o(tpass), .test_fail_o(tfail), .jtag_mode_o(jm), .diag_mode_o(dm)
  );

  // ------------------------------------------------------------------ banks + SFB masters
  logic [NB-1:0] m_en = '0, qreq, qack;
  int   n_err [NB], n_ops [NB];
  genvar k;
  generate
    for (k = 0; k < NB; k++) begin : g_b
      logic req, gnt, we, rvalid, err;
      logic [31:0] addr, wdata, rdata;
      logic [3:0] be;
      logic [31:0] trd;
      sftc_sfv_bank_shim #(.DEPTH(D), .OWN_TIMEOUT(512)) u_shim (
        .clk, .rst_n, .req, .gnt, .addr, .we, .be, .wdata, .rvalid, .rdata, .err,
        .t_req(b_req[k]), .t_gnt(b_gnt[k]), .t_we(b_we), .t_addr(b_addr), .t_wdata(b_wdata),
        .t_rvalid(b_rvalid[k]), .t_rdata(trd), .t_rerr(b_rerr[k]),
        .acq_req(acq_req[k]), .fault_clear(ofault_clr), .quiesce_ack(qack[k]), .quiesce_req(qreq[k]),
        .mbist_busy, .scrub_done(scrub_done[k]), .owned(owned[k]), .owner_state(ostate[k*3 +: 3]),
        .dirty(odirty[k]), .ev_fault(oev_fault[k]), .ev_intrusion(oev_intr[k]), .ev_reinit_req(oev_reinit[k])
      );
      assign b_rdata[k*32 +: 32] = trd;
      // ---- SFB master (req held until gnt; rvalid 1 cycle after accept)
      logic [31:0] shadow [D];
      bit          sval   [D];
      int unsigned r;
      logic pend_rd;
      logic [AW-1:0] pend_a;
      initial begin r = 77 + k; req = 0; we = 0; addr = 0; wdata = 0; be = 0; qack = 0; pend_rd = 0;
                    for (int i = 0; i < D; i++) sval[i] = 0; n_err[k] = 0; n_ops[k] = 0; end
      always @(posedge clk) begin
        if (rvalid && pend_rd) begin
          if (sval[pend_a] && rdata !== shadow[pend_a]) begin
            n_err[k]++; $display("TB_SFV_MASTER_ERROR bank %0d addr %0d got %h exp %h", k, pend_a, rdata, shadow[pend_a]);
          end
        end
        pend_rd <= 0;
        if (req && gnt) begin
          n_ops[k]++;
          if (we) begin shadow[addr[AW+1:2]] = wdata; sval[addr[AW+1:2]] = 1; end   // full-word writes
          else begin pend_rd <= 1; pend_a <= addr[AW+1:2]; end
        end
        // release knowledge: scrubbed = all zero, dirty = unknown
        if (ostate[k*3 +: 3] == 3'd6) for (int i = 0; i < D; i++) begin shadow[i] = 0; sval[i] = !odirty[k]; end
        if (req && !gnt) begin
          // hold (SFB: request held until granted)
        end else if (m_en[k] && !qreq[k] && (({$random(r)} % 100) < 30)) begin
          req <= 1; we <= $random(r); addr <= {17'd0, 13'(({$random(r)}) % D), 2'b00}; wdata <= $random(r); be <= 4'hF;
        end else req <= 0;
        qack[k] <= qreq[k] && !(req && !gnt);
      end
    end
  endgenerate

  // ------------------------------------------------------------------ boot-ROM-like sequencer on the system bus
  task automatic sys_rw(input bit w, input logic [11:0] a, input logic [31:0] d, output logic [31:0] q);
    @(negedge clk); s_req = 1; s_we = w; s_addr = a; s_wdata = d;
    @(posedge clk); while (!s_gnt) @(posedge clk);
    q = s_rdata; #1 s_req = 0;
  endtask
  task automatic wr(input logic [11:0] a, input logic [31:0] d); logic [31:0] q; sys_rw(1, a, d, q); endtask
  task automatic rd(input logic [11:0] a, output logic [31:0] q); sys_rw(0, a, 0, q); endtask

  task automatic run_mbist(input logic [3:0] mask, input logic [3:0] alg, output logic [31:0] res,
                           output logic [31:0] cyc, output logic [31:0] ffaddr, output logic [31:0] ffinfo,
                           output logic [31:0] ffexp, output logic [31:0] ffobs, output logic [31:0] failed);
    logic [31:0] q;
    int guard;
    wr(R_TEST_CONTROL, 32'h4);                 // CLEAR
    wr(R_BANK_MASK, 32'(mask));
    wr(R_UNLOCK, TC_UNLOCK_KEY);
    wr(R_MODE_CTRL, 32'(MODE_MBIST));
    guard = 0;
    do begin rd(R_OWNER_STATUS, q); guard++; end
    while (guard < 2000 && !((q[2:0] == 3'd4 || !mask[0]) && (q[6:4] == 3'd4 || !mask[1]) &&
                              (q[10:8] == 3'd4 || !mask[2]) && (q[14:12] == 3'd4 || !mask[3])));
    wr(R_TEST_CONTROL, 32'h1 | (32'(alg) << 4) | (32'h1 << 10));
    guard = 0;
    do begin repeat (64) @(posedge clk); rd(R_TEST_STATUS, q); guard++; end while (q[0] && guard < 100000);
    rd(R_LAST_RESULT, res); rd(R_CYCLES, cyc); rd(R_FF_ADDR, ffaddr); rd(R_FF_INFO, ffinfo);
    rd(R_FF_EXP0, ffexp); rd(R_FF_OBS0, ffobs); rd(R_BANKS_FAILED, failed);
    wr(R_MODE_CTRL, 32'(MODE_NORMAL));
    guard = 0;
    do begin rd(R_OWNER_STATUS, q); guard++; end while (guard < 2000 && q[15:0] != 16'h0000);
  endtask

  initial begin
    logic [31:0] res, cyc, fa, fi, fe, fo, fb, q;
    #1 rst_n = 0; trst_n = 0;
    #50 rst_n = 1; trst_n = 1;
    rd(R_REVISION, q);
    $display("TB_SFV revision=%08h", q);
    m_en = '1;
    repeat (3000) @(posedge clk);
    // 1. boot-time style test of all four 8192-word banks, fault-free, under live traffic
    run_mbist(4'hF, ALG_MARCH_C_MINUS, res, cyc, fa, fi, fe, fo, fb);
    $display("TB_SFV case=march_all result=%0d cycles=%0d failed=%h", res[2:0], cyc, fb);
    repeat (3000) @(posedge clk);
    // 2. stuck-at-1 on the read path of bank 2, word 4097, bit 13 (SFV's own fault hook)
    g_b[2].u_shim.u_slave.u_ram.fi_en   = 1'b1;
    g_b[2].u_shim.u_slave.u_ram.fi_addr = 32'd4097;
    g_b[2].u_shim.u_slave.u_ram.fi_bit  = 5'd13;
    g_b[2].u_shim.u_slave.u_ram.fi_val  = 1'b1;
    run_mbist(4'h4, ALG_MATS_PLUS, res, cyc, fa, fi, fe, fo, fb);
    $display("TB_SFV case=sa1_bank2 result=%0d cycles=%0d failed=%h ffaddr=%0d ffinfo=%h ffexp=%h ffobs=%h",
             res[2:0], cyc, fb, fa, fi, fe, fo);
    g_b[2].u_shim.u_slave.u_ram.fi_en = 1'b0;
    // 3. checkerboard background March C- on bank 0 only
    run_mbist(4'h1, ALG_CHECKERBOARD, res, cyc, fa, fi, fe, fo, fb);
    $display("TB_SFV case=checker_bank0 result=%0d cycles=%0d failed=%h", res[2:0], cyc, fb);
    repeat (5000) @(posedge clk);
    for (int i = 0; i < NB; i++) $display("TB_SFV master bank=%0d ops=%0d errors=%0d", i, n_ops[i], n_err[i]);
    $display("TB_SFV_DONE");
    $finish;
  end
endmodule
`default_nettype wire
