// =============================================================================
// SilicaFlux TestCore :: tb_mbist
// Case-file-driven testbench for silicaflux_mbist + sftc_mbist_bank_mux with
// up to 4 sftc_fault_mem banks.  The testbench only EXECUTES cases and
// records what happened; pass/fail judgement is made by the independent
// Python golden model (python/testcore/mbist.py, fault_models.py), which
// predicts the exact transaction trace, detection, first-fail record and
// final memory content for each case.
//
// Compile-time configuration (defines, defaults in brackets):
//   TB_BANKS [1]  TB_MAXW [32]  TB_MAXD [256]  TB_W0..3 [32]  TB_D0..3 [256]
//   TB_LMIN [1]  TB_LMAX [1]  TB_GNT [100]  TB_WRESP [0] (bit mask per bank)
//   TB_PIPE_REQ [0]  TB_PIPE_RSP [0]  TB_LOG [4]  TB_TMO [256]
// Run-time: +cases=<file> +results=<file> [+trace=<file>]
// Case line: id alg bg sof scrub mask fbank fkind faddr fbit faddr2 fbit2 fval fparam ctl cparam seed
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

`ifndef TB_BANKS
 `define TB_BANKS 1
`endif
`ifndef TB_MAXW
 `define TB_MAXW 32
`endif
`ifndef TB_MAXD
 `define TB_MAXD 256
`endif
`ifndef TB_W0
 `define TB_W0 `TB_MAXW
`endif
`ifndef TB_W1
 `define TB_W1 `TB_MAXW
`endif
`ifndef TB_W2
 `define TB_W2 `TB_MAXW
`endif
`ifndef TB_W3
 `define TB_W3 `TB_MAXW
`endif
`ifndef TB_D0
 `define TB_D0 `TB_MAXD
`endif
`ifndef TB_D1
 `define TB_D1 `TB_MAXD
`endif
`ifndef TB_D2
 `define TB_D2 `TB_MAXD
`endif
`ifndef TB_D3
 `define TB_D3 `TB_MAXD
`endif
`ifndef TB_LMIN
 `define TB_LMIN 1
`endif
`ifndef TB_LMAX
 `define TB_LMAX `TB_LMIN
`endif
`ifndef TB_GNT
 `define TB_GNT 100
`endif
`ifndef TB_WRESP
 `define TB_WRESP 0
`endif
`ifndef TB_PIPE_REQ
 `define TB_PIPE_REQ 0
`endif
`ifndef TB_PIPE_RSP
 `define TB_PIPE_RSP 0
`endif
`ifndef TB_LOG
 `define TB_LOG 4
`endif
`ifndef TB_TMO
 `define TB_TMO 256
`endif

module tb_mbist;
  import sftc_pkg::*;

  localparam int NB    = `TB_BANKS;
  localparam int MAXW  = `TB_MAXW;
  localparam int MAXD  = `TB_MAXD;
  localparam int AW    = (MAXD > 2) ? $clog2(MAXD) : 1;
  localparam int BW    = (NB > 1) ? $clog2(NB) : 1;
  localparam logic [31:0] PW4 = {8'(`TB_W3), 8'(`TB_W2), 8'(`TB_W1), 8'(`TB_W0)};
  localparam logic [95:0] PD4 = {24'(`TB_D3), 24'(`TB_D2), 24'(`TB_D1), 24'(`TB_D0)};
  localparam logic [3:0]  PR4 = 4'(`TB_WRESP);
  localparam logic [31:0] PF4 = {7'd0, PR4[3], 7'd0, PR4[2], 7'd0, PR4[1], 7'd0, PR4[0]};
  localparam logic [NB*8-1:0]  P_WIDTHS = PW4[NB*8-1:0];
  localparam logic [NB*24-1:0] P_DEPTHS = PD4[NB*24-1:0];
  localparam logic [NB*8-1:0]  P_FLAGS  = PF4[NB*8-1:0];

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  // ---- engine control
  logic          test_enable, start, abort, clear, cfg_bg, cfg_sof, cfg_scrub;
  logic [3:0]    cfg_algo;
  logic [NB-1:0] cfg_mask, owned;
  // ---- engine bus
  logic          t_req, t_we, t_gnt, t_rvalid, t_rerr, t_stray;
  logic [AW-1:0] t_addr;
  logic [MAXW-1:0] t_wdata, t_rdata;
  logic [BW-1:0] t_bank;
  // ---- status
  logic busy, done, pass, fail, aborted, error_st, stopped, scrubbing;
  logic [3:0] state, run_algo;
  logic [BW-1:0] cur_bank;
  logic [2:0] cur_elem, last_result, prev_result;
  logic [AW-1:0] cur_addr;
  logic [NB-1:0] b_tested, b_failed, b_scrubbed;
  logic [31:0] cycles;
  logic ev_refused, ev_tmo, ev_spur, ev_merr, ev_done;
  logic log_pop;
  logic ff_valid, cnt_ovf, log_ovf;
  logic [23:0] ff_info, log_info;
  logic [AW-1:0] ff_addr, log_addr;
  logic [MAXW-1:0] ff_exp, ff_obs, log_synd;
  logic [15:0] fail_count;
  logic [7:0] log_level;

  silicaflux_mbist #(
    .BANK_COUNT(NB), .MAX_W(MAXW), .MAX_DEPTH(MAXD),
    .BANK_WIDTHS(P_WIDTHS), .BANK_DEPTHS(P_DEPTHS), .BANK_FLAGS(P_FLAGS),
    .LOG_DEPTH(`TB_LOG), .TIMEOUT(`TB_TMO)
  ) dut (
    .clk, .rst_n, .test_enable, .start, .abort, .clear, .cfg_algo, .cfg_bg_chk(cfg_bg),
    .cfg_sof, .cfg_scrub, .cfg_bank_mask(cfg_mask), .bank_owned(owned),
    .t_req, .t_we, .t_addr, .t_wdata, .t_bank, .t_gnt, .t_rvalid, .t_rdata, .t_rerr,
    .t_stray_rvalid(t_stray),
    .busy, .done, .pass, .fail, .aborted, .error_st, .stopped, .scrubbing, .state, .cur_bank,
    .cur_elem, .cur_addr, .run_algo, .last_result, .prev_result, .banks_tested(b_tested),
    .banks_failed(b_failed), .banks_scrubbed(b_scrubbed), .cycles,
    .ev_start_refused(ev_refused), .ev_timeout(ev_tmo), .ev_spurious(ev_spur), .ev_mem_err(ev_merr),
    .ev_done, .log_pop, .ff_valid, .ff_info, .ff_addr, .ff_exp, .ff_obs, .fail_count, .cnt_ovf,
    .log_level, .log_ovf, .log_info, .log_addr, .log_synd
  );

  logic [NB-1:0] b_req, b_gnt, b_rvalid, b_rerr;
  logic          b_we;
  logic [AW-1:0] b_addr;
  logic [MAXW-1:0] b_wdata;
  logic [NB*MAXW-1:0] b_rdata;

  sftc_mbist_bank_mux #(.BANK_COUNT(NB), .MAX_W(MAXW), .AW(AW),
                        .PIPE_REQ(`TB_PIPE_REQ), .PIPE_RSP(`TB_PIPE_RSP)) u_mux (
    .clk, .rst_n, .t_req, .t_we, .t_addr, .t_wdata, .t_bank, .t_gnt, .t_rvalid, .t_rdata, .t_rerr,
    .stray_rvalid(t_stray), .b_req, .b_we, .b_addr, .b_wdata, .b_gnt, .b_rvalid, .b_rdata, .b_rerr
  );

  genvar g;
  generate
    for (g = 0; g < NB; g++) begin : g_bank
      localparam int BWID = PW4[g*8 +: 8];
      localparam int BDEP = PD4[g*24 +: 24];
      localparam int BAW  = (BDEP > 2) ? $clog2(BDEP) : 1;
      logic [BWID-1:0] rd;
      sftc_fault_mem #(.W(BWID), .DEPTH(BDEP), .AW(BAW), .LAT_MIN(`TB_LMIN), .LAT_MAX(`TB_LMAX),
                       .GNT_PCT(`TB_GNT), .WRITE_RESP(((`TB_WRESP) >> g) & 1)) u_mem (
        .clk, .rst_n, .req(b_req[g]), .we(b_we), .addr(b_addr[BAW-1:0]), .wdata(b_wdata[BWID-1:0]),
        .gnt(b_gnt[g]), .rvalid(b_rvalid[g]), .rdata(rd), .rerr(b_rerr[g])
      );
      assign b_rdata[g*MAXW +: MAXW] = MAXW'(rd);
    end
  endgenerate

  // ---- hierarchical helpers (constant indices for Icarus)
  task automatic cfg_bank(input int k, input int kind, input int a, input int b, input int a2,
                          input int b2, input int v, input int p, input int unsigned seed);
    case (k)
      0: g_bank[0].u_mem.configure(kind, a, b, a2, b2, v, p, seed);
`ifdef TB_HAS_B1
      1: g_bank[1].u_mem.configure(kind, a, b, a2, b2, v, p, seed);
`endif
`ifdef TB_HAS_B2
      2: g_bank[2].u_mem.configure(kind, a, b, a2, b2, v, p, seed);
`endif
`ifdef TB_HAS_B3
      3: g_bank[3].u_mem.configure(kind, a, b, a2, b2, v, p, seed);
`endif
      default: ;
    endcase
  endtask

  function automatic logic [31:0] fold32(input logic [127:0] d);
    fold32 = d[31:0] ^ d[63:32] ^ d[95:64] ^ d[127:96];
  endfunction

  function automatic logic [31:0] mem_hash(input int k);
    logic [31:0] h;
    h = 32'd0;
    case (k)
      0: for (int i = 0; i < int'(PD4[0*24 +: 24]); i++) h = h * 32'd31 + fold32(128'(g_bank[0].u_mem.mem[i]));
`ifdef TB_HAS_B1
      1: for (int i = 0; i < int'(PD4[1*24 +: 24]); i++) h = h * 32'd31 + fold32(128'(g_bank[1].u_mem.mem[i]));
`endif
`ifdef TB_HAS_B2
      2: for (int i = 0; i < int'(PD4[2*24 +: 24]); i++) h = h * 32'd31 + fold32(128'(g_bank[2].u_mem.mem[i]));
`endif
`ifdef TB_HAS_B3
      3: for (int i = 0; i < int'(PD4[3*24 +: 24]); i++) h = h * 32'd31 + fold32(128'(g_bank[3].u_mem.mem[i]));
`endif
      default: ;
    endcase
    mem_hash = h;
  endfunction

  // ---- trace / event accumulation
  integer fd_res, fd_tr, fd_cases;
  int     cur_id;
  bit     tracing;
  bit     dbg_st = 0;
  logic [NUM_EF-1:0] ef;
  int     n_spur, n_merr;

  always @(posedge clk) begin
    if (rst_n) begin
      if (ev_refused) ef[EF_ILLEGAL_START] <= 1'b1;
      if (ev_tmo)     ef[EF_TIMEOUT]       <= 1'b1;
      if (ev_spur)    begin ef[EF_SPURIOUS] <= 1'b1; n_spur++; end
      if (ev_merr)    begin ef[EF_MEM_ERR]  <= 1'b1; n_merr++; end
      if (cnt_ovf)    ef[EF_CNT_OVF]       <= 1'b1;
      if (log_ovf)    ef[EF_LOG_OVF]       <= 1'b1;
      if (dbg_st) $display("DBG t=%0t st=%0d addr=%0d req=%0b gnt=%0b rv=%0b cyc=%0d", $time, state, t_addr, t_req, t_gnt, t_rvalid, cycles);
      if (tracing && t_req && t_gnt)
        $fdisplay(fd_tr, "T %0d %0d %s %0d %h", cur_id, t_bank, t_we ? "W" : "R", t_addr, t_wdata);
      if (tracing && dut.cmp_en)
        $fdisplay(fd_tr, "C %0d %0d %0d %h %h %0d", cur_id, t_bank, t_addr, dut.op_data,
                  t_rdata & dut.wmask, dut.mism);
    end
  end

  task automatic pulse_start();
    @(negedge clk); start = 1'b1; @(negedge clk); start = 1'b0;
  endtask

  task automatic do_reset();
    @(negedge clk); rst_n = 1'b0; repeat (3) @(negedge clk); rst_n = 1'b1; @(negedge clk);
  endtask

  // wait until the engine is idle (or error) with a cycle guard; returns cycles waited
  task automatic wait_idle(input int guard, output int waited);
    waited = 0;
    @(negedge clk);
    while ((busy || state != 4'd0) && !(error_st) && waited < guard) begin
      @(negedge clk); waited++;
    end
  endtask

  int id, alg, bg, sof, scr, mask, fbank, fkind, faddr, fbit, faddr2, fbit2, fval, fparam, ctl, cparam;
  int unsigned seed;
  int n, waited, refused2, res2, cyc2, ten_t;
  string logs, mems;

  initial begin
    string cf, rf, tf;
    test_enable = 1; start = 0; abort = 0; clear = 0; cfg_bg = 0; cfg_sof = 0; cfg_scrub = 1;
    cfg_algo = 0; cfg_mask = '1; owned = '1; log_pop = 0; tracing = 0; ef = '0;
    if ($test$plusargs("dbgst")) dbg_st = 1;
    if (!$value$plusargs("cases=%s", cf)) $fatal(1, "missing +cases");
    if (!$value$plusargs("results=%s", rf)) $fatal(1, "missing +results");
    fd_cases = $fopen(cf, "r");
    fd_res   = $fopen(rf, "w");
    if ($value$plusargs("trace=%s", tf)) begin fd_tr = $fopen(tf, "w"); end else fd_tr = 0;
    do_reset();

    n = 17;
    while (n == 17) begin
      n = $fscanf(fd_cases, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\n", id, alg, bg, sof, scr,
                  mask, fbank, fkind, faddr, fbit, faddr2, fbit2, fval, fparam, ctl, cparam, seed);
      if (n == 17) begin
      cur_id = id;
      tracing = (fd_tr != 0);
      // ---- configure memories: fault only on fbank, all contents re-randomised
      for (int k = 0; k < NB; k++)
        if (k == fbank) cfg_bank(k, fkind, faddr, fbit, faddr2, fbit2, fval, fparam, seed + k);
        else            cfg_bank(k, 0, 0, 0, 0, 0, 0, 0, seed + k);
      if (ctl != 109) do_reset();
      ef = '0; n_spur = 0; n_merr = 0;
      test_enable = 1; owned = '1;
      cfg_algo = alg[3:0]; cfg_bg = bg[0]; cfg_sof = sof[0]; cfg_scrub = scr[0];
      cfg_mask = NB'(mask);
      if (ctl == 105) owned = ~NB'(mask);           // selected banks not owned
      if (ctl == 102) cfg_mask = '0;                // empty mask
      refused2 = 0; res2 = 0; cyc2 = 0;
      @(negedge clk); clear = 1; @(negedge clk); clear = 0;
      fork
        begin
          pulse_start();
        end
        begin
          // control actions relative to start
          if (ctl == 100 || ctl == 103 || ctl == 104 || ctl == 107 || ctl == 101) begin
            repeat (cparam + 2) @(negedge clk);
            case (ctl)
              100: begin abort = 1; @(negedge clk); abort = 0; end
              103: begin start = 1; @(negedge clk); start = 0; refused2 = ef[EF_ILLEGAL_START]; end
              104: begin test_enable = 0; end
              107: begin owned = '0; end
              101: begin
                rst_n = 0; repeat (3) @(negedge clk);
                // during reset: no request may be presented
                if (t_req) $display("SFTC_ASSERTION_FAILED tb: request during reset");
                rst_n = 1; @(negedge clk);
                if (busy || t_req) $display("SFTC_ASSERTION_FAILED tb: engine active after reset");
              end
              default: ;
            endcase
          end
        end
      join
      wait_idle(4000000, waited);
      if (ctl == 103) refused2 = ef[EF_ILLEGAL_START];
      if (ctl == 101) begin
        // after the reset: memory content may be partially overwritten; rerun must pass cleanly
        ef = '0;
        @(negedge clk); clear = 1; @(negedge clk); clear = 0;
        pulse_start();
        wait_idle(4000000, waited);
      end
      if (ctl == 109) begin
        // repeated execution without reset: run a second time, record its result
        res2 = int'(last_result); cyc2 = int'(cycles);
        pulse_start();
        wait_idle(4000000, waited);
      end
      repeat (4) @(negedge clk);
      // ---- drain the failure FIFO
      logs = "-";
      while (log_level != 0) begin
        $sformat(logs, "%s%0h:%0h:%0h,", logs, log_addr, log_info, log_synd);
        @(negedge clk); log_pop = 1; @(negedge clk); log_pop = 0;
      end
      mems = "";
      for (int k = 0; k < NB; k++) $sformat(mems, "%s%08h,", mems, mem_hash(k));
      $fdisplay(fd_res, "R id=%0d result=%0d prev=%0d fail=%0d done=%0d aborted=%0d stopped=%0d err=%0d cnt=%0d cnt_ovf=%0d ffv=%0d ffinfo=%0h ffaddr=%0h ffexp=%0h ffobs=%0h tested=%0h failed=%0h scrubbed=%0h cycles=%0d ef=%0h nspur=%0d nmerr=%0d refused2=%0d res2=%0d cyc2=%0d logovf=%0d logs=%s mem=%s",
                id, last_result, prev_result, fail, done, aborted, stopped, error_st, fail_count, cnt_ovf,
                ff_valid, ff_info, ff_addr, ff_exp, ff_obs, b_tested, b_failed, b_scrubbed, cycles, ef,
                n_spur, n_merr, refused2, res2, cyc2, log_ovf, logs, mems);
      // leave ERROR state for the next case
      if (error_st) begin @(negedge clk); clear = 1; @(negedge clk); clear = 0; end
      end
    end
    $fclose(fd_res);
    if (fd_tr != 0) $fclose(fd_tr);
    $display("TB_MBIST_DONE");
    $finish;
  end
endmodule

`default_nettype wire
