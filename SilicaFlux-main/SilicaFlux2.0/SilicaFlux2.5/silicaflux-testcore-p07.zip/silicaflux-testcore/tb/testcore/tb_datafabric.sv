// =============================================================================
// SilicaFlux TestCore :: tb_datafabric          *** SIMULATION ONLY ***
// MBIST over the DataFabric SFB2 path: silicaflux_mbist -> sftc_sfb2_master_adapter
// -> DataFabric sfb_reg_slice (REQ+RSP slices) -> DataFabric sfb_sram_slave
// (real Project 03 RTL, vendored) -> SRAM Wrapper Library sram_sp (READ_LATENCY 2).
// Fault injected with the SRAM library's generic-backend hook.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_datafabric;
  import sftc_pkg::*;
  logic clk = 0, rst_n = 1;
  always #5 clk = ~clk;
  logic start = 0, abort = 0, clear = 0;
  logic [3:0] algo = 0;
  logic t_req, t_we, t_gnt, t_rvalid, t_rerr, busy, done, pass, fail, aborted, error_st, stopped, scrubbing, ev_done;
  logic [7:0] t_addr; logic [31:0] t_wdata, t_rdata; logic [0:0] t_bank;
  logic [3:0] state, run_algo; logic [0:0] cur_bank; logic [2:0] cur_elem, last_result, prev_result; logic [7:0] cur_addr;
  logic [0:0] tested, failed, scrubbed; logic [31:0] cycles;
  logic ev_ref, ev_tmo, ev_spur, ev_merr, ffv, cov, lov; logic [23:0] ffi, lgi; logic [7:0] ffa, lga;
  logic [31:0] ffe, ffo, lgs; logic [15:0] fcnt; logic [7:0] lvl;
  silicaflux_mbist #(.BANK_COUNT(1), .MAX_W(32), .MAX_DEPTH(256), .BANK_WIDTHS(8'd32), .BANK_DEPTHS(24'd256),
                     .BANK_FLAGS(8'd1), .LOG_DEPTH(2), .TIMEOUT(64)) u_mbist (
    .clk, .rst_n, .test_enable(1'b1), .start, .abort, .clear, .cfg_algo(algo), .cfg_bg_chk(1'b0), .cfg_sof(1'b0),
    .cfg_scrub(1'b1), .cfg_bank_mask(1'b1), .bank_owned(1'b1), .t_req, .t_we, .t_addr, .t_wdata, .t_bank,
    .t_gnt, .t_rvalid, .t_rdata, .t_rerr, .t_stray_rvalid(1'b0), .busy, .done, .pass, .fail, .aborted, .error_st,
    .stopped, .scrubbing, .state, .cur_bank, .cur_elem, .cur_addr, .run_algo, .last_result, .prev_result,
    .banks_tested(tested), .banks_failed(failed), .banks_scrubbed(scrubbed), .cycles, .ev_start_refused(ev_ref),
    .ev_timeout(ev_tmo), .ev_spurious(ev_spur), .ev_mem_err(ev_merr), .ev_done, .log_pop(1'b0), .ff_valid(ffv),
    .ff_info(ffi), .ff_addr(ffa), .ff_exp(ffe), .ff_obs(ffo), .fail_count(fcnt), .cnt_ovf(cov), .log_level(lvl),
    .log_ovf(lov), .log_info(lgi), .log_addr(lga), .log_synd(lgs));
  logic m_v, m_r, m_w, m_rv, m_rr, m_re, s_v, s_r, s_w, s_rv, s_rr, s_re;
  logic [31:0] m_a, m_d, m_q, s_a, s_d, s_q; logic [3:0] m_s, s_s;
  sftc_sfb2_master_adapter #(.DW(32), .AW(8), .BASE(32'h2000_0000)) u_ad (
    .t_req, .t_gnt, .t_we, .t_addr, .t_wdata, .t_rvalid, .t_rdata, .t_rerr, .req_valid(m_v), .req_ready(m_r),
    .req_write(m_w), .req_addr(m_a), .req_wdata(m_d), .req_wstrb(m_s), .rsp_valid(m_rv), .rsp_ready(m_rr),
    .rsp_rdata(m_q), .rsp_error(m_re));
  sfb_reg_slice #(.AW(32), .DW(32), .REQ_SLICE(1), .RSP_SLICE(1)) u_slice (
    .clk, .rst_n, .s_req_valid(m_v), .s_req_ready(m_r), .s_req_write(m_w), .s_req_addr(m_a), .s_req_wdata(m_d),
    .s_req_wstrb(m_s), .s_rsp_valid(m_rv), .s_rsp_ready(m_rr), .s_rsp_rdata(m_q), .s_rsp_error(m_re),
    .m_req_valid(s_v), .m_req_ready(s_r), .m_req_write(s_w), .m_req_addr(s_a), .m_req_wdata(s_d),
    .m_req_wstrb(s_s), .m_rsp_valid(s_rv), .m_rsp_ready(s_rr), .m_rsp_rdata(s_q), .m_rsp_error(s_re));
  logic [31:0] tq;
  sfb_sram_slave #(.DW(32), .DEPTH(256), .READ_LATENCY(2)) u_slv (
    .clk, .rst_n, .req_valid(s_v), .req_ready(s_r), .req_write(s_w), .req_addr(s_a), .req_wdata(s_d),
    .req_wstrb(s_s), .rsp_valid(s_rv), .rsp_ready(s_rr), .rsp_rdata(s_q), .rsp_error(s_re),
    .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr(8'd0), .tst_wdata(32'd0), .tst_rdata(tq));

  task automatic run(input logic [3:0] a, output int res);
    @(negedge clk); algo = a; clear = 1; @(negedge clk); clear = 0; start = 1; @(negedge clk); start = 0;
    while (!(done || error_st)) @(negedge clk);
    res = last_result;
  endtask
  initial begin
    int r;
    #1 rst_n = 0; #20 rst_n = 1; repeat (3) @(negedge clk);
    run(ALG_MARCH_C_MINUS, r);
    $display("TB_DF case=march_c_minus result=%0d cycles=%0d", r, cycles);
    u_slv.u_sram.u_array.g_generic.u_mem.flt_kind = 1;      // stuck-at-0
    u_slv.u_sram.u_array.g_generic.u_mem.flt_addr = 200;
    u_slv.u_sram.u_array.g_generic.u_mem.flt_bit  = 9;
    run(ALG_MATS_PLUS, r);
    $display("TB_DF case=sa0 result=%0d ffaddr=%0d ffexp=%h ffobs=%h", r, ffa, ffe, ffo);
    $display("TB_DF_DONE");
    $finish;
  end
endmodule
`default_nettype wire
