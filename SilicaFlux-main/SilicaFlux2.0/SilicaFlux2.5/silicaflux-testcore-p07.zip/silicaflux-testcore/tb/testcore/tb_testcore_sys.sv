// =============================================================================
// SilicaFlux TestCore :: tb_testcore_sys          *** SIMULATION ONLY ***
// System-level testbench (MCU-I-style SoC fragment):
//   sftc_testcore_top + 4 MBIST-ready banks built from the SRAM Wrapper Library
//     b0  sram_sp   32 x 512, READ_LATENCY 1   (main SRAM bank)
//     b1  sram_sp   32 x 512, READ_LATENCY 2   (2-cycle macro)
//     b2  sram_sp   36 x 256, READ_LATENCY 1   (byte parity column: raw 36-bit storage)
//     b3  sram_1r1w 16 x 128, READ_LATENCY 1   (one-read/one-write)
//   + one functional master with scoreboard per bank (tb_func_master)
// The testbench is driven by a host program over two named pipes (+cmd, +rsp),
// so the Python host library (python/testcore, SimTransport) runs against the
// real RTL.  Command protocol: python/testcore/transports/sim.py.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_testcore_sys;
  localparam int NB = 4, MAXW = 36, MAXD = 512, AW = 9;
  localparam logic [NB*8-1:0]  WIDTHS = {8'd16, 8'd36, 8'd32, 8'd32};
  localparam logic [NB*24-1:0] DEPTHS = {24'd128, 24'd256, 24'd512, 24'd512};

  logic clk = 0, tck = 0, tms = 1, tdi = 0, trst_n = 1, rst_n = 1;
  real  clk_half = 5.0, tck_half = 20.0;
  always #(clk_half) clk = ~clk;

  logic hw_dbg_en = 1, hw_test_en = 1, cpu_halted = 0, scan_mode_pin = 0, scan_en_pin = 0;
  logic s_req = 0, s_we = 0, s_gnt, s_err;
  logic [11:0] s_addr = 0;
  logic [31:0] s_wdata = 0, s_rdata;
  logic tdo, tdo_oe;
  logic [NB-1:0] b_req, b_gnt, b_rvalid, b_rerr, acq_req, scrub_done, owned, odirty, oev_fault, oev_intr, oev_reinit;
  logic b_we, mbist_busy, ofault_clr;
  logic [AW-1:0] b_addr;
  logic [MAXW-1:0] b_wdata;
  logic [NB*MAXW-1:0] b_rdata;
  logic [NB*3-1:0] ostate;
  logic [2:0] mode;
  logic scan_mode, scan_en, irq, tdone, tpass, tfail, jmode, dmode;

  sftc_testcore_top #(
    .BANK_COUNT(NB), .MAX_W(MAXW), .MAX_DEPTH(MAXD), .BANK_WIDTHS(WIDTHS), .BANK_DEPTHS(DEPTHS),
    .BANK_FLAGS('0), .LOG_DEPTH(4), .TIMEOUT(1024)
  ) dut (
    .tck, .trst_n, .tms, .tdi, .tdo, .tdo_oe, .clk, .rst_n, .hw_dbg_en, .hw_test_en, .cpu_halted,
    .scan_mode_pin, .scan_en_pin, .s_req, .s_we, .s_addr, .s_wdata, .s_gnt, .s_rdata, .s_err,
    .b_req, .b_we, .b_addr, .b_wdata, .b_gnt, .b_rvalid, .b_rdata, .b_rerr,
    .acq_req, .scrub_done, .mbist_busy, .owner_fault_clear(ofault_clr), .owner_state(ostate), .owned,
    .owner_dirty(odirty), .owner_ev_fault(oev_fault), .owner_ev_intrusion(oev_intr),
    .owner_ev_reinit(oev_reinit), .mode, .scan_mode, .scan_en, .irq, .test_done_o(tdone),
    .test_pass_o(tpass), .test_fail_o(tfail), .jtag_mode_o(jmode), .diag_mode_o(dmode)
  );

  // ------------------------------------------------------------------ banks + masters
  logic [NB-1:0] m_en = '0, m_rogue = '0, m_noack = '0, qreq, qack, reinit_zero, invalidate;
  int n_intr [NB];

  // bank-generic master signals (sp contract)
  logic [NB-1:0] f_valid, f_ready, f_we, f_rspv, f_rspr, f_rspwe, f_rsperr;
  logic [AW-1:0] f_addr [NB];
  logic [MAXW-1:0] f_wdata [NB], f_rdata [NB];
  logic [4:0] f_wmask [NB];

  genvar k;
  generate
    for (k = 0; k < 3; k++) begin : g_sp
      localparam int W = WIDTHS[k*8 +: 8];
      localparam int D = DEPTHS[k*24 +: 24];
      localparam int A = $clog2(D);
      localparam int MW = (W == 36) ? 4 : W / 8;
      logic [W-1:0] rd, trd;
      sftc_sramlib_sp_wrap #(.DATA_WIDTH(W), .DEPTH(D), .MASK_WIDTH(MW), .READ_LATENCY(k == 1 ? 2 : 1),
                             .WRITE_ACK(1), .OWN_TIMEOUT(512)) u_bank (
        .clk, .rst_n,
        .req_valid(f_valid[k]), .req_ready(f_ready[k]), .req_we(f_we[k]), .req_addr(f_addr[k][A-1:0]),
        .req_wdata(f_wdata[k][W-1:0]), .req_wmask(f_wmask[k][MW-1:0]), .req_id(1'b0),
        .rsp_valid(f_rspv[k]), .rsp_ready(f_rspr[k]), .rsp_rdata(rd), .rsp_err(f_rsperr[k]), .rsp_we(f_rspwe[k]),
        .rsp_id(),
        .t_req(b_req[k]), .t_gnt(b_gnt[k]), .t_we(b_we), .t_addr(b_addr[A-1:0]), .t_wdata(b_wdata[W-1:0]),
        .t_rvalid(b_rvalid[k]), .t_rdata(trd), .t_rerr(b_rerr[k]),
        .acq_req(acq_req[k]), .fault_clear(ofault_clr), .quiesce_ack(qack[k]), .quiesce_req(qreq[k]),
        .mbist_busy, .scrub_done(scrub_done[k]), .owned(owned[k]), .owner_state(ostate[k*3 +: 3]),
        .dirty(odirty[k]), .ev_fault(oev_fault[k]), .ev_intrusion(oev_intr[k]), .ev_reinit_req(oev_reinit[k]),
        .busy()
      );
      assign f_rdata[k] = MAXW'(rd);
      assign b_rdata[k*MAXW +: MAXW] = MAXW'(trd);
      tb_func_master #(.DW(W), .DEPTH(D), .MW(MW), .SEED(101 + k), .WRITE_RSP(1)) u_m (
        .clk, .rst_n, .enable(m_en[k]), .rogue(m_rogue[k]), .noack(m_noack[k]), .quiesce_req(qreq[k]),
        .quiesce_ack(qack[k]), .reinit_zero(reinit_zero[k]), .invalidate(invalidate[k]),
        .req_valid(f_valid[k]), .req_ready(f_ready[k]), .req_we(f_we[k]), .req_addr(f_addr[k][A-1:0]),
        .req_wdata(f_wdata[k][W-1:0]), .req_wmask(f_wmask[k][MW-1:0]), .rsp_valid(f_rspv[k]),
        .rsp_ready(f_rspr[k]), .rsp_rdata(rd), .rsp_we(f_rspwe[k]), .rsp_err(f_rsperr[k])
      );
    end
  endgenerate

  // 1R1W bank
  logic [15:0] r3, t3;
  logic w3_ready, r3_ready, wr3_err, rsp3_err;
  sftc_sramlib_1r1w_wrap #(.DATA_WIDTH(16), .DEPTH(128), .MASK_WIDTH(2), .READ_LATENCY(1), .OWN_TIMEOUT(512)) u_b3 (
    .clk, .rst_n,
    .wr_valid(f_valid[3] && f_we[3]), .wr_ready(w3_ready), .wr_addr(f_addr[3][6:0]), .wr_data(f_wdata[3][15:0]),
    .wr_mask(f_wmask[3][1:0]), .wr_err(wr3_err),
    .rd_valid(f_valid[3] && !f_we[3]), .rd_ready(r3_ready), .rd_addr(f_addr[3][6:0]), .rd_id(1'b0),
    .rsp_valid(f_rspv[3]), .rsp_ready(f_rspr[3]), .rsp_rdata(r3), .rsp_err(rsp3_err), .rsp_id(),
    .t_req(b_req[3]), .t_gnt(b_gnt[3]), .t_we(b_we), .t_addr(b_addr[6:0]), .t_wdata(b_wdata[15:0]),
    .t_rvalid(b_rvalid[3]), .t_rdata(t3), .t_rerr(b_rerr[3]),
    .acq_req(acq_req[3]), .fault_clear(ofault_clr), .quiesce_ack(qack[3]), .quiesce_req(qreq[3]),
    .mbist_busy, .scrub_done(scrub_done[3]), .owned(owned[3]), .owner_state(ostate[9 +: 3]),
    .dirty(odirty[3]), .ev_fault(oev_fault[3]), .ev_intrusion(oev_intr[3]), .ev_reinit_req(oev_reinit[3]), .busy()
  );
  assign f_ready[3] = f_we[3] ? w3_ready : r3_ready;
  assign f_rsperr[3] = rsp3_err;
  assign f_rspwe[3] = 1'b0;
  assign b_rdata[3*MAXW +: MAXW] = MAXW'(t3);
  tb_func_master #(.DW(16), .DEPTH(128), .MW(2), .SEED(104), .WRITE_RSP(0)) u_m3 (
    .clk, .rst_n, .enable(m_en[3]), .rogue(m_rogue[3]), .noack(m_noack[3]), .quiesce_req(qreq[3]),
    .quiesce_ack(qack[3]), .reinit_zero(reinit_zero[3]), .invalidate(invalidate[3]),
    .req_valid(f_valid[3]), .req_ready(f_ready[3]), .req_we(f_we[3]), .req_addr(f_addr[3][6:0]),
    .req_wdata(f_wdata[3][15:0]), .req_wmask(f_wmask[3][1:0]), .rsp_valid(f_rspv[3]), .rsp_ready(f_rspr[3]),
    .rsp_rdata(r3), .rsp_we(1'b0), .rsp_err(rsp3_err)
  );

  // shadow-memory knowledge from the ownership controllers
  // applied by the master at the edge that ends TEST_RELEASE (no functional
  // access can be accepted in that cycle): clean (scrubbed) bank = all zero,
  // dirty bank or TestCore reset = content undefined
  always @(posedge clk) for (int i = 0; i < NB; i++) if (oev_intr[i]) n_intr[i]++;
  generate
    for (k = 0; k < NB; k++) begin : g_know
      assign reinit_zero[k] = (ostate[k*3 +: 3] == 3'd6) && !odirty[k];
      assign invalidate[k]  = ((ostate[k*3 +: 3] == 3'd6) && odirty[k]) || !rst_n;
    end
  endgenerate

  // ------------------------------------------------------------------ command interface
  integer fc, fr;
  reg [8*16-1:0] cmd, name;
  int     n, a1, a2, a3, a4, a5, a6, val;
  logic [4095:0] tmsv, tdiv, tdov;
  int     n_assert = 0;

  task automatic jtag(input int nb);
    tdov = '0;
    for (int i = 0; i < nb; i++) begin
      tms = tmsv[i]; tdi = tdiv[i];
      #(tck_half);
      tdov[i] = tdo;
      tck = 1;
      #(tck_half);
      tck = 0;
    end
    #0.01;   // let the falling-edge (NBA) updates of TDO settle before any peek
  endtask

  task automatic sys_access(input bit w, input logic [11:0] a, input logic [31:0] d,
                            output logic [31:0] q, output bit e);
    @(negedge clk);
    s_req = 1; s_we = w; s_addr = a; s_wdata = d;
    @(posedge clk);
    while (!s_gnt) @(posedge clk);
    q = s_rdata; e = s_err;
    #1 s_req = 0;
  endtask

  function automatic int getv(input reg [8*16-1:0] nm, input int idx);
    case (nm)
      "test_pass": getv = tpass;
      "test_fail": getv = tfail;
      "test_done": getv = tdone;
      "irq":       getv = irq;
      "mode":      getv = mode;
      "tdo":       getv = tdo;
      "tdo_oe":    getv = tdo_oe;
      "scan_en":   getv = scan_en;
      "scan_mode": getv = scan_mode;
      "owner":     getv = ostate[idx*3 +: 3];
      "dirty":     getv = odirty[idx];
      "intrusions": getv = n_intr[idx];
      "mbist_busy": getv = mbist_busy;
      default:     getv = -1;
    endcase
  endfunction

  function automatic int master_stat(input int idx, input int which);
    case (idx)
      0: master_stat = (which == 0) ? g_sp[0].u_m.n_err : (which == 1) ? g_sp[0].u_m.n_rd : (which == 2) ? g_sp[0].u_m.n_wr : g_sp[0].u_m.n_blocked;
      1: master_stat = (which == 0) ? g_sp[1].u_m.n_err : (which == 1) ? g_sp[1].u_m.n_rd : (which == 2) ? g_sp[1].u_m.n_wr : g_sp[1].u_m.n_blocked;
      2: master_stat = (which == 0) ? g_sp[2].u_m.n_err : (which == 1) ? g_sp[2].u_m.n_rd : (which == 2) ? g_sp[2].u_m.n_wr : g_sp[2].u_m.n_blocked;
      default: master_stat = (which == 0) ? u_m3.n_err : (which == 1) ? u_m3.n_rd : (which == 2) ? u_m3.n_wr : u_m3.n_blocked;
    endcase
  endfunction

  task automatic set_fault(input int b, input int kind, input int addr, input int bit_, input int addr2, input int bit2);
    case (b)
      0: begin g_sp[0].u_bank.u_sram.u_array.g_generic.u_mem.flt_kind = kind; g_sp[0].u_bank.u_sram.u_array.g_generic.u_mem.flt_addr = addr;
               g_sp[0].u_bank.u_sram.u_array.g_generic.u_mem.flt_bit = bit_; g_sp[0].u_bank.u_sram.u_array.g_generic.u_mem.flt_addr2 = addr2;
               g_sp[0].u_bank.u_sram.u_array.g_generic.u_mem.flt_bit2 = bit2; end
      1: begin g_sp[1].u_bank.u_sram.u_array.g_generic.u_mem.flt_kind = kind; g_sp[1].u_bank.u_sram.u_array.g_generic.u_mem.flt_addr = addr;
               g_sp[1].u_bank.u_sram.u_array.g_generic.u_mem.flt_bit = bit_; g_sp[1].u_bank.u_sram.u_array.g_generic.u_mem.flt_addr2 = addr2;
               g_sp[1].u_bank.u_sram.u_array.g_generic.u_mem.flt_bit2 = bit2; end
      2: begin g_sp[2].u_bank.u_sram.u_array.g_generic.u_mem.flt_kind = kind; g_sp[2].u_bank.u_sram.u_array.g_generic.u_mem.flt_addr = addr;
               g_sp[2].u_bank.u_sram.u_array.g_generic.u_mem.flt_bit = bit_; g_sp[2].u_bank.u_sram.u_array.g_generic.u_mem.flt_addr2 = addr2;
               g_sp[2].u_bank.u_sram.u_array.g_generic.u_mem.flt_bit2 = bit2; end
      default: begin u_b3.u_sram.u_array.g_generic.u_mem.flt_kind = kind; u_b3.u_sram.u_array.g_generic.u_mem.flt_addr = addr;
               u_b3.u_sram.u_array.g_generic.u_mem.flt_bit = bit_; u_b3.u_sram.u_array.g_generic.u_mem.flt_addr2 = addr2;
               u_b3.u_sram.u_array.g_generic.u_mem.flt_bit2 = bit2; end
    endcase
  endtask

  initial begin
    string cf, rf;
    logic [31:0] q; bit e;
    for (int i = 0; i < NB; i++) n_intr[i] = 0;
    if (!$value$plusargs("cmd=%s", cf)) $fatal(1, "missing +cmd");
    if (!$value$plusargs("rsp=%s", rf)) $fatal(1, "missing +rsp");
    if ($value$plusargs("clk_half=%f", clk_half)) ;
    if ($value$plusargs("tck_half=%f", tck_half)) ;
    // power-on: both reset domains asserted with a real edge
    #1 trst_n = 0; rst_n = 0;
    #100 trst_n = 1;
    @(negedge clk); rst_n = 1;
    fr = $fopen(rf, "w");
    fc = $fopen(cf, "r");
    $fdisplay(fr, "READY"); $fflush(fr);
    forever begin
      n = $fscanf(fc, "%s", cmd);
      if (n != 1) begin $display("TB_SYS: command stream closed"); $finish; end
      case (cmd)
        "J": begin
          n = $fscanf(fc, "%d %h %h", a1, tmsv, tdiv);
          jtag(a1);
          $fdisplay(fr, "D %h", tdov[1023:0]); $fflush(fr);
        end
        "C": begin n = $fscanf(fc, "%d", a1); repeat (a1) @(posedge clk); $fdisplay(fr, "K"); $fflush(fr); end
        "SW": begin n = $fscanf(fc, "%h %h", a1, a2); sys_access(1, a1[11:0], a2, q, e);
                    $fdisplay(fr, "V %h %0d", q, e); $fflush(fr); end
        "SR": begin n = $fscanf(fc, "%h", a1); sys_access(0, a1[11:0], 32'd0, q, e);
                    $fdisplay(fr, "V %h %0d", q, e); $fflush(fr); end
        "P": begin
          n = $fscanf(fc, "%s %d %d", name, a1, a2);
          case (name)
            "hw_test_en": hw_test_en = a1[0];
            "hw_dbg_en":  hw_dbg_en = a1[0];
            "cpu_halted": cpu_halted = a1[0];
            "scan_mode":  scan_mode_pin = a1[0];
            "scan_en":    scan_en_pin = a1[0];
            "trst":       trst_n = !a1[0];
            "rst":        begin @(negedge clk); rst_n = !a1[0]; end
            "traffic":    m_en[a2] = a1[0];
            "rogue":      m_rogue[a2] = a1[0];
            "noack":      m_noack[a2] = a1[0];
            "clk_half":   clk_half = a1;
            "tck_half":   tck_half = a1;
            default: ;
          endcase
          $fdisplay(fr, "K"); $fflush(fr);
        end
        "G": begin n = $fscanf(fc, "%s %d", name, a1); #0.01; $fdisplay(fr, "V %0d", getv(name, a1)); $fflush(fr); end
        "M": begin n = $fscanf(fc, "%d", a1);
                   $fdisplay(fr, "V %0d %0d %0d %0d", master_stat(a1, 0), master_stat(a1, 1), master_stat(a1, 2),
                             master_stat(a1, 3)); $fflush(fr); end
        "F": begin n = $fscanf(fc, "%d %d %d %d %d %d", a1, a2, a3, a4, a5, a6); set_fault(a1, a2, a3, a4, a5, a6);
                   $fdisplay(fr, "K"); $fflush(fr); end
        "T": begin $fdisplay(fr, "V %0t", $time); $fflush(fr); end
        "Q": begin $fdisplay(fr, "BYE"); $fflush(fr); $finish; end
        default: begin $fdisplay(fr, "E unknown %s", cmd); $fflush(fr); end
      endcase
    end
  end
endmodule
`default_nettype wire
