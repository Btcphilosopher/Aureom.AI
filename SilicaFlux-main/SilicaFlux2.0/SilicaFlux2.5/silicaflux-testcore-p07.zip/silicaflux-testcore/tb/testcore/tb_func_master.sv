// =============================================================================
// SilicaFlux TestCore :: tb_func_master          *** SIMULATION ONLY ***
// Functional (CPU / DMA-like) master for one sram_sp-contract port with a
// data scoreboard.  Models a well-behaved master that honours quiesce_req
// (stops issuing, then acknowledges) unless `rogue` is set, in which case it
// keeps requesting (the wrapper must block it and report an intrusion).
//   * random reads / masked writes, request payload held until accepted
//   * random response back-pressure (rsp_ready)
//   * shadow memory with per-lane valid bits: reads are checked against the
//     value written by the last accepted write; unwritten lanes are not checked
//   * `reinit_zero` pulse: the bank was scrubbed by MBIST -> shadow := all zero
//   * `invalidate` pulse : content undefined (test without scrub) -> shadow invalid
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_func_master #(
  parameter int DW = 32,
  parameter int DEPTH = 512,
  parameter int MW = 4,
  parameter int SEED = 1,
  parameter int WRITE_RSP = 1,
  localparam int AW = $clog2(DEPTH),
  localparam int LW = DW / MW
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          enable,
  input  wire logic          rogue,      // acknowledges quiesce but keeps requesting
  input  wire logic          noack,      // never acknowledges quiesce
  input  wire logic          quiesce_req,
  output logic               quiesce_ack,
  input  wire logic          reinit_zero,
  input  wire logic          invalidate,
  output logic               req_valid,
  input  wire logic          req_ready,
  output logic               req_we,
  output logic [AW-1:0]      req_addr,
  output logic [DW-1:0]      req_wdata,
  output logic [MW-1:0]      req_wmask,
  input  wire logic          rsp_valid,
  output logic               rsp_ready,
  input  wire logic [DW-1:0] rsp_rdata,
  input  wire logic          rsp_we,
  input  wire logic          rsp_err
);
  logic [DW-1:0] shadow [DEPTH];
  logic [MW-1:0] svalid [DEPTH];
  // expected responses (in order)
  logic [DW-1:0] q_exp [64];
  logic [MW-1:0] q_msk [64];
  bit            q_rd  [64];
  int q_h = 0, q_t = 0, q_n = 0;
  int unsigned r;
  int n_rd = 0, n_wr = 0, n_err = 0, n_rsp = 0, n_blocked = 0;

  function automatic int unsigned rnd();
    r = r * 1103515245 + 12345;
    rnd = r >> 8;
  endfunction

  initial begin
    r = SEED;
    for (int i = 0; i < DEPTH; i++) begin shadow[i] = '0; svalid[i] = '0; end
    req_valid = 0; req_we = 0; req_addr = 0; req_wdata = 0; req_wmask = 0; rsp_ready = 1; quiesce_ack = 0;
  end

  wire stop_issue = quiesce_req && !rogue;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      req_valid <= 0; quiesce_ack <= 0; q_h = 0; q_t = 0; q_n = 0;
    end else begin
      // ---------------------------------------------------- scoreboard on accepted request
      if (req_valid && req_ready) begin
        if (req_we) begin
          n_wr++;
          for (int l = 0; l < MW; l++) if (req_wmask[l]) begin
            shadow[req_addr][l*LW +: LW] = req_wdata[l*LW +: LW];
            svalid[req_addr][l] = 1'b1;
          end
          q_rd[q_t] = 0;
          if (WRITE_RSP != 0) begin q_t = (q_t + 1) % 64; q_n++; end
        end else begin
          n_rd++;
          q_exp[q_t] = shadow[req_addr]; q_msk[q_t] = svalid[req_addr]; q_rd[q_t] = 1;
          q_t = (q_t + 1) % 64; q_n++;
        end
      end else if (req_valid && !req_ready) n_blocked++;
      // ---------------------------------------------------- response check
      if (rsp_valid && rsp_ready) begin
        n_rsp++;
        if (q_n == 0) begin
          n_err++; $display("TB_MASTER_ERROR %m unsolicited response t=%0t", $time);
        end else begin
          if (q_rd[q_h]) begin
            for (int l = 0; l < MW; l++)
              if (q_msk[q_h][l] && rsp_rdata[l*LW +: LW] !== q_exp[q_h][l*LW +: LW]) begin
                n_err++;
                $display("TB_MASTER_ERROR %m data lane %0d got %h exp %h t=%0t", l,
                         rsp_rdata[l*LW +: LW], q_exp[q_h][l*LW +: LW], $time);
              end
          end
          if (rsp_err) begin n_err++; $display("TB_MASTER_ERROR %m rsp_err t=%0t", $time); end
          q_h = (q_h + 1) % 64; q_n--;
        end
      end
      // ---------------------------------------------------- next request
      if (req_valid && !req_ready) begin
        // hold payload (valid/ready rule)
      end else if (enable && !stop_issue && (rnd() % 100) < 35) begin
        req_valid <= 1;
        req_we    <= rnd() % 2;
        req_addr  <= AW'(rnd() % DEPTH);
        req_wdata <= {(DW + 31) / 32{rnd()}};
        req_wmask <= MW'(rnd()) | MW'(1);
      end else begin
        req_valid <= 0;
      end
      rsp_ready   <= (rnd() % 100) < 70;
      quiesce_ack <= quiesce_req && !noack && !(req_valid && !req_ready);
      // ---------------------------------------------------- re-initialisation knowledge
      if (reinit_zero) for (int i = 0; i < DEPTH; i++) begin shadow[i] = '0; svalid[i] = '1; end
      if (invalidate)  for (int i = 0; i < DEPTH; i++) svalid[i] = '0;
    end
  end
endmodule
`default_nettype wire
