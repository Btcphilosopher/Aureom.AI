// =============================================================================
// SilicaFlux TestCore :: sftc_fault_mem          *** SIMULATION ONLY ***
// Behavioural memory with the TestCore test-port handshake, configurable
// variable latency / grant back-pressure / write responses, and a single
// injectable fault (single-fault assumption).  NOT synthesizable, never part
// of production RTL.  The fault semantics are defined in
// docs/testcore/fault_injection.md and implemented independently in
// python/testcore/fault_models.py (golden model); the regression requires the
// two to agree on detection AND on the first failing address/data.
//
// Fault kinds (f_kind):
//   0  none
//   1  SA0      cell (a,b) stuck at 0
//   2  SA1      cell (a,b) stuck at 1
//   3  TF_UP    cell (a,b) cannot make a 0->1 transition
//   4  TF_DOWN  cell (a,b) cannot make a 1->0 transition
//   5  AF_ALIAS address a accesses cell row a2 instead of its own (a never reached)
//   6  AF_MULTI access to a also accesses a2: writes go to both, read = mem[a] & mem[a2]
//   7  RD_INV   read of (a) returns bit b inverted (read-path / sense fault)
//   8  CF_IN    inversion coupling: aggressor (a,b) transition in direction val
//               (1 = up, 0 = down) inverts victim (a2,b2)
//   9  CF_ID    idempotent coupling: aggressor (a,b) transition in direction
//               val[1] forces victim (a2,b2) to val[0]
//  10  CF_ST    state coupling: while aggressor (a,b) == val[1], victim (a2,b2)
//               is forced to val[0]
//  11  INTERMIT intermittent read error: every param-th read of a flips bit b
//  12  XLAT     every response delayed by +param cycles (LEGAL: must PASS)
//  13  NO_RSP   the response to the first read of a is never returned
//  14  NO_GNT   grant permanently withdrawn after param accepted requests
//  15  DUP_RSP  the response of accepted transaction number param is duplicated
//  16  AF_NONE  address a selects no cell: writes lost, read returns 0
//  17  DLINE    read data bit b stuck at val[0] for every address (column/sense amp)
//  18  RERR     read of a returns rsp_err = 1 (e.g. uncorrectable ECC indication)
// =============================================================================
`default_nettype none

module sftc_fault_mem #(
  parameter int W          = 32,
  parameter int DEPTH      = 256,
  parameter int AW         = 8,
  parameter int LAT_MIN    = 1,
  parameter int LAT_MAX    = 1,
  parameter int GNT_PCT    = 100,
  parameter int WRITE_RESP = 0
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          req,
  input  wire logic          we,
  input  wire logic [AW-1:0] addr,
  input  wire logic [W-1:0]  wdata,
  output logic               gnt,
  output logic               rvalid,
  output logic [W-1:0]       rdata,
  output logic               rerr
);
  logic [W-1:0] mem [DEPTH];

  // ---- fault configuration (written by the testbench through configure())
  int f_kind, f_addr, f_bit, f_addr2, f_bit2, f_val, f_param;
  int unsigned rnd;
  int acc_cnt, rd_cnt_a, cyc;
  bit no_rsp_done, dup_done;

  // ---- response queue
  localparam int QD = 64;
  int    q_due  [QD];
  logic [W-1:0] q_data [QD];
  bit    q_err  [QD];
  int    q_h, q_t, q_n, last_due;
  bit    gnt_r;

  function automatic int unsigned prng();
    rnd = rnd * 32'd1103515245 + 32'd12345;
    prng = (rnd >> 8) & 32'h00FF_FFFF;
  endfunction

  task automatic configure(input int kind, input int a, input int b, input int a2, input int b2,
                           input int v, input int p, input int unsigned seed);
    f_kind = kind; f_addr = a; f_bit = b; f_addr2 = a2; f_bit2 = b2; f_val = v; f_param = p;
    rnd = seed ^ 32'h5EED_0001;
    acc_cnt = 0; rd_cnt_a = 0; no_rsp_done = 0; dup_done = 0;
    q_h = 0; q_t = 0; q_n = 0; last_due = -1;
    // power-up content is undefined: fill with deterministic pseudo-random data
    for (int i = 0; i < DEPTH; i++)
      for (int k = 0; k < W; k++) mem[i][k] = prng() & 1;
    apply_static();
  endtask

  // state-type faults are re-applied after every array update
  task automatic apply_static();
    if (f_kind == 1) mem[f_addr][f_bit] = 1'b0;
    if (f_kind == 2) mem[f_addr][f_bit] = 1'b1;
    if (f_kind == 10 && mem[f_addr][f_bit] == f_val[1]) mem[f_addr2][f_bit2] = f_val[0];
  endtask

  // write one physical row with transition / coupling semantics
  task automatic write_row(input int row, input logic [W-1:0] d);
    logic [W-1:0] old, nw;
    old = mem[row]; nw = d;
    if (row == f_addr) begin
      if (f_kind == 3 && old[f_bit] == 1'b0 && nw[f_bit] == 1'b1) nw[f_bit] = 1'b0;
      if (f_kind == 4 && old[f_bit] == 1'b1 && nw[f_bit] == 1'b0) nw[f_bit] = 1'b1;
    end
    mem[row] = nw;
    if (row == f_addr && (f_kind == 8 || f_kind == 9)) begin
      // aggressor transition?
      if (old[f_bit] != nw[f_bit]) begin
        if ((f_kind == 8 && nw[f_bit] == f_val[0]) ) mem[f_addr2][f_bit2] = ~mem[f_addr2][f_bit2];
        if ((f_kind == 9 && nw[f_bit] == f_val[1]) ) mem[f_addr2][f_bit2] = f_val[0];
      end
    end
    apply_static();
  endtask

  function automatic logic [W-1:0] read_row(input int a);
    logic [W-1:0] d;
    if (f_kind == 16 && a == f_addr)      d = '0;
    else if (f_kind == 5 && a == f_addr)  d = mem[f_addr2];
    else if (f_kind == 6 && a == f_addr)  d = mem[a] & mem[f_addr2];
    else                                  d = mem[a];
    if (f_kind == 7 && a == f_addr) d[f_bit] = ~d[f_bit];
    if (f_kind == 17)               d[f_bit] = f_val[0];
    read_row = d;
  endfunction

  task automatic do_write(input int a, input logic [W-1:0] d);
    if (f_kind == 16 && a == f_addr) begin
      // write lost
    end else if (f_kind == 5 && a == f_addr) begin
      write_row(f_addr2, d);
    end else begin
      write_row(a, d);
      if (f_kind == 6 && a == f_addr) write_row(f_addr2, d);
    end
  endtask

  task automatic push(input int due, input logic [W-1:0] d, input bit e);
    if (q_n >= QD) $fatal(1, "sftc_fault_mem: response queue overflow");
    q_due[q_t] = due; q_data[q_t] = d; q_err[q_t] = e;
    q_t = (q_t + 1) % QD; q_n++;
    last_due = due;
  endtask

  initial begin
    f_kind = 0; rnd = 1; cyc = 0; q_h = 0; q_t = 0; q_n = 0; last_due = -1; gnt_r = 1;
  end

  assign gnt = gnt_r;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rvalid <= 1'b0; rerr <= 1'b0; rdata <= '0;
      q_h = 0; q_t = 0; q_n = 0; last_due = -1; gnt_r <= 1'b0;
    end else begin
      int lat, due;
      logic [W-1:0] d;
      bit e, drop;
      cyc++;
      // ------------------------------------------------ acceptance (sampled request)
      if (req && gnt_r) begin
        acc_cnt++;
        lat = LAT_MIN + ((LAT_MAX > LAT_MIN) ? (prng() % (LAT_MAX - LAT_MIN + 1)) : 0);
        if (f_kind == 12) lat = lat + f_param;
        due = cyc + lat - 1;
        if (due <= last_due) due = last_due + 1;
        e = 1'b0; drop = 1'b0;
        if (we) begin
          do_write(int'(addr), wdata);
          d = '0;
        end else begin
          d = read_row(int'(addr));
          if (int'(addr) == f_addr) begin
            rd_cnt_a++;
            if (f_kind == 11 && f_param > 0 && (rd_cnt_a % f_param) == 0) d[f_bit] = ~d[f_bit];
            if (f_kind == 18) e = 1'b1;
            if (f_kind == 13 && !no_rsp_done) begin drop = 1'b1; no_rsp_done = 1; end
          end
        end
        if ((!we || WRITE_RESP != 0) && !drop) begin
          push(due, d, e);
          if (f_kind == 15 && acc_cnt == f_param && !dup_done) begin push(due + 1, d, e); dup_done = 1; end
        end
      end
      // ------------------------------------------------ response output for the next cycle
      if (q_n > 0 && q_due[q_h] <= cyc) begin
        rvalid <= 1'b1; rdata <= q_data[q_h]; rerr <= q_err[q_h];
        q_h = (q_h + 1) % QD; q_n--;
      end else begin
        rvalid <= 1'b0; rerr <= 1'b0;
        rdata  <= {(W+31)/32{prng()}};          // garbage when not valid
      end
      // ------------------------------------------------ grant for the next cycle
      if (f_kind == 14 && acc_cnt >= f_param) gnt_r <= 1'b0;
      else gnt_r <= (GNT_PCT >= 100) ? 1'b1 : ((prng() % 100) < GNT_PCT);
    end
  end
endmodule

`default_nettype wire
