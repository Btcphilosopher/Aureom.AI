// =============================================================================
// SilicaFlux TestCore :: tb_jtag_tap
// Self-checking testbench: sftc_jtag_tap + sftc_jtag_reg_bridge + a system-
// domain register-slave model with random wait states.
//   T1  TRST / power-up: Test-Logic-Reset, IDCODE selected, IDCODE value
//   T2  random TMS walk vs an independent table-driven TAP reference model;
//       coverage of all 16 states and all 32 (state, TMS) arcs
//   T3  5 x TMS=1 reaches Test-Logic-Reset from every state
//   T4  Capture-IR value (LSBs 01)
//   T5  BYPASS: 1-bit delay, captures 0
//   T6  every one of the 32 opcodes: measured DR length matches the spec
//       (IDCODE 32, TC_REG 46, TC_STATUS 8, everything else BYPASS = 1)
//   T7  TC_REG write/read through the CDC at several asynchronous clock ratios;
//       each launched request executed exactly once (no loss / duplication)
//   T8  system clock stopped: BUSY + sticky, requests ignored and counted as not
//       executed; clock restarted + CLEAR -> recovery; TC_STATUS alive bit
//   T9  TDO high-impedance (tdo_oe=0) outside Shift states
// Prints "TB_JTAG_RESULT PASS|FAIL checks=<n> errors=<m>" and coverage lines.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_jtag_tap;
  import sftc_pkg::*;

  logic tck = 0, tms = 1, tdi = 0, trst_n = 1;
  logic clk = 0, rst_n = 1;
  logic tdo, tdo_oe;
  real  clk_half = 5.0;
  bit   clk_run = 1;
  always begin
    #(clk_half);
    if (clk_run) clk = ~clk;
  end

  logic [3:0] tap_state;
  logic [IR_LEN-1:0] ir;
  logic sel_reg, sel_status, tdo_reg, tdo_status;
  logic m_req, m_we, m_gnt, m_err, launch_tck, exec_sys;
  logic [11:0] m_addr;
  logic [31:0] m_wdata, m_rdata;

  sftc_jtag_tap u_tap (
    .tck, .trst_n, .tms, .tdi, .tdo, .tdo_oe, .state_o(tap_state), .ir_o(ir),
    .sel_reg, .sel_status, .tdo_reg_i(tdo_reg), .tdo_status_i(tdo_status)
  );
  sftc_jtag_reg_bridge u_br (
    .tck, .trst_n, .tap_state, .sel_reg, .sel_status, .tdi, .tdo_reg, .tdo_status,
    .clk, .rst_n, .m_req, .m_we, .m_addr, .m_wdata, .m_gnt, .m_rdata, .m_err, .launch_tck, .exec_sys
  );

  // ---------------------------------------------------------------- register slave model
  logic [31:0] regs [1024];
  int   n_exec = 0, n_launch = 0;
  int unsigned lfsr = 32'hACE1_2345;
  logic stall;
  always @(posedge clk) begin
    lfsr = {lfsr[30:0], lfsr[31] ^ lfsr[21] ^ lfsr[1] ^ lfsr[0]};
    stall <= lfsr[3] & lfsr[7];            // ~25 % wait states
  end
  assign m_gnt   = m_req && !stall;
  assign m_err   = m_req && (m_addr >= 12'h800);
  assign m_rdata = (m_req && !m_we) ? regs[m_addr[11:2]] : 32'hDEAD_BEEF;
  always @(posedge clk) begin
    if (rst_n && m_req && m_gnt) begin
      n_exec++;
      if (m_we && m_addr < 12'h800) regs[m_addr[11:2]] <= m_wdata;
    end
  end
  always @(posedge tck) if (launch_tck) n_launch++;

  // ---------------------------------------------------------------- reference TAP model (table)
  int ref_tab [32];
  initial begin
    // index = state*2 + tms ; IEEE 1149.1 state diagram written as a table
    // state:      TLR   RTI   SDR   CDR   SHDR  E1DR  PDR   E2DR  UDR   SIR   CIR   SHIR  E1IR  PIR   E2IR  UIR
    ref_tab[0] = 1;
    ref_tab[1] = 0;
    ref_tab[2] = 1;
    ref_tab[3] = 2;
    ref_tab[4] = 3;
    ref_tab[5] = 9;
    ref_tab[6] = 4;
    ref_tab[7] = 5;
    ref_tab[8] = 4;
    ref_tab[9] = 5;
    ref_tab[10] = 6;
    ref_tab[11] = 8;
    ref_tab[12] = 6;
    ref_tab[13] = 7;
    ref_tab[14] = 4;
    ref_tab[15] = 8;
    ref_tab[16] = 1;
    ref_tab[17] = 2;
    ref_tab[18] = 10;
    ref_tab[19] = 0;
    ref_tab[20] = 11;
    ref_tab[21] = 12;
    ref_tab[22] = 11;
    ref_tab[23] = 12;
    ref_tab[24] = 13;
    ref_tab[25] = 15;
    ref_tab[26] = 13;
    ref_tab[27] = 14;
    ref_tab[28] = 11;
    ref_tab[29] = 15;
    ref_tab[30] = 1;
    ref_tab[31] = 2;

  end
  int ref_st;
  int checks = 0, errors = 0;
  bit visited [16];
  bit arc [32];

  task automatic chk(input bit cond, input string what);
    checks++;
    if (!cond) begin errors++; $display("CHECK FAILED: %s (t=%0t)", what, $time); end
  endtask

  real tck_half = 50.0;
  // one TCK cycle: drive tms/tdi while TCK low, rising edge, sample tdo on the rising edge
  task automatic clk_tck(input bit t, input bit d, output bit o);
    tms = t; tdi = d;
    #(tck_half);
    o = tdo;
    tck = 1;
    // reference model advances on the rising edge
    arc[ref_st * 2 + t] = 1;
    ref_st = ref_tab[ref_st * 2 + t];
    #(tck_half);
    tck = 0;
    #0.01;
    visited[ref_st] = 1;
    chk(int'(tap_state) == ref_st, $sformatf("TAP state %0d != reference %0d", tap_state, ref_st));
  endtask

  task automatic go_tlr();
    bit o;
    repeat (5) clk_tck(1, 0, o);
    chk(tap_state == TAP_TLR, "5 x TMS=1 did not reach TLR");
  endtask

  task automatic to_rti();
    bit o;
    clk_tck(0, 0, o);
  endtask

  // from RTI: shift IR and return to RTI
  task automatic shift_ir(input logic [IR_LEN-1:0] v, output logic [IR_LEN-1:0] cap);
    bit o;
    clk_tck(1, 0, o); clk_tck(1, 0, o); clk_tck(0, 0, o); clk_tck(0, 0, o);  // SelDR SelIR CapIR ShIR
    for (int i = 0; i < IR_LEN; i++) begin
      clk_tck(i == IR_LEN - 1, v[i], o);
      cap[i] = o;
    end
    clk_tck(1, 0, o); clk_tck(0, 0, o);   // UpdIR, RTI
  endtask

  // from RTI: shift n DR bits (LSB first) and return to RTI
  task automatic shift_dr(input int n, input logic [63:0] v, output logic [63:0] cap);
    bit o;
    cap = '0;
    clk_tck(1, 0, o); clk_tck(0, 0, o); clk_tck(0, 0, o);           // SelDR CapDR ShDR
    for (int i = 0; i < n; i++) begin
      clk_tck(i == n - 1, v[i], o);
      cap[i] = o;
    end
    clk_tck(1, 0, o); clk_tck(0, 0, o);   // UpdDR, RTI
  endtask

  task automatic idle(input int n);
    bit o;
    repeat (n) clk_tck(0, 0, o);
  endtask

  // DR length measurement: shift 0s to flush, then a single 1, count to its arrival
  task automatic dr_len(output int len);
    bit o;
    clk_tck(1, 0, o); clk_tck(0, 0, o); clk_tck(0, 0, o);           // SelDR CapDR ShDR
    for (int i = 0; i < 80; i++) clk_tck(0, 0, o);
    clk_tck(0, 1, o);
    len = -1;
    for (int i = 1; i <= 80 && len < 0; i++) begin
      clk_tck(0, 0, o);
      if (o) len = i;
    end
    clk_tck(1, 0, o); clk_tck(1, 0, o); clk_tck(0, 0, o);           // Exit1 Upd RTI
  endtask

  // TC_REG transaction helpers (46-bit DR)
  task automatic reg_scan(input logic [1:0] op, input logic [11:0] a, input logic [31:0] d,
                          output logic [1:0] st, output logic [11:0] ra, output logic [31:0] rd);
    logic [63:0] cap;
    shift_dr(REG_DR_LEN, {18'd0, op, a, d}, cap);
    st = cap[45:44]; ra = cap[43:32]; rd = cap[31:0];
  endtask

  task automatic reg_write(input logic [11:0] a, input logic [31:0] d, input int idle_n,
                           output logic [1:0] st);
    logic [11:0] ra; logic [31:0] rd;
    reg_scan(REGOP_WRITE, a, d, st, ra, rd);
    idle(idle_n);
  endtask

  task automatic reg_read(input logic [11:0] a, input int idle_n, output logic [1:0] st,
                          output logic [31:0] rd);
    logic [11:0] ra; logic [1:0] s0;
    reg_scan(REGOP_READ, a, 32'd0, s0, ra, rd);
    idle(idle_n);
    reg_scan(REGOP_NOP, 12'd0, 32'd0, st, ra, rd);   // result of the read
    idle(idle_n);
  endtask

  initial begin
    logic [IR_LEN-1:0] cap;
    logic [63:0] dcap;
    logic [1:0] st;
    logic [31:0] rd;
    int len, nl0, ne0, cov_states, cov_arcs, exp_len_g, idle_n;
    bit o;
    real ratios_c [4];
    real ratios_t [4];
    ref_st = 0;
    ratios_c[0] = 5.0;  ratios_c[1] = 18.5; ratios_c[2] = 2.3;  ratios_c[3] = 41.0;   // clk half periods (ns)
    ratios_t[0] = 50.0; ratios_t[1] = 7.0;  ratios_t[2] = 61.0; ratios_t[3] = 13.0;   // tck half periods (ns)
    for (int i = 0; i < 1024; i++) regs[i] = 32'h1000_0000 + i;

    // ---- T1 reset
    #1 trst_n = 0; rst_n = 0;
    #99 trst_n = 1; rst_n = 1;
    chk(tap_state == TAP_TLR && ir == IR_IDCODE, "reset state / IDCODE instruction");
    to_rti();
    shift_dr(32, 64'h0, dcap);
    chk(dcap[31:0] == IDCODE_VALUE, $sformatf("IDCODE %h", dcap[31:0]));

    // ---- T9 tdo_oe outside shift
    chk(!tdo_oe, "TDO driven outside Shift state");

    // ---- T2 random TMS walk
    begin
      int unsigned r;
      r = 32'h1357_9BDF;
      for (int i = 0; i < 20000; i++) begin
        r = r * 1103515245 + 12345;
        clk_tck(r[16], r[20], o);
        if (!(tap_state == TAP_SH_DR || tap_state == TAP_SH_IR)) begin
          // tdo_oe updates on the falling edge after the state change
        end
      end
    end
    // ---- T3 5xTMS=1 from every state
    for (int s = 0; s < 16; s++) begin
      // navigate to state s using a BFS path in the reference table
      go_tlr();
      begin
        int path [16]; int plen; int q [64]; int prev [16]; int pt [16]; int h, t, cur, nx;
        for (int k = 0; k < 16; k++) prev[k] = -1;
        h = 0; t = 0; q[t++] = 0; prev[0] = 0;
        while (h < t) begin
          cur = q[h++];
          for (int b = 0; b < 2; b++) begin
            nx = ref_tab[cur * 2 + b];
            if (prev[nx] < 0) begin prev[nx] = cur; pt[nx] = b; q[t++] = nx; end
          end
        end
        plen = 0; cur = s;
        while (cur != 0) begin path[plen++] = pt[cur]; cur = prev[cur]; end
        for (int k = plen - 1; k >= 0; k--) clk_tck(path[k], 0, o);
        chk(int'(tap_state) == s, $sformatf("navigate to state %0d", s));
        go_tlr();
      end
    end
    to_rti();

    // ---- T4 Capture-IR
    shift_ir(IR_BYPASS, cap);
    chk(cap == IR_CAPTURE, $sformatf("Capture-IR %b", cap));
    // ---- T5 BYPASS
    shift_dr(16, 64'hA5C3, dcap);
    chk(dcap[0] == 1'b0 && dcap[15:1] == 15'(16'hA5C3), $sformatf("BYPASS delay %h", dcap[15:0]));

    // ---- T6 all opcodes: DR length
    for (int op = 0; op < 32; op++) begin
      shift_ir(IR_LEN'(op), cap);
      chk(ir == IR_LEN'(op), $sformatf("IR update %0d", op));
      len = (op == IR_IDCODE) ? 32 : (op == IR_TC_REG) ? REG_DR_LEN : (op == IR_TC_STATUS) ? 8 : 1;
      exp_len_g = len;
      dr_len(len);
      chk(len == exp_len_g, $sformatf("opcode %02h DR length %0d expected %0d", op, len, exp_len_g));
    end

    // ---- T7 register access at several clock ratios
    shift_ir(IR_TC_REG, cap);
    for (int ph = 0; ph < 4; ph++) begin
      clk_half = ratios_c[ph]; tck_half = ratios_t[ph];
      // idle requirement: >= ~ 4 system clocks + 2 TCK of synchroniser latency, plus wait states
      idle_n = int'((clk_half * 2.0 * 24.0) / (tck_half * 2.0)) + 4;
      nl0 = n_launch; ne0 = n_exec;
      for (int k = 0; k < 24; k++) begin
        logic [11:0] a; logic [31:0] d;
        a = 12'((k * 52 + ph * 4) & 12'h7FC);
        d = 32'h5A00_0000 ^ (ph << 20) ^ (k * 32'h01010101);
        reg_write(a, d, idle_n, st);
        reg_read(a, idle_n, st, rd);
        chk(st == REGST_OK && rd == d, $sformatf("ratio %0d: read-back %h of %h at %h st=%0d", ph, rd, d, a, st));
      end
      // unmapped -> ERR
      reg_read(12'h900, idle_n, st, rd);
      chk(st == REGST_ERR, "unmapped register returns ERROR status");
      chk((n_launch - nl0) == (n_exec - ne0), $sformatf("ratio %0d: launched %0d executed %0d", ph,
          n_launch - nl0, n_exec - ne0));
    end

    // ---- T8 system clock stopped
    clk_half = 5.0; tck_half = 50.0;
    idle(10);
    clk_run = 0;
    nl0 = n_launch; ne0 = n_exec;
    begin
      logic [11:0] ra;
      reg_scan(REGOP_WRITE, 12'h010, 32'h1111_2222, st, ra, rd);   // launched, cannot execute
      idle(4);
      reg_scan(REGOP_WRITE, 12'h014, 32'h3333_4444, st, ra, rd);   // capture sees BUSY -> sticky
      chk(st == REGST_BUSY, "BUSY reported while system clock stopped");
      idle(4);
      reg_scan(REGOP_READ, 12'h010, 32'h0, st, ra, rd);
      chk(st == REGST_BUSY, "sticky BUSY persists");
      chk(n_launch - nl0 == 1, $sformatf("only the first request launched (%0d)", n_launch - nl0));
      // status DR: alive = 0
      shift_ir(IR_TC_STATUS, cap);
      shift_dr(8, 0, dcap);
      shift_dr(8, 0, dcap);
      chk(dcap[2] == 1'b0 && dcap[1] == 1'b1 && dcap[7:4] == 4'h7, $sformatf("TC_STATUS stopped %b", dcap[7:0]));
      // restart clock: pending request executes exactly once
      clk_run = 1;
      idle(20);
      chk(n_exec - ne0 == 1, $sformatf("pending request executed once after clock restart (%0d)", n_exec - ne0));
      shift_dr(8, 0, dcap);
      idle(20);
      shift_dr(8, 0, dcap);
      chk(dcap[2] == 1'b1, $sformatf("TC_STATUS alive after restart %b", dcap[7:0]));
      shift_ir(IR_TC_REG, cap);
      reg_scan(REGOP_CLEAR, 12'h0, 32'h0, st, ra, rd);
      idle(10);
      reg_read(12'h010, 10, st, rd);
      chk(st == REGST_OK && rd == 32'h1111_2222, $sformatf("after CLEAR: %h st=%0d", rd, st));
      chk(regs[12'h014 >> 2] != 32'h3333_4444, "request issued while sticky was not executed");
    end

    // ---- T10 system reset while a request is in flight -> next capture ERROR, then recovery
    begin
      logic [11:0] ra;
      clk_half = 40.0; tck_half = 5.0;        // slow system clock: request still in flight
      reg_scan(REGOP_WRITE, 12'h020, 32'h7777_8888, st, ra, rd);
      #3 rst_n = 0; #200 rst_n = 1;           // system reset hits the in-flight request
      idle(400);
      reg_scan(REGOP_NOP, 12'h0, 32'h0, st, ra, rd);
      chk(st == REGST_ERR || st == REGST_BUSY, $sformatf("request caught by system reset reported %0d (must not be OK)", st));
      if (st == REGST_BUSY) begin reg_scan(REGOP_CLEAR, 12'h0, 32'h0, st, ra, rd); idle(400); end
      clk_half = 5.0; tck_half = 50.0;
      idle(10);
      reg_write(12'h024, 32'h0BAD_F00D, 20, st);
      reg_read(12'h024, 20, st, rd);
      chk(st == REGST_OK && rd == 32'h0BAD_F00D, $sformatf("recovery after system reset: %h st=%0d", rd, st));
    end

    // ---- T1b TRST in the middle of a DR shift
    clk_tck(1, 0, o); clk_tck(0, 0, o); clk_tck(0, 0, o);
    trst_n = 0; #20; trst_n = 1; ref_st = 0;
    chk(tap_state == TAP_TLR && ir == IR_IDCODE, "TRST during shift");

    cov_states = 0; cov_arcs = 0;
    for (int k = 0; k < 16; k++) cov_states += visited[k];
    for (int k = 0; k < 32; k++) cov_arcs += arc[k];
    chk(cov_states == 16 && cov_arcs == 32, "state / arc coverage complete");
    $display("TB_JTAG_COVERAGE states=%0d/16 arcs=%0d/32 launches=%0d executions=%0d",
             cov_states, cov_arcs, n_launch, n_exec);
    $display("TB_JTAG_RESULT %s checks=%0d errors=%0d", errors == 0 ? "PASS" : "FAIL", checks, errors);
    $finish;
  end
endmodule

`default_nettype wire
