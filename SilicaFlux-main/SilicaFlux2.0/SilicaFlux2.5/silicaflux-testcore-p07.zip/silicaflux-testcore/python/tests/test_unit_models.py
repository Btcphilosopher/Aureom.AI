"""Unit tests: spec parsing, golden MBIST model, fault models, records, patterns, CLI."""
import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

from testcore import spec
from testcore.fault_models import Fault, FaultKind, FaultyMemory
from testcore.mbist import ALG_IDS, BankCfg, GoldenMbist, MARCH_TABLE, cycle_formula, element_ops, nominal_ops
from testcore.patterns import mbist_production_pattern
from testcore.report import Evidence, Status, StepRecord, TestRecord

ROOT = Path(__file__).resolve().parents[2]


def test_spec_single_source():
    assert spec.IDCODE == 0x15F07001 and spec.IDCODE & 1
    assert spec.IR_LEN == 5 and spec.IR["IDCODE"] == 2 and spec.IR["BYPASS"] == 0x1F
    addrs = list(spec.REGS.values())
    assert len(addrs) == len(set(addrs)), "duplicate register addresses"
    assert all(a % 4 == 0 for a in addrs)
    pkg = (ROOT / "rtl/testcore/sftc_pkg.sv").read_text()
    assert '`include "sftc_consts.svh"' in pkg      # package is only a wrapper


def addr_sequence(alg, n, w=8):
    seq = []
    for ei, e in enumerate(MARCH_TABLE[alg]):
        for ops in element_ops(alg, ei, e, 0, n, w, False):
            seq.append((ei, ops[0].addr))
    return seq


@pytest.mark.parametrize("n", [1, 2, 5, 16, 37, 256])
def test_march_c_minus_every_address_once_per_element(n):
    seq = addr_sequence(0, n)
    for ei in range(6):
        addrs = [a for e, a in seq if e == ei]
        assert sorted(addrs) == list(range(n))
        if MARCH_TABLE[0][ei][0] == "down":
            assert addrs == list(range(n - 1, -1, -1))
        else:
            assert addrs == list(range(n))


@pytest.mark.parametrize("alg,ops", [(0, 10), (1, 5), (2, 2), (3, 2)])
def test_nominal_operation_counts(alg, ops):
    assert nominal_ops(alg, 100, 32) == ops * 100


def test_walk_ops():
    assert nominal_ops(4, 10, 8) == 17 * 10


@pytest.mark.parametrize("kind", [FaultKind.SA0, FaultKind.SA1, FaultKind.TF_UP, FaultKind.TF_DOWN])
def test_march_c_minus_detects_every_cell_fault(kind):
    w, d = 4, 8
    for a in range(d):
        for b in range(w):
            mem = FaultyMemory(w, d, Fault(kind, a, b), seed=a * w + b)
            r = GoldenMbist([BankCfg(w, d)]).run([mem], 0, 1)
            assert r.fail and r.first["addr"] == a, (kind, a, b)


def test_mats_plus_misses_some_coupling():
    # documents a known limitation: MATS+ does not detect every inversion coupling fault
    misses = 0
    for v in (0, 1):
        for a in range(8):
            for a2 in range(8):
                if a2 == a:
                    continue
                mem = FaultyMemory(1, 8, Fault(FaultKind.CF_IN, a, 0, a2, 0, v), seed=1)
                if not GoldenMbist([BankCfg(1, 8)]).run([mem], 1, 1).fail:
                    misses += 1
    assert misses > 0


def test_cycle_formula_march_sfv_bank():
    # SilicaFlux-V main bank 8192 x 32, latency 1, scrub on, 4-bank configuration
    c = cycle_formula(0, 8192, 32, 1, True, False, 4)
    assert c == 5 * 8192 * 2 + 5 * 8192 + 8192 + 7 + 1 + 5 + 1


def test_record_rules():
    r = TestRecord(evidence_class=Evidence.SIMULATION, design_version="x",
                   steps=[StepRecord(name="mbist", status=Status.PASS)]).finalize()
    assert r.status == Status.PASS and r.bin.startswith("NO-BIN")          # simulation is never binned
    assert r.wafer_id is None and r.temperature_c is None and r.voltage_v is None
    s = TestRecord(evidence_class=Evidence.PACKAGED_SILICON, design_version="x",
                   steps=[StepRecord(name="mbist_x", status=Status.FAIL)]).finalize()
    assert s.bin.startswith("BIN5")
    b = TestRecord(evidence_class=Evidence.PACKAGED_SILICON, design_version="x",
                   steps=[StepRecord(name="x", status=Status.BLOCKED)]).finalize()
    assert b.status == Status.BLOCKED
    assert {x.value for x in Status} == {"PASS", "FAIL", "NOT RUN", "BLOCKED", "INVALID", "INCONCLUSIVE"}


def test_svf_structure():
    p = mbist_production_pattern(0xF, "march_c_minus", 5000)
    svf = p.to_svf()
    assert "SIR 5 TDI (02);" in svf and "SDR 32 TDI (00000000) TDO (15F07001) MASK (FFFFFFFF);" in svf
    assert "RUNTEST 5000 TCK;" in svf
    for ln in svf.splitlines():
        if ln.startswith(("SIR", "SDR")):
            assert re.match(r"^S[ID]R \d+ TDI \([0-9A-F]+\)( TDO \([0-9A-F]+\) MASK \([0-9A-F]+\))?;$", ln), ln


def test_cli_without_hardware_reports_not_available(tmp_path):
    r = subprocess.run([sys.executable, "-m", "testcore", "scan", "--transport", "hw", "--port", "1",
                        "--run-dir", str(tmp_path)], capture_output=True, text=True, cwd=ROOT / "python")
    assert r.returncode == 3
    assert "HARDWARE NOT AVAILABLE" in r.stdout
    rec = json.loads((tmp_path / "test_record.json").read_text())
    assert rec["status"] == "BLOCKED" and "PASS" not in json.dumps(rec["steps"])
