"""System tests against the real RTL (tb_testcore_sys: TestCore + 4 SRAM-library banks
+ functional masters), driven through the host library and the simulation transport."""
import itertools

import pytest

from testcore import spec
from testcore.host import TestCoreHost
from testcore.transports.sim import SimTransport

pytestmark = pytest.mark.sim
R = spec.REGS


@pytest.fixture(scope="module")
def sim():
    t = SimTransport()
    yield t
    t.close()


@pytest.fixture
def host(sim):
    h = TestCoreHost(sim)
    for k in range(4):
        sim.set_pin("traffic", 0, k); sim.set_pin("rogue", 0, k); sim.set_pin("noack", 0, k)
    sim.set_pin("hw_test_en", 1); sim.set_pin("hw_dbg_en", 1); sim.set_pin("cpu_halted", 0)
    sim.set_pin("scan_mode", 0); sim.set_pin("scan_en", 0)
    h.request_mode("NORMAL")
    h.reg_write(R["R_TEST_CONTROL"], 1 << 2)       # CLEAR (also clears owner FAULT)
    h.clear_error_flags()
    for k in range(4):
        sim.inject_fault(k, 0, 0, 0)
    sim._err_base = [sim.master_stats(k)["errors"] for k in range(4)]   # per-test scoreboard baseline
    return h


def masters_clean(sim):
    return all(sim.master_stats(k)["errors"] == sim._err_base[k] for k in range(4))


def test_identification(host, sim):
    info = host.identify()
    assert info["idcode_ok"] and info["revision"] == "2.0.1" and info["bank_count"] == 4
    assert [b["width"] for b in info["banks"]] == [32, 32, 36, 16]
    assert host.bypass_check()
    st = host.tc_status()
    assert st["signature"] == 7 and st["sysclk_alive"] and not st["bridge_busy"]


@pytest.mark.parametrize("alg", list(spec.ALGS))
def test_all_algorithms_pass_under_traffic(host, sim, alg):
    for k in range(4):
        sim.set_pin("traffic", 1, k)
    sim.cycles(500)
    r = host.mbist_run([0, 1, 2, 3], alg)
    assert r.result == "PASS" and r.banks_tested == [0, 1, 2, 3] and r.fail_count == 0
    assert r.owner_states_after == ["NORMAL"] * 4 and not r.error_flags
    sim.cycles(1500)                         # functional traffic resumes on re-initialised memory
    assert masters_clean(sim)


@pytest.mark.parametrize("bank,kind,addr,bit", [(0, 1, 511, 31), (1, 2, 0, 0), (2, 1, 100, 35), (3, 2, 127, 15),
                                                 (0, 3, 17, 5), (1, 4, 300, 30)])
def test_fault_detection_reports_location(host, sim, bank, kind, addr, bit):
    sim.inject_fault(bank, kind, addr, bit)
    r = host.mbist_run([bank], "march_c_minus")
    assert r.result == "FAIL" and r.banks_failed == [bank]
    assert r.first_fail.address == addr and r.first_fail.syndrome == 1 << bit
    # remove the defect and re-initialise the bank (the faulty cell kept a wrong value through the scrub)
    sim.inject_fault(bank, 0, 0, 0)
    assert host.mbist_run([bank], "mats_plus").result == "PASS"


def policy(frm, to, dbg, test, unl):
    legal = {"NORMAL": {0, 1, 2, 5}, "JTAG_ACCESS": {0, 1, 2, 5}, "MBIST": {0, 1, 2}, "DIAGNOSTIC": {0, 1, 5}}[frm]
    if to not in legal:
        return frm, "ILLEGAL"
    name = spec.MODE_NAMES[to]
    if name == frm or name == "NORMAL" or (frm == "MBIST" and name == "MBIST"):
        return name, None
    if name in ("JTAG_ACCESS", "DIAGNOSTIC"):
        return (name, None) if dbg else (frm, "DENIED")
    return (name, None) if (test and unl) else (frm, "DENIED")


def enter(host, sim, mode):
    sim.set_pin("hw_dbg_en", 1); sim.set_pin("hw_test_en", 1)
    host.reg_write(R["R_BANK_MASK"], 0)
    host.request_mode("NORMAL")
    if mode == "MBIST":
        host.unlock()
    if mode != "NORMAL":
        host.request_mode(mode)
    assert host.mode_status()["mode"] == mode


def test_mode_transition_policy_exhaustive(host, sim):
    """Every (current mode, requested code, hw_dbg_en, hw_test_en, unlocked) combination via the
    system-bus register port; compared with the documented policy table."""
    bad = []
    for frm in ("NORMAL", "JTAG_ACCESS", "MBIST", "DIAGNOSTIC"):
        for to, dbg, test, unl in itertools.product(range(8), (0, 1), (0, 1), (0, 1)):
            enter(host, sim, frm)
            host.unlock(spec.UNLOCK_KEY if unl else 0)
            host.clear_error_flags()
            sim.set_pin("hw_dbg_en", dbg); sim.set_pin("hw_test_en", test)
            sim.cycles(4)
            # permission loss itself forces an exit; the expected state accounts for it
            cur = frm
            if (frm == "MBIST" and not (test and unl)) or (frm in ("JTAG_ACCESS", "DIAGNOSTIC") and not dbg):
                cur = "NORMAL"
            assert sim.sys_write(R["R_MODE_CTRL"], to)
            sim.cycles(40)
            got = spec.MODE_NAMES[sim.sys_read(R["R_MODE_STATUS"])[0] & 7]
            exp, flag = policy(cur, to, dbg, test, unl)
            flags = sim.sys_read(R["R_ERROR_FLAGS"])[0]
            if got != exp or (flag and not flags >> spec.c("EF_ILLEGAL_MODE") & 1):
                bad.append((frm, cur, to, dbg, test, unl, got, exp, flag))
    sim.set_pin("hw_dbg_en", 1); sim.set_pin("hw_test_en", 1)
    assert not bad, bad[:10]


def test_mbist_refused_without_hardware_permission(host, sim):
    sim.set_pin("hw_test_en", 0)
    r = host.mbist_run([0], "mats_plus")
    assert r.result == "NOT_RUN" and "ILLEGAL_MODE" in r.error_flags
    sim.set_pin("hw_test_en", 1)


def test_rogue_master_blocked_and_reported(host, sim):
    sim.set_pin("traffic", 1, 0); sim.set_pin("rogue", 1, 0)
    r = host.mbist_run([0], "mats_plus")
    assert r.result == "PASS" and "INTRUSION" in r.error_flags
    sim.set_pin("rogue", 0, 0)
    sim.cycles(1000)
    assert masters_clean(sim)


def test_master_never_acknowledges_quiesce(host, sim):
    sim.set_pin("traffic", 1, 1); sim.set_pin("noack", 1, 1)
    r = host.mbist_run([1], "mats_plus")
    assert r.result == "NOT_RUN" and "OWNER_FAULT" in r.error_flags
    assert "FAULT" == r.owner_states_after[1]
    sim.set_pin("noack", 0, 1)
    host.reg_write(R["R_TEST_CONTROL"], 1 << 2)           # CLEAR -> owner FAULT cleared
    sim.cycles(10)
    assert host.owner_states(4)[1] == "NORMAL"
    sim.cycles(500)
    assert masters_clean(sim)


def test_protected_bank_needs_halted_cpu(host, sim):
    host.reg_write(spec.c("R_PROTECT"), 1 << 2)
    r = host.mbist_run([2], "mats_plus")
    assert r.result == "NOT_RUN"
    sim.set_pin("cpu_halted", 1)
    r = host.mbist_run([2], "mats_plus")
    assert r.result == "PASS"
    sim.set_pin("cpu_halted", 0)


def test_boot_time_test_over_system_bus(host, sim):
    """The CPU / boot-ROM path: same registers through the system-bus port (no JTAG)."""
    w = sim.sys_write
    rd = lambda a: sim.sys_read(a)[0]
    w(R["R_BANK_MASK"], 0b1001); w(R["R_UNLOCK"], spec.UNLOCK_KEY); w(R["R_MODE_CTRL"], spec.MODES["MBIST"])
    for _ in range(200):
        o = rd(R["R_OWNER_STATUS"])
        if (o & 7) == 4 and (o >> 12 & 7) == 4:
            break
        sim.cycles(10)
    w(R["R_TEST_CONTROL"], 1 | (spec.ALGS["march_c_minus"] << 4) | (1 << 10))
    for _ in range(400):                       # poll DONE (busy may not be visible on the first read)
        if rd(R["R_TEST_STATUS"]) >> 1 & 1:
            break
        sim.cycles(500)
    assert rd(R["R_LAST_RESULT"]) & 7 == spec.c("RES_PASS")
    assert sim.get("test_pass") == 1 and sim.get("test_done") == 1     # wafer-probe status pins
    w(R["R_MODE_CTRL"], spec.MODES["NORMAL"])


def test_abort_scrubs_and_releases(host, sim):
    host.reg_write(R["R_BANK_MASK"], 1); host.unlock(); host.request_mode("MBIST")
    sim.cycles(50)
    host.reg_write(R["R_TEST_CONTROL"], 1 | (spec.ALGS["walk_one"] << 4) | (1 << 10))
    sim.cycles(300)
    host.reg_write(R["R_TEST_CONTROL"], 1 << 1)                       # ABORT
    for _ in range(400):
        if host.reg_read(R["R_TEST_STATUS"]) >> 1 & 1:
            break
        sim.cycles(200)
    assert host.reg_read(R["R_LAST_RESULT"]) & 7 == spec.c("RES_ABORTED")
    host.request_mode("NORMAL")
    sim.cycles(20)
    assert host.owner_states(4)[0] == "NORMAL"
    assert "REINIT_REQ" not in host.error_flags()                       # aborted bank was scrubbed


def test_permission_loss_hard_stop_flags_reinit(host, sim):
    host.reg_write(R["R_BANK_MASK"], 2); host.unlock(); host.request_mode("MBIST")
    sim.cycles(50)
    host.reg_write(R["R_TEST_CONTROL"], 1 | (spec.ALGS["march_c_minus"] << 4) | (1 << 10))
    sim.cycles(400)
    sim.set_pin("hw_test_en", 0)                                       # lifecycle / strap withdrawn
    sim.cycles(200)
    assert host.mode_status()["mode"] == "NORMAL"
    assert host.reg_read(R["R_LAST_RESULT"]) & 7 == spec.c("RES_ABORTED")
    assert "REINIT_REQ" in host.error_flags()                          # no further writes, content undefined
    sim.set_pin("hw_test_en", 1)


def test_scan_pins_override_and_block_register_modes(host, sim):
    sim.set_pin("scan_mode", 1); sim.set_pin("scan_en", 1)
    assert sim.get("mode") == spec.MODES["SCAN_SHIFT"] and sim.get("scan_en") == 1
    sim.set_pin("scan_en", 0)
    assert sim.get("mode") == spec.MODES["SCAN_CAPTURE"] and sim.get("scan_en") == 0
    sim.sys_write(R["R_MODE_CTRL"], spec.MODES["MBIST"])
    sim.cycles(10)
    assert sim.sys_read(R["R_ERROR_FLAGS"])[0] >> spec.c("EF_ILLEGAL_MODE") & 1
    sim.set_pin("scan_mode", 0)
    sim.set_pin("hw_test_en", 0); sim.set_pin("scan_mode", 1)          # scan needs hw_test_en too
    assert sim.get("scan_mode") == 0
    sim.set_pin("scan_mode", 0); sim.set_pin("hw_test_en", 1)
    sim.set_pin("rst", 1); sim.cycles(5); sim.set_pin("rst", 0); sim.cycles(5)   # leaving scan requires reset


def test_repeated_runs_identical(host, sim):
    a = host.mbist_run([3], "march_c_minus")
    b = host.mbist_run([3], "march_c_minus")
    assert a.result == b.result == "PASS" and a.cycles == b.cycles


def test_reset_during_test_is_safe(host, sim):
    host.reg_write(R["R_BANK_MASK"], 1); host.unlock(); host.request_mode("MBIST")
    sim.cycles(50)
    host.reg_write(R["R_TEST_CONTROL"], 1 | (spec.ALGS["march_c_minus"] << 4) | (1 << 10))
    sim.cycles(1000)
    sim.set_pin("rst", 1); sim.cycles(5); sim.set_pin("rst", 0); sim.cycles(10)
    assert host.mode_status()["mode"] == "NORMAL"
    assert host.owner_states(4) == ["NORMAL"] * 4
    assert host.reg_read(R["R_LAST_RESULT"]) & 7 == spec.c("RES_NOT_RUN")
    r = host.mbist_run([0], "march_c_minus")
    assert r.result == "PASS"
