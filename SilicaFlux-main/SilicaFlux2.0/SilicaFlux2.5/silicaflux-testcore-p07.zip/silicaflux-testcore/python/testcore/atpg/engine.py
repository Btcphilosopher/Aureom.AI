"""Experimental combinational stuck-at ATPG under a full-scan assumption.

THIS IS A RESEARCH EXPERIMENT, NOT A PRODUCTION ATPG TOOL.

Model
  * netlist: Yosys sky130hd gate netlist (pre-scan), cell functions parsed
    from the liberty (combinational `function`, flip-flop `next_state`);
  * full scan: every flip-flop output is a pseudo-primary input (PPI), every
    flip-flop of the CAPTURE clock domain is observed through its next state
    (pseudo-primary output, PPO);
  * capture domain = one clock (default `clk`, posedge); flops of other
    domains hold their scanned-in value and are not observed in that capture;
  * SRAM macro proxy flops are treated as a BLACK BOX: their outputs are X
    sources, their inputs are not observable (no RAM-sequential model, no
    bypass), which is the conservative case for the logic around memories;
  * scan-mode constraints are applied to primary inputs (scan_mode_pin=1,
    hw_test_en=1, scan_rst_n_pin=1, trst_n=1, rst_n=1, scan_en_pin=0);
  * fault model: single stuck-at-0/1 on every net stem (no fanout-branch
    faults, no clock-net faults);
  * detection is judged by 3-valued (0/1/X) bit-parallel fault simulation:
    a fault is detected only if good and faulty values are both known and
    differ at an observation point.

Test generation: random patterns (bit-parallel), then per-fault SAT (z3)
top-off on the fault's cone; every SAT pattern is re-validated by the
3-valued fault simulator before it is credited.  UNSAT => untestable under
the model and constraints; solver timeout or X-dependent detection =>
aborted.
"""
from __future__ import annotations

import random
import re
import time
from dataclasses import dataclass, field
from pathlib import Path

# =============================================================================== liberty
TOK = re.compile(r"\s*([A-Za-z_][A-Za-z0-9_]*|[!&|^()']|[01])")


def parse_expr(s: str):
    """Liberty boolean expression -> AST (tuple)."""
    toks = [t for t in TOK.findall(s)]
    pos = [0]

    def peek():
        return toks[pos[0]] if pos[0] < len(toks) else None

    def take():
        t = toks[pos[0]]; pos[0] += 1; return t

    def prim():
        t = take()
        if t == "!":
            return ("not", prim())
        if t == "(":
            e = orx()
            take()
            node = e
        elif t in ("0", "1"):
            node = ("const", int(t))
        else:
            node = ("var", t)
        while peek() == "'":
            take(); node = ("not", node)
        return node

    def andx():
        n = prim()
        while peek() is not None and (peek() == "&" or peek() == "!" or peek() == "(" or
                                      (peek() not in ("|", "^", ")") and re.match(r"[A-Za-z_01]", peek()))):
            if peek() == "&":
                take()
            n = ("and", n, prim())
        return n

    def xorx():
        n = andx()
        while peek() == "^":
            take(); n = ("xor", n, andx())
        return n

    def orx():
        n = xorx()
        while peek() == "|":
            take(); n = ("or", n, xorx())
        return n
    return orx()


@dataclass
class Cell:
    name: str
    inputs: list = field(default_factory=list)
    outputs: dict = field(default_factory=dict)   # pin -> AST (combinational)
    ff: dict | None = None                        # {"q": pin, "qn": pin, "next": AST, "clk": pin, "neg": bool, "clear":..}


def load_liberty(path: Path, wanted: set[str]) -> dict[str, Cell]:
    txt = path.read_text()
    cells = {}
    for m in re.finditer(r'cell \("(sky130_fd_sc_hd__\w+)"\) \{', txt):
        name = m.group(1)
        if name not in wanted:
            continue
        # cell body: up to the next top-level cell
        start = m.end()
        nxt = txt.find('\n    cell ("', start)
        body = txt[start: nxt if nxt > 0 else len(txt)]
        c = Cell(name)
        ffm = re.search(r'\n        ff \("(\w+)","(\w+)"\) \{(.*?)\n        \}', body, re.S)
        if ffm:
            fb = ffm.group(3)
            g = lambda k: (re.search(k + r'\s*:\s*"([^"]+)"', fb) or [None, None])[1]
            c.ff = {"iq": ffm.group(1), "iqn": ffm.group(2), "next": parse_expr(g("next_state")),
                    "clk": g("clocked_on")}
        for pm in re.finditer(r'\n        pin \("(\w+)"\) \{(.*?)\n        \}', body, re.S):
            pn, pb = pm.group(1), pm.group(2)
            d = re.search(r'direction\s*:\s*"(\w+)"', pb).group(1)
            if d == "input":
                c.inputs.append(pn)
            elif d == "output":
                f = re.search(r'function\s*:\s*"([^"]+)"', pb)
                c.outputs[pn] = parse_expr(f.group(1)) if f else None
        cells[name] = c
    return cells


# =============================================================================== netlist
@dataclass
class Inst:
    name: str
    cell: str
    pins: dict


def load_netlist(path: Path):
    txt = path.read_text()
    top = re.search(r"^module (\S+)\(", txt, re.M).group(1)
    ins = re.findall(r"^\s*input\s+(?:\[(\d+):(\d+)\]\s*)?(\S+?);", txt, re.M)
    outs = re.findall(r"^\s*output\s+(?:\[(\d+):(\d+)\]\s*)?(\S+?);", txt, re.M)

    def expand(lst):
        r = []
        for hi, lo, n in lst:
            if hi:
                r += [f"{n}[{i}]" for i in range(int(lo), int(hi) + 1)]
            else:
                r.append(n)
        return r
    insts = []
    for m in re.finditer(r"^\s*(sky130_fd_sc_hd__\w+)\s+(\S+)\s*\((.*?)\);", txt, re.M | re.S):
        pins = {k: v.strip() for k, v in re.findall(r"\.(\w+)\(([^()]*)\)", m.group(3))}
        insts.append(Inst(m.group(2), m.group(1), pins))
    assigns = [(a.strip(), b.strip()) for a, b in re.findall(r"^\s*assign\s+(.+?)\s*=\s*(.+?);", txt, re.M)]
    return top, expand(ins), expand(outs), insts, assigns


# =============================================================================== 3-valued bit-parallel ops
def t_not(a, M):
    v, k = a
    return (~v & k & M, k)


def t_and(a, b, M):
    va, ka = a; vb, kb = b
    k = (ka & kb) | (ka & ~va & M) | (kb & ~vb & M)
    return (va & vb & ka & kb, k)


def t_or(a, b, M):
    va, ka = a; vb, kb = b
    k = (ka & kb) | (ka & va) | (kb & vb)
    return ((va & ka) | (vb & kb), k)


def t_xor(a, b, M):
    va, ka = a; vb, kb = b
    k = ka & kb
    return ((va ^ vb) & k, k)


def compile_ast(ast):
    """AST -> python function f(env, M) on (v, k) tuples."""
    op = ast[0]
    if op == "var":
        n = ast[1]
        return lambda env, M: env[n]
    if op == "const":
        c = ast[1]
        return lambda env, M: ((M if c else 0), M)
    if op == "not":
        f = compile_ast(ast[1])
        return lambda env, M: t_not(f(env, M), M)
    fa, fb = compile_ast(ast[1]), compile_ast(ast[2])
    g = {"and": t_and, "or": t_or, "xor": t_xor}[op]
    return lambda env, M: g(fa(env, M), fb(env, M), M)


def ast_vars(ast, acc=None):
    acc = set() if acc is None else acc
    if ast[0] == "var":
        acc.add(ast[1])
    elif ast[0] in ("not",):
        ast_vars(ast[1], acc)
    elif ast[0] in ("and", "or", "xor"):
        ast_vars(ast[1], acc); ast_vars(ast[2], acc)
    return acc


# =============================================================================== circuit model
CONSTRAINTS = {"scan_mode_pin": 1, "hw_test_en": 1, "scan_rst_n_pin": 1, "trst_n": 1, "rst_n": 1,
               "scan_en_pin": 0}
CLOCKS = {"clk", "tck"}


class Model:
    def __init__(self, netlist: Path, liberty: Path, capture_clock: str = "clk",
                 blackbox_re: str = r"u_ram\.p_"):
        top, ins, outs, insts, assigns = load_netlist(netlist)
        self.top = top
        used = {i.cell for i in insts}
        self.lib = load_liberty(liberty, used)
        # alias map from assigns (net = net or constant)
        alias = {}
        for a, b in assigns:
            alias[a] = b
        self.alias = alias

        def canon(n):
            seen = 0
            while n in alias and seen < 50:
                n = alias[n]; seen += 1
            return n
        self.canon = canon
        self.const = {}
        self.gates = []          # (out_net, fn, in_nets)
        self.flops = []          # dict(name, q, qn, next_fn, ins, clk, domain, bb)
        self.drv = {}
        bb = re.compile(blackbox_re)
        for i in insts:
            c = self.lib[i.cell]
            pins = {p: canon(n) for p, n in i.pins.items()}
            if c.ff:
                clkpin = c.ff["clk"].lstrip("!")
                neg = c.ff["clk"].startswith("!")
                clknet = pins.get(clkpin)
                qpin = [p for p, f in c.outputs.items() if f is not None and f[0] == "var" and f[1] == c.ff["iq"]]
                qnpin = [p for p, f in c.outputs.items() if f is not None and f[0] == "var" and f[1] == c.ff["iqn"]]
                q = pins.get(qpin[0]) if qpin else None
                qn = pins.get(qnpin[0]) if qnpin else None
                nets_in = {p: pins[p] for p in c.inputs if p in pins and p != clkpin}
                fl = {"name": i.name, "cell": i.cell, "q": q, "qn": qn, "next": compile_ast(c.ff["next"]),
                      "next_vars": ast_vars(c.ff["next"]), "pins": nets_in, "iq": c.ff["iq"], "clk": clknet,
                      "neg": neg, "bb": bool(q and bb.search(q))}
                fl["domain"] = (clknet if clknet in CLOCKS else "derived:" + str(clknet)) + ("/neg" if neg else "")
                self.flops.append(fl)
                for n in (q, qn):
                    if n:
                        self.drv[n] = ("ff", fl)
            else:
                for p, f in c.outputs.items():
                    if p not in pins or f is None:
                        continue
                    vs = ast_vars(f)
                    self.gates.append((pins[p], compile_ast(f), {v: pins.get(v) for v in vs}, i.name, i.cell, p))
                    self.drv[pins[p]] = ("gate", len(self.gates) - 1)
        self.pis = [n for n in ins if n not in CLOCKS]
        self.pos = [canon(n) for n in outs]
        for n in self.pis:
            self.drv.setdefault(n, ("pi", n))
        # constants appearing as nets
        for g in self.gates:
            for v in g[2].values():
                if v is not None and re.match(r"^1'h[01]$", v):
                    self.const[v] = int(v[-1])
        self.capture = capture_clock
        self._levelize()

    def _levelize(self):
        # topological order of gates
        fanin_gate = []
        for idx, g in enumerate(self.gates):
            deps = []
            for n in g[2].values():
                d = self.drv.get(n)
                if d and d[0] == "gate":
                    deps.append(d[1])
            fanin_gate.append(deps)
        order, state = [], [0] * len(self.gates)
        import sys
        sys.setrecursionlimit(100000)
        for s in range(len(self.gates)):
            stack = [(s, 0)]
            while stack:
                u, i = stack.pop()
                if state[u] == 2:
                    continue
                if i == 0:
                    if state[u] == 1:
                        continue
                    state[u] = 1
                deps = fanin_gate[u]
                if i < len(deps):
                    stack.append((u, i + 1))
                    v = deps[i]
                    if state[v] == 0:
                        stack.append((v, 0))
                else:
                    state[u] = 2
                    order.append(u)
        self.order = order
        self.pos_of = {g: k for k, g in enumerate(order)}
        # fanout: net -> gates reading it ; net -> flops reading it
        self.fo_g, self.fo_f = {}, {}
        for idx, g in enumerate(self.gates):
            for n in g[2].values():
                self.fo_g.setdefault(n, []).append(idx)
        for fl in self.flops:
            for n in fl["pins"].values():
                self.fo_f.setdefault(n, []).append(fl)
        # observation points: PPO = capture-domain non-blackbox flops; PO
        self.obs_flops = [f for f in self.flops if f["domain"] == self.capture and not f["bb"]]
        self.ppis = [f for f in self.flops if not f["bb"]]
        self.xsrc = [f for f in self.flops if f["bb"]]

    # --------------------------------------------------------------- simulation
    def inputs_block(self, rng: random.Random, W: int, fixed=None) -> dict:
        M = (1 << W) - 1
        env = {}
        for n in self.pis:
            if n in CONSTRAINTS:
                env[n] = (M if CONSTRAINTS[n] else 0, M)
            elif fixed and n in fixed:
                env[n] = fixed[n]
            else:
                env[n] = (rng.getrandbits(W), M)
        for f in self.ppis:
            v = fixed[f["q"]] if fixed and f["q"] in fixed else (rng.getrandbits(W), M)
            if f["q"]:
                env[f["q"]] = v
            if f["qn"]:
                env[f["qn"]] = (~v[0] & M, M)
        for f in self.xsrc:
            for n in (f["q"], f["qn"]):
                if n:
                    env[n] = (0, 0)
        for c, val in self.const.items():
            env[c] = (M if val else 0, M)
        env[None] = (0, 0)
        return env

    def eval_good(self, env: dict, M: int) -> dict:
        val = dict(env)
        for gi in self.order:
            out, fn, ins, *_ = self.gates[gi]
            e = {p: val.get(n, (0, 0)) for p, n in ins.items()}
            val[out] = fn(e, M)
        return val

    def observe(self, val: dict, M: int) -> list:
        res = []
        for f in self.obs_flops:
            e = {p: val.get(n, (0, 0)) for p, n in f["pins"].items()}
            e[f["iq"]] = val.get(f["q"], (0, 0)) if f["q"] else (0, 0)
            res.append(f["next"](e, M))
        for n in self.pos:
            res.append(val.get(n, (0, 0)))
        return res

    def fault_sim(self, good: dict, gobs: list, M: int, net: str, sv: int) -> int:
        """Returns the bit mask of patterns that detect net stuck-at-sv."""
        val = {net: ((M if sv else 0), M)}
        if good.get(net) == val[net]:
            return 0
        # propagate in topological order over the fanout cone
        import heapq
        heap, inq = [], set()
        for gi in self.fo_g.get(net, []):
            heapq.heappush(heap, self.pos_of[gi]); inq.add(gi)
        touched_ff = set(id(f) for f in self.fo_f.get(net, []))
        while heap:
            gi = self.order[heapq.heappop(heap)]
            out, fn, ins, *_ = self.gates[gi]
            e = {p: val.get(n, good.get(n, (0, 0))) for p, n in ins.items()}
            nv = fn(e, M)
            if nv != good.get(out):
                if val.get(out) != nv:
                    val[out] = nv
                for gj in self.fo_g.get(out, []):
                    if gj not in inq:
                        inq.add(gj); heapq.heappush(heap, self.pos_of[gj])
                for f in self.fo_f.get(out, []):
                    touched_ff.add(id(f))
            elif out in val:
                del val[out]
        det = 0
        for k, f in enumerate(self.obs_flops):
            if id(f) not in touched_ff and f["q"] != net:
                continue
            e = {p: val.get(n, good.get(n, (0, 0))) for p, n in f["pins"].items()}
            e[f["iq"]] = val.get(f["q"], good.get(f["q"], (0, 0)))
            fv = f["next"](e, M)
            gv = gobs[k]
            det |= gv[1] & fv[1] & (gv[0] ^ fv[0])
        base = len(self.obs_flops)
        for j, n in enumerate(self.pos):
            if n in val:
                fv, gv = val[n], gobs[base + j]
                det |= gv[1] & fv[1] & (gv[0] ^ fv[0])
        return det

    def fault_list(self) -> list:
        nets = set()
        for g in self.gates:
            nets.add(g[0])
        for f in self.ppis:
            for n in (f["q"], f["qn"]):
                if n:
                    nets.add(n)
        for n in self.pis:
            nets.add(n)
        nets.discard(None)
        return sorted((n, sv) for n in nets for sv in (0, 1))
