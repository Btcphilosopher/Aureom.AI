"""ATPG experiment driver.

    python3 -m testcore.atpg.run_atpg [--netlist ...] [--scan-netlist ...] [--sat-seconds 300]

1. builds the full-scan model of the pre-scan netlist (variant E),
2. random-pattern fault simulation (3-valued, bit-parallel) until saturation,
3. SAT (z3) top-off on the remaining faults, each pattern re-validated,
4. classifies every fault: DETECTED (random / SAT), UNTESTABLE (UNSAT under
   model + constraints), ABORTED (timeout / X-dependent / not attempted),
5. validates a sample of the generated patterns on the OpenROAD scan-inserted
   gate netlist (Icarus, liberty-derived cell models): shift in, capture on
   clk, shift out, compare against the model's expected responses.
Writes reports/testcore/atpg/{summary.json,faults.csv,patterns_sample.json}.
"""
from __future__ import annotations

import argparse
import csv
import json
import random
import re
import subprocess
import sys
import time
from pathlib import Path

from .engine import CONSTRAINTS, Model

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "reports" / "testcore" / "atpg"


def sat_pattern(m: Model, net: str, sv: int, timeout_ms: int):
    import z3
    # faulty cone
    cone, frontier = set(), [net]
    while frontier:
        n = frontier.pop()
        for gi in m.fo_g.get(n, []):
            if gi not in cone:
                cone.add(gi); frontier.append(m.gates[gi][0])
    cone_nets = {m.gates[gi][0] for gi in cone} | {net}
    obs_f = [f for f in m.obs_flops if (cone_nets & set(f["pins"].values())) or f["q"] == net]
    obs_p = [n for n in m.pos if n in cone_nets]
    if not obs_f and not obs_p:
        return "UNOBSERVABLE", None
    good = {}
    bad = {}

    def var_good(n):
        if n in good:
            return good[n]
        d = m.drv.get(n)
        if n is None:
            good[n] = z3.BoolVal(False); return good[n]
        if n in m.const:
            good[n] = z3.BoolVal(bool(m.const[n])); return good[n]
        if d is None or d[0] in ("pi", "ff"):
            if d and d[0] == "pi" and n in CONSTRAINTS:
                good[n] = z3.BoolVal(bool(CONSTRAINTS[n]))
            elif d and d[0] == "ff" and d[1]["qn"] == n and d[1]["q"]:
                good[n] = z3.Not(var_good(d[1]["q"]))
            else:
                good[n] = z3.Bool("g_" + n)
            return good[n]
        out, fn, ins, *_ = m.gates[d[1]]
        ast_env = {p: var_good(x) for p, x in ins.items()}
        good[n] = ast_to_z3(m, d[1], ast_env)
        return good[n]

    def var_bad(n):
        if n == net:
            return z3.BoolVal(bool(sv))
        if n not in cone_nets:
            return var_good(n)
        if n in bad:
            return bad[n]
        d = m.drv[n]
        out, fn, ins, *_ = m.gates[d[1]]
        bad[n] = ast_to_z3(m, d[1], {p: var_bad(x) for p, x in ins.items()})
        return bad[n]

    diffs = []
    for f in obs_f:
        eg = {p: var_good(x) for p, x in f["pins"].items()}
        eb = {p: var_bad(x) for p, x in f["pins"].items()}
        if f["q"]:
            eg[f["iq"]] = var_good(f["q"]); eb[f["iq"]] = var_bad(f["q"])
        diffs.append(z3.Xor(ast_eval_z3(f["next_ast"], eg), ast_eval_z3(f["next_ast"], eb)))
    for n in obs_p:
        diffs.append(z3.Xor(var_good(n), var_bad(n)))
    s = z3.Solver()
    s.set("timeout", timeout_ms)
    s.add(z3.Or(*diffs))
    r = s.check()
    if r == z3.unsat:
        return "UNTESTABLE", None
    if r != z3.sat:
        return "ABORTED", None
    mdl = s.model()
    pat = {}
    for d in mdl.decls():
        nm = d.name()
        if nm.startswith("g_"):
            pat[nm[2:]] = 1 if z3.is_true(mdl[d]) else 0
    return "SAT", pat


def ast_eval_z3(ast, env):
    import z3
    op = ast[0]
    if op == "var":
        return env[ast[1]]
    if op == "const":
        return z3.BoolVal(bool(ast[1]))
    if op == "not":
        return z3.Not(ast_eval_z3(ast[1], env))
    a, b = ast_eval_z3(ast[1], env), ast_eval_z3(ast[2], env)
    return {"and": z3.And, "or": z3.Or, "xor": z3.Xor}[op](a, b)


def ast_to_z3(m: Model, gi: int, env):
    return ast_eval_z3(m.gate_ast[gi], env)


def attach_asts(m: Model, liberty_cells):
    from .engine import parse_expr  # noqa
    m.gate_ast = []
    for out, fn, ins, iname, cell, pin in m.gates:
        m.gate_ast.append(liberty_cells[cell].outputs[pin])
    for f in m.flops:
        f["next_ast"] = liberty_cells[f["cell"]].ff["next"]


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--netlist", default=str(ROOT / "reports/testcore/synth/E/netlist.v"))
    ap.add_argument("--scan-netlist", default=str(ROOT / "reports/testcore/dft/scan_netlist.v"))
    ap.add_argument("--liberty", default=str(ROOT / "third_party/pdk/sky130_fd_sc_hd__tt_025C_1v80.lib"))
    ap.add_argument("--block", type=int, default=1024)
    ap.add_argument("--max-blocks", type=int, default=12)
    ap.add_argument("--sat-seconds", type=float, default=600)
    ap.add_argument("--sat-timeout-ms", type=int, default=3000)
    ap.add_argument("--validate", type=int, default=24)
    a = ap.parse_args(argv)
    OUT.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    m = Model(Path(a.netlist), Path(a.liberty), capture_clock="clk")
    attach_asts(m, m.lib)
    faults = m.fault_list()
    status = {f: "UNDETECTED" for f in faults}
    rng = random.Random(0x5F07)
    W = a.block
    M = (1 << W) - 1
    patterns = []           # list of (env_block, bitmask of useful patterns) -- stored as seeds for reproducibility
    hist = []
    det_block = {}
    for b in range(a.max_blocks):
        env = m.inputs_block(rng, W)
        good = m.eval_good(env, M)
        gobs = m.observe(good, M)
        new = 0
        useful = 0
        for f in faults:
            if status[f] != "UNDETECTED":
                continue
            d = m.fault_sim(good, gobs, M, f[0], f[1])
            if d:
                status[f] = "DETECTED_RANDOM"; new += 1
                useful |= d & -d          # lowest detecting pattern
        hist.append({"block": b, "patterns": W, "newly_detected": new, "useful_patterns": bin(useful).count("1"),
                     "cum_detected": sum(1 for v in status.values() if v.startswith("DETECTED"))})
        patterns.append({"block": b, "useful_mask_popcount": bin(useful).count("1")})
        det_block[b] = (env, useful)
        print(f"[atpg] random block {b}: +{new} (useful patterns {bin(useful).count('1')})", flush=True)
        if new < max(3, len(faults) // 2000):
            break
    # ---------------------------------------------------------------- SAT top-off
    sat_pats = []
    t_sat = time.time()
    rem = [f for f in faults if status[f] == "UNDETECTED"]
    attempted = 0
    for f in rem:
        if status[f] != "UNDETECTED":
            continue
        if time.time() - t_sat > a.sat_seconds:
            break
        attempted += 1
        res, pat = sat_pattern(m, f[0], f[1], a.sat_timeout_ms)
        if res in ("UNTESTABLE", "UNOBSERVABLE"):
            status[f] = "UNTESTABLE" if res == "UNTESTABLE" else "UNTESTABLE_UNOBSERVABLE"
            continue
        if res != "SAT":
            status[f] = "ABORTED_TIMEOUT"
            continue
        # validate with the 3-valued simulator (X sources unknown), random fill of unspecified bits
        fixed = {}
        for n, v in pat.items():
            fixed[n] = (1 if v else 0, 1)
        env = m.inputs_block(rng, 1, fixed)
        good = m.eval_good(env, 1)
        gobs = m.observe(good, 1)
        if m.fault_sim(good, gobs, 1, f[0], f[1]):
            status[f] = "DETECTED_SAT"
            sat_pats.append(env)
            # fault-drop: simulate this pattern against the other remaining faults
            for g in rem:
                if status[g] == "UNDETECTED" and m.fault_sim(good, gobs, 1, g[0], g[1]):
                    status[g] = "DETECTED_SAT"
        else:
            status[f] = "ABORTED_X_DEPENDENT"
    for f in faults:
        if status[f] == "UNDETECTED":
            status[f] = "ABORTED_NOT_ATTEMPTED"
    # ---------------------------------------------------------------- second capture: tck domain (posedge)
    mt = Model(Path(a.netlist), Path(a.liberty), capture_clock="tck")
    attach_asts(mt, mt.lib)
    retry = [f for f in faults if not status[f].startswith("DETECTED")]
    tck_hits = 0
    for b in range(4):
        env = mt.inputs_block(rng, W)
        good = mt.eval_good(env, M)
        gobs = mt.observe(good, M)
        for f in retry:
            if not status[f].startswith("DETECTED") and mt.fault_sim(good, gobs, M, f[0], f[1]):
                status[f] = "DETECTED_TCK_CAPTURE"; tck_hits += 1
    t2 = time.time()
    for f in retry:
        if status[f].startswith("DETECTED") or time.time() - t2 > a.sat_seconds / 3:
            continue
        res, pat = sat_pattern(mt, f[0], f[1], a.sat_timeout_ms)
        if res == "SAT":
            env = mt.inputs_block(rng, 1, {n: (1 if v else 0, 1) for n, v in pat.items()})
            good = mt.eval_good(env, 1)
            if mt.fault_sim(good, mt.observe(good, 1), 1, f[0], f[1]):
                status[f] = "DETECTED_TCK_CAPTURE"; tck_hits += 1
        elif res in ("UNTESTABLE", "UNOBSERVABLE") and status[f] in ("UNTESTABLE", "UNTESTABLE_UNOBSERVABLE"):
            # untestable in BOTH capture domains
            status[f] = "UNTESTABLE" if (res == "UNTESTABLE" or status[f] == "UNTESTABLE") else "UNTESTABLE_UNOBSERVABLE"
    cnt = {}
    for v in status.values():
        cnt[v] = cnt.get(v, 0) + 1
    total = len(faults)
    det = cnt.get("DETECTED_RANDOM", 0) + cnt.get("DETECTED_SAT", 0) + cnt.get("DETECTED_TCK_CAPTURE", 0)
    unt = cnt.get("UNTESTABLE", 0) + cnt.get("UNTESTABLE_UNOBSERVABLE", 0)
    n_random_useful = sum(bin(u).count("1") for _, u in det_block.values())
    summary = {
        "evidence_class": "ATPG EXPERIMENT (in-house, research-grade; NOT a production ATPG result)",
        "netlist": a.netlist, "model": {
            "full_scan_assumption": True, "capture_clock": "clk (posedge); second pass tck (posedge) for faults "
            "not detected in the clk capture", "constraints": CONSTRAINTS,
            "fault_model": "single stuck-at on net stems (no fanout-branch, no clock-net faults)",
            "memories": "black box: macro-proxy outputs are X sources, macro inputs unobservable",
            "cells": len(m.gates), "flops": len(m.flops), "ppi": len(m.ppis), "x_sources": len(m.xsrc),
            "observed_flops": len(m.obs_flops), "primary_inputs": len(m.pis), "primary_outputs": len(m.pos)},
        "faults_total": total, "classification": cnt,
        "fault_coverage_pct": round(100.0 * det / total, 3),
        "test_coverage_pct": round(100.0 * det / max(1, total - unt), 3),
        "patterns": {"random_blocks_applied": len(det_block), "random_patterns_applied": len(det_block) * W,
                     "random_patterns_useful (first detecting pattern per fault)": n_random_useful,
                     "sat_patterns": len(sat_pats)},
        "sat": {"faults_attempted": attempted, "seconds": round(time.time() - t_sat, 1),
                "timeout_ms_per_fault": a.sat_timeout_ms},
        "random_history": hist, "seconds_total": round(time.time() - t0, 1),
        "targets": {"stuck_at_target_pct": 99.0, "transition_target_pct": 95.0,
                    "note": "targets are provisional engineering goals; transition faults NOT modelled here"},
    }
    with open(OUT / "faults.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["net", "stuck_at", "class"])
        for (n, sv), st in sorted(status.items()):
            w.writerow([n, sv, st])
    # ---------------------------------------------------------------- gate-level validation of sample patterns
    val = validate_on_scan_netlist(m, det_block, sat_pats, Path(a.scan_netlist), a.validate, W)
    summary["pattern_validation"] = val
    (OUT / "summary.json").write_text(json.dumps(summary, indent=1))
    print(json.dumps({k: summary[k] for k in ("faults_total", "classification", "fault_coverage_pct",
                                              "test_coverage_pct", "patterns")}, indent=1))
    print("[atpg] validation:", val.get("result"), val.get("compared_bits"), val.get("mismatches"))
    return 0


def chain_map(scan_net: Path):
    txt = scan_net.read_text()
    cells = re.findall(r"(sky130_fd_sc_hd__\w+)\s+(\S+)\s*\((.*?)\);", txt, re.S)
    pins = {n: {k: v.strip() for k, v in re.findall(r"\.(\w+)\(([^()]*?)\)", b)} for _, n, b in cells}
    by_scd = {}
    for n, p in pins.items():
        if "SCD" in p:
            by_scd.setdefault(p["SCD"], []).append(n)
    chains = {}
    for m in re.finditer(r"^\s*input scan_in_(\d+);", txt, re.M):
        i = int(m.group(1)); cur = f"scan_in_{i}"; ch = []
        while cur in by_scd:
            nm = by_scd[cur][0]; ch.append(nm); cur = pins[nm].get("Q") or pins[nm].get("Q_N")
        chains[i] = ch
    return chains, txt


def validate_on_scan_netlist(m: Model, blocks: dict, sat_pats: list, scan_net: Path, n: int, W: int) -> dict:
    """Shift / capture / shift-out on the gate-level scan netlist; compare with the model."""
    if not scan_net.exists():
        return {"result": "NOT RUN", "reason": "scan netlist missing"}
    chains, txt = chain_map(scan_net)
    pos = {}
    for ci, ch in chains.items():
        for p, nm in enumerate(ch):
            pos[nm] = (ci, p)
    by_name = {f["name"]: f for f in m.flops}
    missing = [nm for nm in by_name if nm not in pos]
    # choose patterns: bits of block 0 + SAT patterns
    pats = []
    env0, _ = blocks[0]
    for k in range(min(n // 2, W)):
        pats.append({x: ((v >> k) & 1, (kk >> k) & 1) for x, (v, kk) in env0.items() if x is not None})
    for e in sat_pats[: n - len(pats)]:
        pats.append({x: (v & 1, kk & 1) for x, (v, kk) in e.items() if x is not None})
    # expected responses (1-bit evaluation)
    exp_all = []
    for p in pats:
        env = {x: ((1 if v else 0), (1 if k else 0)) for x, (v, k) in p.items()}
        env[None] = (0, 0)
        good = m.eval_good(env, 1)
        exp = {}
        for f in m.flops:
            if f["bb"]:
                continue
            if f["domain"] == m.capture:
                e = {pp: good.get(nn, (0, 0)) for pp, nn in f["pins"].items()}
                e[f["iq"]] = good.get(f["q"], (0, 0))
                exp[f["name"]] = f["next"](e, 1)
            else:
                exp[f["name"]] = good.get(f["q"], (0, 0))     # held (not clocked in this capture)
        exp_all.append(exp)
    # load values per flop (PPI values; X sources loaded with 0)
    L = {ci: len(ch) for ci, ch in chains.items()}
    Lmax = max(L.values())
    top = re.search(r"^module (\w+)", txt, re.M).group(1)
    ins = re.findall(r"^\s*input\s+(\[[^\]]+\])?\s*(\w+);", txt, re.M)
    outs = re.findall(r"^\s*output\s+(\[[^\]]+\])?\s*(\w+);", txt, re.M)
    lines = ["`timescale 1ns/1ps", "module tb_atpg_replay;", "  reg clk = 0, tck = 0;"]
    for w, p in ins:
        if p not in ("clk", "tck"):
            lines.append(f"  reg {w} {p};")
    for w, p in outs:
        lines.append(f"  wire {w} {p};")
    lines.append(f"  {top} dut (" + ", ".join(f".{p}({p})" for _, p in ins + outs) + ");")
    lines.append("  integer errs = 0, cmp = 0;")
    lines.append("  initial begin")
    for w, p in ins:
        if p in ("clk", "tck"):
            continue
        lines.append(f"    {p} = 0;")
    lines += ["    trst_n = 1; rst_n = 1; scan_rst_n_pin = 1; scan_mode_pin = 1; hw_test_en = 1; scan_en_pin = 0;", "    #10;"]
    pi_names = [x for x in m.pis if x not in CONSTRAINTS]

    def pi_assign(p):
        out = []
        for x in pi_names:
            v = p.get(x, (0, 1))[0]
            mm = re.match(r"(\w+)\[(\d+)\]", x)
            out.append(f"    {x} = 1'b{v};" if not mm else f"    {mm.group(1)}[{mm.group(2)}] = 1'b{v};")
        return out
    for pi_idx, (p, exp) in enumerate(zip(pats, exp_all)):
        # shift in: value for position q is shifted at cycle (L-1-q); pad to Lmax per chain
        lines.append(f"    // pattern {pi_idx}")
        lines.append("    scan_enable_0 = 1;")
        load = {}
        for nm, f in by_name.items():
            if nm in pos and f["q"]:
                v = p.get(f["q"], (0, 0))[0] if not f["bb"] else 0
                load[nm] = v
        for t in range(Lmax):
            for ci, ch in chains.items():
                q = L[ci] - 1 - (t - (Lmax - L[ci]))
                bit = load.get(ch[q], 0) if 0 <= q < L[ci] else 0
                lines.append(f"    scan_in_{ci} = 1'b{bit};")
            lines.append("    #5 clk = 1; tck = 1; #5 clk = 0; tck = 0; #1;   // #1: no input change in the falling-edge time step")
        lines += pi_assign(p)
        lines.append("    scan_enable_0 = 0; #5 clk = 1; #5 clk = 0; #1;   // capture on clk only")
        lines.append("    scan_enable_0 = 1;")
        # shift out: before edge t, scan_out shows position L-1-t
        for t in range(Lmax):
            for ci, ch in chains.items():
                q = L[ci] - 1 - t
                if q < 0:
                    continue
                nm = ch[q]
                if nm in exp and exp[nm][1]:
                    lines.append(f"    cmp = cmp + 1; if (scan_out_{ci} !== 1'b{exp[nm][0]}) begin errs = errs + 1; "
                                 f"$display(\"MISMATCH pat {pi_idx} chain {ci} pos {q} cell {nm}\"); end")
            lines.append("    #5 clk = 1; tck = 1; #5 clk = 0; tck = 0; #1;   // #1: no input change in the falling-edge time step")
    lines += ["    $display(\"ATPG_REPLAY compared=%0d errors=%0d\", cmp, errs);", "    $finish;", "  end", "endmodule"]
    tbf = OUT / "tb_atpg_replay.v"
    tbf.write_text("\n".join(lines) + "\n")
    cells_v = ROOT / "reports/testcore/dft/sky130_cells_from_liberty.v"
    r = subprocess.run(["iverilog", "-g2012", "-o", str(OUT / "tb_atpg_replay.vvp"), str(tbf), str(scan_net),
                        str(cells_v)], capture_output=True, text=True)
    if r.returncode:
        return {"result": "ERROR", "detail": (r.stdout + r.stderr)[-1500:]}
    s = subprocess.run(["vvp", "-n", str(OUT / "tb_atpg_replay.vvp")], capture_output=True, text=True, timeout=3600)
    (OUT / "replay.log").write_text(s.stdout[-20000:])
    mm = re.search(r"ATPG_REPLAY compared=(\d+) errors=(\d+)", s.stdout)
    if not mm:
        return {"result": "ERROR", "detail": s.stdout[-1500:]}
    c, e = int(mm.group(1)), int(mm.group(2))
    return {"result": "PASS" if e == 0 else "FAIL", "patterns_replayed": len(pats), "compared_bits": c,
            "mismatches": e, "flops_not_in_chains": len(missing),
            "method": "gate-level Icarus simulation of the OpenROAD scan netlist with liberty-derived cell models: "
                      "shift-in, single clk capture, shift-out; expected values from the ATPG model (X masked)"}


if __name__ == "__main__":
    sys.exit(main())
