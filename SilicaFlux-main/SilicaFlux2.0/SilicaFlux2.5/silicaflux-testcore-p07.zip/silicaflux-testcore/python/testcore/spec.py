"""TestCore specification constants.

The ONE authoritative definition is rtl/testcore/sftc_consts.svh (included by
every RTL module and wrapped by sftc_pkg).  This module parses that file at
import time, so the host software can never drift from the hardware encodings.
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SVH = ROOT / "rtl" / "testcore" / "sftc_consts.svh"

_LIT = re.compile(r"^(?:(\d+)')?([hdbo])?([0-9a-fA-F_xXzZ]+)$")


def _lit(tok: str, env: dict) -> int:
    tok = tok.strip()
    if tok in env:
        return env[tok]
    m = re.match(r"^(\d+)'([hdbo])([0-9a-fA-F_]+)$", tok)
    if m:
        base = {"h": 16, "d": 10, "b": 2, "o": 8}[m.group(2)]
        return int(m.group(3).replace("_", ""), base)
    if re.match(r"^\d+$", tok):
        return int(tok)
    raise ValueError(tok)


def _eval(expr: str, env: dict) -> int:
    expr = expr.strip()
    if expr.startswith("{") and expr.endswith("}"):
        # concatenation of known-width fields: {A, B, C, 1'b1}
        parts = [p.strip() for p in expr[1:-1].split(",")]
        val, width = 0, 0
        for p in reversed(parts):
            w = WIDTHS.get(p)
            m = re.match(r"^(\d+)'", p)
            if m:
                w = int(m.group(1))
            v = _lit(p, env)
            val |= v << width
            width += w
        return val
    return _lit(expr, env)


WIDTHS: dict[str, int] = {}
CONST: dict[str, int] = {}


def _load():
    txt = SVH.read_text()
    for m in re.finditer(r"localparam\s+(?:logic\s*\[(\d+):0\]|int)\s+(\w+)\s*=\s*([^;]+);", txt):
        hi, name, expr = m.group(1), m.group(2), m.group(3)
        if "(" in expr and not expr.strip().startswith("{"):
            continue
        try:
            CONST[name] = _eval(expr, CONST)
            WIDTHS[name] = int(hi) + 1 if hi else 32
        except ValueError:
            pass
    # also "localparam logic [3:0] A = .., B = .." multi-declarations (TAP states)
    for m in re.finditer(r"localparam\s+logic\s*\[\d+:0\]\s+((?:\w+\s*=\s*[^,;]+,\s*)+\w+\s*=\s*[^;]+);", txt):
        for part in m.group(1).split(","):
            n, v = part.split("=")
            CONST.setdefault(n.strip(), _lit(v, CONST))


_load()


def c(name: str) -> int:
    return CONST[name]


REGS = {k: v for k, v in CONST.items() if k.startswith("R_")}
ALGS = {"march_c_minus": c("ALG_MARCH_C_MINUS"), "mats_plus": c("ALG_MATS_PLUS"),
        "checkerboard": c("ALG_CHECKERBOARD"), "inv_checkerboard": c("ALG_INV_CHECKER"),
        "walk_one": c("ALG_WALK_ONE"), "walk_zero": c("ALG_WALK_ZERO")}
MODES = {"NORMAL": c("MODE_NORMAL"), "JTAG_ACCESS": c("MODE_JTAG_ACCESS"), "MBIST": c("MODE_MBIST"),
         "SCAN_SHIFT": c("MODE_SCAN_SHIFT"), "SCAN_CAPTURE": c("MODE_SCAN_CAPTURE"),
         "DIAGNOSTIC": c("MODE_DIAGNOSTIC")}
MODE_NAMES = {v: k for k, v in MODES.items()}
OWNER_STATES = {c("OWN_NORMAL"): "NORMAL", c("OWN_QUIESCE_REQUEST"): "QUIESCE_REQUEST",
                c("OWN_WAIT_FOR_IDLE"): "WAIT_FOR_IDLE", c("OWN_TEST_ACQUIRE"): "TEST_ACQUIRE",
                c("OWN_TEST_ACTIVE"): "TEST_ACTIVE", c("OWN_TEST_COMPLETE"): "TEST_COMPLETE",
                c("OWN_TEST_RELEASE"): "TEST_RELEASE", c("OWN_FAULT"): "FAULT"}
RESULTS = {c("RES_NOT_RUN"): "NOT_RUN", c("RES_PASS"): "PASS", c("RES_FAIL"): "FAIL",
           c("RES_ABORTED"): "ABORTED", c("RES_ERROR"): "ERROR", c("RES_RUNNING"): "RUNNING"}
ERROR_FLAGS = {c(k): k[3:] for k in CONST if k.startswith("EF_") and k != "EF_"}
IR = {k[3:]: v for k, v in CONST.items() if k.startswith("IR_") and k not in ("IR_LEN", "IR_CAPTURE")}
IR_LEN = c("IR_LEN")
IDCODE = c("IDCODE_VALUE")
REG_DR_LEN = c("REG_DR_LEN")
REGOP = {"NOP": c("REGOP_NOP"), "READ": c("REGOP_READ"), "WRITE": c("REGOP_WRITE"), "CLEAR": c("REGOP_CLEAR")}
REGST = {c("REGST_OK"): "OK", c("REGST_ERR"): "ERROR", c("REGST_BUSY"): "BUSY"}
UNLOCK_KEY = c("TC_UNLOCK_KEY")
REVISION = c("TC_REVISION")


def revision_str(v: int) -> str:
    return f"{(v >> 24) & 0xFF}.{(v >> 16) & 0xFF}.{v & 0xFFFF}"
