"""Golden (reference) model of the SilicaFlux TestCore MBIST algorithms.

Written independently from the RTL, from the algorithm definitions in
docs/testcore/mbist.md.  It produces:

* the exact sequence of memory operations an MBIST run must issue
  (bank, read/write, address, data / expected data),
* the outcome of executing that sequence against a (faulty) memory model:
  first failure record, fail count, failure FIFO, final memory content,
* the modelled cycle count for deterministic memory timing.

The RTL regression compares the simulator's transaction trace and result
record against this model; agreement is required for a PASS.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterator, Optional

from .fault_models import FaultyMemory

ALG_IDS = {
    "march_c_minus": 0,
    "mats_plus": 1,
    "checkerboard": 2,
    "inv_checkerboard": 3,
    "walk_one": 4,
    "walk_zero": 5,
}
ALG_NAMES = {v: k for k, v in ALG_IDS.items()}

# (direction, background, ops); op = (is_read, invert)
#   direction: "up" | "down" | "any" (any is executed ascending)
#   background: "solid" | "checker"
R0, R1, W0, W1 = (True, False), (True, True), (False, False), (False, True)
MARCH_TABLE: dict[int, list] = {
    0: [("any", "solid", [W0]), ("up", "solid", [R0, W1]), ("up", "solid", [R1, W0]),
        ("down", "solid", [R0, W1]), ("down", "solid", [R1, W0]), ("any", "solid", [R0])],
    1: [("any", "solid", [W0]), ("up", "solid", [R0, W1]), ("down", "solid", [R1, W0])],
    2: [("up", "checker", [W0]), ("up", "checker", [R0])],
    3: [("up", "checker", [W1]), ("up", "checker", [R1])],
    4: [("walk", 1)],
    5: [("walk", 0)],
}

RES_NOT_RUN, RES_PASS, RES_FAIL, RES_ABORTED, RES_ERROR, RES_RUNNING = range(6)


def nominal_ops(alg: int, n: int, width: int) -> int:
    """Nominal operation count of one algorithm on N words of `width` bits."""
    if alg in (4, 5):
        return (2 * width + 1) * n
    return sum(len(e[2]) for e in MARCH_TABLE[alg]) * n


@dataclass(frozen=True)
class Op:
    bank: int
    is_read: bool
    addr: int
    data: int          # write data, or expected data for reads
    elem: int
    op_idx: int        # RTL op index field (j mod 4)
    walk_bit: int      # RTL walk-bit field ((j >> 1) & 0xff)
    scrub: bool = False


def checker(addr: int, width: int) -> int:
    v = 0
    for i in range(width):
        if ((i % 2) == 1) ^ (addr & 1):
            v |= 1 << i
    return v


def element_ops(alg: int, elem_idx: int, elem, bank: int, depth: int, width: int,
                bg_chk: bool) -> Iterator[list[Op]]:
    """Yield, per address, the list of operations of one element."""
    mask = (1 << width) - 1
    if elem[0] == "walk":
        walk_one = elem[1] == 1
        bg = 0 if walk_one else mask
        for a in range(depth):
            ops = []
            for j in range(2 * width + 1):
                if j == 2 * width:
                    ops.append(Op(bank, False, a, bg, elem_idx, j & 3, (j >> 1) & 0xFF))
                else:
                    b = j >> 1
                    p = (bg ^ (1 << b)) & mask
                    ops.append(Op(bank, bool(j & 1), a, p, elem_idx, j & 3, (j >> 1) & 0xFF))
            yield ops
        return
    direction, bgsel, oplist = elem
    addrs = range(depth - 1, -1, -1) if direction == "down" else range(depth)
    for a in addrs:
        bg = checker(a, width) if (bgsel == "checker" or bg_chk) else 0
        ops = []
        for k, (is_rd, inv) in enumerate(oplist):
            d = (~bg if inv else bg) & mask
            ops.append(Op(bank, is_rd, a, d, elem_idx, k & 3, (k >> 1) & 0xFF))
        yield ops


@dataclass
class BankCfg:
    width: int
    depth: int
    write_resp: bool = False


@dataclass
class RunResult:
    result: int = RES_NOT_RUN
    fail: bool = False
    fail_count: int = 0
    cnt_ovf: bool = False
    first: Optional[dict] = None
    log: list = field(default_factory=list)
    log_ovf: bool = False
    tested: int = 0
    failed: int = 0
    scrubbed: int = 0
    trace: list = field(default_factory=list)       # issued Ops
    compares: list = field(default_factory=list)    # (bank, addr, exp, obs, mism)
    cycles: int = 0
    nspur: int = 0
    nmerr: int = 0
    error: bool = False


class GoldenMbist:
    """Executes MBIST algorithms against FaultyMemory banks."""

    def __init__(self, banks: list[BankCfg], log_depth: int = 4, cnt_w: int = 16):
        self.banks = banks
        self.log_depth = log_depth
        self.cnt_max = (1 << cnt_w) - 1

    def run(self, mems: list[FaultyMemory], alg: int, mask: int, bg_chk=False, sof=False,
            scrub=True, latency=1, timeout=256) -> RunResult:
        r = RunResult()
        stop = False
        nb = len(self.banks)
        cyc = nb + 1 + 1                       # S_BANK visits + final S_BANK + S_DONE
        for b in range(nb):
            if stop:
                break
            if not (mask >> b) & 1:
                continue
            cfg, mem = self.banks[b], mems[b]
            wmask = (1 << cfg.width) - 1
            elems = MARCH_TABLE[alg]
            cyc += len(elems) + 1 + 1          # S_ELEM per element + END element + S_BEND
            bank_stopped = False
            for ei, elem in enumerate(elems):
                for ops in element_ops(alg, ei, elem, b, cfg.depth, cfg.width, bg_chk):
                    for op in ops:
                        if not mem.granted():
                            r.error = True
                            r.result = RES_ERROR
                            r.cycles = None
                            return r
                        r.trace.append(op)
                        if op.is_read:
                            out = mem.read(op.addr)
                            if out.no_response:
                                r.error = True
                                r.result = RES_ERROR
                                r.cycles = None
                                return r
                            cyc += 1 + latency + mem.extra_latency
                            obs = out.data & wmask
                            synd = (op.data ^ obs) & wmask
                            mism = synd != 0 or out.err
                            if out.err:
                                r.nmerr += 1
                            r.compares.append((b, op.addr, op.data, obs, int(mism)))
                            if mism:
                                self._log(r, b, op, obs, synd)
                                r.failed |= 1 << b
                                if sof:
                                    bank_stopped = True
                        else:
                            mem.write(op.addr, op.data, cfg.write_resp)
                            cyc += 1 + ((latency + mem.extra_latency) if cfg.write_resp else 0)
                        if mem.dup_pending():
                            r.nspur += 1
                        if bank_stopped:
                            break
                    if bank_stopped:
                        break
                if bank_stopped:
                    break
            if scrub:
                for a in range(cfg.depth):
                    op = Op(b, False, a, 0, len(elems) if not bank_stopped else ei, 0, 0, True)
                    if not mem.granted():
                        r.error = True
                        r.result = RES_ERROR
                        r.cycles = None
                        return r
                    r.trace.append(op)
                    mem.write(a, 0, cfg.write_resp)
                    cyc += 1 + ((latency + mem.extra_latency) if cfg.write_resp else 0)
                r.scrubbed |= 1 << b
            if bank_stopped:
                stop = True
            else:
                r.tested |= 1 << b
        r.result = RES_ERROR if r.nspur else (RES_FAIL if r.fail else RES_PASS)
        r.cycles = cyc
        return r

    def _log(self, r: RunResult, b: int, op: Op, obs: int, synd: int) -> None:
        info = (op.walk_bit << 16) | (op.op_idx << 12) | (op.elem << 8) | b
        r.fail = True
        if r.fail_count >= self.cnt_max:
            r.cnt_ovf = True
        else:
            r.fail_count += 1
        if r.first is None:
            r.first = dict(info=info, addr=op.addr, exp=op.data, obs=obs)
        elif len(r.log) < self.log_depth:
            r.log.append((op.addr, info, synd))
        else:
            r.log_ovf = True


def cycle_formula(alg: int, n: int, width: int, latency: int = 1, scrub: bool = True,
                  write_resp: bool = False, banks_total: int = 1) -> int:
    """Closed-form cycle count of a fault-free run on ONE selected bank
    (grant always asserted, fixed read latency, no bank-mux register slices)."""
    wcost = 1 + (latency if write_resp else 0)
    rcost = 1 + latency
    if alg in (4, 5):
        reads, writes, nel = width * n, (width + 1) * n, 1
    else:
        reads = sum(1 for e in MARCH_TABLE[alg] for o in e[2] if o[0]) * n
        writes = sum(1 for e in MARCH_TABLE[alg] for o in e[2] if not o[0]) * n
        nel = len(MARCH_TABLE[alg])
    c = reads * rcost + writes * wcost + (nel + 1) + 1 + (banks_total + 1) + 1
    if scrub:
        c += n * wcost
    return c
