"""Manufacturing / bring-up test records (structured, JSON + CSV).

Status values are restricted to PASS, FAIL, NOT RUN, BLOCKED, INVALID,
INCONCLUSIVE.  Physical fields (wafer, die, temperature, voltage, equipment)
are optional and are NEVER filled with invented values: when absent they stay
null.  Records produced against simulation carry evidence_class = SIMULATION
and can never be binned as good silicon.  Synthetic examples are marked
DEMONSTRATION.
"""
from __future__ import annotations

import csv
import datetime as dt
import json
from enum import Enum
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, Field

from . import __version__, spec


class Status(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    NOT_RUN = "NOT RUN"
    BLOCKED = "BLOCKED"
    INVALID = "INVALID"
    INCONCLUSIVE = "INCONCLUSIVE"


class Evidence(str, Enum):
    SIMULATION = "SIMULATION"          # RTL simulation (tb_testcore_sys)
    FPGA = "FPGA"
    WAFER_PROBE = "WAFER_PROBE"
    PACKAGED_SILICON = "PACKAGED_SILICON"
    DEMONSTRATION = "DEMONSTRATION"    # synthetic example data


class StepRecord(BaseModel):
    name: str
    status: Status
    detail: dict = Field(default_factory=dict)
    duration_s: Optional[float] = None


class TestRecord(BaseModel):
    record_version: str = "1.0"
    evidence_class: Evidence
    design_version: str
    device_revision: Optional[str] = None
    testcore_version: str = __version__
    testcore_rtl_revision: Optional[str] = None
    test_firmware_version: Optional[str] = None
    test_configuration: dict = Field(default_factory=dict)
    timestamp_utc: str = Field(default_factory=lambda: dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"))
    equipment_id: Optional[str] = None
    wafer_id: Optional[str] = None
    die_x: Optional[int] = None
    die_y: Optional[int] = None
    package_serial: Optional[str] = None
    temperature_c: Optional[float] = None
    voltage_v: Optional[float] = None
    test_clock_hz: Optional[float] = None
    tck_hz: Optional[float] = None
    steps: list[StepRecord] = Field(default_factory=list)
    mbist: list[dict] = Field(default_factory=list)
    scan_atpg: Optional[dict] = None
    failure_count: int = 0
    failure_locations: list[dict] = Field(default_factory=list)
    status: Status = Status.NOT_RUN
    bin: Optional[str] = None
    notes: list[str] = Field(default_factory=list)

    def finalize(self) -> "TestRecord":
        sts = [s.status for s in self.steps]
        if not sts:
            self.status = Status.NOT_RUN
        elif any(s == Status.FAIL for s in sts):
            self.status = Status.FAIL
        elif any(s in (Status.INVALID, Status.INCONCLUSIVE) for s in sts):
            self.status = Status.INCONCLUSIVE
        elif any(s == Status.BLOCKED for s in sts):
            self.status = Status.BLOCKED
        elif all(s == Status.PASS for s in sts):
            self.status = Status.PASS
        else:
            self.status = Status.INCONCLUSIVE
        self.bin = self.classify()
        return self

    def classify(self) -> str:
        """Bin rules (docs/testcore/manufacturing_data.md).  Only silicon
        evidence can be binned as a good part."""
        if self.evidence_class in (Evidence.SIMULATION, Evidence.DEMONSTRATION, Evidence.FPGA):
            return f"NO-BIN ({self.evidence_class.value})"
        if self.status == Status.PASS:
            return "BIN1 (all executed tests PASS)"
        if any(s.name.startswith("mbist") and s.status == Status.FAIL for s in self.steps):
            return "BIN5 (memory BIST failure)"
        if any(s.name.startswith("jtag") and s.status == Status.FAIL for s in self.steps):
            return "BIN7 (test access failure)"
        if self.status == Status.FAIL:
            return "BIN9 (other failure)"
        return "BIN0 (incomplete / not binnable)"

    def write(self, run_dir: Path) -> Path:
        run_dir.mkdir(parents=True, exist_ok=True)
        p = run_dir / "test_record.json"
        p.write_text(self.model_dump_json(indent=1))
        with open(run_dir / "test_steps.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["timestamp_utc", "evidence_class", "design_version", "step", "status", "detail"])
            for s in self.steps:
                w.writerow([self.timestamp_utc, self.evidence_class.value, self.design_version, s.name,
                            s.status.value, json.dumps(s.detail, sort_keys=True)])
        with open(run_dir / "failures.csv", "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["bank", "address", "element", "op", "walk_bit", "expected", "observed", "syndrome"])
            for fl in self.failure_locations:
                w.writerow([fl.get(k) for k in ("bank", "address", "element", "op", "walk_bit", "expected",
                                                "observed", "syndrome")])
        return p


def summarize(run_dir: Path) -> str:
    rec = TestRecord.model_validate_json((run_dir / "test_record.json").read_text())
    lines = [f"Test record {run_dir}", f"  evidence class : {rec.evidence_class.value}",
             f"  design         : {rec.design_version}  TestCore {rec.testcore_version} "
             f"(RTL {rec.testcore_rtl_revision})", f"  status / bin   : {rec.status.value} / {rec.bin}"]
    for s in rec.steps:
        lines.append(f"  - {s.name:28s} {s.status.value}")
    if rec.failure_locations:
        lines.append(f"  failures       : {len(rec.failure_locations)} recorded (first: {rec.failure_locations[0]})")
    for n in rec.notes:
        lines.append(f"  note: {n}")
    return "\n".join(lines)
