"""Transports.  Two families:

* bit-level  (BitTransport): shifts TMS/TDI bit vectors, returns TDO bits.
  - SimTransport: the real RTL (tb_testcore_sys) under Icarus Verilog.
* TAP-level  (TapTransport): IR/DR scans executed by an external JTAG engine.
  - OpenOcdTransport: OpenOCD TCL-RPC (hardware adapters, or the RTL via the
    remote_bitbang bridge in tools/rbb_sim_bridge.py).

If no hardware adapter is reachable, HardwareNotAvailable is raised; callers
must report HARDWARE NOT AVAILABLE and never a passing silicon result.
"""


class HardwareNotAvailable(RuntimeError):
    pass


class TransportError(RuntimeError):
    pass
