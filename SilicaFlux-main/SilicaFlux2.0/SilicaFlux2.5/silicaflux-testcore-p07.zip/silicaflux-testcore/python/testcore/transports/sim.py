"""Simulation transport: drives tb/testcore/tb_testcore_sys.sv (real RTL) under
Icarus Verilog through two named pipes.

Protocol (one command per line, host -> TB; one reply line TB -> host):
  J <n> <tms_hex> <tdi_hex>      clock n TCK cycles     -> D <tdo_hex>
  C <n>                          run n system clocks    -> K
  SW <addr_hex> <data_hex>       system-bus write       -> V <rdata_hex> <err>
  SR <addr_hex>                  system-bus read        -> V <rdata_hex> <err>
  P <name> <value> <index>       set pin / knob         -> K
  G <name> <index>               read pin / status      -> V <int>
  M <bank>                       master scoreboard      -> V <errors> <reads> <writes> <blocked>
  F <bank> <kind> <a> <b> <a2> <b2>  SRAM-library generic-backend fault   -> K
  T                              simulation time        -> V <time>
  Q                              quit                   -> BYE
Bit i of a hex vector is TCK cycle i.
"""
from __future__ import annotations

import os
import subprocess
import tempfile
import threading
from pathlib import Path

from . import TransportError

ROOT = Path(__file__).resolve().parents[3]


class SimTransport:
    kind = "SIMULATION"
    MAXB = 1024

    def __init__(self, vvp: str | None = None, clk_half: float = 5.0, tck_half: float = 20.0,
                 workdir: str | None = None, log: list | None = None):
        self.log = log
        build = ROOT / "build"
        build.mkdir(exist_ok=True)
        self.vvp = Path(vvp) if vvp else build / "tb_sys.vvp"
        if not self.vvp.exists():
            r = subprocess.run([str(ROOT / "scripts" / "iv_sys.sh"), str(self.vvp)], capture_output=True, text=True)
            if r.returncode != 0:
                raise TransportError("cannot compile tb_testcore_sys: " + r.stdout + r.stderr)
        self.dir = Path(workdir or tempfile.mkdtemp(prefix="sftc_sim_"))
        self.cmd_p, self.rsp_p = self.dir / "cmd.fifo", self.dir / "rsp.fifo"
        for p in (self.cmd_p, self.rsp_p):
            if p.exists():
                p.unlink()
            os.mkfifo(p)
        self.proc = subprocess.Popen(["vvp", "-n", str(self.vvp), f"+cmd={self.cmd_p}", f"+rsp={self.rsp_p}",
                                      f"+clk_half={clk_half}", f"+tck_half={tck_half}"],
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        self._out: list[str] = []
        threading.Thread(target=self._drain, daemon=True).start()
        self.rsp = open(self.rsp_p, "r")
        self.cmd = open(self.cmd_p, "w")
        if self._line() != "READY":
            raise TransportError("simulator did not start")

    def _drain(self):
        for ln in self.proc.stdout:
            self._out.append(ln.rstrip())

    @property
    def sim_output(self) -> list[str]:
        return list(self._out)

    def _line(self) -> str:
        ln = self.rsp.readline()
        if not ln:
            raise TransportError("simulator closed the response pipe:\n" + "\n".join(self._out[-20:]))
        return ln.strip()

    def _x(self, s: str) -> str:
        self.cmd.write(s + "\n")
        self.cmd.flush()
        r = self._line()
        if self.log is not None:
            self.log.append((s, r))
        if r.startswith("E "):
            raise TransportError(r)
        return r

    # ---------------------------------------------------------------- bit level
    def shift(self, tms: list[int], tdi: list[int]) -> list[int]:
        out: list[int] = []
        for o in range(0, len(tms), self.MAXB):
            t, d = tms[o:o + self.MAXB], tdi[o:o + self.MAXB]
            tv = sum(b << i for i, b in enumerate(t))
            dv = sum(b << i for i, b in enumerate(d))
            r = self._x(f"J {len(t)} {tv:x} {dv:x}")
            v = int(r.split()[1], 16)
            out += [(v >> i) & 1 for i in range(len(t))]
        return out

    # ---------------------------------------------------------------- environment (simulation only)
    def cycles(self, n: int):
        self._x(f"C {n}")

    def set_pin(self, name: str, value: int, index: int = 0):
        self._x(f"P {name} {int(value)} {index}")

    def get(self, name: str, index: int = 0) -> int:
        return int(self._x(f"G {name} {index}").split()[1])

    def sys_write(self, addr: int, data: int) -> bool:
        return self._x(f"SW {addr:x} {data:x}").split()[2] == "0"

    def sys_read(self, addr: int) -> tuple[int, bool]:
        p = self._x(f"SR {addr:x}").split()
        return int(p[1], 16), p[2] == "0"

    def master_stats(self, bank: int) -> dict:
        e, r, w, b = (int(x) for x in self._x(f"M {bank}").split()[1:])
        return {"errors": e, "reads": r, "writes": w, "blocked_cycles": b}

    def inject_fault(self, bank: int, kind: int, addr: int, bit: int, addr2: int = 0, bit2: int = 0):
        self._x(f"F {bank} {kind} {addr} {bit} {addr2} {bit2}")

    def time_ns(self) -> int:
        return int(self._x("T").split()[1]) // 1000

    def close(self):
        try:
            self._x("Q")
        except Exception:
            pass
        try:
            self.cmd.close(); self.rsp.close()
        except Exception:
            pass
        try:
            self.proc.wait(timeout=10)
        except Exception:
            self.proc.kill()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()
