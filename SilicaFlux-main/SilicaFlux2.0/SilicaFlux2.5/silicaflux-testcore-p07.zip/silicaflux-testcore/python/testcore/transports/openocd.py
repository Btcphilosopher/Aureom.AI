"""Hardware transport adapter: OpenOCD TCL-RPC client (TAP-level operations).

Works with any OpenOCD-supported JTAG adapter (FTDI, J-Link, CMSIS-DAP, ...)
configured with the TestCore TAP declaration (dft/openocd/silicaflux_testcore.cfg).
It has been exercised ONLY against the RTL simulation through OpenOCD's
remote_bitbang driver (tools/rbb_sim_bridge.py) -- never against a physical
adapter or silicon.  If OpenOCD is not reachable, HardwareNotAvailable is raised.
"""
from __future__ import annotations

import socket

from . import HardwareNotAvailable, TransportError

SEP = b"\x1a"


class OpenOcdTransport:
    kind = "HARDWARE (OpenOCD)"

    def __init__(self, host: str = "127.0.0.1", port: int = 6666, tap: str = "sftc.tap", timeout: float = 5.0):
        self.tap = tap
        try:
            self.s = socket.create_connection((host, port), timeout=timeout)
        except OSError as e:
            raise HardwareNotAvailable(f"OpenOCD TCL server not reachable at {host}:{port} ({e})") from e
        self.s.settimeout(120.0)
        self.buf = b""

    def tcl(self, cmd: str) -> str:
        self.s.sendall(cmd.encode() + SEP)
        while SEP not in self.buf:
            d = self.s.recv(65536)
            if not d:
                raise TransportError("OpenOCD closed the connection")
            self.buf += d
        r, self.buf = self.buf.split(SEP, 1)
        return r.decode(errors="replace").strip()

    # ---------------------------------------------------------------- TAP level
    def reset(self):
        self.tcl("pathmove RESET IDLE")             # Test-Logic-Reset (IDCODE selected), then Run-Test/Idle
        # OpenOCD tracks a per-TAP bypass flag from the last IR it scanned; make
        # its view match the hardware (TLR selects IDCODE) before any drscan.
        self.tcl(f"irscan {self.tap} 0x02")

    def shift_ir(self, value: int, n: int) -> int:
        r = self.tcl(f"irscan {self.tap} 0x{value:x}")
        return int(r, 16) if r and all(ch in "0123456789abcdefABCDEFx" for ch in r) else 0

    def shift_dr(self, value: int, n: int) -> int:
        r = self.tcl(f"drscan {self.tap} {n} 0x{value:x}")
        try:
            return int(r, 16)
        except ValueError as e:
            raise TransportError(f"drscan failed: {r}") from e

    def idle(self, n: int):
        self.tcl(f"runtest {n}")

    def close(self):
        try:
            self.s.close()
        except Exception:
            pass
