"""Memory fault models (golden, Python side).

These are the reference semantics of the simulation-only fault injection used
by the TestCore regression.  The SystemVerilog model
(tb/testcore/models/sftc_fault_mem.sv) implements the same definitions
independently; the regression requires both to agree on detection, first
failing address/data and final memory content for every injected fault.

All faults are *synthetic, enumerated* faults under the single-fault
assumption.  Coverage computed over this population says nothing about the
defect coverage of real silicon (see docs/testcore/fault_coverage.md).
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum


class FaultKind(IntEnum):
    NONE = 0
    SA0 = 1          # cell (a,b) stuck at 0
    SA1 = 2          # cell (a,b) stuck at 1
    TF_UP = 3        # cell cannot make 0->1
    TF_DOWN = 4      # cell cannot make 1->0
    AF_ALIAS = 5     # address a accesses row a2 instead of its own
    AF_MULTI = 6     # access to a also accesses a2 (write both, read AND)
    RD_INV = 7       # read of a returns bit b inverted
    CF_IN = 8        # inversion coupling, aggressor (a,b) transition dir=val&1 -> invert victim (a2,b2)
    CF_ID = 9        # idempotent coupling, transition dir=(val>>1)&1 forces victim to val&1
    CF_ST = 10       # state coupling, aggressor == (val>>1)&1 forces victim to val&1
    INTERMIT = 11    # every param-th read of a flips bit b
    XLAT = 12        # +param cycles on every response (legal, must PASS)
    NO_RSP = 13      # first read of a never answered (protocol fault)
    NO_GNT = 14      # grant withdrawn after param accepted requests
    DUP_RSP = 15     # response of accepted transaction #param duplicated
    AF_NONE = 16     # address a selects no cell
    DLINE = 17       # read data bit b stuck at val&1 for all addresses
    RERR = 18        # read of a returns rsp_err


CELL_FAULTS = {FaultKind.SA0, FaultKind.SA1, FaultKind.TF_UP, FaultKind.TF_DOWN, FaultKind.RD_INV,
               FaultKind.INTERMIT, FaultKind.DLINE, FaultKind.RERR}
ADDR_FAULTS = {FaultKind.AF_ALIAS, FaultKind.AF_MULTI, FaultKind.AF_NONE}
COUPLING_FAULTS = {FaultKind.CF_IN, FaultKind.CF_ID, FaultKind.CF_ST}
PROTOCOL_FAULTS = {FaultKind.XLAT, FaultKind.NO_RSP, FaultKind.NO_GNT, FaultKind.DUP_RSP}


@dataclass
class Fault:
    kind: FaultKind = FaultKind.NONE
    addr: int = 0
    bit: int = 0
    addr2: int = 0
    bit2: int = 0
    val: int = 0
    param: int = 0

    def describe(self) -> str:
        k = self.kind
        if k in (FaultKind.SA0, FaultKind.SA1, FaultKind.TF_UP, FaultKind.TF_DOWN, FaultKind.RD_INV):
            return f"{k.name} @({self.addr},{self.bit})"
        if k in ADDR_FAULTS:
            return f"{k.name} {self.addr}->{self.addr2}"
        if k in COUPLING_FAULTS:
            return f"{k.name} aggr({self.addr},{self.bit}) vict({self.addr2},{self.bit2}) v={self.val}"
        return f"{k.name} a={self.addr} b={self.bit} v={self.val} p={self.param}"


class Lcg:
    """Deterministic PRNG shared (by definition, not by code) with the SV model:
    x = x*1103515245 + 12345 mod 2^32; output (x >> 8) & 0xFFFFFF."""

    def __init__(self, seed: int):
        self.x = (seed ^ 0x5EED0001) & 0xFFFFFFFF

    def next(self) -> int:
        self.x = (self.x * 1103515245 + 12345) & 0xFFFFFFFF
        return (self.x >> 8) & 0xFFFFFF


@dataclass
class ReadOut:
    data: int
    err: bool = False
    no_response: bool = False


class FaultyMemory:
    def __init__(self, width: int, depth: int, fault: Fault | None = None, seed: int = 1):
        self.w, self.d = width, depth
        self.f = fault or Fault()
        rng = Lcg(seed)
        self.cells = [[rng.next() & 1 for _ in range(width)] for _ in range(depth)]
        self.acc = 0
        self.rd_cnt_a = 0
        self.no_rsp_done = False
        self.dup_done = False
        self._dup_flag = False
        self.extra_latency = self.f.param if self.f.kind == FaultKind.XLAT else 0
        self._apply_static()

    # ---------------------------------------------------------------- helpers
    def _apply_static(self):
        f = self.f
        if f.kind == FaultKind.SA0:
            self.cells[f.addr][f.bit] = 0
        elif f.kind == FaultKind.SA1:
            self.cells[f.addr][f.bit] = 1
        elif f.kind == FaultKind.CF_ST and self.cells[f.addr][f.bit] == (f.val >> 1) & 1:
            self.cells[f.addr2][f.bit2] = f.val & 1

    def _write_row(self, row: int, data: int):
        f = self.f
        old = self.cells[row][:]
        new = [(data >> i) & 1 for i in range(self.w)]
        if row == f.addr:
            if f.kind == FaultKind.TF_UP and old[f.bit] == 0 and new[f.bit] == 1:
                new[f.bit] = 0
            if f.kind == FaultKind.TF_DOWN and old[f.bit] == 1 and new[f.bit] == 0:
                new[f.bit] = 1
        self.cells[row] = new
        if row == f.addr and f.kind in (FaultKind.CF_IN, FaultKind.CF_ID) and old[f.bit] != new[f.bit]:
            if f.kind == FaultKind.CF_IN and new[f.bit] == (f.val & 1):
                self.cells[f.addr2][f.bit2] ^= 1
            if f.kind == FaultKind.CF_ID and new[f.bit] == ((f.val >> 1) & 1):
                self.cells[f.addr2][f.bit2] = f.val & 1
        self._apply_static()

    def _row_val(self, row: int) -> int:
        return sum(b << i for i, b in enumerate(self.cells[row]))

    # ---------------------------------------------------------------- port
    def granted(self) -> bool:
        return not (self.f.kind == FaultKind.NO_GNT and self.acc >= self.f.param)

    def write(self, a: int, data: int, write_resp: bool = False):
        f = self.f
        self.acc += 1
        if write_resp:
            self._note_dup()
        if f.kind == FaultKind.AF_NONE and a == f.addr:
            return
        if f.kind == FaultKind.AF_ALIAS and a == f.addr:
            self._write_row(f.addr2, data)
            return
        self._write_row(a, data)
        if f.kind == FaultKind.AF_MULTI and a == f.addr:
            self._write_row(f.addr2, data)

    def read(self, a: int) -> ReadOut:
        f = self.f
        self.acc += 1
        if f.kind == FaultKind.AF_NONE and a == f.addr:
            d = 0
        elif f.kind == FaultKind.AF_ALIAS and a == f.addr:
            d = self._row_val(f.addr2)
        elif f.kind == FaultKind.AF_MULTI and a == f.addr:
            d = self._row_val(a) & self._row_val(f.addr2)
        else:
            d = self._row_val(a)
        if f.kind == FaultKind.RD_INV and a == f.addr:
            d ^= 1 << f.bit
        if f.kind == FaultKind.DLINE:
            d = (d & ~(1 << f.bit)) | ((f.val & 1) << f.bit)
        err = False
        if a == f.addr:
            self.rd_cnt_a += 1
            if f.kind == FaultKind.INTERMIT and f.param > 0 and self.rd_cnt_a % f.param == 0:
                d ^= 1 << f.bit
            if f.kind == FaultKind.RERR:
                err = True
            if f.kind == FaultKind.NO_RSP and not self.no_rsp_done:
                self.no_rsp_done = True
                return ReadOut(d, err, no_response=True)
        self._note_dup()
        return ReadOut(d, err)

    def _note_dup(self):
        if self.f.kind == FaultKind.DUP_RSP and self.acc == self.f.param and not self.dup_done:
            self.dup_done = True
            self._dup_flag = True

    def dup_pending(self) -> bool:
        v, self._dup_flag = self._dup_flag, False
        return v

    def content_hash(self) -> int:
        h = 0
        for r in range(self.d):
            v = self._row_val(r)
            f = 0
            while v:
                f ^= v & 0xFFFFFFFF
                v >>= 32
            h = (h * 31 + f) & 0xFFFFFFFF
        return h
