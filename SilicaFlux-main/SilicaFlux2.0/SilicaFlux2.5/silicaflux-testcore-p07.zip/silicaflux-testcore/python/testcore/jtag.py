"""JTAG layer: TAP state navigation over a bit-level transport, or pass-through
to a TAP-level transport (OpenOCD).  All scans start and end in Run-Test/Idle."""
from __future__ import annotations

from . import spec


class BitBangJtag:
    """TAP operations synthesised as TMS/TDI bit streams (one transport call per scan)."""

    def __init__(self, transport):
        self.t = transport

    def reset(self):
        self.t.shift([1, 1, 1, 1, 1, 0], [0] * 6)          # 5 x TMS=1 -> TLR, then RTI

    def _scan(self, ir: bool, value: int, n: int) -> int:
        pre = [1, 1, 0, 0] if ir else [1, 0, 0]            # RTI->SelDR(->SelIR)->Capture->Shift
        tms = pre + [0] * (n - 1) + [1] + [1, 0]           # last bit -> Exit1, Update, RTI
        tdi = [0] * len(pre) + [(value >> i) & 1 for i in range(n)] + [0, 0]
        o = self.t.shift(tms, tdi)
        cap = o[len(pre):len(pre) + n]
        return sum(b << i for i, b in enumerate(cap))

    def shift_ir(self, value: int, n: int = spec.IR_LEN) -> int:
        return self._scan(True, value, n)

    def shift_dr(self, value: int, n: int) -> int:
        return self._scan(False, value, n)

    def idle(self, n: int):
        if n > 0:
            self.t.shift([0] * n, [0] * n)


def make_jtag(transport):
    return BitBangJtag(transport) if hasattr(transport, "shift") else transport
