"""Host-side TestCore operations (JTAG register protocol, MBIST control,
diagnostics).  Independent of the transport: works over SimTransport (RTL)
and OpenOcdTransport (hardware adapter)."""
from __future__ import annotations

import time
from typing import Optional

from pydantic import BaseModel, Field

from . import spec
from .jtag import make_jtag

R = spec.REGS


class RegAccessError(RuntimeError):
    pass


class FailRecord(BaseModel):
    bank: int
    element: int
    op: int
    walk_bit: int
    address: int
    expected: Optional[int] = None
    observed: Optional[int] = None
    syndrome: int


class MbistResult(BaseModel):
    algorithm: str
    banks_requested: list[int]
    result: str                       # PASS / FAIL / ABORTED / ERROR / NOT_RUN
    banks_tested: list[int]
    banks_failed: list[int]
    fail_count: int
    fail_count_saturated: bool
    first_fail: Optional[FailRecord] = None
    log: list[FailRecord] = Field(default_factory=list)
    log_overflow: bool
    error_flags: list[str]
    cycles: int
    owner_states_after: list[str]
    reinit_required_banks: list[int]
    poll_iterations: int


def _info(v: int) -> dict:
    return {"bank": v & 0xFF, "element": (v >> 8) & 0x7, "op": (v >> 12) & 0x3, "walk_bit": (v >> 16) & 0xFF}


class TestCoreHost:
    def __init__(self, transport, idle_tck: int = 16):
        self.t = transport
        self.j = make_jtag(transport)
        self.idle_tck = idle_tck
        self._ir = None
        self.stats = {"reg_reads": 0, "reg_writes": 0, "busy_retries": 0}

    # ------------------------------------------------------------------ TAP basics
    def tap_reset(self):
        self.j.reset()
        self._ir = spec.IR["IDCODE"]

    def set_ir(self, ir: int):
        if self._ir is None:              # TAP state unknown: synchronise first
            self.tap_reset()
        if self._ir != ir:
            self.j.shift_ir(ir, spec.IR_LEN)
            self._ir = ir

    def read_idcode(self) -> int:
        self.tap_reset()
        return self.j.shift_dr(0, 32) & 0xFFFFFFFF

    def bypass_check(self, pattern: int = 0xA5, n: int = 8) -> bool:
        self.set_ir(spec.IR["BYPASS"])
        out = self.j.shift_dr(pattern, n + 1)
        return (out & 1) == 0 and (out >> 1) == (pattern & ((1 << n) - 1))

    def tc_status(self) -> dict:
        self.set_ir(spec.IR["TC_STATUS"])
        self.j.shift_dr(0, 8)
        self.j.idle(self.idle_tck)
        v = self.j.shift_dr(0, 8)
        return {"bridge_busy": bool(v & 1), "sticky": bool(v & 2), "sysclk_alive": bool(v & 4),
                "sys_in_reset": bool(v & 8), "signature": (v >> 4) & 0xF}

    # ------------------------------------------------------------------ register protocol (TC_REG DR)
    def _scan(self, op: int, addr: int = 0, data: int = 0) -> tuple[str, int, int]:
        v = self.j.shift_dr((op << 44) | ((addr & 0xFFF) << 32) | (data & 0xFFFFFFFF), spec.REG_DR_LEN)
        return spec.REGST.get((v >> 44) & 3, "?"), (v >> 32) & 0xFFF, v & 0xFFFFFFFF

    def _result(self, max_tries: int = 64) -> tuple[str, int, int]:
        op = spec.REGOP["NOP"]
        for i in range(max_tries):
            self.j.idle(self.idle_tck)
            st, a, d = self._scan(op)
            if st != "BUSY":
                return st, a, d
            self.stats["busy_retries"] += 1
            op = spec.REGOP["CLEAR"]               # sticky busy: clear, then capture again
            self.idle_tck = min(self.idle_tck * 2, 4096)
        raise RegAccessError("TC_REG stayed BUSY (system clock stopped or held in reset?)")

    def reg_read(self, addr: int) -> int:
        self.set_ir(spec.IR["TC_REG"])
        self._scan(spec.REGOP["READ"], addr)
        st, a, d = self._result()
        self.stats["reg_reads"] += 1
        if st != "OK" or a != addr:
            raise RegAccessError(f"read 0x{addr:03x}: status {st} addr 0x{a:03x}")
        return d

    def reg_write(self, addr: int, data: int, check: bool = True) -> str:
        self.set_ir(spec.IR["TC_REG"])
        self._scan(spec.REGOP["WRITE"], addr, data)
        st, a, _ = self._result()
        self.stats["reg_writes"] += 1
        if check and (st != "OK" or a != addr):
            raise RegAccessError(f"write 0x{addr:03x}: status {st}")
        return st

    # ------------------------------------------------------------------ identification
    def identify(self) -> dict:
        idc = self.read_idcode()
        rev = self.reg_read(R["R_REVISION"])
        caps = self.reg_read(R["R_CAPS"])
        nb = caps & 0xFF
        banks = []
        for k in range(nb):
            i0 = self.reg_read(R["R_BANK_INFO0"] + 8 * k)
            i1 = self.reg_read(R["R_BANK_INFO0"] + 8 * k + 4)
            banks.append({"bank": k, "width": i0 & 0xFF, "depth": i1 & 0xFFFFFF, "flags": (i0 >> 24) & 0xFF})
        return {"idcode": f"0x{idc:08x}", "idcode_ok": idc == spec.IDCODE, "revision": spec.revision_str(rev),
                "bank_count": nb, "max_width": (caps >> 8) & 0xFF, "log_depth": (caps >> 16) & 0xF,
                "algorithms_compiled": [n for n, v in spec.ALGS.items() if (caps >> 24) >> v & 1],
                "banks": banks}

    # ------------------------------------------------------------------ modes / ownership
    def mode_status(self) -> dict:
        v = self.reg_read(R["R_MODE_STATUS"])
        return {"mode": spec.MODE_NAMES.get(v & 7, str(v & 7)), "busy": bool(v >> 3 & 1),
                "hw_test_en": bool(v >> 4 & 1), "unlocked": bool(v >> 5 & 1), "scan_pin": bool(v >> 6 & 1),
                "pending": spec.MODE_NAMES.get(v >> 8 & 7, "?"), "hw_dbg_en": bool(v >> 31 & 1)}

    def request_mode(self, mode: str, timeout_polls: int = 200) -> dict:
        self.reg_write(R["R_MODE_CTRL"], spec.MODES[mode])
        for _ in range(timeout_polls):
            st = self.mode_status()
            if not st["busy"]:
                return st
        return self.mode_status()

    def unlock(self, key: int = spec.UNLOCK_KEY):
        self.reg_write(R["R_UNLOCK"], key)

    def owner_states(self, nb: int) -> list[str]:
        v = self.reg_read(R["R_OWNER_STATUS"])
        return [spec.OWNER_STATES.get(v >> (4 * k) & 7, "?") for k in range(nb)]

    def error_flags(self) -> list[str]:
        v = self.reg_read(R["R_ERROR_FLAGS"])
        return [n for b, n in spec.ERROR_FLAGS.items() if v >> b & 1]

    def clear_error_flags(self):
        self.reg_write(R["R_ERROR_FLAGS"], 0x7FF)

    # ------------------------------------------------------------------ MBIST
    def mbist_run(self, banks: list[int], algorithm: str = "march_c_minus", bg_checker: bool = False,
                  stop_on_fail: bool = False, scrub: bool = True, max_polls: int = 20000,
                  exit_mode: str = "JTAG_ACCESS", wait=None) -> MbistResult:
        caps = self.reg_read(R["R_CAPS"])
        nb = caps & 0xFF
        mask = sum(1 << b for b in banks)
        self.clear_error_flags()
        self.reg_write(R["R_TEST_CONTROL"], 1 << 2)                       # CLEAR
        self.reg_write(R["R_BANK_MASK"], mask)
        self.unlock()
        st = self.request_mode("MBIST")
        if st["mode"] != "MBIST":
            return self._not_run(algorithm, banks, nb, "mode MBIST refused: " + str(st))
        # wait until every selected bank is owned by test (quiesce + drain completed)
        for _ in range(200):
            own = self.owner_states(nb)
            if all(own[b] == "TEST_ACTIVE" for b in banks):
                break
            if any(own[b] == "FAULT" for b in banks):
                break
        ctrl = (1 << 0) | (spec.ALGS[algorithm] << 4) | (int(bg_checker) << 8) | (int(stop_on_fail) << 9) | \
               (int(scrub) << 10)
        self.reg_write(R["R_TEST_CONTROL"], ctrl)
        if "ILLEGAL_START" in self.error_flags():
            res = self._not_run(algorithm, banks, nb, "START refused (bank not owned / not permitted)")
            self.request_mode(exit_mode)
            return res
        polls = 0
        while polls < max_polls:
            polls += 1
            if wait:
                wait()
            s = self.reg_read(R["R_TEST_STATUS"])
            if not (s & 1) and ((s >> 1 & 1) or (s >> 5 & 1) or polls > 2):
                break
        res = self._collect(algorithm, banks, nb, polls)
        self.request_mode(exit_mode)
        for _ in range(100):
            own = self.owner_states(nb)
            if all(o in ("NORMAL", "FAULT") for o in own):
                break
        res.owner_states_after = own
        flags = self.error_flags()
        res.error_flags = flags
        return res

    def _not_run(self, alg, banks, nb, why) -> MbistResult:
        return MbistResult(algorithm=alg, banks_requested=banks, result="NOT_RUN", banks_tested=[], banks_failed=[],
                           fail_count=0, fail_count_saturated=False, log_overflow=False,
                           error_flags=self.error_flags() + [why], cycles=0, owner_states_after=self.owner_states(nb),
                           reinit_required_banks=[], poll_iterations=0)

    def _collect(self, alg, banks, nb, polls) -> MbistResult:
        last = self.reg_read(R["R_LAST_RESULT"]) & 7
        caps = self.reg_read(R["R_CAPS"])
        words = ((caps >> 8 & 0xFF) + 31) // 32
        tested = self.reg_read(R["R_BANKS_TESTED"])
        failed = self.reg_read(R["R_BANKS_FAILED"])
        cnt = self.reg_read(R["R_FAIL_COUNT"])
        ef = self.reg_read(R["R_ERROR_FLAGS"])
        ffi = self.reg_read(R["R_FF_INFO"])
        first = None
        if ffi >> 31:
            rd = lambda base: sum(self.reg_read(base + 4 * i) << (32 * i) for i in range(words))
            exp, obs = rd(R["R_FF_EXP0"]), rd(R["R_FF_OBS0"])
            first = FailRecord(**_info(ffi), address=self.reg_read(R["R_FF_ADDR"]), expected=exp, observed=obs,
                               syndrome=exp ^ obs)
        log = []
        while True:
            ls = self.reg_read(R["R_LOG_STATUS"])
            if ls & 0xFF == 0:
                break
            li = self.reg_read(R["R_LOG_INFO"])
            la = self.reg_read(R["R_LOG_ADDR"])
            sy = sum(self.reg_read(R["R_LOG_SYND0"] + 4 * i) << (32 * i) for i in range(words))
            log.append(FailRecord(**_info(li), address=la, syndrome=sy))
            self.reg_write(R["R_LOG_POP"], 1)
        ovf = bool(self.reg_read(R["R_LOG_STATUS"]) >> 8 & 1)
        return MbistResult(algorithm=alg, banks_requested=banks, result=spec.RESULTS.get(last, str(last)),
                           banks_tested=[b for b in range(nb) if tested >> b & 1],
                           banks_failed=[b for b in range(nb) if failed >> b & 1], fail_count=cnt,
                           fail_count_saturated=bool(ef >> spec.c("EF_CNT_OVF") & 1), first_fail=first, log=log,
                           log_overflow=ovf, error_flags=[], cycles=self.reg_read(R["R_CYCLES"]),
                           owner_states_after=[], reinit_required_banks=[], poll_iterations=polls)

    # ------------------------------------------------------------------ diagnostics
    def diagnostics(self) -> dict:
        out = {}
        for name, addr in sorted(spec.REGS.items(), key=lambda x: x[1]):
            if name in ("R_UNLOCK", "R_LOG_POP", "R_BANK_INFO0") or name.endswith("0") and "INFO" in name:
                continue
            try:
                out[name] = f"0x{self.reg_read(addr):08x}"
            except RegAccessError as e:
                out[name] = f"ERROR ({e})"
        out["tc_status"] = self.tc_status()
        return out
