"""MBIST functional + fault-injection regression driver.

    python -m testcore.sim.campaign [--quick] [--out reports/testcore/mbist]

Writes per-configuration evidence (case file, raw simulator results, logs,
per-case comparison) and a summary JSON consumed by the coverage report.
Exit status is non-zero if any case disagrees with the golden model or any
embedded RTL assertion fired.
"""
from __future__ import annotations

import argparse
import json
import platform
import random
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path

from ..fault_models import Fault, FaultKind
from ..mbist import ALG_NAMES, BankCfg, nominal_ops, cycle_formula
from .mbist_regress import (CTL_ABORT, CTL_BADALG, CTL_BUSY, CTL_EMPTY, CTL_OWNLOSS, CTL_REPEAT, CTL_RESET,
                            CTL_TEN, CTL_UNOWNED, ROOT, Case, TbConfig, check_case, compile_tb,
                            fault_class, fault_population, run_sim)

ALGS = list(range(6))


def tool_versions() -> dict:
    def v(cmd):
        try:
            return subprocess.run(cmd, capture_output=True, text=True).stdout.splitlines()[0].strip()
        except Exception as e:  # pragma: no cover
            return f"unavailable ({e})"
    return {"iverilog": v(["iverilog", "-V"]), "python": platform.python_version()}


def configs(quick: bool) -> list[TbConfig]:
    c = [
        TbConfig("w8d16_l1", [BankCfg(8, 16)]),
        TbConfig("w32d256_l1", [BankCfg(32, 256)]),
        TbConfig("w13d37_np2", [BankCfg(13, 37)]),
        TbConfig("w16d24_l3", [BankCfg(16, 24)], lmin=3, lmax=3),
        TbConfig("w8d20_rand", [BankCfg(8, 20)], lmin=1, lmax=5, gnt=60, timeout=512),
        TbConfig("w8d16_wresp", [BankCfg(8, 16, write_resp=True)], lmin=2, lmax=2),
        TbConfig("multibank4", [BankCfg(32, 64), BankCfg(8, 17), BankCfg(16, 33, write_resp=True),
                                BankCfg(36, 8)], lmin=1, lmax=1),
        TbConfig("pipe2", [BankCfg(16, 32), BankCfg(9, 11)], lmin=2, lmax=2, pipe_req=1, pipe_rsp=1),
        TbConfig("w128d8", [BankCfg(128, 8)]),
        TbConfig("log0", [BankCfg(8, 16)], log_depth=0),
    ]
    return c[:3] if quick else c


def gen_cases(cfg: TbConfig, rng: random.Random, quick: bool) -> tuple[list[Case], list[Case]]:
    """Returns (traced cases, untraced fault-campaign cases)."""
    nb = len(cfg.banks)
    full_mask = (1 << nb) - 1
    traced: list[Case] = []
    camp: list[Case] = []
    cid = [1]

    def add(lst, **kw):
        kw.setdefault("seed", rng.randrange(1, 1 << 30))
        lst.append(Case(id=cid[0], **kw))
        cid[0] += 1

    # fault-free: every algorithm, both backgrounds, with/without scrub, all banks
    for alg in ALGS:
        for bg in (0, 1):
            add(traced, alg=alg, bg=bg, mask=full_mask, tag="fault-free")
        add(traced, alg=alg, scrub=0, mask=full_mask, tag="fault-free no-scrub")
    if nb > 1:
        for m in range(1, full_mask + 1):
            add(traced, alg=0, mask=m, tag="bank-mask")
    # per-bank sampled faults with trace (first-fail data + trace verified)
    for b, bank in enumerate(cfg.banks):
        pop = fault_population(bank.width, bank.depth, random.Random(rng.randrange(1 << 30)), pair_samples=12)
        sample = rng.sample(pop, min(len(pop), 40 if not quick else 12))
        for f in sample:
            add(traced, alg=rng.choice(ALGS), bg=rng.randrange(2), mask=full_mask, fbank=b, fault=f, tag="fault")
        # stuck-at in the final legal address / bit, first address
        for (a, bit) in ((bank.depth - 1, bank.width - 1), (0, 0)):
            for k in (FaultKind.SA0, FaultKind.SA1):
                add(traced, alg=0, mask=full_mask, fbank=b, fault=Fault(k, a, bit), tag="boundary")
        # stop-on-fail
        add(traced, alg=0, sof=1, mask=full_mask, fbank=b, fault=Fault(FaultKind.SA1, bank.depth // 2, 0),
            tag="stop-on-fail")
        # protocol faults
        add(traced, alg=0, mask=full_mask, fbank=b, fault=Fault(FaultKind.XLAT, param=3), tag="extra-latency")
        add(traced, alg=1, mask=full_mask, fbank=b, fault=Fault(FaultKind.NO_RSP, addr=bank.depth // 3),
            tag="no-response")
        add(traced, alg=1, mask=full_mask, fbank=b, fault=Fault(FaultKind.NO_GNT, param=bank.depth + 3),
            tag="no-grant")
        add(traced, alg=1, mask=full_mask, fbank=b, fault=Fault(FaultKind.DUP_RSP, param=bank.depth + 2),
            tag="dup-response")
    # control cases
    for p in (0, 3, 17, 60):
        add(traced, alg=0, mask=full_mask, ctl=CTL_ABORT, cparam=p, tag="abort")
        add(traced, alg=0, mask=full_mask, ctl=CTL_RESET, cparam=p, tag="reset-during-test")
        add(traced, alg=0, mask=full_mask, ctl=CTL_TEN, cparam=p, tag="test-enable-drop")
    add(traced, alg=0, mask=full_mask, ctl=CTL_OWNLOSS, cparam=10, tag="ownership-loss")
    add(traced, alg=0, mask=full_mask, ctl=CTL_EMPTY, tag="illegal-start: empty mask")
    add(traced, alg=0, mask=full_mask, ctl=CTL_UNOWNED, tag="illegal-start: bank not owned")
    add(traced, alg=9, mask=full_mask, ctl=CTL_BADALG, tag="illegal-start: unknown algorithm")
    add(traced, alg=0, mask=full_mask, ctl=CTL_BUSY, cparam=5, tag="illegal-start: busy")
    add(traced, alg=1, mask=full_mask, ctl=CTL_REPEAT, tag="repeated execution")

    # exhaustive/enumerated campaign: first configuration only (the coverage population)
    if cfg.name == "w8d16_l1":
        bank = cfg.banks[0]
        pop = fault_population(bank.width, bank.depth, random.Random(20261106),
                               pair_samples=40 if quick else 120)
        for alg in ALGS:
            for f in pop:
                add(camp, alg=alg, mask=1, fault=f, tag="campaign")
    return traced, camp


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--out", default=str(ROOT / "reports" / "testcore" / "mbist"))
    ap.add_argument("--only", default="")
    a = ap.parse_args(argv)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    build = ROOT / "build"
    build.mkdir(exist_ok=True)
    rng = random.Random(0x5F07)          # deterministic seed for the whole regression
    summary = {"evidence_class": "FUNCTIONAL SIMULATION + FAULT-INJECTION SIMULATION (RTL, Icarus Verilog)",
               "tools": tool_versions(), "seed": "0x5F07", "configs": {}, "coverage": {}}
    total_fail = 0
    t_all = time.time()
    for cfg in configs(a.quick):
        if a.only and cfg.name != a.only:
            continue
        t0 = time.time()
        work = out / cfg.name
        work.mkdir(parents=True, exist_ok=True)
        vvp = compile_tb(cfg, build)
        traced, camp = gen_cases(cfg, rng, a.quick)
        cinfo = {"banks": [vars(b) for b in cfg.banks], "lat": [cfg.lmin, cfg.lmax], "gnt_pct": cfg.gnt,
                 "pipe": [cfg.pipe_req, cfg.pipe_rsp], "log_depth": cfg.log_depth,
                 "deterministic_timing": cfg.deterministic}
        fails = []
        asserts = 0
        for label, cases, trace in (("traced", traced, True), ("campaign", camp, False)):
            if not cases:
                continue
            wd = work / label
            wd.mkdir(exist_ok=True)
            res, tr, cm, log = run_sim(vvp, cases, wd, trace)
            asserts += log.count("SFTC_ASSERTION_FAILED")
            if "TB_MBIST_DONE" not in log:
                fails.append({"case": None, "errors": ["simulation did not complete"]})
            per_case = []
            for c in cases:
                errs = check_case(cfg, c, res.get(c.id), tr.get(c.id, []) if trace else None,
                                  cm.get(c.id, []) if trace else None)
                r = res.get(c.id, {})
                per_case.append({"id": c.id, "tag": c.tag, "alg": ALG_NAMES.get(c.alg, str(c.alg)),
                                 "fault": c.fault.describe(), "fault_kind": c.fault.kind.name,
                                 "bank": c.fbank, "rtl_result": r.get("result"),
                                 "detected": r.get("fail") == "1" or r.get("result") in ("2", "4"),
                                 "cycles": r.get("cycles"), "errors": errs})
                if errs:
                    fails.append({"case": c.id, "tag": c.tag, "fault": c.fault.describe(), "errors": errs})
            (wd / "compare.json").write_text(json.dumps(per_case, indent=1))
            if label == "campaign":
                cov = defaultdict(lambda: defaultdict(lambda: [0, 0]))
                for pc, c in zip(per_case, cases):
                    cls = fault_class(c.fault.kind)
                    cov[pc["alg"]][cls][1] += 1
                    if pc["detected"]:
                        cov[pc["alg"]][cls][0] += 1
                summary["coverage"][cfg.name] = {alg: {k: {"detected": v[0], "injected": v[1]}
                                                       for k, v in d.items()} for alg, d in cov.items()}
            if label == "traced":
                # measured cycles of fault-free runs
                meas = {}
                for pc, c in zip(per_case, cases):
                    if pc["tag"] == "fault-free" and c.bg == 0 and pc["cycles"]:
                        meas[pc["alg"]] = int(pc["cycles"])
                cinfo["measured_cycles_fault_free"] = meas
                if cfg.deterministic and len(cfg.banks) == 1:
                    b = cfg.banks[0]
                    cinfo["formula_cycles"] = {ALG_NAMES[x]: cycle_formula(x, b.depth, b.width, cfg.lmin, True,
                                                                           b.write_resp) for x in ALGS}
                    cinfo["nominal_ops"] = {ALG_NAMES[x]: nominal_ops(x, b.depth, b.width) for x in ALGS}
        cinfo.update({"cases": len(traced) + len(camp), "traced_cases": len(traced),
                      "campaign_cases": len(camp), "mismatches": len(fails), "rtl_assertions_failed": asserts,
                      "status": "PASS" if not fails and asserts == 0 else "FAIL",
                      "seconds": round(time.time() - t0, 1)})
        if fails:
            (work / "FAILURES.json").write_text(json.dumps(fails[:200], indent=1))
        summary["configs"][cfg.name] = cinfo
        total_fail += len(fails) + asserts
        print(f"[mbist] {cfg.name:14s} cases={cinfo['cases']:6d} mismatches={len(fails):4d} "
              f"assert={asserts} {cinfo['status']} ({cinfo['seconds']} s)", flush=True)
        for f in fails[:5]:
            print("   ", f)
    summary["status"] = "PASS" if total_fail == 0 else "FAIL"
    summary["seconds"] = round(time.time() - t_all, 1)
    (out / "summary.json").write_text(json.dumps(summary, indent=1))
    print(f"[mbist] overall {summary['status']}")
    return 0 if total_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
