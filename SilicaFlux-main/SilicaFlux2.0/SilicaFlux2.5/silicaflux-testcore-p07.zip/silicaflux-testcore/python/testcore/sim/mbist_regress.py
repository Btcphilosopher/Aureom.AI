"""RTL-vs-golden MBIST regression (functional + fault-injection simulation).

For every testbench configuration this module
  1. compiles tb_mbist with Icarus Verilog (scripts/iv_mbist.sh),
  2. writes a case file (fault-free, fault-injection, control cases),
  3. runs the simulation once for all cases (vvp),
  4. predicts every case with the independent golden model,
  5. compares result record, transaction trace, compare events, failure log,
     final memory content and (for deterministic timing) the cycle count.

Evidence class: FUNCTIONAL SIMULATION and FAULT-INJECTION SIMULATION.
"""
from __future__ import annotations

import json
import os
import random
import re
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path

from ..fault_models import Fault, FaultKind, FaultyMemory, CELL_FAULTS, ADDR_FAULTS, COUPLING_FAULTS
from ..mbist import (ALG_NAMES, BankCfg, GoldenMbist, RES_ABORTED, RES_ERROR, RES_FAIL, RES_PASS,
                     nominal_ops)

ROOT = Path(__file__).resolve().parents[3]

CTL_NONE, CTL_ABORT, CTL_RESET, CTL_EMPTY, CTL_BUSY, CTL_TEN, CTL_UNOWNED, CTL_BADALG, CTL_OWNLOSS, \
    CTL_REPEAT = 0, 100, 101, 102, 103, 104, 105, 106, 107, 109


@dataclass
class TbConfig:
    name: str
    banks: list[BankCfg]
    lmin: int = 1
    lmax: int = 1
    gnt: int = 100
    pipe_req: int = 0
    pipe_rsp: int = 0
    log_depth: int = 4
    timeout: int = 256

    @property
    def deterministic(self) -> bool:
        return self.lmin == self.lmax and self.gnt >= 100 and not self.pipe_req and not self.pipe_rsp

    def defines(self) -> list[str]:
        maxw = max(b.width for b in self.banks)
        maxd = max(b.depth for b in self.banks)
        d = [f"-DTB_BANKS={len(self.banks)}", f"-DTB_MAXW={maxw}", f"-DTB_MAXD={maxd}",
             f"-DTB_LMIN={self.lmin}", f"-DTB_LMAX={self.lmax}", f"-DTB_GNT={self.gnt}",
             f"-DTB_PIPE_REQ={self.pipe_req}", f"-DTB_PIPE_RSP={self.pipe_rsp}",
             f"-DTB_LOG={self.log_depth}", f"-DTB_TMO={self.timeout}"]
        wresp = 0
        for k, b in enumerate(self.banks):
            d += [f"-DTB_W{k}={b.width}", f"-DTB_D{k}={b.depth}"]
            if k:
                d.append(f"-DTB_HAS_B{k}")
            if b.write_resp:
                wresp |= 1 << k
        d.append(f"-DTB_WRESP={wresp}")
        return d


@dataclass
class Case:
    id: int
    alg: int
    bg: int = 0
    sof: int = 0
    scrub: int = 1
    mask: int = 1
    fbank: int = 0
    fault: Fault = field(default_factory=Fault)
    ctl: int = 0
    cparam: int = 0
    seed: int = 1
    tag: str = ""

    def line(self) -> str:
        f = self.fault
        return " ".join(str(int(x)) for x in (self.id, self.alg, self.bg, self.sof, self.scrub, self.mask,
                                             self.fbank, f.kind, f.addr, f.bit, f.addr2, f.bit2, f.val,
                                             f.param, self.ctl, self.cparam, self.seed))


# ------------------------------------------------------------------ fault populations
def fault_population(width: int, depth: int, rng: random.Random, pair_samples: int = 120) -> list[Fault]:
    """Enumerated synthetic fault population (documented in docs/testcore/fault_coverage.md)."""
    pop: list[Fault] = []
    for a in range(depth):
        for b in range(width):
            pop += [Fault(FaultKind.SA0, a, b), Fault(FaultKind.SA1, a, b),
                    Fault(FaultKind.TF_UP, a, b), Fault(FaultKind.TF_DOWN, a, b),
                    Fault(FaultKind.RD_INV, a, b)]
    for a in range(depth):
        pop.append(Fault(FaultKind.AF_NONE, a))
        for a2 in range(depth):
            if a2 != a:
                pop += [Fault(FaultKind.AF_ALIAS, a, 0, a2), Fault(FaultKind.AF_MULTI, a, 0, a2)]
    for b in range(width):
        pop += [Fault(FaultKind.DLINE, 0, b, val=0), Fault(FaultKind.DLINE, 0, b, val=1)]
    for a in range(depth):
        pop.append(Fault(FaultKind.RERR, a))
    # coupling faults: deterministic sample of aggressor/victim cell pairs covering
    # inter-word (victim above / below aggressor) and intra-word pairs
    def pairs(n):
        out = []
        for i in range(n):
            a = rng.randrange(depth)
            b = rng.randrange(width)
            mode = i % 3
            if mode == 0 and width > 1:            # intra-word
                a2, b2 = a, (b + 1 + rng.randrange(width - 1)) % width
            elif mode == 1:                         # victim at higher address
                a2 = (a + 1 + rng.randrange(depth - 1)) % depth
                a2, a = max(a, a2), min(a, a2)
                b2 = rng.randrange(width)
            else:                                   # victim at lower address
                a2 = (a + 1 + rng.randrange(depth - 1)) % depth
                a2, a = min(a, a2), max(a, a2)
                b2 = rng.randrange(width)
            if a2 == a and b2 == b:
                b2 = (b + 1) % width
            out.append((a, b, a2, b2))
        return out
    for (a, b, a2, b2) in pairs(pair_samples):
        for v in (0, 1):
            pop.append(Fault(FaultKind.CF_IN, a, b, a2, b2, v))
    for (a, b, a2, b2) in pairs(pair_samples):
        for v in range(4):
            pop.append(Fault(FaultKind.CF_ID, a, b, a2, b2, v))
    for (a, b, a2, b2) in pairs(pair_samples):
        for v in range(4):
            pop.append(Fault(FaultKind.CF_ST, a, b, a2, b2, v))
    for i in range(max(8, depth // 2)):
        pop.append(Fault(FaultKind.INTERMIT, rng.randrange(depth), rng.randrange(width), param=2 + i % 3))
    return pop


def fault_class(k: FaultKind) -> str:
    if k in (FaultKind.SA0, FaultKind.SA1):
        return "stuck-at"
    if k in (FaultKind.TF_UP, FaultKind.TF_DOWN):
        return "transition"
    if k in ADDR_FAULTS:
        return "address-decoder"
    if k in COUPLING_FAULTS:
        return k.name.lower().replace("_", "-") + " coupling"
    if k == FaultKind.RD_INV:
        return "read-path inversion"
    if k == FaultKind.DLINE:
        return "data-line stuck"
    if k == FaultKind.INTERMIT:
        return "intermittent read"
    if k == FaultKind.RERR:
        return "memory error flag"
    return k.name


# ------------------------------------------------------------------ simulation
def compile_tb(cfg: TbConfig, build: Path) -> Path:
    out = build / f"tb_mbist_{cfg.name}.vvp"
    cmd = [str(ROOT / "scripts" / "iv_mbist.sh"), str(out)] + cfg.defines()
    p = subprocess.run(cmd, capture_output=True, text=True)
    (build / f"tb_mbist_{cfg.name}.compile.log").write_text(" ".join(cmd) + "\n" + p.stdout + p.stderr)
    if p.returncode != 0 or not out.exists():
        raise RuntimeError(f"compile failed for {cfg.name}: {p.stdout}{p.stderr}")
    return out


RES_RE = re.compile(r"(\w+)=(\S+)")


def parse_results(path: Path) -> dict[int, dict]:
    out = {}
    for ln in path.read_text().splitlines():
        if not ln.startswith("R "):
            continue
        d = dict(RES_RE.findall(ln))
        out[int(d["id"])] = d
    return out


def parse_trace(path: Path) -> tuple[dict[int, list], dict[int, list]]:
    tr: dict[int, list] = {}
    cm: dict[int, list] = {}
    if not path.exists():
        return tr, cm
    for ln in path.read_text().splitlines():
        p = ln.split()
        if p[0] == "T":
            tr.setdefault(int(p[1]), []).append((int(p[2]), p[3] == "R", int(p[4]), int(p[5], 16)))
        elif p[0] == "C":
            cm.setdefault(int(p[1]), []).append((int(p[2]), int(p[3]), int(p[4], 16), int(p[5], 16),
                                                 int(p[6])))
    return tr, cm


def run_sim(vvp: Path, cases: list[Case], work: Path, trace: bool) -> tuple[dict, dict, dict, str]:
    cf = work / "cases.txt"
    rf = work / "results.txt"
    tf = work / "trace.txt"
    cf.write_text("\n".join(c.line() for c in cases) + "\n")
    cmd = ["vvp", "-n", str(vvp), f"+cases={cf}", f"+results={rf}"]
    if trace:
        cmd.append(f"+trace={tf}")
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
    log = p.stdout + p.stderr
    (work / "sim.log").write_text(" ".join(cmd) + "\n" + log)
    res = parse_results(rf) if rf.exists() else {}
    tr, cm = parse_trace(tf) if trace else ({}, {})
    return res, tr, cm, log


# ------------------------------------------------------------------ checking
def predict(cfg: TbConfig, c: Case):
    mems = []
    for k, b in enumerate(cfg.banks):
        f = c.fault if k == c.fbank else Fault()
        mems.append(FaultyMemory(b.width, b.depth, f, c.seed + k))
    g = GoldenMbist(cfg.banks, log_depth=cfg.log_depth)
    r = g.run(mems, c.alg, c.mask, bool(c.bg), bool(c.sof), bool(c.scrub), latency=cfg.lmin)
    return r, mems


def hexi(s: str) -> int:
    return int(s, 16)


def check_case(cfg: TbConfig, c: Case, rtl: dict, trace, comps) -> list[str]:
    errs: list[str] = []
    if rtl is None:
        return ["no result record from simulation"]
    res = int(rtl["result"])
    ef = hexi(rtl["ef"])
    # -------------------------------------------------- control cases: property checks
    if c.ctl in (CTL_EMPTY, CTL_UNOWNED, CTL_BADALG):
        if not ef & (1 << 2):
            errs.append("START not refused")
        if int(rtl["done"]) or res not in (0,):
            errs.append(f"refused start must not produce a result (result={res})")
        return errs
    if c.ctl == CTL_ABORT:
        if res != RES_ABORTED:
            errs.append(f"expected ABORTED, got {res}")
        if c.scrub and c.fault.kind == FaultKind.NONE:
            # every bank the engine touched was scrubbed: its content is all-zero
            sc = hexi(rtl["scrubbed"])
            hashes = [hexi(h) for h in rtl["mem"].strip(",").split(",")]
            for k, b in enumerate(cfg.banks):
                if sc >> k & 1 and hashes[k] != zero_hash(b):
                    errs.append(f"bank {k} not zero after abort scrub")
            if sc == 0:
                errs.append("no bank scrubbed after abort")
        return errs
    if c.ctl in (CTL_OWNLOSS, CTL_TEN):
        if res != RES_ABORTED:
            errs.append(f"expected ABORTED on ownership/permission loss, got {res}")
        if hexi(rtl["scrubbed"]):
            errs.append("bank scrubbed after ownership/permission loss (must not touch the memory)")
        return errs
    if c.ctl == CTL_BUSY:
        if not int(rtl["refused2"]):
            errs.append("second START while busy not refused")
        # first run must complete normally
    if c.ctl == CTL_RESET:
        if res != RES_PASS:
            errs.append(f"run after mid-test reset did not pass (result={res})")
        hashes = [hexi(h) for h in rtl["mem"].strip(",").split(",")]
        for k, b in enumerate(cfg.banks):
            if c.mask >> k & 1 and hashes[k] != zero_hash(b):
                errs.append(f"bank {k} not re-initialised after rerun")
        return errs
    # -------------------------------------------------- golden comparison
    g, mems = predict(cfg, c)
    if c.ctl == CTL_REPEAT:
        if int(rtl["res2"]) != g.result:
            errs.append(f"first of repeated runs: result {rtl['res2']} != {g.result}")
        if cfg.deterministic and int(rtl["cyc2"]) != int(rtl["cycles"]):
            errs.append("repeated runs took different cycle counts")
        g, mems = predict(cfg, c)   # second run, memory re-predicted from scratch is not exact; check result only
        if res != g.result:
            errs.append(f"second of repeated runs: result {res} != {g.result}")
        return errs
    if g.error:
        if res != RES_ERROR or not int(rtl["err"]):
            errs.append(f"expected ERROR (protocol fault), got result={res}")
        if not ef & 1:
            errs.append("timeout flag not set")
        return errs
    if res != g.result:
        errs.append(f"result {res} != golden {g.result}")
    if int(rtl["fail"]) != int(g.fail):
        errs.append("fail flag mismatch")
    if int(rtl["cnt"]) != g.fail_count:
        errs.append(f"fail_count {rtl['cnt']} != {g.fail_count}")
    if int(rtl["ffv"]) != int(g.first is not None):
        errs.append("first-fail valid mismatch")
    if g.first is not None:
        for k, key in (("ffinfo", "info"), ("ffaddr", "addr"), ("ffexp", "exp"), ("ffobs", "obs")):
            if hexi(rtl[k]) != g.first[key]:
                errs.append(f"{k} {rtl[k]} != golden {g.first[key]:x}")
    logs = [] if rtl["logs"] == "-" else [tuple(int(x, 16) for x in e.split(":"))
                                         for e in rtl["logs"].lstrip("-").strip(",").split(",") if e]
    if logs != [tuple(x) for x in g.log]:
        errs.append(f"failure FIFO {logs[:3]} != golden {g.log[:3]}")
    if int(rtl["logovf"]) != int(g.log_ovf):
        errs.append("log overflow flag mismatch")
    for k, key in (("tested", "tested"), ("failed", "failed"), ("scrubbed", "scrubbed")):
        if hexi(rtl[k]) != getattr(g, key):
            errs.append(f"{k} mask {rtl[k]} != {getattr(g, key):x}")
    hashes = [hexi(h) for h in rtl["mem"].strip(",").split(",")]
    for k in range(len(cfg.banks)):
        if hashes[k] != mems[k].content_hash():
            errs.append(f"final memory content of bank {k} differs from golden")
    if g.nspur and res != RES_ERROR:
        errs.append("duplicated response did not make the run INCONCLUSIVE")
    if (g.nspur > 0) != bool(ef & 2):
        errs.append(f"spurious-response flag {bool(ef & 2)} != golden {g.nspur > 0}")
    if int(rtl["nmerr"]) != g.nmerr:
        errs.append(f"memory-error responses {rtl['nmerr']} != {g.nmerr}")
    if trace is not None:
        gt = [(o.bank, o.is_read, o.addr, o.data) for o in g.trace]
        if trace != gt:
            n = next((i for i, (x, y) in enumerate(zip(trace, gt)) if x != y), min(len(trace), len(gt)))
            errs.append(f"transaction trace differs at op {n}: rtl={trace[n:n+1]} golden={gt[n:n+1]} "
                        f"(len {len(trace)} vs {len(gt)})")
        if comps is not None and comps != g.compares:
            errs.append("compare events differ from golden")
    if cfg.deterministic and not c.sof and c.fault.kind not in (FaultKind.DUP_RSP,) and g.cycles is not None:
        if int(rtl["cycles"]) != g.cycles:
            errs.append(f"cycles {rtl['cycles']} != modelled {g.cycles}")
    return errs


_ZH: dict = {}


def zero_hash(b: BankCfg) -> int:
    key = (b.width, b.depth)
    if key not in _ZH:
        m = FaultyMemory(b.width, b.depth, Fault(), 0)
        for a in range(b.depth):
            m.cells[a] = [0] * b.width
        _ZH[key] = m.content_hash()
    return _ZH[key]
