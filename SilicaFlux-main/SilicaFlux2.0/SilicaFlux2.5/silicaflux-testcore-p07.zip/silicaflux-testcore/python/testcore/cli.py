"""SilicaFlux TestCore host CLI.

    python -m testcore scan        [--transport hw|sim]
    python -m testcore mbist       --bank all --algorithm march_c_minus [--run-dir DIR]
    python -m testcore diagnostics
    python -m testcore report      --run-dir reports/test_run
    python -m testcore svf         --bank all --algorithm march_c_minus --out mbist.svf
    python -m testcore bringup     --run-dir DIR

--transport hw (default) connects to an OpenOCD TCL server (--host/--port).
If none is reachable the CLI prints HARDWARE NOT AVAILABLE, writes a BLOCKED
record and exits with status 3 -- it never reports a passing silicon test.
--transport sim runs the same flow against the RTL (tb_testcore_sys); every
record is then marked evidence_class = SIMULATION.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from . import __version__, spec
from .host import TestCoreHost
from .mbist import cycle_formula
from .patterns import mbist_production_pattern
from .report import Evidence, Status, StepRecord, TestRecord, summarize
from .transports import HardwareNotAvailable

HW_NA = "HARDWARE NOT AVAILABLE"


def _open(args):
    if args.transport == "sim":
        from .transports.sim import SimTransport
        t = SimTransport(clk_half=args.clk_half, tck_half=args.tck_half)
        for k in range(4):
            t.set_pin("traffic", 1 if args.sim_traffic else 0, k)
        for f in args.sim_fault or []:
            b, kind, a, bit = (int(x) for x in f.split(":"))
            t.inject_fault(b, kind, a, bit)
        return t, Evidence.SIMULATION
    from .transports.openocd import OpenOcdTransport
    ev = {"packaged": Evidence.PACKAGED_SILICON, "wafer": Evidence.WAFER_PROBE, "fpga": Evidence.FPGA,
          "sim-bridge": Evidence.SIMULATION}[args.evidence]
    return OpenOcdTransport(args.host, args.port), ev


def _blocked(args, why: str) -> int:
    print(HW_NA)
    print(f"  reason: {why}")
    if getattr(args, "run_dir", None):
        rec = TestRecord(evidence_class=Evidence.PACKAGED_SILICON, design_version=args.design,
                         steps=[StepRecord(name=args.cmd, status=Status.BLOCKED, detail={"reason": why})],
                         notes=[HW_NA]).finalize()
        rec.write(Path(args.run_dir))
        print(f"  BLOCKED record written to {args.run_dir}")
    return 3


def cmd_scan(h: TestCoreHost, args, ev) -> dict:
    info = h.identify()
    info["bypass_ok"] = h.bypass_check()
    info["tc_status"] = h.tc_status()
    info["mode"] = h.mode_status()
    print(json.dumps(info, indent=1))
    return info


def cmd_mbist(h: TestCoreHost, args, ev):
    info = h.identify()
    nb = info["bank_count"]
    banks = list(range(nb)) if args.bank == "all" else [int(b) for b in args.bank.split(",")]
    algos = list(spec.ALGS) if args.algorithm == "all" else args.algorithm.split(",")
    rec = TestRecord(evidence_class=ev, design_version=args.design, testcore_rtl_revision=info["revision"],
                     test_configuration={"banks": banks, "algorithms": algos, "bg_checker": args.bg_checker,
                                         "stop_on_fail": args.stop_on_fail, "scrub": not args.no_scrub},
                     tck_hz=(1e9 / (2 * args.tck_half)) if args.transport == "sim" else None,
                     test_clock_hz=(1e9 / (2 * args.clk_half)) if args.transport == "sim" else None)
    rec.steps.append(StepRecord(name="jtag_idcode", status=Status.PASS if info["idcode_ok"] else Status.FAIL,
                                detail={"idcode": info["idcode"]}))
    for alg in algos:
        t0 = time.time()
        r = h.mbist_run(banks, alg, args.bg_checker, args.stop_on_fail, not args.no_scrub)
        st = {"PASS": Status.PASS, "FAIL": Status.FAIL, "NOT_RUN": Status.BLOCKED}.get(r.result, Status.INCONCLUSIVE)
        rec.steps.append(StepRecord(name=f"mbist_{alg}", status=st, detail=r.model_dump(), duration_s=time.time() - t0))
        rec.mbist.append({"algorithm": alg, "result": r.result, "cycles": r.cycles, "banks_failed": r.banks_failed,
                          "fail_count": r.fail_count, "modelled_cycles": {b: cycle_formula(
                              spec.ALGS[alg], info["banks"][b]["depth"], info["banks"][b]["width"], 1,
                              not args.no_scrub, False, nb) for b in banks}})
        rec.failure_count += r.fail_count
        if r.first_fail:
            rec.failure_locations.append(r.first_fail.model_dump())
        rec.failure_locations += [x.model_dump() for x in r.log]
        print(f"{alg:18s} {r.result:8s} cycles={r.cycles:8d} failed_banks={r.banks_failed} fails={r.fail_count}"
              + (f" first={r.first_fail.model_dump()}" if r.first_fail else ""))
    if ev == Evidence.SIMULATION:
        rec.notes.append("RTL SIMULATION RESULT - NOT A SILICON TEST")
    rec.finalize()
    if args.run_dir:
        print("record:", rec.write(Path(args.run_dir)))
    return rec


def cmd_bringup(h: TestCoreHost, args, ev):
    """Post-fabrication diagnostic order (docs/testcore/bringup_plan.md).
    Electrical/lab stages are manual procedures: recorded NOT RUN here."""
    rec = TestRecord(evidence_class=ev, design_version=args.design)
    manual = ["01_visual_and_package_inspection", "02_supply_current_and_short_checks", "03_clock_and_reset_verification"]
    for m in manual:
        rec.steps.append(StepRecord(name=m, status=Status.NOT_RUN,
                                    detail={"reason": "manual lab procedure with qualified equipment and interlocks; "
                                                      "not automated by this tool"}))
    info = h.identify()
    rec.steps.append(StepRecord(name="04_jtag_tap_identification", status=Status.PASS if info["idcode_ok"] and
                                h.bypass_check() else Status.FAIL, detail=info))
    ms = h.mode_status()
    rec.steps.append(StepRecord(name="05_test_mode_status", status=Status.PASS if ms["mode"] == "NORMAL"
                                else Status.FAIL, detail=ms))
    r = h.mbist_run(list(range(info["bank_count"])), "march_c_minus")
    rec.steps.append(StepRecord(name="06_sram_mbist_march_c_minus",
                                status={"PASS": Status.PASS, "FAIL": Status.FAIL}.get(r.result, Status.INCONCLUSIVE),
                                detail=r.model_dump()))
    for n in ["07_boot_rom_access", "08_cpu_reset_boot", "09_uart_communication", "10_sram_functional_rw",
              "11_dma_copy", "12_vector_engine", "13_tensor_engine", "14_performance_timing"]:
        rec.steps.append(StepRecord(name=n, status=Status.NOT_RUN,
                                    detail={"reason": "requires the integrated SoC (CPU, boot ROM, UART, DMA, "
                                                      "accelerators) and its firmware; not part of the TestCore-only "
                                                      "target"}))
    if ev == Evidence.SIMULATION:
        rec.notes.append("RTL SIMULATION RESULT - NOT A SILICON TEST")
    rec.finalize()
    if args.run_dir:
        rec.write(Path(args.run_dir))
    print(summarize(Path(args.run_dir)) if args.run_dir else rec.model_dump_json(indent=1))
    return rec


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m testcore", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["scan", "mbist", "diagnostics", "report", "svf", "bringup"])
    ap.add_argument("--transport", choices=["hw", "sim"], default="hw")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=6666)
    ap.add_argument("--evidence", choices=["fpga", "wafer", "packaged", "sim-bridge"], default="packaged",
                    help="what the hw transport is connected to; sim-bridge = RTL via tools/rbb_sim_bridge.py")
    ap.add_argument("--design", default="SilicaFlux TestCore integration (tb_testcore_sys)")
    ap.add_argument("--bank", default="all")
    ap.add_argument("--algorithm", default="march_c_minus")
    ap.add_argument("--bg-checker", action="store_true")
    ap.add_argument("--stop-on-fail", action="store_true")
    ap.add_argument("--no-scrub", action="store_true")
    ap.add_argument("--run-dir", default=None)
    ap.add_argument("--out", default="mbist.svf")
    ap.add_argument("--wait-tck", type=int, default=None)
    ap.add_argument("--clk-half", type=float, default=5.0, help="sim: system clock half period (ns)")
    ap.add_argument("--tck-half", type=float, default=20.0, help="sim: TCK half period (ns)")
    ap.add_argument("--sim-traffic", action="store_true", help="sim: enable functional masters")
    ap.add_argument("--sim-fault", action="append", help="sim: bank:kind:addr:bit (SRAM-library fault kinds)")
    args = ap.parse_args(argv)

    if args.cmd == "report":
        if not args.run_dir:
            ap.error("--run-dir required")
        print(summarize(Path(args.run_dir)))
        return 0
    if args.cmd == "svf":
        # deterministic production pattern (no polling): wait derived from the modelled cycle count
        n = 4 if args.bank == "all" else len(args.bank.split(","))
        mask = (1 << n) - 1 if args.bank == "all" else sum(1 << int(b) for b in args.bank.split(","))
        wait = args.wait_tck or 4096
        p = mbist_production_pattern(mask, args.algorithm, wait)
        Path(args.out).write_text(p.to_svf())
        print(f"wrote {args.out} ({len(p.compile())} scan operations, MBIST wait {wait} TCK)")
        return 0
    try:
        t, ev = _open(args)
    except HardwareNotAvailable as e:
        return _blocked(args, str(e))
    try:
        h = TestCoreHost(t)
        if args.cmd == "scan":
            cmd_scan(h, args, ev)
        elif args.cmd == "mbist":
            rec = cmd_mbist(h, args, ev)
            return 0 if rec.status == Status.PASS else 1
        elif args.cmd == "diagnostics":
            print(json.dumps(h.diagnostics(), indent=1))
        elif args.cmd == "bringup":
            cmd_bringup(h, args, ev)
        if ev == Evidence.SIMULATION:
            print("NOTE: RTL SIMULATION RESULT - NOT A SILICON TEST")
        return 0
    finally:
        t.close()


if __name__ == "__main__":
    sys.exit(main())
