"""SilicaFlux TestCore host-side software (Project 07)."""
__version__ = "2.0.1"
