# Formal verification results

Evidence class: FORMAL VERIFICATION (SymbiYosys, abc pdr = unbounded safety proof)

Tools: {'yosys': 'Yosys 0.70+post (git sha1 v0.70, Release, GNU /nix/store/r5ri78axx1qggkjq3vawywlzglg70b5w-gcc-wrapper-16.2.0/bin/g++ 16.2.0)', 'sby': 'unknown SBY version'}

| Harness | Proof | Time (s) | Reachability (non-vacuity) |
|---|---|---|---|
| `fv_mbist` MBIST engine (2 banks 3x5 / 4x3, write-resp on bank 1) | **PASS** | 1.82 | #0: REACHED@63, #1: REACHED@12, #2: REACHED@12, #3: REACHED@10 |
| `fv_sramlib_wrap` Ownership + SRAM Wrapper Library sram_sp wrapper | **PASS** | 0.83 | #0: REACHED@8, #1: REACHED@8 |
| `fv_mode_ctrl` Test-mode controller | **PASS** | 0.32 | #0: REACHED@3, #1: REACHED@4, #2: REACHED@3, #3: REACHED@3 |
| `fv_regs` Register block | **PASS** | 0.55 | #0: REACHED@3, #1: REACHED@3 |
| `fv_tap` JTAG TAP (multiclock, posedge+negedge TCK) | **PASS** | 0.38 | #0: REACHED@32 |
| `fv_bridge` TCK<->clk register bridge (multiclock, asynchronous clocks) | **PASS** | 3.09 | #0: REACHED@27 |

Properties per harness:

* `fv_mbist`: F1 request held stable until accepted; F2 new request only with test_enable + ownership; F3 address within bank bounds; F5 <= 1 transaction outstanding; F6 completion only after final transaction retired; F7 no PASS with a detected mismatch; F8 no request during/after reset; F9 idle engine issues nothing; F10 first-failure record preserved until clear; F11 fail counter saturates; embedded: selection, no PASS after protocol violation, bank/walk index range, address generator never steps past the end, compare only on awaited response
* `fv_sramlib_wrap`: O1 functional/test ownership mutually exclusive; O2 switch only when functional path drained; O3 no unsolicited functional response; O4 no unsolicited test response; O5 test grant only when owned; O6 bounded outstanding; O7 NORMAL = no quiesce; embedded: raw test access only while owned, destructive writes only in TEST_ACTIVE, sram_sp library assertions (SRAMLIB_ASSERT)
* `fv_mode_ctrl`: M1 MBIST needs hw_test_en + unlock; M2 debug modes need hw_dbg_en; M3 scan enable only from pins; M4 at most one mode active; M5 MBIST entry only on permitted request; M6 no spontaneous mode change except to NORMAL; M7 reset -> NORMAL
* `fv_regs`: R1 error flags sticky until W1C; R2 PROTECT only sets; R3 unlock only by key write; R4 START only from TEST_CONTROL write; R5 mode request only from MODE_CTRL write
* `fv_tap`: T1 5 x TMS=1 -> Test-Logic-Reset from any state; T2 one TestCore DR selected; T3 TLR selects IDCODE
* `fv_bridge`: B1 no duplication, at most one request in flight (launch vs execute counters); B2 multibit payload stable while pending (coherent transfer)

Assumptions and limits: properties are proven for the parameterisation in each harness (small banks/widths); synchronisers are modelled as ideal flops (no metastability); liveness (eventual completion) is NOT proven formally -- it is covered by simulation only.

Overall: **PASS**
