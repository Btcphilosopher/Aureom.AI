
read_liberty /tmp/claude-0/-home-user-Aureom-AI/8bda65d8-802c-5f32-81cb-a518c937f1d7/scratchpad/silicaflux-testcore/third_party/pdk/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog /tmp/claude-0/-home-user-Aureom-AI/8bda65d8-802c-5f32-81cb-a518c937f1d7/scratchpad/silicaflux-testcore/reports/testcore/synth/B/netlist.v
link_design sftc_var_b
create_clock -name clk -period 20.0 [get_ports clk]

set_clock_uncertainty 0.25 [all_clocks]
set_input_delay  [expr 20.0 * 0.2] -clock clk [delete_from_list [all_inputs] [get_ports {clk tck trst_n rst_n}]]
set_output_delay [expr 20.0 * 0.2] -clock clk [all_outputs]
set_load 0.01 [all_outputs]
set_false_path -from [get_ports rst_n]

report_checks -path_delay max -group_path_count 1 -format full_clock_expanded -digits 3
report_wns -digits 3
report_tns -digits 3
report_worst_slack -max -digits 3
puts "SFTC_REG2REG_BEGIN"
report_checks -path_delay max -from [all_registers -clock_pins] -to [all_registers -data_pins] -format end -digits 3
puts "SFTC_FUNC_BEGIN"
report_checks -path_delay max -from [get_ports {req* we* addr* wdata* be*}] -format end -digits 3
report_checks -path_delay max -to [get_ports {gnt* rvalid* rdata* err*}] -format end -digits 3
report_power -digits 6
