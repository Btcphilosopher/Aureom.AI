read_liberty /tmp/claude-0/-home-user-Aureom-AI/8bda65d8-802c-5f32-81cb-a518c937f1d7/scratchpad/silicaflux-testcore/third_party/pdk/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog /tmp/claude-0/-home-user-Aureom-AI/8bda65d8-802c-5f32-81cb-a518c937f1d7/scratchpad/silicaflux-testcore/reports/testcore/dft/scan_netlist.v
link_design sftc_var_e
read_sdc /tmp/claude-0/-home-user-Aureom-AI/8bda65d8-802c-5f32-81cb-a518c937f1d7/scratchpad/silicaflux-testcore/constraints/testcore_scan_shift.sdc
puts "SFTC_SETUP"
report_checks -path_delay max -group_path_count 1 -digits 3 -format end
report_wns -digits 3
report_tns -digits 3
puts "SFTC_HOLD"
report_checks -path_delay min -group_path_count 1 -digits 3 -format end
report_worst_slack -min -digits 3
report_check_types -max_slew -max_capacitance -max_fanout -violators
