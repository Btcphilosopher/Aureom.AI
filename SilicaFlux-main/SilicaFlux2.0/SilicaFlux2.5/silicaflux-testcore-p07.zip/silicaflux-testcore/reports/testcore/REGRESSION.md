# SilicaFlux TestCore regression

Date (UTC): 2026-11-06 15:00:34  
Host: Linux-6.18.44-fc-v242-x86_64-with-glibc2.39

## Tool versions

| Tool | Version |
|---|---|
| iverilog | Icarus Verilog version 12.0 (stable) () |
| verilator | Verilator 5.020 2024-01-01 rev (Debian 5.020-1) |
| yosys | Yosys 0.70+post (git sha1 v0.70, Release, GNU /nix/store/r5ri78axx1qggkjq3vawywlzglg70b5w-gcc-wrapper-16.2.0/bin/g++ 16.2.0) |
| sby | unknown SBY version |
| openroad | 26Q3 |
| sta | 3.1.0 |
| openocd | Open On-Chip Debugger 0.12.0 |
| z3 | z3 5.3.3 |
| python | Python 3.13.18 |

## Steps

| Step | Evidence class | Result | Time (s) | Executed (UTC) | Log |
|---|---|---|---|---|---|
| spec_and_unit_tests | SOFTWARE UNIT TEST | **PASS** | 0.6 | 2026-11-06 14:48:46 | logs/spec_and_unit_tests.log |
| lint_verilator | STATIC CHECK | **PASS** | 0.3 | 2026-11-06 14:48:46 | logs/lint_verilator.log |
| yosys_elab_latch_check | STATIC CHECK (Yosys 0.33, the SilicaFlux-V reference version) | **PASS** | 0.4 | 2026-11-06 14:48:47 | logs/yosys_elab_latch_check.log |
| mbist_functional_and_fault_injection | FUNCTIONAL + FAULT-INJECTION SIMULATION | **PASS** | 187.0 | 2026-11-06 14:51:53 | logs/mbist_functional_and_fault_injection.log |
| jtag_tap_and_cdc_sim | FUNCTIONAL SIMULATION | **PASS** | 1.5 | 2026-11-06 14:51:55 | logs/jtag_tap_and_cdc_sim.log |
| system_sim_host_library | FUNCTIONAL SIMULATION (system, host library over RTL) | **PASS** | 97.0 | 2026-11-06 14:53:32 | logs/system_sim_host_library.log |
| sfv_integration_sim | FUNCTIONAL SIMULATION (real SilicaFlux-V sfv_sram_slave) | **PASS** | 35.9 | 2026-11-06 14:54:08 | logs/sfv_integration_sim.log |
| datafabric_path_sim | FUNCTIONAL SIMULATION (real DataFabric sfb_sram_slave) | **PASS** | 0.5 | 2026-11-06 14:54:08 | logs/datafabric_path_sim.log |
| formal | FORMAL VERIFICATION | **PASS** | 18.8 | 2026-11-06 14:54:27 | logs/formal.log |
| synthesis_sky130 | LOGIC SYNTHESIS + STA | **PASS** | 26.2 | 2026-11-06 14:54:53 | logs/synthesis_sky130.log |
| scan_insertion_openroad | DFT SCAN INSERTION | **PASS** | 2.9 | 2026-11-06 14:58:09 | logs/scan_insertion_openroad.log |
| timing_modes | STATIC TIMING PER TEST MODE | **PASS** | 2.9 | 2026-11-06 14:54:57 | logs/timing_modes.log |
| floorplan_placement | PLACEMENT EXPERIMENT | **PASS** | 3.3 | 2026-11-06 14:55:00 | logs/floorplan_placement.log |
| atpg_experiment | ATPG EXPERIMENT (in-house) | **PASS** | 145.3 | 2026-11-06 15:00:34 | logs/atpg_experiment.log |
| openocd_bridge_and_svf | HARDWARE-ADAPTER PATH AGAINST RTL (OpenOCD remote_bitbang) | **PASS** | 32.1 | 2026-11-06 14:57:44 | logs/openocd_bridge_and_svf.log |

## Commands

* `spec_and_unit_tests`: `/usr/local/bin/python3 -m pytest -q python/tests/test_unit_models.py`
* `lint_verilator`: `bash -c verilator --lint-only -Wall -Wno-UNUSEDPARAM -Irtl/testcore -Ithird_party/silicaflux-sramlib/rtl/mem rtl/testcore/sftc_pkg.sv rtl/testcore/sftc_*.sv rtl/testcore/silicaflux_*.sv --top-module sftc_testcore_top && echo LINT_CLEAN`
* `yosys_elab_latch_check`: `bash -c ${SFTC_YOSYS_033:-yosys} -q -p 'read_verilog -sv -DSYNTHESIS -Irtl/testcore -Ithird_party/silicaflux-sramlib/rtl/mem rtl/testcore/sftc_*.sv rtl/testcore/silicaflux_*.sv third_party/silicaflux-sramlib/rtl/mem/sram_sp.sv third_party/silicaflux-sramlib/rtl/mem/sram_1r1w.sv third_party/silicaflux-sramlib/rtl/mem/sram_backend_1rw.sv third_party/silicaflux-sramlib/rtl/mem/sram_backend_1r1w.sv third_party/silicaflux-sramlib/rtl/mem/sram_rsp_path.sv third_party/silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1rw.sv third_party/silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1r1w.sv third_party/silicaflux-v/rtl/mem/sfv_mem_slaves.sv third_party/silicaflux-v/rtl/mem/sfv_sram_sp.sv; hierarchy -top sftc_testcore_top; proc; select -assert-none t:$dlatch t:$adlatch t:$_DLATCH*; check -assert' && echo ELAB_NO_LATCH`
* `mbist_functional_and_fault_injection`: `/usr/local/bin/python3 -m testcore.sim.campaign`
* `jtag_tap_and_cdc_sim`: `bash -c iverilog -g2012 -Wno-timescale -I rtl/testcore -o build/tb_jtag.vvp rtl/testcore/sftc_pkg.sv rtl/testcore/sftc_sync.sv rtl/testcore/sftc_jtag_tap.sv rtl/testcore/sftc_jtag_reg_bridge.sv tb/testcore/tb_jtag_tap.sv && vvp -n build/tb_jtag.vvp`
* `system_sim_host_library`: `bash -c rm -f build/tb_sys.vvp && scripts/iv_sys.sh build/tb_sys.vvp && /usr/local/bin/python3 -m pytest -q python/tests/test_system_sim.py`
* `sfv_integration_sim`: `bash -c scripts/iv_sfv.sh build/tb_sfv.vvp && vvp -n build/tb_sfv.vvp`
* `datafabric_path_sim`: `bash -c scripts/iv_df.sh build/tb_df.vvp && vvp -n build/tb_df.vvp`
* `formal`: `/usr/local/bin/python3 scripts/run_formal.py`
* `synthesis_sky130`: `/usr/local/bin/python3 asic/synth/run_synth.py`
* `scan_insertion_openroad`: `bash -c SFTC_PDK=third_party/pdk SFTC_NET=reports/testcore/synth/E/netlist.v SFTC_TOP=sftc_var_e SFTC_OUT=reports/testcore/dft SFTC_MAXLEN=200 openroad -no_init -exit asic/dft/run_scan.tcl > reports/testcore/dft/openroad_scan.log 2>&1; cat reports/testcore/dft/openroad_scan.log | grep -E 'Scan chain|SFTC_SCAN'; /usr/local/bin/python3 asic/dft/check_chains.py`
* `timing_modes`: `/usr/local/bin/python3 asic/sta/run_modes.py`
* `floorplan_placement`: `bash -c for t in E_prescan E_scan; do n=reports/testcore/synth/E/netlist.v; [ $t = E_scan ] && n=reports/testcore/dft/scan_netlist.v; SFTC_PDK=third_party/pdk SFTC_NET=$n SFTC_TOP=sftc_var_e openroad -no_init -exit asic/floorplan/place_compare.tcl > reports/testcore/floorplan/$t.log 2>&1 || exit 1; grep -E 'legalized HPWL|Design area' reports/testcore/floorplan/$t.log; done`
* `atpg_experiment`: `/usr/local/bin/python3 -m testcore.atpg.run_atpg --sat-seconds 600`
* `openocd_bridge_and_svf`: `bash scripts/run_openocd_bridge.sh`

**Overall: PASS**
