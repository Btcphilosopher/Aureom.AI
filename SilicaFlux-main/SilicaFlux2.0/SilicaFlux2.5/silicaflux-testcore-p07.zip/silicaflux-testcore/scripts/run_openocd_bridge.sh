#!/usr/bin/env bash
# OpenOCD (real JTAG stack, remote_bitbang driver) against the RTL simulation:
#  1. scan + MBIST through the host library's OpenOCD (hardware) transport
#  2. SVF export + playback by OpenOCD: fault-free (must PASS) and with an injected fault (must FAIL)
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
OUT=reports/testcore/openocd; mkdir -p $OUT
CFG="-f asic/dft/openocd/sim_bridge.cfg -f asic/dft/openocd/silicaflux_testcore.cfg"
cleanup() { pkill -f rbb_sim_bridge.py >/dev/null 2>&1; pkill -x openocd >/dev/null 2>&1; pkill -f tb_sys.vvp >/dev/null 2>&1; sleep 1; }
cleanup
ok=1
python3 tools/rbb_sim_bridge.py --port 9824 --traffic > $OUT/bridge_hostflow.log 2>&1 &
sleep 3; openocd $CFG > $OUT/openocd_hostflow.log 2>&1 & sleep 8
(cd python && python3 -m testcore scan --transport hw --evidence sim-bridge) > $OUT/hostflow_scan.log 2>&1 || ok=0
(cd python && python3 -m testcore mbist --transport hw --evidence sim-bridge --bank 0,3 --algorithm mats_plus \
   --run-dir ../$OUT/run_hostflow) > $OUT/hostflow_mbist.log 2>&1 || ok=0
grep -q '"idcode_ok": true' $OUT/hostflow_scan.log || ok=0
grep -q 'mats_plus.*PASS' $OUT/hostflow_mbist.log || ok=0
cleanup
(cd python && python3 -m testcore svf --bank all --algorithm march_c_minus --wait-tck 12000 --out ../$OUT/mbist_march_c_minus_all.svf) > /dev/null
for scen in pass fault; do
  F=""; [ $scen = fault ] && F="--fault 1:1:77:3"
  python3 tools/rbb_sim_bridge.py --port 9824 $F > $OUT/bridge_svf_$scen.log 2>&1 &
  sleep 3
  timeout 1200 openocd $CFG -c "svf -tap sftc.tap $OUT/mbist_march_c_minus_all.svf; shutdown" > $OUT/svf_playback_$scen.log 2>&1
  rc=$?
  # OpenOCD 0.12 prints no success banner: PASS = exit 0, every SDR executed, no TDO check error
  if [ $scen = pass ]; then
    [ $rc = 0 ] && ! grep -q "tdo check error" $OUT/svf_playback_$scen.log && \
      [ "$(grep -c '^SDR' $OUT/svf_playback_$scen.log)" = "$(grep -c '^SDR' $OUT/mbist_march_c_minus_all.svf)" ] || ok=0
  else grep -q "tdo check error" $OUT/svf_playback_$scen.log || ok=0; fi
  cleanup
done
cat $OUT/hostflow_mbist.log | tail -2
echo "SVF pass: $(grep -c '^SDR' $OUT/svf_playback_pass.log) SDR executed, errors: $(grep -c 'tdo check error' $OUT/svf_playback_pass.log)"
echo "SVF fault: $(grep -h -E 'tdo check error|programmed failed' $OUT/svf_playback_fault.log | tr '\n' ' ')"
[ $ok = 1 ] && echo "OPENOCD_BRIDGE PASS" || echo "OPENOCD_BRIDGE FAIL"
