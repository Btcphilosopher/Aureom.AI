#!/usr/bin/env python3
"""SilicaFlux TestCore regression: runs every evidence step, records the exact
command, tool versions, duration and outcome, keeps every log (also failing
ones) and writes reports/testcore/REGRESSION.md + regression.json.

    python3 scripts/regress.py [--quick] [--skip step,step]

Steps whose tools / libraries are missing are reported BLOCKED (never PASS).
"""
import argparse, json, os, platform, re, shutil, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REP = ROOT / "reports" / "testcore"
LOGS = REP / "logs"
ENV = dict(os.environ)
ENV["PYTHONPATH"] = str(ROOT / "python") + os.pathsep + ENV.get("PYTHONPATH", "")


def tool(cmd):
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return (out.stdout or out.stderr).strip().splitlines()[0]
    except Exception:
        return None


def have(x):
    return shutil.which(x) is not None or (x == "sta" and os.environ.get("SFTC_STA"))


STEPS = [
    # name, evidence class, command, required tools, success regex (on output), timeout s
    ("spec_and_unit_tests", "SOFTWARE UNIT TEST", [sys.executable, "-m", "pytest", "-q", "python/tests/test_unit_models.py"],
     ["iverilog"], r" passed", 600),
    ("lint_verilator", "STATIC CHECK", ["bash", "-c",
     "verilator --lint-only -Wall -Wno-UNUSEDPARAM -Irtl/testcore -Ithird_party/silicaflux-sramlib/rtl/mem "
     "rtl/testcore/sftc_pkg.sv rtl/testcore/sftc_*.sv rtl/testcore/silicaflux_*.sv --top-module sftc_testcore_top "
     "&& echo LINT_CLEAN"], ["verilator"], r"LINT_CLEAN", 600),
    ("yosys_elab_latch_check", "STATIC CHECK (Yosys 0.33, the SilicaFlux-V reference version)", ["bash", "-c",
     "${SFTC_YOSYS_033:-yosys} -q -p 'read_verilog -sv -DSYNTHESIS -Irtl/testcore -Ithird_party/silicaflux-sramlib/rtl/mem "
     "rtl/testcore/sftc_*.sv rtl/testcore/silicaflux_*.sv third_party/silicaflux-sramlib/rtl/mem/sram_sp.sv "
     "third_party/silicaflux-sramlib/rtl/mem/sram_1r1w.sv third_party/silicaflux-sramlib/rtl/mem/sram_backend_1rw.sv "
     "third_party/silicaflux-sramlib/rtl/mem/sram_backend_1r1w.sv third_party/silicaflux-sramlib/rtl/mem/sram_rsp_path.sv "
     "third_party/silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1rw.sv "
     "third_party/silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1r1w.sv "
     "third_party/silicaflux-v/rtl/mem/sfv_mem_slaves.sv third_party/silicaflux-v/rtl/mem/sfv_sram_sp.sv; "
     "hierarchy -top sftc_testcore_top; proc; select -assert-none t:$dlatch t:$adlatch t:$_DLATCH*; "
     "check -assert' && echo ELAB_NO_LATCH"], ["yosys"], r"ELAB_NO_LATCH", 600),
    ("mbist_functional_and_fault_injection", "FUNCTIONAL + FAULT-INJECTION SIMULATION",
     [sys.executable, "-m", "testcore.sim.campaign"], ["iverilog"], r"\[mbist\] overall PASS", 3600),
    ("jtag_tap_and_cdc_sim", "FUNCTIONAL SIMULATION", ["bash", "-c",
     "iverilog -g2012 -Wno-timescale -I rtl/testcore -o build/tb_jtag.vvp rtl/testcore/sftc_pkg.sv "
     "rtl/testcore/sftc_sync.sv rtl/testcore/sftc_jtag_tap.sv rtl/testcore/sftc_jtag_reg_bridge.sv "
     "tb/testcore/tb_jtag_tap.sv && vvp -n build/tb_jtag.vvp"], ["iverilog"], r"TB_JTAG_RESULT PASS", 1800),
    ("system_sim_host_library", "FUNCTIONAL SIMULATION (system, host library over RTL)", ["bash", "-c",
     "rm -f build/tb_sys.vvp && scripts/iv_sys.sh build/tb_sys.vvp && "
     f"{sys.executable} -m pytest -q python/tests/test_system_sim.py"], ["iverilog"], r" passed(?!.*failed)", 3600),
    ("sfv_integration_sim", "FUNCTIONAL SIMULATION (real SilicaFlux-V sfv_sram_slave)", ["bash", "-c",
     "scripts/iv_sfv.sh build/tb_sfv.vvp && vvp -n build/tb_sfv.vvp"], ["iverilog"], r"TB_SFV_DONE", 3600),
    ("datafabric_path_sim", "FUNCTIONAL SIMULATION (real DataFabric sfb_sram_slave)", ["bash", "-c",
     "scripts/iv_df.sh build/tb_df.vvp && vvp -n build/tb_df.vvp"], ["iverilog"], r"TB_DF_DONE", 1200),
    ("formal", "FORMAL VERIFICATION", [sys.executable, "scripts/run_formal.py"], ["sby", "yosys"],
     r"\[formal\] overall PASS", 3600),
    ("synthesis_sky130", "LOGIC SYNTHESIS + STA", [sys.executable, "asic/synth/run_synth.py"], ["yosys"],
     r"\[synth\] E ", 3600),
    ("scan_insertion_openroad", "DFT SCAN INSERTION", ["bash", "-c",
     "SFTC_PDK=third_party/pdk SFTC_NET=reports/testcore/synth/E/netlist.v SFTC_TOP=sftc_var_e "
     "SFTC_OUT=reports/testcore/dft SFTC_MAXLEN=200 openroad -no_init -exit asic/dft/run_scan.tcl "
     "> reports/testcore/dft/openroad_scan.log 2>&1; cat reports/testcore/dft/openroad_scan.log | grep -E 'Scan chain|SFTC_SCAN'; "
     f"{sys.executable} asic/dft/check_chains.py"], ["openroad", "iverilog"], r"SCAN_CHAIN_RESULT PASS", 3600),
    ("timing_modes", "STATIC TIMING PER TEST MODE", [sys.executable, "asic/sta/run_modes.py"], ["sta"],
     r"\[sta\] scan_capture", 1800),
    ("floorplan_placement", "PLACEMENT EXPERIMENT", ["bash", "-c",
     "for t in E_prescan E_scan; do n=reports/testcore/synth/E/netlist.v; [ $t = E_scan ] && n=reports/testcore/dft/scan_netlist.v; "
     "SFTC_PDK=third_party/pdk SFTC_NET=$n SFTC_TOP=sftc_var_e openroad -no_init -exit asic/floorplan/place_compare.tcl "
     "> reports/testcore/floorplan/$t.log 2>&1 || exit 1; grep -E 'legalized HPWL|Design area' reports/testcore/floorplan/$t.log; done"],
     ["openroad"], r"Design area.*\n.*\n.*Design area", 3600),
    ("atpg_experiment", "ATPG EXPERIMENT (in-house)", [sys.executable, "-m", "testcore.atpg.run_atpg",
     "--sat-seconds", "600"], ["iverilog"], r"\[atpg\] validation: PASS", 3600),
    ("openocd_bridge_and_svf", "HARDWARE-ADAPTER PATH AGAINST RTL (OpenOCD remote_bitbang)", ["bash", "scripts/run_openocd_bridge.sh"],
     ["openocd", "iverilog"], r"OPENOCD_BRIDGE PASS", 3600),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip", default="")
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    LOGS.mkdir(parents=True, exist_ok=True)
    (ROOT / "build").mkdir(exist_ok=True)
    (REP / "floorplan").mkdir(parents=True, exist_ok=True)
    (REP / "dft").mkdir(parents=True, exist_ok=True)
    tools = {k: tool(v) for k, v in {
        "iverilog": ["iverilog", "-V"], "verilator": ["verilator", "--version"], "yosys": ["yosys", "-V"],
        "sby": ["sby", "--version"], "openroad": ["openroad", "-version"], "sta": [ENV.get("SFTC_STA", "sta"), "-version"],
        "openocd": ["openocd", "--version"], "z3": [sys.executable, "-c", "import z3;print('z3', z3.get_version_string())"],
        "python": [sys.executable, "--version"]}.items()}
    rows = []
    for name, ev, cmd, req, ok_re, tmo in STEPS:
        if (a.only and name not in a.only.split(",")) or name in a.skip.split(","):
            continue
        missing = [t for t in req if not have(t)]
        t0 = time.time()
        if missing:
            rows.append({"step": name, "evidence": ev, "status": "BLOCKED", "detail": f"missing tools: {missing}",
                         "command": " ".join(cmd), "seconds": 0}); print(f"[regress] {name}: BLOCKED {missing}"); continue
        p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=tmo, env=ENV)
        out = p.stdout + p.stderr
        (LOGS / f"{name}.log").write_text(" ".join(cmd) + "\n\n" + out)
        good = p.returncode == 0 and re.search(ok_re, out) is not None and "SFTC_ASSERTION_FAILED" not in out
        tail = [l for l in out.strip().splitlines() if l.strip()][-6:]
        rows.append({"step": name, "evidence": ev, "status": "PASS" if good else "FAIL", "rc": p.returncode,
                     "date_utc": time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()),
                     "command": " ".join(cmd), "seconds": round(time.time() - t0, 1), "log": f"logs/{name}.log",
                     "detail": " | ".join(tail)[-600:]})
        print(f"[regress] {name}: {rows[-1]['status']} ({rows[-1]['seconds']} s)", flush=True)
    if a.only and (REP / "regression.json").exists():
        # merge: keep the other steps of the previous full run, replace the re-run ones
        old = json.loads((REP / "regression.json").read_text())["steps"]
        names = [r["step"] for r in rows]
        rows = [r for r in old if r["step"] not in names] + rows
        order = [s[0] for s in STEPS]
        rows.sort(key=lambda r: order.index(r["step"]) if r["step"] in order else 99)
    overall = "PASS" if all(r["status"] == "PASS" for r in rows) else \
              ("PASS WITH BLOCKED STEPS" if all(r["status"] in ("PASS", "BLOCKED") for r in rows) else "FAIL")
    res = {"date_utc": time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()), "host": platform.platform(),
           "tools": tools, "steps": rows, "overall": overall}
    (REP / "regression.json").write_text(json.dumps(res, indent=1))
    md = ["# SilicaFlux TestCore regression", "", f"Date (UTC): {res['date_utc']}  ", f"Host: {res['host']}", "",
          "## Tool versions", "", "| Tool | Version |", "|---|---|"]
    md += [f"| {k} | {v or 'not found'} |" for k, v in tools.items()]
    md += ["", "## Steps", "", "| Step | Evidence class | Result | Time (s) | Executed (UTC) | Log |", "|---|---|---|---|---|---|"]
    md += [f"| {r['step']} | {r['evidence']} | **{r['status']}** | {r['seconds']} | {r.get('date_utc', '-')} | {r.get('log', '-')} |" for r in rows]
    md += ["", "## Commands", ""] + [f"* `{r['step']}`: `{r['command']}`" for r in rows]
    md += ["", f"**Overall: {overall}**", ""]
    (REP / "REGRESSION.md").write_text("\n".join(md))
    print(f"[regress] overall {overall}")
    return 0 if overall.startswith("PASS") else 1


if __name__ == "__main__":
    sys.exit(main())
