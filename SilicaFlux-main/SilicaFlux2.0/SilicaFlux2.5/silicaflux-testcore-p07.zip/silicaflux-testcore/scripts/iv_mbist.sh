#!/usr/bin/env bash
# compile tb_mbist with Icarus: scripts/iv_mbist.sh <out.vvp> [defines...]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$1"; shift
iverilog -g2012 -Wall -Wno-timescale -Wno-sensitivity-entire-vector -Wno-sensitivity-entire-array \
  -I "$ROOT/rtl/testcore" -o "$OUT" "$@" \
  "$ROOT/rtl/testcore/sftc_pkg.sv" "$ROOT/rtl/testcore/sftc_mbist_addr_gen.sv" \
  "$ROOT/rtl/testcore/sftc_mbist_pattern.sv" "$ROOT/rtl/testcore/sftc_mbist_cmp.sv" \
  "$ROOT/rtl/testcore/sftc_mbist_fail_log.sv" "$ROOT/rtl/testcore/silicaflux_mbist.sv" \
  "$ROOT/rtl/testcore/sftc_mbist_bank_mux.sv" "$ROOT/tb/testcore/models/sftc_fault_mem.sv" \
  "$ROOT/tb/testcore/tb_mbist.sv" 2>&1 | grep -v "sorry: constant selects" || true
test -f "$OUT"
