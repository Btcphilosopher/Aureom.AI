#!/usr/bin/env bash
# compile the system testbench: scripts/iv_sys.sh <out.vvp>
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
R="$ROOT/rtl/testcore"; L="$ROOT/third_party/silicaflux-sramlib/rtl/mem"
iverilog -g2012 -Wno-timescale -Wno-sensitivity-entire-vector -Wno-sensitivity-entire-array \
  -I "$R" -I "$L" -o "$1" \
  "$R"/sftc_pkg.sv "$R"/sftc_sync.sv "$R"/sftc_mbist_addr_gen.sv "$R"/sftc_mbist_pattern.sv "$R"/sftc_mbist_cmp.sv \
  "$R"/sftc_mbist_fail_log.sv "$R"/silicaflux_mbist.sv "$R"/sftc_mbist_bank_mux.sv "$R"/sftc_regs.sv \
  "$R"/silicaflux_test_mode_controller.sv "$R"/sftc_jtag_tap.sv "$R"/sftc_jtag_reg_bridge.sv \
  "$R"/sftc_mem_owner.sv "$R"/sftc_tst_port_adapter.sv "$R"/sftc_sramlib_sp_wrap.sv "$R"/sftc_sramlib_1r1w_wrap.sv \
  "$R"/sftc_testcore_top.sv \
  "$L"/sram_sp.sv "$L"/sram_1r1w.sv "$L"/sram_backend_1rw.sv "$L"/sram_backend_1r1w.sv "$L"/sram_rsp_path.sv \
  "$L"/backends/generic/sram_generic_1rw.sv "$L"/backends/generic/sram_generic_1r1w.sv \
  "$ROOT"/tb/testcore/tb_func_master.sv "$ROOT"/tb/testcore/tb_testcore_sys.sv 2>&1 \
  | grep -v -E "sorry: constant selects|cannot be synthesized|Static variable" || true
test -f "$1"
