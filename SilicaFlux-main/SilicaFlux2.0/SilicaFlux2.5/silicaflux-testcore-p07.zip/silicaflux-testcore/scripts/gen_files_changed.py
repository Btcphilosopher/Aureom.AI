#!/usr/bin/env python3
"""Write docs/testcore/files_changed.md: every source file of this delivery with
its SHA-256 and origin.  No file of the original repository was modified."""
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC_DIRS = ["rtl", "tb", "formal/testcore", "python/testcore", "python/tests", "asic", "constraints", "scripts",
            "tools", "firmware", ".github", "docs/testcore"]
SKIP = ("_prove", "_bmc", "__pycache__", "/runs/", "generated/")
rows = []
for d in SRC_DIRS:
    for p in sorted((ROOT / d).rglob("*")):
        if p.is_file() and not any(s in str(p) for s in SKIP) and p.suffix not in (".pyc", ".vvp"):
            rel = p.relative_to(ROOT)
            rows.append((str(rel), hashlib.sha256(p.read_bytes()).hexdigest()[:16], sum(1 for _ in open(p, errors="ignore"))))
for f in ("README.md", "Makefile"):
    p = ROOT / f
    rows.append((f, hashlib.sha256(p.read_bytes()).hexdigest()[:16], sum(1 for _ in open(p))))
tp = sorted(str(p.relative_to(ROOT)) for p in (ROOT / "third_party").rglob("*") if p.is_file())
L = ["# Exact source files of this delivery", "",
     "All files below are NEW (created for Project 07).  The original repository `btcphilosopher/aureom.ai` was",
     "not modified and nothing was committed or pushed.  `third_party/` holds UNMODIFIED vendored copies",
     "(SHA-256 lists in each `SHA256SUMS.vendored`) of: SRAM Wrapper Library (`silicaflux-sramlib.zip`),",
     "SilicaFlux-V release-1 memory/debug RTL (`silicaflux-v-release1.zip`), DataFabric `sfb_sram_slave`,",
     "`sfb_reg_slice`, `sfb_skid_buffer` (`silicaflux-datafabric.zip`), and the public sky130hd views (`pdk/`).", "",
     "| File | Lines | SHA-256 (16) |", "|---|---|---|"]
L += [f"| `{r}` | {n} | {h} |" for r, h, n in rows]
L += ["", f"Vendored files: {len(tp)} (see `third_party/*/SHA256SUMS.vendored`)."]
(ROOT / "docs/testcore/files_changed.md").write_text("\n".join(L) + "\n")
print(len(rows), "source files,", len(tp), "vendored")
