#!/usr/bin/env bash
# Fetch the open sky130hd standard-cell views used by synthesis / STA / DFT /
# placement (Apache-2.0, SkyWater PDK via the OpenROAD repository test data).
# Not committed to the deliverable: download on demand.
set -euo pipefail
D="$(cd "$(dirname "$0")/.." && pwd)/third_party/pdk"; mkdir -p "$D"
U=https://raw.githubusercontent.com/The-OpenROAD-Project/OpenROAD/master/test/sky130hd
for f in sky130_fd_sc_hd__tt_025C_1v80.lib sky130_fd_sc_hd_merged.lef sky130hd.tlef; do
  [ -s "$D/$f" ] || curl -fsSL -o "$D/$f" "$U/$f"
done
sha256sum "$D"/* | tee "$D/SHA256SUMS"
