#!/usr/bin/env bash
# Tool environment used for the recorded regression (source this file).
#   apt (Ubuntu 24.04): iverilog 12, verilator 5.020, yosys 0.33, z3, boolector, openocd 0.12
#   nixpkgs (binary cache): yosys 0.70, sby 0.70, openroad 26Q3 (incl. OpenSTA `sta`)
#   PyPI: pydantic 2, pytest, z3-solver
# Override the store paths below for another installation.
export SFTC_NIX_YOSYS=${SFTC_NIX_YOSYS:-/nix/store/cfry5mn7l5qk6cy730gspaa51fahc108-yosys-0.70/bin}
export SFTC_NIX_SBY=${SFTC_NIX_SBY:-/nix/store/hmrimr3nwb4d2di2jm9s5r9g70cc6zix-sby-0.70/bin}
export SFTC_NIX_OR=${SFTC_NIX_OR:-/nix/store/6qbn5zjnnnyna6md4rsmiqw4y26y8556-openroad-26Q3/bin}
[ -d "$SFTC_NIX_YOSYS" ] && export PATH="$SFTC_NIX_YOSYS:$PATH"
[ -d "$SFTC_NIX_SBY" ]   && export PATH="$SFTC_NIX_SBY:$PATH"
[ -d "$SFTC_NIX_OR" ]    && export PATH="$SFTC_NIX_OR:$PATH"
export SFTC_YOSYS_033=${SFTC_YOSYS_033:-/usr/bin/yosys}
export SFTC_STA=${SFTC_STA:-$(command -v sta)}
export SFTC_YOSYS=${SFTC_YOSYS:-$(command -v yosys)}
export SFTC_PDK=${SFTC_PDK:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/third_party/pdk}
