#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; R="$ROOT/rtl/testcore"; L="$ROOT/third_party/silicaflux-sramlib/rtl/mem"
F="$ROOT/third_party/silicaflux-datafabric/rtl"
iverilog -g2012 -Wno-timescale -Wno-sensitivity-entire-vector -Wno-sensitivity-entire-array -I "$R" -I "$L" \
  -s tb_datafabric -o "$1" "$R"/sftc_pkg.sv "$R"/sftc_mbist_addr_gen.sv "$R"/sftc_mbist_pattern.sv \
  "$R"/sftc_mbist_cmp.sv "$R"/sftc_mbist_fail_log.sv "$R"/silicaflux_mbist.sv "$R"/sftc_sfb2_master_adapter.sv \
  "$F"/interconnect/sfb_skid_buffer.sv "$F"/interconnect/sfb_reg_slice.sv "$F"/mem/sfb_sram_slave.sv "$L"/sram_sp.sv "$L"/sram_backend_1rw.sv \
  "$L"/sram_rsp_path.sv "$L"/backends/generic/sram_generic_1rw.sv "$ROOT"/tb/testcore/tb_datafabric.sv 2>&1 \
  | grep -v -E "sorry: constant selects|cannot be synthesized|Static variable" || true
test -f "$1"
