#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; R="$ROOT/rtl/testcore"; V="$ROOT/third_party/silicaflux-v/rtl/mem"
iverilog -g2012 -Wno-timescale -Wno-sensitivity-entire-vector -Wno-sensitivity-entire-array -I "$R" -s tb_sfv_integration -o "$1" \
  "$R"/sftc_pkg.sv "$R"/sftc_sync.sv "$R"/sftc_mbist_addr_gen.sv "$R"/sftc_mbist_pattern.sv "$R"/sftc_mbist_cmp.sv \
  "$R"/sftc_mbist_fail_log.sv "$R"/silicaflux_mbist.sv "$R"/sftc_mbist_bank_mux.sv "$R"/sftc_regs.sv \
  "$R"/silicaflux_test_mode_controller.sv "$R"/sftc_jtag_tap.sv "$R"/sftc_jtag_reg_bridge.sv "$R"/sftc_mem_owner.sv \
  "$R"/sftc_tst_port_adapter.sv "$R"/sftc_sfv_bank_shim.sv "$R"/sftc_testcore_top.sv \
  "$V"/sfv_mem_slaves.sv "$V"/sfv_sram_sp.sv "$ROOT"/tb/testcore/tb_sfv_integration.sv 2>&1 \
  | grep -v -E "sorry: constant selects|cannot be synthesized|Static variable" || true
test -f "$1"
