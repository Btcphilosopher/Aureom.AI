#!/usr/bin/env python3
"""Run every TestCore formal harness: unbounded proof (abc pdr) of all safety
properties, then each non-vacuity reach point (expected FAIL = reachable).
Writes reports/testcore/formal/summary.{json,md}.  Exit 1 on any unexpected
result.  Requires SymbiYosys + Yosys (>= 0.70 tested) on PATH."""
import json, re, shutil, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FDIR = ROOT / "formal" / "testcore"
OUT = ROOT / "reports" / "testcore" / "formal"
HARNESSES = {
    "fv_mbist":        ("MBIST engine (2 banks 3x5 / 4x3, write-resp on bank 1)", 4),
    "fv_sramlib_wrap": ("Ownership + SRAM Wrapper Library sram_sp wrapper", 2),
    "fv_mode_ctrl":    ("Test-mode controller", 4),
    "fv_regs":         ("Register block", 2),
    "fv_tap":          ("JTAG TAP (multiclock, posedge+negedge TCK)", 1),
    "fv_bridge":       ("TCK<->clk register bridge (multiclock, asynchronous clocks)", 1),
}
DESC = {
    "fv_mbist": ["F1 request held stable until accepted", "F2 new request only with test_enable + ownership",
                 "F3 address within bank bounds", "F5 <= 1 transaction outstanding",
                 "F6 completion only after final transaction retired", "F7 no PASS with a detected mismatch",
                 "F8 no request during/after reset", "F9 idle engine issues nothing",
                 "F10 first-failure record preserved until clear", "F11 fail counter saturates",
                 "embedded: selection, no PASS after protocol violation, bank/walk index range, "
                 "address generator never steps past the end, compare only on awaited response"],
    "fv_sramlib_wrap": ["O1 functional/test ownership mutually exclusive", "O2 switch only when functional path drained",
                        "O3 no unsolicited functional response", "O4 no unsolicited test response",
                        "O5 test grant only when owned", "O6 bounded outstanding", "O7 NORMAL = no quiesce",
                        "embedded: raw test access only while owned, destructive writes only in TEST_ACTIVE, "
                        "sram_sp library assertions (SRAMLIB_ASSERT)"],
    "fv_mode_ctrl": ["M1 MBIST needs hw_test_en + unlock", "M2 debug modes need hw_dbg_en",
                     "M3 scan enable only from pins", "M4 at most one mode active",
                     "M5 MBIST entry only on permitted request", "M6 no spontaneous mode change except to NORMAL",
                     "M7 reset -> NORMAL"],
    "fv_regs": ["R1 error flags sticky until W1C", "R2 PROTECT only sets", "R3 unlock only by key write",
                "R4 START only from TEST_CONTROL write", "R5 mode request only from MODE_CTRL write"],
    "fv_tap": ["T1 5 x TMS=1 -> Test-Logic-Reset from any state", "T2 one TestCore DR selected",
               "T3 TLR selects IDCODE"],
    "fv_bridge": ["B1 no duplication, at most one request in flight (launch vs execute counters)",
                  "B2 multibit payload stable while pending (coherent transfer)"],
}


def run(sby: Path, task_name: str, extra_def: str = ""):
    work = OUT / "runs"
    work.mkdir(parents=True, exist_ok=True)
    src = sby.read_text()
    if extra_def:
        src = re.sub(r"^read -formal ", f"read -formal {extra_def} ", src, flags=re.M)
    # make [files] paths absolute
    lines, in_files = [], False
    for ln in src.splitlines():
        if ln.startswith("["):
            in_files = ln.strip() == "[files]"
        elif in_files and ln.strip():
            ln = str((FDIR / ln.strip()).resolve())
        lines.append(ln)
    tf = work / f"{task_name}.sby"
    tf.write_text("\n".join(lines) + "\n")
    d = work / f"{task_name}_prove"
    shutil.rmtree(d, ignore_errors=True)
    t0 = time.time()
    p = subprocess.run(["sby", "-f", str(tf), "prove"], cwd=work, capture_output=True, text=True, timeout=3600)
    st = "ERROR"
    m = re.search(r"DONE \((\w+), rc=", p.stdout)
    if m:
        st = m.group(1)
    frame = re.search(r"asserted in frame (\d+)", p.stdout)
    (work / f"{task_name}.log").write_text(p.stdout + p.stderr)
    return st, round(time.time() - t0, 2), int(frame.group(1)) if frame else None


def tool(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True).stdout.strip().splitlines()[0]
    except Exception:
        return "unavailable"


def main():
    if not shutil.which("sby"):
        OUT.mkdir(parents=True, exist_ok=True)
        (OUT / "summary.json").write_text(json.dumps({"status": "BLOCKED", "reason": "sby not on PATH"}))
        print("[formal] BLOCKED: SymbiYosys (sby) not on PATH")
        return 2
    res = {"evidence_class": "FORMAL VERIFICATION (SymbiYosys, abc pdr = unbounded safety proof)",
           "tools": {"yosys": tool(["yosys", "-V"]), "sby": tool(["sby", "--version"])}, "harnesses": {}}
    bad = 0
    for h, (desc, nreach) in HARNESSES.items():
        sby = FDIR / f"{h}.sby"
        st, sec, _ = run(sby, h)
        reach = []
        for k in range(nreach):
            rst, rsec, fr = run(sby, f"{h}_reach{k}", f"-DREACH -DREACH_IDX={k}")
            reach.append({"point": k, "result": "REACHED" if rst == "FAIL" else f"NOT REACHED ({rst})",
                          "depth": fr, "seconds": rsec})
            bad += rst != "FAIL"
        bad += st != "PASS"
        res["harnesses"][h] = {"description": desc, "properties": DESC[h], "proof": st,
                               "engine": "abc pdr (unbounded)", "seconds": sec, "reach": reach}
        print(f"[formal] {h:16s} proof={st:5s} ({sec}s) reach={[r['result'] for r in reach]}", flush=True)
    res["status"] = "PASS" if bad == 0 else "FAIL"
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "summary.json").write_text(json.dumps(res, indent=1))
    md = ["# Formal verification results", "", f"Evidence class: {res['evidence_class']}", "",
          f"Tools: {res['tools']}", "", "| Harness | Proof | Time (s) | Reachability (non-vacuity) |", "|---|---|---|---|"]
    for h, r in res["harnesses"].items():
        md.append(f"| `{h}` {r['description']} | **{r['proof']}** | {r['seconds']} | " +
                  ", ".join(f"#{x['point']}: {x['result']}@{x['depth']}" for x in r["reach"]) + " |")
    md += ["", "Properties per harness:", ""]
    for h, r in res["harnesses"].items():
        md.append(f"* `{h}`: " + "; ".join(r["properties"]))
    md += ["", "Assumptions and limits: properties are proven for the parameterisation in each harness "
           "(small banks/widths); synchronisers are modelled as ideal flops (no metastability); "
           "liveness (eventual completion) is NOT proven formally -- it is covered by simulation only.",
           f"", f"Overall: **{res['status']}**"]
    (OUT / "summary.md").write_text("\n".join(md) + "\n")
    print(f"[formal] overall {res['status']}")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
