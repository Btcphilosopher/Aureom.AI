#!/usr/bin/env python3
"""Turn an SBY/abc counterexample (trace.aiw) into a VCD and a signal table
without SMT replay:  scripts/fv_trace.py <sby task dir> [top] [sig1,sig2,...] [--last N]"""
import re, subprocess, sys, os
d = sys.argv[1]; top = sys.argv[2] if len(sys.argv) > 2 else None
sigs = sys.argv[3].split(",") if len(sys.argv) > 3 and not sys.argv[3].startswith("--") else []
last = int(sys.argv[sys.argv.index("--last") + 1]) if "--last" in sys.argv else 1000
e = os.path.join(d, "engine_0")
subprocess.run(["yosys-witness", "aiw2yw", f"{e}/trace.aiw", f"{d}/model/design_aiger.ywa", f"{e}/trace.yw"],
               check=True, capture_output=True)
top = top or open(f"{d}/model/design_prep.ys").read().split("hierarchy -top")[-1].split()[0] if False else top
r = subprocess.run(["yosys", "-q", "-p", f"read_rtlil {d}/model/design_prep.il; sim -r {e}/trace.yw "
                    + (f"-scope {top} " if top else "") + f"-vcd {e}/trace.vcd"], capture_output=True, text=True)
print("\n".join(l for l in (r.stdout + r.stderr).splitlines() if "ssert" in l))
v = open(f"{e}/trace.vcd").read().split("\n")
ids, scope = {}, []
for l in v:
    if l.startswith("$scope"): scope.append(l.split()[2])
    elif l.startswith("$upscope"): scope.pop()
    m = re.match(r"\$var \w+ (\d+) (\S+) (\S+)", l)
    if m: ids.setdefault(m.group(2), ".".join(scope[1:] + [m.group(3)]))
cur, rows = {}, []
for l in v:
    if l.startswith("#"):
        if "__t" in cur: rows.append(dict(cur))
        cur["__t"] = l
    elif l[:1] in "01xz" and len(l) > 1:
        n = ids.get(l[1:])
        if n: cur[n] = l[0]
    elif l.startswith("b"):
        a, b = l[1:].split(); n = ids.get(b)
        if n: cur[n] = a
rows.append(dict(cur))
for r in rows[-last:]:
    print(r["__t"], " ".join(f"{k}={r.get(k, '?')}" for k in sigs))
