// =============================================================================
// SilicaFlux TestCore :: sftc_sramlib_sp_wrap
// MBIST-ready single-port SRAM: SRAM Wrapper Library `sram_sp` (Project 01,
// vendored unmodified in third_party/silicaflux-sramlib) + ownership
// controller + TestCore test-port adapter.
//   * Normal request path : sram_sp valid/ready request + in-order response,
//                            gated by the ownership controller (f_block).
//   * Test request path   : sram_sp raw tst_* port, only while owned.
//   * Ownership select    : sram_sp tst_active = sel_test.
//   * Read response routing: functional responses keep using sram_sp's
//                            response path (already-accepted reads complete);
//                            test reads return through the adapter's
//                            latency pipeline.  The owner switches only when
//                            both directions are drained.
//   * Write data / masks  : functional writes keep their byte masks; test
//                            writes are full-word (sram_sp forces all lanes).
// No port is added to the memory macro: the test path uses the library's
// existing port mux in front of the single physical port.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sftc_sramlib_sp_wrap #(
  parameter int DATA_WIDTH     = 32,
  parameter int DEPTH          = 1024,
  parameter int MASK_WIDTH     = (DATA_WIDTH % 8 == 0) ? DATA_WIDTH / 8 : 1,
  parameter int READ_LATENCY   = 1,
  parameter int BACKEND        = `SRAM_BACKEND_GENERIC,
  parameter int MACRO          = 0,
  parameter int RSP_FIFO_DEPTH = READ_LATENCY + 1,
  parameter int WRITE_ACK      = 1,
  parameter int ID_WIDTH       = 1,
  parameter int OWN_TIMEOUT    = 4096,
  localparam int AW            = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // functional port (sram_sp contract)
  input  wire logic                  req_valid,
  output logic                       req_ready,
  input  wire logic                  req_we,
  input  wire logic [AW-1:0]         req_addr,
  input  wire logic [DATA_WIDTH-1:0] req_wdata,
  input  wire logic [MASK_WIDTH-1:0] req_wmask,
  input  wire logic [ID_WIDTH-1:0]   req_id,
  output logic                       rsp_valid,
  input  wire logic                  rsp_ready,
  output logic [DATA_WIDTH-1:0]      rsp_rdata,
  output logic                       rsp_err,
  output logic                       rsp_we,
  output logic [ID_WIDTH-1:0]        rsp_id,
  // TestCore test port
  input  wire logic                  t_req,
  output logic                       t_gnt,
  input  wire logic                  t_we,
  input  wire logic [AW-1:0]         t_addr,
  input  wire logic [DATA_WIDTH-1:0] t_wdata,
  output logic                       t_rvalid,
  output logic [DATA_WIDTH-1:0]      t_rdata,
  output logic                       t_rerr,
  // ownership
  input  wire logic                  acq_req,
  input  wire logic                  fault_clear,
  input  wire logic                  quiesce_ack,
  output logic                       quiesce_req,
  input  wire logic                  mbist_busy,
  input  wire logic                  scrub_done,
  output logic                       owned,
  output logic [2:0]                 owner_state,
  output logic                       dirty,
  output logic                       ev_fault,
  output logic                       ev_intrusion,
  output logic                       ev_reinit_req,
  output logic                       busy
);
  logic f_block, sel_test, test_en, t_busy, t_wr, f_busy;
  logic tst_ce, tst_we;
  logic [AW-1:0] tst_addr;
  logic [DATA_WIDTH-1:0] tst_wdata, tst_rdata;
  logic sp_ready;

  sftc_mem_owner #(.TIMEOUT(OWN_TIMEOUT)) u_owner (
    .clk, .rst_n, .acq_req, .fault_clear, .quiesce_ack, .f_busy, .f_req(req_valid), .mbist_busy,
    .t_busy, .t_wr, .scrub_done, .quiesce_req, .f_block, .sel_test, .test_en, .owned,
    .state(owner_state), .dirty, .ev_fault, .ev_intrusion, .ev_reinit_req
  );

  sftc_tst_port_adapter #(.DW(DATA_WIDTH), .AW(AW), .READ_LATENCY(READ_LATENCY)) u_adapt (
    .clk, .rst_n, .test_en, .t_req, .t_gnt, .t_we, .t_addr, .t_wdata, .t_rvalid, .t_rdata, .t_rerr,
    .t_busy, .t_wr, .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata
  );

  sram_sp #(
    .DATA_WIDTH(DATA_WIDTH), .DEPTH(DEPTH), .MASK_WIDTH(MASK_WIDTH), .READ_LATENCY(READ_LATENCY),
    .BACKEND(BACKEND), .MACRO(MACRO), .RSP_FIFO_DEPTH(RSP_FIFO_DEPTH), .WRITE_ACK(WRITE_ACK),
    .ID_WIDTH(ID_WIDTH), .TEST_EN(1)
  ) u_sram (
    .clk, .rst_n,
    .req_valid(req_valid && !f_block), .req_ready(sp_ready), .req_we, .req_addr, .req_wdata, .req_wmask,
    .req_id, .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_err, .rsp_we, .rsp_id,
    .tst_active(sel_test), .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata, .busy
  );
  assign req_ready = sp_ready && !f_block;
  // functional activity still in flight: accepted-but-unanswered requests,
  // responses waiting for the master, or an acceptance in this cycle
  assign f_busy = busy || (req_valid && req_ready);

`ifdef FORMAL
  always @(posedge clk) begin
    if (rst_n) begin
      assert (!tst_ce || (test_en && sel_test));              // raw test access only while owned
      assert (!(req_valid && req_ready && sel_test));         // no functional acceptance under test
      if (tst_ce && tst_we) assert (owner_state == 3'd4);     // destructive writes only in TEST_ACTIVE
    end
  end
`endif
endmodule

`default_nettype wire
