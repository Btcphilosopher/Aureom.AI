// =============================================================================
// SilicaFlux TestCore :: sftc_mbist_bank_mux
// Shared-controller bank selector.  Decodes the engine's single test bus to
// per-bank request strobes and returns the selected bank's grant/response.
// Payload (we/addr/wdata) is broadcast: only the selected bank sees t_req.
// A response from any non-selected bank is reported on stray_rvalid.
// Optional register slice per direction (PIPE_REQ / PIPE_RSP) for physically
// distant banks: legal because the engine is fully handshake-based (adds
// latency, never changes behaviour).  The request slice is a full
// valid/ready skid-free slice: it accepts a new request only when empty.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sftc_mbist_bank_mux #(
  parameter int BANK_COUNT = 2,
  parameter int MAX_W      = 32,
  parameter int AW         = 8,
  parameter bit PIPE_REQ   = 1'b0,
  parameter bit PIPE_RSP   = 1'b0,
  localparam int BW = (BANK_COUNT > 1) ? $clog2(BANK_COUNT) : 1
) (
  input  wire logic                        clk,
  input  wire logic                        rst_n,
  // engine side
  input  wire logic                        t_req,
  input  wire logic                        t_we,
  input  wire logic [AW-1:0]               t_addr,
  input  wire logic [MAX_W-1:0]            t_wdata,
  input  wire logic [BW-1:0]               t_bank,
  output logic                             t_gnt,
  output logic                             t_rvalid,
  output logic [MAX_W-1:0]                 t_rdata,
  output logic                             t_rerr,
  output logic                             stray_rvalid,
  // bank side
  output logic [BANK_COUNT-1:0]            b_req,
  output logic                             b_we,
  output logic [AW-1:0]                    b_addr,
  output logic [MAX_W-1:0]                 b_wdata,
  input  wire logic [BANK_COUNT-1:0]       b_gnt,
  input  wire logic [BANK_COUNT-1:0]       b_rvalid,
  input  wire logic [BANK_COUNT*MAX_W-1:0] b_rdata,
  input  wire logic [BANK_COUNT-1:0]       b_rerr
);
  // ------------------------------------------------------------- request path
  logic          q_req, q_we;
  logic [AW-1:0] q_addr;
  logic [MAX_W-1:0] q_wdata;
  logic [BW-1:0] q_bank;
  logic          q_gnt;

  generate
    if (PIPE_REQ) begin : g_preq
      logic full;
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          full <= 1'b0; q_we <= 1'b0; q_addr <= '0; q_wdata <= '0; q_bank <= '0;
        end else if (!full && t_req) begin
          full <= 1'b1; q_we <= t_we; q_addr <= t_addr; q_wdata <= t_wdata; q_bank <= t_bank;
        end else if (full && q_gnt) begin
          full <= 1'b0;
        end
      end
      assign q_req = full;
      assign t_gnt = !full && t_req;          // engine sees acceptance into the slice
    end else begin : g_nopreq
      assign q_req = t_req; assign q_we = t_we; assign q_addr = t_addr;
      assign q_wdata = t_wdata; assign q_bank = t_bank;
      assign t_gnt = q_gnt;
    end
  endgenerate

  always_comb begin
    for (int k = 0; k < BANK_COUNT; k++) b_req[k] = q_req && (32'(q_bank) == k);
  end
  assign b_we    = q_we;
  assign b_addr  = q_addr;
  assign b_wdata = q_wdata;
  assign q_gnt   = |(b_gnt & b_req);

  // ------------------------------------------------------------- response path
  // Responses are attributed to the bank of the outstanding request.  With a
  // single outstanding transaction the response bank equals q_bank of the
  // request that produced it; `r_bank` remembers it across the slice.
  logic [BW-1:0] r_bank;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)                 r_bank <= '0;
    else if (q_req && q_gnt)    r_bank <= q_bank;
  end
  wire [BW-1:0] sel = r_bank;

  logic             c_rvalid, c_rerr, c_stray;
  logic [MAX_W-1:0] c_rdata;
  always_comb begin
    c_rvalid = 1'b0; c_rerr = 1'b0; c_rdata = '0; c_stray = 1'b0;
    for (int k = 0; k < BANK_COUNT; k++) begin
      if (32'(sel) == k) begin
        c_rvalid = b_rvalid[k]; c_rerr = b_rerr[k]; c_rdata = b_rdata[k*MAX_W +: MAX_W];
      end else if (b_rvalid[k]) begin
        c_stray = 1'b1;
      end
    end
  end

  generate
    if (PIPE_RSP) begin : g_prsp
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          t_rvalid <= 1'b0; t_rerr <= 1'b0; t_rdata <= '0; stray_rvalid <= 1'b0;
        end else begin
          t_rvalid <= c_rvalid; t_rerr <= c_rerr; t_rdata <= c_rdata; stray_rvalid <= c_stray;
        end
      end
    end else begin : g_noprsp
      assign t_rvalid = c_rvalid; assign t_rerr = c_rerr; assign t_rdata = c_rdata;
      assign stray_rvalid = c_stray;
    end
  endgenerate
endmodule

`default_nettype wire
