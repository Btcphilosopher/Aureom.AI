// =============================================================================
// SilicaFlux TestCore :: sftc_jtag_tap   (TCK domain)
// IEEE 1149.1-style TAP: 16-state controller, 5-bit IR, BYPASS, IDCODE and
// selection of the TestCore data registers (TC_REG via sftc_jtag_reg_bridge,
// TC_STATUS).
//   * state, IR shift, DR capture/shift on the rising edge of TCK;
//   * IR parallel register updates on the falling edge in Update-IR and is
//     forced to IDCODE in Test-Logic-Reset / by trst_n;
//   * TDO and TDO-enable change on the falling edge; TDO is driven only in
//     Shift-IR / Shift-DR;
//   * Capture-IR loads 5'b00001; unassigned opcodes (and EXTEST/SAMPLE, which
//     are reserved until a boundary-scan register exists) select BYPASS.
// trst_n = TRST* pin AND power-on reset (the TAP must reset at power-up).
// Design follows the TAP in the earlier in-repo TestCore (tc_tap.sv) and the
// SilicaFlux-V sfv_jtag_tap; NOT IEEE 1149.1 conformance-tested.
// Classification: SYNTHESIZABLE (TCK domain; negedge flops: exclude from
// functional scan chains or place on a dedicated chain)
// =============================================================================
`default_nettype none

module sftc_jtag_tap
(
  input  wire logic        tck,
  input  wire logic        trst_n,
  input  wire logic        tms,
  input  wire logic        tdi,
  output logic             tdo,
  output logic             tdo_oe,
  output logic [3:0]       state_o,
  output logic [4:0] ir_o,
  output logic             sel_reg,      // IR == TC_REG
  output logic             sel_status,   // IR == TC_STATUS
  input  wire logic        tdo_reg_i,
  input  wire logic        tdo_status_i
);
  `include "sftc_consts.svh"

  logic [3:0] state;
  always_ff @(posedge tck or negedge trst_n) begin
    if (!trst_n) state <= TAP_TLR;
    else         state <= tap_next(state, tms);
  end
  assign state_o = state;

  // ---------------------------------------------------------------- IR
  logic [IR_LEN-1:0] ir_sh, ir;
  always_ff @(posedge tck or negedge trst_n) begin
    if (!trst_n)                ir_sh <= IR_CAPTURE;
    else if (state == TAP_CAP_IR) ir_sh <= IR_CAPTURE;
    else if (state == TAP_SH_IR)  ir_sh <= {tdi, ir_sh[IR_LEN-1:1]};
  end
  // DFT: the IR is stored XOR-encoded against IDCODE so that every
  // falling-edge flop has a reset value of 0.  A negedge flop with an
  // asynchronous SET has no sky130hd scan cell; synthesis then builds it from a
  // rising-edge cell on an inverted TCK, which OpenROAD DFT stitched into a
  // RISING-edge chain (effective chain length off by one -- found by the
  // gate-level chain-continuity check).  Behaviour is unchanged.
  logic [IR_LEN-1:0] ir_x;
  always_ff @(negedge tck or negedge trst_n) begin
    if (!trst_n)                  ir_x <= '0;
    else if (state == TAP_TLR)    ir_x <= '0;
    else if (state == TAP_UPD_IR) ir_x <= ir_sh ^ IR_IDCODE;
  end
  assign ir = ir_x ^ IR_IDCODE;
  assign ir_o       = ir;
  assign sel_reg    = (ir == IR_TC_REG);
  assign sel_status = (ir == IR_TC_STATUS);
  wire   sel_id     = (ir == IR_IDCODE);

  // ---------------------------------------------------------------- BYPASS / IDCODE
  logic        bypass_q;
  logic [31:0] id_sh;
  always_ff @(posedge tck or negedge trst_n) begin
    if (!trst_n) begin
      bypass_q <= 1'b0; id_sh <= '0;
    end else if (state == TAP_CAP_DR) begin
      bypass_q <= 1'b0;
      if (sel_id) id_sh <= IDCODE_VALUE;
    end else if (state == TAP_SH_DR) begin
      bypass_q <= tdi;
      if (sel_id) id_sh <= {tdi, id_sh[31:1]};
    end
  end

  // ---------------------------------------------------------------- TDO
  logic tdo_mux;
  always_comb begin
    if (state == TAP_SH_IR)  tdo_mux = ir_sh[0];
    else if (sel_id)         tdo_mux = id_sh[0];
    else if (sel_reg)        tdo_mux = tdo_reg_i;
    else if (sel_status)     tdo_mux = tdo_status_i;
    else                     tdo_mux = bypass_q;
  end
  always_ff @(negedge tck or negedge trst_n) begin
    if (!trst_n) begin tdo <= 1'b0; tdo_oe <= 1'b0; end
    else begin
      tdo    <= tdo_mux;
      tdo_oe <= (state == TAP_SH_IR) || (state == TAP_SH_DR);
    end
  end
endmodule

`default_nettype wire
