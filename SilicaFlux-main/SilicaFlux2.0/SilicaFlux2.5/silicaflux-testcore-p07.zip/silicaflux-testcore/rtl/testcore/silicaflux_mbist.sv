// =============================================================================
// SilicaFlux TestCore :: silicaflux_mbist
// Shared, multi-bank, handshake-based March MBIST controller.
//
// Transaction model (common memory test interface, docs/testcore/mbist_interface.md)
//   request : t_req / t_gnt valid-ready.  t_we, t_addr, t_wdata, t_bank are
//             held stable from the first cycle t_req is high until t_gnt.
//   response: t_rvalid (+ t_rdata, t_rerr) exactly once per accepted read,
//             and once per accepted write when the bank's WRITE_RESP flag is
//             set.  Responses arrive in order, at least one cycle after
//             acceptance, after any number of cycles (variable latency).
//   One transaction is outstanding at a time.  The next operation is issued
//   only after the current one has completed (write: accepted [+ response];
//   read: response received and compared).  Hence a read is always checked
//   before its dependent write, and correctness does not depend on latency.
//
// Algorithms: March C- (10N), MATS+ (5N), checkerboard (2N), inverse
// checkerboard (2N), walking one ((2W+1)N), walking zero ((2W+1)N); each can
// be excluded at compile time through ALG_MASK.  After the algorithm, an
// optional scrub element (⇑ w(all-zero)) re-initialises the bank so that it
// can be returned to functional use; the scrub also runs after an abort or a
// stop-on-fail (once any outstanding transaction has completed).
//
// Banks: BANK_COUNT banks, each with its own width (BANK_WIDTHS, 8 bits per
// bank), depth (BANK_DEPTHS, 24 bits per bank, any value >= 2) and flags
// (BANK_FLAGS, 8 bits per bank: bit0 = WRITE_RESP).  Selected banks are tested
// one after another (bounded test power, one comparator).
//
// Robustness:
//   * request-acceptance and response timeouts (TIMEOUT cycles) -> ERROR
//     state (result INCONCLUSIVE/ERROR, no further requests until CLEAR);
//   * a response while no transaction is outstanding -> EF_SPURIOUS;
//   * START is refused (EF_ILLEGAL_START) when busy, not in MBIST mode, with
//     an empty mask, with a selected bank not owned by test, with an excluded
//     algorithm, or in the ERROR state -- never a false PASS;
//   * abort (request or loss of test_enable) is honoured at the next
//     transaction boundary, never by withdrawing an unaccepted request.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sftc_defs.svh"
`default_nettype none

module silicaflux_mbist
#(
  parameter int BANK_COUNT = 2,
  parameter int MAX_W      = 32,
  parameter int MAX_DEPTH  = 256,
  parameter logic [BANK_COUNT*8-1:0]  BANK_WIDTHS = {BANK_COUNT{8'd32}},
  parameter logic [BANK_COUNT*24-1:0] BANK_DEPTHS = {BANK_COUNT{24'd256}},
  parameter logic [BANK_COUNT*8-1:0]  BANK_FLAGS  = {BANK_COUNT{8'd0}},
  parameter logic [15:0] ALG_MASK  = 16'h003F,
  parameter int LOG_DEPTH  = 4,
  parameter int CNT_W      = 16,
  parameter int TIMEOUT    = 1024,
  localparam int AW = (MAX_DEPTH > 2) ? $clog2(MAX_DEPTH) : 1,
  localparam int BW = (BANK_COUNT > 1) ? $clog2(BANK_COUNT) : 1
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // control (pulses, already permission-checked by the register block)
  input  wire logic                   test_enable,
  input  wire logic                   start,
  input  wire logic                   abort,
  input  wire logic                   clear,
  input  wire logic [3:0]             cfg_algo,
  input  wire logic                   cfg_bg_chk,
  input  wire logic                   cfg_sof,
  input  wire logic                   cfg_scrub,
  input  wire logic [BANK_COUNT-1:0]  cfg_bank_mask,
  input  wire logic [BANK_COUNT-1:0]  bank_owned,
  // memory test bus
  output logic                        t_req,
  output logic                        t_we,
  output logic [AW-1:0]               t_addr,
  output logic [MAX_W-1:0]            t_wdata,
  output logic [BW-1:0]               t_bank,
  input  wire logic                   t_gnt,
  input  wire logic                   t_rvalid,
  input  wire logic [MAX_W-1:0]       t_rdata,
  input  wire logic                   t_rerr,
  input  wire logic                   t_stray_rvalid,   // response from a non-selected bank
  // status
  output logic                        busy,
  output logic                        done,
  output logic                        pass,
  output logic                        fail,
  output logic                        aborted,
  output logic                        error_st,
  output logic                        stopped,
  output logic                        scrubbing,
  output logic [3:0]                  state,
  output logic [BW-1:0]               cur_bank,
  output logic [2:0]                  cur_elem,
  output logic [AW-1:0]               cur_addr,
  output logic [3:0]                  run_algo,
  output logic [2:0]                  last_result,
  output logic [2:0]                  prev_result,
  output logic [BANK_COUNT-1:0]       banks_tested,
  output logic [BANK_COUNT-1:0]       banks_failed,
  output logic [BANK_COUNT-1:0]       banks_scrubbed,
  output logic [31:0]                 cycles,
  output logic                        ev_start_refused,
  output logic                        ev_timeout,
  output logic                        ev_spurious,
  output logic                        ev_mem_err,
  output logic                        ev_done,
  // failure log
  input  wire logic                   log_pop,
  output logic                        ff_valid,
  output logic [23:0]                 ff_info,
  output logic [AW-1:0]               ff_addr,
  output logic [MAX_W-1:0]            ff_exp,
  output logic [MAX_W-1:0]            ff_obs,
  output logic [CNT_W-1:0]            fail_count,
  output logic                        cnt_ovf,
  output logic [7:0]                  log_level,
  output logic                        log_ovf,
  output logic [23:0]                 log_info,
  output logic [AW-1:0]               log_addr,
  output logic [MAX_W-1:0]            log_synd
);
  `include "sftc_consts.svh"

  localparam int JW = $clog2(2 * MAX_W + 1) + 1;
  localparam int TW = (TIMEOUT > 1) ? $clog2(TIMEOUT + 1) : 1;

  localparam logic [3:0] S_IDLE = 4'd0, S_BANK = 4'd1, S_ELEM = 4'd2, S_ISSUE = 4'd3,
                         S_WAIT = 4'd4, S_BEND = 4'd5, S_DONE = 4'd6, S_ERROR = 4'd7;

  // ------------------------------------------------------------- run configuration (latched at start)
  logic [3:0]            r_algo;
  logic                  r_bg, r_sof, r_scrub;
  logic [BANK_COUNT-1:0] r_mask;

  // ------------------------------------------------------------- engine state
  logic [3:0]    st;
  logic [BW:0]   bank;          // one extra bit: must be able to hold BANK_COUNT (end of bank loop)
  wire  [BW-1:0] bank_i = bank[BW-1:0];
  logic [2:0]    elem_idx;
  logic [11:0]   elem_q;
  logic [1:0]    op_idx;
  logic [JW-1:0] walk_j;
  logic          in_scrub;
  logic          abort_pend, stop_pend, any_fail, spur_seen;
  logic [TW-1:0] tmo;

  // ------------------------------------------------------------- current-bank attributes
  wire [7:0]  b_w    = BANK_WIDTHS[bank_i*8 +: 8];
  wire [23:0] b_d    = BANK_DEPTHS[bank_i*24 +: 24];
  /* verilator lint_off UNUSEDSIGNAL */
  wire [7:0]  b_f    = BANK_FLAGS[bank_i*8 +: 8];   // bits 7:1 reserved
  /* verilator lint_on UNUSEDSIGNAL */
  wire        b_wrsp = b_f[0];
  wire [AW-1:0] b_last = AW'(b_d - 24'd1);

  // ------------------------------------------------------------- address generator
  logic          ag_load, ag_step, ag_dn, ag_end;
  logic [AW-1:0] addr;
  sftc_mbist_addr_gen #(.AW(AW)) u_ag (
    .clk, .rst_n, .load(ag_load), .dir_dn(ag_dn), .last(b_last), .step(ag_step),
    .addr, .at_end(ag_end)
  );

  // ------------------------------------------------------------- pattern generator
  logic             op_rd, op_last;
  logic [MAX_W-1:0] op_data, wmask;
  logic [7:0]       walk_bit;
  sftc_mbist_pattern #(.MAX_W(MAX_W), .JW(JW)) u_pat (
    .elem(elem_q), .op_idx, .walk_j, .addr0(addr[0]), .width(b_w), .bg_chk(r_bg),
    .scrub(in_scrub), .is_rd(op_rd), .data(op_data), .wmask, .last_op(op_last), .walk_bit
  );

  // ------------------------------------------------------------- comparator
  wire              in_wait   = (st == S_WAIT);
  wire              rsp_ok    = in_wait && t_rvalid;          // the response we are waiting for
  wire              cmp_en    = rsp_ok && op_rd;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [MAX_W-1:0] synd;            // observable for debug / waveform only
  /* verilator lint_on UNUSEDSIGNAL */
  logic             mism;
  sftc_mbist_cmp #(.MAX_W(MAX_W)) u_cmp (
    .cmp_en, .expected(op_data), .observed(t_rdata & wmask), .wmask, .rsp_err(t_rerr),
    .syndrome(synd), .mismatch(mism)
  );

  // ------------------------------------------------------------- start qualification
  wire alg_ok     = (cfg_algo < 4'(NUM_ALGS)) && ALG_MASK[cfg_algo];
  wire start_ok   = (st == S_IDLE) && test_enable && (cfg_bank_mask != '0) &&
                    ((cfg_bank_mask & ~bank_owned) == '0) && alg_ok;
  wire do_start   = start && start_ok;
  assign ev_start_refused = start && !start_ok;

  // ------------------------------------------------------------- failure log
  wire [23:0] ev_info = {walk_bit, 2'b00, op_idx, 1'b0, elem_idx, 8'(bank_i)};
  sftc_mbist_fail_log #(.MAX_W(MAX_W), .AW(AW), .LOG_DEPTH(LOG_DEPTH), .CNT_W(CNT_W)) u_log (
    .clk, .rst_n, .clear(clear || do_start),
    .ev(mism), .ev_info, .ev_addr(addr), .ev_exp(op_data), .ev_obs(t_rdata & wmask),
    .ff_valid, .ff_info, .ff_addr, .ff_exp, .ff_obs, .fail_count, .cnt_ovf,
    .pop(log_pop), .log_level, .log_ovf, .log_info, .log_addr, .log_synd
  );

  // ownership withdrawn or hard test-enable loss: stop at the transaction
  // boundary WITHOUT further writes (no scrub); the owner flags REINIT_REQUIRED
  wire own_lost   = !bank_owned[bank_i] || !test_enable;
  // ------------------------------------------------------------- op completion
  // A request, once presented, is held until accepted (req_hold).  A NEW
  // request is never presented in a cycle where ownership / test_enable is
  // missing: the decision is re-qualified combinationally, not only one cycle
  // earlier in S_ELEM (found by formal: fv_mbist F2 counterexample).
  logic req_hold;
  wire  req_out    = (st == S_ISSUE) && (req_hold || !own_lost);
  wire accepted   = req_out && t_gnt;
  wire wr_posted  = accepted && !op_rd && !b_wrsp;            // write completes on acceptance
  wire op_done    = wr_posted || rsp_ok;
  wire [11:0] nxt_elem = alg_elem(r_algo, elem_idx);
  wire stop_now   = abort_pend || abort || stop_pend || (mism && r_sof);

  // timeout: waiting for acceptance or for the response
  wire waiting    = (req_out && !t_gnt) || (st == S_WAIT && !t_rvalid);
  wire tmo_hit    = waiting && (32'(tmo) >= TIMEOUT - 1);

  assign ev_timeout  = tmo_hit;
  assign ev_spurious = (t_rvalid && !in_wait && st != S_ERROR) || t_stray_rvalid;
  assign ev_mem_err  = rsp_ok && t_rerr;

  // ------------------------------------------------------------- engine
  always_comb begin
    ag_load = 1'b0;
    ag_step = 1'b0;
    ag_dn   = elem_q[9] && !in_scrub;
    if (st == S_ELEM) begin
      ag_load = 1'b1;
      ag_dn   = (nxt_elem[11:10] != EK_END) && nxt_elem[9];
    end else if (op_done && op_last && !ag_end && !(stop_now && !in_scrub && r_scrub)) begin
      ag_step = !stop_now || in_scrub;
    end else if (op_done && stop_now && !in_scrub && r_scrub) begin
      ag_load = 1'b1;               // jump to the scrub element (ascending)
      ag_dn   = 1'b0;
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; bank <= '0; elem_idx <= '0; elem_q <= '0; op_idx <= '0; walk_j <= '0;
      in_scrub <= 1'b0; abort_pend <= 1'b0; stop_pend <= 1'b0; any_fail <= 1'b0; spur_seen <= 1'b0; tmo <= '0;
      req_hold <= 1'b0;
      r_algo <= ALG_MARCH_C_MINUS; r_bg <= 1'b0; r_sof <= 1'b0; r_scrub <= 1'b1; r_mask <= '0;
      done <= 1'b0; aborted <= 1'b0; stopped <= 1'b0; error_st <= 1'b0;
      last_result <= RES_NOT_RUN; prev_result <= RES_NOT_RUN;
      banks_tested <= '0; banks_failed <= '0; banks_scrubbed <= '0; cycles <= '0;
      ev_done <= 1'b0;
    end else begin
      ev_done <= 1'b0;
      req_hold <= req_out && !t_gnt;
      // ---- timeout counter
      if (!waiting) tmo <= '0;
      else if (!tmo_hit) tmo <= tmo + 1'b1;

      if (st != S_IDLE && st != S_ERROR && !(&cycles)) cycles <= cycles + 32'd1;

      if (mism) begin
        any_fail <= 1'b1;
        banks_failed[bank_i] <= 1'b1;
        if (r_sof) stop_pend <= 1'b1;
      end
      if (st != S_IDLE && st != S_ERROR && (abort || !test_enable)) abort_pend <= 1'b1;
      if (busy && ev_spurious) spur_seen <= 1'b1;

      case (st)
        // ----------------------------------------------------------------
        S_IDLE: begin
          if (clear) begin
            done <= 1'b0; aborted <= 1'b0; stopped <= 1'b0;
            banks_tested <= '0; banks_failed <= '0;
          end
          if (start && !start_ok) begin
            // a refused START must never leave a stale PASS visible to polling
            // software (found by the system tests): report NOT_RUN
            prev_result <= last_result; last_result <= RES_NOT_RUN; done <= 1'b0;
          end
          if (do_start) begin
            r_algo <= cfg_algo; r_bg <= cfg_bg_chk; r_sof <= cfg_sof; r_scrub <= cfg_scrub;
            r_mask <= cfg_bank_mask;
            bank <= '0; any_fail <= 1'b0; spur_seen <= 1'b0; abort_pend <= 1'b0; stop_pend <= 1'b0;
            done <= 1'b0; aborted <= 1'b0; stopped <= 1'b0;
            banks_tested <= '0; banks_failed <= '0; banks_scrubbed <= '0; cycles <= '0;
            prev_result <= last_result; last_result <= RES_RUNNING;
            st <= S_BANK;
          end
        end
        // ----------------------------------------------------------------
        S_BANK: begin
          if (abort_pend || stop_pend || (32'(bank) >= BANK_COUNT)) begin
            st <= S_DONE;
          end else if (r_mask[bank_i]) begin
            elem_idx <= '0; in_scrub <= 1'b0;
            st <= S_ELEM;
          end else begin
            bank <= bank + 1'b1;
          end
        end
        // ----------------------------------------------------------------
        S_ELEM: begin
          // ag_load is asserted combinationally in this state
          elem_q <= nxt_elem;
          op_idx <= '0; walk_j <= '0;
          if (own_lost) begin
            abort_pend <= 1'b1; st <= S_BEND;
          end else if (nxt_elem[11:10] == EK_END) begin
            if (r_scrub) begin in_scrub <= 1'b1; st <= S_ISSUE; end
            else         st <= S_BEND;
          end else begin
            st <= S_ISSUE;
          end
        end
        // ----------------------------------------------------------------
        S_ISSUE, S_WAIT: begin
          if (tmo_hit) begin
            st <= S_ERROR; error_st <= 1'b1;
            last_result <= RES_ERROR;
          end else if (st == S_ISSUE && !req_out) begin
            // ownership / enable lost before the request was presented
            abort_pend <= 1'b1; st <= S_BEND;
          end else begin
            if (accepted && !wr_posted) st <= S_WAIT;
            if (op_done) begin
              st <= S_ISSUE;
              if (own_lost) begin
                // ownership withdrawn under the engine: stop without scrub
                abort_pend <= 1'b1; st <= S_BEND;
              end else if (stop_now && !in_scrub) begin
                // honour abort / stop-on-fail at the transaction boundary
                if (r_scrub) begin in_scrub <= 1'b1; op_idx <= '0; walk_j <= '0; end
                else         st <= S_BEND;
              end else if (!op_last) begin
                op_idx <= op_idx + 2'd1;
                walk_j <= walk_j + 1'b1;
              end else if (!ag_end) begin
                op_idx <= '0; walk_j <= '0;
              end else if (in_scrub) begin
                st <= S_BEND;
              end else begin
                elem_idx <= elem_idx + 3'd1;
                st <= S_ELEM;
              end
            end
          end
        end
        // ----------------------------------------------------------------
        S_BEND: begin
          banks_tested[bank_i]   <= !abort_pend && !stop_pend;
          banks_scrubbed[bank_i] <= in_scrub;
          in_scrub <= 1'b0;
          bank <= bank + 1'b1;
          st <= S_BANK;
        end
        // ----------------------------------------------------------------
        S_DONE: begin
          done <= 1'b1; ev_done <= 1'b1;
          aborted <= abort_pend;
          stopped <= stop_pend && !abort_pend;
          // a protocol violation makes the run INCONCLUSIVE (ERROR), never a PASS
          last_result <= abort_pend ? RES_ABORTED :
                         ((spur_seen || ev_spurious) ? RES_ERROR : (any_fail ? RES_FAIL : RES_PASS));
          st <= S_IDLE;
        end
        // ----------------------------------------------------------------
        S_ERROR: begin
          if (clear) begin st <= S_IDLE; error_st <= 1'b0; end
        end
        default: st <= S_IDLE;
      endcase
    end
  end

  // ------------------------------------------------------------- outputs
  assign t_req     = req_out;
  assign t_we      = !op_rd;
  assign t_addr    = addr;
  assign t_wdata   = op_data;
  assign t_bank    = bank_i;

  assign busy      = (st != S_IDLE) && (st != S_ERROR);
  assign pass      = done && (last_result == RES_PASS);
  assign fail      = any_fail;
  assign scrubbing = in_scrub && busy;
  assign state     = st;
  assign cur_bank  = bank_i;
  assign cur_elem  = elem_idx;
  assign cur_addr  = addr;
  assign run_algo  = r_algo;

  // ------------------------------------------------------------- protocol assertions
`ifdef SFTC_CHECKS
  logic          p_req, p_we;
  logic [AW-1:0] p_addr;
  logic [MAX_W-1:0] p_wdata;
  logic [BW-1:0] p_bank;
  logic          p_valid, p_treq;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      p_valid <= 1'b0; p_treq <= 1'b0; p_req <= 1'b0; p_we <= 1'b0; p_addr <= '0; p_wdata <= '0; p_bank <= '0;
    end else begin
      p_valid <= 1'b1;
      p_req <= t_req && !t_gnt; p_treq <= t_req; p_we <= t_we; p_addr <= t_addr; p_wdata <= t_wdata; p_bank <= t_bank;
    end
  end
  always @(posedge clk) begin
    if (rst_n && p_valid) begin
      // P1: an unaccepted request is held with a stable payload (or the engine errored out)
      `SFTC_ASSERT(!p_req || (t_req && t_we == p_we && t_addr == p_addr && t_wdata == p_wdata &&
                              t_bank == p_bank) || st == S_ERROR, "request withdrawn or changed before acceptance")
      // P2: a NEW request is only issued to a selected bank that is owned by test
      `SFTC_ASSERT(!(t_req && !p_treq) || (bank_owned[t_bank] && r_mask[t_bank]), "request to a bank not owned by test")
      // P3: address within the selected bank
      `SFTC_ASSERT(!t_req || ({{(24-AW){1'b0}}, t_addr} <= (b_d - 24'd1)), "address beyond bank depth")
      // P4: a comparison only happens on the awaited response
      `SFTC_ASSERT(!mism || (st == S_WAIT && t_rvalid), "comparison without valid response")
      // P5: done is only raised from S_DONE (after the final transaction retired)
      `SFTC_ASSERT(!(ev_done && st != S_IDLE), "done raised while engine active")
    end
  end
`endif

`ifdef FORMAL
  // embedded formal-only properties on internal state (Yosys has no
  // hierarchical references in formal harnesses)
  always @(posedge clk) begin
    if (rst_n) begin
      // a new request needs the bank to be selected for this run
      if (t_req && st == S_ISSUE) assert (r_mask[bank_i] || own_lost);
      // the engine never reports PASS for a run with a protocol violation
      if (ev_done && last_result == RES_PASS) assert (!spur_seen && !any_fail);
      // bank index range while operating on a bank
      if (st == S_ELEM || st == S_ISSUE || st == S_WAIT || st == S_BEND) assert (32'(bank) < BANK_COUNT);
      // walk index never exceeds 2W
      if (st == S_ISSUE || st == S_WAIT) assert (walk_j <= JW'({b_w, 1'b0}));
    end
  end
`endif
endmodule

`default_nettype wire
