// =============================================================================
// SilicaFlux TestCore :: sftc_testcore_top
// TestCore integration top: JTAG TAP + CDC register bridge, register-bus
// arbiter (JTAG has priority over the system-bus port used by boot ROM / CPU),
// diagnostic registers, test-mode controller, shared MBIST engine and bank
// selector.  The MBIST-ready memory wrappers (each containing its ownership
// controller) live next to their memories and connect through the bank
// vectors below.
//
// Clock domains: tck (TAP, bridge TCK side) and clk (everything else; must be
// the memory clock of the tested banks).  The functional CPU clock may be
// stopped/gated; clk must run for MBIST and register access.
// Resets: trst_n (TRST* & POR) for the TCK domain, rst_n (TestCore system
// reset, synchronised deassertion by the SoC reset controller) for clk.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sftc_defs.svh"
`default_nettype none

module sftc_testcore_top
#(
  parameter int BANK_COUNT = 2,
  parameter int MAX_W      = 32,
  parameter int MAX_DEPTH  = 256,
  parameter logic [BANK_COUNT*8-1:0]  BANK_WIDTHS = {BANK_COUNT{8'd32}},
  parameter logic [BANK_COUNT*24-1:0] BANK_DEPTHS = {BANK_COUNT{24'd256}},
  parameter logic [BANK_COUNT*8-1:0]  BANK_FLAGS  = {BANK_COUNT{8'd0}},
  parameter logic [15:0] ALG_MASK  = 16'h003F,
  parameter int LOG_DEPTH  = 4,
  parameter int CNT_W      = 16,
  parameter int TIMEOUT    = 1024,
  parameter bit PIPE_REQ   = 1'b0,
  parameter bit PIPE_RSP   = 1'b0,
  localparam int AW = (MAX_DEPTH > 2) ? $clog2(MAX_DEPTH) : 1,
  localparam int NB = BANK_COUNT
) (
  // ---- JTAG
  input  wire logic                tck,
  input  wire logic                trst_n,
  input  wire logic                tms,
  input  wire logic                tdi,
  output logic                     tdo,
  output logic                     tdo_oe,
  // ---- system domain
  input  wire logic                clk,
  /* verilator lint_off SYNCASYNCNET */
  input  wire logic                rst_n,          // also sampled as status data by the TCK domain (intentional)
  /* verilator lint_on SYNCASYNCNET */
  // permissions / strap / tester pins
  input  wire logic                hw_dbg_en,
  input  wire logic                hw_test_en,
  input  wire logic                cpu_halted,
  input  wire logic                scan_mode_pin,
  input  wire logic                scan_en_pin,
  // system-bus register port (boot ROM / CPU)
  input  wire logic                s_req,
  input  wire logic                s_we,
  input  wire logic [11:0]         s_addr,
  input  wire logic [31:0]         s_wdata,
  output logic                     s_gnt,
  output logic [31:0]              s_rdata,
  output logic                     s_err,
  // bank test buses
  output logic [NB-1:0]            b_req,
  output logic                     b_we,
  output logic [AW-1:0]            b_addr,
  output logic [MAX_W-1:0]         b_wdata,
  input  wire logic [NB-1:0]       b_gnt,
  input  wire logic [NB-1:0]       b_rvalid,
  input  wire logic [NB*MAX_W-1:0] b_rdata,
  input  wire logic [NB-1:0]       b_rerr,
  // ownership coupling (to/from the bank wrappers)
  output logic [NB-1:0]            acq_req,
  output logic [NB-1:0]            scrub_done,
  output logic                     mbist_busy,
  output logic                     owner_fault_clear,
  input  wire logic [NB*3-1:0]     owner_state,
  input  wire logic [NB-1:0]       owned,
  input  wire logic [NB-1:0]       owner_dirty,
  input  wire logic [NB-1:0]       owner_ev_fault,
  input  wire logic [NB-1:0]       owner_ev_intrusion,
  input  wire logic [NB-1:0]       owner_ev_reinit,
  // outputs
  output logic [2:0]               mode,
  output logic                     scan_mode,
  output logic                     scan_en,
  output logic                     irq,
  output logic                     test_done_o,      // status pins for wafer probe
  output logic                     test_pass_o,
  output logic                     test_fail_o,
  output logic                     jtag_mode_o,      // JTAG_ACCESS session active (SoC debug muxing)
  output logic                     diag_mode_o       // DIAGNOSTIC mode active (SoC status routing)
);
  `include "sftc_consts.svh"

  localparam int BW = (NB > 1) ? $clog2(NB) : 1;

  // ===================================================================== JTAG
  logic [3:0] tap_state;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [IR_LEN-1:0] ir;          // current instruction (observability)
  logic launch_tck, exec_sys;     // bridge handshake events (assertions / formal)
  /* verilator lint_on UNUSEDSIGNAL */
  logic sel_reg, sel_status, tdo_reg, tdo_status;
  sftc_jtag_tap u_tap (
    .tck, .trst_n, .tms, .tdi, .tdo, .tdo_oe, .state_o(tap_state), .ir_o(ir),
    .sel_reg, .sel_status, .tdo_reg_i(tdo_reg), .tdo_status_i(tdo_status)
  );

  logic j_req, j_we, j_gnt, j_err;
  logic [11:0] j_addr;
  logic [31:0] j_wdata, j_rdata;
  sftc_jtag_reg_bridge u_bridge (
    .tck, .trst_n, .tap_state, .sel_reg, .sel_status, .tdi, .tdo_reg, .tdo_status,
    .clk, .rst_n, .m_req(j_req), .m_we(j_we), .m_addr(j_addr), .m_wdata(j_wdata),
    .m_gnt(j_gnt), .m_rdata(j_rdata), .m_err(j_err), .launch_tck, .exec_sys
  );

  // ===================================================================== register bus arbiter
  logic        r_req, r_we, r_gnt, r_err;
  logic [11:0] r_addr;
  logic [31:0] r_wdata, r_rdata;
  wire j_sel = j_req;                       // JTAG has priority
  assign r_req   = j_req || s_req;
  assign r_we    = j_sel ? j_we    : s_we;
  assign r_addr  = j_sel ? j_addr  : s_addr;
  assign r_wdata = j_sel ? j_wdata : s_wdata;
  assign j_gnt   = j_sel && r_gnt;
  assign j_rdata = r_rdata;
  assign j_err   = r_err;
  assign s_gnt   = !j_sel && s_req && r_gnt;
  assign s_rdata = j_sel ? 32'd0 : r_rdata;
  assign s_err   = !j_sel && r_err;

  // ===================================================================== registers
  logic c_start, c_abort, c_clear, c_bg, c_sof, c_scrub, c_pop, mreq_v, unlocked;
  logic [3:0] c_algo;
  logic [2:0] mreq;
  logic [NB-1:0] c_mask, protect;
  logic [2:0] mode_pend;
  logic mode_busy, mbist_enable, mbist_abort, jtag_mode, diag_mode, ev_illegal, ev_denied;

  // MBIST status
  logic m_busy, m_done, m_pass, m_fail, m_aborted, m_error, m_stopped, m_scrub;
  logic [3:0] m_state, m_algo;
  logic [BW-1:0] m_bank;
  logic [2:0] m_elem, m_last, m_prev;
  logic [AW-1:0] m_addr;
  logic [NB-1:0] m_tested, m_failed, m_scrubbed;
  logic [31:0] m_cycles;
  logic ev_refused, ev_tmo, ev_spur, ev_merr, ev_done;
  logic ff_valid, cnt_ovf, log_ovf;
  logic [23:0] ff_info, log_info;
  logic [AW-1:0] ff_addr, log_addr;
  logic [MAX_W-1:0] ff_exp, ff_obs, log_synd;
  logic [CNT_W-1:0] fail_count;
  logic [7:0] log_level;

  logic cnt_ovf_q, log_ovf_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin cnt_ovf_q <= 1'b0; log_ovf_q <= 1'b0; end
    else        begin cnt_ovf_q <= cnt_ovf; log_ovf_q <= log_ovf; end
  end

  logic [NUM_EF-1:0] ev_flags;
  always_comb begin
    ev_flags = '0;
    ev_flags[EF_TIMEOUT]       = ev_tmo;
    ev_flags[EF_SPURIOUS]      = ev_spur;
    ev_flags[EF_ILLEGAL_START] = ev_refused;
    ev_flags[EF_CNT_OVF]       = cnt_ovf && !cnt_ovf_q;
    ev_flags[EF_LOG_OVF]       = log_ovf && !log_ovf_q;
    ev_flags[EF_MEM_ERR]       = ev_merr;
    ev_flags[EF_OWNER_FAULT]   = |owner_ev_fault;
    ev_flags[EF_INTRUSION]     = |owner_ev_intrusion;
    ev_flags[EF_ILLEGAL_MODE]  = ev_illegal || ev_denied;
    ev_flags[EF_REINIT_REQ]    = |owner_ev_reinit;
  end

  sftc_regs #(
    .BANK_COUNT(NB), .MAX_W(MAX_W), .AW(AW), .CNT_W(CNT_W), .BANK_WIDTHS(BANK_WIDTHS),
    .BANK_DEPTHS(BANK_DEPTHS), .BANK_FLAGS(BANK_FLAGS), .ALG_MASK(ALG_MASK), .LOG_DEPTH(LOG_DEPTH)
  ) u_regs (
    .clk, .rst_n, .req(r_req), .we(r_we), .addr(r_addr), .wdata(r_wdata), .gnt(r_gnt),
    .rdata(r_rdata), .err(r_err),
    .c_start, .c_abort, .c_clear, .c_algo, .c_bg_chk(c_bg), .c_sof, .c_scrub, .c_mask,
    .c_log_pop(c_pop), .mode_req_valid(mreq_v), .mode_req(mreq), .unlocked, .protect,
    .owner_fault_clear, .irq,
    .mode, .mode_busy, .mode_pending(mode_pend), .hw_test_en, .hw_dbg_en, .scan_pin(scan_mode_pin),
    .owner_state, .owner_dirty,
    .m_busy, .m_done, .m_pass, .m_fail, .m_aborted, .m_error, .m_stopped, .m_scrubbing(m_scrub),
    .m_state, .m_bank, .m_elem, .m_addr, .m_algo, .m_last, .m_prev, .m_tested, .m_failed,
    .m_cycles, .m_ff_valid(ff_valid), .m_ff_info(ff_info), .m_ff_addr(ff_addr), .m_ff_exp(ff_exp),
    .m_ff_obs(ff_obs), .m_fail_count(fail_count), .m_log_level(log_level), .m_log_ovf(log_ovf),
    .m_log_info(log_info), .m_log_addr(log_addr), .m_log_synd(log_synd),
    .ev_flags, .ev_done
  );

  // ===================================================================== mode controller
  logic banks_released;
  always_comb begin
    banks_released = 1'b1;
    for (int k = 0; k < NB; k++)
      if (owner_state[k*3 +: 3] != OWN_NORMAL && owner_state[k*3 +: 3] != OWN_FAULT) banks_released = 1'b0;
  end

  silicaflux_test_mode_controller u_mode (
    .clk, .rst_n, .hw_dbg_en, .hw_test_en, .unlocked, .scan_mode_pin, .scan_en_pin,
    .req_valid(mreq_v), .req_mode(mreq), .mbist_busy(m_busy), .banks_released,
    .mode, .mode_busy, .pending(mode_pend), .mbist_enable, .mbist_abort, .jtag_mode, .diag_mode,
    .scan_mode, .scan_en, .ev_illegal, .ev_denied
  );

  // ===================================================================== MBIST
  logic t_req, t_we, t_gnt, t_rvalid, t_rerr, t_stray;
  logic [AW-1:0] t_addr;
  logic [MAX_W-1:0] t_wdata, t_rdata;
  logic [BW-1:0] t_bank;

  silicaflux_mbist #(
    .BANK_COUNT(NB), .MAX_W(MAX_W), .MAX_DEPTH(MAX_DEPTH), .BANK_WIDTHS(BANK_WIDTHS),
    .BANK_DEPTHS(BANK_DEPTHS), .BANK_FLAGS(BANK_FLAGS), .ALG_MASK(ALG_MASK), .LOG_DEPTH(LOG_DEPTH),
    .CNT_W(CNT_W), .TIMEOUT(TIMEOUT)
  ) u_mbist (
    .clk, .rst_n, .test_enable(mbist_enable), .start(c_start), .abort(c_abort || mbist_abort),
    .clear(c_clear), .cfg_algo(c_algo), .cfg_bg_chk(c_bg), .cfg_sof(c_sof), .cfg_scrub(c_scrub),
    .cfg_bank_mask(c_mask), .bank_owned(owned),
    .t_req, .t_we, .t_addr, .t_wdata, .t_bank, .t_gnt, .t_rvalid, .t_rdata, .t_rerr,
    .t_stray_rvalid(t_stray),
    .busy(m_busy), .done(m_done), .pass(m_pass), .fail(m_fail), .aborted(m_aborted),
    .error_st(m_error), .stopped(m_stopped), .scrubbing(m_scrub), .state(m_state), .cur_bank(m_bank),
    .cur_elem(m_elem), .cur_addr(m_addr), .run_algo(m_algo), .last_result(m_last),
    .prev_result(m_prev), .banks_tested(m_tested), .banks_failed(m_failed),
    .banks_scrubbed(m_scrubbed), .cycles(m_cycles),
    .ev_start_refused(ev_refused), .ev_timeout(ev_tmo), .ev_spurious(ev_spur), .ev_mem_err(ev_merr),
    .ev_done, .log_pop(c_pop), .ff_valid, .ff_info, .ff_addr, .ff_exp, .ff_obs, .fail_count,
    .cnt_ovf, .log_level, .log_ovf, .log_info, .log_addr, .log_synd
  );

  sftc_mbist_bank_mux #(.BANK_COUNT(NB), .MAX_W(MAX_W), .AW(AW), .PIPE_REQ(PIPE_REQ),
                        .PIPE_RSP(PIPE_RSP)) u_mux (
    .clk, .rst_n, .t_req, .t_we, .t_addr, .t_wdata, .t_bank, .t_gnt, .t_rvalid, .t_rdata, .t_rerr,
    .stray_rvalid(t_stray), .b_req, .b_we, .b_addr, .b_wdata, .b_gnt, .b_rvalid, .b_rdata, .b_rerr
  );

  // ===================================================================== ownership coupling
  logic [NB-1:0] scrubbed_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) scrubbed_q <= '0;
    else        scrubbed_q <= m_scrubbed;
  end
  assign scrub_done = m_scrubbed & ~scrubbed_q;
  assign mbist_busy = m_busy;
  always_comb begin
    // acquisition requires MBIST mode, selection, and -- for a protected bank --
    // a halted CPU.  It is withdrawn during the MBIST exit sequence so that the
    // owners can release once the engine is idle (exit deadlock found in
    // system simulation: the mode controller waits for the release).
    for (int k = 0; k < NB; k++)
      acq_req[k] = mbist_enable && !mode_busy && c_mask[k] && (!protect[k] || cpu_halted);
  end

  // status pins (quasi-static, for wafer probe / boot-ROM POST observation)
  assign test_done_o = m_done;
  assign test_pass_o = m_pass;
  assign test_fail_o = m_done && !m_pass;
  assign jtag_mode_o = jtag_mode;
  assign diag_mode_o = diag_mode;

`ifdef SFTC_CHECKS
  always @(posedge clk) begin
    if (rst_n) begin
      `SFTC_ASSERT(!(|b_req) || mbist_enable || m_busy, "bank request outside MBIST mode")
    end
  end
`endif
endmodule

`default_nettype wire
