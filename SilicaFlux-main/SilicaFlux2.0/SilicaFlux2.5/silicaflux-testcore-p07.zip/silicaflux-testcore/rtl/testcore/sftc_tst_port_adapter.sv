// =============================================================================
// SilicaFlux TestCore :: sftc_tst_port_adapter
// Bridges the TestCore handshake test port (t_req/t_gnt, t_rvalid) to a RAW
// fixed-latency memory test port of the kind provided by the SRAM Wrapper
// Library (tst_ce/tst_we/tst_addr/tst_wdata -> tst_rdata valid exactly
// READ_LATENCY cycles after a read, never held) and by the SilicaFlux-V
// collar (bist_ce/... -> bist_rdata, latency 1).
//   * t_gnt = test_en: the raw port accepts one operation per cycle.
//   * writes are posted (no response); each accepted read produces exactly
//     one t_rvalid READ_LATENCY cycles later, with tst_rdata sampled then.
//   * t_busy reports reads in flight (used by the ownership controller to
//     drain before releasing the port).
// The raw port is driven only while the request is granted, so tst_ce is
// never asserted outside test ownership.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sftc_defs.svh"
`default_nettype none

module sftc_tst_port_adapter #(
  parameter int DW           = 32,
  parameter int AW           = 10,
  parameter int READ_LATENCY = 1
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          test_en,
  // TestCore handshake side
  input  wire logic          t_req,
  output logic               t_gnt,
  input  wire logic          t_we,
  input  wire logic [AW-1:0] t_addr,
  input  wire logic [DW-1:0] t_wdata,
  output logic               t_rvalid,
  output logic [DW-1:0]      t_rdata,
  output logic               t_rerr,
  output logic               t_busy,
  output logic               t_wr,
  // raw memory test port
  output logic               tst_ce,
  output logic               tst_we,
  output logic [AW-1:0]      tst_addr,
  output logic [DW-1:0]      tst_wdata,
  input  wire logic [DW-1:0] tst_rdata
);
  logic [READ_LATENCY-1:0] rd_pipe;
  wire acc = t_req && test_en;

  assign t_gnt     = test_en;
  assign tst_ce    = acc;
  assign tst_we    = t_we;
  assign tst_addr  = t_addr;
  assign tst_wdata = t_wdata;
  assign t_wr      = acc && t_we;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) rd_pipe <= '0;
    else if (READ_LATENCY == 1) rd_pipe <= READ_LATENCY'(acc && !t_we);
    else rd_pipe <= {rd_pipe[READ_LATENCY-2:0], acc && !t_we};
  end
  assign t_rvalid = rd_pipe[READ_LATENCY-1];
  assign t_rdata  = tst_rdata;
  assign t_rerr   = 1'b0;
  assign t_busy   = |rd_pipe;
endmodule

`default_nettype wire
