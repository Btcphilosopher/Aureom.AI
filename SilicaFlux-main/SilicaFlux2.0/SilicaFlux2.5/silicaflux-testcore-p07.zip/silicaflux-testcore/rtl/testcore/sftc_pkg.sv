// =============================================================================
// SilicaFlux TestCore :: sftc_pkg
// Package wrapper around sftc_consts.svh (the single authoritative definition
// of TestCore encodings) for testbenches and tools that support packages.
// Synthesizable RTL includes sftc_consts.svh directly in each module body.
// =============================================================================
`ifndef SFTC_PKG_SV
`define SFTC_PKG_SV
package sftc_pkg;
`include "sftc_consts.svh"
endpackage
`endif
