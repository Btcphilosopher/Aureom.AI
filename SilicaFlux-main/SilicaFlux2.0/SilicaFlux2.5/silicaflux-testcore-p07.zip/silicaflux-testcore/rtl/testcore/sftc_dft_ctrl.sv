// =============================================================================
// SilicaFlux TestCore :: sftc_dft_ctrl
// Scan-mode control signals for the SoC's DFT insertion points.  Purely
// combinational from tester pins (no flop in the control path, so the values
// are valid while every scan flop -- including TestCore's own -- is shifting).
//   * scan_mode        = scan_mode_pin & hw_test_en (static during a session)
//   * scan_en          = scan_mode & scan_en_pin     (shift = 1, capture = 0)
//   * rst_n_dft[i]     = scan_mode ? scan_rst_n_pin : rst_n_func[i]
//                        (async resets controllable by ATPG; fixes the
//                         SilicaFlux-V finding that the synchroniser flops'
//                         reset inputs are driven by internal logic)
//   * icg_te           = scan_en (ICG test enable follows SCAN ENABLE, not
//                        test_mode, so the functional enable logic of gated
//                        clocks is observed in capture cycles)
//   * mem_inhibit      = scan_mode (functional CE/WE of memory macros gated
//                        during shift and capture: no random writes, bounded
//                        shift power; memories are black boxes for ATPG)
//   * clk_sel_test     = scan_mode (root clock mux selects the tester clock)
// The clock mux is a behavioural placeholder: map to a library glitch-free
// mux cell / OCC.  The select is static during a scan session (the tester
// sets scan_mode_pin before applying clocks), so no glitch can occur in
// this flow; at-speed capture requires an on-chip clock controller (not
// implemented).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sftc_dft_ctrl #(
  parameter int NRST = 3
) (
  input  wire logic            scan_mode_pin,
  input  wire logic            scan_en_pin,
  input  wire logic            scan_rst_n_pin,
  input  wire logic            hw_test_en,
  input  wire logic [NRST-1:0] rst_n_func,
  input  wire logic            clk_func,
  input  wire logic            clk_test,
  output logic                 scan_mode,
  output logic                 scan_en,
  output logic [NRST-1:0]      rst_n_dft,
  output logic                 icg_te,
  output logic                 mem_inhibit,
  output logic                 clk_out
);
  assign scan_mode   = scan_mode_pin && hw_test_en;
  assign scan_en     = scan_mode && scan_en_pin;
  assign rst_n_dft   = scan_mode ? {NRST{scan_rst_n_pin}} : rst_n_func;
  assign icg_te      = scan_en;
  assign mem_inhibit = scan_mode;
  assign clk_out     = scan_mode ? clk_test : clk_func;   // placeholder for library clock-mux cell
endmodule
`default_nettype wire
