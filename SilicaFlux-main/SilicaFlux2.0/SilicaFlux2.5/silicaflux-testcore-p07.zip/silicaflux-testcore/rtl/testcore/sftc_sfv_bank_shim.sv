// =============================================================================
// SilicaFlux TestCore :: sftc_sfv_bank_shim
// Integration shim for one SilicaFlux-V SRAM bank (`sfv_sram_slave`, release 1,
// vendored unmodified in third_party/silicaflux-v).  Placed between the
// crossbar slave port and the existing MBIST collar (bist_*):
//   * crossbar req/gnt pass through, gated by the ownership controller;
//   * the collar's bist_en is driven by the owner's sel_test (the slave itself
//     already blocks functional grants while bist_en = 1);
//   * test operations reach the collar through the latency-1 adapter.
// The SFV slave answers every accepted functional request one cycle later
// (rvalid), so "functional in flight" = acceptance this cycle or rvalid.
// No change to sfv_sram_slave or to its macro is required.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sftc_sfv_bank_shim #(
  parameter int DEPTH       = 8192,
  parameter int OWN_TIMEOUT = 4096,
  localparam int AW = $clog2(DEPTH)
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  // crossbar slave port (SFB, as sfv_sram_slave)
  input  wire logic          req,
  output logic               gnt,
  input  wire logic [31:0]   addr,
  input  wire logic          we,
  input  wire logic [3:0]    be,
  input  wire logic [31:0]   wdata,
  output logic               rvalid,
  output logic [31:0]        rdata,
  output logic               err,
  // TestCore test port
  input  wire logic          t_req,
  output logic               t_gnt,
  input  wire logic          t_we,
  input  wire logic [AW-1:0] t_addr,
  input  wire logic [31:0]   t_wdata,
  output logic               t_rvalid,
  output logic [31:0]        t_rdata,
  output logic               t_rerr,
  // ownership
  input  wire logic          acq_req,
  input  wire logic          fault_clear,
  input  wire logic          quiesce_ack,
  output logic               quiesce_req,
  input  wire logic          mbist_busy,
  input  wire logic          scrub_done,
  output logic               owned,
  output logic [2:0]         owner_state,
  output logic               dirty,
  output logic               ev_fault,
  output logic               ev_intrusion,
  output logic               ev_reinit_req
);
  logic f_block, sel_test, test_en, t_busy, t_wr, f_busy, s_gnt;
  logic bist_ce, bist_we;
  logic [AW-1:0] bist_addr;
  logic [31:0] bist_wdata, bist_rdata;

  sftc_mem_owner #(.TIMEOUT(OWN_TIMEOUT)) u_owner (
    .clk, .rst_n, .acq_req, .fault_clear, .quiesce_ack, .f_busy, .f_req(req), .mbist_busy,
    .t_busy, .t_wr, .scrub_done, .quiesce_req, .f_block, .sel_test, .test_en, .owned,
    .state(owner_state), .dirty, .ev_fault, .ev_intrusion, .ev_reinit_req
  );

  sftc_tst_port_adapter #(.DW(32), .AW(AW), .READ_LATENCY(1)) u_adapt (
    .clk, .rst_n, .test_en, .t_req, .t_gnt, .t_we, .t_addr, .t_wdata, .t_rvalid, .t_rdata, .t_rerr,
    .t_busy, .t_wr, .tst_ce(bist_ce), .tst_we(bist_we), .tst_addr(bist_addr), .tst_wdata(bist_wdata),
    .tst_rdata(bist_rdata)
  );

  sfv_sram_slave #(.DEPTH(DEPTH)) u_slave (
    .clk, .rst_n, .req(req && !f_block), .gnt(s_gnt), .addr, .we, .be, .wdata, .rvalid, .rdata, .err,
    .bist_en(sel_test), .bist_ce, .bist_we, .bist_addr, .bist_wdata, .bist_rdata
  );
  assign gnt    = s_gnt && !f_block;
  assign f_busy = (req && gnt) || rvalid;
endmodule

`default_nettype wire
