// =============================================================================
// SilicaFlux TestCore :: sftc_jtag_reg_bridge
// TC_REG data register (46 bits) + TC_STATUS register (8 bits) and the
// TCK -> system-clock crossing for TestCore register access.
//
//   TC_REG DR [45:44] OP (scan-in) / STATUS (capture)  [43:32] ADDR  [31:0] DATA
//     OP     : 0 NOP, 1 READ, 2 WRITE, 3 CLEAR (clear sticky busy)
//     STATUS : 0 OK, 2 ERROR (unmapped / read-only), 3 BUSY
//   A request is launched at Update-DR; its result is returned by the NEXT
//   Capture-DR of TC_REG.  If that capture finds the request still in flight
//   it returns BUSY and sets a sticky flag: every further request is ignored
//   until CLEAR is scanned, so the host always knows whether a request was
//   dropped (no silent loss, no duplication).
//
// CDC protocol (toggle handshake, one request in flight):
//   * TCK side: payload registers (we/addr/data) are written only when idle,
//     then req_tgl is toggled; they are held stable until the acknowledge
//     toggle returns (synchronised).  -> multibit payload is never sampled
//     while changing.
//   * system side: req_tgl is synchronised (2 FF); a difference between the
//     synchronised toggle and req_seen is exactly one pending request; it is
//     executed once (register bus handshake), its result is stored in
//     system-domain registers and then req_seen := req_sync (= ack toggle).
//   * TCK side reads the result registers only when ack has returned, i.e.
//     at least two TCK edges after they last changed.
//   * After a system-domain reset the receiver first adopts the current
//     toggle value (3 cycles) so a stale request is never replayed, then
//     signals sys_ready; the TCK side launches only when sys_ready (sync) is
//     seen, so no live request can be adopted.  A request caught in flight by
//     a system reset completes with STATUS = ERROR (res_err reset value).
// Requirements: the system clock must run for register access; with the
// system clock stopped requests stay BUSY (reported, not lost) and TC_STATUS
// shows sysclk_alive = 0.  Minimum Run-Test/Idle between Update-DR and the
// next Capture-DR: see docs/testcore/jtag.md (depends on f_sys / f_TCK).
//
//   TC_STATUS DR (8 bits, capture only): [0] request in flight, [1] sticky
//   busy, [2] system clock ran since the previous TC_STATUS capture (ping/pong), [3] TestCore system
//   reset asserted, [7:4] 4'h7 (TestCore P07 signature)
// Classification: SYNTHESIZABLE (TCK side: exclude from functional scan)
// =============================================================================
`default_nettype none

module sftc_jtag_reg_bridge
(
  // TCK domain
  input  wire logic        tck,
  input  wire logic        trst_n,        // TRST* & POR
  input  wire logic [3:0]  tap_state,
  input  wire logic        sel_reg,
  input  wire logic        sel_status,
  input  wire logic        tdi,
  output logic             tdo_reg,
  output logic             tdo_status,
  // system domain
  input  wire logic        clk,
  input  wire logic        rst_n,
  output logic             m_req,
  output logic             m_we,
  output logic [11:0]      m_addr,
  output logic [31:0]      m_wdata,
  input  wire logic        m_gnt,
  input  wire logic [31:0] m_rdata,
  input  wire logic        m_err,
  // observability (for assertions / coverage)
  output logic             launch_tck,    // pulse (TCK): request launched
  output logic             exec_sys       // pulse (clk): request executed
);
  `include "sftc_consts.svh"

  // ---------------------------------------------------------------- TCK side
  logic [REG_DR_LEN-1:0] sh;
  logic        req_tgl, sticky, pl_we;
  logic [11:0] pl_addr;
  logic [31:0] pl_data;
  logic        ack_tgl, ack_sync;
  logic [31:0] res_rdata;
  logic [11:0] res_addr;
  logic        res_err;

  logic sys_ready, rdy_sync;
  sftc_sync #(.W(1)) u_ack_sync (.clk(tck), .rst_n(trst_n), .d(ack_tgl), .q(ack_sync));
  sftc_sync #(.W(1)) u_rdy_sync (.clk(tck), .rst_n(trst_n), .d(sys_ready), .q(rdy_sync));
  // busy: a request in flight, OR the system side is not (yet) ready -- in
  // reset or still arming.  No request is launched before the system side
  // has armed, so the arming step can never swallow a live request (formal
  // fv_bridge counterexample on the earlier design).
  wire busy_now = (req_tgl != ack_sync) || !rdy_sync;

  wire cap = sel_reg && (tap_state == TAP_CAP_DR);
  wire sft = sel_reg && (tap_state == TAP_SH_DR);
  wire upd = sel_reg && (tap_state == TAP_UPD_DR);
  wire [1:0] op = sh[45:44];

  always_ff @(posedge tck or negedge trst_n) begin
    if (!trst_n) sh <= '0;
    else if (cap) begin
      if (busy_now || sticky) sh <= {REGST_BUSY, 12'd0, 32'd0};
      else                    sh <= {res_err ? REGST_ERR : REGST_OK, res_addr, res_rdata};
    end else if (sft) begin
      sh <= {tdi, sh[REG_DR_LEN-1:1]};
    end
  end

  always_ff @(posedge tck or negedge trst_n) begin
    if (!trst_n) begin
      req_tgl <= 1'b0; sticky <= 1'b0; pl_we <= 1'b0; pl_addr <= '0; pl_data <= '0;
    end else begin
      if (cap && busy_now) sticky <= 1'b1;
      if (upd) begin
        if (sticky) begin
          if (op == REGOP_CLEAR && !busy_now) sticky <= 1'b0;
        end else if (op == REGOP_READ || op == REGOP_WRITE) begin
          if (busy_now) sticky <= 1'b1;
          else begin
            pl_we <= (op == REGOP_WRITE); pl_addr <= sh[43:32]; pl_data <= sh[31:0];
            req_tgl <= ~req_tgl;
          end
        end
      end
    end
  end
  assign launch_tck = upd && !sticky && (op == REGOP_READ || op == REGOP_WRITE) && !busy_now;
  assign tdo_reg    = sh[0];

  // ---------------------------------------------------------------- TC_STATUS
  // Clock-alive detection by ping/pong echo: each capture toggles `ping`; the
  // system domain echoes it back (`pong`).  At the next capture, alive = the
  // echo has returned, i.e. the system clock ran (>= ~2 cycles + sync) since
  // the previous capture.  Robust for any clock ratio (no aliasing).
  logic [7:0] st_sh;
  logic       ping, pong, ping_sync, pong_sync, rst_sync;
  sftc_sync #(.W(1)) u_pong_sync (.clk(tck), .rst_n(trst_n), .d(pong), .q(pong_sync));
  /* verilator lint_off SYNCASYNCNET */
  // system reset observed as status data in the TCK domain (intentional)
  sftc_sync #(.W(1)) u_rs_sync (.clk(tck), .rst_n(trst_n), .d(!rst_n), .q(rst_sync));
  /* verilator lint_on SYNCASYNCNET */
  wire scap = sel_status && (tap_state == TAP_CAP_DR);
  wire ssft = sel_status && (tap_state == TAP_SH_DR);
  always_ff @(posedge tck or negedge trst_n) begin
    if (!trst_n) begin st_sh <= '0; ping <= 1'b0; end
    else if (scap) begin
      st_sh <= {4'h7, rst_sync, (pong_sync == ping), sticky, busy_now};
      ping  <= ~ping;
    end else if (ssft) st_sh <= {tdi, st_sh[7:1]};
  end
  assign tdo_status = st_sh[0];

  // ---------------------------------------------------------------- system side
  logic       req_sync, req_seen;
  logic [1:0] arm_cnt;
  sftc_sync #(.W(1)) u_req_sync (.clk, .rst_n, .d(req_tgl), .q(req_sync));
  sftc_sync #(.W(1)) u_ping_sync (.clk, .rst_n, .d(ping), .q(ping_sync));

  wire armed   = (arm_cnt == 2'd3);
  wire pending = armed && (req_sync != req_seen);
  assign m_req   = pending;
  assign m_we    = pl_we;       // TCK-domain registers, stable while pending (protocol)
  assign m_addr  = pl_addr;
  assign m_wdata = pl_data;
  assign exec_sys = pending && m_gnt;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      // res_err = 1: a request that was in flight when the system domain was
      // reset is reported as ERROR at the next capture (never a stale OK)
      arm_cnt <= 2'd0; req_seen <= 1'b0; res_rdata <= '0; res_addr <= '0; res_err <= 1'b1;
      pong <= 1'b0;
    end else begin
      pong <= ping_sync;
      if (!armed) begin
        arm_cnt  <= arm_cnt + 2'd1;
        req_seen <= req_sync;            // adopt: never replay a stale request
      end else if (pending && m_gnt) begin
        res_rdata <= m_we ? 32'd0 : m_rdata;
        res_addr  <= pl_addr;
        res_err   <= m_err;
        req_seen  <= req_sync;
      end
    end
  end
  assign ack_tgl   = req_seen;
  assign sys_ready = armed;
endmodule

`default_nettype wire
