// =============================================================================
// SilicaFlux TestCore :: sftc_sync
// Two-flop synchroniser for single-bit (or Gray / quasi-static) signals.
// ASIC: replace by the library's MTBF-characterised synchroniser cell and
// mark dont_touch; exclude from scan or put on a dedicated chain.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sftc_sync #(
  parameter int W = 1,
  parameter logic [W-1:0] RST_VAL = '0
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic [W-1:0] d,
  output logic      [W-1:0] q
);
  (* async_reg = "true" *) logic [W-1:0] s1, s2;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin s1 <= RST_VAL; s2 <= RST_VAL; end
    else        begin s1 <= d;       s2 <= s1;      end
  end
  assign q = s2;
endmodule
`default_nettype wire
