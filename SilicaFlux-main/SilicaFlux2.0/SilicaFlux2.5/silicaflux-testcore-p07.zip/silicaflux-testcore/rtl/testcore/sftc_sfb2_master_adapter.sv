// =============================================================================
// SilicaFlux TestCore :: sftc_sfb2_master_adapter
// DataFabric (SFB2, docs/datafabric/PROTOCOL.md of Project 03) master port for
// the TestCore memory-test bus: lets the MBIST engine test a memory THROUGH
// the fabric path (crossbar / register slices / sfb_sram_slave), e.g. to
// cover the interconnect datapath or memories without a dedicated test port.
//   t_req/t_gnt   <-> req_valid/req_ready  (payload held until accepted)
//   writes        -> req_write=1, req_wstrb = all ones (full-word test writes)
//   t_rvalid      <- rsp_valid (rsp_ready = 1: the engine always waits)
//   t_rerr        <- rsp_error
// SFB2 acknowledges every write (one response per request), so the bank must be
// declared with BANK_FLAGS.WRITE_RESP = 1.  One transaction outstanding (the
// engine guarantees it), which satisfies SFB2 rule R6.
// This path is NOT isolated by an ownership controller: the fabric's other
// masters must be quiesced by the SoC (e.g. CPU halted, DMA idle) before use.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sftc_sfb2_master_adapter #(
  parameter int DW = 32,
  parameter int AW = 13,
  parameter logic [31:0] BASE = 32'h0,
  localparam int SB = DW / 8,
  localparam int OFF = (DW > 8) ? $clog2(DW / 8) : 0
) (
  input  wire logic          t_req,
  output logic               t_gnt,
  input  wire logic          t_we,
  input  wire logic [AW-1:0] t_addr,
  input  wire logic [DW-1:0] t_wdata,
  output logic               t_rvalid,
  output logic [DW-1:0]      t_rdata,
  output logic               t_rerr,
  output logic               req_valid,
  input  wire logic          req_ready,
  output logic               req_write,
  output logic [31:0]        req_addr,
  output logic [DW-1:0]      req_wdata,
  output logic [SB-1:0]      req_wstrb,
  input  wire logic          rsp_valid,
  output logic               rsp_ready,
  input  wire logic [DW-1:0] rsp_rdata,
  input  wire logic          rsp_error
);
  assign req_valid = t_req;
  assign t_gnt     = req_ready;
  assign req_write = t_we;
  assign req_addr  = BASE + (32'(t_addr) << OFF);
  assign req_wdata = t_wdata;
  assign req_wstrb = '1;
  assign rsp_ready = 1'b1;
  assign t_rvalid  = rsp_valid;
  assign t_rdata   = rsp_rdata;
  assign t_rerr    = rsp_error;
endmodule
`default_nettype wire
