// =============================================================================
// SilicaFlux TestCore :: sftc_mbist_cmp
// Expected-data comparator.  The comparison is performed ONLY on a response
// that the engine has qualified as the read it is waiting for (cmp_en); the
// observed word comes straight from the memory response bus (no forwarding
// path from the write data exists in the engine).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sftc_mbist_cmp #(
  parameter int MAX_W = 32
) (
  input  wire logic             cmp_en,
  input  wire logic [MAX_W-1:0] expected,
  input  wire logic [MAX_W-1:0] observed,
  input  wire logic [MAX_W-1:0] wmask,
  input  wire logic             rsp_err,
  output logic [MAX_W-1:0]      syndrome,
  output logic                  mismatch
);
  assign syndrome = (expected ^ observed) & wmask;
  assign mismatch = cmp_en && ((syndrome != '0) || rsp_err);
endmodule

`default_nettype wire
