// =============================================================================
// SilicaFlux TestCore (Project 07) :: sftc_consts.svh
// Single authoritative definition of TestCore encodings:
//   * MBIST algorithm identifiers and March-element micro-code
//   * test-mode encodings
//   * JTAG instruction opcodes
//   * register map (byte addresses on the 12-bit TestCore register bus)
// The same values are mirrored in python/testcore/spec.py; the regression
// (scripts/check_spec.py) fails if the two copies disagree.
// Classification: SYNTHESIZABLE (constants and pure functions only)
// =============================================================================
// NOTE: no include guard on purpose.  This file is `included INSIDE every
// TestCore module body (Yosys has no support for SystemVerilog `import`), and
// wrapped by package sftc_pkg for testbenches.  All items are localparams /
// automatic functions, so repeated inclusion in different scopes is legal.


  // ------------------------------------------------------------------ revision
  // [31:24] major, [23:16] minor, [15:0] patch
  localparam logic [31:0] TC_REVISION = 32'h0200_0001;   // TestCore r2.0.1

  // ------------------------------------------------------------------ algorithms
  localparam logic [3:0] ALG_MARCH_C_MINUS = 4'd0;   // 10N
  localparam logic [3:0] ALG_MATS_PLUS     = 4'd1;   // 5N
  localparam logic [3:0] ALG_CHECKERBOARD  = 4'd2;   // 2N  w(CB) r(CB)
  localparam logic [3:0] ALG_INV_CHECKER   = 4'd3;   // 2N  w(~CB) r(~CB)
  localparam logic [3:0] ALG_WALK_ONE      = 4'd4;   // (2W+1)N
  localparam logic [3:0] ALG_WALK_ZERO     = 4'd5;   // (2W+1)N
  localparam int         NUM_ALGS          = 6;

  // March element micro-word (12 bits)
  //   [11:10] kind   0 = END, 1 = MARCH, 2 = WALK
  //   [9]     dir    0 = ascending, 1 = descending
  //   [8]     bg     background source: 0 = solid (all-zero word),
  //                  1 = logical checkerboard (bit i = i[0] ^ addr[0])
  //                  (OR-ed with the run-time checkerboard option for March)
  //   [7:6]   nops-1 (MARCH: 1..3 ops per address)
  //   [5:0]   ops    op k = ops[2k+1:2k] = {is_read, invert}
  //                  data = invert ? ~BG(addr) : BG(addr)
  //   WALK:   ops[0] = walking value (1 = walking one over BG, 0 = walking
  //           zero over ~BG); per address: for b in 0..W-1 {w(P_b), r(P_b)},
  //           then w(BG_restore).
  localparam logic [1:0] EK_END   = 2'd0;
  localparam logic [1:0] EK_MARCH = 2'd1;
  localparam logic [1:0] EK_WALK  = 2'd2;

  localparam logic [1:0] OP_W0 = 2'b00;
  localparam logic [1:0] OP_W1 = 2'b01;
  localparam logic [1:0] OP_R0 = 2'b10;
  localparam logic [1:0] OP_R1 = 2'b11;

  function automatic logic [11:0] mk_elem(input logic [1:0] kind, input logic dn,
                                          input logic bg, input logic [1:0] nops_m1,
                                          input logic [1:0] o2, input logic [1:0] o1,
                                          input logic [1:0] o0);
    mk_elem = {kind, dn, bg, nops_m1, o2, o1, o0};
  endfunction

  // Element table.  Index 0..7; an END word terminates the algorithm.
  function automatic logic [11:0] alg_elem(input logic [3:0] alg, input logic [2:0] idx);
    alg_elem = 12'd0;
    case (alg)
      ALG_MARCH_C_MINUS: case (idx)
        // M0 ⇕(w0)  M1 ⇑(r0,w1)  M2 ⇑(r1,w0)  M3 ⇓(r0,w1)  M4 ⇓(r1,w0)  M5 ⇕(r0)
        3'd0: alg_elem = mk_elem(EK_MARCH, 1'b0, 1'b0, 2'd0, OP_W0, OP_W0, OP_W0);
        3'd1: alg_elem = mk_elem(EK_MARCH, 1'b0, 1'b0, 2'd1, OP_W0, OP_W1, OP_R0);
        3'd2: alg_elem = mk_elem(EK_MARCH, 1'b0, 1'b0, 2'd1, OP_W0, OP_W0, OP_R1);
        3'd3: alg_elem = mk_elem(EK_MARCH, 1'b1, 1'b0, 2'd1, OP_W0, OP_W1, OP_R0);
        3'd4: alg_elem = mk_elem(EK_MARCH, 1'b1, 1'b0, 2'd1, OP_W0, OP_W0, OP_R1);
        3'd5: alg_elem = mk_elem(EK_MARCH, 1'b0, 1'b0, 2'd0, OP_W0, OP_W0, OP_R0);
        default: alg_elem = 12'd0;
      endcase
      ALG_MATS_PLUS: case (idx)
        // M0 ⇕(w0)  M1 ⇑(r0,w1)  M2 ⇓(r1,w0)
        3'd0: alg_elem = mk_elem(EK_MARCH, 1'b0, 1'b0, 2'd0, OP_W0, OP_W0, OP_W0);
        3'd1: alg_elem = mk_elem(EK_MARCH, 1'b0, 1'b0, 2'd1, OP_W0, OP_W1, OP_R0);
        3'd2: alg_elem = mk_elem(EK_MARCH, 1'b1, 1'b0, 2'd1, OP_W0, OP_W0, OP_R1);
        default: alg_elem = 12'd0;
      endcase
      ALG_CHECKERBOARD: case (idx)
        3'd0: alg_elem = mk_elem(EK_MARCH, 1'b0, 1'b1, 2'd0, OP_W0, OP_W0, OP_W0);
        3'd1: alg_elem = mk_elem(EK_MARCH, 1'b0, 1'b1, 2'd0, OP_W0, OP_W0, OP_R0);
        default: alg_elem = 12'd0;
      endcase
      ALG_INV_CHECKER: case (idx)
        3'd0: alg_elem = mk_elem(EK_MARCH, 1'b0, 1'b1, 2'd0, OP_W0, OP_W0, OP_W1);
        3'd1: alg_elem = mk_elem(EK_MARCH, 1'b0, 1'b1, 2'd0, OP_W0, OP_W0, OP_R1);
        default: alg_elem = 12'd0;
      endcase
      ALG_WALK_ONE: case (idx)
        3'd0: alg_elem = mk_elem(EK_WALK, 1'b0, 1'b0, 2'd0, 2'b00, 2'b00, 2'b01);
        default: alg_elem = 12'd0;
      endcase
      ALG_WALK_ZERO: case (idx)
        3'd0: alg_elem = mk_elem(EK_WALK, 1'b0, 1'b0, 2'd0, 2'b00, 2'b00, 2'b00);
        default: alg_elem = 12'd0;
      endcase
      default: alg_elem = 12'd0;
    endcase
  endfunction

  // ------------------------------------------------------------------ results
  localparam logic [2:0] RES_NOT_RUN = 3'd0;
  localparam logic [2:0] RES_PASS    = 3'd1;
  localparam logic [2:0] RES_FAIL    = 3'd2;
  localparam logic [2:0] RES_ABORTED = 3'd3;   // aborted by request / mode loss
  localparam logic [2:0] RES_ERROR   = 3'd4;   // protocol error / timeout: INCONCLUSIVE
  localparam logic [2:0] RES_RUNNING = 3'd5;

  // ERROR_FLAGS bit positions (sticky, write-1-to-clear)
  localparam int EF_TIMEOUT      = 0;   // request not accepted / response not returned in time
  localparam int EF_SPURIOUS     = 1;   // response with no outstanding request
  localparam int EF_ILLEGAL_START= 2;   // START refused (mode, ownership, empty mask, busy, algorithm)
  localparam int EF_CNT_OVF      = 3;   // FAIL_COUNT saturated
  localparam int EF_LOG_OVF      = 4;   // error FIFO full, records dropped
  localparam int EF_MEM_ERR      = 5;   // memory reported rsp_err (ECC/parity/bus error)
  localparam int EF_OWNER_FAULT  = 6;   // ownership controller entered FAULT
  localparam int EF_INTRUSION    = 7;   // functional request attempted while bank under test
  localparam int EF_ILLEGAL_MODE = 8;   // illegal / denied mode request
  localparam int EF_REINIT_REQ   = 9;   // bank returned to NORMAL without scrub
  localparam int EF_BUS_ERR      = 10;  // register access to unmapped address / write to RO
  localparam int NUM_EF          = 11;

  // ------------------------------------------------------------------ test modes
  localparam logic [2:0] MODE_NORMAL       = 3'd0;
  localparam logic [2:0] MODE_JTAG_ACCESS  = 3'd1;
  localparam logic [2:0] MODE_MBIST        = 3'd2;
  localparam logic [2:0] MODE_SCAN_SHIFT   = 3'd3;
  localparam logic [2:0] MODE_SCAN_CAPTURE = 3'd4;
  localparam logic [2:0] MODE_DIAGNOSTIC   = 3'd5;

  // Memory-ownership controller states
  localparam logic [2:0] OWN_NORMAL          = 3'd0;
  localparam logic [2:0] OWN_QUIESCE_REQUEST = 3'd1;
  localparam logic [2:0] OWN_WAIT_FOR_IDLE   = 3'd2;
  localparam logic [2:0] OWN_TEST_ACQUIRE    = 3'd3;
  localparam logic [2:0] OWN_TEST_ACTIVE     = 3'd4;
  localparam logic [2:0] OWN_TEST_COMPLETE   = 3'd5;
  localparam logic [2:0] OWN_TEST_RELEASE    = 3'd6;
  localparam logic [2:0] OWN_FAULT           = 3'd7;

  // ------------------------------------------------------------------ unlock
  // NOT a security mechanism: a deliberate-action interlock in addition to the
  // hardware test-enable input (strap / lifecycle), see docs/testcore/test_modes.md.
  localparam logic [31:0] TC_UNLOCK_KEY = 32'h5F7E_57C0;

  // ------------------------------------------------------------------ JTAG
  localparam int         IR_LEN        = 5;
  localparam logic [4:0] IR_CAPTURE    = 5'b00001;   // LSBs 01 per 1149.1
  localparam logic [4:0] IR_EXTEST     = 5'h00;      // reserved: no BSR yet -> BYPASS
  localparam logic [4:0] IR_SAMPLE     = 5'h01;      // reserved: no BSR yet -> BYPASS
  localparam logic [4:0] IR_IDCODE     = 5'h02;
  localparam logic [4:0] IR_TC_REG     = 5'h0B;      // 46-bit register-access DR (CDC bridge)
  localparam logic [4:0] IR_TC_STATUS  = 5'h0C;      // 8-bit TCK-domain status DR
  localparam logic [4:0] IR_BYPASS     = 5'h1F;
  // IDCODE: version / part / manufacturer.  Part and version follow the
  // SilicaFlux-V convention (docs/DFT.md: 0x15F05001); manufacturer field is a
  // PLACEHOLDER (no JEDEC JEP106 code assigned) and must be replaced.
  localparam logic [3:0]  IDCODE_VERSION = 4'h1;
  localparam logic [15:0] IDCODE_PART    = 16'h5F07;  // 5F07 = TestCore P07 build
  localparam logic [10:0] IDCODE_MFG     = 11'h000;   // PLACEHOLDER
  localparam logic [31:0] IDCODE_VALUE   = {IDCODE_VERSION, IDCODE_PART, IDCODE_MFG, 1'b1};
  localparam int          REG_DR_LEN     = 46;        // [45:44] op/status [43:32] addr [31:0] data
  localparam logic [1:0]  REGOP_NOP = 2'd0, REGOP_READ = 2'd1, REGOP_WRITE = 2'd2, REGOP_CLEAR = 2'd3;
  localparam logic [1:0]  REGST_OK  = 2'd0, REGST_ERR  = 2'd2, REGST_BUSY  = 2'd3;

  // TAP states (IEEE 1149.1 Figure 6-1 naming)
  localparam logic [3:0] TAP_TLR = 4'h0, TAP_RTI = 4'h1, TAP_SEL_DR = 4'h2, TAP_CAP_DR = 4'h3,
                         TAP_SH_DR = 4'h4, TAP_EX1_DR = 4'h5, TAP_PA_DR = 4'h6, TAP_EX2_DR = 4'h7,
                         TAP_UPD_DR = 4'h8, TAP_SEL_IR = 4'h9, TAP_CAP_IR = 4'hA, TAP_SH_IR = 4'hB,
                         TAP_EX1_IR = 4'hC, TAP_PA_IR = 4'hD, TAP_EX2_IR = 4'hE, TAP_UPD_IR = 4'hF;

  function automatic logic [3:0] tap_next(input logic [3:0] s, input logic tms_i);
    case (s)
      TAP_TLR:    tap_next = tms_i ? TAP_TLR    : TAP_RTI;
      TAP_RTI:    tap_next = tms_i ? TAP_SEL_DR : TAP_RTI;
      TAP_SEL_DR: tap_next = tms_i ? TAP_SEL_IR : TAP_CAP_DR;
      TAP_CAP_DR: tap_next = tms_i ? TAP_EX1_DR : TAP_SH_DR;
      TAP_SH_DR:  tap_next = tms_i ? TAP_EX1_DR : TAP_SH_DR;
      TAP_EX1_DR: tap_next = tms_i ? TAP_UPD_DR : TAP_PA_DR;
      TAP_PA_DR:  tap_next = tms_i ? TAP_EX2_DR : TAP_PA_DR;
      TAP_EX2_DR: tap_next = tms_i ? TAP_UPD_DR : TAP_SH_DR;
      TAP_UPD_DR: tap_next = tms_i ? TAP_SEL_DR : TAP_RTI;
      TAP_SEL_IR: tap_next = tms_i ? TAP_TLR    : TAP_CAP_IR;
      TAP_CAP_IR: tap_next = tms_i ? TAP_EX1_IR : TAP_SH_IR;
      TAP_SH_IR:  tap_next = tms_i ? TAP_EX1_IR : TAP_SH_IR;
      TAP_EX1_IR: tap_next = tms_i ? TAP_UPD_IR : TAP_PA_IR;
      TAP_PA_IR:  tap_next = tms_i ? TAP_EX2_IR : TAP_PA_IR;
      TAP_EX2_IR: tap_next = tms_i ? TAP_UPD_IR : TAP_SH_IR;
      default:    tap_next = tms_i ? TAP_SEL_DR : TAP_RTI;   // TAP_UPD_IR
    endcase
  endfunction

  // ------------------------------------------------------------------ register map
  // 12-bit byte address, 32-bit registers, word aligned.  RO = read only,
  // RW = read/write, W1C = write-1-to-clear, WO = write only (reads 0).
  localparam logic [11:0] R_REVISION      = 12'h000;  // RO  TEST_REVISION
  localparam logic [11:0] R_CAPS          = 12'h004;  // RO  [7:0] banks [15:8] max width [19:16] log depth [31:24] algo mask
  localparam logic [11:0] R_IDCODE        = 12'h008;  // RO  IDCODE copy
  localparam logic [11:0] R_SCRATCH       = 12'h00C;  // RW  bridge loop-back
  localparam logic [11:0] R_MODE_CTRL     = 12'h010;  // RW  [2:0] requested mode (write = request)
  localparam logic [11:0] R_MODE_STATUS   = 12'h014;  // RO  [2:0] mode [3] busy [4] hw_test_en [5] unlocked [6] scan_pin [10:8] pending [31] hw_dbg_en
  localparam logic [11:0] R_UNLOCK        = 12'h018;  // WO  write TC_UNLOCK_KEY to unlock, anything else locks
  localparam logic [11:0] R_OWNER_STATUS  = 12'h01C;  // RO  4 bits per bank: {dirty, state[2:0]}
  localparam logic [11:0] R_TEST_CONTROL  = 12'h020;  // RW  [0] START [1] ABORT [2] CLEAR (self-clearing)
                                                      //     [7:4] algorithm [8] bg checker [9] stop-on-fail
                                                      //     [10] scrub (default 1) [11] irq enable
  localparam logic [11:0] R_BANK_MASK     = 12'h024;  // RW  banks to test
  localparam logic [11:0] R_TEST_STATUS   = 12'h028;  // RO  [0] busy [1] done [2] pass [3] fail [4] aborted
                                                      //     [5] error [6] stopped [7] scrubbing [11:8] engine state
                                                      //     [23:16] protect mask
  localparam logic [11:0] R_TEST_BANK_ID  = 12'h02C;  // RO  bank currently / last tested
  localparam logic [11:0] R_TEST_ALGO     = 12'h030;  // RO  [3:0] running algorithm [6:4] element [31:16] compiled mask
  localparam logic [11:0] R_TEST_PROGRESS = 12'h034;  // RO  current address
  localparam logic [11:0] R_FAIL_COUNT    = 12'h038;  // RO  saturating fail count
  localparam logic [11:0] R_FF_ADDR       = 12'h03C;  // RO  FIRST_FAIL_ADDRESS
  localparam logic [11:0] R_FF_INFO       = 12'h040;  // RO  [31] valid [23:16] walk bit [15:12] op [11:8] element [7:0] bank
  localparam logic [11:0] R_LAST_RESULT   = 12'h044;  // RO  [2:0] LAST_TEST_RESULT [6:4] result of the run before
  localparam logic [11:0] R_BANKS_TESTED  = 12'h048;  // RO  mask of banks completed in last run
  localparam logic [11:0] R_BANKS_FAILED  = 12'h04C;  // RO  mask of banks with >=1 failure
  localparam logic [11:0] R_ERROR_FLAGS   = 12'h050;  // W1C ERROR_FLAGS
  localparam logic [11:0] R_CYCLES        = 12'h054;  // RO  cycles of last run (saturating)
  localparam logic [11:0] R_IRQ_STATUS    = 12'h058;  // W1C [0] done [1] fail [2] error
  localparam logic [11:0] R_FF_EXP0       = 12'h060;  // RO  FIRST_FAIL_EXPECTED_DATA word 0..3
  localparam logic [11:0] R_FF_OBS0       = 12'h070;  // RO  FIRST_FAIL_OBSERVED_DATA word 0..3
  localparam logic [11:0] R_FF_SYND0      = 12'h080;  // RO  FIRST_FAIL_SYNDROME (exp ^ obs) word 0..3
  localparam logic [11:0] R_LOG_STATUS    = 12'h090;  // RO  [7:0] level [8] overflow
  localparam logic [11:0] R_LOG_POP       = 12'h094;  // WO  pop head
  localparam logic [11:0] R_LOG_INFO      = 12'h098;  // RO  head info (same layout as FF_INFO)
  localparam logic [11:0] R_LOG_ADDR      = 12'h09C;  // RO  head address
  localparam logic [11:0] R_LOG_SYND0     = 12'h0A0;  // RO  head syndrome word 0..3
  localparam logic [11:0] R_PROTECT       = 12'h0F0;  // W1S protected-bank mask (cleared by reset only)
  localparam logic [11:0] R_BANK_INFO0    = 12'h100;  // RO  per bank k at 0x100+8k: {flags[7:0], 8'd0, width[15:0]}, depth

