// =============================================================================
// SilicaFlux TestCore :: sftc_sramlib_1r1w_wrap
// MBIST-ready one-read/one-write SRAM: SRAM Wrapper Library `sram_1r1w`
// (vendored unmodified) + ownership controller + test-port adapter.
// The MBIST engine issues exactly one operation per transaction, so the test
// path never presents a read and a write in the same cycle: 1R1W
// read-during-write behaviour (undefined on the supported ASIC macros) is
// never relied upon.  Test writes use the write port, test reads the read
// port (library TYPE-1 collar semantics).
// Functional write channel is posted; "functional in flight" therefore is
// read responses outstanding (library busy) or any acceptance this cycle.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sftc_sramlib_1r1w_wrap #(
  parameter int DATA_WIDTH     = 32,
  parameter int DEPTH          = 1024,
  parameter int MASK_WIDTH     = (DATA_WIDTH % 8 == 0) ? DATA_WIDTH / 8 : 1,
  parameter int READ_LATENCY   = 1,
  parameter int BACKEND        = `SRAM_BACKEND_GENERIC,
  parameter int MACRO          = 0,
  parameter int RSP_FIFO_DEPTH = READ_LATENCY + 1,
  parameter int ID_WIDTH       = 1,
  parameter int OWN_TIMEOUT    = 4096,
  localparam int AW            = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  input  wire logic                  wr_valid,
  output logic                       wr_ready,
  input  wire logic [AW-1:0]         wr_addr,
  input  wire logic [DATA_WIDTH-1:0] wr_data,
  input  wire logic [MASK_WIDTH-1:0] wr_mask,
  output logic                       wr_err,
  input  wire logic                  rd_valid,
  output logic                       rd_ready,
  input  wire logic [AW-1:0]         rd_addr,
  input  wire logic [ID_WIDTH-1:0]   rd_id,
  output logic                       rsp_valid,
  input  wire logic                  rsp_ready,
  output logic [DATA_WIDTH-1:0]      rsp_rdata,
  output logic                       rsp_err,
  output logic [ID_WIDTH-1:0]        rsp_id,
  input  wire logic                  t_req,
  output logic                       t_gnt,
  input  wire logic                  t_we,
  input  wire logic [AW-1:0]         t_addr,
  input  wire logic [DATA_WIDTH-1:0] t_wdata,
  output logic                       t_rvalid,
  output logic [DATA_WIDTH-1:0]      t_rdata,
  output logic                       t_rerr,
  input  wire logic                  acq_req,
  input  wire logic                  fault_clear,
  input  wire logic                  quiesce_ack,
  output logic                       quiesce_req,
  input  wire logic                  mbist_busy,
  input  wire logic                  scrub_done,
  output logic                       owned,
  output logic [2:0]                 owner_state,
  output logic                       dirty,
  output logic                       ev_fault,
  output logic                       ev_intrusion,
  output logic                       ev_reinit_req,
  output logic                       busy
);
  logic f_block, sel_test, test_en, t_busy, t_wr, f_busy, w_rdy, r_rdy;
  logic tst_ce, tst_we;
  logic [AW-1:0] tst_addr;
  logic [DATA_WIDTH-1:0] tst_wdata, tst_rdata;

  sftc_mem_owner #(.TIMEOUT(OWN_TIMEOUT)) u_owner (
    .clk, .rst_n, .acq_req, .fault_clear, .quiesce_ack, .f_busy, .f_req(wr_valid || rd_valid),
    .mbist_busy, .t_busy, .t_wr, .scrub_done, .quiesce_req, .f_block, .sel_test, .test_en, .owned,
    .state(owner_state), .dirty, .ev_fault, .ev_intrusion, .ev_reinit_req
  );

  sftc_tst_port_adapter #(.DW(DATA_WIDTH), .AW(AW), .READ_LATENCY(READ_LATENCY)) u_adapt (
    .clk, .rst_n, .test_en, .t_req, .t_gnt, .t_we, .t_addr, .t_wdata, .t_rvalid, .t_rdata, .t_rerr,
    .t_busy, .t_wr, .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata
  );

  sram_1r1w #(
    .DATA_WIDTH(DATA_WIDTH), .DEPTH(DEPTH), .MASK_WIDTH(MASK_WIDTH), .READ_LATENCY(READ_LATENCY),
    .BACKEND(BACKEND), .MACRO(MACRO), .RSP_FIFO_DEPTH(RSP_FIFO_DEPTH), .ID_WIDTH(ID_WIDTH), .TEST_EN(1)
  ) u_sram (
    .clk, .rst_n,
    .wr_valid(wr_valid && !f_block), .wr_ready(w_rdy), .wr_addr, .wr_data, .wr_mask, .wr_err,
    .rd_valid(rd_valid && !f_block), .rd_ready(r_rdy), .rd_addr, .rd_id,
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_err, .rsp_id,
    .tst_active(sel_test), .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata, .busy
  );
  assign wr_ready = w_rdy && !f_block;
  assign rd_ready = r_rdy && !f_block;
  assign f_busy = busy || (wr_valid && wr_ready) || (rd_valid && rd_ready);
endmodule

`default_nettype wire
