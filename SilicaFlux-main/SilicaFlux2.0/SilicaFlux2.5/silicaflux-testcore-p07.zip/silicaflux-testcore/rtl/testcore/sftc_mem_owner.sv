// =============================================================================
// SilicaFlux TestCore :: sftc_mem_owner
// Memory ownership / access-isolation controller (one per memory bank).
//
//   NORMAL --acq_req--> QUIESCE_REQUEST --quiesce_ack--> WAIT_FOR_IDLE
//     --!f_busy--> TEST_ACQUIRE --(1 cycle)--> TEST_ACTIVE
//     --!acq_req && !mbist_busy--> TEST_COMPLETE --!t_busy--> TEST_RELEASE
//     --(1 cycle)--> NORMAL
//   Any wait longer than TIMEOUT cycles -> FAULT (sticky until fault_clear).
//
//   * quiesce_req asks the masters (CPU, DMA, accelerators) to stop issuing;
//     quiesce_ack confirms it.  From WAIT_FOR_IDLE until TEST_RELEASE the
//     functional port is blocked (f_block): no functional request is accepted
//     by the wrapper, whatever the master does.
//   * The memory port switches to the test path (sel_test) only after every
//     accepted functional transaction has completed and its response has been
//     delivered (f_busy = 0), and switches back only after every accepted test
//     transaction has completed (t_busy = 0).  Test requests are granted only
//     in TEST_ACTIVE (test_en).
//   * `dirty` = the test path wrote the bank since the last scrub.  Releasing a
//     dirty bank raises ev_reinit_req (sticky REINIT_REQUIRED status): the
//     content is undefined and software must initialise it.
//   * A functional request presented after quiesce was acknowledged
//     (WAIT_FOR_IDLE .. TEST_RELEASE) is blocked and reported (ev_intrusion).
//   * FAULT (quiesce or drain timeout) returns the port to the functional
//     path, keeps test access denied and is reported (ev_fault).  If the
//     timeout happened while draining test transactions, the wrapper's
//     response tagging still routes any late test response to the test port.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sftc_defs.svh"
`default_nettype none

module sftc_mem_owner
#(
  parameter int TIMEOUT = 4096
) (
  input  wire logic       clk,
  input  wire logic       rst_n,
  input  wire logic       acq_req,       // test wants the bank (mode == MBIST && selected)
  input  wire logic       fault_clear,
  input  wire logic       quiesce_ack,   // functional masters stopped issuing
  input  wire logic       f_busy,        // functional transactions / responses in flight
  input  wire logic       f_req,         // functional request presented (raw, for intrusion monitor)
  input  wire logic       mbist_busy,
  input  wire logic       t_busy,        // test transactions in flight in the wrapper
  input  wire logic       t_wr,          // test write accepted this cycle
  input  wire logic       scrub_done,    // MBIST completed the scrub of this bank (pulse)
  output logic            quiesce_req,
  output logic            f_block,
  output logic            sel_test,
  output logic            test_en,
  output logic            owned,
  output logic [2:0]      state,
  output logic            dirty,
  output logic            ev_fault,
  output logic            ev_intrusion,
  output logic            ev_reinit_req
);
  `include "sftc_consts.svh"

  localparam int TW = $clog2(TIMEOUT + 1);
  logic [2:0]    st, st_q;
  logic [TW-1:0] tmo;

  wire waiting = (st == OWN_QUIESCE_REQUEST) || (st == OWN_WAIT_FOR_IDLE) || (st == OWN_TEST_COMPLETE);
  wire tmo_hit = waiting && (32'(tmo) >= TIMEOUT - 1);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= OWN_NORMAL; st_q <= OWN_NORMAL; tmo <= '0; dirty <= 1'b0;
      ev_fault <= 1'b0; ev_reinit_req <= 1'b0;
    end else begin
      ev_fault <= 1'b0; ev_reinit_req <= 1'b0;
      st_q <= st;
      if (!waiting || st != st_q) tmo <= '0;
      else if (!tmo_hit)               tmo <= tmo + 1'b1;
      if (t_wr)            dirty <= 1'b1;
      else if (scrub_done) dirty <= 1'b0;
      case (st)
        OWN_NORMAL:          if (acq_req) st <= OWN_QUIESCE_REQUEST;
        OWN_QUIESCE_REQUEST: if (!acq_req) st <= OWN_NORMAL;
                             else if (tmo_hit) begin st <= OWN_FAULT; ev_fault <= 1'b1; end
                             else if (quiesce_ack) st <= OWN_WAIT_FOR_IDLE;
        OWN_WAIT_FOR_IDLE:   if (!acq_req) st <= OWN_NORMAL;
                             else if (tmo_hit) begin st <= OWN_FAULT; ev_fault <= 1'b1; end
                             else if (!f_busy) st <= OWN_TEST_ACQUIRE;
        OWN_TEST_ACQUIRE:    st <= OWN_TEST_ACTIVE;
        OWN_TEST_ACTIVE:     if (!acq_req && !mbist_busy) st <= OWN_TEST_COMPLETE;
        OWN_TEST_COMPLETE:   if (tmo_hit) begin st <= OWN_FAULT; ev_fault <= 1'b1; end
                             else if (!t_busy) st <= OWN_TEST_RELEASE;
        OWN_TEST_RELEASE:    begin st <= OWN_NORMAL; ev_reinit_req <= dirty; end
        OWN_FAULT:           if (fault_clear && !acq_req) st <= OWN_NORMAL;
        default:             st <= OWN_FAULT;
      endcase
    end
  end

  assign state        = st;
  assign quiesce_req  = (st != OWN_NORMAL) && (st != OWN_FAULT);
  // The functional port stays open during QUIESCE_REQUEST so that a request a
  // master has already presented can complete its handshake (otherwise it
  // could never acknowledge -- deadlock found in system simulation).  From the
  // acknowledge on, the wrapper blocks every functional request.
  assign f_block      = quiesce_req && (st != OWN_QUIESCE_REQUEST);
  assign sel_test     = (st == OWN_TEST_ACQUIRE) || (st == OWN_TEST_ACTIVE) || (st == OWN_TEST_COMPLETE);
  assign test_en      = (st == OWN_TEST_ACTIVE);
  assign owned        = (st == OWN_TEST_ACTIVE);
  assign ev_intrusion = f_req && ((st == OWN_WAIT_FOR_IDLE) || sel_test || (st == OWN_TEST_RELEASE));

`ifdef SFTC_CHECKS
  // embedded properties (also proven formally, formal/testcore/fv_mem_owner.sv)
  always @(posedge clk) begin
    if (rst_n) begin
      `SFTC_ASSERT(!sel_test || f_block, "test owns the port while functional path is open")
      `SFTC_ASSERT(!test_en || sel_test, "test grant without test ownership")
      `SFTC_ASSERT(!(st == OWN_NORMAL && sel_test), "NORMAL state with test ownership")
    end
  end
`endif
endmodule

`default_nettype wire
