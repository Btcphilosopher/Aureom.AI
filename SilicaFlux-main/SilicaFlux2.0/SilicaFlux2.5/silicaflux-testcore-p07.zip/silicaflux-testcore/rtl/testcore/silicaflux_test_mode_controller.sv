// =============================================================================
// SilicaFlux TestCore :: silicaflux_test_mode_controller   (system clock domain)
//
// Modes: NORMAL, JTAG_ACCESS, MBIST, DIAGNOSTIC (register-requested) and
// SCAN_SHIFT / SCAN_CAPTURE (pin-forced by the tester, never by software).
//
// Permission inputs (must come from hardware, NOT from software registers):
//   hw_dbg_en   lifecycle/strap permits non-destructive debug access
//               (JTAG_ACCESS, DIAGNOSTIC)
//   hw_test_en  lifecycle/strap permits destructive test (MBIST, scan)
// plus the software interlock `unlocked` (TC_UNLOCK_KEY written) for MBIST.
// The software interlock alone can never enable a destructive mode.
//
// Register-requested transition table (see docs/testcore/test_modes.md):
//   from \ to     NORMAL  JTAG  MBIST      DIAG   SCAN_*  other
//   NORMAL        -       dbg   test&unl   dbg    ILLEGAL ILLEGAL
//   JTAG_ACCESS   ok      -     test&unl   dbg    ILLEGAL ILLEGAL
//   MBIST         exit    exit* -          ILLEG  ILLEGAL ILLEGAL   (*exit to JTAG needs dbg)
//   DIAGNOSTIC    ok      dbg   ILLEGAL    -      ILLEGAL ILLEGAL
//   ("exit" = abort MBIST, wait until engine idle and every bank released,
//    then switch; a request to the current mode is a legal no-op.)
// A refused request (missing permission) sets ev_denied; a request that is not
// in the table sets ev_illegal; in both cases the mode is unchanged.
// Loss of permission forces the mode back to NORMAL immediately; for MBIST the
// engine is hard-stopped (test_enable low: no further writes, no scrub, banks
// flagged REINIT_REQUIRED by the ownership controllers).
// Scan: scan_mode_pin && hw_test_en overrides everything (combinational, so
// that it is valid while this block's own flops are being scan-shifted);
// SCAN_SHIFT when scan_en_pin = 1, else SCAN_CAPTURE.  Leaving scan requires a
// power-on reset (documented requirement; state is undefined after shifting).
// Reset: NORMAL, no test enable, no pending request.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sftc_defs.svh"
`default_nettype none

module silicaflux_test_mode_controller
(
  input  wire logic       clk,
  input  wire logic       rst_n,
  // permissions (hardware)
  input  wire logic       hw_dbg_en,
  input  wire logic       hw_test_en,
  input  wire logic       unlocked,
  // tester scan pins (static during a scan session)
  input  wire logic       scan_mode_pin,
  input  wire logic       scan_en_pin,
  // request (register write of MODE_CTRL)
  input  wire logic       req_valid,
  input  wire logic [2:0] req_mode,
  // status from MBIST / ownership
  input  wire logic       mbist_busy,
  input  wire logic       banks_released,   // every owner in NORMAL or FAULT
  // outputs
  output logic [2:0]      mode,
  output logic            mode_busy,        // MBIST exit sequence in progress
  output logic [2:0]      pending,
  output logic            mbist_enable,     // MBIST engine test_enable (hard enable)
  output logic            mbist_abort,      // soft abort pulse (exit request)
  output logic            jtag_mode,
  output logic            diag_mode,
  output logic            scan_mode,        // to DFT muxes (reset bypass, ICG TE, memory inhibit)
  output logic            scan_en,          // to scan-enable network
  output logic            ev_illegal,
  output logic            ev_denied
);
  `include "sftc_consts.svh"

  logic [2:0] st, pend;
  logic       exiting;

  wire perm_dbg  = hw_dbg_en;
  wire perm_test = hw_test_en && unlocked;
  wire scan_act  = scan_mode_pin && hw_test_en;

  // ------------------------------------------------------------- request decode
  logic legal, permitted;
  always_comb begin
    legal = 1'b0; permitted = 1'b0;
    case (st)
      MODE_NORMAL: case (req_mode)
        MODE_NORMAL:      begin legal = 1'b1; permitted = 1'b1; end
        MODE_JTAG_ACCESS: begin legal = 1'b1; permitted = perm_dbg; end
        MODE_MBIST:       begin legal = 1'b1; permitted = perm_test; end
        MODE_DIAGNOSTIC:  begin legal = 1'b1; permitted = perm_dbg; end
        default: ;
      endcase
      MODE_JTAG_ACCESS: case (req_mode)
        MODE_NORMAL:      begin legal = 1'b1; permitted = 1'b1; end
        MODE_JTAG_ACCESS: begin legal = 1'b1; permitted = 1'b1; end
        MODE_MBIST:       begin legal = 1'b1; permitted = perm_test; end
        MODE_DIAGNOSTIC:  begin legal = 1'b1; permitted = perm_dbg; end
        default: ;
      endcase
      MODE_MBIST: case (req_mode)
        MODE_NORMAL, MODE_MBIST: begin legal = 1'b1; permitted = 1'b1; end
        MODE_JTAG_ACCESS:        begin legal = 1'b1; permitted = perm_dbg; end   // target must be permitted too
        default: ;
      endcase
      MODE_DIAGNOSTIC: case (req_mode)
        MODE_NORMAL:      begin legal = 1'b1; permitted = 1'b1; end
        MODE_JTAG_ACCESS: begin legal = 1'b1; permitted = perm_dbg; end
        MODE_DIAGNOSTIC:  begin legal = 1'b1; permitted = 1'b1; end
        default: ;
      endcase
      default: ;
    endcase
  end

  wire accept_req = req_valid && !exiting && !scan_act && legal && permitted;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= MODE_NORMAL; pend <= MODE_NORMAL; exiting <= 1'b0;
      ev_illegal <= 1'b0; ev_denied <= 1'b0; mbist_abort <= 1'b0;
    end else begin
      ev_illegal <= 1'b0; ev_denied <= 1'b0; mbist_abort <= 1'b0;
      if (req_valid && (exiting || scan_act || !legal)) ev_illegal <= 1'b1;
      else if (req_valid && legal && !permitted)        ev_denied  <= 1'b1;

      // ---- forced exits on permission loss
      if ((st == MODE_MBIST && !perm_test) ||
          ((st == MODE_JTAG_ACCESS || st == MODE_DIAGNOSTIC) && !perm_dbg)) begin
        st <= MODE_NORMAL; exiting <= 1'b0;
      end else if (exiting) begin
        if (!mbist_busy && banks_released) begin
          st <= pend; exiting <= 1'b0;
        end
      end else if (accept_req && req_mode != st) begin
        if (st == MODE_MBIST) begin
          exiting <= 1'b1; pend <= req_mode; mbist_abort <= 1'b1;
        end else begin
          st <= req_mode;
        end
      end
    end
  end

  // ------------------------------------------------------------- outputs
  assign mode         = scan_act ? (scan_en_pin ? MODE_SCAN_SHIFT : MODE_SCAN_CAPTURE) : st;
  assign mode_busy    = exiting;
  assign pending      = exiting ? pend : st;
  assign mbist_enable = (st == MODE_MBIST) && perm_test && !scan_act;
  assign jtag_mode    = (st == MODE_JTAG_ACCESS) && perm_dbg && !scan_act;   // permission loss takes effect immediately
  assign diag_mode    = (st == MODE_DIAGNOSTIC) && perm_dbg && !scan_act;
  assign scan_mode    = scan_act;
  assign scan_en      = scan_act && scan_en_pin;

`ifdef SFTC_CHECKS
  always @(posedge clk) begin
    if (rst_n) begin
      `SFTC_ASSERT(!mbist_enable || (hw_test_en && unlocked), "MBIST enabled without hardware permission")
      `SFTC_ASSERT(!scan_en || scan_mode, "scan enable outside scan mode")
      `SFTC_ASSERT(st == MODE_NORMAL || st == MODE_JTAG_ACCESS || st == MODE_MBIST || st == MODE_DIAGNOSTIC,
                   "register-controlled state outside the legal set")
    end
  end
`endif
endmodule

`default_nettype wire
