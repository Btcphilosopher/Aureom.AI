// =============================================================================
// SilicaFlux TestCore :: sftc_defs.svh
// Assertion macro with two back-ends:
//   FORMAL     -> immediate `assert` (read by yosys -formal / SymbiYosys)
//   simulation -> $error + error counter in the testbench ($fatal optional)
//   SYNTHESIS  -> nothing
// Yosys 0.33 open-source front end supports immediate assertions with
// $past/$stable only (no SVA sequences), so all properties are written in that
// style and are therefore usable by both simulation and formal.
// =============================================================================
`ifndef SFTC_DEFS_SVH
`define SFTC_DEFS_SVH

`ifdef FORMAL
  `define SFTC_ASSERT(cond, msg) assert (cond);
  `define SFTC_ASSUME(cond)      assume (cond);
`elsif SYNTHESIS
  `define SFTC_ASSERT(cond, msg)
  `define SFTC_ASSUME(cond)
`else
  `define SFTC_ASSERT(cond, msg) if (!(cond)) begin $display("SFTC_ASSERTION_FAILED %m t=%0t: %s", $time, msg); `ifdef SFTC_FATAL_ASSERT $fatal(1); `endif end
  `define SFTC_ASSUME(cond)
`endif

// SFTC_REACH(k, cond): non-vacuity point.  Normal formal runs: cover(cond).
// With -DREACH -DREACH_IDX=k the k-th point becomes assert(!cond) so that an
// unbounded engine (abc pdr) must produce a trace reaching it (expected FAIL).
`ifdef REACH
  `define SFTC_REACH(k, cond) if (k == `REACH_IDX) assert (!(cond));
`else
  `define SFTC_REACH(k, cond) cover (cond);
`endif

// SFTC_CHECKS: embedded property blocks are compiled in simulation and formal,
// removed in synthesis.
`ifdef FORMAL
  `define SFTC_CHECKS
`elsif SYNTHESIS
`else
  `define SFTC_CHECKS
`endif

`endif
