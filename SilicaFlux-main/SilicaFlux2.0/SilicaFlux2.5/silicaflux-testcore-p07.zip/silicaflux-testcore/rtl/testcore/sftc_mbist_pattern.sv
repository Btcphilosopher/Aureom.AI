// =============================================================================
// SilicaFlux TestCore :: sftc_mbist_pattern
// Data-pattern generator (pure combinational).
// Decodes the current March element word + op index / walk index into
//   is_rd  : current op is a read (else write)
//   data   : write data or expected read data, masked to the bank width
//   last_op: current op is the last one applied at this address
// Background BG(a): solid = all-zero word; checkerboard = bit i is i[0]^a[0]
// (a LOGICAL checkerboard: the physical pattern depends on the macro's row/
// column scrambling, which is not modelled -- see docs/testcore/mbist.md).
// Data "0" = BG(a), data "1" = ~BG(a) (word-oriented March).
// Walk elements: per address j = 0..2W: even j -> w(P_b), odd j -> r(P_b),
// b = j/2; j = 2W -> restore write BG.  Walking one: BG = 0, P_b = 1<<b.
// Walking zero: BG = ~0, P_b = ~(1<<b).
// Scrub: write all-zero word (re-initialisation before release).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sftc_mbist_pattern
#(
  parameter int MAX_W = 32,
  parameter int JW    = 9      // walk index width: must hold 2*MAX_W
) (
  input  wire logic [11:0]      elem,
  input  wire logic [1:0]       op_idx,
  input  wire logic [JW-1:0]    walk_j,
  input  wire logic             addr0,      // address bit 0
  input  wire logic [7:0]       width,      // bank width (1..MAX_W)
  input  wire logic             bg_chk,     // run-time checkerboard background (March only)
  input  wire logic             scrub,
  output logic                  is_rd,
  output logic [MAX_W-1:0]      data,
  output logic [MAX_W-1:0]      wmask,
  output logic                  last_op,
  output logic [7:0]            walk_bit
);
  `include "sftc_consts.svh"

  wire [1:0] kind    = elem[11:10];
  wire       e_bg    = elem[8];
  wire [1:0] nops_m1 = elem[7:6];
  wire [1:0] op      = elem[{1'b0, op_idx, 1'b0} +: 2];

  logic [MAX_W-1:0] bg, cb;
  always_comb begin
    for (int i = 0; i < MAX_W; i++) begin
      wmask[i] = (i < 32'(width));
      cb[i]    = (i % 2 == 1) ^ addr0;
    end
  end

  wire [JW-1:0] two_w   = JW'({width, 1'b0});
  wire          j_rest  = (walk_j == two_w);
  wire [JW-2:0] b_idx   = walk_j[JW-1:1];
  assign walk_bit = 8'(b_idx);

  logic [MAX_W-1:0] onehot;
  always_comb begin
    for (int i = 0; i < MAX_W; i++) onehot[i] = (i == 32'(b_idx));
  end

  always_comb begin
    is_rd   = 1'b0;
    last_op = 1'b1;
    data    = '0;
    bg      = '0;
    if (scrub) begin
      is_rd = 1'b0; last_op = 1'b1; data = '0;
    end else if (kind == EK_WALK) begin
      bg      = elem[0] ? '0 : '1;
      last_op = j_rest;
      if (j_rest) begin
        is_rd = 1'b0; data = bg;
      end else begin
        is_rd = walk_j[0];
        data  = bg ^ onehot;
      end
    end else begin
      bg      = (e_bg || bg_chk) ? cb : '0;
      is_rd   = op[1];
      data    = op[0] ? ~bg : bg;
      last_op = (op_idx == nops_m1);
    end
    data = data & wmask;
  end
endmodule

`default_nettype wire
