// =============================================================================
// SilicaFlux TestCore :: sftc_regs   (system clock domain)
// Diagnostic / control register block.  Register map: sftc_pkg (R_*) and
// docs/testcore/register_map.md (generated from python/testcore/spec.py).
// Single-cycle register bus: access completes in the cycle req is high
// (gnt = req); err = unmapped address or write to a read-only register.
//   * TEST_CONTROL.START / ABORT / CLEAR are self-clearing pulses.
//   * Configuration fields are latched by the engine at START; writes while
//     the engine is busy do not affect the running test.
//   * ERROR_FLAGS and IRQ_STATUS are sticky, write-1-to-clear.
//   * UNLOCK is write-only; writing TC_UNLOCK_KEY sets `unlocked`, any other
//     value clears it.  It is a deliberate-action interlock, not security.
//   * PROTECT (write-1-to-set, cleared only by reset): banks that must not be
//     acquired by test while the CPU runs (e.g. the bank holding the boot
//     stack).  A protected bank is acquired only while cpu_halted = 1.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sftc_regs
#(
  parameter int BANK_COUNT = 2,
  parameter int MAX_W      = 32,
  parameter int AW         = 8,
  parameter int CNT_W      = 16,
  parameter logic [BANK_COUNT*8-1:0]  BANK_WIDTHS = {BANK_COUNT{8'd32}},
  parameter logic [BANK_COUNT*24-1:0] BANK_DEPTHS = {BANK_COUNT{24'd256}},
  parameter logic [BANK_COUNT*8-1:0]  BANK_FLAGS  = {BANK_COUNT{8'd0}},
  parameter logic [15:0] ALG_MASK  = 16'h003F,
  parameter int LOG_DEPTH  = 4,
  localparam int BW = (BANK_COUNT > 1) ? $clog2(BANK_COUNT) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // register bus
  input  wire logic                  req,
  input  wire logic                  we,
  input  wire logic [11:0]           addr,
  input  wire logic [31:0]           wdata,
  output logic                       gnt,
  output logic [31:0]                rdata,
  output logic                       err,
  // to MBIST
  output logic                       c_start,
  output logic                       c_abort,
  output logic                       c_clear,
  output logic [3:0]                 c_algo,
  output logic                       c_bg_chk,
  output logic                       c_sof,
  output logic                       c_scrub,
  output logic [BANK_COUNT-1:0]      c_mask,
  output logic                       c_log_pop,
  // to mode controller / owners
  output logic                       mode_req_valid,
  output logic [2:0]                 mode_req,
  output logic                       unlocked,
  output logic [BANK_COUNT-1:0]      protect,
  output logic                       owner_fault_clear,
  output logic                       irq,
  // status in
  input  wire logic [2:0]            mode,
  input  wire logic                  mode_busy,
  input  wire logic [2:0]            mode_pending,
  input  wire logic                  hw_test_en,
  input  wire logic                  hw_dbg_en,
  input  wire logic                  scan_pin,
  input  wire logic [BANK_COUNT*3-1:0] owner_state,
  input  wire logic [BANK_COUNT-1:0] owner_dirty,
  input  wire logic                  m_busy,
  input  wire logic                  m_done,
  input  wire logic                  m_pass,
  input  wire logic                  m_fail,
  input  wire logic                  m_aborted,
  input  wire logic                  m_error,
  input  wire logic                  m_stopped,
  input  wire logic                  m_scrubbing,
  input  wire logic [3:0]            m_state,
  input  wire logic [BW-1:0]         m_bank,
  input  wire logic [2:0]            m_elem,
  input  wire logic [AW-1:0]         m_addr,
  input  wire logic [3:0]            m_algo,
  input  wire logic [2:0]            m_last,
  input  wire logic [2:0]            m_prev,
  input  wire logic [BANK_COUNT-1:0] m_tested,
  input  wire logic [BANK_COUNT-1:0] m_failed,
  input  wire logic [31:0]           m_cycles,
  input  wire logic                  m_ff_valid,
  input  wire logic [23:0]           m_ff_info,
  input  wire logic [AW-1:0]         m_ff_addr,
  input  wire logic [MAX_W-1:0]      m_ff_exp,
  input  wire logic [MAX_W-1:0]      m_ff_obs,
  input  wire logic [CNT_W-1:0]      m_fail_count,
  input  wire logic [7:0]            m_log_level,
  input  wire logic                  m_log_ovf,
  input  wire logic [23:0]           m_log_info,
  input  wire logic [AW-1:0]         m_log_addr,
  input  wire logic [MAX_W-1:0]      m_log_synd,
  // events (pulses) -> sticky ERROR_FLAGS / IRQ_STATUS
  input  wire logic [10:0]     ev_flags,
  input  wire logic                  ev_done
);
  `include "sftc_consts.svh"

  localparam int DW4 = 128;

  // ------------------------------------------------------------- state
  logic [3:0]  r_algo;
  logic        r_bg, r_sof, r_scrub, r_irq_en;
  logic [BANK_COUNT-1:0] r_mask;
  logic [31:0] r_scratch;
  logic [NUM_EF-1:0] r_ef;
  logic [2:0]  r_irq;
  logic [2:0]  r_mode_req;

  wire wr = req && we;
  wire rd = req && !we;

  // ------------------------------------------------------------- read mux
  logic [DW4-1:0] ffe, ffo, ffs, lgs;
  assign ffe = DW4'(m_ff_exp);
  assign ffo = DW4'(m_ff_obs);
  wire [MAX_W-1:0] ffx = m_ff_exp ^ m_ff_obs;
  assign ffs = DW4'(ffx);
  assign lgs = DW4'(m_log_synd);

  logic        mapped, ro;
  logic [31:0] rv;
  always_comb begin
    mapped = 1'b1; ro = 1'b1; rv = 32'd0;
    case (addr)
      R_REVISION:      rv = TC_REVISION;
      R_CAPS:          rv = {ALG_MASK[7:0], 4'd0, 4'(LOG_DEPTH > 15 ? 15 : LOG_DEPTH), 8'(MAX_W), 8'(BANK_COUNT)};
      R_IDCODE:        rv = IDCODE_VALUE;
      R_SCRATCH:       begin rv = r_scratch; ro = 1'b0; end
      R_MODE_CTRL:     begin rv = {29'd0, r_mode_req}; ro = 1'b0; end
      R_MODE_STATUS:   rv = {21'd0, mode_pending, 1'b0, scan_pin, unlocked, hw_test_en, mode_busy, mode} |
                            {hw_dbg_en, 31'd0};
      R_UNLOCK:        begin rv = 32'd0; ro = 1'b0; end
      R_OWNER_STATUS:  for (int k = 0; k < BANK_COUNT && k < 8; k++)
                         rv[k*4 +: 4] = {owner_dirty[k], owner_state[k*3 +: 3]};
      R_TEST_CONTROL:  begin rv = {20'd0, r_irq_en, r_scrub, r_sof, r_bg, r_algo, 4'd0}; ro = 1'b0; end
      R_BANK_MASK:     begin rv = 32'(r_mask); ro = 1'b0; end
      R_TEST_STATUS:   rv = {8'd0, 8'(protect), 4'd0, m_state, m_scrubbing, m_stopped, m_error, m_aborted,
                             m_fail, m_pass, m_done, m_busy};
      R_TEST_BANK_ID:  rv = 32'(m_bank);
      R_TEST_ALGO:     rv = {ALG_MASK, 8'd0, 1'b0, m_elem, m_algo};
      R_TEST_PROGRESS: rv = 32'(m_addr);
      R_FAIL_COUNT:    rv = 32'(m_fail_count);
      R_FF_ADDR:       rv = 32'(m_ff_addr);
      R_FF_INFO:       rv = {m_ff_valid, 7'd0, m_ff_info};
      R_LAST_RESULT:   rv = {25'd0, m_prev, 1'b0, m_last};
      R_BANKS_TESTED:  rv = 32'(m_tested);
      R_BANKS_FAILED:  rv = 32'(m_failed);
      R_ERROR_FLAGS:   begin rv = 32'(r_ef); ro = 1'b0; end
      R_CYCLES:        rv = m_cycles;
      R_IRQ_STATUS:    begin rv = 32'(r_irq); ro = 1'b0; end
      R_FF_EXP0:       rv = ffe[31:0];
      R_FF_EXP0+12'h4: rv = ffe[63:32];
      R_FF_EXP0+12'h8: rv = ffe[95:64];
      R_FF_EXP0+12'hC: rv = ffe[127:96];
      R_FF_OBS0:       rv = ffo[31:0];
      R_FF_OBS0+12'h4: rv = ffo[63:32];
      R_FF_OBS0+12'h8: rv = ffo[95:64];
      R_FF_OBS0+12'hC: rv = ffo[127:96];
      R_FF_SYND0:      rv = ffs[31:0];
      R_FF_SYND0+12'h4: rv = ffs[63:32];
      R_FF_SYND0+12'h8: rv = ffs[95:64];
      R_FF_SYND0+12'hC: rv = ffs[127:96];
      R_LOG_STATUS:    rv = {23'd0, m_log_ovf, m_log_level};
      R_LOG_POP:       begin rv = 32'd0; ro = 1'b0; end
      R_LOG_INFO:      rv = {(m_log_level != 0), 7'd0, m_log_info};
      R_LOG_ADDR:      rv = 32'(m_log_addr);
      R_LOG_SYND0:     rv = lgs[31:0];
      R_LOG_SYND0+12'h4: rv = lgs[63:32];
      R_LOG_SYND0+12'h8: rv = lgs[95:64];
      R_LOG_SYND0+12'hC: rv = lgs[127:96];
      R_PROTECT:       begin rv = 32'(protect); ro = 1'b0; end   // PROTECT (W1S)
      default: begin
        mapped = 1'b0;
        for (int k = 0; k < BANK_COUNT; k++) begin
          if (addr == R_BANK_INFO0 + 12'(8 * k)) begin
            mapped = 1'b1; rv = {BANK_FLAGS[k*8 +: 8], 8'd0, 8'd0, BANK_WIDTHS[k*8 +: 8]};
          end
          if (addr == R_BANK_INFO0 + 12'(8 * k + 4)) begin
            mapped = 1'b1; rv = {8'd0, BANK_DEPTHS[k*24 +: 24]};
          end
        end
      end
    endcase
  end

  assign gnt   = req;
  assign rdata = rd ? rv : 32'd0;
  assign err   = req && (!mapped || (we && ro));

  // ------------------------------------------------------------- writes
  wire w_ok = wr && mapped && !ro;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      r_algo <= ALG_MARCH_C_MINUS; r_bg <= 1'b0; r_sof <= 1'b0; r_scrub <= 1'b1; r_irq_en <= 1'b0;
      r_mask <= '0; r_scratch <= '0; r_ef <= '0; r_irq <= '0; r_mode_req <= MODE_NORMAL;
      unlocked <= 1'b0; protect <= '0;
      c_start <= 1'b0; c_abort <= 1'b0; c_clear <= 1'b0; c_log_pop <= 1'b0;
      mode_req_valid <= 1'b0; owner_fault_clear <= 1'b0;
    end else begin
      c_start <= 1'b0; c_abort <= 1'b0; c_clear <= 1'b0; c_log_pop <= 1'b0;
      mode_req_valid <= 1'b0; owner_fault_clear <= 1'b0;
      // sticky event flags
      r_ef <= r_ef | ev_flags | (NUM_EF'(err) << EF_BUS_ERR);
      if (ev_done) r_irq[0] <= 1'b1;
      if (ev_done && m_fail) r_irq[1] <= 1'b1;
      if (ev_flags[EF_TIMEOUT] || ev_flags[EF_SPURIOUS] || ev_flags[EF_OWNER_FAULT]) r_irq[2] <= 1'b1;
      if (w_ok) begin
        case (addr)
          R_SCRATCH:      r_scratch <= wdata;
          R_MODE_CTRL:    begin r_mode_req <= wdata[2:0]; mode_req_valid <= 1'b1; end
          R_UNLOCK:       unlocked <= (wdata == TC_UNLOCK_KEY);
          R_TEST_CONTROL: begin
            if (!m_busy) begin
              r_algo <= wdata[7:4]; r_bg <= wdata[8]; r_sof <= wdata[9]; r_scrub <= wdata[10];
            end
            r_irq_en <= wdata[11];
            c_start  <= wdata[0];
            c_abort  <= wdata[1];
            c_clear  <= wdata[2];
            if (wdata[2]) owner_fault_clear <= 1'b1;
          end
          R_BANK_MASK:    if (!m_busy) r_mask <= wdata[BANK_COUNT-1:0];
          R_ERROR_FLAGS:  r_ef <= (r_ef | ev_flags) & ~wdata[NUM_EF-1:0];
          R_IRQ_STATUS:   r_irq <= r_irq & ~wdata[2:0];
          R_LOG_POP:      c_log_pop <= 1'b1;
          R_PROTECT:      protect <= protect | wdata[BANK_COUNT-1:0];
          default: ;
        endcase
      end
    end
  end

  assign c_algo   = r_algo;
  assign c_bg_chk = r_bg;
  assign c_sof    = r_sof;
  assign c_scrub  = r_scrub;
  assign c_mask   = r_mask;
  assign mode_req = r_mode_req;
  assign irq      = r_irq_en && (r_irq != 3'd0);

`ifdef FORMAL
  logic f_v;
  initial f_v = 1'b0;
  always @(posedge clk) f_v <= rst_n;
  always @(posedge clk) begin
    if (rst_n && f_v && $past(rst_n)) begin
      for (int i = 0; i < NUM_EF; i++)
        if ($past(r_ef[i]) && !($past(w_ok) && $past(addr) == R_ERROR_FLAGS && $past(wdata[i])))
          assert (r_ef[i]);                                  // R1 sticky until W1C
      assert ((protect & $past(protect)) == $past(protect));  // R2 PROTECT only sets (reset clears)
      if (unlocked && !$past(unlocked))
        assert ($past(w_ok) && $past(addr) == R_UNLOCK && $past(wdata) == TC_UNLOCK_KEY);  // R3
      if (c_start) assert ($past(w_ok) && $past(addr) == R_TEST_CONTROL && $past(wdata[0]));  // R4
      if (mode_req_valid) assert ($past(w_ok) && $past(addr) == R_MODE_CTRL);              // R5
    end
  end
`endif
endmodule

`default_nettype wire
