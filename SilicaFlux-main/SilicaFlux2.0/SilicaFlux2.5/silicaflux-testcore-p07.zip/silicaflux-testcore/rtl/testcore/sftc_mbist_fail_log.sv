// =============================================================================
// SilicaFlux TestCore :: sftc_mbist_fail_log
// Diagnostic failure logger, independent of the test algorithm.
//   * FIRST failure: bank, element, op, walk bit, address, expected and
//     observed data (syndrome = expected ^ observed is derived on read-out).
//     Preserved until `clear` (start of a run or explicit CLEAR).
//   * FAIL_COUNT: saturating counter (CNT_W bits).  On saturation the value
//     stays at all-ones and `cnt_ovf` is set (sticky): the true count is then
//     ">= 2^CNT_W - 1".
//   * Optional FIFO of the next LOG_DEPTH failures (address, info, syndrome).
//     Bounded storage: when full, further records are dropped and `log_ovf`
//     is set (sticky).  LOG_DEPTH = 0 removes the FIFO entirely.
// `ev` is a single-cycle event.  `pop` removes the FIFO head.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sftc_defs.svh"
`default_nettype none

module sftc_mbist_fail_log #(
  parameter int MAX_W     = 32,
  parameter int AW        = 8,
  parameter int LOG_DEPTH = 4,
  parameter int CNT_W     = 16
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             clear,
  // failure event
  input  wire logic             ev,
  input  wire logic [23:0]      ev_info,     // [23:16] walk bit [15:12] op [11:8] element [7:0] bank
  input  wire logic [AW-1:0]    ev_addr,
  input  wire logic [MAX_W-1:0] ev_exp,
  input  wire logic [MAX_W-1:0] ev_obs,
  // first failure
  output logic                  ff_valid,
  output logic [23:0]           ff_info,
  output logic [AW-1:0]         ff_addr,
  output logic [MAX_W-1:0]      ff_exp,
  output logic [MAX_W-1:0]      ff_obs,
  // counter
  output logic [CNT_W-1:0]      fail_count,
  output logic                  cnt_ovf,
  // FIFO of subsequent failures
  input  wire logic             pop,
  output logic [7:0]            log_level,
  output logic                  log_ovf,
  output logic [23:0]           log_info,
  output logic [AW-1:0]         log_addr,
  output logic [MAX_W-1:0]      log_synd
);
  // ------------------------------------------------------------- first failure
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ff_valid <= 1'b0; ff_info <= '0; ff_addr <= '0; ff_exp <= '0; ff_obs <= '0;
    end else if (clear) begin
      ff_valid <= 1'b0; ff_info <= '0; ff_addr <= '0; ff_exp <= '0; ff_obs <= '0;
    end else if (ev && !ff_valid) begin
      ff_valid <= 1'b1; ff_info <= ev_info; ff_addr <= ev_addr; ff_exp <= ev_exp; ff_obs <= ev_obs;
    end
  end

  // ------------------------------------------------------------- counter
  wire cnt_sat = (fail_count == {CNT_W{1'b1}});
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)                 begin fail_count <= '0; cnt_ovf <= 1'b0; end
    else if (clear)             begin fail_count <= '0; cnt_ovf <= 1'b0; end
    else if (ev && cnt_sat)     cnt_ovf <= 1'b1;
    else if (ev)                fail_count <= fail_count + 1'b1;
  end

  // ------------------------------------------------------------- FIFO
  generate
    if (LOG_DEPTH > 0) begin : g_fifo
      localparam int PW = (LOG_DEPTH > 1) ? $clog2(LOG_DEPTH) : 1;
      logic [23:0]      f_info [LOG_DEPTH];
      logic [AW-1:0]    f_addr [LOG_DEPTH];
      logic [MAX_W-1:0] f_synd [LOG_DEPTH];
      logic [PW-1:0]    rd_p, wr_p;
      logic [7:0]       level;

      wire push    = ev && ff_valid;                     // first failure is held separately
      wire full    = (level == 8'(LOG_DEPTH));
      wire do_pop  = pop && (level != 8'd0);
      wire do_push = push && (!full || do_pop);

      function automatic logic [PW-1:0] inc(input logic [PW-1:0] p);
        inc = (32'(p) == LOG_DEPTH - 1) ? '0 : p + 1'b1;
      endfunction

      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          rd_p <= '0; wr_p <= '0; level <= '0; log_ovf <= 1'b0;
        end else if (clear) begin
          rd_p <= '0; wr_p <= '0; level <= '0; log_ovf <= 1'b0;
        end else begin
          if (push && full && !do_pop) log_ovf <= 1'b1;
          if (do_push) wr_p <= inc(wr_p);
          if (do_pop)  rd_p <= inc(rd_p);
          if (do_push && !do_pop)      level <= level + 8'd1;
          else if (do_pop && !do_push) level <= level - 8'd1;
        end
      end
      always_ff @(posedge clk) begin
        if (do_push) begin
          f_info[wr_p] <= ev_info;
          f_addr[wr_p] <= ev_addr;
          f_synd[wr_p] <= ev_exp ^ ev_obs;
        end
      end
      assign log_level = level;
      assign log_info  = (level != 0) ? f_info[rd_p] : '0;
      assign log_addr  = (level != 0) ? f_addr[rd_p] : '0;
      assign log_synd  = (level != 0) ? f_synd[rd_p] : '0;

`ifdef SFTC_CHECKS
      always @(posedge clk) begin
        if (rst_n && !clear) begin
          `SFTC_ASSERT(level <= 8'(LOG_DEPTH), "failure FIFO level exceeds depth")
        end
      end
`endif
    end else begin : g_nofifo
      assign log_level = '0;
      assign log_info  = '0;
      assign log_addr  = '0;
      assign log_synd  = '0;
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)                log_ovf <= 1'b0;
        else if (clear)            log_ovf <= 1'b0;
        else if (ev && ff_valid)   log_ovf <= 1'b1;   // subsequent records not stored
      end
      wire unused_pop = pop;
    end
  endgenerate
endmodule

`default_nettype wire
