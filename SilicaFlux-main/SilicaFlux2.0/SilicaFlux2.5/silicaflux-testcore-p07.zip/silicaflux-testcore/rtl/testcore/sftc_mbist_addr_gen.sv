// =============================================================================
// SilicaFlux TestCore :: sftc_mbist_addr_gen
// Bidirectional address generator for March elements.
//   * ascending : 0, 1, ..., last
//   * descending: last, last-1, ..., 0
// `last` = bank depth - 1 (any value, not restricted to 2^n - 1).
// `at_end` is asserted on the final legal address of the current direction.
// The controller must never `step` while `at_end` (asserted), so the counter
// cannot wrap or underflow: every address 0..last is visited exactly once per
// element.  No arithmetic beyond +1/-1 and an equality compare.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sftc_defs.svh"
`default_nettype none

module sftc_mbist_addr_gen #(
  parameter int AW = 8
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          load,     // start an element
  input  wire logic          dir_dn,   // direction for load (held by caller during element)
  input  wire logic [AW-1:0] last,     // highest legal address
  input  wire logic          step,     // advance to next address
  output logic      [AW-1:0] addr,
  output logic               at_end
);
  // The direction is latched at `load`; stepping and end detection use the
  // latched value only (no combinational path from dir_dn to at_end).
  logic dir_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)      begin addr <= '0; dir_q <= 1'b0; end
    else if (load)   begin addr <= dir_dn ? last : '0; dir_q <= dir_dn; end
    else if (step)   addr <= dir_q ? (addr - 1'b1) : (addr + 1'b1);
  end

  assign at_end = dir_q ? (addr == '0) : (addr == last);

`ifdef SFTC_CHECKS
  always @(posedge clk) begin
    if (rst_n) begin
      `SFTC_ASSERT(!(step && at_end && !load), "address generator stepped past the final address")
      `SFTC_ASSERT(!(step && load), "load and step in the same cycle")
    end
  end
`endif
endmodule

`default_nettype wire
