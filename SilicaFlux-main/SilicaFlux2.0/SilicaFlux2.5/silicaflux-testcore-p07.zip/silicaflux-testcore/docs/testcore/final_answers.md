# Final answers (Project 07 questions), with evidence

All numbers come from the recorded regression (`reports/testcore/REGRESSION.md`, overall **PASS**, 15/15 steps) and its generated tables (`docs/testcore/generated/`). Where evidence is missing, that is stated.

## 1. Which SRAM banks are testable?

**In this delivery (verified against the real RTL of each project):**

* **SilicaFlux-V main SRAM, 4 × 32 × 8192.** Tested through `sftc_sfv_bank_shim` around the unmodified `sfv_sram_slave`.
  * March C− on all four banks: PASS, 524 326 cycles, under live SFB traffic.
  * Injected stuck-at-1 at bank 2, word 4097, bit 13: detected exactly (element 1, op r0, expected `0`, observed `0x2000`).
* **SRAM Wrapper Library memories, as used by MCU-I and DataFabric.**
  * `sram_sp` at latency 1 and 2, and with 36-bit words including the parity column.
  * `sram_1r1w`.
  * All six algorithms PASS under traffic, and faults are located (`tb_testcore_sys`, 24 system tests).
* **DataFabric `sfb_sram_slave` through the SFB2 fabric path.** March C− PASS; a stuck-at-0 is located.

**Testable by the same hardware but not wired into an SoC top here:**

* the 4 SilicaFlux-V TSPM banks (tile `bist_*` collar, 32 × 1024);
* the MCU-I banks inside `mcu_soc`.

The SoC top-level edits needed are listed in `sram_integration.md` §2. They were not made because the original repository must not be modified.

## 2. Which memories remain inaccessible?

* **Boot ROM** (SFV 32 × 1024, MCU-I 32 × 2048). It has no test port and no MISR. It is synthesised logic, so scan and ATPG plus a functional read-back are the path.
* **CPU register files** (32 × 31 in both designs), **UART FIFOs**, and the **MCU-I DSP coefficient and delay-line arrays.** These are flip-flop arrays: covered by scan, not by MBIST.
* **TSPM and MCU-I banks**, until the SoC top-level integration is done (see question 1).
* **The IHP macros' internal BIST pins** (`A_BIST_*`). They are tied off in both designs and unused by design.

## 3. How long does each MBIST algorithm take (modelled clock cycles)?

Measured RTL cycle counts equal the closed-form model in every deterministic configuration (exact match required). Full table: `generated/mbist_cycles.md`.

For one SilicaFlux-V 32 × 8192 bank, read latency 1, scrub on:

| Algorithm | Cycles | Time at 50 MHz |
|---|---|---|
| March C− | 131 083 | 2.62 ms |
| MATS+ | 65 544 | 1.31 ms |
| Checkerboard / inverse checkerboard | 32 775 each | 0.66 ms each |
| Walking one / walking zero | 802 822 each | 16.1 ms each |

All 4 SFV main banks with March C− take 524 326 cycles, which is 10.5 ms. At latency 2, March C− takes 172 043 cycles per bank.

Rule: a read costs (1 + L) cycles and a posted write costs 1 cycle. This one-transaction-at-a-time model is 1.5× the nominal 10N operations; that is the deliberate price of latency-independent correctness.

## 4. Which fault models were actually injected?

All of the following, under the single-fault assumption, in `sftc_fault_mem` (simulation only) and the independent Python golden model. The enumerated population for each fault is run under all 6 algorithms.

* **Cell faults:** stuck-at-0/1 and transition ↑/↓, for every cell.
* **Address-decoder faults:** alias, multi-access and no-access, for every ordered address pair.
* **Read-path and column faults:** read-path inversion; data-line stuck-at.
* **Coupling faults:**
  * inversion coupling (CFin);
  * idempotent coupling (CFid);
  * state coupling (CFst).

  Deterministic samples of inter-word (victim above and below the aggressor) and intra-word pairs.
* **Read and error faults:** intermittent read every k-th access; memory error flag.
* **Protocol faults:**
  * +3-cycle latency, legal, must PASS;
  * dropped response → ERROR;
  * withdrawn grant → ERROR;
  * duplicated response → ERROR, never PASS.

**Total:** 15 320 RTL cases across 10 configurations, every one matching the golden model.

## 5. Which injected faults were detected?

Full table: `generated/fault_coverage.md`. Coverage is over the synthetic population only; it is not silicon defect coverage.

**March C− with solid background: 2216 / 2376 = 93.3 %.**

* **100 %:** stuck-at, transition, address-decoder, CFin, read inversion, data-line, intermittent and error-flag faults.
* **83.3 %:** CFid and CFst.
* **Every escape is an intra-word CFid/CFst pair** (80 + 80 of 320). That is the known limit of word-oriented March tests with a single data background. Recommendation: also run with the checkerboard background (TEST_CONTROL[8]) or with walking patterns.

**Other algorithms:**

| Algorithm | Detected | Coverage |
|---|---|---|
| MATS+ | 1824 / 2376 | 76.8 % |
| Checkerboard | 868 / 2376 | 36.5 % |
| Inverse checkerboard | 836 / 2376 | 35.2 % |
| Walking one | 1115 / 2376 | 46.9 % |
| Walking zero | 1132 / 2376 | 47.6 % |

All protocol faults produced the expected PASS or ERROR, never a false PASS.

## 6. How much additional RTL area did MBIST introduce?

Measured with Yosys 0.70 on sky130hd tt, identical constraints for every variant (`generated/synthesis.md`), compared against the A0 baseline of 4 SFV bank slaves with no MBIST:

| Variant | Contents | Added area |
|---|---|---|
| B | TestCore MBIST, 4 ownership shims, registers | +32 678 µm² |
| C | B + mode controller | +33 400 µm² |
| D | full TestCore with JTAG/CDC | **+42 406 µm²** (895 logic flops, 0 latches) |
| Dmin | D, first-failure record only, 8-bit count | +32 590 µm² |
| A1 | release-1 `sfv_mbist`, for comparison | +4 488 µm² |

The failure FIFO alone is 15 495 µm².

**Context:** the SFV project's own sky130 report (as reported by the project, not re-run here) gives 0.398 mm² of standard cells and 34.15 mm² die. TestCore D is about 10.7 % of that standard-cell area and about 0.12 % of the die.

**Fit in budget:** this fits within the first-silicon area budget. No explicit numeric area budget exists in the repository, so this is a judgement against the reported die size.

## 7. Does test access change normal SRAM latency?

**No.** The functional read latency stays at 1 cycle (SFV) and `READ_LATENCY` (SRAM library). The shims and wrappers add only combinational gating on `req`/`gnt` and the owner's block signal, and no register on the functional path. This is verified in simulation: functional masters with scoreboards run before, during and after testing with zero errors.

**Timing:** pre-placement worst slack at the functional ports moves from 14.89 ns (A0) to 14.59 ns (D) at a 20 ns period. That is −0.30 ns, from the added gating.

## 8. Is the JTAG TAP functionally verified?

Yes, in simulation and formal proof, and through a real JTAG software stack against the RTL:

* `tb_jtag_tap`: 51 776 checks. Covers 16/16 states and 32/32 arcs against an independent reference, every opcode's DR length, BYPASS, IDCODE, TRST, the CDC at 4 clock ratios, a stopped system clock, and a system reset during a request.
* Formal `fv_tap` and `fv_bridge` (multiclock, unbounded PDR): PASS.
* OpenOCD 0.12 enumerated the TAP, read IDCODE `0x15F07001`, ran MBIST, and played SVF against the RTL. The fault-free SVF passes and the faulty one is rejected.

**Not shown:**

* IEEE 1149.1 compliance: there is no boundary-scan register, EXTEST/SAMPLE are reserved, and no conformance suite was run;
* any physical adapter or silicon.

## 9. Is scan insertion working with the chosen cell library?

**Yes, structurally, on the TestCore logic with sky130hd.**

* OpenROAD 26Q3 replaced all 1 227 flops with library scan flops: 0 non-scan flops remain.
* It built 8 clock-domain-pure chains: 6 × 176 on `clk`, 164 on TCK rising, and 7 on TCK falling.
* Every chain passes a bit-exact gate-level continuity test with liberty-derived cell models.

**One tool issue was found and worked around in RTL:** a negedge flop with async SET was mis-chained by OpenROAD.

**Not production-ready.** It lacks compression, placement-aware ordering and shift/capture hold closure: ideal-clock hold is −0.13 ns before CTS. Placement shows +19.9 % area and +21.4 % HPWL after scan, measured on the TestCore block.

## 10. Is ATPG coverage measured or still pending?

**Production ATPG coverage is pending.** No commercial ATPG was run, and the ≥ 99 % stuck-at and ≥ 95 % transition targets are not met or measured.

An **in-house research experiment** was run with this model: full scan, stuck-at faults on net stems, `clk` + `tck` capture, and memories as X black boxes. On 9 028 faults it measured:

* **75.3 % fault coverage and 91.6 % test coverage**;
* 8 192 random patterns, of which 166 were useful, plus 117 SAT patterns;
* 201 faults untestable;
* 1 408 faults unobservable, mostly logic feeding only the black-boxed macro inputs;
* 623 faults aborted as X-dependent.

A sample of 24 patterns replayed on the scan netlist at gate level: 21 480 bits compared, 0 mismatches. Transition faults were not modelled.

## 11. Can the CPU safely boot following a destructive memory test?

**Yes, under the documented conditions, and verified for the memory side.**

* After a test, each bank is scrubbed to zero and released only once nothing is in flight. Functional reads after release return 0, checked by scoreboard.
* The CPU must run from ROM with no SRAM stack during the test, which is the existing SFV `start.S` behaviour. Banks holding live CPU state must be in PROTECT; they are acquired only while the CPU is halted (verified).
* After an abort, the bank is still scrubbed. After hardware-permission loss or a TestCore reset, the bank is **not** scrubbed and REINIT_REQUIRED is flagged, so software must initialise it.

**Not shown:** an actual CPU boot after MBIST in an integrated SoC simulation, because no SoC top-level integration was made (see question 1).

## 12. What test pins must the first fabricated chip expose?

**Required:**

* TCK, TMS, TDI, TDO (tri-state);
* RST_N and CLK_IN (already functional pins);
* TEST_MODE (`scan_mode_pin`), gated internally by OTP lifecycle (`hw_test_en`);
* SCAN_EN.

**Recommended:**

* TRST*;
* TEST_PASS / TEST_FAIL / TEST_DONE for wafer-probe status.

**Scan data:** 8 scan-in and 8 scan-out for the TestCore block alone. At SoC level these should be multiplexed onto GPIO in TEST_MODE, as in the SilicaFlux-V plan, or reduced with compression. The SoC chain count is a tester-channel decision that has not yet been made.

## 13. Which commercial DFT tools or foundry libraries are still required?

* **Foundry PDK and libraries** for the selected node: standard cells with scan flops and a characterised synchroniser cell, ICG and glitch-free clock mux, I/O library with boundary-scan cells, and memory compiler outputs (timing, scrambling, and redundancy if repair is wanted).
* **Scan, compression and ATPG:** Siemens Tessent, Synopsys DFTMAX/TestMAX, or Cadence Modus. Use this flow for stuck-at and transition ATPG with an OCC, and for DFT DRC.
* **Vendor MBIST**, if the memory compiler requires it (for example Tessent MemoryBIST), for qualified algorithms, scrambling-aware backgrounds and repair.
* **Sign-off tools:** CDC/RDC sign-off, gate-level simulation with SDF, and equivalence checking.
* **ATE converters:** STIL/WGL tooling for the selected tester.

## 14. What must be completed before wafer probing?

See `limitations_and_blockers.md`, "Before wafer probing". In summary:

1. SoC integration and full SoC regressions.
2. Commercial scan insertion and ATPG with coverage sign-off.
3. Memory compiler data and macro timing.
4. Post-layout STA in all test modes with hold repair, plus test-power analysis.
5. FPGA validation of the hardware adapter path.
6. JEDEC ID, OTP lifecycle and security review.
7. ATE program, probe card and binning plan.
