# Python host-side test automation (`python/testcore`)

Requirements: Python ≥ 3.12 (tested with 3.13), pydantic 2, pytest. Optional: z3-solver (ATPG), OpenOCD (hardware transport).

| Module | Content |
|---|---|
| `spec.py` | parses `rtl/testcore/sftc_consts.svh`; the host never duplicates encodings |
| `transports/sim.py` | `SimTransport`: drives `tb_testcore_sys` (the real RTL) over named pipes; adds simulation-only knobs (pins, traffic, faults) |
| `transports/openocd.py` | `OpenOcdTransport`: OpenOCD TCL-RPC (irscan/drscan/runtest); raises `HardwareNotAvailable` |
| `jtag.py` | TAP navigation over bit-level transports |
| `host.py` | `TestCoreHost`: IDCODE, BYPASS, TC_STATUS, TC_REG protocol with BUSY/CLEAR recovery, identification, mode control, MBIST run/poll/collect, failure FIFO, diagnostics |
| `report.py` | structured test record (JSON + CSV), status enum, bin rules |
| `patterns.py` | pattern model + SVF adapter |
| `mbist.py`, `fault_models.py` | golden model |
| `sim/` | RTL regression drivers |
| `atpg/` | ATPG experiment |
| `cli.py` | command line |

## Commands (all backed by real software)

```bash
cd python
python -m testcore scan                      # hardware (OpenOCD on 127.0.0.1:6666)
python -m testcore scan --transport sim      # RTL simulation
python -m testcore mbist --bank all --algorithm march_c_minus --run-dir ../reports/test_run [--transport sim --sim-traffic]
python -m testcore diagnostics --transport sim
python -m testcore report --run-dir ../reports/test_run
python -m testcore svf --bank all --algorithm march_c_minus --wait-tck 12000 --out mbist.svf
python -m testcore bringup --transport sim --run-dir ../reports/bringup
```

**No adapter:** without an OpenOCD server the CLI prints **HARDWARE NOT AVAILABLE**, writes a BLOCKED record and exits with status 3. This is tested in `test_cli_without_hardware_reports_not_available`.

**Simulation runs:** every record is marked `evidence_class = SIMULATION`, carries the note "RTL SIMULATION RESULT - NOT A SILICON TEST", and is never binned.

## Hardware path status

* `OpenOcdTransport` was exercised only against the RTL simulation, through OpenOCD's `remote_bitbang` driver (`tools/rbb_sim_bridge.py`, `scripts/run_openocd_bridge.sh`).
* It has never been used with a physical adapter (FT2232H, J-Link, etc.) or with silicon.
* The OpenOCD configuration for the TAP is `asic/dft/openocd/silicaflux_testcore.cfg`.
