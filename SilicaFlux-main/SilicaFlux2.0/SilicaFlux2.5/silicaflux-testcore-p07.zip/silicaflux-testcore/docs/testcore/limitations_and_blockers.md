# Explicit limitations, blockers and what is NOT claimed

## Not claimed

* IEEE 1149.1 compliance. There is no boundary-scan register, EXTEST/SAMPLE are reserved, no BSDL is provided, and no conformance suite was run.
* A valid JEDEC manufacturer ID. `IDCODE_MFG` is a placeholder.
* Production scan or ATPG coverage. The targets (stuck-at ≥ 99 %, transition ≥ 95 %) are **not met and not measured** by a production flow. The in-house experiment's numbers apply only to its stated model.
* Silicon, FPGA, wafer-probe or packaged-part results. **None exist.** No test record in this delivery is silicon evidence.
* Memory repair. No macro with redundancy exists.
* Retention testing.
* Non-destructive (save/restore) memory test.
* Security. The unlock key is an interlock only. There is no lifecycle/OTP implementation and no authenticated debug.
* A physical JTAG adapter path. The OpenOCD transport was exercised only through `remote_bitbang` against the RTL.
* Metastability / MTBF of the synchronisers. Formal models them as ideal flops; CDC tool sign-off is pending.
* Code or functional coverage metrics. None were collected; the scenario and state/arc coverage listed in the verification report is what exists.

## Blockers and missing dependencies

| Item | Blocker | Needed |
|---|---|---|
| Production scan, compression, ATPG | open tools are experimental (OpenROAD DFT) or absent (Fault not packaged, not built) | Siemens Tessent / Synopsys DFTMAX+TestMAX / Cadence Modus with foundry libraries |
| Transition / at-speed test | no OCC; no transition-fault ATPG | OCC design and a commercial ATPG |
| Memory timing at speed | OpenRAM sky130 macro misses 50 MHz (SFV report); macro proxy has no timing | foundry or compiler macro timing models, macro-aware STA |
| Post-layout timing / hold | no CTS / route in this delivery; −0.13 ns ideal-clock hold in scan modes | full PnR (ORFS / FloorplanLab) and hold repair |
| SoC integration | the original repository must not be modified | edit `sfv_soc` / `sfv_tile` / `mcu_soc` per `sram_integration.md` §2 |
| Boundary scan | pad ring / I/O cells not selected | foundry I/O library with BSR cells |
| Lifecycle / straps | OTP not designed | OTP macro, lifecycle encoding, secure unlock |
| Wafer probe / ATE | no tester, probe card or load board | tester selection, SVF/STIL conversion with the supplier's tools |
| IHP / GF180 characterisation of TestCore | only sky130hd was used here | repeat `run_synth.py` with those liberties (FloorplanLab / TimingLab collateral) |

## Before wafer probing

1. Integrate TestCore into the SFV/MCU SoC top and re-run all SoC regressions.
2. Run commercial scan insertion and ATPG on the SoC netlist, with untestable-fault review and coverage sign-off against targets.
3. Get memory compiler MBIST-related data (latency, scrambling, read-during-write) and macro timing.
4. Run post-layout STA in every test mode, with hold repair; run a test-power (shift/capture IR-drop) analysis.
5. Validate the hardware adapter path on an FPGA build: OpenOCD + FT2232H + the TestCore bitstream.
6. Get an assigned JEDEC ID, OTP lifecycle, and the security review.
7. Build the ATE program, probe card and binning plan.
