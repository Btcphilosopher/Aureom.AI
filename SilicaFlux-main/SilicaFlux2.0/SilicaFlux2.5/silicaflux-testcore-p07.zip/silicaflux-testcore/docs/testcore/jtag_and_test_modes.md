# JTAG test access, clock-domain crossing and test modes

## 1. TAP (`sftc_jtag_tap`)

* 16-state IEEE 1149.1-style controller, 5-bit IR.
* Capture-IR value `00001`.
* IR update and TDO change on the falling edge of TCK; TDO is driven only in Shift states.
* TLR and TRST* select IDCODE.
* The IR is stored XOR-encoded so that all falling-edge flops reset to 0 (DFT fix D10).
* Opcodes are in `generated/jtag_instructions.md`.
* Unassigned opcodes, and EXTEST/SAMPLE (reserved until a pad-ring BSR exists), select BYPASS.

**Verification:**

* `tb_jtag_tap`, against an independent table-driven reference model:
  * all 16 states and all 32 arcs are covered;
  * 5 × TMS=1 reaches TLR from every state;
  * the DR length of every one of the 32 opcodes matches the spec;
  * BYPASS, IDCODE, and TRST in mid-shift.
* Formal `fv_tap` (PDR, multiclock): T1 5 × TMS=1 → TLR, T2 DR-select exclusivity, T3 TLR selects IDCODE.
* OpenOCD 0.12 (real JTAG stack) enumerated the TAP and read IDCODE through the `remote_bitbang` bridge, then ran the full host flow and SVF playback.

**Not claimed:** IEEE 1149.1 compliance (no BSR, no conformance suite run); a valid JEDEC manufacturer ID (it is a placeholder).

## 2. TCK → system-clock crossing (`sftc_jtag_reg_bridge`)

* **Request (toggle handshake).** The TCK side writes the payload only when idle, then toggles `req`. The payload is held until the synchronised acknowledge returns. The system side detects exactly one pending request, executes it once, stores the result, then acknowledges.
* **Result.** It is read by TCK only after the acknowledge has returned, i.e. at least two TCK edges after the result last changed. No register is ever sampled while it changes.
* **Busy.** A capture while a request is in flight returns BUSY and sets a sticky flag. Later requests are ignored until CLEAR, so the host always knows when a request was not executed.
* **System reset.** The system side arms for 3 cycles after reset and then signals ready. TCK does not launch before ready (fix D6, found by the multiclock proof). A request caught by a system reset completes with STATUS = ERROR, never a stale OK.
* **Clock-alive indicator.** TC_STATUS[2] uses a ping/pong echo between captures and is robust for any clock ratio.
* **System clock stopped.** Requests stay BUSY (reported, not lost) and TC_STATUS shows `sysclk_alive = 0`. TAP and IDCODE keep working.

**Proofs:** `fv_bridge`, with the two clocks fully asynchronous (solver-chosen interleaving):

* B1: launched − executed ∈ {0, 1}, i.e. no duplication and at most one request in flight;
* B2: the payload is stable while pending.

**Simulation:** `tb_jtag_tap` T7, T8 and T10, at clk/TCK half-period ratios 5/50, 18.5/7, 2.3/61 and 41/13 ns, with the system clock stopped, and with a system reset during a request.

**Not modelled:** metastability. Synchronisers are ideal flops in the proof. A CDC tool sign-off plus synchroniser MTBF analysis against the library's sync cell is still required.

**Host minimum Run-Test/Idle** between update and the next capture: about (24 × T_clk / T_TCK) + 4 TCK. The host library adapts automatically (it doubles the idle on BUSY).

## 3. Test modes (`silicaflux_test_mode_controller`)

| from \ to (register request) | NORMAL | JTAG_ACCESS | MBIST | DIAGNOSTIC | SCAN_* / 6 / 7 |
|---|---|---|---|---|---|
| NORMAL | – | hw_dbg_en | hw_test_en & unlocked | hw_dbg_en | ILLEGAL |
| JTAG_ACCESS | ok | – | hw_test_en & unlocked | hw_dbg_en | ILLEGAL |
| MBIST | exit | exit, needs hw_dbg_en | – | ILLEGAL | ILLEGAL |
| DIAGNOSTIC | ok | hw_dbg_en | ILLEGAL | – | ILLEGAL |

**Request handling:**

* "exit" from MBIST means: soft abort (the engine scrubs), wait until the engine is idle and every bank is released, then switch.
* A request that is not in the table sets `EF_ILLEGAL_MODE` and leaves the mode unchanged.
* A legal request without permission is DENIED: the same flag is set and the mode is unchanged.

**Permission loss and scan:**

* **Hardware permission loss** forces NORMAL immediately. For MBIST this is a hard stop: no new request is issued (proven), there is no scrub, and the banks are flagged REINIT_REQUIRED.
* **Scan:** `scan_mode_pin & hw_test_en` overrides everything combinationally. `scan_en = scan_mode & scan_en_pin`. Register requests are illegal while it is active. Leaving scan requires a reset.

**Verification:**

* Formal `fv_mode_ctrl` (PDR):
  * M1 MBIST requires hw_test_en & unlocked;
  * M2 debug modes require hw_dbg_en;
  * M3 scan enable only from the pins;
  * M4 one mode at a time;
  * M5 MBIST is entered only on a permitted request;
  * M6 no spontaneous change except to NORMAL;
  * M7 reset → NORMAL.
* `test_mode_transition_policy_exhaustive`: 4 source modes × 8 codes × 8 permission combinations = 256 cases on the RTL, compared with the table above.

**Security note:** the unlock key is a *deliberate-action interlock*, not security. Physical test-access security needs lifecycle states in OTP, authenticated debug unlock (challenge-response), and fault-injection hardening. None of these is implemented. `hw_test_en` / `hw_dbg_en` must come from OTP lifecycle or straps, never from a software register.
