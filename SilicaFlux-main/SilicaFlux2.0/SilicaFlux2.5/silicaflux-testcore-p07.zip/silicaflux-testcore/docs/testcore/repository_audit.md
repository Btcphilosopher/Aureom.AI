# SilicaFlux TestCore — repository and DFT audit (Phase 1)

Audit date: 2026-11-06. Source: GitHub `btcphilosopher/aureom.ai`, branch `claude/peaceful-noether-la1ws5`,
commit `36e36d8`. Everything below was read from the files. Every regression quoted here was **re-executed in
this session** unless it is marked "(as reported by the project)".

## 1. What the repository actually contains

* The SilicaFlux sources live in `SilicaFlux-main/`. Most projects there are **zip archives**, not checked-out trees.
  This audit extracted every archive (read-only) and inspected the contents.
* `.sf` files are **plain SystemVerilog with a different extension**:
  * `SilicaFlux2.0/SilicaFlux2.5/run_sim.sh` sets `SF_EXT=.sf` and compiles them with
    `iverilog -g2012 -Wall -Wno-timescale`, `silicaflux_pkg.sf` first.
  * 29 of the 33 `.sf` files contain modules; `tb_*.sf` files are testbench tops.
* `.sfx` files are assembler source for `sfx_asm.py`, not HDL.

| Archive (SHA-256 prefix) | Project | Relevance to TestCore |
|---|---|---|
| `silicaflux-v-release1.zip` (424816e9) | **SilicaFlux-V** CPU/vector/tensor SoC, release 1 | primary target; has `sfv_mbist`, MBIST collars, `sfv_jtag` |
| `SilicaFlux2.5/silicaflux-mcu-i.zip` (f2dd5bda) | **MCU-I** industrial MCU | secondary target; uses the SRAM Wrapper Library |
| `SilicaFlux2.5/silicaflux-sramlib.zip` (13b1cee1) | **Project 01 SRAM Wrapper Library** | integrated (vendored unmodified) |
| `silicaflux-datafabric.zip` (9f1f3735) | **Project 03 DataFabric** (SFB2) | integrated (SFB2 adapter + real `sfb_sram_slave`) |
| `SilicaFlux2.5/silicaflux-timinglab*.zip` (v1.0, v2.0) | **Project 06 TimingFlow** | mode SDCs follow its OpenSTA conventions |
| `SilicaFlux2.5/silicaflux-floorplanlab.zip` | **Project 05 FloorplanLab** | placement experiment reuses its OpenROAD approach |
| `SilicaFlux2.5/silicaflux-testcore.zip` (6664b3a6) | **an earlier TestCore** ("legacy TestCore r1") | audited, re-run, partially reused (§5) |
| `silicaflux.zip` | SilicaFlux v1.0 cluster RTL | per-tile 1 KiB SRAMs; not a first-silicon target |

## 2. Memory inventory

### 2.1 SilicaFlux-V (top `sfv_soc`, `rtl/top/sfv_soc.sv`; defaults `SRAM_BANKS=4`, `SRAM_BANK_WORDS=8192`, `TSPM_WORDS=4096`, `ROM_WORDS=1024`)

| # | Instance path | Source | Type / ports | W × D | Read latency | Write mask | Clock | Array reset | Masters | Existing test interface | Backend | Macro availability | Testability limits |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1–4 | `g_sram[0..3].u_bank.u_ram` | `sfv_sram_sp` (`rtl/mem/sfv_sram_sp.sv`) in `sfv_sram_slave` (`rtl/mem/sfv_mem_slaves.sv:14`) | SRAM 1RW | 32 × 8192 (32 KiB each) | 1 cycle | `be[3:0]` (forced 1111 in BIST) | `clk` | no | JTAG SBA, CPU-D, CPU-I via `sfv_xbar` | collar `bist_en/ce/we/addr/wdata/rdata`; `gnt = !bist_en` | inferred array, or `-DSFV_SRAM_MACRO` → `sfv_sram_macro_bank` | sky130: 8 × `sky130_sram_1rw1r_128x256_8` per bank; IHP: 2 × `RM_IHPSG13_1P_2048x64` per bank | collar fixed at 1-cycle latency; byte enables not exercised by MBIST; no ECC/parity (ISS-014) |
| 5–8 | `u_tile.g_bank[0..3].u_ram` | `sfv_sram_sp` in `sfv_tile` (`rtl/accel/sfv_tile.sv:161`) | SRAM 1RW, word-interleaved (bank = addr[3:2]) | 32 × 1024 (16 KiB total) | 1 cycle | `be` | `clk` (ungated) | no | MBIST > TE/VE lock owner > fabric | tile `bist_*` (all 4 banks in parallel) | as rows 1–4 | sky130: 1 macro / bank; IHP: 512x64 | **TSPM MBIST group is never exercised** by firmware or any SoC test |
| 9 | `u_rom.u_img` | `sfv_bootrom` (`sfv_mem_slaves.sv:77`) + generated `sfv_bootrom_image` | ROM 1R | 32 × 1024 (698 words used) | 1 cycle | n/a | `clk` | address flops only | CPU-I/D, JTAG | **none** (no MISR / signature) | synthesised logic | no ROM macro | only testable by scan / functional read-back |
| 10 | `u_cpu.rf` | `sfv_cpu.sv:234` | register file 2R1W, async read | 32 × 31 | 0 | — | `clk` | no | CPU | none | flip-flops | n/a | covered by scan (flops), not by MBIST |
| 11–12 | `u_uart.u_txf/u_rxf.mem` | `sfv_fifo` (`sfv_common.sv:79`) | FIFO | 8 × 4 | 0 | — | `clk` | pointers only | UART | none | flip-flops | n/a | scan |

There are no caches ("no caches", `sfv_cpu.sv:6`) and no DMA (ISS-015).

### 2.2 MCU-I (top `mcu_top`, configs `basic` / `industrial`)

| # | Instance path | Source | Type | W × D (basic / industrial) | Latency | Mask | Masters | Test port | Backend / macro | ECC/parity |
|---|---|---|---|---|---|---|---|---|---|---|
| 1–4 | `u_soc.g_sram[0..3].u_bank.u_sram` | `mcu_sram_bank` → **sramlib `sram_sp`** (`READ_LATENCY=1, WRITE_ACK=1, TEST_EN=1`) | SRAM 1RW valid/ready | 32×4096 / **36×8192** | 1 | 4 lanes (8 or 9 bit) | CPU-I/D, JTAG, DMA (industrial) | `tst_*` ← `sfv_mbist` | GENERIC / FPGA / ASIC macros (IHP 4096x16, sky130 2kB 32x512, GF180 512x8) | industrial: byte parity (`chk_en`, `inject`); **parity bits not compared by the existing MBIST** |
| 5 | `u_soc.u_rom.u_img` | `sfv_bootrom` | ROM 32×2048 | 1 | — | CPU/JTAG/DMA | none | logic | none |
| 6–13 | `u_cpu.rf`, UART FIFOs, DSP `coef_q`/`dl_q`, sramlib response FIFOs | various | flop arrays | small | 0 | — | — | none | flops | none |

### 2.3 SRAM Wrapper Library (Project 01): what it provides

* **Wrappers:** `sram_sp` (1RW), `sram_1r1w`, `sram_tdp` (2RW), `sram_bank_controller` (N masters × N banks).
* **Backends:** `GENERIC` (simulation fault injection, `flt_kind` 1..6), `FPGA`, `ASIC` (real macros only, never flops).
* **Contract:**
  * valid/ready request;
  * in-order response with back-pressure;
  * `WRITE_ACK` option;
  * raw MBIST test port `tst_active/ce/we/addr/wdata` → `tst_rdata`, valid exactly `READ_LATENCY` cycles after a test read and never held;
  * `busy` = responses in flight.
* **Its own demonstration MBIST:** `sram_mbist_march` (March C-/MATS+, fixed latency).

**Use:** used by **MCU-I** (vendored copy) and by DataFabric `sfb_sram_slave`. **Not used by SilicaFlux-V**, which has its own `sfv_sram_sp` / `sfv_sram_slave`.

## 3. Existing test, debug and DFT logic

| Item | Where | Finding |
|---|---|---|
| `sfv_mbist` | `silicaflux-v/rtl/mem/sfv_mbist.sv` | March C- (10N + checkerboard). Fixed 1-cycle latency ("phase 0 issue read, phase 1 compare+write"). 32-bit only. Parallel broadcast to 4 banks. Runtime `last`. No handshake, no quiesce/drain, no timeouts. **Not usable** for latency-2 macros or valid/ready memories. |
| SYSCTRL MBIST regs | `sfv_sysctrl.sv:15-20` | CPU and JTAG-SBA can start it. Boot ROM runs group 0 only. |
| JTAG | `sfv_jtag.sv` (`sfv_jtag_tap`, `sfv_jtag_dbg`) | 5-bit IR. IDCODE `0x15F05001`, SBA (66-bit DR, toggle CDC), DBGCTRL. **No boundary scan, no RISC-V DM.** |
| Test mode | `sfv_soc.sv:186` | `test_mode` pin bypasses reset synchronisers and forces ICGs on. |
| Scan | — | **Not found** in any project (no `scan_en` / `scan_in`). |
| Clock gating | `sfv_tile.sv:68-69` | 2 ICGs. Library ICG `sky130_fd_sc_hd__sdlclkp_1` with `SCE = test_mode` (not scan enable). |
| MCU-I | `mcu_jtag.sv`, `mcu_dbg_gate.sv` | Same IR set, no BSR. 10 ICGs, all `test_en = test_mode`. No scan, no STA. |

### 3.1 Scan blockers found in SilicaFlux-V (inputs to `docs/testcore/dft.md`)

1. There are no scan-enable / scan-in / scan-out ports. The plan in `docs/DFT.md` is to mux them onto GPIO.
2. ICG `test_en` is tied to `test_mode`, so the clock-enable logic gets no capture coverage. TestCore's `sftc_dft_ctrl` drives TE from **scan enable**.
3. In test mode, the async-reset inputs of the `u_rs_sys` / `u_rs_cpu` synchroniser flops are still driven by internal logic (`soft_reset`, `jtag_srst`, `jtag_hold`). TestCore's `sftc_dft_ctrl` provides a pin-driven reset bypass.
4. clk↔tck crossings use generic `sfv_sync` flops; chains crossing domains would need lock-up latches. TestCore chains are built domain-pure (`-clock_mixing no_mix`).
5. There is no OCC (on-chip clock controller) for at-speed capture and no BSR.
6. Six negedge TCK flops (IEEE-required) need a separate chain.
7. Low-power isolation cells (`lpflow_*`) appear in the SFV sky130 netlist because there is no `dont_use` list. TestCore synthesis excludes them.

## 4. Build methods, flows and tools found

* **SilicaFlux-V:**
  * Makefile targets: `lint`, `cpu-tests`, `soc-sim` (Verilator), `unit` (cocotb/Icarus), `formal` (SymbiYosys), `fpga`, `asic`, `regress`.
  * ASIC flow: Yosys 0.33 synthesis + OpenSTA, then OpenROAD placement.
  * Collateral comes from ORFS platforms, which are not committed.
* **TimingLab v2.0:**
  * Yosys-slang → OpenSTA → OpenROAD at block level.
  * The sky130hd / IHP / GF180 libraries are fetched externally.
  * There is **no test-mode SDC**. `silicaflux_top.sdc` sets `test_mode_i` and `scan_en_i` to 0 with case analysis.
* **FloorplanLab:**
  * ORFS flow for `sfv_soc_df`, primarily on IHP SG13G2, with real reports.
  * The sky130 run failed its macro-overlap gate (as reported by the project).

## 5. The earlier TestCore ("legacy r1") — re-executed and evaluated

* I re-ran `silicaflux-testcore.zip` in a scratch copy with the tools installed here (Icarus 12, Verilator 5.020, Yosys 0.33, Python 3.13).
* `python3 scripts/regress.py` result: **PASS 16/16 steps**.
  * Checks per testbench: `tb_tap_fsm` 14 924, `tb_mbist` 207, `tb_mode_sec` 165, `tb_debug` 165.
  * pytest: 40 passed.
  * Generic synthesis: 13 670 cells, 2 723 flops, 1 ICG latch.
* Its own README is explicit that it is not 1149.1 compliance-tested, has no scan insertion and no ATPG, and has no silicon or adapter validation.

**Gap analysis against the Project 07 requirements:**

| Requirement | Legacy r1 | Decision |
|---|---|---|
| Request acceptance / variable latency; "operation must not advance until its transaction completed" | **No.** Fixed-latency pipeline: ops issued back-to-back and compared `MEM_LAT` cycles later. | **New engine** (`silicaflux_mbist`), fully handshake-based. |
| Memory ownership, quiesce, drain, re-initialisation | **No.** The collar switches immediately on `bist_active`. | **New** `sftc_mem_owner` + wrappers. |
| Integration with the SRAM Wrapper Library / SFV collars | own `tc_sram_model`, demo SoC only | **New** wrappers around the *real* library and *real* SFV slave. |
| Expected / observed data capture | syndrome only | **New** first-fail record (expected, observed, syndrome). |
| TAP state machine | correct structure (`tc_tap.sv`, 14 924 checks) | **Reused design** (adapted into `sftc_jtag_tap`, new opcode set). |
| TCK→clk register bridge | toggle handshake (`tc_reg_bridge.sv`) | **Reused design, one defect fixed** (§6). |
| Formal proofs | none | **New** (6 harnesses). |
| Scan insertion / ATPG | none (collateral templates only) | **New** OpenROAD insertion and ATPG experiment. |

## 6. Defects found during this project (all reproduced by a test, then fixed)

| # | Where | Defect | Found by |
|---|---|---|---|
| D1 | new MBIST engine | bank counter `$clog2(BANK_COUNT)` bits wide → endless loop when `BANK_COUNT` is a power of two | MBIST regression (multibank4 config) |
| D2 | new MBIST engine | address generator end flag depended combinationally on the load direction (combinational loop) | Verilator UNOPTFLAT |
| D3 | new MBIST engine | a NEW request could be presented in the cycle ownership / test_enable was withdrawn | formal `fv_mbist` F2 |
| D4 | new MBIST engine | a spurious response in the S_DONE cycle was flagged but still produced PASS | formal `fv_mbist` (embedded) |
| D5 | mode controller | JTAG/DIAG output stayed active one cycle after hardware permission loss | formal `fv_mode_ctrl` M2 |
| D6 | **register bridge (inherited from legacy r1 design)** | a request launched during the 3-cycle post-reset "arming" window was adopted as stale and silently dropped, while TCK reported OK | formal `fv_bridge` B1 (multiclock) |
| D7 | ownership controller | functional port blocked already in QUIESCE_REQUEST → a master with a pending request could never acknowledge (deadlock) | system simulation |
| D8 | TestCore top | acquire request held during the MBIST exit sequence → owners never released (deadlock) | system simulation |
| D9 | MBIST engine | refused START left the previous run's PASS in LAST_TEST_RESULT (false-PASS hazard for polling software) | system pytest |
| D10 | JTAG TAP | negedge IR bit with async SET mapped to an inverted-clock rising cell → OpenROAD placed it in a rising-edge chain (chain length off by one) | gate-level scan-chain continuity check |
| D11 | mode controller | MBIST→JTAG_ACCESS accepted without debug permission (then force-exited) | exhaustive mode-policy test |

No file of the original repository was modified. All of TestCore is new or vendored (see `files_changed.md`).
