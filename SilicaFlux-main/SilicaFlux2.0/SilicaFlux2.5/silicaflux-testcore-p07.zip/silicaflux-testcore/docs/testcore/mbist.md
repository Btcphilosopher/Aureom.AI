# MBIST algorithms, engine behaviour and limits

## Algorithms (word-oriented)

**Notation:** ⇑ ascending, ⇓ descending, ⇕ either (executed ascending).

* "0" means the background word BG(a); "1" means ~BG(a).
* Both are masked to the bank width.
* BG is the all-zero word (solid) by default. With TEST_CONTROL[8] it becomes the **logical** checkerboard, bit i = i[0] XOR a[0].

| ID | Name | Elements | Nominal ops |
|---|---|---|---|
| 0 | March C− | M0 ⇕(w0) · M1 ⇑(r0,w1) · M2 ⇑(r1,w0) · M3 ⇓(r0,w1) · M4 ⇓(r1,w0) · M5 ⇕(r0) | 10N |
| 1 | MATS+ | ⇕(w0) · ⇑(r0,w1) · ⇓(r1,w0) | 5N |
| 2 | Checkerboard | ⇑(w CB) · ⇑(r CB) | 2N |
| 3 | Inverse checkerboard | ⇑(w ~CB) · ⇑(r ~CB) | 2N |
| 4 | Walking one | per address: for b in 0..W−1 { w(1≪b), r(1≪b) }, then w(0) | (2W+1)N |
| 5 | Walking zero | as 4, over an all-ones background | (2W+1)N |

**Run options:**

* **Scrub:** after the algorithm, optional ⇑(w all-zero), enabled by default. It also runs after an ABORT or stop-on-fail, once the outstanding transaction has completed.
* **Compile-time exclusion:** any algorithm can be left out through `ALG_MASK`. An excluded or unknown algorithm makes START refuse (`EF_ILLEGAL_START`).

**Checkerboard caveat:** the checkerboard is logical. A physical checkerboard requires the macro's row/column scrambling and bit interleaving from the memory compiler datasheet, which is not available for any SilicaFlux macro here.

## Correctness properties

Each property is verified by at least one of: the golden-model regression, a formal proof (F#), or an RTL assertion.

* **Every address exactly once per element.** The address generator latches the direction and steps until the bound; it never steps past the end. There is no underflow in descending elements, and non-power-of-two depths work. Verified by: golden trace comparison for depths 2..512 including 11, 13, 17, 33, 37; assertion; formal F3.
* **Read checked before its dependent write.** There is one transaction at a time, and a write is issued only after the read's response has been compared. Verified by trace comparison and F5.
* **Correct expected data per element and op.** Verified by an exact trace match (bank, R/W, address, data) against the golden model for every traced case.
* **Completion only after the final response.** Verified by F6.
* **Robust under variable latency and back-pressure.** Verified with latency 1–5, 60 % grant, register slices, write responses, and the latency-2 SRAM-library macro.
* **No PASS with a mismatch or a protocol violation.** Verified by F7 and the embedded properties.
* **Failures recorded:**
  * first failure: bank, element, op, walk bit, address, expected, observed, syndrome;
  * saturating count with an overflow flag;
  * optional FIFO of the next `LOG_DEPTH` records with an overflow flag.

  All of this is checked bit-exact against the golden model.

## Fault models targeted (and what the algorithm choice does not guarantee)

| Algorithm | Classic theory (unlinked, bit-oriented) | Measured on the synthetic population |
|---|---|---|
| March C− | SAF, TF, AF, CFin, CFid, CFst | see `generated/fault_coverage.md` |
| MATS+ | SAF, AF | misses some TF and coupling faults (expected) |
| Checkerboard / inverse | SAF on half the cells per pass; pattern-sensitive neighbourhood checks | low on coupling and address faults |
| Walking 0 / 1 | intra-word bit coupling, data-line faults | weak on address-decoder faults |

Coverage depends on how the logical address and bit order map to the physical layout, on the real defect mechanisms, and on timing. **No algorithm gives "complete" memory fault coverage.** All numbers here are for the enumerated synthetic population only.

## Test time

`generated/mbist_cycles.md` gives the closed-form cycle counts for the real SilicaFlux-V and MCU-I bank geometries, plus RTL-measured values (the regression requires an exact match).

The engine uses one transaction at a time, so with L the read latency:

* a read costs 1 + L cycles;
* a posted write costs 1 cycle.

March C− therefore takes about 15N cycles at L = 1, against 10N nominal operations. That is 1.5× slower than a pipelined engine, and it is the price of latency independence.

## Retention testing

**Not implemented.** A retention test needs a pause element with an explicit duration, plus controlled temperature and supply voltage. None of these can be validated in functional simulation.

The element micro-code reserves the encoding for a future PAUSE element. No retention claim is made.

## Memory error flags (ECC / parity)

* `t_rerr` from the memory is treated as a failure of that read and sets `EF_MEM_ERR`.
* None of the SilicaFlux-V memories has ECC or parity.
* MCU-I industrial has byte parity. TestCore tests its **raw 36-bit storage, including the parity column**, through the SRAM library's raw `tst_*` port, which bypasses the parity checker. That is verified in `tb_testcore_sys` bank 2 (bit 35 stuck-at detected).
* The parity *checker and injection* logic of MCU-I is not exercised by TestCore. See `sram_integration.md` §4.
