# Memory ownership and access isolation

There is one `sftc_mem_owner` per bank, inside each MBIST-ready wrapper or shim.

```
NORMAL --acq_req--> QUIESCE_REQUEST --quiesce_ack--> WAIT_FOR_IDLE --(no functional txn in flight)--> TEST_ACQUIRE
  ^                    | !acq_req -> NORMAL              | !acq_req -> NORMAL                            |
  |                    | timeout -> FAULT                | timeout -> FAULT                              v
TEST_RELEASE <--(no test txn in flight)-- TEST_COMPLETE <--(!acq_req && MBIST idle)-- TEST_ACTIVE <--(1 cycle)
  (re-init check: dirty -> REINIT_REQUIRED)                 timeout -> FAULT
FAULT --(CLEAR && !acq_req)--> NORMAL
```

## Sequence before a destructive test

1. **Request ownership.** `acq_req` is raised by the TestCore top when *all* of these hold: the mode is MBIST, the hardware permits destructive test, the software interlock is unlocked, the bank is selected, the MBIST exit sequence is not in progress, and the bank is not protected unless the CPU is halted.
2. **Stop new transactions.** `quiesce_req` tells the masters (CPU, DMA, accelerators) to stop issuing. The port stays open during QUIESCE_REQUEST so that a request already presented can finish its handshake (see D7 in the audit). From the acknowledge onward, the wrapper blocks every functional request.
3. **Drain.** The wrapper waits until no functional transaction is in flight: no outstanding read and no undelivered response. If a master stops accepting responses, the drain does not complete and the owner reaches FAULT on timeout.
4. **Ensure accesses are inactive.** Any functional request presented after the acknowledge is blocked and reported as `EF_INTRUSION`. Verified with a rogue master.
5. **Transfer control.** In TEST_ACQUIRE the port mux switches. Test grants (`test_en`) start one cycle later, in TEST_ACTIVE.
6. **Run.**
7. **Record** results in the registers.
8. **Release.** This happens only when the request has dropped, the engine is idle, and no test transaction is in flight.
9. **Re-initialise.** The scrub element writes all-zero to the bank. Releasing a bank that was written by the test but not scrubbed raises `EF_REINIT_REQ`, and software must initialise it.

## Formal and simulated evidence

* **Formal** (`fv_sramlib_wrap`, using the real `sram_sp`, PDR):
  * functional and test acceptance are mutually exclusive;
  * the port switches only with nothing in flight;
  * there are no unsolicited functional or test responses;
  * test grants happen only when owned;
  * destructive writes happen only in TEST_ACTIVE.
* **System simulation** (`tb_testcore_sys`, `tb_sfv_integration`):
  * random CPU/DMA traffic with response back-pressure before, during and after the test, scoreboard-checked;
  * after release, every functional read of a scrubbed bank must return 0;
  * rogue, non-acknowledging and protected cases;
  * abort, permission loss and reset during the test.

## Boot-time and in-field rules

* **Boot-time test (SilicaFlux-V).** The boot ROM executes from ROM, which is not tested, and keeps no stack in SRAM before the test; this is the existing SFV `start.S` behaviour. It can drive TestCore through the system-bus port (`test_boot_time_test_over_system_bus`) and observe the TEST_PASS/FAIL pins.
* **Protecting the CPU's own memory.** A bank holding the running CPU's stack or code must be marked in `PROTECT`. PROTECT is write-1-to-set and only reset clears it. Such a bank is acquired only while `cpu_halted` = 1, which comes from the SoC (for example the DBGCTRL CPU hold).
* **In-field test.** Only banks that are genuinely offline may be tested. TestCore enforces the protocol, but deciding which banks are offline is the SoC software's responsibility.
* **Non-destructive test** (save/restore) is **not implemented**.
