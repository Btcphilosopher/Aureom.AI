# Fault injection and coverage analysis

## 1. Two independent fault models

| Side | File | Used for |
|---|---|---|
| SystemVerilog (simulation only) | `tb/testcore/models/sftc_fault_mem.sv` | the memory the RTL actually tests |
| Python (golden) | `python/testcore/fault_models.py` | predicting detection, first-fail record and final memory content |

The two were written independently from the same definitions. For every injected fault the regression requires them to agree on:

* result;
* first-fail bank, element, op, address, expected and observed data;
* the failure FIFO;
* the saturating fail count;
* the final memory content.

They also share one definition, not one code base, for the deterministic power-up content: LCG seed per case.

**Fault kinds:**

| Class | Kinds |
|---|---|
| Cell | SA0, SA1, TF↑, TF↓ |
| Address decoder | alias, multi-access, no-access |
| Read path | read inversion |
| Column / sense | data-line stuck |
| Coupling | inversion, idempotent and state coupling (inter-word above and below the aggressor, and intra-word) |
| Other | intermittent read (every k-th read), memory error flag |
| Protocol | extra latency (legal, must PASS), dropped response (→ ERROR), withdrawn grant (→ ERROR), duplicated response (→ ERROR, never PASS) |

## 2. Population and results

* **Population:** enumerated per kind on the `w8d16_l1` configuration (8 bit × 16 words). Every cell for the cell faults, every ordered address pair for the decoder faults, and a deterministic sample of aggressor/victim pairs for the coupling faults (seed 20261106). Each fault is run under all six algorithms.
* **Results:** `generated/fault_coverage.md` (rendered from `reports/testcore/mbist/summary.json`).
* **Definition:** coverage = detected / injected over that population only.

## 3. Separation of coverage types (never collapsed into one number)

| Coverage type | Where | What it means |
|---|---|---|
| MEMORY FAULT-INJECTION COVERAGE | `generated/fault_coverage.md` | synthetic faults in a behavioural model, single-fault assumption |
| MBIST ALGORITHM COVERAGE (theory) | `mbist.md` | textbook properties under the unlinked, bit-oriented fault model |
| LOGIC ATPG COVERAGE | `generated/dft_results.md` | in-house stuck-at experiment on the TestCore netlist, full-scan model, memories as black boxes |
| FUNCTIONAL SIMULATION COVERAGE | `verification_report.md` | TAP state/arc coverage, mode-policy combinations, scenario lists; **no code coverage was collected** |
| POST-SILICON TEST RESULTS | none | **no silicon exists** |

**Limit:** none of these numbers is a claim about production defect detection.
