# Common memory test interface (TestCore test bus)

## Signals (per bank, as seen by a memory wrapper)

| Signal | Dir (wrapper) | Meaning |
|---|---|---|
| `t_req` | in | request valid (selected bank only) |
| `t_gnt` | out | request accepted in this cycle (`t_req && t_gnt`) |
| `t_we` | in | 1 = write, 0 = read |
| `t_addr[AW-1:0]` | in | word address, `0 .. depth-1` (never out of range) |
| `t_wdata[W-1:0]` | in | write data, full word (all lanes) |
| `t_rvalid` | out | response valid: one per accepted read, plus one per accepted write if `WRITE_RESP` = 1 |
| `t_rdata[W-1:0]` | out | read data (meaningful only with `t_rvalid`) |
| `t_rerr` | out | the memory reports an error with this response (ECC uncorrectable, bus error) |

Bank attributes are compile-time parameters of `silicaflux_mbist`:

* `BANK_WIDTHS`: 8 bits per bank, 1..128.
* `BANK_DEPTHS`: 24 bits per bank, any value ≥ 2, not limited to powers of two.
* `BANK_FLAGS`: bit 0 = `WRITE_RESP`.

`ADDRESS_WIDTH = clog2(MAX_DEPTH)`.

Control and status come from the register block or the mode controller:

* control: `test_enable`, `start`, `abort`, `clear`, algorithm, background, stop-on-fail, scrub, bank mask, bank owned;
* status: busy, done, pass, fail, aborted, error, `cur_bank`, `cur_addr`, cycles, first-fail record, error FIFO.

## Timing rules

1. **Request.** Once `t_req` is high, `t_we`, `t_addr`, `t_wdata` and the bank index are held stable until `t_gnt`. This is formally proven (F1). The only exception is the timeout → ERROR state.
2. **One outstanding transaction.** No new request is issued until the current one has completed (proven, F5):
   * a posted write completes at acceptance;
   * a read, or a write with `WRITE_RESP`, completes when its `t_rvalid` arrives.
3. **Response latency.** Any latency ≥ 1 cycle is allowed and need not be constant. Responses arrive in order. A latency-0 (combinational) response is a protocol violation and is reported as spurious.
4. **Comparison** happens only on the awaited response (proven, F4). Expected data comes from the live pattern decode, which is held while waiting. There is no path from write data to the comparator.
5. **Unsolicited response** (any `t_rvalid` while not waiting, or from a non-selected bank) → `EF_SPURIOUS`, and the run result is ERROR (never PASS, proven).
6. **Timeouts** (`TIMEOUT` cycles waiting for grant or response) → ERROR state. No further requests are issued until CLEAR.
7. **New-request qualification.** A new request is presented only while `test_enable` and the bank's ownership are both present in that cycle (proven, F2 / embedded). If either is lost before acceptance, the engine stops without touching the memory.

## Mapping to existing memory ports

| Memory | Port used | Adapter | Notes |
|---|---|---|---|
| SRAM Wrapper Library `sram_sp` / `sram_1r1w` / `sfb_sram_slave` | raw `tst_*` (all lanes written, `tst_rdata` valid exactly `READ_LATENCY` cycles after a read) | `sftc_tst_port_adapter` | 1R1W: write port for writes, read port for reads, never both in one cycle |
| SilicaFlux-V `sfv_sram_slave` | collar `bist_*` (latency 1) | `sftc_tst_port_adapter` inside `sftc_sfv_bank_shim` | no change to the SFV RTL |
| DataFabric SFB2 slave (fabric path) | SFB2 `req_*` / `rsp_*` | `sftc_sfb2_master_adapter` | `WRITE_RESP` = 1 (SFB2 acknowledges writes) |
| Hard macro with a built-in BIST mux (IHP `A_BIST_*`) | not used: TestCore uses the wrapper's port mux | — | the IHP pins stay tied off as in the existing designs |

No port is ever added to a foundry macro. All test accesses use the existing single physical port, or the existing read and write ports.
