# TimingFlow / FloorplanLab integration, synthesis and area

## 1. Synthesis comparison

* Tools: Yosys 0.70 and OpenSTA (bundled with OpenROAD 26Q3).
* Library: sky130hd, tt corner, 25 °C, 1.8 V.
* Script: `asic/synth/run_synth.py`. Results: `generated/synthesis.md`.
* All variants use identical RTL options, library, SDC and macro proxy.

**Macro proxy:** every SRAM macro is replaced by a register proxy of its pins (83 flops per bank). It is identical in every variant, so the area deltas are unaffected by it. Absolute timing to and from the macro is **not** modelled.

**Normal-mode impact:**

* Functional read latency is unchanged at 1 cycle. Structurally, the shim adds only gating on `req`/`gnt` and no register.
* The functional-port worst slack is compared between A0 and D in `generated/synthesis.md`.

**Area context** (SilicaFlux-V project's own reports, as reported by the project, not re-run):

* SFV sky130hd standard cells: 0.3978 mm².
* SRAM macros: about 26.0 mm².
* Die: 34.15 mm².

Compare the TestCore delta in `generated/synthesis.md` against these figures. For the IHP SG13G2 build (5.39 mm² placed), the TestCore logic is not characterised in IHP; that is a pending step.

## 2. TimingFlow (Project 06) integration

TimingFlow v2.0 has only a functional SDC: it sets `test_mode_i` and `scan_en_i` to 0 with case analysis. TestCore adds mode SDCs in its convention (OpenSTA, `set_case_analysis`, asynchronous clock groups):

* `constraints/testcore_normal.sdc`
* `constraints/testcore_mbist.sdc`
* `constraints/testcore_jtag.sdc`
* `constraints/testcore_scan_shift.sdc`
* `constraints/testcore_scan_capture.sdc`

All exceptions are listed with a justification in `testcore_common.tcl`. There are no blanket test false paths: the only false paths are on asynchronous reset assertion.

`asic/sta/run_modes.py` runs all modes on the scan-inserted netlist, plus NORMAL on the pre-scan netlist (the before/after comparison). Results are in `generated/dft_results.md`.

**Normal and test closure are kept separate:** each mode has its own SDC and report.

**Not done:** post-route parasitics, multi-corner analysis, CTS/hold fixing, IHP and GF180 corners.

## 3. FloorplanLab (Project 05) integration

* FloorplanLab's flow targets the full `sfv_soc_df` SoC on IHP SG13G2 with macros, using ORFS installed under `/opt/eda`, which is not available here.
* TestCore ran the equivalent OpenROAD floorplan and placement steps on its own logic block (variant E, standard cells only, sky130hd, 45 % utilisation), before and after scan insertion. Script: `asic/floorplan/place_compare.tcl`.
* The placed area and HPWL deltas quantify the cost of scan cells plus unordered scan stitching.

**Test-related physical structures to place in a FloorplanLab run:**

* MBIST engine, registers, and TAP/bridge near the JTAG pins;
* one shim per bank, adjacent to its macro: the owner, mux and adapter belong next to the macro pins;
* the TCK clock tree, which is small (172 flops);
* scan-enable fanout: buffer tree from the `scan_enable` port.

**Pending:** a FloorplanLab run with TestCore inserted into `sfv_soc_df` (requires ORFS and IHP collateral); placement-aware scan reordering; test-current and IR-drop analysis.

## 4. First-silicon pin budget

| Pin | Required | Note |
|---|---|---|
| TCK, TMS, TDI, TDO | yes | TDO tri-state (`tdo_oe`) |
| TRST* | recommended | otherwise a POR-only TAP reset (TMS=1 × 5 still works) |
| RST_N, CLK_IN | yes (already functional pins) | |
| TEST_MODE / `scan_mode_pin` | yes | must also be gated by OTP lifecycle (`hw_test_en`) |
| SCAN_EN | yes for scan | can be muxed on GPIO in TEST_MODE |
| scan in/out | 8 + 8 for the TestCore block alone | SoC-level chain count is a tester-channel decision; mux on GPIO[7:0] in TEST_MODE (SFV plan) or add compression |
| TEST_PASS / TEST_FAIL / TEST_DONE | optional, recommended for wafer probe | `test_pass_o`, `test_fail_o`, `test_done_o` |
| hw_test_en / hw_dbg_en | internal (OTP / straps) | not pins in production |
