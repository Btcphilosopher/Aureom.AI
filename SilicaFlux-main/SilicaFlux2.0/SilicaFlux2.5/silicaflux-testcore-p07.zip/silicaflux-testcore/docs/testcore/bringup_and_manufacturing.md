# Silicon bring-up plan, test clocks / power, manufacturing data, repair

## 1. Post-fabrication diagnostic order

`python -m testcore bringup` automates the logically applicable steps. Electrical and lab steps are recorded as NOT RUN, and the command refuses to automate supplies.

| # | Stage | Automated? | Procedure / equipment interface |
|---|---|---|---|
| 1 | Package / power visual and electrical inspection | manual | microscope; continuity of every supply ball to the expected net (DMM); no automation |
| 2 | Supply current and short checks | manual, qualified lab procedure | current-limited bench supply. Limits come from the package datasheet and are not invented here. Ramp each rail separately with a compliance limit, and abort on over-current. **Not automated**: interlocks and limits must be set by a qualified engineer. |
| 3 | Clock and reset verification | manual | oscilloscope on CLK_IN, RST_N and TCK; check that POR releases |
| 4 | JTAG TAP identification | **yes** | IDCODE `0x15F07001` (placeholder manufacturer), BYPASS check, TC_STATUS signature 7, sysclk alive |
| 5 | Test-mode status | **yes** | MODE_STATUS = NORMAL; hw_test_en / hw_dbg_en as strapped |
| 6 | SRAM MBIST | **yes** | March C− on all banks; first-fail and FIFO records; TEST_PASS / TEST_FAIL pins |
| 7–13 | Boot ROM, CPU boot, UART, SRAM functional R/W, DMA, vector and tensor engines | NOT RUN in this tool | need the integrated SoC firmware (SilicaFlux-V `start.S` POST mode 2 exists), plus a UART capture on the host |
| 14 | Performance / timing experiments | NOT RUN | shmoo across voltage and frequency with a programmable supply and clock source, in a temperature chamber |

## 2. Test clocks

| Clock | Source | Use | Profiles (constraints in `constraints/`) |
|---|---|---|---|
| functional `clk` | board / PLL bypass | MBIST, registers, functional | 50 MHz (SFV default; MBIST mode SDC) |
| TCK | JTAG adapter | TAP, bridge | 10 MHz nominal (normal / MBIST SDC), 20 MHz max (JTAG SDC) |
| scan shift | ATE on the `clk` and `tck` pins | chain shift | 25 MHz (scan_shift SDC) |
| scan capture | ATE | stuck-at capture, one clock per pattern | 10 MHz (scan_capture SDC) |
| watchdog | none in SilicaFlux-V | — | — |

**Power and frequency caveats:**

* MBIST tests the banks serially, so only one bank is active at a time and peak test current is bounded.
* Scan shift toggles every flop: 1 227 flops in TestCore, about 3 800 in the SFV SoC. Choose the shift frequency from a power analysis on the real netlist and package. That analysis was not done.
* Passing at-speed functional simulation does **not** validate full-speed MBIST or at-speed scan in silicon. That needs memory-macro timing (the OpenRAM sky130 macro misses 50 MHz per the SFV report), an OCC, and silicon shmoo.

## 3. Manufacturing test records (`python/testcore/report.py`)

**Fields:**

* design version, device revision, TestCore version and RTL revision, firmware version;
* configuration, UTC timestamp, equipment ID;
* wafer ID, die X/Y, package serial;
* temperature, voltage, test clock and TCK frequency;
* MBIST per algorithm, scan/ATPG;
* failure count and locations;
* status and bin.

**Statuses:** PASS, FAIL, NOT RUN, BLOCKED, INVALID, INCONCLUSIVE.

**Rules:**

* Physical fields stay `null` unless they were measured.
* Simulation and FPGA evidence is never binned (`NO-BIN`). Demonstration data must carry `evidence_class = DEMONSTRATION`.
* Bins: BIN1 means all executed tests passed; BIN5 MBIST failure; BIN7 test-access failure; BIN9 other; BIN0 incomplete.

**Example records** are in `reports/testcore/examples/`. They are **SIMULATION** records produced by real RTL runs; there are no fictional wafers.

## 4. Memory repair / BISR

* None of the SilicaFlux macros has spare rows or columns:
  * sky130 OpenRAM `sky130_sram_1rw1r_128x256_8`, `sky130_sram_2kbyte_1rw1r_32x512_8`
  * IHP `RM_IHPSG13_1P_*`
  * GF180 `sram512x8m8wm1`
* No repair fuse or OTP path exists. **No repair capability is claimed.**
* **Implemented:** failure identification, first-fail record, FIFO, and per-bank fail mask.
* **Repair feasibility:** the FIFO plus the saturating count give enough information for a bitmap. The host can export failing addresses (`failures.csv`).
* **Future:** a BISR demonstrator with spare rows modelled on a GENERIC-backend wrapper. It must stay separate from production macros until a macro with redundancy is selected.
