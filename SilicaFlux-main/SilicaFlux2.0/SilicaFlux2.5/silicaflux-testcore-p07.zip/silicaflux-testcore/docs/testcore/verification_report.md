# Verification report — evidence by class

The recorded run is in `reports/testcore/REGRESSION.md` and `regression.json`. That run lists the exact command, tool version, duration and log of every step. Failing logs are preserved in `reports/testcore/logs/` and in each step's own report directory.

| Evidence class | What was done | Result location |
|---|---|---|
| FUNCTIONAL SIMULATION | MBIST engine: 10 configurations (widths 8–128; depths 8–512, including 11, 13, 17, 33, 37; latency 1, 2, 3, random 1–5; 60 % grant; write responses; register slices; 1–4 banks; log depth 0 and 4). Fault-free runs of all algorithms and both backgrounds. Abort, reset, test-enable drop, ownership loss, illegal starts, repeated runs. | `reports/testcore/mbist/summary.json` |
|  | Exact comparison against the independent golden model: result, transaction trace, compare events, first-fail record, FIFO, final memory content, and cycle count where timing is deterministic | per-case `compare.json` |
|  | JTAG TAP + CDC bridge: 51 776 checks; 16/16 states; 32/32 arcs; 32 opcodes; 4 clock ratios; stopped system clock; system reset during a request | `logs/jtag_tap_and_cdc_sim.log` |
|  | System: TestCore + 4 SRAM-library banks + functional masters, driven by the Python host. 24 pytest system tests, including the exhaustive 256-case mode policy, rogue / no-ack / protected banks, boot-time system-bus path, abort, permission loss, scan pins, reset | `logs/system_sim_host_library.log` |
|  | Real SilicaFlux-V `sfv_sram_slave` (4 × 8192 × 32) with SFV fault hook; real DataFabric `sfb_sram_slave` path | `logs/sfv_integration_sim.log`, `logs/datafabric_path_sim.log` |
| FAULT-INJECTION SIMULATION | Enumerated synthetic population × 6 algorithms; cell, address, read-path, data-line, coupling, intermittent, error-flag and protocol faults | `generated/fault_coverage.md` |
| FORMAL VERIFICATION | 6 harnesses, unbounded abc PDR proofs, plus 14 reach points (all reached, so no vacuity) | `generated/formal_results.md` |
| LOGIC SYNTHESIS + STA | 7 variants on sky130hd: area, flops, muxes, latches (0), slack, power at default activity | `generated/synthesis.md` |
| DFT SCAN INSERTION | OpenROAD 26Q3: 8 chains, all flops replaced, gate-level continuity PASS | `generated/dft_results.md` |
| ATPG | in-house research experiment, stuck-at, full scan, memories as black box; sample patterns replayed on the scan netlist | `generated/dft_results.md`, `reports/testcore/atpg/` |
| STATIC TIMING PER MODE | normal (pre/post scan), MBIST, JTAG, scan shift, scan capture | `generated/dft_results.md` |
| PLACEMENT | OpenROAD floorplan + placement of the TestCore block, pre and post scan | `generated/dft_results.md` |
| HARDWARE-ADAPTER PATH | OpenOCD 0.12 JTAG stack against the RTL via `remote_bitbang`: scan, MBIST, SVF playback (pass, and fault correctly rejected) | `reports/testcore/openocd/` |
| FPGA VALIDATION | **not done** | — |
| WAFER PROBE | **not done** | — |
| PACKAGED SILICON | **not done** | — |

## Defects found by verification and fixed

There are 11, listed in `repository_audit.md` §6. Each was found by a test (regression, formal proof, lint, system test or gate-level DFT check) and the same test was re-run after the fix.

## What the verification does not show

* No code or functional coverage collection (Verilator / Icarus coverage was not used).
* No gate-level simulation with SDF timing.
* No equivalence check between RTL and netlist, or before and after scan.
* No CDC-tool or RDC-tool sign-off.
* Formal proofs cover small parameterisations only, as stated in each harness.
* No liveness proofs. Completion is shown by simulation only.
