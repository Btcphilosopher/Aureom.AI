# SRAM Wrapper Library, SilicaFlux-V, MCU-I and DataFabric integration

## 1. SRAM Wrapper Library (Project 01)

The library is vendored **unmodified** in `third_party/silicaflux-sramlib/`. Its SHA-256 values are in `SHA256SUMS.vendored`.

| Wrapper | Library module | Normal path | Test path | Verified by |
|---|---|---|---|---|
| `sftc_sramlib_sp_wrap` | `sram_sp` (1RW, valid/ready, `WRITE_ACK`, any `READ_LATENCY`) | library request/response, gated by the owner; byte masks preserved | library `tst_*`, all lanes written | `tb_testcore_sys` banks 0 (L=1), 1 (L=2), 2 (36-bit); formal `fv_sramlib_wrap` |
| `sftc_sramlib_1r1w_wrap` | `sram_1r1w` (posted write channel + read channel) | library channels, gated | test write → write port, test read → read port, never in the same cycle | `tb_testcore_sys` bank 3 |

**Compatibility checklist** (from §8 of the brief):

* single-port ✓
* one-read/one-write ✓
* multiple banks ✓ (4 banks with different widths, depths and latencies)
* configurable latency ✓ (1, 2, and 1–5 random in the engine tests)
* byte write enables ✓ (functional masters issue random byte masks before, during and after the test; scoreboard clean; MBIST writes full words)
* shared interconnect access ✓ (DataFabric path, §3)

**Faults in library memories:** the library's own GENERIC-backend hook is used (`flt_kind`, `flt_addr`, `flt_bit`), set through the `F` command of the simulation transport.

## 2. SilicaFlux-V

`sftc_sfv_bank_shim` wraps the **unmodified** release-1 `sfv_sram_slave` (`third_party/silicaflux-v/`). It sits between the crossbar slave port and the existing collar:

* crossbar `req/gnt` are gated by the owner;
* `bist_en` = owner `sel_test`;
* test operations go through the latency-1 adapter.

`tb_sfv_integration` runs:

* 4 real 8192 × 32 banks with SFB-style traffic;
* a boot-ROM-like sequencer on the system-bus port;
* a fault injected through SFV's own `fi_*` hook in `sfv_sram_sp`.

**SoC-level work still needed:** replacing `sfv_mbist` in `sfv_soc` (and routing the tile TSPM collar) with TestCore. This is a top-level edit, not done here because the original repository must not be modified. The integration recipe:

1. Replace `u_mbist` with `sftc_testcore_top` (`BANK_COUNT` = 8: 4 main + 4 TSPM).
2. Wrap each `sfv_sram_slave` with `sftc_sfv_bank_shim`.
3. Expose the tile `bist_*` of the 4 TSPM banks through 4 shim-equivalent adapters inside `sfv_tile`.
4. Drive `quiesce_ack` from the crossbar idle / CPU-hold status.
5. Share TCK/TMS/TDI/TDO through a second TAP on the chain, or merge TestCore's instructions into `sfv_jtag_tap`'s IR space.

## 3. DataFabric (Project 03)

`sftc_sfb2_master_adapter` lets the engine test a memory **through the fabric**. `tb_datafabric` uses the real DataFabric `sfb_reg_slice` and `sfb_sram_slave`, which wraps `sram_sp` with latency 2.

The fabric path is not isolated by an owner. The SoC must halt or idle the other fabric masters first.

`sfb_sram_slave` also passes the library's `tst_*` port through, so the direct test path (`sftc_tst_port_adapter`) works for it unchanged.

## 4. ECC and parity

* **SilicaFlux-V:** no ECC or parity on any memory (ISS-014). Nothing was invented.
* **MCU-I industrial:** byte parity, 36-bit words with 4 parity bits (`mcu_sram_bank`, `PARITY=1`, `chk_en`, `inject`). The existing `sfv_mbist` there ignores the parity bits. TestCore tests the **raw 36-bit storage** through `tst_*`, which bypasses the parity checker. `tb_testcore_sys` bank 2 detects a stuck-at on bit 35, a parity cell.
* **Parity logic:** to test the checker and injection logic, as opposed to the storage, MCU-I's `inject` and `chk_en` controls should be driven functionally: write with injection, read, expect the parity error, observe the MCU error status. This is a firmware test plan item. It is not implemented as TestCore hardware because TestCore is not inside `mcu_sram_bank`.
* **ECC:** no memory has ECC, so there are no SEC/DED tests. If ECC is added, test the raw array through the raw port, separately from the encode/decode logic. Testing only the corrected output hides storage faults.
