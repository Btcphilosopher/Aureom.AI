# SilicaFlux TestCore r2 (Project 07) — architecture

## 1. Choosing a controller topology

| Option | Area | Routing | Test time | Clocking | Verdict for SilicaFlux-V |
|---|---|---|---|---|---|
| **A. Shared controller + bank selector** | one engine, one comparator, one fail log | one broadcast test bus plus per-bank `t_req` strobes | banks tested one after another | single memory clock | **chosen** |
| B. Distributed controllers (one per memory group) | N × engine | short local buses | groups run in parallel | per group | only for physically distant groups or different clock domains |
| C. One controller per macro | maximum | minimal | fully parallel | per macro | rejected for first silicon |

**Why A for SilicaFlux-V:**

* All 8 SRAM banks are on the same `clk`.
* The 4 main banks are electrically identical (32 × 8192), and so are the 4 TSPM banks (32 × 1024).
* Serial testing bounds peak test current.
* The engine is fully handshake-based, so physically distant banks can be reached through optional register slices (`sftc_mbist_bank_mux` `PIPE_REQ`/`PIPE_RSP`) without changing behaviour. This is verified in the `pipe2` configuration.
* Measured cost: the whole TestCore with 4 bank shims and JTAG adds 42 406 µm² (sky130hd), or 32 590 µm² with first-silicon options. The 4 shims together cost about 4 × 1 100 µm². See `generated/synthesis.md`.

**When to switch to option B:**

* banks on different clocks;
* MCU-I industrial with parallel parity-column test;
* the future multi-engine processor, where test time with serial testing exceeds the budget. For 4 × 32 KiB, serial March C- is 524 k cycles = 10.5 ms at 50 MHz.

## 2. Block diagram

```
                 TCK domain                         |                 system clock domain (clk = memory clock)
  TCK TMS TDI TRST*                                 |
   │                                                |   system-bus register port (boot ROM / CPU)
   ▼                                                |          │
 sftc_jtag_tap ──IR/state──► sftc_jtag_reg_bridge ══╪══► reg-bus arbiter (JTAG priority) ──► sftc_regs
   │ IDCODE/BYPASS            TC_REG 46b / TC_STATUS |  toggle handshake (formally proven)       │   │
   ▼ TDO                                            |                                          │   └► MODE_CTRL/UNLOCK
                                                    |      hw_dbg_en, hw_test_en (strap/OTP) ──┼─► silicaflux_test_mode_controller
                                                    |      scan_mode/scan_en pins ─────────────┘        │ mbist_enable / abort
                                                    |                                                   ▼
                                                    |                                         silicaflux_mbist
                                                    |       (addr gen, pattern gen, comparator, fail log, timeouts)
                                                    |                                                   │ one transaction at a time
                                                    |                                        sftc_mbist_bank_mux
                                                    |                 ┌─────────────────┬──────────┴───────┬──────────────────┐
                                                    |          MBIST-ready wrapper  MBIST-ready wrapper  SFV bank shim   SFB2 adapter
                                                    |          (sram_sp + owner)    (sram_1r1w + owner)  (sfv_sram_slave (DataFabric
                                                    |                │                    │              + owner)         fabric path)
                                                    |          CPU / DMA ports       CPU / DMA ports     crossbar port
```

## 3. Modules

| Module | File | Role |
|---|---|---|
| `sftc_consts.svh` / `sftc_pkg` | `rtl/testcore/` | the single authoritative encodings (algorithms, modes, opcodes, register map). The Python host parses this file. |
| `silicaflux_mbist` | `silicaflux_mbist.sv` | handshake MBIST engine, 6 algorithms, multi-bank, scrub, timeouts, protocol checks |
| `sftc_mbist_addr_gen` / `_pattern` / `_cmp` / `_fail_log` | | address generator, data patterns, comparator, failure logger |
| `sftc_mbist_bank_mux` | | bank selector with optional register slices |
| `sftc_mem_owner` | | per-bank ownership / isolation controller |
| `sftc_tst_port_adapter` | | handshake ↔ raw fixed-latency test port (SRAM library `tst_*`, SFV `bist_*`) |
| `sftc_sramlib_sp_wrap`, `sftc_sramlib_1r1w_wrap` | | MBIST-ready SRAM-library wrappers |
| `sftc_sfv_bank_shim` | | SilicaFlux-V bank integration (unmodified `sfv_sram_slave`) |
| `sftc_sfb2_master_adapter` | | DataFabric SFB2 fabric-path test |
| `silicaflux_test_mode_controller` | | mode policy, permissions, scan override |
| `sftc_regs` | | diagnostic / control registers |
| `sftc_jtag_tap`, `sftc_jtag_reg_bridge`, `sftc_sync` | | TAP, TCK→clk bridge, synchroniser |
| `sftc_dft_ctrl` | | combinational scan controls (reset bypass, ICG TE, memory inhibit, clock mux placeholder) |
| `sftc_testcore_top` | | integration top |

## 4. Clocks and resets

* `tck` is fully asynchronous to `clk`.
* Every TCK→clk crossing goes through the toggle-handshake bridge. Multibit payloads are held stable by protocol, and single bits go through `sftc_sync`.
* `clk` must be the clock of the memories under test and must run for MBIST and register access. The CPU core clock may be gated.
* Resets:
  * `trst_n` = TRST* AND POR;
  * `rst_n` = TestCore system reset, with synchronised deassertion by the SoC (`sfv_rst_sync`).
* In scan mode every asynchronous reset is pin-controlled (`sftc_dft_ctrl`).
