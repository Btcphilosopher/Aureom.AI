#!/usr/bin/env python3
"""OpenOCD remote_bitbang server backed by the TestCore RTL simulation.

    python3 tools/rbb_sim_bridge.py --port 9824 [--traffic]

OpenOCD (adapter driver remote_bitbang) connects to this server; every TCK
rising edge it requests is executed on the RTL (tb_testcore_sys) through
SimTransport, and 'R' (read TDO) returns the RTL's TDO.  This lets the real
OpenOCD JTAG stack, the OpenOcdTransport adapter and SVF playback be
exercised against the RTL.  It is NOT a substitute for a physical adapter.
Protocol: '0'..'7' write (bit2 TCK, bit1 TMS, bit0 TDI), 'R' read, 'r'..'u'
reset lines, 'B'/'b' blink, 'Q' quit.
"""
import argparse
import socket
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))
from testcore.transports.sim import SimTransport  # noqa: E402


def serve(port: int, traffic: bool, faults=()):
    t = SimTransport()
    for k in range(4):
        t.set_pin("traffic", int(traffic), k)
    for f in faults:
        b, kind, a, bit = (int(x) for x in f.split(":"))
        t.inject_fault(b, kind, a, bit)
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", port))
    srv.listen(1)
    print(f"rbb bridge listening on {port}", flush=True)
    conn, _ = srv.accept()
    tck = tms = tdi = 0
    pend_tms, pend_tdi = [], []

    def flush():
        if pend_tms:
            t.shift(pend_tms, pend_tdi)
            pend_tms.clear(); pend_tdi.clear()
    n_edges = 0
    try:
        while True:
            data = conn.recv(65536)
            if not data:
                break
            out = bytearray()
            for ch in data:
                c = chr(ch)
                if "0" <= c <= "7":
                    v = ord(c) - 48
                    ntck, tms, tdi = (v >> 2) & 1, (v >> 1) & 1, v & 1
                    if ntck and not tck:                 # rising edge: one TCK cycle on the RTL
                        pend_tms.append(tms); pend_tdi.append(tdi); n_edges += 1
                    tck = ntck
                elif c == "R":
                    flush()
                    out += b"1" if t.get("tdo") else b"0"
                elif c in "rstu":
                    flush()
                    t.set_pin("trst", 1 if c in "tu" else 0)
                elif c == "Q":
                    flush()
                    raise StopIteration
            flush()
            if out:
                conn.sendall(bytes(out))
    except StopIteration:
        pass
    finally:
        print(f"rbb bridge: {n_edges} TCK edges executed on RTL", flush=True)
        t.close()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=9824)
    ap.add_argument("--traffic", action="store_true")
    ap.add_argument("--fault", action="append", default=[], help="bank:kind:addr:bit (SRAM-library fault kinds)")
    a = ap.parse_args()
    serve(a.port, a.traffic, a.fault)
