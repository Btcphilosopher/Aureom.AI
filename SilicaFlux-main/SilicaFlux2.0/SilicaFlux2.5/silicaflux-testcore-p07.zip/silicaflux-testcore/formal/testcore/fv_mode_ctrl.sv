`include "sftc_defs.svh"
// =============================================================================
// Formal harness: silicaflux_test_mode_controller with every input free.
// =============================================================================
`default_nettype none
module fv_mode_ctrl (
  input wire logic       clk,
  input wire logic       hw_dbg_en, hw_test_en, unlocked, scan_mode_pin, scan_en_pin,
  input wire logic       req_valid,
  input wire logic [2:0] req_mode,
  input wire logic       mbist_busy, banks_released
);
  logic rst_n = 1'b0;
  always @(posedge clk) rst_n <= 1'b1;
  logic [2:0] mode, pending;
  logic mode_busy, mbist_enable, mbist_abort, jtag_mode, diag_mode, scan_mode, scan_en, ev_illegal, ev_denied;
  silicaflux_test_mode_controller dut (
    .clk, .rst_n, .hw_dbg_en, .hw_test_en, .unlocked, .scan_mode_pin, .scan_en_pin, .req_valid,
    .req_mode, .mbist_busy, .banks_released, .mode, .mode_busy, .pending, .mbist_enable, .mbist_abort,
    .jtag_mode, .diag_mode, .scan_mode, .scan_en, .ev_illegal, .ev_denied
  );
  logic [2:0] p_mode; logic p_v, p_scan;
  always @(posedge clk) begin p_mode <= mode; p_v <= rst_n; p_scan <= scan_mode; end
  always @(posedge clk) begin
    if (rst_n) begin
      assert (!mbist_enable || (hw_test_en && unlocked));               // M1 destructive mode needs HW permission + unlock
      assert (!(jtag_mode || diag_mode) || hw_dbg_en);                    // M2 debug modes need HW debug permission
      assert (!scan_en || (scan_mode && scan_en_pin && hw_test_en));      // M3 scan enable only from pins
      assert (!scan_mode || (scan_mode_pin && hw_test_en));
      assert ((32'(mbist_enable) + 32'(jtag_mode) + 32'(diag_mode) + 32'(scan_mode)) <= 1);  // M4 one mode
      if (p_v && !p_scan && !scan_mode && mode == 3'd2 && p_mode != 3'd2)
        assert ($past(req_valid) && $past(req_mode) == 3'd2 && $past(hw_test_en) && $past(unlocked)); // M5 MBIST entry only on permitted request
      if (p_v && !p_scan && !scan_mode && mode != p_mode && mode != 3'd0)
        assert ($past(req_valid) || $past(mode_busy));                    // M6 no spontaneous mode change except to NORMAL
      if (!$past(rst_n)) assert (mode == 3'd0 || scan_mode);              // M7 reset -> NORMAL
    end
  end
  always @(posedge clk) if (rst_n) begin
    `SFTC_REACH(0, mbist_enable)
    `SFTC_REACH(1, mode_busy && !mbist_busy)
    `SFTC_REACH(2, ev_denied)
    `SFTC_REACH(3, ev_illegal)
  end
endmodule
`default_nettype wire
