`include "sftc_defs.svh"
// =============================================================================
// Formal harness: sftc_jtag_tap (posedge + negedge TCK flops; multiclock).
// =============================================================================
`default_nettype none
module fv_tap (input wire logic tck, input wire logic tms, tdi, tdo_reg_i, tdo_status_i);
  logic trst_n = 1'b0;
  always @(posedge tck) trst_n <= 1'b1;
  logic tdo, tdo_oe, sel_reg, sel_status;
  logic [3:0] state; logic [4:0] ir;
  sftc_jtag_tap dut (.tck, .trst_n, .tms, .tdi, .tdo, .tdo_oe, .state_o(state), .ir_o(ir),
                     .sel_reg, .sel_status, .tdo_reg_i, .tdo_status_i);
  logic [2:0] ones;
  always @(posedge tck) begin
    if (!trst_n) ones <= 0; else ones <= tms ? ((ones == 3'd5) ? 3'd5 : ones + 1) : 3'd0;
  end
  always @(posedge tck) begin
    if (trst_n) begin
      if (ones == 3'd5) assert (state == 4'h0);                 // T1 5 x TMS=1 -> Test-Logic-Reset
      assert (!(sel_reg && sel_status));                        // T2 one data register selected
      if (state == 4'h0) assert (ir == 5'h02 || $past(state) != 4'h0);  // T3 TLR selects IDCODE (after the negedge)
    end
  end
  always @(posedge tck) if (trst_n) begin
    `SFTC_REACH(0, state == 4'h4 && sel_reg)
  end
endmodule
`default_nettype wire
