`include "sftc_defs.svh"
// =============================================================================
// Formal harness: sftc_sramlib_sp_wrap (real SRAM Wrapper Library sram_sp,
// GENERIC backend, 2 bits x 4 words, READ_LATENCY 2, WRITE_ACK 1) with
// unconstrained functional master, unconstrained MBIST-side inputs and
// unconstrained ownership requests.
// Properties: mutual exclusion of functional and test ownership; switching
// only with no functional transaction in flight; no functional response lost,
// duplicated or produced while under test; test responses only for test reads.
// =============================================================================
`default_nettype none
module fv_sramlib_wrap (
  input wire logic       clk,
  input wire logic       req_valid, req_we, rsp_ready,
  input wire logic [1:0] req_addr, req_wdata, req_wmask,
  input wire logic       req_id,
  input wire logic       t_req, t_we,
  input wire logic [1:0] t_addr, t_wdata,
  input wire logic       acq_req, fault_clear, quiesce_ack, mbist_busy, scrub_done
);
  logic rst_n = 1'b0;
  always @(posedge clk) rst_n <= 1'b1;
  logic req_ready, rsp_valid, rsp_err, rsp_we, rsp_id, t_gnt, t_rvalid, t_rerr;
  logic [1:0] rsp_rdata, t_rdata;
  logic quiesce_req, owned, dirty, ev_fault, ev_intrusion, ev_reinit_req, busy;
  logic [2:0] owner_state;

  sftc_sramlib_sp_wrap #(.DATA_WIDTH(2), .DEPTH(4), .MASK_WIDTH(2), .READ_LATENCY(2), .WRITE_ACK(1),
                         .ID_WIDTH(1), .OWN_TIMEOUT(5)) dut (
    .clk, .rst_n, .req_valid, .req_ready, .req_we, .req_addr, .req_wdata, .req_wmask, .req_id,
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_err, .rsp_we, .rsp_id,
    .t_req, .t_gnt, .t_we, .t_addr, .t_wdata, .t_rvalid, .t_rdata, .t_rerr,
    .acq_req, .fault_clear, .quiesce_ack, .quiesce_req, .mbist_busy, .scrub_done, .owned,
    .owner_state, .dirty, .ev_fault, .ev_intrusion, .ev_reinit_req, .busy
  );

  // master obeys the valid/ready rule (sram_sp contract): payload stable until accepted
  logic p_hold; logic p_we; logic [1:0] p_addr, p_wdata, p_wmask; logic p_id;
  always @(posedge clk) begin
    p_hold <= rst_n && req_valid && !req_ready;
    p_we <= req_we; p_addr <= req_addr; p_wdata <= req_wdata; p_wmask <= req_wmask; p_id <= req_id;
  end
  always @(*) if (p_hold) assume (req_valid && req_we == p_we && req_addr == p_addr &&
                                  req_wdata == p_wdata && req_wmask == p_wmask && req_id == p_id);

  // bookkeeping
  logic [3:0] f_out;    // accepted functional requests awaiting their response delivery
  logic [3:0] t_out;    // accepted test reads awaiting their response
  wire f_acc = req_valid && req_ready;
  wire f_del = rsp_valid && rsp_ready;
  wire t_acc = t_req && t_gnt && !t_we;
  always @(posedge clk) begin
    if (!rst_n) begin f_out <= 0; t_out <= 0; end
    else begin
      f_out <= f_out + f_acc - f_del;
      t_out <= t_out + t_acc - t_rvalid;
    end
  end
  wire sel_test = (owner_state == 3'd3) || (owner_state == 3'd4) || (owner_state == 3'd5);
  always @(posedge clk) begin
    if (rst_n) begin
      assert (!(f_acc && sel_test));                         // O1 mutual exclusion
      if (sel_test) assert (f_out == 0);                     // O2 switched only when drained
      assert (!(f_del && f_out == 0));                       // O3 no unsolicited functional response
      assert (!(t_rvalid && t_out == 0));                    // O4 no unsolicited test response
      assert (!(t_gnt && !owned));                           // O5 test grant only when owned
      assert (f_out <= 4'd4 && t_out <= 4'd2);               // O6 bounded outstanding
      if (owner_state == 3'd0) assert (!quiesce_req);        // O7 NORMAL = no quiesce
    end
  end
  always @(posedge clk) if (rst_n) begin
    `SFTC_REACH(0, owner_state == 3'd4 && t_rvalid)
    `SFTC_REACH(1, owner_state == 3'd6 && f_out == 0)
  end
endmodule
`default_nettype wire
