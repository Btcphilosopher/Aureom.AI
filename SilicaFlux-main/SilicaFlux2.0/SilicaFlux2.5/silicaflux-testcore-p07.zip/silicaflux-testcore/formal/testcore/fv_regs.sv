`include "sftc_defs.svh"
// Formal harness: sftc_regs with every bus and status input free.
`default_nettype none
module fv_regs (
  input wire logic clk, req, we, input wire logic [11:0] addr, input wire logic [31:0] wdata,
  input wire logic [2:0] mode, mode_pending, input wire logic mode_busy, hw_test_en, hw_dbg_en, scan_pin,
  input wire logic [5:0] owner_state, input wire logic [1:0] owner_dirty,
  input wire logic m_busy, m_done, m_pass, m_fail, m_aborted, m_error, m_stopped, m_scrubbing,
  input wire logic [3:0] m_state, input wire logic m_bank, input wire logic [2:0] m_elem,
  input wire logic [3:0] m_addr, input wire logic [3:0] m_algo, input wire logic [2:0] m_last, m_prev,
  input wire logic [1:0] m_tested, m_failed, input wire logic [31:0] m_cycles, input wire logic m_ff_valid,
  input wire logic [23:0] m_ff_info, input wire logic [3:0] m_ff_addr, input wire logic [7:0] m_ff_exp, m_ff_obs,
  input wire logic [15:0] m_fail_count, input wire logic [7:0] m_log_level, input wire logic m_log_ovf,
  input wire logic [23:0] m_log_info, input wire logic [3:0] m_log_addr, input wire logic [7:0] m_log_synd,
  input wire logic [10:0] ev_flags, input wire logic ev_done
);
  logic rst_n = 1'b0;
  always @(posedge clk) rst_n <= 1'b1;
  logic gnt, err, c_start, c_abort, c_clear, c_bg_chk, c_sof, c_scrub, c_log_pop, mode_req_valid, unlocked,
        owner_fault_clear, irq;
  logic [31:0] rdata; logic [3:0] c_algo; logic [1:0] c_mask, protect; logic [2:0] mode_req;
  sftc_regs #(.BANK_COUNT(2), .MAX_W(8), .AW(4), .CNT_W(16)) dut (.*);
  always @(posedge clk) if (rst_n) begin
    `SFTC_REACH(0, unlocked)
    `SFTC_REACH(1, c_start)
  end
endmodule
`default_nettype wire
