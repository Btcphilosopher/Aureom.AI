`include "sftc_defs.svh"
// =============================================================================
// Formal harness: silicaflux_mbist (2 banks: 3x5 with posted writes, 4x3 with
// write responses).  The memory side is UNCONSTRAINED (any grant, any
// response, any data, any time): the engine's safety properties must hold for
// every memory behaviour, including protocol-violating ones.
// =============================================================================
`default_nettype none
module fv_mbist (
  input wire logic       clk,
  input wire logic       start, abort, clear, test_enable,
  input wire logic [3:0] cfg_algo,
  input wire logic       cfg_bg_chk, cfg_sof, cfg_scrub,
  input wire logic [1:0] cfg_bank_mask, bank_owned,
  input wire logic       t_gnt, t_rvalid, t_rerr, t_stray,
  input wire logic [3:0] t_rdata,
  input wire logic       log_pop
);
  `include "sftc_consts.svh"
  logic rst_n = 1'b0;
  always @(posedge clk) rst_n <= 1'b1;

  logic t_req, t_we, busy, done, pass, fail, aborted, error_st, stopped, scrubbing, ev_done;
  logic [2:0] t_addr;
  logic [3:0] t_wdata;
  logic [0:0] t_bank;
  logic [3:0] state, run_algo;
  logic [0:0] cur_bank;
  logic [2:0] cur_elem, last_result, prev_result, cur_addr;
  logic [1:0] tested, failed, scrubbed;
  logic [31:0] cycles;
  logic ev_ref, ev_tmo, ev_spur, ev_merr, ff_valid, cnt_ovf, log_ovf;
  logic [23:0] ff_info, log_info;
  logic [2:0] ff_addr, log_addr;
  logic [3:0] ff_exp, ff_obs, log_synd;
  logic [15:0] fail_count;
  logic [7:0] log_level;

  silicaflux_mbist #(
    .BANK_COUNT(2), .MAX_W(4), .MAX_DEPTH(5),
    .BANK_WIDTHS({8'd4, 8'd3}), .BANK_DEPTHS({24'd3, 24'd5}), .BANK_FLAGS({8'd1, 8'd0}),
    .LOG_DEPTH(2), .CNT_W(4), .TIMEOUT(6)
  ) dut (
    .clk, .rst_n, .test_enable, .start, .abort, .clear, .cfg_algo, .cfg_bg_chk, .cfg_sof, .cfg_scrub,
    .cfg_bank_mask, .bank_owned, .t_req, .t_we, .t_addr, .t_wdata, .t_bank, .t_gnt, .t_rvalid,
    .t_rdata, .t_rerr, .t_stray_rvalid(t_stray), .busy, .done, .pass, .fail, .aborted, .error_st,
    .stopped, .scrubbing, .state, .cur_bank, .cur_elem, .cur_addr, .run_algo, .last_result,
    .prev_result, .banks_tested(tested), .banks_failed(failed), .banks_scrubbed(scrubbed), .cycles,
    .ev_start_refused(ev_ref), .ev_timeout(ev_tmo), .ev_spurious(ev_spur), .ev_mem_err(ev_merr),
    .ev_done, .log_pop, .ff_valid, .ff_info, .ff_addr, .ff_exp, .ff_obs, .fail_count, .cnt_ovf,
    .log_level, .log_ovf, .log_info, .log_addr, .log_synd
  );

  // ---- harness bookkeeping: transactions that require a response
  wire acc      = t_req && t_gnt;
  wire needs_rsp = acc && (!t_we || t_bank == 1'b1);   // bank 1 has WRITE_RESP
  logic outstanding;
  always @(posedge clk) begin
    if (!rst_n) outstanding <= 1'b0;
    else if (needs_rsp) outstanding <= 1'b1;
    else if (state == 4'd4 && t_rvalid) outstanding <= 1'b0;   // consumed in S_WAIT
    else if (state == 4'd7 || state == 4'd0) outstanding <= 1'b0;  // abandoned (ERROR) / idle
  end

  logic p_req, p_we; logic [2:0] p_addr; logic [3:0] p_wdata; logic p_bank, p_valid, p_treq;
  logic [3:0] p_state;
  always @(posedge clk) begin
    p_valid <= rst_n; p_req <= t_req && !t_gnt; p_treq <= t_req;
    p_we <= t_we; p_addr <= t_addr; p_wdata <= t_wdata; p_bank <= t_bank; p_state <= state;
  end

  always @(posedge clk) begin
    if (rst_n && p_valid) begin
      // F1 request held stable until accepted (or the engine errored out on timeout)
      if (p_req) assert ((t_req && t_we == p_we && t_addr == p_addr && t_wdata == p_wdata &&
                          t_bank == p_bank) || state == 4'd7);
      // F2 a new request needs test_enable, ownership and selection of its bank
      if (t_req && !p_treq) assert (test_enable && bank_owned[t_bank]);
      // F3 address generator within the configured bounds of the selected bank
      if (t_req) assert ((t_bank == 1'b0) ? (t_addr <= 3'd4) : (t_addr <= 3'd2));
      // F5 never more than one transaction outstanding; none while issuing a new one
      if (t_req) assert (!outstanding || p_state == 4'd4);
      // F6 completion only after the final transaction retired
      if (ev_done) assert (!outstanding && p_state == 4'd6);
      // F7 PASS is never reported for a run with a detected mismatch
      if (done && last_result == RES_PASS) assert (!fail);
      // F8 no request during or right after reset
      if (!$past(rst_n)) assert (!t_req);
      // F9 idle engine issues nothing
      if (state == 4'd0 || state == 4'd7) assert (!t_req);
      // F10 first-failure record is preserved until clear / accepted start
      if ($past(ff_valid) && !$past(clear) && !($past(start) && $past(state) == 4'd0))
        assert (ff_valid && $stable(ff_addr) && $stable(ff_exp) && $stable(ff_obs) && $stable(ff_info));
      // F11 fail counter saturates (never wraps)
      if ($past(fail_count) == 4'hF && !$past(clear) && !($past(start) && $past(state) == 4'd0))
        assert (fail_count == 4'hF);
    end
  end
  // reachability (non-vacuity)
  always @(posedge clk) begin
    if (rst_n) begin
      `SFTC_REACH(0, ev_done && last_result == RES_PASS && cfg_algo == 4'd0)
      `SFTC_REACH(1, ev_done && last_result == RES_FAIL)
      `SFTC_REACH(2, state == 4'd7)
      `SFTC_REACH(3, t_req && t_bank == 1'b1 && t_addr == 3'd2)
    end
  end
endmodule
`default_nettype wire
