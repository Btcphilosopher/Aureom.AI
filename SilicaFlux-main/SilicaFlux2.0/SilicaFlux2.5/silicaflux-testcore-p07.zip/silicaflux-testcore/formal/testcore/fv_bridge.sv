`include "sftc_defs.svh"
// =============================================================================
// Formal harness: sftc_jtag_reg_bridge, TCK and system clock ASYNCHRONOUS
// (multiclock: the solver chooses the interleaving of both clock edges).
// TAP state is free (any sequence) but restricted to legal TAP encodings.
// Synchronisers are modelled as plain flops: metastability resolution is NOT
// modelled (structural CDC review + MTBF analysis are separate sign-offs).
// =============================================================================
`default_nettype none
module fv_bridge (
  input wire logic        tck, clk,
  input wire logic [3:0]  tap_state,
  input wire logic        sel_reg, sel_status, tdi,
  input wire logic        m_gnt, m_err,
  input wire logic [31:0] m_rdata
);
  logic trst_n = 1'b0, rst_n = 1'b0;
  always @(posedge tck) trst_n <= 1'b1;
  always @(posedge clk) rst_n <= 1'b1;
  logic tdo_reg, tdo_status, m_req, m_we, launch, exec;
  logic [11:0] m_addr; logic [31:0] m_wdata;
  sftc_jtag_reg_bridge dut (.tck, .trst_n, .tap_state, .sel_reg, .sel_status, .tdi, .tdo_reg, .tdo_status,
    .clk, .rst_n, .m_req, .m_we, .m_addr, .m_wdata, .m_gnt, .m_rdata, .m_err,
    .launch_tck(launch), .exec_sys(exec));
  // launches counted on TCK, executions on clk (both counters 2 bits, compared mod 4)
  logic [1:0] n_l, n_e;
  always @(posedge tck) if (!trst_n) n_l <= 0; else if (launch) n_l <= n_l + 1;
  always @(posedge clk) if (!rst_n)  n_e <= 0; else if (exec)   n_e <= n_e + 1;
  // payload stability while a request is pending (sampled on clk)
  logic p_req; logic [11:0] p_addr; logic [31:0] p_wdata; logic p_we;
  always @(posedge clk) begin p_req <= rst_n && m_req && !m_gnt; p_addr <= m_addr; p_wdata <= m_wdata; p_we <= m_we; end
  always @(posedge clk) begin
    if (rst_n && trst_n) begin
      assert ((n_l - n_e) == 2'd0 || (n_l - n_e) == 2'd1);            // B1 no duplication, <= 1 in flight
      if (p_req) assert (m_req && m_addr == p_addr && m_wdata == p_wdata && m_we == p_we);  // B2 coherent payload
    end
  end
  always @(posedge clk) if (rst_n && trst_n) begin
    `SFTC_REACH(0, exec && n_e == 2'd1)
  end
endmodule
`default_nettype wire
