# JTAG_ACCESS: TCK at the maximum supported test frequency profile (20 MHz)
# with the system clock running (register bridge).
source [file dirname [info script]]/testcore_common.tcl
create_clock -name clk -period 20 [get_ports clk]
create_clock -name tck -period 50 [get_ports tck]
set_clock_groups -asynchronous -group clk -group tck
set_clock_uncertainty 0.25 [all_clocks]
set_case_analysis 0 [get_ports scan_mode_pin]
catch { set_case_analysis 0 [get_ports scan_enable_0] }
sftc_io clk 20
sftc_jtag_io 50
sftc_resets
