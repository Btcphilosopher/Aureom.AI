# NORMAL / functional mode: scan off, test pins static low.
source [file dirname [info script]]/testcore_common.tcl
create_clock -name clk -period 20  [get_ports clk]
create_clock -name tck -period 100 [get_ports tck]
# TCK and clk are asynchronous; every crossing goes through sftc_sync /
# the toggle-handshake bridge (verified formally in fv_bridge).
set_clock_groups -asynchronous -group clk -group tck
set_clock_uncertainty 0.25 [all_clocks]
set_case_analysis 0 [get_ports scan_mode_pin]
set_case_analysis 0 [get_ports scan_en_pin]
catch { set_case_analysis 0 [get_ports scan_enable_0] }
sftc_io clk 20
sftc_jtag_io 100
sftc_resets
