# SCAN_CAPTURE (stuck-at, slow capture 10 MHz): one capture clock pulsed per
# pattern (ATPG capture-domain constraint) -> clocks physically exclusive.
source [file dirname [info script]]/testcore_common.tcl
create_clock -name clk -period 100 [get_ports clk]
create_clock -name tck -period 100 [get_ports tck]
set_clock_groups -physically_exclusive -group clk -group tck
set_clock_uncertainty 0.5 [all_clocks]
set_case_analysis 1 [get_ports scan_mode_pin]
set_case_analysis 1 [get_ports hw_test_en]
set_case_analysis 0 [get_ports scan_enable_0]
set_case_analysis 0 [get_ports scan_en_pin]
sftc_io clk 100
sftc_resets
