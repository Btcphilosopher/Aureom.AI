# SCAN_SHIFT: tester drives clk and tck pins with the shift clock (25 MHz);
# chains are clock-domain pure (OpenROAD -clock_mixing no_mix), so the two
# clocks are logically exclusive in shift.  scan_in/scan_out I/O constrained.
source [file dirname [info script]]/testcore_common.tcl
create_clock -name clk -period 40 [get_ports clk]
create_clock -name tck -period 40 [get_ports tck]
set_clock_groups -logically_exclusive -group clk -group tck
set_clock_uncertainty 0.5 [all_clocks]
set_case_analysis 1 [get_ports scan_mode_pin]
set_case_analysis 1 [get_ports hw_test_en]
set_case_analysis 1 [get_ports scan_enable_0]
set_case_analysis 1 [get_ports scan_en_pin]
set_input_delay  8 -clock clk [get_ports scan_in_*]
set_output_delay 8 -clock clk [get_ports scan_out_*]
sftc_resets
