# SilicaFlux TestCore -- shared SDC helpers (OpenSTA / OpenROAD).  Every
# exception below is listed with its justification; there are NO blanket
# false paths on test logic.
proc sftc_io {clk per} {
  # functional / register-bus I/O: 20 % of the period on both sides
  set ins [delete_from_list [all_inputs] [get_ports {clk tck trst_n rst_n tms tdi}]]
  catch { set ins [delete_from_list $ins [get_ports scan_rst_n_pin]] }
  catch { set ins [delete_from_list $ins [get_ports scan_in_*]] }
  catch { set ins [delete_from_list $ins [get_ports scan_enable_0]] }
  set_input_delay  [expr $per * 0.2] -clock $clk $ins
  set outs [delete_from_list [all_outputs] [get_ports {tdo tdo_oe}]]
  catch { set outs [delete_from_list $outs [get_ports scan_out_*]] }
  set_output_delay [expr $per * 0.2] -clock $clk $outs
  set_load 0.01 [all_outputs]
}
proc sftc_jtag_io {tckper} {
  # IEEE 1149.1 style: TDI/TMS sampled on TCK rise, TDO launched on TCK fall
  set_input_delay  [expr $tckper * 0.2] -clock tck [get_ports {tms tdi}]
  set_output_delay [expr $tckper * 0.2] -clock tck [get_ports {tdo tdo_oe}]
}
# Justified exceptions:
#  * rst_n / trst_n / scan_rst_n_pin: asynchronous reset assertion; deassertion
#    is synchronised by the SoC reset controller (sfv_rst_sync) -> recovery /
#    removal checks only, no data-path timing.
proc sftc_resets {} {
  set_false_path -from [get_ports {rst_n trst_n}]
  catch { set_false_path -from [get_ports scan_rst_n_pin] }
}
