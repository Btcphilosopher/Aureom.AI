# MBIST mode: engine and memories on the functional clock at full speed
# (MBIST at-speed validity in silicon additionally requires the memory macro's
# own timing characterisation -- not modelled by the proxy).
source [file dirname [info script]]/testcore_common.tcl
create_clock -name clk -period 20  [get_ports clk]
create_clock -name tck -period 100 [get_ports tck]
set_clock_groups -asynchronous -group clk -group tck
set_clock_uncertainty 0.25 [all_clocks]
set_case_analysis 1 [get_ports hw_test_en]
set_case_analysis 0 [get_ports scan_mode_pin]
catch { set_case_analysis 0 [get_ports scan_enable_0] }
sftc_io clk 20
sftc_jtag_io 100
sftc_resets
