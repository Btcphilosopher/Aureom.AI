# =============================================================================
# SilicaFlux TestCore -- OpenROAD DFT scan insertion (experimental open flow)
#   openroad -exit asic/dft/run_scan.tcl     (env: SFTC_PDK, SFTC_NET, SFTC_TOP, SFTC_OUT, SFTC_MAXLEN)
# Inputs : Yosys sky130hd netlist of variant E (reports/testcore/synth/E/netlist.v)
# Outputs: scan-inserted netlist, DFT plan / chain report
# =============================================================================
set pdk    $::env(SFTC_PDK)
set net    $::env(SFTC_NET)
set top    $::env(SFTC_TOP)
set out    $::env(SFTC_OUT)
set maxlen $::env(SFTC_MAXLEN)
read_lef     $pdk/sky130hd.tlef
read_lef     $pdk/sky130_fd_sc_hd_merged.lef
read_liberty $pdk/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog $net
link_design  $top
create_clock -name clk -period 20  [get_ports clk]
create_clock -name tck -period 100 [get_ports tck]
set_dft_config -max_length $maxlen -clock_mixing no_mix \
    -scan_enable_name_pattern "scan_enable_{}" -scan_in_name_pattern "scan_in_{}" -scan_out_name_pattern "scan_out_{}"
report_dft_config
scan_replace
report_dft_plan -verbose
execute_dft_plan
write_verilog $out/scan_netlist.v
puts "SFTC_SCAN_DONE"
