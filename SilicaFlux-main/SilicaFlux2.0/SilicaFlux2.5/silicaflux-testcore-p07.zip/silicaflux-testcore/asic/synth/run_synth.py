#!/usr/bin/env python3
"""ASIC synthesis comparison of TestCore variants (Yosys + OpenSTA, sky130hd).

    python3 asic/synth/run_synth.py [--lib <liberty>] [--period-ns 20]

Variants (asic/synth/variants/sftc_synth_variants.sv): A0, A1, B, C, D, E.
Identical RTL options, liberty, constraints and macro proxy for every variant.
Results: reports/testcore/synth/<variant>/{yosys.log,stat.txt,netlist.v,sta.rpt}
and reports/testcore/synth/summary.json.  Evidence class: LOGIC SYNTHESIS +
STATIC TIMING (pre-placement, ideal clocks, wire-load-free) -- not post-layout.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
R = ROOT / "rtl" / "testcore"
V = ROOT / "third_party" / "silicaflux-v" / "rtl" / "mem"
OUT = ROOT / "reports" / "testcore" / "synth"
PDK = Path(os.environ.get("SFTC_PDK", ROOT / "third_party" / "pdk"))

RTL = [R / f for f in ["sftc_sync.sv", "sftc_mbist_addr_gen.sv", "sftc_mbist_pattern.sv", "sftc_mbist_cmp.sv",
                       "sftc_mbist_fail_log.sv", "silicaflux_mbist.sv", "sftc_mbist_bank_mux.sv", "sftc_regs.sv",
                       "silicaflux_test_mode_controller.sv", "sftc_jtag_tap.sv", "sftc_jtag_reg_bridge.sv",
                       "sftc_mem_owner.sv", "sftc_tst_port_adapter.sv", "sftc_sfv_bank_shim.sv", "sftc_dft_ctrl.sv",
                       "sftc_testcore_top.sv"]] + \
      [V / "sfv_mem_slaves.sv", V / "sfv_mbist.sv", ROOT / "asic/synth/stubs/sfv_sram_sp_proxy.sv",
       ROOT / "asic/synth/variants/sftc_synth_variants.sv"]

VARIANTS = {
    "A0": ("sftc_var_a0", "4 x sfv_sram_slave, no MBIST (baseline)"),
    "A1": ("sftc_var_a1", "4 x sfv_sram_slave + release-1 sfv_mbist (existing in-repo MBIST)"),
    "B":  ("sftc_var_b", "TestCore MBIST + ownership shims + registers (system bus)"),
    "C":  ("sftc_var_c", "B + test-mode controller"),
    "D":  ("sftc_var_d", "C + JTAG TAP + CDC bridge (full sftc_testcore_top)"),
    "E":  ("sftc_var_e", "D + DFT scan controls (scan cells inserted by OpenROAD, see dft step)"),
    "Dmin": ("sftc_var_dmin", "D with first-silicon minimal options: LOG_DEPTH=0 (first failure only), CNT_W=8"),
}
PROXY_FLOPS_PER_BANK = 83     # registers of the macro proxy (1+1+4+13+32+32)


def which(name, env):
    p = os.environ.get(env)
    if p:
        return p
    return shutil.which(name)


def yosys_script(top, lib, period_ps, outdir, flatten=True):
    files = " ".join(str(f) for f in RTL)
    return f"""
read_verilog -sv -DSYNTHESIS -I{R} {files}
hierarchy -top {top}
synth -top {top} {'-flatten' if flatten else ''}
dfflibmap -liberty {lib} -dont_use *lpflow* -dont_use *probe*
abc -liberty {lib} -D {period_ps} -dont_use *lpflow* -dont_use *probe*
opt_clean -purge
hilomap -hicell sky130_fd_sc_hd__conb_1 HI -locell sky130_fd_sc_hd__conb_1 LO
setundef -zero
splitnets
opt_clean -purge
check
tee -o {outdir}/stat.txt stat -liberty {lib}
write_verilog -noattr -noexpr {outdir}/netlist.v
"""


def parse_stat(txt: str) -> dict:
    cells = {}
    area = None
    m = re.search(r"Chip area for (?:top )?module '?\\?(\S+?)'?:\s+([\d.]+)", txt)
    if m:
        area = float(m.group(2))
    for mm in re.finditer(r"^\s+(\d+)\s+[\d.E+-]*\s*(sky130_fd_sc_hd__\w+)", txt, re.M):
        cells[mm.group(2)] = cells.get(mm.group(2), 0) + int(mm.group(1))
    if not cells:
        for mm in re.finditer(r"^\s+(sky130_fd_sc_hd__\w+)\s+(\d+)", txt, re.M):
            cells[mm.group(1)] = int(mm.group(2))
    flops = sum(n for c, n in cells.items() if re.search(r"__(s?df|edf|dl)", c))
    scan = sum(n for c, n in cells.items() if "__sdf" in c)
    muxes = sum(n for c, n in cells.items() if "mux" in c)
    return {"area_um2": area, "cells": sum(cells.values()), "flops": flops, "scan_flops": scan, "muxes": muxes,
            "cell_types": cells}


STA_TCL = """
read_liberty {lib}
read_verilog {net}
link_design {top}
create_clock -name clk -period {per} [get_ports clk]
{tck}
set_clock_uncertainty 0.25 [all_clocks]
set_input_delay  [expr {per} * 0.2] -clock clk [delete_from_list [all_inputs] [get_ports {{clk tck trst_n rst_n}}]]
set_output_delay [expr {per} * 0.2] -clock clk [all_outputs]
set_load 0.01 [all_outputs]
set_false_path -from [get_ports rst_n]
{tckfp}
report_checks -path_delay max -group_path_count 1 -format full_clock_expanded -digits 3
report_wns -digits 3
report_tns -digits 3
report_worst_slack -max -digits 3
puts "SFTC_REG2REG_BEGIN"
report_checks -path_delay max -from [all_registers -clock_pins] -to [all_registers -data_pins] -format end -digits 3
puts "SFTC_FUNC_BEGIN"
report_checks -path_delay max -from [get_ports {{req* we* addr* wdata* be*}}] -format end -digits 3
report_checks -path_delay max -to [get_ports {{gnt* rvalid* rdata* err*}}] -format end -digits 3
report_power -digits 6
"""


def run_sta(sta, lib, net, top, per_ns, outdir, has_tck):
    tck = "create_clock -name tck -period 100 [get_ports tck]\nset_clock_groups -asynchronous -group clk -group tck" \
        if has_tck else ""
    # TCK-domain I/O are constrained to tck; reset/trst are asynchronous (documented, not blanket test false paths)
    tckfp = "set_false_path -from [get_ports trst_n]\nset_input_delay 20 -clock tck [get_ports {tms tdi}]\n" \
            "set_output_delay 20 -clock tck [get_ports {tdo tdo_oe}]" if has_tck else ""
    script = STA_TCL.format(lib=lib, net=net, top=top, per=per_ns, tck=tck, tckfp=tckfp)
    (outdir / "sta.tcl").write_text(script)
    p = subprocess.run([sta, "-no_init", "-exit", str(outdir / "sta.tcl")], capture_output=True, text=True, timeout=1800)
    (outdir / "sta.rpt").write_text(p.stdout + p.stderr)
    t = p.stdout
    wns = re.search(r"wns (?:max )?(-?[\d.]+)", t)
    tns = re.search(r"tns (?:max )?(-?[\d.]+)", t)
    ws = re.search(r"worst slack (?:max )?(-?[\d.]+)", t)
    pw = re.search(r"^Total\s+([\d.eE+-]+)\s+([\d.eE+-]+)\s+([\d.eE+-]+)\s+([\d.eE+-]+)", t, re.M)
    def worst_end(seg):
        rows = [(float(x), float(y)) for x, y in
                re.findall(r"-?[\d.]+\s+(-?[\d.]+)\s+(-?[\d.]+) \((?:MET|VIOLATED)\)", seg)]
        return {"worst_slack_ns": min(r[1] for r in rows), "max_arrival_ns": max(r[0] for r in rows)} if rows else None
    r2r = t.split("SFTC_REG2REG_BEGIN")[-1].split("SFTC_FUNC_BEGIN")[0] if "SFTC_REG2REG_BEGIN" in t else ""
    fun = t.split("SFTC_FUNC_BEGIN")[-1] if "SFTC_FUNC_BEGIN" in t else ""
    return {"wns_ns": float(wns.group(1)) if wns else None, "tns_ns": float(tns.group(1)) if tns else None,
            "worst_slack_ns": float(ws.group(1)) if ws else None,
            "reg2reg_worst_slack_ns": worst_end(r2r), "functional_port_worst_slack_ns": worst_end(fun),
            "power_w": {"internal": float(pw.group(1)), "switching": float(pw.group(2)),
                        "leakage": float(pw.group(3)), "total": float(pw.group(4))} if pw else None}


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--lib", default=str(PDK / "sky130_fd_sc_hd__tt_025C_1v80.lib"))
    ap.add_argument("--period-ns", type=float, default=20.0)
    ap.add_argument("--only", default="")
    a = ap.parse_args(argv)
    lib = Path(a.lib)
    yosys = which("yosys", "SFTC_YOSYS")
    sta = which("sta", "SFTC_STA")
    OUT.mkdir(parents=True, exist_ok=True)
    if not lib.exists() or not yosys:
        (OUT / "summary.json").write_text(json.dumps({"status": "BLOCKED",
                                                      "reason": f"liberty {lib} or yosys missing"}))
        print("[synth] BLOCKED: liberty or yosys not available (run scripts/fetch_pdk.sh)")
        return 2
    ver = subprocess.run([yosys, "-V"], capture_output=True, text=True).stdout.strip()
    stav = subprocess.run([sta, "-version"], capture_output=True, text=True).stdout.strip() if sta else "unavailable"
    res = {"evidence_class": "LOGIC SYNTHESIS + STATIC TIMING (pre-placement, ideal clocks, no wire parasitics)",
           "library": lib.name, "period_ns": a.period_ns, "yosys": ver, "sta": stav,
           "macro_proxy_flops_per_bank": PROXY_FLOPS_PER_BANK, "variants": {}}
    for key, (top, desc) in VARIANTS.items():
        if a.only and key not in a.only.split(","):
            continue
        od = OUT / key
        od.mkdir(parents=True, exist_ok=True)
        (od / "synth.ys").write_text(yosys_script(top, lib, int(a.period_ns * 1000), od))
        p = subprocess.run([yosys, "-q", "-l", str(od / "yosys.log"), "-s", str(od / "synth.ys")],
                           capture_output=True, text=True, timeout=3600)
        if p.returncode != 0:
            res["variants"][key] = {"status": "FAIL", "error": (p.stdout + p.stderr)[-2000:]}
            print(f"[synth] {key} FAILED"); continue
        st = parse_stat((od / "stat.txt").read_text())
        log = (od / "yosys.log").read_text()
        st["latches"] = len(re.findall(r"\$_DLATCH|sky130_fd_sc_hd__dl", (od / "netlist.v").read_text()))
        st["check_problems"] = len(re.findall(r"Warning: .*(multiple|driver|combinational loop)", log, re.I))
        st["logic_flops_excl_proxy"] = st["flops"] - 4 * PROXY_FLOPS_PER_BANK
        tim = run_sta(sta, lib, od / "netlist.v", top, a.period_ns, od, key in ("D", "E")) if sta else {}
        res["variants"][key] = {"top": top, "description": desc, "status": "PASS", **st, "timing": tim}
        print(f"[synth] {key:3s} area={st['area_um2']:.1f} um2 cells={st['cells']} flops={st['flops']} "
              f"latches={st['latches']} wns={tim.get('wns_ns')} slack={tim.get('worst_slack_ns')}", flush=True)
    # hierarchical area breakdown of the full TestCore (variant D, not flattened)
    od = OUT / "D_hier"
    od.mkdir(parents=True, exist_ok=True)
    (od / "synth.ys").write_text(yosys_script("sftc_var_d", lib, int(a.period_ns * 1000), od, flatten=False))
    subprocess.run([yosys, "-q", "-l", str(od / "yosys.log"), "-s", str(od / "synth.ys")], capture_output=True,
                   timeout=3600)
    hier = {}
    txt = (od / "stat.txt").read_text() if (od / "stat.txt").exists() else ""
    for m in re.finditer(r"=== (\S+) ===.*?Chip area for module '?\\?(\S+?)'?:\s+([\d.]+)", txt, re.S):
        hier[m.group(1).split("\\")[-1]] = float(m.group(3))
    res["hierarchy_D_um2"] = hier
    base = res["variants"].get("A0", {}).get("area_um2")
    for k, v in res["variants"].items():
        if base and v.get("area_um2"):
            v["delta_vs_A0_um2"] = round(v["area_um2"] - base, 2)
    (OUT / "summary.json").write_text(json.dumps(res, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
