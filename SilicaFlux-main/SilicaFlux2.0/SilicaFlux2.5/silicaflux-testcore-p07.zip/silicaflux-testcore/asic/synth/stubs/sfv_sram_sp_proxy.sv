// =============================================================================
// SYNTHESIS-ONLY timing/area proxy for the SilicaFlux-V SRAM macro bank
// (sfv_sram_sp).  The real bank is a hard macro (sky130 OpenRAM tiling / IHP
// RM_IHPSG13) and must not be synthesised into flip-flops.  This proxy
// registers every macro input pin and drives rdata from a register, so that
//   * all logic in front of / behind the macro is kept and timed
//     (paths end at an ideal registered macro pin: NO macro setup/clk->q
//     timing is modelled -- relative comparison between variants only);
//   * its own cost (83 flops per bank) is identical in every variant and is
//     reported separately and subtracted in the area comparison.
// =============================================================================
`default_nettype none
module sfv_sram_sp #(
  parameter int DEPTH = 8192,
  localparam int AW = $clog2(DEPTH)
) (
  input  wire logic          clk,
  input  wire logic          ce,
  input  wire logic          we,
  input  wire logic [3:0]    be,
  input  wire logic [AW-1:0] addr,
  input  wire logic [31:0]   wdata,
  output logic [31:0]        rdata
);
  (* keep *) logic          p_ce, p_we;
  (* keep *) logic [3:0]    p_be;
  (* keep *) logic [AW-1:0] p_addr;
  (* keep *) logic [31:0]   p_wdata, p_q;
  always_ff @(posedge clk) begin
    p_ce <= ce; p_we <= we; p_be <= be; p_addr <= addr; p_wdata <= wdata;
    p_q  <= p_wdata ^ {{(32-AW){1'b0}}, p_addr} ^ {28'd0, p_be} ^ {30'd0, p_we, p_ce};
  end
  assign rdata = p_q;
endmodule
`default_nettype wire
