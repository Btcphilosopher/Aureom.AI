// =============================================================================
// Synthesis comparison variants (SilicaFlux-V: 4 banks x 32 bit x 8192 words)
//   A0  4 x sfv_sram_slave, collar tied off (no MBIST at all)
//   A1  4 x sfv_sram_slave + release-1 sfv_mbist (existing in-repo MBIST)
//   B   4 x sftc_sfv_bank_shim + silicaflux_mbist + bank mux + registers
//       (register bus from the system bus only, test_enable = pin)
//   C   B + silicaflux_test_mode_controller (permissions, unlock)
//   D   sftc_testcore_top (adds JTAG TAP + CDC bridge) + 4 shims
//   E   D + sftc_dft_ctrl (scan controls); scan cells inserted by OpenROAD
// Functional crossbar ports of the four banks are flattened to top ports.
// =============================================================================
`default_nettype none

module sftc_var_a0 (
  input wire logic clk, rst_n,
  input wire logic [3:0] req, we, input wire logic [127:0] addr, wdata, input wire logic [15:0] be,
  output logic [3:0] gnt, rvalid, err, output logic [127:0] rdata
);
  genvar k;
  for (k = 0; k < 4; k++) begin : g
    sfv_sram_slave #(.DEPTH(8192)) u (.clk, .rst_n, .req(req[k]), .gnt(gnt[k]), .addr(addr[k*32 +: 32]),
      .we(we[k]), .be(be[k*4 +: 4]), .wdata(wdata[k*32 +: 32]), .rvalid(rvalid[k]), .rdata(rdata[k*32 +: 32]),
      .err(err[k]), .bist_en(1'b0), .bist_ce(1'b0), .bist_we(1'b0), .bist_addr('0), .bist_wdata('0), .bist_rdata());
  end
endmodule

module sftc_var_a1 (
  input wire logic clk, rst_n,
  input wire logic [3:0] req, we, input wire logic [127:0] addr, wdata, input wire logic [15:0] be,
  output logic [3:0] gnt, rvalid, err, output logic [127:0] rdata,
  input wire logic start, bg_chk, output logic busy, done, fail, output logic [3:0] fail_bank,
  output logic [12:0] fail_addr, output logic [2:0] fail_elem
);
  logic bist_en, bist_ce, bist_we; logic [12:0] bist_addr; logic [31:0] bist_wdata; logic [127:0] bist_rdata;
  sfv_mbist #(.AW(13), .NBANKS(4)) u_mbist (.clk, .rst_n, .start, .bg_chk, .last(13'd8191), .busy, .done, .fail,
    .fail_bank, .fail_addr, .fail_elem, .bist_en, .bist_ce, .bist_we, .bist_addr, .bist_wdata, .bist_rdata);
  genvar k;
  for (k = 0; k < 4; k++) begin : g
    sfv_sram_slave #(.DEPTH(8192)) u (.clk, .rst_n, .req(req[k]), .gnt(gnt[k]), .addr(addr[k*32 +: 32]),
      .we(we[k]), .be(be[k*4 +: 4]), .wdata(wdata[k*32 +: 32]), .rvalid(rvalid[k]), .rdata(rdata[k*32 +: 32]),
      .err(err[k]), .bist_en, .bist_ce, .bist_we, .bist_addr, .bist_wdata, .bist_rdata(bist_rdata[k*32 +: 32]));
  end
endmodule

// shared bank array of shims (used by B, C, D, E)
module sftc_var_banks (
  input wire logic clk, rst_n,
  input wire logic [3:0] req, we, input wire logic [127:0] addr, wdata, input wire logic [15:0] be,
  output logic [3:0] gnt, rvalid, err, output logic [127:0] rdata,
  input wire logic [3:0] b_req, input wire logic b_we, input wire logic [12:0] b_addr, input wire logic [31:0] b_wdata,
  output logic [3:0] b_gnt, b_rvalid, b_rerr, output logic [127:0] b_rdata,
  input wire logic [3:0] acq_req, scrub_done, quiesce_ack, input wire logic fault_clear, mbist_busy,
  output logic [3:0] quiesce_req, owned, dirty, ev_fault, ev_intr, ev_reinit, output logic [11:0] ostate
);
  genvar k;
  for (k = 0; k < 4; k++) begin : g
    sftc_sfv_bank_shim #(.DEPTH(8192), .OWN_TIMEOUT(4096)) u (.clk, .rst_n, .req(req[k]), .gnt(gnt[k]),
      .addr(addr[k*32 +: 32]), .we(we[k]), .be(be[k*4 +: 4]), .wdata(wdata[k*32 +: 32]), .rvalid(rvalid[k]),
      .rdata(rdata[k*32 +: 32]), .err(err[k]), .t_req(b_req[k]), .t_gnt(b_gnt[k]), .t_we(b_we), .t_addr(b_addr),
      .t_wdata(b_wdata), .t_rvalid(b_rvalid[k]), .t_rdata(b_rdata[k*32 +: 32]), .t_rerr(b_rerr[k]),
      .acq_req(acq_req[k]), .fault_clear, .quiesce_ack(quiesce_ack[k]), .quiesce_req(quiesce_req[k]), .mbist_busy,
      .scrub_done(scrub_done[k]), .owned(owned[k]), .owner_state(ostate[k*3 +: 3]), .dirty(dirty[k]),
      .ev_fault(ev_fault[k]), .ev_intrusion(ev_intr[k]), .ev_reinit_req(ev_reinit[k]));
  end
endmodule

// B and C share this core; C adds the mode controller (WITH_MODE = 1)
module sftc_var_bc #(parameter bit WITH_MODE = 1'b0) (
  input wire logic clk, rst_n,
  input wire logic [3:0] req, we, input wire logic [127:0] addr, wdata, input wire logic [15:0] be,
  output logic [3:0] gnt, rvalid, err, output logic [127:0] rdata,
  input wire logic [3:0] quiesce_ack, output logic [3:0] quiesce_req,
  input wire logic s_req, s_we, input wire logic [11:0] s_addr, input wire logic [31:0] s_wdata,
  output logic [31:0] s_rdata, output logic s_err,
  input wire logic test_enable_pin, hw_dbg_en, hw_test_en, scan_mode_pin, scan_en_pin,
  output logic irq, done, pass, scan_mode, scan_en, output logic [2:0] mode
);
  `include "sftc_consts.svh"
  logic [3:0] b_req, b_gnt, b_rvalid, b_rerr, acq_req, scrub_done, owned, dirty, evf, evi, evr;
  logic b_we, t_req, t_we, t_gnt, t_rvalid, t_rerr, t_stray, s_gnt;
  logic [12:0] b_addr, t_addr; logic [31:0] b_wdata, t_wdata, t_rdata; logic [127:0] b_rdata; logic [1:0] t_bank;
  logic [11:0] ostate;
  logic c_start, c_abort, c_clear, c_bg, c_sof, c_scrub, c_pop, mreq_v, unlocked, ofc;
  logic [3:0] c_algo; logic [2:0] mreq; logic [3:0] c_mask, protect;
  logic m_busy, m_done, m_pass, m_fail, m_ab, m_err, m_stop, m_scr, ev_ref, ev_tmo, ev_spur, ev_merr, ev_done;
  logic [3:0] m_state, m_algo; logic [1:0] m_bank; logic [2:0] m_elem, m_last, m_prev; logic [12:0] m_addr;
  logic [3:0] m_tested, m_failed, m_scrubbed; logic [31:0] m_cycles;
  logic ffv, cov, lov; logic [23:0] ffi, lgi; logic [12:0] ffa, lga; logic [31:0] ffe, ffo, lgs; logic [15:0] fcnt;
  logic [7:0] lvl;
  logic mbist_enable, mbist_abort, mode_busy, jm, dm, ev_ill, ev_den; logic [2:0] mpend;

  sftc_var_banks u_banks (.clk, .rst_n, .req, .we, .addr, .wdata, .be, .gnt, .rvalid, .err, .rdata,
    .b_req, .b_we, .b_addr, .b_wdata, .b_gnt, .b_rvalid, .b_rerr, .b_rdata, .acq_req, .scrub_done, .quiesce_ack,
    .fault_clear(ofc), .mbist_busy(m_busy), .quiesce_req, .owned, .dirty, .ev_fault(evf), .ev_intr(evi),
    .ev_reinit(evr), .ostate);

  logic [10:0] ev_flags;
  always_comb begin
    ev_flags = '0;
    ev_flags[EF_TIMEOUT] = ev_tmo; ev_flags[EF_SPURIOUS] = ev_spur; ev_flags[EF_ILLEGAL_START] = ev_ref;
    ev_flags[EF_MEM_ERR] = ev_merr; ev_flags[EF_OWNER_FAULT] = |evf; ev_flags[EF_INTRUSION] = |evi;
    ev_flags[EF_REINIT_REQ] = |evr; ev_flags[EF_ILLEGAL_MODE] = ev_ill || ev_den;
  end

  sftc_regs #(.BANK_COUNT(4), .MAX_W(32), .AW(13), .CNT_W(16), .BANK_WIDTHS({4{8'd32}}),
              .BANK_DEPTHS({4{24'd8192}}), .BANK_FLAGS('0), .LOG_DEPTH(4)) u_regs (
    .clk, .rst_n, .req(s_req), .we(s_we), .addr(s_addr), .wdata(s_wdata), .gnt(s_gnt), .rdata(s_rdata), .err(s_err),
    .c_start, .c_abort, .c_clear, .c_algo, .c_bg_chk(c_bg), .c_sof, .c_scrub, .c_mask, .c_log_pop(c_pop),
    .mode_req_valid(mreq_v), .mode_req(mreq), .unlocked, .protect, .owner_fault_clear(ofc), .irq,
    .mode, .mode_busy, .mode_pending(mpend), .hw_test_en, .hw_dbg_en, .scan_pin(scan_mode_pin),
    .owner_state(ostate), .owner_dirty(dirty), .m_busy, .m_done, .m_pass, .m_fail, .m_aborted(m_ab),
    .m_error(m_err), .m_stopped(m_stop), .m_scrubbing(m_scr), .m_state, .m_bank, .m_elem, .m_addr, .m_algo,
    .m_last, .m_prev, .m_tested, .m_failed, .m_cycles, .m_ff_valid(ffv), .m_ff_info(ffi), .m_ff_addr(ffa),
    .m_ff_exp(ffe), .m_ff_obs(ffo), .m_fail_count(fcnt), .m_log_level(lvl), .m_log_ovf(lov), .m_log_info(lgi),
    .m_log_addr(lga), .m_log_synd(lgs), .ev_flags, .ev_done);

  if (WITH_MODE) begin : g_mode
    logic released;
    always_comb begin released = 1'b1; for (int i = 0; i < 4; i++) if (ostate[i*3 +: 3] != 3'd0 && ostate[i*3 +: 3] != 3'd7) released = 1'b0; end
    silicaflux_test_mode_controller u_mode (.clk, .rst_n, .hw_dbg_en, .hw_test_en, .unlocked, .scan_mode_pin,
      .scan_en_pin, .req_valid(mreq_v), .req_mode(mreq), .mbist_busy(m_busy), .banks_released(released), .mode,
      .mode_busy, .pending(mpend), .mbist_enable, .mbist_abort, .jtag_mode(jm), .diag_mode(dm), .scan_mode, .scan_en,
      .ev_illegal(ev_ill), .ev_denied(ev_den));
  end else begin : g_nomode
    assign mbist_enable = test_enable_pin; assign mbist_abort = 1'b0; assign mode_busy = 1'b0;
    assign mpend = '0; assign mode = test_enable_pin ? 3'd2 : 3'd0; assign ev_ill = 1'b0; assign ev_den = 1'b0;
    assign scan_mode = 1'b0; assign scan_en = 1'b0; assign jm = 1'b0; assign dm = 1'b0;
  end

  silicaflux_mbist #(.BANK_COUNT(4), .MAX_W(32), .MAX_DEPTH(8192), .BANK_WIDTHS({4{8'd32}}),
    .BANK_DEPTHS({4{24'd8192}}), .BANK_FLAGS('0), .LOG_DEPTH(4), .CNT_W(16), .TIMEOUT(1024)) u_mbist (
    .clk, .rst_n, .test_enable(mbist_enable), .start(c_start), .abort(c_abort || mbist_abort), .clear(c_clear),
    .cfg_algo(c_algo), .cfg_bg_chk(c_bg), .cfg_sof(c_sof), .cfg_scrub(c_scrub), .cfg_bank_mask(c_mask),
    .bank_owned(owned), .t_req, .t_we, .t_addr, .t_wdata, .t_bank, .t_gnt, .t_rvalid, .t_rdata, .t_rerr,
    .t_stray_rvalid(t_stray), .busy(m_busy), .done(m_done), .pass(m_pass), .fail(m_fail), .aborted(m_ab),
    .error_st(m_err), .stopped(m_stop), .scrubbing(m_scr), .state(m_state), .cur_bank(m_bank), .cur_elem(m_elem),
    .cur_addr(m_addr), .run_algo(m_algo), .last_result(m_last), .prev_result(m_prev), .banks_tested(m_tested),
    .banks_failed(m_failed), .banks_scrubbed(m_scrubbed), .cycles(m_cycles), .ev_start_refused(ev_ref),
    .ev_timeout(ev_tmo), .ev_spurious(ev_spur), .ev_mem_err(ev_merr), .ev_done, .log_pop(c_pop), .ff_valid(ffv),
    .ff_info(ffi), .ff_addr(ffa), .ff_exp(ffe), .ff_obs(ffo), .fail_count(fcnt), .cnt_ovf(cov), .log_level(lvl),
    .log_ovf(lov), .log_info(lgi), .log_addr(lga), .log_synd(lgs));
  sftc_mbist_bank_mux #(.BANK_COUNT(4), .MAX_W(32), .AW(13)) u_mux (.clk, .rst_n, .t_req, .t_we, .t_addr, .t_wdata,
    .t_bank, .t_gnt, .t_rvalid, .t_rdata, .t_rerr, .stray_rvalid(t_stray), .b_req, .b_we, .b_addr, .b_wdata, .b_gnt,
    .b_rvalid, .b_rdata, .b_rerr);
  logic [3:0] sq;
  always_ff @(posedge clk or negedge rst_n) if (!rst_n) sq <= '0; else sq <= m_scrubbed;
  assign scrub_done = m_scrubbed & ~sq;
  always_comb for (int i = 0; i < 4; i++) acq_req[i] = mbist_enable && !mode_busy && c_mask[i] && !protect[i];
  assign done = m_done; assign pass = m_pass;
endmodule

module sftc_var_b (
  input wire logic clk, rst_n, input wire logic [3:0] req, we, input wire logic [127:0] addr, wdata,
  input wire logic [15:0] be, output logic [3:0] gnt, rvalid, err, output logic [127:0] rdata,
  input wire logic [3:0] quiesce_ack, output logic [3:0] quiesce_req,
  input wire logic s_req, s_we, input wire logic [11:0] s_addr, input wire logic [31:0] s_wdata,
  output logic [31:0] s_rdata, output logic s_err, input wire logic test_enable_pin, output logic irq, done, pass
);
  logic sm, se; logic [2:0] md;
  sftc_var_bc #(.WITH_MODE(1'b0)) u (.*, .hw_dbg_en(1'b0), .hw_test_en(1'b0), .scan_mode_pin(1'b0), .scan_en_pin(1'b0),
                                    .scan_mode(sm), .scan_en(se), .mode(md));
endmodule

module sftc_var_c (
  input wire logic clk, rst_n, input wire logic [3:0] req, we, input wire logic [127:0] addr, wdata,
  input wire logic [15:0] be, output logic [3:0] gnt, rvalid, err, output logic [127:0] rdata,
  input wire logic [3:0] quiesce_ack, output logic [3:0] quiesce_req,
  input wire logic s_req, s_we, input wire logic [11:0] s_addr, input wire logic [31:0] s_wdata,
  output logic [31:0] s_rdata, output logic s_err, input wire logic hw_dbg_en, hw_test_en, scan_mode_pin, scan_en_pin,
  output logic irq, done, pass, scan_mode, scan_en, output logic [2:0] mode
);
  sftc_var_bc #(.WITH_MODE(1'b1)) u (.*, .test_enable_pin(1'b0));
endmodule

module sftc_var_d #(parameter bit WITH_DFT = 1'b0, parameter int LOGD = 4, parameter int CNTW = 16) (
  input wire logic clk, rst_n, tck, trst_n, tms, tdi, output logic tdo, tdo_oe,
  input wire logic [3:0] req, we, input wire logic [127:0] addr, wdata,
  input wire logic [15:0] be, output logic [3:0] gnt, rvalid, err, output logic [127:0] rdata,
  input wire logic [3:0] quiesce_ack, output logic [3:0] quiesce_req,
  input wire logic s_req, s_we, input wire logic [11:0] s_addr, input wire logic [31:0] s_wdata,
  output logic s_gnt, output logic [31:0] s_rdata, output logic s_err,
  input wire logic hw_dbg_en, hw_test_en, cpu_halted, scan_mode_pin, scan_en_pin, scan_rst_n_pin,
  output logic irq, tdone, tpass, tfail, scan_mode, scan_en, output logic [2:0] mode
);
  logic [3:0] b_req, b_gnt, b_rvalid, b_rerr, acq_req, scrub_done, owned, dirty, evf, evi, evr;
  logic b_we, mbist_busy, ofc, jm, dm; logic [12:0] b_addr; logic [31:0] b_wdata; logic [127:0] b_rdata;
  logic [11:0] ostate;
  logic rst_int;
  if (WITH_DFT) begin : g_dft
    logic sm2, se2, te, inh, ck; logic [0:0] rdft;
    sftc_dft_ctrl #(.NRST(1)) u_dft (.scan_mode_pin, .scan_en_pin, .scan_rst_n_pin, .hw_test_en, .rst_n_func(rst_n),
      .clk_func(clk), .clk_test(clk), .scan_mode(sm2), .scan_en(se2), .rst_n_dft(rdft), .icg_te(te),
      .mem_inhibit(inh), .clk_out(ck));
    assign rst_int = rdft[0];
  end else begin : g_nodft
    assign rst_int = rst_n;
  end
  sftc_var_banks u_banks (.clk, .rst_n(rst_int), .req, .we, .addr, .wdata, .be, .gnt, .rvalid, .err, .rdata,
    .b_req, .b_we, .b_addr, .b_wdata, .b_gnt, .b_rvalid, .b_rerr, .b_rdata, .acq_req, .scrub_done, .quiesce_ack,
    .fault_clear(ofc), .mbist_busy, .quiesce_req, .owned, .dirty, .ev_fault(evf), .ev_intr(evi), .ev_reinit(evr),
    .ostate);
  sftc_testcore_top #(.BANK_COUNT(4), .MAX_W(32), .MAX_DEPTH(8192), .BANK_WIDTHS({4{8'd32}}),
    .BANK_DEPTHS({4{24'd8192}}), .BANK_FLAGS('0), .LOG_DEPTH(LOGD), .CNT_W(CNTW), .TIMEOUT(1024)) u_tc (
    .tck, .trst_n, .tms, .tdi, .tdo, .tdo_oe, .clk, .rst_n(rst_int), .hw_dbg_en, .hw_test_en, .cpu_halted,
    .scan_mode_pin, .scan_en_pin, .s_req, .s_we, .s_addr, .s_wdata, .s_gnt, .s_rdata, .s_err, .b_req, .b_we, .b_addr,
    .b_wdata, .b_gnt, .b_rvalid, .b_rdata, .b_rerr, .acq_req, .scrub_done, .mbist_busy, .owner_fault_clear(ofc),
    .owner_state(ostate), .owned, .owner_dirty(dirty), .owner_ev_fault(evf), .owner_ev_intrusion(evi),
    .owner_ev_reinit(evr), .mode, .scan_mode, .scan_en, .irq, .test_done_o(tdone), .test_pass_o(tpass),
    .test_fail_o(tfail), .jtag_mode_o(jm), .diag_mode_o(dm));
endmodule

module sftc_var_e (
  input wire logic clk, rst_n, tck, trst_n, tms, tdi, output logic tdo, tdo_oe,
  input wire logic [3:0] req, we, input wire logic [127:0] addr, wdata,
  input wire logic [15:0] be, output logic [3:0] gnt, rvalid, err, output logic [127:0] rdata,
  input wire logic [3:0] quiesce_ack, output logic [3:0] quiesce_req,
  input wire logic s_req, s_we, input wire logic [11:0] s_addr, input wire logic [31:0] s_wdata,
  output logic s_gnt, output logic [31:0] s_rdata, output logic s_err,
  input wire logic hw_dbg_en, hw_test_en, cpu_halted, scan_mode_pin, scan_en_pin, scan_rst_n_pin,
  output logic irq, tdone, tpass, tfail, scan_mode, scan_en, output logic [2:0] mode
);
  sftc_var_d #(.WITH_DFT(1'b1)) u (.*);
endmodule
module sftc_var_dmin (
  input wire logic clk, rst_n, tck, trst_n, tms, tdi, output logic tdo, tdo_oe,
  input wire logic [3:0] req, we, input wire logic [127:0] addr, wdata,
  input wire logic [15:0] be, output logic [3:0] gnt, rvalid, err, output logic [127:0] rdata,
  input wire logic [3:0] quiesce_ack, output logic [3:0] quiesce_req,
  input wire logic s_req, s_we, input wire logic [11:0] s_addr, input wire logic [31:0] s_wdata,
  output logic s_gnt, output logic [31:0] s_rdata, output logic s_err,
  input wire logic hw_dbg_en, hw_test_en, cpu_halted, scan_mode_pin, scan_en_pin, scan_rst_n_pin,
  output logic irq, tdone, tpass, tfail, scan_mode, scan_en, output logic [2:0] mode
);
  sftc_var_d #(.WITH_DFT(1'b0), .LOGD(0), .CNTW(8)) u (.*);
endmodule
`default_nettype wire
