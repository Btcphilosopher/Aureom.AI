#!/usr/bin/env python3
"""Per-test-mode static timing (OpenSTA) of the scan-inserted TestCore netlist
(variant E after OpenROAD DFT) and of the pre-scan netlist in NORMAL mode.
Evidence class: STATIC TIMING, pre-placement, ideal clocks, no parasitics."""
import json, os, re, shutil, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "reports" / "testcore" / "timing"
LIB = ROOT / "third_party" / "pdk" / "sky130_fd_sc_hd__tt_025C_1v80.lib"
STA = os.environ.get("SFTC_STA") or shutil.which("sta")
RUNS = [("normal_prescan", "reports/testcore/synth/E/netlist.v", "sftc_var_e", "testcore_normal.sdc"),
        ("normal", "reports/testcore/dft/scan_netlist.v", "sftc_var_e", "testcore_normal.sdc"),
        ("mbist", "reports/testcore/dft/scan_netlist.v", "sftc_var_e", "testcore_mbist.sdc"),
        ("jtag_access", "reports/testcore/dft/scan_netlist.v", "sftc_var_e", "testcore_jtag.sdc"),
        ("scan_shift", "reports/testcore/dft/scan_netlist.v", "sftc_var_e", "testcore_scan_shift.sdc"),
        ("scan_capture", "reports/testcore/dft/scan_netlist.v", "sftc_var_e", "testcore_scan_capture.sdc")]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    if not STA or not LIB.exists():
        (OUT / "modes.json").write_text(json.dumps({"status": "BLOCKED", "reason": "OpenSTA or liberty missing"}))
        print("[sta] BLOCKED"); return 2
    res = {"evidence_class": "STATIC TIMING (OpenSTA, pre-placement, ideal clocks, no wire parasitics)",
           "sta": subprocess.run([STA, "-version"], capture_output=True, text=True).stdout.strip(), "modes": {}}
    for name, net, top, sdc in RUNS:
        tcl = OUT / f"{name}.tcl"
        tcl.write_text(f"""read_liberty {LIB}
read_verilog {ROOT / net}
link_design {top}
read_sdc {ROOT / 'constraints' / sdc}
puts "SFTC_SETUP"
report_checks -path_delay max -group_path_count 1 -digits 3 -format end
report_wns -digits 3
report_tns -digits 3
puts "SFTC_HOLD"
report_checks -path_delay min -group_path_count 1 -digits 3 -format end
report_worst_slack -min -digits 3
report_check_types -max_slew -max_capacitance -max_fanout -violators
""")
        p = subprocess.run([STA, "-no_init", "-exit", str(tcl)], capture_output=True, text=True, timeout=1800)
        (OUT / f"{name}.rpt").write_text(p.stdout + p.stderr)
        t = p.stdout
        wns = re.search(r"wns (?:max )?(-?[\d.]+)", t); tns = re.search(r"tns (?:max )?(-?[\d.]+)", t)
        hold = re.search(r"worst slack (?:min )?(-?[\d.]+)", t)
        setup_rows = re.findall(r"group (\w+).*?Slack\n-+\n(\S+)\s.*?(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+) \(", t.split("SFTC_HOLD")[0], re.S)
        res["modes"][name] = {"netlist": net, "sdc": sdc, "wns_ns": float(wns.group(1)) if wns else None,
                              "tns_ns": float(tns.group(1)) if tns else None,
                              "worst_hold_slack_ns": float(hold.group(1)) if hold else None,
                              "worst_setup_by_group": {g: float(s) for g, _, _, _, s in setup_rows},
                              "errors": [l for l in (p.stdout + p.stderr).splitlines() if "Error" in l][:5]}
        print(f"[sta] {name:15s} wns={res['modes'][name]['wns_ns']} hold={res['modes'][name]['worst_hold_slack_ns']} "
              f"groups={res['modes'][name]['worst_setup_by_group']}")
    (OUT / "modes.json").write_text(json.dumps(res, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
