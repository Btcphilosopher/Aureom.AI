# FloorplanLab-style placement experiment (OpenROAD, sky130hd, standard cells only):
# floorplan at fixed utilisation, random pins, global + detailed placement; reports
# placed area / utilisation and HPWL.  Env: SFTC_PDK SFTC_NET SFTC_TOP SFTC_TAG SFTC_OUT
set pdk $::env(SFTC_PDK)
read_lef     $pdk/sky130hd.tlef
read_lef     $pdk/sky130_fd_sc_hd_merged.lef
read_liberty $pdk/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog $::env(SFTC_NET)
link_design  $::env(SFTC_TOP)
initialize_floorplan -utilization 45 -aspect_ratio 1.0 -core_space 5 -site unithd
make_tracks
place_pins -hor_layers met3 -ver_layers met2
global_placement -density 0.6 -pad_left 1 -pad_right 1
detailed_placement
check_placement
report_design_area
