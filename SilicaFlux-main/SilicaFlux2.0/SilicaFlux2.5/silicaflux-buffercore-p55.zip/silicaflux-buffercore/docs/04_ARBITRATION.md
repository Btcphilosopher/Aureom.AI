# 04 — Arbitration policy and starvation bounds

Four arbitration points; each is documented, bounded, and checked in simulation.

## 1. SRAM banks (`sfsb_bank_xbar`)

Masters: P0 firmware, P1 NAND controller, P2 H2B write, P3 B2H read, P4 ENC read, P5 ENC write, P6 DEC read,
P7 DEC write. One arbiter per bank, every cycle:

1. **AGED** class: ports whose current request has waited ≥ `AGE_LIMIT` cycles;
2. **HIGH** class: the NAND-controller port (the NAND bus is the scarce, timing-sensitive resource — "NAND
   starvation" is counted separately);
3. **NORMAL** class: all other ports (host, ECC, firmware, GC traffic).

The highest non-empty class wins; round robin inside the class, the pointer moving past the winner only on
acceptance. A request presented to a bank that is not ready keeps its grant (grant lock), so the SRAM library sees a
stable payload.

**Bound.** After initialisation a bank accepts one request per cycle. A waiting request becomes AGED after
`AGE_LIMIT` cycles; among AGED requests round robin serves it within `NP − 1 = 7` other acceptances. Hence every
request is accepted within **`AGE_LIMIT + 7` cycles** (23 with the default 16). The HIGH class can therefore delay a
NORMAL port by at most `AGE_LIMIT` cycles. The testbench measures every port's longest wait continuously and checks
it against the bound in every configuration (`t_arb`); `MAX_WAIT` (perf counter 29) reports the longest wait seen by
hardware. Observed under the mixed workload: 4–6 cycles with 4 banks, ≤ 9 in every swept configuration (docs/06).

## 2. Host port (`sfsb_host_mux`)

H2B (reads) and B2H (writes) share one SFB2 master. The arbiter keeps the current burst owner while it has requests
(at most `MAX_BURST` beats, never across a 4 KiB host boundary), then alternates (round robin). Neither direction
waits more than one burst while the other streams. A presented request is never withdrawn (SFB2 R2).

## 3. Media engines: HOST vs GC (`sfsb_dispatch`)

ENC and DEC each have a HOST queue and a GC queue. **Weighted round robin**: while both queues hold work, at most
`CFG.W_HOST` consecutive HOST descriptors are dispatched before a GC one, and at most `CFG.W_GC` consecutive GC
descriptors before a HOST one (0 is treated as 1; defaults 4 : 1). Work conserving: an empty class never blocks
the other. Garbage collection therefore progresses at ≥ 1/(W_HOST + 1) of the media bandwidth under full host load
(it cannot be starved — the drive cannot run out of free blocks because of host pressure), and host latency is
bounded by W_GC GC descriptors. Checked by `t_arb` (run lengths ≤ W_HOST / W_GC while both classes wait, GC served
before the host queue drains).

## 4. Completions (`sfsb_dispatch`)

Four engines post completions into one CQ through a round-robin arbiter. A full CQ back-pressures the engines
(they hold their completion and accept no new descriptor; `CQ_FULL` stall cycles are counted): completions are never
dropped or reordered within an engine. Checked by `t_backpressure` (CQ held full, then drained: every TID exactly
once).

## 5. Concurrency supported

Host transfers (H2B ∥ B2H), NAND transfers (NAND port), ECC (ENC ∥ DEC), firmware metadata access (FW port to the
buffer, to the CSRs and to the DRAM metadata window) and GC (GC-class ENC/DEC) all run at the same time on
different slots; `t_concurrent` and the `mixed` performance workload run them together.
