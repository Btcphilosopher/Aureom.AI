# 05 — DMA: descriptors, validation, completion contract

## 1. Descriptor (firmware writes DESC0..3, then SUBMIT)

| Register | Bits | Field |
|---|---|---|
| DESC0 | [3:0] | OPC: 1 H2B, 2 B2H, 3 ENC, 4 DEC |
| | [5:4] | CLASS: 0 HOST, 1 GC (H2B/B2H must be HOST) |
| | [7] | CRYPT (ENC/DEC only, requires `CRYPTO_EN`) |
| | [15:8] | TID (transaction ID) |
| | [19:16] | LB_FIRST — first logical block inside the slot / codeword inside the page |
| | [23:20] | LB_COUNT — 1 … PAGE_LBS |
| DESC1 | [7:0] / [15:8] | DSLOT / PSLOT |
| DESC2 | [31:0] | host byte address (H2B/B2H, 8-byte aligned) |
| DESC3 | [31:0] | LBA of the first block (H2B: tag stored with the data; DEC: expected tag) |

Transfers are logical-block granular (the host protocol unit); host transfer length = `LB_COUNT × LB_BYTES`.

## 2. Validation (synchronous, `SUBMIT[7:0]`, first failing check)

`DISABLED` (CFG.EN = 0 or SRAM init running) → `BAD_OPC` → `BAD_CLASS` → `BAD_LEN` (count 0) → `RANGE` (LB range
beyond the page) → `UNSUP` (crypt) → `ALIGN` (host address) → `RANGE` (host range wraps the 32-bit space) → `PWR`
(H2B under power fail) → `DUP_TID` → `QFULL` → source/destination checks of the buffer manager: `SLOT` (index),
`OWNER` (state), `BUSY` (locks), `POISON`, `NOT_VALID` (source blocks hold no valid data). A rejected descriptor
has **no side effect and produces no completion**; `DESC_REJ` counts them.

## 3. Engines, bursts, back-pressure

* Engines issue a read only when its response space is reserved (in-flight + FIFO occupancy < FIFO depth), so SRAM
  and host responses are never refused or lost; every stage handshakes, so back-pressure from any port (host
  memory, banks, CQ) stalls the pipeline without loss or duplication.
* Host bursts: ≤ `MAX_BURST` beats, split at 4 KiB boundaries; `HOST_MAX_OUT` outstanding (1 = rev-2.0 crossbar
  compatible; ≥ 2 point-to-point to a pipelined endpoint — the measured optimisation, docs/06).

## 4. Completion contract

A completion is posted **only after the destination holds the data according to its interface contract**:

| Engine | Destination | Completion after |
|---|---|---|
| H2B | buffer SRAM | every bank write acknowledged (array written) |
| B2H | host memory | every SFB2 write response received (SFB2 R7: response after the write was performed) |
| ENC | page slot | every page-image write acknowledged |
| DEC | data slot | every write acknowledged, metadata entries written |

Completion entry: `CPL0 = {LB_ERR_MASK, STATUS, CLASS, OPC, TID}`, `CPL1 = {ERR_FLAGS, ERASED_MASK,
CORRECTED_BITS}`, `CPL2 = cycles from engine start`. STATUS is the most severe class seen, per engine:
DEC `BUF_PAR` > `META_UE` > `UNCORR` > `LBA` > `CRC` > `ERASED` > `CORRECTED` > `OK`; ENC `BUF_PAR` > `CRC`;
B2H `BUF_PAR` > `CRC` > `HOST_ERR`; H2B `HOST_ERR` > `BUF_PAR`. The flags word (CPL1[31:24]) reports every error
class seen and `LB_ERR_MASK` names the failed blocks.
Firmware pops with `CPL_POP`; the TID becomes reusable at that moment.

## 5. Error handling

| Error | Detected | Effect |
|---|---|---|
| host bus error (read) | H2B response | block(s) stay not VALID, `HOST_ERR` |
| host bus error (write) | B2H write response | `HOST_ERR` |
| SRAM parity | any read | `BUF_PAR`, block POISONED (B2H), page BAD (ENC) |
| CRC / LBA mismatch | V1 / V2 / V3 | `CRC` / `LBA`; POISONED (V2, V3) or page BAD (V1) |
| ECC uncorrectable | DEC | `UNCORR` / `META_UE`, POISONED |
| erased codeword | DEC | `ERASED` (not an error), block not VALID |
| ownership violation | FW / NAND port | SFB2 error response, no buffer access |

Every engine always completes the full transfer length (data words of failed blocks are still moved while the slot
is locked), so transfer bookkeeping never depends on data content, and every accepted descriptor completes exactly
once (proved in every regression run; the mutation campaign in `reports/mutation.md` includes a
premature-completion mutant).
