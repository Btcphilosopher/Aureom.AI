# 09 — Limitations (what is not claimed)

* **Simulation and synthesis estimates only.** RTL simulation (Verilator 5.020, Icarus 12) and Yosys 0.33 logic
  synthesis. Nothing ran on an FPGA board or silicon; no place-and-route, no timing closure, no power numbers.
* **ECC is not NAND-grade.** The codeword framing is real, but the inner code is the RAS (P26) SECDED: one bit per
  64-bit beat corrected, two detected. Real NAND needs BCH/LDPC (tens of bits per KiB). No such engine exists in the
  repository and none was invented; the per-codeword framing, ECC input/output buffering and status reporting are
  the integration point. Miscorrection of ≥ 3-bit errors is caught by the end-to-end CRC (V2), not by the ECC.
* **No encryption.** `CRYPTO_EN` is a keyed XOR placeholder, explicitly not a cipher. It proves the pipeline
  position and integrity contract only. The plaintext CRC stored in the OOB would leak information in a real
  encrypted drive.
* **Buffer SRAM protection is detect-only.** Per-byte parity + end-to-end CRC detect corruption; nothing corrects
  it. Corrupted *clean* data can be re-read from NAND; corrupted *dirty* data is lost (reported, poisoned). A SECDED
  buffer (P26 `sfras_sfb_ecc_slave`) would correct single-bit soft errors at the cost of read-modify-write on partial
  writes; not done.
* **B2H streams.** On a V3 (egress) failure the host buffer already holds the corrupted data; the completion status
  reports it (NVMe convention). A store-and-forward egress buffer would prevent it.
* **No PCIe / NVMe.** The host side is an SFB2 master to a host-memory model. Host transfers are logical-block
  granular; no PRP/SGL, no sub-block host transfers, 32-bit host addresses.
* **No DDR controller or PHY.** The DRAM adapter targets the MemoryBridge (P24) upstream port; verification uses
  P24's *simulated* controller. Data slots always live in on-chip SRAM; only firmware metadata uses DRAM.
* **NAND.** Verified against the NANDLab behavioural model through FlashLink (both from this repository), not
  against a vendor model or a physical device; ONFI compliance is not claimed (P53's own limitation). The NAND port
  serves one transaction at a time (≥ 4 cycles per 8-byte beat ≈ 200 MB/s at 100 MHz) — enough for one ONFI SDR
  channel (P53: ≤ 33 MB/s), a bottleneck for many channels (docs/06).
* **Firmware.** No firmware/FTL is delivered; the testbench plays the firmware. A compile-checked usage example is
  in `sw/example/`. Integration under the ControlCore (P21) is by register/port compatibility (SFB2 slave, 32-bit),
  not simulated here.
* **Scale.** Slot bookkeeping and metadata are flip-flops (fine for tens of slots); a multi-megabyte buffer would
  move metadata into SRAM and the read-cache CAM into a hash.
* **Reset** discards buffer contents; power-loss survival requires PLP energy and firmware draining.
* No formal proofs were run for the new RTL; the arbitration bound is argued (docs/04) and checked in simulation.
