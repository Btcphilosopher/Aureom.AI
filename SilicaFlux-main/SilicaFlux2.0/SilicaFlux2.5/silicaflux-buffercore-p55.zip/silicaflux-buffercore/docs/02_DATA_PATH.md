# 02 — Data paths, ECC framing and end-to-end integrity

## 1. Paths

```
WRITE   host memory ─H2B─► data slot ─ENC─► [V1 CRC] ─► [crypt] ─► ECC encode ─► page slot ─NAND port─► NAND PROGRAM
            (G1: CRC32C generated)                                               (S: OOB {CRC32C, LBA} written)

READ    NAND READ_PAGE ─NAND port─► page slot ─DEC─► ECC decode ─► [crypt] ─► [V2 CRC + LBA] ─► data slot ─B2H─► [V3 CRC] ─► host
```

All four engines run concurrently on different slots; each engine is internally pipelined (reader → stage →
writer) with valid/ready between stages.

## 2. Page image (page slot / NAND page), 64-bit beats

```
codeword j (j = 0 .. PAGE_LBS-1), CWB = LB_BEATS + LB_BEATS/8 beats each:
  [ j*CWB              , j*CWB + LB_BEATS )   data beats (systematic: the stored/encrypted payload)
  [ j*CWB + LB_BEATS   , (j+1)*CWB        )   check-byte beats: byte i%8 of beat i/8 = SECDED check byte of data beat i
OOB  = PAGE_LBS*CWB:
  OOB + j                                     metadata beat j = { CRC32C[63:32], LBA[31:0] } of logical block j
  OOB + PAGE_LBS                              OOB parity beat: byte j = SECDED check byte of metadata beat j
```

* Default (LB 512, 4 per page): 4 × (64 + 8) + 5 = 293 beats = 2344 bytes. Integration (LB 128): 616 bytes, fitting a
  512 + 128-byte NAND page.
* The page image is laid out codeword by codeword (each codeword contiguous: its data, then its check bytes), so
  every **codeword boundary** is a beat-aligned unit that can be read, decoded and reported on its own: DEC accepts
  any `LB_FIRST/LB_COUNT` subset (partial-page reads decode only the requested codewords).
* ECC inner code: P26 SECDED (72,64) per beat: 1 bit corrected, 2 bits detected, ≥ 3 bits may alias (handled by V2).
  ECC overhead 12.5 %, + 40 bytes of OOB metadata for 4 blocks.
* **Erased pages.** The check-bit inversion mask makes the all-ones 72-bit word a valid codeword, so an erased page
  decodes without error; DEC recognises it by all-ones metadata (after correction) and reports `ERASED` (block not
  VALID, not POISON) instead of an ECC failure.

## 3. ECC input / output buffers

| Buffer | Where | Size |
|---|---|---|
| ECC encoder input | ENC reader FIFO (`ENG_FIFO` beats) fed from the data slot | 8 × 65 bit |
| ECC encoder output | ENC write queue (4 entries) → page slot; check bytes accumulate in an 8-byte register and are written every 8 data beats | 4 × (addr + 72 bit) |
| ECC decoder input | the page slot itself (random access: check bytes are fetched **before** the data they protect) + the check-byte staging buffer (`PAR_BEATS` × 64 bit) + the DEC reader FIFO | 8 × 64 bit (LB 512) |
| ECC decoder output | DEC write queue → data slot | 4 × (addr + 64 bit) |

## 4. Integrity: where check values are generated, stored and verified

| Point | Stage | What | On failure |
|---|---|---|---|
| **G1** generate | H2B, as each beat enters the buffer | CRC-32C (Castagnoli, reflected 0x82F63B78, init/final 0xFFFFFFFF) over the logical block; stored in the metadata buffer with the block's LBA | — |
| **P** every SRAM read | bank wrapper | odd parity per byte lane (all engines check all lanes; FW port checks the lanes it returns; DEC checks only lane *j* of the OOB parity beat) | `BUF_PAR` status, block POISONED; FW/NAND port: `rsp_error`, data 0 |
| **V1** verify before encode | ENC, on the beats read from the data slot | recomputed CRC == metadata CRC | `CRC` status; the page slot is marked **BAD** and `P2NAND` is refused (`BAD_PAGE`): corrupted data is never handed to the NAND controller |
| **S** store | ENC | the **original** G1 value (from metadata, never a recomputed one) + LBA written to OOB beat *j*, itself SECDED-protected | — |
| **E** medium | DEC | per-beat SECDED: corrects 1, detects 2 | `UNCORR` (or `META_UE`), block POISONED |
| **V2** verify after decode | DEC, on plaintext after ECC correction and decryption | recomputed CRC == OOB CRC **and** OOB LBA == expected LBA (descriptor LBA + block offset) | `CRC` / `LBA` status, block POISONED. Catches ECC miscorrection (≥ 3 errors), misdirected / stale pages and wrong crypt keys |
| **V3** verify on egress | B2H, on the beats leaving the buffer | recomputed CRC == metadata CRC (+ lane parity) | `CRC` / `BUF_PAR` status, block POISONED |

**Containment.** A POISONED block can never be the source of B2H or ENC (submission rejected with `POISON`).
Because B2H streams (no store-and-forward), a V3 failure is reported in the completion after the data reached host
memory; as in NVMe, host data is undefined when the completion status is not OK (docs/09).

**Payload ↔ metadata association under stalls.**
* within an engine, every beat and its position travel through the same valid/ready handshakes (FIFO entries carry
  data + lane errors; counters advance only on handshakes), so no stall can shift a beat against its block index;
* block identity on the medium is checked (V2 LBA tag), and in the buffer by the metadata entry indexed by
  (slot, block);
* transaction tags: every descriptor carries an 8-bit TID; its completion carries the same TID; a TID cannot be
  reused until its completion was popped (`DUP_TID`), and the testbench proves exactly-once completion.

Verified by: `t_basic` (OOB holds the independently computed CRC), `t_ecc` (single/double/triple errors, metadata
errors, misdirected read, erased page), `t_corrupt` (parity, parity-invisible corruption caught at V1 and V3, BAD
page refused), `t_crypt` (wrong key caught at V2), and the DoD integration bench.

## 5. Optional crypt stage (placeholder)

`CRYPTO_EN = 1` inserts a keyed XOR keystream `ks(KEY, LBA, beat)` between the CRC and the ECC on the write path and
between the ECC and the CRC on the read path (descriptor flag `CRYPT`, key in `KEY_LO/HI`). **It is not a cipher.**
It demonstrates the pipeline contract an AES-XTS engine must satisfy: integrity values are computed on plaintext,
ECC protects what is stored, the medium never holds the plaintext, and a wrong key is detected (V2) rather than
returning garbage. Note for a real design: the plaintext CRC stored in the OOB leaks 32 bits per block; an
encrypted-drive design would encrypt the OOB metadata as well or use a keyed check value.
