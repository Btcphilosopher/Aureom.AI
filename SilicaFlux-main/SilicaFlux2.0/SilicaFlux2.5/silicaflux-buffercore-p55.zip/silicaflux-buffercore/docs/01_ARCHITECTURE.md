# 01 — Architecture

```
                         silicaflux_storage_buffer  (one clock domain, rst_n async-assert / sync-release)
  ┌──────────────────────────────────────────────────────────────────────────────────────────────────────┐
  │  ControlCore ──SFB2 32b──► sfsb_fw_port ── CSR (DESC/SUBMIT, CQ, slot cmds, FI, perf) ─┐              │
  │                             │  BUF window (ownership-checked) ───────────────────── P0 │              │
  │                             └─ DRAM window ─► sfsb_meta_cache ──SFB2 64b──► ext. DRAM bridge (P24)    │
  │                                                                                        ▼              │
  │                          sfsb_dispatch: validate → queues (H2B, B2H, ENC×{HOST,GC}, DEC×{HOST,GC})    │
  │                                         → WRR → engines → completion queue (TIDs)                     │
  │                                                     │ locks / metadata                                │
  │                          sfsb_slot_mgr (buffer manager): slot states, locks, DIRTY, metadata buffer,  │
  │                                         clean read cache + LRU eviction, port access checks           │
  │                                                                                                       │
  │  host memory ◄─SFB2 64b─ sfsb_host_mux ◄─► sfsb_eng_h2b (G1) ──────────────────────── P2 (W)          │
  │                                       ◄─► sfsb_eng_b2h (V3) ──────────────────────── P3 (R)           │
  │                                         sfsb_eng_enc: V1 → crypt → ECC enc ──── P4 (R data) P5 (W page)│
  │                                         sfsb_eng_dec: ECC dec → crypt → V2 ──── P6 (R page) P7 (W data)│
  │  NAND ctrl (P53) ─SFB2 64b─► sfsb_nand_port (NAND-owned page slots only) ─────────── P1 (HIGH class)  │
  │                                                                                                       │
  │           P0..P7 ──► sfsb_bank_xbar: per-bank arbiter (aging > HIGH > NORMAL, round robin)            │
  │                        └─► NUM_BANKS × sfsb_sram_bank (sram_sp 72-bit, odd parity per byte, init, FI)  │
  │  sfsb_perf: 38 counters                                                                               │
  └──────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

## 1. Modules

| Module | Role |
|---|---|
| `silicaflux_storage_buffer` | top: parameters, derived geometry, port wiring, power-fail synchroniser, perf event vector |
| `sfsb_sram_bank` | **memory wrapper**: SRAM-library `sram_sp` (72-bit, 8 × 9-bit lanes), per-byte odd parity, power-up initialisation sweep, write fault injection |
| `sfsb_bank_xbar` | 8 master ports × `NUM_BANKS` banks, low-order interleave, per-bank arbiter with aging + priority class, grant lock, response routing by ID |
| `sfsb_slot_mgr` | **buffer manager**: data/page slot state machines, reader/writer locks, DIRTY, metadata buffer (VALID/POISON/LBA/CRC per logical block), read cache (lookup, coherence, LRU eviction), FW/NAND port access checks |
| `sfsb_dispatch` | descriptor validation, per-engine queues, HOST/GC weighted round robin, completion arbiter + queue, TID tracking |
| `sfsb_eng_h2b` | host ingress DMA (integrity point G1) |
| `sfsb_eng_b2h` | host egress DMA (integrity point V3) |
| `sfsb_eng_enc` | write path: page assembly (V1, crypt, ECC encode, OOB metadata) |
| `sfsb_eng_dec` | read path: ECC decode, crypt, V2 (CRC + LBA), poison containment |
| `sfsb_ecc_enc64` / `sfsb_ecc_dec64` | inner code: RAS SECDED (72,64) with NAND erased-page inversion |
| `sfsb_host_mux` | host-memory DMA adapter: SFB2 master, burst-preferring arbitration, configurable outstanding limit |
| `sfsb_nand_port` | NAND-controller DMA adapter: SFB2 slave for FlashLink's `sfnc_buf_master` |
| `sfsb_fw_port` | ControlCore port: CSR file, buffer window, DRAM window |
| `sfsb_meta_cache` | external-DRAM adapter + write-through metadata cache |
| `sfsb_perf` | performance counters (38 used of 40 slots) |
| `sfsb_fifo` | show-ahead FIFO primitive |

## 2. Parameters

| Parameter | Default | Range | Meaning |
|---|---|---|---|
| `NUM_BANKS` | 4 | 2, 4, 8 | SRAM banks (word interleaved) |
| `LB_BYTES` | 512 | 64 … 4096, power of two | logical block = ECC codeword payload |
| `PAGE_LBS` | 4 | 1, 2, 4, 8 | logical blocks (codewords) per NAND page |
| `NUM_DSLOTS` / `NUM_PSLOTS` | 8 / 4 | 1 … 32 | data slots / page slots |
| `DQ_DEPTH` / `CQ_DEPTH` | 4 / 8 | power of two | descriptor queue per engine and class / completion queue |
| `ENG_FIFO` | 8 | power of two ≥ 2 | engine read FIFO (ECC input buffer) |
| `HOST_MAX_OUT` | 1 | 1 … 16 | host-port outstanding transactions (1 = SFB2 rev-2.0 crossbar rule) |
| `MAX_BURST` | 16 | ≥ 1 | host burst length (beats) |
| `AGE_LIMIT` | 16 | 1 … 60000 | bank-arbiter aging threshold (cycles) |
| `CRYPTO_EN` | 1 | 0/1 | crypt placeholder stage |
| `EXT_DRAM_EN`, `MC_SETS`, `DRAM_WIN`, `DRAM_BASE` | 0, 16, 1 MiB, 0x8000_0000 | | external-DRAM metadata window + cache |
| `ND_BASE` | 0 | | NAND-port byte address of buffer word 0 |
| `PLP_PRESENT` | 0 | 0/1 | power-loss-protection energy exists (affects only the early-ack permission bit) |
| `PERF_EN` | 1 | 0/1 | performance counters |
| `SRAM_BACKEND`, `SRAM_MACRO` | generic, 0 | sramlib | memory implementation |

Derived (64-bit words): `LB_BEATS = LB_BYTES/8`, `PAR_BEATS = LB_BEATS/8`, codeword `CWB = LB_BEATS + PAR_BEATS`,
data slot `DSLOT_BEATS = PAGE_LBS·LB_BEATS`, page image `PIMG_BEATS = PAGE_LBS·CWB + PAGE_LBS + 1`, page slot stride
`PSLOT_BEATS = PIMG_BEATS` rounded up to `NUM_BANKS`, `PS_BASE = NUM_DSLOTS·DSLOT_BEATS`,
`TOTAL_BEATS = PS_BASE + NUM_PSLOTS·PSLOT_BEATS`, `BANK_DEPTH = ⌈TOTAL_BEATS / NUM_BANKS⌉`.
Illegal parameter sets stop elaboration in Verilator, Icarus and Yosys (`reports/lint.md`).

| Configuration | Buffer data | Banks × depth × 72 b | Page image |
|---|---|---|---|
| small (starting point): 2 banks, LB 128, 4 data + 3 page slots | 3.8 KiB | 2 × 245 | 616 B |
| base (default): 4 banks, LB 512, 8 data + 4 page slots | 25.25 KiB | 4 × 808 | 2344 B |

## 3. Memory organisation

Word address `wa` (64-bit words) → bank `wa[log2 NB − 1:0]`, row `wa >> log2 NB`. Low-order interleave makes every
sequential stream rotate over all banks, so up to `NUM_BANKS` streams proceed per cycle and no single stream is
bank-bound.

* **Data slots** `[0, PS_BASE)`: `NUM_DSLOTS` × `PAGE_LBS` logical blocks of plaintext — the host ingress buffer, host
  egress buffer (read buffering), GC staging and the clean read cache are all data slots in different ownership
  states.
* **Page slots** `[PS_BASE, TOTAL_BEATS)`: NAND page images = the **NAND page buffer**, which is also the ECC encoder's
  output buffer and the ECC decoder's input buffer (docs/02).
* **Metadata buffer** (in `sfsb_slot_mgr`): one entry per data-slot logical block: `{VALID, POISON, LBA[31:0], CRC32C[31:0]}`.
* **Firmware access**: the BUF window maps the whole buffer for direct 32-bit load/store, ownership-checked.

Memory-port limitations used: each bank is a single-port (1RW) SRAM, one access per cycle, read latency 1, no
response back-pressure; byte enables are lane masks (no read-modify-write); writes are acknowledged after the
array is written.

## 4. External interfaces

| Port | Direction | Protocol | Notes |
|---|---|---|---|
| `fw_*` | slave | SFB2 rev 2.0, 32-bit | windows at offsets 0x000000 (CSR), 0x100000 (BUF), 0x800000 (DRAM) |
| `nd_*` | slave | SFB2 rev 2.0, 64-bit | FlashLink `sfnc_buf_master` (`BUF_DW = 64`) |
| `hm_*` | master | SFB2 rev 2.0, 64-bit | host memory (a PCIe DMA endpoint would sit here); `HOST_MAX_OUT` outstanding |
| `xm_*` | master | SFB2 rev 2.0, 64-bit | MemoryBridge P24 upstream port with `id = 0, len = 0, last = 1` |
| `pwr_fail_i` | in | async | 2-flop synchronised |
| `irq`, `busy`, `init_done`, `plp_dirty` | out | | `plp_dirty` = volatile host data present |

## 5. Clock and reset

One clock. `rst_n` resets every state machine, empties all queues (no completion is produced for a descriptor
cancelled by reset — SFB2 R11 semantics), frees every slot and re-runs the SRAM initialisation sweep (`BANK_DEPTH`
cycles, `init_done`; descriptors are refused with `DISABLED` until it completes). The buffer is volatile: data in it
does not survive a reset; durability is only ever claimed after a NAND program (docs/03 §5).
