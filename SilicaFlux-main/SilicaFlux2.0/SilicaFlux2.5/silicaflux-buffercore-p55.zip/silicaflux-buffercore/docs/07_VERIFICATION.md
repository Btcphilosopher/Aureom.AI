# 07 — Verification

## 1. Environment

| Bench | DUT surroundings | Purpose |
|---|---|---|
| `tb/tb_sfsb.sv` (+ `sfsb_tb_common.svh`, `sfsb_tb_mem.sv`) | firmware BFM on the FW port; NAND-controller BFM on the NAND port (flash array, bit-error injection, random stalls); host-memory model (random back-pressure / latency, error window, per-word write counters); DRAM model | 16 scenario tests, all configurations |
| `tb/tb_sfsb_nand.sv` | **real, unmodified** FlashLink P53 controller (`BUF_DW = 64`) + `sfnc_io_sdr` + NANDLab P52 device + `sfnc_onfi_monitor`; **real** MemoryBridge P24 + `extmem_sim_mc` + `extmem_mc_checker` | definition of done |

Checkers active in every run:
* DataFabric `sfb_protocol_checker` (unmodified) on the FW, NAND, host and DRAM SFB2 ports (R2, R4, R5, R6, R8, X);
* golden model: every block's data is a function of (LBA, beat, version); host buffers are compared word by word,
  and every host word must have been written **exactly once** (no duplicated or dropped beats);
* an independent CRC-32C in the testbench (checked against the standard "123456789" vector) verifies the check
  values the DUT stores (metadata, NAND OOB);
* scoreboard: each accepted descriptor must complete exactly once with its TID; rejected ones never complete;
* **commit monitor**: at every completion the engine's destination writes must all be issued and acknowledged
  (SRAM write acks / host write responses) and equal the transfer length;
* arbitration monitor: every port's wait ≤ `AGE_LIMIT + 7`;
* leak check after every test: no slot allocated, nothing DIRTY, subsystem idle;
* RTL-embedded simulation checks: FIFO overflow/underflow, unsolicited host response, two bank responses to one
  port, metadata update without the lock, lock release without the lock, reader-count underflow, commit of a
  rejected submission;
* integration bench: NANDLab protocol errors and AC-timing violations = 0, ONFI pin monitor violations = 0,
  MemoryBridge controller-interface violations = 0.

## 2. Required tests → where

| Requirement (brief §10) | Test(s) | What is checked |
|---|---|---|
| Multiple simultaneous transfers | `t_concurrent`, `t_perf mixed`, backpressure overlap stress | H2B ∥ DEC ∥ ENC ∥ B2H ∥ NAND program in one window (≥ 3 engines active in the same cycle), all data correct |
| Partial blocks | `t_partial` | 1-block page, read-modify-write (old page DEC + host block merge + re-encode), single-codeword reads, a partial DEC does not validate the other blocks |
| Backpressure | `t_backpressure`, `t_random` | host ready 15–35 %, latency up to 24, NAND stalls 40 %, CQ held full (no completion lost), host read ∥ write overlap stress, stuck-request R2 scenario |
| Buffer exhaustion | `t_exhaust`, `t_invalid` | ALLOC_D/ALLOC_P → NOSPACE, LRU eviction of a clean cached slot, QFULL |
| Concurrent reads/writes | `t_concurrent`, `t_backpressure` | H2B and B2H on the host port together; readers share, writers exclusive (BUSY) |
| Reset | `t_reset` | reset during a slow H2B and during NAND-port writes: no stale or late completion, all slots free, STATUS clean, full function afterwards |
| Invalid descriptors | `t_invalid` | every submission code (DISABLED, BAD_OPC, BAD_CLASS, BAD_LEN, RANGE ×2, UNSUP, ALIGN, SLOT ×2, OWNER ×2, NOT_VALID ×2, BUSY ×2, DUP_TID, QFULL, PWR), no completion for any |
| ECC errors | `t_ecc`, integration | 1-bit errors in data, check bytes and OOB (CORRECTED, exact count), 2-bit (UNCORR, block mask, POISON, B2H refused), metadata 2-bit (META_UE), erased page, medium errors through the real NAND controller |
| Data corruption detection | `t_corrupt`, `t_ecc`, `t_crypt` | SRAM 1-bit (parity → BUF_PAR, FW-port error), 2-bit in one lane (parity-invisible → CRC at V3, at V1 + BAD page refused), page-buffer corruption during a NAND read (BUF_PAR at DEC), NAND port refuses a corrupted beat, ECC miscorrection (3 aliasing errors → CRC at V2), misdirected page (LBA), wrong crypt key (CRC) |
| No duplicated or dropped transfers | every test | exactly-once completions per TID, exactly-once host word writes, commit monitor |
| plus: ownership | `t_owner` | FW/NAND port access rules, FREE of locked / dirty slots |
| plus: caching | `t_cache` | read-cache hit, coherence on host write, TRIM invalidation, dirty refused, metadata cache hits/misses/write-through/error-not-cached/invalidate |
| plus: durability | `t_durable`, integration | DIRTY accounting, early-ack permission, power-fail refuses H2B but drains, DIRTY kept after a real NAND program failure |
| plus: arbitration | `t_arb` | wait bound on every port, HOST/GC WRR run lengths, GC not starved |
| plus: registers | `t_regs` | ID/params, error responses (unmapped, sub-word CSR, misaligned, absent DRAM window) |

## 3. Configurations

`base`, `small`, `wide` (8 banks, 256-byte blocks, 8 blocks per page), `lb64` (64-byte blocks: one check-byte beat
per codeword), `mo4` (4 outstanding host transactions), `dram` (external DRAM + metadata cache), `nocrypt`,
`plp` (PLP present, AGE_LIMIT 4). Results: `reports/regression.md`.

### Results (final run, `reports/regression.md`)

15 / 15 runs PASS, 171,246 checks: Verilator base (seeds 1–3), small, wide, lb64, mo4 (seeds 1–2), dram, nocrypt,
plp; Icarus small and base; the DoD integration bench on Verilator and Icarus. 0 SFB2 protocol violations in every
run, commit monitor 167 / 167 completions clean (base).

## 4. Mutation testing

`scripts/mutate.py` applies 15 single deliberate design bugs (one per run) to a scratch copy and runs the suite;
results in `reports/mutation.md`. The first campaign left two mutants alive — a premature H2B completion and a
host-port arbiter that could switch a presented request — exposing two real verification gaps. They were closed by
the commit monitor and by a directed stuck-request scenario (plus an overlap stress loop); the final campaign is the
one reported.

## 5. Problems found during verification

| Found by | Problem | Fix |
|---|---|---|
| review before the first simulation | ENC wrote the last check-byte beat of each codeword to index −1 (beat counter wrap) | index from `bib − 1` |
| Verilator `-Wall` | width mismatches (host-address adders, perf pop-counts), slot indices wider than the arrays | explicit widths; arrays padded to a power of two |
| integration bench | FlashLink resets with `WP_N = 0`, so program/erase were (correctly) refused | firmware sets CTRL.WP_N (as P53's own bench does) |
| integration bench | MemoryBridge sim controller's `tb_rsp_pct` left unconnected → never responded (testbench wiring) | connected, plus P24's own MC checker |
| mutation testing | 2 verification gaps (above) | commit monitor, directed R2 scenario |
| Icarus 12 | no `break`/task `return`, crashes on outputs written to elements of automatic arrays, `longint` compare in continuous assigns | testbench restructured (module-scope arrays, flags) |
| Verilator 5.020 | inlines every task into its caller (one 36 MB C++ function) | bus BFMs as server processes; one suite binary + one perf binary |

No functional RTL bug was found by simulation after the first build; all simulation failures were testbench or
environment issues listed above. The mutation results are the evidence that the tests can find RTL bugs.

## 6. Not verified

No formal proofs for the new RTL; no gate-level simulation; no FPGA board; no ControlCore-in-the-loop firmware
simulation (the testbench plays the firmware); NAND only through NANDLab + FlashLink (docs/09).
