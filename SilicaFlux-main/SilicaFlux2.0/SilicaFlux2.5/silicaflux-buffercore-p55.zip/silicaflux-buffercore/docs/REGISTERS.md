# Firmware register map (CSR window, offset 0x000000)

Single source of truth: `rtl/sfsb_defs.svh` → C header `sw/include/sfsb_regs.h` (`scripts/gen_header.py`).
All registers are 32-bit; CSR writes must use all four byte strobes (sub-word writes and unmapped offsets get an
SFB2 error response). Windows: CSR `0x000000`, buffer `0x100000` (+ byte address of a buffer word), DRAM
`0x800000` (`EXT_DRAM_EN`).

| Offset | Name | Access | Fields |
|---|---|---|---|
| 0x000 | ID | RO | `0x53465342` ("SFSB") |
| 0x004 | VERSION | RO | `0x37010000` ([31:24] = 55 project, [23:16] major) |
| 0x008 | PARAM0 | RO | [7:0] NUM_DSLOTS, [15:8] NUM_PSLOTS, [19:16] log2 NUM_BANKS, [23:20] PAGE_LBS, [27:24] log2 LB_BYTES, [28] CRYPTO_EN, [29] EXT_DRAM_EN, [30] PLP_PRESENT |
| 0x00C | PARAM1 | RO | [15:0] page-slot stride (beats), [31:16] page-image beats |
| 0x010 | PARAM2 | RO | byte address of page slot 0 |
| 0x014 | PARAM3 | RO | buffer size in bytes |
| 0x020 | CFG | RW | [0] EN, [1] IRQ_EN, [2] WCE (host enabled a volatile write cache), [15:8] W_HOST, [23:16] W_GC (reset 0, 0, 0, 4, 1) |
| 0x024 | STATUS | RO | [0] init_done, [1] power fail, [2] busy, [3] early_ack_ok = WCE \| PLP_PRESENT, [23:16] DIRTY data slots, [31:24] CQ entries |
| 0x028 | OCC | RO | [7:0] data slots allocated, [15:8] cached, [23:16] page slots allocated, [31:24] page slots owned by NAND |
| 0x030 / 0x034 | KEY_LO / KEY_HI | WO | crypt key (placeholder transform) |
| 0x040–0x04C | DESC0..3 | RW | descriptor (docs/05) |
| 0x050 | SUBMIT | W: submit; R | [7:0] last submission code (SFSB_SUB_*), [8] accepted |
| 0x060 | CPL_STAT | RO | [0] CQ not empty, [15:8] entries |
| 0x064 / 0x068 / 0x06C | CPL0 / CPL1 / CPL2 | RO | head completion (0 when empty) |
| 0x070 | CPL_POP | WO | pop the head completion (its TID becomes reusable) |
| 0x080 | SCMD | WO | [3:0] command (SFSB_SC_*), [15:8] slot, [16] flag (FREE_D: DISCARD) |
| 0x084 | SRSP | RO | [7:0] result (SFSB_SR_*), [15:8] slot (ALLOC / LOOKUP), [16] hit (LOOKUP) / evicted (ALLOC_D), [23:20] block (LOOKUP) |
| 0x088 / 0x08C | SARG_LBA / SARG_CNT | RW | LOOKUP / INVAL arguments |
| 0x090 | MSEL | RW | [7:0] data slot, [11:8] block → MLBA / MCRC / MFLAGS |
| 0x094 / 0x098 | MLBA / MCRC | RO | metadata entry |
| 0x09C | MFLAGS | RO | [0] VALID, [1] POISON, [5:4] slot state, [6] DIRTY, [7] write lock, [12:8] readers |
| 0x0A0 / 0x0A4 | PSEL / PINFO | RW / RO | page slot: [1:0] state, [2] write lock, [3] BAD, [7:4] readers |
| 0x0B0 | FI_CTRL | RW | [0] arm (self-clears when fired), [1] fired (sticky; cleared by a write), [15:8] bank |
| 0x0B4 | FI_ROW | RW | bank row |
| 0x0B8–0x0C0 | FI_MASK0..2 | RW | 72-bit XOR mask applied to the stored word (lane l = bits [9l+8:9l], bit 8 = parity) |
| 0x0D0 | MC_CTRL | WO | [0] invalidate the metadata cache |
| 0x100 | PERF_CTRL | RW | [0] clear (W), [1] freeze |
| 0x200 + 4i | PERF[i] | RO | counter i (table below) |

## Slot commands

| Code | Command | Result codes |
|---|---|---|
| 1 | ALLOC_D | OK (SRSP.slot, .hit = evicted a cached slot), NOSPACE |
| 2 | FREE_D (flag = DISCARD) | OK, RANGE, STATE, BUSY, DIRTY |
| 3 | COMMIT_D | OK, RANGE, STATE, BUSY |
| 4 | CACHE_D | OK, RANGE, STATE, BUSY, DIRTY |
| 5 | CLAIM_D | OK, RANGE, STATE |
| 6 | LOOKUP (SARG_LBA) | OK (hit), MISS |
| 7 | INVAL (SARG_LBA, SARG_CNT) | OK |
| 8 | ALLOC_P | OK, NOSPACE |
| 9 | FREE_P | OK, RANGE, STATE, BUSY |
| 10 | P2NAND | OK, RANGE, STATE, BUSY, BAD_PAGE |
| 11 | P2FW | OK, RANGE, STATE |

## Performance counters (32-bit, saturating; indices 30–31 are reserved and read 0)

| i | Counter | i | Counter |
|---|---|---|---|
| 0 | cycles | 16 | NAND starvation: NAND-port request waiting for a bank |
| 1 | SRAM read beats (all banks) | 17 | NAND-port beats |
| 2 | SRAM write beats | 18 | host request wait (valid && !ready) |
| 3 | occupancy integral (allocated slots per cycle) | 19 | host response wait (outstanding, no response) |
| 4 | peak allocated slots | 20 | engine waiting on a full completion queue |
| 5 / 6 | H2B beats / active cycles | 21 / 22 / 23 | descriptors accepted / completed / rejected |
| 7 / 8 | B2H beats / active cycles | 24 / 25 / 26 | cache lookups / hits / evictions |
| 9 / 10 | ENC beats / active cycles | 27 / 28 | metadata-cache hits / misses |
| 11 / 12 | DEC beats / active cycles | 29 | longest bank-arbitration wait of an accepted request |
| 13 | arbitration stall cycles (sum over ports) | 32 … 39 | per-port stall cycles: FW, NAND, H2B, B2H, ENC-R, ENC-W, DEC-R, DEC-W |
| 14 | ECC wait: ENC/DEC stage starved of input | | |
| 15 | ECC queue wait: media descriptor queued while its engine is busy | | |
