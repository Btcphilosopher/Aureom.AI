# 03 — Buffer manager: ownership, metadata, caching, durability

## 1. Slot state machines

```
data slot:   FREE ──ALLOC_D──► FW ──CACHE_D (clean only)──► CACHED ──CLAIM_D──► FW
               ▲                │ ◄──────────────── ALLOC_D (LRU eviction of an unlocked CACHED slot) ──┘
               └────FREE_D──────┘   (refused if locked; refused if DIRTY unless DISCARD)

page slot:   FREE ──ALLOC_P──► FW ──P2NAND (not BAD, not locked)──► NAND ──P2FW──► FW ──FREE_P──► FREE
```

Locks are taken at **descriptor submission** (`sub_commit`) and released in the cycle the descriptor's completion
enters the completion queue:

| Descriptor | Data slot | Page slot | Allowed data-slot states | Side effects at submission |
|---|---|---|---|---|
| H2B | write lock | — | FW | DIRTY := 1; target blocks VALID := 0; cached copies of the LBA range invalidated |
| B2H | read lock | — | FW, CACHED | — |
| ENC | read lock | write lock | FW, CACHED / page FW | page BAD := 0 |
| DEC | write lock | read lock | FW / page FW | target blocks VALID := 0 |

Writers are exclusive, readers share (5-bit reader counts). Conflicts are rejected (`BUSY`) rather than queued, so
firmware sequences dependent operations explicitly and no hidden ordering exists.

**Port access checks** (combinational, at acceptance):
* firmware BUF window — write: slot owned by firmware (data FW / page FW) with no lock; read: slot allocated and not
  write-locked; anything else → `rsp_error`, no access;
* NAND port — only page slots in state NAND; everything else → `rsp_error`.

## 2. Metadata buffer

Per data-slot logical block: `VALID`, `POISON`, `LBA[31:0]`, `CRC32C[31:0]` (flip-flops, `NUM_DSLOTS × PAGE_LBS`
entries). Written by H2B (G1), DEC (V2 result) and B2H (poison on V3 failure); read by ENC (V1, S), B2H (V3), the
read-cache lookup and firmware (`MSEL` → `MLBA/MCRC/MFLAGS`). Simulation checkers assert that only the lock holder
updates an entry and that no two writers touch one slot in a cycle.

## 3. Read buffering and the clean read cache

* **Read buffering**: every NAND read lands in a data slot (DEC) before B2H moves it to the host; decode and host
  transfer of different slots overlap.
* **Clean-data cache**: firmware may insert a data slot whose contents equal the NAND copy (`CACHE_D`, refused if
  DIRTY or write-locked). `LOOKUP(LBA)` searches VALID, non-POISONED blocks of CACHED slots (hit → slot, block; the
  hit slot's age is reset, others age). B2H can be served directly from a CACHED slot.
* **Coherence**: an H2B submission invalidates every cached block whose LBA lies in its range (in the same cycle the
  descriptor is accepted), and `INVAL(LBA, count)` invalidates a range (TRIM/deallocate). Only CACHED slots are
  snooped; FW-owned slots are firmware's working state.
* **Eviction**: `ALLOC_D` with no FREE slot evicts the oldest unlocked CACHED slot (8-bit saturating age, LRU
  approximation) and reports it (`SRSP.hit = 1`). A slot being read (B2H) is never evicted.

## 4. Metadata cache (external DRAM)

`sfsb_meta_cache` (`EXT_DRAM_EN = 1`): direct mapped, `MC_SETS` lines of one 64-bit DRAM word, write-through with
update-on-hit, no write-allocate, read-allocate. A write is acknowledged only after the DRAM write response, so the
cache never holds data newer than DRAM; it has no durability or coherence obligation of its own. `MC_CTRL.inval`
clears it. Hits/misses are counted. Verified against the TB DRAM model and through the real MemoryBridge P24.

## 5. Durability rules (write caching)

1. An **H2B completion means "committed in the volatile buffer"** (every SRAM write acknowledged), never "durable".
   The slot becomes DIRTY at H2B submission; `STATUS.dirty` and the `plp_dirty` output count DIRTY slots.
2. DIRTY is cleared **only** by firmware's `COMMIT_D`, issued after the NAND PROGRAM of the page assembled from that
   slot completed successfully. If the program fails, the slot stays DIRTY (proved with NANDLab's forced program
   failure in the integration bench) and firmware re-programs elsewhere.
3. A DIRTY slot cannot be freed (except with explicit `DISCARD`, e.g. deallocate) and can never enter the clean read
   cache.
4. Firmware may acknowledge a host write **before** `COMMIT_D` only if the host enabled a volatile write cache
   (`CFG.WCE`, mirrored from the host protocol) **or** power-loss protection exists (`PLP_PRESENT`):
   `STATUS.early_ack_ok = WCE | PLP_PRESENT`. Otherwise the host completion must wait for `COMMIT_D`. FLUSH completes
   when `STATUS.dirty == 0`; FUA waits for the commit of its own slot.
5. **Power fail** (`pwr_fail_i`, synchronised): new H2B descriptors are refused (`PWR`) so no new volatile data is
   accepted; ENC/DEC/B2H continue so that, with hold-up energy, firmware can drain DIRTY slots to NAND (proved in
   `t_durable`).
6. Reset discards the buffer contents (volatile SRAM is re-initialised). Nothing here claims data survives a reset
   or power loss without PLP draining.
