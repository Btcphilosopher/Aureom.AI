# 00 — Repository audit (Project 55 BufferCore)

Audited: `btcphilosopher/Aureom.AI`, branch `claude/optimistic-hawking-jtep98`, commit `6cef76d`. As in every
earlier SilicaFlux project, the hardware lives inside zip archives under `SilicaFlux-main/` and
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`. Every archive relevant to a storage buffer was extracted and read.
"Evidence" is what the owning project recorded in its own reports; it was not re-run here unless stated.

## 1. Requested areas — what exists and what this project does with it

| Area requested | Found | Evidence (owning project) | Decision |
|---|---|---|---|
| **SRAM Wrapper Library** | `silicaflux-sramlib.zip` (Project 01): `sram_sp` / `sram_1r1w` / `sram_tdp` with valid/ready request, in-order response, ID pass-through, `WRITE_ACK`, generic / FPGA / ASIC (IHP, SKY130, GF180 macro) backends, MBIST adapter | formal + unit regressions | **Reused unmodified.** Every buffer bank is one `sram_sp` (72-bit word = 8 lanes × 9 bits, `MASK_WIDTH = 8`, `RSP_FIFO_DEPTH = 0`, `WRITE_ACK = 1`); backends selectable by `SRAM_BACKEND` / `SRAM_MACRO`. |
| **Shared SRAM** | `silicaflux-sramgrid-p33.zip` (floorplanned SRAM grids, generator), `silicaflux-hpc-m04-scratchpad.zip` (banked scratchpad, `hpc_spm_bank_arb`) | their reports | Not reused as RTL: the grid is a physical-planning generator and the M04 scratchpad is an accelerator SPM without ownership, IDs or error lanes. Its *idea* (low-order bank interleave + per-bank arbiter) is reproduced in `sfsb_bank_xbar`. |
| **DMA / DataFabric** | `silicaflux-datafabric.zip`: SFB2 protocol (PROTOCOL.md R1–R12), `sfb_crossbar`, `sfb_sram_slave`, DMA engines, **`sfb_protocol_checker`**; `silicaflux-datafabric-noc.zip` (mesh NoC); HPC M05 DMA adapter | formal proofs, regressions | **SFB2 rev 2.0 is the protocol of every external port** (firmware, NAND controller, host memory, external DRAM). `sfb_protocol_checker` **reused unmodified** on all four ports in every testbench. Existing DMA engines are single-transfer register engines without descriptors, TIDs, CRC or ECC framing → **new** descriptor DMA engines. |
| **Memory hierarchy** | `silicaflux-memorycore1.zip` (`sfmem_cache`, `sfmem_banked`), `memory_cache_repo.zip` (direct-mapped / set-assoc caches, FIFOs) | module tests | Not reused: CPU-side caches with write-back state; a storage buffer cache must never hold dirty data of its own (§6). The metadata cache here is write-through by design (`sfsb_meta_cache`). |
| **Existing FIFO interfaces** | `sfnc_fifo` (P53), `dma_fifo` (DataFabric), `sync_fifo` (memory_cache_repo) | per project | `sfsb_fifo` is a 50-line show-ahead flop FIFO written to the same contract; reusing one of the others would have meant vendoring a whole project for one primitive. |
| **DDR memory bridge** | `silicaflux-extmem-bridge-p24.zip` (Project 24, MemoryBridge): SFB2-X (SFB2 rev-2.0 superset) upstream port, scheduler, ROB, generic MC interface, **simulated** controller `extmem_sim_mc`; **no DDR controller or PHY exists** (its AUDIT §6) | 663/663 regressions, integration with DataFabric | **Reused unmodified** as the external-DRAM target of the optional DRAM adapter (`EXT_DRAM_EN`): integration bench `tb/tb_sfsb_nand.sv` runs metadata traffic through the real bridge + its sim controller + its MC-interface checker. No PHY invented. |
| **Cache modules** | see memory hierarchy | — | New `sfsb_meta_cache` (write-through, direct mapped) and a clean read cache inside the buffer manager. |
| **RAS infrastructure** | `silicaflux-ras-project26.zip` (Project 26): `sfras_secded_enc/dec` (extended Hamming, any K, all-bit-position tests), ECC SRAM, fault injection, scrubber | 39 runs, 22/22 mutants | **Reused unmodified**: the NAND codeword ECC's inner code is `sfras_secded_enc/dec` with K = 64 (one check byte per 8-byte beat), with an erased-page-friendly inversion mask computed from the RAS elaboration functions. |
| **Storage SoC** | `silicaflux-storagecore-p51.zip` (Project 51): host queues, command controller, `sfs_dma`, ECC SRAM buffer, simple NAND controller, ControlCore firmware | 4/4 SoC runs | Not reused as RTL (its buffer is one flat ECC SRAM behind a crossbar, per-word inline ECC, no slots/ownership/metadata). BufferCore is the buffer subsystem that P51's architecture leaves to a future project; its firmware/register conventions are followed. |
| **NAND controller** | `silicaflux-flashlink-p53.zip` (Project 53, FlashLink): ONFI-style channel controller, SFB2 **buffer master** (`BUF_DW` 32/64), raw page + OOB, no ECC | 771/771 on two simulators | **Reused unmodified** in the definition-of-done bench: its `sfnc_buf_master` attaches to BufferCore's NAND port (`BUF_DW = 64`). P53 docs: "ECC belongs in the buffer/data path" — that is what BufferCore provides. |
| **NAND device model** | `silicaflux-nandlab-v0.1.0.zip` (Project 52, NANDLab): behavioural ONFI device with timing checks, wear/retention, directed faults | its own reports | **Reused unmodified** (the copy vendored by P53, SHA-256 identical) with a configuration derived from P53's (`config/nandlab_p55/nandlab.svcfg`: 512 + **128** spare bytes so the 616-byte page image fits). |
| ECC engine (BCH / LDPC) | **Nothing** in the repository | — | **Not invented.** The codeword framing (data → check bytes, per-codeword status, erased detection) is real; the inner code is RAS SECDED (1-bit correct / 2-bit detect per 64 bits). NAND-grade codes are a documented limitation (docs/09). |
| Encryption (AES / XTS) | **Nothing** (Project 28 has SHA-256 only) | — | **Not invented.** `CRYPTO_EN` provides a keyed, LBA-tweaked XOR transform that is explicitly **not a cipher**; it exists to prove the pipeline position and the integrity checks around an encryption engine. |
| PCIe / NVMe host | HostLink P25 (PCIe BAR ABI + AXI endpoint *shell*, no physical PCIe) | 144/144 co-sim | The host side is an SFB2 master to host memory, the same abstraction P51 used; a PCIe DMA endpoint would sit behind it. |

## 2. Dependency status

| Dependency | Status here |
|---|---|
| sramlib `sram_sp` + generic/FPGA/ASIC backends | implemented + verified upstream; re-exercised here in every simulation (generic) and synthesis (ASIC IHP macros, ECP5 block RAM) |
| RAS `sfras_secded_enc/dec` | implemented + verified upstream; re-exercised (single/double/triple-error injection, erased pages) |
| DataFabric `sfb_protocol_checker` | verification IP, reused on 4 ports × every run |
| FlashLink P53 + NANDLab P52 + `sfnc_onfi_monitor` | implemented + verified upstream; integrated here (DoD bench) |
| MemoryBridge P24 + `extmem_sim_mc` + `extmem_mc_checker` | implemented + verified upstream (simulated controller only); integrated here |
| Bank crossbar, buffer manager, DMA engines, codeword ECC framing, CRC32C integrity, crypt placeholder, metadata cache, perf counters | **missing → implemented here** |
| BCH/LDPC ECC, AES-XTS, DDR controller/PHY, PCIe endpoint, real NAND parts | **missing → not implemented** (docs/09) |

## 3. Provenance

47 vendored files under `third_party/`, byte-identical to the repository archives:
`scripts/check_vendor.py --repo <Aureom.AI checkout>` → 47 / 47; hashes in `third_party/SHA256SUMS`,
sources in `third_party/PROVENANCE.md`. No licence file exists in the repository.
