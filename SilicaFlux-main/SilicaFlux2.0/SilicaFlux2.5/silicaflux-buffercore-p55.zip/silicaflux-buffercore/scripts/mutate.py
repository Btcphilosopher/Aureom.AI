#!/usr/bin/env python3
"""SilicaFlux BufferCore (Project 55) -- mutation testing.

Each mutant is ONE deliberate design bug, applied to a scratch copy of the tree
(build/mut_work); the Verilator build of tb_sfsb (all 16 scenario tests, base
configuration) must FAIL ("killed").  A surviving mutant marks a verification
gap.  Writes reports/mutation.md and reports/mutation.json.
"""
import json
import os
import re
import shutil
import subprocess

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.join(ROOT, "build", "mut_work")
VLF = ["--binary", "--timing", "-j", "4", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD",
       "--timescale", "1ns/1ps", "--x-assign", "unique", "--x-initial", "unique", "-DSFSB_ONLY=t_suite"]

# (id, file, original text, mutated text, what the bug means)
MUTANTS = [
    ("M01", "rtl/sfsb_slot_mgr.sv", "            ds_dirty[sd] <= 1'b1;", "            ds_dirty[sd] <= 1'b0;",
     "host data not tracked as volatile (DIRTY never set)"),
    ("M02", "rtl/sfsb_slot_mgr.sv", "        else if (any_poison)                      sub_code = `SFSB_SUB_POISON;\n        else if (any_invalid)                     sub_code = `SFSB_SUB_NOT_VALID;\n      end\n      `SFSB_OP_ENC",
     "        else if (any_invalid && !any_poison)      sub_code = `SFSB_SUB_NOT_VALID;\n      end\n      `SFSB_OP_ENC",
     "B2H accepts poisoned blocks (containment hole)"),
    ("M03", "rtl/sfsb_eng_b2h.sv", "  wire        crc_bad = (~crc_nx != rd_crc);", "  wire        crc_bad = 1'b0;",
     "egress CRC check (V3) disabled"),
    ("M04", "rtl/sfsb_eng_enc.sv", "          if ((crc_fin != rd_crc) || lb_par) begin", "          if (lb_par) begin",
     "page-assembly CRC check (V1) disabled"),
    ("M05", "rtl/sfsb_eng_dec.sv", "  wire e_lba    = (m_lba != exp_lba);", "  wire e_lba    = 1'b0;",
     "LBA tag check (misdirected read) disabled"),
    ("M06", "rtl/sfsb_eng_dec.sv", "  wire e_crc    = (~crc_nx != m_crc);", "  wire e_crc    = 1'b0;",
     "read-path CRC check (V2) disabled"),
    ("M07", "rtl/sfsb_sram_bank.sv", "      rsp_perr[l]         = r_valid && !r_we && !r_err && !(^r_rdata[l*9 +: 9]);",
     "      rsp_perr[l]         = 1'b0;", "SRAM parity check disabled"),
    ("M08", "rtl/sfsb_dispatch.sv", "    else if (tid_busy[tid])                                       sub_code = `SFSB_SUB_DUP_TID;\n",
     "", "duplicate transaction IDs accepted"),
    ("M09", "rtl/sfsb_dispatch.sv", "      else if (!turn_gc[e]) sel_gc[e] = (run[e] >= wh);", "      else if (!turn_gc[e]) sel_gc[e] = 1'b0;",
     "HOST class starves GC (WRR broken)"),
    ("M10", "rtl/sfsb_host_mux.sv", "      hold_q   <= m_req_valid && !m_req_ready;", "      hold_q   <= 1'b0;",
     "host-port request switched before acceptance (SFB2 R2)"),
    ("M11", "rtl/sfsb_nand_port.sv", "  wire ok = aligned && in_rng && chk_ok;", "  wire ok = aligned && in_rng;",
     "NAND controller may access page slots it does not own"),
    ("M12", "rtl/sfsb_slot_mgr.sv", "        else if (ds_wl[cs] || ds_rc[cs] != '0)        cmd_code = `SFSB_SR_BUSY;\n        else if (ds_dirty[cs] && !cmd_flag)",
     "        else if (ds_dirty[cs] && !cmd_flag)", "a slot locked by an engine can be freed"),
    ("M13", "rtl/sfsb_eng_dec.sv", "              if (ce_w && ce_bits != 16'hFFFF) ce_bits <= ce_bits + 1'b1;", "",
     "corrected-bit count not reported"),
    ("M14", "rtl/sfsb_slot_mgr.sv", "                if (ds_state[s] == `SFSB_DS_CACHED && (m_lba[eidx(s, i)] - sub_lba) < 32'(sub_lbc))",
     "                if (1'b0)", "read cache not invalidated by host writes (stale reads)"),
    ("M15", "rtl/sfsb_eng_h2b.sv", "  wire done = (wr == tot) && (ack == tot) && (rcv == tot);",
     "  wire done = (rcv == tot);", "completion before the buffer writes are committed"),
]


def main():
    import sys
    only = sys.argv[sys.argv.index("--only") + 1].split(",") if "--only" in sys.argv else None
    res = []
    for mid, f, old, new, what in MUTANTS:
        if only and mid not in only:
            continue
        if os.path.exists(WORK):
            shutil.rmtree(WORK)
        shutil.copytree(ROOT, WORK, ignore=shutil.ignore_patterns("build", "reports", ".git"))
        p = os.path.join(WORK, f)
        s = open(p).read()
        if s.count(old) != 1:
            res.append(dict(id=mid, file=f, what=what, status="NOT-APPLIED"))
            print(f"[mutate] {mid}: pattern not found exactly once -- not applied", flush=True)
            continue
        open(p, "w").write(s.replace(old, new))
        mdir = os.path.join(ROOT, "build", "mut_vl")
        if os.path.exists(mdir):
            shutil.rmtree(mdir)
        b = subprocess.run(["verilator"] + VLF + ["-f", "rtl/files.f", "-f", "tb/files_tb.f", "--top-module", "tb_sfsb",
                                                   "-Mdir", mdir, "-o", "vtb"], cwd=WORK, capture_output=True, text=True)
        if b.returncode != 0:
            res.append(dict(id=mid, file=f, what=what, status="KILLED (build)"))
            print(f"[mutate] {mid}: killed at build", flush=True)
            continue
        try:
            r = subprocess.run([os.path.join(mdir, "vtb"), "+TEST=all"], cwd=WORK, capture_output=True, text=True,
                               timeout=900)
            out = r.stdout + r.stderr
        except subprocess.TimeoutExpired:
            out = "TB RESULT: FAIL (timeout)"
        killed = "TB RESULT: PASS" not in out
        first = re.findall(r"ERROR \(([^)]*)\): ([^\n]*)", out)[:2]
        det = ["%s: %s" % e for e in first]
        if not det:   # checker $error / $fatal stops the simulation before the TB summary
            det = [l.strip() for l in out.splitlines() if re.search(r"%Error|\[(host|fw|nand|dram)\]|RESULT", l)][:2]
        res.append(dict(id=mid, file=f, what=what, status="KILLED" if killed else "SURVIVED", detected_by=det))
        print(f"[mutate] {mid}: {'KILLED' if killed else 'SURVIVED'} {first[:1]}", flush=True)
    shutil.rmtree(WORK, ignore_errors=True)
    if only:
        for r in res:
            print(r["id"], r["status"], r.get("detected_by"))
        return
    json.dump(res, open(os.path.join(ROOT, "reports", "mutation.json"), "w"), indent=1)
    k = sum(r["status"].startswith("KILLED") for r in res)
    md = ["# Mutation testing (generated by `scripts/mutate.py`)", "",
          f"**{k} / {len(res)} mutants killed** by the `tb_sfsb` suite (Verilator, base configuration).", "",
          "| Mutant | File | Injected bug | Result | First failing checks |", "|---|---|---|---|---|"]
    for r in res:
        det = "; ".join(r.get("detected_by", []))[:220].replace("|", "/")
        md.append(f"| {r['id']} | `{r['file']}` | {r['what']} | **{r['status']}** | {det} |")
    open(os.path.join(ROOT, "reports", "mutation.md"), "w").write("\n".join(md) + "\n")


if __name__ == "__main__":
    main()
