#!/usr/bin/env python3
"""SilicaFlux BufferCore (Project 55) -- vendored-source check.

Every file under third_party/ must be byte-identical to the same file inside the
repository archive it was taken from.  Run from a checkout of btcphilosopher/Aureom.AI:

    scripts/check_vendor.py --repo /path/to/Aureom.AI

Also (re)writes third_party/SHA256SUMS with --write.
"""
import argparse
import hashlib
import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
Z = "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5"
# third_party subdirectory -> (archive inside the repository, path prefix inside the archive)
SOURCES = {
    "silicaflux-sramlib":     (f"{Z}/silicaflux-sramlib.zip", "silicaflux-sramlib/"),
    "silicaflux-ras":         (f"{Z}/silicaflux-ras-project26.zip", "silicaflux-ras/"),
    "silicaflux-datafabric":  (f"{Z}/silicaflux-datafabric.zip", "silicaflux-datafabric/"),
    "silicaflux-flashlink":   (f"{Z}/silicaflux-flashlink-p53.zip", "silicaflux-flashlink/"),
    "silicaflux-extmem":      (f"{Z}/silicaflux-extmem-bridge-p24.zip", "silicaflux-extmem/"),
}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=os.environ.get("AUREOM_REPO", ""))
    ap.add_argument("--write", action="store_true")
    a = ap.parse_args()
    files = []
    for sub in sorted(SOURCES):
        base = os.path.join(ROOT, "third_party", sub)
        for dp, _, fns in os.walk(base):
            for fn in sorted(fns):
                files.append(os.path.relpath(os.path.join(dp, fn), os.path.join(ROOT, "third_party")))
    if a.write:
        with open(os.path.join(ROOT, "third_party", "SHA256SUMS"), "w") as f:
            for rel in sorted(files):
                f.write(f"{sha(open(os.path.join(ROOT, 'third_party', rel), 'rb').read())}  {rel}\n")
    if not a.repo:
        print("check_vendor: --repo not given; only SHA256SUMS consistency checked")
    ok = bad = 0
    sums = dict(l.split("  ", 1)[::-1] for l in open(os.path.join(ROOT, "third_party", "SHA256SUMS")).read().split("\n") if l)
    for rel in files:
        local = open(os.path.join(ROOT, "third_party", rel), "rb").read()
        if sums.get(rel) != sha(local):
            print(f"SHA256SUMS mismatch: {rel}")
            bad += 1
            continue
        if a.repo:
            sub, inner = rel.split("/", 1)
            zp, prefix = SOURCES[sub]
            with zipfile.ZipFile(os.path.join(a.repo, zp)) as z:
                try:
                    orig = z.read(prefix + inner)
                except KeyError:
                    print(f"not in archive: {rel} ({zp})")
                    bad += 1
                    continue
            if orig != local:
                print(f"DIFFERS from archive: {rel}")
                bad += 1
                continue
        ok += 1
    print(f"check_vendor: {ok} / {len(files)} vendored files verified" + (" against the repository archives" if a.repo else ""))
    sys.exit(0 if bad == 0 else 1)


if __name__ == "__main__":
    main()
