#!/usr/bin/env python3
"""SilicaFlux BufferCore (Project 55) -- Yosys 0.33 synthesis + SRAM report.

Flows per configuration (results in reports/synth.md and reports/synth.json):
  mem   : generic backend, `memory -nomap` -> inventory of the inferred SRAM arrays
  asic  : SRAM_BACKEND = ASIC (IHP SG13G2 macro black boxes from silicaflux-sramlib),
          generic `synth` of the logic -> cells / flip-flops / macro instances,
          `check -assert` (no latches, loops, multiple drivers)
  ecp5  : SRAM_BACKEND = FPGA (block-RAM inference) -> `synth_ecp5` -> LUT4 / FF / DP16KD

All numbers are logic-synthesis estimates; no place-and-route, no timing.
Usage: scripts/synth.py [--configs small,base] [--flows mem,asic,ecp5]
"""
import argparse
import json
import os
import re
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

RTL = """third_party/silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1rw.sv
third_party/silicaflux-sramlib/rtl/mem/backends/fpga/sram_fpga_1rw.sv
third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_ihp1p.sv
third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_ihp2p.sv
third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_sky130.sv
third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_gf180.sv
third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_asic_array.sv
third_party/silicaflux-sramlib/rtl/mem/sram_backend_1rw.sv
third_party/silicaflux-sramlib/rtl/mem/sram_rsp_path.sv
third_party/silicaflux-sramlib/rtl/mem/sram_sp.sv
third_party/silicaflux-ras/rtl/sfras_secded_enc.sv
third_party/silicaflux-ras/rtl/sfras_secded_dec.sv
rtl/sfsb_fifo.sv
rtl/sfsb_ecc64.sv
rtl/sfsb_sram_bank.sv
rtl/sfsb_bank_xbar.sv
rtl/sfsb_slot_mgr.sv
rtl/sfsb_dispatch.sv
rtl/sfsb_eng_h2b.sv
rtl/sfsb_eng_b2h.sv
rtl/sfsb_eng_enc.sv
rtl/sfsb_eng_dec.sv
rtl/sfsb_host_mux.sv
rtl/sfsb_nand_port.sv
rtl/sfsb_meta_cache.sv
rtl/sfsb_perf.sv
rtl/sfsb_fw_port.sv
rtl/silicaflux_storage_buffer.sv""".split()

STUBS = "third_party/silicaflux-sramlib/rtl/mem/backends/asic/stubs/sram_macro_blackboxes.sv"
INC = ["third_party/silicaflux-sramlib/rtl/mem", "third_party/silicaflux-sramlib/rtl/mem/backends/asic",
       "third_party/silicaflux-ras/rtl", "rtl"]

# small = the starting point ("start with a small banked SRAM buffer"); base = default parameters
CONFIGS = {
    "small": dict(NUM_BANKS=2, LB_BYTES=128, PAGE_LBS=4, NUM_DSLOTS=4, NUM_PSLOTS=3),
    "base":  dict(NUM_BANKS=4, LB_BYTES=512, PAGE_LBS=4, NUM_DSLOTS=8, NUM_PSLOTS=4),
}
# IHP SG13G2 single-port macro used for the ASIC estimate (bit-granular write mask,
# so 9-bit parity lanes map directly): id -> (name, words, bits)
IHP_MACRO = {"small": (26, "RM_IHPSG13_1P_256x16_c2_bm_bist", 256, 16),
             "base":  (20, "RM_IHPSG13_1P_1024x16_c2_bm_bist", 1024, 16)}


def derived(p):
    lbb = p["LB_BYTES"] // 8
    cwb = lbb + lbb // 8
    pimg = p["PAGE_LBS"] * cwb + p["PAGE_LBS"] + 1
    nb = p["NUM_BANKS"]
    pslot = ((pimg + nb - 1) // nb) * nb
    total = p["NUM_DSLOTS"] * p["PAGE_LBS"] * lbb + p["NUM_PSLOTS"] * pslot
    depth = (total + nb - 1) // nb
    return dict(total_beats=total, bank_depth=depth, bytes_data=total * 8, bits_stored=depth * nb * 72,
                pimg=pimg, pslot=pslot)


def read_cmd(extra_files=()):
    incs = " ".join("-I" + i for i in INC)
    files = " ".join(list(extra_files) + RTL)
    return f"read_verilog -defer -sv -DSYNTHESIS {incs} {files}"


def chparams(p, backend, macro=0):
    s = " ".join(f"-set {k} {v}" for k, v in p.items())
    return f"chparam {s} -set SRAM_BACKEND {backend} -set SRAM_MACRO {macro} silicaflux_storage_buffer"


def run_yosys(script, log):
    t0 = time.time()
    with open(log, "w") as f:
        r = subprocess.run(["yosys", "-q", "-l", log + ".full", "-p", script], cwd=ROOT, stdout=f,
                           stderr=subprocess.STDOUT, timeout=7200)
    return r.returncode, time.time() - t0


def parse_stat(text, top="silicaflux_storage_buffer"):
    """Return {cell: count} of the last 'design hierarchy' / top statistics block."""
    blocks = re.split(r"\n=== ", text)
    pick = None
    for b in blocks:
        if b.startswith("design hierarchy") or b.startswith(top + " ==="):
            pick = b
    if pick is None:
        pick = blocks[-1]
    cells = {}
    tot = None
    for line in pick.splitlines():
        m = re.match(r"\s+Number of cells:\s+(\d+)", line)
        if m and tot is None:
            tot = int(m.group(1))
        m = re.match(r"\s+(\S+)\s+(\d+)$", line)
        if m:
            cells[m.group(1)] = cells.get(m.group(1), 0) + int(m.group(2))
    return tot, cells


def flow_mem(name, p, outdir):
    script = "; ".join([read_cmd(), chparams(p, 0), "hierarchy -check -top silicaflux_storage_buffer",
                        "proc", "opt -fast", "memory -nomap", "opt_clean", "stat -width"])
    log = os.path.join(outdir, f"{name}_mem.log")
    rc, dt = run_yosys(script, log)
    txt = open(log + ".full").read()
    mems = re.findall(r"\$mem_v2\s+(\d+)", txt)
    bits = re.findall(r"Number of memory bits:\s+(\d+)", txt)
    return dict(rc=rc, seconds=round(dt, 1), mem_cells_lines=mems, memory_bits=[int(b) for b in bits])


def flow_asic(name, p, outdir):
    mid, mname, words, width = IHP_MACRO[name]
    script = "; ".join([read_cmd([STUBS]), chparams(p, 2, mid), "hierarchy -check -top silicaflux_storage_buffer",
                        "synth -top silicaflux_storage_buffer", "opt_clean -purge",
                        "tee -o " + os.path.join(outdir, f"{name}_asic_check.txt") + " check -assert",
                        "tee -o " + os.path.join(outdir, f"{name}_asic_stat.txt") + " stat -width"])
    log = os.path.join(outdir, f"{name}_asic.log")
    rc, dt = run_yosys(script, log)
    res = dict(rc=rc, seconds=round(dt, 1), macro=mname, macro_words=words, macro_bits=width)
    sp = os.path.join(ROOT, outdir, f"{name}_asic_stat.txt")
    if rc == 0 and os.path.exists(sp):
        txt = open(sp).read()
        tot, cells = parse_stat(txt)
        res["cells_total"] = tot
        res["macros"] = cells.get(mname, 0)
        res["flip_flops"] = sum(v for k, v in cells.items() if re.match(r"\$_(S?DFF|DFFE|SDFFE|SDFFCE|ALDFF|DLATCH)", k))
        res["latches"] = sum(v for k, v in cells.items() if "DLATCH" in k)
        res["cells"] = cells
    return res


def flow_ecp5(name, p, outdir):
    script = "; ".join([read_cmd(), chparams(p, 1), "hierarchy -check -top silicaflux_storage_buffer",
                        "synth_ecp5 -top silicaflux_storage_buffer",
                        "tee -o " + os.path.join(outdir, f"{name}_ecp5_stat.txt") + " stat -width"])
    log = os.path.join(outdir, f"{name}_ecp5.log")
    rc, dt = run_yosys(script, log)
    res = dict(rc=rc, seconds=round(dt, 1))
    sp = os.path.join(ROOT, outdir, f"{name}_ecp5_stat.txt")
    if rc == 0 and os.path.exists(sp):
        tot, cells = parse_stat(open(sp).read())
        res["LUT4"] = cells.get("LUT4", 0)
        res["FF"] = cells.get("TRELLIS_FF", 0)
        res["DP16KD"] = cells.get("DP16KD", 0)
        res["DPR16X4"] = cells.get("TRELLIS_DPR16X4", 0)
        res["CCU2C"] = cells.get("CCU2C", 0)
        res["cells_total"] = tot
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", default="small,base")
    ap.add_argument("--flows", default="mem,asic,ecp5")
    a = ap.parse_args()
    outdir = "synth/yosys"
    os.makedirs(os.path.join(ROOT, outdir), exist_ok=True)
    jpath = os.path.join(ROOT, "reports", "synth.json")
    results = json.load(open(jpath)) if os.path.exists(jpath) else {}
    for name in a.configs.split(","):
        p = CONFIGS[name]
        r = results.setdefault(name, {})
        r["params"] = p
        r["derived"] = derived(p)
        for fl in a.flows.split(","):
            print(f"[synth] {name} / {fl} ...", flush=True)
            r[fl] = {"mem": flow_mem, "asic": flow_asic, "ecp5": flow_ecp5}[fl](name, p, outdir)
            print(f"[synth] {name} / {fl}: rc={r[fl]['rc']} {r[fl].get('seconds')} s", flush=True)
        os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
        json.dump(results, open(jpath, "w"), indent=1, sort_keys=True)
    ok = all(r.get(f, {}).get("rc", 0) == 0 for r in results.values() for f in ("mem", "asic", "ecp5"))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
