#!/usr/bin/env python3
"""SilicaFlux BufferCore (Project 55) -- regression.

  * tb_sfsb (16 scenario tests) on Verilator 5 for every configuration below
    (several seeds for the randomised parts), and on Icarus 12 for a subset;
  * tb_sfsb_nand (definition-of-done integration with FlashLink P53, NANDLab
    P52 and MemoryBridge P24, all unmodified) on Verilator and Icarus.
Writes reports/regression.md and reports/regression.json; logs in reports/sim/.

Usage: scripts/regress.py [--quick] [--no-icarus] [--only cfg1,cfg2]
"""
import argparse
import json
import os
import re
import subprocess
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VLF = ["--binary", "--timing", "-j", "4", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD",
       "--timescale", "1ns/1ps", "--x-assign", "unique", "--x-initial", "unique"]

CONFIGS = {
    "base":    {},
    "small":   dict(NUM_BANKS=2, LB_BYTES=128, NUM_DSLOTS=4, NUM_PSLOTS=3),
    "wide":    dict(NUM_BANKS=8, LB_BYTES=256, PAGE_LBS=8, NUM_DSLOTS=8, NUM_PSLOTS=4),
    "lb64":    dict(NUM_BANKS=2, LB_BYTES=64, PAGE_LBS=2, NUM_DSLOTS=4, NUM_PSLOTS=3),
    "mo4":     dict(HOST_MAX_OUT=4),
    "dram":    dict(EXT_DRAM_EN=1),
    "nocrypt": dict(CRYPTO_EN=0),
    "plp":     dict(PLP_PRESENT=1, AGE_LIMIT=4),
}
SEEDS = {"base": [1, 2, 3], "mo4": [1, 2]}
ICARUS = ["small", "base"]


def sh(cmd, log, timeout):
    t0 = time.time()
    with open(log, "w") as f:
        try:
            r = subprocess.run(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, timeout=timeout)
            rc = r.returncode
        except subprocess.TimeoutExpired:
            rc = -999
    return rc, time.time() - t0


def parse(log):
    txt = open(log, errors="replace").read()
    m = re.search(r"TB RESULT: (PASS|FAIL)[^\n]*", txt)
    n = re.search(r"\((\d+) checks\)|of (\d+) checks", txt)
    checks = int(n.group(1) or n.group(2)) if n else 0
    acc = re.search(r"accepted (\d+) descriptors, (\d+) completions, protocol violations fw/nand/host/dram = "
                    r"(\d+)/(\d+)/(\d+)/(\d+)", txt)
    errors = re.findall(r"ERROR \(([^)]*)\): ([^\n]*)", txt)
    return dict(result=(m.group(1) if m else "NO-RESULT"), line=(m.group(0) if m else ""), checks=checks,
                accepted=int(acc.group(1)) if acc else None, completions=int(acc.group(2)) if acc else None,
                violations=[int(acc.group(i)) for i in range(3, 7)] if acc else None,
                first_errors=errors[:5], dod=("-- MET" in txt))


def gflags(p, icarus=False, top="tb_sfsb"):
    if icarus:
        out = []
        for k, v in p.items():
            out += ["-P", f"{top}.{k}={v}"]
        return out
    return [f"-G{k}={v}" for k, v in p.items()]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--no-icarus", action="store_true")
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    os.makedirs(os.path.join(ROOT, "reports", "sim"), exist_ok=True)
    os.makedirs(os.path.join(ROOT, "build"), exist_ok=True)
    runs = []
    cfgs = [c for c in CONFIGS if (not a.only or c in a.only.split(","))]
    procs = []
    # ---- Icarus runs in the background (slow), Verilator in the foreground
    if not a.no_icarus:
        for c in [c for c in ICARUS if c in cfgs]:
            vvp = f"build/iv_{c}.vvp"
            subprocess.run(["iverilog", "-g2012", "-o", vvp, "-s", "tb_sfsb", "-f", "rtl/files.f", "-f", "tb/files_tb.f"]
                           + gflags(CONFIGS[c], icarus=True), cwd=ROOT, capture_output=True)
            log = os.path.join(ROOT, "reports", "sim", f"iverilog_{c}_seed1.log")
            procs.append((c, "iverilog", 1, log, time.time(),
                          subprocess.Popen(["vvp", "-n", vvp, "+TEST=all", "+SEED=1"], cwd=ROOT,
                                           stdout=open(log, "w"), stderr=subprocess.STDOUT)))
        if not a.only or "integration" in a.only:
            subprocess.run(["iverilog", "-g2012", "-o", "build/iv_nand.vvp", "-s", "tb_sfsb_nand", "-f", "rtl/files.f",
                            "-f", "tb/files_integ.f"], cwd=ROOT, capture_output=True)
            os.makedirs(os.path.join(ROOT, "build", "nandlab"), exist_ok=True)
            subprocess.run(["cp", "config/nandlab_p55/nandlab.svcfg", "build/nandlab/"], cwd=ROOT)
            log = os.path.join(ROOT, "reports", "sim", "iverilog_integration.log")
            procs.append(("integration", "iverilog", 0, log, time.time(),
                          subprocess.Popen(["vvp", "-n", "build/iv_nand.vvp", "+NANDLAB_DIR=build/nandlab",
                                            "+NANDLAB_QUIET", "+NANDLAB_NOTRACE"], cwd=ROOT,
                                           stdout=open(log, "w"), stderr=subprocess.STDOUT)))
    for c in cfgs:
        mdir = f"build/vl_{c}"
        blog = os.path.join(ROOT, "reports", "sim", f"build_verilator_{c}.log")
        rc, dt = sh(["verilator"] + VLF + ["-DSFSB_ONLY=t_suite"] + gflags(CONFIGS[c]) +
                    ["-f", "rtl/files.f", "-f", "tb/files_tb.f", "--top-module", "tb_sfsb", "-Mdir", mdir, "-o", "vtb"],
                    blog, 3600)
        print(f"[regress] build {c}: rc={rc} {dt:.0f} s", flush=True)
        for seed in (SEEDS.get(c, [1])[:1] if a.quick else SEEDS.get(c, [1])):
            log = os.path.join(ROOT, "reports", "sim", f"verilator_{c}_seed{seed}.log")
            rc, dt = sh([f"{mdir}/vtb", "+TEST=all", f"+SEED={seed}"], log, 1800)
            r = parse(log)
            r.update(sim="verilator", config=c, seed=seed, params=CONFIGS[c], seconds=round(dt, 1), rc=rc)
            runs.append(r)
            print(f"[regress] verilator {c} seed {seed}: {r['line']} ({dt:.1f} s)", flush=True)
    # ---- integration on Verilator
    if not a.only or "integration" in a.only:
        os.makedirs(os.path.join(ROOT, "build", "nandlab"), exist_ok=True)
        subprocess.run(["cp", "config/nandlab_p55/nandlab.svcfg", "build/nandlab/"], cwd=ROOT)
        blog = os.path.join(ROOT, "reports", "sim", "build_verilator_integration.log")
        rc, dt = sh(["verilator"] + VLF + ["-f", "rtl/files.f", "-f", "tb/files_integ.f", "--top-module", "tb_sfsb_nand",
                                           "-Mdir", "build/vl_integration", "-o", "vtb"], blog, 3600)
        log = os.path.join(ROOT, "reports", "sim", "verilator_integration.log")
        rc, dt = sh(["build/vl_integration/vtb", "+NANDLAB_DIR=build/nandlab", "+NANDLAB_QUIET", "+NANDLAB_NOTRACE"],
                    log, 1800)
        r = parse(log)
        r.update(sim="verilator", config="integration", seed=0, params={}, seconds=round(dt, 1), rc=rc)
        runs.append(r)
        print(f"[regress] verilator integration: {r['line']} ({dt:.1f} s)", flush=True)
    for (c, sim, seed, log, t0, p) in procs:
        p.wait()
        r = parse(log)
        r.update(sim=sim, config=c, seed=seed, params=CONFIGS.get(c, {}), seconds=round(time.time() - t0, 1),
                 rc=p.returncode)
        runs.append(r)
        print(f"[regress] {sim} {c}: {r['line']}", flush=True)
    json.dump(runs, open(os.path.join(ROOT, "reports", "regression.json"), "w"), indent=1)
    write_md(runs)
    raise SystemExit(0 if all(r["result"] == "PASS" for r in runs) else 1)


def write_md(runs):
    npass = sum(r["result"] == "PASS" for r in runs)
    md = ["# Regression report (generated by `scripts/regress.py`)", "",
          f"**{npass} / {len(runs)} runs PASS.**  Logs: `reports/sim/`.", "",
          "| Simulator | Config | Seed | Result | Checks | Descriptors accepted / completed | SFB2 violations fw/nand/host/dram | Wall time |",
          "|---|---|---|---|---|---|---|---|"]
    for r in runs:
        acc = f"{r['accepted']} / {r['completions']}" if r["accepted"] is not None else "-"
        vio = "/".join(str(v) for v in r["violations"]) if r["violations"] else "-"
        cfg = r["config"] + (" (DoD MET)" if r["dod"] else "")
        wt = (f"≤ {r['seconds']} s" if r["sim"] == "iverilog" else f"{r['seconds']} s")   # Icarus runs in the background
        md.append(f"| {r['sim']} | {cfg} | {r['seed']} | **{r['result']}** | {r['checks']} | {acc} | {vio} | {wt} |")
    md += ["", "Configurations:", ""]
    for c, p in CONFIGS.items():
        md.append(f"* `{c}`: {p or 'defaults (NUM_BANKS=4, LB_BYTES=512, PAGE_LBS=4, NUM_DSLOTS=8, NUM_PSLOTS=4)'}")
    md += ["", "Icarus runs execute in the background while the Verilator runs build; their wall time is an upper",
           "bound (time until collected).", "", "Accepted minus completed = 1 in every suite run: the controller-reset test cancels one in-flight",
           "transfer by design (reset cancels transactions, no completion is owed; the TID bookkeeping is reset).",
           "", "Failures (first five per run):", ""]
    any_fail = False
    for r in runs:
        if r["first_errors"]:
            any_fail = True
            md.append(f"* {r['sim']} {r['config']} seed {r['seed']}: " + "; ".join(f"{t}: {m}" for t, m in r["first_errors"]))
    if not any_fail:
        md.append("* none")
    open(os.path.join(ROOT, "reports", "regression.md"), "w").write("\n".join(md) + "\n")


if __name__ == "__main__":
    main()
