# Vendored sources (all unmodified)

Every file below is byte-identical to the same path inside the named archive of `btcphilosopher/Aureom.AI`
(commit `6cef76d`). Verify with `scripts/check_vendor.py --repo <checkout>` (47 / 47); hashes in `SHA256SUMS`.
No licence file exists in the repository.

| Directory | Archive (`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/…`) | Project | Files used | Used as |
|---|---|---|---|---|
| `silicaflux-sramlib/` | `silicaflux-sramlib.zip` | 01 SRAM Wrapper Library | `sram_sp`, `sram_backend_1rw`, `sram_rsp_path`, `sram_defs.svh`, generic / FPGA / ASIC (IHP, SKY130, GF180 leaves, macro stubs) backends | RTL: every buffer bank |
| `silicaflux-ras/` | `silicaflux-ras-project26.zip` | 26 RAS | `sfras_secded_enc`, `sfras_secded_dec`, `sfras_ecc_funcs.svh`, `sfras_defs.svh` | RTL: NAND codeword ECC inner code |
| `silicaflux-datafabric/` | `silicaflux-datafabric.zip` | DataFabric | `tb/common/sfb_protocol_checker.sv` | verification: SFB2 checker on all ports |
| `silicaflux-flashlink/` | `silicaflux-flashlink-p53.zip` | 53 FlashLink + 52 NANDLab model | controller RTL, `sfnc_io_sdr`, `tb/sfnc_onfi_monitor.sv`, `tb/models/nand_flash_model.sv` (NANDLab, SHA-256 `070651e0…`), `config/nandlab_regress.svcfg` | verification: DoD integration bench |
| `silicaflux-extmem/` | `silicaflux-extmem-bridge-p24.zip` | 24 MemoryBridge | bridge RTL + CDC, `sim/models/extmem_sim_mc.sv`, `tb/extmem_mc_checker.sv` | verification: DRAM-adapter integration |

Derived (not vendored): `config/nandlab_p55/nandlab.svcfg` = `nandlab_regress.svcfg` with `page_spare_bytes 128`
(was 16) and `config_fp buffercore-p55-integration`.
