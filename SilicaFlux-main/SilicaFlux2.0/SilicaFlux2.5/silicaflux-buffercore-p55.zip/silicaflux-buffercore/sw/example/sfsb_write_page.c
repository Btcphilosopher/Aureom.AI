/*
 * SilicaFlux BufferCore (Project 55) -- firmware usage example (compile-checked, not run).
 *
 * The sequence below is exactly what tb/tb_sfsb_nand.sv (write_page) performs on the
 * real RTL: host data -> data slot (H2B) -> page image (ENC) -> NAND program ->
 * COMMIT (durable) -> free.  nand_program() stands for the FlashLink (P53) request
 * interface and is outside the buffer.
 */
#include "sfsb_regs.h"

#define BUF_BASE 0x40000000u   /* where the system map places the buffer's firmware window */

static unsigned csr_rd(unsigned off) { return SFSB_CSR(BUF_BASE, off); }
static void csr_wr(unsigned off, unsigned v) { SFSB_CSR(BUF_BASE, off) = v; }

static unsigned slot_cmd(unsigned cmd, unsigned slot, unsigned flag)
{
  csr_wr(SFSB_CSR_SCMD, SFSB_SCMD(cmd, slot, flag));
  return csr_rd(SFSB_CSR_SRSP);              /* [7:0] code, [15:8] slot, [16] hit/evicted */
}

static int submit(unsigned desc0, unsigned desc1, unsigned haddr, unsigned lba)
{
  csr_wr(SFSB_CSR_DESC0, desc0);
  csr_wr(SFSB_CSR_DESC1, desc1);
  csr_wr(SFSB_CSR_DESC2, haddr);
  csr_wr(SFSB_CSR_DESC3, lba);
  csr_wr(SFSB_CSR_SUBMIT, 1u);
  return (int)(csr_rd(SFSB_CSR_SUBMIT) & 0xFFu);   /* SFSB_SUB_* (0 = accepted) */
}

/* wait for the completion of 'tid'; returns its status (SFSB_ST_*) */
static unsigned wait_cpl(unsigned tid)
{
  for (;;) {
    if (csr_rd(SFSB_CSR_CPL_STAT) & 1u) {
      unsigned w0 = csr_rd(SFSB_CSR_CPL0);
      csr_wr(SFSB_CSR_CPL_POP, 1u);
      if ((w0 & 0xFFu) == tid) return (w0 >> 16) & 0xFFu;
      /* a real firmware dispatches other TIDs to their owners here */
    }
  }
}

extern int nand_program(unsigned buf_byte_addr, unsigned bytes, unsigned row);

int write_page(unsigned host_addr, unsigned lba, unsigned row)
{
  unsigned r, ds, ps, st, page_bytes, page_addr;
  r = slot_cmd(SFSB_SC_ALLOC_D, 0u, 0u); if ((r & 0xFFu) != SFSB_SR_OK) return -1; ds = (r >> 8) & 0xFFu;
  r = slot_cmd(SFSB_SC_ALLOC_P, 0u, 0u); if ((r & 0xFFu) != SFSB_SR_OK) return -1; ps = (r >> 8) & 0xFFu;

  /* host ingress: integrity point G1 (CRC32C per logical block) */
  if (submit(SFSB_DESC0(SFSB_OP_H2B, SFSB_CLS_HOST, 0u, 1u, 0u, 4u), SFSB_DESC1(ds, 0u), host_addr, lba)) return -2;
  if ((st = wait_cpl(1u)) != SFSB_ST_OK) return -3;
  /* the H2B completion means 'in volatile buffer', NOT durable: STATUS.dirty counts it */

  /* page assembly: V1 check, ECC encode, OOB {LBA, CRC32C} */
  if (submit(SFSB_DESC0(SFSB_OP_ENC, SFSB_CLS_HOST, 0u, 2u, 0u, 4u), SFSB_DESC1(ds, ps), 0u, 0u)) return -4;
  if ((st = wait_cpl(2u)) != SFSB_ST_OK) return -5;   /* CRC => page marked BAD, P2NAND refused */

  page_bytes = (csr_rd(SFSB_CSR_PARAM1) >> 16) * 8u;
  page_addr  = csr_rd(SFSB_CSR_PARAM2) + ps * (csr_rd(SFSB_CSR_PARAM1) & 0xFFFFu) * 8u;
  if ((slot_cmd(SFSB_SC_P2NAND, ps, 0u) & 0xFFu) != SFSB_SR_OK) return -6;
  st = (unsigned)nand_program(page_addr, page_bytes, row);
  slot_cmd(SFSB_SC_P2FW, ps, 0u);
  if (st != 0u) return -7;                             /* slot stays DIRTY: retry elsewhere */

  slot_cmd(SFSB_SC_COMMIT_D, ds, 0u);                  /* now durable: DIRTY cleared */
  slot_cmd(SFSB_SC_FREE_D, ds, 0u);
  slot_cmd(SFSB_SC_FREE_P, ps, 0u);
  return 0;
}
