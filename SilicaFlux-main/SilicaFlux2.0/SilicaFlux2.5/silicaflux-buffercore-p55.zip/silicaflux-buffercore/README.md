# SilicaFlux-STORE · Project 55 — BufferCore: high-bandwidth storage buffer and DMA system

**Primary RTL:** [`rtl/silicaflux_storage_buffer.sv`](rtl/silicaflux_storage_buffer.sv) · Aureom.AI | SilicaFlux-STORE

BufferCore is the memory-buffering subsystem of the SilicaFlux storage processor. It moves data between the host,
the ECC engine, the NAND channel controllers and the ControlCore firmware through a banked, parity-protected
on-chip SRAM, with descriptor DMA engines, explicit buffer ownership, end-to-end CRC-32C integrity, codeword ECC
framing, a clean read cache, a write-through metadata cache in front of an optional external DRAM, documented
starvation-free arbitration and 38 hardware performance counters.

```
host memory ◄─SFB2─► H2B (CRC gen) ─┐                 ┌─ ENC: V1 CRC ─► crypt ─► ECC enc ─► page image ─┐
                    B2H (CRC chk) ◄─┤  banked SRAM    │                                                  ├─SFB2─► NAND controller
                                    ├─ data slots ────┤                                                  │        (FlashLink P53)
ControlCore ─SFB2─► CSR / BUF ──────┤  page slots ────┴─ DEC: ECC dec ─► crypt ─► V2 CRC + LBA ◄────────┘
             DRAM window ─► metadata cache ─SFB2─► MemoryBridge (P24)
```

> **Status.** RTL simulation (Verilator 5.020 and Icarus Verilog 12) and Yosys 0.33 synthesis estimates. Nothing
> ran on an FPGA or silicon. The ECC inner code is the repository's SECDED (not BCH/LDPC), the crypt stage is a
> placeholder transform (not a cipher), and there is no DDR PHY and no PCIe endpoint. See
> [docs/09_LIMITATIONS.md](docs/09_LIMITATIONS.md). Delivered as an archive; nothing was committed.

## Definition of done — met in RTL simulation

*A complete memory-to-NAND and NAND-to-memory transfer works with real data integrity checking in RTL simulation.*

`tb/tb_sfsb_nand.sv` connects BufferCore to the **unmodified** FlashLink NAND controller (Project 53), the
NANDLab device model (Project 52), the ONFI pin monitor and the MemoryBridge (Project 24). The testbench, acting as
firmware, resets the NAND, reads the ONFI parameter page into a NAND-owned page slot, erases, then:
host memory → H2B (CRC-32C generated) → ENC (CRC re-verified, SECDED codewords, OOB {CRC, LBA}) → FlashLink PROGRAM
→ FlashLink READ_PAGE → DEC (ECC corrected, CRC and LBA verified) → B2H (CRC verified) → host memory, byte-exact.
The NAND array is checked to hold the codewords and the OOB tags generated at host ingress. Medium errors injected
into the NANDLab array are corrected (1 bit) or detected and contained (2 bits), an erased page reads as ERASED, and
a forced NAND program failure leaves the data DIRTY until re-programmed. Zero NANDLab protocol/timing errors, zero
ONFI-monitor, SFB2 and MemoryBridge-interface violations. Passes on **both** simulators:
`TB DoD: memory->NAND and NAND->memory transfers with end-to-end integrity checking -- MET`.

## Results

| Check | Result | Report |
|---|---|---|
| **Definition of done** — BufferCore + FlashLink P53 + NANDLab P52 + MemoryBridge P24, all unmodified | **MET on Verilator and on Icarus** (1 059 checks each): byte-exact host → NAND → host, NAND array holds the ingress CRC/LBA tags, corrected and detected medium errors, erased page, program failure keeps data DIRTY; 0 NANDLab protocol / timing errors, 0 ONFI-monitor, SFB2 and MemoryBridge-interface violations | [regression](reports/regression.md), `reports/sim/*integration.log` |
| Scenario suite (16 tests, §10 list + ownership, caching, durability, arbitration, registers) | **15 / 15 regression runs PASS** — 8 configurations on Verilator (12 runs incl. seeds), 2 on Icarus, plus the DoD bench on both; **171,246 checks**; every accepted descriptor completed exactly once (the reset test cancels one by design); 0 SFB2 protocol violations; commit monitor: 0 completions before their data was committed | [regression](reports/regression.md), [verification](docs/07_VERIFICATION.md) |
| Mutation testing | **15 / 15** deliberate design bugs detected (integrity checks, poison containment, ownership, DIRTY tracking, TIDs, WRR, SFB2 R2, premature completion, cache coherence) | [mutation](reports/mutation.md) |
| Lint | Verilator `-Wall`: **0 warnings** (synthesizable view) in 9 configurations; 1 simulation-view warning from the vendored SRAM library's assertion block; Icarus elaborates all 9; 5 / 5 illegal parameter sets rejected by both tools | [lint](reports/lint.md) |
| Performance (measured by the DUT's counters) | host port is the bottleneck and follows Little's law: 0.111 → 0.955 beats/cycle at 8-cycle host latency for 1 → 16 outstanding; ENC 0.818 / DEC 0.845 data beats/cycle (92–95 % of the 8/9 bound); 4 banks is the knee (ENC 0.642 with 2); longest bank wait ≤ 9 cycles in every swept configuration (bound 23); NAND starvation 0 | [perf](reports/perf.md), [docs/06](docs/06_PERFORMANCE.md) |
| SRAM synthesis (Yosys 0.33, estimates) | base: 4 × 808 × 72 b → **20 IHP SG13G2 1024×16 macros** (71 % used) or **16 ECP5 DP16KD**; logic ≈ 120 k generic cells, 12.6 k FF, **0 latches**, `check -assert` clean; small: 10 macros (86 %), 4 DP16KD | [synth](reports/synth.md), [docs/08](docs/08_SYNTHESIS.md) |
| Reuse | **47 / 47** vendored files byte-identical to the repository archives | `scripts/check_vendor.py`, [provenance](third_party/PROVENANCE.md) |
| Firmware interface | C header generated from the RTL defines (up to date); example compiles with `gcc -std=c11 -Wall -Wextra -Werror -pedantic` | [registers](docs/REGISTERS.md), `sw/` |

## Requirement → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository audit, reuse verified modules | [docs/00_AUDIT.md](docs/00_AUDIT.md); 47 vendored files byte-identical ([third_party/PROVENANCE.md](third_party/PROVENANCE.md), `scripts/check_vendor.py`): SRAM library, RAS SECDED, DataFabric checker, FlashLink, NANDLab, MemoryBridge |
| 2 | Host ingress/egress buffers, NAND page buffer, ECC input/output buffers, metadata buffer, firmware access, on-chip SRAM first, optional DRAM adapter without a PHY | data slots / page slots / metadata buffer ([docs/01](docs/01_ARCHITECTURE.md) §3, [docs/02](docs/02_DATA_PATH.md) §3), `sfsb_fw_port`, `sfsb_meta_cache` → P24 |
| 3 | Configurable capacity, banks, byte enables, bursts, arbitration, transaction IDs, error responses, ownership, real memory-port limits | top parameters, `sfsb_sram_bank` (1RW, latency 1, lane masks, write acks), `sfsb_bank_xbar`, `sfsb_dispatch` (TIDs), `sfsb_slot_mgr` |
| 4 | Write and read paths with optional encryption; integrity points defined | `sfsb_eng_h2b/enc/dec/b2h`; [docs/02](docs/02_DATA_PATH.md) §4 (G1, P, V1, S, E, V2, V3) |
| 5 | Descriptor DMA: submission, validation, length, bursts, back-pressure, completion tracking, errors; completion only after commit | [docs/05_DMA.md](docs/05_DMA.md); commit monitor in `tb_sfsb` |
| 6 | Read buffering, clean-data cache, metadata cache, eviction, durability rules | [docs/03_BUFFER_MANAGER.md](docs/03_BUFFER_MANAGER.md) §3–5 |
| 7 | Concurrent host / NAND / ECC / firmware / GC, documented anti-starvation policy | [docs/04_ARBITRATION.md](docs/04_ARBITRATION.md) |
| 8 | Codeword boundaries, page/OOB organisation, LBA identifiers, transaction tags, metadata association under stalls | [docs/02](docs/02_DATA_PATH.md) §2, §4 |
| 9 | Performance counters (SRAM traffic, occupancy, DMA throughput, arbitration stalls, ECC wait, NAND starvation, host wait) | `sfsb_perf`, [docs/REGISTERS.md](docs/REGISTERS.md), [docs/06](docs/06_PERFORMANCE.md) |
| 10 | Tests: simultaneous transfers, partial blocks, back-pressure, exhaustion, concurrent R/W, reset, invalid descriptors, ECC errors, corruption, no duplicate/dropped transfers | [docs/07_VERIFICATION.md](docs/07_VERIFICATION.md) §2 |
| 11 | Deliverables | table below |

## Deliverables

| Deliverable | Files |
|---|---|
| `silicaflux_storage_buffer.sv` | [rtl/silicaflux_storage_buffer.sv](rtl/silicaflux_storage_buffer.sv) |
| Buffer manager | [rtl/sfsb_slot_mgr.sv](rtl/sfsb_slot_mgr.sv), [rtl/sfsb_dispatch.sv](rtl/sfsb_dispatch.sv) |
| DMA engines and adapters | [rtl/sfsb_eng_h2b.sv](rtl/sfsb_eng_h2b.sv), [rtl/sfsb_eng_b2h.sv](rtl/sfsb_eng_b2h.sv), [rtl/sfsb_eng_enc.sv](rtl/sfsb_eng_enc.sv), [rtl/sfsb_eng_dec.sv](rtl/sfsb_eng_dec.sv); adapters: host [rtl/sfsb_host_mux.sv](rtl/sfsb_host_mux.sv), NAND controller [rtl/sfsb_nand_port.sv](rtl/sfsb_nand_port.sv), firmware [rtl/sfsb_fw_port.sv](rtl/sfsb_fw_port.sv), external DRAM [rtl/sfsb_meta_cache.sv](rtl/sfsb_meta_cache.sv) |
| Memory wrappers | [rtl/sfsb_sram_bank.sv](rtl/sfsb_sram_bank.sv) over the SRAM library's `sram_sp`; ECC [rtl/sfsb_ecc64.sv](rtl/sfsb_ecc64.sv) over RAS SECDED |
| Arbitration logic | [rtl/sfsb_bank_xbar.sv](rtl/sfsb_bank_xbar.sv), [rtl/sfsb_host_mux.sv](rtl/sfsb_host_mux.sv), WRR + CQ arbiter in [rtl/sfsb_dispatch.sv](rtl/sfsb_dispatch.sv) |
| Tests | [tb/tb_sfsb.sv](tb/tb_sfsb.sv) (16 tests), [tb/tb_sfsb_nand.sv](tb/tb_sfsb_nand.sv) (DoD integration), [tb/sfsb_tb_common.svh](tb/sfsb_tb_common.svh), [tb/sfsb_tb_mem.sv](tb/sfsb_tb_mem.sv); [scripts/regress.py](scripts/regress.py), [scripts/mutate.py](scripts/mutate.py) |
| Performance instrumentation | [rtl/sfsb_perf.sv](rtl/sfsb_perf.sv), [scripts/perf.py](scripts/perf.py), [reports/perf.md](reports/perf.md) |
| SRAM synthesis report | [reports/synth.md](reports/synth.md), [docs/08_SYNTHESIS.md](docs/08_SYNTHESIS.md), [scripts/synth.py](scripts/synth.py) |
| Firmware interface | [docs/REGISTERS.md](docs/REGISTERS.md), generated [sw/include/sfsb_regs.h](sw/include/sfsb_regs.h), [sw/example/sfsb_write_page.c](sw/example/sfsb_write_page.c) |

## Quick start

Tools (Ubuntu 24.04 packages): Verilator 5.020, Icarus Verilog 12, Yosys 0.33, Python 3.

```bash
sudo apt-get install -y verilator iverilog yosys
```

```bash
make sim
```

```bash
make integ
```

```bash
make regress
```

```bash
make lint perf synth mutate
```

* `make sim` builds the 16-test suite on Verilator (~1 min) and runs it (< 1 s); `TEST=<name>` selects one test.
* `make integ` runs the definition-of-done bench (Verilator, ~30 s build, ~3 s run); `make integ-iv` on Icarus (~20 min).
* `make regress` runs every configuration on Verilator, two on Icarus, and the integration bench on both.
* `make vendor-check REPO=<path to the Aureom.AI checkout>` proves the vendored files are byte-identical.

## Layout

```
rtl/          BufferCore RTL (16 modules), sfsb_defs.svh (encodings, CSR map), sfsb_funcs.svh (CRC-32C), files.f
tb/           tb_sfsb.sv (suite), tb_sfsb_nand.sv (DoD integration), shared BFM/scoreboard, host/DRAM model, file lists
config/       nandlab_p55/nandlab.svcfg (NANDLab geometry for the integration bench)
scripts/      regress, lint, perf, synth (+ report), mutate, check_vendor, gen_header
sw/           generated C header + compile-checked firmware example
synth/yosys/  synthesis logs and stat dumps
reports/      regression, lint, perf, synth, mutation reports; sim/ logs
docs/         00 audit … 09 limitations, REGISTERS
third_party/  unmodified SilicaFlux sources (SRAM library, RAS, DataFabric checker, FlashLink + NANDLab, MemoryBridge)
```
