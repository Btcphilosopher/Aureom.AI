// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_fw_port   (control-firmware access)
// SFB2 slave (32-bit) for the ControlCore (Project 21, EXT master port / an
// accelerator page).  Three windows inside a 16 MiB region (addr[23:0]):
//
//   0x000000 CSR     registers (docs/REGISTERS.md): configuration, descriptor
//                    staging + SUBMIT, completion queue, slot commands,
//                    metadata inspection, fault injection, perf counters
//   0x100000 BUF     direct load/store into the buffer SRAM, 32-bit aligned,
//                    byte strobes; OWNERSHIP-CHECKED by the buffer manager:
//                    write -> slot owned by firmware and not locked by any
//                    engine; read -> slot allocated and not write-locked.
//                    Parity of the accessed lanes is checked on reads.
//   0x800000 DRAM    external-DRAM metadata window through sfsb_meta_cache
//                    (EXT_DRAM_EN = 1), else unmapped.
//
// Errors (rsp_error = 1, rdata = 0, no side effect): unmapped offset, CSR
// sub-word write, misaligned access, ownership violation, buffer parity error,
// DRAM error.  One transaction at a time; every response >= 1 cycle after
// acceptance (SFB2 R5).  Register side effects happen in the acceptance cycle,
// so a SUBMIT / SCMD result is readable by the very next access.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfsb_defs.svh"
`default_nettype none

module sfsb_fw_port #(
  parameter int NDS         = 8,
  parameter int NPS         = 4,
  parameter int NB          = 4,
  parameter int PAGE_LBS    = 4,
  parameter int LB_BYTES    = 512,
  parameter int WAW         = 12,
  parameter int RW          = 10,
  parameter int TOTAL_BEATS = 4096,
  parameter int PS_BASE     = 2048,
  parameter int PSLOT_BEATS = 296,
  parameter int PIMG_BEATS  = 293,
  parameter int CRYPTO_EN   = 1,
  parameter int EXT_DRAM_EN = 0,
  parameter int PLP_PRESENT = 0,
  parameter int DRAM_WIN    = 1 << 20,
  parameter int PC_NUM      = `SFSB_PC_NUM,
  parameter int CQAW        = 3,
  localparam int OW         = $clog2(DRAM_WIN)
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  // SFB2 slave
  input  wire logic                 s_req_valid,
  output logic                      s_req_ready,
  input  wire logic                 s_req_write,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [31:0]          s_req_addr,       // [31:24] decoded by the system interconnect
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [31:0]          s_req_wdata,
  input  wire logic [3:0]           s_req_wstrb,
  output logic                      s_rsp_valid,
  input  wire logic                 s_rsp_ready,
  output logic      [31:0]          s_rsp_rdata,
  output logic                      s_rsp_error,
  // configuration
  output logic                      cfg_en,
  output logic                      cfg_irq_en,
  output logic                      cfg_wce,
  output logic      [7:0]           w_host,
  output logic      [7:0]           w_gc,
  output logic      [63:0]          key,
  // descriptor submission
  output logic      [`SFSB_DESC_W-1:0] desc,
  output logic                      submit,
  input  wire logic [7:0]           sub_code,
  // completion queue
  input  wire logic                 cq_nonempty,
  input  wire logic [`SFSB_CPL_W-1:0] cq_head,
  input  wire logic [CQAW:0]        cq_count,
  output logic                      cq_pop,
  // slot commands
  output logic                      cmd_valid,
  output logic      [3:0]           cmd_op,
  output logic      [7:0]           cmd_slot,
  output logic                      cmd_flag,
  output logic      [31:0]          cmd_lba,
  output logic      [31:0]          cmd_cnt,
  input  wire logic [7:0]           cmd_code,
  input  wire logic [7:0]           cmd_rslot,
  input  wire logic                 cmd_hit,
  input  wire logic [3:0]           cmd_rlb,
  // metadata inspection
  output logic      [7:0]           dbg_d,
  output logic      [3:0]           dbg_lb,
  input  wire logic [31:0]          dbg_lba,
  input  wire logic [31:0]          dbg_crc,
  input  wire logic [31:0]          dbg_flags,
  output logic      [7:0]           dbg_p,
  input  wire logic [31:0]          dbg_pflags,
  // status
  input  wire logic                 init_done,
  input  wire logic                 pwr_fail,
  input  wire logic                 busy,
  input  wire logic [7:0]           dirty_cnt,
  input  wire logic [7:0]           ds_alloc_cnt,
  input  wire logic [7:0]           ds_cached_cnt,
  input  wire logic [7:0]           ps_alloc_cnt,
  input  wire logic [7:0]           ps_nand_cnt,
  // fault injection
  output logic                      fi_arm,
  output logic      [7:0]           fi_bank,
  output logic      [RW-1:0]        fi_row,
  output logic      [71:0]          fi_mask,
  input  wire logic                 fi_fire,
  // performance counters
  output logic                      perf_clear,
  output logic                      perf_freeze,
  input  wire logic [PC_NUM*32-1:0] perf_cnt,
  output logic                      mc_inval,
  // buffer window -> bank port 0
  output logic      [WAW-1:0]       fwa_wa,
  output logic                      fwa_we,
  input  wire logic                 fwa_ok,
  output logic                      bp_req_valid,
  input  wire logic                 bp_req_ready,
  output logic                      bp_req_we,
  output logic      [WAW-1:0]       bp_req_addr,
  output logic      [63:0]          bp_req_wdata,
  output logic      [7:0]           bp_req_be,
  input  wire logic                 bp_rsp_valid,
  input  wire logic [63:0]          bp_rsp_rdata,
  input  wire logic [7:0]           bp_rsp_perr,
  input  wire logic                 bp_rsp_rerr,
  // DRAM window -> metadata cache
  output logic                      c_req_valid,
  input  wire logic                 c_req_ready,
  output logic                      c_req_write,
  output logic      [OW-1:0]        c_req_off,
  output logic      [31:0]          c_req_wdata,
  output logic      [3:0]           c_req_wstrb,
  input  wire logic                 c_rsp_valid,
  input  wire logic [31:0]          c_rsp_rdata,
  input  wire logic                 c_rsp_err
);
  typedef enum logic [2:0] {S_IDLE, S_BISSUE, S_BWAIT, S_CREQ, S_CWAIT, S_RESP} st_t;
  st_t st;

  // ------------------------------------------------------------ decode
  wire [23:0] off     = s_req_addr[23:0];
  wire        r_csr   = (off < 24'h001000);
  wire [23:0] boff    = off - `SFSB_WIN_BUF;
  wire        r_buf   = (off >= `SFSB_WIN_BUF) && (32'(boff) < TOTAL_BEATS * 8);
  wire [23:0] doff    = off - `SFSB_WIN_DRAM;
  wire        r_dram  = (EXT_DRAM_EN != 0) && (off >= `SFSB_WIN_DRAM) && (32'(doff) < DRAM_WIN);
  wire        aligned = (off[1:0] == 2'b00);
  wire [11:0] ra      = off[11:0];

  assign s_req_ready = (st == S_IDLE);
  wire acc   = s_req_valid && s_req_ready;
  wire acc_w = acc && s_req_write;
  wire csr_w = acc_w && r_csr && aligned && (s_req_wstrb == 4'hF);

  assign fwa_wa = WAW'(boff[23:3]);
  assign fwa_we = s_req_write;

  // ------------------------------------------------------------ registers
  logic [31:0] desc_r [4];
  logic [8:0]  sub_last;
  logic [31:0] srsp, sarg_lba, sarg_cnt;
  logic [11:0] msel;
  logic [7:0]  psel;
  logic        fi_fired;
  logic        en_q, irq_q, wce_q;

  assign cfg_en     = en_q;
  assign cfg_irq_en = irq_q;
  assign cfg_wce    = wce_q;
  // internal layout: sfsb_defs.svh SFSB_DF_*
  assign desc = {desc_r[3],                          // [103:72] LBA
                 desc_r[2],                          // [71:40]  host address
                 desc_r[0][23:20], desc_r[0][19:16], // [39:36] LB_COUNT, [35:32] LB_FIRST
                 desc_r[1][15:8], desc_r[1][7:0],    // [31:24] PSLOT, [23:16] DSLOT
                 1'b0, desc_r[0][7], desc_r[0][5:4], // [15] rsv, [14] CRYPT, [13:12] CLASS
                 desc_r[0][15:8], desc_r[0][3:0]};   // [11:4] TID, [3:0] OPC
  assign dbg_d  = msel[7:0];
  assign dbg_lb = msel[11:8];
  assign dbg_p  = psel;

  // writes with side effects in the acceptance cycle
  assign submit    = csr_w && (ra == `SFSB_CSR_SUBMIT);
  assign cq_pop    = csr_w && (ra == `SFSB_CSR_CPL_POP);
  assign cmd_valid = csr_w && (ra == `SFSB_CSR_SCMD);
  assign cmd_op    = s_req_wdata[3:0];
  assign cmd_slot  = s_req_wdata[15:8];
  assign cmd_flag  = s_req_wdata[16];
  assign cmd_lba   = sarg_lba;
  assign cmd_cnt   = sarg_cnt;
  assign mc_inval  = csr_w && (ra == `SFSB_CSR_MC_CTRL) && s_req_wdata[0];
  assign perf_clear = csr_w && (ra == `SFSB_CSR_PERF_CTRL) && s_req_wdata[0];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      en_q <= 1'b0; irq_q <= 1'b0; wce_q <= 1'b0; w_host <= 8'd4; w_gc <= 8'd1; key <= '0;
      for (int i = 0; i < 4; i++) desc_r[i] <= '0;
      sub_last <= '0; srsp <= '0; sarg_lba <= '0; sarg_cnt <= '0; msel <= '0; psel <= '0;
      fi_arm <= 1'b0; fi_fired <= 1'b0; fi_bank <= '0; fi_row <= '0; fi_mask <= '0;
      perf_freeze <= 1'b0;
    end else begin
      if (fi_fire) begin fi_arm <= 1'b0; fi_fired <= 1'b1; end
      if (csr_w) begin
        case (ra)
          `SFSB_CSR_CFG:      begin en_q <= s_req_wdata[0]; irq_q <= s_req_wdata[1]; wce_q <= s_req_wdata[2];
                                    w_host <= s_req_wdata[15:8]; w_gc <= s_req_wdata[23:16]; end
          `SFSB_CSR_KEY_LO:   key[31:0]  <= s_req_wdata;
          `SFSB_CSR_KEY_HI:   key[63:32] <= s_req_wdata;
          `SFSB_CSR_DESC0:    desc_r[0] <= s_req_wdata;
          `SFSB_CSR_DESC1:    desc_r[1] <= s_req_wdata;
          `SFSB_CSR_DESC2:    desc_r[2] <= s_req_wdata;
          `SFSB_CSR_DESC3:    desc_r[3] <= s_req_wdata;
          `SFSB_CSR_SUBMIT:   sub_last <= {(sub_code == `SFSB_SUB_OK), sub_code};
          `SFSB_CSR_SCMD:     srsp <= {8'd0, cmd_rlb, 3'd0, cmd_hit, cmd_rslot, cmd_code};
          `SFSB_CSR_SARG_LBA: sarg_lba <= s_req_wdata;
          `SFSB_CSR_SARG_CNT: sarg_cnt <= s_req_wdata;
          `SFSB_CSR_MSEL:     msel <= s_req_wdata[11:0];
          `SFSB_CSR_PSEL:     psel <= s_req_wdata[7:0];
          `SFSB_CSR_FI_CTRL:  begin fi_arm <= s_req_wdata[0]; fi_fired <= 1'b0; fi_bank <= s_req_wdata[15:8]; end
          `SFSB_CSR_FI_ROW:   fi_row <= RW'(s_req_wdata);
          `SFSB_CSR_FI_MASK0: fi_mask[31:0]  <= s_req_wdata;
          `SFSB_CSR_FI_MASK1: fi_mask[63:32] <= s_req_wdata;
          `SFSB_CSR_FI_MASK2: fi_mask[71:64] <= s_req_wdata[7:0];
          `SFSB_CSR_PERF_CTRL: perf_freeze <= s_req_wdata[1];
          default: ;
        endcase
      end
    end
  end

  // ------------------------------------------------------------ CSR read mux
  localparam logic [31:0] PARAM0 = {1'b0, PLP_PRESENT[0], EXT_DRAM_EN[0], CRYPTO_EN[0],
                                    4'($clog2(LB_BYTES)), 4'(PAGE_LBS), 4'($clog2(NB)), 8'(NPS), 8'(NDS)};
  localparam logic [31:0] PARAM1 = {16'(PIMG_BEATS), 16'(PSLOT_BEATS)};

  logic [31:0] rd;
  logic        rd_ok;
  /* verilator lint_off UNUSEDSIGNAL */
  wire  [11:0] poff = ra - `SFSB_CSR_PERF_BASE;      // [1:0]: byte offset, word-aligned access
  /* verilator lint_on UNUSEDSIGNAL */
  wire  [31:0] pidx = {22'd0, poff[11:2]};
  always_comb begin
    rd    = '0;
    rd_ok = 1'b1;
    case (ra)
      `SFSB_CSR_ID:       rd = 32'h5346_5342;            // "SFSB"
      `SFSB_CSR_VERSION:  rd = 32'h3701_0000;            // project 55, v1.0
      `SFSB_CSR_PARAM0:   rd = PARAM0;
      `SFSB_CSR_PARAM1:   rd = PARAM1;
      `SFSB_CSR_PARAM2:   rd = 32'(PS_BASE * 8);
      `SFSB_CSR_PARAM3:   rd = 32'(TOTAL_BEATS * 8);
      `SFSB_CSR_CFG:      rd = {8'd0, w_gc, w_host, 5'd0, wce_q, irq_q, en_q};
      `SFSB_CSR_STATUS:   rd = {8'(cq_count), dirty_cnt, 12'd0,
                                (wce_q || PLP_PRESENT != 0), busy, pwr_fail, init_done};
      `SFSB_CSR_OCC:      rd = {ps_nand_cnt, ps_alloc_cnt, ds_cached_cnt, ds_alloc_cnt};
      `SFSB_CSR_KEY_LO, `SFSB_CSR_KEY_HI: rd = 32'd0;    // write-only
      `SFSB_CSR_DESC0:    rd = desc_r[0];
      `SFSB_CSR_DESC1:    rd = desc_r[1];
      `SFSB_CSR_DESC2:    rd = desc_r[2];
      `SFSB_CSR_DESC3:    rd = desc_r[3];
      `SFSB_CSR_SUBMIT:   rd = {23'd0, sub_last};
      `SFSB_CSR_CPL_STAT: rd = {16'd0, 8'(cq_count), 7'd0, cq_nonempty};
      `SFSB_CSR_CPL0:     rd = cq_nonempty ? cq_head[31:0]  : 32'd0;
      `SFSB_CSR_CPL1:     rd = cq_nonempty ? cq_head[63:32] : 32'd0;
      `SFSB_CSR_CPL2:     rd = cq_nonempty ? cq_head[95:64] : 32'd0;
      `SFSB_CSR_CPL_POP:  rd = 32'd0;
      `SFSB_CSR_SCMD:     rd = 32'd0;
      `SFSB_CSR_SRSP:     rd = srsp;
      `SFSB_CSR_SARG_LBA: rd = sarg_lba;
      `SFSB_CSR_SARG_CNT: rd = sarg_cnt;
      `SFSB_CSR_MSEL:     rd = {20'd0, msel};
      `SFSB_CSR_MLBA:     rd = dbg_lba;
      `SFSB_CSR_MCRC:     rd = dbg_crc;
      `SFSB_CSR_MFLAGS:   rd = dbg_flags;
      `SFSB_CSR_PSEL:     rd = {24'd0, psel};
      `SFSB_CSR_PINFO:    rd = dbg_pflags;
      `SFSB_CSR_FI_CTRL:  rd = {16'd0, fi_bank, 6'd0, fi_fired, fi_arm};
      `SFSB_CSR_FI_ROW:   rd = 32'(fi_row);
      `SFSB_CSR_FI_MASK0: rd = fi_mask[31:0];
      `SFSB_CSR_FI_MASK1: rd = fi_mask[63:32];
      `SFSB_CSR_FI_MASK2: rd = {24'd0, fi_mask[71:64]};
      `SFSB_CSR_MC_CTRL:  rd = 32'd0;
      `SFSB_CSR_PERF_CTRL: rd = {30'd0, perf_freeze, 1'b0};
      default: begin
        if (ra >= `SFSB_CSR_PERF_BASE && pidx < PC_NUM) rd = perf_cnt[32*pidx[5:0] +: 32];
        else rd_ok = 1'b0;
      end
    endcase
  end

  // ------------------------------------------------------------ transaction FSM
  logic           we_q, hi_q;
  logic [WAW-1:0] wa_q;
  logic [31:0]    wd_q;
  logic [3:0]     ws_q;
  logic [OW-1:0]  co_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; s_rsp_rdata <= '0; s_rsp_error <= 1'b0;
      we_q <= 1'b0; hi_q <= 1'b0; wa_q <= '0; wd_q <= '0; ws_q <= '0; co_q <= '0;
    end else begin
      case (st)
        S_IDLE: if (acc) begin
          we_q <= s_req_write; hi_q <= off[2]; wa_q <= fwa_wa; wd_q <= s_req_wdata; ws_q <= s_req_wstrb;
          co_q <= OW'(doff);
          s_rsp_rdata <= '0;
          s_rsp_error <= 1'b0;
          st <= S_RESP;
          if (!aligned) s_rsp_error <= 1'b1;
          else if (r_csr) begin
            if (!rd_ok || (s_req_write && s_req_wstrb != 4'hF)) s_rsp_error <= 1'b1;
            else if (!s_req_write) s_rsp_rdata <= rd;
          end else if (r_buf) begin
            if (fwa_ok) st <= S_BISSUE;
            else        s_rsp_error <= 1'b1;
          end else if (r_dram) begin
            st <= S_CREQ;
          end else begin
            s_rsp_error <= 1'b1;
          end
        end
        S_BISSUE: if (bp_req_ready) st <= S_BWAIT;
        S_BWAIT: if (bp_rsp_valid) begin
          if (bp_rsp_rerr || (!we_q && (|(bp_rsp_perr & (hi_q ? 8'hF0 : 8'h0F))))) begin
            s_rsp_error <= 1'b1;
          end else if (!we_q) begin
            s_rsp_rdata <= hi_q ? bp_rsp_rdata[63:32] : bp_rsp_rdata[31:0];
          end
          st <= S_RESP;
        end
        S_CREQ: if (c_req_ready) st <= S_CWAIT;
        S_CWAIT: if (c_rsp_valid) begin
          s_rsp_error <= c_rsp_err;
          s_rsp_rdata <= c_rsp_err ? 32'd0 : c_rsp_rdata;
          st <= S_RESP;
        end
        S_RESP: if (s_rsp_ready) st <= S_IDLE;
        default: st <= S_IDLE;
      endcase
    end
  end

  assign s_rsp_valid  = (st == S_RESP);
  assign bp_req_valid = (st == S_BISSUE);
  assign bp_req_we    = we_q;
  assign bp_req_addr  = wa_q;
  assign bp_req_wdata = {wd_q, wd_q};
  assign bp_req_be    = hi_q ? {ws_q, 4'd0} : {4'd0, ws_q};
  assign c_req_valid  = (st == S_CREQ);
  assign c_req_write  = we_q;
  assign c_req_off    = co_q;
  assign c_req_wdata  = wd_q;
  assign c_req_wstrb  = ws_q;

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = ^desc_r[1][31:16] ^ ^desc_r[0][31:24] ^ desc_r[0][6];
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
