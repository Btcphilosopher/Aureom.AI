// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_ecc_enc64 / sfsb_ecc_dec64
// Inner code of the NAND codeword ECC: the verified extended-Hamming SECDED
// encoder/decoder of SilicaFlux RAS (Project 26, vendored unmodified under
// third_party/silicaflux-ras) with K = 64 -> (72,64): one 8-bit check byte
// per 64-bit data beat (7 Hamming check bits + overall parity).
//
// Erased-page convention.  NAND reads an erased (never programmed) page as
// all ones.  The check-bit inversion mask INV is chosen so that the
// all-ones 72-bit word is a VALID codeword (data = all ones, no error):
//     INV[6:0] = ~chk(all-ones data),  INV[7] = ~parity(all-ones codeword)
// so an erased codeword decodes cleanly and the engine recognises it by its
// all-ones OOB metadata (LBA = 32'hFFFF_FFFF).  This is the opposite of
// RAS's default memory INV (which makes all-ones UNCORRECTABLE to catch
// stuck word lines): a NAND array is a different medium.
//
// The codeword framing (data beats, then check-byte beats) lives in the
// engines (sfsb_eng_enc / sfsb_eng_dec); see docs/02_DATA_PATH.md.
// Classification: SYNTHESIZABLE (combinational)
// =============================================================================
`include "sfsb_defs.svh"
`default_nettype none

/* verilator lint_off DECLFILENAME */
module sfsb_ecc_enc64 (
  input  wire logic [63:0] data_i,
  output logic      [7:0]  chk_o
);
  /* verilator lint_off VARHIDDEN */
  `include "sfras_ecc_funcs.svh"
  /* verilator lint_on VARHIDDEN */

  function automatic integer sfsb_nand_inv(input integer k);
    integer oc, p1;
    begin
      oc = sfras_ecc_ones_chk(k);
      p1 = sfras_ecc_par(oc) ^ (k & 1);
      sfsb_nand_inv = ((~oc) & 127) | (((p1 ^ 1) & 1) << 7);
    end
  endfunction

  localparam int INV = sfsb_nand_inv(64);

  logic [71:0] cw;
  sfras_secded_enc #(.K(64), .INV(INV)) u_enc (.data_i(data_i), .cw_o(cw));
  assign chk_o = cw[71:64];

  /* verilator lint_off UNUSEDSIGNAL */
  wire [63:0] unused_data = cw[63:0];
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

module sfsb_ecc_dec64 (
  input  wire logic [63:0] data_i,
  input  wire logic [7:0]  chk_i,
  output logic      [63:0] data_o,    // corrected (raw on UE)
  output logic             ce_o,      // one bit corrected (data or check bit)
  output logic             ue_o       // uncorrectable
);
  /* verilator lint_off VARHIDDEN */
  `include "sfras_ecc_funcs.svh"
  /* verilator lint_on VARHIDDEN */

  function automatic integer sfsb_nand_inv(input integer k);
    integer oc, p1;
    begin
      oc = sfras_ecc_ones_chk(k);
      p1 = sfras_ecc_par(oc) ^ (k & 1);
      sfsb_nand_inv = ((~oc) & 127) | (((p1 ^ 1) & 1) << 7);
    end
  endfunction

  localparam int INV = sfsb_nand_inv(64);

  /* verilator lint_off UNUSEDSIGNAL */
  logic [71:0] cw_corr;
  logic        none, ue_inval, ce_data;
  logic [6:0]  err_idx;
  logic [7:0]  syn;
  /* verilator lint_on UNUSEDSIGNAL */

  sfras_secded_dec #(.K(64), .INV(INV)) u_dec (
    .cw_i({chk_i, data_i}), .data_o(data_o), .cw_corr_o(cw_corr),
    .none_o(none), .ce_o(ce_o), .ue_o(ue_o), .ue_inval_o(ue_inval),
    .ce_data_o(ce_data), .err_idx_o(err_idx), .syn_o(syn)
  );
endmodule

`default_nettype wire
