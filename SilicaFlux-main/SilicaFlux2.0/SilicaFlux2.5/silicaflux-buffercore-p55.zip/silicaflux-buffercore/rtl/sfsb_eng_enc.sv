// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_eng_enc   (write path, page assembly)
//   data slot --> [V1 CRC verify] --> [optional crypt] --> ECC encode --> page slot
//
// For each logical block j of the descriptor (codeword j of the page):
//   1. read the LB_BEATS plaintext beats from the data slot (bank reads,
//      reserved FIFO space = the ECC input buffer);
//   2. fold each beat into CRC-32C (V1) and check its parity lanes;
//   3. optionally XOR the crypt keystream (tweak = the block's LBA and beat);
//   4. SECDED-encode each beat (P26 encoder, K = 64) -> 1 check byte; write the
//      beat to codeword j's data area, and every 8 beats one beat of check
//      bytes to codeword j's parity area (the ECC output buffer is the write
//      queue in front of the bank port);
//   5. write the OOB metadata beat j = {CRC32C, LBA} - the ORIGINAL check value
//      from the metadata buffer (generated at G1), never a recomputed one - and
//      its SECDED check byte into byte j of the OOB parity beat (byte-enable
//      write: only lane j changes).
// At the end of block j the recomputed CRC must equal the stored one (V1). A
// mismatch or a parity error marks the page slot BAD: the buffer manager then
// refuses to hand that page to the NAND controller (P2NAND -> BAD_PAGE), so
// corrupted data cannot be programmed silently.
//
// Page image layout (beats of 8 bytes, CW = LB_BEATS + LB_BEATS/8):
//   codeword j : [j*CW, j*CW+LB_BEATS)          data
//                [j*CW+LB_BEATS, (j+1)*CW)       check bytes (byte i = beat i)
//   OOB        : PAGE_LBS*CW + j                 {CRC32C[63:32], LBA[31:0]}
//                PAGE_LBS*CW + PAGE_LBS          check byte of OOB beat j in lane j
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfsb_defs.svh"
`default_nettype none

module sfsb_eng_enc #(
  parameter int LB_BEATS    = 64,
  parameter int PAGE_LBS    = 4,
  parameter int WAW         = 12,
  parameter int DSB_LOG2    = 8,
  parameter int PS_BASE     = 2048,
  parameter int PSLOT_BEATS = 296,
  parameter int FD          = 8,
  parameter int CRYPTO_EN   = 1,
  localparam int DW_        = `SFSB_DESC_W,
  localparam int CW_        = `SFSB_CPL_W
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic [63:0]    key,
  input  wire logic           desc_valid,
  input  wire logic [DW_-1:0] desc,
  output logic                desc_take,
  // bank read port (data slot)
  output logic                rp_req_valid,
  input  wire logic           rp_req_ready,
  output logic      [WAW-1:0] rp_req_addr,
  input  wire logic           rp_rsp_valid,
  input  wire logic [63:0]    rp_rsp_rdata,
  input  wire logic [7:0]     rp_rsp_perr,
  input  wire logic           rp_rsp_rerr,
  // bank write port (page slot)
  output logic                wp_req_valid,
  input  wire logic           wp_req_ready,
  output logic      [WAW-1:0] wp_req_addr,
  output logic      [63:0]    wp_req_wdata,
  output logic      [7:0]     wp_req_be,
  input  wire logic           wp_rsp_valid,
  input  wire logic           wp_rsp_rerr,
  // metadata (expected check value and LBA of block j)
  output logic      [7:0]     rd_d,
  output logic      [3:0]     rd_lb,
  input  wire logic [31:0]    rd_crc,
  input  wire logic [31:0]    rd_lba,
  output logic                bad,
  output logic      [7:0]     bad_p,
  // lock release + completion
  output logic                rel,
  output logic      [7:0]     rel_d,
  output logic      [7:0]     rel_p,
  output logic                cpl_valid,
  output logic      [CW_-1:0] cpl_data,
  input  wire logic           cpl_ready,
  output logic                active,
  output logic                ev_beat,
  output logic                ev_ecc_wait
);
  `include "sfsb_funcs.svh"

  localparam int PAR_BEATS = LB_BEATS / 8;
  localparam int CWB       = LB_BEATS + PAR_BEATS;
  localparam int OOB       = PAGE_LBS * CWB;
  localparam int CNTW      = 16;
  localparam int FAW       = $clog2(FD);
  localparam int LBB       = $clog2(LB_BEATS);

  typedef enum logic [2:0] {S_IDLE, S_DATA, S_PAR, S_META, S_OOBP, S_DRAIN, S_CPL} st_t;
  st_t st;

  /* verilator lint_off UNUSEDSIGNAL */
  logic [DW_-1:0]  d;                    // not every descriptor field is used by this engine
  logic            f_full;               // never full: space is reserved before issue
  /* verilator lint_on UNUSEDSIGNAL */
  logic [CNTW-1:0] tot, rd_iss, rd_rcv, wr_iss, wr_ack;
  logic [31:0]     crc, elapsed, crc_fin;
  logic [7:0]      lb_err, eflags;
  logic [LBB-1:0]  bib;
  logic [3:0]      k;
  logic            lb_par;
  logic [63:0]     chk_acc;
  logic [7:0]      mchk;

  wire [3:0]  j     = `SFSB_DF_LBF(d) + k;
  wire [WAW-1:0] dbase = WAW'((32'(`SFSB_DF_DSLOT(d)) << DSB_LOG2) + 32'(`SFSB_DF_LBF(d)) * LB_BEATS);
  wire [WAW-1:0] pbase = WAW'(PS_BASE + 32'(`SFSB_DF_PSLOT(d)) * PSLOT_BEATS);
  wire [WAW-1:0] cwbase = pbase + WAW'(32'(j) * CWB);

  // ------------------------------------------------------------ data-slot reader
  logic         f_empty, f_pop;
  logic [64:0]  f_rd;
  logic [FAW:0] f_cnt;
  wire [CNTW-1:0] inflight = rd_iss - rd_rcv;
  wire credit_ok = ({1'b0, inflight} + {{(CNTW-FAW){1'b0}}, f_cnt}) < (CNTW+1)'(FD);
  wire running   = (st == S_DATA) || (st == S_PAR) || (st == S_META) || (st == S_OOBP);

  assign rp_req_valid = running && (rd_iss < tot) && credit_ok;
  assign rp_req_addr  = dbase + WAW'(rd_iss);
  wire   r_acc        = rp_req_valid && rp_req_ready;

  sfsb_fifo #(.W(65), .DEPTH(FD)) u_f (
    .clk, .rst_n, .push(rp_rsp_valid), .wdata({(|rp_rsp_perr) || rp_rsp_rerr, rp_rsp_rdata}),
    .pop(f_pop), .rdata(f_rd), .full(f_full), .empty(f_empty), .count(f_cnt)
  );

  // ------------------------------------------------------------ write queue (ECC output buffer)
  logic          q_push, q_full, q_empty;
  logic [WAW+71:0] q_wd, q_rd;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [2:0]    q_cnt;
  /* verilator lint_on UNUSEDSIGNAL */
  sfsb_fifo #(.W(WAW + 72), .DEPTH(4)) u_wq (
    .clk, .rst_n, .push(q_push), .wdata(q_wd), .pop(wp_req_valid && wp_req_ready),
    .rdata(q_rd), .full(q_full), .empty(q_empty), .count(q_cnt)
  );
  assign wp_req_valid = !q_empty;
  assign {wp_req_addr, wp_req_be, wp_req_wdata} = q_rd;

  // ------------------------------------------------------------ transform + encode
  wire [63:0] plain  = f_rd[63:0];
  wire [63:0] ks     = sfsb_keystream(key, rd_lba, 16'(bib));
  wire [63:0] xform  = (CRYPTO_EN != 0 && `SFSB_DF_CRYPT(d)) ? (plain ^ ks) : plain;
  logic [7:0] chk_d;
  sfsb_ecc_enc64 u_enc_d (.data_i(xform), .chk_o(chk_d));

  wire [63:0] meta_beat = {rd_crc, rd_lba};
  logic [7:0] chk_m;
  sfsb_ecc_enc64 u_enc_m (.data_i(meta_beat), .chk_o(chk_m));

  wire [31:0] crc_nx = sfsb_crc32c_beat(crc, plain);

  assign rd_d  = `SFSB_DF_DSLOT(d);
  assign rd_lb = j;

  wire [LBB-1:0] bib_m1 = bib - 1'b1;   // last data beat written (index of the check-byte beat = bib_m1 / 8)
  wire [LBB-1:0] par_i  = bib_m1 >> 3;
  wire take_beat = (st == S_DATA) && !f_empty && !q_full;
  assign f_pop   = take_beat;

  always_comb begin
    q_push = 1'b0;
    q_wd   = '0;
    case (st)
      S_DATA: if (take_beat) begin
        q_push = 1'b1;
        q_wd   = {cwbase + WAW'(bib), 8'hFF, xform};
      end
      S_PAR: if (!q_full) begin
        q_push = 1'b1;
        q_wd   = {cwbase + WAW'(LB_BEATS) + WAW'(par_i), 8'hFF, chk_acc};
      end
      S_META: if (!q_full) begin
        q_push = 1'b1;
        q_wd   = {pbase + WAW'(OOB) + WAW'(j), 8'hFF, meta_beat};
      end
      S_OOBP: if (!q_full) begin
        q_push = 1'b1;
        q_wd   = {pbase + WAW'(OOB + PAGE_LBS), 8'(1) << j[2:0], {8{mchk}}};
      end
      default: ;
    endcase
  end

  // ------------------------------------------------------------ control
  assign desc_take = (st == S_IDLE) && desc_valid;
  wire last_lb = (k + 1'b1 == `SFSB_DF_LBC(d));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; d <= '0; tot <= '0; rd_iss <= '0; rd_rcv <= '0; wr_iss <= '0; wr_ack <= '0;
      crc <= 32'hFFFF_FFFF; crc_fin <= '0; elapsed <= '0; lb_err <= '0; eflags <= '0; bib <= '0;
      k <= '0; lb_par <= 1'b0; chk_acc <= '0; mchk <= '0;
    end else begin
      if (st != S_IDLE) elapsed <= elapsed + 1'b1;
      if (r_acc)        rd_iss  <= rd_iss + 1'b1;
      if (rp_rsp_valid) rd_rcv  <= rd_rcv + 1'b1;
      if (q_push)       wr_iss  <= wr_iss + 1'b1;
      if (wp_rsp_valid) begin
        wr_ack <= wr_ack + 1'b1;
        if (wp_rsp_rerr) eflags[`SFSB_EF_BUF_PAR] <= 1'b1;
      end

      case (st)
        S_IDLE: if (desc_valid) begin
          d      <= desc;
          tot    <= CNTW'(32'(`SFSB_DF_LBC(desc)) * LB_BEATS);
          rd_iss <= '0; rd_rcv <= '0; wr_iss <= '0; wr_ack <= '0;
          crc    <= 32'hFFFF_FFFF; elapsed <= '0; lb_err <= '0; eflags <= '0; bib <= '0; k <= '0;
          lb_par <= 1'b0;
          st     <= S_DATA;
        end
        S_DATA: if (take_beat) begin
          crc <= crc_nx;
          lb_par <= lb_par || f_rd[64];
          chk_acc[8*bib[2:0] +: 8] <= chk_d;
          bib <= bib + 1'b1;
          if (bib[2:0] == 3'd7) st <= S_PAR;
        end
        S_PAR: if (!q_full) begin
          if (bib == '0) begin          // wrapped: all data beats of the block written
            crc_fin <= ~crc;
            st      <= S_META;
          end else begin
            st <= S_DATA;
          end
        end
        S_META: if (!q_full) begin
          mchk <= chk_m;
          if ((crc_fin != rd_crc) || lb_par) begin
            lb_err[j[2:0]] <= 1'b1;
            if (crc_fin != rd_crc) eflags[`SFSB_EF_CRC]     <= 1'b1;
            if (lb_par)            eflags[`SFSB_EF_BUF_PAR] <= 1'b1;
          end
          st <= S_OOBP;
        end
        S_OOBP: if (!q_full) begin
          crc    <= 32'hFFFF_FFFF;
          lb_par <= 1'b0;
          k      <= k + 1'b1;
          st     <= last_lb ? S_DRAIN : S_DATA;
        end
        S_DRAIN: if (q_empty && wr_ack == wr_iss) st <= S_CPL;
        S_CPL:   if (cpl_ready) st <= S_IDLE;
        default: st <= S_IDLE;
      endcase
    end
  end

  wire [7:0] status = eflags[`SFSB_EF_BUF_PAR] ? `SFSB_ST_BUF_PAR :
                      eflags[`SFSB_EF_CRC]     ? `SFSB_ST_CRC     : `SFSB_ST_OK;

  assign cpl_valid = (st == S_CPL);
  assign cpl_data  = {elapsed,
                      eflags, 8'd0, 16'd0,
                      lb_err, status, 2'b00, `SFSB_DF_CLS(d), `SFSB_DF_OPC(d), `SFSB_DF_TID(d)};
  assign bad       = cpl_valid && cpl_ready && (eflags != 8'd0);
  assign bad_p     = `SFSB_DF_PSLOT(d);
  assign rel       = cpl_valid && cpl_ready;
  assign rel_d     = `SFSB_DF_DSLOT(d);
  assign rel_p     = `SFSB_DF_PSLOT(d);
  assign active    = (st != S_IDLE);
  assign ev_beat   = take_beat;
  assign ev_ecc_wait = (st == S_DATA) && f_empty;
endmodule

`default_nettype wire
