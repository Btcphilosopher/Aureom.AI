// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_defs.svh
// Encodings shared by the RTL, the testbenches and the firmware header.
// A `define header, not a package: Yosys 0.33 cannot resolve package
// references in module parameter lists (same convention as silicaflux-sramlib
// and silicaflux-ras).  Values are part of the register contract: never
// renumber, only append.
// =============================================================================
`ifndef SFSB_DEFS_SVH
`define SFSB_DEFS_SVH

// ------------------------------------------------------------ descriptor opcodes
`define SFSB_OP_H2B       4'd1   // host memory  -> data slot          (host ingress)
`define SFSB_OP_B2H       4'd2   // data slot    -> host memory        (host egress)
`define SFSB_OP_ENC       4'd3   // data slot    -> [crypt] -> ECC enc -> page slot (NAND page image)
`define SFSB_OP_DEC       4'd4   // page slot    -> ECC dec -> [crypt] -> data slot

// ------------------------------------------------------------ traffic classes
`define SFSB_CLS_HOST     2'd0
`define SFSB_CLS_GC       2'd1

// ------------------------------------------------------------ submission codes (SUBMIT[7:0])
`define SFSB_SUB_OK        8'h00
`define SFSB_SUB_BAD_OPC   8'h01
`define SFSB_SUB_BAD_CLASS 8'h02
`define SFSB_SUB_BAD_LEN   8'h03   // LB_COUNT == 0
`define SFSB_SUB_RANGE     8'h04   // LB_FIRST + LB_COUNT > PAGE_LBS, or host range wraps
`define SFSB_SUB_SLOT      8'h05   // slot index out of range
`define SFSB_SUB_OWNER     8'h06   // slot state does not allow this operation
`define SFSB_SUB_BUSY      8'h07   // slot lock conflict
`define SFSB_SUB_ALIGN     8'h08   // host address not 8-byte aligned
`define SFSB_SUB_NOT_VALID 8'h09   // a source logical block holds no valid data
`define SFSB_SUB_POISON    8'h0A   // a source logical block is poisoned
`define SFSB_SUB_DUP_TID   8'h0B   // transaction ID already in flight
`define SFSB_SUB_QFULL     8'h0C   // descriptor queue of that engine/class is full
`define SFSB_SUB_DISABLED  8'h0D   // CFG.EN = 0 or buffer initialisation not done
`define SFSB_SUB_PWR       8'h0E   // power-fail asserted: no new volatile (H2B) data accepted
`define SFSB_SUB_UNSUP     8'h0F   // crypt flag set but CRYPTO_EN = 0

// ------------------------------------------------------------ completion status (CPL0[23:16])
`define SFSB_ST_OK         8'h00
`define SFSB_ST_CORRECTED  8'h01   // DEC: ECC corrected >= 1 bit, data good
`define SFSB_ST_ERASED     8'h02   // DEC: >= 1 codeword erased (never programmed), no error
`define SFSB_ST_UNCORR     8'h10   // DEC: ECC uncorrectable codeword
`define SFSB_ST_CRC        8'h11   // end-to-end CRC32C mismatch
`define SFSB_ST_LBA        8'h12   // stored LBA tag differs from the expected LBA
`define SFSB_ST_BUF_PAR    8'h13   // buffer SRAM parity error on a consumed lane
`define SFSB_ST_HOST_ERR   8'h14   // host memory bus error response
`define SFSB_ST_META_UE    8'h15   // OOB metadata beat uncorrectable

// error flag bits (CPL1[31:24])
`define SFSB_EF_BUF_PAR    0
`define SFSB_EF_CRC        1
`define SFSB_EF_LBA        2
`define SFSB_EF_UE         3
`define SFSB_EF_META_UE    4
`define SFSB_EF_HOST       5

// ------------------------------------------------------------ slot states
`define SFSB_DS_FREE      2'd0
`define SFSB_DS_FW        2'd1
`define SFSB_DS_CACHED    2'd2
`define SFSB_PS_FREE      2'd0
`define SFSB_PS_FW        2'd1
`define SFSB_PS_NAND      2'd2

// ------------------------------------------------------------ slot commands (SCMD[3:0])
`define SFSB_SC_ALLOC_D   4'd1
`define SFSB_SC_FREE_D    4'd2    // flag = DISCARD (allow freeing a dirty slot)
`define SFSB_SC_COMMIT_D  4'd3    // data slot contents are now durable on NAND: clear DIRTY
`define SFSB_SC_CACHE_D   4'd4    // FW -> CACHED (clean read cache)
`define SFSB_SC_CLAIM_D   4'd5    // CACHED -> FW
`define SFSB_SC_LOOKUP    4'd6    // read-cache lookup of SARG_LBA
`define SFSB_SC_INVAL     4'd7    // invalidate cached LBAs [SARG_LBA, SARG_LBA+SARG_CNT)
`define SFSB_SC_ALLOC_P   4'd8
`define SFSB_SC_FREE_P    4'd9
`define SFSB_SC_P2NAND    4'd10   // FW -> NAND: the NAND controller may access the page image
`define SFSB_SC_P2FW      4'd11   // NAND -> FW

// slot command result codes (SRSP[7:0])
`define SFSB_SR_OK        8'h00
`define SFSB_SR_BAD_CMD   8'h01
`define SFSB_SR_RANGE     8'h02
`define SFSB_SR_STATE     8'h03
`define SFSB_SR_BUSY      8'h04
`define SFSB_SR_DIRTY     8'h05
`define SFSB_SR_NOSPACE   8'h06
`define SFSB_SR_MISS      8'h07
`define SFSB_SR_BAD_PAGE  8'h08

// ------------------------------------------------------------ CSR offsets (firmware port)
`define SFSB_CSR_ID        12'h000
`define SFSB_CSR_VERSION   12'h004
`define SFSB_CSR_PARAM0    12'h008
`define SFSB_CSR_PARAM1    12'h00C
`define SFSB_CSR_PARAM2    12'h010
`define SFSB_CSR_PARAM3    12'h014
`define SFSB_CSR_CFG       12'h020
`define SFSB_CSR_STATUS    12'h024
`define SFSB_CSR_OCC       12'h028
`define SFSB_CSR_KEY_LO    12'h030
`define SFSB_CSR_KEY_HI    12'h034
`define SFSB_CSR_DESC0     12'h040
`define SFSB_CSR_DESC1     12'h044
`define SFSB_CSR_DESC2     12'h048
`define SFSB_CSR_DESC3     12'h04C
`define SFSB_CSR_SUBMIT    12'h050
`define SFSB_CSR_CPL_STAT  12'h060
`define SFSB_CSR_CPL0      12'h064
`define SFSB_CSR_CPL1      12'h068
`define SFSB_CSR_CPL2      12'h06C
`define SFSB_CSR_CPL_POP   12'h070
`define SFSB_CSR_SCMD      12'h080
`define SFSB_CSR_SRSP      12'h084
`define SFSB_CSR_SARG_LBA  12'h088
`define SFSB_CSR_SARG_CNT  12'h08C
`define SFSB_CSR_MSEL      12'h090
`define SFSB_CSR_MLBA      12'h094
`define SFSB_CSR_MCRC      12'h098
`define SFSB_CSR_MFLAGS    12'h09C
`define SFSB_CSR_PSEL      12'h0A0
`define SFSB_CSR_PINFO     12'h0A4
`define SFSB_CSR_FI_CTRL   12'h0B0
`define SFSB_CSR_FI_ROW    12'h0B4
`define SFSB_CSR_FI_MASK0  12'h0B8
`define SFSB_CSR_FI_MASK1  12'h0BC
`define SFSB_CSR_FI_MASK2  12'h0C0
`define SFSB_CSR_MC_CTRL   12'h0D0
`define SFSB_CSR_PERF_CTRL 12'h100
`define SFSB_CSR_PERF_BASE 12'h200

// firmware-port windows (byte offsets inside the 16 MiB firmware window)
`define SFSB_WIN_CSR      24'h000000   // 4 KiB
`define SFSB_WIN_BUF      24'h100000   // buffer SRAM, direct load/store (ownership-checked)
`define SFSB_WIN_DRAM     24'h800000   // external-DRAM metadata window (through the metadata cache)

// ------------------------------------------------------------ performance counter indices
`define SFSB_PC_CYCLES        0
`define SFSB_PC_SRAM_RD       1
`define SFSB_PC_SRAM_WR       2
`define SFSB_PC_OCC_SUM       3
`define SFSB_PC_OCC_MAX       4
`define SFSB_PC_H2B_BEATS     5
`define SFSB_PC_H2B_ACTIVE    6
`define SFSB_PC_B2H_BEATS     7
`define SFSB_PC_B2H_ACTIVE    8
`define SFSB_PC_ENC_BEATS     9
`define SFSB_PC_ENC_ACTIVE    10
`define SFSB_PC_DEC_BEATS     11
`define SFSB_PC_DEC_ACTIVE    12
`define SFSB_PC_ARB_STALL     13
`define SFSB_PC_ECC_WAIT      14
`define SFSB_PC_ECC_QWAIT     15
`define SFSB_PC_NAND_STARVE   16
`define SFSB_PC_NAND_BEATS    17
`define SFSB_PC_HOST_REQ_WAIT 18
`define SFSB_PC_HOST_RSP_WAIT 19
`define SFSB_PC_CQ_FULL       20
`define SFSB_PC_DESC_SUB      21
`define SFSB_PC_DESC_CPL      22
`define SFSB_PC_DESC_REJ      23
`define SFSB_PC_CACHE_LOOKUP  24
`define SFSB_PC_CACHE_HIT     25
`define SFSB_PC_EVICT         26
`define SFSB_PC_MC_HIT        27
`define SFSB_PC_MC_MISS       28
`define SFSB_PC_MAX_WAIT      29
`define SFSB_PC_PORT_STALL0   32   // 32 .. 32+NP-1 : per bank-port arbitration stall cycles
`define SFSB_PC_NUM           40

// ------------------------------------------------------------ elaboration checks
// Same convention as silicaflux-sramlib: Icarus 12 does not evaluate
// elaboration-time $fatal, so it gets a time-0 $fatal instead.
`ifdef __ICARUS__
  `define SFSB_CFG_FATAL(msg) initial $fatal(1, msg);
`else
  `define SFSB_CFG_FATAL(msg) $fatal(1, msg);
`endif

// ------------------------------------------------------------ internal descriptor layout
// DESC0 = {rsv[31:24], LB_COUNT[23:20], LB_FIRST[19:16], TID[15:8], CRYPT[7], rsv[6], CLASS[5:4], OPC[3:0]}
// DESC1 = {rsv[31:16], PSLOT[15:8], DSLOT[7:0]}   DESC2 = HOST_ADDR   DESC3 = LBA (first logical block)
`define SFSB_DESC_W        104
`define SFSB_DF_OPC(d)     d[3:0]
`define SFSB_DF_TID(d)     d[11:4]
`define SFSB_DF_CLS(d)     d[13:12]
`define SFSB_DF_CRYPT(d)   d[14]
`define SFSB_DF_DSLOT(d)   d[23:16]
`define SFSB_DF_PSLOT(d)   d[31:24]
`define SFSB_DF_LBF(d)     d[35:32]
`define SFSB_DF_LBC(d)     d[39:36]
`define SFSB_DF_HADDR(d)   d[71:40]
`define SFSB_DF_LBA(d)     d[103:72]

// completion entry: word0 = {LB_ERR_MASK[31:24], STATUS[23:16], rsv[15:14], CLASS[13:12], OPC[11:8], TID[7:0]}
//                   word1 = {ERR_FLAGS[31:24], ERASED_MASK[23:16], CORRECTED_BITS[15:0]}
//                   word2 = cycles from engine start to completion
`define SFSB_CPL_W         96

`endif
