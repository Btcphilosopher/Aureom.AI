// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_dispatch
// Descriptor submission, validation, per-engine queues, class arbitration,
// completion queue and transaction-ID tracking.
//
// Submission (one cycle, synchronous to the SUBMIT register write):
//   every check below is evaluated on the staged DESC0..3; the FIRST failing
//   check is returned in SUBMIT[7:0] and the descriptor is dropped without a
//   completion.  An accepted descriptor (code OK) is queued, its TID marked
//   in flight, and the buffer manager takes its slot locks in the same cycle.
//   Every accepted descriptor produces EXACTLY ONE completion; its TID stays
//   in flight until firmware pops that completion (so TIDs are unambiguous).
//     DISABLED, BAD_OPC, BAD_CLASS, BAD_LEN, RANGE (LB range), UNSUP (crypt),
//     ALIGN / RANGE (host address, H2B/B2H), PWR (H2B under power fail),
//     DUP_TID, QFULL, then the buffer manager's SLOT / OWNER / BUSY /
//     POISON / NOT_VALID.
//
// Queues: one FIFO for H2B, one for B2H, and two each (HOST, GC class) for
// the media engines ENC and DEC.  Media dispatch policy (per engine):
//   weighted round robin between HOST and GC: when both classes are waiting,
//   at most W_HOST consecutive HOST descriptors are dispatched before a GC
//   descriptor, and at most W_GC consecutive GC descriptors before a HOST
//   one (CFG.W_HOST / CFG.W_GC, 0 is treated as 1).  Work conserving: a class
//   with nothing queued never blocks the other.  Neither class can starve.
//
// Completion queue: CQ_DEPTH entries; the four engines post completions
// through a round-robin arbiter.  A full CQ back-pressures the engines (they
// hold their completion and accept no new descriptor) - completions are
// never dropped or duplicated.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfsb_defs.svh"
`default_nettype none

module sfsb_dispatch #(
  parameter int PAGE_LBS  = 4,
  parameter int LB_BYTES  = 512,
  parameter int DQ_DEPTH  = 4,
  parameter int CQ_DEPTH  = 8,
  parameter int CRYPTO_EN = 1,
  localparam int DW_      = `SFSB_DESC_W,
  localparam int CW_      = `SFSB_CPL_W,
  localparam int CQAW     = $clog2(CQ_DEPTH)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // configuration / status
  input  wire logic             cfg_en,
  input  wire logic             init_done,
  input  wire logic             pwr_fail,
  input  wire logic [7:0]       w_host,
  input  wire logic [7:0]       w_gc,
  // submission
  input  wire logic             submit,
  input  wire logic [DW_-1:0]   desc,
  output logic      [7:0]       sub_code,     // combinational result for 'desc'
  input  wire logic [7:0]       slot_code,    // buffer manager's part of the check
  output logic                  sub_commit,
  // engine descriptor interfaces
  output logic                  h2b_dv,
  output logic      [DW_-1:0]   h2b_d,
  input  wire logic             h2b_take,
  output logic                  b2h_dv,
  output logic      [DW_-1:0]   b2h_d,
  input  wire logic             b2h_take,
  output logic                  enc_dv,
  output logic      [DW_-1:0]   enc_d,
  input  wire logic             enc_take,
  output logic                  dec_dv,
  output logic      [DW_-1:0]   dec_d,
  input  wire logic             dec_take,
  // engine completions (0 H2B, 1 B2H, 2 ENC, 3 DEC)
  input  wire logic [3:0]       cpl_valid,
  input  wire logic [4*CW_-1:0] cpl_data,
  output logic      [3:0]       cpl_ready,
  // completion queue (firmware side)
  output logic                  cq_nonempty,
  output logic      [CW_-1:0]   cq_head,
  output logic      [CQAW:0]    cq_count,
  input  wire logic             cq_pop,
  // instrumentation
  output logic                  busy_q,       // any descriptor queued
  output logic                  ev_cq_full,   // an engine waits on a full CQ
  output logic      [1:0]       qwait_media   // [0] ENC queue waiting, [1] DEC queue waiting
);
  if (DQ_DEPTH < 2 || (DQ_DEPTH & (DQ_DEPTH - 1)) != 0) begin : g_err_dq
    `SFSB_CFG_FATAL("sfsb_dispatch: DQ_DEPTH must be a power of two >= 2")
  end
  if (CQ_DEPTH < 2 || (CQ_DEPTH & (CQ_DEPTH - 1)) != 0) begin : g_err_cq
    `SFSB_CFG_FATAL("sfsb_dispatch: CQ_DEPTH must be a power of two >= 2")
  end

  localparam int DQAW = $clog2(DQ_DEPTH);

  // ------------------------------------------------------------ queues
  // index: 0 H2B, 1 B2H, 2 ENC-HOST, 3 ENC-GC, 4 DEC-HOST, 5 DEC-GC
  logic [5:0]    q_push, q_pop, q_full, q_empty;
  logic [DW_-1:0] q_rd [6];
  /* verilator lint_off UNUSEDSIGNAL */
  logic [DQAW:0] q_cnt [6];
  /* verilator lint_on UNUSEDSIGNAL */

  for (genvar q = 0; q < 6; q++) begin : g_q
    sfsb_fifo #(.W(DW_), .DEPTH(DQ_DEPTH)) u_q (
      .clk, .rst_n, .push(q_push[q]), .wdata(desc), .pop(q_pop[q]),
      .rdata(q_rd[q]), .full(q_full[q]), .empty(q_empty[q]), .count(q_cnt[q])
    );
  end

  // ------------------------------------------------------------ validation
  wire [3:0]  opc   = `SFSB_DF_OPC(desc);
  wire [7:0]  tid   = `SFSB_DF_TID(desc);
  wire [1:0]  cls   = `SFSB_DF_CLS(desc);
  wire        crypt = `SFSB_DF_CRYPT(desc);
  wire [3:0]  lbf   = `SFSB_DF_LBF(desc);
  wire [3:0]  lbc   = `SFSB_DF_LBC(desc);
  wire [31:0] haddr = `SFSB_DF_HADDR(desc);

  wire is_h2b = (opc == `SFSB_OP_H2B);
  wire is_b2h = (opc == `SFSB_OP_B2H);
  wire is_enc = (opc == `SFSB_OP_ENC);
  wire is_dec = (opc == `SFSB_OP_DEC);
  wire is_host_dma = is_h2b || is_b2h;

  logic [255:0] tid_busy;
  wire [32:0] host_end = {1'b0, haddr} + 33'(32'(lbc) * LB_BYTES);

  logic [2:0] qi;     // target queue index
  always_comb begin
    qi = 3'd0;
    if (is_b2h) qi = 3'd1;
    if (is_enc) qi = (cls == `SFSB_CLS_GC) ? 3'd3 : 3'd2;
    if (is_dec) qi = (cls == `SFSB_CLS_GC) ? 3'd5 : 3'd4;
  end

  always_comb begin
    sub_code = `SFSB_SUB_OK;
    if (!cfg_en || !init_done)                                    sub_code = `SFSB_SUB_DISABLED;
    else if (!(is_h2b || is_b2h || is_enc || is_dec))             sub_code = `SFSB_SUB_BAD_OPC;
    else if (is_host_dma ? (cls != `SFSB_CLS_HOST) : (cls > `SFSB_CLS_GC))
                                                                  sub_code = `SFSB_SUB_BAD_CLASS;
    else if (lbc == 4'd0)                                         sub_code = `SFSB_SUB_BAD_LEN;
    else if (32'(lbf) + 32'(lbc) > PAGE_LBS)                      sub_code = `SFSB_SUB_RANGE;
    else if (crypt && (CRYPTO_EN == 0 || is_host_dma))            sub_code = `SFSB_SUB_UNSUP;
    else if (is_host_dma && haddr[2:0] != 3'd0)                   sub_code = `SFSB_SUB_ALIGN;
    else if (is_host_dma && host_end[32] && host_end[31:0] != 32'd0)
                                                                  sub_code = `SFSB_SUB_RANGE;
    else if (is_h2b && pwr_fail)                                  sub_code = `SFSB_SUB_PWR;
    else if (tid_busy[tid])                                       sub_code = `SFSB_SUB_DUP_TID;
    else if (q_full[qi])                                          sub_code = `SFSB_SUB_QFULL;
    else                                                          sub_code = slot_code;
  end

  assign sub_commit = submit && (sub_code == `SFSB_SUB_OK);
  always_comb begin
    q_push = '0;
    if (sub_commit) q_push[qi] = 1'b1;
  end

  // ------------------------------------------------------------ engine heads
  assign h2b_dv = !q_empty[0];
  assign h2b_d  = q_rd[0];
  assign b2h_dv = !q_empty[1];
  assign b2h_d  = q_rd[1];

  // weighted round robin HOST/GC for ENC (e = 0) and DEC (e = 1)
  logic [1:0] turn_gc;
  logic [7:0] run [2];
  logic [1:0] sel_gc;
  wire  [7:0] wh = (w_host == 8'd0) ? 8'd1 : w_host;
  wire  [7:0] wg = (w_gc   == 8'd0) ? 8'd1 : w_gc;

  for (genvar e = 0; e < 2; e++) begin : g_wrr
    wire hq = !q_empty[2 + 2*e];
    wire gq = !q_empty[3 + 2*e];
    always_comb begin
      if (hq && !gq)       sel_gc[e] = 1'b0;
      else if (gq && !hq)  sel_gc[e] = 1'b1;
      else if (!turn_gc[e]) sel_gc[e] = (run[e] >= wh);
      else                 sel_gc[e] = !(run[e] >= wg);
    end
  end

  assign enc_dv = !q_empty[2] || !q_empty[3];
  assign enc_d  = sel_gc[0] ? q_rd[3] : q_rd[2];
  assign dec_dv = !q_empty[4] || !q_empty[5];
  assign dec_d  = sel_gc[1] ? q_rd[5] : q_rd[4];

  always_comb begin
    q_pop    = '0;
    q_pop[0] = h2b_take && h2b_dv;
    q_pop[1] = b2h_take && b2h_dv;
    if (enc_take && enc_dv) q_pop[sel_gc[0] ? 3 : 2] = 1'b1;
    if (dec_take && dec_dv) q_pop[sel_gc[1] ? 5 : 4] = 1'b1;
  end

  wire [1:0] media_take = {dec_take && dec_dv, enc_take && enc_dv};
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      turn_gc <= '0;
      run[0]  <= '0;
      run[1]  <= '0;
    end else begin
      for (int e = 0; e < 2; e++) begin
        if (media_take[e]) begin
          if (sel_gc[e] == turn_gc[e]) begin
            if (run[e] != 8'hFF) run[e] <= run[e] + 1'b1;
          end else begin
            turn_gc[e] <= sel_gc[e];
            run[e]     <= 8'd1;
          end
        end
      end
    end
  end

  // ------------------------------------------------------------ completion queue
  logic [1:0]    rr;
  logic [1:0]    cwin;
  logic          cfound;
  logic          cq_full, cq_empty;
  logic [CW_-1:0] cq_wdata;

  always_comb begin
    cwin   = rr;
    cfound = 1'b0;
    for (int i = 0; i < 4; i++) begin
      if (!cfound && cpl_valid[(32'(rr) + i) % 4]) begin
        cfound = 1'b1;
        cwin   = 2'((32'(rr) + i) % 4);
      end
    end
  end

  wire cq_push = cfound && !cq_full;
  always_comb begin
    cpl_ready = '0;
    if (cq_push) cpl_ready[cwin] = 1'b1;
  end
  assign cq_wdata = cpl_data[cwin*CW_ +: CW_];

  sfsb_fifo #(.W(CW_), .DEPTH(CQ_DEPTH)) u_cq (
    .clk, .rst_n, .push(cq_push), .wdata(cq_wdata), .pop(cq_pop && !cq_empty),
    .rdata(cq_head), .full(cq_full), .empty(cq_empty), .count(cq_count)
  );
  assign cq_nonempty = !cq_empty;
  assign ev_cq_full  = cfound && cq_full;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rr       <= '0;
      tid_busy <= '0;
    end else begin
      if (cq_push) rr <= cwin + 2'd1;
      // a TID popped and a TID committed in the same cycle are always different
      // (the committed one was not busy)
      if (cq_pop && !cq_empty) tid_busy[cq_head[7:0]] <= 1'b0;
      if (sub_commit)          tid_busy[tid]          <= 1'b1;
    end
  end

  assign busy_q      = (q_empty != 6'h3F);
  assign qwait_media = {dec_dv, enc_dv};
endmodule

`default_nettype wire
