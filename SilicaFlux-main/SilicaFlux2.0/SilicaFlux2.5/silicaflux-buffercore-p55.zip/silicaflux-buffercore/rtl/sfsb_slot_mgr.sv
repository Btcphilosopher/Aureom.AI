// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_slot_mgr  (buffer manager)
//
// Owns every piece of buffer bookkeeping:
//   * data slots   (NDS x PAGE_LBS logical blocks of plaintext): state
//                  FREE / FW / CACHED, write lock, reader count, DIRTY, LRU age
//   * page slots   (NPS NAND page images): state FREE / FW / NAND, write lock,
//                  reader count, BAD (page assembly failed its integrity check)
//   * metadata buffer: per (data slot, logical block) entry
//                  {VALID, POISON, LBA[31:0], CRC32C[31:0]}
//   * clean read cache: CACHED data slots, LBA lookup, LRU eviction
//
// Ownership rules (docs/03_BUFFER_MANAGER.md):
//   - firmware allocates and frees slots with slot commands (one cycle);
//   - a descriptor takes its locks at SUBMISSION (sub_commit) and the engine
//     releases them at completion, so a slot can never be freed, re-allocated,
//     handed to the NAND controller or written by firmware while an engine
//     uses it.  Writers are exclusive; readers share.
//   - the NAND controller may access a page slot only in state NAND;
//     firmware may write a slot only when it owns it and no engine holds a lock.
//   - DIRTY (data written by the host, not yet durable on NAND) is set by H2B
//     submission and cleared only by COMMIT_D (firmware: "NAND program of the
//     page assembled from this slot succeeded").  A dirty slot can be freed
//     only with DISCARD and can never be inserted in the clean read cache.
//
// Conflicting same-cycle updates are impossible by construction (engines only
// update slots they hold a lock on); the simulation checker below verifies it.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfsb_defs.svh"
`default_nettype none

module sfsb_slot_mgr #(
  parameter int NDS         = 8,
  parameter int NPS         = 4,
  parameter int PAGE_LBS    = 4,
  parameter int WAW         = 12,
  parameter int DSB_LOG2    = 8,      // log2(data-slot beats)
  parameter int PS_BASE     = 2048,   // first word of the page-slot region
  parameter int PSLOT_BEATS = 296,
  localparam int DIW        = (NDS > 1) ? $clog2(NDS) : 1,   // data-slot index width
  localparam int PIW        = (NPS > 1) ? $clog2(NPS) : 1,   // page-slot index width
  localparam int DSZ        = 1 << DIW,                       // arrays padded to a power of two:
  localparam int PSZ        = 1 << PIW,                       // entries >= NDS / NPS stay FREE forever
  localparam int NE         = DSZ * PAGE_LBS
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  // ---------------------------------------------------- firmware slot command
  input  wire logic           cmd_valid,
  input  wire logic [3:0]     cmd_op,
  input  wire logic [7:0]     cmd_slot,
  input  wire logic           cmd_flag,
  input  wire logic [31:0]    cmd_lba,
  input  wire logic [31:0]    cmd_cnt,
  output logic      [7:0]     cmd_code,
  output logic      [7:0]     cmd_rslot,
  output logic                cmd_hit,      // LOOKUP hit / ALLOC_D evicted a cached slot
  output logic      [3:0]     cmd_rlb,
  // ---------------------------------------------------- descriptor submission
  input  wire logic [3:0]     sub_op,
  input  wire logic [7:0]     sub_dslot,
  input  wire logic [7:0]     sub_pslot,
  input  wire logic [3:0]     sub_lbf,
  input  wire logic [3:0]     sub_lbc,
  input  wire logic [31:0]    sub_lba,
  output logic      [7:0]     sub_code,
  input  wire logic           sub_commit,
  // slot indices are 8 bits architecturally; only log2(NDS) / log2(NPS) bits are used
  /* verilator lint_off UNUSEDSIGNAL */
  // ---------------------------------------------------- lock release (engine completion)
  input  wire logic           rel_h2b,
  input  wire logic [7:0]     rel_h2b_d,
  input  wire logic           rel_b2h,
  input  wire logic [7:0]     rel_b2h_d,
  input  wire logic           rel_enc,
  input  wire logic [7:0]     rel_enc_d,
  input  wire logic [7:0]     rel_enc_p,
  input  wire logic           rel_dec,
  input  wire logic [7:0]     rel_dec_d,
  input  wire logic [7:0]     rel_dec_p,
  // ---------------------------------------------------- metadata updates
  input  wire logic           h2b_upd,
  input  wire logic [7:0]     h2b_upd_d,
  input  wire logic [3:0]     h2b_upd_lb,
  input  wire logic [31:0]    h2b_upd_lba,
  input  wire logic [31:0]    h2b_upd_crc,
  input  wire logic           h2b_upd_ok,
  input  wire logic           dec_upd,
  input  wire logic [7:0]     dec_upd_d,
  input  wire logic [3:0]     dec_upd_lb,
  input  wire logic [31:0]    dec_upd_lba,
  input  wire logic [31:0]    dec_upd_crc,
  input  wire logic           dec_upd_valid,
  input  wire logic           dec_upd_poison,
  input  wire logic           b2h_poison,
  input  wire logic [7:0]     b2h_poison_d,
  input  wire logic [3:0]     b2h_poison_lb,
  input  wire logic           enc_bad,
  input  wire logic [7:0]     enc_bad_p,
  // ---------------------------------------------------- metadata read ports
  input  wire logic [7:0]     b2h_rd_d,
  input  wire logic [3:0]     b2h_rd_lb,
  output logic      [31:0]    b2h_rd_crc,
  input  wire logic [7:0]     enc_rd_d,
  input  wire logic [3:0]     enc_rd_lb,
  output logic      [31:0]    enc_rd_crc,
  output logic      [31:0]    enc_rd_lba,
  input  wire logic [7:0]     dbg_d,
  input  wire logic [3:0]     dbg_lb,
  output logic      [31:0]    dbg_lba,
  output logic      [31:0]    dbg_crc,
  output logic      [31:0]    dbg_flags,
  input  wire logic [7:0]     dbg_p,
  output logic      [31:0]    dbg_pflags,
  /* verilator lint_on UNUSEDSIGNAL */
  // ---------------------------------------------------- port access checks
  input  wire logic [WAW-1:0] fwa_wa,
  input  wire logic           fwa_we,
  output logic                fwa_ok,
  input  wire logic [WAW-1:0] nda_wa,
  output logic                nda_ok,
  // ---------------------------------------------------- status
  output logic      [7:0]     dirty_cnt,
  output logic      [7:0]     ds_alloc_cnt,
  output logic      [7:0]     ds_cached_cnt,
  output logic      [7:0]     ps_alloc_cnt,
  output logic      [7:0]     ps_nand_cnt,
  output logic                ev_lookup,
  output logic                ev_hit,
  output logic                ev_evict
);
  if (NDS < 1 || NDS > 32) begin : g_err_nds
    `SFSB_CFG_FATAL("sfsb_slot_mgr: NDS must be in 1..32")
  end
  if (NPS < 1 || NPS > 32) begin : g_err_nps
    `SFSB_CFG_FATAL("sfsb_slot_mgr: NPS must be in 1..32")
  end
  if (PAGE_LBS != 1 && PAGE_LBS != 2 && PAGE_LBS != 4 && PAGE_LBS != 8) begin : g_err_lbs
    `SFSB_CFG_FATAL("sfsb_slot_mgr: PAGE_LBS must be 1, 2, 4 or 8")
  end

  // ------------------------------------------------------------ state
  logic [1:0]  ds_state [DSZ];
  logic        ds_wl    [DSZ];
  logic [4:0]  ds_rc    [DSZ];
  logic        ds_dirty [DSZ];
  logic [7:0]  ds_age   [DSZ];
  logic [1:0]  ps_state [PSZ];
  logic        ps_wl    [PSZ];
  logic [4:0]  ps_rc    [PSZ];
  logic        ps_bad   [PSZ];
  logic        m_valid  [NE];
  logic        m_poison [NE];
  logic [31:0] m_lba    [NE];
  logic [31:0] m_crc    [NE];

  function automatic integer eidx(input integer s, input integer lb);
    begin
      eidx = s * PAGE_LBS + lb;
    end
  endfunction

  // ------------------------------------------------------------ helpers
  wire d_in = (32'(sub_dslot) < NDS);
  wire p_in = (32'(sub_pslot) < NPS);
  wire [DIW-1:0] sd = d_in ? sub_dslot[DIW-1:0] : '0;
  wire [PIW-1:0] sp = p_in ? sub_pslot[PIW-1:0] : '0;

  // logical-block range mask of the submitted descriptor (bounds checked by the dispatcher)
  logic [7:0] sub_mask;
  always_comb begin
    sub_mask = '0;
    for (int i = 0; i < 8; i++)
      if (i >= 32'(sub_lbf) && i < 32'(sub_lbf) + 32'(sub_lbc) && i < PAGE_LBS) sub_mask[i] = 1'b1;
  end

  logic any_poison, any_invalid;
  always_comb begin
    any_poison  = 1'b0;
    any_invalid = 1'b0;
    for (int i = 0; i < PAGE_LBS; i++) begin
      if (sub_mask[i] && m_poison[eidx(32'(sd), i)]) any_poison = 1'b1;
      if (sub_mask[i] && !m_valid[eidx(32'(sd), i)]) any_invalid = 1'b1;
    end
  end

  wire d_wr_free = !ds_wl[sd] && (ds_rc[sd] == '0);
  wire p_wr_free = !ps_wl[sp] && (ps_rc[sp] == '0);
  wire [4:0] RC_MAX = 5'd30;

  // ------------------------------------------------------------ submission check
  always_comb begin
    sub_code = `SFSB_SUB_OK;
    case (sub_op)
      `SFSB_OP_H2B: begin
        if (!d_in)                                sub_code = `SFSB_SUB_SLOT;
        else if (ds_state[sd] != `SFSB_DS_FW)     sub_code = `SFSB_SUB_OWNER;
        else if (!d_wr_free)                      sub_code = `SFSB_SUB_BUSY;
      end
      `SFSB_OP_B2H: begin
        if (!d_in)                                sub_code = `SFSB_SUB_SLOT;
        else if (ds_state[sd] == `SFSB_DS_FREE)   sub_code = `SFSB_SUB_OWNER;
        else if (ds_wl[sd] || ds_rc[sd] == RC_MAX) sub_code = `SFSB_SUB_BUSY;
        else if (any_poison)                      sub_code = `SFSB_SUB_POISON;
        else if (any_invalid)                     sub_code = `SFSB_SUB_NOT_VALID;
      end
      `SFSB_OP_ENC: begin
        if (!d_in || !p_in)                       sub_code = `SFSB_SUB_SLOT;
        else if (ds_state[sd] == `SFSB_DS_FREE || ps_state[sp] != `SFSB_PS_FW)
                                                  sub_code = `SFSB_SUB_OWNER;
        else if (ds_wl[sd] || ds_rc[sd] == RC_MAX || !p_wr_free)
                                                  sub_code = `SFSB_SUB_BUSY;
        else if (any_poison)                      sub_code = `SFSB_SUB_POISON;
        else if (any_invalid)                     sub_code = `SFSB_SUB_NOT_VALID;
      end
      `SFSB_OP_DEC: begin
        if (!d_in || !p_in)                       sub_code = `SFSB_SUB_SLOT;
        else if (ds_state[sd] != `SFSB_DS_FW || ps_state[sp] != `SFSB_PS_FW)
                                                  sub_code = `SFSB_SUB_OWNER;
        else if (!d_wr_free || ps_wl[sp] || ps_rc[sp] == RC_MAX)
                                                  sub_code = `SFSB_SUB_BUSY;
      end
      default: sub_code = `SFSB_SUB_BAD_OPC;
    endcase
  end

  // ------------------------------------------------------------ slot-command decode
  wire           cd_in = (32'(cmd_slot) < NDS);
  wire           cp_in = (32'(cmd_slot) < NPS);
  wire [DIW-1:0] cs    = cmd_slot[DIW-1:0];   // data-slot commands (range checked)
  wire [PIW-1:0] cq    = cmd_slot[PIW-1:0];   // page-slot commands (range checked)

  logic           free_d_found, evict_found, free_p_found;
  logic [DIW-1:0] free_d_idx, evict_idx;
  logic [PIW-1:0] free_p_idx;
  logic [7:0] evict_age;
  always_comb begin
    free_d_found = 1'b0; free_d_idx = '0;
    evict_found  = 1'b0; evict_idx  = '0; evict_age = '0;
    free_p_found = 1'b0; free_p_idx = '0;
    for (int s = 0; s < NDS; s++) begin
      if (!free_d_found && ds_state[s] == `SFSB_DS_FREE) begin
        free_d_found = 1'b1; free_d_idx = DIW'(s);
      end
      if (ds_state[s] == `SFSB_DS_CACHED && !ds_wl[s] && ds_rc[s] == '0 &&
          (!evict_found || ds_age[s] > evict_age)) begin
        evict_found = 1'b1; evict_idx = DIW'(s); evict_age = ds_age[s];
      end
    end
    for (int p = 0; p < NPS; p++) begin
      if (!free_p_found && ps_state[p] == `SFSB_PS_FREE) begin
        free_p_found = 1'b1; free_p_idx = PIW'(p);
      end
    end
  end

  // read-cache lookup (CACHED slots only)
  logic           lk_hit;
  logic [DIW-1:0] lk_slot;
  logic [3:0] lk_lb;
  always_comb begin
    lk_hit = 1'b0; lk_slot = '0; lk_lb = '0;
    for (int s = 0; s < NDS; s++)
      for (int i = 0; i < PAGE_LBS; i++)
        if (!lk_hit && ds_state[s] == `SFSB_DS_CACHED && m_valid[eidx(s, i)] &&
            !m_poison[eidx(s, i)] && m_lba[eidx(s, i)] == cmd_lba) begin
          lk_hit = 1'b1; lk_slot = DIW'(s); lk_lb = 4'(i);
        end
  end

  always_comb begin
    cmd_code  = `SFSB_SR_OK;
    cmd_rslot = cmd_slot;
    cmd_hit   = 1'b0;
    cmd_rlb   = '0;
    case (cmd_op)
      `SFSB_SC_ALLOC_D: begin
        if (free_d_found)     cmd_rslot = 8'(free_d_idx);
        else if (evict_found) begin cmd_rslot = 8'(evict_idx); cmd_hit = 1'b1; end
        else                  cmd_code = `SFSB_SR_NOSPACE;
      end
      `SFSB_SC_FREE_D: begin
        if (!cd_in)                                   cmd_code = `SFSB_SR_RANGE;
        else if (ds_state[cs] == `SFSB_DS_FREE)       cmd_code = `SFSB_SR_STATE;
        else if (ds_wl[cs] || ds_rc[cs] != '0)        cmd_code = `SFSB_SR_BUSY;
        else if (ds_dirty[cs] && !cmd_flag)           cmd_code = `SFSB_SR_DIRTY;
      end
      `SFSB_SC_COMMIT_D: begin
        if (!cd_in)                                   cmd_code = `SFSB_SR_RANGE;
        else if (ds_state[cs] != `SFSB_DS_FW)         cmd_code = `SFSB_SR_STATE;
        else if (ds_wl[cs])                           cmd_code = `SFSB_SR_BUSY;
      end
      `SFSB_SC_CACHE_D: begin
        if (!cd_in)                                   cmd_code = `SFSB_SR_RANGE;
        else if (ds_state[cs] != `SFSB_DS_FW)         cmd_code = `SFSB_SR_STATE;
        else if (ds_wl[cs])                           cmd_code = `SFSB_SR_BUSY;
        else if (ds_dirty[cs])                        cmd_code = `SFSB_SR_DIRTY;
      end
      `SFSB_SC_CLAIM_D: begin
        if (!cd_in)                                   cmd_code = `SFSB_SR_RANGE;
        else if (ds_state[cs] != `SFSB_DS_CACHED)     cmd_code = `SFSB_SR_STATE;
      end
      `SFSB_SC_LOOKUP: begin
        if (lk_hit) begin cmd_hit = 1'b1; cmd_rslot = 8'(lk_slot); cmd_rlb = lk_lb; end
        else cmd_code = `SFSB_SR_MISS;
      end
      `SFSB_SC_INVAL: ;
      `SFSB_SC_ALLOC_P: begin
        if (free_p_found) cmd_rslot = 8'(free_p_idx);
        else              cmd_code = `SFSB_SR_NOSPACE;
      end
      `SFSB_SC_FREE_P: begin
        if (!cp_in)                                   cmd_code = `SFSB_SR_RANGE;
        else if (ps_state[cq] != `SFSB_PS_FW)         cmd_code = `SFSB_SR_STATE;
        else if (ps_wl[cq] || ps_rc[cq] != '0)        cmd_code = `SFSB_SR_BUSY;
      end
      `SFSB_SC_P2NAND: begin
        if (!cp_in)                                   cmd_code = `SFSB_SR_RANGE;
        else if (ps_state[cq] != `SFSB_PS_FW)         cmd_code = `SFSB_SR_STATE;
        else if (ps_wl[cq] || ps_rc[cq] != '0)        cmd_code = `SFSB_SR_BUSY;
        else if (ps_bad[cq])                          cmd_code = `SFSB_SR_BAD_PAGE;
      end
      `SFSB_SC_P2FW: begin
        if (!cp_in)                                   cmd_code = `SFSB_SR_RANGE;
        else if (ps_state[cq] != `SFSB_PS_NAND)       cmd_code = `SFSB_SR_STATE;
      end
      default: cmd_code = `SFSB_SR_BAD_CMD;
    endcase
  end

  wire cmd_ok = cmd_valid && (cmd_code == `SFSB_SR_OK);
  wire [DIW-1:0] alloc_d = free_d_found ? free_d_idx : evict_idx;
  assign ev_lookup = cmd_valid && (cmd_op == `SFSB_SC_LOOKUP);
  assign ev_hit    = ev_lookup && lk_hit;
  assign ev_evict  = cmd_ok && (cmd_op == `SFSB_SC_ALLOC_D) && !free_d_found;

  // ------------------------------------------------------------ reader-count deltas
  logic [4:0] d_inc [NDS];
  logic [4:0] d_dec [NDS];
  logic [4:0] p_inc [NPS];
  logic [4:0] p_dec [NPS];
  always_comb begin
    for (int s = 0; s < NDS; s++) begin
      d_inc[s] = '0;
      d_dec[s] = '0;
      if (sub_commit && (sub_op == `SFSB_OP_B2H || sub_op == `SFSB_OP_ENC) && 32'(sd) == s) d_inc[s] = 5'd1;
      if (rel_b2h && 32'(rel_b2h_d) == s) d_dec[s] = d_dec[s] + 5'd1;
      if (rel_enc && 32'(rel_enc_d) == s) d_dec[s] = d_dec[s] + 5'd1;
    end
    for (int p = 0; p < NPS; p++) begin
      p_inc[p] = '0;
      p_dec[p] = '0;
      if (sub_commit && sub_op == `SFSB_OP_DEC && 32'(sp) == p) p_inc[p] = 5'd1;
      if (rel_dec && 32'(rel_dec_p) == p) p_dec[p] = 5'd1;
    end
  end

  // ------------------------------------------------------------ sequential update
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int s = 0; s < DSZ; s++) begin
        ds_state[s] <= `SFSB_DS_FREE;
        ds_wl[s]    <= 1'b0;
        ds_rc[s]    <= '0;
        ds_dirty[s] <= 1'b0;
        ds_age[s]   <= '0;
      end
      for (int p = 0; p < PSZ; p++) begin
        ps_state[p] <= `SFSB_PS_FREE;
        ps_wl[p]    <= 1'b0;
        ps_rc[p]    <= '0;
        ps_bad[p]   <= 1'b0;
      end
      for (int e = 0; e < NE; e++) begin
        m_valid[e]  <= 1'b0;
        m_poison[e] <= 1'b0;
        m_lba[e]    <= '0;
        m_crc[e]    <= '0;
      end
    end else begin
      // ---- reader counts
      for (int s = 0; s < NDS; s++) ds_rc[s] <= ds_rc[s] + d_inc[s] - d_dec[s];
      for (int p = 0; p < NPS; p++) ps_rc[p] <= ps_rc[p] + p_inc[p] - p_dec[p];

      // ---- firmware slot commands
      if (cmd_ok) begin
        case (cmd_op)
          `SFSB_SC_ALLOC_D: begin
            ds_state[alloc_d] <= `SFSB_DS_FW;
            ds_dirty[alloc_d] <= 1'b0;
            ds_age[alloc_d]   <= '0;
            for (int i = 0; i < PAGE_LBS; i++) begin
              m_valid[eidx(32'(alloc_d), i)]  <= 1'b0;
              m_poison[eidx(32'(alloc_d), i)] <= 1'b0;
            end
            for (int s = 0; s < NDS; s++)
              if (ds_state[s] == `SFSB_DS_CACHED && 32'(alloc_d) != s && ds_age[s] != 8'hFF)
                ds_age[s] <= ds_age[s] + 1'b1;
          end
          `SFSB_SC_FREE_D: begin
            ds_state[cs] <= `SFSB_DS_FREE;
            ds_dirty[cs] <= 1'b0;
            for (int i = 0; i < PAGE_LBS; i++) begin
              m_valid[eidx(32'(cs), i)]  <= 1'b0;
              m_poison[eidx(32'(cs), i)] <= 1'b0;
            end
          end
          `SFSB_SC_COMMIT_D: ds_dirty[cs] <= 1'b0;
          `SFSB_SC_CACHE_D: begin
            ds_state[cs] <= `SFSB_DS_CACHED;
            ds_age[cs]   <= '0;
          end
          `SFSB_SC_CLAIM_D: ds_state[cs] <= `SFSB_DS_FW;
          `SFSB_SC_LOOKUP: begin
            for (int s = 0; s < NDS; s++)
              if (ds_state[s] == `SFSB_DS_CACHED) begin
                if (32'(lk_slot) == s)       ds_age[s] <= '0;
                else if (ds_age[s] != 8'hFF) ds_age[s] <= ds_age[s] + 1'b1;
              end
          end
          `SFSB_SC_INVAL: begin
            for (int s = 0; s < NDS; s++)
              for (int i = 0; i < PAGE_LBS; i++)
                if (ds_state[s] == `SFSB_DS_CACHED && (m_lba[eidx(s, i)] - cmd_lba) < cmd_cnt)
                  m_valid[eidx(s, i)] <= 1'b0;
          end
          `SFSB_SC_ALLOC_P: begin
            ps_state[free_p_idx] <= `SFSB_PS_FW;
            ps_bad[free_p_idx]   <= 1'b0;
          end
          `SFSB_SC_FREE_P:  ps_state[cq] <= `SFSB_PS_FREE;
          `SFSB_SC_P2NAND:  ps_state[cq] <= `SFSB_PS_NAND;
          `SFSB_SC_P2FW:    ps_state[cq] <= `SFSB_PS_FW;
          default: ;
        endcase
      end

      // ---- descriptor submission: take locks, side effects
      if (sub_commit) begin
        case (sub_op)
          `SFSB_OP_H2B: begin
            ds_wl[sd]    <= 1'b1;
            ds_dirty[sd] <= 1'b1;
            for (int i = 0; i < PAGE_LBS; i++)
              if (sub_mask[i]) begin
                m_valid[eidx(32'(sd), i)]  <= 1'b0;
                m_poison[eidx(32'(sd), i)] <= 1'b0;
              end
            // coherence: a host write makes cached copies of the same LBAs stale
            for (int s = 0; s < NDS; s++)
              for (int i = 0; i < PAGE_LBS; i++)
                if (ds_state[s] == `SFSB_DS_CACHED && (m_lba[eidx(s, i)] - sub_lba) < 32'(sub_lbc))
                  m_valid[eidx(s, i)] <= 1'b0;
          end
          `SFSB_OP_ENC: begin
            ps_wl[sp]  <= 1'b1;
            ps_bad[sp] <= 1'b0;
          end
          `SFSB_OP_DEC: begin
            ds_wl[sd] <= 1'b1;
            for (int i = 0; i < PAGE_LBS; i++)
              if (sub_mask[i]) begin
                m_valid[eidx(32'(sd), i)]  <= 1'b0;
                m_poison[eidx(32'(sd), i)] <= 1'b0;
              end
          end
          default: ;
        endcase
      end

      // ---- engine metadata updates (slots are write-locked by the updater)
      if (h2b_upd) begin
        m_valid[eidx(32'(h2b_upd_d[DIW-1:0]), 32'(h2b_upd_lb))]  <= h2b_upd_ok;
        m_poison[eidx(32'(h2b_upd_d[DIW-1:0]), 32'(h2b_upd_lb))] <= 1'b0;
        m_lba[eidx(32'(h2b_upd_d[DIW-1:0]), 32'(h2b_upd_lb))]    <= h2b_upd_lba;
        m_crc[eidx(32'(h2b_upd_d[DIW-1:0]), 32'(h2b_upd_lb))]    <= h2b_upd_crc;
      end
      if (dec_upd) begin
        m_valid[eidx(32'(dec_upd_d[DIW-1:0]), 32'(dec_upd_lb))]  <= dec_upd_valid;
        m_poison[eidx(32'(dec_upd_d[DIW-1:0]), 32'(dec_upd_lb))] <= dec_upd_poison;
        m_lba[eidx(32'(dec_upd_d[DIW-1:0]), 32'(dec_upd_lb))]    <= dec_upd_lba;
        m_crc[eidx(32'(dec_upd_d[DIW-1:0]), 32'(dec_upd_lb))]    <= dec_upd_crc;
      end
      if (b2h_poison) begin
        m_poison[eidx(32'(b2h_poison_d[DIW-1:0]), 32'(b2h_poison_lb))] <= 1'b1;
        m_valid[eidx(32'(b2h_poison_d[DIW-1:0]), 32'(b2h_poison_lb))]  <= 1'b0;
      end
      if (enc_bad) ps_bad[enc_bad_p[PIW-1:0]] <= 1'b1;

      // ---- lock release
      if (rel_h2b) ds_wl[rel_h2b_d[DIW-1:0]] <= 1'b0;
      if (rel_dec) ds_wl[rel_dec_d[DIW-1:0]] <= 1'b0;
      if (rel_enc) ps_wl[rel_enc_p[PIW-1:0]] <= 1'b0;
    end
  end

  // ------------------------------------------------------------ read ports
  assign b2h_rd_crc = m_crc[eidx(32'(b2h_rd_d[DIW-1:0]), 32'(b2h_rd_lb) % PAGE_LBS)];
  assign enc_rd_crc = m_crc[eidx(32'(enc_rd_d[DIW-1:0]), 32'(enc_rd_lb) % PAGE_LBS)];
  assign enc_rd_lba = m_lba[eidx(32'(enc_rd_d[DIW-1:0]), 32'(enc_rd_lb) % PAGE_LBS)];

  wire [DIW-1:0] dd = (32'(dbg_d) < NDS) ? dbg_d[DIW-1:0] : '0;
  wire [PIW-1:0] dp = (32'(dbg_p) < NPS) ? dbg_p[PIW-1:0] : '0;
  /* verilator lint_off UNUSEDSIGNAL */
  wire [31:0] de = eidx(32'(dd), 32'(dbg_lb) % PAGE_LBS);
  /* verilator lint_on UNUSEDSIGNAL */
  assign dbg_lba    = m_lba[de];
  assign dbg_crc    = m_crc[de];
  assign dbg_flags  = {16'd0, 3'd0, ds_rc[dd], ds_wl[dd], ds_dirty[dd], ds_state[dd],
                       2'd0, m_poison[de], m_valid[de]};
  assign dbg_pflags = {24'd0, ps_rc[dp][3:0], ps_bad[dp], ps_wl[dp], ps_state[dp]};

  // ------------------------------------------------------------ port access checks
  localparam int PS_END = PS_BASE + NPS * PSLOT_BEATS;

  function automatic [PIW-1:0] pslot_of(input [WAW-1:0] wa);
    integer k;
    begin
      pslot_of = '0;
      for (k = 1; k < NPS; k = k + 1)
        if (32'(wa) >= PS_BASE + k * PSLOT_BEATS) pslot_of = PIW'(k);
    end
  endfunction

  wire        fw_in_d = (32'(fwa_wa) < PS_BASE);
  wire        fw_in_p = (32'(fwa_wa) >= PS_BASE) && (32'(fwa_wa) < PS_END);
  wire [DIW-1:0] fw_d = DIW'(32'(fwa_wa) >> DSB_LOG2);
  wire [PIW-1:0] fw_p = pslot_of(fwa_wa);
  always_comb begin
    fwa_ok = 1'b0;
    if (fw_in_d)
      fwa_ok = fwa_we ? (ds_state[fw_d] == `SFSB_DS_FW && !ds_wl[fw_d] && ds_rc[fw_d] == '0)
                      : (ds_state[fw_d] != `SFSB_DS_FREE && !ds_wl[fw_d]);
    else if (fw_in_p)
      fwa_ok = fwa_we ? (ps_state[fw_p] == `SFSB_PS_FW && !ps_wl[fw_p] && ps_rc[fw_p] == '0)
                      : (ps_state[fw_p] == `SFSB_PS_FW && !ps_wl[fw_p]);
  end

  wire nd_in_p = (32'(nda_wa) >= PS_BASE) && (32'(nda_wa) < PS_END);
  assign nda_ok = nd_in_p && (ps_state[pslot_of(nda_wa)] == `SFSB_PS_NAND);

  // ------------------------------------------------------------ status
  always_comb begin
    dirty_cnt = '0; ds_alloc_cnt = '0; ds_cached_cnt = '0; ps_alloc_cnt = '0; ps_nand_cnt = '0;
    for (int s = 0; s < NDS; s++) begin
      if (ds_dirty[s]) dirty_cnt = dirty_cnt + 1'b1;
      if (ds_state[s] != `SFSB_DS_FREE)  ds_alloc_cnt  = ds_alloc_cnt + 1'b1;
      if (ds_state[s] == `SFSB_DS_CACHED) ds_cached_cnt = ds_cached_cnt + 1'b1;
    end
    for (int p = 0; p < NPS; p++) begin
      if (ps_state[p] != `SFSB_PS_FREE) ps_alloc_cnt = ps_alloc_cnt + 1'b1;
      if (ps_state[p] == `SFSB_PS_NAND) ps_nand_cnt  = ps_nand_cnt + 1'b1;
    end
  end

`ifndef SYNTHESIS
  // ------------------------------------------------------------ simulation checks
  always @(posedge clk) begin
    if (rst_n) begin
      if (h2b_upd && !ds_wl[h2b_upd_d[DIW-1:0]]) $error("%m: H2B metadata update on an unlocked slot");
      if (dec_upd && !ds_wl[dec_upd_d[DIW-1:0]]) $error("%m: DEC metadata update on an unlocked slot");
      if (h2b_upd && dec_upd && h2b_upd_d == dec_upd_d) $error("%m: concurrent writers on one slot");
      if (rel_h2b && !ds_wl[rel_h2b_d[DIW-1:0]]) $error("%m: H2B releases a lock it does not hold");
      if (rel_dec && !ds_wl[rel_dec_d[DIW-1:0]]) $error("%m: DEC releases a lock it does not hold");
      if (rel_enc && !ps_wl[rel_enc_p[PIW-1:0]]) $error("%m: ENC releases a lock it does not hold");
      for (int s = 0; s < NDS; s++)
        if (ds_rc[s] < d_dec[s]) $error("%m: data-slot %0d reader count underflow", s);
      for (int p = 0; p < NPS; p++)
        if (ps_rc[p] < p_dec[p]) $error("%m: page-slot %0d reader count underflow", p);
      if (sub_commit && sub_code != `SFSB_SUB_OK) $error("%m: commit of a rejected submission");
    end
  end
`endif
endmodule

`default_nettype wire
