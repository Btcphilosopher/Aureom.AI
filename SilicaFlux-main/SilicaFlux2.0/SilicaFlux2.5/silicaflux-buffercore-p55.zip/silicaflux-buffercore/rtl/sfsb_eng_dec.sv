// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_eng_dec   (read path)
//   page slot --> ECC decode --> [optional crypt] --> [V2 CRC + LBA verify] --> data slot
//
// Per logical block j of the descriptor (codeword j; any subset of the page
// can be decoded - codeword-granular partial-page reads):
//   1. read OOB metadata beat j and the OOB parity beat, SECDED-decode the
//      metadata with check byte j -> stored {CRC32C, LBA}.  All-ones metadata
//      (after correction) = ERASED codeword (never programmed);
//   2. read the codeword's check-byte beats into the check-byte staging
//      buffer (PAR_BEATS x 64 bit: the decoder's ECC input buffer - the check
//      bytes are stored after the data on the medium);
//   3. read the data beats; each beat + its check byte -> P26 SECDED decoder
//      (1 bit corrected, 2 bits detected), then the crypt stage, then CRC-32C;
//      the plaintext beat is written to the data slot via the write queue;
//   4. V2: recomputed CRC == stored CRC and stored LBA == expected LBA
//      (descriptor LBA + block offset) - this catches ECC miscorrection
//      (>= 3 bit errors aliasing to a valid codeword), stale or misdirected
//      pages and wrong crypt keys.  The metadata buffer entry is written with
//      VALID = good, POISON = bad (not erased): poisoned data is contained in
//      the buffer - B2H and ENC refuse it at submission.
// Data words of a failed block are still written (the slot is write-locked
// until completion) so the transfer length never depends on data content.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfsb_defs.svh"
`default_nettype none

module sfsb_eng_dec #(
  parameter int LB_BEATS    = 64,
  parameter int PAGE_LBS    = 4,
  parameter int WAW         = 12,
  parameter int DSB_LOG2    = 8,
  parameter int PS_BASE     = 2048,
  parameter int PSLOT_BEATS = 296,
  parameter int FD          = 8,
  parameter int CRYPTO_EN   = 1,
  localparam int DW_        = `SFSB_DESC_W,
  localparam int CW_        = `SFSB_CPL_W
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic [63:0]    key,
  input  wire logic           desc_valid,
  input  wire logic [DW_-1:0] desc,
  output logic                desc_take,
  // bank read port (page slot)
  output logic                rp_req_valid,
  input  wire logic           rp_req_ready,
  output logic      [WAW-1:0] rp_req_addr,
  input  wire logic           rp_rsp_valid,
  input  wire logic [63:0]    rp_rsp_rdata,
  input  wire logic [7:0]     rp_rsp_perr,
  input  wire logic           rp_rsp_rerr,
  // bank write port (data slot)
  output logic                wp_req_valid,
  input  wire logic           wp_req_ready,
  output logic      [WAW-1:0] wp_req_addr,
  output logic      [63:0]    wp_req_wdata,
  input  wire logic           wp_rsp_valid,
  input  wire logic           wp_rsp_rerr,
  // metadata update
  output logic                upd,
  output logic      [7:0]     upd_d,
  output logic      [3:0]     upd_lb,
  output logic      [31:0]    upd_lba,
  output logic      [31:0]    upd_crc,
  output logic                upd_valid,
  output logic                upd_poison,
  // lock release + completion
  output logic                rel,
  output logic      [7:0]     rel_d,
  output logic      [7:0]     rel_p,
  output logic                cpl_valid,
  output logic      [CW_-1:0] cpl_data,
  input  wire logic           cpl_ready,
  output logic                active,
  output logic                ev_beat,
  output logic                ev_ecc_wait
);
  `include "sfsb_funcs.svh"

  localparam int PAR_BEATS = LB_BEATS / 8;
  localparam int CWB       = LB_BEATS + PAR_BEATS;
  localparam int OOB       = PAGE_LBS * CWB;
  localparam int RPL       = 2 + PAR_BEATS + LB_BEATS;   // reads per logical block
  localparam int CNTW      = 16;
  localparam int FAW       = $clog2(FD);
  localparam int SIW       = $clog2(RPL + 1);
  localparam int PBW       = (PAR_BEATS > 1) ? $clog2(PAR_BEATS) : 1;

  typedef enum logic [1:0] {S_IDLE, S_RUN, S_DRAIN, S_CPL} st_t;
  st_t st;

  /* verilator lint_off UNUSEDSIGNAL */
  logic [DW_-1:0]  d;                    // not every descriptor field is used by this engine
  logic            f_full;               // never full: space is reserved before issue
  /* verilator lint_on UNUSEDSIGNAL */
  logic [CNTW-1:0] tot, rd_iss, rd_rcv, wr_iss, wr_ack;
  logic [31:0]     crc, elapsed;
  logic [7:0]      lb_err, erased_m, eflags;
  logic [15:0]     ce_bits;
  logic [3:0]      rk, sk;               // reader / stage logical-block counters
  logic [SIW-1:0]  ri, si;               // reader / stage index inside a block
  logic [63:0]     meta_q;
  logic            mpar, lb_par, lb_ue;
  logic [31:0]     m_lba, m_crc;
  logic            m_ue, m_erased;
  logic [63:0]     chkbuf [PAR_BEATS];

  wire [WAW-1:0] pbase = WAW'(PS_BASE + 32'(`SFSB_DF_PSLOT(d)) * PSLOT_BEATS);

  // ------------------------------------------------------------ page reader
  logic         f_empty, f_pop;
  logic [72:0]  f_rd;
  logic [FAW:0] f_cnt;
  wire [CNTW-1:0] inflight = rd_iss - rd_rcv;
  wire credit_ok = ({1'b0, inflight} + {{(CNTW-FAW){1'b0}}, f_cnt}) < (CNTW+1)'(FD);

  wire [3:0]     rj = `SFSB_DF_LBF(d) + rk;
  logic [WAW-1:0] raddr;
  always_comb begin
    if (ri == '0)                           raddr = pbase + WAW'(OOB) + WAW'(rj);
    else if (ri == SIW'(1))                 raddr = pbase + WAW'(OOB + PAGE_LBS);
    else if (32'(ri) < 2 + PAR_BEATS)       raddr = pbase + WAW'(32'(rj) * CWB + LB_BEATS + 32'(ri) - 2);
    else                                    raddr = pbase + WAW'(32'(rj) * CWB + 32'(ri) - 2 - PAR_BEATS);
  end

  assign rp_req_valid = (st == S_RUN) && (rd_iss < tot) && credit_ok;
  assign rp_req_addr  = raddr;
  wire   r_acc        = rp_req_valid && rp_req_ready;

  sfsb_fifo #(.W(73), .DEPTH(FD)) u_f (
    .clk, .rst_n, .push(rp_rsp_valid), .wdata({rp_rsp_rerr, rp_rsp_perr, rp_rsp_rdata}),
    .pop(f_pop), .rdata(f_rd), .full(f_full), .empty(f_empty), .count(f_cnt)
  );

  // ------------------------------------------------------------ write queue
  logic           q_push, q_full, q_empty;
  logic [WAW+63:0] q_rd;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [2:0]     q_cnt;
  /* verilator lint_on UNUSEDSIGNAL */

  // ------------------------------------------------------------ stage
  wire [3:0]  sj      = `SFSB_DF_LBF(d) + sk;
  wire [31:0] exp_lba = `SFSB_DF_LBA(d) + 32'(sk);
  wire [63:0] beat    = f_rd[63:0];
  wire [7:0]  perr    = f_rd[71:64];
  wire        rerr    = f_rd[72];
  wire        is_meta = (si == '0);
  wire        is_oobp = (si == SIW'(1));
  wire        is_par  = !is_meta && !is_oobp && (32'(si) < 2 + PAR_BEATS);
  wire        is_data = (32'(si) >= 2 + PAR_BEATS);
  /* verilator lint_off UNUSEDSIGNAL */
  wire [SIW-1:0] di   = si - SIW'(2 + PAR_BEATS);          // data beat index
  wire [SIW-1:0] pi   = si - SIW'(2);                      // check-byte beat index
  wire [SIW-1:0] dq   = di >> 3;                           // check-byte beat of data beat di
  /* verilator lint_on UNUSEDSIGNAL */

  wire take = (st == S_RUN) && !f_empty && (!is_data || !q_full);
  assign f_pop = take;

  // metadata decode (OOB beat j with check byte j of the OOB parity beat)
  wire [7:0]  mbyte = beat[8*sj[2:0] +: 8];
  logic [63:0] m_dec;
  logic        m_ce_w, m_ue_w;
  sfsb_ecc_dec64 u_dec_m (.data_i(meta_q), .chk_i(mbyte), .data_o(m_dec), .ce_o(m_ce_w), .ue_o(m_ue_w));

  // data decode
  wire [63:0] cw_chk = chkbuf[dq[PBW-1:0]];
  wire [7:0]  dchk   = cw_chk[8*di[2:0] +: 8];
  logic [63:0] corr;
  logic        ce_w, ue_w;
  sfsb_ecc_dec64 u_dec_d (.data_i(beat), .chk_i(dchk), .data_o(corr), .ce_o(ce_w), .ue_o(ue_w));

  wire [63:0] ks     = sfsb_keystream(key, exp_lba, 16'(di));
  wire [63:0] plain  = (CRYPTO_EN != 0 && `SFSB_DF_CRYPT(d)) ? (corr ^ ks) : corr;
  wire [31:0] crc_nx = sfsb_crc32c_beat(crc, plain);

  wire [WAW-1:0] dslot_w = WAW'((32'(`SFSB_DF_DSLOT(d)) << DSB_LOG2) + 32'(sj) * LB_BEATS);
  assign q_push = take && is_data;
  sfsb_fifo #(.W(WAW + 64), .DEPTH(4)) u_wq (
    .clk, .rst_n, .push(q_push), .wdata({dslot_w + WAW'(di), plain}), .pop(wp_req_valid && wp_req_ready),
    .rdata(q_rd), .full(q_full), .empty(q_empty), .count(q_cnt)
  );
  assign wp_req_valid = !q_empty;
  assign {wp_req_addr, wp_req_wdata} = q_rd;

  // end-of-block evaluation (V2)
  wire lb_done  = take && is_data && (32'(di) == LB_BEATS - 1);
  wire par_now  = (|perr) || rerr;
  wire e_par    = lb_par || par_now || mpar;
  wire e_ue     = lb_ue || ue_w;
  wire e_crc    = (~crc_nx != m_crc);
  wire e_lba    = (m_lba != exp_lba);
  wire erased   = m_erased && !e_par;
  wire good     = !erased && !e_par && !m_ue && !e_ue && !e_crc && !e_lba;

  assign upd        = lb_done;
  assign upd_d      = `SFSB_DF_DSLOT(d);
  assign upd_lb     = sj;
  assign upd_lba    = m_lba;
  assign upd_crc    = m_crc;
  assign upd_valid  = good;
  assign upd_poison = !good && !erased;

  // ------------------------------------------------------------ control
  assign desc_take = (st == S_IDLE) && desc_valid;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; d <= '0; tot <= '0; rd_iss <= '0; rd_rcv <= '0; wr_iss <= '0; wr_ack <= '0;
      crc <= 32'hFFFF_FFFF; elapsed <= '0; lb_err <= '0; erased_m <= '0; eflags <= '0; ce_bits <= '0;
      rk <= '0; sk <= '0; ri <= '0; si <= '0; meta_q <= '0; mpar <= 1'b0; lb_par <= 1'b0; lb_ue <= 1'b0;
      m_lba <= '0; m_crc <= '0; m_ue <= 1'b0; m_erased <= 1'b0;
      for (int p = 0; p < PAR_BEATS; p++) chkbuf[p] <= '0;
    end else begin
      if (st != S_IDLE) elapsed <= elapsed + 1'b1;
      if (rp_rsp_valid) rd_rcv  <= rd_rcv + 1'b1;
      if (q_push)       wr_iss  <= wr_iss + 1'b1;
      if (wp_rsp_valid) begin
        wr_ack <= wr_ack + 1'b1;
        if (wp_rsp_rerr) eflags[`SFSB_EF_BUF_PAR] <= 1'b1;
      end
      if (r_acc) begin
        rd_iss <= rd_iss + 1'b1;
        if (32'(ri) == RPL - 1) begin
          ri <= '0;
          rk <= rk + 1'b1;
        end else begin
          ri <= ri + 1'b1;
        end
      end

      case (st)
        S_IDLE: if (desc_valid) begin
          d   <= desc;
          tot <= CNTW'(32'(`SFSB_DF_LBC(desc)) * RPL);
          rd_iss <= '0; rd_rcv <= '0; wr_iss <= '0; wr_ack <= '0;
          crc <= 32'hFFFF_FFFF; elapsed <= '0; lb_err <= '0; erased_m <= '0; eflags <= '0; ce_bits <= '0;
          rk <= '0; sk <= '0; ri <= '0; si <= '0; mpar <= 1'b0; lb_par <= 1'b0; lb_ue <= 1'b0;
          st <= S_RUN;
        end
        S_RUN: begin
          if (take) begin
            si <= (32'(si) == RPL - 1) ? '0 : si + 1'b1;
            if (is_meta) begin
              meta_q <= beat;
              mpar   <= par_now;
            end
            if (is_oobp) begin
              m_lba    <= m_dec[31:0];
              m_crc    <= m_dec[63:32];
              m_ue     <= m_ue_w;
              m_erased <= (m_dec == 64'hFFFF_FFFF_FFFF_FFFF) && !m_ue_w;
              mpar     <= mpar || perr[sj[2:0]] || rerr;
              if (m_ce_w && ce_bits != 16'hFFFF) ce_bits <= ce_bits + 1'b1;
            end
            if (is_par) begin
              chkbuf[pi[PBW-1:0]] <= beat;
              lb_par <= lb_par || par_now;
            end
            if (is_data) begin
              if (ce_w && ce_bits != 16'hFFFF) ce_bits <= ce_bits + 1'b1;
              if (lb_done) begin
                crc    <= 32'hFFFF_FFFF;
                lb_par <= 1'b0;
                lb_ue  <= 1'b0;
                sk     <= sk + 1'b1;
                if (erased) erased_m[sj[2:0]] <= 1'b1;
                if (!good && !erased) begin
                  lb_err[sj[2:0]] <= 1'b1;
                  if (e_par)  eflags[`SFSB_EF_BUF_PAR] <= 1'b1;
                  if (m_ue)   eflags[`SFSB_EF_META_UE] <= 1'b1;
                  if (e_ue)   eflags[`SFSB_EF_UE]      <= 1'b1;
                  if (!m_ue && e_lba) eflags[`SFSB_EF_LBA] <= 1'b1;
                  if (!m_ue && e_crc) eflags[`SFSB_EF_CRC] <= 1'b1;
                end
                if (sk + 1'b1 == `SFSB_DF_LBC(d)) st <= S_DRAIN;
              end else begin
                crc    <= crc_nx;
                lb_par <= lb_par || par_now;
                lb_ue  <= lb_ue || ue_w;
              end
            end
          end
        end
        S_DRAIN: if (q_empty && wr_ack == wr_iss) st <= S_CPL;
        S_CPL:   if (cpl_ready) st <= S_IDLE;
        default: st <= S_IDLE;
      endcase
    end
  end

  wire [7:0] status = eflags[`SFSB_EF_BUF_PAR] ? `SFSB_ST_BUF_PAR   :
                      eflags[`SFSB_EF_META_UE] ? `SFSB_ST_META_UE   :
                      eflags[`SFSB_EF_UE]      ? `SFSB_ST_UNCORR    :
                      eflags[`SFSB_EF_LBA]     ? `SFSB_ST_LBA       :
                      eflags[`SFSB_EF_CRC]     ? `SFSB_ST_CRC       :
                      (erased_m != 8'd0)       ? `SFSB_ST_ERASED    :
                      (ce_bits != 16'd0)       ? `SFSB_ST_CORRECTED : `SFSB_ST_OK;

  assign cpl_valid = (st == S_CPL);
  assign cpl_data  = {elapsed,
                      eflags, erased_m, ce_bits,
                      lb_err, status, 2'b00, `SFSB_DF_CLS(d), `SFSB_DF_OPC(d), `SFSB_DF_TID(d)};
  assign rel       = cpl_valid && cpl_ready;
  assign rel_d     = `SFSB_DF_DSLOT(d);
  assign rel_p     = `SFSB_DF_PSLOT(d);
  assign active    = (st != S_IDLE);
  assign ev_beat   = q_push;
  assign ev_ecc_wait = (st == S_RUN) && f_empty;
endmodule

`default_nettype wire
