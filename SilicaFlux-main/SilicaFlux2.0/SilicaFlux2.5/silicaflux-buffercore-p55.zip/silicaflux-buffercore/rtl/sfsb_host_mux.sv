// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_host_mux   (host-memory DMA adapter)
// Two DMA engines (0 = H2B, reads; 1 = B2H, writes) -> one SFB2 master port
// to host memory (DataFabric PROTOCOL.md rev 2.0).
//
// SFB2 rules honoured:
//   R2  a presented request is held (same engine, same payload) until accepted
//       ('hold' register); engines keep their payload stable by construction;
//   R3  m_req_valid depends only on registered state and engine valids;
//   R4  m_rsp_ready = 1: every engine reserved space for its responses;
//   R5  responses are in order: an in-flight FIFO of source IDs routes them;
//   R9/R10 64-bit aligned single-beat transfers, full strobes.
//   R6  MAX_OUT = 1 (default) is the rev-2.0 crossbar limit (one outstanding
//       transaction per master).  MAX_OUT > 1 is legal only when the port is
//       connected point-to-point to a target that pipelines (DataFabric
//       PROTOCOL.md section 7: "masters that track their own outstanding
//       count"), e.g. the testbench host model or a PCIe endpoint shell; it is
//       the measured optimisation of docs/06_PERFORMANCE.md.
//
// Burst handling: an engine marks the last beat of each burst (MAX_BURST beats,
// never crossing 4 KiB).  The arbiter prefers the current burst owner while it
// has requests and switches engines (round robin) only at burst boundaries or
// when the owner has nothing to send, so neither direction can starve the
// other for more than one burst.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfsb_defs.svh"
`default_nettype none

module sfsb_host_mux #(
  parameter int MAX_OUT = 1,
  localparam int IFD    = (MAX_OUT < 2) ? 2 : (1 << $clog2(MAX_OUT)),
  localparam int IFW    = $clog2(IFD)
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // engine 0 (H2B): reads
  input  wire logic        e0_valid,
  output logic             e0_ready,
  input  wire logic [31:0] e0_addr,
  input  wire logic        e0_last,
  output logic             e0_rsp_valid,
  output logic [63:0]      e0_rsp_rdata,
  output logic             e0_rsp_err,
  // engine 1 (B2H): writes
  input  wire logic        e1_valid,
  output logic             e1_ready,
  input  wire logic [31:0] e1_addr,
  input  wire logic [63:0] e1_wdata,
  input  wire logic        e1_last,
  output logic             e1_rsp_valid,
  output logic             e1_rsp_err,
  // SFB2 master
  output logic             m_req_valid,
  input  wire logic        m_req_ready,
  output logic             m_req_write,
  output logic [31:0]      m_req_addr,
  output logic [63:0]      m_req_wdata,
  output logic [7:0]       m_req_wstrb,
  input  wire logic        m_rsp_valid,
  output logic             m_rsp_ready,
  input  wire logic [63:0] m_rsp_rdata,
  input  wire logic        m_rsp_error,
  // instrumentation
  output logic             ev_req_wait,
  output logic             ev_rsp_wait
);
  if (MAX_OUT < 1 || MAX_OUT > 16) begin : g_err_out
    `SFSB_CFG_FATAL("sfsb_host_mux: MAX_OUT must be in 1..16")
  end

  logic hold_q, hold_src, burst_q, burst_src, last_src;
  logic sel;

  always_comb begin
    if (hold_q)                                       sel = hold_src;
    else if (burst_q && (burst_src ? e1_valid : e0_valid)) sel = burst_src;
    else if (e0_valid && e1_valid)                    sel = !last_src;
    else                                              sel = e1_valid;
  end

  logic         f_full, f_empty, f_src;
  logic [IFW:0] f_cnt;
  wire sel_valid = sel ? e1_valid : e0_valid;
  wire sel_last  = sel ? e1_last  : e0_last;
  assign m_req_valid = sel_valid && (32'(f_cnt) < MAX_OUT) && !f_full;
  assign m_req_write = sel;
  assign m_req_addr  = sel ? e1_addr : e0_addr;
  assign m_req_wdata = sel ? e1_wdata : 64'd0;
  assign m_req_wstrb = sel ? 8'hFF : 8'h00;
  wire acc = m_req_valid && m_req_ready;
  assign e0_ready = acc && !sel;
  assign e1_ready = acc &&  sel;

  sfsb_fifo #(.W(1), .DEPTH(IFD)) u_inflight (
    .clk, .rst_n, .push(acc), .wdata(sel), .pop(m_rsp_valid),
    .rdata(f_src), .full(f_full), .empty(f_empty), .count(f_cnt)
  );

  assign m_rsp_ready  = 1'b1;
  assign e0_rsp_valid = m_rsp_valid && !f_src;
  assign e0_rsp_rdata = m_rsp_rdata;
  assign e0_rsp_err   = m_rsp_error;
  assign e1_rsp_valid = m_rsp_valid &&  f_src;
  assign e1_rsp_err   = m_rsp_error;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      hold_q <= 1'b0; hold_src <= 1'b0; burst_q <= 1'b0; burst_src <= 1'b0; last_src <= 1'b1;
    end else begin
      hold_q   <= m_req_valid && !m_req_ready;
      hold_src <= sel;
      if (acc) begin
        last_src  <= sel;
        burst_q   <= !sel_last;
        burst_src <= sel;
      end
    end
  end

  assign ev_req_wait = m_req_valid && !m_req_ready;
  assign ev_rsp_wait = !f_empty && !m_rsp_valid;

`ifndef SYNTHESIS
  always @(posedge clk) begin
    if (rst_n && m_rsp_valid && f_empty) $error("%m: unsolicited host response");
  end
`endif
endmodule

`default_nettype wire
