// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_bank_xbar
// NP master ports x NB parity-protected SRAM banks (sfsb_sram_bank).
//
// Address interleaving: buffer word address wa -> bank = wa[BB-1:0],
// row = wa >> BB (BB = log2 NB).  Consecutive beats of a burst therefore
// rotate over the banks, so up to NB masters streaming sequential bursts
// proceed in parallel and a single master is never limited by one bank.
//
// Port contract (internal, stricter than SFB2):
//   * request: valid/ready; payload stable while valid && !ready;
//   * at most one request per port per cycle; a request names one bank;
//   * responses are NOT back-pressured: they arrive exactly one cycle after
//     acceptance (bank latency 1), in acceptance order per port, and the master
//     must accept them (every engine reserves space before it issues).
//   * rsp_we = 1 for a write acknowledgement (array written, rule R7).
//
// Arbitration policy, per bank (documented and measured in
// docs/04_ARBITRATION.md):
//   1. AGED   : a port whose request has waited >= AGE_LIMIT cycles;
//   2. HIGH   : ports in HIPRI_MASK (the NAND-controller port: the NAND bus
//               is the scarce resource and must not be starved);
//   3. NORMAL : every other port.
//   The highest non-empty class wins; round robin inside the class (pointer
//   moves past the winner on acceptance).  A request presented to a bank that
//   is not ready keeps the grant (grant lock) so the bank sees a stable
//   payload.  Bound: once a bank has finished initialisation it accepts one
//   request every cycle, so any request is accepted within
//   AGE_LIMIT + NP - 1 cycles (aging promotes it, then at most NP-1 other aged
//   requests are served before it).  acc_wait feeds the MAX_WAIT performance
//   counter; the testbench checks every acceptance against the bound.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`include "sfsb_defs.svh"
`default_nettype none

module sfsb_bank_xbar #(
  parameter int NP         = 8,
  parameter int NB         = 4,
  parameter int WAW        = 12,     // buffer word-address width
  parameter int BANK_DEPTH = 1024,
  parameter int AGE_LIMIT  = 16,
  parameter int HIPRI_MASK = 0,      // bit p = 1: port p is in the HIGH class
  parameter int BACKEND    = `SRAM_BACKEND_GENERIC,
  parameter int MACRO      = 0,
  localparam int BB        = $clog2(NB),
  localparam int RW        = (BANK_DEPTH > 1) ? $clog2(BANK_DEPTH) : 1,
  localparam int IDW       = (NP > 1) ? $clog2(NP) : 1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // master ports (flattened)
  input  wire logic [NP-1:0]     p_req_valid,
  output logic      [NP-1:0]     p_req_ready,
  input  wire logic [NP-1:0]     p_req_we,
  input  wire logic [NP*WAW-1:0] p_req_addr,
  input  wire logic [NP*64-1:0]  p_req_wdata,
  input  wire logic [NP*8-1:0]   p_req_be,
  output logic      [NP-1:0]     p_rsp_valid,
  output logic      [NP-1:0]     p_rsp_we,
  output logic      [NP*64-1:0]  p_rsp_rdata,
  output logic      [NP*8-1:0]   p_rsp_perr,
  output logic      [NP-1:0]     p_rsp_rerr,
  // status / instrumentation
  output logic                   init_done,
  output logic      [NB-1:0]     bank_rd_acc,
  output logic      [NB-1:0]     bank_wr_acc,
  output logic      [NP-1:0]     p_stall,
  output logic      [15:0]       acc_wait,     // longest wait among requests accepted this cycle
  // fault injection
  input  wire logic              fi_arm,
  input  wire logic [7:0]        fi_bank,
  input  wire logic [RW-1:0]     fi_row,
  input  wire logic [71:0]       fi_mask,
  output logic                   fi_fire
);
  if (NB < 2 || (NB & (NB - 1)) != 0) begin : g_err_nb_not_pow2
    `SFSB_CFG_FATAL("sfsb_bank_xbar: NB must be a power of two >= 2")
  end
  if (NP < 2 || NP > 16) begin : g_err_np_range
    `SFSB_CFG_FATAL("sfsb_bank_xbar: NP must be in 2..16")
  end
  if (AGE_LIMIT < 1 || AGE_LIMIT > 60000) begin : g_err_age
    `SFSB_CFG_FATAL("sfsb_bank_xbar: AGE_LIMIT must be in 1..60000")
  end

  // ------------------------------------------------------------ per-port decode + aging
  logic [BB-1:0] p_bank [NP];
  logic [RW-1:0] p_row  [NP];
  logic [15:0]   wcnt   [NP];
  logic [NP-1:0] aged;

  localparam logic [NP-1:0] HI = HIPRI_MASK[NP-1:0];

  always_comb begin
    for (int p = 0; p < NP; p++) begin
      p_bank[p] = p_req_addr[p*WAW +: BB];
      p_row[p]  = RW'(p_req_addr[p*WAW + BB +: (WAW - BB)]);
      aged[p]   = (wcnt[p] >= 16'(AGE_LIMIT));
    end
  end

  assign p_stall = p_req_valid & ~p_req_ready;

  always_comb begin
    acc_wait = '0;
    for (int p = 0; p < NP; p++)
      if (p_req_valid[p] && p_req_ready[p] && wcnt[p] > acc_wait) acc_wait = wcnt[p];
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int p = 0; p < NP; p++) wcnt[p] <= '0;
    end else begin
      for (int p = 0; p < NP; p++) begin
        if (p_req_valid[p] && p_req_ready[p]) begin
          wcnt[p] <= '0;
        end else if (p_req_valid[p] && init_done) begin
          if (wcnt[p] != 16'hFFFF) wcnt[p] <= wcnt[p] + 1'b1;
        end else begin
          wcnt[p] <= '0;
        end
      end
    end
  end

  // ------------------------------------------------------------ banks
  logic [NB-1:0]  b_valid, b_ready, b_we, b_rsp_valid, b_rsp_we, b_rsp_rerr, b_init, b_fire;
  logic [RW-1:0]  b_row   [NB];
  logic [63:0]    b_wdata [NB];
  logic [7:0]     b_be    [NB];
  logic [IDW-1:0] b_id    [NB];
  logic [63:0]    b_rdata [NB];
  logic [7:0]     b_perr  [NB];
  logic [IDW-1:0] b_rid   [NB];

  logic [IDW-1:0] lock_id [NB];
  logic [NB-1:0]  lock_q;
  logic [IDW-1:0] ptr     [NB];
  logic [IDW-1:0] win     [NB];
  logic [NP-1:0]  reqb    [NB];

  for (genvar b = 0; b < NB; b++) begin : g_bank
    logic [NP-1:0] cand;
    logic          found;

    always_comb begin
      for (int p = 0; p < NP; p++) reqb[b][p] = p_req_valid[p] && (p_bank[p] == BB'(b));
      if ((reqb[b] & aged) != '0)      cand = reqb[b] & aged;
      else if ((reqb[b] & HI) != '0)   cand = reqb[b] & HI;
      else                             cand = reqb[b];
      win[b] = ptr[b];
      found  = 1'b0;
      for (int i = 0; i < NP; i++) begin
        if (!found && cand[(32'(ptr[b]) + i) % NP]) begin
          found  = 1'b1;
          win[b] = IDW'((32'(ptr[b]) + i) % NP);
        end
      end
      if (lock_q[b]) win[b] = lock_id[b];
    end

    assign b_valid[b] = (reqb[b] != '0);
    assign b_we[b]    = p_req_we[win[b]];
    assign b_row[b]   = p_row[win[b]];
    assign b_wdata[b] = p_req_wdata[win[b]*64 +: 64];
    assign b_be[b]    = p_req_be[win[b]*8 +: 8];
    assign b_id[b]    = win[b];

    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        ptr[b]     <= '0;
        lock_q[b]  <= 1'b0;
        lock_id[b] <= '0;
      end else begin
        if (b_valid[b] && b_ready[b]) begin
          ptr[b]    <= (32'(win[b]) == NP - 1) ? '0 : win[b] + 1'b1;
          lock_q[b] <= 1'b0;
        end else if (b_valid[b] && init_done) begin
          lock_q[b]  <= 1'b1;
          lock_id[b] <= win[b];
        end
      end
    end

    assign bank_rd_acc[b] = b_valid[b] && b_ready[b] && !b_we[b];
    assign bank_wr_acc[b] = b_valid[b] && b_ready[b] &&  b_we[b];

    sfsb_sram_bank #(
      .DEPTH(BANK_DEPTH), .IDW(IDW), .BACKEND(BACKEND), .MACRO(MACRO)
    ) u_bank (
      .clk, .rst_n,
      .req_valid(b_valid[b]), .req_ready(b_ready[b]), .req_we(b_we[b]), .req_row(b_row[b]),
      .req_wdata(b_wdata[b]), .req_be(b_be[b]), .req_id(b_id[b]),
      .rsp_valid(b_rsp_valid[b]), .rsp_we(b_rsp_we[b]), .rsp_rdata(b_rdata[b]),
      .rsp_perr(b_perr[b]), .rsp_rerr(b_rsp_rerr[b]), .rsp_id(b_rid[b]),
      .init_done(b_init[b]),
      .fi_arm(fi_arm && (fi_bank == 8'(b))), .fi_row(fi_row), .fi_mask(fi_mask), .fi_fire(b_fire[b])
    );
  end

  assign init_done = &b_init;
  assign fi_fire   = |b_fire;

  // grant: a port is ready when the bank it addresses accepts it
  always_comb begin
    p_req_ready = '0;
    for (int b = 0; b < NB; b++)
      if (b_valid[b] && b_ready[b]) p_req_ready[win[b]] = 1'b1;
  end

  // ------------------------------------------------------------ response routing
  always_comb begin
    p_rsp_valid = '0;
    p_rsp_we    = '0;
    p_rsp_rerr  = '0;
    p_rsp_rdata = '0;
    p_rsp_perr  = '0;
    for (int b = 0; b < NB; b++) begin
      if (b_rsp_valid[b]) begin
        p_rsp_valid[b_rid[b]]          = 1'b1;
        p_rsp_we[b_rid[b]]             = b_rsp_we[b];
        p_rsp_rerr[b_rid[b]]           = b_rsp_rerr[b];
        p_rsp_rdata[b_rid[b]*64 +: 64] = b_rdata[b];
        p_rsp_perr[b_rid[b]*8 +: 8]    = b_perr[b];
      end
    end
  end

`ifndef SYNTHESIS
  // two banks never answer the same port in one cycle (one acceptance per port
  // per cycle, fixed latency)
  always @(posedge clk) begin
    if (rst_n) begin
      for (int b1 = 0; b1 < NB; b1++)
        for (int b2 = b1 + 1; b2 < NB; b2++)
          if (b_rsp_valid[b1] && b_rsp_valid[b2] && b_rid[b1] == b_rid[b2])
            $error("%m: two bank responses for port %0d in one cycle", b_rid[b1]);
    end
  end
`endif
endmodule

`default_nettype wire
