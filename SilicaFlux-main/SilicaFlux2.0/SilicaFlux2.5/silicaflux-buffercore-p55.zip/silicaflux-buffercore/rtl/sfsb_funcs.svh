// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_funcs.svh
// Functions included INSIDE module bodies (no package: Yosys 0.33).  Written
// in Verilog-2001 function style (assignment to the function name, loop
// variables declared up front) so that Yosys 0.33, Icarus 12 and Verilator 5
// all accept them.
//
//   sfsb_crc32c_beat : CRC-32C (Castagnoli, reflected polynomial 0x82F63B78)
//                      register update over one 64-bit little-endian beat
//                      (byte 0 = bits [7:0] first).  A logical block's
//                      stored check value is  ~crc  after all beats, with the
//                      register initialised to 32'hFFFF_FFFF (RFC 3720 CRC32C;
//                      check value of "123456789" = 32'hE3069283, verified by
//                      tb/tb_sfsb_units.sv).
//   sfsb_keystream   : 64-bit keystream word of the OPTIONAL crypt stage.
//                      THIS IS NOT A CIPHER.  It is a keyed, LBA/beat-tweaked
//                      XOR mask (xorshift/rotate mixing) that exists only to
//                      exercise the pipeline position of an encryption engine
//                      (integrity is generated and checked on plaintext, NAND
//                      holds transformed data).  No AES/XTS engine exists in
//                      the repository; see docs/08_LIMITATIONS.md.
// =============================================================================

  function automatic [31:0] sfsb_crc32c_beat(input [31:0] c, input [63:0] d);
    integer b, i;
    reg [31:0] x;
    begin
      x = c;
      for (b = 0; b < 8; b = b + 1) begin
        x = x ^ {24'd0, d[8*b +: 8]};
        for (i = 0; i < 8; i = i + 1)
          x = x[0] ? ((x >> 1) ^ 32'h82F6_3B78) : (x >> 1);
      end
      sfsb_crc32c_beat = x;
    end
  endfunction

  function automatic [63:0] sfsb_rotl64(input [63:0] v, input integer n);
    begin
      sfsb_rotl64 = (v << n) | (v >> (64 - n));
    end
  endfunction

  function automatic [63:0] sfsb_keystream(input [63:0] kk, input [31:0] lba, input [15:0] beat);
    reg [63:0] x;
    begin
      x = kk ^ {lba, beat, 16'h5A3C};
      x = x ^ (x << 13);
      x = x ^ (x >> 7);
      x = x ^ (x << 17);
      x = x + sfsb_rotl64(kk, 29);
      x = x ^ sfsb_rotl64(x, 41) ^ sfsb_rotl64(x, 11);
      sfsb_keystream = x;
    end
  endfunction
