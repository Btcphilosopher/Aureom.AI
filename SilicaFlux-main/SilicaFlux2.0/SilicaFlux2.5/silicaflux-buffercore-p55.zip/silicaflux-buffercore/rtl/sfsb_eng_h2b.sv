// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_eng_h2b   (host ingress DMA)
// host memory --(SFB2 reads)--> response FIFO --> data slot (bank writes)
//
// Integrity point G1 (generate): the CRC-32C of every logical block is
// computed here, on the data exactly as it enters the buffer, and stored in
// the metadata buffer with the block's LBA.  From here on the check value
// travels with the data (buffer metadata -> NAND OOB -> buffer metadata) and
// is never regenerated; every later stage only verifies it.
//
// Flow control: a host read is issued only when the response FIFO has a free
// entry reserved for it (inflight + fifo_count < FD), so host responses are
// always accepted (rsp_ready = 1 at the host port).  Bursts: at most
// MAX_BURST consecutive beats, never crossing a 4 KiB host boundary; the
// 'last' flag lets the host-port arbiter switch engines only at burst ends.
// Completion: posted only after every bank write of the transfer has been
// acknowledged by the SRAM (array written, rule R7) - i.e. the data is
// committed in the buffer.  The completion is NOT a durability statement: the
// slot is DIRTY (volatile) until firmware commits it after the NAND program.
// The slot's write lock is released in the cycle the completion enters the CQ.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfsb_defs.svh"
`default_nettype none

module sfsb_eng_h2b #(
  parameter int LB_BEATS  = 64,
  parameter int WAW       = 12,
  parameter int DSB_LOG2  = 8,
  parameter int FD        = 8,
  parameter int MAX_BURST = 16,
  localparam int DW_      = `SFSB_DESC_W,
  localparam int CW_      = `SFSB_CPL_W
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  // descriptor
  input  wire logic           desc_valid,
  input  wire logic [DW_-1:0] desc,
  output logic                desc_take,
  // host port (to sfsb_host_mux)
  output logic                hq_valid,
  input  wire logic           hq_ready,
  output logic      [31:0]    hq_addr,
  output logic                hq_last,
  input  wire logic           hr_valid,
  input  wire logic [63:0]    hr_rdata,
  input  wire logic           hr_err,
  // bank port (writes)
  output logic                bp_req_valid,
  input  wire logic           bp_req_ready,
  output logic      [WAW-1:0] bp_req_addr,
  output logic      [63:0]    bp_req_wdata,
  input  wire logic           bp_rsp_valid,
  input  wire logic           bp_rsp_rerr,
  // metadata update
  output logic                upd,
  output logic      [7:0]     upd_d,
  output logic      [3:0]     upd_lb,
  output logic      [31:0]    upd_lba,
  output logic      [31:0]    upd_crc,
  output logic                upd_ok,
  // lock release + completion
  output logic                rel,
  output logic      [7:0]     rel_d,
  output logic                cpl_valid,
  output logic      [CW_-1:0] cpl_data,
  input  wire logic           cpl_ready,
  // instrumentation
  output logic                active,
  output logic                ev_beat
);
  `include "sfsb_funcs.svh"

  localparam int CNTW = 16;
  localparam int FAW  = $clog2(FD);
  localparam int LBB  = $clog2(LB_BEATS);

  typedef enum logic [1:0] {S_IDLE, S_RUN, S_CPL} st_t;
  st_t st;

  /* verilator lint_off UNUSEDSIGNAL */
  logic [DW_-1:0]  d;                    // not every descriptor field is used by this engine
  logic            f_full;               // never full: space is reserved before issue
  /* verilator lint_on UNUSEDSIGNAL */
  logic [CNTW-1:0] tot, iss, rcv, wr, ack, bcnt;
  logic [31:0]     crc, elapsed;
  logic [7:0]      lb_err, eflags;
  logic [LBB-1:0]  bib;     // beat index inside the current logical block
  logic [3:0]      k;       // logical block counter inside the transfer

  // ------------------------------------------------------------ response FIFO
  logic        f_empty, f_pop;
  logic [64:0] f_rd;
  logic [FAW:0] f_cnt;
  sfsb_fifo #(.W(65), .DEPTH(FD)) u_f (
    .clk, .rst_n, .push(hr_valid), .wdata({hr_err, hr_rdata}), .pop(f_pop),
    .rdata(f_rd), .full(f_full), .empty(f_empty), .count(f_cnt)
  );

  wire [CNTW-1:0] inflight = iss - rcv;
  wire credit_ok = ({1'b0, inflight} + {{(CNTW-FAW){1'b0}}, f_cnt}) < (CNTW+1)'(FD);

  // ------------------------------------------------------------ host reads
  wire [31:0] cur_haddr = `SFSB_DF_HADDR(d) + {16'd0, iss[CNTW-4:0], 3'b000};
  assign hq_valid = (st == S_RUN) && (iss < tot) && credit_ok;
  assign hq_addr  = cur_haddr;
  assign hq_last  = (iss + 1'b1 == tot) || (bcnt + 1'b1 == CNTW'(MAX_BURST)) || (cur_haddr[11:3] == 9'h1FF);
  wire   h_acc    = hq_valid && hq_ready;

  // ------------------------------------------------------------ bank writes
  wire [WAW-1:0] wbase = WAW'((32'(`SFSB_DF_DSLOT(d)) << DSB_LOG2) + 32'(`SFSB_DF_LBF(d)) * LB_BEATS);
  assign bp_req_valid = (st == S_RUN) && !f_empty;
  assign bp_req_addr  = wbase + WAW'(wr);
  assign bp_req_wdata = f_rd[63:0];
  wire   w_acc        = bp_req_valid && bp_req_ready;
  assign f_pop        = w_acc;

  wire [31:0] crc_nx  = sfsb_crc32c_beat(crc, f_rd[63:0]);
  wire        lb_end  = w_acc && (bib == LBB'(LB_BEATS - 1));
  wire        beat_err = f_rd[64];

  assign upd     = lb_end;
  assign upd_d   = `SFSB_DF_DSLOT(d);
  assign upd_lb  = `SFSB_DF_LBF(d) + k;
  assign upd_lba = `SFSB_DF_LBA(d) + 32'(k);
  assign upd_crc = ~crc_nx;
  assign upd_ok  = !(lb_err[upd_lb[2:0]] || beat_err);

  // ------------------------------------------------------------ control
  assign desc_take = (st == S_IDLE) && desc_valid;
  wire done = (wr == tot) && (ack == tot) && (rcv == tot);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; d <= '0; tot <= '0; iss <= '0; rcv <= '0; wr <= '0; ack <= '0; bcnt <= '0;
      crc <= 32'hFFFF_FFFF; elapsed <= '0; lb_err <= '0; eflags <= '0; bib <= '0; k <= '0;
    end else begin
      case (st)
        S_IDLE: if (desc_valid) begin
          d       <= desc;
          tot     <= CNTW'(32'(`SFSB_DF_LBC(desc)) * LB_BEATS);
          iss     <= '0; rcv <= '0; wr <= '0; ack <= '0; bcnt <= '0;
          crc     <= 32'hFFFF_FFFF;
          elapsed <= '0; lb_err <= '0; eflags <= '0; bib <= '0; k <= '0;
          st      <= S_RUN;
        end
        S_RUN: begin
          elapsed <= elapsed + 1'b1;
          if (h_acc) begin
            iss  <= iss + 1'b1;
            bcnt <= hq_last ? '0 : bcnt + 1'b1;
          end
          if (hr_valid) rcv <= rcv + 1'b1;
          if (bp_rsp_valid) begin
            ack <= ack + 1'b1;
            if (bp_rsp_rerr) eflags[`SFSB_EF_BUF_PAR] <= 1'b1;
          end
          if (w_acc) begin
            wr  <= wr + 1'b1;
            bib <= bib + 1'b1;
            crc <= lb_end ? 32'hFFFF_FFFF : crc_nx;
            if (beat_err) begin
              lb_err[upd_lb[2:0]]      <= 1'b1;
              eflags[`SFSB_EF_HOST]    <= 1'b1;
            end
            if (lb_end) k <= k + 1'b1;
          end
          if (done) st <= S_CPL;
        end
        S_CPL: begin
          elapsed <= elapsed + 1'b1;
          if (cpl_ready) st <= S_IDLE;
        end
        default: st <= S_IDLE;
      endcase
    end
  end

  wire [7:0] status = eflags[`SFSB_EF_HOST]    ? `SFSB_ST_HOST_ERR :
                      eflags[`SFSB_EF_BUF_PAR] ? `SFSB_ST_BUF_PAR  : `SFSB_ST_OK;

  assign cpl_valid = (st == S_CPL);
  assign cpl_data  = {elapsed,
                      eflags, 8'd0, 16'd0,
                      lb_err, status, 2'b00, `SFSB_DF_CLS(d), `SFSB_DF_OPC(d), `SFSB_DF_TID(d)};
  assign rel       = cpl_valid && cpl_ready;
  assign rel_d     = `SFSB_DF_DSLOT(d);
  assign active    = (st != S_IDLE);
  assign ev_beat   = w_acc;
endmodule

`default_nettype wire
