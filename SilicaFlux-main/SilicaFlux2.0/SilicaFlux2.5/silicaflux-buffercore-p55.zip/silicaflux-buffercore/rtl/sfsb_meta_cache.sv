// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_meta_cache  (+ external-DRAM adapter)
// Metadata cache in front of the optional external DRAM, used by firmware for
// large metadata tables (e.g. the FTL logical-to-physical map).
//
//   firmware (32-bit, one request at a time) --> cache --> SFB2 master (64-bit)
//
// DRAM adapter: the SFB2 master is the attachment point of SilicaFlux
// MemoryBridge (Project 24, silicaflux_extmem_bridge upstream port, an SFB2
// rev-2.0 superset): single-beat, 64-bit aligned, one outstanding transaction,
// len = 0 / id = 0 on the SFB2-X side.  No DDR controller or PHY is modelled
// or implied here (the repository has none - P24 docs/AUDIT.md section 6).
//
// Cache: direct mapped, SETS lines of one 64-bit DRAM word, WRITE-THROUGH with
// update-on-hit and no write-allocate.  The cache never holds data newer than
// the DRAM, so it has no durability or coherence obligations of its own:
//   * a write is acknowledged only after the DRAM write response (R7);
//   * read misses allocate; a DRAM error response is passed on and never cached;
//   * inval clears every line (for firmware after an external agent changed DRAM).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfsb_defs.svh"
`default_nettype none

module sfsb_meta_cache #(
  parameter int          SETS      = 16,
  parameter int          WIN_BYTES = 1 << 20,     // firmware-visible window
  parameter logic [31:0] DRAM_BASE = 32'h8000_0000,
  localparam int         IW        = $clog2(SETS),
  localparam int         OW        = $clog2(WIN_BYTES),
  localparam int         TW        = OW - 3 - IW
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          inval,
  // firmware side
  input  wire logic          c_req_valid,
  output logic               c_req_ready,
  input  wire logic          c_req_write,
  input  wire logic [OW-1:0] c_req_off,
  input  wire logic [31:0]   c_req_wdata,
  input  wire logic [3:0]    c_req_wstrb,
  output logic               c_rsp_valid,
  output logic      [31:0]   c_rsp_rdata,
  output logic               c_rsp_err,
  // SFB2 master to the external memory bridge
  output logic               m_req_valid,
  input  wire logic          m_req_ready,
  output logic               m_req_write,
  output logic      [31:0]   m_req_addr,
  output logic      [63:0]   m_req_wdata,
  output logic      [7:0]    m_req_wstrb,
  input  wire logic          m_rsp_valid,
  output logic               m_rsp_ready,
  input  wire logic [63:0]   m_rsp_rdata,
  input  wire logic          m_rsp_error,
  output logic               ev_hit,
  output logic               ev_miss
);
  if (SETS < 2 || (SETS & (SETS - 1)) != 0) begin : g_err_sets
    `SFSB_CFG_FATAL("sfsb_meta_cache: SETS must be a power of two >= 2")
  end
  if (TW < 1) begin : g_err_tw
    `SFSB_CFG_FATAL("sfsb_meta_cache: window too small for SETS")
  end

  logic          v   [SETS];
  logic [TW-1:0] tag [SETS];
  logic [63:0]   dat [SETS];

  typedef enum logic [2:0] {S_IDLE, S_LOOK, S_MREQ, S_MWAIT, S_RESP} st_t;
  st_t st;

  logic          we_q;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [OW-1:0] off_q;               // [1:0]: byte offset of a word access
  /* verilator lint_on UNUSEDSIGNAL */
  logic [31:0]   wd_q;
  logic [3:0]    ws_q;

  wire [IW-1:0] idx  = off_q[3 +: IW];
  wire [TW-1:0] tg   = off_q[OW-1 -: TW];
  wire          hi   = off_q[2];
  wire          hit  = v[idx] && (tag[idx] == tg);

  // write-through update of a hit line (byte merge)
  logic [63:0] merged;
  always_comb begin
    merged = dat[idx];
    for (int b = 0; b < 4; b++)
      if (ws_q[b]) merged[(hi ? 32 : 0) + 8*b +: 8] = wd_q[8*b +: 8];
  end

  assign c_req_ready = (st == S_IDLE);
  assign m_rsp_ready = 1'b1;
  assign m_req_valid = (st == S_MREQ);
  assign m_req_write = we_q;
  assign m_req_addr  = DRAM_BASE + 32'({off_q[OW-1:3], 3'b000});
  assign m_req_wdata = hi ? {wd_q, 32'd0} : {32'd0, wd_q};
  assign m_req_wstrb = we_q ? (hi ? {ws_q, 4'd0} : {4'd0, ws_q}) : 8'd0;

  assign ev_hit  = (st == S_LOOK) && !we_q && hit;
  assign ev_miss = (st == S_LOOK) && !we_q && !hit;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; we_q <= 1'b0; off_q <= '0; wd_q <= '0; ws_q <= '0;
      c_rsp_rdata <= '0; c_rsp_err <= 1'b0;
      for (int s = 0; s < SETS; s++) begin v[s] <= 1'b0; tag[s] <= '0; dat[s] <= '0; end
    end else begin
      if (inval) for (int s = 0; s < SETS; s++) v[s] <= 1'b0;
      case (st)
        S_IDLE: if (c_req_valid) begin
          we_q <= c_req_write; off_q <= c_req_off; wd_q <= c_req_wdata; ws_q <= c_req_wstrb;
          st <= S_LOOK;
        end
        S_LOOK: begin
          if (!we_q && hit) begin
            c_rsp_rdata <= hi ? dat[idx][63:32] : dat[idx][31:0];
            c_rsp_err   <= 1'b0;
            st          <= S_RESP;
          end else begin
            st <= S_MREQ;
          end
        end
        S_MREQ: if (m_req_ready) st <= S_MWAIT;
        S_MWAIT: if (m_rsp_valid) begin
          c_rsp_err <= m_rsp_error;
          if (!we_q) begin
            c_rsp_rdata <= m_rsp_error ? 32'd0 : (hi ? m_rsp_rdata[63:32] : m_rsp_rdata[31:0]);
            if (!m_rsp_error && !inval) begin
              v[idx] <= 1'b1; tag[idx] <= tg; dat[idx] <= m_rsp_rdata;
            end
          end else begin
            c_rsp_rdata <= '0;
            if (!m_rsp_error && hit && !inval) dat[idx] <= merged;
          end
          st <= S_RESP;
        end
        S_RESP: st <= S_IDLE;
        default: st <= S_IDLE;
      endcase
    end
  end
  assign c_rsp_valid = (st == S_RESP);
endmodule

`default_nettype wire
