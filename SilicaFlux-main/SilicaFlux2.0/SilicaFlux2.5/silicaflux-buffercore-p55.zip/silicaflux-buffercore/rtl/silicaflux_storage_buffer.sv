// =============================================================================
// SilicaFlux BufferCore (Project 55) :: silicaflux_storage_buffer   (PRIMARY RTL)
// Aureom.AI | SilicaFlux-STORE
//
// High-bandwidth storage buffer and DMA subsystem of the SilicaFlux storage
// processor.  It moves data between the host, the ECC engine, the NAND channel
// controller and the ControlCore firmware with end-to-end integrity checking
// and explicit buffer ownership.
//
//   host memory <-SFB2-> [host mux] <-> H2B / B2H engines <-+
//                                                           |   banked SRAM
//   ControlCore <-SFB2-> [fw port: CSR, BUF, DRAM windows] -+-> (NUM_BANKS x sram_sp,
//                                    |                      |    per-byte parity,
//   ext. DRAM   <-SFB2-  [meta cache]                        |    arbitrated per bank)
//                                                           |
//   NAND ctrl   <-SFB2-> [nand port] -----------------------+
//                         ENC: data slot -> V1 -> crypt -> ECC enc -> page slot
//                         DEC: page slot -> ECC dec -> crypt -> V2 -> data slot
//
// Buffer organisation (64-bit words, bank = word[log2 NB-1:0]):
//   data slots  [0, PS_BASE)            NUM_DSLOTS x PAGE_LBS logical blocks
//                                       (host ingress / egress / read cache / GC staging)
//   page slots  [PS_BASE, TOTAL_BEATS)  NUM_PSLOTS NAND page images
//                                       (codewords + parity + OOB metadata)
//   metadata buffer (buffer manager)    {VALID, POISON, LBA, CRC32C} per logical block
//
// Integrity points (docs/02_DATA_PATH.md):
//   G1  H2B   CRC32C generated per logical block on ingress, stored in metadata
//   V1  ENC   recomputed from the buffer before encoding; page marked BAD on mismatch
//   S   ENC   {CRC32C, LBA} written to the page OOB, SECDED-protected
//   V2  DEC   after ECC correction + decrypt: CRC32C and LBA vs OOB -> poison on mismatch
//   V3  B2H   recomputed on egress vs metadata -> CRC status, block poisoned
//   +   every SRAM read is parity checked (per byte lane)
//
// One clock domain; rst_n: asynchronous assert, synchronous release (provided
// by the integrator, e.g. sfv_rst_sync).  pwr_fail_i is asynchronous and is
// synchronised here.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`include "sfsb_defs.svh"
`default_nettype none

module silicaflux_storage_buffer #(
  // ---- memory organisation
  parameter int          NUM_BANKS    = 4,      // power of two, 2..8
  parameter int          LB_BYTES     = 512,    // logical block = ECC codeword payload, 64..4096, power of two
  parameter int          PAGE_LBS     = 4,      // logical blocks per NAND page: 1, 2, 4, 8
  parameter int          NUM_DSLOTS   = 8,      // data slots (1..32)
  parameter int          NUM_PSLOTS   = 4,      // page slots (1..32)
  // ---- queues / engines
  parameter int          DQ_DEPTH     = 4,      // descriptor queue depth per engine / class
  parameter int          CQ_DEPTH     = 8,      // completion queue depth
  parameter int          ENG_FIFO     = 8,      // engine read FIFO (ECC input buffer) depth
  parameter int          HOST_MAX_OUT = 1,      // host-port outstanding transactions (1 = SFB2 rev 2.0)
  parameter int          MAX_BURST    = 16,     // host burst length (beats)
  parameter int          AGE_LIMIT    = 16,     // bank arbitration aging threshold (cycles)
  // ---- options
  parameter int          CRYPTO_EN    = 1,      // crypt stage (placeholder transform, NOT a cipher)
  parameter int          EXT_DRAM_EN  = 0,      // external-DRAM metadata window + metadata cache
  parameter int          MC_SETS      = 16,
  parameter int          DRAM_WIN     = 1 << 20,
  parameter logic [31:0] DRAM_BASE    = 32'h8000_0000,
  parameter logic [31:0] ND_BASE      = 32'h0,  // NAND-port byte address of buffer word 0
  parameter int          PLP_PRESENT  = 0,      // 1: power-loss protection hold-up energy exists
  parameter int          PERF_EN      = 1,
  parameter int          SRAM_BACKEND = `SRAM_BACKEND_GENERIC,
  parameter int          SRAM_MACRO   = 0,
  // ---- derived (do not override)
  localparam int LB_BEATS    = LB_BYTES / 8,
  localparam int PAR_BEATS   = LB_BEATS / 8,
  localparam int CWB         = LB_BEATS + PAR_BEATS,
  localparam int DSLOT_BEATS = PAGE_LBS * LB_BEATS,
  localparam int DSB_LOG2    = $clog2(DSLOT_BEATS),
  localparam int PIMG_BEATS  = PAGE_LBS * CWB + PAGE_LBS + 1,
  localparam int PSLOT_BEATS = ((PIMG_BEATS + NUM_BANKS - 1) / NUM_BANKS) * NUM_BANKS,
  localparam int PS_BASE     = NUM_DSLOTS * DSLOT_BEATS,
  localparam int TOTAL_BEATS = PS_BASE + NUM_PSLOTS * PSLOT_BEATS,
  localparam int BANK_DEPTH  = (TOTAL_BEATS + NUM_BANKS - 1) / NUM_BANKS,
  localparam int WAW         = $clog2(BANK_DEPTH * NUM_BANKS),
  localparam int RW          = $clog2(BANK_DEPTH),
  localparam int NP          = 8,
  localparam int PCN         = `SFSB_PC_NUM,
  localparam int CQAW        = $clog2(CQ_DEPTH)
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // ---------------------------------------------------------- firmware (SFB2 slave, 32-bit)
  input  wire logic        fw_req_valid,
  output logic             fw_req_ready,
  input  wire logic        fw_req_write,
  input  wire logic [31:0] fw_req_addr,
  input  wire logic [31:0] fw_req_wdata,
  input  wire logic [3:0]  fw_req_wstrb,
  output logic             fw_rsp_valid,
  input  wire logic        fw_rsp_ready,
  output logic [31:0]      fw_rsp_rdata,
  output logic             fw_rsp_error,
  // ---------------------------------------------------------- NAND controller (SFB2 slave, 64-bit)
  input  wire logic        nd_req_valid,
  output logic             nd_req_ready,
  input  wire logic        nd_req_write,
  input  wire logic [31:0] nd_req_addr,
  input  wire logic [63:0] nd_req_wdata,
  input  wire logic [7:0]  nd_req_wstrb,
  output logic             nd_rsp_valid,
  input  wire logic        nd_rsp_ready,
  output logic [63:0]      nd_rsp_rdata,
  output logic             nd_rsp_error,
  // ---------------------------------------------------------- host memory (SFB2 master, 64-bit)
  output logic             hm_req_valid,
  input  wire logic        hm_req_ready,
  output logic             hm_req_write,
  output logic [31:0]      hm_req_addr,
  output logic [63:0]      hm_req_wdata,
  output logic [7:0]       hm_req_wstrb,
  input  wire logic        hm_rsp_valid,
  output logic             hm_rsp_ready,
  input  wire logic [63:0] hm_rsp_rdata,
  input  wire logic        hm_rsp_error,
  // ---------------------------------------------------------- external DRAM (SFB2 master, 64-bit)
  output logic             xm_req_valid,
  input  wire logic        xm_req_ready,
  output logic             xm_req_write,
  output logic [31:0]      xm_req_addr,
  output logic [63:0]      xm_req_wdata,
  output logic [7:0]       xm_req_wstrb,
  input  wire logic        xm_rsp_valid,
  output logic             xm_rsp_ready,
  input  wire logic [63:0] xm_rsp_rdata,
  input  wire logic        xm_rsp_error,
  // ---------------------------------------------------------- status
  input  wire logic        pwr_fail_i,     // asynchronous
  output logic             irq,
  output logic             busy,
  output logic             init_done,
  output logic             plp_dirty       // volatile (not yet durable) host data in the buffer
);
  // ------------------------------------------------------------ parameter checks
  if (NUM_BANKS != 2 && NUM_BANKS != 4 && NUM_BANKS != 8) begin : g_err_banks
    `SFSB_CFG_FATAL("silicaflux_storage_buffer: NUM_BANKS must be 2, 4 or 8")
  end
  if (LB_BYTES < 64 || LB_BYTES > 4096 || (LB_BYTES & (LB_BYTES - 1)) != 0) begin : g_err_lb
    `SFSB_CFG_FATAL("silicaflux_storage_buffer: LB_BYTES must be a power of two in 64..4096")
  end
  if (PAGE_LBS != 1 && PAGE_LBS != 2 && PAGE_LBS != 4 && PAGE_LBS != 8) begin : g_err_lbs
    `SFSB_CFG_FATAL("silicaflux_storage_buffer: PAGE_LBS must be 1, 2, 4 or 8")
  end
  if (ENG_FIFO < 2 || (ENG_FIFO & (ENG_FIFO - 1)) != 0) begin : g_err_fifo
    `SFSB_CFG_FATAL("silicaflux_storage_buffer: ENG_FIFO must be a power of two >= 2")
  end
  if (TOTAL_BEATS * 8 > (1 << 20)) begin : g_err_size
    `SFSB_CFG_FATAL("silicaflux_storage_buffer: buffer larger than the 1 MiB firmware window")
  end

  // ------------------------------------------------------------ power-fail synchroniser
  logic pf_s1, pf_s2;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin pf_s1 <= 1'b0; pf_s2 <= 1'b0; end
    else        begin pf_s1 <= pwr_fail_i; pf_s2 <= pf_s1; end
  end

  // ------------------------------------------------------------ bank crossbar ports
  // 0 FW, 1 NAND, 2 H2B-W, 3 B2H-R, 4 ENC-R, 5 ENC-W, 6 DEC-R, 7 DEC-W
  logic [NP-1:0]     p_req_valid, p_req_ready, p_req_we, p_rsp_valid, p_rsp_rerr, p_stall;
  logic [NP*WAW-1:0] p_req_addr;
  logic [NP*64-1:0]  p_req_wdata;
  logic [NP*8-1:0]   p_req_be;
  // write-only ports (H2B-W, ENC-W, DEC-W) ignore read data / lane parity; rsp_we is
  // implied by the port direction
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NP-1:0]     p_rsp_we;
  logic [NP*64-1:0]  p_rsp_rdata;
  logic [NP*8-1:0]   p_rsp_perr;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [NUM_BANKS-1:0] bank_rd_acc, bank_wr_acc;
  logic [15:0]       acc_wait;
  logic              fi_arm, fi_fire;
  logic [7:0]        fi_bank;
  logic [RW-1:0]     fi_row;
  logic [71:0]       fi_mask;

  sfsb_bank_xbar #(
    .NP(NP), .NB(NUM_BANKS), .WAW(WAW), .BANK_DEPTH(BANK_DEPTH), .AGE_LIMIT(AGE_LIMIT),
    .HIPRI_MASK(32'h0000_0002), .BACKEND(SRAM_BACKEND), .MACRO(SRAM_MACRO)
  ) u_xbar (
    .clk, .rst_n,
    .p_req_valid, .p_req_ready, .p_req_we, .p_req_addr, .p_req_wdata, .p_req_be,
    .p_rsp_valid, .p_rsp_we, .p_rsp_rdata, .p_rsp_perr, .p_rsp_rerr,
    .init_done, .bank_rd_acc, .bank_wr_acc, .p_stall, .acc_wait,
    .fi_arm, .fi_bank, .fi_row, .fi_mask, .fi_fire
  );

  // ------------------------------------------------------------ firmware port
  logic        cfg_en, cfg_irq_en, cfg_wce;
  logic [7:0]  w_host, w_gc;
  logic [63:0] key;
  logic [`SFSB_DESC_W-1:0] desc;
  logic        submit, sub_commit;
  logic [7:0]  sub_code, slot_code;
  logic        cq_nonempty, cq_pop;
  logic [`SFSB_CPL_W-1:0] cq_head;
  logic [CQAW:0] cq_count;
  logic        cmd_valid, cmd_flag, cmd_hit;
  logic [3:0]  cmd_op, cmd_rlb;
  logic [7:0]  cmd_slot, cmd_code, cmd_rslot;
  logic [31:0] cmd_lba, cmd_cnt;
  logic [7:0]  dbg_d, dbg_p;
  logic [3:0]  dbg_lb;
  logic [31:0] dbg_lba, dbg_crc, dbg_flags, dbg_pflags;
  logic [7:0]  dirty_cnt, ds_alloc_cnt, ds_cached_cnt, ps_alloc_cnt, ps_nand_cnt;
  logic        perf_clear, perf_freeze, mc_inval;
  logic [PCN*32-1:0] perf_cnt;
  logic [WAW-1:0] fwa_wa, nda_wa;
  logic        fwa_we, fwa_ok, nda_ok;
  localparam int OW = $clog2(DRAM_WIN);
  logic          c_req_valid, c_req_ready, c_req_write, c_rsp_valid, c_rsp_err;
  logic [OW-1:0] c_req_off;
  logic [31:0]   c_req_wdata, c_rsp_rdata;
  logic [3:0]    c_req_wstrb;

  sfsb_fw_port #(
    .NDS(NUM_DSLOTS), .NPS(NUM_PSLOTS), .NB(NUM_BANKS), .PAGE_LBS(PAGE_LBS), .LB_BYTES(LB_BYTES),
    .WAW(WAW), .RW(RW), .TOTAL_BEATS(TOTAL_BEATS), .PS_BASE(PS_BASE), .PSLOT_BEATS(PSLOT_BEATS),
    .PIMG_BEATS(PIMG_BEATS), .CRYPTO_EN(CRYPTO_EN), .EXT_DRAM_EN(EXT_DRAM_EN),
    .PLP_PRESENT(PLP_PRESENT), .DRAM_WIN(DRAM_WIN), .PC_NUM(PCN), .CQAW(CQAW)
  ) u_fw (
    .clk, .rst_n,
    .s_req_valid(fw_req_valid), .s_req_ready(fw_req_ready), .s_req_write(fw_req_write),
    .s_req_addr(fw_req_addr), .s_req_wdata(fw_req_wdata), .s_req_wstrb(fw_req_wstrb),
    .s_rsp_valid(fw_rsp_valid), .s_rsp_ready(fw_rsp_ready), .s_rsp_rdata(fw_rsp_rdata),
    .s_rsp_error(fw_rsp_error),
    .cfg_en, .cfg_irq_en, .cfg_wce, .w_host, .w_gc, .key,
    .desc, .submit, .sub_code,
    .cq_nonempty, .cq_head, .cq_count, .cq_pop,
    .cmd_valid, .cmd_op, .cmd_slot, .cmd_flag, .cmd_lba, .cmd_cnt, .cmd_code, .cmd_rslot, .cmd_hit, .cmd_rlb,
    .dbg_d, .dbg_lb, .dbg_lba, .dbg_crc, .dbg_flags, .dbg_p, .dbg_pflags,
    .init_done, .pwr_fail(pf_s2), .busy, .dirty_cnt, .ds_alloc_cnt, .ds_cached_cnt, .ps_alloc_cnt, .ps_nand_cnt,
    .fi_arm, .fi_bank, .fi_row, .fi_mask, .fi_fire,
    .perf_clear, .perf_freeze, .perf_cnt, .mc_inval,
    .fwa_wa, .fwa_we, .fwa_ok,
    .bp_req_valid(p_req_valid[0]), .bp_req_ready(p_req_ready[0]), .bp_req_we(p_req_we[0]),
    .bp_req_addr(p_req_addr[0*WAW +: WAW]), .bp_req_wdata(p_req_wdata[0*64 +: 64]), .bp_req_be(p_req_be[0*8 +: 8]),
    .bp_rsp_valid(p_rsp_valid[0]), .bp_rsp_rdata(p_rsp_rdata[0*64 +: 64]), .bp_rsp_perr(p_rsp_perr[0*8 +: 8]),
    .bp_rsp_rerr(p_rsp_rerr[0]),
    .c_req_valid, .c_req_ready, .c_req_write, .c_req_off, .c_req_wdata, .c_req_wstrb,
    .c_rsp_valid, .c_rsp_rdata, .c_rsp_err
  );

  // ------------------------------------------------------------ NAND-controller port
  logic nd_beat;
  sfsb_nand_port #(.WAW(WAW), .TOTAL_BEATS(TOTAL_BEATS), .BASE(ND_BASE)) u_nd (
    .clk, .rst_n,
    .s_req_valid(nd_req_valid), .s_req_ready(nd_req_ready), .s_req_write(nd_req_write),
    .s_req_addr(nd_req_addr), .s_req_wdata(nd_req_wdata), .s_req_wstrb(nd_req_wstrb),
    .s_rsp_valid(nd_rsp_valid), .s_rsp_ready(nd_rsp_ready), .s_rsp_rdata(nd_rsp_rdata),
    .s_rsp_error(nd_rsp_error),
    .chk_wa(nda_wa), .chk_ok(nda_ok),
    .bp_req_valid(p_req_valid[1]), .bp_req_ready(p_req_ready[1]), .bp_req_we(p_req_we[1]),
    .bp_req_addr(p_req_addr[1*WAW +: WAW]), .bp_req_wdata(p_req_wdata[1*64 +: 64]), .bp_req_be(p_req_be[1*8 +: 8]),
    .bp_rsp_valid(p_rsp_valid[1]), .bp_rsp_rdata(p_rsp_rdata[1*64 +: 64]), .bp_rsp_perr(p_rsp_perr[1*8 +: 8]),
    .bp_rsp_rerr(p_rsp_rerr[1]),
    .ev_beat(nd_beat)
  );

  // ------------------------------------------------------------ dispatcher
  logic h2b_dv, b2h_dv, enc_dv, dec_dv, h2b_take, b2h_take, enc_take, dec_take;
  logic [`SFSB_DESC_W-1:0] h2b_d, b2h_d, enc_d, dec_d;
  logic [3:0] cpl_valid, cpl_ready;
  logic [4*`SFSB_CPL_W-1:0] cpl_data;
  logic busy_q, ev_cq_full;
  logic [1:0] qwait_media;

  sfsb_dispatch #(
    .PAGE_LBS(PAGE_LBS), .LB_BYTES(LB_BYTES), .DQ_DEPTH(DQ_DEPTH), .CQ_DEPTH(CQ_DEPTH), .CRYPTO_EN(CRYPTO_EN)
  ) u_disp (
    .clk, .rst_n,
    .cfg_en, .init_done, .pwr_fail(pf_s2), .w_host, .w_gc,
    .submit, .desc, .sub_code, .slot_code, .sub_commit,
    .h2b_dv, .h2b_d, .h2b_take, .b2h_dv, .b2h_d, .b2h_take,
    .enc_dv, .enc_d, .enc_take, .dec_dv, .dec_d, .dec_take,
    .cpl_valid, .cpl_data, .cpl_ready,
    .cq_nonempty, .cq_head, .cq_count, .cq_pop,
    .busy_q, .ev_cq_full, .qwait_media
  );

  // ------------------------------------------------------------ buffer manager
  logic rel_h2b, rel_b2h, rel_enc, rel_dec;
  logic [7:0] rel_h2b_d, rel_b2h_d, rel_enc_d, rel_enc_p, rel_dec_d, rel_dec_p;
  logic h2b_upd, h2b_upd_ok, dec_upd, dec_upd_valid, dec_upd_poison, b2h_poison, enc_bad;
  logic [7:0] h2b_upd_d, dec_upd_d, b2h_poison_d, enc_bad_p, b2h_rd_d, enc_rd_d;
  logic [3:0] h2b_upd_lb, dec_upd_lb, b2h_poison_lb, b2h_rd_lb, enc_rd_lb;
  logic [31:0] h2b_upd_lba, h2b_upd_crc, dec_upd_lba, dec_upd_crc, b2h_rd_crc, enc_rd_crc, enc_rd_lba;
  logic ev_lookup, ev_hit, ev_evict;

  sfsb_slot_mgr #(
    .NDS(NUM_DSLOTS), .NPS(NUM_PSLOTS), .PAGE_LBS(PAGE_LBS), .WAW(WAW), .DSB_LOG2(DSB_LOG2),
    .PS_BASE(PS_BASE), .PSLOT_BEATS(PSLOT_BEATS)
  ) u_mgr (
    .clk, .rst_n,
    .cmd_valid, .cmd_op, .cmd_slot, .cmd_flag, .cmd_lba, .cmd_cnt, .cmd_code, .cmd_rslot, .cmd_hit, .cmd_rlb,
    .sub_op(`SFSB_DF_OPC(desc)), .sub_dslot(`SFSB_DF_DSLOT(desc)), .sub_pslot(`SFSB_DF_PSLOT(desc)),
    .sub_lbf(`SFSB_DF_LBF(desc)), .sub_lbc(`SFSB_DF_LBC(desc)), .sub_lba(`SFSB_DF_LBA(desc)),
    .sub_code(slot_code), .sub_commit,
    .rel_h2b, .rel_h2b_d, .rel_b2h, .rel_b2h_d, .rel_enc, .rel_enc_d, .rel_enc_p, .rel_dec, .rel_dec_d, .rel_dec_p,
    .h2b_upd, .h2b_upd_d, .h2b_upd_lb, .h2b_upd_lba, .h2b_upd_crc, .h2b_upd_ok,
    .dec_upd, .dec_upd_d, .dec_upd_lb, .dec_upd_lba, .dec_upd_crc, .dec_upd_valid, .dec_upd_poison,
    .b2h_poison, .b2h_poison_d, .b2h_poison_lb, .enc_bad, .enc_bad_p,
    .b2h_rd_d, .b2h_rd_lb, .b2h_rd_crc, .enc_rd_d, .enc_rd_lb, .enc_rd_crc, .enc_rd_lba,
    .dbg_d, .dbg_lb, .dbg_lba, .dbg_crc, .dbg_flags, .dbg_p, .dbg_pflags,
    .fwa_wa, .fwa_we, .fwa_ok, .nda_wa, .nda_ok,
    .dirty_cnt, .ds_alloc_cnt, .ds_cached_cnt, .ps_alloc_cnt, .ps_nand_cnt,
    .ev_lookup, .ev_hit, .ev_evict
  );

  // ------------------------------------------------------------ host engines + host port
  logic        h_e0_valid, h_e0_ready, h_e0_last, h_e0_rsp_valid, h_e0_rsp_err;
  logic [31:0] h_e0_addr;
  logic [63:0] h_e0_rsp_rdata;
  logic        h_e1_valid, h_e1_ready, h_e1_last, h_e1_rsp_valid, h_e1_rsp_err;
  logic [31:0] h_e1_addr;
  logic [63:0] h_e1_wdata;
  logic        h2b_active, h2b_beat, b2h_active, b2h_beat, host_req_wait, host_rsp_wait;

  sfsb_eng_h2b #(
    .LB_BEATS(LB_BEATS), .WAW(WAW), .DSB_LOG2(DSB_LOG2), .FD(ENG_FIFO), .MAX_BURST(MAX_BURST)
  ) u_h2b (
    .clk, .rst_n,
    .desc_valid(h2b_dv), .desc(h2b_d), .desc_take(h2b_take),
    .hq_valid(h_e0_valid), .hq_ready(h_e0_ready), .hq_addr(h_e0_addr), .hq_last(h_e0_last),
    .hr_valid(h_e0_rsp_valid), .hr_rdata(h_e0_rsp_rdata), .hr_err(h_e0_rsp_err),
    .bp_req_valid(p_req_valid[2]), .bp_req_ready(p_req_ready[2]), .bp_req_addr(p_req_addr[2*WAW +: WAW]),
    .bp_req_wdata(p_req_wdata[2*64 +: 64]), .bp_rsp_valid(p_rsp_valid[2]), .bp_rsp_rerr(p_rsp_rerr[2]),
    .upd(h2b_upd), .upd_d(h2b_upd_d), .upd_lb(h2b_upd_lb), .upd_lba(h2b_upd_lba), .upd_crc(h2b_upd_crc),
    .upd_ok(h2b_upd_ok),
    .rel(rel_h2b), .rel_d(rel_h2b_d),
    .cpl_valid(cpl_valid[0]), .cpl_data(cpl_data[0*`SFSB_CPL_W +: `SFSB_CPL_W]), .cpl_ready(cpl_ready[0]),
    .active(h2b_active), .ev_beat(h2b_beat)
  );
  assign p_req_we[2]       = 1'b1;
  assign p_req_be[2*8 +: 8] = 8'hFF;

  sfsb_eng_b2h #(
    .LB_BEATS(LB_BEATS), .WAW(WAW), .DSB_LOG2(DSB_LOG2), .FD(ENG_FIFO), .MAX_BURST(MAX_BURST)
  ) u_b2h (
    .clk, .rst_n,
    .desc_valid(b2h_dv), .desc(b2h_d), .desc_take(b2h_take),
    .hq_valid(h_e1_valid), .hq_ready(h_e1_ready), .hq_addr(h_e1_addr), .hq_wdata(h_e1_wdata), .hq_last(h_e1_last),
    .hr_valid(h_e1_rsp_valid), .hr_err(h_e1_rsp_err),
    .bp_req_valid(p_req_valid[3]), .bp_req_ready(p_req_ready[3]), .bp_req_addr(p_req_addr[3*WAW +: WAW]),
    .bp_rsp_valid(p_rsp_valid[3]), .bp_rsp_rdata(p_rsp_rdata[3*64 +: 64]), .bp_rsp_perr(p_rsp_perr[3*8 +: 8]),
    .bp_rsp_rerr(p_rsp_rerr[3]),
    .rd_d(b2h_rd_d), .rd_lb(b2h_rd_lb), .rd_crc(b2h_rd_crc),
    .poison(b2h_poison), .poison_d(b2h_poison_d), .poison_lb(b2h_poison_lb),
    .rel(rel_b2h), .rel_d(rel_b2h_d),
    .cpl_valid(cpl_valid[1]), .cpl_data(cpl_data[1*`SFSB_CPL_W +: `SFSB_CPL_W]), .cpl_ready(cpl_ready[1]),
    .active(b2h_active), .ev_beat(b2h_beat)
  );
  assign p_req_we[3]          = 1'b0;
  assign p_req_wdata[3*64 +: 64] = 64'd0;
  assign p_req_be[3*8 +: 8]    = 8'h00;

  sfsb_host_mux #(.MAX_OUT(HOST_MAX_OUT)) u_hmux (
    .clk, .rst_n,
    .e0_valid(h_e0_valid), .e0_ready(h_e0_ready), .e0_addr(h_e0_addr), .e0_last(h_e0_last),
    .e0_rsp_valid(h_e0_rsp_valid), .e0_rsp_rdata(h_e0_rsp_rdata), .e0_rsp_err(h_e0_rsp_err),
    .e1_valid(h_e1_valid), .e1_ready(h_e1_ready), .e1_addr(h_e1_addr), .e1_wdata(h_e1_wdata), .e1_last(h_e1_last),
    .e1_rsp_valid(h_e1_rsp_valid), .e1_rsp_err(h_e1_rsp_err),
    .m_req_valid(hm_req_valid), .m_req_ready(hm_req_ready), .m_req_write(hm_req_write), .m_req_addr(hm_req_addr),
    .m_req_wdata(hm_req_wdata), .m_req_wstrb(hm_req_wstrb), .m_rsp_valid(hm_rsp_valid), .m_rsp_ready(hm_rsp_ready),
    .m_rsp_rdata(hm_rsp_rdata), .m_rsp_error(hm_rsp_error),
    .ev_req_wait(host_req_wait), .ev_rsp_wait(host_rsp_wait)
  );

  // ------------------------------------------------------------ media engines
  logic enc_active, enc_beat, enc_ecc_wait, dec_active, dec_beat, dec_ecc_wait;

  sfsb_eng_enc #(
    .LB_BEATS(LB_BEATS), .PAGE_LBS(PAGE_LBS), .WAW(WAW), .DSB_LOG2(DSB_LOG2), .PS_BASE(PS_BASE),
    .PSLOT_BEATS(PSLOT_BEATS), .FD(ENG_FIFO), .CRYPTO_EN(CRYPTO_EN)
  ) u_enc (
    .clk, .rst_n, .key,
    .desc_valid(enc_dv), .desc(enc_d), .desc_take(enc_take),
    .rp_req_valid(p_req_valid[4]), .rp_req_ready(p_req_ready[4]), .rp_req_addr(p_req_addr[4*WAW +: WAW]),
    .rp_rsp_valid(p_rsp_valid[4]), .rp_rsp_rdata(p_rsp_rdata[4*64 +: 64]), .rp_rsp_perr(p_rsp_perr[4*8 +: 8]),
    .rp_rsp_rerr(p_rsp_rerr[4]),
    .wp_req_valid(p_req_valid[5]), .wp_req_ready(p_req_ready[5]), .wp_req_addr(p_req_addr[5*WAW +: WAW]),
    .wp_req_wdata(p_req_wdata[5*64 +: 64]), .wp_req_be(p_req_be[5*8 +: 8]),
    .wp_rsp_valid(p_rsp_valid[5]), .wp_rsp_rerr(p_rsp_rerr[5]),
    .rd_d(enc_rd_d), .rd_lb(enc_rd_lb), .rd_crc(enc_rd_crc), .rd_lba(enc_rd_lba),
    .bad(enc_bad), .bad_p(enc_bad_p),
    .rel(rel_enc), .rel_d(rel_enc_d), .rel_p(rel_enc_p),
    .cpl_valid(cpl_valid[2]), .cpl_data(cpl_data[2*`SFSB_CPL_W +: `SFSB_CPL_W]), .cpl_ready(cpl_ready[2]),
    .active(enc_active), .ev_beat(enc_beat), .ev_ecc_wait(enc_ecc_wait)
  );
  assign p_req_we[4]          = 1'b0;
  assign p_req_wdata[4*64 +: 64] = 64'd0;
  assign p_req_be[4*8 +: 8]    = 8'h00;
  assign p_req_we[5]          = 1'b1;

  sfsb_eng_dec #(
    .LB_BEATS(LB_BEATS), .PAGE_LBS(PAGE_LBS), .WAW(WAW), .DSB_LOG2(DSB_LOG2), .PS_BASE(PS_BASE),
    .PSLOT_BEATS(PSLOT_BEATS), .FD(ENG_FIFO), .CRYPTO_EN(CRYPTO_EN)
  ) u_dec (
    .clk, .rst_n, .key,
    .desc_valid(dec_dv), .desc(dec_d), .desc_take(dec_take),
    .rp_req_valid(p_req_valid[6]), .rp_req_ready(p_req_ready[6]), .rp_req_addr(p_req_addr[6*WAW +: WAW]),
    .rp_rsp_valid(p_rsp_valid[6]), .rp_rsp_rdata(p_rsp_rdata[6*64 +: 64]), .rp_rsp_perr(p_rsp_perr[6*8 +: 8]),
    .rp_rsp_rerr(p_rsp_rerr[6]),
    .wp_req_valid(p_req_valid[7]), .wp_req_ready(p_req_ready[7]), .wp_req_addr(p_req_addr[7*WAW +: WAW]),
    .wp_req_wdata(p_req_wdata[7*64 +: 64]),
    .wp_rsp_valid(p_rsp_valid[7]), .wp_rsp_rerr(p_rsp_rerr[7]),
    .upd(dec_upd), .upd_d(dec_upd_d), .upd_lb(dec_upd_lb), .upd_lba(dec_upd_lba), .upd_crc(dec_upd_crc),
    .upd_valid(dec_upd_valid), .upd_poison(dec_upd_poison),
    .rel(rel_dec), .rel_d(rel_dec_d), .rel_p(rel_dec_p),
    .cpl_valid(cpl_valid[3]), .cpl_data(cpl_data[3*`SFSB_CPL_W +: `SFSB_CPL_W]), .cpl_ready(cpl_ready[3]),
    .active(dec_active), .ev_beat(dec_beat), .ev_ecc_wait(dec_ecc_wait)
  );
  assign p_req_we[6]          = 1'b0;
  assign p_req_wdata[6*64 +: 64] = 64'd0;
  assign p_req_be[6*8 +: 8]    = 8'h00;
  assign p_req_we[7]          = 1'b1;
  assign p_req_be[7*8 +: 8]    = 8'hFF;

  // ------------------------------------------------------------ external DRAM adapter + metadata cache
  logic mc_hit, mc_miss;
  if (EXT_DRAM_EN != 0) begin : g_dram
    sfsb_meta_cache #(.SETS(MC_SETS), .WIN_BYTES(DRAM_WIN), .DRAM_BASE(DRAM_BASE)) u_mc (
      .clk, .rst_n, .inval(mc_inval),
      .c_req_valid, .c_req_ready, .c_req_write, .c_req_off, .c_req_wdata, .c_req_wstrb,
      .c_rsp_valid, .c_rsp_rdata, .c_rsp_err,
      .m_req_valid(xm_req_valid), .m_req_ready(xm_req_ready), .m_req_write(xm_req_write),
      .m_req_addr(xm_req_addr), .m_req_wdata(xm_req_wdata), .m_req_wstrb(xm_req_wstrb),
      .m_rsp_valid(xm_rsp_valid), .m_rsp_ready(xm_rsp_ready), .m_rsp_rdata(xm_rsp_rdata),
      .m_rsp_error(xm_rsp_error),
      .ev_hit(mc_hit), .ev_miss(mc_miss)
    );
  end else begin : g_no_dram
    assign xm_req_valid = 1'b0;
    assign xm_req_write = 1'b0;
    assign xm_req_addr  = '0;
    assign xm_req_wdata = '0;
    assign xm_req_wstrb = '0;
    assign xm_rsp_ready = 1'b1;
    assign c_req_ready  = 1'b0;
    assign c_rsp_valid  = 1'b0;
    assign c_rsp_rdata  = '0;
    assign c_rsp_err    = 1'b0;
    assign mc_hit       = 1'b0;
    assign mc_miss      = 1'b0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_dram = xm_req_ready ^ xm_rsp_valid ^ (^xm_rsp_rdata) ^ xm_rsp_error ^ mc_inval ^
                       c_req_valid ^ c_req_write ^ (^c_req_off) ^ (^c_req_wdata) ^ (^c_req_wstrb);
    /* verilator lint_on UNUSEDSIGNAL */
  end

  // ------------------------------------------------------------ status
  assign busy      = busy_q || h2b_active || b2h_active || enc_active || dec_active;
  assign irq       = cfg_irq_en && cq_nonempty;
  assign plp_dirty = (dirty_cnt != 8'd0);

  // ------------------------------------------------------------ performance counters
  function automatic [7:0] popc(input [15:0] v);
    integer i;
    begin
      popc = 8'd0;
      for (i = 0; i < 16; i = i + 1) popc = popc + {7'd0, v[i]};
    end
  endfunction

  logic [PCN*8-1:0] inc;
  wire  [3:0]       cpl_hs = cpl_valid & cpl_ready;
  always_comb begin
    inc = '0;
    inc[8*`SFSB_PC_CYCLES        +: 8] = 8'd1;
    inc[8*`SFSB_PC_SRAM_RD       +: 8] = popc({{(16-NUM_BANKS){1'b0}}, bank_rd_acc});
    inc[8*`SFSB_PC_SRAM_WR       +: 8] = popc({{(16-NUM_BANKS){1'b0}}, bank_wr_acc});
    inc[8*`SFSB_PC_OCC_SUM       +: 8] = ds_alloc_cnt + ps_alloc_cnt;
    inc[8*`SFSB_PC_H2B_BEATS     +: 8] = {7'd0, h2b_beat};
    inc[8*`SFSB_PC_H2B_ACTIVE    +: 8] = {7'd0, h2b_active};
    inc[8*`SFSB_PC_B2H_BEATS     +: 8] = {7'd0, b2h_beat};
    inc[8*`SFSB_PC_B2H_ACTIVE    +: 8] = {7'd0, b2h_active};
    inc[8*`SFSB_PC_ENC_BEATS     +: 8] = {7'd0, enc_beat};
    inc[8*`SFSB_PC_ENC_ACTIVE    +: 8] = {7'd0, enc_active};
    inc[8*`SFSB_PC_DEC_BEATS     +: 8] = {7'd0, dec_beat};
    inc[8*`SFSB_PC_DEC_ACTIVE    +: 8] = {7'd0, dec_active};
    inc[8*`SFSB_PC_ARB_STALL     +: 8] = popc({8'd0, p_stall});
    inc[8*`SFSB_PC_ECC_WAIT      +: 8] = {7'd0, enc_ecc_wait} + {7'd0, dec_ecc_wait};
    inc[8*`SFSB_PC_ECC_QWAIT     +: 8] = {7'd0, qwait_media[0] && enc_active} + {7'd0, qwait_media[1] && dec_active};
    inc[8*`SFSB_PC_NAND_STARVE   +: 8] = {7'd0, p_stall[1]};
    inc[8*`SFSB_PC_NAND_BEATS    +: 8] = {7'd0, nd_beat};
    inc[8*`SFSB_PC_HOST_REQ_WAIT +: 8] = {7'd0, host_req_wait};
    inc[8*`SFSB_PC_HOST_RSP_WAIT +: 8] = {7'd0, host_rsp_wait};
    inc[8*`SFSB_PC_CQ_FULL       +: 8] = {7'd0, ev_cq_full};
    inc[8*`SFSB_PC_DESC_SUB      +: 8] = {7'd0, sub_commit};
    inc[8*`SFSB_PC_DESC_CPL      +: 8] = popc({12'd0, cpl_hs});
    inc[8*`SFSB_PC_DESC_REJ      +: 8] = {7'd0, submit && !sub_commit};
    inc[8*`SFSB_PC_CACHE_LOOKUP  +: 8] = {7'd0, ev_lookup};
    inc[8*`SFSB_PC_CACHE_HIT     +: 8] = {7'd0, ev_hit};
    inc[8*`SFSB_PC_EVICT         +: 8] = {7'd0, ev_evict};
    inc[8*`SFSB_PC_MC_HIT        +: 8] = {7'd0, mc_hit};
    inc[8*`SFSB_PC_MC_MISS       +: 8] = {7'd0, mc_miss};
    for (int p = 0; p < NP; p++) inc[8*(`SFSB_PC_PORT_STALL0 + p) +: 8] = {7'd0, p_stall[p]};
  end

  sfsb_perf #(.NUM(PCN), .EN(PERF_EN)) u_perf (
    .clk, .rst_n, .clear(perf_clear), .freeze(perf_freeze), .inc,
    .occ_now(16'(ds_alloc_cnt) + 16'(ps_alloc_cnt)), .acc_wait, .cnt(perf_cnt)
  );

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_top = cfg_wce;
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
