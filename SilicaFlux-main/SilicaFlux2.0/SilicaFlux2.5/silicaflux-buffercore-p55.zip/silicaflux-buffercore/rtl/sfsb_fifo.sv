// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_fifo
// Synchronous show-ahead FIFO in flip-flops.  DEPTH is a power of two >= 2.
// push when !full (pushing while full is ignored and flagged in simulation),
// pop when !empty.  rdata is the head entry (combinational from registers).
// Reset empties the FIFO (contents are not cleared).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfsb_defs.svh"
`default_nettype none

module sfsb_fifo #(
  parameter int W     = 8,
  parameter int DEPTH = 4,
  localparam int AW   = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         push,
  input  wire logic [W-1:0] wdata,
  input  wire logic         pop,
  output logic      [W-1:0] rdata,
  output logic              full,
  output logic              empty,
  output logic      [AW:0]  count
);
  if (DEPTH < 2 || (DEPTH & (DEPTH - 1)) != 0) begin : g_err_depth_not_pow2
    `SFSB_CFG_FATAL("sfsb_fifo: DEPTH must be a power of two >= 2")
  end

  logic [W-1:0]  mem [DEPTH];
  logic [AW-1:0] wp, rp;

  assign full  = (count == (AW+1)'(DEPTH));
  assign empty = (count == '0);
  assign rdata = mem[rp];

  wire do_push = push && !full;
  wire do_pop  = pop && !empty;

  always_ff @(posedge clk) begin
    if (do_push) mem[wp] <= wdata;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wp    <= '0;
      rp    <= '0;
      count <= '0;
    end else begin
      if (do_push) wp <= wp + 1'b1;
      if (do_pop)  rp <= rp + 1'b1;
      count <= count + {{AW{1'b0}}, do_push} - {{AW{1'b0}}, do_pop};
    end
  end

`ifndef SYNTHESIS
  always @(posedge clk) begin
    if (rst_n && push && full) $error("%m: push while full (entry dropped)");
    if (rst_n && pop && empty) $error("%m: pop while empty");
  end
`endif
endmodule

`default_nettype wire
