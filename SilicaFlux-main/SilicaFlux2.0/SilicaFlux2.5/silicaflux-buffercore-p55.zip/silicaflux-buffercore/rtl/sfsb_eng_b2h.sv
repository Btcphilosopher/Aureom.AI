// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_eng_b2h   (host egress DMA)
// data slot --(bank reads)--> response FIFO --(SFB2 writes)--> host memory
//
// Integrity point V3 (verify on egress): every beat leaving the buffer is
// parity-checked (all 8 lanes) and folded into a CRC-32C that is compared,
// at the end of each logical block, with the check value stored in the
// metadata buffer (generated at G1 for written data, or verified at V2 for
// data read from NAND).  A mismatch poisons the block (VALID=0, POISON=1:
// no later B2H/ENC can use it) and the completion reports CRC / BUF_PAR.
// Data is streamed (no store-and-forward), so on an error status the host
// buffer contents are undefined - the NVMe convention; see docs/02.
//
// Completion: only after every host write has been acknowledged by the host
// memory port (SFB2 R7: the response of a write is issued after the write was
// performed), i.e. the data is committed at the destination.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfsb_defs.svh"
`default_nettype none

module sfsb_eng_b2h #(
  parameter int LB_BEATS  = 64,
  parameter int WAW       = 12,
  parameter int DSB_LOG2  = 8,
  parameter int FD        = 8,
  parameter int MAX_BURST = 16,
  localparam int DW_      = `SFSB_DESC_W,
  localparam int CW_      = `SFSB_CPL_W
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic           desc_valid,
  input  wire logic [DW_-1:0] desc,
  output logic                desc_take,
  // host port (writes)
  output logic                hq_valid,
  input  wire logic           hq_ready,
  output logic      [31:0]    hq_addr,
  output logic      [63:0]    hq_wdata,
  output logic                hq_last,
  input  wire logic           hr_valid,
  input  wire logic           hr_err,
  // bank port (reads)
  output logic                bp_req_valid,
  input  wire logic           bp_req_ready,
  output logic      [WAW-1:0] bp_req_addr,
  input  wire logic           bp_rsp_valid,
  input  wire logic [63:0]    bp_rsp_rdata,
  input  wire logic [7:0]     bp_rsp_perr,
  input  wire logic           bp_rsp_rerr,
  // metadata
  output logic      [7:0]     rd_d,
  output logic      [3:0]     rd_lb,
  input  wire logic [31:0]    rd_crc,
  output logic                poison,
  output logic      [7:0]     poison_d,
  output logic      [3:0]     poison_lb,
  // lock release + completion
  output logic                rel,
  output logic      [7:0]     rel_d,
  output logic                cpl_valid,
  output logic      [CW_-1:0] cpl_data,
  input  wire logic           cpl_ready,
  output logic                active,
  output logic                ev_beat
);
  `include "sfsb_funcs.svh"

  localparam int CNTW = 16;
  localparam int FAW  = $clog2(FD);
  localparam int LBB  = $clog2(LB_BEATS);

  typedef enum logic [1:0] {S_IDLE, S_RUN, S_CPL} st_t;
  st_t st;

  /* verilator lint_off UNUSEDSIGNAL */
  logic [DW_-1:0]  d;                    // not every descriptor field is used by this engine
  logic            f_full;               // never full: space is reserved before issue
  /* verilator lint_on UNUSEDSIGNAL */
  logic [CNTW-1:0] tot, rd_iss, rd_rcv, hw, hack, bcnt;
  logic [31:0]     crc, elapsed;
  logic [7:0]      lb_err, eflags;
  logic [LBB-1:0]  bib;
  logic [3:0]      k;
  logic            lb_par;   // parity error seen in the current logical block

  // ------------------------------------------------------------ bank reads
  logic        f_empty;
  logic [64:0] f_rd;
  logic [FAW:0] f_cnt;
  wire [CNTW-1:0] inflight = rd_iss - rd_rcv;
  wire credit_ok = ({1'b0, inflight} + {{(CNTW-FAW){1'b0}}, f_cnt}) < (CNTW+1)'(FD);
  wire [WAW-1:0] rbase = WAW'((32'(`SFSB_DF_DSLOT(d)) << DSB_LOG2) + 32'(`SFSB_DF_LBF(d)) * LB_BEATS);

  assign bp_req_valid = (st == S_RUN) && (rd_iss < tot) && credit_ok;
  assign bp_req_addr  = rbase + WAW'(rd_iss);
  wire   r_acc        = bp_req_valid && bp_req_ready;

  wire [64:0] f_wd = {(|bp_rsp_perr) || bp_rsp_rerr, bp_rsp_rdata};
  sfsb_fifo #(.W(65), .DEPTH(FD)) u_f (
    .clk, .rst_n, .push(bp_rsp_valid), .wdata(f_wd), .pop(hq_valid && hq_ready),
    .rdata(f_rd), .full(f_full), .empty(f_empty), .count(f_cnt)
  );

  // ------------------------------------------------------------ host writes
  wire [31:0] cur_haddr = `SFSB_DF_HADDR(d) + {16'd0, hw[CNTW-4:0], 3'b000};
  assign hq_valid = (st == S_RUN) && !f_empty;
  assign hq_addr  = cur_haddr;
  assign hq_wdata = f_rd[63:0];
  assign hq_last  = (hw + 1'b1 == tot) || (bcnt + 1'b1 == CNTW'(MAX_BURST)) || (cur_haddr[11:3] == 9'h1FF);
  wire   w_acc    = hq_valid && hq_ready;

  wire [31:0] crc_nx  = sfsb_crc32c_beat(crc, f_rd[63:0]);
  wire        lb_end  = w_acc && (bib == LBB'(LB_BEATS - 1));
  wire        par_now = f_rd[64];
  wire [3:0]  lb_abs  = `SFSB_DF_LBF(d) + k;
  wire        crc_bad = (~crc_nx != rd_crc);
  wire        lb_bad  = crc_bad || lb_par || par_now;

  assign rd_d      = `SFSB_DF_DSLOT(d);
  assign rd_lb     = lb_abs;
  assign poison    = lb_end && lb_bad;
  assign poison_d  = `SFSB_DF_DSLOT(d);
  assign poison_lb = lb_abs;

  assign desc_take = (st == S_IDLE) && desc_valid;
  wire done = (hw == tot) && (hack == tot);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; d <= '0; tot <= '0; rd_iss <= '0; rd_rcv <= '0; hw <= '0; hack <= '0; bcnt <= '0;
      crc <= 32'hFFFF_FFFF; elapsed <= '0; lb_err <= '0; eflags <= '0; bib <= '0; k <= '0; lb_par <= 1'b0;
    end else begin
      case (st)
        S_IDLE: if (desc_valid) begin
          d      <= desc;
          tot    <= CNTW'(32'(`SFSB_DF_LBC(desc)) * LB_BEATS);
          rd_iss <= '0; rd_rcv <= '0; hw <= '0; hack <= '0; bcnt <= '0;
          crc    <= 32'hFFFF_FFFF; elapsed <= '0; lb_err <= '0; eflags <= '0; bib <= '0; k <= '0;
          lb_par <= 1'b0;
          st     <= S_RUN;
        end
        S_RUN: begin
          elapsed <= elapsed + 1'b1;
          if (r_acc)        rd_iss <= rd_iss + 1'b1;
          if (bp_rsp_valid) rd_rcv <= rd_rcv + 1'b1;
          if (hr_valid) begin
            hack <= hack + 1'b1;
            if (hr_err) eflags[`SFSB_EF_HOST] <= 1'b1;
          end
          if (w_acc) begin
            hw   <= hw + 1'b1;
            bcnt <= hq_last ? '0 : bcnt + 1'b1;
            bib  <= bib + 1'b1;
            if (par_now) eflags[`SFSB_EF_BUF_PAR] <= 1'b1;
            if (lb_end) begin
              crc    <= 32'hFFFF_FFFF;
              lb_par <= 1'b0;
              k      <= k + 1'b1;
              if (lb_bad) lb_err[lb_abs[2:0]] <= 1'b1;
              if (crc_bad) eflags[`SFSB_EF_CRC] <= 1'b1;
            end else begin
              crc    <= crc_nx;
              lb_par <= lb_par || par_now;
            end
          end
          if (done) st <= S_CPL;
        end
        S_CPL: begin
          elapsed <= elapsed + 1'b1;
          if (cpl_ready) st <= S_IDLE;
        end
        default: st <= S_IDLE;
      endcase
    end
  end

  wire [7:0] status = eflags[`SFSB_EF_BUF_PAR] ? `SFSB_ST_BUF_PAR  :
                      eflags[`SFSB_EF_CRC]     ? `SFSB_ST_CRC      :
                      eflags[`SFSB_EF_HOST]    ? `SFSB_ST_HOST_ERR : `SFSB_ST_OK;

  assign cpl_valid = (st == S_CPL);
  assign cpl_data  = {elapsed,
                      eflags, 8'd0, 16'd0,
                      lb_err, status, 2'b00, `SFSB_DF_CLS(d), `SFSB_DF_OPC(d), `SFSB_DF_TID(d)};
  assign rel       = cpl_valid && cpl_ready;
  assign rel_d     = `SFSB_DF_DSLOT(d);
  assign active    = (st != S_IDLE);
  assign ev_beat   = w_acc;
endmodule

`default_nettype wire
