// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_nand_port   (NAND-controller DMA adapter)
// SFB2 slave (64-bit, DataFabric rev 2.0) through which a NAND channel
// controller moves raw page images between the NAND bus and the page buffer.
// It is the attachment point of SilicaFlux FlashLink (Project 53): its buffer
// master sfnc_buf_master (BUF_DW = 64) connects here unmodified.
//
// Address: buffer byte address (minus BASE).  Access rule (checked at
// acceptance against the buffer manager): the word must lie inside a page slot
// that firmware has handed to the NAND controller (state NAND, command
// P2NAND).  Anything else - data slots, page slots owned by firmware or an
// engine, misaligned or out-of-range addresses - gets an error response
// (rsp_rdata = 0) and no buffer access.  Reads check the parity of all 8 lanes
// (a NAND program must never send a corrupted beat to the flash silently).
//
// One transaction at a time (R6); response >= 3 cycles after acceptance.
// Write responses are issued after the SRAM acknowledged the write (R7).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfsb_defs.svh"
`default_nettype none

module sfsb_nand_port #(
  parameter int          WAW         = 12,
  parameter int          TOTAL_BEATS = 4096,
  parameter logic [31:0] BASE        = 32'h0
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  // SFB2 slave
  input  wire logic           s_req_valid,
  output logic                s_req_ready,
  input  wire logic           s_req_write,
  input  wire logic [31:0]    s_req_addr,
  input  wire logic [63:0]    s_req_wdata,
  input  wire logic [7:0]     s_req_wstrb,
  output logic                s_rsp_valid,
  input  wire logic           s_rsp_ready,
  output logic      [63:0]    s_rsp_rdata,
  output logic                s_rsp_error,
  // ownership check (buffer manager)
  output logic      [WAW-1:0] chk_wa,
  input  wire logic           chk_ok,
  // bank port
  output logic                bp_req_valid,
  input  wire logic           bp_req_ready,
  output logic                bp_req_we,
  output logic      [WAW-1:0] bp_req_addr,
  output logic      [63:0]    bp_req_wdata,
  output logic      [7:0]     bp_req_be,
  input  wire logic           bp_rsp_valid,
  input  wire logic [63:0]    bp_rsp_rdata,
  input  wire logic [7:0]     bp_rsp_perr,
  input  wire logic           bp_rsp_rerr,
  output logic                ev_beat
);
  typedef enum logic [1:0] {S_IDLE, S_ISSUE, S_WAIT, S_RESP} st_t;
  st_t st;

  wire [31:0] off     = s_req_addr - BASE;
  wire        aligned = (off[2:0] == 3'd0);
  wire        in_rng  = (off[31:3] < 29'(TOTAL_BEATS));
  assign chk_wa = WAW'(off[31:3]);
  wire ok = aligned && in_rng && chk_ok;

  logic           we_q;
  logic [WAW-1:0] wa_q;
  logic [63:0]    wd_q;
  logic [7:0]     be_q;

  assign s_req_ready = (st == S_IDLE);
  wire acc = s_req_valid && s_req_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; we_q <= 1'b0; wa_q <= '0; wd_q <= '0; be_q <= '0;
      s_rsp_rdata <= '0; s_rsp_error <= 1'b0;
    end else begin
      case (st)
        S_IDLE: if (acc) begin
          we_q <= s_req_write; wa_q <= chk_wa; wd_q <= s_req_wdata; be_q <= s_req_wstrb;
          if (ok) st <= S_ISSUE;
          else begin
            s_rsp_rdata <= '0;
            s_rsp_error <= 1'b1;
            st <= S_RESP;
          end
        end
        S_ISSUE: if (bp_req_ready) st <= S_WAIT;
        S_WAIT: if (bp_rsp_valid) begin
          s_rsp_error <= bp_rsp_rerr || (!we_q && (|bp_rsp_perr));
          s_rsp_rdata <= (we_q || bp_rsp_rerr || (|bp_rsp_perr)) ? 64'd0 : bp_rsp_rdata;
          st <= S_RESP;
        end
        S_RESP: if (s_rsp_ready) st <= S_IDLE;
        default: st <= S_IDLE;
      endcase
    end
  end

  assign bp_req_valid = (st == S_ISSUE);
  assign bp_req_we    = we_q;
  assign bp_req_addr  = wa_q;
  assign bp_req_wdata = wd_q;
  assign bp_req_be    = be_q;
  assign s_rsp_valid  = (st == S_RESP);
  assign ev_beat      = bp_req_valid && bp_req_ready;
endmodule

`default_nettype wire
