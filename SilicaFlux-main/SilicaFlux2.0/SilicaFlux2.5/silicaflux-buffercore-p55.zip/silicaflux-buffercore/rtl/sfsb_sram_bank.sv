// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_sram_bank
// Memory wrapper for one buffer bank: a SilicaFlux SRAM Wrapper Library
// single-port SRAM (sram_sp, Project 01, vendored unmodified) organised as
// 8 lanes x 9 bits = 72 bits per 64-bit data word:
//
//   lane l = { p_l, d_l }   d_l = byte l of the data word,
//                           p_l = ~^d_l  (ODD parity: a lane always holds an
//                                         odd number of ones, so an all-zero
//                                         or an all-ones 9-bit lane is an error)
//
// Byte enables map 1:1 onto the library's lane write mask (MASK_WIDTH = 8,
// lane width 9), so a partial write never needs a read-modify-write and the
// parity of every lane is always consistent with its byte.
//
// Response: exactly READ_LATENCY (= 1) cycle after acceptance (sram_sp with
// RSP_FIFO_DEPTH = 0, i.e. no back-pressure: every master of the bank
// crossbar must accept responses unconditionally).  WRITE_ACK = 1: every write
// is acknowledged after the array was written (SFB2 rule R7), which is what the
// DMA engines count before they report completion.  rsp_perr[l] = parity error
// in lane l of a read (0 for writes); the consumer masks the lanes it uses.
// rsp_rerr = row beyond DEPTH (from the library).
//
// Initialisation: real SRAM powers up with random content, i.e. random
// parity.  After every reset the wrapper writes zero data with correct parity
// to every row (DEPTH cycles) before it accepts functional requests
// (init_done).  The initialisation writes carry an internal ID bit and their
// acknowledgements are absorbed here.
//
// Fault injection: while fi_arm = 1, the next accepted functional write to
// row fi_row stores (encoded word XOR fi_mask) and pulses fi_fire.  Used to
// prove that parity (single-bit) and the end-to-end CRC (parity-invisible
// double-bit) detect buffer corruption.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`include "sfsb_defs.svh"
`default_nettype none

module sfsb_sram_bank #(
  parameter int DEPTH   = 1024,
  parameter int IDW     = 3,
  parameter int BACKEND = `SRAM_BACKEND_GENERIC,
  parameter int MACRO   = 0,
  localparam int RW     = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic           req_valid,
  output logic                req_ready,
  input  wire logic           req_we,
  input  wire logic [RW-1:0]  req_row,
  input  wire logic [63:0]    req_wdata,
  input  wire logic [7:0]     req_be,
  input  wire logic [IDW-1:0] req_id,
  output logic                rsp_valid,
  output logic                rsp_we,
  output logic [63:0]         rsp_rdata,
  output logic [7:0]          rsp_perr,
  output logic                rsp_rerr,
  output logic [IDW-1:0]      rsp_id,
  output logic                init_done,
  input  wire logic           fi_arm,
  input  wire logic [RW-1:0]  fi_row,
  input  wire logic [71:0]    fi_mask,
  output logic                fi_fire
);
  // ------------------------------------------------------------ initialisation sweep
  logic          init_q;            // 1 while sweeping
  logic [RW-1:0] init_row;
  logic          s_ready;

  wire init_acc = init_q && s_ready;
  wire init_last = (init_row == RW'(DEPTH - 1));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      init_q   <= 1'b1;
      init_row <= '0;
    end else if (init_acc) begin
      init_row <= init_row + 1'b1;
      if (init_last) init_q <= 1'b0;
    end
  end
  assign init_done = !init_q;

  // ------------------------------------------------------------ encode
  logic [71:0] enc;
  always_comb begin
    for (int l = 0; l < 8; l++) enc[l*9 +: 9] = {~^req_wdata[l*8 +: 8], req_wdata[l*8 +: 8]};
  end
  localparam logic [71:0] ZERO_ENC = {8{9'b1_0000_0000}};

  wire func_acc = !init_q && req_valid && s_ready;
  wire fi_hit   = fi_arm && func_acc && req_we && (req_row == fi_row);
  assign fi_fire = fi_hit;

  logic          s_valid, s_we;
  logic [RW-1:0] s_addr;
  logic [71:0]   s_wdata;
  logic [7:0]    s_mask;
  logic [IDW:0]  s_id;

  always_comb begin
    if (init_q) begin
      s_valid = 1'b1;
      s_we    = 1'b1;
      s_addr  = init_row;
      s_wdata = ZERO_ENC;
      s_mask  = 8'hFF;
      s_id    = {1'b1, {IDW{1'b0}}};
    end else begin
      s_valid = req_valid;
      s_we    = req_we;
      s_addr  = req_row;
      s_wdata = enc ^ (fi_hit ? fi_mask : 72'd0);
      s_mask  = req_be;
      s_id    = {1'b0, req_id};
    end
  end
  assign req_ready = !init_q && s_ready;

  // ------------------------------------------------------------ the library SRAM
  logic          r_valid, r_err, r_we;
  logic [71:0]   r_rdata;
  logic [IDW:0]  r_id;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [71:0]   tst_rdata_unused;
  logic          busy_unused;
  /* verilator lint_on UNUSEDSIGNAL */

  sram_sp #(
    .DATA_WIDTH(72), .DEPTH(DEPTH), .MASK_WIDTH(8), .READ_LATENCY(1),
    .BACKEND(BACKEND), .MACRO(MACRO), .RSP_FIFO_DEPTH(0), .WRITE_ACK(1),
    .ID_WIDTH(IDW + 1), .TEST_EN(0)
  ) u_sram (
    .clk, .rst_n,
    .req_valid(s_valid), .req_ready(s_ready), .req_we(s_we), .req_addr(s_addr),
    .req_wdata(s_wdata), .req_wmask(s_mask), .req_id(s_id),
    .rsp_valid(r_valid), .rsp_ready(1'b1), .rsp_rdata(r_rdata), .rsp_err(r_err), .rsp_we(r_we),
    .rsp_id(r_id),
    .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0),
    .tst_rdata(tst_rdata_unused), .busy(busy_unused)
  );

  // ------------------------------------------------------------ decode / parity check
  assign rsp_valid = r_valid && !r_id[IDW];          // initialisation acks absorbed
  assign rsp_we    = r_we;
  assign rsp_rerr  = r_err;
  assign rsp_id    = r_id[IDW-1:0];
  always_comb begin
    for (int l = 0; l < 8; l++) begin
      rsp_rdata[l*8 +: 8] = r_rdata[l*9 +: 8];
      rsp_perr[l]         = r_valid && !r_we && !r_err && !(^r_rdata[l*9 +: 9]);
    end
  end
endmodule

`default_nettype wire
