// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_perf   (performance instrumentation)
// NUM 32-bit counters.  Counter i adds inc[8i +: 8] every cycle (saturating at
// 2^32-1) unless frozen; clear zeroes all.  Two counters are maxima instead of
// sums: OCC_MAX (peak allocated slots, from occ_now) and MAX_WAIT (longest bank
// arbitration wait of an accepted request, from acc_wait).  EN = 0 removes
// the counters (all read 0).  Index map: sfsb_defs.svh SFSB_PC_*.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfsb_defs.svh"
`default_nettype none

module sfsb_perf #(
  parameter int NUM = `SFSB_PC_NUM,
  parameter int EN  = 1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              clear,
  input  wire logic              freeze,
  input  wire logic [NUM*8-1:0]  inc,
  input  wire logic [15:0]       occ_now,
  input  wire logic [15:0]       acc_wait,
  output logic      [NUM*32-1:0] cnt
);
  if (EN != 0) begin : g_on
    logic [31:0] c [NUM];
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        for (int i = 0; i < NUM; i++) c[i] <= '0;
      end else if (clear) begin
        for (int i = 0; i < NUM; i++) c[i] <= '0;
      end else if (!freeze) begin
        for (int i = 0; i < NUM; i++) begin
          if (i == `SFSB_PC_OCC_MAX) begin
            if (32'(occ_now) > c[i]) c[i] <= 32'(occ_now);
          end else if (i == `SFSB_PC_MAX_WAIT) begin
            if (32'(acc_wait) > c[i]) c[i] <= 32'(acc_wait);
          end else begin
            if ({1'b0, c[i]} + 33'(inc[8*i +: 8]) > 33'h0_FFFF_FFFF) c[i] <= 32'hFFFF_FFFF;
            else c[i] <= c[i] + 32'(inc[8*i +: 8]);
          end
        end
      end
    end
    always_comb for (int i = 0; i < NUM; i++) cnt[32*i +: 32] = c[i];
  end else begin : g_off
    assign cnt = '0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused = clk ^ rst_n ^ clear ^ freeze ^ (^inc) ^ (^occ_now) ^ (^acc_wait);
    /* verilator lint_on UNUSEDSIGNAL */
  end
endmodule

`default_nettype wire
