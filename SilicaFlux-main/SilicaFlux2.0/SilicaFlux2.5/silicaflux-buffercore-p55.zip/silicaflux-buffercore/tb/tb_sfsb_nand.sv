// =============================================================================
// SilicaFlux BufferCore (Project 55) :: tb_sfsb_nand   (VERIFICATION ONLY)
// DEFINITION-OF-DONE integration bench: a complete memory-to-NAND and
// NAND-to-memory transfer with real data-integrity checking, through REAL,
// UNMODIFIED repository blocks:
//
//   host memory model <-SFB2-> silicaflux_storage_buffer <-SFB2 (nd port)-> FlashLink
//   (Project 53) silicaflux_nand_controller (BUF_DW = 64) <-ONFI pins-> sfnc_io_sdr
//   <-> NANDLab (Project 52) nand_flash_device, watched by sfnc_onfi_monitor;
//   the buffer's DRAM adapter <-SFB2-> MemoryBridge (Project 24)
//   silicaflux_extmem_bridge <-SFMC-> extmem_sim_mc (simulation-only controller).
//
// The testbench plays the firmware: it drives the buffer through its firmware
// port and the NAND controller through its request interface, exactly as the
// ControlCore firmware would.  NAND bit errors are injected by flipping stored
// cells of the NANDLab page pool (test-only access, models retention errors).
// Geometry: 512-byte data page + 128-byte spare (config/nandlab_p55.svcfg);
// buffer LB = 128 B, 4 per page -> page image 616 B (data, SECDED check bytes,
// OOB {LBA, CRC32C} metadata).
// =============================================================================
`timescale 1ns/1ps
`include "sfsb_defs.svh"
`include "extmem_defs.svh"
`default_nettype none

module tb_sfsb_nand;
  localparam int NUM_BANKS   = 4;
  localparam int LB_BYTES    = 128;
  localparam int PAGE_LBS    = 4;
  localparam int NUM_DSLOTS  = 8;
  localparam int NUM_PSLOTS  = 4;
  localparam int LB_BEATS    = LB_BYTES / 8;
  localparam int PAR_BEATS   = LB_BEATS / 8;
  localparam int CWB         = LB_BEATS + PAR_BEATS;
  localparam int DSLOT_BEATS = PAGE_LBS * LB_BEATS;
  localparam int PIMG_BEATS  = PAGE_LBS * CWB + PAGE_LBS + 1;
  localparam int PIMG_BYTES  = PIMG_BEATS * 8;
  localparam int PSLOT_BEATS = ((PIMG_BEATS + NUM_BANKS - 1) / NUM_BANKS) * NUM_BANKS;
  localparam int PS_BASE     = NUM_DSLOTS * DSLOT_BEATS;
  localparam int OOB         = PAGE_LBS * CWB;
  localparam int HWORDS      = 32768;
  localparam int PD = 512, PSP = 128, PB = PD + PSP, PPB = 16, BPP = 32, PPL = 2, LUNS = 2;
  localparam int CLK_PS      = 10000;
  localparam logic [31:0] DRAM_BASE = 32'h8000_0000;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  logic vcc_ok = 1'b1;
  always #5 clk = ~clk;

  // ------------------------------------------------------------ buffer subsystem
  logic        fw_req_valid = 0, fw_req_ready, fw_req_write = 0, fw_rsp_valid, fw_rsp_error;
  logic [31:0] fw_req_addr = 0, fw_req_wdata = 0, fw_rsp_rdata;
  logic [3:0]  fw_req_wstrb = 0;
  logic        nd_req_valid, nd_req_ready, nd_req_write, nd_rsp_valid, nd_rsp_ready, nd_rsp_error;
  logic [31:0] nd_req_addr;
  logic [63:0] nd_req_wdata, nd_rsp_rdata;
  logic [7:0]  nd_req_wstrb;
  logic        hm_req_valid, hm_req_ready, hm_req_write, hm_rsp_valid, hm_rsp_ready, hm_rsp_error;
  logic [31:0] hm_req_addr;
  logic [63:0] hm_req_wdata, hm_rsp_rdata;
  logic [7:0]  hm_req_wstrb;
  logic        xm_req_valid, xm_req_ready, xm_req_write, xm_rsp_valid, xm_rsp_ready, xm_rsp_error;
  logic [31:0] xm_req_addr;
  logic [63:0] xm_req_wdata, xm_rsp_rdata;
  logic [7:0]  xm_req_wstrb;
  logic        irq, busy, init_done, plp_dirty;

  silicaflux_storage_buffer #(
    .NUM_BANKS(NUM_BANKS), .LB_BYTES(LB_BYTES), .PAGE_LBS(PAGE_LBS), .NUM_DSLOTS(NUM_DSLOTS),
    .NUM_PSLOTS(NUM_PSLOTS), .CRYPTO_EN(1), .EXT_DRAM_EN(1), .DRAM_BASE(DRAM_BASE)
  ) dut (
    .clk, .rst_n,
    .fw_req_valid, .fw_req_ready, .fw_req_write, .fw_req_addr, .fw_req_wdata, .fw_req_wstrb,
    .fw_rsp_valid, .fw_rsp_ready(1'b1), .fw_rsp_rdata, .fw_rsp_error,
    .nd_req_valid, .nd_req_ready, .nd_req_write, .nd_req_addr, .nd_req_wdata, .nd_req_wstrb,
    .nd_rsp_valid, .nd_rsp_ready, .nd_rsp_rdata, .nd_rsp_error,
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error,
    .xm_req_valid, .xm_req_ready, .xm_req_write, .xm_req_addr, .xm_req_wdata, .xm_req_wstrb,
    .xm_rsp_valid, .xm_rsp_ready, .xm_rsp_rdata, .xm_rsp_error,
    .pwr_fail_i(1'b0), .irq, .busy, .init_done, .plp_dirty
  );

  sfsb_tb_mem #(.WORDS(HWORDS), .BASE(32'h0), .MAX_OUT(8)) u_hm (
    .clk, .rst_n,
    .req_valid(hm_req_valid), .req_ready(hm_req_ready), .req_write(hm_req_write), .req_addr(hm_req_addr),
    .req_wdata(hm_req_wdata), .req_wstrb(hm_req_wstrb), .rsp_valid(hm_rsp_valid), .rsp_ready(hm_rsp_ready),
    .rsp_rdata(hm_rsp_rdata), .rsp_error(hm_rsp_error)
  );

  // ------------------------------------------------------------ FlashLink NAND controller (P53, unmodified)
  logic        req_valid = 0, req_ready;
  logic [3:0]  req_op = 0;
  logic [7:0]  req_tag = 0;
  logic [2:0]  req_ce = 0, req_lun = 0;
  logic [23:0] req_block = 0;
  logic [15:0] req_page = 0, req_col = 0, req_len = 0;
  logic [31:0] req_buf = 0, req_fdata = 0;
  logic [7:0]  req_faddr = 0;
  logic        cpl_valid, cpl_ready;
  logic [7:0]  cpl_tag, cpl_nst;
  logic [3:0]  cpl_op, cpl_status;
  logic [2:0]  cpl_ce, cpl_lun;
  logic [31:0] cpl_info0, cpl_info1, cpl_latency, cpl_dev;
  logic        csr_sel = 0, csr_we = 0, csr_err;
  logic [7:0]  csr_addr = 0;
  logic [31:0] csr_wdata = 0, csr_rdata;
  logic [0:0]  c_ce_n;
  logic        c_cle, c_ale, c_we_n, c_re_n, c_wp_n, c_dq_oe, nirq, nbusy;
  logic [7:0]  c_dq_o, c_dq_i;
  logic [0:0]  c_rb_n;
  logic [2:0]  tmode;
  assign cpl_ready = 1'b1;

  silicaflux_nand_controller #(
    .DQ_WIDTH(8), .NUM_CE(1), .RB_SHARED(0), .NUM_LUN_MAX(2), .QUEUE_DEPTH(4), .CPL_DEPTH(4),
    .TAG_W(8), .BUF_DW(64), .CLK_PERIOD_PS(CLK_PS), .DEF_LUNS(1)
  ) u_nc (
    .clk(clk), .rst_n(rst_n),
    .req_valid(req_valid), .req_ready(req_ready), .req_op(req_op), .req_tag(req_tag), .req_ce(req_ce),
    .req_lun(req_lun), .req_block(req_block), .req_page(req_page), .req_col(req_col), .req_len(req_len),
    .req_buf(req_buf), .req_faddr(req_faddr), .req_fdata(req_fdata),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_tag(cpl_tag), .cpl_op(cpl_op), .cpl_status(cpl_status),
    .cpl_nand_status(cpl_nst), .cpl_ce(cpl_ce), .cpl_lun(cpl_lun), .cpl_info0(cpl_info0), .cpl_info1(cpl_info1),
    .cpl_latency(cpl_latency), .cpl_dev_time(cpl_dev),
    .csr_sel(csr_sel), .csr_we(csr_we), .csr_addr(csr_addr), .csr_wdata(csr_wdata), .csr_rdata(csr_rdata),
    .csr_err(csr_err),
    .m_req_valid(nd_req_valid), .m_req_ready(nd_req_ready), .m_req_write(nd_req_write), .m_req_addr(nd_req_addr),
    .m_req_wdata(nd_req_wdata), .m_req_wstrb(nd_req_wstrb), .m_rsp_valid(nd_rsp_valid), .m_rsp_ready(nd_rsp_ready),
    .m_rsp_rdata(nd_rsp_rdata), .m_rsp_error(nd_rsp_error),
    .nand_ce_n(c_ce_n), .nand_cle(c_cle), .nand_ale(c_ale), .nand_we_n(c_we_n), .nand_re_n(c_re_n),
    .nand_wp_n(c_wp_n), .nand_dq_o(c_dq_o), .nand_dq_oe(c_dq_oe), .nand_dq_i(c_dq_i), .nand_rb_n(c_rb_n),
    .irq(nirq), .busy(nbusy), .timing_mode(tmode));

  // pads idle until the controller has been through reset (as in the P53 bench)
  logic pins_live = 1'b0;
  always @(posedge clk) if (!rst_n) pins_live <= 1'b1;
  wire [0:0] g_ce_n = pins_live ? c_ce_n : 1'b1;
  wire g_cle = pins_live & c_cle, g_ale = pins_live & c_ale, g_we_n = !pins_live | c_we_n;
  wire g_re_n = !pins_live | c_re_n, g_wp_n = pins_live & c_wp_n, g_dq_oe = pins_live & c_dq_oe;
  wire [0:0] p_ce_n;
  wire p_cle, p_ale, p_we_n, p_re_n, p_wp_n;
  tri  [7:0] p_dq;
  wire [0:0] p_rb_n;

  sfnc_io_sdr #(.DQW(8), .NUM_CE(1), .NUM_RB(1), .TECH("SIM")) u_io (
    .c_ce_n(g_ce_n), .c_cle(g_cle), .c_ale(g_ale), .c_we_n(g_we_n), .c_re_n(g_re_n), .c_wp_n(g_wp_n),
    .c_dq_o(c_dq_o), .c_dq_oe(g_dq_oe), .c_dq_i(c_dq_i), .c_rb_n(c_rb_n),
    .pad_ce_n(p_ce_n), .pad_cle(p_cle), .pad_ale(p_ale), .pad_we_n(p_we_n), .pad_re_n(p_re_n),
    .pad_wp_n(p_wp_n), .pad_dq(p_dq), .pad_rb_n(p_rb_n));

  nand_flash_device #(.PAGE_DATA_BYTES(PD), .PAGE_SPARE_BYTES(PSP), .PAGES_PER_BLOCK(PPB),
    .BLOCKS_PER_PLANE(BPP), .PLANES_PER_LUN(PPL), .LUNS(LUNS), .TARGET_ID(0)) u_dev (
    .ce_n(p_ce_n[0]), .cle(p_cle), .ale(p_ale), .we_n(p_we_n), .re_n(p_re_n), .wp_n(p_wp_n),
    .vcc_ok(vcc_ok), .dq(p_dq), .rb_n(p_rb_n[0]));

  sfnc_onfi_monitor #(.NUM_CE(1), .DQW(8), .PER_CE_RB(1)) u_mon (
    .ce_n(p_ce_n), .cle(p_cle), .ale(p_ale), .we_n(p_we_n), .re_n(p_re_n), .wp_n(p_wp_n), .dq(p_dq),
    .dq_oe(g_dq_oe), .rb_n(p_rb_n), .vcc_ok(vcc_ok));

  // ------------------------------------------------------------ MemoryBridge (P24, unmodified) + sim controller
  localparam int XTW = 4;    // tag width for MAX_RD_OUT = MAX_WR_OUT = 8 -> clog2 = 3; bridge TW = 3
  logic             mc_rst_n, mc_init_done, mc_fatal;
  logic             mc_cmd_valid, mc_cmd_ready, mc_cmd_write;
  logic [27:0]      mc_cmd_addr;
  logic [7:0]       mc_cmd_len;
  logic [2:0]       mc_cmd_tag;
  logic             mc_wd_valid, mc_wd_ready, mc_wd_last;
  logic [63:0]      mc_wd_data;
  logic [7:0]       mc_wd_strb;
  logic             mc_rd_valid, mc_rd_ready, mc_rd_last, mc_rd_error;
  logic [63:0]      mc_rd_data;
  logic [2:0]       mc_rd_tag;
  logic             mc_wr_valid, mc_wr_ready, mc_wr_error;
  logic [2:0]       mc_wr_tag;
  /* verilator lint_off UNUSEDSIGNAL */
  logic             x_csr_ready, x_csr_rvalid, x_csr_err, st_ready, st_cal_fail, st_fault, st_idle, x_err_evt, x_err_wr;
  logic [31:0]      x_csr_rdata, x_err_addr;
  logic [2:0]       st_state;
  logic [3:0]       x_err_code, x_err_id, xm_rsp_id;
  logic             xm_rsp_last, xm_rsp_write;
  logic [`XM_PERF_N*32-1:0] x_perf;
  int               mc_viol, mc_rc, mc_wc, mc_rb, mc_wb, mc_re, mc_wp, mc_h, mc_m;
  /* verilator lint_on UNUSEDSIGNAL */

  silicaflux_extmem_bridge #(.DW(64), .EXT_BASE(DRAM_BASE), .EXT_SIZE(33'h0_0010_0000), .MC_AW(28)) u_xb (
    .clk, .rst_n, .mc_clk(clk),
    .up_req_valid(xm_req_valid), .up_req_ready(xm_req_ready), .up_req_write(xm_req_write), .up_req_addr(xm_req_addr),
    .up_req_wdata(xm_req_wdata), .up_req_wstrb(xm_req_wstrb), .up_req_id(4'd0), .up_req_len(8'd0), .up_req_last(1'b1),
    .up_rsp_valid(xm_rsp_valid), .up_rsp_ready(xm_rsp_ready), .up_rsp_rdata(xm_rsp_rdata), .up_rsp_error(xm_rsp_error),
    .up_rsp_id(xm_rsp_id), .up_rsp_last(xm_rsp_last), .up_rsp_write(xm_rsp_write),
    .csr_req_valid(1'b0), .csr_req_ready(x_csr_ready), .csr_req_write(1'b0), .csr_req_addr(32'd0),
    .csr_req_wdata(32'd0), .csr_req_wstrb(4'd0), .csr_rsp_valid(x_csr_rvalid), .csr_rsp_ready(1'b1),
    .csr_rsp_rdata(x_csr_rdata), .csr_rsp_error(x_csr_err),
    .mc_rst_n, .mc_init_done, .mc_fatal,
    .mc_cmd_valid, .mc_cmd_ready, .mc_cmd_write, .mc_cmd_addr, .mc_cmd_len, .mc_cmd_tag,
    .mc_wd_valid, .mc_wd_ready, .mc_wd_data, .mc_wd_strb, .mc_wd_last,
    .mc_rd_valid, .mc_rd_ready, .mc_rd_data, .mc_rd_tag, .mc_rd_last, .mc_rd_error,
    .mc_wr_valid, .mc_wr_ready, .mc_wr_tag, .mc_wr_error,
    .ctl_mc_reset_req(1'b0), .st_state, .st_ready, .st_cal_fail, .st_fault_seen(st_fault), .st_idle,
    .err_evt(x_err_evt), .err_code(x_err_code), .err_addr(x_err_addr), .err_id(x_err_id), .err_write(x_err_wr),
    .perf_cnt(x_perf)
  );

  extmem_sim_mc #(.DW(64), .MC_AW(28), .LW(8), .TW(3), .MB(16), .MEM_BYTES(65536)) u_mc (
    .clk, .rst_n(mc_rst_n), .init_done(mc_init_done), .fatal(mc_fatal),
    .cmd_valid(mc_cmd_valid), .cmd_ready(mc_cmd_ready), .cmd_write(mc_cmd_write), .cmd_addr(mc_cmd_addr),
    .cmd_len(mc_cmd_len), .cmd_tag(mc_cmd_tag),
    .wd_valid(mc_wd_valid), .wd_ready(mc_wd_ready), .wd_data(mc_wd_data), .wd_strb(mc_wd_strb), .wd_last(mc_wd_last),
    .rd_valid(mc_rd_valid), .rd_ready(mc_rd_ready), .rd_data(mc_rd_data), .rd_tag(mc_rd_tag), .rd_last(mc_rd_last),
    .rd_error(mc_rd_error), .wr_valid(mc_wr_valid), .wr_ready(mc_wr_ready), .wr_tag(mc_wr_tag), .wr_error(mc_wr_error),
    .tb_cal_drop(1'b0), .tb_hang(1'b0), .tb_fatal(1'b0), .tb_poison_en(1'b0), .tb_poison_lo(32'd0),
    .tb_poison_hi(32'd0), .tb_rderr_p16(32'd0), .tb_lat_min(32'd2), .tb_lat_max(32'd12),
    .tb_cmd_rdy_pct(32'd80), .tb_wd_rdy_pct(32'd80), .tb_rsp_pct(32'd80),
    .st_violations(mc_viol), .st_rd_cmds(mc_rc), .st_wr_cmds(mc_wc), .st_rd_beats(mc_rb), .st_wr_beats(mc_wb),
    .st_rderr_inj(mc_re), .st_wr_poisoned(mc_wp), .st_row_hits(mc_h), .st_row_miss(mc_m)
  );

  // MemoryBridge's own controller-interface checker (P24 tb, unmodified)
  int mchk_viol;
  /* verilator lint_off UNUSEDSIGNAL */
  int mchk_a, mchk_b, mchk_c, mchk_d;
  /* verilator lint_on UNUSEDSIGNAL */
  extmem_mc_checker #(.DW(64), .MC_AW(28), .LW(8), .TW(3), .NAME("mc")) u_mchk (
    .clk, .rst_n(mc_rst_n),
    .cmd_valid(mc_cmd_valid), .cmd_ready(mc_cmd_ready), .cmd_write(mc_cmd_write), .cmd_addr(mc_cmd_addr),
    .cmd_len(mc_cmd_len), .cmd_tag(mc_cmd_tag),
    .wd_valid(mc_wd_valid), .wd_ready(mc_wd_ready), .wd_data(mc_wd_data), .wd_strb(mc_wd_strb), .wd_last(mc_wd_last),
    .rd_valid(mc_rd_valid), .rd_ready(mc_rd_ready), .rd_data(mc_rd_data), .rd_tag(mc_rd_tag),
    .rd_last(mc_rd_last), .rd_error(mc_rd_error),
    .wr_valid(mc_wr_valid), .wr_ready(mc_wr_ready), .wr_tag(mc_wr_tag), .wr_error(mc_wr_error),
    .violations(mchk_viol), .n_rd_cmd(mchk_a), .n_wr_cmd(mchk_b), .n_rd_beats(mchk_c), .n_wr_rsp(mchk_d)
  );

  int xm_trace = 0;
  always @(posedge clk) if (xm_trace > 0 && rst_n) begin
    if (xm_req_valid || xm_rsp_valid || mc_cmd_valid || mc_wd_valid || mc_wr_valid || mc_rd_valid)
      $display("[%0t] xm req v%0d r%0d w%0d a%h | rsp v%0d e%0d | mc cmd v%0d r%0d wd v%0d r%0d wr v%0d rd v%0d | st %0d idle %0d",
               $time, xm_req_valid, xm_req_ready, xm_req_write, xm_req_addr, xm_rsp_valid, xm_rsp_error,
               mc_cmd_valid, mc_cmd_ready, mc_wd_valid, mc_wd_ready, mc_wr_valid, mc_rd_valid, st_state, st_idle);
    xm_trace <= xm_trace - 1;
  end

  // ------------------------------------------------------------ protocol checkers
  logic [31:0] v_fw, v_nd, v_hm, v_xm;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] nq0, nr0, no0, nq1, nr1, no1, nq2, nr2, no2, nq3, nr3, no3;
  /* verilator lint_on UNUSEDSIGNAL */
  sfb_protocol_checker #(.AW(32), .DW(32), .MAX_OUT(1), .NAME("fw")) u_chk_fw (
    .clk, .rst_n, .req_valid(fw_req_valid), .req_ready(fw_req_ready), .req_write(fw_req_write),
    .req_addr(fw_req_addr), .req_wdata(fw_req_wdata), .req_wstrb(fw_req_wstrb), .rsp_valid(fw_rsp_valid),
    .rsp_ready(1'b1), .rsp_rdata(fw_rsp_rdata), .rsp_error(fw_rsp_error),
    .violations(v_fw), .n_req(nq0), .n_rsp(nr0), .outstanding(no0));
  sfb_protocol_checker #(.AW(32), .DW(64), .MAX_OUT(1), .NAME("nand")) u_chk_nd (
    .clk, .rst_n, .req_valid(nd_req_valid), .req_ready(nd_req_ready), .req_write(nd_req_write),
    .req_addr(nd_req_addr), .req_wdata(nd_req_wdata), .req_wstrb(nd_req_wstrb), .rsp_valid(nd_rsp_valid),
    .rsp_ready(nd_rsp_ready), .rsp_rdata(nd_rsp_rdata), .rsp_error(nd_rsp_error),
    .violations(v_nd), .n_req(nq1), .n_rsp(nr1), .outstanding(no1));
  sfb_protocol_checker #(.AW(32), .DW(64), .MAX_OUT(1), .NAME("host")) u_chk_hm (
    .clk, .rst_n, .req_valid(hm_req_valid), .req_ready(hm_req_ready), .req_write(hm_req_write),
    .req_addr(hm_req_addr), .req_wdata(hm_req_wdata), .req_wstrb(hm_req_wstrb), .rsp_valid(hm_rsp_valid),
    .rsp_ready(hm_rsp_ready), .rsp_rdata(hm_rsp_rdata), .rsp_error(hm_rsp_error),
    .violations(v_hm), .n_req(nq2), .n_rsp(nr2), .outstanding(no2));
  sfb_protocol_checker #(.AW(32), .DW(64), .MAX_OUT(1), .NAME("dram")) u_chk_xm (
    .clk, .rst_n, .req_valid(xm_req_valid), .req_ready(xm_req_ready), .req_write(xm_req_write),
    .req_addr(xm_req_addr), .req_wdata(xm_req_wdata), .req_wstrb(xm_req_wstrb), .rsp_valid(xm_rsp_valid),
    .rsp_ready(xm_rsp_ready), .rsp_rdata(xm_rsp_rdata), .rsp_error(xm_rsp_error),
    .violations(v_xm), .n_req(nq3), .n_rsp(nr3), .outstanding(no3));

  // ------------------------------------------------------------ scoreboard state (see sfsb_tb_common.svh)
  int n_chk = 0, n_err = 0;
  logic        outst [256];
  logic        done  [256];
  logic [31:0] c_w0 [256];
  logic [31:0] c_w1 [256];
  logic [31:0] c_w2 [256];
  int          n_acc = 0, n_cpl = 0;
  logic [7:0]  order [512];
  int          n_order = 0;
  logic [7:0]  gold_ver [1024];
  logic [7:0]  tid_next = 8'd1;
  logic [31:0] h_next = 32'h0;
  logic [7:0]  last_tid = 8'd0;
  logic [8*24-1:0] cur_test = "init";

  `include "sfsb_tb_common.svh"

  function automatic [31:0] ps_addr(input int ps);
    ps_addr = 32'((PS_BASE + ps * PSLOT_BEATS) * 8);
  endfunction

  // ------------------------------------------------------------ NAND controller request side
  bit          nc_got [256];
  logic [3:0]  nc_st  [256];
  logic [7:0]  nc_nst [256];
  logic [31:0] nc_i0  [256];
  logic [31:0] nc_i1  [256];
  logic [7:0]  nc_tag = 8'd0;
  logic [3:0]  r_st;
  logic [7:0]  r_nst;
  logic [31:0] r_i0, r_i1;
  always @(posedge clk) begin
    if (cpl_valid && cpl_ready) begin
      nc_got[cpl_tag] = 1'b1; nc_st[cpl_tag] = cpl_status; nc_nst[cpl_tag] = cpl_nst;
      nc_i0[cpl_tag] = cpl_info0; nc_i1[cpl_tag] = cpl_info1;
    end
  end

  localparam logic [3:0] NC_RST = 4'h0, NC_RPRM = 4'h2, NC_RD = 4'h4, NC_PG = 4'h5, NC_ER = 4'h6;
  localparam logic [3:0] NC_OK = 4'h0, NC_DEVF = 4'h1;

  task automatic nc_op(input logic [3:0] op, input int blk, input int pg, input int col, input int len,
                       input logic [31:0] bufa, input int max_cycles);
    logic [7:0] t;
    int n;
    t = nc_tag; nc_tag = nc_tag + 8'd1;
    nc_got[t] = 1'b0;
    req_valid = 1'b1; req_op = op; req_tag = t; req_ce = 3'd0; req_lun = 3'd0; req_block = 24'(blk);
    req_page = 16'(pg); req_col = 16'(col); req_len = 16'(len); req_buf = bufa; req_faddr = 8'd0; req_fdata = 32'd0;
    #1;
    while (!req_ready) begin @(posedge clk); #2; end
    @(posedge clk); #1;
    req_valid = 1'b0;
    n = 0;
    while (!nc_got[t] && n < max_cycles) begin @(posedge clk); n++; end
    #1;
    chk(nc_got[t], "NAND controller completion");
    r_st = nc_st[t]; r_nst = nc_nst[t]; r_i0 = nc_i0[t]; r_i1 = nc_i1[t];
  endtask

  task automatic nc_csr_rd(input logic [7:0] a, output logic [31:0] v);
    @(negedge clk); csr_sel = 1; csr_we = 0; csr_addr = a; #1;
    v = csr_rdata;
    @(negedge clk); csr_sel = 0;
    @(posedge clk); #1;
  endtask

  task automatic nc_csr_wr(input logic [7:0] a, input logic [31:0] d);
    @(negedge clk); csr_sel = 1; csr_we = 1; csr_addr = a; csr_wdata = d;
    @(negedge clk); csr_sel = 0; csr_we = 0;
    @(posedge clk); #1;
  endtask

  // flip a stored bit of NAND page (lun 0, blk, pg), byte c: a retention error in the medium
  task automatic nand_flip(input int blk, input int pg, input int c, input int b);
    int pi;
    pi = (0 * (BPP * PPL) + blk) * PPB + pg;
    u_dev.u_model.pool[u_dev.u_model.slot_of[pi] * PB + c][b] = ~u_dev.u_model.pool[u_dev.u_model.slot_of[pi] * PB + c][b];
  endtask

  // ------------------------------------------------------------ flows
  // host -> buffer (H2B, G1) -> V1 + crypt + ECC (ENC) -> NAND PROGRAM via FlashLink
  task automatic write_page(input logic [31:0] lba, input int blk, input int pg, input logic [7:0] ver,
                            input logic crypt, input logic [3:0] exp_nc);
    logic [7:0] ds, ps, st;
    logic [31:0] ha, r;
    alloc_d(ds); alloc_p(ps);
    ha = halloc(PAGE_LBS);
    host_fill(ha, lba, PAGE_LBS, ver);
    run_desc(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, ds, 8'd0, 4'd0, 4'(PAGE_LBS), ha, lba, st);
    chk(st == `SFSB_ST_OK, "H2B");
    run_desc(`SFSB_OP_ENC, `SFSB_CLS_HOST, crypt, ds, ps, 4'd0, 4'(PAGE_LBS), 32'd0, 32'd0, st);
    chk(st == `SFSB_ST_OK, "ENC (V1 verified, page assembled)");
    scmd_ok(`SFSB_SC_P2NAND, ps);
    nc_op(NC_PG, blk, pg, 0, PIMG_BYTES, ps_addr(ps), 400000);
    chk(r_st == exp_nc, "NAND PROGRAM completion status");
    scmd_ok(`SFSB_SC_P2FW, ps);
    if (r_st == NC_OK) begin
      scmd_ok(`SFSB_SC_COMMIT_D, ds);       // durable only now
      scmd_ok(`SFSB_SC_FREE_D, ds);
      for (int k = 0; k < PAGE_LBS; k++) gold_ver[(lba + 32'(k)) % 1024] = ver;
    end else begin
      csr_rd(`SFSB_CSR_STATUS, r);
      chk(r[23:16] != 8'd0 && plp_dirty, "failed program: data stays DIRTY (not durable)");
      scmd(`SFSB_SC_FREE_D, ds, 1'b0, r);
      chk(r[7:0] == `SFSB_SR_DIRTY, "failed program: slot cannot be freed without DISCARD");
      // firmware retries in a good block, then commits
      run_desc(`SFSB_OP_ENC, `SFSB_CLS_HOST, crypt, ds, ps, 4'd0, 4'(PAGE_LBS), 32'd0, 32'd0, st);
      scmd_ok(`SFSB_SC_P2NAND, ps);
      nc_op(NC_PG, 2, 2, 0, PIMG_BYTES, ps_addr(ps), 400000);
      chk(r_st == NC_OK, "retry PROGRAM in a good block");
      scmd_ok(`SFSB_SC_P2FW, ps);
      scmd_ok(`SFSB_SC_COMMIT_D, ds);
      scmd_ok(`SFSB_SC_FREE_D, ds);
      for (int k = 0; k < PAGE_LBS; k++) gold_ver[(lba + 32'(k)) % 1024] = ver;
    end
    scmd_ok(`SFSB_SC_FREE_P, ps);
  endtask

  // NAND READ_PAGE via FlashLink -> ECC + crypt + V2 (DEC) -> buffer -> host (B2H, V3)
  task automatic read_page(input logic [31:0] lba, input int blk, input int pg, input int lbf, input int n,
                           input logic crypt, output logic [7:0] dst, output logic [31:0] ha);
    logic [7:0] ds, ps, st;
    alloc_d(ds); alloc_p(ps);
    scmd_ok(`SFSB_SC_P2NAND, ps);
    nc_op(NC_RD, blk, pg, 0, PIMG_BYTES, ps_addr(ps), 200000);
    chk(r_st == NC_OK, "NAND READ_PAGE completion status");
    scmd_ok(`SFSB_SC_P2FW, ps);
    run_desc(`SFSB_OP_DEC, `SFSB_CLS_HOST, crypt, ds, ps, 4'(lbf), 4'(n), 32'd0, lba, dst);
    ha = halloc(n);
    host_clear(ha, n);
    if (dst == `SFSB_ST_OK || dst == `SFSB_ST_CORRECTED) begin
      run_desc(`SFSB_OP_B2H, `SFSB_CLS_HOST, 1'b0, ds, 8'd0, 4'(lbf), 4'(n), ha, 32'd0, st);
      chk(st == `SFSB_ST_OK, "B2H (V3 verified)");
    end
    scmd_ok(`SFSB_SC_FREE_D, ds);
    scmd_ok(`SFSB_SC_FREE_P, ps);
  endtask

  // ======================================================================
  logic [7:0]  st, dst;
  logic [31:0] ha, v;
  logic [7:0]  ps0;
  int          t0, t1;
  logic        dod_ran = 1'b0;
  initial begin
    for (int i = 0; i < 1024; i++) gold_ver[i] = 8'd0;
    for (int t = 0; t < 256; t++) begin outst[t] = 1'b0; done[t] = 1'b0; nc_got[t] = 1'b0; end
    $display("tb_sfsb_nand: buffer LB=%0d x %0d, page image %0d B; NANDLab page %0d+%0d B",
             LB_BYTES, PAGE_LBS, PIMG_BYTES, PD, PSP);
    repeat (5) @(posedge clk); #1;
    rst_n = 1'b1;
    while (!init_done) cyc(1);
    cyc(2);
    set_cfg(1'b1, 1'b0, 8'd4, 8'd1);
    csr_wr(`SFSB_CSR_KEY_LO, 32'h1357_9BDF); csr_wr(`SFSB_CSR_KEY_HI, 32'h2468_ACE0);

    if (!$test$plusargs("DRAM_ONLY")) begin : nand_part
    // ---- bring up the NAND channel: RESET, parameter page (into a NAND-owned page slot), geometry
    cur_test = "nand-init";
    alloc_p(ps0);
    scmd_ok(`SFSB_SC_P2NAND, ps0);
    nc_op(NC_RST, 0, 0, 0, 0, 32'd0, 200000);
    chk(r_st == NC_OK, "NAND RESET");
    nc_op(NC_RPRM, 0, 0, 0, 256, ps_addr(ps0), 200000);
    chk(r_st == NC_OK, "ONFI parameter page read (CRC-16 checked by FlashLink) into the page buffer");
    nc_csr_rd(8'h28, v);
    chk(v == {16'(PSP), 16'(PD)}, "geometry loaded from the parameter page: 512 + 128 bytes");
    nc_csr_rd(8'h0C, v);
    nc_csr_wr(8'h0C, v | 32'h2);                             // CTRL.WP_N = 1: allow program / erase
    nc_op(NC_ER, 2, 0, 0, 0, 32'd0, 400000);
    chk(r_st == NC_OK, "ERASE block 2");
    nc_op(NC_ER, 3, 0, 0, 0, 32'd0, 400000);
    chk(r_st == NC_OK, "ERASE block 3");
    scmd_ok(`SFSB_SC_P2FW, ps0);
    scmd_ok(`SFSB_SC_FREE_P, ps0);

    // ---- DoD: memory -> NAND -> memory
    cur_test = "dod";
    t0 = $time;
    write_page(32'd0, 2, 0, 8'd1, 1'b0, NC_OK);
    // the NAND array holds the page image: systematic data + OOB {LBA, CRC32C}
    begin
      logic [63:0] w;
      int bad;
      bad = 0;
      for (int k = 0; k < PAGE_LBS; k++) begin
        w = '0;
        for (int b = 0; b < 8; b++) w[8*b +: 8] = u_dev.u_model.bd_peek(0, 2, 0, (OOB + k) * 8 + b);
        if (w[31:0] != 32'(k) || w[63:32] != lb_crc(32'(k), 8'd1)) bad++;
        w = '0;
        for (int b = 0; b < 8; b++) w[8*b +: 8] = u_dev.u_model.bd_peek(0, 2, 0, (k * CWB) * 8 + b);
        if (w != pat(32'(k), 0, 8'd1)) bad++;
      end
      chk(bad == 0, "NAND array: codeword data + OOB {LBA, CRC32C} as generated at host ingress");
    end
    read_page(32'd0, 2, 0, 0, PAGE_LBS, 1'b0, dst, ha);
    t1 = $time;
    chk(dst == `SFSB_ST_OK, "DoD: DEC status OK (ECC + CRC + LBA verified)");
    dod_ran = 1'b1;
    host_check(ha, 32'd0, PAGE_LBS, "dod");
    $display("tb_sfsb_nand: DoD round trip (host->buffer->ECC->NAND->ECC->buffer->host) in %0d cycles", (t1 - t0) / 10);

    // ---- crypt page, then medium errors: correctable and uncorrectable
    cur_test = "nand-errors";
    $display("[%0t] section nand-errors", $time);
    write_page(32'd4, 2, 1, 8'd2, 1'b1, NC_OK);
    nand_flip(2, 1, (0 * CWB + 3) * 8 + 2, 5);              // codeword 0, data beat 3
    nand_flip(2, 1, (2 * CWB + LB_BEATS) * 8 + 1, 0);       // codeword 2, a check byte
    nand_flip(2, 1, (OOB + 1) * 8 + 6, 3);                  // OOB metadata of block 1
    read_page(32'd4, 2, 1, 0, PAGE_LBS, 1'b1, dst, ha);
    chk(dst == `SFSB_ST_CORRECTED, "3 single-bit medium errors -> CORRECTED");
    host_check(ha, 32'd4, PAGE_LBS, "corrected");
    nand_flip(2, 1, (3 * CWB + 5) * 8 + 0, 0);              // second bit in codeword 3 beat 5
    nand_flip(2, 1, (3 * CWB + 5) * 8 + 4, 7);
    read_page(32'd4, 2, 1, 0, PAGE_LBS, 1'b1, dst, ha);
    chk(dst == `SFSB_ST_UNCORR, "double-bit medium error -> UNCORR (detected, poisoned)");
    chk(c_w0[last_tid][31:24] == 8'h08, "failed codeword reported (block 3)");
    read_page(32'd4, 2, 1, 0, 3, 1'b1, dst, ha);
    chk(dst == `SFSB_ST_CORRECTED, "codeword-granular partial read of the good blocks");
    host_check(ha, 32'd4, 3, "partial after UE");
    // erased page through the real controller
    read_page(32'd0, 2, 5, 0, PAGE_LBS, 1'b0, dst, ha);
    chk(dst == `SFSB_ST_ERASED, "never-programmed page -> ERASED");

    // ---- NAND program failure (NANDLab force_prog_fail lun0 blk3 pg0): durability is not claimed
    cur_test = "prog-fail";
    $display("[%0t] section prog-fail", $time);
    write_page(32'd8, 3, 0, 8'd3, 1'b0, NC_DEVF);
    read_page(32'd8, 2, 2, 0, PAGE_LBS, 1'b0, dst, ha);
    chk(dst == `SFSB_ST_OK, "data re-programmed after the failure reads back");
    host_check(ha, 32'd8, PAGE_LBS, "after program failure");

    end
    // ---- metadata through the real MemoryBridge (P24)
    cur_test = "dram";
    $display("[%0t] section dram", $time);
    begin
      int g;
      g = 0;
      while (!st_ready && g < 20000) begin cyc(1); g++; end
      chk(st_ready, "MemoryBridge reports ready (sim controller calibrated)");
      $display("    bridge state %0d ready %0d after %0d cycles", st_state, st_ready, g);
    end
    if ($test$plusargs("XM_TRACE")) xm_trace = 300;
    for (int i = 0; i < 32; i++) begin
      logic [31:0] d; logic e;
      fw_acc(1'b1, 32'h0080_0000 + 32'(4 * i), 32'hB000_0000 + 32'(i * 7), 4'hF, d, e);
      chk(!e, "metadata write through MemoryBridge");
    end
    for (int pass = 0; pass < 2; pass++)
      for (int i = 0; i < 32; i++) begin
        logic [31:0] d; logic e;
        fw_acc(1'b0, 32'h0080_0000 + 32'(4 * i), 32'd0, 4'h0, d, e);
        chk(!e && d == 32'hB000_0000 + 32'(i * 7), "metadata read through cache + MemoryBridge");
      end
    csr_rd(`SFSB_CSR_PERF_BASE + 12'(4 * `SFSB_PC_MC_HIT), v);
    chk(v != 32'd0, "metadata cache hits");

    // ---- final
    cur_test = "final";
    $display("[%0t] section final", $time);
    drain_cq();
    csr_rd(`SFSB_CSR_OCC, v);  chk(v == 32'd0, "no slot leaked");
    csr_rd(`SFSB_CSR_STATUS, v); chk(v[23:16] == 8'd0, "nothing left dirty");
    for (int t = 0; t < 256; t++) chk(!outst[t], "every accepted descriptor completed exactly once");
    cyc(20);
    chk(u_dev.u_model.n_proto_errors == 0, "NANDLab: zero protocol errors");
    chk(u_dev.u_model.n_timing_violations == 0, "NANDLab: zero AC-timing violations");
    chk(u_mon.n_viol == 0, "independent ONFI pin monitor: zero violations");
    chk(v_fw == 0 && v_nd == 0 && v_hm == 0 && v_xm == 0, "SFB2 protocol checkers: zero violations");
    chk(mc_viol == 0 && mchk_viol == 0, "MemoryBridge controller interface: zero violations (model + P24 checker)");
    chk(mc_wc > 0 && mc_rc > 0, "metadata traffic reached the simulated DRAM controller");
    $display("tb_sfsb_nand: NANDLab reads %0d programs %0d erases %0d; monitor checks %0d; descriptors %0d",
             u_dev.u_model.n_reads, u_dev.u_model.n_programs, u_dev.u_model.n_erases, u_mon.n_checks, n_acc);
    $display("tb_sfsb_nand: DRAM controller commands rd %0d wr %0d", mc_rc, mc_wc);
    if (n_err == 0) begin
      if (dod_ran) $display("TB DoD: memory->NAND and NAND->memory transfers with end-to-end integrity checking -- MET");
      $display("TB RESULT: PASS (%0d checks)", n_chk);
    end else begin
      $display("TB RESULT: FAIL (%0d of %0d checks failed)", n_err, n_chk);
    end
    $finish;
  end

  initial begin
    #500ms;
    $display("TB RESULT: FAIL (global timeout)");
    $finish;
  end
endmodule

`default_nettype wire
