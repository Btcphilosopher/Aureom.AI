// =============================================================================
// SilicaFlux BufferCore (Project 55) :: tb_sfsb   (VERIFICATION ONLY)
// Self-checking subsystem testbench for silicaflux_storage_buffer.
//
//   firmware BFM  -> fw port   (CSR / BUF / DRAM windows, tasks below)
//   NAND BFM      -> nand port (models a NAND channel controller moving raw page
//                               images between a flash array and the page slots,
//                               with bit-error injection and random stalls)
//   sfsb_tb_mem   <- host port (host memory: random back-pressure / latency /
//                               error window, per-word write counters)
//   sfsb_tb_mem   <- DRAM port (EXT_DRAM_EN configurations)
//   sfb_protocol_checker (DataFabric, unmodified) on all four SFB2 interfaces
//
// Golden model: every logical block's content is a pure function of
// (LBA, beat, version); gold_ver[] tracks the newest version written.  The
// testbench has its own CRC-32C, so the integrity values the DUT stores are
// checked independently.  Every accepted descriptor must complete exactly once
// (outst[] / done[] per TID); host write counters prove no beat was written
// twice or skipped.
//
// +TEST=<name> selects one test (default: all).  +SEED=<n>.
// =============================================================================
`timescale 1ns/1ps
`include "sfsb_defs.svh"
`default_nettype none

module tb_sfsb;
  // ------------------------------------------------------------ configuration
  parameter int NUM_BANKS    = 4;
  parameter int LB_BYTES     = 512;
  parameter int PAGE_LBS     = 4;
  parameter int NUM_DSLOTS   = 8;
  parameter int NUM_PSLOTS   = 4;
  parameter int DQ_DEPTH     = 4;
  parameter int CQ_DEPTH     = 8;
  parameter int HOST_MAX_OUT = 1;
  parameter int ENG_FIFO     = 8;
  parameter int AGE_LIMIT    = 16;
  parameter int CRYPTO_EN    = 1;
  parameter int EXT_DRAM_EN  = 0;
  parameter int PLP_PRESENT  = 0;

  localparam int LB_BEATS    = LB_BYTES / 8;
  localparam int PAR_BEATS   = LB_BEATS / 8;
  localparam int CWB         = LB_BEATS + PAR_BEATS;
  localparam int DSLOT_BEATS = PAGE_LBS * LB_BEATS;
  localparam int PIMG_BEATS  = PAGE_LBS * CWB + PAGE_LBS + 1;
  localparam int PSLOT_BEATS = ((PIMG_BEATS + NUM_BANKS - 1) / NUM_BANKS) * NUM_BANKS;
  localparam int PS_BASE     = NUM_DSLOTS * DSLOT_BEATS;
  localparam int NP          = 8;
  localparam int OOB         = PAGE_LBS * CWB;
  localparam int HWORDS      = 32768;               // 256 KiB host memory
  localparam int NPAGES      = 64;
  localparam logic [31:0] DRAM_BASE = 32'h8000_0000;

  // ------------------------------------------------------------ clock / reset
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  // ------------------------------------------------------------ DUT
  logic        fw_req_valid = 0, fw_req_ready, fw_req_write = 0, fw_rsp_valid, fw_rsp_error;
  logic [31:0] fw_req_addr = 0, fw_req_wdata = 0, fw_rsp_rdata;
  logic [3:0]  fw_req_wstrb = 0;
  logic        nd_req_valid = 0, nd_req_ready, nd_req_write = 0, nd_rsp_valid, nd_rsp_error;
  logic [31:0] nd_req_addr = 0;
  logic [63:0] nd_req_wdata = 0, nd_rsp_rdata;
  logic [7:0]  nd_req_wstrb = 8'hFF;
  logic        hm_req_valid, hm_req_ready, hm_req_write, hm_rsp_valid, hm_rsp_ready, hm_rsp_error;
  logic [31:0] hm_req_addr;
  logic [63:0] hm_req_wdata, hm_rsp_rdata;
  logic [7:0]  hm_req_wstrb;
  logic        xm_req_valid, xm_req_ready, xm_req_write, xm_rsp_valid, xm_rsp_ready, xm_rsp_error;
  logic [31:0] xm_req_addr;
  logic [63:0] xm_req_wdata, xm_rsp_rdata;
  logic [7:0]  xm_req_wstrb;
  logic        pwr_fail = 0, irq, busy, init_done, plp_dirty;

  silicaflux_storage_buffer #(
    .NUM_BANKS(NUM_BANKS), .LB_BYTES(LB_BYTES), .PAGE_LBS(PAGE_LBS), .NUM_DSLOTS(NUM_DSLOTS),
    .NUM_PSLOTS(NUM_PSLOTS), .DQ_DEPTH(DQ_DEPTH), .CQ_DEPTH(CQ_DEPTH), .HOST_MAX_OUT(HOST_MAX_OUT), .ENG_FIFO(ENG_FIFO),
    .AGE_LIMIT(AGE_LIMIT), .CRYPTO_EN(CRYPTO_EN), .EXT_DRAM_EN(EXT_DRAM_EN), .DRAM_BASE(DRAM_BASE),
    .PLP_PRESENT(PLP_PRESENT)
  ) dut (
    .clk, .rst_n,
    .fw_req_valid, .fw_req_ready, .fw_req_write, .fw_req_addr, .fw_req_wdata, .fw_req_wstrb,
    .fw_rsp_valid, .fw_rsp_ready(1'b1), .fw_rsp_rdata, .fw_rsp_error,
    .nd_req_valid, .nd_req_ready, .nd_req_write, .nd_req_addr, .nd_req_wdata, .nd_req_wstrb,
    .nd_rsp_valid, .nd_rsp_ready(1'b1), .nd_rsp_rdata, .nd_rsp_error,
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error,
    .xm_req_valid, .xm_req_ready, .xm_req_write, .xm_req_addr, .xm_req_wdata, .xm_req_wstrb,
    .xm_rsp_valid, .xm_rsp_ready, .xm_rsp_rdata, .xm_rsp_error,
    .pwr_fail_i(pwr_fail), .irq, .busy, .init_done, .plp_dirty
  );

  sfsb_tb_mem #(.WORDS(HWORDS), .BASE(32'h0), .MAX_OUT(32)) u_hm (
    .clk, .rst_n,
    .req_valid(hm_req_valid), .req_ready(hm_req_ready), .req_write(hm_req_write), .req_addr(hm_req_addr),
    .req_wdata(hm_req_wdata), .req_wstrb(hm_req_wstrb), .rsp_valid(hm_rsp_valid), .rsp_ready(hm_rsp_ready),
    .rsp_rdata(hm_rsp_rdata), .rsp_error(hm_rsp_error)
  );

  sfsb_tb_mem #(.WORDS(4096), .BASE(DRAM_BASE), .MAX_OUT(1)) u_xm (
    .clk, .rst_n,
    .req_valid(xm_req_valid), .req_ready(xm_req_ready), .req_write(xm_req_write), .req_addr(xm_req_addr),
    .req_wdata(xm_req_wdata), .req_wstrb(xm_req_wstrb), .rsp_valid(xm_rsp_valid), .rsp_ready(xm_rsp_ready),
    .rsp_rdata(xm_rsp_rdata), .rsp_error(xm_rsp_error)
  );

  // SFB2 protocol checkers (DataFabric, unmodified)
  logic [31:0] v_fw, v_nd, v_hm, v_xm;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] nq0, nr0, no0, nq1, nr1, no1, nq2, nr2, no2, nq3, nr3, no3;
  /* verilator lint_on UNUSEDSIGNAL */
  sfb_protocol_checker #(.AW(32), .DW(32), .MAX_OUT(1), .NAME("fw")) u_chk_fw (
    .clk, .rst_n, .req_valid(fw_req_valid), .req_ready(fw_req_ready), .req_write(fw_req_write),
    .req_addr(fw_req_addr), .req_wdata(fw_req_wdata), .req_wstrb(fw_req_wstrb), .rsp_valid(fw_rsp_valid),
    .rsp_ready(1'b1), .rsp_rdata(fw_rsp_rdata), .rsp_error(fw_rsp_error),
    .violations(v_fw), .n_req(nq0), .n_rsp(nr0), .outstanding(no0));
  sfb_protocol_checker #(.AW(32), .DW(64), .MAX_OUT(1), .NAME("nand")) u_chk_nd (
    .clk, .rst_n, .req_valid(nd_req_valid), .req_ready(nd_req_ready), .req_write(nd_req_write),
    .req_addr(nd_req_addr), .req_wdata(nd_req_wdata), .req_wstrb(nd_req_wstrb), .rsp_valid(nd_rsp_valid),
    .rsp_ready(1'b1), .rsp_rdata(nd_rsp_rdata), .rsp_error(nd_rsp_error),
    .violations(v_nd), .n_req(nq1), .n_rsp(nr1), .outstanding(no1));
  sfb_protocol_checker #(.AW(32), .DW(64), .MAX_OUT(HOST_MAX_OUT), .NAME("host")) u_chk_hm (
    .clk, .rst_n, .req_valid(hm_req_valid), .req_ready(hm_req_ready), .req_write(hm_req_write),
    .req_addr(hm_req_addr), .req_wdata(hm_req_wdata), .req_wstrb(hm_req_wstrb), .rsp_valid(hm_rsp_valid),
    .rsp_ready(hm_rsp_ready), .rsp_rdata(hm_rsp_rdata), .rsp_error(hm_rsp_error),
    .violations(v_hm), .n_req(nq2), .n_rsp(nr2), .outstanding(no2));
  sfb_protocol_checker #(.AW(32), .DW(64), .MAX_OUT(1), .NAME("dram")) u_chk_xm (
    .clk, .rst_n, .req_valid(xm_req_valid), .req_ready(xm_req_ready), .req_write(xm_req_write),
    .req_addr(xm_req_addr), .req_wdata(xm_req_wdata), .req_wstrb(xm_req_wstrb), .rsp_valid(xm_rsp_valid),
    .rsp_ready(xm_rsp_ready), .rsp_rdata(xm_rsp_rdata), .rsp_error(xm_rsp_error),
    .violations(v_xm), .n_req(nq3), .n_rsp(nr3), .outstanding(no3));

  // ------------------------------------------------------------ scoreboard state
  int n_chk = 0, n_err = 0;
  logic       outst [256];
  logic       done  [256];
  logic [31:0] c_w0 [256];
  logic [31:0] c_w1 [256];
  logic [31:0] c_w2 [256];
  int          n_acc = 0, n_cpl = 0;
  logic [7:0]  order [512];
  int          n_order = 0;
  logic [7:0]  gold_ver [1024];
  logic [63:0] flash [NPAGES * PIMG_BEATS];
  int          inj_n = 0;
  int          inj_beat [64];
  int          inj_bit  [64];
  int          nd_stall_pct = 0;
  int          nd_err_cnt = 0;
  logic [7:0]  tid_next = 8'd1;
  logic [31:0] h_next = 32'h0;
  logic [8*24-1:0] cur_test = "init";
  logic [7:0]  g_ds   [32];            // scratch slot / TID lists (module scope: Icarus 12
  logic [7:0]  g_ps   [32];            //  cannot pass elements of automatic arrays as task outputs)
  logic [7:0]  g_tid  [32];
  logic [31:0] g_ha   [8];
  logic [7:0]  tmp8;                   // task-output temporary (see g_ds)
  logic [7:0]  last_tid = 8'd0;        // TID of the last run_desc
  logic [7:0]  last_dec_tid = 8'd0;    // TID of the DEC of the last flow_read

  function automatic [31:0] ps_addr(input int ps);
    ps_addr = 32'((PS_BASE + ps * PSLOT_BEATS) * 8);
  endfunction
  function automatic int ds_word(input int ds, input int lb, input int beat);
    ds_word = ds * DSLOT_BEATS + lb * LB_BEATS + beat;
  endfunction
  function automatic int ps_word(input int ps, input int off);
    ps_word = PS_BASE + ps * PSLOT_BEATS + off;
  endfunction

  `include "sfsb_tb_common.svh"

  // ------------------------------------------------------------ NAND-controller BFM
  logic        ndq_wr, ndq_er;
  logic [31:0] ndq_a;
  logic [63:0] ndq_wd, ndq_rd;
  int          ndq_req = 0, ndq_ack = 0;

  task automatic nd_acc(input logic wr, input logic [31:0] a, input logic [63:0] wd,
                        output logic [63:0] rd, output logic er);
    ndq_wr = wr; ndq_a = a; ndq_wd = wd;
    ndq_req = ndq_req + 1;
    wait (ndq_ack == ndq_req);
    rd = ndq_rd;
    er = ndq_er;
  endtask

  initial begin : nd_server
    forever begin
      wait (ndq_req != ndq_ack);
      nd_req_valid = 1'b1; nd_req_write = ndq_wr; nd_req_addr = ndq_a; nd_req_wdata = ndq_wd; nd_req_wstrb = 8'hFF;
      #1;
      while (!nd_req_ready && rst_n) begin @(posedge clk); #2; end
      @(posedge clk); #1;
      nd_req_valid = 1'b0;
      #1;
      while (!nd_rsp_valid && rst_n) begin @(posedge clk); #2; end
      ndq_rd = nd_rsp_rdata;
      ndq_er = nd_rsp_error;
      @(posedge clk); #1;
      ndq_ack = ndq_req;
    end
  end

  // PROGRAM: page image of page slot ps -> flash page
  task automatic nand_program(input int ps, input int page);
    logic [63:0] d; logic e;
    for (int i = 0; i < PIMG_BEATS; i++) begin
      nd_acc(1'b0, ps_addr(ps) + 32'(8 * i), 64'd0, d, e);
      if (e) nd_err_cnt++;
      flash[page * PIMG_BEATS + i] = d;
      if (nd_stall_pct != 0 && $urandom_range(99, 0) < nd_stall_pct) cyc($urandom_range(6, 1));
    end
  endtask

  // READ_PAGE: flash page (+ injected bit errors) -> page slot ps
  task automatic nand_read(input int page, input int ps);
    logic [63:0] d, r; logic e;
    for (int i = 0; i < PIMG_BEATS; i++) begin
      d = flash[page * PIMG_BEATS + i];
      for (int k = 0; k < inj_n; k++) if (inj_beat[k] == i) d[inj_bit[k]] = ~d[inj_bit[k]];
      nd_acc(1'b1, ps_addr(ps) + 32'(8 * i), d, r, e);
      if (e) nd_err_cnt++;
      if (nd_stall_pct != 0 && $urandom_range(99, 0) < nd_stall_pct) cyc($urandom_range(6, 1));
    end
    inj_n = 0;
  endtask

  task automatic inject(input int beat, input int bitpos);
    inj_beat[inj_n] = beat;
    inj_bit[inj_n]  = bitpos;
    inj_n++;
  endtask

  function automatic int cw_data(input int lb, input int beat);   // page-image word of data beat
    cw_data = lb * CWB + beat;
  endfunction

  // ------------------------------------------------------------ composite flows
  // host -> buffer -> ECC -> NAND page
  task automatic flow_write(input logic [31:0] lba, input int n, input int page, input logic [7:0] ver,
                            input logic crypt);
    logic [7:0] ds, ps, st;
    logic [31:0] ha;
    alloc_d(ds); alloc_p(ps);
    ha = halloc(n);
    host_fill(ha, lba, n, ver);
    run_desc(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, ds, 8'd0, 4'd0, 4'(n), ha, lba, st);
    chk(st == `SFSB_ST_OK, "H2B status");
    run_desc(`SFSB_OP_ENC, `SFSB_CLS_HOST, crypt, ds, ps, 4'd0, 4'(n), 32'd0, 32'd0, st);
    chk(st == `SFSB_ST_OK, "ENC status");
    scmd_ok(`SFSB_SC_P2NAND, ps);
    nand_program(32'(ps), page);
    scmd_ok(`SFSB_SC_P2FW, ps);
    scmd_ok(`SFSB_SC_COMMIT_D, ds);
    scmd_ok(`SFSB_SC_FREE_D, ds);
    scmd_ok(`SFSB_SC_FREE_P, ps);
    for (int k = 0; k < n; k++) gold_ver[(lba + 32'(k)) % 1024] = ver;
  endtask

  // NAND page -> ECC -> buffer -> host; returns the DEC status
  task automatic flow_read(input logic [31:0] lba, input int lbf, input int n, input int page, input logic crypt,
                           output logic [7:0] dst, output logic [31:0] ha);
    logic [7:0] ds, ps, st;
    alloc_d(ds); alloc_p(ps);
    scmd_ok(`SFSB_SC_P2NAND, ps);
    nand_read(page, 32'(ps));
    scmd_ok(`SFSB_SC_P2FW, ps);
    run_desc(`SFSB_OP_DEC, `SFSB_CLS_HOST, crypt, ds, ps, 4'(lbf), 4'(n), 32'd0, lba, dst);
    last_dec_tid = last_tid;
    ha = halloc(n);
    host_clear(ha, n);
    if (dst == `SFSB_ST_OK || dst == `SFSB_ST_CORRECTED) begin
      run_desc(`SFSB_OP_B2H, `SFSB_CLS_HOST, 1'b0, ds, 8'd0, 4'(lbf), 4'(n), ha, 32'd0, st);
      chk(st == `SFSB_ST_OK, "B2H status");
    end
    scmd_ok(`SFSB_SC_FREE_D, ds);
    scmd_ok(`SFSB_SC_FREE_P, ps);
  endtask

  task automatic fi_arm_word(input int wa, input logic [71:0] mask);
    csr_wr(`SFSB_CSR_FI_ROW, 32'(wa / NUM_BANKS));
    csr_wr(`SFSB_CSR_FI_MASK0, mask[31:0]);
    csr_wr(`SFSB_CSR_FI_MASK1, mask[63:32]);
    csr_wr(`SFSB_CSR_FI_MASK2, {24'd0, mask[71:64]});
    csr_wr(`SFSB_CSR_FI_CTRL, {16'd0, 8'(wa % NUM_BANKS), 7'd0, 1'b1});
  endtask

  task automatic expect_quiet();
    logic [31:0] v;
    drain_cq();
    csr_rd(`SFSB_CSR_CPL_STAT, v);
    chk(v[0] == 1'b0, "completion queue not empty after drain");
    for (int t = 0; t < 256; t++) if (outst[t]) begin
      chk(1'b0, "accepted descriptor never completed (dropped)");
      $display("    tid %0d", t);
      outst[t] = 1'b0;
    end
    csr_rd(`SFSB_CSR_OCC, v);
    chk(v == 32'd0, "no buffer slot leaked at the end of the test");
    if (v != 32'd0) $display("    OCC = %08h", v);
    csr_rd(`SFSB_CSR_STATUS, v);
    chk(v[23:16] == 8'd0 && v[2] == 1'b0, "no dirty slot, subsystem idle at the end of the test");
  endtask


  task automatic do_reset(input int cycles);
    rst_n = 1'b0;
    fw_req_valid = 1'b0;
    nd_req_valid = 1'b0;
    cyc(cycles);
    rst_n = 1'b1;
    for (int t = 0; t < 256; t++) begin outst[t] = 1'b0; done[t] = 1'b0; end
    while (!init_done) cyc(1);
    cyc(2);
    set_cfg(1'b1, 1'b0, 8'd4, 8'd1);
  endtask

  // ------------------------------------------------------------ arbitration monitor
  int wait_now [NP];
  int wait_max [NP];
  int multi_active = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      for (int p = 0; p < NP; p++) begin wait_now[p] <= 0; end
    end else begin
      for (int p = 0; p < NP; p++) begin
        if (dut.p_req_valid[p] && !dut.p_req_ready[p] && init_done) begin
          wait_now[p] <= wait_now[p] + 1;
          if (wait_now[p] + 1 > wait_max[p]) wait_max[p] <= wait_now[p] + 1;
        end else begin
          wait_now[p] <= 0;
        end
      end
      if (32'(dut.h2b_active) + 32'(dut.b2h_active) + 32'(dut.enc_active) + 32'(dut.dec_active) >= 3)
        multi_active <= multi_active + 1;
    end
  end
  initial for (int p = 0; p < NP; p++) wait_max[p] = 0;

  // ------------------------------------------------------------ commit-before-completion monitor
  // Requirement: a DMA completion may be reported only after the destination
  // holds the data according to its interface contract.  At the cycle each
  // engine's completion enters the CQ, every destination write of that
  // descriptor must have been issued AND acknowledged (SRAM write ack, or the
  // host's SFB2 write response for B2H), and the number of writes must be the
  // full transfer length.  Checked on every completion of every test.
  int cm_acc [4];
  int cm_ack [4];
  int cm_bad = 0, cm_cpl = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      for (int e = 0; e < 4; e++) begin cm_acc[e] = 0; cm_ack[e] = 0; end
    end else begin
      // ---- checks (counter values = events before this edge)
      if (dut.cpl_valid[0] && dut.cpl_ready[0]) begin
        cm_cpl++;
        if (cm_acc[0] != cm_ack[0] || cm_acc[0] != int'(dut.u_h2b.tot)) begin
          cm_bad++; $display("[%0t] ERROR (commit monitor): H2B completed with %0d/%0d writes acked of %0d", $time, cm_ack[0], cm_acc[0], dut.u_h2b.tot);
        end
      end
      if (dut.cpl_valid[1] && dut.cpl_ready[1]) begin
        cm_cpl++;
        if (cm_acc[1] != cm_ack[1] || cm_acc[1] != int'(dut.u_b2h.tot)) begin
          cm_bad++; $display("[%0t] ERROR (commit monitor): B2H completed with %0d/%0d host writes acked of %0d", $time, cm_ack[1], cm_acc[1], dut.u_b2h.tot);
        end
      end
      if (dut.cpl_valid[2] && dut.cpl_ready[2]) begin
        cm_cpl++;
        if (cm_acc[2] != cm_ack[2] || cm_acc[2] != int'(dut.u_enc.d[39:36]) * (CWB + 2)) begin
          cm_bad++; $display("[%0t] ERROR (commit monitor): ENC completed with %0d/%0d page writes acked", $time, cm_ack[2], cm_acc[2]);
        end
      end
      if (dut.cpl_valid[3] && dut.cpl_ready[3]) begin
        cm_cpl++;
        if (cm_acc[3] != cm_ack[3] || cm_acc[3] != int'(dut.u_dec.d[39:36]) * LB_BEATS) begin
          cm_bad++; $display("[%0t] ERROR (commit monitor): DEC completed with %0d/%0d slot writes acked", $time, cm_ack[3], cm_acc[3]);
        end
      end
      // ---- updates
      if (dut.u_h2b.desc_take) begin cm_acc[0] = 0; cm_ack[0] = 0; end
      if (dut.u_b2h.desc_take) begin cm_acc[1] = 0; cm_ack[1] = 0; end
      if (dut.u_enc.desc_take) begin cm_acc[2] = 0; cm_ack[2] = 0; end
      if (dut.u_dec.desc_take) begin cm_acc[3] = 0; cm_ack[3] = 0; end
      if (dut.p_req_valid[2] && dut.p_req_ready[2]) cm_acc[0]++;
      if (dut.p_rsp_valid[2])                       cm_ack[0]++;
      if (dut.h_e1_valid && dut.h_e1_ready)         cm_acc[1]++;
      if (dut.h_e1_rsp_valid)                       cm_ack[1]++;
      if (dut.p_req_valid[5] && dut.p_req_ready[5]) cm_acc[2]++;
      if (dut.p_rsp_valid[5])                       cm_ack[2]++;
      if (dut.p_req_valid[7] && dut.p_req_ready[7]) cm_acc[3]++;
      if (dut.p_rsp_valid[7])                       cm_ack[3]++;
    end
  end

  // ======================================================================
  //                                  TESTS
  // ======================================================================
  task automatic t_regs();
    logic [31:0] v, d; logic e;
    cur_test = "regs";
    csr_rd(`SFSB_CSR_ID, v);       chk(v == 32'h5346_5342, "ID register");
    csr_rd(`SFSB_CSR_VERSION, v);  chk(v[31:24] == 8'd55, "VERSION project number");
    csr_rd(`SFSB_CSR_PARAM0, v);
    chk(v[7:0] == 8'(NUM_DSLOTS) && v[15:8] == 8'(NUM_PSLOTS) && v[23:20] == 4'(PAGE_LBS), "PARAM0 geometry");
    csr_rd(`SFSB_CSR_PARAM1, v);   chk(v[31:16] == 16'(PIMG_BEATS) && v[15:0] == 16'(PSLOT_BEATS), "PARAM1 page image");
    csr_rd(`SFSB_CSR_PARAM2, v);   chk(v == 32'(PS_BASE * 8), "PARAM2 page-slot base");
    csr_rd(`SFSB_CSR_STATUS, v);   chk(v[0] == 1'b1, "STATUS.init_done");
    // CRC-32C reference value of the TB function ("123456789" = E3069283)
    begin
      logic [31:0] c;
      c = crc32c_beat(32'hFFFF_FFFF, 64'h3837_3635_3433_3231);     // "12345678"
      c = c ^ 32'h39;                                              // "9"
      for (int j = 0; j < 8; j++) c = c[0] ? ((c >> 1) ^ 32'h82F6_3B78) : (c >> 1);
      chk(~c == 32'hE306_9283, "TB CRC-32C check value (\"123456789\" = E3069283)");
    end
    // error responses: unmapped CSR, sub-word CSR write, DRAM window without DRAM, misaligned
    fw_acc(1'b0, 32'h0000_0FF0, 32'd0, 4'h0, d, e);  chk(e, "unmapped CSR -> error");
    fw_acc(1'b1, {20'd0, `SFSB_CSR_CFG}, 32'd1, 4'h1, d, e); chk(e, "CSR sub-word write -> error");
    fw_acc(1'b0, 32'h0000_0002, 32'd0, 4'h0, d, e);  chk(e, "misaligned access -> error");
    fw_acc(1'b0, 32'h00F0_0000, 32'd0, 4'h0, d, e);  chk(e, "unmapped window -> error");
    if (EXT_DRAM_EN == 0) begin
      fw_acc(1'b0, 32'h0080_0000, 32'd0, 4'h0, d, e); chk(e, "DRAM window without DRAM -> error");
    end
  endtask

  // ---- DoD: complete host -> NAND -> host transfer with real integrity checking
  task automatic t_basic();
    logic [7:0] st, ds, ps;
    logic [31:0] ha, v;
    cur_test = "basic";
    flow_write(32'd0, PAGE_LBS, 0, 8'd1, 1'b0);
    // the NAND page must carry {CRC32C, LBA} of every block in its OOB area
    for (int k = 0; k < PAGE_LBS; k++) begin
      chk(flash[OOB + k][31:0] == 32'(k), "OOB LBA tag");
      chk(flash[OOB + k][63:32] == lb_crc(32'(k), 8'd1), "OOB CRC32C = independently computed CRC");
    end
    chk(flash[0] == pat(32'd0, 0, 8'd1), "codeword 0 data stored systematically");
    flow_read(32'd0, 0, PAGE_LBS, 0, 1'b0, st, ha);
    chk(st == `SFSB_ST_OK, "DEC status OK");
    host_check(ha, 32'd0, PAGE_LBS, "basic");
    // metadata after a host write holds the independently computed CRC
    alloc_d(ds);
    ha = halloc(1);
    host_fill(ha, 32'd100, 1, 8'd7);
    run_desc(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, ds, 8'd0, 4'(PAGE_LBS - 1), 4'd1, ha, 32'd100, st);
    csr_wr(`SFSB_CSR_MSEL, {20'd0, 4'(PAGE_LBS - 1), ds});
    csr_rd(`SFSB_CSR_MCRC, v);  chk(v == lb_crc(32'd100, 8'd7), "G1: metadata CRC32C");
    csr_rd(`SFSB_CSR_MLBA, v);  chk(v == 32'd100, "G1: metadata LBA");
    csr_rd(`SFSB_CSR_MFLAGS, v); chk(v[0] == 1'b1 && v[1] == 1'b0 && v[6] == 1'b1, "metadata VALID, !POISON, slot DIRTY");
    scmd_ok(`SFSB_SC_COMMIT_D, ds);
    scmd_ok(`SFSB_SC_FREE_D, ds);
    ps = 8'd0;
    expect_quiet();
  endtask

  // ---- partial pages: partial write, read-modify-write, codeword-granular read
  task automatic t_partial();
    logic [7:0] st, ds, ps, ds2;
    logic [31:0] ha;
    cur_test = "partial";
    // (a) one logical block in a page
    flow_write(32'd10, 1, 1, 8'd2, 1'b0);
    flow_read(32'd10, 0, 1, 1, 1'b0, st, ha);
    chk(st == `SFSB_ST_OK, "partial write/read status");
    host_check(ha, 32'd10, 1, "partial-a");
    if (PAGE_LBS >= 2) begin
      // (b) RMW: page 2 = LBAs 20..; host rewrites LBA 21 -> new page 3
      flow_write(32'd20, PAGE_LBS, 2, 8'd3, 1'b0);
      alloc_d(ds); alloc_p(ps);
      scmd_ok(`SFSB_SC_P2NAND, ps); nand_read(2, 32'(ps)); scmd_ok(`SFSB_SC_P2FW, ps);
      run_desc(`SFSB_OP_DEC, `SFSB_CLS_HOST, 1'b0, ds, ps, 4'd0, 4'(PAGE_LBS), 32'd0, 32'd20, st);
      chk(st == `SFSB_ST_OK, "RMW: old page read");
      ha = halloc(1);
      host_fill(ha, 32'd21, 1, 8'd9);
      run_desc(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, ds, 8'd0, 4'd1, 4'd1, ha, 32'd21, st);
      chk(st == `SFSB_ST_OK, "RMW: host merge");
      run_desc(`SFSB_OP_ENC, `SFSB_CLS_HOST, 1'b0, ds, ps, 4'd0, 4'(PAGE_LBS), 32'd0, 32'd0, st);
      chk(st == `SFSB_ST_OK, "RMW: re-encode");
      scmd_ok(`SFSB_SC_P2NAND, ps); nand_program(32'(ps), 3); scmd_ok(`SFSB_SC_P2FW, ps);
      scmd_ok(`SFSB_SC_COMMIT_D, ds); scmd_ok(`SFSB_SC_FREE_D, ds); scmd_ok(`SFSB_SC_FREE_P, ps);
      gold_ver[21] = 8'd9;
      flow_read(32'd20, 0, PAGE_LBS, 3, 1'b0, st, ha);
      chk(st == `SFSB_ST_OK, "RMW: read new page");
      host_check(ha, 32'd20, PAGE_LBS, "partial-b");
      // (c) codeword-granular read of the last block only
      flow_read(32'(20 + PAGE_LBS - 1), PAGE_LBS - 1, 1, 3, 1'b0, st, ha);
      chk(st == `SFSB_ST_OK, "partial read of one codeword");
      host_check(ha, 32'(20 + PAGE_LBS - 1), 1, "partial-c");
      // (d) a partial-page DEC must not touch the other blocks of the data slot
      alloc_d(ds2); alloc_p(ps);
      scmd_ok(`SFSB_SC_P2NAND, ps); nand_read(3, 32'(ps)); scmd_ok(`SFSB_SC_P2FW, ps);
      run_desc(`SFSB_OP_DEC, `SFSB_CLS_HOST, 1'b0, ds2, ps, 4'd1, 4'd1, 32'd0, 32'd21, st);
      chk(st == `SFSB_ST_OK, "single-block DEC");
      begin
        logic [7:0] tt, cc;
        new_tid(tt);
        submit(`SFSB_OP_B2H, `SFSB_CLS_HOST, 1'b0, tt, ds2, 8'd0, 4'd0, 4'd1, 32'h100, 32'd0, cc);
        chk(cc == `SFSB_SUB_NOT_VALID, "B2H of a block the DEC did not fill is refused (NOT_VALID)");
      end
      scmd_ok(`SFSB_SC_FREE_D, ds2); scmd_ok(`SFSB_SC_FREE_P, ps);
    end
    expect_quiet();
  endtask

  // ---- several engines + NAND traffic at once
  task automatic t_concurrent();
    logic [7:0] dsA, dsB, dsC, dsD, psP, psQ, psR, st, code;
    logic [7:0] t1, t2, t3, t4;
    logic [31:0] haA, haD;
    int mbefore;
    cur_test = "concurrent";
    flow_write(32'd40, PAGE_LBS, 4, 8'd4, 1'b0);
    // pre-fill C (LBAs 60..) and D (LBAs 70..) and page slot R with an encoded page (LBAs 80..)
    alloc_d(dsC); alloc_d(dsD); alloc_d(dsA); alloc_d(dsB);
    alloc_p(psP); alloc_p(psQ); alloc_p(psR);
    haA = halloc(PAGE_LBS); host_fill(haA, 32'd60, PAGE_LBS, 8'd5);
    run_desc(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, dsC, 8'd0, 4'd0, 4'(PAGE_LBS), haA, 32'd60, st);
    haA = halloc(PAGE_LBS); host_fill(haA, 32'd70, PAGE_LBS, 8'd5);
    run_desc(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, dsD, 8'd0, 4'd0, 4'(PAGE_LBS), haA, 32'd70, st);
    for (int k = 0; k < PAGE_LBS; k++) begin gold_ver[60 + k] = 8'd5; gold_ver[70 + k] = 8'd5; end
    haA = halloc(PAGE_LBS); host_fill(haA, 32'd80, PAGE_LBS, 8'd6);
    run_desc(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, dsA, 8'd0, 4'd0, 4'(PAGE_LBS), haA, 32'd80, st);
    run_desc(`SFSB_OP_ENC, `SFSB_CLS_HOST, 1'b0, dsA, psR, 4'd0, 4'(PAGE_LBS), 32'd0, 32'd0, st);
    scmd_ok(`SFSB_SC_COMMIT_D, dsA);
    scmd_ok(`SFSB_SC_P2NAND, psR);
    scmd_ok(`SFSB_SC_P2NAND, psQ);
    for (int k = 0; k < PAGE_LBS; k++) gold_ver[80 + k] = 8'd6;
    // page slot Q gets page 4 from NAND first
    nand_read(4, 32'(psQ));
    scmd_ok(`SFSB_SC_P2FW, psQ);
    // now launch: H2B (A <- LBAs 50..), DEC (Q -> B), ENC (C -> P), B2H (D -> host),
    // and concurrently the NAND BFM programs page slot R into page 5
    haA = halloc(PAGE_LBS); host_fill(haA, 32'd50, PAGE_LBS, 8'd8);
    haD = halloc(PAGE_LBS); host_clear(haD, PAGE_LBS);
    mbefore = multi_active;
    fork
      begin
        new_tid(t1); submit(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, t1, dsA, 8'd0, 4'd0, 4'(PAGE_LBS), haA, 32'd50, code);
        chk(code == `SFSB_SUB_OK, "concurrent H2B accepted");
        new_tid(t2); submit(`SFSB_OP_DEC, `SFSB_CLS_HOST, 1'b0, t2, dsB, psQ, 4'd0, 4'(PAGE_LBS), 32'd0, 32'd40, code);
        chk(code == `SFSB_SUB_OK, "concurrent DEC accepted");
        new_tid(t3); submit(`SFSB_OP_ENC, `SFSB_CLS_HOST, 1'b0, t3, dsC, psP, 4'd0, 4'(PAGE_LBS), 32'd0, 32'd0, code);
        chk(code == `SFSB_SUB_OK, "concurrent ENC accepted");
        new_tid(t4); submit(`SFSB_OP_B2H, `SFSB_CLS_HOST, 1'b0, t4, dsD, 8'd0, 4'd0, 4'(PAGE_LBS), haD, 32'd0, code);
        chk(code == `SFSB_SUB_OK, "concurrent B2H accepted");
        wait_tid(t1); wait_tid(t2); wait_tid(t3); wait_tid(t4);
      end
      nand_program(32'(psR), 5);
    join
    chk(multi_active > mbefore, "at least three engines were active in the same cycle");
    chk(st_of(t1) == `SFSB_ST_OK && st_of(t2) == `SFSB_ST_OK && st_of(t3) == `SFSB_ST_OK &&
        st_of(t4) == `SFSB_ST_OK, "concurrent statuses");
    for (int k = 0; k < PAGE_LBS; k++) gold_ver[50 + k] = 8'd8;
    host_check(haD, 32'd70, PAGE_LBS, "concurrent B2H");
    // B -> host (page 4 = LBAs 40..), A -> host (LBAs 50..)
    haD = halloc(PAGE_LBS); host_clear(haD, PAGE_LBS);
    run_desc(`SFSB_OP_B2H, `SFSB_CLS_HOST, 1'b0, dsB, 8'd0, 4'd0, 4'(PAGE_LBS), haD, 32'd0, st);
    host_check(haD, 32'd40, PAGE_LBS, "concurrent DEC");
    haD = halloc(PAGE_LBS); host_clear(haD, PAGE_LBS);
    run_desc(`SFSB_OP_B2H, `SFSB_CLS_HOST, 1'b0, dsA, 8'd0, 4'd0, 4'(PAGE_LBS), haD, 32'd0, st);
    host_check(haD, 32'd50, PAGE_LBS, "concurrent H2B");
    // P (ENC of C) -> NAND page 6 -> read back; page 5 (programmed concurrently) -> read back
    scmd_ok(`SFSB_SC_P2NAND, psP); nand_program(32'(psP), 6); scmd_ok(`SFSB_SC_P2FW, psP);
    scmd_ok(`SFSB_SC_P2FW, psR);
    begin : free_all
      scmd_ok(`SFSB_SC_COMMIT_D, dsA); scmd_ok(`SFSB_SC_COMMIT_D, dsC); scmd_ok(`SFSB_SC_COMMIT_D, dsD);
      scmd_ok(`SFSB_SC_FREE_D, dsA); scmd_ok(`SFSB_SC_FREE_D, dsB); scmd_ok(`SFSB_SC_FREE_D, dsC);
      scmd_ok(`SFSB_SC_FREE_D, dsD);
      scmd_ok(`SFSB_SC_FREE_P, psP); scmd_ok(`SFSB_SC_FREE_P, psQ); scmd_ok(`SFSB_SC_FREE_P, psR);
    end
    flow_read(32'd60, 0, PAGE_LBS, 6, 1'b0, st, haD);
    chk(st == `SFSB_ST_OK, "page of concurrent ENC");
    host_check(haD, 32'd60, PAGE_LBS, "concurrent ENC");
    flow_read(32'd80, 0, PAGE_LBS, 5, 1'b0, st, haD);
    chk(st == `SFSB_ST_OK, "page programmed concurrently");
    host_check(haD, 32'd80, PAGE_LBS, "concurrent NAND program");
    expect_quiet();
  endtask

  // ---- back-pressure everywhere + full completion queue
  task automatic t_backpressure();
    logic [7:0] st, code;
    logic [31:0] ha, v;
    int nsub, nslots;
    cur_test = "backpressure";
    u_hm.ready_pct = 35; u_hm.lat_min = 1; u_hm.lat_max = 24;
    nd_stall_pct = 40;
    flow_write(32'd90, PAGE_LBS, 7, 8'd11, 1'b0);
    flow_read(32'd90, 0, PAGE_LBS, 7, 1'b0, st, ha);
    chk(st == `SFSB_ST_OK, "read under back-pressure");
    host_check(ha, 32'd90, PAGE_LBS, "backpressure");
    // H2B and B2H at the same time while host memory back-pressures: both engines
    // contend for the one host port (SFB2 R2 checked by the host-port checker)
    begin
      logic [7:0] dsr, dsw, tr, tw;
      logic [31:0] har, haw;
      alloc_d(dsr); alloc_d(dsw);
      har = halloc(PAGE_LBS); host_fill(har, 32'd120, PAGE_LBS, 8'd4);
      run_desc(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, dsr, 8'd0, 4'd0, 4'(PAGE_LBS), har, 32'd120, st);
      for (int k = 0; k < PAGE_LBS; k++) gold_ver[120 + k] = 8'd4;
      har = halloc(PAGE_LBS); host_clear(har, PAGE_LBS);
      haw = halloc(PAGE_LBS); host_fill(haw, 32'd130, PAGE_LBS, 8'd4);
      new_tid(tr); submit(`SFSB_OP_B2H, 0, 0, tr, dsr, 0, 0, 4'(PAGE_LBS), har, 0, code);
      new_tid(tw); submit(`SFSB_OP_H2B, 0, 0, tw, dsw, 0, 0, 4'(PAGE_LBS), haw, 32'd130, code);
      wait_tid(tr); wait_tid(tw);
      chk(st_of(tr) == `SFSB_ST_OK && st_of(tw) == `SFSB_ST_OK, "concurrent host read + write under back-pressure");
      host_check(har, 32'd120, PAGE_LBS, "concurrent host read under back-pressure");
      for (int k = 0; k < PAGE_LBS; k++) gold_ver[130 + k] = 8'd4;
      har = halloc(PAGE_LBS); host_clear(har, PAGE_LBS);
      run_desc(`SFSB_OP_B2H, `SFSB_CLS_HOST, 1'b0, dsw, 8'd0, 4'd0, 4'(PAGE_LBS), har, 32'd0, st);
      host_check(har, 32'd130, PAGE_LBS, "concurrent host write under back-pressure");
      // directed: a B2H burst-start request is stuck (host ready 0 %) right after a
      // B2H transfer, then H2B requests too -> the arbiter must keep presenting the
      // stuck B2H request unchanged (SFB2 R2), not switch to the newcomer
      begin
        logic [31:0] v0;
        v0 = v_hm;
        har = halloc(1); host_clear(har, 1);
        run_desc(`SFSB_OP_B2H, `SFSB_CLS_HOST, 1'b0, dsr, 8'd0, 4'd0, 4'd1, har, 32'd0, st);   // last served: B2H
        u_hm.ready_pct = 0;
        har = halloc(1); host_clear(har, 1);
        haw = halloc(1); host_fill(haw, 32'd150, 1, 8'd5);
        new_tid(tr); submit(`SFSB_OP_B2H, 0, 0, tr, dsr, 0, 4'd0, 4'd1, har, 0, code);
        cyc(20);
        new_tid(tw); submit(`SFSB_OP_H2B, 0, 0, tw, dsw, 0, 4'd0, 4'd1, haw, 32'd150, code);
        cyc(20);
        u_hm.ready_pct = 100;
        wait_tid(tr); wait_tid(tw);
        chk(v_hm == v0, "host-port arbiter holds a stuck request when the other engine starts (SFB2 R2)");
        chk(st_of(tr) == `SFSB_ST_OK && st_of(tw) == `SFSB_ST_OK, "stuck-request scenario statuses");
        host_check(har, 32'd120, 1, "stuck-request B2H");
      end
      // randomised overlap stress: the host-port arbiter must never switch engines
      // while a request is presented but not yet accepted (SFB2 R2)
      for (int it = 0; it < 16; it++) begin
        u_hm.ready_pct = $urandom_range(60, 15);
        har = halloc(1); host_clear(har, 1);
        haw = halloc(1); host_fill(haw, 32'(140 + (it % 8)), 1, 8'(it + 1));
        new_tid(tr); submit(`SFSB_OP_B2H, 0, 0, tr, dsr, 0, 4'(it % PAGE_LBS), 4'd1, har, 0, code);
        cyc($urandom_range(40, 0));
        new_tid(tw); submit(`SFSB_OP_H2B, 0, 0, tw, dsw, 0, 4'(it % PAGE_LBS), 4'd1, haw, 32'(140 + (it % 8)), code);
        wait_tid(tr); wait_tid(tw);
        chk(st_of(tr) == `SFSB_ST_OK && st_of(tw) == `SFSB_ST_OK, "overlap stress statuses");
        host_check(har, 32'(120 + (it % PAGE_LBS)), 1, "overlap stress");
      end
      scmd(`SFSB_SC_FREE_D, dsr, 1'b1, v);
      scmd(`SFSB_SC_FREE_D, dsw, 1'b1, v);
    end
    u_hm.ready_pct = 100; u_hm.lat_min = 1; u_hm.lat_max = 3;
    nd_stall_pct = 0;
    // completion queue full: CQ_DEPTH + 2 H2B completions without popping
    nslots = (NUM_DSLOTS < 4) ? NUM_DSLOTS : 4;
    for (int i = 0; i < nslots; i++) begin alloc_d(tmp8); g_ds[i] = tmp8; end
    nsub = 0;
    for (int i = 0; i < CQ_DEPTH + 2; i++) begin
      begin new_tid(tmp8); g_tid[i] = tmp8; end
      ha = halloc(1); host_fill(ha, 32'(200 + i), 1, 8'd1);
      code = `SFSB_SUB_QFULL;
      while (code == `SFSB_SUB_QFULL || code == `SFSB_SUB_BUSY) begin
        submit(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, g_tid[i], g_ds[i % nslots], 8'd0, 4'd0, 4'd1, ha, 32'(200 + i), code);
        if (code != `SFSB_SUB_OK) cyc(20);
      end
      chk(code == `SFSB_SUB_OK, "CQ-full scenario submission");
      nsub++;
    end
    cyc(3000 * PAGE_LBS * LB_BYTES / 2048);      // enough for every queued transfer to finish
    csr_rd(`SFSB_CSR_STATUS, v);
    chk(v[2] == 1'b1, "an engine is still busy, holding its completion");
    csr_rd(`SFSB_CSR_CPL_STAT, v);
    chk(v[15:8] == 8'(CQ_DEPTH), "completion queue full (no completion dropped while full)");
    csr_rd(`SFSB_CSR_PERF_BASE + 12'(4 * `SFSB_PC_CQ_FULL), v);
    chk(v != 32'd0, "CQ_FULL stall counter incremented");
    drain_cq();
    for (int i = 0; i < nsub; i++) chk(done[g_tid[i]] == 1'b1, "every submission completed after the CQ drained");
    for (int i = 0; i < nslots; i++) scmd(`SFSB_SC_FREE_D, g_ds[i], 1'b1, v);
    expect_quiet();
  endtask

  // ---- exhaustion and eviction
  task automatic t_exhaust();
    logic [31:0] r, ha;
    logic [7:0] st, dsc;
    cur_test = "exhaust";
    flow_write(32'd0, PAGE_LBS, 0, 8'd1, 1'b0);       // self-contained: page 0 = LBAs 0..
    for (int i = 0; i < NUM_DSLOTS; i++) begin alloc_d(tmp8); g_ds[i] = tmp8; end
    scmd(`SFSB_SC_ALLOC_D, 8'd0, 1'b0, r);  chk(r[7:0] == `SFSB_SR_NOSPACE, "data slots exhausted -> NOSPACE");
    for (int i = 0; i < NUM_PSLOTS; i++) begin alloc_p(tmp8); g_ps[i] = tmp8; end
    scmd(`SFSB_SC_ALLOC_P, 8'd0, 1'b0, r);  chk(r[7:0] == `SFSB_SR_NOSPACE, "page slots exhausted -> NOSPACE");
    csr_rd(`SFSB_CSR_OCC, r);
    chk(r[7:0] == 8'(NUM_DSLOTS) && r[23:16] == 8'(NUM_PSLOTS), "OCC counts full");
    // turn slot 0 into a clean cached slot: then ALLOC_D evicts it
    ha = halloc(PAGE_LBS);
    flow_read_into(g_ds[0], g_ps[0], 32'd0, 0, st);
    scmd_ok(`SFSB_SC_CACHE_D, g_ds[0]);
    scmd(`SFSB_SC_ALLOC_D, 8'd0, 1'b0, r);
    chk(r[7:0] == `SFSB_SR_OK && r[16] == 1'b1 && r[15:8] == g_ds[0], "ALLOC_D evicts the LRU clean cached slot");
    scmd(`SFSB_SC_LOOKUP, 8'd0, 1'b0, r);
    chk(r[7:0] == `SFSB_SR_MISS, "evicted data no longer hits");
    for (int i = 0; i < NUM_DSLOTS; i++) scmd_ok(`SFSB_SC_FREE_D, g_ds[i]);
    for (int i = 0; i < NUM_PSLOTS; i++) scmd_ok(`SFSB_SC_FREE_P, g_ps[i]);
    csr_rd(`SFSB_CSR_OCC, r);  chk(r == 32'd0, "all slots free again");
    dsc = 8'd0;
    expect_quiet();
  endtask

  // DEC of NAND page 0 (LBAs 0..) into an allocated data slot via an allocated page slot
  task automatic flow_read_into(input logic [7:0] ds, input logic [7:0] ps, input logic [31:0] lba, input int page,
                                output logic [7:0] st);
    scmd_ok(`SFSB_SC_P2NAND, ps);
    nand_read(page, 32'(ps));
    scmd_ok(`SFSB_SC_P2FW, ps);
    run_desc(`SFSB_OP_DEC, `SFSB_CLS_HOST, 1'b0, ds, ps, 4'd0, 4'(PAGE_LBS), 32'd0, lba, st);
    chk(st == `SFSB_ST_OK, "flow_read_into status");
  endtask

  // ---- invalid descriptors: each rejected with its code, never completed
  task automatic t_invalid();
    logic [7:0] code, ds, ds2, ps, t, st;
    logic [31:0] v, ha;
    int acc0;
    cur_test = "invalid";
    acc0 = n_acc;
    alloc_d(ds); alloc_p(ps);
    new_tid(t);
    set_cfg(1'b0, 1'b0, 8'd4, 8'd1);
    submit(`SFSB_OP_H2B, 0, 0, t, ds, 0, 0, 1, 32'h0, 0, code); chk(code == `SFSB_SUB_DISABLED, "DISABLED");
    set_cfg(1'b1, 1'b0, 8'd4, 8'd1);
    submit(4'd0, 0, 0, t, ds, 0, 0, 1, 32'h0, 0, code);  chk(code == `SFSB_SUB_BAD_OPC, "BAD_OPC (0)");
    submit(4'd9, 0, 0, t, ds, 0, 0, 1, 32'h0, 0, code);  chk(code == `SFSB_SUB_BAD_OPC, "BAD_OPC (9)");
    submit(`SFSB_OP_H2B, `SFSB_CLS_GC, 0, t, ds, 0, 0, 1, 32'h0, 0, code); chk(code == `SFSB_SUB_BAD_CLASS, "BAD_CLASS H2B/GC");
    submit(`SFSB_OP_ENC, 2'd3, 0, t, ds, ps, 0, 1, 32'h0, 0, code); chk(code == `SFSB_SUB_BAD_CLASS, "BAD_CLASS 3");
    submit(`SFSB_OP_H2B, 0, 0, t, ds, 0, 0, 0, 32'h0, 0, code); chk(code == `SFSB_SUB_BAD_LEN, "BAD_LEN");
    submit(`SFSB_OP_H2B, 0, 0, t, ds, 0, 4'(PAGE_LBS - 1), 2, 32'h0, 0, code); chk(code == `SFSB_SUB_RANGE, "LB range");
    submit(`SFSB_OP_H2B, 0, 1, t, ds, 0, 0, 1, 32'h0, 0, code); chk(code == `SFSB_SUB_UNSUP, "crypt on host DMA");
    submit(`SFSB_OP_H2B, 0, 0, t, ds, 0, 0, 1, 32'h4, 0, code); chk(code == `SFSB_SUB_ALIGN, "ALIGN");
    submit(`SFSB_OP_H2B, 0, 0, t, ds, 0, 0, 1, 32'h0 - 32'(LB_BYTES / 2), 0, code); chk(code == `SFSB_SUB_RANGE, "host range wraps");
    submit(`SFSB_OP_H2B, 0, 0, t, 8'(NUM_DSLOTS), 0, 0, 1, 32'h0, 0, code); chk(code == `SFSB_SUB_SLOT, "SLOT range");
    submit(`SFSB_OP_ENC, 0, 0, t, ds, 8'(NUM_PSLOTS), 0, 1, 32'h0, 0, code); chk(code == `SFSB_SUB_SLOT, "page SLOT range");
    // OWNER: H2B into a free slot; DEC from a page slot handed to NAND
    scmd_ok(`SFSB_SC_FREE_D, ds);
    submit(`SFSB_OP_H2B, 0, 0, t, ds, 0, 0, 1, 32'h0, 0, code); chk(code == `SFSB_SUB_OWNER, "OWNER (free data slot)");
    alloc_d(ds);
    scmd_ok(`SFSB_SC_P2NAND, ps);
    submit(`SFSB_OP_DEC, 0, 0, t, ds, ps, 0, 1, 32'h0, 0, code); chk(code == `SFSB_SUB_OWNER, "OWNER (page owned by NAND)");
    scmd_ok(`SFSB_SC_P2FW, ps);
    // NOT_VALID: B2H / ENC of a never-written block
    submit(`SFSB_OP_B2H, 0, 0, t, ds, 0, 0, 1, 32'h0, 0, code); chk(code == `SFSB_SUB_NOT_VALID, "NOT_VALID (B2H)");
    submit(`SFSB_OP_ENC, 0, 0, t, ds, ps, 0, 1, 32'h0, 0, code); chk(code == `SFSB_SUB_NOT_VALID, "NOT_VALID (ENC)");
    // BUSY + DUP_TID: slow host keeps an H2B in flight
    u_hm.ready_pct = 5;
    ha = halloc(PAGE_LBS); host_fill(ha, 32'd300, PAGE_LBS, 8'd1);
    submit(`SFSB_OP_H2B, 0, 0, t, ds, 0, 0, 4'(PAGE_LBS), ha, 32'd300, code); chk(code == `SFSB_SUB_OK, "slow H2B accepted");
    submit(`SFSB_OP_H2B, 0, 0, t, ds, 0, 0, 1, ha, 32'd300, code); chk(code == `SFSB_SUB_DUP_TID, "DUP_TID");
    new_tid(st);
    submit(`SFSB_OP_H2B, 0, 0, st, ds, 0, 0, 1, ha, 32'd300, code); chk(code == `SFSB_SUB_BUSY, "BUSY (writer vs writer)");
    submit(`SFSB_OP_B2H, 0, 0, st, ds, 0, 0, 1, ha, 32'd300, code); chk(code == `SFSB_SUB_BUSY, "BUSY (reader vs writer)");
    // QFULL: H2B queue (DQ_DEPTH) + engine busy
    alloc_d(ds2);
    for (int i = 0; i < DQ_DEPTH; i++) begin
      logic [7:0] tt;
      new_tid(tt);
      submit(`SFSB_OP_H2B, 0, 0, tt, ds2, 0, 0, 1, ha, 32'd300, code);
      if (i == 0) chk(code == `SFSB_SUB_OK, "queued H2B accepted");
      else        chk(code == `SFSB_SUB_BUSY, "second writer on a queued slot -> BUSY");
    end
    begin
      int nq;
      logic stop;
      nq = 0;
      stop = 1'b0;
      for (int i = 0; i < DQ_DEPTH + 1 && i < NUM_DSLOTS - 2 && !stop; i++) begin
        logic [7:0] tt;
        logic [31:0] rr;
        scmd(`SFSB_SC_ALLOC_D, 8'd0, 1'b0, rr);
        if (rr[7:0] != `SFSB_SR_OK) stop = 1'b1;
        else begin
          g_ds[nq] = rr[15:8]; nq++;
          new_tid(tt);
          submit(`SFSB_OP_H2B, 0, 0, tt, rr[15:8], 0, 0, 1, ha, 32'd300, code);
          if (code == `SFSB_SUB_QFULL) stop = 1'b1;
        end
      end
      chk(code == `SFSB_SUB_QFULL || NUM_DSLOTS - 2 < DQ_DEPTH + 1, "H2B queue reports QFULL");
      u_hm.ready_pct = 100;
      drain_cq();
      for (int i = 0; i < nq; i++) scmd(`SFSB_SC_FREE_D, g_ds[i], 1'b1, v);
    end
    // PWR: no new volatile data under power fail; other operations continue
    pwr_fail = 1'b1; cyc(4);
    csr_rd(`SFSB_CSR_STATUS, v); chk(v[1] == 1'b1, "STATUS.pwr_fail");
    new_tid(t);
    submit(`SFSB_OP_H2B, 0, 0, t, ds2, 0, 0, 1, ha, 0, code); chk(code == `SFSB_SUB_PWR, "PWR");
    pwr_fail = 1'b0; cyc(4);
    scmd(`SFSB_SC_FREE_D, ds, 1'b1, v);
    scmd(`SFSB_SC_FREE_D, ds2, 1'b1, v);
    scmd_ok(`SFSB_SC_FREE_P, ps);
    // nothing rejected ever produced a completion; the accepted ones each produced one
    expect_quiet();
    csr_rd(`SFSB_CSR_PERF_BASE + 12'(4 * `SFSB_PC_DESC_REJ), v);
    chk(v >= 32'd20, "rejected descriptors counted");
    $display("    invalid: %0d accepted in this test, %0d rejections counted by hardware", n_acc - acc0, v);
  endtask

  // ---- NAND ECC errors and erased pages
  task automatic t_ecc();
    logic [7:0] st, ds, ps, t;
    logic [31:0] ha, v;
    cur_test = "ecc";
    flow_write(32'd400, PAGE_LBS, 8, 8'd1, 1'b0);
    // single-bit errors: data bits in two codewords, a check byte, the OOB metadata
    inject(cw_data(0, 3), 17);
    inject(cw_data(PAGE_LBS - 1, LB_BEATS - 1), 63);
    inject(cw_data(0, LB_BEATS), 5);            // first check-byte beat of codeword 0
    inject(OOB + 0, 40);                         // metadata beat of block 0 (CRC field)
    flow_read(32'd400, 0, PAGE_LBS, 8, 1'b0, st, ha);
    chk(st == `SFSB_ST_CORRECTED, "single-bit errors -> CORRECTED");
    chk(c_w1[last_dec_tid][15:0] == 16'd4, "4 corrected bits reported");
    host_check(ha, 32'd400, PAGE_LBS, "ecc-ce");
    // double-bit error in one beat -> UNCORRECTABLE, block poisoned, B2H refused
    alloc_d(ds); alloc_p(ps);
    inject(cw_data(1 % PAGE_LBS, 2), 0); inject(cw_data(1 % PAGE_LBS, 2), 9);
    scmd_ok(`SFSB_SC_P2NAND, ps); nand_read(8, 32'(ps)); scmd_ok(`SFSB_SC_P2FW, ps);
    new_tid(t);
    run_desc(`SFSB_OP_DEC, `SFSB_CLS_HOST, 1'b0, ds, ps, 4'd0, 4'(PAGE_LBS), 32'd0, 32'd400, st);
    chk(st == `SFSB_ST_UNCORR, "double-bit error -> UNCORR");
    chk(c_w0[last_tid][31:24] == 8'(1 << (1 % PAGE_LBS)), "LB error mask names the failed block");
    csr_wr(`SFSB_CSR_MSEL, {20'd0, 4'(1 % PAGE_LBS), ds});
    csr_rd(`SFSB_CSR_MFLAGS, v); chk(v[1] == 1'b1 && v[0] == 1'b0, "failed block POISONED in metadata");
    new_tid(t);
    submit(`SFSB_OP_B2H, 0, 0, t, ds, 0, 0, 4'(PAGE_LBS), 32'h0, 0, st);
    chk(st == `SFSB_SUB_POISON, "poisoned data never leaves the buffer (B2H -> POISON)");
    scmd_ok(`SFSB_SC_FREE_D, ds); scmd_ok(`SFSB_SC_FREE_P, ps);
    // three errors that alias to a 'corrected' word (positions 3^5^6 = 0) -> caught by V2 CRC
    inject(cw_data(0, 7), 0); inject(cw_data(0, 7), 1); inject(cw_data(0, 7), 2);
    flow_read(32'd400, 0, PAGE_LBS, 8, 1'b0, st, ha);
    chk(st == `SFSB_ST_CRC, "ECC miscorrection caught by end-to-end CRC (V2)");
    // metadata double error -> META_UE
    inject(OOB + 0, 3); inject(OOB + 0, 4);
    flow_read(32'd400, 0, PAGE_LBS, 8, 1'b0, st, ha);
    chk(st == `SFSB_ST_META_UE, "OOB metadata double error -> META_UE");
    // misdirected read: expected LBA != stored LBA tag
    flow_read(32'd999, 0, PAGE_LBS, 8, 1'b0, st, ha);
    chk(st == `SFSB_ST_LBA, "LBA tag mismatch (misdirected read) -> LBA");
    // erased page
    flow_read(32'd0, 0, PAGE_LBS, NPAGES - 1, 1'b0, st, ha);
    chk(st == `SFSB_ST_ERASED, "never-programmed page -> ERASED");
    chk(c_w1[last_dec_tid][23:16] == 8'((1 << PAGE_LBS) - 1), "erased mask");
    expect_quiet();
  endtask

  // ---- buffer corruption: parity (1 bit) and parity-invisible (2 bits, one lane)
  task automatic t_corrupt();
    logic [7:0] st, ds, ps, t, code;
    logic [31:0] ha, v, d;
    logic e;
    cur_test = "corrupt";
    // (1) single bit in a data slot -> B2H reports BUF_PAR, block poisoned
    alloc_d(ds);
    ha = halloc(PAGE_LBS); host_fill(ha, 32'd500, PAGE_LBS, 8'd1);
    for (int k = 0; k < PAGE_LBS; k++) gold_ver[500 + k] = 8'd1;
    fi_arm_word(ds_word(ds, 0, 5), 72'h1 << (2 * 9 + 3));
    run_desc(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, ds, 8'd0, 4'd0, 4'(PAGE_LBS), ha, 32'd500, st);
    csr_rd(`SFSB_CSR_FI_CTRL, v); chk(v[1] == 1'b1 && v[0] == 1'b0, "fault injection fired once");
    // firmware read of the corrupted word -> error response (parity of its lanes)
    fw_acc(1'b0, 32'h0010_0000 + 32'(ds_word(ds, 0, 5) * 8), 32'd0, 4'h0, d, e);
    chk(e, "FW read of a parity-corrupted word -> error response");
    ha = halloc(PAGE_LBS); host_clear(ha, PAGE_LBS);
    run_desc(`SFSB_OP_B2H, `SFSB_CLS_HOST, 1'b0, ds, 8'd0, 4'd0, 4'(PAGE_LBS), ha, 32'd0, st);
    chk(st == `SFSB_ST_BUF_PAR, "single-bit SRAM error -> BUF_PAR at egress");
    chk(c_w0[last_tid][31:24] == 8'h01, "error mask = block 0");
    csr_wr(`SFSB_CSR_MSEL, {20'd0, 4'd0, ds}); csr_rd(`SFSB_CSR_MFLAGS, v);
    chk(v[1] == 1'b1, "block poisoned after egress error");
    // (2) two bits in one lane (parity cannot see it) -> V3 CRC at egress
    scmd(`SFSB_SC_FREE_D, ds, 1'b1, v);
    alloc_d(ds);
    ha = halloc(PAGE_LBS); host_fill(ha, 32'd500, PAGE_LBS, 8'd1);
    fi_arm_word(ds_word(ds, 1 % PAGE_LBS, 9 % LB_BEATS), (72'h3 << (4 * 9)));
    run_desc(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, ds, 8'd0, 4'd0, 4'(PAGE_LBS), ha, 32'd500, st);
    ha = halloc(PAGE_LBS); host_clear(ha, PAGE_LBS);
    run_desc(`SFSB_OP_B2H, `SFSB_CLS_HOST, 1'b0, ds, 8'd0, 4'd0, 4'(PAGE_LBS), ha, 32'd0, st);
    chk(st == `SFSB_ST_CRC, "parity-invisible SRAM corruption -> CRC at egress (V3)");
    // (3) same corruption before page assembly -> V1 CRC, page BAD, NAND hand-off refused
    scmd(`SFSB_SC_FREE_D, ds, 1'b1, v);
    alloc_d(ds); alloc_p(ps);
    ha = halloc(PAGE_LBS); host_fill(ha, 32'd500, PAGE_LBS, 8'd1);
    fi_arm_word(ds_word(ds, 0, 0), (72'h3 << 0));
    run_desc(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, ds, 8'd0, 4'd0, 4'(PAGE_LBS), ha, 32'd500, st);
    run_desc(`SFSB_OP_ENC, `SFSB_CLS_HOST, 1'b0, ds, ps, 4'd0, 4'(PAGE_LBS), 32'd0, 32'd0, st);
    chk(st == `SFSB_ST_CRC, "corruption before ECC encode -> CRC at V1");
    scmd(`SFSB_SC_P2NAND, ps, 1'b0, v);
    chk(v[7:0] == `SFSB_SR_BAD_PAGE, "BAD page is never handed to the NAND controller");
    csr_wr(`SFSB_CSR_PSEL, {24'd0, ps}); csr_rd(`SFSB_CSR_PINFO, v); chk(v[3] == 1'b1, "PINFO.bad");
    // re-encoding from a good copy clears BAD
    scmd(`SFSB_SC_FREE_D, ds, 1'b1, v);
    alloc_d(ds);
    ha = halloc(PAGE_LBS); host_fill(ha, 32'd500, PAGE_LBS, 8'd1);
    run_desc(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, ds, 8'd0, 4'd0, 4'(PAGE_LBS), ha, 32'd500, st);
    run_desc(`SFSB_OP_ENC, `SFSB_CLS_HOST, 1'b0, ds, ps, 4'd0, 4'(PAGE_LBS), 32'd0, 32'd0, st);
    chk(st == `SFSB_ST_OK, "clean re-encode");
    scmd_ok(`SFSB_SC_P2NAND, ps);
    // (4) single bit corrupted in the page buffer while the NAND controller writes it -> DEC BUF_PAR
    scmd_ok(`SFSB_SC_P2FW, ps);
    scmd(`SFSB_SC_FREE_D, ds, 1'b1, v);
    alloc_d(ds);
    scmd_ok(`SFSB_SC_P2NAND, ps);
    fi_arm_word(ps_word(ps, cw_data(0, 1)), 72'h1 << 8);   // parity bit of lane 0
    nand_read(8, 32'(ps));
    scmd_ok(`SFSB_SC_P2FW, ps);
    run_desc(`SFSB_OP_DEC, `SFSB_CLS_HOST, 1'b0, ds, ps, 4'd0, 4'(PAGE_LBS), 32'd0, 32'd400, st);
    chk(st == `SFSB_ST_BUF_PAR, "page-buffer parity error -> BUF_PAR at DEC");
    // (5) the NAND port refuses to read a corrupted page beat
    scmd_ok(`SFSB_SC_P2NAND, ps);
    begin
      logic [63:0] rd; logic er;
      nd_acc(1'b0, ps_addr(ps) + 32'(8 * cw_data(0, 1)), 64'd0, rd, er);
      chk(er && rd == 64'd0, "NAND port read of a corrupted beat -> error, no data");
    end
    scmd_ok(`SFSB_SC_P2FW, ps);
    scmd(`SFSB_SC_FREE_D, ds, 1'b1, v);
    scmd_ok(`SFSB_SC_FREE_P, ps);
    t = 0; code = 0;
    expect_quiet();
  endtask

  // ---- ownership enforcement on the firmware and NAND ports
  task automatic t_owner();
    logic [7:0] ds, ps, st, t, code;
    logic [31:0] d, ha, a;
    logic [63:0] rd;
    logic e;
    cur_test = "owner";
    a = 32'h0010_0000;
    fw_acc(1'b1, a, 32'h1234_5678, 4'hF, d, e);         chk(e, "FW write to a FREE slot -> error");
    fw_acc(1'b0, a, 32'd0, 4'h0, d, e);                  chk(e, "FW read of a FREE slot -> error");
    alloc_d(ds);
    a = 32'h0010_0000 + 32'(ds_word(ds, 0, 3) * 8);
    fw_acc(1'b1, a, 32'hCAFE_F00D, 4'hF, d, e);          chk(!e, "FW write to an owned slot");
    fw_acc(1'b1, a + 4, 32'h0000_00AB, 4'h1, d, e);      chk(!e, "FW byte write");
    fw_acc(1'b0, a, 32'd0, 4'h0, d, e);                  chk(!e && d == 32'hCAFE_F00D, "FW read-back (low word)");
    fw_acc(1'b0, a + 4, 32'd0, 4'h0, d, e);              chk(!e && d[7:0] == 8'hAB, "FW read-back (byte enable)");
    // while an engine holds the write lock, firmware may not touch the slot
    u_hm.ready_pct = 5;
    ha = halloc(PAGE_LBS); host_fill(ha, 32'd600, PAGE_LBS, 8'd1);
    new_tid(t);
    submit(`SFSB_OP_H2B, 0, 0, t, ds, 0, 0, 4'(PAGE_LBS), ha, 32'd600, code);
    fw_acc(1'b1, a, 32'h0, 4'hF, d, e);                  chk(e, "FW write to an engine-locked slot -> error");
    fw_acc(1'b0, a, 32'h0, 4'h0, d, e);                  chk(e, "FW read of a write-locked slot -> error");
    scmd(`SFSB_SC_FREE_D, ds, 1'b1, d);                  chk(d[7:0] == `SFSB_SR_BUSY, "FREE of a locked slot -> BUSY");
    u_hm.ready_pct = 100;
    wait_tid(t);
    for (int k = 0; k < PAGE_LBS; k++) gold_ver[600 + k] = 8'd1;
    // NAND port: only page slots handed to NAND
    alloc_p(ps);
    nd_acc(1'b1, ps_addr(ps), 64'h1, rd, e);             chk(e, "NAND write to a FW-owned page slot -> error");
    nd_acc(1'b0, 32'(ds_word(ds, 0, 0) * 8), 64'h0, rd, e); chk(e, "NAND access to a data slot -> error");
    scmd_ok(`SFSB_SC_P2NAND, ps);
    nd_acc(1'b1, ps_addr(ps) + 32'd8, 64'h1122_3344_5566_7788, rd, e); chk(!e, "NAND write to a NAND-owned page slot");
    nd_acc(1'b0, ps_addr(ps) + 32'd8, 64'h0, rd, e);     chk(!e && rd == 64'h1122_3344_5566_7788, "NAND read-back");
    nd_acc(1'b0, ps_addr(ps) + 32'd4, 64'h0, rd, e);     chk(e, "NAND misaligned -> error");
    fw_acc(1'b0, 32'h0010_0000 + ps_addr(ps), 32'd0, 4'h0, d, e); chk(e, "FW access to a NAND-owned page -> error");
    scmd(`SFSB_SC_FREE_P, ps, 1'b0, d);                  chk(d[7:0] == `SFSB_SR_STATE, "FREE_P of a NAND-owned page -> STATE");
    new_tid(t);
    submit(`SFSB_OP_ENC, 0, 0, t, ds, ps, 0, 1, 32'h0, 0, code); chk(code == `SFSB_SUB_OWNER, "ENC into a NAND-owned page -> OWNER");
    scmd_ok(`SFSB_SC_P2FW, ps);
    nd_acc(1'b0, ps_addr(ps) + 32'd8, 64'h0, rd, e);     chk(e, "NAND access after P2FW -> error");
    scmd(`SFSB_SC_FREE_D, ds, 1'b0, d);                  chk(d[7:0] == `SFSB_SR_DIRTY, "FREE of a dirty slot -> DIRTY");
    scmd(`SFSB_SC_FREE_D, ds, 1'b1, d);                  chk(d[7:0] == `SFSB_SR_OK, "FREE with DISCARD");
    scmd_ok(`SFSB_SC_FREE_P, ps);
    st = 0;
    expect_quiet();
  endtask

  // ---- clean read cache, coherence on writes, metadata cache (DRAM)
  task automatic t_cache();
    logic [7:0] ds, ds2, ps, st;
    logic [31:0] r, ha;
    cur_test = "cache";
    flow_write(32'd700, PAGE_LBS, 9, 8'd1, 1'b0);
    alloc_d(ds); alloc_p(ps);
    flow_read_into(ds, ps, 32'd700, 9, st);
    scmd_ok(`SFSB_SC_FREE_P, ps);
    scmd_ok(`SFSB_SC_CACHE_D, ds);
    csr_wr(`SFSB_CSR_SARG_LBA, 32'(700 + PAGE_LBS - 1));
    scmd(`SFSB_SC_LOOKUP, 8'd0, 1'b0, r);
    chk(r[7:0] == `SFSB_SR_OK && r[16] && r[15:8] == ds && r[23:20] == 4'(PAGE_LBS - 1), "read-cache hit");
    ha = halloc(1); host_clear(ha, 1);
    run_desc(`SFSB_OP_B2H, `SFSB_CLS_HOST, 1'b0, ds, 8'd0, 4'(PAGE_LBS - 1), 4'd1, ha, 32'd0, st);
    chk(st == `SFSB_ST_OK, "B2H served from the cache (no NAND access)");
    host_check(ha, 32'(700 + PAGE_LBS - 1), 1, "cache hit data");
    scmd(`SFSB_SC_CACHE_D, ds, 1'b0, r); chk(r[7:0] == `SFSB_SR_STATE, "double insert refused");
    // a host write to that LBA invalidates the cached copy
    alloc_d(ds2);
    ha = halloc(1); host_fill(ha, 32'(700 + PAGE_LBS - 1), 1, 8'd2);
    run_desc(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, ds2, 8'd0, 4'd0, 4'd1, ha, 32'(700 + PAGE_LBS - 1), st);
    scmd(`SFSB_SC_LOOKUP, 8'd0, 1'b0, r);
    chk(r[7:0] == `SFSB_SR_MISS, "host write invalidated the stale cached block");
    csr_wr(`SFSB_CSR_SARG_LBA, 32'd700);
    scmd(`SFSB_SC_LOOKUP, 8'd0, 1'b0, r);
    chk(r[7:0] == `SFSB_SR_OK, "other blocks of the slot still cached");
    // dirty data can never enter the clean cache
    scmd(`SFSB_SC_CACHE_D, ds2, 1'b0, r);  chk(r[7:0] == `SFSB_SR_DIRTY, "dirty slot refused by the cache");
    // TRIM-style invalidation
    csr_wr(`SFSB_CSR_SARG_CNT, 32'd2);
    scmd(`SFSB_SC_INVAL, 8'd0, 1'b0, r);
    scmd(`SFSB_SC_LOOKUP, 8'd0, 1'b0, r);  chk(r[7:0] == `SFSB_SR_MISS, "INVAL range");
    scmd_ok(`SFSB_SC_CLAIM_D, ds);
    scmd_ok(`SFSB_SC_FREE_D, ds);
    scmd(`SFSB_SC_FREE_D, ds2, 1'b1, r);
    csr_rd(`SFSB_CSR_PERF_BASE + 12'(4 * `SFSB_PC_CACHE_HIT), r);
    chk(r >= 32'd2, "cache hit counter");
    // metadata cache in front of the external DRAM
    if (EXT_DRAM_EN != 0) begin
      logic [31:0] d, h0, m0;
      logic e;
      csr_rd(`SFSB_CSR_PERF_BASE + 12'(4 * `SFSB_PC_MC_HIT), h0);
      csr_rd(`SFSB_CSR_PERF_BASE + 12'(4 * `SFSB_PC_MC_MISS), m0);
      for (int i = 0; i < 16; i++) begin
        fw_acc(1'b1, 32'h0080_0000 + 32'(4 * i), 32'hA000_0000 + 32'(i), 4'hF, d, e);
        chk(!e, "DRAM write");
      end
      chk(u_xm.mem[1][31:0] == 32'hA000_0002 && u_xm.mem[1][63:32] == 32'hA000_0003, "write-through reached DRAM");
      for (int pass = 0; pass < 2; pass++)
        for (int i = 0; i < 16; i++) begin
          fw_acc(1'b0, 32'h0080_0000 + 32'(4 * i), 32'd0, 4'h0, d, e);
          chk(!e && d == 32'hA000_0000 + 32'(i), "DRAM read through the metadata cache");
        end
      csr_rd(`SFSB_CSR_PERF_BASE + 12'(4 * `SFSB_PC_MC_MISS), d);
      chk(d - m0 == 32'd8, "8 line misses (16 words, 2 per line)");
      csr_rd(`SFSB_CSR_PERF_BASE + 12'(4 * `SFSB_PC_MC_HIT), d);
      chk(d - h0 == 32'd24, "24 hits");
      fw_acc(1'b1, 32'h0080_0004, 32'h5555_5555, 4'hF, d, e);
      fw_acc(1'b0, 32'h0080_0004, 32'd0, 4'h0, d, e);
      chk(d == 32'h5555_5555, "update-on-hit keeps the line coherent");
      u_xm.err_lo = DRAM_BASE + 32'h100; u_xm.err_hi = DRAM_BASE + 32'h1FF;
      fw_acc(1'b0, 32'h0080_0100, 32'd0, 4'h0, d, e);  chk(e, "DRAM error propagated");
      u_xm.err_lo = 32'hFFFF_FFFF; u_xm.err_hi = 32'h0;
      fw_acc(1'b0, 32'h0080_0100, 32'd0, 4'h0, d, e);  chk(!e, "DRAM error was not cached");
      u_xm.mem[0] = 64'h0;                                 // change DRAM behind the cache
      csr_wr(`SFSB_CSR_MC_CTRL, 32'd1);
      fw_acc(1'b0, 32'h0080_0000, 32'd0, 4'h0, d, e);  chk(d == 32'd0, "invalidate-all");
    end
    expect_quiet();
  endtask

  // ---- durability bookkeeping and power fail
  task automatic t_durable();
    logic [7:0] ds, ps, st, t, code;
    logic [31:0] v, ha;
    cur_test = "durable";
    alloc_d(ds); alloc_p(ps);
    ha = halloc(PAGE_LBS); host_fill(ha, 32'd800, PAGE_LBS, 8'd1);
    run_desc(`SFSB_OP_H2B, `SFSB_CLS_HOST, 1'b0, ds, 8'd0, 4'd0, 4'(PAGE_LBS), ha, 32'd800, st);
    chk(st == `SFSB_ST_OK, "H2B");
    csr_rd(`SFSB_CSR_STATUS, v);
    chk(v[23:16] == 8'd1 && plp_dirty, "volatile host data counted as DIRTY");
    chk(v[3] == (PLP_PRESENT != 0), "early-ack permission = WCE | PLP (WCE off)");
    set_cfg(1'b1, 1'b1, 8'd4, 8'd1);
    csr_rd(`SFSB_CSR_STATUS, v);
    chk(v[3] == 1'b1, "early-ack permitted only with host write cache enabled");
    set_cfg(1'b1, 1'b0, 8'd4, 8'd1);
    // power fails: new host data refused, the dirty slot can still be drained to NAND
    pwr_fail = 1'b1; cyc(4);
    new_tid(t);
    submit(`SFSB_OP_H2B, 0, 0, t, ds, 0, 0, 1, ha, 0, code);  chk(code == `SFSB_SUB_PWR, "H2B refused under power fail");
    run_desc(`SFSB_OP_ENC, `SFSB_CLS_HOST, 1'b0, ds, ps, 4'd0, 4'(PAGE_LBS), 32'd0, 32'd0, st);
    chk(st == `SFSB_ST_OK, "drain ENC allowed under power fail");
    scmd_ok(`SFSB_SC_P2NAND, ps); nand_program(32'(ps), 10); scmd_ok(`SFSB_SC_P2FW, ps);
    scmd_ok(`SFSB_SC_COMMIT_D, ds);
    csr_rd(`SFSB_CSR_STATUS, v);
    chk(v[23:16] == 8'd0 && !plp_dirty, "DIRTY cleared only by COMMIT after the NAND program");
    pwr_fail = 1'b0; cyc(4);
    for (int k = 0; k < PAGE_LBS; k++) gold_ver[800 + k] = 8'd1;
    scmd_ok(`SFSB_SC_FREE_D, ds); scmd_ok(`SFSB_SC_FREE_P, ps);
    flow_read(32'd800, 0, PAGE_LBS, 10, 1'b0, st, ha);
    chk(st == `SFSB_ST_OK, "drained page reads back");
    host_check(ha, 32'd800, PAGE_LBS, "durable");
    expect_quiet();
  endtask

  // ---- optional crypt stage (placeholder transform)
  task automatic t_crypt();
    logic [7:0] st;
    logic [31:0] ha;
    int same;
    cur_test = "crypt";
    if (CRYPTO_EN != 0) begin
      csr_wr(`SFSB_CSR_KEY_LO, 32'h0123_4567); csr_wr(`SFSB_CSR_KEY_HI, 32'h89AB_CDEF);
      flow_write(32'd900, PAGE_LBS, 11, 8'd1, 1'b1);
      same = 0;
      for (int b = 0; b < LB_BEATS; b++) if (flash[11 * PIMG_BEATS + b] == pat(32'd900, b, 8'd1)) same++;
      chk(same == 0, "NAND holds transformed data, not plaintext");
      chk(flash[11 * PIMG_BEATS + OOB][31:0] == 32'd900, "OOB metadata (LBA, plaintext CRC) present");
      flow_read(32'd900, 0, PAGE_LBS, 11, 1'b1, st, ha);
      chk(st == `SFSB_ST_OK, "crypt round trip");
      host_check(ha, 32'd900, PAGE_LBS, "crypt");
      csr_wr(`SFSB_CSR_KEY_LO, 32'h0123_4568);
      flow_read(32'd900, 0, PAGE_LBS, 11, 1'b1, st, ha);
      chk(st == `SFSB_ST_CRC, "wrong key detected by the plaintext CRC (V2)");
      csr_wr(`SFSB_CSR_KEY_LO, 32'h0);  csr_wr(`SFSB_CSR_KEY_HI, 32'h0);
    end
    expect_quiet();
  endtask

  // ---- arbitration: starvation bound and HOST/GC weighted round robin
  task automatic t_arb();
    logic [7:0] ps, code, st;
    logic [31:0] v;
    int bound, n, k0, gc_before_last_host;
    cur_test = "arb";
    bound = AGE_LIMIT + NP - 1;
    for (int p = 0; p < NP; p++) begin
      chk(wait_max[p] <= bound, "bank arbitration wait within AGE_LIMIT + NP - 1");
      if (wait_max[p] > bound) $display("    port %0d waited %0d > %0d", p, wait_max[p], bound);
    end
    csr_rd(`SFSB_CSR_PERF_BASE + 12'(4 * `SFSB_PC_MAX_WAIT), v);
    chk(v <= 32'(bound), "MAX_WAIT counter within bound");
    // WRR: 4 HOST + 4 GC DEC from one shared page slot into 8 data slots
    n = (NUM_DSLOTS >= 8) ? 8 : NUM_DSLOTS;
    if (n >= 4 && DQ_DEPTH >= 4) begin
      flow_write(32'd1000 % 1024, PAGE_LBS, 12, 8'd1, 1'b0);
      set_cfg(1'b1, 1'b0, 8'd2, 8'd1);
      alloc_p(ps);
      scmd_ok(`SFSB_SC_P2NAND, ps); nand_read(12, 32'(ps)); scmd_ok(`SFSB_SC_P2FW, ps);
      for (int i = 0; i < n; i++) begin alloc_d(tmp8); g_ds[i] = tmp8; end
      k0 = n_order;
      for (int i = 0; i < n; i++) begin
        begin new_tid(tmp8); g_tid[i] = tmp8; end
        submit(`SFSB_OP_DEC, (i < n / 2) ? `SFSB_CLS_HOST : `SFSB_CLS_GC, 1'b0, g_tid[i], g_ds[i], ps, 4'd0,
               4'(PAGE_LBS), 32'd0, 32'(1000 % 1024), code);
        chk(code == `SFSB_SUB_OK, "WRR submission");
      end
      for (int i = 0; i < n; i++) wait_tid(g_tid[i]);
      // the engine executes in dispatch order, so completion order = dispatch order.
      // While both classes still have queued work (the first descriptor was taken
      // before anything else was queued), runs must respect W_HOST = 2 / W_GC = 1.
      begin
        int rem_h, rem_g, run_len, max_h, max_g;
        logic last_g, is_g;
        rem_h = n / 2; rem_g = n - n / 2; run_len = 0; max_h = 0; max_g = 0; last_g = 1'b0;
        gc_before_last_host = 0;
        $write("    dispatch order:");
        for (int j = k0; j < n_order; j++) begin
          is_g = 1'b0;
          for (int i = n / 2; i < n; i++) if (order[j] == g_tid[i]) is_g = 1'b1;
          $write(" %0s", is_g ? "G" : "H");
          if (j > k0 && rem_h > 0 && rem_g > 0) begin
            run_len = (j > k0 + 1 && is_g == last_g) ? run_len + 1 : 1;
            if (is_g)  begin if (run_len > max_g) max_g = run_len; end
            else       begin if (run_len > max_h) max_h = run_len; end
          end
          if (is_g && rem_h > 0) gc_before_last_host = 1;
          if (is_g) rem_g--; else rem_h--;
          last_g = is_g;
        end
        $display("");
        chk(max_h <= 2 && max_g <= 1, "WRR run lengths respect W_HOST=2 / W_GC=1 while both classes wait");
        chk(gc_before_last_host == 1, "GC class served before the HOST queue drained (no starvation)");
      end
      for (int i = 0; i < n; i++) chk(st_of(g_tid[i]) == `SFSB_ST_OK, "WRR DEC status");
      set_cfg(1'b1, 1'b0, 8'd4, 8'd1);
      for (int i = 0; i < n; i++) scmd_ok(`SFSB_SC_FREE_D, g_ds[i]);
      scmd_ok(`SFSB_SC_FREE_P, ps);
    end
    st = 0;
    expect_quiet();
  endtask

  // ---- controller reset in the middle of transfers
  task automatic t_reset();
    logic [7:0] ds, ps, t, code, st;
    logic [31:0] v, ha;
    cur_test = "reset";
    alloc_d(ds); alloc_p(ps);
    u_hm.ready_pct = 10;
    ha = halloc(PAGE_LBS); host_fill(ha, 32'd950, PAGE_LBS, 8'd3);
    new_tid(t);
    submit(`SFSB_OP_H2B, 0, 0, t, ds, 0, 0, 4'(PAGE_LBS), ha, 32'd950, code);
    chk(code == `SFSB_SUB_OK, "H2B accepted before reset");
    scmd_ok(`SFSB_SC_P2NAND, ps);
    fork
      begin cyc(150); do_reset(5); end
      begin
        // NAND traffic in flight when reset hits: stops at reset (no response is owed)
        for (int i = 0; i < PIMG_BEATS && rst_n; i++) begin
          logic [63:0] rd; logic er;
          nd_acc(1'b1, ps_addr(ps) + 32'(8 * i), 64'h0, rd, er);
        end
      end
    join
    nd_req_valid = 1'b0;
    u_hm.ready_pct = 100;
    cyc(10);
    csr_rd(`SFSB_CSR_STATUS, v);
    chk(v[31:4] == 28'd0 && v[2:1] == 2'd0 && v[0] && v[3] == (PLP_PRESENT != 0), "STATUS clean after reset");
    csr_rd(`SFSB_CSR_OCC, v);      chk(v == 32'd0, "all slots free after reset");
    csr_rd(`SFSB_CSR_CPL_STAT, v); chk(v == 32'd0, "no stale completion after reset");
    cyc(200);
    csr_rd(`SFSB_CSR_CPL_STAT, v); chk(v == 32'd0, "no late completion from a cancelled transfer");
    chk(!busy, "subsystem idle after reset");
    // full function after reset
    flow_write(32'd960, PAGE_LBS, 13, 8'd1, 1'b0);
    flow_read(32'd960, 0, PAGE_LBS, 13, 1'b0, st, ha);
    chk(st == `SFSB_ST_OK, "transfer after reset");
    host_check(ha, 32'd960, PAGE_LBS, "after reset");
    expect_quiet();
  endtask

  // ---- random mixed traffic with random back-pressure
  task automatic t_random();
    logic [7:0] st;
    logic [31:0] ha, lba;
    int page;
    cur_test = "random";
    for (int it = 0; it < 6; it++) begin
      u_hm.ready_pct = $urandom_range(100, 30);
      u_hm.lat_max   = $urandom_range(12, 1);
      nd_stall_pct   = $urandom_range(30, 0);
      lba  = 32'(16 + 4 * it) * 32'(PAGE_LBS);
      page = 20 + it;
      flow_write(lba, PAGE_LBS, page, 8'(it + 20), 1'b0);
      if ($urandom_range(1, 0) == 1) inject(cw_data($urandom_range(PAGE_LBS - 1, 0), $urandom_range(LB_BEATS - 1, 0)),
                                           $urandom_range(63, 0));
      flow_read(lba, 0, PAGE_LBS, page, 1'b0, st, ha);
      chk(st == `SFSB_ST_OK || st == `SFSB_ST_CORRECTED, "random round trip status");
      host_check(ha, lba, PAGE_LBS, "random");
    end
    u_hm.ready_pct = 100; u_hm.lat_max = 1; nd_stall_pct = 0;
    expect_quiet();
  endtask

  // ---- throughput measurement (docs/06_PERFORMANCE.md)
  task automatic print_perf(input logic [8*24-1:0] tag);
    logic [31:0] v [`SFSB_PC_NUM];
    for (int i = 0; i < `SFSB_PC_NUM; i++) csr_rd(`SFSB_CSR_PERF_BASE + 12'(4 * i), v[i]);
    $display("PERF %0s cycles=%0d sram_rd=%0d sram_wr=%0d occ_avg_x100=%0d occ_max=%0d", tag, v[0], v[1], v[2],
             (v[0] != 0) ? (v[3] * 100) / v[0] : 0, v[4]);
    $display("PERF %0s h2b_beats=%0d h2b_active=%0d b2h_beats=%0d b2h_active=%0d enc_beats=%0d enc_active=%0d dec_beats=%0d dec_active=%0d",
             tag, v[5], v[6], v[7], v[8], v[9], v[10], v[11], v[12]);
    $display("PERF %0s arb_stall=%0d ecc_wait=%0d ecc_qwait=%0d nand_starve=%0d nand_beats=%0d host_req_wait=%0d host_rsp_wait=%0d cq_full=%0d max_wait=%0d",
             tag, v[13], v[14], v[15], v[16], v[17], v[18], v[19], v[20], v[29]);
    $display("PERF %0s port_stall fw=%0d nand=%0d h2b=%0d b2h=%0d encr=%0d encw=%0d decr=%0d decw=%0d",
             tag, v[32], v[33], v[34], v[35], v[36], v[37], v[38], v[39]);
  endtask

  task automatic t_perf();
    logic [7:0] code;
    logic [31:0] v;
    int t0, t1, npg;
    cur_test = "perf";
    npg = (NUM_PSLOTS < 4) ? NUM_PSLOTS : 4;
    u_hm.ready_pct = 100; u_hm.lat_min = 1; u_hm.lat_max = 1;
    begin
      int hl;
      if ($value$plusargs("HLAT=%d", hl)) begin u_hm.lat_min = hl; u_hm.lat_max = hl; end
    end
    for (int i = 0; i < npg; i++) begin begin alloc_d(tmp8); g_ds[i] = tmp8; end begin alloc_p(tmp8); g_ps[i] = tmp8; end end
    for (int i = 0; i < npg; i++) begin g_ha[i] = halloc(PAGE_LBS); host_fill(g_ha[i], 32'(i * PAGE_LBS), PAGE_LBS, 8'd1); end
    // (1) host ingress alone
    csr_wr(`SFSB_CSR_PERF_CTRL, 32'd1); t0 = $time;
    for (int i = 0; i < npg; i++) begin
      begin new_tid(tmp8); g_tid[i] = tmp8; end
      submit(`SFSB_OP_H2B, 0, 0, g_tid[i], g_ds[i], 0, 0, 4'(PAGE_LBS), g_ha[i], 32'(i * PAGE_LBS), code);
    end
    for (int i = 0; i < npg; i++) wait_tid(g_tid[i]);
    print_perf("h2b");
    // (2) page assembly alone (ENC)
    csr_wr(`SFSB_CSR_PERF_CTRL, 32'd1);
    for (int i = 0; i < npg; i++) begin
      begin new_tid(tmp8); g_tid[i] = tmp8; end
      submit(`SFSB_OP_ENC, 0, 0, g_tid[i], g_ds[i], g_ps[i], 0, 4'(PAGE_LBS), 32'd0, 0, code);
    end
    for (int i = 0; i < npg; i++) wait_tid(g_tid[i]);
    print_perf("enc");
    // (3) DEC alone
    csr_wr(`SFSB_CSR_PERF_CTRL, 32'd1);
    for (int i = 0; i < npg; i++) begin
      logic [31:0] rr;
      scmd(`SFSB_SC_COMMIT_D, g_ds[i], 1'b0, rr);
      begin new_tid(tmp8); g_tid[i] = tmp8; end
      submit(`SFSB_OP_DEC, 0, 0, g_tid[i], g_ds[i], g_ps[i], 0, 4'(PAGE_LBS), 32'd0, 32'(i * PAGE_LBS), code);
    end
    for (int i = 0; i < npg; i++) wait_tid(g_tid[i]);
    print_perf("dec");
    // (4) host egress alone
    csr_wr(`SFSB_CSR_PERF_CTRL, 32'd1);
    for (int i = 0; i < npg; i++) begin
      begin new_tid(tmp8); g_tid[i] = tmp8; end
      submit(`SFSB_OP_B2H, 0, 0, g_tid[i], g_ds[i], 0, 0, 4'(PAGE_LBS), g_ha[i], 0, code);
    end
    for (int i = 0; i < npg; i++) wait_tid(g_tid[i]);
    print_perf("b2h");
    // (5) everything at once: H2B + B2H + ENC + DEC + NAND port traffic
    scmd_ok(`SFSB_SC_P2NAND, g_ps[0]);          // firmware port: only one thread may use it
    csr_wr(`SFSB_CSR_PERF_CTRL, 32'd1);
    fork
      begin
        begin new_tid(tmp8); g_tid[0] = tmp8; end submit(`SFSB_OP_B2H, 0, 0, g_tid[0], g_ds[0], 0, 0, 4'(PAGE_LBS), g_ha[0], 0, code);
        begin new_tid(tmp8); g_tid[1] = tmp8; end submit(`SFSB_OP_ENC, 0, 0, g_tid[1], g_ds[1], g_ps[1], 0, 4'(PAGE_LBS), 0, 0, code);
        begin new_tid(tmp8); g_tid[2] = tmp8; end submit(`SFSB_OP_DEC, 0, 0, g_tid[2], g_ds[2], g_ps[2], 0, 4'(PAGE_LBS), 0, 32'(2 * PAGE_LBS), code);
        begin new_tid(tmp8); g_tid[3] = tmp8; end submit(`SFSB_OP_H2B, 0, 0, g_tid[3], g_ds[3], 0, 0, 4'(PAGE_LBS), g_ha[3], 32'(3 * PAGE_LBS), code);
        for (int i = 0; i < 4; i++) wait_tid(g_tid[i]);
      end
      nand_program(32'(g_ps[0]), 30);
    join
    print_perf("mixed");
    csr_rd(`SFSB_CSR_PERF_BASE, v);
    t1 = $time;
    $display("PERF config banks=%0d lb=%0d page_lbs=%0d host_max_out=%0d host_latency=%0d", NUM_BANKS, LB_BYTES,
             PAGE_LBS, HOST_MAX_OUT, u_hm.lat_min);
    scmd_ok(`SFSB_SC_P2FW, g_ps[0]);
    for (int i = 0; i < npg; i++) begin
      logic [31:0] rr;
      scmd(`SFSB_SC_FREE_D, g_ds[i], 1'b1, rr);
      scmd(`SFSB_SC_FREE_P, g_ps[i], 1'b0, rr);
    end
    expect_quiet();
  endtask

  logic [8*24-1:0] test_sel;
  int seed;

  task automatic t_suite();
    if (test_sel == "all" || test_sel == "regs")         t_regs();
    if (test_sel == "all" || test_sel == "basic")        t_basic();
    if (test_sel == "all" || test_sel == "partial")      t_partial();
    if (test_sel == "all" || test_sel == "concurrent")   t_concurrent();
    if (test_sel == "all" || test_sel == "backpressure") t_backpressure();
    if (test_sel == "all" || test_sel == "exhaust")      t_exhaust();
    if (test_sel == "all" || test_sel == "invalid")      t_invalid();
    if (test_sel == "all" || test_sel == "ecc")          t_ecc();
    if (test_sel == "all" || test_sel == "corrupt")      t_corrupt();
    if (test_sel == "all" || test_sel == "owner")        t_owner();
    if (test_sel == "all" || test_sel == "cache")        t_cache();
    if (test_sel == "all" || test_sel == "durable")      t_durable();
    if (test_sel == "all" || test_sel == "crypt")        t_crypt();
    if (test_sel == "all" || test_sel == "random")       t_random();
    if (test_sel == "all" || test_sel == "arb")          t_arb();
    if (test_sel == "all" || test_sel == "reset")        t_reset();
  endtask

  // ======================================================================
  initial begin
    if (!$value$plusargs("TEST=%s", test_sel)) test_sel = "all";
    if ($value$plusargs("SEED=%d", seed)) void'($urandom(seed));
    for (int i = 0; i < 1024; i++) gold_ver[i] = 8'd0;
    for (int i = 0; i < NPAGES * PIMG_BEATS; i++) flash[i] = 64'hFFFF_FFFF_FFFF_FFFF;
    for (int t = 0; t < 256; t++) begin outst[t] = 1'b0; done[t] = 1'b0; end
    $display("tb_sfsb: banks=%0d LB=%0d page_lbs=%0d dslots=%0d pslots=%0d host_max_out=%0d crypto=%0d dram=%0d",
             NUM_BANKS, LB_BYTES, PAGE_LBS, NUM_DSLOTS, NUM_PSLOTS, HOST_MAX_OUT, CRYPTO_EN, EXT_DRAM_EN);
    $display("tb_sfsb: page image %0d beats (%0d B), page slot stride %0d beats, buffer %0d beats",
             PIMG_BEATS, PIMG_BEATS * 8, PSLOT_BEATS, dut.TOTAL_BEATS);
    cyc(5);
    rst_n = 1'b1;
    while (!init_done) cyc(1);
    cyc(2);
    set_cfg(1'b1, 1'b0, 8'd4, 8'd1);

`ifdef SFSB_ONLY
    // one task per binary for the Verilator flow (-DSFSB_ONLY=t_suite or t_perf):
    // that tool inlines every task into its caller, and the perf task's unrolled
    // counter dumps alone would add ~25 MB of C++ to the suite binary.
    `SFSB_ONLY();
`else
    if (test_sel == "perf") t_perf();
    else                    t_suite();
`endif
    cyc(20);
    cur_test = "final";
    chk(v_fw == 0 && v_nd == 0 && v_hm == 0 && v_xm == 0, "SFB2 protocol checkers: zero violations");
    chk(cm_bad == 0, "commit monitor: no completion before its destination writes were acknowledged");
    $display("tb_sfsb: commit monitor checked %0d completions, %0d violations", cm_cpl, cm_bad);
    $display("tb_sfsb: accepted %0d descriptors, %0d completions, protocol violations fw/nand/host/dram = %0d/%0d/%0d/%0d",
             n_acc, n_cpl, v_fw, v_nd, v_hm, v_xm);
    if (n_err == 0) $display("TB RESULT: PASS (%0d checks)", n_chk);
    else            $display("TB RESULT: FAIL (%0d of %0d checks failed)", n_err, n_chk);
    $finish;
  end

  initial begin
    #400ms;
    $display("TB RESULT: FAIL (global timeout)");
    $finish;
  end
endmodule

`default_nettype wire
