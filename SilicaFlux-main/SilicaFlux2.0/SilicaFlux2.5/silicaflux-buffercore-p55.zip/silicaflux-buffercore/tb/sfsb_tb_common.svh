// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_tb_common.svh   (VERIFICATION ONLY)
// Firmware BFM, scoreboard and golden-model helpers shared by tb_sfsb and the
// integration benches.  Included INSIDE a testbench module, which must declare:
//   clk, rst_n, fw_req_* / fw_rsp_*, u_hm (sfsb_tb_mem), LB_BEATS, LB_BYTES,
//   PAGE_LBS, HWORDS, n_chk, n_err, outst[], done[], c_w0/1/2[], n_acc, n_cpl,
//   order[], n_order, gold_ver[], tid_next, h_next, last_tid, cur_test.
// =============================================================================
  task automatic chk(input logic c, input logic [8*72-1:0] msg);
    n_chk++;
    if (c !== 1'b1) begin
      n_err++;
      $display("[%0t] ERROR (%0s): %0s", $time, cur_test, msg);
    end
  endtask

  // ------------------------------------------------------------ helpers
  task automatic cyc(input int n);
    repeat (n) @(posedge clk);
    #1;
  endtask

  function automatic [63:0] pat(input [31:0] lba, input int beat, input [7:0] ver);
    logic [63:0] x;
    x = {lba, 16'(beat), ver, 8'hA5};
    x = x ^ (x << 13);
    x = x ^ (x >> 7);
    x = x ^ (x << 17);
    x = x ^ {ver, 24'h5A5A5A, lba};
    pat = x;
  endfunction

  function automatic [31:0] crc32c_beat(input [31:0] c, input [63:0] d);
    logic [31:0] x;
    x = c;
    for (int b = 0; b < 8; b++) begin
      x = x ^ {24'd0, d[8*b +: 8]};
      for (int i = 0; i < 8; i++) x = x[0] ? ((x >> 1) ^ 32'h82F6_3B78) : (x >> 1);
    end
    crc32c_beat = x;
  endfunction

  function automatic [31:0] lb_crc(input [31:0] lba, input [7:0] ver);
    logic [31:0] c;
    c = 32'hFFFF_FFFF;
    for (int b = 0; b < LB_BEATS; b++) c = crc32c_beat(c, pat(lba, b, ver));
    lb_crc = ~c;
  endfunction




  function automatic [31:0] halloc(input int nlb);
    halloc = h_next;
    h_next = h_next + 32'(nlb * LB_BYTES);
    if (h_next + 32'(PAGE_LBS * LB_BYTES) > 32'(HWORDS * 8)) h_next = 32'h0;
  endfunction

  task automatic new_tid(output logic [7:0] t);
    while (outst[tid_next] || tid_next == 8'd0) tid_next = tid_next + 8'd1;
    t = tid_next;
    tid_next = tid_next + 8'd1;
  endtask

  // ------------------------------------------------------------ firmware port BFM
  // All TB activity starts and ends 1 ns after a rising edge; handshakes are
  // sampled 2 ns after the edge (combinational logic settled).
  // The bus protocol runs in one always-active server process; callers post a
  // request and wait once (keeps Verilator's inlined coroutines small).
  logic        fwq_wr, fwq_er;
  logic [31:0] fwq_a, fwq_wd, fwq_rd;
  logic [3:0]  fwq_ws;
  int          fwq_req = 0, fwq_ack = 0;

  task automatic fw_acc(input logic wr, input logic [31:0] a, input logic [31:0] wd, input logic [3:0] ws,
                        output logic [31:0] rd, output logic er);
    fwq_wr = wr; fwq_a = a; fwq_wd = wd; fwq_ws = ws;
    fwq_req = fwq_req + 1;
    wait (fwq_ack == fwq_req);
    rd = fwq_rd;
    er = fwq_er;
  endtask

  initial begin : fw_server
    forever begin
      wait (fwq_req != fwq_ack);
      fw_req_valid = 1'b1; fw_req_write = fwq_wr; fw_req_addr = fwq_a; fw_req_wdata = fwq_wd; fw_req_wstrb = fwq_ws;
      #1;
      while (!fw_req_ready && rst_n) begin @(posedge clk); #2; end
      @(posedge clk); #1;
      fw_req_valid = 1'b0;
      #1;
      while (!fw_rsp_valid && rst_n) begin @(posedge clk); #2; end
      fwq_rd = fw_rsp_rdata;
      fwq_er = fw_rsp_error;
      @(posedge clk); #1;
      fwq_ack = fwq_req;
    end
  end

  task automatic csr_wr(input logic [11:0] r, input logic [31:0] v);
    logic [31:0] d; logic e;
    fw_acc(1'b1, {20'd0, r}, v, 4'hF, d, e);
    chk(!e, "CSR write error response");
  endtask

  task automatic csr_rd(input logic [11:0] r, output logic [31:0] v);
    logic e;
    fw_acc(1'b0, {20'd0, r}, 32'd0, 4'h0, v, e);
    chk(!e, "CSR read error response");
  endtask

  task automatic scmd(input logic [3:0] cmd, input logic [7:0] slot, input logic flag, output logic [31:0] rsp);
    csr_wr(`SFSB_CSR_SCMD, {15'd0, flag, slot, 4'd0, cmd});
    csr_rd(`SFSB_CSR_SRSP, rsp);
  endtask

  task automatic scmd_ok(input logic [3:0] cmd, input logic [7:0] slot);
    logic [31:0] r;
    scmd(cmd, slot, 1'b0, r);
    chk(r[7:0] == `SFSB_SR_OK, "slot command failed");
    if (r[7:0] != `SFSB_SR_OK) $display("    cmd %0d slot %0d -> code %0h", cmd, slot, r[7:0]);
  endtask

  task automatic alloc_d(output logic [7:0] s);
    logic [31:0] r;
    scmd(`SFSB_SC_ALLOC_D, 8'd0, 1'b0, r);
    chk(r[7:0] == `SFSB_SR_OK, "ALLOC_D failed");
    s = r[15:8];
  endtask

  task automatic alloc_p(output logic [7:0] s);
    logic [31:0] r;
    scmd(`SFSB_SC_ALLOC_P, 8'd0, 1'b0, r);
    chk(r[7:0] == `SFSB_SR_OK, "ALLOC_P failed");
    s = r[15:8];
  endtask

  task automatic submit(input logic [3:0] opc, input logic [1:0] cls, input logic crypt, input logic [7:0] tid,
                        input logic [7:0] ds, input logic [7:0] ps, input logic [3:0] lbf, input logic [3:0] lbc,
                        input logic [31:0] haddr, input logic [31:0] lba, output logic [7:0] code);
    logic [31:0] v;
    csr_wr(`SFSB_CSR_DESC0, {8'd0, lbc, lbf, tid, crypt, 1'b0, cls, opc});
    csr_wr(`SFSB_CSR_DESC1, {16'd0, ps, ds});
    csr_wr(`SFSB_CSR_DESC2, haddr);
    csr_wr(`SFSB_CSR_DESC3, lba);
    csr_wr(`SFSB_CSR_SUBMIT, 32'd1);
    csr_rd(`SFSB_CSR_SUBMIT, v);
    code = v[7:0];
    chk(v[8] == (code == `SFSB_SUB_OK), "SUBMIT accepted flag inconsistent");
    if (code == `SFSB_SUB_OK) begin
      chk(!outst[tid], "TB: TID reused while in flight");
      outst[tid] = 1'b1;
      done[tid]  = 1'b0;
      n_acc++;
    end
  endtask

  task automatic poll_cq(output logic got);
    logic [31:0] st, w0, w1, w2;
    csr_rd(`SFSB_CSR_CPL_STAT, st);
    got = st[0];
    if (got) begin
      csr_rd(`SFSB_CSR_CPL0, w0);
      csr_rd(`SFSB_CSR_CPL1, w1);
      csr_rd(`SFSB_CSR_CPL2, w2);
      csr_wr(`SFSB_CSR_CPL_POP, 32'd1);
      chk(outst[w0[7:0]] === 1'b1, "completion for a TID not in flight (duplicate / unsolicited)");
      outst[w0[7:0]] = 1'b0;
      done[w0[7:0]]  = 1'b1;
      c_w0[w0[7:0]]  = w0;
      c_w1[w0[7:0]]  = w1;
      c_w2[w0[7:0]]  = w2;
      n_cpl++;
      if (n_order < 512) begin order[n_order] = w0[7:0]; n_order++; end
    end
  endtask

  task automatic wait_tid(input logic [7:0] t);
    logic g;
    int guard;
    guard = 0;
    while (!done[t] && guard <= 100000) begin
      poll_cq(g);
      if (!g) cyc(8);
      guard++;
    end
    if (!done[t]) begin
      chk(1'b0, "timeout waiting for a completion");
      $display("    tid %0d", t);
    end
  endtask

  // pop completions until the CQ is empty AND no descriptor is queued or running
  task automatic drain_cq();
    logic g;
    logic [31:0] stv;
    int idle, guard;
    idle = 0; guard = 0;
    while (idle < 3 && guard < 200000) begin
      poll_cq(g);
      csr_rd(`SFSB_CSR_STATUS, stv);
      if (g || stv[2]) idle = 0; else idle++;
      if (!g) cyc(16);
      guard++;
    end
    chk(guard < 200000, "drain: subsystem became idle");
  endtask

  function automatic [7:0] st_of(input logic [7:0] t);
    st_of = c_w0[t][23:16];
  endfunction

  // submit, expect acceptance, wait, return status
  task automatic run_desc(input logic [3:0] opc, input logic [1:0] cls, input logic crypt, input logic [7:0] ds,
                          input logic [7:0] ps, input logic [3:0] lbf, input logic [3:0] lbc,
                          input logic [31:0] haddr, input logic [31:0] lba, output logic [7:0] st);
    logic [7:0] t, code;
    new_tid(t);
    last_tid = t;
    submit(opc, cls, crypt, t, ds, ps, lbf, lbc, haddr, lba, code);
    chk(code == `SFSB_SUB_OK, "descriptor rejected");
    if (code != `SFSB_SUB_OK) begin
      $display("    opc %0d ds %0d ps %0d lbf %0d lbc %0d -> code %0h", opc, ds, ps, lbf, lbc, code);
      st = 8'hFF;
    end else begin
      wait_tid(t);
      st = st_of(t);
    end
  endtask

  // ------------------------------------------------------------ host memory helpers
  task automatic host_fill(input logic [31:0] ha, input logic [31:0] lba, input int n, input logic [7:0] ver);
    for (int k = 0; k < n; k++)
      for (int b = 0; b < LB_BEATS; b++) u_hm.mem[(ha >> 3) + k * LB_BEATS + b] = pat(lba + 32'(k), b, ver);
  endtask

  task automatic host_clear(input logic [31:0] ha, input int n);
    for (int w = 0; w < n * LB_BEATS; w++) begin
      u_hm.mem[(ha >> 3) + w]  = 64'hDEAD_BEEF_DEAD_BEEF;
      u_hm.wcnt[(ha >> 3) + w] = 8'd0;
    end
  endtask

  // compare host buffer with the golden data; also: every word written exactly once
  task automatic host_check(input logic [31:0] ha, input logic [31:0] lba, input int n, input logic [8*40-1:0] tag);
    int bad, dup;
    bad = 0; dup = 0;
    for (int k = 0; k < n; k++)
      for (int b = 0; b < LB_BEATS; b++) begin
        if (u_hm.mem[(ha >> 3) + k * LB_BEATS + b] !== pat(lba + 32'(k), b, gold_ver[(lba + 32'(k)) % 1024])) bad++;
        if (u_hm.wcnt[(ha >> 3) + k * LB_BEATS + b] != 8'd1) dup++;
      end
    chk(bad == 0, "host data mismatch against golden model");
    chk(dup == 0, "host word written not exactly once (duplicate or dropped beat)");
    if (bad != 0 || dup != 0) $display("    %0s: %0d bad words, %0d words not written exactly once", tag, bad, dup);
  endtask


  task automatic set_cfg(input logic en, input logic wce, input logic [7:0] wh, input logic [7:0] wg);
    csr_wr(`SFSB_CSR_CFG, {8'd0, wg, wh, 5'd0, wce, 1'b0, en});
  endtask
