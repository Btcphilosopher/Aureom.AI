// =============================================================================
// SilicaFlux BufferCore (Project 55) :: sfsb_tb_mem   (VERIFICATION ONLY)
// Behavioural SFB2 slave (64-bit) used as host memory and as external DRAM.
//   * pipelined: up to MAX_OUT outstanding transactions, responses in order;
//   * random request back-pressure (ready_pct) and random latency
//     [lat_min, lat_max] (>= 1, rule R5), both settable at run time;
//   * a write is performed at acceptance, its response follows (R7);
//   * error window [err_lo, err_hi] (byte addresses) answers rsp_error = 1;
//   * wcnt[] counts writes per word, so the testbench can prove that no
//     transfer was duplicated or dropped.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sfsb_tb_mem #(
  parameter int          WORDS   = 32768,
  parameter logic [31:0] BASE    = 32'h0,
  parameter int          MAX_OUT = 8
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        req_valid,
  output logic             req_ready,
  input  wire logic        req_write,
  input  wire logic [31:0] req_addr,
  input  wire logic [63:0] req_wdata,
  input  wire logic [7:0]  req_wstrb,
  output logic             rsp_valid,
  input  wire logic        rsp_ready,
  output logic [63:0]      rsp_rdata,
  output logic             rsp_error
);
  logic [63:0] mem  [WORDS];
  logic [7:0]  wcnt [WORDS];

  int unsigned ready_pct = 100;
  int unsigned lat_min   = 1;
  int unsigned lat_max   = 1;
  logic [31:0] err_lo    = 32'hFFFF_FFFF;
  logic [31:0] err_hi    = 32'h0000_0000;

  localparam int RQ = 32;
  logic [63:0]   q_data [RQ];
  logic          q_err  [RQ];
  logic [63:0]   q_time [RQ];
  int            q_wp, q_rp, q_cnt;
  logic [63:0]   now, last_time;
  logic          rdy_rnd;
  int            c_v;
  logic [63:0]   t_v;
  logic          e_v;
  logic [63:0]   d_v;

  initial begin
    for (int i = 0; i < WORDS; i++) begin mem[i] = '0; wcnt[i] = '0; end
  end

  assign req_ready = rdy_rnd && (q_cnt < MAX_OUT) && rst_n;
  assign rsp_valid = (q_cnt > 0) && (q_time[q_rp] <= now);
  assign rsp_rdata = rsp_valid ? q_data[q_rp] : 64'd0;
  assign rsp_error = rsp_valid ? q_err[q_rp]  : 1'b0;

  wire [31:0] off = req_addr - BASE;
  wire        in_range = (off[31:3] < WORDS) && (req_addr >= BASE);

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      q_wp <= 0; q_rp <= 0; q_cnt <= 0; now <= 0; last_time <= 0; rdy_rnd <= 1'b0;
    end else begin
      c_v = q_cnt;
      now     <= now + 1;
      rdy_rnd <= ($urandom_range(99, 0) < ready_pct);
      if (rsp_valid && rsp_ready) begin
        q_rp <= (q_rp + 1) % RQ;
        c_v = c_v - 1;
      end
      if (req_valid && req_ready) begin
        t_v = now + 64'(lat_min) + 64'($urandom_range(lat_max - lat_min, 0));
        if (t_v < last_time) t_v = last_time;
        e_v = !in_range || (req_addr >= err_lo && req_addr <= err_hi) || (req_addr[2:0] != 3'd0);
        d_v = 64'd0;
        if (!e_v) begin
          if (req_write) begin
            for (int b = 0; b < 8; b++)
              if (req_wstrb[b]) mem[off[31:3]][8*b +: 8] = req_wdata[8*b +: 8];
            if (wcnt[off[31:3]] != 8'hFF) wcnt[off[31:3]] = wcnt[off[31:3]] + 1;
          end else begin
            d_v = mem[off[31:3]];
          end
        end
        q_data[q_wp] <= d_v;
        q_err[q_wp]  <= e_v;
        q_time[q_wp] <= t_v;
        last_time    <= t_v;
        q_wp <= (q_wp + 1) % RQ;
        c_v = c_v + 1;
      end
      q_cnt <= c_v;
    end
  end
endmodule

`default_nettype wire
