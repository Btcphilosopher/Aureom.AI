// sf-conformance: simt_stack
// SF-G1 per-warp execution-mask and reconvergence stack.
//
// Reference model: sim/sfg1/simt.py (class SimtStack).  Semantics: docs/03-execution-model.md.
//
// One command is accepted per cycle when `ready` is high.  A command updates the
// stack in a single clock edge; the unit then spends one or more cycles popping
// finished paths and reconvergence entries (`ready` low) before the observable
// state (pc, active, live, depth, done, rpc_violation) is valid again.  The
// number of resolution cycles is NOT architectural; the settled state is.
//
//   SIMT_INIT   cmd_pc = entry pc, cmd_mask = launch mask of live lanes
//   SIMT_SEQ    non-control instruction completed: pc <- pc + 1
//   SIMT_JUMP   uniform jump to cmd_pc
//   SIMT_BRANCH cmd_pc = target, cmd_reconv = reconvergence pc,
//               cmd_mask = lanes whose branch condition is true (only active lanes count)
//   SIMT_EXIT   active lanes terminate
//
// `overflow` reports that the last BRANCH needed more entries than DEPTH allows; the
// stack is then unchanged (a precise fault).
module sf_g1_simt_stack
  import sf_g1_pkg::*;
#(
  parameter int L    = LANES,
  parameter int DEPTH = SIMT_STACK_DEPTH,
  parameter int PCW  = PC_W,
  parameter int RPCN = RPC_NONE
) (
  input  logic                         clk,
  input  logic                         rst_n,

  input  logic                         cmd_valid,
  input  sf_simt_cmd_e                 cmd,
  input  logic [PCW-1:0]               cmd_pc,
  input  logic [PCW-1:0]               cmd_reconv,
  input  logic [L-1:0]                 cmd_mask,

  output logic                         ready,
  output logic [PCW-1:0]               pc,
  output logic [L-1:0]                 active,
  output logic [L-1:0]                 live,
  output logic [$clog2(DEPTH+1)-1:0]   depth,
  output logic                         done,
  output logic                         rpc_violation,
  output logic                         overflow
);
  localparam int SPW  = $clog2(DEPTH + 1);   // stack-pointer width (0..DEPTH)
  localparam int IDXW = (DEPTH > 1) ? $clog2(DEPTH) : 1;  // entry-index width (0..DEPTH-1)

  // ---- storage ---------------------------------------------------------------
  logic [PCW-1:0] e_pc   [DEPTH];
  logic [PCW-1:0] e_rpc  [DEPTH];
  logic [L-1:0]   e_mask [DEPTH];
  logic [SPW-1:0] sp;
  logic [L-1:0]   live_q;
  logic           resolving;
  logic           ovf_q;

  // ---- top-of-stack view -----------------------------------------------------
  logic           have_tos;
  logic [IDXW-1:0] tos_i, push_i0, push_i1;   // top entry; first and second free entries
  logic [PCW-1:0] tos_pc, tos_rpc;
  logic [L-1:0]   tos_mask, act;

  assign have_tos = (sp != '0);
  assign tos_i    = IDXW'(sp - SPW'(1));
  assign push_i0  = IDXW'(sp);                 // only written when no overflow, so never past DEPTH-1
  assign push_i1  = IDXW'(sp + SPW'(1));
  assign tos_pc   = have_tos ? e_pc[tos_i]   : '0;
  assign tos_rpc  = have_tos ? e_rpc[tos_i]  : PCW'(RPCN);
  assign tos_mask = have_tos ? e_mask[tos_i] : '0;
  assign act      = tos_mask & live_q;

  assign pc            = tos_pc;
  assign active        = act;
  assign live          = live_q;
  assign depth         = sp;
  assign done          = ~have_tos;
  assign rpc_violation = have_tos && (tos_rpc != PCW'(RPCN)) && (tos_pc > tos_rpc);
  assign ready         = ~resolving;
  assign overflow      = ovf_q;

  // ---- branch decision (combinational) ---------------------------------------
  logic [L-1:0] taken, fall;
  logic         divergent, reuse, fall_valid, taken_valid, will_overflow;
  logic [PCW-1:0] pc_plus1;
  logic [2:0]   needed;           // entries to add beyond the current top
  logic [SPW:0] sp_wide;

  assign taken       = act & cmd_mask;
  assign fall        = act & ~cmd_mask;
  assign divergent   = (taken != '0) && (fall != '0);
  assign pc_plus1    = tos_pc + PCW'(1);
  assign fall_valid  = (pc_plus1 != cmd_reconv);
  assign taken_valid = (cmd_pc != cmd_reconv);
  assign reuse       = (tos_rpc == cmd_reconv);
  assign sp_wide     = {1'b0, sp};

  always_comb begin
    if (reuse) begin
      if (fall_valid && taken_valid) needed = 3'd1;
      else                           needed = 3'd0;
    end else begin
      needed = 3'(fall_valid) + 3'(taken_valid);
    end
  end
  assign will_overflow = divergent && ((sp_wide + (SPW+1)'(needed)) > (SPW+1)'(DEPTH));

  // ---- sequential update -----------------------------------------------------
  logic pop_now;
  assign pop_now = have_tos && ((act == '0) || (tos_pc == tos_rpc));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sp        <= '0;
      live_q    <= '0;
      resolving <= 1'b0;
      ovf_q     <= 1'b0;
    end else if (resolving) begin
      // Resolution: pop finished paths / reached reconvergence entries.
      if (pop_now) sp <= sp - SPW'(1);
      else         resolving <= 1'b0;
    end else if (cmd_valid) begin
      resolving <= 1'b1;
      ovf_q     <= 1'b0;
      case (cmd)
        SIMT_INIT: begin
          e_pc[0]   <= cmd_pc;
          e_rpc[0]  <= PCW'(RPCN);
          e_mask[0] <= cmd_mask;
          sp        <= SPW'(1);
          live_q    <= cmd_mask;
        end
        SIMT_SEQ: begin
          if (have_tos) e_pc[tos_i] <= pc_plus1;
        end
        SIMT_JUMP: begin
          if (have_tos) e_pc[tos_i] <= cmd_pc;
        end
        SIMT_EXIT: begin
          live_q <= live_q & ~act;
        end
        SIMT_BRANCH: begin
          if (have_tos) begin
            if (taken == '0) begin
              e_pc[tos_i] <= pc_plus1;
            end else if (fall == '0) begin
              e_pc[tos_i] <= cmd_pc;
            end else if (will_overflow) begin
              ovf_q <= 1'b1;                   // precise: no state change
            end else if (reuse) begin
              if (fall_valid) begin
                e_pc[tos_i]   <= pc_plus1;     // top becomes the fall-through path ...
                e_mask[tos_i] <= fall;
                if (taken_valid) begin         // ... and the taken path goes on top of it
                  e_pc[push_i0]   <= cmd_pc;
                  e_rpc[push_i0]  <= cmd_reconv;
                  e_mask[push_i0] <= taken;
                  sp         <= sp + SPW'(1);
                end
              end else if (taken_valid) begin
                e_pc[tos_i]   <= cmd_pc;
                e_mask[tos_i] <= taken;
              end else begin
                e_pc[tos_i]   <= cmd_reconv;   // both paths already at the join
              end
            end else begin
              e_pc[tos_i] <= cmd_reconv;       // top becomes the reconvergence entry
              if (fall_valid && taken_valid) begin
                e_pc[push_i0]  <= pc_plus1;    e_rpc[push_i0] <= cmd_reconv;  e_mask[push_i0] <= fall;
                e_pc[push_i1]  <= cmd_pc;      e_rpc[push_i1] <= cmd_reconv;  e_mask[push_i1] <= taken;
                sp             <= sp + SPW'(2);
              end else if (fall_valid) begin
                e_pc[push_i0] <= pc_plus1;      e_rpc[push_i0] <= cmd_reconv;  e_mask[push_i0] <= fall;
                sp       <= sp + SPW'(1);
              end else if (taken_valid) begin
                e_pc[push_i0] <= cmd_pc;        e_rpc[push_i0] <= cmd_reconv;  e_mask[push_i0] <= taken;
                sp       <= sp + SPW'(1);
              end
            end
          end
        end
        default: ;
      endcase
    end
  end
endmodule
