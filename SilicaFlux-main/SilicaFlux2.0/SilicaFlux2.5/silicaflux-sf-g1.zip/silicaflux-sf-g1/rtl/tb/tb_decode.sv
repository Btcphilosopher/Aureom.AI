// Conformance testbench: sf_g1_decode against sim/sfg1/isa.py vectors.  Run with +VEC=<decode.vec>.
`timescale 1ns/1ps
module tb_decode;
  import sf_g1_pkg::*;
  logic [31:0]  insn;
  sf_decoded_t  dec;
  sf_g1_decode dut (.insn(insn), .dec(dec));

  reg [8*512-1:0] path;
  integer fd, n, i, rc, errors;
  logic [31:0]             vinsn;
  logic [SF_DECODED_W-1:0] vexp;

  initial begin
    errors = 0;
    if (!$value$plusargs("VEC=%s", path)) begin
      $display("TB_RESULT decode FAIL missing +VEC");
      $finish;
    end
    fd = $fopen(path, "r");
    if (fd == 0) begin
      $display("TB_RESULT decode FAIL cannot open vector file");
      $finish;
    end
    rc = $fscanf(fd, "%d\n", n);
    for (i = 0; i < n; i = i + 1) begin
      rc = $fscanf(fd, "%h %h\n", vinsn, vexp);
      insn = vinsn;
      #1;
      if (dec !== vexp) begin
        errors = errors + 1;
        if (errors <= 10) $display("MISMATCH #%0d insn=%08h got=%h exp=%h", i, insn, dec, vexp);
      end
    end
    if (errors == 0) $display("TB_RESULT decode PASS vectors=%0d", n);
    else             $display("TB_RESULT decode FAIL errors=%0d of %0d", errors, n);
    $finish;
  end
endmodule
