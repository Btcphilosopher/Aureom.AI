// Conformance testbench: sf_g1_alu against sim/sfg1/alu.py vectors.  Run with +VEC=<alu.vec>.
`timescale 1ns/1ps
module tb_alu;
  import sf_g1_pkg::*;
  logic [3:0]  fn;
  logic [31:0] a, b, y;
  sf_g1_alu dut (.fn(fn), .a(a), .b(b), .y(y));

  reg [8*512-1:0] path;
  integer fd, n, i, rc, errors;
  logic [3:0]  vfn;
  logic [31:0] va, vb, vy;

  initial begin
    errors = 0;
    if (!$value$plusargs("VEC=%s", path)) begin
      $display("TB_RESULT alu FAIL missing +VEC");
      $finish;
    end
    fd = $fopen(path, "r");
    if (fd == 0) begin
      $display("TB_RESULT alu FAIL cannot open vector file");
      $finish;
    end
    rc = $fscanf(fd, "%d\n", n);
    for (i = 0; i < n; i = i + 1) begin
      rc = $fscanf(fd, "%h %h %h %h\n", vfn, va, vb, vy);
      fn = vfn; a = va; b = vb;
      #1;
      if (y !== vy) begin
        errors = errors + 1;
        if (errors <= 10) $display("MISMATCH #%0d fn=%0d a=%08h b=%08h got=%08h exp=%08h", i, fn, a, b, y, vy);
      end
    end
    if (errors == 0) $display("TB_RESULT alu PASS vectors=%0d", n);
    else             $display("TB_RESULT alu FAIL errors=%0d of %0d", errors, n);
    $finish;
  end
endmodule
