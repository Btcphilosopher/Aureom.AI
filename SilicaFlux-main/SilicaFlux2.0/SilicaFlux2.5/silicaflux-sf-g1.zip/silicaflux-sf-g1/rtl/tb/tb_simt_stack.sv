// Conformance testbench: sf_g1_simt_stack against sim/sfg1/simt.py command streams.
// Run with +VEC=<simt_stack.vec>.  Each record is a command followed by the reference
// model's settled state; the testbench waits for `ready` before comparing.
`timescale 1ns/1ps
module tb_simt_stack;
  import sf_g1_pkg::*;
  localparam int L = LANES;
  localparam int SPW = $clog2(SIMT_STACK_DEPTH + 1);

  logic clk = 1'b0;
  logic rst_n;
  logic cmd_valid;
  sf_simt_cmd_e cmd;
  logic [PC_W-1:0] cmd_pc, cmd_reconv;
  logic [L-1:0]    cmd_mask;
  logic            ready, done, rpc_violation, overflow;
  logic [PC_W-1:0] pc;
  logic [L-1:0]    active, live;
  logic [SPW-1:0]  depth;

  sf_g1_simt_stack dut (.clk(clk), .rst_n(rst_n), .cmd_valid(cmd_valid), .cmd(cmd),
                        .cmd_pc(cmd_pc), .cmd_reconv(cmd_reconv), .cmd_mask(cmd_mask),
                        .ready(ready), .pc(pc), .active(active), .live(live), .depth(depth),
                        .done(done), .rpc_violation(rpc_violation), .overflow(overflow));

  always #5 clk = ~clk;

  reg [8*512-1:0] path;
  integer fd, n, i, rc, errors, guard;
  logic [2:0]      v_cmd;
  logic [PC_W-1:0] v_pc, v_rc, e_pc;
  logic [L-1:0]    v_mask, e_act, e_live;
  logic [SPW-1:0]  e_depth;
  logic            e_done, e_viol, e_ovf;

  initial begin
    errors = 0;
    cmd_valid = 1'b0; cmd = SIMT_INIT; cmd_pc = '0; cmd_reconv = '0; cmd_mask = '0;
    rst_n = 1'b0;
    repeat (3) @(negedge clk);
    rst_n = 1'b1;
    if (!$value$plusargs("VEC=%s", path)) begin
      $display("TB_RESULT simt_stack FAIL missing +VEC");
      $finish;
    end
    fd = $fopen(path, "r");
    if (fd == 0) begin
      $display("TB_RESULT simt_stack FAIL cannot open vector file");
      $finish;
    end
    rc = $fscanf(fd, "%d\n", n);
    for (i = 0; i < n; i = i + 1) begin
      rc = $fscanf(fd, "%h %h %h %h %h %h %h %h %h %h %h\n",
                   v_cmd, v_pc, v_rc, v_mask, e_pc, e_act, e_live, e_depth, e_done, e_viol, e_ovf);
      @(negedge clk);
      cmd_valid = 1'b1; cmd = sf_simt_cmd_e'(v_cmd); cmd_pc = v_pc; cmd_reconv = v_rc; cmd_mask = v_mask;
      @(negedge clk);
      cmd_valid = 1'b0;
      guard = 0;
      while (!ready && guard < 1000) begin @(negedge clk); guard = guard + 1; end
      if (guard >= 1000) begin
        errors = errors + 1;
        $display("TIMEOUT #%0d: ready never returned", i);
      end
      if (pc !== e_pc || active !== e_act || live !== e_live || depth !== e_depth ||
          done !== e_done || rpc_violation !== e_viol || overflow !== e_ovf) begin
        errors = errors + 1;
        if (errors <= 10)
          $display("MISMATCH #%0d cmd=%0d pc=%0h rc=%0h mask=%0h | got pc=%0h act=%0h live=%0h depth=%0d done=%0b viol=%0b ovf=%0b | exp pc=%0h act=%0h live=%0h depth=%0d done=%0b viol=%0b ovf=%0b",
                   i, v_cmd, v_pc, v_rc, v_mask, pc, active, live, depth, done, rpc_violation, overflow,
                   e_pc, e_act, e_live, e_depth, e_done, e_viol, e_ovf);
      end
    end
    if (errors == 0) $display("TB_RESULT simt_stack PASS vectors=%0d", n);
    else             $display("TB_RESULT simt_stack FAIL errors=%0d of %0d", errors, n);
    $finish;
  end
endmodule
