# Reference outputs

Golden results produced by the functional reference model (`sim/sfg1`) for the **default** configuration
(`spec/configs/default.json`, `CFG_HASH` recorded in every `report.json`).

| File | Content |
|---|---|
| `<example>/report.json` | launch parameters, input checksums (FNV-1a), outputs (data or checksum), statistics (`ticks`, `warp_instructions`, `lane_ops`, `simt_efficiency`), kernel SHA-256, commit-trace digest |
| `<example>/commit_trace.jsonl` | canonical architectural commit trace, one warp instruction per line, ordered by (workgroup, warp, sequence) |
| `<example>/kernel.lst` | assembler listing |
| `<example>/kernel.hex` | `$readmemh` image of the kernel |

Examples: `vecadd`, `reduce_sum`, `matmul_i32`, `diverge`. Meaning of the trace fields: `docs/09-verification.md` 9.4.
How to use these against hardware: `docs/12-examples-and-reference.md` 12.3.

```bash
bin/sfg1 examples --check     # re-run and compare (fails on any difference)
bin/sfg1 examples --update    # rewrite after an INTENTIONAL spec/model change; review the diff
```

`ticks` (and `PERF_CYCLES`) are timing in the reference model's tick unit; everything else is architectural.
