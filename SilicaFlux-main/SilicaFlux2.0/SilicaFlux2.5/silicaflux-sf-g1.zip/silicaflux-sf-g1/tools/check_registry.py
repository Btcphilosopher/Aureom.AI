#!/usr/bin/env python3
"""Gate: no RTL without a model-backed conformance test (docs/09-verification.md, rule V1).

Fails when
  * an .sv file under rtl/ (outside rtl/tb/) is neither the `rtl` of a *verified* block nor a
    package-only `support_files` entry covered by a verified block, or lacks
    its `// sf-conformance: <id>` marker;
  * a verified block lacks a testbench, a vector generator in sfg1.vectors.GENERATORS, a
    resolvable reference-model symbol, or its module/TB_RESULT strings;
  * a planned block already has RTL, or has no reference hook / compare statement.
"""
from __future__ import annotations

import importlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "sim"))


def resolve(dotted: str):
    parts = dotted.split(".")
    for i in range(len(parts), 0, -1):
        try:
            obj = importlib.import_module(".".join(parts[:i]))
        except ImportError:
            continue
        for attr in parts[i:]:
            obj = getattr(obj, attr)
        return obj
    raise ImportError(dotted)


def main() -> int:
    from sfg1.vectors import GENERATORS
    doc = json.loads((ROOT / "verification" / "blocks.json").read_text())
    reg = doc["blocks"]
    support = {s_["rtl"]: s_ for s_ in doc.get("support_files", [])}
    errors = []
    ids = [b["id"] for b in reg]
    if len(ids) != len(set(ids)):
        errors.append("duplicate block ids in verification/blocks.json")
    by_rtl = {}
    for b in reg:
        if b["status"] == "verified":
            by_rtl[b["rtl"]] = b
            rtl = ROOT / b["rtl"]
            tb = ROOT / b["testbench"]
            if not rtl.exists():
                errors.append(f"{b['id']}: RTL file {b['rtl']} missing")
            else:
                text = rtl.read_text()
                if f"sf-conformance: {b['id']}" not in text:
                    errors.append(f"{b['rtl']}: missing marker '// sf-conformance: {b['id']}'")
                if not re.search(rf"^\s*module\s+{re.escape(b['top'])}\b", text, re.M):
                    errors.append(f"{b['id']}: module {b['top']} not found in {b['rtl']}")
            if not tb.exists():
                errors.append(f"{b['id']}: testbench {b['testbench']} missing")
            elif f"TB_RESULT {b['id']} PASS" not in tb.read_text():
                errors.append(f"{b['id']}: testbench does not report 'TB_RESULT {b['id']} PASS'")
            if b["vectors"] not in GENERATORS:
                errors.append(f"{b['id']}: no vector generator '{b['vectors']}' in sfg1.vectors.GENERATORS")
            try:
                resolve(b["reference"])
            except Exception as e:  # noqa: BLE001
                errors.append(f"{b['id']}: reference model symbol '{b['reference']}' does not resolve ({e})")
        elif b["status"] == "planned":
            if "rtl" in b:
                errors.append(f"{b['id']}: status is 'planned' but an rtl path is set; promote it to 'verified'")
            if not b.get("compare"):
                errors.append(f"{b['id']}: planned block needs a 'compare' statement")
            try:
                resolve(b["reference"])
            except Exception as e:  # noqa: BLE001
                errors.append(f"{b['id']}: planned reference '{b['reference']}' does not resolve ({e})")
        else:
            errors.append(f"{b['id']}: unknown status {b['status']!r}")
    for f in sorted((ROOT / "rtl").rglob("*.sv")):
        rel = f.relative_to(ROOT).as_posix()
        if rel.startswith("rtl/tb/"):
            continue
        if rel in support:
            s_ = support[rel]
            if re.search(r"^\s*module\b", f.read_text(), re.M):
                errors.append(f"{rel}: support files must be package-only (no module); register it as a block instead")
            for cid in s_["covered_by"]:
                if cid not in ids or reg[ids.index(cid)]["status"] != "verified":
                    errors.append(f"{rel}: covered_by '{cid}' is not a verified block")
            continue
        if rel not in by_rtl:
            errors.append(f"{rel}: RTL file is not registered as a verified block (every RTL block needs a model-backed test)")
    if errors:
        print("CONFORMANCE REGISTRY: FAIL")
        print("\n".join("  - " + e for e in errors))
        return 1
    v = sum(b["status"] == "verified" for b in reg)
    p = sum(b["status"] == "planned" for b in reg)
    print(f"CONFORMANCE REGISTRY: OK ({v} verified blocks, {p} planned)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
