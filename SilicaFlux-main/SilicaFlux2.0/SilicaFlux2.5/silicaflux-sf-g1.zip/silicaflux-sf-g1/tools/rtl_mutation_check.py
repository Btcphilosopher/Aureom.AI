#!/usr/bin/env python3
"""Prove the conformance testbenches can fail: inject RTL bugs and require detection.

Each mutation edits a *copy* of an RTL file; the matching testbench must report
FAIL (or the compile/run must break).  A surviving mutant means the vectors or
the testbench are too weak and the block cannot be trusted by `make gate`.
"""
from __future__ import annotations

import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "sim"))
sys.path.insert(0, str(ROOT / "tools"))

import run_rtl  # noqa: E402
from sfg1.spec import Config  # noqa: E402

# (block id, file, old text, new text, description, config the mutant is run on)
# Overflow needs a stack shallower than 2*lanes-1, which only the "small" config has.
MUTANTS = [
    ("alu", "rtl/sf_g1_alu.sv", "ALU_SAR:   y = sa >>> sh;", "ALU_SAR:   y = a >> sh;", "SAR becomes logical shift"),
    ("alu", "rtl/sf_g1_alu.sv", "ALU_SLT:   y = {31'd0, sa < sb};", "ALU_SLT:   y = {31'd0, a < b};", "SLT compares unsigned"),
    ("alu", "rtl/sf_g1_alu.sv", "assign sh   = b[4:0];", "assign sh   = {1'b0, b[3:0]};", "shift amount drops bit 4"),
    ("alu", "rtl/sf_g1_alu.sv", "ALU_SUB:   y = a - b;", "ALU_SUB:   y = b - a;", "SUB operands swapped"),
    ("simt_stack", "rtl/sf_g1_simt_stack.sv", "assign reuse       = (tos_rpc == cmd_reconv);", "assign reuse       = 1'b0;", "never reuses the top entry"),
    ("simt_stack", "rtl/sf_g1_simt_stack.sv", "(act == '0) || (tos_pc == tos_rpc)", "(tos_pc == tos_rpc)", "does not pop entries with no live lanes"),
    ("simt_stack", "rtl/sf_g1_simt_stack.sv", "live_q <= live_q & ~act;", "live_q <= live_q;", "EXIT leaves lanes live"),
    ("simt_stack", "rtl/sf_g1_simt_stack.sv", "assign fall        = act & ~cmd_mask;", "assign fall        = act & cmd_mask;", "fall-through mask wrong"),
    ("simt_stack", "rtl/sf_g1_simt_stack.sv", "assign will_overflow = divergent && ((sp_wide + (SPW+1)'(needed)) > (SPW+1)'(DEPTH));", "assign will_overflow = 1'b0;", "overflow never detected", "small"),
    ("simt_stack", "rtl/sf_g1_simt_stack.sv", "if (will_overflow) begin", "if (1'b0) begin", "overflow not handled precisely", "small"),
    ("simt_stack", "rtl/sf_g1_simt_stack.sv", "(tos_pc > tos_rpc)", "(tos_pc < tos_rpc)", "layout check inverted"),
    ("simt_stack", "rtl/sf_g1_simt_stack.sv", "e_mask[tos_i] <= fall;", "e_mask[tos_i] <= taken;", "reused top gets the wrong mask"),
    ("decode", "rtl/gen/sf_g1_pkg.sv", "(insn & 32'h00003fff) == 32'h0", "(insn & 32'h00003ffe) == 32'h0", "R-format reserved bit 0 not checked"),
    ("decode", "rtl/gen/sf_g1_pkg.sv", "d.imm2    = insn[10:0];", "d.imm2    = insn[9:0];", "branch reconvergence offset loses a bit"),
    ("decode", "rtl/gen/sf_g1_pkg.sv", "insn[10:0] != '0", "1'b1", "zero reconvergence offset accepted"),
]


def main() -> int:
    from sfg1.vectors import write_vectors
    for cname in ("default", "small"):
        write_vectors(Config.from_file(cname), ROOT / "build" / cname / "vectors")
    blocks = {b["id"]: b for b in run_rtl.registry() if b["status"] == "verified"}
    survived = 0
    for m in MUTANTS:
        bid, rel, old, new, desc = m[:5]
        cname = m[5] if len(m) > 5 else "default"
        cfg = Config.from_file(cname)
        vec_dir = ROOT / "build" / cname / "vectors"
        gen_root = run_rtl.rtl_tree(cfg)
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            shutil.copytree(ROOT / "rtl", tmp / "rtl")
            if cname != "default":   # the generated package for this configuration
                shutil.copy(gen_root / "rtl/gen/sf_g1_pkg.sv", tmp / "rtl/gen/sf_g1_pkg.sv")
                shutil.copy(gen_root / "rtl/gen/sf_g1_decode.sv", tmp / "rtl/gen/sf_g1_decode.sv")
            f = tmp / rel
            text = f.read_text()
            if old not in text:
                print(f"  ?? mutant pattern not found ({bid}: {desc}); update tools/rtl_mutation_check.py")
                survived += 1
                continue
            f.write_text(text.replace(old, new, 1))
            b = blocks[bid]
            vvp = tmp / "m.vvp"
            srcs = [tmp / "rtl/gen/sf_g1_pkg.sv"] + [tmp / bb["rtl"] for bb in blocks.values() if bb["rtl"] != "rtl/gen/sf_g1_pkg.sv"]
            c = subprocess.run(["iverilog", "-g2012", "-o", str(vvp), *map(str, srcs), str(ROOT / b["testbench"])], capture_output=True, text=True)
            if c.returncode != 0:
                verdict = "caught (does not compile)"
            else:
                r = subprocess.run(["vvp", str(vvp), f"+VEC={vec_dir / (b['vectors'] + '.vec')}"], capture_output=True, text=True)
                verdict = "SURVIVED" if f"TB_RESULT {bid} PASS" in r.stdout else "caught"
            if verdict == "SURVIVED":
                survived += 1
            print(f"  {bid:<10s} {desc:<46s} [{cname}] {verdict}")
    print(f"mutation check: {len(MUTANTS) - survived}/{len(MUTANTS)} mutants caught")
    return 1 if survived else 0


if __name__ == "__main__":
    raise SystemExit(main())
