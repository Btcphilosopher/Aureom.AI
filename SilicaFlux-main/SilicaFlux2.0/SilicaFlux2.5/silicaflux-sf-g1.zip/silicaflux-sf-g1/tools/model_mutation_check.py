#!/usr/bin/env python3
"""Prove the differential test can fail: inject bugs into the SIMT stack model and require detection.

The differential test (sim/tests/test_differential.py) compares the SIMT machinery with a per-thread
oracle.  Each mutant below breaks one rule of docs/03; every mutant must make the test fail.  A control
mutant (a behaviour-preserving wrapper) must survive, which shows the harness itself is not vacuous.
"""
import io
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "sim"))

from sfg1 import simt  # noqa: E402
import tests.test_differential as td  # noqa: E402

orig = simt.SimtStack


def patch(name, fn):
    saved = getattr(orig, name)
    setattr(orig, name, fn)
    return saved


def m_no_pop(self):
    e = self.entries
    while e and (e[-1][2] & self.live) == 0:
        e.pop()


def m_exit_keeps_live(self):
    self.entries.pop()
    self._resolve()


def m_invert(self, cond, target, reconv, _b=orig.branch):
    return _b(self, ~cond & 0xFFFFFFFF, target, reconv)


def m_ignore_dead(self):
    e = self.entries
    while e and e[-1][0] == e[-1][1]:
        e.pop()


def m_drop_lane0(self, cond, target, reconv, _b=orig.branch):
    ovf = _b(self, cond, target, reconv)
    if len(self.entries) > 1 and self.entries[-1][2] & 1:
        self.entries[-1][2] &= ~1
    return ovf


def m_control(self, cond, target, reconv, _b=orig.branch):
    return _b(self, cond, target, reconv)


MUTANTS = [
    ("no pop when a path reaches its reconvergence address", "_resolve", m_no_pop, True),
    ("EXIT does not clear the live mask", "exit_", m_exit_keeps_live, True),
    ("branch condition inverted", "branch", m_invert, True),
    ("entries with no live lanes are not dropped", "_resolve", m_ignore_dead, True),
    ("lane 0 dropped from a pushed path", "branch", m_drop_lane0, True),
    ("CONTROL: behaviour-preserving wrapper", "branch", m_control, False),
]


def main() -> int:
    bad = 0
    for desc, name, fn, must_fail in MUTANTS:
        saved = patch(name, fn)
        try:
            suite = unittest.TestSuite([td.DifferentialTest("test_default_config")])
            res = unittest.TextTestRunner(stream=io.StringIO()).run(suite)
        finally:
            setattr(orig, name, saved)
        failed = not res.wasSuccessful()
        ok = failed == must_fail
        bad += not ok
        print(f"  {desc:<56s} {'detected' if failed else 'not detected':<13s} {'ok' if ok else 'UNEXPECTED'}")
    print(f"model mutation check: {'PASS' if not bad else 'FAIL'}")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
