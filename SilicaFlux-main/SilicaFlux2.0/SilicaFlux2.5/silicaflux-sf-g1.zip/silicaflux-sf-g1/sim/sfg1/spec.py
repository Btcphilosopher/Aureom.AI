"""Loaders for the machine-readable SF-G1 specification.

The JSON files in ``spec/`` are the single source of truth.  This module loads
them, validates a hardware configuration, derives dependent sizes and computes
the CFG_HASH that the device, the generated RTL package and the generated C
headers all expose, so that mismatches between hardware and software builds
can be detected at run time.
"""
from __future__ import annotations

import json
import zlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional

ROOT = Path(__file__).resolve().parents[2]
SPEC_DIR = ROOT / "spec"

MASK32 = 0xFFFFFFFF


def clog2(n: int) -> int:
    """Ceiling log2, with clog2(1) == 0 (matches SystemVerilog $clog2)."""
    if n < 1:
        raise ValueError("clog2 requires n >= 1")
    return (n - 1).bit_length()


def popcount(x: int) -> int:
    return bin(x).count("1")


def _load(name: str) -> Dict[str, Any]:
    with open(SPEC_DIR / name, "r", encoding="utf-8") as f:
        return json.load(f)


def _strip_docs(obj: Any) -> Any:
    """Remove prose so that editing documentation never changes CFG_HASH."""
    if isinstance(obj, dict):
        return {k: _strip_docs(v) for k, v in obj.items() if k not in ("doc", "semantics")}
    if isinstance(obj, list):
        return [_strip_docs(v) for v in obj]
    return obj


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"))


class ConfigError(ValueError):
    pass


@dataclass(frozen=True)
class Config:
    """A validated SF-G1 hardware configuration."""

    name: str = "default"
    lanes: int = 8
    warps_per_eg: int = 4
    num_eg: int = 2
    wg_slots_per_eg: int = 2
    smem_bytes_per_eg: int = 8192
    imem_words: int = 1024
    simt_stack_depth: int = 16
    gmem_bytes: int = 1048576
    wdog_reset_ticks: int = 1000000
    # fixed architectural constants (spec/sf_g1_config.json "fixed")
    xlen: int = 32
    insn_bits: int = 32
    num_regs: int = 16
    num_args: int = 8
    max_grid_dim: int = 65535
    reset_ticks: int = 4
    launch_ticks: int = 1

    # ---- derived values -------------------------------------------------
    @property
    def max_wg_threads(self) -> int:
        return self.lanes * self.warps_per_eg

    @property
    def wg_slot_smem_bytes(self) -> int:
        return self.smem_bytes_per_eg // self.wg_slots_per_eg

    @property
    def pc_bits(self) -> int:
        # A PC can reach imem_words (fall-through past the last slot, which faults
        # at fetch) and RPC_NONE == imem_words + 1 must also fit.
        return clog2(self.imem_words + 2)

    @property
    def rpc_none(self) -> int:
        # Larger than any reachable PC, so "pc == rpc" and "pc > rpc" never
        # fire for the bottom stack entry.
        return self.imem_words + 1

    @property
    def lane_bits(self) -> int:
        return clog2(self.lanes)

    @property
    def full_mask(self) -> int:
        return (1 << self.lanes) - 1

    @property
    def stack_overflow_free_depth(self) -> int:
        return 2 * self.lanes - 1

    DERIVED = (
        "max_wg_threads", "wg_slot_smem_bytes", "pc_bits", "rpc_none", "lane_bits",
    )

    # ---- construction ---------------------------------------------------
    @staticmethod
    def parameter_table() -> Dict[str, Any]:
        return _load("sf_g1_config.json")["parameters"]

    @staticmethod
    def fixed_table() -> Dict[str, Any]:
        return _load("sf_g1_config.json")["fixed"]

    @classmethod
    def from_dict(cls, params: Dict[str, Any], name: str = "custom") -> "Config":
        table = cls.parameter_table()
        fixed = cls.fixed_table()
        unknown = set(params) - set(table)
        if unknown:
            raise ConfigError(f"unknown configuration parameter(s): {sorted(unknown)}")
        values: Dict[str, Any] = {k: v["default"] for k, v in table.items()}
        values.update(params)
        kw = dict(values)
        kw.update({k: v["value"] for k, v in fixed.items()})
        cfg = cls(name=name, **kw)
        cfg.validate()
        return cfg

    @classmethod
    def default(cls) -> "Config":
        return cls.from_dict({}, name="default")

    @classmethod
    def from_file(cls, path: Any) -> "Config":
        p = Path(path)
        if not p.exists() and (SPEC_DIR / "configs" / f"{path}.json").exists():
            p = SPEC_DIR / "configs" / f"{path}.json"
        with open(p, "r", encoding="utf-8") as f:
            d = json.load(f)
        return cls.from_dict(d.get("parameters", {}), name=d.get("name", p.stem))

    def with_overrides(self, **kw: Any) -> "Config":
        d = self.parameters()
        d.update(kw)
        return Config.from_dict(d, name=self.name + "+")

    def parameters(self) -> Dict[str, Any]:
        return {k: getattr(self, k) for k in self.parameter_table()}

    # ---- validation -----------------------------------------------------
    def validate(self) -> None:
        table = self.parameter_table()
        for k, meta in table.items():
            v = getattr(self, k)
            if not isinstance(v, int) or isinstance(v, bool):
                raise ConfigError(f"{k} must be an integer, got {v!r}")
            if "allowed" in meta and v not in meta["allowed"]:
                raise ConfigError(f"{k}={v} not in allowed set {meta['allowed']}")
            if "min" in meta and v < meta["min"]:
                raise ConfigError(f"{k}={v} below minimum {meta['min']}")
            if "max" in meta and v > meta["max"]:
                raise ConfigError(f"{k}={v} above maximum {meta['max']}")
        if self.wg_slots_per_eg > self.warps_per_eg:
            raise ConfigError("wg_slots_per_eg must not exceed warps_per_eg")
        if self.smem_bytes_per_eg % (4 * self.wg_slots_per_eg) != 0:
            raise ConfigError("smem_bytes_per_eg must be a multiple of 4*wg_slots_per_eg")
        if self.gmem_bytes % 4096 != 0:
            raise ConfigError("gmem_bytes must be a multiple of 4096")
        if self.max_wg_threads > 0xFFFF:
            raise ConfigError("lanes*warps_per_eg must fit in 16 bits")
        if self.warps_per_eg > 255 or self.num_eg > 255:
            raise ConfigError("register fields limit warps_per_eg and num_eg to 255")

    # ---- caps registers -------------------------------------------------
    def caps_regs(self) -> Dict[str, int]:
        return {
            "CAPS_GEOM": (self.wg_slots_per_eg << 24) | (self.num_eg << 16)
            | (self.warps_per_eg << 8) | self.lanes,
            "CAPS_SMEM": self.smem_bytes_per_eg,
            "CAPS_IMEM": (self.num_regs << 24) | (self.simt_stack_depth << 16) | self.imem_words,
            "CAPS_GMEM": self.gmem_bytes,
            "CAPS_LIMITS": (self.max_grid_dim << 16) | self.max_wg_threads,
        }

    # ---- hash -----------------------------------------------------------
    def hash_payload(self) -> Dict[str, Any]:
        params = {k: getattr(self, k) for k in self.parameter_table()}
        fixed = {k: getattr(self, k) for k in self.fixed_table()}
        return {
            "config": {"parameters": params, "fixed": fixed},
            "isa": _strip_docs(_load("sf_g1_isa.json")),
            "device": _strip_docs(_load("sf_g1_device.json")),
        }

    def cfg_hash(self) -> int:
        """CRC-32 over the canonical, documentation-free specification."""
        data = canonical_json(self.hash_payload()).encode("utf-8")
        return zlib.crc32(data) & MASK32


@dataclass
class DeviceSpec:
    """Parsed view of spec/sf_g1_device.json with convenient lookups."""

    raw: Dict[str, Any] = field(default_factory=lambda: _load("sf_g1_device.json"))

    def __post_init__(self) -> None:
        r = self.raw
        self.device_id = int(r["ids"]["device_id"]["value"], 0)
        self.desc_magic = int(r["ids"]["desc_magic"]["value"], 0)
        self.desc_version = int(r["ids"]["desc_version"]["value"])
        v = r["ids"]["version"]
        self.version_word = (v["major"] << 16) | (v["minor"] << 8) | v["patch"]
        self.reg_by_name = {x["name"]: x for x in r["registers"]}
        self.reg_offset = {x["name"]: int(x["offset"], 0) for x in r["registers"]}
        self.reg_by_offset = {int(x["offset"], 0): x for x in r["registers"]}
        self.launch_errors = {x["name"]: x["code"] for x in r["launch_errors"]}
        self.faults = {x["name"]: x["code"] for x in r["faults"]}
        self.error_names = {v: k for k, v in {**self.launch_errors, **self.faults}.items()}
        self.desc_words = {w["name"]: w["index"] for w in r["descriptor"]["words"]}
        self.desc_size_words = r["descriptor"]["size_words"]
        self.desc_flags = {f["name"]: f["bit"] for f in r["descriptor"]["flags"]}
        self.window_bytes = r["mmio"]["window_bytes"]

    def field(self, reg: str, name: str) -> tuple:
        for f in self.reg_by_name[reg].get("fields", []):
            if f["name"] == name:
                return f["hi"], f["lo"]
        raise KeyError(f"{reg}.{name}")

    def field_mask(self, reg: str, name: str) -> int:
        hi, lo = self.field(reg, name)
        return ((1 << (hi - lo + 1)) - 1) << lo


_DEV: Optional[DeviceSpec] = None


def device_spec() -> DeviceSpec:
    global _DEV
    if _DEV is None:
        _DEV = DeviceSpec()
    return _DEV


def load_config(name_or_path: Optional[str] = None) -> Config:
    if name_or_path in (None, "", "default"):
        return Config.from_file("default")
    return Config.from_file(name_or_path)
