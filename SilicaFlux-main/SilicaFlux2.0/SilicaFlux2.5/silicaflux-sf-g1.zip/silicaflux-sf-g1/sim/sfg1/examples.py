"""Example kernels with deterministic inputs, independent references and golden-output reports.

Every example allocates device buffers in a fixed order (documented per
example) so that device addresses, and therefore the commit trace, are the same
whichever host drives the run (Python here, C in sw/apps/sfg1_demo.c).  Input
data comes from a 32-bit LCG that the C demo implements identically.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Optional

from .asm import assemble_file
from .host import Host, LaunchResult, LocalTransport, open_local
from .spec import Config, MASK32

KERNEL_DIR = Path(__file__).resolve().parents[2] / "examples" / "kernels"
ROOT_REFERENCE = Path(__file__).resolve().parents[2] / "reference"
SENTINEL = 0xCCCCCCCC
GUARD_WORDS = 8


def lcg_next(x: int) -> int:
    return (x * 1664525 + 1013904223) & MASK32


def lcg_stream(seed: int, n: int) -> List[int]:
    out, x = [], seed & MASK32
    for _ in range(n):
        x = lcg_next(x)
        out.append(x)
    return out


def fnv1a(words: List[int]) -> int:
    h = 0x811C9DC5
    for w in words:
        for k in range(4):
            h ^= (w >> (8 * k)) & 0xFF
            h = (h * 0x01000193) & MASK32
    return h


def s32(x: int) -> int:
    return x - (1 << 32) if x & 0x80000000 else x


def pow2_floor(n: int) -> int:
    p = 1
    while p * 2 <= n:
        p *= 2
    return p


@dataclass
class ExampleResult:
    name: str
    result: LaunchResult
    ok: bool
    report: Dict
    message: str = ""


# ---------------------------------------------------------------------------
def _vecadd(host: Host, cfg: Config, trace) -> ExampleResult:
    n = 70
    wg = min(32, host.max_wg_threads)
    grid = (n + wg - 1) // wg
    a = [w for w in lcg_stream(1, n)]
    b = [w for w in lcg_stream(2, n)]
    pa, pb = host.alloc(4 * n), host.alloc(4 * n)
    pc = host.alloc(4 * (n + GUARD_WORDS))
    host.write_words(pa, a)
    host.write_words(pb, b)
    host.write_words(pc, [SENTINEL] * (n + GUARD_WORDS))
    words = assemble_file(str(KERNEL_DIR / "vecadd.sfa")).words
    k = host.load_kernel(words)
    r = host.launch(k, grid, wg, 0, [pa, pb, pc, n])
    got = host.read_words(pc, n + GUARD_WORDS)
    exp = [(x + y) & MASK32 for x, y in zip(a, b)] + [SENTINEL] * GUARD_WORDS
    ok = r.ok and got == exp
    rep = dict(launch=dict(grid=grid, wg=wg, shared=0, args=["a", "b", "c", n]),
               inputs=dict(a=_buf(a), b=_buf(b)), outputs=dict(c=_buf(got[:n], full=True), c_guard_intact=got[n:] == exp[n:]),
               kernel=words)
    return ExampleResult("vecadd", r, ok, rep, "" if ok else "c[] mismatch or guard words overwritten")


def _reduce(host: Host, cfg: Config, trace) -> ExampleResult:
    n = 100
    wg = pow2_floor(min(16, host.max_wg_threads))
    grid = (n + wg - 1) // wg
    data = [w % 1000 for w in (x >> 8 for x in lcg_stream(3, n))]
    pin, pout = host.alloc(4 * n), host.alloc(4)
    host.write_words(pin, data)
    host.write_words(pout, [0])
    words = assemble_file(str(KERNEL_DIR / "reduce_sum.sfa")).words
    k = host.load_kernel(words)
    r = host.launch(k, grid, wg, 4 * wg, [pin, pout, n])
    got = host.read_words(pout, 1)[0]
    exp = sum(data) & MASK32
    ok = r.ok and got == exp
    rep = dict(launch=dict(grid=grid, wg=wg, shared=4 * wg, args=["in", "out", n]),
               inputs=dict(inp=_buf(data)), outputs=dict(sum=got, expected_sum=exp, fnv1a=f"0x{fnv1a([got]):08x}"), kernel=words)
    return ExampleResult("reduce_sum", r, ok, rep, "" if ok else f"sum {got} != {exp}")


def _matmul(host: Host, cfg: Config, trace) -> ExampleResult:
    M, K, N = 6, 5, 7
    wg = min(8, host.max_wg_threads)
    A = [((x >> 16) % 201 - 100) & MASK32 for x in lcg_stream(4, M * K)]
    B = [((x >> 16) % 201 - 100) & MASK32 for x in lcg_stream(5, K * N)]
    pA, pB = host.alloc(4 * M * K), host.alloc(4 * K * N)
    pC = host.alloc(4 * (M * N + GUARD_WORDS))
    host.write_words(pA, A)
    host.write_words(pB, B)
    host.write_words(pC, [SENTINEL] * (M * N + GUARD_WORDS))
    words = assemble_file(str(KERNEL_DIR / "matmul_i32.sfa")).words
    k = host.load_kernel(words)
    r = host.launch(k, M, wg, 0, [pA, pB, pC, N, K])
    got = host.read_words(pC, M * N + GUARD_WORDS)
    exp = [sum(s32(A[i * K + t]) * s32(B[t * N + j]) for t in range(K)) & MASK32
           for i in range(M) for j in range(N)] + [SENTINEL] * GUARD_WORDS
    ok = r.ok and got == exp
    rep = dict(launch=dict(grid=M, wg=wg, shared=0, args=["A", "B", "C", N, K]),
               inputs=dict(A=_buf(A), B=_buf(B)), outputs=dict(C=_buf(got[:M * N], full=True), c_guard_intact=got[M * N:] == exp[M * N:]),
               dims=dict(M=M, K=K, N=N), kernel=words)
    return ExampleResult("matmul_i32", r, ok, rep, "" if ok else "C[] mismatch or guard words overwritten")


def diverge_reference(t: int) -> Optional[int]:
    """What thread t of diverge.sfa stores, or None if it exits before storing."""
    v = 100 + t if t & 1 else 200 - t
    v += 1000 if t & 2 else -1
    n, i = t & 7, 0
    while i < n:
        v += i
        i += 1
        if v & 16:
            break
    return None if n == 5 else v & MASK32


def _diverge(host: Host, cfg: Config, trace) -> ExampleResult:
    wg = min(20, host.max_wg_threads)
    grid = 2
    nthr = wg * grid
    po = host.alloc(4 * nthr)
    host.write_words(po, [0xAAAAAAAA] * nthr)
    words = assemble_file(str(KERNEL_DIR / "diverge.sfa")).words
    k = host.load_kernel(words)
    r = host.launch(k, grid, wg, 0, [po])
    got = host.read_words(po, nthr)
    exp = [0xAAAAAAAA if diverge_reference(t) is None else diverge_reference(t) for t in range(nthr)]
    ok = r.ok and got == exp
    rep = dict(launch=dict(grid=grid, wg=wg, shared=0, args=["out"]),
               inputs={}, outputs=dict(out=_buf(got, full=True)), kernel=words)
    return ExampleResult("diverge", r, ok, rep, "" if ok else "out[] mismatch")


def _buf(words: List[int], full: bool = False) -> Dict:
    d = {"words": len(words), "fnv1a": f"0x{fnv1a(words):08x}"}
    if full:
        d["data"] = [w for w in words]
    return d


EXAMPLES: Dict[str, Callable] = {
    "vecadd": _vecadd,
    "reduce_sum": _reduce,
    "matmul_i32": _matmul,
    "diverge": _diverge,
}


def run_example(name: str, cfg: Optional[Config] = None, host: Optional[Host] = None,
                trace: bool = True) -> ExampleResult:
    """Run one example.  With a local host, also records the commit trace digest."""
    cfg = cfg or Config.default()
    local = host is None
    if local:
        host = open_local(cfg, trace=trace)
    ex = EXAMPLES[name](host, cfg, trace)
    kernel_words = ex.report.pop("kernel")
    kbytes = b"".join(w.to_bytes(4, "little") for w in kernel_words)
    ex.report.update(
        example=name, config=cfg.name, cfg_hash=f"0x{cfg.cfg_hash():08x}",
        kernel_words=len(kernel_words), kernel_sha256=hashlib.sha256(kbytes).hexdigest(),
        status=ex.result.status, stats=ex.result.stats(cfg.lanes), verified=ex.ok,
    )
    if local and trace:
        dev = host.device  # type: ignore[attr-defined]
        ex.report["trace"] = dict(events=len(dev.trace.events), sha256=dev.trace.digest())
        ex.trace = dev.trace  # type: ignore[attr-defined]
    return ex


def report_json(report: Dict) -> str:
    return json.dumps(report, indent=1, sort_keys=True) + "\n"
