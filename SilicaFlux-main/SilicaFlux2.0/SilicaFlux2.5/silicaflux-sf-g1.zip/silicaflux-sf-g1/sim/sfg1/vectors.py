"""Conformance vectors: the reference model's answers, in a form RTL testbenches can read.

Each generator returns the lines of a vector file (first line: record count).
RTL testbenches (rtl/tb/) read these with $fscanf and compare every output bit.
A block is only allowed into the design if verification/blocks.json lists a
generator here and its testbench passes (tools/check_registry.py, `make gate`).
"""
from __future__ import annotations

import json
import random
from pathlib import Path
from typing import Callable, Dict, List, Tuple

from . import alu as alu_mod
from .device import Device
from .examples import EXAMPLES
from .host import Host, LocalTransport
from .isa import isa
from .simt import CMD_BRANCH, CMD_EXIT, CMD_INIT, CMD_JUMP, CMD_SEQ, SimtStack
from .spec import Config, MASK32

I = isa()


# ----------------------------------------------------------------- decode
def decode_vectors(cfg: Config, rng: random.Random) -> List[str]:
    words: List[int] = []
    # 1. every instruction with random legal field values
    for ins in I.by_mnemonic.values():
        for _ in range(60):
            kw = {}
            for name, fl in ins.fmt.fields.items():
                lo, hi = (-(1 << (fl.width - 1)), (1 << (fl.width - 1)) - 1) if fl.signed else (0, (1 << fl.width) - 1)
                kw[name] = rng.choice([lo, hi, 0, 1, rng.randint(lo, hi), rng.randint(lo, hi)])
            if "imm2_nonzero" in ins.require and kw.get("imm2", 1) == 0:
                kw["imm2"] = rng.randint(1, 2047)
            if "valid_sr" in ins.require:
                kw["imm"] = rng.choice(sorted(I.valid_sr))
            words.append(I.encode(ins.mnemonic, **kw))
    # 2. illegal variants: one reserved bit set, zero reconvergence offset, every invalid SR index
    for ins in I.by_mnemonic.values():
        resv = ins.fmt.reserved_mask
        for b in range(26):
            if resv >> b & 1:
                kw = {n: 0 for n in ("rd", "rs1", "rs2", "imm", "imm2")}
                for name in ins.fmt.fields:
                    if name == "imm2":
                        kw[name] = 1
                    if name == "imm" and "valid_sr" in ins.require:
                        kw[name] = 0
                kw = {k: v for k, v in kw.items() if k in ins.fmt.fields}
                words.append(I.encode(ins.mnemonic, **kw) | (1 << b))
    bz = I.by_mnemonic["bz"]
    words += [I.encode("bz", rs1=r, imm=rng.randint(-1024, 1023), imm2=1) & ~0x7FF for r in range(16)]  # imm2 == 0
    for sr in range(32):
        words.append(I.encode("rdsr", rd=3, imm=sr))
    # 3. every opcode with a random payload, and fully random words
    for op in range(64):
        for _ in range(40):
            words.append((op << 26) | rng.getrandbits(26))
    words += [rng.getrandbits(32) for _ in range(2000)]
    # 4. the example kernels
    from .asm import assemble_file
    from .examples import KERNEL_DIR
    for f in sorted(KERNEL_DIR.glob("*.sfa")):
        words += assemble_file(str(f)).words
    lines = [str(len(words))]
    for w in words:
        lines.append(f"{w:08x} {I.decode(w).pack():x}")
    return lines


# -------------------------------------------------------------------- alu
CORNERS = [0, 1, 2, 31, 32, 33, 0x7FFFFFFF, 0x80000000, 0x80000001, 0xFFFFFFFE, 0xFFFFFFFF, 0x12345678, 0xAAAAAAAA, 0x55555555]


def alu_vectors(cfg: Config, rng: random.Random) -> List[str]:
    recs: List[Tuple[int, int, int, int]] = []
    for name, code in I.alu_functions.items():
        for a in CORNERS:
            for b in CORNERS:
                recs.append((code, a, b, alu_mod.alu(code, a, b)))
        for _ in range(300):
            a, b = rng.getrandbits(32), rng.getrandbits(32)
            if rng.random() < 0.3:
                b = rng.randint(0, 40)
            recs.append((code, a, b, alu_mod.alu(code, a, b)))
    lines = [str(len(recs))]
    lines += [f"{fn:x} {a:08x} {b:08x} {y:08x}" for fn, a, b, y in recs]
    return lines


# ------------------------------------------------------------- simt stack
Cmd = Tuple[int, int, int, int]  # (cmd, pc/target, reconv, mask/cond)


def replay(cfg: Config, cmds: List[Cmd]) -> List[Tuple[Cmd, Tuple[int, ...], int]]:
    """Apply commands to the reference stack; return (command, snapshot, overflow) per command."""
    st = SimtStack(cfg.simt_stack_depth, cfg.rpc_none)
    out = []
    for c in cmds:
        kind, pc, rc, m = c
        ovf = 0
        if kind == CMD_INIT:
            st.init(pc, m)
        elif kind == CMD_SEQ:
            st.seq()
        elif kind == CMD_JUMP:
            st.jump(pc)
        elif kind == CMD_BRANCH:
            ovf = int(st.branch(m, pc, rc))
        elif kind == CMD_EXIT:
            st.exit_()
        out.append((c, st.snapshot(), ovf))
    return out


def _fmt_simt(results) -> List[str]:
    lines = [str(len(results))]
    for (kind, pc, rc, m), (spc, act, live, depth, done, viol), ovf in results:
        lines.append(" ".join(f"{x:x}" for x in (kind, pc, rc, m, spc, act, live, depth, done, viol, ovf)))
    return lines


def random_stream(cfg: Config, rng: random.Random, length: int) -> List[Cmd]:
    L, imem = cfg.lanes, cfg.imem_words
    full = cfg.full_mask
    st = SimtStack(cfg.simt_stack_depth, cfg.rpc_none)
    cmds: List[Cmd] = []

    def apply(c: Cmd) -> None:
        cmds.append(c)
        k, pc, rc, m = c
        if k == CMD_INIT:
            st.init(pc, m)
        elif k == CMD_SEQ:
            st.seq()
        elif k == CMD_JUMP:
            st.jump(pc)
        elif k == CMD_BRANCH:
            st.branch(m, pc, rc)
        else:
            st.exit_()

    mask = rng.choice([full, full, rng.getrandbits(L) | 1, (1 << rng.randint(1, L)) - 1])
    apply((CMD_INIT, rng.randint(0, imem // 4), 0, mask))
    for _ in range(length):
        if st.done:
            break
        pc = st.pc
        cand = [pc + 1, pc + 2, pc + 3, pc + rng.randint(1, 8), rng.randint(0, imem - 1)]
        for e in st.entries:
            if e[1] != cfg.rpc_none and e[1] < imem:
                cand.append(e[1])
            if e[0] < imem:
                cand.append(e[0])
        if st.tos_rpc != cfg.rpc_none and st.tos_rpc < imem:
            cand += [st.tos_rpc] * 3
        cand = [c for c in cand if 0 <= c < imem]
        r = rng.random()
        if r < 0.38:
            if pc + 1 < imem:
                apply((CMD_SEQ, 0, 0, 0))
        elif r < 0.50:
            apply((CMD_JUMP, rng.choice(cand), 0, 0))
        elif r < 0.93:
            cond = rng.choice([0, full, rng.getrandbits(L), rng.getrandbits(L), 1 << rng.randrange(L), full & ~(1 << rng.randrange(L))])
            apply((CMD_BRANCH, rng.choice(cand), rng.choice(cand), cond))
        else:
            apply((CMD_EXIT, 0, 0, 0))
    return cmds


def kernel_streams(cfg: Config) -> List[List[Cmd]]:
    """The stack commands every warp of every example kernel issued, in order."""
    streams: List[List[Cmd]] = []
    for name, fn in EXAMPLES.items():
        dev = Device(cfg, record_stack=True)
        host = Host(LocalTransport(dev), cfg)
        fn(host, cfg, False)
        for key in sorted(dev.stack_logs):
            streams.append([tuple(x) for x in dev.stack_logs[key]])
    return streams


def simt_vectors(cfg: Config, rng: random.Random) -> List[str]:
    streams = kernel_streams(cfg)
    n_real = len(streams)
    for _ in range(300):
        streams.append(random_stream(cfg, rng, rng.choice([8, 20, 40, 80])))
    results = []
    for s in streams:
        results.extend(replay(cfg, s))
    return _fmt_simt(results)


GENERATORS: Dict[str, Callable[[Config, random.Random], List[str]]] = {
    "decode": decode_vectors,
    "alu": alu_vectors,
    "simt_stack": simt_vectors,
}


def write_vectors(cfg: Config, outdir: Path, seed: int = 1, only=None) -> Dict[str, int]:
    outdir.mkdir(parents=True, exist_ok=True)
    counts = {}
    for name, gen in GENERATORS.items():
        if only and name not in only:
            continue
        rng = random.Random(f"{name}:{seed}")
        lines = gen(cfg, rng)
        (outdir / f"{name}.vec").write_text("\n".join(lines) + "\n")
        counts[name] = int(lines[0])
    (outdir / "manifest.json").write_text(json.dumps(
        {"config": cfg.name, "cfg_hash": f"0x{cfg.cfg_hash():08x}", "seed": seed, "records": counts}, indent=1, sort_keys=True) + "\n")
    return counts
