"""Reference integer ALU semantics.

Pure functions of two 32-bit operands.  This module is the conformance
reference for rtl/sf_g1_alu.sv; the functional simulator calls the same code,
so the model and the vectors cannot drift apart.
"""
from __future__ import annotations

from typing import Callable, Dict

from .isa import isa
from .spec import MASK32


def _signed(x: int) -> int:
    return x - (1 << 32) if x & 0x80000000 else x


def _add(a, b):  return (a + b) & MASK32
def _sub(a, b):  return (a - b) & MASK32
def _mul(a, b):  return (a * b) & MASK32
def _and(a, b):  return a & b
def _or(a, b):   return a | b
def _xor(a, b):  return a ^ b
def _shl(a, b):  return (a << (b & 31)) & MASK32
def _shr(a, b):  return a >> (b & 31)
def _sar(a, b):  return (_signed(a) >> (b & 31)) & MASK32
def _slt(a, b):  return 1 if _signed(a) < _signed(b) else 0
def _sltu(a, b): return 1 if a < b else 0
def _passb(a, b): return b


FUNCS: Dict[str, Callable[[int, int], int]] = {
    "ADD": _add, "SUB": _sub, "MUL": _mul, "AND": _and, "OR": _or, "XOR": _xor,
    "SHL": _shl, "SHR": _shr, "SAR": _sar, "SLT": _slt, "SLTU": _sltu, "PASSB": _passb,
}

# Indexed by ALU function code (the alu_fn field of the decoded record).
BY_CODE: Dict[int, Callable[[int, int], int]] = {
    isa().alu_functions[name]: fn for name, fn in FUNCS.items()
}

assert set(FUNCS) == set(isa().alu_functions), "ALU table out of sync with spec/sf_g1_isa.json"


def alu(fn_code: int, a: int, b: int) -> int:
    return BY_CODE[fn_code](a & MASK32, b & MASK32)
