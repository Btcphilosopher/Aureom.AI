"""Line-protocol device server: exposes the functional model to external host software.

Protocol (one request per line, one reply per line, all numbers hexadecimal
unless noted; see docs/11-host-software.md):

    RR <off>            -> OK <val>          read BAR0 register
    RW <off> <val>      -> OK                write BAR0 register
    MR <addr> <n>       -> OK <hex bytes>    read GMEM aperture (n decimal) | ERR bus
    MW <addr> <hex>     -> OK                write GMEM aperture            | ERR bus
    ST <n>              -> OK <ran>          advance up to n ticks (decimal); stops when idle
    IRQ                 -> OK 0|1            level of the interrupt output
    INFO                -> OK <config-name> <cfg-hash>
    QUIT                -> OK                (also on EOF)
"""
from __future__ import annotations

import argparse
import sys

from .device import Device
from .spec import load_config


def serve(dev: Device, fin, fout) -> None:
    def reply(*parts: str) -> None:
        fout.write(" ".join(parts) + "\n")
        fout.flush()

    for line in fin:
        parts = line.split()
        if not parts:
            continue
        cmd = parts[0].upper()
        try:
            if cmd == "RR":
                reply("OK", f"{dev.reg_read(int(parts[1], 16)):x}")
            elif cmd == "RW":
                dev.reg_write(int(parts[1], 16), int(parts[2], 16))
                reply("OK")
            elif cmd == "MR":
                b = dev.mem_read(int(parts[1], 16), int(parts[2]))
                reply("OK", b.hex()) if b is not None else reply("ERR", "bus")
            elif cmd == "MW":
                ok = dev.mem_write(int(parts[1], 16), bytes.fromhex(parts[2] if len(parts) > 2 else ""))
                reply("OK") if ok else reply("ERR", "bus")
            elif cmd == "ST":
                reply("OK", str(dev.run(int(parts[1]))))
            elif cmd == "IRQ":
                reply("OK", "1" if dev.irq else "0")
            elif cmd == "INFO":
                reply("OK", dev.cfg.name, f"{dev.cfg.cfg_hash():08x}")
            elif cmd == "QUIT":
                reply("OK")
                return
            else:
                reply("ERR", "unknown-command")
        except (ValueError, IndexError) as e:
            reply("ERR", "bad-request")
    return


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="SF-G1 reference device server")
    ap.add_argument("--config", default="default", help="named config or path to a config JSON")
    ap.add_argument("--trace", help="write the canonical commit trace here on exit")
    ap.add_argument("--no-poison", action="store_true", help="zero-fill memories instead of poisoning")
    a = ap.parse_args(argv)
    dev = Device(load_config(a.config), trace=bool(a.trace), poison=not a.no_poison)
    try:
        serve(dev, sys.stdin, sys.stdout)
    finally:
        if a.trace and dev.trace is not None:
            dev.trace.write_jsonl(a.trace)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
