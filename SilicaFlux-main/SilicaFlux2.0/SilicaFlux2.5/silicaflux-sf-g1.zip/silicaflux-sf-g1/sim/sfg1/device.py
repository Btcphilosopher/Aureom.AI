"""SF-G1 functional reference model: the device as software sees it.

The model is *architecturally* exact (instruction semantics, masks and
reconvergence, memory spaces, barriers, launch descriptors, device registers,
interrupts, faults and reset) and *timing-approximate*: time advances in
"ticks", one tick being one scheduling round in which every execution group
issues at most one warp instruction.  Memory operations complete within the
tick that issues them.  Implementations may be slower and pipelined; they must
agree with this model on everything in docs/09-verification.md.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from . import alu as alu_mod
from .isa import isa, Decoded
from .simt import SimtStack
from .spec import Config, MASK32, device_spec
from .trace import TraceRecorder

POISON = 0xDEADBEEF

# device states
ST_RESET, ST_IDLE, ST_LAUNCHING, ST_RUNNING, ST_FAULTED = range(5)
# warp states
W_READY, W_BARRIER, W_DONE = range(3)

_SPEC = device_spec()
_ISA = isa()
F = _SPEC.faults
LE = _SPEC.launch_errors
_C = _ISA.classes
SR = _ISA.special_registers

INT_DONE, INT_FAULT, INT_LAUNCH_ERR, INT_HOST_ERR = 1, 2, 4, 8


def _s32(x: int) -> int:
    return x - (1 << 32) if x & 0x80000000 else x


class Fault(Exception):
    """Execution fault raised by an instruction (precise: no side effects)."""

    def __init__(self, code: int, pc: int = 0, data: int = 0, lane: Optional[int] = None) -> None:
        super().__init__(_SPEC.error_names.get(code, str(code)))
        self.code, self.pc, self.data, self.lane = code, pc, data & MASK32, lane


@dataclass
class Workgroup:
    wg_id: int
    eg: int
    slot: int
    shared_bytes: int
    smem_base: int
    warps: List["Warp"] = field(default_factory=list)


@dataclass
class Warp:
    wg: Workgroup
    index: int          # warp index within the workgroup
    slot: int           # warp slot within the execution group
    regs: List[List[int]]
    stack: SimtStack
    state: int = W_READY
    seq: int = 0


@dataclass
class ExecutionGroup:
    index: int
    warps: List[Optional[Warp]]
    wgs: List[Optional[Workgroup]]
    smem: bytearray
    rr: int


class Device:
    def __init__(self, cfg: Optional[Config] = None, trace: bool = False,
                 poison: bool = True, record_stack: bool = False) -> None:
        self.cfg = cfg or Config.default()
        self.spec = _SPEC
        self.poison = poison
        self.gmem = bytearray(self.cfg.gmem_bytes)
        if poison:
            self._fill(self.gmem, 0, len(self.gmem))
        self.trace: Optional[TraceRecorder] = TraceRecorder() if trace else None
        self.stack_logs: Optional[Dict] = {} if record_stack else None
        self.egs = [
            ExecutionGroup(i, [None] * self.cfg.warps_per_eg, [None] * self.cfg.wg_slots_per_eg,
                           bytearray(self.cfg.smem_bytes_per_eg), self.cfg.warps_per_eg - 1)
            for i in range(self.cfg.num_eg)
        ]
        self.scratch = 0
        self.ticks_total = 0
        self.reset()

    # ------------------------------------------------------------------ reset
    def _fill(self, buf: bytearray, start: int, length: int) -> None:
        pat = struct.pack("<I", POISON) * (length // 4)
        buf[start:start + length] = pat

    def reset(self) -> None:
        """Hard/soft reset: every register and all core state; GMEM survives."""
        self.state = ST_RESET
        self.reset_left = self.cfg.reset_ticks
        self.int_status = 0
        self.int_enable = 0
        self.launch_addr = 0
        self.launch_latched = 0
        self.launch_err = 0
        self.wdog_limit = self.cfg.wdog_reset_ticks
        self.done = False
        self.fault = dict(code=0, loc=0, pc=0, wg=0, mask=0, data=0)
        self.perf_cycles = self.perf_issued = self.perf_lane_ops = 0
        self.wg_dispatched = self.wg_completed = 0
        self.age = 0
        self.scratch = 0
        self.code: List[int] = []
        self.decoded: List[Decoded] = []
        self.code_words = 0
        self.args = [0] * self.cfg.num_args
        self.grid_dim = self.wg_dim = self.shared_bytes = 0
        self.flags = 0
        self.next_wg = 0
        for eg in self.egs:
            eg.warps = [None] * self.cfg.warps_per_eg
            eg.wgs = [None] * self.cfg.wg_slots_per_eg
            eg.rr = self.cfg.warps_per_eg - 1

    # --------------------------------------------------------------- registers
    @property
    def ready(self) -> bool:
        return self.state != ST_RESET

    @property
    def busy(self) -> bool:
        return self.state in (ST_LAUNCHING, ST_RUNNING)

    @property
    def irq(self) -> bool:
        return bool(self.int_status & self.int_enable)

    def status(self) -> int:
        return (int(self.ready) | (int(self.busy) << 1) | (int(self.done) << 2)
                | (int(self.state == ST_FAULTED) << 3) | (int(self.irq) << 4))

    def _host_err(self) -> None:
        self.int_status |= INT_HOST_ERR

    def reg_read(self, off: int) -> int:
        if off & 3 or off not in self.spec.reg_by_offset:
            self._host_err()
            return 0
        name = self.spec.reg_by_offset[off]["name"]
        caps = self.cfg.caps_regs()
        f = self.fault
        table: Dict[str, Callable[[], int]] = {
            "ID": lambda: self.spec.device_id,
            "VERSION": lambda: self.spec.version_word,
            "CFG_HASH": self.cfg.cfg_hash,
            "CTRL": lambda: 0,
            "STATUS": self.status,
            "INT_STATUS": lambda: self.int_status,
            "INT_ENABLE": lambda: self.int_enable,
            "LAUNCH_ADDR": lambda: self.launch_addr,
            "DOORBELL": lambda: 0,
            "LAUNCH_ERR": lambda: self.launch_err,
            "WDOG_LIMIT": lambda: self.wdog_limit,
            "FAULT_CODE": lambda: f["code"], "FAULT_LOC": lambda: f["loc"], "FAULT_PC": lambda: f["pc"],
            "FAULT_WG": lambda: f["wg"], "FAULT_MASK": lambda: f["mask"], "FAULT_DATA": lambda: f["data"],
            "PERF_CYCLES": lambda: self.perf_cycles & MASK32,
            "PERF_ISSUED": lambda: self.perf_issued & MASK32,
            "PERF_LANE_OPS": lambda: self.perf_lane_ops & MASK32,
            "WG_DISPATCHED": lambda: self.wg_dispatched, "WG_COMPLETED": lambda: self.wg_completed,
            "SCRATCH": lambda: self.scratch,
        }
        if name in caps:
            return caps[name]
        return table[name]() & MASK32

    def reg_write(self, off: int, val: int) -> None:
        val &= MASK32
        if off & 3 or off not in self.spec.reg_by_offset:
            self._host_err()
            return
        if not self.ready:
            return  # all writes are ignored while the device resets
        reg = self.spec.reg_by_offset[off]
        name, access = reg["name"], reg["access"]
        if access == "RO":
            return
        if name == "CTRL":
            if val & 1:
                self.reset()
        elif name == "INT_STATUS":
            self.int_status &= ~val & 0xF
        elif name == "INT_ENABLE":
            self.int_enable = val & 0xF
        elif name == "LAUNCH_ADDR":
            self.launch_addr = val
        elif name == "WDOG_LIMIT":
            self.wdog_limit = val
        elif name == "SCRATCH":
            self.scratch = val
        elif name == "DOORBELL":
            if val & 1:
                self._doorbell()

    def _doorbell(self) -> None:
        if self.busy:
            self._launch_error(LE["LE_BUSY"])
            return
        if self.state == ST_FAULTED:
            self._launch_error(LE["LE_FAULTED"])
            return
        self.launch_err = 0
        self.done = False
        self.perf_cycles = self.perf_issued = self.perf_lane_ops = 0
        self.wg_dispatched = self.wg_completed = 0
        self.age = 0
        self.launch_latched = self.launch_addr
        for eg in self.egs:                      # scheduler state never leaks between launches
            eg.rr = self.cfg.warps_per_eg - 1
        self.state = ST_LAUNCHING

    def _launch_error(self, code: int) -> None:
        self.launch_err = code
        self.int_status |= INT_LAUNCH_ERR

    # ------------------------------------------------------------ host aperture
    def mem_read(self, addr: int, n: int) -> Optional[bytes]:
        if not self.ready or self.busy or addr < 0 or n < 0 or addr + n > len(self.gmem):
            self._host_err()
            return None
        return bytes(self.gmem[addr:addr + n])

    def mem_write(self, addr: int, data: bytes) -> bool:
        if not self.ready or self.busy or addr < 0 or addr + len(data) > len(self.gmem):
            self._host_err()
            return False
        self.gmem[addr:addr + len(data)] = data
        return True

    # convenience wrappers used by tests and the Python host
    def read_words(self, addr: int, count: int) -> List[int]:
        b = self.mem_read(addr, 4 * count)
        if b is None:
            raise RuntimeError("host read rejected")
        return list(struct.unpack(f"<{count}I", b))

    def write_words(self, addr: int, words: List[int]) -> None:
        if not self.mem_write(addr, struct.pack(f"<{len(words)}I", *[w & MASK32 for w in words])):
            raise RuntimeError("host write rejected")

    # -------------------------------------------------------------------- time
    @property
    def active(self) -> bool:
        return self.state in (ST_RESET, ST_LAUNCHING, ST_RUNNING)

    def run(self, max_ticks: int) -> int:
        n = 0
        while n < max_ticks and self.active:
            self.tick()
            n += 1
        return n

    def tick(self) -> None:
        self.ticks_total += 1
        if self.state == ST_RESET:
            self.reset_left -= 1
            if self.reset_left <= 0:
                self.state = ST_IDLE
            return
        if self.state == ST_LAUNCHING:
            self.perf_cycles += 1
            self.age += 1
            self._launch_phase()
            return
        if self.state != ST_RUNNING:
            return
        self.perf_cycles += 1
        self.age += 1
        self._dispatch_one()
        for eg in self.egs:
            self._eg_step(eg)
            if self.state == ST_FAULTED:
                return
        self._retire()
        if self.next_wg >= self.grid_dim and self.wg_completed >= self.grid_dim:
            self.state = ST_IDLE
            self.done = True
            self.int_status |= INT_DONE
            return
        if self.wdog_limit and self.age >= self.wdog_limit:
            self._latch_fault(Fault(F["F_WATCHDOG"], 0, self.age), None, None)

    # ----------------------------------------------------------------- launch
    def _launch_phase(self) -> None:
        cfg = self.cfg
        a = self.launch_latched
        dsz = self.spec.desc_size_words * 4
        err = 0
        if a & 3:
            err = LE["LE_ALIGN"]
        elif a + dsz > cfg.gmem_bytes:
            err = LE["LE_RANGE"]
        if err:
            return self._launch_fail(err)
        w = list(struct.unpack_from(f"<{self.spec.desc_size_words}I", self.gmem, a))
        D = self.spec.desc_words
        magic, vf = w[D["MAGIC"]], w[D["VERSION_FLAGS"]]
        code_addr, code_words, entry = w[D["CODE_ADDR"]], w[D["CODE_WORDS"]], w[D["ENTRY_PC"]]
        grid, wgd, shared = w[D["GRID_DIM"]], w[D["WG_DIM"]], w[D["SHARED_BYTES"]]
        known = 0
        for bit in self.spec.desc_flags.values():
            known |= 1 << bit
        if magic != self.spec.desc_magic:
            err = LE["LE_MAGIC"]
        elif (vf >> 16) != self.spec.desc_version:
            err = LE["LE_VERSION"]
        elif (vf & 0xFFFF) & ~known:
            err = LE["LE_RESERVED"]
        elif code_addr & 3:
            err = LE["LE_ALIGN"]
        elif code_words == 0 or code_words > cfg.imem_words:
            err = LE["LE_CODE_SIZE"]
        elif code_addr + 4 * code_words > cfg.gmem_bytes:
            err = LE["LE_RANGE"]
        elif entry >= code_words:
            err = LE["LE_ENTRY"]
        elif grid == 0 or grid > cfg.max_grid_dim or wgd == 0 or wgd > cfg.max_wg_threads:
            err = LE["LE_DIMS"]
        elif shared & 3:
            err = LE["LE_ALIGN"]
        elif shared > cfg.wg_slot_smem_bytes:
            err = LE["LE_SHARED"]
        if err:
            return self._launch_fail(err)
        self.code = list(struct.unpack_from(f"<{code_words}I", self.gmem, code_addr))
        self.decoded = [_ISA.decode(x) for x in self.code]
        self.code_words, self.entry_pc = code_words, entry
        self.grid_dim, self.wg_dim, self.shared_bytes = grid, wgd, shared
        self.flags = vf & 0xFFFF
        self.args = w[D["ARG0"]:D["ARG0"] + cfg.num_args]
        self.next_wg = 0
        self.state = ST_RUNNING

    def _launch_fail(self, code: int) -> None:
        self.state = ST_IDLE
        self._launch_error(code)

    def _dispatch_one(self) -> None:
        """Assign the next workgroup, in id order, to the lowest-numbered execution group that fits."""
        if self.next_wg >= self.grid_dim:
            return
        cfg = self.cfg
        L = cfg.lanes
        nwarps = (self.wg_dim + L - 1) // L
        for eg in self.egs:
            if None not in eg.wgs:
                continue
            free = [i for i, w in enumerate(eg.warps) if w is None]
            if len(free) < nwarps:
                continue
            slot = eg.wgs.index(None)
            base = slot * cfg.wg_slot_smem_bytes
            wg = Workgroup(self.next_wg, eg.index, slot, self.shared_bytes, base)
            if self.flags & (1 << self.spec.desc_flags["SMEM_ZERO"]):
                eg.smem[base:base + cfg.wg_slot_smem_bytes] = bytes(cfg.wg_slot_smem_bytes)
            elif self.poison:
                self._fill(eg.smem, base, cfg.wg_slot_smem_bytes)
            for k in range(nwarps):
                nthreads = min(L, self.wg_dim - k * L)
                st = SimtStack(cfg.simt_stack_depth, cfg.rpc_none)
                if self.stack_logs is not None:
                    st.log = self.stack_logs.setdefault((wg.wg_id, k), [])
                st.init(self.entry_pc, (1 << nthreads) - 1)
                w = Warp(wg, k, free[k], [[0] * L for _ in range(cfg.num_regs)], st)
                wg.warps.append(w)
                eg.warps[free[k]] = w
            eg.wgs[slot] = wg
            self.next_wg += 1
            self.wg_dispatched += 1
            return
        # no execution group can take it this tick: stay in order and wait

    def _retire(self) -> None:
        for eg in self.egs:
            for i, wg in enumerate(eg.wgs):
                if wg is not None and all(w.state == W_DONE for w in wg.warps):
                    for w in wg.warps:
                        eg.warps[w.slot] = None
                    eg.wgs[i] = None
                    self.wg_completed += 1

    # --------------------------------------------------------------- scheduler
    def _eg_step(self, eg: ExecutionGroup) -> None:
        n = self.cfg.warps_per_eg
        for k in range(1, n + 1):
            s = (eg.rr + k) % n
            w = eg.warps[s]
            if w is not None and w.state == W_READY:
                eg.rr = s
                try:
                    self._issue(eg, w)
                except Fault as f:
                    self._latch_fault(f, eg, w)
                return

    def _latch_fault(self, f: Fault, eg: Optional[ExecutionGroup], w: Optional[Warp]) -> None:
        self.state = ST_FAULTED
        self.int_status |= INT_FAULT
        if w is None:
            loc, wg, mask = 0x00FFFFFF, 0, 0
            loc = 0xFF | (0xFF << 8) | (0xFF << 16)
            pc = 0
        else:
            mask = w.stack.active
            lane = f.lane
            if lane is None:
                lane = (mask & -mask).bit_length() - 1 if mask else 0
            loc = eg.index | (w.slot << 8) | (lane << 16)
            wg, pc = w.wg.wg_id, f.pc
        self.fault = dict(code=f.code, loc=loc, pc=pc, wg=wg, mask=mask, data=f.data)

    # ------------------------------------------------------------- instruction
    def _sr_value(self, idx: int, w: Warp, lane: int) -> int:
        L = self.cfg.lanes
        if idx == SR["SR_LANE_ID"]:
            return lane
        if idx == SR["SR_WARP_ID"]:
            return w.index
        tid = w.index * L + lane
        if idx == SR["SR_TID"]:
            return tid
        if idx == SR["SR_WG_ID"]:
            return w.wg.wg_id
        if idx == SR["SR_WG_DIM"]:
            return self.wg_dim
        if idx == SR["SR_GRID_DIM"]:
            return self.grid_dim
        if idx == SR["SR_GTID"]:
            return (w.wg.wg_id * self.wg_dim + tid) & MASK32
        if idx == SR["SR_LANES"]:
            return L
        if idx == SR["SR_SHARED_BYTES"]:
            return w.wg.shared_bytes
        return self.args[idx - SR["SR_ARG0"]]

    def _check_gmem(self, pc: int, lanes: List[int], addrs: List[int]) -> None:
        n = self.cfg.gmem_bytes
        for l, a in zip(lanes, addrs):
            if a & 3:
                raise Fault(F["F_GMEM_ALIGN"], pc, a, l)
            if a >= n:
                raise Fault(F["F_GMEM_RANGE"], pc, a, l)

    def _check_smem(self, pc: int, lanes: List[int], addrs: List[int], limit: int) -> None:
        for l, a in zip(lanes, addrs):
            if a & 3:
                raise Fault(F["F_SMEM_ALIGN"], pc, a, l)
            if a >= limit:
                raise Fault(F["F_SMEM_RANGE"], pc, a, l)

    def _issue(self, eg: ExecutionGroup, w: Warp) -> None:
        st = w.stack
        pc = st.pc
        if pc >= self.code_words:
            raise Fault(F["F_PC_RANGE"], pc, pc)
        if st.rpc_violation():
            raise Fault(F["F_RECONV"], pc, st.tos_rpc)
        d = self.decoded[pc]
        word = self.code[pc]
        if d.illegal:
            raise Fault(F["F_ILLEGAL_INSN"], pc, word)
        L = self.cfg.lanes
        active = st.active
        lanes = [i for i in range(L) if (active >> i) & 1]
        regs = w.regs
        c = d.iclass
        wb = None
        mem = None
        want_trace = self.trace is not None

        def write(rd: int, vals: List[int]) -> None:
            nonlocal wb
            if rd:
                row = regs[rd]
                for l, v in zip(lanes, vals):
                    row[l] = v
                if want_trace:
                    wb = [rd, [[l, v] for l, v in zip(lanes, vals)]]

        if c == _C["NOP"] or c == _C["FENCE"]:
            st.seq()
        elif c == _C["ALU"]:
            fn = alu_mod.BY_CODE[d.alu_fn]
            ra = regs[d.rs1]
            if d.b_imm:
                vals = [fn(ra[l], d.imm) for l in lanes]
            else:
                rb = regs[d.rs2]
                vals = [fn(ra[l], rb[l]) for l in lanes]
            write(d.rd, vals)
            st.seq()
        elif c == _C["SREAD"]:
            write(d.rd, [self._sr_value(d.imm, w, l) for l in lanes])
            st.seq()
        elif c in (_C["LDG"], _C["STG"], _C["ATOM"]):
            base = regs[d.rs1]
            simm = _s32(d.imm)
            addrs = [(base[l] + simm) & MASK32 for l in lanes]
            self._check_gmem(pc, lanes, addrs)
            g = self.gmem
            if c == _C["LDG"]:
                vals = [struct.unpack_from("<I", g, a)[0] for a in addrs]
                write(d.rd, vals)
                mem = ["ldg", [[l, a] for l, a in zip(lanes, addrs)]]
            elif c == _C["STG"]:
                src = regs[d.rs2]
                for l, a in zip(lanes, addrs):
                    struct.pack_into("<I", g, a, src[l])
                mem = ["stg", [[l, a, src[l]] for l, a in zip(lanes, addrs)]]
            else:
                src = regs[d.rs2]
                olds = []
                for l, a in zip(lanes, addrs):
                    old = struct.unpack_from("<I", g, a)[0]
                    struct.pack_into("<I", g, a, (old + src[l]) & MASK32)
                    olds.append(old)
                write(d.rd, olds)
                mem = ["atomadd", [[l, a, src[l]] for l, a in zip(lanes, addrs)]]
            st.seq()
        elif c in (_C["LDS"], _C["STS"]):
            base = regs[d.rs1]
            simm = _s32(d.imm)
            addrs = [(base[l] + simm) & MASK32 for l in lanes]
            self._check_smem(pc, lanes, addrs, w.wg.shared_bytes)
            sm, off = eg.smem, w.wg.smem_base
            if c == _C["LDS"]:
                vals = [struct.unpack_from("<I", sm, off + a)[0] for a in addrs]
                write(d.rd, vals)
                mem = ["lds", [[l, a] for l, a in zip(lanes, addrs)]]
            else:
                src = regs[d.rs2]
                for l, a in zip(lanes, addrs):
                    struct.pack_into("<I", sm, off + a, src[l])
                mem = ["sts", [[l, a, src[l]] for l, a in zip(lanes, addrs)]]
            st.seq()
        elif c == _C["BRANCH"]:
            target = pc + _s32(d.imm)
            reconv = pc + d.imm2
            if not 0 <= target < self.code_words:
                raise Fault(F["F_PC_RANGE"], pc, target)
            if reconv >= self.code_words:
                raise Fault(F["F_PC_RANGE"], pc, reconv)
            row = regs[d.rs1]
            want_zero = d.opcode == _ISA.by_mnemonic["bz"].opcode
            cond = 0
            for l in lanes:
                if (row[l] == 0) == want_zero:
                    cond |= 1 << l
            if st.branch(cond, target, reconv):
                raise Fault(F["F_STACK_OVERFLOW"], pc, st.depth)
        elif c == _C["JUMP"]:
            target = pc + _s32(d.imm)
            if not 0 <= target < self.code_words:
                raise Fault(F["F_PC_RANGE"], pc, target)
            st.jump(target)
        elif c == _C["EXIT"]:
            st.exit_()
        elif c == _C["BAR"]:
            if active != st.live:
                raise Fault(F["F_BAR_DIVERGENT"], pc, st.live)
            st.seq()
            w.state = W_BARRIER
        elif c == _C["TRAP"]:
            raise Fault(F["F_TRAP"], pc, d.imm)
        else:  # pragma: no cover
            raise Fault(F["F_ILLEGAL_INSN"], pc, word)

        # ---- commit -------------------------------------------------------
        self.perf_issued += 1
        self.perf_lane_ops += len(lanes)
        if want_trace:
            self.trace.add({
                "wg": w.wg.wg_id, "warp": w.index, "seq": w.seq, "pc": pc, "insn": word,
                "mask": active, "wb": wb, "mem": mem,
                "npc": None if st.done else st.pc, "nmask": st.active, "depth": st.depth,
                "eg": eg.index, "tick": self.ticks_total,
            })
        w.seq += 1
        if st.done:
            w.state = W_DONE
        if w.state in (W_BARRIER, W_DONE):
            self._barrier_check(w.wg)

    def _barrier_check(self, wg: Workgroup) -> None:
        parts = [x for x in wg.warps if x.state != W_DONE]
        if parts and all(x.state == W_BARRIER for x in parts):
            for x in parts:
                x.state = W_READY

    # --------------------------------------------------------------- reporting
    def stats(self) -> Dict[str, float]:
        eff = self.perf_lane_ops / (self.perf_issued * self.cfg.lanes) if self.perf_issued else 0.0
        return {
            "ticks": self.perf_cycles, "warp_instructions": self.perf_issued,
            "lane_ops": self.perf_lane_ops, "simt_efficiency": round(eff, 6),
            "workgroups": self.wg_completed,
        }

    def fault_name(self) -> str:
        return self.spec.error_names.get(self.fault["code"], "NONE")
