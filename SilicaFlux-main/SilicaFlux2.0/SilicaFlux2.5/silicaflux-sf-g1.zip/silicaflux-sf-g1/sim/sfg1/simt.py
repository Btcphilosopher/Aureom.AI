"""SIMT execution-mask and reconvergence stack (the architectural reference).

One ``SimtStack`` exists per warp.  The functional simulator drives it, and
rtl/sf_g1_simt_stack.sv is verified against it command by command
(tools/gen_vectors.py).  Semantics are specified in docs/03-execution-model.md.

State
-----
* ``entries``: list of ``[pc, rpc, mask]``.  The top entry is the executing
  path: its ``pc`` is the warp PC, ``rpc`` is the address at which it
  reconverges with the entry below, ``mask`` is the set of lanes it covers.
* ``live``: lanes whose threads have not executed EXIT.

The active mask is ``top.mask & live``.  Entries below the top are either
pending paths or reconvergence entries waiting for their paths to arrive.
"""
from __future__ import annotations

from typing import List, Optional, Tuple

CMD_INIT, CMD_SEQ, CMD_JUMP, CMD_BRANCH, CMD_EXIT = 0, 1, 2, 3, 4
CMD_NAMES = {CMD_INIT: "INIT", CMD_SEQ: "SEQ", CMD_JUMP: "JUMP", CMD_BRANCH: "BRANCH", CMD_EXIT: "EXIT"}


class SimtStack:
    __slots__ = ("capacity", "rpc_none", "entries", "live", "log")

    def __init__(self, capacity: int, rpc_none: int) -> None:
        self.capacity = capacity
        self.rpc_none = rpc_none
        self.entries: List[List[int]] = []
        self.live = 0
        self.log: Optional[list] = None

    # ---- commands -----------------------------------------------------
    def init(self, pc: int, mask: int) -> None:
        """Start a warp at ``pc`` with ``mask`` lanes live."""
        if self.log is not None:
            self.log.append((CMD_INIT, pc, 0, mask))
        self.entries = [[pc, self.rpc_none, mask]]
        self.live = mask
        self._resolve()

    def seq(self) -> None:
        """Non-control instruction completed: top.pc <- top.pc + 1."""
        if self.log is not None:
            self.log.append((CMD_SEQ, 0, 0, 0))
        self.entries[-1][0] += 1
        self._resolve()

    def jump(self, target: int) -> None:
        """Uniform jump of every active lane."""
        if self.log is not None:
            self.log.append((CMD_JUMP, target, 0, 0))
        self.entries[-1][0] = target
        self._resolve()

    def branch(self, cond: int, target: int, reconv: int) -> bool:
        """Conditional branch.

        ``cond`` has bit i set when lane i takes the branch (only active lanes
        are considered).  Returns True on stack overflow, in which case the
        stack is left unchanged (the instruction faults precisely).
        """
        if self.log is not None:
            self.log.append((CMD_BRANCH, target, reconv, cond))
        tos = self.entries[-1]
        pc = tos[0]
        act = tos[2] & self.live
        taken = act & cond
        fall = act & ~cond
        if taken == 0:
            tos[0] = pc + 1
        elif fall == 0:
            tos[0] = target
        else:
            paths = []  # bottom-to-top execution stack: fall-through first, taken on top
            if pc + 1 != reconv:
                paths.append([pc + 1, reconv, fall])
            if target != reconv:
                paths.append([target, reconv, taken])
            reuse = tos[1] == reconv
            needed = max(len(paths) - 1, 0) if reuse else len(paths)
            if len(self.entries) + needed > self.capacity:
                return True
            if reuse:
                # The top entry already reconverges at ``reconv``: the lanes
                # that wait there are covered by an entry further down.
                if paths:
                    first = paths.pop(0)
                    tos[0], tos[2] = first[0], first[2]
                    self.entries.extend(paths)
                else:
                    tos[0] = reconv
            else:
                tos[0] = reconv
                self.entries.extend(paths)
        self._resolve()
        return False

    def exit_(self) -> None:
        """The active threads terminate."""
        if self.log is not None:
            self.log.append((CMD_EXIT, 0, 0, 0))
        self.live &= ~self.active
        self._resolve()

    # ---- resolution ---------------------------------------------------
    def _resolve(self) -> None:
        """Pop finished paths and reconvergence entries until the top can run."""
        e = self.entries
        while e:
            top = e[-1]
            if (top[2] & self.live) == 0 or top[0] == top[1]:
                e.pop()
            else:
                break

    # ---- observers ----------------------------------------------------
    @property
    def done(self) -> bool:
        return not self.entries

    @property
    def pc(self) -> int:
        return self.entries[-1][0] if self.entries else 0

    @property
    def tos_rpc(self) -> int:
        return self.entries[-1][1] if self.entries else self.rpc_none

    @property
    def active(self) -> int:
        return (self.entries[-1][2] & self.live) if self.entries else 0

    @property
    def depth(self) -> int:
        return len(self.entries)

    def rpc_violation(self) -> bool:
        """True when the executing path is beyond its reconvergence address."""
        if not self.entries:
            return False
        top = self.entries[-1]
        return top[1] != self.rpc_none and top[0] > top[1]

    def snapshot(self) -> Tuple[int, int, int, int, int, int]:
        """(pc, active, live, depth, done, rpc_violation): the unit's observable state."""
        return (self.pc, self.active, self.live, self.depth, int(self.done), int(self.rpc_violation()))
