"""Architectural commit trace.

Every committed warp instruction produces one event.  The *canonical* projection
(CANON_KEYS) contains only scheduling-independent architectural state, so the
trace digest of a data-race-free kernel is the same for any compliant
implementation, whatever its pipeline timing.  ``eg`` and ``tick`` are kept in
the full event for debugging only.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, Iterable, List

CANON_KEYS = ("wg", "warp", "seq", "pc", "insn", "mask", "wb", "mem", "npc", "nmask", "depth")


def canon(ev: Dict[str, Any]) -> str:
    return json.dumps({k: ev[k] for k in CANON_KEYS}, separators=(",", ":"))


class TraceRecorder:
    def __init__(self) -> None:
        self.events: List[Dict[str, Any]] = []

    def add(self, ev: Dict[str, Any]) -> None:
        self.events.append(ev)

    def ordered(self) -> List[Dict[str, Any]]:
        """Events ordered by (workgroup, warp-in-workgroup, per-warp sequence)."""
        return sorted(self.events, key=lambda e: (e["wg"], e["warp"], e["seq"]))

    def canonical_lines(self) -> List[str]:
        return [canon(e) for e in self.ordered()]

    def digest(self) -> str:
        h = hashlib.sha256()
        for line in self.canonical_lines():
            h.update(line.encode())
            h.update(b"\n")
        return h.hexdigest()

    def write_jsonl(self, path: str, canonical: bool = True) -> None:
        with open(path, "w", encoding="utf-8") as f:
            for ev in self.ordered():
                f.write((canon(ev) if canonical else json.dumps(ev, separators=(",", ":"))) + "\n")


def digest_of_lines(lines: Iterable[str]) -> str:
    h = hashlib.sha256()
    for line in lines:
        h.update(line.encode())
        h.update(b"\n")
    return h.hexdigest()
