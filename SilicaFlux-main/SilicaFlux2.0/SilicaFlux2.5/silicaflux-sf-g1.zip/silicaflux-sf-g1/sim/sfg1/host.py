"""Python host driver for an SF-G1 device (model or, later, an RTL co-simulation).

Mirrors the C host library in sw/ so that examples run identically from both.
A *transport* provides register access (BAR0), global-memory aperture access
(BAR1) and, for simulated devices only, a way to advance device time.
"""
from __future__ import annotations

import os
import struct
import subprocess
import sys
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

from .device import Device
from .spec import Config, MASK32, device_spec

SPEC = device_spec()
R = SPEC.reg_offset


class HostError(RuntimeError):
    pass


# --------------------------------------------------------------------------
class LocalTransport:
    """In-process transport around a Device object."""

    def __init__(self, device: Device) -> None:
        self.dev = device

    def reg_read(self, off: int) -> int:
        return self.dev.reg_read(off)

    def reg_write(self, off: int, val: int) -> None:
        self.dev.reg_write(off, val)

    def mem_read(self, addr: int, n: int) -> bytes:
        b = self.dev.mem_read(addr, n)
        if b is None:
            raise HostError(f"aperture read rejected at {addr:#x}+{n}")
        return b

    def mem_write(self, addr: int, data: bytes) -> None:
        if not self.dev.mem_write(addr, data):
            raise HostError(f"aperture write rejected at {addr:#x}+{len(data)}")

    def advance(self, max_ticks: int) -> int:
        return self.dev.run(max_ticks)

    def irq(self) -> bool:
        return self.dev.irq

    def close(self) -> None:
        pass


class PipeTransport:
    """Talks to ``sfg1_devserver.py`` over a pipe using the line protocol of docs/11."""

    def __init__(self, sim_root: str, config: str = "default", extra: Sequence[str] = ()) -> None:
        script = os.path.join(sim_root, "sfg1_devserver.py")
        self.p = subprocess.Popen([sys.executable, script, "--config", config, *extra],
                                  stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, bufsize=1)

    def _cmd(self, line: str) -> List[str]:
        assert self.p.stdin and self.p.stdout
        self.p.stdin.write(line + "\n")
        self.p.stdin.flush()
        reply = self.p.stdout.readline().split()
        if not reply or reply[0] != "OK":
            raise HostError(f"device server: {' '.join(reply) or 'no reply'} (for '{line[:40]}')")
        return reply[1:]

    def reg_read(self, off: int) -> int:
        return int(self._cmd(f"RR {off:x}")[0], 16)

    def reg_write(self, off: int, val: int) -> None:
        self._cmd(f"RW {off:x} {val & MASK32:x}")

    def mem_read(self, addr: int, n: int) -> bytes:
        out = b""
        while n:
            k = min(n, 4096)
            out += bytes.fromhex(self._cmd(f"MR {addr:x} {k}")[0]) if k else b""
            addr += k
            n -= k
        return out

    def mem_write(self, addr: int, data: bytes) -> None:
        for i in range(0, len(data), 4096):
            chunk = data[i:i + 4096]
            self._cmd(f"MW {addr + i:x} {chunk.hex()}")

    def advance(self, max_ticks: int) -> int:
        return int(self._cmd(f"ST {max_ticks}")[0])

    def irq(self) -> bool:
        return self._cmd("IRQ")[0] == "1"

    def close(self) -> None:
        try:
            self._cmd("QUIT")
        except Exception:
            pass
        for f in (self.p.stdin, self.p.stdout):
            if f:
                f.close()
        self.p.wait(timeout=10)


# --------------------------------------------------------------------------
@dataclass
class Kernel:
    addr: int
    words: int


@dataclass
class LaunchResult:
    status: str                      # "done" | "fault" | "launch_error" | "timeout"
    error: str = ""                  # symbolic name of the F_* / LE_* code
    ticks: int = 0
    issued: int = 0
    lane_ops: int = 0
    fault: Dict[str, int] = field(default_factory=dict)
    launch_err: int = 0

    @property
    def ok(self) -> bool:
        return self.status == "done"

    def stats(self, lanes: int) -> Dict[str, float]:
        eff = self.lane_ops / (self.issued * lanes) if self.issued else 0.0
        return {"ticks": self.ticks, "warp_instructions": self.issued,
                "lane_ops": self.lane_ops, "simt_efficiency": round(eff, 6)}


class Host:
    ALLOC_BASE = 0x100  # keep address 0 unmapped by convention (not an architectural rule)

    def __init__(self, transport, config: Optional[Config] = None, check_hash: bool = True,
                 ready_timeout_ticks: int = 1000) -> None:
        self.t = transport
        self.cfg = config or Config.default()
        self._next = self.ALLOC_BASE
        ticks = 0
        while not (self.t.reg_read(R["STATUS"]) & 1):
            ran = self.t.advance(1)
            ticks += max(ran, 1)
            if ticks > ready_timeout_ticks:
                raise HostError("device never became READY")
        if self.t.reg_read(R["ID"]) != SPEC.device_id:
            raise HostError("not an SF-G1 device (ID mismatch)")
        dev_hash = self.t.reg_read(R["CFG_HASH"])
        if check_hash and dev_hash != self.cfg.cfg_hash():
            raise HostError(f"CFG_HASH mismatch: device {dev_hash:#010x}, host {self.cfg.cfg_hash():#010x}")
        self.caps = {n: self.t.reg_read(R[n]) for n in
                     ("CAPS_GEOM", "CAPS_SMEM", "CAPS_IMEM", "CAPS_GMEM", "CAPS_LIMITS")}
        self.gmem_bytes = self.caps["CAPS_GMEM"]
        self.max_wg_threads = self.caps["CAPS_LIMITS"] & 0xFFFF
        self.lanes = self.caps["CAPS_GEOM"] & 0xFF

    # ---- memory -----------------------------------------------------------
    def alloc(self, nbytes: int, align: int = 64) -> int:
        addr = (self._next + align - 1) & ~(align - 1)
        if addr + nbytes > self.gmem_bytes:
            raise HostError("device memory exhausted")
        self._next = addr + max(nbytes, 4)
        return addr

    def write_words(self, addr: int, words: Sequence[int]) -> None:
        self.t.mem_write(addr, struct.pack(f"<{len(words)}I", *[w & MASK32 for w in words]))

    def read_words(self, addr: int, n: int) -> List[int]:
        return list(struct.unpack(f"<{n}I", self.t.mem_read(addr, 4 * n))) if n else []

    # ---- kernels ----------------------------------------------------------
    def load_kernel(self, words: Sequence[int]) -> Kernel:
        addr = self.alloc(4 * len(words))
        self.write_words(addr, words)
        return Kernel(addr, len(words))

    def build_descriptor(self, kernel: Kernel, grid: int, wg: int, shared: int = 0,
                         args: Sequence[int] = (), flags: int = 0, entry: int = 0) -> List[int]:
        D = SPEC.desc_words
        words = [0] * SPEC.desc_size_words
        words[D["MAGIC"]] = SPEC.desc_magic
        words[D["VERSION_FLAGS"]] = (SPEC.desc_version << 16) | (flags & 0xFFFF)
        words[D["CODE_ADDR"]] = kernel.addr
        words[D["CODE_WORDS"]] = kernel.words
        words[D["ENTRY_PC"]] = entry
        words[D["GRID_DIM"]] = grid
        words[D["WG_DIM"]] = wg
        words[D["SHARED_BYTES"]] = shared
        for i, a in enumerate(args):
            words[D["ARG0"] + i] = a & MASK32
        return words

    def submit(self, desc_words: Sequence[int]) -> None:
        addr = self.alloc(4 * len(desc_words))
        self.write_words(addr, desc_words)
        self.t.reg_write(R["LAUNCH_ADDR"], addr)
        self.t.reg_write(R["DOORBELL"], 1)

    def launch(self, kernel: Kernel, grid: int, wg: int, shared: int = 0,
               args: Sequence[int] = (), flags: int = 0, entry: int = 0,
               max_ticks: int = 50_000_000) -> LaunchResult:
        self.submit(self.build_descriptor(kernel, grid, wg, shared, args, flags, entry))
        return self.wait(max_ticks)

    def wait(self, max_ticks: int = 50_000_000, chunk: int = 10_000) -> LaunchResult:
        total = 0
        while self.t.reg_read(R["STATUS"]) & 2:  # BUSY
            if total >= max_ticks:
                return LaunchResult("timeout", "TIMEOUT")
            total += max(self.t.advance(min(chunk, max_ticks - total)), 1)
        st = self.t.reg_read(R["STATUS"])
        res = LaunchResult("done", ticks=self.t.reg_read(R["PERF_CYCLES"]),
                           issued=self.t.reg_read(R["PERF_ISSUED"]),
                           lane_ops=self.t.reg_read(R["PERF_LANE_OPS"]))
        # LAUNCH_ERR is cleared by every accepted submission, so a non-zero value
        # means the submission we just made was rejected; check it before FAULTED
        # (a rejected doorbell in the FAULTED state must not be misreported).
        le = self.t.reg_read(R["LAUNCH_ERR"])
        if le:
            res.status, res.launch_err = "launch_error", le
            res.error = SPEC.error_names.get(le, hex(le))
        elif st & 8:
            res.status = "fault"
            res.fault = {n: self.t.reg_read(R["FAULT_" + n]) for n in ("CODE", "LOC", "PC", "WG", "MASK", "DATA")}
            res.error = SPEC.error_names.get(res.fault["CODE"], hex(res.fault["CODE"]))
        return res

    # ---- control ----------------------------------------------------------
    def reset(self) -> None:
        self.t.reg_write(R["CTRL"], 1)
        n = 0
        while not (self.t.reg_read(R["STATUS"]) & 1):
            self.t.advance(1)
            n += 1
            if n > 1000:
                raise HostError("reset did not complete")

    def clear_interrupts(self, mask: int = 0xF) -> None:
        self.t.reg_write(R["INT_STATUS"], mask)

    def close(self) -> None:
        self.t.close()


def open_local(config: Optional[Config] = None, trace: bool = False, **dev_kw) -> Host:
    cfg = config or Config.default()
    dev = Device(cfg, trace=trace, **dev_kw)
    host = Host(LocalTransport(dev), cfg)
    host.device = dev  # type: ignore[attr-defined]
    return host
