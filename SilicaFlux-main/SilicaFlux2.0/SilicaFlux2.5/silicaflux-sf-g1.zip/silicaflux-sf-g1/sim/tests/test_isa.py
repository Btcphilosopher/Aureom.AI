"""ISA encoding/decoding properties (docs/02-isa.md)."""
import random
import unittest

from sfg1.asm import assemble
from sfg1.disasm import disassemble_word
from sfg1.isa import isa, decode
from sfg1.spec import MASK32

I = isa()


class IsaTests(unittest.TestCase):
    def test_opcodes_unique_and_in_range(self):
        ops = [i.opcode for i in I.by_mnemonic.values()]
        self.assertEqual(len(ops), len(set(ops)))
        self.assertTrue(all(0 <= o < 64 for o in ops))

    def test_record_width(self):
        self.assertEqual(sum(w for _, w in I.record_layout), 74)

    def test_encode_decode_roundtrip_boundaries(self):
        for ins in I.by_mnemonic.values():
            fields = ins.fmt.fields
            ranges = {}
            for n, fl in fields.items():
                lo, hi = (-(1 << (fl.width - 1)), (1 << (fl.width - 1)) - 1) if fl.signed else (0, (1 << fl.width) - 1)
                ranges[n] = [lo, hi, 0, 1] if lo <= 0 else [lo, hi]
            for trial in range(40):
                rng = random.Random(trial)
                kw = {n: rng.choice(v) for n, v in ranges.items()}
                if "imm2_nonzero" in ins.require and kw.get("imm2") == 0:
                    kw["imm2"] = 7
                if "valid_sr" in ins.require:
                    kw["imm"] = rng.choice(sorted(I.valid_sr))
                w = I.encode(ins.mnemonic, **kw)
                d = decode(w)
                self.assertFalse(d.illegal, (ins.mnemonic, kw))
                self.assertEqual(d.mnemonic, ins.mnemonic)
                self.assertEqual(I.field_values(w), kw)
                for r in ("rd", "rs1", "rs2"):
                    if r in kw:
                        self.assertEqual(getattr(d, r), kw[r])

    def test_every_undefined_opcode_is_illegal(self):
        defined = {i.opcode for i in I.by_mnemonic.values()}
        rng = random.Random(1)
        for op in range(64):
            if op not in defined:
                for _ in range(50):
                    d = decode((op << 26) | rng.getrandbits(26))
                    self.assertEqual(d.pack(), 1 << 73)       # illegal, everything else zero

    def test_each_reserved_bit_makes_instruction_illegal(self):
        for ins in I.by_mnemonic.values():
            kw = {n: 0 for n in ins.fmt.fields}
            if "imm2" in kw:
                kw["imm2"] = 1
            w = I.encode(ins.mnemonic, **kw)
            self.assertFalse(decode(w).illegal, ins.mnemonic)
            for b in range(26):
                if ins.fmt.reserved_mask >> b & 1:
                    self.assertTrue(decode(w | (1 << b)).illegal, f"{ins.mnemonic} bit {b}")

    def test_branch_zero_reconvergence_offset_illegal(self):
        for m in ("bz", "bnz"):
            self.assertTrue(decode(I.encode(m, rs1=1, imm=3, imm2=0)).illegal)
            self.assertFalse(decode(I.encode(m, rs1=1, imm=3, imm2=1)).illegal)

    def test_special_register_validity(self):
        for sr in range(32):
            d = decode(I.encode("rdsr", rd=1, imm=sr))
            self.assertEqual(d.illegal == 0, sr in I.valid_sr)

    def test_decode_normalisation_examples(self):
        d = decode(I.encode("stg", rs2=5, rs1=7, imm=-4))
        self.assertEqual((d.rs2, d.rs1, d.rd, d.rd_we, d.rs1_re, d.rs2_re, d.b_imm), (5, 7, 0, 0, 1, 1, 1))
        self.assertEqual(d.imm, (-4) & MASK32)
        d = decode(I.encode("lui", rd=2, imm=0x3FFFFF))
        self.assertEqual(d.imm, 0xFFFFFC00)
        d = decode(I.encode("bnz", rs1=9, imm=-12, imm2=30))
        self.assertEqual((d.rs1, d.imm, d.imm2), (9, (-12) & MASK32, 30))

    def test_disassembly_reassembles_non_control_words(self):
        rng = random.Random(7)
        for _ in range(3000):
            w = rng.getrandbits(32)
            d = decode(w)
            if d.illegal or d.mnemonic in ("bra", "bz", "bnz"):
                continue
            text = disassemble_word(w)
            self.assertEqual(assemble(text).words, [w], text)

    def test_assembler_range_checks(self):
        from sfg1.asm import AsmError
        for bad in ("addi r1, r0, 131072", "addi r1, r0, -131073", "shli r1, r1, 32", "lui r1, 0x400000",
                    "trap 65536", "ldg r1, [r1 + 131072]", "ldg r1, [r1 * 2]", "atomadd r1, [r2 + 4], r3"):
            with self.assertRaises(AsmError, msg=bad):
                assemble(bad)
        assemble("addi r1, r0, 131071\n addi r1, r0, -131072\n shli r1, r1, 31\n trap 65535")


if __name__ == "__main__":
    unittest.main()
