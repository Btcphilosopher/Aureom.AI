"""Example kernels: results, golden reference outputs and transport equivalence (docs/10, reference/README.md)."""
import json
import sys
import tempfile
import unittest
from pathlib import Path

from sfg1.examples import EXAMPLES, run_example, report_json
from sfg1.host import Host, PipeTransport
from sfg1.spec import Config

ROOT = Path(__file__).resolve().parents[2]


class Examples(unittest.TestCase):
    def test_all_examples_verify_on_all_configs(self):
        for cname in ("default", "small", "wide"):
            cfg = Config.from_file(cname)
            for name in EXAMPLES:
                ex = run_example(name, cfg)
                self.assertTrue(ex.ok, f"{name} on {cname}: {ex.message} {ex.result}")

    def test_default_results_match_golden_reference(self):
        cfg = Config.from_file("default")
        for name in EXAMPLES:
            ex = run_example(name, cfg)
            d = ROOT / "reference" / name
            self.assertEqual((d / "report.json").read_text(), report_json(ex.report), name)
            with tempfile.TemporaryDirectory() as td:
                ex.trace.write_jsonl(f"{td}/t.jsonl")
                self.assertEqual((d / "commit_trace.jsonl").read_text(), Path(f"{td}/t.jsonl").read_text(), name)

    def test_vecadd_tail_lanes_stay_masked(self):
        ex = run_example("vecadd", Config.from_file("default"))
        self.assertTrue(ex.report["outputs"]["c_guard_intact"])
        self.assertLess(ex.report["stats"]["simt_efficiency"], 1.0)     # tail warp is partially active

    def test_diverge_reference_is_independent_of_warp_width(self):
        outs = {}
        for cname in ("default", "wide"):
            outs[cname] = run_example("diverge", Config.from_file(cname)).report["outputs"]["out"]["data"][:20]
        self.assertEqual(outs["default"], outs["wide"])

    def test_pipe_transport_matches_local_run(self):
        # The same example driven through the line-protocol device server.
        cfg = Config.from_file("default")
        local = run_example("matmul_i32", cfg)
        t = PipeTransport(str(ROOT / "sim"), "default")
        try:
            host = Host(t, cfg)
            piped = run_example("matmul_i32", cfg, host=host, trace=False)
        finally:
            t.close()
        self.assertTrue(piped.ok)
        self.assertEqual(piped.report["outputs"], local.report["outputs"])
        self.assertEqual(piped.report["stats"], local.report["stats"])

    def test_pipe_transport_reports_hash_mismatch(self):
        t = PipeTransport(str(ROOT / "sim"), "small")
        try:
            with self.assertRaises(Exception) as cm:
                Host(t, Config.from_file("default"))
            self.assertIn("CFG_HASH mismatch", str(cm.exception))
        finally:
            t.close()


if __name__ == "__main__":
    unittest.main()
