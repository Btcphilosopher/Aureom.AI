"""Directed tests of the functional reference model (docs/03-08)."""
import struct
import unittest

from sfg1.asm import assemble
from sfg1.device import Device, ST_FAULTED, ST_IDLE, POISON
from sfg1.host import Host, LocalTransport, HostError
from sfg1.spec import Config, device_spec

SPEC = device_spec()
R = SPEC.reg_offset
FC = SPEC.faults
LE = SPEC.launch_errors
M = 0xFFFFFFFF


def make(cfg=None, trace=False):
    cfg = cfg or Config.from_file("default")
    dev = Device(cfg, trace=trace)
    host = Host(LocalTransport(dev), cfg)
    host.alloc(0x1000)          # reserve [0x100, 0x1100) as scratch data for tests that use fixed addresses
    return dev, host


def run(src, grid=1, wg=8, args=(), shared=0, cfg=None, flags=0, trace=False, setup=None):
    dev, host = make(cfg, trace)
    if setup:
        setup(host)
    k = host.load_kernel(assemble(src).words)
    res = host.launch(k, grid=grid, wg=wg, shared=shared, args=args, flags=flags)
    return dev, host, res


def out_buf(host, n, fill=0):
    a = host.alloc(4 * n)
    host.write_words(a, [fill] * n)
    return a


class AluSemantics(unittest.TestCase):
    def test_corner_values(self):
        # Each thread t computes a set of results and stores them; lane 0 only is checked.
        src = """
            rdsr r1, SR_ARG0
            li   r2, 0x80000000
            li   r3, 31
            li   r4, 0xFFFFFFFF
            li   r5, 33
            li   r6, 0x12345678
            sar  r7, r2, r3        ; 0xFFFFFFFF
            shr  r8, r2, r3        ; 1
            shl  r9, r6, r5        ; shift amount 33 & 31 = 1 -> 0x2468ACF0
            slt  r10, r2, r0       ; signed(-2^31) < 0 -> 1
            sltu r11, r2, r0       ; 0x80000000 <u 0 -> 0
            mul  r12, r4, r4       ; (-1)*(-1) = 1
            sub  r13, r0, r4       ; 0 - 0xFFFFFFFF = 1
            sltiu r14, r4, -1      ; 0xFFFFFFFF <u 0xFFFFFFFF -> 0
            sltiu r15, r0, -1      ; 0 <u 0xFFFFFFFF -> 1
            stg r7,  [r1 + 0]
            stg r8,  [r1 + 4]
            stg r9,  [r1 + 8]
            stg r10, [r1 + 12]
            stg r11, [r1 + 16]
            stg r12, [r1 + 20]
            stg r13, [r1 + 24]
            stg r14, [r1 + 28]
            stg r15, [r1 + 32]
            exit
        """
        dev, host = make()
        out = out_buf(host, 9)
        k = host.load_kernel(assemble(src).words)
        r = host.launch(k, grid=1, wg=1, args=[out])
        self.assertTrue(r.ok, r)
        self.assertEqual(host.read_words(out, 9),
                         [0xFFFFFFFF, 1, 0x2468ACF0, 1, 0, 1, 1, 0, 1])

    def test_r0_is_zero_and_writes_ignored(self):
        src = """
            rdsr r1, SR_ARG0
            addi r0, r0, 55        ; write to r0 is discarded
            stg  r0, [r1]
            exit
        """
        dev, host, r = run(src, wg=1, args=[0x100], setup=lambda h: h.write_words(0x100, [7]))
        self.assertEqual(host.read_words(0x100, 1), [0])

    def test_registers_zero_at_thread_start(self):
        src = """
            rdsr r1, SR_ARG0
            add  r2, r3, r4        ; never written: must be zero
            or   r2, r2, r15
            stg  r2, [r1]
            exit
        """
        dev, host, r = run(src, wg=1, args=[0x100], setup=lambda h: h.write_words(0x100, [7]))
        self.assertEqual(host.read_words(0x100, 1), [0])

    def test_li_expansion(self):
        for v in (0, 1, -1, 131071, -131072, 131072, 0x400, 0x12345678, 0xFFFFFFFF, 0x80000000, -2**31):
            src = f"""
                rdsr r1, SR_ARG0
                li r2, {v}
                stg r2, [r1]
                exit
            """
            dev, host, r = run(src, wg=1, args=[0x100])
            self.assertEqual(host.read_words(0x100, 1)[0], v & M, v)


class SpecialRegisters(unittest.TestCase):
    def test_identity_values(self):
        cfg = Config.from_file("default")
        L = cfg.lanes
        src = """
            rdsr r1, SR_ARG0
            rdsr r2, SR_GTID
            shli r3, r2, 5          ; 8 words per thread = 32 bytes
            add  r1, r1, r3
            rdsr r4, SR_LANE_ID
            rdsr r5, SR_WARP_ID
            rdsr r6, SR_TID
            rdsr r7, SR_WG_ID
            rdsr r8, SR_WG_DIM
            rdsr r9, SR_GRID_DIM
            rdsr r10, SR_LANES
            rdsr r11, SR_SHARED_BYTES
            stg r4, [r1 + 0]
            stg r5, [r1 + 4]
            stg r6, [r1 + 8]
            stg r7, [r1 + 12]
            stg r8, [r1 + 16]
            stg r9, [r1 + 20]
            stg r10, [r1 + 24]
            stg r11, [r1 + 28]
            exit
        """
        wg, grid = 20, 3          # 20 threads = 2 full warps + a partial one
        dev, host = make()
        out = out_buf(host, 8 * wg * grid, 0xAAAAAAAA)
        k = host.load_kernel(assemble(src).words)
        r = host.launch(k, grid=grid, wg=wg, shared=64, args=[out])
        self.assertTrue(r.ok, r)
        got = host.read_words(out, 8 * wg * grid)
        for g in range(wg * grid):
            t, w = g % wg, g // wg
            self.assertEqual(got[8 * g:8 * g + 8], [t % L, t // L, t, w, wg, grid, L, 64], f"gtid {g}")

    def test_undefined_special_register_is_illegal(self):
        dev, host, r = run(".word 0xA8400000 | (9 << 0)\n exit", wg=1)   # rdsr r1, sr9 (undefined)
        self.assertEqual((r.status, r.error), ("fault", "F_ILLEGAL_INSN"))


class MemorySpaces(unittest.TestCase):
    def test_store_lane_order_highest_lane_wins(self):
        src = """
            rdsr r1, SR_ARG0
            rdsr r2, SR_LANE_ID
            stg  r2, [r1]          ; all lanes store to the same word
            exit
        """
        dev, host, r = run(src, wg=8, args=[0x100], setup=lambda h: h.write_words(0x100, [99]))
        self.assertEqual(host.read_words(0x100, 1), [7])

    def test_atomadd_ascending_lane_order_and_old_values(self):
        src = """
            rdsr r1, SR_ARG0
            rdsr r2, SR_LANE_ID
            addi r2, r2, 1          ; operand = lane+1
            atomadd r3, [r1], r2    ; old values: 100, 101, 103, 106, ...
            rdsr r4, SR_ARG1
            rdsr r5, SR_LANE_ID
            shli r5, r5, 2
            add  r4, r4, r5
            stg  r3, [r4]
            exit
        """
        dev, host = make()
        ctr = out_buf(host, 1, 100)
        olds = out_buf(host, 8)
        k = host.load_kernel(assemble(src).words)
        host.launch(k, grid=1, wg=8, args=[ctr, olds])
        acc, exp = 100, []
        for l in range(8):
            exp.append(acc)
            acc += l + 1
        self.assertEqual(host.read_words(olds, 8), exp)
        self.assertEqual(host.read_words(ctr, 1), [acc])

    def test_shared_memory_private_per_workgroup(self):
        src = """
            rdsr r1, SR_WG_ID
            addi r1, r1, 1000
            sts  r1, [r0]           ; each workgroup writes its own shared word 0
            bar
            lds  r2, [r0]
            rdsr r3, SR_ARG0
            rdsr r4, SR_GTID
            shli r4, r4, 2
            add  r3, r3, r4
            stg  r2, [r3]
            exit
        """
        dev, host = make()
        out = out_buf(host, 4 * 8)
        k = host.load_kernel(assemble(src).words)
        r = host.launch(k, grid=4, wg=8, shared=16, args=[out])
        self.assertTrue(r.ok, r)
        got = host.read_words(out, 32)
        for wgid in range(4):
            self.assertEqual(got[8 * wgid:8 * wgid + 8], [1000 + wgid] * 8)

    def test_shared_memory_zero_flag(self):
        src = """
            lds r2, [r0]
            rdsr r3, SR_ARG0
            stg r2, [r3]
            exit
        """
        for flags, expect in ((0, POISON), (1, 0)):
            dev, host = make()
            out = out_buf(host, 1, 5)
            k = host.load_kernel(assemble(src).words)
            r = host.launch(k, grid=1, wg=1, shared=16, args=[out], flags=flags)
            self.assertTrue(r.ok, r)
            self.assertEqual(host.read_words(out, 1), [expect])

    def test_faults_are_precise_no_partial_store(self):
        # Lane 5 stores out of range: no lane's store may take effect.
        src = """
            rdsr r1, SR_ARG0
            rdsr r2, SR_LANE_ID
            shli r3, r2, 2
            add  r1, r1, r3
            addi r4, r2, -5
            bnz  r4, ok, ok
            li   r1, 0x7FFFFFF0     ; lane 5 only: far out of range
        ok:
            stg  r2, [r1]
            exit
        """
        dev, host, r = run(src, wg=8, args=[0x100], setup=lambda h: h.write_words(0x100, [0xAB] * 8))
        self.assertEqual((r.status, r.error), ("fault", "F_GMEM_RANGE"))
        self.assertEqual(r.fault["DATA"], 0x7FFFFFF0)
        self.assertEqual((r.fault["LOC"] >> 16) & 0xFF, 5)        # faulting lane
        self.assertEqual(dev.state, ST_FAULTED)
        # Host can still read memory in the FAULTED state; nothing was stored.
        self.assertEqual(host.read_words(0x100, 8), [0xAB] * 8)

    def test_lowest_failing_lane_reported_and_alignment_before_range(self):
        src = """
            rdsr r2, SR_LANE_ID
            li   r1, 0x7FFFFFF1     ; misaligned AND out of range
            ldg  r3, [r1]
            exit
        """
        dev, host, r = run(src, wg=4)
        self.assertEqual(r.error, "F_GMEM_ALIGN")

    def test_shared_range_and_alignment(self):
        for body, code in (("li r1, 16\n lds r2, [r1]", "F_SMEM_RANGE"),
                           ("li r1, 6\n lds r2, [r1]", "F_SMEM_ALIGN"),
                           ("li r1, 12\n sts r1, [r1]", None)):
            dev, host, r = run(body + "\n exit", wg=1, shared=16)
            if code:
                self.assertEqual(r.error, code, body)
            else:
                self.assertTrue(r.ok, body)


class Barriers(unittest.TestCase):
    def test_barrier_orders_shared_memory_between_warps(self):
        # Warp 1 writes after a delay loop; warp 0 reads after the barrier.
        src = """
            rdsr r1, SR_WARP_ID
            rdsr r6, SR_ARG0
            bz   r1, reader, reader          ; warp 0 skips the writer block
            addi r2, r0, 30                   ; delay: warp 1 is slow
        spin:
            addi r2, r2, -1
            bnz  r2, spin, wr
        wr:
            addi r3, r0, 777
            sts  r3, [r0]
        reader:
            bar
            bnz  r1, done, done               ; only warp 0 reads
            lds  r4, [r0]
            stg  r4, [r6]
        done:
            exit
        """
        dev, host, r = run(src, wg=16, shared=16, args=[0x100], setup=lambda h: h.write_words(0x100, [0]))
        self.assertTrue(r.ok, r)
        self.assertEqual(host.read_words(0x100, 1), [777])

    def test_divergent_barrier_faults(self):
        src = """
            rdsr r1, SR_LANE_ID
            andi r1, r1, 1
            bz   r1, skip, skip
            bar                       ; odd lanes only: divergent
        skip:
            exit
        """
        dev, host, r = run(src, wg=8)
        self.assertEqual((r.status, r.error), ("fault", "F_BAR_DIVERGENT"))
        self.assertEqual(r.fault["PC"], 3)
        self.assertEqual(r.fault["MASK"], 0b10101010)
        self.assertEqual(r.fault["DATA"], 0xFF)     # live mask

    def test_barrier_not_blocked_by_exited_warp_or_lane(self):
        # Warp 1 exits without reaching the barrier; warp 0 must still be released.
        # Lane 7 of warp 0 exits early; the barrier needs only the live lanes.
        src = """
            rdsr r1, SR_WARP_ID
            rdsr r2, SR_LANE_ID
            rdsr r6, SR_ARG0
            bz   r1, w0, w0
            exit                              ; warp 1 leaves
        w0:
            addi r3, r2, -7
            bnz  r3, stay, stay
            exit                              ; lane 7 leaves
        stay:
            bar
            addi r4, r0, 1
            stg  r4, [r6]
            exit
        """
        dev, host, r = run(src, wg=16, args=[0x100], setup=lambda h: h.write_words(0x100, [0]))
        self.assertTrue(r.ok, r)
        self.assertEqual(host.read_words(0x100, 1), [1])

    def test_multiple_barriers_in_loop(self):
        src = """
            rdsr r6, SR_ARG0
            addi r1, r0, 5
        again:
            bar
            addi r1, r1, -1
            bnz  r1, again, out
        out:
            rdsr r2, SR_TID
            bnz  r2, fin, fin
            addi r3, r0, 42
            stg  r3, [r6]
        fin:
            exit
        """
        dev, host, r = run(src, wg=32, args=[0x100], setup=lambda h: h.write_words(0x100, [0]))
        self.assertTrue(r.ok, r)
        self.assertEqual(host.read_words(0x100, 1), [42])


class Faults(unittest.TestCase):
    def fault(self, src, code, wg=1, cfg=None, **kw):
        dev, host, r = run(src, wg=wg, cfg=cfg, **kw)
        self.assertEqual((r.status, r.error), ("fault", code), r)
        return dev, host, r

    def test_illegal_opcode_and_reserved_bits(self):
        dev, host, r = self.fault(".word 0xFC000000", "F_ILLEGAL_INSN")
        self.assertEqual(r.fault["DATA"], 0xFC000000)
        self.fault(".word 0x00000001\n exit", "F_ILLEGAL_INSN")          # nop with reserved bit set
        self.fault(".word 0xE5400000\n exit", "F_ILLEGAL_INSN")          # bz with zero reconvergence offset

    def test_fall_off_end(self):
        dev, host, r = self.fault("nop\n nop", "F_PC_RANGE")
        self.assertEqual((r.fault["PC"], r.fault["DATA"]), (2, 2))

    def test_fall_off_end_of_full_size_kernel_still_faults(self):
        # Regression: with RPC_NONE == imem_words the base stack entry would be popped silently.
        cfg = Config.from_file("small")
        src = "nop\n" * cfg.imem_words
        dev, host, r = run(src, wg=1, cfg=cfg)
        self.assertEqual((r.status, r.error), ("fault", "F_PC_RANGE"))

    def test_branch_target_out_of_range(self):
        # bra to pc+50 inside a 2-word kernel
        word = (56 << 26) | 50
        self.fault(f".word {word}\n exit", "F_PC_RANGE")

    def test_reconvergence_layout_violation(self):
        # Taken path target is beyond the declared reconvergence address.
        src = """
            rdsr r1, SR_LANE_ID
            andi r1, r1, 1
            bnz  r1, far, near
        near:
            exit
            exit
        far:
            exit
        """
        res = assemble(src)
        self.assertTrue(any("beyond its reconvergence" in w for w in res.warnings))
        self.fault(src, "F_RECONV", wg=8)

    def test_trap(self):
        dev, host, r = self.fault("trap 0x1234", "F_TRAP")
        self.assertEqual(r.fault["DATA"], 0x1234)

    def test_stack_overflow_small_config(self):
        cfg = Config.from_file("small")          # stack depth 4, 4 lanes: depth 7 would be needed
        src = """
            rdsr r1, SR_LANE_ID
            addi r2, r1, -1
            addi r3, r1, -2
            addi r4, r1, -3
            bz   r1, e0, end
            bz   r2, e1, end2
            bz   r3, e2, end3
            exit
        e2: exit
        end3: exit
        e1: exit
        end2: exit
        e0: exit
        end: exit
        """
        # Not a well-formed program; just count entries needed by nested splits.
        src = """
            rdsr r1, SR_LANE_ID
            addi r2, r1, -1
            addi r3, r1, -2
            bz   r1, a0, r0end
            bz   r2, a1, r1end
            bz   r3, a2, r2end
            nop
        a2: nop
        r2end: nop
        a1: nop
        r1end: nop
        a0: nop
        r0end: exit
        """
        dev, host, r = self.fault(src, "F_STACK_OVERFLOW", wg=4, cfg=cfg)
        self.assertEqual(r.fault["PC"], 5)
        # same program on a deep enough stack runs fine
        dev, host, r = run(src, wg=4, cfg=cfg.with_overrides(simt_stack_depth=7))
        self.assertTrue(r.ok, r)

    def test_watchdog(self):
        dev, host = make()
        host.t.reg_write(R["WDOG_LIMIT"], 200)
        k = host.load_kernel(assemble("spin: bra spin").words)
        r = host.launch(k, grid=1, wg=1)
        self.assertEqual((r.status, r.error), ("fault", "F_WATCHDOG"))
        self.assertEqual(r.fault["LOC"], 0xFFFFFF)
        self.assertEqual(r.fault["DATA"], 200)

    def test_fault_state_blocks_launch_until_reset_then_recovers(self):
        dev, host = make()
        k = host.load_kernel(assemble("trap 1").words)
        r = host.launch(k, grid=1, wg=1)
        self.assertEqual(r.status, "fault")
        st = host.t.reg_read(R["STATUS"])
        self.assertEqual(st & 0b1111, 0b1001)                    # READY | FAULTED
        self.assertTrue(host.t.reg_read(R["INT_STATUS"]) & 2)
        r2 = host.launch(k, grid=1, wg=1)
        self.assertEqual((r2.status, r2.error), ("launch_error", "LE_FAULTED"))
        self.assertEqual(host.t.reg_read(R["FAULT_CODE"]), FC["F_TRAP"])   # first fault preserved
        host.write_words(0x40, [123])
        host.reset()
        self.assertEqual(host.t.reg_read(R["STATUS"]), 1)
        self.assertEqual(host.t.reg_read(R["FAULT_CODE"]), 0)
        self.assertEqual(host.read_words(0x40, 1), [123])        # GMEM survives reset
        k2 = host.load_kernel(assemble("exit").words)
        self.assertTrue(host.launch(k2, grid=1, wg=1).ok)


class LaunchValidation(unittest.TestCase):
    def submit(self, host, kernel, **over):
        d = host.build_descriptor(kernel, 1, 8)
        D = SPEC.desc_words
        for k, v in over.items():
            d[D[k]] = v
        host.submit(d)
        return host.wait()

    def test_each_rejection(self):
        cfg = Config.from_file("default")
        dev, host = make(cfg)
        k = host.load_kernel(assemble("exit").words)
        cases = [
            ({"MAGIC": 1}, "LE_MAGIC"),
            ({"VERSION_FLAGS": (2 << 16)}, "LE_VERSION"),
            ({"VERSION_FLAGS": (1 << 16) | 2}, "LE_RESERVED"),
            ({"CODE_ADDR": k.addr + 2}, "LE_ALIGN"),
            ({"CODE_WORDS": 0}, "LE_CODE_SIZE"),
            ({"CODE_WORDS": cfg.imem_words + 1}, "LE_CODE_SIZE"),
            ({"CODE_ADDR": cfg.gmem_bytes - 4, "CODE_WORDS": 2}, "LE_RANGE"),
            ({"ENTRY_PC": 1}, "LE_ENTRY"),
            ({"GRID_DIM": 0}, "LE_DIMS"),
            ({"GRID_DIM": 65536}, "LE_DIMS"),
            ({"WG_DIM": 0}, "LE_DIMS"),
            ({"WG_DIM": cfg.max_wg_threads + 1}, "LE_DIMS"),
            ({"SHARED_BYTES": 6}, "LE_ALIGN"),
            ({"SHARED_BYTES": cfg.wg_slot_smem_bytes + 4}, "LE_SHARED"),
        ]
        for over, name in cases:
            r = self.submit(host, k, **over)
            self.assertEqual((r.status, r.error), ("launch_error", name), over)
            self.assertEqual(dev.state, ST_IDLE)                  # device stays usable
            self.assertTrue(host.t.reg_read(R["INT_STATUS"]) & 4)
            host.clear_interrupts()
        # misaligned and out-of-range LAUNCH_ADDR
        for addr, name in ((0x102, "LE_ALIGN"), (cfg.gmem_bytes - 8, "LE_RANGE")):
            host.t.reg_write(R["LAUNCH_ADDR"], addr)
            host.t.reg_write(R["DOORBELL"], 1)
            r = host.wait()
            self.assertEqual(r.error, name)
        self.assertTrue(host.launch(k, grid=1, wg=8).ok)
        self.assertEqual(host.t.reg_read(R["LAUNCH_ERR"]), 0)     # cleared by an accepted submission

    def test_doorbell_while_busy_does_not_disturb_running_launch(self):
        dev, host = make()
        src = "addi r1, r0, 100\nl: addi r1, r1, -1\n bnz r1, l, e\ne: exit"
        k = host.load_kernel(assemble(src).words)
        host.submit(host.build_descriptor(k, 1, 8))
        host.t.advance(5)
        self.assertTrue(host.t.reg_read(R["STATUS"]) & 2)
        host.t.reg_write(R["DOORBELL"], 1)
        self.assertEqual(host.t.reg_read(R["LAUNCH_ERR"]), LE["LE_BUSY"])
        r = host.wait()
        self.assertEqual(r.status, "launch_error")               # LAUNCH_ERR is still latched ...
        self.assertTrue(host.t.reg_read(R["STATUS"]) & 4)        # ... but the running launch completed
        self.assertEqual(dev.wg_completed, 1)


class DeviceRegisters(unittest.TestCase):
    def test_identity_and_caps(self):
        cfg = Config.from_file("default")
        dev, host = make(cfg)
        rd = host.t.reg_read
        self.assertEqual(rd(R["ID"]), 0x31474653)
        self.assertEqual(rd(R["VERSION"]), 0x00010000)
        self.assertEqual(rd(R["CFG_HASH"]), cfg.cfg_hash())
        self.assertEqual(rd(R["CAPS_GEOM"]), (2 << 24) | (2 << 16) | (4 << 8) | 8)
        self.assertEqual(rd(R["CAPS_GMEM"]), cfg.gmem_bytes)
        self.assertEqual(rd(R["CAPS_LIMITS"]), (65535 << 16) | 32)
        self.assertEqual(rd(R["WDOG_LIMIT"]), cfg.wdog_reset_ticks)

    def test_ready_after_reset_ticks(self):
        dev = Device(Config.from_file("default"))
        self.assertEqual(dev.reg_read(R["STATUS"]) & 1, 0)
        dev.reg_write(R["SCRATCH"], 5)                          # ignored while resetting
        dev.run(3)
        self.assertEqual(dev.reg_read(R["STATUS"]) & 1, 0)
        dev.run(1)
        self.assertEqual(dev.reg_read(R["STATUS"]) & 1, 1)
        self.assertEqual(dev.reg_read(R["SCRATCH"]), 0)

    def test_access_rules(self):
        dev, host = make()
        t = host.t
        t.reg_write(R["SCRATCH"], 0xDEAD)
        self.assertEqual(t.reg_read(R["SCRATCH"]), 0xDEAD)
        t.reg_write(R["ID"], 0)                                  # RO: silently ignored
        self.assertEqual(t.reg_read(R["ID"]), 0x31474653)
        self.assertEqual(t.reg_read(R["INT_STATUS"]) & 8, 0)
        self.assertEqual(t.reg_read(0x0F4), 0)                   # unmapped
        self.assertEqual(t.reg_read(R["INT_STATUS"]) & 8, 8)
        t.reg_write(R["INT_STATUS"], 8)
        self.assertEqual(t.reg_read(R["INT_STATUS"]), 0)         # W1C
        dev.reg_read(R["ID"] + 1)                                # misaligned
        self.assertEqual(t.reg_read(R["INT_STATUS"]), 8)
        t.reg_write(R["INT_ENABLE"], 0xFFFF)
        self.assertEqual(t.reg_read(R["INT_ENABLE"]), 0xF)

    def test_interrupt_levels_and_done(self):
        dev, host = make()
        t = host.t
        k = host.load_kernel(assemble("exit").words)
        t.reg_write(R["INT_ENABLE"], 1)
        self.assertFalse(dev.irq)
        r = host.launch(k, grid=3, wg=8)
        self.assertTrue(r.ok)
        self.assertTrue(dev.irq)                                  # level stays asserted ...
        self.assertTrue(t.reg_read(R["STATUS"]) & 0x10)
        t.reg_write(R["INT_STATUS"], 1)                           # ... until the host clears it
        self.assertFalse(dev.irq)
        self.assertEqual(t.reg_read(R["WG_COMPLETED"]), 3)
        self.assertEqual(t.reg_read(R["WG_DISPATCHED"]), 3)
        # masked interrupt: status set, line low
        t.reg_write(R["INT_ENABLE"], 0)
        host.launch(k, grid=1, wg=1)
        self.assertEqual(t.reg_read(R["INT_STATUS"]), 1)
        self.assertFalse(dev.irq)

    def test_aperture_rejected_while_busy_or_out_of_range(self):
        dev, host = make()
        k = host.load_kernel(assemble("l: bra l").words)
        host.t.reg_write(R["WDOG_LIMIT"], 50)
        host.submit(host.build_descriptor(k, 1, 1))
        host.t.advance(3)
        with self.assertRaises(HostError):
            host.t.mem_read(0x100, 4)
        self.assertTrue(host.t.reg_read(R["INT_STATUS"]) & 8)
        host.wait()
        with self.assertRaises(HostError):
            host.t.mem_write(dev.cfg.gmem_bytes - 2, b"1234")    # straddles the end
        self.assertEqual(host.t.mem_read(0x100, 4), host.t.mem_read(0x100, 4))   # allowed after the fault

    def test_soft_reset_aborts_running_launch(self):
        dev, host = make()
        k = host.load_kernel(assemble("l: bra l").words)
        host.t.reg_write(R["INT_ENABLE"], 0xF)
        host.submit(host.build_descriptor(k, 1, 1))
        host.t.advance(10)
        host.reset()
        st = host.t.reg_read(R["STATUS"])
        self.assertEqual(st, 1)
        self.assertEqual(host.t.reg_read(R["INT_ENABLE"]), 0)
        self.assertEqual(host.t.reg_read(R["WDOG_LIMIT"]), dev.cfg.wdog_reset_ticks)
        self.assertTrue(host.launch(host.load_kernel(assemble("exit").words), grid=1, wg=1).ok)


class SchedulingAndDispatch(unittest.TestCase):
    def test_dispatch_order_and_residency(self):
        cfg = Config.from_file("default")   # 2 EG x 2 wg slots x 4 warps
        src = "rdsr r1, SR_ARG0\n exit"
        dev, host = make(cfg, trace=True)
        k = host.load_kernel(assemble(src).words)
        host.launch(k, grid=6, wg=16, args=[0])
        placement = {}
        for ev in dev.trace.events:
            placement.setdefault(ev["wg"], set()).add(ev["eg"])
        # 16 threads = 2 warps; an EG holds two such workgroups; ids go to the lowest EG that fits
        self.assertEqual(placement[0], {0})
        self.assertEqual(placement[1], {0})
        self.assertEqual(placement[2], {1})
        self.assertEqual(placement[3], {1})
        self.assertEqual(dev.wg_completed, 6)

    def test_round_robin_alternates_between_ready_warps(self):
        cfg = Config.from_file("default").with_overrides(num_eg=1)
        dev, host = make(cfg, trace=True)
        k = host.load_kernel(assemble("nop\nnop\nnop\nexit").words)
        host.launch(k, grid=1, wg=24)           # 3 warps on one EG
        seq = [(e["warp"]) for e in sorted(dev.trace.events, key=lambda e: e["tick"])]
        self.assertEqual(seq[:6], [0, 1, 2, 0, 1, 2])

    def test_trace_digest_independent_of_scheduling_resources(self):
        # Same lanes, different numbers of EGs/slots: only timing and placement change.
        src = open("../examples/kernels/reduce_sum.sfa").read() if False else None
        from pathlib import Path
        src = (Path(__file__).resolve().parents[2] / "examples/kernels/reduce_sum.sfa").read_text()
        digests = []
        for overrides in ({}, {"num_eg": 1, "wg_slots_per_eg": 1}, {"num_eg": 4, "wg_slots_per_eg": 4, "warps_per_eg": 4}):
            cfg = Config.from_file("default").with_overrides(**overrides)
            dev, host = make(cfg, trace=True)
            n = 100
            data = host.alloc(4 * n)
            host.write_words(data, list(range(n)))
            out = out_buf(host, 1)
            k = host.load_kernel(assemble(src).words)
            r = host.launch(k, grid=7, wg=16, shared=64, args=[data, out, n])
            self.assertTrue(r.ok, r)
            self.assertEqual(host.read_words(out, 1), [sum(range(n))])
            digests.append(dev.trace.digest())
        self.assertEqual(len(set(digests)), 1, digests)


class SpecPinning(unittest.TestCase):
    """Behaviours that docs/05, 07, 08 and 09 state precisely; found by an independent audit."""

    def test_barrier_counts_are_not_checked_extra_arrivals_released_by_exit(self):
        src = """
            rdsr r1, SR_WARP_ID
            bar
            bnz  r1, out, out        ; warp 1 exits after one barrier
            bar
            bar                      ; warp 0 waits at two more: released because warp 1 is done
        out:
            exit
        """
        dev, host, r = run(src, wg=16)
        self.assertTrue(r.ok, r)

    def test_barrier_hangs_only_if_a_live_warp_never_arrives(self):
        src = """
            rdsr r1, SR_WARP_ID
            bnz  r1, spin, spin
            bar                      ; warp 0 waits for warp 1 ...
            exit
        spin:
            bra  spin                ; ... which never arrives
        """
        dev, host = make()
        host.t.reg_write(R["WDOG_LIMIT"], 300)
        r = host.launch(host.load_kernel(assemble(src).words), grid=1, wg=16)
        self.assertEqual((r.status, r.error), ("fault", "F_WATCHDOG"))

    def test_fault_location_does_not_depend_on_earlier_launches(self):
        locs = []
        for earlier in (False, True):
            dev, host = make()
            if earlier:
                self.assertTrue(host.launch(host.load_kernel(assemble("exit").words), grid=1, wg=8).ok)
            r = host.launch(host.load_kernel(assemble("trap 1").words), grid=1, wg=16)
            locs.append(r.fault["LOC"])
        self.assertEqual(locs[0], locs[1])

    def test_watchdog_edges_and_precedence(self):
        def wd(limit, src):
            dev, host = make()
            host.t.reg_write(R["WDOG_LIMIT"], limit)
            r = host.launch(host.load_kernel(assemble(src).words), grid=1, wg=1)
            return r.status, r.error, r.fault.get("DATA")
        self.assertEqual(wd(1, "l: bra l"), ("fault", "F_WATCHDOG", 2))          # not evaluated in the launch tick
        self.assertEqual(wd(3, "nop\nexit")[0], "done")                           # completion beats the watchdog
        self.assertEqual(wd(3, "nop\ntrap 5"), ("fault", "F_TRAP", 5))            # an execution fault beats it too
        self.assertEqual(wd(0, "nop\nnop\nnop\nnop\nexit")[0], "done")         # 0 disables

    def test_invalid_access_during_reset_sets_host_err_that_survives(self):
        dev = Device(Config.from_file("default"))
        dev.reg_write(0x0F4, 1)                                   # unmapped offset while READY=0
        self.assertEqual(dev.int_status, 8)
        dev.reg_write(R["SCRATCH"], 5)                            # valid write: ignored, no error
        self.assertEqual(dev.reg_read(R["SCRATCH"]), 0)
        self.assertEqual(dev.reg_read(R["ID"]), 0x31474653)       # every register reads during reset
        dev.run(10)
        self.assertEqual(dev.reg_read(R["INT_STATUS"]), 8)

    def test_launch_err_describes_the_most_recent_submission_only(self):
        dev, host = make()
        k = host.load_kernel(assemble("addi r1, r0, 50\nl: addi r1, r1, -1\n bnz r1, l, e\ne: exit").words)
        host.submit(host.build_descriptor(k, 1, 8))
        host.t.reg_write(R["DOORBELL"], 1)                        # stray second doorbell
        host.wait()
        self.assertEqual(host.t.reg_read(R["LAUNCH_ERR"]), LE["LE_BUSY"])
        self.assertTrue(host.t.reg_read(R["STATUS"]) & 4)         # the first launch did complete
        self.assertTrue(host.launch(k, grid=1, wg=8).ok)          # an accepted doorbell clears it
        self.assertEqual(host.t.reg_read(R["LAUNCH_ERR"]), 0)

    def test_memory_poisoning_rules(self):
        dev = Device(Config.from_file("default"))
        self.assertEqual(struct.unpack_from("<I", dev.gmem, 0)[0], POISON)       # global: at power-up
        self.assertEqual(struct.unpack_from("<I", dev.egs[0].smem, 0)[0], 0)     # shared: not touched by reset ...
        src = "lds r2, [r0]\n rdsr r3, SR_ARG0\n stg r2, [r3]\n exit"          # ... but poisoned at dispatch
        d2, host = make()
        out = out_buf(host, 1, 5)
        host.launch(host.load_kernel(assemble(src).words), grid=1, wg=1, shared=16, args=[out])
        self.assertEqual(host.read_words(out, 1), [POISON])

    def test_branch_range_fault_data_prefers_target(self):
        both_bad = (57 << 26) | (1 << 22) | ((100 & 0x7FF) << 11) | 1000   # bz r1, +100, reconv +1000 in a 2-word kernel
        dev, host, r = run(f".word {both_bad}\n exit", wg=1)
        self.assertEqual((r.error, r.fault["DATA"]), ("F_PC_RANGE", 100))
        ok_target = (57 << 26) | (1 << 22) | (1 << 11) | 1000              # target in range, reconv not
        dev, host, r = run(f".word {ok_target}\n exit", wg=1)
        self.assertEqual((r.error, r.fault["DATA"]), ("F_PC_RANGE", 1000))


class AssemblerBasics(unittest.TestCase):
    def test_errors_are_collected_with_line_numbers(self):
        from sfg1.asm import AsmError
        with self.assertRaises(AsmError) as cm:
            assemble("add r1, r2\nfoo r1\naddi r1, r2, 999999\nld: bz r1, nowhere, nowhere\nadd r16, r1, r2")
        text = str(cm.exception)
        for frag in (":1:", ":2:", ":3:", ":4:", ":5:", "unknown mnemonic", "out of range", "undefined symbol", "does not exist"):
            self.assertIn(frag, text)

    def test_expressions_and_equ(self):
        r = assemble(".equ A, 3\n.equ B, A*4+1\n addi r1, r0, B << 1\n addi r2, r0, %lo(0x12345678)\n lui r3, %hi(0x12345678)")
        from sfg1.isa import decode
        self.assertEqual(decode(r.words[0]).imm, 26)
        self.assertEqual(decode(r.words[1]).imm, 0x278)
        self.assertEqual(decode(r.words[2]).imm, 0x12345400)

    def test_roundtrip_through_disassembler(self):
        from sfg1.disasm import disassemble
        src = (__import__("pathlib").Path(__file__).resolve().parents[2] / "examples/kernels/diverge.sfa").read_text()
        words = assemble(src).words
        again = assemble(disassemble(words)).words
        self.assertEqual(words, again)


if __name__ == "__main__":
    unittest.main()
