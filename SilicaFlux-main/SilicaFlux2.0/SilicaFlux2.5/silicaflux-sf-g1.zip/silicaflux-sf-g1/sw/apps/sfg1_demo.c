/*
 * sfg1_demo: run the bundled example kernels from C and verify them against
 * results computed here in C (independent of the Python reference).
 *
 *   sfg1_demo --sim <sim_root> --config <name> --kernels <dir of .sfbin> [--trace-dir <dir>] [example ...]
 *
 * One line per example:  RESULT example=NAME status=PASS|FAIL ticks=N warp_insns=N lane_ops=N fnv=0x........
 * sw/tests/check_demo.py compare these numbers with the Python model and the reference/ directory.
 * Inputs come from the same LCG as sim/sfg1/examples.py and buffers are allocated in the same order,
 * so device addresses (and therefore the commit trace) are identical to the Python run.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sfg1_host.h"
#include "sf_g1_config.h"
#include "sf_g1_regs.h"

#define SENTINEL 0xCCCCCCCCu
#define GUARD 8u

typedef struct {
    const char *sim, *config, *kernels, *trace_dir;
} opts_t;

static uint32_t lcg(uint32_t x) { return x * 1664525u + 1013904223u; }

static void lcg_stream(uint32_t seed, uint32_t *out, size_t n)
{
    uint32_t x = seed;
    for (size_t i = 0; i < n; i++) { x = lcg(x); out[i] = x; }
}

static uint32_t fnv1a(const uint32_t *w, size_t n)
{
    uint32_t h = 0x811C9DC5u;
    for (size_t i = 0; i < n; i++)
        for (int k = 0; k < 4; k++) {
            h ^= (w[i] >> (8 * k)) & 0xFFu;
            h *= 0x01000193u;
        }
    return h;
}

static uint32_t umin(uint32_t a, uint32_t b) { return a < b ? a : b; }
static uint32_t pow2_floor(uint32_t n) { uint32_t p = 1; while (p * 2 <= n) p *= 2; return p; }

static int open_dev(sfg1_dev *d, const opts_t *o, const char *name)
{
    sfg1_transport t;
    char trace[4096];
    const char *tp = NULL;
    if (o->trace_dir) {
        snprintf(trace, sizeof trace, "%s/%s.jsonl", o->trace_dir, name);
        tp = trace;
    }
    int rc = sfg1_pipe_open(&t, NULL, o->sim, o->config, tp);
    if (rc) { fprintf(stderr, "cannot start device server: %s\n", sfg1_strerror(rc)); return rc; }
    rc = sfg1_open(d, &t, 0);
    if (rc) { fprintf(stderr, "sfg1_open: %s\n", sfg1_strerror(rc)); if (t.close) t.close(t.ctx); }
    return rc;
}

static int load(sfg1_dev *d, const opts_t *o, const char *name, sfg1_kernel *k)
{
    char path[4096];
    snprintf(path, sizeof path, "%s/%s.sfbin", o->kernels, name);
    int rc = sfg1_load_kernel_file(d, path, k);
    if (rc) fprintf(stderr, "cannot load %s: %s\n", path, sfg1_strerror(rc));
    return rc;
}

static int report(const char *name, int pass, const sfg1_result *r, uint32_t fnv)
{
    printf("RESULT example=%s status=%s ticks=%u warp_insns=%u lane_ops=%u fnv=0x%08x\n",
           name, pass ? "PASS" : "FAIL", r->ticks, r->issued, r->lane_ops, fnv);
    if (r->status == SFG1_E_FAULT)
        printf("  fault code=%u (%s) pc=%u data=0x%x\n", r->fault.code, sf_error_name(r->fault.code), r->fault.pc, r->fault.data);
    if (r->status == SFG1_E_LAUNCH)
        printf("  launch error %u (%s)\n", r->launch_err, sf_error_name(r->launch_err));
    return pass ? 0 : 1;
}

/* ---------------------------------------------------------------------------------------- */
static int ex_vecadd(const opts_t *o)
{
    sfg1_dev d; sfg1_kernel k; sfg1_result r = {0};
    if (open_dev(&d, o, "vecadd")) return 1;
    const uint32_t n = 70, wg = umin(32, d.caps.max_wg_threads), grid = (n + wg - 1) / wg;
    uint32_t a[70], b[70], c[70 + GUARD], exp[70 + GUARD];
    lcg_stream(1, a, n); lcg_stream(2, b, n);
    uint32_t pa, pb, pc;
    sfg1_alloc(&d, 4 * n, 64, &pa); sfg1_alloc(&d, 4 * n, 64, &pb); sfg1_alloc(&d, 4 * (n + GUARD), 64, &pc);
    for (uint32_t i = 0; i < n + GUARD; i++) { c[i] = SENTINEL; exp[i] = i < n ? a[i] + b[i] : SENTINEL; }
    sfg1_write_words(&d, pa, a, n); sfg1_write_words(&d, pb, b, n); sfg1_write_words(&d, pc, c, n + GUARD);
    int rc = load(&d, o, "vecadd", &k);
    uint32_t args[4] = {pa, pb, pc, n};
    if (!rc) sfg1_launch(&d, &k, grid, wg, 0, args, 4, 0, &r);
    memset(c, 0, sizeof c);
    int rr = sfg1_read_words(&d, pc, c, n + GUARD);
    int pass = !rc && !rr && r.status == SFG1_OK && memcmp(c, exp, sizeof c) == 0;
    int ret = report("vecadd", pass, &r, fnv1a(c, n));
    sfg1_close(&d);
    return ret;
}

static int ex_reduce(const opts_t *o)
{
    sfg1_dev d; sfg1_kernel k; sfg1_result r = {0};
    if (open_dev(&d, o, "reduce_sum")) return 1;
    const uint32_t n = 100, wg = pow2_floor(umin(16, d.caps.max_wg_threads)), grid = (n + wg - 1) / wg;
    uint32_t in[100], x[100], zero = 0, got = 0, expect = 0;
    lcg_stream(3, x, n);
    for (uint32_t i = 0; i < n; i++) { in[i] = (x[i] >> 8) % 1000u; expect += in[i]; }
    uint32_t pin, pout;
    sfg1_alloc(&d, 4 * n, 64, &pin); sfg1_alloc(&d, 4, 64, &pout);
    sfg1_write_words(&d, pin, in, n); sfg1_write_words(&d, pout, &zero, 1);
    int rc = load(&d, o, "reduce_sum", &k);
    uint32_t args[3] = {pin, pout, n};
    if (!rc) sfg1_launch(&d, &k, grid, wg, 4 * wg, args, 3, 0, &r);
    int rr = sfg1_read_words(&d, pout, &got, 1);
    int pass = !rc && !rr && r.status == SFG1_OK && got == expect;
    int ret = report("reduce_sum", pass, &r, fnv1a(&got, 1));
    sfg1_close(&d);
    return ret;
}

static int ex_matmul(const opts_t *o)
{
    enum { M = 6, K = 5, N = 7 };
    sfg1_dev d; sfg1_kernel k; sfg1_result r = {0};
    if (open_dev(&d, o, "matmul_i32")) return 1;
    const uint32_t wg = umin(8, d.caps.max_wg_threads);
    uint32_t A[M * K], B[K * N], C[M * N + GUARD], exp[M * N + GUARD], x[M * K > K * N ? M * K : K * N];
    lcg_stream(4, x, M * K);
    for (int i = 0; i < M * K; i++) A[i] = (uint32_t)((int32_t)((x[i] >> 16) % 201u) - 100);
    lcg_stream(5, x, K * N);
    for (int i = 0; i < K * N; i++) B[i] = (uint32_t)((int32_t)((x[i] >> 16) % 201u) - 100);
    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++) {
            uint32_t acc = 0;
            for (int t = 0; t < K; t++) acc += A[i * K + t] * B[t * N + j];   /* wraps mod 2^32 */
            exp[i * N + j] = acc;
        }
    for (uint32_t i = 0; i < GUARD; i++) exp[M * N + i] = SENTINEL;
    for (uint32_t i = 0; i < M * N + GUARD; i++) C[i] = SENTINEL;
    uint32_t pA, pB, pC;
    sfg1_alloc(&d, 4 * M * K, 64, &pA); sfg1_alloc(&d, 4 * K * N, 64, &pB); sfg1_alloc(&d, 4 * (M * N + GUARD), 64, &pC);
    sfg1_write_words(&d, pA, A, M * K); sfg1_write_words(&d, pB, B, K * N); sfg1_write_words(&d, pC, C, M * N + GUARD);
    int rc = load(&d, o, "matmul_i32", &k);
    uint32_t args[5] = {pA, pB, pC, N, K};
    if (!rc) sfg1_launch(&d, &k, M, wg, 0, args, 5, 0, &r);
    memset(C, 0, sizeof C);
    int rr = sfg1_read_words(&d, pC, C, M * N + GUARD);
    int pass = !rc && !rr && r.status == SFG1_OK && memcmp(C, exp, sizeof C) == 0;
    int ret = report("matmul_i32", pass, &r, fnv1a(C, M * N));
    sfg1_close(&d);
    return ret;
}

static int diverge_ref(uint32_t t, uint32_t *v_out)
{
    uint32_t v = (t & 1) ? 100 + t : 200 - t;
    v += (t & 2) ? 1000u : (uint32_t)-1;
    uint32_t n = t & 7, i = 0;
    while (i < n) { v += i; i++; if (v & 16) break; }
    *v_out = v;
    return n != 5;
}

static int ex_diverge(const opts_t *o)
{
    sfg1_dev d; sfg1_kernel k; sfg1_result r = {0};
    if (open_dev(&d, o, "diverge")) return 1;
    const uint32_t wg = umin(20, d.caps.max_wg_threads), grid = 2, nthr = wg * grid;
    uint32_t out[64], exp[64], po;
    sfg1_alloc(&d, 4 * nthr, 64, &po);
    for (uint32_t t = 0; t < nthr; t++) { out[t] = 0xAAAAAAAAu; uint32_t v; exp[t] = diverge_ref(t, &v) ? v : 0xAAAAAAAAu; }
    sfg1_write_words(&d, po, out, nthr);
    int rc = load(&d, o, "diverge", &k);
    uint32_t args[1] = {po};
    if (!rc) sfg1_launch(&d, &k, grid, wg, 0, args, 1, 0, &r);
    memset(out, 0, sizeof out);
    int rr = sfg1_read_words(&d, po, out, nthr);
    int pass = !rc && !rr && r.status == SFG1_OK && memcmp(out, exp, 4 * nthr) == 0;
    int ret = report("diverge", pass, &r, fnv1a(out, nthr));
    sfg1_close(&d);
    return ret;
}

int main(int argc, char **argv)
{
    opts_t o = {NULL, "default", NULL, NULL};
    const char *names[8];
    int nn = 0;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--sim") && i + 1 < argc) o.sim = argv[++i];
        else if (!strcmp(argv[i], "--config") && i + 1 < argc) o.config = argv[++i];
        else if (!strcmp(argv[i], "--kernels") && i + 1 < argc) o.kernels = argv[++i];
        else if (!strcmp(argv[i], "--trace-dir") && i + 1 < argc) o.trace_dir = argv[++i];
        else if (argv[i][0] != '-' && nn < 8) names[nn++] = argv[i];
        else { fprintf(stderr, "unknown argument %s\n", argv[i]); return 2; }
    }
    if (!o.sim || !o.kernels) {
        fprintf(stderr, "usage: %s --sim <sim_root> --config <name> --kernels <dir> [--trace-dir <dir>] [example...]\n", argv[0]);
        return 2;
    }
    printf("host build: config %s, CFG_HASH 0x%08x\n", SF_G1_CONFIG_NAME, SF_G1_CFG_HASH);
    static const struct { const char *n; int (*fn)(const opts_t *); } table[] = {
        {"vecadd", ex_vecadd}, {"reduce_sum", ex_reduce}, {"matmul_i32", ex_matmul}, {"diverge", ex_diverge}};
    int rc = 0;
    for (size_t i = 0; i < sizeof table / sizeof table[0]; i++) {
        int want = nn == 0;
        for (int j = 0; j < nn; j++) want |= !strcmp(names[j], table[i].n);
        if (want) rc |= table[i].fn(&o);
    }
    return rc;
}
