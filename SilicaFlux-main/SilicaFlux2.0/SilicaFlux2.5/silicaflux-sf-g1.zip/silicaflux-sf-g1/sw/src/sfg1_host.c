/* SF-G1 host library core: device bring-up, memory, launch, completion, errors. */
#define _POSIX_C_SOURCE 200809L
#include "sfg1_host.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "sf_g1_config.h"
#include "sf_g1_regs.h"

#define ALLOC_BASE 0x100u
#define DEFAULT_TIMEOUT_TICKS 50000000ull
#define WAIT_CHUNK 10000ull

static void put_le32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24);
}

static uint32_t get_le32(const uint8_t *p)
{
    return (uint32_t)p[0] | (uint32_t)p[1] << 8 | (uint32_t)p[2] << 16 | (uint32_t)p[3] << 24;
}

int sfg1_reg_read(sfg1_dev *d, uint32_t off, uint32_t *val) { return d->t.reg_read(d->t.ctx, off, val); }
int sfg1_reg_write(sfg1_dev *d, uint32_t off, uint32_t val) { return d->t.reg_write(d->t.ctx, off, val); }

int sfg1_advance(sfg1_dev *d, uint64_t ticks, uint64_t *ran)
{
    if (!d->t.advance) {           /* real hardware: time passes by itself */
        struct timespec ts = {0, 200000};
        nanosleep(&ts, NULL);
        if (ran) *ran = 0;
        return SFG1_OK;
    }
    return d->t.advance(d->t.ctx, ticks, ran);
}

int sfg1_irq_level(sfg1_dev *d, int *level)
{
    if (!d->t.irq_level) {
        uint32_t st;
        int rc = sfg1_reg_read(d, SF_REG_STATUS, &st);
        if (rc) return rc;
        *level = (st >> SF_STATUS_IRQ_SHIFT) & SF_STATUS_IRQ_MASK;
        return SFG1_OK;
    }
    return d->t.irq_level(d->t.ctx, level);
}

static int wait_ready(sfg1_dev *d)
{
    for (int i = 0; i < 1000; i++) {
        uint32_t st;
        int rc = sfg1_reg_read(d, SF_REG_STATUS, &st);
        if (rc) return rc;
        if (st & (1u << SF_STATUS_READY_SHIFT))
            return SFG1_OK;
        rc = sfg1_advance(d, 1, NULL);
        if (rc) return rc;
    }
    return SFG1_E_NOT_READY;
}

int sfg1_open(sfg1_dev *d, const sfg1_transport *t, unsigned flags)
{
    if (!d || !t)
        return SFG1_E_ARG;
    memset(d, 0, sizeof *d);
    d->t = *t;
    d->next_alloc = ALLOC_BASE;
    int rc = wait_ready(d);
    if (rc) return rc;
    uint32_t id, hash, geom, smem, imem, gmem, lim;
    if ((rc = sfg1_reg_read(d, SF_REG_ID, &id))) return rc;
    if (id != SF_G1_DEVICE_ID) return SFG1_E_BAD_ID;
    if ((rc = sfg1_reg_read(d, SF_REG_CFG_HASH, &hash))) return rc;
    if (hash != SF_G1_CFG_HASH && !(flags & SFG1_OPEN_IGNORE_CFG_HASH))
        return SFG1_E_CFG_MISMATCH;
    if ((rc = sfg1_reg_read(d, SF_REG_CAPS_GEOM, &geom))) return rc;
    if ((rc = sfg1_reg_read(d, SF_REG_CAPS_SMEM, &smem))) return rc;
    if ((rc = sfg1_reg_read(d, SF_REG_CAPS_IMEM, &imem))) return rc;
    if ((rc = sfg1_reg_read(d, SF_REG_CAPS_GMEM, &gmem))) return rc;
    if ((rc = sfg1_reg_read(d, SF_REG_CAPS_LIMITS, &lim))) return rc;
    sfg1_caps *c = &d->caps;
    c->lanes = (geom >> SF_CAPS_GEOM_LANES_SHIFT) & SF_CAPS_GEOM_LANES_MASK;
    c->warps_per_eg = (geom >> SF_CAPS_GEOM_WARPS_PER_EG_SHIFT) & SF_CAPS_GEOM_WARPS_PER_EG_MASK;
    c->num_eg = (geom >> SF_CAPS_GEOM_NUM_EG_SHIFT) & SF_CAPS_GEOM_NUM_EG_MASK;
    c->wg_slots_per_eg = (geom >> SF_CAPS_GEOM_WG_SLOTS_PER_EG_SHIFT) & SF_CAPS_GEOM_WG_SLOTS_PER_EG_MASK;
    c->smem_bytes_per_eg = smem;
    c->imem_words = (imem >> SF_CAPS_IMEM_IMEM_WORDS_SHIFT) & SF_CAPS_IMEM_IMEM_WORDS_MASK;
    c->simt_stack_depth = (imem >> SF_CAPS_IMEM_SIMT_STACK_DEPTH_SHIFT) & SF_CAPS_IMEM_SIMT_STACK_DEPTH_MASK;
    c->num_regs = (imem >> SF_CAPS_IMEM_NUM_REGS_SHIFT) & SF_CAPS_IMEM_NUM_REGS_MASK;
    c->gmem_bytes = gmem;
    c->max_wg_threads = (lim >> SF_CAPS_LIMITS_MAX_WG_THREADS_SHIFT) & SF_CAPS_LIMITS_MAX_WG_THREADS_MASK;
    c->max_grid_dim = (lim >> SF_CAPS_LIMITS_MAX_GRID_DIM_SHIFT) & SF_CAPS_LIMITS_MAX_GRID_DIM_MASK;
    c->cfg_hash = hash;
    return SFG1_OK;
}

void sfg1_close(sfg1_dev *d)
{
    if (d && d->t.close)
        d->t.close(d->t.ctx);
    if (d)
        memset(d, 0, sizeof *d);
}

int sfg1_alloc(sfg1_dev *d, uint32_t bytes, uint32_t align, uint32_t *addr)
{
    if (!align || (align & (align - 1)))
        return SFG1_E_ARG;
    uint64_t a = ((uint64_t)d->next_alloc + align - 1) & ~(uint64_t)(align - 1);
    uint32_t span = bytes < 4 ? 4 : bytes;
    if (a + span > d->caps.gmem_bytes)
        return SFG1_E_NOMEM;
    *addr = (uint32_t)a;
    d->next_alloc = (uint32_t)(a + span);
    return SFG1_OK;
}

int sfg1_write(sfg1_dev *d, uint32_t addr, const void *src, size_t n) { return d->t.mem_write(d->t.ctx, addr, src, n); }
int sfg1_read(sfg1_dev *d, uint32_t addr, void *dst, size_t n) { return d->t.mem_read(d->t.ctx, addr, dst, n); }

int sfg1_write_words(sfg1_dev *d, uint32_t addr, const uint32_t *w, size_t count)
{
    uint8_t *b = malloc(count * 4 + 1);
    if (!b) return SFG1_E_NOMEM;
    for (size_t i = 0; i < count; i++) put_le32(b + 4 * i, w[i]);
    int rc = sfg1_write(d, addr, b, count * 4);
    free(b);
    return rc;
}

int sfg1_read_words(sfg1_dev *d, uint32_t addr, uint32_t *w, size_t count)
{
    uint8_t *b = malloc(count * 4 + 1);
    if (!b) return SFG1_E_NOMEM;
    int rc = sfg1_read(d, addr, b, count * 4);
    if (!rc)
        for (size_t i = 0; i < count; i++) w[i] = get_le32(b + 4 * i);
    free(b);
    return rc;
}

int sfg1_load_kernel(sfg1_dev *d, const uint32_t *code, uint32_t words, sfg1_kernel *k)
{
    uint32_t addr;
    int rc = sfg1_alloc(d, 4 * words, 64, &addr);
    if (rc) return rc;
    if ((rc = sfg1_write_words(d, addr, code, words))) return rc;
    k->addr = addr;
    k->words = words;
    return SFG1_OK;
}

int sfg1_load_kernel_file(sfg1_dev *d, const char *path, sfg1_kernel *k)
{
    FILE *f = fopen(path, "rb");
    if (!f) return SFG1_E_FILE;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (n <= 0 || n % 4) { fclose(f); return SFG1_E_FILE; }
    uint8_t *raw = malloc((size_t)n);
    uint32_t *w = malloc((size_t)n);
    if (!raw || !w) { fclose(f); free(raw); free(w); return SFG1_E_NOMEM; }
    int rc = fread(raw, 1, (size_t)n, f) == (size_t)n ? SFG1_OK : SFG1_E_FILE;
    fclose(f);
    if (!rc) {
        for (long i = 0; i < n / 4; i++) w[i] = get_le32(raw + 4 * i);
        rc = sfg1_load_kernel(d, w, (uint32_t)(n / 4), k);
    }
    free(raw); free(w);
    return rc;
}

int sfg1_submit(sfg1_dev *d, const sfg1_kernel *k, uint32_t grid, uint32_t wg_dim, uint32_t shared_bytes,
                const uint32_t *args, unsigned nargs, uint32_t flags)
{
    if (nargs > SF_G1_NUM_ARGS)
        return SFG1_E_ARG;
    uint32_t desc[SF_DESC_WORDS] = {0};
    desc[SF_DESC_MAGIC] = SF_G1_DESC_MAGIC;
    desc[SF_DESC_VERSION_FLAGS] = (SF_G1_DESC_VERSION << 16) | (flags & 0xFFFFu);
    desc[SF_DESC_CODE_ADDR] = k->addr;
    desc[SF_DESC_CODE_WORDS] = k->words;
    desc[SF_DESC_ENTRY_PC] = 0;
    desc[SF_DESC_GRID_DIM] = grid;
    desc[SF_DESC_WG_DIM] = wg_dim;
    desc[SF_DESC_SHARED_BYTES] = shared_bytes;
    for (unsigned i = 0; i < nargs; i++)
        desc[SF_DESC_ARG0 + i] = args[i];
    uint32_t addr;
    int rc = sfg1_alloc(d, sizeof desc, 64, &addr);
    if (rc) return rc;
    if ((rc = sfg1_write_words(d, addr, desc, SF_DESC_WORDS))) return rc;
    if ((rc = sfg1_reg_write(d, SF_REG_LAUNCH_ADDR, addr))) return rc;
    return sfg1_reg_write(d, SF_REG_DOORBELL, 1);
}

int sfg1_wait(sfg1_dev *d, uint64_t max_ticks, sfg1_result *res)
{
    sfg1_result local;
    if (!res) res = &local;
    memset(res, 0, sizeof *res);
    if (!max_ticks) max_ticks = DEFAULT_TIMEOUT_TICKS;
    uint64_t total = 0;
    uint32_t st;
    int rc;
    for (;;) {
        if ((rc = sfg1_reg_read(d, SF_REG_STATUS, &st))) return res->status = rc;
        if (!(st & (1u << SF_STATUS_BUSY_SHIFT)))
            break;
        if (total >= max_ticks)
            return res->status = SFG1_E_TIMEOUT;
        uint64_t ran = 0, chunk = max_ticks - total < WAIT_CHUNK ? max_ticks - total : WAIT_CHUNK;
        if ((rc = sfg1_advance(d, chunk, &ran))) return res->status = rc;
        total += ran ? ran : 1;
    }
    uint32_t le;
    if ((rc = sfg1_reg_read(d, SF_REG_PERF_CYCLES, &res->ticks))) return res->status = rc;
    sfg1_reg_read(d, SF_REG_PERF_ISSUED, &res->issued);
    sfg1_reg_read(d, SF_REG_PERF_LANE_OPS, &res->lane_ops);
    /* LAUNCH_ERR is cleared by every accepted submission, so a non-zero value means the
     * submission just made was rejected; test it before FAULTED. */
    sfg1_reg_read(d, SF_REG_LAUNCH_ERR, &le);
    if (le) {
        res->launch_err = le;
        return res->status = SFG1_E_LAUNCH;
    }
    if (st & (1u << SF_STATUS_FAULTED_SHIFT)) {
        sfg1_reg_read(d, SF_REG_FAULT_CODE, &res->fault.code);
        sfg1_reg_read(d, SF_REG_FAULT_LOC, &res->fault.loc);
        sfg1_reg_read(d, SF_REG_FAULT_PC, &res->fault.pc);
        sfg1_reg_read(d, SF_REG_FAULT_WG, &res->fault.wg);
        sfg1_reg_read(d, SF_REG_FAULT_MASK, &res->fault.mask);
        sfg1_reg_read(d, SF_REG_FAULT_DATA, &res->fault.data);
        return res->status = SFG1_E_FAULT;
    }
    return res->status = SFG1_OK;
}

int sfg1_launch(sfg1_dev *d, const sfg1_kernel *k, uint32_t grid, uint32_t wg_dim, uint32_t shared_bytes,
                const uint32_t *args, unsigned nargs, uint32_t flags, sfg1_result *res)
{
    int rc = sfg1_submit(d, k, grid, wg_dim, shared_bytes, args, nargs, flags);
    if (rc) {
        if (res) { memset(res, 0, sizeof *res); res->status = rc; }
        return rc;
    }
    return sfg1_wait(d, 0, res);
}

int sfg1_reset(sfg1_dev *d)
{
    int rc = sfg1_reg_write(d, SF_REG_CTRL, 1u << SF_CTRL_SOFT_RESET_SHIFT);
    if (rc) return rc;
    return wait_ready(d);
}

const char *sfg1_strerror(int s)
{
    switch (s) {
    case SFG1_OK: return "ok";
    case SFG1_E_IO: return "transport I/O error";
    case SFG1_E_PROTO: return "protocol error";
    case SFG1_E_BAD_ID: return "not an SF-G1 device";
    case SFG1_E_CFG_MISMATCH: return "device CFG_HASH differs from this host build";
    case SFG1_E_NOT_READY: return "device never became ready";
    case SFG1_E_BUS: return "aperture access rejected";
    case SFG1_E_NOMEM: return "out of memory";
    case SFG1_E_LAUNCH: return "launch descriptor rejected";
    case SFG1_E_FAULT: return "kernel faulted";
    case SFG1_E_TIMEOUT: return "timed out";
    case SFG1_E_ARG: return "bad argument";
    case SFG1_E_FILE: return "file error";
    default: return "unknown error";
    }
}
