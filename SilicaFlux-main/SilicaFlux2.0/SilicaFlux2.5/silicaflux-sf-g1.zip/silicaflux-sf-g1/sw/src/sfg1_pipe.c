/* Pipe transport: fork/exec `python3 <sim_root>/sfg1_devserver.py` and speak the line protocol
 * documented in sim/sfg1/devserver.py and docs/11-host-software.md. */
#define _POSIX_C_SOURCE 200809L
#include "sfg1_host.h"

#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define LINE_MAX_BYTES (1u << 16)
#define XFER_CHUNK 4096u

typedef struct {
    FILE *to, *from;
    pid_t pid;
    char *line;
} pipe_ctx;

static int xchg(pipe_ctx *c, const char *req, char **reply_args)
{
    if (fputs(req, c->to) == EOF || fputc('\n', c->to) == EOF || fflush(c->to) == EOF)
        return SFG1_E_IO;
    if (!fgets(c->line, LINE_MAX_BYTES, c->from))
        return SFG1_E_IO;
    size_t n = strlen(c->line);
    while (n && (c->line[n - 1] == '\n' || c->line[n - 1] == '\r'))
        c->line[--n] = 0;
    if (strncmp(c->line, "OK", 2) == 0 && (c->line[2] == 0 || c->line[2] == ' ')) {
        if (reply_args)
            *reply_args = c->line[2] ? c->line + 3 : c->line + 2;
        return SFG1_OK;
    }
    if (strncmp(c->line, "ERR bus", 7) == 0)
        return SFG1_E_BUS;
    return SFG1_E_PROTO;
}

static int p_reg_read(void *ctx, uint32_t off, uint32_t *val)
{
    char req[48], *args;
    snprintf(req, sizeof req, "RR %x", off);
    int rc = xchg(ctx, req, &args);
    if (rc)
        return rc;
    char *end;
    unsigned long v = strtoul(args, &end, 16);
    if (end == args)
        return SFG1_E_PROTO;
    *val = (uint32_t)v;
    return SFG1_OK;
}

static int p_reg_write(void *ctx, uint32_t off, uint32_t val)
{
    char req[64];
    snprintf(req, sizeof req, "RW %x %x", off, val);
    return xchg(ctx, req, NULL);
}

static int hexval(int ch)
{
    if (ch >= '0' && ch <= '9') return ch - '0';
    if (ch >= 'a' && ch <= 'f') return ch - 'a' + 10;
    if (ch >= 'A' && ch <= 'F') return ch - 'A' + 10;
    return -1;
}

static int p_mem_read(void *ctx, uint32_t addr, void *buf, size_t n)
{
    uint8_t *out = buf;
    char req[64], *args;
    while (n) {
        size_t k = n < XFER_CHUNK ? n : XFER_CHUNK;
        snprintf(req, sizeof req, "MR %x %zu", addr, k);
        int rc = xchg(ctx, req, &args);
        if (rc)
            return rc;
        if (strlen(args) != 2 * k)
            return SFG1_E_PROTO;
        for (size_t i = 0; i < k; i++) {
            int hi = hexval(args[2 * i]), lo = hexval(args[2 * i + 1]);
            if (hi < 0 || lo < 0)
                return SFG1_E_PROTO;
            out[i] = (uint8_t)(hi << 4 | lo);
        }
        out += k; addr += (uint32_t)k; n -= k;
    }
    return SFG1_OK;
}

static int p_mem_write(void *ctx, uint32_t addr, const void *buf, size_t n)
{
    pipe_ctx *c = ctx;
    const uint8_t *in = buf;
    char *req = malloc(2 * XFER_CHUNK + 64);
    if (!req)
        return SFG1_E_NOMEM;
    int rc = SFG1_OK;
    while (n && rc == SFG1_OK) {
        size_t k = n < XFER_CHUNK ? n : XFER_CHUNK;
        int len = snprintf(req, 64, "MW %x ", addr);
        for (size_t i = 0; i < k; i++)
            len += sprintf(req + len, "%02x", in[i]);
        rc = xchg(c, req, NULL);
        in += k; addr += (uint32_t)k; n -= k;
    }
    free(req);
    return rc;
}

static int p_advance(void *ctx, uint64_t max_ticks, uint64_t *ran)
{
    char req[48], *args;
    snprintf(req, sizeof req, "ST %llu", (unsigned long long)max_ticks);
    int rc = xchg(ctx, req, &args);
    if (rc)
        return rc;
    if (ran)
        *ran = strtoull(args, NULL, 10);
    return SFG1_OK;
}

static int p_irq(void *ctx, int *level)
{
    char *args;
    int rc = xchg(ctx, "IRQ", &args);
    if (rc)
        return rc;
    *level = args[0] == '1';
    return SFG1_OK;
}

static void p_close(void *ctx)
{
    pipe_ctx *c = ctx;
    if (!c)
        return;
    xchg(c, "QUIT", NULL);
    fclose(c->to);
    fclose(c->from);
    int st;
    waitpid(c->pid, &st, 0);
    free(c->line);
    free(c);
}

int sfg1_pipe_open(sfg1_transport *t, const char *python, const char *sim_root,
                   const char *config, const char *trace_path)
{
    if (!t || !sim_root || !config)
        return SFG1_E_ARG;
    if (!python)
        python = getenv("SFG1_PYTHON") ? getenv("SFG1_PYTHON") : "python3";
    char script[4096];
    if (snprintf(script, sizeof script, "%s/sfg1_devserver.py", sim_root) >= (int)sizeof script)
        return SFG1_E_ARG;
    int to_child[2], from_child[2];
    if (pipe(to_child) || pipe(from_child))
        return SFG1_E_IO;
    signal(SIGPIPE, SIG_IGN);
    pid_t pid = fork();
    if (pid < 0)
        return SFG1_E_IO;
    if (pid == 0) {
        dup2(to_child[0], 0);
        dup2(from_child[1], 1);
        close(to_child[0]); close(to_child[1]); close(from_child[0]); close(from_child[1]);
        if (trace_path)
            execlp(python, python, script, "--config", config, "--trace", trace_path, (char *)NULL);
        else
            execlp(python, python, script, "--config", config, (char *)NULL);
        _exit(127);
    }
    close(to_child[0]);
    close(from_child[1]);
    pipe_ctx *c = calloc(1, sizeof *c);
    if (!c)
        return SFG1_E_NOMEM;
    c->line = malloc(LINE_MAX_BYTES);
    c->to = fdopen(to_child[1], "w");
    c->from = fdopen(from_child[0], "r");
    c->pid = pid;
    if (!c->line || !c->to || !c->from)
        return SFG1_E_NOMEM;
    memset(t, 0, sizeof *t);
    t->reg_read = p_reg_read;
    t->reg_write = p_reg_write;
    t->mem_read = p_mem_read;
    t->mem_write = p_mem_write;
    t->advance = p_advance;
    t->irq_level = p_irq;
    t->close = p_close;
    t->ctx = c;
    return SFG1_OK;
}
