#!/usr/bin/env python3
"""Run the C demo and compare it with the Python model (and, for the default config, reference/*.json).

Checks per example: C-side verification passed; ticks / warp instructions / lane ops equal the model's;
the FNV-1a checksum of the output equals the model's; and the commit trace the device server wrote
while the C host drove it has the same SHA-256 as the model's trace for a Python-driven run.
"""
import argparse
import hashlib
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "sim"))

from sfg1.examples import run_example  # noqa: E402
from sfg1.spec import Config  # noqa: E402

FNV_KEY = {"vecadd": ("outputs", "c"), "reduce_sum": ("outputs",), "matmul_i32": ("outputs", "C"), "diverge": ("outputs", "out")}


def file_digest(path):
    h = hashlib.sha256()
    for line in Path(path).read_text().splitlines():
        h.update(line.encode())
        h.update(b"\n")
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="default")
    ap.add_argument("--demo", required=True)
    ap.add_argument("--kernels", required=True)
    a = ap.parse_args()
    cfg = Config.from_file(a.config)
    with tempfile.TemporaryDirectory() as td:
        p = subprocess.run([a.demo, "--sim", str(ROOT / "sim"), "--config", a.config, "--kernels", a.kernels, "--trace-dir", td],
                           capture_output=True, text=True)
        print(p.stdout, end="")
        if p.stderr:
            print(p.stderr, end="", file=sys.stderr)
        results = {m.group(1): dict(re.findall(r"(\w+)=(\S+)", m.group(0))) for m in re.finditer(r"RESULT example=(\S+) .*", p.stdout)}
        bad = 0 if p.returncode == 0 else 1
        if len(results) != 4:
            print("expected 4 RESULT lines, got", len(results))
            bad += 1
        for name, got in results.items():
            ex = run_example(name, cfg)
            rep = ex.report
            node = rep
            for k in FNV_KEY[name]:
                node = node[k]
            want = {"ticks": str(rep["stats"]["ticks"]), "warp_insns": str(rep["stats"]["warp_instructions"]),
                    "lane_ops": str(rep["stats"]["lane_ops"]), "fnv": node["fnv1a"], "status": "PASS"}
            for k, v in want.items():
                if got.get(k) != v:
                    print(f"  MISMATCH {name}.{k}: C host saw {got.get(k)}, model says {v}")
                    bad += 1
            tdig = file_digest(Path(td) / f"{name}.jsonl")
            if tdig != rep["trace"]["sha256"]:
                print(f"  MISMATCH {name}: commit-trace digest {tdig[:16]}... != model {rep['trace']['sha256'][:16]}...")
                bad += 1
            if a.config == "default":
                ref = json.loads((ROOT / "reference" / name / "report.json").read_text())
                if ref["stats"] != rep["stats"] or ref["trace"] != rep["trace"]:
                    print(f"  MISMATCH {name}: model differs from reference/")
                    bad += 1
    print("check_demo:", "FAIL" if bad else f"OK (C host results, statistics and commit traces match the model for config {a.config})")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
