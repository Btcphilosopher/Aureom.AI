# 6. Kernel launch

## 6.1 Launch descriptor

A launch is described by a 64-byte, little-endian structure in global memory (16 words); the generated table is
[generated/device_reference.md](generated/device_reference.md), the C layout is `SF_DESC_*` in `sf_g1_regs.h`.

| Word | Name | Meaning |
|---|---|---|
| 0 | `MAGIC` | `0x444B4653` ("SFKD") |
| 1 | `VERSION_FLAGS` | `[31:16]` descriptor version (1); `[15:0]` flags |
| 2 | `CODE_ADDR` | global byte address of the code image, 4-byte aligned |
| 3 | `CODE_WORDS` | number of instructions, `1 .. IMEM_WORDS` |
| 4 | `ENTRY_PC` | entry instruction index, `< CODE_WORDS` |
| 5 | `GRID_DIM` | workgroups, `1 .. 65535` |
| 6 | `WG_DIM` | threads per workgroup, `1 .. MAX_WG_THREADS` |
| 7 | `SHARED_BYTES` | shared bytes per workgroup, multiple of 4, `<= SMEM_BYTES_PER_EG / WG_SLOTS_PER_EG` |
| 8..15 | `ARG0..ARG7` | kernel arguments, read with `rdsr SR_ARG0..7`; typically pointers and sizes |

Flag bit 0, `SMEM_ZERO`: zero each workgroup's shared region at dispatch. All other flag bits are reserved and MUST be zero.

Descriptors are 4-byte aligned; 64-byte alignment is recommended. Pointers in arguments are global byte addresses.

## 6.2 Launch sequence

1. The host places the code image, input data and the descriptor in global memory through the aperture
   (the device MUST be idle, `READY=1`, `BUSY=0`).
2. The host writes the descriptor's address to `LAUNCH_ADDR`.
3. The host writes `DOORBELL` with bit 0 set.
4. **Acceptance.** If `BUSY=1`: the submission is rejected with `LAUNCH_ERR = LE_BUSY`; the running launch is untouched.
   If `FAULTED=1`: rejected with `LE_FAULTED`. (`LAUNCH_ERR` is overwritten by such a rejection and describes the most recent
   submission only: after a `LE_BUSY` rejection it still reads `LE_BUSY` once the running launch has completed, until
   the next accepted doorbell clears it. Check `LAUNCH_ERR` after a single submission.) Otherwise the submission is accepted: `LAUNCH_ERR` is cleared, `STATUS.DONE`
   is cleared, performance counters and workgroup counters are cleared, `LAUNCH_ADDR` is latched, and `STATUS.BUSY` becomes 1.
5. **Launch phase** (reference model: exactly 1 tick). The device reads and validates the descriptor, copies the code image
   into each EG's instruction memory and latches the geometry and arguments. On any validation failure (6.3) the launch
   is abandoned: `BUSY` returns to 0, `LAUNCH_ERR` holds the code, `INT_STATUS.LAUNCH_ERR` is set, and the device stays
   usable.
6. **Execution.** Workgroups are dispatched and run ([05](05-scheduling-sync.md)).
7. **Completion.** When all workgroups have completed and all their memory writes are visible: `BUSY=0`, `DONE=1`,
   `INT_STATUS.DONE` set. A fault instead leaves `FAULTED=1`, `BUSY=0` and `INT_STATUS.FAULT` set ([08](08-errors-reset.md)).

The host learns the outcome by polling `STATUS` or by waiting for the interrupt line ([07](07-registers-interrupts.md)).

## 6.3 Validation and error codes

Checks are performed in this order; the first failure determines the code.

| # | Check | Code |
|---|---|---|
| 1 | `LAUNCH_ADDR` not 4-byte aligned | `LE_ALIGN` |
| 2 | descriptor does not fit in global memory | `LE_RANGE` |
| 3 | `MAGIC` wrong | `LE_MAGIC` |
| 4 | descriptor version is not 1 | `LE_VERSION` |
| 5 | unknown flag bit | `LE_RESERVED` |
| 6 | `CODE_ADDR` not 4-byte aligned | `LE_ALIGN` |
| 7 | `CODE_WORDS` is 0 or above `IMEM_WORDS` | `LE_CODE_SIZE` |
| 8 | code image does not fit in global memory | `LE_RANGE` |
| 9 | `ENTRY_PC >= CODE_WORDS` | `LE_ENTRY` |
| 10 | `GRID_DIM`, `WG_DIM` zero or over their limits | `LE_DIMS` |
| 11 | `SHARED_BYTES` not a multiple of 4 | `LE_ALIGN` |
| 12 | `SHARED_BYTES` over the per-workgroup allocation | `LE_SHARED` |

(`LE_BUSY` and `LE_FAULTED` are reported at the doorbell, before any of the above.) The code image itself is **not**
validated at launch: illegal instructions fault when executed.

## 6.4 Resource constraints worth knowing

* `WG_DIM <= MAX_WG_THREADS = LANES x WARPS_PER_EG`: a workgroup must fit in one EG.
* A workgroup occupies `ceil(WG_DIM / LANES)` warp slots; the EG then has fewer free for other workgroups.
* `SHARED_BYTES` is per workgroup, and workgroups of one EG split the EG's shared memory evenly by slot, whether or not
  they use it all.
* Kernels larger than `IMEM_WORDS` instructions are rejected; kernels larger than 1024 instructions may also be unable to encode
  their branches (branch offsets are 11-bit signed: -1024..+1023 instructions).

## 6.5 Example: from C

```c
sfg1_dev d;  sfg1_transport t;
sfg1_pipe_open(&t, NULL, "sim", "default", NULL);      /* or your own transport */
sfg1_open(&d, &t, 0);                                   /* checks ID and CFG_HASH, reads capabilities */
uint32_t a, b, c;
sfg1_alloc(&d, 4*n, 64, &a); /* ... b, c ... */
sfg1_write_words(&d, a, host_a, n);
sfg1_kernel k;  sfg1_load_kernel_file(&d, "vecadd.sfbin", &k);
uint32_t args[] = { a, b, c, n };
sfg1_result r;
sfg1_launch(&d, &k, (n + 31) / 32, 32, 0, args, 4, 0, &r);   /* grid, wg_dim, shared bytes, args, flags */
if (r.status == SFG1_OK) sfg1_read_words(&d, c, host_c, n);
```

The same flow in Python is `Host.launch` (`sim/sfg1/host.py`).
