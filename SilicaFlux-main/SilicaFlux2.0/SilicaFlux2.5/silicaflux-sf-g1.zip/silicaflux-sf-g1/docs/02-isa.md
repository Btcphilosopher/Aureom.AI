# 2. Instruction set and register organisation

The complete, machine-generated instruction table is [generated/isa_reference.md](generated/isa_reference.md);
it is produced from `spec/sf_g1_isa.json`, which is authoritative. This chapter states the rules.

## 2.1 Register organisation

Each thread has **16 general registers** `r0`..`r15`, each 32 bits wide.

* `r0` always reads as zero; writes to it are discarded. (`zero` is an assembler alias.)
* All registers are zero when a thread starts. There is no other register state visible to software:
  no flags, no condition codes, no predicate registers, no stack pointer, no link register.
* Registers are private to a thread. Lane *i* of a warp reads and writes only the register slice of lane *i*.
* **Special registers** are read-only values obtained with `rdsr`: identity (`SR_LANE_ID`, `SR_WARP_ID`,
  `SR_TID`, `SR_WG_ID`, `SR_GTID`), geometry (`SR_WG_DIM`, `SR_GRID_DIM`, `SR_LANES`, `SR_SHARED_BYTES`) and the eight
  kernel arguments `SR_ARG0`..`SR_ARG7`. All are uniform across a workgroup except the identity values.
  `rdsr` with an undefined index is an illegal instruction.

Storage cost of the default configuration: 2 EG x 4 warps x 8 lanes x 16 regs x 32 bit = 32 Kbit of registers.

## 2.2 Per-lane evaluation

Every instruction is evaluated independently in each **active** lane, using that lane's registers.
Results are written only in active lanes. An instruction never reads a register of another lane;
the only cross-lane effects are through memory, in the order defined in [04](04-memory.md).

All arithmetic is on 32-bit two's-complement values with wrap-around. There are no exceptions
for overflow.

## 2.2.1 Program counter

The architectural **PC is an instruction index**, not a byte address. Instruction *n* is the *n*-th
32-bit word of the code image; it is fetched from instruction memory of the executing EG. The kernel
entry is the descriptor's `ENTRY_PC`. All branch offsets are in instructions and are relative to
the address of the branch instruction itself (not to the next instruction).

## 2.3 Encoding

All instructions are 32 bits, little-endian in memory. Bits `[31:26]` are the **opcode** (6 bits).
The remaining 26 bits are laid out by one of ten **formats**:

```
 31    26 25  22 21  18 17  14 13                        0
 +-------+------+------+------+--------------------------+
 | opcode|  rd  | rs1  | rs2  |   reserved (zero)        |   R   add sub mul and or xor shl shr sar slt sltu atomadd
 +-------+------+------+------+--------------------------+
 | opcode|  rd  | rs1  |            imm18 (signed)        |   I   addi andi ori xori slti sltiu ldg lds
 +-------+------+------+----------------------------------+
 | opcode|  rd  | rs1  | reserved (zero)  |   imm5   |        IS  shli shri sari
 +-------+------+------+------------------+----------+
 | opcode|  rd  |            imm22 (unsigned)           |   U   lui
 +-------+------+---------------------------------------+
 | opcode| rs2  | rs1  |            imm18 (signed)        |   S   stg sts           (rs2 = data register)
 +-------+------+------+----------------------------------+
 | opcode| rs1  |  toff11 (signed) |   roff11 (unsigned)  |   B   bz bnz
 +-------+------+------------------+----------------------+
 | opcode|              off26 (signed)                    |   J   bra
 +-------+------------------------------------------------+
 | opcode| reserved (zero) |         code16               |   T   trap
 +-------+-----------------+------------------------------+
 | opcode|            reserved (zero)                     |   Z   nop exit bar fence
 +-------+------------------------------------------------+
 | opcode|  rd  | reserved (zero)           | sr5 (unsigned)|  SR   rdsr
 +-------+------+---------------------------+--------------+
```

(Exact bit positions per format are in the generated reference. In `B`, `toff` is bits `[21:11]` and
`roff` is bits `[10:0]`; in `SR`, bits `[21:5]` are reserved.)

**Reserved bits MUST be zero.** A word that has any reserved bit set, an undefined opcode, a branch with
`roff = 0`, or an `rdsr` with an undefined special-register index is *illegal*; executing it raises fault
`F_ILLEGAL_INSN` with the word in `FAULT_DATA`. This rule is part of the decoder specification and is
checked bit-for-bit by the RTL conformance vectors.

## 2.4 Instruction summary

| Group | Instructions | Notes |
|---|---|---|
| ALU, register | `add sub mul and or xor shl shr sar slt sltu` | `mul` = low 32 bits. Shift amount is `rs2[4:0]`. |
| ALU, immediate | `addi andi ori xori slti sltiu` | 18-bit **signed** immediate, sign-extended to 32 bits for all of them (also `andi/ori/xori`). `sltiu` compares unsigned against the sign-extended value. |
| Shifts, immediate | `shli shri sari` | Shift amount 0..31 in `imm5`. |
| Constants | `lui` | `rd = imm22 << 10`. A full 32-bit constant is `lui` + `ori` with a 10-bit low part (the `li` pseudo-instruction). |
| Special registers | `rdsr` | |
| Global memory | `ldg stg atomadd` | word accesses at `rs1 + sext(imm18)` (`atomadd`: address is `rs1`) |
| Shared memory | `lds sts` | address relative to the workgroup's shared region |
| Control flow | `bra bz bnz` | `bra`: uniform jump. `bz/bnz`: per-lane conditional, may diverge. |
| Thread/warp control | `exit bar fence trap nop` | |

There is no divide, no compare-and-branch, no condition code: a comparison produces 0/1 in a register
(`slt`, `sltu`, `xor`, ...) and `bz`/`bnz` tests a register against zero.

### Comparison recipes

| Test | Code |
|---|---|
| `a < b` (signed) | `slt t, a, b` |
| `a >= b` | `slt t, a, b` then `bz t, ...` (taken when `a >= b`) |
| `a > b` | `sgt t, a, b` (pseudo for `slt t, b, a`) |
| `a == b` | `xor t, a, b` then `bz t, ...` |
| `a != b` | `xor t, a, b` then `bnz t, ...` |
| `a == const` | `addi t, a, -const` then `bz` |

## 2.5 Semantics of each instruction

Let `A = rs1`, `B = rs2`, all in the executing lane.

* **ALU, shifts, `slt*`, `lui`.** As in the table; `rd <- f(A, B or imm)`. A write to `r0` is discarded.
* **`rdsr rd, sr`.** `rd <- SR[sr]` for each active lane. Values: [generated/isa_reference.md](generated/isa_reference.md).
* **`ldg rd, [rs1 + imm]`, `lds`.** Loads the aligned 32-bit word at the effective address; see
  [04](04-memory.md) for spaces, alignment, ranges and faults.
* **`stg rs2, [rs1 + imm]`, `sts`.** Stores `rs2`. Lanes act in ascending lane order, so when several
  lanes store to the same word the highest active lane wins.
* **`atomadd rd, [rs1], rs2`.** For each active lane in ascending order: `old <- mem[A]; mem[A] <- old + B; rd <- old`.
  The address is exactly `rs1` (no offset). Use `rd = r0` when the old value is not needed.
* **`bra target`.** Every active lane continues at `pc + sext(off26)`. Uniform: it never creates divergence.
* **`bz/bnz rs1, target, reconv`.** A lane is *taken* if `rs1 == 0` (`bz`) or `rs1 != 0` (`bnz`). Taken lanes continue at
  `target = pc + sext(toff11)`, the others at `pc + 1`. If both groups are non-empty the warp diverges and the
  two groups reconverge at `reconv = pc + roff11` ([03](03-execution-model.md)).
  Static checks: both `target` and `reconv` MUST lie inside the code image (else `F_PC_RANGE`, checked
  for every execution of the branch whether or not it is taken; `FAULT_DATA` is the target if the target is outside,
  otherwise the reconvergence address), and `roff >= 1` (else illegal).
* **`exit`.** The active lanes' threads end. They leave the live mask and no instruction ever executes for them again.
* **`bar`.** Workgroup barrier ([05](05-scheduling-sync.md)). Requires `active == live`; otherwise fault `F_BAR_DIVERGENT`.
* **`fence`.** Memory ordering only ([04](04-memory.md)).
* **`trap code16`.** Raises `F_TRAP`, `FAULT_DATA = code16`. For assertions and tests.
* **`nop`.** Does nothing.

## 2.6 Instruction fetch rules

Before an instruction executes, in this order:

1. `pc >= CODE_WORDS` -> fault `F_PC_RANGE` (`FAULT_DATA = pc`). Falling off the end of the code image
   is therefore a fault, never silent termination; kernels end with `exit`.
2. The running path is beyond its reconvergence address (`pc > rpc` of the top stack entry) ->
   fault `F_RECONV` ([03](03-execution-model.md)).
3. The word is illegal -> fault `F_ILLEGAL_INSN`.

All three are *precise*: no architectural state has changed.

## 2.7 Pseudo-instructions

Assembler-only conveniences ([10](10-assembler.md)): `li`, `la`, `mov`, `neg`, `not`, `sgt`, `sgtu`, `j`.
`li rd, expr` becomes one instruction when the value fits the signed 18-bit range or has zero low 10 bits,
and two (`lui`+`ori`) otherwise; a forward reference always reserves two words.

## 2.8 Why this ISA is small on purpose

Every instruction is something the RTL must decode, execute and verify. The set is the minimum that
runs the example kernels (vector add, tree reduction, integer matrix multiply) and a divergence stress
test: add/sub/mul/logic/shift/compare, loads and stores in two spaces, one atomic, a barrier, a fence,
and branches with explicit reconvergence. New instructions need: a row in `sf_g1_isa.json`, semantics in
the model, vectors, and RTL that passes them ([09](09-verification.md)).
