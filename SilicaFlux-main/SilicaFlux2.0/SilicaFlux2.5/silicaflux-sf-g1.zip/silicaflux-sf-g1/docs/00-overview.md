# SilicaFlux SF-G1: overview

SilicaFlux SF-G1 is an **original, educational** SIMT compute architecture designed for Aureom.AI.
It is small enough to hold in your head and precise enough to verify: every behaviour that software
can observe is defined here, implemented by an executable reference model, and checked against any
hardware that claims to implement it.

> **Non-claims.** SF-G1 is not compatible with, derived from, or a subset of CUDA, Vulkan, OpenCL,
> or any commercial GPU instruction set, programming model or driver interface. Words such as *warp*,
> *lane* and *workgroup* are used in the senses defined in [01-terminology.md](01-terminology.md) and
> nowhere else. Do not infer behaviour from other architectures that use the same words.

## What SF-G1 is

* A configurable **SIMT** (single instruction, multiple threads) processor: groups of threads
  (*warps*) execute one instruction stream in lock-step under an execution mask, and diverge and
  reconverge through a hardware stack.
* A deliberately **limited ISA**: 35 fixed-width 32-bit instructions, 32-bit integer arithmetic,
  PC-relative branches, word loads/stores to global and shared memory, one atomic, a barrier and a fence.
  No floating point, no division, no byte/half accesses, no warp shuffles, no recursion, no function calls.
* **Execution groups** (EGs): a small number of replicated compute clusters, each with its own warp
  scheduler, instruction memory, shared memory and barrier hardware. Default: 2 EGs x 4 warps x 8 lanes.
* A **host interface**: 4 KiB of 32-bit registers, a global-memory aperture, one interrupt line,
  a 64-byte kernel launch descriptor, precise faults and a defined reset behaviour.

## Repository map

| Path | Contents |
|---|---|
| `spec/` | Machine-readable specification: `sf_g1_config.json`, `sf_g1_isa.json`, `sf_g1_device.json`, named configurations in `configs/`. **Single source of truth.** |
| `docs/` | This specification. `docs/generated/` holds tables generated from `spec/`. |
| `sim/sfg1/` | Python: assembler, disassembler, SIMT stack, functional simulator and device model, host driver, examples, vector generators. |
| `sim/tests/` | Unit, property and differential tests of the model (86 tests). |
| `examples/kernels/` | `vecadd.sfa`, `reduce_sum.sfa`, `matmul_i32.sfa`, `diverge.sfa`. |
| `reference/` | Golden outputs: result data, statistics, assembler listing and the architectural commit trace of each example. |
| `rtl/` | SystemVerilog: generated package and decoder, ALU, SIMT stack; `rtl/tb/` self-checking testbenches. |
| `verification/blocks.json` | Conformance registry: which RTL blocks exist, how each is checked against the model, which are planned. |
| `tools/` | Generator (`gen.py`), RTL runner, registry gate, mutation checker. |
| `sw/` | C host library, pipe transport to the model, demo and self-test. |
| `bin/sfg1` | Command line: `asm`, `dis`, `run`, `examples`, `vectors`, `devserver`. |

## Order of work

The architecture was brought up in the order the specification demands: **specification, then
assembler and functional simulator, then hardware**. The reference model exists, is tested, and is
what the hardware is measured against.

| Item | State |
|---|---|
| Architecture specification (this directory) | complete for v1.0 |
| Assembler, disassembler, functional simulator, device model | complete, tested |
| Example kernels and golden outputs (vector add, reduction, integer matmul, divergence stress) | complete |
| Host software in C (and Python), driving the model | complete, tested on three configurations |
| Generated RTL package and decoder; ALU; SIMT stack | **verified** against the model (all three configurations), lint-clean, mutation-checked |
| Register file, lane execution, LSU, barrier, scheduler, launch unit, register/interrupt block, core top | **planned, not written**. Each has a registered reference hook and compare statement in `verification/blocks.json`; `make gate` refuses RTL that lacks a passing model-backed test |

The execution pipeline is intentionally not part of this delivery. [09-verification.md](09-verification.md)
defines the rules every later block must follow, and [13-pipeline-plan.md](13-pipeline-plan.md) sketches
how the pipeline maps onto the model's commit trace.

## Quick start

```bash
make test                      # everything: generation check, 86 Python tests, examples vs reference/,
                               #   RTL conformance on 3 configs, mutation check, C host on 3 configs
bin/sfg1 examples              # run the four example kernels on the model
bin/sfg1 run examples/kernels/vecadd.sfa --grid 1 --wg 8 \
    --buf a=1,2,3,4,5,6,7,8 --buf b=8x100 --buf c=8x0 --arg @a --arg @b --arg @c --arg 8 --dump c
bin/sfg1 dis examples/kernels/diverge.sfa
```

Requirements: Python 3 (standard library only; written for 3.9+, tested on 3.13 only), a C11 compiler, Icarus Verilog 12 (`make rtl`),
Verilator 5 (optional, lint only; tested with 5.020). Nothing is downloaded or installed by the build.

## Document guide

| Chapter | Topic |
|---|---|
| [01](01-terminology.md) | lane, warp, workgroup, thread, execution group, grid: precise definitions |
| [02](02-isa.md) | registers, instruction encoding, instruction semantics |
| [03](03-execution-model.md) | execution masks, the reconvergence stack, divergence rules |
| [04](04-memory.md) | memory spaces and the consistency model |
| [05](05-scheduling-sync.md) | dispatch, warp scheduling, barriers, forward progress |
| [06](06-launch.md) | kernel launch descriptors and the launch sequence |
| [07](07-registers-interrupts.md) | device registers, interrupts, performance counters |
| [08](08-errors-reset.md) | faults, launch errors, reset and recovery |
| [09](09-verification.md) | the reference-model contract every hardware block must meet |
| [10](10-assembler.md) | assembler language and structured-control-flow recipes |
| [11](11-host-software.md) | C and Python host libraries, line protocol |
| [12](12-examples-and-reference.md) | example kernels and reference outputs |
| [13](13-pipeline-plan.md) | plan for the execution pipeline (not yet written) |
| [generated/](generated/) | ISA, configuration and device tables generated from `spec/` |

Normative words: **MUST**, **MUST NOT**, **MAY** are used as in RFC 2119. Anything not specified
is *unspecified* and software must not depend on it; the reference model's choice in such cases
is one valid outcome, not a promise.
