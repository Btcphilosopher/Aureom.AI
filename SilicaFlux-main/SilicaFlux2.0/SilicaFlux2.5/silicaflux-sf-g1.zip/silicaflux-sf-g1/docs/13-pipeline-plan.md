# 13. Execution pipeline: plan (not implemented)

The pipeline is deliberately **not** part of this delivery; the assembler, functional simulator, decoder, ALU and SIMT stack come first
and are what the pipeline is built from and checked against. This chapter records how the remaining blocks map to the model so that
the work is incremental and every step is gated by [09](09-verification.md).

## 13.1 Proposed per-EG pipeline

```
 launch unit ──▶ warp table ──▶ scheduler ──▶ fetch/IMEM ──▶ decode ──▶ operand read ──▶ lane ALUs ─┐
                  (per-warp: pc stack, live, state)             (verified)   (regfile)     (verified) │
                                                                                      │ memory ops    ▼
                                         SIMT stack ◀──────────── branch/exit ───────┘     LSU ──▶ shared mem / global port
                                         (verified)                                         │
                                                      barrier unit ◀─── bar/exit ──────────┘          writeback ──▶ regfile
```

* The scheduler picks a ready warp (reference policy: loose round-robin; any work-conserving policy is legal).
* Fetch reads `IMEM[pc]` with `pc` from the SIMT stack; the fetch-time checks of [02](02-isa.md) 2.6 apply.
* Decode is the verified `sf_g1_decode`; the lane ALUs are `LANES` copies of the verified `sf_g1_alu`.
* Branch results feed `sf_g1_simt_stack` commands (`SEQ`, `JUMP`, `BRANCH`, `EXIT`); the stack's multi-cycle resolution is hidden behind `ready`.
* One in-flight instruction per warp (no intra-warp hazards) is the simplest legal design; multithreading across warps hides latency.

## 13.2 Blocks, reference hooks and compare points

(These are the `planned` entries of `verification/blocks.json`.)

| Block | Level | Reference | Compare |
|---|---|---|---|
| register file | L1 | `device.Warp.regs` | read data after each commit; `r0` zero; registers zero at warp start |
| lane execution | L2 | `Device._issue` | commit trace `wb`, `npc`, `nmask`, `depth` for ALU and `rdsr` instructions |
| LSU | L2 | `Device._issue` (memory classes) | `mem` records; precise faults; lane order; atomics |
| barrier unit | L1 | `Device._barrier_check` | set of released warps after each arrive/exit event |
| scheduler | L2 | `Device._eg_step` | per-warp traces and memory unchanged under any legal policy |
| launch unit | L2 | `Device._launch_phase`, `_dispatch_one` | descriptor verdict (`LE_*`), dispatch legality |
| register/interrupt block | L1 | `Device.reg_read/reg_write` | register semantics, `STATUS`, interrupts, soft reset |
| core top | L3 | `Device` + `reference/*` | the four examples, all fault and reset behaviours, `CFG_HASH` |

## 13.3 Suggested order

1. **Register/interrupt block** and **launch unit** (mostly control; vectors can be derived from the host-interface tests already in `test_model.py`).
2. **Register file + lane execution** in a one-warp, one-EG core running straight-line `vecadd`; compare the commit trace digest.
3. **SIMT integration:** add the stack to the core; run `diverge`; compare traces.
4. **LSU and shared memory**, then **barrier unit**: run `reduce_sum`.
5. **Multi-warp scheduler, multi-EG launch**: run `matmul_i32`, then all examples on `default`, `small`, `wide`.
6. Co-simulate with the C host through a transport (the line protocol of [11](11-host-software.md) 11.4 is the intended adapter).

## 13.4 Decisions the plan leaves open

* Memory-system microarchitecture (banking, coalescing, atomic unit placement). Constraint: results equal ascending-lane order ([04](04-memory.md) 4.4) and the rules C1-C8.
* Whether instruction memory is a copy per EG (as modelled) or a shared cache. Constraint: the image is latched at launch.
* Pipeline depth and hazard handling. Constraint: per-warp in-order commit; the commit trace is the contract.
* How multi-cycle `SIMT stack` resolution overlaps fetch of the next instruction (the next pc is not known until `ready`).
