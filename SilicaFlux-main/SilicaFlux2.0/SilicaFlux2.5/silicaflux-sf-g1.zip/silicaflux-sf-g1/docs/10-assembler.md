# 10. Assembler language

`bin/sfg1 asm kernel.sfa -o kernel.sfbin [--hex kernel.hex] [--listing kernel.lst] [--symbols kernel.json]`

Outputs: `.sfbin` (raw little-endian words, what the launch descriptor points at), `.hex` (`$readmemh` format, one word per line,
for RTL instruction memories), a listing and a symbol table. Warnings go to stderr. `bin/sfg1 dis` disassembles; the
output re-assembles to the same words (tested).

## 10.1 Syntax

```
; comment to end of line      // also a comment
label:        add  r1, r2, r3       ; labels may share a line with an instruction
.equ  N, 4*8                         ; constant (expression; may use earlier symbols)
.reg  acc, r9                        ; register alias
.word 0x12345678, -1, label          ; raw data words (also usable to hand-encode instructions)
```

* Mnemonics, register names and `zero` are case-insensitive; labels and constants are case-sensitive.
* Registers: `r0`..`r15`. Special-register names (`SR_TID`, ...) are predefined constants for `rdsr`.
* Immediates are expressions: decimal, `0x..`, `0b..`, symbols, `+ - * / % << >> & | ^ ~`, parentheses, `%hi(x)`
  (`x >> 10`) and `%lo(x)` (`x & 0x3ff`).
* Memory operands: `[r5]`, `[r5 + 8]`, `[r5 - 4]`, `[r5 + N*4]`. `atomadd` takes `[rN]` only.
* **Branch operands are absolute labels** (instruction indices); the assembler converts them to PC-relative offsets and range-checks them:
  `bz r3, target, reconv`, `bra target`.
* `lui rd, imm22` takes the raw 22-bit field: it loads `imm22 << 10`.

## 10.2 Diagnostics

All errors in a file are collected and reported as `file:line: error: message`: unknown mnemonic, wrong operand count,
unknown register (`r16` does not exist), immediate out of range, undefined or duplicate symbol, reconvergence address not after the branch,
branch offset not encodable. Warning: branch `target` beyond its `reconv` (it will fault with `F_RECONV` if the branch diverges).

## 10.3 Pseudo-instructions

| Form | Expands to |
|---|---|
| `li rd, expr` | `addi rd, r0, v` (v fits 18-bit signed) / `lui rd, v>>10` (low 10 bits zero) / `lui` + `ori` |
| `la rd, label` | same as `li` |
| `mov rd, rs` | `addi rd, rs, 0` |
| `neg rd, rs` | `sub rd, r0, rs` |
| `not rd, rs` | `xori rd, rs, -1` |
| `sgt rd, a, b` / `sgtu` | `slt rd, b, a` / `sltu rd, b, a` |
| `j label` | `bra label` |

A forward-referenced `li` reserves two words and is padded with `nop` if the value turns out small.

## 10.4 Structured control flow: recipes

Registers `t`, `i`, `n`... are any free registers.

**Guard** (`if (gtid < n) { body }`) — skip the body for out-of-range lanes:
```
    slt  r3, r1, r2
    bz   r3, done, done        ; lanes with r3 == 0 wait at `done`
    ...body...
done:
```

**If / else:**
```
    bz   c, else, end
    ...then...
    bra  end
else:
    ...else...
end:
```

**Counted loop with a per-lane trip count** (test at top):
```
loop:
    slt  t, i, n
    bz   t, loopend, loopend
    ...body...
    addi i, i, 1
    bra  loop
loopend:
```

**Do-while** (back-edge at the end; the fall-through is the reconvergence address):
```
loop:
    ...body...
    bnz  c, loop, after
after:
```

**Early thread exit:**
```
    bnz  ok, go, go
    exit
go:
```

**Break from inside an `if`** — the enclosing `if` must reconverge at the loop exit (see [03](03-execution-model.md) 3.6):
```
loop:
    ...
    bz   c, endif, loopexit    ; NOT endif
    bnz  b, loopexit, loopexit ; break
    ...
endif:
    ...
    bra  loop
loopexit:
```

**Barrier in a loop** (all threads must execute `bar` the same number of times, and not while diverged):
```
step:
    bar
    ...divergent work reconverging before the next bar...
    bnz  s, step, after        ; uniform loop condition
after:
```

## 10.5 Kernel conventions used by the examples

* Identity from `rdsr`; arguments are pointers (byte addresses) and sizes; array index to byte offset is `shli r, idx, 2`.
* A `rd = r0` atomic keeps traces scheduling-independent.
* Kernels end with `exit` on every path (`exit` also at a join label is fine).
