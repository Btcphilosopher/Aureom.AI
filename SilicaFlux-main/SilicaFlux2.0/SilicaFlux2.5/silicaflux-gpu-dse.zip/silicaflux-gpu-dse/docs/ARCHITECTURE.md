# SFG-CU architecture (the design under exploration)

The SilicaFlux GPU compute unit (SFG-CU) is a parameterised SIMT core written
for this study in a conservative SystemVerilog subset that Verilator 5, Icarus
Verilog 12 and Yosys 0.33 all accept. Every design-space dimension is a real
RTL parameter that changes the generated hardware.

```
             +-----------+   +----------------+   +--------------------------+
 imem  ----> |  fetch +  |-->| issue: warp    |-->| operand collect (RD)     |
 (1024 w)    |  per-warp |   | dispatcher,    |   | banked RF, 1R+1W / bank  |
             |  ibuf[IBD]|   | scoreboard,    |   +------------+-------------+
             +-----------+   | LRR scheduler  |                |
                             +----------------+   +------------v-------------+
                                                  | execute (EX): LANES-wide |
                                                  | 32-bit int ALU, MUL/MAD  |
                                                  +--+---------+---------+---+
                                                     |ALU wb   |mem req  |MMA start
                                    +----------------v-+  +----v----+  +-v-----------+
                                    | register file    |  | LSU     |  | matrix unit |
                                    | RFB banks        |<-| queue   |  | TMxTNxTK    |
                                    +------------------+  | L1D+MSHR|  | MACs        |
                                                          | LB/warp |  +------+------+
                                                          +--+---+--+         |
                                             line req/resp   |   | smem ports |
                                          <------------------+   +--> shared memory <--+
                                                                      SMB banks, NW KiB
```

## ISA (fixed for every candidate)

* 32-bit instructions, 16 x 32-bit registers per thread (r0 = 0), warps of 16 threads.
* Integer ALU: ADD SUB MUL AND OR XOR SHL SHR SRA SLT SLTU MIN MAX, MAD (rd = a*b+c),
  SEL (rd = a ? b : c), immediates ADDI ANDI ORI XORI SHLI SHRI SRAI SLTI MULI LUI, S2R
  (TID, WID, NWARPS, GTID).
* Memory: LD/ST (global, 1 MiB byte-addressed, word aligned), LDS/STS (private 1 KiB
  shared-memory window per resident warp).
* MMA rA, rB, rC: C[8x8] += A[8x8] x B[8x8] on shared-memory tiles (signed 16-bit A/B
  elements, 32-bit C), 64-byte aligned bases. The *hardware* tile TMxTNxTK only changes
  how many cycles the instruction takes, so binaries are identical across candidates.
* Control: BRZ/BNZ (warp-uniform condition), JMP, EXIT.

Encodings are defined once in `sfdse/isa.py`; `rtl/sfg_defs.svh` mirrors them and
`tests/test_isa_sync.py` checks the two agree.

## Microarchitecture and the explored parameters

| Parameter | RTL | What it changes |
|---|---|---|
| lanes | `LANES` | SIMD datapath width. A 16-thread warp instruction executes in 16/LANES passes; ALU area scales with LANES. |
| resident_warps | `NW` | Warp slots: per-slot instruction buffer, scoreboard, load buffer, 1 KiB shared-memory window. More slots hide more latency. |
| rf_banks | `RFB` | Register r of a warp lives in bank r % RFB; each bank has one read and one write port, so operands of a 2/3-source instruction that share a bank are read in successive cycles, and a load writeback yields to an ALU writeback on the same bank. |
| ibuf_depth | `IBD` | Per-warp instruction buffer (fetch runs ahead until a control instruction). |
| lsu_queue_depth | `LQD` | LSU request queue; issue holds a credit per memory instruction. |
| mshrs | `NMSHR` | Outstanding L1 line misses. Secondary misses to a pending line merge into its MSHR; stores to a pending line wait. |
| l1 sets/ways/line_bytes | `L1S/L1W/LINEB` | Write-through, no-write-allocate L1D with FIFO replacement. One cache line is resolved per two cycles; a warp access costs one step per distinct line touched. |
| smem_banks | `SMB` | Word-interleaved shared-memory banks; lanes hitting different words of one bank serialise, same-word lanes broadcast. Also sets the MMA unit's load/store bandwidth (SMB words/cycle). |
| mma_tile m/n/k | `TM/TN/TK` | Matrix-unit MAC array (TM*TN*TK 16x16 multipliers). An MMA takes 192/SMB load cycles + 512/(TM*TN*TK) compute cycles + 64/SMB store cycles. |

Fixed environment for all candidates: 16-thread warps, 16 registers, 1 KiB shared
memory per resident warp, 40-cycle memory latency, 16 B/cycle memory bus, 16-entry
memory request queue.

## Negative control

`negative_control: smem_conflict_skip` (RTL `NEG=1`) serves every shared-memory lane in
one cycle regardless of bank conflicts: conflicting lanes read the wrong word and
conflicting stores are dropped. It is faster on conflict-heavy kernels and wrong. It
exists only to demonstrate that the correctness gate removes faster-but-incorrect
designs from the ranking; it is generated as an explicit control, never sampled.
