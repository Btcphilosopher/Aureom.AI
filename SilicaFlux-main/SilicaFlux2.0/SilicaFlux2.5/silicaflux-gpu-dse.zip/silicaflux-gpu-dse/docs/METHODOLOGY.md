# Methodology

## 1. One validated schema

`schema/sfg_config.schema.json` is the single source of truth:

* JSON-Schema (draft 2020-12) types and per-field domains (`enum`) for every
  dimension; `additionalProperties: false` everywhere, so unknown or misspelt
  fields are rejected.
* `x-rtl` maps each field to its RTL parameter; `x-fixed` holds environment
  constants (warp size, memory model, target-device capacities); `x-derived`
  defines derived quantities (L1 bytes, MAC count, DSP estimate, ...).
* `x-constraints` are cross-field rules in a restricted expression language
  (`sfdse/schema.py` evaluates them over an AST whitelist - no `eval` of
  arbitrary code). `kind: architectural` rules encode legality (lanes divide
  the warp, hardware MMA tile divides the ISA tile, ...); `kind: resource`
  rules encode a-priori budgets (MAC array <= 64, estimated MULT18 <= device,
  L1 <= 16 KiB).

Every candidate - baseline, sweep, random sample, refinement neighbour or
control - is built with `schema.unflatten()` and must pass `schema.validate()`
before any file is generated. Rejected combinations are recorded with the
violated rule ids and are listed in the report.

`sfdse/configgen.py` then generates the candidate's configuration files
(`config.json`, Verilator `-G` file, Yosys `chparam` arguments, Icarus
parameter include, make-style list) from the validated object only.

## 2. Per-candidate pipeline

| Step | Tool | Gate |
|---|---|---|
| Lint | Verilator `--lint-only -Wall`; Icarus elaboration | any error fails the candidate (warnings counted) |
| Build | Verilator (`-O1`), cycle-accurate model of CU + testbench + memory model | build failure stops the candidate |
| Correctness suite | 8 kernels: every ALU opcode with edge operands, control flow and slot reuse (37 warps), global-memory corner cases, shared-memory bank patterns, MMA incl. aliasing, 3 constrained-random programs | every output word must equal the golden model; hang/timeouts fail |
| Cross-simulation | Icarus Verilog runs the same correctness suite | outputs AND cycle counts must match Verilator exactly |
| Selection workloads | 6 kernels, identical binaries and data for all candidates | bit-exact vs golden; cycles + 26 performance counters collected |
| Synthesis | Yosys 0.33 `synth_ecp5 -abc9`, per module, cached | LUT4/FF/MULT18/DP16KD/LUTRAM; device fit <= 85 % peak utilisation |
| Place (& route) | nextpnr-ecp5 on LFE5UM-85F (shortlist only) | Fmax from post-placement STA; full route attempted for the final pick and baseline |
| Held-out evaluation | 6 different kernels, only after the decision is frozen | bit-exact vs golden |

The **golden model** (`sfdse/golden.py`) is an untimed ISA interpreter. It
rejects kernels whose result could depend on scheduling or stale state
(inter-warp races, uninitialised register/shared-memory reads, divergent
branches, misaligned/out-of-range addresses), so each accepted kernel has
exactly one correct final memory image. Each workload also carries an
independent NumPy reference that the golden output must match, so the golden
model itself is checked.

A candidate is **verified** only if lint, every correctness kernel on both
simulators (with identical cycle counts) and every selection workload pass.
Unverified candidates keep all their numbers in the results (including their
speed), but they are never eligible for any Pareto front or ranking.

A deliberately wrong **negative control** (`smem_conflict_skip`) is part of every
study to demonstrate the gate.

## 3. Selection vs. evaluation workloads

* `selection` (vecadd, gather, transpose_swizzled, gemm_mma, alu_poly,
  reduce_smem) drives the refinement round, the place-and-route shortlist, the
  Pareto fronts and the recommendation.
* `evaluation` (stencil1d, spmv_ell, gemm_mma_epilogue, fir16,
  matvec_rowmajor, rowblur_smem) uses different algorithms, problem shapes,
  access patterns and random seeds. `check_suite_separation()` asserts that no
  program+data image appears in both suites.
* The `freeze` stage writes `frozen/shortlist.json` (rule, objectives, ranked
  front, source digest, SHA-256) **before** any evaluation workload is run; the
  `evaluate` stage refuses to run without it, and `freeze` refuses to run again
  once evaluation results exist (unless `--force-refreeze`, which is recorded).
* After evaluation, the final recommendation is the first entry of the frozen
  ranking that also passes every held-out workload. The held-out speedups are
  reported next to the selection speedups and their rank correlation is plotted
  to expose over-fitting.

## 4. Metrics

* **Performance** - per workload, `speedup = baseline_cycles / candidate_cycles`;
  suite score = geometric mean. *Wall-clock* speedup multiplies by
  `Fmax_candidate / Fmax_baseline`.
* **Resources** - LUT4 (primary objective), plus FF, MULT18X18D, DP16KD, LUTRAM
  and peak utilisation of the LFE5UM-85F.
* **Timing** - Fmax (MHz): nextpnr-ecp5 post-placement static timing for ranking; routed Fmax for the final pick and baseline where routing completes within the limit.
* **Energy** - unavailable (see LIMITATIONS).

## 5. Exploration strategy (bounded)

1. Baseline.
2. One-at-a-time sweep of every dimension over its bounded domain.
3. Seeded uniform random samples (rejected draws are logged).
4. Negative control.
5. Refinement: neighbours (one step in one dimension) of the 2-objective front
   (selection speedup vs LUT4), verified and synthesised.
6. Placement (timing) of the baseline plus the best Pareto ranks (non-dominated
   sorting on speedup/LUT4), up to `pnr.max_candidates`.
7. 3-objective Pareto front (speedup max, LUT4 min, Fmax max) and the frozen
   rule from the study file.

## 6. Reproducibility

`manifest.json` records tool versions, the SHA-256 digest of RTL + testbench +
schema + Python sources, every command line, and per-stage wall time. All seeds
(study sampling, workload data, nextpnr) are fixed. Each candidate directory
keeps its generated config files, lint/build/simulation logs, per-workload
`perf.txt`, Yosys scripts/logs (in `synth_cache/`) and nextpnr command/logs.
