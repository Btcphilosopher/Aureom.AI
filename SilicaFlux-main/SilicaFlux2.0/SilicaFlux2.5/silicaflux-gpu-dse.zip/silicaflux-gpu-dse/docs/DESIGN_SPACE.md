# Design space (generated from schema/sfg_config.schema.json - do not edit)

| field | RTL parameter | domain | description |
|---|---|---|---|
| lanes | `LANES` | [4, 8, 16] | SIMD datapath lanes; a 16-thread warp instruction takes 16/lanes passes |
| resident_warps | `NW` | [2, 4, 8, 16] | Resident warp slots (occupancy); each slot owns registers, a load buffer and a 1 KiB shared-memory window |
| rf_banks | `RFB` | [1, 2, 4] | Register-file banks, 1 read + 1 write port each; register r lives in bank r % rf_banks |
| ibuf_depth | `IBD` | [1, 2, 4] | Per-warp instruction-buffer depth (queue depth) |
| lsu_queue_depth | `LQD` | [1, 2, 4, 8] | LSU request-queue depth, credits counted at issue (queue depth) |
| mshrs | `NMSHR` | [1, 2, 4, 8] | Miss-status holding registers = outstanding line reads (memory-request capacity) |
| l1.sets | `L1S` | [4, 8, 16, 32, 64] |  |
| l1.ways | `L1W` | [1, 2, 4] |  |
| l1.line_bytes | `LINEB` | [16, 32, 64] |  |
| smem_banks | `SMB` | [2, 4, 8, 16] | Word-interleaved shared-memory banks |
| mma_tile.m | `TM` | [1, 2, 4, 8] |  |
| mma_tile.n | `TN` | [1, 2, 4, 8] |  |
| mma_tile.k | `TK` | [1, 2, 4, 8] |  |

Full cross-product: **19,906,560** points.

## Fixed environment (`x-fixed`)

| name | value |
|---|---|
| warp_size | 16 |
| num_regs | 16 |
| smem_window_bytes | 1024 |
| global_bytes | 1048576 |
| imem_words | 1024 |
| isa_mma_tile | 8 |
| mem_latency_cycles | 40 |
| mem_bus_bytes_per_cycle | 16 |
| mem_queue_entries | 16 |
| target_device | Lattice ECP5 LFE5UM-85F (CABGA381) |
| device_lut4 | 83640 |
| device_ff | 83640 |
| device_mult18 | 156 |
| device_bram_dp16kd | 208 |
| dsp_mult18_per_lane | 3 |
| resource_lut_fraction_max | 0.85 |

## Derived quantities (`x-derived`)

| name | expression |
|---|---|
| passes | `warp_size // lanes` |
| l1_bytes | `l1_sets * l1_ways * line_bytes` |
| mma_macs | `mma_m * mma_n * mma_k` |
| smem_bytes | `resident_warps * smem_window_bytes` |
| rf_bits | `resident_warps * num_regs * warp_size * 32` |
| mult18_estimate | `lanes * dsp_mult18_per_lane + mma_macs` |

## Constraints (`x-constraints`)

| id | kind | expression | rationale |
|---|---|---|---|
| A1 | architectural | `warp_size % lanes == 0` | lanes must divide the 16-thread warp |
| A2 | architectural | `num_regs % rf_banks == 0` | rf_banks must divide the 16 architectural registers |
| A3 | architectural | `smem_banks <= warp_size` | more shared-memory banks than threads per warp cannot be exercised by one warp access |
| A4 | architectural | `line_bytes >= mem_bus_bytes_per_cycle` | a cache line must cover at least one memory-bus beat |
| A5 | architectural | `mshrs <= mem_queue_entries` | outstanding misses cannot exceed the memory request queue |
| A6 | architectural | `isa_mma_tile % mma_m == 0 and isa_mma_tile % mma_n == 0 and isa_mma_tile % mma_k == 0` | hardware MMA tile must evenly divide the ISA 8x8x8 tile |
| A7 | architectural | `l1_bytes >= 512` | L1 smaller than 512 B cannot hold one line per resident-warp working set |
| R1 | resource | `mma_macs <= 64` | matrix-unit MAC array budget is 64 multipliers |
| R2 | resource | `mult18_estimate <= device_mult18` | estimated MULT18X18 demand (3 per 32-bit lane multiplier, calibrated on the baseline flat netlist, + 1 per matrix MAC) exceeds the target device |
| R3 | resource | `l1_bytes <= 16384` | L1 capacity budget is 16 KiB |
