# Run notes for results/sfg_dse_v1 (kept for transparency)

* The run was started with `python3 -m sfdse.explore run --study studies/default.json --out results/sfg_dse_v1 --jobs 4`
  and completed the generate, verify, synth and refine stages unmodified.
* At the start of the `pnr` stage a defect in the shortlist selection was noticed: the selection-stage
  Pareto front had grown to 15 members, the placement cap was 14, and the code truncated the
  LUT4-sorted front, which silently dropped the **highest-performance** end of the front. The run was
  stopped before any placement finished and before `freeze`; no held-out data had been produced.
* Fix (`sfdse/explore.py::stage_pnr`): the shortlist now always spans the whole front (evenly spaced,
  both extremes kept) and only then fills spare slots from later Pareto ranks. The cap was raised
  from 14 to 16 (front + baseline) in `studies/default.json`.
* The remaining stages were then run individually with `stage pnr`, `stage freeze`, `stage evaluate`,
  `stage confirm`, `stage report` (see `manifest.json` -> `runs`). Verification, synthesis and
  refinement results were reused unchanged; RTL and testbench sources were not modified at any point
  of the run (the source digest changes only through the Python fix above and report-formatting edits).
* The `confirm` stage attempted full routing of the recommendation and the baseline with router1 and a
  1-hour limit; both timed out with ~217K-227K arcs still unrouted. Timing in this study is therefore the
  post-placement estimate only.
