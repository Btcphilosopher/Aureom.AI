# SilicaFlux GPU design-space exploration (sfdse)

A Python system that configures, simulates, verifies, synthesises and compares
SystemVerilog implementations of a parameterised SilicaFlux GPU compute unit
(SFG-CU), and recommends a configuration with evidence.

```
schema/sfg_config.schema.json   one validated schema: domains, RTL mapping, constraints
rtl/                            parameterised SFG-CU (SystemVerilog) + P&R timing wrapper
tb/                             system testbench (memory model, perf counters), Verilator/Icarus harnesses
sfdse/                          Python package
  isa.py asm.py golden.py         ISA, assembler, golden reference model
  workloads/                      correctness, selection and held-out evaluation kernels
  schema.py configgen.py          validation / constraint evaluation / config-file generation
  sim.py synth.py                 lint, simulator builds, runs, Yosys + nextpnr
  explore.py pareto.py report.py  orchestration, Pareto analysis, reports
studies/default.json            the bounded study that produced results/
results/sfg_dse_v1/             all results (see report/index.html)
docs/                           ARCHITECTURE, METHODOLOGY, LIMITATIONS, DESIGN_SPACE (generated), RUN_NOTES
tests/                          unit tests
```

## Explored dimensions (all real RTL parameters)

| Dimension | Domain | RTL |
|---|---|---|
| SIMD lanes | 4, 8, 16 | `LANES` |
| resident warps | 2, 4, 8, 16 | `NW` |
| register-file banks | 1, 2, 4 | `RFB` |
| queue depths: instruction buffer / LSU queue | 1-4 / 1-8 | `IBD` / `LQD` |
| memory-request capacity (MSHRs) | 1, 2, 4, 8 | `NMSHR` |
| L1D sets / ways / line bytes | 4-64 / 1-4 / 16-64 | `L1S` `L1W` `LINEB` |
| shared-memory banks | 2, 4, 8, 16 | `SMB` |
| matrix tile m x n x k | 1-8 each, <= 64 MACs | `TM` `TN` `TK` |

The schema admits ~2x10^7 combinations; architectural and resource rules
(`x-constraints`) reject illegal ones before anything is generated.

## Results of `results/sfg_dse_v1` (summary - evidence in `results/sfg_dse_v1/report/`)

* **Space**: 19,906,560 schema points; **82 generated**, **16 rejected** by constraints
  (L1 < 512 B, MAC array > 64, DSP estimate over device), **66 simulated** (baseline, 34
  one-at-a-time sweeps, 20 seeded random samples, 10 Pareto-refinement neighbours, 1 negative control).
* **Correctness**: all 65 real candidates passed lint, the 8-kernel correctness suite on Verilator
  *and* Icarus (identical outputs and cycle counts), the 6 selection kernels and - after the freeze -
  the 6 held-out kernels, all bit-exact against the golden model.
* **Negative control** (`...-neg`, shared-memory conflict serialisation skipped): faster on some kernels
  (1.001x selection geomean) but failed 5 correctness kernels, Icarus cross-sim, 3 selection kernels and
  2 held-out kernels. It is kept in every table and never ranked.
* **Resources**: 10 verified candidates exceed the LFE5UM-85F (peak utilisation > 85 %), including the two
  fastest overall (1.66x and 1.63x selection speedup at 104K / 98K LUT4). 55 candidates are eligible.
* **Sensitivity (one-at-a-time around the baseline, selection-suite cycle speedup / LUT4)**:
  MSHRs 1 -> 8: 0.41x -> 1.17x for +0.3 % LUT4 (strongest, cheapest knob);
  line 16 -> 64 B: 0.62x -> 1.16x (+15 % LUT4); lanes 4 -> 16: 0.75x -> 1.13x (44K -> 81K LUT4, 16 lanes does
  not fit); resident warps 2 -> 4 -> 16: 0.76x -> 1.00x -> 0.96x; shared-memory banks 2 -> 16: 0.91x -> 1.01x
  (+47 % LUT4 for the crossbar); RF banks 1 -> 4: 0.95x -> 1.03x; instruction-buffer depth, LSU queue depth,
  L1 sets/ways and the MMA tile change cycles by <= 4 % on these kernels (`gemm_mma` is bound by global
  loads, so a bigger MAC array does not help).
* **Generalisation**: Spearman rank correlation between selection and held-out speedups over all 65
  verified candidates is 0.947.
* **Timing**: 16 shortlisted candidates (whole speedup/LUT4 Pareto front + baseline) were placed:
  14.6 - 21.6 MHz post-placement estimate; baseline 17.1 MHz. Full routing of the recommendation and the
  baseline was attempted (router1, 1 h limit) and did **not** complete (~220K arcs still unrouted), so no
  routed Fmax exists. The RTL is not timing-optimised (see LIMITATIONS).
* **Recommendation** (rule frozen, SHA-256 recorded, before held-out data): **`l8w4b2i2q4m8c16x2x32s8t222`** -
  the baseline with 8 MSHRs: 1.169x selection / **1.172x held-out** cycle speedup, 16.7 MHz placed
  (baseline 17.1 MHz, i.e. -2.6 %; single placement seed, seed variation not measured), 1.14x wall-clock, 54.7K LUT4
  (65 % of the device), 33 MULT18, 24 DP16KD. Energy: unavailable.

## Quick start

```bash
make deps-check          # verilator, iverilog, yosys, nextpnr-ecp5, numpy, jsonschema, matplotlib
make unit                # ISA/RTL sync, schema, golden model + workload references
make smoke               # ~10 min end-to-end mini study (no place & route)
make explore             # the full study (hours, resumable: completed work is reused)
make report OUT=results/sfg_dse_v1
```

Ubuntu 24.04 packages used: `verilator 5.020`, `iverilog 12.0`, `yosys 0.33`,
`nextpnr-ecp5 0.6`, `fpga-trellis 1.4`; Python 3.10+ with the packages in
`requirements.txt`. Exact versions of the recorded run are in
`results/sfg_dse_v1/manifest.json`.

## What happens to every candidate

1. **Generate** configuration files from the validated schema object.
2. **Lint** (Verilator `-Wall`, Icarus elaboration) and **correctness tests**:
   8 kernels (all opcodes with edge operands, control flow, memory and
   shared-memory corner cases, MMA incl. aliasing, 3 constrained-random
   programs) must match the golden model bit-for-bit, and Icarus must reproduce
   Verilator's outputs *and cycle counts*.
3. **Identical workloads**: the same binaries and data on every candidate.
4. **Simulation metrics**: cycles and 26 hardware performance counters per run.
5. **Synthesis** (Yosys -> ECP5) for resources; **place & route** (nextpnr) of
   the shortlist for Fmax.
6. **Tool versions, logs, commands and results** are recorded per candidate.

Faster-but-incorrect designs are never ranked; a deliberately broken negative
control demonstrates the gate. Selection and held-out evaluation workloads are
separate, and the decision is frozen (hashed) before the held-out suite runs.
Energy is reported as unavailable (no measurement, no validated power model).

See `results/sfg_dse_v1/report/index.html` (searchable table + plots),
`RECOMMENDATION.md`, `FAILURES.md` and `REPRODUCE.md` in the same folder.

The recorded run was interrupted once (before any decision was frozen) to fix a
shortlist-selection defect; see `docs/RUN_NOTES.md`.
