#!/usr/bin/env bash
# SilicaFlux IOSHELL -- build one Verilator testbench variant.
#   scripts/build_sim.sh <name> [TECH=sim|ihpsim] [+define+...]
# e.g. scripts/build_sim.sh min sim ; scripts/build_sim.sh hpcsim sim +define+TB_DIE_CFG=1 +define+TB_DIE_HPC +define+TB_MEM_CTRL=1 +define+SF_IO_SIM_MODELS
set -euo pipefail
cd "$(dirname "$0")/.."
NAME=$1; TECH=${2:-sim}; shift 2 || true
OUT=build/v_$NAME
mkdir -p "$OUT"
EXTRA=()
for a in "$@"; do EXTRA+=("$a"); done
SIMF=()
if printf '%s\n' "${EXTRA[@]:-}" | grep -q SF_IO_SIM_MODELS; then SIMF=(-f rtl/files_sim_models.f); fi
verilator --binary --timing -O2 -j "${JOBS:-4}" -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD \
  --top-module tb_io_shell -Mdir "$OUT" -o vtb "${EXTRA[@]}" \
  -f rtl/files_tech_${TECH}.f -f rtl/files_core.f "${SIMF[@]}" \
  third_party/silicaflux-dietop/third_party/silicaflux-datafabric/tb/common/sfb_protocol_checker.sv \
  +incdir+tb/generated tb/tb_io_shell.sv > "$OUT/build.log" 2>&1
echo "built $OUT/vtb"
