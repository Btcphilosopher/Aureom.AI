#!/usr/bin/env python3
"""SilicaFlux IOSHELL :: floorplan pin-placement report + floorplan picture.

Inputs: physical/generated/padring.json (plan), build/phys/or/silicaflux_io_shell.def
(OpenROAD result), LEFs, inventory.  Outputs:
  reports/physical/PIN_PLACEMENT.md     per-side pad table, region orientation, pad-net lengths
  reports/physical/floorplan.svg        die, seal-ring zone, IO ring, bond pads, core block, shell cells
  reports/physical/pad_nets.csv         half-perimeter length of every pad core-side net (placed)
"""
from __future__ import annotations

import csv
import json
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import check_physical as C  # noqa: E402
import sfio_inv as I  # noqa: E402
from sfio_lef import read_lef  # noqa: E402

ROOT = I.ROOT
GROUP_COL = {"clkrst": "#c0392b", "clock": "#e74c3c", "straps": "#8e44ad", "status": "#2980b9", "ras": "#d35400",
             "jtag": "#16a085", "mgmt_uart": "#27ae60", "mgmt_spi": "#2ecc71", "mgmt_gpio": "#7f8c8d",
             "host_link": "#f39c12"}
SUP_COL = {"VDD": "#e8b4b4", "VSS": "#b4c8e8", "IOVDD": "#f2d0a4", "IOVSS": "#a4d8f2"}
REGION = {"N": "control region: clock / reset root, straps, status, RAS",
          "E": "host region: host-command link (+ reserved PCIe sideband, PCIe PHY in milestone B)",
          "S": "memory region: reserved for the DDR / HBM PHY of milestone B (supplies only today)",
          "W": "test / debug + management: JTAG near the north-west corner, UART, SPI, GPIO"}


def main():
    inv = I.load()
    plan = json.loads((ROOT / "physical/generated/padring.json").read_text())
    geo = plan["geometry"]
    lef = read_lef([ROOT / "third_party/ihp-sg13g2/lef/sg13g2_tech.lef", ROOT / "third_party/ihp-sg13g2/lef/sg13g2_stdcell.lef",
                    ROOT / "third_party/ihp-sg13g2/lef/sg13g2_io.lef", ROOT / "third_party/ihp-sg13g2/lef/bondpad_70x70.lef",
                    ROOT / "build/phys/sf_io_die_core_abstract.lef"])
    df = C.read_def(C.DEF)
    comps = df["comps"]
    core_abs = json.loads((ROOT / "build/phys/core_abstract.json").read_text())
    W, H = geo["die"][2], geo["die"][3]

    def loc(inst, pin):
        c = comps.get(inst)
        if not c or not c["xy"]:
            return None
        m = lef.macros[c["master"]]
        if pin in m.pins and m.pins[pin].shapes:
            r = C.rect_of(c, m, m.pins[pin].shapes[0][1:])
            return ((r[0] + r[2]) / 2, (r[1] + r[3]) / 2)
        b = C.bbox(c, m)
        return ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)

    # nets touching a pad core pin
    pad_inst = {s["inst"]: s for s in plan["slots"] if s["kind"] == "signal"}
    rows = []
    for net, conns in df["nets"].items():
        if net in ("VDD", "VSS", "IOVDD", "IOVSS"):
            continue
        hit = [(i, p) for i, p in conns if i in pad_inst and p in ("p2c", "c2p", "c2p_en")]
        if not hit:
            continue
        pts = [loc(i, p) for i, p in conns if i != "PIN"]
        pts = [p for p in pts if p]
        if len(pts) < 2:
            continue
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        hpwl = (max(xs) - min(xs)) + (max(ys) - min(ys))
        for i, p in hit:
            s = pad_inst[i]
            rows.append({"pad": s["inst"], "port": s["port"], "side": s["side"], "group": s["group"], "pin": p, "net": net,
                         "fanout": len(conns) - 1, "hpwl_um": round(hpwl, 1)})
    rows.sort(key=lambda r: (-r["hpwl_um"]))
    with open(ROOT / "reports/physical/pad_nets.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    # ------------------------------------------------------------------ SVG
    S = 1000.0 / max(W, H)
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-40 -40 {W * S + 80:.0f} {H * S + 80:.0f}" font-family="sans-serif">',
           '<style>text{font-size:6px} .t{font-size:11px;font-weight:bold}</style>',
           f'<rect x="0" y="0" width="{W * S:.1f}" height="{H * S:.1f}" fill="#fbfbfb" stroke="#333" stroke-width="1"/>',
           f'<rect x="{70 * S:.1f}" y="{70 * S:.1f}" width="{(W - 140) * S:.1f}" height="{(H - 140) * S:.1f}" fill="none" stroke="#bbb" stroke-dasharray="3,2"/>']

    def rect(b, fill, stroke="none", sw=0.3, op=1.0):
        x0, y0, x1, y1 = b
        return (f'<rect x="{x0 * S:.2f}" y="{(H - y1) * S:.2f}" width="{(x1 - x0) * S:.2f}" height="{(y1 - y0) * S:.2f}" '
                f'fill="{fill}" stroke="{stroke}" stroke-width="{sw}" fill-opacity="{op}"/>')
    core = geo["core"]
    out.append(rect(core, "#f4f6f7", "#999", 0.5))
    db = C.bbox(comps["u_die"], lef.macros["sf_io_die_core"])
    out.append(rect(db, "#d5dbdb", "#555", 0.8))
    out.append(f'<text class="t" x="{(db[0] + db[2]) / 2 * S:.0f}" y="{(H - (db[1] + db[3]) / 2) * S:.0f}" text-anchor="middle">'
               f'die core block (P31) -- floorplan reservation {lef.macros["sf_io_die_core"].size[0]:.0f} x {lef.macros["sf_io_die_core"].size[1]:.0f} um</text>')
    for n, c in comps.items():
        m = c["master"]
        if not c["xy"]:
            continue
        b = C.bbox(c, lef.macros[m])
        if m.startswith("sg13g2_Filler"):
            out.append(rect(b, "#eeeeee"))
        elif m == "sg13g2_Corner":
            out.append(rect(b, "#999999"))
        elif m == "bondpad_70x70":
            out.append(rect(b, "#d4ac0d", "#7d6608", 0.3))
        elif m.startswith("sg13g2_") and not m.startswith("sg13g2_IOPad"):
            out.append(rect(b, "#5d6d7e", op=0.6))
    for s in plan["slots"]:
        b = s["bbox"]
        col = SUP_COL[s["net"]] if s["kind"] == "supply" else GROUP_COL.get(s["group"], "#555")
        out.append(rect(b, col, "#333", 0.3))
        cx, cy = (b[0] + b[2]) / 2 * S, (H - (b[1] + b[3]) / 2) * S
        lab = s["net"] if s["kind"] == "supply" else s["port"]
        rot = 90 if s["side"] in "NS" else 0
        out.append(f'<text x="{cx:.1f}" y="{cy:.1f}" text-anchor="middle" dominant-baseline="middle" '
                   f'transform="rotate({rot} {cx:.1f} {cy:.1f})">{lab}</text>')
    out.append(f'<text class="t" x="{W * S / 2:.0f}" y="-14" text-anchor="middle">NORTH -- {REGION["N"]}</text>')
    out.append(f'<text class="t" x="{W * S / 2:.0f}" y="{H * S + 28:.0f}" text-anchor="middle">SOUTH -- {REGION["S"]}</text>')
    out.append(f'<text class="t" x="-14" y="{H * S / 2:.0f}" text-anchor="middle" transform="rotate(-90 -14 {H * S / 2:.0f})">WEST -- {REGION["W"]}</text>')
    out.append(f'<text class="t" x="{W * S + 18:.0f}" y="{H * S / 2:.0f}" text-anchor="middle" transform="rotate(90 {W * S + 18:.0f} {H * S / 2:.0f})">EAST -- {REGION["E"]}</text>')
    out.append(f'<text x="{W * S / 2:.0f}" y="{(H - core[3] + 25) * S:.0f}" text-anchor="middle" style="font-size:9px">shell standard cells (TAP, BSR, host link, management, P35 clock / reset root): north strip</text>')
    out.append("</svg>")
    (ROOT / "reports/physical/floorplan.svg").write_text("\n".join(out))

    # ------------------------------------------------------------------ markdown
    L = ["# Floorplan pin-placement report -- SilicaFlux IOSHELL", "",
         f"Die {W:.0f} x {H:.0f} um, IHP SG13G2 wire-bond pad ring of real `sg13g2_io` cells, placed by OpenROAD "
         f"(`physical/padring.tcl`) from the plan of `scripts/pin_assign.py`; every placement re-checked by "
         f"`scripts/check_physical.py` ([PHYSICAL_CHECKS](PHYSICAL_CHECKS.md)). Picture: [floorplan.svg](floorplan.svg).", "",
         "## 1. Orientation", "", "| Side | Region | Signal pads | Supply pads |", "|---|---|---|---|"]
    for s in I.SIDES:
        L.append(f"| {s} | {REGION[s]} | {sum(1 for x in plan['slots'] if x['side'] == s and x['kind'] == 'signal')} | "
                 f"{sum(1 for x in plan['slots'] if x['side'] == s and x['kind'] == 'supply')} |")
    L += ["", "Evaluation against the brief (section 8):", "",
          "* **Control and low-speed pins near the top / control region** -- clocks, resets, straps, status and RAS are on the "
          "north side; the P35 clock / reset root and the shell logic are placed in the north strip directly inside them.",
          "* **External-memory interface near the memory subsystem** -- the south side is kept free of signal pads for the "
          "DDR / HBM PHY of milestone B (the die's SFMC port is the boundary; P31 recommends the memory slices next to the "
          "vector clusters, so the PHY should face them). Today it carries supplies only.",
          "* **Host interface near its controller region** -- the host-command link is on the east side, which is also where "
          "the PCIe sideband pins are reserved and where a PCIe PHY would sit.",
          "* **Test and debug at accessible perimeter positions** -- JTAG occupies the north end of the west side (first "
          "bond-order positions), away from the high-speed sides; UART / SPI / GPIO follow on the same side.",
          "* **Clock inputs** have an IOVSS pad as neighbour (planning rule, `config/io_inventory.yaml`).", "",
          "## 2. Pads per side (die coordinates, um; lower-left of the 80 x 180 um IO cell)", ""]
    for s in I.SIDES:
        sl = sorted((x for x in plan["slots"] if x["side"] == s), key=lambda x: x["along"])
        L += [f"### {s} ({len(sl)} slots, pitch {sl[0]['pitch']} um)", "",
              "| # | Bond idx | Instance | Cell | Net / port | Kind | x0 | y0 |", "|---|---|---|---|---|---|---|---|"]
        for k, x in enumerate(sl):
            L.append(f"| {k} | {x['bond_index']} | `{x['inst']}` | `{x['cell']}` | `{x['net']}` | {x['kind']} | {x['bbox'][0]:.1f} | {x['bbox'][1]:.1f} |")
        L.append("")
    by_side = {}
    for r in rows:
        by_side.setdefault(r["side"], []).append(r["hpwl_um"])
    L += ["## 3. Pad-net lengths after placement (half-perimeter, um)", "",
          "Nets between each pad's core-side pin and the shell logic, from the placed DEF (`pad_nets.csv`). Indicative only: "
          "pre-route, and the shell logic sits in one north strip because the die core's real outline is unknown.", "",
          "| Side | Nets | Median | Max |", "|---|---|---|---|"]
    for s in I.SIDES:
        v = by_side.get(s, [])
        if v:
            L.append(f"| {s} | {len(v)} | {statistics.median(v):.0f} | {max(v):.0f} |")
    L += ["", "Longest ten:", "", "| Pad | Pin | Net | Fan-out | HPWL (um) |", "|---|---|---|---|---|"]
    for r in rows[:10]:
        L.append(f"| `{r['port']}` ({r['side']}) | {r['pin']} | `{r['net']}` | {r['fanout']} | {r['hpwl_um']} |")
    L += ["", "Reading: north pads reach the shell strip in a few hundred um. East (host link) and west (JTAG, management) "
          "pads cross up to ~2.5 mm to reach logic in the strip. All of them are low-speed or oversampled, so this is "
          "acceptable for milestone A, but it is the first floorplan change once the die core is sized: place the host-link "
          "logic (`u_hlink`, `u_split`) in an east region and the TAP / boundary scan (`u_jtag`) and management peripherals "
          "in a west region (placement fences), keeping each pad-to-logic hop short. TCK is a clock: its pad-to-TAP route "
          "is the one that matters most for JTAG timing.", ""]
    (ROOT / "reports/physical/PIN_PLACEMENT.md").write_text("\n".join(L))
    print(f"report_pins: {len(rows)} pad nets; per side median HPWL " +
          ", ".join(f"{s}:{statistics.median(v):.0f}" for s, v in by_side.items()))


if __name__ == "__main__":
    main()
