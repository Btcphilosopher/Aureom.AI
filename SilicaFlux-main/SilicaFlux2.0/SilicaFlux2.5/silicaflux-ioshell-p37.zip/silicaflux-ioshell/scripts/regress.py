#!/usr/bin/env python3
"""SilicaFlux IOSHELL :: RTL regression.

  * lint: Verilator -Wall on the shell RTL for every legal build (warnings counted in rtl/ only)
  * refusals: every missing-dependency build must stop at elaboration with its message
  * simulation: Verilator builds of tb_io_shell (real P31 die inside), each running its test list;
    one Icarus cross-check build
Writes reports/rtl/regression.md + regression.json and the logs under reports/rtl/sim/.
Usage: regress.py [--only NAME[,NAME]] [--skip-build] [--no-icarus] [--no-firmware]
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
R = ROOT / "reports" / "rtl"
LOGS = R / "sim"
CHK = "third_party/silicaflux-dietop/third_party/silicaflux-datafabric/tb/common/sfb_protocol_checker.sv"

# name: (tech, defines, [(test, plusargs, timeout_s)])
BUILDS = {
    "min": ("sim", ["+define+TB_DIE_CFG=0"],
            [("all", [], 1800), ("reset", [], 600), ("firmware", ["+timeout_ms=900"], 5400)]),
    "min_ihp": ("ihpsim", ["+define+TB_DIE_CFG=0"],
                [("all", [], 1800)]),
    "hpc_nomem": ("sim", ["+define+TB_DIE_CFG=1", "+define+TB_DIE_HPC", "+define+TB_ALLOW_NO_EXTMEM=1"],
                  [("mem_absent", [], 900)]),
    "hpc_memsim": ("sim", ["+define+TB_DIE_CFG=1", "+define+TB_DIE_HPC", "+define+TB_MEM_CTRL=1", "+define+SF_IO_SIM_MODELS"],
                   [("memsim", [], 900), ("all", [], 2400), ("memcalfail", ["+SF_IO_MEMPHY_CALFAIL=7"], 900)]),
}

# missing-dependency builds: (name, top, -G params, defines, tech, extra files, expected message fragment)
REFUSALS = [
    ("PCIe without PHY / controller IP", "silicaflux_io_shell", ["-GPCIE_EN=1"], [], "sim", [], "PCIE-PHY"),
    ("memory controller VENDOR without IP", "silicaflux_io_shell", ["-GMEM_CTRL=2"], [], "sim", [], "MEM-CTRL"),
    ("HPC die without a memory controller", "silicaflux_io_shell", ["-GDIE_CFG=1"], [], "sim", [], "needs an external-memory controller"),
    ("MEM_CTRL = SIM without the simulation models", "silicaflux_io_shell", ["-GMEM_CTRL=1", "-GDIE_CFG=1"], [], "sim", [], "simulation-only models"),
    ("behavioural pads in an implementation build", "silicaflux_io_shell", [], ["+define+SF_IO_ASIC_IMPL"], "sim", [], "SIMULATION ONLY"),
    ("IHP pad with a drive strength the library lacks", "sf_io_pad_out", ["-GDRIVE=8"], [], "ihp", [], "4 / 16 / 30"),
    ("illegal die configuration", "silicaflux_io_shell", ["-GDIE_CFG=2"], [], "sim", [], "DIE_CFG must be 0"),
]
LINTS = [
    ("MIN, behavioural pads", "sim", []),
    ("MIN, IHP pad cells (vendor model)", "ihpsim", []),
    ("HPC + simulated controller / PHY", "sim", ["-GDIE_CFG=1", "-GMEM_CTRL=1", "+define+SF_IO_SIM_MODELS"]),
]


def run(cmd, log, timeout):
    t0 = time.time()
    with open(log, "w") as f:
        try:
            p = subprocess.run(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, timeout=timeout)
            rc = p.returncode
        except subprocess.TimeoutExpired:
            rc = -999
    return rc, time.time() - t0


def lint(rows):
    for name, tech, extra in LINTS:
        sims = ["-f", "rtl/files_sim_models.f"] if any("SF_IO_SIM_MODELS" in e for e in extra) else []
        log = LOGS / f"lint_{tech}_{len(rows)}.log"
        cmd = ["verilator", "--lint-only", "-Wall", "-Wno-fatal", "--timing", "-Wno-TIMESCALEMOD",
               "--top-module", "silicaflux_io_shell"] + extra + ["-f", f"rtl/files_tech_{tech}.f", "-f", "rtl/files_core.f"] + sims
        rc, t = run(cmd, log, 900)
        txt = log.read_text()
        warn = [l for l in txt.splitlines() if l.startswith("%Warning") and re.search(r" (rtl|sim)/", l)]
        err = [l for l in txt.splitlines() if l.startswith("%Error")]
        rows.append({"kind": "lint", "name": name, "ok": rc == 0 and not warn and not err,
                     "detail": f"{len(warn)} warnings in rtl/ + sim/, {len(err)} errors", "time_s": round(t, 1),
                     "log": str(log.relative_to(ROOT))})


def refusals(rows):
    for i, (name, top, gp, defs, tech, extra, frag) in enumerate(REFUSALS):
        log = LOGS / f"refuse_{i}.log"
        # elaboration-time $fatal is warning USERFATAL in Verilator: make it an error here
        cmd = ["verilator", "--lint-only", "-Wno-fatal", "-Werror-USERFATAL", "-Wno-lint", "-Wno-style", "--timing",
               "-Wno-TIMESCALEMOD", "--top-module", top] + gp + defs + ["-f", f"rtl/files_tech_{tech}.f", "-f", "rtl/files_core.f"] + extra
        rc, t = run(cmd, log, 600)
        txt = log.read_text()
        ok = rc != 0 and frag in txt
        rows.append({"kind": "refusal", "name": name, "ok": ok,
                     "detail": f"exit {rc}, message {'found' if frag in txt else 'MISSING'}: '{frag}'", "time_s": round(t, 1),
                     "log": str(log.relative_to(ROOT))})


def build(name, tech, defs):
    out = ROOT / "build" / f"v_{name}"
    out.mkdir(parents=True, exist_ok=True)
    sims = ["-f", "rtl/files_sim_models.f"] if any("SF_IO_SIM_MODELS" in d for d in defs) else []
    cmd = ["verilator", "--binary", "--timing", "-O2", "-j", os.environ.get("JOBS", "4"), "-Wno-fatal", "-Wno-lint",
           "-Wno-style", "-Wno-TIMESCALEMOD", "--top-module", "tb_io_shell", "-Mdir", str(out), "-o", "vtb"] + defs + \
          ["-f", f"rtl/files_tech_{tech}.f", "-f", "rtl/files_core.f"] + sims + [CHK, "+incdir+tb/generated", "tb/tb_io_shell.sv"]
    return run(cmd, LOGS / f"build_{name}.log", 7200)


def parse(log):
    txt = Path(log).read_text(errors="replace")
    m = re.search(r"TB RESULT (PASS|FAIL)(?: TIMEOUT[^\n]*)? checks=(\d+) fails=(\d+)", txt)
    if not m:
        return False, 0, -1, txt[-600:]
    return m.group(1) == "PASS" and int(m.group(3)) == 0, int(m.group(2)), int(m.group(3)), ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    ap.add_argument("--skip-build", action="store_true")
    ap.add_argument("--no-icarus", action="store_true")
    ap.add_argument("--no-firmware", action="store_true")
    ap.add_argument("--no-static", action="store_true")
    a = ap.parse_args()
    LOGS.mkdir(parents=True, exist_ok=True)
    rows = []
    if not a.no_static:
        lint(rows)
        refusals(rows)
    only = set(a.only.split(",")) if a.only else set(BUILDS)
    for name, (tech, defs, tests) in BUILDS.items():
        if name not in only:
            continue
        if not a.skip_build:
            rc, t = build(name, tech, defs)
            rows.append({"kind": "build", "name": f"verilator {name} ({tech})", "ok": rc == 0, "detail": f"exit {rc}",
                         "time_s": round(t, 1), "log": f"reports/rtl/sim/build_{name}.log"})
            if rc != 0:
                continue
        for test, plus, tmo in tests:
            if test == "firmware" and a.no_firmware:
                continue
            log = LOGS / f"{name}_{test}.log"
            rc, t = run([str(ROOT / "build" / f"v_{name}" / "vtb"), f"+TEST={test}"] + plus, log, tmo)
            ok, nchk, nfail, tail = parse(log)
            rows.append({"kind": "sim", "name": f"{name} / {test}", "ok": ok and rc == 0,
                         "detail": f"{nchk} checks, {nfail} fails" + (f" (exit {rc})" if rc else "") + (f" {tail[-200:]!r}" if tail else ""),
                         "time_s": round(t, 1), "log": str(log.relative_to(ROOT))})
            print(f"[{'PASS' if rows[-1]['ok'] else 'FAIL'}] {rows[-1]['name']}: {rows[-1]['detail']} ({t:.0f} s)", flush=True)
    if not a.no_icarus and ("icarus" in only or not a.only):
        out = ROOT / "build" / "icarus"
        out.mkdir(parents=True, exist_ok=True)
        cmd = ["iverilog", "-g2012", "-DTB_DIE_CFG=0", "-s", "tb_io_shell", "-o", str(out / "tb.vvp"), "-I", "rtl", "-I", "rtl/generated",
               "-I", "tb/generated", "-c", "build/icarus/files.f"]
        files = []
        for f in ("rtl/files_tech_sim.f", "rtl/files_core.f"):
            for l in (ROOT / f).read_text().splitlines():
                l = l.strip()
                if l and not l.startswith("//"):
                    files.append(l.replace("+incdir+", "+incdir+"))
        (out / "files.f").write_text("\n".join(files + [CHK, "tb/tb_io_shell.sv"]) + "\n")
        rc, t = run(cmd, LOGS / "build_icarus.log", 3600)
        rows.append({"kind": "build", "name": "icarus min (sim)", "ok": rc == 0, "detail": f"exit {rc}", "time_s": round(t, 1),
                     "log": "reports/rtl/sim/build_icarus.log"})
        if rc == 0:
            for test in ("reset", "hostlink", "jtag"):
                log = LOGS / f"icarus_{test}.log"
                rc2, t2 = run(["vvp", "-n", str(out / "tb.vvp"), f"+TEST={test}"], log, 7200)
                ok, nchk, nfail, tail = parse(log)
                rows.append({"kind": "sim", "name": f"icarus min / {test}", "ok": ok and rc2 == 0,
                             "detail": f"{nchk} checks, {nfail} fails" + (f" {tail[-200:]!r}" if tail else ""),
                             "time_s": round(t2, 1), "log": str(log.relative_to(ROOT))})
                print(f"[{'PASS' if rows[-1]['ok'] else 'FAIL'}] {rows[-1]['name']}: {rows[-1]['detail']} ({t2:.0f} s)", flush=True)
    prev = []
    jp = R / "regression.json"
    if a.only and jp.exists():
        names = {r["name"] for r in rows}
        prev = [r for r in json.loads(jp.read_text()) if r["name"] not in names]
    allrows = prev + rows
    jp.write_text(json.dumps(allrows, indent=1))
    tools = {t: subprocess.run([t, v], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True).stdout.strip().splitlines()[0]
             for t, v in (("verilator", "--version"), ("iverilog", "-V"))}
    L = ["# RTL regression -- SilicaFlux IOSHELL", "",
         f"Tools: {tools['verilator']}; {tools['iverilog']}. The DUT of every simulation is the whole chip "
         "(`silicaflux_io_shell` with the real P31 die inside); the testbench drives pads only.", "",
         "| Kind | Item | Result | Detail | Time (s) | Log |", "|---|---|---|---|---|---|"]
    for r in allrows:
        L.append(f"| {r['kind']} | {r['name']} | {'PASS' if r['ok'] else '**FAIL**'} | {r['detail']} | {r['time_s']} | `{r['log']}` |")
    sims = [r for r in allrows if r["kind"] == "sim"]
    nchk = sum(int(re.match(r"(\d+) checks", r["detail"]).group(1)) for r in sims if re.match(r"\d+ checks", r["detail"]))
    L += ["", f"**{sum(r['ok'] for r in allrows)} / {len(allrows)} items pass**; simulations: "
          f"{sum(r['ok'] for r in sims)} / {len(sims)} runs, {nchk} self-checks.", ""]
    (R / "regression.md").write_text("\n".join(L))
    print(f"regress: {sum(r['ok'] for r in allrows)} / {len(allrows)} pass")
    sys.exit(0 if all(r["ok"] for r in allrows) else 1)


if __name__ == "__main__":
    main()
