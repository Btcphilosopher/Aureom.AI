#!/usr/bin/env python3
"""SilicaFlux IOSHELL :: mutation testing of the new RTL.

Each mutant is a deliberate defect in the shell's own RTL.  All mutants of a
configuration are compiled into ONE build: every mutation site in a copy of
rtl/ (build/mut/rtl) becomes  ((sf_io_mut_pkg::sel == K) ? (MUTANT) : (ORIGINAL))
and the testbench sets sel from +MUT=K.  sel = 0 (baseline) must PASS; every
mutant must make its test FAIL (or time out).  The source tree is never touched.
Output: reports/rtl/mutation.md + mutation.json
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
B = ROOT / "build" / "mut"
R = ROOT / "reports" / "rtl"
CHK = "third_party/silicaflux-dietop/third_party/silicaflux-datafabric/tb/common/sfb_protocol_checker.sv"

# (id, file, original text (must occur once), mutant expression or None for a full replacement,
#  description, build, test)
M = [
    (1, "host/sf_io_spi_host.sv", "(rise || fall) && seen_edge && (32'(half_cnt) + 1 < MIN_HALF)", "1'b0",
     "host link: SCK speed check removed", "min", "all"),
    (2, "host/sf_io_spi_host.sv", "assign miso_oe_o = active;", ("assign miso_oe_o = ", "active", "1'b1", ";"),
     "host link: MISO driven while deselected", "min", "all"),
    (3, "host/sf_io_spi_host.sv", "else if (busy_q) begin phase <= P_RESP; resp_code <= HL_ST_BUSY_ERR; err_frame[E_BUSY] <= 1'b1; end\n              else begin phase <= P_POLL; launch <= 1'b1; launch_write <= 1'b0; end",
     ("else if (", "busy_q", "1'b0", ") begin phase <= P_RESP; resp_code <= HL_ST_BUSY_ERR; err_frame[E_BUSY] <= 1'b1; end\n              else begin phase <= P_POLL; launch <= 1'b1; launch_write <= 1'b0; end"),
     "host link: READ launched while a transaction is outstanding", "min", "all"),
    (4, "host/sf_io_spi_host.sv", "if (rx_byte == HL_RESET_KEY) begin", ("if (", "rx_byte == HL_RESET_KEY", "1'b1", ") begin"),
     "host link: RESET accepted without the key", "min", "all"),
    (5, "host/sf_io_spi_host.sv", "(phase == P_ADDR) || (phase == P_STRB) || (phase == P_DATA) || (phase == P_KEY)", "1'b0",
     "host link: truncated argument phase not flagged", "min", "all"),
    (6, "host/sf_io_host_split.sv", "die_rst_s && (die_platform_ready_i || die_force_i)", "die_rst_s",
     "split: die accesses not gated by PLATFORM_READY", "min", "all"),
    (7, "host/sf_io_host_split.sv", "if (!die_rst_s) begin                              // reset fence",
     ("if (", "!die_rst_s", "1'b0", ") begin                              // reset fence"),
     "split: reset fence removed", "min", "all"),
    (8, "mgmt/sf_io_mgmt.sv", "(s_req_addr[1:0] == 2'b00) && (!s_req_write || (s_req_wstrb == 4'hF))", "(s_req_addr[1:0] == 2'b00)",
     "management: partial-strobe writes accepted", "min", "all"),
    (9, "mgmt/sf_io_mgmt.sv", "ctrl_q[1] && |(irq_lvl & irq_en_q[9:0])", "ctrl_q[1] && |irq_lvl",
     "management: IRQ_ENABLE mask ignored", "min", "all"),
    (10, "mgmt/sf_io_mgmt.sv", "diag_valid_i && ctrl_q[0]", "diag_valid_i",
     "management: console forwarded although CONSOLE_EN = 0", "min", "all"),
    (11, "mgmt/sf_io_mgmt.sv", "R_ID:          begin sh_rdata = R_ID_RST; sh_err = s_req_write; end",
     ("R_ID:          begin sh_rdata = R_ID_RST; sh_err = ", "s_req_write", "1'b0", "; end"),
     "management: write to a read-only register accepted", "min", "all"),
    (12, "jtag/sf_io_jtag.sv", "(ir == TC_IR_EXTEST) || (ir == TC_IR_CLAMP)", "(ir == TC_IR_EXTEST)",
     "JTAG: CLAMP does not hold the pads", "min", "all"),
    (13, "jtag/sf_io_jtag.sv", "wire highz    = (ir == TC_IR_HIGHZ);", ("wire highz    = ", "(ir == TC_IR_HIGHZ)", "1'b0", ";"),
     "JTAG: HIGHZ ignored", "min", "all"),
    (14, "silicaflux_io_shell.sv", "assign bsr_in[BSRI_HOST_SCK]         = host_sck_p;",
     ("assign bsr_in[BSRI_HOST_SCK]         = ", "host_sck_p", "host_mosi_p", ";"),
     "top: boundary-scan input cells of HOST_SCK / HOST_MOSI crossed", "min", "all"),
    (15, "silicaflux_io_shell.sv", "assign f_oe[BSRO_HOST_IRQ_N]     = host_irq;",
     ("assign f_oe[BSRO_HOST_IRQ_N]     = ", "host_irq", "1'b1", ";"),
     "top: HOST_IRQ_N driven instead of open drain", "min", "all"),
    (16, "silicaflux_io_shell.sv", "wire tap_trst_n = trst_n && por_n;", ("wire tap_trst_n = ", "trst_n && por_n", "trst_n", ";"),
     "top: TAP not reset by POR", "min", "all"),
    (17, "pads/sf_io_pads.sv", "if (!por_ni) test_o <= p2c;", ("if (", "!por_ni", "1'b1", ") test_o <= p2c;"),
     "pads: TEST_MODE strap latch transparent in mission mode", "min", "all"),
    (18, "host/sf_io_spi_host.sv", "end else if (m_req_valid && m_req_ready) begin", ("end else if (m_req_valid && ", "m_req_ready", "1'b1", ") begin"),
     "host link: SFB2 request withdrawn before acceptance", "min", "all"),
    (19, "pads/sf_io_pads.sv", "sf_io_cell_tri #(.DRIVE(DRIVE)) u_cell (.pad(pad), .c2p(c2p_i), .c2p_en(c2p_en_i));\n  end else begin : g_pp",
     ("sf_io_cell_tri #(.DRIVE(DRIVE)) u_cell (.pad(pad), .c2p(c2p_i), .c2p_en(", "c2p_en_i", "1'b1", "));\n  end else begin : g_pp"),
     "pads: output wrapper ignores its enable (no HIGHZ)", "min", "all"),
    (20, "mgmt/sf_io_mgmt.sv", "wire crt_off_ok   = (off[11:8] == 4'd0);", ("wire crt_off_ok   = ", "(off[11:8] == 4'd0)", "1'b1", ";"),
     "management: CRT page offsets beyond 0xFF aliased", "min", "all"),
    (21, "mem/sf_io_mem_boundary.sv", "    assign mc_init_done_o = 1'b0;", ("    assign mc_init_done_o = ", "1'b0", "1'b1", ";"),
     "memory slot NONE: controller reported initialised", "hpc_nomem", "mem_absent"),
    (22, "mem/sf_io_mem_boundary.sv", "assign mc_init_done_o = mc_init_raw && phy_status_o.cal_done;",
     ("assign mc_init_done_o = ", "mc_init_raw && phy_status_o.cal_done", "mc_init_raw", ";"),
     "memory slot SIM: controller ready without PHY calibration", "hpc_memsim", "memcalfail"),
]
BUILDS = {"min": ["+define+TB_DIE_CFG=0"],
          "hpc_nomem": ["+define+TB_DIE_CFG=1", "+define+TB_DIE_HPC", "+define+TB_ALLOW_NO_EXTMEM=1"],
          "hpc_memsim": ["+define+TB_DIE_CFG=1", "+define+TB_DIE_HPC", "+define+TB_MEM_CTRL=1", "+define+SF_IO_SIM_MODELS"]}
PLUS = {"memcalfail": ["+SF_IO_MEMPHY_CALFAIL=7"]}


def mutate_tree():
    if B.exists():
        shutil.rmtree(B)
    shutil.copytree(ROOT / "rtl", B / "rtl")
    (B / "rtl" / "sf_io_mut_pkg.sv").write_text("// mutation selector (build/mut only)\npackage sf_io_mut_pkg;\n  int sel = 0;\nendpackage\n")
    for k, f, orig, mut, desc, build, test in M:
        p = B / "rtl" / f
        t = p.read_text()
        if t.count(orig) != 1:
            sys.exit(f"mutate: site of mutant {k} found {t.count(orig)} times in {f}")
        if isinstance(mut, tuple):
            pre, o, m, post = mut
            new = f"{pre}((sf_io_mut_pkg::sel == {k}) ? ({m}) : ({o})){post}"
        else:
            new = f"((sf_io_mut_pkg::sel == {k}) ? ({mut}) : ({orig}))"
        p.write_text(t.replace(orig, new, 1))
    files = []
    for fl in ("rtl/files_tech_sim.f", "rtl/files_core.f"):
        for l in (ROOT / fl).read_text().splitlines():
            l = l.strip()
            if not l or l.startswith("//"):
                continue
            if l.startswith("+incdir+rtl"):
                l = "+incdir+" + str(B / l[len("+incdir+"):])
            elif l.startswith("rtl/"):
                l = str(B / l)
            files.append(l)
    (B / "files.f").write_text("\n".join([str(B / "rtl/sf_io_mut_pkg.sv")] + files) + "\n")


def build(name, defs):
    out = B / f"v_{name}"
    sims = ["-f", "rtl/files_sim_models.f"] if any("SF_IO_SIM_MODELS" in d for d in defs) else []
    cmd = ["verilator", "--binary", "--timing", "-O2", "-j", os.environ.get("JOBS", "4"), "-Wno-fatal", "-Wno-lint", "-Wno-style",
           "-Wno-TIMESCALEMOD", "--top-module", "tb_io_shell", "-Mdir", str(out), "-o", "vtb", "+define+SF_IO_MUTATION"] + defs + \
          ["-f", str(B / "files.f")] + sims + [CHK, "+incdir+tb/generated", "tb/tb_io_shell.sv"]
    with open(B / f"build_{name}.log", "w") as f:
        return subprocess.run(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT).returncode


def run(name, test, k):
    log = B / f"{name}_{test}_m{k}.log"
    t0 = time.time()
    with open(log, "w") as f:
        try:
            subprocess.run([str(B / f"v_{name}" / "vtb"), f"+TEST={test}", f"+MUT={k}"] + PLUS.get(test, []),
                           cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, timeout=900)
        except subprocess.TimeoutExpired:
            pass
    res, first = parse_log(log)
    return res, first, round(time.time() - t0, 1)


def parse_log(log):
    """Result of one run and the first evidence: a failing self-check, or a protocol-checker assertion."""
    txt = log.read_text(errors="replace")
    m = re.search(r"TB RESULT (PASS|FAIL)[^\n]*checks=(\d+) fails=(\d+)", txt)
    first = re.search(r"FAIL \[[^\]]*\] [^\n]*|Assertion failed in [^\n]*", txt)
    return (m.group(1) if m else "NO-RESULT (stopped)"), (first.group(0)[:150] if first else "")


def main():
    if "--report-only" in sys.argv:                 # re-read the logs of the last run, rewrite the report
        rows = json.loads((R / "mutation.json").read_text())
        for r in rows:
            name, test = (r["test"].split(" / ") if r["id"] else re.search(r"\((\S+) / (\S+)\)", r["desc"]).groups())
            res, first = parse_log(B / f"{name}_{test}_m{r['id']}.log")
            r["result"] = res
            r["ok"] = (res != "PASS") if r["id"] else (res == "PASS")
            if r["id"]:
                r["killed_by"] = first
        report(rows)
        return
    mutate_tree()
    rows = []
    for name, defs in BUILDS.items():
        rc = build(name, defs)
        if rc:
            sys.exit(f"mutate: build {name} failed (see build/mut/build_{name}.log)")
        tests = sorted({m[6] for m in M if m[5] == name})
        for test in tests:
            res, first, t = run(name, test, 0)
            rows.append({"id": 0, "desc": f"baseline ({name} / {test})", "result": res, "ok": res == "PASS",
                         "killed_by": "", "time_s": t})
            print(f"baseline {name}/{test}: {res}", flush=True)
        for k, f, orig, mut, desc, b, test in M:
            if b != name:
                continue
            res, first, t = run(name, test, k)
            killed = res != "PASS"
            rows.append({"id": k, "desc": desc, "file": f, "test": f"{name} / {test}", "result": res, "ok": killed,
                         "killed_by": first, "time_s": t})
            print(f"M{k:02d} {'KILLED' if killed else 'SURVIVED'}: {desc} -- {first}", flush=True)
    report(rows)


def report(rows):
    (R / "mutation.json").write_text(json.dumps(rows, indent=1))
    muts = [r for r in rows if r["id"]]
    L = ["# Mutation testing -- SilicaFlux IOSHELL", "",
         "Each mutant is a deliberate defect in the shell's new RTL, compiled behind a runtime selector in a copy of "
         "`rtl/` (`scripts/mutate.py`); the source tree is untouched. Baselines (selector 0) must pass; every mutant must "
         "be detected.", "", "| # | Mutant | File | Test | Result | First failing check |", "|---|---|---|---|---|---|"]
    for r in rows:
        if r["id"] == 0:
            L.append(f"| - | {r['desc']} | | | {r['result']} | |")
    for r in muts:
        L.append(f"| M{r['id']:02d} | {r['desc']} | `rtl/{r['file']}` | {r['test']} | {'KILLED' if r['ok'] else '**SURVIVED**'} | {r['killed_by'].replace('|', '/')} |")
    L.append(f"\n**{sum(r['ok'] for r in muts)} / {len(muts)} mutants killed; baselines "
             f"{'all pass' if all(r['ok'] for r in rows if r['id'] == 0) else 'NOT all pass'}.**\n")
    (R / "mutation.md").write_text("\n".join(L))
    print(f"mutation: {sum(r['ok'] for r in muts)} / {len(muts)} killed")
    sys.exit(0 if all(r["ok"] for r in rows) else 1)


if __name__ == "__main__":
    main()
