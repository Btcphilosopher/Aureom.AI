#!/usr/bin/env python3
"""SilicaFlux IOSHELL :: deliverable archive (MANIFEST.sha256 + zip; build/ excluded)."""
from __future__ import annotations

import hashlib
import shutil
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
NAME = "silicaflux-ioshell"
# physical results kept in the archive (build/ itself is excluded): copied to physical/out/
PHYS_OUT = {
    "build/phys/or/silicaflux_io_shell.def": "silicaflux_io_shell.def",      # placed pad ring + die block + cells
    "build/phys/silicaflux_io_shell.v": "silicaflux_io_shell.v",             # physical netlist (IHP cells)
    "build/phys/sf_io_die_core_abstract.lef": "sf_io_die_core_abstract.lef",  # die-block reservation
}


def files():
    for p in sorted(ROOT.rglob("*")):
        rel = p.relative_to(ROOT)
        if p.is_dir() or rel.parts[0] == "build" or p.name == "MANIFEST.sha256" or "__pycache__" in rel.parts:
            continue
        yield p, rel


def main():
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT.parent / f"{NAME}-p37.zip"
    (ROOT / "physical" / "out").mkdir(exist_ok=True)
    for src, dst in PHYS_OUT.items():
        if not (ROOT / src).exists():
            sys.exit(f"package: {src} missing -- run 'make physical' first")
        shutil.copyfile(ROOT / src, ROOT / "physical" / "out" / dst)
    man = [f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {rel.as_posix()}" for p, rel in files()]
    (ROOT / "MANIFEST.sha256").write_text("\n".join(man) + "\n")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p, rel in files():
            z.write(p, f"{NAME}/{rel.as_posix()}")
        z.write(ROOT / "MANIFEST.sha256", f"{NAME}/MANIFEST.sha256")
    print(f"{out}: {len(man) + 1} files, {out.stat().st_size / 1e6:.1f} MB")


if __name__ == "__main__":
    main()
