"""SilicaFlux IOSHELL :: minimal LEF reader (macros, sites, pins, layers).

Only what the generators and checkers need: MACRO CLASS / SIZE / SITE,
PIN DIRECTION / USE and the layer + rectangles of each PORT, SITE sizes and
the tech-LEF routing layers with their DIRECTION.  Values are returned as
read; nothing is defaulted.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Pin:
    name: str
    direction: str | None = None
    use: str | None = None
    shapes: list = field(default_factory=list)   # (layer, x0, y0, x1, y1)

    @property
    def layers(self):
        return sorted({s[0] for s in self.shapes})


@dataclass
class Macro:
    name: str
    cls: str | None = None
    size: tuple | None = None
    site: str | None = None
    symmetry: str | None = None
    pins: dict = field(default_factory=dict)


@dataclass
class Lef:
    macros: dict = field(default_factory=dict)
    sites: dict = field(default_factory=dict)
    layers: dict = field(default_factory=dict)    # name -> {type, direction}
    files: list = field(default_factory=list)


def _tokens(text):
    text = re.sub(r"#[^\n]*", "", text)
    return text.replace(";", " ; ").split()


def read_lef(paths, lef: Lef | None = None) -> Lef:
    lef = lef or Lef()
    for p in paths:
        p = Path(p)
        lef.files.append(str(p))
        toks = _tokens(p.read_text())
        i, n = 0, len(toks)
        while i < n:
            t = toks[i]
            if t == "PROPERTYDEFINITIONS":
                while not (toks[i] == "END" and toks[i + 1] == "PROPERTYDEFINITIONS"):
                    i += 1
                i += 2
            elif t == "MACRO":
                i = _macro(toks, i + 1, lef)
            elif t == "SITE":
                name = toks[i + 1]
                j = i + 2
                site = {}
                while not (toks[j] == "END" and toks[j + 1] == name):
                    if toks[j] == "SIZE":
                        site["size"] = (float(toks[j + 1]), float(toks[j + 3]))
                    if toks[j] == "CLASS":
                        site["class"] = toks[j + 1]
                    j += 1
                lef.sites[name] = site
                i = j + 2
            elif t == "LAYER" and i + 1 < n:
                name = toks[i + 1]
                j = i + 2
                layer = {}
                while j < n and not (toks[j] == "END" and toks[j + 1] == name):
                    if toks[j] == "TYPE":
                        layer["type"] = toks[j + 1]
                    if toks[j] == "DIRECTION":
                        layer["direction"] = toks[j + 1]
                    j += 1
                lef.layers.setdefault(name, layer)
                i = j + 2
            else:
                i += 1
    return lef


def _macro(toks, i, lef):
    name = toks[i]
    m = Macro(name)
    j = i + 1
    while not (toks[j] == "END" and toks[j + 1] == name):
        t = toks[j]
        if t == "CLASS":
            k = j + 1
            parts = []
            while toks[k] != ";":
                parts.append(toks[k]); k += 1
            m.cls = " ".join(parts)
            j = k
        elif t == "SIZE":
            m.size = (float(toks[j + 1]), float(toks[j + 3]))
            j += 4
        elif t == "SITE":
            m.site = toks[j + 1]; j += 2
        elif t == "SYMMETRY":
            k = j + 1
            parts = []
            while toks[k] != ";":
                parts.append(toks[k]); k += 1
            m.symmetry = " ".join(parts); j = k
        elif t == "PIN":
            j = _pin(toks, j + 1, m)
        elif t == "OBS":
            while toks[j] != "END":
                j += 1
        j += 1
    lef.macros[name] = m
    return j + 2


def _pin(toks, j, m):
    pname = toks[j]
    pin = Pin(pname)
    j += 1
    layer = None
    while not (toks[j] == "END" and toks[j + 1] == pname):
        t = toks[j]
        if t == "DIRECTION":
            pin.direction = toks[j + 1]
        elif t == "USE":
            pin.use = toks[j + 1]
        elif t == "LAYER":
            layer = toks[j + 1]
        elif t == "RECT":
            vals = [float(x) for x in toks[j + 1:j + 5]]
            pin.shapes.append((layer, *vals))
        j += 1
    m.pins[pname] = pin
    return j + 1
