"""SilicaFlux IOSHELL :: inventory loader, expander and validator.

load() reads config/io_inventory.yaml, expands bus pads to single-bit pads,
resolves every pad's vendor cell through technology.cell_map, derives the
boundary-scan order (tc_bsr contract: inputs, then outputs, then bidirs, in
inventory order, LSB first) and runs the validation rules V1..V12.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
from sfio_lef import read_lef  # noqa: E402

SIDES = ("N", "E", "S", "W")
DIR_WRAP = {"in": {"in", "clk", "rst", "test"}, "out": {"out"}, "tri": {"tri"}, "od": {"od"}, "bidir": {"bidir"}}
DIR_BSR = {"in": {"in", "none"}, "out": {"out", "none"}, "tri": {"out", "none"}, "od": {"out", "none"}, "bidir": {"bidir", "none"}}
DIR_LEFPIN = {"in": "INPUT", "out": "OUTPUT", "tri": "OUTPUT", "od": "OUTPUT", "bidir": "INOUT"}
DIR_CLASS = {"in": "PAD INPUT", "out": "PAD OUTPUT", "tri": "PAD OUTPUT", "od": "PAD OUTPUT", "bidir": "PAD INOUT"}
DEP_STATUS = {"AVAILABLE", "SIM-ONLY", "ABSENT", "BLOCKED", "ASSUMED"}


class InventoryError(Exception):
    pass


def bits(p):
    w = int(p.get("width", 1))
    if w <= 1 and "width" not in p:
        return [(p["name"], None)]
    return [(f"{p['name']}_{i}", i) for i in range(w)]


def load(path=None):
    path = Path(path or ROOT / "config" / "io_inventory.yaml")
    inv = yaml.safe_load(path.read_text())
    tech = inv["technology"]
    lef = read_lef([ROOT / tech["tech_lef"], ROOT / tech["io_lef"], ROOT / tech["bondpad_lef"]])
    inv["_lef"] = lef
    pads = []
    for p in inv["pads"]:
        cm = tech["cell_map"][p["wrap"]]
        cell = cm if isinstance(cm, str) else cm.get(int(p.get("drive", 4)))
        for bname, idx in bits(p):
            pads.append({**p, "bit": idx, "bitname": bname, "cell": cell,
                         "port": p["name"] if idx is None else f"{p['name']}[{idx}]",
                         "inst": f"pad_{bname}"})
    inv["_pads"] = pads
    inv["_bsr"] = bsr_order(pads)
    return inv


def bsr_order(pads):
    ins = [p for p in pads if p["bsr"] == "in"]
    outs = [p for p in pads if p["bsr"] == "out"]
    bid = [p for p in pads if p["bsr"] == "bidir"]
    cells = []
    for i, p in enumerate(ins):
        cells.append({"cell": i, "pad": p, "kind": "input", "type": "BC_4", "cls": "in", "idx": i})
    ni = len(ins)
    for o, p in enumerate(outs):
        cells.append({"cell": ni + 2 * o, "pad": p, "kind": "output3", "type": "BC_1", "cls": "out", "idx": o, "role": "data", "ctl": ni + 2 * o + 1})
        cells.append({"cell": ni + 2 * o + 1, "pad": p, "kind": "control", "type": "BC_1", "cls": "out", "idx": o, "role": "control"})
    no = len(outs)
    for b, p in enumerate(bid):
        base = ni + 2 * no + 3 * b
        cells.append({"cell": base, "pad": p, "kind": "input", "type": "BC_4", "cls": "bidir", "idx": b, "role": "input"})
        cells.append({"cell": base + 1, "pad": p, "kind": "bidir", "type": "BC_1", "cls": "bidir", "idx": b, "role": "data", "ctl": base + 2})
        cells.append({"cell": base + 2, "pad": p, "kind": "control", "type": "BC_1", "cls": "bidir", "idx": b, "role": "control"})
    return {"ins": ins, "outs": outs, "bidirs": bid, "cells": cells,
            "num_in": len(ins), "num_out": len(outs), "num_bidir": len(bid),
            "len": len(ins) + 2 * len(outs) + 3 * len(bid)}


def die_top_ports(path):
    """Port names of silicaflux_die_top (vendored P31 source)."""
    t = Path(path).read_text()
    t = re.sub(r"//[^\n]*", "", t)
    m = re.search(r"module\s+silicaflux_die_top\b.*?\)\s*\(\s*(.*?)\);", t, re.S)
    body = m.group(1)
    names = re.findall(r"(?:input|output|inout)\s+(?:wire\s+)?(?:logic\s+)?(?:\[[^\]]*\]\s*)?(\w+)", body)
    return names


def validate(inv):
    """Return a list of (rule, ok, message)."""
    res = []
    lef = inv["_lef"]
    tech = inv["technology"]
    pads = inv["_pads"]

    def chk(rule, ok, msg):
        res.append((rule, bool(ok), msg))

    names = [p["name"] for p in inv["pads"]] + [p["name"] for p in inv.get("reserved", [])] + [p["name"] for p in inv.get("phy_owned", [])]
    dup = sorted({n for n in names if names.count(n) > 1})
    chk("V1", not dup, f"signal names unique ({len(names)} names){'; duplicates: ' + ', '.join(dup) if dup else ''}")

    bad = [p["name"] for p in inv["pads"] if p["wrap"] not in DIR_WRAP[p["dir"]] or p["bsr"] not in DIR_BSR[p["dir"]]]
    chk("V2", not bad, f"dir / wrapper / BSR class consistent for {len(inv['pads'])} pad entries{'; bad: ' + ', '.join(bad) if bad else ''}")

    bad = []
    for p in pads:
        m = lef.macros.get(p["cell"])
        if m is None:
            bad.append(f"{p['bitname']}: cell {p['cell']} not in LEF"); continue
        if m.cls != DIR_CLASS[p["dir"]]:
            bad.append(f"{p['bitname']}: {p['cell']} CLASS {m.cls} != {DIR_CLASS[p['dir']]}")
        if m.pins["pad"].direction != DIR_LEFPIN[p["dir"]]:
            bad.append(f"{p['bitname']}: pad pin {m.pins['pad'].direction} != {DIR_LEFPIN[p['dir']]}")
        need = {"in": {"p2c"}, "out": {"c2p", "c2p_en"}, "tri": {"c2p", "c2p_en"}, "od": {"c2p", "c2p_en"}, "bidir": {"c2p", "c2p_en", "p2c"}}[p["dir"]]
        if not need <= set(m.pins):
            bad.append(f"{p['bitname']}: {p['cell']} lacks {need - set(m.pins)}")
    chk("V3", not bad, f"{len(pads)} signal pads map to LEF cells with matching CLASS, pad-pin direction and core pins{'; ' + '; '.join(bad) if bad else ''}")

    bad = []
    for k, c in tech["supply_cells"].items():
        m = lef.macros.get(c)
        if not m or m.cls != "PAD POWER":
            bad.append(c)
    for c in [tech["corner_cell"], *tech["filler_cells"]]:
        m = lef.macros.get(c)
        if not m or m.cls != "PAD SPACER":
            bad.append(c)
    chk("V4", not bad, f"supply ({len(tech['supply_cells'])}), corner and {len(tech['filler_cells'])} filler cells present with PAD POWER / PAD SPACER class{'; bad: ' + ', '.join(bad) if bad else ''}")

    bad = [n["name"] for n in inv["pads"] + inv.get("reserved", []) + inv.get("phy_owned", []) if n.get("side") not in SIDES]
    chk("V5", not bad, f"every pad / reserved / PHY-owned entry has a side in {SIDES}{'; bad: ' + ', '.join(bad) if bad else ''}")

    die_src = ROOT / "third_party/silicaflux-dietop/rtl/top/silicaflux_die_top.sv"
    dports = die_top_ports(die_src)
    mapped = set(inv["die_ports"])
    missing = [p for p in dports if p not in mapped]
    extra = sorted(mapped - set(dports))
    chk("V6", not missing and not extra,
        f"die-port traceability: {len(dports)} ports of silicaflux_die_top, {len(mapped)} mapped"
        f"{'; unmapped: ' + ', '.join(missing) if missing else ''}{'; not in die: ' + ', '.join(extra) if extra else ''}")

    deps = inv["dependencies"]
    ids = [d["id"] for d in deps]
    hw = [d["hw_field"] for d in deps if d.get("hw_field")]
    bad = [d["id"] for d in deps if d["status"] not in DEP_STATUS]
    refd = {x.get("dep") for x in inv.get("reserved", []) + inv.get("phy_owned", [])} - {None}
    chk("V7", len(set(ids)) == len(ids) and len(set(hw)) == len(hw) and not bad and refd <= set(ids),
        f"{len(deps)} dependency entries: unique IDs / hw fields, valid status, every reserved / PHY-owned dep ({len(refd)}) registered")

    regs = inv["shell_registers"]
    offs = [r["offset"] for r in regs]
    chk("V8", len(set(offs)) == len(offs) and all(o % 4 == 0 and o < 0x1000 for o in offs),
        f"{len(regs)} SHELL registers: unique, word aligned, inside the 4 KiB page")

    jt = {p["name"]: p for p in inv["pads"] if p["group"] == "jtag"}
    chk("V9", {"TCK", "TMS", "TDI", "TDO"} <= set(jt) and all(p["bsr"] == "none" for p in jt.values()),
        "JTAG TCK/TMS/TDI/TDO present and excluded from the boundary-scan register")

    bad = [p["name"] for p in inv["pads"] if not all(p.get(k) for k in ("domain", "eclass", "function", "group"))]
    chk("V10", not bad, f"every pad has clock domain, electrical class, function and group{'; missing: ' + ', '.join(bad) if bad else ''}")

    b = inv["_bsr"]
    chk("V11", b["len"] == b["num_in"] + 2 * b["num_out"] + 3 * b["num_bidir"] and len(b["cells"]) == b["len"],
        f"BSR: {b['num_in']} inputs, {b['num_out']} outputs, {b['num_bidir']} bidirs = {b['len']} cells (tc_bsr contract)")

    outs_reset = [p["name"] for p in inv["pads"] if p["dir"] in ("out", "tri", "od", "bidir") and "reset_value" not in p]
    chk("V12", not outs_reset, f"every driven pad declares its reset state{'; missing: ' + ', '.join(outs_reset) if outs_reset else ''}")
    return res
