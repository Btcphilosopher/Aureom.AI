#!/usr/bin/env python3
"""SilicaFlux IOSHELL :: self-test of scripts/check_physical.py (seeded faults).

Each case copies the clean DEF (or netlist), injects ONE fault and requires the
named rule to FAIL; the clean inputs must PASS every rule.  Output:
reports/physical/CHECKER_SELFTEST.md
"""
from __future__ import annotations

import json
import re
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import check_physical as C  # noqa: E402

ROOT = C.ROOT
W = ROOT / "build/phys/selftest"
SRC = ROOT / "build/phys/or/silicaflux_io_shell.def"
NL = ROOT / "build/phys/netlist.json"


def comp_line(t, name):
    m = re.search(rf"\n(\s*-\s+{re.escape(name)}\s+[^;]*;)", t)
    return m.group(1)


def move_pad(t):
    l = comp_line(t, "pad_CLK_REF")
    m = re.search(r"\(\s*(\d+)\s+(\d+)\s*\)", l)
    return t.replace(l, l.replace(m.group(0), f"( {int(m.group(1)) + 1000} {m.group(2)} )"), 1)


def drop_comp(t, pattern):
    m = re.search(rf"\n\s*-\s+(\S*(?:{pattern})\S*)\s+[^;]*;", t)
    return t.replace(m.group(0), "", 1)


def std_on_block(t):
    m = re.search(r"\n(\s*-\s+(\S+)\s+sg13g2_(?!IOPad|Filler|Corner)\S+\s+\+\s+PLACED\s+\(\s*\d+\s+\d+\s*\)\s+(\S+)\s*;)", t)
    l = m.group(1)
    return t.replace(l, re.sub(r"\(\s*\d+\s+\d+\s*\)", "( 1000000 1000000 )", l), 1)


def rename_term(t):
    return t.replace("- TCK + NET TCK", "- TCKX + NET TCK", 1)


def wrong_layer(t):
    i = t.index("- TDI + NET TDI")
    j = t.index(";", i)
    seg = t[i:j].replace("LAYER TopMetal2", "LAYER Metal1", 1)
    return t[:i] + seg + t[j:]


def supply_cut(t):
    return re.sub(r"\(\s*pad_GPIO_3\s+vdd\s*\)", "", t, count=1)


def wrong_orient(t):
    l = comp_line(t, "pad_CLK_REF")
    return t.replace(l, re.sub(r"\)\s+FS\s*;", ") N ;", l), 1)


CASES = [
    ("pad moved by 1 um", "def", move_pad, {"P4"}),
    ("filler removed", "def", lambda t: drop_comp(t, "FILLER|Filler|IO_FILL"), {"P6"}),
    ("bond pad removed", "def", lambda t: drop_comp(t, "IO_BOND|bond"), {"P7"}),
    ("standard cell placed on the core block", "def", std_on_block, {"P5"}),
    ("terminal renamed", "def", rename_term, {"P3"}),
    ("terminal on a wrong layer", "def", wrong_layer, {"P8"}),
    ("pad vdd pin off the VDD rail", "def", supply_cut, {"P10"}),
    ("pad with the wrong orientation", "def", wrong_orient, {"P4"}),
    ("supply pad removed", "def", lambda t: t.replace(comp_line(t, "pad_IOVSS_W0"), "", 1), {"P3", "P10"}),
    ("port direction flipped in the netlist", "netlist", None, {"P1"}),
]


def main():
    W.mkdir(parents=True, exist_ok=True)
    rows = []
    clean = C.main(["--def", str(SRC), "--netlist", str(NL), "--report", "build/phys/selftest/clean", "--quiet"])
    rows.append(("clean inputs", "all PASS", all(r["ok"] for r in clean), ""))
    src = SRC.read_text()
    for i, (name, kind, fn, want) in enumerate(CASES):
        d, n = SRC, NL
        if kind == "def":
            d = W / f"case{i}.def"
            mut = fn(src)
            assert mut != src, name
            d.write_text(mut)
        else:
            nl = json.loads(NL.read_text())
            nl["modules"]["silicaflux_io_shell"]["ports"]["TMS"]["direction"] = "output"
            n = W / f"case{i}.json"
            n.write_text(json.dumps(nl))
        res = C.main(["--def", str(d), "--netlist", str(n), "--report", f"build/phys/selftest/case{i}", "--quiet"])
        failed = {r["rule"] for r in res if not r["ok"]}
        ok = want <= failed
        rows.append((name, ", ".join(sorted(want)), ok, ", ".join(sorted(failed)) or "none"))
    L = ["# Physical checker self-test (seeded faults)", "",
         "Each case injects one fault into a copy of the DEF or netlist; the named rule must fail.", "",
         "| Case | Rule expected to fail | Result | Rules that failed |", "|---|---|---|---|"]
    for name, want, ok, got in rows:
        L.append(f"| {name} | {want} | {'PASS' if ok else '**FAIL**'} | {got} |")
    L.append(f"\n**{sum(r[2] for r in rows)} / {len(rows)} cases behave as required.**\n")
    (ROOT / "reports/physical/CHECKER_SELFTEST.md").write_text("\n".join(L))
    for name, want, ok, got in rows:
        print(f"[{'PASS' if ok else 'FAIL'}] {name}: expected {want}, failed: {got}")
    sys.exit(0 if all(r[2] for r in rows) else 1)


if __name__ == "__main__":
    main()
