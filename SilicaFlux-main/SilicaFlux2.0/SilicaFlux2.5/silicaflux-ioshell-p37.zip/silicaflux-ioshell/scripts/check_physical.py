#!/usr/bin/env python3
"""SilicaFlux IOSHELL :: independent physical checks of the pad ring.

Reads the OpenROAD DEF (build/phys/or/silicaflux_io_shell.def), the vendored LEFs,
the Yosys netlist (build/phys/netlist.json + pad_rename.json), the inventory and
the plan (physical/generated/padring.json) and re-derives every check itself:

  P1  netlist top-level ports == inventory pads (name, bit, direction), nothing extra
  P2  one vendor pad cell per inventory pad bit, right master, pad pin on its port, core pins connected
  P3  DEF component / terminal names == netlist instance / port names
  P4  every pad placed (FIXED/PLACED) at its planned side, offset and row orientation
  P5  no overlap between any two placed instances (ring cells, bond pads, core block, std cells)
  P6  IO-ring continuity: corner + pads + fillers tile every side without gap
  P7  bond pads: one per pad cell, at the planned offset, inside the die, outside the IO cell
  P8  layers / locations: terminals on a routing layer of the tech LEF that the pad pin uses, on
      the pad's outer edge; pad core-side pins face the core; core-block pins on their LEF layers
  P9  macro / pad geometry: core block inside the core area, core area clear of the ring
  P10 power / ground: planned supply pads present; every ring cell's vdd / vss / iovdd / iovss pin
      on the VDD / VSS / IOVDD / IOVSS net
  P11 unassigned signals reported (reserved, PHY-owned, any unplaced port)
Output: reports/physical/PHYSICAL_CHECKS.md + .json; exit 1 on any FAIL.
"""
from __future__ import annotations

import json
import re
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import sfio_inv as I  # noqa: E402
from sfio_lef import read_lef  # noqa: E402

ROOT = I.ROOT
DEF = ROOT / "build/phys/or/silicaflux_io_shell.def"
EPS = 1e-6


# ----------------------------------------------------------------------------- DEF reader
def read_def(path):
    t = Path(path).read_text()
    units = int(re.search(r"UNITS\s+DISTANCE\s+MICRONS\s+(\d+)", t).group(1))
    die = [int(v) / units for v in re.search(r"DIEAREA\s+\(\s*(-?\d+)\s+(-?\d+)\s*\)\s*\(\s*(-?\d+)\s+(-?\d+)\s*\)", t).groups()]

    def section(name):
        m = re.search(rf"\n{name}\s+\d+\s*;(.*?)\nEND {name}", t, re.S)
        return m.group(1) if m else ""

    comps = {}
    for rec in section("COMPONENTS").split(";"):
        m = re.search(r"-\s+(\S+)\s+(\S+)(.*)", rec, re.S)
        if not m:
            continue
        name, master, rest = m.group(1), m.group(2), m.group(3)
        pm = re.search(r"\+\s+(PLACED|FIXED|FIRM|COVER)\s+\(\s*(-?\d+)\s+(-?\d+)\s*\)\s+(\S+)", rest)
        comps[name.replace("\\", "")] = {"master": master, "status": pm.group(1) if pm else "UNPLACED",
                                         "xy": (int(pm.group(2)) / units, int(pm.group(3)) / units) if pm else None,
                                         "orient": pm.group(4) if pm else None}
    pins = {}
    for rec in section("PINS").split(";"):
        m = re.search(r"-\s+(\S+)\s+\+\s+NET\s+(\S+)(.*)", rec, re.S)
        if not m:
            continue
        name, net, rest = m.group(1), m.group(2), m.group(3)
        d = re.search(r"DIRECTION\s+(\S+)", rest)
        lay = re.search(r"LAYER\s+(\S+)\s+\(\s*(-?\d+)\s+(-?\d+)\s*\)\s+\(\s*(-?\d+)\s+(-?\d+)\s*\)", rest)
        pl = re.search(r"(PLACED|FIXED)\s+\(\s*(-?\d+)\s+(-?\d+)\s*\)\s+(\S+)", rest)
        rect = None
        if lay and pl:
            x0, y0, x1, y1 = (int(v) / units for v in lay.groups()[1:])
            ox, oy = int(pl.group(2)) / units, int(pl.group(3)) / units
            rect = (ox + min(x0, x1), oy + min(y0, y1), ox + max(x0, x1), oy + max(y0, y1))   # N orientation
        pins[name.replace("\\", "")] = {"net": net.replace("\\", ""), "dir": d.group(1) if d else None,
                                        "layer": lay.group(1) if lay else None, "rect": rect,
                                        "use": (re.search(r"USE\s+(\S+)", rest) or [None, None])[1]}
    nets = defaultdict(list)
    for sec in ("SPECIALNETS", "NETS"):
        for rec in section(sec).split(";"):
            m = re.search(r"-\s+(\S+)(.*)", rec, re.S)
            if not m:
                continue
            for inst, pin in re.findall(r"\(\s*(\S+)\s+(\S+)\s*\)", m.group(2)):
                nets[m.group(1).replace("\\", "")].append((inst.replace("\\", ""), pin))
    return {"units": units, "die": die, "comps": comps, "pins": pins, "nets": nets}


def xform(orient, w, h, px, py):
    return {"N": (px, py), "S": (w - px, h - py), "W": (h - py, px), "E": (py, w - px),
            "FN": (w - px, py), "FS": (px, h - py), "FW": (py, px), "FE": (h - py, w - px)}[orient]


def bbox(comp, macro):
    w, h = macro.size
    x, y = comp["xy"]
    if comp["orient"] in ("W", "E", "FW", "FE"):
        w, h = h, w
    return (x, y, x + w, y + h)


def rect_of(comp, macro, r):
    w, h = macro.size
    x, y = comp["xy"]
    a = xform(comp["orient"], w, h, r[0], r[1])
    b = xform(comp["orient"], w, h, r[2], r[3])
    return (x + min(a[0], b[0]), y + min(a[1], b[1]), x + max(a[0], b[0]), y + max(a[1], b[1]))


def overlap(a, b):
    return min(a[2], b[2]) - max(a[0], b[0]) > EPS and min(a[3], b[3]) - max(a[1], b[1]) > EPS


def inside(a, box):
    return a[0] >= box[0] - EPS and a[1] >= box[1] - EPS and a[2] <= box[2] + EPS and a[3] <= box[3] + EPS


# ----------------------------------------------------------------------------- checks
def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--def", dest="deff", default=str(DEF))
    ap.add_argument("--netlist", default=str(ROOT / "build/phys/netlist.json"))
    ap.add_argument("--report", default="reports/physical")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args(argv)
    inv = I.load()
    plan = json.loads((ROOT / "physical/generated/padring.json").read_text())
    geo = plan["geometry"]
    lef = read_lef([ROOT / "third_party/ihp-sg13g2/lef/sg13g2_tech.lef", ROOT / "third_party/ihp-sg13g2/lef/sg13g2_stdcell.lef",
                    ROOT / "third_party/ihp-sg13g2/lef/sg13g2_io.lef", ROOT / "third_party/ihp-sg13g2/lef/bondpad_70x70.lef",
                    ROOT / "build/phys/sf_io_die_core_abstract.lef"])
    routing = {k for k, v in lef.layers.items() if v.get("type") == "ROUTING"}
    nl = json.loads(Path(args.netlist).read_text())["modules"]["silicaflux_io_shell"]
    ren = json.loads((ROOT / "build/phys/pad_rename.json").read_text())
    df = read_def(args.deff)
    comps, pins = df["comps"], df["pins"]
    res = []

    def chk(rule, ok, msg, detail=None):
        res.append({"rule": rule, "ok": bool(ok), "msg": msg, "detail": detail or []})

    pads = inv["_pads"]
    want_dir = {"in": "input", "out": "output", "tri": "output", "od": "output", "bidir": "inout"}
    # ---- P1
    nports = {}
    for n, p in nl["ports"].items():
        nb = len(p["bits"])
        for i, b in enumerate(p["bits"]):
            nports[n if nb == 1 else f"{n}[{i}]"] = (p["direction"], b)
    bad = []
    for p in pads:
        if p["port"] not in nports:
            bad.append(f"{p['port']} missing")
        elif nports[p["port"]][0] != want_dir[p["dir"]]:
            bad.append(f"{p['port']}: {nports[p['port']][0]} != {want_dir[p['dir']]}")
    extra = sorted(set(nports) - {p["port"] for p in pads})
    chk("P1", not bad and not extra, f"{len(nports)} netlist port bits == {len(pads)} inventory pad bits, directions equal",
        bad + [f"extra port {e}" for e in extra])
    # ---- P2
    cells = nl["cells"]
    inst2cell = {}
    for old, new in ren.items():
        c = cells.get(old) or cells.get("\\" + old)
        inst2cell[new] = c
    bad = []
    for p in pads:
        c = inst2cell.get(p["inst"])
        if c is None:
            bad.append(f"{p['inst']} missing"); continue
        if c["type"] != p["cell"]:
            bad.append(f"{p['inst']}: {c['type']} != {p['cell']}")
        if c["connections"].get("pad") != [nports[p["port"]][1]]:
            bad.append(f"{p['inst']}: pad pin not on port {p['port']}")
        for cp in ("p2c", "c2p", "c2p_en"):
            if cp in c["connections"]:
                b = c["connections"][cp][0]
                if cp == "c2p_en" and b in ("0",):
                    bad.append(f"{p['inst']}: c2p_en tied 0 (output can never drive)")
                if cp == "p2c":
                    users = sum(1 for cc in cells.values() for pn, bb in cc["connections"].items()
                                if b in bb and cc is not c and cc.get("port_directions", {}).get(pn) != "output")
                    if users == 0:
                        bad.append(f"{p['inst']}: p2c drives nothing")
    sup_plan = [s for s in plan["slots"] if s["kind"] == "supply"]
    sup_nl = {k: v for k, v in inst2cell.items() if v["type"] in inv["technology"]["supply_cells"].values()}
    for s in sup_plan:
        if s["inst"] not in sup_nl or sup_nl[s["inst"]]["type"] != s["cell"]:
            bad.append(f"supply {s['inst']} missing or wrong cell")
    chk("P2", not bad, f"{len(pads)} signal pad cells + {len(sup_plan)} supply pad cells: master, pad-pin net and core pins as planned", bad)
    # ---- P3
    nl_inst = set(inst2cell)
    def_pad = {n for n, c in comps.items() if c["master"].startswith("sg13g2_IOPad")}
    sup_terms = {"VDD", "VSS", "IOVDD", "IOVSS"}
    def_ports = set(pins) - sup_terms
    bad = [f"pad {n} only in netlist" for n in sorted(nl_inst - def_pad)] + [f"pad {n} only in DEF" for n in sorted(def_pad - nl_inst)]
    bad += [f"port {n} only in netlist" for n in sorted(set(nports) - def_ports)] + [f"terminal {n} only in DEF" for n in sorted(def_ports - set(nports))]
    bad += [f"{n}: master {comps[n]['master']} != netlist {inst2cell[n]['type']}" for n in sorted(nl_inst & def_pad) if comps[n]["master"] != inst2cell[n]["type"]]
    chk("P3", not bad, f"DEF: {len(def_pad)} pad instances and {len(def_ports)} signal terminals match the netlist names "
        f"(+{len(set(pins) & sup_terms)} supply terminals {sorted(set(pins) & sup_terms)} created by connect_by_abutment)", bad)
    # ---- P4
    want_orient = {"S": "N", "N": "FS", "E": "W", "W": "FW"}
    bad = []
    io_off, cw, depth = geo["io_offset"], geo["cell_w"], geo["depth"]
    W, H = geo["die"][2], geo["die"][3]
    for s in plan["slots"]:
        c = comps.get(s["inst"])
        if not c or c["status"] not in ("PLACED", "FIXED"):
            bad.append(f"{s['inst']} not placed"); continue
        bb = bbox(c, lef.macros[c["master"]])
        if [round(v, 3) for v in bb] != [round(v, 3) for v in s["bbox"]]:
            bad.append(f"{s['inst']} at {bb} != plan {s['bbox']}")
        if c["orient"] != want_orient[s["side"]]:
            bad.append(f"{s['inst']}: orientation {c['orient']} on side {s['side']}")
    chk("P4", not bad, f"{len(plan['slots'])} pads placed at the planned side / offset / row orientation (S N, N FS, E W, W FW)", bad)
    # ---- P5
    boxes = []
    for n, c in comps.items():
        if c["xy"] is None:
            continue
        boxes.append((bbox(c, lef.macros[c["master"]]), n, c["master"]))
    boxes.sort()
    over = []
    for i in range(len(boxes)):
        bi = boxes[i][0]
        for j in range(i + 1, len(boxes)):
            bj = boxes[j][0]
            if bj[0] >= bi[2] - EPS:
                break
            if overlap(bi, bj):
                over.append(f"{boxes[i][1]} x {boxes[j][1]}")
    n_std = sum(1 for b in boxes if not b[2].startswith(("sg13g2_IO", "sg13g2_Filler", "sg13g2_Corner", "bondpad", "sf_io_die_core")))
    chk("P5", not over, f"{len(boxes)} placed instances ({n_std} standard cells): no overlap", over[:20])
    # ---- P6
    corner = geo["corner"][0]
    gaps = []
    ring = [(bbox(c, lef.macros[c["master"]]), n) for n, c in comps.items() if c["xy"] and
            (c["master"].startswith("sg13g2_IOPad") or c["master"].startswith("sg13g2_Filler"))]
    corners = [bbox(c, lef.macros[c["master"]]) for c in comps.values() if c["master"] == "sg13g2_Corner" and c["xy"]]
    for side in I.SIDES:
        if side in "NS":
            ivs = sorted((b[0], b[2]) for b, n in ring if (b[1] < H / 2) == (side == "S") and b[3] - b[1] > b[2] - b[0] - EPS)
            lo, hi = io_off + corner, W - io_off - corner
        else:
            ivs = sorted((b[1], b[3]) for b, n in ring if (b[0] < W / 2) == (side == "W") and b[2] - b[0] > b[3] - b[1] - EPS)
            lo, hi = io_off + corner, H - io_off - corner
        cur = lo
        for a, b in ivs:
            if a > cur + EPS:
                gaps.append(f"{side}: gap {cur:.3f}-{a:.3f}")
            cur = max(cur, b)
        if cur < hi - EPS:
            gaps.append(f"{side}: gap {cur:.3f}-{hi:.3f}")
    exp_corners = [(io_off, io_off), (W - io_off - corner, io_off), (io_off, H - io_off - corner), (W - io_off - corner, H - io_off - corner)]
    miss = [c for c in exp_corners if not any(abs(b[0] - c[0]) < EPS and abs(b[1] - c[1]) < EPS for b in corners)]
    chk("P6", not gaps and not miss and len(corners) == 4,
        f"ring continuity: 4 corners, {sum(1 for _, n in ring if comps[n]['master'].startswith('sg13g2_Filler'))} fillers + pads tile all four sides without gap",
        gaps + [f"corner missing at {m}" for m in miss])
    # ---- P7
    bonds = {n: c for n, c in comps.items() if c["master"] == "bondpad_70x70"}
    bad = []
    die_box = (0, 0, W, H)
    used = set()
    bb_list = []
    for s in plan["slots"]:
        exp = [round(v, 3) for v in s["bondpad"]]
        hit = [n for n, c in bonds.items() if [round(v, 3) for v in bbox(c, lef.macros["bondpad_70x70"])] == exp]
        if len(hit) != 1:
            bad.append(f"{s['inst']}: {len(hit)} bond pads at {exp}"); continue
        used.add(hit[0])
        b = bbox(bonds[hit[0]], lef.macros["bondpad_70x70"])
        bb_list.append(b)
        if not inside(b, die_box):
            bad.append(f"{hit[0]} outside the die")
        if overlap(b, tuple(s["bbox"])):
            bad.append(f"{hit[0]} overlaps its IO cell")
    if len(bonds) != len(plan["slots"]):
        bad.append(f"{len(bonds)} bond pads for {len(plan['slots'])} pad cells")
    gap_min = min((max(b2[0] - b1[2], b2[1] - b1[3], b1[0] - b2[2], b1[1] - b2[3])
                   for i, b1 in enumerate(bb_list) for b2 in bb_list[i + 1:]), default=None)
    edge_min = min(min(b[0], b[1], W - b[2], H - b[3]) for b in bb_list) if bb_list else None
    chk("P7", not bad, f"{len(bonds)} bond pads (70 x 70 um) at the planned offset, inside the die, outside their IO cells; "
        f"closest bond-pad spacing {gap_min:.1f} um, closest to die edge {edge_min:.1f} um (assembly rules: dependency PKG)", bad)
    # ---- P8
    bad = []
    term_layers = set()
    for s in plan["slots"]:
        if s["kind"] != "signal":
            continue
        port = s["port"]
        tp = pins.get(port)
        if not tp or tp["rect"] is None:
            bad.append(f"terminal {port} not placed"); continue
        term_layers.add(tp["layer"])
        cell = lef.macros[s["cell"]]
        if tp["layer"] not in routing or tp["layer"] not in cell.pins["pad"].layers:
            bad.append(f"{port}: layer {tp['layer']} not a pad-pin routing layer")
        c = comps[s["inst"]]
        pad_shapes = [rect_of(c, cell, sh[1:]) for sh in cell.pins["pad"].shapes if sh[0] == tp["layer"]]
        if not any(inside(tp["rect"], ps) for ps in pad_shapes):
            bad.append(f"{port}: terminal not on its pad pin")
        side = s["side"]
        r = tp["rect"]
        d_edge = {"S": r[1], "N": H - r[3], "W": r[0], "E": W - r[2]}[side]
        if abs(d_edge - io_off) > 3.0 + EPS:
            bad.append(f"{port}: terminal {d_edge:.2f} um from the die edge (outer pad edge is {io_off})")
        for cp in ("p2c", "c2p", "c2p_en"):
            if cp not in cell.pins:
                continue
            for sh in cell.pins[cp].shapes:
                pr = rect_of(c, cell, sh[1:])
                dist = {"S": io_off + depth - pr[3], "N": pr[1] - (H - io_off - depth), "W": io_off + depth - pr[2],
                        "E": pr[0] - (W - io_off - depth)}[side]
                if dist > 25.0:
                    bad.append(f"{s['inst']}.{cp} is {dist:.1f} um from the ring's inner edge")
                if sh[0] not in routing:
                    bad.append(f"{s['inst']}.{cp} on non-routing layer {sh[0]}")
    core_m = lef.macros["sf_io_die_core"]
    cpin_layers = sorted({sh[0] for p in core_m.pins.values() for sh in p.shapes})
    if not set(cpin_layers) <= routing:
        bad.append(f"core block pins on {cpin_layers}")
    chk("P8", not bad, f"signal terminals on {sorted(term_layers)} over their pad pins at the outer pad edge; pad core pins "
        f"(p2c / c2p / c2p_en) on the ring's inner edge; core-block pins on {cpin_layers} (all tech-LEF routing layers)", bad)
    # ---- P9
    core = geo["core"]
    bad = []
    dc = comps.get("u_die")
    if not dc or dc["status"] not in ("FIRM", "FIXED", "PLACED"):
        bad.append("core block u_die not placed")
    else:
        b = bbox(dc, core_m)
        if not inside(b, core):
            bad.append(f"core block {b} outside the core area {core}")
        ring_inner = (io_off + depth, io_off + depth, W - io_off - depth, H - io_off - depth)
        if not inside(core, ring_inner):
            bad.append("core area intersects the IO ring")
    gap = min(core[0] - (io_off + depth), core[1] - (io_off + depth), W - io_off - depth - core[2], H - io_off - depth - core[3])
    stray = [n for bx, n, m in boxes if not m.startswith(("sg13g2_IO", "sg13g2_Filler", "sg13g2_Corner", "bondpad", "sf_io_die_core"))
             and not inside(bx, core)]
    if stray:
        bad.append(f"{len(stray)} standard cells outside the core area")
    chk("P9", not bad, f"core block {core_m.size[0]:.1f} x {core_m.size[1]:.1f} um inside the core area; core area {gap:.2f} um "
        f"clear of the ring's inner edge; every standard cell inside the core area", bad + stray[:5])
    # ---- P10
    bad = []
    plan_sup = defaultdict(int)
    for s in sup_plan:
        plan_sup[(s["side"], s["supply"])] += 1
    def_sup = defaultdict(int)
    for s in sup_plan:
        if s["inst"] in comps:
            def_sup[(s["side"], s["supply"])] += 1
    if plan_sup != def_sup:
        bad.append("supply pads differ from the plan")
    netmap = {"vdd": "VDD", "vss": "VSS", "iovdd": "IOVDD", "iovss": "IOVSS"}
    on = {k: set(df["nets"].get(v, [])) for k, v in netmap.items()}
    nring = 0
    for n, c in comps.items():
        m = c["master"]
        if not (m.startswith("sg13g2_IOPad") or m.startswith("sg13g2_Filler") or m == "sg13g2_Corner"):
            continue
        nring += 1
        for pin, net in netmap.items():
            if pin in lef.macros[m].pins and (n, pin) not in on[pin]:
                bad.append(f"{n}.{pin} not on {net}")
    chk("P10", not bad, f"{len(sup_plan)} supply pads as planned per side and kind; all {nring} ring cells have vdd / vss / iovdd / "
        f"iovss on VDD / VSS / IOVDD / IOVSS", bad[:20])
    # ---- P11
    unassigned = [f"{p['name']} ({p.get('width', 1)} bit, RESERVED, {p['dep']})" for p in inv.get("reserved", [])]
    unassigned += [f"{p['name']} ({p.get('width', 1) or 'vendor-defined'} bit, BLOCKED, {p['dep']})" for p in inv.get("phy_owned", [])]
    unplaced = [n for n, p in pins.items() if p["rect"] is None]
    chk("P11", not unplaced, f"no unplaced terminal; {len(unassigned)} inventory signals unassigned by design (reserved / PHY-owned)",
        unassigned + [f"UNPLACED terminal {u}" for u in unplaced])

    # ---------------------------------------------------------------- report
    out = ROOT / args.report
    out.mkdir(parents=True, exist_ok=True)
    (out / "PHYSICAL_CHECKS.json").write_text(json.dumps(res, indent=1))
    L = ["# Physical checks -- pad ring (independent re-derivation from DEF / LEF / netlist)", "",
         f"DEF `{Path(args.deff).resolve().relative_to(ROOT)}`, die {W:.0f} x {H:.0f} um. Every check is recomputed here from the files; "
         "OpenROAD's own reports are kept in `reports/physical/openroad/`.", "",
         "| Rule | Result | Check |", "|---|---|---|"]
    for r in res:
        L.append(f"| {r['rule']} | {'PASS' if r['ok'] else '**FAIL**'} | {r['msg']} |")
    for r in res:
        if r["detail"]:
            L += ["", f"### {r['rule']} detail", ""] + [f"* {d}" for d in r["detail"]]
    (out / "PHYSICAL_CHECKS.md").write_text("\n".join(L) + "\n")
    if not args.quiet:
        for r in res:
            print(f"[{'PASS' if r['ok'] else 'FAIL'}] {r['rule']} {r['msg']}")
            for d in r["detail"][:6] if not r["ok"] else []:
                print("      ", d)
    return res


if __name__ == "__main__" and False:
    pass


if __name__ == "__main__":
    sys.exit(0 if all(r["ok"] for r in main()) else 1)
