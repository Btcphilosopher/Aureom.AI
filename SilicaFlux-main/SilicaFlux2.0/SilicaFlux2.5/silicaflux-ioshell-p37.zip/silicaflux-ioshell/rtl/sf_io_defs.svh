// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: sf_io_defs.svh -- shared macros
// SF_IO_ELAB_FATAL(msg): stop elaboration with a fixed message.  Verilator and
// Yosys evaluate a generate-time $fatal; Icarus 12 needs an initial block.
// =============================================================================
`ifndef SF_IO_DEFS_SVH
`define SF_IO_DEFS_SVH
`ifdef __ICARUS__
`define SF_IO_ELAB_FATAL(MSG) initial $fatal(1, MSG);
`else
`define SF_IO_ELAB_FATAL(MSG) $fatal(1, MSG);
`endif
`endif
