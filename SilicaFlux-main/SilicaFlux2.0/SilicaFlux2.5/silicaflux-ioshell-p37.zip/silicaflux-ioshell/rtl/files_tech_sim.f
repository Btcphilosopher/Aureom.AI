// technology layer: SIMULATION ONLY behavioural pads + P35 sim cells
rtl/pads/tech/sim/sf_io_cells_sim.sv
third_party/silicaflux-clocktree/rtl/tech/sim/sf_crt_tech_cells.sv
