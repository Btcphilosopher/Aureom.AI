// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: silicaflux_io_shell -- chip perimeter
// Aureom.AI | SilicaFlux-HPC          PRIMARY RTL
//
// The chip top: every port is a pad (a bond pad of the IHP sg13g2_io ring in
// the IHP build).  Inventory, cell choice and boundary-scan order come from
// config/io_inventory.yaml (rtl/generated/sf_io_pkg.sv); supply pads from
// scripts/pin_assign.py (rtl/generated/sf_io_supply_pads.svh).
//
//   pads ──► pad wrappers ──► boundary scan (tc_bsr) ──► functional blocks ──► die
//
//          CLK_REF CLK_CORE CLKGEN_LOCK POR_N RST_N ──► P35 clock/reset tree ──► clk, rst_n (shell)
//                                                                              └► die clk_i / por_ni
//          TEST_MODE BOOT_MODE ──► strap latches (POR) ──────────────────────────► die, P35
//          HOST_SCK/CS_N/MOSI/MISO ──► sf_io_spi_host ──► sf_io_host_split ─┬─► sf_io_mgmt (shell window)
//                                                                          └─► die host port (SFB2)
//          UART / MSPI / GPIO ◄──► sf_io_mgmt (MCU-I peripherals; firmware console from DIAG_TX)
//          HOST_IRQ_N ◄── IRQ aggregation        RAS / status pads ◄──► die
//          TCK TMS TDI TRST_N TDO ──► sf_io_jtag (TestCore tc_tap + tc_bsr)
//          die SFMC ──► sf_io_mem_boundary (controller / PHY slots: empty in milestone A)
//          sf_io_pcie_boundary (typed endpoint interface, gated: PCIE_EN = 0)
//
// Clocking: CLK_REF (reference, P35 sequencer), CLK_CORE (external functional
// clock, gated root clk = P35 clk_core_o, also the die clock), TCK (JTAG only).
// The shell adds no clock-domain crossing beyond synchronisers: SPI inputs are
// oversampled in clk, asynchronous status inputs pass 2-flop synchronisers,
// JTAG status capture synchronises into TCK.
// Resets: shell logic on P35 fab_rst_no; the die on P35 cc_rst_no (released
// after the shell); the TAP on TRST_N AND POR_N.  All outputs have defined
// reset states with no clock running (asynchronous reset assertion).
// Nothing here is an ESD-qualified pad ring, a PHY or a PLL (docs/11_LIMITATIONS.md).
// Classification: SYNTHESIZABLE (new, Project 37)
// =============================================================================
`include "sf_io_defs.svh"
`default_nettype none

module silicaflux_io_shell
  import sf_io_pkg::*;
  import sf_io_mem_pkg::*;
  import sf_io_pcie_pkg::*;
#(
  parameter int          DIE_CFG      = 0,                // 0 = SILICAFLUX_MIN (milestone A), 1 = SILICAFLUX_HPC
  parameter bit          ALLOW_NO_EXTMEM = 1'b0,          // diagnostic builds only: HPC die without a memory controller
  parameter int          MEM_CTRL     = MEM_CTRL_NONE,    // 0 NONE, 1 SIM (simulation only), 2 VENDOR
  parameter bit          PCIE_EN      = 1'b0,             // gated milestone: refused without IP
  // P35 clock qualification: core edges per MON_WINDOW reference cycles
  parameter int          MON_WINDOW   = 16,
  parameter logic [15:0] CORE_CNT_MIN = 16'd1,
  parameter logic [15:0] CORE_CNT_MAX = 16'hFFFF,
  parameter int          QTIMEOUT     = 1024,
  parameter int          HL_HALF_MIN  = HL_MIN_HALF
) (
  // ---------------------------------------------------------------- north: control region
  output wire logic       PLATFORM_READY,
  output wire logic       DEVICE_READY,
  output wire logic       TEST_DONE,
  output wire logic       TEST_FAIL,
  input  wire logic       POR_N,
  input  wire logic       RST_N,
  input  wire logic       CLK_REF,
  input  wire logic       CLK_CORE,
  input  wire logic       CLKGEN_LOCK,
  input  wire logic       TEST_MODE,
  input  wire logic [1:0] BOOT_MODE,
  output wire logic       RAS_FATAL_N,
  input  wire logic       BOARD_WARN_N,
  input  wire logic       BOARD_FATAL_N,
  // ---------------------------------------------------------------- west: test / debug + management
  input  wire logic       TRST_N,
  input  wire logic       TCK,
  input  wire logic       TMS,
  input  wire logic       TDI,
  output wire logic       TDO,
  output wire logic       UART_TX,
  input  wire logic       UART_RX,
  output wire logic       MSPI_SCK,
  output wire logic       MSPI_MOSI,
  input  wire logic       MSPI_MISO,
  output wire logic       MSPI_CS_N,
  inout  wire logic [7:0] GPIO,
  // ---------------------------------------------------------------- east: host region
  input  wire logic       HOST_SCK,
  input  wire logic       HOST_CS_N,
  input  wire logic       HOST_MOSI,
  output wire logic       HOST_MISO,
  output wire logic       HOST_IRQ_N
);

  localparam bit MEM_SIM = (MEM_CTRL == MEM_CTRL_SIM);

  // The HPC die's PLATFORM_READY includes EXTMEM_READY (silicaflux_die_pkg::DIE_ST_PLATFORM_READY):
  // without a memory controller + PHY it can never become platform-ready.  Refuse that
  // build unless it is explicitly a diagnostic one (dependencies MEM-CTRL, MEM-PHY).
  if (DIE_CFG == 1 && MEM_CTRL == MEM_CTRL_NONE && !ALLOW_NO_EXTMEM) begin : g_need_mem
    `SF_IO_ELAB_FATAL("silicaflux_io_shell: DIE_CFG = HPC needs an external-memory controller + PHY (MEM-CTRL, MEM-PHY) to reach PLATFORM_READY; use DIE_CFG = MIN, MEM_CTRL = SIM (simulation) or ALLOW_NO_EXTMEM = 1 (diagnostic build)")
  end
  localparam logic [3:0] DEP_MEM = (MEM_CTRL == MEM_CTRL_SIM) ? DEP_SIM_MODEL :
                                   (MEM_CTRL == MEM_CTRL_VENDOR) ? DEP_PRESENT : DEP_ABSENT;
  localparam logic [3:0] DEP_PCIE = PCIE_EN ? DEP_PRESENT : DEP_ABSENT;
  localparam logic [3:0] DEP_IO   = (sf_io_tech_pkg::IO_TECH == 1) ? DEP_PRESENT : DEP_SIM_MODEL;
  //                         scan        mem_phy  mem_ctrl pcie_ctrl pcie_phy pll         bsr          io_lib
  localparam logic [31:0] PHY_DEP = {DEP_ABSENT, DEP_MEM, DEP_MEM, DEP_PCIE, DEP_PCIE, DEP_ABSENT, DEP_PRESENT, DEP_IO};

  // =================================================================== input pads
  logic por_n, por_raw, ext_rst_n, rst_raw, clk_ref, clk_core_in, clkgen_lock;
  logic test_mode, test_raw, board_warn_raw_n, board_fatal_raw_n;
  logic trst_n, trst_raw, tck, tms, tdi;
  logic uart_rx_p, mspi_miso_p, host_sck_p, host_cs_np, host_mosi_p;
  logic [1:0] boot_raw, boot_mode;

  sf_io_pad_rst  u_pad_POR_N       (.pad(POR_N),       .rst_no(por_n),     .raw_o(por_raw));
  sf_io_pad_rst  u_pad_RST_N       (.pad(RST_N),       .rst_no(ext_rst_n), .raw_o(rst_raw));
  sf_io_pad_clk  u_pad_CLK_REF     (.pad(CLK_REF),     .clk_o(clk_ref));
  sf_io_pad_clk  u_pad_CLK_CORE    (.pad(CLK_CORE),    .clk_o(clk_core_in));
  sf_io_pad_in   u_pad_CLKGEN_LOCK (.pad(CLKGEN_LOCK), .p2c_o(clkgen_lock));
  sf_io_pad_test u_pad_TEST_MODE   (.pad(TEST_MODE),   .por_ni(por_n), .test_o(test_mode), .raw_o(test_raw));
  for (genvar i = 0; i < 2; i++) begin : g_pad_BOOT_MODE
    sf_io_pad_in u_pad (.pad(BOOT_MODE[i]), .p2c_o(boot_raw[i]));
  end
  sf_io_strap_latch #(.W(2)) u_boot_strap (.por_ni(por_n), .d_i(boot_raw), .q_o(boot_mode));
  sf_io_pad_in   u_pad_BOARD_WARN_N  (.pad(BOARD_WARN_N),  .p2c_o(board_warn_raw_n));
  sf_io_pad_in   u_pad_BOARD_FATAL_N (.pad(BOARD_FATAL_N), .p2c_o(board_fatal_raw_n));
  sf_io_pad_rst  u_pad_TRST_N      (.pad(TRST_N),      .rst_no(trst_n),    .raw_o(trst_raw));
  sf_io_pad_clk  u_pad_TCK         (.pad(TCK),         .clk_o(tck));
  sf_io_pad_in   u_pad_TMS         (.pad(TMS),         .p2c_o(tms));
  sf_io_pad_in   u_pad_TDI         (.pad(TDI),         .p2c_o(tdi));
  sf_io_pad_in   u_pad_UART_RX     (.pad(UART_RX),     .p2c_o(uart_rx_p));
  sf_io_pad_in   u_pad_MSPI_MISO   (.pad(MSPI_MISO),   .p2c_o(mspi_miso_p));
  sf_io_pad_in   u_pad_HOST_SCK    (.pad(HOST_SCK),    .p2c_o(host_sck_p));
  sf_io_pad_in   u_pad_HOST_CS_N   (.pad(HOST_CS_N),   .p2c_o(host_cs_np));
  sf_io_pad_in   u_pad_HOST_MOSI   (.pad(HOST_MOSI),   .p2c_o(host_mosi_p));

  // =================================================================== clock / reset root (P35, unmodified)
  // die_por_n is the die's asynchronous reset AND is sampled (2-flop synchroniser) by sf_io_host_split
  /* verilator lint_off SYNCASYNCNET */
  wire logic   die_por_n;
  /* verilator lint_on SYNCASYNCNET */
  logic        clk, rst_n, crt_sys_ready, crt_wdog_irq, split_idle;
  wire logic   quiesce;                                    // net (the testbench forces it to back-pressure the link)
  logic [3:0]  crt_seq_state;
  logic        crt_rb_sel, crt_rb_we, crt_rb_err;
  logic [7:0]  crt_rb_addr;
  logic [31:0] crt_rb_wdata, crt_rb_rdata;
  logic        br_clk_unused, br_ce_unused, br_rst_unused, mc_rst_unused, br_q_unused, mc_ready_unused;

  silicaflux_clock_reset_tree #(
    .NB(1), .NW(2), .MC_EN(1'b0), .MON_WINDOW(MON_WINDOW),
    .CORE_CNT_MIN(CORE_CNT_MIN), .CORE_CNT_MAX(CORE_CNT_MAX), .QTIMEOUT(QTIMEOUT)
  ) u_crt (
    .clk_ref_i(clk_ref), .clk_core_i(clk_core_in), .clk_mc_i(1'b0),
    .por_ni(por_n), .ext_rst_ni(ext_rst_n), .pll_lock_i(clkgen_lock),
    .test_mode_i(test_mode), .test_rst_ni(por_n), .test_en_i(test_mode),
    .clk_core_o(clk), .clk_br_o(br_clk_unused), .clk_br_ce_o(br_ce_unused),
    .fab_rst_no(rst_n), .cc_rst_no(die_por_n), .br_rst_no(br_rst_unused), .mc_rst_no(mc_rst_unused),
    .fab_quiesce_o(quiesce), .fab_idle_i(split_idle), .br_quiesce_o(br_q_unused), .br_idle_i(1'b1),
    .br_clk_req_i(1'b0), .br_wake_i(1'b0), .wdog_req_i(2'b00), .wdog_irq_o(crt_wdog_irq),
    .sys_ready_o(crt_sys_ready), .mc_ready_o(mc_ready_unused),
    .rb_sel_i(crt_rb_sel), .rb_we_i(crt_rb_we), .rb_addr_i(crt_rb_addr), .rb_wdata_i(crt_rb_wdata),
    .rb_rdata_o(crt_rb_rdata), .rb_err_o(crt_rb_err), .seq_state_o(crt_seq_state));

  // =================================================================== die (P31, unmodified)
  wire logic   die_req_valid, die_req_ready;               // nets (fault injection in the testbench forces them)
  logic        die_req_write, die_rsp_valid, die_rsp_ready, die_rsp_error;
  logic [31:0] die_req_addr, die_req_wdata, die_rsp_rdata;
  logic [3:0]  die_req_wstrb;
  logic        die_host_irq, die_platform_ready, die_device_ready, die_ras_fatal;
  logic        die_diag_valid, die_test_done, die_test_fail, die_cpu_sleep, host_rst_req;
  logic [7:0]  die_diag_char;
  logic [15:0] die_test_code;
  logic        die_tdo_unused, die_tdo_oe_unused;
  // SFMC
  logic             mc_rst_n, mc_init_done, mc_fatal, mc_cmd_valid, mc_cmd_ready, mc_cmd_write;
  logic [25:0]      mc_cmd_addr;
  logic [7:0]       mc_cmd_len;
  logic [1:0]       mc_cmd_tag, mc_rd_tag, mc_wr_tag;
  logic             mc_wd_valid, mc_wd_ready, mc_wd_last, mc_rd_valid, mc_rd_ready, mc_rd_last, mc_rd_error;
  logic [31:0]      mc_wd_data, mc_rd_data;
  logic [3:0]       mc_wd_strb;
  logic             mc_wr_valid, mc_wr_ready, mc_wr_error;

  sf_io_die_core #(.DIE_CFG(DIE_CFG)) u_die (
    .clk_i(clk), .por_ni(die_por_n), .pll_lock_i(clkgen_lock), .test_mode_i(test_mode), .boot_mode_i(boot_mode),
    .host_rst_req_i(host_rst_req),
    .host_req_valid_i(die_req_valid), .host_req_ready_o(die_req_ready), .host_req_write_i(die_req_write),
    .host_req_addr_i(die_req_addr), .host_req_wdata_i(die_req_wdata), .host_req_wstrb_i(die_req_wstrb),
    .host_rsp_valid_o(die_rsp_valid), .host_rsp_ready_i(die_rsp_ready), .host_rsp_rdata_o(die_rsp_rdata),
    .host_rsp_error_o(die_rsp_error), .host_irq_o(die_host_irq),
    .platform_ready_o(die_platform_ready), .device_ready_o(die_device_ready),
    .mc_clk_i(clk), .mc_rst_no(mc_rst_n), .mc_init_done_i(mc_init_done), .mc_fatal_i(mc_fatal),
    .mc_cmd_valid_o(mc_cmd_valid), .mc_cmd_ready_i(mc_cmd_ready), .mc_cmd_write_o(mc_cmd_write),
    .mc_cmd_addr_o(mc_cmd_addr), .mc_cmd_len_o(mc_cmd_len), .mc_cmd_tag_o(mc_cmd_tag),
    .mc_wd_valid_o(mc_wd_valid), .mc_wd_ready_i(mc_wd_ready), .mc_wd_data_o(mc_wd_data), .mc_wd_strb_o(mc_wd_strb),
    .mc_wd_last_o(mc_wd_last), .mc_rd_valid_i(mc_rd_valid), .mc_rd_ready_o(mc_rd_ready), .mc_rd_data_i(mc_rd_data),
    .mc_rd_tag_i(mc_rd_tag), .mc_rd_last_i(mc_rd_last), .mc_rd_error_i(mc_rd_error),
    .mc_wr_valid_i(mc_wr_valid), .mc_wr_ready_o(mc_wr_ready), .mc_wr_tag_i(mc_wr_tag), .mc_wr_error_i(mc_wr_error),
    .tck_i(1'b0), .tms_i(1'b1), .tdi_i(1'b1), .trst_ni(1'b0), .tdo_o(die_tdo_unused), .tdo_oe_o(die_tdo_oe_unused),
    .ext_warn_i(!board_warn_raw_n), .ext_fatal_i(!board_fatal_raw_n), .ras_fatal_o(die_ras_fatal),
    .diag_valid_o(die_diag_valid), .diag_char_o(die_diag_char), .test_done_o(die_test_done),
    .test_fail_o(die_test_fail), .test_code_o(die_test_code), .cpu_sleep_o(die_cpu_sleep));

  // =================================================================== external-memory slots
  mem_phy_status_t mem_phy_st;
  logic [31:0]     mem_phy_word;
  sf_io_mem_boundary #(.MEM_CTRL(MEM_CTRL), .MC_AW(26), .MC_TW(2)) u_mem (
    .clk, .rst_n,
    .mc_rst_ni(mc_rst_n), .mc_init_done_o(mc_init_done), .mc_fatal_o(mc_fatal),
    .mc_cmd_valid_i(mc_cmd_valid), .mc_cmd_ready_o(mc_cmd_ready), .mc_cmd_write_i(mc_cmd_write),
    .mc_cmd_addr_i(mc_cmd_addr), .mc_cmd_len_i(mc_cmd_len), .mc_cmd_tag_i(mc_cmd_tag),
    .mc_wd_valid_i(mc_wd_valid), .mc_wd_ready_o(mc_wd_ready), .mc_wd_data_i(mc_wd_data), .mc_wd_strb_i(mc_wd_strb),
    .mc_wd_last_i(mc_wd_last), .mc_rd_valid_o(mc_rd_valid), .mc_rd_ready_i(mc_rd_ready), .mc_rd_data_o(mc_rd_data),
    .mc_rd_tag_o(mc_rd_tag), .mc_rd_last_o(mc_rd_last), .mc_rd_error_o(mc_rd_error),
    .mc_wr_valid_o(mc_wr_valid), .mc_wr_ready_i(mc_wr_ready), .mc_wr_tag_o(mc_wr_tag), .mc_wr_error_o(mc_wr_error),
    .phy_status_o(mem_phy_st), .mem_phy_reg_o(mem_phy_word));

  // =================================================================== PCIe slot (gated milestone)
  pcie_bar_rsp_t pcie_bar_rsp_unused;
  pcie_dma_req_t pcie_dma_req_unused;
  pcie_msi_req_t pcie_msi_unused;
  logic          pcie_req_valid, pcie_req_write, pcie_rsp_ready, pcie_host_rst;
  logic [31:0]   pcie_req_addr, pcie_req_wdata, pcie_word;
  logic [3:0]    pcie_req_wstrb;
  sf_io_pcie_boundary #(.PCIE_EN(PCIE_EN)) u_pcie (
    .clk, .rst_n,
    .ep_bar_req_i('0), .ep_bar_rsp_o(pcie_bar_rsp_unused), .ep_dma_req_o(pcie_dma_req_unused),
    .ep_dma_rsp_i('0), .ep_msi_o(pcie_msi_unused), .ep_msi_ready_i(1'b0), .ep_link_i('0),
    .m_req_valid(pcie_req_valid), .m_req_ready(1'b0), .m_req_write(pcie_req_write), .m_req_addr(pcie_req_addr),
    .m_req_wdata(pcie_req_wdata), .m_req_wstrb(pcie_req_wstrb), .m_rsp_valid(1'b0), .m_rsp_ready(pcie_rsp_ready),
    .m_rsp_rdata(32'd0), .m_rsp_error(1'b0), .host_rst_req_o(pcie_host_rst), .pcie_reg_o(pcie_word));

  // =================================================================== host-command path
  logic        hl_req_valid, hl_req_ready, hl_req_write, hl_rsp_valid, hl_rsp_ready, hl_rsp_error;
  logic [31:0] hl_req_addr, hl_req_wdata, hl_rsp_rdata;
  logic [3:0]  hl_req_wstrb;
  logic        sh_req_valid, sh_req_ready, sh_req_write, sh_rsp_valid, sh_rsp_ready, sh_rsp_error;
  logic [31:0] sh_req_addr, sh_req_wdata, sh_rsp_rdata;
  logic [3:0]  sh_req_wstrb;
  logic        miso, miso_oe, hl_busy, host_irq, die_in_reset, spi_rst_req, die_force;
  logic [4:0]  link_err, link_err_clr;
  logic        link_cnt_clr;
  logic [15:0] link_good, link_bad, split_refused, split_fenced;

  sf_io_spi_host #(.MIN_HALF(HL_HALF_MIN)) u_hlink (
    .clk, .rst_n, .sck_i(host_sck_p), .cs_ni(host_cs_np), .mosi_i(host_mosi_p), .miso_o(miso), .miso_oe_o(miso_oe),
    .m_req_valid(hl_req_valid), .m_req_ready(hl_req_ready), .m_req_write(hl_req_write), .m_req_addr(hl_req_addr),
    .m_req_wdata(hl_req_wdata), .m_req_wstrb(hl_req_wstrb), .m_rsp_valid(hl_rsp_valid), .m_rsp_ready(hl_rsp_ready),
    .m_rsp_rdata(hl_rsp_rdata), .m_rsp_error(hl_rsp_error),
    .platform_ready_i(die_platform_ready), .device_ready_i(die_device_ready), .irq_i(host_irq),
    .die_in_reset_i(die_in_reset), .crt_ready_i(crt_sys_ready), .host_rst_req_o(spi_rst_req),
    .err_o(link_err), .err_clr_i(link_err_clr), .cnt_clr_i(link_cnt_clr),
    .good_frames_o(link_good), .bad_frames_o(link_bad), .busy_o(hl_busy));
  assign host_rst_req = spi_rst_req || pcie_host_rst;

  sf_io_host_split u_split (
    .clk, .rst_n,
    .s_req_valid(hl_req_valid), .s_req_ready(hl_req_ready), .s_req_write(hl_req_write), .s_req_addr(hl_req_addr),
    .s_req_wdata(hl_req_wdata), .s_req_wstrb(hl_req_wstrb), .s_rsp_valid(hl_rsp_valid), .s_rsp_ready(hl_rsp_ready),
    .s_rsp_rdata(hl_rsp_rdata), .s_rsp_error(hl_rsp_error),
    .sh_req_valid, .sh_req_ready, .sh_req_write, .sh_req_addr, .sh_req_wdata, .sh_req_wstrb,
    .sh_rsp_valid, .sh_rsp_ready, .sh_rsp_rdata, .sh_rsp_error,
    .die_req_valid, .die_req_ready, .die_req_write, .die_req_addr, .die_req_wdata, .die_req_wstrb,
    .die_rsp_valid, .die_rsp_ready, .die_rsp_rdata, .die_rsp_error,
    .die_platform_ready_i(die_platform_ready), .die_force_i(die_force), .die_rst_ni(die_por_n), .quiesce_i(quiesce), .idle_o(split_idle),
    .die_in_reset_o(die_in_reset), .refused_o(split_refused), .fenced_o(split_fenced));

  // =================================================================== synchronised status
  logic clkgen_lock_s, board_warn_s, board_fatal_s;
  logic [3:0] crt_state_s;
  sfv_sync u_sy_lock  (.clk, .rst_n, .d(clkgen_lock),         .q(clkgen_lock_s));
  sfv_sync u_sy_bwarn (.clk, .rst_n, .d(!board_warn_raw_n),  .q(board_warn_s));
  sfv_sync u_sy_bfat  (.clk, .rst_n, .d(!board_fatal_raw_n), .q(board_fatal_s));
  for (genvar i = 0; i < 4; i++) begin : g_sy_state     // per-bit, status only (not coherent)
    sfv_sync u_sy (.clk, .rst_n, .d(crt_seq_state[i]), .q(crt_state_s[i]));
  end
  wire [31:0] shell_status = {12'd0, crt_state_s, mc_rst_n, mc_init_done, quiesce, die_in_reset,
                              crt_wdog_irq, die_host_irq, boot_mode, test_mode, board_fatal_s, board_warn_s,
                              die_ras_fatal, die_device_ready, die_platform_ready, crt_sys_ready, clkgen_lock_s};

  // =================================================================== management window
  logic       uart_tx_f, mspi_sck_f, mspi_mosi_f, mspi_cs_nf;
  logic [7:0] gpio_o_f, gpio_oe_f, gpio_i_c;
  logic [9:0] irq_status;
  sf_io_mgmt #(.DIE_CONFIG_ID(8'(DIE_CFG + 1)), .PHY_DEP(PHY_DEP), .P_IO_TECH(sf_io_tech_pkg::IO_TECH == 1),
               .P_MEM_SIM(MEM_SIM), .PCIE_PRESENT(PCIE_EN)) u_mgmt (
    .clk, .rst_n,
    .s_req_valid(sh_req_valid), .s_req_ready(sh_req_ready), .s_req_write(sh_req_write), .s_req_addr(sh_req_addr),
    .s_req_wdata(sh_req_wdata), .s_req_wstrb(sh_req_wstrb), .s_rsp_valid(sh_rsp_valid), .s_rsp_ready(sh_rsp_ready),
    .s_rsp_rdata(sh_rsp_rdata), .s_rsp_error(sh_rsp_error),
    .uart_txd_o(uart_tx_f), .uart_rxd_i(uart_rx_p), .mspi_sck_o(mspi_sck_f), .mspi_mosi_o(mspi_mosi_f),
    .mspi_miso_i(mspi_miso_p), .mspi_cs_no(mspi_cs_nf), .gpio_i(gpio_i_c), .gpio_o(gpio_o_f), .gpio_oe_o(gpio_oe_f),
    .crt_rb_sel_o(crt_rb_sel), .crt_rb_we_o(crt_rb_we), .crt_rb_addr_o(crt_rb_addr), .crt_rb_wdata_o(crt_rb_wdata),
    .crt_rb_rdata_i(crt_rb_rdata), .crt_rb_err_i(crt_rb_err),
    .diag_valid_i(die_diag_valid), .diag_char_i(die_diag_char),
    .status_i(shell_status), .die_irq_i(die_host_irq), .crt_wdog_irq_i(crt_wdog_irq),
    .board_warn_i(board_warn_s), .board_fatal_i(board_fatal_s), .ras_fatal_i(die_ras_fatal),
    .mc_init_done_i(mc_init_done), .mc_fatal_i(mc_fatal),
    .link_err_i(link_err), .link_good_i(link_good), .link_bad_i(link_bad),
    .link_err_clr_o(link_err_clr), .link_cnt_clr_o(link_cnt_clr),
    .die_test_code_i(die_test_code), .die_test_done_i(die_test_done), .die_test_fail_i(die_test_fail),
    .die_cpu_sleep_i(die_cpu_sleep), .mem_phy_i(mem_phy_word), .pcie_i(pcie_word),
    .die_force_o(die_force), .host_irq_o(host_irq), .irq_status_o(irq_status));

  // =================================================================== boundary scan (functional side)
  logic [BSR_NUM_IN-1:0]    bsr_in;
  logic [BSR_NUM_OUT-1:0]   f_out, f_oe, p_out, p_oe;
  logic [BSR_NUM_BIDIR-1:0] f_io, f_io_oe, p_io, p_io_oe, p_io_in, c_io_in;

  assign bsr_in[BSRI_POR_N]            = por_raw;
  assign bsr_in[BSRI_RST_N]            = rst_raw;
  assign bsr_in[BSRI_CLK_REF]          = clk_ref;
  assign bsr_in[BSRI_CLK_CORE]         = clk_core_in;
  assign bsr_in[BSRI_CLKGEN_LOCK]      = clkgen_lock;
  assign bsr_in[BSRI_TEST_MODE]        = test_raw;
  assign bsr_in[BSRI_BOOT_MODE +: 2]   = boot_raw;
  assign bsr_in[BSRI_BOARD_WARN_N]     = board_warn_raw_n;
  assign bsr_in[BSRI_BOARD_FATAL_N]    = board_fatal_raw_n;
  assign bsr_in[BSRI_UART_RX]          = uart_rx_p;
  assign bsr_in[BSRI_MSPI_MISO]        = mspi_miso_p;
  assign bsr_in[BSRI_HOST_SCK]         = host_sck_p;
  assign bsr_in[BSRI_HOST_CS_N]        = host_cs_np;
  assign bsr_in[BSRI_HOST_MOSI]        = host_mosi_p;

  // functional values: push-pull outputs always enabled; pseudo open drain = (0, assert)
  assign f_out[BSRO_PLATFORM_READY] = die_platform_ready; assign f_oe[BSRO_PLATFORM_READY] = 1'b1;
  assign f_out[BSRO_DEVICE_READY]   = die_device_ready;   assign f_oe[BSRO_DEVICE_READY]   = 1'b1;
  assign f_out[BSRO_TEST_DONE]      = die_test_done;      assign f_oe[BSRO_TEST_DONE]      = 1'b1;
  assign f_out[BSRO_TEST_FAIL]      = die_test_fail;      assign f_oe[BSRO_TEST_FAIL]      = 1'b1;
  assign f_out[BSRO_RAS_FATAL_N]    = 1'b0;               assign f_oe[BSRO_RAS_FATAL_N]    = die_ras_fatal;
  assign f_out[BSRO_UART_TX]        = uart_tx_f;          assign f_oe[BSRO_UART_TX]        = 1'b1;
  assign f_out[BSRO_MSPI_SCK]       = mspi_sck_f;         assign f_oe[BSRO_MSPI_SCK]       = 1'b1;
  assign f_out[BSRO_MSPI_MOSI]      = mspi_mosi_f;        assign f_oe[BSRO_MSPI_MOSI]      = 1'b1;
  assign f_out[BSRO_MSPI_CS_N]      = mspi_cs_nf;         assign f_oe[BSRO_MSPI_CS_N]      = 1'b1;
  assign f_out[BSRO_HOST_MISO]      = miso;               assign f_oe[BSRO_HOST_MISO]      = miso_oe;
  assign f_out[BSRO_HOST_IRQ_N]     = 1'b0;               assign f_oe[BSRO_HOST_IRQ_N]     = host_irq;
  assign f_io    = gpio_o_f;
  assign f_io_oe = gpio_oe_f;
  assign gpio_i_c = c_io_in;

  // JTAG: TAP reset = TRST_N AND POR_N; status capture (asynchronous to TCK)
  logic tdo_c, tdo_oe_c, bsr_ext;
  logic [4:0] tap_ir;
  logic ref_tog, core_tog;
  always_ff @(posedge clk_ref or negedge por_n)     if (!por_n) ref_tog  <= 1'b0; else ref_tog  <= !ref_tog;
  always_ff @(posedge clk_core_in or negedge por_n) if (!por_n) core_tog <= 1'b0; else core_tog <= !core_tog;
  wire [31:0] jtag_status = {8'h37, 7'd0, !die_por_n, crt_seq_state, die_ras_fatal, die_device_ready,
                             die_platform_ready, crt_sys_ready, core_tog, ref_tog, boot_mode, test_mode,
                             clkgen_lock, rst_raw, por_raw};
  wire tap_trst_n = trst_n && por_n;

  sf_io_jtag u_jtag (
    .tck_i(tck), .tms_i(tms), .tdi_i(tdi), .trst_ni(tap_trst_n), .tdo_o(tdo_c), .tdo_oe_o(tdo_oe_c),
    .in_pad_i(bsr_in), .out_core_i(f_out), .out_core_oe_i(f_oe), .out_pad_o(p_out), .out_pad_oe_o(p_oe),
    .io_core_o_i(f_io), .io_core_oe_i(f_io_oe), .io_core_i_o(c_io_in), .io_pad_o(p_io), .io_pad_oe_o(p_io_oe),
    .io_pad_i(p_io_in), .status_i(jtag_status), .ir_o(tap_ir), .bsr_ext_o(bsr_ext));

  // =================================================================== output pads
  sf_io_pad_out #(.DRIVE(4)) u_pad_PLATFORM_READY (.pad(PLATFORM_READY), .c2p_i(p_out[BSRO_PLATFORM_READY]), .c2p_en_i(p_oe[BSRO_PLATFORM_READY]));
  sf_io_pad_out #(.DRIVE(4)) u_pad_DEVICE_READY   (.pad(DEVICE_READY),   .c2p_i(p_out[BSRO_DEVICE_READY]),   .c2p_en_i(p_oe[BSRO_DEVICE_READY]));
  sf_io_pad_out #(.DRIVE(4)) u_pad_TEST_DONE      (.pad(TEST_DONE),      .c2p_i(p_out[BSRO_TEST_DONE]),      .c2p_en_i(p_oe[BSRO_TEST_DONE]));
  sf_io_pad_out #(.DRIVE(4)) u_pad_TEST_FAIL      (.pad(TEST_FAIL),      .c2p_i(p_out[BSRO_TEST_FAIL]),      .c2p_en_i(p_oe[BSRO_TEST_FAIL]));
  sf_io_pad_tri #(.DRIVE(4)) u_pad_RAS_FATAL_N    (.pad(RAS_FATAL_N),    .c2p_i(p_out[BSRO_RAS_FATAL_N]),    .c2p_en_i(p_oe[BSRO_RAS_FATAL_N]));
  sf_io_pad_out #(.DRIVE(4)) u_pad_UART_TX        (.pad(UART_TX),        .c2p_i(p_out[BSRO_UART_TX]),        .c2p_en_i(p_oe[BSRO_UART_TX]));
  sf_io_pad_out #(.DRIVE(4)) u_pad_MSPI_SCK       (.pad(MSPI_SCK),       .c2p_i(p_out[BSRO_MSPI_SCK]),       .c2p_en_i(p_oe[BSRO_MSPI_SCK]));
  sf_io_pad_out #(.DRIVE(4)) u_pad_MSPI_MOSI      (.pad(MSPI_MOSI),      .c2p_i(p_out[BSRO_MSPI_MOSI]),      .c2p_en_i(p_oe[BSRO_MSPI_MOSI]));
  sf_io_pad_out #(.DRIVE(4)) u_pad_MSPI_CS_N      (.pad(MSPI_CS_N),      .c2p_i(p_out[BSRO_MSPI_CS_N]),      .c2p_en_i(p_oe[BSRO_MSPI_CS_N]));
  sf_io_pad_tri #(.DRIVE(4)) u_pad_HOST_MISO      (.pad(HOST_MISO),      .c2p_i(p_out[BSRO_HOST_MISO]),      .c2p_en_i(p_oe[BSRO_HOST_MISO]));
  sf_io_pad_tri #(.DRIVE(4)) u_pad_HOST_IRQ_N     (.pad(HOST_IRQ_N),     .c2p_i(p_out[BSRO_HOST_IRQ_N]),     .c2p_en_i(p_oe[BSRO_HOST_IRQ_N]));
  sf_io_pad_tri #(.DRIVE(4)) u_pad_TDO            (.pad(TDO),            .c2p_i(tdo_c),                      .c2p_en_i(tdo_oe_c));
  for (genvar i = 0; i < 8; i++) begin : g_pad_GPIO
    sf_io_pad_bidir #(.DRIVE(4)) u_pad (.pad(GPIO[i]), .c2p_i(p_io[BSRB_GPIO + i]), .c2p_en_i(p_io_oe[BSRB_GPIO + i]),
                                        .p2c_o(p_io_in[BSRB_GPIO + i]));
  end

  // =================================================================== supply pads (scripts/pin_assign.py)
`include "sf_io_supply_pads.svh"

  wire unused_ok = &{1'b0, br_clk_unused, br_ce_unused, br_rst_unused, mc_rst_unused, br_q_unused, mc_ready_unused,
                     die_tdo_unused, die_tdo_oe_unused, pcie_bar_rsp_unused, pcie_dma_req_unused, pcie_msi_unused,
                     pcie_req_valid, pcie_req_write, pcie_req_addr, pcie_req_wdata, pcie_req_wstrb, pcie_rsp_ready,
                     mem_phy_st, hl_busy, split_refused, split_fenced, irq_status, tap_ir, bsr_ext, trst_raw};

endmodule

`default_nettype wire
