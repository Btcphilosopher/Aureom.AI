// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: sf_io_jtag -- shell TAP + boundary scan
// Aureom.AI | SilicaFlux-HPC
//
// TestCore (Project 07) tc_tap and tc_bsr, vendored UNMODIFIED, wired to the
// shell's pad wrappers.  P31 refused TESTCORE_EN because tc_top owns the clock
// root; tc_tap + tc_bsr own no clock and run on TCK only, so the shell can use
// them without changing the die's clocking.
//
//   IR (5 bits, tc_spec_pkg)        DR                       pads
//   EXTEST          0x00            BSR (61 cells)           driven from the BSR update stage
//   SAMPLE/PRELOAD  0x01            BSR                      functional
//   IDCODE          0x02 (reset)    IDCODE {VER,0x5F10,MFG*,1}
//   CLAMP           0x03            BYPASS                   driven from the BSR update stage
//   HIGHZ           0x04            BYPASS                   every BSR-controlled driver disabled
//   TC_STATUS       0x08            SHELL_STATUS (32)        functional
//   TC_MODE/UNLOCK/REG 0x09-0x0B    1-bit, captures 0        functional  (TestCore private DRs
//                                                            are not implemented in the shell)
//   BYPASS 0x1F and every other code  BYPASS
//   * IDCODE manufacturer field is TestCore's placeholder (JEP106 code not assigned).
// SHELL_STATUS: status_i is asynchronous to TCK; each bit passes a 2-flop
// synchroniser and is captured in Capture-DR.  The bits are quasi-static and
// are NOT a coherent snapshot (documented).
// TAP reset: trst_ni = TRST_N pad AND POR_N pad (tc_tap requirement).
// Everything here is TCK-domain DFT infrastructure (exclude from scan).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_io_jtag
  import tc_spec_pkg::*;
#(
  parameter int         NI             = sf_io_pkg::BSR_NUM_IN,
  parameter int         NO             = sf_io_pkg::BSR_NUM_OUT,
  parameter int         NB             = sf_io_pkg::BSR_NUM_BIDIR,
  parameter logic [3:0] IDCODE_VERSION = 4'h1
) (
  input  wire logic          tck_i,
  input  wire logic          tms_i,
  input  wire logic          tdi_i,
  input  wire logic          trst_ni,
  output logic               tdo_o,
  output logic               tdo_oe_o,
  // boundary scan: inputs are observe-only (the core always sees the pad)
  input  wire logic [NI-1:0] in_pad_i,
  input  wire logic [NO-1:0] out_core_i,
  input  wire logic [NO-1:0] out_core_oe_i,
  output logic      [NO-1:0] out_pad_o,
  output logic      [NO-1:0] out_pad_oe_o,
  input  wire logic [NB-1:0] io_core_o_i,
  input  wire logic [NB-1:0] io_core_oe_i,
  output logic      [NB-1:0] io_core_i_o,
  output logic      [NB-1:0] io_pad_o,
  output logic      [NB-1:0] io_pad_oe_o,
  input  wire logic [NB-1:0] io_pad_i,
  // shell status, asynchronous to TCK
  input  wire logic [31:0]   status_i,
  // observability
  output logic [TC_IR_LEN-1:0] ir_o,
  output logic               bsr_ext_o       // pads currently owned by boundary scan
);

  logic [3:0]           state;
  logic [TC_IR_LEN-1:0] ir;
  logic                 capture_dr, shift_dr, update_dr, tlr;
  logic                 tdo_bsr, tdo_status, tdo_dummy;

  tc_tap u_tap (
    .tck(tck_i), .trst_n(trst_ni), .tms(tms_i), .tdi(tdi_i), .tdo(tdo_o), .tdo_oe(tdo_oe_o),
    .idcode_version_i(IDCODE_VERSION), .state_o(state), .ir_o(ir),
    .capture_dr_o(capture_dr), .shift_dr_o(shift_dr), .update_dr_o(update_dr), .tlr_o(tlr),
    .tdo_bsr_i(tdo_bsr), .tdo_status_i(tdo_status), .tdo_mode_i(tdo_dummy),
    .tdo_unlock_i(tdo_dummy), .tdo_reg_i(tdo_dummy));

  // ------------------------------------------------------------------ instruction decode
  wire sel_bsr  = (ir == TC_IR_EXTEST) || (ir == TC_IR_SAMPLE_PRELOAD);
  wire ext_mode = (ir == TC_IR_EXTEST) || (ir == TC_IR_CLAMP);
  wire highz    = (ir == TC_IR_HIGHZ);
  assign ir_o      = ir;
  assign bsr_ext_o = ext_mode || highz;

  logic [NI-1:0] in_core_unused;
  tc_bsr #(.NUM_IN(NI), .NUM_OUT(NO), .NUM_BIDIR(NB)) u_bsr (
    .tck(tck_i), .trst_n(trst_ni), .tdi(tdi_i), .tdo(tdo_bsr), .sel(sel_bsr),
    .capture_dr(capture_dr), .shift_dr(shift_dr), .update_dr(update_dr),
    .ext_mode(ext_mode), .highz(highz),
    .in_pad_i(in_pad_i), .in_core_o(in_core_unused),
    .out_core_i(out_core_i), .out_core_oe_i(out_core_oe_i), .out_pad_o(out_pad_o), .out_pad_oe_o(out_pad_oe_o),
    .io_core_o_i(io_core_o_i), .io_core_oe_i(io_core_oe_i), .io_core_i_o(io_core_i_o),
    .io_pad_o(io_pad_o), .io_pad_oe_o(io_pad_oe_o), .io_pad_i(io_pad_i));

  // ------------------------------------------------------------------ SHELL_STATUS DR (IR TC_STATUS)
  logic [31:0] st_m, st_s, st_sh;
  always_ff @(posedge tck_i or negedge trst_ni) begin
    if (!trst_ni) {st_s, st_m} <= '0;
    else          {st_s, st_m} <= {st_m, status_i};
  end
  wire sel_st = (ir == TC_IR_TC_STATUS);
  always_ff @(posedge tck_i or negedge trst_ni) begin
    if (!trst_ni)                st_sh <= '0;
    else if (capture_dr && sel_st) st_sh <= st_s;
    else if (shift_dr && sel_st)   st_sh <= {tdi_i, st_sh[31:1]};
  end
  assign tdo_status = st_sh[0];

  // ------------------------------------------------------------------ TestCore private DRs: 1-bit, BYPASS-like
  logic dummy_q;
  always_ff @(posedge tck_i or negedge trst_ni) begin
    if (!trst_ni)        dummy_q <= 1'b0;
    else if (capture_dr) dummy_q <= 1'b0;
    else if (shift_dr)   dummy_q <= tdi_i;
  end
  assign tdo_dummy = dummy_q;

  wire unused_ok = &{1'b0, state, update_dr, tlr, in_core_unused};

endmodule

`default_nettype wire
