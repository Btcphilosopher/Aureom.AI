// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: sf_io_strap_latch -- POR strap latch
// Aureom.AI | SilicaFlux-HPC
//
// Transparent while por_ni is low, holds from POR release on.  Used for the
// BOOT_MODE straps (TEST_MODE has the same latch inside sf_io_pad_test).  An
// intentional latch: no clock exists during POR.  The held value is static in
// mission mode; consumers that need it in a clock domain synchronise it (the
// ControlCore synchronises boot_mode_i).
// Classification: SYNTHESIZABLE (intentional latch)
// =============================================================================
`default_nettype none

module sf_io_strap_latch #(parameter int W = 1) (
  input  wire logic         por_ni,
  input  wire logic [W-1:0] d_i,
  output logic      [W-1:0] q_o
);
  /* verilator lint_off COMBDLY */
  always_latch begin
    if (!por_ni) q_o <= d_i;
  end
  /* verilator lint_on COMBDLY */
endmodule

`default_nettype wire
