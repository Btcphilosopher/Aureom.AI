// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: sf_io_die_core -- the die inside the shell
// Aureom.AI | SilicaFlux-HPC
//
// Fixed-port wrapper around the P31 die (vendored UNMODIFIED): DIE_CFG selects
// P31's own configuration wrappers silicaflux_die_min (0) / silicaflux_die_hpc (1).
// The port list does not depend on the configuration (MC_AW is fixed by the
// 64 MiB external-memory window of silicaflux_die_pkg), so this module is also
// the black-box boundary of the physical (pad-ring) netlist: scripts/synth_phys.py
// replaces it by an abstract macro.
// Classification: SYNTHESIZABLE (wrapper)
// =============================================================================
`include "sf_io_defs.svh"
`default_nettype none

module sf_io_die_core #(
  parameter int DIE_CFG = 1,                 // 0 = SILICAFLUX_MIN, 1 = SILICAFLUX_HPC
  localparam int MC_AW  = 26,
  localparam int MC_TW  = 2
) (
  input  wire logic             clk_i,
  input  wire logic             por_ni,
  input  wire logic             pll_lock_i,
  input  wire logic             test_mode_i,
  input  wire logic [1:0]       boot_mode_i,
  input  wire logic             host_rst_req_i,
  input  wire logic             host_req_valid_i,
  output logic                  host_req_ready_o,
  input  wire logic             host_req_write_i,
  input  wire logic [31:0]      host_req_addr_i,
  input  wire logic [31:0]      host_req_wdata_i,
  input  wire logic [3:0]       host_req_wstrb_i,
  output logic                  host_rsp_valid_o,
  input  wire logic             host_rsp_ready_i,
  output logic [31:0]           host_rsp_rdata_o,
  output logic                  host_rsp_error_o,
  output logic                  host_irq_o,
  output logic                  platform_ready_o,
  output logic                  device_ready_o,
  input  wire logic             mc_clk_i,
  output logic                  mc_rst_no,
  input  wire logic             mc_init_done_i,
  input  wire logic             mc_fatal_i,
  output logic                  mc_cmd_valid_o,
  input  wire logic             mc_cmd_ready_i,
  output logic                  mc_cmd_write_o,
  output logic [MC_AW-1:0]      mc_cmd_addr_o,
  output logic [7:0]            mc_cmd_len_o,
  output logic [MC_TW-1:0]      mc_cmd_tag_o,
  output logic                  mc_wd_valid_o,
  input  wire logic             mc_wd_ready_i,
  output logic [31:0]           mc_wd_data_o,
  output logic [3:0]            mc_wd_strb_o,
  output logic                  mc_wd_last_o,
  input  wire logic             mc_rd_valid_i,
  output logic                  mc_rd_ready_o,
  input  wire logic [31:0]      mc_rd_data_i,
  input  wire logic [MC_TW-1:0] mc_rd_tag_i,
  input  wire logic             mc_rd_last_i,
  input  wire logic             mc_rd_error_i,
  input  wire logic             mc_wr_valid_i,
  output logic                  mc_wr_ready_o,
  input  wire logic [MC_TW-1:0] mc_wr_tag_i,
  input  wire logic             mc_wr_error_i,
  input  wire logic             tck_i,
  input  wire logic             tms_i,
  input  wire logic             tdi_i,
  input  wire logic             trst_ni,
  output logic                  tdo_o,
  output logic                  tdo_oe_o,
  input  wire logic             ext_warn_i,
  input  wire logic             ext_fatal_i,
  output logic                  ras_fatal_o,
  output logic                  diag_valid_o,
  output logic [7:0]            diag_char_o,
  output logic                  test_done_o,
  output logic                  test_fail_o,
  output logic [15:0]           test_code_o,
  output logic                  cpu_sleep_o
);

`define SF_IO_DIE_PORTS \
    .clk_i, .por_ni, .pll_lock_i, .test_mode_i, .boot_mode_i, .host_rst_req_i, \
    .host_req_valid_i, .host_req_ready_o, .host_req_write_i, .host_req_addr_i, .host_req_wdata_i, .host_req_wstrb_i, \
    .host_rsp_valid_o, .host_rsp_ready_i, .host_rsp_rdata_o, .host_rsp_error_o, .host_irq_o, .platform_ready_o, .device_ready_o, \
    .mc_clk_i, .mc_rst_no, .mc_init_done_i, .mc_fatal_i, .mc_cmd_valid_o, .mc_cmd_ready_i, .mc_cmd_write_o, .mc_cmd_addr_o, \
    .mc_cmd_len_o, .mc_cmd_tag_o, .mc_wd_valid_o, .mc_wd_ready_i, .mc_wd_data_o, .mc_wd_strb_o, .mc_wd_last_o, \
    .mc_rd_valid_i, .mc_rd_ready_o, .mc_rd_data_i, .mc_rd_tag_i, .mc_rd_last_i, .mc_rd_error_i, \
    .mc_wr_valid_i, .mc_wr_ready_o, .mc_wr_tag_i, .mc_wr_error_i, \
    .tck_i, .tms_i, .tdi_i, .trst_ni, .tdo_o, .tdo_oe_o, .ext_warn_i, .ext_fatal_i, .ras_fatal_o, \
    .diag_valid_o, .diag_char_o, .test_done_o, .test_fail_o, .test_code_o, .cpu_sleep_o

  if (DIE_CFG == 0) begin : g_min
    silicaflux_die_min u_die (`SF_IO_DIE_PORTS);
  end else if (DIE_CFG == 1) begin : g_hpc
    silicaflux_die_hpc u_die (`SF_IO_DIE_PORTS);
  end else begin : g_bad
    `SF_IO_ELAB_FATAL("sf_io_die_core: DIE_CFG must be 0 (MIN) or 1 (HPC)")
  end
`undef SF_IO_DIE_PORTS

endmodule

`default_nettype wire
