// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: sf_io_spi_host -- low-speed host-command link
// Aureom.AI | SilicaFlux-HPC
//
// SPI target (mode 0, MSB first) -> SFB2 master.  The low-pin-count transport of
// the die's host-command port for milestone A (PCIe is a gated milestone).
// Protocol and codes: docs/generated/REGISTERS.md (from config/io_inventory.yaml).
//
// Sampling: HOST_SCK / HOST_CS_N / HOST_MOSI are asynchronous and are
// OVERSAMPLED in clk (2-flop synchronisers); SCK is never used as a clock, so
// there is no SCK clock domain and no CDC beyond the synchronisers.
// Requirement: f_SCK <= f_clk / 8 and CS_N low >= 4 clk cycles before the first
// SCK edge.  Two detected SCK edges closer than MIN_HALF clk cycles set the
// SPEED error and suppress any bus transaction for the rest of the frame.
//
// Frame:  CS_N falls -> MISO shows SYNC (0x5A) during the command byte.
//   READ   0x0B A3 A2 A1 A0          | poll 0x00.. STATUS D3 D2 D1 D0
//   WRITE  0x02 A3..A0 STRB D3..D0   | poll 0x00.. STATUS
//   RESULT 0x0D                      | poll 0x00.. STATUS D3..D0 (last transaction)
//   STATUS 0x05                      | LINK_STAT LINK_ERR
//   CLRERR 0x06                      | 0x80
//   ID     0x9F                      | 0x53 0x46 0x49 0x4F
//   RESET  0xA5 KEY                  | 0x80 (KEY ok: host_rst_req pulse) / 0x82
// A transaction, once launched, always completes on SFB2 (a request is never
// withdrawn, SFB2 R2); if CS_N rises first, its result is kept for RESULT.
// One transaction at a time: a launch while busy answers BUSY_ERR, no launch.
// Errors (sticky, SHELL.LINK_STATUS): FRAME (CS_N rose inside a byte or before
// the arguments were complete), SPEED, CMD (unknown command, bad argument, bad
// key, RESULT with nothing to report), BUSY, BUS (rsp_error).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_io_spi_host
  import sf_io_pkg::*;
#(
  parameter int MIN_HALF = HL_MIN_HALF
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // pads (asynchronous)
  input  wire logic        sck_i,
  input  wire logic        cs_ni,
  input  wire logic        mosi_i,
  output logic             miso_o,
  output logic             miso_oe_o,
  // SFB2 master (host-command path)
  output logic             m_req_valid,
  input  wire logic        m_req_ready,
  output logic             m_req_write,
  output logic [31:0]      m_req_addr,
  output logic [31:0]      m_req_wdata,
  output logic [3:0]       m_req_wstrb,
  input  wire logic        m_rsp_valid,
  output logic             m_rsp_ready,
  input  wire logic [31:0] m_rsp_rdata,
  input  wire logic        m_rsp_error,
  // link status inputs (LINK_STAT bits 7,6,5,2,1)
  input  wire logic        platform_ready_i,
  input  wire logic        device_ready_i,
  input  wire logic        irq_i,
  input  wire logic        die_in_reset_i,
  input  wire logic        crt_ready_i,
  // die host reset request
  output logic             host_rst_req_o,
  // errors / counters
  output logic [4:0]       err_o,
  input  wire logic [4:0]  err_clr_i,
  input  wire logic        cnt_clr_i,
  output logic [15:0]      good_frames_o,
  output logic [15:0]      bad_frames_o,
  output logic             busy_o
);

  localparam int E_FRAME = 0, E_SPEED = 1, E_CMD = 2, E_BUSY = 3, E_BUS = 4;

  // ------------------------------------------------------------------ synchronisers
  logic sck_s, cs_s, mosi_s, sck_q, cs_q;
  sfv_sync #(.STAGES(2), .RESET_VAL(1'b0)) u_sy_sck  (.clk, .rst_n, .d(sck_i),  .q(sck_s));
  sfv_sync #(.STAGES(2), .RESET_VAL(1'b1)) u_sy_cs   (.clk, .rst_n, .d(cs_ni),  .q(cs_s));
  sfv_sync #(.STAGES(2), .RESET_VAL(1'b0)) u_sy_mosi (.clk, .rst_n, .d(mosi_i), .q(mosi_s));
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin sck_q <= 1'b0; cs_q <= 1'b1; end
    else        begin sck_q <= sck_s; cs_q <= cs_s; end
  end
  wire active  = !cs_s;
  wire f_start = cs_q && !cs_s;
  wire f_end   = !cs_q && cs_s;
  wire rise    = active && !cs_q && sck_s && !sck_q;     // edges inside a frame only
  wire fall    = active && !cs_q && !sck_s && sck_q;

  // ------------------------------------------------------------------ frame state
  typedef enum logic [3:0] {
    P_CMD, P_ADDR, P_STRB, P_DATA, P_KEY, P_POLL, P_RESP, P_STAT, P_ID, P_OUT, P_DONE
  } phase_e;
  phase_e      phase;
  logic [7:0]  cmd_q;
  logic [7:0]  rx_sh;
  logic [2:0]  rx_bit;
  logic [2:0]  tx_bit;
  logic [7:0]  tx_sh;
  logic [1:0]  arg_cnt;
  logic [31:0] addr_q, data_q;
  logic [3:0]  strb_q;
  logic [7:0]  resp_code;
  logic [31:0] out_sh;
  logic [2:0]  out_cnt;
  logic [7:0]  half_cnt;
  logic        seen_edge, frame_bad, frame_err_now;
  logic [4:0]  err_q, err_frame;

  // transaction / result
  logic        busy_q, res_valid_q, res_read_q;
  logic [7:0]  res_code_q;
  logic [31:0] res_rdata_q;
  logic        launch;            // pulse: start a transaction with addr_q / data_q / strb_q / cmd_q
  logic        launch_write;
  logic [2:0]  rst_req_cnt;

  wire [7:0] rx_byte = {rx_sh[6:0], mosi_s};
  wire       byte_rx = rise && (rx_bit == 3'd7);
  wire       byte_tx = fall && (tx_bit == 3'd7);
  wire       speed_viol = (rise || fall) && seen_edge && (32'(half_cnt) + 1 < MIN_HALF);

  wire [7:0] link_stat = {platform_ready_i, device_ready_i, irq_i, res_valid_q, busy_q, die_in_reset_i, crt_ready_i, 1'b1};

  // next MISO byte, chosen at a byte boundary (falling edge that ends a byte)
  logic [7:0]  tx_next;
  phase_e      phase_tx;
  logic [31:0] out_next;
  logic [2:0]  out_cnt_next;
  always_comb begin
    tx_next      = 8'h00;
    phase_tx     = phase;
    out_next     = out_sh;
    out_cnt_next = out_cnt;
    unique case (phase)
      P_POLL: if (res_valid_q && !busy_q && !launch) begin
                tx_next = res_code_q;
                if (res_read_q) begin out_next = res_rdata_q; out_cnt_next = 3'd4; phase_tx = P_OUT; end
                else phase_tx = P_DONE;
              end
      P_RESP: begin tx_next = resp_code; phase_tx = P_DONE; end
      P_STAT: begin tx_next = link_stat; out_next = {3'b000, err_q, 24'd0}; out_cnt_next = 3'd1; phase_tx = P_OUT; end
      P_ID:   begin tx_next = HL_ID[31:24]; out_next = {HL_ID[23:0], 8'd0}; out_cnt_next = 3'd3; phase_tx = P_OUT; end
      P_OUT:  begin
                tx_next = out_sh[31:24]; out_next = {out_sh[23:0], 8'd0}; out_cnt_next = out_cnt - 3'd1;
                if (out_cnt == 3'd1) phase_tx = P_DONE;
              end
      default: ;
    endcase
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      phase <= P_CMD; cmd_q <= '0; rx_sh <= '0; rx_bit <= '0; tx_bit <= '0; tx_sh <= HL_SYNC;
      arg_cnt <= '0; addr_q <= '0; data_q <= '0; strb_q <= '0; resp_code <= '0;
      out_sh <= '0; out_cnt <= '0; half_cnt <= '0; seen_edge <= 1'b0; frame_bad <= 1'b0;
      err_frame <= '0; launch <= 1'b0; launch_write <= 1'b0; rst_req_cnt <= '0;
    end else begin
      launch <= 1'b0;
      if (rst_req_cnt != 0) rst_req_cnt <= rst_req_cnt - 3'd1;
      // ---------------- edge spacing (speed) monitor
      if (rise || fall) begin half_cnt <= '0; seen_edge <= 1'b1; end
      else if (half_cnt != 8'hFF) half_cnt <= half_cnt + 8'd1;
      if (speed_viol) begin frame_bad <= 1'b1; err_frame[E_SPEED] <= 1'b1; end

      if (f_start) begin
        phase <= P_CMD; rx_bit <= '0; tx_bit <= '0; tx_sh <= HL_SYNC; arg_cnt <= '0;
        seen_edge <= 1'b0; half_cnt <= '0; frame_bad <= 1'b0; err_frame <= '0;
      end
      // ---------------- receive (rising edge)
      if (rise) begin
        rx_sh  <= rx_byte;
        rx_bit <= rx_bit + 3'd1;
      end
      if (byte_rx && !speed_viol && !frame_bad) begin
        unique case (phase)
          P_CMD: begin
            cmd_q   <= rx_byte;
            arg_cnt <= '0;
            unique case (rx_byte)
              HL_CMD_READ, HL_CMD_WRITE: phase <= P_ADDR;
              HL_CMD_RESULT: if (busy_q || res_valid_q) phase <= P_POLL;
                             else begin phase <= P_RESP; resp_code <= HL_ST_CMD_ERR; err_frame[E_CMD] <= 1'b1; end
              HL_CMD_STATUS: phase <= P_STAT;
              HL_CMD_CLRERR: begin phase <= P_RESP; resp_code <= HL_ST_OK; end
              HL_CMD_ID:     phase <= P_ID;
              HL_CMD_RESET:  phase <= P_KEY;
              default: begin phase <= P_RESP; resp_code <= HL_ST_CMD_ERR; err_frame[E_CMD] <= 1'b1; end
            endcase
          end
          P_ADDR: begin
            addr_q  <= {addr_q[23:0], rx_byte};
            arg_cnt <= arg_cnt + 2'd1;
            if (arg_cnt == 2'd3) begin
              if (cmd_q == HL_CMD_WRITE) phase <= P_STRB;
              else if (busy_q) begin phase <= P_RESP; resp_code <= HL_ST_BUSY_ERR; err_frame[E_BUSY] <= 1'b1; end
              else begin phase <= P_POLL; launch <= 1'b1; launch_write <= 1'b0; end
            end
          end
          P_STRB: begin
            if (rx_byte[7:4] != 4'd0) begin phase <= P_RESP; resp_code <= HL_ST_CMD_ERR; err_frame[E_CMD] <= 1'b1; end
            else begin strb_q <= rx_byte[3:0]; phase <= P_DATA; arg_cnt <= '0; end
          end
          P_DATA: begin
            data_q  <= {data_q[23:0], rx_byte};
            arg_cnt <= arg_cnt + 2'd1;
            if (arg_cnt == 2'd3) begin
              if (busy_q) begin phase <= P_RESP; resp_code <= HL_ST_BUSY_ERR; err_frame[E_BUSY] <= 1'b1; end
              else begin phase <= P_POLL; launch <= 1'b1; launch_write <= 1'b1; end
            end
          end
          P_KEY: begin
            phase <= P_RESP;
            if (rx_byte == HL_RESET_KEY) begin resp_code <= HL_ST_OK; rst_req_cnt <= 3'd4; end
            else begin resp_code <= HL_ST_CMD_ERR; err_frame[E_CMD] <= 1'b1; end
          end
          default: ;  // P_POLL / P_RESP / P_STAT / P_ID / P_OUT / P_DONE: dummy bytes
        endcase
      end
      // ---------------- transmit (falling edge)
      if (fall) begin
        tx_bit <= tx_bit + 3'd1;
        if (byte_tx) begin
          tx_sh   <= tx_next;
          phase   <= phase_tx;
          out_sh  <= out_next;
          out_cnt <= out_cnt_next;
        end else begin
          tx_sh <= {tx_sh[6:0], 1'b0};
        end
      end
      // ---------------- frame end: truncated frame?
      if (f_end) begin
        phase <= P_CMD;
        tx_sh <= HL_SYNC;
        if (frame_err_now) err_frame[E_FRAME] <= 1'b1;
      end
    end
  end

  // truncated: inside a byte, or inside the argument phase
  assign frame_err_now = (rx_bit != 3'd0) ||
                         (phase == P_ADDR) || (phase == P_STRB) || (phase == P_DATA) || (phase == P_KEY);

  assign miso_o    = tx_sh[7];
  assign miso_oe_o = active;
  assign host_rst_req_o = (rst_req_cnt != 0);

  // ------------------------------------------------------------------ SFB2 master: one transaction at a time
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      m_req_valid <= 1'b0; m_req_write <= 1'b0; m_req_addr <= '0; m_req_wdata <= '0; m_req_wstrb <= '0;
      busy_q <= 1'b0; res_valid_q <= 1'b0; res_read_q <= 1'b0; res_code_q <= '0; res_rdata_q <= '0;
    end else begin
      if (launch) begin
        m_req_valid <= 1'b1;
        m_req_write <= launch_write;
        m_req_addr  <= addr_q;
        m_req_wdata <= launch_write ? data_q : 32'd0;
        m_req_wstrb <= launch_write ? strb_q : 4'd0;
        busy_q      <= 1'b1;
        res_valid_q <= 1'b0;
        res_read_q  <= !launch_write;
      end else if (m_req_valid && m_req_ready) begin
        m_req_valid <= 1'b0;
      end
      if (busy_q && m_rsp_valid) begin
        busy_q      <= 1'b0;
        res_valid_q <= 1'b1;
        res_code_q  <= m_rsp_error ? HL_ST_BUS_ERR : HL_ST_OK;
        res_rdata_q <= m_rsp_error ? 32'd0 : m_rsp_rdata;
      end
    end
  end
  assign m_rsp_ready = 1'b1;
  assign busy_o      = busy_q;

  // ------------------------------------------------------------------ sticky errors, frame counters
  // Frame-level errors (CMD, BUSY, SPEED, FRAME) are committed when CS_N rises;
  // BUS is committed when the response arrives (it may outlive the frame).
  wire bus_err_evt = busy_q && m_rsp_valid && m_rsp_error;
  wire clrerr_evt  = byte_rx && !speed_viol && !frame_bad && (phase == P_CMD) && (rx_byte == HL_CMD_CLRERR);
  logic [4:0] err_nxt;
  always_comb begin
    err_nxt = err_q & ~err_clr_i;
    if (clrerr_evt)  err_nxt = '0;
    if (bus_err_evt) err_nxt[E_BUS] = 1'b1;
    if (f_end)       err_nxt = err_nxt | err_frame | {4'd0, frame_err_now};
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      err_q <= '0; good_frames_o <= '0; bad_frames_o <= '0;
    end else begin
      err_q <= err_nxt;
      if (cnt_clr_i) begin
        good_frames_o <= '0; bad_frames_o <= '0;
      end else if (f_end) begin
        if ((err_frame != 0) || frame_err_now) begin
          if (bad_frames_o != 16'hFFFF) bad_frames_o <= bad_frames_o + 16'd1;
        end else if (good_frames_o != 16'hFFFF) good_frames_o <= good_frames_o + 16'd1;
      end
    end
  end
  assign err_o = err_q;
  wire unused_ok = rx_sh[7];

endmodule

`default_nettype wire
