// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: sf_io_host_split -- host-command router
// Aureom.AI | SilicaFlux-HPC
//
// One SFB2 slave (the host-command transport: SPI link today, PCIe HostLink in
// the gated milestone) -> two SFB2 masters:
//   shell window 0x5000_0000..0x5000_FFFF -> sf_io_mgmt
//   everything else                        -> die host port (P31 host_io_subsystem
//                                             decodes it further; unmapped -> error)
// One transaction at a time (like P31's host bridge), so ordering across the
// two paths is trivially preserved.
//
// Die protection
//   * readiness: die-bound requests are answered locally with an error while the
//     die is not ready (PLATFORM_READY low or die reset asserted) -- never left
//     waiting on a port that is held in reset.  SHELL.CTRL.DIE_FORCE lifts the
//     PLATFORM_READY condition (bring-up / diagnosis), never the reset condition;
//   * reset fence: if the die reset asserts while a die-bound transaction is
//     outstanding, the transaction is completed locally with an error.  The die
//     port is in reset, so no late response can follow.  die_rst_ni is an
//     asynchronously asserted reset: it is synchronised (2 flops) before use;
//   * quiesce (P35 fab_quiesce_o): no new request is accepted; idle_o reports
//     that nothing is outstanding (P35 fab_idle_i) for graceful software resets.
// Error responses carry rdata = 0 (SFB2 R8).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_io_host_split
  import sf_io_pkg::*;
(
  input  wire logic        clk,
  input  wire logic        rst_n,
  // upstream (slave)
  input  wire logic        s_req_valid,
  output logic             s_req_ready,
  input  wire logic        s_req_write,
  input  wire logic [31:0] s_req_addr,
  input  wire logic [31:0] s_req_wdata,
  input  wire logic [3:0]  s_req_wstrb,
  output logic             s_rsp_valid,
  input  wire logic        s_rsp_ready,
  output logic [31:0]      s_rsp_rdata,
  output logic             s_rsp_error,
  // shell window (master)
  output logic             sh_req_valid,
  input  wire logic        sh_req_ready,
  output logic             sh_req_write,
  output logic [31:0]      sh_req_addr,
  output logic [31:0]      sh_req_wdata,
  output logic [3:0]       sh_req_wstrb,
  input  wire logic        sh_rsp_valid,
  output logic             sh_rsp_ready,
  input  wire logic [31:0] sh_rsp_rdata,
  input  wire logic        sh_rsp_error,
  // die host port (master)
  output logic             die_req_valid,
  input  wire logic        die_req_ready,
  output logic             die_req_write,
  output logic [31:0]      die_req_addr,
  output logic [31:0]      die_req_wdata,
  output logic [3:0]       die_req_wstrb,
  input  wire logic        die_rsp_valid,
  output logic             die_rsp_ready,
  input  wire logic [31:0] die_rsp_rdata,
  input  wire logic        die_rsp_error,
  // control / status
  input  wire logic        die_platform_ready_i,
  input  wire logic        die_force_i,          // SHELL.CTRL.DIE_FORCE (bring-up override)
  input  wire logic        die_rst_ni,           // die reset (asynchronous assert)
  input  wire logic        quiesce_i,
  output logic             idle_o,
  output logic             die_in_reset_o,       // synchronised
  output logic [15:0]      refused_o,            // die-bound requests answered locally (saturating)
  output logic [15:0]      fenced_o              // die transactions cut by a die reset (saturating)
);

  typedef enum logic [2:0] {S_IDLE, S_SHELL, S_DIE, S_RESP} st_e;
  st_e         st;
  logic        req_w;
  logic [31:0] req_a, req_d;
  logic [3:0]  req_s;
  logic        rsp_err;
  logic [31:0] rsp_dat;
  logic        presented;          // request still being presented downstream

  // die reset synchroniser (assert asynchronously visible after 2 clk)
  logic die_rst_m, die_rst_s;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) {die_rst_s, die_rst_m} <= 2'b00;
    else        {die_rst_s, die_rst_m} <= {die_rst_m, die_rst_ni};
  end
  assign die_in_reset_o = !die_rst_s;
  wire die_ok = die_rst_s && (die_platform_ready_i || die_force_i);

  wire in_shell = (s_req_addr & ~(SHELL_SIZE - 32'd1)) == SHELL_BASE;
  assign s_req_ready = (st == S_IDLE) && !quiesce_i;
  wire   accept      = s_req_valid && s_req_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; req_w <= 1'b0; req_a <= '0; req_d <= '0; req_s <= '0;
      rsp_err <= 1'b0; rsp_dat <= '0; presented <= 1'b0; refused_o <= '0; fenced_o <= '0;
    end else begin
      unique case (st)
        S_IDLE: if (accept) begin
          req_w <= s_req_write; req_a <= s_req_addr; req_d <= s_req_wdata; req_s <= s_req_wstrb;
          if (in_shell) begin
            st <= S_SHELL; presented <= 1'b1;
          end else if (die_ok) begin
            st <= S_DIE; presented <= 1'b1;
          end else begin
            st <= S_RESP; rsp_err <= 1'b1; rsp_dat <= '0;
            if (refused_o != 16'hFFFF) refused_o <= refused_o + 16'd1;
          end
        end
        S_SHELL: begin
          if (presented && sh_req_ready) presented <= 1'b0;
          if (sh_rsp_valid) begin
            st <= S_RESP; rsp_err <= sh_rsp_error; rsp_dat <= sh_rsp_error ? 32'd0 : sh_rsp_rdata;
          end
        end
        S_DIE: begin
          if (!die_rst_s) begin                              // reset fence
            st <= S_RESP; rsp_err <= 1'b1; rsp_dat <= '0; presented <= 1'b0;
            if (fenced_o != 16'hFFFF) fenced_o <= fenced_o + 16'd1;
          end else begin
            if (presented && die_req_ready) presented <= 1'b0;
            if (die_rsp_valid) begin
              st <= S_RESP; rsp_err <= die_rsp_error; rsp_dat <= die_rsp_error ? 32'd0 : die_rsp_rdata;
            end
          end
        end
        S_RESP: if (s_rsp_ready) begin st <= S_IDLE; rsp_err <= 1'b0; rsp_dat <= '0; end
        default: st <= S_IDLE;
      endcase
    end
  end

  assign sh_req_valid  = (st == S_SHELL) && presented;
  assign sh_req_write  = req_w;
  assign sh_req_addr   = req_a;
  assign sh_req_wdata  = req_d;
  assign sh_req_wstrb  = req_s;
  assign sh_rsp_ready  = (st == S_SHELL);
  assign die_req_valid = (st == S_DIE) && presented && die_rst_s;
  assign die_req_write = req_w;
  assign die_req_addr  = req_a;
  assign die_req_wdata = req_d;
  assign die_req_wstrb = req_s;
  assign die_rsp_ready = (st == S_DIE);
  assign s_rsp_valid   = (st == S_RESP);
  assign s_rsp_rdata   = rsp_dat;
  assign s_rsp_error   = rsp_err;
  assign idle_o        = (st == S_IDLE);              // nothing outstanding (a held request is not)

endmodule

`default_nettype wire
