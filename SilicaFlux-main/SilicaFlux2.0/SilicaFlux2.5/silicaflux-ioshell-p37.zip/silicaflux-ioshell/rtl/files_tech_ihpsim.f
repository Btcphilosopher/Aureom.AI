// technology layer for SIMULATION with the IHP vendor pad models (P35 keeps its sim cells:
// its IHP layer instantiates standard cells that have no model here)
rtl/pads/tech/ihp_sg13g2/sf_io_cells_ihp.sv
third_party/ihp-sg13g2/verilog/sg13g2_io.v
third_party/silicaflux-clocktree/rtl/tech/sim/sf_crt_tech_cells.sv
