// SIMULATION-ONLY models (MEM_CTRL = SIM): P24 extmem_sim_mc + PHY status model
third_party/silicaflux-dietop/third_party/silicaflux-extmem/sim/models/extmem_sim_mc.sv
sim/sf_io_sim_mem_phy.sv
