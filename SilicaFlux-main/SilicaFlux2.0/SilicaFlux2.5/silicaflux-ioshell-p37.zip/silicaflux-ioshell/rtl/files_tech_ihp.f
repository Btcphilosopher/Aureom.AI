// technology layer: IHP SG13G2 pad cells (vendor model for simulation) + P35 IHP cells
rtl/pads/tech/ihp_sg13g2/sf_io_cells_ihp.sv
third_party/silicaflux-clocktree/rtl/tech/ihp_sg13g2/sf_crt_tech_cells.sv
