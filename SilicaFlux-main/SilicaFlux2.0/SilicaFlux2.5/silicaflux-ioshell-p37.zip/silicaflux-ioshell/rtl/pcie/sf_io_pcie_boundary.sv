// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: sf_io_pcie_boundary -- gated PCIe milestone
// Aureom.AI | SilicaFlux-HPC
//
// The slot where a licensed PCIe PHY + endpoint controller and HostLink (P25)
// meet.  Its ports are the typed endpoint interface of sf_io_pcie_pkg.
//
//   PCIE_EN = 0 (milestone A)  slot empty: no request is ever driven, link
//                              status reads "not present"; the host-command
//                              path is the SPI link only.
//   PCIE_EN = 1                needs `SF_IO_HAVE_PCIE_IP` and the vendor
//                              integration module sf_io_vendor_pcie_subsys;
//                              refused otherwise (PCIE-PHY, PCIE-CTRL).
// When enabled, HostLink's SFB2 master (df_*) becomes a second host-command
// master: the integration point is an arbiter in front of sf_io_host_split's
// upstream port (docs/04_PCIE_MILESTONE.md).  Nothing here implies a PCIe
// generation, lane rate or compliance.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_io_defs.svh"
`default_nettype none

module sf_io_pcie_boundary
  import sf_io_pcie_pkg::*;
#(
  parameter bit PCIE_EN = 1'b0
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  // endpoint controller side (user interface of the controller IP)
  input  wire pcie_bar_req_t ep_bar_req_i,
  output pcie_bar_rsp_t      ep_bar_rsp_o,
  output pcie_dma_req_t      ep_dma_req_o,
  input  wire pcie_dma_rsp_t ep_dma_rsp_i,
  output pcie_msi_req_t      ep_msi_o,
  input  wire logic          ep_msi_ready_i,
  input  wire pcie_link_t    ep_link_i,
  // host-command master towards sf_io_host_split (HostLink df_* when enabled)
  output logic               m_req_valid,
  input  wire logic          m_req_ready,
  output logic               m_req_write,
  output logic [31:0]        m_req_addr,
  output logic [31:0]        m_req_wdata,
  output logic [3:0]         m_req_wstrb,
  input  wire logic          m_rsp_valid,
  output logic               m_rsp_ready,
  input  wire logic [31:0]   m_rsp_rdata,
  input  wire logic          m_rsp_error,
  output logic               host_rst_req_o,    // PERST# / hot reset towards the die (enabled builds)
  output logic [31:0]        pcie_reg_o         // SHELL.PCIE
);

  if (!PCIE_EN) begin : g_absent
    assign ep_bar_rsp_o   = '0;
    assign ep_dma_req_o   = '0;
    assign ep_msi_o       = '0;
    assign m_req_valid    = 1'b0;
    assign m_req_write    = 1'b0;
    assign m_req_addr     = '0;
    assign m_req_wdata    = '0;
    assign m_req_wstrb    = '0;
    assign m_rsp_ready    = 1'b1;
    assign host_rst_req_o = 1'b0;
    assign pcie_reg_o     = 32'd0;              // register image of an absent link
    wire unused_ok = &{1'b0, clk, rst_n, ep_bar_req_i, ep_dma_rsp_i, ep_msi_ready_i, ep_link_i,
                       m_req_ready, m_rsp_valid, m_rsp_rdata, m_rsp_error};
  end else begin : g_present
`ifdef SF_IO_HAVE_PCIE_IP
    sf_io_vendor_pcie_subsys u_ip (.*);
`else
    `SF_IO_ELAB_FATAL("sf_io_pcie_boundary: PCIE_EN = 1 needs a licensed PCIe PHY + endpoint controller (dependencies PCIE-PHY, PCIE-CTRL): not available")
`endif
  end

endmodule

`default_nettype wire
