// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: sf_io_pcie_pkg -- PCIe endpoint boundary types
// Aureom.AI | SilicaFlux-HPC
//
// The internal PCIe endpoint interface: what a licensed PCIe endpoint controller
// exposes on its user side towards SilicaFlux HostLink (Project 25), whose
// verified "generic AXI endpoint boundary" fixes the widths:
//   BAR   : AXI4-style slave into HostLink (12-bit BAR0 offset, 32-bit data)
//   DMA   : AXI4-style master from HostLink to host memory (64-bit addr / data)
//   MSI   : interrupt request (vector) with ready
//   LINK  : link / PHY status reported by the controller + PHY
// This is a logical boundary only.  Declaring it implies no PCIe generation,
// lane rate, width or compliance: those belong to the PHY / controller IP
// (dependencies PCIE-PHY, PCIE-CTRL), which do not exist here.
// Classification: SYNTHESIZABLE (package)
// =============================================================================
`ifndef SF_IO_PCIE_PKG_SV
`define SF_IO_PCIE_PKG_SV
package sf_io_pcie_pkg;

  // controller -> HostLink (BAR0 slave requests)
  typedef struct packed {
    logic        awvalid; logic [11:0] awaddr;
    logic        wvalid;  logic [31:0] wdata;  logic [3:0] wstrb;
    logic        bready;
    logic        arvalid; logic [11:0] araddr;
    logic        rready;
  } pcie_bar_req_t;
  // HostLink -> controller (BAR0 slave responses)
  typedef struct packed {
    logic        awready; logic wready;
    logic        bvalid;  logic [1:0] bresp;
    logic        arready;
    logic        rvalid;  logic [31:0] rdata; logic [1:0] rresp;
  } pcie_bar_rsp_t;
  // HostLink -> controller (host-memory DMA master requests)
  typedef struct packed {
    logic        awvalid; logic [63:0] awaddr; logic [7:0] awlen; logic [2:0] awsize; logic [1:0] awburst; logic [3:0] awid;
    logic        wvalid;  logic [63:0] wdata;  logic [7:0] wstrb; logic wlast;
    logic        bready;
    logic        arvalid; logic [63:0] araddr; logic [7:0] arlen; logic [2:0] arsize; logic [1:0] arburst; logic [3:0] arid;
    logic        rready;
  } pcie_dma_req_t;
  // controller -> HostLink (host-memory DMA responses)
  typedef struct packed {
    logic        awready; logic wready;
    logic        bvalid;  logic [1:0] bresp; logic [3:0] bid;
    logic        arready;
    logic        rvalid;  logic [63:0] rdata; logic [1:0] rresp; logic rlast; logic [3:0] rid;
  } pcie_dma_rsp_t;
  // MSI request (HostLink -> controller) and its acceptance
  typedef struct packed { logic valid; logic [3:0] vector; } pcie_msi_req_t;
  // link / PHY status (controller + PHY -> shell).  Raw IP fields: no meaning is
  // attached to speed_code / width beyond what the selected IP documents.
  typedef struct packed {
    logic       present;     // controller + PHY instantiated
    logic       link_up;
    logic [5:0] ltssm;
    logic       perst_n;     // PCIE_PERST_N as seen by the controller
    logic       refclk_ok;
    logic       phy_ready;
    logic [2:0] speed_code;
    logic [4:0] width;
  } pcie_link_t;

  // SHELL.PCIE register image (packed by the PCIe integration, 0 while absent):
  //   {13'd0, width, speed_code, phy_ready, refclk_ok, perst_n, ltssm, link_up, present}

endpackage
`endif
