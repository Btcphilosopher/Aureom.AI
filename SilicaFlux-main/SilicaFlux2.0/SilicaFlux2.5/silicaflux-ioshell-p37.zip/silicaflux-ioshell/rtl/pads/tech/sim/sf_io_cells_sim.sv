// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: sf_io_cells_sim -- BEHAVIOURAL PAD MODELS
// Aureom.AI | SilicaFlux-HPC
//
//   *** SIMULATION ONLY.  NOT A PAD CELL.  NO ESD, NO LEVEL SHIFTING, NO DRIVE
//   *** STRENGTH, NO ELECTRICAL BEHAVIOUR OF ANY KIND. ***
//
// Technology layer "sim": the same module names and ports as the IHP SG13G2
// layer (rtl/pads/tech/ihp_sg13g2/sf_io_cells_ihp.sv), with the logical
// function of a pad only, so the shell can be simulated without vendor models.
// Compiling this file together with `SF_IO_ASIC_IMPL` (any implementation
// flow) stops elaboration: a behavioural pad must never reach a netlist that
// is mistaken for ESD-qualified silicon.
// Classification: SIMULATION ONLY
// =============================================================================
`include "sf_io_defs.svh"
`default_nettype none
/* verilator lint_off DECLFILENAME */
/* verilator lint_off UNUSEDPARAM */   // DRIVE / KIND have no meaning in a behavioural model

package sf_io_tech_pkg;
  localparam int IO_TECH = 0;            // 0 = behavioural model (sim), 1 = IHP sg13g2_io
endpackage

module sf_io_tech_guard;
`ifdef SF_IO_ASIC_IMPL
  `SF_IO_ELAB_FATAL("sf_io_cells_sim: behavioural pad models are SIMULATION ONLY and cannot be implemented (IO-LIB / IO-ESD); build with rtl/pads/tech/ihp_sg13g2")
`endif
endmodule

// input buffer: pad -> core
module sf_io_cell_in (
  input  wire logic pad,
  output wire logic p2c
);
  sf_io_tech_guard u_guard ();
  assign p2c = pad;
endmodule

// push-pull output, no enable (used only when a wrapper is built with HIGHZ_CAPABLE = 0)
module sf_io_cell_out #(parameter int DRIVE = 4) (
  output wire logic pad,
  input  wire logic c2p
);
  sf_io_tech_guard u_guard ();
  assign pad = c2p;
endmodule

// tri-state output
module sf_io_cell_tri #(parameter int DRIVE = 4) (
  output wire logic pad,
  input  wire logic c2p,
  input  wire logic c2p_en
);
  sf_io_tech_guard u_guard ();
  assign pad = c2p_en ? c2p : 1'bz;
endmodule

// bidirectional
module sf_io_cell_bidir #(parameter int DRIVE = 4) (
  inout  wire logic pad,
  input  wire logic c2p,
  input  wire logic c2p_en,
  output wire logic p2c
);
  sf_io_tech_guard u_guard ();
  assign pad = c2p_en ? c2p : 1'bz;
  assign p2c = pad;
endmodule

// supply pad: no logical function (kept for instance-count consistency)
module sf_io_cell_supply #(parameter KIND = "VDD") ();
  sf_io_tech_guard u_guard ();
endmodule

`default_nettype wire
