// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: sf_io_cells_ihp -- IHP SG13G2 pad cells
// Aureom.AI | SilicaFlux-HPC
//
// Technology layer "ihp_sg13g2": instantiates the IHP-Open-PDK sg13g2_io
// library cells (Apache-2.0; LEF / Liberty / Verilog / GDS vendored under
// third_party/ihp-sg13g2 from ORFS bfcc1895, LEF byte-identical to
// IHP-Open-PDK e73adb40).  Integration requirements honoured here:
//   * one vendor cell per pad, instance name u_cell (renamed pad_<NAME> in the
//     physical netlist by scripts/synth_phys.py);
//   * supply pads instantiated with (* keep *) and no connections: vdd / vss /
//     iovdd / iovss are ring rails joined by abutment (connect_by_abutment)
//     and global connects, exactly as the ORFS reference design does;
//   * drive strength restricted to the cells that exist (4 / 16 / 30 mA).
// The cells' electrical / ESD behaviour is the vendor's; the SilicaFlux pad
// ring itself is NOT ESD-qualified (dependency IO-ESD).
// Simulation with this layer uses the vendor's functional model
// (third_party/ihp-sg13g2/verilog/sg13g2_io.v).
// Classification: SYNTHESIZABLE (technology mapping)
// =============================================================================
`include "sf_io_defs.svh"
`default_nettype none
/* verilator lint_off DECLFILENAME */
// vdd / vss / iovdd / iovss are ring rails: joined by abutment and global connects in the
// physical flow (as in the ORFS ihp-sg13g2 reference design), never wired in RTL.
/* verilator lint_off PINMISSING */

package sf_io_tech_pkg;
  localparam int IO_TECH = 1;            // 0 = behavioural model (sim), 1 = IHP sg13g2_io
endpackage

module sf_io_cell_in (
  input  wire logic pad,
  output wire logic p2c
);
  sg13g2_IOPadIn u_cell (.pad(pad), .p2c(p2c));
endmodule

module sf_io_cell_out #(parameter int DRIVE = 4) (
  output wire logic pad,
  input  wire logic c2p
);
  if (DRIVE == 4) begin : g_cell
    sg13g2_IOPadOut4mA u_cell (.pad(pad), .c2p(c2p));
  end else if (DRIVE == 16) begin : g_cell
    sg13g2_IOPadOut16mA u_cell (.pad(pad), .c2p(c2p));
  end else if (DRIVE == 30) begin : g_cell
    sg13g2_IOPadOut30mA u_cell (.pad(pad), .c2p(c2p));
  end else begin : g_bad
    `SF_IO_ELAB_FATAL("sf_io_cell_out: sg13g2_io has 4 / 16 / 30 mA outputs only")
  end
endmodule

module sf_io_cell_tri #(parameter int DRIVE = 4) (
  output wire logic pad,
  input  wire logic c2p,
  input  wire logic c2p_en
);
  if (DRIVE == 4) begin : g_cell
    sg13g2_IOPadTriOut4mA u_cell (.pad(pad), .c2p(c2p), .c2p_en(c2p_en));
  end else if (DRIVE == 16) begin : g_cell
    sg13g2_IOPadTriOut16mA u_cell (.pad(pad), .c2p(c2p), .c2p_en(c2p_en));
  end else if (DRIVE == 30) begin : g_cell
    sg13g2_IOPadTriOut30mA u_cell (.pad(pad), .c2p(c2p), .c2p_en(c2p_en));
  end else begin : g_bad
    `SF_IO_ELAB_FATAL("sf_io_cell_tri: sg13g2_io has 4 / 16 / 30 mA outputs only")
  end
endmodule

module sf_io_cell_bidir #(parameter int DRIVE = 4) (
  inout  wire logic pad,
  input  wire logic c2p,
  input  wire logic c2p_en,
  output wire logic p2c
);
  if (DRIVE == 4) begin : g_cell
    sg13g2_IOPadInOut4mA u_cell (.pad(pad), .c2p(c2p), .c2p_en(c2p_en), .p2c(p2c));
  end else if (DRIVE == 16) begin : g_cell
    sg13g2_IOPadInOut16mA u_cell (.pad(pad), .c2p(c2p), .c2p_en(c2p_en), .p2c(p2c));
  end else if (DRIVE == 30) begin : g_cell
    sg13g2_IOPadInOut30mA u_cell (.pad(pad), .c2p(c2p), .c2p_en(c2p_en), .p2c(p2c));
  end else begin : g_bad
    `SF_IO_ELAB_FATAL("sf_io_cell_bidir: sg13g2_io has 4 / 16 / 30 mA bidirs only")
  end
endmodule

module sf_io_cell_supply #(parameter KIND = "VDD") ();
  if (KIND == "VDD") begin : g_cell
    (* keep *) sg13g2_IOPadVdd u_cell ();
  end else if (KIND == "VSS") begin : g_cell
    (* keep *) sg13g2_IOPadVss u_cell ();
  end else if (KIND == "IOVDD") begin : g_cell
    (* keep *) sg13g2_IOPadIOVdd u_cell ();
  end else if (KIND == "IOVSS") begin : g_cell
    (* keep *) sg13g2_IOPadIOVss u_cell ();
  end else begin : g_bad
    `SF_IO_ELAB_FATAL("sf_io_cell_supply: unknown supply kind")
  end
endmodule

`default_nettype wire
