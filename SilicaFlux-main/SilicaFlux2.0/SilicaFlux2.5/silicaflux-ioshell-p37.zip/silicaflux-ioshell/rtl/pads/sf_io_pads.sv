// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: sf_io_pads -- reusable logical pad wrappers
// Aureom.AI | SilicaFlux-HPC
//
// One wrapper per pad function.  Each wrapper instantiates exactly one cell of
// the technology layer selected at compile time:
//   rtl/pads/tech/sim/sf_io_cells_sim.sv          behavioural, SIMULATION ONLY
//   rtl/pads/tech/ihp_sg13g2/sf_io_cells_ihp.sv   IHP sg13g2_io vendor cells
// The wrapper names the pad's role; the cell layer decides what silicon (if
// any) implements it.  Core-side ports carry the physical-side values (after
// boundary scan): c2p / c2p_en into the pad, p2c out of it.
//
//   sf_io_pad_in      input                     sg13g2_IOPadIn
//   sf_io_pad_clk     clock input               sg13g2_IOPadIn (clock net; SDC create_clock on the port)
//   sf_io_pad_rst     reset input               sg13g2_IOPadIn (+ polarity normalisation to active low)
//   sf_io_pad_test    test-mode input           sg13g2_IOPadIn + strap latch (transparent while POR is low)
//   sf_io_pad_out     output                    sg13g2_IOPadTriOut<n>mA (HIGHZ_CAPABLE = 1) / Out<n>mA
//   sf_io_pad_tri     tri-state output          sg13g2_IOPadTriOut<n>mA
//   sf_io_pad_bidir   bidirectional             sg13g2_IOPadInOut<n>mA
//   sf_io_pad_supply  VDD / VSS / IOVDD / IOVSS sg13g2_IOPad{Vdd,Vss,IOVdd,IOVss}
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_io_defs.svh"
`default_nettype none
/* verilator lint_off DECLFILENAME */

module sf_io_pad_in (
  input  wire logic pad,
  output wire logic p2c_o
);
  sf_io_cell_in u_cell (.pad(pad), .p2c(p2c_o));
endmodule

// Clock input.  Logically a plain input buffer; the wrapper exists so that the
// clock net is identifiable (SDC: create_clock on the pad port, scripts/gen_sdc.py)
// and so that a clock-specific receiver can be substituted per technology.
// IHP sg13g2_io has no dedicated clock receiver: the general input cell is used,
// whose vendor characterisation is a simulation (InputPerformance: 100 MHz target).
module sf_io_pad_clk (
  input  wire logic pad,
  output wire logic clk_o
);
  sf_io_cell_in u_cell (.pad(pad), .p2c(clk_o));
endmodule

// Reset input, normalised to active low.  No filtering: the library has no
// Schmitt-trigger input, so monotonic edges are a board requirement (POR
// supervisor).  Synchronisation happens in the consuming domain (P35 tree).
module sf_io_pad_rst #(parameter bit ACTIVE_LOW = 1'b1) (
  input  wire logic pad,
  output wire logic rst_no,
  output wire logic raw_o            // pad level, for boundary scan / status
);
  wire logic p2c;
  sf_io_cell_in u_cell (.pad(pad), .p2c(p2c));
  assign raw_o  = p2c;
  assign rst_no = ACTIVE_LOW ? p2c : ~p2c;
endmodule

// Test-mode input with a strap latch.  The latch is transparent while por_ni is
// low and holds from the release of POR on, so a glitch on the pin in mission
// mode cannot enter test mode (test mode bypasses reset synchronisers in P31 and
// P35).  Intentional latch (no clock exists during POR).
module sf_io_pad_test (
  input  wire logic pad,
  input  wire logic por_ni,
  output logic      test_o,          // latched (qualified) test mode
  output wire logic raw_o            // pad level, for boundary scan / status
);
  wire logic p2c;
  sf_io_cell_in u_cell (.pad(pad), .p2c(p2c));
  assign raw_o = p2c;
  /* verilator lint_off COMBDLY */
  always_latch begin
    if (!por_ni) test_o <= p2c;
  end
  /* verilator lint_on COMBDLY */
endmodule

// Output.  HIGHZ_CAPABLE = 1 (default, used for every SilicaFlux output) maps to
// a tri-state cell so that the boundary-scan control cell can disable the
// driver (HIGHZ / EXTEST); functional logic drives c2p_en_i = 1.
module sf_io_pad_out #(parameter int DRIVE = 4, parameter bit HIGHZ_CAPABLE = 1'b1) (
  output wire logic pad,
  input  wire logic c2p_i,
  input  wire logic c2p_en_i
);
  if (HIGHZ_CAPABLE) begin : g_tri
    sf_io_cell_tri #(.DRIVE(DRIVE)) u_cell (.pad(pad), .c2p(c2p_i), .c2p_en(c2p_en_i));
  end else begin : g_pp
    sf_io_cell_out #(.DRIVE(DRIVE)) u_cell (.pad(pad), .c2p(c2p_i));
    wire unused_en = c2p_en_i;
  end
endmodule

// Tri-state output (TDO, HOST_MISO, pseudo-open-drain HOST_IRQ_N / RAS_FATAL_N).
module sf_io_pad_tri #(parameter int DRIVE = 4) (
  output wire logic pad,
  input  wire logic c2p_i,
  input  wire logic c2p_en_i
);
  sf_io_cell_tri #(.DRIVE(DRIVE)) u_cell (.pad(pad), .c2p(c2p_i), .c2p_en(c2p_en_i));
endmodule

module sf_io_pad_bidir #(parameter int DRIVE = 4) (
  inout  wire logic pad,
  input  wire logic c2p_i,
  input  wire logic c2p_en_i,
  output wire logic p2c_o
);
  sf_io_cell_bidir #(.DRIVE(DRIVE)) u_cell (.pad(pad), .c2p(c2p_i), .c2p_en(c2p_en_i), .p2c(p2c_o));
endmodule

module sf_io_pad_supply #(parameter KIND = "VDD") ();
  sf_io_cell_supply #(.KIND(KIND)) u_cell ();
endmodule

`default_nettype wire
