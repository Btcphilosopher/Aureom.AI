// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: sf_io_mgmt -- shell management window
// Aureom.AI | SilicaFlux-HPC
//
// SFB2 slave for the shell window (sf_io_pkg::SHELL_BASE, 64 KiB):
//   page 0 SHELL  identity, status, control, IRQ aggregation, host-link and
//                 console counters, PHY dependency register, PHY / PCIe status
//   page 1 UART   mcu_uart  (MCU-I, unmodified, 16-entry FIFOs)
//   page 2 GPIO   mcu_gpio  (MCU-I, unmodified, 8 pins)
//   page 3 MSPI   mcu_spi   (MCU-I, unmodified, 1 chip select)
//   page 4 CRT    silicaflux_clock_reset_tree register bus (P35, outside, 8-bit offsets)
// Access rules: 32-bit aligned; writes need wstrb = 4'hF; otherwise an error
// response with no side effect.  Writes to read-only SHELL registers and
// unknown offsets / pages answer an error.  The register buses are the MCU-I /
// SilicaFlux-V style: one-cycle select strobe, combinational read data and
// error, captured into the SFB2 response one cycle after acceptance.
//
// Firmware console: every DIAG_TX write of the ControlCore (die diag_valid /
// diag_char, one-cycle pulse) is pushed into the UART TX FIFO when
// CTRL.CONSOLE_EN = 1.  It has priority on the UART register bus; a host access
// arriving in that cycle is simply not accepted until the next one.  A full
// FIFO drops the byte and sets the UART's own sticky TX_OVF (MCU-I behaviour).
// The die cannot reach these peripherals otherwise (dependency DIE-PERIPH).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_io_mgmt
  import sf_io_pkg::*;
#(
  parameter logic [7:0] DIE_CONFIG_ID = 8'd1,
  parameter logic [31:0] PHY_DEP      = 32'd0,     // assembled by the shell from the build
  parameter bit          P_IO_TECH    = 1'b0,
  parameter bit          P_MEM_SIM    = 1'b0,
  parameter bit          PCIE_PRESENT = 1'b0
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // SFB2 slave
  input  wire logic        s_req_valid,
  output logic             s_req_ready,
  input  wire logic        s_req_write,
  input  wire logic [31:0] s_req_addr,
  input  wire logic [31:0] s_req_wdata,
  input  wire logic [3:0]  s_req_wstrb,
  output logic             s_rsp_valid,
  input  wire logic        s_rsp_ready,
  output logic [31:0]      s_rsp_rdata,
  output logic             s_rsp_error,
  // management peripherals (pad side, after boundary scan)
  output logic             uart_txd_o,
  input  wire logic        uart_rxd_i,
  output logic             mspi_sck_o,
  output logic             mspi_mosi_o,
  input  wire logic        mspi_miso_i,
  output logic             mspi_cs_no,
  input  wire logic [7:0]  gpio_i,
  output logic [7:0]       gpio_o,
  output logic [7:0]       gpio_oe_o,
  // P35 clock / reset tree register bus
  output logic             crt_rb_sel_o,
  output logic             crt_rb_we_o,
  output logic [7:0]       crt_rb_addr_o,
  output logic [31:0]      crt_rb_wdata_o,
  input  wire logic [31:0] crt_rb_rdata_i,
  input  wire logic        crt_rb_err_i,
  // firmware console
  input  wire logic        diag_valid_i,
  input  wire logic [7:0]  diag_char_i,
  // status (synchronous to clk)
  input  wire logic [31:0] status_i,          // SHELL.STATUS, assembled by the shell
  input  wire logic        die_irq_i,
  input  wire logic        crt_wdog_irq_i,
  input  wire logic        board_warn_i,
  input  wire logic        board_fatal_i,
  input  wire logic        ras_fatal_i,
  input  wire logic        mc_init_done_i,
  input  wire logic        mc_fatal_i,
  input  wire logic [4:0]  link_err_i,
  input  wire logic [15:0] link_good_i,
  input  wire logic [15:0] link_bad_i,
  output logic [4:0]       link_err_clr_o,
  output logic             link_cnt_clr_o,
  input  wire logic [15:0] die_test_code_i,
  input  wire logic        die_test_done_i,
  input  wire logic        die_test_fail_i,
  input  wire logic        die_cpu_sleep_i,
  input  wire logic [31:0] mem_phy_i,
  input  wire logic [31:0] pcie_i,
  // die access override (CTRL.DIE_FORCE)
  output logic             die_force_o,
  // interrupt
  output logic             host_irq_o,
  output logic [9:0]       irq_status_o
);

  // ------------------------------------------------------------------ declarations
  logic [31:0] ctrl_q, irq_en_q, scratch_q;
  logic        mem_evt_q, mc_init_q, mc_fatal_q;
  logic [15:0] con_fwd_q, con_ign_q;
  logic [9:0]  irq_lvl;
  logic        uart_sel, uart_we, uart_err, uart_irq, uart_err_evt, uart_dtx, uart_drx;
  logic [11:0] uart_addr;
  logic [31:0] uart_wdata, uart_rdata;
  logic        gpio_err, gpio_irq;
  logic [31:0] gpio_rdata;
  logic [7:0]  gpio_in_sync;
  logic        mspi_err, mspi_irq, mspi_dtx, mspi_drx;
  logic [31:0] mspi_rdata;
  logic [0:0]  mspi_cs;

  // ------------------------------------------------------------------ request decode
  logic        rsp_pend;
  wire         fwd       = diag_valid_i && ctrl_q[0];
  assign       s_req_ready = !rsp_pend && !fwd;
  wire         accept    = s_req_valid && s_req_ready;
  wire  [3:0]  page      = s_req_addr[15:12];
  wire  [11:0] off       = s_req_addr[11:0];
  wire         legal     = (s_req_addr[1:0] == 2'b00) && (!s_req_write || (s_req_wstrb == 4'hF));
  wire         acc_ok    = accept && legal;

  // ------------------------------------------------------------------ SHELL registers
  assign irq_lvl = {mem_evt_q, |link_err_i, ras_fatal_i, board_fatal_i, board_warn_i, crt_wdog_irq_i,
                    mspi_irq, uart_irq, gpio_irq, die_irq_i};
  assign irq_status_o = irq_lvl;
  assign host_irq_o   = ctrl_q[1] && |(irq_lvl & irq_en_q[9:0]);
  assign die_force_o  = ctrl_q[2];

  wire sh_sel = acc_ok && (page == PAGE_SHELL);
  logic [31:0] sh_rdata;
  logic        sh_err;
  always_comb begin
    sh_rdata = 32'd0;
    sh_err   = 1'b0;
    unique case (off)
      R_ID:          begin sh_rdata = R_ID_RST; sh_err = s_req_write; end
      R_VERSION:     begin sh_rdata = {13'd0, PCIE_PRESENT, P_MEM_SIM, P_IO_TECH, DIE_CONFIG_ID, 8'd1}; sh_err = s_req_write; end
      R_STATUS:      begin sh_rdata = status_i; sh_err = s_req_write; end
      R_CTRL:        sh_rdata = ctrl_q;
      R_IRQ_STATUS:  begin sh_rdata = {22'd0, irq_lvl}; sh_err = s_req_write; end
      R_IRQ_ENABLE:  sh_rdata = irq_en_q;
      R_IRQ_CLEAR:   sh_rdata = 32'd0;
      R_LINK_STATUS: begin sh_rdata = {27'd0, link_err_i}; sh_err = s_req_write; end
      R_LINK_COUNT:  begin sh_rdata = {link_bad_i, link_good_i}; sh_err = s_req_write; end
      R_LINK_CLEAR:  sh_rdata = 32'd0;
      R_DIE_TEST:    begin sh_rdata = {13'd0, die_cpu_sleep_i, die_test_fail_i, die_test_done_i, die_test_code_i}; sh_err = s_req_write; end
      R_CONSOLE_CNT: begin sh_rdata = {con_ign_q, con_fwd_q}; sh_err = s_req_write; end
      R_PHY_DEP:     begin sh_rdata = PHY_DEP; sh_err = s_req_write; end
      R_MEM_PHY:     begin sh_rdata = mem_phy_i; sh_err = s_req_write; end
      R_PCIE:        begin sh_rdata = pcie_i; sh_err = s_req_write; end
      R_SCRATCH:     sh_rdata = scratch_q;
      default:       sh_err = 1'b1;
    endcase
  end
  wire sh_wr = sh_sel && s_req_write && !sh_err;

  wire mc_chg = (mc_init_done_i != mc_init_q) || (mc_fatal_i != mc_fatal_q);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ctrl_q <= R_CTRL_RST; irq_en_q <= R_IRQ_ENABLE_RST; scratch_q <= R_SCRATCH_RST;
      mem_evt_q <= 1'b0; mc_init_q <= 1'b0; mc_fatal_q <= 1'b0; con_fwd_q <= '0; con_ign_q <= '0;
    end else begin
      mc_init_q  <= mc_init_done_i;
      mc_fatal_q <= mc_fatal_i;
      if (mc_chg) mem_evt_q <= 1'b1;
      else if (sh_wr && off == R_IRQ_CLEAR && s_req_wdata[9]) mem_evt_q <= 1'b0;
      if (sh_wr && off == R_CTRL)       ctrl_q    <= {29'd0, s_req_wdata[2:0]};
      if (sh_wr && off == R_IRQ_ENABLE) irq_en_q  <= {22'd0, s_req_wdata[9:0]};
      if (sh_wr && off == R_SCRATCH)    scratch_q <= s_req_wdata;
      if (fwd && con_fwd_q != 16'hFFFF) con_fwd_q <= con_fwd_q + 16'd1;
      if (diag_valid_i && !ctrl_q[0] && con_ign_q != 16'hFFFF) con_ign_q <= con_ign_q + 16'd1;
    end
  end
  assign link_err_clr_o = (sh_wr && off == R_LINK_CLEAR) ? s_req_wdata[4:0] : 5'd0;
  assign link_cnt_clr_o = sh_wr && (off == R_LINK_CLEAR) && s_req_wdata[31];

  // ------------------------------------------------------------------ peripheral register buses
  wire        rb_we    = s_req_write;
  wire [11:0] rb_addr  = off;
  wire [31:0] rb_wdata = s_req_wdata;

  // UART (console forwarder has priority)
  assign uart_sel   = fwd || (acc_ok && page == PAGE_UART);
  assign uart_we    = fwd ? 1'b1 : rb_we;
  assign uart_addr  = fwd ? 12'h000 : rb_addr;
  assign uart_wdata = fwd ? {24'd0, diag_char_i} : rb_wdata;
  mcu_uart #(.FIFO_DEPTH(16)) u_uart (
    .clk, .rst_n, .rb_sel(uart_sel), .rb_we(uart_we), .rb_addr(uart_addr), .rb_wdata(uart_wdata),
    .rb_rdata(uart_rdata), .rb_err(uart_err), .txd(uart_txd_o), .rxd(uart_rxd_i), .irq(uart_irq),
    .dreq_tx(uart_dtx), .dreq_rx(uart_drx), .err_evt(uart_err_evt));

  mcu_gpio #(.N(8)) u_gpio (
    .clk, .rst_n, .rb_sel(acc_ok && page == PAGE_GPIO), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(gpio_rdata), .rb_err(gpio_err), .gpio_i, .gpio_o, .gpio_oe(gpio_oe_o),
    .gpio_in_sync(gpio_in_sync), .irq(gpio_irq));

  mcu_spi #(.NCS(1)) u_mspi (
    .clk, .rst_n, .rb_sel(acc_ok && page == PAGE_MSPI), .rb_we, .rb_addr, .rb_wdata,
    .rb_rdata(mspi_rdata), .rb_err(mspi_err), .sck(mspi_sck_o), .mosi(mspi_mosi_o), .miso(mspi_miso_i),
    .cs_n(mspi_cs), .irq(mspi_irq), .dreq_tx(mspi_dtx), .dreq_rx(mspi_drx));
  assign mspi_cs_no = mspi_cs[0];

  wire crt_off_ok   = (off[11:8] == 4'd0);
  assign crt_rb_sel_o   = acc_ok && (page == PAGE_CRT) && crt_off_ok;
  assign crt_rb_we_o    = rb_we;
  assign crt_rb_addr_o  = off[7:0];
  assign crt_rb_wdata_o = rb_wdata;

  // ------------------------------------------------------------------ response
  logic [31:0] rd_mux;
  logic        err_mux;
  always_comb begin
    rd_mux  = 32'd0;
    err_mux = 1'b1;
    if (legal) begin
      unique case (page)
        PAGE_SHELL: begin rd_mux = sh_rdata;   err_mux = sh_err;   end
        PAGE_UART:  begin rd_mux = uart_rdata; err_mux = uart_err; end
        PAGE_GPIO:  begin rd_mux = gpio_rdata; err_mux = gpio_err; end
        PAGE_MSPI:  begin rd_mux = mspi_rdata; err_mux = mspi_err; end
        PAGE_CRT:   begin rd_mux = crt_rb_rdata_i; err_mux = !crt_off_ok || crt_rb_err_i; end
        default:    ;
      endcase
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rsp_pend <= 1'b0; s_rsp_rdata <= '0; s_rsp_error <= 1'b0;
    end else if (accept) begin
      rsp_pend    <= 1'b1;
      s_rsp_error <= err_mux;
      s_rsp_rdata <= (err_mux || s_req_write) ? 32'd0 : rd_mux;     // SFB2 R8
    end else if (rsp_pend && s_rsp_ready) begin
      rsp_pend <= 1'b0; s_rsp_rdata <= '0; s_rsp_error <= 1'b0;
    end
  end
  assign s_rsp_valid = rsp_pend;

  wire unused_ok = &{1'b0, s_req_addr[31:16], uart_dtx, uart_drx, uart_err_evt, mspi_dtx, mspi_drx, gpio_in_sync};

endmodule

`default_nettype wire
