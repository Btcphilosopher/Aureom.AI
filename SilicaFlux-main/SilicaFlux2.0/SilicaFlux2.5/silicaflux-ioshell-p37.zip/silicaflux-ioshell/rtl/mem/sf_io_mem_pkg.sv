// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: sf_io_mem_pkg -- memory-interface boundaries
// Aureom.AI | SilicaFlux-HPC
//
// The external-memory path is split into three slots, each a separate boundary:
//
//   die (P24 bridge)  --SFMC-->  [controller slot]  --PHY boundary-->  [PHY slot]  --> pads / bumps
//
//   * Controller command/data: SFMC (P24 docs/MC_INTERFACE.md, rules C1-C11),
//     carried unchanged on the die's mc_* ports -- not redefined here.
//   * PHY status, calibration, clocking and reset: the structs below.  The field
//     names follow the DFI vocabulary (init_start / init_complete, update
//     requests, frequency ratio) so that a DFI PHY maps onto them, but this is
//     NOT a DFI implementation and claims no DFI compliance.
// No controller or PHY IP exists (dependencies MEM-CTRL, MEM-PHY): milestone A
// builds the slots empty (MEM_CTRL = NONE) or with simulation models only.
// Classification: SYNTHESIZABLE (package)
// =============================================================================
`ifndef SF_IO_MEM_PKG_SV
`define SF_IO_MEM_PKG_SV
package sf_io_mem_pkg;

  localparam int MEM_CTRL_NONE   = 0;    // no controller: mc_init_done = 0 (bridge waits in CAL)
  localparam int MEM_CTRL_SIM    = 1;    // SIMULATION ONLY: P24 extmem_sim_mc + sf_io_sim_mem_phy
  localparam int MEM_CTRL_VENDOR = 2;    // licensed controller + PHY (not available)

  typedef enum logic [3:0] {
    PHY_ABSENT  = 4'd0,
    PHY_RESET   = 4'd1,
    PHY_INIT    = 4'd2,
    PHY_CAL     = 4'd3,
    PHY_READY   = 4'd4,
    PHY_CALFAIL = 4'd5
  } mem_phy_state_e;

  // PHY -> controller / shell : status
  typedef struct packed {
    logic           present;        // a PHY occupies the slot
    logic           init_complete;  // DFI-style init_complete
    logic           cal_busy;       // training / calibration in progress
    logic           cal_done;       // last calibration passed
    logic           cal_fail;       // last calibration failed (sticky until reset)
    logic [7:0]     cal_err_code;   // PHY-specific failure code
    mem_phy_state_e state;
  } mem_phy_status_t;

  // controller -> PHY : calibration / training control
  typedef struct packed {
    logic init_start;               // (re)initialise and train
    logic cal_req;                  // periodic re-calibration request
  } mem_phy_cal_t;

  // clocking
  typedef struct packed {
    logic       ref_clk_ok;         // PHY reference clock present (from the shell clock root)
    logic       phy_clk_ok;         // PHY-generated controller clock running
    logic [1:0] freq_ratio;         // controller : PHY clock ratio (0 = 1:1, 1 = 1:2, 2 = 1:4)
  } mem_phy_clk_t;

  // reset
  typedef struct packed {
    logic phy_rst_n;                // shell -> PHY
    logic ctrl_rst_n;               // die bridge mc_rst_no -> controller
  } mem_phy_rst_t;

  // SHELL.MEM_PHY register image (packed in sf_io_mem_boundary; Yosys 0.33 cannot read struct
  // members inside package functions):
  //   {8'd0, state, ctrl_fatal, ctrl_init_done, ctrl_rst_n, ctrl_present, cal_err_code, 2'd0,
  //    init_complete, cal_fail, cal_done, cal_busy, phy_rst_n, present}

endpackage
`endif
