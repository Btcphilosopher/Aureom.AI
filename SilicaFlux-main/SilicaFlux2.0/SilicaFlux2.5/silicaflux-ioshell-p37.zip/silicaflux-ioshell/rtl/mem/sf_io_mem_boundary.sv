// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: sf_io_mem_boundary -- external-memory slots
// Aureom.AI | SilicaFlux-HPC
//
// Terminates the die's SFMC port (P24 bridge = master) and hosts the controller
// and PHY slots of sf_io_mem_pkg.  The bridge is NOT touched: it stays inside
// the die; this module is where licensed controller / PHY IP would attach.
//
// MEM_CTRL
//   NONE   (default, milestone A) no controller, no PHY.  mc_init_done = 0, every
//          ready / valid = 0.  The bridge's own verified link FSM goes RESET ->
//          CAL and waits there (P31 builds it with CAL_TIMEOUT = 0, "wait
//          forever"); external-memory accesses are answered UNAVAIL.
//   SIM    SIMULATION ONLY (needs `SF_IO_SIM_MODELS`): P24 extmem_sim_mc as the
//          controller and sf_io_sim_mem_phy as the PHY status model; the
//          controller reports init_done only once the PHY reports cal_done.
//   VENDOR needs `SF_IO_HAVE_MEM_IP` and a sf_io_vendor_mem_subsys module from the
//          IP integration; refused otherwise (MEM-CTRL / MEM-PHY dependencies).
// Classification: SYNTHESIZABLE (NONE / VENDOR); SIM instantiates simulation models
// =============================================================================
`include "sf_io_defs.svh"
`default_nettype none

module sf_io_mem_boundary
  import sf_io_mem_pkg::*;
#(
  parameter int MEM_CTRL = MEM_CTRL_NONE,
  parameter int MC_AW    = 26,
  parameter int MC_TW    = 2
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // SFMC (die bridge is the master)
  input  wire logic             mc_rst_ni,
  output logic                  mc_init_done_o,
  output logic                  mc_fatal_o,
  input  wire logic             mc_cmd_valid_i,
  output logic                  mc_cmd_ready_o,
  input  wire logic             mc_cmd_write_i,
  input  wire logic [MC_AW-1:0] mc_cmd_addr_i,
  input  wire logic [7:0]       mc_cmd_len_i,
  input  wire logic [MC_TW-1:0] mc_cmd_tag_i,
  input  wire logic             mc_wd_valid_i,
  output logic                  mc_wd_ready_o,
  input  wire logic [31:0]      mc_wd_data_i,
  input  wire logic [3:0]       mc_wd_strb_i,
  input  wire logic             mc_wd_last_i,
  output logic                  mc_rd_valid_o,
  input  wire logic             mc_rd_ready_i,
  output logic [31:0]           mc_rd_data_o,
  output logic [MC_TW-1:0]      mc_rd_tag_o,
  output logic                  mc_rd_last_o,
  output logic                  mc_rd_error_o,
  output logic                  mc_wr_valid_o,
  input  wire logic             mc_wr_ready_i,
  output logic [MC_TW-1:0]      mc_wr_tag_o,
  output logic                  mc_wr_error_o,
  // status
  output mem_phy_status_t       phy_status_o,
  output logic [31:0]           mem_phy_reg_o
);

  mem_phy_rst_t rst_b;
  mem_phy_cal_t cal_b;
  mem_phy_clk_t clk_b;
  logic         ctrl_present;

  // PHY reset follows the controller reset request of the bridge (each bridge
  // RESET re-trains the PHY), qualified by the shell reset.
  assign rst_b.ctrl_rst_n = mc_rst_ni;
  assign rst_b.phy_rst_n  = mc_rst_ni && rst_n;

  if (MEM_CTRL == MEM_CTRL_NONE) begin : g_none
    assign ctrl_present   = 1'b0;
    assign cal_b          = '0;
    assign clk_b          = '0;
    assign phy_status_o   = '0;                     // not present, state PHY_ABSENT (= 0)
    assign mc_init_done_o = 1'b0;
    assign mc_fatal_o     = 1'b0;
    assign mc_cmd_ready_o = 1'b0;
    assign mc_wd_ready_o  = 1'b0;
    assign mc_rd_valid_o  = 1'b0;
    assign mc_rd_data_o   = '0;
    assign mc_rd_tag_o    = '0;
    assign mc_rd_last_o   = 1'b0;
    assign mc_rd_error_o  = 1'b0;
    assign mc_wr_valid_o  = 1'b0;
    assign mc_wr_tag_o    = '0;
    assign mc_wr_error_o  = 1'b0;
    wire unused_ok = &{1'b0, mc_cmd_valid_i, mc_cmd_write_i, mc_cmd_addr_i, mc_cmd_len_i, mc_cmd_tag_i,
                       mc_wd_valid_i, mc_wd_data_i, mc_wd_strb_i, mc_wd_last_i, mc_rd_ready_i, mc_wr_ready_i, clk,
                       cal_b, clk_b};
  end else if (MEM_CTRL == MEM_CTRL_SIM) begin : g_sim
`ifdef SF_IO_SIM_MODELS
    logic mc_init_raw;
    // model statistics, read by the testbench (st_violations: the model's own SFMC rule checks)
    /* verilator lint_off UNUSEDSIGNAL */
    int   st_violations, st_rd_cmds, st_wr_cmds, st_rd_beats, st_wr_beats, st_rderr_inj, st_wr_poisoned,
          st_row_hits, st_row_miss;
    /* verilator lint_on UNUSEDSIGNAL */
    assign ctrl_present = 1'b1;
    assign cal_b        = '{init_start: rst_b.phy_rst_n, cal_req: 1'b0};
    assign clk_b        = '{ref_clk_ok: 1'b1, phy_clk_ok: 1'b1, freq_ratio: 2'd0};
    sf_io_sim_mem_phy u_phy (.clk, .rst_i(rst_b), .cal_i(cal_b), .clk_i(clk_b), .status_o(phy_status_o));
    extmem_sim_mc #(.DW(32), .MC_AW(MC_AW), .LW(8), .TW(MC_TW), .MB(8), .MEM_BYTES(65536), .OOO(1),
                    .CAL_CYCLES(20), .SEED(7), .STRICT_WD(1)) u_mc (
      .clk, .rst_n(mc_rst_ni), .init_done(mc_init_raw), .fatal(mc_fatal_o),
      .cmd_valid(mc_cmd_valid_i), .cmd_ready(mc_cmd_ready_o), .cmd_write(mc_cmd_write_i), .cmd_addr(mc_cmd_addr_i),
      .cmd_len(mc_cmd_len_i), .cmd_tag(mc_cmd_tag_i),
      .wd_valid(mc_wd_valid_i), .wd_ready(mc_wd_ready_o), .wd_data(mc_wd_data_i), .wd_strb(mc_wd_strb_i), .wd_last(mc_wd_last_i),
      .rd_valid(mc_rd_valid_o), .rd_ready(mc_rd_ready_i), .rd_data(mc_rd_data_o), .rd_tag(mc_rd_tag_o), .rd_last(mc_rd_last_o),
      .rd_error(mc_rd_error_o), .wr_valid(mc_wr_valid_o), .wr_ready(mc_wr_ready_i), .wr_tag(mc_wr_tag_o), .wr_error(mc_wr_error_o),
      .tb_cal_drop(1'b0), .tb_hang(1'b0), .tb_fatal(1'b0), .tb_poison_en(1'b0), .tb_poison_lo(32'd0), .tb_poison_hi(32'd0),
      .tb_rderr_p16(32'd0), .tb_lat_min(32'd2), .tb_lat_max(32'd12), .tb_cmd_rdy_pct(32'd80), .tb_wd_rdy_pct(32'd80),
      .tb_rsp_pct(32'd80),
      .st_violations, .st_rd_cmds, .st_wr_cmds, .st_rd_beats, .st_wr_beats, .st_rderr_inj, .st_wr_poisoned,
      .st_row_hits, .st_row_miss);
    // the controller is initialised only when its PHY has calibrated
    assign mc_init_done_o = mc_init_raw && phy_status_o.cal_done;
`else
    `SF_IO_ELAB_FATAL("sf_io_mem_boundary: MEM_CTRL = SIM uses simulation-only models; compile with SF_IO_SIM_MODELS")
`endif
  end else if (MEM_CTRL == MEM_CTRL_VENDOR) begin : g_vendor
`ifdef SF_IO_HAVE_MEM_IP
    assign ctrl_present = 1'b1;
    sf_io_vendor_mem_subsys #(.MC_AW(MC_AW), .MC_TW(MC_TW)) u_ip (.*);
`else
    `SF_IO_ELAB_FATAL("sf_io_mem_boundary: MEM_CTRL = VENDOR needs licensed memory controller + PHY IP (dependencies MEM-CTRL, MEM-PHY): not available")
`endif
  end else begin : g_bad
    `SF_IO_ELAB_FATAL("sf_io_mem_boundary: illegal MEM_CTRL")
  end

  assign mem_phy_reg_o = {8'd0, phy_status_o.state, mc_fatal_o, mc_init_done_o, rst_b.ctrl_rst_n, ctrl_present,
                          phy_status_o.cal_err_code, 2'd0, phy_status_o.init_complete, phy_status_o.cal_fail,
                          phy_status_o.cal_done, phy_status_o.cal_busy, rst_b.phy_rst_n, phy_status_o.present};

endmodule

`default_nettype wire
