# Physical checks -- pad ring (independent re-derivation from DEF / LEF / netlist)

DEF `build/phys/or/silicaflux_io_shell.def`, die 3442 x 3444 um. Every check is recomputed here from the files; OpenROAD's own reports are kept in `reports/physical/openroad/`.

| Rule | Result | Check |
|---|---|---|
| P1 | PASS | 39 netlist port bits == 39 inventory pad bits, directions equal |
| P2 | PASS | 39 signal pad cells + 34 supply pad cells: master, pad-pin net and core pins as planned |
| P3 | PASS | DEF: 73 pad instances and 39 signal terminals match the netlist names (+4 supply terminals ['IOVDD', 'IOVSS', 'VDD', 'VSS'] created by connect_by_abutment) |
| P4 | PASS | 73 pads placed at the planned side / offset / row orientation (S N, N FS, E W, W FW) |
| P5 | PASS | 8328 placed instances (7928 standard cells): no overlap |
| P6 | PASS | ring continuity: 4 corners, 249 fillers + pads tile all four sides without gap |
| P7 | PASS | 73 bond pads (70 x 70 um) at the planned offset, inside the die, outside their IO cells; closest bond-pad spacing 20.0 um, closest to die edge 70.0 um (assembly rules: dependency PKG) |
| P8 | PASS | signal terminals on ['TopMetal2'] over their pad pins at the outer pad edge; pad core pins (p2c / c2p / c2p_en) on the ring's inner edge; core-block pins on ['Metal2'] (all tech-LEF routing layers) |
| P9 | PASS | core block 2738.4 x 2566.6 um inside the core area; core area 31.36 um clear of the ring's inner edge; every standard cell inside the core area |
| P10 | PASS | 34 supply pads as planned per side and kind; all 326 ring cells have vdd / vss / iovdd / iovss on VDD / VSS / IOVDD / IOVSS |
| P11 | PASS | no unplaced terminal; 19 inventory signals unassigned by design (reserved / PHY-owned) |

### P11 detail

* PCIE_PERST_N (1 bit, RESERVED, PCIE-CTRL)
* PCIE_WAKE_N (1 bit, RESERVED, PCIE-CTRL)
* PCIE_CLKREQ_N (1 bit, RESERVED, PCIE-CTRL)
* SCAN_EN (1 bit, RESERVED, DFT-SCAN)
* SCAN_IN (2 bit, RESERVED, DFT-SCAN)
* SCAN_OUT (2 bit, RESERVED, DFT-SCAN)
* PCIE_TXP (4 bit, BLOCKED, PCIE-PHY)
* PCIE_TXN (4 bit, BLOCKED, PCIE-PHY)
* PCIE_RXP (4 bit, BLOCKED, PCIE-PHY)
* PCIE_RXN (4 bit, BLOCKED, PCIE-PHY)
* PCIE_REFCLK_P (1 bit, BLOCKED, PCIE-PHY)
* PCIE_REFCLK_N (1 bit, BLOCKED, PCIE-PHY)
* PCIE_PHY_ANALOG (vendor-defined bit, BLOCKED, PCIE-PHY)
* DDR_CK (2 bit, BLOCKED, MEM-PHY)
* DDR_CA (28 bit, BLOCKED, MEM-PHY)
* DDR_DQ (16 bit, BLOCKED, MEM-PHY)
* DDR_DQS (4 bit, BLOCKED, MEM-PHY)
* DDR_DM (2 bit, BLOCKED, MEM-PHY)
* DDR_PHY_ANALOG (vendor-defined bit, BLOCKED, MEM-PHY)
