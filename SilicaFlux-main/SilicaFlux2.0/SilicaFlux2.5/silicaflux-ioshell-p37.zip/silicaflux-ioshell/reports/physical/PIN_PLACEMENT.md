# Floorplan pin-placement report -- SilicaFlux IOSHELL

Die 3442 x 3444 um, IHP SG13G2 wire-bond pad ring of real `sg13g2_io` cells, placed by OpenROAD (`physical/padring.tcl`) from the plan of `scripts/pin_assign.py`; every placement re-checked by `scripts/check_physical.py` ([PHYSICAL_CHECKS](PHYSICAL_CHECKS.md)). Picture: [floorplan.svg](floorplan.svg).

## 1. Orientation

| Side | Region | Signal pads | Supply pads |
|---|---|---|---|
| N | control region: clock / reset root, straps, status, RAS | 15 | 10 |
| E | host region: host-command link (+ reserved PCIe sideband, PCIe PHY in milestone B) | 5 | 6 |
| S | memory region: reserved for the DDR / HBM PHY of milestone B (supplies only today) | 0 | 6 |
| W | test / debug + management: JTAG near the north-west corner, UART, SPI, GPIO | 19 | 12 |

Evaluation against the brief (section 8):

* **Control and low-speed pins near the top / control region** -- clocks, resets, straps, status and RAS are on the north side; the P35 clock / reset root and the shell logic are placed in the north strip directly inside them.
* **External-memory interface near the memory subsystem** -- the south side is kept free of signal pads for the DDR / HBM PHY of milestone B (the die's SFMC port is the boundary; P31 recommends the memory slices next to the vector clusters, so the PHY should face them). Today it carries supplies only.
* **Host interface near its controller region** -- the host-command link is on the east side, which is also where the PCIe sideband pins are reserved and where a PCIe PHY would sit.
* **Test and debug at accessible perimeter positions** -- JTAG occupies the north end of the west side (first bond-order positions), away from the high-speed sides; UART / SPI / GPIO follow on the same side.
* **Clock inputs** have an IOVSS pad as neighbour (planning rule, `config/io_inventory.yaml`).

## 2. Pads per side (die coordinates, um; lower-left of the 80 x 180 um IO cell)

### N (25 slots, pitch 112 um)

| # | Bond idx | Instance | Cell | Net / port | Kind | x0 | y0 |
|---|---|---|---|---|---|---|---|
| 0 | 73 | `pad_PLATFORM_READY` | `sg13g2_IOPadTriOut4mA` | `PLATFORM_READY` | signal | 337.0 | 3124.0 |
| 1 | 72 | `pad_IOVDD_N0` | `sg13g2_IOPadIOVdd` | `IOVDD` | supply | 449.0 | 3124.0 |
| 2 | 71 | `pad_DEVICE_READY` | `sg13g2_IOPadTriOut4mA` | `DEVICE_READY` | signal | 561.0 | 3124.0 |
| 3 | 70 | `pad_TEST_DONE` | `sg13g2_IOPadTriOut4mA` | `TEST_DONE` | signal | 673.0 | 3124.0 |
| 4 | 69 | `pad_VDD_N0` | `sg13g2_IOPadVdd` | `VDD` | supply | 785.0 | 3124.0 |
| 5 | 68 | `pad_TEST_FAIL` | `sg13g2_IOPadTriOut4mA` | `TEST_FAIL` | signal | 897.0 | 3124.0 |
| 6 | 67 | `pad_POR_N` | `sg13g2_IOPadIn` | `POR_N` | signal | 1009.0 | 3124.0 |
| 7 | 66 | `pad_IOVDD_N1` | `sg13g2_IOPadIOVdd` | `IOVDD` | supply | 1121.0 | 3124.0 |
| 8 | 65 | `pad_RST_N` | `sg13g2_IOPadIn` | `RST_N` | signal | 1233.0 | 3124.0 |
| 9 | 64 | `pad_IOVSS_N0` | `sg13g2_IOPadIOVss` | `IOVSS` | supply | 1345.0 | 3124.0 |
| 10 | 63 | `pad_CLK_REF` | `sg13g2_IOPadIn` | `CLK_REF` | signal | 1457.0 | 3124.0 |
| 11 | 62 | `pad_VDD_N1` | `sg13g2_IOPadVdd` | `VDD` | supply | 1569.0 | 3124.0 |
| 12 | 61 | `pad_IOVSS_N1` | `sg13g2_IOPadIOVss` | `IOVSS` | supply | 1681.0 | 3124.0 |
| 13 | 60 | `pad_CLK_CORE` | `sg13g2_IOPadIn` | `CLK_CORE` | signal | 1793.0 | 3124.0 |
| 14 | 59 | `pad_IOVDD_N2` | `sg13g2_IOPadIOVdd` | `IOVDD` | supply | 1905.0 | 3124.0 |
| 15 | 58 | `pad_CLKGEN_LOCK` | `sg13g2_IOPadIn` | `CLKGEN_LOCK` | signal | 2017.0 | 3124.0 |
| 16 | 57 | `pad_TEST_MODE` | `sg13g2_IOPadIn` | `TEST_MODE` | signal | 2129.0 | 3124.0 |
| 17 | 56 | `pad_VSS_N0` | `sg13g2_IOPadVss` | `VSS` | supply | 2241.0 | 3124.0 |
| 18 | 55 | `pad_BOOT_MODE_0` | `sg13g2_IOPadIn` | `BOOT_MODE[0]` | signal | 2353.0 | 3124.0 |
| 19 | 54 | `pad_BOOT_MODE_1` | `sg13g2_IOPadIn` | `BOOT_MODE[1]` | signal | 2465.0 | 3124.0 |
| 20 | 53 | `pad_IOVSS_N2` | `sg13g2_IOPadIOVss` | `IOVSS` | supply | 2577.0 | 3124.0 |
| 21 | 52 | `pad_RAS_FATAL_N` | `sg13g2_IOPadTriOut4mA` | `RAS_FATAL_N` | signal | 2689.0 | 3124.0 |
| 22 | 51 | `pad_BOARD_WARN_N` | `sg13g2_IOPadIn` | `BOARD_WARN_N` | signal | 2801.0 | 3124.0 |
| 23 | 50 | `pad_VSS_N1` | `sg13g2_IOPadVss` | `VSS` | supply | 2913.0 | 3124.0 |
| 24 | 49 | `pad_BOARD_FATAL_N` | `sg13g2_IOPadIn` | `BOARD_FATAL_N` | signal | 3025.0 | 3124.0 |

### E (11 slots, pitch 254 um)

| # | Bond idx | Instance | Cell | Net / port | Kind | x0 | y0 |
|---|---|---|---|---|---|---|---|
| 0 | 38 | `pad_VSS_E1` | `sg13g2_IOPadVss` | `VSS` | supply | 3122.0 | 412.0 |
| 1 | 39 | `pad_HOST_IRQ_N` | `sg13g2_IOPadTriOut4mA` | `HOST_IRQ_N` | signal | 3122.0 | 666.0 |
| 2 | 40 | `pad_VSS_E0` | `sg13g2_IOPadVss` | `VSS` | supply | 3122.0 | 920.0 |
| 3 | 41 | `pad_HOST_MISO` | `sg13g2_IOPadTriOut4mA` | `HOST_MISO` | signal | 3122.0 | 1174.0 |
| 4 | 42 | `pad_VDD_E1` | `sg13g2_IOPadVdd` | `VDD` | supply | 3122.0 | 1428.0 |
| 5 | 43 | `pad_HOST_MOSI` | `sg13g2_IOPadIn` | `HOST_MOSI` | signal | 3122.0 | 1682.0 |
| 6 | 44 | `pad_IOVSS_E0` | `sg13g2_IOPadIOVss` | `IOVSS` | supply | 3122.0 | 1936.0 |
| 7 | 45 | `pad_HOST_CS_N` | `sg13g2_IOPadIn` | `HOST_CS_N` | signal | 3122.0 | 2190.0 |
| 8 | 46 | `pad_VDD_E0` | `sg13g2_IOPadVdd` | `VDD` | supply | 3122.0 | 2444.0 |
| 9 | 47 | `pad_HOST_SCK` | `sg13g2_IOPadIn` | `HOST_SCK` | signal | 3122.0 | 2698.0 |
| 10 | 48 | `pad_IOVDD_E0` | `sg13g2_IOPadIOVdd` | `IOVDD` | supply | 3122.0 | 2952.0 |

### S (6 slots, pitch 467 um)

| # | Bond idx | Instance | Cell | Net / port | Kind | x0 | y0 |
|---|---|---|---|---|---|---|---|
| 0 | 32 | `pad_IOVDD_S0` | `sg13g2_IOPadIOVdd` | `IOVDD` | supply | 513.0 | 140.0 |
| 1 | 33 | `pad_VDD_S0` | `sg13g2_IOPadVdd` | `VDD` | supply | 980.0 | 140.0 |
| 2 | 34 | `pad_IOVSS_S0` | `sg13g2_IOPadIOVss` | `IOVSS` | supply | 1447.0 | 140.0 |
| 3 | 35 | `pad_VDD_S1` | `sg13g2_IOPadVdd` | `VDD` | supply | 1914.0 | 140.0 |
| 4 | 36 | `pad_VSS_S0` | `sg13g2_IOPadVss` | `VSS` | supply | 2381.0 | 140.0 |
| 5 | 37 | `pad_VSS_S1` | `sg13g2_IOPadVss` | `VSS` | supply | 2848.0 | 140.0 |

### W (31 slots, pitch 90 um)

| # | Bond idx | Instance | Cell | Net / port | Kind | x0 | y0 |
|---|---|---|---|---|---|---|---|
| 0 | 31 | `pad_GPIO_7` | `sg13g2_IOPadInOut4mA` | `GPIO[7]` | signal | 140.0 | 332.0 |
| 1 | 30 | `pad_IOVSS_W3` | `sg13g2_IOPadIOVss` | `IOVSS` | supply | 140.0 | 422.0 |
| 2 | 29 | `pad_GPIO_6` | `sg13g2_IOPadInOut4mA` | `GPIO[6]` | signal | 140.0 | 512.0 |
| 3 | 28 | `pad_GPIO_5` | `sg13g2_IOPadInOut4mA` | `GPIO[5]` | signal | 140.0 | 602.0 |
| 4 | 27 | `pad_IOVSS_W2` | `sg13g2_IOPadIOVss` | `IOVSS` | supply | 140.0 | 692.0 |
| 5 | 26 | `pad_GPIO_4` | `sg13g2_IOPadInOut4mA` | `GPIO[4]` | signal | 140.0 | 782.0 |
| 6 | 25 | `pad_IOVSS_W1` | `sg13g2_IOPadIOVss` | `IOVSS` | supply | 140.0 | 872.0 |
| 7 | 24 | `pad_GPIO_3` | `sg13g2_IOPadInOut4mA` | `GPIO[3]` | signal | 140.0 | 962.0 |
| 8 | 23 | `pad_GPIO_2` | `sg13g2_IOPadInOut4mA` | `GPIO[2]` | signal | 140.0 | 1052.0 |
| 9 | 22 | `pad_VSS_W1` | `sg13g2_IOPadVss` | `VSS` | supply | 140.0 | 1142.0 |
| 10 | 21 | `pad_GPIO_1` | `sg13g2_IOPadInOut4mA` | `GPIO[1]` | signal | 140.0 | 1232.0 |
| 11 | 20 | `pad_GPIO_0` | `sg13g2_IOPadInOut4mA` | `GPIO[0]` | signal | 140.0 | 1322.0 |
| 12 | 19 | `pad_IOVDD_W3` | `sg13g2_IOPadIOVdd` | `IOVDD` | supply | 140.0 | 1412.0 |
| 13 | 18 | `pad_MSPI_CS_N` | `sg13g2_IOPadTriOut4mA` | `MSPI_CS_N` | signal | 140.0 | 1502.0 |
| 14 | 17 | `pad_VSS_W0` | `sg13g2_IOPadVss` | `VSS` | supply | 140.0 | 1592.0 |
| 15 | 16 | `pad_MSPI_MISO` | `sg13g2_IOPadIn` | `MSPI_MISO` | signal | 140.0 | 1682.0 |
| 16 | 15 | `pad_MSPI_MOSI` | `sg13g2_IOPadTriOut4mA` | `MSPI_MOSI` | signal | 140.0 | 1772.0 |
| 17 | 14 | `pad_IOVDD_W2` | `sg13g2_IOPadIOVdd` | `IOVDD` | supply | 140.0 | 1862.0 |
| 18 | 13 | `pad_MSPI_SCK` | `sg13g2_IOPadTriOut4mA` | `MSPI_SCK` | signal | 140.0 | 1952.0 |
| 19 | 12 | `pad_UART_RX` | `sg13g2_IOPadIn` | `UART_RX` | signal | 140.0 | 2042.0 |
| 20 | 11 | `pad_VDD_W1` | `sg13g2_IOPadVdd` | `VDD` | supply | 140.0 | 2132.0 |
| 21 | 10 | `pad_UART_TX` | `sg13g2_IOPadTriOut4mA` | `UART_TX` | signal | 140.0 | 2222.0 |
| 22 | 9 | `pad_TDO` | `sg13g2_IOPadTriOut4mA` | `TDO` | signal | 140.0 | 2312.0 |
| 23 | 8 | `pad_IOVDD_W1` | `sg13g2_IOPadIOVdd` | `IOVDD` | supply | 140.0 | 2402.0 |
| 24 | 7 | `pad_TDI` | `sg13g2_IOPadIn` | `TDI` | signal | 140.0 | 2492.0 |
| 25 | 6 | `pad_VDD_W0` | `sg13g2_IOPadVdd` | `VDD` | supply | 140.0 | 2582.0 |
| 26 | 5 | `pad_TMS` | `sg13g2_IOPadIn` | `TMS` | signal | 140.0 | 2672.0 |
| 27 | 4 | `pad_TCK` | `sg13g2_IOPadIn` | `TCK` | signal | 140.0 | 2762.0 |
| 28 | 3 | `pad_IOVSS_W0` | `sg13g2_IOPadIOVss` | `IOVSS` | supply | 140.0 | 2852.0 |
| 29 | 2 | `pad_IOVDD_W0` | `sg13g2_IOPadIOVdd` | `IOVDD` | supply | 140.0 | 2942.0 |
| 30 | 1 | `pad_TRST_N` | `sg13g2_IOPadIn` | `TRST_N` | signal | 140.0 | 3032.0 |

## 3. Pad-net lengths after placement (half-perimeter, um)

Nets between each pad's core-side pin and the shell logic, from the placed DEF (`pad_nets.csv`). Indicative only: pre-route, and the shell logic sits in one north strip because the die core's real outline is unknown.

| Side | Nets | Median | Max |
|---|---|---|---|
| N | 20 | 905 | 1712 |
| E | 7 | 3494 | 4126 |
| W | 40 | 1969 | 2870 |

Longest ten:

| Pad | Pin | Net | Fan-out | HPWL (um) |
|---|---|---|---|---|
| `HOST_IRQ_N` (E) | c2p_en | `u_pad_HOST_IRQ_N.c2p_en_i` | 1 | 4126.4 |
| `HOST_IRQ_N` (E) | c2p | `u_pad_HOST_IRQ_N.c2p_i` | 1 | 4031.1 |
| `HOST_MISO` (E) | c2p_en | `u_pad_HOST_MISO.c2p_en_i` | 1 | 3560.3 |
| `HOST_MISO` (E) | c2p | `u_pad_HOST_MISO.c2p_i` | 1 | 3494.5 |
| `HOST_MOSI` (E) | p2c | `u_hlink.mosi_i` | 2 | 2930.4 |
| `GPIO[7]` (W) | p2c | `g_pad_GPIO[7].u_pad.p2c_o` | 2 | 2870.0 |
| `GPIO[7]` (W) | c2p_en | `g_pad_GPIO[7].u_pad.c2p_en_i` | 1 | 2778.4 |
| `GPIO[7]` (W) | c2p | `g_pad_GPIO[7].u_pad.c2p_i` | 1 | 2773.9 |
| `GPIO[6]` (W) | p2c | `g_pad_GPIO[6].u_pad.p2c_o` | 2 | 2677.0 |
| `GPIO[6]` (W) | c2p | `g_pad_GPIO[6].u_pad.c2p_i` | 1 | 2618.9 |

Reading: north pads reach the shell strip in a few hundred um. East (host link) and west (JTAG, management) pads cross up to ~2.5 mm to reach logic in the strip. All of them are low-speed or oversampled, so this is acceptable for milestone A, but it is the first floorplan change once the die core is sized: place the host-link logic (`u_hlink`, `u_split`) in an east region and the TAP / boundary scan (`u_jtag`) and management peripherals in a west region (placement fences), keeping each pad-to-logic hop short. TCK is a clock: its pad-to-TAP route is the one that matters most for JTAG timing.
