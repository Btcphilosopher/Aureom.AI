# Physical checker self-test (seeded faults)

Each case injects one fault into a copy of the DEF or netlist; the named rule must fail.

| Case | Rule expected to fail | Result | Rules that failed |
|---|---|---|---|
| clean inputs | all PASS | PASS |  |
| pad moved by 1 um | P4 | PASS | P4, P5, P6, P8 |
| filler removed | P6 | PASS | P6 |
| bond pad removed | P7 | PASS | P7 |
| standard cell placed on the core block | P5 | PASS | P5 |
| terminal renamed | P3 | PASS | P3, P8 |
| terminal on a wrong layer | P8 | PASS | P8 |
| pad vdd pin off the VDD rail | P10 | PASS | P10 |
| pad with the wrong orientation | P4 | PASS | P4, P8 |
| supply pad removed | P10, P3 | PASS | P10, P3, P4, P6 |
| port direction flipped in the netlist | P1 | PASS | P1 |

**11 / 11 cases behave as required.**
