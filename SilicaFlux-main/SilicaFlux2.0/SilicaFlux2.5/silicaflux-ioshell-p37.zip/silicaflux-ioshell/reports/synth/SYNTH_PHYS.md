# Physical netlist synthesis (Yosys 0.33, IHP SG13G2 typ)

The die (`sf_io_die_core`, P31) is a black box: it has no PDK mapping. Everything else is mapped to real sg13g2 cells. Area is Yosys' Liberty sum (pad cells carry no area in the I/O Liberty), pre-placement, no claim beyond that.

| Item | Value |
|---|---|
| Pad cells | 73 (sg13g2_IOPadIOVdd x9, sg13g2_IOPadIOVss x9, sg13g2_IOPadIn x19, sg13g2_IOPadInOut4mA x8, sg13g2_IOPadTriOut4mA x12, sg13g2_IOPadVdd x8, sg13g2_IOPadVss x8) |
| Standard cells | 7928 |
| Strap latches (sg13g2_dlhq_1 / dllrq_1) | 3 (intentional: TEST_MODE + BOOT_MODE[1:0]) |
| Clock-gate cells (sg13g2_slgcp_1, P35 root / branch ICG) | 2 |
| Black boxes | 1 (sf_io_die_core) |
| Standard-cell area (Yosys) | 166282.8804 um2 |
| Pad instances renamed to pad_<NAME> | 73 |
