# Mutation testing -- SilicaFlux IOSHELL

Each mutant is a deliberate defect in the shell's new RTL, compiled behind a runtime selector in a copy of `rtl/` (`scripts/mutate.py`); the source tree is untouched. Baselines (selector 0) must pass; every mutant must be detected.

| # | Mutant | File | Test | Result | First failing check |
|---|---|---|---|---|---|
| - | baseline (min / all) | | | PASS | |
| - | baseline (hpc_nomem / mem_absent) | | | PASS | |
| - | baseline (hpc_memsim / memcalfail) | | | PASS | |
| M01 | host link: SCK speed check removed | `rtl/host/sf_io_spi_host.sv` | min / all | KILLED | FAIL [hostlink] over-speed frame did not write: got deadbeef expected c0ffee37 |
| M02 | host link: MISO driven while deselected | `rtl/host/sf_io_spi_host.sv` | min / all | KILLED | FAIL [direction] HOST_MISO released while deselected |
| M03 | host link: READ launched while a transaction is outstanding | `rtl/host/sf_io_spi_host.sv` | min / all | KILLED | FAIL [hostlink] second launch while busy -> BUSY_ERR: got 00000000 expected 00000083 |
| M04 | host link: RESET accepted without the key | `rtl/host/sf_io_spi_host.sv` | min / all | KILLED | FAIL [hostlink] RESET with a wrong key -> CMD_ERR: got 00000080 expected 00000082 |
| M05 | host link: truncated argument phase not flagged | `rtl/host/sf_io_spi_host.sv` | min / all | KILLED | FAIL [hostlink] LINK_STATUS: FRAME after a truncated argument phase: got 00000000 expected 00000001 |
| M06 | split: die accesses not gated by PLATFORM_READY | `rtl/host/sf_io_host_split.sv` | min / all | KILLED | FAIL [dieready] die access before PLATFORM_READY refused (BUS_ERR): got 00000080 expected 00000081 |
| M07 | split: reset fence removed | `rtl/host/sf_io_host_split.sv` | min / all | KILLED | FAIL [fence] reset fence: the cut transaction ends with BUS_ERR: got 00000000 expected 00000081 |
| M08 | management: partial-strobe writes accepted | `rtl/mgmt/sf_io_mgmt.sv` | min / all | KILLED | FAIL [hostlink] WRITE with WSTRB 0 to the shell -> BUS_ERR: got 00000080 expected 00000081 |
| M09 | management: IRQ_ENABLE mask ignored | `rtl/mgmt/sf_io_mgmt.sv` | min / all | KILLED | FAIL [jtag] SAMPLE: HOST_IRQ_N control (no irq): got 00000001 expected 00000000 |
| M10 | management: console forwarded although CONSOLE_EN = 0 | `rtl/mgmt/sf_io_mgmt.sv` | min / all | KILLED | FAIL [console] CONSOLE_EN = 0: nothing on UART_TX: got 00000001 expected 00000000 |
| M11 | management: write to a read-only register accepted | `rtl/mgmt/sf_io_mgmt.sv` | min / all | KILLED | FAIL [hostlink] write to a read-only register -> BUS_ERR: got 00000080 expected 00000081 |
| M12 | JTAG: CLAMP does not hold the pads | `rtl/jtag/sf_io_jtag.sv` | min / all | KILLED | FAIL [jtag] CLAMP: pads hold the update stage (PLATFORM_READY 0): got 00000001 expected 00000000 |
| M13 | JTAG: HIGHZ ignored | `rtl/jtag/sf_io_jtag.sv` | min / all | KILLED | FAIL [jtag] HIGHZ: PLATFORM_READY released |
| M14 | top: boundary-scan input cells of HOST_SCK / HOST_MOSI crossed | `rtl/silicaflux_io_shell.sv` | min / all | KILLED | FAIL [jtag] SAMPLE: HOST_SCK: got 00000000 expected 00000001 |
| M15 | top: HOST_IRQ_N driven instead of open drain | `rtl/silicaflux_io_shell.sv` | min / all | KILLED | FAIL [direction] HOST_IRQ_N released (no interrupt) |
| M16 | top: TAP not reset by POR | `rtl/silicaflux_io_shell.sv` | min / all | KILLED | FAIL [-] PLATFORM_READY pad rises |
| M17 | pads: TEST_MODE strap latch transparent in mission mode | `rtl/pads/sf_io_pads.sv` | min / all | KILLED | FAIL [direction] TEST_MODE / BOOT_MODE toggled in mission mode: latched values unchanged: got 00000080 expected 00000000 |
| M18 | host link: SFB2 request withdrawn before acceptance | `rtl/host/sf_io_spi_host.sv` | min / all | KILLED | Assertion failed in TOP.tb_io_shell.u_chk_hl: [hostlink] R2: req_valid dropped before acceptance |
| M19 | pads: output wrapper ignores its enable (no HIGHZ) | `rtl/pads/sf_io_pads.sv` | min / all | KILLED | FAIL [jtag] EXTEST: TEST_DONE released |
| M20 | management: CRT page offsets beyond 0xFF aliased | `rtl/mgmt/sf_io_mgmt.sv` | min / all | KILLED | FAIL [hostlink] CRT offset beyond its 8-bit space -> BUS_ERR: got 00000080 expected 00000081 |
| M21 | memory slot NONE: controller reported initialised | `rtl/mem/sf_io_mem_boundary.sv` | hpc_nomem / mem_absent | KILLED | FAIL [mem_absent] HPC die without a memory controller never reaches PLATFORM_READY: got 00000001 expected 00000000 |
| M22 | memory slot SIM: controller ready without PHY calibration | `rtl/mem/sf_io_mem_boundary.sv` | hpc_memsim / memcalfail | KILLED | FAIL [memcalfail] calibration failure: no PLATFORM_READY: got 00000001 expected 00000000 |

**22 / 22 mutants killed; baselines all pass.**
