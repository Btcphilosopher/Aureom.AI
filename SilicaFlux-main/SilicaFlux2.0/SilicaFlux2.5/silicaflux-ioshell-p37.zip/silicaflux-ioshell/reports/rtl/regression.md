# RTL regression -- SilicaFlux IOSHELL

Tools: Verilator 5.020 2024-01-01 rev (Debian 5.020-1); Icarus Verilog version 12.0 (stable) (). The DUT of every simulation is the whole chip (`silicaflux_io_shell` with the real P31 die inside); the testbench drives pads only.

| Kind | Item | Result | Detail | Time (s) | Log |
|---|---|---|---|---|---|
| lint | MIN, behavioural pads | PASS | 0 warnings in rtl/ + sim/, 0 errors | 5.5 | `reports/rtl/sim/lint_sim_0.log` |
| lint | MIN, IHP pad cells (vendor model) | PASS | 0 warnings in rtl/ + sim/, 0 errors | 5.3 | `reports/rtl/sim/lint_ihpsim_1.log` |
| lint | HPC + simulated controller / PHY | PASS | 0 warnings in rtl/ + sim/, 0 errors | 12.9 | `reports/rtl/sim/lint_sim_2.log` |
| refusal | PCIe without PHY / controller IP | PASS | exit 1, message found: 'PCIE-PHY' | 1.0 | `reports/rtl/sim/refuse_0.log` |
| refusal | memory controller VENDOR without IP | PASS | exit 1, message found: 'MEM-CTRL' | 0.9 | `reports/rtl/sim/refuse_1.log` |
| refusal | HPC die without a memory controller | PASS | exit 1, message found: 'needs an external-memory controller' | 1.1 | `reports/rtl/sim/refuse_2.log` |
| refusal | MEM_CTRL = SIM without the simulation models | PASS | exit 1, message found: 'simulation-only models' | 1.1 | `reports/rtl/sim/refuse_3.log` |
| refusal | behavioural pads in an implementation build | PASS | exit 1, message found: 'SIMULATION ONLY' | 0.9 | `reports/rtl/sim/refuse_4.log` |
| refusal | IHP pad with a drive strength the library lacks | PASS | exit 1, message found: '4 / 16 / 30' | 0.6 | `reports/rtl/sim/refuse_5.log` |
| refusal | illegal die configuration | PASS | exit 1, message found: 'DIE_CFG must be 0' | 0.8 | `reports/rtl/sim/refuse_6.log` |
| build | verilator min (sim) | PASS | exit 0 | 210.3 | `reports/rtl/sim/build_min.log` |
| sim | min / all | PASS | 663 checks, 0 fails | 14.7 | `reports/rtl/sim/min_all.log` |
| sim | min / reset | PASS | 144 checks, 0 fails | 2.8 | `reports/rtl/sim/min_reset.log` |
| sim | min / firmware | PASS | 8025 checks, 0 fails | 98.0 | `reports/rtl/sim/min_firmware.log` |
| build | verilator min_ihp (ihpsim) | PASS | exit 0 | 224.4 | `reports/rtl/sim/build_min_ihp.log` |
| sim | min_ihp / all | PASS | 663 checks, 0 fails | 14.4 | `reports/rtl/sim/min_ihp_all.log` |
| build | verilator hpc_nomem (sim) | PASS | exit 0 | 235.7 | `reports/rtl/sim/build_hpc_nomem.log` |
| sim | hpc_nomem / mem_absent | PASS | 29 checks, 0 fails | 26.3 | `reports/rtl/sim/hpc_nomem_mem_absent.log` |
| build | verilator hpc_memsim (sim) | PASS | exit 0 | 245.4 | `reports/rtl/sim/build_hpc_memsim.log` |
| sim | hpc_memsim / memsim | PASS | 44 checks, 0 fails | 9.5 | `reports/rtl/sim/hpc_memsim_memsim.log` |
| sim | hpc_memsim / all | PASS | 663 checks, 0 fails | 125.2 | `reports/rtl/sim/hpc_memsim_all.log` |
| sim | hpc_memsim / memcalfail | PASS | 14 checks, 0 fails | 23.0 | `reports/rtl/sim/hpc_memsim_memcalfail.log` |
| build | icarus min (sim) | PASS | exit 0 | 0.6 | `reports/rtl/sim/build_icarus.log` |
| sim | icarus min / reset | PASS | 143 checks, 0 fails | 388.2 | `reports/rtl/sim/icarus_reset.log` |
| sim | icarus min / hostlink | PASS | 106 checks, 0 fails | 184.2 | `reports/rtl/sim/icarus_hostlink.log` |
| sim | icarus min / jtag | PASS | 62 checks, 0 fails | 138.2 | `reports/rtl/sim/icarus_jtag.log` |

**26 / 26 items pass**; simulations: 11 / 11 runs, 10556 self-checks.
