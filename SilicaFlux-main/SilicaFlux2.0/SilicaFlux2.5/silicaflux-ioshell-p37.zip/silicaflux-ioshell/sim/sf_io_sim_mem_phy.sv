// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: sf_io_sim_mem_phy -- PHY STATUS MODEL
// Aureom.AI | SilicaFlux-HPC
//
//   *** SIMULATION ONLY.  NOT A PHY.  No DQ/DQS path, no training algorithm, no
//   *** analog behaviour: it reproduces the STATUS SEQUENCE a PHY exposes so the
//   *** shell's PHY-status plumbing (SHELL.MEM_PHY, controller gating, bridge
//   *** link FSM) can be verified. ***
//
//   phy_rst_n low -> RESET; release -> INIT (INIT_CYCLES) -> CAL (CAL_CYCLES)
//   -> READY (cal_done, init_complete)  or  CALFAIL (cal_fail, cal_err_code).
//   cal_req in READY re-enters CAL.
//   Plusargs: +SF_IO_MEMPHY_CALFAIL=<code>  calibration fails with <code> (!= 0)
// Classification: SIMULATION ONLY
// =============================================================================
`include "sf_io_defs.svh"
`default_nettype none

module sf_io_sim_mem_phy
  import sf_io_mem_pkg::*;
#(
  parameter int INIT_CYCLES = 8,
  parameter int CAL_CYCLES  = 48
) (
  input  wire logic            clk,
  input  wire mem_phy_rst_t    rst_i,
  input  wire mem_phy_cal_t    cal_i,
  input  wire mem_phy_clk_t    clk_i,
  output mem_phy_status_t      status_o
);
`ifdef SF_IO_ASIC_IMPL
  `SF_IO_ELAB_FATAL("sf_io_sim_mem_phy is a SIMULATION-ONLY status model")
`endif

  int unsigned fail_code;
  initial begin
    fail_code = 0;
    void'($value$plusargs("SF_IO_MEMPHY_CALFAIL=%d", fail_code));
  end

  mem_phy_state_e st;
  int unsigned    cnt;
  logic           fail_q;
  logic [7:0]     code_q;

  always_ff @(posedge clk or negedge rst_i.phy_rst_n) begin
    if (!rst_i.phy_rst_n) begin
      st <= PHY_RESET; cnt <= 0; fail_q <= 1'b0; code_q <= 8'd0;
    end else begin
      unique case (st)
        PHY_RESET:   begin st <= PHY_INIT; cnt <= 0; end
        PHY_INIT:    if (cnt + 1 >= INIT_CYCLES) begin st <= PHY_CAL; cnt <= 0; end else cnt <= cnt + 1;
        PHY_CAL:     if (cnt + 1 >= CAL_CYCLES) begin
                       if (fail_code != 0) begin st <= PHY_CALFAIL; fail_q <= 1'b1; code_q <= 8'(fail_code); end
                       else st <= PHY_READY;
                       cnt <= 0;
                     end else cnt <= cnt + 1;
        PHY_READY:   if (cal_i.cal_req) begin st <= PHY_CAL; cnt <= 0; end
        PHY_CALFAIL: ;
        default:     st <= PHY_RESET;
      endcase
    end
  end

  assign status_o = '{present: 1'b1, init_complete: (st == PHY_READY), cal_busy: (st == PHY_CAL),
                      cal_done: (st == PHY_READY), cal_fail: fail_q, cal_err_code: code_q, state: st};

  wire unused_ok = &{1'b0, cal_i.init_start, clk_i, rst_i.ctrl_rst_n};
endmodule

`default_nettype wire
