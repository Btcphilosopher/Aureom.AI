# 00 — Repository audit (brief §1)

Everything below was checked against the archives in the Aureom.AI checkout (`SilicaFlux-main/...`), not
against earlier prompts. Classification: **available** (RTL / collateral exists and was used), **verified**
(has passing evidence), **absent** (nothing exists), **incompatible** (exists, cannot be connected as is).

## 1. What the shell has to wrap

| Item | Where | Finding | Use in Project 37 |
|---|---|---|---|
| `silicaflux_die_top.sv` | `silicaflux-dietop-p31.zip` (P31) | 59 ports: `clk_i`, `por_ni`, `pll_lock_i`, `test_mode_i`, `boot_mode_i`, `host_rst_req_i`, an SFB2 host slave port, `host_irq_o`, `platform_ready_o`, `device_ready_o`, the SFMC memory-controller port (`mc_*`, 26-bit address, 2-bit tags), JTAG pins **reserved and inactive** (`tdo_o = 0`), board RAS, diagnostics (`diag_*`, `test_*`, `cpu_sleep_o`). MIN and HPC configuration wrappers. | Vendored **unmodified** (rtl + its 232 vendored files); wrapped by `sf_io_die_core`; every port traced (rule V6, `docs/generated/IO_INVENTORY.md` §5). |
| Host port semantics | P31 `host_io_subsystem` | One transaction at a time; addresses outside the ControlCore regions and `0x2000_0000-0x3FFF_FFFF` get a local decode error. `0x5000_0000` is unmapped. | The shell window `0x5000_0000-0x5000_FFFF` is decoded **before** the die. |
| Readiness | P31 `die_sysctrl` | `PLATFORM_READY = RESET_DONE & FABRIC_READY & MEM_READY & EXTMEM_READY & CC_RUNNING & COMPUTE_READY`. **The HPC die's PLATFORM_READY needs the external-memory link** (EXTMEM_READY is 1 only when EXTMEM is absent). | Finding F1 below. |
| External-memory bridge | P24, inside P31 | Link FSM RESET → CAL → READY; P31 builds it with `CAL_TIMEOUT = 0` ("wait forever"); accesses while not READY are answered UNAVAIL. Only a **simulation** controller exists (`extmem_sim_mc`). | SFMC terminated in `sf_io_mem_boundary`; SIM slot uses `extmem_sim_mc` (simulation only). |
| JTAG | P31 pins reserved; TestCore (P07) `tc_top` refused by P31 because it owns the clock root | `tc_tap` (16-state TAP, IR 5 bits, IDCODE, BYPASS, external DR hooks) and `tc_bsr` (parameterised BSR, SAMPLE / PRELOAD / EXTEST / CLAMP / HIGHZ) **own no clock**: they run on TCK only. Byte-identical copies in P31's tree. | Used unmodified in `sf_io_jtag`; the die's JTAG pins are tied off. |
| Clock / reset | P35 `silicaflux_clock_reset_tree` | Reference clock + core clock, PLL-lock input, frequency qualification against the reference, ordered fabric → ControlCore release with acknowledgements, cause log, watchdog, register bus. P35's integration note maps it onto P31 but it was never simulated with the die. | Instantiated unmodified as the chip's clock / reset root in front of the die (§3 of docs/02). |
| PLL | — | **Absent** (no PLL in the repository or the open PDK). | `CLK_CORE` is an external clock with a `CLKGEN_LOCK` input; P35 qualifies it. |
| GPIO / UART / SPI | MCU-I (`mcu_gpio`, `mcu_uart`, `mcu_spi`), SilicaFlux-V (`sfv_*`) | Verified register-bus peripherals (one-cycle select, combinational read). **The P31 die exposes none of them and has no outbound peripheral master**: firmware can reach nothing outside the die except the DIAG_TX console stream. | MCU-I peripherals in the shell, host-owned through the shell window; DIAG_TX forwarded to the UART (finding F3). |
| PCIe host bridge | P25 HostLink | BAR register ABI, queues, DMA engine, MSI requests behind a **generic AXI endpoint boundary**; contains no PCIe protocol logic. Endpoint IP, PHY and boards: **absent**. | Endpoint boundary typed in `sf_io_pcie_pkg`; the slot is refused at elaboration without IP (docs/04). |
| Interrupts | P31 `host_irq_o` (die IRQ routing + mailbox) | Level, single output. | One of ten sources of `HOST_IRQ_N` (pseudo open drain). |
| Power domains | P36 | One supply domain implemented; IHP has no power-management cells. | Core VDD / VSS + IOVDD / IOVSS only; no switchable domain in the ring. |
| Package | P29 PackageTwin | Wire-bond QFN reference (assumed 8 VDD + 8 VSS, 80 um in-line pitch, one I/O supply pair per 6 signals) and an FCBGA option with an **assumed** 200 um C4 pitch ("IHP MPW dies need third-party wafer bumping"). **No package drawing exists.** | Planning rules with provenance in `config/io_inventory.yaml`; package pins left UNASSIGNED. |
| Physical die | FloorplanLab (P05) | The only SilicaFlux core with a PDK floorplan is `sfv_soc_df` (IHP SG13G2, core 2738.40 x 2740.50 um, no pad ring). The P31 die was never mapped to a PDK (behavioural SRAMs). | Reference core outline for the pad-ring floorplan; the P31 die is represented by an abstract block (a reservation). |

## 2. Pad / ESD / PHY collateral

| Item | Finding |
|---|---|
| IHP SG13G2 I/O library `sg13g2_io` | **Available**: LEF, Liberty (typ / slow / fast), Verilog functional model, GDS, CDL, SPICE in IHP-Open-PDK (Apache-2.0). Vendored from ORFS `bfcc1895` (the revision P35 pinned); the LEF is byte-identical to IHP-Open-PDK `e73adb40`. Cells: `IOPadIn`, `IOPadOut{4,16,30}mA`, `IOPadTriOut{4,16,30}mA`, `IOPadInOut{4,16,30}mA`, `IOPadAnalog`, `IOPadVdd/Vss/IOVdd/IOVss`, `Corner`, `Filler{200..10000}`; site `sg13g2_ioSite` 1 x 180 um; every pad cell **80 x 180 um**; corner 180 x 180 um; `bondpad_70x70`. 3.3 V I/O, 1.2 V core. |
| What the cells do **not** have | No internal pull-up / pull-down, no Schmitt-trigger or slew control, no input enable, no clock-specific receiver. The vendor's input characterisation is a simulation notebook (100 MHz target). Wire-bond only. |
| ESD | The cells contain the vendor's protection structures, but the open collateral contains no ESD design manual and the open flow no ESD check: **the SilicaFlux ring is not ESD-qualified** (dependency IO-ESD). |
| PCIe / DDR / HBM PHY | **Absent** in the repository and in the open PDK. |
| Seal ring | ORFS reference values only (`IO_SEALRING_OFFSET` 70 um); the IHP rule was not checked. |

## 3. Tools available here

Verilator 5.020, Icarus 12, Yosys 0.33 (Ubuntu apt, the versions of P31 / P35); OpenROAD
2.0-12331-g6011bbe77 (FloorplanLab's pinned conda build, with the ICeWall pad commands); sv2v v0.0.12
(GitHub release, SHA-256 `ff8c9eea...a00`, for Yosys only).

## 4. Findings that shaped the design

* **F1 — HPC needs external memory to become ready.** Without a memory controller + PHY the HPC die can
  never assert PLATFORM_READY. The shell therefore defaults to the MIN die for milestone A and **refuses**
  `DIE_CFG = HPC, MEM_CTRL = NONE` at elaboration unless `ALLOW_NO_EXTMEM = 1` (diagnostic build), and offers
  `SHELL.CTRL.DIE_FORCE` so a host can still read the die's own diagnosis (verified, test `mem_absent`).
* **F2 — TestCore can be used without its clock root.** `tc_tap` + `tc_bsr` give the chip a working TAP and a
  61-cell boundary-scan register without touching the die's clocking (P31's reason for refusing TestCore does
  not apply to these two modules).
* **F3 — The die has no outbound peripheral path.** Management peripherals are host-owned; the firmware
  console (DIAG_TX) is the only firmware output and is carried to `UART_TX` (dependency DIE-PERIPH).
* **F4 — No pull resistors in the pad cells.** TMS / TDI / RST_N / UART_RX / chip selects need board pulls
  (inventory column "Board requirement").
* **F5 — The die is core-limited.** Around the FloorplanLab core, a real `sg13g2_io` ring has 140 slots; the
  milestone-A plan uses 73 (docs/07). The ring adds 3.89 mm² to the die.
* **F6 — Simulator semantics.** Verilator (2-state) applies asynchronous resets only on edges and resolves
  tri-states to 0 internally; the testbench accounts for both (POR edge at t = 1 ns, released pads checked
  through the pad enables) and Icarus (4-state) covers power-on from X and real Z.
