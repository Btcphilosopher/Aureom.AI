# 11 — Limitations and open items

This list states what the deliverable does **not** establish. Each item names the dependency that closes it
(see [generated/PHY_DEPENDENCY_REGISTER.md](generated/PHY_DEPENDENCY_REGISTER.md)).

## Silicon / technology

| # | Limitation | Closes with |
|---|---|---|
| L1 | **No ESD qualification.** The `sg13g2_io` cells carry the vendor's protection, but no ESD path / latch-up check was run on the ring and no ESD design manual is in the open collateral. | IO-ESD |
| L2 | **The behavioural pad layer is not silicon.** It is refused in every implementation build (`SF_IO_ASIC_IMPL`). | — (by design) |
| L3 | **No PLL.** `CLK_CORE` comes from the board; `CLKGEN_LOCK` is a board signal standing in for a lock detector. | PLL |
| L4 | **No PCIe, no DDR / HBM.** Boundaries are typed; controller and PHY slots are empty; `PCIE_EN = 1` and `MEM_CTRL = VENDOR` are refused. No PCIe generation or memory standard is claimed. | PCIE-CTRL, PCIE-PHY, MEM-CTRL, MEM-PHY |
| L5 | **The pad library's electrical limits** (no pulls, no Schmitt input, no slew control, 4 / 16 / 30 mA only) are pushed to the board. Drive strengths (all 4 mA) are placeholders without a load / SI analysis. | board design, SI |
| L6 | **Supply-pad counts are planning assumptions** (one IOVDD / IOVSS pair per six signals, 8 + 8 core), not SSO / IR / EM results. | foundry SSO rules + PI analysis |
| L7 | **Seal ring offset (70 µm) and core-to-ring gap are ORFS defaults**, not checked against the IHP rule deck. | SEALRING |
| L8 | **No package.** Package pins are UNASSIGNED; bond-pad spacing (20 µm closest) and wire geometry are not checked against assembly rules. | PKG |

## Physical

| # | Limitation |
|---|---|
| L9 | The P31 die has no PDK mapping (behavioural SRAMs). The floorplan reserves it as an abstract block derived from FloorplanLab's `sfv_soc_df` core outline; the real die outline will differ. |
| L10 | Placement only: the pad nets and the shell are not routed; no GDS, DRC, LVS, antenna or timing sign-off. The shell's standard cells are placed (OpenROAD global + detailed placement) inside a north strip. |
| L11 | Timing: no SDC-based sign-off of pad-to-core paths was attempted (the die itself is a black box in the physical netlist). |

## Logic / verification

| # | Limitation |
|---|---|
| L12 | The **SPI host link** is the milestone-A transport: one transaction at a time, f_SCK ≤ f_CLK_CORE / 8, no CRC on the wire (framing and speed errors are detected; bit errors in data are not). |
| L13 | **JTAG** is IEEE 1149.1-style: IDCODE / BYPASS / SAMPLE / PRELOAD / EXTEST / CLAMP / HIGHZ tested in simulation and a BSDL is generated and self-checked, but no commercial BSDL compliance checker or tester was run. The five TAP pins have no boundary-scan cell (as the standard requires); every other pad has one. |
| L14 | **No scan insertion**: SCAN_* pins are reserved on GPIO but the multiplexing is not built (DFT-SCAN). |
| L15 | **Management peripherals are host-owned**: the die's firmware cannot reach UART / SPI / GPIO (it has no outbound master); only the DIAG_TX console stream is forwarded (DIE-PERIPH). |
| L16 | **Memory calibration failure raises no interrupt** by itself: `IRQ_STATUS.MEM_EVT` follows the controller's `init_done` / `fatal`; the PHY status is polled in `SHELL.MEM_PHY`. A vendor controller is expected to escalate calibration failure to `mc_fatal`. |
| L17 | The JTAG status DR samples 32 quasi-static bits into TCK with per-bit synchronisers: not a coherent snapshot. |
| L18 | **Simulator semantics**: Verilator (2-state) runs most tests; released pads are checked through their enables there and as real Z in Icarus. The memory "SIM" configuration uses simulation models only (P24 `extmem_sim_mc`, `sf_io_sim_mem_phy`). |
| L19 | The P35 clock-qualification window (±40 % in the testbench) is board-dependent and must be set for the real clocks. |
| L20 | **The firmware console is best effort.** The die's DIAG_TX stream has no backpressure; the shell pushes it into the 16-entry UART TX FIFO, which drops characters when full (sticky `UART.STATUS.TX_OVF`). At the fastest UART setting (4 clocks / bit) the boot banner of the real firmware already overflows (404 of 479 characters arrive, in order); at a board baud rate most of a burst is lost. A die revision with a console-ready flag, or a deeper console buffer, closes it (DIE-PERIPH). |
