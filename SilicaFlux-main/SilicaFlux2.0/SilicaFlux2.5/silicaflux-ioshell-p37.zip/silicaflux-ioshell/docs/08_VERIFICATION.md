# 08 — Verification (brief §10)

## 1. Set-up

* **DUT = the whole chip**: `silicaflux_io_shell` with the **real P31 die** (ControlCore, fabric, compute,
  P24 bridge), the P35 clock / reset tree, TestCore TAP / BSR and the MCU-I peripherals. The testbench
  (`tb/tb_io_shell.sv`) touches **pads only**: board models for the clocks, POR supervisor, clock-generator
  lock, straps, an SPI host master, a JTAG probe, a UART terminal, an SPI loopback and GPIO drivers. Fault
  injection uses `force` on a few internal nets; monitors read the hierarchy without driving it.
* **Continuous checkers in every test**: DataFabric's `sfb_protocol_checker` on the host-link master, the shell
  window and the die host port; no X on any driven pad after reset; no contention on GPIO.
* **Builds**: `min` (MIN die, behavioural pads), `min_ihp` (MIN die, **IHP `sg13g2_io` cells with the vendor
  Verilog model**), `hpc_nomem` (HPC die, empty memory slot, `ALLOW_NO_EXTMEM`), `hpc_memsim` (HPC die,
  simulation-only controller + PHY model), and an Icarus build (4-state) for X / Z behaviour.

## 2. Brief §10 → tests

| Brief item | Test(s) | What is shown |
|---|---|---|
| direction | `direction` | inputs never driven by the chip; outputs driven; tri-state / pseudo-open-drain pads released when idle (HOST_MISO, TDO, HOST_IRQ_N, RAS_FATAL_N); GPIO follows OE; straps latched (pad toggles in mission mode do not reach the die) |
| reset propagation | `reset` (+ Icarus `reset`) | pad reset states with **no clocks**; shell and die resets asserted without clocks; die released after the shell; PLATFORM_READY after the sequence; RST_N warm reset; POR resets the TAP. Icarus: power-on from X, released pads at real Z |
| clock status | `clock` | no core clock → shell held in reset, JTAG status shows the reference clock and WAIT_CLK; core clock lost / restored; lock lost / restored; out-of-range clock refused; CRT status bits |
| JTAG | `jtag` (+ Icarus) | IR capture, IDCODE, BYPASS, unassigned opcode → BYPASS, SAMPLE of inputs and output data / control cells, PRELOAD + EXTEST (pads forced, GPIO pattern, capture), CLAMP, HIGHZ, TC_STATUS DR, TRST, operation with no core clock |
| GPIO | `gpio` | OUT / OE / IN through the pins, released on OE = 0, board-driven inputs seen |
| UART / SPI / console | `uart`, `mspi`, `console` | TX / RX through the pins at a programmed baud rate; SPI master with a loopback; DIAG_TX console forwarded to UART_TX; CONSOLE_EN = 0 forwards nothing |
| interrupts | `irq` | die error → die IRQ → HOST_IRQ_N; board warning masked / unmasked; board fatal → die RAS → RAS_FATAL_N + HOST_IRQ_N; released after clear |
| PHY-model status | `memsim`, `memcalfail`, `mem_absent`, `deps` | SIM PHY: RESET → INIT → CAL → READY, controller ready only after calibration, traffic reaches the model; calibration failure reported with code and state, die not ready; empty slot: bridge waits in CAL, accesses UNAVAIL; `PHY_DEP` / `PCIE` registers show ABSENT / SIM_MODEL |
| invalid protocol | `hostlink` | every link error: unknown command, illegal strobe, wrong RESET key, truncated frame (inside a byte; inside the argument phase), over-speed SCK, launch while busy, bus errors (unmapped, misaligned, partial strobe, read-only, unknown page / offset); errors sticky and counted; refused frames have no side effect; a request back-pressured by the split is held until accepted (SFB2 R2) |
| IO-shell integration | `die`, `dieready`, `fence`, `firmware` | die identity and SRAM through the pins; refusal before PLATFORM_READY and DIE_FORCE; reset fence completes an outstanding die transaction with an error; **the real ControlCore firmware is loaded through the SPI pins**, boots, answers mailbox PING through HOST_IRQ_N, raises DEVICE_READY, prints on UART_TX (best effort: when the FIFO overflows the test requires the received characters to be an in-order subsequence of the DIAG stream, docs/11 L20), and SHUTDOWN reports on TEST_DONE / TEST_FAIL |
| missing pad / PHY dependencies | regression **refusals** | 7 configurations must stop at elaboration with the dependency named: PCIe without IP, memory VENDOR without IP, HPC without a memory controller, SIM without models, behavioural pads in an implementation build, an IHP drive strength the library lacks, an illegal die configuration |

## 3. Results

Full report: [`reports/rtl/regression.md`](../reports/rtl/regression.md) (logs in `reports/rtl/sim/`).
**26 / 26 items pass; 11 / 11 simulation runs, 10 556 self-checks, 0 failures.**

| Kind | Items | Result |
|---|---|---|
| Lint (Verilator `-Wall`, shell RTL) | MIN behavioural pads; MIN IHP cells + vendor model; HPC + SIM controller / PHY | 3 / 3, 0 warnings in `rtl/` and `sim/` |
| Refusals (elaboration must stop, dependency named) | 7 missing-dependency configurations | 7 / 7 |
| Verilator `min` | `all` 663, `reset` 144, `firmware` 8 025 checks | PASS |
| Verilator `min_ihp` (vendor `sg13g2_io` model) | `all` 663 checks | PASS |
| Verilator `hpc_nomem` | `mem_absent` 29 checks | PASS |
| Verilator `hpc_memsim` | `memsim` 44, `all` 663, `memcalfail` 14 checks | PASS |
| Icarus 12 (4-state) | `reset` 143, `hostlink` 106, `jtag` 62 checks | PASS |

### Mutation testing

[`reports/rtl/mutation.md`](../reports/rtl/mutation.md): 22 deliberate defects in the shell's own RTL
(host link, split, management, JTAG, top-level wiring, pad wrappers, memory slots), each compiled behind a
runtime selector into a copy of `rtl/`. **22 / 22 are detected; the three baselines pass.** Detection is by a
failing self-check, except M18 (SFB2 request withdrawn before acceptance), which the DataFabric protocol
checker stops with an R2 assertion, and M16 (TAP not reset by POR), where the TAP powers up in EXTEST and holds
PLATFORM_READY low: the silicon hazard the POR term prevents.

Four mutants survived the first complete run and each exposed a test gap, now closed:

| Mutant | Gap | Change |
|---|---|---|
| M05 truncated argument phase not flagged | FRAME is sticky and two FRAME cases ran back to back | errors cleared between the cases, FRAME checked after each |
| M14 BSR cells of HOST_SCK / HOST_MOSI crossed | both pads were 1 during SAMPLE | MOSI driven 0 during SAMPLE |
| M18 request withdrawn before acceptance | the link master was never back-pressured | new step: the split is quiesced under a pending READ; the request must be held and complete afterwards |
| M19 output wrapper ignores its enable | under Verilator, "released" was judged at the wrapper input | the released / driven checks read the enable that reaches the pad cell |

### Physical checker

The physical checks (docs/09) have their own seeded-fault self-test: 11 / 11 cases behave as required.

## 4. Simulator notes

* Verilator 5.020 is 2-state and applies asynchronous resets on edges only: the testbench gives POR a falling
  edge at t = 1 ns, and checks released pads through their enables (`RELEASED` macro). Icarus 12 (4-state)
  covers power-on from X and real Z on released pads (`reset`, `hostlink`, `jtag`).
* The X checker flags X only: Z on an output pad is legal while boundary scan releases it (HIGHZ, EXTEST), and
  only the 4-state run can see the difference.
* Icarus 12 restrictions the testbench respects (each one crashed or mis-elaborated `vvp` during development):
  no automatic queues / arrays, no bit-select of an automatic variable as a task output argument, no `ref`
  ports, no `force` on a variable driven through a port (such nets are declared `wire`).
* The SPI host link is oversampled; the testbench keeps f_SCK ≤ f_CLK_CORE / 8 except in the over-speed test.
* Timing values in the testbench (100 MHz core, reference and TCK periods) are simulation conveniences, not
  board requirements.
