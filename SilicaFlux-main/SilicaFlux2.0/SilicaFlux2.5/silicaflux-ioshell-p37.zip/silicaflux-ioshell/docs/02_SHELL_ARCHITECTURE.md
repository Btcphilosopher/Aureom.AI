# 02 — `silicaflux_io_shell` architecture (brief §3)

```
 pads (bond pads)      pad wrappers          boundary scan         functional blocks                    die
 ─────────────────     ────────────          ─────────────         ─────────────────                    ───
 CLK_REF CLK_CORE ──► sf_io_pad_clk ─┬───────────────────────► P35 clock/reset tree ── clk, rst_n ──► (shell)
 POR_N RST_N ──────► sf_io_pad_rst  │                            (qualifies CLK_CORE        └ cc_rst_no ─► por_ni
 CLKGEN_LOCK ──────► sf_io_pad_in   │  observe-only input          against CLK_REF)          clk ───────► clk_i
 TEST_MODE ────────► sf_io_pad_test (strap latch) ───────────────────────────────────────────────────► test_mode_i
 BOOT_MODE[1:0] ───► sf_io_pad_in + sf_io_strap_latch ─────────────────────────────────────────────────► boot_mode_i
 HOST_SCK/CS_N/MOSI► sf_io_pad_in ──┤  cells (BC_4)  ──────► sf_io_spi_host ─► sf_io_host_split ─┬► die host port (SFB2)
 HOST_MISO ◄─────── sf_io_pad_tri ◄─┤                                                            └► sf_io_mgmt (shell window)
 UART / MSPI / GPIO ◄► pad wrappers ◄┤  data + control    ◄──── sf_io_mgmt: mcu_uart / mcu_spi / mcu_gpio
 status / RAS pads ◄► pad wrappers  ◄┤  cells (BC_1)      ◄──── die platform/device ready, test, ras_fatal
 HOST_IRQ_N ◄─────── sf_io_pad_tri ◄─┘                    ◄──── IRQ aggregation (10 sources)
 TCK TMS TDI TRST_N ► pad wrappers ─► sf_io_jtag = tc_tap + tc_bsr (61 cells) + SHELL_STATUS DR
 TDO ◄────────────── sf_io_pad_tri
                                       sf_io_mem_boundary ◄── die SFMC (controller / PHY slots: empty in milestone A)
                                       sf_io_pcie_boundary  (typed endpoint interface; PCIE_EN = 0)
 supply pads: 34 x sf_io_pad_supply (IOVDD / IOVSS / VDD / VSS), rails by abutment
```

## 1. Interfaces and typing

* **Pads** are the top-level ports; their direction is the pad pin direction of the vendor cell (input,
  output — tri-state capable — or inout). Port names equal the inventory names and the physical netlist keeps
  them (rule P1).
* **Host-command path**: SFB2 (valid/ready request, valid/ready response) end to end — the same protocol as
  P31's host port, checked by DataFabric's `sfb_protocol_checker` on all three internal ports in every test.
* **Memory path**: SFMC (P24) on the die side; the PHY boundary is typed (`sf_io_mem_pkg`: PHY status,
  calibration, clocking, reset structs).
* **PCIe**: the endpoint user interface is typed (`sf_io_pcie_pkg`: BAR slave, DMA master, MSI, link status).
* **Register buses** inside `sf_io_mgmt` follow the MCU-I / SilicaFlux-V convention (one-cycle select,
  combinational data), so the MCU-I peripherals and P35's register file attach unmodified.

## 2. Clocks and resets

| Clock | Source | Users |
|---|---|---|
| `CLK_REF` | pad | P35 sequencer, clock monitors, watchdog; reference-toggle status for JTAG |
| `CLK_CORE` | pad (external generator; no PLL) | P35 qualifies it, opens the root ICG → `clk` for the shell and the die |
| `TCK` | pad | TAP, BSR, SHELL_STATUS DR only |
| HOST_SCK | pad | **not a clock**: oversampled by `clk` (f_SCK ≤ f_CLK_CORE / 8) |

| Reset | Source | Domain |
|---|---|---|
| `rst_n` (shell) | P35 `fab_rst_no` | asserted asynchronously by POR / RST_N / clock loss / lock loss / watchdog; released synchronously after the core clock is qualified |
| die `por_ni` | P35 `cc_rst_no` | released after the shell (verified order); the die's own sequencer then releases fabric → ControlCore |
| TAP | `TRST_N` AND `POR_N` | tc_tap requirement |
| straps | latched while `POR_N` is low | static afterwards |

The shell adds **no clock-domain crossing** beyond synchronisers: SPI inputs pass 2-flop synchronisers,
board RAS inputs too (the die synchronises its own copies), the die-reset input of the host split is
synchronised before use, P35's reference-domain sequencer state is synchronised per bit for status only,
and the JTAG status DR synchronises its 32 inputs into TCK (quasi-static, documented as not coherent).

## 3. Host-command path

* `sf_io_spi_host` — the milestone-A transport (protocol in [generated/REGISTERS.md](generated/REGISTERS.md)):
  framed SPI commands become SFB2 transactions; one transaction at a time; a launched transaction is never
  withdrawn (SFB2 R2) and its result survives an early CS_N (`RESULT`); errors FRAME / SPEED / CMD / BUSY /
  BUS are sticky and counted; a keyed `RESET` command pulses the die's `host_rst_req_i`.
* `sf_io_host_split` — shell window vs die; refuses die-bound traffic while the die is not ready (or not
  out of reset), completes a die transaction with an error if the die is reset under it (reset fence),
  supports P35's quiesce / idle handshake. `SHELL.CTRL.DIE_FORCE` lifts the readiness (never the reset)
  condition for bring-up.
* **PCIe (gated)**: HostLink's SFB2 master would become a second master in front of the split (an arbiter at
  that single point). Not built: no endpoint / PHY (docs/04).

## 4. Management window (`0x5000_0000`, 64 KiB)

SHELL page (identity, live status, control, IRQ aggregation, host-link and console counters, **PHY_DEP**
dependency register, MEM_PHY and PCIE status), and the MCU-I UART / GPIO / SPI and P35 CRT register pages.
Access rules: aligned, full-word writes; RO writes, unknown offsets / pages → error, no side effect.
`HOST_IRQ_N = CTRL.IRQ_PIN_EN & |(IRQ_STATUS & IRQ_ENABLE)` over: die IRQ (default enabled), GPIO, UART,
MSPI, P35 watchdog, board warning, board fatal, die RAS fatal, host-link errors, memory-controller events.

## 5. What reaches the die, and what does not

| Die port group | Connected to |
|---|---|
| clock, reset, PLL lock, test mode, boot mode | P35 / pads / strap latches |
| host SFB2 port, `host_irq_o`, `host_rst_req_i` | host split / IRQ aggregation / SPI RESET command |
| `platform_ready_o`, `device_ready_o`, `test_done_o`, `test_fail_o`, `ras_fatal_o` | pads (through boundary scan) + status |
| `diag_valid_o` / `diag_char_o` | console forwarder → UART TX FIFO |
| SFMC (`mc_*`) | `sf_io_mem_boundary` |
| JTAG (`tck_i` …) | tied off: the shell owns the TAP |
| `ext_warn_i`, `ext_fatal_i` | `BOARD_WARN_N`, `BOARD_FATAL_N` (inverted) |
| `test_code_o`, `cpu_sleep_o` | SHELL.DIE_TEST register only |

## 6. Parameters and refused builds

| Parameter | Values | Refused combinations (elaboration error, with the dependency named) |
|---|---|---|
| `DIE_CFG` | 0 MIN (default), 1 HPC | 2+; HPC with `MEM_CTRL = NONE` unless `ALLOW_NO_EXTMEM = 1` |
| `MEM_CTRL` | 0 NONE, 1 SIM, 2 VENDOR | SIM without `SF_IO_SIM_MODELS`; VENDOR without `SF_IO_HAVE_MEM_IP` |
| `PCIE_EN` | 0, 1 | 1 without `SF_IO_HAVE_PCIE_IP` |
| technology layer | `sim` / `ihp_sg13g2` | `sim` together with `SF_IO_ASIC_IMPL`; IHP drive strengths other than 4 / 16 / 30 mA |
| P35 qualification | `MON_WINDOW`, `CORE_CNT_MIN/MAX`, `QTIMEOUT` | — (board-dependent; the testbench uses ±40 %) |
