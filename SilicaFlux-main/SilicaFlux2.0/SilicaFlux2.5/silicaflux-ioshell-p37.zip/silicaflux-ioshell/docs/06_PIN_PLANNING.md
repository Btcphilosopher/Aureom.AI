# 06 — Pin planning and floorplan orientation (brief §7, §8)

## 1. Flow

```
config/io_inventory.yaml ─► scripts/pin_assign.py ─► physical/generated/padring.json        (plan: slots, sides, offsets)
                                                   ├► physical/generated/padring_place.tcl  (OpenROAD place_pad list)
                                                   ├► physical/generated/orfs_io.mk         (ORFS variables, if ORFS is used)
                                                   ├► physical/generated/pin_assignment.csv
                                                   ├► physical/generated/package_signal_map.csv + docs/generated/PACKAGE_SIGNAL_MAP.md
                                                   └► rtl/generated/sf_io_supply_pads.svh   (supply-pad instances, same names)
rtl/ ─► scripts/synth_phys.py (sv2v + Yosys, IHP cells) ─► build/phys/silicaflux_io_shell.v
        scripts/gen_core_abstract.py ─► die block abstract (LEF) for the P31 die
physical/padring.tcl (OpenROAD 2.0) ─► make_io_sites / place_pad / place_corners / place_io_fill /
        connect_by_abutment / place_bondpad / place_io_terminals ─► DEF + ODB
scripts/check_physical.py ─► P1–P11 (independent of OpenROAD)       scripts/report_pins.py ─► PIN_PLACEMENT.md, floorplan.svg
```

`make physical` runs the whole chain (`make zip` keeps the placed DEF, the physical netlist and the die-block
LEF in `physical/out/`); [`reports/physical/PIN_PLACEMENT.md`](../reports/physical/PIN_PLACEMENT.md)
lists every pad with its cell, net, side, die coordinates and bond-order index, and
[`floorplan.svg`](../reports/physical/floorplan.svg) draws it.

## 2. Placement rules (in the generator)

* Pads are grouped per side in the inventory order (`side`, `group`); supplies are interleaved: one IOVDD /
  IOVSS pair per started group of six signals (minimum one pair per side), core VDD / VSS spread evenly
  (8 + 8 total), an IOVSS pad next to every clock input (`CLK_REF`, `CLK_CORE`, `TCK`). These are
  **planning rules with recorded provenance** (PackageTwin assumptions), not foundry SSO / EM rules.
* Slots are spread over the usable side length at a whole-µm pitch (`floor(L / n)`), on the 1 µm IO site;
  the remainder becomes fillers. Index order runs west → east on N / S and north → south on E / W, so the
  first west-side slots (JTAG) sit at the north-west corner.
* Instance names are `pad_<PORT>` (bus bit `[i]` → `_i`) for signals and `pad_<KIND>_<SIDE><n>` for
  supplies; the RTL, the netlist, the DEF and the reports use the same names (rules P1–P3).

## 3. Orientation (brief §8)

| Side | Region | Contents | Reason |
|---|---|---|---|
| **North** | control | `CLK_REF`, `CLK_CORE`, `POR_N`, `RST_N`, `CLKGEN_LOCK`, straps, status outputs, RAS | the shell logic and the P35 clock / reset root are placed in the north strip directly inside this side, so the clock and reset inputs travel ~180 µm, not across the die |
| **West** | test / debug, management | JTAG first (north-west corner, first bond positions), then UART, MSPI, GPIO | accessible, low-speed, away from the planned high-speed sides; the management peripherals sit in the same north strip |
| **East** | host | host-command SPI + `HOST_IRQ_N`; reserved PCIe sideband; PCIe PHY (milestone B) | the host interface stays next to its controller region; a PCIe PHY would join on the same side |
| **South** | memory | supplies only; reserved for the DDR / HBM PHY (milestone B) | faces the die's memory subsystem; nothing low-speed occupies the PHY's edge |

**Long buses** are avoided by construction: every pad wire goes from the pad's core pin (on the ring's inner
edge) to logic in the north strip or to the die block's pins, which are grouped by the side of the pads they
serve (`gen_core_abstract.py`: W, N, E, S groups along the strip edge). No signal crosses the die. The SFB2
host port and the SFMC port are internal and never reach the ring.

## 4. The die block (abstract)

The P31 die has no PDK mapping, so the floorplan reserves it as a hard block (`sf_io_die_core`, 2738.4 x
2566.6 µm, from FloorplanLab's core outline minus a 173.88 µm north strip sized for the shell's 166 283 µm²
of standard cells at 35 % density). Its 278 pins are on the strip edge (Metal2, 8.64 µm pitch). When the die
gets a real implementation, its LEF replaces the abstract; nothing else in the flow changes.

## 5. Package signal map

[`PACKAGE_SIGNAL_MAP.md`](generated/PACKAGE_SIGNAL_MAP.md) lists every bond pad (signals and supplies) with
its net, cell, side, bond-pad centre and a counter-clockwise bond-order index starting at the north end of the
west side. **Package pins are UNASSIGNED**: there is no package drawing (dependency PKG). The map is the input a
package / bond-diagram engineer needs; nothing in it is a package decision.
