# 09 — Physical checks (brief §11)

`scripts/check_physical.py` re-derives every result from the DEF written by OpenROAD, the vendored LEFs, the
synthesised netlist and the inventory: it does **not** trust OpenROAD's own reports (kept separately in
`reports/physical/openroad/`). Results: [`reports/physical/PHYSICAL_CHECKS.md`](../reports/physical/PHYSICAL_CHECKS.md).

| Rule | Brief item | What is checked |
|---|---|---|
| P1 | pin names match the netlist | netlist port bits == inventory pad bits, names and directions |
| P2 | macro / pad compatibility | each pad instance: vendor master as planned (wrapper kind + drive), pad-pin net = its port, core pins connected as the wrapper requires |
| P3 | pin names match the netlist | DEF pad instances and terminals == netlist names (+ the four supply terminals created by `connect_by_abutment`) |
| P4 | permitted locations | every pad at its planned side, offset and row orientation |
| P5 | no overlaps | all placed instances (pads, corners, fillers, bond pads, die block, standard cells) pairwise, by sweep |
| P6 | ring legality | four corners; pads + fillers tile each side without gap or overlap |
| P7 | bond pads | one 70 × 70 µm bond pad per pad cell at the planned offset, inside the die, outside the IO cell; minimum spacing reported (assembly rules: PKG) |
| P8 | permitted layers | signal terminals on TopMetal2 over the pad pin at the outer edge; pad core pins on the ring's inner edge; die-block pins on tech-LEF routing layers |
| P9 | core / ring clearance | die block inside the core area; core area clear of the ring; every standard cell inside the core |
| P10 | P/G accounted for | supply pads per side and kind as planned; every ring cell's `vdd / vss / iovdd / iovss` on the right global net |
| P11 | unassigned pins reported | no unplaced terminal; every inventory signal without a pad listed with its status and dependency (19 entries: reserved / PHY-owned) |

## Does the checker catch faults?

`scripts/check_physical_selftest.py` copies the clean DEF / netlist, injects one fault at a time and requires
the expected rule to fail: pad moved by 1 µm (P4), filler removed (P6), bond pad removed (P7), standard cell
placed on the die block (P5), terminal renamed (P3), terminal on a wrong layer (P8), pad `vdd` pin off the VDD
rail (P10), pad with the wrong orientation (P4), supply pad removed (P10, P3), port direction flipped in the
netlist (P1); plus the clean case, which must pass. Result:
[`reports/physical/CHECKER_SELFTEST.md`](../reports/physical/CHECKER_SELFTEST.md) (11 / 11). P2, P9 and P11
have no seeded case (P2 and P9 are exercised only by the clean run).

## Not checked here

DRC and LVS of the GDS (no GDS is streamed: the die block is an abstract), antenna, ESD paths (IO-ESD),
seal-ring rules (SEALRING), bond-wire geometry and package rules (PKG), SSO / IR / EM on the I/O supplies
(the supply counts are planning assumptions). Routing of the pad nets is not done: placement is the milestone.
