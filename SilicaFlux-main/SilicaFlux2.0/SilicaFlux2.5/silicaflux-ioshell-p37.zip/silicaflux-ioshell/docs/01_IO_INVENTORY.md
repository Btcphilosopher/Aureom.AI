# 01 — External interface inventory (brief §2, §7)

The single source of truth is [`config/io_inventory.yaml`](../config/io_inventory.yaml). It is validated by
twelve rules (V1–V12, [`reports/inventory_check.md`](../reports/inventory_check.md)) and every derived artefact
is generated from it:

| Generated artefact | Generator | Content |
|---|---|---|
| [`docs/generated/IO_INVENTORY.md`](generated/IO_INVENTORY.md) | `scripts/gen_io.py` | the full tables: signal pads, reserved signals, PHY-owned pads / bumps, die-port traceability, BSR order |
| [`docs/generated/REGISTERS.md`](generated/REGISTERS.md) | `gen_io.py` | shell window, SHELL registers, host-link protocol |
| [`docs/generated/PHY_DEPENDENCY_REGISTER.md`](generated/PHY_DEPENDENCY_REGISTER.md) | `gen_io.py` | every PHY / IP / package dependency with status, evidence and the gate that closes it |
| `rtl/generated/sf_io_pkg.sv`, `sw/include/silicaflux_io_shell.h` | `gen_io.py` | BSR indices, window / register map, host-link codes |
| `tb/generated/tb_io_pads.svh` | `gen_io.py` | reset state of every driven pad, list of input pads (used by the tests) |
| `rtl/generated/sf_io_supply_pads.svh`, `physical/generated/*` | `scripts/pin_assign.py` | supply pads, pad-ring plan, OpenROAD placement, ORFS variables, package signal map |
| [`docs/generated/PACKAGE_SIGNAL_MAP.md`](generated/PACKAGE_SIGNAL_MAP.md) | `pin_assign.py` | bond pad → net, bond-order index, package pin (UNASSIGNED) |
| [`reports/bsdl/silicaflux_io_shell.bsd`](../reports/bsdl/silicaflux_io_shell.bsd) | `scripts/gen_bsdl.py` | BSDL of the shell's boundary scan |

## 1. Four kinds of entries (logical ports vs physical pads vs supply pins vs PHY-owned)

| Kind | Count | Physical form | Status |
|---|---|---|---|
| **Logical ports** of the die (`silicaflux_die_top`) | 59 ports | on-die nets; never a pad. The SFB2 host port and the SFMC memory port stay internal | traced one by one to the shell (V6) |
| **Signal pads** (milestone A) | 31 entries, 39 pads | one `sg13g2_io` cell + bond pad each; a top-level port of `silicaflux_io_shell` | ASSIGNED, placed |
| **Supply pads** | 34 (9 IOVDD, 9 IOVSS, 8 VDD, 8 VSS) | `sg13g2_IOPad{IOVdd,IOVss,Vdd,Vss}`, no logical port; rails by abutment | ASSIGNED, placed |
| **Reserved CMOS signals** | 6 entries, 8 bits (PCIe PERST#, WAKE#, CLKREQ#; scan enable / in / out) | 3.3 V CMOS, could use `sg13g2_io` | RESERVED (not instantiated) |
| **PHY-owned pads / bumps** | 13 entries (planning scenario: PCIe x4, DDR4 x16) | vendor PHY cells / bumps | BLOCKED |

## 2. Signal groups (milestone A)

| Group | Pads | Clock domain | Electrical class |
|---|---|---|---|
| Reference clocks | `CLK_REF` (reference, P35 sequencer), `CLK_CORE` (external functional clock; no PLL exists) | own clocks | 3.3 V CMOS clock input (`IOPadIn`) |
| Reset | `POR_N` (power-on), `RST_N` (warm) | asynchronous | 3.3 V CMOS input |
| Clock generator status | `CLKGEN_LOCK` (stands in for a PLL lock) | asynchronous → P35 | 3.3 V CMOS input |
| Straps | `TEST_MODE`, `BOOT_MODE[1:0]` (latched while POR is low) | asynchronous, static | 3.3 V CMOS input |
| JTAG / debug | `TCK`, `TMS`, `TDI`, `TRST_N`, `TDO` (tri-state) | TCK | 3.3 V CMOS |
| Management | `UART_TX/RX`, `MSPI_SCK/MOSI/MISO/CS_N`, `GPIO[7:0]` | core clock (inputs synchronised) | 3.3 V CMOS, 4 mA |
| Host command (low speed) | `HOST_SCK/CS_N/MOSI/MISO` (SPI target), `HOST_IRQ_N` | oversampled in the core clock | 3.3 V CMOS; IRQ pseudo open drain |
| Interrupt / status | `PLATFORM_READY`, `DEVICE_READY`, `TEST_DONE`, `TEST_FAIL`, `RAS_FATAL_N`, `BOARD_WARN_N`, `BOARD_FATAL_N` | core clock / asynchronous inputs | 3.3 V CMOS |
| Test access | JTAG + `TEST_MODE`; scan pins reserved on GPIO (no scan inserted) | | |
| Power / ground | `VDD` 1.2 V, `VSS`, `IOVDD` 3.3 V, `IOVSS` | | supply pads |

Every pad row in the generated table also carries: direction, wrapper, vendor cell, side, clock domain,
electrical class, reset state, boundary-scan class, function and the board requirement (pulls, levels).
