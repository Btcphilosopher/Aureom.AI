# 07 — I/O budget (brief §9)

The full, generated budget is [`reports/physical/IO_BUDGET.md`](../reports/physical/IO_BUDGET.md). Summary:

| Item | Value | Source |
|---|---|---|
| Required signal pads (milestone A) | **39** (15 N, 5 E, 0 S, 19 W) | inventory |
| of which clock inputs | 3 (`CLK_REF`, `CLK_CORE`, `TCK`) | inventory |
| of which test pins | 6 (`TEST_MODE`, `TRST_N`, `TCK`, `TMS`, `TDI`, `TDO`) | inventory |
| Supply pads | **34** (9 IOVDD, 9 IOVSS, 8 VDD, 8 VSS) | planning rules (assumed) |
| Reserved CMOS signals | 8 bits (PCIe PERST# / WAKE# / CLKREQ#; scan enable, 2 in, 2 out on GPIO) | inventory |
| PHY-owned (planning scenario) | PCIe x4: 18 + vendor analog / supply; DDR4 x16: 52 + vendor analog / supply | inventory, **BLOCKED** |
| Perimeter capacity (this die, abutted 80 µm cells) | **140** slots (35 per side) | LEF cell width × usable side length |
| Used | 73 (52 %), busiest side W 31 / 35 | OpenROAD placement, checked |
| Bump-array capacity (only if flip-chip) | 289 sites at 200 µm, range 169–484 for 250–150 µm | PackageTwin's **assumed** range, not a decision |

## What is not invented

* **Pad pitch.** Capacity is computed from the I/O cell width in the vendor LEF (80 µm, the minimum abutted
  pitch). Whether an assembly house can bond at that pitch, with which wire length and tiers, is open
  (dependency PKG). The placed pitch per side (90–467 µm) is simply the spread over the available edge.
* **Bump pitch.** `sg13g2_io` is a wire-bond library and no bumping process exists in the repository; the
  bump table spans PackageTwin's assumed range and is labelled as such.
* **Die size.** The core outline is FloorplanLab's `sfv_soc_df` core (the only SilicaFlux core with a PDK
  floorplan); the P31 die's own outline is unknown. The generator takes the outline as an input: the die is
  **core-limited** (spare 67 slots), so the outline, not the I/O count, sets the die size.

## Gated milestones against the perimeter

PHY-owned interfaces bring their own pad / bump structures, pitch and supplies; their perimeter cost cannot be
computed without the vendor map. What can be said: the PCIe sideband (3 CMOS pins) fits the 24 free east slots;
the south side is entirely free for a memory PHY.
