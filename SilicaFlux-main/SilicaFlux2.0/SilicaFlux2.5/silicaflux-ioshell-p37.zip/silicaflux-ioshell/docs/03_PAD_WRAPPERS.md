# 03 — Pad and PHY wrappers (brief §4)

## 1. Two layers

```
 silicaflux_io_shell ─► sf_io_pad_<role>  (rtl/pads/sf_io_pads.sv: role, polarity, strap latch)
                          └► sf_io_cell_<kind>  (technology layer, one of:)
                               rtl/pads/tech/sim/sf_io_cells_sim.sv        behavioural, SIMULATION ONLY
                               rtl/pads/tech/ihp_sg13g2/sf_io_cells_ihp.sv  IHP sg13g2_io vendor cells
```

| Wrapper | Role | Core-side ports | IHP cell | Notes |
|---|---|---|---|---|
| `sf_io_pad_in` | input | `p2c_o` | `sg13g2_IOPadIn` | |
| `sf_io_pad_clk` | clock input | `clk_o` | `sg13g2_IOPadIn` | the library has no clock receiver; the wrapper marks the clock net for constraints and substitution |
| `sf_io_pad_rst` | reset input | `rst_no` (active low), `raw_o` | `sg13g2_IOPadIn` | `ACTIVE_LOW` normalisation; no Schmitt input exists, so monotonic edges are a board requirement |
| `sf_io_pad_test` | test-mode input | `test_o` (latched), `raw_o` | `sg13g2_IOPadIn` + strap latch | latch transparent while POR is low: a glitch in mission mode cannot enter test mode (test mode bypasses reset synchronisers in P31 / P35). Verified; mutant M17 |
| `sf_io_pad_out` | output | `c2p_i`, `c2p_en_i` | `sg13g2_IOPadTriOut<n>mA` (`HIGHZ_CAPABLE = 1`) or `IOPadOut<n>mA` | every SilicaFlux output uses the tri-state cell so the boundary-scan control cell can release it (HIGHZ / EXTEST). Mutant M19 |
| `sf_io_pad_tri` | tri-state output | `c2p_i`, `c2p_en_i` | `sg13g2_IOPadTriOut<n>mA` | TDO, HOST_MISO, pseudo open drain (HOST_IRQ_N, RAS_FATAL_N: data 0, enable = assert) |
| `sf_io_pad_bidir` | bidirectional | `c2p_i`, `c2p_en_i`, `p2c_o` | `sg13g2_IOPadInOut<n>mA` | GPIO |
| `sf_io_pad_supply` | VDD / VSS / IOVDD / IOVSS | — | `sg13g2_IOPad{Vdd,Vss,IOVdd,IOVss}` | `(* keep *)`, no connections: rails by abutment, exactly like the ORFS reference design |

Drive strength is a wrapper parameter restricted to the cells that exist (4 / 16 / 30 mA); anything else
stops elaboration in the IHP layer (regression refusal "IHP pad with a drive strength the library lacks").
All milestone-A outputs use 4 mA: a placeholder pending board-load / SI analysis.

## 2. What is and is not claimed

* **Vendor cells are used only because their models and integration requirements are available**: LEF,
  Liberty, Verilog, GDS, CDL / SPICE under Apache-2.0; the integration rules followed are those of the ORFS
  `ihp-sg13g2` platform (`pad.tcl`): IO sites, corner cells, fillers, `connect_by_abutment`, bond pads at
  offset (5, −70) um.
* **The behavioural layer is not a pad.** It contains `assign`s only and carries a guard: compiled with
  `SF_IO_ASIC_IMPL` (every implementation flow defines it) elaboration stops with "behavioural pad models are
  SIMULATION ONLY and cannot be implemented" (regression refusal, verified).
* **No ESD qualification is claimed.** The IHP cells contain the vendor's protection; the SilicaFlux ring has
  not been ESD-verified (no ESD rule deck in the open collateral, no ESD check in the open flow). Dependency
  IO-ESD stays BLOCKED.
* **Electrical limits of the library** (no pulls, no Schmitt, no slew control, no input enable) are carried
  into the inventory as board requirements.

## 3. Simulating the real cells

`rtl/files_tech_ihpsim.f` compiles the IHP layer with the vendor functional model
(`third_party/ihp-sg13g2/verilog/sg13g2_io.v`); the whole test list runs on that build too (regression item
`min_ihp / all`). The physical netlist (`scripts/synth_phys.py`) instantiates the same cells: 73 pad cells,
renamed `pad_<NAME>`, checked against the inventory (rule P2).

## 4. PHY wrappers

There is no PHY to wrap. The PHY slots are the typed boundaries of docs/04 (PCIe) and docs/05 (memory); their
vendor branches exist only behind `SF_IO_HAVE_PCIE_IP` / `SF_IO_HAVE_MEM_IP` and stop elaboration otherwise.
