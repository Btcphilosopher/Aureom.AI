# 05 — External memory: controller vs PHY (brief §6)

## 1. Three blocks, three owners

```
 die (P31, unmodified)            shell: sf_io_mem_boundary                         outside
 ─────────────────────            ─────────────────────────                         ───────
 P24 extmem bridge ── SFMC ──►  controller slot ── DFI-like ──► PHY slot ──► PHY-owned pads / bumps
 (link FSM RESET→CAL→READY)       (MEM-CTRL)          typed       (MEM-PHY)      (DDR planning scenario,
                                                      boundary                    south side, BLOCKED)
```

* The **bridge** stays inside the die and is not touched. Its SFMC master port (26-bit address, 32-bit data,
  2-bit tags, separate read / write completions) leaves the die and ends in `sf_io_mem_boundary`.
* The **controller slot** is the SFMC slave. It must honour P24's rules C1–C11 (`docs/MC_INTERFACE.md` of P24).
* The **PHY slot** has a typed boundary in `sf_io_mem_pkg`:

| Boundary | Type | Fields |
|---|---|---|
| PHY status | `mem_phy_status_t` | `present`, `init_complete`, `cal_busy`, `cal_done`, `cal_fail` (sticky), `cal_err_code[7:0]`, `state` (ABSENT / RESET / INIT / CAL / READY / CALFAIL) |
| Calibration | `mem_phy_cal_t` | `init_start`, `cal_req` |
| Clocking | `mem_phy_clk_t` | `ref_clk_ok`, `phy_clk_ok`, `freq_ratio` (1:1 / 1:2 / 1:4) |
| Reset | `mem_phy_rst_t` | `phy_rst_n` (bridge controller-reset request AND shell reset: each bridge RESET re-trains the PHY), `ctrl_rst_n` |

Controller command / data use SFMC itself (not re-typed: it is P24's verified interface). The PHY data path
(DFI write / read data, DQS gating) is deliberately not declared: it belongs to the PHY vendor's DFI version.

## 2. Slot configurations (`MEM_CTRL`)

| Value | Controller | PHY | Behaviour (verified) |
|---|---|---|---|
| `NONE` (0, default) | none | none | `mc_init_done = 0`; the bridge waits in CAL (P31 builds it with `CAL_TIMEOUT = 0`), external-memory accesses are answered UNAVAIL; `SHELL.MEM_PHY = 0`; `PHY_DEP.mem_ctrl = mem_phy = ABSENT`. Test `mem_absent` (HPC + `ALLOW_NO_EXTMEM`) |
| `SIM` (1) | P24 `extmem_sim_mc` | `sf_io_sim_mem_phy` (status sequence RESET → INIT → CAL → READY, programmable latency) | **simulation only** (`SF_IO_SIM_MODELS`); the controller reports init_done only after the PHY reports `cal_done`; HPC die reaches PLATFORM_READY; a host read / write through the die reaches the model. Tests `memsim`, `all` on the HPC build |
| `SIM` + `+SF_IO_MEMPHY_CALFAIL=<code>` | as above | calibration fails | `cal_fail`, error code and state CALFAIL in `SHELL.MEM_PHY`, controller never initialised, bridge stays in CAL, die never PLATFORM_READY. Test `memcalfail` (mutant M22). `IRQ_STATUS.MEM_EVT` reports changes of the controller's `init_done` / `fatal` only, so a calibration failure that the controller does not escalate to `mc_fatal` raises no interrupt: the host polls `MEM_PHY` (open item in docs/11) |
| `VENDOR` (2) | licensed | licensed | refused unless `SF_IO_HAVE_MEM_IP` (regression refusal) |

## 3. Why the default is the MIN die (finding F1)

The HPC die's PLATFORM_READY includes EXTMEM_READY. With an empty slot it would never become ready, so:

* the default build uses `DIE_CFG = MIN` (no external-memory link);
* `DIE_CFG = HPC, MEM_CTRL = NONE` is refused unless `ALLOW_NO_EXTMEM = 1` (diagnostic build);
* `SHELL.CTRL.DIE_FORCE` lets the host reach the die's own registers while it is not ready (but never while it
  is in reset), so the cause can be read back.

## 4. HBM

No HBM PHY, interposer or package exists. HBM would replace the DDR planning scenario entirely (micro-bumps on
an interposer, not a perimeter ring); the controller slot and SFMC would be unchanged, the PHY boundary would
need the vendor's DFI / IEEE 1500 test port. Nothing is reserved for it in the ring.
