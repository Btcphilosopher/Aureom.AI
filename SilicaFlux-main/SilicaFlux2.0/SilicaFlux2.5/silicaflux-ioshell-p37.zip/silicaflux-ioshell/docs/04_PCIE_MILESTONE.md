# 04 — PCIe (brief §5): gated milestone B

## 1. What exists

| Layer | Status | Where |
|---|---|---|
| Host-side ABI (BAR0 registers, queues, DMA engine, MSI requests) | verified RTL, **no PCIe protocol logic** | P25 HostLink, behind a generic AXI endpoint boundary |
| Endpoint user interface (this project) | **typed, declared** | `rtl/pcie/sf_io_pcie_pkg.sv`: `pcie_bar_req_t / rsp_t` (BAR0 slave, 12-bit offset, 32-bit data), `pcie_dma_req_t / rsp_t` (host-memory master, 64-bit address / data, 4-bit ID), `pcie_msi_req_t`, `pcie_link_t` |
| Boundary module | built, `PCIE_EN = 0` | `rtl/pcie/sf_io_pcie_boundary.sv`: absent → `SHELL.PCIE = 0`, `PHY_DEP.pcie_ctrl = pcie_phy = ABSENT` (tested, `deps`) |
| Endpoint controller (DLL / TL / config space) | **BLOCKED** (PCIE-CTRL) | none in the repository |
| PHY / SerDes, reference-clock receiver | **BLOCKED** (PCIE-PHY) | none in the repository or the IHP open PDK |
| Sideband (PERST#, WAKE#, CLKREQ#) | RESERVED, 3.3 V CMOS, east side | inventory `reserved`; 24 free east slots |
| Lanes (TX / RX pairs x4, REFCLK) | BLOCKED planning scenario | inventory `phy_owned`, east side |

## 2. What is **not** claimed

Declaring an endpoint boundary claims nothing about PCIe generation, lane rate, width, encoding, equalisation
or compliance. The x4 lane count in the inventory is a **planning scenario** used only to reserve a side and
to count signals; it is not a specification. No PCIe 6.0 / 7.0 (or any other) operation is claimed, and
`pcie_link_t.speed_code` / `width` are raw IP fields with no meaning attached here.

`PCIE_EN = 1` stops elaboration unless `SF_IO_HAVE_PCIE_IP` is defined (regression refusal "PCIe without
IP", verified):

```
sf_io_pcie_boundary: PCIE_EN = 1 needs a licensed PCIe PHY + endpoint controller (dependencies PCIE-PHY, PCIE-CTRL): not available
```

## 3. Integration plan (when IP exists)

1. **Controller** whose user side matches `sf_io_pcie_pkg` (or an adapter to it); HostLink (P25) attaches to
   BAR / DMA / MSI unchanged.
2. **HostLink → die**: HostLink's SFB2 master becomes a second master in front of `sf_io_host_split` (one
   SFB2 arbiter at that single point; the split's readiness and reset fence then cover both masters). The SPI
   host link stays as the bring-up / management path.
3. **Sideband**: instantiate PERST# / WAKE# / CLKREQ# from the reserved entries (`sf_io_pad_rst` for PERST#,
   open-drain `sf_io_pad_tri` for WAKE# / CLKREQ#); PERST# joins P35 as a reset source of the PCIe domain only.
4. **PHY**: the vendor macro brings its own pads / bumps, analog supplies and reference-clock receiver; the
   inventory's `phy_owned` rows are replaced by the vendor map and `pin_assign.py` reserves the east edge for it.
5. **Gate to close**: controller + PHY netlists, bump / pad map, SI / PI channel model, compliance plan.
   Until then, `SHELL.PCIE` reads 0 and the build refuses `PCIE_EN = 1`.
