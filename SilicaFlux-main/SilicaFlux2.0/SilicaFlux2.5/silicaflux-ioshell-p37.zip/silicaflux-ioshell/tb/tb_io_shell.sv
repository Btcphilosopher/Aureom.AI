// =============================================================================
// SilicaFlux IOSHELL (Project 37) :: tb_io_shell -- chip-level testbench
// Aureom.AI | SilicaFlux-HPC
//
// The DUT is the whole chip: silicaflux_io_shell with the REAL P31 die inside.
// The testbench touches pads only (plus TB-only fault injection by `force`,
// and read-only hierarchical monitors).  Board models: reference / core / TCK
// clocks, POR supervisor, clock-generator lock, straps, SPI host master (host
// command link), JTAG probe, UART terminal, SPI loopback for the management
// SPI, GPIO drivers.
//
// Tests (+TEST=<name>, default all; firmware is long and separate):
//   reset      reset propagation: pad reset states without clocks, ordered release, RST_N, POR
//   direction  pad directions: inputs never driven by the chip, outputs / tri / od / bidir drive rules
//   clock      clock status: core clock absent / lost / out of range, lock loss, recovery, cause log
//   jtag       IDCODE, BYPASS, IR capture, SAMPLE, PRELOAD, EXTEST, CLAMP, HIGHZ, status DR, TRST, no core clock
//   hostlink   SPI link protocol + every invalid condition (cmd, strobe, key, frame, speed, busy, bus)
//   gpio uart mspi console irq     management peripherals and interrupts through the pins
//   die        integration: die identity, shared SRAM, die errors -> die IRQ -> HOST_IRQ_N
//   deps       PHY dependency register, version, PCIe status
//   fence      die reset while a die transaction is outstanding: completed with an error, no hang
//   dieready   die access between die release and PLATFORM_READY refused and counted; DIE_FORCE
//   mem_absent (HPC, no controller): PLATFORM_READY withheld, DIE_FORCE diagnosis, bridge waits in CAL
//   memsim     (HPC + simulation-only controller / PHY): calibration status, external-memory traffic
//   memcalfail (HPC + SIM, +SF_IO_MEMPHY_CALFAIL=7): failure reported, die not ready
//   firmware   real ControlCore firmware loaded through the SPI pins, console on UART_TX, mailbox IRQ pin
// Continuous checkers: SFB2 protocol (link master, shell window, die host port),
// no X on any driven pad after reset, GPIO contention.
// Result line: "TB RESULT PASS|FAIL checks=<n> fails=<n>".
// Classification: TESTBENCH
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

`ifndef TB_DIE_CFG
`define TB_DIE_CFG 0
`endif
`ifndef TB_MEM_CTRL
`define TB_MEM_CTRL 0
`endif
// hierarchical path of silicaflux_die_top inside the configuration wrapper (optional +trace only)
`ifndef TB_DIE_TOP
`ifdef TB_DIE_HPC
`define TB_DIE_TOP u_dut.u_die.g_hpc.u_die.u_die
`else
`define TB_DIE_TOP u_dut.u_die.g_min.u_die.u_die
`endif
`endif
`ifndef TB_ALLOW_NO_EXTMEM
`define TB_ALLOW_NO_EXTMEM 0
`endif

module tb_io_shell;
  import sf_io_pkg::*;
  import silicaflux_die_pkg::*;
  import cc_memmap_pkg::*;

  // ------------------------------------------------------------------ timing (simulation conveniences, no claim)
  localparam real T_REF  = 40.0;          // CLK_REF  25 MHz
  localparam real T_CORE = 10.0;          // CLK_CORE 100 MHz
  localparam real T_TCK  = 50.0;          // TCK      20 MHz
  localparam int  WIN    = 16;
  localparam int  CORE_EXP = 64;          // WIN * T_REF / T_CORE
  localparam logic [15:0] CNT_MIN = 16'd38, CNT_MAX = 16'd92;   // +-40 % qualification window
  localparam logic [31:0] SYS = DIE_DIE_REGS_BASE + 32'(DIE_REGS_PAGE_SYS) * 32'h1000;
  localparam logic [31:0] SH  = SHELL_BASE;
  localparam logic [4:0]  TC_IR_TC_STATUS_C = 5'h08;
  localparam int          XM_CAL = 1;                  // extmem_defs.svh XM_ST_CAL
  localparam logic [31:0] PG_UART = SHELL_BASE + 32'h1000, PG_GPIO = SHELL_BASE + 32'h2000,
                          PG_MSPI = SHELL_BASE + 32'h3000, PG_CRT = SHELL_BASE + 32'h4000;

  // ------------------------------------------------------------------ board drivers
  logic tb_float = 1'b0;                  // float every input pad (direction test)
  logic ref_run = 1'b0, core_run = 1'b0, tck_run = 1'b0;
  logic clk_ref_r = 1'b0, clk_core_r = 1'b0;
  real  core_half = T_CORE / 2.0;
  always begin #(T_REF / 2.0);  if (ref_run)  clk_ref_r  = !clk_ref_r;  end
  always begin #(core_half);    if (core_run) clk_core_r = !clk_core_r; end

  logic por_n_r = 1'b1, rst_n_r = 1'b1, lock_r = 1'b0, test_mode_r = 1'b0, warn_n_r = 1'b1, fatal_n_r = 1'b1;
  logic [1:0] boot_r = 2'b00;
  logic trst_n_r = 1'b1, tck_r = 1'b0, tms_r = 1'b1, tdi_r = 1'b1;
  logic uart_rx_r = 1'b1, sck_r = 1'b0, cs_n_r = 1'b1, mosi_r = 1'b0, mspi_loop = 1'b1;
  logic [7:0] gpio_en = 8'h00, gpio_val = 8'h00;

  // POR edge at t = 1 ns: Verilator (2-state) applies an asynchronous reset only on an edge, and the
  // TAP's only clock (TCK) is idle -- without this edge its IR would start at 0 (EXTEST).  Silicon
  // resets on the level; this is a simulator artefact, not a board requirement.
  initial begin #1; por_n_r = 1'b0; end
  wire       CLK_REF       = tb_float ? 1'bz : clk_ref_r;
  wire       CLK_CORE      = tb_float ? 1'bz : clk_core_r;
  wire       CLKGEN_LOCK   = tb_float ? 1'bz : lock_r;
  wire       POR_N         = tb_float ? 1'bz : por_n_r;
  wire       RST_N         = tb_float ? 1'bz : rst_n_r;
  wire       TEST_MODE     = tb_float ? 1'bz : test_mode_r;
  wire [1:0] BOOT_MODE     = tb_float ? 2'bzz : boot_r;
  wire       BOARD_WARN_N  = tb_float ? 1'bz : warn_n_r;
  wire       BOARD_FATAL_N = tb_float ? 1'bz : fatal_n_r;
  wire       TRST_N        = tb_float ? 1'bz : trst_n_r;
  wire       TCK           = tb_float ? 1'bz : tck_r;
  wire       TMS           = tb_float ? 1'bz : tms_r;
  wire       TDI           = tb_float ? 1'bz : tdi_r;
  wire       UART_RX       = tb_float ? 1'bz : uart_rx_r;
  wire       HOST_SCK      = tb_float ? 1'bz : sck_r;
  wire       HOST_CS_N     = tb_float ? 1'bz : cs_n_r;
  wire       HOST_MOSI     = tb_float ? 1'bz : mosi_r;
  wire       PLATFORM_READY, DEVICE_READY, TEST_DONE, TEST_FAIL, RAS_FATAL_N, TDO, UART_TX;
  wire       MSPI_SCK, MSPI_MOSI, MSPI_CS_N, HOST_MISO, HOST_IRQ_N;
  wire       MSPI_MISO     = tb_float ? 1'bz : (mspi_loop ? MSPI_MOSI : 1'b1);
  wire [7:0] GPIO;
  for (genvar i = 0; i < 8; i++) begin : g_gpio_drv
    assign GPIO[i] = gpio_en[i] ? gpio_val[i] : 1'bz;
  end

  // ------------------------------------------------------------------ DUT: the chip
  silicaflux_io_shell #(
    .DIE_CFG(`TB_DIE_CFG), .MEM_CTRL(`TB_MEM_CTRL), .ALLOW_NO_EXTMEM(`TB_ALLOW_NO_EXTMEM),
    .MON_WINDOW(WIN), .CORE_CNT_MIN(CNT_MIN), .CORE_CNT_MAX(CNT_MAX), .QTIMEOUT(1024)
  ) u_dut (
    .PLATFORM_READY, .DEVICE_READY, .TEST_DONE, .TEST_FAIL, .POR_N, .RST_N, .CLK_REF, .CLK_CORE, .CLKGEN_LOCK,
    .TEST_MODE, .BOOT_MODE, .RAS_FATAL_N, .BOARD_WARN_N, .BOARD_FATAL_N,
    .TRST_N, .TCK, .TMS, .TDI, .TDO, .UART_TX, .UART_RX, .MSPI_SCK, .MSPI_MOSI, .MSPI_MISO, .MSPI_CS_N, .GPIO,
    .HOST_SCK, .HOST_CS_N, .HOST_MOSI, .HOST_MISO, .HOST_IRQ_N);

  // ------------------------------------------------------------------ bookkeeping
  int    checks = 0, fails = 0;
  string cur_test = "-";
  longint cyc = 0;
  always @(posedge clk_core_r) cyc <= cyc + 1;

  task automatic check(input string what, input logic [31:0] got, input logic [31:0] exp);
    checks++;
    if (got !== exp) begin
      fails++;
      $display("[%0t] FAIL [%s] %s: got %h expected %h", $time, cur_test, what, got, exp);
    end
  endtask
  task automatic check1(input string what, input bit cond);
    checks++;
    if (!cond) begin fails++; $display("[%0t] FAIL [%s] %s", $time, cur_test, what); end
  endtask
  task automatic chk_pad(input string when, input string name, input logic v, input logic exp);
    checks++;
    if (v !== exp) begin
      fails++;
      $display("[%0t] FAIL [%s] pad %s (%s): %b expected %b", $time, cur_test, name, when, v, exp);
    end
  endtask
  // A released pad: real Z under 4-state simulators; under Verilator (2-state, tri-states resolved to 0
  // inside the model) the pad cell's enable is the observable, so that is what is checked there.
  task automatic chk_drv(input string when, input string name, input logic v, input logic en, input int exp);
    checks++;                                            // exp: 0 / 1 driven, -1 released
`ifdef VERILATOR
    if (exp < 0 ? (en !== 1'b0) : (en !== 1'b1 || v !== 1'(exp))) begin
`else
    if (exp < 0 ? (v !== 1'bz) : (v !== 1'(exp))) begin
`endif
      fails++;
      $display("[%0t] FAIL [%s] pad %s (%s): value %b enable %b, expected %0d (-1 = released)", $time, cur_test, name, when, v, en, exp);
    end
  endtask
  function automatic bit gpio_is(input logic [7:0] oe, input logic [7:0] val);
    bit ok;
    ok = 1;
    for (int i = 0; i < 8; i++) begin
`ifdef VERILATOR
      if (u_dut.p_io_oe[i] !== oe[i]) ok = 0;
      if (oe[i] && GPIO[i] !== val[i]) ok = 0;
`else
      if (oe[i] ? (GPIO[i] !== val[i]) : (!gpio_en[i] && GPIO[i] !== 1'bz)) ok = 0;
`endif
    end
    return ok;
  endfunction
`ifdef VERILATOR
`define RELEASED(NET, EN) ((EN) === 1'b0)
`else
`define RELEASED(NET, EN) ((NET) === 1'bz)
`endif
`include "tb_io_pads.svh"

  // ------------------------------------------------------------------ continuous checkers
  logic [31:0] v_hl, v_sh, v_die, n_hl_req, n_hl_rsp, out_hl, n_sh_req, n_sh_rsp, out_sh, n_die_req, n_die_rsp, out_die;
  sfb_protocol_checker #(.MAX_OUT(1), .NAME("hostlink")) u_chk_hl (
    .clk(u_dut.clk), .rst_n(u_dut.rst_n), .req_valid(u_dut.hl_req_valid), .req_ready(u_dut.hl_req_ready),
    .req_write(u_dut.hl_req_write), .req_addr(u_dut.hl_req_addr), .req_wdata(u_dut.hl_req_wdata),
    .req_wstrb(u_dut.hl_req_wstrb), .rsp_valid(u_dut.hl_rsp_valid), .rsp_ready(u_dut.hl_rsp_ready),
    .rsp_rdata(u_dut.hl_rsp_rdata), .rsp_error(u_dut.hl_rsp_error),
    .violations(v_hl), .n_req(n_hl_req), .n_rsp(n_hl_rsp), .outstanding(out_hl));
  sfb_protocol_checker #(.MAX_OUT(1), .NAME("shellwin")) u_chk_sh (
    .clk(u_dut.clk), .rst_n(u_dut.rst_n), .req_valid(u_dut.sh_req_valid), .req_ready(u_dut.sh_req_ready),
    .req_write(u_dut.sh_req_write), .req_addr(u_dut.sh_req_addr), .req_wdata(u_dut.sh_req_wdata),
    .req_wstrb(u_dut.sh_req_wstrb), .rsp_valid(u_dut.sh_rsp_valid), .rsp_ready(u_dut.sh_rsp_ready),
    .rsp_rdata(u_dut.sh_rsp_rdata), .rsp_error(u_dut.sh_rsp_error),
    .violations(v_sh), .n_req(n_sh_req), .n_rsp(n_sh_rsp), .outstanding(out_sh));
  wire die_chk_rst_n = u_dut.rst_n && u_dut.die_por_n;
  sfb_protocol_checker #(.MAX_OUT(1), .NAME("dieport")) u_chk_die (
    .clk(u_dut.clk), .rst_n(die_chk_rst_n), .req_valid(u_dut.die_req_valid), .req_ready(u_dut.die_req_ready),
    .req_write(u_dut.die_req_write), .req_addr(u_dut.die_req_addr), .req_wdata(u_dut.die_req_wdata),
    .req_wstrb(u_dut.die_req_wstrb), .rsp_valid(u_dut.die_rsp_valid), .rsp_ready(u_dut.die_rsp_ready),
    .rsp_rdata(u_dut.die_rsp_rdata), .rsp_error(u_dut.die_rsp_error),
    .violations(v_die), .n_req(n_die_req), .n_rsp(n_die_rsp), .outstanding(out_die));

  // no X on a driven pad once the shell is out of reset; no GPIO contention ever
  int xviol = 0;
  int xv_i;                                    // loop counters of static processes live at module level
  wire [7:0] xv_pp = {PLATFORM_READY, DEVICE_READY, TEST_DONE, TEST_FAIL, UART_TX, MSPI_SCK, MSPI_MOSI, MSPI_CS_N};
  logic xv_any;
  always @(posedge clk_core_r) begin
    // X only: Z is legal (boundary-scan HIGHZ / EXTEST release these pads; Verilator resolves Z to 0 anyway)
    if (u_dut.rst_n === 1'b1 && !tb_float) begin
      xv_any = 1'b0;
      for (xv_i = 0; xv_i < 8; xv_i++) if (xv_pp[xv_i] === 1'bx) xv_any = 1'b1;
      if (xv_any) begin
        xviol++; if (xviol < 5) $display("[%0t] FAIL X on a push-pull output pad (test %s): PLATFORM_READY %b DEVICE_READY %b TEST_DONE %b TEST_FAIL %b UART_TX %b MSPI_SCK %b MSPI_MOSI %b MSPI_CS_N %b",
                                         $time, cur_test, PLATFORM_READY, DEVICE_READY, TEST_DONE, TEST_FAIL, UART_TX, MSPI_SCK, MSPI_MOSI, MSPI_CS_N);
      end
    end
    for (xv_i = 0; xv_i < 8; xv_i++)
      if (GPIO[xv_i] === 1'bx) begin xviol++; if (xviol < 5) $display("[%0t] FAIL GPIO[%0d] contention / X", $time, xv_i); end
  end

  // ------------------------------------------------------------------ monitors
  logic [7:0] diag_q[$];                        // the die's DIAG_TX stream (read-only probe)
  string diag_line = "";
  always @(posedge u_dut.clk) if (u_dut.die_diag_valid === 1'b1) begin
    diag_q.push_back(u_dut.die_diag_char);
    if (u_dut.die_diag_char == 8'h0A) begin $display("[%0t] FW| %s", $time, diag_line); diag_line = ""; end
    else diag_line = {diag_line, string'(u_dut.die_diag_char)};
  end
  int rst_req_pulses = 0;
  always @(posedge u_dut.host_rst_req) rst_req_pulses++;

  // UART terminal on UART_TX
  real uart_bit_ns = 0.0;
  logic [7:0] uart_q[$];
  int  uart_frame_err = 0;
  logic [7:0] uart_c;
  int         uart_b;
  always begin
    @(negedge UART_TX);
    if (uart_bit_ns > 0.0 && u_dut.rst_n === 1'b1) begin
      #(uart_bit_ns * 1.5);
      for (uart_b = 0; uart_b < 8; uart_b++) begin uart_c[uart_b] = UART_TX; #(uart_bit_ns); end
      if (UART_TX !== 1'b1) uart_frame_err++;
      uart_q.push_back(uart_c);
      #(uart_bit_ns * 0.4);
    end
  end
  task automatic uart_send(input logic [7:0] c);
    uart_rx_r = 1'b0; #(uart_bit_ns);
    for (int b = 0; b < 8; b++) begin uart_rx_r = c[b]; #(uart_bit_ns); end
    uart_rx_r = 1'b1; #(uart_bit_ns * 2.0);
  endtask

  // ------------------------------------------------------------------ SPI host master (host-command link)
  real spi_half = 4.0 * T_CORE;          // f_SCK = f_core / 8
  task automatic spi_begin();
    cs_n_r = 1'b0; #(8.0 * T_CORE);
  endtask
  // bit-level engine: one process does the timed work, tasks only hand over a byte
  // (keeps Verilator from inlining the timed loop at every call site)
  logic [7:0] spi_tx_b, spi_rx_b;
  int  spi_req = 0, spi_ack = 0, spi_b;
  always begin
    wait (spi_req != spi_ack);
    for (spi_b = 7; spi_b >= 0; spi_b--) begin
      mosi_r = spi_tx_b[spi_b];
      #(spi_half);
      spi_rx_b[spi_b] = HOST_MISO;
      sck_r = 1'b1;
      #(spi_half);
      sck_r = 1'b0;
    end
    spi_ack = spi_req;
  end
  task automatic spi_byte(input logic [7:0] tx, output logic [7:0] rx);
    spi_tx_b = tx;
    spi_req  = spi_req + 1;
    wait (spi_ack == spi_req);
    rx = spi_rx_b;
  endtask
  task automatic spi_end();
    #(spi_half); cs_n_r = 1'b1; #(spi_half + 8.0 * T_CORE);
  endtask
  task automatic hl_begin(input logic [7:0] cmd);
    logic [7:0] r;
    spi_begin();
    spi_byte(cmd, r);
    check("link sync byte", 32'(r), 32'(HL_SYNC));
  endtask
  task automatic hl_poll(output logic [7:0] st);
    logic [7:0] r; int n;
    n = 0;
    r = 8'h00;
    while (!r[7] && n < 2000) begin spi_byte(8'h00, r); n++; end
    st = r;
  endtask
  task automatic hl_read(input logic [31:0] a, output logic [31:0] d, output logic [7:0] st);
    logic [7:0] r;
    hl_begin(HL_CMD_READ);
    for (int i = 3; i >= 0; i--) spi_byte(a[8 * i +: 8], r);
    hl_poll(st);
    d = '0;
    if (st == HL_ST_OK) for (int i = 0; i < 4; i++) begin spi_byte(8'h00, r); d = {d[23:0], r}; end
    spi_end();
  endtask
  task automatic hl_write(input logic [31:0] a, input logic [31:0] wd, input logic [3:0] strb, output logic [7:0] st);
    logic [7:0] r;
    hl_begin(HL_CMD_WRITE);
    for (int i = 3; i >= 0; i--) spi_byte(a[8 * i +: 8], r);
    spi_byte({4'h0, strb}, r);
    for (int i = 3; i >= 0; i--) spi_byte(wd[8 * i +: 8], r);
    hl_poll(st);
    spi_end();
  endtask
  task automatic rd(input logic [31:0] a, output logic [31:0] d);
    logic [7:0] st;
    hl_read(a, d, st);
    if (st != HL_ST_OK) begin fails++; checks++; $display("[%0t] FAIL [%s] read %h status %h", $time, cur_test, a, st); end
  endtask
  task automatic wr(input logic [31:0] a, input logic [31:0] d);
    logic [7:0] st;
    hl_write(a, d, 4'hF, st);
    if (st != HL_ST_OK) begin fails++; checks++; $display("[%0t] FAIL [%s] write %h status %h", $time, cur_test, a, st); end
  endtask
  task automatic rchk(input string what, input logic [31:0] a, input logic [31:0] exp);
    logic [31:0] d;
    rd(a, d);
    check(what, d, exp);
  endtask
  task automatic rchk_mask(input string what, input logic [31:0] a, input logic [31:0] mask, input logic [31:0] exp);
    logic [31:0] d;
    rd(a, d);
    check(what, d & mask, exp);
  endtask

  // ------------------------------------------------------------------ JTAG probe
  logic jt_tms, jt_tdi, jt_tdo;
  int   jt_req = 0, jt_ack = 0;
  always begin
    wait (jt_req != jt_ack);
    tms_r = jt_tms; tdi_r = jt_tdi;
    #(T_TCK / 2.0);
    jt_tdo = TDO;                           // sampled before the rising edge
    tck_r = 1'b1;
    #(T_TCK / 2.0);
    tck_r = 1'b0;
    jt_ack = jt_req;
  end
  task automatic jclk(input logic tms, input logic tdi, output logic tdo);
    jt_tms = tms; jt_tdi = tdi;
    jt_req = jt_req + 1;
    wait (jt_ack == jt_req);
    tdo = jt_tdo;
  endtask
  task automatic jtag_tlr();
    logic d;
    for (int i = 0; i < 6; i++) jclk(1'b1, 1'b1, d);
    jclk(1'b0, 1'b1, d);                    // Run-Test/Idle
  endtask
  task automatic jtag_ir(input logic [4:0] ir, output logic [4:0] cap);
    logic d;
    jclk(1'b1, 1'b1, d); jclk(1'b1, 1'b1, d);   // Select-DR, Select-IR
    jclk(1'b0, 1'b1, d); jclk(1'b0, 1'b1, d);   // Capture-IR, Shift-IR
    for (int i = 0; i < 5; i++) begin jclk(i == 4, ir[i], d); cap[i] = d; end   // Icarus: no bit-select as output arg
    jclk(1'b1, 1'b1, d); jclk(1'b0, 1'b1, d);   // Update-IR, RTI
  endtask
  task automatic jtag_dr(input int n, input logic [127:0] din, output logic [127:0] dout);
    logic d;
    dout = '0;
    jclk(1'b1, 1'b1, d);                        // Select-DR
    jclk(1'b0, 1'b1, d); jclk(1'b0, 1'b1, d);   // Capture-DR, Shift-DR
    for (int i = 0; i < n; i++) begin jclk(i == n - 1, din[i], d); dout[i] = d; end
    jclk(1'b1, 1'b1, d); jclk(1'b0, 1'b1, d);   // Update-DR, RTI
  endtask

  // ------------------------------------------------------------------ bring-up helpers
  task automatic power_off();
    por_n_r = 1'b0; lock_r = 1'b0; rst_n_r = 1'b1; cs_n_r = 1'b1; sck_r = 1'b0;
    #(4.0 * T_REF);
  endtask
  task automatic power_up(input bit wait_platform);
    real t0;
    ref_run = 1'b1; core_run = 1'b1; core_half = T_CORE / 2.0;
    por_n_r = 1'b0; lock_r = 1'b0;
    #(20.0 * T_REF);
    por_n_r = 1'b1;
    #(10.0 * T_REF);
    lock_r = 1'b1;
    begin
      t0 = $realtime;
      while (u_dut.rst_n !== 1'b1 && ($realtime - t0) < 200_000.0) #(T_CORE);
      check1("shell released by the P35 sequencer", u_dut.rst_n === 1'b1);
      if (wait_platform) begin
        t0 = $realtime;
        while (PLATFORM_READY !== 1'b1 && ($realtime - t0) < 5_000_000.0) #(10.0 * T_CORE);
        check1("PLATFORM_READY pad rises", PLATFORM_READY === 1'b1);
      end
    end
    #(20.0 * T_CORE);
  endtask

  // ==================================================================== tests
  // ------------------------------------------------------------------ reset propagation
  task automatic t_reset();
    logic [31:0] d;
    logic [4:0]   rcap;
    logic [127:0] ro;
    real t_shell, t_die, t0;
    cur_test = "reset";
`ifdef VERILATOR
    // A 2-state simulator (Verilator) applies asynchronous resets on edges only: from power-on, the P35 reset
    // flops start at 0 and the shell's async resets never see an edge while the gated clock is stopped.
    // Silicon resets on the level; Icarus (4-state) checks the power-on case from X (regression).  Here
    // the chip runs once, so that the POR below is an edge for every reset in the hierarchy.
    if (u_dut.rst_n !== 1'b1) power_up(1'b0);
`endif
    // 1. POR asserted, no clock at all: every driven pad at its inventory reset state
    ref_run = 1'b0; core_run = 1'b0; por_n_r = 1'b0; lock_r = 1'b0;
    #(500.0);
    check_pad_reset_states("POR, no clock running");
    // inputs: the chip never drives an input pad (every board driver released while POR holds the chip)
    tb_float = 1'b1;
    #(50.0);
    check_inputs_undriven("all board drivers released");
    tb_float = 1'b0;
    #(50.0);
    check("shell reset asserted without clocks", 32'(u_dut.rst_n), 0);
    check("die reset asserted without clocks", 32'(u_dut.die_por_n), 0);
    // 2. clocks running, POR still low
    ref_run = 1'b1; core_run = 1'b1;
    #(40.0 * T_REF);
    check_pad_reset_states("POR, clocks running");
    // 3. ordered release: shell (fabric) before the die (ControlCore branch), then PLATFORM_READY
    por_n_r = 1'b1; #(10.0 * T_REF); lock_r = 1'b1;
    t0 = $realtime;
    while (u_dut.rst_n !== 1'b1 && ($realtime - t0) < 200_000.0) #(1.0);
    t_shell = $realtime;
    check("die still in reset when the shell is released", 32'(u_dut.die_por_n), 0);
    while (u_dut.die_por_n !== 1'b1 && ($realtime - t0) < 400_000.0) #(1.0);
    t_die = $realtime;
    check1("die released after the shell", t_die > t_shell);
    check_pad_reset_states("shell released, die not yet ready");
    while (PLATFORM_READY !== 1'b1 && ($realtime - t0) < 5_000_000.0) #(10.0 * T_CORE);
    check("PLATFORM_READY after the sequence", 32'(PLATFORM_READY), 1);
    $display("[%0t] reset: shell released %0.0f ns, die %0.0f ns, PLATFORM_READY %0.0f ns after lock",
             $time, t_shell - t0, t_die - t0, $realtime - t0);
    rchk_mask("SHELL.STATUS ready bits", SH + 32'(R_STATUS), 32'h0000_100F, 32'h0000_0007);
    rchk("CRT.CAUSE after first POR (POR)", PG_CRT + 32'h0C, 32'h0000_0001);
    wr(PG_CRT + 32'h0C, 32'h0000_07FF);                        // W1C the causes
    #(40.0 * T_REF);
    rchk("CRT.CAUSE cleared", PG_CRT + 32'h0C, 32'h0);
    // 4. external reset pin: asynchronous assertion to every pad, clean re-sequence, cause logged
    rst_n_r = 1'b0;
    t0 = $realtime;
    while (u_dut.rst_n !== 1'b0 && ($realtime - t0) < 2_000.0) #(1.0);
    check1("RST_N asserts the shell reset", u_dut.rst_n === 1'b0);
    $display("[%0t] reset: RST_N -> shell reset in %0.1f ns", $time, $realtime - t0);
    #(2.0);
    check_pad_reset_states("RST_N asserted");
    #(20.0 * T_REF);
    rst_n_r = 1'b1;
    t0 = $realtime;
    while (PLATFORM_READY !== 1'b1 && ($realtime - t0) < 5_000_000.0) #(10.0 * T_CORE);
    check("PLATFORM_READY after RST_N", 32'(PLATFORM_READY), 1);
    rchk_mask("CRT.CAUSE: external reset pin", PG_CRT + 32'h0C, 32'h0000_0002, 32'h0000_0002);
    rchk_mask("CRT.RST_INFO reset count >= 2", PG_CRT + 32'h10, 32'h0000_FFFE, 32'h0000_0000);
    // 5. POR in operation: everything, including the TAP, back to reset (IR returns to IDCODE)
    begin
      jtag_tlr(); jtag_ir(5'h1F, rcap);                             // BYPASS selected
      por_n_r = 1'b0; #(10.0 * T_TCK); por_n_r = 1'b1; #(2.0 * T_TCK);
      begin logic b; jclk(1'b0, 1'b1, b); end                                  // TLR -> RTI (a TAP not reset would stay in RTI)
      jtag_dr(32, '0, ro);
      check("POR resets the TAP: IDCODE selected again", ro[31:0], 32'h15F1_0001);
    end
    por_n_r = 1'b0;
    #(5.0);
    check_pad_reset_states("POR asserted in operation");
    check1("TAP held in reset by POR (TDO released)", `RELEASED(TDO, u_dut.u_pad_TDO.u_cell.c2p_en));
    #(20.0 * T_REF);
    power_up(1'b1);
  endtask

  // ------------------------------------------------------------------ directions
  task automatic t_direction();
    logic [31:0] d;
    logic [7:0] r;
    cur_test = "direction";
    // push-pull outputs always driven, never Z/X in operation
    check1("PLATFORM_READY driven", PLATFORM_READY === 1'b1);
    check1("DEVICE_READY driven", DEVICE_READY === 1'b0 || DEVICE_READY === 1'b1);
    check1("UART_TX driven idle high", UART_TX === 1'b1);
    check1("MSPI_CS_N driven high", MSPI_CS_N === 1'b1);
    check1("MSPI_SCK driven", MSPI_SCK === 1'b0);
    check1("TEST_DONE driven", TEST_DONE === 1'b0 || TEST_DONE === 1'b1);
    // straps: latched while POR is low, ignored afterwards (test mode bypasses reset synchronisers)
    test_mode_r = 1'b1; boot_r = 2'b11;
    #(20.0 * T_CORE);
    rchk_mask("TEST_MODE / BOOT_MODE toggled in mission mode: latched values unchanged", SH + 32'(R_STATUS), 32'h380, 32'h000);
    check("die test_mode_i unchanged", 32'(u_dut.test_mode), 0);
    test_mode_r = 1'b0; boot_r = 2'b00;
    // tri-state: HOST_MISO only while CS_N is low; TDO only in Shift-IR/DR
    check1("HOST_MISO released while deselected", `RELEASED(HOST_MISO, u_dut.u_pad_HOST_MISO.u_cell.c2p_en));
    spi_begin();
    check1("HOST_MISO driven while selected", HOST_MISO === 1'b0 || HOST_MISO === 1'b1);
    spi_byte(HL_CMD_ID, r);
    spi_end();
    check1("HOST_MISO released after the frame", `RELEASED(HOST_MISO, u_dut.u_pad_HOST_MISO.u_cell.c2p_en));
    check1("TDO released outside shift states", `RELEASED(TDO, u_dut.u_pad_TDO.u_cell.c2p_en));
    // pseudo open drain: released (never driven high)
    check1("HOST_IRQ_N released (no interrupt)", `RELEASED(HOST_IRQ_N, u_dut.u_pad_HOST_IRQ_N.u_cell.c2p_en));
    check1("RAS_FATAL_N released (no fatal)", `RELEASED(RAS_FATAL_N, u_dut.u_pad_RAS_FATAL_N.u_cell.c2p_en));
    // bidir GPIO: driven only when OE
    check1("GPIO released after reset", gpio_is(8'h00, 8'h00));
    wr(PG_GPIO + 32'h04, 32'h0000_00C3);                       // OUT
    wr(PG_GPIO + 32'h08, 32'h0000_000F);                       // OE[3:0]
    #(4.0 * T_CORE);
    check1("GPIO[3:0] driven = OUT, [7:4] released", gpio_is(8'h0F, 8'h03));
    gpio_en = 8'hF0; gpio_val = 8'h50;
    #(4.0 * T_CORE);
    rchk_mask("GPIO.IN sees board-driven [7:4] and own [3:0]", PG_GPIO + 32'h00, 32'hFF, 32'h53);
    gpio_en = 8'h00;
    wr(PG_GPIO + 32'h08, 32'h0);
    #(4.0 * T_CORE);
    check1("GPIO released when OE = 0", gpio_is(8'h00, 8'h00));
  endtask

  // ------------------------------------------------------------------ clock status
  task automatic t_clock();
    logic [31:0] d;
    logic [127:0] o;
    logic [31:0] st1, st2;
    logic [4:0] cap;
    real t0;
    bit ref_seen0, ref_seen1, core_changed;
    cur_test = "clock";
    // 1. core clock absent at power-up: sequencer waits, chip stays in reset, JTAG still works
    power_off();
    core_run = 1'b0; ref_run = 1'b1;
    #(20.0 * T_REF); por_n_r = 1'b1; #(10.0 * T_REF); lock_r = 1'b1;
    #(300.0 * T_REF);
    check("no core clock: shell held in reset", 32'(u_dut.rst_n), 0);
    check_pad_reset_states("no core clock");
    jtag_tlr();
    jtag_ir(TC_IR_TC_STATUS_C, cap);
    begin
      ref_seen0 = 0; ref_seen1 = 0; core_changed = 0;
      jtag_dr(32, '0, o); st1 = o[31:0];
      for (int k = 0; k < 8; k++) begin
        #(1.37 * T_REF);
        jtag_dr(32, '0, o); st2 = o[31:0];
        if (st2[6]) ref_seen1 = 1; else ref_seen0 = 1;
        if (st2[7] != st1[7]) core_changed = 1;
      end
      check("JTAG status marker", 32'(st1[31:24]), 32'h37);
      check1("JTAG status: reference clock toggling (both levels captured)", ref_seen0 && ref_seen1);
      check("JTAG status: core clock not toggling", 32'(core_changed), 0);
    end
    check("JTAG status: sequencer waiting for the core clock (WAIT_CLK)", 32'(st2[15:12]), 1);
    check("JTAG status: lock seen", 32'(st2[2]), 1);
    // 2. core clock starts -> qualified -> RUN -> die -> PLATFORM_READY
    core_run = 1'b1;
    t0 = $realtime;
    while (PLATFORM_READY !== 1'b1 && ($realtime - t0) < 5_000_000.0) #(10.0 * T_CORE);
    check("core clock started: PLATFORM_READY", 32'(PLATFORM_READY), 1);
    rd(PG_CRT + 32'h08, d);
    check("CRT.STATUS RUN", 32'(d[6]), 1);
    check("CRT.STATUS PLL_LOCKED", 32'(d[7]), 1);
    check("CRT.STATUS CORE_CLK_OK", 32'(d[8]), 1);
    rd(PG_CRT + 32'h30, d);
    check1($sformatf("CRT.CLK_MEAS core edges per window %0d within [%0d, %0d]", d[15:0], CNT_MIN, CNT_MAX),
           d[15:0] >= CNT_MIN && d[15:0] <= CNT_MAX);
    rchk_mask("SHELL.STATUS CLKGEN_LOCK + CRT_SYS_READY", SH + 32'(R_STATUS), 32'h3, 32'h3);
    wr(PG_CRT + 32'h0C, 32'h7FF); #(40.0 * T_REF);
    // 3. core clock lost in operation -> asynchronous reset -> recovery
    core_run = 1'b0;
    t0 = $realtime;
    while (PLATFORM_READY !== 1'b0 && ($realtime - t0) < 50_000.0) #(1.0);
    check("core clock lost: PLATFORM_READY dropped", 32'(PLATFORM_READY), 0);
    $display("[%0t] clock: core clock loss detected in %0.0f ns", $time, $realtime - t0);
    #(50.0);
    check_pad_reset_states("core clock lost");
    #(50.0 * T_REF);
    core_run = 1'b1;
    t0 = $realtime;
    while (PLATFORM_READY !== 1'b1 && ($realtime - t0) < 5_000_000.0) #(10.0 * T_CORE);
    check("core clock restored: PLATFORM_READY", 32'(PLATFORM_READY), 1);
    rchk_mask("CRT.CAUSE: core clock absent", PG_CRT + 32'h0C, 32'h4, 32'h4);
    wr(PG_CRT + 32'h0C, 32'h7FF); #(40.0 * T_REF);
    // 4. lock lost
    lock_r = 1'b0;
    t0 = $realtime;
    while (PLATFORM_READY !== 1'b0 && ($realtime - t0) < 50_000.0) #(1.0);
    check("lock lost: PLATFORM_READY dropped", 32'(PLATFORM_READY), 0);
    #(20.0 * T_REF);
    lock_r = 1'b1;
    t0 = $realtime;
    while (PLATFORM_READY !== 1'b1 && ($realtime - t0) < 5_000_000.0) #(10.0 * T_CORE);
    check("lock restored: PLATFORM_READY", 32'(PLATFORM_READY), 1);
    rchk_mask("CRT.CAUSE: PLL lock lost", PG_CRT + 32'h0C, 32'h8, 32'h8);
    wr(PG_CRT + 32'h0C, 32'h7FF); #(40.0 * T_REF);
    // 5. core clock out of range (3x too slow)
    core_half = 3.0 * T_CORE / 2.0;
    t0 = $realtime;
    while (PLATFORM_READY !== 1'b0 && ($realtime - t0) < 100_000.0) #(1.0);
    check("core clock out of range: chip held in reset", 32'(PLATFORM_READY), 0);
    #(100.0 * T_REF);
    check("out-of-range clock not accepted", 32'(u_dut.rst_n), 0);
    core_half = T_CORE / 2.0;
    t0 = $realtime;
    while (PLATFORM_READY !== 1'b1 && ($realtime - t0) < 5_000_000.0) #(10.0 * T_CORE);
    check("clock back in range: PLATFORM_READY", 32'(PLATFORM_READY), 1);
    rchk_mask("CRT.CAUSE: core clock out of range", PG_CRT + 32'h0C, 32'h4, 32'h4);
  endtask

  // ------------------------------------------------------------------ JTAG / boundary scan
  task automatic t_jtag();
    logic [4:0]   cap;
    logic [127:0] o, pre;
    logic [31:0]  d;
    logic         x;
    int           base, g2, g5;
    cur_test = "jtag";
    tck_run = 1'b1;
    // TRST
    trst_n_r = 1'b0; #(3.0 * T_TCK); trst_n_r = 1'b1; #(T_TCK);
    jtag_tlr();
    // IR capture pattern and IDCODE (selected by reset)
    jtag_ir(5'h02, cap);
    check("IR capture pattern 0b00001", 32'(cap), 32'h01);
    jtag_dr(32, '0, o);
    check("IDCODE {ver 1, part 0x5F10, mfg placeholder, 1}", o[31:0], 32'h15F1_0001);
    check1("TDO released in Run-Test/Idle", `RELEASED(TDO, u_dut.u_pad_TDO.u_cell.c2p_en));
    // BYPASS: one-bit register
    jtag_ir(5'h1F, cap);
    jtag_dr(9, 128'h1A5, o);
    check("BYPASS delays by one bit", o[8:0], {8'hA5 & 8'hFF, 1'b0} & 9'h1FF);
    jtag_ir(5'h1E, cap);                                          // unassigned -> BYPASS
    jtag_dr(5, 128'h1F, o);
    check("unassigned opcode selects BYPASS", o[4:0], 5'b11110);
    jtag_ir(5'h09, cap);                                          // TestCore private DR not in the shell
    jtag_dr(5, 128'h1F, o);
    check("TC_MODE (not implemented) behaves as a 1-bit register", o[4:0], 5'b11110);
    // SAMPLE: drive inputs to a pattern, capture every cell
    boot_r = 2'b10; warn_n_r = 1'b0; uart_rx_r = 1'b0; cs_n_r = 1'b1; sck_r = 1'b1; mosi_r = 1'b0;   // MOSI differs from SCK / CS_N (CS_N stays high: link idle)
    gpio_en = 8'h0F; gpio_val = 8'h09;
    #(10.0 * T_CORE);
    jtag_ir(5'h01, cap);
    jtag_dr(BSR_LEN, '0, o);
    check("SAMPLE: POR_N",         32'(o[BSRI_POR_N]), 1);
    check("SAMPLE: RST_N",         32'(o[BSRI_RST_N]), 1);
    check("SAMPLE: CLKGEN_LOCK",   32'(o[BSRI_CLKGEN_LOCK]), 1);
    check("SAMPLE: TEST_MODE",     32'(o[BSRI_TEST_MODE]), 0);
    check("SAMPLE: BOOT_MODE",     32'(o[BSRI_BOOT_MODE +: 2]), 2);
    check("SAMPLE: BOARD_WARN_N",  32'(o[BSRI_BOARD_WARN_N]), 0);
    check("SAMPLE: BOARD_FATAL_N", 32'(o[BSRI_BOARD_FATAL_N]), 1);
    check("SAMPLE: UART_RX",       32'(o[BSRI_UART_RX]), 0);
    check("SAMPLE: HOST_SCK",      32'(o[BSRI_HOST_SCK]), 1);
    check("SAMPLE: HOST_CS_N",     32'(o[BSRI_HOST_CS_N]), 1);
    check("SAMPLE: HOST_MOSI",     32'(o[BSRI_HOST_MOSI]), 0);
    check("SAMPLE: MSPI_MISO (loopback of MOSI)", 32'(o[BSRI_MSPI_MISO]), 32'(MSPI_MOSI));
    check("SAMPLE: PLATFORM_READY data / control", 32'({o[BSR_NUM_IN + 2*BSRO_PLATFORM_READY + 1], o[BSR_NUM_IN + 2*BSRO_PLATFORM_READY]}), 32'b11);
    check("SAMPLE: UART_TX data / control", 32'({o[BSR_NUM_IN + 2*BSRO_UART_TX + 1], o[BSR_NUM_IN + 2*BSRO_UART_TX]}), 32'b11);
    check("SAMPLE: MSPI_CS_N data / control", 32'({o[BSR_NUM_IN + 2*BSRO_MSPI_CS_N + 1], o[BSR_NUM_IN + 2*BSRO_MSPI_CS_N]}), 32'b11);
    check("SAMPLE: HOST_MISO control (deselected)", 32'(o[BSR_NUM_IN + 2*BSRO_HOST_MISO + 1]), 0);
    check("SAMPLE: HOST_IRQ_N control (no irq)", 32'(o[BSR_NUM_IN + 2*BSRO_HOST_IRQ_N + 1]), 0);
    for (int i = 0; i < 8; i++) begin
      base = BSR_NUM_IN + 2 * BSR_NUM_OUT + 3 * (BSRB_GPIO + i);
      if (i < 4) check($sformatf("SAMPLE: GPIO[%0d] input cell", i), 32'(o[base]), 32'(gpio_val[i]));
      check($sformatf("SAMPLE: GPIO[%0d] control cell (OE 0)", i), 32'(o[base + 2]), 0);
    end
    check1("SAMPLE leaves PLATFORM_READY functional", PLATFORM_READY === 1'b1);
    gpio_en = 8'h00; warn_n_r = 1'b1; uart_rx_r = 1'b1; sck_r = 1'b0; mosi_r = 1'b0; boot_r = 2'b00;
    // PRELOAD + EXTEST: drive the pads from the update stage
    pre = '0;
    pre[BSR_NUM_IN + 2*BSRO_PLATFORM_READY]     = 1'b0; pre[BSR_NUM_IN + 2*BSRO_PLATFORM_READY + 1] = 1'b1;   // drive 0
    pre[BSR_NUM_IN + 2*BSRO_DEVICE_READY]       = 1'b1; pre[BSR_NUM_IN + 2*BSRO_DEVICE_READY + 1]   = 1'b1;   // drive 1
    pre[BSR_NUM_IN + 2*BSRO_TEST_DONE + 1]      = 1'b0;                                                   // released
    pre[BSR_NUM_IN + 2*BSRO_HOST_MISO]          = 1'b1; pre[BSR_NUM_IN + 2*BSRO_HOST_MISO + 1]      = 1'b1;   // drive 1
    pre[BSR_NUM_IN + 2*BSRO_UART_TX]            = 1'b0; pre[BSR_NUM_IN + 2*BSRO_UART_TX + 1]        = 1'b1;   // drive 0
    begin
      g2 = BSR_NUM_IN + 2 * BSR_NUM_OUT + 3 * (BSRB_GPIO + 2);
      g5 = BSR_NUM_IN + 2 * BSR_NUM_OUT + 3 * (BSRB_GPIO + 5);
      pre[g2 + 1] = 1'b1; pre[g2 + 2] = 1'b1;      // GPIO[2] drive 1
      pre[g5 + 1] = 1'b0; pre[g5 + 2] = 1'b1;      // GPIO[5] drive 0
    end
    jtag_ir(5'h01, cap);
    jtag_dr(BSR_LEN, pre, o);                                    // PRELOAD
    jtag_ir(5'h00, cap);                                         // EXTEST
    #(2.0 * T_TCK);
    check("EXTEST: PLATFORM_READY forced 0", 32'(PLATFORM_READY), 0);
    check("EXTEST: DEVICE_READY forced 1", 32'(DEVICE_READY), 1);
    check1("EXTEST: TEST_DONE released", `RELEASED(TEST_DONE, u_dut.u_pad_TEST_DONE.g_tri.u_cell.c2p_en));
    check("EXTEST: HOST_MISO driven 1 although deselected", 32'(HOST_MISO), 1);
    check("EXTEST: UART_TX forced 0", 32'(UART_TX), 0);
    check1("EXTEST: GPIO pattern (GPIO[2] = 1, GPIO[5] = 0, rest released)", gpio_is(8'h24, 8'h04));
    check1("EXTEST: TDO / JTAG pins unaffected (TDO released in RTI)", `RELEASED(TDO, u_dut.u_pad_TDO.u_cell.c2p_en));
    jtag_dr(BSR_LEN, pre, o);                                    // EXTEST capture = pad values
    check("EXTEST capture: GPIO[2] input cell sees the driven 1", 32'(o[BSR_NUM_IN + 2*BSR_NUM_OUT + 3*(BSRB_GPIO+2)]), 1);
    // CLAMP: same pad values, BYPASS selected
    jtag_ir(5'h03, cap);
    #(2.0 * T_TCK);
    check("CLAMP: pads hold the update stage (PLATFORM_READY 0)", 32'(PLATFORM_READY), 0);
    jtag_dr(4, 128'hF, o);
    check("CLAMP selects BYPASS", o[3:0], 4'b1110);
    // HIGHZ: every BSR-controlled driver released, including push-pull functions
    jtag_ir(5'h04, cap);
    #(2.0 * T_TCK);
    check1("HIGHZ: PLATFORM_READY released", `RELEASED(PLATFORM_READY, u_dut.u_pad_PLATFORM_READY.g_tri.u_cell.c2p_en));
    check1("HIGHZ: UART_TX released", `RELEASED(UART_TX, u_dut.u_pad_UART_TX.g_tri.u_cell.c2p_en));
    check1("HIGHZ: MSPI_CS_N released", `RELEASED(MSPI_CS_N, u_dut.u_pad_MSPI_CS_N.g_tri.u_cell.c2p_en));
    check1("HIGHZ: GPIO released", gpio_is(8'h00, 8'h00));
    // back to functional (Test-Logic-Reset selects IDCODE)
    jtag_tlr();
    #(2.0 * T_TCK);
    check("TLR restores functional PLATFORM_READY", 32'(PLATFORM_READY), 1);
    check("TLR restores functional UART_TX", 32'(UART_TX), 1);
    // status DR
    jtag_ir(TC_IR_TC_STATUS_C, cap);
    jtag_dr(32, '0, o);
    check("status DR marker", 32'(o[31:24]), 32'h37);
    check("status DR POR_N/RST_N/lock", 32'(o[2:0]), 32'h7);
    check("status DR CRT ready + PLATFORM_READY", 32'(o[9:8]), 32'h3);
    // TRST in EXTEST: pads return to functional
    jtag_ir(5'h00, cap);
    #(2.0 * T_TCK);
    trst_n_r = 1'b0; #(2.0 * T_TCK);
    check("TRST_N releases EXTEST (PLATFORM_READY functional)", 32'(PLATFORM_READY), 1);
    trst_n_r = 1'b1; #(T_TCK);
    jtag_tlr();
    // functional host path still alive after boundary scan
    rchk("host link alive after boundary scan", SH + 32'(R_ID), R_ID_RST);
  endtask

  // ------------------------------------------------------------------ host-command link
  function automatic logic [7:0] spd_frame(input int k);   // WRITE SCRATCH <- 0xDEADBEEF
    case (k)
      0: return HL_CMD_WRITE;  1: return 8'h50;  2: return 8'h00;  3: return 8'h00;  4: return 8'(R_SCRATCH);
      5: return 8'h0F;         6: return 8'hDE;  7: return 8'hAD;  8: return 8'hBE;  default: return 8'hEF;
    endcase
  endfunction
  task automatic t_hostlink();
    logic [31:0] d, cnt0, cnt1;
    logic [7:0] r, st;
    cur_test = "hostlink";
    // RESULT with no transaction since reset -> CMD error
    hl_begin(HL_CMD_RESULT); spi_byte(8'h00, r); spi_end();
    check("RESULT without a transaction -> CMD_ERR", 32'(r), 32'(HL_ST_CMD_ERR));
    // ID / STATUS
    hl_begin(HL_CMD_ID);
    for (int i = 0; i < 4; i++) begin spi_byte(8'h00, r); d = {d[23:0], r}; end
    spi_end();
    check("ID bytes", d, HL_ID);
    hl_begin(HL_CMD_STATUS); spi_byte(8'h00, r); spi_byte(8'h00, st); spi_end();
    check("LINK_STAT: platform ready, CRT ready, bit0", 32'(r) & 32'h87, 32'h83);
    check("LINK_ERR: CMD error of the first frame", 32'(st), 32'h04);
    hl_begin(HL_CMD_CLRERR); spi_byte(8'h00, r); spi_end();
    check("CLRERR -> OK", 32'(r), 32'(HL_ST_OK));
    rchk("LINK_STATUS cleared", SH + 32'(R_LINK_STATUS), 32'h0);
    // shell window and die
    rchk("SHELL.ID", SH + 32'(R_ID), R_ID_RST);
    wr(SH + 32'(R_SCRATCH), 32'hC0FF_EE37);
    rchk("SHELL.SCRATCH", SH + 32'(R_SCRATCH), 32'hC0FF_EE37);
    rchk("die DIE_SYS.ID through the pins", SYS + 32'(DIE_SYS_ID), DIE_ID);
    // CS_N raised before polling: the transaction completes, RESULT returns it
    hl_begin(HL_CMD_READ);
    for (int i = 3; i >= 0; i--) spi_byte(SH[8*i +: 8] | (i == 0 ? 8'(R_SCRATCH) : 8'h00), r);
    spi_end();
    hl_begin(HL_CMD_RESULT); hl_poll(st);
    for (int i = 0; i < 4; i++) begin spi_byte(8'h00, r); d = {d[23:0], r}; end
    spi_end();
    check("RESULT after early CS_N: status", 32'(st), 32'(HL_ST_OK));
    check("RESULT after early CS_N: data", d, 32'hC0FF_EE37);
    // BUSY: a slow die (forced) + a second launch
    force u_dut.die_req_valid = 1'b0;                            // a die that does not answer:
    force u_dut.die_req_ready = 1'b0;                            // neither side sees the handshake
    hl_begin(HL_CMD_READ);
    for (int i = 3; i >= 0; i--) spi_byte(SYS[8*i +: 8], r);
    spi_byte(8'h00, r); spi_byte(8'h00, r);
    spi_end();
    check("slow die: poll bytes return BUSY (0x00)", 32'(r), 0);
    hl_read(SH + 32'(R_ID), d, st);
    check("second launch while busy -> BUSY_ERR", 32'(st), 32'(HL_ST_BUSY_ERR));
    hl_begin(HL_CMD_STATUS); spi_byte(8'h00, r); spi_end();
    check("LINK_STAT BUSY while the die stalls", 32'(r[3]), 1);
    release u_dut.die_req_valid;
    release u_dut.die_req_ready;
    hl_begin(HL_CMD_RESULT); hl_poll(st);
    for (int i = 0; i < 4; i++) begin spi_byte(8'h00, r); d = {d[23:0], r}; end
    spi_end();
    check("stalled transaction completes later: OK", 32'(st), 32'(HL_ST_OK));
    check("stalled transaction completes later: data", d, DIE_ID);
    // back-pressure on the link master (split quiesced, so it does not accept): the request must be
    // held, unchanged, until it is accepted (SFB2 R2; the protocol checker watches the same port)
    force u_dut.quiesce = 1'b1;
    hl_begin(HL_CMD_READ);
    for (int i = 3; i >= 0; i--) spi_byte(SH[8*i +: 8] | (i == 0 ? 8'(R_SCRATCH) : 8'h00), r);
    spi_end();
    #(50.0 * T_CORE);
    check1("request held while the split does not accept it", u_dut.hl_req_valid === 1'b1 && u_dut.hl_req_ready === 1'b0);
    release u_dut.quiesce;
    hl_begin(HL_CMD_RESULT); hl_poll(st);
    d = 0;
    for (int i = 0; i < 4; i++) begin spi_byte(8'h00, r); d = {d[23:0], r}; end
    spi_end();
    check("held request completes once accepted: status", 32'(st), 32'(HL_ST_OK));
    check("held request completes once accepted: data", d, 32'hC0FF_EE37);
    // invalid commands and arguments
    hl_begin(8'h77); spi_byte(8'h00, r); spi_end();
    check("unknown command -> CMD_ERR", 32'(r), 32'(HL_ST_CMD_ERR));
    hl_write(SH + 32'(R_SCRATCH), 32'h1111_1111, 4'h0, st);    // strobe byte 0x00 is legal (no bytes) -> shell refuses
    check("WRITE with WSTRB 0 to the shell -> BUS_ERR", 32'(st), 32'(HL_ST_BUS_ERR));
    hl_begin(HL_CMD_WRITE);
    for (int i = 3; i >= 0; i--) spi_byte(SH[8*i +: 8] | (i == 0 ? 8'(R_SCRATCH) : 8'h00), r);
    spi_byte(8'h1F, r); spi_byte(8'h00, r); spi_end();
    check("WRITE with an illegal strobe byte -> CMD_ERR", 32'(r), 32'(HL_ST_CMD_ERR));
    hl_begin(HL_CMD_RESET); spi_byte(8'h33, r); spi_byte(8'h00, r); spi_end();
    check("RESET with a wrong key -> CMD_ERR", 32'(r), 32'(HL_ST_CMD_ERR));
    check("no host reset request on a wrong key", 32'(rst_req_pulses), 0);
    rchk("SCRATCH unchanged by refused frames", SH + 32'(R_SCRATCH), 32'hC0FF_EE37);
    // FRAME: CS_N inside a byte, and inside the argument phase (no transaction); each case on its own
    rchk_mask("LINK_STATUS: CMD + BUSY errors sticky", SH + 32'(R_LINK_STATUS), 32'h0C, 32'h0C);
    hl_begin(HL_CMD_CLRERR); spi_byte(8'h00, r); spi_end();
    rchk("LINK_STATUS clear before the FRAME cases", SH + 32'(R_LINK_STATUS), 32'h0);
    spi_begin(); mosi_r = 1'b0;
    for (int b = 0; b < 3; b++) begin #(spi_half); sck_r = 1'b1; #(spi_half); sck_r = 1'b0; end
    spi_end();
    rchk_mask("LINK_STATUS: FRAME after CS_N inside a byte", SH + 32'(R_LINK_STATUS), 32'h01, 32'h01);
    hl_begin(HL_CMD_CLRERR); spi_byte(8'h00, r); spi_end();
    rchk_mask("LINK_STATUS: FRAME cleared", SH + 32'(R_LINK_STATUS), 32'h01, 32'h00);
    hl_begin(HL_CMD_WRITE);
    for (int i = 3; i >= 0; i--) spi_byte(SH[8*i +: 8] | (i == 0 ? 8'(R_SCRATCH) : 8'h00), r);
    spi_byte(8'h0F, r); spi_byte(8'hAB, r);                      // two data bytes only (byte-aligned CS_N)
    spi_end();
    rchk("truncated WRITE frame did not write", SH + 32'(R_SCRATCH), 32'hC0FF_EE37);
    rchk_mask("LINK_STATUS: FRAME after a truncated argument phase", SH + 32'(R_LINK_STATUS), 32'h01, 32'h01);
    // SPEED: SCK at f_core / 2 -> error, frame ignored
    spi_half = 1.0 * T_CORE;                                      // raw frame: no sync check at this speed
    spi_begin();
    for (int k = 0; k < 10; k++) spi_byte(spd_frame(k), r);
    for (int k = 0; k < 4; k++) spi_byte(8'h00, r);
    spi_end();
    spi_half = 4.0 * T_CORE;
    rchk("over-speed frame did not write", SH + 32'(R_SCRATCH), 32'hC0FF_EE37);
    rchk_mask("LINK_STATUS: SPEED", SH + 32'(R_LINK_STATUS), 32'h02, 32'h02);
    // BUS errors: die decode error, shell access rules
    hl_read(32'h6000_0000, d, st);
    check("unmapped die address -> BUS_ERR", 32'(st), 32'(HL_ST_BUS_ERR));
    check("BUS_ERR carries no data", d, 0);
    hl_read(SH + 32'h2, d, st);
    check("misaligned shell access -> BUS_ERR", 32'(st), 32'(HL_ST_BUS_ERR));
    hl_write(SH + 32'(R_SCRATCH), 32'h2222_2222, 4'h3, st);
    check("partial-strobe shell write -> BUS_ERR", 32'(st), 32'(HL_ST_BUS_ERR));
    hl_write(SH + 32'(R_ID), 32'h0, 4'hF, st);
    check("write to a read-only register -> BUS_ERR", 32'(st), 32'(HL_ST_BUS_ERR));
    hl_read(SH + 32'h8000, d, st);
    check("unknown shell page -> BUS_ERR", 32'(st), 32'(HL_ST_BUS_ERR));
    hl_read(PG_CRT + 32'h100, d, st);
    check("CRT offset beyond its 8-bit space -> BUS_ERR", 32'(st), 32'(HL_ST_BUS_ERR));
    hl_read(SH + 32'h0FFC, d, st);
    check("unknown SHELL offset -> BUS_ERR", 32'(st), 32'(HL_ST_BUS_ERR));
    rchk("SCRATCH unchanged by refused writes", SH + 32'(R_SCRATCH), 32'hC0FF_EE37);
    rchk_mask("LINK_STATUS: BUS", SH + 32'(R_LINK_STATUS), 32'h10, 32'h10);
    // counters, LINK_CLEAR
    rd(SH + 32'(R_LINK_COUNT), cnt0);
    check1("LINK_COUNT has good and bad frames", cnt0[15:0] != 0 && cnt0[31:16] != 0);
    wr(SH + 32'(R_LINK_CLEAR), 32'h8000_001F);
    rd(SH + 32'(R_LINK_COUNT), cnt1);
    check("LINK_CLEAR clears the counters (the clearing frame and this read count)", cnt1, 32'h0000_0001);
    rchk("LINK_CLEAR clears the sticky errors", SH + 32'(R_LINK_STATUS), 0);
    // other SCK ratios
    spi_half = 6.0 * T_CORE;  rchk("f_SCK = f_core / 12", SYS + 32'(DIE_SYS_ID), DIE_ID);
    spi_half = 8.0 * T_CORE;  rchk("f_SCK = f_core / 16", SYS + 32'(DIE_SYS_ID), DIE_ID);
    spi_half = 4.0 * T_CORE;
    // host reset command with the right key
    hl_begin(HL_CMD_RESET); spi_byte(HL_RESET_KEY, r); spi_byte(8'h00, r); spi_end();
    check("RESET with the key -> OK", 32'(r), 32'(HL_ST_OK));
    #(20.0 * T_CORE);
    check("host_rst_req pulse delivered to the die", 32'(rst_req_pulses), 1);
    check("protocol violations: host link", v_hl, 0);
    check("protocol violations: shell window", v_sh, 0);
    check("protocol violations: die host port", v_die, 0);
  endtask

  // ------------------------------------------------------------------ die not ready / DIE_FORCE (MIN die)
  task automatic t_dieready();
    logic [31:0] d;
    logic [7:0] st;
    real t0;
    cur_test = "dieready";
    // restart and talk to the die between the shell release and PLATFORM_READY
    power_off();
    power_up(1'b0);
    t0 = $realtime;
    while (u_dut.die_por_n !== 1'b1 && ($realtime - t0) < 100_000.0) #(T_CORE);
    #(200.0 * T_CORE);
    check("die released, PLATFORM_READY not yet", 32'({u_dut.die_por_n, PLATFORM_READY}), 32'b10);
    hl_read(SYS + 32'(DIE_SYS_ID), d, st);
    check("die access before PLATFORM_READY refused (BUS_ERR)", 32'(st), 32'(HL_ST_BUS_ERR));
    check1("refusal counted", u_dut.split_refused != 0);
    wr(SH + 32'(R_CTRL), 32'h7);                                  // DIE_FORCE
    hl_read(SYS + 32'(DIE_SYS_ID), d, st);
    check("DIE_FORCE: die identity readable before PLATFORM_READY", d, DIE_ID);
    rchk_mask("DIE_SYS.STATUS: PLATFORM_READY bit still 0", SYS + 32'(DIE_SYS_STATUS), 32'h80, 32'h00);
    wr(SH + 32'(R_CTRL), 32'h3);
    t0 = $realtime;
    while (PLATFORM_READY !== 1'b1 && ($realtime - t0) < 5_000_000.0) #(10.0 * T_CORE);
    check("PLATFORM_READY", 32'(PLATFORM_READY), 1);
  endtask

  // ------------------------------------------------------------------ die reset while a die transaction is outstanding
  task automatic t_fence();
    logic [31:0] d;
    logic [7:0] r, st;
    real t0;
    cur_test = "fence";
    force u_dut.die_req_valid = 1'b0;                           // stall a die read (neither side sees the handshake)
    force u_dut.die_req_ready = 1'b0;
    hl_begin(HL_CMD_READ);
    for (int i = 3; i >= 0; i--) spi_byte(SYS[8*i +: 8], r);
    spi_end();
    #(50.0 * T_CORE);
    check("die transaction outstanding", 32'(u_dut.u_split.st), 2);
    force u_dut.die_por_n = 1'b0;                              // the die is reset under the transaction
    #(20.0 * T_CORE);
    release u_dut.die_req_valid;
    release u_dut.die_req_ready;
    hl_begin(HL_CMD_RESULT); hl_poll(st); spi_end();
    check("reset fence: the cut transaction ends with BUS_ERR", 32'(st), 32'(HL_ST_BUS_ERR));
    check("reset fence counted", 32'(u_dut.split_fenced), 1);
    hl_read(SYS + 32'(DIE_SYS_ID), d, st);
    check("die in reset: further die accesses refused", 32'(st), 32'(HL_ST_BUS_ERR));
    rchk("shell window still served during the die reset", SH + 32'(R_ID), R_ID_RST);
    release u_dut.die_por_n;
    t0 = $realtime;
    while (PLATFORM_READY !== 1'b1 && ($realtime - t0) < 5_000_000.0) #(10.0 * T_CORE);
    check("die back: PLATFORM_READY", 32'(PLATFORM_READY), 1);
    rchk("die back: identity", SYS + 32'(DIE_SYS_ID), DIE_ID);
    check("protocol violations after the fenced transaction", v_hl + v_sh + v_die, 0);
  endtask

  // ------------------------------------------------------------------ GPIO
  task automatic t_gpio();
    logic [31:0] d;
    cur_test = "gpio";
    gpio_en = 8'hF0; gpio_val = 8'h00;
    wr(PG_GPIO + 32'h04, 32'h05);  wr(PG_GPIO + 32'h08, 32'h0F);
    #(4.0 * T_CORE);
    check("GPIO[3:0] = OUT", 32'(GPIO[3:0]), 32'h5);
    wr(PG_GPIO + 32'h20, 32'h0F);                                 // OUT_TGL
    #(4.0 * T_CORE);
    check("OUT_TGL", 32'(GPIO[3:0]), 32'hA);
    gpio_val = 8'hA0;
    #(4.0 * T_CORE);
    rchk_mask("GPIO.IN", PG_GPIO + 32'h00, 32'hFF, 32'hAA);
    wr(PG_GPIO + 32'h0C, 32'h40);                                 // rise IRQ on bit 6
    wr(SH + 32'(R_IRQ_ENABLE), 32'h3);                            // DIE + GPIO
    check1("HOST_IRQ_N released before the edge", `RELEASED(HOST_IRQ_N, u_dut.u_pad_HOST_IRQ_N.u_cell.c2p_en));
    gpio_val = 8'hE0;
    #(10.0 * T_CORE);
    rchk_mask("GPIO.IRQ_PEND bit 6", PG_GPIO + 32'h14, 32'h40, 32'h40);
    rchk_mask("SHELL.IRQ_STATUS GPIO", SH + 32'(R_IRQ_STATUS), 32'h2, 32'h2);
    check("HOST_IRQ_N asserted low", 32'(HOST_IRQ_N), 0);
    wr(SH + 32'(R_CTRL), 32'h1);                                  // IRQ_PIN_EN = 0
    #(4.0 * T_CORE);
    check1("CTRL.IRQ_PIN_EN = 0 releases HOST_IRQ_N", `RELEASED(HOST_IRQ_N, u_dut.u_pad_HOST_IRQ_N.u_cell.c2p_en));
    wr(SH + 32'(R_CTRL), 32'h3);
    wr(PG_GPIO + 32'h14, 32'h40);                                 // W1C
    #(4.0 * T_CORE);
    check1("HOST_IRQ_N released after clearing", `RELEASED(HOST_IRQ_N, u_dut.u_pad_HOST_IRQ_N.u_cell.c2p_en));
    wr(SH + 32'(R_IRQ_ENABLE), 32'h1);
    wr(PG_GPIO + 32'h08, 32'h0); wr(PG_GPIO + 32'h0C, 32'h0);
    gpio_en = 8'h00;
  endtask

  // ------------------------------------------------------------------ UART
  task automatic t_uart();
    logic [31:0] d, dd;
    int k;
    cur_test = "uart";
    wr(PG_UART + 32'h0C, 32'd8);                                  // BAUD: 8 clk per bit
    uart_bit_ns = 8.0 * T_CORE;
    wr(SH + 32'(R_CTRL), 32'h2);                                  // console off for this test
    uart_q.delete();
    wr(PG_UART + 32'h00, 32'h41); wr(PG_UART + 32'h00, 32'h37);
    #(400.0 * T_CORE);
    check("UART_TX: two bytes received", uart_q.size(), 2);
    if (uart_q.size() == 2) begin check("UART_TX byte 0", 32'(uart_q[0]), 32'h41); check("UART_TX byte 1", 32'(uart_q[1]), 32'h37); end
    check("UART_TX framing", 32'(uart_frame_err), 0);
    begin k = 0; rd(PG_UART + 32'h00, dd); while (!dd[31] && k < 20) begin rd(PG_UART + 32'h00, dd); k++; end end
    uart_send(8'h5C);
    rchk("UART_RX byte read through DATA", PG_UART + 32'h00, 32'h0000_005C);
    rchk_mask("UART DATA empty afterwards", PG_UART + 32'h00, 32'h8000_0000, 32'h8000_0000);
    wr(SH + 32'(R_CTRL), 32'h3);
  endtask

  // ------------------------------------------------------------------ management SPI master (loopback on the board)
  int mspi_edges = 0;
  always @(posedge MSPI_SCK) mspi_edges++;
  task automatic t_mspi();
    logic [31:0] d;
    bit cs_seen;
    int e0;
    cur_test = "mspi";
    mspi_loop = 1'b1;
    wr(PG_MSPI + 32'h0C, 32'd2);                                  // DIV
    wr(PG_MSPI + 32'h08, 32'h0000_0100);                          // CS0 asserted, mode 0, 8-bit
    #(4.0 * T_CORE);
    check("MSPI_CS_N asserted by CTRL.CS", 32'(MSPI_CS_N), 0);
    cs_seen = 1'b0;
    begin e0 = mspi_edges; wr(PG_MSPI + 32'h00, 32'h0000_00A5); #(400.0 * T_CORE);
      check("MSPI_SCK: 8 rising edges for an 8-bit frame", 32'(mspi_edges - e0), 8); end
    rchk_mask("MSPI DONE", PG_MSPI + 32'h04, 32'h2, 32'h2);
    rchk_mask("MSPI loopback data", PG_MSPI + 32'h00, 32'hFF, 32'hA5);
    wr(PG_MSPI + 32'h08, 32'h0);
    #(4.0 * T_CORE);
    check("MSPI_CS_N released", 32'(MSPI_CS_N), 1);
  endtask

  // ------------------------------------------------------------------ firmware console path without firmware: host -> DIAG_TX
  task automatic t_console();
    logic [31:0] d, d2;
    string s;
    int n0;
    logic [7:0] st;
    s = "SFIO\n";
    cur_test = "console";
    wr(PG_UART + 32'h0C, 32'd4);
    uart_bit_ns = 4.0 * T_CORE;
    wr(SH + 32'(R_CTRL), 32'h3);
    uart_q.delete(); diag_q.delete();
    rd(SH + 32'(R_CONSOLE_CNT), d); n0 = d[15:0];
    for (int i = 0; i < s.len(); i++) begin
      hl_write(CC_MAILBOX_BASE + 32'(CC_MBOX_DIAG_TX), 32'(s[i]), 4'hF, st);
      check($sformatf("host write to DIAG_TX char %0d", i), 32'(st), 32'(HL_ST_OK));
    end
    #(400.0 * T_CORE);
    check("die DIAG stream seen", diag_q.size(), s.len());
    check("UART_TX carries the console stream", uart_q.size(), s.len());
    for (int i = 0; i < s.len() && i < uart_q.size(); i++) check($sformatf("console char %0d", i), 32'(uart_q[i]), 32'(s[i]));
    rchk_mask("CONSOLE_CNT forwarded", SH + 32'(R_CONSOLE_CNT), 32'hFFFF, 32'(n0 + s.len()));
    rd(SH + 32'(R_CONSOLE_CNT), d);
    wr(SH + 32'(R_CTRL), 32'h2);                                  // console off
    uart_q.delete();
    hl_write(CC_MAILBOX_BASE + 32'(CC_MBOX_DIAG_TX), 32'h58, 4'hF, st);
    #(200.0 * T_CORE);
    check("CONSOLE_EN = 0: nothing on UART_TX", uart_q.size(), 0);
    begin rd(SH + 32'(R_CONSOLE_CNT), d2);
      check1("CONSOLE_CNT ignored counter advanced by the refused character", d2[31:16] >= d[31:16] + 1);
      check("CONSOLE_CNT forwarded counter unchanged while disabled", 32'(d2[15:0]), 32'(d[15:0])); end
    wr(SH + 32'(R_CTRL), 32'h3);
  endtask

  // ------------------------------------------------------------------ interrupts and RAS through the pins
  task automatic t_irq();
    logic [31:0] d;
    logic [7:0] st;
    real t0;
    cur_test = "irq";
    // die interrupt: a host decode error -> DIE_SYS.ERR -> die IRQ 16 -> host_irq_o -> HOST_IRQ_N
    wr(SYS + 32'(DIE_SYS_ERR_STATUS), 32'hFFFF_FFFF);
    wr(SYS + 32'(DIE_SYS_IRQ_HOST_EN), 32'(1) << DIE_IRQ_DIE_ERR);
    check1("HOST_IRQ_N released", `RELEASED(HOST_IRQ_N, u_dut.u_pad_HOST_IRQ_N.u_cell.c2p_en));
    hl_read(32'h6000_0000, d, st);
    #(20.0 * T_CORE);
    check("die error -> die host IRQ -> HOST_IRQ_N", 32'(HOST_IRQ_N), 0);
    rchk_mask("SHELL.IRQ_STATUS DIE", SH + 32'(R_IRQ_STATUS), 32'h1, 32'h1);
    wr(SYS + 32'(DIE_SYS_ERR_STATUS), 32'hFFFF_FFFF);
    #(20.0 * T_CORE);
    check1("HOST_IRQ_N released after the die error is cleared", `RELEASED(HOST_IRQ_N, u_dut.u_pad_HOST_IRQ_N.u_cell.c2p_en));
    wr(SYS + 32'(DIE_SYS_IRQ_HOST_EN), 32'h0);
    // a disabled source does not reach the pin
    wr(SH + 32'(R_IRQ_ENABLE), 32'h01);
    warn_n_r = 1'b0; #(20.0 * T_CORE);
    check1("BOARD_WARN_N with IRQ_ENABLE[5] = 0: HOST_IRQ_N stays released", `RELEASED(HOST_IRQ_N, u_dut.u_pad_HOST_IRQ_N.u_cell.c2p_en));
    rchk_mask("... but IRQ_STATUS shows it", SH + 32'(R_IRQ_STATUS), 32'h20, 32'h20);
    warn_n_r = 1'b1; #(20.0 * T_CORE);
    // board warning -> SHELL IRQ 5 (enabled) and the die's own RAS input
    wr(SH + 32'(R_IRQ_ENABLE), 32'h21);
    warn_n_r = 1'b0; #(20.0 * T_CORE);
    check("BOARD_WARN_N -> HOST_IRQ_N", 32'(HOST_IRQ_N), 0);
    rchk_mask("SHELL.STATUS BOARD_WARN", SH + 32'(R_STATUS), 32'h20, 32'h20);
    warn_n_r = 1'b1; #(20.0 * T_CORE);
    check1("BOARD_WARN_N released -> HOST_IRQ_N released", `RELEASED(HOST_IRQ_N, u_dut.u_pad_HOST_IRQ_N.u_cell.c2p_en));
    // board fatal -> die RAS -> RAS_FATAL_N pin (pseudo open drain)
    wr(SH + 32'(R_IRQ_ENABLE), 32'hC1);
    fatal_n_r = 1'b0;
    t0 = $realtime;
    while (RAS_FATAL_N !== 1'b0 && ($realtime - t0) < 20_000.0) #(T_CORE);
    check("BOARD_FATAL_N -> die RAS -> RAS_FATAL_N low", 32'(RAS_FATAL_N), 0);
    rchk_mask("SHELL.IRQ_STATUS BOARD_FATAL + RAS_FATAL", SH + 32'(R_IRQ_STATUS), 32'hC0, 32'hC0);
    check("HOST_IRQ_N asserted for the fatal", 32'(HOST_IRQ_N), 0);
    fatal_n_r = 1'b1;
    // the die's fatal state is sticky until reset: restart the chip
    wr(SH + 32'(R_IRQ_ENABLE), 32'h1);
    power_off(); power_up(1'b1);
    check1("RAS_FATAL_N released after reset", `RELEASED(RAS_FATAL_N, u_dut.u_pad_RAS_FATAL_N.u_cell.c2p_en));
  endtask

  // ------------------------------------------------------------------ die integration
  task automatic t_die();
    logic [31:0] d, st32;
    logic [7:0]  st8;
    int          k;
    cur_test = "die";
    rchk("DIE_SYS.ID", SYS + 32'(DIE_SYS_ID), DIE_ID);
    rchk("DIE_SYS.CONFIG_ID", SYS + 32'(DIE_SYS_CONFIG_ID), 32'(`TB_DIE_CFG + 1));
    rchk_mask("DIE_SYS.STATUS PLATFORM_READY", SYS + 32'(DIE_SYS_STATUS), 32'h80, 32'h80);
    rchk("SHELL.VERSION config id mirrors the die", SH + 32'(R_VERSION) , 32'(((`TB_MEM_CTRL == 1) ? 32'h2_0000 : 0) |
         (32'(sf_io_tech_pkg::IO_TECH) << 16) | (32'(`TB_DIE_CFG + 1) << 8) | 32'h01));
    for (int i = 0; i < 8; i++) wr(DIE_SHARED_SRAM_BASE + 32'h100 + 32'(4 * i), 32'hA500_0000 + 32'(i * 32'h0101_0101));
    for (int i = 0; i < 8; i++) rchk($sformatf("shared SRAM word %0d through the pins", i),
                                     DIE_SHARED_SRAM_BASE + 32'h100 + 32'(4 * i), 32'hA500_0000 + 32'(i * 32'h0101_0101));
    // byte strobe through the link
    begin hl_write(DIE_SHARED_SRAM_BASE + 32'h100, 32'h0000_00EE, 4'h1, st8); check("byte write status", 32'(st8), 32'(HL_ST_OK)); end
    rchk("byte-strobe write merged", DIE_SHARED_SRAM_BASE + 32'h100, 32'hA500_00EE);
    begin k = 0;
      rd(CC_SYSCTRL_BASE + 32'(CC_SYSCTRL_BOOT_STAGE), st32);
      while (st32 != CC_BOOT_STAGE_WAIT_IMAGE && k < 200) begin #(2000.0 * T_CORE); rd(CC_SYSCTRL_BASE + 32'(CC_SYSCTRL_BOOT_STAGE), st32); k++; end
      check("ControlCore boot ROM waits for an image", st32, CC_BOOT_STAGE_WAIT_IMAGE); end
    check("die host-port protocol violations", v_die, 0);
  endtask

  // ------------------------------------------------------------------ dependency register
  task automatic t_deps();
    logic [31:0] exp;
    logic [3:0]  mem;
    cur_test = "deps";
    mem = (`TB_MEM_CTRL == 1) ? DEP_SIM_MODEL : DEP_ABSENT;
    exp = {DEP_ABSENT, mem, mem, DEP_ABSENT, DEP_ABSENT, DEP_ABSENT, DEP_PRESENT,
           (sf_io_tech_pkg::IO_TECH == 1) ? DEP_PRESENT : DEP_SIM_MODEL};
    rchk("SHELL.PHY_DEP matches the build", SH + 32'(R_PHY_DEP), exp);
    rchk("SHELL.PCIE: absent", SH + 32'(R_PCIE), 32'h0);
    rchk_mask("SHELL.MEM_PHY: PHY / controller presence", SH + 32'(R_MEM_PHY), 32'h0001_0001,
              (`TB_MEM_CTRL == 1) ? 32'h0001_0001 : 32'h0);
  endtask

  // ------------------------------------------------------------------ HPC without a memory controller (diagnostic build)
  task automatic t_mem_absent();
    logic [31:0] d;
    logic [7:0] st;
    real t0;
    cur_test = "mem_absent";
    t0 = $realtime;
    while (PLATFORM_READY !== 1'b1 && ($realtime - t0) < 2_000_000.0) #(100.0 * T_CORE);
    check("HPC die without a memory controller never reaches PLATFORM_READY", 32'(PLATFORM_READY), 0);
    hl_read(SYS + 32'(DIE_SYS_ID), d, st);
    check("die access refused while not ready", 32'(st), 32'(HL_ST_BUS_ERR));
    rchk_mask("SHELL.MEM_PHY: no PHY, no controller, controller not initialised", SH + 32'(R_MEM_PHY), 32'h0005_0001, 32'h0);
    rchk_mask("SHELL.STATUS MC_INIT_DONE = 0", SH + 32'(R_STATUS), 32'h4000, 32'h0);
    wr(SH + 32'(R_CTRL), 32'h7);                                  // DIE_FORCE: diagnose
    rchk("DIE_FORCE: die identity", SYS + 32'(DIE_SYS_ID), DIE_ID);
    rd(SYS + 32'(DIE_SYS_STATUS), d);
    check("DIE_SYS.STATUS: EXTMEM_READY = 0", 32'(d[DIE_ST_EXTMEM_READY]), 0);
    check("DIE_SYS.STATUS: FABRIC_READY = 1", 32'(d[DIE_ST_FABRIC_READY]), 1);
    check("DIE_SYS.STATUS: PLATFORM_READY = 0", 32'(d[DIE_ST_PLATFORM_READY]), 0);
    rd(DIE_EXTMEM_CSR_BASE + 32'h18, d);
    check("ExtMem bridge: waiting in CAL (P31: CAL_TIMEOUT = 0, wait forever)", 32'(d[2:0]), 32'(XM_CAL));
    check("ExtMem bridge: not READY", 32'(d[3]), 0);
    hl_read(DIE_EXTMEM_BASE, d, st);
    check("external-memory access -> BUS_ERR (UNAVAIL)", 32'(st), 32'(HL_ST_BUS_ERR));
    wr(SH + 32'(R_CTRL), 32'h3);
  endtask

  // ------------------------------------------------------------------ HPC with simulation-only controller + PHY
  task automatic t_memsim();
    logic [31:0] d;
    cur_test = "memsim";
    rd(SH + 32'(R_MEM_PHY), d);
    check("MEM_PHY: PHY present", 32'(d[0]), 1);
    check("MEM_PHY: calibration done", 32'(d[3]), 1);
    check("MEM_PHY: init complete", 32'(d[5]), 1);
    check("MEM_PHY: no calibration failure", 32'(d[4]), 0);
    check("MEM_PHY: controller present + initialised", 32'(d[18:16]), 32'b111);
    check("MEM_PHY: PHY state READY", 32'(d[23:20]), 4);
    rchk_mask("ExtMem bridge READY", DIE_EXTMEM_CSR_BASE + 32'h18, 32'h18, 32'h08);
    rchk_mask("SHELL.IRQ_STATUS MEM_EVT (controller came up)", SH + 32'(R_IRQ_STATUS), 32'h200, 32'h200);
    wr(SH + 32'(R_IRQ_CLEAR), 32'h200);
    rchk_mask("MEM_EVT cleared", SH + 32'(R_IRQ_STATUS), 32'h200, 32'h0);
    for (int i = 0; i < 8; i++) wr(DIE_EXTMEM_BASE + 32'h40 + 32'(4 * i), 32'h5EED_0000 + 32'(i));
    for (int i = 0; i < 8; i++) rchk($sformatf("external memory word %0d through the pins", i),
                                     DIE_EXTMEM_BASE + 32'h40 + 32'(4 * i), 32'h5EED_0000 + 32'(i));
`ifdef SF_IO_SIM_MODELS
    check("SFMC rule violations seen by the controller model", 32'(u_dut.u_mem.g_sim.st_violations), 0);
    check1("controller model saw the writes and reads", u_dut.u_mem.g_sim.st_wr_cmds >= 8 && u_dut.u_mem.g_sim.st_rd_cmds >= 8);
`endif
  endtask
  task automatic t_memcalfail();
    logic [31:0] d;
    real t0;
    cur_test = "memcalfail";
    t0 = $realtime;
    while (PLATFORM_READY !== 1'b1 && ($realtime - t0) < 2_000_000.0) #(100.0 * T_CORE);
    check("calibration failure: no PLATFORM_READY", 32'(PLATFORM_READY), 0);
    rd(SH + 32'(R_MEM_PHY), d);
    check("MEM_PHY: CAL_FAIL", 32'(d[4]), 1);
    check("MEM_PHY: error code 7", 32'(d[15:8]), 7);
    check("MEM_PHY: state CALFAIL", 32'(d[23:20]), 5);
    check("MEM_PHY: controller not initialised", 32'(d[18]), 0);
    wr(SH + 32'(R_CTRL), 32'h7);
    rd(DIE_EXTMEM_CSR_BASE + 32'h18, d);
    check("ExtMem bridge still waiting in CAL (controller never initialised)", 32'(d[2:0]), 32'(XM_CAL));
    check("ExtMem bridge not READY", 32'(d[3]), 0);
    wr(SH + 32'(R_CTRL), 32'h3);
  endtask

  // ------------------------------------------------------------------ firmware through the pins
  logic [31:0] fw_img[$];                     // module scope: Icarus 12 cannot allocate automatic queues / arrays
  logic [31:0] rsp[8];
  task automatic t_firmware();
    string fw;
    int fd, nw, guard;
    logic [31:0] w, v;
    real t0;
    logic [7:0] st;
    logic [31:0] us, bst;
    int k;
    cur_test = "firmware";
    if (!$value$plusargs("fw=%s", fw)) fw = "third_party/silicaflux-dietop/third_party/silicaflux-controlcore/firmware/build/fw/controlcore_fw.hex";
    fd = $fopen(fw, "r");
    if (fd == 0) check1("firmware image readable", 1'b0);
    else begin
      while ($fscanf(fd, "%h\n", w) == 1) fw_img.push_back(w);
      $fclose(fd);
    end
    $display("[%0t] firmware: %0d words, loading through HOST_SCK/CS_N/MOSI/MISO", $time, fw_img.size());
    // console: stop it, let the UART drain the boot-ROM characters at the reset baud rate, then
    // switch to 4 clk / bit (mcu_uart clamps BAUD to >= 4) and capture everything from here on
    wr(SH + 32'(R_CTRL), 32'h2);
    begin k = 0; rd(PG_UART + 32'h04, us);
      while (!us[1] && k < 200) begin #(5000.0 * T_CORE); rd(PG_UART + 32'h04, us); k++; end end   // STATUS[1] TX idle
    #(4000.0 * T_CORE);
    wr(PG_UART + 32'h0C, 32'd4);
    uart_bit_ns = 4.0 * T_CORE;
    uart_q.delete(); diag_q.delete();
    wr(SH + 32'(R_CTRL), 32'h3);
    // the boot ROM reaches WAIT_IMAGE some time after reset (P31's testbench polls for it too)
    begin k = 0;
      rd(CC_SYSCTRL_BASE + 32'(CC_SYSCTRL_BOOT_STAGE), bst);
      while (bst != CC_BOOT_STAGE_WAIT_IMAGE && k < 400) begin #(2000.0 * T_CORE); rd(CC_SYSCTRL_BASE + 32'(CC_SYSCTRL_BOOT_STAGE), bst); k++; end
      check("boot ROM waits for an image", bst, CC_BOOT_STAGE_WAIT_IMAGE); end
    t0 = $realtime;
    for (int i = 0; i < fw_img.size(); i++) wr(CC_IMEM_BASE + 32'(4 * i), fw_img[i]);
    $display("[%0t] firmware: image loaded in %0.0f us of simulated time", $time, ($realtime - t0) / 1000.0);
    // mailbox: IMAGE_READY, answer signalled on the HOST_IRQ_N pin
    wr(CC_MAILBOX_BASE + 32'(CC_MBOX_H2F_MSG0), CC_MBOX_CMD_IMAGE_READY);
    wr(CC_MAILBOX_BASE + 32'(CC_MBOX_H2F_RING), CC_MBOX_CMD_IMAGE_READY);
    t0 = $realtime;
    while (HOST_IRQ_N !== 1'b0 && ($realtime - t0) < 30_000_000.0) #(10.0 * T_CORE);
    check("mailbox answer on the HOST_IRQ_N pin", 32'(HOST_IRQ_N), 0);
    for (int i = 0; i < 4; i++) rd(CC_MAILBOX_BASE + 32'(CC_MBOX_F2H_MSG0) + 32'(4 * i), rsp[i]);
    wr(CC_MAILBOX_BASE + 32'(CC_MBOX_F2H_ACK), 0);
    check("boot ROM accepted the image (CRC32)", rsp[0] & 32'hFF, CC_MBOX_STS_OK);
    t0 = $realtime;
    while (DEVICE_READY !== 1'b1 && ($realtime - t0) < 60_000_000.0) #(10.0 * T_CORE);
    check("DEVICE_READY pad rises (firmware up)", 32'(DEVICE_READY), 1);
    // drain the boot mailbox message if any, then PING
    #(2000.0 * T_CORE);
    if (HOST_IRQ_N === 1'b0) begin
      for (int i = 0; i < 4; i++) rd(CC_MAILBOX_BASE + 32'(CC_MBOX_F2H_MSG0) + 32'(4 * i), rsp[i]);
      wr(CC_MAILBOX_BASE + 32'(CC_MBOX_F2H_ACK), 0);
    end
    #(200.0 * T_CORE);
    wr(CC_MAILBOX_BASE + 32'(CC_MBOX_H2F_MSG0) + 4, 32'h1234_5678);
    wr(CC_MAILBOX_BASE + 32'(CC_MBOX_H2F_MSG0), CC_MBOX_CMD_PING);
    wr(CC_MAILBOX_BASE + 32'(CC_MBOX_H2F_RING), CC_MBOX_CMD_PING);
    t0 = $realtime;
    while (HOST_IRQ_N !== 1'b0 && ($realtime - t0) < 10_000_000.0) #(10.0 * T_CORE);
    for (int i = 0; i < 4; i++) rd(CC_MAILBOX_BASE + 32'(CC_MBOX_F2H_MSG0) + 32'(4 * i), rsp[i]);
    wr(CC_MAILBOX_BASE + 32'(CC_MBOX_F2H_ACK), 0);
    check("PING status", rsp[0] & 32'hFF, CC_MBOX_STS_OK);
    check("PING echo through the pins", rsp[1], 32'h1234_5678);
    // SHUTDOWN reports to the TEST_DONE / TEST_FAIL pads
    wr(CC_MAILBOX_BASE + 32'(CC_MBOX_H2F_MSG0) + 4, 32'd0);
    wr(CC_MAILBOX_BASE + 32'(CC_MBOX_H2F_MSG0), CC_MBOX_CMD_SHUTDOWN);
    wr(CC_MAILBOX_BASE + 32'(CC_MBOX_H2F_RING), CC_MBOX_CMD_SHUTDOWN);
    t0 = $realtime;
    while (TEST_DONE !== 1'b1 && ($realtime - t0) < 10_000_000.0) #(10.0 * T_CORE);
    check("TEST_DONE pad", 32'(TEST_DONE), 1);
    check("TEST_FAIL pad", 32'(TEST_FAIL), 0);
    rchk_mask("SHELL.DIE_TEST done, not failed", SH + 32'(R_DIE_TEST), 32'h3_0000, 32'h1_0000);
    // console: everything the firmware wrote to DIAG_TX left on UART_TX
    #(5000.0 * T_CORE);
    rd(PG_UART + 32'h04, v);
    $display("[%0t] firmware: DIAG stream %0d chars, UART_TX %0d chars, UART TX_OVF %0d", $time, diag_q.size(), uart_q.size(), v[5]);
    check1("firmware printed on the console", diag_q.size() > 0);
    if (v[5] == 1'b0) begin                                     // STATUS[5] TX_OVF
      check("UART_TX carries the whole console stream", uart_q.size(), diag_q.size());
      nw = 0;
      for (int i = 0; i < diag_q.size() && i < uart_q.size(); i++) if (uart_q[i] != diag_q[i]) nw++;
      check("console characters identical", 32'(nw), 0);
    end else begin
      // the die's DIAG stream has no backpressure: a full TX FIFO drops characters (sticky TX_OVF);
      // what leaves UART_TX must still be the console, in order, with characters missing only
      nw = 0;                                                   // characters of uart_q matched so far
      for (int i = 0; i < diag_q.size() && nw < uart_q.size(); i++) if (diag_q[i] == uart_q[nw]) nw++;
      check1("TX_OVF: UART_TX is an in-order subsequence of the console, characters dropped", uart_q.size() < diag_q.size());
      check("TX_OVF: every UART_TX character matched in order", 32'(nw), 32'(uart_q.size()));
    end
    check("UART_TX framing", 32'(uart_frame_err), 0);
  endtask

  // optional trace (+trace): periodic view of the chip's internal state
  longint clk_edges = 0, raw_edges = 0;
  always @(posedge u_dut.clk) clk_edges <= clk_edges + 1;
  always @(posedge u_dut.clk_core_in) raw_edges <= raw_edges + 1;
  initial if ($test$plusargs("trace")) forever begin
    #(20_000.0);
    $display("[%0t] TRACE2 clk_edges=%0d raw_edges=%0d host_cs_np=%b sck=%b die_stage=%0d die_fab=%b die_cc=%b",
             $time, clk_edges, raw_edges, u_dut.host_cs_np, u_dut.host_sck_p,
             `TB_DIE_TOP.u_clkrst.st_q, `TB_DIE_TOP.u_clkrst.fab_q, `TB_DIE_TOP.u_clkrst.cc_q);
    $display("[%0t] TRACE3 reset_done=%b mem_ready=%b ext_ready=%b cc_running=%b compute_ready=%b",
             $time, `TB_DIE_TOP.u_sysctrl.reset_done, `TB_DIE_TOP.u_sysctrl.mem_ready,
             `TB_DIE_TOP.u_sysctrl.extmem_ready, `TB_DIE_TOP.u_sysctrl.cc_running,
             `TB_DIE_TOP.u_sysctrl.compute_ready);
    $display("[%0t] TRACE rst_n=%b die_por_n=%b crt_state=%0d sys_ready=%b lock=%b clk=%b plat=%b dev=%b cs_s=%b miso=%b/%b hl_busy=%b split_st=%0d",
             $time, u_dut.rst_n, u_dut.die_por_n, u_dut.crt_seq_state, u_dut.crt_sys_ready, u_dut.clkgen_lock, u_dut.clk,
             PLATFORM_READY, DEVICE_READY, u_dut.u_hlink.cs_s, u_dut.miso, u_dut.miso_oe, u_dut.hl_busy, u_dut.u_split.st);
  end

`ifdef SF_IO_MUTATION
  // mutation testing (scripts/mutate.py): select the mutant before anything runs
  int mut_k;
  initial if ($value$plusargs("MUT=%d", mut_k)) sf_io_mut_pkg::sel = mut_k;
`endif

  // ==================================================================== main
  initial begin
    real tmo;
    if (!$value$plusargs("timeout_ms=%f", tmo)) tmo = 400.0;
    #(tmo * 1_000_000.0);
    $display("TB RESULT FAIL TIMEOUT at %0t (test %s) checks=%0d fails=%0d", $time, cur_test, checks, fails + 1);
    $finish;
  end

  initial begin
    string test;
    if (!$value$plusargs("TEST=%s", test)) test = "all";
    #2;                                                   // after the t = 1 ns POR edge
    $display("tb_io_shell: TEST=%s DIE_CFG=%0d MEM_CTRL=%0d IO_TECH=%0d", test, `TB_DIE_CFG, `TB_MEM_CTRL, sf_io_tech_pkg::IO_TECH);
    if (test == "reset") t_reset();
    else if (test == "mem_absent") begin power_up(1'b0); t_mem_absent(); t_deps(); end
    else if (test == "memcalfail") begin power_up(1'b0); t_memcalfail(); end
    else begin
      power_up(1'b1);
      if (test == "all" || test == "hostlink")  t_hostlink();   // first: checks RESULT with no transaction yet
      if (test == "all" || test == "direction") t_direction();
      if (test == "all" || test == "jtag")      t_jtag();
      if (test == "all" || test == "gpio")      t_gpio();
      if (test == "all" || test == "uart")      t_uart();
      if (test == "all" || test == "mspi")      t_mspi();
      if (test == "all" || test == "console")   t_console();
      if (test == "all" || test == "die")       t_die();
      if (test == "all" || test == "deps")      t_deps();
      if (test == "memsim")                     t_memsim();
      if (test == "all" || test == "irq")       t_irq();
      if (test == "all" || test == "fence")     t_fence();
      if (test == "all" || test == "clock")     t_clock();
      if (test == "all" || test == "dieready")  t_dieready();
      if (test == "all")                        t_reset();
      if (test == "firmware")                   t_firmware();
    end
    #(100.0 * T_CORE);
    check("SFB2 protocol violations (host link / shell window / die port)", v_hl + v_sh + v_die, 0);
    check("X / contention on pads", 32'(xviol), 0);
    $display("TB RESULT %s checks=%0d fails=%0d", (fails == 0) ? "PASS" : "FAIL", checks, fails);
    $finish;
  end

endmodule

`default_nettype wire
