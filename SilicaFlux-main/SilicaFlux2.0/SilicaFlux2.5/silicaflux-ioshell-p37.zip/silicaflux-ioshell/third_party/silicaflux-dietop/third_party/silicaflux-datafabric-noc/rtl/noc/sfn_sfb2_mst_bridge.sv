// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_sfb2_mst_bridge -- SFB2 master -> SFB3 master port
//
// Connects an existing SFB2 master unmodified (SilicaFlux-V CPU data port,
// DataFabric DMA, HPC tile DMA, TensorCore unit).  Purely combinational:
//   req_write -> OP_WRITE (acknowledged; an SFB2 master expects a response) / OP_READ
//   ID        -> a constant per port: SFB2 masters expect in-order responses, and
//                one ID guarantees in-order responses (PROTOCOL.md O2)
//   QOS       -> a constant per port (traffic class of the endpoint)
//   rsp_error <- status != OKAY
// The SFB2 master's own outstanding limit (1 for the CPU, MAX_OUT for the tensor
// unit / buffered DMA) is preserved; set the fabric's MST_MAXO >= it to use it.
// =============================================================================
`default_nettype none

module sfn_sfb2_mst_bridge #(
  parameter int             AW  = 32,
  parameter int             DW  = 32,
  parameter int             IDW = 2,
  parameter logic [IDW-1:0] ID  = '0,
  parameter logic [2:0]     QOS = 3'd0,
  localparam int            SB  = DW / 8
) (
  // ---------------------------------------------------------------- SFB2 master
  input  wire logic           s_req_valid,
  output logic                s_req_ready,
  input  wire logic           s_req_write,
  input  wire logic [AW-1:0]  s_req_addr,
  input  wire logic [DW-1:0]  s_req_wdata,
  input  wire logic [SB-1:0]  s_req_wstrb,
  output logic                s_rsp_valid,
  input  wire logic           s_rsp_ready,
  output logic [DW-1:0]       s_rsp_rdata,
  output logic                s_rsp_error,
  // ---------------------------------------------------------------- SFB3 master port (to the fabric)
  output logic                m_req_valid,
  input  wire logic           m_req_ready,
  output logic [2:0]          m_req_opcode,
  output logic [IDW-1:0]      m_req_id,
  output logic [2:0]          m_req_qos,
  output logic [AW-1:0]       m_req_addr,
  output logic [DW-1:0]       m_req_wdata,
  output logic [SB-1:0]       m_req_wstrb,
  input  wire logic           m_rsp_valid,
  output logic                m_rsp_ready,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [IDW-1:0] m_rsp_id,
  input  wire logic [2:0]     m_rsp_opcode,
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [1:0]     m_rsp_status,
  input  wire logic [DW-1:0]  m_rsp_rdata
);
  assign m_req_valid  = s_req_valid;
  assign s_req_ready  = m_req_ready;
  assign m_req_opcode = s_req_write ? sfn_pkg::OP_WRITE : sfn_pkg::OP_READ;
  assign m_req_id     = ID;
  assign m_req_qos    = QOS;
  assign m_req_addr   = s_req_addr;
  assign m_req_wdata  = s_req_wdata;
  assign m_req_wstrb  = s_req_wstrb;
  assign s_rsp_valid  = m_rsp_valid;
  assign m_rsp_ready  = s_rsp_ready;
  assign s_rsp_rdata  = m_rsp_rdata;
  assign s_rsp_error  = (m_rsp_status != sfn_pkg::ST_OKAY);
endmodule

`default_nettype wire
