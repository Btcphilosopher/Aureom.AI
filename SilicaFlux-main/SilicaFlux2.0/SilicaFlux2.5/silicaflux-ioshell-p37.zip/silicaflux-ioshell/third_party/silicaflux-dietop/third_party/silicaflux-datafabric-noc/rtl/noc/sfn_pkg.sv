// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_pkg -- shared protocol package (SFB3)
//
// SFB3 is revision 3 of the SilicaFlux bus.  It is the additive extension that
// DataFabric's PROTOCOL.md sec. 8 planned for SFB2: transaction IDs, several
// outstanding transactions per port, source identifiers on the target side,
// explicit opcodes (posted writes, FENCE) and response status codes.  An SFB2
// master or slave attaches through sfn_sfb2_mst_bridge / sfn_sfb2_tgt_bridge.
// Normative definition: docs/PROTOCOL.md.
//
// Tool rules (Yosys 0.33 front end): package holds localparams and functions
// written in the "assign to the function name" style only (no `return`, no
// typedefs, no structs), so every tool in the flow elaborates it identically.
// =============================================================================
package sfn_pkg;
  /* verilator lint_off UNUSEDPARAM */

  // ------------------------------------------------------------------ opcodes
  localparam int          OPW             = 3;
  localparam logic [2:0]  OP_READ         = 3'd0;  // read one DW-wide word, response carries data
  localparam logic [2:0]  OP_WRITE        = 3'd1;  // acknowledged write: response after the write is performed
  localparam logic [2:0]  OP_WRITE_POSTED = 3'd2;  // posted write: no response to the master (completion
                                                    // returns to the fabric, which retires it; errors -> event)
  localparam logic [2:0]  OP_FENCE        = 3'd3;  // completes when every earlier transaction of the
                                                    // master has completed; answered by the fabric itself
  // 3'd4 .. 3'd7 reserved: answered by the fabric with ST_DECERR, never forwarded

  // ------------------------------------------------------------------ response status
  localparam int          STW        = 2;
  localparam logic [1:0]  ST_OKAY    = 2'd0;
  localparam logic [1:0]  ST_SLVERR  = 2'd1;    // target reported an error (no side effect)
  localparam logic [1:0]  ST_DECERR  = 2'd2;    // fabric: unmapped / denied / misaligned / reserved opcode
  // 2'd3 reserved

  // ------------------------------------------------------------------ QoS classes (req_qos)
  // Larger value = more urgent.  Priority is latency preference only, never a
  // bandwidth guarantee; starvation is bounded by the aging rule of sfn_qos_arbiter.
  localparam int          QOSW        = 3;
  localparam logic [2:0]  QOS_DMA     = 3'd0;   // bulk DMA traffic
  localparam logic [2:0]  QOS_TENSOR  = 3'd1;   // TensorCore operand / result transfers
  localparam logic [2:0]  QOS_VECTOR  = 3'd2;   // vector-tile transfers
  localparam logic [2:0]  QOS_CTRL    = 3'd3;   // latency-sensitive ControlCore traffic
  localparam logic [2:0]  QOS_EVENT   = 3'd4;   // error / status events
  // 3'd5 .. 3'd7 legal, unnamed

  // ------------------------------------------------------------------ arbitration modes
  localparam int ARB_FIXED = 0;   // fixed priority by port index (port 0 highest) -- may starve
  localparam int ARB_RR    = 1;   // round robin, pointer moves on acceptance (bounded waiting N-1)
  localparam int ARB_QOS   = 2;   // QoS level, round robin inside a level, aging (bound STARVE+N-1)

  // ------------------------------------------------------------------ topologies
  localparam int TOPO_SHARED_BUS = 0;
  localparam int TOPO_CROSSBAR   = 1;
  localparam int TOPO_MESH       = 2;

  // ------------------------------------------------------------------ mesh router ports
  localparam int PORT_L = 0;      // local (network interface)
  localparam int PORT_N = 1;      // y - 1
  localparam int PORT_E = 2;      // x + 1
  localparam int PORT_S = 3;      // y + 1
  localparam int PORT_W = 4;      // x - 1
  localparam int NPORT  = 5;

  // ------------------------------------------------------------------ helpers
  // width of an index into n things (at least 1 bit)
  function automatic integer clog2c(input integer n);
    begin
      if (n > 1) clog2c = $clog2(n);
      else       clog2c = 1;
    end
  endfunction

  // opcode forwarded to a target
  function automatic logic op_to_target(input logic [2:0] op);
    begin
      op_to_target = (op == OP_READ) || (op == OP_WRITE) || (op == OP_WRITE_POSTED);
    end
  endfunction

  // opcode that writes
  function automatic logic op_is_write(input logic [2:0] op);
    begin
      op_is_write = (op == OP_WRITE) || (op == OP_WRITE_POSTED);
    end
  endfunction

  // ------------------------------------------------------------------ mesh flit format
  // flit = {head, tail, payload[FW-1:0]}; a packet is 1 or 2 flits.
  //   request  head : {dst_node, src, id, opcode, qos, wstrb, addr}       (+ data flit {wdata} for writes)
  //   response head : {dst_node, tgt, id, opcode, status}                 (+ data flit {rdata} for reads)
  // Field widths are derived from the fabric parameters by the functions below,
  // so no address, tag or source bit is ever truncated.
  function automatic integer req_hdr_w(input integer nodew, input integer srcw, input integer idw,
                                       input integer sb, input integer aw);
    begin
      req_hdr_w = nodew + srcw + idw + OPW + QOSW + sb + aw;
    end
  endfunction

  function automatic integer rsp_hdr_w(input integer nodew, input integer tw, input integer idw);
    begin
      rsp_hdr_w = nodew + tw + idw + OPW + STW;
    end
  endfunction

  function automatic integer max3(input integer a, input integer b, input integer c);
    begin
      max3 = a;
      if (b > max3) max3 = b;
      if (c > max3) max3 = c;
    end
  endfunction

  /* verilator lint_on UNUSEDPARAM */
endpackage
