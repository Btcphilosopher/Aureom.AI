// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_mst_port -- per-master front end (all topologies)
//
// Sits between one SFB3 master and the switching core (crossbar, shared bus or
// mesh network interface).  It owns every per-master rule of docs/PROTOCOL.md:
//
//  * decode    : DataFabric sfb_addr_decoder (unmodified) -- base/mask regions,
//                access matrix EN, alignment check.  Opcode check: READ, WRITE,
//                WRITE_POSTED go to a target; FENCE and reserved opcodes and
//                every decode miss go to the LOCAL responder (index NT).
//  * tracking  : out_cnt (all outstanding) and, per transaction ID, a count and
//                the target it is outstanding at.
//                  O1  out_cnt never exceeds MAXO;
//                  O2  all outstanding transactions of one ID are at ONE target
//                      (a request of ID i to another target waits until ID i has
//                      drained) => responses of one ID return in request order;
//                  O3  FENCE is accepted only when nothing is outstanding, so it
//                      completes after every earlier transaction (posted writes
//                      included: their completions are retired here).
//                With RETIRE_BYPASS = 1 a response retiring in the same cycle frees
//                its slot in that cycle (no bubble, same as SFB2's accept-while-
//                retiring rule) at the cost of a combinational path from the
//                response side into the request side; RETIRE_BYPASS = 0 keeps the
//                two sides independent (docs/ARCHITECTURE.md sec. 6).
//  * local responder: one entry; answers FENCE with OKAY and decode errors /
//                reserved opcodes with DECERR one cycle after acceptance.
//                A POSTED write that decodes to an error has no response: it is
//                accepted, dropped (no side effect) and reported on ev_decerr.
//  * responses : merges switch responses and local responses (round robin, grant
//                lock while the master stalls).  Posted-write completions are
//                retired here and never shown to the master; an error status in
//                one is reported on ev_posted_err.  A switch response that matches no
//                outstanding transaction (wrong target for its ID, or ID not
//                outstanding) is an ORPHAN: it is consumed, never delivered, and
//                reported on ev_orphan (target fault containment).
//
// Combinational paths: m_req_* -> fq_*; fq_ready -> m_req_ready; fr_* -> m_rsp_*;
// m_rsp_ready -> fr_ready; and only with RETIRE_BYPASS = 1: m_rsp_ready, fr_* ->
// m_req_ready (retire-and-issue).  With the default RETIRE_BYPASS = 0 the request
// side depends on registered tracker state only.
// =============================================================================
`default_nettype none

module sfn_mst_port #(
  parameter int               NT          = 4,
  parameter int               AW          = 32,
  parameter int               DW          = 32,
  parameter int               IDW         = 2,
  parameter int               MAXO_MAX    = 4,       // sizes the counters
  parameter int               MAXO        = 4,       // this master's limit, 1..MAXO_MAX
  parameter int               CHECK_ALIGN = 1,
  parameter int               RETIRE_BYPASS = 0,     // 1: a slot freed by a response retiring this cycle is reusable
                                                     //    this cycle (no bubble; long response->request path)
                                                     // 0: eligibility from registered state only (short paths,
                                                     //    one bubble per back-to-back transaction at the limit)
  parameter logic [NT*AW-1:0] TGT_BASE    = {(NT*AW){1'b0}},
  parameter logic [NT*AW-1:0] TGT_MASK    = {(NT*AW){1'b0}},
  parameter logic [NT-1:0]    EN          = {NT{1'b1}},
  localparam int              SB          = DW / 8,
  localparam int              TW          = sfn_pkg::clog2c(NT + 1),   // NT = LOCAL
  localparam int              SW          = (NT > 1) ? $clog2(NT) : 1, // sfb_addr_decoder sel width
  localparam int              NID         = 1 << IDW,
  localparam int              CW          = sfn_pkg::clog2c(MAXO_MAX + 1)
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  // ------------------------------------------------------------ SFB3 master port
  input  wire logic           m_req_valid,
  output logic                m_req_ready,
  input  wire logic [2:0]     m_req_opcode,
  input  wire logic [IDW-1:0] m_req_id,
  input  wire logic [2:0]     m_req_qos,
  input  wire logic [AW-1:0]  m_req_addr,
  input  wire logic [DW-1:0]  m_req_wdata,
  input  wire logic [SB-1:0]  m_req_wstrb,
  output logic                m_rsp_valid,
  input  wire logic           m_rsp_ready,
  output logic [IDW-1:0]      m_rsp_id,
  output logic [2:0]          m_rsp_opcode,
  output logic [1:0]          m_rsp_status,
  output logic [DW-1:0]       m_rsp_rdata,
  // ------------------------------------------------------------ to the switching core
  output logic                fq_valid,
  input  wire logic           fq_ready,
  output logic [TW-1:0]       fq_tgt,
  output logic [2:0]          fq_opcode,
  output logic [IDW-1:0]      fq_id,
  output logic [2:0]          fq_qos,
  output logic [AW-1:0]       fq_addr,
  output logic [DW-1:0]       fq_wdata,
  output logic [SB-1:0]       fq_wstrb,
  // ------------------------------------------------------------ from the switching core
  input  wire logic           fr_valid,
  output logic                fr_ready,
  input  wire logic [TW-1:0]  fr_tgt,
  input  wire logic [IDW-1:0] fr_id,
  input  wire logic [2:0]     fr_opcode,
  input  wire logic [1:0]     fr_status,
  input  wire logic [DW-1:0]  fr_rdata,
  // ------------------------------------------------------------ status / events
  output logic [CW-1:0]       out_cnt,        // outstanding transactions (queue occupancy)
  output logic                id_idle,        // nothing outstanding with m_req_id (latency sampler)
  output logic                ev_blk_out,     // request held back by the MAXO limit (O1)
  output logic                ev_blk_id,      // request held back by the per-ID target rule (O2)
  output logic                ev_blk_fence,   // FENCE waiting for earlier transactions (O3)
  output logic                ev_decerr,      // a request answered (or dropped) with DECERR accepted
  output logic                ev_posted_done, // posted-write completion retired
  output logic                ev_posted_err,  // posted-write completion with an error status (SLVERR)
                                              // (a posted write dropped by decode is ev_decerr)
  output logic                ev_orphan       // unmatched switch response consumed
);
  localparam logic [TW-1:0] LOCAL = TW'(NT);

  // ================================================================ decode
  logic          dec_hit;
  logic [SW-1:0] dec_sel;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NT-1:0] dec_oh_unused;
  logic          dec_mis_unused;
  /* verilator lint_on UNUSEDSIGNAL */
  sfb_addr_decoder #(
    .NS(NT), .AW(AW), .DW(DW), .CHECK_ALIGN(CHECK_ALIGN),
    .SLV_BASE(TGT_BASE), .SLV_MASK(TGT_MASK), .EN(EN)
  ) u_dec (
    .addr(m_req_addr), .hit(dec_hit), .sel(dec_sel), .sel_oh(dec_oh_unused), .misaligned(dec_mis_unused)
  );

  wire op_fwd   = sfn_pkg::op_to_target(m_req_opcode);
  wire is_fence = (m_req_opcode == sfn_pkg::OP_FENCE);
  wire is_post  = (m_req_opcode == sfn_pkg::OP_WRITE_POSTED);
  wire to_tgt   = op_fwd && dec_hit;
  wire [TW-1:0] tgt = to_tgt ? TW'(dec_sel) : LOCAL;
  // a posted write that cannot be delivered is dropped without a response
  wire post_drop = !to_tgt && is_post;

  // ================================================================ tracker state
  logic              run_q;     // 0 during reset and its first cycle: nothing is accepted or delivered (R11)
  logic [CW-1:0]     out_q;
  logic [NID*CW-1:0] idc_q;     // per-ID outstanding count
  logic [NID*TW-1:0] idt_q;     // per-ID target (valid when count != 0)

  // ================================================================ responses
  // local responder (one entry)
  logic           lr_valid_q;
  logic [IDW-1:0] lr_id_q;
  logic [2:0]     lr_op_q;
  logic [1:0]     lr_st_q;

  wire [CW-1:0] fr_idc   = idc_q[fr_id*CW +: CW];
  wire [TW-1:0] fr_idt   = idt_q[fr_id*TW +: TW];
  wire          fr_legit = run_q && fr_valid && (fr_tgt != LOCAL) && (fr_idc != '0) && (fr_idt == fr_tgt);
  wire          fr_post  = (fr_opcode == sfn_pkg::OP_WRITE_POSTED);

  logic [1:0] rgrant;
  /* verilator lint_off UNUSEDSIGNAL */
  logic       rgidx_unused;
  logic       rgv_unused;
  /* verilator lint_on UNUSEDSIGNAL */
  logic       ret;
  logic [IDW-1:0] ret_id;

  // response merge: [0] switch response, [1] local responder
  sfb_arbiter #(.N(2), .MODE(1)) u_rarb (
    .clk, .rst_n, .req({lr_valid_q, fr_legit}),
    .stall(m_rsp_valid && !m_rsp_ready), .accept(ret),
    .grant(rgrant), .grant_idx(rgidx_unused), .grant_valid(rgv_unused)
  );

  wire sel_fr = rgrant[0];
  wire sel_lr = rgrant[1];

  assign m_rsp_valid  = (sel_fr && !fr_post) || sel_lr;
  assign m_rsp_id     = sel_lr ? lr_id_q : fr_id;
  assign m_rsp_opcode = sel_lr ? lr_op_q : fr_opcode;
  assign m_rsp_status = sel_lr ? lr_st_q : fr_status;
  assign m_rsp_rdata  = sel_lr ? '0      : fr_rdata;

  wire fr_take = sel_fr && (fr_post || m_rsp_ready);
  wire lr_hs   = sel_lr && m_rsp_ready;
  assign fr_ready = fr_take || (run_q && fr_valid && !fr_legit);
  assign ret      = fr_take || lr_hs;
  assign ret_id   = sel_lr ? lr_id_q : fr_id;

  assign ev_orphan      = run_q && fr_valid && !fr_legit;
  assign ev_posted_done = fr_take && fr_post;

  // ================================================================ request eligibility
  wire [CW-1:0] r_idc = idc_q[m_req_id*CW +: CW];
  wire [TW-1:0] r_idt = idt_q[m_req_id*TW +: TW];
  wire byp      = (RETIRE_BYPASS != 0) && ret;
  wire cnt_ok   = (out_q < CW'(MAXO)) || byp;
  wire id_ok    = (r_idc == '0) || (r_idt == tgt) || ((r_idc == CW'(1)) && byp && (ret_id == m_req_id));
  wire fence_ok = !is_fence || (out_q == '0) || ((out_q == CW'(1)) && byp);
  wire elig     = run_q && cnt_ok && id_ok && fence_ok;
  wire lr_free  = !lr_valid_q || ((RETIRE_BYPASS != 0) && lr_hs);

  assign fq_valid    = m_req_valid && to_tgt && elig;
  assign fq_tgt      = tgt;
  assign fq_opcode   = m_req_opcode;
  assign fq_id       = m_req_id;
  assign fq_qos      = m_req_qos;
  assign fq_addr     = m_req_addr;
  assign fq_wdata    = m_req_wdata;
  assign fq_wstrb    = m_req_wstrb;
  assign m_req_ready = elig && (to_tgt ? fq_ready : (post_drop || lr_free));

  wire acc    = m_req_valid && m_req_ready;
  wire track  = acc && !post_drop;
  wire lr_ld  = acc && !to_tgt && !post_drop;

  assign ev_blk_out    = run_q && m_req_valid && !cnt_ok;
  assign ev_blk_id     = run_q && m_req_valid && cnt_ok && !id_ok;
  assign ev_blk_fence  = run_q && m_req_valid && is_fence && !fence_ok;
  assign ev_decerr     = acc && !to_tgt && !is_fence;
  assign ev_posted_err = ev_posted_done && (fr_status != sfn_pkg::ST_OKAY);
  assign out_cnt       = out_q;
  assign id_idle       = (r_idc == '0);

  // ================================================================ state update
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      run_q      <= 1'b0;
      out_q      <= '0;
      idc_q      <= '0;
      idt_q      <= '0;
      lr_valid_q <= 1'b0;
      lr_id_q    <= '0;
      lr_op_q    <= '0;
      lr_st_q    <= '0;
    end else begin
      run_q <= 1'b1;
      out_q <= out_q + CW'(track) - CW'(ret);
      for (int i = 0; i < NID; i++) begin
        idc_q[i*CW +: CW] <= idc_q[i*CW +: CW]
                             + CW'(track && (m_req_id == IDW'(i)))
                             - CW'(ret   && (ret_id   == IDW'(i)));
        if (track && (m_req_id == IDW'(i))) idt_q[i*TW +: TW] <= tgt;
      end
      if (lr_ld) begin
        lr_valid_q <= 1'b1;
        lr_id_q    <= m_req_id;
        lr_op_q    <= m_req_opcode;
        lr_st_q    <= is_fence ? sfn_pkg::ST_OKAY : sfn_pkg::ST_DECERR;
      end else if (lr_hs) begin
        lr_valid_q <= 1'b0;
      end
    end
  end

`ifndef SYNTHESIS
  // elaboration checks
  initial begin
    if (MAXO < 1 || MAXO > MAXO_MAX) $fatal(1, "sfn_mst_port: MAXO=%0d outside 1..MAXO_MAX=%0d", MAXO, MAXO_MAX);
    if (DW < 8 || (DW % 8) != 0)     $fatal(1, "sfn_mst_port: DW=%0d must be a multiple of 8", DW);
    if (IDW < 1 || IDW > 8)          $fatal(1, "sfn_mst_port: IDW=%0d outside 1..8", IDW);
  end
`endif
endmodule

`default_nettype wire
