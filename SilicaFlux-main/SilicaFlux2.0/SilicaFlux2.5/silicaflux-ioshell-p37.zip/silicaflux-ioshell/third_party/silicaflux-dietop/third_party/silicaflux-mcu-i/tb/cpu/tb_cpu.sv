// =============================================================================
// SilicaFlux MCU-I :: tb_cpu -- stand-alone CPU testbench
// (derived from third_party/silicaflux-v/tb/cpu/tb_cpu.sv: DUT is mcu_cpu,
//  RV32M parameter added; everything else unchanged)
//
// Two SFB slave models (instruction + data) share one memory image.  Each
// port has a randomised grant probability and response latency (backpressure
// test); interrupts can be injected at random.  Test completion follows the
// riscv-tests "tohost" convention: a store of 1 = PASS, (n<<1)|1 = FAIL(n).
//
// plusargs: +hex=<file> +tohost=<hex addr> +seed=<n> +gnt=<0..100>
//           +lat=<max latency 1..4> +maxcyc=<n> +trace=<file> +irq=<0|1>
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_cpu #(parameter int RV32M = 0);
  localparam logic [31:0] MEM_BASE = 32'h8000_0000;
  localparam int          MEM_WORDS = 65536;          // 256 KiB

  logic clk = 1'b0, rst_n = 1'b1;
  initial #1 rst_n = 1'b0;           // reset asserted with an edge
  always #5 clk = ~clk;

  logic        i_req, i_gnt, i_rvalid, i_err;
  logic [31:0] i_addr, i_rdata;
  logic        d_req, d_gnt, d_we, d_rvalid, d_err;
  logic [3:0]  d_be;
  logic [31:0] d_addr, d_wdata, d_rdata;
  logic        irq_ext, irq_timer, irq_soft, sleeping;
  logic        rt_valid, rt_trap, rt_rd_we;
  logic [31:0] rt_pc, rt_insn, rt_cause, rt_rd_wdata;
  logic [4:0]  rt_rd;

  mcu_cpu #(.BOOT_ADDR(MEM_BASE), .RV32M(RV32M)) dut (
    .clk, .rst_n,
    .i_req, .i_gnt, .i_addr, .i_rvalid, .i_rdata, .i_err,
    .d_req, .d_gnt, .d_addr, .d_we, .d_be, .d_wdata, .d_rvalid, .d_rdata, .d_err,
    .irq_ext, .irq_timer, .irq_soft, .sleeping, .bus_idle(),
    .rt_valid, .rt_pc, .rt_insn, .rt_trap, .rt_cause, .rt_rd, .rt_rd_wdata, .rt_rd_we
  );

  logic [31:0] mem [0:MEM_WORDS-1];
  string       hexfile, tracefile;
  logic [31:0] tohost;
  int          seed, pgnt, maxlat, maxcyc, cyc, fd, use_irq;

  function automatic bit in_mem(input logic [31:0] a);
    in_mem = (a >= MEM_BASE) && (a < MEM_BASE + MEM_WORDS * 4);
  endfunction

  // ------------------------------------------------------------ I port model
  int          i_cnt;           // cycles until response
  logic        i_pend;
  logic [31:0] i_paddr;
  always_comb i_gnt = i_req && ($urandom_range(99) < pgnt);
  always_ff @(posedge clk) begin
    i_rvalid <= 1'b0;
    if (!rst_n) begin
      i_pend <= 1'b0;
    end else begin
      if (i_pend) begin
        if (i_cnt <= 1) begin
          i_rvalid <= 1'b1;
          i_err    <= !in_mem(i_paddr);
          i_rdata  <= in_mem(i_paddr) ? mem[(i_paddr - MEM_BASE) >> 2] : 32'hDEAD_BEEF;
          i_pend   <= 1'b0;
        end else i_cnt <= i_cnt - 1;
      end
      if (i_req && i_gnt) begin
        if (i_pend && i_cnt > 1) $fatal(1, "I-port: second request while pending");
        i_pend  <= 1'b1;
        i_paddr <= i_addr;
        i_cnt   <= $urandom_range(maxlat - 1);   // 0 -> respond next cycle
      end
    end
  end

  // ------------------------------------------------------------ D port model
  int          d_cnt;
  logic        d_pend, d_pwe;
  logic [31:0] d_paddr, d_pwdata;
  logic [3:0]  d_pbe;
  int          result = -1;
  always_comb d_gnt = d_req && ($urandom_range(99) < pgnt);
  always_ff @(posedge clk) begin
    d_rvalid <= 1'b0;
    if (!rst_n) begin
      d_pend <= 1'b0;
    end else begin
      if (d_pend) begin
        if (d_cnt <= 1) begin
          d_rvalid <= 1'b1;
          d_pend   <= 1'b0;
          d_err    <= !in_mem(d_paddr) && (d_paddr != tohost) && (d_paddr != tohost + 4);
          d_rdata  <= in_mem(d_paddr) ? mem[(d_paddr - MEM_BASE) >> 2] : 32'h0;
          if (d_pwe && in_mem(d_paddr)) begin
            for (int b = 0; b < 4; b++)
              if (d_pbe[b]) mem[(d_paddr - MEM_BASE) >> 2][b*8 +: 8] <= d_pwdata[b*8 +: 8];
          end
          if (d_pwe && d_paddr == tohost && d_pwdata != 0) result <= d_pwdata;
        end else d_cnt <= d_cnt - 1;
      end
      if (d_req && d_gnt) begin
        d_pend   <= 1'b1;
        d_paddr  <= d_addr;
        d_pwe    <= d_we;
        d_pbe    <= d_be;
        d_pwdata <= d_wdata;
        d_cnt    <= $urandom_range(maxlat - 1);
      end
    end
  end

  // ------------------------------------------------------------ random IRQs
  // (only meaningful for firmware-style tests that enable interrupts)
  always_ff @(posedge clk) begin
    if (!rst_n || !use_irq) begin
      irq_ext <= 1'b0; irq_timer <= 1'b0; irq_soft <= 1'b0;
    end else begin
      irq_ext   <= ($urandom_range(999) < 2) ? ~irq_ext   : irq_ext;
      irq_timer <= ($urandom_range(999) < 2) ? ~irq_timer : irq_timer;
      irq_soft  <= ($urandom_range(999) < 2) ? ~irq_soft  : irq_soft;
    end
  end

  // ------------------------------------------------------------ protocol checks
  logic        i_req_q, d_req_q, d_gnt_q;
  logic [31:0] d_addr_q, d_wdata_q;
  always_ff @(posedge clk) begin
    if (rst_n) begin
      // D-port: once asserted, request and attributes stay until grant
      if (d_req_q && !d_gnt_q) begin
        if (!d_req) $fatal(1, "D-port retracted request");
        if (d_addr != d_addr_q || d_wdata != d_wdata_q) $fatal(1, "D-port changed attributes before grant");
      end
      if (i_req && i_addr[1:0] != 2'b00) $fatal(1, "misaligned fetch request");
    end
    i_req_q <= i_req; d_req_q <= d_req; d_gnt_q <= d_gnt;
    d_addr_q <= d_addr; d_wdata_q <= d_wdata;
  end

  // ------------------------------------------------------------ trace & control
  always_ff @(posedge clk) begin
    if (rst_n && rt_valid && fd != 0) begin
      if (rt_trap) $fdisplay(fd, "%08x %08x TRAP %08x", rt_pc, rt_insn, rt_cause);
      else if (rt_rd_we) $fdisplay(fd, "%08x %08x x%0d=%08x", rt_pc, rt_insn, rt_rd, rt_rd_wdata);
      else $fdisplay(fd, "%08x %08x", rt_pc, rt_insn);
    end
  end

  initial begin
    if (!$value$plusargs("hex=%s", hexfile)) $fatal(1, "need +hex=");
    if (!$value$plusargs("tohost=%h", tohost)) tohost = 32'h8000_1000;
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    if (!$value$plusargs("gnt=%d", pgnt)) pgnt = 100;
    if (!$value$plusargs("lat=%d", maxlat)) maxlat = 1;
    if (!$value$plusargs("maxcyc=%d", maxcyc)) maxcyc = 200000;
    if (!$value$plusargs("irq=%d", use_irq)) use_irq = 0;
    fd = 0;
    if ($value$plusargs("trace=%s", tracefile)) fd = $fopen(tracefile, "w");
    void'($urandom(seed));
    for (int k = 0; k < MEM_WORDS; k++) mem[k] = 32'h0;
    $readmemh(hexfile, mem);
    repeat (3) @(posedge clk);
    rst_n = 1'b1;
    cyc = 0;
    while (result < 0 && cyc < maxcyc) begin
      @(posedge clk);
      cyc++;
    end
    if (result == 1)
      $display("TB_CPU RESULT PASS cycles=%0d instret=%0d", cyc, dut.minstret_q);
    else if (result < 0)
      $display("TB_CPU RESULT TIMEOUT cycles=%0d pc=%08x", cyc, dut.fb0_pc_q);
    else
      $display("TB_CPU RESULT FAIL test=%0d cycles=%0d", result >> 1, cyc);
    if (fd != 0) $fclose(fd);
    $finish;
  end
endmodule

`default_nettype wire
