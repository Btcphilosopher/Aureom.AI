// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_sbus -- shared-bus switching core
//
// The smallest topology, kept for comparison (docs/ARCHITECTURE.md sec. 2):
// one request slot and one response slot shared by every endpoint, i.e. a
// split-transaction bus with a separate address/write phase and response phase.
//  * request : ONE arbiter (sfn_arbiter, any mode) over all masters; the winner's
//              payload is broadcast, t_req_valid is raised only at its target.
//              At most one request transfer per cycle in the whole fabric.
//  * response: ONE round-robin arbiter over all targets; the winner is steered
//              to the master named by t_rsp_src.  At most one response per cycle.
// Same port list and same front ends as sfn_xbar, so every testbench, counter and
// scoreboard applies unchanged.
// =============================================================================
`default_nettype none

module sfn_sbus #(
  parameter int               NM         = 2,
  parameter int               NT         = 2,
  parameter int               AW         = 32,
  parameter int               DW         = 32,
  parameter int               IDW        = 2,
  parameter int               ARB_MODE   = 1,
  parameter int               STARVE     = 8,
  parameter logic [NM*NT-1:0] MST_TGT_EN = {(NM*NT){1'b1}},
  localparam int              SB         = DW / 8,
  localparam int              TW         = sfn_pkg::clog2c(NT + 1),
  localparam int              SRCW       = sfn_pkg::clog2c(NM),
  localparam int              QW         = sfn_pkg::QOSW,
  localparam int              PW         = TW + 3 + IDW + QW + AW + DW + SB,
  localparam int              RW         = SRCW + IDW + 3 + 2 + DW
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic [NM-1:0]      fq_valid,
  output logic      [NM-1:0]      fq_ready,
  input  wire logic [NM*TW-1:0]   fq_tgt,
  input  wire logic [NM*3-1:0]    fq_opcode,
  input  wire logic [NM*IDW-1:0]  fq_id,
  input  wire logic [NM*QW-1:0]   fq_qos,
  input  wire logic [NM*AW-1:0]   fq_addr,
  input  wire logic [NM*DW-1:0]   fq_wdata,
  input  wire logic [NM*SB-1:0]   fq_wstrb,
  output logic      [NM-1:0]      fr_valid,
  input  wire logic [NM-1:0]      fr_ready,
  output logic      [NM*TW-1:0]   fr_tgt,
  output logic      [NM*IDW-1:0]  fr_id,
  output logic      [NM*3-1:0]    fr_opcode,
  output logic      [NM*2-1:0]    fr_status,
  output logic      [NM*DW-1:0]   fr_rdata,
  output logic      [NT-1:0]      t_req_valid,
  input  wire logic [NT-1:0]      t_req_ready,
  output logic      [NT*3-1:0]    t_req_opcode,
  output logic      [NT*SRCW-1:0] t_req_src,
  output logic      [NT*IDW-1:0]  t_req_id,
  output logic      [NT*QW-1:0]   t_req_qos,
  output logic      [NT*AW-1:0]   t_req_addr,
  output logic      [NT*DW-1:0]   t_req_wdata,
  output logic      [NT*SB-1:0]   t_req_wstrb,
  input  wire logic [NT-1:0]      t_rsp_valid,
  output logic      [NT-1:0]      t_rsp_ready,
  input  wire logic [NT*SRCW-1:0] t_rsp_src,
  input  wire logic [NT*IDW-1:0]  t_rsp_id,
  input  wire logic [NT*3-1:0]    t_rsp_opcode,
  input  wire logic [NT*2-1:0]    t_rsp_status,
  input  wire logic [NT*DW-1:0]   t_rsp_rdata,
  output logic      [NM-1:0]      ev_arb_loss,
  output logic      [NT-1:0]      ev_bad_src
);
  genvar gm, gt;

  // ================================================================ request phase
  logic [NM*PW-1:0] mpay;
  logic [NM-1:0]    cand, grant;
  logic [SRCW-1:0]  gidx;
  logic             gv;
  logic [PW-1:0]    pay;
  logic [TW-1:0]    sel_t;
  logic             sel_ready;
  for (gm = 0; gm < NM; gm++) begin : g_m
    assign mpay[gm*PW +: PW] = {fq_tgt[gm*TW +: TW], fq_opcode[gm*3 +: 3], fq_id[gm*IDW +: IDW], fq_qos[gm*QW +: QW],
                                fq_addr[gm*AW +: AW], fq_wdata[gm*DW +: DW], fq_wstrb[gm*SB +: SB]};
    assign cand[gm] = fq_valid[gm];
  end
  sfn_arbiter #(.N(NM), .MODE(ARB_MODE), .STARVE(STARVE)) u_arb (
    .clk, .rst_n, .req(cand), .qos(fq_qos),
    .stall(gv && !sel_ready), .accept(gv && sel_ready),
    .grant(grant), .grant_idx(gidx), .grant_valid(gv)
  );
  sfn_onehot_mux #(.N(NM), .W(PW)) u_mux (.sel(grant), .din(mpay), .dout(pay));

  logic [2:0]     b_op;
  logic [IDW-1:0] b_id;
  logic [QW-1:0]  b_qos;
  logic [AW-1:0]  b_addr;
  logic [DW-1:0]  b_wdata;
  logic [SB-1:0]  b_wstrb;
  assign {sel_t, b_op, b_id, b_qos, b_addr, b_wdata, b_wstrb} = pay;

  always_comb begin
    sel_ready = 1'b0;
    for (int t = 0; t < NT; t++) if (sel_t == TW'(t)) sel_ready = t_req_ready[t];
  end

  for (gt = 0; gt < NT; gt++) begin : g_t
    assign t_req_valid[gt]                = gv && (sel_t == TW'(gt));
    assign t_req_opcode[gt*3 +: 3]        = b_op;
    assign t_req_src[gt*SRCW +: SRCW]     = gidx;
    assign t_req_id[gt*IDW +: IDW]        = b_id;
    assign t_req_qos[gt*QW +: QW]         = b_qos;
    assign t_req_addr[gt*AW +: AW]        = b_addr;
    assign t_req_wdata[gt*DW +: DW]       = b_wdata;
    assign t_req_wstrb[gt*SB +: SB]       = b_wstrb;
  end
  assign fq_ready    = grant & {NM{sel_ready}};
  assign ev_arb_loss = fq_valid & ~grant;

  // ================================================================ response phase
  logic [NT*RW-1:0] tpay;
  logic [NT-1:0]    rcand, rgrant;
  logic [sfn_pkg::clog2c(NT)-1:0] ridx;
  logic             rgv;
  logic [RW-1:0]    rpay;
  logic [SRCW-1:0]  r_src;
  logic [IDW-1:0]   r_id;
  logic [2:0]       r_op;
  logic [1:0]       r_st;
  logic [DW-1:0]    r_data;
  logic             dst_ready;

  for (gt = 0; gt < NT; gt++) begin : g_r
    logic src_ok;
    always_comb begin
      src_ok = 1'b0;
      for (int m = 0; m < NM; m++)
        if (MST_TGT_EN[m*NT + gt] && (t_rsp_src[gt*SRCW +: SRCW] == SRCW'(m))) src_ok = 1'b1;
    end
    assign ev_bad_src[gt] = t_rsp_valid[gt] && !src_ok;
    assign rcand[gt]      = t_rsp_valid[gt] && src_ok;
    assign tpay[gt*RW +: RW] = {t_rsp_src[gt*SRCW +: SRCW], t_rsp_id[gt*IDW +: IDW], t_rsp_opcode[gt*3 +: 3],
                                t_rsp_status[gt*2 +: 2], t_rsp_rdata[gt*DW +: DW]};
  end
  sfb_arbiter #(.N(NT), .MODE(1)) u_rarb (
    .clk, .rst_n, .req(rcand), .stall(rgv && !dst_ready), .accept(rgv && dst_ready),
    .grant(rgrant), .grant_idx(ridx), .grant_valid(rgv)
  );
  sfn_onehot_mux #(.N(NT), .W(RW)) u_rmux (.sel(rgrant), .din(tpay), .dout(rpay));
  assign {r_src, r_id, r_op, r_st, r_data} = rpay;

  always_comb begin
    dst_ready = 1'b0;
    for (int m = 0; m < NM; m++) if (r_src == SRCW'(m)) dst_ready = fr_ready[m];
  end

  for (gm = 0; gm < NM; gm++) begin : g_fr
    assign fr_valid[gm]              = rgv && (r_src == SRCW'(gm));
    assign fr_tgt[gm*TW +: TW]       = TW'(ridx);
    assign fr_id[gm*IDW +: IDW]      = r_id;
    assign fr_opcode[gm*3 +: 3]      = r_op;
    assign fr_status[gm*2 +: 2]      = r_st;
    assign fr_rdata[gm*DW +: DW]     = r_data;
  end
  assign t_rsp_ready = (rgrant & {NT{rgv && dst_ready}}) | ev_bad_src;
endmodule

`default_nettype wire
