// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_onehot_mux -- AND-OR one-hot multiplexer
// sel must be one-hot or zero (zero -> dout = 0).  Purely combinational.
// =============================================================================
`default_nettype none

module sfn_onehot_mux #(
  parameter int N = 2,
  parameter int W = 8
) (
  input  wire logic [N-1:0]   sel,
  input  wire logic [N*W-1:0] din,
  output logic      [W-1:0]   dout
);
  always_comb begin
    dout = '0;
    for (int i = 0; i < N; i++)
      dout = dout | (din[i*W +: W] & {W{sel[i]}});
  end
endmodule

`default_nettype wire
