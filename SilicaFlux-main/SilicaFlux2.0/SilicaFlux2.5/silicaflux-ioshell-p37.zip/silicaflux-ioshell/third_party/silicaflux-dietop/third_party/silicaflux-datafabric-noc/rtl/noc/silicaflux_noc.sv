// =============================================================================
// SilicaFlux DataFabric-NoC :: silicaflux_noc -- configurable on-chip fabric (top)
//
//   NM SFB3 master ports ──► sfn_mst_port (decode, per-ID tracking, FENCE,
//                            local responder, orphan containment)  ×NM
//                        ──► switching core, selected by TOPOLOGY:
//                              0 sfn_sbus  shared bus (one request + one response slot)
//                              1 sfn_xbar  crossbar   (SilicaFlux baseline, recommended)
//                              2 sfn_mesh  2-D mesh, XY wormhole routing, separate
//                                          request / response networks, credits
//                        ──► NT SFB3 target ports
//   optional sfn_perf counter page (PERF = 1) on the SilicaFlux register bus.
//
// Protocol: SFB3 (docs/PROTOCOL.md, sfn_pkg).  SFB2 endpoints attach through
// sfn_sfb2_mst_bridge / sfn_sfb2_tgt_bridge.  One clock domain, asynchronous
// reset assert / synchronous release by the SoC reset synchroniser (SilicaFlux
// convention); reset cancels every transaction in flight (PROTOCOL.md R11).
//
// Parameters are validated at elaboration (simulation): see the checks below.
// Sized fill literals only in parameter defaults (Yosys 0.33, DataFabric rule).
// =============================================================================
`default_nettype none

module silicaflux_noc #(
  parameter int               TOPOLOGY    = 1,     // sfn_pkg::TOPO_*
  parameter int               NM          = 4,
  parameter int               NT          = 4,
  parameter int               AW          = 32,
  parameter int               DW          = 32,
  parameter int               IDW         = 2,
  parameter int               ARB_MODE    = 1,     // sfn_pkg::ARB_*
  parameter int               STARVE      = 8,     // ARB_QOS aging threshold
  parameter int               CHECK_ALIGN = 1,
  parameter int               RETIRE_BYPASS = 0,   // 0 (default): registered eligibility, short paths; 1: SFB2-style
                                                   // accept-while-retiring (see sfn_mst_port, docs/ARCHITECTURE.md sec. 6)
  parameter logic [NT*AW-1:0] TGT_BASE    = {(NT*AW){1'b0}},
  parameter logic [NT*AW-1:0] TGT_MASK    = {(NT*AW){1'b0}},
  parameter logic [NM*NT-1:0] MST_TGT_EN  = {(NM*NT){1'b1}},  // bit m*NT+t
  parameter int               MAXO_MAX    = 4,                // counter sizing bound
  parameter logic [NM*8-1:0]  MST_MAXO    = {NM{8'd4}},       // per-master outstanding limit
  // ---------------------------------------------------------------- mesh only
  parameter int               MESH_X      = 2,
  parameter int               MESH_Y      = 2,
  parameter logic [NM*8-1:0]  MST_NODE    = {NM{8'd0}},       // node (y*MESH_X+x) of each master
  parameter logic [NT*8-1:0]  TGT_NODE    = {NT{8'd0}},       // node of each target
  parameter int               FIFO_DEPTH  = 4,                // router input buffer, flits
  // ---------------------------------------------------------------- counters
  parameter int               PERF        = 1,
  localparam int              SB          = DW / 8,
  localparam int              TW          = sfn_pkg::clog2c(NT + 1),
  localparam int              SRCW        = sfn_pkg::clog2c(NM),
  localparam int              QW          = sfn_pkg::QOSW,
  localparam int              CW          = sfn_pkg::clog2c(MAXO_MAX + 1)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ---------------------------------------------------------------- SFB3 master ports
  input  wire logic [NM-1:0]      m_req_valid,
  output logic      [NM-1:0]      m_req_ready,
  input  wire logic [NM*3-1:0]    m_req_opcode,
  input  wire logic [NM*IDW-1:0]  m_req_id,
  input  wire logic [NM*QW-1:0]   m_req_qos,
  input  wire logic [NM*AW-1:0]   m_req_addr,
  input  wire logic [NM*DW-1:0]   m_req_wdata,
  input  wire logic [NM*SB-1:0]   m_req_wstrb,
  output logic      [NM-1:0]      m_rsp_valid,
  input  wire logic [NM-1:0]      m_rsp_ready,
  output logic      [NM*IDW-1:0]  m_rsp_id,
  output logic      [NM*3-1:0]    m_rsp_opcode,
  output logic      [NM*2-1:0]    m_rsp_status,
  output logic      [NM*DW-1:0]   m_rsp_rdata,
  // ---------------------------------------------------------------- SFB3 target ports
  output logic      [NT-1:0]      t_req_valid,
  input  wire logic [NT-1:0]      t_req_ready,
  output logic      [NT*3-1:0]    t_req_opcode,
  output logic      [NT*SRCW-1:0] t_req_src,
  output logic      [NT*IDW-1:0]  t_req_id,
  output logic      [NT*QW-1:0]   t_req_qos,
  output logic      [NT*AW-1:0]   t_req_addr,
  output logic      [NT*DW-1:0]   t_req_wdata,
  output logic      [NT*SB-1:0]   t_req_wstrb,
  input  wire logic [NT-1:0]      t_rsp_valid,
  output logic      [NT-1:0]      t_rsp_ready,
  input  wire logic [NT*SRCW-1:0] t_rsp_src,
  input  wire logic [NT*IDW-1:0]  t_rsp_id,
  input  wire logic [NT*3-1:0]    t_rsp_opcode,
  input  wire logic [NT*2-1:0]    t_rsp_status,
  input  wire logic [NT*DW-1:0]   t_rsp_rdata,
  // ---------------------------------------------------------------- counter page / error interrupt
  input  wire logic               rb_sel,
  input  wire logic               rb_we,
  input  wire logic [11:0]        rb_addr,
  input  wire logic [31:0]        rb_wdata,
  output logic      [31:0]        rb_rdata,
  output logic                    rb_err,
  output logic                    irq_err,
  // ---------------------------------------------------------------- observation (verification / tracing)
  output logic      [NM-1:0]      obs_sw_valid,    // request presented to the switching core
  output logic      [NM-1:0]      obs_sw_ready,    // ... and accepted by it
  output logic      [NM*CW-1:0]   obs_out_cnt,     // outstanding per master
  output logic      [NM-1:0]      obs_decerr,
  output logic      [NM-1:0]      obs_posted_err,
  output logic      [NM-1:0]      obs_orphan,
  output logic      [NT-1:0]      obs_bad_src
);
  genvar gm;

  // ================================================================ master front ends
  logic [NM-1:0]     fq_valid, fq_ready, fr_valid, fr_ready;
  logic [NM*TW-1:0]  fq_tgt, fr_tgt;
  logic [NM*3-1:0]   fq_opcode, fr_opcode;
  logic [NM*IDW-1:0] fq_id, fr_id;
  logic [NM*QW-1:0]  fq_qos;
  logic [NM*AW-1:0]  fq_addr;
  logic [NM*DW-1:0]  fq_wdata, fr_rdata;
  logic [NM*SB-1:0]  fq_wstrb;
  logic [NM*2-1:0]   fr_status;
  /* verilator lint_off UNUSEDSIGNAL */   // events are consumed by the optional counter block only
  logic [NM-1:0]     ev_blk_out, ev_blk_id, ev_blk_fence, ev_decerr, ev_posted_done, ev_posted_err, ev_orphan, id_idle;
  /* verilator lint_on UNUSEDSIGNAL */

  for (gm = 0; gm < NM; gm++) begin : g_mp
    sfn_mst_port #(
      .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .MAXO_MAX(MAXO_MAX), .MAXO(32'(MST_MAXO[gm*8 +: 8])),
      .CHECK_ALIGN(CHECK_ALIGN), .RETIRE_BYPASS(RETIRE_BYPASS), .TGT_BASE(TGT_BASE), .TGT_MASK(TGT_MASK),
      .EN(MST_TGT_EN[gm*NT +: NT])
    ) u_mp (
      .clk, .rst_n,
      .m_req_valid(m_req_valid[gm]), .m_req_ready(m_req_ready[gm]), .m_req_opcode(m_req_opcode[gm*3 +: 3]),
      .m_req_id(m_req_id[gm*IDW +: IDW]), .m_req_qos(m_req_qos[gm*QW +: QW]), .m_req_addr(m_req_addr[gm*AW +: AW]),
      .m_req_wdata(m_req_wdata[gm*DW +: DW]), .m_req_wstrb(m_req_wstrb[gm*SB +: SB]),
      .m_rsp_valid(m_rsp_valid[gm]), .m_rsp_ready(m_rsp_ready[gm]), .m_rsp_id(m_rsp_id[gm*IDW +: IDW]),
      .m_rsp_opcode(m_rsp_opcode[gm*3 +: 3]), .m_rsp_status(m_rsp_status[gm*2 +: 2]),
      .m_rsp_rdata(m_rsp_rdata[gm*DW +: DW]),
      .fq_valid(fq_valid[gm]), .fq_ready(fq_ready[gm]), .fq_tgt(fq_tgt[gm*TW +: TW]),
      .fq_opcode(fq_opcode[gm*3 +: 3]), .fq_id(fq_id[gm*IDW +: IDW]), .fq_qos(fq_qos[gm*QW +: QW]),
      .fq_addr(fq_addr[gm*AW +: AW]), .fq_wdata(fq_wdata[gm*DW +: DW]), .fq_wstrb(fq_wstrb[gm*SB +: SB]),
      .fr_valid(fr_valid[gm]), .fr_ready(fr_ready[gm]), .fr_tgt(fr_tgt[gm*TW +: TW]), .fr_id(fr_id[gm*IDW +: IDW]),
      .fr_opcode(fr_opcode[gm*3 +: 3]), .fr_status(fr_status[gm*2 +: 2]), .fr_rdata(fr_rdata[gm*DW +: DW]),
      .out_cnt(obs_out_cnt[gm*CW +: CW]), .id_idle(id_idle[gm]),
      .ev_blk_out(ev_blk_out[gm]), .ev_blk_id(ev_blk_id[gm]), .ev_blk_fence(ev_blk_fence[gm]),
      .ev_decerr(ev_decerr[gm]), .ev_posted_done(ev_posted_done[gm]), .ev_posted_err(ev_posted_err[gm]),
      .ev_orphan(ev_orphan[gm])
    );
  end

  // ================================================================ switching core
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NM-1:0] ev_arb_loss;           // per-master switch losses (trace / future counter)
  /* verilator lint_on UNUSEDSIGNAL */
  logic [NT-1:0] ev_bad_src;

  if (TOPOLOGY == sfn_pkg::TOPO_SHARED_BUS) begin : g_sbus
    sfn_sbus #(
      .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(ARB_MODE), .STARVE(STARVE), .MST_TGT_EN(MST_TGT_EN)
    ) u_core (
      .clk, .rst_n,
      .fq_valid, .fq_ready, .fq_tgt, .fq_opcode, .fq_id, .fq_qos, .fq_addr, .fq_wdata, .fq_wstrb,
      .fr_valid, .fr_ready, .fr_tgt, .fr_id, .fr_opcode, .fr_status, .fr_rdata,
      .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_src, .t_req_id, .t_req_qos, .t_req_addr, .t_req_wdata,
      .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata,
      .ev_arb_loss, .ev_bad_src
    );
  end else if (TOPOLOGY == sfn_pkg::TOPO_CROSSBAR) begin : g_xbar
    sfn_xbar #(
      .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(ARB_MODE), .STARVE(STARVE), .MST_TGT_EN(MST_TGT_EN)
    ) u_core (
      .clk, .rst_n,
      .fq_valid, .fq_ready, .fq_tgt, .fq_opcode, .fq_id, .fq_qos, .fq_addr, .fq_wdata, .fq_wstrb,
      .fr_valid, .fr_ready, .fr_tgt, .fr_id, .fr_opcode, .fr_status, .fr_rdata,
      .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_src, .t_req_id, .t_req_qos, .t_req_addr, .t_req_wdata,
      .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata,
      .ev_arb_loss, .ev_bad_src
    );
  end else begin : g_mesh
    sfn_mesh #(
      .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .ARB_MODE(ARB_MODE), .STARVE(STARVE),
      .MESH_X(MESH_X), .MESH_Y(MESH_Y), .MST_NODE(MST_NODE), .TGT_NODE(TGT_NODE), .FIFO_DEPTH(FIFO_DEPTH)
    ) u_core (
      .clk, .rst_n,
      .fq_valid, .fq_ready, .fq_tgt, .fq_opcode, .fq_id, .fq_qos, .fq_addr, .fq_wdata, .fq_wstrb,
      .fr_valid, .fr_ready, .fr_tgt, .fr_id, .fr_opcode, .fr_status, .fr_rdata,
      .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_src, .t_req_id, .t_req_qos, .t_req_addr, .t_req_wdata,
      .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_id, .t_rsp_opcode, .t_rsp_status, .t_rsp_rdata,
      .ev_arb_loss, .ev_bad_src
    );
  end

  // ================================================================ observation
  assign obs_sw_valid   = fq_valid;
  assign obs_sw_ready   = fq_ready;
  assign obs_decerr     = ev_decerr;
  assign obs_posted_err = ev_posted_err;
  assign obs_orphan     = ev_orphan;
  assign obs_bad_src    = ev_bad_src;

  // ================================================================ counters
  if (PERF != 0) begin : g_perf
    sfn_perf #(
      .NM(NM), .NT(NT), .AW(AW), .DW(DW), .IDW(IDW), .MAXO_MAX(MAXO_MAX), .TOPOLOGY(TOPOLOGY)
    ) u_perf (
      .clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
      .m_req_valid, .m_req_ready, .m_req_opcode, .m_req_id, .m_req_addr, .m_req_wstrb, .m_id_idle(id_idle),
      .m_rsp_valid, .m_rsp_ready, .m_rsp_id, .m_rsp_opcode, .m_rsp_status,
      .m_fq_stall(fq_valid & ~fq_ready), .m_blk(ev_blk_out | ev_blk_id | ev_blk_fence), .m_out_cnt(obs_out_cnt),
      .m_decerr(ev_decerr), .m_posted_err(ev_posted_err), .m_orphan(ev_orphan),
      .t_req_valid, .t_req_ready, .t_req_opcode, .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_bad_src(ev_bad_src),
      .irq_err
    );
  end else begin : g_noperf
    assign rb_rdata = 32'd0;
    assign rb_err   = rb_sel;
    assign irq_err  = 1'b0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_perf = &{1'b0, rb_we, rb_addr, rb_wdata, id_idle, ev_posted_done, ev_arb_loss};
    /* verilator lint_on UNUSEDSIGNAL */
  end

`ifndef SYNTHESIS
  // ================================================================ elaboration checks
  initial begin
    if (TOPOLOGY < 0 || TOPOLOGY > 2) $fatal(1, "silicaflux_noc: TOPOLOGY=%0d not in 0..2", TOPOLOGY);
    if (NM < 1 || NT < 1)             $fatal(1, "silicaflux_noc: NM and NT must be >= 1");
    if (AW < 8 || AW > 64)            $fatal(1, "silicaflux_noc: AW=%0d outside 8..64", AW);
    if (DW != 32 && DW != 64 && DW != 128 && DW != 256)
                                      $fatal(1, "silicaflux_noc: DW=%0d not in {32,64,128,256}", DW);
    if (ARB_MODE < 0 || ARB_MODE > 2) $fatal(1, "silicaflux_noc: ARB_MODE=%0d not in 0..2", ARB_MODE);
    if (STARVE < 0 || STARVE > 255)   $fatal(1, "silicaflux_noc: STARVE=%0d outside 0..255", STARVE);
    for (int m = 0; m < NM; m++)
      if (32'(MST_MAXO[m*8 +: 8]) < 1 || 32'(MST_MAXO[m*8 +: 8]) > MAXO_MAX)
        $fatal(1, "silicaflux_noc: MST_MAXO[%0d]=%0d outside 1..MAXO_MAX=%0d", m, MST_MAXO[m*8 +: 8], MAXO_MAX);
    // overlapping target windows would alias (the lowest index would win): refuse
    for (int a = 0; a < NT; a++)
      for (int b = a + 1; b < NT; b++)
        if ((((TGT_BASE[a*AW +: AW] ^ TGT_BASE[b*AW +: AW]) & TGT_MASK[a*AW +: AW] & TGT_MASK[b*AW +: AW]) == '0))
          $fatal(1, "silicaflux_noc: target windows %0d and %0d overlap", a, b);
    for (int t = 0; t < NT; t++)
      if ((TGT_BASE[t*AW +: AW] & ~TGT_MASK[t*AW +: AW]) != '0)
        $fatal(1, "silicaflux_noc: TGT_BASE[%0d] has bits outside its mask", t);
  end
`endif
endmodule

`default_nettype wire
