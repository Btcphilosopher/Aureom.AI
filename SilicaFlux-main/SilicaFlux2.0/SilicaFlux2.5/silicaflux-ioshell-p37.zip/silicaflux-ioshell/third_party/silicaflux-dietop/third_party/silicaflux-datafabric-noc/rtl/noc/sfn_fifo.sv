// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_fifo -- synchronous valid/ready FIFO
//
// DEPTH >= 1 entries (any value, not only powers of two), W-bit entries.
//   in_ready  = not full   (never overflows: a push needs in_ready)
//               PASS_FULL = 1: also when full and the head leaves in the same
//               cycle (combinational out_ready -> in_ready path; a full FIFO of
//               depth 1 then sustains one transfer per cycle).  in_ready can only
//               rise until the push, so a request held on in_valid stays legal.
//   out_valid = not empty  (never underflows: a pop needs out_valid)
// out_data is the registered head entry, stable while out_valid && !out_ready.
// Proved (unbounded, formal/fv_sfn_fifo.sv): count == pushes - pops, no
// overflow/underflow, data leave in order and unchanged.
// =============================================================================
`default_nettype none

module sfn_fifo #(
  parameter int  W         = 8,
  parameter int  DEPTH     = 4,
  parameter int  PASS_FULL = 0,
  localparam int PW    = sfn_pkg::clog2c(DEPTH),
  localparam int CNTW  = sfn_pkg::clog2c(DEPTH + 1)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            in_valid,
  output logic                 in_ready,
  input  wire logic [W-1:0]    in_data,
  output logic                 out_valid,
  input  wire logic            out_ready,
  output logic      [W-1:0]    out_data,
  output logic      [CNTW-1:0] count
);
  logic [W-1:0]    mem [DEPTH];
  logic [PW-1:0]   rd_q, wr_q;
  logic [CNTW-1:0] cnt_q;

  wire push = in_valid && in_ready;
  wire pop  = out_valid && out_ready;

  assign in_ready  = (cnt_q != CNTW'(DEPTH)) || ((PASS_FULL != 0) && out_ready);
  assign out_valid = (cnt_q != '0);
  assign out_data  = mem[rd_q];
  assign count     = cnt_q;

  function automatic logic [PW-1:0] inc(input logic [PW-1:0] p);
    begin
      if (p == PW'(DEPTH - 1)) inc = '0;
      else                     inc = p + PW'(1);
    end
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd_q  <= '0;
      wr_q  <= '0;
      cnt_q <= '0;
    end else begin
      if (push) wr_q <= inc(wr_q);
      if (pop)  rd_q <= inc(rd_q);
      cnt_q <= cnt_q + CNTW'(push) - CNTW'(pop);
    end
  end

  // storage is not reset (datapath); only written on a push
  always_ff @(posedge clk) begin
    if (push) mem[wr_q] <= in_data;
  end
endmodule

`default_nettype wire
