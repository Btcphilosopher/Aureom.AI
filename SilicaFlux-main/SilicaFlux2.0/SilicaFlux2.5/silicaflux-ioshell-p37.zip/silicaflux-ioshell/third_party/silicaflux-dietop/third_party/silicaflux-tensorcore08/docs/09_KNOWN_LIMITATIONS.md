# 09 — Known limitations and next actions

## 1. Evidence limits

* **RTL simulation only** (Verilator 5.020, Icarus 12), self-checking against an independent Python reference and,
  for the host example, a C reference. No formal proof of the new RTL, no gate-level simulation, no FPGA bitstream
  loaded on a board, no silicon.
* **FPGA numbers are tool estimates**: Yosys mapping and nextpnr-ecp5's post-route static timing of a non-functional
  harness (LFSR inputs, folded outputs) on LFE5U-85F. No board run; timing closure at a target clock is not claimed.
* **The full configuration misses 25 MHz on ECP5** (post-route estimate 23.93 MHz at seed 1; the baseline reaches
  28.85 MHz). The critical path is inside TC05's rounding stage (doc 10); no seed sweep or retiming was attempted.
* **The ASIC run is a smoke test**: logic synthesis onto SKY130 HD cells (TT corner) with the buffers as flip-flops,
  no SRAM macros, floorplan, placement, clock tree, wires, IR drop or power analysis. Its area and ABC delay are not
  silicon results, and nothing here is tapeout-ready.
* **Cycle counts are against modelled memories** (1-, 2-, 8-cycle and crossbar models). A real SoC's numbers depend
  on its SRAM and fabric.
* **No PCIe or OS driver.** The host driver is bare-metal C; it ran only on the simulation backend.

## 2. Functional scope

| Limitation | Consequence | Next action |
|---|---|---|
| INT8 × INT8 → INT32, dense, row-major only | other types / layouts are rejected (PRECISION / LAYOUT), never converted or transposed | a transposed-operand mode needs a column gather in the descriptor generator (2-D descriptors with ROW_LEN = 1) |
| Requantisation is per tensor (one M / S / zp), no bias | TC05's per-channel table, bias and asymmetric-activation modes are not reachable from the ABI | add a parameter-load command (TC05 `p_*` port) and per-channel flags; the OPEN descriptor already carries CH_GRP |
| One command at a time | command n+1 starts after command n's record; no overlap of the next command's loads with the previous drain | overlap VALIDATE / first LOADs of n+1 with the STORE drain of n when footprints do not alias |
| Compute sequencer = TC07 `tdma_compute_seq` | one job at a time, no operand reuse across tiles (TC06's REUSE) — every step loads its A and B blocks | port TC06's reuse decisions into the descriptor iterator (skip a LOAD when the block is resident) |
| `ldb_loc`, `lda_loc` layout fixed (TC07's bank-friendly rule) | no software control of the local layout | — |
| Accumulator slots = 2 (TC04 `NUM_TILES`), M- or N-major order only | no K-major / blocked-K schedule | TC04 with more slots |
| `NUM_SLOTS` must stay 2 | `tdma_compute_seq` advances its slot with `slot + 1` modulo 2^SLOT_W, correct only for powers of two; the scheduler predicts the slot for TC05 the same way (checked by an assertion) | — |
| Array shapes verified: 2×2, 4×4, 8×8 | other shapes elaborate only with `ALLOW_UNVERIFIED = 1` | run stage 3 for the shape before enabling it |
| 32-bit SFB2 port | `MEM_BACKEND`, buffers and the DMA are word-wide; TC07 supports 64-bit, not wired here | expose `WB` |
| ALIAS check uses bounding intervals | interleaved but disjoint footprints (C rows inside A's padding) are rejected | exact row-interval test |
| Abort granularity | ABORT stops at the next descriptor / job boundary inside the hardware; C of the aborted command is partially written | — (documented: C is don't-care after ABORTED) |
| Commands written while `STATUS.ABORTING = 1` | may be flushed with the queue | wait for ABORTING = 0 (the driver and the testbench do) |
| HALT after an undrainable port | only a hard reset recovers (the fabric still owes a response) | — |

## 3. Performance limits (measured, `reports/perf.md`)

* **The single 32-bit SFB2 port bounds utilisation.** A 4×4 step with K = 64 moves ~128 operand words (A: 4 × 64 B,
  B: 64 × 4 B) for 1 024 MACs, at most one word per cycle: about 50 % utilisation even with perfect overlap. Measured:
  25.8 % sequential, 40.9 % with PREFETCH (32×32×256, 1-cycle memory).
* **Behind the DataFabric crossbar** one transaction per port (R6) limits the port to one word per slave round trip.
* **Memory latency** reduces the prefetch gain (TC07: 1.59× at 1 cycle, 1.24× at 8 cycles).
* Per-command overhead ~22 cycles (validation + record); per-launch fixed costs of TC02 (fill / drain) and TC03 (tile
  set-up) make short K chunks inefficient.

## 4. Implementation notes

* The validator's four products and the chunk division run in a shared 18-cycle shift-add loop — no multiplier on
  the command path; the descriptor iterator uses incremental pointers (adds only). The remaining multipliers are
  TC02's PEs, TC05's lanes, TC07's validation and TC03's tile AGU (reused, not changed), plus the MAC-count event
  (3-bit × 3-bit × 17-bit).
* `perf_ev` is 640 bits wide; an integration that does not use it should leave it unconnected (synthesis removes the
  unused increments of the counter bank only if `PERF_EN = 0`).
* Testbench note: Verilator 5.020 evaluates an impure function call in the unselected arm of `?:` (found while
  aligning the Verilator and Icarus random streams); the testbench avoids the construct.
