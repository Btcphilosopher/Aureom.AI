// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_sfb2_tgt_bridge -- SFB3 target port -> SFB2 slave
//
// Lets every existing SFB2 slave (SRAM Wrapper Library adapters, the HPC tile
// scratchpad window, SilicaFlux-V slaves behind sfb_v1_slave_adapter) sit on the
// NoC unmodified.  SFB2 slaves answer in acceptance order (SFB2 R5), so a FIFO
// of {src, id, opcode} per accepted request (DEPTH entries) restores the SFB3
// response tags.  DEPTH is this target's outstanding limit: the bridge refuses
// requests when DEPTH are in flight (explicit limit, docs/PROTOCOL.md O4) -- set
// DEPTH to what the SFB2 slave supports (1 for slaves designed for the SFB2
// crossbar's one-transaction-per-port rule R6).  t_req_ready depends
// combinationally on t_rsp_ready (allowed: SFB3 R4, accept-while-retiring).
//   READ          -> SFB2 read;  response data, SLVERR on rsp_error
//   WRITE         -> SFB2 write; acknowledged after the slave's response (R7)
//   WRITE_POSTED  -> SFB2 write; its SFB2 response becomes the posted completion
//                    that the fabric retires (never shown to the master)
// =============================================================================
`default_nettype none

module sfn_sfb2_tgt_bridge #(
  parameter int  NM    = 2,
  parameter int  AW    = 32,
  parameter int  DW    = 32,
  parameter int  IDW   = 2,
  parameter int  DEPTH = 4,
  localparam int SB    = DW / 8,
  localparam int SRCW  = sfn_pkg::clog2c(NM),
  localparam int QW    = sfn_pkg::QOSW,
  localparam int FW    = SRCW + IDW + 3
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // ---------------------------------------------------------------- SFB3 target port (from the fabric)
  input  wire logic            t_req_valid,
  output logic                 t_req_ready,
  input  wire logic [2:0]      t_req_opcode,
  input  wire logic [SRCW-1:0] t_req_src,
  input  wire logic [IDW-1:0]  t_req_id,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [QW-1:0]   t_req_qos,
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [AW-1:0]   t_req_addr,
  input  wire logic [DW-1:0]   t_req_wdata,
  input  wire logic [SB-1:0]   t_req_wstrb,
  output logic                 t_rsp_valid,
  input  wire logic            t_rsp_ready,
  output logic [SRCW-1:0]      t_rsp_src,
  output logic [IDW-1:0]       t_rsp_id,
  output logic [2:0]           t_rsp_opcode,
  output logic [1:0]           t_rsp_status,
  output logic [DW-1:0]        t_rsp_rdata,
  // ---------------------------------------------------------------- SFB2 slave
  output logic                 s_req_valid,
  input  wire logic            s_req_ready,
  output logic                 s_req_write,
  output logic [AW-1:0]        s_req_addr,
  output logic [DW-1:0]        s_req_wdata,
  output logic [SB-1:0]        s_req_wstrb,
  input  wire logic            s_rsp_valid,
  output logic                 s_rsp_ready,
  input  wire logic [DW-1:0]   s_rsp_rdata,
  input  wire logic            s_rsp_error
);
  logic          f_in_ready, f_out_valid;
  logic [FW-1:0] f_out;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [sfn_pkg::clog2c(DEPTH + 1)-1:0] f_cnt_unused;
  logic          f_out_valid_unused;
  /* verilator lint_on UNUSEDSIGNAL */

  assign s_req_valid = t_req_valid && f_in_ready;
  assign t_req_ready = s_req_ready && f_in_ready;
  assign s_req_write = sfn_pkg::op_is_write(t_req_opcode);
  assign s_req_addr  = t_req_addr;
  assign s_req_wdata = t_req_wdata;
  assign s_req_wstrb = t_req_wstrb;

  // PASS_FULL: a new request may enter in the cycle the oldest response retires,
  // so DEPTH = 1 (legacy single-outstanding slaves) still sustains back-to-back transfers
  sfn_fifo #(.W(FW), .DEPTH(DEPTH), .PASS_FULL(1)) u_tags (
    .clk, .rst_n,
    .in_valid(s_req_valid && s_req_ready), .in_ready(f_in_ready), .in_data({t_req_src, t_req_id, t_req_opcode}),
    .out_valid(f_out_valid), .out_ready(s_rsp_valid && s_rsp_ready), .out_data(f_out), .count(f_cnt_unused)
  );
  assign f_out_valid_unused = f_out_valid;

  assign t_rsp_valid  = s_rsp_valid;
  assign s_rsp_ready  = t_rsp_ready;
  assign {t_rsp_src, t_rsp_id, t_rsp_opcode} = f_out;
  assign t_rsp_status = s_rsp_error ? sfn_pkg::ST_SLVERR : sfn_pkg::ST_OKAY;
  assign t_rsp_rdata  = (f_out[2:0] == sfn_pkg::OP_READ && !s_rsp_error) ? s_rsp_rdata : '0;

`ifndef SYNTHESIS
  // an SFB2 slave never responds without an outstanding request (SFB2 R5)
  always @(posedge clk) if (rst_n && s_rsp_valid && !f_out_valid)
    $error("sfn_sfb2_tgt_bridge: SFB2 response without an outstanding request");
`endif
endmodule

`default_nettype wire
