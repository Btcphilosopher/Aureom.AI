// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_router -- 5-port wormhole router, XY routing
//
// Ports: 0 L (local network interface), 1 N (y-1), 2 E (x+1), 3 S (y+1), 4 W (x-1).
// Flit  : {head, tail, payload[FW-1:0]}.  A packet is a head flit followed by
//         body/tail flits; a single-flit packet has head = tail = 1.  The
//         destination {y, x} is payload[DST_LSB +: YW+XW] of the head flit.
// Buffers: one input FIFO of DEPTH flits per port (sfn_fifo).
// Flow control: credit based, per link.  Each output keeps a credit counter
//         initialised to DEPTH (the downstream input FIFO depth); a flit is sent
//         only with a credit; the downstream router (or network interface)
//         returns one credit (in_credit pulse) per flit it pops.  Invariant:
//         credits + downstream FIFO occupancy = DEPTH -> no buffer overflow.
// Routing: dimension order, X first then Y (deterministic, minimal).  A
//         packet never turns from the Y into the X dimension and never leaves
//         the mesh (assertion), so the channel-dependency graph is acyclic.
// Switching: wormhole.  An output is allocated to one input from the head flit
//         to the tail flit (packet atomicity on every link); allocation by
//         sfn_arbiter among head flits (round robin, or QoS taken from the head
//         flit at QOS_LSB when ARB_MODE = ARB_QOS), only when a credit exists.
// Latency: 1 cycle per hop (FIFO write); one flit per input and per output
//         per cycle.
// =============================================================================
`default_nettype none

module sfn_router #(
  parameter int X        = 0,
  parameter int Y        = 0,
  parameter int XW       = 1,
  parameter int YW       = 1,
  parameter int FW       = 32,
  parameter int DST_LSB  = 0,
  parameter int QOS_LSB  = 0,
  parameter int ARB_MODE = 1,
  parameter int STARVE   = 8,
  parameter int DEPTH    = 4,
  parameter logic [4:0] PORT_EN = 5'b11111,   // ports that exist (edges of the mesh have none)
  localparam int FLW     = FW + 2,
  localparam int CRW     = sfn_pkg::clog2c(DEPTH + 1)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic [4:0]       in_valid,
  input  wire logic [5*FLW-1:0] in_flit,
  output logic      [4:0]       in_credit,      // one pulse per flit popped from an input FIFO
  output logic      [4:0]       out_valid,
  output logic      [5*FLW-1:0] out_flit,
  input  wire logic [4:0]       out_credit,     // one pulse per flit the downstream popped
  // observation (verification / counters)
  output logic      [5*CRW-1:0] obs_credits,
  output logic      [5*CRW-1:0] obs_occupancy,
  output logic                  obs_turn_err    // a Y->X turn or an off-mesh route was requested
);
  localparam int NW = YW + XW;
  genvar gi, go;

  // ================================================================ input FIFOs
  logic [4:0]     h_valid, pop;
  logic [FLW-1:0] h_flit [5];
  for (gi = 0; gi < 5; gi++) begin : g_in
    logic [FLW-1:0] f_out;
    logic           f_in_ready_unused;
    sfn_fifo #(.W(FLW), .DEPTH(DEPTH)) u_fifo (
      .clk, .rst_n,
      .in_valid(in_valid[gi] && PORT_EN[gi]), .in_ready(f_in_ready_unused), .in_data(in_flit[gi*FLW +: FLW]),
      .out_valid(h_valid[gi]), .out_ready(pop[gi]), .out_data(f_out), .count(obs_occupancy[gi*CRW +: CRW])
    );
    assign h_flit[gi]    = f_out;
    assign in_credit[gi] = pop[gi];
  end

  // ================================================================ route computation (XY)
  logic [2:0] rt [5];             // requested output port of each input's head flit
  logic [4:0] in_pkt_q;           // input is inside a packet (head sent, tail not yet)
  logic [2:0] route_q [5];
  logic [4:0] bad_turn;
  logic [XW-1:0] dx [5];
  logic [YW-1:0] dy [5];
  for (gi = 0; gi < 5; gi++) begin : g_dst
    assign {dy[gi], dx[gi]} = h_flit[gi][DST_LSB +: NW];
  end
  /* verilator lint_off CMPCONST */
  /* verilator lint_off UNSIGNED */
  always_comb begin
    for (int i = 0; i < 5; i++) begin
      if (in_pkt_q[i])             rt[i] = route_q[i];
      else if (32'(dx[i]) > X)     rt[i] = 3'(sfn_pkg::PORT_E);
      else if (32'(dx[i]) < X)     rt[i] = 3'(sfn_pkg::PORT_W);
      else if (32'(dy[i]) > Y)     rt[i] = 3'(sfn_pkg::PORT_S);
      else if (32'(dy[i]) < Y)     rt[i] = 3'(sfn_pkg::PORT_N);
      else                         rt[i] = 3'(sfn_pkg::PORT_L);
      // XY restriction: a flit that arrived on N or S travels in Y and may not turn into X
      bad_turn[i] = h_valid[i] && !in_pkt_q[i] && h_flit[i][FLW-1] &&
                    (((i == sfn_pkg::PORT_N || i == sfn_pkg::PORT_S) && (rt[i] == 3'(sfn_pkg::PORT_E) || rt[i] == 3'(sfn_pkg::PORT_W)))
                     || !PORT_EN[rt[i]]);
    end
  end
  /* verilator lint_on UNSIGNED */
  /* verilator lint_on CMPCONST */
  assign obs_turn_err = |bad_turn;

  // ================================================================ output allocation (wormhole)
  logic [CRW-1:0] cr_q [5];
  logic [4:0]     busy_q;         // output allocated to a packet
  logic [2:0]     own_q [5];      // owning input
  logic [4:0]     send;
  logic [2:0]     src [5];        // input sending on each output this cycle
  logic [4:0]     new_alloc;      // a head flit of a multi-flit packet was granted
  /* verilator lint_off UNUSEDSIGNAL */
  logic [24:0]    gnt;            // bit o*5+i (one-hot grants; the index is used)
  /* verilator lint_on UNUSEDSIGNAL */

  for (go = 0; go < 5; go++) begin : g_out
    logic [4:0]  cand;
    logic [14:0] cqos;
    logic [2:0]  gidx;
    logic        gv;
    for (gi = 0; gi < 5; gi++) begin : g_c
      assign cand[gi] = PORT_EN[go] && h_valid[gi] && h_flit[gi][FLW-1] && !in_pkt_q[gi] &&
                        (rt[gi] == 3'(go)) && (cr_q[go] != '0) && !busy_q[go];
      assign cqos[gi*3 +: 3] = (ARB_MODE == sfn_pkg::ARB_QOS) ? h_flit[gi][QOS_LSB +: 3] : 3'd0;
    end
    sfn_arbiter #(.N(5), .MODE(ARB_MODE), .STARVE(STARVE)) u_arb (
      .clk, .rst_n, .req(cand), .qos(cqos), .stall(1'b0), .accept(gv),
      .grant(gnt[go*5 +: 5]), .grant_idx(gidx), .grant_valid(gv)
    );
    always_comb begin
      if (busy_q[go]) begin
        src[go]  = own_q[go];
        send[go] = h_valid[own_q[go]] && (cr_q[go] != '0);
      end else begin
        src[go]  = gidx;
        send[go] = gv;
      end
      new_alloc[go] = !busy_q[go] && gv && !h_flit[gidx][FLW-2];
    end
    assign out_valid[go]             = send[go];
    assign out_flit[go*FLW +: FLW]   = h_flit[src[go]];
  end

  always_comb begin
    pop = '0;
    for (int o = 0; o < 5; o++) if (send[o]) pop[src[o]] = 1'b1;
  end

  // ================================================================ state
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      busy_q   <= '0;
      in_pkt_q <= '0;
      for (int k = 0; k < 5; k++) begin
        cr_q[k]    <= CRW'(DEPTH);
        own_q[k]   <= '0;
        route_q[k] <= '0;
      end
    end else begin
      for (int o = 0; o < 5; o++) begin
        cr_q[o] <= cr_q[o] - CRW'(send[o]) + CRW'(out_credit[o] && PORT_EN[o]);
        if (new_alloc[o]) begin
          busy_q[o]          <= 1'b1;
          own_q[o]           <= src[o];
          in_pkt_q[src[o]]   <= 1'b1;
          route_q[src[o]]    <= 3'(o);
        end else if (busy_q[o] && send[o] && h_flit[src[o]][FLW-2]) begin   // tail leaves: release
          busy_q[o]          <= 1'b0;
          in_pkt_q[src[o]]   <= 1'b0;
        end
      end
    end
  end

  for (go = 0; go < 5; go++) begin : g_obs
    assign obs_credits[go*CRW +: CRW] = cr_q[go];
  end

`ifndef SYNTHESIS
  // credit invariant violations and illegal routes are design errors (simulation-only checks)
  /* verilator lint_off SYNCASYNCNET */
  always @(posedge clk) if (rst_n && obs_turn_err)
    $error("sfn_router(%0d,%0d): illegal route (Y->X turn or off-mesh)", X, Y);
  for (gi = 0; gi < 5; gi++) begin : g_ovf
    always @(posedge clk) if (rst_n && in_valid[gi] && PORT_EN[gi] && !g_in[gi].f_in_ready_unused)
      $error("sfn_router(%0d,%0d): flit arrived at a full input FIFO %0d (credit protocol broken)", X, Y, gi);
  end
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
