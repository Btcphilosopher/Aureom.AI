// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_mesh -- 2-D mesh switching core (scale-out option)
//
// MESH_X x MESH_Y nodes, node n = y*MESH_X + x.  Each node hosts at most one
// master (MST_NODE) and at most one target (TGT_NODE).  TWO physically separate
// networks of sfn_router (deadlock analysis: docs/DEADLOCK.md):
//   request network : master NI (sfn_ni_tx) -> routers -> target NI (sfn_ni_rx)
//   response network: target NI (sfn_ni_tx) -> routers -> master NI (sfn_ni_rx)
// so a response can never wait behind a request (no protocol deadlock), and
// XY routing inside each network has an acyclic channel-dependency graph (no
// routing deadlock).
//
// Packets (flit = {head, tail, payload[FW-1:0]}, field widths from the fabric
// parameters, nothing truncated):
//   request : head {dst{y,x}, src, id, opcode, qos, wstrb, addr}; writes add one data flit {wdata}
//   response: head {dst{y,x}, tgt, id, opcode, status};           reads add one data flit {rdata}
// Same front ends and target ports as the crossbar: ordering per (master, ID)
// holds because a (master, target) pair always uses the same XY path through
// FIFO links (in-order), and sfn_mst_port keeps an ID at one target (O2).
// A target response naming an illegal source is consumed at the target NI
// and flagged (ev_bad_src).
// =============================================================================
`default_nettype none

module sfn_mesh #(
  parameter int              NM         = 2,
  parameter int              NT         = 2,
  parameter int              AW         = 32,
  parameter int              DW         = 32,
  parameter int              IDW        = 2,
  parameter int              ARB_MODE   = 1,
  parameter int              STARVE     = 8,
  parameter int              MESH_X     = 2,
  parameter int              MESH_Y     = 2,
  parameter logic [NM*8-1:0] MST_NODE   = {NM{8'd0}},
  parameter logic [NT*8-1:0] TGT_NODE   = {NT{8'd0}},
  parameter int              FIFO_DEPTH = 4,
  localparam int SB     = DW / 8,
  localparam int TW     = sfn_pkg::clog2c(NT + 1),
  localparam int SRCW   = sfn_pkg::clog2c(NM),
  localparam int QW     = sfn_pkg::QOSW,
  localparam int NN     = MESH_X * MESH_Y,
  localparam int XW     = sfn_pkg::clog2c(MESH_X),
  localparam int YW     = sfn_pkg::clog2c(MESH_Y),
  localparam int NW     = XW + YW,
  localparam int RQ_HW  = NW + SRCW + IDW + 3 + QW + SB + AW,      // request header
  localparam int RS_HW  = NW + TW + IDW + 3 + 2,                   // response header
  localparam int RQ_FW  = (RQ_HW > DW) ? RQ_HW : DW,               // request flit payload
  localparam int RS_FW  = (RS_HW > DW) ? RS_HW : DW,               // response flit payload
  localparam int RQ_FLW = RQ_FW + 2,
  localparam int RS_FLW = RS_FW + 2,
  localparam int CRW    = sfn_pkg::clog2c(FIFO_DEPTH + 1)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic [NM-1:0]      fq_valid,
  output logic      [NM-1:0]      fq_ready,
  input  wire logic [NM*TW-1:0]   fq_tgt,
  input  wire logic [NM*3-1:0]    fq_opcode,
  input  wire logic [NM*IDW-1:0]  fq_id,
  input  wire logic [NM*QW-1:0]   fq_qos,
  input  wire logic [NM*AW-1:0]   fq_addr,
  input  wire logic [NM*DW-1:0]   fq_wdata,
  input  wire logic [NM*SB-1:0]   fq_wstrb,
  output logic      [NM-1:0]      fr_valid,
  input  wire logic [NM-1:0]      fr_ready,
  output logic      [NM*TW-1:0]   fr_tgt,
  output logic      [NM*IDW-1:0]  fr_id,
  output logic      [NM*3-1:0]    fr_opcode,
  output logic      [NM*2-1:0]    fr_status,
  output logic      [NM*DW-1:0]   fr_rdata,
  output logic      [NT-1:0]      t_req_valid,
  input  wire logic [NT-1:0]      t_req_ready,
  output logic      [NT*3-1:0]    t_req_opcode,
  output logic      [NT*SRCW-1:0] t_req_src,
  output logic      [NT*IDW-1:0]  t_req_id,
  output logic      [NT*QW-1:0]   t_req_qos,
  output logic      [NT*AW-1:0]   t_req_addr,
  output logic      [NT*DW-1:0]   t_req_wdata,
  output logic      [NT*SB-1:0]   t_req_wstrb,
  input  wire logic [NT-1:0]      t_rsp_valid,
  output logic      [NT-1:0]      t_rsp_ready,
  input  wire logic [NT*SRCW-1:0] t_rsp_src,
  input  wire logic [NT*IDW-1:0]  t_rsp_id,
  input  wire logic [NT*3-1:0]    t_rsp_opcode,
  input  wire logic [NT*2-1:0]    t_rsp_status,
  input  wire logic [NT*DW-1:0]   t_rsp_rdata,
  output logic      [NM-1:0]      ev_arb_loss,
  output logic      [NT-1:0]      ev_bad_src
);
  genvar gn, gm, gt;

  // node index -> {y, x}
  function automatic logic [NW-1:0] coord(input int n);
    logic [XW-1:0] x;
    logic [YW-1:0] y;
    begin
      x = XW'(n % MESH_X);
      y = YW'(n / MESH_X);
      coord = {y, x};
    end
  endfunction

  // which master / target sits on each node (-1 = none)
  function automatic int mst_at(input int n);
    begin
      mst_at = -1;
      for (int m = 0; m < NM; m++) if (32'(MST_NODE[m*8 +: 8]) == n) mst_at = m;
    end
  endfunction
  function automatic int tgt_at(input int n);
    begin
      tgt_at = -1;
      for (int t = 0; t < NT; t++) if (32'(TGT_NODE[t*8 +: 8]) == n) tgt_at = t;
    end
  endfunction

  // ================================================================ link wiring
  // per node, per port: flit into the router, flit out of the router, credits
  /* verilator lint_off UNUSEDSIGNAL */   // edge ports of the mesh are unconnected by construction
  logic [NN*5-1:0]        q_in_v, q_in_c, q_out_v, q_out_c;   // request network
  logic [NN*5*RQ_FLW-1:0] q_in_f, q_out_f;
  logic [NN*5-1:0]        s_in_v, s_in_c, s_out_v, s_out_c;   // response network
  logic [NN*5*RS_FLW-1:0] s_in_f, s_out_f;
  logic [NN-1:0]          q_turn, s_turn;                     // observation (checked in simulation)
  /* verilator lint_on UNUSEDSIGNAL */

  for (gn = 0; gn < NN; gn++) begin : g_node
    localparam int X = gn % MESH_X;
    localparam int Y = gn / MESH_X;
    localparam logic [4:0] PEN = {X > 0, Y < MESH_Y - 1, X < MESH_X - 1, Y > 0, 1'b1};   // {W, S, E, N, L}
    // neighbour node indices (only used where the port exists)
    localparam int NN_N = (Y > 0) ? gn - MESH_X : gn;
    localparam int NN_S = (Y < MESH_Y - 1) ? gn + MESH_X : gn;
    localparam int NN_E = (X < MESH_X - 1) ? gn + 1 : gn;
    localparam int NN_W = (X > 0) ? gn - 1 : gn;
    /* verilator lint_off UNUSEDSIGNAL */
    logic [5*CRW-1:0] q_cr, q_occ, s_cr, s_occ;
    /* verilator lint_on UNUSEDSIGNAL */

    sfn_router #(.X(X), .Y(Y), .XW(XW), .YW(YW), .FW(RQ_FW), .DST_LSB(RQ_HW - NW), .QOS_LSB(AW + SB),
                 .ARB_MODE(ARB_MODE), .STARVE(STARVE), .DEPTH(FIFO_DEPTH), .PORT_EN(PEN)) u_rq (
      .clk, .rst_n,
      .in_valid(q_in_v[gn*5 +: 5]), .in_flit(q_in_f[gn*5*RQ_FLW +: 5*RQ_FLW]), .in_credit(q_in_c[gn*5 +: 5]),
      .out_valid(q_out_v[gn*5 +: 5]), .out_flit(q_out_f[gn*5*RQ_FLW +: 5*RQ_FLW]), .out_credit(q_out_c[gn*5 +: 5]),
      .obs_credits(q_cr), .obs_occupancy(q_occ), .obs_turn_err(q_turn[gn]));
    sfn_router #(.X(X), .Y(Y), .XW(XW), .YW(YW), .FW(RS_FW), .DST_LSB(RS_HW - NW), .QOS_LSB(0),
                 .ARB_MODE((ARB_MODE == sfn_pkg::ARB_QOS) ? sfn_pkg::ARB_RR : ARB_MODE), .STARVE(STARVE),
                 .DEPTH(FIFO_DEPTH), .PORT_EN(PEN)) u_rs (
      .clk, .rst_n,
      .in_valid(s_in_v[gn*5 +: 5]), .in_flit(s_in_f[gn*5*RS_FLW +: 5*RS_FLW]), .in_credit(s_in_c[gn*5 +: 5]),
      .out_valid(s_out_v[gn*5 +: 5]), .out_flit(s_out_f[gn*5*RS_FLW +: 5*RS_FLW]), .out_credit(s_out_c[gn*5 +: 5]),
      .obs_credits(s_cr), .obs_occupancy(s_occ), .obs_turn_err(s_turn[gn]));

    // ------------------------------------------------ mesh links: my input <- neighbour's opposite output
    // N input <- S output of the node above; E input <- W output of the right node; etc.
    assign q_in_v[gn*5 + 1] = PEN[1] ? q_out_v[NN_N*5 + 3] : 1'b0;
    assign q_in_v[gn*5 + 2] = PEN[2] ? q_out_v[NN_E*5 + 4] : 1'b0;
    assign q_in_v[gn*5 + 3] = PEN[3] ? q_out_v[NN_S*5 + 1] : 1'b0;
    assign q_in_v[gn*5 + 4] = PEN[4] ? q_out_v[NN_W*5 + 2] : 1'b0;
    assign q_in_f[(gn*5 + 1)*RQ_FLW +: RQ_FLW] = q_out_f[(NN_N*5 + 3)*RQ_FLW +: RQ_FLW];
    assign q_in_f[(gn*5 + 2)*RQ_FLW +: RQ_FLW] = q_out_f[(NN_E*5 + 4)*RQ_FLW +: RQ_FLW];
    assign q_in_f[(gn*5 + 3)*RQ_FLW +: RQ_FLW] = q_out_f[(NN_S*5 + 1)*RQ_FLW +: RQ_FLW];
    assign q_in_f[(gn*5 + 4)*RQ_FLW +: RQ_FLW] = q_out_f[(NN_W*5 + 2)*RQ_FLW +: RQ_FLW];
    // credits for my outputs come back from the neighbour's opposite input
    assign q_out_c[gn*5 + 1] = PEN[1] ? q_in_c[NN_N*5 + 3] : 1'b0;
    assign q_out_c[gn*5 + 2] = PEN[2] ? q_in_c[NN_E*5 + 4] : 1'b0;
    assign q_out_c[gn*5 + 3] = PEN[3] ? q_in_c[NN_S*5 + 1] : 1'b0;
    assign q_out_c[gn*5 + 4] = PEN[4] ? q_in_c[NN_W*5 + 2] : 1'b0;
    assign s_in_v[gn*5 + 1] = PEN[1] ? s_out_v[NN_N*5 + 3] : 1'b0;
    assign s_in_v[gn*5 + 2] = PEN[2] ? s_out_v[NN_E*5 + 4] : 1'b0;
    assign s_in_v[gn*5 + 3] = PEN[3] ? s_out_v[NN_S*5 + 1] : 1'b0;
    assign s_in_v[gn*5 + 4] = PEN[4] ? s_out_v[NN_W*5 + 2] : 1'b0;
    assign s_in_f[(gn*5 + 1)*RS_FLW +: RS_FLW] = s_out_f[(NN_N*5 + 3)*RS_FLW +: RS_FLW];
    assign s_in_f[(gn*5 + 2)*RS_FLW +: RS_FLW] = s_out_f[(NN_E*5 + 4)*RS_FLW +: RS_FLW];
    assign s_in_f[(gn*5 + 3)*RS_FLW +: RS_FLW] = s_out_f[(NN_S*5 + 1)*RS_FLW +: RS_FLW];
    assign s_in_f[(gn*5 + 4)*RS_FLW +: RS_FLW] = s_out_f[(NN_W*5 + 2)*RS_FLW +: RS_FLW];
    assign s_out_c[gn*5 + 1] = PEN[1] ? s_in_c[NN_N*5 + 3] : 1'b0;
    assign s_out_c[gn*5 + 2] = PEN[2] ? s_in_c[NN_E*5 + 4] : 1'b0;
    assign s_out_c[gn*5 + 3] = PEN[3] ? s_in_c[NN_S*5 + 1] : 1'b0;
    assign s_out_c[gn*5 + 4] = PEN[4] ? s_in_c[NN_W*5 + 2] : 1'b0;

    // ------------------------------------------------ local ports
    localparam int MI = mst_at(gn);
    localparam int TI = tgt_at(gn);
    if (MI < 0) begin : g_nomst
      assign q_in_v[gn*5] = 1'b0;
      assign q_in_f[gn*5*RQ_FLW +: RQ_FLW] = '0;
      assign s_out_c[gn*5] = 1'b0;
    end
    if (TI < 0) begin : g_notgt
      assign q_out_c[gn*5] = 1'b0;
      assign s_in_v[gn*5] = 1'b0;
      assign s_in_f[gn*5*RS_FLW +: RS_FLW] = '0;
    end
  end

  // ================================================================ master network interfaces
  for (gm = 0; gm < NM; gm++) begin : g_mni
    localparam int N = 32'(MST_NODE[gm*8 +: 8]);
    // request: {dst, src, id, opcode, qos, wstrb, addr} (+ wdata)
    logic [NW-1:0] dst;
    always_comb begin
      dst = '0;
      for (int t = 0; t < NT; t++)
        if (fq_tgt[gm*TW +: TW] == TW'(t)) dst = coord(32'(TGT_NODE[t*8 +: 8]));
    end
    sfn_ni_tx #(.FW(RQ_FW), .DW(DW), .DEPTH(FIFO_DEPTH)) u_tx (
      .clk, .rst_n, .in_valid(fq_valid[gm]), .in_ready(fq_ready[gm]),
      .in_hdr(RQ_FW'({dst, SRCW'(gm), fq_id[gm*IDW +: IDW], fq_opcode[gm*3 +: 3], fq_qos[gm*QW +: QW],
                      fq_wstrb[gm*SB +: SB], fq_addr[gm*AW +: AW]})),
      .in_two(sfn_pkg::op_is_write(fq_opcode[gm*3 +: 3])), .in_data(fq_wdata[gm*DW +: DW]),
      .out_valid(q_in_v[N*5]), .out_flit(q_in_f[N*5*RQ_FLW +: RQ_FLW]), .out_credit(q_in_c[N*5]));
    assign ev_arb_loss[gm] = fq_valid[gm] && !fq_ready[gm];
    // response: {dst, tgt, id, opcode, status} (+ rdata)
    /* verilator lint_off UNUSEDSIGNAL */
    logic [RS_FW-1:0] rh;               // payload bits above the response header are padding
    /* verilator lint_on UNUSEDSIGNAL */
    /* verilator lint_off UNUSEDSIGNAL */
    logic [sfn_pkg::clog2c(FIFO_DEPTH + 1)-1:0] occ_unused;
    logic ovf_unused;
    /* verilator lint_on UNUSEDSIGNAL */
    sfn_ni_rx #(.FW(RS_FW), .DW(DW), .DEPTH(FIFO_DEPTH)) u_rx (
      .clk, .rst_n, .in_valid(s_out_v[N*5]), .in_flit(s_out_f[N*5*RS_FLW +: RS_FLW]), .in_credit(s_out_c[N*5]),
      .out_valid(fr_valid[gm]), .out_ready(fr_ready[gm]), .out_hdr(rh), .out_data(fr_rdata[gm*DW +: DW]),
      .occupancy(occ_unused), .overflow(ovf_unused));
    assign {fr_tgt[gm*TW +: TW], fr_id[gm*IDW +: IDW], fr_opcode[gm*3 +: 3], fr_status[gm*2 +: 2]} =
           rh[TW + IDW + 3 + 2 - 1 : 0];
  end

  // ================================================================ target network interfaces
  for (gt = 0; gt < NT; gt++) begin : g_tni
    localparam int N = 32'(TGT_NODE[gt*8 +: 8]);
    // request side
    /* verilator lint_off UNUSEDSIGNAL */
    logic [RQ_FW-1:0] qh;
    /* verilator lint_on UNUSEDSIGNAL */
    /* verilator lint_off UNUSEDSIGNAL */
    logic [NW-1:0] q_dst_unused;
    logic [sfn_pkg::clog2c(FIFO_DEPTH + 1)-1:0] occ_unused;
    logic ovf_unused;
    /* verilator lint_on UNUSEDSIGNAL */
    sfn_ni_rx #(.FW(RQ_FW), .DW(DW), .DEPTH(FIFO_DEPTH)) u_rx (
      .clk, .rst_n, .in_valid(q_out_v[N*5]), .in_flit(q_out_f[N*5*RQ_FLW +: RQ_FLW]), .in_credit(q_out_c[N*5]),
      .out_valid(t_req_valid[gt]), .out_ready(t_req_ready[gt]), .out_hdr(qh), .out_data(t_req_wdata[gt*DW +: DW]),
      .occupancy(occ_unused), .overflow(ovf_unused));
    assign {q_dst_unused, t_req_src[gt*SRCW +: SRCW], t_req_id[gt*IDW +: IDW], t_req_opcode[gt*3 +: 3],
            t_req_qos[gt*QW +: QW], t_req_wstrb[gt*SB +: SB], t_req_addr[gt*AW +: AW]} = qh[RQ_HW-1:0];
    // response side: a response naming an illegal source is consumed here and flagged
    logic          src_ok;
    logic [NW-1:0] rdst;
    always_comb begin
      src_ok = 1'b0;
      rdst   = '0;
      for (int m = 0; m < NM; m++)
        if (t_rsp_src[gt*SRCW +: SRCW] == SRCW'(m)) begin
          src_ok = 1'b1;
          rdst   = coord(32'(MST_NODE[m*8 +: 8]));
        end
    end
    logic tx_ready;
    sfn_ni_tx #(.FW(RS_FW), .DW(DW), .DEPTH(FIFO_DEPTH)) u_tx (
      .clk, .rst_n, .in_valid(t_rsp_valid[gt] && src_ok), .in_ready(tx_ready),
      .in_hdr(RS_FW'({rdst, TW'(gt), t_rsp_id[gt*IDW +: IDW], t_rsp_opcode[gt*3 +: 3], t_rsp_status[gt*2 +: 2]})),
      .in_two(t_rsp_opcode[gt*3 +: 3] == sfn_pkg::OP_READ), .in_data(t_rsp_rdata[gt*DW +: DW]),
      .out_valid(s_in_v[N*5]), .out_flit(s_in_f[N*5*RS_FLW +: RS_FLW]), .out_credit(s_in_c[N*5]));
    assign ev_bad_src[gt]  = t_rsp_valid[gt] && !src_ok;
    assign t_rsp_ready[gt] = src_ok ? tx_ready : 1'b1;
  end

`ifndef SYNTHESIS
  initial begin
    for (int n = 0; n < NN; n++) begin
      int cm, ct;
      cm = 0; ct = 0;
      for (int m = 0; m < NM; m++) if (32'(MST_NODE[m*8 +: 8]) == n) cm++;
      for (int t = 0; t < NT; t++) if (32'(TGT_NODE[t*8 +: 8]) == n) ct++;
      if (cm > 1) $fatal(1, "sfn_mesh: %0d masters on node %0d (at most 1)", cm, n);
      if (ct > 1) $fatal(1, "sfn_mesh: %0d targets on node %0d (at most 1)", ct, n);
    end
    for (int m = 0; m < NM; m++) if (32'(MST_NODE[m*8 +: 8]) >= NN) $fatal(1, "sfn_mesh: master %0d node out of range", m);
    for (int t = 0; t < NT; t++) if (32'(TGT_NODE[t*8 +: 8]) >= NN) $fatal(1, "sfn_mesh: target %0d node out of range", t);
    if (FIFO_DEPTH < 2) $fatal(1, "sfn_mesh: FIFO_DEPTH must be >= 2 (credit round trip)");
  end
`endif
endmodule

`default_nettype wire
