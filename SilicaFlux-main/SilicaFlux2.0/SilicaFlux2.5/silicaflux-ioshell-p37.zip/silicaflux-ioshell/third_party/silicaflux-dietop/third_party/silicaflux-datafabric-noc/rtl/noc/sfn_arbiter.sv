// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_arbiter -- arbitration-mode selector
//
// MODE = sfn_pkg::ARB_FIXED / ARB_RR : DataFabric's verified sfb_arbiter,
//        instantiated unmodified (third_party/datafabric; unbounded proofs of
//        one-hot grant, lock and round-robin bounded waiting N-1).
// MODE = sfn_pkg::ARB_QOS            : sfn_qos_arbiter (QoS levels + aging).
// The QoS input is ignored in the first two modes.
// =============================================================================
`default_nettype none

module sfn_arbiter #(
  parameter int N      = 4,
  parameter int MODE   = 1,
  parameter int STARVE = 8,
  localparam int QW    = sfn_pkg::QOSW,
  localparam int IW    = sfn_pkg::clog2c(N)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic [N-1:0]    req,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [N*QW-1:0] qos,
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic            stall,
  input  wire logic            accept,
  output logic      [N-1:0]    grant,
  output logic      [IW-1:0]   grant_idx,
  output logic                 grant_valid
);
  if (MODE == sfn_pkg::ARB_QOS) begin : g_qos
    /* verilator lint_off UNUSEDSIGNAL */
    logic [N-1:0] urgent_unused;
    /* verilator lint_on UNUSEDSIGNAL */
    sfn_qos_arbiter #(.N(N), .STARVE(STARVE)) u_arb (
      .clk, .rst_n, .req, .qos, .stall, .accept,
      .grant, .grant_idx, .grant_valid, .urgent(urgent_unused)
    );
  end else begin : g_base
    sfb_arbiter #(.N(N), .MODE(MODE == sfn_pkg::ARB_FIXED ? 0 : 1)) u_arb (
      .clk, .rst_n, .req, .stall, .accept, .grant, .grant_idx, .grant_valid
    );
  end
endmodule

`default_nettype wire
