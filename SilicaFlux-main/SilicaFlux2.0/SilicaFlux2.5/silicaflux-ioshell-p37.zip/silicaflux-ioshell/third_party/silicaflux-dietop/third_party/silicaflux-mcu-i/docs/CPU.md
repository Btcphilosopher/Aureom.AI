# MCU-I CPU (`rtl/cpu/mcu_cpu.sv`)

## Origin and verification status

`mcu_cpu` is a derived copy of SilicaFlux-V's `sfv_cpu` (vendored unmodified in `third_party/silicaflux-v`).
The existing SilicaFlux CPU was suitable (RV32I, machine mode, precise traps, CLINT-compatible interrupts,
synthesizable, riscv-tests clean), so no external core was imported.

| Evidence | Result (this release) |
|---|---|
| riscv-tests rv32ui + rv32mi on RV32M = 0 | 55/55 pass under 3 bus profiles x 2 seeds (`reports/sim/riscv_tests_m0.txt`) |
| riscv-tests rv32ui + rv32um + rv32mi on RV32M = 1 and 2 | 63/63 pass each (`riscv_tests_m1.txt`, `riscv_tests_m2.txt`) |
| Formal equivalence `mcu_cpu(RV32M=0)` vs `sfv_cpu` | proven (Yosys equiv_simple + equiv_induct, `reports/formal/formal.md`) |
| SoC firmware (both variants) | all scenarios pass (`reports/sim/soc_*.txt`) |

Excluded tests: `rv32ui/ma_data` (hardware misaligned access is optional; the core traps), `rv32mi/pmpaddr`
(no PMP), `rv32mi/breakpoint` (no debug trigger module).

**Compliance statement.** These are the riscv-software-src *riscv-tests* self-checking ISA tests.  The RISC-V
International architectural test suite (riscv-arch-test / ACT) has **not** been run, so MCU-I makes **no claim
of RISC-V compliance or certification**.

## ISA

| Item | Implementation |
|---|---|
| Base | RV32I (32 x 32-bit registers, x0 = 0); RV32E available as a parameter (not used) |
| Extensions | Zicsr; Zifencei (FENCE.I flushes the 2-entry prefetch buffer); **M** optional (RV32M = 1 iterative, 2 single-cycle multiply + iterative divide); **C: not implemented** (removed from the specification: it would need a fetch realigner and 16-bit decode; area and verification cost were not justified for first silicon) |
| Privilege | machine mode only; no U/S mode, no PMP, no MMU |
| Toolchain target | BASIC `-march=rv32i_zicsr_zifencei -mabi=ilp32`; INDUSTRIAL `-march=rv32im_zicsr_zifencei -mabi=ilp32` (GNU riscv64-unknown-elf-gcc 13.2, rv32 multilibs) |
| Reset vector | `0x0000_0000` (boot ROM); `mtvec` resets to the reset vector |
| CSRs | mstatus (MIE/MPIE, MPP=M), misa (I[+M]), mie, mip, mtvec (direct/vectored), mscratch, mepc, mcause, mtval, mcountinhibit, mcycle[h], minstret[h] (+ user read-only aliases), mvendorid = 0, marchid = 0, mimpid = 0x0002_0000, mhartid = 0, mconfigptr = 0 |
| Exceptions | instruction misaligned (on the branch/jump), instruction access fault, illegal instruction, breakpoint, load/store misaligned, load/store access fault (bus error), ecall |
| Interrupts | MEI (from `mcu_intc`), MTI and MSI (from the CLINT-style machine timer); priority MEI > MSI > MTI; taken only at an instruction boundary that is not inside a bus access; a multiply/divide in progress is abandoned (re-executed after MRET) |
| WFI | stalls until any enabled-or-not pending interrupt; with SYSCTRL.CLK_EN.CPU_SLEEP_CG the CPU clock is gated by an ICG once the bus is idle (`bus_idle` output) |

## Pipeline and timing

Two stages: IF keeps one outstanding instruction request and a 2-entry buffer; EX decodes, reads registers,
executes, performs the (blocking) load/store, handles traps and writes back (no forwarding needed).

| Instruction class | Cycles (zero-wait-state slaves) |
|---|---|
| ALU, LUI/AUIPC, CSR | 1 |
| load / store | 2 (+ slave wait states, + arbitration) |
| taken branch / JAL / JALR / trap / MRET | 3 |
| MUL/MULH*/DIV*/REM* with RV32M = 1 | 35 (start, prepare, 32 steps, done) -- data independent |
| MUL/MULH* with RV32M = 2 | 1 (33 x 33 multiplier); DIV*/REM* 35 |

The M unit forms operand magnitudes in a separate *prepare* cycle so the 32-bit negation is not on the
register-file-to-flop path.  This was introduced as a timing fix that turned out not to address the FPGA
critical path (which was the peripheral read path, see [FPGA.md](FPGA.md) and ISSUES.md MCU-R4); it costs one
cycle per MUL/DIV and was kept because it shortens the M-unit input path.

## Debug

JTAG TAP (IDCODE `0x14D49001`; the JEDEC manufacturer field is a placeholder until an ID is assigned), system-bus
access (read/write any address through the crossbar), CPU hold (CPU kept in reset), system reset request and
boot-mode override.  **No RISC-V External Debug Module**: no halt/step/breakpoints/register access through
JTAG (upstream issue ISS-009, still open).  All debug functions can be locked by firmware (see
[SECURITY.md](SECURITY.md)).
