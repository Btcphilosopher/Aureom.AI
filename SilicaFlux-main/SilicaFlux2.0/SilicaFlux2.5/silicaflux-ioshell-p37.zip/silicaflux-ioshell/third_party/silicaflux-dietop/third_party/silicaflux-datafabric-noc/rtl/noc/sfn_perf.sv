// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_perf -- performance counters + error capture
//
// Register page in the SilicaFlux-V register-bus style (rb_*: combinational
// read, write on rb_sel && rb_we), 4 KiB, word addressed:
//   0x000 CTRL       bit0 ENABLE (reset 1), bit1 CLEAR (write 1: zero all counters)
//   0x004 CYCLES     cycles counted while enabled
//   0x008 ERR_STATUS sticky, write-1-to-clear: [0] decode error  [1] posted-write error
//                    [2] orphan response  [3] response with bad source
//                    (bit 1 = a posted completion with SLVERR or a posted write dropped by decode)
//   0x00C ERR_INFO   first decode error since clear: [7:0] master, [10:8] opcode, [31] valid
//   0x010 ERR_ADDR   its address (AW <= 32 bits shown; upper bits in 0x014 when AW > 32)
//   0x014 ERR_ADDR_HI
//   0x018 CONFIG     [7:0] NM  [15:8] NT  [23:16] MAXO_MAX  [25:24] topology  [31:28] IDW
//   0x100 + m*0x40 + 4*k   master m counter k (M_* below), m < 28
//   0x800 + t*0x20 + 4*k   target t counter k (T_* below), t < 64
// All counters are 32-bit and saturate (never wrap).  Byte counts:
//   accepted bytes  (M_ACC_BYTES) : at master acceptance -- popcount(wstrb) for
//                                   writes, DW/8 for reads;
//   delivered bytes : read data delivered to the master with OKAY (M_RD_BYTES) and
//                     write bytes accepted by the target port (T_WR_BYTES).
// Latency (M_LAT_*) is SAMPLED: one transaction per master at a time, started
// when a non-posted request is accepted while no other transaction of its ID
// is outstanding, stopped by the first response of that ID delivered to the
// master; cycles from request acceptance to response acceptance.
// Area: ~(14*NM + 6*NT) x 32 flops; PERF = 0 in silicaflux_noc removes it.
// =============================================================================
`default_nettype none

module sfn_perf #(
  parameter int NM       = 2,
  parameter int NT       = 2,
  parameter int AW       = 32,
  parameter int DW       = 32,
  parameter int IDW      = 2,
  parameter int MAXO_MAX = 4,
  parameter int TOPOLOGY = 1,
  localparam int SB      = DW / 8,
  localparam int CW      = sfn_pkg::clog2c(MAXO_MAX + 1),
  localparam int BW      = sfn_pkg::clog2c(SB + 1),
  localparam int NMC     = 14,     // counters per master
  localparam int NTC     = 6       // counters per target
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // ---------------------------------------------------------------- register bus
  input  wire logic              rb_sel,
  input  wire logic              rb_we,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [11:0]       rb_addr,         // word addressed: [1:0] ignored
  input  wire logic [31:0]       rb_wdata,        // only the control bits are used
  /* verilator lint_on UNUSEDSIGNAL */
  output logic      [31:0]       rb_rdata,
  output logic                   rb_err,
  // ---------------------------------------------------------------- master-side observation
  input  wire logic [NM-1:0]     m_req_valid,
  input  wire logic [NM-1:0]     m_req_ready,
  input  wire logic [NM*3-1:0]   m_req_opcode,
  input  wire logic [NM*IDW-1:0] m_req_id,
  input  wire logic [NM*AW-1:0]  m_req_addr,
  input  wire logic [NM*SB-1:0]  m_req_wstrb,
  input  wire logic [NM-1:0]     m_id_idle,      // no outstanding transaction with m_req_id
  input  wire logic [NM-1:0]     m_rsp_valid,
  input  wire logic [NM-1:0]     m_rsp_ready,
  input  wire logic [NM*IDW-1:0] m_rsp_id,
  input  wire logic [NM*3-1:0]   m_rsp_opcode,
  input  wire logic [NM*2-1:0]   m_rsp_status,
  input  wire logic [NM-1:0]     m_fq_stall,     // presented to the switch, not accepted
  input  wire logic [NM-1:0]     m_blk,          // held back by MAXO / ID / FENCE rules
  input  wire logic [NM*CW-1:0]  m_out_cnt,
  input  wire logic [NM-1:0]     m_decerr,
  input  wire logic [NM-1:0]     m_posted_err,
  input  wire logic [NM-1:0]     m_orphan,
  // ---------------------------------------------------------------- target-side observation
  input  wire logic [NT-1:0]     t_req_valid,
  input  wire logic [NT-1:0]     t_req_ready,
  input  wire logic [NT*3-1:0]   t_req_opcode,
  input  wire logic [NT*SB-1:0]  t_req_wstrb,
  input  wire logic [NT-1:0]     t_rsp_valid,
  input  wire logic [NT-1:0]     t_rsp_ready,
  input  wire logic [NT-1:0]     t_bad_src,
  output logic                   irq_err          // ERR_STATUS != 0
);
  // master counter indices
  localparam int M_REQ       = 0;   // requests accepted
  localparam int M_ACC_BYTES = 1;   // accepted bytes
  localparam int M_RSP       = 2;   // responses delivered
  localparam int M_RD_BYTES  = 3;   // delivered read bytes (OKAY)
  localparam int M_REQ_STALL = 4;   // cycles m_req_valid && !m_req_ready (backpressure at the master)
  localparam int M_ARB_STALL = 5;   // cycles presented to the switch and not accepted (arbitration / target busy)
  localparam int M_BLK       = 6;   // cycles held back by MAXO / ID / FENCE rules
  localparam int M_RSP_STALL = 7;   // cycles m_rsp_valid && !m_rsp_ready (master backpressure)
  localparam int M_OCC_SUM   = 8;   // sum of outstanding count per cycle (average = /CYCLES)
  localparam int M_OCC_MAX   = 9;   // maximum outstanding count
  localparam int M_LAT_SUM   = 10;  // sampled latency sum
  localparam int M_LAT_CNT   = 11;  // sampled latency count
  localparam int M_LAT_MAX   = 12;  // sampled latency maximum
  localparam int M_ERR       = 13;  // error responses delivered + decode errors + posted errors
  // target counter indices
  localparam int T_REQ       = 0;   // requests accepted (request-link transfers)
  localparam int T_WR_BYTES  = 1;   // delivered write bytes
  localparam int T_REQ_BP    = 2;   // cycles t_req_valid && !t_req_ready
  localparam int T_RSP       = 3;   // responses accepted (response-link transfers)
  localparam int T_RSP_BP    = 4;   // cycles t_rsp_valid && !t_rsp_ready
  localparam int T_OCC_MAX   = 5;   // maximum transactions in flight at the target

  logic        en_q;
  logic [31:0] cyc_q;
  logic [3:0]  err_q;
  logic        einfo_v_q;
  logic [7:0]  einfo_m_q;
  logic [2:0]  einfo_op_q;
  logic [AW-1:0] eaddr_q;
  logic [NM*NMC*32-1:0] mc_q;
  logic [NT*NTC*32-1:0] tc_q;
  // latency sampler
  logic [NM-1:0]     smp_q;
  logic [NM*IDW-1:0] smp_id_q;
  logic [NM*32-1:0]  smp_t_q;
  // target occupancy
  logic [NT*16-1:0]  tocc_q;

  wire [NM-1:0] m_acc = m_req_valid & m_req_ready;
  wire [NM-1:0] m_rhs = m_rsp_valid & m_rsp_ready;
  wire clear = rb_sel && rb_we && (rb_addr[11:2] == 10'h000) && rb_wdata[1];

  function automatic logic [31:0] sat_add(input logic [31:0] a, input logic [31:0] b);
    logic [32:0] s;
    begin
      s = {1'b0, a} + {1'b0, b};
      sat_add = s[32] ? 32'hFFFF_FFFF : s[31:0];
    end
  endfunction

  function automatic logic [BW-1:0] popc(input logic [SB-1:0] v);
    begin
      popc = '0;
      for (int i = 0; i < SB; i++) popc = popc + BW'(v[i]);
    end
  endfunction

  // ---------------------------------------------------------------- read mux
  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    if (rb_addr[11:8] == 4'h0) begin
      case (rb_addr[7:2])
        6'd0: rb_rdata = {31'd0, en_q};
        6'd1: rb_rdata = cyc_q;
        6'd2: rb_rdata = {28'd0, err_q};
        6'd3: rb_rdata = {einfo_v_q, 20'd0, einfo_op_q, einfo_m_q};
        6'd4: rb_rdata = eaddr_q[31:0];
        6'd5: rb_rdata = (AW > 32) ? 32'(eaddr_q >> 32) : 32'd0;
        6'd6: rb_rdata = {4'(IDW), 2'd0, 2'(TOPOLOGY), 8'(MAXO_MAX), 8'(NT), 8'(NM)};
        default: rb_err = rb_sel;
      endcase
    end else if (rb_addr[11] == 1'b0) begin
      // masters: 0x100 + m*0x40
      if ((32'(rb_addr[10:6]) - 32'd4) < NM && rb_addr[10:6] >= 5'd4 && rb_addr[5:2] < 4'(NMC))
        rb_rdata = mc_q[((32'(rb_addr[10:6]) - 4) * NMC + 32'(rb_addr[5:2])) * 32 +: 32];
      else
        rb_err = rb_sel;
    end else begin
      if (32'(rb_addr[10:5]) < NT && rb_addr[4:2] < 3'(NTC))
        rb_rdata = tc_q[(32'(rb_addr[10:5]) * NTC + 32'(rb_addr[4:2])) * 32 +: 32];
      else
        rb_err = rb_sel;
    end
  end

  assign irq_err = (err_q != 4'd0);

  // ---------------------------------------------------------------- counters
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      en_q       <= 1'b1;
      cyc_q      <= '0;
      err_q      <= '0;
      einfo_v_q  <= 1'b0;
      einfo_m_q  <= '0;
      einfo_op_q <= '0;
      eaddr_q    <= '0;
      mc_q       <= '0;
      tc_q       <= '0;
      smp_q      <= '0;
      smp_id_q   <= '0;
      smp_t_q    <= '0;
      tocc_q     <= '0;
    end else begin
      // control
      if (rb_sel && rb_we && rb_addr[11:2] == 10'h000) en_q <= rb_wdata[0];
      if (rb_sel && rb_we && rb_addr[11:2] == 10'h002) err_q <= err_q & ~rb_wdata[3:0];
      // error capture (always on, independent of ENABLE)
      for (int m = 0; m < NM; m++) begin
        if (m_decerr[m])     err_q[0] <= 1'b1;
        if (m_posted_err[m] || (m_decerr[m] && m_req_opcode[m*3 +: 3] == sfn_pkg::OP_WRITE_POSTED)) err_q[1] <= 1'b1;
        if (m_orphan[m])     err_q[2] <= 1'b1;
      end
      if (|t_bad_src) err_q[3] <= 1'b1;
      if (rb_sel && rb_we && rb_addr[11:2] == 10'h002 && rb_wdata[0]) einfo_v_q <= 1'b0;
      if (!einfo_v_q) begin
        for (int m = NM - 1; m >= 0; m--) begin
          if (m_decerr[m]) begin
            einfo_v_q  <= 1'b1;
            einfo_m_q  <= 8'(m);
            einfo_op_q <= m_req_opcode[m*3 +: 3];
            eaddr_q    <= m_req_addr[m*AW +: AW];
          end
        end
      end

      // target occupancy tracking runs always (it is state, not a statistic)
      for (int t = 0; t < NT; t++)
        tocc_q[t*16 +: 16] <= tocc_q[t*16 +: 16] + 16'(t_req_valid[t] && t_req_ready[t])
                                                 - 16'(t_rsp_valid[t] && t_rsp_ready[t]);

      // latency sampler state runs always
      for (int m = 0; m < NM; m++) begin
        if (smp_q[m]) begin
          smp_t_q[m*32 +: 32] <= sat_add(smp_t_q[m*32 +: 32], 32'd1);
          if (m_rsp_valid[m] && m_rsp_ready[m] && m_rsp_id[m*IDW +: IDW] == smp_id_q[m*IDW +: IDW])
            smp_q[m] <= 1'b0;
        end else if (m_req_valid[m] && m_req_ready[m] && m_id_idle[m] &&
                     m_req_opcode[m*3 +: 3] != sfn_pkg::OP_WRITE_POSTED) begin
          smp_q[m]              <= 1'b1;
          smp_id_q[m*IDW +: IDW] <= m_req_id[m*IDW +: IDW];
          smp_t_q[m*32 +: 32]    <= 32'd1;
        end
      end

      if (clear) begin
        cyc_q <= '0;
        mc_q  <= '0;
        tc_q  <= '0;
      end else if (en_q) begin
        cyc_q <= sat_add(cyc_q, 32'd1);
        for (int m = 0; m < NM; m++) begin
          if (m_acc[m]) begin
            mc_q[(m*NMC+M_REQ)*32 +: 32] <= sat_add(mc_q[(m*NMC+M_REQ)*32 +: 32], 32'd1);
            if (m_req_opcode[m*3 +: 3] == sfn_pkg::OP_READ)
              mc_q[(m*NMC+M_ACC_BYTES)*32 +: 32] <= sat_add(mc_q[(m*NMC+M_ACC_BYTES)*32 +: 32], 32'(SB));
            else if (sfn_pkg::op_is_write(m_req_opcode[m*3 +: 3]))
              mc_q[(m*NMC+M_ACC_BYTES)*32 +: 32] <= sat_add(mc_q[(m*NMC+M_ACC_BYTES)*32 +: 32],
                                                            32'(popc(m_req_wstrb[m*SB +: SB])));
          end
          if (m_rhs[m]) begin
            mc_q[(m*NMC+M_RSP)*32 +: 32] <= sat_add(mc_q[(m*NMC+M_RSP)*32 +: 32], 32'd1);
            if (m_rsp_opcode[m*3 +: 3] == sfn_pkg::OP_READ && m_rsp_status[m*2 +: 2] == sfn_pkg::ST_OKAY)
              mc_q[(m*NMC+M_RD_BYTES)*32 +: 32] <= sat_add(mc_q[(m*NMC+M_RD_BYTES)*32 +: 32], 32'(SB));
          end
          if (m_req_valid[m] && !m_req_ready[m])
            mc_q[(m*NMC+M_REQ_STALL)*32 +: 32] <= sat_add(mc_q[(m*NMC+M_REQ_STALL)*32 +: 32], 32'd1);
          if (m_fq_stall[m])
            mc_q[(m*NMC+M_ARB_STALL)*32 +: 32] <= sat_add(mc_q[(m*NMC+M_ARB_STALL)*32 +: 32], 32'd1);
          if (m_blk[m])
            mc_q[(m*NMC+M_BLK)*32 +: 32] <= sat_add(mc_q[(m*NMC+M_BLK)*32 +: 32], 32'd1);
          if (m_rsp_valid[m] && !m_rsp_ready[m])
            mc_q[(m*NMC+M_RSP_STALL)*32 +: 32] <= sat_add(mc_q[(m*NMC+M_RSP_STALL)*32 +: 32], 32'd1);
          mc_q[(m*NMC+M_OCC_SUM)*32 +: 32] <= sat_add(mc_q[(m*NMC+M_OCC_SUM)*32 +: 32], 32'(m_out_cnt[m*CW +: CW]));
          if (32'(m_out_cnt[m*CW +: CW]) > mc_q[(m*NMC+M_OCC_MAX)*32 +: 32])
            mc_q[(m*NMC+M_OCC_MAX)*32 +: 32] <= 32'(m_out_cnt[m*CW +: CW]);
          if (smp_q[m] && m_rhs[m] && m_rsp_id[m*IDW +: IDW] == smp_id_q[m*IDW +: IDW]) begin
            mc_q[(m*NMC+M_LAT_SUM)*32 +: 32] <= sat_add(mc_q[(m*NMC+M_LAT_SUM)*32 +: 32], smp_t_q[m*32 +: 32]);
            mc_q[(m*NMC+M_LAT_CNT)*32 +: 32] <= sat_add(mc_q[(m*NMC+M_LAT_CNT)*32 +: 32], 32'd1);
            if (smp_t_q[m*32 +: 32] > mc_q[(m*NMC+M_LAT_MAX)*32 +: 32])
              mc_q[(m*NMC+M_LAT_MAX)*32 +: 32] <= smp_t_q[m*32 +: 32];
          end
          // one count per error event (a delivered error response, a failed posted
          // completion and a dropped posted write can coincide in one cycle)
          mc_q[(m*NMC+M_ERR)*32 +: 32] <= sat_add(mc_q[(m*NMC+M_ERR)*32 +: 32],
              32'(m_rhs[m] && m_rsp_status[m*2 +: 2] != sfn_pkg::ST_OKAY) + 32'(m_posted_err[m]) +
              32'(m_decerr[m] && m_req_opcode[m*3 +: 3] == sfn_pkg::OP_WRITE_POSTED));
        end
        for (int t = 0; t < NT; t++) begin
          if (t_req_valid[t] && t_req_ready[t]) begin
            tc_q[(t*NTC+T_REQ)*32 +: 32] <= sat_add(tc_q[(t*NTC+T_REQ)*32 +: 32], 32'd1);
            if (sfn_pkg::op_is_write(t_req_opcode[t*3 +: 3]))
              tc_q[(t*NTC+T_WR_BYTES)*32 +: 32] <= sat_add(tc_q[(t*NTC+T_WR_BYTES)*32 +: 32],
                                                           32'(popc(t_req_wstrb[t*SB +: SB])));
          end
          if (t_req_valid[t] && !t_req_ready[t])
            tc_q[(t*NTC+T_REQ_BP)*32 +: 32] <= sat_add(tc_q[(t*NTC+T_REQ_BP)*32 +: 32], 32'd1);
          if (t_rsp_valid[t] && t_rsp_ready[t])
            tc_q[(t*NTC+T_RSP)*32 +: 32] <= sat_add(tc_q[(t*NTC+T_RSP)*32 +: 32], 32'd1);
          if (t_rsp_valid[t] && !t_rsp_ready[t])
            tc_q[(t*NTC+T_RSP_BP)*32 +: 32] <= sat_add(tc_q[(t*NTC+T_RSP_BP)*32 +: 32], 32'd1);
          if (32'(tocc_q[t*16 +: 16]) > tc_q[(t*NTC+T_OCC_MAX)*32 +: 32])
            tc_q[(t*NTC+T_OCC_MAX)*32 +: 32] <= 32'(tocc_q[t*16 +: 16]);
        end
      end
    end
  end

`ifndef SYNTHESIS
  initial begin
    if (NM > 28) $fatal(1, "sfn_perf: NM=%0d > 28 does not fit the register page", NM);
    if (NT > 64) $fatal(1, "sfn_perf: NT=%0d > 64 does not fit the register page", NT);
  end
`endif
endmodule

`default_nettype wire
