// =============================================================================
// sf_reset_sync : asynchronous assertion, synchronous de-assertion.
// rst_ni may come from any domain (POR, an always-on flop, ...). It must be
// glitch-free: drive it only from a flop output or a POR cell, never from
// combinational logic of multiple signals.
// test_mode_i bypasses the synchroniser so scan can control the reset directly.
// =============================================================================
module sf_reset_sync #(
  parameter int STAGES = 2
) (
  input  logic clk_i,
  input  logic rst_ni,
  input  logic test_mode_i,
  output logic rst_no
);
  (* ASYNC_REG = "TRUE" *) logic [STAGES-1:0] sync_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) sync_q <= '0;
    else         sync_q <= {sync_q[STAGES-2:0], 1'b1};
  end

  assign rst_no = test_mode_i ? rst_ni : sync_q[STAGES-1];
endmodule
