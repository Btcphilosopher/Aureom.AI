// =============================================================================
// SilicaFlux DataFabric-NoC :: network interfaces (packetiser / depacketiser)
//
// sfn_ni_tx : message {hdr, two, data} -> packet into a router local input.
//             two = 0: one flit  {head=1, tail=1, hdr}
//             two = 1: two flits {head=1, tail=0, hdr} then {head=0, tail=1, data}
//             Sends only with a credit (counter initialised to DEPTH = the router
//             input FIFO depth, +1 per returned credit).  in_ready does not depend
//             on in_valid; a message is taken when its head flit is sent, its data
//             flit follows (one flit per cycle per link).
// sfn_ni_rx : packet from a router local output -> message.  Own input FIFO of
//             DEPTH flits; one credit returned per flit popped.  A two-flit
//             packet's head is latched; the message is presented with the data
//             flit at the FIFO head.  Output held stable until accepted (R4).
// Packet boundaries are carried by the head/tail bits only, so the same pair is
// used for requests (two = write) and responses (two = read) on both networks.
// =============================================================================
`default_nettype none

module sfn_ni_tx #(
  parameter int  FW    = 32,
  parameter int  DW    = 32,
  parameter int  DEPTH = 4,
  localparam int FLW   = FW + 2,
  localparam int CRW   = sfn_pkg::clog2c(DEPTH + 1)
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic           in_valid,
  output logic                in_ready,
  input  wire logic [FW-1:0]  in_hdr,
  input  wire logic           in_two,
  input  wire logic [DW-1:0]  in_data,
  output logic                out_valid,
  output logic [FLW-1:0]      out_flit,
  input  wire logic           out_credit
);
  logic [CRW-1:0] cr_q;
  logic           pend_q;
  logic [DW-1:0]  data_q;
  wire can = (cr_q != '0);

  assign in_ready  = !pend_q && can;
  assign out_valid = pend_q ? can : (in_valid && can);
  assign out_flit  = pend_q ? {1'b0, 1'b1, FW'(data_q)} : {1'b1, !in_two, in_hdr};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cr_q   <= CRW'(DEPTH);
      pend_q <= 1'b0;
      data_q <= '0;
    end else begin
      cr_q <= cr_q - CRW'(out_valid) + CRW'(out_credit);
      if (pend_q) begin
        if (can) pend_q <= 1'b0;
      end else if (in_valid && can && in_two) begin
        pend_q <= 1'b1;
        data_q <= in_data;
      end
    end
  end
endmodule

module sfn_ni_rx #(
  parameter int  FW    = 32,
  parameter int  DW    = 32,
  parameter int  DEPTH = 4,
  localparam int FLW   = FW + 2,
  localparam int CNTW  = sfn_pkg::clog2c(DEPTH + 1)
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic           in_valid,
  input  wire logic [FLW-1:0] in_flit,
  output logic                in_credit,
  output logic                out_valid,
  input  wire logic           out_ready,
  output logic [FW-1:0]       out_hdr,
  output logic [DW-1:0]       out_data,
  output logic [CNTW-1:0]     occupancy,
  output logic                overflow       // a flit arrived at a full FIFO (credit protocol broken)
);
  logic           f_valid, f_pop, f_in_ready;
  logic [FLW-1:0] f_head;
  sfn_fifo #(.W(FLW), .DEPTH(DEPTH)) u_fifo (
    .clk, .rst_n, .in_valid, .in_ready(f_in_ready), .in_data(in_flit),
    .out_valid(f_valid), .out_ready(f_pop), .out_data(f_head), .count(occupancy)
  );
  assign overflow = in_valid && !f_in_ready;

  logic          hv_q;
  logic [FW-1:0] hdr_q;
  wire is_head = f_head[FLW-1];
  wire is_tail = f_head[FLW-2];
  // states: no latched head -> a single-flit packet is delivered from the FIFO head,
  //         the head of a two-flit packet is latched (popped); latched head -> deliver with the data flit
  assign out_valid = hv_q ? f_valid : (f_valid && is_head && is_tail);
  assign out_hdr   = hv_q ? hdr_q : f_head[FW-1:0];
  assign out_data  = hv_q ? f_head[DW-1:0] : '0;
  assign f_pop     = (out_valid && out_ready) || (!hv_q && f_valid && is_head && !is_tail);
  assign in_credit = f_pop;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      hv_q  <= 1'b0;
      hdr_q <= '0;
    end else if (!hv_q && f_valid && is_head && !is_tail) begin
      hv_q  <= 1'b1;
      hdr_q <= f_head[FW-1:0];
    end else if (hv_q && out_valid && out_ready) begin
      hv_q  <= 1'b0;
    end
  end
endmodule

`default_nettype wire
