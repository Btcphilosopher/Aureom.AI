// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_qos_arbiter -- QoS arbiter with aging
//
// Every requester i presents a QoS level qos[i] (sfn_pkg::QOS_*; larger = more
// urgent).  Selection, in this order:
//   1. grant lock: a granted request that was presented downstream but not
//      accepted (`stall`) keeps the grant while it is still requested (payload
//      stability at the target, SFB3 rule R2 -- same rule as sfb_arbiter);
//   2. aging: requester i that has seen STARVE other acceptances in a row
//      while requesting becomes URGENT; urgent requesters form the top level;
//   3. otherwise the highest QoS level present wins;
//   4. ties inside the winning level: round robin from pointer prio_q, which
//      moves past the winner only when the grant is ACCEPTED.
//
// Guarantee (proved unbounded in formal/fv_sfn_qos_arbiter.sv): a requester
// that keeps requesting is accepted after at most STARVE + N - 1 acceptances of
// other requesters.  Priority gives latency preference only -- it is NOT a
// bandwidth guarantee: under saturation a level gets whatever the levels above
// leave, down to the aging floor of one grant per STARVE + N - 1.
// STARVE = 0 makes every requester urgent at once: plain round robin.
// Combinational path: req/qos -> grant.  No path from stall/accept.
// =============================================================================
`default_nettype none

module sfn_qos_arbiter #(
  parameter int N      = 4,
  parameter int STARVE = 8,
  localparam int QW    = sfn_pkg::QOSW,
  localparam int IW    = sfn_pkg::clog2c(N),
  localparam int AGW   = sfn_pkg::clog2c(STARVE + 1)
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic [N-1:0]   req,
  input  wire logic [N*QW-1:0] qos,
  input  wire logic           stall,       // granted request presented, not accepted
  input  wire logic           accept,      // granted request accepted this cycle
  output logic      [N-1:0]   grant,       // one-hot or zero
  output logic      [IW-1:0]  grant_idx,
  output logic                grant_valid,
  output logic      [N-1:0]   urgent       // observability (aging reached)
);
  logic [IW-1:0]  prio_q;
  logic           lock_q;
  logic [IW-1:0]  lock_idx_q;
  logic [N*AGW-1:0] age_q;

  // effective level: urgent requesters sit above every QoS level
  logic [QW:0]    lvl [N];
  logic [QW:0]    top;
  logic [N-1:0]   elig;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [2*N-1:0] elig2;                  // upper half intentionally unused
  /* verilator lint_on UNUSEDSIGNAL */
  logic [N-1:0]   rot;
  logic [IW-1:0]  off;
  logic           found;
  logic [IW:0]    sum;

  always_comb begin
    for (int i = 0; i < N; i++) begin
      urgent[i] = (age_q[i*AGW +: AGW] >= AGW'(STARVE));
      lvl[i]    = urgent[i] ? {1'b1, {QW{1'b0}}} : {1'b0, qos[i*QW +: QW]};
    end
    top = '0;
    for (int i = 0; i < N; i++)
      if (req[i] && lvl[i] > top) top = lvl[i];
    for (int i = 0; i < N; i++)
      elig[i] = req[i] && (lvl[i] == top);

    elig2     = '0;
    rot       = '0;
    off       = '0;
    found     = 1'b0;
    sum       = '0;
    grant_idx = '0;
    if (lock_q && req[lock_idx_q]) begin
      found     = 1'b1;
      grant_idx = lock_idx_q;
    end else begin
      elig2 = {elig, elig} >> prio_q;
      rot   = elig2[N-1:0];
      for (int k = N - 1; k >= 0; k--) begin
        if (rot[k]) begin
          found = 1'b1;
          off   = IW'(k);
        end
      end
      sum = {1'b0, prio_q} + {1'b0, off};
      if (sum >= (IW+1)'(N)) grant_idx = IW'(sum - (IW+1)'(N));
      else                   grant_idx = IW'(sum);
    end
    grant_valid = found;
    grant       = found ? (N'(1) << grant_idx) : '0;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      prio_q     <= '0;
      lock_q     <= 1'b0;
      lock_idx_q <= '0;
      age_q      <= '0;
    end else begin
      lock_q     <= grant_valid && stall && !accept;
      lock_idx_q <= grant_idx;
      if (accept && grant_valid)
        prio_q <= (grant_idx == IW'(N - 1)) ? '0 : grant_idx + IW'(1);
      for (int i = 0; i < N; i++) begin
        if (!req[i] || (accept && grant_valid && grant_idx == IW'(i)))
          age_q[i*AGW +: AGW] <= '0;
        else if (accept && grant_valid && age_q[i*AGW +: AGW] < AGW'(STARVE))
          age_q[i*AGW +: AGW] <= age_q[i*AGW +: AGW] + AGW'(1);
      end
    end
  end
endmodule

`default_nettype wire
