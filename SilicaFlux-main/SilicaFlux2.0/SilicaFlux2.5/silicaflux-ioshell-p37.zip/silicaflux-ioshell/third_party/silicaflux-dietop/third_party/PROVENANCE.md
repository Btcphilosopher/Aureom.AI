# third_party — provenance

Every file under `third_party/` is copied **unmodified** from an archive in the Aureom.AI repository
(`SilicaFlux-main/` and `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`).

* `MANIFEST.tsv` gives, for each file, the destination path, the source archive, the path inside the archive
  and its SHA-256.
* `SHA256SUMS` can be checked with `make vendor` (`sha256sum -c`).

| Directory | Project | Source archive | Role in the die |
|---|---|---|---|
| `silicaflux-controlcore/` | Project 21 ControlCore: RTL, generated map / boot-ROM image, prebuilt firmware image, `cc_memmap.yaml`, C map header | `silicaflux-controlcore.zip` | `control_subsystem`, firmware scenario, map cross-check (generator rule R5) |
| `silicaflux-mcu-i/`, `silicaflux-v/` | CPU, INTC, WDT, system DMA, SRAM bank; SilicaFlux-V bus/peripheral utilities | as vendored by ControlCore (`silicaflux-controlcore.zip` `third_party/`) | inside the ControlCore; `sfv_periph_bridge` in `die_regs_window` |
| `silicaflux-datafabric/` | SFB2 interconnect, DMA engines, `silicaflux_dma` + register file, `sfb_protocol_checker` (TB) | ControlCore `third_party/` + `silicaflux-memorycore1.zip` `third_party/silicaflux-datafabric` | ControlCore crossbar, die DMA, register-window adapter, testbench checker |
| `silicaflux-sramlib/` | SRAM library (bank controller, generic / FPGA / ASIC back ends, macro black boxes) | ControlCore `third_party/` + MemoryCore `third_party/` (`sram_bank_controller.sv`) | all SRAMs |
| `silicaflux-hpc-m08-tile/` (+ M03, M04, M05 inside) | HPC Module 08 FP32 vector tile | ControlCore `third_party/` | `vector_cluster` |
| `silicaflux-tensorcore02` … `silicaflux-tensorcore08/` | INT8 tensor unit and its parts | ControlCore `third_party/` | `tensor_cluster` |
| `silicaflux-hpc-m04-scratchpad/` | banked scratchpad (inside the tile) | ControlCore `third_party/` | inside the tile |
| `silicaflux-datafabric-noc/` | Project 22 DataFabric-NoC (`rtl/noc/`) | `silicaflux-datafabric-noc.zip` | `datafabric` |
| `silicaflux-memorycore/` | MemoryCore `sfmem_banked` + defines | `silicaflux-memorycore1.zip` | `memory_subsystem` |
| `silicaflux-extmem/` | Project 24 external-memory bridge RTL (+ CDC), **simulation-only** controller model `sim/models/extmem_sim_mc.sv`, SFMC checker `tb/extmem_mc_checker.sv` | `silicaflux-extmem-bridge-p24.zip` | `memory_subsystem`; the model and checker are testbench-only |
| `silicaflux-powerclock/` | Project 27 `sf_reset_sync` | `silicaflux-powerclock.zip` | `clock_reset_subsystem` |
| `silicaflux-testcore/` | TestCore RTL | `silicaflux-testcore.zip` | **not compiled** (vendored for the future TestCore integration; see `docs/06_LIMITATIONS.md`) |

Consistency check performed during the audit: every same-named `.sv` / `.svh` file was hashed across all 26
extracted archives. All copies are identical, except `dma_defs.svh`, whose two variants differ only in a
generated header comment.

The repository contains no license file (as the ControlCore audit also notes).
