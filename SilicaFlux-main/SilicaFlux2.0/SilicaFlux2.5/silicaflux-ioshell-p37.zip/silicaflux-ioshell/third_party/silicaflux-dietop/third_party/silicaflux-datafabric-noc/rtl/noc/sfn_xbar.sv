// =============================================================================
// SilicaFlux DataFabric-NoC :: sfn_xbar -- crossbar switching core
//
// Between NM sfn_mst_port front ends and NT SFB3 target ports.
//  * request : per target one arbiter (sfn_arbiter: fixed / round robin / QoS)
//              over the masters that present a request for it; one-hot payload
//              mux; the source identifier t_req_src is the winning master index
//              (stamped by the fabric: a master cannot spoof it).
//  * response: per master one round-robin arbiter over the targets whose
//              response carries t_rsp_src == that master; grant lock while the
//              master port stalls.  A response with t_rsp_src >= NM can only
//              come from a faulty target: it is consumed and flagged.
//  * MST_TGT_EN removes disabled master/target pairs by constant propagation
//    (the front end already never presents them).
//  * every master and every target can transfer one request and one response
//    per cycle concurrently (non-blocking for disjoint pairs); 0 added cycles.
// =============================================================================
`default_nettype none

module sfn_xbar #(
  parameter int               NM         = 2,
  parameter int               NT         = 2,
  parameter int               AW         = 32,
  parameter int               DW         = 32,
  parameter int               IDW        = 2,
  parameter int               ARB_MODE   = 1,
  parameter int               STARVE     = 8,
  parameter logic [NM*NT-1:0] MST_TGT_EN = {(NM*NT){1'b1}},     // bit m*NT+t
  localparam int              SB         = DW / 8,
  localparam int              TW         = sfn_pkg::clog2c(NT + 1),
  localparam int              SRCW       = sfn_pkg::clog2c(NM),
  localparam int              QW         = sfn_pkg::QOSW,
  localparam int              PW         = 3 + IDW + QW + AW + DW + SB,   // request payload
  localparam int              RW         = IDW + 3 + 2 + DW               // response payload
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ------------------------------------------------------------ master front ends
  input  wire logic [NM-1:0]      fq_valid,
  output logic      [NM-1:0]      fq_ready,
  input  wire logic [NM*TW-1:0]   fq_tgt,
  input  wire logic [NM*3-1:0]    fq_opcode,
  input  wire logic [NM*IDW-1:0]  fq_id,
  input  wire logic [NM*QW-1:0]   fq_qos,
  input  wire logic [NM*AW-1:0]   fq_addr,
  input  wire logic [NM*DW-1:0]   fq_wdata,
  input  wire logic [NM*SB-1:0]   fq_wstrb,
  output logic      [NM-1:0]      fr_valid,
  input  wire logic [NM-1:0]      fr_ready,
  output logic      [NM*TW-1:0]   fr_tgt,
  output logic      [NM*IDW-1:0]  fr_id,
  output logic      [NM*3-1:0]    fr_opcode,
  output logic      [NM*2-1:0]    fr_status,
  output logic      [NM*DW-1:0]   fr_rdata,
  // ------------------------------------------------------------ SFB3 target ports
  output logic      [NT-1:0]      t_req_valid,
  input  wire logic [NT-1:0]      t_req_ready,
  output logic      [NT*3-1:0]    t_req_opcode,
  output logic      [NT*SRCW-1:0] t_req_src,
  output logic      [NT*IDW-1:0]  t_req_id,
  output logic      [NT*QW-1:0]   t_req_qos,
  output logic      [NT*AW-1:0]   t_req_addr,
  output logic      [NT*DW-1:0]   t_req_wdata,
  output logic      [NT*SB-1:0]   t_req_wstrb,
  input  wire logic [NT-1:0]      t_rsp_valid,
  output logic      [NT-1:0]      t_rsp_ready,
  input  wire logic [NT*SRCW-1:0] t_rsp_src,
  input  wire logic [NT*IDW-1:0]  t_rsp_id,
  input  wire logic [NT*3-1:0]    t_rsp_opcode,
  input  wire logic [NT*2-1:0]    t_rsp_status,
  input  wire logic [NT*DW-1:0]   t_rsp_rdata,
  // ------------------------------------------------------------ events
  output logic      [NM-1:0]      ev_arb_loss,   // presented, another master won the target this cycle
  output logic      [NT-1:0]      ev_bad_src     // response with an out-of-range source consumed
);
  genvar gm, gt;

  // ================================================================ request path
  logic [NT*NM-1:0] grant;       // bit t*NM+m
  logic [NT-1:0]    gvalid;
  logic [NM*PW-1:0] mpay;
  for (gm = 0; gm < NM; gm++) begin : g_mpay
    assign mpay[gm*PW +: PW] = {fq_opcode[gm*3 +: 3], fq_id[gm*IDW +: IDW], fq_qos[gm*QW +: QW],
                                fq_addr[gm*AW +: AW], fq_wdata[gm*DW +: DW], fq_wstrb[gm*SB +: SB]};
  end

  for (gt = 0; gt < NT; gt++) begin : g_tgt
    logic [NM-1:0]   cand;
    logic [SRCW-1:0] gidx;
    logic [PW-1:0]   pay;
    for (gm = 0; gm < NM; gm++) begin : g_cand
      assign cand[gm] = MST_TGT_EN[gm*NT + gt] && fq_valid[gm] && (fq_tgt[gm*TW +: TW] == TW'(gt));
    end
    sfn_arbiter #(.N(NM), .MODE(ARB_MODE), .STARVE(STARVE)) u_arb (
      .clk, .rst_n, .req(cand), .qos(fq_qos),
      .stall(t_req_valid[gt] && !t_req_ready[gt]),
      .accept(t_req_valid[gt] && t_req_ready[gt]),
      .grant(grant[gt*NM +: NM]), .grant_idx(gidx), .grant_valid(gvalid[gt])
    );
    sfn_onehot_mux #(.N(NM), .W(PW)) u_mux (.sel(grant[gt*NM +: NM]), .din(mpay), .dout(pay));
    assign t_req_valid[gt] = gvalid[gt];
    assign t_req_src[gt*SRCW +: SRCW] = gidx;
    assign {t_req_opcode[gt*3 +: 3], t_req_id[gt*IDW +: IDW], t_req_qos[gt*QW +: QW],
            t_req_addr[gt*AW +: AW], t_req_wdata[gt*DW +: DW], t_req_wstrb[gt*SB +: SB]} = pay;
  end

  always_comb begin
    for (int m = 0; m < NM; m++) begin
      fq_ready[m]    = 1'b0;
      ev_arb_loss[m] = 1'b0;
      for (int t = 0; t < NT; t++) begin
        if (grant[t*NM + m] && t_req_ready[t]) fq_ready[m] = 1'b1;
        if (MST_TGT_EN[m*NT + t] && fq_valid[m] && (fq_tgt[m*TW +: TW] == TW'(t)) && !grant[t*NM + m] && gvalid[t])
          ev_arb_loss[m] = 1'b1;
      end
    end
  end

  // ================================================================ response path
  logic [NT*RW-1:0] tpay;
  logic [NM*NT-1:0] rgrant;      // bit m*NT+t
  for (gt = 0; gt < NT; gt++) begin : g_tpay
    assign tpay[gt*RW +: RW] = {t_rsp_id[gt*IDW +: IDW], t_rsp_opcode[gt*3 +: 3], t_rsp_status[gt*2 +: 2],
                                t_rsp_rdata[gt*DW +: DW]};
    // a source that is out of range or not allowed to reach this target cannot own the response
    logic src_ok;
    always_comb begin
      src_ok = 1'b0;
      for (int m = 0; m < NM; m++)
        if (MST_TGT_EN[m*NT + gt] && (t_rsp_src[gt*SRCW +: SRCW] == SRCW'(m))) src_ok = 1'b1;
    end
    assign ev_bad_src[gt] = t_rsp_valid[gt] && !src_ok;
  end

  for (gm = 0; gm < NM; gm++) begin : g_mst
    logic [NT-1:0]   rcand;
    logic [sfn_pkg::clog2c(NT)-1:0] ridx;
    logic            rgv;
    logic [RW-1:0]   rpay;
    for (gt = 0; gt < NT; gt++) begin : g_rcand
      assign rcand[gt] = MST_TGT_EN[gm*NT + gt] && t_rsp_valid[gt] && (t_rsp_src[gt*SRCW +: SRCW] == SRCW'(gm));
    end
    sfb_arbiter #(.N(NT), .MODE(1)) u_rarb (
      .clk, .rst_n, .req(rcand),
      .stall(fr_valid[gm] && !fr_ready[gm]), .accept(fr_valid[gm] && fr_ready[gm]),
      .grant(rgrant[gm*NT +: NT]), .grant_idx(ridx), .grant_valid(rgv)
    );
    sfn_onehot_mux #(.N(NT), .W(RW)) u_rmux (.sel(rgrant[gm*NT +: NT]), .din(tpay), .dout(rpay));
    assign fr_valid[gm] = rgv;
    assign fr_tgt[gm*TW +: TW] = TW'(ridx);
    assign {fr_id[gm*IDW +: IDW], fr_opcode[gm*3 +: 3], fr_status[gm*2 +: 2], fr_rdata[gm*DW +: DW]} = rpay;
  end

  always_comb begin
    for (int t = 0; t < NT; t++) begin
      t_rsp_ready[t] = ev_bad_src[t];
      for (int m = 0; m < NM; m++)
        if (rgrant[m*NT + t] && fr_ready[m]) t_rsp_ready[t] = 1'b1;
    end
  end
endmodule

`default_nettype wire
