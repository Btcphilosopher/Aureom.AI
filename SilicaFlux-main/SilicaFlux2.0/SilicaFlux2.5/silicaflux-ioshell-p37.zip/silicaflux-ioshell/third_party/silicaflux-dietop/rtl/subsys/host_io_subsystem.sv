// =============================================================================
// SilicaFlux DieTop :: host_io_subsystem -- host interface of the die
//
// MIN / default: the SIMULATION HOST BRIDGE.  The die boundary carries a plain
// SFB2 slave port (host_*) -- the transaction-level stand-in for a physical host
// link.  The bridge splits it by address:
//   ControlCore regions (boot ROM, IMEM, DMEM, register pages) ─► ControlCore host port (hs_*)
//   EXT window 0x2000_0000..0x3FFF_FFFF (shared SRAM, SPM windows, external memory)
//                                                              ─► NoC master HOST (fab_*)
//   anything else ─► answered locally with rsp_error = 1 (HOST_DECODE event)
// One transaction at a time; a request is routed only after the previous
// response was delivered, so ordering across the two paths is preserved.
// Requests are presented on the selected path only (never withdrawn: the
// decode depends on the held request, SFB2 R2).
// A physical host link (PCIe endpoint + HostLink BAR / queue engine) attaches to
// this port from outside the die: see silicaflux_die_pcie_wrap (optional wrapper).
// Classification: SYNTHESIZABLE (new, Project 31)
// =============================================================================
`default_nettype none

module host_io_subsystem
(
  input  wire logic        clk,
  input  wire logic        rst_n,          // fabric reset
  // die boundary: host port (SFB2 slave)
  input  wire logic        host_req_valid,
  output logic             host_req_ready,
  input  wire logic        host_req_write,
  input  wire logic [31:0] host_req_addr,
  input  wire logic [31:0] host_req_wdata,
  input  wire logic [3:0]  host_req_wstrb,
  output logic             host_rsp_valid,
  input  wire logic        host_rsp_ready,
  output logic [31:0]      host_rsp_rdata,
  output logic             host_rsp_error,
  // to the ControlCore host access port (SFB2 master)
  output logic             cc_req_valid,
  input  wire logic        cc_req_ready,
  output logic             cc_req_write,
  output logic [31:0]      cc_req_addr,
  output logic [31:0]      cc_req_wdata,
  output logic [3:0]       cc_req_wstrb,
  input  wire logic        cc_rsp_valid,
  output logic             cc_rsp_ready,
  input  wire logic [31:0] cc_rsp_rdata,
  input  wire logic        cc_rsp_error,
  // to the NoC (SFB2 master HOST)
  output logic             fab_req_valid,
  input  wire logic        fab_req_ready,
  output logic             fab_req_write,
  output logic [31:0]      fab_req_addr,
  output logic [31:0]      fab_req_wdata,
  output logic [3:0]       fab_req_wstrb,
  input  wire logic        fab_rsp_valid,
  output logic             fab_rsp_ready,
  input  wire logic [31:0] fab_rsp_rdata,
  input  wire logic        fab_rsp_error,
  // events / status
  output logic             dec_err_evt,
  output logic [31:0]      dec_err_addr,
  output logic             busy
);

  function automatic logic in_win(input logic [31:0] a, input logic [31:0] base, input logic [31:0] win);
    in_win = (a & ~(win - 32'd1)) == base;
  endfunction
  localparam logic [31:0] EXT_LO = silicaflux_die_pkg::DIE_SHARED_SRAM_BASE;     // ControlCore EXT window
  localparam logic [31:0] EXT_HI = silicaflux_die_pkg::DIE_CC_PERIPH_BASE;

  wire a_cc  = in_win(host_req_addr, silicaflux_die_pkg::DIE_CC_BOOTROM_BASE, silicaflux_die_pkg::DIE_CC_BOOTROM_WINDOW) ||
               in_win(host_req_addr, silicaflux_die_pkg::DIE_CC_IMEM_BASE, silicaflux_die_pkg::DIE_CC_IMEM_WINDOW) ||
               in_win(host_req_addr, silicaflux_die_pkg::DIE_CC_DMEM_BASE, silicaflux_die_pkg::DIE_CC_DMEM_WINDOW) ||
               in_win(host_req_addr, silicaflux_die_pkg::DIE_CC_PERIPH_BASE, silicaflux_die_pkg::DIE_CC_PERIPH_WINDOW);
  wire a_fab = (host_req_addr >= EXT_LO) && (host_req_addr < EXT_HI);

  typedef enum logic [2:0] {H_IDLE, H_CC_REQ, H_CC_RSP, H_FB_REQ, H_FB_RSP, H_LOC} st_t;
  st_t st_q, st_d;

  always_comb begin
    st_d           = st_q;
    host_req_ready = 1'b0;
    host_rsp_valid = 1'b0;
    host_rsp_rdata = 32'd0;
    host_rsp_error = 1'b0;
    cc_req_valid   = 1'b0;
    fab_req_valid  = 1'b0;
    cc_rsp_ready   = 1'b0;
    fab_rsp_ready  = 1'b0;
    dec_err_evt    = 1'b0;
    unique case (st_q)
      H_IDLE: if (host_req_valid) begin
        if (a_cc)       st_d = H_CC_REQ;
        else if (a_fab) st_d = H_FB_REQ;
        else begin                              // outside every die region
          host_req_ready = 1'b1;
          dec_err_evt    = 1'b1;
          st_d           = H_LOC;
        end
      end
      H_CC_REQ: begin
        cc_req_valid   = 1'b1;
        host_req_ready = cc_req_ready;
        if (cc_req_ready) st_d = H_CC_RSP;
      end
      H_CC_RSP: begin
        host_rsp_valid = cc_rsp_valid;
        host_rsp_rdata = cc_rsp_rdata;
        host_rsp_error = cc_rsp_error;
        cc_rsp_ready   = host_rsp_ready;
        if (cc_rsp_valid && host_rsp_ready) st_d = H_IDLE;
      end
      H_FB_REQ: begin
        fab_req_valid  = 1'b1;
        host_req_ready = fab_req_ready;
        if (fab_req_ready) st_d = H_FB_RSP;
      end
      H_FB_RSP: begin
        host_rsp_valid = fab_rsp_valid;
        host_rsp_rdata = fab_rsp_rdata;
        host_rsp_error = fab_rsp_error;
        fab_rsp_ready  = host_rsp_ready;
        if (fab_rsp_valid && host_rsp_ready) st_d = H_IDLE;
      end
      H_LOC: begin
        host_rsp_valid = 1'b1;
        host_rsp_error = 1'b1;
        if (host_rsp_ready) st_d = H_IDLE;
      end
      default: st_d = H_IDLE;
    endcase
  end

  assign cc_req_write  = host_req_write;
  assign cc_req_addr   = host_req_addr;
  assign cc_req_wdata  = host_req_wdata;
  assign cc_req_wstrb  = host_req_wstrb;
  assign fab_req_write = host_req_write;
  assign fab_req_addr  = host_req_addr;
  assign fab_req_wdata = host_req_wdata;
  assign fab_req_wstrb = host_req_wstrb;
  assign dec_err_addr  = host_req_addr;
  assign busy          = (st_q != H_IDLE);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) st_q <= H_IDLE;
    else        st_q <= st_d;
  end
endmodule

`default_nettype wire
