// =============================================================================
// SilicaFlux DieTop :: memory_subsystem -- shared SRAM slices + external-memory bridge
//
//   NoC target SRAM[s] ─► sfmem_banked (MemoryCore, UNMODIFIED; around the SRAM
//                         library's sram_bank_controller) : BANKS_PER_SLICE x 1RW banks
//   NoC target EXT     ─► silicaflux_extmem_bridge (Project 24, UNMODIFIED) data port
//   NoC target EXTCSR  ─► silicaflux_extmem_bridge CSR port
//                         └► SFMC generic memory-controller interface = DIE BOUNDARY
//                            (vendor controller + PHY are NOT part of the die RTL;
//                             simulation uses extmem_sim_mc, SIMULATION ONLY)
//
// Shared SRAM: NSLICES contiguous slices of SRAM_BYTES / NSLICES, slice s at
// SRAM_BASE + s * slice size (the NoC decodes slices; each slice is word-
// interleaved over its banks).  MIN: 1 slice x 4 banks.  HPC: 4 slices x 4 banks
// ("distributed SRAM": each slice is a separate fabric target and placement region).
// Banks are behavioural / generic SRAM unless SRAM_BACKEND selects a macro
// backend; no behavioural model here is a qualified silicon macro.
// Integrity: SRAM_PARITY = 1 stores odd parity per byte (MemoryCore convention);
// SECDED is NOT implemented (reserved for Project 26).
// Initialisation (SRAM_INIT = 1, default): after fabric reset release every
// row of every bank of every slice is written with zero and VALID parity
// through the bank controller's test port (all banks in parallel, one row per
// cycle: exactly BANK_DEPTH cycles, deterministic).  Functional traffic is held
// off meanwhile (the test port blocks it) and mem_ready rises when the sweep
// ends.  Without it a read of a never-written word returns a parity error --
// found when the ControlCore firmware self-test read uninitialised SRAM.
// Clocking: one functional clock.  EXTMEM_ASYNC = 1 selects the bridge's own
// verified CDC to mc_clk (Project 24 extmem_mc_cdc); 0 runs SFMC on clk.
// Classification: SYNTHESIZABLE (new wrapper, Project 31)
// =============================================================================
`include "sram_defs.svh"
`include "sfmem_defs.svh"
`include "extmem_defs.svh"
`default_nettype none

module memory_subsystem #(
  parameter int          NSLICES         = 1,
  parameter int          BANKS_PER_SLICE = 4,
  parameter logic [31:0] SRAM_BASE       = 32'h2000_0000,
  parameter int          SRAM_BYTES      = 1 << 20,
  parameter int          SRAM_PARITY     = 1,
  parameter int          SRAM_RD_LAT     = 1,
  parameter int          SRAM_BACKEND    = `SRAM_BACKEND_GENERIC,
  parameter int          SRAM_INIT       = 1,
  parameter int          EXTMEM_EN       = 0,
  parameter int          EXTMEM_ASYNC    = 0,
  parameter logic [31:0] EXT_BASE        = 32'h3800_0000,
  parameter int          EXT_BYTES       = 32'h0400_0000,
  parameter int          MC_AW           = 26,
  localparam int         MC_TW           = 2        // tag width for MAX_RD_OUT / MAX_WR_OUT = 4
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // shared SRAM slices (SFB2 slaves)
  input  wire logic [NSLICES-1:0]    s_req_valid,
  output logic [NSLICES-1:0]         s_req_ready,
  input  wire logic [NSLICES-1:0]    s_req_write,
  input  wire logic [NSLICES*32-1:0] s_req_addr,
  input  wire logic [NSLICES*32-1:0] s_req_wdata,
  input  wire logic [NSLICES*4-1:0]  s_req_wstrb,
  output logic [NSLICES-1:0]         s_rsp_valid,
  input  wire logic [NSLICES-1:0]    s_rsp_ready,
  output logic [NSLICES*32-1:0]      s_rsp_rdata,
  output logic [NSLICES-1:0]         s_rsp_error,
  // external-memory data window (SFB2 slave; unused when EXTMEM_EN = 0)
  input  wire logic                  x_req_valid,
  output logic                       x_req_ready,
  input  wire logic                  x_req_write,
  input  wire logic [31:0]           x_req_addr,
  input  wire logic [31:0]           x_req_wdata,
  input  wire logic [3:0]            x_req_wstrb,
  output logic                       x_rsp_valid,
  input  wire logic                  x_rsp_ready,
  output logic [31:0]                x_rsp_rdata,
  output logic                       x_rsp_error,
  // external-memory bridge CSR (SFB2 slave)
  input  wire logic                  c_req_valid,
  output logic                       c_req_ready,
  input  wire logic                  c_req_write,
  input  wire logic [31:0]           c_req_addr,
  input  wire logic [31:0]           c_req_wdata,
  input  wire logic [3:0]            c_req_wstrb,
  output logic                       c_rsp_valid,
  input  wire logic                  c_rsp_ready,
  output logic [31:0]                c_rsp_rdata,
  output logic                       c_rsp_error,
  // SFMC memory-controller interface (die boundary)
  input  wire logic                  mc_clk,
  output logic                       mc_rst_n,
  input  wire logic                  mc_init_done,
  input  wire logic                  mc_fatal,
  output logic                       mc_cmd_valid,
  input  wire logic                  mc_cmd_ready,
  output logic                       mc_cmd_write,
  output logic [MC_AW-1:0]           mc_cmd_addr,
  output logic [7:0]                 mc_cmd_len,
  output logic [MC_TW-1:0]           mc_cmd_tag,
  output logic                       mc_wd_valid,
  input  wire logic                  mc_wd_ready,
  output logic [31:0]                mc_wd_data,
  output logic [3:0]                 mc_wd_strb,
  output logic                       mc_wd_last,
  input  wire logic                  mc_rd_valid,
  output logic                       mc_rd_ready,
  input  wire logic [31:0]           mc_rd_data,
  input  wire logic [MC_TW-1:0]      mc_rd_tag,
  input  wire logic                  mc_rd_last,
  input  wire logic                  mc_rd_error,
  input  wire logic                  mc_wr_valid,
  output logic                       mc_wr_ready,
  input  wire logic [MC_TW-1:0]      mc_wr_tag,
  input  wire logic                  mc_wr_error,
  // status / events
  output logic                       mem_ready,      // SRAM initialisation complete
  output logic                       sram_busy,
  output logic                       par_evt,
  output logic [31:0]                par_addr,
  output logic                       ext_ready,      // link up (1 when EXTMEM_EN = 0)
  output logic                       ext_idle,
  output logic                       ext_fault,      // sticky fault / calibration failure seen
  output logic                       ext_err_evt,
  output logic [31:0]                ext_err_addr
);
  localparam int SLICE_BYTES = SRAM_BYTES / NSLICES;
  localparam int ECC         = (SRAM_PARITY != 0) ? `SFMEM_ECC_PARITY : `SFMEM_ECC_NONE;
  localparam int SW          = (ECC == `SFMEM_ECC_PARITY) ? 36 : 32;
  localparam int BANK_DEPTH  = SLICE_BYTES / 4 / BANKS_PER_SLICE;
  localparam int RAW         = (BANK_DEPTH > 1) ? $clog2(BANK_DEPTH) : 1;

  // ---------------------------------------------------------------- SRAM initialisation sweep
  localparam logic [SW-1:0] ZERO_WORD = (ECC == `SFMEM_ECC_PARITY) ? {4{9'h100}} : '0;   // {odd parity, 8'h00} per lane
  logic           init_q;
  logic [RAW-1:0] row_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      init_q <= (SRAM_INIT != 0);
      row_q  <= '0;
    end else if (init_q) begin
      if (row_q == RAW'(BANK_DEPTH - 1)) init_q <= 1'b0;
      row_q <= row_q + 1'b1;
    end
  end
  assign mem_ready = !init_q;

  // ---------------------------------------------------------------- shared SRAM slices
  logic [NSLICES-1:0]    sl_busy, sl_par;
  logic [NSLICES*32-1:0] sl_par_addr;
  for (genvar s = 0; s < NSLICES; s++) begin : g_slice
    /* verilator lint_off UNUSEDSIGNAL */
    logic                     inj_ack_u;
    logic [3:0]               par_syn_u;
    logic [2:0]               par_port_u;
    logic                     ev_acc_u, ev_conf_u;
    logic [BANKS_PER_SLICE-1:0] ev_bank_u;
    logic [5:0]               ev_rd_u, ev_wr_u;
    logic [BANKS_PER_SLICE*SW-1:0] tst_rdata_u;
    /* verilator lint_on UNUSEDSIGNAL */
    sfmem_banked #(
      .NP(1), .BYTES(SLICE_BYTES), .BANKS(BANKS_PER_SLICE), .RD_LAT(SRAM_RD_LAT), .ECC_MODE(ECC),
      .BACKEND(SRAM_BACKEND), .BASE(SRAM_BASE + 32'(s) * 32'(SLICE_BYTES))
    ) u_sram (
      .clk, .rst_n,
      .p_req_valid(s_req_valid[s]), .p_req_ready(s_req_ready[s]), .p_req_write(s_req_write[s]),
      .p_req_addr(s_req_addr[s*32 +: 32]), .p_req_wdata(s_req_wdata[s*32 +: 32]), .p_req_wstrb(s_req_wstrb[s*4 +: 4]),
      .p_rsp_valid(s_rsp_valid[s]), .p_rsp_ready(s_rsp_ready[s]), .p_rsp_rdata(s_rsp_rdata[s*32 +: 32]),
      .p_rsp_error(s_rsp_error[s]),
      .chk_dis(1'b0), .inj_req(1'b0), .inj_lanes(4'd0), .inj_ack(inj_ack_u),
      .par_evt(sl_par[s]), .par_syn(par_syn_u), .par_addr(sl_par_addr[s*32 +: 32]), .par_port(par_port_u),
      .ev_acc(ev_acc_u), .ev_conf(ev_conf_u), .ev_bank(ev_bank_u), .ev_rd_bytes(ev_rd_u), .ev_wr_bytes(ev_wr_u),
      .tst_active(init_q), .tst_sel({BANKS_PER_SLICE{1'b1}}), .tst_ce(init_q), .tst_we(1'b1), .tst_addr(row_q),
      .tst_wdata(ZERO_WORD),
      .tst_rdata(tst_rdata_u), .busy(sl_busy[s]));
  end
  assign sram_busy = |sl_busy;
  assign par_evt   = |sl_par;
  always_comb begin
    par_addr = 32'd0;
    for (int s = 0; s < NSLICES; s++) if (sl_par[s]) par_addr = sl_par_addr[s*32 +: 32];
  end

  // ---------------------------------------------------------------- external-memory bridge
  if (EXTMEM_EN != 0) begin : g_ext
    /* verilator lint_off UNUSEDSIGNAL */
    logic [0:0]  up_rsp_id_u;
    logic        up_rsp_last_u, up_rsp_write_u;
    logic [2:0]  st_state_u;
    logic        st_fault_u, err_write_u;
    logic [3:0]  err_code_u;
    logic [0:0]  err_id_u;
    logic [`XM_PERF_N*32-1:0] perf_u;
    /* verilator lint_on UNUSEDSIGNAL */
    logic st_ready, st_cal_fail, st_idle;
    silicaflux_extmem_bridge #(
      .AW(32), .DW(32), .IDW(1), .LW(8), .MAX_BURST(8), .MAX_RD_OUT(4), .MAX_WR_OUT(4), .MC_AW(MC_AW),
      .EXT_BASE(EXT_BASE), .EXT_SIZE(33'(EXT_BYTES)), .ASYNC(EXTMEM_ASYNC), .PERF(1)
    ) u_bridge (
      .clk, .rst_n, .mc_clk,
      .up_req_valid(x_req_valid), .up_req_ready(x_req_ready), .up_req_write(x_req_write), .up_req_addr(x_req_addr),
      .up_req_wdata(x_req_wdata), .up_req_wstrb(x_req_wstrb), .up_req_id(1'b0), .up_req_len(8'd0), .up_req_last(1'b1),
      .up_rsp_valid(x_rsp_valid), .up_rsp_ready(x_rsp_ready), .up_rsp_rdata(x_rsp_rdata), .up_rsp_error(x_rsp_error),
      .up_rsp_id(up_rsp_id_u), .up_rsp_last(up_rsp_last_u), .up_rsp_write(up_rsp_write_u),
      .csr_req_valid(c_req_valid), .csr_req_ready(c_req_ready), .csr_req_write(c_req_write), .csr_req_addr(c_req_addr),
      .csr_req_wdata(c_req_wdata), .csr_req_wstrb(c_req_wstrb), .csr_rsp_valid(c_rsp_valid), .csr_rsp_ready(c_rsp_ready),
      .csr_rsp_rdata(c_rsp_rdata), .csr_rsp_error(c_rsp_error),
      .mc_rst_n, .mc_init_done, .mc_fatal,
      .mc_cmd_valid, .mc_cmd_ready, .mc_cmd_write, .mc_cmd_addr, .mc_cmd_len, .mc_cmd_tag,
      .mc_wd_valid, .mc_wd_ready, .mc_wd_data, .mc_wd_strb, .mc_wd_last,
      .mc_rd_valid, .mc_rd_ready, .mc_rd_data, .mc_rd_tag, .mc_rd_last, .mc_rd_error,
      .mc_wr_valid, .mc_wr_ready, .mc_wr_tag, .mc_wr_error,
      .ctl_mc_reset_req(1'b0),
      .st_state(st_state_u), .st_ready, .st_cal_fail, .st_fault_seen(st_fault_u), .st_idle,
      .err_evt(ext_err_evt), .err_code(err_code_u), .err_addr(ext_err_addr), .err_id(err_id_u), .err_write(err_write_u),
      .perf_cnt(perf_u));
    assign ext_ready = st_ready;
    assign ext_idle  = st_idle;
    assign ext_fault = st_cal_fail || st_fault_u;
  end else begin : g_no_ext
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_ext = x_req_valid ^ x_req_write ^ ^x_req_addr ^ ^x_req_wdata ^ ^x_req_wstrb ^ x_rsp_ready ^
                      c_req_valid ^ c_req_write ^ ^c_req_addr ^ ^c_req_wdata ^ ^c_req_wstrb ^ c_rsp_ready ^
                      mc_clk ^ mc_init_done ^ mc_fatal ^ mc_cmd_ready ^ mc_wd_ready ^ mc_rd_valid ^ ^mc_rd_data ^
                      ^mc_rd_tag ^ mc_rd_last ^ mc_rd_error ^ mc_wr_valid ^ ^mc_wr_tag ^ mc_wr_error;
    /* verilator lint_on UNUSEDSIGNAL */
    assign x_req_ready = 1'b0;  assign x_rsp_valid = 1'b0;  assign x_rsp_rdata = '0;  assign x_rsp_error = 1'b0;
    assign c_req_ready = 1'b0;  assign c_rsp_valid = 1'b0;  assign c_rsp_rdata = '0;  assign c_rsp_error = 1'b0;
    assign mc_rst_n = 1'b0;     assign mc_cmd_valid = 1'b0; assign mc_cmd_write = 1'b0; assign mc_cmd_addr = '0;
    assign mc_cmd_len = '0;     assign mc_cmd_tag = '0;     assign mc_wd_valid = 1'b0;  assign mc_wd_data = '0;
    assign mc_wd_strb = '0;     assign mc_wd_last = 1'b0;   assign mc_rd_ready = 1'b0;  assign mc_wr_ready = 1'b0;
    assign ext_ready = 1'b1;    assign ext_idle = 1'b1;     assign ext_fault = 1'b0;
    assign ext_err_evt = 1'b0;  assign ext_err_addr = '0;
  end
endmodule

`default_nettype wire
