// =============================================================================
// SilicaFlux DieTop :: die_sysctrl -- DIE_SYS sub-blocks CTRL (0x000) and IRQ (0x100)
//
// SilicaFlux-V register-bus slave (one-cycle rb_sel strobe, combinational
// read data / error, write at the end of the strobe).  Unmapped offsets, sub-word
// semantics aside (the ControlCore bridge refuses sub-word writes), and writes
// to read-only registers answer rb_err.  Offsets: silicaflux_die_pkg (generated).
//
// Readiness: PLATFORM_READY = RESET_DONE & FABRIC_READY & MEM_READY &
// EXTMEM_READY & CC_RUNNING & COMPUTE_READY; DEVICE_READY = PLATFORM_READY &
// FW_HOST_READY (ControlCore firmware HOST_READY pin).  Both are registered and
// drive the device_ready_o pin (DEVICE_READY).  PLATFORM_CYC / DEVICE_CYC freeze at
// the first cycle each condition held (deterministic boot measurement in cycles,
// counted from fabric reset release).
// Interrupts: every source is a level; host_irq = (IRQ_RAW & IRQ_HOST_EN) != 0 OR
// the ControlCore mailbox doorbell; the ControlCore's VECTOR / TENSOR interrupt
// inputs are (IRQ_RAW & IRQ_CC_VEC_EN) / (IRQ_RAW & IRQ_CC_TSU_EN).
// Classification: SYNTHESIZABLE (new, Project 31)
// =============================================================================
`default_nettype none

module die_sysctrl
#(
  parameter int          CONFIG_ID    = 1,
  parameter int          NV           = 1,
  parameter int          NT           = 1,
  parameter int          ND           = 1,
  parameter int          NBANKS       = 4,
  parameter int          NSLICES      = 1,
  parameter int          SRAM_BYTES   = 1 << 20,
  parameter int          NOC_TOPOLOGY = 0,
  parameter int          EXTMEM_EN    = 0,
  parameter int          EXTMEM_ASYNC = 0,
  parameter int          TESTCORE_EN  = 0,
  parameter int          SRAM_PARITY  = 1,
  parameter int          NOC_NM       = 4,
  parameter int          NOC_NT       = 2,
  parameter int          TSU_ROWS     = 4,
  parameter int          TSU_COLS     = 4,
  parameter int          VEC_LANES    = 4
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          rb_sel,
  input  wire logic          rb_we,
  input  wire logic [11:0]   rb_addr,
  input  wire logic [31:0]   rb_wdata,
  output logic [31:0]        rb_rdata,
  output logic               rb_err,
  // readiness inputs
  input  wire logic [2:0]    rst_stage,
  input  wire logic          reset_done,
  input  wire logic          mem_ready,
  input  wire logic          extmem_ready,
  input  wire logic          cc_running,
  input  wire logic          compute_ready,
  input  wire logic          fw_host_ready,
  // busy
  input  wire logic [NV-1:0] vec_busy,
  input  wire logic [NT-1:0] tsu_busy,
  input  wire logic [ND-1:0] dma_busy,
  input  wire logic          extmem_busy,
  // interrupt sources (levels)
  input  wire logic [NV-1:0] vec_irq,
  input  wire logic [NT-1:0] tsu_irq,
  input  wire logic [ND-1:0] dma_irq,
  input  wire logic          die_err_irq,
  input  wire logic          noc_err_irq,
  input  wire logic          extmem_irq,
  input  wire logic          cc_host_irq,
  // outputs
  output logic               host_irq,
  output logic               cc_vec_irq,
  output logic               cc_tsu_irq,
  output logic               platform_ready,
  output logic               device_ready,
  output logic [31:0]        irq_raw
);

  // ---------------------------------------------------------------- constants
  localparam logic [31:0] CFG0 = 32'(NV) | (32'(NT) << 4) | (32'(NBANKS) << 8) | (32'(NSLICES) << 16) |
                                 (32'(ND) << 20) | (32'(NOC_TOPOLOGY) << 24) | (32'(EXTMEM_EN != 0) << 26) |
                                 (32'(EXTMEM_ASYNC != 0) << 27) | (32'(TESTCORE_EN != 0) << 28) |
                                 (32'(SRAM_PARITY != 0) << 29);
  localparam logic [31:0] VEC_MASK = 32'((64'd1 << NV) - 1) << silicaflux_die_pkg::DIE_IRQ_VEC;
  localparam logic [31:0] TSU_MASK = 32'((64'd1 << NT) - 1) << silicaflux_die_pkg::DIE_IRQ_TSU;

  // ---------------------------------------------------------------- IRQ_RAW
  always_comb begin
    irq_raw = 32'd0;
    for (int i = 0; i < NV; i++) irq_raw[silicaflux_die_pkg::DIE_IRQ_VEC + i] = vec_irq[i];
    for (int j = 0; j < NT; j++) irq_raw[silicaflux_die_pkg::DIE_IRQ_TSU + j] = tsu_irq[j];
    for (int c = 0; c < ND; c++) irq_raw[silicaflux_die_pkg::DIE_IRQ_DMA + c] = dma_irq[c];
    irq_raw[silicaflux_die_pkg::DIE_IRQ_DIE_ERR] = die_err_irq;
    irq_raw[silicaflux_die_pkg::DIE_IRQ_NOC_ERR] = noc_err_irq;
    irq_raw[silicaflux_die_pkg::DIE_IRQ_EXTMEM]  = extmem_irq;
    irq_raw[silicaflux_die_pkg::DIE_IRQ_CC_HOST] = cc_host_irq;
  end

  // ---------------------------------------------------------------- registers
  logic [31:0] scratch_q, host_en_q, cc_vec_en_q, cc_tsu_en_q, plat_cyc_q, dev_cyc_q;
  logic        plat_q, dev_q;
  wire  wr = rb_sel && rb_we;
  wire  plat_now = reset_done && mem_ready && extmem_ready && cc_running && compute_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      scratch_q   <= 32'd0;
      host_en_q   <= 32'd0;
      cc_vec_en_q <= VEC_MASK;
      cc_tsu_en_q <= TSU_MASK;
      plat_cyc_q  <= 32'd0;
      dev_cyc_q   <= 32'd0;
      plat_q      <= 1'b0;
      dev_q       <= 1'b0;
    end else begin
      plat_q <= plat_now;
      dev_q  <= plat_now && fw_host_ready;
      if (!plat_q && plat_cyc_q != 32'hFFFF_FFFF) plat_cyc_q <= plat_cyc_q + 32'd1;
      if (!dev_q  && dev_cyc_q  != 32'hFFFF_FFFF) dev_cyc_q  <= dev_cyc_q + 32'd1;
      if (wr) begin
        unique case (rb_addr)
          silicaflux_die_pkg::DIE_SYS_SCRATCH:       scratch_q   <= rb_wdata;
          silicaflux_die_pkg::DIE_SYS_IRQ_HOST_EN:   host_en_q   <= rb_wdata;
          silicaflux_die_pkg::DIE_SYS_IRQ_CC_VEC_EN: cc_vec_en_q <= rb_wdata;
          silicaflux_die_pkg::DIE_SYS_IRQ_CC_TSU_EN: cc_tsu_en_q <= rb_wdata;
          default: ;
        endcase
      end
    end
  end

  wire [31:0] status = (32'(reset_done)    << silicaflux_die_pkg::DIE_ST_RESET_DONE)    | (32'(1'b1)          << silicaflux_die_pkg::DIE_ST_FABRIC_READY) |
                       (32'(mem_ready)     << silicaflux_die_pkg::DIE_ST_MEM_READY)     | (32'(extmem_ready)  << silicaflux_die_pkg::DIE_ST_EXTMEM_READY) |
                       (32'(cc_running)    << silicaflux_die_pkg::DIE_ST_CC_RUNNING)    | (32'(compute_ready) << silicaflux_die_pkg::DIE_ST_COMPUTE_READY) |
                       (32'(fw_host_ready) << silicaflux_die_pkg::DIE_ST_FW_HOST_READY) | (32'(plat_q)        << silicaflux_die_pkg::DIE_ST_PLATFORM_READY) |
                       (32'(dev_q)         << silicaflux_die_pkg::DIE_ST_DEVICE_READY);
  wire [31:0] busy_w = 32'(vec_busy) | (32'(tsu_busy) << 4) | (32'(dma_busy) << 8) | (32'(extmem_busy) << 12);

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    unique case (rb_addr)
      silicaflux_die_pkg::DIE_SYS_ID:              rb_rdata = silicaflux_die_pkg::DIE_ID;
      silicaflux_die_pkg::DIE_SYS_HW_VERSION:      rb_rdata = silicaflux_die_pkg::DIE_HW_VERSION;
      silicaflux_die_pkg::DIE_SYS_MAP_VERSION:     rb_rdata = silicaflux_die_pkg::DIE_MAP_VERSION;
      silicaflux_die_pkg::DIE_SYS_CONFIG_ID:       rb_rdata = 32'(CONFIG_ID);
      silicaflux_die_pkg::DIE_SYS_CFG0:            rb_rdata = CFG0;
      silicaflux_die_pkg::DIE_SYS_SRAM_BYTES:      rb_rdata = 32'(SRAM_BYTES);
      silicaflux_die_pkg::DIE_SYS_TSU_ARRAY:       rb_rdata = 32'(TSU_ROWS) | (32'(TSU_COLS) << 8) | (32'(VEC_LANES) << 16);
      silicaflux_die_pkg::DIE_SYS_FABRIC:          rb_rdata = 32'(NOC_NM) | (32'(NOC_NT) << 8);
      silicaflux_die_pkg::DIE_SYS_RESET_STAGE:     rb_rdata = 32'(rst_stage);
      silicaflux_die_pkg::DIE_SYS_STATUS:          rb_rdata = status;
      silicaflux_die_pkg::DIE_SYS_SCRATCH:         rb_rdata = scratch_q;
      silicaflux_die_pkg::DIE_SYS_PLATFORM_CYC:    rb_rdata = plat_cyc_q;
      silicaflux_die_pkg::DIE_SYS_DEVICE_CYC:      rb_rdata = dev_cyc_q;
      silicaflux_die_pkg::DIE_SYS_BUSY:            rb_rdata = busy_w;
      silicaflux_die_pkg::DIE_SYS_IRQ_RAW:         rb_rdata = irq_raw;
      silicaflux_die_pkg::DIE_SYS_IRQ_HOST_EN:     rb_rdata = host_en_q;
      silicaflux_die_pkg::DIE_SYS_IRQ_HOST_STATUS: rb_rdata = irq_raw & host_en_q;
      silicaflux_die_pkg::DIE_SYS_IRQ_CC_VEC_EN:   rb_rdata = cc_vec_en_q;
      silicaflux_die_pkg::DIE_SYS_IRQ_CC_TSU_EN:   rb_rdata = cc_tsu_en_q;
      default:                 rb_err   = rb_sel;
    endcase
    // writes to read-only registers are refused
    if (rb_sel && rb_we && !(rb_addr == silicaflux_die_pkg::DIE_SYS_SCRATCH || rb_addr == silicaflux_die_pkg::DIE_SYS_IRQ_HOST_EN ||
                             rb_addr == silicaflux_die_pkg::DIE_SYS_IRQ_CC_VEC_EN || rb_addr == silicaflux_die_pkg::DIE_SYS_IRQ_CC_TSU_EN))
      rb_err = 1'b1;
  end

  assign host_irq       = |(irq_raw & host_en_q) || cc_host_irq;
  assign cc_vec_irq     = |(irq_raw & cc_vec_en_q);
  assign cc_tsu_irq     = |(irq_raw & cc_tsu_en_q);
  assign platform_ready = plat_q;
  assign device_ready   = dev_q;
endmodule

`default_nettype wire
