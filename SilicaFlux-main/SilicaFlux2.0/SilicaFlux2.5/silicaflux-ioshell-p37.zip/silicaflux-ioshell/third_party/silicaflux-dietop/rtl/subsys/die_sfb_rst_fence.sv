// =============================================================================
// SilicaFlux DieTop :: die_sfb_rst_fence -- SFB2 master-side reset fence for a
// master in the resettable accelerator domain (tile DMA, tensor-unit DMA) or the
// ControlCore external port
//
//   master (domain reset dom_rst_n) ─► die_sfb_rst_fence ─► NoC SFB2 master bridge (fabric reset)
//
// The NoC and the shared memories stay alive when the ControlCore resets the
// accelerator domain (PMU ACC_CTRL.RST, soft / watchdog / host reset).  Without
// a fence, a response to a transaction issued before that reset would be
// delivered to the freshly reset master as the answer to its NEXT request.
// The fence:
//   * counts transactions accepted by the fabric and not yet answered;
//   * keeps presenting a request that was presented but not yet accepted when
//     the domain went into reset (SFB2 R2: never withdrawn), from a registered
//     copy, so the fabric never sees a withdrawn request;
//   * while the domain is in reset, and after release until every orphan was
//     answered, sinks (drains) the fabric's responses and holds new requests
//     off (req_ready = 0), so a reset master can never see a stale response;
//   * passes everything through combinationally otherwise (no added latency).
// MAXO bounds the counter (the master's own outstanding limit; the NoC's
// MST_MAXO for the port must be >= it).
// Classification: SYNTHESIZABLE (new, Project 31)
// =============================================================================
`default_nettype none

module die_sfb_rst_fence #(
  parameter int MAXO = 4
) (
  input  wire logic        clk,
  input  wire logic        rst_n,          // fabric reset
  input  wire logic        dom_rst_n,      // master-domain reset, synchronous to clk
  // from the master
  input  wire logic        s_req_valid,
  output logic             s_req_ready,
  input  wire logic        s_req_write,
  input  wire logic [31:0] s_req_addr,
  input  wire logic [31:0] s_req_wdata,
  input  wire logic [3:0]  s_req_wstrb,
  output logic             s_rsp_valid,
  input  wire logic        s_rsp_ready,
  output logic [31:0]      s_rsp_rdata,
  output logic             s_rsp_error,
  // to the fabric
  output logic             m_req_valid,
  input  wire logic        m_req_ready,
  output logic             m_req_write,
  output logic [31:0]      m_req_addr,
  output logic [31:0]      m_req_wdata,
  output logic [3:0]       m_req_wstrb,
  input  wire logic        m_rsp_valid,
  output logic             m_rsp_ready,
  input  wire logic [31:0] m_rsp_rdata,
  input  wire logic        m_rsp_error,
  // status
  output logic             drained_evt,    // pulse: an orphan response was drained
  output logic             fenced,         // drain / hold-off mode active
  output logic             idle            // nothing outstanding, nothing held
);
  localparam int CW = $clog2(MAXO + 2);
  logic [CW-1:0] cnt_q;
  logic          drain_q, hold_q, hw_q;
  logic [31:0]   ha_q, hd_q;
  logic [3:0]    hs_q;

  // drain mode: domain in reset, or released while orphans / a held request remain
  wire drain = !dom_rst_n || drain_q;

  always_comb begin
    if (!drain) begin
      m_req_valid = s_req_valid;
      m_req_write = s_req_write;
      m_req_addr  = s_req_addr;
      m_req_wdata = s_req_wdata;
      m_req_wstrb = s_req_wstrb;
      s_req_ready = m_req_ready;
      s_rsp_valid = m_rsp_valid;
      s_rsp_rdata = m_rsp_rdata;
      s_rsp_error = m_rsp_error;
      m_rsp_ready = s_rsp_ready;
    end else begin
      m_req_valid = hold_q;                    // finish presenting a held request only
      m_req_write = hw_q;
      m_req_addr  = ha_q;
      m_req_wdata = hd_q;
      m_req_wstrb = hs_q;
      s_req_ready = 1'b0;
      s_rsp_valid = 1'b0;
      s_rsp_rdata = 32'd0;
      s_rsp_error = 1'b0;
      m_rsp_ready = 1'b1;                      // sink orphans
    end
  end

  wire req_hs = m_req_valid && m_req_ready;
  wire rsp_hs = m_rsp_valid && m_rsp_ready;
  assign drained_evt = drain && rsp_hs;
  assign fenced      = drain;
  assign idle        = (cnt_q == '0) && !hold_q && !m_req_valid;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cnt_q   <= '0;
      drain_q <= 1'b0;
      hold_q  <= 1'b0;
      hw_q    <= 1'b0;
      ha_q    <= '0;
      hd_q    <= '0;
      hs_q    <= '0;
    end else begin
      cnt_q <= cnt_q + CW'(req_hs) - CW'(rsp_hs);
      // a presented, not yet accepted request is remembered (it must not be withdrawn)
      hold_q <= m_req_valid && !m_req_ready;
      if (m_req_valid && !m_req_ready) begin
        hw_q <= m_req_write;
        ha_q <= m_req_addr;
        hd_q <= m_req_wdata;
        hs_q <= m_req_wstrb;
      end
      // enter drain mode with the domain reset; leave once released and clean
      if (!dom_rst_n)
        drain_q <= 1'b1;
      else if (drain_q && (cnt_q + CW'(req_hs) - CW'(rsp_hs)) == '0 && !(m_req_valid && !m_req_ready))
        drain_q <= 1'b0;
    end
  end

`ifndef SYNTHESIS
  // the counter can never exceed the master's own limit (simulation check; samples rst_n synchronously)
  /* verilator lint_off SYNCASYNCNET */
  always @(posedge clk) if (rst_n && cnt_q > CW'(MAXO))
    $error("die_sfb_rst_fence: %0d outstanding > MAXO %0d", cnt_q, MAXO);
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
