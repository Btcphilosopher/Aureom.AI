// =============================================================================
// SilicaFlux DieTop :: control_subsystem -- the ControlCore
//
//   silicaflux_control_core (Project 21, UNMODIFIED): RV32IM_Zicsr CPU, boot ROM,
//   64 KiB IMEM / 32 KiB DMEM (parity), SFB2 crossbar, INTC, timer, watchdog,
//   system DMA, mailbox (host interface), perf counters, PMU (accelerator clock
//   gate / reset / isolation), RAS, security status.
//   ext_* (SFB2 master, EXT window) ─► die_sfb_rst_fence ─► NoC master CC
//   acc_rb_* (pages 8..15)          ─► die_rb_decode (in the die top)
//   acc_clk_o / acc_rst_no          ─► compute_subsystem clock and reset
//
// The fence on the external port uses the accelerator reset (acc_rst_no), which
// is asserted whenever the ControlCore's system reset is (soft / watchdog / host
// / die reset) and by PMU ACC_CTRL.RST (applied only once the external port is
// idle, with isolation blocking new requests): an orphan fabric response can
// never be delivered to a freshly reset ControlCore.
// Classification: SYNTHESIZABLE (new wrapper, Project 31)
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module control_subsystem #(
  parameter int SRAM_BACKEND = `SRAM_BACKEND_GENERIC
) (
  input  wire logic        clk,
  input  wire logic        cc_rst_n,
  input  wire logic        fab_rst_n,
  input  wire logic        test_mode,
  input  wire logic [1:0]  boot_mode,
  input  wire logic        host_rst_req,
  // host access port (SFB2 slave)
  input  wire logic        hs_req_valid,
  output logic             hs_req_ready,
  input  wire logic        hs_req_write,
  input  wire logic [31:0] hs_req_addr,
  input  wire logic [31:0] hs_req_wdata,
  input  wire logic [3:0]  hs_req_wstrb,
  output logic             hs_rsp_valid,
  input  wire logic        hs_rsp_ready,
  output logic [31:0]      hs_rsp_rdata,
  output logic             hs_rsp_error,
  output logic             host_irq,
  output logic             host_ready,
  output logic             cmdproc_ready,
  output logic             ras_fatal,
  // die register port (pages 8..15)
  output logic             rb_sel,
  output logic             rb_we,
  output logic [15:0]      rb_addr,
  output logic [31:0]      rb_wdata,
  input  wire logic [31:0] rb_rdata,
  input  wire logic        rb_err,
  // external data port (SFB2 master, fenced) -> NoC
  output logic             x_req_valid,
  input  wire logic        x_req_ready,
  output logic             x_req_write,
  output logic [31:0]      x_req_addr,
  output logic [31:0]      x_req_wdata,
  output logic [3:0]       x_req_wstrb,
  input  wire logic        x_rsp_valid,
  output logic             x_rsp_ready,
  input  wire logic [31:0] x_rsp_rdata,
  input  wire logic        x_rsp_error,
  // accelerator domain
  output logic             acc_clk,
  output logic             acc_rst_n,
  input  wire logic        acc_vec_irq,
  input  wire logic        acc_tsu_irq,
  input  wire logic        acc_vec_busy,
  input  wire logic        acc_tsu_busy,
  input  wire logic        acc_tsu_halted,
  // RAS
  input  wire logic        ext_warn,
  input  wire logic        ext_fatal,
  // diagnostics
  output logic             diag_valid,
  output logic [7:0]       diag_char,
  output logic             test_done,
  output logic             test_fail,
  output logic [15:0]      test_code,
  output logic             cpu_sleep,
  output logic             fence_drained_evt
);
  logic        e_req_valid, e_req_ready, e_req_write, e_rsp_valid, e_rsp_ready, e_rsp_error;
  logic [31:0] e_req_addr, e_req_wdata, e_rsp_rdata;
  logic [3:0]  e_req_wstrb;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        fence_on_u, fence_idle_u;
  /* verilator lint_on UNUSEDSIGNAL */

  silicaflux_control_core #(.RV32M(1), .SRAM_PARITY(1), .SRAM_BACKEND(SRAM_BACKEND)) u_cc (
    .clk, .rst_ni(cc_rst_n), .test_mode, .boot_mode_i(boot_mode), .host_rst_req_i(host_rst_req),
    .hs_req_valid, .hs_req_ready, .hs_req_write, .hs_req_addr, .hs_req_wdata, .hs_req_wstrb,
    .hs_rsp_valid, .hs_rsp_ready, .hs_rsp_rdata, .hs_rsp_error,
    .host_irq_o(host_irq), .host_ready_o(host_ready), .cmdproc_ready_o(cmdproc_ready), .ras_fatal_o(ras_fatal),
    .acc_rb_sel(rb_sel), .acc_rb_we(rb_we), .acc_rb_addr(rb_addr), .acc_rb_wdata(rb_wdata),
    .acc_rb_rdata(rb_rdata), .acc_rb_err(rb_err),
    .ext_req_valid(e_req_valid), .ext_req_ready(e_req_ready), .ext_req_write(e_req_write), .ext_req_addr(e_req_addr),
    .ext_req_wdata(e_req_wdata), .ext_req_wstrb(e_req_wstrb), .ext_rsp_valid(e_rsp_valid), .ext_rsp_ready(e_rsp_ready),
    .ext_rsp_rdata(e_rsp_rdata), .ext_rsp_error(e_rsp_error),
    .acc_clk_o(acc_clk), .acc_rst_no(acc_rst_n),
    .acc_vec_irq_i(acc_vec_irq), .acc_tsu_irq_i(acc_tsu_irq), .acc_vec_busy_i(acc_vec_busy),
    .acc_tsu_busy_i(acc_tsu_busy), .acc_tsu_halted_i(acc_tsu_halted),
    .ext_warn_i(ext_warn), .ext_fatal_i(ext_fatal),
    .diag_valid_o(diag_valid), .diag_char_o(diag_char), .test_done_o(test_done), .test_fail_o(test_fail),
    .test_code_o(test_code), .cpu_sleep_o(cpu_sleep));

  die_sfb_rst_fence #(.MAXO(1)) u_ext_fence (
    .clk, .rst_n(fab_rst_n), .dom_rst_n(acc_rst_n),
    .s_req_valid(e_req_valid), .s_req_ready(e_req_ready), .s_req_write(e_req_write), .s_req_addr(e_req_addr),
    .s_req_wdata(e_req_wdata), .s_req_wstrb(e_req_wstrb), .s_rsp_valid(e_rsp_valid), .s_rsp_ready(e_rsp_ready),
    .s_rsp_rdata(e_rsp_rdata), .s_rsp_error(e_rsp_error),
    .m_req_valid(x_req_valid), .m_req_ready(x_req_ready), .m_req_write(x_req_write), .m_req_addr(x_req_addr),
    .m_req_wdata(x_req_wdata), .m_req_wstrb(x_req_wstrb), .m_rsp_valid(x_rsp_valid), .m_rsp_ready(x_rsp_ready),
    .m_rsp_rdata(x_rsp_rdata), .m_rsp_error(x_rsp_error),
    .drained_evt(fence_drained_evt), .fenced(fence_on_u), .idle(fence_idle_u));
endmodule

`default_nettype wire
