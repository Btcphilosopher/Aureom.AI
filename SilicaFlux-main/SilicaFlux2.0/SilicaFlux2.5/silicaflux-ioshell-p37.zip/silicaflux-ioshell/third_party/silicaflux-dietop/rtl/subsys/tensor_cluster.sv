// =============================================================================
// SilicaFlux DieTop :: tensor_cluster -- one INT8 tensor compute region
//
//   rb page ─► silicaflux_tensor_unit (TENSORCORE 08, UNMODIFIED: 4x4 systolic
//              array, operand / output buffers, accumulator, quantiser, DMA adapter)
//   tensor DMA m_* ─► die_sfb_rst_fence ─► NoC master
//
// The tensor unit's legal memory window [MEM_LO, MEM_HI) is the shared SRAM;
// its own descriptor validation rejects anything else (TSU_E_RANGE), and the
// NoC access matrix gives it the shared SRAM only.
// Classification: SYNTHESIZABLE (new wrapper, Project 31)
// =============================================================================
`include "tsu_defs.svh"
`default_nettype none

module tensor_cluster #(
  parameter logic [32:0] MEM_LO     = 33'h0_2000_0000,
  parameter logic [32:0] MEM_HI     = 33'h0_2010_0000,
  parameter int          TSU_QUANT  = 1,
  parameter int          TSU_DBUF   = 1,
  parameter int          TSU_MAXOUT = 4,
  parameter int          SRAM_BACKEND = `SRAM_BACKEND_GENERIC
) (
  input  wire logic        clk,
  input  wire logic        fab_rst_n,
  input  wire logic        acc_clk,
  input  wire logic        acc_rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  output logic             dma_req_valid,
  input  wire logic        dma_req_ready,
  output logic             dma_req_write,
  output logic [31:0]      dma_req_addr,
  output logic [31:0]      dma_req_wdata,
  output logic [3:0]       dma_req_wstrb,
  input  wire logic        dma_rsp_valid,
  output logic             dma_rsp_ready,
  input  wire logic [31:0] dma_rsp_rdata,
  input  wire logic        dma_rsp_error,
  output logic             irq,
  output logic             busy,
  output logic             halted,
  output logic             fence_drained_evt
);
  logic        t_req_valid, t_req_ready, t_req_write, t_rsp_valid, t_rsp_ready, t_rsp_error;
  logic [31:0] t_req_addr, t_req_wdata, t_rsp_rdata;
  logic [3:0]  t_req_wstrb;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [`TSU_NUM_PC*32-1:0] perf_ev_u;
  logic        fence_on_u, fence_idle_u;
  /* verilator lint_on UNUSEDSIGNAL */

  silicaflux_tensor_unit #(
    .ENABLE_QUANTIZATION(TSU_QUANT), .ENABLE_DOUBLE_BUFFERING(TSU_DBUF), .MAX_OUT(TSU_MAXOUT),
    .MEM_LO(MEM_LO), .MEM_HI(MEM_HI), .MEM_BACKEND(SRAM_BACKEND)
  ) u_tsu (
    .clk(acc_clk), .rst_n(acc_rst_n),
    .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .m_req_valid(t_req_valid), .m_req_ready(t_req_ready), .m_req_write(t_req_write), .m_req_addr(t_req_addr),
    .m_req_wdata(t_req_wdata), .m_req_wstrb(t_req_wstrb), .m_rsp_valid(t_rsp_valid), .m_rsp_ready(t_rsp_ready),
    .m_rsp_rdata(t_rsp_rdata), .m_rsp_error(t_rsp_error),
    .irq, .busy, .halted, .perf_ev(perf_ev_u), .fi_mode(2'd0));

  die_sfb_rst_fence #(.MAXO(TSU_MAXOUT)) u_dma_fence (
    .clk, .rst_n(fab_rst_n), .dom_rst_n(acc_rst_n),
    .s_req_valid(t_req_valid), .s_req_ready(t_req_ready), .s_req_write(t_req_write), .s_req_addr(t_req_addr),
    .s_req_wdata(t_req_wdata), .s_req_wstrb(t_req_wstrb), .s_rsp_valid(t_rsp_valid), .s_rsp_ready(t_rsp_ready),
    .s_rsp_rdata(t_rsp_rdata), .s_rsp_error(t_rsp_error),
    .m_req_valid(dma_req_valid), .m_req_ready(dma_req_ready), .m_req_write(dma_req_write),
    .m_req_addr(dma_req_addr), .m_req_wdata(dma_req_wdata), .m_req_wstrb(dma_req_wstrb),
    .m_rsp_valid(dma_rsp_valid), .m_rsp_ready(dma_rsp_ready), .m_rsp_rdata(dma_rsp_rdata),
    .m_rsp_error(dma_rsp_error),
    .drained_evt(fence_drained_evt), .fenced(fence_on_u), .idle(fence_idle_u));
endmodule

`default_nettype wire
