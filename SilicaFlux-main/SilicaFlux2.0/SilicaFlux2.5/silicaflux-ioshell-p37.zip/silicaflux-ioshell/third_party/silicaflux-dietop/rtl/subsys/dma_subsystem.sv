// =============================================================================
// SilicaFlux DieTop :: dma_subsystem -- die DMA channels
//
//   DIE_REGS page DMA (c * 0x100)            ─► silicaflux_dma[c] (DataFabric, UNMODIFIED;
//                                                buffered burst engine, one SFB2 master port)
//                                              ─► NoC master DMA[c]
//
// Memory-to-memory copies between shared SRAM, vector scratchpad windows and
// external memory (access matrix: DMA -> SRAM, SPM, EXT; never register space).
// Register map per channel: DataFabric dma_defs.svh (CONTROL, STATUS, SRC_ADDR,
// DST_ADDR, LENGTH, ... ID = "SFDF").  Each channel's interrupt is a die IRQ
// source; a bus-error response seen on a channel's port is a die error event.
// The ControlCore's own system DMA (mcu_dma, page 4) is separate and unchanged.
// Classification: SYNTHESIZABLE (new wrapper, Project 31)
// =============================================================================
`default_nettype none

module dma_subsystem #(
  parameter int ND           = 1,
  parameter int MAX_LEN_LOG2 = 20
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // DMA page of DIE_REGS (rb_addr = page offset; channel c at c * 0x100, 0x000..0x3FF)
  input  wire logic             rb_sel,
  input  wire logic             rb_we,
  input  wire logic [11:0]      rb_addr,
  input  wire logic [31:0]      rb_wdata,
  output logic [31:0]           rb_rdata,
  output logic                  rb_err,
  // SFB2 masters
  output logic [ND-1:0]         m_req_valid,
  input  wire logic [ND-1:0]    m_req_ready,
  output logic [ND-1:0]         m_req_write,
  output logic [ND*32-1:0]      m_req_addr,
  output logic [ND*32-1:0]      m_req_wdata,
  output logic [ND*4-1:0]       m_req_wstrb,
  input  wire logic [ND-1:0]    m_rsp_valid,
  output logic [ND-1:0]         m_rsp_ready,
  input  wire logic [ND*32-1:0] m_rsp_rdata,
  input  wire logic [ND-1:0]    m_rsp_error,
  // status
  output logic [ND-1:0]         irq,
  output logic [ND-1:0]         busy,
  output logic                  err_evt,          // a channel received an error response
  output logic [7:0]            err_chan
);
  wire [1:0] ch = 2'(rb_addr[9:8]);               // c * 0x100
  logic [ND*32-1:0] c_rdata;
  logic [ND-1:0]    c_err;
  for (genvar c = 0; c < ND; c++) begin : g_ch
    /* verilator lint_off UNUSEDSIGNAL */
    logic        ev_done_u;
    logic [31:0] bytes_u;
    logic [7:0]  lvl_u;
    /* verilator lint_on UNUSEDSIGNAL */
    silicaflux_dma #(.DW(32), .ENGINE(1), .FIFO_DEPTH(8), .BURST(8), .DUAL_PORT(0), .MAX_OUT(2),
                     .MAX_LEN_LOG2(MAX_LEN_LOG2), .PERF(1)) u_dma (
      .clk, .rst_n,
      .rb_sel(rb_sel && rb_addr[11:10] == 2'b00 && 32'(ch) == c),.rb_we, .rb_addr({4'd0, rb_addr[7:0]}), .rb_wdata,
      .rb_rdata(c_rdata[c*32 +: 32]), .rb_err(c_err[c]), .irq(irq[c]),
      .m_req_valid(m_req_valid[c]), .m_req_ready(m_req_ready[c]), .m_req_write(m_req_write[c]),
      .m_req_addr(m_req_addr[c*32 +: 32]), .m_req_wdata(m_req_wdata[c*32 +: 32]), .m_req_wstrb(m_req_wstrb[c*4 +: 4]),
      .m_rsp_valid(m_rsp_valid[c]), .m_rsp_ready(m_rsp_ready[c]), .m_rsp_rdata(m_rsp_rdata[c*32 +: 32]),
      .m_rsp_error(m_rsp_error[c]),
      .busy(busy[c]), .ev_done(ev_done_u), .bytes_done(bytes_u), .fifo_level(lvl_u));
  end

  // read mux; an unpopulated channel (or an offset outside the DMA sub-block) -> rb_err
  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = rb_sel;
    for (int c = 0; c < ND; c++) if (rb_addr[11:10] == 2'b00 && 32'(ch) == c) begin
      rb_rdata = c_rdata[c*32 +: 32];
      rb_err   = rb_sel && c_err[c];
    end
  end

  always_comb begin
    err_evt  = 1'b0;
    err_chan = 8'd0;
    for (int c = ND - 1; c >= 0; c--) if (m_rsp_valid[c] && m_rsp_ready[c] && m_rsp_error[c]) begin
      err_evt  = 1'b1;
      err_chan = 8'(c);
    end
  end
endmodule

`default_nettype wire
