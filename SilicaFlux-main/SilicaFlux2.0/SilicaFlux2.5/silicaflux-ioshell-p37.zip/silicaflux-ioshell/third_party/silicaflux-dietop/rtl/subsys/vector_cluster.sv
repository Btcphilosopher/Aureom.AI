// =============================================================================
// SilicaFlux DieTop :: vector_cluster -- one FP32 vector compute region
//
//   rb page (ControlCore accelerator register port) ─► silicaflux_hpc_tile (HPC Module 08, UNMODIFIED)
//   NoC SPM target  ─► die_sfb_dom_gate ─► tile hs_* (64 KiB scratchpad host window)
//   tile fab_* DMA  ─► die_sfb_rst_fence ─► NoC master
//
// The tile and its scratchpad run in the accelerator domain (acc_clk = the
// ControlCore's ICG-gated clk, acc_rst_n = its accelerator reset); the gate and
// the fence run on clk in the fabric reset domain.  Physical partition: one
// cluster = one placement region (tile + its SRAM banks + boundary cells).
// Classification: SYNTHESIZABLE (new wrapper, Project 31)
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module vector_cluster #(
  parameter logic [31:0] SPM_BASE     = 32'h3000_0000,
  parameter int          SPM_BYTES    = 65536,
  parameter int          SRAM_BACKEND = `SRAM_BACKEND_GENERIC
) (
  input  wire logic        clk,
  input  wire logic        fab_rst_n,
  input  wire logic        acc_clk,
  input  wire logic        acc_rst_n,
  input  wire logic        acc_clk_live,
  // register page
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  // scratchpad window (SFB2 slave, from the NoC)
  input  wire logic        spm_req_valid,
  output logic             spm_req_ready,
  input  wire logic        spm_req_write,
  input  wire logic [31:0] spm_req_addr,
  input  wire logic [31:0] spm_req_wdata,
  input  wire logic [3:0]  spm_req_wstrb,
  output logic             spm_rsp_valid,
  input  wire logic        spm_rsp_ready,
  output logic [31:0]      spm_rsp_rdata,
  output logic             spm_rsp_error,
  // tile DMA (SFB2 master, to the NoC)
  output logic             dma_req_valid,
  input  wire logic        dma_req_ready,
  output logic             dma_req_write,
  output logic [31:0]      dma_req_addr,
  output logic [31:0]      dma_req_wdata,
  output logic [3:0]       dma_req_wstrb,
  input  wire logic        dma_rsp_valid,
  output logic             dma_rsp_ready,
  input  wire logic [31:0] dma_rsp_rdata,
  input  wire logic        dma_rsp_error,
  // status
  output logic             irq,
  output logic             busy,            // tile busy OR scratchpad-window activity (clock request)
  output logic             halted,
  output logic             gate_refused_evt,
  output logic             gate_abandoned_evt,
  output logic             fence_drained_evt
);
  logic        hs_req_valid, hs_req_ready, hs_req_write, hs_rsp_valid, hs_rsp_ready, hs_rsp_error;
  logic [31:0] hs_req_addr, hs_req_wdata, hs_rsp_rdata;
  logic [3:0]  hs_req_wstrb;
  logic        f_req_valid, f_req_ready, f_req_write, f_rsp_valid, f_rsp_ready, f_rsp_error;
  logic [31:0] f_req_addr, f_req_wdata, f_rsp_rdata;
  logic [3:0]  f_req_wstrb;
  logic        tile_busy, gate_busy;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        fence_on_u, fence_idle_u;
  /* verilator lint_on UNUSEDSIGNAL */

  silicaflux_hpc_tile #(.SPM_BASE(SPM_BASE), .SCRATCHPAD_BYTES(SPM_BYTES), .SPM_BACKEND(SRAM_BACKEND)) u_tile (
    .clk(acc_clk), .rst_n(acc_rst_n),
    .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .hs_req_valid, .hs_req_ready, .hs_req_write, .hs_req_addr, .hs_req_wdata, .hs_req_wstrb,
    .hs_rsp_valid, .hs_rsp_ready, .hs_rsp_rdata, .hs_rsp_error,
    .fab_req_valid(f_req_valid), .fab_req_ready(f_req_ready), .fab_req_write(f_req_write),
    .fab_req_addr(f_req_addr), .fab_req_wdata(f_req_wdata), .fab_req_wstrb(f_req_wstrb),
    .fab_rsp_valid(f_rsp_valid), .fab_rsp_ready(f_rsp_ready), .fab_rsp_rdata(f_rsp_rdata),
    .fab_rsp_error(f_rsp_error),
    .irq, .busy(tile_busy), .halted);

  die_sfb_dom_gate u_spm_gate (
    .clk, .rst_n(fab_rst_n), .dom_rst_n(acc_rst_n), .dom_clk_live(acc_clk_live),
    .s_req_valid(spm_req_valid), .s_req_ready(spm_req_ready), .s_req_write(spm_req_write),
    .s_req_addr(spm_req_addr), .s_req_wdata(spm_req_wdata), .s_req_wstrb(spm_req_wstrb),
    .s_rsp_valid(spm_rsp_valid), .s_rsp_ready(spm_rsp_ready), .s_rsp_rdata(spm_rsp_rdata),
    .s_rsp_error(spm_rsp_error),
    .m_req_valid(hs_req_valid), .m_req_ready(hs_req_ready), .m_req_write(hs_req_write),
    .m_req_addr(hs_req_addr), .m_req_wdata(hs_req_wdata), .m_req_wstrb(hs_req_wstrb),
    .m_rsp_valid(hs_rsp_valid), .m_rsp_ready(hs_rsp_ready), .m_rsp_rdata(hs_rsp_rdata),
    .m_rsp_error(hs_rsp_error),
    .dom_busy(gate_busy), .refused_evt(gate_refused_evt), .abandoned_evt(gate_abandoned_evt));

  die_sfb_rst_fence #(.MAXO(1)) u_dma_fence (
    .clk, .rst_n(fab_rst_n), .dom_rst_n(acc_rst_n),
    .s_req_valid(f_req_valid), .s_req_ready(f_req_ready), .s_req_write(f_req_write), .s_req_addr(f_req_addr),
    .s_req_wdata(f_req_wdata), .s_req_wstrb(f_req_wstrb), .s_rsp_valid(f_rsp_valid), .s_rsp_ready(f_rsp_ready),
    .s_rsp_rdata(f_rsp_rdata), .s_rsp_error(f_rsp_error),
    .m_req_valid(dma_req_valid), .m_req_ready(dma_req_ready), .m_req_write(dma_req_write),
    .m_req_addr(dma_req_addr), .m_req_wdata(dma_req_wdata), .m_req_wstrb(dma_req_wstrb),
    .m_rsp_valid(dma_rsp_valid), .m_rsp_ready(dma_rsp_ready), .m_rsp_rdata(dma_rsp_rdata),
    .m_rsp_error(dma_rsp_error),
    .drained_evt(fence_drained_evt), .fenced(fence_on_u), .idle(fence_idle_u));

  assign busy = tile_busy || gate_busy;
endmodule

`default_nettype wire
