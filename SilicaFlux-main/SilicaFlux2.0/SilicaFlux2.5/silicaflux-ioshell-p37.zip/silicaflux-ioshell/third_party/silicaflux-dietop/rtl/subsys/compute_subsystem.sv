// =============================================================================
// SilicaFlux DieTop :: compute_subsystem -- vector_cluster[NV] + tensor_cluster[NT]
//
//   die register port (pages 8..13) ─► page decode ─► vector_cluster[i] (page vec_page(i))
//                                                 └► tensor_cluster[j] (page tsu_page(j))
//   SPM windows   [NV] SFB2 slaves  (from the NoC)       ─► vector_cluster[i].spm_*
//   vector DMAs   [NV] SFB2 masters (to the NoC)         ◄─ vector_cluster[i].dma_*
//   tensor DMAs   [NT] SFB2 masters (to the NoC)         ◄─ tensor_cluster[j].dma_*
//
// Clocking: every cluster runs on acc_clk (the ControlCore's ICG-gated clk) and
// acc_rst_n; the boundary gates/fences and the clock-live detector's sampling
// flop run on clk.  acc_clk_live: a toggle flop in the accelerator domain sampled
// on clk -- equal-edge (ICG-derived) clocks, not a clock-domain crossing.
// Busy / interrupt outputs feed the ControlCore (aggregated) and DIE_SYS.
// Unpopulated instance pages answer rb_err (never a silent alias).
// Classification: SYNTHESIZABLE (new, Project 31)
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module compute_subsystem
#(
  parameter int          NV           = 1,
  parameter int          NT           = 1,
  parameter logic [31:0] SPM_BASE0    = 32'h3000_0000,
  parameter logic [31:0] SPM_STRIDE   = 32'h0010_0000,
  parameter int          SPM_BYTES    = 65536,
  parameter logic [31:0] SRAM_BASE    = 32'h2000_0000,
  parameter int          SRAM_BYTES   = 1 << 20,
  parameter int          TSU_QUANT    = 1,
  parameter int          TSU_DBUF     = 1,
  parameter int          TSU_MAXOUT   = 4,
  parameter int          SRAM_BACKEND = `SRAM_BACKEND_GENERIC
) (
  input  wire logic             clk,
  input  wire logic             fab_rst_n,
  input  wire logic             acc_clk,
  input  wire logic             acc_rst_n,
  // ControlCore accelerator register port (all forwarded pages 8..15; non-instance pages answer rb_err)
  input  wire logic             rb_sel,
  input  wire logic             rb_we,
  input  wire logic [15:0]      rb_addr,
  input  wire logic [31:0]      rb_wdata,
  output logic [31:0]           rb_rdata,
  output logic                  rb_err,
  // scratchpad windows (SFB2 slaves)
  input  wire logic [NV-1:0]    spm_req_valid,
  output logic [NV-1:0]         spm_req_ready,
  input  wire logic [NV-1:0]    spm_req_write,
  input  wire logic [NV*32-1:0] spm_req_addr,
  input  wire logic [NV*32-1:0] spm_req_wdata,
  input  wire logic [NV*4-1:0]  spm_req_wstrb,
  output logic [NV-1:0]         spm_rsp_valid,
  input  wire logic [NV-1:0]    spm_rsp_ready,
  output logic [NV*32-1:0]      spm_rsp_rdata,
  output logic [NV-1:0]         spm_rsp_error,
  // vector tile DMAs (SFB2 masters)
  output logic [NV-1:0]         vdma_req_valid,
  input  wire logic [NV-1:0]    vdma_req_ready,
  output logic [NV-1:0]         vdma_req_write,
  output logic [NV*32-1:0]      vdma_req_addr,
  output logic [NV*32-1:0]      vdma_req_wdata,
  output logic [NV*4-1:0]       vdma_req_wstrb,
  input  wire logic [NV-1:0]    vdma_rsp_valid,
  output logic [NV-1:0]         vdma_rsp_ready,
  input  wire logic [NV*32-1:0] vdma_rsp_rdata,
  input  wire logic [NV-1:0]    vdma_rsp_error,
  // tensor unit DMAs (SFB2 masters)
  output logic [NT-1:0]         tdma_req_valid,
  input  wire logic [NT-1:0]    tdma_req_ready,
  output logic [NT-1:0]         tdma_req_write,
  output logic [NT*32-1:0]      tdma_req_addr,
  output logic [NT*32-1:0]      tdma_req_wdata,
  output logic [NT*4-1:0]       tdma_req_wstrb,
  input  wire logic [NT-1:0]    tdma_rsp_valid,
  output logic [NT-1:0]         tdma_rsp_ready,
  input  wire logic [NT*32-1:0] tdma_rsp_rdata,
  input  wire logic [NT-1:0]    tdma_rsp_error,
  // status
  output logic [NV-1:0]         vec_irq,
  output logic [NV-1:0]         vec_busy,
  output logic [NT-1:0]         tsu_irq,
  output logic [NT-1:0]         tsu_busy,
  output logic [NT-1:0]         tsu_halted,
  output logic                  acc_clk_live,
  output logic                  gate_refused_evt,
  output logic                  gate_abandoned_evt,
  output logic                  fence_drained_evt
);

  // ---------------------------------------------------------------- accelerator clock-live detector
  logic tgl_acc_q, tgl_smp_q;
  always_ff @(posedge acc_clk or negedge acc_rst_n)
    if (!acc_rst_n) tgl_acc_q <= 1'b0;
    else            tgl_acc_q <= !tgl_acc_q;
  always_ff @(posedge clk or negedge fab_rst_n)
    if (!fab_rst_n) tgl_smp_q <= 1'b0;
    else            tgl_smp_q <= tgl_acc_q;
  assign acc_clk_live = tgl_acc_q ^ tgl_smp_q;

  // ---------------------------------------------------------------- register pages
  wire [3:0] page = rb_addr[15:12];
  logic [NV*32-1:0] v_rdata;
  logic [NV-1:0]    v_err, v_hit;
  logic [NT*32-1:0] t_rdata;
  logic [NT-1:0]    t_err, t_hit;
  logic [NV-1:0]    v_ref, v_aba, v_drn;
  logic [NT-1:0]    t_drn;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NV-1:0]    v_halted_u;     // vector-tile halt is reported through its IRQ_STATUS / page
  /* verilator lint_on UNUSEDSIGNAL */

  for (genvar i = 0; i < NV; i++) begin : g_vec
    localparam logic [31:0] BASE = SPM_BASE0 + 32'(i) * SPM_STRIDE;
    assign v_hit[i] = (32'(page) == silicaflux_config_pkg::vec_page(i));
    vector_cluster #(.SPM_BASE(BASE), .SPM_BYTES(SPM_BYTES), .SRAM_BACKEND(SRAM_BACKEND)) u_vc (
      .clk, .fab_rst_n, .acc_clk, .acc_rst_n, .acc_clk_live,
      .rb_sel(rb_sel && v_hit[i]), .rb_we, .rb_addr(rb_addr[11:0]), .rb_wdata,
      .rb_rdata(v_rdata[i*32 +: 32]), .rb_err(v_err[i]),
      .spm_req_valid(spm_req_valid[i]), .spm_req_ready(spm_req_ready[i]), .spm_req_write(spm_req_write[i]),
      .spm_req_addr(spm_req_addr[i*32 +: 32]), .spm_req_wdata(spm_req_wdata[i*32 +: 32]),
      .spm_req_wstrb(spm_req_wstrb[i*4 +: 4]), .spm_rsp_valid(spm_rsp_valid[i]), .spm_rsp_ready(spm_rsp_ready[i]),
      .spm_rsp_rdata(spm_rsp_rdata[i*32 +: 32]), .spm_rsp_error(spm_rsp_error[i]),
      .dma_req_valid(vdma_req_valid[i]), .dma_req_ready(vdma_req_ready[i]), .dma_req_write(vdma_req_write[i]),
      .dma_req_addr(vdma_req_addr[i*32 +: 32]), .dma_req_wdata(vdma_req_wdata[i*32 +: 32]),
      .dma_req_wstrb(vdma_req_wstrb[i*4 +: 4]), .dma_rsp_valid(vdma_rsp_valid[i]), .dma_rsp_ready(vdma_rsp_ready[i]),
      .dma_rsp_rdata(vdma_rsp_rdata[i*32 +: 32]), .dma_rsp_error(vdma_rsp_error[i]),
      .irq(vec_irq[i]), .busy(vec_busy[i]), .halted(v_halted_u[i]),
      .gate_refused_evt(v_ref[i]), .gate_abandoned_evt(v_aba[i]), .fence_drained_evt(v_drn[i]));
  end

  for (genvar j = 0; j < NT; j++) begin : g_tsu
    assign t_hit[j] = (32'(page) == silicaflux_config_pkg::tsu_page(j));
    tensor_cluster #(
      .MEM_LO(33'(SRAM_BASE)), .MEM_HI(33'(SRAM_BASE) + 33'(SRAM_BYTES)), .TSU_QUANT(TSU_QUANT), .TSU_DBUF(TSU_DBUF),
      .TSU_MAXOUT(TSU_MAXOUT), .SRAM_BACKEND(SRAM_BACKEND)
    ) u_tc (
      .clk, .fab_rst_n, .acc_clk, .acc_rst_n,
      .rb_sel(rb_sel && t_hit[j]), .rb_we, .rb_addr(rb_addr[11:0]), .rb_wdata,
      .rb_rdata(t_rdata[j*32 +: 32]), .rb_err(t_err[j]),
      .dma_req_valid(tdma_req_valid[j]), .dma_req_ready(tdma_req_ready[j]), .dma_req_write(tdma_req_write[j]),
      .dma_req_addr(tdma_req_addr[j*32 +: 32]), .dma_req_wdata(tdma_req_wdata[j*32 +: 32]),
      .dma_req_wstrb(tdma_req_wstrb[j*4 +: 4]), .dma_rsp_valid(tdma_rsp_valid[j]), .dma_rsp_ready(tdma_rsp_ready[j]),
      .dma_rsp_rdata(tdma_rsp_rdata[j*32 +: 32]), .dma_rsp_error(tdma_rsp_error[j]),
      .irq(tsu_irq[j]), .busy(tsu_busy[j]), .halted(tsu_halted[j]), .fence_drained_evt(t_drn[j]));
  end

  // read mux: one-hot hit (pages are distinct); a page with no populated instance -> rb_err
  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = rb_sel;
    for (int i = 0; i < NV; i++) if (v_hit[i]) begin rb_rdata = v_rdata[i*32 +: 32]; rb_err = rb_sel && v_err[i]; end
    for (int j = 0; j < NT; j++) if (t_hit[j]) begin rb_rdata = t_rdata[j*32 +: 32]; rb_err = rb_sel && t_err[j]; end
  end

  assign gate_refused_evt   = |v_ref;
  assign gate_abandoned_evt = |v_aba;
  assign fence_drained_evt  = |v_drn || |t_drn;
endmodule

`default_nettype wire
