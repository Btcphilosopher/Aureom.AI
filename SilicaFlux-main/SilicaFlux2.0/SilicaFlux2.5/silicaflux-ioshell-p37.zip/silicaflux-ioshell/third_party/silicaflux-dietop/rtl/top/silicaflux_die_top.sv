// =============================================================================
// SilicaFlux DieTop (Project 31) :: silicaflux_die_top -- master hierarchical top
// Aureom.AI | SilicaFlux-HPC | Physical Design Batch 04
//
//                        ┌──────────────────────── silicaflux_die_top ─────────────────────────┐
//  clk_i pll_lock_i por_ni ─► clock_reset_subsystem ── fab_rst_n / cc_rst_n / stage            │
//  host_* (SFB2) ──────────► host_io_subsystem ─┬─► control_subsystem (ControlCore) ── acc_clk/acc_rst ─┐
//                                               │        │ ext (fenced)   │ rb pages 8..13             │
//                                               │        ▼                └──────────────► compute_subsystem
//                                               └──► datafabric (NoC) ─► SPM windows ─────► vector_cluster[NV]
//                                                   ▲  │  │  │                                 tensor_cluster[NT]
//                         dma_subsystem[ND] ────────┘  │  │  └► memory_subsystem (SRAM slices, ExtMem bridge) ─► mc_* (SFMC)
//                         (DMA masters / regs) ◄───────┴──┴──── die_regs_window (DIE_REGS: DIE_SYS, NOC_PERF, DMA)
//                         die_sysctrl (CTRL/IRQ) + ras_test_subsystem (ERR/TEST) ◄── error events
//                        └─────────────────────────────────────────────────────────────────────┘
//
// Everything reused is vendored UNMODIFIED under third_party/ (SHA256SUMS,
// MANIFEST.tsv).  The integration contract (address map, pages, registers,
// interrupts, error codes, configurations) is config/silicaflux_die.yaml ->
// silicaflux_die_pkg / silicaflux_config_pkg (generated).
//
// Configurations (silicaflux_config_pkg, wrappers silicaflux_die_min / _hpc):
//   MIN  1 vector tile, 1 INT8 4x4 tensor unit, 1 MiB / 4 banks, shared-bus NoC, 1 DMA
//   HPC  4 vector tiles, 2 tensor units, 4 MiB / 4 slices x 4 banks, crossbar NoC,
//        2 DMA channels, external-memory bridge  -- ARCHITECTURAL EXPLORATION
// Clocking: one functional clock (clk_i).  Accelerators run on the ControlCore's
// ICG-gated copy; boundary handshakes follow the clock-request protocol of
// die_sfb_dom_gate.  mc_clk_i is used only with EXTMEM_ASYNC = 1 (bridge CDC).
// Nothing here is a qualified silicon macro, PHY or PLL; no area, frequency or
// power figure is claimed (docs/LIMITATIONS.md).
// Classification: SYNTHESIZABLE (new, Project 31)
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module silicaflux_die_top
#(
  parameter int NUM_VECTOR_CLUSTERS = 1,
  parameter int NUM_TENSOR_CLUSTERS = 1,
  parameter int NUM_SRAM_BANKS      = 4,
  parameter int NUM_SRAM_SLICES     = 1,
  parameter int SRAM_BYTES          = 32'h0010_0000,
  parameter int NUM_DMA_CHANNELS    = 1,
  parameter int NOC_TOPOLOGY        = 0,
  parameter int EXTMEM_EN           = 0,
  parameter int EXTMEM_ASYNC        = 0,
  parameter int TESTCORE_EN         = 0,
  parameter int SRAM_PARITY         = 1,
  parameter int SRAM_BACKEND        = `SRAM_BACKEND_GENERIC,
  parameter int TSU_QUANT           = 1,
  parameter int TSU_DBUF            = 1,
  parameter int CONFIG_ID           = silicaflux_die_pkg::DIE_CFGID_MIN,
  parameter int RST_FABRIC_DELAY    = 16,
  parameter int RST_CONTROL_DELAY   = 16,
  localparam int MC_AW              = $clog2(silicaflux_die_pkg::DIE_EXTMEM_SIZE),
  localparam int MC_TW              = 2
) (
  // ------------------------------------------------ clock / reset / PLL boundary
  input  wire logic             clk_i,
  input  wire logic             por_ni,
  input  wire logic             pll_lock_i,
  input  wire logic             test_mode_i,
  input  wire logic [1:0]       boot_mode_i,
  input  wire logic             host_rst_req_i,
  // ------------------------------------------------ host port (simulation host bridge, SFB2 slave)
  input  wire logic             host_req_valid_i,
  output logic                  host_req_ready_o,
  input  wire logic             host_req_write_i,
  input  wire logic [31:0]      host_req_addr_i,
  input  wire logic [31:0]      host_req_wdata_i,
  input  wire logic [3:0]       host_req_wstrb_i,
  output logic                  host_rsp_valid_o,
  input  wire logic             host_rsp_ready_i,
  output logic [31:0]           host_rsp_rdata_o,
  output logic                  host_rsp_error_o,
  output logic                  host_irq_o,
  output logic                  platform_ready_o,
  output logic                  device_ready_o,
  // ------------------------------------------------ external-memory controller interface (SFMC)
  input  wire logic             mc_clk_i,
  output logic                  mc_rst_no,
  input  wire logic             mc_init_done_i,
  input  wire logic             mc_fatal_i,
  output logic                  mc_cmd_valid_o,
  input  wire logic             mc_cmd_ready_i,
  output logic                  mc_cmd_write_o,
  output logic [MC_AW-1:0]      mc_cmd_addr_o,
  output logic [7:0]            mc_cmd_len_o,
  output logic [MC_TW-1:0]      mc_cmd_tag_o,
  output logic                  mc_wd_valid_o,
  input  wire logic             mc_wd_ready_i,
  output logic [31:0]           mc_wd_data_o,
  output logic [3:0]            mc_wd_strb_o,
  output logic                  mc_wd_last_o,
  input  wire logic             mc_rd_valid_i,
  output logic                  mc_rd_ready_o,
  input  wire logic [31:0]      mc_rd_data_i,
  input  wire logic [MC_TW-1:0] mc_rd_tag_i,
  input  wire logic             mc_rd_last_i,
  input  wire logic             mc_rd_error_i,
  input  wire logic             mc_wr_valid_i,
  output logic                  mc_wr_ready_o,
  input  wire logic [MC_TW-1:0] mc_wr_tag_i,
  input  wire logic             mc_wr_error_i,
  // ------------------------------------------------ JTAG (reserved for TestCore; inactive in this release)
  input  wire logic             tck_i,
  input  wire logic             tms_i,
  input  wire logic             tdi_i,
  input  wire logic             trst_ni,
  output logic                  tdo_o,
  output logic                  tdo_oe_o,
  // ------------------------------------------------ board RAS
  input  wire logic             ext_warn_i,
  input  wire logic             ext_fatal_i,
  output logic                  ras_fatal_o,
  // ------------------------------------------------ diagnostics
  output logic                  diag_valid_o,
  output logic [7:0]            diag_char_o,
  output logic                  test_done_o,
  output logic                  test_fail_o,
  output logic [15:0]           test_code_o,
  output logic                  cpu_sleep_o
);

  // ================================================================ configuration
  localparam int NV  = NUM_VECTOR_CLUSTERS;
  localparam int NT  = NUM_TENSOR_CLUSTERS;
  localparam int ND  = NUM_DMA_CHANNELS;
  localparam int NSL = NUM_SRAM_SLICES;
  localparam int BPS = NUM_SRAM_BANKS / NUM_SRAM_SLICES;
  localparam int SLICE_BYTES = SRAM_BYTES / NUM_SRAM_SLICES;
  localparam int NM  = silicaflux_config_pkg::noc_nm(ND, NV, NT);
  localparam int NTG = silicaflux_config_pkg::noc_nt(NSL, NV, EXTMEM_EN);
  localparam int CFG_ERR = silicaflux_config_pkg::cfg_error(NV, NT, NUM_SRAM_BANKS, NSL, SRAM_BYTES, ND, NOC_TOPOLOGY, EXTMEM_EN);

  // elaboration-time parameter validation (Verilator / Yosys: generate-time $fatal; Icarus: initial)
  if (CFG_ERR != 0) begin : g_cfg_error
`ifdef __ICARUS__
    initial $fatal(1, "silicaflux_die_top: illegal configuration, rule %0d (silicaflux_config_pkg::cfg_error)", CFG_ERR);
`else
    $fatal(1, "silicaflux_die_top: illegal configuration, rule %0d (silicaflux_config_pkg::cfg_error)", CFG_ERR);
`endif
  end
  if (EXTMEM_ASYNC != 0 && EXTMEM_EN == 0) begin : g_cfg_async
`ifdef __ICARUS__
    initial $fatal(1, "silicaflux_die_top: EXTMEM_ASYNC requires EXTMEM_EN");
`else
    $fatal(1, "silicaflux_die_top: EXTMEM_ASYNC requires EXTMEM_EN");
`endif
  end

  // ---------------------------------------------------------------- fabric description (from the contract)
  // Master order CC, HOST, DMA[ND], VEC[NV], TSU[NT]; target order SRAM[NSL], SPM[NV], REGS, EXT, EXTCSR
  // (silicaflux_config_pkg m_* / t_* helpers).  Class decode is written inline in every function:
  // Icarus 12 does not allow a constant function to call another function.
  function automatic logic [NTG*32-1:0] f_tgt_base();
    for (int t = 0; t < NTG; t++)
      if (t < NSL)            f_tgt_base[t*32 +: 32] = silicaflux_die_pkg::DIE_SHARED_SRAM_BASE + 32'(t) * 32'(SLICE_BYTES);
      else if (t < NSL + NV)  f_tgt_base[t*32 +: 32] = silicaflux_die_pkg::DIE_VEC_SPM_BASE + 32'(t - NSL) * silicaflux_die_pkg::DIE_VEC_SPM_STRIDE;
      else if (t == NSL + NV) f_tgt_base[t*32 +: 32] = silicaflux_die_pkg::DIE_DIE_REGS_BASE;
      else if (t == NSL + NV + 1) f_tgt_base[t*32 +: 32] = silicaflux_die_pkg::DIE_EXTMEM_BASE;
      else                    f_tgt_base[t*32 +: 32] = silicaflux_die_pkg::DIE_EXTMEM_CSR_BASE;
  endfunction
  function automatic logic [NTG*32-1:0] f_tgt_mask();
    for (int t = 0; t < NTG; t++)
      if (t < NSL)            f_tgt_mask[t*32 +: 32] = ~(32'(SLICE_BYTES) - 32'd1);
      else if (t < NSL + NV)  f_tgt_mask[t*32 +: 32] = ~(silicaflux_die_pkg::DIE_VEC_SPM_SIZE - 32'd1);
      else if (t == NSL + NV) f_tgt_mask[t*32 +: 32] = ~(silicaflux_die_pkg::DIE_DIE_REGS_WINDOW - 32'd1);
      else if (t == NSL + NV + 1) f_tgt_mask[t*32 +: 32] = ~(silicaflux_die_pkg::DIE_EXTMEM_SIZE - 32'd1);
      else                    f_tgt_mask[t*32 +: 32] = ~(silicaflux_die_pkg::DIE_EXTMEM_CSR_SIZE - 32'd1);
  endfunction
  function automatic logic [NM*NTG-1:0] f_access();
    int mc, tc;
    for (int m = 0; m < NM; m++)
      for (int t = 0; t < NTG; t++) begin
        if (m == 0)                 mc = silicaflux_die_pkg::DIE_MCLASS_CC;
        else if (m == 1)            mc = silicaflux_die_pkg::DIE_MCLASS_HOST;
        else if (m < 2 + ND)        mc = silicaflux_die_pkg::DIE_MCLASS_DMA;
        else if (m < 2 + ND + NV)   mc = silicaflux_die_pkg::DIE_MCLASS_VEC;
        else                        mc = silicaflux_die_pkg::DIE_MCLASS_TSU;
        if (t < NSL)                tc = silicaflux_die_pkg::DIE_TCLASS_SRAM;
        else if (t < NSL + NV)      tc = silicaflux_die_pkg::DIE_TCLASS_SPM;
        else if (t == NSL + NV)     tc = silicaflux_die_pkg::DIE_TCLASS_REGS;
        else if (t == NSL + NV + 1) tc = silicaflux_die_pkg::DIE_TCLASS_EXT;
        else                        tc = silicaflux_die_pkg::DIE_TCLASS_EXTCSR;
        f_access[m*NTG + t] = silicaflux_die_pkg::DIE_CLASS_ACCESS[mc * silicaflux_die_pkg::DIE_NUM_TCLASS + tc];
      end
  endfunction
  function automatic logic [NM*8-1:0] f_maxo();
    for (int m = 0; m < NM; m++)
      if (m == 0)                 f_maxo[m*8 +: 8] = 8'(silicaflux_die_pkg::DIE_MAXO_CC);
      else if (m == 1)            f_maxo[m*8 +: 8] = 8'(silicaflux_die_pkg::DIE_MAXO_HOST);
      else if (m < 2 + ND)        f_maxo[m*8 +: 8] = 8'(silicaflux_die_pkg::DIE_MAXO_DMA);
      else if (m < 2 + ND + NV)   f_maxo[m*8 +: 8] = 8'(silicaflux_die_pkg::DIE_MAXO_VEC);
      else                        f_maxo[m*8 +: 8] = 8'(silicaflux_die_pkg::DIE_MAXO_TSU);
  endfunction
  function automatic logic [NM*3-1:0] f_qos();
    for (int m = 0; m < NM; m++)
      if (m < 2)                  f_qos[m*3 +: 3] = sfn_pkg::QOS_CTRL;
      else if (m < 2 + ND)        f_qos[m*3 +: 3] = sfn_pkg::QOS_DMA;
      else if (m < 2 + ND + NV)   f_qos[m*3 +: 3] = sfn_pkg::QOS_VECTOR;
      else                        f_qos[m*3 +: 3] = sfn_pkg::QOS_TENSOR;
  endfunction
  function automatic logic [NTG*8-1:0] f_depth();
    for (int t = 0; t < NTG; t++)
      if (t < NSL)            f_depth[t*8 +: 8] = 8'(silicaflux_die_pkg::DIE_DEPTH_SRAM);
      else if (t < NSL + NV)  f_depth[t*8 +: 8] = 8'(silicaflux_die_pkg::DIE_DEPTH_SPM);
      else if (t == NSL + NV) f_depth[t*8 +: 8] = 8'(silicaflux_die_pkg::DIE_DEPTH_REGS);
      else if (t == NSL + NV + 1) f_depth[t*8 +: 8] = 8'(silicaflux_die_pkg::DIE_DEPTH_EXT);
      else                    f_depth[t*8 +: 8] = 8'(silicaflux_die_pkg::DIE_DEPTH_EXTCSR);
  endfunction
  localparam logic [NTG*32-1:0] TGT_BASE   = f_tgt_base();
  localparam logic [NTG*32-1:0] TGT_MASK   = f_tgt_mask();
  localparam logic [NM*NTG-1:0] MST_TGT_EN = f_access();
  localparam logic [NM*8-1:0]   MST_MAXO   = f_maxo();
  localparam logic [NM*3-1:0]   MST_QOS    = f_qos();
  localparam logic [NTG*8-1:0]  TGT_DEPTH  = f_depth();

  // ================================================================ clock / reset
  logic       fab_rst_n, cc_rst_n, reset_done, pll_locked;
  logic [2:0] rst_stage;
  clock_reset_subsystem #(.FABRIC_DELAY(RST_FABRIC_DELAY), .CONTROL_DELAY(RST_CONTROL_DELAY)) u_clkrst (
    .clk_i, .por_ni, .pll_lock_i, .test_mode_i,
    .fab_rst_n, .cc_rst_n, .stage(rst_stage), .reset_done, .pll_locked);
  wire clk = clk_i;

  // ================================================================ fabric buses
  logic [NM-1:0]      m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NM*32-1:0]   m_req_addr, m_req_wdata, m_rsp_rdata;
  logic [NM*4-1:0]    m_req_wstrb;
  logic [NTG-1:0]     t_req_valid, t_req_ready, t_req_write, t_rsp_valid, t_rsp_ready, t_rsp_error;
  logic [NTG*32-1:0]  t_req_addr, t_req_wdata, t_rsp_rdata;
  logic [NTG*4-1:0]   t_req_wstrb;

  // ================================================================ host I/O
  logic        hs_req_valid, hs_req_ready, hs_req_write, hs_rsp_valid, hs_rsp_ready, hs_rsp_error;
  logic [31:0] hs_req_addr, hs_req_wdata, hs_rsp_rdata;
  logic [3:0]  hs_req_wstrb;
  logic        host_dec_evt, host_busy;
  logic [31:0] host_dec_addr;
  host_io_subsystem u_host_io (
    .clk, .rst_n(fab_rst_n),
    .host_req_valid(host_req_valid_i), .host_req_ready(host_req_ready_o), .host_req_write(host_req_write_i),
    .host_req_addr(host_req_addr_i), .host_req_wdata(host_req_wdata_i), .host_req_wstrb(host_req_wstrb_i),
    .host_rsp_valid(host_rsp_valid_o), .host_rsp_ready(host_rsp_ready_i), .host_rsp_rdata(host_rsp_rdata_o),
    .host_rsp_error(host_rsp_error_o),
    .cc_req_valid(hs_req_valid), .cc_req_ready(hs_req_ready), .cc_req_write(hs_req_write), .cc_req_addr(hs_req_addr),
    .cc_req_wdata(hs_req_wdata), .cc_req_wstrb(hs_req_wstrb), .cc_rsp_valid(hs_rsp_valid), .cc_rsp_ready(hs_rsp_ready),
    .cc_rsp_rdata(hs_rsp_rdata), .cc_rsp_error(hs_rsp_error),
    .fab_req_valid(m_req_valid[1]), .fab_req_ready(m_req_ready[1]), .fab_req_write(m_req_write[1]),
    .fab_req_addr(m_req_addr[32 +: 32]), .fab_req_wdata(m_req_wdata[32 +: 32]), .fab_req_wstrb(m_req_wstrb[4 +: 4]),
    .fab_rsp_valid(m_rsp_valid[1]), .fab_rsp_ready(m_rsp_ready[1]), .fab_rsp_rdata(m_rsp_rdata[32 +: 32]),
    .fab_rsp_error(m_rsp_error[1]),
    .dec_err_evt(host_dec_evt), .dec_err_addr(host_dec_addr), .busy(host_busy));

  // ================================================================ control (ControlCore)
  logic        rb_sel, rb_we, rb_err;
  logic [15:0] rb_addr;
  logic [31:0] rb_wdata, rb_rdata;
  logic        acc_clk, acc_rst_n, cc_host_irq, cc_host_ready;
  logic        cc_vec_irq, cc_tsu_irq, cc_warn, cc_fatal, cc_drain_evt;
  logic [NV-1:0] vec_irq, vec_busy;
  logic [NT-1:0] tsu_irq, tsu_busy, tsu_halted;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        cmdproc_ready_u;
  /* verilator lint_on UNUSEDSIGNAL */
  control_subsystem #(.SRAM_BACKEND(SRAM_BACKEND)) u_control (
    .clk, .cc_rst_n, .fab_rst_n, .test_mode(test_mode_i), .boot_mode(boot_mode_i), .host_rst_req(host_rst_req_i),
    .hs_req_valid, .hs_req_ready, .hs_req_write, .hs_req_addr, .hs_req_wdata, .hs_req_wstrb,
    .hs_rsp_valid, .hs_rsp_ready, .hs_rsp_rdata, .hs_rsp_error,
    .host_irq(cc_host_irq), .host_ready(cc_host_ready), .cmdproc_ready(cmdproc_ready_u), .ras_fatal(ras_fatal_o),
    .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .x_req_valid(m_req_valid[0]), .x_req_ready(m_req_ready[0]), .x_req_write(m_req_write[0]),
    .x_req_addr(m_req_addr[0 +: 32]), .x_req_wdata(m_req_wdata[0 +: 32]), .x_req_wstrb(m_req_wstrb[0 +: 4]),
    .x_rsp_valid(m_rsp_valid[0]), .x_rsp_ready(m_rsp_ready[0]), .x_rsp_rdata(m_rsp_rdata[0 +: 32]),
    .x_rsp_error(m_rsp_error[0]),
    .acc_clk, .acc_rst_n,
    .acc_vec_irq(cc_vec_irq), .acc_tsu_irq(cc_tsu_irq), .acc_vec_busy(|vec_busy), .acc_tsu_busy(|tsu_busy),
    .acc_tsu_halted(|tsu_halted),
    .ext_warn(ext_warn_i || cc_warn), .ext_fatal(ext_fatal_i || cc_fatal),
    .diag_valid(diag_valid_o), .diag_char(diag_char_o), .test_done(test_done_o), .test_fail(test_fail_o),
    .test_code(test_code_o), .cpu_sleep(cpu_sleep_o), .fence_drained_evt(cc_drain_evt));

  // ================================================================ die register window (DIE_REGS, NoC target REGS)
  localparam int TR = NSL + NV;        // REGS target index
  logic        d_we, sys_sel, ras_sel, dma_sel, noc_sel;
  logic [11:0] d_addr;
  logic [31:0] d_wdata, sys_rdata, ras_rdata, dma_rdata, noc_rdata;
  logic        sys_err, ras_err, dma_err, noc_err;
  die_regs_window u_regs (
    .clk, .rst_n(fab_rst_n),
    .req_valid(t_req_valid[TR]), .req_ready(t_req_ready[TR]), .req_write(t_req_write[TR]),
    .req_addr(t_req_addr[TR*32 +: 32]), .req_wdata(t_req_wdata[TR*32 +: 32]), .req_wstrb(t_req_wstrb[TR*4 +: 4]),
    .rsp_valid(t_rsp_valid[TR]), .rsp_ready(t_rsp_ready[TR]), .rsp_rdata(t_rsp_rdata[TR*32 +: 32]),
    .rsp_error(t_rsp_error[TR]),
    .rb_we(d_we), .rb_addr(d_addr), .rb_wdata(d_wdata),
    .sys_sel, .sys_rdata, .sys_err, .ras_sel, .ras_rdata, .ras_err, .noc_sel, .noc_rdata, .noc_err,
    .dma_sel, .dma_rdata, .dma_err);

  // ================================================================ compute
  localparam int MV = 2 + ND;          // first vector-DMA master
  localparam int MT = 2 + ND + NV;     // first tensor-DMA master
  logic acc_clk_live, gate_ref_evt, gate_aba_evt, comp_drain_evt;
  compute_subsystem #(
    .NV(NV), .NT(NT), .SPM_BASE0(silicaflux_die_pkg::DIE_VEC_SPM_BASE), .SPM_STRIDE(silicaflux_die_pkg::DIE_VEC_SPM_STRIDE), .SPM_BYTES(32'(silicaflux_die_pkg::DIE_VEC_SPM_SIZE)),
    .SRAM_BASE(silicaflux_die_pkg::DIE_SHARED_SRAM_BASE), .SRAM_BYTES(SRAM_BYTES), .TSU_QUANT(TSU_QUANT), .TSU_DBUF(TSU_DBUF),
    .TSU_MAXOUT(silicaflux_die_pkg::DIE_MAXO_TSU), .SRAM_BACKEND(SRAM_BACKEND)
  ) u_compute (
    .clk, .fab_rst_n, .acc_clk, .acc_rst_n,
    .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,          // ControlCore pages 8..15 (13..15 refused)
    .spm_req_valid(t_req_valid[NSL +: NV]), .spm_req_ready(t_req_ready[NSL +: NV]), .spm_req_write(t_req_write[NSL +: NV]),
    .spm_req_addr(t_req_addr[NSL*32 +: NV*32]), .spm_req_wdata(t_req_wdata[NSL*32 +: NV*32]),
    .spm_req_wstrb(t_req_wstrb[NSL*4 +: NV*4]), .spm_rsp_valid(t_rsp_valid[NSL +: NV]),
    .spm_rsp_ready(t_rsp_ready[NSL +: NV]), .spm_rsp_rdata(t_rsp_rdata[NSL*32 +: NV*32]),
    .spm_rsp_error(t_rsp_error[NSL +: NV]),
    .vdma_req_valid(m_req_valid[MV +: NV]), .vdma_req_ready(m_req_ready[MV +: NV]), .vdma_req_write(m_req_write[MV +: NV]),
    .vdma_req_addr(m_req_addr[MV*32 +: NV*32]), .vdma_req_wdata(m_req_wdata[MV*32 +: NV*32]),
    .vdma_req_wstrb(m_req_wstrb[MV*4 +: NV*4]), .vdma_rsp_valid(m_rsp_valid[MV +: NV]),
    .vdma_rsp_ready(m_rsp_ready[MV +: NV]), .vdma_rsp_rdata(m_rsp_rdata[MV*32 +: NV*32]),
    .vdma_rsp_error(m_rsp_error[MV +: NV]),
    .tdma_req_valid(m_req_valid[MT +: NT]), .tdma_req_ready(m_req_ready[MT +: NT]), .tdma_req_write(m_req_write[MT +: NT]),
    .tdma_req_addr(m_req_addr[MT*32 +: NT*32]), .tdma_req_wdata(m_req_wdata[MT*32 +: NT*32]),
    .tdma_req_wstrb(m_req_wstrb[MT*4 +: NT*4]), .tdma_rsp_valid(m_rsp_valid[MT +: NT]),
    .tdma_rsp_ready(m_rsp_ready[MT +: NT]), .tdma_rsp_rdata(m_rsp_rdata[MT*32 +: NT*32]),
    .tdma_rsp_error(m_rsp_error[MT +: NT]),
    .vec_irq, .vec_busy, .tsu_irq, .tsu_busy, .tsu_halted, .acc_clk_live,
    .gate_refused_evt(gate_ref_evt), .gate_abandoned_evt(gate_aba_evt), .fence_drained_evt(comp_drain_evt));

  // ================================================================ DMA
  logic [ND-1:0] dma_irq, dma_busy;
  logic          dma_err_evt;
  logic [7:0]    dma_err_chan;
  dma_subsystem #(.ND(ND)) u_dma (
    .clk, .rst_n(fab_rst_n),
    .rb_sel(dma_sel), .rb_we(d_we), .rb_addr(d_addr), .rb_wdata(d_wdata), .rb_rdata(dma_rdata), .rb_err(dma_err),
    .m_req_valid(m_req_valid[2 +: ND]), .m_req_ready(m_req_ready[2 +: ND]), .m_req_write(m_req_write[2 +: ND]),
    .m_req_addr(m_req_addr[64 +: ND*32]), .m_req_wdata(m_req_wdata[64 +: ND*32]), .m_req_wstrb(m_req_wstrb[8 +: ND*4]),
    .m_rsp_valid(m_rsp_valid[2 +: ND]), .m_rsp_ready(m_rsp_ready[2 +: ND]), .m_rsp_rdata(m_rsp_rdata[64 +: ND*32]),
    .m_rsp_error(m_rsp_error[2 +: ND]),
    .irq(dma_irq), .busy(dma_busy), .err_evt(dma_err_evt), .err_chan(dma_err_chan));

  // ================================================================ fabric
  localparam int MW = (NM > 1) ? $clog2(NM) : 1;
  logic          noc_irq, noc_dec_evt, fab_busy;
  logic [MW-1:0] noc_dec_master;
  logic [31:0]   noc_dec_addr;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NM-1:0] req_accept_u;
  /* verilator lint_on UNUSEDSIGNAL */
  datafabric #(
    .TOPOLOGY(NOC_TOPOLOGY), .NM(NM), .NT(NTG), .TGT_BASE(TGT_BASE), .TGT_MASK(TGT_MASK), .MST_TGT_EN(MST_TGT_EN),
    .MST_MAXO(MST_MAXO), .MST_QOS(MST_QOS), .TGT_DEPTH(TGT_DEPTH), .MAXO_MAX(silicaflux_die_pkg::DIE_MAXO_TSU)
  ) u_fabric (
    .clk, .rst_n(fab_rst_n),
    .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
    .t_req_valid, .t_req_ready, .t_req_write, .t_req_addr, .t_req_wdata, .t_req_wstrb,
    .t_rsp_valid, .t_rsp_ready, .t_rsp_rdata, .t_rsp_error,
    .rb_sel(noc_sel), .rb_we(d_we), .rb_addr(d_addr), .rb_wdata(d_wdata), .rb_rdata(noc_rdata), .rb_err(noc_err),
    .irq_err(noc_irq), .dec_err_evt(noc_dec_evt), .dec_err_master(noc_dec_master), .dec_err_addr(noc_dec_addr),
    .req_accept(req_accept_u), .busy(fab_busy));

  // ================================================================ memory
  localparam int TX = NSL + NV + 1;    // EXT / EXTCSR target indices (when present)
  logic        x_req_valid, x_req_ready, x_req_write, x_rsp_valid, x_rsp_ready, x_rsp_error;
  logic [31:0] x_req_addr, x_req_wdata, x_rsp_rdata;
  logic [3:0]  x_req_wstrb;
  logic        c_req_valid, c_req_ready, c_req_write, c_rsp_valid, c_rsp_ready, c_rsp_error;
  logic [31:0] c_req_addr, c_req_wdata, c_rsp_rdata;
  logic [3:0]  c_req_wstrb;
  if (EXTMEM_EN != 0) begin : g_ext_tgt
    assign x_req_valid = t_req_valid[TX];          assign t_req_ready[TX] = x_req_ready;
    assign x_req_write = t_req_write[TX];          assign x_req_addr = t_req_addr[TX*32 +: 32];
    assign x_req_wdata = t_req_wdata[TX*32 +: 32]; assign x_req_wstrb = t_req_wstrb[TX*4 +: 4];
    assign t_rsp_valid[TX] = x_rsp_valid;          assign x_rsp_ready = t_rsp_ready[TX];
    assign t_rsp_rdata[TX*32 +: 32] = x_rsp_rdata; assign t_rsp_error[TX] = x_rsp_error;
    assign c_req_valid = t_req_valid[TX+1];          assign t_req_ready[TX+1] = c_req_ready;
    assign c_req_write = t_req_write[TX+1];          assign c_req_addr = t_req_addr[(TX+1)*32 +: 32];
    assign c_req_wdata = t_req_wdata[(TX+1)*32 +: 32]; assign c_req_wstrb = t_req_wstrb[(TX+1)*4 +: 4];
    assign t_rsp_valid[TX+1] = c_rsp_valid;          assign c_rsp_ready = t_rsp_ready[TX+1];
    assign t_rsp_rdata[(TX+1)*32 +: 32] = c_rsp_rdata; assign t_rsp_error[TX+1] = c_rsp_error;
  end else begin : g_no_ext_tgt
    assign x_req_valid = 1'b0; assign x_req_write = 1'b0; assign x_req_addr = '0; assign x_req_wdata = '0;
    assign x_req_wstrb = '0;   assign x_rsp_ready = 1'b0;
    assign c_req_valid = 1'b0; assign c_req_write = 1'b0; assign c_req_addr = '0; assign c_req_wdata = '0;
    assign c_req_wstrb = '0;   assign c_rsp_ready = 1'b0;
  end
  logic        mem_ready, sram_busy, par_evt, ext_ready, ext_idle, ext_fault, ext_err_evt;
  logic [31:0] par_addr, ext_err_addr;
  memory_subsystem #(
    .NSLICES(NSL), .BANKS_PER_SLICE(BPS), .SRAM_BASE(silicaflux_die_pkg::DIE_SHARED_SRAM_BASE), .SRAM_BYTES(SRAM_BYTES),
    .SRAM_PARITY(SRAM_PARITY), .SRAM_BACKEND(SRAM_BACKEND), .EXTMEM_EN(EXTMEM_EN), .EXTMEM_ASYNC(EXTMEM_ASYNC),
    .EXT_BASE(silicaflux_die_pkg::DIE_EXTMEM_BASE), .EXT_BYTES(32'(silicaflux_die_pkg::DIE_EXTMEM_SIZE)), .MC_AW(MC_AW)
  ) u_memory (
    .clk, .rst_n(fab_rst_n),
    .s_req_valid(t_req_valid[0 +: NSL]), .s_req_ready(t_req_ready[0 +: NSL]), .s_req_write(t_req_write[0 +: NSL]),
    .s_req_addr(t_req_addr[0 +: NSL*32]), .s_req_wdata(t_req_wdata[0 +: NSL*32]), .s_req_wstrb(t_req_wstrb[0 +: NSL*4]),
    .s_rsp_valid(t_rsp_valid[0 +: NSL]), .s_rsp_ready(t_rsp_ready[0 +: NSL]), .s_rsp_rdata(t_rsp_rdata[0 +: NSL*32]),
    .s_rsp_error(t_rsp_error[0 +: NSL]),
    .x_req_valid, .x_req_ready, .x_req_write, .x_req_addr, .x_req_wdata, .x_req_wstrb,
    .x_rsp_valid, .x_rsp_ready, .x_rsp_rdata, .x_rsp_error,
    .c_req_valid, .c_req_ready, .c_req_write, .c_req_addr, .c_req_wdata, .c_req_wstrb,
    .c_rsp_valid, .c_rsp_ready, .c_rsp_rdata, .c_rsp_error,
    .mc_clk(mc_clk_i), .mc_rst_n(mc_rst_no), .mc_init_done(mc_init_done_i), .mc_fatal(mc_fatal_i),
    .mc_cmd_valid(mc_cmd_valid_o), .mc_cmd_ready(mc_cmd_ready_i), .mc_cmd_write(mc_cmd_write_o),
    .mc_cmd_addr(mc_cmd_addr_o), .mc_cmd_len(mc_cmd_len_o), .mc_cmd_tag(mc_cmd_tag_o),
    .mc_wd_valid(mc_wd_valid_o), .mc_wd_ready(mc_wd_ready_i), .mc_wd_data(mc_wd_data_o), .mc_wd_strb(mc_wd_strb_o),
    .mc_wd_last(mc_wd_last_o), .mc_rd_valid(mc_rd_valid_i), .mc_rd_ready(mc_rd_ready_o), .mc_rd_data(mc_rd_data_i),
    .mc_rd_tag(mc_rd_tag_i), .mc_rd_last(mc_rd_last_i), .mc_rd_error(mc_rd_error_i),
    .mc_wr_valid(mc_wr_valid_i), .mc_wr_ready(mc_wr_ready_o), .mc_wr_tag(mc_wr_tag_i), .mc_wr_error(mc_wr_error_i),
    .mem_ready, .sram_busy, .par_evt, .par_addr, .ext_ready, .ext_idle, .ext_fault, .ext_err_evt, .ext_err_addr);

  // ================================================================ RAS / test
  logic die_err_irq;
  ras_test_subsystem #(.TESTCORE_EN(TESTCORE_EN)) u_ras_test (
    .clk, .rst_n(fab_rst_n),
    .rb_sel(ras_sel), .rb_we(d_we), .rb_addr(d_addr), .rb_wdata(d_wdata), .rb_rdata(ras_rdata), .rb_err(ras_err),
    .noc_dec_evt, .noc_dec_master(8'(noc_dec_master)), .noc_dec_addr,
    .host_dec_evt, .host_dec_addr,
    .ext_err_evt, .ext_err_addr, .ext_fatal(ext_fault),
    .dma_err_evt, .dma_err_chan,
    .par_evt, .par_addr,
    .gate_evt(gate_ref_evt || gate_aba_evt), .drain_evt(comp_drain_evt || cc_drain_evt),
    .tsu_halted(|tsu_halted),
    .test_mode(test_mode_i), .pll_locked,
    .err_irq(die_err_irq), .cc_warn, .cc_fatal);
  assign tdo_o    = 1'b0;                          // TestCore not instantiated in this release
  assign tdo_oe_o = 1'b0;

  // ================================================================ die control / status / interrupts
  logic [31:0] irq_raw_u;
  die_sysctrl #(
    .CONFIG_ID(CONFIG_ID), .NV(NV), .NT(NT), .ND(ND), .NBANKS(NUM_SRAM_BANKS), .NSLICES(NSL), .SRAM_BYTES(SRAM_BYTES),
    .NOC_TOPOLOGY(NOC_TOPOLOGY), .EXTMEM_EN(EXTMEM_EN), .EXTMEM_ASYNC(EXTMEM_ASYNC), .TESTCORE_EN(TESTCORE_EN),
    .SRAM_PARITY(SRAM_PARITY), .NOC_NM(NM), .NOC_NT(NTG), .TSU_ROWS(4), .TSU_COLS(4), .VEC_LANES(4)
  ) u_sysctrl (
    .clk, .rst_n(fab_rst_n),
    .rb_sel(sys_sel), .rb_we(d_we), .rb_addr(d_addr), .rb_wdata(d_wdata), .rb_rdata(sys_rdata), .rb_err(sys_err),
    .rst_stage, .reset_done, .mem_ready, .extmem_ready(ext_ready), .cc_running(cc_rst_n),
    .compute_ready(acc_rst_n), .fw_host_ready(cc_host_ready),
    .vec_busy, .tsu_busy, .dma_busy, .extmem_busy(!ext_idle),
    .vec_irq, .tsu_irq, .dma_irq, .die_err_irq, .noc_err_irq(noc_irq), .extmem_irq(ext_fault),
    .cc_host_irq,
    .host_irq(host_irq_o), .cc_vec_irq, .cc_tsu_irq, .platform_ready(platform_ready_o), .device_ready(device_ready_o),
    .irq_raw(irq_raw_u));

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ok = &{1'b0, tck_i, tms_i, tdi_i, trst_ni, host_busy, fab_busy, sram_busy, irq_raw_u, acc_clk_live,
                     x_req_ready, x_rsp_valid, x_rsp_error, x_rsp_rdata, c_req_ready, c_rsp_valid, c_rsp_error, c_rsp_rdata};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
