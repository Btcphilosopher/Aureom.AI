// =============================================================================
// SilicaFlux DieTop :: clock_reset_subsystem -- die clock boundary and
// deterministic reset sequencer
//
// Clocking (docs/CLOCKING.md): ONE functional clock, clk_i, delivered by the
// clock/PLL integration boundary (pll_lock_i).  Nothing in this block divides,
// muxes or crosses clocks.  The only derived clock on the die is the
// ControlCore's ICG-gated accelerator clock (equal edges, same tree).  The
// memory-controller clock mc_clk_i is a separate boundary used only when the
// external-memory bridge's own verified CDC is enabled (EXTMEM_ASYNC = 1).
//
// Reset sequence (all releases synchronous to clk_i; assertion asynchronous
// through por_ni; test_mode_i bypasses the sequencer to por_ni for DFT):
//   POR      por_ni low, or PLL not locked: fabric, memory, DMA, die registers
//            and the ControlCore held in reset.
//   FABRIC   FABRIC_DELAY cycles after (POR released AND PLL locked): fabric,
//            shared SRAM, external-memory bridge, DMA, die registers released.
//   CONTROL  CONTROL_DELAY cycles later: ControlCore released.  Its boot ROM runs;
//            the accelerator domain follows the ControlCore's own reset generator
//            and PMU (acc_rst_no), exactly as in the verified ControlCore system.
//   RUN      one cycle later: sequence complete (DIE_SYS.STATUS.RESET_DONE).
// Loss of PLL lock after release re-runs the sequence from POR (documented
// policy: the functional clock is not trusted without lock).
// Reset synchroniser: PowerClock (Project 27) sf_reset_sync, unmodified.
// Classification: SYNTHESIZABLE (new, Project 31)
// =============================================================================
`default_nettype none

module clock_reset_subsystem
#(
  parameter int FABRIC_DELAY  = 16,
  parameter int CONTROL_DELAY = 16
) (
  input  wire logic       clk_i,
  input  wire logic       por_ni,
  input  wire logic       pll_lock_i,
  input  wire logic       test_mode_i,
  output logic            fab_rst_n,      // fabric / memory / DMA / die registers
  output logic            cc_rst_n,       // ControlCore rst_ni
  output logic [2:0]      stage,
  output logic            reset_done,
  output logic            pll_locked      // synchronised PLL lock
);

  localparam int CW = $clog2(((FABRIC_DELAY > CONTROL_DELAY) ? FABRIC_DELAY : CONTROL_DELAY) + 2);

  // POR synchroniser (async assert, sync release; test_mode bypass)
  logic por_sync_n;
  sf_reset_sync #(.STAGES(2)) u_por_sync (.clk_i, .rst_ni(por_ni), .test_mode_i, .rst_no(por_sync_n));

  // PLL lock: asynchronous status from the clock boundary -> 2-flop synchroniser
  logic lock_m, lock_s;
  always_ff @(posedge clk_i or negedge por_sync_n) begin
    if (!por_sync_n) {lock_s, lock_m} <= 2'b00;
    else             {lock_s, lock_m} <= {lock_m, pll_lock_i};
  end
  assign pll_locked = lock_s;

  logic [2:0]    st_q;
  logic [CW-1:0] cnt_q;
  logic          fab_q, cc_q;
  always_ff @(posedge clk_i or negedge por_sync_n) begin
    if (!por_sync_n) begin
      st_q  <= silicaflux_die_pkg::DIE_RST_STAGE_POR;
      cnt_q <= '0;
      fab_q <= 1'b0;
      cc_q  <= 1'b0;
    end else if (!lock_s) begin                  // no lock: hold (or fall back to) POR
      st_q  <= silicaflux_die_pkg::DIE_RST_STAGE_POR;
      cnt_q <= '0;
      fab_q <= 1'b0;
      cc_q  <= 1'b0;
    end else begin
      unique case (st_q)
        silicaflux_die_pkg::DIE_RST_STAGE_POR: begin
          if (cnt_q == CW'(FABRIC_DELAY)) begin st_q <= silicaflux_die_pkg::DIE_RST_STAGE_FABRIC; fab_q <= 1'b1; cnt_q <= '0; end
          else cnt_q <= cnt_q + 1'b1;
        end
        silicaflux_die_pkg::DIE_RST_STAGE_FABRIC: begin
          if (cnt_q == CW'(CONTROL_DELAY)) begin st_q <= silicaflux_die_pkg::DIE_RST_STAGE_CONTROL; cc_q <= 1'b1; cnt_q <= '0; end
          else cnt_q <= cnt_q + 1'b1;
        end
        silicaflux_die_pkg::DIE_RST_STAGE_CONTROL: st_q <= silicaflux_die_pkg::DIE_RST_STAGE_RUN;
        default: ;                                // RUN: hold
      endcase
    end
  end

  assign fab_rst_n  = test_mode_i ? por_ni : fab_q;
  assign cc_rst_n   = test_mode_i ? por_ni : cc_q;
  assign stage      = st_q;
  assign reset_done = (st_q == silicaflux_die_pkg::DIE_RST_STAGE_RUN);
endmodule

`default_nettype wire
