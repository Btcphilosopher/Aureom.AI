// =============================================================================
// SilicaFlux DieTop :: ras_test_subsystem -- die error log, error forwarding and
// test/debug status (DIE_SYS sub-blocks ERR 0x200 and TEST 0x300)
//
// Error sources (die_pkg DIE_ERR_* codes):
//   NOC_DECODE   fabric decode error (master index, exact address)
//   HOST_DECODE  host bridge: address outside every die region (address)
//   EXTMEM       external-memory bridge error event (address)
//   DMA          die DMA channel received an error response (channel)
//   SRAM_PARITY  shared SRAM parity failure (address)
//   GATE_REFUSED scratchpad window refused / abandoned: compute domain down
//   FENCE_DRAIN  orphan response drained after a compute-domain reset
//   TSU_HALTED   a tensor unit halted (rising edge)
//   EXTMEM_FATAL external-memory controller fatal / calibration failure (rising edge)
// ERR_STATUS bit = code (sticky, W1C); ERR_FIRST / ERR_FIRST_ADDR hold the first
// event since ERR_CTRL[0] (lowest code wins within a cycle); ERR_COUNT counts
// cycles with at least one event (saturating).  With ERR_CTRL[1] (reset 1) every
// event is forwarded as a one-cycle warning to the ControlCore (ext_warn_i ->
// its RAS page, RAS_WARN interrupt); EXTMEM_FATAL also asserts the ControlCore's
// ext_fatal_i while ERR_STATUS[EXTMEM_FATAL] is set.
// The ControlCore keeps its own RAS page (cc_ras, page 16) and parity-protected
// memories.  SECDED / scrubbing (Project 26 RAS) are NOT integrated here.
// TestCore (JTAG TAP, MBIST) is not instantiated in this release (TESTCORE_EN
// must be 0); the TEST sub-block reports the test-mode pin and PLL lock.
// Classification: SYNTHESIZABLE (new, Project 31)
// =============================================================================
`default_nettype none

module ras_test_subsystem
#(
  parameter int TESTCORE_EN = 0
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  // events
  input  wire logic        noc_dec_evt,
  input  wire logic [7:0]  noc_dec_master,
  input  wire logic [31:0] noc_dec_addr,
  input  wire logic        host_dec_evt,
  input  wire logic [31:0] host_dec_addr,
  input  wire logic        ext_err_evt,
  input  wire logic [31:0] ext_err_addr,
  input  wire logic        ext_fatal,       // level
  input  wire logic        dma_err_evt,
  input  wire logic [7:0]  dma_err_chan,
  input  wire logic        par_evt,
  input  wire logic [31:0] par_addr,
  input  wire logic        gate_evt,
  input  wire logic        drain_evt,
  input  wire logic        tsu_halted,      // level (OR of tensor units)
  // test / debug status
  input  wire logic        test_mode,
  input  wire logic        pll_locked,
  // outputs
  output logic             err_irq,
  output logic             cc_warn,
  output logic             cc_fatal
);

  // ---------------------------------------------------------------- edge detection of level sources
  logic halted_q, xfatal_q;
  wire  halted_evt = tsu_halted && !halted_q;
  wire  xfatal_evt = ext_fatal && !xfatal_q;

  // ---------------------------------------------------------------- event vector by code
  logic [31:0] ev;
  always_comb begin
    ev = 32'd0;
    ev[silicaflux_die_pkg::DIE_ERR_NOC_DECODE]   = noc_dec_evt;
    ev[silicaflux_die_pkg::DIE_ERR_HOST_DECODE]  = host_dec_evt;
    ev[silicaflux_die_pkg::DIE_ERR_EXTMEM]       = ext_err_evt;
    ev[silicaflux_die_pkg::DIE_ERR_DMA]          = dma_err_evt;
    ev[silicaflux_die_pkg::DIE_ERR_SRAM_PARITY]  = par_evt;
    ev[silicaflux_die_pkg::DIE_ERR_GATE_REFUSED] = gate_evt;
    ev[silicaflux_die_pkg::DIE_ERR_FENCE_DRAIN]  = drain_evt;
    ev[silicaflux_die_pkg::DIE_ERR_TSU_HALTED]   = halted_evt;
    ev[silicaflux_die_pkg::DIE_ERR_EXTMEM_FATAL] = xfatal_evt;
  end
  // first event of the cycle (lowest code) with its port / address
  logic [7:0]  f_code, f_port;
  logic [31:0] f_addr;
  always_comb begin
    f_code = 8'd0; f_port = 8'd0; f_addr = 32'd0;
    if      (ev[silicaflux_die_pkg::DIE_ERR_NOC_DECODE])   begin f_code = 8'(silicaflux_die_pkg::DIE_ERR_NOC_DECODE);   f_port = noc_dec_master; f_addr = noc_dec_addr; end
    else if (ev[silicaflux_die_pkg::DIE_ERR_HOST_DECODE])  begin f_code = 8'(silicaflux_die_pkg::DIE_ERR_HOST_DECODE);  f_addr = host_dec_addr; end
    else if (ev[silicaflux_die_pkg::DIE_ERR_EXTMEM])       begin f_code = 8'(silicaflux_die_pkg::DIE_ERR_EXTMEM);       f_addr = ext_err_addr; end
    else if (ev[silicaflux_die_pkg::DIE_ERR_DMA])          begin f_code = 8'(silicaflux_die_pkg::DIE_ERR_DMA);          f_port = dma_err_chan; end
    else if (ev[silicaflux_die_pkg::DIE_ERR_SRAM_PARITY])  begin f_code = 8'(silicaflux_die_pkg::DIE_ERR_SRAM_PARITY);  f_addr = par_addr; end
    else if (ev[silicaflux_die_pkg::DIE_ERR_GATE_REFUSED]) begin f_code = 8'(silicaflux_die_pkg::DIE_ERR_GATE_REFUSED); end
    else if (ev[silicaflux_die_pkg::DIE_ERR_FENCE_DRAIN])  begin f_code = 8'(silicaflux_die_pkg::DIE_ERR_FENCE_DRAIN);  end
    else if (ev[silicaflux_die_pkg::DIE_ERR_TSU_HALTED])   begin f_code = 8'(silicaflux_die_pkg::DIE_ERR_TSU_HALTED);   end
    else if (ev[silicaflux_die_pkg::DIE_ERR_EXTMEM_FATAL]) begin f_code = 8'(silicaflux_die_pkg::DIE_ERR_EXTMEM_FATAL); end
  end

  // ---------------------------------------------------------------- registers
  logic [31:0] status_q, first_q, first_addr_q, count_q, drained_q, refused_q;
  logic        fwd_q;
  wire wr = rb_sel && rb_we;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      status_q <= '0; first_q <= '0; first_addr_q <= '0; count_q <= '0; drained_q <= '0; refused_q <= '0;
      fwd_q <= 1'b1; halted_q <= 1'b0; xfatal_q <= 1'b0;
    end else begin
      halted_q <= tsu_halted;
      xfatal_q <= ext_fatal;
      // sticky status: set wins over a same-cycle W1C
      status_q <= (wr && rb_addr == silicaflux_die_pkg::DIE_SYS_ERR_STATUS ? (status_q & ~rb_wdata) : status_q) | ev;
      if (wr && rb_addr == silicaflux_die_pkg::DIE_SYS_ERR_CTRL) begin
        fwd_q <= rb_wdata[1];
        if (rb_wdata[0]) begin first_q <= '0; first_addr_q <= '0; end
      end
      if (|ev && !first_q[31] && !(wr && rb_addr == silicaflux_die_pkg::DIE_SYS_ERR_CTRL && rb_wdata[0])) begin
        first_q      <= {1'b1, 15'd0, f_port, f_code};
        first_addr_q <= f_addr;
      end
      if (|ev && count_q != 32'hFFFF_FFFF)  count_q   <= count_q + 32'd1;
      if (drain_evt && drained_q != 32'hFFFF_FFFF) drained_q <= drained_q + 32'd1;
      if (gate_evt && refused_q != 32'hFFFF_FFFF)  refused_q <= refused_q + 32'd1;
    end
  end

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    unique case (rb_addr)
      silicaflux_die_pkg::DIE_SYS_ERR_STATUS:     rb_rdata = status_q;
      silicaflux_die_pkg::DIE_SYS_ERR_FIRST:      rb_rdata = first_q;
      silicaflux_die_pkg::DIE_SYS_ERR_FIRST_ADDR: rb_rdata = first_addr_q;
      silicaflux_die_pkg::DIE_SYS_ERR_COUNT:      rb_rdata = count_q;
      silicaflux_die_pkg::DIE_SYS_ERR_CTRL:       rb_rdata = {30'd0, fwd_q, 1'b0};
      silicaflux_die_pkg::DIE_SYS_FENCE_DRAINED:  rb_rdata = drained_q;
      silicaflux_die_pkg::DIE_SYS_GATE_REFUSED:   rb_rdata = refused_q;
      silicaflux_die_pkg::DIE_SYS_TEST_STATUS:    rb_rdata = {29'd0, 1'(TESTCORE_EN != 0), pll_locked, test_mode};
      default:                rb_err   = rb_sel;
    endcase
    if (rb_sel && rb_we && !(rb_addr == silicaflux_die_pkg::DIE_SYS_ERR_STATUS || rb_addr == silicaflux_die_pkg::DIE_SYS_ERR_CTRL)) rb_err = 1'b1;
  end

  assign err_irq  = |status_q;
  assign cc_warn  = fwd_q && |ev;
  assign cc_fatal = fwd_q && status_q[silicaflux_die_pkg::DIE_ERR_EXTMEM_FATAL];

  // ---------------------------------------------------------------- elaboration check
  if (TESTCORE_EN != 0) begin : g_err_testcore
    $fatal(1, "ras_test_subsystem: TESTCORE_EN = 1 is not supported in this release (TestCore owns the clock root; see docs/CLOCKING.md)");
  end
endmodule

`default_nettype wire
