// =============================================================================
// SilicaFlux DieTop :: die_regs_window -- the DIE_REGS fabric region
//
//   NoC target REGS (SFB2) ─► sfb_v1_slave_adapter (DataFabric, UNMODIFIED)
//                          ─► sfv_periph_bridge (SilicaFlux-V, UNMODIFIED; page = addr[16:12])
//        page 0 DIE_SYS   ─► 0x000-0x1FF die_sysctrl (CTRL, IRQ)
//                           0x200-0x3FF ras_test_subsystem (ERR, TEST)   other offsets: rb_err
//        page 1 NOC_PERF  ─► datafabric (sfn_perf)
//        page 2 DMA       ─► dma_subsystem (channel c at c * 0x100)
//
// This is the same SFB2 -> register-bus chain the ControlCore uses for its own
// pages.  32-bit accesses only: a sub-word write, an absent page or a refused
// register answers rsp_error = 1 with no side effect.  Because the window is on
// the fabric (not behind the ControlCore's forwarded pages), die status, error
// log and DMA stay reachable while the accelerator domain is isolated.
// Classification: SYNTHESIZABLE (new, Project 31)
// =============================================================================
`default_nettype none

module die_regs_window
(
  input  wire logic        clk,
  input  wire logic        rst_n,
  // SFB2 slave (NoC target REGS)
  input  wire logic        req_valid,
  output logic             req_ready,
  input  wire logic        req_write,
  input  wire logic [31:0] req_addr,
  input  wire logic [31:0] req_wdata,
  input  wire logic [3:0]  req_wstrb,
  output logic             rsp_valid,
  input  wire logic        rsp_ready,
  output logic [31:0]      rsp_rdata,
  output logic             rsp_error,
  // register-bus fan-out (shared we / addr / wdata)
  output logic             rb_we,
  output logic [11:0]      rb_addr,
  output logic [31:0]      rb_wdata,
  output logic             sys_sel,
  input  wire logic [31:0] sys_rdata,
  input  wire logic        sys_err,
  output logic             ras_sel,
  input  wire logic [31:0] ras_rdata,
  input  wire logic        ras_err,
  output logic             noc_sel,
  input  wire logic [31:0] noc_rdata,
  input  wire logic        noc_err,
  output logic             dma_sel,
  input  wire logic [31:0] dma_rdata,
  input  wire logic        dma_err
);

  localparam int          NP      = 32;
  localparam logic [31:0] PAGE_EN = (32'd1 << silicaflux_die_pkg::DIE_REGS_PAGE_SYS) | (32'd1 << silicaflux_die_pkg::DIE_REGS_PAGE_NOC_PERF) |
                                    (32'd1 << silicaflux_die_pkg::DIE_REGS_PAGE_DMA);

  logic        v1_req, v1_gnt, v1_we, v1_rvalid, v1_err;
  logic [31:0] v1_addr, v1_wdata, v1_rdata;
  logic [3:0]  v1_be;
  sfb_v1_slave_adapter u_v1 (
    .clk, .rst_n,
    .req_valid, .req_ready, .req_write, .req_addr, .req_wdata, .req_wstrb,
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_error,
    .v1_req, .v1_gnt, .v1_addr, .v1_we, .v1_be, .v1_wdata, .v1_rvalid, .v1_rdata, .v1_err);

  logic [NP-1:0]    pg_sel, pg_err;
  logic [NP*32-1:0] pg_rdata;
  sfv_periph_bridge #(.NP(NP), .PAGE_EN(PAGE_EN)) u_bridge (
    .clk, .rst_n,
    .req(v1_req), .gnt(v1_gnt), .addr(v1_addr), .we(v1_we), .be(v1_be), .wdata(v1_wdata),
    .rvalid(v1_rvalid), .rdata(v1_rdata), .err(v1_err),
    .rb_sel(pg_sel), .rb_we, .rb_addr, .rb_wdata, .rb_rdata(pg_rdata), .rb_err(pg_err));

  // DIE_SYS page: split between die_sysctrl (0x000-0x1FF) and ras_test_subsystem (0x200-0x3FF)
  wire s_sys = pg_sel[silicaflux_die_pkg::DIE_REGS_PAGE_SYS];
  wire o_ctl = rb_addr[11:9] == 3'b000;
  wire o_ras = rb_addr[11:9] == 3'b001;
  assign sys_sel = s_sys && o_ctl;
  assign ras_sel = s_sys && o_ras;
  assign noc_sel = pg_sel[silicaflux_die_pkg::DIE_REGS_PAGE_NOC_PERF];
  assign dma_sel = pg_sel[silicaflux_die_pkg::DIE_REGS_PAGE_DMA];

  always_comb begin
    pg_rdata = '0;
    pg_err   = '1;
    pg_rdata[silicaflux_die_pkg::DIE_REGS_PAGE_SYS*32 +: 32]      = o_ctl ? sys_rdata : o_ras ? ras_rdata : 32'd0;
    pg_err[silicaflux_die_pkg::DIE_REGS_PAGE_SYS]                 = o_ctl ? sys_err : o_ras ? ras_err : 1'b1;
    pg_rdata[silicaflux_die_pkg::DIE_REGS_PAGE_NOC_PERF*32 +: 32] = noc_rdata;
    pg_err[silicaflux_die_pkg::DIE_REGS_PAGE_NOC_PERF]            = noc_err;
    pg_rdata[silicaflux_die_pkg::DIE_REGS_PAGE_DMA*32 +: 32]      = dma_rdata;
    pg_err[silicaflux_die_pkg::DIE_REGS_PAGE_DMA]                 = dma_err;
  end
endmodule

`default_nettype wire
