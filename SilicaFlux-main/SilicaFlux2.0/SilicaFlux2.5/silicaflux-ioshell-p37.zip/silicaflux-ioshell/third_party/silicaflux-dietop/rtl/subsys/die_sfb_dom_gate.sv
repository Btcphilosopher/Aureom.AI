// =============================================================================
// SilicaFlux DieTop :: die_sfb_dom_gate -- SFB2 target-side gate into the
// gated / resettable accelerator domain (vector-tile scratchpad window)
//
//   NoC target bridge (clk, fabric reset) ─► die_sfb_dom_gate ─► tile hs_* (acc_clk, acc reset)
//
// The accelerator domain runs on the ControlCore's ICG-gated copy of clk and
// can be reset by the ControlCore at any time.  An SFB2 handshake across that
// boundary is only real if the accelerator clock ticks on the handshake edge,
// and a transaction is lost if the domain is reset while it is outstanding.
//
// Clock-request protocol (relies on cc_pmu: clk_on_q <= CLK_EN || busy, where
// busy includes acc_vec_busy_i, which is not synchronised -- see docs/CLOCKING.md):
//   * dom_busy is raised the cycle a request is first seen (IDLE) and stays
//     high until its response has been delivered upstream.  The PMU samples it
//     at the next edge, so from the following cycle on clk_on_q = 1 and every
//     edge ticks the accelerator clock.  The request is therefore presented to
//     the tile only one cycle later (ARM -> FWD): every handshake with the tile
//     happens on an edge where the tile's clock ticks.
//   * requests arriving while the domain is in reset or its clock has been
//     observed stopped (dom_clk_live = 0) are refused: accepted locally and
//     answered with rsp_error = 1, rdata = 0 (SFB2 R8); nothing reaches the tile.
//   * if the domain is reset while a request is presented or outstanding, the
//     transaction is abandoned and answered with an error (the tile, being in
//     reset, can never answer it; no late response is possible after reset).
// One transaction at a time (the NoC target bridge of a scratchpad window is
// built with DEPTH = 1, SFB2 one-transaction rule), so ordering is preserved.
// Classification: SYNTHESIZABLE (new, Project 31)
// =============================================================================
`default_nettype none

module die_sfb_dom_gate (
  input  wire logic        clk,
  input  wire logic        rst_n,          // fabric reset (async assert, sync release)
  input  wire logic        dom_rst_n,      // accelerator-domain reset, synchronous to clk
  input  wire logic        dom_clk_live,   // accelerator clock ticked on the last edge
  // upstream (NoC target bridge)
  input  wire logic        s_req_valid,
  output logic             s_req_ready,
  input  wire logic        s_req_write,
  input  wire logic [31:0] s_req_addr,
  input  wire logic [31:0] s_req_wdata,
  input  wire logic [3:0]  s_req_wstrb,
  output logic             s_rsp_valid,
  input  wire logic        s_rsp_ready,
  output logic [31:0]      s_rsp_rdata,
  output logic             s_rsp_error,
  // downstream (tile host scratchpad port, accelerator domain)
  output logic             m_req_valid,
  input  wire logic        m_req_ready,
  output logic             m_req_write,
  output logic [31:0]      m_req_addr,
  output logic [31:0]      m_req_wdata,
  output logic [3:0]       m_req_wstrb,
  input  wire logic        m_rsp_valid,
  output logic             m_rsp_ready,
  input  wire logic [31:0] m_rsp_rdata,
  input  wire logic        m_rsp_error,
  // status
  output logic             dom_busy,       // clock request / activity, to the ControlCore busy input
  output logic             refused_evt,    // pulse: request refused (domain down)
  output logic             abandoned_evt   // pulse: outstanding transaction abandoned by a domain reset
);
  typedef enum logic [2:0] {S_IDLE, S_ARM, S_FWD, S_OUT, S_LOC} st_t;
  st_t st_q, st_d;

  wire dom_ok = dom_rst_n && dom_clk_live;

  always_comb begin
    st_d          = st_q;
    s_req_ready   = 1'b0;
    m_req_valid   = 1'b0;
    m_rsp_ready   = 1'b0;
    s_rsp_valid   = 1'b0;
    s_rsp_rdata   = 32'd0;
    s_rsp_error   = 1'b0;
    refused_evt   = 1'b0;
    abandoned_evt = 1'b0;
    unique case (st_q)
      S_IDLE: if (s_req_valid) begin
        if (!dom_ok) begin                       // refuse locally
          s_req_ready = 1'b1;
          refused_evt = 1'b1;
          st_d        = S_LOC;
        end else begin
          st_d        = S_ARM;                   // request the clock first (dom_busy below)
        end
      end
      S_ARM: begin
        if (!dom_rst_n) begin
          s_req_ready = 1'b1;
          refused_evt = 1'b1;
          st_d        = S_LOC;
        end else begin
          st_d = S_FWD;
        end
      end
      S_FWD: begin
        if (!dom_rst_n) begin                    // domain reset before acceptance: refuse
          s_req_ready = 1'b1;
          refused_evt = 1'b1;
          st_d        = S_LOC;
        end else begin
          m_req_valid = 1'b1;
          s_req_ready = m_req_ready;
          if (m_req_ready) st_d = S_OUT;
        end
      end
      S_OUT: begin
        if (!dom_rst_n) begin                    // lost to a domain reset: answer with an error
          abandoned_evt = 1'b1;
          st_d          = S_LOC;
        end else begin
          s_rsp_valid = m_rsp_valid;
          s_rsp_rdata = m_rsp_rdata;
          s_rsp_error = m_rsp_error;
          m_rsp_ready = s_rsp_ready;
          if (m_rsp_valid && s_rsp_ready) st_d = S_IDLE;
        end
      end
      S_LOC: begin
        s_rsp_valid = 1'b1;
        s_rsp_error = 1'b1;
        if (s_rsp_ready) st_d = S_IDLE;
      end
      default: st_d = S_IDLE;
    endcase
  end

  assign m_req_write = s_req_write;
  assign m_req_addr  = s_req_addr;
  assign m_req_wdata = s_req_wdata;
  assign m_req_wstrb = s_req_wstrb;

  // clock request: raised combinationally on first sight of a request the gate
  // will forward, held through ARM / FWD / OUT (the response handshake included)
  assign dom_busy = (st_q == S_ARM) || (st_q == S_FWD) || (st_q == S_OUT) ||
                    (st_q == S_IDLE && s_req_valid && dom_ok);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) st_q <= S_IDLE;
    else        st_q <= st_d;
  end
endmodule

`default_nettype wire
