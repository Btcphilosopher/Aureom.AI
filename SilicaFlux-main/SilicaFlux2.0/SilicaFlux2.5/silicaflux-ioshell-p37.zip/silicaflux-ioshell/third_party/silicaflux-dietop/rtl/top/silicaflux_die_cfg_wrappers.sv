// =============================================================================
// SilicaFlux DieTop :: documented configuration wrappers
//
//   silicaflux_die_min -- SILICAFLUX_MIN (bring-up; end-to-end RTL workload)
//   silicaflux_die_hpc -- SILICAFLUX_HPC (ARCHITECTURAL EXPLORATION until validated)
//
// Both are silicaflux_die_top with the parameter set of silicaflux_config_pkg
// (generated from config/silicaflux_die.yaml) and the same port list; they exist
// so synthesis, hierarchy reports and floorplanning scripts can name a fixed top.
// Classification: SYNTHESIZABLE (new, Project 31)
// =============================================================================
`include "sram_defs.svh"
`default_nettype none
/* verilator lint_off DECLFILENAME */

`define SFD_WRAPPER_PORTS \
  input  wire logic clk_i, input wire logic por_ni, input wire logic pll_lock_i, input wire logic test_mode_i, \
  input  wire logic [1:0] boot_mode_i, input wire logic host_rst_req_i, \
  input  wire logic host_req_valid_i, output logic host_req_ready_o, input wire logic host_req_write_i, \
  input  wire logic [31:0] host_req_addr_i, input wire logic [31:0] host_req_wdata_i, input wire logic [3:0] host_req_wstrb_i, \
  output logic host_rsp_valid_o, input wire logic host_rsp_ready_i, output logic [31:0] host_rsp_rdata_o, \
  output logic host_rsp_error_o, output logic host_irq_o, output logic platform_ready_o, output logic device_ready_o, \
  input  wire logic mc_clk_i, output logic mc_rst_no, input wire logic mc_init_done_i, input wire logic mc_fatal_i, \
  output logic mc_cmd_valid_o, input wire logic mc_cmd_ready_i, output logic mc_cmd_write_o, output logic [25:0] mc_cmd_addr_o, \
  output logic [7:0] mc_cmd_len_o, output logic [1:0] mc_cmd_tag_o, output logic mc_wd_valid_o, input wire logic mc_wd_ready_i, \
  output logic [31:0] mc_wd_data_o, output logic [3:0] mc_wd_strb_o, output logic mc_wd_last_o, \
  input  wire logic mc_rd_valid_i, output logic mc_rd_ready_o, input wire logic [31:0] mc_rd_data_i, \
  input  wire logic [1:0] mc_rd_tag_i, input wire logic mc_rd_last_i, input wire logic mc_rd_error_i, \
  input  wire logic mc_wr_valid_i, output logic mc_wr_ready_o, input wire logic [1:0] mc_wr_tag_i, input wire logic mc_wr_error_i, \
  input  wire logic tck_i, input wire logic tms_i, input wire logic tdi_i, input wire logic trst_ni, \
  output logic tdo_o, output logic tdo_oe_o, \
  input  wire logic ext_warn_i, input wire logic ext_fatal_i, output logic ras_fatal_o, \
  output logic diag_valid_o, output logic [7:0] diag_char_o, output logic test_done_o, output logic test_fail_o, \
  output logic [15:0] test_code_o, output logic cpu_sleep_o

module silicaflux_die_min
#(parameter int SRAM_BACKEND = `SRAM_BACKEND_GENERIC) (`SFD_WRAPPER_PORTS);

  silicaflux_die_top #(
    .NUM_VECTOR_CLUSTERS(silicaflux_config_pkg::MIN_NUM_VECTOR_CLUSTERS), .NUM_TENSOR_CLUSTERS(silicaflux_config_pkg::MIN_NUM_TENSOR_CLUSTERS),
    .NUM_SRAM_BANKS(silicaflux_config_pkg::MIN_NUM_SRAM_BANKS), .NUM_SRAM_SLICES(silicaflux_config_pkg::MIN_NUM_SRAM_SLICES), .SRAM_BYTES(silicaflux_config_pkg::MIN_SRAM_BYTES),
    .NUM_DMA_CHANNELS(silicaflux_config_pkg::MIN_NUM_DMA_CHANNELS), .NOC_TOPOLOGY(silicaflux_config_pkg::MIN_NOC_TOPOLOGY), .EXTMEM_EN(silicaflux_config_pkg::MIN_EXTMEM_EN),
    .TESTCORE_EN(silicaflux_config_pkg::MIN_TESTCORE_EN), .SRAM_BACKEND(SRAM_BACKEND), .CONFIG_ID(silicaflux_config_pkg::MIN_CONFIG_ID)
  ) u_die (.*);
endmodule

module silicaflux_die_hpc
#(parameter int SRAM_BACKEND = `SRAM_BACKEND_GENERIC) (`SFD_WRAPPER_PORTS);

  silicaflux_die_top #(
    .NUM_VECTOR_CLUSTERS(silicaflux_config_pkg::HPC_NUM_VECTOR_CLUSTERS), .NUM_TENSOR_CLUSTERS(silicaflux_config_pkg::HPC_NUM_TENSOR_CLUSTERS),
    .NUM_SRAM_BANKS(silicaflux_config_pkg::HPC_NUM_SRAM_BANKS), .NUM_SRAM_SLICES(silicaflux_config_pkg::HPC_NUM_SRAM_SLICES), .SRAM_BYTES(silicaflux_config_pkg::HPC_SRAM_BYTES),
    .NUM_DMA_CHANNELS(silicaflux_config_pkg::HPC_NUM_DMA_CHANNELS), .NOC_TOPOLOGY(silicaflux_config_pkg::HPC_NOC_TOPOLOGY), .EXTMEM_EN(silicaflux_config_pkg::HPC_EXTMEM_EN),
    .TESTCORE_EN(silicaflux_config_pkg::HPC_TESTCORE_EN), .SRAM_BACKEND(SRAM_BACKEND), .CONFIG_ID(silicaflux_config_pkg::HPC_CONFIG_ID)
  ) u_die (.*);
endmodule

`undef SFD_WRAPPER_PORTS
/* verilator lint_on DECLFILENAME */
`default_nettype wire
