// =============================================================================
// SilicaFlux MCU-I :: mcu_uart -- UART with TX/RX FIFOs, parity, 1/2 stop bits
//
// Derived from third_party/silicaflux-v/rtl/periph/sfv_uart.sv (8N1, FIFOs,
// framing/overrun detection, register offsets 0x0..0xC kept so SilicaFlux-V
// console code runs unchanged).  Added for MCU-I: even/odd parity generation
// and checking, 2 stop bits, parity-error flag, FIFO counts, RX_FULL, error
// interrupt, DMA request outputs, error event for the fault log, bus error on
// writes to read-only registers.  Register map: docs/REGISTERS.md `uart`.
//
// Frame: start, d0..d7 (LSB first), [parity], stop, [stop2].  Separate TX and
// RX engines, each clocked by its own bit-period counter (BAUD clk cycles).
// RX: 2-flop synchroniser, start bit validated at mid-bit (glitches shorter
// than half a bit are rejected), data/parity/stop sampled at mid-bit; only the
// first stop bit is checked.  A byte with a framing error is dropped; a byte
// with a parity error is stored (PARITY_ERR flags it).
// Deterministic FIFO behaviour: TX push while full -> byte dropped, TX_OVF;
// RX byte while full -> byte dropped, RX_OVF; DATA read while empty ->
// RX_EMPTY=1, no pop.
// DMA requests: dreq_tx = TX FIFO not full, dreq_rx = RX FIFO not empty.  One
// DMA element per request level check: the DMA re-samples the level only
// after its previous access completed (>= 2 cycles after the pop/push).
// =============================================================================
`default_nettype none

module mcu_uart #(
  parameter int          FIFO_DEPTH = 8,
  parameter logic [15:0] BAUD_RESET = 16'd217        // 25 MHz / 115200
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  output logic             txd,
  input  wire logic        rxd,
  output logic             irq,
  output logic             dreq_tx,
  output logic             dreq_rx,
  output logic             err_evt        // a framing/parity/overrun error occurred (pulse)
);
  localparam int CW = $clog2(FIFO_DEPTH) + 1;
  localparam logic [11:0] A_DATA = mcu_memmap_pkg::UART_DATA;
  localparam logic [11:0] A_STAT = mcu_memmap_pkg::UART_STATUS;
  localparam logic [11:0] A_CTRL = mcu_memmap_pkg::UART_CTRL;
  localparam logic [11:0] A_BAUD = mcu_memmap_pkg::UART_BAUD;

  logic [15:0] baud_q;
  logic        tx_ien_q, rx_ien_q, loop_q, stop2_q, err_ien_q;
  logic [1:0]  par_q;
  logic        rx_ovf_q, frm_err_q, tx_ovf_q, par_err_q;

  wire wr = rb_sel && rb_we;
  wire rd = rb_sel && !rb_we;
  wire par_on  = (par_q == 2'd1) || (par_q == 2'd2);
  wire par_odd = (par_q == 2'd2);

  // ------------------------------------------------------------ TX
  logic [7:0] txf_q;  logic txf_empty, txf_full; logic [CW-1:0] txf_cnt;
  logic       tx_pop;
  sfv_fifo #(.WIDTH(8), .DEPTH(FIFO_DEPTH)) u_txf (
    .clk, .rst_n, .clr(1'b0), .push(wr && rb_addr == A_DATA), .wdata(rb_wdata[7:0]),
    .pop(tx_pop), .rdata(txf_q), .empty(txf_empty), .full(txf_full), .count(txf_cnt));

  // bit index: 0 start, 1..8 data, 9 parity (if enabled), then stop bit(s)
  logic        tx_busy;
  logic [3:0]  tx_bit;
  logic [15:0] tx_cnt;
  logic [7:0]  tx_sh;
  logic        tx_par;
  wire  [3:0]  tx_last = 4'd9 + {3'd0, par_on} + {3'd0, stop2_q};   // index of the last stop bit
  assign tx_pop = !tx_busy && !txf_empty;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tx_busy <= 1'b0; tx_bit <= '0; tx_cnt <= '0; tx_sh <= '0; tx_par <= 1'b0; txd <= 1'b1;
    end else if (!tx_busy) begin
      txd <= 1'b1;
      if (tx_pop) begin
        tx_busy <= 1'b1; tx_bit <= 4'd0; tx_cnt <= baud_q - 16'd1;
        tx_sh   <= txf_q; tx_par <= (^txf_q) ^ par_odd;
        txd     <= 1'b0;                                     // start bit
      end
    end else if (tx_cnt != 16'd0) begin
      tx_cnt <= tx_cnt - 16'd1;
    end else begin
      tx_cnt <= baud_q - 16'd1;
      if (tx_bit == tx_last) begin
        tx_busy <= 1'b0; txd <= 1'b1;
      end else begin
        tx_bit <= tx_bit + 4'd1;
        if (tx_bit <= 4'd7) begin                            // next: data bit tx_bit
          txd <= tx_sh[0]; tx_sh <= {1'b0, tx_sh[7:1]};
        end else if (tx_bit == 4'd8 && par_on) begin         // next: parity
          txd <= tx_par;
        end else begin                                       // next: stop bit(s)
          txd <= 1'b1;
        end
      end
    end
  end

  // ------------------------------------------------------------ RX
  logic rxd_s;
  sfv_sync #(.STAGES(2), .RESET_VAL(1'b1)) u_rxs (.clk, .rst_n, .d(loop_q ? txd : rxd), .q(rxd_s));

  logic        rx_busy;
  logic [3:0]  rx_bit;
  logic [15:0] rx_cnt;
  logic [7:0]  rx_sh;
  logic        rx_par_bad, rx_push, rx_frame_bad, rx_perr;
  logic [7:0]  rxf_q; logic rxf_empty, rxf_full; logic [CW-1:0] rxf_cnt;
  wire  [3:0]  rx_stop = 4'd9 + {3'd0, par_on};             // index of the (first) stop bit
  sfv_fifo #(.WIDTH(8), .DEPTH(FIFO_DEPTH)) u_rxf (
    .clk, .rst_n, .clr(1'b0), .push(rx_push), .wdata(rx_sh),
    .pop(rd && rb_addr == A_DATA), .rdata(rxf_q), .empty(rxf_empty), .full(rxf_full), .count(rxf_cnt));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rx_busy <= 1'b0; rx_bit <= '0; rx_cnt <= '0; rx_sh <= '0; rx_par_bad <= 1'b0;
      rx_push <= 1'b0; rx_frame_bad <= 1'b0; rx_perr <= 1'b0;
    end else begin
      rx_push      <= 1'b0;
      rx_frame_bad <= 1'b0;
      rx_perr      <= 1'b0;
      if (!rx_busy) begin
        if (!rxd_s) begin                                    // start edge
          rx_busy <= 1'b1; rx_bit <= 4'd0; rx_cnt <= {1'b0, baud_q[15:1]};
        end
      end else if (rx_cnt != 16'd0) begin
        rx_cnt <= rx_cnt - 16'd1;
      end else begin
        rx_cnt <= baud_q - 16'd1;
        if (rx_bit == 4'd0) begin
          if (rxd_s) rx_busy <= 1'b0;                        // glitch: abort
          else       rx_bit  <= 4'd1;
        end else if (rx_bit <= 4'd8) begin
          rx_sh  <= {rxd_s, rx_sh[7:1]};
          rx_bit <= rx_bit + 4'd1;
        end else if (rx_bit == 4'd9 && par_on) begin         // parity bit
          rx_par_bad <= (^rx_sh) ^ rxd_s ^ par_odd;
          rx_bit     <= rx_bit + 4'd1;
        end else begin                                       // stop bit (rx_stop)
          rx_busy <= 1'b0;
          if (rxd_s) begin
            rx_push <= 1'b1;
            rx_perr <= par_on && rx_par_bad;
          end else begin
            rx_frame_bad <= 1'b1;
          end
        end
      end
    end
  end
  wire unused_stop = ^rx_stop;

  // ------------------------------------------------------------ registers
  wire rx_ovf_evt = rx_push && rxf_full;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      baud_q <= BAUD_RESET; tx_ien_q <= 1'b0; rx_ien_q <= 1'b0; loop_q <= 1'b0;
      par_q <= 2'd0; stop2_q <= 1'b0; err_ien_q <= 1'b0;
      rx_ovf_q <= 1'b0; frm_err_q <= 1'b0; tx_ovf_q <= 1'b0; par_err_q <= 1'b0;
    end else begin
      if (rx_ovf_evt)                          rx_ovf_q  <= 1'b1;
      if (rx_frame_bad)                        frm_err_q <= 1'b1;
      if (rx_perr)                             par_err_q <= 1'b1;
      if (wr && rb_addr == A_DATA && txf_full) tx_ovf_q  <= 1'b1;
      if (wr && rb_addr == A_STAT) begin
        if (rb_wdata[3]) rx_ovf_q  <= 1'b0;
        if (rb_wdata[4]) frm_err_q <= 1'b0;
        if (rb_wdata[5]) tx_ovf_q  <= 1'b0;
        if (rb_wdata[6]) par_err_q <= 1'b0;
      end
      if (wr && rb_addr == A_CTRL) begin
        tx_ien_q <= rb_wdata[0]; rx_ien_q <= rb_wdata[1]; loop_q <= rb_wdata[2];
        par_q    <= rb_wdata[4:3]; stop2_q <= rb_wdata[5]; err_ien_q <= rb_wdata[6];
      end
      if (wr && rb_addr == A_BAUD) baud_q <= (rb_wdata[15:0] < 16'd4) ? 16'd4 : rb_wdata[15:0];
    end
  end

  wire tx_idle  = txf_empty && !tx_busy;
  wire any_err  = rx_ovf_q || frm_err_q || tx_ovf_q || par_err_q;
  wire [4:0] rxc = 5'(rxf_cnt);
  wire [4:0] txc = 5'(txf_cnt);
  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    case (rb_addr)
      A_DATA: rb_rdata = {rxf_empty, 23'd0, rxf_empty ? 8'd0 : rxf_q};
      A_STAT: rb_rdata = {11'd0, txc, 3'd0, rxc, rxf_full, par_err_q, tx_ovf_q, frm_err_q,
                          rx_ovf_q, !rxf_empty, tx_idle, !txf_full};
      A_CTRL: rb_rdata = {25'd0, err_ien_q, stop2_q, par_q, loop_q, rx_ien_q, tx_ien_q};
      A_BAUD: rb_rdata = {16'd0, baud_q};
      default: rb_err  = 1'b1;
    endcase
  end
  assign irq     = (tx_ien_q && tx_idle) || (rx_ien_q && !rxf_empty) || (err_ien_q && any_err);
  assign dreq_tx = !txf_full;
  assign dreq_rx = !rxf_empty;
  assign err_evt = rx_ovf_evt || rx_frame_bad || rx_perr;
  wire unused_ok = ^{rb_wdata[31:16]};
endmodule

`default_nettype wire
