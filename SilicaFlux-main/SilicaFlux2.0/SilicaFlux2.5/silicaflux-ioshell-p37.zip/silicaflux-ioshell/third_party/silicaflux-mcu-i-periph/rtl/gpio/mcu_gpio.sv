// =============================================================================
// SilicaFlux MCU-I :: mcu_gpio -- general-purpose I/O
//
// Derived from third_party/silicaflux-v/rtl/periph/sfv_periph_misc.sv
// (sfv_gpio: IN/OUT/OE/edge enables/W1C pending at offsets 0x00..0x14 kept).
// Added for MCU-I: width up to 32, atomic OUT_SET/OUT_CLR/OUT_TGL, level-high
// and level-low interrupts, IRQ_STATUS, bus error on read-only writes.
// Register map: docs/REGISTERS.md block `gpio`.
//
// Inputs pass a 2-flop synchroniser (sfv_sync) per pin; edges are detected
// between consecutive synchronised samples.  Sampling limitations: a pulse
// shorter than one clk period may be missed entirely, and a pulse must be
// stable for >= 2 clk periods to be guaranteed to produce an edge event;
// the input-to-IN latency is 2 clk cycles (+1 for IRQ_PEND).  Pads, output
// drivers, pull-ups and ESD protection are NOT part of this RTL; they come
// from the foundry I/O library (docs/ASIC.md).
// =============================================================================
`default_nettype none

module mcu_gpio #(
  parameter int N = 16
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         rb_sel,
  input  wire logic         rb_we,
  input  wire logic [11:0]  rb_addr,
  input  wire logic [31:0]  rb_wdata,
  output logic [31:0]       rb_rdata,
  output logic              rb_err,
  input  wire logic [N-1:0] gpio_i,
  output logic [N-1:0]      gpio_o,
  output logic [N-1:0]      gpio_oe,
  output logic [N-1:0]      gpio_in_sync,   // synchronised inputs (timer capture etc.)
  output logic              irq
);
  localparam logic [11:0] A_IN       = mcu_memmap_pkg::GPIO_IN;
  localparam logic [11:0] A_OUT      = mcu_memmap_pkg::GPIO_OUT;
  localparam logic [11:0] A_OE       = mcu_memmap_pkg::GPIO_OE;
  localparam logic [11:0] A_RISE     = mcu_memmap_pkg::GPIO_IRQ_RISE_EN;
  localparam logic [11:0] A_FALL     = mcu_memmap_pkg::GPIO_IRQ_FALL_EN;
  localparam logic [11:0] A_PEND     = mcu_memmap_pkg::GPIO_IRQ_PEND;
  localparam logic [11:0] A_SET      = mcu_memmap_pkg::GPIO_OUT_SET;
  localparam logic [11:0] A_CLR      = mcu_memmap_pkg::GPIO_OUT_CLR;
  localparam logic [11:0] A_TGL      = mcu_memmap_pkg::GPIO_OUT_TGL;
  localparam logic [11:0] A_HIGH     = mcu_memmap_pkg::GPIO_IRQ_HIGH_EN;
  localparam logic [11:0] A_LOW      = mcu_memmap_pkg::GPIO_IRQ_LOW_EN;
  localparam logic [11:0] A_STATUS   = mcu_memmap_pkg::GPIO_IRQ_STATUS;

  logic [N-1:0] in_s, in_q, rise_q, fall_q, pend_q, high_q, low_q;
  wire wr = rb_sel && rb_we;
  wire [N-1:0] wd = rb_wdata[N-1:0];

  genvar g;
  for (g = 0; g < N; g++) begin : g_sync
    sfv_sync u_s (.clk, .rst_n, .d(gpio_i[g]), .q(in_s[g]));
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      in_q <= '0; gpio_o <= '0; gpio_oe <= '0; rise_q <= '0; fall_q <= '0; pend_q <= '0;
      high_q <= '0; low_q <= '0;
    end else begin
      in_q <= in_s;
      if (wr) begin
        case (rb_addr)
          A_OUT:  gpio_o  <= wd;
          A_SET:  gpio_o  <= gpio_o | wd;
          A_CLR:  gpio_o  <= gpio_o & ~wd;
          A_TGL:  gpio_o  <= gpio_o ^ wd;
          A_OE:   gpio_oe <= wd;
          A_RISE: rise_q  <= wd;
          A_FALL: fall_q  <= wd;
          A_HIGH: high_q  <= wd;
          A_LOW:  low_q   <= wd;
          default: ;
        endcase
      end
      pend_q <= (pend_q & ~((wr && rb_addr == A_PEND) ? wd : {N{1'b0}}))
              | (rise_q & in_s & ~in_q) | (fall_q & ~in_s & in_q);
    end
  end
  wire [N-1:0] lvl = (high_q & in_s) | (low_q & ~in_s);
  wire [N-1:0] st  = pend_q | lvl;
  assign irq = |st;
  assign gpio_in_sync = in_s;
  if (N < 32) begin : g_unused
    wire unused_ok = ^rb_wdata[31:N];
  end

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    case (rb_addr)
      A_IN:     begin rb_rdata[N-1:0] = in_s; rb_err = rb_we; end
      A_OUT:    rb_rdata[N-1:0] = gpio_o;
      A_OE:     rb_rdata[N-1:0] = gpio_oe;
      A_RISE:   rb_rdata[N-1:0] = rise_q;
      A_FALL:   rb_rdata[N-1:0] = fall_q;
      A_PEND:   rb_rdata[N-1:0] = pend_q;
      A_SET, A_CLR, A_TGL: rb_rdata = 32'd0;
      A_HIGH:   rb_rdata[N-1:0] = high_q;
      A_LOW:    rb_rdata[N-1:0] = low_q;
      A_STATUS: begin rb_rdata[N-1:0] = st; rb_err = rb_we; end
      default:  rb_err = 1'b1;
    endcase
  end
endmodule

`default_nettype wire
