// =============================================================================
// SilicaFlux MCU-I :: mcu_spi -- SPI master (modes 0-3, 8/16/32-bit frames)
//
// Derived from third_party/silicaflux-v/rtl/periph/sfv_spi.sv (edge
// sequencer, CPOL/CPHA handling, DIV semantics, register offsets kept).
// Added for MCU-I: frame length 8/16/32 bits, 4 chip selects, RX_VALID /
// RX_OVF, RX_AUTO mode and DMA request outputs.  Register map:
// docs/REGISTERS.md block `spi`.
//
// Full duplex, MSB first.  A frame of L bits produces 2L SCK edges; with
// CPHA = 0 data is sampled on leading (odd-numbered) edges and shifted on
// trailing edges, with CPHA = 1 the other way round.  SCK idles at CPOL.
// Chip selects are software controlled (CTRL.CS) so multi-frame flash
// commands keep CS asserted.  This controller is also the boot-flash
// interface (SPI0, CS0): the boot ROM drives it in software, so the boot
// path and the application never own the pins at the same time and no pin
// arbitration is needed (docs/BOOT.md).
// DMA: dreq_tx = !BUSY && !RX_AUTO (a DATA write starts the next frame);
// dreq_rx = RX_VALID.  RX_AUTO: a DATA read (CPU or DMA) clears RX_VALID and
// starts the next frame transmitting all-ones, so a single DMA channel can
// stream a flash read; the DMA's final read starts one extra frame, which is
// harmless for flash reads (documented in docs/PERIPHERALS.md).
// =============================================================================
`default_nettype none

module mcu_spi #(
  parameter int NCS = 4
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic           rb_sel,
  input  wire logic           rb_we,
  input  wire logic [11:0]    rb_addr,
  input  wire logic [31:0]    rb_wdata,
  output logic [31:0]         rb_rdata,
  output logic                rb_err,
  output logic                sck,
  output logic                mosi,
  input  wire logic           miso,
  output logic [NCS-1:0]      cs_n,
  output logic                irq,
  output logic                dreq_tx,
  output logic                dreq_rx
);
  localparam logic [11:0] A_DATA = mcu_memmap_pkg::SPI_DATA;
  localparam logic [11:0] A_STAT = mcu_memmap_pkg::SPI_STATUS;
  localparam logic [11:0] A_CTRL = mcu_memmap_pkg::SPI_CTRL;
  localparam logic [11:0] A_DIV  = mcu_memmap_pkg::SPI_DIV;

  logic        cpol_q, cpha_q, ien_q, auto_q, done_q, busy_q, rxv_q, rxovf_q;
  logic [1:0]  len_q;
  logic [3:0]  cs_q;
  logic [15:0] div_q, dcnt;
  logic [6:0]  edge_n;              // 0 .. 2*bits-1
  logic [31:0] tx_sh, rx_sh, rx_q;

  wire wr      = rb_sel && rb_we;
  wire rd      = rb_sel && !rb_we;
  wire [6:0] last_edge = (len_q == 2'd0) ? 7'd15 : (len_q == 2'd1) ? 7'd31 : 7'd63;
  wire wr_start   = wr && rb_addr == A_DATA && !busy_q;
  wire auto_start = rd && rb_addr == A_DATA && auto_q && !busy_q;
  wire start      = wr_start || auto_start;
  wire [31:0] start_word = wr_start ? rb_wdata : 32'hFFFF_FFFF;

  // frame data is left-aligned in the shift registers: MSB out first
  function automatic logic [31:0] align(input logic [31:0] w, input logic [1:0] len);
    case (len)
      2'd0:    align = {w[7:0], 24'd0};
      2'd1:    align = {w[15:0], 16'd0};
      default: align = w;
    endcase
  endfunction

  wire tick      = busy_q && (dcnt == 16'd0);
  wire is_lead   = !edge_n[0];                  // edge_n even -> leading edge
  wire do_sample = tick && (is_lead ^ cpha_q);
  // CPHA=1: the first edge only starts the bit (nothing to shift yet);
  // CPHA=0: the last (trailing) edge must not shift out a bit past the frame
  wire do_shift  = tick && !(is_lead ^ cpha_q) && !(cpha_q && edge_n == 7'd0) &&
                   !(!cpha_q && edge_n == last_edge);
  wire fin       = tick && (edge_n == last_edge);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cpol_q <= 1'b0; cpha_q <= 1'b0; ien_q <= 1'b0; auto_q <= 1'b0; len_q <= 2'd0; cs_q <= '0;
      div_q  <= 16'd3; dcnt <= '0; edge_n <= '0; busy_q <= 1'b0; done_q <= 1'b0;
      rxv_q  <= 1'b0; rxovf_q <= 1'b0;
      tx_sh  <= '0; rx_sh <= '0; rx_q <= '0; sck <= 1'b0;
    end else begin
      if (wr && rb_addr == A_CTRL) begin
        cpol_q <= rb_wdata[0]; cpha_q <= rb_wdata[1]; ien_q <= rb_wdata[2];
        if (!busy_q) len_q <= rb_wdata[5:4];
        auto_q <= rb_wdata[6]; cs_q <= rb_wdata[11:8];
        if (!busy_q) sck <= rb_wdata[0];
      end
      if (wr && rb_addr == A_DIV) div_q <= rb_wdata[15:0];
      if (wr && rb_addr == A_STAT) begin
        if (rb_wdata[1]) done_q  <= 1'b0;
        if (rb_wdata[3]) rxovf_q <= 1'b0;
      end
      if (rd && rb_addr == A_DATA) rxv_q <= 1'b0;
      if (start) begin
        busy_q <= 1'b1; done_q <= 1'b0; edge_n <= '0; dcnt <= div_q;
        tx_sh  <= align(start_word, len_q); sck <= cpol_q;
      end else if (busy_q) begin
        if (dcnt != 16'd0) dcnt <= dcnt - 16'd1;
        else begin
          dcnt   <= div_q;
          sck    <= ~sck;
          edge_n <= edge_n + 7'd1;
          if (do_sample) rx_sh <= {rx_sh[30:0], miso};
          if (do_shift)  tx_sh <= {tx_sh[30:0], 1'b0};
          if (fin) begin
            busy_q <= 1'b0; done_q <= 1'b1;
            rx_q   <= do_sample ? {rx_sh[30:0], miso} : rx_sh;
            rxv_q  <= 1'b1;
            if (rxv_q && !(rd && rb_addr == A_DATA)) rxovf_q <= 1'b1;
          end
        end
      end
    end
  end

  logic [31:0] rx_view;
  always_comb begin
    case (len_q)
      2'd0:    rx_view = {24'd0, rx_q[7:0]};
      2'd1:    rx_view = {16'd0, rx_q[15:0]};
      default: rx_view = rx_q;
    endcase
  end

  assign mosi    = tx_sh[31];
  assign cs_n    = ~cs_q[NCS-1:0];
  assign irq     = ien_q && done_q;
  assign dreq_tx = !busy_q && !auto_q;
  assign dreq_rx = rxv_q;

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    case (rb_addr)
      A_DATA: begin rb_rdata = rx_view; rb_err = wr && busy_q; end
      A_STAT: rb_rdata = {28'd0, rxovf_q, rxv_q, done_q, busy_q};
      A_CTRL: rb_rdata = {20'd0, cs_q, 1'b0, auto_q, len_q, 1'b0, ien_q, cpha_q, cpol_q};
      A_DIV:  rb_rdata = {16'd0, div_q};
      default: rb_err  = 1'b1;
    endcase
  end
  wire unused_ok = ^{rb_wdata[31:12], rb_wdata[7]};
endmodule

`default_nettype wire
