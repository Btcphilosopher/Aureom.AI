# SilicaFlux IOSHELL — Project 37: chip perimeter, PHY integration and package signals

Aureom.AI | SilicaFlux-HPC. Primary RTL: [`rtl/silicaflux_io_shell.sv`](rtl/silicaflux_io_shell.sv).

`silicaflux_io_shell` is the chip top: real IHP SG13G2 `sg13g2_io` pad cells around the unmodified P31 die
(`silicaflux_die_top`), with the P35 clock / reset tree as the clock root, a TestCore TAP + 61-cell
boundary-scan register, an SPI host-command link into the die's SFB2 host port, host-owned management
peripherals (UART, SPI, GPIO), interrupt aggregation, and typed, **empty and gated** PCIe and external-memory
PHY slots. One YAML inventory drives the RTL constants, the C header, the documents, the testbench tables,
the pad-ring plan, the OpenROAD placement and the BSDL.

**Milestone A (this deliverable): low-speed control, test and management signals — done.**
**Milestone B (PCIe, DDR / HBM PHY): gated.** No PHY, PCIe endpoint, memory controller or PLL exists in the
repository or the open PDK; the shell refuses to elaborate such configurations and names the missing
dependency. Nothing here claims ESD qualification, a PCIe generation or a memory standard.

## Results

| Check | Result | Evidence |
|---|---|---|
| Inventory rules V1–V12; generated files current | 12 / 12 PASS | `reports/inventory_check.md`, `make check-gen` |
| Lint (Verilator `-Wall`, shell RTL, 3 legal builds) | 0 warnings, 0 errors | `reports/rtl/regression.md` |
| Missing-dependency builds refused at elaboration (PCIe, memory VENDOR, HPC without memory, SIM without models, behavioural pads in an implementation build, illegal drive strength, illegal die config) | 7 / 7 | same |
| Chip-level simulation, real P31 die, pads only: MIN, MIN with IHP cells (vendor model), HPC without memory, HPC with simulated controller + PHY, Icarus 4-state | 11 / 11 runs, **10 556 self-checks, 0 failures** | same |
| Real ControlCore firmware loaded through the SPI pins, boots, mailbox IRQ pin, console on UART_TX, TEST_DONE | PASS (8 025 checks) | `reports/rtl/sim/min_firmware.log` |
| Mutation testing (22 defects in the new RTL) | **22 / 22 detected** | `reports/rtl/mutation.md` |
| Physical netlist (sv2v + Yosys → IHP sg13g2) | 73 pad cells, 7 928 standard cells, 166 283 µm², die = 1 black box | `reports/synth/SYNTH_PHYS.md` |
| OpenROAD pad ring + placement (IHP SG13G2, die 3442 × 3444 µm) | 73 pads, 4 corners, 249 fillers, 73 bond pads, 0 unplaced | `reports/physical/openroad/` |
| Independent physical checks P1–P11 | 11 / 11 PASS | `reports/physical/PHYSICAL_CHECKS.md` |
| Physical-checker seeded-fault self-test | 11 / 11 | `reports/physical/CHECKER_SELFTEST.md` |
| BSDL (61 boundary-scan cells) self-check | PASS | `reports/bsdl/bsdl_selfcheck.txt` |

Not established (see [docs/11_LIMITATIONS.md](docs/11_LIMITATIONS.md)): ESD qualification, any PHY / PCIe /
memory standard, PLL, package, routing / DRC / LVS / timing sign-off, SSO / IR / EM of the I/O supplies.

## Brief → where

| Brief section | Where |
|---|---|
| §1 repository audit | [docs/00_AUDIT.md](docs/00_AUDIT.md) |
| §2 external interface inventory (logical / pad / supply / PHY-owned) | [config/io_inventory.yaml](config/io_inventory.yaml), [docs/01_IO_INVENTORY.md](docs/01_IO_INVENTORY.md), [docs/generated/IO_INVENTORY.md](docs/generated/IO_INVENTORY.md) |
| §3 top-level RTL | [rtl/silicaflux_io_shell.sv](rtl/silicaflux_io_shell.sv), [docs/02_SHELL_ARCHITECTURE.md](docs/02_SHELL_ARCHITECTURE.md) |
| §4 pad and PHY wrappers | [rtl/pads/](rtl/pads/), [docs/03_PAD_WRAPPERS.md](docs/03_PAD_WRAPPERS.md) |
| §5 PCIe | [rtl/pcie/](rtl/pcie/), [docs/04_PCIE_MILESTONE.md](docs/04_PCIE_MILESTONE.md) |
| §6 DDR / HBM | [rtl/mem/](rtl/mem/), [docs/05_MEMORY_PHY.md](docs/05_MEMORY_PHY.md) |
| §7 pin inventory + pin-assignment files | [docs/generated/IO_INVENTORY.md](docs/generated/IO_INVENTORY.md), [physical/generated/](physical/generated/) |
| §8 floorplan orientation | [docs/06_PIN_PLANNING.md](docs/06_PIN_PLANNING.md), [reports/physical/PIN_PLACEMENT.md](reports/physical/PIN_PLACEMENT.md), [floorplan.svg](reports/physical/floorplan.svg) |
| §9 I/O budget | [docs/07_IO_BUDGET.md](docs/07_IO_BUDGET.md), [reports/physical/IO_BUDGET.md](reports/physical/IO_BUDGET.md) |
| §10 verification | [docs/08_VERIFICATION.md](docs/08_VERIFICATION.md), [reports/rtl/regression.md](reports/rtl/regression.md), [reports/rtl/mutation.md](reports/rtl/mutation.md) |
| §11 physical checks | [docs/09_PHYSICAL_CHECKS.md](docs/09_PHYSICAL_CHECKS.md), [reports/physical/PHYSICAL_CHECKS.md](reports/physical/PHYSICAL_CHECKS.md) |
| limitations, open items | [docs/11_LIMITATIONS.md](docs/11_LIMITATIONS.md) |

## Deliverables (§12)

| Deliverable | File(s) |
|---|---|
| `silicaflux_io_shell.sv` | `rtl/silicaflux_io_shell.sv` (+ `rtl/host`, `rtl/mgmt`, `rtl/jtag`, `rtl/ctrl`, `rtl/mem`, `rtl/pcie`, `rtl/sf_io_die_core.sv`) |
| Pad wrappers | `rtl/pads/sf_io_pads.sv`; technology layers `rtl/pads/tech/ihp_sg13g2/` (vendor cells) and `rtl/pads/tech/sim/` (simulation only, refused for implementation) |
| I/O inventory | `config/io_inventory.yaml` → `docs/generated/IO_INVENTORY.md` |
| Pin-assignment generator | `scripts/pin_assign.py` → `physical/generated/{padring.json, pin_assignment.csv, padring_place.tcl, orfs_io.mk}` |
| Package signal map | `physical/generated/package_signal_map.csv`, `docs/generated/PACKAGE_SIGNAL_MAP.md` (package pins UNASSIGNED: no package exists) |
| Tests | `tb/tb_io_shell.sv` (chip-level, pads only, real die), `scripts/regress.py`, `scripts/mutate.py`, `scripts/check_physical_selftest.py` |
| PHY dependency register | `docs/generated/PHY_DEPENDENCY_REGISTER.md`; readable at run time in `SHELL.PHY_DEP` |
| Floorplan pin-placement report | `reports/physical/PIN_PLACEMENT.md`, `reports/physical/floorplan.svg`, `reports/physical/pad_nets.csv`; placed DEF `physical/out/silicaflux_io_shell.def` |
| Also | BSDL `reports/bsdl/silicaflux_io_shell.bsd`; C header `sw/include/silicaflux_io_shell.h`; register map `docs/generated/REGISTERS.md`; physical netlist report `reports/synth/SYNTH_PHYS.md` |

## Quick start

```bash
make help
```

```bash
make gen check-gen      # regenerate everything from the inventory, then verify it is current
```

```bash
make lint
```

```bash
make sim CFG=min && make run CFG=min TEST=all
```

```bash
make regress            # lint, refusals, all builds and tests, Icarus cross-check
```

```bash
make mutate
```

```bash
make physical           # needs OpenROAD (OPENROAD=...) and sv2v (SV2V=...)
```

```bash
make zip
```

## Layout

```
config/       io_inventory.yaml (single source of truth)
rtl/          shell RTL; generated/ (package, supply pads); file lists files_*.f
sim/          simulation-only memory PHY status model
tb/           chip-level testbench; generated/ (pad tables)
sw/include/   C header (register map, host-link codes)
scripts/      generators, regression, mutation, synthesis, physical checks, packaging
physical/     OpenROAD flow (padring.tcl); generated/ (plan, placement, ORFS variables, package map);
              out/ (placed DEF, physical netlist, die-block LEF: copies of the last `make physical`)
docs/         00–09, 11 design documents; generated/ (inventory, registers, dependency register, package map)
reports/      inventory check, rtl/ (regression, mutation, logs), synth/, physical/, bsdl/
third_party/  vendored, unmodified: P31 die tree (incl. P24, DataFabric, ControlCore, TestCore), P35 clock tree,
              MCU-I peripherals, IHP sg13g2_io + stdcell LEF / Liberty / Verilog models (Apache-2.0; GDS / CDL
              stay in IHP-Open-PDK and are not needed for placement)
```

## Tools

Verilator 5.020, Icarus Verilog 12, Yosys 0.33, Python 3 + PyYAML; OpenROAD 2.0-12331-g6011bbe77; sv2v v0.0.12
(Yosys front end only). `MANIFEST.sha256` lists every file of the archive.

## Repository status

Delivered as a zip only, as requested: **nothing was committed or pushed** to the Aureom.AI repository.
