# =============================================================================
# SilicaFlux IOSHELL (Project 37) :: OpenROAD pad ring + floorplan placement
# Aureom.AI | SilicaFlux-HPC
#
# Inputs (all generated, nothing hand-placed):
#   build/phys/silicaflux_io_shell.v          Yosys netlist, IHP sg13g2 cells, die core black box
#   build/phys/sf_io_die_core_abstract.lef     floorplanning abstract of the die core
#   physical/generated/padring_place.tcl       pad order and positions from scripts/pin_assign.py
# Flow (ICeWall commands of OpenROAD 2.0-12331, as used by the ORFS ihp-sg13g2 pad.tcl):
#   floorplan -> IO sites -> place_pad per pad -> corners -> IO fill -> supply rails
#   (global connect + connect_by_abutment) -> bond pads -> IO terminals -> core block
#   (FIRM) -> global + detailed placement of the shell's standard cells
#   -> check_placement -> DEF / ODB + reports for scripts/check_physical.py
# Usage: openroad -no_init -exit physical/padring.tcl   (from the project root)
# =============================================================================
set T   third_party/ihp-sg13g2
set OUT build/phys/or
file mkdir $OUT
source physical/generated/padring_place.tcl

read_lef $T/lef/sg13g2_tech.lef
read_lef $T/lef/sg13g2_stdcell.lef
read_lef $T/lef/sg13g2_io.lef
read_lef $T/lef/bondpad_70x70.lef
read_lef build/phys/sf_io_die_core_abstract.lef
read_liberty $T/lib/sg13g2_stdcell_typ_1p20V_25C.lib
read_liberty $T/lib/sg13g2_io_typ_1p2V_3p3V_25C.lib
read_verilog build/phys/silicaflux_io_shell.v
link_design silicaflux_io_shell

initialize_floorplan -die_area $SFIO_DIE -core_area $SFIO_CORE -site CoreSite
make_tracks

# ---------------------------------------------------------------- pad ring
make_io_sites -horizontal_site sg13g2_ioSite -vertical_site sg13g2_ioSite \
              -corner_site sg13g2_cornerSite -offset $SFIO_IO_OFFSET
foreach p $SFIO_PADS {
  lassign $p row loc inst cell
  place_pad -row $row -location $loc $inst
}
place_corners sg13g2_Corner
foreach row {IO_NORTH IO_EAST IO_SOUTH IO_WEST} {
  place_io_fill -row $row {*}$SFIO_FILLERS
}
# ring rails: pad pins vdd / vss / iovdd / iovss joined by abutment into the four supply nets
add_global_connection -net VDD   -pin_pattern {^vdd$}   -power
add_global_connection -net VSS   -pin_pattern {^vss$}   -ground
add_global_connection -net IOVDD -pin_pattern {^iovdd$} -power
add_global_connection -net IOVSS -pin_pattern {^iovss$} -ground
add_global_connection -net VDD   -pin_pattern {^VDD$}   -power
add_global_connection -net VSS   -pin_pattern {^VSS$}   -ground
global_connect
connect_by_abutment
place_bondpad -bond bondpad_70x70 pad_* -offset {5.0 -70.0}
place_io_terminals pad_*/pad
remove_io_rows

# ---------------------------------------------------------------- die core block (floorplan reservation)
set block [ord::get_db_block]
set cj [open build/phys/core_abstract.json r]; set cjs [read $cj]; close $cj
regexp {"origin": \[\s*([0-9.]+),\s*([0-9.]+)\s*\]} $cjs -> ox oy
set die [$block findInst u_die]
$die setOrigin [ord::microns_to_dbu $ox] [ord::microns_to_dbu $oy]
$die setPlacementStatus FIRM
# no cut_rows: the block spans the core width, so cut rows would shrink the placer's core to the strip;
# the FIRM block is an obstacle for global and detailed placement

# ---------------------------------------------------------------- shell standard cells in the band
global_placement -density 0.5
detailed_placement
check_placement -verbose

# ---------------------------------------------------------------- outputs
write_def $OUT/silicaflux_io_shell.def
write_db  $OUT/silicaflux_io_shell.odb
set n_pad 0; set n_fill 0; set n_corner 0; set n_bond 0; set n_std 0; set n_unplaced 0
foreach inst [$block getInsts] {
  set m [[$inst getMaster] getName]
  if {[string match sg13g2_IOPad* $m]} { incr n_pad } \
  elseif {[string match sg13g2_Filler* $m]} { incr n_fill } \
  elseif {$m eq "sg13g2_Corner"} { incr n_corner } \
  elseif {$m eq "bondpad_70x70"} { incr n_bond } \
  elseif {$m ne "sf_io_die_core"} { incr n_std }
  if {![$inst isPlaced]} { incr n_unplaced }
}
set f [open $OUT/or_summary.txt w]
puts $f "pads $n_pad"
puts $f "corners $n_corner"
puts $f "fillers $n_fill"
puts $f "bondpads $n_bond"
puts $f "std_cells $n_std"
puts $f "unplaced $n_unplaced"
puts $f "bterms [llength [$block getBTerms]]"
close $f
puts "SFIO-PADRING pads $n_pad corners $n_corner fillers $n_fill bondpads $n_bond std $n_std unplaced $n_unplaced"
