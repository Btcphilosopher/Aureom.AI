// =============================================================================
// SilicaFlux FlashMap (Project 56) :: tb_ftl_soc -- FTL firmware on the RTL SoC
//
// DUT: silicaflux_storage_soc from StorageCore P51, UNMODIFIED (vendored in
//      third_party/silicaflux-storagecore-p51): ControlCore RV32IM CPU + boot
//      ROM + storage subsystem with the sfs_nand_ctrl NAND channel controller.
//      Parameters = P51 "min1ch" except NAND_PAGE_BYTES = 528 (512 B FTL data
//      + 16 B FTL spare record in one ECC-protected program operation).
// Around it: P51's behavioural NAND model (64 blocks x 16 pages, 768 B raw
//      pages, unmodified) and host-memory model; a host BAR BFM that loads the
//      firmware through the ControlCore boot-ROM flow (as P51's tb_storage_soc).
//
// The firmware (firmware/silicaflux_ftl/fw) runs the FTL self-test and reports
// through SYSCTRL.TEST_CTRL.  Fault injection on firmware request: a console
// line "TBREQ <id> BAD <blk> ..." or "TBREQ <id> FLIP <blk> <pg> <rawbyte> <bit>"
// is executed on the NAND model, then the host writes <id> to SYSCTRL.SCRATCH3.
// Factory-bad blocks 13 and 41 (marker 00h at raw column 640 of pages 0 and 15,
// program/erase FAIL) are set before the firmware boots.
//
// Plusargs: +fw=<hex> +timeout=<cycles> +expect_req=<n> (testbench requests the firmware must make; 4)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_ftl_soc;
  import silicaflux_storage_pkg::*;
  import sfs_map_pkg::*;
  import cc_memmap_pkg::*;

  localparam int NCH = 1, CDW = 8, BUFB = 16384, DW = 32, AWID = 32, NT = 8, ECC = 1, RAS = 1;
  localparam int PAGE = 528, PPB = 16, BLOCKS = 64, RAW_PAGE = 768, SB = DW / 8;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;                       // 100 MHz
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  logic        hb_req_valid = 0, hb_req_write = 0, hb_req_ready, hb_rsp_valid, hb_rsp_error;
  logic [31:0] hb_req_addr = 0, hb_req_wdata = 0, hb_rsp_rdata;
  logic [3:0]  hb_req_wstrb = 4'hF;
  logic        hm_req_valid, hm_req_ready, hm_req_write, hm_rsp_valid, hm_rsp_ready, hm_rsp_error;
  logic [31:0] hm_req_addr;
  logic [DW-1:0] hm_req_wdata, hm_rsp_rdata;
  logic [SB-1:0] hm_req_wstrb;
  logic        host_irq, mgmt_irq, host_ready, cmdproc_ready, ras_fatal;
  logic [NCH-1:0] ce_n, cle, ale, we_n, re_n, wp_n, dq_oe, rb_n;
  logic [NCH*CDW-1:0] dq_o, dq_i;
  logic        diag_valid, test_done, test_fail, cpu_sleep;
  logic [7:0]  diag_char;
  logic [15:0] test_code;
  int          bp_pct = 0, lat_max = 2;

  silicaflux_storage_soc #(
    .NUM_NAND_CHANNELS(NCH), .CHANNEL_DATA_WIDTH(CDW), .BUFFER_SIZE_BYTES(BUFB), .DMA_DATA_WIDTH(DW),
    .ADDRESS_WIDTH(AWID), .CMD_QUEUE_DEPTH(NT), .ENABLE_ECC(ECC), .ENABLE_RAS(RAS), .NAND_PAGE_BYTES(PAGE)
  ) dut (
    .clk, .rst_ni(rst_n), .test_mode(1'b0), .boot_mode_i(2'(CC_BOOT_MODE_HOST)), .host_rst_req_i(1'b0),
    .pwr_fail_ni(1'b1),
    .hb_req_valid, .hb_req_ready, .hb_req_write, .hb_req_addr, .hb_req_wdata, .hb_req_wstrb,
    .hb_rsp_valid, .hb_rsp_ready(1'b1), .hb_rsp_rdata, .hb_rsp_error,
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error,
    .host_irq_o(host_irq), .mgmt_irq_o(mgmt_irq), .host_ready_o(host_ready), .cmdproc_ready_o(cmdproc_ready),
    .ras_fatal_o(ras_fatal),
    .nand_ce_n(ce_n), .nand_cle(cle), .nand_ale(ale), .nand_we_n(we_n), .nand_re_n(re_n), .nand_wp_n(wp_n),
    .nand_dq_o(dq_o), .nand_dq_oe(dq_oe), .nand_dq_i(dq_i), .nand_rb_n(rb_n),
    .diag_valid_o(diag_valid), .diag_char_o(diag_char), .test_done_o(test_done), .test_fail_o(test_fail),
    .test_code_o(test_code), .cpu_sleep_o(cpu_sleep)
  );

  sfs_tb_hostmem #(.DW(DW), .SIZE(1 << 20)) hmem (
    .clk, .rst_n, .req_valid(hm_req_valid), .req_ready(hm_req_ready), .req_write(hm_req_write),
    .req_addr(hm_req_addr), .req_wdata(hm_req_wdata), .req_wstrb(hm_req_wstrb), .rsp_valid(hm_rsp_valid),
    .rsp_ready(hm_rsp_ready), .rsp_rdata(hm_rsp_rdata), .rsp_error(hm_rsp_error), .bp_pct, .lat_max
  );

  wire [CDW-1:0] dq;
  assign dq = dq_oe[0] ? dq_o[CDW-1:0] : {CDW{1'bz}};
  assign dq_i[CDW-1:0] = dq;
  sfs_nand_flash_model #(.DQW(CDW), .RAW_PAGE(RAW_PAGE), .PAGES_PER_BLOCK(PPB), .BLOCKS(BLOCKS), .CH(0)) flash (
    .ce_n(ce_n[0]), .cle(cle[0]), .ale(ale[0]), .we_n(we_n[0]), .re_n(re_n[0]), .wp_n(wp_n[0]), .dq, .rb_n(rb_n[0])
  );

  // ---------------------------------------------------------------- host BAR BFM (as P51 tb_storage_soc)
  bit          bfm_wr, bfm_err, bfm_busy = 0;
  logic [31:0] bfm_a, bfm_wd, bfm_rd;
  event        bfm_go, bfm_fin;
  always begin
    @(bfm_go);
    @(negedge clk);
    hb_req_valid = 1; hb_req_write = bfm_wr; hb_req_addr = bfm_a; hb_req_wdata = bfm_wd; hb_req_wstrb = 4'hF;
    #4; while (!hb_req_ready) begin @(negedge clk); #4; end
    @(posedge clk); #1;
    hb_req_valid = 0;
    @(negedge clk); #4; while (!hb_rsp_valid) begin @(negedge clk); #4; end
    bfm_rd = hb_rsp_rdata; bfm_err = hb_rsp_error;
    @(posedge clk); #1;
    -> bfm_fin;
  end
  task automatic bar_access(input bit wr, input logic [31:0] a, input logic [31:0] wd, output logic [31:0] rd,
                            output logic err);
    while (bfm_busy) @(posedge clk);
    bfm_busy = 1; bfm_wr = wr; bfm_a = a; bfm_wd = wd;
    #1 -> bfm_go;
    @(bfm_fin);
    rd = bfm_rd; err = bfm_err; bfm_busy = 0;
  endtask
  int n_fail = 0, n_pass = 0;
  task automatic bw(input logic [31:0] a, input logic [31:0] d);
    logic [31:0] r; logic e;
    bar_access(1, a, d, r, e);
    if (e) begin n_fail++; $display("[%0d] FAIL BAR write error @%08h", cyc, a); end
  endtask
  task automatic br(input logic [31:0] a, output logic [31:0] d);
    logic e;
    bar_access(0, a, 0, d, e);
    if (e) begin n_fail++; $display("[%0d] FAIL BAR read error @%08h", cyc, a); end
  endtask
  task automatic check(input string what, input logic [63:0] got, input logic [63:0] exp);
    if (got === exp) n_pass++;
    else begin n_fail++; $display("[%0d] FAIL %s: got 0x%0h expected 0x%0h", cyc, what, got, exp); end
  endtask

  // ---------------------------------------------------------------- console + testbench requests
  string con_line = "", req_line;
  event  req_ev;
  int    n_req = 0;
  always @(posedge clk) if (diag_valid) begin
    if (diag_char == 8'h0A) begin
      $display("FW| %s  @%0d", con_line, cyc);
      $fflush();
      if (con_line.len() > 6 && con_line.substr(0, 5) == "TBREQ ") begin req_line = con_line; -> req_ev; end
      con_line = "";
    end else con_line = {con_line, string'(diag_char)};
  end
  initial forever begin
    int id, a, b, c, d, n;
    string cmd;
    @(req_ev);
    n = $sscanf(req_line, "TBREQ %d %s %d %d %d %d", id, cmd, a, b, c, d);
    if (n < 3) begin n_fail++; $display("[%0d] FAIL malformed request '%s'", cyc, req_line); end
    else if (cmd == "BAD") begin
      flash.set_bad_block(a, 1'b1);
      $display("[%0d] TB: NAND block %0d now fails program/erase (grown bad)", cyc, a);
    end else if (cmd == "FLIP") begin
      flash.flip_bit(a, b, c, d);
      $display("[%0d] TB: flipped bit %0d of raw byte %0d, block %0d page %0d", cyc, d, c, a, b);
    end else begin n_fail++; $display("[%0d] FAIL unknown request %s", cyc, cmd); end
    n_req++;
    bw(CC_SYSCTRL_BASE + CC_SYSCTRL_SCRATCH3, 32'(id));
  end

  // ---------------------------------------------------------------- boot (ControlCore host-load flow)
  logic [31:0] img [$];
  task automatic boot();
    string fw; int fd; logic [31:0] w, v; longint t0;
    if (!$value$plusargs("fw=%s", fw)) fw = "../firmware/silicaflux_ftl/fw/build/flashmap_fw.hex";
    fd = $fopen(fw, "r");
    if (fd == 0) $fatal(1, "cannot open firmware image %s", fw);
    while ($fscanf(fd, "%h\n", w) == 1) img.push_back(w);
    $fclose(fd);
    $display("TB host: firmware image %s, %0d words", fw, img.size());
    t0 = cyc;
    do br(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STAGE, v); while (v != CC_BOOT_STAGE_WAIT_IMAGE && cyc - t0 < 2_000_000);
    check("ROM waits for the image", v, CC_BOOT_STAGE_WAIT_IMAGE);
    for (int i = 0; i < img.size(); i++) bw(CC_IMEM_BASE + 32'(4 * i), img[i]);
    bw(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 4, 0);
    bw(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0, CC_MBOX_CMD_IMAGE_READY);
    bw(CC_MAILBOX_BASE + CC_MBOX_H2F_RING, CC_MBOX_CMD_IMAGE_READY);
    t0 = cyc;
    while (!mgmt_irq && cyc - t0 < 3_000_000) @(posedge clk);
    br(CC_MAILBOX_BASE + CC_MBOX_F2H_MSG0, v);
    check("boot ROM accepted the image", 64'(v & 32'hFF), CC_MBOX_STS_OK);
    bw(CC_MAILBOX_BASE + CC_MBOX_F2H_ACK, 0);
    $display("TB host: image accepted at cycle %0d", cyc);
    $fflush();
  endtask

  // ---------------------------------------------------------------- main
  initial begin
    longint tmo;
    int exp_req;
    if (!$value$plusargs("timeout=%d", tmo)) tmo = 1_500_000_000;
    repeat (10) @(posedge clk);
    // manufacturer bad blocks: marker 00h in the FTL spare byte 0 (raw column 640 with ECC) of pages 0 and 15
    for (int k = 0; k < 2; k++) begin
      int b = (k == 0) ? 13 : 41;
      flash.poke(b, 0, 640, 8'h00);
      flash.poke(b, PPB - 1, 640, 8'h00);
      flash.set_bad_block(b, 1'b1);
    end
    $display("TB: factory-bad blocks 13 and 41 marked");
    rst_n = 1'b1;
    boot();
    while (!test_done && cyc < tmo) @(posedge clk);
    repeat (20) @(posedge clk);
    check("firmware TEST_CTRL done", 64'(test_done), 1);
    check("firmware TEST_CTRL fail", 64'(test_fail), 0);
    check("NAND protocol errors", 64'(flash.n_proto_err), 0);
    check("NAND timing errors", 64'(flash.n_timing_err), 0);
    check("NAND re-programs without erase", 64'(flash.n_reprog), 0);
    if (!$value$plusargs("expect_req=%d", exp_req)) exp_req = 4;
    check("testbench requests served", 64'(n_req), 64'(exp_req));
    $display("TB summary: NAND reads %0d programs %0d erases %0d resets %0d; firmware code %0d",
             flash.n_reads, flash.n_progs, flash.n_erases, flash.n_resets, test_code);
    $display("tb_ftl_soc: %0d checks, %0d failures, %0d cycles (%.3f ms at 100 MHz) -> %s", n_pass + n_fail, n_fail, cyc,
             real'(cyc) / 1.0e5, (n_fail == 0) ? "PASS" : "FAIL");
    $finish;
  end
endmodule

`default_nettype wire
