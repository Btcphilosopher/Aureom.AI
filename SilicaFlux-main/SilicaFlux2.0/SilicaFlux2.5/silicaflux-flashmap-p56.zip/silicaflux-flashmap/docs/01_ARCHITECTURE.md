# 01 — Architecture

## 1. Layers

```
 host command (P51 SQ/CQ: READ WRITE DEALLOCATE FLUSH)            ControlCore firmware main loop
        │
 ┌──────▼──────────────────────────────── sfftl.h (public API) ─────────────────────────────────┐
 │ ftl_io.c     read / write / trim / flush / shutdown / background ; PowerSafe hooks           │
 │ ftl_map.c    L2P table, valid-page bitmap, valid counts          (mapping structures)        │
 │ ftl_alloc.c  block life cycle, free pool, streams, out-of-place page write                   │
 │ ftl_gc.c     victim selection, relocation, paced / foreground / background GC               │
 │ ftl_wear.c   erase-count tracking, dynamic + static wear levelling                           │
 │ ftl_bbm.c    factory markers, grown-bad handling, retirement                                 │
 │ ftl_meta.c   metadata ring: checkpoints, journal, generation counter                         │
 │ ftl_mount.c  layout, format, mount + recovery (roll-forward)                                 │
 │ ftl_check.c  invariant checker, space accounting, statistics                                 │
 │ ftl_util.c   CRC-32, spare-record codec, NAND call wrappers with statistics                  │
 └──────┬───────────────────────────────── sfftl_hal.h (5 functions) ───────────────────────────┘
        │ read(ppn, data, spare) · program(ppn, data, spare) · erase(pbn) · read_marker(ppn) · write_protect
 ┌──────▼─────────────────────┐        ┌──────────────────────────────────────────────┐
 │ hal/sfs  ControlCore →     │        │ hal/sim  simulated NAND (host): NANDLab rules,│
 │ P51 sfs_nand_ctrl registers│        │ ECC model, faults, power cuts, timing         │
 └──────┬─────────────────────┘        └──────────────────────────────────────────────┘
        ▼ ONFI-style SDR bus (RTL)                ▼ tests/, bench/
   P51 NAND flash model
```

FTL **policy** (mapping, GC, wear, bad blocks, persistence) is entirely firmware. The hardware below the HAL is the
existing P51 controller; no accelerator was added (the evidence is in docs/10 §4).

## 2. Execution model

* **Single-threaded and synchronous.** Each API call runs to completion; every HAL call returns with the device status
  known. This matches the ControlCore main loop (P51 runs one deferred-processing loop) and makes the persistence
  argument (docs/07) a sequential one. Multi-channel / multi-LUN overlap is a documented extension (docs/11).
* **No dynamic memory.** `sfftl_mem_required()` / `sfftl_layout_info()` size one arena the caller provides; the instance
  (`sfftl_t`, 0.8 KiB) can be static. The library has no `.data`/`.bss` (RV32 size report: `reports/firmware_size.md`).
* **ISR-safe power-fail entry.** `sfftl_ps_warn()` only sets a flag, polled between page operations.

## 3. Data structures (RAM)

| Structure | Size | Purpose |
|---|---|---|
| L2P | 4 B × logical pages | `PPN` or `0xFFFFFFFF` (unmapped → reads zeros) |
| VBM | 1 bit × physical pages | page holds the current copy of its LPN (GC needs no reverse map) |
| block table | 16 B × blocks | erase count, valid count, write pointer, state, flags, close sequence (cost-benefit age) |
| zone list | 4 B × metadata blocks | physical blocks of the metadata ring |
| 3 page buffers | 3 × page | host read-modify-write · GC relocation (GC can run inside a host write) · metadata / verify |
| journal queue | 2 pages of records | buffered erase-count records; TRIM / retire records are flushed at once |
| mount scratch | 20 B × metadata pages | catalogue of metadata pages during mount |

On NAND: every page carries a 16-byte spare record {type, LPN, 48-bit sequence number, CRC-32}; metadata pages carry a
16-byte header. Normative definition: `include/sfftl_schema.h`; design: docs/07.

## 4. Block states and write streams

```
          pick (wear policy) + erase-on-allocate
  FREE ──────────────────────────────────────────► OPEN (stream frontier)
   ▲  ▲                                              │ last page / program failure
   │  └─ last valid page invalidated ──┐             ▼
   │                                   └──────── CLOSED ──── GC victim ──► relocate valid pages ──► erase ─► FREE
   │                                                │
   └──────────────────── (never) ◄──── BAD ◄────────┘ program / erase / read failure (RETIRE flag, then retire)
   META: metadata ring blocks (first good blocks by factory marker)
```

Streams separate data by temperature: **HOST** (host writes), **RELOC** (GC copies — survived at least one GC, colder),
**COLD** (static wear-levelling copies, placed on the most-worn free blocks).

## 5. Configuration (sfftl_cfg_t, defaults)

| Field | Default | Meaning |
|---|---|---|
| `lba_bytes` | 512 | logical block size; divides the page data size |
| `nlba` | 0 (max) | namespace capacity |
| `op_permille` | 70 | over-provisioning of the data area |
| `meta_blocks` | auto | ≥ 2·⌈ckpt pages / ppb⌉ + 3, min 4 |
| `gc_reserve_blocks` / `gc_fg_free_blocks` / `gc_bg_free_blocks` | 2 / 3 / 6 | relocation reserve, blocking-GC threshold, background target |
| `gc_policy` | GREEDY | or COST_BENEFIT |
| `wl_policy` | DYNAMIC_STATIC | or NONE, DYNAMIC |
| `wl_static_threshold` / `interval` | 64 / 64 erases | static migration trigger |
| `ckpt_interval_blocks` | max(8, blocks/4) | bounds the mount roll-forward |
| `read_retries` | 2 | re-reads after uncorrectable / CRC / LPN mismatch |
| `refresh_bitflips` | off | corrected-bit threshold for refresh relocation |
| `flags` | VERIFY_READ_CRC, PACED_GC | + VERIFY_GC_COPY, PARANOID, ALLOW_REBUILD |

## 6. Source map

| Deliverable (brief §11) | Where |
|---|---|
| FTL source library | `firmware/silicaflux_ftl/src/`, `include/sfftl.h` |
| NAND HAL | `include/sfftl_hal.h`, `hal/sfs/` (ControlCore / P51), `hal/sim/` (host) |
| Mapping structures | `src/ftl_map.c`, docs/02 |
| Garbage collector | `src/ftl_gc.c`, docs/04 |
| Wear-levelling engine | `src/ftl_wear.c`, docs/05 |
| Bad-block manager | `src/ftl_bbm.c`, docs/06 |
| Persistence schema | `include/sfftl_schema.h`, `src/ftl_meta.c`, `src/ftl_mount.c`, docs/07 |
| Recovery tests | `tests/` (27 tests), docs/09 |
| Firmware build | `fw/` (RV32IM image), `rtl_sim/` (run on the P51 SoC RTL) |
| Performance reports | `bench/`, `reports/perf/`, docs/10 |
