# 02 — Address translation

## 1. Chain

```
LBA (lba_bytes)  ──÷ spp──►  LPN (logical page)  ──L2P──►  PPN = PBN · ppb + page  ──HAL──►  NAND row / column
                 offset = LBA mod spp                 0xFFFFFFFF = unmapped
spp = page_data_bytes / lba_bytes   (sectors per logical page, a power of two)
```

**Mapping granularity: one L2P entry per logical page, and a logical page is exactly the data area of one physical
NAND page.** For the P51 device (512-B pages, 512-B LBAs) that is one entry per LBA; with 4-KiB pages and 512-B LBAs one
entry covers 8 LBAs (8× less mapping memory, at the price of read-modify-write for writes smaller than a page).

PBN is flat: the HAL maps it onto channel / chip enable / LUN / plane / block (`hal/sfs` uses one channel, row =
PBN · 16 + page, as the P51 controller expects).

## 2. Namespace capacity

```
data blocks   = blocks − metadata blocks − factory-bad blocks
usable blocks = data blocks − max(gc_fg_free_blocks, gc_reserve_blocks) − 3 streams − 1
nlpn_max      = usable blocks · ppb · (1000 − op_permille) / 1000
nlba          = cfg.nlba  (must be ≤ nlpn_max · spp)   or   nlpn_max · spp
```

Computed at format (after the factory marker scan) and stored in every checkpoint; mount refuses a different
geometry, LBA size, metadata size or a configured `nlba` that differs (`SFFTL_EGEOM`). P51 device: 64 blocks × 16 pages
→ 5 metadata blocks, **773 LBAs** of 512 B (1024 physical pages).

## 3. Requests

| Case | Behaviour |
|---|---|
| `nlb = 0` | success, no work |
| `lba ≥ nlba`, or `nlb > nlba − lba` (overflow-safe) | `SFFTL_ERANGE`, nothing touched |
| read of an unmapped LPN | zeros, no NAND access (`unmapped_reads`) |
| read of a mapped LPN | one page read; spare record must decode, **name this LPN** (misdirected-read check) and match its CRC (configurable, on by default); a mismatch is re-read up to `read_retries` times, then `SFFTL_EIO` — wrong data is never returned |
| full-page write | data programmed straight from the caller's buffer |
| partial-page write | read-modify-write in the host buffer: old page (verified) or zeros, merge, program the whole page |
| deallocate (TRIM) | whole logical pages: journal record, then unmap; partial pages at either end: sectors written as zeros (RMW) — every deallocated LBA reads zeros |

Multi-page requests are processed page by page; a failure part-way returns an error after the pages already done
(those are committed, the request as a whole is not acknowledged). Each logical page is atomic.

## 4. Why page mapping

A page-level map gives the FTL freedom to place every page anywhere, which keeps write amplification low for random
writes and makes GC simple (any valid page can move independently). Its cost is RAM: 4 bytes per logical page. That fits
the ControlCore DMEM for the P51 device (3.0 KiB of L2P); it does not fit for gigabyte devices (≈ 0.95 MiB per GiB at
4-KiB pages, docs/10 §5). Block- or hybrid-mapping would save RAM at a large WA cost; a DRAM-resident or demand-paged
page map is the conventional answer and is listed as future work.
