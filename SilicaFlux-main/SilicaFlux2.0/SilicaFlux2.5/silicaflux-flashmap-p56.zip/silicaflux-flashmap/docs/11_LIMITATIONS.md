# 11 — Limitations and what is not claimed

## Not claimed

* **Silicon, FPGA or real NAND.** Host tests run against a simulated device; the firmware ran in RTL simulation
  (Verilator) against P51's behavioural NAND model. Nothing ran on a board, a vendor NAND model or a physical device.
* **Device lifetime / endurance.** Erase counts are reported; no TBW, DWPD or lifetime is derived — the wear model is
  uncalibrated (P52) and the simulated device has no wear-dependent failures.
* **Absolute latency or throughput.** Device times are NANDLab's illustrative SLC values; the RTL run uses P51's model
  timing (tR 2 µs, tPROG 4 µs, tBERS 8 µs — far faster than real NAND). Latencies are *modelled* and only comparable
  with each other.
* **NAND-grade ECC.** The FTL relies on the controller's ECC (P51: per-word SECDED, a placeholder for BCH/LDPC). The
  FTL's CRC-32, LPN check and re-reads detect miscorrection and misdirection; they do not correct anything.
* **NVMe semantics.** The API maps onto P51's NVMe-inspired command set; namespaces management, PI, atomic-write-unit
  guarantees beyond one logical page, etc. are not implemented.
* **PowerSafe hold-up energy.** Budgets are given in NAND operations; no capacitance / energy figure (docs/08).

## Design limits

* **Mapping memory.** The page-level L2P is RAM-resident: 4 B per logical page. The ControlCore DMEM (32 KiB) holds it
  for devices up to roughly 4 000–5 000 logical pages next to the rest of the firmware (P51 device: 773 LBAs, arena
  8.3 KiB). Gigabyte devices need ≈ 1 MiB of map per GiB (4-KiB pages): DRAM, or a demand-paged map (map pages on NAND
  + a small cache), which is future work.
* **Synchronous, single-queue execution.** One NAND operation at a time; no multi-channel / multi-LUN / multi-plane
  overlap, no cache program, no program/erase suspend. Correct and simple; leaves throughput on the table for
  multi-channel configurations (P51 research4ch, P53 multi-channel).
* **Mount scales with the device.** Clean mount reads the metadata zone + checkpoint; unclean mount additionally reads
  page 0 of every block plus the post-checkpoint pages (bounded by `ckpt_interval_blocks`). Rebuild without metadata
  reads every programmed page.
* **Metadata zone is fixed** (first good blocks by marker). Metadata blocks that fail are skipped, not replaced; when
  the ring can no longer advance the device becomes read-only (mount still works). Raise `meta_blocks` for more margin.
* **Paced GC trades WA for latency** (bench device, uniform random: WA 6.01 vs 5.63, +7 %, for a 31× lower write p99).
  It is a flag; blocking GC remains available.
* **No read-disturb / retention scrubbing.** Refresh is triggered only by corrected-bit counts on reads that happen; no
  background patrol read. The RTL run uses the P51 model, which has no retention / disturb physics.
* **No hardware accelerator.** CRC-32 is still ≈ 39 % of the ControlCore's cycles per host write after the slice-by-4
  optimisation; a data-path CRC engine in the NAND controller is specified (docs/10 §4.3) but not built — worth ≈ 17 %
  on today's single channel, ≈ 1.6× once several channels run concurrently.
* **Erase counts can under-count** after a crash (unflushed journal batch), never over-count.
* **48-bit sequence numbers**: 2.8·10¹⁴ programs, not wrap-safe beyond that (8.9 years at 10⁶ programs/s).
* **One firmware geometry table.** `hal/sfs` targets the P51 model (64 × 16 pages, 528-B ECC page, one channel); other
  devices need geometry from READ_ID / the ONFI parameter page (P53 has a parser).
* **`NAND_PAGE_BYTES = 528`** is a parameter value of the unmodified P51 RTL that P51 itself did not verify; it
  passes this project's RTL run (0 NAND protocol / timing errors). The alternative (512-B page + separate spare
  program) works with P51's verified configuration but needs two programs per page.

## Tool notes

* Verilator 5.020 and `gcc-riscv64-unknown-elf` 13.2 were installed from Ubuntu 24.04 packages for this work (the
  versions P51 records). No Icarus run of the SoC testbench.
* The simulated NAND is not bit-exact with NANDLab's statistical fault model; it implements the same rules (erase,
  1→0 programming, sequential pages, factory markers, sticky erase failure, interrupted operations) with its own
  seeded fault injection.
