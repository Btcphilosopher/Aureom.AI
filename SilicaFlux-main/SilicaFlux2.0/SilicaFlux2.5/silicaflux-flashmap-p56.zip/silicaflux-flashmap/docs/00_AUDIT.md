# 00 — Repository audit (Project 56 FlashMap)

Audited: `btcphilosopher/Aureom.AI`, branch `claude/clever-cannon-vp2jtb`, commit `6cef76d`. As in every earlier
SilicaFlux project, the hardware and firmware work lives in zip archives under
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`. Every archive relevant to an FTL was extracted and read:
`silicaflux-controlcore.zip` (P21), `silicaflux-storagecore-p51.zip` (P51), `silicaflux-nandlab-v0.1.0.zip` (P52),
`silicaflux-flashlink-p53.zip` (P53), `silicaflux-hostlink-project25.zip` (P25), `silicaflux-ras-project26.zip` (P26),
`silicaflux-powerclock.zip`. "Evidence" is what the owning project recorded in its own reports; it was not re-run here
unless stated.

## 1. Findings and decisions

| Area requested | Found | Decision |
|---|---|---|
| **ControlCore firmware** | P21 ControlCore: MCU-I `mcu_cpu` **RV32IM_Zicsr**, machine mode; boot ROM with host image load + CRC32; **64 KiB IMEM, 32 KiB DMEM** (byte parity); GNU `riscv64-unknown-elf-gcc` 13.2, freestanding C; runtime `crt0.S`, `trap_entry.S`, `fw.ld`, `crc32.c`, `cc_hw.h`, `mkimage.py`. Reused unmodified by P51. | FTL written in **C99, freestanding**, no malloc, no `.data`/`.bss` in the library (caller-provided arena). Firmware links against the ControlCore runtime **unmodified** (vendored through P51). |
| **C / Rust runtime** | C only. No Rust target, crate or runtime for the ControlCore exists in the repository (a host `rustc` exists in this container but nothing in the repo targets RV32 with it). | **C**, per the brief ("according to the actual ControlCore toolchain"). |
| **NAND controller API** | (a) P51 `sfs_nand_ctrl`: per-channel registers `OP_ROW/COL/BUF/LEN`, `OP_SUBMIT {op, ECC_EN, tag}`, completion queue `CPL_HEAD/INFO0/INFO1/POP`, `Q_STATUS`; ops RESET, READ_ID, READ_STATUS, READ_PAGE, PROGRAM, ERASE; per-word SECDED page ECC; WP#; op length ≤ `NAND_PAGE_BYTES`. **The only NAND controller wired to the ControlCore.** (b) P53 FlashLink: richer ONFI-style channel controller (parameter page, timing modes, multi-LUN), verified against NANDLab, not integrated with a CPU. | FTL talks to a 5-function **HAL** (`include/sfftl_hal.h`). Firmware backend `hal/sfs/` targets **P51 `sfs_nand_ctrl`** (polled, synchronous). The HAL contract (page data + 16-B spare in one ECC-protected program, raw marker read) maps equally onto P53. |
| **NAND device model** | P51 `sfs_nand_flash_model.sv`: 64 blocks × 16 pages, raw page configurable, program = AND, `set_bad_block`, `flip_bit`, `poke`, protocol/timing checkers. P52 NANDLab: SLC device twin — erase → 1, program 1 → 0 only, sequential pages, NOP, factory marker at spare byte 0 of first/last page, program/erase failures (erase sticky), power loss mid-operation, illustrative timing (tR 25 µs, tPROG 200 µs, tBERS 2 ms). | Host tests use `hal/sim/simnand.c`, a C device with **NANDLab semantics** plus rule-violation counters, fault and power-cut injection. RTL run uses the **P51 model unmodified**. |
| **Storage command descriptors** | P51 `silicaflux_storage_pkg` / `sfs_map.h`: `FLUSH`, `WRITE` (+`FUA`), `READ`, `DEALLOCATE`, `IDENTIFY`, `GET_LOG`, physical `ERASE`; 8-word SQEs, tagged completions. | API maps 1:1: `sfftl_write` (every acknowledged write is already durable, so FUA is implicit), `sfftl_read`, `sfftl_trim` (= DEALLOCATE, reads zeros afterwards), `sfftl_flush`; `sfftl_stats/space` feed IDENTIFY / GET_LOG. |
| **Available RAM** | DMEM 32 KiB for data + bss + ≥ 4 KiB stack (link-script assert); P51 firmware used 7.8 KiB bss. Storage buffer SRAM 16 KiB (min1ch) on the storage fabric. No DRAM anywhere. | Mapping must fit DMEM for the P51 device: arena **8.3 KiB** (L2P 3.0 KiB). Larger devices need a DRAM-resident or demand-paged map — stated limit (docs/11). |
| **Persistent metadata facilities** | None besides NAND. P51's FTL wrote one checkpoint (L2P + bad-block bitmap) to block 0, **no A/B copy** (an interrupted erase loses it), no journal, writes after the checkpoint lost on power loss. | New design: self-describing spare records + metadata **ring** with commit-last checkpoints, journal, generation counter, 48-bit sequence numbers, CRC-32 everywhere (docs/07). |
| **Existing FTL** | P51 `firmware/app/ftl.c`: page map, 16-bit entries, 256 LBAs per channel, pre-erase, program-failure retirement, **no GC, no wear levelling**, block 0 metadata. | Replaced by the FlashMap library (not patched); the new HAL backend reuses P51's register sequences. |
| **PowerSafe** | **No PowerSafe project exists in the repository.** P51 has power-loss hardware: `pwr_fail_ni` pin, `SYS.PLP_STATUS {PWR_FAIL, EVENT, QUIESCE, DRAINED, FW_SAFE, WP_ASSERTED}`, `SYS.PLP_CTRL {FW_SAFE, FORCE_QUIESCE, AUTO_WP}`, `IRQ_PLP`. `silicaflux-powerclock` is DVFS/thermal, unrelated. | Coordination contract defined (`include/sfftl_powersafe.h`, docs/08) and mapped onto the P51 PLP registers. |
| CRC | ControlCore `cc_crc32()` (table built at run time in 1 KiB of bss; init/xorout fixed). | Own incremental CRC-32 (same polynomial), slice-by-4 tables (4 KiB) in rodata (IMEM) so DMEM stays free; chosen from RTL cycle measurements (docs/10 §4). |
| Simulation tools | Verilator 5.020, Icarus 12 used by P51/P53; not installed in this container. | Installed `verilator` 5.020 and `gcc-riscv64-unknown-elf` 13.2 from Ubuntu 24.04 — the versions P51 records. |

## 2. Dependency status

| Dependency | Status |
|---|---|
| ControlCore CPU, boot ROM, runtime | implemented + verified upstream (P21); re-exercised here by the FTL firmware on the RTL (`reports/rtl/`) |
| P51 SoC, `sfs_nand_ctrl`, flash model | implemented + verified upstream (P51); used unmodified with `NAND_PAGE_BYTES = 528` (a parameter value P51 did not run; see docs/09) |
| NANDLab semantics | specified + verified upstream (P52); re-implemented in C for host tests (not bit-exact with NANDLab's fault statistics) |
| FTL, HAL, persistence, GC, WL, BBM, recovery, tests, benchmarks | **implemented here** |
| PowerSafe, P53 integration, multi-channel / multi-LUN parallelism, DRAM-resident map | **missing → not implemented** (contract / HAL only; docs/11) |

## 3. Unverified inherited items

* No SilicaFlux block has run on an FPGA board or silicon; nothing here either.
* All NAND reliability and timing numbers in P52 are illustrative, not measured; every latency in this project inherits that.
* No licence file exists in the repository (same as P51).
