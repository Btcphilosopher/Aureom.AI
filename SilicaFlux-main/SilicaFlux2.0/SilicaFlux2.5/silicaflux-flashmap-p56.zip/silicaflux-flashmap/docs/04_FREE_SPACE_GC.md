# 04 — Free-space management and garbage collection

## 1. What is tracked

| Quantity | Where | Reported by |
|---|---|---|
| free blocks (and how many are known-erased) | block state FREE, flag ERASED, `free_blocks` counter | `sfftl_space()` |
| free pages | erased pages of open blocks + pages of free blocks (`pages_writable`) | `sfftl_space()` |
| valid pages | VBM bits, per-block `valid` | `sfftl_space()`, `sfftl_check()` recomputes |
| invalid pages | programmed or abandoned pages that are not valid | `sfftl_space()` |
| reserved blocks | metadata ring + `gc_reserve_blocks` | `sfftl_space()` |
| bad blocks | factory and grown, separately | `sfftl_space()` |

`sfftl_check()` recomputes the VBM popcount per block, the mapped-LPN count and the free count, and verifies every
mapping points at a valid page of a data-bearing block below its write pointer. The tests call it continuously.

## 2. Deterministic allocator

`wear_pick_free()` scans the block table: WL_NONE → lowest free index; dynamic WL → lowest erase count, ties → lowest
index; COLD stream → highest erase count. No randomness anywhere in the library: the same command sequence on the same
device state always produces the same physical layout (the RTL run and the host tests rely on this to be reproducible).
Free blocks are erased on allocation unless GC already erased them (eager erase after collection; after an unclean mount
every free block is treated as not erased).

## 3. Victim selection

1. blocks flagged **RETIRE** (failing hardware) — relocate, then retire;
2. blocks flagged **REFRESH** (corrected bits ≥ `refresh_bitflips`) — relocate, then erase;
3. policy over CLOSED blocks with at least one invalid page:
   * **GREEDY**: fewest valid pages; ties → lower erase count → lower index;
   * **COST_BENEFIT**: maximise `(1 − u) · age / 2u`, u = valid / ppb, age = SEQ distance since the block closed
     (compared by cross-multiplication in 64-bit integers; no floating point on the ControlCore).

## 4. Three ways GC runs

| Mode | When | Work per call |
|---|---|---|
| **paced** (default, `SFFTL_F_PACED_GC`) | after each host page, while free blocks ≤ `gc_fg_free_blocks + 1` | `ceil(v / (ppb − v))` valid pages of the current victim (v = its valid count at selection) — freeing one block is spread over the `ppb − v` host pages it makes room for |
| **foreground** (blocking safety net) | before a host block opens with free blocks ≤ `gc_fg_free_blocks` | finish the paced victim, then whole victims until above the threshold |
| **background** | `sfftl_background(budget)` from the idle loop | urgent victims (RETIRE / REFRESH) and collection up to `gc_bg_free_blocks`, bounded by `budget` pages |

Static wear levelling is checked whenever a victim completes (docs/05). Measured effect of pacing on the bench device
(uniform random, 7 % OP): write p99 **5.2 ms instead of 161 ms**, max 12 ms instead of 195 ms, at a WA cost of
6.0 vs 5.6 (pages relocated early in a victim's window can be overwritten by the host before the victim completes) —
docs/10 §2.

## 5. Relocation never destroys the last valid copy

For each valid page of the victim (`collect_step()`, ftl_gc.c):

1. read source with ECC; spare record must pass the CRC and name an LPN whose L2P entry is **this** page;
2. `write_page()` programs a copy (type RELOC, new SEQ) and confirms its status; program failures go to another block;
3. with `SFFTL_F_VERIFY_GC_COPY` the copy is read back and compared byte for byte; a bad copy is treated like a
   program failure and redone;
4. `map_commit()` moves the mapping; the source page becomes invalid.

The victim is **erased only when its valid count is 0**. Each copy is durable on its own (spare record with a higher
SEQ), so no checkpoint has to be written between the copies and the erase: after a power loss, recovery prefers the
higher SEQ, and a partially erased victim only contains older copies. With `SFFTL_F_PARANOID` (used by every test and
by the RTL firmware) the whole L2P is scanned for references into the victim before the erase. Pages that cannot be
read are left mapped in the victim, which is then retired instead of erased (docs/06).

Mutation evidence: "GC erases a victim that still holds one valid page" is caught by 8+ tests.

## 6. Full device

With 100 % of the namespace written, random single-page overwrites at 8× capacity complete with no `ENOSPC`
(`t_full_device`). When grown bad blocks consume the over-provisioning, writes return `SFFTL_ENOSPC`, all data stays
readable, and mount still works (`t_degraded_wearout`).
