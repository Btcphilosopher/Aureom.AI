# 05 — Wear levelling

## 1. Erase counts

* Kept per block in RAM (`blk[].ec`), incremented on every successful erase (data and metadata blocks).
* Persisted in every checkpoint body (one word per block) and journalled between checkpoints
  (`SFFTL_J_ERASE {pbn, ec}`, buffered, flushed with the next journal page / at `FLUSH` / by PowerSafe).
* After an unclean shutdown, a block found reprogrammed since the checkpoint without a journalled erase gets `ec + 1`
  (the erase certainly happened). Remaining error: only erases whose record was lost *and* whose block was not
  reprogrammed — an under-count, never an over-count.
* Reported: `sfftl_space()` min / max / sum; per-block counts in `reports/perf/erase_counts_*.csv`, next to the
  simulated device's ground truth (identical in the benchmark runs).

## 2. Policies

| Policy | Rule |
|---|---|
| `SFFTL_WL_NONE` | lowest-index free block (baseline only, to measure what the policies buy) |
| `SFFTL_WL_DYNAMIC` | lowest-EC free block for every allocation |
| `SFFTL_WL_DYNAMIC_STATIC` (default) | dynamic + every `wl_static_interval` erases: if `max EC − min EC(closed data block) > wl_static_threshold`, relocate the lowest-EC closed block into the COLD stream, whose blocks come from the highest-EC free blocks. The young block returns to the pool and dynamic WL hands it to hot data. |

Dynamic WL only levels blocks that cycle through the free pool; blocks holding cold data never come back. Static WL
moves the cold data onto worn blocks, so the young blocks can take hot writes.

## 3. Measured effect (bench device, 4 KiB × 64 × 256, 20× capacity of writes, 90 % to 10 % of LBAs)

| Policy | EC min | max | mean | std-dev | max / mean | WA |
|---|---|---|---|---|---|---|
| none (lowest index) | 1 | 201 | 115.4 | 25.99 | 1.74 | 6.36 |
| dynamic | 70 | 147 | 115.0 | 14.69 | 1.28 | 6.33 |
| **dynamic + static** | **104** | **121** | 113.3 | **4.11** | **1.07** | 6.24 |

Device ground-truth counts are identical to the FTL's counts in these runs (no crashes). Static WL cuts the spread
(max − min) from 200 to 17 erases and the standard deviation by 6×, with **no write-amplification penalty** here (the
cold-data moves are paid back because young blocks no longer sit idle under cold data). Source:
`reports/perf/PERF.md` §2, per-block CSVs `reports/perf/erase_counts_wl_*.csv`, chart
`reports/perf/wear_erase_counts.svg`. The host test `wear_levelling` asserts the ordering on a second geometry.

## 4. What is not claimed

Erase counts are counts. **No endurance, lifetime, TBW or DWPD figure is derived**: the NAND wear model (P52 NANDLab) is
illustrative and uncalibrated, and the simulated device used here does not even model wear-dependent failure. A
narrower erase-count distribution means the most-worn block reaches any given count later; how much real lifetime that
buys depends on device data that does not exist in this repository.
