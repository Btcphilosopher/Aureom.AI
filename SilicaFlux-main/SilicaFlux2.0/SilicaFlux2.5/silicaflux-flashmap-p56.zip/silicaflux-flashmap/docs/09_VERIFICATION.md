# 09 — Verification

## 1. Strategy

| Layer | What | Where |
|---|---|---|
| **Reference model** | independent of the FTL: per LBA the acknowledged version and at most one in-doubt version (an operation that failed); data = 64-bit hash pattern of (LBA, version), so it needs 8 B per LBA instead of a data copy. A failed operation's LBAs are resolved by reading back while the device is alive, so a later failure cannot make an earlier in-doubt version unrepresentable (this harness bug was found by the randomized suite and fixed). | `tests/refmodel.c` |
| **Simulated NAND** | NANDLab rules, enforced and counted: erase → FFh, program 1 → 0 only, ascending page order, one program per page, factory-bad blocks untouchable, WP#. Faults: program / erase (sticky) / read failures, correctable bit errors, ECC miscorrection, misdirected reads, random rates. Power cut at any operation index: the interrupted program is not started / complete / ECC-recoverable / torn (1 in 4 torn pages pass ECC as garbage); interrupted erase leaves pages erased / intact / garbage. | `hal/sim/simnand.c` |
| **Invariant checker** | `sfftl_check()` recomputes VBM popcounts, mapped count, free count, mapping targets. | `src/ftl_check.c` |
| **Host test suite** | 27 tests (table in `reports/TESTS.md`). | `tests/test_main.c` |
| **Sanitizers** | quick suite under ASan + UBSan. | `make sanitize` |
| **Mutation check** | 12 deliberate bugs planted one at a time; the suite must fail. | `scripts/mutation_check.py`, `reports/mutation.md` |
| **Target run** | the FTL compiled for RV32IM runs on the ControlCore RTL against the P51 NAND controller RTL and NAND model, with its own on-target reference model and testbench fault injection. | `fw/`, `rtl_sim/`, `reports/RTL_RUN.md` |

## 2. Brief §10 → tests

| Required | Tests |
|---|---|
| sequential writes | `sequential`, every config / bench fill |
| random writes | `random_overwrite`, `gc_policies`, `repeated_random` |
| overwrites | all; `full_device` at 100 % mapping |
| reads after overwrite | `random_overwrite` (every write read back), random workloads (34 % reads) |
| TRIM / deallocation | `trim`, every random workload (5–25 % TRIM), `powercut_*` |
| full-device conditions | `full_device`, `degraded_wearout`, `meta_zone_exhaustion` |
| garbage collection | everything with overwrites; `gc_policies`; PARANOID + VERIFY_GC_COPY on |
| bad-block injection | `factory_bad_blocks`, `program_failures`, `erase_failures`, `read_failures`, `random_faults`, `powercut_with_faults`, RTL run (factory + grown + SECDED errors) |
| wear distribution | `wear_levelling`, bench §2 |
| restart recovery | `restart_clean`, `restart_unclean`, `powercut_sweep`, `powercut_random`, `powercut_mount_sweep`, `metadata_fallback`, `rebuild_from_spare`, RTL run (clean + unclean) |
| repeated random workloads | `repeated_random` (240 runs), `powercut_random` (400), `powercut_with_faults` (150) |

## 3. Definition of done

> *After arbitrary supported sequences of writes, overwrites, reads, garbage collection and simulated restarts, the FTL
> returns the correct acknowledged logical data.*

Evidence (all in `reports/`):

* every acknowledged LBA is checked against the reference model after every restart in every test — including a power
  cut at **each** of 1 200 consecutive device-operation indices, at **each** operation of a recovery mount, 400 random
  cuts (⅓ with a second cut during mount), 150 seeds under stress-level fault rates, and 240 randomized multi-restart
  runs across 7 geometries and all GC / WL policies;
* zero NAND rule violations across the suite;
* 11 of 12 planted bugs are caught; the survivor is a redundant integrity layer (docs/07 §6);
* the same library, cross-compiled, passes its self-test on the RTL CPU against the RTL NAND controller.

## 4. Bugs found during development (by these tests)

| Found by | Bug | Fix |
|---|---|---|
| design review while writing the allocator | closing a full stream block *before* the mapping commit could free a block whose newest page was about to become valid | `streams_settle()` after `map_commit()` |
| design review of mount | rebuild could inherit `nlpn` from a failed checkpoint load; erase-count inference over-counted blocks erased before the checkpoint | explicit `nlpn`; inference only for blocks not erased at the checkpoint |
| `powercut_with_faults` | a worn-out metadata ring made **mount** fail although the map was recoverable | read-only mount |
| `powersafe` | test harness: "arm cut at op 0" did not cut until the next op, leaving WP# asserted into the mount; mount should release WP# anyway | `simnand_power_off()`; mount releases WP# |
| `wear_levelling` | with paced GC the blocking path (the only static-WL trigger) almost never ran: static WL silently stopped | static WL check at every completed paced victim |
| `repeated_random` | harness: two consecutive failed writes to one LBA — the model kept only the second in-doubt version | resolve in-doubt LBAs by read-back right after a failure |
| mutation check | tests could not distinguish CRC-on-replay, LPN check and the live-region guard from no-ops | new fault types (torn-but-ECC-pass, late-cut torn, misdirected read) and `meta_zone_exhaustion` |

## 5. Not verified

* Real NAND, vendor models, FPGA, silicon (docs/11).
* Power loss on the RTL: the P51 NAND model has no supply input, so the RTL run covers clean and unclean restarts
  (RAM discarded) but not torn operations; torn operations are covered by the host model only.
* Concurrency: the FTL is single-threaded by design; no multi-queue interleaving is tested.
