# 03 — Out-of-place write path

## 1. The five steps (per logical page)

| Step | Code | What happens | Failure handling |
|---|---|---|---|
| 1. allocate | `alloc_page()` (ftl_alloc.c) | next page of the stream's open block; if full, close it and open a free block: foreground GC first if free blocks ≤ `gc_fg_free_blocks`; host may not take the last `gc_reserve_blocks`; wear policy picks the block; erase it unless known erased | erase failure → block retired, next block; no space → `SFFTL_ENOSPC` (nothing changed) |
| 2. program | `write_page()` | build the spare record {HOST, LPN, SEQ = next_seq++, CRC-32(data ‖ spare)}; program data + spare in **one** HAL operation | — |
| 3. confirm | `write_page()` | HAL status must be OK | PROGRAM_FAIL → `bbm_program_failed()`: block closed and flagged RETIRE (durable PRETIRE record), retry on a fresh page (≤ 4 attempts); POWER_LOSS → `SFFTL_EPOWER` (not acknowledged) |
| 4. commit | `map_commit()` (ftl_map.c) | `L2P[LPN] = new PPN`, VBM bit set, valid count +1 | only reached after step 3 succeeded |
| 5. retire old | `map_commit()` → `map_invalidate_ppn()` | old page's VBM bit cleared, its block's valid count −1; a closed block reaching 0 valid pages becomes FREE | old page stays physically intact until its block is erased |

After the page: `streams_settle()` closes a full stream block (only after the commit, so a block whose other pages were
all invalid is not freed while its newest page is being committed — a bug caught during development), then
`gc_paced()` performs this page's share of incremental GC (docs/04 §4).

## 2. No silent loss of acknowledged data

* The previous copy is never modified before step 4, so any failure between steps 1 and 4 leaves the old data readable
  and the L2P pointing at it.
* `sfftl_write` returns `SFFTL_OK` only when **every** page of the request completed step 4.
* Durability does not depend on RAM: the new page's spare record (LPN + SEQ) makes the mapping recoverable by
  roll-forward (docs/07 §5). There is no volatile write cache; `FLUSH` therefore only makes buffered erase-count
  records durable, and P51's `FUA` flag is implicit.
* A program failure on a page whose block already holds acknowledged data does not lose that data: the block is only
  flagged; GC relocates its valid pages before retiring it.
* Test evidence: every host test checks every acknowledged LBA against the reference model after power cuts at every
  device-operation index (docs/09); mutation "mapping committed even when the program failed" is caught.

## 3. TRIM (DEALLOCATE)

Whole logical pages: one `SFFTL_J_TRIM {first LPN, count}` record is **programmed** (journal page) before the L2P
entries are cleared, and only then is the command acknowledged. Recovery applies a TRIM record only where it is newer
(by SEQ) than the LPN's surviving data page (docs/07 §5). Partial pages are written as zeros. An acknowledged TRIM
therefore can neither resurrect old data nor hide a later write.

## 4. Read-modify-write

Partial writes read the current page into the host buffer, verify its spare record (CRC and LPN), merge and program the
whole page out of place. An unreadable old page fails the write with `SFFTL_EIO` (the other sectors cannot be
preserved); nothing is changed.
