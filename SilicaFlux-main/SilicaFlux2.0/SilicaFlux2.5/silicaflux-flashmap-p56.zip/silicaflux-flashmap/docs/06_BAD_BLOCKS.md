# 06 — Bad-block management

## 1. Factory bad blocks — markers preserved

* Format reads the manufacturer marker (spare byte 0 of the **first and last page**, NANDLab convention) of every block
  through `hal.read_marker()` — a raw read, no ECC — **before anything is erased**.
* A block is factory-bad when either marker has **≥ 4 zero bits** (a factory marker is 00h). A majority rule, so a single
  read-disturb flip cannot turn a good block bad and shift the metadata zone.
* Factory-bad blocks are never programmed or erased (the simulated device counts any attempt as a rule violation; every
  test requires zero), so the markers survive the life of the device. The FTL itself always writes FFh in that byte,
  so its own pages never look bad. `t_factory_bad_blocks` reads the markers back after heavy use.
* Block 0 is guaranteed good (ONFI / NANDLab). Mount finds the metadata zone by marker, so it needs no metadata.
* Not all blocks are assumed usable: capacity is computed after the scan (docs/02 §2).

## 2. Grown bad blocks

| Event | Response | Persistence |
|---|---|---|
| **program failure** | page abandoned; write retried on a fresh page of another block; block closed + RETIRE flag; GC relocates its earlier valid pages with priority, then retires it | `J_PRETIRE` programmed at once; `J_RETIRE` at retirement |
| **erase failure** | block holds no valid data (only free blocks / finished victims are erased): retired at once | `J_RETIRE` programmed at once |
| **read failure** (uncorrectable after `read_retries`) | `SFFTL_EIO` for that LBA; block flagged RETIRE; GC moves every readable page; unreadable pages stay mapped to the retired block ("stranded") so reads keep returning EIO — never stale or zero data — until the host rewrites / trims them | RETIRE flag in the next checkpoint; `J_RETIRE` at retirement |
| **CRC / LPN mismatch** (ECC miscorrection, misdirected read) | re-read up to `read_retries`; still bad → `SFFTL_EIO` | — |
| **high corrected-bit count** (≥ `refresh_bitflips`) | REFRESH flag: GC relocates the block, then erases it normally | RAM / checkpoint |
| **metadata block** failure | block marked bad, ring skips it, a checkpoint is scheduled to move the live region away | `J_RETIRE` |

**Replacement** is implicit: there is no fixed spare pool; every block is drawn from the free pool, and the
over-provisioning absorbs retired blocks. When it is used up, writes return `SFFTL_ENOSPC` while reads and mount keep
working (`t_degraded_wearout`); when the metadata ring cannot advance, the FTL becomes read-only and **mount still
succeeds read-only** (`t_meta_zone_exhaustion`, and 2 of 150 stress-rate seeds in `t_powercut_with_faults`).

## 3. Not done

No on-NAND grown-bad marker is written: re-programming page 0 of a partly written block would break the sequential-page
rule, and the persistent table (checkpoint + journal) is authoritative. A rebuild after total metadata loss therefore
re-learns grown-bad blocks by failing on them again.
