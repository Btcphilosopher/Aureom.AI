# 10 — Performance

Two sources:

* **Simulated NAND** (`bench/bench.c`, `make bench` → `reports/perf/PERF.md`, CSVs, SVG charts). Counters are exact;
  device times are NANDLab's illustrative SLC values (tR 25 µs, tPROG 200 µs, tBERS 2 ms, 30 ns/byte), so latencies are
  *modelled* and comparable only with each other. Every run verifies all data and requires zero NAND-rule violations.
  Bench device: 4 KiB pages × 64 × 256 blocks (64 MiB, 4 KiB LBAs). P51 device: 512 B × 16 × 64.
* **ControlCore RTL** (`make rtl` → `reports/RTL_RUN.md`): CPU cycles of the RV32IM firmware against the P51 NAND
  controller RTL (§4).

## 1. Write amplification, GC overhead, free space

Preconditioned by a full sequential fill; then 4× capacity of writes (WA = physical bytes programmed / logical bytes
written).

| Workload (7 % OP, greedy, paced GC) | WA | WA w/o metadata | GC pages moved per host page | metadata share of programs | GC share of device time |
|---|---|---|---|---|---|
| sequential overwrite | **1.00** | 1.00 | 0.00 | 0.4 % | 8 % |
| uniform random | **6.01** | 5.99 | 4.99 | 0.4 % | 87 % |
| hot/cold 80/20 | 6.09 | 6.07 | 5.07 | 0.4 % | 87 % |
| hot/cold 90/10 | 5.64 | 5.61 | 4.61 | 0.4 % | 86 % |
| 70 % reads, uniform writes | 5.93 | 5.90 | 4.90 | 0.4 % | 77 % |

| Over-provisioning (uniform random) | 7 % | 15 % | 25 % | 40 % |
|---|---|---|---|---|
| WA | 6.01 | 3.16 | 2.03 | 1.39 |

`reports/perf/wa_vs_op.svg`. Free space settles at 3–5 free blocks once GC runs (`reports/perf/free_space.svg`,
`timeline_*.csv` sample free blocks, valid / invalid / writable pages and cumulative WA 100 times per run).

**GC policy.** Cost-benefit pays off on skewed data: 90/10 hot/cold WA **5.64 → 3.78** (−33 %), 80/20 6.09 → 5.36;
on uniform data it is slightly worse (6.01 → 6.14), as expected — greedy is the default, cost-benefit is one flag.

**Metadata overhead.** 0.4 % of programs on the bench device; 3.4 % on the tiny P51 device with the default checkpoint
interval (16 blocks), 1.0 % with a 64-block interval (P51 WA 4.07 → 3.97) — the interval trades metadata WA against
roll-forward length at mount.

## 2. Latency (modelled device time per synchronous call)

| Uniform random 4 KiB writes | p50 | p99 | p99.9 | max |
|---|---|---|---|---|
| blocking GC only | 323 µs | **160 915 µs** | 166 561 µs | 195 464 µs |
| **paced GC** (default) | 2 682 µs | **5 154 µs** | 8 327 µs | 12 327 µs |

Blocking GC is cheap for most writes and then stalls one write for whole-victim relocations (≈ 5 victims of ~58 valid
pages each at 7 % OP). Paced GC spreads that work over the host writes that consume the freed space: **31× lower p99,
16× lower max**, for a WA of 6.01 instead of 5.63 (+7 %) — pages relocated early in a victim's window can be overwritten
before the victim completes. `reports/perf/latency_cdf.svg`. Reads: 148 µs (tR + transfer) at every percentile; reads
never wait for GC in this synchronous design except when issued between the paced steps of a write.

## 3. Erase-count distribution

docs/05 §3: max/mean 1.74 (no WL) → 1.28 (dynamic) → **1.07** (dynamic + static), std-dev 26.0 → 14.7 → 4.1, no WA
penalty. No lifetime is inferred.

## 4. ControlCore CPU cost and accelerator decision

Measured with `mcycle` on the RTL CPU (100 MHz) while the FTL self-test drives the P51 NAND controller RTL
(`reports/RTL_RUN.md`). The random-overwrite phase writes 2 061 host LBAs (512 B) and causes 7 775 NAND programs,
5 547 reads and 481 erases (WA 3.8, the P51 device is small).

### 4.1 Where the cycles went (v1: byte-at-a-time CRC, byte-packing copies)

| Component (random phase, 247.2 M cycles = 119 949 per host LBA) | Cycles | Share |
|---|---|---|
| CRC-32 of every programmed and every read page: 13 322 × 8 995 | ≈ 119.8 M | **48 %** |
| HAL CPU copies DMEM ↔ buffer SRAM | 37.4 M | 15 % |
| HAL waiting for the controller (bus transfer + the model's array time) and register staging | 65.9 M | 27 % |
| everything else in the FTL (mapping, allocation, GC selection, spare records, journal, PARANOID scans) | ≈ 24.1 M | 10 % (≈ 3.1 k per NAND program) |

### 4.2 Software first

A CRC / copy microbenchmark on the same RTL CPU (`fw/crc_bench.c`, `make -C rtl_sim crcbench`), 528-byte page:

| Variant | Cycles |
|---|---|
| byte-at-a-time, table in DMEM | 7 921 |
| library v1 (byte-at-a-time, table in IMEM rodata) — measured in the v1 self-test | 8 995 |
| **slice-by-4**, tables in DMEM | **4 621** |
| slice-by-8, tables in DMEM (8 KiB) | 4 423 |
| slice-by-8 reading the storage buffer SRAM directly | 4 557 |
| **library v2** (slice-by-4, tables in IMEM rodata, incl. call) | **5 181** |
| word copy DMEM ↔ buffer SRAM (each way) | 1 323 (v1 HAL byte packing ≈ 2 800) |

Slice-by-8 buys 4 % over slice-by-4 for twice the table, so the library uses **slice-by-4** (checked against a
bit-serial IEEE reference at every alignment, test `crc32`) and the HAL copies aligned buffers word by word. Tables read
from IMEM cost ≈ 12 % more than from DMEM (the data port shares IMEM with instruction fetch); keeping the 4 KiB of
tables in IMEM leaves the scarce DMEM to the mapping, at ≈ 4 % of total cycles.

| v1 → v2 (same workload, same seed) | v1 | v2 | |
|---|---|---|---|
| cycles per host LBA written | 119 949 | **86 965** | −27 % |
| cycles per LBA read | 16 967 | 12 219 | −28 % |
| CRC-32 of one page (library call) | 8 995 | 5 185 | −42 % |
| HAL copy cycles, random phase | 37.4 M | 19.8 M | −47 % |
| clean / unclean mount | 1.59 M / 6.06 M | 1.18 M / 4.43 M | −26 % / −27 % |
| whole self-test | 451.0 M | 344.8 M | −24 % |

Behaviour is unchanged: the benchmark CSV is byte-identical before and after, all 27 host tests pass, and the RTL
self-test passes with the same NAND operation counts.

### 4.3 Is a hardware accelerator justified?

After the software step, CRC-32 is still the largest single CPU cost: ≈ 13 322 × 5 185 ≈ 69 M of 179 M cycles
(**39 %**), ≈ 33.5 k cycles per host LBA. The CRC cannot be dropped — the mutation check shows recovery depends on it
(torn pages that slip past ECC). The candidate is a **CRC-32 engine in the NAND controller data path**: `sfs_nand_ctrl`
already streams every word through its SECDED encoder / decoder, so a CRC-32 over the user bytes of each PROGRAM /
READ_PAGE could be computed on the fly and returned in the completion record (e.g. `CPL_INFO1` for programs, a new
`CPL_CRC` register for reads) at ≈ 0 CPU cycles; the FTL would take it through an optional HAL output.

What it would buy, using the measured CPU cost and NANDLab's illustrative device times (tPROG 200 µs, tR 25 µs,
tBERS 2 ms, 30 ns/byte → ≈ 139 k cycles of device time per host LBA at this WA):

| Configuration | CPU per host LBA (FTL + copies) | Device time per host LBA | Gain from a CRC engine |
|---|---|---|---|
| **P51 min1ch: one channel, synchronous FTL (what exists)** | ≈ 55 k cycles | ≈ 139 k | **≈ −17 % time per write (1.2× throughput)** |
| hypothetical 4 channels with overlapped operations | ≈ 55 k (CPU-bound) | ≈ 35 k amortised | ≈ 1.6× throughput (then device-bound) |

**Decision: no accelerator is implemented in this project.** For the configuration that exists, the engine is worth
≈ 17 %, less than the 27 % the firmware change already delivered, and it would mean modifying P51's verified
controller RTL (vendored here unmodified). It becomes the **first accelerator to build when the FTL drives several
channels concurrently** (P51 `research4ch`, P53 multi-channel): there the CPU, not the NAND, limits throughput and the
CRC is ≈ 61 % of the CPU work per host write (33.5 k of 55 k cycles). Before that, zero-copy buffers (FTL pages living in buffer SRAM; CRC from
SRAM costs the same, 4 557 vs 4 423 cycles) remove the remaining 9.6 k cycles of copies per host LBA without hardware.

## 5. Mapping memory

| Device | Logical pages | L2P | Arena total | Fits ControlCore DMEM (32 KiB)? |
|---|---|---|---|---|
| P51 (512 B × 16 × 64) | 773 | 3.0 KiB | **8.3 KiB** | yes (firmware bss 19.9 KiB incl. 12 KiB arena reservation + test buffers) |
| NANDLab slc_tiny-like (512 B × 16 × 128) | 1 696 | 6.6 KiB | 13.6 KiB | yes |
| bench (4 KiB × 64 × 256, 64 MiB) | 14 522 | 56.7 KiB | 89 KiB | no |
| 1 GiB (4 KiB × 64 × 4096) | 242 603 | 948 KiB | 1.05 MiB | no — DRAM / paged map |
| 16 GiB (16 KiB × 256 × 4096) | 971 842 | 3.7 MiB | 4.0 MiB | no |

Rule of thumb: 4 B per logical page + 1 bit per physical page + 16 B per block + 3 page buffers + metadata catalogue;
≈ 1 MiB per GiB at 4-KiB pages, 0.25 MiB per GiB at 16-KiB pages. Instance struct 0.8 KiB.

## 6. Mount cost (simulated device)

| Device | Case | Device ops | Modelled time | Data pages scanned / replayed |
|---|---|---|---|---|
| P51 | clean shutdown | 92 | 3.6 ms | 0 / 0 |
| P51 | power lost after 1/3 × capacity of random writes | 381 | 18.8 ms | 214 / 209 |
| bench | clean shutdown | 300 | 43.3 ms | 0 / 0 |
| bench | power lost after 1/3 × capacity of random writes | 824 | 125.7 ms | 269 / 269 |

Unclean mount = page-0 probe of every block + post-checkpoint pages + a new checkpoint; bounded by
`ckpt_interval_blocks`, independent of how long the device ran.
