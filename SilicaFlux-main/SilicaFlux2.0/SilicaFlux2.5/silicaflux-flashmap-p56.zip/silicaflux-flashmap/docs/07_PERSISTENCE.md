# 07 — Mapping persistence and recovery

Normative format: `include/sfftl_schema.h` (schema version 1, little endian, byte-wise codec).

## 1. Ingredients

| Requested | Implementation |
|---|---|
| **sequence numbers** | one global 48-bit counter `SEQ`; every page program (data, relocation, metadata) takes the next value and stores it in the page's spare record. SEQ totally orders all events on the medium. 48 bits = 2.8·10¹⁴ programs (8.9 years at 10⁶ programs/s). |
| **generation counters** | checkpoint generation `gen`, +1 per committed checkpoint; in every body / commit page header; journal pages carry the generation they follow. |
| **mapping checkpoints** | full snapshot: L2P + per-block {erase count, state, flags, write pointer}, as body pages, then ONE commit page (written last) holding geometry, `ckpt_seq`, body page list (runs of PPNs), body CRC, lifetime counters. |
| **journals** | records for events that data pages do not describe themselves: `TRIM`, `ERASE` (erase count), `RETIRE`, `PRETIRE`, `MOUNT` (medium modified after a clean shutdown). |
| **metadata integrity** | CRC-32 over data ‖ spare on **every** page (data and metadata); header magic + schema version + kind/index cross-check (spare tag vs header); body CRC in the commit; L2P values range-checked on load; geometry / configuration fingerprint (EGEOM). |
| **recovery on startup** | `sfftl_mount()`: §5. |

### Spare record (every page, 16 bytes)

```
byte 0     BBM    FFh always (manufacturer marker position; never written otherwise)
byte 1     TYPE   D1h host data | D2h relocated data | E1h metadata
bytes 2-5  TAG    data: LPN          metadata: kind << 24 | index
bytes 6-11 SEQ    48-bit sequence number
bytes 12-15 CRC   CRC-32 (IEEE, reflected) over page data || bytes 1..11
```

This record is what makes an acknowledged write durable **without a checkpoint**: a valid data page names its LPN and
its age. The HAL contract requires data and spare to be programmed in one operation and covered by the same ECC
(`hal/sfs` uses a 528-byte P51 page for exactly that).

## 2. Metadata ring

* Zone = the first `meta_blocks` blocks whose factory marker is good (mount can find it with no metadata). Size is
  automatic: ≥ 2·⌈checkpoint pages / ppb⌉ + 3 (P51 device: 5 blocks, checkpoint = 9 pages: 773 + 2 × 64 words at 124 words per page = 8 body pages + 1 commit).
* Pages are appended in ring order. **Live region** = from the block holding the first body page of the newest commit to
  the head. The ring never erases into the live region (`meta_advance`; mutation-tested).
* A checkpoint is forced while at least ⌈checkpoint / ppb⌉ whole ring blocks are still free, so a checkpoint always fits —
  including the one mount writes into a *fresh* block after an unclean shutdown.
* Between API calls the head always has an erased page ready (PowerSafe needs one program, never an erase).
* Metadata block program / erase failure → block marked bad, skipped, checkpoint scheduled. If the ring cannot advance,
  the FTL turns read-only; mount still succeeds read-only.

## 3. When things are written

| Event | Metadata written |
|---|---|
| host write | nothing (spare record suffices) |
| TRIM of whole pages | 1 journal page **before** the acknowledgement |
| program / erase failure | 1 journal page (PRETIRE / RETIRE) at once |
| erase | record buffered; flushed with the next journal page, `FLUSH`, PowerSafe, or dropped when a checkpoint subsumes it |
| first change after a clean shutdown or mount | `MOUNT` record (so the clean checkpoint is no longer "last") |
| automatic checkpoint | every `ckpt_interval_blocks` block openings (bounds roll-forward), when the ring runs low, after a metadata-block failure, after an unclean mount |
| `sfftl_shutdown()` | checkpoint with the CLEAN flag; nothing may follow it |

## 4. Checkpoint atomicity

Body pages first, commit last. The commit lists the PPN runs of the body; mount loads a checkpoint only if the commit's
CRC is valid, every listed body page is present with matching generation and index and a valid CRC, and the body CRC
matches. An interrupted checkpoint leaves its predecessor in force. Interrupted metadata erases cannot destroy a live
checkpoint (the ring never erases the live region).

## 5. Mount

1. **Zone**: first `meta_blocks` blocks with good markers.
2. **Catalogue**: read every zone page up to the first fully erased page; keep pages whose CRC and header are valid.
3. **Checkpoint**: newest commit whose body loads (§4); otherwise the next older one; none → `SFFTL_ENOFS`, or with
   `SFFTL_F_ALLOW_REBUILD` an empty map with `ckpt_seq = 0` (full rebuild from spare records).
4. **Journal pass 1** (SEQ order, SEQ > `ckpt_seq`): ERASE → `ec = max`, RETIRE, PRETIRE.
5. **Fast path**: if the checkpoint is CLEAN and no valid metadata page is newer than its commit, skip 6–7.
6. **Roll-forward**: for every non-metadata, non-factory-bad block read page 0:
   * erased → nothing was programmed since its last erase;
   * valid with SEQ ≤ `ckpt_seq` → older than the checkpoint; scan only its tail if it was OPEN at the checkpoint;
   * otherwise (newer, torn, unreadable) → scan from page 0.
   Scanning stops at the first fully erased page. Every valid data page with SEQ > `ckpt_seq` is applied to its LPN if it
   is newer than what the L2P holds: a checkpoint mapping is older by construction; a mapping placed by the roll-forward
   itself is compared by reading that page's spare SEQ. Pages failing ECC or CRC are skipped (re-read up to
   `read_retries` first). Unacknowledged torn pages are thus ignored, even when ECC "corrects" them into garbage.
7. **Journal pass 2**: a TRIM record unmaps an LPN only if the record's SEQ is newer than the LPN's surviving data page.
8. **Rebuild** VBM and valid counts from the L2P; open blocks are closed (their erased tail is not reused — a page may be
   half-programmed); free blocks are considered not erased; erase counts of blocks reprogrammed without a journalled
   erase are incremented; `next_seq` = max(commit, every valid SEQ seen) + 1.
9. **Head**: after a clean commit continue on the next erased page; otherwise erase a fresh ring block after the last
   commit / journal page that matters (pages of an interrupted earlier mount are not "live", so repeated failures during
   mount do not consume the ring), then write a new checkpoint immediately (bounds the next roll-forward). If the ring
   cannot provide a block, mount completes **read-only**.

Cost (measured, docs/10 §6): P51 device — clean mount 92 device operations (3.6 ms modelled), unclean after 1/3 ×
capacity of random writes 381 operations (18.8 ms), of which 214 data pages scanned and 209 replayed.

## 6. Why acknowledged data survive (argument)

Let a crash happen at any point. Consider an LPN whose last acknowledged event *E* is a write (data page *P*, SEQ *s*)
or a TRIM (journal page, SEQ *s*).

* **E before the checkpoint used by mount** (`s ≤ ckpt_seq`): the checkpoint captured the LPN's state at `ckpt_seq`. Any
  later *unacknowledged* event may or may not be visible; any later acknowledged event contradicts "last acknowledged".
  Pages with SEQ ≤ `ckpt_seq` are never re-applied, so no older data resurrects.
* **E after the checkpoint** (`s > ckpt_seq`):
  * *P* is still on the medium: it is valid (confirmed program), and its block's page 0 is newer than the checkpoint or
    the block was open at the checkpoint, so the roll-forward scans it. Every other surviving page of that LPN with a
    higher SEQ is an unacknowledged later write (allowed) or a GC copy of *P* itself (same data). Lower SEQs lose.
  * *P* was erased: a block is erased only with zero valid pages, so *P* had been superseded by a GC copy (durable, higher
    SEQ, same data — apply the argument to the copy), by a newer write (contradiction), or by a TRIM (journal page,
    retained in the live region until the next checkpoint subsumes it).
  * E is a TRIM: its journal page has SEQ > `ckpt_seq`, so it is in the live region and applied in pass 2; data pages
    of the LPN with lower SEQ lose, higher ones are later writes.
* Torn pages fail ECC or CRC and are ignored; a torn program never carried an acknowledged write.
* SEQ values never repeat: `next_seq` resumes above every valid SEQ on the medium.

Each step corresponds to tests that fail when the mechanism is removed: `scripts/mutation_check.py` plants 12 such bugs
(SEQ ordering, TRIM journalling, open-block tail scan, TRIM-vs-rewrite ordering, CRC on replay, live-region guard, …);
11 are caught. The surviving one (body-CRC check) is a redundant layer: every body page has its own CRC, generation and
index, and the commit lists exact PPNs.

## 7. Limits

* Erase counts lost with an unflushed journal batch are under-counted (bounded, §5.8 recovers most).
* Rebuild without any metadata cannot recover erase counts, grown-bad knowledge or TRIMs whose journal is gone (old data
  of trimmed LBAs may reappear) — that is why it is opt-in.
* Multi-page writes are not atomic as a unit (each logical page is).
