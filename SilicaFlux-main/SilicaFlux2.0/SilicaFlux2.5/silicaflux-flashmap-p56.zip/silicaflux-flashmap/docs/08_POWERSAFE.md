# 08 — Coordination with PowerSafe

**No PowerSafe project exists in the repository** (docs/00). This document is the contract the FTL offers it, mapped
onto the power-loss hardware that already exists in StorageCore P51. Interface: `include/sfftl_powersafe.h`.

## 1. The property that makes PowerSafe cheap

The FTL keeps **no acknowledged user data and no acknowledged mapping change in RAM only**:

* a write is acknowledged after its page — carrying {LPN, SEQ, CRC} — is programmed and confirmed;
* a TRIM is acknowledged after its journal page is programmed;
* retirement decisions are journalled at once.

So a power-fail warning needs **no checkpoint and no data flush**. The only volatile state worth saving is the batch of
buffered erase-count records (wear statistics). The FTL keeps an erased page ready at the metadata head between calls,
so saving that batch is at most **one page program, never an erase**.

## 2. Sequence (ControlCore, P51 PLP hardware)

| Step | P51 hardware / firmware | FTL call |
|---|---|---|
| 1 | `pwr_fail_ni` falls → `SYS.PLP_STATUS.PWR_FAIL/EVENT`, `IRQ_PLP` (EVENT line); P51 quiesces the command path (`SFS_ST_ABORT_PWR_LOSS`) | ISR: `sfftl_ps_warn(f)` — sets a volatile flag only |
| 2 | main loop resumes; the FTL call in progress returns at its next page boundary with `SFFTL_EPOWER` (= not acknowledged; the host sees the command aborted) | — |
| 3 | main loop | `sfftl_ps_power_fail(f, SFFTL_PS_FLUSH_JOURNAL)`: ≤ 1 page program, then `hal.write_protect(1)` |
| 4 | firmware sets `SYS.PLP_CTRL.FW_SAFE`; with `AUTO_WP` P51 forces WP# on every channel once drained (`PLP_STATUS.WP_ASSERTED`) | — |
| 5a | power really lost: next boot mounts (unclean path, roll-forward) | `sfftl_mount()` |
| 5b | brown-out recovered (`PWR_FAIL` high again, `PLP_CTRL.CLR`) | `sfftl_ps_power_restored(f)`: WP# released, writes accepted |

While warned, every mutating call returns `SFFTL_EPOWER`; reads keep working. Background GC and automatic checkpoints
are suppressed.

## 3. Hold-up budget (in NAND operations, not energy)

`sfftl_ps_worst_case_ops()` reports the worst-case work after the warning, assuming no further failures:

| Item | Reads | Programs | Erases |
|---|---|---|---|
| page operation in flight (host RMW page, or one GC relocation incl. read-back verify) | 1 (+1 with VERIFY_GC_COPY) | 1 | — |
| block opening in flight (erase-on-allocate) | — | — | 1 |
| `sfftl_ps_power_fail` journal page | — | 1 | — |
| **total** | **1–2** | **2** | **1** |

Each program failure in that window adds 1 program + 1 journal program. With the illustrative NANDLab times that is
≈ 2 × 216 µs + 2 ms + 2 × 148 µs ≈ 2.7 ms of device activity. Converting that into hold-up capacitance needs the board's
power figures, which do not exist in the repository — **no capacitance or energy figure is claimed.**

## 4. Tests

* `t_powersafe`: writes and TRIMs refused after the warning; reads served; ≤ 1 program by `power_fail`; WP# asserted
  (the simulated device counts programs under WP# as violations: 0); restore path; then a real loss → mount → every
  acknowledged write present.
* All power-cut tests (docs/09) cut power **without** any warning — the stronger case: durability does not depend on
  PowerSafe at all; PowerSafe only saves wear statistics and bounds the work in flight.

## 5. Open items for the PowerSafe project

* Wire `IRQ_PLP` → `sfftl_ps_warn()` in the P51 firmware event handler and `PLP_CTRL.FW_SAFE` after step 3.
* Measure the real worst-case in-flight time on the target (the RTL run gives cycle counts for each step, docs/10 §4).
* Decide whether the host-visible abort status for interrupted commands should be retried after a brown-out.
