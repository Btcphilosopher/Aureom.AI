# SilicaFlux FlashMap · Project 56 — Flash Translation Layer and NAND management

**Primary directory:** [`firmware/silicaflux_ftl/`](firmware/silicaflux_ftl/) · Aureom.AI | SilicaFlux-STORE

A page-mapping Flash Translation Layer for the SilicaFlux storage controller, in C for the **ControlCore RV32IM**
firmware processor (the toolchain and runtime of the repository). It translates LBAs to physical NAND pages with
out-of-place writes, and manages free space, garbage collection, wear levelling, bad blocks and crash-consistent
mapping persistence. It runs against a simulated NAND device on the host (tests, measurements) and — cross-compiled —
on the **StorageCore (P51) SoC RTL**: the unmodified ControlCore CPU driving the unmodified P51 NAND controller and
flash model in Verilator.

```
host cmd ─► sfftl_write/read/trim/flush ─► L2P (LBA → logical page → physical page) ─► NAND HAL ─┬─► P51 sfs_nand_ctrl (ControlCore firmware, RTL)
                 out-of-place write · paced/greedy/cost-benefit GC · dynamic+static WL            └─► simulated NAND (host tests, benchmarks)
                 bad-block manager · checkpoint + journal + spare-record roll-forward · PowerSafe hooks
```

> **Status — read first.** Host simulation and RTL simulation only. Nothing ran on an FPGA, silicon or a real NAND
> device. NAND timing and reliability numbers are NANDLab's illustrative values; **no device-lifetime figure is derived**.
> No PowerSafe project exists in the repository — this project defines the interface it will use. Delivered as an
> archive; nothing was committed. See [docs/11_LIMITATIONS.md](docs/11_LIMITATIONS.md).

## Definition of done — met

*After arbitrary supported sequences of writes, overwrites, reads, garbage collection and simulated restarts, the FTL
returns the correct acknowledged logical data.*

| Evidence | Result | Report |
|---|---|---|
| Host test suite: 27 tests, independent reference model, zero NAND-rule violations required, invariant checker throughout | **27 / 27 PASS**, 4 882 checks, 0 failures (21 s) | [reports/TESTS.md](reports/TESTS.md) |
| Power cut at **every** device-operation index 0…1 199 of a workload; mount twice + continue + verify | **PASS** (1 200 cut points) | `powercut_sweep` |
| Power cut at **every** operation of a recovery mount (212 ops), then two remounts | **PASS** | `powercut_mount_sweep` |
| 400 random power cuts, ⅓ with a second cut during mount; 150 seeds × 4 cuts under stress-level fault rates | **PASS** — every acknowledged LBA intact; worn-out devices go read-only and still mount | `powercut_random`, `powercut_with_faults` |
| 240 randomized runs: 7 geometries × both GC policies × 3 WL policies, cuts + clean/unclean restarts + random faults | **PASS** | `repeated_random` |
| Sanitizers (ASan + UBSan) | **27 / 27 PASS**, 0 reports | [reports/TESTS.md](reports/TESTS.md) |
| Mutation check: 12 planted FTL bugs | **11 / 12 caught**; survivor is a redundant integrity layer | [reports/mutation.md](reports/mutation.md) |
| FTL firmware on the ControlCore + P51 NAND controller **RTL** (format with 2 factory-bad blocks, fill, 2 061 random writes with GC, TRIM, clean + unclean restart, grown bad block, SECDED single / double-bit errors) | **PASS**: firmware 164 / 164 checks, testbench 8 / 8, 0 NAND protocol / timing errors, 0 re-programs; 344.8 M cycles | [reports/RTL_RUN.md](reports/RTL_RUN.md) |

## Key measurements

| | |
|---|---|
| Write amplification, uniform random 4 KiB, 7 / 15 / 25 / 40 % OP | **6.01 / 3.16 / 2.03 / 1.39**; sequential 1.00 |
| Cost-benefit vs greedy GC, 90/10 hot/cold | WA 5.64 → **3.78** |
| Write latency p99 (modelled), blocking vs **paced** GC | 160.9 ms → **5.2 ms** (max 195 → 12 ms; WA +7 %) |
| Erase-count spread, 20× capacity of 90/10 writes: none / dynamic / dynamic+static WL | max/mean 1.74 / 1.28 / **1.07**; std-dev 26.0 / 14.7 / **4.1** |
| Mapping memory, P51 device (773 × 512-B LBAs) | **8.3 KiB** arena (fits the 32 KiB DMEM); ≈ 1 MiB per GiB at 4-KiB pages |
| Mount, P51 device: clean / after power loss | 92 / 381 device operations |
| Firmware image (RV32IM, `-Os`) | 39.8 KB = 61 % of IMEM, 19.9 KB DMEM; library 29.6 KB text, **0** data/bss |
| ControlCore cycles per host LBA write / read (RTL, incl. GC at WA 3.8) | **86 965 / 12 219** — after a measured firmware optimisation (slice-by-4 CRC, word copies: −27 %); no hardware accelerator justified yet (docs/10 §4) |

Details: [docs/10_PERFORMANCE.md](docs/10_PERFORMANCE.md), [reports/perf/PERF.md](reports/perf/PERF.md), charts in
`reports/perf/*.svg`.

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository audit: ControlCore, NAND controller API, device model, command descriptors, RAM, persistence, runtime | [docs/00_AUDIT.md](docs/00_AUDIT.md) |
| 2 | LBA → logical page → physical page; capacity, LBA size, geometry, page map, unmapped, out-of-range; documented granularity | [docs/02](docs/02_ADDRESS_TRANSLATION.md), `src/ftl_map.c`, `src/ftl_io.c` |
| 3 | Out-of-place write in 5 steps; no silent loss of acknowledged data | [docs/03](docs/03_WRITE_PATH.md), `src/ftl_alloc.c`, `src/ftl_io.c` |
| 4 | Free / valid / invalid pages, free / reserved / bad blocks; deterministic allocator | [docs/04](docs/04_FREE_SPACE_GC.md), `src/ftl_alloc.c`, `sfftl_space()` |
| 5 | GC: victims with invalid pages, verified copies + commitment before erase, never the last valid copy | [docs/04](docs/04_FREE_SPACE_GC.md), `src/ftl_gc.c` |
| 6 | Erase counts, dynamic + static WL, policies, reporting, measured effect, no lifetime inference | [docs/05](docs/05_WEAR_LEVELLING.md), `src/ftl_wear.c` |
| 7 | Factory + grown bad blocks, program / erase / read failure, replacement, markers preserved | [docs/06](docs/06_BAD_BLOCKS.md), `src/ftl_bbm.c` |
| 8 | Checkpoints, journals, generation counters, sequence numbers, integrity checks, recovery; PowerSafe | [docs/07](docs/07_PERSISTENCE.md), [docs/08](docs/08_POWERSAFE.md), `include/sfftl_schema.h`, `src/ftl_meta.c`, `src/ftl_mount.c` |
| 9 | Logical / physical bytes, WA, erase distribution, GC overhead, free space, memory, latency | [docs/10](docs/10_PERFORMANCE.md), `bench/`, `reports/perf/` |
| 10 | Tests incl. reference model; restart recovery; repeated random workloads | [docs/09](docs/09_VERIFICATION.md), `tests/`, [reports/TESTS.md](reports/TESTS.md) |
| 11 | Deliverables | table below |

## Deliverables

| Deliverable | Files |
|---|---|
| FTL source library | `firmware/silicaflux_ftl/src/*.c`, `include/sfftl.h` |
| NAND HAL | `include/sfftl_hal.h`; `hal/sfs/` (ControlCore → P51 `sfs_nand_ctrl`); `hal/sim/` (simulated device) |
| Mapping structures | `src/ftl_map.c` (+ `sfftl_t` in `include/sfftl.h`) |
| Garbage collector | `src/ftl_gc.c` |
| Wear-levelling engine | `src/ftl_wear.c` |
| Bad-block manager | `src/ftl_bbm.c` |
| Persistence schema | `include/sfftl_schema.h`, `src/ftl_meta.c`, `src/ftl_mount.c`, [docs/07](docs/07_PERSISTENCE.md) |
| Recovery tests | `tests/` (reference model `refmodel.c`, harness, 27 tests), `scripts/mutation_check.py` |
| Firmware build | `firmware/silicaflux_ftl/fw/` → `build/flashmap_fw.{img,hex,elf,map,dis}`, `libsfftl_rv32.a`; [reports/firmware_size.md](reports/firmware_size.md); RTL run `rtl_sim/` |
| Performance reports | [reports/perf/PERF.md](reports/perf/PERF.md) (+ CSV, SVG), [reports/RTL_RUN.md](reports/RTL_RUN.md), [docs/10](docs/10_PERFORMANCE.md) |

## Quick start

Tools (Ubuntu 24.04): `gcc`, `gcc-riscv64-unknown-elf` 13.2, `verilator` 5.020, `python3`.

```bash
sudo apt-get install -y gcc-riscv64-unknown-elf verilator
```

```bash
make test
```

```bash
make bench
```

```bash
make fw
```

```bash
make rtl
```

```bash
make mutation
```

`make sanitize` runs the quick suite under ASan/UBSan; `make vendor-check REPO=<Aureom.AI checkout>` re-verifies that
the vendored P51 sources are byte-identical to the repository archive (90 / 90).

## Layout

```
firmware/silicaflux_ftl/  include/ src/ hal/{sfs,sim}/ tests/ bench/ fw/      the FTL (primary directory)
rtl_sim/                  tb_ftl_soc.sv + Makefile: firmware on the P51 SoC RTL (Verilator)
third_party/              StorageCore P51 subset, unmodified (RTL, NAND model, ControlCore runtime), SHA256SUMS
scripts/                  mutation check, charts, vendor check, report generators
docs/                     00 audit … 11 limitations
reports/                  tests, sanitizers, mutation, perf (CSV + SVG), RTL run, firmware size, vendor check
```
