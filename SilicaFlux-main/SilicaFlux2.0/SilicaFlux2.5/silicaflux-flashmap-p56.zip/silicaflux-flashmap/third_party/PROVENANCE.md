# Third-party (vendored) sources

## `silicaflux-storagecore-p51/` — StorageCore SoC, Project 51 (unmodified subset)

Source: `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-storagecore-p51.zip` in `btcphilosopher/Aureom.AI`
(commit `6cef76d`), archive SHA-256 `fdbc980a74069bb6c147a296308d8a5b79417eb0be7279e6d8bb7d9180a84067`.

| Path | Used for |
|---|---|
| `rtl/` (+ `generated/`, `files.f`) | `silicaflux_storage_soc` and `sfs_nand_ctrl` RTL — the DUT of `rtl_sim/tb_ftl_soc.sv` |
| `tb/models/sfs_nand_flash_model.sv`, `sfs_tb_hostmem.sv` | behavioural NAND device and host memory around the DUT |
| `sw/include/generated/sfs_map.h` | storage register map for `hal/sfs` and the firmware |
| `third_party/silicaflux-controlcore/` | ControlCore RTL (P21) and firmware runtime: `crt0.S`, `trap_entry.S`, `fw.ld`, generated `cc_memmap.h` / `cc_memory.ld`, `cc_hw.h`, `scripts/mkimage.py` |
| `third_party/silicaflux-ras/` | SECDED encoder/decoder and ECC SRAM (P26) used by the SoC |
| `README_P51.md` | P51's README (renamed) |

Every file is byte-identical to the archive: `third_party/SHA256SUMS.p51-subset` lists 90 files;
`python3 scripts/check_vendor.py <Aureom.AI checkout>` re-verifies them against the zip
(result in `reports/vendor_check.txt`). P51's own `third_party/PROVENANCE.md` and `SHA256SUMS` trace the ControlCore /
DataFabric / SRAMLIB / MCU-I / SilicaFlux-V files further back to their archives.

No licence file exists in the repository; the same terms as the rest of the repository apply.
