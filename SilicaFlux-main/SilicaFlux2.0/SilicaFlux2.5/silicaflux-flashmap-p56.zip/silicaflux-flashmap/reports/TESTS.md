# Host test results

`make test` (`firmware/silicaflux_ftl/tests`, `build/sfftl_tests`). Every data check goes through the independent reference model (`tests/refmodel.c`); every test also requires **zero NAND-rule violations** from the simulated device (out-of-order program, re-program, 0->1, touching factory-bad blocks, programming under WP#) and `sfftl_check()` == OK. All tests run with `SFFTL_F_PARANOID` (L2P scan before every GC erase) and `SFFTL_F_VERIFY_GC_COPY`. Power-cut model: the interrupted operation is not started / completed / ECC-recoverable / torn (and 1 torn page in 4 slips past ECC as garbage, so only the CRC can reject it). `checks` counts assertions: one "verify all" assertion compares every LBA of the namespace against the reference model (773 LBAs on the P51 geometry), and the power-cut tests make two such assertions per cut point.

| test | result | checks | ms | what it establishes | measured notes |
|---|---|---|---|---|---|
| `geometry_and_range` | **PASS** | 21 | 0 | illegal geometries / configurations rejected; capacity; out-of-range, wrapping and zero-length requests; unmapped LBAs read zeros; space accounting |  |
| `crc32` | **PASS** | 2 | 14 | CRC-32 (slice-by-4) equals a bit-serial IEEE reference at every alignment and split; standard check value |  |
| `sequential` | **PASS** | 4 | 2 | 3 sequential passes over the whole namespace; every LBA verified; sequential rewrite needs no relocation (WA 1) |  |
| `random_overwrite` | **PASS** | 3 | 67 | 6000 random overwrites, each read back immediately (read after overwrite), full verify |  |
| `subpage_rmw` | **PASS** | 4 | 89 | 2 KiB pages / 512 B LBAs: sub-page writes are read-modify-write; random workload with TRIM |  |
| `trim` | **PASS** | 15 | 66 | aligned, unaligned, sub-page and whole-device TRIM; rewrite inside a trimmed range; TRIM durable across crashes |  |
| `full_device` | **PASS** | 8 | 31 | 100 % of the namespace mapped, 8x capacity of single-page random overwrites: no ENOSPC, bounded WA, remount | full device: 773 LBAs, WA 3.72, GC victims 1508, ckpts 98 |
| `gc_policies` | **PASS** | 8 | 268 | greedy and cost-benefit GC under a skewed workload; data verified |  |
| `factory_bad_blocks` | **PASS** | 9 | 112 | 6 % factory-bad blocks found by marker scan; never programmed/erased; markers intact after heavy use |  |
| `program_failures` | **PASS** | 7 | 74 | injected program failures: block retired, write retried, data intact, retirement persisted across remount |  |
| `erase_failures` | **PASS** | 6 | 56 | injected (sticky) erase failures: blocks retired, data intact across remount |  |
| `read_failures` | **PASS** | 18 | 1 | transient UNC (retry), correctable bits, ECC miscorrection (CRC), misdirected read (LPN check), permanent UNC: EIO only for that LBA, block retired with stranded page, rewrite heals |  |
| `random_faults` | **PASS** | 5 | 534 | random program / erase failures, bit flips, refresh relocation, 3 % factory bad; 30000 operations; remount | random faults: prog_fail 12 erase_fail 5 retired 17 corrected 3030 refresh 391 |
| `wear_levelling` | **PASS** | 11 | 226 | hot/cold workload under WL none / dynamic / dynamic+static: static WL narrows the device erase-count spread | wear policy 0: erase-count spread (device ground truth) 224; wear policy 1: erase-count spread (device ground truth) 193; wear policy 2: erase-count spread (device ground truth) 15 |
| `restart_clean` | **PASS** | 62 | 41 | 20 clean shutdown + mount cycles: fast mount path, no data-page scan, all data verified |  |
| `restart_unclean` | **PASS** | 63 | 105 | 60 crashes (RAM discarded, no shutdown) at random points: roll-forward, all data verified |  |
| `powercut_sweep` | **PASS** | 2400 | 2300 | power cut at EVERY device operation index 0..1199 of a workload; mount twice (stability) + continue + verify | 1200 consecutive cut points tested |
| `powercut_random` | **PASS** | 934 | 3979 | 400 random power cuts, 1/3 with a second power cut during the recovery mount | 400 random power cuts (1/3 with a second cut during mount) |
| `powercut_with_faults` | **PASS** | 302 | 2520 | 150 seeds x 4 power cuts under stress fault rates (program 0.2 %, erase 0.5 %): devices may wear out read-only; acknowledged data always intact | 150 seeds x 4 power cuts under stress fault rates; 2 ended read-only (worn out), data intact |
| `powercut_mount_sweep` | **PASS** | 427 | 512 | power cut at EVERY device operation of a recovery mount, then two remounts + verify | recovery mount = 212 device operations; power cut at each of them, then two remounts |
| `degraded_wearout` | **PASS** | 7 | 6 | erase failures until over-provisioning is gone: ENOSPC, all data readable, worn-out device still mounts | stopped after 444 writes: 8 grown bad blocks, no physical space |
| `metadata_fallback` | **PASS** | 7 | 6 | newest checkpoint commit unreadable: mount falls back to the previous checkpoint + roll-forward |  |
| `meta_zone_exhaustion` | **PASS** | 8 | 2 | metadata blocks fail until the ring cannot advance: read-only, live checkpoint never erased, mount works |  |
| `rebuild_from_spare` | **PASS** | 8 | 22 | whole metadata zone destroyed: ENOFS by default; opt-in rebuild from spare records recovers the data |  |
| `powersafe` | **PASS** | 14 | 2 | power-fail warning: writes/TRIM refused, reads served, <= 1 program, WP# asserted; restore; real loss -> data intact |  |
| `configs` | **PASS** | 49 | 564 | 7 geometries (512 B..4 KiB pages, 512 B / 2 KiB / 4 KiB LBAs, 8..64 pages/block): workload, crash, clean remount |  |
| `repeated_random` | **PASS** | 480 | 9611 | 240 randomized runs over 7 geometries x both GC policies x 3 WL policies x checkpoint intervals, random power cuts, clean/unclean restarts, 1/4 with random faults | 240 randomized runs (7 geometries, both GC policies, 3 WL policies, cuts/clean/unclean restarts, faults) |

`SUMMARY 27 tests, 0 failed, 4882 checks, 0 failed checks` — wall time 0m21.305s

## Sanitizers

`make sanitize` (ASan + UBSan, `--quick`): `SUMMARY 27 tests, 0 failed, 1794 checks, 0 failed checks (quick)`, 0 sanitizer reports.
