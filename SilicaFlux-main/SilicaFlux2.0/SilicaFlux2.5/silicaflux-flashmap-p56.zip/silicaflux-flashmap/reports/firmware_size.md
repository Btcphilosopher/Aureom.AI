# Firmware build and size (RV32IM, ControlCore)

Toolchain: `riscv64-unknown-elf-gcc` 13.2, `-march=rv32im_zicsr_zifencei -mabi=ilp32 -Os`, freestanding, `-Wall -Wextra -Werror` clean. Runtime: ControlCore `crt0.S`, `trap_entry.S`, `fw.ld`, `mkimage.py` (unmodified).

## FTL library (`make -C firmware/silicaflux_ftl/fw lib` -> `libsfftl_rv32.a`)

| object | text B | data B | bss B |
|---|---|---|---|
| ftl_alloc.o | 1168 | 0 | 0 |
| ftl_bbm.o | 872 | 0 | 0 |
| ftl_check.o | 1697 | 0 | 0 |
| ftl_gc.o | 3252 | 0 | 0 |
| ftl_io.o | 3468 | 0 | 0 |
| ftl_map.o | 284 | 0 | 0 |
| ftl_meta.o | 3612 | 0 | 0 |
| ftl_mount.o | 8868 | 0 | 0 |
| ftl_util.o | 5915 | 0 | 0 |
| ftl_wear.o | 416 | 0 | 0 |
| (TOTALS) | 29552 | 0 | 0 |

The library has no `.data` / `.bss`: all state is in the caller's arena + `sfftl_t`. `.text` includes the 4 KiB slice-by-4 CRC-32 tables (read-only, IMEM).

## Self-test firmware image (`flashmap_fw`)

| section | bytes | memory | capacity | use |
|---|---|---|---|---|
| text + rodata | 39548 | IMEM | 65 536 | 60 % |
| data + bss | 19872 | DMEM | 32 768 (4 096 reserved for stack by fw.ld) | 61 % |
| image (header + payload) | 39812 | IMEM | 65 536 | 61 % |

Image CRC-32 `0x7bee70e7`, entry `0x00010100`, version `0x00560100`. bss = FTL arena (12 KiB static, 8.3 KiB used) + instance + on-target reference model + I/O buffers.
