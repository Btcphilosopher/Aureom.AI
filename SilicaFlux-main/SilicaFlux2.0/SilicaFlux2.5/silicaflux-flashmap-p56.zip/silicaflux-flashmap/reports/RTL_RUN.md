# FTL firmware on the StorageCore SoC RTL

`make rtl` — Verilator 5.020 model of `rtl_sim/tb_ftl_soc.sv`: the **unmodified** P51 `silicaflux_storage_soc` (ControlCore RV32IM CPU + boot ROM + storage subsystem + `sfs_nand_ctrl`, min1ch parameters with `NAND_PAGE_BYTES = 528`) and P51's behavioural NAND model (64 blocks x 16 pages, raw 768 B; model timing tR 2 us, tPROG 4 us, tBERS 8 us). The host BFM loads `flashmap_fw.hex` through the ControlCore boot ROM (header + CRC32 check); the firmware runs the FTL self-test (`fw/fw_main.c`) with an on-target reference model and reports through `SYSCTRL.TEST_CTRL`.

**Verdict:** `tb_ftl_soc: 8 checks, 0 failures, 344820395 cycles (3448.204 ms at 100 MHz) -> PASS`

Simulated cycles: 344,820,395 at 100 MHz (3.45 s of SoC time); wall time 13m52.233s.

## Firmware console

```

SFCC boot ROM v1.0
ROM: start 00010100 crc 7bee70e7

[fw] SilicaFlux FlashMap FTL self-test, firmware 560100, library 560100
[fw] NAND ch0: CH_INFO page 528 B, ECC 1, READ_ID 10a1da5f -> 0
[fw] layout: arena 8488 B (L2P 3096, bitmap 128, blocks 1024, buffers 1536, journal 1080, scratch 1600), instance 744 B, 5 metadata blocks, checkpoint 9 pages
[fw] formatted: 744 LBAs x 512 B, factory-bad blocks 2 (expected 2: 13, 41)
[fw] verify after sequential fill: 744 LBAs, 0 mismatches
[fw] verify after random overwrites: 744 LBAs, 0 mismatches
[fw] after random overwrites: host LBAs 2805, programs host/reloc/meta 2805/5453/289 (WA x100 = 304), erases 544, GC victims 464, ckpts 32, retired 0, prog_fail 0, read corrected 0 uncorrectable 0
[fw] after random overwrites: blocks free 4 closed 51 open 2 meta 5 bad factory 2 grown 0; EC min 4 max 11 mean x10 87
[fw] verify after TRIM: 744 LBAs, 0 mismatches
[fw] verify after clean restart: 744 LBAs, 0 mismatches
[fw] verify after unclean restart (roll-forward): 744 LBAs, 0 mismatches
TBREQ 1 BAD 49 0 0 0
[fw] verify after grown bad block: 744 LBAs, 0 mismatches
TBREQ 2 FLIP 46 15 125 3
TBREQ 3 FLIP 47 4 250 1
TBREQ 4 FLIP 47 4 250 2
[fw] verify after read errors: 744 LBAs, 0 mismatches
[fw] verify final: 744 LBAs, 0 mismatches
[fw] final: host LBAs 0, programs host/reloc/meta 0/0/9 (WA x100 = 0), erases 1, GC victims 0, ckpts 1, retired 0, prog_fail 0, read corrected 1 uncorrectable 0
[fw] final: blocks free 6 closed 49 open 0 meta 5 bad factory 2 grown 2; EC min 5 max 12 mean x10 100
[fw] RESULT PASS: 164 checks, 0 failures
```

## Testbench

```
TB: factory-bad blocks 13 and 41 marked
TB host: firmware image ../firmware/silicaflux_ftl/fw/build/flashmap_fw.hex, 9953 words
TB host: image accepted at cycle 790465
[285081676] TB: NAND block 49 now fails program/erase (grown bad)
[311648121] TB: flipped bit 3 of raw byte 125, block 46 page 15
[311672057] TB: flipped bit 1 of raw byte 250, block 47 page 4
[311673511] TB: flipped bit 2 of raw byte 250, block 47 page 4
TB summary: NAND reads 11639 programs 9642 erases 622 resets 1; firmware code 164
tb_ftl_soc: 8 checks, 0 failures, 344820395 cycles (3448.204 ms at 100 MHz) -> PASS
```

## CRC-32 / copy microbenchmark (`make -C rtl_sim crcbench`, 528-byte page, RTL CPU cycles)

| variant | cycles | cycles / byte |
|---|---|---|
| byte-at-a-time, table in DMEM (library v1 algorithm) | 7,921 | 15.0 |
| slice-by-4, 4 KiB tables in DMEM (library v2 algorithm) | 4,621 | 8.8 |
| library `sfftl_crc32_update` as built (slice-by-4, tables in IMEM rodata, incl. call) | 5,181 | 9.8 |
| slice-by-8, 8 KiB tables in DMEM | 4,423 | 8.4 |
| word loads + byte table, from buffer SRAM | 7,659 | 14.5 |
| slice-by-8 from buffer SRAM (zero-copy variant) | 4,557 | 8.6 |
| word copy DMEM -> buffer SRAM | 1,323 | 2.5 |
| word copy buffer SRAM -> DMEM | 1,322 | 2.5 |

## Before / after the firmware optimisation

v1 = byte-at-a-time CRC-32 and byte-packing HAL copies (`reports/rtl/rtl_run_v1_bytewise_crc.log`); v2 = slice-by-4 CRC-32 and word copies for aligned buffers (this run). Same workload, same seed.

| measurement | v1 | v2 | v2 / v1 |
|---|---|---|---|
| `write_cycles_per_lba` | 119,949 | 86,965 | 0.73 |
| `hal_cycles_per_lba` | 50,103 | 41,559 | 0.83 |
| `ftl_cycles_per_lba` | 69,846 | 45,406 | 0.65 |
| `read_cycles_per_lba` | 16,967 | 12,219 | 0.72 |
| `ftl_cycles_per_read` | 9,577 | 5,852 | 0.61 |
| `crc32_528B_cycles` | 8,995 | 5,185 | 0.58 |
| `clean_mount_cycles` | 1,591,574 | 1,176,071 | 0.74 |
| `unclean_mount_cycles` | 6,063,613 | 4,428,927 | 0.73 |
| `checkpoint_cycles` | 265,893 | 193,391 | 0.73 |
| `random_phase_cycles` | 247,215,226 | 179,236,844 | 0.73 |
| `copy_cycles` | 37,381,236 | 19,772,030 | 0.53 |

## Cycle measurements (mcycle on the RTL CPU, 100 MHz)

`hal` = cycles inside HAL calls: register staging, polling the NAND controller while the bus transfer and the model's array time run, and CPU copies DMEM <-> buffer SRAM. `ftl` = everything else (mapping, allocation, GC decisions, CRC-32 of every page, spare records, journal, checks).

| measurement | cycles |
|---|---|
| `write_cycles_per_lba` | 86,965 |
| `hal_cycles_per_lba` | 41,559 |
| `ftl_cycles_per_lba` | 45,406 |
| `read_cycles_per_lba` | 12,219 |
| `hal_cycles_per_read` | 6,367 |
| `ftl_cycles_per_read` | 5,852 |
| `unmapped_read_cycles` | 1,678 |
| `crc32_528B_cycles` | 5,185 |
| `format_cycles` | 371,849 |
| `shutdown_cycles` | 191,880 |
| `clean_mount_cycles` | 1,176,071 |
| `unclean_mount_cycles` | 4,428,927 |
| `checkpoint_cycles` | 193,391 |

Random-overwrite phase: 2061 host LBAs, 7775 NAND programs, 5547 reads, 481 erases in 179,236,844 cycles; of which HAL 85,653,327 (CPU copies 19,772,030).
