#!/usr/bin/env python3
"""SilicaFlux FlashMap -- reports/TESTS.md from reports/tests.log (+ sanitize.log)."""
import os, re, sys

DESC = {
    "geometry_and_range": "illegal geometries / configurations rejected; capacity; out-of-range, wrapping and zero-length requests; unmapped LBAs read zeros; space accounting",
    "crc32": "CRC-32 (slice-by-4) equals a bit-serial IEEE reference at every alignment and split; standard check value",
    "sequential": "3 sequential passes over the whole namespace; every LBA verified; sequential rewrite needs no relocation (WA 1)",
    "random_overwrite": "6000 random overwrites, each read back immediately (read after overwrite), full verify",
    "subpage_rmw": "2 KiB pages / 512 B LBAs: sub-page writes are read-modify-write; random workload with TRIM",
    "trim": "aligned, unaligned, sub-page and whole-device TRIM; rewrite inside a trimmed range; TRIM durable across crashes",
    "full_device": "100 % of the namespace mapped, 8x capacity of single-page random overwrites: no ENOSPC, bounded WA, remount",
    "gc_policies": "greedy and cost-benefit GC under a skewed workload; data verified",
    "factory_bad_blocks": "6 % factory-bad blocks found by marker scan; never programmed/erased; markers intact after heavy use",
    "program_failures": "injected program failures: block retired, write retried, data intact, retirement persisted across remount",
    "erase_failures": "injected (sticky) erase failures: blocks retired, data intact across remount",
    "read_failures": "transient UNC (retry), correctable bits, ECC miscorrection (CRC), misdirected read (LPN check), permanent UNC: EIO only for that LBA, block retired with stranded page, rewrite heals",
    "random_faults": "random program / erase failures, bit flips, refresh relocation, 3 % factory bad; 30000 operations; remount",
    "wear_levelling": "hot/cold workload under WL none / dynamic / dynamic+static: static WL narrows the device erase-count spread",
    "restart_clean": "20 clean shutdown + mount cycles: fast mount path, no data-page scan, all data verified",
    "restart_unclean": "60 crashes (RAM discarded, no shutdown) at random points: roll-forward, all data verified",
    "powercut_sweep": "power cut at EVERY device operation index 0..1199 of a workload; mount twice (stability) + continue + verify",
    "powercut_random": "400 random power cuts, 1/3 with a second power cut during the recovery mount",
    "powercut_with_faults": "150 seeds x 4 power cuts under stress fault rates (program 0.2 %, erase 0.5 %): devices may wear out read-only; acknowledged data always intact",
    "powercut_mount_sweep": "power cut at EVERY device operation of a recovery mount, then two remounts + verify",
    "degraded_wearout": "erase failures until over-provisioning is gone: ENOSPC, all data readable, worn-out device still mounts",
    "metadata_fallback": "newest checkpoint commit unreadable: mount falls back to the previous checkpoint + roll-forward",
    "meta_zone_exhaustion": "metadata blocks fail until the ring cannot advance: read-only, live checkpoint never erased, mount works",
    "rebuild_from_spare": "whole metadata zone destroyed: ENOFS by default; opt-in rebuild from spare records recovers the data",
    "powersafe": "power-fail warning: writes/TRIM refused, reads served, <= 1 program, WP# asserted; restore; real loss -> data intact",
    "configs": "7 geometries (512 B..4 KiB pages, 512 B / 2 KiB / 4 KiB LBAs, 8..64 pages/block): workload, crash, clean remount",
    "repeated_random": "240 randomized runs over 7 geometries x both GC policies x 3 WL policies x checkpoint intervals, random power cuts, clean/unclean restarts, 1/4 with random faults",
}

def main():
    log = open("reports/tests.log").read()
    rows = re.findall(r"RESULT (\S+)\s+(PASS|FAIL)\s+(\d+) checks\s+(\d+) ms", log)
    summ = re.search(r"SUMMARY .*", log)
    real = re.search(r"real\s+(\S+)", log)
    notes = {}
    cur = None
    for line in log.splitlines():
        m = re.match(r"\[ RUN  \] (\S+)", line)
        if m: cur = m.group(1); continue
        if cur and line.startswith("    ") and "FAIL" not in line:
            notes.setdefault(cur, []).append(line.strip())
    md = ["# Host test results", "",
          "`make test` (`firmware/silicaflux_ftl/tests`, `build/sfftl_tests`). Every data check goes through the independent "
          "reference model (`tests/refmodel.c`); every test also requires **zero NAND-rule violations** from the simulated "
          "device (out-of-order program, re-program, 0->1, touching factory-bad blocks, programming under WP#) and "
          "`sfftl_check()` == OK. All tests run with `SFFTL_F_PARANOID` (L2P scan before every GC erase) and "
          "`SFFTL_F_VERIFY_GC_COPY`. Power-cut model: the interrupted operation is not started / completed / "
          "ECC-recoverable / torn (and 1 torn page in 4 slips past ECC as garbage, so only the CRC can reject it). "
          "`checks` counts assertions: one \"verify all\" assertion compares every LBA of the namespace against the "
          "reference model (773 LBAs on the P51 geometry), and the power-cut tests make two such assertions per cut point.", "",
          "| test | result | checks | ms | what it establishes | measured notes |", "|---|---|---|---|---|---|"]
    for name, res, checks, ms in rows:
        md.append(f"| `{name}` | **{res}** | {checks} | {ms} | {DESC.get(name, '')} | {'; '.join(notes.get(name, []))} |")
    md += ["", f"`{summ.group(0) if summ else 'no summary'}` — wall time {real.group(1) if real else '?'}", ""]
    if os.path.exists("reports/sanitize.log"):
        s = open("reports/sanitize.log").read()
        m = re.search(r"SUMMARY .*", s)
        errs = len(re.findall(r"runtime error|AddressSanitizer", s))
        md += ["## Sanitizers", "", f"`make sanitize` (ASan + UBSan, `--quick`): `{m.group(0) if m else '?'}`, "
               f"{errs} sanitizer reports.", ""]
    open("reports/TESTS.md", "w").write("\n".join(md))
    print("\n".join(md[-6:]))

if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    main()
