#!/usr/bin/env python3
"""SilicaFlux FlashMap -- mutation check of the host test suite.

Each mutation plants one deliberate bug in a private copy of the FTL sources,
rebuilds the test binary and runs the quick suite.  A mutation is "killed"
when the suite fails.  A surviving mutation means a test gap.

    python3 scripts/mutation_check.py [--out reports/mutation.md]
"""
import os, shutil, subprocess, sys, tempfile, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FTL = os.path.join(ROOT, "firmware", "silicaflux_ftl")

MUTATIONS = [
    ("replay ignores SEQ order (older copy may win)", "src/ftl_mount.c",
     "    if (cur >= seq) return SFFTL_OK;\n", "    if (cur >= seq + (1ull << 47)) return SFFTL_OK;\n"),
    ("GC erases a victim that still holds one valid page", "src/ftl_gc.c",
     "while (*cursor < ppb && bk->state == SFFTL_BS_CLOSED && bk->valid > 0 && budget > 0)",
     "while (*cursor < ppb && bk->state == SFFTL_BS_CLOSED && bk->valid > 1 && budget > 0)"),
    ("TRIM acknowledged without its journal record", "src/ftl_io.c",
     "      rc = journal_flush(f);\n      if (rc < 0) return rc;\n      for (uint64_t l = first; l < last; l++) map_unmap(f, (uint32_t)l);",
     "      f->jn--;\n      for (uint64_t l = first; l < last; l++) map_unmap(f, (uint32_t)l);"),
    ("free block reused without erase", "src/ftl_alloc.c",
     "    if (!(bk->flags & SFFTL_BF_ERASED)) {", "    if (0) {"),
    ("mount trusts spare records without the CRC", "src/ftl_mount.c",
     "        r = oob_parse(f, spare, f->buf_host, &o);\n        if (r >= 0) break;",
     "        r = oob_parse(f, spare, NULL, &o);\n        if (r >= 0) break;"),
    ("TRIM replay ignores newer rewrites", "src/ftl_mount.c",
     "            if (cur > best) continue;                  /* rewritten after the TRIM */",
     "            (void)cur;"),
    ("roll-forward skips blocks open at the checkpoint", "src/ftl_mount.c",
     "        from = bk->wp;                                      /* open at the checkpoint: its tail is new */",
     "        continue;"),
    ("mapping committed even when the program failed", "src/ftl_alloc.c",
     "    if (st != SFFTL_HAL_PROGRAM_FAIL) return hal_rc(st);\n    rc = bbm_program_failed(f, b);\n    if (rc < 0) return rc;",
     "    if (st != SFFTL_HAL_PROGRAM_FAIL) return hal_rc(st);\n    *out = ppn;\n    return SFFTL_OK;"),
    ("checkpoint body CRC not verified at mount", "src/ftl_mount.c",
     "  if (k != W || idx != body_pages || SFFTL_CRC_FINAL(crc) != body_crc) return SFFTL_EIO;",
     "  if (k != W || idx != body_pages || (body_crc == 1u && crc == 2u)) return SFFTL_EIO;"),
    ("metadata ring erases into the live region", "src/ftl_meta.c",
     "      if (c == f->mz_live_start) break;                         /* never into the live region */",
     "      (void)0;"),
    ("host read skips the LPN check (misdirected read)", "src/ftl_io.c",
     "    else if (o.type == SFFTL_OOB_TYPE_META || o.tag != lpn) { f->st.lpn_mismatch++; bad = 1; }",
     "    else if (o.type == SFFTL_OOB_TYPE_META) { f->st.lpn_mismatch++; bad = 1; }"),
    ("factory-bad blocks allocated as data blocks", "src/ftl_mount.c",
     "    if (bad) { f->blk[b].state = SFFTL_BS_BAD; f->blk[b].flags = SFFTL_BF_FACTORY; nbad++; }",
     "    if (bad) { nbad++; }"),
]

def run(cmd, cwd):
    return subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

def main():
    out = sys.argv[sys.argv.index("--out") + 1] if "--out" in sys.argv else None
    rows, killed = [], 0
    for name, path, old, new in MUTATIONS:
        tmp = tempfile.mkdtemp(prefix="sfftl_mut_")
        try:
            shutil.copytree(FTL, os.path.join(tmp, "ftl"), ignore=shutil.ignore_patterns("build", "fw"))
            d = os.path.join(tmp, "ftl")
            src = open(os.path.join(d, path)).read()
            if src.count(old) != 1:
                rows.append((name, "NOT APPLIED (pattern not found once)", "")); continue
            open(os.path.join(d, path), "w").write(src.replace(old, new))
            b = run(["make", "-s", "build/sfftl_tests"], d)
            if b.returncode != 0:
                rows.append((name, "killed (does not compile)", "")); killed += 1; continue
            t0 = time.time()
            r = run(["timeout", "900", "./build/sfftl_tests", "--quick"], d)
            dt = time.time() - t0
            failed = [l.split()[1] for l in r.stdout.splitlines() if l.startswith("RESULT") and " FAIL " in l]
            crashed = r.returncode not in (0, 1)
            if r.returncode != 0:
                killed += 1
                how = ("crash/timeout, " if crashed else "") + ", ".join(failed[:4]) + (" ..." if len(failed) > 4 else "")
                rows.append((name, "**killed**", how))
            else:
                rows.append((name, "SURVIVED", ""))
            print(f"{name}: {rows[-1][1]} {rows[-1][2]} ({dt:.0f}s)", flush=True)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    md = ["# Mutation check of the test suite", "",
          "Each row plants one deliberate bug into a copy of the FTL and runs `sfftl_tests --quick`. "
          "`killed` = the suite failed (good). Generated by `scripts/mutation_check.py`.", "",
          "| planted bug | result | failing tests |", "|---|---|---|"]
    md += [f"| {n} | {r} | {h} |" for n, r, h in rows]
    md += ["", f"**{killed} / {len(MUTATIONS)} mutations killed.**", ""]
    text = "\n".join(md)
    print(text)
    if out:
        open(out, "w").write(text)
    return 0 if killed == len(MUTATIONS) else 1

if __name__ == "__main__":
    sys.exit(main())
