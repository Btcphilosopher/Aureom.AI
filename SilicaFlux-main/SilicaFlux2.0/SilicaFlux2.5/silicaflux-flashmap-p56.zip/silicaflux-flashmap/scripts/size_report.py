#!/usr/bin/env python3
"""SilicaFlux FlashMap -- firmware / library size report from the RV32 build outputs.

    python3 scripts/size_report.py firmware/silicaflux_ftl/fw/build reports/firmware_size.md
"""
import json, os, re, sys

def main():
    b, out = sys.argv[1], sys.argv[2]
    lib = open(os.path.join(b, "size_lib.txt")).read().strip().splitlines()
    fw = open(os.path.join(b, "size_fw.txt")).read().strip().splitlines()
    img = json.load(open(os.path.join(b, "flashmap_fw.json")))
    t, d, s = (int(x) for x in fw[1].split()[:3])
    rows = []
    for line in lib[1:]:
        p = line.split()
        rows.append((os.path.basename(p[5]) if len(p) > 5 else p[-1], int(p[0]), int(p[1]), int(p[2])))
    md = ["# Firmware build and size (RV32IM, ControlCore)", "",
          "Toolchain: `riscv64-unknown-elf-gcc` 13.2, `-march=rv32im_zicsr_zifencei -mabi=ilp32 -Os`, freestanding, "
          "`-Wall -Wextra -Werror` clean. Runtime: ControlCore `crt0.S`, `trap_entry.S`, `fw.ld`, `mkimage.py` (unmodified).", "",
          "## FTL library (`make -C firmware/silicaflux_ftl/fw lib` -> `libsfftl_rv32.a`)", "",
          "| object | text B | data B | bss B |", "|---|---|---|---|"]
    md += [f"| {n} | {a} | {c} | {e} |" for n, a, c, e in rows]
    md += ["", "The library has no `.data` / `.bss`: all state is in the caller's arena + `sfftl_t`. "
           "`.text` includes the 4 KiB slice-by-4 CRC-32 tables (read-only, IMEM).", "",
           "## Self-test firmware image (`flashmap_fw`)", "",
           "| section | bytes | memory | capacity | use |", "|---|---|---|---|---|",
           f"| text + rodata | {t} | IMEM | 65 536 | {100 * t / 65536:.0f} % |",
           f"| data + bss | {d + s} | DMEM | 32 768 (4 096 reserved for stack by fw.ld) | {100 * (d + s) / 32768:.0f} % |",
           f"| image (header + payload) | {img['size']} | IMEM | 65 536 | {100 * img['size'] / 65536:.0f} % |", "",
           f"Image CRC-32 `{img['crc32']}`, entry `{img['entry']}`, version `{img['version']}`. "
           "bss = FTL arena (12 KiB static, 8.3 KiB used) + instance + on-target reference model + I/O buffers.", ""]
    open(out, "w").write("\n".join(md))
    print("\n".join(md))

if __name__ == "__main__":
    main()
