#!/usr/bin/env python3
"""SilicaFlux FlashMap -- reports/RTL_RUN.md from reports/rtl/rtl_run.log."""
import os, re

def perf_of(text):
    perf = {}
    for m in re.finditer(r"PERF (.*?)(?:  @\d+)?$", text, re.M):
        for kv in m.group(1).split():
            if "=" in kv:
                k, v = kv.split("=", 1)
                perf[k] = int(v)
    return perf

def main():
    log = open("reports/rtl/rtl_run.log").read()
    perf = perf_of(log)
    v1 = perf_of(open("reports/rtl/rtl_run_v1_bytewise_crc.log").read()) if os.path.exists("reports/rtl/rtl_run_v1_bytewise_crc.log") else {}
    cb = perf_of(open("reports/rtl/crcbench.log").read()) if os.path.exists("reports/rtl/crcbench.log") else {}
    fw = [re.sub(r"\s+@\d+$", "", l[4:]) for l in log.splitlines() if l.startswith("FW| ") and "PERF" not in l]
    tb = [l for l in log.splitlines() if l.startswith(("TB", "tb_ftl_soc", "[")) and "FW|" not in l]
    verdict = re.search(r"tb_ftl_soc: .*", log)
    real = re.search(r"real\s+(\S+)", log)
    cyc = re.search(r"(\d+) cycles \(", log)
    md = ["# FTL firmware on the StorageCore SoC RTL", "",
          "`make rtl` — Verilator 5.020 model of `rtl_sim/tb_ftl_soc.sv`: the **unmodified** P51 `silicaflux_storage_soc` "
          "(ControlCore RV32IM CPU + boot ROM + storage subsystem + `sfs_nand_ctrl`, min1ch parameters with "
          "`NAND_PAGE_BYTES = 528`) and P51's behavioural NAND model (64 blocks x 16 pages, raw 768 B; model timing "
          "tR 2 us, tPROG 4 us, tBERS 8 us). The host BFM loads `flashmap_fw.hex` through the ControlCore boot ROM "
          "(header + CRC32 check); the firmware runs the FTL self-test (`fw/fw_main.c`) with an on-target reference "
          "model and reports through `SYSCTRL.TEST_CTRL`.", "",
          f"**Verdict:** `{verdict.group(0) if verdict else 'no verdict (run incomplete)'}`", "",
          f"Simulated cycles: {int(cyc.group(1)):,} at 100 MHz ({int(cyc.group(1)) / 1e8:.2f} s of SoC time); "
          f"wall time {real.group(1) if real else '?'}." if cyc else "", "",
          "## Firmware console", "", "```"] + fw + ["```", "", "## Testbench", "", "```"] + tb + ["```", ""]
    if perf:
        def g(k): return perf.get(k, 0)
        if cb:
            md += ["## CRC-32 / copy microbenchmark (`make -C rtl_sim crcbench`, 528-byte page, RTL CPU cycles)", "",
                   "| variant | cycles | cycles / byte |", "|---|---|---|"]
            for k, lab in [("crc_bytewise_dmem", "byte-at-a-time, table in DMEM (library v1 algorithm)"), ("crc_slice4_dmem", "slice-by-4, 4 KiB tables in DMEM (library v2 algorithm)"),
                           ("crc_library_dmem", "library `sfftl_crc32_update` as built (slice-by-4, tables in IMEM rodata, incl. call)"),
                           ("crc_slice8_dmem", "slice-by-8, 8 KiB tables in DMEM"), ("crc_bytewise_bufsram", "word loads + byte table, from buffer SRAM"),
                           ("crc_slice8_bufsram", "slice-by-8 from buffer SRAM (zero-copy variant)"),
                           ("copy_dmem_to_bufsram", "word copy DMEM -> buffer SRAM"), ("copy_bufsram_to_dmem", "word copy buffer SRAM -> DMEM")]:
                if k in cb: md.append(f"| {lab} | {cb[k]:,} | {cb[k] / 528:.1f} |")
            md += [""]
        if v1:
            keys = ["write_cycles_per_lba", "hal_cycles_per_lba", "ftl_cycles_per_lba", "read_cycles_per_lba", "ftl_cycles_per_read",
                    "crc32_528B_cycles", "clean_mount_cycles", "unclean_mount_cycles", "checkpoint_cycles", "random_phase_cycles", "copy_cycles"]
            md += ["## Before / after the firmware optimisation", "",
                   "v1 = byte-at-a-time CRC-32 and byte-packing HAL copies (`reports/rtl/rtl_run_v1_bytewise_crc.log`); "
                   "v2 = slice-by-4 CRC-32 and word copies for aligned buffers (this run). Same workload, same seed.", "",
                   "| measurement | v1 | v2 | v2 / v1 |", "|---|---|---|---|"]
            for k in keys:
                if k in v1 and k in perf:
                    md.append(f"| `{k}` | {v1[k]:,} | {perf[k]:,} | {perf[k] / v1[k]:.2f} |")
            md += [""]
        md += ["## Cycle measurements (mcycle on the RTL CPU, 100 MHz)", "",
               "`hal` = cycles inside HAL calls: register staging, polling the NAND controller while the bus transfer and "
               "the model's array time run, and CPU copies DMEM <-> buffer SRAM. `ftl` = everything else (mapping, "
               "allocation, GC decisions, CRC-32 of every page, spare records, journal, checks).", "",
               "| measurement | cycles |", "|---|---|"]
        for k in ["write_cycles_per_lba", "hal_cycles_per_lba", "ftl_cycles_per_lba", "read_cycles_per_lba",
                  "hal_cycles_per_read", "ftl_cycles_per_read", "unmapped_read_cycles", "crc32_528B_cycles",
                  "format_cycles", "shutdown_cycles", "clean_mount_cycles", "unclean_mount_cycles", "checkpoint_cycles"]:
            if k in perf: md.append(f"| `{k}` | {perf[k]:,} |")
        if g("random_phase_cycles"):
            md += ["", f"Random-overwrite phase: {g('host_lbas')} host LBAs, {g('nand_programs')} NAND programs, "
                   f"{g('nand_reads')} reads, {g('nand_erases')} erases in {g('random_phase_cycles'):,} cycles; "
                   f"of which HAL {g('hal_cycles'):,} (CPU copies {g('copy_cycles'):,}).", ""]
    open("reports/RTL_RUN.md", "w").write("\n".join(md))
    print(verdict.group(0) if verdict else "no verdict")

if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    main()
