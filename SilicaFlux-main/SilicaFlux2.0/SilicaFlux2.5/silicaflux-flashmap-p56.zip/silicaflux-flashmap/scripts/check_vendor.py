#!/usr/bin/env python3
"""SilicaFlux FlashMap -- check that the vendored StorageCore P51 subset is
byte-identical to the archive in the repository.

    python3 scripts/check_vendor.py <path to the Aureom.AI checkout>

Compares every file listed in third_party/SHA256SUMS.p51-subset with the
same path inside SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-storagecore-p51.zip.
"""
import hashlib, os, sys, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ZIP_REL = "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-storagecore-p51.zip"

def main():
    if len(sys.argv) < 2:
        print(__doc__); return 2
    zpath = os.path.join(sys.argv[1], ZIP_REL)
    sums = os.path.join(ROOT, "third_party", "SHA256SUMS.p51-subset")
    vend = os.path.join(ROOT, "third_party", "silicaflux-storagecore-p51")
    z = zipfile.ZipFile(zpath)
    names = {n: n for n in z.namelist()}
    ok = bad = 0
    for line in open(sums):
        digest, rel = line.split(None, 1)
        rel = rel.strip().lstrip("./")
        local = os.path.join(vend, rel)
        zname = "silicaflux-storagecore/" + (rel if rel != "README_P51.md" else "README.md")
        h_local = hashlib.sha256(open(local, "rb").read()).hexdigest()
        h_zip = hashlib.sha256(z.read(names[zname])).hexdigest() if zname in names else None
        if h_local == digest == h_zip:
            ok += 1
        else:
            bad += 1
            print("MISMATCH", rel, "(local", h_local[:12], "listed", digest[:12], "archive", (h_zip or "missing")[:12], ")")
    print(f"vendored P51 files byte-identical to {ZIP_REL}: {ok}/{ok + bad}")
    return 0 if bad == 0 else 1

if __name__ == "__main__":
    sys.exit(main())
