#!/usr/bin/env python3
"""SilicaFlux FlashMap -- SVG charts from the benchmark CSVs (no dependencies).

    python3 scripts/make_charts.py reports/perf

Writes into the same directory:
    wear_erase_counts.svg   per-block erase counts, sorted, one line per WL policy
    wa_vs_op.svg            write amplification vs over-provisioning (uniform random)
    latency_cdf.svg         write latency distribution, paced vs blocking GC
    free_space.svg          free blocks over time (uniform random, paced GC)
"""
import csv, os, sys

W, H, ML, MR, MT, MB = 720, 400, 70, 20, 40, 55
COL = ["#2563eb", "#dc2626", "#16a34a", "#9333ea", "#ea580c"]

def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;")

class Chart:
    def __init__(self, title, xlabel, ylabel, xmin, xmax, ymin, ymax, logx=False):
        self.t, self.xl, self.yl = title, xlabel, ylabel
        self.x0, self.x1, self.y0, self.y1, self.logx = xmin, xmax, ymin, ymax, logx
        self.items = []
    def sx(self, x):
        import math
        if self.logx:
            x, a, b = math.log10(max(x, 1e-9)), math.log10(self.x0), math.log10(self.x1)
        else:
            a, b = self.x0, self.x1
        return ML + (x - a) / (b - a) * (W - ML - MR)
    def sy(self, y): return H - MB - (y - self.y0) / (self.y1 - self.y0) * (H - MT - MB)
    def line(self, xs, ys, label, i):
        pts = " ".join(f"{self.sx(x):.1f},{self.sy(y):.1f}" for x, y in zip(xs, ys))
        self.items.append(f'<polyline fill="none" stroke="{COL[i % 5]}" stroke-width="2" points="{pts}"/>')
        self.legend(label, i)
    def bars(self, labels, ys, i0=0):
        n = len(ys); bw = (W - ML - MR) / n * 0.6
        for k, (lab, y) in enumerate(zip(labels, ys)):
            cx = ML + (k + 0.5) * (W - ML - MR) / n
            self.items.append(f'<rect x="{cx - bw / 2:.1f}" y="{self.sy(y):.1f}" width="{bw:.1f}" height="{self.sy(self.y0) - self.sy(y):.1f}" fill="{COL[(i0 + k) % 5]}"/>')
            self.items.append(f'<text x="{cx:.1f}" y="{self.sy(y) - 5:.1f}" text-anchor="middle" font-size="12">{y:.2f}</text>')
            self.items.append(f'<text x="{cx:.1f}" y="{H - MB + 18}" text-anchor="middle" font-size="12">{esc(lab)}</text>')
    def legend(self, label, i):
        y = MT + 8 + 18 * i
        self.items.append(f'<rect x="{W - MR - 210}" y="{y - 9}" width="12" height="12" fill="{COL[i % 5]}"/>')
        self.items.append(f'<text x="{W - MR - 192}" y="{y + 2}" font-size="12">{esc(label)}</text>')
    def svg(self, xticks=None, yticks=None, xtick_labels=True):
        o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" font-family="sans-serif">',
             f'<rect width="{W}" height="{H}" fill="white"/>',
             f'<text x="{W / 2}" y="22" text-anchor="middle" font-size="15" font-weight="bold">{esc(self.t)}</text>',
             f'<line x1="{ML}" y1="{H - MB}" x2="{W - MR}" y2="{H - MB}" stroke="#333"/>',
             f'<line x1="{ML}" y1="{MT}" x2="{ML}" y2="{H - MB}" stroke="#333"/>',
             f'<text x="{(ML + W - MR) / 2}" y="{H - 12}" text-anchor="middle" font-size="13">{esc(self.xl)}</text>',
             f'<text x="16" y="{(MT + H - MB) / 2}" text-anchor="middle" font-size="13" transform="rotate(-90 16 {(MT + H - MB) / 2})">{esc(self.yl)}</text>']
        for t in (yticks or []):
            t, lab = t if isinstance(t, tuple) else (t, f"{t:g}")
            o.append(f'<line x1="{ML - 4}" y1="{self.sy(t):.1f}" x2="{W - MR}" y2="{self.sy(t):.1f}" stroke="#ddd"/>')
            o.append(f'<text x="{ML - 7}" y="{self.sy(t) + 4:.1f}" text-anchor="end" font-size="11">{lab}</text>')
        if xtick_labels:
            for t in (xticks or []):
                o.append(f'<line x1="{self.sx(t):.1f}" y1="{H - MB}" x2="{self.sx(t):.1f}" y2="{H - MB + 4}" stroke="#333"/>')
                o.append(f'<text x="{self.sx(t):.1f}" y="{H - MB + 17}" text-anchor="middle" font-size="11">{t:g}</text>')
        return "\n".join(o + self.items + ["</svg>"])

def rd(path):
    with open(path) as f: return list(csv.DictReader(f))

def ticks(lo, hi, n=5):
    import math
    step = (hi - lo) / n
    mag = 10 ** math.floor(math.log10(step)) if step > 0 else 1
    step = max(mag * k for k in (1, 2, 5, 10) if mag * k <= step * 1.5) if step > 0 else 1
    t, out = math.floor(lo / step) * step, []
    while t <= hi + 1e-9: out.append(round(t, 6)); t += step
    return out

def main():
    d = sys.argv[1] if len(sys.argv) > 1 else "reports/perf"
    # ---- wear
    sets = [("none", "erase_counts_wl_none.csv"), ("dynamic", "erase_counts_wl_dynamic.csv"), ("dynamic + static", "erase_counts_wl_static.csv")]
    curves = []
    for name, fn in sets:
        p = os.path.join(d, fn)
        if not os.path.exists(p): continue
        ec = sorted(int(r["device_erase_count"]) for r in rd(p) if r["state"] not in ("3", "4"))
        curves.append((name, ec))
    if curves:
        ymax = max(max(c) for _, c in curves) * 1.1
        n = max(len(c) for _, c in curves)
        ch = Chart("Erase count per data block (sorted), 90/10 hot/cold, 20x capacity", "data blocks (sorted by erase count)",
                   "erase count (device ground truth)", 0, n, 0, ymax)
        for i, (name, c) in enumerate(curves): ch.line(range(len(c)), c, f"WL {name}", i)
        open(os.path.join(d, "wear_erase_counts.svg"), "w").write(ch.svg(ticks(0, n), ticks(0, ymax)))
    # ---- WA vs OP
    runs = rd(os.path.join(d, "runs.csv"))
    pts = []
    for r in runs:
        if r["pattern"] == "uniform" and r["device"].startswith("Bench") and r["gc"] == "greedy" and "blocking" not in r["run"] \
                and "read" not in r["run"]:
            pts.append((int(r["op_permille"]) / 10.0, float(r["wa_total"])))
    pts = sorted(set(pts))
    if pts:
        ch = Chart("Write amplification vs over-provisioning (uniform random 4 KiB, greedy, paced GC)", "over-provisioning",
                   "write amplification", 0, 1, 0, max(p[1] for p in pts) * 1.2)
        ch.bars([f"{p[0]:g} %" for p in pts], [p[1] for p in pts])
        open(os.path.join(d, "wa_vs_op.svg"), "w").write(ch.svg([], ticks(0, max(p[1] for p in pts) * 1.2), False))
    # ---- latency CDF
    lat = [("paced GC", "latency_uniform.csv"), ("blocking GC only", "latency_uniform_blocking.csv")]
    curves = []
    for name, fn in lat:
        p = os.path.join(d, fn)
        if os.path.exists(p):
            rows = rd(p)
            curves.append((name, [max(float(r["write_us"]), 1.0) for r in rows], [float(r["percentile"]) for r in rows]))
    if curves:
        import math
        nines = lambda p: min(math.log10(1.0 / max(1.0 - p, 1e-4)), 3.4)
        xmax = max(max(c[1]) for c in curves) * 1.5
        ch = Chart("Write latency distribution, uniform random (modelled device time)", "latency per write (us, log scale)",
                   "percentile", 100, xmax, 0, 3.5, logx=True)
        for i, (name, xs, ys) in enumerate(curves): ch.line(xs, [nines(y) for y in ys], name, i)
        xt = [t for t in (100, 1000, 10000, 100000, 1000000) if t <= xmax]
        yt = [(0, "p0"), (nines(0.5), "p50"), (1, "p90"), (2, "p99"), (3, "p99.9")]
        open(os.path.join(d, "latency_cdf.svg"), "w").write(ch.svg(xt, yt))
    # ---- free space
    p = os.path.join(d, "timeline_uniform.csv")
    if os.path.exists(p):
        rows = rd(p)
        xs = [float(r["capacity_multiple"]) for r in rows]
        fb = [int(r["free_blocks"]) for r in rows]
        wa = [float(r["wa_cumulative"]) for r in rows]
        ymax = max(max(fb), max(wa)) * 1.2
        ch = Chart("Free blocks and cumulative WA over time (uniform random, paced GC)", "host writes / capacity",
                   "free blocks  |  cumulative WA", 0, max(xs), 0, ymax)
        ch.line(xs, fb, "free blocks", 0)
        ch.line(xs, wa, "cumulative WA", 1)
        open(os.path.join(d, "free_space.svg"), "w").write(ch.svg(ticks(0, max(xs)), ticks(0, ymax)))
    print("charts written to", d)

if __name__ == "__main__":
    main()
