# firmware/silicaflux_ftl — FlashMap FTL library

Page-mapping Flash Translation Layer for the SilicaFlux storage controller (Aureom.AI | SilicaFlux-STORE, Project 56).
Portable C99, freestanding, no malloc, single-threaded, synchronous. Runs on the ControlCore RV32IM firmware processor
and on a host.

```
include/   sfftl.h (API) · sfftl_hal.h (NAND HAL contract) · sfftl_schema.h (on-NAND formats) · sfftl_powersafe.h
src/       ftl_io ftl_map ftl_alloc ftl_gc ftl_wear ftl_bbm ftl_meta ftl_mount ftl_check ftl_util (+ sfftl_internal.h)
hal/sfs/   ControlCore backend for the StorageCore P51 sfs_nand_ctrl registers
hal/sim/   simulated NAND device (NANDLab semantics, fault + power-cut injection, timing) for tests / benchmarks
tests/     reference model, harness, 27 tests
bench/     performance measurements
fw/        ControlCore firmware image: FTL self-test (runs on the P51 SoC RTL, ../../rtl_sim)
```

## Build

```bash
make test
```

```bash
make sanitize
```

```bash
make bench
```

```bash
make -C fw && make -C fw lib
```

Host: any C11 compiler. Target: `riscv64-unknown-elf-gcc` 13.2 (`sudo apt-get install gcc-riscv64-unknown-elf`).

## Using it (ControlCore firmware)

```c
#include "sfftl.h"
#include "sfftl_powersafe.h"
#include "hal_sfs.h"

static uint64_t arena[12288 / 8];           /* sfftl_mem_required() = 8488 B for the P51 device */
static sfftl_t ftl;
static sfs_hal_t hw;
static sfftl_hal_t hal;
static const sfftl_geom_t geom = { 512, 16, 16, 64 };   /* page data, spare, pages/block, blocks */

void storage_init(void) {
  sfftl_cfg_t cfg;
  sfftl_cfg_default(&cfg);                                /* 512-B LBAs, 7 % OP, paced greedy GC, dyn+static WL */
  uint32_t id;
  sfs_hal_init(&hw, 0, SFS_BUF_BASE, &id);                /* channel bring-up: timing, RESET, READ_ID */
  sfs_hal_bind(&hw, &hal);
  if (sfftl_mount(&ftl, &geom, &cfg, &hal, arena, sizeof(arena)) == SFFTL_ENOFS)
    sfftl_format(&ftl, &geom, &cfg, &hal, arena, sizeof(arena));      /* virgin device only */
}

/* command processing */
int on_write(uint64_t lba, uint32_t n, const void *buf) { return sfftl_write(&ftl, lba, n, buf); }   /* durable on return */
int on_read(uint64_t lba, uint32_t n, void *buf)        { return sfftl_read(&ftl, lba, n, buf); }
int on_deallocate(uint64_t lba, uint32_t n)             { return sfftl_trim(&ftl, lba, n); }
int on_flush(void)                                      { return sfftl_flush(&ftl); }
void on_idle(void)                                      { sfftl_background(&ftl, 64); }
void on_shutdown(void)                                  { sfftl_shutdown(&ftl); }
void plp_isr(void)                                      { sfftl_ps_warn(&ftl); }        /* then, in the main loop: */
void on_power_fail(void)                                { sfftl_ps_power_fail(&ftl, SFFTL_PS_FLUSH_JOURNAL); }
```

Return codes: `SFFTL_OK` = acknowledged. `SFFTL_EPOWER` / `ENOSPC` / `EIO` / `EROFS` = not acknowledged (a multi-page
write may have completed some of its pages; each logical page is atomic). `sfftl_strerror()` names them.

## Porting to another NAND controller

Implement the five functions of `sfftl_hal.h`: page read (data and/or 16-byte spare, ECC over both), page program
(data + spare in one operation), block erase, raw marker read, optional write protect. Calls are synchronous.
Addressing is flat (`ppn = pbn · pages_per_block + page`). The simulated device in `hal/sim` checks that the FTL obeys
the NAND rules your device will impose.

Design documents: `../../docs/`. Results: `../../reports/`.
