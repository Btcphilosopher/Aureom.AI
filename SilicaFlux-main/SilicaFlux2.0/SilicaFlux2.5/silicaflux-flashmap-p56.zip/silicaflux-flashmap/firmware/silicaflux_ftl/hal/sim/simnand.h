/* =============================================================================
 * SilicaFlux FlashMap -- simulated NAND device (host only)
 *
 * Behavioural model with the semantics of the SilicaFlux NANDLab device twin
 * (Project 52, MODEL_LIMITATIONS.md): SLC; erase sets every bit to 1; program
 * only clears bits (1 -> 0); pages of a block programmed in ascending order;
 * factory bad blocks marked with 0x00 in spare byte 0 of the first and last
 * page, failing program and erase, markers kept; program / erase failures;
 * erase failures sticky; power loss interrupts the operation in flight.
 *
 * It sits behind the HAL, i.e. it already includes the controller's ECC:
 * a page returns CORRECTED while its bit errors are <= ecc_bits and
 * UNCORRECTABLE beyond.  Rule violations by the FTL (out-of-order program,
 * re-program, 0->1 request, touching a factory-bad block) are counted and the
 * operation fails; the tests require zero violations.
 *
 * All randomness comes from one seeded generator: every run is reproducible.
 * Timing values are the illustrative NANDLab slc_tiny numbers unless
 * configured otherwise; they are not measurements of any device.
 * ===========================================================================*/
#ifndef SIMNAND_H
#define SIMNAND_H

#include <stdint.h>
#include "sfftl_hal.h"

typedef struct {
  uint32_t page_data_bytes, page_spare_bytes, pages_per_block, blocks;
  uint32_t ecc_bits;          /* correctable bit errors per page (codeword over data + FTL spare) */
  uint32_t t_r_ns, t_prog_ns, t_bers_ns, t_byte_ns;   /* array times + bus transfer per byte */
  /* random faults, parts per million per operation (0 = off) */
  uint32_t prog_fail_ppm, erase_fail_ppm, read_unc_ppm, read_flip_ppm;
  uint32_t factory_bad_permille;                     /* applied by simnand_manufacture() */
  uint32_t torn_pass_permille;                       /* torn programs that ECC "corrects" into garbage */
} simnand_cfg_t;

typedef struct {
  uint64_t reads, programs, erases, marker_reads;
  uint64_t prog_fail, erase_fail, read_unc, read_corrected;
  uint64_t violations;              /* NAND rule violations by the FTL: must stay 0 */
  uint64_t v_order, v_reprogram, v_zero_to_one, v_factory_bad, v_wp;
  uint64_t power_cuts, power_lost_ops;
  uint64_t time_ns;                 /* modelled device busy + transfer time */
} simnand_stats_t;

typedef struct simnand simnand_t;

void       simnand_cfg_default(simnand_cfg_t *c, uint32_t page_data, uint32_t ppb, uint32_t blocks);
simnand_t *simnand_create(const simnand_cfg_t *c, uint64_t seed);
void       simnand_destroy(simnand_t *n);
/* factory state: everything erased, random factory-bad blocks (never block 0) */
void       simnand_manufacture(simnand_t *n);
void       simnand_set_factory_bad(simnand_t *n, uint32_t pbn);

/* device operations (the HAL calls these) */
int  simnand_read(simnand_t *n, uint32_t ppn, uint8_t *data, uint8_t *spare, uint32_t *bitflips);
int  simnand_program(simnand_t *n, uint32_t ppn, const uint8_t *data, const uint8_t *spare);
int  simnand_erase(simnand_t *n, uint32_t pbn);
int  simnand_read_marker(simnand_t *n, uint32_t ppn, uint8_t *m);
void simnand_write_protect(simnand_t *n, int on);

/* directed fault injection */
void simnand_fail_next_program(simnand_t *n, uint32_t pbn);      /* next program into this block fails */
void simnand_fail_erase(simnand_t *n, uint32_t pbn);              /* erases of this block fail (sticky) */
void simnand_fail_read(simnand_t *n, uint32_t ppn, uint32_t times);   /* uncorrectable N times (~0u: forever) */
void simnand_flip_bits(simnand_t *n, uint32_t ppn, uint32_t bits);    /* persistent bit errors on a page */
void simnand_miscorrect(simnand_t *n, uint32_t ppn);              /* next read: garbage reported as CORRECTED */
void simnand_misdirect(simnand_t *n, uint32_t ppn, uint32_t other); /* next read of ppn returns page `other` */
void simnand_set_random(simnand_t *n, uint32_t prog_ppm, uint32_t erase_ppm, uint32_t unc_ppm, uint32_t flip_ppm);

/* power: the op with index `after_ops` (counted from now; 0 = the next one)
 * is interrupted, then every operation reports SFFTL_HAL_POWER_LOSS until
 * simnand_power_on() */
void simnand_arm_powercut(simnand_t *n, uint64_t after_ops);
void simnand_disarm_powercut(simnand_t *n);
void simnand_power_off(simnand_t *n);                  /* supply lost now, between operations */
int  simnand_powered(const simnand_t *n);
void simnand_power_on(simnand_t *n);

/* test back door (a real controller cannot do this) */
uint32_t simnand_erase_count(const simnand_t *n, uint32_t pbn);
int      simnand_is_factory_bad(const simnand_t *n, uint32_t pbn);
void     simnand_corrupt_page(simnand_t *n, uint32_t ppn);        /* make a page permanently unreadable */
const simnand_stats_t *simnand_stats(const simnand_t *n);
void     simnand_reset_stats(simnand_t *n);
uint64_t simnand_ops(const simnand_t *n);

/* HAL adapter */
void simnand_hal(simnand_t *n, sfftl_hal_t *hal);

#endif /* SIMNAND_H */
