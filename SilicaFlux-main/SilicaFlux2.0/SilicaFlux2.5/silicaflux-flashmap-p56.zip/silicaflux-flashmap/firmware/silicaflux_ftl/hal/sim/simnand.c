/* =============================================================================
 * SilicaFlux FlashMap -- simulated NAND device (see simnand.h)
 * ===========================================================================*/
#include <stdlib.h>
#include <string.h>
#include "simnand.h"

#define PG_PROG 0x01u   /* programmed (or program started) since the last erase */
#define PG_UNC  0x02u   /* sticky uncorrectable: torn program / partial erase / corrupted */
#define PG_MISC 0x04u   /* next read: ECC miscorrection (garbage reported as corrected) */
#define PG_TPASS 0x08u  /* torn page that ECC decodes "successfully": garbage, CORRECTED, every read */

typedef struct { uint8_t flags; uint8_t rsvd; uint16_t flips; uint32_t unc_reads; } pstate_t;
typedef struct { uint32_t ec; uint8_t factory, erase_fail, prog_fail_next, rsvd; int32_t last_pg; } bstate_t;

struct simnand {
  simnand_cfg_t c;
  uint32_t pbytes, total;
  uint8_t *mem;
  pstate_t *pg;
  bstate_t *bk;
  uint64_t rng, ops;
  int wp, powered, armed;
  uint64_t cut_at;
  uint32_t misdirect_ppn, misdirect_to;
  simnand_stats_t st;
};

/* ---------------------------------------------------------------- deterministic RNG (splitmix64) */
static uint64_t rnd(simnand_t *n) {
  uint64_t z = (n->rng += 0x9E3779B97F4A7C15ull);
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
  return z ^ (z >> 31);
}
static int chance_ppm(simnand_t *n, uint32_t ppm) { return ppm && (rnd(n) % 1000000u) < ppm; }

void simnand_cfg_default(simnand_cfg_t *c, uint32_t page_data, uint32_t ppb, uint32_t blocks) {
  memset(c, 0, sizeof(*c));
  c->page_data_bytes = page_data;
  c->page_spare_bytes = page_data / 32u > SFFTL_OOB_BYTES ? page_data / 32u : SFFTL_OOB_BYTES;
  c->pages_per_block = ppb;
  c->blocks = blocks;
  c->ecc_bits = 8;
  /* NANDLab config/slc_tiny.json (illustrative SLC values) + ~33 MB/s bus (FlashLink P53 mode-5 read phase) */
  c->t_r_ns = 25000;
  c->t_prog_ns = 200000;
  c->t_bers_ns = 2000000;
  c->t_byte_ns = 30;
}

simnand_t *simnand_create(const simnand_cfg_t *c, uint64_t seed) {
  simnand_t *n = (simnand_t *)calloc(1, sizeof(*n));
  if (!n) return NULL;
  n->c = *c;
  n->pbytes = c->page_data_bytes + SFFTL_OOB_BYTES;
  n->total = c->blocks * c->pages_per_block;
  n->mem = (uint8_t *)malloc((size_t)n->total * n->pbytes);
  n->pg = (pstate_t *)calloc(n->total, sizeof(pstate_t));
  n->bk = (bstate_t *)calloc(c->blocks, sizeof(bstate_t));
  if (!n->mem || !n->pg || !n->bk) { simnand_destroy(n); return NULL; }
  n->rng = seed ^ 0x5F1CA0F1A5Bull;
  n->powered = 1;
  n->misdirect_ppn = 0xFFFFFFFFu;
  simnand_manufacture(n);
  return n;
}

void simnand_destroy(simnand_t *n) {
  if (!n) return;
  free(n->mem); free(n->pg); free(n->bk); free(n);
}

static uint8_t *pdata(simnand_t *n, uint32_t ppn) { return n->mem + (size_t)ppn * n->pbytes; }

void simnand_set_factory_bad(simnand_t *n, uint32_t b) {
  if (b == 0 || b >= n->c.blocks) return;               /* block 0 is guaranteed good */
  n->bk[b].factory = 1;
  uint32_t ppb = n->c.pages_per_block, pages[2] = { 0u, ppb - 1u };
  for (int i = 0; i < 2; i++) {
    uint32_t ppn = b * ppb + pages[i];
    pdata(n, ppn)[n->c.page_data_bytes + 0] = 0x00u;    /* manufacturer marker, spare byte 0 */
    n->pg[ppn].flags = PG_PROG;
  }
  n->bk[b].last_pg = (int32_t)ppb - 1;
}

void simnand_manufacture(simnand_t *n) {
  memset(n->mem, 0xFF, (size_t)n->total * n->pbytes);
  memset(n->pg, 0, (size_t)n->total * sizeof(pstate_t));
  for (uint32_t b = 0; b < n->c.blocks; b++) { memset(&n->bk[b], 0, sizeof(bstate_t)); n->bk[b].last_pg = -1; }
  if (n->c.factory_bad_permille)
    for (uint32_t b = 1; b < n->c.blocks; b++)
      if (rnd(n) % 1000u < n->c.factory_bad_permille) simnand_set_factory_bad(n, b);
}

/* ---------------------------------------------------------------- power */
void simnand_arm_powercut(simnand_t *n, uint64_t after) { n->armed = 1; n->cut_at = n->ops + after; }
void simnand_disarm_powercut(simnand_t *n) { n->armed = 0; }
void simnand_power_off(simnand_t *n) { n->powered = 0; n->armed = 0; n->st.power_cuts++; }
int  simnand_powered(const simnand_t *n) { return n->powered; }
void simnand_power_on(simnand_t *n) { n->powered = 1; n->armed = 0; n->wp = 0; }
uint64_t simnand_ops(const simnand_t *n) { return n->ops; }

/* returns 1 when the operation with this index is the one power fails in */
static int op_begin(simnand_t *n, int *dead) {
  uint64_t idx = n->ops++;
  *dead = 0;
  if (!n->powered) { n->st.power_lost_ops++; *dead = 1; return 0; }
  if (n->armed && idx == n->cut_at) {
    n->armed = 0;
    n->powered = 0;
    n->st.power_cuts++;
    return 1;
  }
  return 0;
}

static void garble(simnand_t *n, uint8_t *p, uint32_t len, uint32_t bits) {
  for (uint32_t i = 0; i < bits; i++) {
    uint64_t r = rnd(n);
    p[(r >> 8) % len] ^= (uint8_t)(1u << (r & 7u));
  }
}

/* ---------------------------------------------------------------- operations */
int simnand_read(simnand_t *n, uint32_t ppn, uint8_t *data, uint8_t *spare, uint32_t *bitflips) {
  int dead;
  if (op_begin(n, &dead) || dead) return SFFTL_HAL_POWER_LOSS;     /* a read leaves the medium unchanged */
  if (ppn >= n->total) return SFFTL_HAL_INVALID;
  const uint32_t pd = n->c.page_data_bytes;
  if (ppn == n->misdirect_ppn) { n->misdirect_ppn = 0xFFFFFFFFu; ppn = n->misdirect_to; }   /* wrong address decoded */
  pstate_t *P = &n->pg[ppn];
  uint8_t *src = pdata(n, ppn);
  n->st.reads++;
  n->st.time_ns += n->c.t_r_ns + (uint64_t)n->c.t_byte_ns * ((data ? pd : 0u) + (spare ? SFFTL_OOB_BYTES : 0u));
  if (data) memcpy(data, src, pd);
  if (spare) memcpy(spare, src + pd, SFFTL_OOB_BYTES);
  uint32_t e = P->flips;
  int unc = (P->flags & PG_UNC) != 0;
  if (P->unc_reads) { unc = 1; if (P->unc_reads != ~0u) P->unc_reads--; }
  if (chance_ppm(n, n->c.read_unc_ppm)) unc = 1;
  if (chance_ppm(n, n->c.read_flip_ppm)) e += 1u + (uint32_t)(rnd(n) % (n->c.ecc_bits ? n->c.ecc_bits : 1u));
  if (unc || e > n->c.ecc_bits) {
    if (data) garble(n, data, pd, n->c.ecc_bits + 3u);
    if (spare) garble(n, spare, SFFTL_OOB_BYTES, 3u);
    n->st.read_unc++;
    return SFFTL_HAL_UNCORRECTABLE;
  }
  if (P->flags & PG_TPASS) {                           /* torn page, decoder "succeeds" on garbage */
    if (bitflips) *bitflips = n->c.ecc_bits;
    n->st.read_corrected++;
    return SFFTL_HAL_CORRECTED;
  }
  if (P->flags & PG_MISC) {                            /* decoder converged on a wrong codeword */
    P->flags &= (uint8_t)~PG_MISC;
    if (data) garble(n, data, pd, 5u);
    if (bitflips) *bitflips = n->c.ecc_bits;
    n->st.read_corrected++;
    return SFFTL_HAL_CORRECTED;
  }
  if (bitflips) *bitflips = e;
  if (e) { n->st.read_corrected++; return SFFTL_HAL_CORRECTED; }
  return SFFTL_HAL_OK;
}

int simnand_read_marker(simnand_t *n, uint32_t ppn, uint8_t *m) {
  int dead;
  if (op_begin(n, &dead) || dead) return SFFTL_HAL_POWER_LOSS;
  if (ppn >= n->total) return SFFTL_HAL_INVALID;
  n->st.marker_reads++;
  n->st.time_ns += n->c.t_r_ns + n->c.t_byte_ns;
  *m = pdata(n, ppn)[n->c.page_data_bytes + 0];        /* raw byte, no ECC */
  return SFFTL_HAL_OK;
}

static void violation(simnand_t *n, uint64_t *which) { (*which)++; n->st.violations++; }

int simnand_program(simnand_t *n, uint32_t ppn, const uint8_t *data, const uint8_t *spare) {
  int dead;
  int cut = op_begin(n, &dead);
  if (dead) return SFFTL_HAL_POWER_LOSS;
  if (ppn >= n->total) return SFFTL_HAL_INVALID;
  const uint32_t pd = n->c.page_data_bytes, ppb = n->c.pages_per_block;
  uint32_t b = ppn / ppb, p = ppn % ppb;
  bstate_t *B = &n->bk[b];
  pstate_t *P = &n->pg[ppn];
  uint8_t *dst = pdata(n, ppn);
  if (!cut) {
    n->st.programs++;
    n->st.time_ns += (uint64_t)n->c.t_byte_ns * (pd + SFFTL_OOB_BYTES) + n->c.t_prog_ns;
    if (n->wp) { violation(n, &n->st.v_wp); return SFFTL_HAL_WRITE_PROTECT; }
    if (B->factory) { violation(n, &n->st.v_factory_bad); return SFFTL_HAL_PROGRAM_FAIL; }
    if (P->flags & PG_PROG) { violation(n, &n->st.v_reprogram); return SFFTL_HAL_PROGRAM_FAIL; }
    if ((int32_t)p <= B->last_pg) { violation(n, &n->st.v_order); return SFFTL_HAL_PROGRAM_FAIL; }
  }
  /* 1 -> 0 only: a request to set a programmed 0 back to 1 is a rule violation */
  for (uint32_t i = 0; i < pd; i++)
    if ((uint8_t)(~dst[i] & data[i])) { violation(n, &n->st.v_zero_to_one); return SFFTL_HAL_PROGRAM_FAIL; }
  B->last_pg = (int32_t)p;
  P->flags = PG_PROG;
  P->flips = 0;
  P->unc_reads = 0;
  if (cut) {
    switch (rnd(n) % 4u) {
      case 0: break;                                             /* not started: page still erased */
      case 1:                                                    /* completed, status never seen */
        memcpy(dst, data, pd); memcpy(dst + pd, spare, SFFTL_OOB_BYTES); break;
      case 2:                                                    /* almost done: ECC recovers it */
        memcpy(dst, data, pd); memcpy(dst + pd, spare, SFFTL_OOB_BYTES);
        P->flips = (uint16_t)(1u + rnd(n) % (n->c.ecc_bits ? n->c.ecc_bits : 1u)); break;
      default:                                                   /* torn: some cells programmed */
        for (uint32_t i = 0; i < pd; i++) dst[i] = (uint8_t)(data[i] | (uint8_t)rnd(n));
        if (rnd(n) & 1u) memcpy(dst + pd, spare, SFFTL_OOB_BYTES);      /* late cut: the few spare cells done */
        else for (uint32_t i = 0; i < SFFTL_OOB_BYTES; i++) dst[pd + i] = (uint8_t)(spare[i] | (uint8_t)rnd(n));
        dst[pd] = 0xFFu;
        /* usually ECC fails; optionally it miscorrects and returns the garbage as good data */
        P->flags |= (rnd(n) % 1000u < n->c.torn_pass_permille) ? PG_TPASS : PG_UNC; break;
    }
    return SFFTL_HAL_POWER_LOSS;
  }
  if (B->prog_fail_next || chance_ppm(n, n->c.prog_fail_ppm)) {
    B->prog_fail_next = 0;
    n->st.prog_fail++;
    for (uint32_t i = 0; i < pd; i++) dst[i] = (uint8_t)(data[i] | (uint8_t)rnd(n));
    P->flags |= PG_UNC;
    return SFFTL_HAL_PROGRAM_FAIL;
  }
  memcpy(dst, data, pd);
  memcpy(dst + pd, spare, SFFTL_OOB_BYTES);
  return SFFTL_HAL_OK;
}

static void erase_block(simnand_t *n, uint32_t b) {
  const uint32_t ppb = n->c.pages_per_block;
  memset(pdata(n, b * ppb), 0xFF, (size_t)ppb * n->pbytes);
  memset(&n->pg[b * ppb], 0, (size_t)ppb * sizeof(pstate_t));
  n->bk[b].last_pg = -1;
}

int simnand_erase(simnand_t *n, uint32_t b) {
  int dead;
  int cut = op_begin(n, &dead);
  if (dead) return SFFTL_HAL_POWER_LOSS;
  if (b >= n->c.blocks) return SFFTL_HAL_INVALID;
  bstate_t *B = &n->bk[b];
  const uint32_t ppb = n->c.pages_per_block;
  if (cut) {
    uint32_t mode = (uint32_t)(rnd(n) % 3u);
    if (mode == 1) { erase_block(n, b); B->ec++; }
    else if (mode == 2) {                                  /* partially erased: each page erased, intact or garbage */
      B->ec++;
      for (uint32_t p = 0; p < ppb; p++) {
        uint32_t ppn = b * ppb + p, k = (uint32_t)(rnd(n) % 3u);
        if (k == 0) { memset(pdata(n, ppn), 0xFF, n->pbytes); n->pg[ppn].flags = PG_PROG; }
        else if (k == 2) {
          uint8_t *d = pdata(n, ppn);
          for (uint32_t i = 0; i < n->pbytes; i++) d[i] |= (uint8_t)rnd(n);
          d[n->c.page_data_bytes] = 0xFFu;
          n->pg[ppn].flags |= PG_UNC | PG_PROG;
        }
      }
      B->last_pg = (int32_t)ppb - 1;                       /* not programmable until erased */
    }
    return SFFTL_HAL_POWER_LOSS;
  }
  n->st.erases++;
  n->st.time_ns += n->c.t_bers_ns;
  if (n->wp) { violation(n, &n->st.v_wp); return SFFTL_HAL_WRITE_PROTECT; }
  if (B->factory) { violation(n, &n->st.v_factory_bad); return SFFTL_HAL_ERASE_FAIL; }
  if (B->erase_fail || chance_ppm(n, n->c.erase_fail_ppm)) {
    B->erase_fail = 1;                                     /* NANDLab erase_fail_sticky */
    B->ec++;
    n->st.erase_fail++;
    for (uint32_t p = 0; p < ppb; p++) n->pg[b * ppb + p].flags |= PG_UNC | PG_PROG;
    B->last_pg = (int32_t)ppb - 1;
    return SFFTL_HAL_ERASE_FAIL;
  }
  erase_block(n, b);
  B->ec++;
  return SFFTL_HAL_OK;
}

void simnand_write_protect(simnand_t *n, int on) { n->wp = on; }

/* ---------------------------------------------------------------- fault injection / back door */
void simnand_fail_next_program(simnand_t *n, uint32_t b) { if (b < n->c.blocks) n->bk[b].prog_fail_next = 1; }
void simnand_fail_erase(simnand_t *n, uint32_t b) { if (b < n->c.blocks) n->bk[b].erase_fail = 1; }
void simnand_fail_read(simnand_t *n, uint32_t ppn, uint32_t times) { if (ppn < n->total) n->pg[ppn].unc_reads = times; }
void simnand_flip_bits(simnand_t *n, uint32_t ppn, uint32_t bits) { if (ppn < n->total) n->pg[ppn].flips = (uint16_t)bits; }
void simnand_miscorrect(simnand_t *n, uint32_t ppn) { if (ppn < n->total) n->pg[ppn].flags |= PG_MISC; }
void simnand_corrupt_page(simnand_t *n, uint32_t ppn) { if (ppn < n->total) n->pg[ppn].flags |= PG_UNC; }
void simnand_misdirect(simnand_t *n, uint32_t ppn, uint32_t other) { n->misdirect_ppn = ppn; n->misdirect_to = other; }
void simnand_set_random(simnand_t *n, uint32_t prog, uint32_t erase, uint32_t unc, uint32_t flip) {
  n->c.prog_fail_ppm = prog; n->c.erase_fail_ppm = erase; n->c.read_unc_ppm = unc; n->c.read_flip_ppm = flip;
}
uint32_t simnand_erase_count(const simnand_t *n, uint32_t b) { return b < n->c.blocks ? n->bk[b].ec : 0u; }
int simnand_is_factory_bad(const simnand_t *n, uint32_t b) { return b < n->c.blocks && n->bk[b].factory; }
const simnand_stats_t *simnand_stats(const simnand_t *n) { return &n->st; }
void simnand_reset_stats(simnand_t *n) { memset(&n->st, 0, sizeof(n->st)); }

/* ---------------------------------------------------------------- HAL adapter */
static int h_read(void *c, uint32_t ppn, void *d, void *s, uint32_t *bf) {
  return simnand_read((simnand_t *)c, ppn, (uint8_t *)d, (uint8_t *)s, bf);
}
static int h_prog(void *c, uint32_t ppn, const void *d, const void *s) {
  return simnand_program((simnand_t *)c, ppn, (const uint8_t *)d, (const uint8_t *)s);
}
static int h_erase(void *c, uint32_t pbn) { return simnand_erase((simnand_t *)c, pbn); }
static int h_marker(void *c, uint32_t ppn, uint8_t *m) { return simnand_read_marker((simnand_t *)c, ppn, m); }
static void h_wp(void *c, int on) { simnand_write_protect((simnand_t *)c, on); }

void simnand_hal(simnand_t *n, sfftl_hal_t *h) {
  h->ctx = n;
  h->read = h_read;
  h->program = h_prog;
  h->erase = h_erase;
  h->read_marker = h_marker;
  h->write_protect = h_wp;
}
