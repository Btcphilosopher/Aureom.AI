// =============================================================================
// MemoryPool :: sfmp_cxl_boundary_stub -- the FUTURE adapter boundary for CXL-capable memory (tier 2)
//
//   *** THIS IS NOT CXL. ***  It contains no CXL.io / CXL.mem / CXL.cache logic, no link layer, no PHY, no
//   discovery, no coherence.  It is a lint-checked statement of the port list that a future CXL adapter must
//   present to the pool (docs/CXL_ADAPTER_SPEC.md), implemented as "device not present": `x_present = 0`, and any
//   request that is nevertheless presented completes with an error response.
//
// A genuine CXL implementation needs compatible controller / PHY IP, protocol compliance testing and platform
// interoperability testing -- none of which exist in this repository.  A normal DDR controller, a DMA link or
// this stub must never be labelled CXL.
//
// Port groups (all from the POOL's point of view of the tier-2 adapter):
//   request / response   SFB2-style tier port (same as tier 1) addressed by DEVICE physical address, response adds `poison`
//   discovery            presence, capacity, latency/bandwidth class, coherence mode of the memory region
//   hotness              a stream of hot-granule records (CHMU-like or adapter-local monitor) offered to the policy
//   errors               media / poison / viral / link-down events
//   security             link-integrity (IDE-like) state and a "protected placement allowed" bit
//   quiesce              handshake before hot-remove, reset or link retrain
// Classification: SIMULATION/LINT ONLY (non-functional placeholder)
// =============================================================================
`default_nettype none

module sfmp_cxl_boundary_stub #(
  parameter int DW = 32,
  parameter int AW = 32
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // ---- request / response (pool = master)
  input  wire logic                x_req_valid,
  output logic                     x_req_ready,
  input  wire logic                x_req_write,
  input  wire logic [AW-1:0]       x_req_dpa,        // device physical address (after the adapter's HDM decode)
  input  wire logic [DW-1:0]       x_req_wdata,
  input  wire logic [DW/8-1:0]     x_req_wstrb,
  output logic                     x_rsp_valid,
  input  wire logic                x_rsp_ready,
  output logic      [DW-1:0]       x_rsp_rdata,
  output logic                     x_rsp_err,
  output logic                     x_rsp_poison,     // data is poisoned (uncorrectable media error); never consumed silently
  // ---- discovery (adapter -> pool)
  output logic                     x_present,        // a device is present and decoded; 0 => the pool must not allocate in tier 2
  output logic      [31:0]         x_capacity_gran,  // usable granules
  output logic      [7:0]          x_lat_class,      // latency class (from the device's CDAT-equivalent), lower = faster
  output logic      [7:0]          x_bw_class,
  output logic      [1:0]          x_coherence,      // 0 none (pool treats the range as non-cacheable device memory); other values reserved
  // ---- hotness stream (adapter -> policy)
  output logic                     x_hot_valid,
  input  wire logic                x_hot_ready,
  output logic      [31:0]         x_hot_gran,       // device-granule index
  output logic      [15:0]         x_hot_count,
  // ---- error events
  output logic                     x_err_valid,
  output logic      [3:0]          x_err_type,       // 1 poison, 2 viral, 3 media, 4 link down
  output logic      [31:0]         x_err_dpa,
  // ---- security
  output logic                     x_sec_link_protected,   // link integrity / encryption established
  output logic                     x_sec_placement_ok,     // policy may place confidential domains here
  // ---- quiesce
  input  wire logic                x_quiesce_req,
  output logic                     x_quiesce_ack
);
  logic pend_q;
  assign x_present            = 1'b0;
  assign x_capacity_gran      = 32'd0;
  assign x_lat_class          = 8'hFF;
  assign x_bw_class           = 8'h00;
  assign x_coherence          = 2'd0;
  assign x_hot_valid          = 1'b0;
  assign x_hot_gran           = 32'd0;
  assign x_hot_count          = 16'd0;
  assign x_err_valid          = 1'b0;
  assign x_err_type           = 4'd0;
  assign x_err_dpa            = 32'd0;
  assign x_sec_link_protected = 1'b0;
  assign x_sec_placement_ok   = 1'b0;
  assign x_quiesce_ack        = x_quiesce_req;          // nothing to quiesce

  // any request that is presented anyway completes with an error (never with data)
  assign x_req_ready  = !pend_q;
  assign x_rsp_valid  = pend_q;
  assign x_rsp_rdata  = '0;
  assign x_rsp_err    = 1'b1;
  assign x_rsp_poison = 1'b0;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)                          pend_q <= 1'b0;
    else if (x_req_valid && x_req_ready) pend_q <= 1'b1;
    else if (x_rsp_ready)                pend_q <= 1'b0;
  end
  wire unused_ok = &{1'b0, x_req_write, x_req_dpa, x_req_wdata, x_req_wstrb, x_hot_ready};
endmodule

`default_nettype wire
