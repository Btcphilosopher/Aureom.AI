// =============================================================================
// SilicaFlux MemoryPool (Project 65) :: sfmp_pkg -- shared constants
//
// SINGLE SOURCE OF TRUTH for every code, state encoding, command, register offset and counter
// index that crosses a module, testbench or tool boundary.
//
//   * Synthesizable RTL uses ONLY the localparams of this package, fully qualified
//     (sfmp_pkg::NAME), on flat bit vectors -- the repository's RTL coding rules (no structs
//     on ports, no module-header `import`, no `return`): the baseline flow is Yosys.
//   * tools/gen_regmap.py cross-checks the register offsets below against docs/REGISTER_MAP.md.
//
// Terminology
//   PVA      pool virtual address: the byte address a client uses inside the managed window.
//   granule  translation granularity (2**GRAN_LG bytes, default 256 B).  Regions, extents,
//            domain windows and tier allocation are all granule aligned.
//   tier 0   on-chip SRAM            tier 1   external DRAM (a modelled interface in simulation)
//   domain   tenant / security domain.  Client port i is hard-bound to one domain by a
//            privileged BIND; the domain of an access is never taken from the request.
// Classification: SYNTHESIZABLE (constants only)
// =============================================================================
package sfmp_pkg;

  // ---------------------------------------------------------------- identification
  localparam logic [31:0] ID_MAGIC = 32'h5346_4D50;   // "SFMP"
  localparam logic [31:0] RTL_VER  = 32'h0001_0000;   // Project 65 RTL 1.0

  // ---------------------------------------------------------------- limits
  localparam int MAX_DOMAINS = 8;
  localparam int MAX_REGIONS = 32;

  // ---------------------------------------------------------------- tiers
  localparam logic TIER_SRAM = 1'b0;
  localparam logic TIER_DRAM = 1'b1;

  // allocation tier preference (ALLOC argument)
  localparam logic [1:0] PREF_SRAM = 2'd0;   // SRAM only
  localparam logic [1:0] PREF_DRAM = 2'd1;   // DRAM only
  localparam logic [1:0] PREF_AUTO = 2'd2;   // SRAM if it fits (and the domain quota allows), else DRAM

  // ---------------------------------------------------------------- region allocation state
  localparam logic [1:0] RS_FREE    = 2'd0;
  localparam logic [1:0] RS_SCRUB   = 2'd1;  // reserved, being zeroed: not accessible
  localparam logic [1:0] RS_ACTIVE  = 2'd2;
  localparam logic [1:0] RS_FREEING = 2'd3;  // no new access; waiting for in-flight accesses to drain

  // ---------------------------------------------------------------- region migration state
  localparam logic [1:0] MG_NONE    = 2'd0;
  localparam logic [1:0] MG_PRECOPY = 2'd1;  // reads+writes served from the source; writes tracked (dirty)
  localparam logic [1:0] MG_FROZEN  = 2'd2;  // quiesced: no access to the region is dispatched

  // ---------------------------------------------------------------- access fault causes
  // INTERNAL / management-visible only.  The client sees CE_FAULT for every access fault so a
  // tenant cannot tell "unmapped" from "someone else's region" (no allocation-map side channel).
  localparam logic [3:0] FC_NONE     = 4'd0;
  localparam logic [3:0] FC_UNMAPPED = 4'd1;  // no region covers the address
  localparam logic [3:0] FC_XTENANT  = 4'd2;  // region owned by another domain
  localparam logic [3:0] FC_PERM     = 4'd3;  // region permission (read / write) denies the access
  localparam logic [3:0] FC_STATE    = 4'd4;  // region scrubbing / being freed
  localparam logic [3:0] FC_QUAR     = 4'd5;  // domain quarantined
  localparam logic [3:0] FC_IOMMU    = 4'd6;  // host-DMA request without a valid IOMMU translation
  localparam logic [3:0] FC_ALIGN    = 4'd7;  // address not beat aligned / above the managed window
  localparam logic [3:0] FC_DOMAIN   = 4'd8;  // domain not enabled / port not bound
  localparam logic [3:0] FC_MEDIA    = 4'd9;  // the tier answered with an error (not an isolation fault)

  // client-visible response codes
  localparam logic [7:0] CE_NONE  = 8'h00;
  localparam logic [7:0] CE_FAULT = 8'h01;    // access fault (uniform for every FC_* except media)
  localparam logic [7:0] CE_MEDIA = 8'h02;    // media / tier error

  // region error status (per-region sticky code, management visible)
  localparam logic [7:0] RE_NONE      = 8'h00;
  localparam logic [7:0] RE_MEDIA     = 8'h01;   // a tenant access to the region got a tier error
  localparam logic [7:0] RE_MIG_DMA   = 8'h02;   // migration aborted: DMA / tier error
  localparam logic [7:0] RE_MIG_VER   = 8'h03;   // migration aborted: destination verification failed
  localparam logic [7:0] RE_MIG_GUARD = 8'h04;   // migration aborted: DMA guard refused a beat

  // ---------------------------------------------------------------- privileged commands
  localparam logic [7:0] CMD_NOP       = 8'h00;
  localparam logic [7:0] CMD_DOM_SET   = 8'h01;  // arg0=dom  arg1=win_base(byte)  arg2=win_limit(byte, exclusive)
                                                 // arg3=[15:0] SRAM quota (granules)  [16] enable  [17] auto-quarantine
  localparam logic [7:0] CMD_BIND      = 8'h02;  // arg0=client port  arg1=dom
  localparam logic [7:0] CMD_ALLOC     = 8'h03;  // arg0=dom arg1=pva(byte) arg2=len(byte) arg3=[1:0] pref [2] R [3] W [4] pin
  localparam logic [7:0] CMD_FREE      = 8'h04;  // arg0=idx  arg1=gen
  localparam logic [7:0] CMD_SET_PERM  = 8'h05;  // arg0=idx  arg1=gen  arg2=[0] R [1] W
  localparam logic [7:0] CMD_PIN       = 8'h06;  // arg0=idx  arg1=gen  arg2=[0] pin
  localparam logic [7:0] CMD_MIGRATE   = 8'h07;  // arg0=idx  arg1=gen  arg2=[0] destination tier
  localparam logic [7:0] CMD_CLR_ERR   = 8'h08;  // arg0=idx  arg1=gen
  localparam logic [7:0] CMD_CLR_QUAR  = 8'h09;  // arg0=dom

  // command result codes (CMD_STATUS.RC)
  localparam logic [7:0] RC_OK           = 8'h00;
  localparam logic [7:0] RC_BAD_CMD      = 8'h01;
  localparam logic [7:0] RC_BAD_ARG      = 8'h02;  // out-of-range index/domain/port, zero length, mis-aligned
  localparam logic [7:0] RC_NO_SLOT      = 8'h03;  // region table full
  localparam logic [7:0] RC_NO_SPACE     = 8'h04;  // no contiguous extent in the requested tier(s)
  localparam logic [7:0] RC_OVERLAP      = 8'h05;  // PVA range overlaps an existing region
  localparam logic [7:0] RC_OUTSIDE_WIN  = 8'h06;  // PVA range not inside the domain's managed window
  localparam logic [7:0] RC_BAD_DOMAIN   = 8'h07;  // domain not enabled
  localparam logic [7:0] RC_STALE        = 8'h08;  // handle (idx,gen) does not name a live region
  localparam logic [7:0] RC_BUSY         = 8'h09;  // region migrating, engine busy, port not idle, domain has live regions
  localparam logic [7:0] RC_NOT_ACTIVE   = 8'h0A;  // region not ACTIVE
  localparam logic [7:0] RC_PINNED       = 8'h0B;
  localparam logic [7:0] RC_SAME_TIER    = 8'h0C;
  localparam logic [7:0] RC_TOO_LARGE    = 8'h0D;  // longer than MAX_REGION_GRAN
  localparam logic [7:0] RC_QUOTA        = 8'h0E;  // domain SRAM quota exceeded
  localparam logic [7:0] RC_MEDIA        = 8'h0F;  // scrub of the new extent failed
  localparam logic [7:0] RC_WIN_OVERLAP  = 8'h10;  // domain window overlaps another enabled domain's window
  localparam logic [7:0] RC_NOT_PRIV     = 8'h11;  // not issued from the privileged plane (reported by the register block)
  localparam logic [7:0] RC_CMD_DROPPED  = 8'h12;  // a command was written while another was pending

  // migration result codes (MIG_STATUS.RESULT)
  localparam logic [7:0] MR_NONE   = 8'h00;
  localparam logic [7:0] MR_OK     = 8'h01;
  localparam logic [7:0] MR_DMA    = 8'h02;  // DMA / tier error while copying
  localparam logic [7:0] MR_VERIFY = 8'h03;  // verification failed after the retry budget
  localparam logic [7:0] MR_GUARD  = 8'h04;  // per-beat DMA guard refused a beat

  // ---------------------------------------------------------------- RAS event types
  // numerically identical to SFRAS_EV_* in the RAS project (silicaflux-ras-project26 rtl/sfras_defs.svh)
  localparam logic [3:0] EV_MEM_UE     = 4'd2;
  localparam logic [3:0] EV_DMA_ERR    = 4'd4;
  localparam logic [3:0] EV_ILLEGAL_OP = 4'd8;
  localparam logic [3:0] EV_TIMEOUT    = 4'd11;


  // ---------------------------------------------------------------- region-table entry layout (read ports)
  // A region entry is exported as one flat vector so every consumer (command engine, register block,
  // policy) slices the same bits.  Field widths are fixed upper bounds; unused upper bits read 0.
  localparam int W_STATE = 2,  E_STATE = 0;
  localparam int W_TIER  = 1,  E_TIER  = 2;
  localparam int W_MIG   = 2,  E_MIG   = 3;
  localparam int W_DIRTY = 1,  E_DIRTY = 5;
  localparam int W_PIN   = 1,  E_PIN   = 6;
  localparam int W_PR    = 1,  E_PR    = 7;
  localparam int W_PW_   = 1,  E_PW    = 8;
  localparam int W_DOM   = 4,  E_DOM   = 9;
  localparam int W_ERR   = 8,  E_ERR   = 13;
  localparam int W_GEN   = 8,  E_GEN   = 21;
  localparam int W_PVA   = 26, E_PVA   = 29;     // PVA granule base       (POOL_AW - GRAN_LG <= 26)
  localparam int W_LEN   = 8,  E_LEN   = 55;     // length in granules     (MAX_REGION_GRAN <= 255)
  localparam int W_PHYS  = 16, E_PHYS  = 63;     // physical granule base inside the tier
  localparam int W_EP    = 16, E_RDEP  = 79;     // reads  in the current policy epoch (saturating)
  localparam int            E_WREP  = 95;        // writes in the current policy epoch (saturating)
  localparam int W_TOT   = 32, E_RDTOT = 111;    // lifetime reads  (saturating)
  localparam int            E_WRTOT = 143;       // lifetime writes (saturating)
  localparam int ENTRY_W = 175;

  // command-engine -> region-table operations (ct_op)
  localparam logic [3:0] CT_NONE     = 4'd0;
  localparam logic [3:0] CT_ALLOC    = 4'd1;   // reserve a free slot: SCRUB state, new generation
  localparam logic [3:0] CT_ACTIVATE = 4'd2;   // SCRUB -> ACTIVE
  localparam logic [3:0] CT_FREEING  = 4'd3;   // ACTIVE -> FREEING
  localparam logic [3:0] CT_RELEASE  = 4'd4;   // any -> FREE (frees the slot; used by FREE and by alloc rollback)
  localparam logic [3:0] CT_PERM     = 4'd5;
  localparam logic [3:0] CT_PIN      = 4'd6;
  localparam logic [3:0] CT_CLRERR   = 4'd7;
  localparam logic [3:0] CT_MIGBEGIN = 4'd8;   // mig := PRECOPY (or FROZEN); accounts the destination reservation

  // migration-engine -> region-table operations (mg_op)
  localparam logic [1:0] MGO_NONE   = 2'd0;
  localparam logic [1:0] MGO_FREEZE = 2'd1;
  localparam logic [1:0] MGO_COMMIT = 2'd2;    // atomic mapping update: tier := other tier, phys := new base
  localparam logic [1:0] MGO_ABORT  = 2'd3;

  // ---------------------------------------------------------------- global event counters (64-bit, LO/HI latch)
  localparam int G_ACC         = 0;    // accesses dispatched to a tier (accepted by the tier path)
  localparam int G_ACC_RD      = 1;
  localparam int G_ACC_WR      = 2;
  localparam int G_ACC_T0      = 3;    // ... served by tier 0 (SRAM)
  localparam int G_ACC_T1      = 4;    // ... served by tier 1 (DRAM)
  localparam int G_BYTES_RD    = 5;    // payload bytes of completed reads  (write strobes counted for writes)
  localparam int G_BYTES_WR    = 6;
  localparam int G_BYTES_T0    = 7;
  localparam int G_BYTES_T1    = 8;
  localparam int G_LAT_SUM     = 9;    // sum of service latencies (cycles, enqueue -> response ready)
  localparam int G_LAT_CNT     = 10;   // number of responses in LAT_SUM
  localparam int G_REJECT      = 11;   // accesses answered with an error (any cause)
  localparam int G_VIOL        = 12;   // isolation violations (XTENANT, PERM, QUAR, IOMMU)
  localparam int G_QFULL       = 13;   // cycles a client request was refused by a full request queue
  localparam int G_HEADBLK     = 14;   // cycles a queue head was waiting (arbitration, tier busy, freeze)
  localparam int G_FRZBLK      = 15;   // cycles the selected queue head was held by a migration freeze
  localparam int G_MIG_OK      = 16;   // committed migrations
  localparam int G_MIG_ABORT   = 17;
  localparam int G_MIG_BYTES   = 18;   // migration DMA bytes acknowledged (includes dirty re-copies)
  localparam int G_MIG_VBYTES  = 19;   // verification read bytes
  localparam int G_MIG_RECOPY  = 20;   // chunks copied again because a write dirtied them
  localparam int G_MIG_FRZ_CYC = 21;   // cycles a region was frozen
  localparam int G_MIG_ACT_CYC = 22;   // cycles the migration engine was busy
  localparam int G_MIG_RETRY   = 23;   // chunk copies repeated after a verify mismatch
  localparam int G_SCRUB_BYTES = 24;
  localparam int G_ALLOC_OK    = 25;
  localparam int G_ALLOC_FAIL  = 26;
  localparam int G_FREE_OK     = 27;
  localparam int G_MEDIA_ERR   = 28;
  localparam int G_CYCLES      = 29;
  localparam int G_PRESS_CYC   = 30;   // cycles SRAM occupancy was above the high watermark
  localparam int G_EM_STALL    = 31;   // cycles a DRAM-tier request waited for the external port / tag queue
  localparam int G_F_UNMAPPED  = 32;
  localparam int G_F_XTENANT   = 33;
  localparam int G_F_PERM      = 34;
  localparam int G_F_STATE     = 35;
  localparam int G_F_QUAR      = 36;
  localparam int G_F_IOMMU     = 37;
  localparam int G_F_ALIGN     = 38;
  localparam int G_F_DOMAIN    = 39;
  localparam int G_PRIV_VIOL   = 40;   // register writes refused for lack of privilege
  localparam int G_CMD_ERR     = 41;   // management commands that returned RC != OK
  localparam int G_POL_REQ     = 42;   // migrations requested by the baseline policy
  localparam int G_POL_FAIL    = 43;   // ... of which the command engine refused
  localparam int G_LAT_SUM_T0  = 44;   // service latency of accesses completed by tier 0 (sum, count): input of the
  localparam int G_LAT_CNT_T0  = 45;   //   policy's auto-calibrated benefit estimate
  localparam int G_LAT_SUM_T1  = 46;
  localparam int G_LAT_CNT_T1  = 47;
  localparam int NG            = 48;

  // ---------------------------------------------------------------- per-domain counters
  localparam int D_ACC       = 0;
  localparam int D_ACC_T0    = 1;      // hit ratio of the SRAM tier = D_ACC_T0 / D_ACC
  localparam int D_ACC_T1    = 2;
  localparam int D_BYTES     = 3;
  localparam int D_LAT_SUM   = 4;
  localparam int D_LAT_CNT   = 5;
  localparam int D_VIOL      = 6;
  localparam int D_REJECT    = 7;
  localparam int D_QSTALL    = 8;      // queue-full + head-blocked cycles of this domain's ports
  localparam int D_MIG_BYTES = 9;      // migration bytes of regions this domain owns
  localparam int NDC         = 10;

  // ---------------------------------------------------------------- register offsets (rb_addr, byte offsets in a 4 KiB page)
  localparam logic [11:0] R_ID          = 12'h000;  // RO  "SFMP"
  localparam logic [11:0] R_VERSION     = 12'h004;  // RO
  localparam logic [11:0] R_CAP0        = 12'h008;  // RO  [3:0] domains [11:4] regions [15:12] GRAN_LG [23:16] DW/8 [31:24] CHUNK_LG
  localparam logic [11:0] R_CAP1        = 12'h00C;  // RO  [15:0] SRAM granules  [31:16] MAX_REGION_GRAN
  localparam logic [11:0] R_CAP2        = 12'h010;  // RO  DRAM granules
  localparam logic [11:0] R_CAP3        = 12'h014;  // RO  [7:0] migration channels [15:8] POOL_AW
  localparam logic [11:0] R_CTRL        = 12'h020;  // RW  [0] POLICY_EN [1] PRECOPY_EN [2] VERIFY_EN [3] AUTOCOST [4] AUTODELTA
  localparam logic [11:0] R_CMD_ARG0    = 12'h040;
  localparam logic [11:0] R_CMD_ARG1    = 12'h044;
  localparam logic [11:0] R_CMD_ARG2    = 12'h048;
  localparam logic [11:0] R_CMD_ARG3    = 12'h04C;
  localparam logic [11:0] R_CMD         = 12'h050;  // WO  launch
  localparam logic [11:0] R_CMD_STATUS  = 12'h054;  // RO  [0] busy [1] done [15:8] rc [20:16] idx [31:24] gen
  localparam logic [11:0] R_CMD_RES0    = 12'h058;  // RO  ALLOC: [0] tier [31:8] phys byte address >> 8 ... see docs
  localparam logic [11:0] R_CMD_RES1    = 12'h05C;  // RO  ALLOC: PVA granule base
  localparam logic [11:0] R_MIG_STATUS  = 12'h060;  // RO  [0] busy [1] done [2] ok [15:8] result [20:16] idx
  localparam logic [11:0] R_MIG_CYCLES  = 12'h064;  // RO  duration of the last migration (cycles)
  localparam logic [11:0] R_MIG_BYTES   = 12'h068;  // RO  bytes of the last migration (copied, incl. re-copies)
  localparam logic [11:0] R_MIG_CTL     = 12'h06C;  // RW  [7:0] MAX_ROUNDS [15:8] FREEZE_THRESH(chunks) [23:16] MAX_RETRY
  localparam logic [11:0] R_FAULT_INFO  = 12'h070;  // RO  last access fault: [3:0] cause [7:4] port [11:8] domain [12] write
  localparam logic [11:0] R_FAULT_ADDR  = 12'h074;  // RO  last access fault PVA
  localparam logic [11:0] R_STICKY      = 12'h078;  // RW1C [0] CMD_DROPPED [1] TIMEOUT [2] INV_ERR [3] TIER_OOR
  localparam logic [11:0] R_OCC         = 12'h07C;  // RO  [15:0] SRAM granules used [31:16] DRAM granules used (low 16 bits)
  localparam logic [11:0] R_RSEL        = 12'h080;  // RW  region index selected for the read-out window
  localparam logic [11:0] R_RD_W0       = 12'h084;  // RO  [1:0] state [2] tier [4:3] mig [5] dirty [6] pin [7] perm_r [8] perm_w [15:12] dom [23:16] err [31:24] gen
  localparam logic [11:0] R_RD_PVA      = 12'h088;  // RO  PVA granule base
  localparam logic [11:0] R_RD_LEN      = 12'h08C;  // RO  length (granules)
  localparam logic [11:0] R_RD_PHYS     = 12'h090;  // RO  physical granule base inside the tier
  localparam logic [11:0] R_RD_RDTOT    = 12'h094;  // RO
  localparam logic [11:0] R_RD_WRTOT    = 12'h098;  // RO
  localparam logic [11:0] R_RD_SCORE    = 12'h09C;  // RO  policy hotness score (Q4 accesses per epoch)
  localparam logic [11:0] R_DSEL        = 12'h0A0;  // RW  domain selected for the per-domain read-out
  localparam logic [11:0] R_DOM_STAT    = 12'h0A4;  // RO  [0] enabled [1] quarantined [2] auto-quarantine [3] bound-port-count
  localparam logic [11:0] R_DOM_WBASE   = 12'h0A8;  // RO
  localparam logic [11:0] R_DOM_WLIM    = 12'h0AC;  // RO
  localparam logic [11:0] R_DOM_QUOTA   = 12'h0B0;  // RO  SRAM quota (granules)
  localparam logic [11:0] R_DOM_USE     = 12'h0B4;  // RO  SRAM granules reserved by the domain
  localparam logic [11:0] R_DOM_LIVE    = 12'h0B8;  // RO  live regions of the domain
  localparam logic [11:0] R_DOM_LATMAX  = 12'h0BC;  // RO  max service latency of the domain
  localparam logic [11:0] R_GLAT_MAX    = 12'h0C0;  // RO  global max service latency
  localparam logic [11:0] R_SRAM_PEAK   = 12'h0C4;  // RO  peak SRAM granules used
  localparam logic [11:0] R_DRAM_PEAK   = 12'h0C8;  // RO
  localparam logic [11:0] R_BIND0       = 12'h0D0;  // RO  4 bits per client port, port 0 in [3:0]  (reads of the BIND state)
  localparam logic [11:0] R_TLM_CTRL    = 12'h0E0;  // RW  [0] FREEZE [1] CLEAR (self-clearing)
  localparam logic [11:0] R_POL_CTRL0   = 12'h100;  // RW  EPOCH_CYCLES
  localparam logic [11:0] R_POL_CTRL1   = 12'h104;  // RW  [7:0] HOT_MIN [15:8] DECAY_SHIFT [23:16] COOLDOWN_EPOCHS [31:24] HORIZON_EPOCHS
  localparam logic [11:0] R_POL_COST    = 12'h108;  // RW  [15:0] COST_PER_GRAN (cycles) [31:16] COST_PER_CHUNK (cycles)
  localparam logic [11:0] R_POL_DELTA   = 12'h10C;  // RW  cycles saved per access when served by SRAM instead of DRAM
  localparam logic [11:0] R_POL_MARGIN  = 12'h110;  // RW  [7:0] MARGIN_SHIFT [15:8] HYST_GAP (hotness points) [31:16] HIGH_WATERMARK (granules)
  localparam logic [11:0] R_POL_STATUS  = 12'h114;  // RO  [0] scanning [15:8] epochs counted (low 8 bits)
  localparam logic [11:0] R_POL_COSTEST = 12'h118;  // RO  current (auto-calibrated) cost per granule
  localparam logic [11:0] R_POL_SRAMLAT = 12'h120;  // RW  [7:0] SRAM reference latency (cycles): stands in for the tier-0 mean while tier 0 has too few samples (AUTODELTA)
  localparam logic [11:0] R_POL_DELTAEST = 12'h11C; // RO  current benefit estimate: mean(tier-1 latency) - mean(tier-0 latency), cycles
  localparam logic [11:0] R_G_BASE      = 12'h200;  // RO  global counter k: LO at +8k, HI at +8k+4   (NG counters)
  localparam logic [11:0] R_D_BASE      = 12'h400;  // RO  per-domain counter k of the selected domain: LO at +8k, HI at +8k+4

  // register-field helpers
  localparam int CTRL_POLICY_EN = 0;
  localparam int CTRL_PRECOPY   = 1;
  localparam int CTRL_VERIFY    = 2;
  localparam int CTRL_AUTOCOST  = 3;   // measure the migration cost from completed migrations
  localparam int CTRL_AUTODELTA = 4;   // measure the per-access benefit from the per-tier latency counters

endpackage
