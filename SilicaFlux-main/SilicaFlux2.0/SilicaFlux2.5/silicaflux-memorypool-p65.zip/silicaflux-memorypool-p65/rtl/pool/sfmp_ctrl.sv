// =============================================================================
// MemoryPool :: sfmp_ctrl -- privileged command engine, domain configuration and allocation sequencing
//
// The ONLY writer of region ownership, permissions, pinning and the allocator.  Commands arrive from the
// register block (which already refused anything not issued from the privileged plane) or, for
// MIGRATE, from the tiering policy.  One command at a time; a management command has priority over a
// policy request.
//
//   ALLOC   validate (domain enabled, window, alignment, size, free slot, PVA overlap, quota)
//           -> FIND an extent (first fit; AUTO tries SRAM within the domain quota, then DRAM)
//           -> MARK it -> region := SCRUB (not accessible) -> ZERO-FILL the extent -> region := ACTIVE
//   FREE    validate handle (index + generation) -> region := FREEING (no new accesses) -> wait until no
//           access is in flight -> release the extent -> region := FREE
//   MIGRATE validate (ACTIVE, not pinned, not migrating, other tier, quota) -> reserve the destination
//           extent -> mark the region PRECOPY / FROZEN -> start the migration engine
//   DOM_SET / BIND / CLR_QUAR / SET_PERM / PIN / CLR_ERR   single-cycle updates after validation
//
// A region handle is (index, generation); the generation changes on every ALLOC, so a stale handle held by
// the management plane can never free, re-permission or migrate somebody else's later allocation.
// Domain windows of enabled domains never overlap; a domain's window and quota cannot change while it
// owns live regions.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfmp_ctrl #(
  parameter int ND       = 4,
  parameter int NR       = 32,
  parameter int GRAN_LG  = 8,
  parameter int POOL_AW  = 28,
  parameter int GA       = 20,
  parameter int LW       = 7,
  parameter int PW       = 10,
  parameter int MAXLEN   = 64
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // management command (a pending command held by the register block)
  input  wire logic                cmd_pend,
  input  wire logic [7:0]          cmd,
  input  wire logic [31:0]         a0,
  input  wire logic [31:0]         a1,
  input  wire logic [31:0]         a2,
  input  wire logic [31:0]         a3,
  output logic                     cmd_take,        // pulse: the pending command was taken
  output logic                     cmd_done,        // pulse
  output logic [7:0]               cmd_rc,
  output logic [4:0]               cmd_idx,
  output logic [7:0]               cmd_gen,
  output logic [31:0]              cmd_res0,
  output logic [31:0]              cmd_res1,
  output logic                     busy,
  // policy request
  input  wire logic                pol_valid,
  input  wire logic [$clog2(NR)-1:0] pol_idx,
  input  wire logic                pol_dst,
  output logic                     pol_ready,
  output logic                     pol_done,
  output logic [7:0]               pol_rc,
  // run-time config
  input  wire logic                precopy_en,
  // domain state
  output logic [ND-1:0]            dom_en,
  output logic [ND-1:0]            dom_quar,
  output logic [ND-1:0]            dom_autoq,
  output logic [ND*4-1:0]          bind_dom,
  output logic [ND*(GA+1)-1:0]     dom_wbase,
  output logic [ND*(GA+1)-1:0]     dom_wlim,
  output logic [ND*16-1:0]         dom_quota,
  input  wire logic [ND-1:0]       quar_set,
  input  wire logic [ND:0]         port_idle,       // accelerator ports 0..ND-1 (+ host port)
  // region table
  output logic [3:0]               ct_op,
  output logic [$clog2(NR)-1:0]    ct_idx,
  output logic [3:0]               ct_dom,
  output logic [GA-1:0]            ct_pva,
  output logic [LW-1:0]            ct_len,
  output logic                     ct_tier,
  output logic [PW-1:0]            ct_phys,
  output logic                     ct_perm_r,
  output logic                     ct_perm_w,
  output logic                     ct_pin,
  output logic                     ct_frozen,
  output logic [GA-1:0]            ov_base,
  output logic [LW-1:0]            ov_len,
  input  wire logic                ov_any,
  input  wire logic                fr_vld,
  input  wire logic [$clog2(NR)-1:0] fr_idx,
  output logic [$clog2(NR)-1:0]    rd_idx,
  input  wire logic [sfmp_pkg::ENTRY_W-1:0] rd_ent,
  input  wire logic [ND*16-1:0]    use_sram,
  input  wire logic [ND*8-1:0]     live_cnt,
  input  wire logic [NR-1:0]       infl_nz,
  // allocator
  output logic                     al_valid,
  input  wire logic                al_ready,
  output logic [1:0]               al_op,
  output logic                     al_tier,
  output logic [PW-1:0]            al_base,
  output logic [LW-1:0]            al_len,
  input  wire logic                al_done,
  input  wire logic                al_found,
  input  wire logic [PW-1:0]       al_found_base,
  // scrubber
  output logic                     sc_start,
  output logic                     sc_tier,
  output logic [31:0]              sc_base,
  output logic [31:0]              sc_len,
  input  wire logic                sc_idle,
  input  wire logic                sc_done,
  input  wire logic                sc_err,
  // migration engine
  output logic                     me_start,
  output logic [$clog2(NR)-1:0]    me_idx,
  output logic                     me_dir,
  output logic [3:0]               me_dom,
  output logic [31:0]              me_dram_base,
  output logic [31:0]              me_sram_base,
  output logic [PW-1:0]            me_src_gran,
  output logic [PW-1:0]            me_dst_gran,
  output logic [LW-1:0]            me_len,
  output logic                     me_precopy,
  input  wire logic                me_busy,
  // events
  output logic                     ev_alloc_ok,
  output logic                     ev_alloc_fail,
  output logic                     ev_free_ok,
  output logic                     ev_cmd_err
);
  localparam int IW = $clog2(NR);
  localparam int GL = GA + 1;
  localparam int DIW = (ND > 1) ? $clog2(ND) : 1;

  localparam logic [5:0] S_IDLE = 6'd0,  S_DEC = 6'd1,
                         S_A_F0 = 6'd2,  S_A_F0W = 6'd3, S_A_MARK = 6'd6, S_A_MARKW = 6'd7,
                         S_A_TBL = 6'd8, S_A_SCR = 6'd9, S_A_SCRW = 6'd10, S_A_ACT = 6'd11, S_A_RB = 6'd12, S_A_RBW = 6'd13, S_A_RBR = 6'd14,
                         S_F_WAIT = 6'd15, S_F_CLR = 6'd16, S_F_CLRW = 6'd17, S_F_REL = 6'd18,
                         S_M_FIND = 6'd19, S_M_FINDW = 6'd20, S_M_MARK = 6'd21, S_M_MARKW = 6'd22, S_M_BEGIN = 6'd23,
                         S_FIN = 6'd24;

  logic [5:0]    st_q;
  logic [7:0]    cmd_q;
  logic [31:0]   a0_q, a1_q, a2_q, a3_q;
  logic          pol_q;                                  // current command came from the policy
  logic [7:0]    rc_q;
  logic [IW-1:0] idx_q;
  logic [3:0]    dom_q;
  logic [GA-1:0] pva_q;
  logic [LW-1:0] len_q;
  logic          tier_q, tier2_valid_q, tier2_q, perm_r_q, perm_w_q, pin_q, dst_q;
  logic [PW-1:0] ph_q;
  logic [7:0]    gen_q;
  logic [31:0]   res0_q, res1_q;
  logic          pre_q, freeing_done_q;

  // domain registers
  logic [ND-1:0]    en_q, quar_q, autoq_q;
  logic [3:0]       bind_q [ND];
  logic [GL-1:0]    wb_q [ND];
  logic [GL-1:0]    wl_q [ND];
  logic [15:0]      quota_q [ND];

  always_comb begin
    dom_en = en_q; dom_quar = quar_q; dom_autoq = autoq_q;
    for (int d = 0; d < ND; d++) begin
      bind_dom[d*4 +: 4]    = bind_q[d];
      dom_wbase[d*GL +: GL] = wb_q[d];
      dom_wlim[d*GL +: GL]  = wl_q[d];
      dom_quota[d*16 +: 16] = quota_q[d];
    end
  end

  assign busy      = (st_q != S_IDLE);
  assign pol_ready = (st_q == S_IDLE) && !cmd_pend;
  assign cmd_take  = (st_q == S_IDLE) && cmd_pend;

  // ------------------------------------------------------------------ entry decode (read port follows idx)
  logic [IW-1:0] sel_idx;
  assign sel_idx = (st_q == S_DEC) ? a0_q[IW-1:0] : idx_q;
  assign rd_idx  = sel_idx;
  wire [1:0]  e_state = rd_ent[sfmp_pkg::E_STATE +: 2];
  wire        e_tier  = rd_ent[sfmp_pkg::E_TIER];
  wire [1:0]  e_mig   = rd_ent[sfmp_pkg::E_MIG +: 2];
  wire        e_pin   = rd_ent[sfmp_pkg::E_PIN];
  wire [3:0]  e_dom   = rd_ent[sfmp_pkg::E_DOM +: 4];
  wire [7:0]  e_gen   = rd_ent[sfmp_pkg::E_GEN +: 8];
  wire [LW-1:0] e_len = rd_ent[sfmp_pkg::E_LEN +: LW];
  wire [PW-1:0] e_ph  = rd_ent[sfmp_pkg::E_PHYS +: PW];

  // region-command argument checks (S_DEC)
  wire idx_in   = (a0_q < 32'(NR));
  wire live_ent = idx_in && (e_state != sfmp_pkg::RS_FREE);
  wire gen_ok   = pol_q || (a1_q[7:0] == e_gen);

  // ------------------------------------------------------------------ ALLOC validation (S_DEC)
  wire [31:0] nwb32   = a1_q >> GRAN_LG;      // DOM_SET window in granules
  wire [31:0] nwl32   = a2_q >> GRAN_LG;
  wire [31:0] len_g32 = a2_q >> GRAN_LG;
  wire [31:0] pva_g32 = a1_q >> GRAN_LG;
  wire dom_in    = (a0_q < 32'(ND));
  wire [DIW-1:0] a0_d = a0_q[DIW-1:0];      // domain / port index (values >= ND are rejected before use)
  wire [DIW-1:0] a1_d = a1_q[DIW-1:0];
  wire [$clog2(ND+1)-1:0] a0_p = a0_q[$clog2(ND+1)-1:0];   // client-port index (ports 0..ND-1 are bindable)
  logic          d_en_sel;
  logic [GL-1:0] d_wb, d_wl;
  logic [15:0]   d_quota, d_use;
  always_comb begin
    d_en_sel = 1'b0; d_wb = '0; d_wl = '0; d_quota = '0; d_use = '0;
    for (int d = 0; d < ND; d++) if (a0_q[3:0] == 4'(d)) begin
      d_en_sel = en_q[d]; d_wb = wb_q[d]; d_wl = wl_q[d]; d_quota = quota_q[d]; d_use = use_sram[d*16 +: 16];
    end
  end
  wire a_aligned = (a1_q[GRAN_LG-1:0] == '0) && (a2_q[GRAN_LG-1:0] == '0) && (a2_q != 32'd0) && (a3_q[1:0] != 2'd3);
  wire a_toolarge= (len_g32 > 32'(MAXLEN));
  wire a_inwin   = ({1'b0, pva_g32[GA-1:0]} >= d_wb) && ({1'b0, pva_g32[GA-1:0]} + {1'b0, len_g32[GA-1:0]} <= d_wl) &&
                   (pva_g32[31:GA] == '0) && (len_g32[31:GA] == '0);
  assign ov_base = pva_g32[GA-1:0];
  assign ov_len  = len_g32[LW-1:0];
  wire sram_fits = ({16'd0, d_use} + len_g32 <= {16'd0, d_quota});

  // ---- decode: result for commands that finish in S_DEC
  logic [7:0] dec_rc;
  logic       dec_ok_cmd;      // single-cycle command that applies its effect
  always_comb begin
    dec_rc = sfmp_pkg::RC_BAD_CMD;
    dec_ok_cmd = 1'b0;
    case (cmd_q)
      sfmp_pkg::CMD_NOP: begin dec_rc = sfmp_pkg::RC_OK; end
      sfmp_pkg::CMD_DOM_SET: begin
        logic ovl;
        ovl = 1'b0;
        for (int d = 0; d < ND; d++)
          if (a0_q[3:0] != 4'(d) && en_q[d] && a3_q[16] &&
              (nwb32 < {{(32-GL){1'b0}}, wl_q[d]}) && ({{(32-GL){1'b0}}, wb_q[d]} < nwl32))
            ovl = 1'b1;
        if (!dom_in)                                                        dec_rc = sfmp_pkg::RC_BAD_ARG;
        else if (a1_q[GRAN_LG-1:0] != '0 || a2_q[GRAN_LG-1:0] != '0 || nwl32 <= nwb32 ||
                 nwl32 > (32'd1 << GA) || nwb32 >= (32'd1 << GA))           dec_rc = sfmp_pkg::RC_BAD_ARG;
        else if (live_cnt[a0_d*8 +: 8] != 8'd0)                         dec_rc = sfmp_pkg::RC_BUSY;
        else if (ovl)                                                       dec_rc = sfmp_pkg::RC_WIN_OVERLAP;
        else begin dec_rc = sfmp_pkg::RC_OK; dec_ok_cmd = 1'b1; end
      end
      sfmp_pkg::CMD_BIND: begin
        if (a0_q >= 32'(ND) || a1_q >= 32'(ND))                              dec_rc = sfmp_pkg::RC_BAD_ARG;
        else if (!port_idle[a0_p])                                      dec_rc = sfmp_pkg::RC_BUSY;
        else begin dec_rc = sfmp_pkg::RC_OK; dec_ok_cmd = 1'b1; end
      end
      sfmp_pkg::CMD_CLR_QUAR: begin
        if (!dom_in) dec_rc = sfmp_pkg::RC_BAD_ARG;
        else begin dec_rc = sfmp_pkg::RC_OK; dec_ok_cmd = 1'b1; end
      end
      sfmp_pkg::CMD_SET_PERM, sfmp_pkg::CMD_PIN, sfmp_pkg::CMD_CLR_ERR: begin
        if (!idx_in)                                                         dec_rc = sfmp_pkg::RC_BAD_ARG;
        else if (!live_ent || !gen_ok)                                       dec_rc = sfmp_pkg::RC_STALE;
        else if (e_state != sfmp_pkg::RS_ACTIVE && cmd_q != sfmp_pkg::CMD_CLR_ERR) dec_rc = sfmp_pkg::RC_NOT_ACTIVE;
        else begin dec_rc = sfmp_pkg::RC_OK; dec_ok_cmd = 1'b1; end
      end
      default: dec_rc = sfmp_pkg::RC_BAD_CMD;
    endcase
  end

  // ---- ALLOC pre-checks as a priority ladder (valid in S_DEC)
  logic [7:0] a_rc;
  always_comb begin
    a_rc = sfmp_pkg::RC_OK;
    if (!dom_in)                          a_rc = sfmp_pkg::RC_BAD_ARG;
    else if (!d_en_sel)                   a_rc = sfmp_pkg::RC_BAD_DOMAIN;
    else if (!a_aligned)                  a_rc = sfmp_pkg::RC_BAD_ARG;
    else if (a_toolarge)                  a_rc = sfmp_pkg::RC_TOO_LARGE;
    else if (!a_inwin)                    a_rc = sfmp_pkg::RC_OUTSIDE_WIN;
    else if (!fr_vld)                     a_rc = sfmp_pkg::RC_NO_SLOT;
    else if (ov_any)                      a_rc = sfmp_pkg::RC_OVERLAP;
    else if (a3_q[1:0] == sfmp_pkg::PREF_SRAM && !sram_fits) a_rc = sfmp_pkg::RC_QUOTA;
  end

  // ---- MIGRATE pre-checks (valid in S_DEC)
  logic [7:0] m_rc;
  always_comb begin
    m_rc = sfmp_pkg::RC_OK;
    if (!idx_in)                          m_rc = sfmp_pkg::RC_BAD_ARG;
    else if (!live_ent || !gen_ok)        m_rc = sfmp_pkg::RC_STALE;
    else if (e_state != sfmp_pkg::RS_ACTIVE) m_rc = sfmp_pkg::RC_NOT_ACTIVE;
    else if (e_mig != sfmp_pkg::MG_NONE || me_busy) m_rc = sfmp_pkg::RC_BUSY;
    else if (e_pin)                       m_rc = sfmp_pkg::RC_PINNED;
    else if (a2_q[0] == e_tier)           m_rc = sfmp_pkg::RC_SAME_TIER;
  end
  // quota for a promotion: domain of the region
  logic [15:0] m_use, m_quota;
  always_comb begin
    m_use = '0; m_quota = '0;
    for (int d = 0; d < ND; d++) if (e_dom == 4'(d)) begin m_use = use_sram[d*16 +: 16]; m_quota = quota_q[d]; end
  end
  wire m_quota_ok = (a2_q[0] != sfmp_pkg::TIER_SRAM) || ({16'd0, m_use} + {{(32-LW){1'b0}}, e_len} <= {16'd0, m_quota});

  // ------------------------------------------------------------------ outputs driven by state
  always_comb begin
    ct_op = sfmp_pkg::CT_NONE; ct_idx = idx_q; ct_dom = dom_q; ct_pva = pva_q; ct_len = len_q; ct_tier = tier_q; ct_phys = ph_q;
    ct_perm_r = perm_r_q; ct_perm_w = perm_w_q; ct_pin = pin_q; ct_frozen = !pre_q;
    al_valid = 1'b0; al_op = 2'd0; al_tier = tier_q; al_base = ph_q; al_len = len_q;
    sc_start = 1'b0; sc_tier = tier_q; sc_base = {{(32-PW-GRAN_LG){1'b0}}, ph_q, {GRAN_LG{1'b0}}}; sc_len = {{(32-LW-GRAN_LG){1'b0}}, len_q, {GRAN_LG{1'b0}}};
    me_start = 1'b0;
    case (st_q)
      S_DEC: begin
        ct_idx = a0_q[IW-1:0];
        if (dec_ok_cmd) begin
          case (cmd_q)
            sfmp_pkg::CMD_SET_PERM: begin ct_op = sfmp_pkg::CT_PERM; ct_perm_r = a2_q[0]; ct_perm_w = a2_q[1]; end
            sfmp_pkg::CMD_PIN:      begin ct_op = sfmp_pkg::CT_PIN;  ct_pin = a2_q[0]; end
            sfmp_pkg::CMD_CLR_ERR:  ct_op = sfmp_pkg::CT_CLRERR;
            default: ;
          endcase
        end
      end
      S_A_F0:   begin al_valid = 1'b1; al_op = 2'd0; al_base = '0; end
      S_A_MARK: begin al_valid = 1'b1; al_op = 2'd1; end
      S_A_TBL:  begin ct_op = sfmp_pkg::CT_ALLOC; end
      S_A_SCR:  sc_start = 1'b1;
      S_A_ACT:  begin ct_op = sfmp_pkg::CT_ACTIVATE; end
      S_A_RB:   begin al_valid = 1'b1; al_op = 2'd2; end
      S_A_RBR:  begin ct_op = sfmp_pkg::CT_RELEASE; end
      S_F_WAIT: begin
        // FREEING is applied on entry (first cycle) -- see below
      end
      S_F_CLR:  begin al_valid = 1'b1; al_op = 2'd2; al_tier = e_tier; al_base = e_ph; al_len = e_len; end
      S_F_REL:  begin ct_op = sfmp_pkg::CT_RELEASE; end
      S_M_FIND: begin al_valid = 1'b1; al_op = 2'd0; al_tier = dst_q; al_base = '0; al_len = e_len; end
      S_M_MARK: begin al_valid = 1'b1; al_op = 2'd1; al_tier = dst_q; al_base = ph_q; al_len = e_len; end
      S_M_BEGIN: begin
        ct_op = sfmp_pkg::CT_MIGBEGIN; me_start = 1'b1;
      end
      default: ;
    endcase
    // FREEING mark: issued in the dedicated one-cycle state below
    if (st_q == S_F_WAIT && !freeing_done_q) ct_op = sfmp_pkg::CT_FREEING;
  end

  // migration start payload (valid in S_M_BEGIN)
  always_comb begin
    me_idx       = idx_q;
    me_dir       = (e_tier == sfmp_pkg::TIER_SRAM);                    // SRAM region -> demote
    me_dom       = e_dom;
    me_src_gran  = e_ph;
    me_dst_gran  = ph_q;
    me_len       = e_len;
    me_precopy   = pre_q;
    me_dram_base = {{(32-PW-GRAN_LG){1'b0}}, (me_dir ? ph_q : e_ph), {GRAN_LG{1'b0}}};
    me_sram_base = {{(32-PW-GRAN_LG){1'b0}}, (me_dir ? e_ph : ph_q), {GRAN_LG{1'b0}}};
  end

  // ------------------------------------------------------------------ results
  assign cmd_done = (st_q == S_FIN) && !pol_q;
  assign pol_done = (st_q == S_FIN) &&  pol_q;
  assign cmd_rc   = rc_q;
  assign pol_rc   = rc_q;
  assign cmd_idx  = 5'(idx_q);
  assign cmd_gen  = gen_q;
  assign cmd_res0 = res0_q;
  assign cmd_res1 = res1_q;
  assign ev_alloc_ok   = (st_q == S_FIN) && !pol_q && (cmd_q == sfmp_pkg::CMD_ALLOC) && (rc_q == sfmp_pkg::RC_OK);
  assign ev_alloc_fail = (st_q == S_FIN) && !pol_q && (cmd_q == sfmp_pkg::CMD_ALLOC) && (rc_q != sfmp_pkg::RC_OK);
  assign ev_free_ok    = (st_q == S_FIN) && !pol_q && (cmd_q == sfmp_pkg::CMD_FREE)  && (rc_q == sfmp_pkg::RC_OK);
  assign ev_cmd_err    = (st_q == S_FIN) && !pol_q && (rc_q != sfmp_pkg::RC_OK);

  // ------------------------------------------------------------------ sequencing
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= S_IDLE; cmd_q <= '0; a0_q <= '0; a1_q <= '0; a2_q <= '0; a3_q <= '0; pol_q <= 1'b0; rc_q <= '0; idx_q <= '0; dom_q <= '0;
      pva_q <= '0; len_q <= '0; tier_q <= 1'b0; tier2_valid_q <= 1'b0; tier2_q <= 1'b0; perm_r_q <= 1'b0; perm_w_q <= 1'b0; pin_q <= 1'b0;
      dst_q <= 1'b0; ph_q <= '0; gen_q <= '0; res0_q <= '0; res1_q <= '0; pre_q <= 1'b1; freeing_done_q <= 1'b0;
      en_q <= '0; quar_q <= '0; autoq_q <= '0;
      for (int d = 0; d < ND; d++) begin bind_q[d] <= 4'(d); wb_q[d] <= '0; wl_q[d] <= '0; quota_q[d] <= '0; end
    end else begin
      // hardware quarantine (set wins over a same-cycle clear)
      for (int d = 0; d < ND; d++) if (quar_set[d]) quar_q[d] <= 1'b1;

      case (st_q)
        S_IDLE: begin
          if (cmd_pend) begin
            cmd_q <= cmd; a0_q <= a0; a1_q <= a1; a2_q <= a2; a3_q <= a3; pol_q <= 1'b0; st_q <= S_DEC;
          end else if (pol_valid) begin
            cmd_q <= sfmp_pkg::CMD_MIGRATE; a0_q <= {{(32-IW){1'b0}}, pol_idx}; a1_q <= '0; a2_q <= {31'd0, pol_dst}; a3_q <= '0;
            pol_q <= 1'b1; st_q <= S_DEC;
          end
        end

        S_DEC: begin
          idx_q <= a0_q[IW-1:0]; gen_q <= e_gen; res0_q <= '0; res1_q <= '0; freeing_done_q <= 1'b0; pre_q <= precopy_en;
          case (cmd_q)
            sfmp_pkg::CMD_ALLOC: begin
              rc_q <= a_rc;
              dom_q <= a0_q[3:0]; pva_q <= pva_g32[GA-1:0]; len_q <= len_g32[LW-1:0];
              perm_r_q <= a3_q[2]; perm_w_q <= a3_q[3]; pin_q <= a3_q[4];
              idx_q <= fr_idx;
              if (a_rc != sfmp_pkg::RC_OK) st_q <= S_FIN;
              else begin
                // tier order
                case (a3_q[1:0])
                  sfmp_pkg::PREF_SRAM: begin tier_q <= sfmp_pkg::TIER_SRAM; tier2_valid_q <= 1'b0; end
                  sfmp_pkg::PREF_DRAM: begin tier_q <= sfmp_pkg::TIER_DRAM; tier2_valid_q <= 1'b0; end
                  default: begin   // AUTO
                    if (sram_fits) begin tier_q <= sfmp_pkg::TIER_SRAM; tier2_valid_q <= 1'b1; tier2_q <= sfmp_pkg::TIER_DRAM; end
                    else           begin tier_q <= sfmp_pkg::TIER_DRAM; tier2_valid_q <= 1'b0; end
                  end
                endcase
                st_q <= S_A_F0;
              end
            end
            sfmp_pkg::CMD_FREE: begin
              if (!idx_in)                        begin rc_q <= sfmp_pkg::RC_BAD_ARG; st_q <= S_FIN; end
              else if (!live_ent || !gen_ok)      begin rc_q <= sfmp_pkg::RC_STALE; st_q <= S_FIN; end
              else if (e_state != sfmp_pkg::RS_ACTIVE) begin rc_q <= sfmp_pkg::RC_NOT_ACTIVE; st_q <= S_FIN; end
              else if (e_mig != sfmp_pkg::MG_NONE) begin rc_q <= sfmp_pkg::RC_BUSY; st_q <= S_FIN; end
              else begin rc_q <= sfmp_pkg::RC_OK; st_q <= S_F_WAIT; end
            end
            sfmp_pkg::CMD_MIGRATE: begin
              dst_q <= a2_q[0];
              if (m_rc != sfmp_pkg::RC_OK)        begin rc_q <= m_rc; st_q <= S_FIN; end
              else if (!m_quota_ok)               begin rc_q <= sfmp_pkg::RC_QUOTA; st_q <= S_FIN; end
              else begin rc_q <= sfmp_pkg::RC_OK; st_q <= S_M_FIND; end
            end
            default: begin
              rc_q <= dec_rc;
              if (dec_ok_cmd) begin
                case (cmd_q)
                  sfmp_pkg::CMD_DOM_SET: begin
                    en_q[a0_d] <= a3_q[16]; autoq_q[a0_d] <= a3_q[17]; quota_q[a0_d] <= a3_q[15:0];
                    wb_q[a0_d] <= nwb32[GL-1:0];
                    wl_q[a0_d] <= nwl32[GL-1:0];
                  end
                  sfmp_pkg::CMD_BIND:     bind_q[a0_d] <= 4'(a1_d);
                  sfmp_pkg::CMD_CLR_QUAR: if (!quar_set[a0_d]) quar_q[a0_d] <= 1'b0;
                  default: ;
                endcase
              end
              st_q <= S_FIN;
            end
          endcase
        end

        // ---------------- ALLOC
        S_A_F0: if (al_ready) st_q <= S_A_F0W;
        S_A_F0W: if (al_done) begin
          if (al_found) begin ph_q <= al_found_base; st_q <= S_A_MARK; end
          else if (tier2_valid_q) begin tier_q <= tier2_q; tier2_valid_q <= 1'b0; st_q <= S_A_F0; end   // AUTO: fall back to DRAM
          else begin rc_q <= sfmp_pkg::RC_NO_SPACE; st_q <= S_FIN; end
        end
        S_A_MARK: if (al_ready) st_q <= S_A_MARKW;
        S_A_MARKW: if (al_done) st_q <= S_A_TBL;
        S_A_TBL: st_q <= S_A_SCR;
        S_A_SCR: if (sc_idle) st_q <= S_A_SCRW;
        S_A_SCRW: if (sc_done) begin
          if (sc_err) st_q <= S_A_RB;
          else        st_q <= S_A_ACT;
        end
        S_A_ACT: begin
          gen_q  <= e_gen;                                               // generation assigned by CT_ALLOC
          res0_q <= {tier_q, 7'd0, 8'd0, {(16-PW){1'b0}}, ph_q};        // [31] tier, [15:0] physical granule
          res1_q <= {{(32-GA){1'b0}}, pva_q};
          rc_q <= sfmp_pkg::RC_OK; st_q <= S_FIN;
        end
        S_A_RB: if (al_ready) st_q <= S_A_RBW;
        S_A_RBW: if (al_done) st_q <= S_A_RBR;
        S_A_RBR: begin rc_q <= sfmp_pkg::RC_MEDIA; st_q <= S_FIN; end

        // ---------------- FREE
        S_F_WAIT: begin
          freeing_done_q <= 1'b1;                                   // CT_FREEING was issued in the first cycle of this state
          if (freeing_done_q && !infl_nz[idx_q]) st_q <= S_F_CLR;
        end
        S_F_CLR: if (al_ready) st_q <= S_F_CLRW;
        S_F_CLRW: if (al_done) st_q <= S_F_REL;
        S_F_REL: begin rc_q <= sfmp_pkg::RC_OK; st_q <= S_FIN; end

        // ---------------- MIGRATE
        S_M_FIND: if (al_ready) st_q <= S_M_FINDW;
        S_M_FINDW: if (al_done) begin
          if (al_found) begin ph_q <= al_found_base; st_q <= S_M_MARK; end
          else begin rc_q <= sfmp_pkg::RC_NO_SPACE; st_q <= S_FIN; end
        end
        S_M_MARK: if (al_ready) st_q <= S_M_MARKW;
        S_M_MARKW: if (al_done) st_q <= S_M_BEGIN;
        S_M_BEGIN: begin rc_q <= sfmp_pkg::RC_OK; st_q <= S_FIN; end

        S_FIN: st_q <= S_IDLE;
        default: st_q <= S_IDLE;
      endcase
    end
  end

  wire unused_ok = &{1'b0, e_dom[0], rd_ent[sfmp_pkg::ENTRY_W-1], a3_q[31:18]};
endmodule

`default_nettype wire
