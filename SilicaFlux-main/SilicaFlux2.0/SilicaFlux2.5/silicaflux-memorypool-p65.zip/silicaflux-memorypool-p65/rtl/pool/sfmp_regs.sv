// =============================================================================
// MemoryPool :: sfmp_regs -- privileged register page
//
// Same page protocol as the rest of the SilicaFlux register pages (`rb_sel / rb_we / rb_addr[11:0] /
// rb_wdata -> rb_rdata / rb_err`, plus `rb_priv` as in the RAS page): a one-cycle strobe, combinational
// read, write at the end of the strobe, word access only.
//
// PROTECTION.  `rb_priv` must be driven by the trusted management plane (the ControlCore firmware / the
// host physical function).  Without it:
//   * a write to ANY register is refused (no effect, rb_err, counted in G_PRIV_VIOL, RAS ILLEGAL_OP event);
//   * a read of anything except ID / VERSION / CAP returns 0 with rb_err -- allocation metadata, the
//     last-fault capture and the counters are management-only (tenants cannot read each other's metadata).
// All region-table changes happen through the command registers (ARG0..3 + CMD); the data path has no
// write access to ownership or mappings.
//
// COMMANDS.  Writing CMD latches ARG0..3 into a one-deep pending buffer (so the arguments cannot change
// under the command engine); a second CMD write while one is pending/running is dropped and sets the
// CMD_DROPPED sticky bit.  CMD_STATUS reports busy / done / result code / region handle.
//
// COUNTERS are 64-bit and read as LO then HI: reading LO latches the matching HI half (one shared latch
// per counter class), so a 64-bit value is read coherently with two 32-bit accesses.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfmp_regs #(
  parameter int ND        = 4,
  parameter int NR        = 32,
  parameter int GA        = 20,
  parameter int GRAN_LG   = 8,
  parameter int DW        = 32,
  parameter int CHUNK_LG  = 6,
  parameter int G0        = 256,
  parameter int G1        = 1024,
  parameter int MAXLEN    = 64,
  parameter int NCH       = 1,
  parameter int POOL_AW   = 28
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // register page
  input  wire logic                rb_sel,
  input  wire logic                rb_we,
  input  wire logic [11:0]         rb_addr,
  input  wire logic [31:0]         rb_wdata,
  input  wire logic                rb_priv,
  output logic      [31:0]         rb_rdata,
  output logic                     rb_err,
  // run-time controls
  output logic                     ctl_policy_en,
  output logic                     ctl_precopy,
  output logic                     ctl_verify,
  output logic                     ctl_autocost,
  output logic                     ctl_autodelta,
  output logic      [7:0]          mig_max_rounds,
  output logic      [7:0]          mig_freeze_thresh,
  output logic      [7:0]          mig_max_retry,
  output logic                     tlm_freeze,
  output logic                     tlm_clear,
  // command engine
  output logic                     cmd_pend,
  output logic      [7:0]          cmd_o,
  output logic      [31:0]         arg0_o,
  output logic      [31:0]         arg1_o,
  output logic      [31:0]         arg2_o,
  output logic      [31:0]         arg3_o,
  input  wire logic                cmd_take,
  input  wire logic                cmd_done,
  input  wire logic [7:0]          cmd_rc,
  input  wire logic [4:0]          cmd_idx,
  input  wire logic [7:0]          cmd_gen,
  input  wire logic [31:0]         cmd_res0,
  input  wire logic [31:0]         cmd_res1,
  // migration status
  input  wire logic                mig_busy,
  input  wire logic                mig_done_evt,
  input  wire logic                mig_done_ok,
  input  wire logic [7:0]          mig_done_result,
  input  wire logic [$clog2(NR)-1:0] mig_done_idx,
  input  wire logic [31:0]         mig_done_cycles,
  input  wire logic [31:0]         mig_done_bytes,
  input  wire logic                mig_start_evt,
  // last access fault
  input  wire logic [3:0]          lf_cause,
  input  wire logic [3:0]          lf_port,
  input  wire logic [3:0]          lf_dom,
  input  wire logic                lf_write,
  input  wire logic [31:0]         lf_addr,
  // sticky error sources
  input  wire logic                st_timeout,
  input  wire logic                st_inv,
  input  wire logic                st_oor,
  // occupancy
  input  wire logic [15:0]         occ0,
  input  wire logic [15:0]         occ1,
  input  wire logic [15:0]         peak0,
  input  wire logic [15:0]         peak1,
  // region read-out window
  output logic      [$clog2(NR)-1:0] rsel_o,
  input  wire logic [sfmp_pkg::ENTRY_W-1:0] rent,
  input  wire logic [31:0]         r_score,
  // domain read-out window
  output logic      [3:0]          dsel_o,
  input  wire logic [ND-1:0]       dom_en,
  input  wire logic [ND-1:0]       dom_quar,
  input  wire logic [ND-1:0]       dom_autoq,
  input  wire logic [ND*4-1:0]     bind_dom,
  input  wire logic [ND*(GA+1)-1:0] dom_wbase,
  input  wire logic [ND*(GA+1)-1:0] dom_wlim,
  input  wire logic [ND*16-1:0]    dom_quota,
  input  wire logic [ND*16-1:0]    dom_use,
  input  wire logic [ND*8-1:0]     dom_live,
  input  wire logic [ND*32-1:0]    dom_latmax,
  input  wire logic [31:0]         glat_max,
  // counters
  input  wire logic [sfmp_pkg::NG*64-1:0]              cnt_g,
  input  wire logic [ND*sfmp_pkg::NDC*64-1:0]          cnt_d,
  // policy registers
  output logic      [31:0]         pol_epoch,
  output logic      [7:0]          pol_hot_min,
  output logic      [7:0]          pol_decay,
  output logic      [7:0]          pol_cool,
  output logic      [7:0]          pol_horizon,
  output logic      [15:0]         pol_cost_gran,
  output logic      [15:0]         pol_cost_chunk,
  output logic      [31:0]         pol_delta,
  output logic      [7:0]          pol_margin,
  output logic      [7:0]          pol_hyst,
  output logic      [15:0]         pol_high_wm,
  output logic      [7:0]          pol_sram_lat,
  input  wire logic                pol_scanning,
  input  wire logic [7:0]          pol_epochs,
  input  wire logic [15:0]         pol_cost_est,
  input  wire logic [15:0]         pol_delta_est,
  // events
  output logic                     ev_priv_viol,
  output logic                     ev_cmd_dropped
);
  localparam int IW = $clog2(NR);
  localparam int DIW = (ND > 1) ? $clog2(ND) : 1;

  // ---------------------------------------------------------------- state
  logic        pol_en_q, pre_q, ver_q, auto_q, autod_q, tlm_frz_q;
  logic [7:0]  rounds_q, thresh_q, retry_q;
  logic [31:0] a0_q, a1_q, a2_q, a3_q, arg0_q, arg1_q, arg2_q, arg3_q;
  logic [7:0]  cmd_q;
  logic        pend_q, inflight_q, done_q;
  logic [7:0]  rc_q, gen_q;
  logic [4:0]  idx_q;
  logic [31:0] res0_q, res1_q;
  logic        mdone_q, mok_q;
  logic [7:0]  mres_q;
  logic [4:0]  midx_q;
  logic [31:0] mcyc_q, mbytes_q;
  logic [3:0]  sticky_q;
  logic [IW-1:0] rsel_q;
  logic [3:0]  dsel_q;
  logic [31:0] gl_lo_hi_q, dm_lo_hi_q;       // HI halves latched by a LO read (global / per-domain)
  logic [31:0] pe_q, ph_q_unused;
  logic [7:0]  hm_q, dc_q, cd_q, hz_q, ms_q, hg_q, sl_q;
  logic [15:0] cg_q, cc_q, wm_q;
  logic [31:0] dl_q;

  assign ctl_policy_en = pol_en_q;
  assign ctl_precopy   = pre_q;
  assign ctl_verify    = ver_q;
  assign ctl_autocost  = auto_q;
  assign ctl_autodelta = autod_q;
  assign mig_max_rounds = rounds_q; assign mig_freeze_thresh = thresh_q; assign mig_max_retry = retry_q;
  assign tlm_freeze = tlm_frz_q;
  assign cmd_pend = pend_q;
  assign cmd_o = cmd_q; assign arg0_o = arg0_q; assign arg1_o = arg1_q; assign arg2_o = arg2_q; assign arg3_o = arg3_q;
  assign rsel_o = rsel_q; assign dsel_o = dsel_q;
  assign pol_epoch = pe_q; assign pol_hot_min = hm_q; assign pol_decay = dc_q; assign pol_cool = cd_q; assign pol_horizon = hz_q;
  assign pol_cost_gran = cg_q; assign pol_cost_chunk = cc_q; assign pol_delta = dl_q; assign pol_margin = ms_q; assign pol_hyst = hg_q;
  assign pol_high_wm = wm_q;
  assign pol_sram_lat = sl_q;

  // ---------------------------------------------------------------- decode helpers
  wire wr = rb_sel && rb_we;
  wire rd = rb_sel && !rb_we;
  wire [DIW-1:0] dsel_i = dsel_q[DIW-1:0];

  // region read-out fields
  wire [1:0]  e_state = rent[sfmp_pkg::E_STATE +: 2];
  wire        e_tier  = rent[sfmp_pkg::E_TIER];
  wire [1:0]  e_mig   = rent[sfmp_pkg::E_MIG +: 2];
  wire        e_dirty = rent[sfmp_pkg::E_DIRTY];
  wire        e_pin   = rent[sfmp_pkg::E_PIN];
  wire        e_pr    = rent[sfmp_pkg::E_PR];
  wire        e_pw    = rent[sfmp_pkg::E_PW];
  wire [3:0]  e_dom   = rent[sfmp_pkg::E_DOM +: 4];
  wire [7:0]  e_err   = rent[sfmp_pkg::E_ERR +: 8];
  wire [7:0]  e_gen   = rent[sfmp_pkg::E_GEN +: 8];

  // counter windows: LO at +8k, HI at +8k+4
  wire [11:0] g_off = rb_addr - sfmp_pkg::R_G_BASE;
  wire [11:0] d_off = rb_addr - sfmp_pkg::R_D_BASE;
  wire        in_g  = (rb_addr >= sfmp_pkg::R_G_BASE) && (g_off < 12'(sfmp_pkg::NG * 8));
  wire        in_d  = (rb_addr >= sfmp_pkg::R_D_BASE) && (d_off < 12'(sfmp_pkg::NDC * 8));
  wire [8:0]  g_k   = g_off[11:3];
  wire [8:0]  d_k   = d_off[11:3];
  wire [15:0] d_sel_k = 16'(dsel_i) * 16'(sfmp_pkg::NDC) + 16'(d_k);

  // is this offset a writable / readable register?  (for rb_err)
  logic        w_known, r_known, r_open;       // r_open: readable without privilege
  logic [31:0] rdv;
  always_comb begin
    w_known = 1'b0; r_known = 1'b0; r_open = 1'b0; rdv = '0;
    case (rb_addr)
      sfmp_pkg::R_ID:      begin r_known = 1'b1; r_open = 1'b1; rdv = sfmp_pkg::ID_MAGIC; end
      sfmp_pkg::R_VERSION: begin r_known = 1'b1; r_open = 1'b1; rdv = sfmp_pkg::RTL_VER; end
      sfmp_pkg::R_CAP0:    begin r_known = 1'b1; r_open = 1'b1; rdv = {8'(CHUNK_LG), 8'(DW/8), 4'(GRAN_LG), 8'(NR), 4'(ND)}; end
      sfmp_pkg::R_CAP1:    begin r_known = 1'b1; r_open = 1'b1; rdv = {16'(MAXLEN), 16'(G0)}; end
      sfmp_pkg::R_CAP2:    begin r_known = 1'b1; r_open = 1'b1; rdv = 32'(G1); end
      sfmp_pkg::R_CAP3:    begin r_known = 1'b1; r_open = 1'b1; rdv = {16'd0, 8'(POOL_AW), 8'(NCH)}; end
      sfmp_pkg::R_CTRL:    begin r_known = 1'b1; w_known = 1'b1; rdv = {27'd0, autod_q, auto_q, ver_q, pre_q, pol_en_q}; end
      sfmp_pkg::R_CMD_ARG0: begin r_known = 1'b1; w_known = 1'b1; rdv = a0_q; end
      sfmp_pkg::R_CMD_ARG1: begin r_known = 1'b1; w_known = 1'b1; rdv = a1_q; end
      sfmp_pkg::R_CMD_ARG2: begin r_known = 1'b1; w_known = 1'b1; rdv = a2_q; end
      sfmp_pkg::R_CMD_ARG3: begin r_known = 1'b1; w_known = 1'b1; rdv = a3_q; end
      sfmp_pkg::R_CMD:      begin w_known = 1'b1; end
      sfmp_pkg::R_CMD_STATUS: begin r_known = 1'b1; rdv = {gen_q, 3'd0, idx_q, rc_q, 6'd0, done_q, inflight_q}; end
      sfmp_pkg::R_CMD_RES0: begin r_known = 1'b1; rdv = res0_q; end
      sfmp_pkg::R_CMD_RES1: begin r_known = 1'b1; rdv = res1_q; end
      sfmp_pkg::R_MIG_STATUS: begin r_known = 1'b1; rdv = {11'd0, midx_q, mres_q, 5'd0, mok_q, mdone_q, mig_busy}; end
      sfmp_pkg::R_MIG_CYCLES: begin r_known = 1'b1; rdv = mcyc_q; end
      sfmp_pkg::R_MIG_BYTES:  begin r_known = 1'b1; rdv = mbytes_q; end
      sfmp_pkg::R_MIG_CTL:    begin r_known = 1'b1; w_known = 1'b1; rdv = {8'd0, retry_q, thresh_q, rounds_q}; end
      sfmp_pkg::R_FAULT_INFO: begin r_known = 1'b1; rdv = {19'd0, lf_write, lf_dom, lf_port, lf_cause}; end
      sfmp_pkg::R_FAULT_ADDR: begin r_known = 1'b1; rdv = lf_addr; end
      sfmp_pkg::R_STICKY:     begin r_known = 1'b1; w_known = 1'b1; rdv = {28'd0, sticky_q}; end
      sfmp_pkg::R_OCC:        begin r_known = 1'b1; rdv = {occ1, occ0}; end
      sfmp_pkg::R_RSEL:       begin r_known = 1'b1; w_known = 1'b1; rdv = {{(32-IW){1'b0}}, rsel_q}; end
      sfmp_pkg::R_RD_W0:      begin r_known = 1'b1; rdv = {e_gen, e_err, e_dom, 3'd0, e_pw, e_pr, e_pin, e_dirty, e_mig, e_tier, e_state}; end
      sfmp_pkg::R_RD_PVA:     begin r_known = 1'b1; rdv = {{(32-GA){1'b0}}, rent[sfmp_pkg::E_PVA +: GA]}; end
      sfmp_pkg::R_RD_LEN:     begin r_known = 1'b1; rdv = {24'd0, rent[sfmp_pkg::E_LEN +: 8]}; end
      sfmp_pkg::R_RD_PHYS:    begin r_known = 1'b1; rdv = {16'd0, rent[sfmp_pkg::E_PHYS +: 16]}; end
      sfmp_pkg::R_RD_RDTOT:   begin r_known = 1'b1; rdv = rent[sfmp_pkg::E_RDTOT +: 32]; end
      sfmp_pkg::R_RD_WRTOT:   begin r_known = 1'b1; rdv = rent[sfmp_pkg::E_WRTOT +: 32]; end
      sfmp_pkg::R_RD_SCORE:   begin r_known = 1'b1; rdv = r_score; end
      sfmp_pkg::R_DSEL:       begin r_known = 1'b1; w_known = 1'b1; rdv = {28'd0, dsel_q}; end
      sfmp_pkg::R_DOM_STAT:   begin r_known = 1'b1; rdv = {29'd0, dom_autoq[dsel_i], dom_quar[dsel_i], dom_en[dsel_i]}; end
      sfmp_pkg::R_DOM_WBASE:  begin r_known = 1'b1; rdv = {{(32-GA-1){1'b0}}, dom_wbase[dsel_i*(GA+1) +: GA+1]} << GRAN_LG; end
      sfmp_pkg::R_DOM_WLIM:   begin r_known = 1'b1; rdv = {{(32-GA-1){1'b0}}, dom_wlim[dsel_i*(GA+1) +: GA+1]} << GRAN_LG; end
      sfmp_pkg::R_DOM_QUOTA:  begin r_known = 1'b1; rdv = {16'd0, dom_quota[dsel_i*16 +: 16]}; end
      sfmp_pkg::R_DOM_USE:    begin r_known = 1'b1; rdv = {16'd0, dom_use[dsel_i*16 +: 16]}; end
      sfmp_pkg::R_DOM_LIVE:   begin r_known = 1'b1; rdv = {24'd0, dom_live[dsel_i*8 +: 8]}; end
      sfmp_pkg::R_DOM_LATMAX: begin r_known = 1'b1; rdv = dom_latmax[dsel_i*32 +: 32]; end
      sfmp_pkg::R_GLAT_MAX:   begin r_known = 1'b1; rdv = glat_max; end
      sfmp_pkg::R_SRAM_PEAK:  begin r_known = 1'b1; rdv = {16'd0, peak0}; end
      sfmp_pkg::R_DRAM_PEAK:  begin r_known = 1'b1; rdv = {16'd0, peak1}; end
      sfmp_pkg::R_BIND0:      begin r_known = 1'b1; rdv = 32'(bind_dom); end
      sfmp_pkg::R_TLM_CTRL:   begin r_known = 1'b1; w_known = 1'b1; rdv = {31'd0, tlm_frz_q}; end
      sfmp_pkg::R_POL_CTRL0:  begin r_known = 1'b1; w_known = 1'b1; rdv = pe_q; end
      sfmp_pkg::R_POL_CTRL1:  begin r_known = 1'b1; w_known = 1'b1; rdv = {hz_q, cd_q, dc_q, hm_q}; end
      sfmp_pkg::R_POL_COST:   begin r_known = 1'b1; w_known = 1'b1; rdv = {cc_q, cg_q}; end
      sfmp_pkg::R_POL_DELTA:  begin r_known = 1'b1; w_known = 1'b1; rdv = dl_q; end
      sfmp_pkg::R_POL_MARGIN: begin r_known = 1'b1; w_known = 1'b1; rdv = {wm_q, hg_q, ms_q}; end
      sfmp_pkg::R_POL_STATUS: begin r_known = 1'b1; rdv = {16'd0, pol_epochs, 7'd0, pol_scanning}; end
      sfmp_pkg::R_POL_COSTEST: begin r_known = 1'b1; rdv = {16'd0, pol_cost_est}; end
      sfmp_pkg::R_POL_DELTAEST: begin r_known = 1'b1; rdv = {16'd0, pol_delta_est}; end
      sfmp_pkg::R_POL_SRAMLAT: begin r_known = 1'b1; w_known = 1'b1; rdv = {24'd0, sl_q}; end
      default: ;
    endcase
    // counters: LO / HI at +8k / +8k+4
    if (in_g) begin
      r_known = 1'b1;
      rdv = rb_addr[2] ? gl_lo_hi_q : cnt_g[g_k*64 +: 32];
    end
    if (in_d) begin
      r_known = 1'b1;
      rdv = rb_addr[2] ? dm_lo_hi_q : cnt_d[d_sel_k*64 +: 32];
    end
  end

  always_comb begin
    rb_rdata = '0;
    rb_err   = 1'b0;
    if (rb_sel) begin
      if (rb_we) begin
        if (!w_known || !rb_priv) rb_err = 1'b1;
      end else begin
        if (!r_known)                  rb_err = 1'b1;
        else if (!r_open && !rb_priv)  rb_err = 1'b1;
        else                           rb_rdata = rdv;
      end
    end
  end

  assign ev_priv_viol   = wr && w_known && !rb_priv;
  wire   wr_ok          = wr && w_known && rb_priv;
  wire   launch         = wr_ok && (rb_addr == sfmp_pkg::R_CMD);
  assign ev_cmd_dropped = launch && (pend_q || inflight_q);

  assign tlm_clear = wr_ok && (rb_addr == sfmp_pkg::R_TLM_CTRL) && rb_wdata[1];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pol_en_q <= 1'b0; pre_q <= 1'b1; ver_q <= 1'b1; auto_q <= 1'b0; autod_q <= 1'b0; tlm_frz_q <= 1'b0;
      rounds_q <= 8'd3; thresh_q <= 8'd2; retry_q <= 8'd2;
      a0_q <= '0; a1_q <= '0; a2_q <= '0; a3_q <= '0; arg0_q <= '0; arg1_q <= '0; arg2_q <= '0; arg3_q <= '0; cmd_q <= '0;
      pend_q <= 1'b0; inflight_q <= 1'b0; done_q <= 1'b0; rc_q <= '0; gen_q <= '0; idx_q <= '0; res0_q <= '0; res1_q <= '0;
      mdone_q <= 1'b0; mok_q <= 1'b0; mres_q <= '0; midx_q <= '0; mcyc_q <= '0; mbytes_q <= '0;
      sticky_q <= '0; rsel_q <= '0; dsel_q <= '0; gl_lo_hi_q <= '0; dm_lo_hi_q <= '0;
      pe_q <= 32'd20000; hm_q <= 8'd4; dc_q <= 8'd1; cd_q <= 8'd4; hz_q <= 8'd8; cg_q <= 16'd1500; cc_q <= 16'd400; dl_q <= 32'd18;
      sl_q <= 8'd3; ms_q <= 8'd1; hg_q <= 8'd8; wm_q <= 16'(G0);          // pressure relief is opt-in: default watermark = capacity
      ph_q_unused <= '0;
    end else begin
      // ---- sticky error sources
      if (ev_cmd_dropped) sticky_q[0] <= 1'b1;
      if (st_timeout)     sticky_q[1] <= 1'b1;
      if (st_inv)         sticky_q[2] <= 1'b1;
      if (st_oor)         sticky_q[3] <= 1'b1;

      // ---- command pipeline
      if (cmd_take) pend_q <= 1'b0;
      if (cmd_done) begin
        inflight_q <= 1'b0; done_q <= 1'b1; rc_q <= cmd_rc; idx_q <= cmd_idx; gen_q <= cmd_gen; res0_q <= cmd_res0; res1_q <= cmd_res1;
      end
      if (launch && !(pend_q || inflight_q)) begin
        pend_q <= 1'b1; inflight_q <= 1'b1; done_q <= 1'b0; cmd_q <= rb_wdata[7:0];
        arg0_q <= a0_q; arg1_q <= a1_q; arg2_q <= a2_q; arg3_q <= a3_q;
      end

      // ---- migration status (last migration)
      if (mig_start_evt) mdone_q <= 1'b0;
      if (mig_done_evt) begin
        mdone_q <= 1'b1; mok_q <= mig_done_ok; mres_q <= mig_done_result; midx_q <= 5'(mig_done_idx);
        mcyc_q <= mig_done_cycles; mbytes_q <= mig_done_bytes;
      end

      // ---- counter HI latch
      if (rd && in_g && !rb_addr[2] && rb_priv) gl_lo_hi_q <= cnt_g[g_k*64 + 32 +: 32];
      if (rd && in_d && !rb_addr[2] && rb_priv) dm_lo_hi_q <= cnt_d[d_sel_k*64 + 32 +: 32];

      // ---- privileged writes
      if (wr_ok) begin
        case (rb_addr)
          sfmp_pkg::R_CTRL:     begin pol_en_q <= rb_wdata[0]; pre_q <= rb_wdata[1]; ver_q <= rb_wdata[2]; auto_q <= rb_wdata[3]; autod_q <= rb_wdata[4]; end
          sfmp_pkg::R_CMD_ARG0: a0_q <= rb_wdata;
          sfmp_pkg::R_CMD_ARG1: a1_q <= rb_wdata;
          sfmp_pkg::R_CMD_ARG2: a2_q <= rb_wdata;
          sfmp_pkg::R_CMD_ARG3: a3_q <= rb_wdata;
          sfmp_pkg::R_MIG_CTL:  begin rounds_q <= rb_wdata[7:0]; thresh_q <= rb_wdata[15:8]; retry_q <= rb_wdata[23:16]; end
          sfmp_pkg::R_STICKY:   sticky_q <= sticky_q & ~rb_wdata[3:0];
          sfmp_pkg::R_RSEL:     rsel_q <= rb_wdata[IW-1:0];
          sfmp_pkg::R_DSEL:     dsel_q <= rb_wdata[3:0];
          sfmp_pkg::R_TLM_CTRL: tlm_frz_q <= rb_wdata[0];
          sfmp_pkg::R_POL_CTRL0: pe_q <= rb_wdata;
          sfmp_pkg::R_POL_CTRL1: begin hm_q <= rb_wdata[7:0]; dc_q <= rb_wdata[15:8]; cd_q <= rb_wdata[23:16]; hz_q <= rb_wdata[31:24]; end
          sfmp_pkg::R_POL_COST:  begin cg_q <= rb_wdata[15:0]; cc_q <= rb_wdata[31:16]; end
          sfmp_pkg::R_POL_DELTA: dl_q <= rb_wdata;
          sfmp_pkg::R_POL_SRAMLAT: sl_q <= rb_wdata[7:0];
          sfmp_pkg::R_POL_MARGIN: begin ms_q <= rb_wdata[7:0]; hg_q <= rb_wdata[15:8]; wm_q <= rb_wdata[31:16]; end
          default: ;
        endcase
      end
    end
  end

  wire unused_ok = &{1'b0, ph_q_unused, rent[sfmp_pkg::ENTRY_W-1], mig_start_evt, rb_wdata[31:24]};
endmodule

`default_nettype wire
