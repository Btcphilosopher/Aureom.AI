// =============================================================================
// MemoryPool :: sfmp_mig_chan -- one migration copy channel (CloudDMA + guard + CRC verify)
//
// Copies ONE chunk between the DRAM tier and the SRAM tier with the repository's CloudDMA
// (`sfd_clouddma`, Project 61, vendored unmodified):
//     dir 0  PROMOTE  DRAM -> SRAM   (CloudDMA "H2D": host-memory port = DRAM tier, SRAM port = SRAM tier)
//     dir 1  DEMOTE   SRAM -> DRAM   (CloudDMA "D2H")
// then (optionally) VERIFIES the destination:
//   * a CRC-32 is accumulated over the data CloudDMA READ from the source (tapped at the response of
//     the source port, so an errored/swallowed beat is never included);
//   * the destination chunk is read back through a separate verify master and CRC-ed;
//   * equal -> chunk done; different -> the chunk is copied again (up to `max_retry` times), then the
//     channel fails with MR_VERIFY.  A DMA/tier error fails the channel with MR_DMA.
// The source CRC is taken from the DMA's own reads, so a tenant write that lands on the source after
// the read cannot cause a false mismatch (the dirty-chunk logic in sfmp_migrate re-copies that chunk).
//
// DEFENCE IN DEPTH.  Each CloudDMA port passes through `sfd_sfb_gate` driven by a per-beat window check
// against THIS chunk only: the DRAM-side beat must lie inside the chunk's DRAM window with the right
// direction (read when promoting, write when demoting), the SRAM-side beat likewise.  A beat that violates
// it is swallowed (no tier ever sees it) and the channel fails with MR_GUARD.  So even a corrupted job
// descriptor cannot make the migration DMA touch memory outside the chunk it was given.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfmp_mig_chan #(
  parameter int DW = 32
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // job
  input  wire logic              start,
  input  wire logic              dir,            // 0 promote (DRAM->SRAM), 1 demote (SRAM->DRAM)
  input  wire logic [31:0]       dram_addr,      // chunk base byte address in tier 1
  input  wire logic [31:0]       sram_addr,      // chunk base byte address in tier 0
  input  wire logic [31:0]       len_bytes,      // chunk length (multiple of DW/8)
  input  wire logic              verify_en,
  input  wire logic [7:0]        max_retry,
  output logic                   idle,
  output logic                   done,           // pulse: chunk finished (ok or failed)
  output logic                   fail,           // valid with done
  output logic [7:0]             fail_code,      // MR_*  (valid with done && fail)
  // DRAM-side DMA master (-> tier 1 arbiter)
  output logic                   d_req_valid,
  input  wire logic              d_req_ready,
  output logic                   d_req_write,
  output logic [31:0]            d_req_addr,
  output logic [DW-1:0]          d_req_wdata,
  output logic [DW/8-1:0]        d_req_wstrb,
  input  wire logic              d_rsp_valid,
  output logic                   d_rsp_ready,
  input  wire logic [DW-1:0]     d_rsp_rdata,
  input  wire logic              d_rsp_err,
  // SRAM-side DMA master (-> tier 0 arbiter)
  output logic                   s_req_valid,
  input  wire logic              s_req_ready,
  output logic                   s_req_write,
  output logic [31:0]            s_req_addr,
  output logic [DW-1:0]          s_req_wdata,
  output logic [DW/8-1:0]        s_req_wstrb,
  input  wire logic              s_rsp_valid,
  output logic                   s_rsp_ready,
  input  wire logic [DW-1:0]     s_rsp_rdata,
  input  wire logic              s_rsp_err,
  // verify masters (read only): to tier 0 and to tier 1
  output logic                   v0_req_valid,
  input  wire logic              v0_req_ready,
  output logic [31:0]            v0_req_addr,
  input  wire logic              v0_rsp_valid,
  input  wire logic [DW-1:0]     v0_rsp_rdata,
  input  wire logic              v0_rsp_err,
  output logic                   v1_req_valid,
  input  wire logic              v1_req_ready,
  output logic [31:0]            v1_req_addr,
  input  wire logic              v1_rsp_valid,
  input  wire logic [DW-1:0]     v1_rsp_rdata,
  input  wire logic              v1_rsp_err,
  // events
  output logic [31:0]            ev_copy_bytes,  // chunk bytes acknowledged (pulse value)
  output logic [31:0]            ev_verify_bytes,
  output logic                   ev_retry
);
  localparam int DWB = DW / 8;
  localparam int LGB = $clog2(DWB);

  localparam logic [3:0] C_IDLE = 4'd0, C_CMD = 4'd1, C_WAIT = 4'd2, C_VER = 4'd3, C_DONE = 4'd4, C_FAIL = 4'd5;

  // ---- CRC-32 (IEEE, reflected) over whole beats, byte 0 = data[7:0]
  function automatic logic [31:0] crc_beat(input logic [31:0] crc_in, input logic [DW-1:0] data);
    logic [31:0] c;
    c = crc_in;
    for (int b = 0; b < DWB; b++) begin
      c = c ^ {24'd0, data[b*8 +: 8]};
      for (int i = 0; i < 8; i++) c = c[0] ? ((c >> 1) ^ 32'hEDB8_8320) : (c >> 1);
    end
    crc_beat = c;
  endfunction

  logic [3:0]  st_q;
  logic        dir_q, ver_q;
  logic [31:0] dram_q, sram_q, len_q;
  logic [7:0]  retry_max_q, retry_q, code_q;
  logic [31:0] crc_src_q, crc_dst_q;
  logic [31:0] v_iss_q, v_got_q;
  logic        v_err_q;

  assign idle = (st_q == C_IDLE);
  assign done = (st_q == C_DONE) || (st_q == C_FAIL);
  assign fail = (st_q == C_FAIL);
  assign fail_code = code_q;

  // ---- CloudDMA
  logic        cmd_valid, cmd_ready, dn_valid, dn_commit, dn_busy;
  logic [7:0]  dn_err;
  logic [31:0] dn_bytes;
  assign cmd_valid = (st_q == C_CMD);

  // DMA-side (unguarded) master signals
  logic        hm_req_valid, hm_req_ready, hm_req_write, hm_rsp_valid, hm_rsp_ready, hm_rsp_error;
  logic [31:0] hm_req_addr;
  logic [DW-1:0] hm_req_wdata, hm_rsp_rdata;
  logic [DWB-1:0] hm_req_wstrb;
  logic        sm_req_valid, sm_req_ready, sm_req_write, sm_rsp_valid, sm_rsp_ready, sm_rsp_error;
  logic [31:0] sm_req_addr;
  logic [DW-1:0] sm_req_wdata, sm_rsp_rdata;
  logic [DWB-1:0] sm_req_wstrb;
  logic        g_viol_h, g_viol_s;
  logic        ev_h2d, ev_d2h;
  logic [7:0]  ev_bb;

  sfd_clouddma #(.DW(DW), .AW(32)) u_dma (
    .clk, .rst_n,
    .cmd_valid, .cmd_ready, .cmd_dir(dir_q), .cmd_haddr(dram_q), .cmd_saddr(sram_q), .cmd_len(len_q),
    .done_valid(dn_valid), .done_err(dn_err), .done_bytes(dn_bytes), .done_commit(dn_commit), .busy(dn_busy),
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error(hm_rsp_error),
    .sm_req_valid, .sm_req_ready, .sm_req_write, .sm_req_addr, .sm_req_wdata, .sm_req_wstrb,
    .sm_rsp_valid, .sm_rsp_ready, .sm_rsp_rdata, .sm_rsp_error(sm_rsp_error),
    .g_viol(g_viol_h || g_viol_s),
    .ev_h2d_beat(ev_h2d), .ev_d2h_beat(ev_d2h), .ev_beat_bytes(ev_bb)
  );

  // ---- per-beat window checks (this chunk only)
  wire [31:0] dram_hi = dram_q + len_q;
  wire [31:0] sram_hi = sram_q + len_q;
  wire job_act = (st_q == C_WAIT);
  wire allow_h = job_act && (hm_req_addr >= dram_q) && ((hm_req_addr + 32'(DWB)) <= dram_hi) && (hm_req_write == dir_q);
  wire allow_s = job_act && (sm_req_addr >= sram_q) && ((sm_req_addr + 32'(DWB)) <= sram_hi) && (sm_req_write == !dir_q);

  sfd_sfb_gate #(.AW(32), .DW(DW)) u_gate_h (
    .clk, .rst_n,
    .m_req_valid(hm_req_valid), .m_req_ready(hm_req_ready), .m_req_write(hm_req_write), .m_req_addr(hm_req_addr),
    .m_req_wdata(hm_req_wdata), .m_req_wstrb(hm_req_wstrb),
    .m_rsp_valid(hm_rsp_valid), .m_rsp_ready(hm_rsp_ready), .m_rsp_rdata(hm_rsp_rdata), .m_rsp_error(hm_rsp_error),
    .s_req_valid(d_req_valid), .s_req_ready(d_req_ready), .s_req_write(d_req_write), .s_req_addr(d_req_addr),
    .s_req_wdata(d_req_wdata), .s_req_wstrb(d_req_wstrb),
    .s_rsp_valid(d_rsp_valid), .s_rsp_ready(d_rsp_ready), .s_rsp_rdata(d_rsp_rdata), .s_rsp_error(d_rsp_err),
    .allow(allow_h), .blk_evt(g_viol_h)
  );
  sfd_sfb_gate #(.AW(32), .DW(DW)) u_gate_s (
    .clk, .rst_n,
    .m_req_valid(sm_req_valid), .m_req_ready(sm_req_ready), .m_req_write(sm_req_write), .m_req_addr(sm_req_addr),
    .m_req_wdata(sm_req_wdata), .m_req_wstrb(sm_req_wstrb),
    .m_rsp_valid(sm_rsp_valid), .m_rsp_ready(sm_rsp_ready), .m_rsp_rdata(sm_rsp_rdata), .m_rsp_error(sm_rsp_error),
    .s_req_valid(s_req_valid), .s_req_ready(s_req_ready), .s_req_write(s_req_write), .s_req_addr(s_req_addr),
    .s_req_wdata(s_req_wdata), .s_req_wstrb(s_req_wstrb),
    .s_rsp_valid(s_rsp_valid), .s_rsp_ready(s_rsp_ready), .s_rsp_rdata(s_rsp_rdata), .s_rsp_error(s_rsp_err),
    .allow(allow_s), .blk_evt(g_viol_s)
  );

  // ---- CRC tap on the SOURCE stream (response side of the source port, error beats excluded)
  wire src_beat = dir_q ? (sm_rsp_valid && sm_rsp_ready && !sm_rsp_error)
                        : (hm_rsp_valid && hm_rsp_ready && !hm_rsp_error);
  wire [DW-1:0] src_data = dir_q ? sm_rsp_rdata : hm_rsp_rdata;

  // ---- verify reads on the destination tier
  wire v_issue  = (st_q == C_VER) && (v_iss_q < (len_q >> LGB)) && ((v_iss_q - v_got_q) < 32'd4);
  wire v_tier1  = dir_q;                               // destination is DRAM when demoting
  wire [31:0] v_addr = (dir_q ? dram_q : sram_q) + (v_iss_q << LGB);
  assign v0_req_valid = v_issue && !v_tier1;
  assign v1_req_valid = v_issue &&  v_tier1;
  assign v0_req_addr  = v_addr;
  assign v1_req_addr  = v_addr;
  wire v_acc = (v0_req_valid && v0_req_ready) || (v1_req_valid && v1_req_ready);
  wire v_rsp = (st_q == C_VER) && (v_tier1 ? v1_rsp_valid : v0_rsp_valid);
  wire [DW-1:0] v_data = v_tier1 ? v1_rsp_rdata : v0_rsp_rdata;
  wire v_rerr = v_tier1 ? v1_rsp_err : v0_rsp_err;

  assign ev_copy_bytes   = (st_q == C_WAIT && dn_valid && dn_err == 8'd0 && dn_bytes == len_q) ? len_q : 32'd0;
  assign ev_verify_bytes = (st_q == C_VER && v_rsp && !v_rerr) ? 32'(DWB) : 32'd0;
  assign ev_retry        = (st_q == C_VER) && (v_got_q == (len_q >> LGB)) && (crc_dst_q != crc_src_q) && (retry_q < retry_max_q);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= C_IDLE; dir_q <= 1'b0; ver_q <= 1'b0; dram_q <= '0; sram_q <= '0; len_q <= '0; retry_max_q <= '0; retry_q <= '0;
      code_q <= '0; crc_src_q <= 32'hFFFF_FFFF; crc_dst_q <= 32'hFFFF_FFFF; v_iss_q <= '0; v_got_q <= '0; v_err_q <= 1'b0;
    end else begin
      case (st_q)
        C_IDLE: if (start) begin
          dir_q <= dir; dram_q <= dram_addr; sram_q <= sram_addr; len_q <= len_bytes; ver_q <= verify_en;
          retry_max_q <= max_retry; retry_q <= '0; crc_src_q <= 32'hFFFF_FFFF; code_q <= '0;
          st_q <= C_CMD;
        end
        C_CMD: if (cmd_ready) begin
          crc_src_q <= 32'hFFFF_FFFF;
          st_q <= C_WAIT;
        end
        C_WAIT: begin
          if (src_beat) crc_src_q <= crc_beat(crc_src_q, src_data);
          if (dn_valid) begin
            if (dn_err != 8'd0) begin
              code_q <= (dn_err == silicaflux_cloud_pkg::ERR_PERM_BEAT) ? sfmp_pkg::MR_GUARD : sfmp_pkg::MR_DMA;
              st_q   <= C_FAIL;
            end else if (dn_bytes != len_q) begin
              code_q <= sfmp_pkg::MR_DMA; st_q <= C_FAIL;
            end else if (ver_q) begin
              crc_dst_q <= 32'hFFFF_FFFF; v_iss_q <= '0; v_got_q <= '0; v_err_q <= 1'b0;
              st_q <= C_VER;
            end else begin
              st_q <= C_DONE;
            end
          end
        end
        C_VER: begin
          if (v_acc) v_iss_q <= v_iss_q + 32'd1;
          if (v_rsp) begin
            v_got_q <= v_got_q + 32'd1;
            if (v_rerr) v_err_q <= 1'b1;
            else        crc_dst_q <= crc_beat(crc_dst_q, v_data);
          end
          if (v_got_q == (len_q >> LGB)) begin
            if (v_err_q) begin
              code_q <= sfmp_pkg::MR_DMA; st_q <= C_FAIL;
            end else if (crc_dst_q == crc_src_q) begin
              st_q <= C_DONE;
            end else if (retry_q < retry_max_q) begin
              retry_q <= retry_q + 8'd1; st_q <= C_CMD;            // copy the chunk again
            end else begin
              code_q <= sfmp_pkg::MR_VERIFY; st_q <= C_FAIL;
            end
          end
        end
        C_DONE, C_FAIL: st_q <= C_IDLE;
        default: st_q <= C_IDLE;
      endcase
    end
  end

  wire unused_ok = &{1'b0, dn_commit, dn_busy, ev_h2d, ev_d2h, ev_bb, hm_req_wdata[0], sm_req_wdata[0], dram_hi[0], sram_hi[0]};
endmodule

`default_nettype wire
