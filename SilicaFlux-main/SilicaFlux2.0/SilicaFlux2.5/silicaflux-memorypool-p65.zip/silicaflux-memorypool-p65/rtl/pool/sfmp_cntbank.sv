// =============================================================================
// MemoryPool :: sfmp_cntbank -- bank of N 64-bit event counters
//
// Every counter adds the multi-bit increment presented on its slice of `inc_i` in the cycle it is
// presented (so a byte counter adds the byte count of the beat, a cycle counter adds 1 per cycle).
// Increments come from real handshakes in the data path -- nothing is estimated.
// `freeze_i` stops counting (the counters keep their value); `clear_i` zeroes them and wins.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfmp_cntbank #(
  parameter int N     = 8,
  parameter int INC_W = 32
) (
  input  wire logic               clk,
  input  wire logic               rst_n,
  input  wire logic [N*INC_W-1:0] inc_i,
  input  wire logic               freeze_i,
  input  wire logic               clear_i,
  output logic      [N*64-1:0]    cnt_o
);
  logic [63:0] c_q [N];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < N; i++) c_q[i] <= 64'd0;
    end else if (clear_i) begin
      for (int i = 0; i < N; i++) c_q[i] <= 64'd0;
    end else if (!freeze_i) begin
      for (int i = 0; i < N; i++) c_q[i] <= c_q[i] + {{(64-INC_W){1'b0}}, inc_i[i*INC_W +: INC_W]};
    end
  end

  always_comb begin
    for (int i = 0; i < N; i++) cnt_o[i*64 +: 64] = c_q[i];
  end
endmodule

`default_nettype wire
