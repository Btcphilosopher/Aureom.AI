// =============================================================================
// MemoryPool :: sfmp_alloc -- per-tier extent allocator (granule bitmaps, first-fit contiguous)
//
// One bitmap per tier, one bit per granule.  Serial FSM: FIND scans one granule per cycle for the
// first run of `len` free granules (so fragmentation is REAL: a request can fail although the
// total free space would suffice); MARK / CLEAR walk `len` granules.  Two users:
//   * the command engine (ctrl port, valid/ready, then a `done` pulse), and
//   * the migration engine's release of an extent (level request `r_req`, `r_done` pulse);
//     a pending release has priority over a new ctrl operation.
// The bitmaps are the physical-overlap guard: FIND only ever returns granules whose bit is clear, and
// MARK sets them, so no two allocations (including migration destinations, which are marked at
// migration start) can overlap.  Occupancy counters follow MARK / CLEAR.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfmp_alloc #(
  parameter int G0     = 256,       // tier-0 granules
  parameter int G1     = 1024,      // tier-1 granules
  parameter int MAXLEN = 64
) (
  input  wire logic                         clk,
  input  wire logic                         rst_n,
  // command-engine port
  input  wire logic                         c_valid,
  output logic                              c_ready,
  input  wire logic [1:0]                   c_op,        // 0 FIND, 1 MARK, 2 CLEAR
  input  wire logic                         c_tier,
  input  wire logic [$clog2((G0>G1)?G0:G1)-1:0] c_base,
  input  wire logic [$clog2(MAXLEN+1)-1:0]  c_len,
  output logic                              c_done,      // pulse
  output logic                              c_found,     // valid with c_done for FIND
  output logic [$clog2((G0>G1)?G0:G1)-1:0]  c_found_base,
  // migration-engine release port
  input  wire logic                         r_req,
  input  wire logic                         r_tier,
  input  wire logic [$clog2((G0>G1)?G0:G1)-1:0] r_base,
  input  wire logic [$clog2(MAXLEN+1)-1:0]  r_len,
  output logic                              r_done,      // pulse
  // status
  output logic                              idle,
  output logic [$clog2(G0+1)-1:0]           occ0,
  output logic [$clog2(G1+1)-1:0]           occ1,
  output logic [G0-1:0]                     bm0_o,
  output logic [G1-1:0]                     bm1_o
);
  localparam int GMAX = (G0 > G1) ? G0 : G1;
  localparam int GW   = $clog2(GMAX);
  localparam int LW   = $clog2(MAXLEN + 1);

  localparam logic [1:0] OP_FIND = 2'd0, OP_MARK = 2'd1, OP_CLEAR = 2'd2;
  localparam logic [1:0] A_IDLE = 2'd0, A_FIND = 2'd1, A_SET = 2'd2, A_FIN = 2'd3;

  logic [G0-1:0] bm0_q;
  logic [G1-1:0] bm1_q;
  logic [1:0]    st_q, op_q;
  logic          tier_q, from_rel_q, rel_infl_q, found_q;
  logic [GW-1:0] base_q, pos_q, fbase_q;
  logic [LW-1:0] len_q, run_q, i_q;
  logic [$clog2(G0+1)-1:0] occ0_q;
  logic [$clog2(G1+1)-1:0] occ1_q;

  assign bm0_o = bm0_q;
  assign bm1_o = bm1_q;
  assign occ0  = occ0_q;
  assign occ1  = occ1_q;
  assign idle  = (st_q == A_IDLE);

  wire rel_take = (st_q == A_IDLE) && r_req && !rel_infl_q;
  assign c_ready = (st_q == A_IDLE) && !(r_req && !rel_infl_q);

  wire [GW-1:0] last_pos = tier_q ? GW'(G1 - 1) : GW'(G0 - 1);
  localparam int G0W = $clog2(G0);
  localparam int G1W = $clog2(G1);
  wire          cur_bit  = tier_q ? bm1_q[pos_q[G1W-1:0]] : bm0_q[pos_q[G0W-1:0]];
  wire          is_free  = !cur_bit;
  wire          run_hit  = is_free && ((run_q + 1'b1) == len_q);
  wire [GW-1:0] set_idx  = base_q + GW'(i_q);

  assign c_done       = (st_q == A_FIN) && !from_rel_q;
  assign r_done       = (st_q == A_FIN) &&  from_rel_q;
  assign c_found      = found_q;
  assign c_found_base = fbase_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      bm0_q <= '0; bm1_q <= '0; st_q <= A_IDLE; op_q <= OP_FIND; tier_q <= 1'b0; from_rel_q <= 1'b0;
      rel_infl_q <= 1'b0; found_q <= 1'b0; base_q <= '0; pos_q <= '0; fbase_q <= '0; len_q <= '0; run_q <= '0;
      i_q <= '0; occ0_q <= '0; occ1_q <= '0;
    end else begin
      if (!r_req) rel_infl_q <= 1'b0;
      case (st_q)
        A_IDLE: begin
          if (rel_take) begin
            rel_infl_q <= 1'b1; from_rel_q <= 1'b1; op_q <= OP_CLEAR; tier_q <= r_tier; base_q <= r_base; len_q <= r_len;
            i_q <= '0; st_q <= (r_len == '0) ? A_FIN : A_SET;
          end else if (c_valid) begin
            from_rel_q <= 1'b0; op_q <= c_op; tier_q <= c_tier; base_q <= c_base; len_q <= c_len; found_q <= 1'b0;
            i_q <= '0; pos_q <= '0; run_q <= '0;
            st_q <= (c_op == OP_FIND) ? ((c_len == '0) ? A_FIN : A_FIND) : ((c_len == '0) ? A_FIN : A_SET);
          end
        end
        A_FIND: begin
          if (run_hit) begin
            found_q <= 1'b1;
            fbase_q <= pos_q - GW'(run_q);
            st_q    <= A_FIN;
          end else begin
            run_q <= is_free ? run_q + 1'b1 : '0;
            if (pos_q == last_pos) st_q <= A_FIN;     // not found
            pos_q <= pos_q + 1'b1;
          end
        end
        A_SET: begin
          if (tier_q) bm1_q[set_idx[G1W-1:0]] <= (op_q == OP_MARK);
          else        bm0_q[set_idx[G0W-1:0]] <= (op_q == OP_MARK);
          i_q <= i_q + 1'b1;
          if ((i_q + 1'b1) == len_q) begin
            if (tier_q) occ1_q <= (op_q == OP_MARK) ? occ1_q + $bits(occ1_q)'(len_q) : occ1_q - $bits(occ1_q)'(len_q);
            else        occ0_q <= (op_q == OP_MARK) ? occ0_q + $bits(occ0_q)'(len_q) : occ0_q - $bits(occ0_q)'(len_q);
            st_q <= A_FIN;
          end
        end
        A_FIN: st_q <= A_IDLE;
        default: st_q <= A_IDLE;
      endcase
    end
  end
endmodule

`default_nettype wire
