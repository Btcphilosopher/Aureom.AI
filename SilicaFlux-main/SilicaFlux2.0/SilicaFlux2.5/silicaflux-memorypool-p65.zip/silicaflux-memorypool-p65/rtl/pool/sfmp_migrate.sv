// =============================================================================
// MemoryPool :: sfmp_migrate -- region migration engine
//
//   Source Region -> Validate Ownership -> Quiesce / Coordinate Access -> CloudDMA Copy -> Verify
//   Completion -> Update Mapping -> Release Old Region
//
//   * "Validate ownership" and the destination reservation are done by the command engine (sfmp_ctrl)
//     BEFORE this engine starts: the region is ACTIVE, owned, not pinned, the destination extent is
//     allocated in the other tier and the region is marked PRECOPY (or FROZEN).
//   * "Coordinate" = PRE-COPY.  The region stays live: reads and writes are still served from the
//     SOURCE (authoritative) while chunks are copied.  A write that reaches the tier ordered after the
//     chunk was taken out of the to-do set marks the chunk DIRTY; dirty chunks are copied again in the
//     next round.  When the dirty set is small (<= FREEZE_THRESH chunks) or MAX_ROUNDS have run, the
//     region is FROZEN (the table stops dispatching ANY access to it) -- "quiesce".
//   * "Quiesce" = FREEZE + DRAIN: wait until no access to the region is in flight (infl_nz), then copy
//     the remaining dirty chunks.  With PRECOPY_EN = 0 the engine starts in this phase (stop-and-copy).
//   * Every chunk is copied by a CloudDMA channel and verified by CRC read-back (sfmp_mig_chan).
//   * COMMIT is a single table update (tier, physical base) in one cycle, only when: every chunk is
//     copied and verified, nothing is dirty, the region is frozen and no access is in flight.  Until
//     that cycle nothing refers to the destination, so a partially copied destination is never visible.
//   * Only after the commit is the OLD extent released to the allocator.
//   * ABORT (DMA error, verify failure after retries, guard violation): the engine stops handing out
//     chunks, waits for every channel to finish, clears the migration state (the region simply stays at
//     the source, which was never modified by the migration), records a region error code and releases
//     the DESTINATION extent.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfmp_migrate #(
  parameter int NCH       = 1,
  parameter int NR        = 32,
  parameter int ND        = 4,
  parameter int DW        = 32,
  parameter int GRAN_LG   = 8,
  parameter int CHUNK_LG  = 6,
  parameter int MAXCHUNKS = 256,
  parameter int PW        = 10,
  parameter int LW        = 7,
  parameter int GW        = 10          // width of an allocator granule index
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // run-time controls
  input  wire logic                   verify_en,
  input  wire logic [7:0]             max_rounds,
  input  wire logic [7:0]             freeze_thresh,
  input  wire logic [7:0]             max_retry,
  // start (from the command engine); accepted when !busy
  input  wire logic                   start_valid,
  input  wire logic [$clog2(NR)-1:0]  start_idx,
  input  wire logic                   start_dir,          // 0 promote, 1 demote
  input  wire logic [3:0]             start_dom,
  input  wire logic [31:0]            start_dram_base,    // byte address of the region's extent in tier 1 (source or destination)
  input  wire logic [31:0]            start_sram_base,    // ... in tier 0
  input  wire logic [PW-1:0]          start_src_gran,     // source extent (granule index inside its tier)
  input  wire logic [PW-1:0]          start_dst_gran,     // destination extent
  input  wire logic [LW-1:0]          start_len_gran,
  input  wire logic                   start_precopy,
  output logic                        busy,
  output logic      [$clog2(NR)-1:0]  cur_idx,
  // dirty-write events from the access path (every write ordered at a tier)
  input  wire logic                   mw_valid,
  input  wire logic [$clog2(NR)-1:0]  mw_idx,
  input  wire logic [$clog2(MAXCHUNKS)-1:0] mw_chunk,
  input  wire logic [NR-1:0]          infl_nz,
  // region-table migration port
  output logic      [1:0]             mg_op,
  output logic      [$clog2(NR)-1:0]  mg_idx,
  output logic      [PW-1:0]          mg_phys,
  output logic      [7:0]             mg_err,
  // allocator release port
  output logic                        rel_req,
  output logic                        rel_tier,
  output logic      [GW-1:0]          rel_base,
  output logic      [LW-1:0]          rel_len,
  input  wire logic                   rel_done,
  // completion
  output logic                        done_evt,
  output logic                        done_ok,
  output logic      [7:0]             done_result,
  output logic      [$clog2(NR)-1:0]  done_idx,
  output logic      [31:0]            done_cycles,
  output logic      [31:0]            done_bytes,
  output logic      [31:0]            done_frz_cycles,
  output logic                        timeout_evt,
  // channel masters (flat, NCH wide)
  output logic      [NCH-1:0]         d_req_valid,
  input  wire logic [NCH-1:0]         d_req_ready,
  output logic      [NCH-1:0]         d_req_write,
  output logic      [NCH*32-1:0]      d_req_addr,
  output logic      [NCH*DW-1:0]      d_req_wdata,
  output logic      [NCH*(DW/8)-1:0]  d_req_wstrb,
  input  wire logic [NCH-1:0]         d_rsp_valid,
  output logic      [NCH-1:0]         d_rsp_ready,
  input  wire logic [NCH*DW-1:0]      d_rsp_rdata,
  input  wire logic [NCH-1:0]         d_rsp_err,
  output logic      [NCH-1:0]         s_req_valid,
  input  wire logic [NCH-1:0]         s_req_ready,
  output logic      [NCH-1:0]         s_req_write,
  output logic      [NCH*32-1:0]      s_req_addr,
  output logic      [NCH*DW-1:0]      s_req_wdata,
  output logic      [NCH*(DW/8)-1:0]  s_req_wstrb,
  input  wire logic [NCH-1:0]         s_rsp_valid,
  output logic      [NCH-1:0]         s_rsp_ready,
  input  wire logic [NCH*DW-1:0]      s_rsp_rdata,
  input  wire logic [NCH-1:0]         s_rsp_err,
  output logic      [NCH-1:0]         v0_req_valid,
  input  wire logic [NCH-1:0]         v0_req_ready,
  output logic      [NCH*32-1:0]      v0_req_addr,
  input  wire logic [NCH-1:0]         v0_rsp_valid,
  input  wire logic [NCH*DW-1:0]      v0_rsp_rdata,
  input  wire logic [NCH-1:0]         v0_rsp_err,
  output logic      [NCH-1:0]         v1_req_valid,
  input  wire logic [NCH-1:0]         v1_req_ready,
  output logic      [NCH*32-1:0]      v1_req_addr,
  input  wire logic [NCH-1:0]         v1_rsp_valid,
  input  wire logic [NCH*DW-1:0]      v1_rsp_rdata,
  input  wire logic [NCH-1:0]         v1_rsp_err,
  // telemetry
  output logic      [sfmp_pkg::NG*32-1:0]       inc_g,
  output logic      [ND*sfmp_pkg::NDC*32-1:0]   inc_d
);
  localparam int IW   = $clog2(NR);
  localparam int CKW  = $clog2(MAXCHUNKS);
  localparam int CNW  = $clog2(MAXCHUNKS + 1);
  localparam int CHB  = 1 << CHUNK_LG;
  localparam int CHJ  = (NCH > 1) ? $clog2(NCH) : 1;
  localparam int PERC = 1 << (GRAN_LG - CHUNK_LG);       // chunks per granule

  localparam logic [3:0] E_IDLE = 4'd0, E_RUN = 4'd1, E_EVAL = 4'd2, E_FREEZE = 4'd3, E_DRAIN = 4'd4, E_COMMIT = 4'd5,
                         E_REL = 4'd6, E_ABORT = 4'd7, E_DONE = 4'd8;

  logic [3:0]            st_q;
  logic [IW-1:0]         idx_q;
  logic                  dir_q, frozen_q, abort_q, ok_q, rel_dst_q;
  logic [3:0]            dom_q;
  logic [31:0]           dram_q, sram_q;
  logic [PW-1:0]         src_g_q, dst_g_q;
  logic [LW-1:0]         len_q;
  logic [CNW-1:0]        nch_q;                          // chunks in the region
  logic [MAXCHUNKS-1:0]  todo_q, dirty_q, copied_q;
  logic [7:0]            rounds_q, res_q, errc_q;
  logic [CNW-1:0]        infl_ch_q;                      // chunks assigned and not yet finished
  logic [31:0]           cyc_q, bytes_q, frz_q, wd_q;
  logic                  tmo_q;

  assign busy    = (st_q != E_IDLE);
  assign cur_idx = idx_q;

  // ---- channels
  logic [NCH-1:0]  ch_idle, ch_done, ch_fail, ch_start, ch_ev_retry;
  logic [8*NCH-1:0] ch_code;
  logic [32*NCH-1:0] ch_copy_b, ch_ver_b;
  logic [31:0]     ch_dram [NCH];
  logic [31:0]     ch_sram [NCH];

  genvar j;
  generate
    for (j = 0; j < NCH; j++) begin : g_ch
      sfmp_mig_chan #(.DW(DW)) u_ch (
        .clk, .rst_n,
        .start(ch_start[j]), .dir(dir_q), .dram_addr(ch_dram[j]), .sram_addr(ch_sram[j]), .len_bytes(32'(CHB)),
        .verify_en, .max_retry,
        .idle(ch_idle[j]), .done(ch_done[j]), .fail(ch_fail[j]), .fail_code(ch_code[j*8 +: 8]),
        .d_req_valid(d_req_valid[j]), .d_req_ready(d_req_ready[j]), .d_req_write(d_req_write[j]), .d_req_addr(d_req_addr[j*32 +: 32]),
        .d_req_wdata(d_req_wdata[j*DW +: DW]), .d_req_wstrb(d_req_wstrb[j*(DW/8) +: DW/8]),
        .d_rsp_valid(d_rsp_valid[j]), .d_rsp_ready(d_rsp_ready[j]), .d_rsp_rdata(d_rsp_rdata[j*DW +: DW]), .d_rsp_err(d_rsp_err[j]),
        .s_req_valid(s_req_valid[j]), .s_req_ready(s_req_ready[j]), .s_req_write(s_req_write[j]), .s_req_addr(s_req_addr[j*32 +: 32]),
        .s_req_wdata(s_req_wdata[j*DW +: DW]), .s_req_wstrb(s_req_wstrb[j*(DW/8) +: DW/8]),
        .s_rsp_valid(s_rsp_valid[j]), .s_rsp_ready(s_rsp_ready[j]), .s_rsp_rdata(s_rsp_rdata[j*DW +: DW]), .s_rsp_err(s_rsp_err[j]),
        .v0_req_valid(v0_req_valid[j]), .v0_req_ready(v0_req_ready[j]), .v0_req_addr(v0_req_addr[j*32 +: 32]),
        .v0_rsp_valid(v0_rsp_valid[j]), .v0_rsp_rdata(v0_rsp_rdata[j*DW +: DW]), .v0_rsp_err(v0_rsp_err[j]),
        .v1_req_valid(v1_req_valid[j]), .v1_req_ready(v1_req_ready[j]), .v1_req_addr(v1_req_addr[j*32 +: 32]),
        .v1_rsp_valid(v1_rsp_valid[j]), .v1_rsp_rdata(v1_rsp_rdata[j*DW +: DW]), .v1_rsp_err(v1_rsp_err[j]),
        .ev_copy_bytes(ch_copy_b[j*32 +: 32]), .ev_verify_bytes(ch_ver_b[j*32 +: 32]), .ev_retry(ch_ev_retry[j])
      );
    end
  endgenerate

  // ---- chunk scheduler: lowest to-do chunk -> lowest idle channel
  logic            have_todo, have_idle;
  logic [CKW-1:0]  next_chunk;
  logic [CHJ-1:0]  next_ch;
  always_comb begin
    have_todo = 1'b0; next_chunk = '0;
    for (int c = MAXCHUNKS - 1; c >= 0; c--) if (todo_q[c]) begin have_todo = 1'b1; next_chunk = CKW'(c); end
    have_idle = 1'b0; next_ch = '0;
    for (int k = NCH - 1; k >= 0; k--) if (ch_idle[k]) begin have_idle = 1'b1; next_ch = CHJ'(k); end
  end
  wire assign_ok = (st_q == E_RUN) && !abort_q && have_todo && have_idle;
  always_comb begin
    ch_start = '0;
    if (assign_ok) ch_start[next_ch] = 1'b1;
    for (int k = 0; k < NCH; k++) begin
      ch_dram[k]  = dram_q + (32'(next_chunk) << CHUNK_LG);
      ch_sram[k]  = sram_q + (32'(next_chunk) << CHUNK_LG);
    end
  end

  // channel completions / failures this cycle
  logic [CNW-1:0] fin_cnt;
  logic           any_fail;
  logic [7:0]     fail_code;
  always_comb begin
    fin_cnt = '0; any_fail = 1'b0; fail_code = '0;
    for (int k = 0; k < NCH; k++) begin
      if (ch_done[k]) fin_cnt = fin_cnt + CNW'(1);
      if (ch_done[k] && ch_fail[k]) begin any_fail = 1'b1; fail_code = ch_code[k*8 +: 8]; end
    end
  end

  // ---- per-cycle sums over the channels
  logic [31:0] vsum, csum, retry_sum;
  always_comb begin
    csum = 32'd0; vsum = 32'd0; retry_sum = 32'd0;
    for (int k = 0; k < NCH; k++) begin
      csum = csum + ch_copy_b[k*32 +: 32];
      vsum = vsum + ch_ver_b[k*32 +: 32];
      if (ch_ev_retry[k]) retry_sum = retry_sum + 32'd1;
    end
  end

  // ---- dirty events (a write ordered at a tier for the region being migrated)
  wire evt_c = mw_valid && (st_q != E_IDLE) && (mw_idx == idx_q) && (CNW'(mw_chunk) < nch_q);

  // popcount of the dirty set
  logic [CNW-1:0] dcount;
  always_comb begin
    dcount = '0;
    for (int c = 0; c < MAXCHUNKS; c++) dcount = dcount + CNW'(dirty_q[c]);
  end

  // ---- outputs driven by state
  assign mg_idx   = idx_q;
  assign mg_phys  = dst_g_q;
  assign mg_op    = (st_q == E_FREEZE) ? sfmp_pkg::MGO_FREEZE :
                    (st_q == E_COMMIT && !infl_nz[idx_q]) ? sfmp_pkg::MGO_COMMIT :
                    (st_q == E_ABORT)  ? sfmp_pkg::MGO_ABORT : sfmp_pkg::MGO_NONE;
  assign mg_err   = (st_q == E_ABORT) ? errc_q : 8'd0;
  assign rel_req  = (st_q == E_REL);
  assign rel_tier = rel_dst_q ? (dir_q ? sfmp_pkg::TIER_DRAM : sfmp_pkg::TIER_SRAM)    // destination tier
                              : (dir_q ? sfmp_pkg::TIER_SRAM : sfmp_pkg::TIER_DRAM);   // source tier
  assign rel_base = GW'(rel_dst_q ? dst_g_q : src_g_q);
  assign rel_len  = len_q;
  assign done_evt = (st_q == E_DONE);
  assign done_ok  = ok_q;
  assign done_result = res_q;
  assign done_idx = idx_q;
  assign done_cycles = cyc_q;
  assign done_bytes  = bytes_q;
  assign done_frz_cycles = frz_q;
  assign timeout_evt = tmo_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= E_IDLE; idx_q <= '0; dir_q <= 1'b0; frozen_q <= 1'b0; abort_q <= 1'b0; ok_q <= 1'b0; rel_dst_q <= 1'b0; dom_q <= '0;
      dram_q <= '0; sram_q <= '0; src_g_q <= '0; dst_g_q <= '0; len_q <= '0; nch_q <= '0;
      todo_q <= '0; dirty_q <= '0; copied_q <= '0; rounds_q <= '0; res_q <= '0; errc_q <= '0; infl_ch_q <= '0;
      cyc_q <= '0; bytes_q <= '0; frz_q <= '0; wd_q <= '0; tmo_q <= 1'b0;
    end else begin
      // dirty-set update from write events (skip chunks still waiting in the to-do set)
      if (evt_c && !todo_q[mw_chunk]) dirty_q[mw_chunk] <= 1'b1;
      infl_ch_q <= infl_ch_q + (assign_ok ? CNW'(1) : CNW'(0)) - fin_cnt;
      if (assign_ok) begin
        todo_q[next_chunk]   <= 1'b0;
        copied_q[next_chunk] <= 1'b1;
      end
      if (st_q != E_IDLE) begin
        cyc_q <= cyc_q + 32'd1;
        wd_q  <= wd_q + 32'd1;
        if (frozen_q) frz_q <= frz_q + 32'd1;
        if (wd_q == 32'h00FF_FFFF) tmo_q <= 1'b1;
      end
      bytes_q <= bytes_q + csum;

      case (st_q)
        E_IDLE: if (start_valid) begin
          idx_q <= start_idx; dir_q <= start_dir; dom_q <= start_dom; dram_q <= start_dram_base; sram_q <= start_sram_base;
          src_g_q <= start_src_gran; dst_g_q <= start_dst_gran; len_q <= start_len_gran;
          nch_q <= CNW'(start_len_gran) * CNW'(PERC);
          copied_q <= '0; dirty_q <= '0; rounds_q <= '0; abort_q <= 1'b0; ok_q <= 1'b0; res_q <= sfmp_pkg::MR_NONE; errc_q <= '0;
          rel_dst_q <= 1'b0; cyc_q <= '0; bytes_q <= '0; frz_q <= '0; wd_q <= '0; tmo_q <= 1'b0; infl_ch_q <= '0;
          if (start_precopy) begin
            frozen_q <= 1'b0; st_q <= E_RUN;
            for (int c = 0; c < MAXCHUNKS; c++) todo_q[c] <= (CNW'(c) < (CNW'(start_len_gran) * CNW'(PERC)));
          end else begin
            frozen_q <= 1'b0; st_q <= E_FREEZE; todo_q <= '0;
            for (int c = 0; c < MAXCHUNKS; c++) dirty_q[c] <= (CNW'(c) < (CNW'(start_len_gran) * CNW'(PERC)));
          end
        end

        E_RUN: begin
          if (any_fail && !abort_q) begin
            abort_q <= 1'b1; todo_q <= '0;
            errc_q  <= (fail_code == sfmp_pkg::MR_GUARD)  ? sfmp_pkg::RE_MIG_GUARD :
                       (fail_code == sfmp_pkg::MR_VERIFY) ? sfmp_pkg::RE_MIG_VER : sfmp_pkg::RE_MIG_DMA;
            res_q   <= fail_code;
          end
          if (abort_q || any_fail) begin
            if (infl_ch_q == fin_cnt && !assign_ok) st_q <= E_ABORT;              // everything the channels held is finished
          end else if (!have_todo && (infl_ch_q == fin_cnt) && !assign_ok) begin
            st_q <= E_EVAL;
          end
        end

        E_EVAL: begin
          if (frozen_q) begin
            if (dirty_q != '0) begin todo_q <= dirty_q; dirty_q <= '0; st_q <= E_RUN; end     // cannot happen (frozen), but stay correct
            else st_q <= E_COMMIT;
          end else begin
            rounds_q <= rounds_q + 8'd1;
            if (dcount <= CNW'(freeze_thresh) || (rounds_q + 8'd1) >= max_rounds) st_q <= E_FREEZE;
            else begin
              todo_q <= dirty_q; dirty_q <= '0; st_q <= E_RUN;
              if (evt_c && !dirty_q[mw_chunk]) dirty_q[mw_chunk] <= 1'b1;
            end
          end
        end

        E_FREEZE: begin frozen_q <= 1'b1; st_q <= E_DRAIN; end

        E_DRAIN: if (!infl_nz[idx_q]) begin
          // every access that was in flight when the freeze began has completed and its dirty event has arrived
          todo_q <= dirty_q | (evt_c ? ({{(MAXCHUNKS-1){1'b0}}, 1'b1} << mw_chunk) : '0);
          dirty_q <= '0;
          st_q <= E_RUN;
        end

        E_COMMIT: if (!infl_nz[idx_q]) begin
          // mg_op = COMMIT in this cycle: the mapping now points at the destination
          ok_q <= 1'b1; res_q <= sfmp_pkg::MR_OK; rel_dst_q <= 1'b0; st_q <= E_REL;
        end

        E_ABORT: begin
          // mg_op = ABORT: migration state cleared, region stays at the source, error code recorded
          ok_q <= 1'b0; rel_dst_q <= 1'b1; frozen_q <= 1'b0; st_q <= E_REL;
        end

        E_REL: if (rel_done) st_q <= E_DONE;
        E_DONE: begin st_q <= E_IDLE; frozen_q <= 1'b0; end
        default: st_q <= E_IDLE;
      endcase
    end
  end

  // ---- telemetry
  always_comb begin
    inc_g = '0;
    inc_d = '0;
    inc_g[sfmp_pkg::G_MIG_BYTES*32 +: 32]   = csum;
    inc_g[sfmp_pkg::G_MIG_VBYTES*32 +: 32]  = vsum;
    inc_g[sfmp_pkg::G_MIG_RETRY*32 +: 32]   = retry_sum;
    inc_g[sfmp_pkg::G_MIG_ACT_CYC*32 +: 32] = (st_q != E_IDLE) ? 32'd1 : 32'd0;
    inc_g[sfmp_pkg::G_MIG_FRZ_CYC*32 +: 32] = (frozen_q && st_q != E_IDLE) ? 32'd1 : 32'd0;
    inc_g[sfmp_pkg::G_MIG_OK*32 +: 32]      = (st_q == E_DONE && ok_q) ? 32'd1 : 32'd0;
    inc_g[sfmp_pkg::G_MIG_ABORT*32 +: 32]   = (st_q == E_DONE && !ok_q) ? 32'd1 : 32'd0;
    inc_g[sfmp_pkg::G_MIG_RECOPY*32 +: 32]  = assign_ok && copied_q[next_chunk] ? 32'd1 : 32'd0;
    for (int d = 0; d < ND; d++)
      if (dom_q == 4'(d)) inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_MIG_BYTES)*32 +: 32] = csum;
  end

  // freeze_thresh is 8 bits wide; narrower chunk-count widths use only the low bits
  wire unused_ok = &{1'b0, freeze_thresh};
endmodule

`default_nettype wire
