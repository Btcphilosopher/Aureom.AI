// =============================================================================
// MemoryPool :: sfmp_region_table -- region table, CAM translation and per-domain accounting
//
// Per region: state, tier, migration state, dirty flag, pin, R/W permission, owner domain, error code,
// generation, PVA base, length, physical base, epoch and lifetime access counters.
//
// TRANSLATION.  A region maps a PVA range (granule aligned) onto a physical extent of one tier.  The
// lookup is a fully parallel compare of the request granule against every non-free entry (CAM); the
// allocator and the overlap query guarantee at most one entry hits (`lk_multi` is a tripwire).  The
// physical granule is  phys_base + (pva_granule - pva_base);  the byte offset inside the granule is
// untouched.  Granularity = 2**GRAN_LG bytes.  This is the accelerator's OWN remapping of its managed
// windows -- it is not a CPU MMU and not the host IOMMU (see docs/ARCHITECTURE.md, "IOMMU boundary").
//
// WRITE OWNERSHIP (who may change which field):
//   command engine : state, dom, pva, len, perm, pin, gen, tier/phys at ALLOC, mig at MIGBEGIN
//   migration eng. : mig (FREEZE / COMMIT / ABORT), tier+phys+dirty at COMMIT
//   access path    : dirty, epoch + lifetime counters, error code (media errors)
//   policy         : consumes (reads and clears) the epoch counters
// The data path never changes the mapping, ownership or permissions.
//
// SRAM accounting: `use_sram[d]` = SRAM granules reserved by domain d = regions in SRAM (including a
// region being demoted, until its commit) + destination reservations of promotions in progress.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfmp_region_table #(
  parameter int NR     = 32,
  parameter int ND     = 4,
  parameter int GA     = 20,      // PVA granule width
  parameter int LW     = 7,       // length width
  parameter int PW     = 10       // physical granule width
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // ---- translation lookup (combinational), used by the access path
  input  wire logic [GA-1:0]       lk_gran,
  output logic                     lk_hit,
  output logic [$clog2(NR)-1:0]    lk_idx,
  output logic [PW-1:0]            lk_pgran,      // physical granule of the requested granule
  output logic [1:0]               lk_state,
  output logic [3:0]               lk_dom,
  output logic                     lk_tier,
  output logic                     lk_perm_r,
  output logic                     lk_perm_w,
  output logic [1:0]               lk_mig,
  output logic [GA-1:0]            lk_base,       // PVA granule base of the hit region
  output logic                     lk_multi,      // tripwire: more than one entry hit
  // ---- overlap query (command engine)
  input  wire logic [GA-1:0]       ov_base,
  input  wire logic [LW-1:0]       ov_len,
  output logic                     ov_any,
  // ---- first free slot
  output logic                     fr_vld,
  output logic [$clog2(NR)-1:0]    fr_idx,
  // ---- read ports (flat entry vectors, layout in sfmp_pkg)
  input  wire logic [$clog2(NR)-1:0] rd0_idx,
  output logic [sfmp_pkg::ENTRY_W-1:0] rd0_ent,
  input  wire logic [$clog2(NR)-1:0] rd1_idx,
  output logic [sfmp_pkg::ENTRY_W-1:0] rd1_ent,
  input  wire logic [$clog2(NR)-1:0] rd2_idx,
  output logic [sfmp_pkg::ENTRY_W-1:0] rd2_ent,
  // ---- command-engine write port
  input  wire logic [3:0]          ct_op,
  input  wire logic [$clog2(NR)-1:0] ct_idx,
  input  wire logic [3:0]          ct_dom,
  input  wire logic [GA-1:0]       ct_pva,
  input  wire logic [LW-1:0]       ct_len,
  input  wire logic                ct_tier,
  input  wire logic [PW-1:0]       ct_phys,
  input  wire logic                ct_perm_r,
  input  wire logic                ct_perm_w,
  input  wire logic                ct_pin,
  input  wire logic                ct_frozen,
  // ---- migration-engine write port
  input  wire logic [1:0]          mg_op,
  input  wire logic [$clog2(NR)-1:0] mg_idx,
  input  wire logic [PW-1:0]       mg_phys,
  input  wire logic [7:0]          mg_err,        // sticky error code recorded on ABORT (0 = none)
  // ---- access-path events
  input  wire logic                ac_valid,
  input  wire logic [$clog2(NR)-1:0] ac_idx,
  input  wire logic                ac_write,
  input  wire logic                er_valid,
  input  wire logic [$clog2(NR)-1:0] er_idx,
  input  wire logic [7:0]          er_code,
  // ---- policy: consume the epoch counters of one region
  input  wire logic                p_consume,
  input  wire logic [$clog2(NR)-1:0] p_idx,
  // ---- accounting
  output logic [ND*16-1:0]         use_sram,      // granules reserved in SRAM, per domain
  output logic [ND*8-1:0]          live_cnt       // live regions per domain
);
  localparam int IW = $clog2(NR);

  logic [1:0]   st_q   [NR];
  logic [3:0]   dom_q  [NR];
  logic [GA-1:0] pva_q [NR];
  logic [LW-1:0] len_q [NR];
  logic         tier_q [NR];
  logic [PW-1:0] ph_q  [NR];
  logic         pr_q   [NR];
  logic         pw_q   [NR];
  logic         pin_q  [NR];
  logic [1:0]   mig_q  [NR];
  logic         dirty_q[NR];
  logic [7:0]   err_q  [NR];
  logic [7:0]   gen_q  [NR];
  logic [15:0]  rdep_q [NR];
  logic [15:0]  wrep_q [NR];
  logic [31:0]  rdtot_q[NR];
  logic [31:0]  wrtot_q[NR];
  logic [15:0]  use_q  [ND];
  logic [7:0]   live_q [ND];

  // ------------------------------------------------------------------ lookup (CAM)
  logic [NR-1:0] hit_vec;
  always_comb begin
    hit_vec = '0;
    for (int r = 0; r < NR; r++)
      hit_vec[r] = (st_q[r] != sfmp_pkg::RS_FREE) && (lk_gran >= pva_q[r]) &&
                   ((lk_gran - pva_q[r]) < {{(GA-LW){1'b0}}, len_q[r]});
  end
  logic [IW-1:0] hit_idx;
  always_comb begin
    hit_idx = '0;
    for (int r = NR - 1; r >= 0; r--) if (hit_vec[r]) hit_idx = IW'(r);
  end
  assign lk_hit    = |hit_vec;
  assign lk_idx    = hit_idx;
  assign lk_multi  = (hit_vec & (hit_vec - 1'b1)) != '0;
  assign lk_state  = st_q[hit_idx];
  assign lk_dom    = dom_q[hit_idx];
  assign lk_tier   = tier_q[hit_idx];
  assign lk_perm_r = pr_q[hit_idx];
  assign lk_perm_w = pw_q[hit_idx];
  assign lk_mig    = mig_q[hit_idx];
  assign lk_base   = pva_q[hit_idx];
  assign lk_pgran  = ph_q[hit_idx] + PW'(lk_gran - pva_q[hit_idx]);

  // ------------------------------------------------------------------ overlap query / free slot
  always_comb begin
    ov_any = 1'b0;
    for (int r = 0; r < NR; r++) begin
      if (st_q[r] != sfmp_pkg::RS_FREE) begin
        if (({1'b0, ov_base} < ({1'b0, pva_q[r]} + {{(GA+1-LW){1'b0}}, len_q[r]})) &&
            ({1'b0, pva_q[r]} < ({1'b0, ov_base} + {{(GA+1-LW){1'b0}}, ov_len})))
          ov_any = 1'b1;
      end
    end
  end
  always_comb begin
    fr_vld = 1'b0;
    fr_idx = '0;
    for (int r = NR - 1; r >= 0; r--) if (st_q[r] == sfmp_pkg::RS_FREE) begin fr_vld = 1'b1; fr_idx = IW'(r); end
  end

  // ------------------------------------------------------------------ read ports
  function automatic logic [sfmp_pkg::ENTRY_W-1:0] pack_entry(input logic [IW-1:0] r);
    logic [sfmp_pkg::ENTRY_W-1:0] e;
    e = '0;
    e[sfmp_pkg::E_STATE +: 2]  = st_q[r];
    e[sfmp_pkg::E_TIER]        = tier_q[r];
    e[sfmp_pkg::E_MIG +: 2]    = mig_q[r];
    e[sfmp_pkg::E_DIRTY]       = dirty_q[r];
    e[sfmp_pkg::E_PIN]         = pin_q[r];
    e[sfmp_pkg::E_PR]          = pr_q[r];
    e[sfmp_pkg::E_PW]          = pw_q[r];
    e[sfmp_pkg::E_DOM +: 4]    = dom_q[r];
    e[sfmp_pkg::E_ERR +: 8]    = err_q[r];
    e[sfmp_pkg::E_GEN +: 8]    = gen_q[r];
    e[sfmp_pkg::E_PVA +: GA]   = pva_q[r];
    e[sfmp_pkg::E_LEN +: LW]   = len_q[r];
    e[sfmp_pkg::E_PHYS +: PW]  = ph_q[r];
    e[sfmp_pkg::E_RDEP +: 16]  = rdep_q[r];
    e[sfmp_pkg::E_WREP +: 16]  = wrep_q[r];
    e[sfmp_pkg::E_RDTOT +: 32] = rdtot_q[r];
    e[sfmp_pkg::E_WRTOT +: 32] = wrtot_q[r];
    pack_entry = e;
  endfunction
  assign rd0_ent = pack_entry(rd0_idx);
  assign rd1_ent = pack_entry(rd1_idx);
  assign rd2_ent = pack_entry(rd2_idx);

  genvar gd;
  generate
    for (gd = 0; gd < ND; gd++) begin : g_acc
      assign use_sram[gd*16 +: 16] = use_q[gd];
      assign live_cnt[gd*8 +: 8]   = live_q[gd];
    end
  endgenerate

  // ------------------------------------------------------------------ accounting deltas (one update per domain per cycle)
  // command-engine side
  logic signed [16:0] ct_d;      // SRAM-use delta
  logic [3:0]         ct_d_dom;
  logic signed [8:0]  ct_l;      // live-count delta
  logic [3:0]         ct_l_dom;
  always_comb begin
    ct_d = '0; ct_d_dom = ct_dom; ct_l = '0; ct_l_dom = ct_dom;
    case (ct_op)
      sfmp_pkg::CT_ALLOC: begin
        ct_d_dom = ct_dom; ct_l_dom = ct_dom; ct_l = 9'sd1;
        if (ct_tier == sfmp_pkg::TIER_SRAM) ct_d = $signed({1'b0, 16'(ct_len)});
      end
      sfmp_pkg::CT_RELEASE: begin
        ct_d_dom = dom_q[ct_idx]; ct_l_dom = dom_q[ct_idx]; ct_l = -9'sd1;
        if (tier_q[ct_idx] == sfmp_pkg::TIER_SRAM) ct_d = -$signed({1'b0, 16'(len_q[ct_idx])});
      end
      sfmp_pkg::CT_MIGBEGIN: begin
        ct_d_dom = dom_q[ct_idx];
        if (tier_q[ct_idx] == sfmp_pkg::TIER_DRAM) ct_d = $signed({1'b0, 16'(len_q[ct_idx])});   // promotion reserves SRAM
      end
      default: ;
    endcase
  end
  // migration-engine side
  logic signed [16:0] mg_d;
  logic [3:0]         mg_d_dom;
  always_comb begin
    mg_d = '0; mg_d_dom = dom_q[mg_idx];
    case (mg_op)
      sfmp_pkg::MGO_COMMIT: if (tier_q[mg_idx] == sfmp_pkg::TIER_SRAM) mg_d = -$signed({1'b0, 16'(len_q[mg_idx])});   // demotion done
      sfmp_pkg::MGO_ABORT:  if (tier_q[mg_idx] == sfmp_pkg::TIER_DRAM) mg_d = -$signed({1'b0, 16'(len_q[mg_idx])});   // promotion cancelled
      default: ;
    endcase
  end

  // ------------------------------------------------------------------ state update
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int r = 0; r < NR; r++) begin
        st_q[r] <= sfmp_pkg::RS_FREE; dom_q[r] <= '0; pva_q[r] <= '0; len_q[r] <= '0; tier_q[r] <= 1'b0; ph_q[r] <= '0;
        pr_q[r] <= 1'b0; pw_q[r] <= 1'b0; pin_q[r] <= 1'b0; mig_q[r] <= sfmp_pkg::MG_NONE; dirty_q[r] <= 1'b0; err_q[r] <= '0;
        gen_q[r] <= '0; rdep_q[r] <= '0; wrep_q[r] <= '0; rdtot_q[r] <= '0; wrtot_q[r] <= '0;
      end
      for (int d = 0; d < ND; d++) begin use_q[d] <= '0; live_q[d] <= '0; end
    end else begin
      // ---- access-path counters, dirty, media errors; policy consume
      for (int r = 0; r < NR; r++) begin
        if (ac_valid && ac_idx == IW'(r)) begin
          if (ac_write) begin
            dirty_q[r] <= 1'b1;
            if (wrtot_q[r] != 32'hFFFF_FFFF) wrtot_q[r] <= wrtot_q[r] + 32'd1;
          end else begin
            if (rdtot_q[r] != 32'hFFFF_FFFF) rdtot_q[r] <= rdtot_q[r] + 32'd1;
          end
        end
        if (p_consume && p_idx == IW'(r)) begin
          rdep_q[r] <= (ac_valid && ac_idx == IW'(r) && !ac_write) ? 16'd1 : 16'd0;
          wrep_q[r] <= (ac_valid && ac_idx == IW'(r) &&  ac_write) ? 16'd1 : 16'd0;
        end else if (ac_valid && ac_idx == IW'(r)) begin
          if (ac_write) begin if (wrep_q[r] != 16'hFFFF) wrep_q[r] <= wrep_q[r] + 16'd1; end
          else          begin if (rdep_q[r] != 16'hFFFF) rdep_q[r] <= rdep_q[r] + 16'd1; end
        end
        if (er_valid && er_idx == IW'(r)) err_q[r] <= er_code;
      end

      // ---- migration engine
      case (mg_op)
        sfmp_pkg::MGO_FREEZE: mig_q[mg_idx] <= sfmp_pkg::MG_FROZEN;
        sfmp_pkg::MGO_COMMIT: begin
          tier_q[mg_idx]  <= !tier_q[mg_idx];
          ph_q[mg_idx]    <= mg_phys;
          mig_q[mg_idx]   <= sfmp_pkg::MG_NONE;
          dirty_q[mg_idx] <= 1'b0;
        end
        sfmp_pkg::MGO_ABORT: begin
          mig_q[mg_idx] <= sfmp_pkg::MG_NONE;
          if (mg_err != 8'd0) err_q[mg_idx] <= mg_err;
        end
        default: ;
      endcase

      // ---- command engine
      case (ct_op)
        sfmp_pkg::CT_ALLOC: begin
          st_q[ct_idx] <= sfmp_pkg::RS_SCRUB; dom_q[ct_idx] <= ct_dom; pva_q[ct_idx] <= ct_pva; len_q[ct_idx] <= ct_len;
          tier_q[ct_idx] <= ct_tier; ph_q[ct_idx] <= ct_phys; pr_q[ct_idx] <= ct_perm_r; pw_q[ct_idx] <= ct_perm_w;
          pin_q[ct_idx] <= ct_pin; mig_q[ct_idx] <= sfmp_pkg::MG_NONE; dirty_q[ct_idx] <= 1'b0; err_q[ct_idx] <= '0;
          gen_q[ct_idx] <= gen_q[ct_idx] + 8'd1; rdep_q[ct_idx] <= '0; wrep_q[ct_idx] <= '0; rdtot_q[ct_idx] <= '0; wrtot_q[ct_idx] <= '0;
        end
        sfmp_pkg::CT_ACTIVATE: st_q[ct_idx] <= sfmp_pkg::RS_ACTIVE;
        sfmp_pkg::CT_FREEING:  st_q[ct_idx] <= sfmp_pkg::RS_FREEING;
        sfmp_pkg::CT_RELEASE: begin
          st_q[ct_idx] <= sfmp_pkg::RS_FREE; len_q[ct_idx] <= '0; pin_q[ct_idx] <= 1'b0; mig_q[ct_idx] <= sfmp_pkg::MG_NONE;
          dirty_q[ct_idx] <= 1'b0; pr_q[ct_idx] <= 1'b0; pw_q[ct_idx] <= 1'b0;
        end
        sfmp_pkg::CT_PERM:   begin pr_q[ct_idx] <= ct_perm_r; pw_q[ct_idx] <= ct_perm_w; end
        sfmp_pkg::CT_PIN:    pin_q[ct_idx] <= ct_pin;
        sfmp_pkg::CT_CLRERR: err_q[ct_idx] <= '0;
        sfmp_pkg::CT_MIGBEGIN: mig_q[ct_idx] <= ct_frozen ? sfmp_pkg::MG_FROZEN : sfmp_pkg::MG_PRECOPY;
        default: ;
      endcase

      // ---- per-domain accounting (both sources applied additively)
      for (int d = 0; d < ND; d++) begin
        logic signed [17:0] du;
        logic signed [9:0]  dl;
        du = '0; dl = '0;
        if (ct_d_dom == 4'(d)) du = du + 18'(ct_d);
        if (mg_d_dom == 4'(d)) du = du + 18'(mg_d);
        if (ct_l_dom == 4'(d)) dl = dl + 10'(ct_l);
        use_q[d]  <= 16'(signed'({2'b00, use_q[d]}) + du);
        live_q[d] <= 8'(signed'({2'b00, live_q[d]}) + dl);
      end
    end
  end

endmodule

`default_nettype wire
