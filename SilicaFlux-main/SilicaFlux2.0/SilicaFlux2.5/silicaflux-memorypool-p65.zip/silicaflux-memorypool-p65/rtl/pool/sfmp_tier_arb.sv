// =============================================================================
// MemoryPool :: sfmp_tier_arb -- N masters -> one tier port, round robin, IN-ORDER responses
//
// Every master is an SFB2-style master (valid/ready request, valid/ready response; rules R1..R5,
// R7, R8 of silicaflux-datafabric docs/PROTOCOL.md).  Differences from `sfb_crossbar`, stated
// plainly:
//   * the slave side may have up to MAXOUT transactions outstanding (the crossbar allows one,
//     rule R6).  The tier models (SRAM library, DRAM model, external-memory bridge) all return
//     responses in acceptance order; a small tag FIFO remembers which master owns each response.
//   * the pool's own masters may issue several requests before the first response returns
//     (scrubber, verify reader, tenant dispatcher).  CloudDMA still keeps one outstanding per port.
// Grant lock: a request presented to the slave but not accepted keeps its grant (payload stable,
// R2 at the slave port).  The round-robin pointer moves past the winner on ACCEPTANCE only.
// s_req_valid does not depend on s_req_ready (R3).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfmp_tier_arb #(
  parameter int NM     = 4,
  parameter int DW     = 32,
  parameter int MAXOUT = 4
) (
  input  wire logic                     clk,
  input  wire logic                     rst_n,
  // masters
  input  wire logic [NM-1:0]            m_req_valid,
  output logic      [NM-1:0]            m_req_ready,
  input  wire logic [NM-1:0]            m_req_write,
  input  wire logic [NM*32-1:0]         m_req_addr,
  input  wire logic [NM*DW-1:0]         m_req_wdata,
  input  wire logic [NM*(DW/8)-1:0]     m_req_wstrb,
  output logic      [NM-1:0]            m_rsp_valid,
  input  wire logic [NM-1:0]            m_rsp_ready,
  output logic      [NM*DW-1:0]         m_rsp_rdata,
  output logic      [NM-1:0]            m_rsp_err,
  // slave (the tier)
  output logic                          s_req_valid,
  input  wire logic                     s_req_ready,
  output logic                          s_req_write,
  output logic      [31:0]              s_req_addr,
  output logic      [DW-1:0]            s_req_wdata,
  output logic      [DW/8-1:0]          s_req_wstrb,
  input  wire logic                     s_rsp_valid,
  output logic                          s_rsp_ready,
  input  wire logic [DW-1:0]            s_rsp_rdata,
  input  wire logic                     s_rsp_err,
  // events
  output logic                          ev_slave_stall,   // a request is presented and the tier is not ready
  output logic                          ev_tag_stall,     // requests waiting, outstanding-tag queue full
  output logic      [7:0]               ev_loss           // masters that lost arbitration this cycle
);
  localparam int DWB = DW / 8;
  localparam int IDW = (NM > 1) ? $clog2(NM) : 1;
  localparam int PW  = (MAXOUT > 1) ? $clog2(MAXOUT) : 1;
  localparam int CW  = $clog2(MAXOUT + 1);

  localparam logic [PW-1:0]  LAST_P = PW'(MAXOUT - 1);
  localparam logic [IDW-1:0] LAST_M = IDW'(NM - 1);

  logic [IDW-1:0] tf_q [MAXOUT];
  logic [PW-1:0]  tf_rd_q, tf_wr_q;
  logic [CW-1:0]  tf_cnt_q;
  wire            tf_full  = (tf_cnt_q == CW'(MAXOUT));
  wire            tf_empty = (tf_cnt_q == '0);

  logic [IDW-1:0] ptr_q;
  logic           lock_q;
  logic [NM-1:0]  lock_gnt_q;

  // ---- grant
  logic [NM-1:0]  gnt;
  logic [IDW-1:0] win;
  integer         rr_i;
  always_comb begin
    gnt  = '0;
    win  = '0;
    rr_i = 0;
    if (lock_q) begin
      gnt = lock_gnt_q & m_req_valid;
    end else begin
      for (int k = 0; k < NM; k++) begin
        rr_i = {{(32-IDW){1'b0}}, ptr_q} + k;
        if (rr_i >= NM) rr_i = rr_i - NM;
        if (gnt == '0) begin
          if (m_req_valid[rr_i]) gnt[rr_i] = 1'b1;
        end
      end
    end
    for (int i = 0; i < NM; i++) if (gnt[i]) win = IDW'(i);
  end

  assign s_req_valid = (gnt != '0) && !tf_full;
  wire   acc         = s_req_valid && s_req_ready;
  assign m_req_ready = gnt & {NM{s_req_ready && !tf_full}};

  always_comb begin
    s_req_write = 1'b0;
    s_req_addr  = 32'd0;
    s_req_wdata = '0;
    s_req_wstrb = '0;
    for (int i = 0; i < NM; i++) begin
      if (gnt[i]) begin
        s_req_write = m_req_write[i];
        s_req_addr  = m_req_addr[i*32 +: 32];
        s_req_wdata = m_req_wdata[i*DW +: DW];
        s_req_wstrb = m_req_wstrb[i*DWB +: DWB];
      end
    end
  end

  // ---- response routing
  wire [IDW-1:0] src = tf_q[tf_rd_q];
  always_comb begin
    m_rsp_valid = '0;
    for (int i = 0; i < NM; i++) m_rsp_valid[i] = s_rsp_valid && !tf_empty && (src == IDW'(i));
    m_rsp_rdata = '0;
    m_rsp_err   = '0;
    for (int i = 0; i < NM; i++) begin
      m_rsp_rdata[i*DW +: DW] = s_rsp_rdata;
      m_rsp_err[i]            = s_rsp_err;
    end
  end
  logic src_ready;
  always_comb begin
    src_ready = 1'b0;
    for (int i = 0; i < NM; i++) if (src == IDW'(i)) src_ready = m_rsp_ready[i];
  end
  assign s_rsp_ready = !tf_empty && src_ready;
  wire pop = s_rsp_valid && s_rsp_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tf_rd_q <= '0;
      tf_wr_q <= '0;
      tf_cnt_q <= '0;
      ptr_q   <= '0;
      lock_q  <= 1'b0;
      lock_gnt_q <= '0;
    end else begin
      lock_q     <= s_req_valid && !s_req_ready;
      lock_gnt_q <= gnt;
      if (acc) begin
        tf_q[tf_wr_q] <= win;
        tf_wr_q <= (tf_wr_q == LAST_P) ? '0 : tf_wr_q + 1'b1;
        ptr_q   <= (win == LAST_M) ? '0 : win + 1'b1;
      end
      if (pop) tf_rd_q <= (tf_rd_q == LAST_P) ? '0 : tf_rd_q + 1'b1;
      case ({acc, pop})
        2'b10:   tf_cnt_q <= tf_cnt_q + 1'b1;
        2'b01:   tf_cnt_q <= tf_cnt_q - 1'b1;
        default: tf_cnt_q <= tf_cnt_q;
      endcase
    end
  end

  assign ev_slave_stall = (gnt != '0) && !tf_full && !s_req_ready;
  assign ev_tag_stall   = (m_req_valid != '0) && tf_full;
  always_comb begin
    ev_loss = 8'd0;
    for (int i = 0; i < NM; i++) if (m_req_valid[i] && !gnt[i]) ev_loss = ev_loss + 8'd1;
  end
endmodule

`default_nettype wire
