// =============================================================================
// MemoryPool :: sfmp_sram_tier -- tier 0, the on-chip SRAM
//
// A thin adapter between the pool's tier port (byte address, valid/ready request and in-order
// valid/ready response, one beat per request) and the repository's SRAM Wrapper Library cell
// `sram_sp` (Project 01, vendored unmodified).  BACKEND = GENERIC in simulation; the FPGA and
// ASIC-macro backends are one parameter away (see docs/00_AUDIT.md for SRAMGrid, the banked
// multi-port production candidate, which speaks the same SFB2-style protocol).
//
// `oor_evt` is a tripwire: it pulses if a request carries an address beyond the SRAM.  It cannot
// happen by construction (every address comes from an allocated extent and the DMA guard); the
// pool latches it in R_STICKY so a bug elsewhere cannot go unnoticed.  The access is still
// performed on the masked address, so tier 0 never answers out of range.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sfmp_sram_tier #(
  parameter int DW           = 32,
  parameter int BYTES        = 65536,
  parameter int SRAM_BACKEND = `SRAM_BACKEND_GENERIC
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic                req_valid,
  output logic                     req_ready,
  input  wire logic                req_write,
  input  wire logic [31:0]         req_addr,
  input  wire logic [DW-1:0]       req_wdata,
  input  wire logic [DW/8-1:0]     req_wstrb,
  output logic                     rsp_valid,
  input  wire logic                rsp_ready,
  output logic      [DW-1:0]       rsp_rdata,
  output logic                     rsp_err,
  output logic                     oor_evt
);
  localparam int DWB   = DW / 8;
  localparam int LGB   = $clog2(DWB);
  localparam int DEPTH = BYTES / DWB;
  localparam int AWW   = $clog2(DEPTH);

  wire [AWW-1:0] waddr = req_addr[LGB +: AWW];
  assign oor_evt = req_valid && req_ready && (req_addr[31:LGB+AWW] != '0);

  logic sp_rsp_we;
  logic sp_busy;
  logic sp_rsp_id;
  logic [DW-1:0] sp_tst_rdata;
  sram_sp #(
    .DATA_WIDTH(DW), .DEPTH(DEPTH), .READ_LATENCY(1), .BACKEND(SRAM_BACKEND), .WRITE_ACK(1), .TEST_EN(0)
  ) u_sram (
    .clk, .rst_n,
    .req_valid, .req_ready, .req_we(req_write), .req_addr(waddr), .req_wdata, .req_wmask(req_wstrb), .req_id(1'b0),
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_err, .rsp_we(sp_rsp_we), .rsp_id(sp_rsp_id),
    .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata(sp_tst_rdata),
    .busy(sp_busy)
  );
  wire unused_ok = &{1'b0, sp_rsp_we, sp_busy, sp_rsp_id, sp_tst_rdata, req_addr[LGB-1:0]};
endmodule

`default_nettype wire
