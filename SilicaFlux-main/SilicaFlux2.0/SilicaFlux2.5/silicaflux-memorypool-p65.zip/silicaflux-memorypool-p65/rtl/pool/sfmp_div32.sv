// =============================================================================
// MemoryPool :: sfmp_div32 -- 32-bit unsigned serial (restoring) divider, 32 cycles
// `start` is accepted when !busy; `done` pulses for one cycle with `quo` valid (quotient 0 if den == 0).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfmp_div32 (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        start,
  input  wire logic [31:0] num,
  input  wire logic [31:0] den,
  output logic             busy,
  output logic             done,
  output logic      [31:0] quo
);
  logic        busy_q, done_q;
  logic [5:0]  n_q;
  logic [31:0] q_q, r_q, d_q;
  wire  [32:0] rem_n = {r_q, q_q[31]};                 // 33 bits: correct for any divisor up to 2**32-1
  wire         ge    = (rem_n >= {1'b0, d_q});

  assign busy = busy_q;
  assign done = done_q;
  assign quo  = q_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      busy_q <= 1'b0; done_q <= 1'b0; n_q <= '0; q_q <= '0; r_q <= '0; d_q <= '0;
    end else begin
      done_q <= 1'b0;
      if (!busy_q) begin
        if (start) begin
          if (den == 32'd0) begin q_q <= 32'd0; done_q <= 1'b1; end
          else begin busy_q <= 1'b1; n_q <= 6'd32; q_q <= num; r_q <= '0; d_q <= den; end
        end
      end else begin
        r_q <= ge ? 32'(rem_n - {1'b0, d_q}) : rem_n[31:0];
        q_q <= {q_q[30:0], ge};
        n_q <= n_q - 6'd1;
        if (n_q == 6'd1) begin busy_q <= 1'b0; done_q <= 1'b1; end
      end
    end
  end
endmodule

`default_nettype wire
