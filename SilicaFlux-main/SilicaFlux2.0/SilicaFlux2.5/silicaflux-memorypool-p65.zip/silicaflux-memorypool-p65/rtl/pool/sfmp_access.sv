// =============================================================================
// MemoryPool :: sfmp_access -- client ports, request/response queues, translation, checks, dispatch
//
// CLIENT PORTS.  Ports 0..ND-1 are accelerator ports: port i is hard-bound to one domain by a privileged
// BIND -- the domain of an access is taken from that binding at enqueue time and is never part of the
// request.  Port ND is the HOST-DMA port behind the IOMMU boundary: the domain comes from the IOMMU
// sideband (`hd_dom`) and the request is refused unless the IOMMU asserted `hd_xlat_ok`.
//
// QUEUES.  Every port has a request FIFO (RQ_DEPTH) and a response FIFO (RSP_DEPTH).  A port has at most
// ONE access in flight in the tiers (its next request waits at the FIFO head): responses therefore come
// back in order per port although the tiers have different latencies.  Ports run concurrently.
//
// DISPATCH (stage 1, one decision per cycle).  A round-robin pointer picks the next port whose head is
// eligible (queue non-empty, nothing in flight, room for the response).  The head is checked in this order
//   domain enabled -> not quarantined -> IOMMU ok (host port) -> aligned -> mapped -> owner == domain
//   -> region ACTIVE -> permission (R / W) -> region not FROZEN
// and any failure of the first eight completes immediately with an access fault.  Every client sees the
// same fault code for every cause (no allocation-map side channel); the precise cause goes to the
// management-visible last-fault capture and the per-cause counters.  A region that is FROZEN by a migration
// holds the head (counted as a freeze stall) -- nothing for that region is dispatched while it is frozen.
// A request that passes is committed to a one-entry DISPATCH REGISTER and counted in-flight for its region
// in the same cycle; stage 2 presents it to the tier until accepted (payload stable, SFB2 R2).
//
// MIGRATION COORDINATION.  `infl_nz[r]` tells the migration engine and the command engine when no access to
// region r is outstanding (freeze drain, FREE, commit).  A write that is accepted by the tier while its
// region is being pre-copied raises `mw_*` (region, chunk) AT THE TIER HANDSHAKE -- the same cycle the write
// is ordered ahead of any later migration DMA read -- so the dirty bit can never be set too early.
//
// COUNTERS.  Everything is counted at a real event: completions for accesses/bytes/latency, handshakes for
// queue stalls.  Latency = cycles from enqueue to the cycle the response is placed in the response queue.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfmp_access #(
  parameter int NPT       = 5,      // client ports = ND accelerator ports + 1 host-DMA port
  parameter int ND        = 4,
  parameter int NR        = 32,
  parameter int DW        = 32,
  parameter int GRAN_LG   = 8,
  parameter int POOL_AW   = 28,
  parameter int GA        = 20,
  parameter int PW        = 10,
  parameter int LW        = 7,
  parameter int RQ_DEPTH  = 4,
  parameter int RSP_DEPTH = 2,
  parameter int CHUNK_LG  = 6,
  parameter int CW        = 9       // chunk-index width = LW + GRAN_LG - CHUNK_LG
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // ---- client ports (flat)
  input  wire logic [NPT-1:0]         c_req_valid,
  output logic      [NPT-1:0]         c_req_ready,
  input  wire logic [NPT-1:0]         c_req_write,
  input  wire logic [NPT*32-1:0]      c_req_addr,
  input  wire logic [NPT*DW-1:0]      c_req_wdata,
  input  wire logic [NPT*(DW/8)-1:0]  c_req_wstrb,
  output logic      [NPT-1:0]         c_rsp_valid,
  input  wire logic [NPT-1:0]         c_rsp_ready,
  output logic      [NPT*DW-1:0]      c_rsp_rdata,
  output logic      [NPT-1:0]         c_rsp_err,
  output logic      [NPT*8-1:0]       c_rsp_code,
  // ---- IOMMU boundary sideband for the host-DMA port (port NPT-1), sampled with its request
  input  wire logic [3:0]             hd_dom,
  input  wire logic                   hd_xlat_ok,
  // ---- domain control state
  input  wire logic [ND-1:0]          dom_en,
  input  wire logic [ND-1:0]          dom_quar,
  input  wire logic [ND-1:0]          dom_autoq,
  input  wire logic [ND*4-1:0]        bind_dom,        // domain of accelerator port i
  output logic      [ND-1:0]          quar_set,
  output logic      [NPT-1:0]         port_idle,
  // ---- region table lookup
  output logic      [GA-1:0]          lk_gran,
  input  wire logic                   lk_hit,
  input  wire logic [$clog2(NR)-1:0]  lk_idx,
  input  wire logic [PW-1:0]          lk_pgran,
  input  wire logic [1:0]             lk_state,
  input  wire logic [3:0]             lk_dom,
  input  wire logic                   lk_tier,
  input  wire logic                   lk_perm_r,
  input  wire logic                   lk_perm_w,
  input  wire logic [1:0]             lk_mig,
  input  wire logic [GA-1:0]          lk_base,
  input  wire logic                   lk_multi,
  // ---- region table events
  output logic                        ac_valid,
  output logic      [$clog2(NR)-1:0]  ac_idx,
  output logic                        ac_write,
  output logic                        er_valid,
  output logic      [$clog2(NR)-1:0]  er_idx,
  output logic      [7:0]             er_code,
  // ---- migration coordination
  output logic      [NR-1:0]          infl_nz,
  output logic                        mw_valid,
  output logic      [$clog2(NR)-1:0]  mw_idx,
  output logic      [CW-1:0]          mw_chunk,
  // ---- tier ports (master 0 of each tier arbiter)
  output logic                        t0_req_valid,
  input  wire logic                   t0_req_ready,
  output logic                        t0_req_write,
  output logic      [31:0]            t0_req_addr,
  output logic      [DW-1:0]          t0_req_wdata,
  output logic      [DW/8-1:0]        t0_req_wstrb,
  input  wire logic                   t0_rsp_valid,
  output logic                        t0_rsp_ready,
  input  wire logic [DW-1:0]          t0_rsp_rdata,
  input  wire logic                   t0_rsp_err,
  output logic                        t1_req_valid,
  input  wire logic                   t1_req_ready,
  output logic                        t1_req_write,
  output logic      [31:0]            t1_req_addr,
  output logic      [DW-1:0]          t1_req_wdata,
  output logic      [DW/8-1:0]        t1_req_wstrb,
  input  wire logic                   t1_rsp_valid,
  output logic                        t1_rsp_ready,
  input  wire logic [DW-1:0]          t1_rsp_rdata,
  input  wire logic                   t1_rsp_err,
  // ---- telemetry (increments, one slice per counter; unused slices are zero)
  output logic      [sfmp_pkg::NG*32-1:0]            inc_g,
  output logic      [ND*sfmp_pkg::NDC*32-1:0]        inc_d,
  output logic      [31:0]                           lat_max_g,
  output logic      [ND*32-1:0]                      lat_max_d,
  // ---- last access fault (management visible)
  output logic                        lf_valid,
  output logic      [3:0]             lf_cause,
  output logic      [3:0]             lf_port,
  output logic      [3:0]             lf_dom,
  output logic                        lf_write,
  output logic      [31:0]            lf_addr,
  // ---- RAS
  output logic                        ev_media,
  output logic      [31:0]            ev_media_addr,
  output logic                        inv_evt
);
  if (GA != POOL_AW - GRAN_LG) begin : g_err_ga
    $fatal(1, "sfmp_access: GA must equal POOL_AW - GRAN_LG");
  end
  if (RQ_DEPTH < 2 || RSP_DEPTH < 2) begin : g_err_depth
    $fatal(1, "sfmp_access: RQ_DEPTH and RSP_DEPTH must be >= 2");
  end
  localparam int DWB  = DW / 8;
  localparam int LGB  = $clog2(DWB);
  localparam int IW   = $clog2(NR);
  localparam int PIW  = $clog2(NPT);
  localparam int RQW  = $clog2(RQ_DEPTH);
  localparam int RSW  = $clog2(RSP_DEPTH);
  localparam int CTXD = NPT + 1;
  localparam int CXW  = $clog2(CTXD);
  localparam logic [PIW-1:0] LAST_PORT = PIW'(NPT - 1);

  // ------------------------------------------------------------------ time
  logic [31:0] now_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) now_q <= 32'd0;
    else        now_q <= now_q + 32'd1;
  end

  // ------------------------------------------------------------------ request FIFOs
  logic         rq_w   [NPT][RQ_DEPTH];
  logic [31:0]  rq_a   [NPT][RQ_DEPTH];
  logic [DW-1:0] rq_d  [NPT][RQ_DEPTH];
  logic [DWB-1:0] rq_s [NPT][RQ_DEPTH];
  logic [3:0]   rq_dom [NPT][RQ_DEPTH];
  logic         rq_xok [NPT][RQ_DEPTH];
  logic [31:0]  rq_t   [NPT][RQ_DEPTH];
  logic [RQW-1:0] rq_rd_q [NPT];
  logic [RQW-1:0] rq_wr_q [NPT];
  logic [RQW:0]   rq_cnt_q [NPT];
  // response FIFOs
  logic [DW-1:0] rs_d  [NPT][RSP_DEPTH];
  logic          rs_e  [NPT][RSP_DEPTH];
  logic [7:0]    rs_c  [NPT][RSP_DEPTH];
  logic [RSW-1:0] rs_rd_q [NPT];
  logic [RSW-1:0] rs_wr_q [NPT];
  logic [RSW:0]   rs_cnt_q [NPT];
  logic [NPT-1:0] infl_q;

  localparam logic [RQW-1:0] RQ_LAST = RQW'(RQ_DEPTH - 1);
  localparam logic [RSW-1:0] RS_LAST = RSW'(RSP_DEPTH - 1);

  // ---- enqueue
  always_comb begin
    for (int p = 0; p < NPT; p++) c_req_ready[p] = (rq_cnt_q[p] != (RQW+1)'(RQ_DEPTH));
  end
  wire [NPT-1:0] enq = c_req_valid & c_req_ready;

  // ---- responses to the clients
  always_comb begin
    for (int p = 0; p < NPT; p++) begin
      c_rsp_valid[p]            = (rs_cnt_q[p] != '0);
      c_rsp_rdata[p*DW +: DW]   = rs_d[p][rs_rd_q[p]];
      c_rsp_err[p]              = rs_e[p][rs_rd_q[p]];
      c_rsp_code[p*8 +: 8]      = rs_c[p][rs_rd_q[p]];
    end
  end
  wire [NPT-1:0] rsp_pop = c_rsp_valid & c_rsp_ready;

  always_comb begin
    for (int p = 0; p < NPT; p++) port_idle[p] = (rq_cnt_q[p] == '0) && !infl_q[p] && (rs_cnt_q[p] == '0);
  end

  // ------------------------------------------------------------------ stage 1: selection
  logic [PIW-1:0] ptr_q;
  logic [NPT-1:0] elig;
  always_comb begin
    for (int p = 0; p < NPT; p++) elig[p] = (rq_cnt_q[p] != '0) && !infl_q[p] && (rs_cnt_q[p] != (RSW+1)'(RSP_DEPTH));
  end
  logic           sel_v;
  logic [PIW-1:0] sel;
  integer         sel_i;
  always_comb begin
    sel_v = 1'b0;
    sel   = '0;
    sel_i = 0;
    for (int k = 1; k <= NPT; k++) begin
      sel_i = {{(32-PIW){1'b0}}, ptr_q} + k;
      if (sel_i >= NPT) sel_i = sel_i - NPT;
      if (!sel_v && elig[sel_i]) begin sel_v = 1'b1; sel = PIW'(sel_i); end
    end
  end

  // head entry of the selected port
  logic         h_w;
  logic [31:0]  h_a;
  logic [DW-1:0] h_d;
  logic [DWB-1:0] h_s;
  logic [3:0]   h_dom;
  logic         h_xok;
  logic [31:0]  h_t;
  always_comb begin
    h_w = 1'b0; h_a = '0; h_d = '0; h_s = '0; h_dom = '0; h_xok = 1'b0; h_t = '0;
    for (int p = 0; p < NPT; p++) begin
      if (sel == PIW'(p)) begin
        h_w = rq_w[p][rq_rd_q[p]]; h_a = rq_a[p][rq_rd_q[p]]; h_d = rq_d[p][rq_rd_q[p]]; h_s = rq_s[p][rq_rd_q[p]];
        h_dom = rq_dom[p][rq_rd_q[p]]; h_xok = rq_xok[p][rq_rd_q[p]]; h_t = rq_t[p][rq_rd_q[p]];
      end
    end
  end

  // ------------------------------------------------------------------ stage 1: checks
  wire         is_host   = (sel == LAST_PORT);
  wire         dom_vld   = (h_dom < 4'(ND));
  logic        d_en, d_quar, d_autoq;
  always_comb begin
    d_en = 1'b0; d_quar = 1'b0; d_autoq = 1'b0;
    for (int d = 0; d < ND; d++) if (h_dom == 4'(d)) begin d_en = dom_en[d]; d_quar = dom_quar[d]; d_autoq = dom_autoq[d]; end
  end
  wire         bad_addr  = (h_a[LGB-1:0] != '0) || (h_a[31:POOL_AW] != '0);
  assign       lk_gran   = h_a[POOL_AW-1:GRAN_LG];

  logic [3:0]  cause;
  always_comb begin
    cause = sfmp_pkg::FC_NONE;
    if (!dom_vld || !d_en)                       cause = sfmp_pkg::FC_DOMAIN;
    else if (d_quar)                             cause = sfmp_pkg::FC_QUAR;
    else if (is_host && !h_xok)                  cause = sfmp_pkg::FC_IOMMU;
    else if (bad_addr)                           cause = sfmp_pkg::FC_ALIGN;
    else if (!lk_hit)                            cause = sfmp_pkg::FC_UNMAPPED;
    else if (lk_dom != h_dom)                    cause = sfmp_pkg::FC_XTENANT;
    else if (lk_state != sfmp_pkg::RS_ACTIVE)    cause = sfmp_pkg::FC_STATE;
    else if (h_w ? !lk_perm_w : !lk_perm_r)      cause = sfmp_pkg::FC_PERM;
  end
  wire fault      = sel_v && (cause != sfmp_pkg::FC_NONE);
  wire frozen_blk = sel_v && !fault && (lk_mig == sfmp_pkg::MG_FROZEN);

  // dispatch register
  logic          pv_q;                  // valid
  logic          pv_w;
  logic          pv_t;                  // tier
  logic [31:0]   pv_a;
  logic [DW-1:0] pv_d;
  logic [DWB-1:0] pv_s;
  wire           pend_acc = pv_q && (pv_t ? t1_req_ready : t0_req_ready);
  wire           pend_free = !pv_q || pend_acc;
  wire           commit  = sel_v && !fault && !frozen_blk && pend_free;
  wire           pop_sel = fault || commit;
  logic [31:0]   phys_a;
  assign phys_a = {{(32-PW-GRAN_LG){1'b0}}, lk_pgran, h_a[GRAN_LG-1:0]};

  assign t0_req_valid = pv_q && !pv_t;
  assign t1_req_valid = pv_q &&  pv_t;
  assign t0_req_write = pv_w;  assign t1_req_write = pv_w;
  assign t0_req_addr  = pv_a;  assign t1_req_addr  = pv_a;
  assign t0_req_wdata = pv_d;  assign t1_req_wdata = pv_d;
  assign t0_req_wstrb = pv_s;  assign t1_req_wstrb = pv_s;

  // per-dispatch context kept until the response (tier-ordered), as one flat vector
  localparam int C_PORT = 0;
  localparam int C_REG  = C_PORT + PIW;
  localparam int C_WR   = C_REG + IW;
  localparam int C_NS   = C_WR + 1;          // popcount of the write strobes (bytes written)
  localparam int C_DOM  = C_NS + 4;
  localparam int C_TENQ = C_DOM + 4;
  localparam int C_ADDR = C_TENQ + 32;       // PVA
  localparam int CTXW   = C_ADDR + 32;
  logic [CTXW-1:0] pv_ctx_q;
  logic [CTXW-1:0] cq0 [CTXD];
  logic [CTXW-1:0] cq1 [CTXD];
  logic [CXW-1:0] cq0_rd_q, cq0_wr_q, cq1_rd_q, cq1_wr_q;
  logic [CXW:0]   cq0_cnt_q, cq1_cnt_q;
  localparam logic [CXW-1:0] CQ_LAST = CXW'(CTXD - 1);

  function automatic logic [3:0] popc(input logic [DWB-1:0] s);
    logic [3:0] n;
    n = 4'd0;
    for (int b = 0; b < DWB; b++) n = n + {3'b000, s[b]};
    popc = n;
  endfunction

  // ------------------------------------------------------------------ tier responses
  wire         r0_v = t0_rsp_valid && (cq0_cnt_q != '0);
  wire         r1_v = t1_rsp_valid && (cq1_cnt_q != '0);
  wire [CTXW-1:0] r0_c = cq0[cq0_rd_q];
  wire [CTXW-1:0] r1_c = cq1[cq1_rd_q];
  wire [PIW-1:0]  r0_port = r0_c[C_PORT +: PIW];
  wire [IW-1:0]   r0_reg  = r0_c[C_REG +: IW];
  wire            r0_wr   = r0_c[C_WR];
  wire [3:0]      r0_ns   = r0_c[C_NS +: 4];
  wire [3:0]      r0_dom  = r0_c[C_DOM +: 4];
  wire [31:0]     r0_tenq = r0_c[C_TENQ +: 32];
  wire [31:0]     r0_addr = r0_c[C_ADDR +: 32];
  wire [PIW-1:0]  r1_port = r1_c[C_PORT +: PIW];
  wire [IW-1:0]   r1_reg  = r1_c[C_REG +: IW];
  wire            r1_wr   = r1_c[C_WR];
  wire [3:0]      r1_ns   = r1_c[C_NS +: 4];
  wire [3:0]      r1_dom  = r1_c[C_DOM +: 4];
  wire [31:0]     r1_tenq = r1_c[C_TENQ +: 32];
  wire [31:0]     r1_addr = r1_c[C_ADDR +: 32];
  wire [IW-1:0]   pv_reg  = pv_ctx_q[C_REG +: IW];
  wire            pv_wr   = pv_ctx_q[C_WR];
  wire [31:0]     pv_addr = pv_ctx_q[C_ADDR +: 32];
  assign t0_rsp_ready = (cq0_cnt_q != '0);
  assign t1_rsp_ready = (cq1_cnt_q != '0);

  // ------------------------------------------------------------------ in-flight counters per region
  logic [3:0] infl_cnt_q [NR];
  always_comb begin
    for (int r = 0; r < NR; r++) infl_nz[r] = (infl_cnt_q[r] != 4'd0);
  end

  // ------------------------------------------------------------------ sequential state
  logic [31:0] lat0, lat1;
  assign lat0 = now_q - r0_tenq;
  assign lat1 = now_q - r1_tenq;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int p = 0; p < NPT; p++) begin
        rq_rd_q[p] <= '0; rq_wr_q[p] <= '0; rq_cnt_q[p] <= '0; rs_rd_q[p] <= '0; rs_wr_q[p] <= '0; rs_cnt_q[p] <= '0;
      end
      infl_q <= '0; ptr_q <= '0; pv_q <= 1'b0; pv_w <= 1'b0; pv_t <= 1'b0; pv_a <= '0; pv_d <= '0; pv_s <= '0; pv_ctx_q <= '0;
      cq0_rd_q <= '0; cq0_wr_q <= '0; cq0_cnt_q <= '0; cq1_rd_q <= '0; cq1_wr_q <= '0; cq1_cnt_q <= '0;
      for (int r = 0; r < NR; r++) infl_cnt_q[r] <= 4'd0;
    end else begin
      if (sel_v) ptr_q <= sel;

      // ---- request enqueue
      for (int p = 0; p < NPT; p++) begin
        if (enq[p]) begin
          rq_w[p][rq_wr_q[p]]   <= c_req_write[p];
          rq_a[p][rq_wr_q[p]]   <= c_req_addr[p*32 +: 32];
          rq_d[p][rq_wr_q[p]]   <= c_req_wdata[p*DW +: DW];
          rq_s[p][rq_wr_q[p]]   <= c_req_wstrb[p*DWB +: DWB];
          rq_dom[p][rq_wr_q[p]] <= (p == NPT - 1) ? hd_dom : bind_dom[(p < ND ? p : 0)*4 +: 4];
          rq_xok[p][rq_wr_q[p]] <= (p == NPT - 1) ? hd_xlat_ok : 1'b1;
          rq_t[p][rq_wr_q[p]]   <= now_q;
          rq_wr_q[p] <= (rq_wr_q[p] == RQ_LAST) ? '0 : rq_wr_q[p] + 1'b1;
        end
        if (pop_sel && sel == PIW'(p)) rq_rd_q[p] <= (rq_rd_q[p] == RQ_LAST) ? '0 : rq_rd_q[p] + 1'b1;
        case ({enq[p], pop_sel && sel == PIW'(p)})
          2'b10:   rq_cnt_q[p] <= rq_cnt_q[p] + 1'b1;
          2'b01:   rq_cnt_q[p] <= rq_cnt_q[p] - 1'b1;
          default: rq_cnt_q[p] <= rq_cnt_q[p];
        endcase
      end

      // ---- dispatch register
      if (pend_acc) pv_q <= 1'b0;
      if (commit) begin
        pv_q <= 1'b1; pv_w <= h_w; pv_t <= lk_tier; pv_a <= phys_a; pv_d <= h_d; pv_s <= h_s;
        pv_ctx_q <= {h_a, h_t, h_dom, popc(h_s), h_w, lk_idx, sel};
        infl_q[sel] <= 1'b1;
      end
      // tier handshake: remember the context in tier order
      if (pend_acc) begin
        if (!pv_t) begin cq0[cq0_wr_q] <= pv_ctx_q; cq0_wr_q <= (cq0_wr_q == CQ_LAST) ? '0 : cq0_wr_q + 1'b1; end
        else       begin cq1[cq1_wr_q] <= pv_ctx_q; cq1_wr_q <= (cq1_wr_q == CQ_LAST) ? '0 : cq1_wr_q + 1'b1; end
      end
      case ({pend_acc && !pv_t, r0_v})
        2'b10:   cq0_cnt_q <= cq0_cnt_q + 1'b1;
        2'b01:   cq0_cnt_q <= cq0_cnt_q - 1'b1;
        default: cq0_cnt_q <= cq0_cnt_q;
      endcase
      case ({pend_acc && pv_t, r1_v})
        2'b10:   cq1_cnt_q <= cq1_cnt_q + 1'b1;
        2'b01:   cq1_cnt_q <= cq1_cnt_q - 1'b1;
        default: cq1_cnt_q <= cq1_cnt_q;
      endcase
      if (r0_v) cq0_rd_q <= (cq0_rd_q == CQ_LAST) ? '0 : cq0_rd_q + 1'b1;
      if (r1_v) cq1_rd_q <= (cq1_rd_q == CQ_LAST) ? '0 : cq1_rd_q + 1'b1;

      // ---- responses: tier 0, tier 1 and immediate faults write the response FIFOs
      begin : rsp_push
        logic [NPT-1:0] push;
        logic [DW-1:0]  pd [NPT];
        logic           pe [NPT];
        logic [7:0]     pc [NPT];
        push = '0;
        for (int p = 0; p < NPT; p++) begin pd[p] = '0; pe[p] = 1'b0; pc[p] = sfmp_pkg::CE_NONE; end
        if (r0_v) begin
          push[r0_port] = 1'b1; pd[r0_port] = t0_rsp_err ? '0 : t0_rsp_rdata; pe[r0_port] = t0_rsp_err;
          pc[r0_port] = t0_rsp_err ? sfmp_pkg::CE_MEDIA : sfmp_pkg::CE_NONE;
          infl_q[r0_port] <= 1'b0;
        end
        if (r1_v) begin
          push[r1_port] = 1'b1; pd[r1_port] = t1_rsp_err ? '0 : t1_rsp_rdata; pe[r1_port] = t1_rsp_err;
          pc[r1_port] = t1_rsp_err ? sfmp_pkg::CE_MEDIA : sfmp_pkg::CE_NONE;
          infl_q[r1_port] <= 1'b0;
        end
        if (fault) begin
          push[sel] = 1'b1; pd[sel] = '0; pe[sel] = 1'b1; pc[sel] = sfmp_pkg::CE_FAULT;
        end
        for (int p = 0; p < NPT; p++) begin
          if (push[p]) begin
            rs_d[p][rs_wr_q[p]] <= pd[p]; rs_e[p][rs_wr_q[p]] <= pe[p]; rs_c[p][rs_wr_q[p]] <= pc[p];
            rs_wr_q[p] <= (rs_wr_q[p] == RS_LAST) ? '0 : rs_wr_q[p] + 1'b1;
          end
          if (rsp_pop[p]) rs_rd_q[p] <= (rs_rd_q[p] == RS_LAST) ? '0 : rs_rd_q[p] + 1'b1;
          case ({push[p], rsp_pop[p]})
            2'b10:   rs_cnt_q[p] <= rs_cnt_q[p] + 1'b1;
            2'b01:   rs_cnt_q[p] <= rs_cnt_q[p] - 1'b1;
            default: rs_cnt_q[p] <= rs_cnt_q[p];
          endcase
        end
      end

      // ---- per-region in-flight counters
      for (int r = 0; r < NR; r++) begin
        logic [3:0] n;
        n = infl_cnt_q[r];
        if (commit && lk_idx == IW'(r)) n = n + 4'd1;
        if (r0_v && r0_reg == IW'(r)) n = n - 4'd1;
        if (r1_v && r1_reg == IW'(r)) n = n - 4'd1;
        infl_cnt_q[r] <= n;
      end
    end
  end

  // ------------------------------------------------------------------ events to the region table / migration engine
  assign ac_valid = pend_acc;                 // the access is ordered at the tier now; table counts it, sets dirty
  assign ac_idx   = pv_reg;
  assign ac_write = pv_wr;
  // migration dirty tracking: EVERY write handshaken at the tier is reported (region, chunk) in the cycle it
  // is ordered at the tier; the migration engine filters by its own region and phase.  A write that stage 1
  // committed before a freeze is already counted in flight, so the engine is still draining it and still
  // receives its event.
  assign mw_valid = pend_acc && pv_wr;
  assign mw_idx   = pv_reg;
  // chunk index of the written word inside its region = (byte offset in region) >> CHUNK_LG.
  // The region's PVA base is captured at commit time, together with the rest of the dispatch context.
  logic [GA-1:0] pv_base_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)       pv_base_q <= '0;
    else if (commit)  pv_base_q <= lk_base;
  end
  wire [GA-1:0] pv_gran_off = pv_addr[POOL_AW-1:GRAN_LG] - pv_base_q;
  assign mw_chunk = {pv_gran_off[LW-1:0], pv_addr[GRAN_LG-1:CHUNK_LG]};

  assign er_valid = (r0_v && t0_rsp_err) || (r1_v && t1_rsp_err);
  assign er_idx   = (r0_v && t0_rsp_err) ? r0_reg : r1_reg;
  assign er_code  = sfmp_pkg::RE_MEDIA;
  assign ev_media = er_valid;
  assign ev_media_addr = (r0_v && t0_rsp_err) ? r0_addr : r1_addr;

  // ------------------------------------------------------------------ quarantine, last fault, tripwire
  logic viol_cause;
  assign viol_cause = (cause == sfmp_pkg::FC_XTENANT) || (cause == sfmp_pkg::FC_PERM) || (cause == sfmp_pkg::FC_IOMMU);
  always_comb begin
    quar_set = '0;
    for (int d = 0; d < ND; d++) if (fault && viol_cause && d_autoq && h_dom == 4'(d)) quar_set[d] = 1'b1;
  end
  assign inv_evt = sel_v && lk_multi;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      lf_valid <= 1'b0; lf_cause <= '0; lf_port <= '0; lf_dom <= '0; lf_write <= 1'b0; lf_addr <= '0;
    end else if (fault) begin
      lf_valid <= 1'b1; lf_cause <= cause; lf_port <= 4'(sel); lf_dom <= h_dom; lf_write <= h_w; lf_addr <= h_a;
    end
  end

  // ------------------------------------------------------------------ telemetry
  logic [31:0] lm_g;
  logic [31:0] lm_d [ND];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      lm_g <= '0;
      for (int d = 0; d < ND; d++) lm_d[d] <= '0;
    end else begin
      if (r0_v && lat0 > lm_g) lm_g <= lat0;
      if (r1_v && lat1 > lm_g) lm_g <= lat1;
      for (int d = 0; d < ND; d++) begin
        if (r0_v && r0_dom == 4'(d) && lat0 > lm_d[d]) lm_d[d] <= lat0;
        if (r1_v && r1_dom == 4'(d) && lat1 > lm_d[d]) lm_d[d] <= lat1;
      end
    end
  end
  assign lat_max_g = lm_g;
  always_comb begin
    for (int d = 0; d < ND; d++) lat_max_d[d*32 +: 32] = lm_d[d];
  end

  // held heads: eligible ports not served this cycle
  logic [3:0] held;
  always_comb begin
    held = 4'd0;
    for (int p = 0; p < NPT; p++) if (elig[p] && !(pop_sel && sel == PIW'(p))) held = held + 4'd1;
  end

  always_comb begin
    inc_g = '0;
    inc_d = '0;
    // ---- completions (tier 0 and tier 1 may both complete this cycle)
    if (r0_v) begin
      inc_g[sfmp_pkg::G_LAT_SUM*32 +: 32] = inc_g[sfmp_pkg::G_LAT_SUM*32 +: 32] + lat0;
      inc_g[sfmp_pkg::G_LAT_CNT*32 +: 32] = inc_g[sfmp_pkg::G_LAT_CNT*32 +: 32] + 32'd1;
      inc_g[sfmp_pkg::G_LAT_SUM_T0*32 +: 32] = inc_g[sfmp_pkg::G_LAT_SUM_T0*32 +: 32] + lat0;
      inc_g[sfmp_pkg::G_LAT_CNT_T0*32 +: 32] = inc_g[sfmp_pkg::G_LAT_CNT_T0*32 +: 32] + 32'd1;
      for (int d = 0; d < ND; d++) if (r0_dom == 4'(d)) begin
        inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_LAT_SUM)*32 +: 32] = inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_LAT_SUM)*32 +: 32] + lat0;
        inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_LAT_CNT)*32 +: 32] = inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_LAT_CNT)*32 +: 32] + 32'd1;
      end
      if (t0_rsp_err) begin
        inc_g[sfmp_pkg::G_MEDIA_ERR*32 +: 32] = inc_g[sfmp_pkg::G_MEDIA_ERR*32 +: 32] + 32'd1;
      end else begin
        inc_g[sfmp_pkg::G_ACC*32 +: 32]      = inc_g[sfmp_pkg::G_ACC*32 +: 32] + 32'd1;
        inc_g[sfmp_pkg::G_ACC_T0*32 +: 32]   = inc_g[sfmp_pkg::G_ACC_T0*32 +: 32] + 32'd1;
        if (r0_wr) inc_g[sfmp_pkg::G_ACC_WR*32 +: 32] = inc_g[sfmp_pkg::G_ACC_WR*32 +: 32] + 32'd1;
        else         inc_g[sfmp_pkg::G_ACC_RD*32 +: 32] = inc_g[sfmp_pkg::G_ACC_RD*32 +: 32] + 32'd1;
        inc_g[(r0_wr ? sfmp_pkg::G_BYTES_WR : sfmp_pkg::G_BYTES_RD)*32 +: 32] =
          inc_g[(r0_wr ? sfmp_pkg::G_BYTES_WR : sfmp_pkg::G_BYTES_RD)*32 +: 32] + (r0_wr ? {28'd0, r0_ns} : 32'(DWB));
        inc_g[sfmp_pkg::G_BYTES_T0*32 +: 32] = inc_g[sfmp_pkg::G_BYTES_T0*32 +: 32] + (r0_wr ? {28'd0, r0_ns} : 32'(DWB));
        for (int d = 0; d < ND; d++) if (r0_dom == 4'(d)) begin
          inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_ACC)*32 +: 32]    = inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_ACC)*32 +: 32] + 32'd1;
          inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_ACC_T0)*32 +: 32] = inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_ACC_T0)*32 +: 32] + 32'd1;
          inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_BYTES)*32 +: 32]  = inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_BYTES)*32 +: 32] + (r0_wr ? {28'd0, r0_ns} : 32'(DWB));
        end
      end
    end
    if (r1_v) begin
      inc_g[sfmp_pkg::G_LAT_SUM*32 +: 32] = inc_g[sfmp_pkg::G_LAT_SUM*32 +: 32] + lat1;
      inc_g[sfmp_pkg::G_LAT_CNT*32 +: 32] = inc_g[sfmp_pkg::G_LAT_CNT*32 +: 32] + 32'd1;
      inc_g[sfmp_pkg::G_LAT_SUM_T1*32 +: 32] = inc_g[sfmp_pkg::G_LAT_SUM_T1*32 +: 32] + lat1;
      inc_g[sfmp_pkg::G_LAT_CNT_T1*32 +: 32] = inc_g[sfmp_pkg::G_LAT_CNT_T1*32 +: 32] + 32'd1;
      for (int d = 0; d < ND; d++) if (r1_dom == 4'(d)) begin
        inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_LAT_SUM)*32 +: 32] = inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_LAT_SUM)*32 +: 32] + lat1;
        inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_LAT_CNT)*32 +: 32] = inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_LAT_CNT)*32 +: 32] + 32'd1;
      end
      if (t1_rsp_err) begin
        inc_g[sfmp_pkg::G_MEDIA_ERR*32 +: 32] = inc_g[sfmp_pkg::G_MEDIA_ERR*32 +: 32] + 32'd1;
      end else begin
        inc_g[sfmp_pkg::G_ACC*32 +: 32]      = inc_g[sfmp_pkg::G_ACC*32 +: 32] + 32'd1;
        inc_g[sfmp_pkg::G_ACC_T1*32 +: 32]   = inc_g[sfmp_pkg::G_ACC_T1*32 +: 32] + 32'd1;
        if (r1_wr) inc_g[sfmp_pkg::G_ACC_WR*32 +: 32] = inc_g[sfmp_pkg::G_ACC_WR*32 +: 32] + 32'd1;
        else         inc_g[sfmp_pkg::G_ACC_RD*32 +: 32] = inc_g[sfmp_pkg::G_ACC_RD*32 +: 32] + 32'd1;
        inc_g[(r1_wr ? sfmp_pkg::G_BYTES_WR : sfmp_pkg::G_BYTES_RD)*32 +: 32] =
          inc_g[(r1_wr ? sfmp_pkg::G_BYTES_WR : sfmp_pkg::G_BYTES_RD)*32 +: 32] + (r1_wr ? {28'd0, r1_ns} : 32'(DWB));
        inc_g[sfmp_pkg::G_BYTES_T1*32 +: 32] = inc_g[sfmp_pkg::G_BYTES_T1*32 +: 32] + (r1_wr ? {28'd0, r1_ns} : 32'(DWB));
        for (int d = 0; d < ND; d++) if (r1_dom == 4'(d)) begin
          inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_ACC)*32 +: 32]    = inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_ACC)*32 +: 32] + 32'd1;
          inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_ACC_T1)*32 +: 32] = inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_ACC_T1)*32 +: 32] + 32'd1;
          inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_BYTES)*32 +: 32]  = inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_BYTES)*32 +: 32] + (r1_wr ? {28'd0, r1_ns} : 32'(DWB));
        end
      end
    end
    // ---- faults
    if (fault) begin
      inc_g[sfmp_pkg::G_REJECT*32 +: 32] = 32'd1;
      if (viol_cause) inc_g[sfmp_pkg::G_VIOL*32 +: 32] = 32'd1;
      case (cause)
        sfmp_pkg::FC_UNMAPPED: inc_g[sfmp_pkg::G_F_UNMAPPED*32 +: 32] = 32'd1;
        sfmp_pkg::FC_XTENANT:  inc_g[sfmp_pkg::G_F_XTENANT*32 +: 32]  = 32'd1;
        sfmp_pkg::FC_PERM:     inc_g[sfmp_pkg::G_F_PERM*32 +: 32]     = 32'd1;
        sfmp_pkg::FC_STATE:    inc_g[sfmp_pkg::G_F_STATE*32 +: 32]    = 32'd1;
        sfmp_pkg::FC_QUAR:     inc_g[sfmp_pkg::G_F_QUAR*32 +: 32]     = 32'd1;
        sfmp_pkg::FC_IOMMU:    inc_g[sfmp_pkg::G_F_IOMMU*32 +: 32]    = 32'd1;
        sfmp_pkg::FC_ALIGN:    inc_g[sfmp_pkg::G_F_ALIGN*32 +: 32]    = 32'd1;
        sfmp_pkg::FC_DOMAIN:   inc_g[sfmp_pkg::G_F_DOMAIN*32 +: 32]   = 32'd1;
        default: ;
      endcase
      for (int d = 0; d < ND; d++) if (h_dom == 4'(d)) begin
        inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_REJECT)*32 +: 32] = 32'd1;
        if (viol_cause) inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_VIOL)*32 +: 32] = 32'd1;
      end
    end
    // ---- queue stalls
    begin : stalls
      logic [3:0] qf;
      qf = 4'd0;
      for (int p = 0; p < NPT; p++) if (c_req_valid[p] && !c_req_ready[p]) qf = qf + 4'd1;
      inc_g[sfmp_pkg::G_QFULL*32 +: 32]   = {28'd0, qf};
      inc_g[sfmp_pkg::G_HEADBLK*32 +: 32] = {28'd0, held};
      if (frozen_blk) inc_g[sfmp_pkg::G_FRZBLK*32 +: 32] = 32'd1;
      for (int d = 0; d < ND; d++) begin
        logic [3:0] ds;
        ds = 4'd0;
        if (c_req_valid[d] && !c_req_ready[d]) ds = ds + 4'd1;
        if (elig[d] && !(pop_sel && sel == PIW'(d))) ds = ds + 4'd1;
        inc_d[(d*sfmp_pkg::NDC + sfmp_pkg::D_QSTALL)*32 +: 32] = {28'd0, ds};
      end
    end
  end

  wire unused_ok = &{1'b0, pv_addr[31:POOL_AW], pv_addr[CHUNK_LG-1:0], pv_gran_off[GA-1:LW]};
endmodule

`default_nettype wire
