// =============================================================================
// MemoryPool :: sfmp_scrub -- zero-fill engine (stale-data protection)
//
// A newly allocated extent is zeroed BEFORE its region becomes ACTIVE, so a new owner can never read
// what a previous owner left behind (the "stale mapping reuse" / data-remanence hole).  Migration
// destinations are not scrubbed: every byte is overwritten by the copy and verified before commit.
// Writes full-strobe zero beats through its own master port on the target tier; several beats may be
// outstanding.  `done` is a pulse after the LAST write response; `err` (valid with done) if any
// response was an error.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfmp_scrub #(
  parameter int DW      = 32,
  parameter int MAXOUT  = 8
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              start,
  input  wire logic              tier,
  input  wire logic [31:0]       base,        // byte address inside the tier
  input  wire logic [31:0]       len_bytes,   // multiple of DW/8
  output logic                   idle,
  output logic                   done,
  output logic                   err,
  // tier 0 / tier 1 master ports (write only)
  output logic                   t0_req_valid,
  input  wire logic              t0_req_ready,
  output logic      [31:0]       t0_req_addr,
  input  wire logic              t0_rsp_valid,
  input  wire logic              t0_rsp_err,
  output logic                   t1_req_valid,
  input  wire logic              t1_req_ready,
  output logic      [31:0]       t1_req_addr,
  input  wire logic              t1_rsp_valid,
  input  wire logic              t1_rsp_err,
  output logic      [DW-1:0]     req_wdata,
  output logic      [DW/8-1:0]   req_wstrb,
  output logic      [31:0]       ev_bytes          // bytes acknowledged this cycle
);
  localparam int DWB = DW / 8;
  localparam int LGB = $clog2(DWB);

  logic        run_q, tier_q, err_q;
  logic [31:0] addr_q, left_q, pend_q;      // next address, beats left to issue, beats awaiting a response

  assign req_wdata = '0;
  assign req_wstrb = {DWB{1'b1}};
  assign idle      = !run_q;

  wire can_issue = run_q && (left_q != 32'd0) && (pend_q < 32'd8);
  assign t0_req_valid = can_issue && !tier_q;
  assign t1_req_valid = can_issue &&  tier_q;
  assign t0_req_addr  = addr_q;
  assign t1_req_addr  = addr_q;
  wire issued = (t0_req_valid && t0_req_ready) || (t1_req_valid && t1_req_ready);
  wire rsp    = run_q && (tier_q ? t1_rsp_valid : t0_rsp_valid);
  wire rsp_e  = tier_q ? t1_rsp_err : t0_rsp_err;

  assign ev_bytes = (rsp && !rsp_e) ? 32'(DWB) : 32'd0;
  assign done     = run_q && (left_q == 32'd0) && (pend_q == 32'd0);
  assign err      = err_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      run_q <= 1'b0; tier_q <= 1'b0; err_q <= 1'b0; addr_q <= '0; left_q <= '0; pend_q <= '0;
    end else begin
      if (!run_q) begin
        if (start) begin
          run_q  <= 1'b1;
          tier_q <= tier;
          err_q  <= 1'b0;
          addr_q <= base;
          left_q <= len_bytes >> LGB;
          pend_q <= 32'd0;
        end
      end else begin
        if (issued) begin
          addr_q <= addr_q + 32'(DWB);
          left_q <= left_q - 32'd1;
        end
        case ({issued, rsp})
          2'b10:   pend_q <= pend_q + 32'd1;
          2'b01:   pend_q <= pend_q - 32'd1;
          default: pend_q <= pend_q;
        endcase
        if (rsp && rsp_e) err_q <= 1'b1;
        if (left_q == 32'd0 && pend_q == 32'd0) run_q <= 1'b0;     // `done` is high in this cycle
      end
    end
  end
endmodule

`default_nettype wire
