// =============================================================================
// MemoryPool :: sfmp_policy -- baseline hardware tiering policy
//
// POLICY INTERFACE (the part another policy -- firmware, a host daemon, an ML model -- must reproduce)
//   inputs   per-region epoch access counters (reads, writes) from the region table, which the policy
//            CONSUMES (reads and clears) once per epoch;  region size, tier, owner, pin / migration state;
//            SRAM occupancy; the migration cost (programmed, or measured from completed migrations);
//   output   ONE migration request per epoch  {region index, destination tier}  to the command engine
//            (`req_*`).  The command engine re-validates everything (ownership, quota, space), so a policy
//            can only ever ASK for a migration; it cannot bypass an isolation or allocation rule.
//   A software policy uses the same request path through the CMD_MIGRATE management command.
//
// BASELINE ALGORITHM (integer arithmetic only; see docs/TIERING_POLICY.md)
//   every EPOCH_CYCLES:  for every region
//       hotness  S <- S - (S >> D) + ((accesses << 4) >> D)          EWMA, Q4 accesses per epoch (D = DECAY_SHIFT)
//       wS       likewise for writes                                  (read/write mix)
//   promotion candidate (region in DRAM, ACTIVE, unpinned, not cooling down):
//       benefit  = (S >> 4) * DELTA * HORIZON        cycles saved over HORIZON epochs if served by SRAM
//       cost     = len * COST_PER_GRAN + min(wS >> 4, chunks) * COST_PER_CHUNK   (copy + expected dirty re-copy)
//       promote only if  S >> 4 >= HOT_MIN  and  benefit > cost + (cost >> MARGIN_SHIFT)
//       best candidate = largest (benefit - cost)
//   capacity: if SRAM has room, promote.  If not, demote the COLDEST SRAM region (unpinned, not cooling)
//       only if  (S_candidate - S_victim) >= HYST_GAP (in accesses per epoch), the demotion frees enough, AND the
//       candidate's benefit covers BOTH migrations:  benefit > (cost_promote + cost_demote) * (1 + 2^-MARGIN_SHIFT).
//   pressure (OPT-IN: the reset value of HIGH_WATERMARK is the SRAM capacity, so it never fires): if SRAM occupancy
//       exceeds HIGH_WATERMARK and the coldest SRAM region is below HOT_MIN, demote it -- keeps headroom for AUTO
//       allocations; it costs migration bandwidth without a demonstrated demand, hence off by default.
//   ANTI-OSCILLATION:  (1) hysteresis -- a region is demoted only when CLEARLY colder than what replaces it,
//       (2) cooldown -- a region that was just requested cannot be requested again for COOLDOWN_EPOCHS,
//       (3) cost-aware margin -- a migration must pay for itself with a margin, (4) one request per epoch,
//       (5) none while a migration is running, (6) a refused request (no contiguous space, quota, ...) backs the region
//       off for 4x COOLDOWN_EPOCHS instead of retrying every cooldown period.
// MIGRATION COST.  Programmed (`cost_gran`) or, with AUTOCOST, an EWMA of cycles per granule measured from
// the migrations that actually completed (cost estimate = (3*old + sample) / 4).
// BENEFIT PER ACCESS (`delta`).  Programmed, or, with AUTODELTA, MEASURED every epoch from the per-tier latency
// counters: delta = mean(tier-1 service latency) - mean(tier-0 service latency) over the epoch, smoothed
// (new = (old + sample) / 2).  The measured value includes queueing, so it tracks the load the platform is under.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfmp_policy #(
  parameter int NR       = 32,
  parameter int LW       = 7,
  parameter int PERC     = 4            // chunks per granule
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // configuration (register block)
  input  wire logic                pol_en,
  input  wire logic                autocost,
  input  wire logic                autodelta,
  input  wire logic [7:0]          sram_ref,        // reference tier-0 latency used while tier 0 has too few latency samples
  input  wire logic [31:0]         epoch_cycles,
  input  wire logic [7:0]          hot_min,
  input  wire logic [7:0]          decay_shift,
  input  wire logic [7:0]          cooldown_epochs,
  input  wire logic [7:0]          horizon_epochs,
  input  wire logic [15:0]         cost_gran,
  input  wire logic [15:0]         cost_chunk,
  input  wire logic [31:0]         delta,
  input  wire logic [7:0]          margin_shift,
  input  wire logic [7:0]          hyst_gap,
  input  wire logic [15:0]         high_wm,
  // state
  input  wire logic [15:0]         sram_total,      // granules
  input  wire logic [15:0]         sram_used,       // granules
  input  wire logic                mig_busy,
  // region table (read port + consume)
  output logic      [$clog2(NR)-1:0] rt_idx,
  input  wire logic [sfmp_pkg::ENTRY_W-1:0] rt_ent,
  output logic                     rt_consume,
  // per-tier service latency counters (low 32 bits of the telemetry counters)
  input  wire logic [31:0]         lat_sum0,
  input  wire logic [31:0]         lat_cnt0,
  input  wire logic [31:0]         lat_sum1,
  input  wire logic [31:0]         lat_cnt1,
  output logic      [15:0]         delta_est_o,
  // migration cost feedback
  input  wire logic                mig_done_evt,
  input  wire logic                mig_done_ok,
  input  wire logic [31:0]         mig_done_cycles,
  input  wire logic [LW-1:0]       mig_done_len,
  // request to the command engine
  output logic                     req_valid,
  input  wire logic                req_ready,
  output logic      [$clog2(NR)-1:0] req_idx,
  output logic                     req_dst,
  input  wire logic                req_done,
  input  wire logic [7:0]          req_rc,
  // debug read of a region's hotness
  input  wire logic [$clog2(NR)-1:0] sc_rd_idx,
  output logic      [31:0]         sc_rd_val,
  output logic      [15:0]         cost_est_o,
  output logic                     scanning,
  output logic      [7:0]          epochs,
  // events
  output logic                     ev_req,
  output logic                     ev_fail
);
  localparam int IW = $clog2(NR);

  localparam logic [2:0] P_IDLE = 3'd0, P_SCAN = 3'd1, P_DECIDE = 3'd2, P_REQ = 3'd3, P_WAIT = 3'd4, P_WDIV = 3'd5;

  logic [2:0]  st_q;
  logic [31:0] ep_cnt_q;
  logic [IW-1:0] scan_q;
  logic [7:0]  epochs_q;
  logic [23:0] score_q [NR];
  logic [23:0] wscore_q [NR];
  logic [7:0]  cool_q [NR];
  logic [7:0]  genseen_q [NR];
  logic [15:0] cost_q;

  // best promotion candidate / coldest SRAM victim found by the scan
  logic          bp_v, vc_v;
  logic [IW-1:0] bp_idx, vc_idx;
  logic [47:0]   bp_net, bp_ben, bp_cost;
  logic [23:0]   bp_score, vc_score;
  logic [LW-1:0] bp_len, vc_len;
  logic          req_dst_q;
  logic [IW-1:0] req_idx_q;

  assign scanning   = (st_q != P_IDLE);
  assign epochs     = epochs_q;
  assign cost_est_o = cost_q;
  assign sc_rd_val  = {8'd0, score_q[sc_rd_idx]};

  // ---------------------------------------------------------------- region fields (read port follows the scan index)
  assign rt_idx = scan_q;
  wire [1:0]  e_state = rt_ent[sfmp_pkg::E_STATE +: 2];
  wire        e_tier  = rt_ent[sfmp_pkg::E_TIER];
  wire [1:0]  e_mig   = rt_ent[sfmp_pkg::E_MIG +: 2];
  wire        e_pin   = rt_ent[sfmp_pkg::E_PIN];
  wire [7:0]  e_gen   = rt_ent[sfmp_pkg::E_GEN +: 8];
  wire [LW-1:0] e_len = rt_ent[sfmp_pkg::E_LEN +: LW];
  wire [15:0] e_rd    = rt_ent[sfmp_pkg::E_RDEP +: 16];
  wire [15:0] e_wr    = rt_ent[sfmp_pkg::E_WREP +: 16];

  // ---------------------------------------------------------------- scan arithmetic (combinational on the current region)
  logic        fresh;                       // slot unused or reallocated since the last scan
  logic [23:0] s_old, w_old, s_new, w_new;
  logic [16:0] acc;
  logic [7:0]  cool_new;
  logic [47:0] benefit, cost, cost_pad, net;
  logic [47:0] pen;
  logic [16:0] w_acc;
  logic [8:0]  nchunks;
  logic        eligible, is_cand, is_vict;
  logic [16:0] s_acc;
  always_comb begin
    acc   = {1'b0, e_rd} + {1'b0, e_wr};
    fresh = (e_state == sfmp_pkg::RS_FREE) || (e_gen != genseen_q[scan_q]);
    s_old = fresh ? 24'd0 : score_q[scan_q];
    w_old = fresh ? 24'd0 : wscore_q[scan_q];
    s_new = s_old - (s_old >> decay_shift[2:0]) + ((24'(acc) << 4) >> decay_shift[2:0]);
    w_new = w_old - (w_old >> decay_shift[2:0]) + ((24'(e_wr) << 4) >> decay_shift[2:0]);
    cool_new = fresh ? 8'd0 : ((cool_q[scan_q] != 8'd0) ? cool_q[scan_q] - 8'd1 : 8'd0);
    s_acc    = s_new[20:4];
    w_acc    = w_new[20:4];
    nchunks  = 9'(e_len) * 9'(PERC);
    benefit  = {31'd0, s_acc} * {32'd0, delta_eff} * {40'd0, horizon_epochs};
    pen      = ({31'd0, ((w_acc > {8'd0, nchunks}) ? {8'd0, nchunks} : w_acc)}) * {32'd0, cost_chunk};
    cost     = {41'd0, e_len} * {32'd0, cost_q} + pen;
    cost_pad = cost + (cost >> margin_shift[2:0]);
    net      = benefit - cost;
    eligible = (e_state == sfmp_pkg::RS_ACTIVE) && (e_mig == sfmp_pkg::MG_NONE) && !e_pin && (cool_new == 8'd0);
    is_cand  = eligible && (e_tier == sfmp_pkg::TIER_DRAM) && (s_acc >= {9'd0, hot_min}) && (benefit > cost_pad);
    is_vict  = eligible && (e_tier == sfmp_pkg::TIER_SRAM);
  end

  // ---------------------------------------------------------------- measured cost (cycles / granule) and measured benefit
  logic [15:0] delta_est_q;
  logic [15:0] cg_prev_q;
  wire  [15:0] delta_eff = autodelta ? delta_est_q : (delta[31:16] != 16'd0 ? 16'hFFFF : delta[15:0]);
  assign delta_est_o = delta_est_q;
  // cost: one division per completed migration
  logic          dc_pend_q;
  logic [31:0]   dc_cyc_q;
  logic [LW-1:0] dc_len_q;
  logic          dc_start, dc_busy, dc_done;
  logic [31:0]   dc_quo;
  assign dc_start = dc_pend_q && !dc_busy;
  sfmp_div32 u_dc (.clk, .rst_n, .start(dc_start), .num(dc_cyc_q), .den({{(32-LW){1'b0}}, dc_len_q}), .busy(dc_busy), .done(dc_done), .quo(dc_quo));
  // benefit: two divisions per epoch (mean latency of each tier)
  logic [31:0] s0_snap_q, c0_snap_q, s1_snap_q, c1_snap_q, m0_q, m1_q;
  logic        dd_run_q, dd0_have_q, dd1_have_q;
  wire  [31:0] ds0 = lat_sum0 - s0_snap_q;
  wire  [31:0] dc0 = lat_cnt0 - c0_snap_q;
  wire  [31:0] ds1 = lat_sum1 - s1_snap_q;
  wire  [31:0] dc1 = lat_cnt1 - c1_snap_q;
  wire         dd0_use = (dc0 >= 32'd8);                 // tier 0 has enough samples: measure it, else use the reference
  wire         dd_ok = (dc1 >= 32'd8);                   // tier 1 (the slow tier) must have samples
  wire         epoch_tick = (st_q == P_IDLE) && pol_en && (ep_cnt_q + 32'd1 >= epoch_cycles);
  wire         dd_start = epoch_tick && autodelta && dd_ok;
  logic        dd0_busy, dd0_done, dd1_busy, dd1_done;
  logic [31:0] dd0_quo, dd1_quo;
  sfmp_div32 u_dd0 (.clk, .rst_n, .start(dd_start && dd0_use), .num(ds0), .den(dc0), .busy(dd0_busy), .done(dd0_done), .quo(dd0_quo));
  sfmp_div32 u_dd1 (.clk, .rst_n, .start(dd_start), .num(ds1), .den(dc1), .busy(dd1_busy), .done(dd1_done), .quo(dd1_quo));
  wire [31:0] est_d   = (m1_q > m0_q) ? (m1_q - m0_q) : 32'd0;
  wire [31:0] new_d   = ({16'd0, delta_est_q} + est_d) >> 1;

  // ---------------------------------------------------------------- decision (after the scan)
  wire [15:0] free_g = (sram_total > sram_used) ? (sram_total - sram_used) : 16'd0;
  // making room costs a second migration: the candidate's benefit must cover the promotion AND the demotion, with margin
  wire [47:0] cost_v    = {41'd0, vc_len} * {32'd0, cost_q};
  wire [47:0] cost_both = bp_cost + cost_v;
  wire        pays_both = bp_ben > (cost_both + (cost_both >> margin_shift[2:0]));
  logic        d_go, d_dst;
  logic [IW-1:0] d_idx;
  always_comb begin
    d_go = 1'b0; d_dst = 1'b0; d_idx = '0;
    if (bp_v && ({1'b0, free_g} >= {1'b0, 16'(bp_len)})) begin
      d_go = 1'b1; d_dst = sfmp_pkg::TIER_SRAM; d_idx = bp_idx;                       // room: promote
    end else if (bp_v && vc_v && (bp_score >= vc_score + {12'd0, hyst_gap, 4'd0}) &&
                 ({1'b0, free_g} + {1'b0, 16'(vc_len)} >= {1'b0, 16'(bp_len)}) && pays_both) begin
      d_go = 1'b1; d_dst = sfmp_pkg::TIER_DRAM; d_idx = vc_idx;                       // make room: demote the coldest
    end else if (vc_v && (sram_used > high_wm) && (vc_score[20:4] < {9'd0, hot_min})) begin
      d_go = 1'b1; d_dst = sfmp_pkg::TIER_DRAM; d_idx = vc_idx;                       // memory pressure: demote a cold region
    end
  end

  assign req_valid = (st_q == P_REQ);
  assign req_idx   = req_idx_q;
  assign req_dst   = req_dst_q;
  assign rt_consume = (st_q == P_SCAN);
  assign ev_req    = (st_q == P_REQ) && req_ready;
  assign ev_fail   = (st_q == P_WAIT) && req_done && (req_rc != sfmp_pkg::RC_OK);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= P_IDLE; ep_cnt_q <= '0; scan_q <= '0; epochs_q <= '0; cost_q <= 16'd1500;
      bp_v <= 1'b0; vc_v <= 1'b0; bp_idx <= '0; vc_idx <= '0; bp_net <= '0; bp_ben <= '0; bp_cost <= '0; bp_score <= '0; vc_score <= '0; bp_len <= '0; vc_len <= '0;
      req_dst_q <= 1'b0; req_idx_q <= '0;
      cg_prev_q <= 16'd1500; dc_pend_q <= 1'b0; dc_cyc_q <= '0; dc_len_q <= '0; delta_est_q <= 16'd11; s0_snap_q <= '0; c0_snap_q <= '0; s1_snap_q <= '0; c1_snap_q <= '0;
      m0_q <= '0; m1_q <= '0; dd_run_q <= 1'b0; dd0_have_q <= 1'b0; dd1_have_q <= 1'b0;
      for (int r = 0; r < NR; r++) begin score_q[r] <= '0; wscore_q[r] <= '0; cool_q[r] <= '0; genseen_q[r] <= '0; end
    end else begin
      // keep the programmed value as the starting estimate while AUTOCOST is off
      if (!autocost || cost_gran != cg_prev_q) cost_q <= cost_gran;       // programming COST_PER_GRAN (re)seeds the estimate
      cg_prev_q <= cost_gran;

      // ---- measured cost: queue one division per completed migration
      if (mig_done_evt && mig_done_ok && autocost && mig_done_len != '0) begin
        dc_pend_q <= 1'b1; dc_cyc_q <= mig_done_cycles; dc_len_q <= mig_done_len;
      end
      if (dc_start) dc_pend_q <= 1'b0;
      if (dc_done)  cost_q <= 16'(((32'(cost_q) * 32'd3) + dc_quo) >> 2 > 32'hFFFF ? 32'hFFFF : (((32'(cost_q) * 32'd3) + dc_quo) >> 2));
      // ---- measured benefit: capture the two mean latencies, fold them into the estimate once the scan is over
      if (!autodelta) delta_est_q <= (delta[31:16] != 16'd0) ? 16'hFFFF : delta[15:0];
      if (dd0_done) begin m0_q <= dd0_quo; dd0_have_q <= 1'b1; end
      if (dd1_done) begin m1_q <= dd1_quo; dd1_have_q <= 1'b1; end
      if (dd_start) begin
        dd_run_q <= 1'b1; dd0_have_q <= !dd0_use; dd1_have_q <= 1'b0;
        if (!dd0_use) m0_q <= {24'd0, sram_ref};
        s0_snap_q <= lat_sum0; c0_snap_q <= lat_cnt0; s1_snap_q <= lat_sum1; c1_snap_q <= lat_cnt1;
      end

      // ---- epoch FSM
      case (st_q)
        P_IDLE: begin
          if (pol_en) begin
            ep_cnt_q <= ep_cnt_q + 32'd1;
            if (ep_cnt_q + 32'd1 >= epoch_cycles) begin
              ep_cnt_q <= '0; scan_q <= '0; epochs_q <= epochs_q + 8'd1;
              bp_v <= 1'b0; vc_v <= 1'b0; bp_net <= '0; vc_score <= '1; bp_score <= '0;
              st_q <= P_SCAN;
            end
          end else ep_cnt_q <= '0;
        end
        P_SCAN: begin
          score_q[scan_q] <= s_new; wscore_q[scan_q] <= w_new; genseen_q[scan_q] <= e_gen; cool_q[scan_q] <= cool_new;
          if (is_cand && (!bp_v || net > bp_net)) begin bp_v <= 1'b1; bp_idx <= scan_q; bp_net <= net; bp_ben <= benefit; bp_cost <= cost; bp_score <= s_new; bp_len <= e_len; end
          if (is_vict && (!vc_v || s_new < vc_score)) begin vc_v <= 1'b1; vc_idx <= scan_q; vc_score <= s_new; vc_len <= e_len; end
          if (scan_q == IW'(NR - 1)) st_q <= P_WDIV;
          else scan_q <= scan_q + 1'b1;
        end
        P_WDIV: begin
          // wait for the two mean-latency divisions (32 cycles) before using / updating the benefit estimate
          if (!dd_run_q) st_q <= P_DECIDE;
          else if (dd0_have_q && dd1_have_q) begin
            delta_est_q <= (new_d > 32'hFFFF) ? 16'hFFFF : new_d[15:0];
            dd_run_q <= 1'b0; st_q <= P_DECIDE;
          end
        end
        P_DECIDE: begin
          if (d_go && !mig_busy) begin
            req_idx_q <= d_idx; req_dst_q <= d_dst; st_q <= P_REQ;
            cool_q[d_idx] <= cooldown_epochs;
          end else st_q <= P_IDLE;
        end
        P_REQ:  if (req_ready) st_q <= P_WAIT;
        P_WAIT: if (req_done) begin
          // a refused request (no contiguous space, quota, ...) backs the region off 4x longer than a successful one
          if (req_rc != sfmp_pkg::RC_OK) cool_q[req_idx_q] <= (cooldown_epochs > 8'd63) ? 8'hFF : {cooldown_epochs[5:0], 2'b00};
          st_q <= P_IDLE;
        end
        default: st_q <= P_IDLE;
      endcase
    end
  end

  wire unused_ok = &{1'b0, benefit[47], cost_pad[47], bp_net[0], bp_ben[47], cost_both[47], e_wr[0], decay_shift[7:3], margin_shift[7:3], net[47], dd0_busy, dd1_busy, dd1_done};
endmodule

`default_nettype wire
