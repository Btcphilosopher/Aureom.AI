// =============================================================================
// SilicaFlux MemoryPool (Project 65) :: silicaflux_memory_pool  -- PRIMARY RTL
//
// Cloud memory tiering and allocation accelerator for SilicaFlux CloudDPU.
//
//   tier 0  on-chip SRAM        -- the repository's SRAM Wrapper Library cell (`sram_sp`, generic backend)
//   tier 1  external DRAM       -- a plain valid/ready tier port (`em_*`).  In simulation it is a BEHAVIOURAL
//                                  MODEL (model/sfmp_dram_model.sv).  This block contains NO DRAM controller,
//                                  NO PHY, and NO CXL logic.  CXL is a separate future integration project;
//                                  the adapter boundary is specified in docs/CXL_ADAPTER_SPEC.md.
//
//   client side   NUM_DOMAINS accelerator ports (port i hard-bound to a domain by a privileged BIND) plus one
//                 host-DMA port behind the IOMMU boundary (domain + "translated" flag come from the IOMMU).
//   data path     per-port request / response queues -> region-table CAM translation -> ownership,
//                 permission, state and migration-freeze checks -> tier arbiter -> SRAM or `em_*`.
//   management    privileged register page (`rb_*`): region table, domains, quotas, migration, policy,
//                 counters.  The data path can never change ownership or mappings.
//   migration     sfmp_migrate: pre-copy with dirty tracking, freeze, CloudDMA copy (vendored, unmodified),
//                 CRC read-back verify, atomic commit, release of the old extent.
//   tiering       sfmp_policy: baseline epoch policy (hotness, cost-aware, hysteresis, cooldown).
//
// Translation granularity: 2**GRAN_LG bytes (default 256 B).  This is the accelerator's own remapping of its
// managed window; it does not replace the CPU MMU or the host IOMMU.
//
// Reset: asynchronous assert (`rst_n`), to be released synchronously by the SoC reset controller.  The
// external DRAM interface MUST be reset together with this block (a response owed by a request that
// was in flight at reset is not tracked).  SRAM contents are not cleared by reset; a new allocation is
// always zero-filled before it becomes visible.
//
// Classification: SYNTHESIZABLE (the DRAM model and testbench are simulation-only)
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module silicaflux_memory_pool #(
  parameter int NUM_DOMAINS     = 4,        // 1..8: accelerator ports and tenant domains
  parameter int NUM_REGIONS     = 32,       // 4..32
  parameter int DATA_WIDTH      = 32,       // 32 | 64
  parameter int GRAN_LG         = 8,        // translation granule = 2**GRAN_LG bytes
  parameter int POOL_AW         = 28,       // managed PVA window = 2**POOL_AW bytes
  parameter int SRAM_BYTES      = 65536,    // tier 0 capacity (power of two)
  parameter int DRAM_BYTES      = 262144,   // tier 1 capacity addressed by the pool (power of two)
  parameter int MAX_REGION_GRAN = 64,       // longest region (granules)
  parameter int CHUNK_LG        = 6,        // migration copy / verify / dirty-tracking unit = 2**CHUNK_LG bytes
  parameter int MIG_CH          = 1,        // parallel migration copy channels (CloudDMA instances)
  parameter int RQ_DEPTH        = 4,        // per-port request queue depth
  parameter int EM_OUT          = 4,        // outstanding requests allowed on the external tier port
  parameter int SRAM_BACKEND    = `SRAM_BACKEND_GENERIC
) (
  input  wire logic                                 clk,
  input  wire logic                                 rst_n,
  // ---- privileged register page (same protocol as the other SilicaFlux pages; rb_priv as in the RAS page)
  input  wire logic                                 rb_sel,
  input  wire logic                                 rb_we,
  input  wire logic [11:0]                          rb_addr,
  input  wire logic [31:0]                          rb_wdata,
  input  wire logic                                 rb_priv,
  output logic      [31:0]                          rb_rdata,
  output logic                                      rb_err,
  // ---- client ports: [NUM_DOMAINS-1:0] accelerator ports, [NUM_DOMAINS] host-DMA port (flat vectors)
  input  wire logic [NUM_DOMAINS:0]                 c_req_valid,
  output logic      [NUM_DOMAINS:0]                 c_req_ready,
  input  wire logic [NUM_DOMAINS:0]                 c_req_write,
  input  wire logic [(NUM_DOMAINS+1)*32-1:0]        c_req_addr,        // PVA (byte, beat aligned)
  input  wire logic [(NUM_DOMAINS+1)*DATA_WIDTH-1:0] c_req_wdata,
  input  wire logic [(NUM_DOMAINS+1)*(DATA_WIDTH/8)-1:0] c_req_wstrb,
  output logic      [NUM_DOMAINS:0]                 c_rsp_valid,
  input  wire logic [NUM_DOMAINS:0]                 c_rsp_ready,
  output logic      [(NUM_DOMAINS+1)*DATA_WIDTH-1:0] c_rsp_rdata,
  output logic      [NUM_DOMAINS:0]                 c_rsp_err,
  output logic      [(NUM_DOMAINS+1)*8-1:0]         c_rsp_code,
  // ---- IOMMU boundary for the host-DMA port (sampled with its request)
  input  wire logic [3:0]                           hd_dom,            // domain resolved by the IOMMU for the requester
  input  wire logic                                 hd_xlat_ok,        // the IOMMU translated / permitted this transaction
  // ---- external DRAM tier port (SFB2-style, in-order responses, up to EM_OUT outstanding)
  output logic                                      em_req_valid,
  input  wire logic                                 em_req_ready,
  output logic                                      em_req_write,
  output logic      [31:0]                          em_req_addr,       // byte address inside the DRAM tier
  output logic      [DATA_WIDTH-1:0]                em_req_wdata,
  output logic      [DATA_WIDTH/8-1:0]              em_req_wstrb,
  input  wire logic                                 em_rsp_valid,
  output logic                                      em_rsp_ready,
  input  wire logic [DATA_WIDTH-1:0]                em_rsp_rdata,
  input  wire logic                                 em_rsp_error,
  // ---- RAS / interrupts (event format of the RAS project's external-event port)
  output logic                                      ras_ev_valid,
  output logic      [3:0]                           ras_ev_type,
  output logic      [31:0]                          ras_ev_addr,
  output logic      [31:0]                          ras_ev_info,
  output logic                                      irq_event,         // pulse: command or migration finished
  output logic                                      irq_fault,         // pulse: media error / privilege violation / migration abort
  // ---- status
  output logic                                      mig_busy_o
);
  localparam int ND   = NUM_DOMAINS;
  localparam int NR   = NUM_REGIONS;
  localparam int DW   = DATA_WIDTH;
  localparam int DWB  = DW / 8;
  localparam int NPT  = ND + 1;
  localparam int GA   = POOL_AW - GRAN_LG;
  localparam int G0   = SRAM_BYTES >> GRAN_LG;
  localparam int G1   = DRAM_BYTES >> GRAN_LG;
  localparam int GMAX = (G0 > G1) ? G0 : G1;
  localparam int GW   = $clog2(GMAX);
  localparam int PW   = GW;
  localparam int LW   = $clog2(MAX_REGION_GRAN + 1);
  localparam int IW   = $clog2(NR);
  localparam int PERC = 1 << (GRAN_LG - CHUNK_LG);
  localparam int MAXCHUNKS = MAX_REGION_GRAN * PERC;
  localparam int CKW  = $clog2(MAXCHUNKS);
  localparam int CW   = LW + GRAN_LG - CHUNK_LG;
  localparam int NM   = 2 + 2 * MIG_CH;           // tier-arbiter masters: access, scrub, (DMA, verify) x MIG_CH

  // ------------------------------------------------------------------ elaboration checks (illegal configurations refused)
  if (ND < 1 || ND > sfmp_pkg::MAX_DOMAINS)             begin : g_err_nd   $fatal(1, "NUM_DOMAINS must be 1..8"); end
  if (NR < 4 || NR > sfmp_pkg::MAX_REGIONS)             begin : g_err_nr   $fatal(1, "NUM_REGIONS must be 4..32"); end
  if (DW != 32 && DW != 64)                             begin : g_err_dw   $fatal(1, "DATA_WIDTH must be 32 or 64"); end
  if (GRAN_LG < CHUNK_LG || GRAN_LG > 12)               begin : g_err_gl   $fatal(1, "need CHUNK_LG <= GRAN_LG <= 12"); end
  if ((1 << CHUNK_LG) < DWB)                            begin : g_err_ch   $fatal(1, "chunk must hold at least one data beat"); end
  if (SRAM_BYTES != (1 << $clog2(SRAM_BYTES)) || DRAM_BYTES != (1 << $clog2(DRAM_BYTES)))
                                                        begin : g_err_pw2  $fatal(1, "SRAM_BYTES and DRAM_BYTES must be powers of two"); end
  if (SRAM_BYTES < (1 << GRAN_LG) || DRAM_BYTES < (1 << GRAN_LG))
                                                        begin : g_err_cap  $fatal(1, "tier smaller than one granule"); end
  if (MAX_REGION_GRAN < 1 || MAX_REGION_GRAN > 255)     begin : g_err_mrg  $fatal(1, "MAX_REGION_GRAN must be 1..255"); end
  if (GA > 26 || GA < 1)                                begin : g_err_ga   $fatal(1, "POOL_AW - GRAN_LG must be 1..26"); end
  if (PW > 16)                                          begin : g_err_pw   $fatal(1, "tier too large: more than 65536 granules"); end
  if (MIG_CH < 1 || MIG_CH > 4)                         begin : g_err_mc   $fatal(1, "MIG_CH must be 1..4"); end
  if (RQ_DEPTH < 2 || EM_OUT < 1)                       begin : g_err_q    $fatal(1, "RQ_DEPTH >= 2 and EM_OUT >= 1"); end
  if (MAXCHUNKS > 1024)                                 begin : g_err_mck  $fatal(1, "too many chunks per region"); end

  // ------------------------------------------------------------------ cycle counter
  logic [31:0] unused_now;
  assign unused_now = '0;

  // ------------------------------------------------------------------ register block <-> everything
  logic        ctl_policy_en, ctl_precopy, ctl_verify, ctl_autocost, ctl_autodelta, tlm_freeze, tlm_clear;
  logic [7:0]  mig_max_rounds, mig_freeze_thresh, mig_max_retry;
  logic        cmd_pend, cmd_take, cmd_done;
  logic [7:0]  cmd_o, cmd_rc, cmd_gen;
  logic [31:0] arg0, arg1, arg2, arg3, cmd_res0, cmd_res1;
  logic [4:0]  cmd_idx;
  logic [IW-1:0] rsel;
  logic [3:0]  dsel;
  logic        pol_scanning;
  logic [7:0]  pol_epochs;
  logic [15:0] pol_cost_est, pol_delta_est;
  logic [7:0]  pol_sram_lat;
  logic [31:0] pol_epoch, pol_delta;
  logic [7:0]  pol_hot_min, pol_decay, pol_cool, pol_horizon, pol_margin, pol_hyst;
  logic [15:0] pol_cost_gran, pol_cost_chunk, pol_high_wm;
  logic        ev_priv_viol, ev_cmd_dropped;

  // ------------------------------------------------------------------ region table
  logic [GA-1:0]  lk_gran;
  logic           lk_hit, lk_tier, lk_perm_r, lk_perm_w, lk_multi;
  logic [IW-1:0]  lk_idx;
  logic [PW-1:0]  lk_pgran;
  logic [1:0]     lk_state, lk_mig;
  logic [3:0]     lk_dom;
  logic [GA-1:0]  lk_base;
  logic [GA-1:0]  ov_base;
  logic [LW-1:0]  ov_len;
  logic           ov_any, fr_vld;
  logic [IW-1:0]  fr_idx;
  logic [IW-1:0]  rd0_idx, rd2_idx;
  logic [sfmp_pkg::ENTRY_W-1:0] rd0_ent, rd1_ent, rd2_ent;
  logic [3:0]     ct_op, ct_dom;
  logic [IW-1:0]  ct_idx;
  logic [GA-1:0]  ct_pva;
  logic [LW-1:0]  ct_len;
  logic           ct_tier, ct_perm_r, ct_perm_w, ct_pin, ct_frozen;
  logic [PW-1:0]  ct_phys;
  logic [1:0]     mg_op;
  logic [IW-1:0]  mg_idx;
  logic [PW-1:0]  mg_phys;
  logic [7:0]     mg_err;
  logic           ac_valid, ac_write, er_valid;
  logic [IW-1:0]  ac_idx, er_idx;
  logic [7:0]     er_code;
  logic           p_consume;
  logic [IW-1:0]  p_idx;
  logic [ND*16-1:0] use_sram;
  logic [ND*8-1:0]  live_cnt;

  sfmp_region_table #(.NR(NR), .ND(ND), .GA(GA), .LW(LW), .PW(PW)) u_table (
    .clk, .rst_n,
    .lk_gran, .lk_hit, .lk_idx, .lk_pgran, .lk_state, .lk_dom, .lk_tier, .lk_perm_r, .lk_perm_w, .lk_mig, .lk_base, .lk_multi,
    .ov_base, .ov_len, .ov_any, .fr_vld, .fr_idx,
    .rd0_idx, .rd0_ent, .rd1_idx(rsel), .rd1_ent, .rd2_idx, .rd2_ent,
    .ct_op, .ct_idx, .ct_dom, .ct_pva, .ct_len, .ct_tier, .ct_phys, .ct_perm_r, .ct_perm_w, .ct_pin, .ct_frozen,
    .mg_op, .mg_idx, .mg_phys, .mg_err,
    .ac_valid, .ac_idx, .ac_write, .er_valid, .er_idx, .er_code,
    .p_consume, .p_idx,
    .use_sram, .live_cnt
  );

  // ------------------------------------------------------------------ allocator
  logic            al_valid, al_ready, al_tier, al_done, al_found, al_idle, rel_req, rel_tier, rel_done;
  logic [1:0]      al_op;
  logic [PW-1:0]   al_base, al_found_base, rel_base;
  logic [LW-1:0]   al_len, rel_len;
  logic [$clog2(G0+1)-1:0] occ0;
  logic [$clog2(G1+1)-1:0] occ1;
  logic [G0-1:0]   bm0;
  logic [G1-1:0]   bm1;

  sfmp_alloc #(.G0(G0), .G1(G1), .MAXLEN(MAX_REGION_GRAN)) u_alloc (
    .clk, .rst_n,
    .c_valid(al_valid), .c_ready(al_ready), .c_op(al_op), .c_tier(al_tier), .c_base(al_base), .c_len(al_len),
    .c_done(al_done), .c_found(al_found), .c_found_base(al_found_base),
    .r_req(rel_req), .r_tier(rel_tier), .r_base(rel_base), .r_len(rel_len), .r_done(rel_done),
    .idle(al_idle), .occ0, .occ1, .bm0_o(bm0), .bm1_o(bm1)
  );

  // ------------------------------------------------------------------ command engine
  logic [ND-1:0]   dom_en, dom_quar, dom_autoq, quar_set;
  logic [ND*4-1:0] bind_dom;
  logic [ND*(GA+1)-1:0] dom_wbase, dom_wlim;
  logic [ND*16-1:0] dom_quota;
  logic [NPT-1:0]  port_idle;
  logic            pol_ready, pol_done, pol_req_valid, pol_req_dst;
  logic [7:0]      pol_rc;
  logic [IW-1:0]   pol_req_idx;
  logic            sc_start, sc_tier, sc_idle, sc_done, sc_err;
  logic [31:0]     sc_base, sc_len;
  logic            me_start, me_dir, me_precopy, me_busy;
  logic [IW-1:0]   me_idx;
  logic [3:0]      me_dom;
  logic [31:0]     me_dram_base, me_sram_base;
  logic [PW-1:0]   me_src_gran, me_dst_gran;
  logic [LW-1:0]   me_len;
  logic            ev_alloc_ok, ev_alloc_fail, ev_free_ok, ev_cmd_err;
  logic [NR-1:0]   infl_nz;
  logic            ctrl_busy;

  sfmp_ctrl #(.ND(ND), .NR(NR), .GRAN_LG(GRAN_LG), .POOL_AW(POOL_AW), .GA(GA), .LW(LW), .PW(PW), .MAXLEN(MAX_REGION_GRAN)) u_ctrl (
    .clk, .rst_n,
    .cmd_pend, .cmd(cmd_o), .a0(arg0), .a1(arg1), .a2(arg2), .a3(arg3),
    .cmd_take, .cmd_done, .cmd_rc, .cmd_idx, .cmd_gen, .cmd_res0, .cmd_res1, .busy(ctrl_busy),
    .pol_valid(pol_req_valid), .pol_idx(pol_req_idx), .pol_dst(pol_req_dst), .pol_ready, .pol_done, .pol_rc,
    .precopy_en(ctl_precopy),
    .dom_en, .dom_quar, .dom_autoq, .bind_dom, .dom_wbase, .dom_wlim, .dom_quota, .quar_set, .port_idle,
    .ct_op, .ct_idx, .ct_dom, .ct_pva, .ct_len, .ct_tier, .ct_phys, .ct_perm_r, .ct_perm_w, .ct_pin, .ct_frozen,
    .ov_base, .ov_len, .ov_any, .fr_vld, .fr_idx, .rd_idx(rd0_idx), .rd_ent(rd0_ent), .use_sram, .live_cnt, .infl_nz,
    .al_valid, .al_ready, .al_op, .al_tier, .al_base, .al_len, .al_done, .al_found, .al_found_base,
    .sc_start, .sc_tier, .sc_base, .sc_len, .sc_idle, .sc_done, .sc_err,
    .me_start, .me_idx, .me_dir, .me_dom, .me_dram_base, .me_sram_base, .me_src_gran, .me_dst_gran, .me_len, .me_precopy, .me_busy,
    .ev_alloc_ok, .ev_alloc_fail, .ev_free_ok, .ev_cmd_err
  );

  // ------------------------------------------------------------------ access path
  logic            mw_valid;
  logic [IW-1:0]   mw_idx;
  logic [CW-1:0]   mw_chunk;
  logic            a_t0_req_valid, a_t0_req_ready, a_t0_req_write, a_t0_rsp_valid, a_t0_rsp_ready, a_t0_rsp_err;
  logic [31:0]     a_t0_req_addr;
  logic [DW-1:0]   a_t0_req_wdata, a_t0_rsp_rdata;
  logic [DWB-1:0]  a_t0_req_wstrb;
  logic            a_t1_req_valid, a_t1_req_ready, a_t1_req_write, a_t1_rsp_valid, a_t1_rsp_ready, a_t1_rsp_err;
  logic [31:0]     a_t1_req_addr;
  logic [DW-1:0]   a_t1_req_wdata, a_t1_rsp_rdata;
  logic [DWB-1:0]  a_t1_req_wstrb;
  logic [sfmp_pkg::NG*32-1:0]       inc_g_acc, inc_g_mig, inc_g_top;
  logic [ND*sfmp_pkg::NDC*32-1:0]   inc_d_acc, inc_d_mig;
  logic [31:0]     glat_max;
  logic [ND*32-1:0] dlat_max;
  logic            lf_valid, lf_write, ev_media, inv_evt;
  logic [3:0]      lf_cause, lf_port, lf_dom;
  logic [31:0]     lf_addr, ev_media_addr;

  sfmp_access #(.NPT(NPT), .ND(ND), .NR(NR), .DW(DW), .GRAN_LG(GRAN_LG), .POOL_AW(POOL_AW), .GA(GA), .PW(PW), .LW(LW),
                .RQ_DEPTH(RQ_DEPTH), .RSP_DEPTH(2), .CHUNK_LG(CHUNK_LG), .CW(CW)) u_access (
    .clk, .rst_n,
    .c_req_valid, .c_req_ready, .c_req_write, .c_req_addr, .c_req_wdata, .c_req_wstrb,
    .c_rsp_valid, .c_rsp_ready, .c_rsp_rdata, .c_rsp_err, .c_rsp_code,
    .hd_dom, .hd_xlat_ok,
    .dom_en, .dom_quar, .dom_autoq, .bind_dom, .quar_set, .port_idle,
    .lk_gran, .lk_hit, .lk_idx, .lk_pgran, .lk_state, .lk_dom, .lk_tier, .lk_perm_r, .lk_perm_w, .lk_mig, .lk_base, .lk_multi,
    .ac_valid, .ac_idx, .ac_write, .er_valid, .er_idx, .er_code,
    .infl_nz, .mw_valid, .mw_idx, .mw_chunk,
    .t0_req_valid(a_t0_req_valid), .t0_req_ready(a_t0_req_ready), .t0_req_write(a_t0_req_write), .t0_req_addr(a_t0_req_addr),
    .t0_req_wdata(a_t0_req_wdata), .t0_req_wstrb(a_t0_req_wstrb),
    .t0_rsp_valid(a_t0_rsp_valid), .t0_rsp_ready(a_t0_rsp_ready), .t0_rsp_rdata(a_t0_rsp_rdata), .t0_rsp_err(a_t0_rsp_err),
    .t1_req_valid(a_t1_req_valid), .t1_req_ready(a_t1_req_ready), .t1_req_write(a_t1_req_write), .t1_req_addr(a_t1_req_addr),
    .t1_req_wdata(a_t1_req_wdata), .t1_req_wstrb(a_t1_req_wstrb),
    .t1_rsp_valid(a_t1_rsp_valid), .t1_rsp_ready(a_t1_rsp_ready), .t1_rsp_rdata(a_t1_rsp_rdata), .t1_rsp_err(a_t1_rsp_err),
    .inc_g(inc_g_acc), .inc_d(inc_d_acc), .lat_max_g(glat_max), .lat_max_d(dlat_max),
    .lf_valid, .lf_cause, .lf_port, .lf_dom, .lf_write, .lf_addr,
    .ev_media, .ev_media_addr, .inv_evt
  );

  // ------------------------------------------------------------------ tier arbiters
  // master numbering on BOTH arbiters: 0 tenant access, 1 scrubber, 2+2j DMA of channel j, 3+2j verify of channel j
  logic [NM-1:0]        m0_req_valid, m0_req_ready, m0_req_write, m0_rsp_valid, m0_rsp_ready, m0_rsp_err;
  logic [NM*32-1:0]     m0_req_addr;
  logic [NM*DW-1:0]     m0_req_wdata, m0_rsp_rdata;
  logic [NM*DWB-1:0]    m0_req_wstrb;
  logic [NM-1:0]        m1_req_valid, m1_req_ready, m1_req_write, m1_rsp_valid, m1_rsp_ready, m1_rsp_err;
  logic [NM*32-1:0]     m1_req_addr;
  logic [NM*DW-1:0]     m1_req_wdata, m1_rsp_rdata;
  logic [NM*DWB-1:0]    m1_req_wstrb;

  logic s0_req_valid, s0_req_ready, s0_req_write, s0_rsp_valid, s0_rsp_ready, s0_rsp_err, s0_oor;
  logic [31:0] s0_req_addr;
  logic [DW-1:0] s0_req_wdata, s0_rsp_rdata;
  logic [DWB-1:0] s0_req_wstrb;
  logic ev0_ss, ev0_ts, ev1_ss, ev1_ts;
  logic [7:0] ev0_loss, ev1_loss;

  sfmp_tier_arb #(.NM(NM), .DW(DW), .MAXOUT(4)) u_arb0 (
    .clk, .rst_n,
    .m_req_valid(m0_req_valid), .m_req_ready(m0_req_ready), .m_req_write(m0_req_write), .m_req_addr(m0_req_addr),
    .m_req_wdata(m0_req_wdata), .m_req_wstrb(m0_req_wstrb),
    .m_rsp_valid(m0_rsp_valid), .m_rsp_ready(m0_rsp_ready), .m_rsp_rdata(m0_rsp_rdata), .m_rsp_err(m0_rsp_err),
    .s_req_valid(s0_req_valid), .s_req_ready(s0_req_ready), .s_req_write(s0_req_write), .s_req_addr(s0_req_addr),
    .s_req_wdata(s0_req_wdata), .s_req_wstrb(s0_req_wstrb),
    .s_rsp_valid(s0_rsp_valid), .s_rsp_ready(s0_rsp_ready), .s_rsp_rdata(s0_rsp_rdata), .s_rsp_err(s0_rsp_err),
    .ev_slave_stall(ev0_ss), .ev_tag_stall(ev0_ts), .ev_loss(ev0_loss)
  );
  sfmp_sram_tier #(.DW(DW), .BYTES(SRAM_BYTES), .SRAM_BACKEND(SRAM_BACKEND)) u_sram (
    .clk, .rst_n,
    .req_valid(s0_req_valid), .req_ready(s0_req_ready), .req_write(s0_req_write), .req_addr(s0_req_addr),
    .req_wdata(s0_req_wdata), .req_wstrb(s0_req_wstrb),
    .rsp_valid(s0_rsp_valid), .rsp_ready(s0_rsp_ready), .rsp_rdata(s0_rsp_rdata), .rsp_err(s0_rsp_err), .oor_evt(s0_oor)
  );
  sfmp_tier_arb #(.NM(NM), .DW(DW), .MAXOUT(EM_OUT)) u_arb1 (
    .clk, .rst_n,
    .m_req_valid(m1_req_valid), .m_req_ready(m1_req_ready), .m_req_write(m1_req_write), .m_req_addr(m1_req_addr),
    .m_req_wdata(m1_req_wdata), .m_req_wstrb(m1_req_wstrb),
    .m_rsp_valid(m1_rsp_valid), .m_rsp_ready(m1_rsp_ready), .m_rsp_rdata(m1_rsp_rdata), .m_rsp_err(m1_rsp_err),
    .s_req_valid(em_req_valid), .s_req_ready(em_req_ready), .s_req_write(em_req_write), .s_req_addr(em_req_addr),
    .s_req_wdata(em_req_wdata), .s_req_wstrb(em_req_wstrb),
    .s_rsp_valid(em_rsp_valid), .s_rsp_ready(em_rsp_ready), .s_rsp_rdata(em_rsp_rdata), .s_rsp_err(em_rsp_error),
    .ev_slave_stall(ev1_ss), .ev_tag_stall(ev1_ts), .ev_loss(ev1_loss)
  );

  // master 0: tenant access path
  assign m0_req_valid[0] = a_t0_req_valid;  assign a_t0_req_ready = m0_req_ready[0];  assign m0_req_write[0] = a_t0_req_write;
  assign m0_req_addr[0*32 +: 32] = a_t0_req_addr;  assign m0_req_wdata[0*DW +: DW] = a_t0_req_wdata;  assign m0_req_wstrb[0*DWB +: DWB] = a_t0_req_wstrb;
  assign a_t0_rsp_valid = m0_rsp_valid[0];  assign m0_rsp_ready[0] = a_t0_rsp_ready;  assign a_t0_rsp_rdata = m0_rsp_rdata[0*DW +: DW];  assign a_t0_rsp_err = m0_rsp_err[0];
  assign m1_req_valid[0] = a_t1_req_valid;  assign a_t1_req_ready = m1_req_ready[0];  assign m1_req_write[0] = a_t1_req_write;
  assign m1_req_addr[0*32 +: 32] = a_t1_req_addr;  assign m1_req_wdata[0*DW +: DW] = a_t1_req_wdata;  assign m1_req_wstrb[0*DWB +: DWB] = a_t1_req_wstrb;
  assign a_t1_rsp_valid = m1_rsp_valid[0];  assign m1_rsp_ready[0] = a_t1_rsp_ready;  assign a_t1_rsp_rdata = m1_rsp_rdata[0*DW +: DW];  assign a_t1_rsp_err = m1_rsp_err[0];

  // master 1: scrubber (write-only)
  logic sc0_v, sc1_v;
  logic [31:0] sc0_a, sc1_a, sc_ev_bytes;
  logic [DW-1:0] sc_wd;
  logic [DWB-1:0] sc_ws;
  sfmp_scrub #(.DW(DW)) u_scrub (
    .clk, .rst_n, .start(sc_start), .tier(sc_tier), .base(sc_base), .len_bytes(sc_len), .idle(sc_idle), .done(sc_done), .err(sc_err),
    .t0_req_valid(sc0_v), .t0_req_ready(m0_req_ready[1]), .t0_req_addr(sc0_a), .t0_rsp_valid(m0_rsp_valid[1]), .t0_rsp_err(m0_rsp_err[1]),
    .t1_req_valid(sc1_v), .t1_req_ready(m1_req_ready[1]), .t1_req_addr(sc1_a), .t1_rsp_valid(m1_rsp_valid[1]), .t1_rsp_err(m1_rsp_err[1]),
    .req_wdata(sc_wd), .req_wstrb(sc_ws), .ev_bytes(sc_ev_bytes)
  );
  assign m0_req_valid[1] = sc0_v;  assign m0_req_write[1] = 1'b1;  assign m0_req_addr[1*32 +: 32] = sc0_a;
  assign m0_req_wdata[1*DW +: DW] = sc_wd;  assign m0_req_wstrb[1*DWB +: DWB] = sc_ws;  assign m0_rsp_ready[1] = 1'b1;
  assign m1_req_valid[1] = sc1_v;  assign m1_req_write[1] = 1'b1;  assign m1_req_addr[1*32 +: 32] = sc1_a;
  assign m1_req_wdata[1*DW +: DW] = sc_wd;  assign m1_req_wstrb[1*DWB +: DWB] = sc_ws;  assign m1_rsp_ready[1] = 1'b1;

  // ------------------------------------------------------------------ migration engine and its channels
  logic            me_done_evt, me_done_ok, me_timeout;
  logic [7:0]      me_done_result;
  logic [IW-1:0]   me_done_idx, me_cur_idx;
  logic [31:0]     me_done_cycles, me_done_bytes, me_done_frz;
  logic [MIG_CH-1:0]        d_req_valid, d_req_ready, d_req_write, d_rsp_valid, d_rsp_ready, d_rsp_err;
  logic [MIG_CH*32-1:0]     d_req_addr;
  logic [MIG_CH*DW-1:0]     d_req_wdata, d_rsp_rdata;
  logic [MIG_CH*DWB-1:0]    d_req_wstrb;
  logic [MIG_CH-1:0]        s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_err;
  logic [MIG_CH*32-1:0]     s_req_addr;
  logic [MIG_CH*DW-1:0]     s_req_wdata, s_rsp_rdata;
  logic [MIG_CH*DWB-1:0]    s_req_wstrb;
  logic [MIG_CH-1:0]        v0_req_valid, v0_req_ready, v0_rsp_valid, v0_rsp_err, v1_req_valid, v1_req_ready, v1_rsp_valid, v1_rsp_err;
  logic [MIG_CH*32-1:0]     v0_req_addr, v1_req_addr;
  logic [MIG_CH*DW-1:0]     v0_rsp_rdata, v1_rsp_rdata;

  sfmp_migrate #(.NCH(MIG_CH), .NR(NR), .ND(ND), .DW(DW), .GRAN_LG(GRAN_LG), .CHUNK_LG(CHUNK_LG), .MAXCHUNKS(MAXCHUNKS),
                 .PW(PW), .LW(LW), .GW(GW)) u_mig (
    .clk, .rst_n,
    .verify_en(ctl_verify), .max_rounds(mig_max_rounds), .freeze_thresh(mig_freeze_thresh), .max_retry(mig_max_retry),
    .start_valid(me_start), .start_idx(me_idx), .start_dir(me_dir), .start_dom(me_dom), .start_dram_base(me_dram_base),
    .start_sram_base(me_sram_base), .start_src_gran(me_src_gran), .start_dst_gran(me_dst_gran), .start_len_gran(me_len),
    .start_precopy(me_precopy), .busy(me_busy), .cur_idx(me_cur_idx),
    .mw_valid, .mw_idx, .mw_chunk(mw_chunk[CKW-1:0]), .infl_nz,
    .mg_op, .mg_idx, .mg_phys, .mg_err,
    .rel_req, .rel_tier, .rel_base, .rel_len, .rel_done,
    .done_evt(me_done_evt), .done_ok(me_done_ok), .done_result(me_done_result), .done_idx(me_done_idx), .done_cycles(me_done_cycles),
    .done_bytes(me_done_bytes), .done_frz_cycles(me_done_frz), .timeout_evt(me_timeout),
    .d_req_valid, .d_req_ready, .d_req_write, .d_req_addr, .d_req_wdata, .d_req_wstrb,
    .d_rsp_valid, .d_rsp_ready, .d_rsp_rdata, .d_rsp_err,
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_err,
    .v0_req_valid, .v0_req_ready, .v0_req_addr, .v0_rsp_valid, .v0_rsp_rdata, .v0_rsp_err,
    .v1_req_valid, .v1_req_ready, .v1_req_addr, .v1_rsp_valid, .v1_rsp_rdata, .v1_rsp_err,
    .inc_g(inc_g_mig), .inc_d(inc_d_mig)
  );
  assign mig_busy_o  = me_busy;

  genvar gj;
  generate
    for (gj = 0; gj < MIG_CH; gj++) begin : g_mm
      // DMA: DRAM side -> arbiter 1, SRAM side -> arbiter 0
      assign m1_req_valid[2+2*gj] = d_req_valid[gj];  assign d_req_ready[gj] = m1_req_ready[2+2*gj];  assign m1_req_write[2+2*gj] = d_req_write[gj];
      assign m1_req_addr[(2+2*gj)*32 +: 32] = d_req_addr[gj*32 +: 32];
      assign m1_req_wdata[(2+2*gj)*DW +: DW] = d_req_wdata[gj*DW +: DW];  assign m1_req_wstrb[(2+2*gj)*DWB +: DWB] = d_req_wstrb[gj*DWB +: DWB];
      assign d_rsp_valid[gj] = m1_rsp_valid[2+2*gj];  assign m1_rsp_ready[2+2*gj] = d_rsp_ready[gj];
      assign d_rsp_rdata[gj*DW +: DW] = m1_rsp_rdata[(2+2*gj)*DW +: DW];  assign d_rsp_err[gj] = m1_rsp_err[2+2*gj];
      assign m0_req_valid[2+2*gj] = s_req_valid[gj];  assign s_req_ready[gj] = m0_req_ready[2+2*gj];  assign m0_req_write[2+2*gj] = s_req_write[gj];
      assign m0_req_addr[(2+2*gj)*32 +: 32] = s_req_addr[gj*32 +: 32];
      assign m0_req_wdata[(2+2*gj)*DW +: DW] = s_req_wdata[gj*DW +: DW];  assign m0_req_wstrb[(2+2*gj)*DWB +: DWB] = s_req_wstrb[gj*DWB +: DWB];
      assign s_rsp_valid[gj] = m0_rsp_valid[2+2*gj];  assign m0_rsp_ready[2+2*gj] = s_rsp_ready[gj];
      assign s_rsp_rdata[gj*DW +: DW] = m0_rsp_rdata[(2+2*gj)*DW +: DW];  assign s_rsp_err[gj] = m0_rsp_err[2+2*gj];
      // verify reads: tier 0 and tier 1 (read-only masters, response always accepted)
      assign m0_req_valid[3+2*gj] = v0_req_valid[gj];  assign v0_req_ready[gj] = m0_req_ready[3+2*gj];  assign m0_req_write[3+2*gj] = 1'b0;
      assign m0_req_addr[(3+2*gj)*32 +: 32] = v0_req_addr[gj*32 +: 32];  assign m0_req_wdata[(3+2*gj)*DW +: DW] = '0;  assign m0_req_wstrb[(3+2*gj)*DWB +: DWB] = '0;
      assign v0_rsp_valid[gj] = m0_rsp_valid[3+2*gj];  assign m0_rsp_ready[3+2*gj] = 1'b1;
      assign v0_rsp_rdata[gj*DW +: DW] = m0_rsp_rdata[(3+2*gj)*DW +: DW];  assign v0_rsp_err[gj] = m0_rsp_err[3+2*gj];
      assign m1_req_valid[3+2*gj] = v1_req_valid[gj];  assign v1_req_ready[gj] = m1_req_ready[3+2*gj];  assign m1_req_write[3+2*gj] = 1'b0;
      assign m1_req_addr[(3+2*gj)*32 +: 32] = v1_req_addr[gj*32 +: 32];  assign m1_req_wdata[(3+2*gj)*DW +: DW] = '0;  assign m1_req_wstrb[(3+2*gj)*DWB +: DWB] = '0;
      assign v1_rsp_valid[gj] = m1_rsp_valid[3+2*gj];  assign m1_rsp_ready[3+2*gj] = 1'b1;
      assign v1_rsp_rdata[gj*DW +: DW] = m1_rsp_rdata[(3+2*gj)*DW +: DW];  assign v1_rsp_err[gj] = m1_rsp_err[3+2*gj];
    end
  endgenerate

  // length of the migration in progress (latched at start) for the policy's measured-cost feedback
  logic [LW-1:0] me_len_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)        me_len_q <= '0;
    else if (me_start) me_len_q <= me_len;
  end

  // ------------------------------------------------------------------ tiering policy
  logic        ev_pol_req, ev_pol_fail;
  logic [31:0] sc_rd_val;
  sfmp_policy #(.NR(NR), .LW(LW), .PERC(PERC)) u_policy (
    .clk, .rst_n,
    .pol_en(ctl_policy_en), .autocost(ctl_autocost), .autodelta(ctl_autodelta), .sram_ref(pol_sram_lat), .epoch_cycles(pol_epoch), .hot_min(pol_hot_min), .decay_shift(pol_decay),
    .cooldown_epochs(pol_cool), .horizon_epochs(pol_horizon), .cost_gran(pol_cost_gran), .cost_chunk(pol_cost_chunk),
    .delta(pol_delta), .margin_shift(pol_margin), .hyst_gap(pol_hyst), .high_wm(pol_high_wm),
    .sram_total(16'(G0)), .sram_used(16'(occ0)), .mig_busy(me_busy || me_start),
    .rt_idx(rd2_idx), .rt_ent(rd2_ent), .rt_consume(p_consume),
    .lat_sum0(cnt_g[sfmp_pkg::G_LAT_SUM_T0*64 +: 32]), .lat_cnt0(cnt_g[sfmp_pkg::G_LAT_CNT_T0*64 +: 32]),
    .lat_sum1(cnt_g[sfmp_pkg::G_LAT_SUM_T1*64 +: 32]), .lat_cnt1(cnt_g[sfmp_pkg::G_LAT_CNT_T1*64 +: 32]), .delta_est_o(pol_delta_est),
    .mig_done_evt(me_done_evt), .mig_done_ok(me_done_ok), .mig_done_cycles(me_done_cycles), .mig_done_len(me_len_q),
    .req_valid(pol_req_valid), .req_ready(pol_ready), .req_idx(pol_req_idx), .req_dst(pol_req_dst), .req_done(pol_done), .req_rc(pol_rc),
    .sc_rd_idx(rsel), .sc_rd_val, .cost_est_o(pol_cost_est), .scanning(pol_scanning), .epochs(pol_epochs),
    .ev_req(ev_pol_req), .ev_fail(ev_pol_fail)
  );
  assign p_idx = rd2_idx;

  // ------------------------------------------------------------------ register block
  logic [ND*16-1:0] use_sram_regs;
  assign use_sram_regs = use_sram;
  logic [sfmp_pkg::NG*64-1:0]       cnt_g;
  logic [ND*sfmp_pkg::NDC*64-1:0]   cnt_d;
  logic [15:0] peak0_q, peak1_q;

  sfmp_regs #(.ND(ND), .NR(NR), .GA(GA), .GRAN_LG(GRAN_LG), .DW(DW), .CHUNK_LG(CHUNK_LG), .G0(G0), .G1(G1),
              .MAXLEN(MAX_REGION_GRAN), .NCH(MIG_CH), .POOL_AW(POOL_AW)) u_regs (
    .clk, .rst_n,
    .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_priv, .rb_rdata, .rb_err,
    .ctl_policy_en, .ctl_precopy, .ctl_verify, .ctl_autocost, .ctl_autodelta, .mig_max_rounds, .mig_freeze_thresh, .mig_max_retry,
    .tlm_freeze, .tlm_clear,
    .cmd_pend, .cmd_o, .arg0_o(arg0), .arg1_o(arg1), .arg2_o(arg2), .arg3_o(arg3),
    .cmd_take, .cmd_done, .cmd_rc, .cmd_idx, .cmd_gen, .cmd_res0, .cmd_res1,
    .mig_busy(me_busy), .mig_done_evt(me_done_evt), .mig_done_ok(me_done_ok), .mig_done_result(me_done_result),
    .mig_done_idx(me_done_idx), .mig_done_cycles(me_done_cycles), .mig_done_bytes(me_done_bytes), .mig_start_evt(me_start),
    .lf_cause, .lf_port, .lf_dom, .lf_write, .lf_addr,
    .st_timeout(me_timeout), .st_inv(inv_evt), .st_oor(s0_oor),
    .occ0(16'(occ0)), .occ1(16'(occ1)), .peak0(peak0_q), .peak1(peak1_q),
    .rsel_o(rsel), .rent(rd1_ent), .r_score(sc_rd_val), .dsel_o(dsel),
    .dom_en, .dom_quar, .dom_autoq, .bind_dom, .dom_wbase, .dom_wlim, .dom_quota, .dom_use(use_sram_regs), .dom_live(live_cnt),
    .dom_latmax(dlat_max), .glat_max,
    .cnt_g, .cnt_d,
    .pol_epoch, .pol_hot_min, .pol_decay, .pol_cool, .pol_horizon, .pol_cost_gran, .pol_cost_chunk, .pol_delta, .pol_margin,
    .pol_hyst, .pol_high_wm, .pol_sram_lat, .pol_scanning, .pol_epochs, .pol_cost_est, .pol_delta_est,
    .ev_priv_viol, .ev_cmd_dropped
  );

  // ------------------------------------------------------------------ peak occupancy, pressure, top-level counter events
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin peak0_q <= '0; peak1_q <= '0; end
    else begin
      if (16'(occ0) > peak0_q) peak0_q <= 16'(occ0);
      if (16'(occ1) > peak1_q) peak1_q <= 16'(occ1);
    end
  end

  always_comb begin
    inc_g_top = '0;
    inc_g_top[sfmp_pkg::G_SCRUB_BYTES*32 +: 32] = sc_ev_bytes;
    inc_g_top[sfmp_pkg::G_ALLOC_OK*32 +: 32]    = {31'd0, ev_alloc_ok};
    inc_g_top[sfmp_pkg::G_ALLOC_FAIL*32 +: 32]  = {31'd0, ev_alloc_fail};
    inc_g_top[sfmp_pkg::G_FREE_OK*32 +: 32]     = {31'd0, ev_free_ok};
    inc_g_top[sfmp_pkg::G_CYCLES*32 +: 32]      = 32'd1;
    inc_g_top[sfmp_pkg::G_PRESS_CYC*32 +: 32]   = (16'(occ0) > pol_high_wm) ? 32'd1 : 32'd0;
    inc_g_top[sfmp_pkg::G_EM_STALL*32 +: 32]    = {31'd0, ev1_ss || ev1_ts};
    inc_g_top[sfmp_pkg::G_PRIV_VIOL*32 +: 32]   = {31'd0, ev_priv_viol};
    inc_g_top[sfmp_pkg::G_CMD_ERR*32 +: 32]     = {31'd0, ev_cmd_err};
    inc_g_top[sfmp_pkg::G_POL_REQ*32 +: 32]     = {31'd0, ev_pol_req};
    inc_g_top[sfmp_pkg::G_POL_FAIL*32 +: 32]    = {31'd0, ev_pol_fail};
  end

  sfmp_cntbank #(.N(sfmp_pkg::NG), .INC_W(32)) u_cnt_g (
    .clk, .rst_n, .inc_i(inc_g_acc | inc_g_mig | inc_g_top), .freeze_i(tlm_freeze), .clear_i(tlm_clear), .cnt_o(cnt_g)
  );
  sfmp_cntbank #(.N(ND * sfmp_pkg::NDC), .INC_W(32)) u_cnt_d (
    .clk, .rst_n, .inc_i(inc_d_acc | inc_d_mig), .freeze_i(tlm_freeze), .clear_i(tlm_clear), .cnt_o(cnt_d)
  );

  // ------------------------------------------------------------------ RAS / interrupt events (one per cycle, priority order)
  logic abort_evt;
  assign abort_evt = me_done_evt && !me_done_ok;
  always_comb begin
    ras_ev_valid = 1'b0; ras_ev_type = sfmp_pkg::EV_ILLEGAL_OP; ras_ev_addr = '0; ras_ev_info = '0;
    if (ev_media) begin
      ras_ev_valid = 1'b1; ras_ev_type = sfmp_pkg::EV_MEM_UE; ras_ev_addr = ev_media_addr;
    end else if (abort_evt && me_done_result != sfmp_pkg::MR_OK) begin
      ras_ev_valid = 1'b1; ras_ev_type = sfmp_pkg::EV_DMA_ERR; ras_ev_info = {24'd0, me_done_result};
    end else if (ev_priv_viol) begin
      ras_ev_valid = 1'b1; ras_ev_type = sfmp_pkg::EV_ILLEGAL_OP; ras_ev_addr = {20'd0, rb_addr};
    end else if (me_timeout) begin
      ras_ev_valid = 1'b1; ras_ev_type = sfmp_pkg::EV_TIMEOUT;
    end
  end
  assign irq_event = cmd_done || me_done_evt;
  assign irq_fault = ev_media || abort_evt || ev_priv_viol;

  wire unused_ok = &{1'b0, unused_now, lf_valid, bm0, bm1, al_idle, ev0_ts, ev0_ss, ev0_loss, ev1_loss, me_cur_idx,
                     me_done_frz, ctrl_busy, mw_chunk[CW-1], ev_cmd_dropped, er_code[7], dsel, m0_rsp_rdata, m1_rsp_rdata};
endmodule

`default_nettype wire
