# Source this: locates Verilator (>=5.0 with --binary/--timing) and sets common flags.
# VERILATOR_ROOT may be preset; otherwise the pip wheel layout is searched under $VENV or the PATH.
if [ -z "$VERILATOR" ]; then
  if command -v verilator >/dev/null 2>&1; then VERILATOR=verilator
  elif [ -n "$VENV" ] && [ -x "$VENV/lib/python3.13/site-packages/verilator/bin/verilator" ]; then
    export VERILATOR_ROOT="$VENV/lib/python3.13/site-packages/verilator"; VERILATOR="$VERILATOR_ROOT/bin/verilator"
  fi
fi
export VERILATOR
