#!/usr/bin/env python3
"""Generic structural synthesis check with Yosys (a *sanity* check, not an implementation result).

For every MemoryPool module (and the top) this runs, with default parameters:
    read_verilog -sv <all RTL>; hierarchy -top <m> -check; synth -noabc -top <m>; techmap; opt -fast; stat
and reports: success/timeout, latches, undriven/multiply-driven wire warnings, flip-flops and generic gate cells.

What this is NOT: no technology library, no timing, no area, no power.  The ABC step is skipped because the WebAssembly
build of Yosys used here terminates silently inside ABC, so the cell counts are *un-optimised generic gates* and must not
be quoted as area.  Their purpose is to catch non-synthesizable constructs, inferred latches, combinational loops and
accidental wide logic.

  tools/synth_check.py [--yosys PATH] [--timeout 900] [--only m1,m2] [--out reports]
"""
import argparse, os, re, subprocess, sys, time, json

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODULES = ["sfmp_cntbank", "sfmp_div32", "sfmp_tier_arb", "sfmp_sram_tier", "sfmp_scrub", "sfmp_alloc",
           "sfmp_region_table", "sfmp_access", "sfmp_mig_chan", "sfmp_migrate", "sfmp_ctrl", "sfmp_policy",
           "sfmp_regs", "silicaflux_memory_pool"]
EXTRA = {"sfmp_cxl_boundary_stub": ["rtl/future/sfmp_cxl_boundary_stub.sv"]}


# The vendored ASIC-macro wrapper hangs the Yosys front end (and is only instantiated for BACKEND=ASIC, which is not the
# configuration under test); it and the macro black boxes are left out.  The generic backend is what is synthesized.
SKIP = ("sram_asic_array.sv", "sram_macro_blackboxes.sv")


def rtl_files():
    files = []
    for ln in open(os.path.join(HERE, "rtl", "rtl_files.f")):
        ln = ln.split("//")[0].strip()
        if ln and not ln.startswith("+") and not ln.endswith(SKIP):
            files.append(ln)
    return files


def run_one(yosys, mod, files, timeout, outdir):
    rd = " ".join(files)
    script = (f"read_verilog -sv -I third_party/sramlib/rtl/mem -I third_party/sramlib/rtl/mem/backends/asic {rd}; "
              f"hierarchy -check -top {mod}; synth -noabc -top {mod}; techmap; opt -fast; stat")
    t0 = time.time()
    log = os.path.join(outdir, mod + ".log")
    try:
        p = subprocess.run([yosys, "-p", script], cwd=HERE, capture_output=True, text=True, timeout=timeout)
        txt = p.stdout + p.stderr
        rc = p.returncode
    except subprocess.TimeoutExpired as e:
        txt = (e.stdout or b"").decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")
        rc = "timeout"
    dt = time.time() - t0
    open(log, "w").write(txt)
    res = {"module": mod, "rc": rc, "secs": round(dt, 1)}
    if rc != 0:
        res["status"] = "FAIL" if rc != "timeout" else "TIMEOUT"
        res["error"] = next((l for l in txt.splitlines() if "ERROR" in l), "")
        return res
    # statistics of the top module only (last "=== mod ===" block, "design hierarchy" if present)
    m = re.search(r"=== design hierarchy ===(.*)", txt, re.S)
    blk = m.group(1) if m else txt
    if not m:
        parts = re.split(r"=== (\S+) ===", txt)
        blk = parts[-1] if len(parts) > 1 else txt
    cells = {}
    for ln in blk.splitlines():
        mm = re.match(r"\s+(\d+)\s+(\$_\w+_)\s*$", ln)
        if mm:
            cells[mm.group(2)] = int(mm.group(1))
    tot = re.findall(r"^\s+(\d+)\s+cells\s*$", blk, re.M)
    res["cells"] = int(tot[-1]) if tot else sum(cells.values())
    res["ffs"] = sum(v for k, v in cells.items() if "DFF" in k)
    res["latches"] = sum(v for k, v in cells.items() if "LATCH" in k)
    res["warnings"] = [l.strip() for l in txt.splitlines()
                       if re.match(r"\s*Warning:", l) and not re.search(r"Replacing memory", l)][:8]
    res["comb_loops"] = len(re.findall(r"found logic loop|logic loop", txt))
    res["status"] = "OK" if res["latches"] == 0 and res["comb_loops"] == 0 and not res["warnings"] else "ISSUE"
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--yosys", default=os.environ.get("YOSYS", "yowasp-yosys"))
    ap.add_argument("--timeout", type=int, default=900)
    ap.add_argument("--only", default="")
    ap.add_argument("--out", default=os.path.join(HERE, "reports"))
    a = ap.parse_args()
    od = os.path.join(a.out, "synth")
    os.makedirs(od, exist_ok=True)
    files = rtl_files()
    mods = [m for m in (a.only.split(",") if a.only else MODULES + list(EXTRA)) if m]
    results = []
    for m in mods:
        fl = files + EXTRA.get(m, [])
        r = run_one(a.yosys, m, fl, a.timeout, od)
        results.append(r)
        print(f"{m:26s} {r['status']:8s} {r.get('cells','-'):>7} cells {r.get('ffs','-'):>6} ff {r.get('latches','-')} latches  {r['secs']}s", flush=True)
    with open(os.path.join(a.out, "synth_results.json"), "w") as f:
        json.dump(results, f, indent=1)
    bad = [r for r in results if r["status"] != "OK"]
    print("SYNTH CHECK", "PASS" if not bad else "FAIL: " + ", ".join(r["module"] for r in bad))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
