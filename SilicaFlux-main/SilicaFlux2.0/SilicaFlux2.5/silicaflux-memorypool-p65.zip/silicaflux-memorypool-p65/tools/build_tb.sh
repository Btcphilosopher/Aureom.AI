#!/bin/bash
# Build a Verilator simulation of tb_pool.  usage: tools/build_tb.sh <build-dir> [verilator -G... overrides]
# Needs Verilator >= 5.0 with --binary/--timing and g++ >= 11 (coroutines).  Run from the project root.
set -e
B="$1"; shift
HERE="$(cd "$(dirname "$0")/.." && pwd)"; cd "$HERE"
. tools/env.sh
[ -n "$VERILATOR" ] || { echo "verilator not found (set VERILATOR or VENV)"; exit 2; }
mkdir -p "$B"
$VERILATOR --binary --timing -CFLAGS -fcoroutines -CFLAGS -O1 --x-initial unique --x-assign unique \
  -Wno-fatal -Werror-USERFATAL -Werror-USERERROR -Wno-lint -Wno-style -Wno-TIMESCALEMOD -Wno-SYMRSVDWORD --build-jobs ${BUILD_JOBS:-4} -MAKEFLAGS CFG_CXXFLAGS_PCH_I=-include \
  -Mdir "$B" +incdir+tb "$@" -f rtl/rtl_files.f model/sfmp_dram_model.sv tb/tb_pool.sv --top-module tb_pool -o tb_pool
