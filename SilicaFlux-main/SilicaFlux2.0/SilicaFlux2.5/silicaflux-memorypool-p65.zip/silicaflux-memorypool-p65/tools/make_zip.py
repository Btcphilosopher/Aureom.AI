#!/usr/bin/env python3
"""Package the deliverable zip: silicaflux-memorypool-p65.zip (top-level folder silicaflux-memorypool-p65/).

Included : rtl/ model/ third_party/ tb/ tools/ docs/ reports/ traces/ README.md Makefile  + MANIFEST.sha256 (SHA-256 of every file)
Excluded : build directories, Python caches, per-module Yosys logs (reports/synth/*.log -- regenerate with `make synth`),
           temporary trace files, editor/OS droppings.

  tools/make_zip.py [--out PATH]
"""
import argparse, hashlib, os, sys, zipfile, fnmatch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NAME = "silicaflux-memorypool-p65"
TOP = ["rtl", "model", "third_party", "tb", "tools", "docs", "reports", "traces", "README.md", "Makefile"]
EXCL_DIRS = {"__pycache__", "build", "traces_tmp", ".git", ".pytest_cache"}
EXCL_GLOBS = ["*.pyc", "*.o", "*.a", "*.swp", ".DS_Store", "reports/synth/*.log"]


def files():
    out = []
    for t in TOP:
        p = os.path.join(ROOT, t)
        if os.path.isfile(p):
            out.append(t)
            continue
        for dp, dns, fns in os.walk(p):
            dns[:] = sorted(d for d in dns if d not in EXCL_DIRS)
            for fn in sorted(fns):
                rel = os.path.relpath(os.path.join(dp, fn), ROOT)
                if any(fnmatch.fnmatch(rel, g) or fnmatch.fnmatch(fn, g) for g in EXCL_GLOBS):
                    continue
                out.append(rel)
    return sorted(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(os.path.dirname(ROOT), NAME + ".zip"))
    a = ap.parse_args()
    fl = files()
    manifest = []
    with zipfile.ZipFile(a.out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel in fl:
            data = open(os.path.join(ROOT, rel), "rb").read()
            manifest.append(f"{hashlib.sha256(data).hexdigest()}  {rel}")
            zi = zipfile.ZipInfo(f"{NAME}/{rel}", date_time=(2026, 1, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = (0o100000 | (0o755 if os.access(os.path.join(ROOT, rel), os.X_OK) else 0o644)) << 16
            z.writestr(zi, data)
        zi = zipfile.ZipInfo(f"{NAME}/MANIFEST.sha256", date_time=(2026, 1, 1, 0, 0, 0))
        zi.external_attr = (0o100000 | 0o644) << 16
        z.writestr(zi, "\n".join(manifest) + "\n", compress_type=zipfile.ZIP_DEFLATED)
    h = hashlib.sha256(open(a.out, "rb").read()).hexdigest()
    print(f"{a.out}: {len(fl)} files + MANIFEST.sha256, {os.path.getsize(a.out)} bytes, sha256 {h}")


if __name__ == "__main__":
    sys.exit(main())
