#!/usr/bin/env python3
"""Mutation campaign: inject one deliberate RTL bug at a time and require the verification suite to FAIL.

For every mutant the project is copied, one exact-text substitution (or a pair) is applied (the script refuses a
substitution that does not match exactly once), the default-configuration system testbench is rebuilt, and tests
t01..t12 are run with a fixed seed (a timeout or crash counts as detected).  Mutants of the migration channel's guard
are also run through the guard unit bench.  A mutant that PASSES the suite is a SURVIVOR: a hole in the tests (or an
equivalent mutant) that must be explained -- survivors are listed, never hidden.

  tools/mutate.py [--jobs 3] [--only M03,M07] [--out reports]
"""
import argparse, os, re, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

M = lambda *a, **k: (a, k)
# (id, property, description, [(file, old, new), ...], bench)  bench: "sys" | "guard" | "sys+guard"
MUTANTS = [
 ("M01", "quiesce", "dispatch continues into a FROZEN region", [("rtl/pool/sfmp_access.sv",
   "  wire frozen_blk = sel_v && !fault && (lk_mig == sfmp_pkg::MG_FROZEN);", "  wire frozen_blk = 1'b0;")], "sys"),
 ("M02", "isolation", "region owner is not checked (cross-tenant access allowed)", [("rtl/pool/sfmp_access.sv",
   "    else if (lk_dom != h_dom)                    cause = sfmp_pkg::FC_XTENANT;", "    else if (1'b0)                               cause = sfmp_pkg::FC_XTENANT;")], "sys"),
 ("M03", "permissions", "write permission is not checked", [("rtl/pool/sfmp_access.sv",
   "    else if (h_w ? !lk_perm_w : !lk_perm_r)      cause = sfmp_pkg::FC_PERM;", "    else if (h_w ? 1'b0 : !lk_perm_r)            cause = sfmp_pkg::FC_PERM;")], "sys"),
 ("M04", "no physical overlap", "allocator treats every granule as free", [("rtl/pool/sfmp_alloc.sv",
   "  wire          is_free  = !cur_bit;", "  wire          is_free  = 1'b1;")], "sys"),
 ("M05", "no PVA overlap", "PVA overlap check disabled", [("rtl/pool/sfmp_ctrl.sv",
   "    else if (ov_any)                      a_rc = sfmp_pkg::RC_OVERLAP;", "    else if (1'b0)                        a_rc = sfmp_pkg::RC_OVERLAP;")], "sys"),
 ("M06", "stale handles", "generation check disabled", [("rtl/pool/sfmp_ctrl.sv",
   "  wire gen_ok   = pol_q || (a1_q[7:0] == e_gen);", "  wire gen_ok   = 1'b1;")], "sys"),
 ("M07", "stale data", "scrubber writes ones instead of zeros", [("rtl/pool/sfmp_scrub.sv",
   "  assign req_wdata = '0;", "  assign req_wdata = '1;")], "sys"),
 ("M08", "migration verify", "CRC comparison always succeeds", [("rtl/pool/sfmp_mig_chan.sv",
   "            end else if (crc_dst_q == crc_src_q) begin", "            end else if (1'b1) begin")], "sys"),
 ("M09", "DMA guard", "per-beat DMA-side window check removed", [("rtl/pool/sfmp_mig_chan.sv",
   "  wire allow_h = job_act && (hm_req_addr >= dram_q) && ((hm_req_addr + 32'(DWB)) <= dram_hi) && (hm_req_write == dir_q);", "  wire allow_h = 1'b1;")], "guard"),
 ("M10", "dirty data", "writes during pre-copy no longer mark chunks dirty", [("rtl/pool/sfmp_migrate.sv",
   "      if (evt_c && !todo_q[mw_chunk]) dirty_q[mw_chunk] <= 1'b1;", "      if (1'b0) dirty_q[mw_chunk] <= 1'b1;")], "sys"),
 ("M11", "commit safety", "commit without waiting for in-flight accesses", [("rtl/pool/sfmp_migrate.sv",
   "                    (st_q == E_COMMIT && !infl_nz[idx_q]) ? sfmp_pkg::MGO_COMMIT :", "                    (st_q == E_COMMIT) ? sfmp_pkg::MGO_COMMIT :"),
   ("rtl/pool/sfmp_migrate.sv", "        E_COMMIT: if (!infl_nz[idx_q]) begin", "        E_COMMIT: begin")], "sys"),
 ("M12", "quiesce", "no drain of in-flight accesses before the final copy pass", [("rtl/pool/sfmp_migrate.sv",
   "        E_DRAIN: if (!infl_nz[idx_q]) begin", "        E_DRAIN: begin")], "sys"),
 ("M13", "release", "commit releases the destination extent instead of the source", [("rtl/pool/sfmp_migrate.sv",
   "ok_q <= 1'b1; res_q <= sfmp_pkg::MR_OK; rel_dst_q <= 1'b0; st_q <= E_REL;", "ok_q <= 1'b1; res_q <= sfmp_pkg::MR_OK; rel_dst_q <= 1'b1; st_q <= E_REL;")], "sys"),
 ("M14", "partial copy", "the final pass drops the remaining dirty chunks", [("rtl/pool/sfmp_migrate.sv",
   "          todo_q <= dirty_q | (evt_c ? ({{(MAXCHUNKS-1){1'b0}}, 1'b1} << mw_chunk) : '0);", "          todo_q <= '0;")], "sys"),
 ("M15", "privilege", "register writes accepted without privilege", [("rtl/pool/sfmp_regs.sv",
   "  wire   wr_ok          = wr && w_known && rb_priv;", "  wire   wr_ok          = wr && w_known;")], "sys"),
 ("M16", "anti-oscillation", "policy cooldown removed", [("rtl/pool/sfmp_policy.sv",
   "            cool_q[d_idx] <= cooldown_epochs;", "            cool_q[d_idx] <= 8'd0;")], "sys"),
 ("M17", "anti-oscillation", "policy hysteresis removed", [("rtl/pool/sfmp_policy.sv",
   "(bp_score >= vc_score + {12'd0, hyst_gap, 4'd0})", "1'b1")], "sys"),
 ("M18", "drain", "in-flight accounting not incremented at dispatch", [("rtl/pool/sfmp_access.sv",
   "        if (commit && lk_idx == IW'(r)) n = n + 4'd1;", "        if (1'b0 && lk_idx == IW'(r)) n = n + 4'd1;")], "sys"),
 ("M19", "telemetry", "service latency counter always zero", [("rtl/pool/sfmp_access.sv",
   "  assign lat0 = now_q - r0_tenq;", "  assign lat0 = 32'd0;")], "sys"),
 ("M20", "backpressure", "tier arbiter pops its response tag without waiting for the master", [("rtl/pool/sfmp_tier_arb.sv",
   "  wire pop = s_rsp_valid && s_rsp_ready;", "  wire pop = s_rsp_valid;")], "sys+tier"),
 ("M21", "allocation", "allocator marks one granule too many", [("rtl/pool/sfmp_alloc.sv",
   "          if ((i_q + 1'b1) == len_q) begin", "          if ((i_q) == len_q) begin")], "sys"),
 ("M22", "translation", "physical granule offset uses only 4 bits (wrong for long regions)", [("rtl/pool/sfmp_region_table.sv",
   "  assign lk_pgran  = ph_q[hit_idx] + PW'(lk_gran - pva_q[hit_idx]);", "  assign lk_pgran  = ph_q[hit_idx] + PW'(lk_gran[3:0] - pva_q[hit_idx][3:0]);")], "sys"),
 ("M23", "quota", "SRAM quota check ignores existing usage", [("rtl/pool/sfmp_ctrl.sv",
   "  wire sram_fits = ({16'd0, d_use} + len_g32 <= {16'd0, d_quota});", "  wire sram_fits = (len_g32 <= {16'd0, d_quota});")], "sys"),
 ("M24", "IOMMU boundary", "host DMA accepted without a valid translation", [("rtl/pool/sfmp_access.sv",
   "    else if (is_host && !h_xok)                  cause = sfmp_pkg::FC_IOMMU;", "    else if (1'b0)                               cause = sfmp_pkg::FC_IOMMU;")], "sys"),
]

# Mutants that cannot change the behaviour of the design (a redundant, defence-in-depth check).  They are still reported as
# SURVIVED -- the justification is printed next to them -- and they do not fail the campaign.
EQUIV = {
 "M11": "equivalent: the engine already waits for in-flight accesses in E_DRAIN, and a FROZEN region is never dispatched into "
        "(invariant I5, killed separately by M01), so the in-flight count can only fall between E_DRAIN and E_COMMIT; the check at "
        "E_COMMIT is a redundant safety net, and the commit-time monitor (`commit with an access in flight`) still guards it.",
}

def sh(cmd, cwd, timeout):
    try:
        r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout, cwd=cwd)
        return r.returncode, r.stdout, False
    except subprocess.TimeoutExpired as e:
        return -1, (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or ""), True

def run_mutant(args):
    mid, prop, desc, subs, bench, root, V = args
    d = os.path.join(root, mid)
    if os.path.exists(d): shutil.rmtree(d)
    shutil.copytree(HERE, d, ignore=shutil.ignore_patterns("build", "reports", "traces", ".git", "__pycache__"))
    for f, old, new in subs:
        p = os.path.join(d, f)
        s = open(p).read()
        if s.count(old) != 1:
            return mid, prop, desc, "INVALID", f"pattern matched {s.count(old)} times in {f}"
        open(p, "w").write(s.replace(old, new))
    env = dict(os.environ, VERILATOR=V)
    detected, why = False, ""
    if "sys" in bench:
        rc, out, _ = sh(["bash", os.path.join(d, "tools", "build_tb.sh"), os.path.join(d, "b")], d, 1800)
        if rc != 0: return mid, prop, desc, "INVALID", "build failed: " + out[-300:].replace("\n", " ")
        rc, out, to = sh([os.path.join(d, "b", "tb_pool"), "+test=all", "+verilator+rand+reset+2", "+verilator+seed+1"], d, 900)
        fails = [l for l in out.splitlines() if "FAIL" in l]
        passed = any(l.strip() == "TB RESULT PASS" for l in out.splitlines()) and not fails
        if to: detected, why = True, "timeout (hang)"
        elif not passed:
            detected = True
            why = (fails[0].strip() if fails else "no PASS line (crash)")[:150]
    if not detected and "tier" in bench:
        os.makedirs(os.path.join(d, "bt"), exist_ok=True)
        cmd = [V, "--binary", "--timing", "-CFLAGS", "-fcoroutines", "--x-initial", "unique", "--x-assign", "unique", "-Wno-fatal", "-Werror-USERFATAL", "-Werror-USERERROR", "-Wno-lint", "-Wno-style",
               "-Wno-TIMESCALEMOD", "-Wno-SYMRSVDWORD", "--build-jobs", os.environ.get("BUILD_JOBS", "4"), "-MAKEFLAGS", "CFG_CXXFLAGS_PCH_I=-include", "-Mdir", os.path.join(d, "bt"),
               "-f", "rtl/sram_files.f", "rtl/pkg/sfmp_pkg.sv", "rtl/pool/sfmp_tier_arb.sv", "rtl/pool/sfmp_sram_tier.sv", "rtl/pool/sfmp_scrub.sv", "model/sfmp_dram_model.sv", "tb/tb_tier_path.sv",
               "--top-module", "tb_tier_path", "-o", "ub"]
        rc, out, _ = sh(cmd, d, 1800)
        if rc != 0: return mid, prop, desc, "INVALID", "tier-path bench build failed"
        rc, out, to = sh([os.path.join(d, "bt", "ub"), "+verilator+rand+reset+2", "+verilator+seed+1"], d, 300)
        fails = [l for l in out.splitlines() if "FAIL" in l]
        passed = any(l.strip() == "TB RESULT PASS" for l in out.splitlines()) and not fails
        if to or not passed:
            detected, why = True, "tier-path unit bench: " + ((fails[0].strip() if fails else "timeout / no PASS")[:120])
    if not detected and "guard" in bench:
        os.makedirs(os.path.join(d, "bg"), exist_ok=True)
        cmd = [V, "--binary", "--timing", "-CFLAGS", "-fcoroutines", "--public-flat-rw", "--x-initial", "unique", "--x-assign", "unique", "-Wno-fatal", "-Werror-USERFATAL", "-Werror-USERERROR", "-Wno-lint", "-Wno-style",
               "-Wno-TIMESCALEMOD", "-Wno-SYMRSVDWORD", "--build-jobs", os.environ.get("BUILD_JOBS", "4"), "-MAKEFLAGS", "CFG_CXXFLAGS_PCH_I=-include", "-Mdir", os.path.join(d, "bg"),
               "-f", "rtl/rtl_files.f", "model/sfmp_dram_model.sv", "tb/tb_mig_guard.sv", "--top-module", "tb_mig_guard", "-o", "ub"]
        rc, out, _ = sh(cmd, d, 1800)
        if rc != 0: return mid, prop, desc, "INVALID", "guard bench build failed"
        rc, out, to = sh([os.path.join(d, "bg", "ub"), "+verilator+rand+reset+2", "+verilator+seed+1"], d, 300)
        fails = [l for l in out.splitlines() if "FAIL" in l]
        passed = any(l.strip() == "TB RESULT PASS" for l in out.splitlines()) and not fails
        if to or not passed:
            detected, why = True, "guard unit bench: " + ((fails[0].strip() if fails else "timeout")[:120])
    shutil.rmtree(d, ignore_errors=True)
    return mid, prop, desc, "KILLED" if detected else "SURVIVED", why

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--only", default="")
    ap.add_argument("--out", default=os.path.join(HERE, "reports"))
    a = ap.parse_args()
    V = subprocess.run(["bash", "-c", f". {HERE}/tools/env.sh; echo $VERILATOR"], stdout=subprocess.PIPE, text=True).stdout.strip()
    root = os.path.join(os.environ.get("TMPDIR", "/tmp"), "sfmp_mutants")
    os.makedirs(root, exist_ok=True)
    sel = [m for m in MUTANTS if not a.only or m[0] in a.only.split(",")]
    t0 = time.time()
    with ThreadPoolExecutor(a.jobs) as ex:
        results = list(ex.map(run_mutant, [(*m, root, V) for m in sel]))
    L = ["# Mutation campaign\n", f"{len(results)} deliberately injected RTL bugs; each must make the verification suite fail (`tools/mutate.py`, {time.time() - t0:.0f} s).\n",
         "| id | property under test | injected bug | result | first failing check |", "|---|---|---|---|---|"]
    results = [(m, p_, d_, ("SURVIVED (equivalent)" if st_ == "SURVIVED" and m in EQUIV else st_),
                (EQUIV[m] if st_ == "SURVIVED" and m in EQUIV else w_)) for m, p_, d_, st_, w_ in results]
    for mid, prop, desc, st, why in results:
        L.append(f"| {mid} | {prop} | {desc} | **{st}** | {why.replace('|', '/')} |")
        print(f"{mid} {st:9s} {prop:18s} {desc}  -> {why[:90]}", flush=True)
    k = sum(r[3] == "KILLED" for r in results); inv = sum(r[3] == "INVALID" for r in results)
    eq = sum(r[3].startswith("SURVIVED (eq") for r in results); s = sum(r[3] == "SURVIVED" for r in results)
    L += ["", f"**{k} killed, {s + eq} survived ({eq} documented as equivalent, {s} unexplained), {inv} invalid** of {len(results)}.", ""]
    os.makedirs(a.out, exist_ok=True)
    open(os.path.join(a.out, "mutation.md"), "w").write("\n".join(L) + "\n")
    print(f"killed {k}, survived {s + eq} ({eq} documented equivalent, {s} unexplained), invalid {inv}")
    return 0 if (s == 0 and inv == 0) else 1

if __name__ == "__main__":
    sys.exit(main())
