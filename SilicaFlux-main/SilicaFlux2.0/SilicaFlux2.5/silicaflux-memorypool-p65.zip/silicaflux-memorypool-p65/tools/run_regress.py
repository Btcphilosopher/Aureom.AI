#!/usr/bin/env python3
"""MemoryPool regression: lint, illegal-parameter refusal, vendor check, unit benches, system suite (configs x seeds).

Every simulation run must print an explicit `TB RESULT PASS`; a missing line (crash, timeout, truncated output) is a
FAILURE, never a pass.  The tenant-isolation suite (t10) is run FIRST in every configuration and the multi-tenant
performance workloads are only meaningful if it passed (tools/perf_report.py refuses to run without reports/regression.json
showing isolation = PASS).

  tools/run_regress.py [--build-root build] [--seeds 1,2,3] [--configs default,wide,small] [--no-build] [--jobs 3]
"""
import argparse, json, os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIGS = {
    "default": [],
    "wide":    ["-GDW=64", "-GMIG_CH=2"],                              # 64-bit datapath, two CloudDMA migration channels
    "small":   ["-GND=8", "-GRQ=2", "-GEM_OUT=1", "-GT_REFI=200"],     # 8 domains, queue depth 2, one outstanding external request, frequent refresh
}
LINT_CONFIGS = {
    "default": [],
    "wide64":  ["-GDATA_WIDTH=64", "-GNUM_DOMAINS=2", "-GNUM_REGIONS=8", "-GMIG_CH=2"],
    "max":     ["-GNUM_DOMAINS=8", "-GNUM_REGIONS=32", "-GMIG_CH=4", "-GRQ_DEPTH=2"],
    "bigGran": ["-GGRAN_LG=10", "-GCHUNK_LG=8", "-GSRAM_BYTES=131072", "-GDRAM_BYTES=1048576", "-GMAX_REGION_GRAN=16"],
}
ILLEGAL = [  # (overrides, text that must appear in the elaboration error)
    (["-GNUM_DOMAINS=0"], "NUM_DOMAINS must be"), (["-GNUM_DOMAINS=9"], "NUM_DOMAINS must be"),
    (["-GNUM_REGIONS=3"], "NUM_REGIONS must be"), (["-GNUM_REGIONS=33"], "NUM_REGIONS must be"),
    (["-GDATA_WIDTH=16"], "DATA_WIDTH must be"), (["-GDATA_WIDTH=128"], "DATA_WIDTH must be"),
    (["-GGRAN_LG=13"], "CHUNK_LG <= GRAN_LG"), (["-GGRAN_LG=5", "-GCHUNK_LG=6"], "CHUNK_LG <= GRAN_LG"),
    (["-GCHUNK_LG=1"], "chunk must hold"), (["-GSRAM_BYTES=3000"], "powers of two"), (["-GDRAM_BYTES=100000"], "powers of two"),
    (["-GMAX_REGION_GRAN=0"], "MAX_REGION_GRAN must be"), (["-GMAX_REGION_GRAN=300"], "MAX_REGION_GRAN must be"),
    (["-GMIG_CH=0"], "MIG_CH must be"), (["-GMIG_CH=5"], "MIG_CH must be"), (["-GRQ_DEPTH=1"], "RQ_DEPTH >= 2"),
    (["-GPOOL_AW=40"], "POOL_AW - GRAN_LG"),
]

def sh(cmd, timeout=3600, cwd=HERE):
    t = time.time()
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout, cwd=cwd)
    return r.returncode, r.stdout, time.time() - t

def verilator():
    sys.path.insert(0, os.path.join(HERE, "tools"))
    out = subprocess.run(["bash", "-c", f". {HERE}/tools/env.sh; echo $VERILATOR"], stdout=subprocess.PIPE, text=True).stdout.strip()
    if not out: sys.exit("verilator not found: set VERILATOR or VENV (see tools/env.sh)")
    return out

def lint(V, extra):
    cmd = [V, "--lint-only", "-Wall", "-Werror-USERFATAL", "-Werror-USERERROR", "-Wno-DECLFILENAME", "-Wno-UNUSEDPARAM", "-Wno-SYMRSVDWORD", *extra, "-f", "rtl/rtl_files.f", "--top-module", "silicaflux_memory_pool"]
    rc, out, _ = sh(cmd)
    return rc, [l for l in out.splitlines() if l.startswith("%Warning") or l.startswith("%Error")], out

def parse_result(out):
    passed = any(l.strip() == "TB RESULT PASS" for l in out.splitlines())
    fails = [l for l in out.splitlines() if "FAIL" in l]
    m = re.search(r"tests complete: (\d+) test assertions \+ (\d+) monitor checks, (\d+) errors, (\d+) migration commits cross-checked \((\d+) bytes", out)
    stats = dict(assertions=int(m[1]), monitor=int(m[2]), errors=int(m[3]), commits=int(m[4]), commit_bytes=int(m[5])) if m else {}
    return passed and not fails, stats, fails

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--build-root", default=os.path.join(HERE, "build"))
    ap.add_argument("--seeds", default="1,2,3")
    ap.add_argument("--configs", default=",".join(CONFIGS))
    ap.add_argument("--no-build", action="store_true")
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--out", default=os.path.join(HERE, "reports"))
    a = ap.parse_args()
    V = verilator()
    os.makedirs(a.out, exist_ok=True)
    os.makedirs(a.build_root, exist_ok=True)
    res = dict(lint={}, illegal={}, vendor=None, unit={}, system={}, isolation_first={})
    ok_all = True
    t0 = time.time()

    # ---- vendor
    rc, out, _ = sh([sys.executable, "-I", os.path.join(HERE, "tools", "check_vendor.py")])
    res["vendor"] = dict(rc=rc, text=out.strip().splitlines()[-1]); ok_all &= rc == 0
    print("vendor:", res["vendor"]["text"])

    # ---- lint
    for name, ov in LINT_CONFIGS.items():
        rc, warns, out = lint(V, ov)
        good = (rc == 0 and not warns)
        res["lint"][name] = dict(ok=good, warnings=len(warns)); ok_all &= good
        print(f"lint {name:8s}: {'0 warnings' if good else str(len(warns)) + ' warnings/errors'}")
        if not good: print("\n".join(warns[:8]))
    # ---- illegal parameter sets must be refused at elaboration
    n_ref = 0; n_expl = 0
    for ov, text in ILLEGAL:
        rc, warns, out = lint(V, ov)
        refused = rc != 0 and "%Error" in out            # by the explicit check, or by a downstream elaboration error
        n_ref += refused
        n_expl += refused and (text in out)
        res["illegal"][" ".join(ov)] = refused
        if not refused: print("NOT REFUSED:", ov, "expected:", text); ok_all = False
    print(f"illegal parameter sets refused at elaboration: {n_ref}/{len(ILLEGAL)} ({n_expl} by the explicit readable check)")

    # ---- builds
    jobs = []
    for name in a.configs.split(","):
        jobs.append((name, os.path.join(a.build_root, name), CONFIGS[name]))
    def build(j):
        name, d, ov = j
        if a.no_build and os.path.exists(os.path.join(d, "tb_pool")): return name, 0, ""
        rc, out, dt = sh(["bash", os.path.join(HERE, "tools", "build_tb.sh"), d, *ov])
        return name, rc, out
    with ThreadPoolExecutor(a.jobs) as ex:
        for name, rc, out in ex.map(build, jobs):
            if rc != 0: print("BUILD FAILED", name, out[-600:]); ok_all = False

    # ---- unit benches
    unit = {
        "tier_path": ["tb/tb_tier_path.sv", "rtl/pkg/sfmp_pkg.sv rtl/pool/sfmp_tier_arb.sv rtl/pool/sfmp_sram_tier.sv rtl/pool/sfmp_scrub.sv model/sfmp_dram_model.sv", "tb_tier_path", []],
        "mig_chan_guard": ["tb/tb_mig_guard.sv", "", "tb_mig_guard", ["--public-flat-rw"]],
    }
    for name, (tbf, srcs, top, extra) in unit.items():
        d = os.path.join(a.build_root, "unit_" + name)
        os.makedirs(d, exist_ok=True)
        files = ["-f", "rtl/rtl_files.f", "model/sfmp_dram_model.sv", tbf] if name == "mig_chan_guard" else ["-f", "rtl/sram_files.f", *srcs.split(), tbf]
        cmd = [V, "--binary", "--timing", "-CFLAGS", "-fcoroutines", "--x-initial", "unique", "--x-assign", "unique", "-Wno-fatal", "-Werror-USERFATAL", "-Werror-USERERROR", "-Wno-lint", "-Wno-style",
               "-Wno-TIMESCALEMOD", "-Wno-SYMRSVDWORD", "--build-jobs", "4", "-MAKEFLAGS", "CFG_CXXFLAGS_PCH_I=-include", *extra, "-Mdir", d, *files, "--top-module", top, "-o", "ub"]
        rc, out, _ = sh(cmd)
        if rc != 0: print("unit build failed", name, out[-400:]); ok_all = False; continue
        allok = True
        for seed in a.seeds.split(","):
            rc, out, _ = sh([os.path.join(d, "ub"), "+verilator+rand+reset+2", f"+verilator+seed+{seed}"], timeout=600)
            p, st, f = parse_result(out)
            p = any(l.strip() == "TB RESULT PASS" for l in out.splitlines()) and not [l for l in out.splitlines() if "FAIL" in l]
            allok &= p
        res["unit"][name] = allok; ok_all &= allok
        print(f"unit {name}: {'PASS' if allok else 'FAIL'} ({len(a.seeds.split(','))} seeds)")

    # ---- system suite: isolation first, then everything
    def run_sys(args):
        cfg, seed, test = args
        d = os.path.join(a.build_root, cfg)
        rc, out, dt = sh([os.path.join(d, "tb_pool"), f"+test={test}", "+verilator+rand+reset+2", f"+verilator+seed+{seed}"], timeout=3600)
        p, st, f = parse_result(out)
        return cfg, seed, test, p, st, f, dt
    for cfg in a.configs.split(","):
        r = run_sys((cfg, a.seeds.split(",")[0], "t10"))
        res["isolation_first"][cfg] = r[3]
        print(f"isolation suite first, config {cfg}: {'PASS' if r[3] else 'FAIL'}")
        ok_all &= r[3]
    todo = [(cfg, seed, "all") for cfg in a.configs.split(",") for seed in a.seeds.split(",")]
    with ThreadPoolExecutor(a.jobs) as ex:
        for cfg, seed, test, p, st, f, dt in ex.map(run_sys, todo):
            res["system"][f"{cfg}/seed{seed}"] = dict(passed=p, **st)
            ok_all &= p
            print(f"system {cfg:8s} seed {seed}: {'PASS' if p else 'FAIL'}  {st.get('assertions', 0)} assertions + {st.get('monitor', 0)} monitor checks, "
                  f"{st.get('commits', 0)} commits ({st.get('commit_bytes', 0)} bytes) cross-checked  ({dt:.0f}s)")
            if not p: print("\n".join(f[:6]))
    res["all_passed"] = bool(ok_all)
    res["isolation_pass"] = all(res["isolation_first"].values())
    res["wall_seconds"] = round(time.time() - t0)
    json.dump(res, open(os.path.join(a.out, "regression.json"), "w"), indent=1)

    L = ["# Regression report\n", f"Generated by `tools/run_regress.py` in {res['wall_seconds']} s. Every run must print an explicit `TB RESULT PASS`.\n",
         f"**Overall: {'PASS' if ok_all else 'FAIL'}**\n", "## Static checks\n",
         f"* Vendored third-party RTL: {res['vendor']['text']}",
         "* Verilator `-Wall` lint: " + ", ".join(f"{k}: {'0 warnings' if v['ok'] else 'FAILED'}" for k, v in res["lint"].items()),
         f"* Illegal parameter sets refused at elaboration: {n_ref}/{len(ILLEGAL)} ({n_expl} with the explicit `$fatal` message; the rest by a downstream elaboration error; Verilator reports `$fatal`/`$error` as warning classes, so every flow must pass `-Werror-USERFATAL -Werror-USERERROR`)\n", "## Unit benches\n"]
    for k, v in res["unit"].items(): L.append(f"* `{k}`: {'PASS' if v else 'FAIL'} (seeds {a.seeds})")
    L += ["", "## System suite (`tb_pool`, tests t01..t12 in one run)\n",
          "Configurations: " + "; ".join(f"**{k}** = {' '.join(v) or 'defaults'}" for k, v in CONFIGS.items() if k in a.configs.split(",")) + "\n",
          "| run | result | explicit test assertions | monitor checks | migration commits compared byte-for-byte | bytes compared |", "|---|---|---|---|---|---|"]
    for k, v in res["system"].items():
        L.append(f"| {k} | {'PASS' if v['passed'] else 'FAIL'} | {v.get('assertions', 0)} | {v.get('monitor', 0)} | {v.get('commits', 0)} | {v.get('commit_bytes', 0)} |")
    L += ["", "Isolation suite (t10) run first in each configuration: " + ", ".join(f"{k}: {'PASS' if v else 'FAIL'}" for k, v in res["isolation_first"].items()), ""]
    open(os.path.join(a.out, "regression.md"), "w").write("\n".join(L) + "\n")
    print("OVERALL:", "PASS" if ok_all else "FAIL", f"({res['wall_seconds']} s)")
    return 0 if ok_all else 1

if __name__ == "__main__":
    sys.exit(main())
