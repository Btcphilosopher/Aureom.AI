#!/usr/bin/env python3
"""Run the MemoryPool workload matrix in simulation and write reports/PERFORMANCE.md (+ CSV + raw REPORT dumps).

Every number comes from a simulation run of the RTL (tb_pool, +test=trace).  Nothing is estimated.  For every run
the script checks that (a) the testbench printed `TB RESULT PASS` (all data integrity, isolation and migration
checks passed, including the byte-for-byte source==destination comparison at every migration commit), and (b) the
DUT's own telemetry counters agree with what the testbench measured independently (completed accesses, bytes).

usage:  tools/perf_report.py --tb build/perf/tb_pool [--n 12000] [--seed 1] [--workloads a,b,...] [--out reports]
"""
import argparse, csv, json, os, re, subprocess, sys, time

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
G = dict(ACC=0, ACC_RD=1, ACC_WR=2, ACC_T0=3, ACC_T1=4, BYTES_RD=5, BYTES_WR=6, BYTES_T0=7, BYTES_T1=8, LAT_SUM=9, LAT_CNT=10,
         REJECT=11, VIOL=12, QFULL=13, HEADBLK=14, FRZBLK=15, MIG_OK=16, MIG_ABORT=17, MIG_BYTES=18, MIG_VBYTES=19, MIG_RECOPY=20,
         MIG_FRZ_CYC=21, MIG_ACT_CYC=22, MIG_RETRY=23, SCRUB_BYTES=24, ALLOC_OK=25, ALLOC_FAIL=26, FREE_OK=27, MEDIA_ERR=28, CYCLES=29,
         PRESS_CYC=30, EM_STALL=31, POL_REQ=42, POL_FAIL=43)
HIST_UB = [8, 16, 32, 64, 256, 1024, 8192, None]

MATRIX = {
    "seq":      ["dram", "auto", "static", "dyn_pre", "dyn_stop"],
    "rand":     ["dram", "auto", "static", "dyn_pre", "dyn_stop"],
    "hotcold":  ["dram", "auto", "static", "dyn_pre", "dyn_stop"],
    "mixed":    ["dram", "auto", "static", "dyn_pre", "dyn_stop"],
    "migload":  ["dram", "static", "mig_pre", "mig_stop"],
    "oversub":  ["dram", "auto", "dyn_pre", "dyn_stop"],
    "frag":     ["dram", "auto", "dyn_pre"],
    "frag_ctl": ["auto", "dyn_pre"],
    "skew":     ["dram", "auto", "static", "dyn_pre", "dyn_stop"],
}
DESC = {
    "seq": "sequential streaming (every domain, 16 KiB footprint each, 64 KiB total vs 32 KiB SRAM)",
    "rand": "uniform random access (same footprint, no locality to exploit)",
    "hotcold": "hot/cold data: one 4 KiB region per domain takes 85 % of the accesses",
    "mixed": "mixed tenants: hot/cold + streaming + random + write-heavy, with per-domain SRAM quotas",
    "migload": "migration under load: a 16 KiB region is migrated at cycle 30000 while three other tenants run",
    "oversub": "oversubscription: 128 KiB footprint vs 32 KiB SRAM, hot set (2 of 8 regions per domain) moves every quarter",
    "frag": "region fragmentation: 8 KiB hot regions, SRAM fragmented (holes of 4 KiB)",
    "frag_ctl": "control for 'frag': identical SRAM free space, but contiguous",
    "skew": "access skew: Zipf(1.1) over 16 regions, popularity re-shuffled half way",
}

def run(cmd, timeout=3600):
    t = time.time()
    r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
    return r.stdout, time.time() - t

def parse(out):
    rep, passed = {}, False
    for line in out.splitlines():
        m = re.match(r"REPORT (\S+) (-?\d+)", line)
        if m: rep[m.group(1)] = int(m.group(2))
        if "TB RESULT PASS" in line: passed = True
    return rep, passed

def metrics(rep):
    g = lambda k: rep.get(f"g{G[k]}", 0)
    ops = g("ACC")
    cyc = rep["total_cycles"]
    hist = [rep.get(f"hist{i}", 0) for i in range(8)]
    tot = sum(hist) or 1
    acc, p99 = 0, ">8192"
    for i, c in enumerate(hist):
        acc += c
        if acc >= 0.99 * tot:
            p99 = f"<={HIST_UB[i]}" if HIST_UB[i] else ">8192"
            break
    pdone = [rep[f"port{q}_done_cycle"] for q in range(9) if f"port{q}_done_cycle" in rep]
    m = dict(
        mean_port=sum(pdone) / len(pdone) if pdone else cyc,
        cycles=cyc, ops=ops, thr=1000.0 * ops / cyc if cyc else 0,
        mean=g("LAT_SUM") / g("LAT_CNT") if g("LAT_CNT") else 0, p99=p99, maxlat=rep.get("lat_max_dut", 0),
        hit=g("ACC_T0") / ops if ops else 0, mig_ok=g("MIG_OK"), mig_abort=g("MIG_ABORT"),
        mig_copy=g("MIG_BYTES"), mig_ver=g("MIG_VBYTES"), recopy=g("MIG_RECOPY"), frz=g("MIG_FRZ_CYC"), act=g("MIG_ACT_CYC"),
        retry=g("MIG_RETRY"), pol_req=g("POL_REQ"), pol_fail=g("POL_FAIL"), qfull=g("QFULL"), headblk=g("HEADBLK"), frzblk=g("FRZBLK"),
        bytes=g("BYTES_RD") + g("BYTES_WR"), em_stall=g("EM_STALL"), reject=g("REJECT"),
        row_hit=rep.get("dram_row_hit", 0) / max(1, rep.get("dram_row_hit", 0) + rep.get("dram_row_closed", 0) + rep.get("dram_row_conf", 0)),
        sram_peak=rep.get("sram_peak", 0), tb_ops=rep.get("tb_ops", 0), tb_mean=rep.get("tb_lat_sum", 0) / max(1, rep.get("tb_ops", 1)),
        mig_cmd_ok=rep.get("mig_cmd_ok", 0), mig_cmd_refused=rep.get("mig_cmd_refused", 0), cost_est=rep.get("cost_est", 0),
        dom=[dict(acc=rep.get(f"d{d}_0", 0), t0=rep.get(f"d{d}_1", 0), lat=rep.get(f"d{d}_4", 0) / max(1, rep.get(f"d{d}_5", 1)),
                  viol=rep.get(f"d{d}_6", 0)) for d in range(4)],
    )
    m["mig_overhead"] = m["act"] / cyc if cyc else 0
    m["mig_bytes_ratio"] = (m["mig_copy"] + m["mig_ver"]) / m["bytes"] if m["bytes"] else 0
    return m

def fmt(x, nd=2):
    return f"{x:.{nd}f}"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tb", required=True)
    ap.add_argument("--n", type=int, default=12000)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--sram-kib", type=int, default=32)
    ap.add_argument("--workloads", default=",".join(MATRIX))
    ap.add_argument("--out", default=os.path.join(HERE, "reports"))
    ap.add_argument("--workdir", default=None)
    ap.add_argument("--amortization", action="store_true", help="also run the hot/cold workload at several run lengths")
    ap.add_argument("--skip-gate", action="store_true", help="development only: run even if the isolation suite has not passed (noted in the report)")
    ap.add_argument("--determinism", action="store_true", help="repeat one run and require bit-identical reports")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    # verification gate: multi-tenant workloads only after the isolation suite has passed (docs/02_TENANT_ISOLATION.md, section 5)
    gate_ok, gate_note = False, "reports/regression.json missing"
    try:
        gate_ok = bool(json.load(open(os.path.join(a.out, "regression.json"))).get("isolation_pass"))
        gate_note = "isolation suite (t10) passed in every regression configuration" if gate_ok else "isolation suite has NOT passed"
    except Exception:
        pass
    if not gate_ok and not a.skip_gate:
        sys.exit(f"refusing to run multi-tenant workloads: {gate_note}. Run tools/run_regress.py first (or --skip-gate for development).")
    raw = os.path.join(a.out, "perf_raw"); os.makedirs(raw, exist_ok=True)
    wd = a.workdir or os.path.join(a.out, "traces_tmp"); os.makedirs(wd, exist_ok=True)

    # calibrate: idle latency delta between the tiers (the same measurement T12 makes)
    results, problems = {}, []
    t_all = time.time()
    for wl in a.workloads.split(","):
        results[wl] = {}
        for mode in MATRIX[wl]:
            tf = os.path.join(wd, f"{wl}_{mode}.trace")
            gen = [sys.executable, os.path.join(HERE, "tools", "trace_gen.py"), "--workload", wl,
                   "--mode", mode, "--seed", str(a.seed), "--n", str(a.n), "--sram-kib", str(a.sram_kib), "--out", tf]
            subprocess.run(gen, check=True)
            out, dt = run([a.tb, "+test=trace", f"+trace={tf}", "+verilator+rand+reset+2", f"+verilator+seed+{a.seed}"])
            rep, ok = parse(out)
            with open(os.path.join(raw, f"{wl}_{mode}.txt"), "w") as f:
                f.write("\n".join(l for l in out.splitlines() if l.startswith("REPORT") or "FAIL" in l or "RESULT" in l or "tests complete" in l) + "\n")
            if not ok or "total_cycles" not in rep:
                problems.append(f"{wl}/{mode}: run did not pass\n" + "\n".join(l for l in out.splitlines() if "FAIL" in l)[:800])
                continue
            m = metrics(rep)
            if m["ops"] != m["tb_ops"]:
                problems.append(f"{wl}/{mode}: DUT counted {m['ops']} accesses, the testbench {m['tb_ops']}")
            results[wl][mode] = m
            print(f"  {wl:9s} {mode:9s} {m['cycles']:8d} cycles  mean {m['mean']:6.2f}  SRAM {100*m['hit']:5.1f}%  migrations {m['mig_ok']:3d}  ({dt:.0f}s)", flush=True)
    if a.determinism:
        wl, mode = "hotcold", "dyn_pre"
        tf = os.path.join(wd, f"{wl}_{mode}.trace")
        o1, _ = run([a.tb, "+test=trace", f"+trace={tf}", "+verilator+rand+reset+2", f"+verilator+seed+{a.seed}"])
        o2, _ = run([a.tb, "+test=trace", f"+trace={tf}", "+verilator+rand+reset+2", f"+verilator+seed+{a.seed}"])
        r1 = [l for l in o1.splitlines() if l.startswith("REPORT")]
        r2 = [l for l in o2.splitlines() if l.startswith("REPORT")]
        print("determinism: two runs of hotcold/dyn_pre produce", "IDENTICAL" if r1 == r2 else "DIFFERENT", "reports")
        if r1 != r2: problems.append("non-deterministic report")
    amort = {}
    if a.amortization:
        for n in (3000, 6000, 12000, 24000, 48000):
            amort[n] = {}
            for mode in ("dram", "static", "dyn_pre", "dyn_stop"):
                tf = os.path.join(wd, f"amort_{n}_{mode}.trace")
                subprocess.run([sys.executable, os.path.join(HERE, "tools", "trace_gen.py"), "--workload", "hotcold", "--mode", mode, "--seed", str(a.seed),
                                "--n", str(n), "--sram-kib", str(a.sram_kib), "--out", tf], check=True)
                out, dt = run([a.tb, "+test=trace", f"+trace={tf}", "+verilator+rand+reset+2", f"+verilator+seed+{a.seed}"])
                rep, ok = parse(out)
                if not ok or "total_cycles" not in rep: problems.append(f"amortization n={n} {mode}: run did not pass"); continue
                amort[n][mode] = metrics(rep)
                print(f"  amort n={n:6d} {mode:9s} {amort[n][mode]['cycles']:8d} cycles", flush=True)
    results["_amort"] = {str(k): v for k, v in amort.items()} if amort else {}
    json.dump(results, open(os.path.join(a.out, "perf_results.json"), "w"), indent=1)
    results.pop("_amort", None)

    # ------------------------------------------------------------------ CSV
    with open(os.path.join(a.out, "perf_results.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["workload", "mode", "makespan_cycles", "mean_port_finish_cycles", "accesses", "throughput_per_kcycle", "mean_latency", "p99_latency", "max_latency", "sram_hit_ratio",
                    "migrations", "aborts", "mig_copy_bytes", "mig_verify_bytes", "chunk_recopies", "frozen_cycles", "mig_active_cycles",
                    "mig_overhead", "policy_requests", "policy_refused", "queue_full_cycles", "head_blocked_cycles", "freeze_stall_cycles"])
        for wl, d in results.items():
            for mode, m in d.items():
                w.writerow([wl, mode, m["cycles"], fmt(m["mean_port"], 1), m["ops"], fmt(m["thr"], 3), fmt(m["mean"], 3), m["p99"], m["maxlat"], fmt(m["hit"], 4), m["mig_ok"],
                            m["mig_abort"], m["mig_copy"], m["mig_ver"], m["recopy"], m["frz"], m["act"], fmt(m["mig_overhead"], 4), m["pol_req"],
                            m["pol_fail"], m["qfull"], m["headblk"], m["frzblk"]])

    # ------------------------------------------------------------------ Markdown
    L = []
    L.append("# MemoryPool performance report (simulation)\n")
    L.append("Generated by `tools/perf_report.py` from RTL simulation runs (Verilator). **Every figure below is a measurement of a simulated run; nothing is estimated.**\n")
    L.append(f"**Verification gate:** {gate_note}{' (BYPASSED with --skip-gate)' if (not gate_ok) else ''}.\n")
    L.append("## Platform and method\n")
    sp = next(iter(next(iter(results.values())).values()), None)
    L.append(f"* Pool: 4 domains, DATA_WIDTH 32, granule 256 B, chunk 64 B, **SRAM tier {a.sram_kib} KiB** (SRAM Wrapper Library cell, 3-cycle idle service latency), "
             f"**DRAM tier 256 KiB modelled** (`sfmp_dram_model`: row-hit 12 / closed 24 / conflict 36 cycles + refresh, up to 4 outstanding — *model parameters, not a DDR device*), "
             f"**2 migration channels** (2 CloudDMA instances), pre-copy rounds 3 / freeze threshold 2 chunks / verify (CRC read-back) on.")
    L.append(f"* Policy (dyn modes): epoch 8192 cycles, EWMA decay 1/2, hot_min 4 accesses/epoch, cooldown 4 epochs, horizon 16 epochs, hysteresis 8 accesses/epoch, **migration cost and per-access benefit both measured by the hardware** (cost: cycles/granule of completed migrations, seeded 1100; benefit: mean tier-1 minus mean tier-0 service latency per epoch, seeded 11, tier-0 reference 3 cycles while tier 0 has no samples).")
    L.append(f"* Each run: {a.n} accesses per active port, closed loop (next access issues after the previous response + 1 cycle), seed {a.seed}; identical access stream in every mode of a workload. "
             f"`cycles` = time from the first access to the last response, **including all migration stalls**; the migration engine's DMA/verify traffic competes with tenant traffic on both tier ports.")
    L.append("* Modes: `dram` = no tiering (everything in DRAM) · `auto` = first-come-first-served SRAM (naive tiering) · `static` = oracle placement of the hot regions in SRAM · `dyn_pre` / `dyn_stop` = baseline policy with pre-copy / stop-and-copy migration · `mig_pre` / `mig_stop` = one manual migration at a fixed time.")
    L.append("* Integrity: every run passed the testbench's data-integrity sweep, isolation monitors and the byte-for-byte source==destination check at every migration commit; DUT counters equal the testbench's own counts of accesses and bytes.\n")
    if problems:
        L.append("## PROBLEMS\n")
        for p in problems: L.append("* " + p)
        L.append("")
    modes = ["auto", "static", "dyn_pre", "dyn_stop", "mig_pre", "mig_stop"]
    for title, key in (("makespan (time until the LAST tenant finishes; all migration overhead included)", "cycles"),
                       ("mean per-tenant completion time (average of the ports' finish times; what the average tenant experiences)", "mean_port")):
        L.append(f"## Summary: speed-up over `dram` (no tiering) by {title}\n")
        L.append("| workload | " + " | ".join(modes) + " |")
        L.append("|---|" + "---|" * len(modes))
        for wl, d in results.items():
            base = d.get("dram") or (results.get("frag", {}).get("dram") if wl == "frag_ctl" else None) or d.get("auto")
            cells = []
            for mode in modes:
                if mode in d and base:
                    cells.append(f"{base[key] / d[mode][key]:.2f}x")
                else: cells.append("-")
            L.append(f"| {wl} | " + " | ".join(cells) + " |")
        L.append("")
    L.append("(`frag_ctl` is normalised to the `dram` run of `frag` (same footprint). A value below 1.00x means the mode was SLOWER than not tiering at all.)\n")
    for wl, d in results.items():
        L.append(f"## {wl} — {DESC[wl]}\n")
        L.append("| mode | makespan (cycles) | mean tenant finish | accesses/kcycle | mean latency | p99 | max | SRAM hit | migrations | copy+verify bytes / tenant bytes | frozen cycles | engine busy | re-copied chunks | policy req/refused |")
        L.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|---|")
        for mode, m in d.items():
            L.append(f"| {mode} | {m['cycles']} | {fmt(m['mean_port'],0)} | {fmt(m['thr'])} | {fmt(m['mean'])} | {m['p99']} | {m['maxlat']} | {fmt(100*m['hit'],1)} % | {m['mig_ok']}"
                     f"{' (+%d aborted)' % m['mig_abort'] if m['mig_abort'] else ''} | {fmt(m['mig_bytes_ratio'],3)} | {m['frz']} | {fmt(100*m['mig_overhead'],1)} % | {m['recopy']} | {m['pol_req']}/{m['pol_fail']} |")
        if wl == "mixed":
            L.append("\nPer-domain mean service latency (cycles) and share of accesses served from SRAM:\n")
            L.append("| mode | dom0 hot/cold | dom1 stream | dom2 random | dom3 write-heavy |")
            L.append("|---|---|---|---|---|")
            for mode, m in d.items():
                L.append(f"| {mode} | " + " | ".join(f"{fmt(x['lat'])} ({fmt(100*x['t0']/max(1,x['acc']),0)} %)" for x in m["dom"]) + " |")
        L.append("")
    if "frag" in results and "frag_ctl" in results:
        L.append("## Fragmentation effect (same free space, different layout)\n")
        L.append("| layout | mode | makespan | mean tenant finish | SRAM hit | policy requests / refused |")
        L.append("|---|---|---|---|---|---|")
        for lay in ("frag", "frag_ctl"):
            for mode, m in results[lay].items():
                if mode in ("auto", "dyn_pre"):
                    L.append(f"| {lay} | {mode} | {m['cycles']} | {fmt(m['mean_port'],0)} | {fmt(100*m['hit'],1)} % | {m['pol_req']}/{m['pol_fail']} |")
        L.append("")
    if amort:
        L.append("## Amortization: how long must a workload run before migration pays off? (hot/cold, 12000-access baseline scaled)\n")
        L.append("Speed-up over `dram` by makespan, same access pattern, run length varied (accesses per port):\n")
        L.append("| accesses per port | dram cycles | static (oracle) | dyn_pre | dyn_stop |")
        L.append("|---|---|---|---|---|")
        for n, d in amort.items():
            if "dram" not in d: continue
            L.append(f"| {n} | {d['dram']['cycles']} | " + " | ".join(f"{d['dram']['cycles'] / d[m]['cycles']:.2f}x" if m in d else "-" for m in ("static", "dyn_pre", "dyn_stop")) + " |")
        L.append("")
    L.append(f"_Total wall-clock for the matrix: {time.time() - t_all:.0f} s on this machine. Raw per-run reports: `reports/perf_raw/`. CSV: `reports/perf_results.csv`._\n")
    open(os.path.join(a.out, "PERFORMANCE.md"), "w").write("\n".join(L) + "\n")
    print("wrote", os.path.join(a.out, "PERFORMANCE.md"))
    if problems:
        print("PROBLEMS:"); [print(" -", p) for p in problems]
        return 1
    return 0

if __name__ == "__main__":
    sys.exit(main())
