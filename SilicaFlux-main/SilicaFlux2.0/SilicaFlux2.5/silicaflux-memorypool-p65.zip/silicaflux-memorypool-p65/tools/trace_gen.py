#!/usr/bin/env python3
"""MemoryPool memory-trace generator.

Writes a workload trace (format documented in tb/tb_tests.svh) for tb_pool's `+test=trace +trace=<file>`.
Everything is deterministic: the same (workload, mode, seed, geometry) always produces the same file, and the
ACCESS STREAM is identical across modes -- only the placement / policy header differs -- so the modes are
directly comparable.

Workloads
  seq      every domain streams sequentially (wrapping) through its own 16 KiB, 10 % writes
  rand     every domain accesses its own 16 KiB uniformly at random, 30 % writes
  hotcold  every domain: 4 regions of 4 KiB, one hot region takes 85 % of the accesses
  mixed    four different tenants at once (hot/cold, streaming, random, write-heavy hot/cold) with per-domain SRAM quotas
  migload  three hot/cold tenants plus one tenant whose 16 KiB hot region is migrated by management at a fixed time
  oversub  footprint 4x the SRAM; each domain's hot set (2 of 8 regions) moves every quarter of the run
  frag     SRAM is fragmented before two 8 KiB hot regions are placed (and a control with an unfragmented SRAM)
  skew     one tenant, four ports, 16 regions, Zipf(1.1) popularity that is re-shuffled half way through

Modes
  dram     everything in DRAM, policy off                       (baseline: no tiering)
  auto     PREF_AUTO allocation (fast memory first-come-first-served), policy off   (naive tiering)
  static   oracle placement of the hot regions in SRAM, policy off                    (best static, where one exists)
  sram     everything in SRAM where it fits, policy off                               (upper bound)
  dyn_pre  everything starts in DRAM, baseline policy on, PRE-COPY migration
  dyn_stop everything starts in DRAM, baseline policy on, STOP-AND-COPY migration
  (migload only)  mig_pre / mig_stop: one manual promotion at a fixed time, pre-copy or stop-and-copy
"""
import argparse, math, random, sys

DOMSZ = 1 << 20
RS = 4096                      # region size used by most workloads

def zipf_weights(n, s):
    w = [1.0 / ((k + 1) ** s) for k in range(n)]
    t = sum(w)
    return [x / t for x in w]

def pick(rng, cum):
    r = rng.random()
    for i, c in enumerate(cum):
        if r <= c:
            return i
    return len(cum) - 1

def cumulative(w):
    out, a = [], 0.0
    for x in w:
        a += x
        out.append(a)
    return out

class Trace:
    def __init__(self, a):
        self.a = a
        self.lines = []
        self.regs = {}                       # id -> (dom, pva, bytes)
        self.nid = 0
        self.acc = {}                        # port -> list of (gap, rw, pva)
    def cfg(self, s): self.lines.append(s)
    def reg(self, dom, pva, size, pref, perm=3, pin=0):
        self.nid += 1
        self.regs[self.nid] = (dom, pva, size)
        self.lines.append(f"REG {self.nid} {dom} {pva:x} {size} {pref} {perm} {pin}")
        return self.nid
    def free(self, rid): self.lines.append(f"FREE {rid}")
    def access(self, port, gap, rw, pva): self.acc.setdefault(port, []).append((gap, rw, pva))
    def write(self, path, header):
        with open(path, "w") as f:
            f.write("\n".join(header) + "\n")
            f.write("\n".join(self.lines) + "\n")
            for p in sorted(self.acc):
                for gap, rw, pva in self.acc[p]:
                    f.write(f"A {p} {gap} {rw} {pva:x}\n")

def policy_header(a, mode):
    h = []
    if mode == "dyn_pre":    h.append("CTRL 1f")       # policy | pre-copy | verify | auto-cost | auto-delta
    elif mode == "dyn_stop": h.append("CTRL 1d")       # policy | verify | auto-cost | auto-delta (stop-and-copy)
    elif mode == "mig_stop": h.append("CTRL 4")        # policy off, verify on, STOP-AND-COPY (the one manual migration freezes its region)
    else:                    h.append("CTRL 6")        # policy off, pre-copy, verify
    h += [f"POL epoch {a.epoch}", "POL hot_min 4", "POL decay 1", "POL cooldown 4", f"POL horizon {a.horizon}",
          "POL cost_gran 1100", "POL cost_chunk 400", f"POL delta {a.delta}", "POL margin 1", "POL hyst 8"]
    return h

def pref_for(mode, hot=False, fits=True):
    """placement preference at allocation time for a region"""
    if mode in ("dram", "dyn_pre", "dyn_stop", "mig_pre", "mig_stop"): return 1
    if mode == "auto": return 2
    if mode == "sram": return 0 if fits else 2
    if mode == "static": return 0 if hot else 1
    raise ValueError(mode)

def gen(a):
    rng = random.Random(a.seed)
    tr = Trace(a)
    n = a.n
    mode = a.mode
    sram_regions = a.sram_kib * 1024 // RS          # how many 4 KiB regions fit in SRAM
    head = policy_header(a, mode)
    head.insert(0, f"# workload={a.workload} mode={mode} seed={a.seed} n={n} sram_kib={a.sram_kib}")

    def domain_regions(d, k, hot_idx=None, hotcount=1):
        ids = []
        for i in range(k):
            hot = (hot_idx is not None and i in hot_idx)
            ids.append(tr.reg(d, d * DOMSZ + i * RS, RS, pref_for(mode, hot=hot, fits=True)))
        return ids

    words = RS // 4

    if a.workload == "seq":
        for d in range(4):
            # first half of the domains' footprints are "hot" for the static oracle: all equally hot, so pick domains 0,1
            for i in range(4):
                tr.reg(d, d * DOMSZ + i * RS, RS, pref_for(mode, hot=(d < 2), fits=(d < 2)))
        for d in range(4):
            pos = 0
            for _ in range(n):
                rw = "W" if rng.random() < 0.10 else "R"
                tr.access(d, 1, rw, d * DOMSZ + (pos % (4 * words)) * 4)
                pos += 1
    elif a.workload == "rand":
        for d in range(4):
            for i in range(4):
                tr.reg(d, d * DOMSZ + i * RS, RS, pref_for(mode, hot=(d < 2), fits=(d < 2)))
        for d in range(4):
            for _ in range(n):
                tr.access(d, 1, "W" if rng.random() < 0.30 else "R", d * DOMSZ + rng.randrange(4 * words) * 4)
    elif a.workload in ("hotcold", "mixed", "migload"):
        hot = [rng.randrange(4) for _ in range(4)]
        if a.workload == "mixed":
            for d in range(4): tr.cfg(f"DOM {d} {a.sram_kib * 1024 // 256 // 4} 0")      # SRAM quota = 1/4 of the SRAM per tenant
        if a.workload == "migload":
            # tenant 3: one 16 KiB region, manually promoted
            for d in range(3):
                for i in range(4):
                    tr.reg(d, d * DOMSZ + i * RS, RS, pref_for(mode, hot=(i == hot[d]), fits=True))
            big = tr.reg(3, 3 * DOMSZ, 16384, 1 if mode != "static" else 0)
            if mode in ("mig_pre", "mig_stop"):
                tr.cfg(f"EVT {a.mig_at} MIG {big} 0")
        else:
            for d in range(4):
                for i in range(4):
                    tr.reg(d, d * DOMSZ + i * RS, RS, pref_for(mode, hot=(i == hot[d]), fits=True))
        for d in range(4):
            for k in range(n):
                if a.workload == "migload" and d == 3:
                    tr.access(d, 1, "W" if rng.random() < 0.20 else "R", d * DOMSZ + rng.randrange(4096) * 4)
                    continue
                kind = a.workload == "mixed" and d
                if a.workload == "mixed" and d == 1:           # streaming tenant
                    tr.access(d, 1, "R", d * DOMSZ + ((k * 4) % (4 * RS)))
                    continue
                if a.workload == "mixed" and d == 2:           # uniform random tenant
                    tr.access(d, 1, "R" if rng.random() < 0.7 else "W", d * DOMSZ + rng.randrange(4 * words) * 4)
                    continue
                wfrac = 0.5 if (a.workload == "mixed" and d == 3) else 0.25
                reg = hot[d] if rng.random() < 0.85 else rng.randrange(4)
                tr.access(d, 1, "W" if rng.random() < wfrac else "R", d * DOMSZ + reg * RS + rng.randrange(words) * 4)
    elif a.workload == "oversub":
        phases = 4
        for d in range(4):
            for i in range(8):
                # naive FCFS (auto) fills SRAM with whichever regions were allocated first
                tr.reg(d, d * DOMSZ + i * RS, RS, pref_for(mode, hot=False, fits=False))
        hot_sets = [[rng.sample(range(8), 2) for _ in range(phases)] for _ in range(4)]
        for d in range(4):
            for k in range(n):
                ph = min(phases - 1, k * phases // n)
                reg = rng.choice(hot_sets[d][ph]) if rng.random() < 0.90 else rng.randrange(8)
                tr.access(d, 1, "W" if rng.random() < 0.25 else "R", d * DOMSZ + reg * RS + rng.randrange(words) * 4)
    elif a.workload in ("frag", "frag_ctl"):
        # domain 3 owns pinned filler regions that fragment the SRAM; domains 0 and 1 own the 8 KiB hot regions
        per = 4096
        fill = []
        nfill = a.sram_kib * 1024 // per                 # fillers of 4 KiB fill the SRAM exactly
        for k in range(nfill):
            fill.append(tr.reg(3, 3 * DOMSZ + k * per, per, 0, 3, 1))
        if a.workload == "frag":
            for k in range(0, nfill, 2): tr.free(fill[k])                  # every other filler freed: holes of 4 KiB
        else:
            for k in range(nfill // 2): tr.free(fill[k])                   # control: the freed half is contiguous
        hotreg = []
        for d in (0, 1):
            hotreg.append(tr.reg(d, d * DOMSZ, 8192, 2 if mode != "dyn_pre" else 1))
        for d in (0, 1):
            for _ in range(n):
                tr.access(d, 1, "W" if rng.random() < 0.20 else "R", d * DOMSZ + rng.randrange(8192 // 4) * 4)
    elif a.workload == "skew":
        for i in range(16):
            tr.reg(0, i * RS, RS, pref_for(mode, hot=(i < 4), fits=(i < 8)))
        for p in range(1, 4): tr.cfg(f"BIND {p} 0")
        w = zipf_weights(16, 1.1)
        cum1 = cumulative(w)
        perm = list(range(16)); rng.shuffle(perm)
        for p in range(4):
            for k in range(n):
                r = pick(rng, cum1)
                if k >= n // 2: r = perm[r]                                  # popularity re-shuffled halfway
                tr.access(p, 1, "W" if rng.random() < 0.2 else "R", r * RS + (rng.randrange(words) * 4 + p * 4 * 0) % RS)
    else:
        sys.exit(f"unknown workload {a.workload}")
    tr.write(a.out, head)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workload", required=True)
    ap.add_argument("--mode", required=True)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--n", type=int, default=12000, help="accesses per port")
    ap.add_argument("--sram-kib", type=int, default=32)
    ap.add_argument("--epoch", type=int, default=8192)
    ap.add_argument("--horizon", type=int, default=16)
    ap.add_argument("--delta", type=int, default=11, help="DRAM-SRAM latency difference (cycles), from the calibration step")
    ap.add_argument("--mig-at", type=int, default=30000)
    ap.add_argument("--out", required=True)
    gen(ap.parse_args())

if __name__ == "__main__":
    main()
