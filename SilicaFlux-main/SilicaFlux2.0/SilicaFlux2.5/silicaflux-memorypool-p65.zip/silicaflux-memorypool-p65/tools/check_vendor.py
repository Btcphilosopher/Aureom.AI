#!/usr/bin/env python3
"""Verify the vendored third-party files are byte-identical to what was recorded (and, optionally,
to the original archive members in a repository checkout).

  tools/check_vendor.py                 # hashes against third_party/SHA256SUMS
  tools/check_vendor.py --repo <path>   # additionally compare with the archive inside the repo checkout
"""
import argparse, hashlib, io, os, sys, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TP = os.path.join(ROOT, "third_party")
P61 = "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-clouddpu-p61.zip"
P61_PREFIX = "silicaflux-clouddpu-p61/"
SRAM_PREFIX = P61_PREFIX + "third_party/silicaflux-controlcore/third_party/silicaflux-sramlib/rtl/mem/"

def sha(b): return hashlib.sha256(b).hexdigest()

def member_for(rel):
    """Map a third_party-relative path to the member path inside the P61 archive."""
    if rel.startswith("clouddpu/rtl/"):
        name = os.path.basename(rel)
        sub = "rtl/pkg/" if name == "silicaflux_cloud_pkg.sv" else "rtl/dpu/"
        return P61_PREFIX + sub + name
    if rel.startswith("sramlib/rtl/mem/"):
        return SRAM_PREFIX + rel[len("sramlib/rtl/mem/"):]
    return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", help="path to a checkout of btcphilosopher/Aureom.AI")
    a = ap.parse_args()
    bad = 0
    recorded = {}
    with open(os.path.join(TP, "SHA256SUMS")) as f:
        for line in f:
            h, p = line.split(None, 1)
            recorded[p.strip().lstrip("./")] = h
    files = []
    for d, _, fs in os.walk(TP):
        for n in fs:
            if n in ("SHA256SUMS", "PROVENANCE.md"): continue
            files.append(os.path.relpath(os.path.join(d, n), TP))
    for rel in sorted(files):
        h = sha(open(os.path.join(TP, rel), "rb").read())
        if recorded.get(rel) != h:
            print(f"MISMATCH vs SHA256SUMS: {rel}"); bad += 1
    for rel in recorded:
        if rel not in files:
            print(f"MISSING: {rel}"); bad += 1
    n_arch = 0
    if a.repo:
        z_outer = zipfile.ZipFile(os.path.join(a.repo, P61))
        if True:
            for rel in sorted(files):
                m = member_for(rel)
                if m is None:
                    print(f"no archive mapping: {rel}"); bad += 1; continue
                try:
                    data = z_outer.read(m)
                except KeyError:
                    print(f"NOT IN ARCHIVE: {m}"); bad += 1; continue
                n_arch += 1
                if sha(data) != recorded.get(rel):
                    print(f"DIFFERS FROM ARCHIVE: {rel}"); bad += 1
    print(f"vendor check: {len(files)} files, archive-compared {n_arch}, problems {bad}")
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main())
