# Mutation campaign

24 deliberately injected RTL bugs; each must make the verification suite fail (`tools/mutate.py`, 4728 s).

| id | property under test | injected bug | result | first failing check |
|---|---|---|---|---|
| M01 | quiesce | dispatch continues into a FROZEN region | **KILLED** | [5539020000] FAIL (T05_dirty_v0) [monitor]: access dispatched into a FROZEN region |
| M02 | isolation | region owner is not checked (cross-tenant access allowed) | **KILLED** | [15376766000] FAIL (T10_isolation): cross-tenant read of 0 leaked data (err=0 code=0 data=3947e6cb) |
| M03 | permissions | write permission is not checked | **KILLED** | [372326000] FAIL (T03_perms): write to a read-only region err=0 code=0 |
| M04 | no physical overlap | allocator treats every granule as free | **KILLED** | [338530000] FAIL (T01_alloc_free) [monitor]: regions 0 and 2 overlap physically |
| M05 | no PVA overlap | PVA overlap check disabled | **KILLED** | [350110000] FAIL (T02_overlap) [monitor]: regions 0 and 1 overlap in PVA |
| M06 | stale handles | generation check disabled | **KILLED** | [309946000] FAIL (T01_alloc_free): free with wrong generation rc=0 |
| M07 | stale data | scrubber writes ones instead of zeros | **KILLED** | [3466000] FAIL (T01_alloc_free): port 0 read 0: got ffffffff expected 00000000 |
| M08 | migration verify | CRC comparison always succeeds | **KILLED** | [16460930000] FAIL (T11_faults) [monitor]: COMMIT with 1 bytes of the destination differing from the source (region 0) |
| M09 | DMA guard | per-beat DMA-side window check removed | **KILLED** | guard unit bench: [136236000] FAIL: G5: expected MR_GUARD, got fail=0 code=0 |
| M10 | dirty data | writes during pre-copy no longer mark chunks dirty | **KILLED** | [5373900000] FAIL (T05_dirty_v0) [monitor]: COMMIT with 1511 bytes of the destination differing from the source (region 0) |
| M11 | commit safety | commit without waiting for in-flight accesses | **SURVIVED (equivalent)** | equivalent: the engine already waits for in-flight accesses in E_DRAIN, and a FROZEN region is never dispatched into (invariant I5, killed separately by M01), so the in-flight count can only fall between E_DRAIN and E_COMMIT; the check at E_COMMIT is a redundant safety net, and the commit-time monitor (`commit with an access in flight`) still guards it. |
| M12 | quiesce | no drain of in-flight accesses before the final copy pass | **KILLED** | [10492300000] FAIL (T05d_stalled_write) [monitor]: commit with dirty / pending chunks |
| M13 | release | commit releases the destination extent instead of the source | **KILLED** | [669426000] FAIL (T04_migrate_stop_and_copy): extents after promotion (old DRAM extent released, SRAM reserved) |
| M14 | partial copy | the final pass drops the remaining dirty chunks | **KILLED** | [540500000] FAIL (T04_migrate_stop_and_copy) [monitor]: COMMIT with 3060 bytes of the destination differing from the source (region 0) |
| M15 | privilege | register writes accepted without privilege | **KILLED** | [386666000] FAIL (T03_perms): CTRL changed by a non-privileged write |
| M16 | anti-oscillation | policy cooldown removed | **KILLED** | [21832876000] FAIL (T12c_oscillation_unprotected): protection did not reduce migrations: protected 10 vs unprotected 10 |
| M17 | anti-oscillation | policy hysteresis removed | **KILLED** | [25153716000] FAIL (T12h_hysteresis_off): hysteresis gap 24 did not stop a swap of two almost equally hot regions (10 requests) |
| M18 | drain | in-flight accounting not incremented at dispatch | **KILLED** | [45875236000] FAIL (T05_dirty_v1): migration did not complete |
| M19 | telemetry | service latency counter always zero | **KILLED** | [17481656000] FAIL (T12a_promote): calibration: idle SRAM service latency 0.000000 cycles is implausible (expected about 3) |
| M20 | backpressure | tier arbiter pops its response tag without waiting for the master | **KILLED** | tier-path unit bench: [109110000] FAIL: tier 0 master 1: response withdrawn before acceptance (SFB2 R2) |
| M21 | allocation | allocator marks one granule too many | **KILLED** | [800000] FAIL (T01_alloc_free) [monitor]: SRAM occupancy counter != bitmap popcount |
| M22 | translation | physical granule offset uses only 4 bits (wrong for long regions) | **KILLED** | [2488776000] FAIL (T04_migrate_stop_and_copy): port 1 read 100000: got b8ece42e expected 4f682fdb |
| M23 | quota | SRAM quota check ignores existing usage | **KILLED** | [14318646000] FAIL (T08_exhaust): quota exhausted |
| M24 | IOMMU boundary | host DMA accepted without a valid translation | **KILLED** | [15487866000] FAIL (T10_isolation): host DMA without an IOMMU translation was served |

**23 killed, 1 survived (1 documented as equivalent, 0 unexplained), 0 invalid** of 24.

