# SilicaFlux Project 65 — MemoryPool

A programmable **memory tiering and allocation accelerator** for the SilicaFlux CloudDPU (Aureom.AI). Primary RTL: [`rtl/silicaflux_memory_pool.sv`](rtl/silicaflux_memory_pool.sv).

It manages per-tenant **regions** in a managed address window, places each region in **on-chip SRAM** or **external DRAM**, translates and protects every access, measures real traffic, and **migrates** regions between tiers with the vendored CloudDMA without ever exposing a partial copy.

> **Status in one paragraph.** RTL + testbench + reports, verified **in simulation only** (Verilator). The DRAM tier is a **behavioural model** — there is no DRAM controller or PHY. **There is no CXL implementation and no coherence claim**; `rtl/future/sfmp_cxl_boundary_stub.sv` is a non-functional placeholder and `docs/CXL_ADAPTER_SPEC.md` is a study. No silicon, FPGA or area/timing result exists. See [`docs/07_LIMITATIONS.md`](docs/07_LIMITATIONS.md).

## What is in the zip

| Path | Content |
|---|---|
| `rtl/silicaflux_memory_pool.sv`, `rtl/pool/sfmp_*.sv`, `rtl/pkg/sfmp_pkg.sv` | the design (top, region table/mapping engine, allocator, access path, migration engine + channels, scrubber, tiering policy, command engine, register page, counters) |
| `rtl/future/sfmp_cxl_boundary_stub.sv` | **non-functional** future tier-2 boundary (device "not present") |
| `model/sfmp_dram_model.sv` | simulation-only DRAM model (bank/row timing, refresh, fault injection) |
| `third_party/` | vendored, **unmodified**: SRAM Wrapper Library (P01), CloudDMA + SFB2 gate + package (P61); `SHA256SUMS`, `PROVENANCE.md` |
| `tb/` | system testbench (`tb_pool.sv`, `tb_tests.svh`: golden model, monitors, tests T01–T12, trace replay) and two unit benches |
| `tools/` | `run_regress.py`, `perf_report.py`, `trace_gen.py` (memory trace generator), `mutate.py`, `synth_check.py`, `gen_regmap.py`, `check_vendor.py`, `make_zip.py` |
| `docs/` | `00_AUDIT` … `08_PERFORMANCE_ANALYSIS`, `CXL_ADAPTER_SPEC`, `REGISTER_MAP` (generated) |
| `reports/` | `regression.md/json`, `PERFORMANCE.md` + `perf_results.csv/json` + `perf_raw/`, `mutation.md`, `synth_results.json` |
| `MANIFEST.sha256` | SHA-256 of every file in the zip |

## Quick start

```bash
# Verilator >= 5 with --binary/--timing and g++ >= 11 are required (tools/env.sh finds verilator on PATH or under $VENV).
make check-vendor check-map     # vendored files unchanged; register map current
make lint                       # Verilator -Wall: zero warnings
make regress                    # lint, 17 illegal-parameter refusals, unit benches, system suite x 3 configs x 3 seeds
make perf                       # workload matrix (needs `make regress` first: isolation gate), amortization, determinism
make mutate                     # 24-mutant campaign (about an hour with JOBS=2; BUILD_JOBS=2 limits memory)
make synth                      # generic Yosys structural check (no area/timing claim)
make test T=t05 SEED=2          # one test, one seed
```

Verilator pitfalls found on the way (all handled in `tools/`): pass `-Werror-USERFATAL -Werror-USERERROR` (otherwise `$fatal` in generate blocks is only a warning); `-CFLAGS -fcoroutines` for `--timing`; `-MAKEFLAGS CFG_CXXFLAGS_PCH_I=-include` for the pip wheel; avoid many parallel builds on a 16 GB machine (one build running alongside two others failed once without a diagnostic; memory exhaustion is suspected but was not confirmed — `BUILD_JOBS` lowers the compile parallelism).

## Design in brief

* **Regions** (`sfmp_region_table`): base, length, tier, owner domain, R/W permissions, allocation / dirty / migration state, error status, generation. Created, freed, re-permissioned and migrated **only** by privileged commands; no PVA or physical overlap is ever allowed (checked at ALLOC and by an always-on monitor).
* **Translation**: pool virtual address → region CAM → tier + physical address at **256 B granularity**, regions ≤ 64 granules, contiguous. A pool-local remap table — **not** a CPU MMU and **not** a replacement for the host IOMMU, whose `hd_dom`/`hd_xlat_ok` sideband it consumes.
* **Isolation** (`docs/02`): each client port is hard-bound to a domain by a privileged command; every access is checked against owner and permission; all failure causes look identical to the tenant (`CE_FAULT`, zero data); new extents are zero-filled before they become visible; stale handles are rejected by generation.
* **Migration** (`docs/03`): validate → reserve destination → pre-copy with dirty-chunk tracking (or stop-and-copy) → freeze + drain → final pass → CRC-verified read-back → **atomic mapping switch** → release old extent. A monitor compares destination and source byte-for-byte at every commit.
* **Policy** (`docs/04`): epoch scan, EWMA hotness and write ratio, benefit-vs-cost with margin, hysteresis, cooldown, measured cost and benefit; advisory only — the command engine re-validates every request.
* **Telemetry**: 48 global and 10 per-domain 64-bit counters from real transactions, per-region hotness, per-tier latency, migration statistics, RAS events.

## Headline results (simulation; details and caveats in `reports/` and `docs/08`)

* **Verification**: regression OVERALL PASS — 3 configurations × 3 seeds, e.g. default: ≈ 232 K explicit assertions plus ≈ 487 M monitor checks, 0 errors, 77 migration commits compared byte-for-byte; lint 0 warnings in 4 parameter sets; 17/17 illegal parameter sets refused; unit benches pass; generic Yosys synthesis of every module without latches or loops. **Mutation campaign: 23 of 24 injected bugs detected; the one survivor (M11) is a redundant safety check argued to be equivalent.** Four of the tests were added *after* the first campaign showed survivors, so 23/24 is not independent evidence of test strength (`docs/05_VERIFICATION.md`). No coverage measurement, no formal proof.
* **Tiering is not free.** Makespan speed-up over no tiering on the 12 K-access workloads: hot/cold 1.78× (pre-copy) / 2.53× (stop-and-copy) against 3.93× for an oracle placement; random access 1.00× (the policy correctly does nothing); oversubscription **0.92×** (slower than not tiering); a fragmented SRAM loses the whole gain (1.00× vs 5.36× for the same free space laid out contiguously). Run-length sweep: pre-copy needs between 3 000 and 6 000 accesses per port to break even on hot/cold.
* **Migration costs**: 16 KiB promotion ≈ 68 K cycles (1 channel, 32-bit, idle) or ≈ 18.5 K cycles (2 channels, 64-bit); under load a stop-and-copy froze the region for ≈ 72 K cycles, pre-copy for ≈ 20 K (at the price of re-copying 260 chunks).

## Not done / not claimed

CXL (any form), coherence, DRAM controller/PHY, FPGA or silicon results, area/timing/power, formal proof, side-channel isolation, bandwidth quotas, compaction, bursts. Full list: [`docs/07_LIMITATIONS.md`](docs/07_LIMITATIONS.md).

## Provenance

`third_party/` is copied byte-for-byte from other projects in the repository (`PROVENANCE.md`); `make check-vendor` re-verifies it. The repository contains **no licence file** — one must be added by the owner before external distribution.
