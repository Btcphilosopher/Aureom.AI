# Vendored third-party RTL (unmodified)

Everything under `third_party/` is copied **byte-for-byte** from other SilicaFlux projects in
`btcphilosopher/Aureom.AI`. Nothing here is edited. `make check-vendor` (tools/check_vendor.py)
re-verifies the SHA-256 of every file against `SHA256SUMS`, and — when the repository checkout is
available (`--repo <path>`) — against the original archive member.

| Directory | Origin (archive inside the repository) | Member path | Why it is used |
|---|---|---|---|
| `clouddpu/rtl/sfd_clouddma.sv` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-clouddpu-p61.zip` (Project 61, CloudDPU) | `silicaflux-clouddpu-p61/rtl/dpu/sfd_clouddma.sv` | **CloudDMA** — the migration copy engine (host-side port = DRAM tier, SRAM-side port = on-chip SRAM tier) |
| `clouddpu/rtl/sfd_sfb_gate.sv` | same | `silicaflux-clouddpu-p61/rtl/dpu/sfd_sfb_gate.sv` | per-beat request gate (swallow + error response) used as the migration DMA guard |
| `clouddpu/rtl/silicaflux_cloud_pkg.sv` | same | `silicaflux-clouddpu-p61/rtl/pkg/silicaflux_cloud_pkg.sv` | package that `sfd_clouddma` references (`ERR_*` codes) |
| `sramlib/rtl/mem/*` | same (vendored there under `third_party/silicaflux-controlcore/third_party/silicaflux-sramlib/rtl/mem`) | SRAM Wrapper Library (Project 01): `sram_sp`, `sram_rsp_path`, `sram_backend_1rw`, generic / FPGA / ASIC-array backends, include files | the **on-chip SRAM tier** array (`BACKEND = GENERIC` in simulation; the ASIC/FPGA backends are one parameter away) |

Licence: the repository has **no licence file** (same finding as Project 61's `PROVENANCE.md`). An owner
must add one before external distribution; this project does not add or assume one.
