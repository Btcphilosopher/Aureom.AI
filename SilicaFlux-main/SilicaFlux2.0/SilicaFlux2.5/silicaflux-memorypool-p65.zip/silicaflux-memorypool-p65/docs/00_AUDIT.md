# 00 — Repository audit (Project 65, SilicaFlux MemoryPool)

Audited: `btcphilosopher/Aureom.AI`, branch `claude/sharp-davinci-ye9ng3` (HEAD `698c554`). As in the earlier SilicaFlux
projects, the RTL lives inside zip archives (`SilicaFlux-main/` and `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`). The
archives relevant to this brief were extracted read-only into a scratch directory and inspected; nothing in the repository
was modified. The brief's eight areas were each searched for by name, by function and by keyword (see "How far to trust
this").

## How far to trust this audit

| Evidence | What it covers |
|---|---|
| **Read and re-verified by me directly** | P61 CloudDPU (README, `00_AUDIT`, `01_ARCHITECTURE`, `02_TENANT_ISOLATION`, `07_LIMITATIONS`; RTL of `sfd_clouddma`, `sfd_sfb_gate`, `sfd_crc32`, `sfd_host_guard`, the package header); the SFB2 protocol document of DataFabric; the SRAM Wrapper Library cell `sram_sp` (ports, protocol, file dependencies); the RAS project's external-event port and event codes; the claims marked ✔ below (re-checked by grep) |
| **From a read-only audit sub-agent's report** (file/line citations given by it; I spot-checked the ones marked ✔) | SRAMGrid (P33), MemoryCore, the external-memory bridge (P24), DataFabric-NoC, HPC M07 counters, PowerFabric (P36), the CloudDPU register-page occupancy, the exhaustive search for translation / CXL / DDR terms |
| **Mechanically verified** | every vendored file is byte-identical to its archive member: `make check-vendor` → 13 files, 13 archive-compared, 0 differences |

Nothing below is a hardware result. Every verification number in this project is RTL simulation.

## 1. What exists, what is reusable, what was decided

| Area (brief) | Found | Evidence recorded by that project | Decision for MemoryPool |
|---|---|---|---|
| **SRAMGrid** (P33) | `silicaflux_sram_grid`: N-port, banked (1…16 banks per region), word/XOR/high interleave, per-region none/parity/SECDED, SFB2-compatible valid/ready **plus tags**, up to `reorder_slots` outstanding; 2–4 cycle read latency | 232/232 sim runs, mutation 20/20, lint 19/19; *simulation, Yosys and geometric placement only; no OpenROAD, STA or power; no scrub engine; no poison storage* | **Not instantiated.** It is the natural production SRAM tier (banking, ECC, tags) — the pool's tier port is a subset of its protocol, so it can be swapped in behind `sfmp_sram_tier`. For this project tier 0 is the single-port SRAM Wrapper Library cell (below), which is simpler to verify exhaustively |
| **SRAM Wrapper Library** (P01) | `sram_sp`: 1RW synchronous SRAM, valid/ready request, **in-order** valid/ready response, write acknowledges, generic / FPGA / ASIC-macro backends, MBIST port | lint, sweep, mutation, formal (bounded), cross-simulator (their reports) ✔ interface read directly | **Reused, vendored unmodified** as tier 0 (`BACKEND = GENERIC` in simulation). The FPGA and ASIC-macro backends are one parameter away |
| **MemoryCore** | `silicaflux_memory_subsystem`: banked shared SRAM (256 KiB), LMEM, optional non-coherent cache, VSPM host window, EXT window (256 MiB), SFB2 32-bit; **"no address translation"** ✔ | 588/588 regression, mutation 25/25; *EXT model has fixed latency, no DRAM timing; simulation only* | Not reused (a CPU-side memory map, not a tiering substrate). Its EXT window is where a pool's DRAM tier would appear in a SoC |
| **External-memory bridge** (P24) | `silicaflux_extmem_bridge`: SFB2 upstream (+id/len/last), generic "SFMC" controller-side interface; **no DRAM controller or PHY exists** — "none available — not claimed" ✔; behavioural `extmem_sim_mc` (random 2…12-cycle latency + toy row model) | 663/663, mutation 32/33, ECP5 Fmax 27–57 MHz; *no adapter, no hardware run; one transaction outstanding behind the crossbar* | **Not instantiated.** The pool's DRAM-side port (`em_*`) is a plain SFB2-style port with in-order responses and up to `EM_OUT` outstanding; the bridge's SFMC side or an AXI adapter is the integration path. The DRAM tier in simulation is a **new behavioural model with bank/row timing and fault injection** (`sfmp_dram_model`), clearly labelled as a model |
| **DataFabric** (P03) | SFB2 protocol (rules R1–R12 ✔ read), `sfb_crossbar`, arbiters, register slice, `sfb_sram_slave` | unbounded proofs for the interconnect, bounded for the DMA | **Protocol reused** for every internal and tier port (`sfmp_tier_arb` follows R1–R5, R7, R8; differs from the crossbar only in allowing several outstanding transactions per slave, stated in its header) |
| **DataFabric-NoC** (P22) | SFB3 shared bus / crossbar / mesh with QoS | 782 runs, 38/38 formal | Not used (≤ 9 client ports) |
| **CloudDMA** | **Exists only in the CloudDPU (P61)**: `sfd_clouddma`, SFB2 single-beat, host memory ↔ SRAM, per-beat commit semantics, partial last beat ✔ read in full | P61: 55/55 system runs, mutation 20/20 | **Reused, vendored unmodified** as the migration copy engine: its host-memory port is the DRAM tier, its SRAM port is tier 0 (`dir 0` = promote, `dir 1` = demote). Wrapped by `sfd_sfb_gate` (also vendored) as the per-beat guard |
| **RAS** (P26) | SECDED ECC SRAM slave (`sfras_sfb_ecc_slave`, drop-in for `sfb_sram_slave`), scrub, `silicaflux_ras` event concentrator; external-event port `{valid, type[3:0], addr, addr_v, info, corr}` ✔, codes `MEM_UE=2`, `DMA_ERR=4`, `ILLEGAL_OP=8`, `TIMEOUT=11` ✔ | 39/39 runs, mutation 22/22 | **Interface adopted:** `ras_ev_*` carries exactly that format with those codes. The ECC slave is the obvious next step for tier 0 (not integrated) |
| **Existing address translation** | **None.** ✔ No IOMMU / MMU / TLB / page table / PASID anywhere in the extracted projects: the only hits are documents stating there is none (MemoryCore, CloudDPU, VirtIO P63 — "addresses are IOVAs used 1:1 (no translation)" with an external-IOMMU hook) and the RISC-V core's `CPU.md`. Closest things: window range checks (`sfd_win_check`, `sfd_host_guard`, `sfd_sram_guard`, `silicaflux_virtio_domain_perm`), `sfb_addr_decoder` (identity), SRAMGrid's static bank/row decode | — | **New: `sfmp_region_table`** is the first real remapping logic in the repository, deliberately scoped to the accelerator's own managed window and with a clean IOMMU boundary |
| **Power counters** | PowerFabric (P36): per-region clock enable, retention capability-gated and simulation-only; no per-bank retention/sleep pins on the IHP macros | 107 runs | No hook usable for tier power management; noted as follow-on |
| **Performance counters** | `sfd_perf` (P61): 16 global + per-tenant 64-bit counters, LO/HI latch ✔; **no generic external-event input**; its memory-map doc/yaml say `count: 32` while the RTL has `NG = 16` ✔ (a documentation discrepancy in P61, not fixed here); HPC M07 `hpc_perf_counters`: generic bank (≤ 32 counters, ≤ 64 bit, `inc_i` multi-event adds, LIVE_LO/HI) | M07: formal A1–A7, mutation 46/46 | Counter **conventions adopted** (64-bit, LO read latches HI, freeze/clear, multi-bit increments from real handshakes). A dedicated bank (`sfmp_cntbank`) was written because the pool needs maximum-latency values and per-domain arrays that M07's bank cannot express; replacing it by M07 for the additive counters is a clean follow-up |
| **CloudDPU register map** | The DPU owns all eight forwarded ControlCore pages (8…15); ControlCore pages 0–7 and 16–17 are internal; 18–31 disabled (`CC_PAGE_EN = 0x0003FFFF`) | — | **The MemoryPool cannot be dropped into the CloudDPU register space unmodified.** It exposes its own 4 KiB page in the same `rb_*` + `rb_priv` protocol; integration needs a page allocation in the ControlCore map (a change to a vendored-unmodified block) |
| **DDR / HBM / CXL / tiering** | ✔ **No CXL anywhere** (case-insensitive search of all RTL/docs/yaml/py in the extracted projects: no hits). DDR/HBM appear only in the P24 roadmap/config templates (research study, no IP), BufferCore limitations ("No DDR controller or PHY") and MemoryLab's first-order `dram.py` ("NOT JEDEC-accurate"). Nothing about tiering, NUMA, migration or hot/cold pages | — | CXL is therefore specified as a *future adapter boundary only* (`docs/CXL_ADAPTER_SPEC.md`); nothing in this project is, or is labelled as, CXL |

## 2. Modules that do not exist (and what stands in for them)

| Item | Status | What this project provides |
|---|---|---|
| Real DRAM controller / PHY / DDR / HBM | does not exist | a **behavioural DRAM tier model** (`model/sfmp_dram_model.sv`): bank/row timing abstraction, refresh, in-order responses, fault injection. Its cycle counts are model parameters, not JEDEC timings |
| CXL controller / PHY / device | does not exist | an adapter-boundary specification and a lint-checked **non-functional** boundary stub (`rtl/future/sfmp_cxl_boundary_stub.sv`) that answers every request with "unsupported" |
| Host IOMMU | does not exist | the pool's **IOMMU boundary** (`hd_dom`, `hd_xlat_ok`): trust contract, enforcement and tests (see `01_ARCHITECTURE.md`) |
| Address translation | does not exist | `sfmp_region_table` (granule-based CAM remap of the managed window) |
| Memory tiering / migration | does not exist | `sfmp_migrate`, `sfmp_policy` |

## 3. Interface decisions that follow from the audit

* **One protocol everywhere:** SFB2 single-beat valid/ready with in-order responses, so CloudDMA, the SRAM library cell and
  the DRAM model attach without translation layers; the pool's tier arbiter is a small SFB2 N-to-1 with a tag FIFO.
* **CloudDMA is used as-is.** Its one-outstanding, single-beat nature (a P61 design limit) sets the migration bandwidth; the
  pool scales it by instantiating `MIG_CH` channels (1–4), each with its own guard and verify reader.
* **Register page, not a ControlCore page:** see the table above.
* **RAS event format and counter conventions** are those of P26 and P61/M07.

## 4. Tool versions used here (a deviation from the P61 baseline, stated)

| Tool | Here | P61 baseline |
|---|---|---|
| Verilator | 5.48 (pip wheel `verilator`; runtime banner reports 5.49) with `--binary --timing`, g++ 13.3 (`-fcoroutines`) | 5.020 |
| Yosys | 0.71 (WebAssembly build via `yowasp-yosys`) — **newer than the 0.33 baseline**, so "synthesizes under Yosys" here is a weaker statement about the baseline flow than P61's | 0.33 |
| Icarus Verilog | not available in this environment. The testbench uses SystemVerilog queues, associative arrays, `fork/join` and `--timing`, and several constructs had to be avoided because of Verilator limitations (see `05_VERIFICATION.md`); its portability to other simulators is **untested** | 12 |
| Python | 3.13 | 3.13 |

The RTL follows the repository's coding rules (flat ports, no structs on ports, no `import` in module headers, no `return`,
no `int'()` casts, fully-qualified `sfmp_pkg::NAME`) so that it remains acceptable to the older flow, but it was **not**
run through Yosys 0.33.

## 5. Gaps found in the repository that this project does not close

* No licence file (the vendored copies keep their provenance in `third_party/PROVENANCE.md`; an owner must add a licence before
  external distribution).
* No hardware (FPGA or silicon) result for any memory block; none here either.
* The P61 documentation/yaml counter-count discrepancy (16 vs 32) is left as found.
* No block in the repository enforces *host* memory protection beyond window checks; the IOMMU boundary here relies on a
  trusted external IOMMU that does not exist in the repository.
