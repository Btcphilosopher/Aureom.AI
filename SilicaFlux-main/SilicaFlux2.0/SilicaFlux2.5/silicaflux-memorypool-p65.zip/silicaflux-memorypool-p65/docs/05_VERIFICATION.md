# 05 — Verification

All evidence is from **RTL simulation with Verilator 5.48/5.49** (`--binary --timing`). No formal proof, no gate-level or FPGA run, no code-coverage measurement. Reproduce with `make regress` / `make mutate` (see `README.md`); results are in `../reports/regression.md`, `regression.json`, `mutation.md`.

## 1. Environment

| Piece | What it does |
|---|---|
| `tb/tb_pool.sv` | harness: clock/reset, register-page and client-port drivers, **golden byte-accurate memory model keyed by pool virtual address** (every accepted write updates it; every read is compared), RAS-event capture, DRAM fault-injection and stall hooks, always-on monitors (§3), negative control |
| `tb/tb_tests.svh` | directed tests T01–T12 and the trace replayer |
| `tb/tb_tier_path.sv` | unit bench: tier arbiter + SRAM tier + scrubber + DRAM model — random masters on both tiers (with and without master-side response back-pressure), scoreboard per master |
| `tb/tb_mig_guard.sv` | unit bench: the migration channel's CloudDMA guards (G1–G7), with a corrupted DMA address |
| `model/sfmp_dram_model.sv` | the modelled DRAM tier (bank/row timing, refresh, in-order, non-zero initial pattern, corruption / error / stall injection) |
| `tools/run_regress.py` | vendor check, lint (4 parameter sets), 17 illegal-parameter refusals, unit benches, isolation suite **first**, then the whole system suite in 3 configurations × 3 seeds; every run must print an explicit `TB RESULT PASS` |

Configurations: **default** (4 domains, 32-bit, 1 migration channel, 64 KiB SRAM / 256 KiB DRAM); **wide** (`-GDW=64 -GMIG_CH=2`); **small** (`-GND=8 -GRQ=2 -GEM_OUT=1 -GT_REFI=200`: more domains, shallow queues, one outstanding DRAM request, frequent refresh).

## 2. The brief's verification list → tests

| Brief item | Test(s) | What is checked |
|---|---|---|
| Allocation / deallocation | `T01`, `T08` | handles carry a generation; double free / stale handle / wrong generation refused (`RC_STALE`); new extent reads **zero** (scrubber); free returns the extent (allocator occupancy == bitmap popcount) |
| Address overlap | `T02` + overlap monitors | seven overlapping placements (partial, containing, contained, identical) must be refused, an **adjacent** region is accepted, window straddling / above-window / wrong-window / disabled-domain placements are refused, argument validation; monitors assert **no PVA overlap and no physical overlap** at all times |
| Invalid permissions | `T03`, `T10` | read/write permission per region, privileged-only register writes (a non-privileged write changes nothing and is counted), cross-tenant access |
| Migration correctness | `T04`, `T11` + commit monitor | promote and demote, pre-copy and stop-and-copy, every word read back through the golden model; **at every migration commit a monitor compares source and destination byte-for-byte by backdoor**, and requires region FROZEN, nothing in flight, nothing dirty |
| Dirty-data handling | `T05` (v0/v1/v2), `T05c`, `T05d` | writers and readers racing a migration; chunk re-copies counted; continuous writers + busy DRAM; **a write stalled in the dispatch register across the freeze** |
| Reset behaviour | `T06` | reset mid-migration and with accesses in flight: nothing commits across the reset, migration engine idle, DRAM model and response queues empty, allocator empty, every region FREE, an access after reset fails (nothing configured), a fresh allocation works, no stale response appears |
| Concurrent traffic | `T07` | all ports + host DMA, migration and allocation churn; DUT counters (accesses, bytes, per tier, per domain) must equal the testbench's own counts |
| Memory exhaustion | `T08` | SRAM/DRAM exhaustion, per-domain quota, fragmentation (`RC_NO_SPACE`, `RC_QUOTA`), recovery after frees |
| Backpressure | `T09` | clients that stop accepting responses (queue fills, `QFULL` counter moves, data still correct and in order on release); saturated external port with a migration on top |
| Tenant separation | `T10`, `T11` | see `02_TENANT_ISOLATION.md`: cross-tenant reads/writes (victim data unchanged), uniform client fault code, quarantine, stale-extent reuse (B reads zeros where A wrote data), access during migration, host DMA without translation |
| Faults / errors | `T11` | DRAM error responses, corruption during migration (CRC verify catches and re-copies, then aborts after the retry limit), abort leaves the region intact, RAS events |
| Tiering policy | `T12a`–`T12h` | promotion, capacity-driven demotion, anti-oscillation (2 vs 10 migrations), no-benefit regions left alone, opt-in pressure relief, auto-measured benefit and cost, refusal back-off, hysteresis in isolation, plausible measured latencies |
| Trace replay | `+test=trace` | the generated workloads, with the same data-integrity and monitor checks |

## 3. Always-on monitors (`tb_pool.sv`)

region-table "more than one entry hit" tripwire · SRAM out-of-range tripwire · **SFB2 R2 at both tier ports** (a presented request is held unchanged until accepted) · **no dispatch into a FROZEN region** · PVA ranges never overlap · physical extents of live regions disjoint per tier · every live extent reserved in the allocator bitmap · occupancy counters == bitmap popcount · **commit-time source == destination comparison** and commit preconditions. Each verified regression run executes hundreds of millions of monitor checks (`reports/regression.md`).

A **negative control** (`T11`) disables the commit comparison while a corruption is injected and requires the byte difference to show up, proving that the monitor can detect what it claims to detect.

## 4. Results (final sources)

`../reports/regression.md`: **OVERALL PASS** — vendor check 13 files unchanged; Verilator `-Wall` lint 0 warnings in 4 parameter sets; 17/17 illegal parameter sets refused at elaboration; unit benches pass for 3 seeds; isolation suite first in every configuration; system suite PASS in all 9 runs (default ≈ 232 K explicit assertions + ≈ 487 M monitor checks and 77 migration commits compared byte-for-byte per run; wide 87–88 commits; small 72 commits). Generic Yosys synthesis of every module: no latches, no loops (`06_SYNTHESIS.md`).

## 5. Mutation campaign (`tools/mutate.py`)

Each mutant is a copy of the project with **one deliberate RTL bug**; the whole default-configuration suite (plus the unit benches where listed) must **fail**. A mutant that passes is a *survivor* and is listed, not hidden.

Result (`../reports/mutation.md`): 23 killed, 1 survived (1 documented as equivalent, 0 unexplained), 0 invalid of 24.

| id | property under test | injected bug | result | first failing check |
|---|---|---|---|---|
| M01 | quiesce | dispatch continues into a FROZEN region | **KILLED** | [5539020000] FAIL (T05_dirty_v0) [monitor]: access dispatched into a FROZEN region |
| M02 | isolation | region owner is not checked (cross-tenant access allowed) | **KILLED** | [15376766000] FAIL (T10_isolation): cross-tenant read of 0 leaked data (err=0 code=0 data=3947e6cb) |
| M03 | permissions | write permission is not checked | **KILLED** | [372326000] FAIL (T03_perms): write to a read-only region err=0 code=0 |
| M04 | no physical overlap | allocator treats every granule as free | **KILLED** | [338530000] FAIL (T01_alloc_free) [monitor]: regions 0 and 2 overlap physically |
| M05 | no PVA overlap | PVA overlap check disabled | **KILLED** | [350110000] FAIL (T02_overlap) [monitor]: regions 0 and 1 overlap in PVA |
| M06 | stale handles | generation check disabled | **KILLED** | [309946000] FAIL (T01_alloc_free): free with wrong generation rc=0 |
| M07 | stale data | scrubber writes ones instead of zeros | **KILLED** | [3466000] FAIL (T01_alloc_free): port 0 read 0: got ffffffff expected 00000000 |
| M08 | migration verify | CRC comparison always succeeds | **KILLED** | [16460930000] FAIL (T11_faults) [monitor]: COMMIT with 1 bytes of the destination differing from the source (region 0) |
| M09 | DMA guard | per-beat DMA-side window check removed | **KILLED** | guard unit bench: [136236000] FAIL: G5: expected MR_GUARD, got fail=0 code=0 |
| M10 | dirty data | writes during pre-copy no longer mark chunks dirty | **KILLED** | [5373900000] FAIL (T05_dirty_v0) [monitor]: COMMIT with 1511 bytes of the destination differing from the source (region 0) |
| M11 | commit safety | commit without waiting for in-flight accesses | **SURVIVED (equivalent)** | equivalent: the engine already waits for in-flight accesses in E_DRAIN, and a FROZEN region is never dispatched into (invariant I5, killed separately by M01), so the in-flight count can only fall between E_DRAIN and E_COMMIT; the check at E_COMMIT is a redundant safety net, and the commit-time monitor (`commit with an access in flight`) still guards it. |
| M12 | quiesce | no drain of in-flight accesses before the final copy pass | **KILLED** | [10492300000] FAIL (T05d_stalled_write) [monitor]: commit with dirty / pending chunks |
| M13 | release | commit releases the destination extent instead of the source | **KILLED** | [669426000] FAIL (T04_migrate_stop_and_copy): extents after promotion (old DRAM extent released, SRAM reserved) |
| M14 | partial copy | the final pass drops the remaining dirty chunks | **KILLED** | [540500000] FAIL (T04_migrate_stop_and_copy) [monitor]: COMMIT with 3060 bytes of the destination differing from the source (region 0) |
| M15 | privilege | register writes accepted without privilege | **KILLED** | [386666000] FAIL (T03_perms): CTRL changed by a non-privileged write |
| M16 | anti-oscillation | policy cooldown removed | **KILLED** | [21832876000] FAIL (T12c_oscillation_unprotected): protection did not reduce migrations: protected 10 vs unprotected 10 |
| M17 | anti-oscillation | policy hysteresis removed | **KILLED** | [25153716000] FAIL (T12h_hysteresis_off): hysteresis gap 24 did not stop a swap of two almost equally hot regions (10 requests) |
| M18 | drain | in-flight accounting not incremented at dispatch | **KILLED** | [45875236000] FAIL (T05_dirty_v1): migration did not complete |
| M19 | telemetry | service latency counter always zero | **KILLED** | [17481656000] FAIL (T12a_promote): calibration: idle SRAM service latency 0.000000 cycles is implausible (expected about 3) |
| M20 | backpressure | tier arbiter pops its response tag without waiting for the master | **KILLED** | tier-path unit bench: [109110000] FAIL: tier 0 master 1: response withdrawn before acceptance (SFB2 R2) |
| M21 | allocation | allocator marks one granule too many | **KILLED** | [800000] FAIL (T01_alloc_free) [monitor]: SRAM occupancy counter != bitmap popcount |
| M22 | translation | physical granule offset uses only 4 bits (wrong for long regions) | **KILLED** | [2488776000] FAIL (T04_migrate_stop_and_copy): port 1 read 100000: got b8ece42e expected 4f682fdb |
| M23 | quota | SRAM quota check ignores existing usage | **KILLED** | [14318646000] FAIL (T08_exhaust): quota exhausted |
| M24 | IOMMU boundary | host DMA accepted without a valid translation | **KILLED** | [15487866000] FAIL (T10_isolation): host DMA without an IOMMU translation was served |

How to read this:

* **M11 is the single survivor and is argued to be equivalent, not proven.** The engine already waits for in-flight accesses in `E_DRAIN`; a FROZEN region is never dispatched into (invariant I5, killed separately by M01), so the in-flight count can only fall between `E_DRAIN` and `E_COMMIT`. The wait at `E_COMMIT` is therefore a redundant safety net, and the commit-time monitor still checks it. This reasoning is by inspection of the RTL.
* **The campaign was used to improve the tests.** The first run killed 19 of 24. The five survivors showed real holes: nothing isolated policy **hysteresis** (M17 → `T12h`), checked the per-tier **latency counters** for plausibility (M19 → `calibrate_latency` checks), **back-pressured a master's response** at the tier arbiter (M20 → response back-pressure in `tb_tier_path`), or held a write **in the dispatch register across the freeze** (M12 → `T05d`; the continuous-writer test `T05c` alone did not kill it, because the engine's `E_EVAL` re-check rescues the mutant whenever the final pass has chunks to copy). M11 was classified as equivalent. The final 23/24 is therefore **not independent evidence of test strength**: four of the tests were written after seeing which mutants survived. What it does show is that each of the 24 injected bugs is now detected and *where* (the right-hand column).
* M20 is detected by the tier-path **unit bench**, not by the system suite: the system tests never made a master stall a tier response (the access path reserves response space before it dispatches), so the bug is invisible there; the unit bench is where the arbiter's own response back-pressure is exercised. It would matter for any master that does stall responses.
* 24 mutants are hand-chosen; they cover isolation, allocation, mapping, migration, policy and telemetry but are a small sample of possible bugs.

## 6. Defects the verification found (and fixed)

| Found by | Defect | Fix |
|---|---|---|
| policy tests (`T12`) | room-making demoted a region without paying for the **second** migration; candidates failed to qualify the next epoch | benefit must cover promotion + demotion |
| policy tests (`T12e`) | memory-pressure relief fired with the default 87.5 % watermark and demoted cold data for no demonstrated demand | opt-in; the reset watermark equals the capacity |
| `T12` (4-port workloads) | benefit measured on an idle machine (11 cycles) was far below the *loaded* gap (≈ 30), so the policy never migrated | `AUTODELTA`: per-tier latency counters, SRAM reference latency as fallback |
| `T12` | measured migration cost was never seeded from the programmed cost | reseed on change |
| `T12g` | a request refused for lack of contiguous SRAM was retried every cooldown period | refused requests back the region off 4× longer |
| monitors / unit benches | several testbench defects (see §7) — the DUT was correct in each case, the checkers or drivers were wrong | fixed in the testbench |
| mutation campaign | no test isolated policy **hysteresis**, checked the **measured latency counters**, back-pressured a **master's response** at the tier arbiter, or stalled a write **across the freeze** | `T12h`, the latency checks in `calibrate_latency`, response back-pressure in `tb_tier_path`, `T05d` (mutants M17, M19, M20, M12) |

Other implementation defects found and fixed during development were not logged individually.

## 7. Verilator-specific pitfalls (so they are not rediscovered)

* `$fatal` / `$error` in generate blocks are only warning classes (`USERFATAL`, `USERERROR`): every flow passes `-Werror-USERFATAL -Werror-USERERROR`, otherwise an illegal parameter set elaborates silently.
* Testbench drives must be made `#1` after the clock edge and sampled at the falling edge; a drive at the edge races the DUT. Static initialisers inside `always` blocks run once (a counter initialised there leaked across tests). `foreach (a[p][i])` makes `p` a loop variable. Arrays of queues and `fork … join_none` were unreliable; flat queues and plain `fork … join` with constant branches are used. `$display(cond ? "A" : "B")` prints a number.
* The pip wheel needs `-CFLAGS -fcoroutines` and `-MAKEFLAGS CFG_CXXFLAGS_PCH_I=-include`. Do not run many parallel builds on a 16 GB machine (a build failed once under heavy load without a diagnostic).
* `--x-initial unique --x-assign unique` randomises initial state per seed (`+verilator+rand+reset+2`) — this is the only X-style check available.

## 8. What the evidence does *not* show

* No coverage measurement (line, toggle, functional): "all 12 tests pass" is not "everything was exercised"; the mutation campaign is the only measure of test strength, and it covers 24 hand-chosen bugs.
* The testbench and the RTL have the same author. The independent oracles are the golden model, the monitors and the mutants.
* Randomisation is seed-based and small (3 seeds per configuration; one seed for the mutation runs).
* No formal proof of the isolation or migration invariants; no gate-level, FPGA or silicon verification; no multi-clock or reset-domain analysis (single clock, asynchronous active-low reset).
* The DRAM tier is a model; real DRAM controllers reorder, refresh and error differently.
