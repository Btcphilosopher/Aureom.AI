# 03 — Migration protocol and why it keeps data consistent

Modules: `sfmp_ctrl` (validation, destination reservation, start), `sfmp_migrate` (engine), `sfmp_mig_chan` (one copy channel: CloudDMA + guard + CRC verify), `sfmp_region_table` (mapping), `sfmp_access` (freeze, in-flight tracking, dirty events), `sfmp_alloc` (extents).

```
Source Region → Validate Ownership → Quiesce / Coordinate Access → CloudDMA Copy → Verify Completion → Update Mapping → Release Old Region
```

## 1. The flow in this implementation

| Brief step | Where | What happens |
|---|---|---|
| **Validate ownership** | `sfmp_ctrl`, before anything moves | handle `(index, generation)` is live; region is `ACTIVE`, not migrating, not pinned; destination tier differs; domain SRAM quota is respected (promotions); a **contiguous destination extent** is found and *reserved* (so it can never be handed to anybody else). Refusals leave no trace (`RC_STALE`, `RC_BUSY`, `RC_PINNED`, `RC_SAME_TIER`, `RC_QUOTA`, `RC_NO_SPACE`). |
| **Quiesce or coordinate** | region state `PRECOPY` → `FROZEN` | *Pre-copy (coordinate):* the region stays live, served from the **source**; every write ordered at a tier while a chunk is not waiting in the to-do set marks that chunk **dirty**. When the dirty set is ≤ `FREEZE_THRESH` chunks, or `MAX_ROUNDS` rounds have run, the region is **frozen**: `sfmp_access` stops dispatching *any* access to it (the heads wait; they are not failed) and the engine waits until **no access to the region is in flight**. *Stop-and-copy (`PRECOPY_EN=0`):* the region is frozen from the start. |
| **CloudDMA copy** | `sfmp_mig_chan` | one 64-byte chunk at a time per channel: `sfd_clouddma` reads the source tier and writes the destination tier (promote = DRAM→SRAM, demote = SRAM→DRAM), every beat through `sfd_sfb_gate` with a window check on *this chunk only* |
| **Verify completion** | `sfmp_mig_chan` | CRC-32 of the data the DMA **read** from the source (tapped on the response side) vs. CRC-32 of a read-back of the destination chunk; mismatch → the chunk is copied again (up to `MAX_RETRY`), then the migration aborts (`MR_VERIFY`); DMA/tier error → `MR_DMA`; guard refusal → `MR_GUARD` |
| **Update mapping** | `sfmp_migrate` → `sfmp_region_table` | **one cycle, atomic:** `tier` and `phys` switch to the destination, migration state → `NONE`, dirty flag cleared |
| **Release old region** | `sfmp_migrate` → `sfmp_alloc` | only *after* the commit cycle, the source extent is returned to the allocator (it will be zero-filled before anybody can use it) |

## 2. Invariants (each one is checked by an always-on monitor or a directed test)

| # | Invariant | Enforced by | Checked by |
|---|---|---|---|
| I1 | The destination is **never visible** before commit: nothing maps to it; it is not allocatable to anyone else | reservation at start; mapping switch only at COMMIT | monitor: live extents disjoint; `T04/T05` |
| I2 | At the commit cycle the region is `FROZEN`, **no access is in flight**, the to-do and dirty sets are **empty** | `E_COMMIT` waits for `!infl_nz[region]`; `E_EVAL` loops until clean | monitor asserts all three at every commit |
| I3 | **Destination == source byte-for-byte at the commit cycle** (nothing partially copied is ever committed) | final pass copies every dirty chunk after the drain | monitor compares both tiers by **backdoor read at every commit** (`mon_checks`), independent of the CRC mechanism |
| I4 | A write accepted while the region is pre-copying is **never lost**: it is either copied before the chunk was taken, or marks the chunk dirty and is re-copied | dirty bit set at the tier handshake (same cycle the write is ordered ahead of any later DMA read); skip rule for chunks still in the to-do set | `T05` (writer + reader racing a migration, full sweep against the golden model); mutant `M10` |
| I4b | A write that was **dispatched but not yet ordered at the tier** when the freeze begins is not lost: the engine waits for in-flight accesses before it snapshots the dirty set | `E_DRAIN` waits for `!infl_nz[region]` | `T05d`: the DRAM stops accepting requests once the last chunk has been handed out, one write is issued (it sits in the dispatch register: in flight, not yet ordered at the tier) and the stall is released only after the freeze — swept over 14 stall start times, data swept against the golden model, commit monitors active; `T05c`: 24 migrations under two continuous writers with the DRAM stalled from the freeze on; mutant `M12` (killed by `T05d` only — with continuous writers the engine's `E_EVAL` re-check rescues it) |
| I5 | No access is dispatched into a `FROZEN` region | `frozen_blk` in stage 1 | monitor: stage-1 dispatch into `FROZEN` is an error; mutant `M01` |
| I6 | The source is never modified by the migration, so an **abort leaves the region exactly as it was** | DMA reads the source only; abort only clears the migration state and releases the *destination* | `T11 (b)(d)`: after aborts the data and mapping are intact and the destination is released |
| I7 | The old extent is released only after the mapping changed (no window in which two owners can reach it) | `E_REL` follows `E_COMMIT`; mutant `M13` releases the wrong extent | monitors: allocator occupancy == bitmap popcount; extents disjoint |
| I8 | The migration DMA can only touch the chunk it was handed | per-beat window check and direction check in `sfmp_sfb_gate` | `tb_mig_guard` G5/G6: a corrupted DMA address is swallowed; bytes outside the chunk unchanged; mutant `M09` |

## 3. Why the dirty-set ordering is sufficient

Tier models accept requests **in order**; a write's effect is ordered by its **tier handshake**, and the dirty event is raised in that same cycle. The engine takes a chunk out of the to-do set *before* its first DMA read is
presented.

* Write accepted **before** the chunk left the to-do set → the later DMA read sees it (in-order tier). The event is ignored (`!todo` rule) — harmless, the chunk is still going to be copied.
* Write accepted **at or after** the chunk left the to-do set → the event sets the dirty bit → next round (or the final pass) copies it again.
* A write that stage 1 committed *before* the freeze is counted in-flight, so the freeze drain waits for its response; its dirty event (raised at the tier handshake, earlier than the response) has therefore arrived before the final snapshot `todo ← dirty` is taken.
* The freeze/drain race: the table's `FROZEN` update and stage-1's in-flight increment happen at the same clock edge, and the engine only samples `infl_nz` in a later state, so a request that slipped in during the freeze cycle is always seen.

The verify CRC is accumulated from the DMA's own reads, so a tenant write that lands on the source *after* the read cannot produce a false mismatch (it re-dirties the chunk instead).

## 4. Failure handling

| Failure | Result |
|---|---|
| DMA or tier error while copying (`MR_DMA`) | engine stops handing out chunks, waits for every channel to finish, `ABORT`: migration state cleared (region unfreezes), region error `RE_MIG_DMA`, destination released, RAS `DMA_ERR` event |
| Verify mismatch after `MAX_RETRY` re-copies (`MR_VERIFY`) | same, error `RE_MIG_VER` |
| Guard refused a beat (`MR_GUARD`) | same, error `RE_MIG_GUARD` |
| Reset during a migration | everything resets; the table is empty; nothing was committed (`T06`) |
| Migration watchdog (≈ 16 M cycles) | sets a sticky bit and a RAS `TIMEOUT` event; it does **not** abort (a channel mid-DMA cannot be cancelled — the CloudDMA has no abort). A never-answering tier therefore needs a reset (shared-fate limit, same as P61's zombie slot) |

## 5. Costs (measured in simulation; model DRAM; see `../reports/PERFORMANCE.md`)

* A 16 KiB promotion takes **≈ 68 K cycles** with one 32-bit channel (about 4.2 cycles per byte, copy + verify read-back) and **≈ 18.5 K cycles** with two channels and a 64-bit datapath (both from `T04`, idle machine). CloudDMA is a single-beat, one-outstanding engine (a P61 design limit); `MIG_CH` and `DATA_WIDTH` are the levers.
* `T05` (4 KiB region, a port writing continuously while another reads): pre-copy needed 92 chunk re-copies (9984 B copied for a 4096 B region) and froze the region for **8.0 K cycles**; stop-and-copy froze it for **17.1 K cycles** with no re-copy. Pre-copy trades extra copy traffic for a shorter stall; stop-and-copy finishes sooner but holds the owner's accesses (and shows a long latency tail — see the performance report).
* Verification read-back adds one read of the destination per copied byte (≈ one third of the migration traffic).

## 6. What is not done

* No ECC/poison handling on the copy path (the tiers here have none).
* One migration at a time (a second request gets `RC_BUSY`).
* A frozen region's *reads* are also held (reads could be served from the source until commit; held for simplicity of the drain argument).
* Regions are contiguous in both tiers; there is no compaction or splitting.
