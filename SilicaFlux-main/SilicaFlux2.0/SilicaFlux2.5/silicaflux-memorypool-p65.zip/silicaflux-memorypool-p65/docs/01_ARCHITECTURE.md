# 01 — Architecture

Primary RTL: `rtl/silicaflux_memory_pool.sv` · blocks: `rtl/pool/sfmp_*.sv` · constants: `rtl/pkg/sfmp_pkg.sv` · registers: `REGISTER_MAP.md` (generated).

## 1. What it is

A programmable memory-management subsystem that sits beside the CloudDPU. It manages **regions** of a managed address window,
places each region in one of two tiers, translates accesses, tracks real access statistics, and moves regions between tiers
safely.

| Tier | What it is in this project | Status |
|---|---|---|
| **0** | on-chip SRAM — the SRAM Wrapper Library cell `sram_sp` (generic backend), vendored unmodified | real RTL |
| **1** | external DRAM — the `em_*` tier port. In simulation: `sfmp_dram_model`, a **behavioural model** (bank/row timing abstraction, refresh, fault injection) | **modelled**; no DRAM controller, PHY, DDR or HBM exists in the repository |
| *CXL* | not implemented — see `CXL_ADAPTER_SPEC.md` | **future, separate project** |

## 2. Block diagram

```
 accelerator ports 0..ND-1 (hard-bound to a domain)      host-DMA port ND  (behind the IOMMU)
 c_req_* / c_rsp_* ──────────────┐                        c_req_* + hd_dom + hd_xlat_ok
                                 ▼
        ┌──────────────── sfmp_access ──────────────────────────────────────────────┐
        │ per-port request FIFO  ->  round-robin pick  ->  CHECK LADDER  ->  dispatch│
        │ per-port response FIFO <-  response path   <-  tier responses              │      ┌──────────────────┐
        │ in-flight counters per region · dirty-write events · telemetry pulses      │◄────►│ sfmp_region_table │
        └───────┬───────────────────────────────────────────────────────┬───────────┘ CAM  │ state tier phys   │
                │ tier 0 (master 0)                                     │ tier 1           │ dom perm mig dirty│
                ▼                                                       ▼                  │ err gen counters  │
   ┌── sfmp_tier_arb (SRAM) ──┐                              ┌── sfmp_tier_arb (DRAM) ──┐   └───────▲──────────┘
   │ masters: access, scrub,  │                              │ same masters, in-order   │           │ ct_* / mg_* ops
   │ DMA-SRAM-side, verify    │                              │ responses, EM_OUT out-   │   ┌───────┴──────────┐
   └───────────┬──────────────┘                              │ standing                 │   │ sfmp_ctrl         │◄─ rb_* page (regs)
               ▼                                             └────────────┬─────────────┘   │ privileged command│
        sfmp_sram_tier  (sram_sp)                                         ▼                 │ engine, domains,  │◄─ sfmp_policy
                                                                  em_* tier-1 port          │ quotas, alloc seq │   (migration requests)
   sfmp_scrub (zero-fill on alloc) ──► both arbiters                                        └───────┬──────────┘
   sfmp_migrate ──► N x sfmp_mig_chan { sfd_clouddma (vendored) + 2 x sfd_sfb_gate + CRC + verify reader } ──► both arbiters
   sfmp_alloc (first-fit extent bitmaps) · sfmp_cntbank x2 (global + per-domain 64-bit counters) · sfmp_regs · ras_ev_* / irq_*
```

## 3. Parameters (`silicaflux_memory_pool`)

| Parameter | Default | Legal | Meaning |
|---|---|---|---|
| `NUM_DOMAINS` | 4 | 1…8 | tenant domains = accelerator client ports |
| `NUM_REGIONS` | 32 | 4…32 | region-table entries |
| `DATA_WIDTH` | 32 | 32, 64 | beat width (SRAM word, DMA beat, tier ports) |
| `GRAN_LG` | 8 | CHUNK_LG…12 | **translation granularity** = 2^GRAN_LG bytes (256 B) |
| `POOL_AW` | 28 | GA ≤ 26 | managed PVA window = 256 MiB |
| `SRAM_BYTES` / `DRAM_BYTES` | 64 KiB / 256 KiB | powers of two | tier capacities |
| `MAX_REGION_GRAN` | 64 | 1…255 | longest region (16 KiB); longer ALLOCs are refused |
| `CHUNK_LG` | 6 | ≥ log2(beat) | migration copy / verify / dirty-tracking unit (64 B) |
| `MIG_CH` | 1 | 1…4 | parallel migration channels (CloudDMA instances) |
| `RQ_DEPTH` | 4 | ≥ 2 | per-port request queue depth (response queue 2) |
| `EM_OUT` | 4 | ≥ 1 | outstanding requests on the external port |

Illegal combinations are refused at elaboration by `$fatal` in named generate blocks (`g_err_*`). **Verilator reports `$fatal`/`$error` as warning classes**;
every flow in this project passes `-Werror-USERFATAL -Werror-USERERROR` (17/17 illegal parameter sets are refused by `tools/run_regress.py`).

## 4. Address translation

* **Model.** A *region* maps a contiguous, granule-aligned **PVA** range (pool virtual address, the address a client uses)
  onto a contiguous, granule-aligned **physical extent** of one tier. The lookup is a fully parallel compare of the request
  granule against every non-free entry (CAM, ≤ 32 entries). Physical byte address = `{phys_granule_base + (pva_granule - pva_base), pva[GRAN_LG-1:0]}`.
* **Granularity** = `2^GRAN_LG` bytes for PVA bases, lengths, physical extents, domain windows and tier allocation.
* **Per-domain managed windows.** Each domain has a privileged window `[base, limit)` of the PVA space; windows of enabled
  domains never overlap; an ALLOC must lie inside its domain's window.
* **Overlap rules.** Two regions never overlap in PVA (checked on ALLOC by a parallel overlap query; `lk_multi` is a tripwire).
  Two extents never overlap physically (first-fit bitmap allocator; migration destinations are reserved at migration start).
  **Aliasing / shared mappings are not supported** — "unless explicitly supported" is answered *not supported*.
* **What it is not.** It does not replace the CPU MMU or the host IOMMU. It remaps only the accelerator's managed window.
  Nothing here walks page tables, caches translations, or handles page faults: an access that misses completes with an access fault.

### IOMMU integration boundary (host DMA addresses)

The host-DMA port (`c_*[ND]`) is the only way host-originated addresses reach the pool. Contract with the (trusted, external) IOMMU:

1. The IOMMU has already translated the device address; the address presented is a **PVA inside the managed window**.
2. `hd_dom` is the domain the IOMMU bound to that requester (stream id / PASID); `hd_xlat_ok` says the IOMMU translated and permitted the transaction. Both are sampled with the request.
3. The pool **refuses** the access unless `hd_xlat_ok` (cause `FC_IOMMU`), the domain exists and is enabled, and it then applies the **same** region checks as for an accelerator port (owner, permission, state). A mistaken or malicious IOMMU mapping can therefore only reach regions of the domain it names.
4. Not provided: ATS, PRI, PASID tables, address-translation caches. The pool never issues translated-address requests upstream.

Tested: translation absent → fault; translation present for the right domain → served; wrong domain → cross-tenant fault; non-existent domain → fault (`T10_isolation`).

## 5. Region table (`sfmp_region_table`)

Per region: base (PVA granule), length (granules), **tier**, physical base, **owner domain**, **read / write permissions**, **allocation state**
(`FREE / SCRUB / ACTIVE / FREEING`), **migration state** (`NONE / PRECOPY / FROZEN`), **dirty** flag, pin, sticky **error status**, a
**generation** counter (changes on every ALLOC), epoch and lifetime read/write counters, plus per-domain SRAM-reservation and live-region counts.

**Write ownership** (who can change what): the command engine owns state / owner / permission / pin / generation and writes tier+physical base at ALLOC;
the migration engine owns the migration state and performs the atomic mapping update (`tier`, `phys`) at COMMIT; the data path may only update the dirty flag,
counters and the media-error code. **Updates are privileged:** every command enters through `rb_priv`-gated registers; the data path has no write path to ownership or mappings.
A region handle is `(index, generation)`; a stale handle (freed and re-allocated since) is refused (`RC_STALE`).

## 6. Access path (`sfmp_access`)

* **Queues.** Each client port has a request FIFO (`RQ_DEPTH`) and a response FIFO (2). A port has **at most one access in flight in the tiers**; its next
  request waits at the FIFO head, so responses are in order per port although tiers differ in latency. Ports run concurrently. (This limit is deliberate and
  documented in `07_LIMITATIONS.md`; per-port outstanding > 1 is a follow-on.)
* **Check ladder** (first failure wins; the client always sees the same code):
  domain enabled → not quarantined → IOMMU ok (host port) → aligned and inside the window → mapped → owner == port's domain → region `ACTIVE` → R/W permission → region not `FROZEN`
  (a frozen region *holds* the request, it does not fail it).
* **Dispatch register.** A passing request is committed in one cycle to a one-entry dispatch register and counted in-flight for its region in the same cycle; stage 2
  presents it to the tier until accepted with a stable payload (SFB2 R2). The dirty/migration-write event is raised at the **tier handshake**, the instant the write is ordered ahead of any later migration read.
* **Tier ordering.** Tier models return responses in acceptance order (SFB2 R5); a per-tier context FIFO routes them back. The external port must order overlapping accesses (the P24 controller requirement "C9").
* **Uniform fault code.** Unmapped, someone else's, permission, scrub/free state — all complete with `err=1, code=CE_FAULT`; media/tier errors complete with `CE_MEDIA`. The precise cause is visible only to the
  management plane (`R_FAULT_INFO/ADDR`, per-cause counters), so a tenant gets no allocation-map side channel.
* Idle service latency: **3 cycles** from the SRAM tier; **≈14 cycles** from the modelled DRAM (row hit 12, closed 24, conflict 36, plus queueing).

## 7. Allocation, scrubbing, free

`ALLOC`: validate → pick a free slot → check PVA overlap and quota → first-fit contiguous extent (`AUTO` = SRAM within the domain's quota, else DRAM) → reserve → region `SCRUB`
→ **zero-fill the extent through the tier port** → region `ACTIVE`. So a new owner can never read a previous owner's bytes (the SRAM array powers up random and the DRAM model's background pattern is non-zero,
which is how the tests prove it). `FREE`: region → `FREEING` (no new accesses) → wait until no access to it is in flight → release the extent → slot free. First-fit means **fragmentation is real**; a request
can be refused although enough granules are free in total (`T08`, workload `frag`).

## 8. Tier arbiters (`sfmp_tier_arb`)

Two instances (SRAM, DRAM). Masters: tenant access path, scrubber, and per migration channel one DMA port and one verify reader. Round-robin, grant lock (a presented request keeps its grant until accepted), in-order responses via a tag FIFO,
up to `EM_OUT` outstanding on the external port. Differences from `sfb_crossbar` (which allows one outstanding per slave) are stated in the module header.

## 9. Migration and tiering

See `03_MIGRATION_PROTOCOL.md` and `04_TIERING_POLICY.md`.

## 10. Telemetry

All counters are 64-bit, count real events in the cycle they happen (handshakes, completions) and are read LO-then-HI (LO read latches HI). 48 global counters and 10 per domain — see `REGISTER_MAP.md`.

* **Bytes accessed** (`BYTES_RD/WR`, per tier, per domain; write strobes counted), **access frequency** (`ACC*`, per region epoch counters used by the policy),
* **service latency**: sum + count (global, per tier, per domain) and **maximum** (global, per domain) — enqueue → response-ready,
* **tier hit ratio** = `ACC_T0 / ACC` (global and per domain),
* **queue stalls**: client blocked by a full queue, head waiting (arbitration / tier busy / freeze), freeze-held cycles, external-port stalls,
* **migration**: count, aborts, DMA bytes, verify bytes, chunk re-copies, frozen cycles, engine-busy cycles, retries,
* **memory pressure**: SRAM/DRAM occupancy (granules), peaks, cycles above the programmed watermark.

Counters are cross-checked against the testbench's own counts in `T07` and in every trace run.

## 11. Reset, errors, events

* `rst_n` is asynchronous-assert; the external DRAM interface must be reset together with the pool (a response owed to a request that was in flight at reset is not tracked). Everything resets: region table, allocator, domains (nothing is accessible until the privileged plane reconfigures), queues, engines. SRAM contents are not cleared; a new allocation is always zero-filled.
* `ras_ev_*` uses the RAS project's external-event format: media error → `MEM_UE` (address = PVA), migration abort → `DMA_ERR` (info = result), privileged-register violation → `ILLEGAL_OP`, migration watchdog → `TIMEOUT`. `irq_event` pulses when a command or migration completes; `irq_fault` on media error / abort / privilege violation.
* Sticky bits (`R_STICKY`): command dropped, migration watchdog, region-table tripwire (more than one entry hit), SRAM tier out-of-range tripwire.

## 12. Integration with the CloudDPU (what is and is not done)

* **CloudDMA** is used as the migration copy engine (vendored unmodified). Its host-memory port is wired to the DRAM tier and its SRAM port to tier 0.
* **Not integrated into `silicaflux_cloud_dpu`:** the pool is a standalone block with its own register page and tier ports. The CloudDPU's register space has no free page, so a ControlCore page allocation (and a hookup of `dpu`/`pool` SRAM and DRAM paths) is integration work, not done here.
* The pool's `ras_ev_*` can feed the RAS block's external-event port; `irq_*` map onto interrupt sources.
