# 06 — Synthesizability check (generic Yosys; **not** an implementation result)

`tools/synth_check.py` (`make synth`) synthesizes every module separately, with default parameters, using Yosys 0.71 (the `yowasp-yosys` WebAssembly build):

```
read_verilog -sv <rtl/rtl_files.f minus the ASIC-macro wrapper>; hierarchy -check -top <module>
synth -noabc -top <module>; techmap; opt -fast; stat
```

Raw logs per module are written to `reports/synth/` (not included in the zip because of size; `make synth` regenerates them); the summary is `reports/synth_results.json`.

## What the check establishes

* Every module — and the top, `silicaflux_memory_pool` — is accepted by the Yosys SystemVerilog front end and reduces to flip-flops and generic gates.
* **No latches** are inferred and **no combinational loops** are reported in any module.
* The only warnings are `Replacing memory … with list of registers` (arrays — the region table, the counter banks, the migration scoreboard — become registers, as intended).
* The CXL boundary stub (`rtl/future/sfmp_cxl_boundary_stub.sv`) also synthesizes (4 generic cells): it is a placeholder, not a function.

## Results (generic gates, **un-optimised**, default parameters)

| module | generic cells | flip-flops | note |
|---|---:|---:|---|
| `sfmp_cntbank` | 3 618 | 512 | per-bank counters (the top has two) |
| `sfmp_div32` | 588 | 104 | serial divider |
| `sfmp_tier_arb` | 797 | 22 | per tier arbiter (the top has two) |
| `sfmp_sram_tier` | 1 131 127 | 524 404 | **the 64 KiB array mapped to flip-flops** by the generic SRAM backend (524 288 bits) |
| `sfmp_scrub` | 888 | 99 | |
| `sfmp_alloc` | 12 170 | 1 361 | bitmaps for both tiers |
| `sfmp_region_table` | 95 467 | 5 280 | 32 entries × 175 b + CAM + accounting |
| `sfmp_access` | 19 439 | 3 997 | queues, check ladder, dispatch register, telemetry |
| `sfmp_mig_chan` | 6 123 | 426 | CloudDMA + guards + CRC (per channel) |
| `sfmp_migrate` | 25 622 | 1 460 | |
| `sfmp_ctrl` | 4 251 | 479 | |
| `sfmp_policy` | 23 731 | 2 888 | |
| `sfmp_regs` | 15 223 | 706 | |
| **`silicaflux_memory_pool`** | **1 372 451** | **546 377** | whole hierarchy |

Reading the numbers: apart from the SRAM array, the pool is about **22 K flip-flops** (546 377 − 524 404). The region table dominates the control logic because every entry is held in flip-flops and looked up associatively. In a real build the 64 KiB array would be an SRAM macro or block RAM (the vendored SRAM wrapper supports both through its `BACKEND` parameter), not flip-flops.

## What it does **not** establish

* **No area, timing or power claim.** There is no technology library, no clock constraint, no place and route. The ABC mapping step is skipped because the WebAssembly Yosys used here terminates silently inside ABC, so the cell counts are neither minimised nor mapped; they are only useful to spot gross problems (inferred latches, runaway logic).
* The vendored ASIC-macro wrapper (`sram_asic_array.sv`) is **excluded**: it hangs this Yosys front end, and it is only instantiated for `BACKEND = ASIC`, which this check does not use. Therefore ASIC macro integration is **not** exercised.
* Yosys 0.71 is not the version named in the repository's guidance (0.33); results may differ with it.
* Clock-domain-crossing, reset-domain and scan/DFT checks were not done; the design has a single clock and an asynchronous active-low reset.
