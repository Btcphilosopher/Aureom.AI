# CXL adapter specification (future, separate project)

> **Status: specification and study only. Nothing in this repository implements, emulates or claims CXL.**
> A genuine CXL implementation requires **compatible controller and PHY IP, protocol-compliance testing and platform-interoperability testing**.
> None of those exist here. A normal DDR controller, a DMA link, the modelled DRAM tier, or the boundary stub (`rtl/future/sfmp_cxl_boundary_stub.sv`) must never be labelled CXL.
> The MemoryPool today has two tiers (SRAM, modelled DRAM); this document defines where a third tier would attach.

**How this study was made.** From public sources only (listed at the end); the normative CXL specification requires registration with the CXL Consortium and was **not** read. Statements below are
the author's reading of public summaries, kernel documentation and mailing-list material and **must be validated against the specification** before any design depends on them. Where a point is a design
proposal rather than a fact about CXL it is marked *(proposal)*.

## 1. What a CXL tier would be

| Concept | Public description (to be validated) | Consequence for the pool |
|---|---|---|
| Protocols | CXL runs over the PCIe physical layer with three protocols: **CXL.io** (PCIe-like: enumeration, configuration, DMA, interrupts), **CXL.cache** (a device caches host memory coherently), **CXL.mem** (the host accesses device-attached memory with load/store semantics). | A memory tier needs CXL.io (discovery/management) and CXL.mem (data). CXL.cache is irrelevant to a tier. |
| Device types | Type 1 (cache only), Type 2 (accelerator **with** device memory: coherent device memory, host-bias/device-bias style coherence), Type 3 (**memory expander**, CXL.io + CXL.mem). | The natural tier-2 device is **Type 3**. *Coherent device memory* (Type 2, HDM-D/-DB style) is a different and much larger problem: the device must answer host snoops. **The pool does not provide coherence and must not claim it.** |
| Address decode | Host-managed Device Memory is described by **HDM decoders** in the host bridge / switches / endpoint; in a Type 3 endpoint the decoder translates host physical → **device physical** addresses (Linux assumes the endpoint decoder is the one that translates HPA→DPA). | The tier-2 port is addressed by **device** physical address; HPA placement and interleave are host/OS business. |
| Discovery | PCIe enumeration finds the device; **DVSEC** capabilities identify it as CXL; a component register block exposes HDM-decoder capability and an MMIO **mailbox** (Identify, partition info, poison list, …); **CDAT** (obtained over **DOE**) carries per-range descriptors (DSMAS: memory range) and latency/bandwidth structures; the host firmware describes windows in ACPI (CEDT/CFMWS). Linux splits this into `cxl_pci` / `cxl_mem` / `cxl_port` / `cxl_acpi` and creates NUMA nodes / memory tiers from it. | The adapter, not the pool, performs discovery. The pool needs only the *result*: present, capacity, a **latency class** and a **bandwidth class** (from CDAT-equivalent data), and the coherence mode. |
| Hot-page monitoring | **CXL 3.2 (December 2024)** adds a *CXL Hotness Monitoring Unit (CHMU)* for memory tiering. The specification defines the **interface** — a ring buffer of hotness records exposed through a BAR plus capability / configuration / status registers; the **detection algorithm is implementation-defined**. A Linux RFC adds a perf driver that only captures raw hotness data (no migration yet). | The policy gets an optional **hotness stream** input; page-granular device-side counters complement, they do not replace, the pool's own transaction counters. |
| Errors | Poisoned data is signalled on returned data and handled by the requester; **viral** is a link-level containment state controlled through PCIe DVSEC registers; media errors are reported through the mailbox (poison list / media-error records); protocol errors reach the root port's AER; a CXL 3.1 RAS white paper describes the model. | The tier port needs a `poison` bit on responses and an error-event channel; the pool must never consume poisoned data silently and must raise `MEM_UE`-class RAS events. |
| Security | **IDE** (link integrity and data encryption) and, from CXL 3.1, **TSP** (TEE Security Protocol; most features optional). | A tier-2 placement of confidential data must be allowed only when the link is protected: `x_sec_link_protected`, `x_sec_placement_ok`. |
| Host integration | interleave sets, firmware tables (CEDT), hot-plug/removal, Fabric-Manager API for pooled devices, OS tiering (NUMA nodes, demotion/promotion) | The pool is an *accelerator-side* manager of its own managed window; it does not replace OS tiering of host memory. Hot-remove needs a quiesce handshake. |

## 2. The boundary (what the pool will expect from a tier-2 adapter)

Implemented as a port list in `rtl/future/sfmp_cxl_boundary_stub.sv` (lint-checked; behaviour = "device not present", any request fails).

| Group | Signals | Contract |
|---|---|---|
| Request / response | `x_req_valid/ready/write/dpa/wdata/wstrb`, `x_rsp_valid/ready/rdata/err/poison` | SFB2-style, in-order responses, addressed by **device** physical address; `x_rsp_poison` = uncorrectable data, never silently consumed |
| Discovery | `x_present`, `x_capacity_gran`, `x_lat_class`, `x_bw_class`, `x_coherence` | the pool allocates in tier 2 only if `x_present`; `x_coherence == 0` means the pool treats the range as **non-cacheable device memory** (anything else is reserved and refused until coherence is designed and verified) |
| Hotness | `x_hot_valid/ready/gran/count` | optional stream of hot-granule records (CHMU-like or adapter-local monitor) offered to the policy as an *additional* score input |
| Errors | `x_err_valid/type/dpa` (poison, viral, media, link-down) | become region error status (`RE_MEDIA`) and RAS events; link-down quarantines every region placed in tier 2 |
| Security | `x_sec_link_protected`, `x_sec_placement_ok` | confidential domains may not be placed or migrated into tier 2 unless both are set *(proposal: a per-domain "needs protected tier" flag)* |
| Quiesce | `x_quiesce_req/ack` | before hot-remove, reset or retrain: the pool drains tier-2 traffic, freezes (or evacuates) affected regions, then acknowledges |

## 3. Changes the pool would need *(proposal; all are generalisations of existing mechanisms)*

| Block | Change |
|---|---|
| `sfmp_pkg`, region table | tier field 1 → 2 bits; `RS_*`/`MG_*` unchanged |
| `sfmp_alloc` | a third bitmap/tier; `PREF_*` extended; tier order by `x_lat_class` instead of hard-wired SRAM → DRAM |
| `sfmp_tier_arb` ×3 | a third arbiter instance; the access path and migration channel get a third tier port (CloudDMA already abstracts "host memory ↔ SRAM"; tier-1↔tier-2 copies need a DMA with two external ports, **which does not exist** in the repository) |
| `sfmp_policy` | tiers ordered by latency class; a promotion path 2→1→0 and demotion 0→1→2; benefit/cost per tier pair; optional hotness input |
| `sfmp_ctrl` | `MIGRATE` destination tier becomes a tier number; quota per tier |
| Errors/security | poison propagation to the client response, per-domain protected-tier flag, link-down quarantine |

## 4. Verification plan *(proposal)*

1. Adapter-level: a **protocol-accurate CXL.mem/CXL.io model** (or licensed VIP) — not the DRAM model renamed — driving the boundary; poison, viral, link-down, hot-remove, back-pressure.
2. Pool-level: re-run the isolation, migration, fault-injection and policy suites with three tiers; add tier-2-specific mutants.
3. Platform-level: compliance testing and interoperability with real hosts and devices; **required before any "CXL" claim**.

## 5. Explicit non-goals of this project

CXL.cache / coherent device memory; a CXL controller or PHY; HDM decode; DVSEC/CDAT/DOE implementation; CHMU hardware; IDE/TSP; fabric management; multi-host sharing.

## Sources consulted

* CXL Consortium announcement of the 3.2 specification and coverage of the CXL Hotness Monitoring Unit — [insideHPC, "CXL Consortium Releases 3.2 Specification"](https://insidehpc.com/2024/12/cxl-consortium-releases-3-2-specification), [CXL 3.2 announcement (PDF)](https://computeexpresslink.org/wp-content/uploads/2024/12/CXL_3.2-Spec-Announcement_FINAL-1.pdf).
* CHMU description and the Linux perf-driver RFC — [LKML: "CXL Hotness Monitoring Unit perf driver" (RFC)](https://lkml.iu.edu/hypermail/linux/kernel/2411.2/05215.html).
* Linux CXL driver architecture (memdev, ports, HDM decoders, root/switch/endpoint decoders) — [kernel.org: CXL Driver Operation](https://docs.kernel.org/driver-api/cxl/linux/cxl-driver.html) and the kernel CXL documentation index (CDAT, memory tiers).
* DOE/CDAT discovery flow for a CXL 2.0 Type 3 expander — [Arm Neoverse reference design: Compute Express Link](https://neoverse-reference-design.docs.arm.com/en/main/features/cxl.html).
* RAS model (poison, viral, error reporting) — [CXL Consortium, "An Overview of RAS for CXL 3.1" (white paper)](https://computeexpresslink.org/wp-content/uploads/2024/08/An-Overview-of-RAS-for-Compute-Express-Link-3.1-Whitepaper.pdf) and a [Linux Plumbers CXL error-handling deck](https://lpc.events/event/18/contributions/1838/attachments/1472/3138/lpc-2024-cxl-error-handling-3.pdf).
* TSP / IDE — [CXL Consortium compliance-chapter updates for the TSP ECN](https://computeexpresslink.org/wp-content/uploads/2024/11/Compliance-Chapter-Updates-for-TSP-ECN_watermark.pdf).
