# 02 — Tenant isolation

> *A domain id on a request is a label the requester could lie about.* The pool therefore never takes the domain from the request.
> Accelerator port *i* is **hard-bound** to a domain by a privileged `BIND` (changeable only while the port is idle); the host-DMA port takes its domain from the IOMMU sideband and is
> refused without a valid translation. Every decision after that compares against ownership recorded by the privileged plane.

## 1. What is separated, and how

| Object | Where it lives | Protection |
|---|---|---|
| **Region metadata** (base, length, tier, owner, permissions, state, migration, dirty, error, generation, counters) | `sfmp_region_table`, entries tagged with the owning domain | written **only** by the command engine and migration engine; readable **only** through the privileged register page (a non-privileged read returns 0 + `rb_err`). One physical table, separated by tagging — *not* by physical partitioning |
| **Domain configuration** (managed window, SRAM quota, enable, auto-quarantine) | `sfmp_ctrl` | privileged `DOM_SET`; refused while the domain owns live regions; windows of enabled domains cannot overlap |
| **Allocation accounting** (SRAM granules reserved, live regions, per-domain counters) | region table, `sfmp_cntbank` | per-domain; the SRAM quota is enforced at ALLOC and at every promotion (reservations are counted from the start of a migration, so a promotion in flight cannot be used to exceed a quota) |
| **Client request path** | `sfmp_access` | domain comes from the port binding / IOMMU sideband; per-port queues (a port with no response credit blocks only itself) |
| **Memory contents** | tier arrays | every access is checked against the owner; a new extent is **zero-filled before the region becomes visible** |
| **Migration DMA** | `sfmp_mig_chan` | a trusted master, but each beat passes a window + direction check for the chunk it was given |

## 2. The five things that must not happen (brief §8) and what stops each

| Must not happen | Mechanism | Test / mutant |
|---|---|---|
| **Cross-tenant read** | owner check in the check ladder, on *every* access, after the mapping lookup; a faulting read returns **zero data** | `T10 §1` (16 reads), `M02` (owner check removed → detected) |
| **Cross-tenant write** | same; the write never reaches a tier, so the victim's bytes are unchanged (verified by the owner's golden-model sweep afterwards) | `T10 §1` (16 writes) |
| **Unauthorised remapping** | the data path has no write path to the table; every change is a **privileged** command (`rb_priv`); handles carry a generation, so a stale handle cannot free / re-permission / migrate somebody else's later allocation; migrations are re-validated by the command engine whether they come from a human or from the policy | `T03` (non-privileged writes refused, counted, state unchanged), `T10 §6`, `M06` (generation check removed), `M15` (privilege removed) |
| **Stale mapping reuse** | (1) `FREE` first blocks new accesses (`FREEING`) and waits until none is in flight; (2) a migration commits only with nothing in flight; (3) the old extent is zero-filled again before the next owner can see it; (4) `ALLOC` bumps the generation | `T10 §5` forces the same physical SRAM extent to be handed from domain A to B and requires B to read zeros; `T10 §8` repeats it across a demotion; `M07` (scrub writes ones) |
| **Access during unsafe migration** | a `FROZEN` region holds its accesses; `FREE`/`MIGRATE` of a migrating region is refused (`RC_BUSY`); commit requires drain; the commit-time monitor requires destination == source | `T05`, `T10 §7` (the owner's reads stall and complete with the right data; another tenant is unaffected), `M01`, `M11`, `M12`, `M14` |

## 3. No allocation-map side channel

The client-visible response for *unmapped*, *someone else's region*, *permission denied* and *region being scrubbed/freed* is identical: `err = 1, code = CE_FAULT, data = 0`.
A tenant therefore cannot probe the address space to learn what others have allocated. The precise cause is recorded for the management plane only (last-fault capture, per-cause counters).
`T10 §2` asserts that the client-visible code of an unmapped probe and a cross-tenant probe are equal while the management view still distinguishes them.

## 4. Quarantine

A domain with `auto-quarantine` set is quarantined on its **first isolation violation** (cross-tenant, permission, or untranslated host DMA): all its further accesses fail (`FC_QUAR`) until the management plane issues `CLR_QUAR`. Other domains are unaffected (`T10 §4`).

## 5. "Test isolation before allowing multi-tenant mode"

Enforcement is **not a mode**: no parameter, register or build option disables an isolation check, so `NUM_DOMAINS > 1` runs the same RTL that passed the single-tenant tests. The gate is therefore a *verification gate*:

1. `tools/run_regress.py` runs the isolation suite (`t10`) **first in every configuration** and records the result in `reports/regression.json` (`isolation_pass`).
2. `tools/perf_report.py` refuses to run the multi-tenant workloads unless `isolation_pass` is true there (`--skip-gate` exists for development and is printed in the report if used).

## 6. Trust boundaries — stated plainly

* The **management plane is trusted**: whatever drives `rb_priv` (ControlCore firmware / the host physical function) can reconfigure domains, read all metadata and counters, and migrate any region. Tenants have only their client port.
* The **host IOMMU is trusted** to bind requester → domain correctly and to set `hd_xlat_ok` only for translated transactions. The pool limits the blast radius of an IOMMU error to the regions of the domain it names; it cannot detect a wrong binding.
* The **tiers are trusted to be separate memories**: the pool does not encrypt data at rest in DRAM and cannot stop a physical attacker on the external bus.
* **Not claimed:** side-channel isolation (SRAM arbitration and shared tier latency are observable — the per-domain latency counters themselves show it); denial-of-service guarantees beyond round-robin arbitration, per-port queues and the SRAM *capacity* quota (there is **no bandwidth quota**: a tenant streaming from DRAM slows others' DRAM accesses — measured in the `mixed` workload); data remanence (a freed extent keeps its bytes until it is zero-filled on the next allocation, i.e. zero-on-allocate, not zero-on-free; a cold-boot or management-plane read of physical memory sees them); error-containment beyond the per-region error code.
* The per-region metadata storage is a single shared array; a hardware fault in the table could in principle break separation. There is no ECC/parity on the table.
