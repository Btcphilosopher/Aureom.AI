# 04 — Tiering policy

Module: `rtl/pool/sfmp_policy.sv` (baseline hardware policy). The policy is **advisory**: its only output is a migration *request*; the command engine re-validates it (ownership, quota, space, state), so no policy — hardware, firmware or ML — can bypass an isolation or allocation rule.

## 1. The policy interface (what any replacement must use)

| Direction | Signals | Meaning |
|---|---|---|
| in | per-region **epoch read and write counters** (region table read port `rt_*` + `rt_consume`) | real transactions counted at the tier handshake; the policy *consumes* (reads and clears) them once per epoch |
| in | region **size**, **tier**, owner, pin and migration state; SRAM **occupancy** and capacity | from the same read port and the allocator |
| in | **migration cost** (programmed `COST_PER_GRAN`, or measured), **benefit per access** (programmed `DELTA`, or measured) | see §3 |
| out | `req_valid / req_ready`, `req_idx`, `req_dst` (+ `req_done`, `req_rc`) | **one** migration request at a time; the command engine answers with a result code |

A software policy uses the same request through the privileged `CMD_MIGRATE` command and reads the same statistics through `R_RSEL/R_RD_*` (including `R_RD_SCORE`, the hardware hotness score). Selecting hardware policy vs. manual-only is `R_CTRL.POLICY_EN`.

## 2. Baseline algorithm (integer arithmetic, no floating point)

Every `EPOCH_CYCLES` the policy scans all regions (one per cycle):

```
hotness   S ← S − (S >> D) + ((accesses << 4) >> D)          EWMA, Q4 accesses per epoch   (frequency + recent history)
wS        likewise for the write count                         (read/write ratio)
fresh     a region whose generation changed starts from S = 0
```

For each **DRAM region that is ACTIVE, unpinned, not migrating and not cooling down** (promotion candidate):

```
benefit = (S >> 4) × DELTA × HORIZON                           cycles saved over HORIZON epochs if served by SRAM
cost    = len × COST_PER_GRAN + min(wS >> 4, chunks) × COST_PER_CHUNK        (copy + expected dirty re-copy: region size, write ratio, migration cost)
promote ⇔ (S >> 4) ≥ HOT_MIN  and  benefit > cost + (cost >> MARGIN_SHIFT)
```

Decision once per epoch, **one request**:

1. best candidate fits in the free SRAM (**available capacity**) → promote it;
2. else, demote the **coldest** SRAM region (unpinned, not cooling down) **only if** the candidate is hotter by at least `HYST_GAP` accesses/epoch, the demotion frees enough space, **and the candidate's benefit covers both migrations** (`benefit > (cost_promote + cost_demote)(1 + 2^-MARGIN_SHIFT)`) — found by a test: without the second-migration term the policy demoted for candidates that failed to qualify next epoch;
3. else, if SRAM occupancy exceeds `HIGH_WATERMARK` and the coldest SRAM region is below `HOT_MIN`, demote it (**memory-pressure relief — opt-in:** the reset value of the watermark is the SRAM capacity, so it never fires; found by a test: with an 87.5 % default it demoted cold data for no demonstrated demand).

## 3. Measured cost and benefit

* **`AUTOCOST`**: after every completed migration the policy folds `cycles / granules` into the cost estimate (`new = (3·old + sample)/4`), seeded from `COST_PER_GRAN`. Under load the measurement rises well above the idle figure (≈1.1 K → 1.6–1.8 K cycles per granule in the `hotcold` run) because migrations compete with tenant traffic.
* **`AUTODELTA`**: every epoch the policy divides the per-tier service-latency counters (`mean(tier 1) − mean(tier 0)`) and smooths it (`new = (old + sample)/2`). While tier 0 has too few samples (everything starts in DRAM) it uses the programmed SRAM reference latency (`R_POL_SRAMLAT`, default 3). Found by a test: with the idle-measured benefit (11 cycles) the policy never migrated in the 4-port workloads, whose *loaded* gap is ≈ 30 cycles.

## 4. Avoiding pathological migration oscillation

| Mechanism | Effect |
|---|---|
| **Hysteresis** (`HYST_GAP`) | a region is demoted only when clearly colder than what replaces it |
| **Cooldown** (`COOLDOWN_EPOCHS`) | a region just requested cannot be requested again for N epochs; a **refused** request backs the region off 4× longer |
| **Cost-aware margin** | a migration must pay for itself with margin over the horizon; making room must pay for two migrations |
| **One request per epoch, none while migrating** | bounds the migration bandwidth the policy can consume |

Hysteresis in isolation (`T12h`, cooldown 0, long horizon, two almost equally hot regions competing for one SRAM slot): **0 migration requests with a gap of 24 accesses/epoch, 2 (a demotion and a promotion) with gap 0** — the test was added after the mutation campaign showed that removing the hysteresis term went unnoticed by the other tests.

Measured (`T12c`): hot spot alternating between two regions that compete for one SRAM slot, every 8000 cycles, 10 phases: **2 migrations with cooldown + hysteresis vs 10 without** (all other settings equal). `T12g`: a region that cannot be placed (fragmented SRAM) is retried 7 times in ~100 epochs instead of every cooldown period.

## 5. Parameters (registers `R_POL_*`; defaults at reset)

| Register field | Default | Meaning |
|---|---|---|
| `EPOCH_CYCLES` | 20000 | scan period (the traces use 8192) |
| `HOT_MIN` | 4 | minimum accesses/epoch for promotion |
| `DECAY_SHIFT` | 1 | EWMA weight 2^-D |
| `COOLDOWN_EPOCHS` | 4 | |
| `HORIZON_EPOCHS` | 8 | how long a promotion is assumed to pay |
| `COST_PER_GRAN` / `COST_PER_CHUNK` | 1500 / 400 | cycles |
| `DELTA` | 18 | cycles saved per access (manual); `CTRL.AUTODELTA` measures it |
| `MARGIN_SHIFT` | 1 | cost × 1.5 |
| `HYST_GAP` | 8 | accesses/epoch |
| `HIGH_WATERMARK` | SRAM capacity | pressure relief off |
| `SRAMLAT` | 3 | tier-0 reference latency for `AUTODELTA` |

## 6. Known weaknesses (observed in simulation; see `../reports/PERFORMANCE.md`)

* It **cannot beat free placement** when migration is expensive relative to the run: on short runs (≈60 epochs) naive first-come SRAM allocation (`auto`) or an oracle (`static`) often beats it; the amortization sweep shows where it breaks even.
* On rotating hot sets that exceed SRAM (`oversub`) it can be **slower than not tiering** (migrations cost more than they return).
* It has **no compaction**: with a fragmented SRAM it can only refuse and back off (`frag`).
* It ignores bandwidth contention between tenants and treats all tenants alike (fairness comes from the per-domain SRAM quota, not from the policy).
* Single request per epoch; epoch length and horizon are static.
