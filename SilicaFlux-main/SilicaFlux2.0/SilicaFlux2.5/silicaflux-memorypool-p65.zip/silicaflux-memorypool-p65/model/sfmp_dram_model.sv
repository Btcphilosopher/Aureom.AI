// =============================================================================
// MemoryPool :: sfmp_dram_model -- MODELLED external DRAM tier  (SIMULATION ONLY, NOT SYNTHESIZABLE)
//
//   THIS IS NOT A DRAM CONTROLLER, NOT A PHY, NOT DDR4/DDR5/LPDDR/HBM AND NOT CXL.
//   It is a behavioural stand-in with a bank / row-buffer timing abstraction, used so the pool's
//   tiering decisions can be measured against a memory that is much slower than SRAM.  The cycle
//   counts below are MODEL PARAMETERS in pool-clock cycles; they are not JEDEC timings and no
//   claim is made that any real device behaves like this.  (The repository already contains two
//   other behavioural memories -- `extmem_sim_mc` of the P24 bridge and MemoryLab's `dram.py`;
//   neither is a controller.  See docs/00_AUDIT.md.)
//
// Behaviour
//   * port protocol = the pool's tier port (SFB2-style, in-order responses, up to MAXOUT outstanding);
//     the response never appears in the acceptance cycle (R5); a write is applied at acceptance and
//     acknowledged later (R7); an errored write has no side effect (R8);
//   * row-buffer model: bank = addr[ROW_LG +: BANK_LG], row = addr >> (ROW_LG+BANK_LG), open-page policy:
//       row hit      latency T_CL
//       bank closed  latency T_RCD + T_CL
//       row conflict latency T_RP + T_RCD + T_CL
//     responses are spaced T_BURST apart (data-bus occupancy) and returned in order;
//   * refresh: every T_REFI cycles the interface stops accepting for T_RFC cycles and all rows close;
//   * memory contents are initialised to a deterministic NON-ZERO pattern so any path that forgot to
//     scrub a new region shows up as non-zero data;
//   * fault injection (testbench controlled): one-shot or persistent data corruption on writes into an
//     address range, and an error-response window.
// =============================================================================
`default_nettype none
/* verilator lint_off BLKSEQ */
/* verilator lint_off WIDTHEXPAND */
/* verilator lint_off WIDTHTRUNC */
/* verilator lint_off UNUSEDSIGNAL */

module sfmp_dram_model #(
  parameter int DW       = 32,
  parameter int BYTES    = 262144,
  parameter int MAXOUT   = 4,
  parameter int BANK_LG  = 3,
  parameter int ROW_LG   = 10,
  parameter int T_CL     = 12,
  parameter int T_RCD    = 12,
  parameter int T_RP     = 12,
  parameter int T_BURST  = 1,
  parameter int T_REFI   = 3900,
  parameter int T_RFC    = 60,
  parameter bit REFRESH_EN = 1'b1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              req_valid,
  output logic                   req_ready,
  input  wire logic              req_write,
  input  wire logic [31:0]       req_addr,
  input  wire logic [DW-1:0]     req_wdata,
  input  wire logic [DW/8-1:0]   req_wstrb,
  output logic                   rsp_valid,
  input  wire logic              rsp_ready,
  output logic      [DW-1:0]     rsp_rdata,
  output logic                   rsp_error,
  // fault injection
  input  wire logic              inj_corrupt_en,
  input  wire logic [31:0]       inj_corrupt_lo,
  input  wire logic [31:0]       inj_corrupt_hi,      // exclusive
  input  wire logic [DW-1:0]     inj_corrupt_mask,
  input  wire logic              inj_corrupt_once,
  input  wire logic              inj_err_en,
  input  wire logic [31:0]       inj_err_lo,
  input  wire logic [31:0]       inj_err_hi,          // exclusive
  input  wire logic              inj_stall_en         // hold request acceptance (req_ready = 0) while set: models a busy / refreshing DRAM
);
  localparam int DWB   = DW / 8;
  localparam int NBANK = 1 << BANK_LG;

  logic [7:0] mem [0:BYTES-1];

  // statistics (read hierarchically by the testbench)
  longint unsigned st_reads, st_writes, st_row_hit, st_row_closed, st_row_conf, st_refresh, st_busy_stall;
  longint unsigned cyc;
  logic            corrupt_fired;      // one-shot corruption already applied (re-armed when inj_corrupt_en drops)
  longint unsigned st_corrupted, st_errs;

  // in-flight queue
  logic [DW-1:0]   q_data [MAXOUT];
  logic            q_err  [MAXOUT];
  longint unsigned q_due  [MAXOUT];
  int              q_head, q_tail, q_cnt;
  longint unsigned last_due, ref_until, ref_cnt;
  logic            bank_open [NBANK];
  int unsigned     bank_row  [NBANK];

  initial begin
    for (int i = 0; i < BYTES; i++) mem[i] = 8'hA5 ^ 8'(i * 37) ^ 8'(i >> 8);   // deterministic non-zero pattern
  end

  assign req_ready = (q_cnt < MAXOUT) && (cyc >= ref_until) && !inj_stall_en;
  assign rsp_valid = (q_cnt != 0) && (q_due[q_head] <= cyc);
  assign rsp_rdata = rsp_valid ? q_data[q_head] : '0;
  assign rsp_error = rsp_valid ? q_err[q_head]  : 1'b0;

  function automatic logic in_rng(input logic [31:0] a, input logic [31:0] lo, input logic [31:0] hi);
    return (a >= lo) && (a < hi);
  endfunction

  logic            acc;
  int unsigned     bank, row, lat;
  logic [DW-1:0]   rd, wr_old;
  logic            e;
  longint unsigned due;
  logic [31:0]     base;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      corrupt_fired <= 1'b0; st_corrupted <= 0; st_errs <= 0;
      cyc <= 0; q_head <= 0; q_tail <= 0; q_cnt <= 0; last_due <= 0; ref_until <= 0; ref_cnt <= 0;
      st_reads <= 0; st_writes <= 0; st_row_hit <= 0; st_row_closed <= 0; st_row_conf <= 0; st_refresh <= 0; st_busy_stall <= 0;
      for (int b = 0; b < NBANK; b++) begin bank_open[b] <= 1'b0; bank_row[b] <= 0; end
    end else begin
      cyc <= cyc + 1;
      acc = req_valid && req_ready;
      if (!inj_corrupt_en) corrupt_fired <= 1'b0;
      if (req_valid && !req_ready) st_busy_stall <= st_busy_stall + 1;
      // refresh
      if (REFRESH_EN) begin
        ref_cnt <= ref_cnt + 1;
        if (ref_cnt + 1 >= T_REFI) begin
          ref_cnt   <= 0;
          ref_until <= cyc + 1 + T_RFC;
          st_refresh <= st_refresh + 1;
          for (int b = 0; b < NBANK; b++) bank_open[b] <= 1'b0;
        end
      end
      // response pop
      if (rsp_valid && rsp_ready) begin
        q_head <= (q_head == MAXOUT - 1) ? 0 : q_head + 1;
      end
      // accept
      if (acc) begin
        base = {req_addr[31:$clog2(DWB)], {$clog2(DWB){1'b0}}};
        bank = (base >> ROW_LG) & (NBANK - 1);
        row  = base >> (ROW_LG + BANK_LG);
        if (bank_open[bank] && bank_row[bank] == row)  begin lat = T_CL;                    st_row_hit    <= st_row_hit + 1;    end
        else if (!bank_open[bank])                     begin lat = T_RCD + T_CL;            st_row_closed <= st_row_closed + 1; end
        else                                           begin lat = T_RP + T_RCD + T_CL;     st_row_conf   <= st_row_conf + 1;   end
        bank_open[bank] <= 1'b1;
        bank_row[bank]  <= row;
        due = cyc + lat;
        if (last_due + T_BURST > due) due = last_due + T_BURST;
        last_due <= due;
        e  = 1'b0;
        rd = '0;
        for (int b = 0; b < DWB; b++) rd[b*8 +: 8] = mem[base + b];
        if (inj_err_en && (in_rng(base, inj_err_lo, inj_err_hi))) begin
          e = 1'b1; rd = '0; st_errs <= st_errs + 1;           // R8: an errored access has no side effect
        end else if (req_write) begin
          wr_old = rd;
          for (int b = 0; b < DWB; b++) if (req_wstrb[b]) mem[base + b] <= req_wdata[b*8 +: 8];
          if (inj_corrupt_en && in_rng(base, inj_corrupt_lo, inj_corrupt_hi) && !(inj_corrupt_once && corrupt_fired)) begin
            for (int b = 0; b < DWB; b++)
              if (req_wstrb[b]) mem[base + b] <= req_wdata[b*8 +: 8] ^ inj_corrupt_mask[b*8 +: 8];
            corrupt_fired <= 1'b1;
            st_corrupted  <= st_corrupted + 1;
          end
          rd = '0;
        end
        if (req_write) st_writes <= st_writes + 1; else st_reads <= st_reads + 1;
        q_data[q_tail] <= rd;
        q_err[q_tail]  <= e;
        q_due[q_tail]  <= due;
        q_tail <= (q_tail == MAXOUT - 1) ? 0 : q_tail + 1;
      end
      case ({acc, rsp_valid && rsp_ready})
        2'b10:   q_cnt <= q_cnt + 1;
        2'b01:   q_cnt <= q_cnt - 1;
        default: q_cnt <= q_cnt;
      endcase
    end
  end
  wire unused_ok = &{1'b0, wr_old};
endmodule

`default_nettype wire
