// =============================================================================
// MemoryPool :: tb_tier_path -- unit bench: tier arbiter + SRAM tier (sram_sp) + DRAM model + scrubber
//
// For each tier: NM = 3 masters (two random read/write generators with up to 3 requests outstanding,
// plus the scrubber on master 2) share one tier through `sfmp_tier_arb`.  Checks:
//   * every read returns the value last written by the SAME master to that word (private ranges),
//   * responses are routed to the right master and arrive in order (per-master expected queue),
//   * the scrubber zeroes its extent (and only its extent),
//   * no response is lost / duplicated (final outstanding count is zero),
//   * the DRAM model's row-hit / conflict latency is visible (hit < conflict).
// Prints "TB RESULT PASS" / "TB RESULT FAIL".
// =============================================================================
`timescale 1ns/1ps

module tb_tier_path;
  localparam int DW  = 32;
  localparam int DWB = DW / 8;
  localparam int NM  = 3;
  localparam int SRAM_BYTES = 8192;
  localparam int DRAM_BYTES = 65536;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  // all TB drives happen 1 ns after the clock edge (no race with the DUT's clocked logic)
  task automatic tick(); @(posedge clk); #1; endtask

  int errors = 0;
  int checks = 0;
  task automatic fail(input string m);
    errors++;
    if (errors < 20) $display("[%0t] FAIL: %s", $time, m);
  endtask

  // ------------------------------------------------------------------ per-tier plumbing
  // tier 0
  logic [NM-1:0]        a0_req_valid, a0_req_ready, a0_req_write, a0_rsp_valid, a0_rsp_ready, a0_rsp_err;
  logic [NM*32-1:0]     a0_req_addr;
  logic [NM*DW-1:0]     a0_req_wdata, a0_rsp_rdata;
  logic [NM*DWB-1:0]    a0_req_wstrb;
  logic s0_req_valid, s0_req_ready, s0_req_write, s0_rsp_valid, s0_rsp_ready, s0_rsp_err, s0_oor;
  logic [31:0] s0_req_addr; logic [DW-1:0] s0_req_wdata, s0_rsp_rdata; logic [DWB-1:0] s0_req_wstrb;
  logic ev0_ss, ev0_ts; logic [7:0] ev0_loss;
  // tier 1
  logic [NM-1:0]        a1_req_valid, a1_req_ready, a1_req_write, a1_rsp_valid, a1_rsp_ready, a1_rsp_err;
  logic [NM*32-1:0]     a1_req_addr;
  logic [NM*DW-1:0]     a1_req_wdata, a1_rsp_rdata;
  logic [NM*DWB-1:0]    a1_req_wstrb;
  logic s1_req_valid, s1_req_ready, s1_req_write, s1_rsp_valid, s1_rsp_ready, s1_rsp_err;
  logic [31:0] s1_req_addr; logic [DW-1:0] s1_req_wdata, s1_rsp_rdata; logic [DWB-1:0] s1_req_wstrb;
  logic ev1_ss, ev1_ts; logic [7:0] ev1_loss;

  sfmp_tier_arb #(.NM(NM), .DW(DW), .MAXOUT(4)) u_arb0 (
    .clk, .rst_n,
    .m_req_valid(a0_req_valid), .m_req_ready(a0_req_ready), .m_req_write(a0_req_write), .m_req_addr(a0_req_addr),
    .m_req_wdata(a0_req_wdata), .m_req_wstrb(a0_req_wstrb),
    .m_rsp_valid(a0_rsp_valid), .m_rsp_ready(a0_rsp_ready), .m_rsp_rdata(a0_rsp_rdata), .m_rsp_err(a0_rsp_err),
    .s_req_valid(s0_req_valid), .s_req_ready(s0_req_ready), .s_req_write(s0_req_write), .s_req_addr(s0_req_addr),
    .s_req_wdata(s0_req_wdata), .s_req_wstrb(s0_req_wstrb),
    .s_rsp_valid(s0_rsp_valid), .s_rsp_ready(s0_rsp_ready), .s_rsp_rdata(s0_rsp_rdata), .s_rsp_err(s0_rsp_err),
    .ev_slave_stall(ev0_ss), .ev_tag_stall(ev0_ts), .ev_loss(ev0_loss));
  sfmp_sram_tier #(.DW(DW), .BYTES(SRAM_BYTES)) u_sram (
    .clk, .rst_n, .req_valid(s0_req_valid), .req_ready(s0_req_ready), .req_write(s0_req_write), .req_addr(s0_req_addr),
    .req_wdata(s0_req_wdata), .req_wstrb(s0_req_wstrb), .rsp_valid(s0_rsp_valid), .rsp_ready(s0_rsp_ready),
    .rsp_rdata(s0_rsp_rdata), .rsp_err(s0_rsp_err), .oor_evt(s0_oor));

  sfmp_tier_arb #(.NM(NM), .DW(DW), .MAXOUT(4)) u_arb1 (
    .clk, .rst_n,
    .m_req_valid(a1_req_valid), .m_req_ready(a1_req_ready), .m_req_write(a1_req_write), .m_req_addr(a1_req_addr),
    .m_req_wdata(a1_req_wdata), .m_req_wstrb(a1_req_wstrb),
    .m_rsp_valid(a1_rsp_valid), .m_rsp_ready(a1_rsp_ready), .m_rsp_rdata(a1_rsp_rdata), .m_rsp_err(a1_rsp_err),
    .s_req_valid(s1_req_valid), .s_req_ready(s1_req_ready), .s_req_write(s1_req_write), .s_req_addr(s1_req_addr),
    .s_req_wdata(s1_req_wdata), .s_req_wstrb(s1_req_wstrb),
    .s_rsp_valid(s1_rsp_valid), .s_rsp_ready(s1_rsp_ready), .s_rsp_rdata(s1_rsp_rdata), .s_rsp_err(s1_rsp_err),
    .ev_slave_stall(ev1_ss), .ev_tag_stall(ev1_ts), .ev_loss(ev1_loss));
  sfmp_dram_model #(.DW(DW), .BYTES(DRAM_BYTES), .MAXOUT(4), .REFRESH_EN(1'b1), .T_REFI(900), .T_RFC(30)) u_dram (
    .clk, .rst_n, .req_valid(s1_req_valid), .req_ready(s1_req_ready), .req_write(s1_req_write), .req_addr(s1_req_addr),
    .req_wdata(s1_req_wdata), .req_wstrb(s1_req_wstrb), .rsp_valid(s1_rsp_valid), .rsp_ready(s1_rsp_ready),
    .rsp_rdata(s1_rsp_rdata), .rsp_error(s1_rsp_err),
    .inj_corrupt_en(1'b0), .inj_corrupt_lo(32'd0), .inj_corrupt_hi(32'd0), .inj_corrupt_mask('0), .inj_corrupt_once(1'b0),
    .inj_err_en(1'b0), .inj_err_lo(32'd0), .inj_err_hi(32'd0), .inj_stall_en(1'b0));

  // ------------------------------------------------------------------ scrubber on master 2 of both tiers
  logic sc_start, sc_tier, sc_idle, sc_done, sc_err;
  logic [31:0] sc_base, sc_len, sc_ev;
  logic sc_t0_v, sc_t1_v; logic [31:0] sc_t0_a, sc_t1_a; logic [DW-1:0] sc_wd; logic [DWB-1:0] sc_ws;
  sfmp_scrub #(.DW(DW)) u_scrub (
    .clk, .rst_n, .start(sc_start), .tier(sc_tier), .base(sc_base), .len_bytes(sc_len), .idle(sc_idle), .done(sc_done), .err(sc_err),
    .t0_req_valid(sc_t0_v), .t0_req_ready(a0_req_ready[2]), .t0_req_addr(sc_t0_a), .t0_rsp_valid(a0_rsp_valid[2]), .t0_rsp_err(a0_rsp_err[2]),
    .t1_req_valid(sc_t1_v), .t1_req_ready(a1_req_ready[2]), .t1_req_addr(sc_t1_a), .t1_rsp_valid(a1_rsp_valid[2]), .t1_rsp_err(a1_rsp_err[2]),
    .req_wdata(sc_wd), .req_wstrb(sc_ws), .ev_bytes(sc_ev));
  assign a0_req_valid[2] = sc_t0_v;  assign a0_req_write[2] = 1'b1;  assign a0_req_addr[2*32 +: 32] = sc_t0_a;
  assign a0_req_wdata[2*DW +: DW] = sc_wd;  assign a0_req_wstrb[2*DWB +: DWB] = sc_ws;  assign a0_rsp_ready[2] = 1'b1;
  assign a1_req_valid[2] = sc_t1_v;  assign a1_req_write[2] = 1'b1;  assign a1_req_addr[2*32 +: 32] = sc_t1_a;
  assign a1_req_wdata[2*DW +: DW] = sc_wd;  assign a1_req_wstrb[2*DWB +: DWB] = sc_ws;  assign a1_rsp_ready[2] = 1'b1;

  // ------------------------------------------------------------------ random masters 0 and 1 (both tiers)
  // master m owns bytes [m*RANGE, (m+1)*RANGE) of each tier; the scrubber's extent is above 2*RANGE.
  localparam int RANGE_S = 1024;
  localparam int RANGE_D = 4096;
  byte unsigned shadow_s [2][RANGE_S];
  byte unsigned shadow_d [2][RANGE_D];
  bit           known_s  [2][RANGE_S/DWB];   // word written at least once (DRAM/SRAM initial content differs)
  bit           known_d  [2][RANGE_D/DWB];

  typedef struct { bit is_read; logic [DW-1:0] exp; bit chk; int tier; int word; int master; longint t_issue; } exp_t;
  exp_t expq [2][2][$];     // [tier][master]
  int   outstanding;
  int   rd_lat_min [2] = '{99999, 99999};
  int   rd_lat_max [2] = '{0, 0};
  longint total_rd [2] = '{0, 0};
  longint total_wr [2] = '{0, 0};
  longint cyc = 0;
  logic [DW-1:0] last_rd [2][2];
  always @(posedge clk) cyc <= cyc + 1;

  // request drivers: tier t, master m
  logic [1:0] drv_v [2];        // [tier][master] valid
  logic       drv_w [2][2];
  logic [31:0] drv_a [2][2];
  logic [DW-1:0] drv_d [2][2];
  logic [DWB-1:0] drv_s [2][2];

  // master-side RESPONSE back-pressure: rr_mode 0 = always ready, 1 = ready only 40 % of the cycles (random).
  // (Mutation M20 -- the arbiter popping its response tag without waiting for the master -- is only visible with this.)
  bit   rr_mode = 1'b0;
  logic rr [2][2];
  for (genvar t = 0; t < 2; t++) begin : g_rrt
    for (genvar m = 0; m < 2; m++) begin : g_rrm
      initial rr[t][m] = 1'b1;
      always @(posedge clk) begin
        #1;
        rr[t][m] = rr_mode ? ($urandom_range(0, 9) < 4) : 1'b1;
      end
    end
  end

  for (genvar m = 0; m < 2; m++) begin : g_conn
    assign a0_req_valid[m] = drv_v[0][m];  assign a0_req_write[m] = drv_w[0][m];  assign a0_req_addr[m*32 +: 32] = drv_a[0][m];
    assign a0_req_wdata[m*DW +: DW] = drv_d[0][m];  assign a0_req_wstrb[m*DWB +: DWB] = drv_s[0][m];  assign a0_rsp_ready[m] = rr[0][m];
    assign a1_req_valid[m] = drv_v[1][m];  assign a1_req_write[m] = drv_w[1][m];  assign a1_req_addr[m*32 +: 32] = drv_a[1][m];
    assign a1_req_wdata[m*DW +: DW] = drv_d[1][m];  assign a1_req_wstrb[m*DWB +: DWB] = drv_s[1][m];  assign a1_rsp_ready[m] = rr[1][m];
  end

  // response checker: one process per tier and master
  for (genvar t = 0; t < 2; t++) begin : g_rt
    for (genvar m = 0; m < 2; m++) begin : g_rm
      wire         rv = (t == 0) ? a0_rsp_valid[m] : a1_rsp_valid[m];
      wire [DW-1:0] rd = (t == 0) ? a0_rsp_rdata[m*DW +: DW] : a1_rsp_rdata[m*DW +: DW];
      wire         re = (t == 0) ? a0_rsp_err[m] : a1_rsp_err[m];
      wire         rrdy = rr[t][m];
      logic        hold_v = 1'b0;                      // previous cycle: response valid but not accepted
      logic [DW-1:0] hold_d; logic hold_e;
      always @(negedge clk) if (rst_n) begin
        if (hold_v && !rv) fail($sformatf("tier %0d master %0d: response withdrawn before acceptance (SFB2 R2)", t, m));
        if (hold_v && rv && (rd !== hold_d || re !== hold_e)) fail($sformatf("tier %0d master %0d: response changed before acceptance", t, m));
        hold_v = rv && !rrdy; hold_d = rd; hold_e = re;
      end
      always @(negedge clk) if (rst_n && rv && rrdy) begin
        exp_t e;
        if (expq[t][m].size() == 0) fail($sformatf("tier %0d master %0d: unsolicited response", t, m));
        else begin
          e = expq[t][m].pop_front();
          outstanding--;
          last_rd[t][m] = rd;
          if (re) fail($sformatf("tier %0d master %0d: unexpected error response", t, m));
          if (e.is_read) begin
            int lat;
            lat = int'(cyc - e.t_issue);
            if (lat < rd_lat_min[t]) rd_lat_min[t] = lat;
            if (lat > rd_lat_max[t]) rd_lat_max[t] = lat;
            if (e.chk) begin
              checks++;
              if (rd !== e.exp) fail($sformatf("tier %0d master %0d word %0d: read %08h expected %08h", t, m, e.word, rd, e.exp));
            end
          end
        end
      end
    end
  end

  // stimulus per tier/master
  task automatic run_master(input int t, input int m, input int n, input int seed_in);
    int unsigned rnd;
    int words, w;
    logic [DW-1:0] d;
    logic [DWB-1:0] s;
    bit wr;
    exp_t e;
    rnd = seed_in;
    words = (t == 0) ? RANGE_S / DWB : RANGE_D / DWB;
    for (int i = 0; i < n; i++) begin
      rnd = rnd * 1664525 + 1013904223;
      w   = (rnd >> 8) % words;
      // first touch of a word is always a full write so the shadow is defined
      wr  = ((t == 0 ? !known_s[m][w] : !known_d[m][w]) || ((rnd >> 3) % 100) < 45);
      d   = $urandom;
      s   = {DWB{1'b1}};
      if (wr && (t == 0 ? known_s[m][w] : known_d[m][w]) && (((rnd >> 20) % 4) == 0)) s = DWB'($urandom_range(1, (1 << DWB) - 1));   // partial strobes
      // wait until fewer than 3 requests outstanding for this master/tier
      while (expq[t][m].size() >= 3) tick();
      // present
      drv_v[t][m] = 1'b1; drv_w[t][m] = wr; drv_a[t][m] = 32'(m * ((t == 0) ? RANGE_S : RANGE_D) + w * DWB);
      drv_d[t][m] = d; drv_s[t][m] = s;
      do @(negedge clk); while (!((t == 0) ? a0_req_ready[m] : a1_req_ready[m]));
      tick();
      // accepted this edge
      e.is_read = !wr; e.tier = t; e.word = w; e.master = m; e.t_issue = cyc; e.chk = 1'b0; e.exp = '0;
      if (wr) begin
        for (int b = 0; b < DWB; b++) if (s[b]) begin
          if (t == 0) shadow_s[m][w*DWB + b] = d[b*8 +: 8]; else shadow_d[m][w*DWB + b] = d[b*8 +: 8];
        end
        if (t == 0) known_s[m][w] = 1'b1; else known_d[m][w] = 1'b1;
        total_wr[t]++;
      end else begin
        for (int b = 0; b < DWB; b++) e.exp[b*8 +: 8] = (t == 0) ? shadow_s[m][w*DWB + b] : shadow_d[m][w*DWB + b];
        e.chk = 1'b1;
        total_rd[t]++;
      end
      expq[t][m].push_back(e);
      outstanding++;
      drv_v[t][m] = 1'b0;
      if (((rnd >> 12) % 5) == 0) repeat ((rnd >> 16) % 4) tick();
    end
  endtask

  // single read through tier t, master m (registers an expectation so the response checker stays quiet)
  task automatic rd_one(input int t, input int m, input logic [31:0] addr, output logic [DW-1:0] data);
    exp_t e;
    drv_v[t][m] = 1'b1; drv_w[t][m] = 1'b0; drv_a[t][m] = addr;
    do @(negedge clk); while (!((t == 0) ? a0_req_ready[m] : a1_req_ready[m]));
    tick();
    drv_v[t][m] = 1'b0;
    e.is_read = 1'b1; e.chk = 1'b0; e.exp = '0; e.tier = t; e.word = 0; e.master = m; e.t_issue = cyc;
    expq[t][m].push_back(e); outstanding++;
    while (expq[t][m].size() != 0) tick();
    data = last_rd[t][m];
  endtask


  // ------------------------------------------------------------------ test sequence
  int scrub_nonzero;
  initial begin
    for (int t = 0; t < 2; t++) for (int m = 0; m < 2; m++) begin drv_v[t][m] = 1'b0; drv_w[t][m] = 1'b0; drv_a[t][m] = '0; drv_d[t][m] = '0; drv_s[t][m] = '0; end
    sc_start = 1'b0; sc_tier = 1'b0; sc_base = '0; sc_len = '0; outstanding = 0;
    repeat (4) tick();
    rst_n = 1'b1;
    repeat (2) tick();

    // phase 1: random traffic on both tiers from both masters, concurrently, while the scrubber runs
    fork
      run_master(0, 0, 600, 32'h1111);
      run_master(0, 1, 600, 32'h2222);
      run_master(1, 0, 400, 32'h3333);
      run_master(1, 1, 400, 32'h4444);
      begin  // scrub 2 KiB of tier 0 at 4096.. and 8 KiB of tier 1 at 16384.., after pre-filling the words with a known non-zero value
        repeat (50) tick();
        sc_start = 1'b1; sc_tier = 1'b0; sc_base = 32'd4096; sc_len = 32'd2048; tick(); sc_start = 1'b0;
        do @(negedge clk); while (!sc_done);
        if (sc_err) fail("tier 0 scrub reported an error");
        while (!sc_idle) @(negedge clk);
        tick();
        sc_start = 1'b1; sc_tier = 1'b1; sc_base = 32'd16384; sc_len = 32'd8192; tick(); sc_start = 1'b0;
        do @(negedge clk); while (!sc_done);
        if (sc_err) fail("tier 1 scrub reported an error");
      end
    join
    // drain
    while (outstanding != 0) tick();
    repeat (20) tick();
    if (outstanding != 0) fail("outstanding requests at end");

    // phase 1b: the same kind of random traffic with the MASTERS applying response back-pressure (no scrubber)
    rr_mode = 1'b1;
    fork
      run_master(0, 0, 300, 32'h5555);
      run_master(0, 1, 300, 32'h6666);
      run_master(1, 0, 200, 32'h7777);
      run_master(1, 1, 200, 32'h8888);
    join
    while (outstanding != 0) tick();
    rr_mode = 1'b0;
    repeat (10) tick();
    if (outstanding != 0) fail("outstanding requests at end of phase 1b");

    // phase 2: verify scrub results by reading the scrubbed extents back through master 0 (one at a time)
    $display("phase 1 done at cycle %0d, starting readback", cyc);
    scrub_nonzero = 0;
    for (int w = 0; w < 2048 / DWB; w++) begin
      logic [DW-1:0] rd;
      rd_one(0, 0, 32'(4096 + w * DWB), rd);
      if (rd !== '0) scrub_nonzero++;
      checks++;
    end
    $display("tier0 readback done at cycle %0d", cyc);
    for (int w = 0; w < 8192 / DWB; w++) begin
      logic [DW-1:0] rd;
      rd_one(1, 0, 32'(16384 + w * DWB), rd);
      if (rd !== '0) scrub_nonzero++;
      checks++;
    end
    // words just outside the scrubbed extents must NOT have been touched: tier 1 background pattern is non-zero
    begin
      logic [DW-1:0] rd_lo, rd_hi;
      rd_one(1, 0, 32'(16384 - DWB), rd_lo);
      rd_one(1, 0, 32'(16384 + 8192), rd_hi);
      checks += 2;
      if (rd_lo === '0 || rd_hi === '0) fail("scrubber wrote outside its extent");
    end
    if (scrub_nonzero != 0) fail($sformatf("%0d scrubbed words are not zero", scrub_nonzero));
    // the DRAM background pattern is non-zero, so a scrub that missed words would have been caught above.

    $display("tier0: reads %0d writes %0d  read latency min %0d max %0d cycles", total_rd[0], total_wr[0], rd_lat_min[0], rd_lat_max[0]);
    $display("tier1: reads %0d writes %0d  read latency min %0d max %0d cycles  (row hit %0d closed %0d conflict %0d refresh %0d)",
             total_rd[1], total_wr[1], rd_lat_min[1], rd_lat_max[1], u_dram.st_row_hit, u_dram.st_row_closed, u_dram.st_row_conf, u_dram.st_refresh);
    if (!(rd_lat_min[1] > rd_lat_min[0])) fail("DRAM tier is not slower than SRAM tier");
    if (u_dram.st_row_conf == 0) fail("no row conflicts exercised");
    if (u_dram.st_refresh == 0) fail("no refresh exercised");
    if (s0_oor) fail("SRAM tier out-of-range tripwire");
    $display("%0d checks, %0d errors", checks, errors);
    if (errors == 0) $display("TB RESULT PASS"); else $display("TB RESULT FAIL");
    $finish;
  end

  // watchdog
  initial begin
    #50_000_000;
    $display("watchdog: outstanding=%0d expq t0m0=%0d t0m1=%0d t1m0=%0d t1m1=%0d | arb0 tf=%0d arb1 tf=%0d | scrub run=%0b left=%0d pend=%0d tier=%0b | total_rd=%0d/%0d total_wr=%0d/%0d",
      outstanding, expq[0][0].size(), expq[0][1].size(), expq[1][0].size(), expq[1][1].size(), u_arb0.tf_cnt_q, u_arb1.tf_cnt_q,
      u_scrub.run_q, u_scrub.left_q, u_scrub.pend_q, u_scrub.tier_q, total_rd[0], total_rd[1], total_wr[0], total_wr[1]);
    $display("dram q_cnt=%0d  s1 req v=%0b r=%0b  rsp v=%0b r=%0b", u_dram.q_cnt, s1_req_valid, s1_req_ready, s1_rsp_valid, s1_rsp_ready);
    $display("TB RESULT FAIL (timeout)");
    $finish;
  end
endmodule
