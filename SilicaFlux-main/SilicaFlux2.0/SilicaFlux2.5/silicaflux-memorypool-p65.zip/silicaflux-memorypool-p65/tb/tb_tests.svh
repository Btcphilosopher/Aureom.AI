// =============================================================================
// MemoryPool :: tb_tests.svh -- directed verification tests (included into tb_pool)
// =============================================================================

// ---------------------------------------------------------------------------------------------------------
// T01  allocation / deallocation, zero-fill, stale handles, generation
// ---------------------------------------------------------------------------------------------------------
task automatic t01_alloc_free();
  logic [7:0] rc, gen_a, gen_b, gen2;
  int ia, ib, i2;
  bit e;
  rinfo_t ri;
  cur_test = "T01_alloc_free";
  fresh(1'b0);

  // SRAM region (1 KiB) for domain 0
  do_alloc(0, 0, 1024, PREF_SRAM, 1, 1, 0, rc, ia, gen_a);
  chk(rc == RC_OK, $sformatf("alloc SRAM region rc=%0h", rc));
  rinfo(ia, ri);
  chk(ri.state == RS_ACTIVE && ri.tier == 0 && ri.dom == 0 && ri.len_g == 1024 / GRAN && ri.pva_b == 0 && ri.mig == 0,
      $sformatf("region read-out wrong: state=%0d tier=%0d dom=%0d len=%0d pva=%0h", ri.state, ri.tier, ri.dom, ri.len_g, ri.pva_b));
  chk(bm_pop(0) == 1024 / GRAN, "SRAM bitmap occupancy after alloc");
  // the SRAM array powers up with random contents (--x-initial unique): a new region must still read as zero
  sweep_range(0, 0, 1024);

  // DRAM region (2 KiB) -- the DRAM model's background pattern is non-zero, so a missing scrub would show here
  do_alloc(0, 4096, 2048, PREF_DRAM, 1, 1, 0, rc, ib, gen_b);
  chk(rc == RC_OK, "alloc DRAM region");
  rinfo(ib, ri);
  chk(ri.tier == 1 && ri.state == RS_ACTIVE, "DRAM region read-out");
  sweep_range(0, 4096, 2048);

  // write patterns, read back
  fill_range(0, 0, 1024);
  fill_range(0, 4096, 2048);
  sweep_range(0, 0, 1024);
  sweep_range(0, 4096, 2048);

  // free the SRAM region: occupancy returns, region no longer accessible
  do_free(ia, gen_a, 0, 1024, rc);
  chk(rc == RC_OK, "free SRAM region");
  chk(bm_pop(0) == 0, "SRAM bitmap after free");
  rd_chk(0, 0, e);
  chk(e, "freed region is still accessible");

  // stale / bad handles
  cmd_rc(CMD_FREE, ia, gen_a, 0, 0, rc);          chk(rc == RC_STALE,   $sformatf("double free rc=%0h", rc));
  cmd_rc(CMD_FREE, 99, 0, 0, 0, rc);              chk(rc == RC_BAD_ARG, $sformatf("free of index 99 rc=%0h", rc));
  cmd_rc(CMD_FREE, ib, gen_b + 8'd1, 0, 0, rc);   chk(rc == RC_STALE,   $sformatf("free with wrong generation rc=%0h", rc));

  // re-allocate the same range: fresh generation, zeroed, old data gone
  do_alloc(0, 0, 1024, PREF_SRAM, 1, 1, 0, rc, i2, gen2);
  chk(rc == RC_OK, "re-alloc");
  chk(i2 != ia || gen2 != gen_a, "re-allocation reused the same (index, generation) handle");
  sweep_range(0, 0, 1024);
  cmd_rc(CMD_FREE, ia, gen_a, 0, 0, rc);
  chk(rc == RC_STALE, $sformatf("stale handle freed a later allocation (rc=%0h)", rc));
  sweep_range(0, 0, 1024);                           // and it is still there

  // AUTO prefers SRAM
  do_alloc(1, DOMSZ, 512, PREF_AUTO, 1, 1, 0, rc, ia, gen_a);
  chk(rc == RC_OK, "AUTO alloc");
  rinfo(ia, ri);
  chk(ri.tier == 0, "AUTO placed the region in DRAM although SRAM had room");

  // free everything: occupancy zero
  do_free(i2, gen2, 0, 1024, rc);                    chk(rc == RC_OK, "free i2");
  do_free(ib, gen_b, 4096, 2048, rc);                chk(rc == RC_OK, "free ib");
  do_free(ia, gen_a, DOMSZ, 512, rc);                chk(rc == RC_OK, "free ia");
  chk(bm_pop(0) == 0 && bm_pop(1) == 0, "occupancy not zero after freeing everything");
  chk(int'(dut.occ0) == 0 && int'(dut.occ1) == 0, "occupancy counters not zero");
endtask

// ---------------------------------------------------------------------------------------------------------
// T02  address overlap, windows, argument validation
// ---------------------------------------------------------------------------------------------------------
task automatic t02_overlap();
  logic [7:0] rc;
  int i0, i1, ix;
  logic [7:0] g0, g1, gx;
  logic [31:0] v;
  cur_test = "T02_overlap";
  fresh(1'b0);

  do_alloc(0, 0, 1024, PREF_DRAM, 1, 1, 0, rc, i0, g0);
  chk(rc == RC_OK, "base region");
  // every kind of overlap with [0,1024)
  begin
    longint ov_pva [7] = '{512, 768, 0, 0, 0, 256, 768};
    int     ov_len [7] = '{1024, 512, 256, 1024, 2048, 256, 256};
    for (int k = 0; k < 7; k++) begin
      do_alloc(0, ov_pva[k], ov_len[k], PREF_DRAM, 1, 1, 0, rc, ix, gx);
      chk(rc == RC_OVERLAP, $sformatf("overlap case %0d (pva %0h len %0d) rc=%0h", k, ov_pva[k], ov_len[k], rc));
    end
  end
  // adjacent is fine
  do_alloc(0, 1024, 512, PREF_DRAM, 1, 1, 0, rc, i1, g1);
  chk(rc == RC_OK, $sformatf("adjacent region rc=%0h", rc));
  // outside the domain window
  do_alloc(0, DOMSZ, 256, PREF_DRAM, 1, 1, 0, rc, ix, gx);           chk(rc == RC_OUTSIDE_WIN, $sformatf("above window rc=%0h", rc));
  do_alloc(0, DOMSZ - 256, 512, PREF_DRAM, 1, 1, 0, rc, ix, gx);    chk(rc == RC_OUTSIDE_WIN, $sformatf("straddling window end rc=%0h", rc));
  do_alloc(1, 0, 256, PREF_DRAM, 1, 1, 0, rc, ix, gx);              chk(rc == RC_OUTSIDE_WIN, $sformatf("domain 1 in domain 0's window rc=%0h", rc));
  // malformed arguments
  do_alloc(0, 100, 256, PREF_DRAM, 1, 1, 0, rc, ix, gx);            chk(rc == RC_BAD_ARG, "unaligned pva");
  do_alloc(0, 4096, 100, PREF_DRAM, 1, 1, 0, rc, ix, gx);           chk(rc == RC_BAD_ARG, "unaligned length");
  do_alloc(0, 4096, 0, PREF_DRAM, 1, 1, 0, rc, ix, gx);             chk(rc == RC_BAD_ARG, "zero length");
  do_alloc(0, 4096, (MAXG + 1) * GRAN, PREF_DRAM, 1, 1, 0, rc, ix, gx); chk(rc == RC_TOO_LARGE, "longer than MAX_REGION_GRAN");
  do_alloc(ND, 4096, 256, PREF_DRAM, 1, 1, 0, rc, ix, gx);          chk(rc == RC_BAD_ARG, "domain index out of range");
  cmd_rc(CMD_ALLOC, 0, 4096, 256, 32'd3, rc);                       chk(rc == RC_BAD_ARG, "tier preference 3");
  // disabled domain
  dom_set(2, 65535, 1'b0, 1'b0, rc);                                chk(rc == RC_OK, "disable domain 2");
  do_alloc(2, 2 * DOMSZ, 256, PREF_DRAM, 1, 1, 0, rc, ix, gx);      chk(rc == RC_BAD_DOMAIN, $sformatf("alloc in disabled domain rc=%0h", rc));
  dom_set(2, 65535, 1'b0, 1'b1, rc);                                chk(rc == RC_OK, "re-enable domain 2");
  // domain window rules
  cmd_rc(CMD_DOM_SET, 1, 32'h0008_0000, 32'h0018_0000, 32'h1_FFFF, rc);   chk(rc == RC_WIN_OVERLAP, $sformatf("overlapping domain windows rc=%0h", rc));
  cmd_rc(CMD_DOM_SET, 0, 0, DOMSZ, 32'h1_FFFF, rc);                 chk(rc == RC_BUSY, $sformatf("reconfigure a domain with live regions rc=%0h", rc));
  cmd_rc(CMD_DOM_SET, 3, 3 * DOMSZ + 100, 4 * DOMSZ, 32'h1_FFFF, rc); chk(rc == RC_BAD_ARG, "unaligned window");
  cmd_rc(CMD_DOM_SET, 3, 4 * DOMSZ, 3 * DOMSZ, 32'h1_FFFF, rc);     chk(rc == RC_BAD_ARG, "empty window");
  cmd_rc(CMD_DOM_SET, 3, 3 * DOMSZ, (64'd1 << POOL_AW) + GRAN, 32'h1_FFFF, rc); chk(rc == RC_BAD_ARG, "window beyond the managed range");
  cmd_rc(CMD_DOM_SET, ND, 0, DOMSZ, 32'h1_FFFF, rc);                chk(rc == RC_BAD_ARG, "DOM_SET domain out of range");
  cmd_rc(8'h7F, 0, 0, 0, 0, rc);                                    chk(rc == RC_BAD_CMD, "unknown command");
  // failed allocations did not consume slots or space
  rd(R_DSEL, v); wr(R_DSEL, 0); rd(R_DOM_LIVE, v);
  chk(v == 2, $sformatf("domain 0 has %0d live regions, expected 2", v));
  chk(bm_pop(1) == (1024 + 512) / GRAN, "DRAM occupancy after failed allocations");
endtask

// ---------------------------------------------------------------------------------------------------------
// T03  permissions and privilege
// ---------------------------------------------------------------------------------------------------------
task automatic t03_perms();
  logic [7:0] rc, gen, code;
  int idx;
  bit e, er;
  logic [31:0] v;
  logic [DW-1:0] d;
  longint unsigned f0, f1;
  cur_test = "T03_perms";
  fresh(1'b0);

  do_alloc(0, 0, 512, PREF_SRAM, 1, 1, 0, rc, idx, gen);
  chk(rc == RC_OK, "alloc");
  fill_range(0, 0, 512);
  sweep_range(0, 0, 512);

  // read-only
  cmd_rc(CMD_SET_PERM, idx, gen, 32'b01, 0, rc);  chk(rc == RC_OK, "SET_PERM R");
  seq_ctr++; cwr(0, 0, mkdata(0, seq_ctr), {DWB{1'b1}}, e, code);
  chk(e && code == CE_FAULT, $sformatf("write to a read-only region err=%0b code=%0h", e, code));
  sweep_range(0, 0, 512);                              // data unchanged (golden not updated by the refused write)
  // write-only
  cmd_rc(CMD_SET_PERM, idx, gen, 32'b10, 0, rc);  chk(rc == RC_OK, "SET_PERM W");
  crd(0, 0, d, e, code);
  chk(e && code == CE_FAULT, "read of a write-only region");
  seq_ctr++; cwr(0, 256, mkdata(256, seq_ctr), {DWB{1'b1}}, e, code);
  chk(!e, "write to a write-only region");
  // no permission
  cmd_rc(CMD_SET_PERM, idx, gen, 32'b00, 0, rc);  chk(rc == RC_OK, "SET_PERM none");
  crd(0, 0, d, e, code);                           chk(e, "read with no permission");
  seq_ctr++; cwr(0, 0, mkdata(0, seq_ctr), {DWB{1'b1}}, e, code); chk(e, "write with no permission");
  // restore, and a stale generation cannot change permissions
  cmd_rc(CMD_SET_PERM, idx, gen + 8'd1, 32'b11, 0, rc);  chk(rc == RC_STALE, "SET_PERM with a stale generation");
  cmd_rc(CMD_SET_PERM, idx, gen, 32'b11, 0, rc);         chk(rc == RC_OK, "SET_PERM RW");
  sweep_range(0, 0, 512);
  // fault counters by cause
  snap_g();
  chk(snap[G_F_PERM] == 4, $sformatf("F_PERM counter = %0d, expected 4", snap[G_F_PERM]));
  chk(snap[G_VIOL] >= 4, "violation counter");

  // ---- privilege: a non-privileged write has no effect
  reg_wr(R_CTRL, 32'h0, 1'b0, er);                chk(er, "non-privileged write to CTRL was accepted");
  rd(R_CTRL, v);                                  chk(v[1] == 1'b1, "CTRL changed by a non-privileged write");
  reg_wr(R_CMD_ARG0, 32'h1234, 1'b0, er);         chk(er, "non-privileged write to ARG0 accepted");
  reg_wr(R_CMD, CMD_FREE, 1'b0, er);              chk(er, "non-privileged CMD write accepted");
  rd(R_CMD_STATUS, v);                            chk(v[0] == 1'b0, "a non-privileged CMD started something");
  // non-privileged FREE of the region must not happen
  chk(dut.u_table.st_q[idx] == RS_ACTIVE, "region disturbed by non-privileged writes");
  // reads: ID/VERSION/CAP are open, metadata and counters are not
  reg_rd(R_ID, 1'b0, v, er);                      chk(!er && v == ID_MAGIC, "ID read without privilege");
  reg_rd(R_CAP1, 1'b0, v, er);                    chk(!er, "CAP read without privilege");
  reg_rd(R_RD_W0, 1'b0, v, er);                   chk(er && v == 0, "region metadata readable without privilege");
  reg_rd(R_G_BASE, 1'b0, v, er);                  chk(er && v == 0, "counters readable without privilege");
  reg_rd(R_FAULT_ADDR, 1'b0, v, er);              chk(er, "fault capture readable without privilege");
  reg_rd(12'hF00, 1'b1, v, er);                   chk(er, "read of an undefined register did not error");
  snap_g();
  chk(snap[G_PRIV_VIOL] == 3, $sformatf("privilege-violation counter = %0d, expected 3", snap[G_PRIV_VIOL]));
  // last fault capture shows the (privileged) view of the latest isolation fault
  rd(R_FAULT_INFO, v);
  chk(v[3:0] == FC_PERM, $sformatf("last fault cause %0d, expected PERM", v[3:0]));
endtask

// ---------------------------------------------------------------------------------------------------------
// T04  migration correctness (both tiers, both modes)
// ---------------------------------------------------------------------------------------------------------
task automatic t04_migrate();
  logic [7:0] rc, gen;
  logic [31:0] st, v;
  int idx;
  rinfo_t r0, r1;
  int len;
  longint unsigned b0, b1, v0, v1, ok0, ok1, t0a, t0b, t1a, t1b;
  for (int mode = 0; mode < 2; mode++) begin
    cur_test = $sformatf("T04_migrate_%s", mode ? "precopy" : "stop_and_copy");
    fresh(1'b0);
    wr(R_CTRL, mode ? 32'b0110 : 32'b0100);                       // verify on, pre-copy per mode, policy off
    len = 3072;
    do_alloc(0, 0, len, PREF_DRAM, 1, 1, 0, rc, idx, gen);
    chk(rc == RC_OK, "alloc");
    fill_range(0, 0, len);
    rinfo(idx, r0);
    snap_g(); b0 = snap[G_MIG_BYTES]; v0 = snap[G_MIG_VBYTES]; ok0 = snap[G_MIG_OK]; t0a = snap[G_ACC_T0]; t1a = snap[G_ACC_T1];

    // ---- promote DRAM -> SRAM
    migrate(idx, gen, 0, rc, st);
    chk(rc == RC_OK, $sformatf("MIGRATE command rc=%0h", rc));
    chk(st[2] && st[15:8] == MR_OK, $sformatf("promotion result %0h", st[15:8]));
    rinfo(idx, r1);
    chk(r1.tier == 0 && r1.mig == 0 && r1.dirty == 0 && r1.state == RS_ACTIVE && r1.pva_b == 0 && r1.len_g == len / GRAN,
        "mapping after promotion");
    chk(bm_pop(1) == 0 && bm_pop(0) == len / GRAN, "extents after promotion (old DRAM extent released, SRAM reserved)");
    chk(r1.gen == r0.gen, "generation changed by a migration");
    sweep_range(0, 0, len);
    snap_g();
    chk(snap[G_MIG_BYTES] - b0 == len, $sformatf("migration DMA bytes %0d expected %0d", snap[G_MIG_BYTES] - b0, len));
    chk(snap[G_MIG_VBYTES] - v0 == len, $sformatf("verify bytes %0d expected %0d", snap[G_MIG_VBYTES] - v0, len));
    chk(snap[G_MIG_OK] - ok0 == 1, "migration counter");
    chk(snap[G_ACC_T0] - t0a == len / DWB && snap[G_ACC_T1] == t1a, "post-migration reads were not all served by tier 0");
    rd(R_MIG_BYTES, v);   chk(v == len, "R_MIG_BYTES");

    // ---- write through the new mapping, then demote SRAM -> DRAM
    fill_range(0, 0, 1024);
    b1 = snap[G_MIG_BYTES];
    migrate(idx, gen, 1, rc, st);
    chk(rc == RC_OK && st[2], "demotion");
    rinfo(idx, r1);
    chk(r1.tier == 1 && r1.mig == 0, "mapping after demotion");
    chk(bm_pop(0) == 0 && bm_pop(1) == len / GRAN, "extents after demotion");
    sweep_range(0, 0, len);
    snap_g();
    chk(snap[G_MIG_BYTES] - b1 == len, "demotion DMA bytes");

    // ---- refused migrations
    cmd_rc(CMD_MIGRATE, idx, gen, 1, 0, rc);              chk(rc == RC_SAME_TIER, $sformatf("migrate to the same tier rc=%0h", rc));
    cmd_rc(CMD_MIGRATE, idx, gen + 8'd1, 0, 0, rc);       chk(rc == RC_STALE, "migrate with a stale handle");
    cmd_rc(CMD_PIN, idx, gen, 1, 0, rc);                  chk(rc == RC_OK, "pin");
    cmd_rc(CMD_MIGRATE, idx, gen, 0, 0, rc);              chk(rc == RC_PINNED, "migrate a pinned region");
    cmd_rc(CMD_PIN, idx, gen, 0, 0, rc);                  chk(rc == RC_OK, "unpin");

    // ---- largest region
    do_alloc(1, DOMSZ, MAXG * GRAN, PREF_DRAM, 1, 1, 0, rc, idx, gen);
    chk(rc == RC_OK, "alloc max-size region");
    fill_range(1, DOMSZ, MAXG * GRAN);
    migrate(idx, gen, 0, rc, st);
    chk(rc == RC_OK && st[2], "max-size promotion");
    sweep_range(1, DOMSZ, MAXG * GRAN);
    rd(R_MIG_CYCLES, v);
    $display("  %s: %0d-byte promotion took %0d cycles", cur_test, MAXG * GRAN, v);
  end
endtask


// ---------------------------------------------------------------------------------------------------------
// T05  dirty-data handling: writes (and reads) racing with a migration, in both modes
// ---------------------------------------------------------------------------------------------------------
bit stop_w, stop_r;
task automatic writer_thread(input int p, input longint base, input int words, input int gap);
  bit e;
  int w;
  while (!stop_w) begin
    w = $urandom_range(0, words - 1);
    wr_full(p, base + longint'(w) * DWB, e);
    chk(!e, "writer: write refused during migration");
    if (gap > 0) repeat ($urandom_range(0, gap)) tick();
  end
endtask
task automatic reader_thread(input int p, input longint base, input int words);
  bit e;
  while (!stop_r) begin
    rd_chk(p, base + longint'($urandom_range(0, words - 1)) * DWB, e);
    chk(!e, "reader: read refused during migration");
  end
endtask
task automatic start_migration_nowait(input int idx, input logic [7:0] gen, input int dst);
  logic [7:0] rc;
  cmd_rc(CMD_MIGRATE, idx, gen, dst, 0, rc);
  chk(rc == RC_OK, $sformatf("start migration rc=%0h", rc));
endtask

// T05c  freeze race: many short migrations of a 512 B region while two ports write it continuously (different gaps in every
// iteration, so the phase between the writes and the engine's freeze decision keeps changing) and two more ports keep the DRAM
// tier busy, and the DRAM stops accepting requests for a few tens of cycles from the freeze decision on (so a write in the dispatch register sits
// in the dispatch register, in flight but not yet ordered at the tier, after the freeze).  A write that
// was dispatched but not yet ordered at the tier when the freeze began must never be lost: the engine has to wait for in-flight
// accesses before it takes the final dirty snapshot (kills mutants such as M12).  Data is swept against the golden model after
// every migration and the commit-time monitors (destination == source, nothing dirty, nothing in flight) are active throughout.
task automatic t05c_freeze_race();
  localparam logic [3:0] ME_FREEZE = 4'd3;    // engine state FREEZE (one cycle; the next state, DRAIN, is where the dirty snapshot is taken)
  logic [7:0] rc, gen;
  logic [31:0] st;
  int idx;
  longint unsigned fz0, fz1;
  cur_test = "T05c_freeze_race";
  fresh(1'b0);
  wr(R_CTRL, 32'b0110);                                                         // pre-copy, policy off
  logic_bind_port1_to_dom0();
  for (int d2 = 2; d2 < ND && d2 < 4; d2++) begin
    do_alloc(d2, longint'(d2) * DOMSZ, 1024, PREF_DRAM, 1, 1, 0, rc, idx, gen);
    fill_range(d2, longint'(d2) * DOMSZ, 1024);
  end
  snap_g(); fz0 = snap[G_MIG_FRZ_CYC];
  for (int k = 0; k < 24; k++) begin
    longint base;
    base = longint'(k) * 1024;
    do_alloc(0, base, 512, PREF_DRAM, 1, 1, 0, rc, idx, gen);
    chk(rc == RC_OK, "T05c alloc");
    fill_range(0, base, 512);
    stop_w = 1'b0;
    cmd_rc(CMD_MIGRATE, idx, gen, 0, 0, rc);                                    // promote to SRAM
    chk(rc == RC_OK, $sformatf("T05c start migration rc=%0h", rc));
    fork
      writer_thread(0, base, (512 / DWB) / 2, k % 4);                           // first half of the region
      writer_thread(1, base + 256, (512 / DWB) / 2, (k / 4) % 3);               // second half (port 1 is bound to domain 0)
      if (ND > 2) rnd_port_traffic(2, 2 * DOMSZ, 1024 / DWB, 400);
      if (ND > 3) rnd_port_traffic(3, 3 * DOMSZ, 1024 / DWB, 400);
      begin                                                                     // a busy DRAM: it stops accepting requests from the cycle after the freeze decision
        int guard;
        guard = 0;
        while (dut.u_mig.st_q != ME_FREEZE && !stop_w && guard < 400000) begin @(negedge clk); guard++; end
        tick();
        if (!stop_w) begin
          inj_stall_en = 1'b1;
          repeat (24 + 8 * (k % 3)) tick();
          inj_stall_en = 1'b0;
        end
      end
      begin wait_mig_done(2_000_000, st); stop_w = 1'b1; end
    join
    inj_stall_en = 1'b0;
    chk(st[2] && st[15:8] == MR_OK, $sformatf("T05c iteration %0d: migration result %0h", k, st[15:8]));
    sweep_range(0, base, 512);                                                  // every word, including the ones written during the copy
  end
  snap_g(); fz1 = snap[G_MIG_FRZ_CYC];
  chk(fz1 > fz0, "T05c: no region was ever frozen (scenario insensitive)");
  $display("  T05c: 24 migrations under two continuous writers and a busy DRAM tier, %0d cycles frozen in total (data verified by the sweeps above)", fz1 - fz0);
endtask

// T05d  one stalled write across the freeze.  The DRAM stops accepting requests after the migration engine has handed out its last chunk
// (the engine needs the source tier no more), one write to the region is issued -- it sits in the dispatch register: counted as in
// flight, NOT yet ordered at the tier -- and the stall is released only after the engine has frozen the region.  The final pass has
// nothing else to copy, so the only thing that can save the write is the engine waiting for in-flight accesses before it takes the
// final dirty snapshot (kills mutant M12; the E_EVAL re-check alone rescues it only when the final pass is long enough).
// The delay between "last chunk handed out" and the stall is swept so that the stall starts before / around / after the freeze.
task automatic t05d_stalled_write();
  localparam logic [3:0] ME_RUN = 4'd1;
  logic [7:0] rc, gen;
  logic [31:0] st;
  int idx;
  bit e, stall_on;
  longint unsigned rc0, rc1;
  cur_test = "T05d_stalled_write";
  fresh(1'b0);
  wr(R_CTRL, 32'b0110);                                                         // pre-copy, policy off
  snap_g(); rc0 = snap[G_MIG_RECOPY];
  for (int k = 0; k < 14; k++) begin
    longint base;
    base = longint'(k) * 1024;
    do_alloc(0, base, 512, PREF_DRAM, 1, 1, 0, rc, idx, gen);
    chk(rc == RC_OK, "T05d alloc");
    fill_range(0, base, 512);
    stall_on = 1'b0;
    cmd_rc(CMD_MIGRATE, idx, gen, 0, 0, rc);                                    // promote to SRAM
    chk(rc == RC_OK, $sformatf("T05d start migration rc=%0h", rc));
    fork
      begin                                                                     // the DRAM stall
        int guard;
        guard = 0;
        while (!(dut.u_mig.st_q == ME_RUN && dut.u_mig.todo_q == '0) && guard < 400000) begin @(negedge clk); guard++; end
        repeat (60 + 20 * k) tick();
        stall_on = 1'b1;
        inj_stall_en = 1'b1;
        repeat (1200) tick();
        inj_stall_en = 1'b0;
      end
      begin                                                                     // the write that gets stuck
        int guard;
        guard = 0;
        while (!stall_on && guard < 400000) begin @(negedge clk); guard++; end
        repeat (2) tick();
        wr_full(0, base + 4 * DWB, e);
        chk(!e, $sformatf("T05d k=%0d: stalled write refused", k));
      end
      wait_mig_done(2_000_000, st);
    join
    inj_stall_en = 1'b0;
    chk(st[2] && st[15:8] == MR_OK, $sformatf("T05d iteration %0d: migration result %0h", k, st[15:8]));
    sweep_range(0, base, 512);                                                  // includes the stalled write
  end
  snap_g(); rc1 = snap[G_MIG_RECOPY];
  $display("  T05d: 14 migrations with a write stalled in the dispatch register across the freeze; %0d chunk re-copies (data verified by the sweeps above)", rc1 - rc0);
endtask

task automatic t05_dirty();
  logic [7:0] rc, gen;
  logic [31:0] st, v;
  int idx;
  rinfo_t r;
  longint unsigned re0, re1, fz0, fz1, fb0, fb1, mb0, mb1;
  int len;
  for (int variant = 0; variant < 3; variant++) begin
    // variant 0: pre-copy, light writes   1: pre-copy, back-to-back writes (forces rounds + freeze)   2: stop-and-copy
    cur_test = $sformatf("T05_dirty_v%0d", variant);
    fresh(1'b0);
    len = 4096;
    wr(R_CTRL, (variant == 2) ? 32'b0100 : 32'b0110);
    logic_bind_port1_to_dom0();
    do_alloc(0, 0, len, PREF_DRAM, 1, 1, 0, rc, idx, gen);
    chk(rc == RC_OK, "alloc");
    fill_range(0, 0, len);
    snap_g(); re0 = snap[G_MIG_RECOPY]; fz0 = snap[G_MIG_FRZ_CYC]; fb0 = snap[G_FRZBLK]; mb0 = snap[G_MIG_BYTES];
    stop_w = 1'b0; stop_r = 1'b0;
    start_migration_nowait(idx, gen, 0);
    fork
      writer_thread(0, 0, (len / DWB) / 2, (variant == 1) ? 0 : 6);     // writes the first half
      reader_thread(1, len / 2, (len / DWB) / 2);                       // reads the second half (never written)
      begin
        wait_mig_done(4_000_000, st);
        stop_w = 1'b1; stop_r = 1'b1;
      end
    join
    chk(st[2] && st[15:8] == MR_OK, $sformatf("migration under load result %0h", st[15:8]));
    rinfo(idx, r);
    chk(r.tier == 0 && r.mig == 0 && r.state == RS_ACTIVE, "region state after migration under load");   // (dirty may be set again: the writer kept running after the commit)
    sweep_range(0, 0, len);              // every word, including the ones written while the copy was running
    snap_g();
    re1 = snap[G_MIG_RECOPY]; fz1 = snap[G_MIG_FRZ_CYC]; fb1 = snap[G_FRZBLK]; mb1 = snap[G_MIG_BYTES];
    $display("  %s: copied %0d B for a %0d B region (%0d chunk re-copies), frozen %0d cycles, %0d freeze stalls, %0d writes by port 0",
             cur_test, mb1 - mb0, len, re1 - re0, fz1 - fz0, fb1 - fb0, ok_acc[0]);
    if (variant == 2) begin
      chk(re1 - re0 == 0, "stop-and-copy re-copied chunks although the region was frozen from the start");
      chk(fz1 - fz0 > 0 && fb1 - fb0 > 0, "stop-and-copy froze nothing / stalled nobody");
    end else begin
      chk(re1 - re0 > 0, "pre-copy under writes never re-copied a dirty chunk (dirty tracking not exercised)");
      chk(mb1 - mb0 > len, "pre-copy copied no more than the region size although it was written during the copy");
    end
    if (variant == 1) chk(fz1 - fz0 > 0, "back-to-back writes did not force the freeze phase");
  end
  t05c_freeze_race();
  t05d_stalled_write();
endtask
task automatic logic_bind_port1_to_dom0();
  logic [7:0] rc;
  cmd_rc(CMD_BIND, 1, 0, 0, 0, rc);
  chk(rc == RC_OK, $sformatf("BIND port 1 -> domain 0 rc=%0h", rc));
endtask

// ---------------------------------------------------------------------------------------------------------
// T06  reset: mid-migration and with an access in flight
// ---------------------------------------------------------------------------------------------------------
task automatic t06_reset();
  logic [7:0] rc, gen_s, gen_d;
  logic [31:0] v;
  int is, id;
  int commits_before;
  bit e;
  logic [DW-1:0] d;
  logic [7:0] code;
  rinfo_t r;
  cur_test = "T06_reset";
  fresh(1'b0);
  do_alloc(0, 0, 2048, PREF_SRAM, 1, 1, 0, rc, is, gen_s);
  do_alloc(0, 8192, 4096, PREF_DRAM, 1, 1, 0, rc, id, gen_d);
  fill_range(0, 0, 2048);
  fill_range(0, 8192, 4096);
  start_migration_nowait(id, gen_d, 0);
  repeat (3000) tick();
  chk(mig_busy_o, "migration was not running at the reset point");
  commits_before = mig_commits_seen;
  // ---- reset in the middle of the copy
  rst_n = 1'b0;
  repeat (5) tick();
  chk(!mig_busy_o, "migration engine busy during reset");
  rst_n = 1'b1;
  repeat (3) tick();
  chk(mig_commits_seen == commits_before, "a migration committed across a reset");
  chk(!mig_busy_o, "migration engine busy after reset");
  chk(dram.q_cnt == 0, "DRAM model still has requests in flight after reset");
  chk(c_rsp_valid == '0, "a response is pending after reset");
  chk(bm_pop(0) == 0 && bm_pop(1) == 0, "allocator not empty after reset");
  for (int k = 0; k < NR; k++) chk(dut.u_table.st_q[k] == RS_FREE && dut.u_table.mig_q[k] == MG_NONE, $sformatf("region %0d not free after reset", k));
  // configuration is also cleared: nothing is accessible until the privileged plane reconfigures
  rd_chk(0, 0, e);
  chk(e, "access succeeded after reset although nothing is configured");
  gm.delete();
  setup_domains(65535, 1'b0);
  // the old data must be gone for any new owner (SRAM not cleared by reset; DRAM holds the old tenant data)
  do_alloc(0, 0, 2048, PREF_SRAM, 1, 1, 0, rc, is, gen_s);
  do_alloc(0, 8192, 4096, PREF_DRAM, 1, 1, 0, rc, id, gen_d);
  chk(rc == RC_OK, "alloc after reset");
  sweep_range(0, 0, 2048);
  sweep_range(0, 8192, 4096);
  // ---- reset with an access in flight: the request was accepted, the response never arrives
  cv[0] = 1'b1; cw[0] = 1'b0; ca[0] = 32'd8192; cd[0] = '0; cs[0] = '0;
  do @(negedge clk); while (!c_req_ready[0]);
  tick(); cv[0] = 1'b0;
  rst_n = 1'b0; repeat (4) tick(); rst_n = 1'b1; repeat (3) tick();
  repeat (200) begin tick(); chk(c_rsp_valid == '0, "a response appeared for a request that was dropped by reset"); end
  gm.delete();
  setup_domains(65535, 1'b0);
  do_alloc(0, 0, 1024, PREF_AUTO, 1, 1, 0, rc, is, gen_s);
  chk(rc == RC_OK, "alloc after the second reset");
  fill_range(0, 0, 1024); sweep_range(0, 0, 1024);
  // a migration can be run after a reset
  migrate(is, gen_s, 1 - int'(dut.u_table.tier_q[is]), rc, v);
  chk(rc == RC_OK && v[2], "migration after reset");
  sweep_range(0, 0, 1024);
endtask

// ---------------------------------------------------------------------------------------------------------
// T07  concurrent accesses from every port (+ host DMA), migration and allocation churn, counter cross-check
// ---------------------------------------------------------------------------------------------------------
task automatic rnd_port_traffic(input int p, input longint base, input int words, input int n);
  bit e;
  int w;
  for (int i = 0; i < n; i++) begin
    w = $urandom_range(0, words - 1);
    if ($urandom_range(0, 99) < 45) begin wr_full(p, base + longint'(w) * DWB, e); chk(!e, $sformatf("port %0d write refused", p)); end
    else begin rd_chk(p, base + longint'(w) * DWB, e); chk(!e, $sformatf("port %0d read refused", p)); end
    if ($urandom_range(0, 9) == 0) repeat ($urandom_range(1, 8)) tick();
  end
endtask
task automatic host_ro_reads(input longint base, input int words, input int n);
  bit e;
  for (int i = 0; i < n; i++) begin
    rd_chk(ND, base + longint'($urandom_range(0, words - 1)) * DWB, e);
    chk(!e, "host DMA read refused");
  end
endtask

task automatic t07_concurrent();
  logic [7:0] rc;
  logic [31:0] st;
  int i [ND]; logic [7:0] g [ND]; int ro_i; logic [7:0] ro_g, gc;
  int churn_i, tmp;
  longint unsigned s_acc, s_rd, s_wr, s_lat, s_lc, s_rej, s_t0, s_t1;
  longint unsigned d_acc;
  longint unsigned dsum;
  real m_dut, m_tb;
  cur_test = "T07_concurrent";
  fresh(1'b0);
  wr(R_CTRL, 32'b0110);
  // one working region per domain: dom0 SRAM, dom1 DRAM (will be promoted under load), dom2 AUTO, dom3 DRAM (will be demoted... stays)
  do_alloc(0, 0, 2048, PREF_SRAM, 1, 1, 0, rc, i[0], g[0]);
  do_alloc(1, DOMSZ, 2048, PREF_DRAM, 1, 1, 0, rc, i[1], g[1]);
  if (ND > 2) do_alloc(2, 2 * DOMSZ, 2048, PREF_AUTO, 1, 1, 0, rc, i[2], g[2]);
  if (ND > 3) do_alloc(3, 3 * DOMSZ, 2048, PREF_DRAM, 1, 1, 0, rc, i[3], g[3]);
  // a read-only shared region of domain 0 that the host-DMA port reads (filled first, then made read-only)
  do_alloc(0, 4096, 1024, PREF_DRAM, 1, 1, 0, rc, ro_i, ro_g);
  fill_range(0, 4096, 1024);
  cmd_rc(CMD_SET_PERM, ro_i, ro_g, 32'b01, 0, rc);
  hd_dom = 0; hd_xlat_ok = 1'b1;
  snap_g();
  s_acc = snap[G_ACC]; s_rd = snap[G_BYTES_RD]; s_wr = snap[G_BYTES_WR]; s_lat = snap[G_LAT_SUM]; s_lc = snap[G_LAT_CNT]; s_t0 = snap[G_ACC_T0]; s_t1 = snap[G_ACC_T1];
  for (int p = 0; p < NPT; p++) begin ok_acc[p] = 0; flt_acc[p] = 0; end
  ok_bytes_rd = 0; ok_bytes_wr = 0; lat_sum_tb = 0; lat_cnt_tb = 0; lat_max_tb = 0;
  // (counters read above include the fill traffic: they are differenced below)

  fork
    rnd_port_traffic(0, 0, 2048 / DWB, 400);
    rnd_port_traffic(1, DOMSZ, 2048 / DWB, 400);
    if (ND > 2) rnd_port_traffic(2, 2 * DOMSZ, 2048 / DWB, 400);
    if (ND > 3) rnd_port_traffic(3, 3 * DOMSZ, 2048 / DWB, 400);
    host_ro_reads(4096, 1024 / DWB, 150);
    begin   // management: promote domain 1's region while everybody is running, then allocation churn in domain 2
      repeat (200) tick();
      migrate(i[1], g[1], 0, rc, st);
      chk(rc == RC_OK && st[2], "promotion under concurrent load");
      for (int k = 0; k < 4; k++) begin
        if (ND > 2) begin
          do_alloc(2, 2 * DOMSZ + 65536 + k * 4096, 1024, (k % 2) ? PREF_DRAM : PREF_AUTO, 1, 1, 0, rc, churn_i, gc);
          chk(rc == RC_OK, "churn alloc");
          do_free(churn_i, gc, 2 * DOMSZ + 65536 + k * 4096, 1024, rc);
          chk(rc == RC_OK, "churn free");
        end
      end
    end
  join
  // everything the clients wrote must still be there, wherever it lives now
  sweep_range(0, 0, 2048); sweep_range(1, DOMSZ, 2048);
  if (ND > 2) sweep_range(2, 2 * DOMSZ, 2048);
  if (ND > 3) sweep_range(3, 3 * DOMSZ, 2048);

  // ---- DUT telemetry vs. what the testbench observed (differences, since the setup traffic is in the counters)
  snap_g();
  begin
    longint unsigned tb_acc, tb_rdb, tb_wrb;
    tb_acc = 0; for (int p = 0; p < NPT; p++) tb_acc += ok_acc[p];
    tb_rdb = ok_bytes_rd; tb_wrb = ok_bytes_wr;
    chk(snap[G_ACC] - s_acc == tb_acc, $sformatf("G_ACC delta %0d != TB-completed accesses %0d", snap[G_ACC] - s_acc, tb_acc));
    chk(snap[G_BYTES_RD] - s_rd == tb_rdb, $sformatf("G_BYTES_RD delta %0d != %0d", snap[G_BYTES_RD] - s_rd, tb_rdb));
    chk(snap[G_BYTES_WR] - s_wr == tb_wrb, $sformatf("G_BYTES_WR delta %0d != %0d", snap[G_BYTES_WR] - s_wr, tb_wrb));
    chk(snap[G_ACC_T0] + snap[G_ACC_T1] == snap[G_ACC], "tier counters do not add up to the access counter");
    chk(snap[G_LAT_CNT] - s_lc == tb_acc, "latency sample count != accesses");
    chk(snap[G_REJECT] == 0, "unexpected access faults");
    m_dut = real'(snap[G_LAT_SUM] - s_lat) / real'(snap[G_LAT_CNT] - s_lc);
    m_tb  = real'(lat_sum_tb) / real'(lat_cnt_tb);
    chk(m_tb - m_dut >= 0.0 && m_tb - m_dut <= 4.0, $sformatf("mean service latency DUT %f vs TB %f cycles", m_dut, m_tb));
    $display("  T07: %0d accesses, mean service latency %f cycles (TB-observed %f), tier0 %0d / tier1 %0d accesses, %0d queue-full, %0d head-blocked cycles",
             tb_acc, m_dut, m_tb, snap[G_ACC_T0] - s_t0, snap[G_ACC_T1] - s_t1, snap[G_QFULL], snap[G_HEADBLK]);
  end
  // per-domain counters: ports 0..3 -> domains 0..3, the host port acted as domain 0
  for (int d = 0; d < ND; d++) begin
    cnt_d(d, D_ACC, dsum);
    d_acc = ok_acc[d] + ((d == 0) ? ok_acc[ND] : 0);
    // domain counters include the fill traffic of the setup (domain 0 filled the read-only region): compare only >=
    chk(dsum >= d_acc, $sformatf("domain %0d counter %0d < TB %0d", d, dsum, d_acc));
  end
endtask

// ---------------------------------------------------------------------------------------------------------
// T08  resource exhaustion, quota, fragmentation
// ---------------------------------------------------------------------------------------------------------
task automatic t08_exhaust();
  logic [7:0] rc, gen;
  int idx;
  int slots [64]; logic [7:0] gens [64]; longint pvas [64];
  int n, nfull;
  rinfo_t r;
  logic [31:0] v;
  cur_test = "T08_exhaust";
  fresh(1'b0);

  // ---- region-table exhaustion (single-granule DRAM regions)
  n = 0;
  for (int k = 0; k < NR; k++) begin
    pvas[k] = (k % 2) * DOMSZ + (k / 2) * GRAN;
    do_alloc(k % 2, pvas[k], GRAN, PREF_DRAM, 1, 1, 0, rc, slots[k], gens[k]);
    if (rc == RC_OK) n++;
  end
  chk(n == NR, $sformatf("could not fill the region table: %0d of %0d", n, NR));
  do_alloc(0, 100 * GRAN, GRAN, PREF_DRAM, 1, 1, 0, rc, idx, gen);
  chk(rc == RC_NO_SLOT, $sformatf("allocation with a full region table rc=%0h", rc));
  do_free(slots[5], gens[5], pvas[5], GRAN, rc);        chk(rc == RC_OK, "free one");
  do_alloc(0, 100 * GRAN, GRAN, PREF_DRAM, 1, 1, 0, rc, idx, gen);
  chk(rc == RC_OK, "allocation works again after a free");
  for (int k = 0; k < NR; k++) if (k != 5) begin do_free(slots[k], gens[k], pvas[k], GRAN, rc); chk(rc == RC_OK, "free"); end
  do_free(idx, gen, 100 * GRAN, GRAN, rc);
  chk(bm_pop(0) == 0 && bm_pop(1) == 0, "occupancy after emptying the table");

  // ---- SRAM capacity: PREF_SRAM fails, AUTO falls back to DRAM
  n = 0;
  for (int k = 0; k < 8; k++) begin
    pvas[k] = longint'(k % 4) * DOMSZ + (k / 4) * MAXG * GRAN;
    do_alloc(k % 4 < ND ? k % 4 : 0, pvas[k], MAXG * GRAN, PREF_SRAM, 1, 1, 0, rc, slots[k], gens[k]);
    if (rc == RC_OK) n++; else chk(rc == RC_NO_SPACE, $sformatf("SRAM-full rc=%0h", rc));
  end
  nfull = G0 / MAXG;
  chk(n == nfull, $sformatf("SRAM fits %0d max-size regions, allocated %0d", nfull, n));
  do_alloc(0, 20 * MAXG * GRAN, GRAN, PREF_SRAM, 1, 1, 0, rc, idx, gen);
  chk(rc == RC_NO_SPACE, "one more granule into a full SRAM");
  do_alloc(0, 20 * MAXG * GRAN, 4 * GRAN, PREF_AUTO, 1, 1, 0, rc, idx, gen);
  chk(rc == RC_OK, "AUTO with full SRAM");
  rinfo(idx, r); chk(r.tier == 1, "AUTO did not fall back to DRAM");
  // ---- DRAM capacity
  n = 0;
  for (int k = 0; k < 40; k++) begin
    do_alloc(1, DOMSZ + longint'(32 + k) * MAXG * GRAN, MAXG * GRAN, PREF_DRAM, 1, 1, 0, rc, slots[k % 64], gens[k % 64]);
    if (rc == RC_OK) n++;
    else begin chk(rc == RC_NO_SPACE || rc == RC_NO_SLOT, $sformatf("DRAM-full rc=%0h", rc)); break; end
  end
  $display("  T08: %0d max-size regions fit in DRAM; SRAM holds %0d", n, nfull);
  chk(n >= (G1 / MAXG) - 4 && n <= G1 / MAXG, "DRAM capacity not reached / exceeded");
  do_alloc(1, DOMSZ + 63 * MAXG * GRAN, MAXG * GRAN, PREF_AUTO, 1, 1, 0, rc, idx, gen);
  chk(rc == RC_NO_SPACE || rc == RC_NO_SLOT, $sformatf("AUTO with both tiers full rc=%0h", rc));

  // ---- fresh table: quota
  fresh(1'b0);
  dom_set(0, 8, 1'b0, 1'b1, rc);                          chk(rc == RC_OK, "set quota 8");
  do_alloc(0, 0, 16 * GRAN, PREF_SRAM, 1, 1, 0, rc, idx, gen);   chk(rc == RC_QUOTA, $sformatf("SRAM-only above quota rc=%0h", rc));
  do_alloc(0, 0, 16 * GRAN, PREF_AUTO, 1, 1, 0, rc, idx, gen);   chk(rc == RC_OK, "AUTO above quota");
  rinfo(idx, r);                                          chk(r.tier == 1, "AUTO above the SRAM quota did not go to DRAM");
  begin
    int q_idx; logic [7:0] q_gen;
    do_alloc(0, 16 * GRAN, 8 * GRAN, PREF_SRAM, 1, 1, 0, rc, q_idx, q_gen);   chk(rc == RC_OK, "SRAM within quota");
    do_alloc(0, 32 * GRAN, GRAN, PREF_SRAM, 1, 1, 0, rc, slots[0], gens[0]);  chk(rc == RC_QUOTA, "quota exhausted");
    rd(R_DSEL, v); wr(R_DSEL, 0); rd(R_DOM_USE, v);                             chk(v == 8, $sformatf("quota usage %0d", v));
    // promotion into SRAM is refused by the quota, allowed after the SRAM region is freed
    migrate(idx, gen, 0, rc, v);                                                chk(rc == RC_QUOTA, $sformatf("promotion above the quota rc=%0h", rc));
    do_free(q_idx, q_gen, 16 * GRAN, 8 * GRAN, rc);                             chk(rc == RC_OK, "free quota region");
    migrate(idx, gen, 0, rc, v);                                                chk(rc == RC_QUOTA, "16-granule promotion above an 8-granule quota");
  end

  // ---- migration into full SRAM is refused
  fresh(1'b0);
  for (int k = 0; k < G0 / MAXG; k++) begin
    do_alloc(1, DOMSZ + longint'(k) * MAXG * GRAN, MAXG * GRAN, PREF_SRAM, 1, 1, 0, rc, slots[k], gens[k]);
    chk(rc == RC_OK, "fill SRAM");
  end
  do_alloc(0, 0, 2 * GRAN, PREF_DRAM, 1, 1, 0, rc, idx, gen);
  migrate(idx, gen, 0, rc, v);
  chk(rc == RC_NO_SPACE, $sformatf("promotion into a full SRAM rc=%0h", rc));
  rinfo(idx, r); chk(r.mig == 0 && r.tier == 1, "refused migration changed the region");
  chk(bm_pop(0) == G0, "refused migration leaked an SRAM reservation");

  // ---- fragmentation: 16 regions of 16 granules fill the SRAM; free every other one -> 8 holes of 16 granules
  fresh(1'b0);
  n = 0;
  for (int k = 0; k < 16; k++) begin
    pvas[k] = longint'(k % 4) * DOMSZ + longint'(k / 4) * 16 * GRAN;
    do_alloc(k % 4 < ND ? k % 4 : 0, pvas[k], 16 * GRAN, PREF_SRAM, 1, 1, 0, rc, slots[k], gens[k]);
    if (rc == RC_OK) n++;
  end
  chk(n == G0 / 16, $sformatf("SRAM filled with %0d regions of 16 granules", n));
  for (int k = 0; k < 16; k += 2) begin do_free(slots[k], gens[k], pvas[k], 16 * GRAN, rc); chk(rc == RC_OK, "free alternate"); end
  chk(G0 - int'(dut.occ0) == 8 * 16, "free granules after freeing alternate regions");
  do_alloc(0, 40 * GRAN, 32 * GRAN, PREF_SRAM, 1, 1, 0, rc, idx, gen);
  chk(rc == RC_NO_SPACE, $sformatf("32-granule request in a fragmented SRAM (128 free granules, largest hole 16) rc=%0h", rc));
  do_alloc(0, 40 * GRAN, 16 * GRAN, PREF_SRAM, 1, 1, 0, rc, idx, gen);
  chk(rc == RC_OK, "16-granule request fits a hole");
  $display("  T08: fragmentation verified: 32 granules refused with %0d granules free", G0 - int'(dut.occ0) + 16);
endtask


// ---------------------------------------------------------------------------------------------------------
// T09  backpressure: clients that do not accept responses, queues that fill, a saturated external port
// ---------------------------------------------------------------------------------------------------------
task automatic t09_backpressure();
  logic [7:0] rc, g0, g1;
  int i0, i1;
  int accepted, stuck;
  bit acc, e;
  logic [DW-1:0] d;
  logic [7:0] code;
  longint unsigned qf0, qf1, em0, em1;
  longint base;
  cur_test = "T09_backpressure";
  fresh(1'b0);
  do_alloc(0, 0, 1024, PREF_SRAM, 1, 1, 0, rc, i0, g0);
  do_alloc(1, DOMSZ, 1024, PREF_DRAM, 1, 1, 0, rc, i1, g1);
  fill_range(0, 0, 1024);
  fill_range(1, DOMSZ, 1024);
  for (int tier = 0; tier < 2; tier++) begin
    int p = tier;
    base = (tier == 0) ? 0 : DOMSZ;
    snap_g(); qf0 = snap[G_QFULL];
    crr[p] = 1'b0;                                           // the client stops accepting responses
    accepted = 0; stuck = 0;
    for (int k = 0; k < 24 && stuck < 40; k++) begin
      cv[p] = 1'b1; cw[p] = 1'b0; ca[p] = 32'(base + k * DWB); cs[p] = '0; cd[p] = '0;
      acc = 1'b0;
      while (!acc && stuck < 40) begin
        @(negedge clk);
        acc = c_req_ready[p];
        if (!acc) stuck++;
      end
      tick();
      cv[p] = 1'b0;
      if (acc) begin accepted++; stuck = 0; end
    end
    chk(accepted >= RQ && accepted <= RQ + 3, $sformatf("tier %0d: %0d requests accepted before back-pressure (queue depth %0d)", tier, accepted, RQ));
    chk(c_req_ready[p] == 1'b0, "request port still ready although the queue is full");
    repeat (60) tick();
    snap_g(); qf1 = snap[G_QFULL];
    chk(qf1 > qf0, "queue-full stall counter did not move");
    // release: the responses must come back in order, complete, and carry the right data
    crr[p] = 1'b1;
    for (int k = 0; k < accepted; k++) begin
      do @(negedge clk); while (!c_rsp_valid[p]);
      d = c_rsp_rdata[p*DW +: DW];
      chk(!c_rsp_err[p] && d === gm_word(base + k * DWB), $sformatf("tier %0d: response %0d wrong: %h expected %h", tier, k, d, gm_word(base + k * DWB)));
      tick();
    end
    repeat (50) begin @(negedge clk); chk(!c_rsp_valid[p], "extra response after draining"); end
    tick();
    $display("  T09 tier %0d: %0d requests accepted with responses blocked (RQ_DEPTH=%0d)", tier, accepted, RQ);
  end
  // saturate the external port: every port streams reads from its own DRAM region
  begin
    int ii [ND]; logic [7:0] gg [ND];
    for (int d2 = 2; d2 < ND; d2++) begin
      do_alloc(d2, longint'(d2) * DOMSZ, 1024, PREF_DRAM, 1, 1, 0, rc, ii[d2], gg[d2]);
      fill_range(d2, longint'(d2) * DOMSZ, 1024);
    end
    snap_g(); em0 = snap[G_EM_STALL];
    fork
      rnd_port_traffic(1, DOMSZ, 1024 / DWB, 200);
      if (ND > 2) rnd_port_traffic(2, 2 * DOMSZ, 1024 / DWB, 200);
      if (ND > 3) rnd_port_traffic(3, 3 * DOMSZ, 1024 / DWB, 200);
      begin
        // a migration in the background adds DMA + verify traffic to the same external port
        do_alloc(0, 65536, 2048, PREF_DRAM, 1, 1, 0, rc, i0, g0);
        fill_range(0, 65536, 2048);
        migrate(i0, g0, 0, rc, d);
      end
    join
    snap_g(); em1 = snap[G_EM_STALL];
    $display("  T09: external-port stall cycles under saturation: %0d", em1 - em0);
    chk(em1 > em0, "no external-port stalls under saturation");
    sweep_range(0, 65536, 2048);
  end
endtask

// ---------------------------------------------------------------------------------------------------------
// T10  tenant isolation
// ---------------------------------------------------------------------------------------------------------
task automatic t10_isolation();
  logic [7:0] rc, ga, gb, ga2, gb2, gm_, code, code_un, code_xt, gx;
  int ia, ib, ia2, ib2, im, ix;
  bit e, e2;
  logic [DW-1:0] d;
  logic [31:0] v, v2;
  rinfo_t r, rb2;
  longint unsigned f0, f1;
  longint unsigned x0;
  longint ph_old;
  cur_test = "T10_isolation";
  hw_reset(); tb_state_reset();
  for (int dd = 0; dd < ND; dd++) begin dom_set(dd, 65535, (dd == 3), 1'b1, rc); chk(rc == RC_OK, "domain setup"); end
  wr(R_CTRL, 32'b0110);

  // A = domain 0, B = domain 1; each owns an SRAM and a DRAM region with distinct secrets
  do_alloc(0, 0,    2048, PREF_SRAM, 1, 1, 0, rc, ia,  ga);
  do_alloc(0, 8192, 2048, PREF_DRAM, 1, 1, 0, rc, ia2, ga2);
  do_alloc(1, DOMSZ,        2048, PREF_SRAM, 1, 1, 0, rc, ib,  gb);
  do_alloc(1, DOMSZ + 8192, 2048, PREF_DRAM, 1, 1, 0, rc, ib2, gb2);
  fill_range(0, 0, 2048); fill_range(0, 8192, 2048); fill_range(1, DOMSZ, 2048); fill_range(1, DOMSZ + 8192, 2048);

  // ---- 1. cross-tenant reads and writes (B attacks A)
  snap_g(); f0 = snap[G_F_XTENANT];
  for (int o = 0; o < 2048; o += 128) begin
    crd(1, o, d, e, code);                                   chk(e && code == CE_FAULT && d === '0, $sformatf("cross-tenant read of %0h leaked data (err=%0b code=%0h data=%h)", o, e, code, d));
    seq_ctr++; cwr(1, 8192 + o, mkdata(o, seq_ctr), {DWB{1'b1}}, e, code); chk(e && code == CE_FAULT, "cross-tenant write accepted");
  end
  snap_g(); f1 = snap[G_F_XTENANT];
  chk(f1 - f0 == 32, $sformatf("cross-tenant fault counter delta %0d, expected 32", f1 - f0));
  rd(R_FAULT_INFO, v); chk(v[3:0] == FC_XTENANT && v[7:4] == 4'd1 && v[11:8] == 4'd1 && v[12] == 1'b1, $sformatf("fault capture %h", v));
  // victim data unchanged (reads by the owner compare against the golden model)
  sweep_range(0, 0, 2048); sweep_range(0, 8192, 2048);

  // ---- 2. no allocation-map side channel: unmapped and "someone else's" look identical to the client
  crd(1, 65536, d, e, code_un);                            // in B's window, nothing allocated there
  crd(1, 1024,  d, e2, code_xt);                           // inside A's SRAM region
  chk(e && e2 && code_un == code_xt && code_un == CE_FAULT, $sformatf("client-visible fault codes differ: unmapped %0h vs cross-tenant %0h", code_un, code_xt));
  rd(R_FAULT_INFO, v); chk(v[3:0] == FC_XTENANT, "management view lost the precise cause (cross-tenant)");
  crd(1, 65536, d, e, code_un);
  rd(R_FAULT_INFO, v); chk(v[3:0] == FC_UNMAPPED, "management view lost the precise cause (unmapped)");
  // malformed addresses
  crd(1, DOMSZ + 2, d, e, code);                           chk(e, "misaligned access accepted");
  rd(R_FAULT_INFO, v); chk(v[3:0] == FC_ALIGN, "misaligned access cause");
  crd(1, 64'h1000_0000, d, e, code);                       chk(e, "access above the managed window accepted");

  // ---- 3. host-DMA port behind the IOMMU boundary
  hd_dom = 0; hd_xlat_ok = 1'b0;
  crd(ND, 0, d, e, code);                                  chk(e, "host DMA without an IOMMU translation was served");
  rd(R_FAULT_INFO, v); chk(v[3:0] == FC_IOMMU, "host DMA cause");
  hd_xlat_ok = 1'b1;
  crd(ND, 0, d, e, code);                                  chk(!e, "host DMA for domain 0 with a valid translation refused");
  hd_dom = 1;
  crd(ND, 0, d, e, code);                                  chk(e, "host DMA bound to domain 1 read domain 0's region");
  rd(R_FAULT_INFO, v); chk(v[3:0] == FC_XTENANT && v[7:4] == ND, "host DMA cross-tenant cause / port");
  crd(ND, DOMSZ, d, e, code);                              chk(!e, "host DMA bound to domain 1 refused on its own region");
  hd_dom = 4'd9;                                           // a domain that does not exist
  crd(ND, 0, d, e, code);                                  chk(e, "host DMA with a non-existent domain was served");
  rd(R_FAULT_INFO, v); chk(v[3:0] == FC_DOMAIN, "host DMA non-existent domain cause");
  hd_dom = 0;

  // ---- 4. quarantine (domain 3 has auto-quarantine): one violation locks the domain, others are unaffected
  if (ND > 3) begin
    do_alloc(3, 3 * DOMSZ, 1024, PREF_DRAM, 1, 1, 0, rc, im, gm_);
    fill_range(3, 3 * DOMSZ, 1024);
    crd(3, 0, d, e, code);                                 chk(e, "domain 3 read domain 0 memory");
    wr(R_DSEL, 3); rd(R_DOM_STAT, v);                      chk(v[1], "domain 3 was not quarantined after a violation");
    crd(3, 3 * DOMSZ, d, e, code);                         chk(e, "quarantined domain still has access to its own region");
    rd(R_FAULT_INFO, v); chk(v[3:0] == FC_QUAR, "quarantine cause");
    rd_chk(0, 0, e);                                       chk(!e, "an unrelated domain was affected by the quarantine");
    cmd_rc(CMD_CLR_QUAR, 3, 0, 0, 0, rc);                  chk(rc == RC_OK, "CLR_QUAR");
    rd_chk(3, 3 * DOMSZ, e);                               chk(!e, "domain 3 did not recover after CLR_QUAR");
  end

  // ---- 5. stale mapping reuse: A frees its SRAM region; B receives the same physical SRAM; reads zero; A's old PVA is dead
  rinfo(ia, r);
  ph_old = r.phys_g;
  do_free(ia, ga, 0, 2048, rc);                            chk(rc == RC_OK, "A frees its SRAM region");
  do_alloc(1, DOMSZ + 32768, 2048, PREF_SRAM, 1, 1, 0, rc, ix, gx);
  chk(rc == RC_OK, "B allocates SRAM");
  rinfo(ix, rb2);
  chk(rb2.tier == 0 && rb2.phys_g == ph_old, $sformatf("B did not receive A's old extent (%0d vs %0d) -- test premise", rb2.phys_g, ph_old));
  sweep_range(1, DOMSZ + 32768, 2048);                     // golden = zeros: A's secrets must not be visible
  rd_chk(0, 0, e);                                         chk(e, "A still reaches its freed region");
  do_alloc(0, 0, 2048, PREF_DRAM, 1, 1, 0, rc, ia, ga);    // A re-allocates the same PVA in DRAM
  sweep_range(0, 0, 2048);                                 // zeros again, not A's old pattern

  // ---- 6. unauthorised remapping / management: non-privileged commands do nothing
  begin
    bit er;
    rinfo(ib, r);
    reg_wr(R_CMD_ARG0, ib, 1'b0, er);                      chk(er, "ARG0 written without privilege");
    reg_wr(R_CMD, CMD_MIGRATE, 1'b0, er);                  chk(er, "MIGRATE launched without privilege");
    reg_wr(R_CMD, CMD_FREE, 1'b0, er);                     chk(er, "FREE launched without privilege");
    rinfo(ib, rb2);
    chk(rb2.tier == r.tier && rb2.mig == 0 && rb2.state == RS_ACTIVE, "region changed by non-privileged commands");
  end
  // a handle from before the re-allocation is useless
  cmd_rc(CMD_MIGRATE, ia, ga + 8'd5, 1, 0, rc);            chk(rc == RC_STALE, "stale handle was accepted for MIGRATE");

  // ---- 7. access during an unsafe migration: the owner's accesses stall, they do not fault; others are unaffected;
  //         the management plane cannot free / re-migrate a region that is moving
  wr(R_CTRL, 32'b0100);                                    // stop-and-copy: the region is FROZEN from the start
  begin
    int mi; logic [7:0] mg;
    longint unsigned okb, okb2;
    do_alloc(0, 65536, 4096, PREF_DRAM, 1, 1, 0, rc, mi, mg);
    fill_range(0, 65536, 4096);
    start_migration_nowait(mi, mg, 0);
    cmd_rc(CMD_FREE, mi, mg, 0, 0, rc);                    chk(rc == RC_BUSY, $sformatf("FREE of a migrating region rc=%0h", rc));
    cmd_rc(CMD_MIGRATE, mi, mg, 1, 0, rc);                 chk(rc == RC_BUSY, "second MIGRATE of a migrating region");
    okb = ok_acc[1];
    fork
      begin  // A reads its migrating region: must complete (after the freeze) with the right data
        for (int k = 0; k < 8; k++) begin rd_chk(0, 65536 + 512 * k, e); chk(!e, "owner read refused during migration"); end
      end
      begin  // B works normally the whole time
        stop_r = 1'b0;
        while (ok_acc[1] < okb + 150) begin rd_chk(1, DOMSZ + 8192 + DWB * ($urandom_range(0, 100)), e2); chk(!e2, "B refused during A's migration"); end
      end
    join
    wait_mig_done(2_000_000, v);
    chk(v[2], "migration of the contested region");
    sweep_range(0, 65536, 4096);
  end
  // ---- 8. data A left in SRAM after a demotion is not readable by the next SRAM owner
  begin
    int si; logic [7:0] sg; int ti; logic [7:0] tg;
    do_alloc(0, 131072, 1024, PREF_SRAM, 1, 1, 0, rc, si, sg);
    fill_range(0, 131072, 1024);
    migrate(si, sg, 1, rc, v);                             chk(rc == RC_OK && v[2], "demote A's SRAM region");
    do_alloc(1, DOMSZ + 131072, 1024, PREF_SRAM, 1, 1, 0, rc, ti, tg);
    chk(rc == RC_OK, "B takes the SRAM that A vacated");
    sweep_range(1, DOMSZ + 131072, 1024);
    sweep_range(0, 131072, 1024);
  end
  // final global check of the invariants and that nobody's data moved: everything previously written still matches
  sweep_range(1, DOMSZ, 2048); sweep_range(1, DOMSZ + 8192, 2048);
endtask

// ---------------------------------------------------------------------------------------------------------
// T11  fault injection: media errors, corruption during migration, verification, abort, retry
// ---------------------------------------------------------------------------------------------------------
task automatic t11_faults();
  logic [7:0] rc, gen, code;
  logic [31:0] st, v;
  int idx;
  rinfo_t r;
  bit e;
  logic [DW-1:0] d;
  longint unsigned retry0, retry1, ab0, ab1, mismatches;
  longint dram_base_b;
  int len;
  cur_test = "T11_faults";
  fresh(1'b0);
  wr(R_CTRL, 32'b0110);
  len = 2048;

  // ---- (a) one-shot corruption of the destination while demoting SRAM -> DRAM: verify detects it, the chunk is copied again
  do_alloc(0, 0, len, PREF_SRAM, 1, 1, 0, rc, idx, gen);
  fill_range(0, 0, len);
  snap_g(); retry0 = snap[G_MIG_RETRY];
  inj_corrupt_lo = 0; inj_corrupt_hi = DRAM_BYTES; inj_corrupt_mask = {{(DW-1){1'b0}}, 1'b1}; inj_corrupt_once = 1'b1; inj_corrupt_en = 1'b1;
  migrate(idx, gen, 1, rc, st);
  inj_corrupt_en = 1'b0;
  chk(rc == RC_OK && st[2] && st[15:8] == MR_OK, $sformatf("one-shot corruption: migration result %0h", st[15:8]));
  snap_g(); retry1 = snap[G_MIG_RETRY];
  chk(retry1 - retry0 >= 1, "verification did not trigger a retry after the corrupted write");
  chk(dram.st_corrupted == 1, $sformatf("DRAM model corrupted %0d writes", dram.st_corrupted));
  sweep_range(0, 0, len);
  rinfo(idx, r); chk(r.tier == 1 && r.err == RE_NONE, "region after a recovered corruption");

  // ---- (b) persistent corruption: the migration aborts, the source stays authoritative and intact, the destination is released
  do_free(idx, gen, 0, len, rc);
  do_alloc(0, 0, len, PREF_SRAM, 1, 1, 0, rc, idx, gen);
  fill_range(0, 0, len);
  snap_g(); ab0 = snap[G_MIG_ABORT];
  inj_corrupt_lo = 0; inj_corrupt_hi = DRAM_BYTES; inj_corrupt_mask = {{(DW-1){1'b0}}, 1'b1}; inj_corrupt_once = 1'b0; inj_corrupt_en = 1'b1;
  begin int ras0 = ras_cnt[EV_DMA_ERR];
    migrate(idx, gen, 1, rc, st);
    inj_corrupt_en = 1'b0;
    chk(rc == RC_OK && !st[2] && st[15:8] == MR_VERIFY, $sformatf("persistent corruption: result %0h (expected MR_VERIFY)", st[15:8]));
    chk(ras_cnt[EV_DMA_ERR] > ras0, "no RAS event for the aborted migration");
  end
  snap_g(); ab1 = snap[G_MIG_ABORT];
  chk(ab1 - ab0 == 1, "abort counter");
  rinfo(idx, r);
  chk(r.tier == 0 && r.mig == 0 && r.state == RS_ACTIVE && r.err == RE_MIG_VER, $sformatf("region after abort: tier=%0d mig=%0d err=%0h", r.tier, r.mig, r.err));
  chk(bm_pop(1) == 0 && bm_pop(0) == len / GRAN, "destination extent leaked after an aborted migration");
  sweep_range(0, 0, len);                                   // the source was never touched
  cmd_rc(CMD_CLR_ERR, idx, gen, 0, 0, rc);                  chk(rc == RC_OK, "CLR_ERR");
  rinfo(idx, r);                                            chk(r.err == RE_NONE, "region error not cleared");
  migrate(idx, gen, 1, rc, st);                             chk(rc == RC_OK && st[2], "migration succeeds once the fault is gone");
  sweep_range(0, 0, len);

  // ---- (c) negative control: with verification OFF the same corruption IS committed (the commit-time comparison would flag it)
  do_free(idx, gen, 0, len, rc);
  do_alloc(0, 0, len, PREF_SRAM, 1, 1, 0, rc, idx, gen);
  fill_range(0, 0, len);
  wr(R_CTRL, 32'b0010);                                     // pre-copy, verify OFF
  mon_commit_en = 1'b0; neg_ctrl_bytes = 0;
  inj_corrupt_lo = 0; inj_corrupt_hi = DRAM_BYTES; inj_corrupt_mask = {{(DW-1){1'b0}}, 1'b1}; inj_corrupt_once = 1'b1; inj_corrupt_en = 1'b1;
  migrate(idx, gen, 1, rc, st);
  inj_corrupt_en = 1'b0;
  mon_commit_en = 1'b1;
  chk(rc == RC_OK && st[2], "negative control: migration with verify off");
  chk(neg_ctrl_bytes >= 1, "negative control: the commit-time monitor did not see the corruption (the check cannot fail)");
  mismatches = 0;
  for (int o = 0; o < len; o += DWB) begin
    rd_chk_count(0, o, e);
  end
  $display("  T11 negative control: %0d destination bytes differed at commit without verification (detected by the monitor, as it must)", neg_ctrl_bytes);
  wr(R_CTRL, 32'b0110);
  // restore golden: re-fill the region with fresh data so later checks are meaningful
  fill_range(0, 0, len);
  sweep_range(0, 0, len);
  do_free(idx, gen, 0, len, rc);

  // ---- (d) DRAM error responses while PROMOTING (source reads fail): migration aborts with MR_DMA, source intact
  do_alloc(0, 4096, len, PREF_DRAM, 1, 1, 0, rc, idx, gen);
  fill_range(0, 4096, len);
  rinfo(idx, r);
  inj_err_lo = r.phys_g * GRAN + 256; inj_err_hi = r.phys_g * GRAN + 512; inj_err_en = 1'b1;   // errors on one granule of the source
  migrate(idx, gen, 0, rc, st);
  chk(rc == RC_OK && !st[2] && st[15:8] == MR_DMA, $sformatf("DRAM error during copy: result %0h (expected MR_DMA)", st[15:8]));
  inj_err_en = 1'b0;
  rinfo(idx, r);
  chk(r.tier == 1 && r.mig == 0 && r.err == RE_MIG_DMA, $sformatf("region after DMA abort: tier=%0d mig=%0d err=%0h", r.tier, r.mig, r.err));
  chk(bm_pop(0) == 0, "SRAM reservation leaked by the DMA abort");
  sweep_range(0, 4096, len);
  cmd_rc(CMD_CLR_ERR, idx, gen, 0, 0, rc);

  // ---- (e) media error on a tenant read: client sees CE_MEDIA (not CE_FAULT), region error latched, RAS event raised
  rinfo(idx, r);
  begin int ras0 = ras_cnt[EV_MEM_UE];
    inj_err_lo = r.phys_g * GRAN + 512; inj_err_hi = r.phys_g * GRAN + 512 + DWB; inj_err_en = 1'b1;
    crd(0, 4096 + 512, d, e, code);
    inj_err_en = 1'b0;
    chk(e && code == CE_MEDIA && d === '0, $sformatf("media error presented as err=%0b code=%0h", e, code));
    chk(ras_cnt[EV_MEM_UE] == ras0 + 1 && ras_last_addr == 32'(4096 + 512), "RAS event for the media error");
  end
  rinfo(idx, r);                                            chk(r.err == RE_MEDIA, "region error code after a media error");
  snap_g();                                                 chk(snap[G_MEDIA_ERR] == 1, "media-error counter");
  rd_chk(0, 4096 + 512, e);                                 chk(!e, "the region is usable again after the transient error");
  cmd_rc(CMD_CLR_ERR, idx, gen, 0, 0, rc);                  chk(rc == RC_OK, "CLR_ERR after a media error");
endtask
task automatic rd_chk_count(input int p, input longint pva, output bit err);
  logic [DW-1:0] r; logic [7:0] code;
  xfer(p, 1'b0, pva, '0, '0, r, err, code);
  if (!err && gm_all(pva)) begin
    if (r !== gm_word(pva)) begin
      neg_ctrl_bytes += 0;                                     // golden mismatch expected here; counted via the monitor above
      for (int b = 0; b < DWB; b++) if (r[b*8 +: 8] !== gm[pva + b]) gm[pva + b] = r[b*8 +: 8];   // adopt the corrupted value as truth
    end
  end
endtask


// ---------------------------------------------------------------------------------------------------------
// T12  tiering policy: promotion, capacity-driven demotion, no churn, anti-oscillation
// ---------------------------------------------------------------------------------------------------------
// measure idle service latencies of the two tiers (single outstanding access, no migration)
task automatic calibrate_latency(input int p, input longint sram_pva, input longint dram_pva, output real lat_s, output real lat_d);
  longint unsigned s0, s1, c0, c1, t0s0, t0c0, t1s0, t1c0;
  bit e;
  snap_g(); s0 = snap[G_LAT_SUM]; c0 = snap[G_LAT_CNT]; t0s0 = snap[G_LAT_SUM_T0]; t0c0 = snap[G_LAT_CNT_T0]; t1s0 = snap[G_LAT_SUM_T1]; t1c0 = snap[G_LAT_CNT_T1];
  for (int i = 0; i < 64; i++) begin rd_chk(p, sram_pva + (i % 32) * DWB, e); repeat (3) tick(); end
  snap_g(); s1 = snap[G_LAT_SUM]; c1 = snap[G_LAT_CNT];
  lat_s = real'(s1 - s0) / real'(c1 - c0);
  // the per-tier counters (the policy's auto-benefit input) must have seen exactly these accesses and agree with the global ones
  chk(snap[G_LAT_CNT_T0] - t0c0 == c1 - c0 && snap[G_LAT_CNT_T1] == t1c0, "calibration: per-tier latency sample counts wrong (SRAM reads)");
  chk(snap[G_LAT_SUM_T0] - t0s0 == s1 - s0, "calibration: tier-0 latency sum differs from the global latency sum");
  chk(lat_s >= 2.0 && lat_s <= 8.0, $sformatf("calibration: idle SRAM service latency %f cycles is implausible (expected about 3)", lat_s));
  s0 = s1; c0 = c1; t1s0 = snap[G_LAT_SUM_T1]; t1c0 = snap[G_LAT_CNT_T1]; t0c0 = snap[G_LAT_CNT_T0];
  for (int i = 0; i < 64; i++) begin rd_chk(p, dram_pva + (i % 32) * DWB, e); repeat (3) tick(); end
  snap_g(); s1 = snap[G_LAT_SUM]; c1 = snap[G_LAT_CNT];
  lat_d = real'(s1 - s0) / real'(c1 - c0);
  chk(snap[G_LAT_CNT_T1] - t1c0 == c1 - c0 && snap[G_LAT_CNT_T0] == t0c0, "calibration: per-tier latency sample counts wrong (DRAM reads)");
  chk(snap[G_LAT_SUM_T1] - t1s0 == s1 - s0, "calibration: tier-1 latency sum differs from the global latency sum");
  chk(lat_d >= 8.0 && lat_d <= 45.0, $sformatf("calibration: idle DRAM service latency %f cycles is implausible", lat_d));
endtask
task automatic pol_cfg(input int epoch, input int hot_min, input int decay, input int cool, input int horizon,
                       input int cost_gran, input int cost_chunk, input int delta, input int margin_shift, input int hyst, input int high_wm);
  wr(R_POL_CTRL0, epoch);
  wr(R_POL_CTRL1, {8'(horizon), 8'(cool), 8'(decay), 8'(hot_min)});
  wr(R_POL_COST,  {16'(cost_chunk), 16'(cost_gran)});
  wr(R_POL_DELTA, delta);
  wr(R_POL_MARGIN, {16'(high_wm), 8'(hyst), 8'(margin_shift)});
endtask
bit hammer_stop;
task automatic hammer(input int p, input longint base, input int words, input int gap, input bit wr_mix);
  bit e;
  while (!hammer_stop) begin
    if (wr_mix && $urandom_range(0, 3) == 0) wr_full(p, base + longint'($urandom_range(0, words - 1)) * DWB, e);
    else rd_chk(p, base + longint'($urandom_range(0, words - 1)) * DWB, e);
    if (gap > 0) repeat (gap) tick();
  end
endtask
task automatic wait_cycles(input int n); repeat (n) tick(); endtask
// reads region A and region B alternately (same word index); B once more every 6th iteration (so B is marginally hotter than A)
task automatic hammer_pair(input int p, input longint a, input longint b, input int words, input int gap);
  bit e;
  int w, it;
  it = 0;
  while (!hammer_stop) begin
    w = $urandom_range(0, words - 1);
    rd_chk(p, a + longint'(w) * DWB, e);
    rd_chk(p, b + longint'(w) * DWB, e);
    if (it % 6 == 0) rd_chk(p, b + longint'((w + 1) % words) * DWB, e);
    it++;
    repeat (gap) tick();
  end
endtask

task automatic t12_policy();
  logic [7:0] rc, g_hot, g_cold, g_s [16]; 
  int i_hot, i_cold, i_s [16];
  real ls, ld;
  rinfo_t r;
  longint unsigned p0, p1, mg0, mg1;
  int n_prot, n_unprot;
  logic [31:0] v;

  // ------------------------------------------------------------------ (a) a hot DRAM region is promoted, a cold one is left alone
  cur_test = "T12a_promote";
  fresh(1'b0);
  wr(R_CTRL, 32'b0110);
  do_alloc(0, 0, 4096, PREF_DRAM, 1, 1, 0, rc, i_hot, g_hot);
  do_alloc(0, 65536, 4096, PREF_DRAM, 1, 1, 0, rc, i_cold, g_cold);
  do_alloc(1, DOMSZ, 4096, PREF_SRAM, 1, 1, 0, rc, i_s[0], g_s[0]);          // reference regions of domain 1 for calibration
  do_alloc(1, DOMSZ + 65536, 4096, PREF_DRAM, 1, 1, 0, rc, i_s[1], g_s[1]);
  calibrate_latency(1, DOMSZ, DOMSZ + 65536, ls, ld);
  chk(ld > ls, "calibration: DRAM is not slower than SRAM");
  $display("  T12a: idle service latency SRAM %f cycles, DRAM %f cycles (delta %f)", ls, ld, ld - ls);
  pol_cfg(4000, 2, 1, 4, 16, 1100, 400, int'(ld - ls), 1, 8, G0);
  wr(R_CTRL, 32'b0111);                                                        // policy on
  hammer_stop = 1'b0;
  snap_g(); p0 = snap[G_POL_REQ];
  fork
    hammer(0, 0, 1024, 3, 1'b0);
    begin
      for (int w = 0; w < 400 && !(dut.u_table.tier_q[i_hot] == 1'b0 && dut.u_table.mig_q[i_hot] == MG_NONE); w++) wait_cycles(1000);
      hammer_stop = 1'b1;
    end
  join
  wait_cycles(200);
  rinfo(i_hot, r);
  chk(r.tier == 0 && r.mig == 0, "the hot DRAM region was not promoted by the policy");
  rinfo(i_cold, r);
  chk(r.tier == 1, "the cold region was migrated although nobody uses it");
  snap_g(); p1 = snap[G_POL_REQ];
  chk(p1 - p0 >= 1, "no policy request was made");
  chk(snap[G_POL_FAIL] == 0, "the command engine refused a policy request");
  chk(snap[G_MIG_OK] >= 1, "no migration completed");
  sweep_range(0, 0, 4096);
  rd(R_POL_COSTEST, v); $display("  T12a: promoted after %0d epochs; policy requests %0d; cost estimate %0d cycles/granule", dut.u_policy.epochs_q, p1 - p0, v);
  wr(R_CTRL, 32'b0110);

  // ------------------------------------------------------------------ (b) SRAM full of cold regions: the coldest is demoted to make room for a hot one
  cur_test = "T12b_capacity";
  fresh(1'b0);
  wr(R_CTRL, 32'b0110);
  begin
    int ns;
    ns = G0 * GRAN / 4096;                                                       // 4 KiB regions filling SRAM
    for (int k = 0; k < ns && k < 16; k++) begin
      do_alloc(k % 4 < ND ? k % 4 : 0, longint'(k % 4) * DOMSZ + longint'(k / 4) * 4096, 4096, PREF_SRAM, 1, 1, 0, rc, i_s[k], g_s[k]);
      chk(rc == RC_OK, "fill SRAM with cold regions");
    end
    chk(int'(dut.occ0) == G0 || ns > 16, "SRAM not full before the test");
    do_alloc(0, 65536, 4096, PREF_DRAM, 1, 1, 0, rc, i_hot, g_hot);   // hot region lives in DRAM (domain 0)
    chk(rc == RC_OK, "alloc hot");
    // two SRAM regions get a little traffic (warm); the rest are cold
    // making room costs two migrations (~2 x 17.6K cycles, x1.5 margin = 52.8K): the benefit over the horizon must cover that
    pol_cfg(4000, 2, 1, 4, 64, 1100, 400, 11, 1, 8, G0);
    wr(R_CTRL, 32'b0111);
    hammer_stop = 1'b0;
    fork
      hammer(0, 65536, 1024, 0, 1'b0);
      begin
        for (int w = 0; w < 600 && !(dut.u_table.tier_q[i_hot] == 1'b0 && dut.u_table.mig_q[i_hot] == MG_NONE); w++) wait_cycles(1000);
        hammer_stop = 1'b1;
      end
    join
    wait_cycles(200);
    rinfo(i_hot, r);
    chk(r.tier == 0, "hot region not promoted into a full SRAM (no demotion made room)");
    begin int in_dram = 0;
      for (int k = 0; k < ns && k < 16; k++) if (dut.u_table.tier_q[i_s[k]] == 1'b1) in_dram++;
      chk(in_dram == 1, $sformatf("%0d cold regions were demoted, expected exactly 1", in_dram));
    end
    snap_g();
    $display("  T12b: %0d policy requests (expected a demotion then a promotion), %0d migrations completed", snap[G_POL_REQ], snap[G_MIG_OK]);
    chk(snap[G_POL_REQ] == 2 && snap[G_MIG_OK] == 2, $sformatf("expected 2 migrations (demote + promote), got %0d requests / %0d completions", snap[G_POL_REQ], snap[G_MIG_OK]));
    wr(R_CTRL, 32'b0110);
  end

  // ------------------------------------------------------------------ (c) alternating hotness: protected policy vs. one without cooldown / hysteresis
  // SRAM is full: 15 pinned 4 KiB regions, one pinned 3 KiB region, and region A (1 KiB).  Region B (1 KiB) lives in DRAM.
  // Only A can be evicted, so A and B compete for ONE slot, and the hot spot alternates between them every 8000 cycles
  // (two policy epochs) -- faster than a migration pays back.
  for (int variant = 0; variant < 2; variant++) begin
    int ia_, ib_; logic [7:0] ga_, gb_;
    cur_test = $sformatf("T12c_oscillation_%s", variant ? "unprotected" : "protected");
    fresh(1'b0);
    wr(R_CTRL, 32'b0110);
    for (int k = 0; k < 15; k++) begin
      do_alloc(k % 4 < ND ? k % 4 : 0, longint'(k % 4) * DOMSZ + longint'(k / 4) * 4096, 4096, PREF_SRAM, 1, 1, 1, rc, i_s[k], g_s[k]);   // pinned fillers
      chk(rc == RC_OK, "pinned filler");
    end
    do_alloc(0, 32768, G0 * GRAN - 15 * 4096 - 1024, PREF_SRAM, 1, 1, 1, rc, i_s[15], g_s[15]);   // pinned remainder (3 KiB at 64 KiB SRAM)
    chk(rc == RC_OK, "pinned remainder");
    do_alloc(1, DOMSZ + 32768, 1024, PREF_SRAM, 1, 1, 0, rc, ia_, ga_);        // A in SRAM (domain 1)
    do_alloc(1, DOMSZ + 65536, 1024, PREF_DRAM, 1, 1, 0, rc, ib_, gb_);        // B in DRAM (domain 1)
    chk(int'(dut.occ0) == G0, "SRAM not full in the oscillation scenario");
    if (variant == 0) pol_cfg(4000, 2, 1, 6, 16, 1100, 400, 11, 1, 8, G0);   // cooldown 6 epochs, hysteresis 8 accesses/epoch
    else              pol_cfg(4000, 2, 1, 0, 16, 1100, 400, 11, 7, 0, G0);   // cooldown 0, hysteresis 0, margin ~0
    wr(R_CTRL, 32'b0111);
    snap_g(); mg0 = snap[G_POL_REQ];
    for (int ph = 0; ph < 10; ph++) begin
      hammer_stop = 1'b0;
      fork
        begin if (ph % 2 == 0) hammer(1, DOMSZ + 65536, 256, 0, 1'b0); else hammer(1, DOMSZ + 32768, 256, 0, 1'b0); end
        begin wait_cycles(8000); hammer_stop = 1'b1; end
      join
    end
    wr(R_CTRL, 32'b0110);
    wait_cycles(60000);                                                           // let any migration finish
    snap_g(); mg1 = snap[G_POL_REQ];
    if (variant == 0) n_prot = int'(mg1 - mg0); else n_unprot = int'(mg1 - mg0);
    $display("  T12c %s: %0d migration requests in 10 alternating 8000-cycle phases (%0d completed)", variant ? "unprotected" : "protected", mg1 - mg0, snap[G_MIG_OK]);
    sweep_range(1, DOMSZ + 32768, 1024); sweep_range(1, DOMSZ + 65536, 1024);
  end
  chk(n_prot < n_unprot, $sformatf("protection did not reduce migrations: protected %0d vs unprotected %0d", n_prot, n_unprot));
  chk(n_prot <= 6, $sformatf("protected policy still migrated %0d times in 10 phases", n_prot));
  chk(n_unprot >= 2 * n_prot || n_unprot >= n_prot + 4, $sformatf("the unprotected policy was not meaningfully worse (%0d vs %0d): scenario insensitive", n_unprot, n_prot));

  // ------------------------------------------------------------------ (h) hysteresis ALONE (cooldown 0, a long horizon so the swap would pay): A (SRAM) and B (DRAM) are almost equally hot,
  // B hotter by roughly 10 accesses per epoch.  A hysteresis gap of 24 must keep the policy from swapping them; gap 0 swaps once.
  begin
    int n_h [2];
    for (int variant = 0; variant < 2; variant++) begin
      int ia_, ib_; logic [7:0] ga_, gb_;
      cur_test = $sformatf("T12h_hysteresis_%s", variant ? "off" : "on");
      fresh(1'b0);
      wr(R_CTRL, 32'b0110);
      for (int k = 0; k < 15; k++) begin
        do_alloc(k % 4 < ND ? k % 4 : 0, longint'(k % 4) * DOMSZ + longint'(k / 4) * 4096, 4096, PREF_SRAM, 1, 1, 1, rc, i_s[k], g_s[k]);
        chk(rc == RC_OK, "pinned filler");
      end
      do_alloc(0, 32768, G0 * GRAN - 15 * 4096 - 1024, PREF_SRAM, 1, 1, 1, rc, i_s[15], g_s[15]);
      chk(rc == RC_OK, "pinned remainder");
      do_alloc(1, DOMSZ + 32768, 1024, PREF_SRAM, 1, 1, 0, rc, ia_, ga_);        // A in SRAM
      do_alloc(1, DOMSZ + 65536, 1024, PREF_DRAM, 1, 1, 0, rc, ib_, gb_);        // B in DRAM
      chk(int'(dut.occ0) == G0, "SRAM not full in the hysteresis scenario");
      pol_cfg(4000, 2, 1, 0, 64, 1100, 400, 11, 1, variant ? 0 : 24, G0);
      wr(R_CTRL, 32'b0111);
      snap_g(); mg0 = snap[G_POL_REQ];
      hammer_stop = 1'b0;
      fork
        hammer_pair(1, DOMSZ + 32768, DOMSZ + 65536, 1024 / DWB, 40);
        begin wait_cycles(80000); hammer_stop = 1'b1; end
      join
      wr(R_CTRL, 32'b0110);
      wait_cycles(60000);
      snap_g(); n_h[variant] = int'(snap[G_POL_REQ] - mg0);
      $display("  T12h hysteresis %s: %0d migration requests in 20 epochs", variant ? "off (gap 0)" : "on (gap 24)", n_h[variant]);
      sweep_range(1, DOMSZ + 32768, 1024); sweep_range(1, DOMSZ + 65536, 1024);
    end
    chk(n_h[0] == 0, $sformatf("hysteresis gap 24 did not stop a swap of two almost equally hot regions (%0d requests)", n_h[0]));
    chk(n_h[1] >= 2, $sformatf("scenario insensitive: with gap 0 the policy made only %0d requests (expected a demotion and a promotion)", n_h[1]));
  end


  // ------------------------------------------------------------------ (e) opt-in memory-pressure relief
  cur_test = "T12e_pressure";
  fresh(1'b0);
  wr(R_CTRL, 32'b0110);
  for (int k = 0; k < 16; k++) begin
    do_alloc(k % 4 < ND ? k % 4 : 0, longint'(k % 4) * DOMSZ + longint'(k / 4) * 4096, 4096, PREF_SRAM, 1, 1, 0, rc, i_s[k], g_s[k]);
    chk(rc == RC_OK, "fill SRAM");
  end
  chk(int'(dut.occ0) == G0, "SRAM not full");
  pol_cfg(4000, 2, 1, 2, 16, 1100, 400, 11, 1, 8, G0);                         // watermark = capacity: pressure relief OFF
  wr(R_CTRL, 32'b0111);
  wait_cycles(60000);
  snap_g();
  chk(snap[G_POL_REQ] == 0, "pressure relief fired with the default (disabled) watermark");
  pol_cfg(4000, 2, 1, 2, 16, 1100, 400, 11, 1, 8, G0 * 3 / 4);                 // 75 %: demote cold regions until occupancy <= 192 granules
  wait_cycles(300000);
  snap_g();
  $display("  T12e: with a 75%% watermark the policy made %0d demotions; SRAM occupancy %0d of %0d granules", snap[G_POL_REQ], dut.occ0, G0);
  chk(int'(dut.occ0) <= G0 * 3 / 4, "SRAM occupancy still above the watermark");
  chk(snap[G_POL_REQ] == (G0 - G0 * 3 / 4) / 16, $sformatf("expected %0d demotions of 16 granules, got %0d", (G0 - G0 * 3 / 4) / 16, snap[G_POL_REQ]));
  wait_cycles(100000);
  begin longint unsigned a, b2; snap_g(); a = snap[G_POL_REQ]; wait_cycles(100000); snap_g(); b2 = snap[G_POL_REQ];
    chk(a == b2, "the policy kept migrating after the pressure was relieved"); end
  wr(R_CTRL, 32'b0110);


  // ------------------------------------------------------------------ (f) auto-calibrated benefit: with delta programmed to 0 the policy must still find the benefit by measuring
  cur_test = "T12f_auto_delta";
  fresh(1'b0);
  wr(R_CTRL, 32'b0110);
  do_alloc(0, 0, 4096, PREF_DRAM, 1, 1, 0, rc, i_hot, g_hot);
  do_alloc(1, DOMSZ, 4096, PREF_SRAM, 1, 1, 0, rc, i_s[0], g_s[0]);              // SRAM latency reference traffic
  do_alloc(1, DOMSZ + 65536, 4096, PREF_DRAM, 1, 1, 0, rc, i_s[1], g_s[1]);      // DRAM latency reference traffic
  pol_cfg(4000, 2, 1, 4, 16, 1100, 400, 0, 1, 8, G0);                           // delta = 0: with a programmed benefit of 0 nothing could ever pay
  wr(R_CTRL, 32'b10111);                                                         // policy | pre-copy | verify | AUTODELTA
  hammer_stop = 1'b0;
  snap_g(); p0 = snap[G_POL_REQ];
  fork
    hammer(0, 0, 1024, 3, 1'b0);
    begin  // light traffic on domain 1's SRAM and DRAM regions so that both tiers have latency samples
      while (!hammer_stop) begin bit e2; rd_chk(1, DOMSZ + 4 * $urandom_range(0, 100), e2); rd_chk(1, DOMSZ + 65536 + 4 * $urandom_range(0, 100), e2); repeat (40) tick(); end
    end
    begin
      for (int w = 0; w < 400 && !(dut.u_table.tier_q[i_hot] == 1'b0 && dut.u_table.mig_q[i_hot] == MG_NONE); w++) wait_cycles(1000);
      hammer_stop = 1'b1;
    end
  join
  wait_cycles(200);
  rd(R_POL_DELTAEST, v);
  $display("  T12f: measured benefit estimate %0d cycles/access (idle calibration gave %f); promoted after %0d epochs", v, ld - ls, dut.u_policy.epochs_q);
  rinfo(i_hot, r);
  chk(r.tier == 0, "with delta programmed to 0 and AUTODELTA on, the hot region was not promoted");
  chk(v >= 8 && v <= 60, $sformatf("measured benefit estimate %0d is outside the plausible range", v));
  wr(R_CTRL, 32'b0110);


  // ------------------------------------------------------------------ (g) a refused request backs off: fragmented SRAM, nowhere to put a hot 8 KiB region
  cur_test = "T12g_refusal_backoff";
  fresh(1'b0);
  wr(R_CTRL, 32'b0110);
  begin
    int n_f; n_f = G0 * GRAN / 4096;
    for (int k = 0; k < n_f && k < 16; k++) do_alloc(3 % ND, 3 * DOMSZ + longint'(k) * 4096, 4096, PREF_SRAM, 1, 1, 1, rc, i_s[k], g_s[k]);   // pinned fillers fill the SRAM
    for (int k = 0; k < n_f && k < 16; k += 2) begin do_free(i_s[k], g_s[k], 3 * DOMSZ + longint'(k) * 4096, 4096, rc); chk(rc == RC_OK, "free alternate filler"); end
    chk(G0 - int'(dut.occ0) >= 2 * 16, "no SRAM free space in the fragmentation scenario");
  end
  do_alloc(0, 0, 8192, PREF_DRAM, 1, 1, 0, rc, i_hot, g_hot);                       // 32 granules: larger than every 16-granule hole
  pol_cfg(4000, 2, 1, 4, 64, 1100, 400, 11, 1, 8, G0);
  wr(R_CTRL, 32'b0111);
  hammer_stop = 1'b0;
  fork
    hammer(0, 0, 2048, 0, 1'b0);
    begin wait_cycles(400000); hammer_stop = 1'b1; end
  join
  wr(R_CTRL, 32'b0110);
  snap_g();
  $display("  T12g: hot region cannot be placed: %0d policy requests, %0d refused over ~100 epochs (cooldown 4)", snap[G_POL_REQ], snap[G_POL_FAIL]);
  chk(snap[G_POL_FAIL] >= 1 && snap[G_POL_FAIL] == snap[G_POL_REQ], "the policy never tried (or something was accepted)");
  chk(snap[G_POL_FAIL] <= 8, $sformatf("refused requests are retried too often (%0d in 100 epochs)", snap[G_POL_FAIL]));
  rinfo(i_hot, r); chk(r.tier == 1 && r.mig == 0, "refused migrations must leave the region untouched");

  // ------------------------------------------------------------------ (d) a short burst does not pay for a migration
  cur_test = "T12d_no_benefit";
  fresh(1'b0);
  wr(R_CTRL, 32'b0110);
  do_alloc(0, 0, 4096, PREF_DRAM, 1, 1, 0, rc, i_hot, g_hot);
  pol_cfg(4000, 2, 1, 4, 16, 1100, 400, 11, 1, 8, G0);
  wr(R_CTRL, 32'b0111);
  hammer_stop = 1'b0;
  fork
    hammer(0, 0, 1024, 40, 1'b0);                                                  // ~25 accesses per 1000 cycles: warm, not hot
    begin wait_cycles(60000); hammer_stop = 1'b1; end
  join
  wr(R_CTRL, 32'b0110);
  snap_g();
  $display("  T12d: warm region (about 100 accesses per epoch): %0d policy requests", snap[G_POL_REQ]);
  chk(snap[G_POL_REQ] == 0, "a lukewarm region was migrated although the migration cannot pay for itself");
endtask

// ---------------------------------------------------------------------------------------------------------

// ---------------------------------------------------------------------------------------------------------
// TRACE  replay of a workload trace file (tools/trace_gen.py) with a machine-readable report
//
// Trace format (one command per line, '#' starts a comment):
//   CTRL <hex>                      R_CTRL  [0] policy  [1] pre-copy  [2] verify  [3] auto-cost
//   MIGCTL <rounds> <thresh> <retry>
//   POL <name> <value>              epoch hot_min decay cooldown horizon cost_gran cost_chunk delta margin hyst highwm
//   DOM <d> <quota_gran> <autoq>    window [d MiB, d+1 MiB), enabled
//   BIND <port> <dom>
//   REG <id> <dom> <pva_hex> <bytes> <pref 0|1|2> <perm 1..3> <pin>
//   FREE <id>
//   A <port> <gap> <R|W> <pva_hex>  one client access (closed loop: next one starts after this response + gap)
//   EVT <cycle> MIG <id> <dst>      management migration at <cycle> after the run started
//   EVT <cycle> CTRL <hex>
// ---------------------------------------------------------------------------------------------------------
typedef struct { int port; int gap; bit wr; longint pva; } acc_t;
typedef struct { longint cyc; int kind; int a; int b; } evt_t;
acc_t   tr_all [$];                // every access record of the trace, in file order, tagged with its port
int     tr_cnt [NPT];              // records per port (an array of queues is avoided on purpose: not reliable in Verilator)
evt_t   tr_evt [$];
int     tr_idx  [int];
logic [7:0] tr_gen [int];
longint tr_pva  [int];
int     tr_len  [int];
int     tr_dom  [int];
bit     tr_live [int];
longint unsigned tr_done_cyc [NPT];
bit tr_thr_done [NPT];
bit tr_evt_done;
longint unsigned lat_hist [8];
longint unsigned tr_mig_ok, tr_mig_refused;

task automatic tr_lat_hist_add(input longint unsigned lat);
  int b;
  if      (lat <= 8)    b = 0;
  else if (lat <= 16)   b = 1;
  else if (lat <= 32)   b = 2;
  else if (lat <= 64)   b = 3;
  else if (lat <= 256)  b = 4;
  else if (lat <= 1024) b = 5;
  else if (lat <= 8192) b = 6;
  else                  b = 7;
  lat_hist[b]++;
endtask

task automatic trace_port(input int p);
  bit e; logic [DW-1:0] d; logic [7:0] code; longint unsigned t0;
  acc_t x;
  for (int i = 0; i < tr_all.size(); i++) begin
    x = tr_all[i];
    if (x.port == p) begin
      if (x.gap > 0) repeat (x.gap) tick();
      t0 = lat_sum_tb;
      if (x.wr) begin seq_ctr++; cwr(p, x.pva, mkdata(x.pva, seq_ctr), {DWB{1'b1}}, e, code); end
      else crd(p, x.pva, d, e, code);
      tr_lat_hist_add(lat_sum_tb - t0);
      chk(!e, $sformatf("trace access refused: port %0d %s %0h", p, x.wr ? "W" : "R", x.pva));
    end
  end
  tr_done_cyc[p] = cyc;
  tr_thr_done[p] = 1'b1;
endtask

task automatic trace_events(input longint unsigned t_start);
  logic [7:0] rc;
  foreach (tr_evt[i]) begin
    while ((cyc - t_start) < tr_evt[i].cyc) tick();
    case (tr_evt[i].kind)
      0: begin
        cmd_rc(CMD_MIGRATE, tr_idx[tr_evt[i].a], tr_gen[tr_evt[i].a], tr_evt[i].b, 0, rc);
        if (rc == RC_OK) tr_mig_ok++; else tr_mig_refused++;
      end
      1: wr(R_CTRL, tr_evt[i].a);
      default: ;
    endcase
  end
  tr_evt_done = 1'b1;
endtask

task automatic run_trace(input string file);
  int fd, r, a, b, c, d2, e2, f2;
  string tok, nm, rw, line;
  longint pa;
  logic [31:0] hx;
  logic [7:0] rc, gen;
  int idx;
  int pol_epoch = 8192, pol_hot_min = 4, pol_decay = 1, pol_cool = 4, pol_horizon = 16, pol_cost_gran = 1100, pol_cost_chunk = 400, pol_delta = 11, pol_margin = 1, pol_hyst = 8, pol_highwm = G0;
  int n_acc;
  longint unsigned t_start, t_end;
  bit any_dom;
  cur_test = "TRACE";
  hw_reset(); tb_state_reset();
  tr_all.delete();
  for (int p = 0; p < NPT; p++) tr_cnt[p] = 0;
  tr_evt.delete(); tr_idx.delete(); tr_gen.delete(); tr_pva.delete(); tr_len.delete(); tr_dom.delete(); tr_live.delete();
  for (int k = 0; k < 8; k++) lat_hist[k] = 0;
  tr_mig_ok = 0; tr_mig_refused = 0; n_acc = 0; any_dom = 1'b0;
  fd = $fopen(file, "r");
  chk(fd != 0, $sformatf("cannot open trace %s", file));
  if (fd == 0) return;
  while (!$feof(fd)) begin
    r = $fscanf(fd, "%s", tok);
    if (r != 1) break;
    if (tok.len() == 0) continue;
    if (tok[0] == "#") begin r = $fgets(line, fd); continue; end
    case (tok)
      "CTRL":   begin r = $fscanf(fd, "%h", hx); wr(R_CTRL, hx); end
      "MIGCTL": begin r = $fscanf(fd, "%d %d %d", a, b, c); wr(R_MIG_CTL, {8'd0, 8'(c), 8'(b), 8'(a)}); end
      "POL": begin
        r = $fscanf(fd, "%s %d", nm, a);
        case (nm)
          "epoch": pol_epoch = a;  "hot_min": pol_hot_min = a;  "decay": pol_decay = a;  "cooldown": pol_cool = a;  "horizon": pol_horizon = a;
          "cost_gran": pol_cost_gran = a;  "cost_chunk": pol_cost_chunk = a;  "delta": pol_delta = a;  "margin": pol_margin = a;  "hyst": pol_hyst = a;
          "highwm": pol_highwm = a;
          default: chk(0, $sformatf("unknown POL key %s", nm));
        endcase
      end
      "DOM": begin r = $fscanf(fd, "%d %d %d", a, b, c); dom_set(a, b, c != 0, 1'b1, rc); chk(rc == RC_OK, $sformatf("DOM_SET %0d rc=%0h", a, rc)); any_dom = 1'b1; end
      "BIND": begin r = $fscanf(fd, "%d %d", a, b); cmd_rc(CMD_BIND, a, b, 0, 0, rc); chk(rc == RC_OK, "BIND"); end
      "REG": begin
        r = $fscanf(fd, "%d %d %h %d %d %d %d", a, b, pa, c, d2, e2, f2);
        if (!any_dom) begin setup_domains(65535, 1'b0); any_dom = 1'b1; end
        do_alloc(b, pa, c, d2, e2[0], e2[1], f2 != 0, rc, idx, gen);
        chk(rc == RC_OK, $sformatf("trace REG %0d rc=%0h", a, rc));
        tr_idx[a] = idx; tr_gen[a] = gen; tr_pva[a] = pa; tr_len[a] = c; tr_dom[a] = b; tr_live[a] = 1'b1;
      end
      "FREE": begin r = $fscanf(fd, "%d", a); do_free(tr_idx[a], tr_gen[a], tr_pva[a], tr_len[a], rc); chk(rc == RC_OK, "trace FREE"); tr_live[a] = 1'b0; end
      "A": begin
        r = $fscanf(fd, "%d %d %s %h", a, b, rw, pa);
        begin acc_t x; x.port = a; x.gap = b; x.wr = (rw == "W"); x.pva = pa; tr_all.push_back(x); tr_cnt[a]++; n_acc++; end
      end
      "EVT": begin
        evt_t ev;
        r = $fscanf(fd, "%d %s", a, nm);
        ev.cyc = a;
        if (nm == "MIG")       begin r = $fscanf(fd, "%d %d", b, c); ev.kind = 0; ev.a = b; ev.b = c; end
        else if (nm == "CTRL") begin r = $fscanf(fd, "%h", hx); ev.kind = 1; ev.a = int'(hx); ev.b = 0; end
        else chk(0, $sformatf("unknown EVT %s", nm));
        tr_evt.push_back(ev);
      end
      default: chk(0, $sformatf("unknown trace token '%s'", tok));
    endcase
  end
  $fclose(fd);
  pol_cfg(pol_epoch, pol_hot_min, pol_decay, pol_cool, pol_horizon, pol_cost_gran, pol_cost_chunk, pol_delta, pol_margin, pol_hyst, pol_highwm);
  // ---- timed run
  tb_state_reset_counters();
  snap_g();
  t_start = cyc;
  // one explicit branch per possible port (constants only: no variable captured by a forked process)
  fork
    if (0 < NPT) trace_port(0);
    if (1 < NPT) trace_port(1);
    if (2 < NPT) trace_port(2);
    if (3 < NPT) trace_port(3);
    if (4 < NPT) trace_port(4);
    if (5 < NPT) trace_port(5);
    if (6 < NPT) trace_port(6);
    if (7 < NPT) trace_port(7);
    if (8 < NPT) trace_port(8);
    trace_events(t_start);
  join
  t_end = 0; for (int p = 0; p < NPT; p++) if (tr_done_cyc[p] > t_end && tr_cnt[p] > 0) t_end = tr_done_cyc[p];
  while (mig_busy_o) tick();
  // ---- report
  begin
    longint unsigned tot_ops;
    tot_ops = 0; for (int p = 0; p < NPT; p++) tot_ops += ok_acc[p];
    $display("REPORT total_cycles %0d", t_end - t_start);
    $display("REPORT tb_ops %0d", tot_ops);
    $display("REPORT tb_lat_sum %0d", lat_sum_tb);
    $display("REPORT tb_lat_max %0d", lat_max_tb);
    for (int p = 0; p < NPT; p++) if (tr_cnt[p] > 0) $display("REPORT port%0d_done_cycle %0d", p, tr_done_cyc[p] - t_start);
    for (int k = 0; k < 8; k++) $display("REPORT hist%0d %0d", k, lat_hist[k]);
    $display("REPORT mig_cmd_ok %0d", tr_mig_ok);
    $display("REPORT mig_cmd_refused %0d", tr_mig_refused);
    snap_g();
    for (int k = 0; k < NG; k++) $display("REPORT g%0d %0d", k, snap[k]);
    begin longint unsigned v; for (int dd = 0; dd < ND; dd++) for (int k = 0; k < NDC; k++) begin cnt_d(dd, k, v); $display("REPORT d%0d_%0d %0d", dd, k, v); end end
    begin logic [31:0] v; rd(R_GLAT_MAX, v); $display("REPORT lat_max_dut %0d", v); rd(R_SRAM_PEAK, v); $display("REPORT sram_peak %0d", v); rd(R_DRAM_PEAK, v); $display("REPORT dram_peak %0d", v);
      rd(R_POL_COSTEST, v); $display("REPORT cost_est %0d", v); end
    $display("REPORT dram_row_hit %0d", dram.st_row_hit); $display("REPORT dram_row_closed %0d", dram.st_row_closed);
    $display("REPORT dram_row_conf %0d", dram.st_row_conf); $display("REPORT dram_refresh %0d", dram.st_refresh);
    $display("REPORT dram_reads %0d", dram.st_reads); $display("REPORT dram_writes %0d", dram.st_writes);
    $display("REPORT commits_checked %0d", mig_commits_seen);
    $display("REPORT cfg_sram_bytes %0d", SRAM_BYTES); $display("REPORT cfg_dram_bytes %0d", DRAM_BYTES); $display("REPORT cfg_dw %0d", DW);
    $display("REPORT cfg_mig_ch %0d", MIG_CH); $display("REPORT cfg_gran %0d", GRAN); $display("REPORT cfg_nd %0d", ND);
  end
  // ---- final integrity sweep of every live region (stopped policy first so nothing moves underneath)
  wr(R_CTRL, 32'b0110);
  repeat (50) tick();
  foreach (tr_live[k]) if (tr_live[k]) sweep_range(tr_dom[k], tr_pva[k], tr_len[k]);
endtask
task automatic tb_state_reset_counters();
  for (int p = 0; p < NPT; p++) begin ok_acc[p] = 0; flt_acc[p] = 0; tr_done_cyc[p] = 0; end
  ok_bytes_rd = 0; ok_bytes_wr = 0; lat_sum_tb = 0; lat_cnt_tb = 0; lat_max_tb = 0;
endtask

function automatic bit sel(input string which, input string name);
  // "all", a single test name, or a comma-separated list
  string rest, tok;
  int c;
  if (which == "all") return 1'b1;
  rest = which;
  forever begin
    c = -1;
    for (int k = 0; k < rest.len(); k++) if (rest[k] == ",") begin c = k; break; end
    tok = (c < 0) ? rest : rest.substr(0, c - 1);
    if (tok == name) return 1'b1;
    if (c < 0) return 1'b0;
    rest = rest.substr(c + 1, rest.len() - 1);
  end
endfunction
task automatic run_tests(input string which);
  if (which == "trace") begin string tf; if (!$value$plusargs("trace=%s", tf)) begin chk(0, "+trace=<file> required"); end else run_trace(tf); return; end
  if (sel(which, "t01")) t01_alloc_free();
  if (sel(which, "t02")) t02_overlap();
  if (sel(which, "t03")) t03_perms();
  if (sel(which, "t04")) t04_migrate();
  if (sel(which, "t05")) t05_dirty();
  if (sel(which, "t06")) t06_reset();
  if (sel(which, "t07")) t07_concurrent();
  if (sel(which, "t08")) t08_exhaust();
  if (sel(which, "t09")) t09_backpressure();
  if (sel(which, "t10")) t10_isolation();
  if (sel(which, "t11")) t11_faults();
  if (sel(which, "t12")) t12_policy();
endtask
