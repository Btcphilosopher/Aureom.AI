// =============================================================================
// MemoryPool :: tb_pool -- system testbench
//
//   DUT  silicaflux_memory_pool  (real RTL, including the vendored CloudDMA and SRAM library cell)
//   MEM  sfmp_dram_model         (MODELLED external DRAM tier; fault injection)
//
// Timing discipline: every TB output changes 1 ns after a clock edge; every sample is taken on the falling edge
// (mid-cycle, stable).  Handshakes therefore happen at the following rising edge.
//
// What is checked, independently of the RTL:
//   GOLDEN   byte-accurate model of the data every client has written (keyed by PVA, so it is invariant under
//            migration): every read is compared with it.
//   MONITORS (always on) region PVA ranges never overlap; every live region's physical extent is reserved in the
//            allocator bitmap and no two live extents overlap; occupancy == bitmap popcount; tier-port requests
//            are held stable until accepted (SFB2 R2); no stage-1 dispatch into a FROZEN region; and AT EVERY
//            MIGRATION COMMIT the destination memory equals the source memory byte for byte (backdoor read),
//            with nothing in flight and nothing dirty -- i.e. partially copied memory is never committed.
//   COUNTERS the DUT's telemetry counters (read through the register page) are cross-checked against counts the
//            testbench derived from the transactions it issued.
// Prints "TB RESULT PASS" / "TB RESULT FAIL"; the regression runner requires the PASS line.
// =============================================================================
`timescale 1ns/1ps

module tb_pool;
  import sfmp_pkg::*;

  parameter int ND         = 4;
  parameter int NR         = 32;
  parameter int DW         = 32;
  parameter int GRAN_LG    = 8;
  parameter int POOL_AW    = 28;
  parameter int SRAM_BYTES = 65536;
  parameter int DRAM_BYTES = 262144;
  parameter int MAXG       = 64;
  parameter int CHUNK_LG   = 6;
  parameter int MIG_CH     = 1;
  parameter int RQ         = 4;
  parameter int EM_OUT     = 4;
  parameter int T_REFI     = 3900;

  localparam int NPT   = ND + 1;
  localparam int DWB   = DW / 8;
  localparam int GRAN  = 1 << GRAN_LG;
  localparam int G0    = SRAM_BYTES >> GRAN_LG;
  localparam int G1    = DRAM_BYTES >> GRAN_LG;
  localparam longint DOMSZ = 64'd1 << 20;          // 1 MiB managed window per domain

  // ------------------------------------------------------------------ clock / reset / DUT
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;
  longint unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  logic        rb_sel, rb_we, rb_priv;
  logic [11:0] rb_addr;
  logic [31:0] rb_wdata, rb_rdata;
  logic        rb_err;

  logic            cv [NPT];
  logic            cw [NPT];
  logic [31:0]     ca [NPT];
  logic [DW-1:0]   cd [NPT];
  logic [DWB-1:0]  cs [NPT];
  logic            crr[NPT];
  logic [NPT-1:0]  c_req_valid, c_req_ready, c_req_write, c_rsp_valid, c_rsp_ready, c_rsp_err;
  logic [NPT*32-1:0]  c_req_addr;
  logic [NPT*DW-1:0]  c_req_wdata, c_rsp_rdata;
  logic [NPT*DWB-1:0] c_req_wstrb;
  logic [NPT*8-1:0]   c_rsp_code;
  logic [3:0] hd_dom;
  logic       hd_xlat_ok;
  generate
    for (genvar p = 0; p < NPT; p++) begin : g_cli
      assign c_req_valid[p] = cv[p];
      assign c_req_write[p] = cw[p];
      assign c_req_addr[p*32 +: 32] = ca[p];
      assign c_req_wdata[p*DW +: DW] = cd[p];
      assign c_req_wstrb[p*DWB +: DWB] = cs[p];
      assign c_rsp_ready[p] = crr[p];
    end
  endgenerate

  logic        em_req_valid, em_req_ready, em_req_write, em_rsp_valid, em_rsp_ready, em_rsp_error;
  logic [31:0] em_req_addr;
  logic [DW-1:0] em_req_wdata, em_rsp_rdata;
  logic [DWB-1:0] em_req_wstrb;
  logic        ras_ev_valid, irq_event, irq_fault, mig_busy_o;
  logic [3:0]  ras_ev_type;
  logic [31:0] ras_ev_addr, ras_ev_info;

  logic              inj_corrupt_en, inj_corrupt_once, inj_err_en, inj_stall_en;
  logic [31:0]       inj_corrupt_lo, inj_corrupt_hi, inj_err_lo, inj_err_hi;
  logic [DW-1:0]     inj_corrupt_mask;

  silicaflux_memory_pool #(
    .NUM_DOMAINS(ND), .NUM_REGIONS(NR), .DATA_WIDTH(DW), .GRAN_LG(GRAN_LG), .POOL_AW(POOL_AW), .SRAM_BYTES(SRAM_BYTES),
    .DRAM_BYTES(DRAM_BYTES), .MAX_REGION_GRAN(MAXG), .CHUNK_LG(CHUNK_LG), .MIG_CH(MIG_CH), .RQ_DEPTH(RQ), .EM_OUT(EM_OUT)
  ) dut (
    .clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_priv, .rb_rdata, .rb_err,
    .c_req_valid, .c_req_ready, .c_req_write, .c_req_addr, .c_req_wdata, .c_req_wstrb,
    .c_rsp_valid, .c_rsp_ready, .c_rsp_rdata, .c_rsp_err, .c_rsp_code,
    .hd_dom, .hd_xlat_ok,
    .em_req_valid, .em_req_ready, .em_req_write, .em_req_addr, .em_req_wdata, .em_req_wstrb,
    .em_rsp_valid, .em_rsp_ready, .em_rsp_rdata, .em_rsp_error,
    .ras_ev_valid, .ras_ev_type, .ras_ev_addr, .ras_ev_info, .irq_event, .irq_fault, .mig_busy_o
  );

  sfmp_dram_model #(.DW(DW), .BYTES(DRAM_BYTES), .MAXOUT(EM_OUT), .T_REFI(T_REFI)) dram (
    .clk, .rst_n, .req_valid(em_req_valid), .req_ready(em_req_ready), .req_write(em_req_write), .req_addr(em_req_addr),
    .req_wdata(em_req_wdata), .req_wstrb(em_req_wstrb), .rsp_valid(em_rsp_valid), .rsp_ready(em_rsp_ready),
    .rsp_rdata(em_rsp_rdata), .rsp_error(em_rsp_error),
    .inj_corrupt_en, .inj_corrupt_lo, .inj_corrupt_hi, .inj_corrupt_mask, .inj_corrupt_once, .inj_err_en, .inj_err_lo, .inj_err_hi, .inj_stall_en
  );

  // ------------------------------------------------------------------ check bookkeeping
  int checks = 0;
  int errors = 0;
  string cur_test = "-";
  function automatic void chk(input bit c, input string m);
    checks++;
    if (!c) begin
      errors++;
      if (errors <= 40) $display("[%0t] FAIL (%s): %s", $time, cur_test, m);
    end
  endfunction

  task automatic tick(); @(posedge clk); #1; endtask

  // checks made by the always-on monitors are counted separately from the explicit test assertions
  int mon_checks = 0;
  function automatic void mchk(input bit c, input string m);
    mon_checks++;
    if (!c) begin
      errors++;
      if (errors <= 40) $display("[%0t] FAIL (%s) [monitor]: %s", $time, cur_test, m);
    end
  endfunction
  bit mon_commit_en = 1'b1;                  // negative-control tests switch the commit-time comparison to count-only
  longint unsigned neg_ctrl_bytes = 0;

  // RAS event capture (one event per cycle at most)
  int ras_cnt [16];
  logic [3:0]  ras_last_type;
  logic [31:0] ras_last_addr, ras_last_info;
  always @(negedge clk) if (rst_n && ras_ev_valid) begin
    ras_cnt[ras_ev_type]++; ras_last_type = ras_ev_type; ras_last_addr = ras_ev_addr; ras_last_info = ras_ev_info;
  end

  // ------------------------------------------------------------------ register page driver
  task automatic reg_wr(input logic [11:0] a, input logic [31:0] d, input bit priv, output bit err);
    rb_sel = 1'b1; rb_we = 1'b1; rb_addr = a; rb_wdata = d; rb_priv = priv;
    @(negedge clk); err = rb_err;
    tick();
    rb_sel = 1'b0; rb_we = 1'b0; rb_priv = 1'b0;
  endtask
  task automatic reg_rd(input logic [11:0] a, input bit priv, output logic [31:0] d, output bit err);
    rb_sel = 1'b1; rb_we = 1'b0; rb_addr = a; rb_priv = priv;
    @(negedge clk); d = rb_rdata; err = rb_err;
    tick();
    rb_sel = 1'b0; rb_priv = 1'b0;
  endtask
  task automatic wr(input logic [11:0] a, input logic [31:0] d);
    bit e; reg_wr(a, d, 1'b1, e);
    chk(!e, $sformatf("privileged write to %03h refused", a));
  endtask
  task automatic rd(input logic [11:0] a, output logic [31:0] d);
    bit e; reg_rd(a, 1'b1, d, e);
    chk(!e, $sformatf("privileged read of %03h refused", a));
  endtask

  // 64-bit counter read (LO latches HI)
  task automatic cnt_g(input int k, output longint unsigned v);
    logic [31:0] lo, hi;
    rd(R_G_BASE + 12'(k * 8), lo);
    rd(R_G_BASE + 12'(k * 8 + 4), hi);
    v = {hi, lo};
  endtask
  task automatic cnt_d(input int d, input int k, output longint unsigned v);
    logic [31:0] lo, hi;
    wr(R_DSEL, d);
    rd(R_D_BASE + 12'(k * 8), lo);
    rd(R_D_BASE + 12'(k * 8 + 4), hi);
    v = {hi, lo};
  endtask
  longint unsigned snap [NG];                              // counter snapshot (see snap_g)
  task automatic snap_g();
    for (int k = 0; k < NG; k++) cnt_g(k, snap[k]);
  endtask

  // ------------------------------------------------------------------ management commands
  task automatic mcmd(input logic [7:0] c, input logic [31:0] a0, input logic [31:0] a1, input logic [31:0] a2, input logic [31:0] a3,
                      output logic [7:0] rc, output int idx, output logic [7:0] gen, output logic [31:0] r0, output logic [31:0] r1);
    logic [31:0] st;
    bit e;
    wr(R_CMD_ARG0, a0); wr(R_CMD_ARG1, a1); wr(R_CMD_ARG2, a2); wr(R_CMD_ARG3, a3);
    wr(R_CMD, {24'd0, c});
    st = '0;
    for (int i = 0; i < 400000; i++) begin
      reg_rd(R_CMD_STATUS, 1'b1, st, e);
      if (st[1]) break;
    end
    chk(st[1], $sformatf("command %02h did not complete", c));
    rc = st[15:8]; idx = int'(st[20:16]); gen = st[31:24];
    rd(R_CMD_RES0, r0); rd(R_CMD_RES1, r1);
  endtask
  // short forms returning only the result code
  task automatic cmd_rc(input logic [7:0] c, input logic [31:0] a0, input logic [31:0] a1, input logic [31:0] a2, input logic [31:0] a3, output logic [7:0] rc);
    int idx; logic [7:0] gen; logic [31:0] r0, r1;
    mcmd(c, a0, a1, a2, a3, rc, idx, gen, r0, r1);
  endtask

  // ------------------------------------------------------------------ golden memory (byte accurate, keyed by PVA)
  byte unsigned gm [longint];
  function automatic bit gm_all(input longint a);       // are all bytes of the beat at `a` known?
    bit k = 1'b1;
    for (int b = 0; b < DWB; b++) if (!gm.exists(a + b)) k = 1'b0;
    gm_all = k;
  endfunction
  task automatic gm_zero(input longint a, input longint n);
    for (longint i = 0; i < n; i++) gm[a + i] = 8'h00;
  endtask
  task automatic gm_forget(input longint a, input longint n);
    for (longint i = 0; i < n; i++) if (gm.exists(a + i)) gm.delete(a + i);
  endtask
  function automatic logic [DW-1:0] gm_word(input longint a);
    logic [DW-1:0] w;
    w = '0;
    for (int b = 0; b < DWB; b++) w[b*8 +: 8] = gm[a + b];
    gm_word = w;
  endfunction
  function automatic logic [DW-1:0] mkdata(input longint a, input int unsigned seq);
    logic [DW-1:0] w;
    longint unsigned h;
    w = '0;
    for (int k = 0; k < (DW + 31) / 32; k++) begin
      h = (a * 64'h9E37_79B9_7F4A_7C15) ^ (64'(seq) * 64'hC2B2_AE3D_27D4_EB4F) ^ (64'(k) * 64'h1656_67B1_9E37_79F9);
      h = h ^ (h >> 29); h = h * 64'hBF58_476D_1CE4_E5B9; h = h ^ (h >> 32);
      w[k*32 +: 32] = h[31:0];
    end
    mkdata = w;
  endfunction

  // ------------------------------------------------------------------ client port primitives (blocking, one access)
  int unsigned seq_ctr = 0;
  longint unsigned ok_acc [NPT];         // completed successful accesses per port (TB-side count)
  longint unsigned ok_bytes_rd, ok_bytes_wr;
  longint unsigned flt_acc [NPT];
  longint unsigned lat_sum_tb, lat_cnt_tb, lat_max_tb;

  task automatic xfer(input int p, input bit w, input longint pva, input logic [DW-1:0] wd, input logic [DWB-1:0] ws,
                      output logic [DW-1:0] rdat, output bit err, output logic [7:0] code);
    longint unsigned t0;
    cv[p] = 1'b1; cw[p] = w; ca[p] = 32'(pva); cd[p] = wd; cs[p] = ws;
    do @(negedge clk); while (!c_req_ready[p]);
    tick();                                   // accepted at this edge
    cv[p] = 1'b0;
    t0 = cyc;
    do @(negedge clk); while (!c_rsp_valid[p]);
    rdat = c_rsp_rdata[p*DW +: DW]; err = c_rsp_err[p]; code = c_rsp_code[p*8 +: 8];
    lat_sum_tb += (cyc - t0); lat_cnt_tb++;
    if ((cyc - t0) > lat_max_tb) lat_max_tb = cyc - t0;
    tick();                                   // response popped at this edge (crr = 1)
    if (err) flt_acc[p]++;
    else begin
      ok_acc[p]++;
      if (w) begin for (int b = 0; b < DWB; b++) if (ws[b]) ok_bytes_wr++; end
      else   ok_bytes_rd += DWB;
    end
  endtask

  // write a beat and update the golden model on success
  task automatic cwr(input int p, input longint pva, input logic [DW-1:0] wd, input logic [DWB-1:0] ws, output bit err, output logic [7:0] code);
    logic [DW-1:0] rd_unused;
    xfer(p, 1'b1, pva, wd, ws, rd_unused, err, code);
    if (!err) for (int b = 0; b < DWB; b++) if (ws[b]) gm[pva + b] = wd[b*8 +: 8];
  endtask
  // read a beat; if the golden model knows every byte, compare
  task automatic crd(input int p, input longint pva, output logic [DW-1:0] rdat, output bit err, output logic [7:0] code);
    logic [DW-1:0] unused_wd;
    unused_wd = '0;
    xfer(p, 1'b0, pva, unused_wd, '0, rdat, err, code);
    if (!err && gm_all(pva)) chk(rdat === gm_word(pva), $sformatf("port %0d read %0h: got %h expected %h", p, pva, rdat, gm_word(pva)));
  endtask
  // full-word write with fresh data
  task automatic wr_full(input int p, input longint pva, output bit err);
    logic [7:0] code;
    seq_ctr++;
    cwr(p, pva, mkdata(pva, seq_ctr), {DWB{1'b1}}, err, code);
  endtask
  task automatic rd_chk(input int p, input longint pva, output bit err);
    logic [DW-1:0] r; logic [7:0] code;
    crd(p, pva, r, err, code);
  endtask
  // fill / verify a whole range through port p
  task automatic fill_range(input int p, input longint pva, input int bytes);
    bit e;
    for (int o = 0; o < bytes; o += DWB) begin wr_full(p, pva + o, e); chk(!e, $sformatf("fill write %0h refused", pva + o)); end
  endtask
  task automatic sweep_range(input int p, input longint pva, input int bytes);
    bit e;
    for (int o = 0; o < bytes; o += DWB) begin rd_chk(p, pva + o, e); chk(!e, $sformatf("sweep read %0h refused", pva + o)); end
  endtask

  // ------------------------------------------------------------------ region-table read-out through the register page
  typedef struct { int state, tier, mig, dirty, pin, pr, pw, dom, err, gen; longint pva_b; int len_g, phys_g; longint rdtot, wrtot; } rinfo_t;
  task automatic rinfo(input int idx, output rinfo_t r);
    logic [31:0] w0, v;
    wr(R_RSEL, idx);
    rd(R_RD_W0, w0);
    r.state = w0[1:0]; r.tier = w0[2]; r.mig = w0[4:3]; r.dirty = w0[5]; r.pin = w0[6]; r.pr = w0[7]; r.pw = w0[8];
    r.dom = w0[15:12]; r.err = w0[23:16]; r.gen = w0[31:24];
    rd(R_RD_PVA, v);  r.pva_b = longint'(v) << GRAN_LG;
    rd(R_RD_LEN, v);  r.len_g = int'(v);
    rd(R_RD_PHYS, v); r.phys_g = int'(v);
    rd(R_RD_RDTOT, v); r.rdtot = v;
    rd(R_RD_WRTOT, v); r.wrtot = v;
  endtask

  // ------------------------------------------------------------------ setup helpers
  task automatic hw_reset();
    rst_n = 1'b0;
    for (int p = 0; p < NPT; p++) begin cv[p] = 1'b0; cw[p] = 1'b0; ca[p] = '0; cd[p] = '0; cs[p] = '0; crr[p] = 1'b1; end
    rb_sel = 1'b0; rb_we = 1'b0; rb_addr = '0; rb_wdata = '0; rb_priv = 1'b0;
    hd_dom = '0; hd_xlat_ok = 1'b1;
    inj_corrupt_en = 1'b0; inj_corrupt_once = 1'b0; inj_err_en = 1'b0; inj_stall_en = 1'b0; inj_corrupt_lo = '0; inj_corrupt_hi = '0; inj_err_lo = '0; inj_err_hi = '0; inj_corrupt_mask = '0;
    repeat (4) tick();
    rst_n = 1'b1;
    repeat (3) tick();
  endtask
  task automatic tb_state_reset();
    gm.delete();
    for (int p = 0; p < NPT; p++) begin ok_acc[p] = 0; flt_acc[p] = 0; end
    ok_bytes_rd = 0; ok_bytes_wr = 0; lat_sum_tb = 0; lat_cnt_tb = 0; lat_max_tb = 0;
  endtask
  // domain d: window [d MiB, (d+1) MiB), SRAM quota in granules, enabled
  task automatic dom_set(input int d, input int quota, input bit autoq, input bit en, output logic [7:0] rc);
    cmd_rc(CMD_DOM_SET, d, longint'(d) * DOMSZ, (longint'(d) + 1) * DOMSZ, {14'd0, autoq, en, 16'(quota)}, rc);
  endtask
  task automatic setup_domains(input int quota, input bit autoq);
    logic [7:0] rc;
    for (int d = 0; d < ND; d++) begin dom_set(d, quota, autoq, 1'b1, rc); chk(rc == RC_OK, $sformatf("DOM_SET %0d rc=%0h", d, rc)); end
  endtask
  task automatic fresh(input bit autoq);
    hw_reset();
    tb_state_reset();
    setup_domains(65535, autoq);
  endtask
  // allocate; on success the golden model sees zeros
  task automatic do_alloc(input int dom, input longint pva, input int len, input int pref, input bit r, input bit w, input bit pin,
                          output logic [7:0] rc, output int idx, output logic [7:0] gen);
    logic [31:0] r0, r1;
    mcmd(CMD_ALLOC, dom, pva, len, {27'd0, pin, w, r, 2'(pref)}, rc, idx, gen, r0, r1);
    if (rc == RC_OK) gm_zero(pva, len);
  endtask
  task automatic do_free(input int idx, input logic [7:0] gen, input longint pva, input int len, output logic [7:0] rc);
    cmd_rc(CMD_FREE, idx, gen, 0, 0, rc);
    if (rc == RC_OK) gm_forget(pva, len);
  endtask
  task automatic wait_mig_done(input int timeout_cycles, output logic [31:0] st);
    bit e;
    st = '0;
    for (int i = 0; i < timeout_cycles; i++) begin
      reg_rd(R_MIG_STATUS, 1'b1, st, e);
      if (st[1] && !st[0]) break;
    end
    chk(st[1] && !st[0], "migration did not complete");
  endtask
  // start a migration and wait for it; returns the MIG_STATUS word
  task automatic migrate(input int idx, input logic [7:0] gen, input int dst_tier, output logic [7:0] rc, output logic [31:0] st);
    cmd_rc(CMD_MIGRATE, idx, gen, dst_tier, 0, rc);
    st = '0;
    if (rc == RC_OK) wait_mig_done(4_000_000, st);
  endtask
  function automatic int popc(input logic [4095:0] v, input int n);
    int c = 0;
    for (int i = 0; i < n; i++) c += int'(v[i]);
    popc = c;
  endfunction
  function automatic int bm_pop(input int tier);
    logic [4095:0] v;
    v = '0;
    if (tier == 0) v[G0-1:0] = dut.bm0; else v[G1-1:0] = dut.bm1;
    bm_pop = popc(v, (tier == 0) ? G0 : G1);
  endfunction

  // ------------------------------------------------------------------ backdoor memory access (monitors only)
  function automatic logic [7:0] bd_byte(input int tier, input longint a);
    logic [DW-1:0] w;
    if (tier == 0) begin
      w = dut.u_sram.u_sram.u_array.g_generic.u_mem.mem[a / DWB];
      bd_byte = w[(a % DWB) * 8 +: 8];
    end else begin
      bd_byte = dram.mem[a];
    end
  endfunction

  // ------------------------------------------------------------------ always-on monitors
  bit mon_en = 1'b0;
  int mig_commits_seen = 0;
  longint unsigned commit_bytes_checked = 0;
  logic        p0_v, p0_r, p0_w, p1_v, p1_r, p1_w;
  logic [31:0] p0_a, p1_a;
  logic [DW-1:0] p0_d, p1_d;
  logic [DWB-1:0] p0_s, p1_s;
  logic        have_prev = 1'b0;
  always @(negedge clk) if (!rst_n) have_prev <= 1'b0;

  always @(negedge clk) if (rst_n && mon_en) begin
    // ---- tripwires inside the DUT
    mchk(!dut.u_access.inv_evt, "region table: more than one entry hit (overlap)");
    mchk(!dut.s0_oor, "SRAM tier out-of-range tripwire");
    // ---- SFB2 R2 at both tier ports: a presented request is held, unchanged, until accepted
    if (have_prev) begin
      if (p0_v && !p0_r) mchk(dut.s0_req_valid && dut.s0_req_write === p0_w && dut.s0_req_addr === p0_a && (!p0_w || dut.s0_req_wdata === p0_d) && dut.s0_req_wstrb === p0_s,
                             "tier 0 request withdrawn / changed before acceptance");
      if (p1_v && !p1_r) mchk(em_req_valid && em_req_write === p1_w && em_req_addr === p1_a && (!p1_w || em_req_wdata === p1_d) && em_req_wstrb === p1_s,
                             "tier 1 request withdrawn / changed before acceptance");
    end
    p0_v = dut.s0_req_valid; p0_r = dut.s0_req_ready; p0_w = dut.s0_req_write; p0_a = dut.s0_req_addr; p0_d = dut.s0_req_wdata; p0_s = dut.s0_req_wstrb;
    p1_v = em_req_valid;     p1_r = em_req_ready;     p1_w = em_req_write;     p1_a = em_req_addr;     p1_d = em_req_wdata;     p1_s = em_req_wstrb;
    have_prev = 1'b1;
    // ---- stage-1 dispatch into a frozen region is forbidden
    if (dut.u_access.commit) mchk(dut.u_table.mig_q[dut.u_access.lk_idx] != MG_FROZEN, "access dispatched into a FROZEN region");
    // ---- region PVA ranges never overlap; live extents reserved and disjoint
    for (int a = 0; a < NR; a++) begin
      if (dut.u_table.st_q[a] != RS_FREE) begin
        for (int b = a + 1; b < NR; b++) begin
          if (dut.u_table.st_q[b] != RS_FREE) begin
            mchk(!(longint'(dut.u_table.pva_q[a]) < longint'(dut.u_table.pva_q[b]) + longint'(dut.u_table.len_q[b]) &&
                  longint'(dut.u_table.pva_q[b]) < longint'(dut.u_table.pva_q[a]) + longint'(dut.u_table.len_q[a])),
                $sformatf("regions %0d and %0d overlap in PVA", a, b));
            if (dut.u_table.tier_q[a] == dut.u_table.tier_q[b])
              mchk(!(longint'(dut.u_table.ph_q[a]) < longint'(dut.u_table.ph_q[b]) + longint'(dut.u_table.len_q[b]) &&
                    longint'(dut.u_table.ph_q[b]) < longint'(dut.u_table.ph_q[a]) + longint'(dut.u_table.len_q[a])),
                  $sformatf("regions %0d and %0d overlap physically", a, b));
          end
        end
      end
    end
    // allocator vs table: only at stable points (the allocator walks bits one per cycle; a FREEING region's
    // bits may already be cleared while its slot is still occupied)
    if ((cyc & 15) == 0 && dut.al_idle) begin
      for (int a = 0; a < NR; a++) begin
        if (dut.u_table.st_q[a] == RS_ACTIVE || dut.u_table.st_q[a] == RS_SCRUB) begin
          for (int g = 0; g < int'(dut.u_table.len_q[a]); g++)
            mchk(dut.u_table.tier_q[a] ? dut.bm1[int'(dut.u_table.ph_q[a]) + g] : dut.bm0[int'(dut.u_table.ph_q[a]) + g],
                $sformatf("region %0d extent granule %0d not reserved in the allocator", a, g));
        end
      end
      mchk(int'(dut.occ0) == bm_pop(0), "SRAM occupancy counter != bitmap popcount");
      mchk(int'(dut.occ1) == bm_pop(1), "DRAM occupancy counter != bitmap popcount");
    end
    // ---- AT EVERY COMMIT: destination == source, nothing in flight, nothing dirty, region frozen
    if (dut.mg_op == MGO_COMMIT) begin
      int ri; int st_t; longint sp, dp; int ln;
      ri = int'(dut.mg_idx);
      st_t = int'(dut.u_table.tier_q[ri]);
      sp = longint'(dut.u_table.ph_q[ri]) * GRAN;
      dp = longint'(dut.mg_phys) * GRAN;
      ln = int'(dut.u_table.len_q[ri]) * GRAN;
      mig_commits_seen++;
      mchk(dut.u_table.mig_q[ri] == MG_FROZEN, "commit while the region is not FROZEN");
      mchk(!dut.infl_nz[ri], "commit with an access in flight");
      mchk(dut.u_mig.dirty_q == '0 && dut.u_mig.todo_q == '0, "commit with dirty / pending chunks");
      begin
        int bad; int first;
        bad = 0; first = -1;      // (declaration initialisers in an always block run only once)
        for (int o = 0; o < ln; o++) if (bd_byte(st_t, sp + o) !== bd_byte(1 - st_t, dp + o)) begin bad++; if (first < 0) first = o; end
        if (bad != 0 && mon_commit_en) $display("   commit mismatch detail: region %0d src tier %0d phys %0h dst phys %0h len %0d: first diff at +%0d src=%02h dst=%02h",
                                               ri, st_t, sp, dp, ln, first, bd_byte(st_t, sp + first), bd_byte(1 - st_t, dp + first));
        if (mon_commit_en) mchk(bad == 0, $sformatf("COMMIT with %0d bytes of the destination differing from the source (region %0d)", bad, ri));
        else begin mon_checks++; neg_ctrl_bytes += bad; end
        commit_bytes_checked += ln;
      end
    end
  end

  // optional policy trace (+poldbg): one line per epoch decision
  bit poldbg;
  initial poldbg = $test$plusargs("poldbg");
  always @(posedge clk) if (poldbg && rst_n && dut.u_policy.st_q == 3'd2) begin
    $display("[pol] cyc %0d epoch %0d  bp_v=%0b idx=%0d ben=%0d cost=%0d score=%0d len=%0d | vc_v=%0b vscore=%0d | free=%0d | delta_eff=%0d cost_q=%0d | d_go=%0b",
      cyc, dut.u_policy.epochs_q, dut.u_policy.bp_v, dut.u_policy.bp_idx, dut.u_policy.bp_ben, dut.u_policy.bp_cost, dut.u_policy.bp_score,
      dut.u_policy.bp_len, dut.u_policy.vc_v, dut.u_policy.vc_score, dut.u_policy.free_g, dut.u_policy.delta_eff, dut.u_policy.cost_q, dut.u_policy.d_go);
  end

  // ------------------------------------------------------------------ verification tests are `include`d below
  `include "tb_tests.svh"

  // ------------------------------------------------------------------ main
  string tname;
  initial begin
    for (int k = 0; k < 16; k++) ras_cnt[k] = 0;
    for (int p = 0; p < NPT; p++) begin cv[p] = 1'b0; cw[p] = 1'b0; ca[p] = '0; cd[p] = '0; cs[p] = '0; crr[p] = 1'b1; end
    rb_sel = 1'b0; rb_we = 1'b0; rb_addr = '0; rb_wdata = '0; rb_priv = 1'b0; hd_dom = '0; hd_xlat_ok = 1'b1;
    inj_corrupt_en = 1'b0; inj_corrupt_once = 1'b0; inj_err_en = 1'b0; inj_stall_en = 1'b0; inj_corrupt_lo = '0; inj_corrupt_hi = '0; inj_err_lo = '0; inj_err_hi = '0; inj_corrupt_mask = '0;
    if (!$value$plusargs("test=%s", tname)) tname = "all";
    #1;
    mon_en = 1'b1;
    run_tests(tname);
    $display("tests complete: %0d test assertions + %0d monitor checks, %0d errors, %0d migration commits cross-checked (%0d bytes compared at commit)",
             checks, mon_checks, errors, mig_commits_seen, commit_bytes_checked);
    if (errors == 0 && checks > 0) $display("TB RESULT PASS"); else $display("TB RESULT FAIL");
    $finish;
  end

  initial begin
    #2_000_000_000;
    $display("TB RESULT FAIL (global timeout, test %s)", cur_test);
    $finish;
  end
endmodule
