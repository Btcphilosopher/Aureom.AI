// =============================================================================
// MemoryPool :: tb_mig_guard -- unit bench for sfmp_mig_chan (CloudDMA + per-beat guard + CRC verify)
//
// The channel is wired to the real SRAM tier (sram_sp) and the DRAM model through two tier arbiters.
// Cases:
//   G1  promote chunk DRAM -> SRAM, verified: result ok, data equal, CRC loop exercised
//   G2  demote  chunk SRAM -> DRAM, verified: result ok, data equal
//   G3  persistent corruption of the destination: MR_VERIFY after max_retry+1 attempts, retries counted
//   G4  one-shot corruption: retry succeeds, retry counted
//   G5  GUARD: while a demotion is running the DMA's DRAM-side address register is overwritten with an address
//       OUTSIDE the chunk (hierarchical write -- a stand-in for a corrupted descriptor / a bug upstream):
//       the guard swallows the beat, the channel fails with MR_GUARD, and the bytes outside the chunk are untouched
//   G6  GUARD, SRAM side: same, with the SRAM-side address of a promotion; SRAM outside the chunk untouched
//   G7  DMA error response from the DRAM (inject): MR_DMA
// =============================================================================
`timescale 1ns/1ps

module tb_mig_guard;
  localparam int DW = 32, DWB = 4;
  localparam int CHUNK = 256;
  localparam int SRAM_BYTES = 8192, DRAM_BYTES = 16384;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  task automatic tick(); @(posedge clk); #1; endtask
  int errors = 0, checks = 0;
  function automatic void chk(input bit c, input string m);
    checks++;
    if (!c) begin errors++; if (errors < 20) $display("[%0t] FAIL: %s", $time, m); end
  endfunction

  // channel
  logic start, dir, verify_en, idle, done, fail;
  logic [31:0] dram_addr, sram_addr, len_bytes;
  logic [7:0] max_retry, fail_code;
  logic d_rv, d_rr, d_rw, d_pv, d_pr, d_perr, s_rv, s_rr, s_rw, s_pv, s_pr, s_perr;
  logic [31:0] d_ra, s_ra;
  logic [DW-1:0] d_rwd, s_rwd, d_prd, s_prd;
  logic [DWB-1:0] d_rws, s_rws;
  logic v0_v, v0_r, v0_pv, v0_pe, v1_v, v1_r, v1_pv, v1_pe;
  logic [31:0] v0_a, v1_a, ev_cb, ev_vb;
  logic [DW-1:0] v0_pd, v1_pd;
  logic ev_retry;

  sfmp_mig_chan #(.DW(DW)) dut (
    .clk, .rst_n, .start, .dir, .dram_addr, .sram_addr, .len_bytes, .verify_en, .max_retry, .idle, .done, .fail, .fail_code,
    .d_req_valid(d_rv), .d_req_ready(d_rr), .d_req_write(d_rw), .d_req_addr(d_ra), .d_req_wdata(d_rwd), .d_req_wstrb(d_rws),
    .d_rsp_valid(d_pv), .d_rsp_ready(d_pr), .d_rsp_rdata(d_prd), .d_rsp_err(d_perr),
    .s_req_valid(s_rv), .s_req_ready(s_rr), .s_req_write(s_rw), .s_req_addr(s_ra), .s_req_wdata(s_rwd), .s_req_wstrb(s_rws),
    .s_rsp_valid(s_pv), .s_rsp_ready(s_pr), .s_rsp_rdata(s_prd), .s_rsp_err(s_perr),
    .v0_req_valid(v0_v), .v0_req_ready(v0_r), .v0_req_addr(v0_a), .v0_rsp_valid(v0_pv), .v0_rsp_rdata(v0_pd), .v0_rsp_err(v0_pe),
    .v1_req_valid(v1_v), .v1_req_ready(v1_r), .v1_req_addr(v1_a), .v1_rsp_valid(v1_pv), .v1_rsp_rdata(v1_pd), .v1_rsp_err(v1_pe),
    .ev_copy_bytes(ev_cb), .ev_verify_bytes(ev_vb), .ev_retry
  );

  // tier 0 behind an arbiter (master 0 = DMA SRAM port, master 1 = verify)
  logic [1:0] a0_v, a0_r, a0_w, a0_pv, a0_pr, a0_pe;
  logic [63:0] a0_a; logic [2*DW-1:0] a0_wd, a0_prd; logic [2*DWB-1:0] a0_ws;
  logic t0_v, t0_r, t0_w, t0_pv, t0_pr, t0_pe, t0_oor; logic [31:0] t0_a; logic [DW-1:0] t0_wd, t0_prd; logic [DWB-1:0] t0_ws;
  logic e0a, e0b; logic [7:0] e0c;
  assign a0_v = {v0_v, s_rv}; assign a0_w = {1'b0, s_rw}; assign a0_a = {v0_a, s_ra}; assign a0_wd = {32'd0, s_rwd}; assign a0_ws = {4'd0, s_rws};
  assign {v0_r, s_rr} = a0_r; assign {v0_pv, s_pv} = a0_pv; assign a0_pr = {1'b1, s_pr}; assign {v0_pd, s_prd} = a0_prd; assign {v0_pe, s_perr} = a0_pe;
  sfmp_tier_arb #(.NM(2), .DW(DW), .MAXOUT(4)) arb0 (.clk, .rst_n,
    .m_req_valid(a0_v), .m_req_ready(a0_r), .m_req_write(a0_w), .m_req_addr(a0_a), .m_req_wdata(a0_wd), .m_req_wstrb(a0_ws),
    .m_rsp_valid(a0_pv), .m_rsp_ready(a0_pr), .m_rsp_rdata(a0_prd), .m_rsp_err(a0_pe),
    .s_req_valid(t0_v), .s_req_ready(t0_r), .s_req_write(t0_w), .s_req_addr(t0_a), .s_req_wdata(t0_wd), .s_req_wstrb(t0_ws),
    .s_rsp_valid(t0_pv), .s_rsp_ready(t0_pr), .s_rsp_rdata(t0_prd), .s_rsp_err(t0_pe), .ev_slave_stall(e0a), .ev_tag_stall(e0b), .ev_loss(e0c));
  sfmp_sram_tier #(.DW(DW), .BYTES(SRAM_BYTES)) sram (.clk, .rst_n, .req_valid(t0_v), .req_ready(t0_r), .req_write(t0_w), .req_addr(t0_a),
    .req_wdata(t0_wd), .req_wstrb(t0_ws), .rsp_valid(t0_pv), .rsp_ready(t0_pr), .rsp_rdata(t0_prd), .rsp_err(t0_pe), .oor_evt(t0_oor));

  // tier 1 behind an arbiter (master 0 = DMA DRAM port, master 1 = verify)
  logic [1:0] a1_v, a1_r, a1_w, a1_pv, a1_pr, a1_pe;
  logic [63:0] a1_a; logic [2*DW-1:0] a1_wd, a1_prd; logic [2*DWB-1:0] a1_ws;
  logic t1_v, t1_r, t1_w, t1_pv, t1_pr, t1_pe; logic [31:0] t1_a; logic [DW-1:0] t1_wd, t1_prd; logic [DWB-1:0] t1_ws;
  logic e1a, e1b; logic [7:0] e1c;
  assign a1_v = {v1_v, d_rv}; assign a1_w = {1'b0, d_rw}; assign a1_a = {v1_a, d_ra}; assign a1_wd = {32'd0, d_rwd}; assign a1_ws = {4'd0, d_rws};
  assign {v1_r, d_rr} = a1_r; assign {v1_pv, d_pv} = a1_pv; assign a1_pr = {1'b1, d_pr}; assign {v1_pd, d_prd} = a1_prd; assign {v1_pe, d_perr} = a1_pe;
  sfmp_tier_arb #(.NM(2), .DW(DW), .MAXOUT(4)) arb1 (.clk, .rst_n,
    .m_req_valid(a1_v), .m_req_ready(a1_r), .m_req_write(a1_w), .m_req_addr(a1_a), .m_req_wdata(a1_wd), .m_req_wstrb(a1_ws),
    .m_rsp_valid(a1_pv), .m_rsp_ready(a1_pr), .m_rsp_rdata(a1_prd), .m_rsp_err(a1_pe),
    .s_req_valid(t1_v), .s_req_ready(t1_r), .s_req_write(t1_w), .s_req_addr(t1_a), .s_req_wdata(t1_wd), .s_req_wstrb(t1_ws),
    .s_rsp_valid(t1_pv), .s_rsp_ready(t1_pr), .s_rsp_rdata(t1_prd), .s_rsp_err(t1_pe), .ev_slave_stall(e1a), .ev_tag_stall(e1b), .ev_loss(e1c));
  logic inj_c_en, inj_c_once, inj_e_en;
  logic [31:0] inj_c_lo, inj_c_hi, inj_e_lo, inj_e_hi;
  logic [DW-1:0] inj_mask;
  sfmp_dram_model #(.DW(DW), .BYTES(DRAM_BYTES), .MAXOUT(4), .REFRESH_EN(1'b0)) dram (.clk, .rst_n,
    .req_valid(t1_v), .req_ready(t1_r), .req_write(t1_w), .req_addr(t1_a), .req_wdata(t1_wd), .req_wstrb(t1_ws),
    .rsp_valid(t1_pv), .rsp_ready(t1_pr), .rsp_rdata(t1_prd), .rsp_error(t1_pe),
    .inj_corrupt_en(inj_c_en), .inj_corrupt_lo(inj_c_lo), .inj_corrupt_hi(inj_c_hi), .inj_corrupt_mask(inj_mask), .inj_corrupt_once(inj_c_once),
    .inj_err_en(inj_e_en), .inj_err_lo(inj_e_lo), .inj_err_hi(inj_e_hi), .inj_stall_en(1'b0));

  // backdoor
  function automatic logic [7:0] sb(input int a); logic [DW-1:0] w; w = sram.u_sram.u_array.g_generic.u_mem.mem[a / DWB]; sb = w[(a % DWB) * 8 +: 8]; endfunction
  task automatic sset(input int a, input logic [7:0] v);
    logic [DW-1:0] w; w = sram.u_sram.u_array.g_generic.u_mem.mem[a / DWB]; w[(a % DWB) * 8 +: 8] = v; sram.u_sram.u_array.g_generic.u_mem.mem[a / DWB] = w;
  endtask
  function automatic logic [7:0] pat(input int a, input int salt); pat = 8'((a * 131 + salt * 17 + (a >> 5)) ^ 8'hC3); endfunction

  task automatic run_job(input bit d, input int dram_a, input int sram_a, input bit ver, input int retries, output bit f, output logic [7:0] code);
    int to;
    start = 1'b1; dir = d; dram_addr = dram_a; sram_addr = sram_a; len_bytes = CHUNK; verify_en = ver; max_retry = retries;
    tick(); start = 1'b0;
    to = 0;
    do begin @(negedge clk); to++; end while (!done && to < 200000);
    chk(done, "job did not finish");
    f = fail; code = fail_code;
    tick();
    while (!idle) tick();
  endtask

  initial begin
    bit f; logic [7:0] code; int bad; int unchanged_bad; int ret_seen;
    start = 0; dir = 0; verify_en = 1; max_retry = 2; dram_addr = 0; sram_addr = 0; len_bytes = 0;
    inj_c_en = 0; inj_c_once = 0; inj_e_en = 0; inj_c_lo = 0; inj_c_hi = 0; inj_e_lo = 0; inj_e_hi = 0; inj_mask = 32'h1;
    repeat (4) tick(); rst_n = 1; repeat (3) tick();

    // ---- G1 promote, verified
    for (int i = 0; i < CHUNK; i++) dram.mem[1024 + i] = pat(i, 1);
    run_job(1'b0, 1024, 2048, 1'b1, 2, f, code);
    chk(!f, $sformatf("G1: promotion failed (code %0h)", code));
    bad = 0; for (int i = 0; i < CHUNK; i++) if (sb(2048 + i) !== pat(i, 1)) bad++;
    chk(bad == 0, $sformatf("G1: %0d bytes differ", bad));

    // ---- G2 demote, verified
    for (int i = 0; i < CHUNK; i++) sset(512 + i, pat(i, 2));
    run_job(1'b1, 4096, 512, 1'b1, 2, f, code);
    chk(!f, "G2: demotion failed");
    bad = 0; for (int i = 0; i < CHUNK; i++) if (dram.mem[4096 + i] !== pat(i, 2)) bad++;
    chk(bad == 0, "G2: data differs");

    // ---- G3 persistent corruption of the destination -> MR_VERIFY after max_retry+1 copies
    inj_c_lo = 4096; inj_c_hi = 4096 + CHUNK; inj_c_once = 0; inj_c_en = 1;
    for (int i = 0; i < CHUNK; i++) sset(512 + i, pat(i, 3));
    ret_seen = 0;
    fork
      run_job(1'b1, 4096, 512, 1'b1, 2, f, code);
      begin for (int i = 0; i < 6000; i++) begin @(negedge clk); if (ev_retry) ret_seen++; end end
    join
    inj_c_en = 0;
    chk(f && code == sfmp_pkg::MR_VERIFY, $sformatf("G3: expected MR_VERIFY, got fail=%0b code=%0h", f, code));
    chk(ret_seen == 2, $sformatf("G3: %0d retries seen, expected 2", ret_seen));

    // ---- G4 one-shot corruption -> retry succeeds
    inj_c_en = 0; repeat (3) tick();                                          // let the model re-arm the one-shot injector
    inj_c_lo = 4096; inj_c_hi = 4096 + CHUNK; inj_c_once = 1; inj_c_en = 1;
    ret_seen = 0;
    fork
      run_job(1'b1, 4096, 512, 1'b1, 2, f, code);
      begin for (int i = 0; i < 3000; i++) begin @(negedge clk); if (ev_retry) ret_seen++; end end
    join
    inj_c_en = 0;
    chk(!f, $sformatf("G4: one-shot corruption was not recovered (code %0h)", code));
    chk(ret_seen == 1, $sformatf("G4: %0d retries, expected 1", ret_seen));
    bad = 0; for (int i = 0; i < CHUNK; i++) if (dram.mem[4096 + i] !== pat(i, 3)) bad++;
    chk(bad == 0, "G4: destination wrong after the retry");

    // ---- G5 guard, DRAM side: demotion whose DRAM-side address register is corrupted mid-job
    for (int i = 0; i < 2 * CHUNK; i++) dram.mem[8192 + i] = 8'h5A;          // sentinel pattern around the chunk's window [8192+256, +256)
    for (int i = 0; i < CHUNK; i++) sset(1024 + i, pat(i, 5));
    begin
      byte unsigned snap_stray [CHUNK];
      for (int i = 0; i < CHUNK; i++) snap_stray[i] = dram.mem[8192 + CHUNK + 4096 + i];
      fork
        run_job(1'b1, 8192 + CHUNK, 1024, 1'b1, 2, f, code);
        begin
          repeat (40) @(posedge clk);                                         // some beats are in
          dut.u_dma.haddr_q = 32'(8192 + CHUNK + 4096);                       // corrupted pointer: far outside the chunk
        end
      join
      chk(f && code == sfmp_pkg::MR_GUARD, $sformatf("G5: expected MR_GUARD, got fail=%0b code=%0h", f, code));
      unchanged_bad = 0;
      begin int b1, b2;
        b1 = 0; b2 = 0;
        for (int i = 0; i < CHUNK; i++) if (dram.mem[8192 + i] !== 8'h5A) b1++;                 // before the window
        for (int i = 0; i < CHUNK; i++) if (dram.mem[8192 + CHUNK + 4096 + i] !== snap_stray[i]) b2++;   // the stray target
        $display("  G5: %0d bytes before the window modified, %0d bytes changed at the stray target", b1, b2);
        unchanged_bad = b1 + b2;
      end
      chk(unchanged_bad == 0, "G5: a beat outside the chunk window reached the DRAM");
    end

    // ---- G6 guard, SRAM side: promotion whose SRAM-side address register is corrupted mid-job
    for (int i = 0; i < CHUNK; i++) dram.mem[12288 + i] = pat(i, 6);
    for (int i = 0; i < 4096; i++) sset(4096 + i, 8'hA5);                    // sentinel
    fork
      run_job(1'b0, 12288, 4096 + 512, 1'b1, 2, f, code);
      begin
        repeat (60) @(posedge clk);
        dut.u_dma.saddr_q = 32'(4096 + 512 + 2048);                           // out of the SRAM chunk window
      end
    join
    chk(f && code == sfmp_pkg::MR_GUARD, $sformatf("G6: expected MR_GUARD, got fail=%0b code=%0h", f, code));
    unchanged_bad = 0;
    for (int i = 0; i < 512; i++) if (sb(4096 + i) !== 8'hA5) unchanged_bad++;
    for (int i = 0; i < 2048 - 512; i++) if (sb(4096 + 512 + CHUNK + i) !== 8'hA5 && (4096 + 512 + CHUNK + i) < 4096 + 4096) begin
      // bytes beyond the chunk (up to the stray target) must still be the sentinel
      if ((4096 + 512 + CHUNK + i) < 4096 + 512 + 2048) unchanged_bad++;
    end
    chk(unchanged_bad == 0, "G6: SRAM outside the chunk window was modified");

    // ---- G7 DRAM error response -> MR_DMA
    for (int i = 0; i < CHUNK; i++) dram.mem[2048 + i] = pat(i, 7);
    inj_e_lo = 2048 + 64; inj_e_hi = 2048 + 128; inj_e_en = 1;
    run_job(1'b0, 2048, 6144, 1'b1, 2, f, code);
    inj_e_en = 0;
    chk(f && code == sfmp_pkg::MR_DMA, $sformatf("G7: expected MR_DMA, got fail=%0b code=%0h", f, code));

    $display("%0d checks, %0d errors", checks, errors);
    if (errors == 0) $display("TB RESULT PASS"); else $display("TB RESULT FAIL");
    $finish;
  end
  initial begin #200_000_000; $display("TB RESULT FAIL (timeout)"); $finish; end
endmodule
