# SilicaFlux RAS (Project 26) -- regression results

Generated 2026-11-10 16:58 UTC by `scripts/run_regress.py`.  Tools: Icarus Verilog 12.0, Verilator 5.020 (`--assert -DSFRAS_ASSERT`).

**39 / 39 runs passed.**

| Test | Simulator | Result |
|---|---|---|
| `ecc_sram_k128_bit_lat3` | icarus | PASS |
| `ecc_sram_k128_bit_lat3` | verilator | PASS |
| `ecc_sram_k32_sig_np2` | icarus | PASS |
| `ecc_sram_k32_sig_np2` | verilator | PASS |
| `ecc_sram_k32_word_only` | icarus | PASS |
| `ecc_sram_k32_word_only` | verilator | PASS |
| `ecc_sram_k64_bit` | icarus | PASS |
| `ecc_sram_k64_bit` | verilator | PASS |
| `ecc_sram_k64_none_lat2_pipe` | icarus | PASS |
| `ecc_sram_k64_none_lat2_pipe` | verilator | PASS |
| `ecc_sram_k64_sig` | icarus | PASS |
| `ecc_sram_k64_sig` | verilator | PASS |
| `event_ctrl` | icarus | PASS |
| `event_ctrl` | verilator | PASS |
| `ras_system` | icarus | PASS |
| `ras_system` | verilator | PASS |
| `ras_system_prod` | icarus | PASS |
| `ras_system_prod` | verilator | PASS |
| `secded_k11_invd` | icarus | PASS |
| `secded_k11_invd` | verilator | PASS |
| `secded_k128_invd` | icarus | PASS |
| `secded_k128_invd` | verilator | PASS |
| `secded_k16_invd` | icarus | PASS |
| `secded_k16_invd` | verilator | PASS |
| `secded_k32_inv0` | icarus | PASS |
| `secded_k32_inv0` | verilator | PASS |
| `secded_k32_invd` | icarus | PASS |
| `secded_k32_invd` | verilator | PASS |
| `secded_k57_invd` | icarus | PASS |
| `secded_k57_invd` | verilator | PASS |
| `secded_k64_inv0` | icarus | PASS |
| `secded_k64_inv0` | verilator | PASS |
| `secded_k64_invd` | icarus | PASS |
| `secded_k64_invd` | verilator | PASS |
| `secded_k8_inv0` | icarus | PASS |
| `secded_k8_inv0` | verilator | PASS |
| `secded_k8_invd` | icarus | PASS |
| `secded_k8_invd` | verilator | PASS |
| `sw_cosim` | verilator | PASS |

## Key result lines (first simulator of each test)

### `ecc_sram_k128_bit_lat3`

```
RESULT P1 init: 32 words initialised and read clean
RESULT P2 random traffic: 1312 responses checked
RESULT P3 single-bit: all 138 stored-bit positions corrected (CE events with exact index)
RESULT P4 double-bit: 543 bit pairs detected as UE (err + poison, uncorrected data returned)
RESULT P5 read/write-path injection: 685 injections fired as predicted
RESULT P6 partial writes: RMW on clean / CE / UE / poisoned words as specified (POISON_MODE=2)
RESULT P7 scrub: 8 seeded single-bit errors found, written back and verified; all words clean
RESULT P8 scrub UE: stop policy halted at word 16; continue policy counted it and left it uncorrectable
RESULT P9 stuck-at: CE corrected on read, write-back verified failing -> recovery event (hard_count=1)
RESULT P10 recovery fault: corrupted write-back detected by verify (hard_count=1)
RESULT P11 MBIST: raw 138-bit patterns written/read through the test port; memory re-initialised
RESULT P12 strobes/addresses: no-op and error responses as specified
MEAS mix=rd50_wr50 scrub_interval=off functional_accepts=4000/4000 cycles (1.000/cycle) scrub_reads=0 (0.000/cycle) slowdown=0.0%
MEAS mix=rd50_wr50 scrub_interval=0 functional_accepts=3693/4000 cycles (0.923/cycle) scrub_reads=307 (0.076/cycle) slowdown=7.6%
MEAS mix=rd50_wr50 scrub_interval=16 functional_accepts=3862/4000 cycles (0.965/cycle) scrub_reads=138 (0.034/cycle) slowdown=3.4%
MEAS mix=rd50_wr50 scrub_interval=256 functional_accepts=3986/4000 cycles (0.996/cycle) scrub_reads=14 (0.003/cycle) slowdown=0.3%
MEAS mix=rd50_wr25_rmw25 scrub_interval=off functional_accepts=2022/4000 cycles (0.505/cycle) scrub_reads=0 (0.000/cycle) slowdown=0.0%
MEAS mix=rd50_wr25_rmw25 scrub_interval=0 functional_accepts=1872/4000 cycles (0.468/cycle) scrub_reads=280 (0.070/cycle) slowdown=7.4%
MEAS mix=rd50_wr25_rmw25 scrub_interval=16 functional_accepts=1956/4000 cycles (0.489/cycle) scrub_reads=132 (0.033/cycle) slowdown=3.2%
MEAS mix=rd50_wr25_rmw25 scrub_interval=256 functional_accepts=2019/4000 cycles (0.504/cycle) scrub_reads=14 (0.003/cycle) slowdown=0.1%
RESULT P14 reset during traffic: no spurious response/event, memory re-initialised
tb_ecc_sram K=128 N=138 DEPTH=32 LAT=3 DEC_PIPE=0 POISON_MODE=2 BYTE_EN=1: 27891 responses, 847 events (CE 294, UE 550, poison 3), 1054 scrub responses
PASS tb_ecc_sram
```

### `ecc_sram_k32_sig_np2`

```
RESULT P1 init: 100 words initialised and read clean
RESULT P2 random traffic: 4100 responses checked
RESULT P3 single-bit: all 39 stored-bit positions corrected (CE events with exact index)
RESULT P4 double-bit: 741 bit pairs detected as UE (err + poison, uncorrected data returned)
RESULT P5 read/write-path injection: 784 injections fired as predicted
RESULT P6 partial writes: RMW on clean / CE / UE / poisoned words as specified (POISON_MODE=1)
RESULT P7 scrub: 25 seeded single-bit errors found, written back and verified; all words clean
RESULT P8 scrub UE: stop policy halted at word 50; continue policy counted it and left it uncorrectable
RESULT P9 stuck-at: CE corrected on read, write-back verified failing -> recovery event (hard_count=1)
RESULT P10 recovery fault: corrupted write-back detected by verify (hard_count=1)
RESULT P11 MBIST: raw 39-bit patterns written/read through the test port; memory re-initialised
RESULT P12 strobes/addresses: no-op and error responses as specified
MEAS mix=rd50_wr50 scrub_interval=off functional_accepts=4000/4000 cycles (1.000/cycle) scrub_reads=0 (0.000/cycle) slowdown=0.0%
MEAS mix=rd50_wr50 scrub_interval=0 functional_accepts=3637/4000 cycles (0.909/cycle) scrub_reads=363 (0.090/cycle) slowdown=9.0%
MEAS mix=rd50_wr50 scrub_interval=16 functional_accepts=3852/4000 cycles (0.963/cycle) scrub_reads=148 (0.037/cycle) slowdown=3.7%
MEAS mix=rd50_wr50 scrub_interval=256 functional_accepts=3986/4000 cycles (0.996/cycle) scrub_reads=14 (0.003/cycle) slowdown=0.3%
MEAS mix=rd50_wr25_rmw25 scrub_interval=off functional_accepts=2632/4000 cycles (0.658/cycle) scrub_reads=0 (0.000/cycle) slowdown=0.0%
MEAS mix=rd50_wr25_rmw25 scrub_interval=0 functional_accepts=2390/4000 cycles (0.597/cycle) scrub_reads=346 (0.086/cycle) slowdown=9.1%
MEAS mix=rd50_wr25_rmw25 scrub_interval=16 functional_accepts=2533/4000 cycles (0.633/cycle) scrub_reads=145 (0.036/cycle) slowdown=3.7%
MEAS mix=rd50_wr25_rmw25 scrub_interval=256 functional_accepts=2621/4000 cycles (0.655/cycle) scrub_reads=14 (0.003/cycle) slowdown=0.4%
RESULT P14 reset during traffic: no spurious response/event, memory re-initialised
tb_ecc_sram K=32 N=39 DEPTH=100 LAT=1 DEC_PIPE=0 POISON_MODE=1 BYTE_EN=1: 34654 responses, 864 events (CE 113, UE 751, poison 10), 1543 scrub responses
PASS tb_ecc_sram
```

### `ecc_sram_k32_word_only`

```
RESULT P1 init: 64 words initialised and read clean
RESULT P2 random traffic: 2624 responses checked
RESULT P3 single-bit: all 39 stored-bit positions corrected (CE events with exact index)
RESULT P4 double-bit: 741 bit pairs detected as UE (err + poison, uncorrected data returned)
RESULT P5 read/write-path injection: 784 injections fired as predicted
RESULT P6 partial writes: MW=1 (no byte lanes): only full / empty strobes exist
RESULT P7 scrub: 16 seeded single-bit errors found, written back and verified; all words clean
RESULT P8 scrub UE: stop policy halted at word 32; continue policy counted it and left it uncorrectable
RESULT P9 stuck-at: CE corrected on read, write-back verified failing -> recovery event (hard_count=1)
RESULT P10 recovery fault: corrupted write-back detected by verify (hard_count=1)
RESULT P11 MBIST: raw 39-bit patterns written/read through the test port; memory re-initialised
RESULT P12 strobes/addresses: no-op and error responses as specified
MEAS mix=rd50_wr50 scrub_interval=off functional_accepts=4000/4000 cycles (1.000/cycle) scrub_reads=0 (0.000/cycle) slowdown=0.0%
MEAS mix=rd50_wr50 scrub_interval=0 functional_accepts=3637/4000 cycles (0.909/cycle) scrub_reads=363 (0.090/cycle) slowdown=9.0%
MEAS mix=rd50_wr50 scrub_interval=16 functional_accepts=3852/4000 cycles (0.963/cycle) scrub_reads=148 (0.037/cycle) slowdown=3.7%
MEAS mix=rd50_wr50 scrub_interval=256 functional_accepts=3986/4000 cycles (0.996/cycle) scrub_reads=14 (0.003/cycle) slowdown=0.3%
RESULT P14 reset during traffic: no spurious response/event, memory re-initialised
tb_ecc_sram K=32 N=39 DEPTH=64 LAT=1 DEC_PIPE=0 POISON_MODE=1 BYTE_EN=0: 20841 responses, 848 events (CE 101, UE 747, poison 7), 856 scrub responses
PASS tb_ecc_sram
```

### `ecc_sram_k64_bit`

```
RESULT P1 init: 64 words initialised and read clean
RESULT P2 random traffic: 2624 responses checked
RESULT P3 single-bit: all 73 stored-bit positions corrected (CE events with exact index)
RESULT P4 double-bit: 249 bit pairs detected as UE (err + poison, uncorrected data returned)
RESULT P5 read/write-path injection: 326 injections fired as predicted
RESULT P6 partial writes: RMW on clean / CE / UE / poisoned words as specified (POISON_MODE=2)
RESULT P7 scrub: 16 seeded single-bit errors found, written back and verified; all words clean
RESULT P8 scrub UE: stop policy halted at word 32; continue policy counted it and left it uncorrectable
RESULT P9 stuck-at: CE corrected on read, write-back verified failing -> recovery event (hard_count=1)
RESULT P10 recovery fault: corrupted write-back detected by verify (hard_count=1)
RESULT P11 MBIST: raw 73-bit patterns written/read through the test port; memory re-initialised
RESULT P12 strobes/addresses: no-op and error responses as specified
MEAS mix=rd50_wr50 scrub_interval=off functional_accepts=4000/4000 cycles (1.000/cycle) scrub_reads=0 (0.000/cycle) slowdown=0.0%
MEAS mix=rd50_wr50 scrub_interval=0 functional_accepts=3637/4000 cycles (0.909/cycle) scrub_reads=363 (0.090/cycle) slowdown=9.0%
MEAS mix=rd50_wr50 scrub_interval=16 functional_accepts=3852/4000 cycles (0.963/cycle) scrub_reads=148 (0.037/cycle) slowdown=3.7%
MEAS mix=rd50_wr50 scrub_interval=256 functional_accepts=3986/4000 cycles (0.996/cycle) scrub_reads=14 (0.003/cycle) slowdown=0.3%
MEAS mix=rd50_wr25_rmw25 scrub_interval=off functional_accepts=2639/4000 cycles (0.659/cycle) scrub_reads=0 (0.000/cycle) slowdown=0.0%
MEAS mix=rd50_wr25_rmw25 scrub_interval=0 functional_accepts=2406/4000 cycles (0.601/cycle) scrub_reads=348 (0.087/cycle) slowdown=8.8%
MEAS mix=rd50_wr25_rmw25 scrub_interval=16 functional_accepts=2545/4000 cycles (0.636/cycle) scrub_reads=145 (0.036/cycle) slowdown=3.5%
MEAS mix=rd50_wr25_rmw25 scrub_interval=256 functional_accepts=2632/4000 cycles (0.658/cycle) scrub_reads=14 (0.003/cycle) slowdown=0.2%
RESULT P14 reset during traffic: no spurious response/event, memory re-initialised
tb_ecc_sram K=64 N=73 DEPTH=64 LAT=1 DEC_PIPE=0 POISON_MODE=2 BYTE_EN=1: 31052 responses, 431 events (CE 172, UE 256, poison 3), 1364 scrub responses
PASS tb_ecc_sram
```

### `ecc_sram_k64_none_lat2_pipe`

```
RESULT P1 init: 64 words initialised and read clean
RESULT P2 random traffic: 2624 responses checked
RESULT P3 single-bit: all 72 stored-bit positions corrected (CE events with exact index)
RESULT P4 double-bit: 246 bit pairs detected as UE (err + poison, uncorrected data returned)
RESULT P5 read/write-path injection: 322 injections fired as predicted
RESULT P6 partial writes: RMW on clean / CE / UE / poisoned words as specified (POISON_MODE=0)
RESULT P7 scrub: 16 seeded single-bit errors found, written back and verified; all words clean
RESULT P8 scrub UE: stop policy halted at word 32; continue policy counted it and left it uncorrectable
RESULT P9 stuck-at: CE corrected on read, write-back verified failing -> recovery event (hard_count=1)
RESULT P10 recovery fault: corrupted write-back detected by verify (hard_count=1)
RESULT P11 MBIST: raw 72-bit patterns written/read through the test port; memory re-initialised
RESULT P12 strobes/addresses: no-op and error responses as specified
MEAS mix=rd50_wr50 scrub_interval=off functional_accepts=4000/4000 cycles (1.000/cycle) scrub_reads=0 (0.000/cycle) slowdown=0.0%
MEAS mix=rd50_wr50 scrub_interval=0 functional_accepts=3693/4000 cycles (0.923/cycle) scrub_reads=307 (0.076/cycle) slowdown=7.6%
MEAS mix=rd50_wr50 scrub_interval=16 functional_accepts=3862/4000 cycles (0.965/cycle) scrub_reads=138 (0.034/cycle) slowdown=3.4%
MEAS mix=rd50_wr50 scrub_interval=256 functional_accepts=3986/4000 cycles (0.996/cycle) scrub_reads=14 (0.003/cycle) slowdown=0.3%
MEAS mix=rd50_wr25_rmw25 scrub_interval=off functional_accepts=1972/4000 cycles (0.493/cycle) scrub_reads=0 (0.000/cycle) slowdown=0.0%
MEAS mix=rd50_wr25_rmw25 scrub_interval=0 functional_accepts=1824/4000 cycles (0.456/cycle) scrub_reads=284 (0.071/cycle) slowdown=7.5%
MEAS mix=rd50_wr25_rmw25 scrub_interval=16 functional_accepts=1893/4000 cycles (0.473/cycle) scrub_reads=132 (0.033/cycle) slowdown=4.0%
MEAS mix=rd50_wr25_rmw25 scrub_interval=256 functional_accepts=1960/4000 cycles (0.490/cycle) scrub_reads=14 (0.003/cycle) slowdown=0.6%
RESULT P14 reset during traffic: no spurious response/event, memory re-initialised
tb_ecc_sram K=64 N=72 DEPTH=64 LAT=2 DEC_PIPE=1 POISON_MODE=0 BYTE_EN=1: 28531 responses, 426 events (CE 170, UE 256, poison 0), 1219 scrub responses
PASS tb_ecc_sram
```

### `ecc_sram_k64_sig`

```
RESULT P1 init: 64 words initialised and read clean
RESULT P2 random traffic: 2624 responses checked
RESULT P3 single-bit: all 72 stored-bit positions corrected (CE events with exact index)
RESULT P4 double-bit: 246 bit pairs detected as UE (err + poison, uncorrected data returned)
RESULT P5 read/write-path injection: 322 injections fired as predicted
RESULT P6 partial writes: RMW on clean / CE / UE / poisoned words as specified (POISON_MODE=1)
RESULT P7 scrub: 16 seeded single-bit errors found, written back and verified; all words clean
RESULT P8 scrub UE: stop policy halted at word 32; continue policy counted it and left it uncorrectable
RESULT P9 stuck-at: CE corrected on read, write-back verified failing -> recovery event (hard_count=1)
RESULT P10 recovery fault: corrupted write-back detected by verify (hard_count=1)
RESULT P11 MBIST: raw 72-bit patterns written/read through the test port; memory re-initialised
RESULT P12 strobes/addresses: no-op and error responses as specified
MEAS mix=rd50_wr50 scrub_interval=off functional_accepts=4000/4000 cycles (1.000/cycle) scrub_reads=0 (0.000/cycle) slowdown=0.0%
MEAS mix=rd50_wr50 scrub_interval=0 functional_accepts=3637/4000 cycles (0.909/cycle) scrub_reads=363 (0.090/cycle) slowdown=9.0%
MEAS mix=rd50_wr50 scrub_interval=16 functional_accepts=3852/4000 cycles (0.963/cycle) scrub_reads=148 (0.037/cycle) slowdown=3.7%
MEAS mix=rd50_wr50 scrub_interval=256 functional_accepts=3986/4000 cycles (0.996/cycle) scrub_reads=14 (0.003/cycle) slowdown=0.3%
MEAS mix=rd50_wr25_rmw25 scrub_interval=off functional_accepts=2639/4000 cycles (0.659/cycle) scrub_reads=0 (0.000/cycle) slowdown=0.0%
MEAS mix=rd50_wr25_rmw25 scrub_interval=0 functional_accepts=2406/4000 cycles (0.601/cycle) scrub_reads=348 (0.087/cycle) slowdown=8.8%
MEAS mix=rd50_wr25_rmw25 scrub_interval=16 functional_accepts=2545/4000 cycles (0.636/cycle) scrub_reads=145 (0.036/cycle) slowdown=3.5%
MEAS mix=rd50_wr25_rmw25 scrub_interval=256 functional_accepts=2632/4000 cycles (0.658/cycle) scrub_reads=14 (0.003/cycle) slowdown=0.2%
RESULT P14 reset during traffic: no spurious response/event, memory re-initialised
tb_ecc_sram K=64 N=72 DEPTH=64 LAT=1 DEC_PIPE=0 POISON_MODE=1 BYTE_EN=1: 31038 responses, 426 events (CE 170, UE 256, poison 4), 1364 scrub responses
PASS tb_ecc_sram
```

### `event_ctrl`

```
RESULT E1 severity: hardware minimum severity correct for all 16 type codes (+ watchdog stage 2)
RESULT E2 severity policy: escalation applied, downgrade of FATAL refused
RESULT E3 aggregation: 30 simultaneous events from 5 ports counted exactly; log kept the 4 oldest, 26 reported lost (LOG_OVF)
RESULT E4 counter overflow: 4-bit counters saturate at 15, sticky per-counter and global overflow flags, clear works
RESULT E5 first-error capture: first ERROR-or-worse event frozen (lowest port on a tie), INFO ignored
RESULT E6 sticky status: W1C clears, SEEN_FATAL survives W1C once FATAL_LOCK is set
RESULT E7 reset: counters, log, first error, sticky status and timestamp cleared
PASS tb_event_ctrl
```

### `ras_system`

```
RESULT T1 reset/identification: ID, VERSION, CFG (NP=17), reset values, outputs quiet
RESULT T2 illegal operations: RO/unmapped/unprivileged writes refused with rb_err and logged (reason, offset); WARN -> irq_ctrl only
RESULT T3 FI access control: refused without hardware permission, with a wrong key and for a bad target; unlocked only by KEY1,KEY2
RESULT T4 CE: in-place single-bit fault corrected on an SFB2 read (data intact, rsp_error=0), MEM_CE logged with address 10, bit 5, origin READ; FI armed+fired audited
RESULT T5 UE: double-bit fault answered rsp_error=1 + poison on SFB2, MEM_UE logged (ERROR), first-error capture, irq_ctrl
RESULT T6 DMA containment: DMA aborted with READ_BUS at 0x14; words 0-4 copied, words 5-15 of the destination untouched; MEM_UE + DMA_ERR logged
RESULT T7 injected DMA failure: forced bus error -> DMA_ERR_READ_BUS, DMA_ERR event, injection audited
RESULT T8 timeout: 100-cycle response delay -> one TIMEOUT event (limit 40), transfer completed correctly
RESULT T9 bus parity: corrupted request never executed (local error response), corrupted response delivered with rsp_error; 2 BUS_PARITY events
RESULT T10 UNPROTECTED: a response corrupted between the parity checker and the master is NOT detected (only the injection audit is logged) -- listed as a single point of failure
RESULT T11 scrub: 3 seeded single-bit faults (data + check bit) found, written back, verified; injected write-back fault -> RECOVERY; UE stop policy -> STOPPED_UE at word 40
RESULT T12 aggregation: 12 simultaneous events on 4 ports counted exactly (type + source), logged 6 + lost 6; LOG_THR interrupt asserted / released
RESULT T13 thermal: WARN at 3100, fatal threshold clamped to 3400, FATAL at 3500 -> immediate hardware shutdown, fatal_o/contain_o/irq_host; stale sensor warned; FATAL_LOCK holds fatal_o
RESULT T14 reset during DMA + scrub + locked fatal: all status, counters, log, outputs cleared; memories re-initialised; FI locked
RESULT T15 watchdog: kicks hold it off, lock and key enforced, stage 1 -> ERROR, stage 2 -> FATAL + wdog_reset_req
RESULT T16 FI_LOCK: set-only lock refuses unlock and arm until reset; memory untouched
PASS tb_ras_system
```

### `ras_system_prod`

```
RESULT T1 reset/identification: ID, VERSION, CFG (NP=17), reset values, outputs quiet
RESULT T2 illegal operations: RO/unmapped/unprivileged writes refused with rb_err and logged (reason, offset); WARN -> irq_ctrl only
RESULT PROD: FI_EN=0 build -- unlock and arm refused (4 ILLEGAL_OP events), no injection reached a memory or the bus
PASS tb_ras_system (PROD)
```

### `secded_k11_invd`

```
tb_secded K=11 R=4 N=16 INV=0x3: 2048 encode + 65536 decode vectors, 0 invalid-syndrome UEs
  tag(0 clean,1 single,2 double,3 triple,4 multi,5 exhaustive) x class(NONE,CE,UE):
  tag 5: NONE 2048  CE 32768  UE 30720
PASS tb_secded K=11 INV=0x3
```

### `secded_k128_invd`

```
tb_secded K=128 R=8 N=137 INV=0x3: 660 encode + 48596 decode vectors, 424 invalid-syndrome UEs
  tag(0 clean,1 single,2 double,3 triple,4 multi,5 exhaustive) x class(NONE,CE,UE):
  tag 0: NONE 64  CE 0  UE 0
  tag 1: NONE 0  CE 8768  UE 0
  tag 2: NONE 0  CE 0  UE 37264
  tag 3: NONE 0  CE 1652  UE 348
  tag 4: NONE 0  CE 147  UE 353
PASS tb_secded K=128 INV=0x3
```

### `secded_k16_invd`

```
tb_secded K=16 R=5 N=22 INV=0x3: 65536 encode + 5544 decode vectors, 688 invalid-syndrome UEs
  tag(0 clean,1 single,2 double,3 triple,4 multi,5 exhaustive) x class(NONE,CE,UE):
  tag 0: NONE 52  CE 0  UE 0
  tag 1: NONE 0  CE 1144  UE 0
  tag 2: NONE 0  CE 0  UE 1848
  tag 3: NONE 0  CE 1378  UE 622
  tag 4: NONE 3  CE 158  UE 339
PASS tb_secded K=16 INV=0x3
```

### `secded_k32_inv0`

```
tb_secded K=32 R=6 N=39 INV=0x0: 468 encode + 10988 decode vectors, 719 invalid-syndrome UEs
  tag(0 clean,1 single,2 double,3 triple,4 multi,5 exhaustive) x class(NONE,CE,UE):
  tag 0: NONE 64  CE 0  UE 0
  tag 1: NONE 0  CE 2496  UE 0
  tag 2: NONE 0  CE 0  UE 5928
  tag 3: NONE 0  CE 1366  UE 634
  tag 4: NONE 3  CE 142  UE 355
PASS tb_secded K=32 INV=0x0
```

### `secded_k32_invd`

```
tb_secded K=32 R=6 N=39 INV=0x9: 468 encode + 10988 decode vectors, 697 invalid-syndrome UEs
  tag(0 clean,1 single,2 double,3 triple,4 multi,5 exhaustive) x class(NONE,CE,UE):
  tag 0: NONE 64  CE 0  UE 0
  tag 1: NONE 0  CE 2496  UE 0
  tag 2: NONE 0  CE 0  UE 5928
  tag 3: NONE 0  CE 1392  UE 608
  tag 4: NONE 2  CE 117  UE 381
PASS tb_secded K=32 INV=0x9
```

### `secded_k57_invd`

```
tb_secded K=57 R=6 N=64 INV=0x3: 518 encode + 22788 decode vectors, 0 invalid-syndrome UEs
  tag(0 clean,1 single,2 double,3 triple,4 multi,5 exhaustive) x class(NONE,CE,UE):
  tag 0: NONE 64  CE 0  UE 0
  tag 1: NONE 0  CE 4096  UE 0
  tag 2: NONE 0  CE 0  UE 16128
  tag 3: NONE 0  CE 2000  UE 0
  tag 4: NONE 5  CE 231  UE 264
PASS tb_secded K=57 INV=0x3
```

### `secded_k64_inv0`

```
tb_secded K=64 R=7 N=72 INV=0x0: 532 encode + 27620 decode vectors, 539 invalid-syndrome UEs
  tag(0 clean,1 single,2 double,3 triple,4 multi,5 exhaustive) x class(NONE,CE,UE):
  tag 0: NONE 64  CE 0  UE 0
  tag 1: NONE 0  CE 4608  UE 0
  tag 2: NONE 0  CE 0  UE 20448
  tag 3: NONE 0  CE 1540  UE 460
  tag 4: NONE 4  CE 139  UE 357
PASS tb_secded K=64 INV=0x0
```

### `secded_k64_invd`

```
tb_secded K=64 R=7 N=72 INV=0x3: 532 encode + 27620 decode vectors, 557 invalid-syndrome UEs
  tag(0 clean,1 single,2 double,3 triple,4 multi,5 exhaustive) x class(NONE,CE,UE):
  tag 0: NONE 64  CE 0  UE 0
  tag 1: NONE 0  CE 4608  UE 0
  tag 2: NONE 0  CE 0  UE 20448
  tag 3: NONE 0  CE 1525  UE 475
  tag 4: NONE 2  CE 141  UE 357
PASS tb_secded K=64 INV=0x3
```

### `secded_k8_inv0`

```
tb_secded K=8 R=4 N=13 INV=0x0: 256 encode + 8192 decode vectors, 768 invalid-syndrome UEs
  tag(0 clean,1 single,2 double,3 triple,4 multi,5 exhaustive) x class(NONE,CE,UE):
  tag 5: NONE 256  CE 3328  UE 4608
PASS tb_secded K=8 INV=0x0
```

### `secded_k8_invd`

```
tb_secded K=8 R=4 N=13 INV=0x3: 256 encode + 8192 decode vectors, 768 invalid-syndrome UEs
  tag(0 clean,1 single,2 double,3 triple,4 multi,5 exhaustive) x class(NONE,CE,UE):
  tag 5: NONE 256  CE 3328  UE 4608
PASS tb_secded K=8 INV=0x3
```

### `sw_cosim`

```
RESULT C1 init: ID/VERSION checked, CFG decoded (NEXT=8 NMEM=2 sources=17)
RESULT C2 service: DMA_ERR and MEM_CE decoded field-exact (src, addr, severity, corrected, origin, syndrome, bit), interrupt cleared, first error, counters, timestamp
RESULT C3 overflow: 40 events in 10 cycles -> driver got 13 entries and a lost count of 27; counter exact (40)
RESULT C4 thermal: clamp reported as SFRAS_E_REFUSED; fatal event kept asserted across sfras_service
RESULT C5 watchdog: started locked, kicked, re-configuration refused
RESULT C6 memory: init completed; one-pass scrub of 16 words (passes=1 reads=16)
RESULT C7 fault injection: refused without permission, armed memory (mode/addr/mask exact) and bus (target/mode/delay) targets, refused after sfras_lock_fi
PASS sw_cosim
```

