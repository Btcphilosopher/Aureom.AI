# Lint (Verilator 5.020 `--lint-only -Wall`)

| Top | Parameters | Result |
|---|---|---|
| `sfras_secded_dec` | `-GK=1 -GINV=3` | clean |
| `sfras_secded_dec` | `-GK=8 -GINV=3` | clean |
| `sfras_secded_dec` | `-GK=32 -GINV=3` | clean |
| `sfras_secded_dec` | `-GK=64 -GINV=3` | clean |
| `sfras_secded_dec` | `-GK=128 -GINV=3` | clean |
| `sfras_secded_dec` | `-GK=132 -GINV=3` | clean |
| `sfras_ecc_sram` | `-GFI_EN=1` | clean |
| `sfras_ecc_sram` | `-GFI_EN=0 -GDEC_PIPE=1 -GREAD_LATENCY=2` | clean |
| `sfras_ecc_sram` | `-GPOISON_MODE=1 -GK=32 -GDEPTH=100` | clean |
| `sfras_ecc_sram` | `-GPOISON_MODE=0 -GBYTE_EN=0 -GWRITE_ACK=0` | clean |
| `sfras_ecc_sram` | `-GK=128 -GREAD_LATENCY=3 -GFI_EN=1` | clean |
| `sfras_scrub` | `defaults` | clean |
| `sfras_event_ctrl` | `-GNP=17` | clean |
| `sfras_event_ctrl` | `-GNP=1 -GLOG_DEPTH=2 -GCNT_W=4` | clean |
| `silicaflux_ras` | `defaults` | clean |
| `silicaflux_ras` | `-GNMEM=1 -GNEXT=1 -GNBUS=1 -GFI_EN=0` | clean |
| `silicaflux_ras` | `-GNMEM=8 -GNEXT=5 -GNBUS=8 -GMEM_NW=256` | clean |
| `sfras_sfb_ecc_slave` | `-GFI_EN=1` | clean |
| `sfras_sfb_par_link` | `defaults` | clean |
| `sfras_sfb_fault_inj` | `defaults` | clean |
| `sfras_dma_mon` | `defaults` | clean |
| `sfras_timeout_mon` | `defaults` | clean |
| `sfras_watchdog` | `defaults` | clean |
| `sfras_thermal_mon` | `defaults` | clean |
