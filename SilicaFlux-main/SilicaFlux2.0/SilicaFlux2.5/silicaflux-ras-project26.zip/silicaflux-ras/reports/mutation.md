# Mutation check

Generated 2026-11-10 17:02 UTC by `scripts/run_mutation.py` (Icarus).  Each mutant is one deliberate RTL defect; it is killed when at least one listed test fails.

**22 / 22 mutants killed.**

| Id | File | Defect | Result |
|---|---|---|---|
| M01 | `rtl/sfras_secded_dec.sv` | decoder does not correct data bits | killed: killed by secded_k64_invd |
| M02 | `rtl/sfras_secded_dec.sv` | invalid syndromes treated as correctable | killed: killed by secded_k64_invd |
| M03 | `rtl/sfras_secded_enc.sv` | overall parity of the wrong sense | killed: killed by secded_k8_invd |
| M04 | `rtl/sfras_secded_dec.sv` | invalid syndrome not flagged uncorrectable | killed: killed by secded_k64_invd |
| M05 | `rtl/sfras_ecc_sram.sv` | RMW merges the uncorrected old bytes | killed: killed by ecc_sram_k64_bit |
| M06 | `rtl/sfras_ecc_sram.sv` | port not locked during read-modify-write | killed: killed by ecc_sram_k64_bit |
| M07 | `rtl/sfras_ecc_sram.sv` | RMW onto an uncorrectable word not poisoned | killed: killed by ecc_sram_k64_bit |
| M08 | `rtl/sfras_ecc_sram.sv` | uncorrectable read answered without error | killed: killed by ecc_sram_k64_bit |
| M09 | `rtl/sfras_ecc_sram.sv` | scrub FIX does not write back | killed: killed by ecc_sram_k64_bit |
| M10 | `rtl/sfras_ecc_sram.sv` | re-arm while an injection mask is still in use (bug found during development) | killed: killed by ecc_sram_k128_bit_lat3, ecc_sram_k64_none_lat2_pipe |
| M11 | `rtl/sfras_scrub.sv` | scrub ignores the UE stop policy | killed: killed by ecc_sram_k64_bit |
| M12 | `rtl/sfras_event_ctrl.sv` | counters wrap instead of saturating | killed: killed by event_ctrl |
| M13 | `rtl/sfras_event_ctrl.sv` | software can downgrade severity | killed: killed by event_ctrl |
| M14 | `rtl/sfras_event_ctrl.sv` | lost events not counted | killed: killed by event_ctrl |
| M15 | `rtl/sfras_fi_ctrl.sv` | fault injection ignores the hardware permission and FI_LOCK | killed: killed by ras_system |
| M16 | `rtl/silicaflux_ras.sv` | fatal error does not assert containment | killed: killed by ras_system |
| M17 | `rtl/sfras_bus_parity.sv` | request with bad parity forwarded to the slave | killed: killed by ras_system |
| M18 | `rtl/silicaflux_ras.sv` | fatal thermal threshold not clamped | killed: killed by ras_system |
| M19 | `rtl/sfras_event_ctrl.sv` | watchdog stage 2 not fatal | killed: killed by ras_system |
| M20 | `rtl/sfras_dma_mon.sv` | DMA error reported at the wrong address | killed: killed by ras_system |
| M21 | `rtl/sfras_ecc_sram.sv` | check-bit inversion dropped (all-zero word would read as valid) | killed: killed by ecc_sram_k64_bit |
| M22 | `rtl/sfras_ecc_sram.sv` | memory not re-initialised after MBIST | killed: killed by ecc_sram_k64_bit |
