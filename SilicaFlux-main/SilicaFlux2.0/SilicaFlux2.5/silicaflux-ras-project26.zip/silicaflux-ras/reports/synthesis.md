# Synthesis check (Yosys 0.33, technology-neutral)

Generated 2026-11-10 17:00 UTC by `synth/run_synth.py`.

`synth -flatten` to Yosys internal cells, `-DSYNTHESIS`.  **Cell counts are a relative complexity measure only** -- no liberty file, no area, no timing.  The GENERIC SRAM backend becomes flip-flops, so memory rows include the stored words (DEPTH = 2 rows isolate the wrapper logic).

| Block | Synthesised | Cells | of which flip-flops |
|---|---|---|---|
| SECDED encoder (39,32) | yes | 83 | 0 |
| SECDED encoder (72,64) | yes | 175 | 0 |
| SECDED decoder + classifier (39,32) | yes | 369 | 0 |
| SECDED decoder + classifier (72,64) | yes | 714 | 0 |
| SECDED decoder + classifier (137,128) | yes | 1375 | 0 |
| ECC SRAM wrapper K=64, POISON_BIT (73-bit words), DEPTH=16, FI_EN=0 | yes | 5572 | 1701 |
| same, DEPTH=2 (wrapper logic + 2 stored words) | yes | 3453 | 670 |
| same with FI_EN=1 | yes | 4165 | 755 |
| K=64 POISON_SIG (72-bit words), DEPTH=2 | yes | 3458 | 666 |
| Scrub engine (16-bit address, 32-bit counters) | yes | 1649 | 305 |
| Event controller, 17 ports, 16-entry log | yes | 27528 | 5376 |
| silicaflux_ras (NEXT=8, NMEM=2, NBUS=2, FI_EN=1) | yes | 35012 | 6416 |
| SFB2 parity link (32-bit) | yes | 213 | 72 |
| SFB2 fault injector (32-bit) | yes | 338 | 53 |
| Watchdog | yes | 352 | 37 |
| Thermal monitor (12-bit code) | yes | 770 | 64 |
| DMA bus-error monitor | yes | 70 | 67 |
| Transaction timeout monitor | yes | 400 | 68 |
