// =============================================================================
// SilicaFlux RAS (Project 26) :: synth_tops.sv -- fixed-parameter synthesis
// harnesses (Yosys 0.33 cannot re-derive a parameterised top given with
// hierarchy -chparam when one of its children is derived later; a parameter-
// free harness avoids that).  Not part of the design.
// =============================================================================
`include "sram_defs.svh"
`include "sfras_defs.svh"
`default_nettype none

module synth_ecc_sram_k64_bit #(parameter int K = 64, parameter int DEPTH = 16, parameter int PM = `SFRAS_POISON_BIT,
                                parameter int FI = 0, localparam int AW = $clog2(DEPTH),
                                localparam int KC = K + ((PM == `SFRAS_POISON_BIT) ? 1 : 0),
                                localparam int R = $clog2(KC + $clog2(KC + 1) + 1), localparam int N = KC + R + 1) (
  input  wire logic clk, rst_n, req_valid, req_we, rsp_ready, scr_req_valid, init_req_i, tst_active, tst_ce, tst_we,
  input  wire logic fi_arm_i, fi_addr_en_i,
  input  wire logic [AW-1:0] req_addr, scr_req_addr, tst_addr, fi_addr_i,
  input  wire logic [K-1:0] req_wdata,
  input  wire logic [K/8-1:0] req_wmask,
  input  wire logic [1:0] scr_req_op, fi_mode_i,
  input  wire logic [N-1:0] tst_wdata, fi_mask_i,
  output logic req_ready, rsp_valid, rsp_err, rsp_ce, rsp_poison, rsp_we, scr_req_ready, scr_rsp_valid,
  output logic scr_rsp_ce, scr_rsp_ue, scr_rsp_poison, scr_rsp_wb, init_busy_o, init_done_o, tst_ready,
  output logic ev_valid, ev_ce, ev_ue, ev_poison, fi_armed_o, fi_fired_o, busy, perf_lock_o, perf_rmw_o,
  output logic [K-1:0] rsp_rdata,
  output logic [1:0] scr_rsp_op,
  output logic [2:0] ev_org,
  output logic [AW-1:0] scr_rsp_addr, ev_addr, fi_fired_addr_o,
  output logic [N-1:0] tst_rdata,
  output logic [R:0] ev_syn,
  output logic [$clog2(N)-1:0] ev_idx,
  output logic [0:0] rsp_id
);
  sfras_ecc_sram #(.K(K), .DEPTH(DEPTH), .POISON_MODE(PM), .FI_EN(FI)) u (
    .clk, .rst_n, .req_valid, .req_ready, .req_we, .req_addr, .req_wdata, .req_wmask, .req_id(1'b0),
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_err, .rsp_ce, .rsp_poison, .rsp_we, .rsp_id,
    .scr_req_valid, .scr_req_ready, .scr_req_op, .scr_req_addr, .scr_rsp_valid, .scr_rsp_op, .scr_rsp_addr,
    .scr_rsp_ce, .scr_rsp_ue, .scr_rsp_poison, .scr_rsp_wb, .init_req_i, .init_busy_o, .init_done_o,
    .tst_active, .tst_ready, .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata,
    .ev_valid, .ev_ce, .ev_ue, .ev_poison, .ev_org, .ev_addr, .ev_syn, .ev_idx,
    .fi_arm_i, .fi_mode_i, .fi_mask_i, .fi_addr_en_i, .fi_addr_i, .fi_armed_o, .fi_fired_o, .fi_fired_addr_o,
    .busy, .perf_lock_o, .perf_rmw_o
  );
endmodule

`default_nettype wire
