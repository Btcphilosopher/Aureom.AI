#!/usr/bin/env bash
# usage: synth/synth_one.sh TAG TOP "-chparam NAME VALUE ..." files...
# Generic Yosys 0.33 synthesis (no technology library): proves the RTL is
# synthesizable in the open flow and gives a technology-neutral cell count.
# SYNTHESIS is defined, so simulation-only code (the GENERIC SRAM model's fault
# hooks) is excluded.  The GENERIC backend array becomes flip-flops here: the
# cell counts of memories are therefore NOT silicon area (see the report).
set -euo pipefail
tag=$1; shift; top=$1; shift; params=$1; shift
inc="-Irtl -Ithird_party/silicaflux-sramlib/rtl/mem -Ithird_party/silicaflux-sramlib/rtl/mem/backends/asic -Ithird_party/silicaflux-datafabric/rtl/dma"
mkdir -p build/synth
{
  echo "read_verilog -sv -DSYNTHESIS $inc $*"
  echo "hierarchy -check -top $top $params"
  echo "synth -flatten"
  echo "stat"
} > build/synth/$tag.ys
yosys -q -l build/synth/$tag.log build/synth/$tag.ys > /dev/null
