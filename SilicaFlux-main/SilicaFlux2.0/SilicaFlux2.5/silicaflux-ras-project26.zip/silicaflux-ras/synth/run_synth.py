#!/usr/bin/env python3
"""Generic Yosys 0.33 synthesis of every synthesizable RAS block.

usage: synth/run_synth.py      -> build/synth/*.log, reports/synthesis.md

Technology-neutral: `synth -flatten` maps to Yosys internal gates ($_AND_,
$_XOR_, $_DFF_*, ...).  Cell counts are a relative complexity measure, NOT
silicon area or timing (no liberty file, no placement).  Memories are
synthesised with DEPTH = 2 so that the flip-flop model of the GENERIC SRAM
backend does not dominate; the row "2 stored words" is the array part.
"""

from __future__ import annotations

import datetime
import os
import re
import subprocess

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SL = "third_party/silicaflux-sramlib/rtl/mem"
MEM = ["rtl/sfras_secded_enc.sv", "rtl/sfras_secded_dec.sv", f"{SL}/backends/generic/sram_generic_1rw.sv",
       f"{SL}/backends/fpga/sram_fpga_1rw.sv", f"{SL}/sram_backend_1rw.sv", "rtl/sfras_ecc_sram.sv",
       "synth/synth_tops.sv"]
RAS = ["rtl/sfras_event_ctrl.sv", "rtl/sfras_watchdog.sv", "rtl/sfras_thermal_mon.sv", "rtl/sfras_scrub.sv",
       "rtl/sfras_fi_ctrl.sv", "rtl/silicaflux_ras.sv"]

JOBS = [
    # tag, top, params, files, description
    ("enc_k32", "sfras_secded_enc", "-chparam K 32", ["rtl/sfras_secded_enc.sv"], "SECDED encoder (39,32)"),
    ("enc_k64", "sfras_secded_enc", "-chparam K 64", ["rtl/sfras_secded_enc.sv"], "SECDED encoder (72,64)"),
    ("dec_k32", "sfras_secded_dec", "-chparam K 32", ["rtl/sfras_secded_enc.sv", "rtl/sfras_secded_dec.sv"], "SECDED decoder + classifier (39,32)"),
    ("dec_k64", "sfras_secded_dec", "-chparam K 64", ["rtl/sfras_secded_enc.sv", "rtl/sfras_secded_dec.sv"], "SECDED decoder + classifier (72,64)"),
    ("dec_k128", "sfras_secded_dec", "-chparam K 128", ["rtl/sfras_secded_enc.sv", "rtl/sfras_secded_dec.sv"], "SECDED decoder + classifier (137,128)"),
    ("ecc_sram_k64_bit", "synth_ecc_sram_k64_bit", "", MEM, "ECC SRAM wrapper K=64, POISON_BIT (73-bit words), DEPTH=16, FI_EN=0"),
    ("ecc_sram_k64_bit_d2", "synth_ecc_sram_k64_bit", "-chparam DEPTH 2", MEM, "same, DEPTH=2 (wrapper logic + 2 stored words)"),
    ("ecc_sram_k64_bit_d2_fi", "synth_ecc_sram_k64_bit", "-chparam DEPTH 2 -chparam FI 1", MEM, "same with FI_EN=1"),
    ("ecc_sram_k64_sig_d2", "synth_ecc_sram_k64_bit", "-chparam DEPTH 2 -chparam PM 1", MEM, "K=64 POISON_SIG (72-bit words), DEPTH=2"),
    ("scrub", "sfras_scrub", "-chparam AW 16", ["rtl/sfras_scrub.sv"], "Scrub engine (16-bit address, 32-bit counters)"),
    ("event_ctrl", "sfras_event_ctrl", "-chparam NP 17", ["rtl/sfras_event_ctrl.sv"], "Event controller, 17 ports, 16-entry log"),
    ("silicaflux_ras", "silicaflux_ras", "", RAS, "silicaflux_ras (NEXT=8, NMEM=2, NBUS=2, FI_EN=1)"),
    ("par_link", "sfras_sfb_par_link", "", ["rtl/sfras_bus_parity.sv"], "SFB2 parity link (32-bit)"),
    ("fault_inj", "sfras_sfb_fault_inj", "", ["rtl/sfras_sfb_fault_inj.sv"], "SFB2 fault injector (32-bit)"),
    ("watchdog", "sfras_watchdog", "", ["rtl/sfras_watchdog.sv"], "Watchdog"),
    ("thermal", "sfras_thermal_mon", "", ["rtl/sfras_thermal_mon.sv"], "Thermal monitor (12-bit code)"),
    ("dma_mon", "sfras_dma_mon", "", ["rtl/sfras_dma_mon.sv"], "DMA bus-error monitor"),
    ("timeout_mon", "sfras_timeout_mon", "", ["rtl/sfras_timeout_mon.sv"], "Transaction timeout monitor"),
]


def run(tag, top, params, files):
    os.makedirs(os.path.join(ROOT, "build", "synth"), exist_ok=True)
    cmd = ["bash", os.path.join(ROOT, "synth", "synth_one.sh"), tag, top, params] + files
    p = subprocess.run(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    log = open(os.path.join(ROOT, "build", "synth", f"{tag}.log")).read() if os.path.exists(
        os.path.join(ROOT, "build", "synth", f"{tag}.log")) else p.stdout
    ok = p.returncode == 0 and "ERROR" not in log
    cells = re.findall(r"Number of cells:\s+(\d+)", log)
    ffs = 0
    tail = log[log.rfind("Printing statistics"):] if "Printing statistics" in log else ""
    for m in re.finditer(r"\$_(?:S?DFFE?|ADFFE?|DFF|SDFFCE|DFFE)_[A-Z0-9_]*\s+(\d+)", tail):
        ffs += int(m.group(1))
    return ok, (int(cells[-1]) if cells else None), ffs


def main() -> int:
    rows = []
    for tag, top, params, files, desc in JOBS:
        ok, cells, ffs = run(tag, top, params, files)
        rows.append((tag, desc, ok, cells, ffs))
        print(f"{'OK  ' if ok else 'FAIL'} {tag:24s} cells={cells} ff={ffs}")
    with open(os.path.join(ROOT, "reports", "synthesis.md"), "w") as f:
        f.write("# Synthesis check (Yosys 0.33, technology-neutral)\n\n")
        f.write(f"Generated {datetime.datetime.now(datetime.timezone.utc):%Y-%m-%d %H:%M UTC} by `synth/run_synth.py`.\n\n")
        f.write("`synth -flatten` to Yosys internal cells, `-DSYNTHESIS`.  **Cell counts are a relative complexity "
                "measure only** -- no liberty file, no area, no timing.  The GENERIC SRAM backend becomes flip-flops, "
                "so memory rows include the stored words (DEPTH = 2 rows isolate the wrapper logic).\n\n")
        f.write("| Block | Synthesised | Cells | of which flip-flops |\n|---|---|---|---|\n")
        for tag, desc, ok, cells, ffs in rows:
            f.write(f"| {desc} | {'yes' if ok else '**FAILED**'} | {cells if cells is not None else '-'} | {ffs} |\n")
    return 0 if all(r[2] for r in rows) else 1


if __name__ == "__main__":
    raise SystemExit(main())
