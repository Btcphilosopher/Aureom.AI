#!/usr/bin/env python3
"""Generate SECDED encoder/decoder test vectors from the independent reference.

usage: gen_secded_vectors.py OUT_DIR

One file per configuration, vectors/secded_k<K>_inv<INV>.vec, one vector per line:
    op  a  b  c  cls  idx  syn  tag            (a, b, c, syn hex; others decimal)
    op=2 header     : a=K b=R c=N idx=INV(dec)
    op=0 encode     : a=data            c=expected stored word
    op=1 decode     : a=received word   b=expected data  c=expected corrected word
                      cls=0 NONE / 1 CE / 2 UE, idx=corrected stored-bit index,
                      syn={pe,s}
    tag (decode)    : 0 no error, 1 single, 2 double, 3 triple, 4 weight>=4,
                      5 exhaustive input space (every possible received word)
A summary (counts per tag and class) is written to OUT_DIR/secded_vectors_summary.json.
"""

from __future__ import annotations

import itertools
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from secded_ref import Secded  # noqa: E402

# (K, INV) configurations; INV None = default inversion of the memory wrapper
CONFIGS = [
    (8, None), (8, 0),
    (11, None),
    (16, None),
    (32, None), (32, 0),
    (57, None),
    (64, None), (64, 0),
    (128, None),
]

EXHAUSTIVE_MAX_N = 16      # every possible received word when N <= this


def patterns(k: int, rnd: random.Random, n_random: int) -> list[int]:
    m = (1 << k) - 1
    pats = [0, m]
    pats += [1 << i for i in range(k)]                  # walking one
    pats += [m ^ (1 << i) for i in range(k)]            # walking zero
    a = int("01" * k, 2) & m
    pats += [a, m ^ a]
    pats += [rnd.getrandbits(k) for _ in range(n_random)]
    seen, out = set(), []
    for p in pats:
        if p not in seen:
            seen.add(p)
            out.append(p)
    return out


def main() -> int:
    out_dir = sys.argv[1] if len(sys.argv) > 1 else "vectors"
    os.makedirs(out_dir, exist_ok=True)
    summary = {}
    for k, inv in CONFIGS:
        c = Secded(k, inv=inv)
        rnd = random.Random(1000 + k * 7 + (0 if inv is None else 1))
        lines = [f"2 {k:x} {c.r:x} {c.n:x} 0 {c.inv} 0 0"]
        counts: dict[str, int] = {}

        def dec(cw: int, tag: int) -> None:
            r = c.decode(cw)
            lines.append(f"1 {cw:x} {r.data:x} {r.cw_corr:x} {r.cls} {r.idx} {r.syn:x} {tag}")
            key = f"tag{tag}_cls{r.cls}"
            counts[key] = counts.get(key, 0) + 1

        enc_pats = patterns(k, rnd, 400 if k > 16 else 0)
        if k <= 16:
            enc_pats = list(range(1 << k))                # every data word
        for d in enc_pats:
            lines.append(f"0 {d:x} 0 {c.encode(d):x} 0 0 0 0")
        counts["encode"] = len(enc_pats)

        if c.n <= EXHAUSTIVE_MAX_N:
            # the decoder's entire input space
            for w in range(1 << c.n):
                dec(w, 5)
        else:
            single_pats = patterns(k, rnd, 16)[:64 if k > 16 else 256]
            for d in single_pats:
                cw = c.encode(d)
                dec(cw, 0)
                for b in range(c.n):                      # EVERY bit position
                    dec(cw ^ (1 << b), 1)
            double_pats = single_pats[:8 if c.n <= 80 else 4]
            for d in double_pats:
                cw = c.encode(d)
                for a, b in itertools.combinations(range(c.n), 2):   # EVERY pair
                    dec(cw ^ (1 << a) ^ (1 << b), 2)
            for _ in range(2000):
                d = rnd.getrandbits(k)
                e = 0
                for b in rnd.sample(range(c.n), 3):
                    e |= 1 << b
                dec(c.encode(d) ^ e, 3)
            for _ in range(500):
                d = rnd.getrandbits(k)
                e = 0
                for b in rnd.sample(range(c.n), rnd.randint(4, min(12, c.n))):
                    e |= 1 << b
                dec(c.encode(d) ^ e, 4)

        name = f"secded_k{k}_inv{'d' if inv is None else inv}.vec"
        with open(os.path.join(out_dir, name), "w") as f:
            f.write("\n".join(lines) + "\n")
        summary[name] = {"K": k, "R": c.r, "N": c.n, "INV": c.inv, "counts": counts}
        print(f"{name}: {len(lines) - 1} vectors")
    with open(os.path.join(out_dir, "secded_vectors_summary.json"), "w") as f:
        json.dump(summary, f, indent=1, sort_keys=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
