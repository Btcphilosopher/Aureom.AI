#!/usr/bin/env python3
"""SilicaFlux RAS (Project 26) -- independent SECDED reference model.

Written separately from the RTL and deliberately *not* using the RTL's
syndrome-to-position decode:

  * the code is built from its parity-check matrix H (one column per stored
    bit, column = Hamming position in binary, plus an all-ones overall-parity
    row) and every encoded word is checked against H;
  * decoding is by **nearest-codeword search**: a received word is a codeword,
    or exactly one single-bit flip turns it into a codeword (CE, that bit), or
    neither (UE).  For a distance-4 code this is the SECDED decision rule; it
    needs no syndrome table and no notion of "valid syndrome", so it checks the
    RTL's invalid-syndrome handling instead of repeating it.

Layout (the specification both sides implement, docs/01_ecc_architecture.md):
  stored word cw = {p, c[R-1:0], d[K-1:0]}, data bit i at cw[i], check bit j at
  cw[K+j], overall parity at cw[K+R]; data bit i has the (i+1)-th Hamming
  position >= 3 that is not a power of two; check bit j has position 2^j;
  p makes the total parity of {p, c, d} even; INV (R+1 bits) is XORed onto
  cw[K+R:K] after encoding and before decoding.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass

NONE, CE, UE = 0, 1, 2
CLASS_NAME = {NONE: "NONE", CE: "CE", UE: "UE"}


def _popcount(x: int) -> int:
    return bin(x).count("1")


@dataclass
class DecodeResult:
    cls: int          # NONE / CE / UE
    data: int         # corrected data (stored data bits on UE)
    cw_corr: int      # corrected stored word (received word on UE)
    idx: int          # stored-bit index of the corrected bit (0 unless CE)
    syn: int          # {pe, s} as the RTL reports it (informational)


class Secded:
    def __init__(self, k: int, inv: int | None = 0):
        if k < 1:
            raise ValueError("k must be >= 1")
        self.k = k
        r = 1
        while (1 << r) < k + r + 1:
            r += 1
        self.r = r
        self.n = k + r + 1
        # Hamming positions 1..K+R: powers of two -> check bits, the rest -> data
        self.dpos = [p for p in range(1, k + r + 1) if p & (p - 1)]
        assert len(self.dpos) == k, "position assignment does not fill K data bits"
        self.cpos = [1 << j for j in range(r)]
        assert max(self.cpos) <= k + r
        # parity-check matrix rows over the N stored bits (before inversion)
        # row j (j < R): stored bits whose position has bit j set
        # row R        : all N bits (overall parity)
        self.hpos = self.dpos + self.cpos + [0]          # stored-bit order
        self.h_rows = []
        for j in range(r):
            row = 0
            for b, p in enumerate(self.hpos):
                if (p >> j) & 1:
                    row |= 1 << b
            self.h_rows.append(row)
        self.h_rows.append((1 << self.n) - 1)
        # H column of every stored bit -> stored-bit index (for decode())
        self._col_index = {}
        for b in range(self.n):
            col = 0
            for j, row in enumerate(self.h_rows):
                col |= ((row >> b) & 1) << j
            assert col not in self._col_index and col != 0, "H columns not distinct / zero"
            self._col_index[col] = b
        # data-bit masks per check row (for the encoder)
        self.dmask = [self.h_rows[j] & ((1 << k) - 1) for j in range(r)]
        if inv is None:
            inv = self.default_inv()
        self.inv = inv & ((1 << (r + 1)) - 1)

    # ------------------------------------------------------------- encoding
    def encode_plain(self, d: int) -> int:
        assert 0 <= d < (1 << self.k)
        c = 0
        for j in range(self.r):
            c |= (_popcount(d & self.dmask[j]) & 1) << j
        p = (_popcount(d) + _popcount(c)) & 1
        cw = d | (c << self.k) | (p << (self.k + self.r))
        # H * cw == 0 (every row even) -- the definition of a codeword
        assert all(_popcount(cw & row) % 2 == 0 for row in self.h_rows), "encoder violates H"
        return cw

    def encode(self, d: int) -> int:
        return self.encode_plain(d) ^ (self.inv << self.k)

    def is_codeword(self, cw: int) -> bool:
        plain = cw ^ (self.inv << self.k)
        return self.encode_plain(plain & ((1 << self.k) - 1)) == plain

    # ------------------------------------------------------------- decoding
    def syndrome(self, cw: int) -> int:
        """{pe, s} exactly as the RTL reports it (informational only)."""
        plain = cw ^ (self.inv << self.k)
        s = 0
        for j in range(self.r):
            s |= (_popcount(plain & self.h_rows[j]) & 1) << j
        pe = _popcount(plain) & 1
        return (pe << self.r) | s

    def _hvec(self, cw: int) -> int:
        """H * (cw with the inversion removed), R+1 bits (bit R = overall parity row)."""
        plain = cw ^ (self.inv << self.k)
        v = 0
        for j, row in enumerate(self.h_rows):
            v |= (_popcount(plain & row) & 1) << j
        return v

    def decode(self, cw: int) -> DecodeResult:
        """SECDED decision by column search: the received word is a codeword
        (H*cw = 0), or H*cw equals exactly one column of H (that single bit is
        wrong), or neither (uncorrectable).  No position arithmetic, no notion of
        a 'valid syndrome': a vector that matches no column is simply UE."""
        kmask = (1 << self.k) - 1
        syn = self.syndrome(cw)
        v = self._hvec(cw)
        if v == 0:
            return DecodeResult(NONE, cw & kmask, cw, 0, syn)
        b = self._col_index.get(v)
        if b is not None:
            fixed = cw ^ (1 << b)
            return DecodeResult(CE, fixed & kmask, fixed, b, syn)
        return DecodeResult(UE, cw & kmask, cw, 0, syn)

    def decode_bruteforce(self, cw: int) -> DecodeResult:
        """Nearest-codeword search by trial flips (slow; cross-checks decode())."""
        kmask = (1 << self.k) - 1
        syn = self.syndrome(cw)
        if self.is_codeword(cw):
            return DecodeResult(NONE, cw & kmask, cw, 0, syn)
        hits = [b for b in range(self.n) if self.is_codeword(cw ^ (1 << b))]
        assert len(hits) <= 1, "distance < 3: two codewords at distance 1"
        if hits:
            fixed = cw ^ (1 << hits[0])
            return DecodeResult(CE, fixed & kmask, fixed, hits[0], syn)
        return DecodeResult(UE, cw & kmask, cw, 0, syn)

    # ------------------------------------------------- default inversion mask
    def default_inv(self) -> int:
        """First pair (a<b) of {check bits, parity} whose inversion makes BOTH
        the all-zero and the all-ones stored word uncorrectable; else (0,1).
        Computed with the brute-force decoder (independent of the RTL formula)."""
        allones = (1 << self.n) - 1
        saved = getattr(self, "inv", 0)
        choice = 0b11
        for a, b in itertools.combinations(range(self.r + 1), 2):
            self.inv = (1 << a) | (1 << b)
            if self.decode_bruteforce(0).cls == UE and self.decode_bruteforce(allones).cls == UE:
                choice = self.inv
                break
        self.inv = saved
        return choice

    # ---------------------------------------------------- code-level checks
    def check_properties(self, samples: int = 2000, seed: int = 1) -> None:
        import random
        rnd = random.Random(seed)
        # distinct, non-zero H columns for the K+R covered bits (SEC); the
        # parity row makes every column odd-weight in the extended sense (DED)
        cols = []
        for b in range(self.n):
            col = 0
            for j, row in enumerate(self.h_rows):
                col |= ((row >> b) & 1) << j
            cols.append(col)
        assert len(set(cols)) == self.n, "duplicate H columns"
        assert 0 not in cols, "zero H column"
        # the two decoders agree on random words of every weight class
        for _ in range(samples // 4):
            d = rnd.getrandbits(self.k)
            e = 0
            for b in rnd.sample(range(self.n), rnd.randint(0, min(5, self.n))):
                e |= 1 << b
            w = self.encode(d) ^ e
            assert self.decode(w) == self.decode_bruteforce(w), "decode() != decode_bruteforce()"
        # random codeword pairs: distance >= 4
        for _ in range(samples):
            a = rnd.getrandbits(self.k)
            b = rnd.getrandbits(self.k)
            if a != b:
                assert _popcount(self.encode(a) ^ self.encode(b)) >= 4


def default_inv_for(k: int) -> int:
    return Secded(k, inv=None).inv


if __name__ == "__main__":
    for k in (1, 4, 8, 11, 16, 32, 57, 64, 120, 128, 132):
        c = Secded(k, inv=None)
        c.check_properties(300)
        print(f"K={k:4d} R={c.r} N={c.n:4d} default INV=0x{c.inv:x} "
              f"zero->{CLASS_NAME[c.decode(0).cls]} ones->{CLASS_NAME[c.decode((1 << c.n) - 1).cls]}")
