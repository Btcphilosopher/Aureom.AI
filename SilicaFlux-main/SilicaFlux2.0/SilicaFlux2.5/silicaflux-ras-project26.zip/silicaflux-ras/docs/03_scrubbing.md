# 03 — Background scrubbing: `sfras_scrub`

RTL: `rtl/sfras_scrub.sv` (one engine per ECC memory, instantiated inside `silicaflux_ras`), scrub port of
`rtl/sfras_ecc_sram.sv`. Registers: `MEM_CTRL / INTERVAL / LO / HI / STATUS / CUR / UE_ADDR / PASS / CE / FIX / UE /
POISON / HARD / READS` (`docs/08`).

## 1. Walk and operations

```
 every INTERVAL cycles:  CHECK(addr) ── clean / poisoned ─────────────────────────► addr++ (wrap at HI → PASS++)
                              │ CE (fix_en)                    │ UE
                              ▼                                ▼
                         FIX(addr): locked read,          stop_on_ue ? STOPPED_UE (UE_ADDR) : count, addr++
                         corrected word written back           (the word is NEVER rewritten: it stays UE)
                              │ written back (verify_en)
                              ▼
                         VERIFY(addr) ── clean ──► addr++
                              │ still CE / UE
                              ▼
                         HARD++ and RECOVERY event (stuck cell or corrupted write-back)
```

* **CHECK / VERIFY** are plain reads (one array cycle, no lock): a clean word costs one cycle of array time.
* **FIX** is a locked read + write-back of the *stored codeword with the one bit flipped back* (the poison flag is
  preserved). If a functional write replaced the word between CHECK and FIX, FIX finds it clean and writes nothing.
* **Configurable**: `INTERVAL` (0 = as fast as arbitration allows), address range `LO..HI`, `ONE_PASS`, `FIX_EN`,
  `VERIFY_EN`, `STOP_ON_UE`; `SCRUB_START` restarts at LO and acknowledges STOPPED_UE / DONE.
* **Counters** (CNT_W bits, saturating, sticky overflow `MEM_STATUS.CNT_OVF`): passes, CE found, fixed, UE found,
  poisoned found, hard (verify failures), reads issued.

## 2. Arbitration with normal accesses

Inside `sfras_ecc_sram`: functional requests have priority; a scrub request that has waited `SCRUB_MAX_WAIT` cycles
takes the next free slot (the functional port sees `req_ready = 0` for that one cycle). Locked operations (RMW,
FIX, in-place injection) exclude everything else until their write-back. Scrubbing therefore never starves and never
blocks for more than one slot per `SCRUB_MAX_WAIT + 1` cycles under full load.

## 3. Measured interference (`tb_ecc_sram` P13)

K = 64, DEPTH = 64, READ_LATENCY = 1, FIX + VERIFY on, SCRUB_MAX_WAIT = 8, **100 % offered load** (a new request every
cycle), identical request sequence for each setting:

| Mix | Interval | Functional accepts/cycle | Scrub reads/cycle | Slowdown |
|---|---|---|---|---|
| 50 % read / 50 % full write | off | 1.000 | 0 | — |
| | 0 | 0.909 | 0.090 | 9.0 % |
| | 16 | 0.963 | 0.037 | 3.7 % |
| | 256 | 0.996 | 0.003 | 0.3 % |
| 50 % read / 25 % write / 25 % partial write | off | 0.659 | 0 | — |
| | 0 | 0.601 | 0.087 | 8.8 % |
| | 16 | 0.636 | 0.036 | 3.5 % |
| | 256 | 0.658 | 0.003 | 0.2 % |

(Regenerated on every regression: `docs/09` §4.) Interval 0 is the worst case: the starvation guard bounds the cost at
one slot in SCRUB_MAX_WAIT + 1. In idle periods the scrubber uses free slots at no cost. Time for one pass at light
load ≈ DEPTH × (INTERVAL + 1) cycles (e.g. 64 Ki words at INTERVAL = 255: 16.8 M cycles = 16.8 ms at 1 GHz); choose
the interval from the accumulation-of-errors budget, not from this RTL.

## 4. Uncorrectable-error policy

`STOP_ON_UE = 1`: the engine stops at the first uncorrectable word (`MEM_STATUS.STOPPED_UE`, `MEM_UE_ADDR`) and an
`MEM_UE` event (origin SCRUB) is raised; firmware decides (retire the page, rewrite from a good copy, escalate) and
restarts with `SCRUB_START`. `STOP_ON_UE = 0`: counted, first address recorded, the walk continues. In both cases the
word is left uncorrectable — a scrubber that rewrote it would launder the error into valid-looking data.

## 5. Verified (`tb_ecc_sram` P7–P10, P13; `tb_ras_system` T11)

Seeded single-bit errors in data and check bits found, written back, verified, all words clean afterwards; UE stop
and continue policies; a stuck-at cell (GENERIC backend fault hook) makes VERIFY fail → `HARD` + RECOVERY event; an
injected corruption of the FIX write-back (FI mode SCRUB_WB) is detected the same way; scrub never starved under full
load.
