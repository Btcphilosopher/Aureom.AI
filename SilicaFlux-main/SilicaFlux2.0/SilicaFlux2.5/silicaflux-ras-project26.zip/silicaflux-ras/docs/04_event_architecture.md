# 04 — Fault classification and the central RAS event interface

RTL: `rtl/sfras_event_ctrl.sv` (aggregation), `rtl/silicaflux_ras.sv` (sources, registers, outputs),
`rtl/sfras_watchdog.sv`, `rtl/sfras_thermal_mon.sv`, `rtl/sfras_timeout_mon.sv`, `rtl/sfras_dma_mon.sv`,
`rtl/sfras_bus_parity.sv`.

## 1. Event interface (every source, one port each)

| Signal | Width | Meaning |
|---|---|---|
| `ev_valid` | 1 | pulse: one event this cycle |
| `ev_type` | 4 | `SFRAS_EV_*` (below) |
| `ev_addr`, `ev_addr_v` | 32 + 1 | address where one exists (memory word, bus byte address, register offset) |
| `ev_info` | 32 | source-specific detail (syndrome, origin, DMA direction, sensor code, reason code …) |
| `ev_corr` | 1 | a correction **was performed** (only sources that actually corrected set it) |

The controller adds **source** (= port index), **severity**, **timestamp** (free-running TS_W-bit cycle counter,
48 bits by default) and the **corrected / uncorrected status** to form a 128-bit record.

## 2. Classification

| Code | Type | Hardware min. severity | Raised by |
|---|---|---|---|
| 1 | `MEM_CE` correctable memory error | INFO | ECC memory: a bit was flipped back (read, RMW, scrub check/verify) |
| 2 | `MEM_UE` detected uncorrectable memory error | ERROR | ECC memory: double error / invalid syndrome (read, RMW, scrub) |
| 3 | `BUS_PARITY` bus parity error | ERROR | `sfras_sfb_par_link` (request or response side) |
| 4 | `DMA_ERR` DMA transaction error | ERROR | `sfras_dma_mon` on a DMA SFB2 port |
| 5 | `WDOG` watchdog expiration | ERROR (stage 1) / **FATAL** (stage 2) | `sfras_watchdog` |
| 6 | `THERM_WARN` thermal warning | WARN | `sfras_thermal_mon` (threshold; sensor stale: info[31]) |
| 7 | `THERM_FATAL` fatal thermal event | **FATAL** | `sfras_thermal_mon` |
| 8 | `ILLEGAL_OP` illegal control operation | WARN | RAS register file (reason codes), external ports (e.g. ControlCore command validation) |
| 9 | `POISON` poisoned data consumed | ERROR | ECC memory read of a poisoned word (BIT mode) |
| 10 | `RECOVERY` recovery action failed | WARN | scrub VERIFY after a write-back still in error |
| 11 | `TIMEOUT` transaction timeout | ERROR | `sfras_timeout_mon` |
| 12 | `FI` fault injection armed / fired | INFO | RAS register file (armed), memories / bus injectors (fired, info[31] = 1) |

"Corrected" is never claimed without a correction: `MEM_CE` comes only from a decoder whose `ce_o` is asserted, and
`ce_o` is asserted only when exactly one stored bit was flipped back (checked on every vector in `tb_secded`). A
corrected bit inside a poisoned word is reported as `POISON` with `corrected = 1`; a SIG-mode poisoned word is
reported as `MEM_UE` with info[28] = poison.

**Severity policy.** Effective severity = max(hardware minimum, `SEV_CFG[type]`): firmware may escalate (e.g.
`MEM_UE` → FATAL for a memory without containment downstream) but cannot downgrade (a fatal thermal event stays
FATAL). Unknown type codes default to WARN.

## 3. Aggregation without silent loss

* **Counters are exact**: one counter per type (16) and one per source (≤ 32), CNT_W bits, incremented for *every*
  event — several events of the same type in one cycle all count. Saturating; per-counter sticky overflow flags,
  `STATUS.CNT_OVF`.
* **Log**: each port has a one-entry pending slot (stamped on arrival); a round-robin drain moves one slot per cycle
  into the LOG_DEPTH FIFO. An event that finds its slot still occupied, or reaches a full / disabled log, is **counted
  in `LOG_STAT.LOST` and sets `STATUS.LOG_OVF`** — never silently dropped. The oldest entries are kept.
* **First error**: the first ERROR-or-FATAL event (lowest port on a tie) is frozen in `FIRST_*` until `CLR_FIRST`,
  independent of the log.
* **Sticky status**: `STATUS.SEEN_{INFO,WARN,ERROR,FATAL}`, `TYPE_STATUS[type]`, W1C.

Verified: `tb_event_ctrl` (30 simultaneous events from 5 ports into a 4-entry log, 4-bit counters saturating);
`tb_ras_system` T12; co-simulation C3 (40 events in 10 cycles: driver receives entries + exact lost count).

## 4. Exposure to ControlCore and host software

| Output | Driven by | Intended connection |
|---|---|---|
| `irq_ctrl_o` | `STATUS.SEEN_* & IRQ_EN_CTRL` (+ log threshold) | ControlCore interrupt controller (default WARN, ERROR, FATAL) |
| `irq_host_o` | `STATUS.SEEN_* & IRQ_EN_HOST` (+ log threshold) | host interrupt (default FATAL only) |
| `cc_warn_o`, `cc_fatal_o` | WARN/ERROR seen; FATAL seen | the **existing** `cc_ras` `lv_ext_warn` / `lv_ext_fatal` level inputs — no ControlCore change needed |
| `fatal_o` | `STATUS.SEEN_FATAL` | SoC fatal pin / host |
| `contain_o` | `fatal_o & CTRL.FATAL_CONTAIN` | accelerator isolation (as `cc_ras FATAL_ISOLATE` / PMU) |
| `therm_shutdown_o` | thermal fatal (hardware path, no firmware) | power / clock controller |
| `wdog_reset_req_o` | watchdog stage 2 | reset controller |
| register page | `rb_*` (+ `rb_priv`) | a ControlCore register page (like `CC_PG_RAS`) **and** the host port |

Interrupts are level: they stay asserted until the firmware clears the sticky bits (W1C) — `sfras_service()` drains
the log and clears the serviced non-fatal bits; it never clears `SEEN_FATAL`. With `CTRL.FATAL_LOCK` only reset
clears it.

## 5. Source map of `silicaflux_ras` (NEXT external ports, NMEM memories)

`0 … NEXT-1` external; `NEXT + 3m + {0,1,2}` memory m errors / scrub recovery / injection fired;
`NEXT + 3·NMEM + {0,1,2}` watchdog / thermal / register file. Total ≤ 32.
