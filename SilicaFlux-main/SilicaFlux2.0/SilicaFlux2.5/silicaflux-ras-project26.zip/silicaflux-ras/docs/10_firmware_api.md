# 10 — Firmware register API

Files: `sw/silicaflux_ras_regs.h` (generated register map), `sw/silicaflux_ras.h` / `sw/silicaflux_ras.c` (driver,
freestanding C99, no libc). Verified against the RTL by co-simulation (`tb/sw_cosim.cpp`, regression test
`sw_cosim`): the driver source is compiled unchanged, every register access is a bus cycle of the Verilated
`silicaflux_ras`.

## 1. Access model

* One 4 KiB page; same offsets for ControlCore firmware and host software (`SFRAS_*` offsets, `SFRAS_MEM(m, r)` for
  per-memory blocks). Default MMIO is a volatile 32-bit access at `dev->base + offset`; define `SFRAS_READ32` /
  `SFRAS_WRITE32` before including the header to use another path (host driver, PCIe BAR, test harness).
* Fault-injection functions exist only with `-DSFRAS_ENABLE_FI`. Production builds omit it **and** lock the
  hardware (`sfras_init()` sets `CTRL.FI_LOCK` unless told otherwise).

## 2. Boot

```c
#include "silicaflux_ras.h"
static sfras_dev_t ras;

void ras_boot(void) {
    sfras_config_t cfg;
    sfras_default_config(&cfg);          /* WARN|ERROR|FATAL -> ControlCore, FATAL -> host, contain on FATAL,
                                            fault injection locked */
    cfg.fatal_lock   = true;             /* production: FATAL survives until reset */
    cfg.sev_escalate = 3u << (2 * SFRAS_EV_MEM_UE);   /* e.g. treat UE as FATAL on this SoC */
    if (sfras_init(&ras, RAS_BASE, &cfg) != SFRAS_OK) { /* not a RAS page */ }
    for (uint32_t m = 0; m < ras.nmem; m++) {
        sfras_mem_init(&ras, m, 100000);                 /* valid codewords everywhere */
        sfras_scrub_start(&ras, m, 0, depth[m] - 1, 1024,
                          SFRAS_SCRUB_FIX | SFRAS_SCRUB_VERIFY | SFRAS_SCRUB_STOP_ON_UE);
    }
    sfras_therm_config(&ras, warn_code, fatal_code, 8, 100000);  /* SFRAS_E_REFUSED if fatal_code was clamped */
    sfras_wdog_start(&ras, 50000000, true);                      /* locked */
}
```

## 3. Interrupt service

```c
static void on_event(void *ctx, const sfras_event_t *e) {
    switch (e->type) {
    case SFRAS_EV_MEM_CE: {                      /* corrected: count, maybe retire a page on repetition */
        sfras_mem_info_t mi = sfras_decode_mem_info(e->info);
        /* mi.origin (READ/RMW/SCRUB/...), mi.bit, mi.syndrome, e->addr (word), e->src (memory) */
        break; }
    case SFRAS_EV_MEM_UE: case SFRAS_EV_POISON:  /* data lost at e->addr: the consumer got an error response */
    case SFRAS_EV_DMA_ERR:                        /* re-program / fail the job */
    case SFRAS_EV_RECOVERY:                       /* hard fault: stop using the word */
    default: break;
    }
}

void ras_irq(void) {
    uint32_t lost;
    sfras_service(&ras, on_event, 0, &lost);     /* drains the log, clears serviced non-fatal sticky bits */
    if (lost) { /* events were counted but not logged: read sfras_type_count() / sfras_src_count() */ }
    if (sfras_fatal(&ras)) { /* containment is already active in hardware: record and reset */ }
}
```

`sfras_service()` never clears `SEEN_FATAL`. Counters are exact even when the log overflowed. `sfras_first_error()`
returns the first ERROR/FATAL event since the last `sfras_clear_first()`.

## 4. Function reference

| Function | Purpose |
|---|---|
| `sfras_default_config`, `sfras_init` | configuration (ID/version check, interrupt routing, severity escalation, locks) |
| `sfras_log_pop`, `sfras_service`, `sfras_first_error`, `sfras_clear_first`, `sfras_log_lost` | event log |
| `sfras_status`, `sfras_fatal`, `sfras_type_count`, `sfras_src_count`, `sfras_clear_counts`, `sfras_timestamp` | status / counters (64-bit timestamp read is tear-free) |
| `sfras_src_mem / _mem_rec / _mem_fi / _wdog / _therm / _regs` | source-id map |
| `sfras_decode_mem_info`, `sfras_type_name`, `sfras_sev_name` | decoding |
| `sfras_mem_init`, `sfras_scrub_start`, `sfras_scrub_stop`, `sfras_scrub_stats` | ECC memories |
| `sfras_wdog_start`, `sfras_wdog_kick`, `sfras_therm_config` | watchdog / thermal |
| `sfras_lock_fi` | permanent (until reset) injection lock |
| `sfras_fi_unlock`, `sfras_fi_relock`, `sfras_fi_inject_mem`, `sfras_fi_inject_bus` | `SFRAS_ENABLE_FI` only |

Register-level detail: `docs/08_register_map.md`.
