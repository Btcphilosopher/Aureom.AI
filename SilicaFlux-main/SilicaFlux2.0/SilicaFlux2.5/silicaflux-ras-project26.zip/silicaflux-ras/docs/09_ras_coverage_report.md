# 09 — RAS coverage report (Project 26)

Generated 2026-11-10 17:02 UTC by `scripts/ras_report.py` — 39 / 39 regression runs passed, 22 / 22 mutants killed.

> **Scope of the numbers.** Coverage figures below are *for the implemented fault model* (bit flips in stored words, parity-covered bus fields, injected transaction failures). They are exact properties of the codes or measured in simulation. **No FIT rate, soft-error rate or field reliability is stated or implied**: that needs device, process, package and environment data (neutron/alpha flux, Qcrit, multi-cell-upset statistics, physical bit interleaving) which this project does not have.

## 1. Protected and unprotected memory capacity

Capacities are the default RTL parameters found in the audit (`docs/00_audit.md`). "Current" is what the existing repositories implement today; the Project 26 column is the recommended disposition. Only the DataFabric SFB2 SRAM slave has a verified drop-in replacement in this deliverable; the other SECDED integrations are specified (docs/02) but **not yet applied** to those repositories.

| Memory | Module | Size (KiB) | Current protection | Project 26 disposition |
|---|---|---|---|---|
| ControlCore IMEM | silicaflux-controlcore mcu_sram_bank | 64 | byte parity (detect only) | SECDED-capable: word-written by firmware loader; replace mcu_sram_bank parity by sfras_ecc_sram (K=32, SIG -> 39-bit) |
| ControlCore DMEM | silicaflux-controlcore mcu_sram_bank | 32 | byte parity (detect only) | SECDED with RMW for byte stores (sfras_ecc_sram K=32) |
| Shared SRAM | silicaflux-memorycore sfmem_banked | 256 | byte parity (ECC_MODE=PARITY default) | SECDED at the sfmem_banked encode/decode point (ECC_MODE=2 hook), RMW via bank lock |
| LMEM | silicaflux-memorycore sfmem_banked | 32 | byte parity (ECC_MODE=PARITY default) | as shared SRAM |
| HPC tile scratchpad (VSPM) | silicaflux-hpc-m04/m08 hpc_scratchpad | 64 | none (M08 default SPM_ECC=NONE); byte parity optional | SECDED for BYTE_WE=0 configurations; byte parity otherwise (RMW would halve bank bandwidth) |
| DataFabric SFB2 SRAM slaves | silicaflux-datafabric sfb_sram_slave | per instance | none | drop-in sfras_sfb_ecc_slave (this project; verified with the real DMA) |
| Tensor operand buffer (A+B) | TENSORCORE 03 tensor_operand_buffer | 2 | none | unprotected: transient operands, refilled per tile -- candidate for byte parity |
| Tensor output buffer | TENSORCORE 07 tensor_output_buffer (hpc_scratchpad ECC NONE) | 0.500 | none | unprotected; SECDED possible (word writes) -- not integrated |
| Tensor accumulator storage | TENSORCORE 04 tensor_acc_storage (flip-flop array) | 0.129 | none | unprotected (flip-flops; 8 x 132 bits default) |
| ControlCore D-cache data | silicaflux-memorycore sfmem_cache | 2 | none | unprotected; write-back dirty data is a single point of failure |
| DMA burst FIFO | silicaflux-datafabric dma_fifo | 0.031 | none | unprotected |
| RAS event log + pending slots | this project sfras_event_ctrl | 0.516 | none | unprotected (diagnostic data only) |

Today (audited defaults): **0 KiB SECDED-correctable**, **384 KiB detect-only (byte parity)**, **69.2 KiB unprotected** of 453.2 KiB inventoried on-die storage.

After the planned integrations of section 1 (IMEM, DMEM, shared SRAM, LMEM to SECDED; HPC scratchpad to byte parity): **384 KiB SECDED** (85 %), **64 KiB detect-only**, **5.2 KiB unprotected** (tensor buffers, accumulators, cache data, FIFOs, RAS log). SECDED storage overhead: 7/32 = 21.9 % for (39,32), 8/64 = 12.5 % for (72,64), 9/64 = 14.1 % for the 73-bit poison-bit variant; byte parity: 12.5 %.

## 2. Error-detection coverage for the implemented fault model (exact enumeration)

Every error pattern of the given weight in the N stored bits is enumerated (the code is linear, so the outcome does not depend on the data). *Corrected* for weight ≥ 2 means **miscorrected** (the decoder flips a third bit and reports CE): that is the silent-corruption risk of any distance-4 code.

| Code | Overhead | 1-bit: corrected | 2-bit: detected (UE) | 3-bit: detected | 3-bit: **miscorrected** | 3-bit adjacent: miscorrected | 4-bit: **undetected** | invalid syndromes |
|---|---|---|---|---|---|---|---|---|
| (13,8) | 62.5 % | 13/13 (100.00 %) | 78/78 (100.00 %) | 23.08 % | 76.92 % | 8/11 | 7.69 % (55 of 715) | 3 |
| (22,16) | 37.5 % | 22/22 (100.00 %) | 231/231 (100.00 %) | 31.69 % | 68.31 % | 17/20 | 3.60 % (263 of 7315) | 10 |
| (39,32) | 21.9 % | 39/39 (100.00 %) | 741/741 (100.00 %) | 30.71 % | 69.29 % | 34/37 | 1.92 % (1583 of 82251) | 25 |
| (72,64) | 12.5 % | 72/72 (100.00 %) | 2556/2556 (100.00 %) | 24.04 % | 75.96 % | 68/70 | 1.10 % (11326 of 1028790) | 56 |
| (137,128) | 7.0 % | 137/137 (100.00 %) | 9316/9316 (100.00 %) | 16.36 % | 83.64 % | 131/135 | not enumerated | 119 |

For comparison, the existing **byte parity** (36,32): 1-bit detected 100.00 % (corrected 0 %), 2-bit detected 77.14 % (the 144 same-byte pairs are missed), 3-bit detected 100.00 %.

**SIG poison mode ambiguity** (no extra stored bit): double errors whose syndrome equals the signature are reported as UE *and* poison (still contained — the read is answered with an error — only the classification is ambiguous):

| Code | ambiguous double-error pairs | of all double-error pairs |
|---|---|---|
| (13,8) | 4 | 5.13 % |
| (22,16) | 6 | 2.60 % |
| (39,32) | 7 | 0.94 % |
| (72,64) | 8 | 0.31 % |
| (137,128) | 9 | 0.10 % |

POISON_MODE = BIT stores the poison flag as a code data bit, so poison is itself single-error-corrected and never ambiguous; it costs one stored bit per word.

## 3. Error-injection results (simulation)

Key result lines of the Icarus runs (the same tests pass on Verilator 5.020 with assertions; see `reports/regression.md`).

**`ecc_sram_k128_bit_lat3`**

```
RESULT P1 init: 32 words initialised and read clean
RESULT P2 random traffic: 1312 responses checked
RESULT P3 single-bit: all 138 stored-bit positions corrected (CE events with exact index)
RESULT P4 double-bit: 543 bit pairs detected as UE (err + poison, uncorrected data returned)
RESULT P5 read/write-path injection: 685 injections fired as predicted
RESULT P6 partial writes: RMW on clean / CE / UE / poisoned words as specified (POISON_MODE=2)
RESULT P7 scrub: 8 seeded single-bit errors found, written back and verified; all words clean
RESULT P8 scrub UE: stop policy halted at word 16; continue policy counted it and left it uncorrectable
RESULT P9 stuck-at: CE corrected on read, write-back verified failing -> recovery event (hard_count=1)
RESULT P10 recovery fault: corrupted write-back detected by verify (hard_count=1)
RESULT P11 MBIST: raw 138-bit patterns written/read through the test port; memory re-initialised
RESULT P12 strobes/addresses: no-op and error responses as specified
RESULT P14 reset during traffic: no spurious response/event, memory re-initialised
PASS tb_ecc_sram
```

**`ecc_sram_k32_sig_np2`**

```
RESULT P1 init: 100 words initialised and read clean
RESULT P2 random traffic: 4100 responses checked
RESULT P3 single-bit: all 39 stored-bit positions corrected (CE events with exact index)
RESULT P4 double-bit: 741 bit pairs detected as UE (err + poison, uncorrected data returned)
RESULT P5 read/write-path injection: 784 injections fired as predicted
RESULT P6 partial writes: RMW on clean / CE / UE / poisoned words as specified (POISON_MODE=1)
RESULT P7 scrub: 25 seeded single-bit errors found, written back and verified; all words clean
RESULT P8 scrub UE: stop policy halted at word 50; continue policy counted it and left it uncorrectable
RESULT P9 stuck-at: CE corrected on read, write-back verified failing -> recovery event (hard_count=1)
RESULT P10 recovery fault: corrupted write-back detected by verify (hard_count=1)
RESULT P11 MBIST: raw 39-bit patterns written/read through the test port; memory re-initialised
RESULT P12 strobes/addresses: no-op and error responses as specified
RESULT P14 reset during traffic: no spurious response/event, memory re-initialised
PASS tb_ecc_sram
```

**`ecc_sram_k32_word_only`**

```
RESULT P1 init: 64 words initialised and read clean
RESULT P2 random traffic: 2624 responses checked
RESULT P3 single-bit: all 39 stored-bit positions corrected (CE events with exact index)
RESULT P4 double-bit: 741 bit pairs detected as UE (err + poison, uncorrected data returned)
RESULT P5 read/write-path injection: 784 injections fired as predicted
RESULT P6 partial writes: MW=1 (no byte lanes): only full / empty strobes exist
RESULT P7 scrub: 16 seeded single-bit errors found, written back and verified; all words clean
RESULT P8 scrub UE: stop policy halted at word 32; continue policy counted it and left it uncorrectable
RESULT P9 stuck-at: CE corrected on read, write-back verified failing -> recovery event (hard_count=1)
RESULT P10 recovery fault: corrupted write-back detected by verify (hard_count=1)
RESULT P11 MBIST: raw 39-bit patterns written/read through the test port; memory re-initialised
RESULT P12 strobes/addresses: no-op and error responses as specified
RESULT P14 reset during traffic: no spurious response/event, memory re-initialised
PASS tb_ecc_sram
```

**`ecc_sram_k64_bit`**

```
RESULT P1 init: 64 words initialised and read clean
RESULT P2 random traffic: 2624 responses checked
RESULT P3 single-bit: all 73 stored-bit positions corrected (CE events with exact index)
RESULT P4 double-bit: 249 bit pairs detected as UE (err + poison, uncorrected data returned)
RESULT P5 read/write-path injection: 326 injections fired as predicted
RESULT P6 partial writes: RMW on clean / CE / UE / poisoned words as specified (POISON_MODE=2)
RESULT P7 scrub: 16 seeded single-bit errors found, written back and verified; all words clean
RESULT P8 scrub UE: stop policy halted at word 32; continue policy counted it and left it uncorrectable
RESULT P9 stuck-at: CE corrected on read, write-back verified failing -> recovery event (hard_count=1)
RESULT P10 recovery fault: corrupted write-back detected by verify (hard_count=1)
RESULT P11 MBIST: raw 73-bit patterns written/read through the test port; memory re-initialised
RESULT P12 strobes/addresses: no-op and error responses as specified
RESULT P14 reset during traffic: no spurious response/event, memory re-initialised
PASS tb_ecc_sram
```

**`ecc_sram_k64_none_lat2_pipe`**

```
RESULT P1 init: 64 words initialised and read clean
RESULT P2 random traffic: 2624 responses checked
RESULT P3 single-bit: all 72 stored-bit positions corrected (CE events with exact index)
RESULT P4 double-bit: 246 bit pairs detected as UE (err + poison, uncorrected data returned)
RESULT P5 read/write-path injection: 322 injections fired as predicted
RESULT P6 partial writes: RMW on clean / CE / UE / poisoned words as specified (POISON_MODE=0)
RESULT P7 scrub: 16 seeded single-bit errors found, written back and verified; all words clean
RESULT P8 scrub UE: stop policy halted at word 32; continue policy counted it and left it uncorrectable
RESULT P9 stuck-at: CE corrected on read, write-back verified failing -> recovery event (hard_count=1)
RESULT P10 recovery fault: corrupted write-back detected by verify (hard_count=1)
RESULT P11 MBIST: raw 72-bit patterns written/read through the test port; memory re-initialised
RESULT P12 strobes/addresses: no-op and error responses as specified
RESULT P14 reset during traffic: no spurious response/event, memory re-initialised
PASS tb_ecc_sram
```

**`ecc_sram_k64_sig`**

```
RESULT P1 init: 64 words initialised and read clean
RESULT P2 random traffic: 2624 responses checked
RESULT P3 single-bit: all 72 stored-bit positions corrected (CE events with exact index)
RESULT P4 double-bit: 246 bit pairs detected as UE (err + poison, uncorrected data returned)
RESULT P5 read/write-path injection: 322 injections fired as predicted
RESULT P6 partial writes: RMW on clean / CE / UE / poisoned words as specified (POISON_MODE=1)
RESULT P7 scrub: 16 seeded single-bit errors found, written back and verified; all words clean
RESULT P8 scrub UE: stop policy halted at word 32; continue policy counted it and left it uncorrectable
RESULT P9 stuck-at: CE corrected on read, write-back verified failing -> recovery event (hard_count=1)
RESULT P10 recovery fault: corrupted write-back detected by verify (hard_count=1)
RESULT P11 MBIST: raw 72-bit patterns written/read through the test port; memory re-initialised
RESULT P12 strobes/addresses: no-op and error responses as specified
RESULT P14 reset during traffic: no spurious response/event, memory re-initialised
PASS tb_ecc_sram
```

**`event_ctrl`**

```
RESULT E1 severity: hardware minimum severity correct for all 16 type codes (+ watchdog stage 2)
RESULT E2 severity policy: escalation applied, downgrade of FATAL refused
RESULT E3 aggregation: 30 simultaneous events from 5 ports counted exactly; log kept the 4 oldest, 26 reported lost (LOG_OVF)
RESULT E4 counter overflow: 4-bit counters saturate at 15, sticky per-counter and global overflow flags, clear works
RESULT E5 first-error capture: first ERROR-or-worse event frozen (lowest port on a tie), INFO ignored
RESULT E6 sticky status: W1C clears, SEEN_FATAL survives W1C once FATAL_LOCK is set
RESULT E7 reset: counters, log, first error, sticky status and timestamp cleared
PASS tb_event_ctrl
```

**`ras_system`**

```
RESULT T1 reset/identification: ID, VERSION, CFG (NP=17), reset values, outputs quiet
RESULT T2 illegal operations: RO/unmapped/unprivileged writes refused with rb_err and logged (reason, offset); WARN -> irq_ctrl only
RESULT T3 FI access control: refused without hardware permission, with a wrong key and for a bad target; unlocked only by KEY1,KEY2
RESULT T4 CE: in-place single-bit fault corrected on an SFB2 read (data intact, rsp_error=0), MEM_CE logged with address 10, bit 5, origin READ; FI armed+fired audited
RESULT T5 UE: double-bit fault answered rsp_error=1 + poison on SFB2, MEM_UE logged (ERROR), first-error capture, irq_ctrl
RESULT T6 DMA containment: DMA aborted with READ_BUS at 0x14; words 0-4 copied, words 5-15 of the destination untouched; MEM_UE + DMA_ERR logged
RESULT T7 injected DMA failure: forced bus error -> DMA_ERR_READ_BUS, DMA_ERR event, injection audited
RESULT T8 timeout: 100-cycle response delay -> one TIMEOUT event (limit 40), transfer completed correctly
RESULT T9 bus parity: corrupted request never executed (local error response), corrupted response delivered with rsp_error; 2 BUS_PARITY events
RESULT T10 UNPROTECTED: a response corrupted between the parity checker and the master is NOT detected (only the injection audit is logged) -- listed as a single point of failure
RESULT T11 scrub: 3 seeded single-bit faults (data + check bit) found, written back, verified; injected write-back fault -> RECOVERY; UE stop policy -> STOPPED_UE at word 40
RESULT T12 aggregation: 12 simultaneous events on 4 ports counted exactly (type + source), logged 6 + lost 6; LOG_THR interrupt asserted / released
RESULT T13 thermal: WARN at 3100, fatal threshold clamped to 3400, FATAL at 3500 -> immediate hardware shutdown, fatal_o/contain_o/irq_host; stale sensor warned; FATAL_LOCK holds fatal_o
RESULT T14 reset during DMA + scrub + locked fatal: all status, counters, log, outputs cleared; memories re-initialised; FI locked
RESULT T15 watchdog: kicks hold it off, lock and key enforced, stage 1 -> ERROR, stage 2 -> FATAL + wdog_reset_req
RESULT T16 FI_LOCK: set-only lock refuses unlock and arm until reset; memory untouched
PASS tb_ras_system
```

**`ras_system_prod`**

```
RESULT T1 reset/identification: ID, VERSION, CFG (NP=17), reset values, outputs quiet
RESULT T2 illegal operations: RO/unmapped/unprivileged writes refused with rb_err and logged (reason, offset); WARN -> irq_ctrl only
RESULT PROD: FI_EN=0 build -- unlock and arm refused (4 ILLEGAL_OP events), no injection reached a memory or the bus
PASS tb_ras_system (PROD)
```

**`secded_k11_invd`**

```
tb_secded K=11 R=4 N=16 INV=0x3: 2048 encode + 65536 decode vectors, 0 invalid-syndrome UEs
PASS tb_secded K=11 INV=0x3
```

**`secded_k128_invd`**

```
tb_secded K=128 R=8 N=137 INV=0x3: 660 encode + 48596 decode vectors, 424 invalid-syndrome UEs
PASS tb_secded K=128 INV=0x3
```

**`secded_k16_invd`**

```
tb_secded K=16 R=5 N=22 INV=0x3: 65536 encode + 5544 decode vectors, 688 invalid-syndrome UEs
PASS tb_secded K=16 INV=0x3
```

**`secded_k32_inv0`**

```
tb_secded K=32 R=6 N=39 INV=0x0: 468 encode + 10988 decode vectors, 719 invalid-syndrome UEs
PASS tb_secded K=32 INV=0x0
```

**`secded_k32_invd`**

```
tb_secded K=32 R=6 N=39 INV=0x9: 468 encode + 10988 decode vectors, 697 invalid-syndrome UEs
PASS tb_secded K=32 INV=0x9
```

**`secded_k57_invd`**

```
tb_secded K=57 R=6 N=64 INV=0x3: 518 encode + 22788 decode vectors, 0 invalid-syndrome UEs
PASS tb_secded K=57 INV=0x3
```

**`secded_k64_inv0`**

```
tb_secded K=64 R=7 N=72 INV=0x0: 532 encode + 27620 decode vectors, 539 invalid-syndrome UEs
PASS tb_secded K=64 INV=0x0
```

**`secded_k64_invd`**

```
tb_secded K=64 R=7 N=72 INV=0x3: 532 encode + 27620 decode vectors, 557 invalid-syndrome UEs
PASS tb_secded K=64 INV=0x3
```

**`secded_k8_inv0`**

```
tb_secded K=8 R=4 N=13 INV=0x0: 256 encode + 8192 decode vectors, 768 invalid-syndrome UEs
PASS tb_secded K=8 INV=0x0
```

**`secded_k8_invd`**

```
tb_secded K=8 R=4 N=13 INV=0x3: 256 encode + 8192 decode vectors, 768 invalid-syndrome UEs
PASS tb_secded K=8 INV=0x3
```

## 4. Scrub interference (measured)

`tb_ecc_sram` P13, K=64 / DEPTH=64 / READ_LATENCY=1, 100 % offered functional load (one request every cycle), identical request sequence for every setting, scrub with FIX + VERIFY, starvation guard SCRUB_MAX_WAIT = 8:

| Traffic mix | Scrub interval | Functional accepts / cycle | Scrub reads / cycle | Slowdown |
|---|---|---|---|---|
| rd50_wr50 | off | 1.000 | 0.000 | 0.0% |
| rd50_wr50 | 0 | 0.909 | 0.090 | 9.0% |
| rd50_wr50 | 16 | 0.963 | 0.037 | 3.7% |
| rd50_wr50 | 256 | 0.996 | 0.003 | 0.3% |
| rd50_wr25_rmw25 | off | 0.659 | 0.000 | 0.0% |
| rd50_wr25_rmw25 | 0 | 0.601 | 0.087 | 8.8% |
| rd50_wr25_rmw25 | 16 | 0.636 | 0.036 | 3.5% |
| rd50_wr25_rmw25 | 256 | 0.658 | 0.003 | 0.2% |

A scrub CHECK costs one array cycle (no lock); only a word that needs correction costs a locked read + write-back (READ_LATENCY + DEC_PIPE + 1 cycles). Under full load the guard gives the scrubber one slot per 9 cycles (interval 0): ~9 % slowdown, an upper bound. At interval 256 the cost is < 0.5 %. Partial writes (RMW) cost READ_LATENCY + 2 cycles each with or without scrubbing — in mix rd50_wr25_rmw25 they, not the scrubber, dominate the throughput loss. Pass time = DEPTH × (interval + 1) cycles at light load.

## 5. Recovery behaviour

| Fault | Detection | Immediate action | Recovery | Event (severity) |
|---|---|---|---|---|
| 1 bit in a stored word | SECDED decode on read / scrub | corrected data returned (`rsp_ce`) | scrub FIX writes the corrected word back + VERIFY; any full write also clears it | MEM_CE (INFO) |
| stuck cell (hard fault) | VERIFY after write-back still in error | reads keep being corrected | none in hardware: RECOVERY event; firmware may retire / spare the region | MEM_CE + RECOVERY (WARN) |
| 2 bits in a stored word | SECDED (pe = 0, s ≠ 0) | read answered with `rsp_err` + `rsp_poison`; SFB2 `rsp_error` | not correctable: word stays UE until rewritten; partial writes store it poisoned; scrub never "fixes" it | MEM_UE (ERROR) |
| ≥ 3 bits | invalid syndrome → UE; otherwise possible miscorrection (section 2) | as above, or silently miscorrected | - | MEM_UE or (wrong) MEM_CE |
| poisoned word consumed | poison flag / signature | error response | rewrite | POISON (ERROR) |
| bus parity (request) | parity link checker | request not executed, local error response | master retries / aborts | BUS_PARITY (ERROR) |
| bus parity (response) | parity link checker | response delivered with `rsp_error` | master retries / aborts | BUS_PARITY (ERROR) |
| DMA bus error | SFB2 `rsp_error` | DMA aborts (READ_BUS / WRITE_BUS), destination not written past the fault | firmware re-programs the transfer | DMA_ERR (ERROR) |
| response timeout | timeout monitor | none (passive) | escalate per policy; a hung slave needs reset / isolation | TIMEOUT (ERROR) |
| watchdog | counter | stage 1: interrupt; stage 2: `wdog_reset_req_o` | reset | WDOG (ERROR / FATAL) |
| over-temperature | sensor thresholds | warning: interrupt; fatal: `therm_shutdown_o` in hardware, `contain_o` | cool-down below threshold − hysteresis; fatal latched until W1C (or reset with FATAL_LOCK) | THERM_WARN (WARN) / THERM_FATAL (FATAL) |
| illegal control operation | register file / external ports | write refused (`rb_err`) | none needed | ILLEGAL_OP (WARN) |

Fatal propagation: any FATAL event sets STATUS.SEEN_FATAL → `fatal_o`, `cc_fatal_o` (existing cc_ras EXT_FATAL input), `contain_o` (if CTRL.FATAL_CONTAIN), `irq_host_o` (default enable). With CTRL.FATAL_LOCK set it can only be cleared by reset (verified, tb_ras_system T13/T15).

## 6. Remaining single points of failure and uncovered faults

1. **Unprotected storage** (section 1): tensor operand/output buffers, tensor accumulators (flip-flops), the ControlCore D-cache data and tags, DMA FIFOs, command queues, register files of ControlCore/vector lanes, the RAS event log itself. A flip there is silent.
2. **SFB2 data path outside parity links**: SFB2 has no end-to-end protection. A response corrupted between the parity checker and the master is delivered as good data — demonstrated, not hidden (tb_ras_system T10). Parity links cover only the segments where they are instantiated; the crossbar, routers and NoC have no parity/CRC.
3. **Encoder / decoder logic**: a fault in the ECC logic itself (e.g. a stuck XOR output) is not self-checked. The write path encodes and the read path decodes with separate instances but there is no duplicate-and-compare or encoder self-check.
4. **Address-decoder faults** of a macro (reading the right data from the wrong row) produce a valid codeword and are not detected: the code does not include the address. Option: fold the word address into the check bits (address-in-ECC); not implemented.
5. **Multi-bit upsets in one word** (≥ 3 bits): may miscorrect (section 2). Physical column interleaving in the macro (bits of one word far apart) is the mitigation and is a macro/floorplan decision outside this RTL.
6. **SIG poison mode**: a poisoned word hit by one more upset can decode as a (wrong) CE; and a few genuine double errors read as poison (section 2). POISON_MODE = BIT avoids both.
7. **RAS controller itself**: counters, log, status and the watchdog/thermal registers are not protected; a fault there can lose or corrupt diagnostics (not data). The fatal path (`therm_shutdown_o`, `wdog_reset_req_o`) is single-rail.
8. **Clock / reset / power faults** are outside the fault model (no clock monitor, no reset-glitch detection).
9. **Timeouts are reported, not recovered**: a hung SFB2 slave keeps its master blocked (SFB2 has no abort).
10. **Write-ack of posted writes**: with WRITE_ACK = 0 an RMW error is only visible as an event.

