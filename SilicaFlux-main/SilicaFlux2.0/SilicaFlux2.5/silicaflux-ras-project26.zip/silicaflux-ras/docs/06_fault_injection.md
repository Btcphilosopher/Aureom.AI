# 06 — Fault-injection framework

RTL: `rtl/sfras_fi_ctrl.sv` (access control), injection datapaths in `rtl/sfras_ecc_sram.sv`,
`rtl/sfras_sfb_fault_inj.sv`, `rtl/sfras_bus_parity.sv`. Firmware: `sfras_fi_*()` (only with `SFRAS_ENABLE_FI`).

## 1. What can be injected

| Fault | Mechanism | Target / mode |
|---|---|---|
| single-bit memory error | XOR mask (N bits, one set) | memory, `FI_INPLACE` (persistent, in the stored word), `FI_WRITE` (next write), `FI_READ` (transient, next read) |
| double-bit / multi-bit memory error | XOR mask with 2+ bits | same modes |
| corrupted bus response | XOR into `rdata` of the next response | bus injector, BUS_MODE 0 |
| bus parity error | flip request / response parity | parity link, BUS_MODE 0 / 1 |
| DMA failure | force `rsp_error` on the next response | bus injector, BUS_MODE 1 |
| timeout | delay the next response by `FI_DELAY` cycles | bus injector, BUS_MODE 2 |
| corrupted write data | XOR into `wdata` of the next write | bus injector, BUS_MODE 3 |
| recovery fault | XOR into the next scrub write-back | memory, `FI_SCRUB_WB` |

Each injection is one-shot; the target reports `armed / busy` until the mask has been fully applied (a re-arm
before that is ignored — a race found by `tb_ecc_sram` at READ_LATENCY ≥ 2 and now a mutation-tested property).

## 2. Production protection (no injection control reachable by production workloads)

An injection is armed only if **all** hold:

1. **build**: `FI_EN = 1`. With `FI_EN = 0` the injection datapaths and the controller are compiled out (verified:
   `tb_ras_system PROD` — every attempt refused, nothing reaches a memory or the bus);
2. **hardware permission**: `fi_allow_i = 1`, a pin from TestCore test mode / the secure monitor's debug unlock —
   not software-controllable;
3. **no lock**: `CTRL.FI_LOCK = 0`; FI_LOCK is set-only until reset — production firmware sets it at boot
   (`sfras_init()` does by default, `sfras_lock_fi()` explicitly);
4. **privilege**: FI registers are writable only with `rb_priv = 1` (a privileged master); the host or user code
   gets `rb_err` and an `ILLEGAL_OP` (NOT_PRIV) event;
5. **unlock sequence**: `FI_KEY` = 0xF1A70001 then 0xF1A70002; any other value re-locks (`ILLEGAL_OP` BAD_KEY);
   losing `fi_allow_i` or setting `FI_LOCK` re-locks immediately;
6. **valid, idle target**.

Every refusal is counted (`FI_STATUS.REFUSED`) and logged as `ILLEGAL_OP` with a reason code; every accepted arm and
every fired injection is logged as an `FI` event (audit trail: armed = info[31] 0, fired = 1); `fi_active_o` and
`STATUS.FI_UNLOCKED / FI_BUSY` make an enabled injection visible to monitoring.

## 3. Use (firmware)

```c
sfras_fi_unlock(&dev);                                         /* needs fi_allow_i and a privileged master */
uint32_t m[2] = { 1u << 5, 0 };
sfras_fi_inject_mem(&dev, 0, SFRAS_FI_INPLACE, true, 10, m, 2); /* flip stored bit 5 of word 10 of memory 0 */
sfras_fi_inject_bus(&dev, 0, 1 /* force error */, 0, 0);       /* next response on injector 0 fails */
sfras_fi_relock(&dev);
```

## 4. Simulation-only fault hooks

In addition, the GENERIC SRAM backend (silicaflux-sramlib, unchanged) offers stuck-at / transition / coupling /
address-decoder faults through hierarchical variables (excluded under `SYNTHESIS`); `tb_ecc_sram` uses its stuck-at
fault to produce a hard error that scrub write-back cannot clear.
