# 05 — Poison handling and failure-containment boundaries

Principle: **data associated with an uncorrectable error is either tagged or rejected at every boundary it reaches —
never replaced by zero and passed on as valid.**

## 1. Inside an ECC memory (`sfras_ecc_sram`)

| Situation | Behaviour |
|---|---|
| read of an uncorrectable word | `rsp_err = 1`, `rsp_poison = 1`; `rsp_rdata` = the stored (uncorrected) bits (`UE_ZERO = 0`) or 0 (`UE_ZERO = 1`). Both flags are always set: a consumer can never receive the word without an error indication. |
| read of a poisoned word | same as above; event `POISON` (BIT mode) or `MEM_UE` with info[28] (SIG mode) |
| partial write onto an uncorrectable / poisoned word | NONE: aborted; SIG / BIT: stored **poisoned**; write response `rsp_err = 1` |
| full write onto a poisoned word | clears it (the whole word is new, valid data) |
| scrub of an uncorrectable word | counted, reported, **left uncorrectable** (rewriting it would launder it) |
| scrub of a poisoned word | counted as poisoned, untouched (a correctable bit inside it is fixed, poison preserved) |

**Poison encodings.** `POISON_MODE = BIT` stores the flag as an extra data bit *inside* the code (K+1 data bits): a
poisoned word is a valid codeword with the flag set, so one further upset is corrected and the poison survives.
`POISON_MODE = SIG` stores `encode(data) ^ {check bits R-1, R-2}`: no extra column (keeps 72-bit macros for K = 64),
decodes as UE with a fixed syndrome; two caveats, both quantified in `docs/09` §2: a few genuine double errors share
that syndrome (8 of 2 556 pairs for (72,64): reported as poison, still contained), and a poisoned word hit by one
more upset can decode as a wrong CE. `POISON_MODE = NONE` never creates poison (aborts the partial write).

## 2. At the fabric boundary (`sfras_sfb_ecc_slave`)

SFB2 has a single response error bit. The ECC slave answers `rsp_error = 1` for an uncorrectable or poisoned read
and for a partial write onto one, and additionally drives `rsp_poison` for poison-aware masters. Every existing
SFB2 master already treats `rsp_error` as a failed access:

| Master | Reaction (existing RTL) | Verified |
|---|---|---|
| DataFabric DMA (`silicaflux_dma`) | transfer aborts with `DMA_ERR_READ_BUS`, `ERROR_ADDR` = failing address; **no word after the fault is written** | `tb_ras_system` T6: UE at word 5 of a 16-word copy → words 0–4 copied, 5–15 of the destination untouched |
| ControlCore CPU | load/store access fault (precise exception) | by construction (`cc_ras` BUS path), not simulated here |
| Tensor / HPC DMA adapters | transfer error status | by construction, not simulated here |

## 3. Containment boundaries

```
  ┌──────────── ECC memory ────────────┐   ┌──── SFB2 fabric ────┐   ┌──── consumer ────┐
  │ stored word  ──decode──►  CE: fixed │──►│ rsp_error=1         │──►│ DMA abort / fault │  ① data path: tagged / rejected
  │                           UE: flag  │   │ (+ rsp_poison)      │   │                   │
  └─────────────────────────────────────┘   └─────────────────────┘   └───────────────────┘
          │ event                                 │ parity link events         │
          ▼                                       ▼                            ▼
       silicaflux_ras: log / counters / IRQ ──► FATAL ──► contain_o, fatal_o   ② reporting: never silent
```

1. **Memory boundary** — no uncorrectable data leaves an ECC memory without `rsp_err`/`rsp_poison`.
2. **Fabric boundary** — poison becomes `rsp_error`; a parity-protected link refuses a corrupted *request* (it is
   never executed; a local error response is returned) and flags a corrupted *response*.
3. **Consumer boundary** — the consumer aborts (DMA) or traps (CPU); results computed after the fault are not
   written.
4. **System boundary** — a FATAL event asserts `contain_o` (isolate / stop the accelerators) and `fatal_o`; with
   `FATAL_LOCK` only a reset clears it.

**Where containment does not hold** (also `docs/09` §6): data corrupted *outside* every protected region — inside an
unprotected tensor buffer, in a register file, on an SFB2 segment without a parity link (demonstrated in
`tb_ras_system` T10), or by a ≥ 3-bit upset that aliases to a CE — is not detected. These are listed as single
points of failure, not claimed as covered.
