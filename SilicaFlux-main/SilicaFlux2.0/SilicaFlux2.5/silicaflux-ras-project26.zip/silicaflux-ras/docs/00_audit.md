# 00 — Audit: fault protection in the SilicaFlux RTL before Project 26

Sources inspected (archives in `Aureom.AI/SilicaFlux-main/` and `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`,
read-only): `silicaflux-sramlib`, `silicaflux-memorycore1`, `silicaflux-hpc-m04-scratchpad`, `silicaflux-hpc-m05-dma-adapter`,
`silicaflux-hpc-m08-tile`, `silicaflux-controlcore`, `silicaflux-datafabric`, `silicaflux-datafabric-noc`,
`silicaflux-testcore` / `silicaflux-testcore-p07`, `silicaflux-tensorcore05/06/07`, `silicaflux-tensorcore08`
(with its vendored TC02–TC07), `silicaflux-extmem-bridge-p24`. Every statement below was checked in the RTL, not
only in the documentation.

## 1. Summary

| Area | Module(s) | Storage / path | Protection found | Correction | Reporting |
|---|---|---|---|---|---|
| SRAM wrapper library | `sram_sp`, `sram_1r1w`, `sram_tdp`, `sram_bank_controller`, backends | all on-chip SRAM | **none** (pure storage; raw MBIST test port) | – | – |
| Memory core | `sfmem_banked` (`ECC_MODE`) | LMEM 32 KiB, shared SRAM 256 KiB | **odd byte parity** (default `ECC_MODE=PARITY`), `rdata = 0` + `rsp_error` on a bad lane | no | `ECC_ERR_ADDR/INFO/COUNT`, IRQ |
| | | SECDED | `ECC_MODE=SECDED` **reserved, rejected at elaboration** ("reserved for Project 26") | – | – |
| | `sfmem_cache` | ControlCore D-cache 2 KiB (I-cache optional) | **none** (tags in flops, data in 1RW arrays) | – | – |
| HPC scratchpad | `hpc_scratchpad`, `hpc_spm_bank` (M04) | 64 KiB/tile | odd byte parity **optional**; M08 tile default `SPM_ECC=NONE`; SECDED reserved/rejected | no | `rsp_err_code=PARITY(4)`, code 5 `ECC_UE` reserved |
| ControlCore | `mcu_sram_bank` | IMEM 64 KiB, DMEM 32 KiB | odd byte parity (`SRAM_PARITY=1`), `PAR_INJECT`, `PAR_CHK_EN` | no | `cc_ras` source `MEM_PARITY` (fatal class) |
| | `cc_ras` | – | 12-source RAS block: sticky status, warn/fatal IRQ, counters, first/last address, `FATAL_TO_HOST`, `FATAL_ISOLATE`, `EXT_WARN/EXT_FATAL` level inputs | – | – |
| Tensor unit | TC03 `tensor_operand_buffer` | A+B 2 KiB | **none** | – | ownership refusals only |
| | TC04 `tensor_acc_storage` | accumulators, flip-flops, 8 × 132 b default | **none** | – | – |
| | TC07 `tensor_output_buffer` | `hpc_scratchpad` instance with `ECC_MODE=NONE` | **none** | – | – |
| DataFabric | `sfb_crossbar`, `sfb_rsp_router`, `sfb_error_slave` | SFB2 request/response | **no parity / CRC**; one `rsp_error` bit (decode, access matrix, alignment, slave errors) | – | `cc_ras BUS_DECODE` (ControlCore side) |
| | `sfb_sram_slave` | SRAM targets | **none** | – | – |
| DataFabric NoC | `sfn_*` | flits | **no parity / CRC** | – | – |
| DMA | `silicaflux_dma`, engines | FIFO 8 × 32 b (burst engine) | FIFO unprotected; bus errors abort the transfer (`DMA_ERR_READ_BUS=8`, `WRITE_BUS=9`, `ERROR_ADDR`) | – | DMA IRQ; `cc_ras DMA_ERR` |
| TestCore / MBIST | `silicaflux_mbist`, `tc_mbist`, `sram_mbist_march` | all SRAMs via raw test port | March C-, MATS+, checkerboard, walking 0/1; fail logs; **final scrub element writes all-zero** | – | MBIST result registers |
| External memory bridge | `extmem_*` | ROB / CDC FIFOs | none in RTL; simulation MC model can poison byte ranges → error beats | – | `rsp_error` |

## 2. Findings that shaped the design

1. **SECDED is explicitly reserved for Project 26** in two places (`sfmem_banked` and `hpc_scratchpad`), with documented
   hooks: an encode point, a decode point, a stored-word width parameter, a reserved response code `ECC_UE = 5`, a
   syndrome output and an injection register. The reason given for not implementing it is the byte-write problem
   (word-wide code ⇒ read-modify-write ⇒ bank lock + RAW hazard). → `sfras_ecc_sram` implements exactly that RMW,
   with a port lock that removes the hazard, and documents its cost.
2. **No double encoding rule**: the memory core already has one encode/decode layer above the SRAM library. → the ECC
   wrapper writes the macro with `MASK_WIDTH = 1` (whole codewords only) and must replace — not stack on — an
   existing parity layer.
3. **Parity data substitution**: the parity designs return `rdata = 0` with `rsp_error = 1`. → The ECC wrapper keeps
   `rsp_error` but also raises an explicit `rsp_poison` and, by default, returns the stored (uncorrected) bits, so
   zero is never mistaken for data by a consumer that ignores the error flag; `UE_ZERO = 1` reproduces the legacy
   behaviour where required.
4. **MBIST interaction**: TestCore's March algorithms test raw stored words and end with an all-zero scrub element.
   The all-zero word is a *valid* codeword of a plain extended Hamming code, so a dead row would read as valid zero
   data. → default check-bit inversion makes the all-zero (and, for every K checked, all-ones) word uncorrectable; the
   wrapper re-initialises the array with valid codewords after the test port is released.
5. **SFB2 has a single error bit** and no data/address protection. → poison is carried to the fabric as
   `rsp_error = 1` (every existing master already handles it: CPU access fault, DMA abort); a parity link is provided
   for selected segments; the rest of the fabric is listed as a single point of failure.
6. **The DMA exposes only `irq`**; its `fail / err_code / err_addr` are internal. → `sfras_dma_mon` observes DMA
   failures at its SFB2 port, no change to the DMA RTL.
7. **`cc_ras` already exists** with `EXT_WARN` / `EXT_FATAL` level inputs. → `silicaflux_ras` does not replace it:
   `cc_warn_o` / `cc_fatal_o` drive those inputs, so existing ControlCore firmware sees Project 26 faults immediately.
8. **Tensor storage is entirely unprotected** (operand buffers, accumulators in flip-flops, output buffer). This is
   reported as unprotected capacity; protecting it is a follow-on (see `docs/09`, section 6).

## 3. Capacity inventory (default parameters)

See `docs/09_ras_coverage_report.md` section 1 (generated from the same table, `scripts/ras_report.py`).
