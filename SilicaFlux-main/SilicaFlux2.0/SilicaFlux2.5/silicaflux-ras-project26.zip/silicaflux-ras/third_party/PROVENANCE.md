# Vendored sources (unmodified)

| Directory | Origin (Aureom.AI repository) | Files | Use |
|---|---|---|---|
| `silicaflux-sramlib/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` → `silicaflux-sramlib/rtl/mem/` (Project 01) | `sram_defs.svh`, `sram_backend_1rw.sv`, GENERIC / FPGA / ASIC 1RW backends, ASIC leaf wrappers, macro id/function headers, macro black-box stubs | raw macro under `sfras_ecc_sram` |
| `silicaflux-datafabric/rtl/dma/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-datafabric.zip` → `silicaflux-datafabric/rtl/dma/` | `silicaflux_dma.sv` and its engines / registers / FIFO / defines | real DMA in `tb_ras_system` (containment of poisoned data) |

Each directory has a `SHA256SUMS` file computed on the copies; they are byte-identical to the archive contents.
