// =============================================================================
// SilicaFlux RAS (Project 26) :: tb_event_ctrl
// Unit test of sfras_event_ctrl with deliberately small counters (CNT_W = 4)
// and a small log (LOG_DEPTH = 4) so that saturation and overflow are reached:
//   E1 single events: severity table (every type), record fields, timestamps
//   E2 software escalation (SEV_CFG) and the "never downgrade" rule
//   E3 aggregation: all ports firing in the same cycle, repeatedly -> exact
//      per-type / per-source counts, log keeps the oldest, lost count exact
//   E4 counter saturation at 15 + sticky overflow flags + CNT_OVF + clear
//   E5 first-error capture (lowest port wins a tie) and CLR_FIRST
//   E6 sticky status W1C and FATAL_LOCK
//   E7 reset clears everything
// A reference model counts every event independently of the log.
// Classification: SIMULATION ONLY
// =============================================================================
`include "sfras_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module tb_event_ctrl;
  localparam int NP = 5, LOG_DEPTH = 4, CNT_W = 4, TS_W = 40;
  localparam int RECW = TS_W + 80;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic [NP-1:0] ev_valid = '0, ev_addr_v = '0, ev_corr = '0;
  logic [NP*4-1:0] ev_type = '0;
  logic [NP*32-1:0] ev_addr = '0, ev_info = '0;
  logic [31:0] sev_cfg = '0;
  logic log_en = 1, clr_counts = 0, clr_log = 0, clr_first = 0, pop = 0, ovf_w1c = 0, cnt_ovf_w1c = 0, fatal_lock = 0;
  logic [3:0] sev_w1c = '0;
  logic [15:0] type_w1c = '0;
  logic [TS_W-1:0] ts;
  logic [3:0] sev_seen, ev_sev_mask;
  logic log_ovf, cnt_ovf, log_v, first_v, ev_any;
  logic [15:0] type_seen, type_ovf, log_count, log_lost;
  logic [16*CNT_W-1:0] type_cnt;
  logic [NP*CNT_W-1:0] src_cnt;
  logic [NP-1:0] src_ovf;
  logic [RECW-1:0] log_head, first_rec;

  sfras_event_ctrl #(.NP(NP), .LOG_DEPTH(LOG_DEPTH), .CNT_W(CNT_W), .TS_W(TS_W)) dut (.*);

  int errors = 0;
  task automatic fail(input string m);
    errors++;
    if (errors <= 30) $display("FAIL @%0t: %s", $time, m);
  endtask

  // reference counters
  int r_type [16];
  int r_src  [NP];
  function automatic int sat(input int v); return (v > 15) ? 15 : v; endfunction
  task automatic check_counts(input string w);
    for (int t = 0; t < 16; t++) begin
      if (int'(type_cnt[t*CNT_W +: CNT_W]) != sat(r_type[t])) fail($sformatf("%s: type %0d count %0d exp %0d", w, t, type_cnt[t*CNT_W +: CNT_W], sat(r_type[t])));
      if (type_ovf[t] !== (r_type[t] > 15)) fail($sformatf("%s: type %0d ovf %b", w, t, type_ovf[t]));
    end
    for (int p = 0; p < NP; p++) begin
      if (int'(src_cnt[p*CNT_W +: CNT_W]) != sat(r_src[p])) fail($sformatf("%s: src %0d count %0d exp %0d", w, p, src_cnt[p*CNT_W +: CNT_W], sat(r_src[p])));
      if (src_ovf[p] !== (r_src[p] > 15)) fail($sformatf("%s: src %0d ovf %b", w, p, src_ovf[p]));
    end
  endtask
  task automatic clear_ref();
    for (int t = 0; t < 16; t++) r_type[t] = 0;
    for (int p = 0; p < NP; p++) r_src[p] = 0;
  endtask

  // fire a set of events in one cycle
  task automatic fire(input logic [NP-1:0] which, input logic [NP*4-1:0] t, input logic [31:0] info0);
    // whole-vector assignments (Verilator 5.020 --timing drops part-select writes to
    // module variables made from inside a task loop)
    logic [NP*32-1:0] a, inf;
    logic [NP-1:0]    c;
    for (int p = 0; p < NP; p++) begin
      a[p*32 +: 32]   = 32'h1000 + p;
      inf[p*32 +: 32] = info0 + p;
      c[p]            = (t[p*4 +: 4] == `SFRAS_EV_MEM_CE);
      if (which[p]) begin r_type[t[p*4 +: 4]]++; r_src[p]++; end
    end
    ev_type = t; ev_addr = a; ev_info = inf; ev_corr = c; ev_addr_v = '1;
    ev_valid = which;
    @(posedge clk); #1;
    ev_valid = '0;
  endtask

  task automatic do_pop(); pop = 1; @(posedge clk); #1; pop = 0; endtask

  // fields of a record
  function automatic logic [7:0] f_src(input logic [RECW-1:0] r); return r[79:72]; endfunction
  function automatic logic [3:0] f_type(input logic [RECW-1:0] r); return r[71:68]; endfunction
  function automatic logic [1:0] f_sev(input logic [RECW-1:0] r); return r[67:66]; endfunction
  function automatic logic [TS_W-1:0] f_ts(input logic [RECW-1:0] r); return r[RECW-1 -: TS_W]; endfunction

  logic [NP*4-1:0] tv;
  logic [1:0] exp_sev [16];
  logic [TS_W-1:0] t_first;
  logic [7:0] src_prev;

  initial begin
    clear_ref();
    exp_sev[0] = `SFRAS_SEV_WARN;   exp_sev[1] = `SFRAS_SEV_INFO;   exp_sev[2] = `SFRAS_SEV_ERROR;
    exp_sev[3] = `SFRAS_SEV_ERROR;  exp_sev[4] = `SFRAS_SEV_ERROR;  exp_sev[5] = `SFRAS_SEV_ERROR;
    exp_sev[6] = `SFRAS_SEV_WARN;   exp_sev[7] = `SFRAS_SEV_FATAL;  exp_sev[8] = `SFRAS_SEV_WARN;
    exp_sev[9] = `SFRAS_SEV_ERROR;  exp_sev[10] = `SFRAS_SEV_WARN;  exp_sev[11] = `SFRAS_SEV_ERROR;
    exp_sev[12] = `SFRAS_SEV_INFO;  exp_sev[13] = `SFRAS_SEV_WARN;  exp_sev[14] = `SFRAS_SEV_WARN;
    exp_sev[15] = `SFRAS_SEV_WARN;
    repeat (2) @(posedge clk);
    #1 rst_n = 1;
    @(posedge clk); #1;

    // ---- E1 severity table, one type at a time on port 2, popping each
    for (int t = 0; t < 16; t++) begin
      for (int p = 0; p < NP; p++) tv[p*4 +: 4] = 4'(t);
      fire(5'b00100, tv, (t == `SFRAS_EV_WDOG) ? 32'd0 : 32'd100);
      repeat (2) @(posedge clk); #1;
      if (!log_v) fail($sformatf("E1 type %0d not logged", t));
      if (f_type(log_head) != 4'(t) || f_src(log_head) != 8'd2 || f_sev(log_head) != exp_sev[t])
        fail($sformatf("E1 type %0d: logged type %0d src %0d sev %0d exp sev %0d", t, f_type(log_head), f_src(log_head), f_sev(log_head), exp_sev[t]));
      if (log_head[63:32] != 32'h1002) fail("E1 address");
      do_pop();
    end
    // watchdog stage 2 is FATAL
    for (int p = 0; p < NP; p++) tv[p*4 +: 4] = `SFRAS_EV_WDOG;
    fire(5'b00001, tv, 32'd1);
    repeat (2) @(posedge clk); #1;
    if (f_sev(log_head) != `SFRAS_SEV_FATAL) fail("E1 watchdog stage 2 not FATAL");
    do_pop();
    check_counts("E1");
    if (sev_seen != 4'b1111) fail($sformatf("E1 sev_seen %b", sev_seen));
    $display("RESULT E1 severity: hardware minimum severity correct for all 16 type codes (+ watchdog stage 2)");

    // ---- E2 software escalation, no downgrade
    sev_cfg = '0;
    sev_cfg[`SFRAS_EV_MEM_UE*2 +: 2]    = `SFRAS_SEV_FATAL;    // escalate UE
    sev_cfg[`SFRAS_EV_THERM_FATAL*2 +: 2] = `SFRAS_SEV_INFO;   // attempt to downgrade
    for (int p = 0; p < NP; p++) tv[p*4 +: 4] = (p == 0) ? `SFRAS_EV_MEM_UE : `SFRAS_EV_THERM_FATAL;
    fire(5'b00011, tv, 32'd0);
    repeat (3) @(posedge clk); #1;
    if (f_sev(log_head) != `SFRAS_SEV_FATAL) fail("E2 UE not escalated"); do_pop();
    if (f_sev(log_head) != `SFRAS_SEV_FATAL) fail("E2 thermal fatal downgraded"); do_pop();
    sev_cfg = '0;
    $display("RESULT E2 severity policy: escalation applied, downgrade of FATAL refused");

    // ---- E3 aggregation: all ports, 6 consecutive cycles (30 events) into a 4-entry log
    clr_counts = 1; clr_log = 1; @(posedge clk); #1; clr_counts = 0; clr_log = 0;
    clear_ref();
    ovf_w1c = 1; @(posedge clk); #1; ovf_w1c = 0;
    for (int c = 0; c < 6; c++) begin
      for (int p = 0; p < NP; p++) tv[p*4 +: 4] = 4'(1 + ((p + c) % 3));
      fire('1, tv, 32'(c * 16));
    end
    repeat (NP + 3) @(posedge clk); #1;
    check_counts("E3");
    // slots: 5 accepted in cycle 0; subsequent same-port events while the slot waits are lost;
    // the log takes 4 and keeps the oldest.  Logged + lost must equal 30.
    if (int'(log_count) != LOG_DEPTH) fail($sformatf("E3 log count %0d", log_count));
    if (int'(log_count) + int'(log_lost) != 30)
      fail($sformatf("E3 logged %0d + lost %0d != 30", log_count, log_lost));
    if (!log_ovf) fail("E3 LOG_OVF not set");
    t_first = f_ts(log_head);
    src_prev = f_src(log_head);
    for (int i = 0; i < LOG_DEPTH; i++) begin
      if (f_ts(log_head) != t_first) fail("E3 logged entries are not the first (oldest) cycle's events");
      if (i > 0 && f_src(log_head) != 8'((int'(src_prev) + 1) % NP))
        fail($sformatf("E3 round-robin order: entry %0d src %0d after %0d", i, f_src(log_head), src_prev));
      src_prev = f_src(log_head);
      do_pop();
    end
    if (log_v) fail("E3 log not empty after pops");
    $display("RESULT E3 aggregation: 30 simultaneous events from %0d ports counted exactly; log kept the %0d oldest, %0d reported lost (LOG_OVF)", NP, LOG_DEPTH, log_lost);

    // ---- E4 counter saturation
    clr_counts = 1; clr_log = 1; @(posedge clk); #1; clr_counts = 0; clr_log = 0; clear_ref();
    cnt_ovf_w1c = 1; @(posedge clk); #1; cnt_ovf_w1c = 0;
    for (int c = 0; c < 20; c++) begin
      for (int p = 0; p < NP; p++) tv[p*4 +: 4] = `SFRAS_EV_MEM_CE;
      fire(5'b00011, tv, 32'd0);                         // 2 CE per cycle -> type count 40, sources 20 each
    end
    @(posedge clk); #1;
    check_counts("E4");
    if (!cnt_ovf || !type_ovf[`SFRAS_EV_MEM_CE] || !src_ovf[0] || !src_ovf[1] || src_ovf[2]) fail("E4 overflow flags");
    clr_counts = 1; @(posedge clk); #1; clr_counts = 0; clear_ref();
    check_counts("E4 clear");
    cnt_ovf_w1c = 1; @(posedge clk); #1; cnt_ovf_w1c = 0;
    if (cnt_ovf) fail("E4 CNT_OVF not cleared");
    $display("RESULT E4 counter overflow: %0d-bit counters saturate at %0d, sticky per-counter and global overflow flags, clear works", CNT_W, (1 << CNT_W) - 1);

    // ---- E5 first error
    clr_first = 1; @(posedge clk); #1; clr_first = 0;
    for (int p = 0; p < NP; p++) tv[p*4 +: 4] = `SFRAS_EV_MEM_CE;
    fire(5'b11111, tv, 0);                                // INFO only: no capture
    if (first_v) fail("E5 INFO captured as first error");
    for (int p = 0; p < NP; p++) tv[p*4 +: 4] = (p >= 3) ? `SFRAS_EV_MEM_UE : `SFRAS_EV_MEM_CE;
    fire(5'b11000, tv, 32'hA0);                           // ports 3 and 4 tie: 3 wins
    for (int p = 0; p < NP; p++) tv[p*4 +: 4] = `SFRAS_EV_DMA_ERR;
    fire(5'b00001, tv, 32'hB0);                           // later error: ignored
    if (!first_v || f_src(first_rec) != 8'd3 || f_type(first_rec) != `SFRAS_EV_MEM_UE || first_rec[31:0] != 32'hA3)
      fail($sformatf("E5 first record src %0d type %0d info %h", f_src(first_rec), f_type(first_rec), first_rec[31:0]));
    clr_first = 1; @(posedge clk); #1; clr_first = 0;
    if (first_v) fail("E5 CLR_FIRST");
    $display("RESULT E5 first-error capture: first ERROR-or-worse event frozen (lowest port on a tie), INFO ignored");

    // ---- E6 W1C and FATAL_LOCK
    sev_w1c = 4'b1111; type_w1c = '1; @(posedge clk); #1; sev_w1c = '0; type_w1c = '0;
    if (sev_seen != 0 || type_seen != 0) fail("E6 W1C");
    for (int p = 0; p < NP; p++) tv[p*4 +: 4] = `SFRAS_EV_THERM_FATAL;
    fire(5'b00001, tv, 0);
    fatal_lock = 1;
    sev_w1c = 4'b1111; @(posedge clk); #1; sev_w1c = '0;
    if (sev_seen != 4'b1000) fail($sformatf("E6 FATAL_LOCK: sev_seen %b", sev_seen));
    $display("RESULT E6 sticky status: W1C clears, SEEN_FATAL survives W1C once FATAL_LOCK is set");

    // ---- E7 reset
    #2 rst_n = 0; #20 rst_n = 1; fatal_lock = 0;
    @(posedge clk); #1;
    clear_ref();
    check_counts("E7");
    if (sev_seen != 0 || type_seen != 0 || log_v || first_v || log_lost != 0 || cnt_ovf || log_ovf || ts > 2)
      fail("E7 reset state");
    $display("RESULT E7 reset: counters, log, first error, sticky status and timestamp cleared");

    if (errors == 0) $display("PASS tb_event_ctrl");
    else             $display("FAIL tb_event_ctrl: %0d errors", errors);
    $finish;
  end
endmodule

`default_nettype wire
