// =============================================================================
// SilicaFlux RAS (Project 26) :: tb_ecc_sram
// sfras_ecc_sram + sfras_scrub against a reference model that tracks, for every
// word: data, poison state and the XOR "error mask" between the ideal stored
// codeword and what is physically stored (plus an optional stuck-at cell).  The
// expected class of a read follows from the error weight alone (0 clean, 1
// corrected, 2 uncorrectable): that is the SECDED guarantee, independent of the
// decoder implementation (which tb_secded proves bit-exact separately).
//
// Checked continuously (every cycle, every access, in order):
//   * every functional response: data, err, ce, poison, we, id;
//   * every RAS event: ce / ue / poison / origin / address / corrected-bit index;
//   * every scrub response class; scrub counters at the end of each phase;
//   * fault-injection fire pulses;
//   * the physical array content (backdoor) against ideal ^ error mask.
// Phases: init, random traffic with back-pressure, every single-bit error
// position (in-place injection), double-bit errors (all pairs up to N = 40 bits,
// otherwise a structured set), read-path / write-path injection, partial writes
// on clean / correctable / uncorrectable / poisoned words, scrub correction,
// scrub UE stop policy, stuck-at cell (recovery failure), injected recovery
// fault, MBIST hand-over and re-initialisation, invalid address / strobe,
// reset during traffic, contention and scrub-interference measurement.
// Classification: SIMULATION ONLY
// =============================================================================
`include "sram_defs.svh"
`include "sfras_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module tb_ecc_sram #(
  parameter int K            = 64,
  parameter int DEPTH        = 64,
  parameter int READ_LATENCY = 1,
  parameter int DEC_PIPE     = 0,
  parameter int POISON_MODE  = `SFRAS_POISON_BIT,
  parameter int BYTE_EN      = 1,
  parameter int UE_ZERO      = 0,
  parameter int SEED         = 1
);
  `include "sfras_ecc_funcs.svh"
  localparam int KC  = K + ((POISON_MODE == `SFRAS_POISON_BIT) ? 1 : 0);
  localparam int R   = $clog2(KC + $clog2(KC + 1) + 1);
  localparam int N   = KC + R + 1;
  localparam int IW  = $clog2(N);
  localparam int MW  = (BYTE_EN != 0 && (K % 8) == 0) ? K / 8 : 1;
  localparam int AW  = (DEPTH > 1) ? $clog2(DEPTH) : 1;
  localparam int INV = sfras_ecc_default_inv(KC);
  localparam logic [R-1:0] SIG_C  = R'((1 << (R - 1)) | (1 << (R - 2)));
  localparam logic [N-1:0] SIG_CW = N'(SIG_C) << KC;
  localparam int ID_W = 4;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- DUT
  logic            req_valid, req_ready, req_we;
  logic [AW-1:0]   req_addr;
  logic [K-1:0]    req_wdata;
  logic [MW-1:0]   req_wmask;
  logic [ID_W-1:0] req_id;
  logic            rsp_valid, rsp_ready, rsp_err, rsp_ce, rsp_poison, rsp_we;
  logic [K-1:0]    rsp_rdata;
  logic [ID_W-1:0] rsp_id;
  logic            scr_req_valid, scr_req_ready, scr_rsp_valid, scr_rsp_ce, scr_rsp_ue, scr_rsp_poison, scr_rsp_wb;
  logic [1:0]      scr_req_op, scr_rsp_op;
  logic [AW-1:0]   scr_req_addr, scr_rsp_addr;
  logic            init_req, init_busy, init_done;
  logic            tst_active, tst_ready, tst_ce, tst_we;
  logic [AW-1:0]   tst_addr;
  logic [N-1:0]    tst_wdata, tst_rdata;
  logic            ev_valid, ev_ce, ev_ue, ev_poison;
  logic [2:0]      ev_org;
  logic [AW-1:0]   ev_addr;
  logic [R:0]      ev_syn;
  logic [IW-1:0]   ev_idx;
  logic            fi_arm, fi_addr_en, fi_armed, fi_fired;
  logic [1:0]      fi_mode;
  logic [N-1:0]    fi_mask;
  logic [AW-1:0]   fi_addr, fi_fired_addr;
  logic            busy, perf_lock, perf_rmw;

  sfras_ecc_sram #(
    .K(K), .DEPTH(DEPTH), .READ_LATENCY(READ_LATENCY), .BACKEND(`SRAM_BACKEND_GENERIC), .BYTE_EN(BYTE_EN),
    .WRITE_ACK(1), .ID_W(ID_W), .DEC_PIPE(DEC_PIPE), .POISON_MODE(POISON_MODE), .UE_ZERO(UE_ZERO),
    .INIT_ON_RESET(1), .REINIT_AFTER_TEST(1), .TEST_EN(1), .SCRUB_MAX_WAIT(8), .FI_EN(1)
  ) u_dut (
    .clk, .rst_n,
    .req_valid, .req_ready, .req_we, .req_addr, .req_wdata, .req_wmask, .req_id,
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_err, .rsp_ce, .rsp_poison, .rsp_we, .rsp_id,
    .scr_req_valid, .scr_req_ready, .scr_req_op, .scr_req_addr,
    .scr_rsp_valid, .scr_rsp_op, .scr_rsp_addr, .scr_rsp_ce, .scr_rsp_ue, .scr_rsp_poison, .scr_rsp_wb,
    .init_req_i(init_req), .init_busy_o(init_busy), .init_done_o(init_done),
    .tst_active, .tst_ready, .tst_ce, .tst_we, .tst_addr, .tst_wdata, .tst_rdata,
    .ev_valid, .ev_ce, .ev_ue, .ev_poison, .ev_org, .ev_addr, .ev_syn, .ev_idx,
    .fi_arm_i(fi_arm), .fi_mode_i(fi_mode), .fi_mask_i(fi_mask), .fi_addr_en_i(fi_addr_en), .fi_addr_i(fi_addr),
    .fi_armed_o(fi_armed), .fi_fired_o(fi_fired), .fi_fired_addr_o(fi_fired_addr),
    .busy, .perf_lock_o(perf_lock), .perf_rmw_o(perf_rmw)
  );

  // scrub engine
  logic            s_en, s_start, s_one, s_fix, s_ver, s_stop, s_clr;
  logic [23:0]     s_int;
  logic [AW-1:0]   s_lo, s_hi;
  logic            s_active, s_stopped, s_done, s_ue_seen, s_ovf, rec_v, rec_ue;
  logic [AW-1:0]   s_cur, s_ue_addr, rec_addr;
  logic [31:0]     c_pass, c_ce, c_fix, c_ue, c_pois, c_hard, c_rd;
  sfras_scrub #(.AW(AW), .CNT_W(32), .IVW(24)) u_scrub (
    .clk, .rst_n, .en(s_en), .start(s_start), .one_pass(s_one), .fix_en(s_fix), .verify_en(s_ver),
    .stop_on_ue(s_stop), .interval(s_int), .addr_lo(s_lo), .addr_hi(s_hi), .clr_counts(s_clr),
    .scr_req_valid, .scr_req_ready, .scr_req_op, .scr_req_addr,
    .scr_rsp_valid, .scr_rsp_op, .scr_rsp_addr, .scr_rsp_ce, .scr_rsp_ue, .scr_rsp_poison, .scr_rsp_wb,
    .active(s_active), .stopped_ue(s_stopped), .done(s_done), .cur_addr(s_cur), .ue_addr(s_ue_addr),
    .ue_seen(s_ue_seen), .pass_count(c_pass), .ce_count(c_ce), .fix_count(c_fix), .ue_count(c_ue),
    .poison_count(c_pois), .hard_count(c_hard), .read_count(c_rd), .cnt_ovf(s_ovf),
    .ev_rec_valid(rec_v), .ev_rec_addr(rec_addr), .ev_rec_ue(rec_ue)
  );

  // ---------------------------------------------------------------- reference model
  logic [K-1:0] m_data [DEPTH];
  logic         m_pois [DEPTH];
  logic [N-1:0] m_emask[DEPTH];
  int           stuck_addr = -1, stuck_bit = 0, stuck_val = 0;

  function automatic logic [N-1:0] ideal_cw(input logic [K-1:0] d, input logic p);
    logic [KC-1:0] dc;
    logic [R-1:0]  c;
    logic          par;
    logic [N-1:0]  cw;
    dc = '0;
    dc[K-1:0] = d;
    if (POISON_MODE == `SFRAS_POISON_BIT) dc[KC-1] = p;
    c = '0;
    for (int i = 0; i < KC; i++) if (dc[i]) c = c ^ R'(sfras_ecc_dpos(i));
    par = (^dc) ^ (^c);
    cw = {par, c, dc} ^ (N'(INV) << KC);
    if (POISON_MODE == `SFRAS_POISON_SIG && p) cw = cw ^ SIG_CW;
    return cw;
  endfunction

  // effective error mask seen by a read of word a (stored errors + stuck cell)
  function automatic logic [N-1:0] eff_emask(input int a);
    logic [N-1:0] e, ic;
    e = m_emask[a];
    if (a == stuck_addr) begin
      ic = ideal_cw(m_data[a], m_pois[a]);
      e[stuck_bit] = ic[stuck_bit] ^ logic'(stuck_val[0]);
    end
    return e;
  endfunction

  // Hamming syndrome of an error pattern (XOR of the positions of the flipped bits)
  function automatic logic [R-1:0] syn_of(input logic [N-1:0] e);
    logic [R-1:0] sy;
    sy = '0;
    for (int b = 0; b < N - 1; b++) if (e[b]) sy = sy ^ R'(sfras_ecc_hpos(KC, b));
    return sy;
  endfunction

  function automatic int popc(input logic [N-1:0] v);
    int c;
    c = 0;
    for (int i = 0; i < N; i++) c += v[i] ? 1 : 0;
    return c;
  endfunction
  function automatic int lowbit(input logic [N-1:0] v);
    int r;
    r = -1;
    for (int i = N - 1; i >= 0; i--) if (v[i]) r = i;
    return r;
  endfunction

  // decode outcome predicted from the error pattern (for SIG-poisoned words the
  // only pattern used is "no extra error": the signature itself decodes UE)
  typedef struct packed {
    logic ce, ue, pois;
    logic [N-1:0] e;
  } pred_t;
  function automatic pred_t predict(input int a, input logic [N-1:0] extra);
    pred_t pr;
    int w;
    pr.e = eff_emask(a) ^ extra;
    w = popc(pr.e);
    if (w > 2) $fatal(1, "TB model: weight %0d error pattern on word %0d is outside the modelled fault set", w, a);
    pr.ce = 1'b0; pr.ue = 1'b0; pr.pois = 1'b0;
    if (POISON_MODE == `SFRAS_POISON_SIG && m_pois[a]) begin
      if (w != 0) $fatal(1, "TB model: extra errors on a SIG-poisoned word are not modelled");
      pr.ue = 1'b1; pr.pois = 1'b1;
    end else begin
      pr.ce   = (w == 1);
      pr.ue   = (w == 2);
      pr.pois = (POISON_MODE == `SFRAS_POISON_BIT) && !pr.ue && m_pois[a];
      // SIG mode limitation (documented, quantified in the coverage report): a genuine
      // double error whose syndrome equals the signature is indistinguishable from poison
      if (POISON_MODE == `SFRAS_POISON_SIG && w == 2 && syn_of(pr.e) == SIG_C) pr.pois = 1'b1;
    end
    return pr;
  endfunction

  // ---------------------------------------------------------------- expectation FIFOs
  localparam int QN = 256;
  logic [K+4+ID_W-1:0] rq [QN];  int rq_h = 0, rq_t = 0;               // responses {rdata, err, ce, pois, we, id}
  logic [3+3+AW+IW+1-1:0] eq [QN]; int eq_h = 0, eq_t = 0;             // events {ce, ue, pois, org, addr, idx, idx_chk}
  logic [2+3+AW+3-1:0] sq [QN]; int sq_h = 0, sq_t = 0;                  // scrub responses {op?, ce, ue, pois, addr, ...}
  int errors = 0, n_rsp = 0, n_ev = 0, n_ev_ce = 0, n_ev_ue = 0, n_ev_pois = 0, n_scr = 0;
  int n_fi_fired_exp = 0, n_fi_fired = 0;
  int n_single_pos = 0, n_double = 0;

  task automatic fail(input string m);
    errors++;
    if (errors <= 30) $display("FAIL @%0t: %s", $time, m);
  endtask

  // TB-side mirror of the armed injection (write/read modes are predicted at acceptance)
  logic         t_fi_armed = 1'b0;
  logic [1:0]   t_fi_mode;
  logic [N-1:0] t_fi_mask;
  logic         t_fi_aen;
  logic [AW-1:0] t_fi_addr;

  // ---------------------------------------------------------------- monitor: model updates + checks
  logic         rmw_pend_fi;
  always @(posedge clk) begin
    if (rst_n) begin
      // (1) model updates by locked internal operations (no acceptance can coincide)
      if (scr_rsp_valid && scr_rsp_wb) begin
        m_emask[scr_rsp_addr] = '0;
        if (t_fi_armed && t_fi_mode == `SFRAS_FI_SCRUB_WB && (!t_fi_aen || t_fi_addr == scr_rsp_addr)) begin
          m_emask[scr_rsp_addr] = t_fi_mask; t_fi_armed = 1'b0; n_fi_fired_exp++;
        end
      end
      if (u_dut.fi_go) begin
        // in-place injection issues now; model the write-back (stored ^ mask)
        m_emask[fi_addr] = m_emask[fi_addr] ^ t_fi_mask;
        t_fi_armed = 1'b0; n_fi_fired_exp++;
      end
      // (2) acceptances
      if (req_valid && req_ready) accept_functional();
      if (scr_req_valid && scr_req_ready) accept_scrub();
      // (3) checks
      if (rsp_valid && rsp_ready) check_response();
      if (ev_valid) check_event();
      if (scr_rsp_valid) check_scrub_rsp();
      if (fi_fired) n_fi_fired++;
    end
  end

  task automatic push_rsp(input logic [K-1:0] d, input logic e, c, p, w, input logic [ID_W-1:0] id);
    rq[rq_t % QN] = {d, e, c, p, w, id}; rq_t++;
  endtask
  task automatic push_ev(input logic c, u, p, input logic [2:0] org, input logic [AW-1:0] a, input int idx);
    eq[eq_t % QN] = {c, u, p, org, a, IW'(idx < 0 ? 0 : idx), logic'(idx >= 0)}; eq_t++;
  endtask

  task automatic accept_functional();
    int a;
    pred_t pr;
    logic [N-1:0] rmask;
    logic bad;
    logic [K-1:0] newd;
    a = int'(req_addr);
    if (a >= DEPTH) begin
      push_rsp('0, 1'b1, 1'b0, 1'b0, req_we, req_id);
    end else if (!req_we) begin
      rmask = '0;
      if (t_fi_armed && t_fi_mode == `SFRAS_FI_READ && (!t_fi_aen || t_fi_addr == req_addr)) begin
        rmask = t_fi_mask; t_fi_armed = 1'b0; n_fi_fired_exp++;
      end
      pr  = predict(a, rmask);
      bad = pr.ue || pr.pois;
      push_rsp((bad && UE_ZERO != 0) ? '0 : (pr.ue ? (m_data[a] ^ pr.e[K-1:0]) : m_data[a]),
               bad, pr.ce, bad, 1'b0, req_id);
      if (pr.ce || pr.ue || pr.pois) push_ev(pr.ce, pr.ue, pr.pois, `SFRAS_ORG_READ, req_addr, pr.ce ? lowbit(pr.e) : -1);
    end else if (req_wmask == '1 || req_wmask == '0) begin
      if (req_wmask != '0) begin
        m_data[a] = req_wdata; m_pois[a] = 1'b0; m_emask[a] = '0;
        if (t_fi_armed && t_fi_mode == `SFRAS_FI_WRITE && (!t_fi_aen || t_fi_addr == req_addr)) begin
          m_emask[a] = t_fi_mask; t_fi_armed = 1'b0; n_fi_fired_exp++;
        end
      end
      push_rsp('0, 1'b0, 1'b0, 1'b0, 1'b1, req_id);
    end else if (BYTE_EN == 0 || MW == 1) begin
      push_rsp('0, 1'b1, 1'b0, 1'b0, 1'b1, req_id);      // strobe refused, no side effect
    end else begin
      // read-modify-write
      pr  = predict(a, '0);
      bad = pr.ue || pr.pois;
      newd = pr.ue ? (m_data[a] ^ pr.e[K-1:0]) : m_data[a];
      for (int l = 0; l < MW; l++) if (req_wmask[l]) newd[l*8 +: 8] = req_wdata[l*8 +: 8];
      if (pr.ce || pr.ue || pr.pois) push_ev(pr.ce, pr.ue, pr.pois, `SFRAS_ORG_RMW, req_addr, pr.ce ? lowbit(pr.e) : -1);
      push_rsp('0, bad, pr.ce, 1'b0, 1'b1, req_id);
      rmw_pend_fi = t_fi_armed && t_fi_mode == `SFRAS_FI_WRITE && (!t_fi_aen || t_fi_addr == req_addr);
      if (rmw_pend_fi) begin t_fi_armed = 1'b0; n_fi_fired_exp++; end
      if (!bad || POISON_MODE != `SFRAS_POISON_NONE) begin
        m_data[a]  = newd;
        m_pois[a]  = bad;
        m_emask[a] = rmw_pend_fi ? t_fi_mask : '0;
      end
    end
  endtask

  task automatic accept_scrub();
    int a;
    pred_t pr;
    a  = int'(scr_req_addr);
    pr = predict(a, '0);
    sq[sq_t % QN] = {scr_req_op, pr.ce, pr.ue, pr.pois, scr_req_addr, 3'b000}; sq_t++;
    case (scr_req_op)
      `SFRAS_SCR_CHECK:  if (pr.ce || pr.ue || pr.pois) push_ev(pr.ce, pr.ue, pr.pois, `SFRAS_ORG_SCRUB, scr_req_addr, pr.ce ? lowbit(pr.e) : -1);
      `SFRAS_SCR_VERIFY: if (pr.ce || pr.ue || pr.pois) push_ev(pr.ce, pr.ue, pr.pois, `SFRAS_ORG_SCRUB_VERIFY, scr_req_addr, pr.ce ? lowbit(pr.e) : -1);
      default:           if (pr.ue) push_ev(pr.ce, pr.ue, pr.pois, `SFRAS_ORG_SCRUB_FIX, scr_req_addr, -1);
    endcase
  endtask

  task automatic check_response();
    logic [K-1:0] d; logic e, c, p, w; logic [ID_W-1:0] id;
    n_rsp++;
    if (rq_h == rq_t) fail("unexpected response");
    else begin
    {d, e, c, p, w, id} = rq[rq_h % QN]; rq_h++;
    if ({rsp_rdata, rsp_err, rsp_ce, rsp_poison, rsp_we, rsp_id} !== {d, e, c, p, w, id})
      fail($sformatf("response: got d=%h err=%b ce=%b pois=%b we=%b id=%0d exp d=%h err=%b ce=%b pois=%b we=%b id=%0d",
                     rsp_rdata, rsp_err, rsp_ce, rsp_poison, rsp_we, rsp_id, d, e, c, p, w, id));
    end
  endtask

  task automatic check_event();
    logic c, u, p, ic; logic [2:0] org; logic [AW-1:0] a; logic [IW-1:0] idx;
    n_ev++;
    if (ev_ce) n_ev_ce++;
    if (ev_ue) n_ev_ue++;
    if (ev_poison) n_ev_pois++;
    if (eq_h == eq_t) fail($sformatf("unexpected event org=%0d addr=%0d ce=%b ue=%b", ev_org, ev_addr, ev_ce, ev_ue));
    else begin
    {c, u, p, org, a, idx, ic} = eq[eq_h % QN]; eq_h++;
    if ({ev_ce, ev_ue, ev_poison, ev_org, ev_addr} !== {c, u, p, org, a})
      fail($sformatf("event: got ce=%b ue=%b pois=%b org=%0d addr=%0d exp ce=%b ue=%b pois=%b org=%0d addr=%0d",
                     ev_ce, ev_ue, ev_poison, ev_org, ev_addr, c, u, p, org, a));
    if (ic && ev_idx !== idx) fail($sformatf("event: corrected bit index %0d exp %0d", ev_idx, idx));
    end
  endtask

  task automatic check_scrub_rsp();
    logic [1:0] op; logic c, u, p; logic [AW-1:0] a; logic [2:0] x;
    n_scr++;
    if (sq_h == sq_t) fail("unexpected scrub response");
    else begin
    {op, c, u, p, a, x} = sq[sq_h % QN]; sq_h++;
    if ({scr_rsp_op, scr_rsp_ce, scr_rsp_ue, scr_rsp_poison, scr_rsp_addr} !== {op, c, u, p, a})
      fail($sformatf("scrub rsp: got op=%0d ce=%b ue=%b pois=%b addr=%0d exp op=%0d ce=%b ue=%b pois=%b addr=%0d",
                     scr_rsp_op, scr_rsp_ce, scr_rsp_ue, scr_rsp_poison, scr_rsp_addr, op, c, u, p, a));
    if (scr_rsp_wb !== (op == `SFRAS_SCR_FIX && c)) fail("scrub write-back flag");
    end
  endtask

  // ---------------------------------------------------------------- stimulus helpers
  int unsigned rnd_state;
  function automatic int unsigned rnd();
    rnd_state = rnd_state * 1103515245 + 12345;
    return rnd_state ^ (rnd_state >> 13);
  endfunction
  function automatic logic [K-1:0] rnd_data();
    logic [K-1:0] d;
    for (int i = 0; i < K; i += 16) d[i +: 16] = 16'(rnd());
    return d;
  endfunction

  int rr_mode = 0;    // response-ready: 0 always 1, 1 random
  always @(posedge clk) begin
    #1;
    rsp_ready <= (rr_mode == 0) ? 1'b1 : ((rnd() & 3) != 0);
  end

  task automatic req(input logic we, input int a, input logic [K-1:0] d, input logic [MW-1:0] m);
    req_valid = 1'b1; req_we = we; req_addr = AW'(a); req_wdata = d; req_wmask = m; req_id = req_id + 1'b1;
    @(posedge clk);
    while (!req_ready) @(posedge clk);
    #1;
    req_valid = 1'b0;
  endtask
  task automatic rd(input int a);                              req(1'b0, a, '0, '0); endtask
  task automatic wr(input int a, input logic [K-1:0] d);       req(1'b1, a, d, '1);  endtask

  task automatic drain();
    int t;
    t = 0;
    while ((rq_h != rq_t || busy || scr_req_valid && s_en) && t < 20000) begin @(posedge clk); t++; end
    repeat (4) @(posedge clk);
    #1;
    if (rq_h != rq_t) fail($sformatf("%0d responses missing after drain", rq_t - rq_h));
    if (eq_h != eq_t) fail($sformatf("%0d events missing after drain", eq_t - eq_h));
    if (sq_h != sq_t) fail($sformatf("%0d scrub responses missing after drain", sq_t - sq_h));
  endtask

  task automatic arm(input logic [1:0] mode, input logic [N-1:0] mask, input logic aen, input int a);
    while (fi_armed) @(posedge clk);
    #1;
    fi_mode = mode; fi_mask = mask; fi_addr_en = aen; fi_addr = AW'(a); fi_arm = 1'b1;
    t_fi_mode = mode; t_fi_mask = mask; t_fi_aen = aen; t_fi_addr = AW'(a);
    @(posedge clk); #1;
    fi_arm = 1'b0;
    t_fi_armed = 1'b1;
  endtask
  task automatic inject_inplace(input int a, input logic [N-1:0] mask);
    arm(`SFRAS_FI_INPLACE, mask, 1'b1, a);
    while (fi_armed) @(posedge clk);
    #1;
  endtask

  task automatic backdoor_check(input string where);
    logic [N-1:0] exp, got;
    int bad;
    bad = 0;
    for (int a = 0; a < DEPTH; a++) begin
      got = u_dut.u_array.g_generic.u_mem.mem[a];
      exp = ideal_cw(m_data[a], m_pois[a]) ^ m_emask[a];
      if (a == stuck_addr) begin got[stuck_bit] = 1'b0; exp[stuck_bit] = 1'b0; end
      if (got !== exp) begin
        bad++;
        if (bad <= 3) fail($sformatf("%s: stored word %0d = %h, model %h", where, a, got, exp));
      end
    end
  endtask

  task automatic model_reset();
    for (int a = 0; a < DEPTH; a++) begin m_data[a] = '0; m_pois[a] = 1'b0; m_emask[a] = '0; end
    rq_h = 0; rq_t = 0; eq_h = 0; eq_t = 0; sq_h = 0; sq_t = 0; t_fi_armed = 1'b0;
  endtask

  task automatic wait_init();
    int t;
    t = 0;
    @(posedge clk);
    while ((init_busy || !init_done) && t < 10 * DEPTH + 100) begin @(posedge clk); t++; end
    if (!init_done) fail("initialisation did not complete");
    #1;
  endtask

  task automatic scrub_pass(input logic fix, input logic ver, input logic stop, input int interval);
    s_fix = fix; s_ver = ver; s_stop = stop; s_int = 24'(interval); s_one = 1'b1; s_lo = '0; s_hi = AW'(DEPTH - 1);
    s_en = 1'b1; s_start = 1'b1;
    @(posedge clk); #1; s_start = 1'b0;
    while (!s_done && !s_stopped) @(posedge clk);
    #1;
  endtask
  task automatic scrub_off();
    s_en = 1'b0;
    repeat (3 * (READ_LATENCY + DEC_PIPE + 3)) @(posedge clk);
    #1;
  endtask
  task automatic scrub_clear();
    s_clr = 1'b1; @(posedge clk); #1; s_clr = 1'b0;
  endtask

  // ---------------------------------------------------------------- phases
  int t0, acc, sacc;
  string ivs;
  int meas_base;
  int rec_seen;
  logic [N-1:0] m2;

  initial begin
    rnd_state = SEED;
    req_valid = 0; req_we = 0; req_addr = '0; req_wdata = '0; req_wmask = '0; req_id = '0;
    init_req = 0; tst_active = 0; tst_ce = 0; tst_we = 0; tst_addr = '0; tst_wdata = '0;
    fi_arm = 0; fi_mode = '0; fi_mask = '0; fi_addr_en = 0; fi_addr = '0;
    s_en = 0; s_start = 0; s_one = 0; s_fix = 0; s_ver = 0; s_stop = 0; s_clr = 0; s_int = '0; s_lo = '0; s_hi = '0;
    rsp_ready = 1;
    model_reset();
    repeat (3) @(posedge clk);
    #1 rst_n = 1;

    // ---- P1: initialisation and clean read of every word
    wait_init();
    for (int a = 0; a < DEPTH; a++) rd(a);
    drain();
    backdoor_check("P1 init");
    $display("RESULT P1 init: %0d words initialised and read clean", DEPTH);

    // ---- P2: random full writes / reads with back-pressure
    rr_mode = 1;
    for (int i = 0; i < 40 * DEPTH; i++) begin
      if ((rnd() & 1) != 0) wr(int'(rnd() % DEPTH), rnd_data());
      else                  rd(int'(rnd() % DEPTH));
    end
    drain();
    backdoor_check("P2 random");
    rr_mode = 0;
    $display("RESULT P2 random traffic: %0d responses checked", n_rsp);

    // ---- P3: EVERY single-bit position (data, check, parity, poison bit) via in-place injection
    for (int b = 0; b < N; b++) begin
      int a;
      a = b % DEPTH;
      wr(a, rnd_data());
      drain();
      inject_inplace(a, N'(1) << b);
      rd(a); rd(a);                       // persistent: both reads corrected, index = b
      drain();
      wr(a, m_data[a]);                   // rewrite clears it
      rd(a);
      drain();
      n_single_pos++;
    end
    backdoor_check("P3 single");
    $display("RESULT P3 single-bit: all %0d stored-bit positions corrected (CE events with exact index)", n_single_pos);

    // ---- P4: double-bit errors
    for (int b0 = 0; b0 < N; b0++) begin
      for (int b1 = b0 + 1; b1 < N; b1++) begin
        if (N <= 40 || b1 == b0 + 1 || b1 == N - 1 || (b0 % 9 == 0 && b1 % 7 == 0) || b0 == 0) begin
          int a;
          a = (b0 * 7 + b1) % DEPTH;
          wr(a, rnd_data());
          inject_inplace(a, (N'(1) << b0) | (N'(1) << b1));
          rd(a);
          drain();
          wr(a, rnd_data());
          n_double++;
        end
      end
    end
    drain();
    backdoor_check("P4 double");
    $display("RESULT P4 double-bit: %0d bit pairs detected as UE (err + poison, uncorrected data returned)", n_double);

    // ---- P5: read-path (transient) and write-path (persistent) injection
    wr(3, rnd_data()); drain();
    arm(`SFRAS_FI_READ, N'(1) << (N / 2), 1'b1, 3);
    rd(3); rd(3); drain();                                          // first CE, second clean
    arm(`SFRAS_FI_READ, (N'(1) << 1) | (N'(1) << (N - 2)), 1'b0, 0);
    rd(5); rd(5); drain();                                          // first UE, second clean
    // an arm pulse while a fired read-path injection is still in flight must be ignored
    arm(`SFRAS_FI_READ, N'(1) << 2, 1'b0, 0);
    rd(4);                                                          // fires at acceptance, mask used later
    fi_mode = `SFRAS_FI_READ; fi_mask = N'(1) << 9; fi_addr_en = 1'b0; fi_arm = 1'b1;   // raw pulse, not modelled
    @(posedge clk); #1; fi_arm = 1'b0;
    rd(4); rd(4); drain();                                          // first CE (bit 2), then clean, clean
    arm(`SFRAS_FI_WRITE, (N'(1) << 0) | (N'(1) << (K - 1)), 1'b1, 7);
    wr(6, rnd_data()); wr(7, rnd_data()); rd(6); rd(7); rd(7); drain();   // only word 7 corrupted (UE)
    wr(7, rnd_data()); rd(7); drain();
    if (n_fi_fired != n_fi_fired_exp) fail($sformatf("fi fired %0d exp %0d", n_fi_fired, n_fi_fired_exp));
    $display("RESULT P5 read/write-path injection: %0d injections fired as predicted", n_fi_fired);

    // ---- P6: partial writes (RMW)
    if (MW > 1) begin
      for (int i = 0; i < 20 * DEPTH; i++) begin
        int a;
        a = int'(rnd() % DEPTH);
        case (rnd() % 4)
          0: req(1'b1, a, rnd_data(), MW'(rnd()));                  // random strobe (may be full / empty)
          1: rd(a);
          2: wr(a, rnd_data());
          default: req(1'b1, a, rnd_data(), MW'(1) << (rnd() % MW));
        endcase
      end
      drain();
      // RMW onto a correctable word: corrected and merged, word clean afterwards -- the
      // faulty bit in a lane that is NOT written (it must be corrected in the merged word)
      // and, separately, in the lane that is written
      wr(9, rnd_data()); drain();
      inject_inplace(9, N'(1) << 21);
      req(1'b1, 9, rnd_data(), MW'(1)); rd(9); drain();
      inject_inplace(9, N'(1) << 5);
      req(1'b1, 9, rnd_data(), MW'(1)); rd(9); drain();
      // RMW onto an uncorrectable word: poisoned (SIG / BIT) or aborted (NONE)
      wr(10, rnd_data()); drain();
      inject_inplace(10, (N'(1) << 2) | (N'(1) << 11));
      req(1'b1, 10, rnd_data(), MW'(2)); rd(10); drain();
      // RMW onto a poisoned word keeps it poisoned; a full write clears poison
      req(1'b1, 10, rnd_data(), MW'(4)); rd(10); wr(10, rnd_data()); rd(10); drain();
      // RMW with write-path injection into its write-back
      arm(`SFRAS_FI_WRITE, N'(1) << 3, 1'b1, 11);
      req(1'b1, 11, rnd_data(), MW'(1)); rd(11); drain();
      wr(11, rnd_data()); drain();
      backdoor_check("P6 rmw");
      $display("RESULT P6 partial writes: RMW on clean / CE / UE / poisoned words as specified (POISON_MODE=%0d)", POISON_MODE);
    end else begin
      req(1'b1, 2, rnd_data(), '0); drain();
      $display("RESULT P6 partial writes: MW=1 (no byte lanes): only full / empty strobes exist");
    end

    // ---- P7: scrub correction of seeded single-bit errors
    for (int a = 0; a < DEPTH; a++) wr(a, rnd_data());
    drain();
    scrub_clear();
    for (int i = 0; i < DEPTH / 4; i++) inject_inplace(i * 4 + 1, N'(1) << ((i * 13) % N));
    scrub_pass(1'b1, 1'b1, 1'b0, 0);
    drain();
    if (c_ce != DEPTH / 4 || c_fix != DEPTH / 4 || c_hard != 0 || c_ue != 0 || c_pass != 1)
      fail($sformatf("scrub counts ce=%0d fix=%0d hard=%0d ue=%0d pass=%0d exp ce=fix=%0d", c_ce, c_fix, c_hard, c_ue, c_pass, DEPTH / 4));
    for (int a = 0; a < DEPTH; a++) rd(a);                          // all clean now: no CE events expected
    drain();
    backdoor_check("P7 scrub");
    $display("RESULT P7 scrub: %0d seeded single-bit errors found, written back and verified; all words clean", c_fix);
    scrub_off();

    // ---- P8: uncorrectable error found by scrub: stop policy and continue policy
    scrub_clear();
    m2 = (N'(1) << 4) | (N'(1) << 9);
    inject_inplace(DEPTH / 2, m2);
    scrub_pass(1'b1, 1'b1, 1'b1, 0);
    if (!s_stopped || s_ue_addr != AW'(DEPTH / 2) || c_ue != 1) fail("scrub did not stop at the UE word");
    s_en = 1'b0; @(posedge clk); #1; s_start = 1'b1; @(posedge clk); #1; s_start = 1'b0;   // acknowledge
    scrub_off();
    drain();
    scrub_clear();
    scrub_pass(1'b1, 1'b1, 1'b0, 0);                                // continue policy: whole pass, UE counted, word untouched
    drain();
    if (s_stopped || c_ue != 1 || c_pass != 1 || c_fix != 0) fail($sformatf("continue policy: ue=%0d pass=%0d fix=%0d", c_ue, c_pass, c_fix));
    rd(DEPTH / 2); drain();                                          // still UE: never silently "fixed"
    wr(DEPTH / 2, rnd_data()); drain();
    scrub_off();
    $display("RESULT P8 scrub UE: stop policy halted at word %0d; continue policy counted it and left it uncorrectable", DEPTH / 2);

    // ---- P9: stuck-at cell: write-back cannot clear it -> recovery failure
    scrub_clear();
    wr(5, rnd_data()); drain();
    begin
      logic [N-1:0] ic;
      ic = ideal_cw(m_data[5], m_pois[5]);
      stuck_addr = 5; stuck_bit = 3; stuck_val = ic[3] ? 0 : 1;      // force the opposite value
      u_dut.u_array.g_generic.u_mem.flt_addr = 5;
      u_dut.u_array.g_generic.u_mem.flt_bit  = 3;
      u_dut.u_array.g_generic.u_mem.flt_kind = stuck_val ? 2 : 1;
    end
    rec_seen = 0;
    fork
      begin : rec_watch
        while (rec_seen == 0) begin @(posedge clk); if (rec_v) rec_seen = 1; end
        if (rec_addr != AW'(5) || rec_ue) fail("recovery event address / class");
      end
      scrub_pass(1'b1, 1'b1, 1'b0, 0);
    join
    drain();
    if (c_hard != 1 || c_fix != 1) fail($sformatf("stuck-at: hard=%0d fix=%0d", c_hard, c_fix));
    rd(5); drain();                                                  // still corrected on every read
    u_dut.u_array.g_generic.u_mem.flt_kind = 0;
    stuck_addr = -1;
    wr(5, rnd_data()); drain();
    scrub_off();
    $display("RESULT P9 stuck-at: CE corrected on read, write-back verified failing -> recovery event (hard_count=%0d)", c_hard);

    // ---- P10: injected recovery fault (corrupted scrub write-back)
    scrub_clear();
    wr(12, rnd_data()); drain();
    inject_inplace(12, N'(1) << 7);
    arm(`SFRAS_FI_SCRUB_WB, N'(1) << 20, 1'b1, 12);
    scrub_pass(1'b1, 1'b1, 1'b0, 0);
    drain();
    if (c_hard != 1) fail($sformatf("recovery fault not detected: hard=%0d", c_hard));
    wr(12, rnd_data()); drain();
    scrub_off();
    $display("RESULT P10 recovery fault: corrupted write-back detected by verify (hard_count=%0d)", c_hard);

    // ---- P11: MBIST hand-over: raw access to all N bits, then automatic re-initialisation
    wr(1, rnd_data()); rd(1);
    tst_active = 1'b1;
    begin
      int t;
      t = 0;
      @(posedge clk);
      while (!tst_ready && t < 100) begin @(posedge clk); t++; end
      if (!tst_ready) fail("test port not granted");
      #1;
      for (int a = 0; a < DEPTH; a++) begin
        tst_ce = 1; tst_we = 1; tst_addr = AW'(a); tst_wdata = (a % 2 != 0) ? '1 : {N/2{2'b10}};
        @(posedge clk); #1;
      end
      for (int a = 0; a < DEPTH; a++) begin
        tst_ce = 1; tst_we = 0; tst_addr = AW'(a);
        @(posedge clk); #1;
        tst_ce = 0;
        repeat (READ_LATENCY - 1) begin @(posedge clk); #1; end
        if (tst_rdata !== ((a % 2 != 0) ? {N{1'b1}} : N'({N/2{2'b10}})))
          fail($sformatf("MBIST raw read word %0d = %h", a, tst_rdata));
      end
      tst_ce = 0;
    end
    tst_active = 1'b0;
    drain();
    model_reset_data_only();
    wait_init();
    for (int a = 0; a < DEPTH; a++) rd(a);
    drain();
    backdoor_check("P11 mbist");
    $display("RESULT P11 MBIST: raw %0d-bit patterns written/read through the test port; memory re-initialised", N);

    // ---- P12: invalid strobe / invalid address handled with error responses
    req(1'b1, 0, rnd_data(), '0); drain();                     // empty strobe: acknowledged no-op
    if (DEPTH != (1 << AW)) begin rd(DEPTH); wr(DEPTH + 1, rnd_data()); drain(); end   // invalid addresses
    $display("RESULT P12 strobes/addresses: no-op and error responses as specified");

    // ---- P13: contention + scrub interference measurement
    //   Same pseudo-random request sequence for every scrub setting (the
    //   generator is re-seeded), 100 % offered load, random response-ready
    //   off.  mix 0: 50 % reads / 50 % full writes; mix 1: 25 % partial writes.
    begin
      int cyc, ivs_list [4];
      cyc = 4000;
      ivs_list[0] = -1; ivs_list[1] = 0; ivs_list[2] = 16; ivs_list[3] = 256;
      for (int mix = 0; mix < ((MW > 1) ? 2 : 1); mix++) begin
        for (int pass = 0; pass < 4; pass++) begin
          int iv;
          iv = ivs_list[pass];
          scrub_clear();
          rnd_state = 32'hC0FFEE + mix;
          if (iv >= 0) begin
            s_fix = 1; s_ver = 1; s_stop = 0; s_int = 24'(iv); s_one = 0; s_lo = '0; s_hi = AW'(DEPTH - 1);
            s_en = 1; s_start = 1; @(posedge clk); #1; s_start = 0;
          end
          acc = 0;
          t0 = 0;
          fork
            begin : load
              while (t0 < cyc) begin
                req_valid = 1'b1; req_we = (rnd() & 1); req_addr = AW'(rnd() % DEPTH); req_wdata = rnd_data();
                req_wmask = (mix == 1 && (rnd() & 1) == 0 && req_we) ? MW'(1) : '1; req_id = req_id + 1'b1;
                @(posedge clk);
                while (!req_ready) @(posedge clk);
                #1;
              end
              req_valid = 1'b0;
            end
            begin : count
              while (t0 < cyc) begin
                @(posedge clk);
                if (req_valid && req_ready) acc++;
                t0++;
              end
            end
          join
          sacc = int'(c_rd);
          scrub_off();
          drain();
          if (iv < 0) begin ivs = "off"; meas_base = acc; end
          else ivs = $sformatf("%0d", iv);
          $display("MEAS mix=%0s scrub_interval=%0s functional_accepts=%0d/%0d cycles (%0d.%03d/cycle) scrub_reads=%0d (%0d.%03d/cycle) slowdown=%0d.%01d%%",
                   (mix == 0) ? "rd50_wr50" : "rd50_wr25_rmw25", ivs, acc, cyc, acc / cyc, (acc * 1000 / cyc) % 1000,
                   sacc, sacc / cyc, (sacc * 1000 / cyc) % 1000,
                   ((meas_base - acc) * 100) / meas_base, (((meas_base - acc) * 1000) / meas_base) % 10);
          if (iv >= 0 && sacc == 0) fail("scrub starved under full functional load");
        end
      end
    end

    // ---- P14: reset during traffic: reads pipelined, a scrub walk running, and
    //      reset asserted one time step after a partial write (RMW lock) was accepted
    s_fix = 1; s_ver = 1; s_stop = 0; s_int = 24'(0); s_one = 0; s_lo = '0; s_hi = AW'(DEPTH - 1);
    s_en = 1; s_start = 1; @(posedge clk); #1; s_start = 0;
    for (int i = 0; i < 40; i++) begin
      if ((rnd() & 1) != 0) wr(int'(rnd() % DEPTH), rnd_data()); else rd(int'(rnd() % DEPTH));
    end
    rd(1); rd(2); rd(3);
    if (MW > 1) req(1'b1, 4, rnd_data(), MW'(1)); else wr(4, rnd_data());
    rst_n = 1'b0;                                    // asynchronous, mid-operation
    s_en = 0;
    req_valid = 0;
    repeat (3) @(posedge clk);
    model_reset();
    #1 rst_n = 1'b1;
    if (rsp_valid || ev_valid || scr_rsp_valid) fail("outputs active right after reset");
    wait_init();
    for (int a = 0; a < DEPTH; a++) rd(a);
    drain();
    backdoor_check("P14 reset");
    $display("RESULT P14 reset during traffic: no spurious response/event, memory re-initialised");

    // ---------------------------------------------------------------- summary
    $display("tb_ecc_sram K=%0d N=%0d DEPTH=%0d LAT=%0d DEC_PIPE=%0d POISON_MODE=%0d BYTE_EN=%0d: %0d responses, %0d events (CE %0d, UE %0d, poison %0d), %0d scrub responses",
             K, N, DEPTH, READ_LATENCY, DEC_PIPE, POISON_MODE, BYTE_EN, n_rsp, n_ev, n_ev_ce, n_ev_ue, n_ev_pois, n_scr);
    if (errors == 0) $display("PASS tb_ecc_sram");
    else             $display("FAIL tb_ecc_sram: %0d errors", errors);
    $finish;
  end

  task automatic model_reset_data_only();
    for (int a = 0; a < DEPTH; a++) begin m_data[a] = '0; m_pois[a] = 1'b0; m_emask[a] = '0; end
  endtask

  initial begin
    #(200_000_000);
    $display("FAIL tb_ecc_sram: global timeout");
    $finish;
  end
endmodule

`default_nettype wire
