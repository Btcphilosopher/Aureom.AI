// =============================================================================
// SilicaFlux RAS (Project 26) :: tb_secded
// Bit-exact check of sfras_secded_enc / sfras_secded_dec against vectors from
// the independent Python reference (model/secded_ref.py, nearest-codeword /
// H-column decoding).  One compile per (K, INV); the vector file is chosen with
// +VEC=<file>.  Every field is compared: stored word, corrected data,
// corrected stored word, class (NONE/CE/UE, one-hot), corrected-bit index,
// "corrected bit is a data bit", syndrome.  Additionally:
//   * the RTL elaboration-time default inversion (sfras_ecc_default_inv) must
//     equal the reference's independently computed choice (+INVD=1 files);
//   * ce_o must never be set without exactly one bit of difference between the
//     received and the corrected word (no "corrected" claim without a
//     correction), and data_o must equal the received data bits on UE.
// Classification: SIMULATION ONLY
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_secded #(
  parameter int K   = 64,
  parameter int INV = 0
);
  `include "sfras_ecc_funcs.svh"
  localparam int R  = $clog2(K + $clog2(K + 1) + 1);
  localparam int N  = K + R + 1;
  localparam int IW = $clog2(N);

  logic [K-1:0]  enc_d;
  logic [N-1:0]  enc_cw;
  logic [N-1:0]  dec_cw;
  logic [K-1:0]  dec_d;
  logic [N-1:0]  dec_cwc;
  logic          dec_none, dec_ce, dec_ue, dec_inval, dec_cedata;
  logic [IW-1:0] dec_idx;
  logic [R:0]    dec_syn;

  sfras_secded_enc #(.K(K), .INV(INV)) u_enc (.data_i(enc_d), .cw_o(enc_cw));
  sfras_secded_dec #(.K(K), .INV(INV)) u_dec (
    .cw_i(dec_cw), .data_o(dec_d), .cw_corr_o(dec_cwc), .none_o(dec_none), .ce_o(dec_ce),
    .ue_o(dec_ue), .ue_inval_o(dec_inval), .ce_data_o(dec_cedata), .err_idx_o(dec_idx), .syn_o(dec_syn)
  );

  int fd, rc, op, cls, idx, tag, errors, n_enc, n_dec, line;
  int n_tag_cls [6][3];
  int n_inval;
  logic [255:0] a, b, c, syn;
  string vec;
  int invd;

  // loop-based popcount: Icarus 12 $countones miscounts vectors wider than 64 bits
  function automatic int popcnt(input logic [N-1:0] v);
    int c;
    c = 0;
    for (int i = 0; i < N; i++) c += (v[i] === 1'b1) ? 1 : 0;
    return c;
  endfunction

  task automatic fail(input string what);
    errors++;
    if (errors <= 20) $display("FAIL line %0d: %s", line, what);
  endtask

  initial begin
    errors = 0; n_enc = 0; n_dec = 0; line = 0; n_inval = 0;
    foreach (n_tag_cls[i, j]) n_tag_cls[i][j] = 0;
    if (!$value$plusargs("VEC=%s", vec)) $fatal(1, "missing +VEC=<file>");
    if (!$value$plusargs("INVD=%d", invd)) invd = 0;
    fd = $fopen(vec, "r");
    if (fd == 0) $fatal(1, "cannot open %s", vec);
    enc_d = '0; dec_cw = '0;
    rc = 8;
    while (rc == 8 && !$feof(fd)) begin
      rc = $fscanf(fd, "%d %h %h %h %d %d %h %d\n", op, a, b, c, cls, idx, syn, tag);
      if (rc != 8 && !$feof(fd)) $fatal(1, "bad vector line %0d (rc=%0d)", line + 1, rc);
      if (rc != 8) op = -1;
      else line++;
      if (op == 2) begin
          if (a != K || b != R || c != N || idx != INV)
            $fatal(1, "vector header K=%0d R=%0d N=%0d INV=%0d does not match DUT K=%0d R=%0d N=%0d INV=%0d",
                   a, b, c, idx, K, R, N, INV);
          if (invd != 0 && sfras_ecc_default_inv(K) != idx)
            fail($sformatf("RTL default INV 0x%0h != reference default INV 0x%0h", sfras_ecc_default_inv(K), idx));
      end else if (op == 0) begin
          n_enc = n_enc + 1;
          enc_d = a[K-1:0];
          #1;
          if (enc_cw !== c[N-1:0]) fail($sformatf("encode d=%h: cw=%h exp %h", enc_d, enc_cw, c[N-1:0]));
          // round trip through the decoder: clean
          dec_cw = enc_cw;
          #1;
          if (!(dec_none === 1'b1 && dec_ce === 1'b0 && dec_ue === 1'b0 && dec_d === enc_d))
            fail($sformatf("round trip d=%h not clean", enc_d));
      end else if (op == 1) begin
          n_dec = n_dec + 1;
          dec_cw = a[N-1:0];
          #1;
          n_tag_cls[tag][cls]++;
          if (dec_inval) n_inval++;
          if (dec_d   !== b[K-1:0]) fail($sformatf("decode cw=%h: data=%h exp %h", dec_cw, dec_d, b[K-1:0]));
          if (dec_cwc !== c[N-1:0]) fail($sformatf("decode cw=%h: cw_corr=%h exp %h", dec_cw, dec_cwc, c[N-1:0]));
          if ({dec_ue, dec_ce, dec_none} !== (3'b001 << cls))
            fail($sformatf("decode cw=%h: class none/ce/ue=%b%b%b exp cls %0d", dec_cw, dec_none, dec_ce, dec_ue, cls));
          if (dec_syn !== syn[R:0]) fail($sformatf("decode cw=%h: syn=%h exp %h", dec_cw, dec_syn, syn[R:0]));
          if (cls == 1) begin
            if (dec_idx !== IW'(idx)) fail($sformatf("decode cw=%h: idx=%0d exp %0d", dec_cw, dec_idx, idx));
            if (dec_cedata !== (idx < K)) fail($sformatf("decode cw=%h: ce_data=%b exp %b", dec_cw, dec_cedata, idx < K));
          end
          // "corrected" only when exactly one bit was changed
          if (dec_ce && popcnt(dec_cw ^ dec_cwc) != 1) fail("ce_o without a single-bit correction");
          if (!dec_ce && (dec_cw !== dec_cwc)) fail("corrected word differs although ce_o = 0");
          if (dec_ue && (dec_d !== dec_cw[K-1:0])) fail("UE data is not the stored data (substituted)");
          if (dec_inval && !dec_ue) fail("invalid syndrome not reported as UE");
      end else if (op != -1) begin
        $fatal(1, "unknown op %0d", op);
      end
    end
    $fclose(fd);
    $display("tb_secded K=%0d R=%0d N=%0d INV=0x%0h: %0d encode + %0d decode vectors, %0d invalid-syndrome UEs",
             K, R, N, INV, n_enc, n_dec, n_inval);
    $display("  tag(0 clean,1 single,2 double,3 triple,4 multi,5 exhaustive) x class(NONE,CE,UE):");
    for (int t = 0; t < 6; t++)
      if (n_tag_cls[t][0] + n_tag_cls[t][1] + n_tag_cls[t][2] != 0)
        $display("  tag %0d: NONE %0d  CE %0d  UE %0d", t, n_tag_cls[t][0], n_tag_cls[t][1], n_tag_cls[t][2]);
    // fault-model guarantees, checked on the counts as well as per vector
    if (n_tag_cls[1][0] + n_tag_cls[1][2] != 0) fail("a single-bit error was not corrected");
    if (n_tag_cls[2][0] + n_tag_cls[2][1] != 0) fail("a double-bit error was not detected as UE");
    if (n_tag_cls[0][1] + n_tag_cls[0][2] != 0) fail("a clean word was flagged");
    if (n_enc == 0 || n_dec == 0) fail("no vectors executed");
    if (errors == 0) $display("PASS tb_secded K=%0d INV=0x%0h", K, INV);
    else             $display("FAIL tb_secded K=%0d INV=0x%0h: %0d errors", K, INV, errors);
    $finish;
  end
endmodule

`default_nettype wire
