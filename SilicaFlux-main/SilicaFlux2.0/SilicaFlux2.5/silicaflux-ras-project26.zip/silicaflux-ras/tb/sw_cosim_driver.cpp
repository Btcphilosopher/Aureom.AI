// Compiles the UNMODIFIED firmware driver with the co-simulation MMIO hooks
// (avoids a forced -include, which clashes with Verilator's precompiled header).
#include "sw_cosim_mmio.h"
extern "C" {
#include "../sw/silicaflux_ras.c"
}
