/* SilicaFlux RAS (Project 26): MMIO hooks that route the firmware driver's
 * register accesses into the Verilated silicaflux_ras (tb/sw_cosim.cpp).
 * Force-included before sw/silicaflux_ras.c, so the driver source is used
 * unmodified. */
#ifndef SW_COSIM_MMIO_H
#define SW_COSIM_MMIO_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
uint32_t cosim_rd(uint32_t off);
void     cosim_wr(uint32_t off, uint32_t v);
#ifdef __cplusplus
}
#endif
#define SFRAS_READ32(dev, off)       ((void)(dev), cosim_rd((uint32_t)(off)))
#define SFRAS_WRITE32(dev, off, val) ((void)(dev), cosim_wr((uint32_t)(off), (uint32_t)(val)))
#endif
