// =============================================================================
// SilicaFlux RAS (Project 26) :: sw_cosim.cpp
// Firmware-driver / RTL co-simulation: the UNMODIFIED driver (sw/silicaflux_ras.c)
// runs against the Verilated silicaflux_ras.  Every SFRAS_READ32 / WRITE32 is a
// register-page bus cycle.  The harness plays the SoC around the RAS block:
// event sources, memory init / scrub responders, the thermal sensor, the
// fault-injection permission pin, and it records the injection pulses that
// reach the memory / bus targets.
// Build: scripts/run_cosim.sh   (Verilator 5.020, -DSFRAS_ENABLE_FI)
// =============================================================================
#include <cstdio>
#include <cstring>
#include <cstdint>
#include "Vsilicaflux_ras.h"
#include "verilated.h"
extern "C" {
#include "silicaflux_ras.h"
}

static Vsilicaflux_ras *top;
static uint64_t cyc = 0;
static int errors = 0;
#define CHECK(c, ...) do { if (!(c)) { errors++; std::printf("FAIL line %d: ", __LINE__); std::printf(__VA_ARGS__); std::printf("\n"); } } while (0)

// ---------------------------------------------------------------- SoC model
static int init_cnt[2] = {0, 0};
static bool scr_pend[2] = {false, false};
static uint32_t scr_op[2], scr_addr[2];
static int mem_arm_seen = 0, bus_arm_seen = 0;
static uint32_t last_mem_mode, last_mem_addr, last_mem_mask0, last_bus_mode, last_bus_delay, last_bus_target;

static void soc_comb() {
    // memory init responder: busy for 8 cycles after a request
    uint32_t busy = 0, done = top->mem_init_done;
    for (int m = 0; m < 2; m++) {
        if (init_cnt[m] > 0) busy |= 1u << m;
    }
    top->mem_init_busy = busy;
    top->mem_init_done = done;
    // scrub responder: always ready, answers the next cycle, clean words
    top->mem_scr_req_ready = 0x3;
    uint32_t rv = 0, rop = 0;
    for (int m = 0; m < 2; m++) if (scr_pend[m]) { rv |= 1u << m; rop |= scr_op[m] << (2 * m); }
    top->mem_scr_rsp_valid = rv;
    top->mem_scr_rsp_op = rop;
    top->mem_scr_rsp_addr = (scr_addr[1] << 16) | (scr_addr[0] & 0xFFFF);
    top->mem_scr_rsp_ce = 0; top->mem_scr_rsp_ue = 0; top->mem_scr_rsp_poison = 0; top->mem_scr_rsp_wb = 0;
}

static void tick() {
    soc_comb();
    top->clk = 0; top->eval();
    // sample outputs that act at this edge
    for (int m = 0; m < 2; m++) {
        if (top->mem_init_req & (1u << m)) { init_cnt[m] = 8; top->mem_init_done &= ~(1u << m); }
    }
    if (top->mem_fi_arm) {
        mem_arm_seen++; last_mem_mode = top->mem_fi_mode; last_mem_addr = top->mem_fi_addr; last_mem_mask0 = top->mem_fi_mask[0];
    }
    if (top->bfi_arm) {
        bus_arm_seen++; last_bus_mode = top->bfi_mode; last_bus_delay = top->bfi_delay;
        last_bus_target = top->bfi_arm;
    }
    bool sq[2]; uint32_t sop[2], sad[2];
    for (int m = 0; m < 2; m++) {
        sq[m] = (top->mem_scr_req_valid >> m) & 1;
        sop[m] = (top->mem_scr_req_op >> (2 * m)) & 3;
        sad[m] = (top->mem_scr_req_addr >> (16 * m)) & 0xFFFF;
    }
    top->clk = 1; top->eval();
    cyc++;
    for (int m = 0; m < 2; m++) {
        scr_pend[m] = sq[m];
        scr_op[m] = sop[m]; scr_addr[m] = sad[m];
        if (init_cnt[m] > 0 && --init_cnt[m] == 0) top->mem_init_done |= 1u << m;
    }
    top->ext_ev_valid = 0; top->mem_ev_valid = 0; top->therm_valid_i = 0;
}

extern "C" uint32_t cosim_rd(uint32_t off) {
    top->rb_sel = 1; top->rb_we = 0; top->rb_addr = off & 0xFFF; top->rb_priv = 1;
    soc_comb(); top->clk = 0; top->eval();
    uint32_t v = top->rb_rdata;
    tick();
    top->rb_sel = 0;
    return v;
}
extern "C" void cosim_wr(uint32_t off, uint32_t v) {
    top->rb_sel = 1; top->rb_we = 1; top->rb_addr = off & 0xFFF; top->rb_wdata = v; top->rb_priv = 1;
    tick();
    top->rb_sel = 0; top->rb_we = 0;
}

// ---------------------------------------------------------------- event sources
static void ext_event(int port, uint32_t type, uint32_t addr, uint32_t info) {
    top->ext_ev_valid |= 1u << port;
    top->ext_ev_type = (top->ext_ev_type & ~(0xFu << (4 * port))) | (type << (4 * port));
    top->ext_ev_addr[port] = addr;
    top->ext_ev_info[port] = info;
    top->ext_ev_addr_v |= 1u << port;
}
static void mem_ce_event(int m, uint32_t addr, uint32_t org, uint32_t syn, uint32_t idx) {
    top->mem_ev_valid = 1u << m; top->mem_ev_ce = 1u << m; top->mem_ev_ue = 0; top->mem_ev_poison = 0;
    top->mem_ev_org = org << (3 * m);
    top->mem_ev_addr = addr << (16 * m);
    top->mem_ev_syn = syn << (9 * m);
    top->mem_ev_idx = idx << (8 * m);
}

struct Collected { int n; sfras_event_t ev[64]; };
static void collect(void *ctx, const sfras_event_t *ev) {
    Collected *c = (Collected *)ctx;
    if (c->n < 64) c->ev[c->n] = *ev;
    c->n++;
}

int main(int argc, char **argv) {
    Verilated::commandArgs(argc, argv);
    top = new Vsilicaflux_ras;
    top->rst_n = 0; top->fi_allow_i = 0;
    for (int i = 0; i < 4; i++) tick();
    top->rst_n = 1;
    for (int i = 0; i < 2; i++) tick();

    sfras_dev_t dev;
    sfras_config_t cfg;
    sfras_default_config(&cfg);
    cfg.lock_fault_injection = false;            // this run exercises the FI API
    cfg.log_threshold = 0;

    // ---- C1 init
    CHECK(sfras_init(&dev, 0, &cfg) == SFRAS_OK, "init");
    CHECK(dev.next == 8 && dev.nmem == 2 && dev.nsrc == 17, "cfg next=%u nmem=%u nsrc=%u", dev.next, dev.nmem, dev.nsrc);
    std::printf("RESULT C1 init: ID/VERSION checked, CFG decoded (NEXT=%u NMEM=%u sources=%u)\n", dev.next, dev.nmem, dev.nsrc);

    // ---- C2 events through the driver's service routine
    ext_event(3, SFRAS_EV_DMA_ERR, 0x1234, 0x80000000u);
    mem_ce_event(1, 0x55, SFRAS_ORG_SCRUB, 0x45, 17);
    tick();
    for (int i = 0; i < 4; i++) tick();
    CHECK(top->irq_ctrl_o == 1, "irq_ctrl for ERROR");
    Collected col; col.n = 0;
    uint32_t lost = 99;
    uint32_t n = sfras_service(&dev, collect, &col, &lost);
    CHECK(n == 2 && lost == 0, "service n=%u lost=%u", n, lost);
    bool saw_dma = false, saw_ce = false;
    for (int i = 0; i < col.n; i++) {
        const sfras_event_t &e = col.ev[i];
        if (e.type == SFRAS_EV_DMA_ERR) {
            saw_dma = (e.src == 3 && e.addr == 0x1234 && e.sev == SFRAS_SEV_ERROR && !e.corrected && e.info == 0x80000000u);
        }
        if (e.type == SFRAS_EV_MEM_CE) {
            sfras_mem_info_t mi = sfras_decode_mem_info(e.info);
            saw_ce = (e.src == sfras_src_mem(&dev, 1) && e.addr == 0x55 && e.corrected && e.sev == SFRAS_SEV_INFO &&
                      mi.origin == SFRAS_ORG_SCRUB && mi.ce && !mi.ue && mi.syndrome == 0x45 && mi.bit == 17);
        }
    }
    CHECK(saw_dma && saw_ce, "event fields (dma %d ce %d)", saw_dma, saw_ce);
    CHECK(top->irq_ctrl_o == 0, "service did not clear the interrupt");
    sfras_event_t fe;
    CHECK(sfras_first_error(&dev, &fe) && fe.type == SFRAS_EV_DMA_ERR && fe.addr == 0x1234, "first error");
    CHECK(sfras_type_count(&dev, SFRAS_EV_MEM_CE) == 1 && sfras_src_count(&dev, 3) == 1, "counters");
    CHECK(std::strcmp(sfras_type_name(SFRAS_EV_DMA_ERR), "DMA_ERR") == 0, "type name");
    uint64_t t0 = sfras_timestamp(&dev), t1 = sfras_timestamp(&dev);
    CHECK(t1 > t0, "timestamp not increasing");
    std::printf("RESULT C2 service: DMA_ERR and MEM_CE decoded field-exact (src, addr, severity, corrected, origin, syndrome, bit), interrupt cleared, first error, counters, timestamp\n");

    // ---- C3 lost events reported to the driver
    for (int c = 0; c < 10; c++) {
        for (int p = 4; p < 8; p++) ext_event(p, SFRAS_EV_ILLEGAL_OP, p, 0);
        tick();
    }
    for (int i = 0; i < 8; i++) tick();
    col.n = 0;
    n = sfras_service(&dev, collect, &col, &lost);
    CHECK(n + lost == 40, "logged %u + lost %u != 40", n, lost);
    CHECK(sfras_type_count(&dev, SFRAS_EV_ILLEGAL_OP) == 40, "exact count despite losses");
    std::printf("RESULT C3 overflow: 40 events in 10 cycles -> driver got %u entries and a lost count of %u; counter exact (40)\n", n, lost);

    // ---- C4 thermal config (clamp detected) and fatal handling
    CHECK(sfras_therm_config(&dev, 3000, 4000, 8, 0) == SFRAS_E_REFUSED, "fatal threshold above the hardware maximum must be refused");
    top->therm_valid_i = 1; top->therm_code_i = 3500; tick();
    for (int i = 0; i < 4; i++) tick();
    CHECK(sfras_fatal(&dev) && top->contain_o && top->irq_host_o, "thermal fatal");
    col.n = 0;
    sfras_service(&dev, collect, &col, &lost);
    CHECK(sfras_fatal(&dev), "service must not clear FATAL");
    std::printf("RESULT C4 thermal: clamp reported as SFRAS_E_REFUSED; fatal event kept asserted across sfras_service\n");

    // ---- C5 watchdog lock
    CHECK(sfras_wdog_start(&dev, 1000, true) == SFRAS_OK, "wdog start");
    sfras_wdog_kick(&dev);
    CHECK(sfras_wdog_start(&dev, 50, false) == SFRAS_E_REFUSED, "locked watchdog must refuse");
    std::printf("RESULT C5 watchdog: started locked, kicked, re-configuration refused\n");

    // ---- C6 memory init and scrub through the driver
    CHECK(sfras_mem_init(&dev, 1, 100) == SFRAS_OK, "mem init");
    CHECK(sfras_scrub_start(&dev, 0, 0, 15, 0, SFRAS_SCRUB_ONE_PASS | SFRAS_SCRUB_FIX | SFRAS_SCRUB_VERIFY) == SFRAS_OK, "scrub start");
    sfras_scrub_stats_t st;
    int t = 0;
    do { sfras_scrub_stats(&dev, 0, &st); t++; } while (!(st.status & SFRAS_MEM_STATUS_DONE_MASK) && t < 200);
    CHECK(st.passes == 1 && st.reads == 16 && st.ce == 0, "scrub stats passes=%u reads=%u", st.passes, st.reads);
    sfras_scrub_stop(&dev, 0);
    std::printf("RESULT C6 memory: init completed; one-pass scrub of 16 words (passes=%u reads=%u)\n", st.passes, st.reads);

    // ---- C7 fault-injection API and its locks
    CHECK(sfras_fi_unlock(&dev) == SFRAS_E_REFUSED, "unlock without hardware permission");
    top->fi_allow_i = 1;
    CHECK(sfras_fi_unlock(&dev) == SFRAS_OK, "unlock");
    uint32_t mask[3] = {0x20, 0, 0};
    CHECK(sfras_fi_inject_mem(&dev, 0, SFRAS_FI_INPLACE, true, 7, mask, 3) == SFRAS_OK, "inject mem");
    CHECK(mem_arm_seen == 1 && last_mem_mode == SFRAS_FI_INPLACE && last_mem_addr == 7 && last_mem_mask0 == 0x20, "mem arm pulse");
    CHECK(sfras_fi_inject_bus(&dev, 1, 2, 0, 50) == SFRAS_OK, "inject bus");
    CHECK(bus_arm_seen == 1 && last_bus_target == 2 && last_bus_mode == 2 && last_bus_delay == 50, "bus arm pulse");
    sfras_lock_fi(&dev);
    CHECK(sfras_fi_unlock(&dev) == SFRAS_E_REFUSED, "unlock after FI_LOCK");
    CHECK(sfras_fi_inject_mem(&dev, 0, SFRAS_FI_INPLACE, true, 7, mask, 3) == SFRAS_E_REFUSED, "inject after FI_LOCK");
    CHECK(mem_arm_seen == 1, "an injection reached a memory after FI_LOCK");
    std::printf("RESULT C7 fault injection: refused without permission, armed memory (mode/addr/mask exact) and bus (target/mode/delay) targets, refused after sfras_lock_fi\n");

    delete top;
    if (errors == 0) std::printf("PASS sw_cosim\n");
    else             std::printf("FAIL sw_cosim: %d errors\n", errors);
    return errors ? 1 : 0;
}
