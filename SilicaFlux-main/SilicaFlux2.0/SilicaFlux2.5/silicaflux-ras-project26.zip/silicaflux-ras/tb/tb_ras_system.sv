// =============================================================================
// SilicaFlux RAS (Project 26) :: tb_ras_system
// System-level test: silicaflux_ras + two SECDED SFB2 memories + the REAL
// DataFabric DMA (vendored unmodified) + a parity-protected SFB2 link + a bus
// fault injector + DMA / timeout monitors, all controlled through the RAS
// register page exactly as firmware would (sw/silicaflux_ras_regs.h offsets).
//
//   TB master ─┐                                                  ┌─ mem0 (POISON_BIT, 40-bit words) @0x0000_0000
//              ├─ mux ─ fault_inj (bus tgt 8) ─ par_link (tgt 9) ─ router
//   DMA ───────┘   │                                              └─ mem1 (POISON_SIG, 39-bit words) @0x0001_0000
//                  └─ dma_mon (ext 0), timeout_mon (ext 2)
//   par_link events (ext 1), injector fired (ext 3), TB-driven ext 4..7
//
// PROD = 1 builds silicaflux_ras and the memories with FI_EN = 0 and runs the
// production checks only (every injection attempt refused, nothing injected).
// Classification: SIMULATION ONLY
// =============================================================================
`include "sram_defs.svh"
`include "sfras_defs.svh"
`include "sfras_regs.svh"
`include "dma_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module tb_ras_system #(
  parameter int PROD = 0
);
  localparam int FI   = (PROD != 0) ? 0 : 1;
  localparam int DW   = 32;
  localparam int DEPTH = 256;
  localparam int AW   = 8;
  localparam int NEXT = 8, NMEM = 2, NBUS = 2;
  localparam int N0   = 40, N1 = 39;                 // (40,33) with poison bit, (39,32) signature
  localparam int P_MEM = NEXT, P_WDOG = NEXT + 6, P_THRM = NEXT + 7, P_REG = NEXT + 8;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- RAS
  logic        rb_sel = 0, rb_we = 0, rb_priv = 1;
  logic [11:0] rb_addr = '0;
  logic [31:0] rb_wdata = '0, rb_rdata;
  logic        rb_err;
  logic [NEXT-1:0]    ext_v, ext_av, ext_c;
  logic [NEXT*4-1:0]  ext_t;
  logic [NEXT*32-1:0] ext_a, ext_i;
  logic [NMEM-1:0]    m_ev_v, m_ev_ce, m_ev_ue, m_ev_p;
  logic [NMEM*3-1:0]  m_ev_org;
  logic [NMEM*AW-1:0] m_ev_addr;
  logic [NMEM*9-1:0]  m_ev_syn;
  logic [NMEM*8-1:0]  m_ev_idx;
  logic [NMEM-1:0]    m_sq_v, m_sq_r, m_sr_v, m_sr_ce, m_sr_ue, m_sr_p, m_sr_wb;
  logic [NMEM*2-1:0]  m_sq_op, m_sr_op;
  logic [NMEM*AW-1:0] m_sq_a, m_sr_a;
  logic [NMEM-1:0]    m_init_req, m_init_busy, m_init_done;
  logic [NMEM-1:0]    m_fi_arm, m_fi_armed, m_fi_fired;
  logic [1:0]         m_fi_mode;
  logic [N0-1:0]      m_fi_mask;
  logic               m_fi_aen;
  logic [AW-1:0]      m_fi_addr;
  logic [NMEM*AW-1:0] m_fi_faddr;
  logic [NBUS-1:0]    bfi_arm, bfi_busy;
  logic [1:0]         bfi_mode;
  logic [63:0]        bfi_mask;
  logic [15:0]        bfi_delay;
  logic               th_v = 0;
  logic [11:0]        th_code = '0;
  logic               fi_allow = 0;
  logic               irq_ctrl, irq_host, fatal, contain, cc_warn, cc_fatal, th_shut, wd_rst, fi_active;

  silicaflux_ras #(
    .NEXT(NEXT), .NMEM(NMEM), .NBUS(NBUS), .MEM_AW(AW), .MEM_NW(N0), .MEM_DEPTHS({32'd256, 32'd256}),
    .LOG_DEPTH(16), .CNT_W(32), .TS_W(48), .FI_EN(FI), .THERM_W(12)
  ) u_ras (
    .clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .rb_priv,
    .ext_ev_valid(ext_v), .ext_ev_type(ext_t), .ext_ev_addr(ext_a), .ext_ev_addr_v(ext_av), .ext_ev_info(ext_i),
    .ext_ev_corr(ext_c),
    .mem_ev_valid(m_ev_v), .mem_ev_ce(m_ev_ce), .mem_ev_ue(m_ev_ue), .mem_ev_poison(m_ev_p), .mem_ev_org(m_ev_org),
    .mem_ev_addr(m_ev_addr), .mem_ev_syn(m_ev_syn), .mem_ev_idx(m_ev_idx),
    .mem_scr_req_valid(m_sq_v), .mem_scr_req_ready(m_sq_r), .mem_scr_req_op(m_sq_op), .mem_scr_req_addr(m_sq_a),
    .mem_scr_rsp_valid(m_sr_v), .mem_scr_rsp_op(m_sr_op), .mem_scr_rsp_addr(m_sr_a), .mem_scr_rsp_ce(m_sr_ce),
    .mem_scr_rsp_ue(m_sr_ue), .mem_scr_rsp_poison(m_sr_p), .mem_scr_rsp_wb(m_sr_wb),
    .mem_init_req(m_init_req), .mem_init_busy(m_init_busy), .mem_init_done(m_init_done),
    .mem_fi_arm(m_fi_arm), .mem_fi_mode(m_fi_mode), .mem_fi_mask(m_fi_mask), .mem_fi_addr_en(m_fi_aen),
    .mem_fi_addr(m_fi_addr), .mem_fi_armed(m_fi_armed), .mem_fi_fired(m_fi_fired), .mem_fi_fired_addr(m_fi_faddr),
    .bfi_arm, .bfi_mode, .bfi_mask, .bfi_delay, .bfi_busy,
    .therm_valid_i(th_v), .therm_code_i(th_code), .fi_allow_i(fi_allow),
    .irq_ctrl_o(irq_ctrl), .irq_host_o(irq_host), .fatal_o(fatal), .contain_o(contain), .cc_warn_o(cc_warn),
    .cc_fatal_o(cc_fatal), .therm_shutdown_o(th_shut), .wdog_reset_req_o(wd_rst), .fi_active_o(fi_active)
  );

  // ---------------------------------------------------------------- masters
  // TB master
  logic        tq_v = 0, tq_w = 0;
  logic [31:0] tq_a = '0, tq_d = '0;
  logic [3:0]  tq_s = '0;
  logic        tb_own = 1;
  // DMA
  logic        d_sel = 0, d_we = 0;
  logic [11:0] d_addr = '0;
  logic [31:0] d_wdata = '0, d_rdata;
  logic        d_err, d_irq, d_busy, d_done;
  logic [31:0] d_bytes;
  logic [7:0]  d_fifo;
  logic        dq_v, dq_r, dq_w, dr_v, dr_r, dr_e;
  logic [31:0] dq_a, dq_d, dr_d;
  logic [3:0]  dq_s;
  silicaflux_dma #(.DW(32), .ENGINE(0)) u_dma (
    .clk, .rst_n, .rb_sel(d_sel), .rb_we(d_we), .rb_addr(d_addr), .rb_wdata(d_wdata), .rb_rdata(d_rdata),
    .rb_err(d_err), .irq(d_irq),
    .m_req_valid(dq_v), .m_req_ready(dq_r), .m_req_write(dq_w), .m_req_addr(dq_a), .m_req_wdata(dq_d),
    .m_req_wstrb(dq_s), .m_rsp_valid(dr_v), .m_rsp_ready(dr_r), .m_rsp_rdata(dr_d), .m_rsp_error(dr_e),
    .busy(d_busy), .ev_done(d_done), .bytes_done(d_bytes), .fifo_level(d_fifo)
  );

  // master mux -> A
  logic        a_qv, a_qr, a_qw, a_rv, a_rr, a_re;
  logic [31:0] a_qa, a_qd, a_rd;
  logic [3:0]  a_qs;
  assign a_qv = tb_own ? tq_v : dq_v;
  assign a_qw = tb_own ? tq_w : dq_w;
  assign a_qa = tb_own ? tq_a : dq_a;
  assign a_qd = tb_own ? tq_d : dq_d;
  assign a_qs = tb_own ? tq_s : dq_s;
  assign dq_r = !tb_own && a_qr;
  assign dr_v = !tb_own && a_rv;
  assign dr_d = a_rd;
  assign dr_e = a_re;
  assign a_rr = tb_own ? 1'b1 : dr_r;

  // monitors on the DMA port
  logic        dm_v, to_v;
  logic [31:0] dm_a, dm_i, to_a, to_i;
  logic [31:0] to_limit = 32'd0;
  sfras_dma_mon u_dmon (.clk, .rst_n, .req_valid(dq_v), .req_ready(dq_r), .req_write(dq_w), .req_addr(dq_a),
                        .rsp_valid(dr_v), .rsp_ready(dr_r), .rsp_error(dr_e), .ev_valid(dm_v), .ev_addr(dm_a), .ev_info(dm_i));
  sfras_timeout_mon u_tmon (.clk, .rst_n, .limit(to_limit), .req_valid(dq_v), .req_ready(dq_r), .req_write(dq_w),
                            .req_addr(dq_a), .rsp_valid(dr_v), .rsp_ready(dr_r), .ev_valid(to_v), .ev_addr(to_a), .ev_info(to_i));

  // A -> fault injector -> B
  logic        b_qv, b_qr, b_qw, b_rv, b_rr, b_re, bi_armed, bi_fired;
  logic [31:0] b_qa, b_qd, b_rd;
  logic [3:0]  b_qs;
  sfras_sfb_fault_inj #(.DW(32)) u_binj (
    .clk, .rst_n, .arm(bfi_arm[0]), .mode(bfi_mode), .mask(bfi_mask[31:0]), .delay(bfi_delay),
    .armed(bi_armed), .fired(bi_fired),
    .m_req_valid(a_qv), .m_req_ready(a_qr), .m_req_write(a_qw), .m_req_addr(a_qa), .m_req_wdata(a_qd), .m_req_wstrb(a_qs),
    .m_rsp_valid(a_rv), .m_rsp_ready(a_rr), .m_rsp_rdata(a_rd), .m_rsp_error(a_re),
    .s_req_valid(b_qv), .s_req_ready(b_qr), .s_req_write(b_qw), .s_req_addr(b_qa), .s_req_wdata(b_qd), .s_req_wstrb(b_qs),
    .s_rsp_valid(b_rv), .s_rsp_ready(b_rr), .s_rsp_rdata(b_rd), .s_rsp_error(b_re)
  );

  // B -> parity link -> C
  logic        c_qv, c_qr, c_qw, c_rv, c_rr, c_re, pl_armed, pl_fired, pl_ev;
  logic [31:0] c_qa, c_qd, c_rd, pl_a, pl_i;
  logic [3:0]  c_qs;
  sfras_sfb_par_link #(.DW(32)) u_link (
    .clk, .rst_n,
    .m_req_valid(b_qv), .m_req_ready(b_qr), .m_req_write(b_qw), .m_req_addr(b_qa), .m_req_wdata(b_qd), .m_req_wstrb(b_qs),
    .m_rsp_valid(b_rv), .m_rsp_ready(b_rr), .m_rsp_rdata(b_rd), .m_rsp_error(b_re),
    .s_req_valid(c_qv), .s_req_ready(c_qr), .s_req_write(c_qw), .s_req_addr(c_qa), .s_req_wdata(c_qd), .s_req_wstrb(c_qs),
    .s_rsp_valid(c_rv), .s_rsp_ready(c_rr), .s_rsp_rdata(c_rd), .s_rsp_error(c_re),
    .inj_req_arm(bfi_arm[1] && bfi_mode == 2'd0), .inj_rsp_arm(bfi_arm[1] && bfi_mode == 2'd1),
    .inj_armed(pl_armed), .inj_fired(pl_fired), .ev_valid(pl_ev), .ev_addr(pl_a), .ev_info(pl_i)
  );
  assign bfi_busy = {pl_armed, bi_armed};

  // C -> router -> memories (SFB2: one outstanding transaction)
  logic        sel_q, c_sel;
  logic [1:0]  s_qv, s_qr, s_rv, s_re, s_rp;
  logic [63:0] s_rd;
  assign c_sel = c_qa[16];
  assign s_qv  = {c_qv && c_sel, c_qv && !c_sel};
  assign c_qr  = c_sel ? s_qr[1] : s_qr[0];
  assign c_rv  = sel_q ? s_rv[1] : s_rv[0];
  assign c_rd  = sel_q ? s_rd[63:32] : s_rd[31:0];
  assign c_re  = sel_q ? s_re[1] : s_re[0];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) sel_q <= 1'b0;
    else if (c_qv && c_qr) sel_q <= c_sel;
  end

  // memories
  logic [AW-1:0] m_ev_a0, m_ev_a1;
  logic [6:0]    m_syn0, m_syn1;
  logic [5:0]    m_idx0, m_idx1;
  logic [N0-1:0] tst_rd0;
  logic [N1-1:0] tst_rd1;
  logic          tst_rdy0, tst_rdy1;
  sfras_sfb_ecc_slave #(.DW(32), .DEPTH(DEPTH), .POISON_MODE(`SFRAS_POISON_BIT), .FI_EN(FI), .SCRUB_MAX_WAIT(8)) u_m0 (
    .clk, .rst_n,
    .req_valid(s_qv[0]), .req_ready(s_qr[0]), .req_write(c_qw), .req_addr(c_qa), .req_wdata(c_qd), .req_wstrb(c_qs),
    .rsp_valid(s_rv[0]), .rsp_ready(c_rr), .rsp_rdata(s_rd[31:0]), .rsp_error(s_re[0]), .rsp_poison(s_rp[0]),
    .scr_req_valid(m_sq_v[0]), .scr_req_ready(m_sq_r[0]), .scr_req_op(m_sq_op[1:0]), .scr_req_addr(m_sq_a[AW-1:0]),
    .scr_rsp_valid(m_sr_v[0]), .scr_rsp_op(m_sr_op[1:0]), .scr_rsp_addr(m_sr_a[AW-1:0]), .scr_rsp_ce(m_sr_ce[0]),
    .scr_rsp_ue(m_sr_ue[0]), .scr_rsp_poison(m_sr_p[0]), .scr_rsp_wb(m_sr_wb[0]),
    .init_req_i(m_init_req[0]), .init_busy_o(m_init_busy[0]), .init_done_o(m_init_done[0]),
    .tst_active(1'b0), .tst_ready(tst_rdy0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata(tst_rd0),
    .ev_valid(m_ev_v[0]), .ev_ce(m_ev_ce[0]), .ev_ue(m_ev_ue[0]), .ev_poison(m_ev_p[0]), .ev_org(m_ev_org[2:0]),
    .ev_addr(m_ev_a0), .ev_syn(m_syn0), .ev_idx(m_idx0),
    .fi_arm_i(m_fi_arm[0]), .fi_mode_i(m_fi_mode), .fi_mask_i(m_fi_mask), .fi_addr_en_i(m_fi_aen), .fi_addr_i(m_fi_addr),
    .fi_armed_o(m_fi_armed[0]), .fi_fired_o(m_fi_fired[0]), .fi_fired_addr_o(m_fi_faddr[AW-1:0])
  );
  sfras_sfb_ecc_slave #(.DW(32), .DEPTH(DEPTH), .POISON_MODE(`SFRAS_POISON_SIG), .FI_EN(FI), .SCRUB_MAX_WAIT(8)) u_m1 (
    .clk, .rst_n,
    .req_valid(s_qv[1]), .req_ready(s_qr[1]), .req_write(c_qw), .req_addr(c_qa), .req_wdata(c_qd), .req_wstrb(c_qs),
    .rsp_valid(s_rv[1]), .rsp_ready(c_rr), .rsp_rdata(s_rd[63:32]), .rsp_error(s_re[1]), .rsp_poison(s_rp[1]),
    .scr_req_valid(m_sq_v[1]), .scr_req_ready(m_sq_r[1]), .scr_req_op(m_sq_op[3:2]), .scr_req_addr(m_sq_a[2*AW-1:AW]),
    .scr_rsp_valid(m_sr_v[1]), .scr_rsp_op(m_sr_op[3:2]), .scr_rsp_addr(m_sr_a[2*AW-1:AW]), .scr_rsp_ce(m_sr_ce[1]),
    .scr_rsp_ue(m_sr_ue[1]), .scr_rsp_poison(m_sr_p[1]), .scr_rsp_wb(m_sr_wb[1]),
    .init_req_i(m_init_req[1]), .init_busy_o(m_init_busy[1]), .init_done_o(m_init_done[1]),
    .tst_active(1'b0), .tst_ready(tst_rdy1), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata(tst_rd1),
    .ev_valid(m_ev_v[1]), .ev_ce(m_ev_ce[1]), .ev_ue(m_ev_ue[1]), .ev_poison(m_ev_p[1]), .ev_org(m_ev_org[5:3]),
    .ev_addr(m_ev_a1), .ev_syn(m_syn1), .ev_idx(m_idx1),
    .fi_arm_i(m_fi_arm[1]), .fi_mode_i(m_fi_mode), .fi_mask_i(m_fi_mask[N1-1:0]), .fi_addr_en_i(m_fi_aen), .fi_addr_i(m_fi_addr),
    .fi_armed_o(m_fi_armed[1]), .fi_fired_o(m_fi_fired[1]), .fi_fired_addr_o(m_fi_faddr[2*AW-1:AW])
  );
  assign m_ev_addr = {m_ev_a1, m_ev_a0};
  assign m_ev_syn  = {2'd0, m_syn1, 2'd0, m_syn0};
  assign m_ev_idx  = {2'd0, m_idx1, 2'd0, m_idx0};

  // external event ports
  logic [3:0]  tbx_v = '0;                           // TB-driven ports 4..7
  logic [15:0] tbx_t = '0;
  assign ext_v  = {tbx_v, bi_fired || pl_fired, to_v, pl_ev, dm_v};
  assign ext_t  = {tbx_t, `SFRAS_EV_FI, `SFRAS_EV_TIMEOUT, `SFRAS_EV_BUS_PARITY, `SFRAS_EV_DMA_ERR};
  assign ext_a  = {32'h4004, 32'h4003, 32'h4002, 32'h4001, 32'd0, to_a, pl_a, dm_a};
  assign ext_av = 8'b1111_0111;
  assign ext_i  = {32'd7, 32'd6, 32'd5, 32'd4, 32'h8000_0000 | 32'(pl_fired), to_i, pl_i, dm_i};
  assign ext_c  = '0;

  // ================================================================ helpers
  int errors = 0;
  task automatic fail(input string m);
    errors++;
    if (errors <= 40) $display("FAIL @%0t: %s", $time, m);
  endtask
  task automatic chk(input bit c, input string m);
    if (!c) fail(m);
  endtask

  // register page (firmware view)
  logic last_err;
  task automatic reg_wr(input logic [11:0] a, input logic [31:0] d, input logic priv = 1'b1);
    rb_sel = 1; rb_we = 1; rb_addr = a; rb_wdata = d; rb_priv = priv;
    #1 last_err = rb_err;
    @(posedge clk); #1;
    rb_sel = 0; rb_we = 0; rb_priv = 1;
  endtask
  task automatic reg_rd(input logic [11:0] a, output logic [31:0] d);
    rb_sel = 1; rb_we = 0; rb_addr = a;
    #1 d = rb_rdata; last_err = rb_err;
    @(posedge clk); #1;
    rb_sel = 0;
  endtask
  function automatic logic [11:0] mreg(input int m, input logic [5:0] r);
    return 12'(`SFRAS_MEM_BASE + `SFRAS_MEM_STRIDE * m) + 12'(r);
  endfunction

  // DMA register bus
  task automatic dma_wr(input logic [11:0] a, input logic [31:0] d);
    d_sel = 1; d_we = 1; d_addr = a; d_wdata = d;
    @(posedge clk); #1;
    d_sel = 0; d_we = 0;
  endtask
  task automatic dma_rd(input logic [11:0] a, output logic [31:0] d);
    d_sel = 1; d_we = 0; d_addr = a;
    #1 d = d_rdata;
    @(posedge clk); #1;
    d_sel = 0;
  endtask

  // TB SFB2 master (one transaction at a time)
  logic        last_rerr, last_rpois;
  logic [31:0] last_rdata;
  task automatic sfb(input logic w, input logic [31:0] a, input logic [31:0] d, input logic [3:0] s);
    tb_own = 1;
    tq_v = 1; tq_w = w; tq_a = a; tq_d = d; tq_s = s;
    @(posedge clk);
    while (!a_qr) @(posedge clk);
    #1 tq_v = 0;
    while (!a_rv) @(posedge clk);
    last_rdata = a_rd; last_rerr = a_re; last_rpois = sel_q ? s_rp[1] : s_rp[0];
    @(posedge clk); #1;
  endtask
  task automatic mem_wr(input logic [31:0] a, input logic [31:0] d); sfb(1'b1, a, d, 4'hF); endtask
  task automatic mem_rd(input logic [31:0] a);                       sfb(1'b0, a, 32'd0, 4'h0); endtask

  // event log access
  localparam int LMAX = 64;
  int          n_log;
  logic [7:0]  l_src  [LMAX];
  logic [3:0]  l_type [LMAX];
  logic [1:0]  l_sev  [LMAX];
  logic        l_corr [LMAX];
  logic [31:0] l_addr [LMAX];
  logic [31:0] l_info [LMAX];
  task automatic drain_log();
    logic [31:0] v, st;
    n_log = 0;
    repeat (4) @(posedge clk);
    #1;
    reg_rd(`SFRAS_R_LOG_STAT, st);
    for (int i = 0; i < int'(st[15:0]); i++) begin
      reg_rd(`SFRAS_R_LOG_SRC, v);
      if (n_log < LMAX) begin
        l_src[n_log] = v[7:0]; l_type[n_log] = v[11:8]; l_sev[n_log] = v[13:12]; l_corr[n_log] = v[14];
        reg_rd(`SFRAS_R_LOG_ADDR, l_addr[n_log]);
        reg_rd(`SFRAS_R_LOG_INFO, l_info[n_log]);
        n_log++;
      end
      reg_wr(`SFRAS_R_LOG_POP, 32'd0);
    end
  endtask
  function automatic int count_ev(input int src, input int typ);
    int c;
    c = 0;
    for (int i = 0; i < n_log; i++) if (int'(l_src[i]) == src && int'(l_type[i]) == typ) c++;
    return c;
  endfunction
  function automatic int find_ev(input int src, input int typ);
    int r;
    r = -1;
    for (int i = n_log - 1; i >= 0; i--) if (int'(l_src[i]) == src && int'(l_type[i]) == typ) r = i;
    return r;
  endfunction
  task automatic show_log(input string w);
    for (int i = 0; i < n_log; i++)
      $display("  %s log[%0d]: src %0d type %0d sev %0d corr %b addr %h info %h", w, i, l_src[i], l_type[i], l_sev[i], l_corr[i], l_addr[i], l_info[i]);
  endtask
  task automatic clean_slate();
    reg_wr(`SFRAS_R_CTRL, 32'h0000_0703);                 // CLR_COUNTS | CLR_LOG | CLR_FIRST, LOG_EN, FATAL_CONTAIN
    reg_wr(`SFRAS_R_STATUS, 32'h0000_030F);
    reg_wr(`SFRAS_R_TYPE_STATUS, 32'h0000_FFFF);
  endtask

  // fault injection
  task automatic fi_unlock();
    reg_wr(`SFRAS_R_FI_KEY, `SFRAS_FI_KEY1);
    reg_wr(`SFRAS_R_FI_KEY, `SFRAS_FI_KEY2);
  endtask
  task automatic fi_mem(input int m, input logic [1:0] mode, input int a, input logic [63:0] mask);
    logic [31:0] st;
    reg_wr(`SFRAS_R_FI_MASK, mask[31:0]);
    reg_wr(`SFRAS_R_FI_MASK + 12'h4, mask[63:32]);
    reg_wr(`SFRAS_R_FI_ADDR, 32'(a));
    reg_wr(`SFRAS_R_FI_CTRL, (32'(m) << 8) | (32'h40) | (32'(mode) << 4) | 32'h1);
    chk(!last_err, "FI arm refused");
  endtask
  task automatic fi_wait_mem(input int m);
    logic [31:0] st;
    int t;
    t = 0;
    st = 32'h80;
    while (st[7] && t < 200) begin reg_rd(mreg(m, `SFRAS_M_STATUS), st); t++; end
    chk(!st[7], "FI did not complete");
  endtask
  task automatic fi_bus(input int b, input logic [1:0] mode, input logic [31:0] mask, input logic [15:0] dly);
    reg_wr(`SFRAS_R_FI_MASK, mask);
    reg_wr(`SFRAS_R_FI_DELAY, 32'(dly));
    reg_wr(`SFRAS_R_FI_CTRL, (32'(b + 8) << 8) | (32'(mode) << 16) | 32'h1);
    chk(!last_err, "bus FI arm refused");
  endtask

  task automatic dma_copy(input logic [31:0] src, input logic [31:0] dst, input logic [31:0] len, output logic [31:0] status);
    int t;
    tb_own = 0;
    dma_wr(`DMA_REG_SRC_ADDR, src);
    dma_wr(`DMA_REG_DST_ADDR, dst);
    dma_wr(`DMA_REG_LENGTH, len);
    dma_wr(`DMA_REG_CONTROL, 32'h1);
    t = 0;
    status = 32'h1;
    while (status[0] && t < 5000) begin dma_rd(`DMA_REG_STATUS, status); t++; end
    tb_own = 1;
  endtask

  task automatic wait_mem_init();
    logic [31:0] s0, s1;
    int t;
    t = 0;
    s0 = '0; s1 = '0;
    while (!(s0[4] && s1[4]) && t < 2000) begin
      reg_rd(mreg(0, `SFRAS_M_STATUS), s0); reg_rd(mreg(1, `SFRAS_M_STATUS), s1); t++;
    end
    chk(s0[4] && s1[4], "memories not initialised");
  endtask

  // ================================================================ tests
  logic [31:0] v, st, code, ea;
  int i0;

  initial begin
    ext_v_init();
    repeat (3) @(posedge clk);
    #1 rst_n = 1;
    wait_mem_init();

    // ---- T1 identification / reset state
    reg_rd(`SFRAS_R_ID, v);      chk(v == `SFRAS_ID_VALUE, $sformatf("T1 ID %h", v));
    reg_rd(`SFRAS_R_VERSION, v); chk(v == `SFRAS_VERSION_VALUE, "T1 VERSION");
    reg_rd(`SFRAS_R_CFG, v);
    chk(v[7:0] == NEXT && v[15:8] == NMEM && v[23:16] == 16 && v[24] == FI && v[31:25] == 17, $sformatf("T1 CFG %h", v));
    reg_rd(`SFRAS_R_CTRL, v);    chk(v == 32'h3, "T1 CTRL reset");
    reg_rd(`SFRAS_R_STATUS, v);  chk(v[15:0] == 0, $sformatf("T1 STATUS %h", v));
    reg_rd(`SFRAS_R_LOG_STAT, v); chk(v == 0, "T1 log not empty");
    reg_rd(mreg(1, `SFRAS_M_HI), v); chk(v == 255, "T1 MEM_HI reset = DEPTH-1");
    chk(!irq_ctrl && !irq_host && !fatal && !contain, "T1 outputs after reset");
    $display("RESULT T1 reset/identification: ID, VERSION, CFG (NP=17), reset values, outputs quiet");

    // ---- T2 register access rules (illegal control operations)
    clean_slate();
    reg_wr(`SFRAS_R_ID, 32'h1);          chk(last_err, "T2 write to RO not refused");
    reg_rd(`SFRAS_R_LOG_POP, v);         chk(last_err, "T2 read of WO not refused");
    reg_rd(12'hFFC, v);                  chk(last_err, "T2 unmapped read not refused");
    reg_wr(12'h7F0, 32'h1);              chk(last_err, "T2 unmapped write not refused");
    reg_wr(`SFRAS_R_FI_ADDR, 32'h5, 1'b0); chk(last_err, "T2 unprivileged FI write not refused");
    drain_log();
    chk(n_log == 3 && count_ev(P_REG, `SFRAS_EV_ILLEGAL_OP) == 3, $sformatf("T2 %0d log entries", n_log));
    chk(l_info[0][15:12] == `SFRAS_ILL_RO_OR_UNMAPPED && l_info[0][11:0] == `SFRAS_R_ID, "T2 reason/offset 0");
    chk(l_info[2][15:12] == `SFRAS_ILL_NOT_PRIV, "T2 reason NOT_PRIV");
    chk(l_sev[0] == `SFRAS_SEV_WARN, "T2 severity");
    reg_rd(`SFRAS_R_TYPE_CNT + 12'(4 * `SFRAS_EV_ILLEGAL_OP), v); chk(v == 3, "T2 type count");
    chk(irq_ctrl && !irq_host && cc_warn, "T2 interrupt routing (WARN -> ControlCore only)");
    reg_wr(`SFRAS_R_STATUS, 32'hF);
    chk(!irq_ctrl, "T2 W1C did not clear the interrupt");
    $display("RESULT T2 illegal operations: RO/unmapped/unprivileged writes refused with rb_err and logged (reason, offset); WARN -> irq_ctrl only");

    if (PROD != 0) begin
      // ---- production build: everything refused, nothing injected
      fi_allow = 1;
      clean_slate();
      fi_unlock();
      reg_rd(`SFRAS_R_FI_STATUS, v); chk(v[0] == 0, "PROD unlocked");
      mem_wr(32'h40, 32'hCAFE0001);
      reg_wr(`SFRAS_R_FI_CTRL, (32'h0 << 8) | 32'h40 | (32'd3 << 4) | 32'h1); chk(last_err, "PROD arm not refused");
      reg_wr(`SFRAS_R_FI_CTRL, (32'h8 << 8) | (32'd1 << 16) | 32'h1);         chk(last_err, "PROD bus arm not refused");
      repeat (10) @(posedge clk);
      mem_rd(32'h40); chk(last_rdata == 32'hCAFE0001 && !last_rerr, "PROD data changed");
      drain_log();
      chk(count_ev(P_REG, `SFRAS_EV_ILLEGAL_OP) == 4 && count_ev(P_REG, `SFRAS_EV_FI) == 0, "PROD refusals not logged");
      chk(!fi_active, "PROD fi_active");
      $display("RESULT PROD: FI_EN=0 build -- unlock and arm refused (4 ILLEGAL_OP events), no injection reached a memory or the bus");
      finish_test();
    end

    // ---- T3 fault-injection access control
    clean_slate();
    fi_allow = 0;
    fi_unlock();                                                 // not allowed by the hardware pin
    reg_rd(`SFRAS_R_FI_STATUS, v); chk(v[0] == 0 && v[1] == 0, "T3 unlocked without permission");
    fi_allow = 1;
    reg_wr(`SFRAS_R_FI_KEY, 32'h1234);                           // wrong key
    fi_unlock();
    reg_rd(`SFRAS_R_FI_STATUS, v); chk(v[0] == 1 && v[1] == 1, "T3 unlock");
    reg_wr(`SFRAS_R_FI_CTRL, (32'd7 << 8) | 32'h1);              // memory 7 does not exist
    chk(last_err, "T3 bad target not refused");
    drain_log();
    chk(count_ev(P_REG, `SFRAS_EV_ILLEGAL_OP) == 4, $sformatf("T3 refusals logged %0d", count_ev(P_REG, `SFRAS_EV_ILLEGAL_OP)));
    $display("RESULT T3 FI access control: refused without hardware permission, with a wrong key and for a bad target; unlocked only by KEY1,KEY2");

    // ---- T4 correctable error through the bus: corrected data, CE event with the bit index
    clean_slate();
    mem_wr(32'h28, 32'hDEADBEEF);                                // mem0 word 10
    fi_mem(0, `SFRAS_FI_INPLACE, 10, 64'h20);                    // flip stored bit 5
    fi_wait_mem(0);
    mem_rd(32'h28);
    chk(last_rdata == 32'hDEADBEEF && !last_rerr && !last_rpois, $sformatf("T4 read %h err %b", last_rdata, last_rerr));
    drain_log();
    i0 = find_ev(P_MEM, `SFRAS_EV_MEM_CE);
    chk(i0 >= 0 && l_addr[i0] == 10 && l_corr[i0] && l_info[i0][7:0] == 5 && l_info[i0][31:29] == `SFRAS_ORG_READ &&
        l_sev[i0] == `SFRAS_SEV_INFO, "T4 CE event fields");
    chk(count_ev(P_REG, `SFRAS_EV_FI) == 1 && count_ev(P_MEM + 2, `SFRAS_EV_FI) == 1, "T4 FI audit trail (armed + fired)");
    chk(!irq_ctrl, "T4 INFO must not interrupt by default");
    $display("RESULT T4 CE: in-place single-bit fault corrected on an SFB2 read (data intact, rsp_error=0), MEM_CE logged with address 10, bit 5, origin READ; FI armed+fired audited");

    // ---- T5 uncorrectable error contained at the bus
    clean_slate();
    mem_wr(32'h2C, 32'h12345678);                                // word 11
    fi_mem(0, `SFRAS_FI_INPLACE, 11, (64'h1 << 3) | (64'h1 << 17));
    fi_wait_mem(0);
    mem_rd(32'h2C);
    chk(last_rerr && last_rpois, "T5 UE not signalled on the bus");
    drain_log();
    i0 = find_ev(P_MEM, `SFRAS_EV_MEM_UE);
    chk(i0 >= 0 && l_addr[i0] == 11 && !l_corr[i0] && l_sev[i0] == `SFRAS_SEV_ERROR, "T5 UE event");
    reg_rd(`SFRAS_R_FIRST_SRC, v); chk(v[31] && v[7:0] == P_MEM && v[11:8] == `SFRAS_EV_MEM_UE, $sformatf("T5 FIRST_SRC %h", v));
    reg_rd(`SFRAS_R_FIRST_ADDR, v); chk(v == 11, "T5 FIRST_ADDR");
    chk(irq_ctrl && !irq_host, "T5 ERROR interrupt routing");
    mem_wr(32'h2C, 32'h0);                                       // rewrite clears it
    mem_rd(32'h2C); chk(!last_rerr, "T5 rewrite did not clear the UE");
    $display("RESULT T5 UE: double-bit fault answered rsp_error=1 + poison on SFB2, MEM_UE logged (ERROR), first-error capture, irq_ctrl");

    // ---- T6 DMA copy over an uncorrectable word: aborted, nothing past it written
    clean_slate();
    for (int i = 0; i < 16; i++) mem_wr(32'(4 * i), 32'h5000_0000 + i);
    for (int i = 0; i < 16; i++) mem_wr(32'h1_0000 + 32'(4 * i), 32'hAAAA_0000 + i);
    fi_mem(0, `SFRAS_FI_INPLACE, 5, (64'h1 << 0) | (64'h1 << 30));
    fi_wait_mem(0);
    dma_copy(32'h0, 32'h1_0000, 32'd64, st);
    dma_rd(`DMA_REG_ERROR_CODE, code);
    dma_rd(`DMA_REG_ERROR_ADDR, ea);
    chk(st[`DMA_STATUS_ERROR] && code == 32'(`DMA_ERR_READ_BUS) && ea == 32'h14,
        $sformatf("T6 DMA status %h code %0d addr %h", st, code, ea));
    for (int i = 0; i < 16; i++) begin
      mem_rd(32'h1_0000 + 32'(4 * i));
      chk(!last_rerr && last_rdata == ((i < 5) ? 32'h5000_0000 + i : 32'hAAAA_0000 + i),
          $sformatf("T6 destination word %0d = %h", i, last_rdata));
    end
    drain_log();
    chk(count_ev(P_MEM, `SFRAS_EV_MEM_UE) == 1 && count_ev(0, `SFRAS_EV_DMA_ERR) == 1, "T6 UE + DMA_ERR events");
    i0 = find_ev(0, `SFRAS_EV_DMA_ERR); chk(i0 >= 0 && l_addr[i0] == 32'h14 && l_info[i0][31] == 0, "T6 DMA_ERR address / direction");
    mem_wr(32'h14, 32'h0);
    $display("RESULT T6 DMA containment: DMA aborted with READ_BUS at 0x14; words 0-4 copied, words 5-15 of the destination untouched; MEM_UE + DMA_ERR logged");

    // ---- T7 DMA failure injected on the bus (forced error response)
    clean_slate();
    fi_bus(0, 2'd1, 32'h0, 16'd0);
    dma_copy(32'h0, 32'h1_0040, 32'd16, st);
    dma_rd(`DMA_REG_ERROR_CODE, code);
    chk(st[`DMA_STATUS_ERROR] && code == 32'(`DMA_ERR_READ_BUS), "T7 forced error not reported by DMA");
    drain_log();
    chk(count_ev(0, `SFRAS_EV_DMA_ERR) == 1 && count_ev(3, `SFRAS_EV_FI) == 1 && count_ev(P_REG, `SFRAS_EV_FI) == 1, "T7 events");
    $display("RESULT T7 injected DMA failure: forced bus error -> DMA_ERR_READ_BUS, DMA_ERR event, injection audited");

    // ---- T8 timeout: response delayed beyond the monitor limit
    clean_slate();
    to_limit = 32'd40;
    fi_bus(0, 2'd2, 32'h0, 16'd100);
    dma_copy(32'h0, 32'h1_0080, 32'd8, st);
    chk(st[`DMA_STATUS_DONE] && !st[`DMA_STATUS_ERROR], "T8 delayed transfer should complete");
    mem_rd(32'h1_0080); chk(last_rdata == 32'h5000_0000, "T8 data");
    drain_log();
    i0 = find_ev(2, `SFRAS_EV_TIMEOUT);
    chk(i0 >= 0 && l_sev[i0] == `SFRAS_SEV_ERROR && count_ev(2, `SFRAS_EV_TIMEOUT) == 1, "T8 TIMEOUT event");
    to_limit = 32'd0;
    $display("RESULT T8 timeout: 100-cycle response delay -> one TIMEOUT event (limit 40), transfer completed correctly");

    // ---- T9 bus parity: request corruption refused, response corruption flagged
    clean_slate();
    mem_wr(32'h1_0050, 32'h0BAD_F00D);
    fi_bus(1, 2'd0, 32'h0, 16'd0);                               // flip request parity
    mem_wr(32'h1_0050, 32'h1111_1111);
    chk(last_rerr, "T9 corrupted request not refused");
    mem_rd(32'h1_0050); chk(last_rdata == 32'h0BAD_F00D && !last_rerr, "T9 corrupted request reached the memory");
    fi_bus(1, 2'd1, 32'h0, 16'd0);                               // flip response parity
    mem_rd(32'h1_0050); chk(last_rerr, "T9 corrupted response not flagged");
    drain_log();
    chk(count_ev(1, `SFRAS_EV_BUS_PARITY) == 2, $sformatf("T9 parity events %0d", count_ev(1, `SFRAS_EV_BUS_PARITY)));
    i0 = find_ev(1, `SFRAS_EV_BUS_PARITY); chk(i0 >= 0 && l_info[i0][31] == 0 && l_addr[i0] == 32'h1_0050, "T9 request-side event");
    $display("RESULT T9 bus parity: corrupted request never executed (local error response), corrupted response delivered with rsp_error; 2 BUS_PARITY events");

    // ---- T10 corrupted response OUTSIDE parity coverage (characterisation of an unprotected segment)
    clean_slate();
    mem_wr(32'h0, 32'h5000_0000);
    fi_bus(0, 2'd0, 32'h0000_0100, 16'd0);                       // flip rdata bit 8 between link and master
    mem_rd(32'h0);
    chk(last_rdata == 32'h5000_0100 && !last_rerr, "T10 expected undetected corruption on the unprotected segment");
    drain_log();
    chk(count_ev(3, `SFRAS_EV_FI) == 1 && count_ev(1, `SFRAS_EV_BUS_PARITY) == 0 && count_ev(0, `SFRAS_EV_DMA_ERR) == 0,
        "T10 events");
    $display("RESULT T10 UNPROTECTED: a response corrupted between the parity checker and the master is NOT detected (only the injection audit is logged) -- listed as a single point of failure");

    // ---- T11 scrub through the register page (mem1, signature poison mode)
    clean_slate();
    for (int i = 0; i < 64; i++) mem_wr(32'h1_0000 + 32'(4 * i), 32'h7000_0000 + i);
    fi_mem(1, `SFRAS_FI_INPLACE, 3,  64'h1 << 2);  fi_wait_mem(1);
    fi_mem(1, `SFRAS_FI_INPLACE, 7,  64'h1 << 31); fi_wait_mem(1);
    fi_mem(1, `SFRAS_FI_INPLACE, 30, 64'h1 << 36); fi_wait_mem(1);   // a check bit
    reg_wr(mreg(1, `SFRAS_M_LO), 0); reg_wr(mreg(1, `SFRAS_M_HI), 63); reg_wr(mreg(1, `SFRAS_M_INTERVAL), 0);
    reg_wr(mreg(1, `SFRAS_M_CTRL), 32'h0000_030F);                   // CLR_COUNTS | START | VERIFY | FIX | ONE_PASS | EN
    v = 0; i0 = 0;
    while (!v[2] && i0 < 500) begin reg_rd(mreg(1, `SFRAS_M_STATUS), v); i0++; end
    chk(v[2], "T11 scrub pass did not complete");
    reg_rd(mreg(1, `SFRAS_M_CE), v);   chk(v == 3, $sformatf("T11 CE %0d", v));
    reg_rd(mreg(1, `SFRAS_M_FIX), v);  chk(v == 3, "T11 FIX");
    reg_rd(mreg(1, `SFRAS_M_HARD), v); chk(v == 0, "T11 HARD");
    reg_rd(mreg(1, `SFRAS_M_PASS), v); chk(v == 1, "T11 PASS");
    drain_log();
    chk(count_ev(P_MEM + 3, `SFRAS_EV_MEM_CE) == 3, $sformatf("T11 scrub CE events %0d", count_ev(P_MEM + 3, `SFRAS_EV_MEM_CE)));
    i0 = find_ev(P_MEM + 3, `SFRAS_EV_MEM_CE); chk(i0 >= 0 && l_info[i0][31:29] == `SFRAS_ORG_SCRUB, "T11 origin SCRUB");
    clean_slate();
    mem_rd(32'h1_000C); mem_rd(32'h1_001C); mem_rd(32'h1_0078);
    drain_log();
    chk(n_log == 0, "T11 words not clean after scrub");
    // recovery fault: corrupt the scrub write-back -> verify fails -> RECOVERY event
    fi_mem(1, `SFRAS_FI_INPLACE, 9, 64'h1 << 4); fi_wait_mem(1);
    fi_mem(1, `SFRAS_FI_SCRUB_WB, 9, 64'h1 << 12);
    reg_wr(mreg(1, `SFRAS_M_CTRL), 32'h0000_030F);
    v = 0; i0 = 0;
    while (!v[2] && i0 < 500) begin reg_rd(mreg(1, `SFRAS_M_STATUS), v); i0++; end
    reg_rd(mreg(1, `SFRAS_M_HARD), v); chk(v == 1, "T11 recovery fault not detected");
    drain_log();
    i0 = find_ev(P_MEM + 4, `SFRAS_EV_RECOVERY); chk(i0 >= 0 && l_addr[i0] == 9 && l_sev[i0] == `SFRAS_SEV_WARN, "T11 RECOVERY event");
    // UE found by scrub with stop policy
    mem_wr(32'h1_0024, 32'h0);
    fi_mem(1, `SFRAS_FI_INPLACE, 40, (64'h1 << 1) | (64'h1 << 20)); fi_wait_mem(1);
    reg_wr(mreg(1, `SFRAS_M_CTRL), 32'h0000_031F);                   // + STOP_ON_UE
    v = 0; i0 = 0;
    while (!v[1] && i0 < 500) begin reg_rd(mreg(1, `SFRAS_M_STATUS), v); i0++; end
    chk(v[1] && v[6], "T11 scrub did not stop at the UE");
    reg_rd(mreg(1, `SFRAS_M_UE_ADDR), v); chk(v == 40, "T11 UE_ADDR");
    reg_wr(mreg(1, `SFRAS_M_CTRL), 32'h0000_010C);                   // disable + acknowledge
    mem_wr(32'h1_00A0, 32'h0);
    $display("RESULT T11 scrub: 3 seeded single-bit faults (data + check bit) found, written back, verified; injected write-back fault -> RECOVERY; UE stop policy -> STOPPED_UE at word 40");

    // ---- T12 aggregation through the top + log-threshold interrupt
    clean_slate();
    reg_wr(`SFRAS_R_IRQ_EN_CTRL, 32'h10);                            // log threshold only
    reg_wr(`SFRAS_R_LOG_THR, 32'd3);
    tbx_t = {4'(`SFRAS_EV_ILLEGAL_OP), 4'(`SFRAS_EV_MEM_CE), 4'(`SFRAS_EV_ILLEGAL_OP), 4'(`SFRAS_EV_MEM_CE)};
    for (int c = 0; c < 3; c++) begin tbx_v = 4'hF; @(posedge clk); #1; end
    tbx_v = 4'h0;
    repeat (8) @(posedge clk); #1;
    reg_rd(`SFRAS_R_TYPE_CNT + 12'(4 * `SFRAS_EV_MEM_CE), v);     chk(v == 6, $sformatf("T12 CE count %0d", v));
    reg_rd(`SFRAS_R_TYPE_CNT + 12'(4 * `SFRAS_EV_ILLEGAL_OP), v); chk(v == 6, "T12 ILLEGAL count");
    for (int p = 4; p < 8; p++) begin reg_rd(`SFRAS_R_SRC_CNT + 12'(4 * p), v); chk(v == 3, $sformatf("T12 src %0d count %0d", p, v)); end
    reg_rd(`SFRAS_R_LOG_STAT, st);
    chk(int'(st[15:0]) + int'(st[31:16]) == 12, $sformatf("T12 logged %0d + lost %0d != 12", st[15:0], st[31:16]));
    chk(irq_ctrl, "T12 log-threshold interrupt");
    reg_rd(`SFRAS_R_STATUS, v); chk(v[8] == (st[31:16] != 0), "T12 LOG_OVF");
    ea = st;
    while (st[15:0] >= 3) begin reg_wr(`SFRAS_R_LOG_POP, 0); reg_rd(`SFRAS_R_LOG_STAT, st); end
    chk(!irq_ctrl, "T12 log-threshold interrupt not released");
    reg_wr(`SFRAS_R_IRQ_EN_CTRL, 32'hE);
    $display("RESULT T12 aggregation: 12 simultaneous events on 4 ports counted exactly (type + source), logged %0d + lost %0d; LOG_THR interrupt asserted / released", ea[15:0], ea[31:16]);

    // ---- T13 thermal: warning, clamped threshold, fatal (hardware shutdown), stale sensor
    clean_slate();
    reg_wr(`SFRAS_R_THERM_CTRL, 1);
    reg_wr(`SFRAS_R_THERM_FATAL, 32'd4000); chk(last_err, "T13 clamp not reported");
    reg_rd(`SFRAS_R_THERM_FATAL, v); chk(v == 3400, $sformatf("T13 fatal threshold %0d", v));
    th_drive(12'd2900); th_drive(12'd3100); th_drive(12'd3150);
    chk(!th_shut && !fatal, "T13 premature shutdown");
    th_drive(12'd3500);
    chk(th_shut, "T13 thermal shutdown not immediate");
    repeat (3) @(posedge clk); #1;
    chk(fatal && contain && irq_host && cc_fatal, "T13 fatal propagation");
    th_drive(12'd3300);
    chk(!th_shut, "T13 shutdown not released below threshold - hysteresis");
    chk(fatal, "T13 fatal must stay sticky");
    reg_wr(`SFRAS_R_THERM_STALE, 32'd20);
    repeat (30) @(posedge clk); #1;
    drain_log();
    chk(count_ev(P_THRM, `SFRAS_EV_THERM_WARN) == 2 && count_ev(P_THRM, `SFRAS_EV_THERM_FATAL) == 1, "T13 thermal events");
    i0 = find_ev(P_THRM, `SFRAS_EV_THERM_FATAL); chk(i0 >= 0 && l_sev[i0] == `SFRAS_SEV_FATAL && l_info[i0] == 3500, "T13 fatal record");
    chk(count_ev(P_REG, `SFRAS_EV_ILLEGAL_OP) == 1, "T13 clamp logged");
    // FATAL_LOCK: SEEN_FATAL can no longer be cleared
    reg_wr(`SFRAS_R_STATUS, 32'h8); chk(!fatal, "T13 W1C of fatal (unlocked) failed");
    th_drive(12'd3600);
    repeat (3) @(posedge clk); #1;
    reg_wr(`SFRAS_R_CTRL, 32'h7);                                    // FATAL_LOCK
    reg_wr(`SFRAS_R_STATUS, 32'h8);
    chk(fatal && contain, "T13 FATAL_LOCK did not hold fatal_o");
    reg_wr(`SFRAS_R_THERM_CTRL, 0);
    $display("RESULT T13 thermal: WARN at 3100, fatal threshold clamped to 3400, FATAL at 3500 -> immediate hardware shutdown, fatal_o/contain_o/irq_host; stale sensor warned; FATAL_LOCK holds fatal_o");

    // ---- T14 reset while active (scrub running, DMA running, fatal locked)
    reg_wr(mreg(0, `SFRAS_M_INTERVAL), 0); reg_wr(mreg(0, `SFRAS_M_CTRL), 32'h10D);
    tb_own = 0;
    dma_wr(`DMA_REG_SRC_ADDR, 32'h0); dma_wr(`DMA_REG_DST_ADDR, 32'h1_0000); dma_wr(`DMA_REG_LENGTH, 32'd256);
    dma_wr(`DMA_REG_CONTROL, 32'h1);
    repeat (20) @(posedge clk);
    #2 rst_n = 0;
    repeat (3) @(posedge clk);
    #1 rst_n = 1;
    tb_own = 1;
    chk(!fatal && !contain && !irq_ctrl && !irq_host && !th_shut && !wd_rst, "T14 outputs after reset");
    wait_mem_init();
    reg_rd(`SFRAS_R_STATUS, v); chk(v[15:0] == 0, "T14 STATUS after reset");
    reg_rd(`SFRAS_R_LOG_STAT, v); chk(v == 0, "T14 log after reset");
    reg_rd(`SFRAS_R_TYPE_CNT + 12'(4 * `SFRAS_EV_MEM_CE), v); chk(v == 0, "T14 counters after reset");
    reg_rd(`SFRAS_R_FI_STATUS, v); chk(v[0] == 0, "T14 FI must be locked after reset");
    reg_rd(mreg(0, `SFRAS_M_STATUS), v); chk(!v[0], "T14 scrub must be idle after reset");
    mem_rd(32'h4); chk(last_rdata == 0 && !last_rerr, "T14 memory not re-initialised");
    $display("RESULT T14 reset during DMA + scrub + locked fatal: all status, counters, log, outputs cleared; memories re-initialised; FI locked");

    // ---- T15 watchdog: kicks, bad key, lock, stage 1 (ERROR), stage 2 (FATAL + reset request)
    clean_slate();
    reg_wr(`SFRAS_R_WDOG_LOAD, 32'd40);
    reg_wr(`SFRAS_R_WDOG_CTRL, 32'h3);                               // EN | LOCK
    for (int k = 0; k < 4; k++) begin repeat (20) @(posedge clk); #1; reg_wr(`SFRAS_R_WDOG_KICK, `SFRAS_WDOG_KEY); end
    reg_wr(`SFRAS_R_WDOG_CTRL, 32'h0); chk(last_err, "T15 locked watchdog disabled");
    reg_wr(`SFRAS_R_WDOG_KICK, 32'h1234); chk(last_err, "T15 bad kick key accepted");
    reg_rd(`SFRAS_R_WDOG_STATUS, v); chk(v == 0, "T15 premature expiry");
    repeat (50) @(posedge clk); #1;
    reg_rd(`SFRAS_R_WDOG_STATUS, v); chk(v == 1, "T15 stage 1");
    chk(!fatal && irq_ctrl, "T15 stage 1 is ERROR, not FATAL");
    repeat (50) @(posedge clk); #1;
    reg_rd(`SFRAS_R_WDOG_STATUS, v); chk(v == 3 && wd_rst, "T15 stage 2 / reset request");
    chk(fatal && contain && irq_host, "T15 fatal propagation");
    drain_log();
    chk(count_ev(P_WDOG, `SFRAS_EV_WDOG) == 2 && count_ev(P_REG, `SFRAS_EV_ILLEGAL_OP) == 2, "T15 events");
    i0 = find_ev(P_WDOG, `SFRAS_EV_WDOG); chk(i0 >= 0 && l_sev[i0] == `SFRAS_SEV_ERROR && l_sev[i0 + 1] == `SFRAS_SEV_FATAL, "T15 severities");
    $display("RESULT T15 watchdog: kicks hold it off, lock and key enforced, stage 1 -> ERROR, stage 2 -> FATAL + wdog_reset_req");

    // ---- T16 production lock: FI_LOCK refuses everything until reset
    #2 rst_n = 0; repeat (2) @(posedge clk); #1 rst_n = 1;
    wait_mem_init();
    clean_slate();
    fi_allow = 1;
    reg_wr(`SFRAS_R_CTRL, 32'hB);                                    // FI_LOCK
    fi_unlock();
    reg_rd(`SFRAS_R_FI_STATUS, v); chk(v[0] == 0 && v[2] == 1, "T16 FI_LOCK");
    mem_wr(32'h8, 32'h600D_DA7A);
    reg_wr(`SFRAS_R_FI_CTRL, 32'h0000_0071); chk(last_err, "T16 arm accepted under FI_LOCK");
    repeat (10) @(posedge clk);
    mem_rd(32'h8); chk(last_rdata == 32'h600D_DA7A && !last_rerr, "T16 data modified under FI_LOCK");
    reg_wr(`SFRAS_R_CTRL, 32'h3); reg_rd(`SFRAS_R_CTRL, v); chk(v[3], "T16 FI_LOCK cleared by software");
    $display("RESULT T16 FI_LOCK: set-only lock refuses unlock and arm until reset; memory untouched");

    finish_test();
  end

  task automatic th_drive(input logic [11:0] c);
    th_code = c; th_v = 1; @(posedge clk); #1; th_v = 0; @(posedge clk); #1;
  endtask
  task automatic ext_v_init();
    tbx_v = '0;
  endtask
  task automatic finish_test();
    if (errors == 0) $display("PASS tb_ras_system%s", (PROD != 0) ? " (PROD)" : "");
    else             $display("FAIL tb_ras_system: %0d errors", errors);
    $finish;
  endtask

  initial begin
    #(50_000_000);
    $display("FAIL tb_ras_system: global timeout");
    $finish;
  end
endmodule

`default_nettype wire
