// =============================================================================
// SilicaFlux RAS (Project 26) :: sfras_event_ctrl
// Central RAS event aggregation: severity, timestamp, counters, sticky status,
// event log, first-error capture.
//
// Event interface (one per port p = source id p; all signals valid with ev_valid):
//   ev_valid[p]                pulse, one event
//   ev_type [p*4 +: 4]         SFRAS_EV_*
//   ev_addr [p*32 +: 32]       address (memory word / bus byte address / register offset)
//   ev_addr_v[p]               address is meaningful
//   ev_info [p*32 +: 32]       source-specific information
//   ev_corr [p]                a correction WAS performed (only CE-type sources set it)
//
// Severity = max(hardware minimum for the type, software minimum SEV_CFG):
// software can escalate (e.g. MEM_UE -> FATAL for a memory without poison
// containment) but can never downgrade a FATAL thermal or watchdog event.
//
// Counters (exact; they never depend on the log): one per event type and one
// per source, CNT_W bits, saturating at all-ones with a sticky overflow flag.
// Several events of one type in the same cycle are all counted.
//
// Log: each port has a one-entry pending slot (stamped with the cycle counter
// and severity when the event arrives); a round-robin drain moves one slot per
// cycle into the LOG_DEPTH-entry FIFO.  An event whose port slot is still
// occupied, or that finds the log full / disabled, is counted in `lost` and sets
// STATUS.LOG_OVF -- never silently.  The oldest entries are kept (the first
// errors of a burst are the diagnostic ones).
//
// First-error capture: the first ERROR-or-FATAL event (lowest port index wins a
// tie) is frozen until clr_first, independent of the log.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfras_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfras_event_ctrl #(
  parameter int NP        = 8,
  parameter int LOG_DEPTH = 16,           // power of two, >= 2
  parameter int CNT_W     = 32,
  parameter int TS_W      = 48,
  localparam int SW       = (NP > 1) ? $clog2(NP) : 1,
  localparam int LW       = $clog2(LOG_DEPTH),
  localparam int RECW     = TS_W + 8 + 4 + 2 + 1 + 1 + 32 + 32
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // event ports
  input  wire logic [NP-1:0]     ev_valid,
  input  wire logic [NP*4-1:0]   ev_type,
  input  wire logic [NP*32-1:0]  ev_addr,
  input  wire logic [NP-1:0]     ev_addr_v,
  input  wire logic [NP*32-1:0]  ev_info,
  input  wire logic [NP-1:0]     ev_corr,
  // configuration / commands
  input  wire logic [31:0]       sev_cfg,       // 2 bits per type
  input  wire logic              log_en,
  input  wire logic              clr_counts,    // pulse
  input  wire logic              clr_log,       // pulse
  input  wire logic              clr_first,     // pulse
  input  wire logic              pop,           // pulse: remove log head
  input  wire logic [3:0]        sev_w1c,       // pulse mask: clear STATUS.SEEN_*
  input  wire logic              ovf_w1c,       // pulse: clear STATUS.LOG_OVF
  input  wire logic              cnt_ovf_w1c,   // pulse: clear STATUS.CNT_OVF
  input  wire logic [15:0]       type_w1c,      // pulse mask
  input  wire logic              fatal_lock,    // SEEN_FATAL not clearable
  // status
  output logic [TS_W-1:0]        ts,
  output logic [3:0]             sev_seen,
  output logic                   log_ovf,
  output logic                   cnt_ovf,
  output logic [15:0]            type_seen,
  output logic [16*CNT_W-1:0]    type_cnt,
  output logic [15:0]            type_ovf,
  output logic [NP*CNT_W-1:0]    src_cnt,
  output logic [NP-1:0]          src_ovf,
  // log head
  output logic [15:0]            log_count,
  output logic [15:0]            log_lost,
  output logic                   log_v,
  output logic [RECW-1:0]        log_head,      // {ts, src, type, sev, corr, addr_v, addr, info}
  // first error
  output logic                   first_v,
  output logic [RECW-1:0]        first_rec,
  // per-cycle summary (for interrupt / fatal logic and tests)
  output logic                   ev_any,
  output logic [3:0]             ev_sev_mask    // severities of the events in this cycle
);

  if (LOG_DEPTH < 2 || (LOG_DEPTH & (LOG_DEPTH - 1)) != 0) begin : g_err_log_depth
    `SFRAS_CFG_FATAL("sfras_event_ctrl: LOG_DEPTH must be a power of two >= 2")
  end
  if (NP < 1 || NP > 256) begin : g_err_np
    `SFRAS_CFG_FATAL("sfras_event_ctrl: NP must be 1..256")
  end

  // ---------------------------------------------------------------- severity
  function automatic logic [1:0] hw_min_sev(input logic [3:0] t, input logic stage2);
    case (t)
      `SFRAS_EV_MEM_CE:      hw_min_sev = `SFRAS_SEV_INFO;
      `SFRAS_EV_MEM_UE:      hw_min_sev = `SFRAS_SEV_ERROR;
      `SFRAS_EV_BUS_PARITY:  hw_min_sev = `SFRAS_SEV_ERROR;
      `SFRAS_EV_DMA_ERR:     hw_min_sev = `SFRAS_SEV_ERROR;
      `SFRAS_EV_WDOG:        hw_min_sev = stage2 ? `SFRAS_SEV_FATAL : `SFRAS_SEV_ERROR;
      `SFRAS_EV_THERM_WARN:  hw_min_sev = `SFRAS_SEV_WARN;
      `SFRAS_EV_THERM_FATAL: hw_min_sev = `SFRAS_SEV_FATAL;
      `SFRAS_EV_ILLEGAL_OP:  hw_min_sev = `SFRAS_SEV_WARN;
      `SFRAS_EV_POISON:      hw_min_sev = `SFRAS_SEV_ERROR;
      `SFRAS_EV_RECOVERY:    hw_min_sev = `SFRAS_SEV_WARN;
      `SFRAS_EV_TIMEOUT:     hw_min_sev = `SFRAS_SEV_ERROR;
      `SFRAS_EV_FI:          hw_min_sev = `SFRAS_SEV_INFO;
      default:               hw_min_sev = `SFRAS_SEV_WARN;      // unknown / reserved type
    endcase
  endfunction

  function automatic logic [1:0] max2(input logic [1:0] a, input logic [1:0] b);
    max2 = (a > b) ? a : b;
  endfunction

  logic [NP*2-1:0] sev;
  always_comb begin
    for (int p = 0; p < NP; p++)
      sev[p*2 +: 2] = max2(hw_min_sev(ev_type[p*4 +: 4], ev_info[p*32]), sev_cfg[ev_type[p*4 +: 4]*2 +: 2]);
  end

  // ---------------------------------------------------------------- per-cycle summary
  logic [15:0] t_hit;
  logic [3:0]  s_hit;
  always_comb begin
    t_hit = '0; s_hit = '0;
    for (int p = 0; p < NP; p++) begin
      if (ev_valid[p]) begin
        t_hit[ev_type[p*4 +: 4]] = 1'b1;
        s_hit[sev[p*2 +: 2]]     = 1'b1;
      end
    end
  end
  assign ev_any      = |ev_valid;
  assign ev_sev_mask = s_hit;

  // ---------------------------------------------------------------- timestamp
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) ts <= '0;
    else        ts <= ts + 1'b1;
  end

  // ---------------------------------------------------------------- counters
  localparam int PCW = $clog2(NP + 1);
  logic [PCW-1:0] t_n [16];
  always_comb begin
    for (int t = 0; t < 16; t++) begin
      t_n[t] = '0;
      for (int p = 0; p < NP; p++)
        if (ev_valid[p] && ev_type[p*4 +: 4] == 4'(t)) t_n[t] = t_n[t] + 1'b1;
    end
  end

  // returns {overflow, saturated sum}
  function automatic logic [CNT_W:0] sat_add(input logic [CNT_W-1:0] a, input logic [PCW-1:0] b);
    logic [CNT_W:0] s;
    s = {1'b0, a} + (CNT_W+1)'(b);
    sat_add = s[CNT_W] ? {1'b1, {CNT_W{1'b1}}} : {(b != '0 && a == '1), s[CNT_W-1:0]};
  endfunction

  logic [CNT_W:0] t_sum [16];
  logic [CNT_W:0] s_sum [NP];
  always_comb begin
    for (int t = 0; t < 16; t++) t_sum[t] = sat_add(type_cnt[t*CNT_W +: CNT_W], t_n[t]);
    for (int p = 0; p < NP; p++) s_sum[p] = sat_add(src_cnt[p*CNT_W +: CNT_W], PCW'(ev_valid[p]));
  end


  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      type_cnt <= '0; type_ovf <= '0; src_cnt <= '0; src_ovf <= '0;
    end else if (clr_counts) begin
      type_cnt <= '0; type_ovf <= '0; src_cnt <= '0; src_ovf <= '0;
    end else begin
      for (int t = 0; t < 16; t++) begin
        type_cnt[t*CNT_W +: CNT_W] <= t_sum[t][CNT_W-1:0];
        if (t_sum[t][CNT_W]) type_ovf[t] <= 1'b1;
      end
      for (int p = 0; p < NP; p++) begin
        src_cnt[p*CNT_W +: CNT_W] <= s_sum[p][CNT_W-1:0];
        if (s_sum[p][CNT_W]) src_ovf[p] <= 1'b1;
      end
    end
  end

  // ---------------------------------------------------------------- sticky status
  logic cnt_ovf_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sev_seen <= '0; type_seen <= '0; cnt_ovf_q <= 1'b0;
    end else begin
      sev_seen  <= (sev_seen & ~(sev_w1c & {!fatal_lock, 3'b111})) | s_hit;
      type_seen <= (type_seen & ~type_w1c) | t_hit;
      if (cnt_ovf_w1c) cnt_ovf_q <= 1'b0;
      if ((|type_ovf) || (|src_ovf)) cnt_ovf_q <= 1'b1;
    end
  end
  assign cnt_ovf = cnt_ovf_q;

  // ---------------------------------------------------------------- pending slots
  logic [NP-1:0]   pv_q;
  logic [RECW-1:0] prec_q [NP];
  logic [SW-1:0]   rr_q;

  // round-robin selection of one pending slot, starting at rr_q
  logic          drain_v;
  logic [SW-1:0] drain_p;
  // round robin without casts (Yosys 0.33): the first pending slot at or above rr_q,
  // else the first pending slot below it
  always_comb begin
    drain_v = 1'b0; drain_p = '0;
    for (int k = NP - 1; k >= 0; k--) begin
      if (pv_q[k] && (SW+1)'(k) >= {1'b0, rr_q}) begin drain_v = 1'b1; drain_p = SW'(k); end
    end
    if (!drain_v) begin
      for (int k = NP - 1; k >= 0; k--) begin
        if (pv_q[k]) begin drain_v = 1'b1; drain_p = SW'(k); end
      end
    end
  end

  // log FIFO
  logic [RECW-1:0] log_mem [LOG_DEPTH];
  logic [LW-1:0]   wp_q, rp_q;
  logic [LW:0]     cnt_q;
  wire log_full = (cnt_q == (LW+1)'(LOG_DEPTH));
  wire do_pop   = pop && (cnt_q != '0);
  wire do_push  = drain_v && log_en && !log_full;
  wire drop_drain = drain_v && !(log_en && !log_full);

  // events arriving while their slot is busy (and not freed this cycle)
  logic [NP-1:0] lost_in;
  always_comb begin
    for (int p = 0; p < NP; p++) lost_in[p] = ev_valid[p] && pv_q[p] && !(drain_v && drain_p == SW'(p));
  end
  localparam int LCW = $clog2(NP + 2);
  logic [LCW-1:0] n_lost;
  always_comb begin
    n_lost = LCW'(drop_drain);
    for (int p = 0; p < NP; p++) n_lost = n_lost + LCW'(lost_in[p]);
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pv_q <= '0; rr_q <= '0; wp_q <= '0; rp_q <= '0; cnt_q <= '0; log_lost <= '0; log_ovf <= 1'b0;
    end else begin
      // drain one slot
      if (drain_v) begin
        pv_q[drain_p] <= 1'b0;
        rr_q <= (drain_p == SW'(NP - 1)) ? '0 : drain_p + 1'b1;
      end
      // capture new events into free (or just freed) slots
      for (int p = 0; p < NP; p++) begin
        if (ev_valid[p] && !lost_in[p]) begin
          pv_q[p]   <= 1'b1;
          prec_q[p] <= {ts, 8'(p), ev_type[p*4 +: 4], sev[p*2 +: 2], ev_corr[p], ev_addr_v[p],
                        ev_addr[p*32 +: 32], ev_info[p*32 +: 32]};
        end
      end
      // FIFO
      if (clr_log) begin
        wp_q <= '0; rp_q <= '0; cnt_q <= '0; log_lost <= '0;
      end else begin
        if (do_push) begin
          log_mem[wp_q] <= prec_q[drain_p];
          wp_q <= wp_q + 1'b1;
        end
        if (do_pop) rp_q <= rp_q + 1'b1;
        cnt_q <= cnt_q + (LW+1)'(do_push) - (LW+1)'(do_pop);
        if (n_lost != '0) log_lost <= (log_lost > 16'hFFFF - 16'(n_lost)) ? 16'hFFFF : log_lost + 16'(n_lost);
      end
      if (ovf_w1c) log_ovf <= 1'b0;
      if (n_lost != '0) log_ovf <= 1'b1;
    end
  end

  assign log_count = 16'(cnt_q);
  assign log_v     = (cnt_q != '0);
  assign log_head  = log_mem[rp_q];

  // ---------------------------------------------------------------- first error
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      first_v <= 1'b0; first_rec <= '0;
    end else begin
      if (clr_first) first_v <= 1'b0;
      if (!first_v || clr_first) begin
        for (int p = NP - 1; p >= 0; p--) begin
          if (ev_valid[p] && sev[p*2 +: 2] >= `SFRAS_SEV_ERROR) begin
            first_v   <= 1'b1;
            first_rec <= {ts, 8'(p), ev_type[p*4 +: 4], sev[p*2 +: 2], ev_corr[p], ev_addr_v[p],
                          ev_addr[p*32 +: 32], ev_info[p*32 +: 32]};
          end
        end
      end
    end
  end

`ifdef SFRAS_ASSERT
  always_ff @(posedge clk) begin
    if (rst_n) begin
      assert (cnt_q <= (LW+1)'(LOG_DEPTH)) else $error("%m: log count overflow");
      assert (!(do_push && log_full)) else $error("%m: push into a full log");
    end
  end
`endif

endmodule

`default_nettype wire
