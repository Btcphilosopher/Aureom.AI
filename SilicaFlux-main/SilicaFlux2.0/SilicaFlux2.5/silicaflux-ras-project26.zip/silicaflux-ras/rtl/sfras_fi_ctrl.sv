// =============================================================================
// SilicaFlux RAS (Project 26) :: sfras_fi_ctrl
// Access control for fault injection.  An injection is armed ONLY if all of:
//   1. FI_EN = 1 at build time (FI_EN = 0: this block and every injection
//      datapath in the memories / bus injectors are compiled out);
//   2. allow_i = 1: hardware permission (TestCore test mode, or the secure
//      monitor's debug-unlock) -- not controllable by software;
//   3. lock_i = 0: CTRL.FI_LOCK, set-only until reset (production firmware sets
//      it at boot, after which nothing can re-enable injection);
//   4. the unlock sequence KEY1, KEY2 was written by a privileged master
//      (privilege is checked by the register file: unprivileged writes never
//      reach this block);
//   5. the target exists and is idle.
// Any violation is refused, counted and reported as an ILLEGAL_OP event with a
// reason code; a wrong key or loss of allow_i / set lock_i re-locks.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfras_defs.svh"
`include "sfras_regs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfras_fi_ctrl #(
  parameter int FI_EN = 1
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        allow_i,
  input  wire logic        lock_i,
  input  wire logic        key_wr,         // privileged write to FI_KEY
  input  wire logic [31:0] key_val,
  input  wire logic        relock,         // pulse
  input  wire logic        arm_req,        // privileged FI_CTRL.ARM
  input  wire logic        tgt_valid,      // the selected target exists
  input  wire logic        tgt_busy,       // the selected target is armed / injecting
  output logic             unlocked,
  output logic             arm_ok,         // pulse: route the arm to the target
  output logic             refuse,         // pulse
  output logic [3:0]       refuse_reason,  // SFRAS_ILL_*
  output logic [7:0]       arm_count,
  output logic [7:0]       refuse_count
);
  if (FI_EN != 0) begin : g_fi
    logic step_q;                            // KEY1 seen
    wire  perm = allow_i && !lock_i;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        unlocked <= 1'b0; step_q <= 1'b0; arm_count <= '0; refuse_count <= '0;
      end else begin
        if (!perm || relock) begin
          unlocked <= 1'b0; step_q <= 1'b0;
        end else if (key_wr) begin
          if (!step_q && key_val == `SFRAS_FI_KEY1) begin
            step_q <= 1'b1;
          end else if (step_q && key_val == `SFRAS_FI_KEY2) begin
            step_q <= 1'b0; unlocked <= 1'b1;
          end else begin
            step_q <= 1'b0; unlocked <= 1'b0;
          end
        end
        if (arm_ok && arm_count != '1)    arm_count <= arm_count + 1'b1;
        if (refuse && refuse_count != '1) refuse_count <= refuse_count + 1'b1;
      end
    end
    // refusals (combinational, registered by the event path)
    always_comb begin
      arm_ok = 1'b0; refuse = 1'b0; refuse_reason = 4'd0;
      if (key_wr) begin
        if (!perm) begin
          refuse = 1'b1; refuse_reason = `SFRAS_ILL_FI_NOT_ALLOWED;
        end else if (!((!step_q && key_val == `SFRAS_FI_KEY1) || (step_q && key_val == `SFRAS_FI_KEY2))) begin
          refuse = 1'b1; refuse_reason = `SFRAS_ILL_BAD_KEY;
        end
      end else if (arm_req) begin
        if (!perm || !unlocked) begin
          refuse = 1'b1; refuse_reason = `SFRAS_ILL_FI_NOT_ALLOWED;
        end else if (!tgt_valid || tgt_busy) begin
          refuse = 1'b1; refuse_reason = `SFRAS_ILL_FI_BUSY;
        end else begin
          arm_ok = 1'b1;
        end
      end
    end
  end else begin : g_no_fi
    always_comb begin
      unlocked = 1'b0; arm_ok = 1'b0; arm_count = '0;
      refuse = key_wr || arm_req;
      refuse_reason = `SFRAS_ILL_FI_NOT_ALLOWED;
    end
    logic [7:0] rc_q;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) rc_q <= '0;
      else if (refuse && rc_q != '1) rc_q <= rc_q + 1'b1;
    end
    assign refuse_count = rc_q;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused = allow_i ^ lock_i ^ (^key_val) ^ relock ^ tgt_valid ^ tgt_busy;
    /* verilator lint_on UNUSEDSIGNAL */
  end
endmodule

`default_nettype wire
