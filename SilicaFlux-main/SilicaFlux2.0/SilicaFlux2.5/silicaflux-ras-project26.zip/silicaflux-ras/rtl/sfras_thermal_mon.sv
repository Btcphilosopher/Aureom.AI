// =============================================================================
// SilicaFlux RAS (Project 26) :: sfras_thermal_mon
// Threshold monitor for an on-die temperature sensor delivering unsigned codes
// (monotonic in temperature; the code-to-degree mapping belongs to the sensor
// and is NOT assumed here).
//   WARN : code >= warn_thr  -> event THERM_WARN (info = {0, code}); leaves WARN
//          when code < warn_thr - hyst (no event).
//   FATAL: code >= fatal_thr -> event THERM_FATAL (info = code) and
//          shutdown = 1 immediately, in hardware, without firmware; leaves when
//          code < fatal_thr - hyst.  fatal_thr is clamped to FATAL_MAX by the
//          register file, so software cannot disable the protection.
//   STALE: en, stale_lim != 0 and no sample for stale_lim cycles -> event
//          THERM_WARN (info[31] = 1, sensor fault), once until the next sample.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfras_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfras_thermal_mon #(
  parameter int TW = 12
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          en,
  input  wire logic [TW-1:0] warn_thr,
  input  wire logic [TW-1:0] fatal_thr,
  input  wire logic [TW-1:0] hyst,
  input  wire logic [31:0]   stale_lim,
  input  wire logic          s_valid,
  input  wire logic [TW-1:0] s_code,
  output logic [TW-1:0]      last_code,
  output logic               seen,
  output logic               warn,
  output logic               fatal,
  output logic               stale,
  output logic               shutdown,
  output logic               ev_valid,
  output logic [3:0]         ev_type,
  output logic [31:0]        ev_info
);
  logic [31:0] st_cnt_q;

  function automatic logic below(input logic [TW-1:0] c, input logic [TW-1:0] thr, input logic [TW-1:0] h);
    below = ({1'b0, c} + {1'b0, h}) < {1'b0, thr};      // c < thr - h without underflow
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      last_code <= '0; seen <= 1'b0; warn <= 1'b0; fatal <= 1'b0; stale <= 1'b0; st_cnt_q <= '0;
      ev_valid <= 1'b0; ev_type <= '0; ev_info <= '0;
    end else begin
      ev_valid <= 1'b0;
      if (!en) begin
        warn <= 1'b0; fatal <= 1'b0; stale <= 1'b0; st_cnt_q <= '0;
      end else begin
        if (s_valid) begin
          last_code <= s_code; seen <= 1'b1; stale <= 1'b0; st_cnt_q <= '0;
          // fatal has priority: one event per sample
          if (!fatal && s_code >= fatal_thr) begin
            fatal <= 1'b1; warn <= 1'b1;
            ev_valid <= 1'b1; ev_type <= `SFRAS_EV_THERM_FATAL; ev_info <= 32'(s_code);
          end else if (!warn && s_code >= warn_thr) begin
            warn <= 1'b1;
            ev_valid <= 1'b1; ev_type <= `SFRAS_EV_THERM_WARN; ev_info <= 32'(s_code);
          end
          if (fatal && below(s_code, fatal_thr, hyst)) fatal <= 1'b0;
          if (warn && below(s_code, warn_thr, hyst) && below(s_code, fatal_thr, hyst)) warn <= 1'b0;
        end else if (stale_lim != '0) begin
          if (st_cnt_q >= stale_lim) begin
            if (!stale) begin
              stale <= 1'b1;
              ev_valid <= 1'b1; ev_type <= `SFRAS_EV_THERM_WARN; ev_info <= 32'h8000_0000 | 32'(last_code);
            end
          end else begin
            st_cnt_q <= st_cnt_q + 1'b1;
          end
        end
      end
    end
  end
  assign shutdown = fatal;

endmodule

`default_nettype wire
