// =============================================================================
// SilicaFlux RAS (Project 26) :: silicaflux_ras -- RASCore top
//
//   register page (ControlCore page bus + rb_priv) ──► register file ─┐
//                                                                     │ cfg / status
//   NEXT external event ports ───────────────────────┐                │
//   NMEM ECC memories: error events ─► convert ──────┤                │
//                      scrub port ◄──► sfras_scrub ──┤ (recovery ev.) │
//                      fault-inj  ◄─── sfras_fi_ctrl ┤ (fired ev.)    │
//   sfras_watchdog ──────────────────────────────────┤                │
//   sfras_thermal_mon ◄── on-die sensor ─────────────┤                │
//   register file (ILLEGAL_OP, FI audit) ────────────┤                │
//                                                    ▼                │
//                                         sfras_event_ctrl ──────────┘
//                                         (severity, timestamp, counters,
//                                          log, first error, sticky status)
//                                                    │
//        irq_ctrl_o (ControlCore INTC)  irq_host_o (host)  fatal_o  contain_o
//        cc_warn_o / cc_fatal_o (existing cc_ras EXT_WARN / EXT_FATAL inputs)
//        therm_shutdown_o / wdog_reset_req_o (hardware, no firmware involved)
//
// Source ids (= event ports = SRC_CNT index = LOG_SRC.SRC):
//   0 .. NEXT-1                 external ports (DMA monitors, parity links,
//                               timeout monitors, ControlCore illegal ops, ...)
//   NEXT + 3m + 0               ECC memory m: CE / UE / POISON
//   NEXT + 3m + 1               ECC memory m: scrub recovery failure
//   NEXT + 3m + 2               ECC memory m: fault injection fired
//   NEXT + 3*NMEM + 0 / 1 / 2   watchdog / thermal / RAS register file
// ECC memory event info: [31:29] origin (SFRAS_ORG_*) [28] poison [27] UE
//   [26] CE [24:16] syndrome {pe, s} [7:0] stored-bit index of the corrected bit.
// Register map: docs/08_register_map.md (generated, scripts/regmap.py).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfras_defs.svh"
`include "sfras_regs.svh"
`timescale 1ns/1ps
`default_nettype none

module silicaflux_ras #(
  parameter int NEXT           = 8,
  parameter int NMEM           = 2,
  parameter int NBUS           = 2,              // bus fault injectors (targets 8 .. 8+NBUS-1)
  parameter int MEM_AW         = 16,             // memory word-address field width
  parameter int MEM_NW         = 80,             // max stored-word width of the memories (FI mask)
  parameter logic [NMEM*32-1:0] MEM_DEPTHS = {NMEM{32'd1024}},
  parameter int LOG_DEPTH      = 16,
  parameter int CNT_W          = 32,
  parameter int TS_W           = 48,
  parameter int FI_EN          = 1,
  parameter int THERM_W        = 12,
  parameter logic [THERM_W-1:0] THERM_WARN_RST  = THERM_W'(3000),
  parameter logic [THERM_W-1:0] THERM_FATAL_MAX = THERM_W'(3400),
  localparam int NP            = NEXT + 3 * NMEM + 3
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // register page
  input  wire logic                   rb_sel,
  input  wire logic                   rb_we,
  input  wire logic [11:0]            rb_addr,
  input  wire logic [31:0]            rb_wdata,
  output logic [31:0]                 rb_rdata,
  output logic                        rb_err,
  input  wire logic                   rb_priv,
  // external event ports
  input  wire logic [NEXT-1:0]        ext_ev_valid,
  input  wire logic [NEXT*4-1:0]      ext_ev_type,
  input  wire logic [NEXT*32-1:0]     ext_ev_addr,
  input  wire logic [NEXT-1:0]        ext_ev_addr_v,
  input  wire logic [NEXT*32-1:0]     ext_ev_info,
  input  wire logic [NEXT-1:0]        ext_ev_corr,
  // ECC memories: events
  input  wire logic [NMEM-1:0]        mem_ev_valid,
  input  wire logic [NMEM-1:0]        mem_ev_ce,
  input  wire logic [NMEM-1:0]        mem_ev_ue,
  input  wire logic [NMEM-1:0]        mem_ev_poison,
  input  wire logic [NMEM*3-1:0]      mem_ev_org,
  input  wire logic [NMEM*MEM_AW-1:0] mem_ev_addr,
  input  wire logic [NMEM*9-1:0]      mem_ev_syn,     // {pe, s}, zero-extended
  input  wire logic [NMEM*8-1:0]      mem_ev_idx,
  // ECC memories: scrub ports
  output logic [NMEM-1:0]             mem_scr_req_valid,
  input  wire logic [NMEM-1:0]        mem_scr_req_ready,
  output logic [NMEM*2-1:0]           mem_scr_req_op,
  output logic [NMEM*MEM_AW-1:0]      mem_scr_req_addr,
  input  wire logic [NMEM-1:0]        mem_scr_rsp_valid,
  input  wire logic [NMEM*2-1:0]      mem_scr_rsp_op,
  input  wire logic [NMEM*MEM_AW-1:0] mem_scr_rsp_addr,
  input  wire logic [NMEM-1:0]        mem_scr_rsp_ce,
  input  wire logic [NMEM-1:0]        mem_scr_rsp_ue,
  input  wire logic [NMEM-1:0]        mem_scr_rsp_poison,
  input  wire logic [NMEM-1:0]        mem_scr_rsp_wb,
  // ECC memories: initialisation
  output logic [NMEM-1:0]             mem_init_req,
  input  wire logic [NMEM-1:0]        mem_init_busy,
  input  wire logic [NMEM-1:0]        mem_init_done,
  // ECC memories: fault injection
  output logic [NMEM-1:0]             mem_fi_arm,
  output logic [1:0]                  mem_fi_mode,
  output logic [MEM_NW-1:0]           mem_fi_mask,
  output logic                        mem_fi_addr_en,
  output logic [MEM_AW-1:0]           mem_fi_addr,
  input  wire logic [NMEM-1:0]        mem_fi_armed,
  input  wire logic [NMEM-1:0]        mem_fi_fired,
  input  wire logic [NMEM*MEM_AW-1:0] mem_fi_fired_addr,
  // bus fault injectors / parity links
  output logic [NBUS-1:0]             bfi_arm,
  output logic [1:0]                  bfi_mode,
  output logic [63:0]                 bfi_mask,
  output logic [15:0]                 bfi_delay,
  input  wire logic [NBUS-1:0]        bfi_busy,
  // thermal sensor
  input  wire logic                   therm_valid_i,
  input  wire logic [THERM_W-1:0]     therm_code_i,
  // fault-injection hardware permission (TestCore test mode / debug unlock)
  input  wire logic                   fi_allow_i,
  // outputs
  output logic                        irq_ctrl_o,
  output logic                        irq_host_o,
  output logic                        fatal_o,
  output logic                        contain_o,
  output logic                        cc_warn_o,
  output logic                        cc_fatal_o,
  output logic                        therm_shutdown_o,
  output logic                        wdog_reset_req_o,
  output logic                        fi_active_o
);
  localparam int P_MEM  = NEXT;
  localparam int P_WDOG = NEXT + 3 * NMEM;
  localparam int P_THRM = P_WDOG + 1;
  localparam int P_REG  = P_WDOG + 2;
  localparam int RECW   = TS_W + 8 + 4 + 2 + 1 + 1 + 32 + 32;
  localparam int MASKW  = 32 * `SFRAS_FI_MASK_WORDS;

  if (NP > `SFRAS_MAX_SRC) begin : g_err_np
    `SFRAS_CFG_FATAL("silicaflux_ras: NEXT + 3*NMEM + 3 must be <= 32 (source counters)")
  end
  if (NMEM < 1 || NMEM > `SFRAS_MAX_MEM) begin : g_err_nmem
    `SFRAS_CFG_FATAL("silicaflux_ras: NMEM must be 1..8")
  end
  if (NBUS < 1 || NBUS > 8) begin : g_err_nbus
    `SFRAS_CFG_FATAL("silicaflux_ras: NBUS must be 1..8")
  end
  if (MEM_NW > MASKW) begin : g_err_nw
    `SFRAS_CFG_FATAL("silicaflux_ras: MEM_NW must be <= 256")
  end
  if (TS_W <= 32 || TS_W > 64 || CNT_W < 2 || CNT_W > 32) begin : g_err_w
    `SFRAS_CFG_FATAL("silicaflux_ras: TS_W must be 33..64, CNT_W 2..32")
  end

  // ================================================================ registers
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] ctrl_q;                               // [3:0] used
  logic [31:0] th_fatal_wv;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [31:0] irq_en_ctrl_q, irq_en_host_q, log_thr_q, sev_cfg_q;
  logic        wd_en_q, wd_lock_q;
  logic [31:0] wd_load_q;
  logic        th_en_q;
  logic [THERM_W-1:0] th_warn_q, th_fatal_q, th_hyst_q;
  logic [31:0] th_stale_q;
  logic [31:0] fi_ctrl_q, fi_addr_q, fi_delay_q;
  logic [MASKW-1:0] fi_mask_q;
  logic [NMEM-1:0] m_en_q, m_one_q, m_fix_q, m_ver_q, m_stop_q;
  logic [NMEM*32-1:0] m_int_q, m_lo_q, m_hi_q;

  wire wr = rb_sel && rb_we;
  wire rd = rb_sel && !rb_we;
  wire a_mem  = (rb_addr >= 12'h400) && (rb_addr < 12'h600);
  wire [2:0] a_m = rb_addr[8:6];
  wire [5:0] a_mr = rb_addr[5:0];
  wire a_mem_ok = a_mem && (32'(a_m) < NMEM);

  // ---------------- write decode (register offsets from sfras_regs.svh)
  wire w_ctrl     = wr && rb_addr == `SFRAS_R_CTRL;
  wire w_status   = wr && rb_addr == `SFRAS_R_STATUS;
  wire w_tstatus  = wr && rb_addr == `SFRAS_R_TYPE_STATUS;
  wire w_irqc     = wr && rb_addr == `SFRAS_R_IRQ_EN_CTRL;
  wire w_irqh     = wr && rb_addr == `SFRAS_R_IRQ_EN_HOST;
  wire w_thr      = wr && rb_addr == `SFRAS_R_LOG_THR;
  wire w_sev      = wr && rb_addr == `SFRAS_R_SEV_CFG;
  wire w_pop      = wr && rb_addr == `SFRAS_R_LOG_POP;
  wire w_wdctrl   = wr && rb_addr == `SFRAS_R_WDOG_CTRL;
  wire w_wdload   = wr && rb_addr == `SFRAS_R_WDOG_LOAD;
  wire w_wdkick   = wr && rb_addr == `SFRAS_R_WDOG_KICK;
  wire w_wdst     = wr && rb_addr == `SFRAS_R_WDOG_STATUS;
  wire w_thctrl   = wr && rb_addr == `SFRAS_R_THERM_CTRL;
  wire w_thwarn   = wr && rb_addr == `SFRAS_R_THERM_WARN;
  wire w_thfatal  = wr && rb_addr == `SFRAS_R_THERM_FATAL;
  wire w_thhyst   = wr && rb_addr == `SFRAS_R_THERM_HYST;
  wire w_thstale  = wr && rb_addr == `SFRAS_R_THERM_STALE;
  wire a_fi_w     = (rb_addr == `SFRAS_R_FI_KEY) || (rb_addr == `SFRAS_R_FI_CTRL) || (rb_addr == `SFRAS_R_FI_ADDR) ||
                    (rb_addr == `SFRAS_R_FI_DELAY) || (rb_addr >= `SFRAS_R_FI_MASK && rb_addr < `SFRAS_R_FI_MASK + 12'h20);
  wire w_fi_np    = wr && a_fi_w && !rb_priv;                          // refused: not privileged
  wire w_fikey    = wr && rb_priv && rb_addr == `SFRAS_R_FI_KEY;
  wire w_fictrl   = wr && rb_priv && rb_addr == `SFRAS_R_FI_CTRL;
  wire w_fiaddr   = wr && rb_priv && rb_addr == `SFRAS_R_FI_ADDR;
  wire w_fidly    = wr && rb_priv && rb_addr == `SFRAS_R_FI_DELAY;
  wire w_fimask   = wr && rb_priv && rb_addr >= `SFRAS_R_FI_MASK && rb_addr < `SFRAS_R_FI_MASK + 12'h20;
  wire w_mem      = wr && a_mem_ok;
  wire w_mctrl    = w_mem && a_mr == `SFRAS_M_CTRL;

  // writable addresses (anything else written -> RO_OR_UNMAPPED)
  wire wr_ok_addr = w_ctrl || w_status || w_tstatus || w_irqc || w_irqh || w_thr || w_sev || w_pop ||
                    w_wdctrl || w_wdload || w_wdkick || w_wdst || w_thctrl || w_thwarn || w_thfatal ||
                    w_thhyst || w_thstale || (wr && a_fi_w) ||
                    (w_mem && (a_mr == `SFRAS_M_CTRL || a_mr == `SFRAS_M_INTERVAL || a_mr == `SFRAS_M_LO ||
                               a_mr == `SFRAS_M_HI));
  wire wd_locked_w = (w_wdctrl || w_wdload) && wd_lock_q;
  wire wd_badkey   = w_wdkick && rb_wdata != `SFRAS_WDOG_KEY;
  wire th_clamp    = w_thfatal && (rb_wdata[THERM_W-1:0] > THERM_FATAL_MAX || rb_wdata[31:THERM_W] != '0);

  // ---------------- fault-injection access control
  logic        fi_unlocked, fi_arm_ok, fi_refuse;
  logic [3:0]  fi_reason;
  logic [7:0]  fi_arms, fi_refused;
  wire  [3:0]  fi_tgt   = rb_wdata[`SFRAS_FI_CTRL_TARGET_MSB:`SFRAS_FI_CTRL_TARGET_LSB];
  wire         fi_armrq = w_fictrl && rb_wdata[`SFRAS_FI_CTRL_ARM_LSB];
  wire         tgt_mem  = (fi_tgt < 4'd8);
  wire         tgt_valid = tgt_mem ? (32'(fi_tgt) < NMEM) : (32'(fi_tgt) - 8 < NBUS);
  logic        tgt_busy;
  always_comb begin
    tgt_busy = 1'b0;
    for (int m = 0; m < NMEM; m++) if (tgt_mem && 32'(fi_tgt) == m) tgt_busy = mem_fi_armed[m];
    for (int b = 0; b < NBUS; b++) if (!tgt_mem && 32'(fi_tgt) == b + 8) tgt_busy = bfi_busy[b];
  end

  sfras_fi_ctrl #(.FI_EN(FI_EN)) u_fi (
    .clk, .rst_n, .allow_i(fi_allow_i), .lock_i(ctrl_q[`SFRAS_CTRL_FI_LOCK_LSB]),
    .key_wr(w_fikey), .key_val(rb_wdata), .relock(w_fictrl && rb_wdata[`SFRAS_FI_CTRL_RELOCK_LSB]),
    .arm_req(fi_armrq), .tgt_valid, .tgt_busy,
    .unlocked(fi_unlocked), .arm_ok(fi_arm_ok), .refuse(fi_refuse), .refuse_reason(fi_reason),
    .arm_count(fi_arms), .refuse_count(fi_refused)
  );

  // arm routing: the request's own fields (mode / target / addr-en come with the ARM write)
  always_comb begin
    mem_fi_arm = '0; bfi_arm = '0;
    for (int m = 0; m < NMEM; m++) mem_fi_arm[m] = fi_arm_ok && tgt_mem && 32'(fi_tgt) == m;
    for (int b = 0; b < NBUS; b++) bfi_arm[b]    = fi_arm_ok && !tgt_mem && 32'(fi_tgt) == b + 8;
  end
  assign mem_fi_mode    = rb_wdata[`SFRAS_FI_CTRL_MODE_MSB:`SFRAS_FI_CTRL_MODE_LSB];
  assign mem_fi_addr_en = rb_wdata[`SFRAS_FI_CTRL_ADDR_EN_LSB];
  assign mem_fi_addr    = fi_addr_q[MEM_AW-1:0];
  assign mem_fi_mask    = fi_mask_q[MEM_NW-1:0];
  assign bfi_mode       = rb_wdata[`SFRAS_FI_CTRL_BUS_MODE_MSB:`SFRAS_FI_CTRL_BUS_MODE_LSB];
  assign bfi_mask       = fi_mask_q[63:0];
  assign bfi_delay      = fi_delay_q[15:0];
  assign fi_active_o    = fi_unlocked || (|mem_fi_armed) || (|bfi_busy);

  // ---------------- register-file event (ILLEGAL_OP / FI audit), registered
  logic        reg_ev_v;
  logic [3:0]  reg_ev_t;
  logic [31:0] reg_ev_addr, reg_ev_info;
  logic        ill;
  logic [3:0]  ill_reason;
  always_comb begin
    ill = 1'b0; ill_reason = 4'd0;
    if (wr && !wr_ok_addr)      begin ill = 1'b1; ill_reason = `SFRAS_ILL_RO_OR_UNMAPPED; end
    else if (w_fi_np)           begin ill = 1'b1; ill_reason = `SFRAS_ILL_NOT_PRIV; end
    else if (wd_locked_w)       begin ill = 1'b1; ill_reason = `SFRAS_ILL_LOCKED; end
    else if (wd_badkey)         begin ill = 1'b1; ill_reason = `SFRAS_ILL_BAD_KEY; end
    else if (th_clamp)          begin ill = 1'b1; ill_reason = `SFRAS_ILL_CLAMPED; end
    else if (fi_refuse)         begin ill = 1'b1; ill_reason = fi_reason; end
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      reg_ev_v <= 1'b0; reg_ev_t <= '0; reg_ev_addr <= '0; reg_ev_info <= '0;
    end else begin
      reg_ev_v <= ill || fi_arm_ok;
      reg_ev_t <= ill ? `SFRAS_EV_ILLEGAL_OP : `SFRAS_EV_FI;
      reg_ev_addr <= ill ? {20'd0, rb_addr} : fi_addr_q;
      reg_ev_info <= ill ? {16'd0, ill_reason, rb_addr} : {1'b0, 13'd0, rb_wdata[17:0]};
    end
  end

  // ---------------- register storage
  assign th_fatal_wv = th_clamp ? 32'(THERM_FATAL_MAX) : rb_wdata;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ctrl_q <= `SFRAS_RST_CTRL; irq_en_ctrl_q <= `SFRAS_RST_IRQ_EN_CTRL; irq_en_host_q <= `SFRAS_RST_IRQ_EN_HOST;
      log_thr_q <= `SFRAS_RST_LOG_THR; sev_cfg_q <= `SFRAS_RST_SEV_CFG;
      wd_en_q <= 1'b0; wd_lock_q <= 1'b0; wd_load_q <= `SFRAS_RST_WDOG_LOAD;
      th_en_q <= 1'b0; th_warn_q <= THERM_WARN_RST; th_fatal_q <= THERM_FATAL_MAX;
      th_hyst_q <= THERM_W'(`SFRAS_RST_THERM_HYST); th_stale_q <= `SFRAS_RST_THERM_STALE;
      fi_ctrl_q <= '0; fi_addr_q <= '0; fi_delay_q <= '0; fi_mask_q <= '0;
      m_en_q <= '0; m_one_q <= '0; m_fix_q <= '1; m_ver_q <= '1; m_stop_q <= '0;
      for (int m = 0; m < NMEM; m++) begin
        m_int_q[m*32 +: 32] <= `SFRAS_MRST_INTERVAL;
        m_lo_q[m*32 +: 32]  <= '0;
        m_hi_q[m*32 +: 32]  <= MEM_DEPTHS[m*32 +: 32] - 1;
      end
    end else begin
      if (w_ctrl) begin
        ctrl_q[`SFRAS_CTRL_LOG_EN_LSB]        <= rb_wdata[`SFRAS_CTRL_LOG_EN_LSB];
        ctrl_q[`SFRAS_CTRL_FATAL_CONTAIN_LSB] <= rb_wdata[`SFRAS_CTRL_FATAL_CONTAIN_LSB];
        if (rb_wdata[`SFRAS_CTRL_FATAL_LOCK_LSB]) ctrl_q[`SFRAS_CTRL_FATAL_LOCK_LSB] <= 1'b1;   // set-only
        if (rb_wdata[`SFRAS_CTRL_FI_LOCK_LSB])    ctrl_q[`SFRAS_CTRL_FI_LOCK_LSB]    <= 1'b1;   // set-only
      end
      if (w_irqc) irq_en_ctrl_q <= {27'd0, rb_wdata[4:0]};
      if (w_irqh) irq_en_host_q <= {27'd0, rb_wdata[4:0]};
      if (w_thr)  log_thr_q <= {24'd0, rb_wdata[7:0]};
      if (w_sev)  sev_cfg_q <= rb_wdata;
      if (w_wdctrl && !wd_lock_q) begin
        wd_en_q <= rb_wdata[`SFRAS_WDOG_CTRL_EN_LSB];
        if (rb_wdata[`SFRAS_WDOG_CTRL_LOCK_LSB]) wd_lock_q <= 1'b1;
      end
      if (w_wdload && !wd_lock_q) wd_load_q <= rb_wdata;
      if (w_thctrl)  th_en_q    <= rb_wdata[0];
      if (w_thwarn)  th_warn_q  <= rb_wdata[THERM_W-1:0];
      if (w_thfatal) th_fatal_q <= th_fatal_wv[THERM_W-1:0];
      if (w_thhyst)  th_hyst_q  <= rb_wdata[THERM_W-1:0];
      if (w_thstale) th_stale_q <= rb_wdata;
      if (w_fictrl)  fi_ctrl_q  <= {14'd0, rb_wdata[17:16], 4'd0, rb_wdata[11:8], 1'b0, rb_wdata[6:4], 4'd0};
      if (w_fiaddr)  fi_addr_q  <= rb_wdata;
      if (w_fidly)   fi_delay_q <= {16'd0, rb_wdata[15:0]};
      if (w_fimask)  fi_mask_q[32'(rb_addr[4:2])*32 +: 32] <= rb_wdata;
      for (int m = 0; m < NMEM; m++) begin
        if (w_mem && 32'(a_m) == m) begin
          if (a_mr == `SFRAS_M_CTRL) begin
            m_en_q[m]   <= rb_wdata[`SFRAS_M_CTRL_SCRUB_EN_LSB];
            m_one_q[m]  <= rb_wdata[`SFRAS_M_CTRL_ONE_PASS_LSB];
            m_fix_q[m]  <= rb_wdata[`SFRAS_M_CTRL_FIX_EN_LSB];
            m_ver_q[m]  <= rb_wdata[`SFRAS_M_CTRL_VERIFY_EN_LSB];
            m_stop_q[m] <= rb_wdata[`SFRAS_M_CTRL_STOP_ON_UE_LSB];
          end
          if (a_mr == `SFRAS_M_INTERVAL) m_int_q[m*32 +: 32] <= rb_wdata;
          if (a_mr == `SFRAS_M_LO)       m_lo_q[m*32 +: 32]  <= rb_wdata;
          if (a_mr == `SFRAS_M_HI)       m_hi_q[m*32 +: 32]  <= rb_wdata;
        end
      end
    end
  end

  // ================================================================ watchdog
  logic [31:0] wd_count, wd_info;
  logic        wd_s1, wd_s2, wd_ev;
  sfras_watchdog u_wdog (
    .clk, .rst_n, .en(wd_en_q), .load(wd_load_q), .kick(w_wdkick && !wd_badkey),
    .st_w1c(w_wdst ? rb_wdata[1:0] : 2'b00), .count(wd_count), .stage1(wd_s1), .stage2(wd_s2),
    .reset_req(wdog_reset_req_o), .ev_valid(wd_ev), .ev_info(wd_info)
  );

  // ================================================================ thermal
  logic [THERM_W-1:0] th_last;
  logic        th_seen, th_warn, th_fatal, th_stale, th_ev;
  logic [3:0]  th_ev_t;
  logic [31:0] th_ev_info;
  sfras_thermal_mon #(.TW(THERM_W)) u_therm (
    .clk, .rst_n, .en(th_en_q), .warn_thr(th_warn_q), .fatal_thr(th_fatal_q), .hyst(th_hyst_q),
    .stale_lim(th_stale_q), .s_valid(therm_valid_i), .s_code(therm_code_i),
    .last_code(th_last), .seen(th_seen), .warn(th_warn), .fatal(th_fatal), .stale(th_stale),
    .shutdown(therm_shutdown_o), .ev_valid(th_ev), .ev_type(th_ev_t), .ev_info(th_ev_info)
  );

  // ================================================================ scrub engines
  logic [NMEM-1:0] s_active, s_stopped, s_done, s_ue_seen, s_ovf, s_rec_v, s_rec_ue;
  logic [NMEM*MEM_AW-1:0] s_cur, s_ue_addr, s_rec_addr;
  logic [NMEM*CNT_W-1:0]  c_pass, c_ce, c_fix, c_ue, c_pois, c_hard, c_rd;
  wire  m_start = w_mctrl && rb_wdata[`SFRAS_M_CTRL_SCRUB_START_LSB];
  wire  m_clr   = w_mctrl && rb_wdata[`SFRAS_M_CTRL_CLR_COUNTS_LSB];
  wire  m_init  = w_mctrl && rb_wdata[`SFRAS_M_CTRL_INIT_LSB];

  for (genvar m = 0; m < NMEM; m++) begin : g_mem
    sfras_scrub #(.AW(MEM_AW), .CNT_W(CNT_W), .IVW(24)) u_scrub (
      .clk, .rst_n,
      .en(m_en_q[m]), .start(m_start && 32'(a_m) == m), .one_pass(m_one_q[m]), .fix_en(m_fix_q[m]),
      .verify_en(m_ver_q[m]), .stop_on_ue(m_stop_q[m]), .interval(m_int_q[m*32 +: 24]),
      .addr_lo(m_lo_q[m*32 +: MEM_AW]), .addr_hi(m_hi_q[m*32 +: MEM_AW]),
      .clr_counts(m_clr && 32'(a_m) == m),
      .scr_req_valid(mem_scr_req_valid[m]), .scr_req_ready(mem_scr_req_ready[m]),
      .scr_req_op(mem_scr_req_op[m*2 +: 2]), .scr_req_addr(mem_scr_req_addr[m*MEM_AW +: MEM_AW]),
      .scr_rsp_valid(mem_scr_rsp_valid[m]), .scr_rsp_op(mem_scr_rsp_op[m*2 +: 2]),
      .scr_rsp_addr(mem_scr_rsp_addr[m*MEM_AW +: MEM_AW]), .scr_rsp_ce(mem_scr_rsp_ce[m]),
      .scr_rsp_ue(mem_scr_rsp_ue[m]), .scr_rsp_poison(mem_scr_rsp_poison[m]), .scr_rsp_wb(mem_scr_rsp_wb[m]),
      .active(s_active[m]), .stopped_ue(s_stopped[m]), .done(s_done[m]),
      .cur_addr(s_cur[m*MEM_AW +: MEM_AW]), .ue_addr(s_ue_addr[m*MEM_AW +: MEM_AW]), .ue_seen(s_ue_seen[m]),
      .pass_count(c_pass[m*CNT_W +: CNT_W]), .ce_count(c_ce[m*CNT_W +: CNT_W]), .fix_count(c_fix[m*CNT_W +: CNT_W]),
      .ue_count(c_ue[m*CNT_W +: CNT_W]), .poison_count(c_pois[m*CNT_W +: CNT_W]),
      .hard_count(c_hard[m*CNT_W +: CNT_W]), .read_count(c_rd[m*CNT_W +: CNT_W]), .cnt_ovf(s_ovf[m]),
      .ev_rec_valid(s_rec_v[m]), .ev_rec_addr(s_rec_addr[m*MEM_AW +: MEM_AW]), .ev_rec_ue(s_rec_ue[m])
    );
    assign mem_init_req[m] = m_init && 32'(a_m) == m;
  end

  // ================================================================ event ports
  logic [NP-1:0]    e_valid, e_addr_v, e_corr;
  logic [NP*4-1:0]  e_type;
  logic [NP*32-1:0] e_addr, e_info;
  always_comb begin
    e_valid = '0; e_addr_v = '0; e_corr = '0; e_type = '0; e_addr = '0; e_info = '0;
    // external
    e_valid[NEXT-1:0]       = ext_ev_valid;
    e_addr_v[NEXT-1:0]      = ext_ev_addr_v;
    e_corr[NEXT-1:0]        = ext_ev_corr;
    e_type[NEXT*4-1:0]      = ext_ev_type;
    e_addr[NEXT*32-1:0]     = ext_ev_addr;
    e_info[NEXT*32-1:0]     = ext_ev_info;
    // memories
    for (int m = 0; m < NMEM; m++) begin
      // errors: UE > POISON > CE (a corrected bit inside a poisoned word is reported as POISON, corr = 1)
      e_valid[P_MEM + 3*m]  = mem_ev_valid[m];
      e_type[(P_MEM + 3*m)*4 +: 4] = mem_ev_ue[m] ? `SFRAS_EV_MEM_UE : mem_ev_poison[m] ? `SFRAS_EV_POISON : `SFRAS_EV_MEM_CE;
      e_corr[P_MEM + 3*m]   = mem_ev_ce[m];
      e_addr_v[P_MEM + 3*m] = 1'b1;
      e_addr[(P_MEM + 3*m)*32 +: 32] = 32'(mem_ev_addr[m*MEM_AW +: MEM_AW]);
      e_info[(P_MEM + 3*m)*32 +: 32] = {mem_ev_org[m*3 +: 3], mem_ev_poison[m], mem_ev_ue[m], mem_ev_ce[m], 1'b0,
                                        mem_ev_syn[m*9 +: 9], 8'd0, mem_ev_idx[m*8 +: 8]};
      // scrub recovery failure
      e_valid[P_MEM + 3*m + 1]  = s_rec_v[m];
      e_type[(P_MEM + 3*m + 1)*4 +: 4] = `SFRAS_EV_RECOVERY;
      e_addr_v[P_MEM + 3*m + 1] = 1'b1;
      e_addr[(P_MEM + 3*m + 1)*32 +: 32] = 32'(s_rec_addr[m*MEM_AW +: MEM_AW]);
      e_info[(P_MEM + 3*m + 1)*32 +: 32] = {31'd0, s_rec_ue[m]};
      // injection fired
      e_valid[P_MEM + 3*m + 2]  = mem_fi_fired[m];
      e_type[(P_MEM + 3*m + 2)*4 +: 4] = `SFRAS_EV_FI;
      e_addr_v[P_MEM + 3*m + 2] = 1'b1;
      e_addr[(P_MEM + 3*m + 2)*32 +: 32] = 32'(mem_fi_fired_addr[m*MEM_AW +: MEM_AW]);
      e_info[(P_MEM + 3*m + 2)*32 +: 32] = 32'h8000_0000;                 // [31] = fired (0 = armed audit)
    end
    // watchdog / thermal / register file
    e_valid[P_WDOG] = wd_ev;  e_type[P_WDOG*4 +: 4] = `SFRAS_EV_WDOG;  e_info[P_WDOG*32 +: 32] = wd_info;
    e_valid[P_THRM] = th_ev;  e_type[P_THRM*4 +: 4] = th_ev_t;         e_info[P_THRM*32 +: 32] = th_ev_info;
    e_valid[P_REG]  = reg_ev_v; e_type[P_REG*4 +: 4] = reg_ev_t;
    e_addr_v[P_REG] = 1'b1;   e_addr[P_REG*32 +: 32] = reg_ev_addr;     e_info[P_REG*32 +: 32] = reg_ev_info;
  end

  // ================================================================ event controller
  logic [TS_W-1:0]      ts;
  logic [3:0]           sev_seen;
  logic                 log_ovf, cnt_ovf, log_v, first_v;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [3:0]           ev_sev_mask;                 // per-cycle summary, observed by tests
  logic                 ev_any;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [15:0]          type_seen, type_ovf, log_count, log_lost;
  logic [16*CNT_W-1:0]  type_cnt;
  logic [NP*CNT_W-1:0]  src_cnt;
  logic [NP-1:0]        src_ovf;
  logic [RECW-1:0]      log_head, first_rec;

  sfras_event_ctrl #(.NP(NP), .LOG_DEPTH(LOG_DEPTH), .CNT_W(CNT_W), .TS_W(TS_W)) u_ev (
    .clk, .rst_n,
    .ev_valid(e_valid), .ev_type(e_type), .ev_addr(e_addr), .ev_addr_v(e_addr_v), .ev_info(e_info), .ev_corr(e_corr),
    .sev_cfg(sev_cfg_q), .log_en(ctrl_q[`SFRAS_CTRL_LOG_EN_LSB]),
    .clr_counts(w_ctrl && rb_wdata[`SFRAS_CTRL_CLR_COUNTS_LSB]),
    .clr_log(w_ctrl && rb_wdata[`SFRAS_CTRL_CLR_LOG_LSB]),
    .clr_first(w_ctrl && rb_wdata[`SFRAS_CTRL_CLR_FIRST_LSB]),
    .pop(w_pop),
    .sev_w1c(w_status ? rb_wdata[3:0] : 4'd0),
    .ovf_w1c(w_status && rb_wdata[`SFRAS_STATUS_LOG_OVF_LSB]),
    .cnt_ovf_w1c(w_status && rb_wdata[`SFRAS_STATUS_CNT_OVF_LSB]),
    .type_w1c(w_tstatus ? rb_wdata[15:0] : 16'd0),
    .fatal_lock(ctrl_q[`SFRAS_CTRL_FATAL_LOCK_LSB]),
    .ts, .sev_seen, .log_ovf, .cnt_ovf, .type_seen, .type_cnt, .type_ovf, .src_cnt, .src_ovf,
    .log_count, .log_lost, .log_v, .log_head, .first_v, .first_rec, .ev_any, .ev_sev_mask
  );

  // ================================================================ interrupts / fatal
  wire log_irq = (log_thr_q[7:0] != 8'd0) && (log_count >= {8'd0, log_thr_q[7:0]});
  assign irq_ctrl_o = |(sev_seen & irq_en_ctrl_q[3:0]) || (irq_en_ctrl_q[4] && log_irq);
  assign irq_host_o = |(sev_seen & irq_en_host_q[3:0]) || (irq_en_host_q[4] && log_irq);
  assign fatal_o    = sev_seen[`SFRAS_SEV_FATAL];
  assign contain_o  = fatal_o && ctrl_q[`SFRAS_CTRL_FATAL_CONTAIN_LSB];
  assign cc_warn_o  = sev_seen[`SFRAS_SEV_WARN] || sev_seen[`SFRAS_SEV_ERROR];
  assign cc_fatal_o = fatal_o;

  // ================================================================ read mux
  // r[79:64] of a record {ts, src[8], type[4], sev[2], corr, addr_v, addr[32], info[32]}
  function automatic logic [31:0] rec_src(input logic v, input logic [15:0] r);
    rec_src = {v, 15'd0, r[0], r[1], r[3:2], r[7:4], r[15:8]};
  endfunction

  logic [31:0] rdata;
  logic        rerr;
  always_comb begin
    rdata = 32'd0;
    rerr  = 1'b0;
    if (a_mem) begin
      if (!a_mem_ok) rerr = 1'b1;
      else begin
        for (int m = 0; m < NMEM; m++) begin
          if (32'(a_m) == m) begin
            case (a_mr)
              `SFRAS_M_CTRL:     rdata = {27'd0, m_stop_q[m], m_ver_q[m], m_fix_q[m], m_one_q[m], m_en_q[m]};
              `SFRAS_M_INTERVAL: rdata = m_int_q[m*32 +: 32];
              `SFRAS_M_LO:       rdata = m_lo_q[m*32 +: 32];
              `SFRAS_M_HI:       rdata = m_hi_q[m*32 +: 32];
              `SFRAS_M_STATUS:   rdata = {24'd0, mem_fi_armed[m], s_ue_seen[m], s_ovf[m], mem_init_done[m],
                                          mem_init_busy[m], s_done[m], s_stopped[m], s_active[m]};
              `SFRAS_M_CUR:      rdata = 32'(s_cur[m*MEM_AW +: MEM_AW]);
              `SFRAS_M_UE_ADDR:  rdata = 32'(s_ue_addr[m*MEM_AW +: MEM_AW]);
              `SFRAS_M_PASS:     rdata = 32'(c_pass[m*CNT_W +: CNT_W]);
              `SFRAS_M_CE:       rdata = 32'(c_ce[m*CNT_W +: CNT_W]);
              `SFRAS_M_FIX:      rdata = 32'(c_fix[m*CNT_W +: CNT_W]);
              `SFRAS_M_UE:       rdata = 32'(c_ue[m*CNT_W +: CNT_W]);
              `SFRAS_M_POISON:   rdata = 32'(c_pois[m*CNT_W +: CNT_W]);
              `SFRAS_M_HARD:     rdata = 32'(c_hard[m*CNT_W +: CNT_W]);
              `SFRAS_M_READS:    rdata = 32'(c_rd[m*CNT_W +: CNT_W]);
              default:           rerr = 1'b1;
            endcase
          end
        end
      end
    end else if (rb_addr >= `SFRAS_R_TYPE_CNT && rb_addr < `SFRAS_R_TYPE_CNT + 12'h40) begin
      rdata = 32'(type_cnt[32'(rb_addr[5:2])*CNT_W +: CNT_W]);
    end else if (rb_addr >= `SFRAS_R_SRC_CNT && rb_addr < `SFRAS_R_SRC_CNT + 12'h80) begin
      for (int s = 0; s < NP; s++) if (32'(rb_addr[6:2]) == s) rdata = 32'(src_cnt[s*CNT_W +: CNT_W]);
    end else if (rb_addr >= `SFRAS_R_FI_MASK && rb_addr < `SFRAS_R_FI_MASK + 12'h20) begin
      rdata = fi_mask_q[32'(rb_addr[4:2])*32 +: 32];
    end else begin
      case (rb_addr)
        `SFRAS_R_ID:          rdata = `SFRAS_ID_VALUE;
        `SFRAS_R_VERSION:     rdata = `SFRAS_VERSION_VALUE;
        `SFRAS_R_CFG:         rdata = {7'(NP), 1'(FI_EN != 0), 8'(LOG_DEPTH), 8'(NMEM), 8'(NEXT)};
        `SFRAS_R_CFG2:        rdata = {8'(MEM_NW / 8), 8'(THERM_W), 8'(CNT_W), 8'(TS_W)};
        `SFRAS_R_CTRL:        rdata = {28'd0, ctrl_q[3:0]};
        `SFRAS_R_STATUS:      rdata = {9'd0, wd_s2, wd_s1, therm_shutdown_o, fi_active_o && ((|mem_fi_armed) || (|bfi_busy)),
                                       fi_unlocked, contain_o, fatal_o, 6'd0, cnt_ovf, log_ovf, 4'd0, sev_seen};
        `SFRAS_R_TYPE_STATUS: rdata = {16'd0, type_seen};
        `SFRAS_R_IRQ_EN_CTRL: rdata = irq_en_ctrl_q;
        `SFRAS_R_IRQ_EN_HOST: rdata = irq_en_host_q;
        `SFRAS_R_LOG_THR:     rdata = log_thr_q;
        `SFRAS_R_SEV_CFG:     rdata = sev_cfg_q;
        `SFRAS_R_IRQ_STATUS:  rdata = {30'd0, irq_host_o, irq_ctrl_o};
        `SFRAS_R_TS_LO:       rdata = ts[31:0];
        `SFRAS_R_TS_HI:       rdata = 32'(ts[TS_W-1:32]);
        `SFRAS_R_LOG_STAT:    rdata = {log_lost, log_count};
        `SFRAS_R_LOG_POP:     rerr  = rd;
        `SFRAS_R_LOG_SRC:     rdata = rec_src(log_v, log_head[79:64]);
        `SFRAS_R_LOG_ADDR:    rdata = log_head[63:32];
        `SFRAS_R_LOG_INFO:    rdata = log_head[31:0];
        `SFRAS_R_LOG_TS_LO:   rdata = log_head[RECW-TS_W +: 32];
        `SFRAS_R_LOG_TS_HI:   rdata = 32'(log_head[RECW-1 : RECW-TS_W+32]);
        `SFRAS_R_FIRST_SRC:   rdata = rec_src(first_v, first_rec[79:64]);
        `SFRAS_R_FIRST_ADDR:  rdata = first_rec[63:32];
        `SFRAS_R_FIRST_INFO:  rdata = first_rec[31:0];
        `SFRAS_R_FIRST_TS_LO: rdata = first_rec[RECW-TS_W +: 32];
        `SFRAS_R_FIRST_TS_HI: rdata = 32'(first_rec[RECW-1 : RECW-TS_W+32]);
        `SFRAS_R_TYPE_OVF:    rdata = {16'd0, type_ovf};
        `SFRAS_R_SRC_OVF:     rdata = 32'(src_ovf);
        `SFRAS_R_WDOG_CTRL:   rdata = {30'd0, wd_lock_q, wd_en_q};
        `SFRAS_R_WDOG_LOAD:   rdata = wd_load_q;
        `SFRAS_R_WDOG_KICK:   rerr  = rd;
        `SFRAS_R_WDOG_COUNT:  rdata = wd_count;
        `SFRAS_R_WDOG_STATUS: rdata = {30'd0, wd_s2, wd_s1};
        `SFRAS_R_THERM_CTRL:  rdata = {31'd0, th_en_q};
        `SFRAS_R_THERM_WARN:  rdata = 32'(th_warn_q);
        `SFRAS_R_THERM_FATAL: rdata = 32'(th_fatal_q);
        `SFRAS_R_THERM_HYST:  rdata = 32'(th_hyst_q);
        `SFRAS_R_THERM_STALE: rdata = th_stale_q;
        `SFRAS_R_THERM_STATUS: rdata = {12'd0, th_seen, th_stale, th_fatal, th_warn, 16'(th_last)};
        `SFRAS_R_FI_KEY:      rerr  = rd;
        `SFRAS_R_FI_CTRL:     rdata = fi_ctrl_q;
        `SFRAS_R_FI_ADDR:     rdata = fi_addr_q;
        `SFRAS_R_FI_STATUS:   rdata = {8'd0, fi_refused, fi_arms, 4'd0, tgt_busy, ctrl_q[`SFRAS_CTRL_FI_LOCK_LSB],
                                       fi_allow_i, fi_unlocked};
        `SFRAS_R_FI_DELAY:    rdata = fi_delay_q;
        default:              rerr  = 1'b1;
      endcase
    end
  end
  assign rb_rdata = rdata;
  assign rb_err   = rb_sel && ((rd && rerr) || ill);

`ifdef SFRAS_ASSERT
  always_ff @(posedge clk) begin
    if (rst_n) begin
      assert (!(|mem_fi_arm && |bfi_arm)) else $error("%m: two injection targets armed at once");
      if (FI_EN == 0) assert (mem_fi_arm == '0 && bfi_arm == '0) else $error("%m: injection with FI_EN = 0");
      assert (!(fi_arm_ok && (!fi_allow_i || ctrl_q[`SFRAS_CTRL_FI_LOCK_LSB] || !rb_priv)))
        else $error("%m: injection armed without permission");
    end
  end
`endif

endmodule

`default_nettype wire
