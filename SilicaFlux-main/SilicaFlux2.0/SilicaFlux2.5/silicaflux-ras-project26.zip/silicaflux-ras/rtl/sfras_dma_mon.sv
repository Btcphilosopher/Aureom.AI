// =============================================================================
// SilicaFlux RAS (Project 26) :: sfras_dma_mon
// Passive monitor on one SFB2 master port of a DMA engine (DataFabric
// silicaflux_dma, TENSORCORE tensor DMA, HPC DMA adapter): every response
// accepted with rsp_error = 1 is a failed DMA transaction -> event DMA_ERR,
// addr = the byte address of that transaction, info = {write, 31'd0}.
// SFB2 allows one outstanding transaction per port, so the address captured at
// request acceptance belongs to the next response.  The DMA itself aborts the
// transfer (DMA_ERR_READ_BUS / DMA_ERR_WRITE_BUS, existing behaviour); this
// monitor makes the failure a RAS event without modifying the DMA RTL.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sfras_dma_mon (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        req_valid,
  input  wire logic        req_ready,
  input  wire logic        req_write,
  input  wire logic [31:0] req_addr,
  input  wire logic        rsp_valid,
  input  wire logic        rsp_ready,
  input  wire logic        rsp_error,
  output logic             ev_valid,
  output logic [31:0]      ev_addr,
  output logic [31:0]      ev_info
);
  logic [31:0] addr_q;
  logic        wr_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      addr_q <= '0; wr_q <= 1'b0; ev_valid <= 1'b0; ev_addr <= '0; ev_info <= '0;
    end else begin
      if (req_valid && req_ready) begin addr_q <= req_addr; wr_q <= req_write; end
      ev_valid <= rsp_valid && rsp_ready && rsp_error;
      if (rsp_valid && rsp_ready && rsp_error) begin
        ev_addr <= addr_q; ev_info <= {wr_q, 31'd0};
      end
    end
  end
endmodule

`default_nettype wire
