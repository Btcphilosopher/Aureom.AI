// =============================================================================
// SilicaFlux RAS (Project 26) :: sfras_sfb_fault_inj
// SFB2 pass-through with one-shot fault injection (verification / bring-up;
// armed only through the RAS fault-injection controller, which enforces the
// unlock / privilege / permission rules).  When not armed it is a wire.
//   mode 0 FLIP_RDATA : XOR `mask` into rdata of the next response (error flag
//                       untouched) -- a corrupted bus response.  Behind an
//                       unprotected link this is SILENT corruption; behind a
//                       parity link or an ECC memory it is detected.
//   mode 1 FORCE_ERR  : next response delivered with rsp_error = 1 (DMA /
//                       transaction failure).
//   mode 2 DELAY      : next response held back `delay` cycles (timeout).
//   mode 3 FLIP_WDATA : XOR `mask` into wdata of the next write request.
// fired pulses once when the injection is applied.
// Classification: SYNTHESIZABLE
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module sfras_sfb_fault_inj #(
  parameter int DW  = 32,
  localparam int SB = DW / 8
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          arm,
  input  wire logic [1:0]    mode,
  input  wire logic [DW-1:0] mask,
  input  wire logic [15:0]   delay,
  output logic               armed,
  output logic               fired,
  // master side
  input  wire logic          m_req_valid,
  output logic               m_req_ready,
  input  wire logic          m_req_write,
  input  wire logic [31:0]   m_req_addr,
  input  wire logic [DW-1:0] m_req_wdata,
  input  wire logic [SB-1:0] m_req_wstrb,
  output logic               m_rsp_valid,
  input  wire logic          m_rsp_ready,
  output logic [DW-1:0]      m_rsp_rdata,
  output logic               m_rsp_error,
  // slave side
  output logic               s_req_valid,
  input  wire logic          s_req_ready,
  output logic               s_req_write,
  output logic [31:0]        s_req_addr,
  output logic [DW-1:0]      s_req_wdata,
  output logic [SB-1:0]      s_req_wstrb,
  input  wire logic          s_rsp_valid,
  output logic               s_rsp_ready,
  input  wire logic [DW-1:0] s_rsp_rdata,
  input  wire logic          s_rsp_error
);
  logic          armed_q, dly_on_q;
  logic [1:0]    mode_q;
  logic [DW-1:0] mask_q;
  logic [15:0]   dly_q;

  wire rsp_inj  = armed_q && (mode_q == 2'd0 || mode_q == 2'd1);
  wire dly_inj  = armed_q && (mode_q == 2'd2);
  wire wr_inj   = armed_q && (mode_q == 2'd3) && m_req_write;
  wire hold     = (dly_inj || dly_on_q) && s_rsp_valid && (dly_q != '0);

  assign s_req_valid = m_req_valid;
  assign m_req_ready = s_req_ready;
  assign s_req_write = m_req_write;
  assign s_req_addr  = m_req_addr;
  assign s_req_wdata = m_req_wdata ^ (wr_inj ? mask_q : '0);
  assign s_req_wstrb = m_req_wstrb;

  assign m_rsp_valid = s_rsp_valid && !hold;
  assign s_rsp_ready = m_rsp_ready && !hold;
  assign m_rsp_rdata = s_rsp_rdata ^ ((rsp_inj && mode_q == 2'd0) ? mask_q : '0);
  assign m_rsp_error = s_rsp_error || (rsp_inj && mode_q == 2'd1);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      armed_q <= 1'b0; mode_q <= '0; mask_q <= '0; dly_q <= '0; dly_on_q <= 1'b0; fired <= 1'b0;
    end else begin
      fired <= 1'b0;
      if (arm && !armed_q && !dly_on_q) begin
        armed_q <= 1'b1; mode_q <= mode; mask_q <= mask; dly_q <= delay;
      end
      if (rsp_inj && s_rsp_valid && m_rsp_ready) begin armed_q <= 1'b0; fired <= 1'b1; end
      if (wr_inj && m_req_valid && s_req_ready)  begin armed_q <= 1'b0; fired <= 1'b1; end
      if (dly_inj && s_rsp_valid) begin
        armed_q <= 1'b0; fired <= 1'b1; dly_on_q <= (dly_q != '0);
        if (dly_q != '0) dly_q <= dly_q - 1'b1;
      end else if (dly_on_q) begin
        if (dly_q != '0) dly_q <= dly_q - 1'b1;
        else             dly_on_q <= 1'b0;
      end
    end
  end
  assign armed = armed_q || dly_on_q;

endmodule

`default_nettype wire
