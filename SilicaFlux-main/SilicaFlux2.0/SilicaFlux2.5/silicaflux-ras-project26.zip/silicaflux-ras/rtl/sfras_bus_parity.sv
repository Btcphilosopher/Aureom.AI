// =============================================================================
// SilicaFlux RAS (Project 26) :: sfras_bus_parity
//   sfras_par_gen   odd parity per byte lane (+ injection XOR on the parity)
//   sfras_par_chk   lane syndrome / error
//   sfras_sfb_par_link
//                   an SFB2 point-to-point link (master side m_*, slave side
//                   s_*) carrying odd byte parity on the request
//                   {write, wstrb, addr, wdata} and on the response
//                   {error, rdata}.  Only meaningful fields are covered: wdata /
//                   wstrb of a read and rdata of a write acknowledgement are
//                   don't-care on SFB2 (the DataFabric DMA leaves read wdata
//                   undefined), so they are masked to 0 before parity -- found
//                   by tb_ras_system with the real DMA.  The generators sit at the sending end, the
//                   checkers at the receiving end; between them is the "wire"
//                   where the injection XOR models a transient upset.
// Odd parity: an all-zero lane (a dead / stuck-at-0 byte of a bus) is detected.
//
// Containment (no corrupted transaction is executed or delivered as good):
//   request parity error  -> the request is NOT forwarded to the slave; the
//                            link accepts it and answers rsp_error = 1 itself;
//                            event BUS_PARITY (addr = received address,
//                            info = {1'b0 = request, lane syndrome}).
//   response parity error -> forwarded with rsp_error forced to 1;
//                            event BUS_PARITY (info[31] = 1 = response).
// Parity detects any odd number of flips per lane; it corrects nothing.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfras_defs.svh"
`timescale 1ns/1ps
`default_nettype none
/* verilator lint_off DECLFILENAME */

module sfras_par_gen #(
  parameter int W  = 32,
  localparam int L = (W + 7) / 8
) (
  input  wire logic [W-1:0] d,
  input  wire logic [L-1:0] flip,
  output logic      [L-1:0] p
);
  always_comb begin
    for (int l = 0; l < L; l++) begin
      p[l] = 1'b1 ^ flip[l];
      for (int b = l * 8; b < l * 8 + 8; b++) if (b < W) p[l] = p[l] ^ d[b];
    end
  end
endmodule

module sfras_par_chk #(
  parameter int W  = 32,
  localparam int L = (W + 7) / 8
) (
  input  wire logic [W-1:0] d,
  input  wire logic [L-1:0] p,
  output logic      [L-1:0] syn,
  output logic              err
);
  logic [L-1:0] exp_p;
  sfras_par_gen #(.W(W)) u_gen (.d, .flip('0), .p(exp_p));
  assign syn = exp_p ^ p;
  assign err = |syn;
endmodule

module sfras_sfb_par_link #(
  parameter int DW  = 32,
  localparam int SB = DW / 8
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  // master side (from the requester)
  input  wire logic          m_req_valid,
  output logic               m_req_ready,
  input  wire logic          m_req_write,
  input  wire logic [31:0]   m_req_addr,
  input  wire logic [DW-1:0] m_req_wdata,
  input  wire logic [SB-1:0] m_req_wstrb,
  output logic               m_rsp_valid,
  input  wire logic          m_rsp_ready,
  output logic [DW-1:0]      m_rsp_rdata,
  output logic               m_rsp_error,
  // slave side (to the target)
  output logic               s_req_valid,
  input  wire logic          s_req_ready,
  output logic               s_req_write,
  output logic [31:0]        s_req_addr,
  output logic [DW-1:0]      s_req_wdata,
  output logic [SB-1:0]      s_req_wstrb,
  input  wire logic          s_rsp_valid,
  output logic               s_rsp_ready,
  input  wire logic [DW-1:0] s_rsp_rdata,
  input  wire logic          s_rsp_error,
  // injection (one-shot, armed by the RAS fault-injection controller)
  input  wire logic          inj_req_arm,
  input  wire logic          inj_rsp_arm,
  output logic               inj_armed,
  output logic               inj_fired,
  // RAS event
  output logic               ev_valid,
  output logic [31:0]        ev_addr,
  output logic [31:0]        ev_info
);
  localparam int QW = 1 + SB + 32 + DW;               // request payload
  localparam int QL = (QW + 7) / 8;
  localparam int PW = 1 + DW;                         // response payload
  localparam int PL = (PW + 7) / 8;

  logic inj_req_q, inj_rsp_q, loc_q;
  logic [31:0] out_addr_q;                            // address of the forwarded transaction
  logic        out_wr_q;                              // it is a write

  // ---------------- request: generate at the master end, check at the slave end
  wire [QW-1:0] q_data = {m_req_write, m_req_write ? m_req_wstrb : '0, m_req_addr, m_req_write ? m_req_wdata : '0};
  logic [QL-1:0] q_par, q_syn;
  logic          q_err;
  sfras_par_gen #(.W(QW)) u_qgen (.d(q_data), .flip({{(QL-1){1'b0}}, inj_req_q}), .p(q_par));
  sfras_par_chk #(.W(QW)) u_qchk (.d(q_data), .p(q_par), .syn(q_syn), .err(q_err));

  // a request with bad parity is consumed locally (never forwarded)
  wire q_bad = m_req_valid && q_err;
  assign s_req_valid = m_req_valid && !q_err && !loc_q;
  assign s_req_write = m_req_write;
  assign s_req_addr  = m_req_addr;
  assign s_req_wdata = m_req_wdata;
  assign s_req_wstrb = m_req_wstrb;
  assign m_req_ready = loc_q ? 1'b0 : (q_err ? 1'b1 : s_req_ready);

  // ---------------- response: generate at the slave end, check at the master end
  wire [PW-1:0] p_data = {s_rsp_error, out_wr_q ? '0 : s_rsp_rdata};
  logic [PL-1:0] p_par, p_syn;
  logic          p_err;
  sfras_par_gen #(.W(PW)) u_pgen (.d(p_data), .flip({{(PL-1){1'b0}}, inj_rsp_q && s_rsp_valid}), .p(p_par));
  sfras_par_chk #(.W(PW)) u_pchk (.d(p_data), .p(p_par), .syn(p_syn), .err(p_err));

  assign inj_armed   = inj_req_q || inj_rsp_q;
  assign m_rsp_valid = loc_q || s_rsp_valid;
  assign m_rsp_rdata = loc_q ? '0 : s_rsp_rdata;
  assign m_rsp_error = loc_q ? 1'b1 : (s_rsp_error || p_err);
  assign s_rsp_ready = !loc_q && m_rsp_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      inj_req_q <= 1'b0; inj_rsp_q <= 1'b0; loc_q <= 1'b0; inj_fired <= 1'b0;
      ev_valid <= 1'b0; ev_addr <= '0; ev_info <= '0; out_addr_q <= '0; out_wr_q <= 1'b0;
    end else begin
      inj_fired <= 1'b0;
      ev_valid  <= 1'b0;
      if (s_req_valid && s_req_ready) begin out_addr_q <= m_req_addr; out_wr_q <= m_req_write; end
      if (inj_req_arm) inj_req_q <= 1'b1;
      if (inj_rsp_arm) inj_rsp_q <= 1'b1;
      if (inj_req_q && m_req_valid && m_req_ready) begin inj_req_q <= 1'b0; inj_fired <= 1'b1; end
      if (inj_rsp_q && s_rsp_valid && s_rsp_ready) begin inj_rsp_q <= 1'b0; inj_fired <= 1'b1; end
      // local error response for a refused request
      if (q_bad && !loc_q) begin
        loc_q <= 1'b1;
        ev_valid <= 1'b1; ev_addr <= m_req_addr; ev_info <= {1'b0, 31'(q_syn)};
      end else if (loc_q && m_rsp_ready) begin
        loc_q <= 1'b0;
      end
      if (!loc_q && s_rsp_valid && m_rsp_ready && p_err) begin
        ev_valid <= 1'b1; ev_addr <= out_addr_q; ev_info <= {1'b1, 31'(p_syn)};
      end
    end
  end

endmodule

/* verilator lint_on DECLFILENAME */
`default_nettype wire
