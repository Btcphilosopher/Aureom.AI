// =============================================================================
// SilicaFlux RAS (Project 26) :: sfras_watchdog
// Two-stage watchdog.  While enabled the counter runs down from `load`; a kick
// (correct key, checked by the register file) reloads it.
//   reaching 0 (stage 1): event WDOG (info[0] = 0, severity ERROR), counter
//                         reloaded -- firmware gets one more period to recover;
//   reaching 0 again (stage 2, no kick in between): event WDOG (info[0] = 1,
//                         severity FATAL) and reset_req held until reset.
// A kick in stage 1 returns to normal (stage-1 status stays sticky until W1C).
// Disabling (only possible while not locked) stops the counter.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfras_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfras_watchdog (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        en,
  input  wire logic [31:0] load,
  input  wire logic        kick,          // pulse (key already verified)
  input  wire logic [1:0]  st_w1c,        // pulse mask: clear sticky stage bits
  output logic [31:0]      count,
  output logic             stage1,        // sticky
  output logic             stage2,        // sticky until reset
  output logic             reset_req,
  output logic             ev_valid,
  output logic [31:0]      ev_info
);
  logic in_s1_q;      // currently in the second period

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      count <= '0; stage1 <= 1'b0; stage2 <= 1'b0; in_s1_q <= 1'b0; ev_valid <= 1'b0; ev_info <= '0;
    end else begin
      ev_valid <= 1'b0;
      if (st_w1c[0]) stage1 <= 1'b0;
      if (!en) begin
        count <= load; in_s1_q <= 1'b0;
      end else if (stage2) begin
        count <= '0;                                       // stopped: reset requested
      end else if (kick) begin
        count <= load; in_s1_q <= 1'b0;
      end else if (count == '0) begin
        ev_valid <= 1'b1;
        if (!in_s1_q) begin
          stage1 <= 1'b1; in_s1_q <= 1'b1; count <= load; ev_info <= 32'd0;
        end else begin
          stage2 <= 1'b1; ev_info <= 32'd1;
        end
      end else begin
        count <= count - 1'b1;
      end
      // stage 2 is cleared only by reset (st_w1c[1] is accepted only to document the attempt)
    end
  end
  assign reset_req = stage2;

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused = st_w1c[1];
  /* verilator lint_on UNUSEDSIGNAL */

endmodule

`default_nettype wire
