// =============================================================================
// SilicaFlux RAS (Project 26) :: sfras_timeout_mon
// Passive transaction-timeout monitor for one SFB2 master port (one transaction
// outstanding per port, SFB2 rule).  Counts cycles from request acceptance to
// response acceptance; if `limit` (> 0) cycles pass, raises one TIMEOUT event
// (addr = request address, info = {write, 31'(limit)}) for that transaction.
// It does not alter the bus: a hung slave must be handled by the fatal /
// containment policy (docs/05_poison_containment.md).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfras_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfras_timeout_mon (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic [31:0] limit,         // 0 = off
  input  wire logic        req_valid,
  input  wire logic        req_ready,
  input  wire logic        req_write,
  input  wire logic [31:0] req_addr,
  input  wire logic        rsp_valid,
  input  wire logic        rsp_ready,
  output logic             ev_valid,
  output logic [31:0]      ev_addr,
  output logic [31:0]      ev_info
);
  logic        out_q, fired_q, wr_q;
  logic [31:0] cnt_q, addr_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      out_q <= 1'b0; fired_q <= 1'b0; wr_q <= 1'b0; cnt_q <= '0; addr_q <= '0; ev_valid <= 1'b0;
    end else begin
      ev_valid <= 1'b0;
      if (rsp_valid && rsp_ready) begin
        out_q <= 1'b0;
      end
      if (req_valid && req_ready) begin
        out_q <= 1'b1; fired_q <= 1'b0; cnt_q <= '0; addr_q <= req_addr; wr_q <= req_write;
      end else if (out_q && !(rsp_valid && rsp_ready)) begin
        if (cnt_q != '1) cnt_q <= cnt_q + 1'b1;
        if (limit != '0 && cnt_q + 1'b1 >= limit && !fired_q) begin
          fired_q <= 1'b1; ev_valid <= 1'b1;
        end
      end
    end
  end
  assign ev_addr = addr_q;
  assign ev_info = {wr_q, limit[30:0]};

endmodule

`default_nettype wire
