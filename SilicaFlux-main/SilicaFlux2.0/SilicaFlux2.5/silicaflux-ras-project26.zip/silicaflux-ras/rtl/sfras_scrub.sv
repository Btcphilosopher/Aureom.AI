// =============================================================================
// SilicaFlux RAS (Project 26) :: sfras_scrub
// Background patrol-scrub engine for one sfras_ecc_sram (its scrub port).
//
//   Address walk  addr_lo .. addr_hi (inclusive, word addresses), wrapping;
//                 one CHECK read every `interval` cycles (interval = 0 -> back
//                 to back, i.e. one CHECK per free array slot).  A pass ends at
//                 addr_hi; pass_count counts completed passes; ONE_PASS stops
//                 after one.
//   Correction    CHECK finds a correctable word -> FIX (locked read + write
//                 back of the corrected word, inside the memory wrapper) ->
//                 VERIFY (fix_en / verify_en).  A VERIFY that still sees an
//                 error means the write-back did not clear it (stuck cell or a
//                 recovery fault): hard_count++ and a RECOVERY event.
//                 A FIX that finds the word uncorrectable (it degraded between
//                 CHECK and FIX) is counted as an UE.  A FIX that finds the word
//                 clean (a functional write replaced it) needs nothing.
//   UE policy     stop_on_ue = 1: the engine stops at the first uncorrectable
//                 word (status STOPPED_UE, ue_addr = that word) until `start`
//                 is pulsed again; 0: it counts, records the first address and
//                 continues.  An UE is never "fixed": the word is left as found
//                 (it keeps decoding as UE, so it cannot be consumed silently).
//   Poisoned words (POISON_MODE BIT / SIG) are counted, not touched.
//   Arbitration with functional traffic is in the wrapper (functional first,
//   scrub after SCRUB_MAX_WAIT cycles of waiting).
//   Counters saturate at all-ones (CNT_W bits) and set the sticky overflow
//   flag `cnt_ovf`.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfras_defs.svh"
`timescale 1ns/1ps
`default_nettype none

module sfras_scrub #(
  parameter int AW    = 10,
  parameter int CNT_W = 32,
  parameter int IVW   = 24          // interval counter width
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // configuration (static while enabled, except start / stop)
  input  wire logic             en,          // engine enabled (0 = stop at the next request boundary)
  input  wire logic             start,       // pulse: (re)start at addr_lo, clears STOPPED_UE / DONE
  input  wire logic             one_pass,
  input  wire logic             fix_en,
  input  wire logic             verify_en,
  input  wire logic             stop_on_ue,
  input  wire logic [IVW-1:0]   interval,
  input  wire logic [AW-1:0]    addr_lo,
  input  wire logic [AW-1:0]    addr_hi,
  input  wire logic             clr_counts,  // pulse
  // memory scrub port
  output logic                  scr_req_valid,
  input  wire logic             scr_req_ready,
  output logic [1:0]            scr_req_op,
  output logic [AW-1:0]         scr_req_addr,
  input  wire logic             scr_rsp_valid,
  input  wire logic [1:0]       scr_rsp_op,
  input  wire logic [AW-1:0]    scr_rsp_addr,
  input  wire logic             scr_rsp_ce,
  input  wire logic             scr_rsp_ue,
  input  wire logic             scr_rsp_poison,
  input  wire logic             scr_rsp_wb,
  // status
  output logic                  active,      // walking (not idle / stopped / done)
  output logic                  stopped_ue,
  output logic                  done,        // ONE_PASS completed
  output logic [AW-1:0]         cur_addr,
  output logic [AW-1:0]         ue_addr,
  output logic                  ue_seen,
  output logic [CNT_W-1:0]      pass_count,
  output logic [CNT_W-1:0]      ce_count,    // CHECK reads that found a correctable word
  output logic [CNT_W-1:0]      fix_count,   // corrected words written back
  output logic [CNT_W-1:0]      ue_count,    // uncorrectable words found (CHECK or FIX)
  output logic [CNT_W-1:0]      poison_count,
  output logic [CNT_W-1:0]      hard_count,  // VERIFY after a write-back still in error
  output logic [CNT_W-1:0]      read_count,  // scrub reads issued (interference accounting)
  output logic                  cnt_ovf,
  // RAS event: recovery failure (VERIFY after FIX still in error)
  output logic                  ev_rec_valid,
  output logic [AW-1:0]         ev_rec_addr,
  output logic                  ev_rec_ue
);
  typedef enum logic [2:0] {S_IDLE, S_WAIT, S_REQ, S_RSP, S_STOP_UE, S_DONE} st_t;
  st_t st_q;
  logic [IVW-1:0] tmr_q;
  logic [AW-1:0]  addr_q;
  logic [1:0]     op_q;

  function automatic logic [CNT_W-1:0] sat_inc(input logic [CNT_W-1:0] c, input logic inc);
    sat_inc = (inc && c != '1) ? c + 1'b1 : c;
  endfunction

  wire rsp = scr_rsp_valid && (st_q == S_RSP);
  wire last = (addr_q == addr_hi);

  // counter increments (one decision per response)
  wire inc_ce   = rsp && scr_rsp_op == `SFRAS_SCR_CHECK && scr_rsp_ce && !scr_rsp_ue;
  wire inc_fix  = rsp && scr_rsp_op == `SFRAS_SCR_FIX && scr_rsp_wb;
  wire inc_ue   = rsp && (scr_rsp_op == `SFRAS_SCR_CHECK || scr_rsp_op == `SFRAS_SCR_FIX) && scr_rsp_ue;
  wire inc_pois = rsp && scr_rsp_op == `SFRAS_SCR_CHECK && scr_rsp_poison;
  wire inc_hard = rsp && scr_rsp_op == `SFRAS_SCR_VERIFY && (scr_rsp_ce || scr_rsp_ue);
  // response decisions
  wire r_chk  = rsp && scr_rsp_op == `SFRAS_SCR_CHECK;
  wire r_fix  = rsp && scr_rsp_op == `SFRAS_SCR_FIX;
  wire go_stop = (r_chk || r_fix) && scr_rsp_ue && stop_on_ue;
  wire go_fix  = r_chk && scr_rsp_ce && !scr_rsp_ue && fix_en;
  wire go_ver  = r_fix && scr_rsp_wb && verify_en;
  wire adv     = rsp && !go_stop && !go_fix && !go_ver;      // this address is finished
  wire inc_pass = adv && last;
  wire issue = scr_req_valid && scr_req_ready;

  wire [AW-1:0] next_addr = last ? addr_lo : addr_q + 1'b1;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= S_IDLE; tmr_q <= '0; addr_q <= '0; op_q <= `SFRAS_SCR_CHECK;
      ue_addr <= '0; ue_seen <= 1'b0;
      pass_count <= '0; ce_count <= '0; fix_count <= '0; ue_count <= '0; poison_count <= '0;
      hard_count <= '0; read_count <= '0; cnt_ovf <= 1'b0;
      ev_rec_valid <= 1'b0; ev_rec_addr <= '0; ev_rec_ue <= 1'b0;
    end else begin
      ev_rec_valid <= 1'b0;
      // ---------------------------------------------------------- counters
      if (clr_counts) begin
        pass_count <= '0; ce_count <= '0; fix_count <= '0; ue_count <= '0; poison_count <= '0;
        hard_count <= '0; read_count <= '0; cnt_ovf <= 1'b0;
      end else begin
        pass_count   <= sat_inc(pass_count,   inc_pass);
        ce_count     <= sat_inc(ce_count,     inc_ce);
        fix_count    <= sat_inc(fix_count,    inc_fix);
        ue_count     <= sat_inc(ue_count,     inc_ue);
        poison_count <= sat_inc(poison_count, inc_pois);
        hard_count   <= sat_inc(hard_count,   inc_hard);
        read_count   <= sat_inc(read_count,   issue);
        if ((inc_pass && pass_count == '1) || (inc_ce && ce_count == '1) || (inc_fix && fix_count == '1) ||
            (inc_ue && ue_count == '1) || (inc_pois && poison_count == '1) || (inc_hard && hard_count == '1) ||
            (issue && read_count == '1))
          cnt_ovf <= 1'b1;
      end
      if (inc_ue && !ue_seen) begin
        ue_seen <= 1'b1; ue_addr <= scr_rsp_addr;
      end
      if (inc_hard) begin
        ev_rec_valid <= 1'b1; ev_rec_addr <= scr_rsp_addr; ev_rec_ue <= scr_rsp_ue;
      end
      if (start) begin
        ue_seen <= 1'b0;
      end
      // ---------------------------------------------------------- walk
      case (st_q)
        S_IDLE: if (en) begin
          if (start || addr_q < addr_lo || addr_q > addr_hi) addr_q <= addr_lo;
          tmr_q <= interval; op_q <= `SFRAS_SCR_CHECK; st_q <= S_WAIT;
        end
        S_WAIT: begin
          if (!en)                st_q <= S_IDLE;
          else if (tmr_q == '0)   st_q <= S_REQ;
          else                    tmr_q <= tmr_q - 1'b1;
        end
        S_REQ: begin
          if (issue)              st_q <= S_RSP;
          else if (!en)           st_q <= S_IDLE;   // a request is withdrawn only before it is accepted
        end
        S_RSP: if (scr_rsp_valid) begin
          tmr_q <= interval;
          if (go_stop) begin
            st_q <= S_STOP_UE;
          end else if (go_fix) begin
            st_q <= en ? S_REQ : S_IDLE; op_q <= `SFRAS_SCR_FIX;      // same address, immediately
          end else if (go_ver) begin
            st_q <= en ? S_REQ : S_IDLE; op_q <= `SFRAS_SCR_VERIFY;
          end else begin
            addr_q <= next_addr; op_q <= `SFRAS_SCR_CHECK;
            st_q   <= (last && one_pass) ? S_DONE : (en ? S_WAIT : S_IDLE);
          end
        end
        S_STOP_UE: if (start) st_q <= S_IDLE;
        S_DONE:    if (start) st_q <= S_IDLE;
        default:   st_q <= S_IDLE;
      endcase
      if (start && (st_q == S_WAIT)) addr_q <= addr_lo;
    end
  end

  assign scr_req_valid = (st_q == S_REQ);
  assign scr_req_op    = op_q;
  assign scr_req_addr  = addr_q;
  assign active        = (st_q == S_WAIT) || (st_q == S_REQ) || (st_q == S_RSP);
  assign stopped_ue    = (st_q == S_STOP_UE);
  assign done          = (st_q == S_DONE);
  assign cur_addr      = addr_q;

`ifdef SFRAS_ASSERT
  always_ff @(posedge clk) begin
    if (rst_n) begin
      if (scr_rsp_valid) assert (st_q == S_RSP && scr_rsp_addr == addr_q && scr_rsp_op == op_q)
        else $error("%m: unexpected scrub response");
    end
  end
`endif

endmodule

`default_nettype wire
