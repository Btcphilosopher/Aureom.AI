/*
 * SilicaFlux RAS (Project 26) -- firmware / host driver implementation.
 * See silicaflux_ras.h.  Freestanding C99: no libc calls.
 */
#include "silicaflux_ras.h"

#define RD(off)       SFRAS_READ32(dev, (off))
#define WR(off, v)    SFRAS_WRITE32(dev, (off), (v))
#define MEMR(m, r)    SFRAS_MEM((m), (r))

void sfras_default_config(sfras_config_t *cfg)
{
    cfg->irq_ctrl_sev_mask    = (1u << SFRAS_SEV_WARN) | (1u << SFRAS_SEV_ERROR) | (1u << SFRAS_SEV_FATAL);
    cfg->irq_host_sev_mask    = (1u << SFRAS_SEV_FATAL);
    cfg->log_threshold        = 0;
    cfg->sev_escalate         = 0;
    cfg->fatal_contain        = true;
    cfg->fatal_lock           = false;
    cfg->lock_fault_injection = true;
}

sfras_status_t sfras_init(sfras_dev_t *dev, uintptr_t base, const sfras_config_t *cfg)
{
    uint32_t c, ctrl, irq_c, irq_h;
    dev->base = base;
    if (RD(SFRAS_ID) != SFRAS_ID_VALUE || (RD(SFRAS_VERSION) >> 16) != (SFRAS_VERSION_VALUE >> 16))
        return SFRAS_E_ID;
    c = RD(SFRAS_CFG);
    dev->next      = (c & SFRAS_CFG_NEXT_MASK) >> SFRAS_CFG_NEXT_SHIFT;
    dev->nmem      = (c & SFRAS_CFG_NMEM_MASK) >> SFRAS_CFG_NMEM_SHIFT;
    dev->nsrc      = (c & SFRAS_CFG_NP_MASK) >> SFRAS_CFG_NP_SHIFT;
    dev->lost_seen = 0;

    irq_c = cfg->irq_ctrl_sev_mask & SFRAS_IRQ_EN_CTRL_SEV_MASK;
    irq_h = cfg->irq_host_sev_mask & SFRAS_IRQ_EN_CTRL_SEV_MASK;
    if (cfg->log_threshold != 0u) {
        WR(SFRAS_LOG_THR, cfg->log_threshold & 0xFFu);
        irq_c |= SFRAS_IRQ_EN_CTRL_LOG_THR_MASK;
    }
    WR(SFRAS_SEV_CFG, cfg->sev_escalate);
    /* start from a clean log / counters / first-error capture */
    ctrl = SFRAS_CTRL_LOG_EN_MASK | SFRAS_CTRL_CLR_COUNTS_MASK | SFRAS_CTRL_CLR_LOG_MASK | SFRAS_CTRL_CLR_FIRST_MASK;
    if (cfg->fatal_contain)        ctrl |= SFRAS_CTRL_FATAL_CONTAIN_MASK;
    if (cfg->fatal_lock)           ctrl |= SFRAS_CTRL_FATAL_LOCK_MASK;
    if (cfg->lock_fault_injection) ctrl |= SFRAS_CTRL_FI_LOCK_MASK;
    WR(SFRAS_CTRL, ctrl);
    WR(SFRAS_STATUS, SFRAS_STATUS_SEEN_INFO_MASK | SFRAS_STATUS_SEEN_WARN_MASK | SFRAS_STATUS_SEEN_ERROR_MASK |
                     SFRAS_STATUS_LOG_OVF_MASK | SFRAS_STATUS_CNT_OVF_MASK);
    WR(SFRAS_TYPE_STATUS, 0xFFFFu);
    WR(SFRAS_IRQ_EN_CTRL, irq_c);
    WR(SFRAS_IRQ_EN_HOST, irq_h);
    return SFRAS_OK;
}

static void read_record(sfras_dev_t *dev, uint32_t src_off, sfras_event_t *ev, uint32_t s)
{
    /* src_off: LOG_SRC or FIRST_SRC; the following registers keep the same order */
    ev->src        = (uint8_t)((s & SFRAS_LOG_SRC_SRC_MASK) >> SFRAS_LOG_SRC_SRC_SHIFT);
    ev->type       = (uint8_t)((s & SFRAS_LOG_SRC_TYPE_MASK) >> SFRAS_LOG_SRC_TYPE_SHIFT);
    ev->sev        = (uint8_t)((s & SFRAS_LOG_SRC_SEV_MASK) >> SFRAS_LOG_SRC_SEV_SHIFT);
    ev->corrected  = (s & SFRAS_LOG_SRC_CORR_MASK) != 0u;
    ev->addr_valid = (s & SFRAS_LOG_SRC_ADDR_V_MASK) != 0u;
    ev->addr       = RD(src_off + 0x4u);
    ev->info       = RD(src_off + 0x8u);
    ev->ts         = ((uint64_t)RD(src_off + 0x10u) << 32) | RD(src_off + 0xCu);
}

bool sfras_log_pop(sfras_dev_t *dev, sfras_event_t *ev)
{
    uint32_t s = RD(SFRAS_LOG_SRC);
    if ((s & SFRAS_LOG_SRC_VALID_MASK) == 0u)
        return false;
    read_record(dev, SFRAS_LOG_SRC, ev, s);
    WR(SFRAS_LOG_POP, 0u);
    return true;
}

bool sfras_first_error(sfras_dev_t *dev, sfras_event_t *ev)
{
    uint32_t s = RD(SFRAS_FIRST_SRC);
    if ((s & SFRAS_LOG_SRC_VALID_MASK) == 0u)
        return false;
    read_record(dev, SFRAS_FIRST_SRC, ev, s);
    return true;
}

void sfras_clear_first(sfras_dev_t *dev)
{
    WR(SFRAS_CTRL, (RD(SFRAS_CTRL) & (SFRAS_CTRL_LOG_EN_MASK | SFRAS_CTRL_FATAL_CONTAIN_MASK)) | SFRAS_CTRL_CLR_FIRST_MASK);
}

uint32_t sfras_log_lost(sfras_dev_t *dev)
{
    return (RD(SFRAS_LOG_STAT) & SFRAS_LOG_STAT_LOST_MASK) >> SFRAS_LOG_STAT_LOST_SHIFT;
}

uint32_t sfras_service(sfras_dev_t *dev, sfras_handler_t handler, void *ctx, uint32_t *lost_out)
{
    sfras_event_t ev;
    uint32_t n = 0, st, lost;
    /* snapshot the sticky bits first: anything arriving later stays pending */
    st = RD(SFRAS_STATUS);
    while (sfras_log_pop(dev, &ev)) {
        if (handler)
            handler(ctx, &ev);
        n++;
    }
    lost = sfras_log_lost(dev);
    if (lost_out)
        *lost_out = lost - dev->lost_seen;
    dev->lost_seen = lost;
    /* clear the serviced non-fatal sticky bits (W1C); never SEEN_FATAL here */
    WR(SFRAS_STATUS, st & (SFRAS_STATUS_SEEN_INFO_MASK | SFRAS_STATUS_SEEN_WARN_MASK | SFRAS_STATUS_SEEN_ERROR_MASK |
                           SFRAS_STATUS_LOG_OVF_MASK));
    return n;
}

uint32_t sfras_status(sfras_dev_t *dev)              { return RD(SFRAS_STATUS); }
bool     sfras_fatal(sfras_dev_t *dev)               { return (RD(SFRAS_STATUS) & SFRAS_STATUS_FATAL_OUT_MASK) != 0u; }
uint32_t sfras_type_count(sfras_dev_t *dev, uint32_t t) { return t < 16u ? RD(SFRAS_TYPE_CNT(t)) : 0u; }
uint32_t sfras_src_count(sfras_dev_t *dev, uint32_t s)  { return s < SFRAS_MAX_SRC ? RD(SFRAS_SRC_CNT(s)) : 0u; }

void sfras_clear_counts(sfras_dev_t *dev)
{
    WR(SFRAS_CTRL, (RD(SFRAS_CTRL) & (SFRAS_CTRL_LOG_EN_MASK | SFRAS_CTRL_FATAL_CONTAIN_MASK)) | SFRAS_CTRL_CLR_COUNTS_MASK);
    WR(SFRAS_STATUS, SFRAS_STATUS_CNT_OVF_MASK);
}

uint64_t sfras_timestamp(sfras_dev_t *dev)
{
    uint32_t hi, lo, hi2;
    do {                                  /* consistent 64-bit read of a running counter */
        hi  = RD(SFRAS_TS_HI);
        lo  = RD(SFRAS_TS_LO);
        hi2 = RD(SFRAS_TS_HI);
    } while (hi != hi2);
    return ((uint64_t)hi << 32) | lo;
}

sfras_mem_info_t sfras_decode_mem_info(uint32_t info)
{
    sfras_mem_info_t r;
    r.origin   = (uint8_t)((info >> 29) & 0x7u);
    r.poison   = ((info >> 28) & 1u) != 0u;
    r.ue       = ((info >> 27) & 1u) != 0u;
    r.ce       = ((info >> 26) & 1u) != 0u;
    r.syndrome = (uint16_t)((info >> 16) & 0x1FFu);
    r.bit      = (uint8_t)(info & 0xFFu);
    return r;
}

const char *sfras_type_name(uint32_t t)
{
    static const char *const names[] = {
        "NONE", "MEM_CE", "MEM_UE", "BUS_PARITY", "DMA_ERR", "WDOG", "THERM_WARN", "THERM_FATAL",
        "ILLEGAL_OP", "POISON", "RECOVERY", "TIMEOUT", "FI"
    };
    return t < sizeof(names) / sizeof(names[0]) ? names[t] : "RESERVED";
}

const char *sfras_sev_name(uint32_t s)
{
    static const char *const names[] = { "INFO", "WARN", "ERROR", "FATAL" };
    return names[s & 3u];
}

sfras_status_t sfras_mem_init(sfras_dev_t *dev, uint32_t m, uint32_t poll_limit)
{
    uint32_t i;
    if (m >= dev->nmem)
        return SFRAS_E_ARG;
    WR(MEMR(m, SFRAS_MEM_CTRL), (RD(MEMR(m, SFRAS_MEM_CTRL)) & 0x1Fu) | SFRAS_MEM_CTRL_INIT_MASK);
    for (i = 0; i < poll_limit; i++) {
        uint32_t s = RD(MEMR(m, SFRAS_MEM_STATUS));
        if ((s & SFRAS_MEM_STATUS_INIT_DONE_MASK) && !(s & SFRAS_MEM_STATUS_INIT_BUSY_MASK))
            return SFRAS_OK;
    }
    return SFRAS_E_TIMEOUT;
}

sfras_status_t sfras_scrub_start(sfras_dev_t *dev, uint32_t m, uint32_t lo, uint32_t hi, uint32_t interval,
                                 uint32_t flags)
{
    if (m >= dev->nmem || lo > hi)
        return SFRAS_E_ARG;
    WR(MEMR(m, SFRAS_MEM_CTRL), 0u);                         /* stop first */
    WR(MEMR(m, SFRAS_MEM_LO), lo);
    WR(MEMR(m, SFRAS_MEM_HI), hi);
    WR(MEMR(m, SFRAS_MEM_INTERVAL), interval);
    WR(MEMR(m, SFRAS_MEM_CTRL), SFRAS_MEM_CTRL_SCRUB_EN_MASK | SFRAS_MEM_CTRL_SCRUB_START_MASK |
                                 SFRAS_MEM_CTRL_CLR_COUNTS_MASK |
                                 (flags & (SFRAS_SCRUB_ONE_PASS | SFRAS_SCRUB_FIX | SFRAS_SCRUB_VERIFY |
                                           SFRAS_SCRUB_STOP_ON_UE)));
    return SFRAS_OK;
}

void sfras_scrub_stop(sfras_dev_t *dev, uint32_t m)
{
    /* disable and acknowledge a STOPPED_UE / DONE state */
    WR(MEMR(m, SFRAS_MEM_CTRL), (RD(MEMR(m, SFRAS_MEM_CTRL)) & ~SFRAS_MEM_CTRL_SCRUB_EN_MASK & 0x1Fu) |
                                 SFRAS_MEM_CTRL_SCRUB_START_MASK);
}

void sfras_scrub_stats(sfras_dev_t *dev, uint32_t m, sfras_scrub_stats_t *st)
{
    st->status   = RD(MEMR(m, SFRAS_MEM_STATUS));
    st->cur      = RD(MEMR(m, SFRAS_MEM_CUR));
    st->ue_addr  = RD(MEMR(m, SFRAS_MEM_UE_ADDR));
    st->passes   = RD(MEMR(m, SFRAS_MEM_PASS));
    st->ce       = RD(MEMR(m, SFRAS_MEM_CE));
    st->fixed    = RD(MEMR(m, SFRAS_MEM_FIX));
    st->ue       = RD(MEMR(m, SFRAS_MEM_UE));
    st->poisoned = RD(MEMR(m, SFRAS_MEM_POISON));
    st->hard     = RD(MEMR(m, SFRAS_MEM_HARD));
    st->reads    = RD(MEMR(m, SFRAS_MEM_READS));
}

sfras_status_t sfras_wdog_start(sfras_dev_t *dev, uint32_t cycles, bool lock)
{
    if (RD(SFRAS_WDOG_CTRL) & SFRAS_WDOG_CTRL_LOCK_MASK)
        return SFRAS_E_REFUSED;
    WR(SFRAS_WDOG_LOAD, cycles);
    WR(SFRAS_WDOG_CTRL, SFRAS_WDOG_CTRL_EN_MASK | (lock ? SFRAS_WDOG_CTRL_LOCK_MASK : 0u));
    return SFRAS_OK;
}

void sfras_wdog_kick(sfras_dev_t *dev) { WR(SFRAS_WDOG_KICK, SFRAS_WDOG_KEY); }

sfras_status_t sfras_therm_config(sfras_dev_t *dev, uint32_t warn, uint32_t fatal, uint32_t hyst,
                                  uint32_t stale_cycles)
{
    WR(SFRAS_THERM_WARN, warn);
    WR(SFRAS_THERM_FATAL, fatal);
    WR(SFRAS_THERM_HYST, hyst);
    WR(SFRAS_THERM_STALE, stale_cycles);
    WR(SFRAS_THERM_CTRL, 1u);
    /* the hardware clamps the fatal threshold to its build-time maximum */
    return RD(SFRAS_THERM_FATAL) == fatal ? SFRAS_OK : SFRAS_E_REFUSED;
}

void sfras_lock_fi(sfras_dev_t *dev)
{
    WR(SFRAS_CTRL, (RD(SFRAS_CTRL) & (SFRAS_CTRL_LOG_EN_MASK | SFRAS_CTRL_FATAL_CONTAIN_MASK)) | SFRAS_CTRL_FI_LOCK_MASK);
}

#ifdef SFRAS_ENABLE_FI
sfras_status_t sfras_fi_unlock(sfras_dev_t *dev)
{
    WR(SFRAS_FI_KEY, SFRAS_FI_KEY1);
    WR(SFRAS_FI_KEY, SFRAS_FI_KEY2);
    return (RD(SFRAS_FI_STATUS) & SFRAS_FI_STATUS_UNLOCKED_MASK) ? SFRAS_OK : SFRAS_E_REFUSED;
}

void sfras_fi_relock(sfras_dev_t *dev) { WR(SFRAS_FI_CTRL, SFRAS_FI_CTRL_RELOCK_MASK); }

static sfras_status_t fi_arm(sfras_dev_t *dev, uint32_t ctrl)
{
    uint32_t before = (RD(SFRAS_FI_STATUS) & SFRAS_FI_STATUS_REFUSED_MASK);
    WR(SFRAS_FI_CTRL, ctrl | SFRAS_FI_CTRL_ARM_MASK);
    return ((RD(SFRAS_FI_STATUS) & SFRAS_FI_STATUS_REFUSED_MASK) == before) ? SFRAS_OK : SFRAS_E_REFUSED;
}

sfras_status_t sfras_fi_inject_mem(sfras_dev_t *dev, uint32_t m, uint32_t mode, bool addr_match, uint32_t addr,
                                   const uint32_t *mask, uint32_t mask_words)
{
    uint32_t i;
    if (m >= dev->nmem || mode > 3u || mask_words > SFRAS_FI_MASK_WORDS)
        return SFRAS_E_ARG;
    for (i = 0; i < SFRAS_FI_MASK_WORDS; i++)
        WR(SFRAS_FI_MASK(i), i < mask_words ? mask[i] : 0u);
    WR(SFRAS_FI_ADDR, addr);
    return fi_arm(dev, (m << SFRAS_FI_CTRL_TARGET_SHIFT) | (mode << SFRAS_FI_CTRL_MODE_SHIFT) |
                       (addr_match ? SFRAS_FI_CTRL_ADDR_EN_MASK : 0u));
}

sfras_status_t sfras_fi_inject_bus(sfras_dev_t *dev, uint32_t injector, uint32_t bus_mode, uint32_t mask,
                                   uint32_t delay)
{
    if (injector > 7u || bus_mode > 3u)
        return SFRAS_E_ARG;
    WR(SFRAS_FI_MASK(0), mask);
    WR(SFRAS_FI_DELAY, delay & 0xFFFFu);
    return fi_arm(dev, ((injector + 8u) << SFRAS_FI_CTRL_TARGET_SHIFT) | (bus_mode << SFRAS_FI_CTRL_BUS_MODE_SHIFT));
}
#endif
