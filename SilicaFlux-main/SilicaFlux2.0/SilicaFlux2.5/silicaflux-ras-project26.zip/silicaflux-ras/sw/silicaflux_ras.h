/*
 * SilicaFlux RAS (Project 26) -- firmware / host driver API.
 *
 * Works on the ControlCore (bare metal, RV32) and from the host through the
 * host port: the register page is identical, only the base address differs.
 * Register offsets and fields come from silicaflux_ras_regs.h, which is
 * generated from the same table as the RTL header (scripts/regmap.py).
 *
 * MMIO access goes through SFRAS_READ32 / SFRAS_WRITE32; define them before
 * including this header to use another access method (host driver, test mock).
 *
 * Fault injection: the functions exist only when SFRAS_ENABLE_FI is defined.
 * Production firmware should NOT define it and should call sfras_lock_fi() at
 * boot; the hardware then refuses every injection until reset, whatever
 * software runs later.
 */
#ifndef SILICAFLUX_RAS_H
#define SILICAFLUX_RAS_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "silicaflux_ras_regs.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef SFRAS_READ32
#define SFRAS_READ32(dev, off)       (*(volatile uint32_t *)((dev)->base + (off)))
#endif
#ifndef SFRAS_WRITE32
#define SFRAS_WRITE32(dev, off, val) (*(volatile uint32_t *)((dev)->base + (off)) = (uint32_t)(val))
#endif

typedef struct {
    uintptr_t base;            /* byte address of the RAS register page */
    uint32_t  nmem;            /* from CFG */
    uint32_t  next;            /* external event ports (source ids 0 .. next-1) */
    uint32_t  nsrc;            /* total sources */
    uint32_t  lost_seen;       /* LOG_STAT.LOST at the last service */
} sfras_dev_t;

/* one event-log entry */
typedef struct {
    uint8_t  src;              /* source id (event port), see sfras_src_*() */
    uint8_t  type;             /* SFRAS_EV_* */
    uint8_t  sev;              /* SFRAS_SEV_* */
    bool     corrected;        /* a correction WAS performed */
    bool     addr_valid;
    uint32_t addr;
    uint32_t info;
    uint64_t ts;               /* cycle counter */
} sfras_event_t;

/* decoded info word of an ECC-memory event (MEM_CE / MEM_UE / POISON) */
typedef struct {
    uint8_t origin;            /* SFRAS_ORG_* */
    bool    poison, ue, ce;
    uint16_t syndrome;         /* {pe, s} */
    uint8_t bit;               /* stored-bit index of the corrected bit (valid if ce) */
} sfras_mem_info_t;

typedef enum {
    SFRAS_OK = 0,
    SFRAS_E_ID = -1,           /* ID / version mismatch: not a RAS page */
    SFRAS_E_ARG = -2,
    SFRAS_E_REFUSED = -3,      /* the hardware refused the access (rb_err / refusal counter) */
    SFRAS_E_TIMEOUT = -4,
} sfras_status_t;

/* boot-time configuration */
typedef struct {
    uint32_t irq_ctrl_sev_mask;    /* bit per severity -> ControlCore interrupt (default WARN|ERROR|FATAL) */
    uint32_t irq_host_sev_mask;    /* -> host interrupt (default FATAL) */
    uint32_t log_threshold;        /* 0 = no log-threshold interrupt */
    uint32_t sev_escalate;         /* SEV_CFG value (2 bits per type), 0 = hardware minimum */
    bool     fatal_contain;        /* isolate accelerators on FATAL */
    bool     fatal_lock;           /* FATAL cleared only by reset */
    bool     lock_fault_injection; /* production: refuse injection until reset */
} sfras_config_t;

void            sfras_default_config(sfras_config_t *cfg);
sfras_status_t  sfras_init(sfras_dev_t *dev, uintptr_t base, const sfras_config_t *cfg);

/* source ids (the port map of silicaflux_ras) */
static inline uint32_t sfras_src_mem(const sfras_dev_t *d, uint32_t m)      { return d->next + 3u * m; }
static inline uint32_t sfras_src_mem_rec(const sfras_dev_t *d, uint32_t m)  { return d->next + 3u * m + 1u; }
static inline uint32_t sfras_src_mem_fi(const sfras_dev_t *d, uint32_t m)   { return d->next + 3u * m + 2u; }
static inline uint32_t sfras_src_wdog(const sfras_dev_t *d)                 { return d->next + 3u * d->nmem; }
static inline uint32_t sfras_src_therm(const sfras_dev_t *d)                { return d->next + 3u * d->nmem + 1u; }
static inline uint32_t sfras_src_regs(const sfras_dev_t *d)                 { return d->next + 3u * d->nmem + 2u; }

/* event log */
bool            sfras_log_pop(sfras_dev_t *dev, sfras_event_t *ev);        /* false when empty */
bool            sfras_first_error(sfras_dev_t *dev, sfras_event_t *ev);    /* false when none captured */
void            sfras_clear_first(sfras_dev_t *dev);
uint32_t        sfras_log_lost(sfras_dev_t *dev);

/* interrupt service: drains the log into handler(), then clears the sticky
 * severity bits that were serviced.  Returns the number of events handled.
 * *lost_out (optional) receives the number of events lost since the last call.
 * SEEN_FATAL is left set (and fatal_o asserted): fatal handling is the
 * caller's decision (and impossible to clear once FATAL_LOCK is set). */
typedef void (*sfras_handler_t)(void *ctx, const sfras_event_t *ev);
uint32_t        sfras_service(sfras_dev_t *dev, sfras_handler_t handler, void *ctx, uint32_t *lost_out);

uint32_t        sfras_status(sfras_dev_t *dev);
bool            sfras_fatal(sfras_dev_t *dev);
uint32_t        sfras_type_count(sfras_dev_t *dev, uint32_t type);
uint32_t        sfras_src_count(sfras_dev_t *dev, uint32_t src);
void            sfras_clear_counts(sfras_dev_t *dev);
uint64_t        sfras_timestamp(sfras_dev_t *dev);

/* decoding helpers (pure functions) */
sfras_mem_info_t sfras_decode_mem_info(uint32_t info);
const char      *sfras_type_name(uint32_t type);
const char      *sfras_sev_name(uint32_t sev);

/* ECC memories: initialisation and patrol scrub */
sfras_status_t  sfras_mem_init(sfras_dev_t *dev, uint32_t m, uint32_t poll_limit);
#define SFRAS_SCRUB_ONE_PASS   SFRAS_MEM_CTRL_ONE_PASS_MASK
#define SFRAS_SCRUB_FIX        SFRAS_MEM_CTRL_FIX_EN_MASK
#define SFRAS_SCRUB_VERIFY     SFRAS_MEM_CTRL_VERIFY_EN_MASK
#define SFRAS_SCRUB_STOP_ON_UE SFRAS_MEM_CTRL_STOP_ON_UE_MASK
sfras_status_t  sfras_scrub_start(sfras_dev_t *dev, uint32_t m, uint32_t lo, uint32_t hi,
                                  uint32_t interval, uint32_t flags);
void            sfras_scrub_stop(sfras_dev_t *dev, uint32_t m);
typedef struct {
    uint32_t status, cur, ue_addr, passes, ce, fixed, ue, poisoned, hard, reads;
} sfras_scrub_stats_t;
void            sfras_scrub_stats(sfras_dev_t *dev, uint32_t m, sfras_scrub_stats_t *st);

/* watchdog and thermal */
sfras_status_t  sfras_wdog_start(sfras_dev_t *dev, uint32_t cycles, bool lock);
void            sfras_wdog_kick(sfras_dev_t *dev);
sfras_status_t  sfras_therm_config(sfras_dev_t *dev, uint32_t warn, uint32_t fatal, uint32_t hyst,
                                   uint32_t stale_cycles);

/* production lock (always available: it only removes capability) */
void            sfras_lock_fi(sfras_dev_t *dev);

#ifdef SFRAS_ENABLE_FI
/* fault injection: test / bring-up builds only.  Needs the hardware
 * permission pin (TestCore test mode / debug unlock), a privileged master and
 * FI_LOCK clear; every request is logged as an FI event either way. */
sfras_status_t  sfras_fi_unlock(sfras_dev_t *dev);
void            sfras_fi_relock(sfras_dev_t *dev);
sfras_status_t  sfras_fi_inject_mem(sfras_dev_t *dev, uint32_t m, uint32_t mode, bool addr_match,
                                    uint32_t addr, const uint32_t *mask, uint32_t mask_words);
sfras_status_t  sfras_fi_inject_bus(sfras_dev_t *dev, uint32_t injector, uint32_t bus_mode,
                                    uint32_t mask, uint32_t delay);
#endif

#ifdef __cplusplus
}
#endif
#endif /* SILICAFLUX_RAS_H */
