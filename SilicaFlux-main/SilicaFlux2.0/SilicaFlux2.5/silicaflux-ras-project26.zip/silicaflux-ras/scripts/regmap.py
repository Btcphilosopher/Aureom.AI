#!/usr/bin/env python3
"""SilicaFlux RAS (Project 26) register map -- the single source of truth.

usage: scripts/regmap.py            (re)generates
         rtl/sfras_regs.svh          `define offsets / fields for the RTL
         sw/silicaflux_ras_regs.h    C header for firmware and host drivers
         docs/08_register_map.md     human-readable map

Page: 4 KiB, 32-bit registers, 12-bit byte offset (ControlCore register-page
bus: rb_sel / rb_we / rb_addr[11:0] / rb_wdata / rb_rdata / rb_err).
Access: RO read-only (write -> rb_err + ILLEGAL_OP event), RW, W1C (write one
to clear), WO (read -> rb_err), W1P (write-one pulse bits inside an RW reg),
PRIV (write requires rb_priv = 1, else rb_err + ILLEGAL_OP event).
"""

from __future__ import annotations

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

ID_VALUE = 0x52415326          # "RAS" + 0x26 (project 26)
VERSION = 0x00010000           # 1.0.0
WDOG_KEY = 0x5AFEC0DE
FI_KEY1 = 0xF1A70001
FI_KEY2 = 0xF1A70002
MEM_BASE = 0x400
MEM_STRIDE = 0x40
MAX_MEM = 8
MAX_SRC = 32
FI_MASK_WORDS = 8

# (offset, name, access, reset, description, [(field, msb, lsb, description), ...])
REGS = [
    (0x000, "ID", "RO", ID_VALUE, "Identification: 0x52415326 ('RAS', project 0x26)", []),
    (0x004, "VERSION", "RO", VERSION, "Register-map version [31:16] major [15:8] minor [7:0] patch", []),
    (0x008, "CFG", "RO", None, "Build configuration", [
        ("NEXT", 7, 0, "number of external event ports"),
        ("NMEM", 15, 8, "number of managed ECC memories"),
        ("LOG_DEPTH", 23, 16, "event-log entries"),
        ("FI_EN", 24, 24, "fault injection compiled in"),
        ("NP", 31, 25, "total event ports (= source ids 0 .. NP-1)")]),
    (0x00C, "CFG2", "RO", None, "Build configuration 2", [
        ("TS_W", 7, 0, "timestamp width"),
        ("CNT_W", 15, 8, "counter width"),
        ("THERM_W", 23, 16, "thermal code width"),
        ("FI_MASK_W", 31, 24, "fault-injection mask width / 8")]),
    (0x010, "CTRL", "RW", 0x3, "Global control", [
        ("LOG_EN", 0, 0, "1 = record events in the log"),
        ("FATAL_CONTAIN", 1, 1, "1 = a FATAL event asserts contain_o (isolate / stop accelerators)"),
        ("FATAL_LOCK", 2, 2, "set-only until reset: STATUS.SEEN_FATAL can no longer be cleared"),
        ("FI_LOCK", 3, 3, "set-only until reset: fault injection permanently refused"),
        ("CLR_COUNTS", 8, 8, "W1P: clear type / source counters and overflow flags"),
        ("CLR_LOG", 9, 9, "W1P: empty the event log, clear the lost count"),
        ("CLR_FIRST", 10, 10, "W1P: re-arm the first-error capture")]),
    (0x014, "STATUS", "W1C", 0x0, "Sticky status ([9:0] W1C, [31:16] live, read-only)", [
        ("SEEN_INFO", 0, 0, "an INFO event occurred"),
        ("SEEN_WARN", 1, 1, "a WARN event occurred"),
        ("SEEN_ERROR", 2, 2, "an ERROR event occurred"),
        ("SEEN_FATAL", 3, 3, "a FATAL event occurred (drives fatal_o; not clearable once FATAL_LOCK)"),
        ("LOG_OVF", 8, 8, "an event could not be logged (log full or port slot busy)"),
        ("CNT_OVF", 9, 9, "a counter saturated"),
        ("FATAL_OUT", 16, 16, "live: fatal_o"),
        ("CONTAIN_OUT", 17, 17, "live: contain_o"),
        ("FI_UNLOCKED", 18, 18, "live: fault injection unlocked"),
        ("FI_BUSY", 19, 19, "live: an injection is armed / in progress"),
        ("THERM_SHUTDOWN", 20, 20, "live: thermal shutdown request"),
        ("WDOG_STAGE1", 21, 21, "live: watchdog first expiry"),
        ("WDOG_STAGE2", 22, 22, "live: watchdog second expiry (reset request)")]),
    (0x018, "TYPE_STATUS", "W1C", 0x0, "Sticky per-event-type bits [15:0] (bit = SFRAS_EV_* code)", []),
    (0x01C, "IRQ_EN_CTRL", "RW", 0xE, "Interrupt enables, ControlCore line irq_ctrl_o", [
        ("SEV", 3, 0, "one bit per severity (INFO, WARN, ERROR, FATAL) of STATUS.SEEN_*"),
        ("LOG_THR", 4, 4, "interrupt while log count >= LOG_THR")]),
    (0x020, "IRQ_EN_HOST", "RW", 0x8, "Interrupt enables, host line irq_host_o (same fields)", []),
    (0x024, "LOG_THR", "RW", 0x1, "Log-count interrupt threshold [7:0]", []),
    (0x028, "SEV_CFG", "RW", 0x0, "Software minimum severity, 2 bits per event type (type t at [2t+1:2t]); "
                                 "effective severity = max(hardware minimum, this): software can raise, never lower", []),
    (0x02C, "IRQ_STATUS", "RO", None, "[0] irq_ctrl_o [1] irq_host_o", []),
    (0x030, "TS_LO", "RO", None, "Timestamp (cycle counter) [31:0]", []),
    (0x034, "TS_HI", "RO", None, "Timestamp upper bits", []),
    (0x040, "LOG_STAT", "RO", None, "Event log", [
        ("COUNT", 15, 0, "entries in the log"),
        ("LOST", 31, 16, "events not logged (saturating)")]),
    (0x044, "LOG_POP", "WO", None, "Write: remove the head entry", []),
    (0x048, "LOG_SRC", "RO", None, "Head entry: source / type / severity", [
        ("SRC", 7, 0, "source id (event port)"),
        ("TYPE", 11, 8, "SFRAS_EV_*"),
        ("SEV", 13, 12, "SFRAS_SEV_*"),
        ("CORR", 14, 14, "a correction was performed"),
        ("ADDR_V", 15, 15, "LOG_ADDR is valid"),
        ("VALID", 31, 31, "entry valid (log not empty)")]),
    (0x04C, "LOG_ADDR", "RO", None, "Head entry: address", []),
    (0x050, "LOG_INFO", "RO", None, "Head entry: source-specific information", []),
    (0x054, "LOG_TS_LO", "RO", None, "Head entry: timestamp [31:0]", []),
    (0x058, "LOG_TS_HI", "RO", None, "Head entry: timestamp upper bits", []),
    (0x060, "FIRST_SRC", "RO", None, "First ERROR-or-worse event since CLR_FIRST (LOG_SRC packing)", []),
    (0x064, "FIRST_ADDR", "RO", None, "First error: address", []),
    (0x068, "FIRST_INFO", "RO", None, "First error: information", []),
    (0x06C, "FIRST_TS_LO", "RO", None, "First error: timestamp [31:0]", []),
    (0x070, "FIRST_TS_HI", "RO", None, "First error: timestamp upper bits", []),
    (0x0C0, "TYPE_OVF", "RO", None, "Per-type counter saturated [15:0]", []),
    (0x0C4, "SRC_OVF", "RO", None, "Per-source counter saturated [31:0]", []),
    # watchdog
    (0x200, "WDOG_CTRL", "RW", 0x0, "Watchdog control", [
        ("EN", 0, 0, "enable (count down from WDOG_LOAD)"),
        ("LOCK", 1, 1, "set-only until reset: EN and LOAD can no longer change")]),
    (0x204, "WDOG_LOAD", "RW", 0x00100000, "Timeout in cycles (each stage)", []),
    (0x208, "WDOG_KICK", "WO", None, f"Write 0x{WDOG_KEY:08X} to restart the count; any other value -> ILLEGAL_OP event", []),
    (0x20C, "WDOG_COUNT", "RO", None, "Current count", []),
    (0x210, "WDOG_STATUS", "W1C", 0x0, "[0] STAGE1 expired (ERROR event)  [1] STAGE2 expired (FATAL event, reset request)", []),
    # thermal
    (0x240, "THERM_CTRL", "RW", 0x0, "[0] EN", []),
    (0x244, "THERM_WARN", "RW", None, "Warning threshold (sensor code)", []),
    (0x248, "THERM_FATAL", "RW", None, "Fatal threshold; writes above the hardware maximum are clamped (ILLEGAL_OP event)", []),
    (0x24C, "THERM_HYST", "RW", 0x8, "Hysteresis (codes) for leaving WARN / FATAL", []),
    (0x250, "THERM_STALE", "RW", 0x0, "Sensor-stale timeout in cycles (0 = off)", []),
    (0x254, "THERM_STATUS", "RO", None, "Thermal status", [
        ("CODE", 15, 0, "last sample"),
        ("WARN", 16, 16, "warning active"),
        ("FATAL", 17, 17, "fatal active (therm_shutdown_o)"),
        ("STALE", 18, 18, "no sample within THERM_STALE cycles"),
        ("SEEN", 19, 19, "at least one sample received")]),
    # fault injection
    (0x300, "FI_KEY", "WO", None, f"PRIV. Unlock: 0x{FI_KEY1:08X} then 0x{FI_KEY2:08X}; any other value re-locks (ILLEGAL_OP)", []),
    (0x304, "FI_CTRL", "RW", 0x0, "PRIV. Injection request", [
        ("ARM", 0, 0, "W1P: arm one injection at TARGET (refused unless unlocked)"),
        ("RELOCK", 1, 1, "W1P: lock again"),
        ("MODE", 5, 4, "memory: SFRAS_FI_WRITE / READ / SCRUB_WB / INPLACE"),
        ("ADDR_EN", 6, 6, "memory: only at FI_ADDR"),
        ("TARGET", 11, 8, "0..7 memory m, 8..15 bus injector (m - 8)"),
        ("BUS_MODE", 17, 16, "bus injector: 0 flip response data, 1 force error response, 2 delay response (FI_DELAY), 3 flip write data; parity link: 0 request parity, 1 response parity")]),
    (0x308, "FI_ADDR", "RW", 0x0, "PRIV. Injection address (word address for memories)", []),
    (0x30C, "FI_STATUS", "RO", None, "Fault-injection status", [
        ("UNLOCKED", 0, 0, "unlock sequence completed"),
        ("ALLOW", 1, 1, "hardware permission pin fi_allow_i"),
        ("LOCKED", 2, 2, "CTRL.FI_LOCK set"),
        ("BUSY", 3, 3, "target busy (armed / in progress)"),
        ("ARMS", 15, 8, "accepted arms (saturating)"),
        ("REFUSED", 23, 16, "refused requests (saturating)")]),
    (0x310, "FI_DELAY", "RW", 0x0, "PRIV. Bus injector delay in cycles [15:0]", []),
]
for i in range(FI_MASK_WORDS):
    REGS.append((0x320 + 4 * i, f"FI_MASK{i}", "RW", 0x0, f"PRIV. XOR mask bits [{32 * i + 31}:{32 * i}]", []))
for t in range(16):
    REGS.append((0x080 + 4 * t, f"TYPE_CNT{t}", "RO", None, f"Events of type {t} (saturating)", []))
for s in range(MAX_SRC):
    REGS.append((0x100 + 4 * s, f"SRC_CNT{s}", "RO", None, f"Events from source {s} (saturating)", []))

MEM_REGS = [
    (0x00, "CTRL", "RW", 0x0C, "Scrub / init control", [
        ("SCRUB_EN", 0, 0, "patrol scrub enabled"),
        ("ONE_PASS", 1, 1, "stop after one pass (STATUS.DONE)"),
        ("FIX_EN", 2, 2, "write corrected words back"),
        ("VERIFY_EN", 3, 3, "re-read after a write-back"),
        ("STOP_ON_UE", 4, 4, "stop at the first uncorrectable word"),
        ("SCRUB_START", 8, 8, "W1P: (re)start at LO"),
        ("CLR_COUNTS", 9, 9, "W1P: clear the scrub counters"),
        ("INIT", 10, 10, "W1P: re-initialise the memory (all words = encode(0))")]),
    (0x04, "INTERVAL", "RW", 0x400, "Cycles between scrub reads", []),
    (0x08, "LO", "RW", 0x0, "First scrubbed word", []),
    (0x0C, "HI", "RW", None, "Last scrubbed word (reset: DEPTH-1)", []),
    (0x10, "STATUS", "RO", None, "Memory status", [
        ("ACTIVE", 0, 0, "scrub walking"),
        ("STOPPED_UE", 1, 1, "stopped at an uncorrectable word (see UE_ADDR)"),
        ("DONE", 2, 2, "one-pass scrub completed"),
        ("INIT_BUSY", 3, 3, "initialisation running"),
        ("INIT_DONE", 4, 4, "initialisation completed"),
        ("CNT_OVF", 5, 5, "a scrub counter saturated"),
        ("UE_SEEN", 6, 6, "scrub found an uncorrectable word"),
        ("FI_ARMED", 7, 7, "an injection is armed / in progress at this memory")]),
    (0x14, "CUR", "RO", None, "Scrub position", []),
    (0x18, "UE_ADDR", "RO", None, "First uncorrectable word found by scrub", []),
    (0x1C, "PASS", "RO", None, "Completed scrub passes", []),
    (0x20, "CE", "RO", None, "Correctable words found by scrub", []),
    (0x24, "FIX", "RO", None, "Corrected words written back", []),
    (0x28, "UE", "RO", None, "Uncorrectable words found by scrub", []),
    (0x2C, "POISON", "RO", None, "Poisoned words found by scrub", []),
    (0x30, "HARD", "RO", None, "Write-backs that did not clear the error (recovery failures)", []),
    (0x34, "READS", "RO", None, "Scrub reads issued", []),
]

EVENT_TYPES = [
    (0, "NONE", "-", "reserved"),
    (1, "MEM_CE", "INFO", "correctable memory error (a bit was corrected)"),
    (2, "MEM_UE", "ERROR", "detected uncorrectable memory error"),
    (3, "BUS_PARITY", "ERROR", "parity mismatch on a protected bus link"),
    (4, "DMA_ERR", "ERROR", "DMA transaction ended in a bus error"),
    (5, "WDOG", "ERROR / FATAL (info[0] = stage 2)", "watchdog expired"),
    (6, "THERM_WARN", "WARN", "thermal warning threshold crossed / sensor stale"),
    (7, "THERM_FATAL", "FATAL", "fatal thermal threshold crossed"),
    (8, "ILLEGAL_OP", "WARN", "illegal control operation"),
    (9, "POISON", "ERROR", "poisoned data consumed"),
    (10, "RECOVERY", "WARN", "recovery action failed (write-back did not clear an error)"),
    (11, "TIMEOUT", "ERROR", "bus transaction timeout"),
    (12, "FI", "INFO", "fault injection armed / fired (audit trail)"),
]
ILLEGAL_REASONS = [
    (1, "RO_OR_UNMAPPED", "write to a read-only or unmapped register"),
    (2, "NOT_PRIV", "fault-injection register written by an unprivileged master"),
    (3, "LOCKED", "write to a locked register (WDOG / FI_LOCK)"),
    (4, "BAD_KEY", "wrong watchdog kick or fault-injection unlock key"),
    (5, "FI_NOT_ALLOWED", "injection requested while not unlocked / not allowed / locked"),
    (6, "CLAMPED", "THERM_FATAL above the hardware maximum (clamped)"),
    (7, "FI_BUSY", "injection requested while the target is busy, or bad target"),
]


ARRAYS = ("TYPE_CNT", "SRC_CNT", "FI_MASK")


def array_of(name: str):
    """(base, index) for array registers TYPE_CNTi / SRC_CNTi / FI_MASKi, else (None, None)."""
    for base in ARRAYS:
        if name.startswith(base) and name[len(base):].isdigit():
            return base, int(name[len(base):])
    return None, None


def gen_svh() -> str:
    out = ["// GENERATED by scripts/regmap.py -- do not edit.",
           "// SilicaFlux RAS (Project 26) register offsets and fields.",
           "`ifndef SFRAS_REGS_SVH", "`define SFRAS_REGS_SVH", ""]
    out.append(f"`define SFRAS_ID_VALUE       32'h{ID_VALUE:08X}")
    out.append(f"`define SFRAS_VERSION_VALUE  32'h{VERSION:08X}")
    out.append(f"`define SFRAS_WDOG_KEY       32'h{WDOG_KEY:08X}")
    out.append(f"`define SFRAS_FI_KEY1        32'h{FI_KEY1:08X}")
    out.append(f"`define SFRAS_FI_KEY2        32'h{FI_KEY2:08X}")
    out.append(f"`define SFRAS_MEM_BASE       12'h{MEM_BASE:03X}")
    out.append(f"`define SFRAS_MEM_STRIDE     12'h{MEM_STRIDE:03X}")
    out.append(f"`define SFRAS_MAX_MEM        {MAX_MEM}")
    out.append(f"`define SFRAS_MAX_SRC        {MAX_SRC}")
    out.append(f"`define SFRAS_FI_MASK_WORDS  {FI_MASK_WORDS}")
    out.append("")
    for off, name, acc, rst, desc, fields in REGS:
        base, idx = array_of(name)
        if base is not None and idx != 0:
            continue
        n = base if base is not None else name
        out.append(f"`define SFRAS_R_{n:<14s} 12'h{off:03X}   // {acc}")
        if rst is not None and acc in ("RW", "W1C"):
            out.append(f"`define SFRAS_RST_{n:<12s} 32'h{rst:08X}")
        for f, msb, lsb, _ in fields:
            out.append(f"`define SFRAS_{n}_{f}_LSB {lsb}")
            if msb != lsb:
                out.append(f"`define SFRAS_{n}_{f}_MSB {msb}")
    out.append("")
    for off, name, acc, rst, desc, fields in MEM_REGS:
        out.append(f"`define SFRAS_M_{name:<14s} 6'h{off:02X}   // {acc}")
        if rst is not None and acc == "RW":
            out.append(f"`define SFRAS_MRST_{name:<11s} 32'h{rst:08X}")
        for f, msb, lsb, _ in fields:
            out.append(f"`define SFRAS_M_{name}_{f}_LSB {lsb}")
    out.append("")
    for code, name, _ in ILLEGAL_REASONS:
        out.append(f"`define SFRAS_ILL_{name:<16s} 4'd{code}")
    out += ["", "`endif // SFRAS_REGS_SVH", ""]
    return "\n".join(out)


def gen_h() -> str:
    out = ["/* GENERATED by scripts/regmap.py -- do not edit. */",
           "/* SilicaFlux RAS (Project 26): register map for firmware and host software. */",
           "#ifndef SILICAFLUX_RAS_REGS_H", "#define SILICAFLUX_RAS_REGS_H", "", "#include <stdint.h>", ""]
    out.append(f"#define SFRAS_ID_VALUE      0x{ID_VALUE:08X}u")
    out.append(f"#define SFRAS_VERSION_VALUE 0x{VERSION:08X}u")
    out.append(f"#define SFRAS_WDOG_KEY      0x{WDOG_KEY:08X}u")
    out.append(f"#define SFRAS_FI_KEY1       0x{FI_KEY1:08X}u")
    out.append(f"#define SFRAS_FI_KEY2       0x{FI_KEY2:08X}u")
    out.append(f"#define SFRAS_MAX_MEM       {MAX_MEM}u")
    out.append(f"#define SFRAS_MAX_SRC       {MAX_SRC}u")
    out.append(f"#define SFRAS_FI_MASK_WORDS {FI_MASK_WORDS}u")
    out.append("")
    out.append("/* register byte offsets inside the 4 KiB RAS page */")
    for off, name, acc, rst, desc, fields in REGS:
        base, idx = array_of(name)
        if base is not None:
            if idx == 0:
                out.append(f"#define SFRAS_{base}(i)      (0x{off:03X}u + 4u * (uint32_t)(i))   /* {acc} */")
            continue
        out.append(f"#define SFRAS_{name:<15s} 0x{off:03X}u   /* {acc}: {desc[:70]} */")
    out.append(f"#define SFRAS_MEM(m, reg)     (0x{MEM_BASE:03X}u + 0x{MEM_STRIDE:02X}u * (uint32_t)(m) + (reg))")
    for off, name, acc, rst, desc, fields in MEM_REGS:
        out.append(f"#define SFRAS_MEM_{name:<11s} 0x{off:02X}u   /* {acc}: {desc[:70]} */")
    out.append("")
    out.append("/* fields */")
    for off, name, acc, rst, desc, fields in list(REGS):
        for f, msb, lsb, d in fields:
            w = msb - lsb + 1
            mask = ((1 << w) - 1) << lsb
            out.append(f"#define SFRAS_{name}_{f}_SHIFT {lsb}u")
            out.append(f"#define SFRAS_{name}_{f}_MASK  0x{mask:08X}u")
    for off, name, acc, rst, desc, fields in MEM_REGS:
        for f, msb, lsb, d in fields:
            w = msb - lsb + 1
            mask = ((1 << w) - 1) << lsb
            out.append(f"#define SFRAS_MEM_{name}_{f}_MASK 0x{mask:08X}u")
    out.append("")
    out.append("/* event types (LOG_SRC.TYPE) */")
    for code, name, sev, d in EVENT_TYPES:
        out.append(f"#define SFRAS_EV_{name:<12s} {code}u   /* {sev}: {d} */")
    out.append("/* severities */")
    for i, n in enumerate(["INFO", "WARN", "ERROR", "FATAL"]):
        out.append(f"#define SFRAS_SEV_{n:<6s} {i}u")
    out.append("/* ECC memory event origin (MEM_CE / MEM_UE / POISON info[31:29]) */")
    for i, n in enumerate(["READ", "RMW", "SCRUB", "SCRUB_FIX", "SCRUB_VERIFY", "FI"]):
        out.append(f"#define SFRAS_ORG_{n:<13s} {i}u")
    out.append("/* fault-injection memory modes (FI_CTRL.MODE) */")
    for i, n in enumerate(["WRITE", "READ", "SCRUB_WB", "INPLACE"]):
        out.append(f"#define SFRAS_FI_{n:<9s} {i}u")
    out.append("/* ILLEGAL_OP info[15:12] reasons (info[11:0] = register offset) */")
    for code, name, d in ILLEGAL_REASONS:
        out.append(f"#define SFRAS_ILL_{name:<16s} {code}u  /* {d} */")
    out += ["", "#endif /* SILICAFLUX_RAS_REGS_H */", ""]
    return "\n".join(out)


def gen_md() -> str:
    out = ["# 08 — Register map (generated by `scripts/regmap.py`)", "",
           "One 4 KiB page, 32-bit registers, ControlCore register-page bus (`rb_sel / rb_we / rb_addr[11:0] / "
           "rb_wdata / rb_rdata / rb_err`) plus `rb_priv`.  The same page is mapped for the ControlCore firmware and "
           "the host port; fault-injection writes additionally need `rb_priv = 1`.", "",
           "Access: **RO** (a write returns `rb_err` and logs an `ILLEGAL_OP` event), **RW**, **W1C**, **WO** (a "
           "read returns `rb_err`), **W1P** (write-one pulse bit), **PRIV** (write needs `rb_priv`).", "",
           "| Offset | Name | Access | Reset | Description |", "|---|---|---|---|---|"]
    for off, name, acc, rst, desc, fields in sorted(REGS):
        base, idx = array_of(name)
        if base is not None and idx != 0:
            continue
        nm = name if base is None else base + "[i]"
        r = "-" if rst is None else f"0x{rst:X}"
        out.append(f"| 0x{off:03X} | {nm} | {acc} | {r} | {desc} |")
        for f, msb, lsb, d in fields:
            bits = f"[{msb}:{lsb}]" if msb != lsb else f"[{lsb}]"
            out.append(f"| | `{f}` {bits} | | | {d} |")
    out += ["", f"`TYPE_CNT[i]` at 0x080 + 4i (i < 16), `SRC_CNT[s]` at 0x100 + 4s (s < {MAX_SRC}), "
                f"`FI_MASK[i]` at 0x320 + 4i (i < {FI_MASK_WORDS}).", "",
            f"## Per-memory block: 0x{MEM_BASE:03X} + 0x{MEM_STRIDE:02X} × m (m < {MAX_MEM})", "",
            "| Offset | Name | Access | Reset | Description |", "|---|---|---|---|---|"]
    for off, name, acc, rst, desc, fields in MEM_REGS:
        r = "-" if rst is None else f"0x{rst:X}"
        out.append(f"| +0x{off:02X} | MEM_{name} | {acc} | {r} | {desc} |")
        for f, msb, lsb, d in fields:
            bits = f"[{msb}:{lsb}]" if msb != lsb else f"[{lsb}]"
            out.append(f"| | `{f}` {bits} | | | {d} |")
    out += ["", "## Event types and hardware minimum severity", "", "| Code | Type | Min. severity | Meaning |",
            "|---|---|---|---|"]
    for code, name, sev, d in EVENT_TYPES:
        out.append(f"| {code} | `{name}` | {sev} | {d} |")
    out += ["", "## `ILLEGAL_OP` reasons (`info[15:12]`; `info[11:0]` = register offset)", "",
            "| Code | Reason | Meaning |", "|---|---|---|"]
    for code, name, d in ILLEGAL_REASONS:
        out.append(f"| {code} | `{name}` | {d} |")
    out.append("")
    return "\n".join(out)


def main() -> int:
    targets = {
        os.path.join(ROOT, "rtl", "sfras_regs.svh"): gen_svh(),
        os.path.join(ROOT, "sw", "silicaflux_ras_regs.h"): gen_h(),
        os.path.join(ROOT, "docs", "08_register_map.md"): gen_md(),
    }
    offs = [r[0] for r in REGS]
    assert len(offs) == len(set(offs)), "duplicate register offsets"
    for p, txt in targets.items():
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w") as f:
            f.write(txt)
        print("wrote", os.path.relpath(p, ROOT))
    return 0


if __name__ == "__main__":
    sys.exit(main())
