#!/usr/bin/env bash
# Regenerate everything: register headers, lint, regression (Icarus + Verilator +
# firmware co-simulation), synthesis check, mutation check, coverage report.
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -I scripts/regmap.py
bash scripts/lint.sh
python3 -I scripts/run_regress.py --sim both
python3 -I synth/run_synth.py
python3 -I scripts/run_mutation.py
python3 -I scripts/ras_report.py
