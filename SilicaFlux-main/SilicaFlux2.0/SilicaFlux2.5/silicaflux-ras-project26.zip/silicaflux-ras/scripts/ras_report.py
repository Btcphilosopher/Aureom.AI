#!/usr/bin/env python3
"""Generate the RAS coverage report from the code model and the regression logs.

usage: scripts/ras_report.py     (after scripts/run_regress.py)
   -> reports/ras_coverage_report.md, reports/ras_coverage.json

Everything numeric in the report is either
  * computed exactly from the code definition (model/secded_ref.py): the code
    is linear, so whether an error pattern is corrected / detected / missed
    depends only on the pattern, not on the data -- every pattern of weight
    1..3 (and 4 for N <= 80) is enumerated, nothing is sampled; or
  * taken from simulation logs (RESULT / MEAS lines of build/logs/*.log); or
  * a capacity read from RTL parameters during the audit (docs/00_audit.md).
No failure rate (FIT), soft-error rate or field reliability is computed or
implied: that needs device / process / environment data this project does not
have.
"""

from __future__ import annotations

import datetime
import glob
import itertools
import json
import math
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "model"))
from secded_ref import Secded  # noqa: E402


# ------------------------------------------------------------------ code analysis
def analyse(k: int, max_w4_n: int = 80) -> dict:
    c = Secded(k, inv=0)
    n = c.n
    cols = []
    for b in range(n):
        col = 0
        for j, row in enumerate(c.h_rows):
            col |= ((row >> b) & 1) << j
        cols.append(col)
    colset = set(cols)
    res = {"K": k, "R": c.r, "N": n, "overhead_pct": round(100.0 * (n - k) / k, 1)}

    def classify(v: int) -> str:
        if v == 0:
            return "undetected"
        if v in colset:
            return "corrected"            # flagged CE (for weight >= 2 this is a MIScorrection)
        return "detected"

    for w in (1, 2, 3, 4):
        if w == 4 and n > max_w4_n:
            continue
        cnt = {"corrected": 0, "detected": 0, "undetected": 0}
        for combo in itertools.combinations(range(n), w):
            v = 0
            for b in combo:
                v ^= cols[b]
            cnt[classify(v)] += 1
        res[f"w{w}"] = cnt
        res[f"w{w}_total"] = math.comb(n, w)
    # adjacent (burst) triples: contiguous stored bits
    cnt = {"corrected": 0, "detected": 0, "undetected": 0}
    for s in range(n - 2):
        cnt[classify(cols[s] ^ cols[s + 1] ^ cols[s + 2])] += 1
    res["burst3"] = cnt
    # SIG-mode ambiguity: double errors whose syndrome equals the signature (two top check bits)
    sig = (1 << (c.r - 1)) | (1 << (c.r - 2))
    amb = 0
    for a, b in itertools.combinations(range(n - 1), 2):          # exclude the overall parity bit (pe stays 0)
        if (cols[a] ^ cols[b]) & ((1 << c.r) - 1) == sig:
            amb += 1
    res["sig_ambiguous_doubles"] = amb
    # invalid syndromes (names no bit) available for triple detection
    res["invalid_syndromes"] = (1 << c.r) - 1 - (k + c.r)
    return res


def byte_parity_analysis(width_bytes: int = 4) -> dict:
    """The existing byte-parity scheme (9 bits per byte, 36 bits per 32-bit word)."""
    n = 9 * width_bytes
    res = {"N": n, "K": 8 * width_bytes}
    for w in (1, 2, 3):
        det = und = 0
        for combo in itertools.combinations(range(n), w):
            lanes = {}
            for b in combo:
                lanes[b // 9] = lanes.get(b // 9, 0) + 1
            if any(v % 2 == 1 for v in lanes.values()):
                det += 1
            else:
                und += 1
        res[f"w{w}"] = {"detected": det, "undetected": und, "corrected": 0}
        res[f"w{w}_total"] = math.comb(n, w)
    return res


# ------------------------------------------------------------------ capacities (audit, docs/00_audit.md)
# (memory, repository/module, KiB, current protection, Project 26 disposition)
CAPACITY = [
    ("ControlCore IMEM", "silicaflux-controlcore mcu_sram_bank", 64.0, "byte parity (detect only)",
     "SECDED-capable: word-written by firmware loader; replace mcu_sram_bank parity by sfras_ecc_sram (K=32, SIG -> 39-bit)"),
    ("ControlCore DMEM", "silicaflux-controlcore mcu_sram_bank", 32.0, "byte parity (detect only)",
     "SECDED with RMW for byte stores (sfras_ecc_sram K=32)"),
    ("Shared SRAM", "silicaflux-memorycore sfmem_banked", 256.0, "byte parity (ECC_MODE=PARITY default)",
     "SECDED at the sfmem_banked encode/decode point (ECC_MODE=2 hook), RMW via bank lock"),
    ("LMEM", "silicaflux-memorycore sfmem_banked", 32.0, "byte parity (ECC_MODE=PARITY default)",
     "as shared SRAM"),
    ("HPC tile scratchpad (VSPM)", "silicaflux-hpc-m04/m08 hpc_scratchpad", 64.0, "none (M08 default SPM_ECC=NONE); byte parity optional",
     "SECDED for BYTE_WE=0 configurations; byte parity otherwise (RMW would halve bank bandwidth)"),
    ("DataFabric SFB2 SRAM slaves", "silicaflux-datafabric sfb_sram_slave", None, "none",
     "drop-in sfras_sfb_ecc_slave (this project; verified with the real DMA)"),
    ("Tensor operand buffer (A+B)", "TENSORCORE 03 tensor_operand_buffer", 2.0, "none",
     "unprotected: transient operands, refilled per tile -- candidate for byte parity"),
    ("Tensor output buffer", "TENSORCORE 07 tensor_output_buffer (hpc_scratchpad ECC NONE)", 0.5, "none",
     "unprotected; SECDED possible (word writes) -- not integrated"),
    ("Tensor accumulator storage", "TENSORCORE 04 tensor_acc_storage (flip-flop array)", 1056 / 8 / 1024, "none",
     "unprotected (flip-flops; 8 x 132 bits default)"),
    ("ControlCore D-cache data", "silicaflux-memorycore sfmem_cache", 2.0, "none",
     "unprotected; write-back dirty data is a single point of failure"),
    ("DMA burst FIFO", "silicaflux-datafabric dma_fifo", 8 * 4 / 1024, "none", "unprotected"),
    ("RAS event log + pending slots", "this project sfras_event_ctrl", (16 + 17) * 128 / 8 / 1024, "none",
     "unprotected (diagnostic data only)"),
]


# ------------------------------------------------------------------ simulation results
def collect_logs() -> dict:
    out = {"RESULT": {}, "MEAS": []}
    for p in sorted(glob.glob(os.path.join(ROOT, "build", "logs", "*.icarus.log"))):
        name = os.path.basename(p).replace(".icarus.log", "")
        lines = open(p).read().splitlines()
        out["RESULT"][name] = [ln for ln in lines if ln.startswith(("RESULT", "PASS", "FAIL", "tb_"))]
        if name == "ecc_sram_k64_bit":
            out["MEAS"] = [ln for ln in lines if ln.startswith("MEAS")]
    return out


def pct(a: int, b: int) -> str:
    return f"{100.0 * a / b:.2f} %" if b else "-"


def main() -> int:
    codes = {k: analyse(k) for k in (8, 16, 32, 64, 128)}
    bp = byte_parity_analysis(4)
    logs = collect_logs()
    reg = os.path.join(ROOT, "reports", "regression.md")
    reg_line = ""
    if os.path.exists(reg):
        m = re.search(r"\*\*(\d+) / (\d+) runs passed\.\*\*", open(reg).read())
        if m:
            reg_line = f"{m.group(1)} / {m.group(2)} regression runs passed"
    mut = os.path.join(ROOT, "reports", "mutation.md")
    mut_line = ""
    if os.path.exists(mut):
        m = re.search(r"\*\*(\d+) / (\d+) mutants killed\.\*\*", open(mut).read())
        if m:
            mut_line = f"{m.group(1)} / {m.group(2)} mutants killed"

    L = []
    L.append("# 09 — RAS coverage report (Project 26)")
    L.append("")
    L.append(f"Generated {datetime.datetime.now(datetime.timezone.utc):%Y-%m-%d %H:%M UTC} by `scripts/ras_report.py`"
             + (f" — {reg_line}" if reg_line else "") + (f", {mut_line}" if mut_line else "") + ".")
    L.append("")
    L.append("> **Scope of the numbers.** Coverage figures below are *for the implemented fault model* (bit flips in "
             "stored words, parity-covered bus fields, injected transaction failures). They are exact properties of "
             "the codes or measured in simulation. **No FIT rate, soft-error rate or field reliability is stated or "
             "implied**: that needs device, process, package and environment data (neutron/alpha flux, Qcrit, "
             "multi-cell-upset statistics, physical bit interleaving) which this project does not have.")
    L.append("")

    # ---------------- 1 capacity
    L.append("## 1. Protected and unprotected memory capacity")
    L.append("")
    L.append("Capacities are the default RTL parameters found in the audit (`docs/00_audit.md`). \"Current\" is what the "
             "existing repositories implement today; the Project 26 column is the recommended disposition. Only the "
             "DataFabric SFB2 SRAM slave has a verified drop-in replacement in this deliverable; the other SECDED "
             "integrations are specified (docs/02) but **not yet applied** to those repositories.")
    L.append("")
    L.append("| Memory | Module | Size (KiB) | Current protection | Project 26 disposition |")
    L.append("|---|---|---|---|---|")
    tot = {"secded": 0.0, "parity": 0.0, "none": 0.0}
    for name, mod, kib, cur, disp in CAPACITY:
        size = "per instance" if kib is None else (f"{kib:.3f}" if kib < 1 else f"{kib:.0f}")
        L.append(f"| {name} | {mod} | {size} | {cur} | {disp} |")
        if kib is not None:
            key = "parity" if "parity" in cur and "none" not in cur else "none"
            tot[key] += kib
    L.append("")
    allk = tot["parity"] + tot["none"]
    L.append(f"Today (audited defaults): **0 KiB SECDED-correctable**, **{tot['parity']:.0f} KiB detect-only (byte "
             f"parity)**, **{tot['none']:.1f} KiB unprotected** of {allk:.1f} KiB inventoried on-die storage.")
    L.append("")
    plan_secded = 64 + 32 + 256 + 32
    L.append(f"After the planned integrations of section 1 (IMEM, DMEM, shared SRAM, LMEM to SECDED; HPC scratchpad "
             f"to byte parity): **{plan_secded} KiB SECDED** ({100 * plan_secded / allk:.0f} %), "
             f"**64 KiB detect-only**, **{allk - plan_secded - 64:.1f} KiB unprotected** (tensor buffers, accumulators, "
             "cache data, FIFOs, RAS log). SECDED storage overhead: 7/32 = 21.9 % for (39,32), 8/64 = 12.5 % for "
             "(72,64), 9/64 = 14.1 % for the 73-bit poison-bit variant; byte parity: 12.5 %.")
    L.append("")

    # ---------------- 2 code coverage
    L.append("## 2. Error-detection coverage for the implemented fault model (exact enumeration)")
    L.append("")
    L.append("Every error pattern of the given weight in the N stored bits is enumerated (the code is linear, so the "
             "outcome does not depend on the data). *Corrected* for weight ≥ 2 means **miscorrected** (the decoder "
             "flips a third bit and reports CE): that is the silent-corruption risk of any distance-4 code.")
    L.append("")
    L.append("| Code | Overhead | 1-bit: corrected | 2-bit: detected (UE) | 3-bit: detected | 3-bit: **miscorrected** | 3-bit adjacent: miscorrected | 4-bit: **undetected** | invalid syndromes |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    for k, r in codes.items():
        w1, w2, w3 = r["w1"], r["w2"], r["w3"]
        w4 = r.get("w4")
        b3 = r["burst3"]
        L.append(f"| ({r['N']},{k}) | {r['overhead_pct']} % | {w1['corrected']}/{r['w1_total']} ({pct(w1['corrected'], r['w1_total'])}) "
                 f"| {w2['detected']}/{r['w2_total']} ({pct(w2['detected'], r['w2_total'])}) "
                 f"| {pct(w3['detected'], r['w3_total'])} | {pct(w3['corrected'], r['w3_total'])} "
                 f"| {b3['corrected']}/{sum(b3.values())} "
                 f"| {(pct(w4['undetected'], r['w4_total']) + f' ({w4['undetected']} of {r['w4_total']})') if w4 else 'not enumerated'} "
                 f"| {r['invalid_syndromes']} |")
    L.append("")
    w1, w2, w3 = bp["w1"], bp["w2"], bp["w3"]
    L.append(f"For comparison, the existing **byte parity** (36,32): 1-bit detected {pct(w1['detected'], bp['w1_total'])} "
             f"(corrected 0 %), 2-bit detected {pct(w2['detected'], bp['w2_total'])} "
             f"(the {w2['undetected']} same-byte pairs are missed), 3-bit detected {pct(w3['detected'], bp['w3_total'])}.")
    L.append("")
    L.append("**SIG poison mode ambiguity** (no extra stored bit): double errors whose syndrome equals the signature "
             "are reported as UE *and* poison (still contained — the read is answered with an error — only the "
             "classification is ambiguous):")
    L.append("")
    L.append("| Code | ambiguous double-error pairs | of all double-error pairs |")
    L.append("|---|---|---|")
    for k, r in codes.items():
        L.append(f"| ({r['N']},{k}) | {r['sig_ambiguous_doubles']} | {pct(r['sig_ambiguous_doubles'], r['w2_total'])} |")
    L.append("")
    L.append("POISON_MODE = BIT stores the poison flag as a code data bit, so poison is itself single-error-corrected "
             "and never ambiguous; it costs one stored bit per word.")
    L.append("")

    # ---------------- 3 injection results
    L.append("## 3. Error-injection results (simulation)")
    L.append("")
    L.append("Key result lines of the Icarus runs (the same tests pass on Verilator 5.020 with assertions; see "
             "`reports/regression.md`).")
    L.append("")
    for name, lines in logs["RESULT"].items():
        if not lines:
            continue
        L.append(f"**`{name}`**")
        L.append("")
        L.append("```")
        L.extend(ln for ln in lines if ln.startswith(("RESULT", "PASS", "FAIL")) or "vectors" in ln)
        L.append("```")
        L.append("")

    # ---------------- 4 scrub interference
    L.append("## 4. Scrub interference (measured)")
    L.append("")
    L.append("`tb_ecc_sram` P13, K=64 / DEPTH=64 / READ_LATENCY=1, 100 % offered functional load (one request every "
             "cycle), identical request sequence for every setting, scrub with FIX + VERIFY, starvation guard "
             "SCRUB_MAX_WAIT = 8:")
    L.append("")
    L.append("| Traffic mix | Scrub interval | Functional accepts / cycle | Scrub reads / cycle | Slowdown |")
    L.append("|---|---|---|---|---|")
    for ln in logs["MEAS"]:
        m = re.search(r"mix=(\S+) scrub_interval=(\S+) functional_accepts=\d+/\d+ cycles \(([\d.]+)/cycle\) "
                      r"scrub_reads=\d+ \(([\d.]+)/cycle\) slowdown=([\d.]+%)", ln)
        if m:
            L.append(f"| {m.group(1)} | {m.group(2)} | {m.group(3)} | {m.group(4)} | {m.group(5)} |")
    L.append("")
    L.append("A scrub CHECK costs one array cycle (no lock); only a word that needs correction costs a locked "
             "read + write-back (READ_LATENCY + DEC_PIPE + 1 cycles). Under full load the guard gives the scrubber "
             "one slot per 9 cycles (interval 0): ~9 % slowdown, an upper bound. At interval 256 the cost is "
             "< 0.5 %. Partial writes (RMW) cost READ_LATENCY + 2 cycles each with or without scrubbing — in mix "
             "rd50_wr25_rmw25 they, not the scrubber, dominate the throughput loss. Pass time = DEPTH × (interval + "
             "1) cycles at light load.")
    L.append("")

    # ---------------- 5 recovery
    L.append("## 5. Recovery behaviour")
    L.append("")
    L.append("| Fault | Detection | Immediate action | Recovery | Event (severity) |")
    L.append("|---|---|---|---|---|")
    L.extend([
        "| 1 bit in a stored word | SECDED decode on read / scrub | corrected data returned (`rsp_ce`) | scrub FIX writes the corrected word back + VERIFY; any full write also clears it | MEM_CE (INFO) |",
        "| stuck cell (hard fault) | VERIFY after write-back still in error | reads keep being corrected | none in hardware: RECOVERY event; firmware may retire / spare the region | MEM_CE + RECOVERY (WARN) |",
        "| 2 bits in a stored word | SECDED (pe = 0, s ≠ 0) | read answered with `rsp_err` + `rsp_poison`; SFB2 `rsp_error` | not correctable: word stays UE until rewritten; partial writes store it poisoned; scrub never \"fixes\" it | MEM_UE (ERROR) |",
        "| ≥ 3 bits | invalid syndrome → UE; otherwise possible miscorrection (section 2) | as above, or silently miscorrected | - | MEM_UE or (wrong) MEM_CE |",
        "| poisoned word consumed | poison flag / signature | error response | rewrite | POISON (ERROR) |",
        "| bus parity (request) | parity link checker | request not executed, local error response | master retries / aborts | BUS_PARITY (ERROR) |",
        "| bus parity (response) | parity link checker | response delivered with `rsp_error` | master retries / aborts | BUS_PARITY (ERROR) |",
        "| DMA bus error | SFB2 `rsp_error` | DMA aborts (READ_BUS / WRITE_BUS), destination not written past the fault | firmware re-programs the transfer | DMA_ERR (ERROR) |",
        "| response timeout | timeout monitor | none (passive) | escalate per policy; a hung slave needs reset / isolation | TIMEOUT (ERROR) |",
        "| watchdog | counter | stage 1: interrupt; stage 2: `wdog_reset_req_o` | reset | WDOG (ERROR / FATAL) |",
        "| over-temperature | sensor thresholds | warning: interrupt; fatal: `therm_shutdown_o` in hardware, `contain_o` | cool-down below threshold − hysteresis; fatal latched until W1C (or reset with FATAL_LOCK) | THERM_WARN (WARN) / THERM_FATAL (FATAL) |",
        "| illegal control operation | register file / external ports | write refused (`rb_err`) | none needed | ILLEGAL_OP (WARN) |",
    ])
    L.append("")
    L.append("Fatal propagation: any FATAL event sets STATUS.SEEN_FATAL → `fatal_o`, `cc_fatal_o` (existing cc_ras "
             "EXT_FATAL input), `contain_o` (if CTRL.FATAL_CONTAIN), `irq_host_o` (default enable). With "
             "CTRL.FATAL_LOCK set it can only be cleared by reset (verified, tb_ras_system T13/T15).")
    L.append("")

    # ---------------- 6 SPOF
    L.append("## 6. Remaining single points of failure and uncovered faults")
    L.append("")
    L.extend([
        "1. **Unprotected storage** (section 1): tensor operand/output buffers, tensor accumulators (flip-flops), the "
        "ControlCore D-cache data and tags, DMA FIFOs, command queues, register files of ControlCore/vector lanes, "
        "the RAS event log itself. A flip there is silent.",
        "2. **SFB2 data path outside parity links**: SFB2 has no end-to-end protection. A response corrupted between "
        "the parity checker and the master is delivered as good data — demonstrated, not hidden (tb_ras_system T10). "
        "Parity links cover only the segments where they are instantiated; the crossbar, routers and NoC have no "
        "parity/CRC.",
        "3. **Encoder / decoder logic**: a fault in the ECC logic itself (e.g. a stuck XOR output) is not "
        "self-checked. The write path encodes and the read path decodes with separate instances but there is no "
        "duplicate-and-compare or encoder self-check.",
        "4. **Address-decoder faults** of a macro (reading the right data from the wrong row) produce a valid "
        "codeword and are not detected: the code does not include the address. Option: fold the word address into "
        "the check bits (address-in-ECC); not implemented.",
        "5. **Multi-bit upsets in one word** (≥ 3 bits): may miscorrect (section 2). Physical column interleaving in "
        "the macro (bits of one word far apart) is the mitigation and is a macro/floorplan decision outside this RTL.",
        "6. **SIG poison mode**: a poisoned word hit by one more upset can decode as a (wrong) CE; and a few genuine "
        "double errors read as poison (section 2). POISON_MODE = BIT avoids both.",
        "7. **RAS controller itself**: counters, log, status and the watchdog/thermal registers are not protected; a "
        "fault there can lose or corrupt diagnostics (not data). The fatal path (`therm_shutdown_o`, "
        "`wdog_reset_req_o`) is single-rail.",
        "8. **Clock / reset / power faults** are outside the fault model (no clock monitor, no reset-glitch detection).",
        "9. **Timeouts are reported, not recovered**: a hung SFB2 slave keeps its master blocked (SFB2 has no abort).",
        "10. **Write-ack of posted writes**: with WRITE_ACK = 0 an RMW error is only visible as an event.",
    ])
    L.append("")
    with open(os.path.join(ROOT, "docs", "09_ras_coverage_report.md"), "w") as f:
        f.write("\n".join(L) + "\n")
    with open(os.path.join(ROOT, "reports", "ras_coverage.json"), "w") as f:
        json.dump({"codes": codes, "byte_parity": bp, "capacity": CAPACITY}, f, indent=1)
    print("wrote docs/09_ras_coverage_report.md, reports/ras_coverage.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
