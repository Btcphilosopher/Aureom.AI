#!/usr/bin/env bash
# Verilator -Wall lint of every synthesizable RAS module in several configurations.
# Exit status != 0 on any warning.  Output: reports/lint.md
set -uo pipefail
cd "$(dirname "$0")/.."
SL=third_party/silicaflux-sramlib/rtl/mem
INC="-Irtl -I$SL -I$SL/backends/asic"
MEMF="rtl/sfras_secded_enc.sv rtl/sfras_secded_dec.sv $SL/backends/generic/sram_generic_1rw.sv $SL/backends/fpga/sram_fpga_1rw.sv $SL/backends/asic/sram_asic_array.sv $SL/backends/asic/sram_leaf_sky130.sv $SL/backends/asic/sram_leaf_gf180.sv $SL/backends/asic/sram_leaf_ihp1p.sv $SL/backends/asic/sram_leaf_ihp2p.sv $SL/backends/asic/stubs/sram_macro_blackboxes.sv $SL/sram_backend_1rw.sv rtl/sfras_ecc_sram.sv"
RASF="rtl/sfras_event_ctrl.sv rtl/sfras_watchdog.sv rtl/sfras_thermal_mon.sv rtl/sfras_scrub.sv rtl/sfras_fi_ctrl.sv rtl/silicaflux_ras.sv"
fail=0
out=reports/lint.md
mkdir -p reports
{
echo "# Lint (Verilator 5.020 \`--lint-only -Wall\`)"
echo
echo "| Top | Parameters | Result |"
echo "|---|---|---|"
} > $out
run() {   # top params files...
  local top=$1 params=$2; shift 2
  local log
  log=$(verilator --lint-only -Wall -Wno-DECLFILENAME $INC --top-module $top $params "$@" 2>&1)
  if [ -z "$log" ]; then echo "| \`$top\` | \`${params:-defaults}\` | clean |" >> $out; echo "clean  $top $params";
  else echo "| \`$top\` | \`${params:-defaults}\` | **warnings** |" >> $out; echo "WARN   $top $params"; echo "$log" | head -20; fail=1; fi
}
for K in 1 8 32 64 128 132; do run sfras_secded_dec "-GK=$K -GINV=3" rtl/sfras_secded_enc.sv rtl/sfras_secded_dec.sv; done
run sfras_ecc_sram "-GFI_EN=1" $MEMF
run sfras_ecc_sram "-GFI_EN=0 -GDEC_PIPE=1 -GREAD_LATENCY=2" $MEMF
run sfras_ecc_sram "-GPOISON_MODE=1 -GK=32 -GDEPTH=100" $MEMF
run sfras_ecc_sram "-GPOISON_MODE=0 -GBYTE_EN=0 -GWRITE_ACK=0" $MEMF
run sfras_ecc_sram "-GK=128 -GREAD_LATENCY=3 -GFI_EN=1" $MEMF
run sfras_scrub "" rtl/sfras_scrub.sv
run sfras_event_ctrl "-GNP=17" rtl/sfras_event_ctrl.sv
run sfras_event_ctrl "-GNP=1 -GLOG_DEPTH=2 -GCNT_W=4" rtl/sfras_event_ctrl.sv
run silicaflux_ras "" $RASF
run silicaflux_ras "-GNMEM=1 -GNEXT=1 -GNBUS=1 -GFI_EN=0" $RASF
run silicaflux_ras "-GNMEM=8 -GNEXT=5 -GNBUS=8 -GMEM_NW=256" $RASF
run sfras_sfb_ecc_slave "-GFI_EN=1" $MEMF rtl/sfras_sfb_ecc_slave.sv
run sfras_sfb_par_link "" rtl/sfras_bus_parity.sv
run sfras_sfb_fault_inj "" rtl/sfras_sfb_fault_inj.sv
run sfras_dma_mon "" rtl/sfras_dma_mon.sv
run sfras_timeout_mon "" rtl/sfras_timeout_mon.sv
run sfras_watchdog "" rtl/sfras_watchdog.sv
run sfras_thermal_mon "" rtl/sfras_thermal_mon.sv
exit $fail
