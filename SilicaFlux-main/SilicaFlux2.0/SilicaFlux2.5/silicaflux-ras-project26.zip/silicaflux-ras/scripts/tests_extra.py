# Additional regression tests (loaded by scripts/run_regress.py).
# Globals available: MEM, RAS, SFB, CODEC, SRAMLIB_FILES
EXTRA_TESTS = []

def _ecc(name, **p):
    EXTRA_TESTS.append(dict(name=f"ecc_sram_{name}", top="tb_ecc_sram", files=MEM + ["tb/tb_ecc_sram.sv"],
                            params=p, defines=["SRAMLIB_POISON"], pass_tag="PASS tb_ecc_sram"))

_ecc("k64_bit")                                                     # (73,65): 64 data + poison bit
_ecc("k64_sig", POISON_MODE=1)                                      # (72,64)
_ecc("k64_none_lat2_pipe", POISON_MODE=0, READ_LATENCY=2, DEC_PIPE=1)
_ecc("k32_sig_np2", K=32, POISON_MODE=1, DEPTH=100, SEED=7)         # (39,32), non-power-of-two depth
_ecc("k32_word_only", K=32, BYTE_EN=0, POISON_MODE=1, UE_ZERO=1, SEED=3)
_ecc("k128_bit_lat3", K=128, READ_LATENCY=3, DEPTH=32, SEED=11)

EXTRA_TESTS.append(dict(name="event_ctrl", top="tb_event_ctrl", files=["rtl/sfras_event_ctrl.sv", "tb/tb_event_ctrl.sv"],
                        params={}, pass_tag="PASS tb_event_ctrl"))

_SYS = CODEC + SRAMLIB_FILES + ["rtl/sfras_ecc_sram.sv"] + RAS + SFB + DMA_FILES + ["tb/tb_ras_system.sv"]
EXTRA_TESTS.append(dict(name="ras_system", top="tb_ras_system", files=_SYS, params={},
                        defines=["SRAMLIB_POISON"], pass_tag="PASS tb_ras_system"))
EXTRA_TESTS.append(dict(name="ras_system_prod", top="tb_ras_system", files=_SYS, params={"PROD": 1},
                        defines=["SRAMLIB_POISON"], pass_tag="PASS tb_ras_system"))

# firmware driver (unmodified C) co-simulated with the Verilated RTL
EXTRA_TESTS.append(dict(name="sw_cosim", top="-", files=[], cmd=["bash", "scripts/run_cosim.sh"],
                        sims=["verilator"], pass_tag="PASS sw_cosim"))
