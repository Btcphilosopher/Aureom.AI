#!/usr/bin/env bash
# Firmware driver (sw/silicaflux_ras.c, unmodified) co-simulated with the
# Verilated silicaflux_ras (MEM_AW = 16 so memory addresses pack in 16-bit lanes).
set -euo pipefail
cd "$(dirname "$0")/.."
rm -rf build/cosim
verilator --cc --exe --build -j 4 -Wno-fatal -Wno-lint -Wno-style --assert -DSFRAS_ASSERT \
  -Irtl --top-module silicaflux_ras -Mdir build/cosim -o cosim -GMEM_AW=16 \
  -CFLAGS "-DSFRAS_ENABLE_FI -I$PWD/sw -I$PWD/tb -Wall" \
  rtl/sfras_event_ctrl.sv rtl/sfras_watchdog.sv rtl/sfras_thermal_mon.sv rtl/sfras_scrub.sv rtl/sfras_fi_ctrl.sv \
  rtl/silicaflux_ras.sv "$PWD/tb/sw_cosim.cpp" "$PWD/tb/sw_cosim_driver.cpp" > build/cosim_build.log 2>&1
./build/cosim/cosim
