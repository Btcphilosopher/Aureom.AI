#!/usr/bin/env python3
"""SilicaFlux RAS (Project 26) regression runner.

usage: scripts/run_regress.py [--sim icarus|verilator|both] [--only SUBSTR] [--jobs N]

Runs every test in TESTS on the selected simulator(s), stores logs under
build/logs/, and writes reports/regression.md (pass/fail table + the key
result lines each test prints).  Exit status 0 only if every test passed.
A test passes only if its log contains the line 'PASS <name>' and no line
starting with 'FAIL' / '%Error' / 'ERROR'.
"""

from __future__ import annotations

import argparse
import concurrent.futures as cf
import datetime
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.path.join(ROOT, "build")
VEC = os.path.join(BUILD, "vectors")

SRAMLIB = "third_party/silicaflux-sramlib/rtl/mem"
SRAMLIB_FILES = [
    f"{SRAMLIB}/backends/generic/sram_generic_1rw.sv",
    f"{SRAMLIB}/backends/fpga/sram_fpga_1rw.sv",
    f"{SRAMLIB}/backends/asic/sram_asic_array.sv",
    f"{SRAMLIB}/backends/asic/sram_leaf_sky130.sv",
    f"{SRAMLIB}/backends/asic/sram_leaf_gf180.sv",
    f"{SRAMLIB}/backends/asic/sram_leaf_ihp1p.sv",
    f"{SRAMLIB}/backends/asic/sram_leaf_ihp2p.sv",
    f"{SRAMLIB}/backends/asic/stubs/sram_macro_blackboxes.sv",
    f"{SRAMLIB}/sram_backend_1rw.sv",
]
DMA_DIR = "third_party/silicaflux-datafabric/rtl/dma"
DMA_FILES = [f"{DMA_DIR}/{f}.sv" for f in ("dma_fifo", "dma_validate", "dma_irq", "dma_control_regs",
                                           "dma_transfer_engine", "dma_burst_engine", "silicaflux_dma")]
INCDIRS = ["rtl", SRAMLIB, f"{SRAMLIB}/backends/asic", DMA_DIR, "tb"]
CODEC = ["rtl/sfras_secded_enc.sv", "rtl/sfras_secded_dec.sv"]
MEM = CODEC + SRAMLIB_FILES + ["rtl/sfras_ecc_sram.sv", "rtl/sfras_scrub.sv"]
RAS = ["rtl/sfras_event_ctrl.sv", "rtl/sfras_watchdog.sv", "rtl/sfras_thermal_mon.sv", "rtl/sfras_scrub.sv",
       "rtl/sfras_fi_ctrl.sv", "rtl/silicaflux_ras.sv"]
SFB = ["rtl/sfras_sfb_ecc_slave.sv", "rtl/sfras_sfb_fault_inj.sv", "rtl/sfras_bus_parity.sv",
       "rtl/sfras_timeout_mon.sv", "rtl/sfras_dma_mon.sv"]

TESTS: list[dict] = []

# ---------------------------------------------------------------- codec
for k, inv_tag in [(8, "d"), (8, "0"), (11, "d"), (16, "d"), (32, "d"), (32, "0"),
                   (57, "d"), (64, "d"), (64, "0"), (128, "d")]:
    vec = f"secded_k{k}_inv{inv_tag}.vec"
    TESTS.append(dict(
        name=f"secded_k{k}_inv{inv_tag}", top="tb_secded", files=CODEC + ["tb/tb_secded.sv"],
        params={"K": k}, inv_from_vec=vec,
        plusargs=[f"+VEC={os.path.join(VEC, vec)}", f"+INVD={1 if inv_tag == 'd' else 0}"],
        pass_tag="PASS tb_secded"))

# ---------------------------------------------------------------- later stages register here
EXTRA = os.path.join(ROOT, "scripts", "tests_extra.py")
if os.path.exists(EXTRA):
    ns: dict = {"MEM": MEM, "RAS": RAS, "SFB": SFB, "CODEC": CODEC, "SRAMLIB_FILES": SRAMLIB_FILES,
                "DMA_FILES": DMA_FILES}
    exec(compile(open(EXTRA).read(), EXTRA, "exec"), ns)
    TESTS.extend(ns["EXTRA_TESTS"])


def inv_of(vecfile: str) -> int:
    with open(os.path.join(VEC, vecfile)) as f:
        hdr = f.readline().split()
    return int(hdr[5])


def run(cmd: list[str], log, cwd=ROOT, timeout=3600) -> int:
    log.write("$ " + " ".join(cmd) + "\n")
    log.flush()
    p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                       timeout=timeout)
    log.write(p.stdout)
    log.flush()
    return p.returncode


IVL_NOISE = re.compile(r"(no explicit time unit|time precision|Affected design elements|declared here)")


def run_test(t: dict, sim: str) -> tuple[str, str, bool, list[str]]:
    name = t["name"]
    if "cmd" in t:                                   # self-contained script (e.g. firmware co-simulation)
        logpath = os.path.join(BUILD, "logs", f"{name}.{sim}.log")
        os.makedirs(os.path.dirname(logpath), exist_ok=True)
        p = subprocess.run(t["cmd"], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        open(logpath, "w").write(p.stdout)
        lines = p.stdout.splitlines()
        ok = p.returncode == 0 and any(ln.startswith(t["pass_tag"]) for ln in lines) and \
            not any(ln.startswith("FAIL") for ln in lines)
        return name, sim, ok, [ln for ln in lines if ln.startswith(("PASS", "FAIL", "RESULT"))]
    params = dict(t.get("params", {}))
    if "inv_from_vec" in t:
        params["INV"] = inv_of(t["inv_from_vec"])
    logdir = os.path.join(BUILD, "logs")
    os.makedirs(logdir, exist_ok=True)
    logpath = os.path.join(logdir, f"{name}.{sim}.log")
    defines = t.get("defines", [])
    with open(logpath, "w") as log:
        if sim == "icarus":
            exe = os.path.join(BUILD, "sim", f"{name}.vvp")
            os.makedirs(os.path.dirname(exe), exist_ok=True)
            cmd = ["iverilog", "-g2012", "-o", exe, "-s", t["top"]]
            cmd += [f"-I{d}" for d in INCDIRS]
            cmd += [f"-D{d}" for d in defines]
            cmd += [f"-P{t['top']}.{k}={v}" for k, v in params.items()]
            cmd += t["files"]
            rc = run(cmd, log)
            if rc == 0:
                rc = run(["vvp", "-n", exe] + t.get("plusargs", []), log)
        else:
            mdir = os.path.join(BUILD, "vl", name)
            os.makedirs(mdir, exist_ok=True)
            # -O0: Verilator 5.020 --timing miscompiles module-scope testbench counters
            # that are updated across '#' delays in an initial block (value lost at
            # the end of the block; reproduced in tb_secded, fixed by -O0 or by
            # making the variable public).  Testbench speed is not a concern here.
            cmd = ["verilator", "--binary", "--timing", "-O0", "-j", "2", "-Wno-fatal", "-Wno-lint", "-Wno-style",
                   "--assert", "-DSFRAS_ASSERT", "--top-module", t["top"], "-Mdir", mdir, "-o", "sim"]
            cmd += [f"-I{d}" for d in INCDIRS]
            cmd += [f"-D{d}" for d in defines]
            cmd += [f"-G{k}={v}" for k, v in params.items()]
            cmd += t["files"]
            rc = run(cmd, log)
            if rc == 0:
                rc = run([os.path.join(mdir, "sim")] + t.get("plusargs", []), log)
    text = open(logpath).read()
    lines = [ln for ln in text.splitlines() if not IVL_NOISE.search(ln)]
    bad = [ln for ln in lines if ln.startswith(("FAIL", "%Error", "ERROR", "ASSERT")) or "Assertion failed" in ln
           or ln.startswith("%Warning-") and "lint" not in ln.lower() and False]
    ok = (rc == 0) and any(ln.startswith(t["pass_tag"]) for ln in lines) and not bad
    keep = [ln for ln in lines if ln.startswith(("PASS", "FAIL", "  ", "RESULT", "tb_", "MEAS", "COV"))]
    return name, sim, ok, keep[:80]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--sim", default="both", choices=["icarus", "verilator", "both"])
    ap.add_argument("--only", default="")
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    ap.add_argument("--no-report", action="store_true")
    a = ap.parse_args()

    # reference vectors first (independent model)
    subprocess.run([sys.executable, "-I", os.path.join(ROOT, "model", "gen_secded_vectors.py"), VEC],
                   check=True, cwd=ROOT, stdout=subprocess.DEVNULL)
    sims = ["icarus", "verilator"] if a.sim == "both" else [a.sim]
    jobs = [(t, s) for t in TESTS for s in sims if a.only in t["name"] and s in t.get("sims", sims)]
    results = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for name, sim, ok, keep in ex.map(lambda ts: run_test(*ts), jobs):
            print(f"{'PASS' if ok else 'FAIL'}  {sim:9s} {name}")
            results.append((name, sim, ok, keep))
    n_fail = sum(1 for r in results if not r[2])
    if not a.no_report and not a.only:
        os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
        with open(os.path.join(ROOT, "reports", "regression.md"), "w") as f:
            f.write("# SilicaFlux RAS (Project 26) -- regression results\n\n")
            f.write(f"Generated {datetime.datetime.now(datetime.timezone.utc):%Y-%m-%d %H:%M UTC} by "
                    "`scripts/run_regress.py`.  Tools: Icarus Verilog 12.0, Verilator 5.020 "
                    "(`--assert -DSFRAS_ASSERT`).\n\n")
            f.write(f"**{len(results) - n_fail} / {len(results)} runs passed.**\n\n")
            f.write("| Test | Simulator | Result |\n|---|---|---|\n")
            for name, sim, ok, _ in sorted(results):
                f.write(f"| `{name}` | {sim} | {'PASS' if ok else '**FAIL**'} |\n")
            f.write("\n## Key result lines (first simulator of each test)\n\n")
            first_sim = {}
            for name, sim, ok, keep in sorted(results, key=lambda r: (r[0], r[1] != sims[0])):
                first_sim.setdefault(name, sim)
            for name, sim, ok, keep in sorted(results):
                if sim != first_sim[name]:
                    continue
                f.write(f"### `{name}`\n\n```\n" + "\n".join(keep) + "\n```\n\n")
    print(f"{len(results) - n_fail}/{len(results)} passed")
    return 1 if n_fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
