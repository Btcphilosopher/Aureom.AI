#!/usr/bin/env python3
"""Mutation check: are the tests able to see real bugs?

usage: scripts/run_mutation.py [--jobs N]   -> reports/mutation.md

Each mutant is one deliberate RTL defect (a single text substitution).  The
tree is copied to build/mut/<id>/, the mutant applied, and the listed tests
are run on Icarus.  A mutant is KILLED if at least one of them fails.  The
script itself fails if a mutant survives or does not apply.
"""

from __future__ import annotations

import argparse
import concurrent.futures as cf
import datetime
import os
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

MUTANTS = [
    ("M01", "rtl/sfras_secded_dec.sv", "assign data_o    = d_rx ^ hit[K-1:0];", "assign data_o    = d_rx;",
     "decoder does not correct data bits", ["secded_k64_invd"]),
    ("M02", "rtl/sfras_secded_dec.sv", "wire s_valid = ({1'b0, s} <= (R+1)'(K + R));", "wire s_valid = 1'b1;",
     "invalid syndromes treated as correctable", ["secded_k64_invd"]),
    ("M03", "rtl/sfras_secded_enc.sv", "wire par = (^data_i) ^ (^chk);", "wire par = ~((^data_i) ^ (^chk));",
     "overall parity of the wrong sense", ["secded_k8_invd"]),
    ("M04", "rtl/sfras_secded_dec.sv", "assign ue_o       = !s_zero && (!pe || !s_valid);", "assign ue_o       = !s_zero && !pe;",
     "invalid syndrome not flagged uncorrectable", ["secded_k64_invd"]),
    ("M05", "rtl/sfras_ecc_sram.sv", ": d_data[l*(K/MW) +: (K/MW)];", ": dec_raw[l*(K/MW) +: (K/MW)];",
     "RMW merges the uncorrected old bytes", ["ecc_sram_k64_bit"]),
    ("M06", "rtl/sfras_ecc_sram.sv", "wire can_op  = rst_live_q && !t_req && !init_q && !init_pend_q && !lock_q && !wb_q;",
     "wire can_op  = rst_live_q && !t_req && !init_q && !init_pend_q && !wb_q;",
     "port not locked during read-modify-write", ["ecc_sram_k64_bit"]),
    ("M07", "rtl/sfras_ecc_sram.sv", "assign enc_m_in = {d_bad, merged};", "assign enc_m_in = {1'b0, merged};",
     "RMW onto an uncorrectable word not poisoned", ["ecc_sram_k64_bit"]),
    ("M08", "rtl/sfras_ecc_sram.sv", "          push_err   = d_bad;", "          push_err   = 1'b0;",
     "uncorrectable read answered without error", ["ecc_sram_k64_bit"]),
    ("M09", "rtl/sfras_ecc_sram.sv", "if (d_ce) begin wb_set = 1'b1; wb_cw_d = d_cwc; end", "if (1'b0) begin wb_set = 1'b1; wb_cw_d = d_cwc; end",
     "scrub FIX does not write back", ["ecc_sram_k64_bit"]),
    ("M10", "rtl/sfras_ecc_sram.sv", "if (fi_arm_i && !fi_armed_q && !fi_use_q) begin", "if (fi_arm_i && !fi_armed_q) begin",
     "re-arm while an injection mask is still in use (bug found during development)", ["ecc_sram_k128_bit_lat3", "ecc_sram_k64_none_lat2_pipe"]),
    ("M11", "rtl/sfras_scrub.sv", "wire go_stop = (r_chk || r_fix) && scr_rsp_ue && stop_on_ue;", "wire go_stop = 1'b0;",
     "scrub ignores the UE stop policy", ["ecc_sram_k64_bit"]),
    ("M12", "rtl/sfras_event_ctrl.sv", "sat_add = s[CNT_W] ? {1'b1, {CNT_W{1'b1}}} : {(b != '0 && a == '1), s[CNT_W-1:0]};",
     "sat_add = {1'b0, s[CNT_W-1:0]};", "counters wrap instead of saturating", ["event_ctrl"]),
    ("M13", "rtl/sfras_event_ctrl.sv", "max2 = (a > b) ? a : b;", "max2 = b;",
     "software can downgrade severity", ["event_ctrl"]),
    ("M14", "rtl/sfras_event_ctrl.sv", "for (int p = 0; p < NP; p++) n_lost = n_lost + LCW'(lost_in[p]);",
     "for (int p = 0; p < NP; p++) n_lost = n_lost;", "lost events not counted", ["event_ctrl"]),
    ("M15", "rtl/sfras_fi_ctrl.sv", "wire  perm = allow_i && !lock_i;", "wire  perm = 1'b1;",
     "fault injection ignores the hardware permission and FI_LOCK", ["ras_system"]),
    ("M16", "rtl/silicaflux_ras.sv", "assign contain_o  = fatal_o && ctrl_q[`SFRAS_CTRL_FATAL_CONTAIN_LSB];", "assign contain_o  = 1'b0;",
     "fatal error does not assert containment", ["ras_system"]),
    ("M17", "rtl/sfras_bus_parity.sv", "assign s_req_valid = m_req_valid && !q_err && !loc_q;", "assign s_req_valid = m_req_valid && !loc_q;",
     "request with bad parity forwarded to the slave", ["ras_system"]),
    ("M18", "rtl/silicaflux_ras.sv", "wire th_clamp    = w_thfatal && (rb_wdata[THERM_W-1:0] > THERM_FATAL_MAX || rb_wdata[31:THERM_W] != '0);",
     "wire th_clamp    = 1'b0;", "fatal thermal threshold not clamped", ["ras_system"]),
    ("M19", "rtl/sfras_event_ctrl.sv", "`SFRAS_EV_WDOG:        hw_min_sev = stage2 ? `SFRAS_SEV_FATAL : `SFRAS_SEV_ERROR;",
     "`SFRAS_EV_WDOG:        hw_min_sev = `SFRAS_SEV_ERROR;", "watchdog stage 2 not fatal", ["ras_system"]),
    ("M20", "rtl/sfras_dma_mon.sv", "if (req_valid && req_ready) begin addr_q <= req_addr; wr_q <= req_write; end",
     "if (req_valid && req_ready) begin addr_q <= '0; wr_q <= req_write; end", "DMA error reported at the wrong address", ["ras_system"]),
    ("M21", "rtl/sfras_ecc_sram.sv", "localparam int INV = (INV_SEL < 0) ? sfras_ecc_default_inv(KC) : INV_SEL;", "localparam int INV = 0;",
     "check-bit inversion dropped (all-zero word would read as valid)", ["ecc_sram_k64_bit"]),
    ("M22", "rtl/sfras_ecc_sram.sv", "wire init_start = init_req_i || (REINIT_AFTER_TEST != 0 && t_own_q && !t_req);",
     "wire init_start = init_req_i;",
     "memory not re-initialised after MBIST", ["ecc_sram_k64_bit"]),
]


def run_mutant(m) -> tuple[str, str, bool, str]:
    mid, path, old, new, desc, tests = m
    d = os.path.join(ROOT, "build", "mut", mid)
    if os.path.exists(d):
        shutil.rmtree(d)
    for sub in ("rtl", "tb", "model", "scripts", "third_party"):
        shutil.copytree(os.path.join(ROOT, sub), os.path.join(d, sub))
    f = os.path.join(d, path)
    src = open(f).read()
    if src.count(old) != 1:
        return mid, desc, False, f"mutation does not apply ({src.count(old)} matches)"
    open(f, "w").write(src.replace(old, new))
    failed = []
    for t in tests:
        p = subprocess.run([sys.executable, "-I", os.path.join(d, "scripts", "run_regress.py"), "--sim", "icarus",
                            "--only", t, "--no-report", "--jobs", "1"], cwd=d, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, text=True, timeout=3600)
        if p.returncode != 0:
            failed.append(t)
    killed = bool(failed)
    shutil.rmtree(d, ignore_errors=True)
    return mid, desc, killed, ("killed by " + ", ".join(failed)) if killed else "SURVIVED (" + ", ".join(tests) + " passed)"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    a = ap.parse_args()
    results = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for r in ex.map(run_mutant, MUTANTS):
            print(f"{r[0]} {'KILLED  ' if r[2] else 'SURVIVED'} {r[1]} -- {r[3]}")
            results.append(r)
    killed = sum(1 for r in results if r[2])
    with open(os.path.join(ROOT, "reports", "mutation.md"), "w") as f:
        f.write("# Mutation check\n\n")
        f.write(f"Generated {datetime.datetime.now(datetime.timezone.utc):%Y-%m-%d %H:%M UTC} by "
                "`scripts/run_mutation.py` (Icarus).  Each mutant is one deliberate RTL defect; it is killed when "
                "at least one listed test fails.\n\n")
        f.write(f"**{killed} / {len(results)} mutants killed.**\n\n| Id | File | Defect | Result |\n|---|---|---|---|\n")
        for (mid, desc, k, note), m in zip(results, MUTANTS):
            f.write(f"| {mid} | `{m[1]}` | {desc} | {'killed' if k else '**SURVIVED**'}: {note} |\n")
    print(f"{killed}/{len(results)} killed")
    return 0 if killed == len(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
