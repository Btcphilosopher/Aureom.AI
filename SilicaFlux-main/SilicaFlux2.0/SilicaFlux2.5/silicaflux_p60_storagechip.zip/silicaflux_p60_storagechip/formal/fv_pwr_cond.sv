// Formal harness for sfx_pwr_cond: the conditioned power-fail output changes only after the (synchronised) input has differed from it for FILTER consecutive
// cycles, and an input glitch shorter than FILTER cycles never changes it.  FILTER = 4 (module parameter default of the top).
`default_nettype none
module fv_pwr_cond (input wire clk);
  localparam int FILTER = 4;
  (* anyseq *) wire pwr_fail_n_i;
  reg rst_n = 1'b0; always @(posedge clk) rst_n <= 1'b1;
  wire pwr_fail_n_o, pf_event;
  sfx_pwr_cond #(.FILTER(FILTER)) dut (.clk, .rst_n, .pwr_fail_n_i, .pwr_fail_n_o, .pf_event);
  reg [FILTER+4:0] h = {(FILTER+5){1'b1}};                      // h[k] = input value k+1 cycles ago
  always @(posedge clk) h <= {h[FILTER+3:0], pwr_fail_n_i};
  reg prev_o = 1'b1; always @(posedge clk) prev_o <= pwr_fail_n_o;
  reg past_valid = 1'b0; always @(posedge clk) past_valid <= 1'b1;
  always @(*) if (rst_n && past_valid) begin
    // output fell: the input must have been low for the FILTER cycles that precede the two synchroniser stages
    if (prev_o && !pwr_fail_n_o) assert(h[FILTER+1:2] == {FILTER{1'b0}});
    // output rose: the input must have been high for the same span
    if (!prev_o && pwr_fail_n_o) assert(h[FILTER+1:2] == {FILTER{1'b1}});
    // pf_event is a one-cycle pulse that coincides with the fall
    if (pf_event) assert(!pwr_fail_n_o);
  end
  always @(*) cover(rst_n && !pwr_fail_n_o);
endmodule
