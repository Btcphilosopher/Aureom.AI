// Formal harness for sfx_hb_split (SFB2 host-BAR splitter).  Proves, for all behaviours of a host that obeys SFB2 (request held until
// accepted) and of downstream blocks that respond only to accepted requests:
//   P1 at most one transaction outstanding; a response is only produced for an accepted request
//   P2 the SoC port and the local window are never active together
//   P3 routing: addresses with [31:28] == 0xC never reach the SoC; all others never reach the local window
//   P4 an accepted request is answered exactly once (no lost / duplicated response), and the request stays held on the SoC side until accepted
//   P5 the local window request is stable while pending (registered capture)
`default_nettype none
module fv_hb_split (input wire clk);
  (* anyseq *) wire        s_req_valid, s_req_write, s_rsp_ready, m_req_ready, m_rsp_valid, m_rsp_error, l_done, l_err;
  (* anyseq *) wire [31:0] s_req_addr, s_req_wdata, m_rsp_rdata, l_rdata;
  (* anyseq *) wire [3:0]  s_req_wstrb;
  reg rst_n = 1'b0;
  always @(posedge clk) rst_n <= 1'b1;
  wire s_req_ready, s_rsp_valid, s_rsp_error, m_req_valid, m_req_write, m_rsp_ready, l_req, l_we;
  wire [31:0] s_rsp_rdata, m_req_addr, m_req_wdata, l_wdata; wire [3:0] m_req_wstrb; wire [15:0] l_addr;
  sfx_hb_split dut (.clk, .rst_n, .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error, .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error, .l_req, .l_we, .l_addr, .l_wdata, .l_done, .l_rdata, .l_err);
  reg [15:0] la; reg lacc = 1'b0;
  // ---- environment assumptions
  reg past_valid = 1'b0; always @(posedge clk) past_valid <= 1'b1;
  reg pv_req = 1'b0; reg [31:0] pv_addr; reg pv_w; reg [31:0] pv_d;
  always @(posedge clk) begin pv_req <= s_req_valid && !s_req_ready; pv_addr <= s_req_addr; pv_w <= s_req_write; pv_d <= s_req_wdata; end
  always @(*) if (rst_n && past_valid) begin
    if (pv_req) begin assume(s_req_valid); assume(s_req_addr == pv_addr); assume(s_req_write == pv_w); assume(s_req_wdata == pv_d); end   // SFB2: held until accepted
  end
  // downstream: respond only after acceptance (SoC), local done only while the request is active
  reg soc_pend = 1'b0, loc_pend = 1'b0;
  always @(posedge clk) begin
    if (!rst_n) begin soc_pend <= 1'b0; end
    else begin
      if (m_req_valid && m_req_ready) soc_pend <= 1'b1;
      else if (m_rsp_valid && m_rsp_ready) soc_pend <= 1'b0;
    end
  end
  always @(*) if (rst_n) begin
    if (!soc_pend) assume(!m_rsp_valid);
    if (!l_req) assume(!l_done);
  end
  // ---- properties
  reg outstanding = 1'b0;                                  // transaction accepted from the host and not yet answered
  always @(posedge clk) begin
    if (!rst_n) outstanding <= 1'b0;
    else begin
      if (s_req_valid && s_req_ready) outstanding <= 1'b1;
      if (s_rsp_valid && s_rsp_ready) outstanding <= 1'b0;
    end
  end
  always @(*) if (rst_n) begin
    if (outstanding) assert(!s_req_ready);                                                       // P1
    if (s_rsp_valid) assert(outstanding);                                                        // P1
    assert(!(m_req_valid && l_req));                                                             // P2
    if (m_req_valid) assert(s_req_addr[31:28] != 4'hC);                                          // P3
    if (m_req_valid) assert(s_req_valid && m_req_addr == s_req_addr && m_req_wdata == s_req_wdata && m_req_write == s_req_write); // pass-through
  end
  always @(posedge clk) begin
    if (s_req_valid && s_req_ready && s_req_addr[31:28] == 4'hC) begin la <= s_req_addr[15:0]; lacc <= 1'b1; end
    if (s_rsp_valid && s_rsp_ready) lacc <= 1'b0;
    if (rst_n && l_req) begin assert(lacc); assert(l_addr == la); end                            // P3/P5: local access uses the captured address of an accepted local request
    if (rst_n && s_req_valid && s_req_ready && s_req_addr[31:28] == 4'hC) assert(!m_req_valid);  // P3: a local request never reaches the SoC
  end
  // P4: a response is delivered when the downstream responds (SoC) / done (local): cover that responses really occur
  always @(*) begin cover(rst_n && s_rsp_valid && s_rsp_ready && !s_rsp_error); end
endmodule
