#!/bin/bash
# =============================================================================
# SilicaFlux-STORE P60 -- block-level physical design (OPEN-SOURCE flow, sky130hd, typical corner only)
#   Block: sfx_page_engine (BCH t=8 ECC engine from P54 + XTS-AES core + SFB2 pump, ~ the P60 datapath)
#   Steps: Yosys (sky130hd liberty mapping) -> OpenROAD: floorplan, I/O placement, power grid, global/detailed placement,
#          clock tree (TritonCTS), global + detailed routing -> OpenSTA parasitics-estimated timing, power, area.
#   NOT signoff: no DRC/LVS, one PVT corner, no extraction signoff, SRAM macros absent, placeholder constraints.
# usage: run_block_pd.sh [clock_period_ns=15] [utilization=40] [detailed-route iteration cap=6]
# env  : OPENROAD (path to the openroad binary; default: $(command -v openroad)), YOSYS
# =============================================================================
set -e
HERE=$(cd "$(dirname "$0")" && pwd); P60=$(cd "$HERE/.." && pwd)
PERIOD=${1:-15}; UTIL=${2:-40}; DROUTE_ITERS=${3:-6}
OR=${OPENROAD:-$(command -v openroad || true)}; YOS=${YOSYS:-yosys}
[ -x "$OR" ] || { echo "openroad not found (set OPENROAD=...; see docs/09_PHYSICAL_DESIGN.md for the Nix recipe)"; exit 2; }
PDK=$HERE/pdk; OUT=$P60/build/pd/block_${PERIOD}ns; rm -rf "$OUT"; mkdir -p "$OUT"
P54=$P60/vendor/p54/rtl
SRC="$(grep -v '^//' $P54/files.f | sed "s#^rtl/#$P54/#" | tr '\n' ' ') $P60/rtl/security/sfx_aes_sbox.sv $P60/rtl/security/sfx_aes_keyexp.sv $P60/rtl/security/sfx_aes_core.sv $P60/rtl/security/sfx_aes_xts.sv $P60/rtl/storage/sfx_page_engine.sv"
cat > "$OUT/synth.ys" <<EOS
read_verilog -sv -DSYNTHESIS -I$P54 -I$P54/generated $SRC
read_liberty -overwrite -setattr liberty_cell -lib $PDK/sky130_fd_sc_hd__tt_025C_1v80.lib
hierarchy -check -top sfx_page_engine
synth -top sfx_page_engine -flatten
dfflegalize -cell \$_DFF_P_ x -cell \$_DFF_N_ x -cell \$_DFF_PN0_ x -cell \$_DFF_PN1_ x -cell \$_DFF_NN0_ x -cell \$_DFF_NN1_ x
dfflibmap -liberty $PDK/sky130_fd_sc_hd__tt_025C_1v80.lib
abc -D $((PERIOD * 1000)) -liberty $PDK/sky130_fd_sc_hd__tt_025C_1v80.lib
setundef -zero
splitnets
opt_clean -purge
hilomap -hicell sky130_fd_sc_hd__conb_1 HI -locell sky130_fd_sc_hd__conb_1 LO
insbuf -buf sky130_fd_sc_hd__buf_2 A X
check -assert
tee -o $OUT/synth_stat.txt stat -liberty $PDK/sky130_fd_sc_hd__tt_025C_1v80.lib
write_verilog -noattr -noexpr -nohex -nodec $OUT/netlist.v
EOS
$YOS -q -l "$OUT/yosys.log" "$OUT/synth.ys" > /dev/null
cat > "$OUT/pd.sdc" <<EOS
create_clock -name clk -period $PERIOD [get_ports clk]
set_input_delay  [expr $PERIOD * 0.3] -clock clk [all_inputs]
set_output_delay [expr $PERIOD * 0.3] -clock clk [all_outputs]
set_false_path -from [get_ports rst_n]
EOS
cat > "$OUT/pd.tcl" <<EOS
read_lef $PDK/sky130hd.tlef
read_lef $PDK/sky130_fd_sc_hd_merged.lef
read_liberty $PDK/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog $OUT/netlist.v
link_design sfx_page_engine
read_sdc $OUT/pd.sdc
set_wire_rc -signal -layer met2
set_wire_rc -clock  -layer met5
initialize_floorplan -utilization $UTIL -aspect_ratio 1.0 -core_space 8 -site unithd
make_tracks
place_pins -hor_layers met3 -ver_layers met2
# minimal power grid (VDD/VSS straps) so that routing and power analysis have rails
add_global_connection -net VDD -pin_pattern {^VPWR\$} -power
add_global_connection -net VDD -pin_pattern {^VPB\$} -power
add_global_connection -net VSS -pin_pattern {^VGND\$} -ground
add_global_connection -net VSS -pin_pattern {^VNB\$} -ground
global_connect
set_voltage_domain -name CORE -power VDD -ground VSS
define_pdn_grid -name grid -voltage_domains CORE
add_pdn_stripe -layer met1 -followpins -width 0.48
add_pdn_stripe -layer met4 -width 1.6 -pitch 54 -offset 10
add_pdn_stripe -layer met5 -width 1.6 -pitch 54 -offset 10
add_pdn_connect -layers {met1 met4}
add_pdn_connect -layers {met4 met5}
pdngen
global_placement -density 0.55 -pad_left 1 -pad_right 1
estimate_parasitics -placement
repair_design
detailed_placement
clock_tree_synthesis -root_buf sky130_fd_sc_hd__clkbuf_16 -buf_list sky130_fd_sc_hd__clkbuf_8
set_propagated_clock [all_clocks]
detailed_placement
estimate_parasitics -placement
repair_timing -setup -max_buffer_percent 20
detailed_placement
write_db $OUT/block_cts.odb
set_global_routing_layer_adjustment met1-met5 0.3
global_route -guide_file $OUT/route.guide -congestion_report_file $OUT/congestion.rpt
estimate_parasitics -global_routing
# ---- results at global-route stage (written BEFORE detailed routing, which is the slow and least predictable step)
report_design_area
report_checks -path_delay max -group_path_count 3 -format full_clock_expanded -digits 3 > $OUT/timing_setup_gr.rpt
report_checks -path_delay min -group_path_count 1 -digits 3 > $OUT/timing_hold_gr.rpt
report_wns > $OUT/wns_gr.rpt
report_tns >> $OUT/wns_gr.rpt
report_power > $OUT/power_gr.rpt
report_clock_skew > $OUT/skew_gr.rpt
report_cell_usage
write_db $OUT/block_gr.odb
# ---- detailed routing, bounded (the iteration cap keeps the run time predictable; a non-zero DRC count at the end is REPORTED, not hidden)
detailed_route -output_drc $OUT/drc.rpt -droute_end_iter $DROUTE_ITERS
estimate_parasitics -global_routing
report_design_area
report_checks -path_delay max -group_path_count 3 -format full_clock_expanded -digits 3 > $OUT/timing_setup.rpt
report_checks -path_delay min -group_path_count 1 -digits 3 > $OUT/timing_hold.rpt
report_wns > $OUT/wns.rpt
report_tns >> $OUT/wns.rpt
report_power > $OUT/power.rpt
report_clock_skew > $OUT/skew.rpt
report_cell_usage
write_db $OUT/block.odb
exit
EOS
( time $OR -no_splash -exit "$OUT/pd.tcl" ) > "$OUT/openroad.log" 2>&1 || { tail -20 "$OUT/openroad.log"; exit 1; }
echo "== synthesis"; grep -E "Chip area|cells|sky130" "$OUT/synth_stat.txt" | head -4
echo "== area / timing / power (after detailed route)"; grep -E "Design area" "$OUT/openroad.log" | tail -1; cat "$OUT/wns.rpt"; grep -E "Total|total" "$OUT/power.rpt" | head -3
