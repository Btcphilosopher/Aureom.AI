// SilicaFlux-STORE P60 FPGA wrapper :: minimal 8N1 UART (transmitter + receiver), CLKS_PER_BIT = f_clk / baud.  Classification: SYNTHESIZABLE
`default_nettype none
module sfx_uart #(
  parameter int CLKS_PER_BIT = 87            // 100 MHz / 1.152 Mbaud ~ 87
) (
  input  wire logic       clk,
  input  wire logic       rst_n,
  input  wire logic       rx,                // asynchronous
  output logic            tx,
  output logic            rx_valid,          // one-cycle strobe
  output logic [7:0]      rx_data,
  input  wire logic       tx_valid,
  output logic            tx_ready,
  input  wire logic [7:0] tx_data
);
  localparam int CW = $clog2(CLKS_PER_BIT * 2);
  // receiver
  logic rx_s0, rx_s1, rx_busy;
  logic [CW-1:0] rx_cnt; logic [3:0] rx_bit; logic [7:0] rx_sh;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin rx_s0 <= 1'b1; rx_s1 <= 1'b1; rx_busy <= 1'b0; rx_cnt <= '0; rx_bit <= '0; rx_sh <= '0; rx_valid <= 1'b0; rx_data <= '0; end
    else begin
      rx_s0 <= rx; rx_s1 <= rx_s0; rx_valid <= 1'b0;
      if (!rx_busy) begin
        if (!rx_s1) begin rx_busy <= 1'b1; rx_cnt <= CW'(CLKS_PER_BIT / 2); rx_bit <= '0; end     // start bit: sample mid-bit
      end else if (rx_cnt != '0) rx_cnt <= rx_cnt - 1'b1;
      else begin
        rx_cnt <= CW'(CLKS_PER_BIT - 1);
        if (rx_bit == 4'd0) begin if (rx_s1) rx_busy <= 1'b0; rx_bit <= 4'd1; end       // false start -> abort
        else if (rx_bit <= 4'd8) begin rx_sh <= {rx_s1, rx_sh[7:1]}; rx_bit <= rx_bit + 1'b1; end
        else begin rx_busy <= 1'b0; if (rx_s1) begin rx_valid <= 1'b1; rx_data <= rx_sh; end end      // stop bit
      end
    end
  end
  // transmitter
  logic tx_busy; logic [CW-1:0] tx_cnt; logic [3:0] tx_bit; logic [9:0] tx_sh;
  assign tx_ready = !tx_busy;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin tx <= 1'b1; tx_busy <= 1'b0; tx_cnt <= '0; tx_bit <= '0; tx_sh <= '1; end
    else if (!tx_busy) begin
      if (tx_valid) begin tx_sh <= {1'b1, tx_data, 1'b0}; tx_busy <= 1'b1; tx_cnt <= CW'(CLKS_PER_BIT - 1); tx_bit <= '0; tx <= 1'b0; end
    end else if (tx_cnt != '0) tx_cnt <= tx_cnt - 1'b1;
    else begin
      tx_cnt <= CW'(CLKS_PER_BIT - 1);
      if (tx_bit == 4'd9) begin tx_busy <= 1'b0; tx <= 1'b1; end
      else begin tx_bit <= tx_bit + 1'b1; tx <= tx_sh[tx_bit + 1'b1]; end
    end
  end
endmodule
`default_nettype wire
