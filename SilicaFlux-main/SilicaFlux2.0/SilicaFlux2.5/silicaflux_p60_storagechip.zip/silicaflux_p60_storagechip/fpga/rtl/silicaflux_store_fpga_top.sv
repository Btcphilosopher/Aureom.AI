// =============================================================================
// SilicaFlux-STORE P60 :: silicaflux_store_fpga_top -- BOARD-INDEPENDENT FPGA integration wrapper
//
//   board clock/reset -> sfx_fpga_clk (PLL hook) -> silicaflux_storage_top  (SRAM_BACKEND = FPGA block RAM)
//   UART <-> sfx_uart_bridge: the "host": BAR accesses + host-memory BRAM access (firmware load, queue submit, DMA buffers)
//   host memory   : sfx_hostmem_bram (256 KiB), the controller's DMA master port lands here (no PCIe in this release)
//   NAND          : x8 SDR pins to a daughterboard / FMC NAND module (board specific; constraints are templates)
//   JTAG          : TestCore TAP pins to a header
// Nothing in this file claims hardware results: see fpga/README.md for the evidence required before any FPGA claim.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module silicaflux_store_fpga_top #(
  parameter int CLK_HZ       = 100_000_000,
  parameter int BAUD         = 1_000_000,
  parameter int HOSTMEM_WORDS = 65536
) (
  input  wire logic        clk_in,
  input  wire logic        rst_btn_n,                 // board reset button (active low)
  // UART host link
  input  wire logic        uart_rx,
  output logic             uart_tx,
  // NAND (x8 SDR)
  output logic             nand_ce_n,
  output logic             nand_cle,
  output logic             nand_ale,
  output logic             nand_we_n,
  output logic             nand_re_n,
  output logic             nand_wp_n,
  inout  wire logic [7:0]  nand_dq,
  input  wire logic        nand_rb_n,
  // JTAG
  input  wire logic        tck,
  input  wire logic        trst_n,
  input  wire logic        tms,
  input  wire logic        tdi,
  output logic             tdo,
  // straps / indicators
  input  wire logic        pwr_fail_n,                // supply-fail warning (tie high on a bench board without a supervisor)
  input  wire logic        hw_dbg_en,
  input  wire logic        hw_test_en,
  output logic [3:0]       led
);
  // ---- clock: no PLL by default (board clock used directly); a vendor MMCM/PLL wrapper replaces sfx_fpga_clk per board
  wire clk = clk_in;
  // ---- reset: button, stretched 1024 cycles so the synchroniser inside the top sees a clean assertion
  logic [10:0] rst_cnt = '0;
  logic        por_n;
  always_ff @(posedge clk) begin
    if (!rst_btn_n) rst_cnt <= '0;
    else if (!rst_cnt[10]) rst_cnt <= rst_cnt + 1'b1;
  end
  assign por_n = rst_cnt[10];

  // ---- host link
  logic rx_valid, tx_valid, tx_ready; logic [7:0] rx_data, tx_data;
  sfx_uart #(.CLKS_PER_BIT(CLK_HZ / BAUD)) u_uart (.clk, .rst_n(por_n), .rx(uart_rx), .tx(uart_tx), .rx_valid, .rx_data, .tx_valid, .tx_ready, .tx_data);
  logic        hb_req_valid, hb_req_ready, hb_req_write, hb_rsp_valid, hb_rsp_ready, hb_rsp_error;
  logic [31:0] hb_req_addr, hb_req_wdata, hb_rsp_rdata; logic [3:0] hb_req_wstrb;
  logic        bm_en, bm_we; logic [31:0] bm_addr, bm_wdata, bm_rdata;
  sfx_uart_bridge u_bridge (
    .clk, .rst_n(por_n), .rx_valid, .rx_data, .tx_valid, .tx_ready, .tx_data,
    .hb_req_valid, .hb_req_ready, .hb_req_write, .hb_req_addr, .hb_req_wdata, .hb_req_wstrb,
    .hb_rsp_valid, .hb_rsp_ready, .hb_rsp_rdata, .hb_rsp_error,
    .hm_en(bm_en), .hm_we(bm_we), .hm_addr(bm_addr), .hm_wdata(bm_wdata), .hm_rdata(bm_rdata)
  );

  // ---- host memory (the controller's DMA master lands here; window base 0x3000_0000 is removed by the subsystem gate)
  logic        hm_req_valid, hm_req_ready, hm_req_write, hm_rsp_valid, hm_rsp_ready, hm_rsp_error;
  logic [31:0] hm_req_addr, hm_req_wdata, hm_rsp_rdata; logic [3:0] hm_req_wstrb;
  sfx_hostmem_bram #(.WORDS(HOSTMEM_WORDS)) u_hm (
    .clk, .rst_n(por_n),
    .s_req_valid(hm_req_valid), .s_req_ready(hm_req_ready), .s_req_write(hm_req_write), .s_req_addr(hm_req_addr),
    .s_req_wdata(hm_req_wdata), .s_req_wstrb(hm_req_wstrb), .s_rsp_valid(hm_rsp_valid), .s_rsp_ready(hm_rsp_ready),
    .s_rsp_rdata(hm_rsp_rdata), .s_rsp_error(hm_rsp_error),
    .b_en(bm_en), .b_we(bm_we), .b_addr(bm_addr), .b_wdata(bm_wdata), .b_rdata(bm_rdata)
  );

  // ---- the controller
  logic [7:0] dq_o; logic dq_oe; logic irq, host_ready, cmdproc_ready, host_irq, mgmt_irq, ras_fatal, test_done, test_fail, cpu_sleep, tdo_oe;
  /* verilator lint_off UNUSEDSIGNAL */
  logic diag_valid; logic [7:0] diag_char; logic [15:0] test_code;
  /* verilator lint_on UNUSEDSIGNAL */
  logic tdo_i;
  silicaflux_storage_top #(.NUM_NAND_CHANNELS(1), .CHANNEL_DATA_WIDTH(8), .BUFFER_SIZE_BYTES(16384), .DMA_DATA_WIDTH(32),
                           .ADDRESS_WIDTH(32), .CMD_QUEUE_DEPTH(8), .NAND_PAGE_BYTES(544), .SRAM_BACKEND(1)) u_top (
    .clk, .por_n, .pwr_fail_n, .boot_mode(2'b00), .host_rst_req(1'b0),
    .hb_req_valid, .hb_req_ready, .hb_req_write, .hb_req_addr, .hb_req_wdata, .hb_req_wstrb,
    .hb_rsp_valid, .hb_rsp_ready, .hb_rsp_rdata, .hb_rsp_error,
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error,
    .nand_ce_n, .nand_cle, .nand_ale, .nand_we_n, .nand_re_n, .nand_wp_n, .nand_dq_o(dq_o), .nand_dq_oe(dq_oe), .nand_dq_i(nand_dq), .nand_rb_n,
    .tck, .trst_n, .tms, .tdi, .tdo(tdo_i), .tdo_oe,
    .hw_dbg_en, .hw_test_en, .scan_mode_pin(1'b0), .scan_en_pin(1'b0),
    .irq_o(irq), .host_irq_o(host_irq), .mgmt_irq_o(mgmt_irq), .host_ready_o(host_ready), .cmdproc_ready_o(cmdproc_ready),
    .ras_fatal_o(ras_fatal), .diag_valid_o(diag_valid), .diag_char_o(diag_char), .test_done_o(test_done), .test_fail_o(test_fail),
    .test_code_o(test_code), .cpu_sleep_o(cpu_sleep)
  );
  assign nand_dq = dq_oe ? dq_o : 8'bz;
  assign tdo = tdo_oe ? tdo_i : 1'bz;
  assign led = {ras_fatal | test_fail, irq | host_irq | mgmt_irq, cmdproc_ready, host_ready};
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_fpga = test_done ^ cpu_sleep;
  /* verilator lint_on UNUSEDSIGNAL */
endmodule
`default_nettype wire
