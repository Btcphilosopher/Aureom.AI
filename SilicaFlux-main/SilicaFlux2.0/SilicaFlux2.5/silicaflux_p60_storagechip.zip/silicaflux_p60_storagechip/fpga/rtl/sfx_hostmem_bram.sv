// =============================================================================
// SilicaFlux-STORE P60 FPGA wrapper :: sfx_hostmem_bram -- host memory emulation in block RAM
//   SFB2 slave (DW = 32, one transaction outstanding) for the controller's host-memory master port (hm_*), plus a second
//   word-wide port for the UART bridge (the "host CPU").  Addresses are relative to the host window base.
// Classification: SYNTHESIZABLE (dual-port block-RAM inference)
// =============================================================================
`default_nettype none
module sfx_hostmem_bram #(
  parameter int WORDS = 65536                // 256 KiB
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // SFB2 slave (controller DMA)
  input  wire logic        s_req_valid,
  output logic             s_req_ready,
  input  wire logic        s_req_write,
  input  wire logic [31:0] s_req_addr,
  input  wire logic [31:0] s_req_wdata,
  input  wire logic [3:0]  s_req_wstrb,
  output logic             s_rsp_valid,
  input  wire logic        s_rsp_ready,
  output logic [31:0]      s_rsp_rdata,
  output logic             s_rsp_error,
  // bridge port
  input  wire logic        b_en,
  input  wire logic        b_we,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [31:0] b_addr,           // byte address (bits above the memory size are ignored)
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [31:0] b_wdata,
  output logic [31:0]      b_rdata
);
  localparam int AW = $clog2(WORDS);
  logic [31:0] mem [0:WORDS-1];
  wire [AW-1:0] sa = s_req_addr[AW+1:2];
  wire s_ok = (s_req_addr[31:AW+2] == '0) && (s_req_addr[1:0] == 2'b00);
  logic pend, bad;
  assign s_req_ready = !pend;
  assign s_rsp_valid = pend;
  assign s_rsp_error = bad;
  always_ff @(posedge clk) begin                                     // port A: SFB2 slave (no reset on the array)
    if (s_req_valid && s_req_ready && s_ok) begin
      if (s_req_write) begin
        for (int i = 0; i < 4; i++) if (s_req_wstrb[i]) mem[sa][8*i +: 8] <= s_req_wdata[8*i +: 8];
      end
      s_rsp_rdata <= mem[sa];
    end
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin pend <= 1'b0; bad <= 1'b0; end
    else if (!pend) begin if (s_req_valid) begin pend <= 1'b1; bad <= !s_ok; end end
    else if (s_rsp_ready) pend <= 1'b0;
  end
  wire [AW-1:0] ba = b_addr[AW+1:2];
  always_ff @(posedge clk) begin                                     // port B: bridge
    if (b_en) begin
      if (b_we) mem[ba] <= b_wdata;
      b_rdata <= mem[ba];
    end
  end
endmodule
`default_nettype wire
