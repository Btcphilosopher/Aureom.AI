// =============================================================================
// SilicaFlux-STORE P60 FPGA wrapper :: sfx_uart_bridge -- UART-to-host-BAR bridge (the "host CPU" of the bring-up setup)
//
//   Frame PC -> FPGA (9 bytes):  cmd[7:0]  addr[31:0] (little endian)  data[31:0] (little endian)
//   Frame FPGA -> PC (5 bytes):  status[7:0]  data[31:0]                    status: 0 OK, 1 bus error, 0xFF unknown command
//     0x01 BAR write      (SFB2 transaction on hb_*: management window 0x0000_0000.., storage host controller 0x8000_0000.., top 0xC000_0000..)
//     0x02 BAR read
//     0x11 host-memory write (word, byte address in the host-memory BRAM)
//     0x12 host-memory read
//     0x20 ping (returns 0x5346_5850 "SFXP")
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sfx_uart_bridge (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rx_valid,
  input  wire logic [7:0]  rx_data,
  output logic             tx_valid,
  input  wire logic        tx_ready,
  output logic [7:0]       tx_data,
  // BAR master (SFB2)
  output logic             hb_req_valid,
  input  wire logic        hb_req_ready,
  output logic             hb_req_write,
  output logic [31:0]      hb_req_addr,
  output logic [31:0]      hb_req_wdata,
  output logic [3:0]       hb_req_wstrb,
  input  wire logic        hb_rsp_valid,
  output logic             hb_rsp_ready,
  input  wire logic [31:0] hb_rsp_rdata,
  input  wire logic        hb_rsp_error,
  // host-memory port
  output logic             hm_en,
  output logic             hm_we,
  output logic [31:0]      hm_addr,
  output logic [31:0]      hm_wdata,
  input  wire logic [31:0] hm_rdata
);
  typedef enum logic [3:0] { S_RX, S_BAR_REQ, S_BAR_RSP, S_HM, S_HM_RD, S_TX } st_e;
  st_e st;
  logic [7:0] cmd; logic [31:0] addr, data; logic [3:0] nrx; logic [7:0] stat; logic [31:0] rdat; logic [2:0] ntx;
  assign hb_req_write = (cmd == 8'h01);
  assign hb_req_addr  = addr;
  assign hb_req_wdata = data;
  assign hb_req_wstrb = 4'hF;
  assign hb_rsp_ready = 1'b1;
  assign hm_en    = (st == S_HM);
  assign hm_we    = (cmd == 8'h11);
  assign hm_addr  = addr;
  assign hm_wdata = data;
  assign hb_req_valid = (st == S_BAR_REQ);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin st <= S_RX; cmd <= '0; addr <= '0; data <= '0; nrx <= '0; stat <= '0; rdat <= '0; ntx <= '0; tx_valid <= 1'b0; tx_data <= '0; end
    else begin
      tx_valid <= 1'b0;
      case (st)
        S_RX: if (rx_valid) begin
          case (nrx)
            4'd0: cmd <= rx_data;
            4'd1: addr[7:0] <= rx_data;   4'd2: addr[15:8] <= rx_data;   4'd3: addr[23:16] <= rx_data;   4'd4: addr[31:24] <= rx_data;
            4'd5: data[7:0] <= rx_data;   4'd6: data[15:8] <= rx_data;   4'd7: data[23:16] <= rx_data;
            default: ;
          endcase
          if (nrx == 4'd8) begin
            data[31:24] <= rx_data; nrx <= '0;
            case (cmd)
              8'h01, 8'h02: st <= S_BAR_REQ;
              8'h11, 8'h12: st <= S_HM;
              8'h20: begin stat <= 8'h00; rdat <= 32'h5346_5850; st <= S_TX; ntx <= '0; end
              default: begin stat <= 8'hFF; rdat <= '0; st <= S_TX; ntx <= '0; end
            endcase
          end else nrx <= nrx + 1'b1;
        end
        S_BAR_REQ: if (hb_req_ready) st <= S_BAR_RSP;
        S_BAR_RSP: if (hb_rsp_valid) begin stat <= {7'h0, hb_rsp_error}; rdat <= hb_rsp_rdata; st <= S_TX; ntx <= '0; end
        S_HM: st <= S_HM_RD;                                      // the BRAM presents read data one cycle later
        S_HM_RD: begin stat <= 8'h00; rdat <= hm_rdata; st <= S_TX; ntx <= '0; end
        S_TX: begin
          if (tx_ready && !tx_valid && ntx <= 3'd4) begin
            tx_valid <= 1'b1;
            tx_data  <= (ntx == 3'd0) ? stat : (ntx == 3'd1) ? rdat[7:0] : (ntx == 3'd2) ? rdat[15:8] : (ntx == 3'd3) ? rdat[23:16] : rdat[31:24];
            ntx <= ntx + 1'b1;
          end
          if (ntx == 3'd5 && tx_ready) st <= S_RX;
        end
        default: st <= S_RX;
      endcase
    end
  end
endmodule
`default_nettype wire
