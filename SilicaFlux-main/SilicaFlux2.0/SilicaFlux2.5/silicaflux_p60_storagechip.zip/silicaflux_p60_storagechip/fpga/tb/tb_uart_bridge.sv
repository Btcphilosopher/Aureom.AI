// SilicaFlux-STORE P60 FPGA wrapper :: tb_uart_bridge -- UART bridge + host-memory BRAM unit test (iverilog / Verilator)
`timescale 1ns/1ps
module tb_uart_bridge;
  localparam int CPB = 10;                       // clocks per bit (fast simulation)
  logic clk = 0, rst_n = 0; always #5 clk = ~clk;
  logic pc_tx = 1, fpga_tx; logic rx_valid; logic [7:0] rx_data; logic tx_valid, tx_ready; logic [7:0] tx_data;
  logic        hb_req_valid, hb_req_ready, hb_req_write, hb_rsp_valid, hb_rsp_ready, hb_rsp_error;
  logic [31:0] hb_req_addr, hb_req_wdata, hb_rsp_rdata; logic [3:0] hb_req_wstrb;
  logic bm_en, bm_we; logic [31:0] bm_addr, bm_wdata, bm_rdata;
  sfx_uart #(.CLKS_PER_BIT(CPB)) u_uart (.clk, .rst_n, .rx(pc_tx), .tx(fpga_tx), .rx_valid, .rx_data, .tx_valid, .tx_ready, .tx_data);
  sfx_uart_bridge u_br (.clk, .rst_n, .rx_valid, .rx_data, .tx_valid, .tx_ready, .tx_data,
    .hb_req_valid, .hb_req_ready, .hb_req_write, .hb_req_addr, .hb_req_wdata, .hb_req_wstrb, .hb_rsp_valid, .hb_rsp_ready, .hb_rsp_rdata, .hb_rsp_error,
    .hm_en(bm_en), .hm_we(bm_we), .hm_addr(bm_addr), .hm_wdata(bm_wdata), .hm_rdata(bm_rdata));
  // SFB2 slave of the controller DMA side
  logic        dq_v, dq_r, dq_w, dp_v, dp_e; logic [31:0] dq_a, dq_d, dp_d; logic [3:0] dq_s;
  sfx_hostmem_bram #(.WORDS(1024)) u_hm (.clk, .rst_n, .s_req_valid(dq_v), .s_req_ready(dq_r), .s_req_write(dq_w), .s_req_addr(dq_a), .s_req_wdata(dq_d),
    .s_req_wstrb(dq_s), .s_rsp_valid(dp_v), .s_rsp_ready(1'b1), .s_rsp_rdata(dp_d), .s_rsp_error(dp_e),
    .b_en(bm_en), .b_we(bm_we), .b_addr(bm_addr), .b_wdata(bm_wdata), .b_rdata(bm_rdata));
  // BAR slave model: 16 registers; address 0x0000_00FC returns a bus error
  logic [31:0] regs [0:15]; logic pend_q; logic [31:0] rd_q; logic err_q;
  assign hb_req_ready = !pend_q;
  assign hb_rsp_valid = pend_q; assign hb_rsp_rdata = rd_q; assign hb_rsp_error = err_q;
  always_ff @(posedge clk) begin
    if (!rst_n) pend_q <= 1'b0;
    else if (!pend_q) begin
      if (hb_req_valid) begin
        pend_q <= 1'b1; err_q <= (hb_req_addr[7:0] == 8'hFC);
        if (hb_req_write) regs[hb_req_addr[5:2]] <= hb_req_wdata;
        rd_q <= regs[hb_req_addr[5:2]];
      end
    end else pend_q <= 1'b0;
  end
  int errors = 0, checks = 0;
  task automatic send_byte(input [7:0] b);
    pc_tx = 0; repeat (CPB) @(posedge clk);
    for (int i = 0; i < 8; i++) begin pc_tx = b[i]; repeat (CPB) @(posedge clk); end
    pc_tx = 1; repeat (CPB) @(posedge clk);
  endtask
  logic [7:0] rb; int nb;
  task automatic recv_byte(output [7:0] b);
    int t;
    t = 0; while (fpga_tx && t < 200000) begin @(posedge clk); t++; end
    repeat (CPB + CPB / 2) @(posedge clk);
    for (int i = 0; i < 8; i++) begin b[i] = fpga_tx; repeat (CPB) @(posedge clk); end
    repeat (CPB / 2) @(posedge clk);
  endtask
  task automatic xact(input [7:0] cmd, input [31:0] a, input [31:0] d, output [7:0] st, output [31:0] rd);
    logic [7:0] b0, b1, b2, b3, b4;
    send_byte(cmd);
    for (int i = 0; i < 4; i++) send_byte(a[8*i +: 8]);
    for (int i = 0; i < 4; i++) send_byte(d[8*i +: 8]);
    recv_byte(b0); recv_byte(b1); recv_byte(b2); recv_byte(b3); recv_byte(b4);
    st = b0; rd = {b4, b3, b2, b1};
  endtask
  task automatic chk(input string w, input [31:0] got, input [31:0] exp);
    checks++; if (got !== exp) begin errors++; $display("FAIL %s: got %08h expected %08h", w, got, exp); end
  endtask
  logic [7:0] st; logic [31:0] rd;
  initial begin
    dq_v = 0; dq_w = 0; dq_a = 0; dq_d = 0; dq_s = 0;
    repeat (10) @(posedge clk); rst_n = 1; repeat (10) @(posedge clk);
    xact(8'h20, 0, 0, st, rd); chk("ping status", st, 0); chk("ping data", rd, 32'h5346_5850);
    xact(8'h01, 32'h8000_0008, 32'hCAFE_F00D, st, rd); chk("bar write status", st, 0);
    xact(8'h02, 32'h8000_0008, 0, st, rd);              chk("bar read status", st, 0); chk("bar read data", rd, 32'hCAFE_F00D);
    xact(8'h02, 32'h8000_00FC, 0, st, rd);              chk("bar error reported", st, 1);
    xact(8'h11, 32'h0000_0040, 32'h1234_5678, st, rd);  chk("hm write status", st, 0);
    xact(8'h12, 32'h0000_0040, 0, st, rd);              chk("hm read back via bridge", rd, 32'h1234_5678);
    // controller-side DMA write into the same BRAM, read back through the bridge
    @(negedge clk); dq_v = 1; dq_w = 1; dq_a = 32'h0000_0080; dq_d = 32'hA5A5_0F0F; dq_s = 4'hF;
    @(posedge clk); while (!dq_r) @(posedge clk); @(negedge clk); dq_v = 0; repeat (4) @(posedge clk);
    xact(8'h12, 32'h0000_0080, 0, st, rd);              chk("DMA write visible to the host", rd, 32'hA5A5_0F0F);
    @(negedge clk); dq_v = 1; dq_w = 0; dq_a = 32'h0000_0040; @(posedge clk); while (!dq_r) @(posedge clk); @(negedge clk); dq_v = 0;
    while (!dp_v) @(posedge clk);
    chk("DMA read of host-written data", dp_d, 32'h1234_5678); chk("DMA read no error", dp_e, 0);
    @(negedge clk); dq_v = 1; dq_a = 32'h0010_0000; @(posedge clk); while (!dq_r) @(posedge clk); @(negedge clk); dq_v = 0;
    while (!dp_v) @(posedge clk); chk("DMA out-of-range access flagged", dp_e, 1);
    xact(8'h7F, 0, 0, st, rd);                          chk("unknown command rejected", st, 8'hFF);
    $display("TB RESULT tb_uart_bridge checks=%0d errors=%0d -> %s", checks, errors, errors == 0 ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #50000000; $display("TB RESULT tb_uart_bridge TIMEOUT -> FAIL"); $finish; end
endmodule
