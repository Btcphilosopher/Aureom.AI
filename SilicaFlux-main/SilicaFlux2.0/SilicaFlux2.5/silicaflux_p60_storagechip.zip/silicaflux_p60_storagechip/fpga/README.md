# FPGA prototype — board-independent wrapper (NO HARDWARE RESULTS EXIST)

`rtl/silicaflux_store_fpga_top.sv` wraps `silicaflux_storage_top` (built with `SRAM_BACKEND=FPGA`, i.e. block-RAM inference) with a UART host
bridge (`sfx_uart_bridge`: BAR reads/writes + host-memory access), a block-RAM host memory (`sfx_hostmem_bram`, the DMA target — there is no
PCIe in this release), tri-state NAND pins and JTAG. `host_uart.py` is the bring-up host; `constraints/` holds **templates** (every pin is a placeholder).

| What | Status |
|---|---|
| Wrapper RTL lints clean (Verilator -Wall, P60 files) | yes |
| UART bridge + host-memory BRAM unit test (`tb/tb_uart_bridge.sv`, Icarus) | **13/13 checks pass** (BAR write/read/error, host-memory write/read, DMA write visible to host, DMA out-of-range flagged, unknown command) |
| Full-chip firmware run *through the UART bridge* | **not done** (the full-chip testbench drives the BAR directly) |
| Synthesis for an FPGA family (resource estimate) | see `reports/fpga_resource_estimate.md` (Yosys, estimates only) |
| Place & route, timing, bitstream, board bring-up, memory-interface exercise, data-integrity run on hardware | **NOT DONE — no board, no vendor tools** |
| Achieved clock frequency, measured utilisation | **none** (the 20 ns period in the SDC is a placeholder) |

## Bring-up checklist (to be executed on real hardware; record evidence under `evidence/`)
1. Board: a part with ≥ the LUT/BRAM budget of the estimate (by Yosys pre-P&R count the SoC without the wrapper is ≈ 29 k LUT6 / 14.8 k FF / 29.5 RAMB36 on 7-series, ≈ 60–65 % of an ECP5-85F by LUT4 equivalents — timing unknown; see `reports/fpga_resource_estimate.md`), a x8 SDR NAND daughterboard (FMC/PMOD), 3.3 V UART.
2. Replace the pin tokens in `constraints/*TEMPLATE*`; set `CLK_HZ`, `BAUD`; add the vendor MMCM/PLL if the board clock differs.
3. Synthesize/implement; **record** utilisation (LUT/FF/BRAM/DSP), WNS/TNS, achieved fmax; adjust the SDC period to the measured value.
4. `host_uart.py ping` → `SFXP`; read `0xC000_0000` (`SFST`); read TestCore IDCODE register `0xC000_1008` = `0x15F07001` and via JTAG.
5. `load-fw` (boot-ROM host-load flow), then run the queue flow of `tb/soc/tb_p60_soc.sv` (port `boot()`, `enable_ctrl()`, `submit()`) with the real NAND; confirm `READ_ID`, bad-block scan, format, write/read/verify the whole namespace; run the crash campaign by cutting the board supply (needs a supervisor wired to `pwr_fail_n`).
6. Exercise: each memory interface (BRAM host memory, NAND bus timing against the device datasheet — the controller's TIMING registers must be re-derived, they were chosen for the simulated twin), data-integrity soak, GET_LOG health.
Only after steps 3–6 produce logs may anything be claimed about FPGA performance or function.
