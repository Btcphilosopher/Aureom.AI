#!/usr/bin/env python3
"""
host_uart.py -- bring-up host for silicaflux_store_fpga_top over the UART bridge (frames: see rtl/sfx_uart_bridge.sv).

  host_uart.py --port /dev/ttyUSB0 --baud 1000000 ping
  host_uart.py ... load-fw fw/build/p60_fw.hex        # boot-ROM host-load flow, mailbox IMAGE_READY
  host_uart.py ... selftest                           # IDENTIFY, write/read/verify a few LBAs through the SQ/CQ ABI

STATUS: written against the simulated bridge (fpga/tb/tb_uart_bridge.sv) and the full-chip testbench's driver flow; it has NEVER
been run against hardware.  `--sim-selftest` runs the protocol against an in-process model of the bridge so the script itself
can be checked without a board.  Requires pyserial for real use.
"""
import argparse, struct, sys

class Link:
    def __init__(self, port=None, baud=1000000):
        import serial  # pyserial
        self.s = serial.Serial(port, baud, timeout=2)
    def xact(self, cmd, addr=0, data=0):
        self.s.write(struct.pack("<BII", cmd, addr & 0xFFFFFFFF, data & 0xFFFFFFFF))
        r = self.s.read(5)
        if len(r) != 5: raise IOError("bridge timeout")
        st, val = struct.unpack("<BI", r)
        return st, val

class SimLink:
    """in-process model of the bridge + a register file, to exercise this script without hardware"""
    def __init__(self): self.reg, self.hm = {}, {}
    def xact(self, cmd, addr=0, data=0):
        if cmd == 0x20: return 0, 0x53465850
        if cmd == 0x01: self.reg[addr] = data; return 0, 0
        if cmd == 0x02: return 0, self.reg.get(addr, 0)
        if cmd == 0x11: self.hm[addr] = data; return 0, 0
        if cmd == 0x12: return 0, self.hm.get(addr, 0)
        return 0xFF, 0

BAR_SHC = 0x80000000
def bar_w(l, a, d):
    st, _ = l.xact(0x01, a, d);  assert st == 0, f"BAR write error @{a:08x}"
def bar_r(l, a):
    st, v = l.xact(0x02, a);     assert st == 0, f"BAR read error @{a:08x}"; return v
def hm_w(l, a, d): l.xact(0x11, a, d)
def hm_r(l, a): return l.xact(0x12, a)[1]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port"); ap.add_argument("--baud", type=int, default=1000000)
    ap.add_argument("cmd", choices=["ping", "load-fw", "selftest", "sim-selftest"]); ap.add_argument("arg", nargs="?")
    a = ap.parse_args()
    if a.cmd == "sim-selftest":
        l = SimLink(); assert l.xact(0x20)[1] == 0x53465850; bar_w(l, 0xC0000018, 1); assert bar_r(l, 0xC0000018) == 1
        hm_w(l, 0x40, 0x1234); assert hm_r(l, 0x40) == 0x1234; print("sim-selftest OK"); return
    l = Link(a.port, a.baud)
    if a.cmd == "ping":
        print("bridge ID %08x" % l.xact(0x20)[1])
    elif a.cmd == "load-fw":
        words = [int(x, 16) for x in open(a.arg).read().split()]
        for i, w in enumerate(words): bar_w(l, 0x00010000 + 4 * i, w)         # CC_IMEM_BASE (management window)
        print(f"wrote {len(words)} words; ring the boot ROM mailbox IMAGE_READY next (see tb/soc/tb_p60_soc.sv: boot())")
    else:
        print("top ID %08x" % bar_r(l, 0xC0000000))
        print("selftest: queue flow is implemented in tb/soc/tb_p60_soc.sv; port it here before the first board session")

if __name__ == "__main__":
    main()
