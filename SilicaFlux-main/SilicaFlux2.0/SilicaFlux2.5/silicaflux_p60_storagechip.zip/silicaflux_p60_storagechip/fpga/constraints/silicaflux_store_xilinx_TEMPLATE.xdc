# Xilinx 7-series / UltraScale+ pin template for silicaflux_store_fpga_top -- EVERY PACKAGE_PIN IS A PLACEHOLDER.
# Replace the <PIN_*> tokens with the board's pins; do not run implementation with these tokens.
# set_property -dict {PACKAGE_PIN <PIN_CLK>  IOSTANDARD LVCMOS33} [get_ports clk_in]
# set_property -dict {PACKAGE_PIN <PIN_RST>  IOSTANDARD LVCMOS33} [get_ports rst_btn_n]
# set_property -dict {PACKAGE_PIN <PIN_URX>  IOSTANDARD LVCMOS33} [get_ports uart_rx]
# set_property -dict {PACKAGE_PIN <PIN_UTX>  IOSTANDARD LVCMOS33} [get_ports uart_tx]
# NAND daughterboard (FMC / PMOD): 3.3 V or 1.8 V per the device; x8 SDR
# set_property -dict {PACKAGE_PIN <PIN_NCE>  IOSTANDARD LVCMOS18} [get_ports nand_ce_n]
# ... nand_cle nand_ale nand_we_n nand_re_n nand_wp_n nand_rb_n nand_dq[0..7]
# JTAG header: tck tms tdi tdo trst_n ; straps: pwr_fail_n hw_dbg_en hw_test_en ; led[3:0]
# set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets tck_IBUF]      ;# only if tck is not on a clock-capable pin
# Block RAM inference: the SoC is built with SRAM_BACKEND = FPGA (sram_fpga_1rw); IMEM/DMEM/buffer/host memory map to RAMB36.
