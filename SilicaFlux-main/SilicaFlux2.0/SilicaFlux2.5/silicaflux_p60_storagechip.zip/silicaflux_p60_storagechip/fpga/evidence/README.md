Put hardware evidence here (bitstream hash, utilisation report, timing summary, UART transcripts, board photo/serial numbers, NAND part number, test logs).
This directory is intentionally empty: the release contains no hardware evidence.
