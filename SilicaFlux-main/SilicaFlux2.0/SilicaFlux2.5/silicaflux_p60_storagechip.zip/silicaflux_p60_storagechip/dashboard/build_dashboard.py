#!/usr/bin/env python3
"""
build_dashboard.py -- SilicaFlux-STORE storage health dashboard (single self-contained HTML, inline SVG, no external resources).

  build_dashboard.py --getlog <getlog.txt> --endurance <results_dir> --analysis <endurance.json> [--bench <bench.json>] --out <file.html>

Inputs
  getlog.txt   "word value" lines written by the testbench from the GET_LOG page 0 (layout: docs/02_HOST_INTERFACE.md)
  endurance    output of endurance/run_endurance.sh (CSV time series + erase-count histograms)
  analysis     endurance/analyze.py output (ECC trend)
  bench        bench/parse_bench.py output
Every number shown is SIMULATION data (RTL simulation cycles / host simulation); the page says so.
"""
import argparse, csv, glob, html, json, os

ap = argparse.ArgumentParser()
ap.add_argument("--getlog"); ap.add_argument("--endurance"); ap.add_argument("--analysis"); ap.add_argument("--bench"); ap.add_argument("--out", required=True)
a = ap.parse_args()

def esc(x): return html.escape(str(x))

# ------------------------------------------------------------------ GET_LOG
log = {}
if a.getlog and os.path.exists(a.getlog):
    for line in open(a.getlog):
        p = line.split()
        if len(p) == 2: log[int(p[0])] = int(p[1])
def w(i, d=0): return log.get(i, d)

def tile(label, value, note="", cls=""):
    return f'<div class="tile {cls}"><div class="tl">{esc(label)}</div><div class="tv">{esc(value)}</div><div class="tn">{esc(note)}</div></div>'

tiles = []
if log:
    host_w, p_host, p_rel, p_meta = w(6), w(8), w(9), w(10)
    wa = (p_host + p_rel + p_meta) / host_w if host_w else 0
    mean_ec = (w(34) / w(35)) if w(35) else 0
    unc = w(25) + w(26)
    tiles = [
        tile("Namespace", f"{w(37)} LBAs", "512 B logical blocks"),
        tile("Valid pages", w(36)),
        tile("Write amplification", f"{wa:.2f}", f"programs host/reloc/meta = {p_host}/{p_rel}/{p_meta}"),
        tile("Free blocks", w(28), f"{w(29)} closed"),
        tile("Bad blocks", f"{w(30)} factory + {w(31)} grown", "grown = retired after program/erase failure", "warn" if w(31) else ""),
        tile("Erase count", f"{w(32)} – {w(33)}", f"mean {mean_ec:.1f} over {w(35)} blocks"),
        tile("ECC corrected bits", w(23), f"{w(24)} pages, {w(27)} erased-page reads"),
        tile("Uncorrectable reads", unc, f"ECC {w(25)} + integrity {w(26)} (explicit MEDIA_UNREC)", "bad" if unc else ""),
        tile("CRC / LPN errors", f"{w(21)} / {w(22)}", "end-to-end FTL checks"),
        tile("GC", f"{w(13)} victims", f"{w(14)} pages moved, {w(15)} checkpoints"),
        tile("Mounts", f"clean {w(38) & 255}, unclean {(w(38) >> 8) & 255}, rebuild {(w(38) >> 16) & 255}", f"last: replayed {w(39)}, torn {w(40)}, fallback {w(41)}"),
        tile("Data at rest", "XTS-AES-256" if w(43) & 1 else "plain", "key loaded" if w(43) & 2 else "no key", ""),
        tile("Read-only", "yes" if w(42) else "no", "", "bad" if w(42) else ""),
        tile("Firmware errors", w(53), f"page-engine errors {w(47)}", "bad" if w(53) else ""),
    ]

# ------------------------------------------------------------------ endurance charts
def svg_lines(series, xlabel, ylabel, w_=560, h_=260, title=""):
    xs = [x for s in series for (x, _) in s["pts"]]; ys = [y for s in series for (_, y) in s["pts"]]
    if not xs: return ""
    x0, x1, y0, y1 = 0, max(xs) or 1, 0, (max(ys) or 1) * 1.08
    L, R, T, B = 52, 12, 22, 40
    def px(x): return L + (x - x0) / (x1 - x0) * (w_ - L - R)
    def py(y): return h_ - B - (y - y0) / (y1 - y0) * (h_ - T - B)
    g = [f'<svg viewBox="0 0 {w_} {h_}" role="img" aria-label="{esc(title)}">', f'<text x="{L}" y="14" class="ct">{esc(title)}</text>']
    for k in range(5):
        yv = y0 + (y1 - y0) * k / 4
        g.append(f'<line x1="{L}" x2="{w_-R}" y1="{py(yv):.1f}" y2="{py(yv):.1f}" class="grid"/><text x="{L-6}" y="{py(yv)+4:.1f}" class="ax" text-anchor="end">{yv:.3g}</text>')
    for k in range(5):
        xv = x0 + (x1 - x0) * k / 4
        g.append(f'<text x="{px(xv):.1f}" y="{h_-B+16}" class="ax" text-anchor="middle">{xv:.3g}</text>')
    g.append(f'<text x="{(L+w_-R)/2:.0f}" y="{h_-6}" class="ax" text-anchor="middle">{esc(xlabel)}</text>')
    g.append(f'<text x="12" y="{(T+h_-B)/2:.0f}" class="ax" transform="rotate(-90 12 {(T+h_-B)/2:.0f})" text-anchor="middle">{esc(ylabel)}</text>')
    for i, s in enumerate(series):
        pts = " ".join(f"{px(x):.1f},{py(y):.1f}" for x, y in s["pts"])
        g.append(f'<polyline points="{pts}" class="ln c{i % 6}" fill="none"/>')
        g.append(f'<text x="{w_-R-4}" y="{T+12+i*13}" class="lg c{i % 6}t" text-anchor="end">{esc(s["name"])}</text>')
    g.append("</svg>")
    return "".join(g)

def smooth(pts, n=9):
    out = []
    for i in range(len(pts)):
        lo = max(0, i - n // 2); hi = min(len(pts), i + n // 2 + 1)
        out.append((pts[i][0], sum(y for _, y in pts[lo:hi]) / (hi - lo)))
    return out
def series_from(csvfile, xcol, ycol):
    pts = []
    for r in csv.DictReader(open(csvfile)):
        try: pts.append((float(r[xcol]), float(r[ycol])))
        except (ValueError, KeyError): pass
    return pts

def svg_hist(csvfile, title, w_=560, h_=230):
    vals = [int(r["erase_count"]) for r in csv.DictReader(open(csvfile)) if r["factory_bad"] == "0"]
    if not vals: return ""
    lo, hi = min(vals), max(vals); nb = 24
    bw = max(1, (hi - lo + nb) // nb)
    bins = [0] * nb
    for v in vals: bins[min(nb - 1, (v - lo) // bw)] += 1
    L, R, T, B = 40, 10, 22, 36; m = max(bins) or 1
    g = [f'<svg viewBox="0 0 {w_} {h_}" role="img" aria-label="{esc(title)}"><text x="{L}" y="14" class="ct">{esc(title)}</text>']
    for i, c in enumerate(bins):
        bwid = (w_ - L - R) / nb; hh = c / m * (h_ - T - B)
        g.append(f'<rect x="{L+i*bwid+1:.1f}" y="{h_-B-hh:.1f}" width="{bwid-2:.1f}" height="{hh:.1f}" class="bar"><title>{lo+i*bw}–{lo+(i+1)*bw-1} cycles: {c} blocks</title></rect>')
    g.append(f'<text x="{L}" y="{h_-6}" class="ax">{lo}</text><text x="{w_-R}" y="{h_-6}" class="ax" text-anchor="end">{hi} erase cycles</text></svg>')
    return "".join(g)

charts = []; ablate = []
if a.endurance and os.path.isdir(a.endurance):
    wa_series = []; bad_series = []
    for wl in ("uniform", "hotcold", "jesd219", "seq"):
        f = os.path.join(a.endurance, f"{wl}_op70.csv")
        if os.path.exists(f):
            wa_series.append(dict(name=wl, pts=series_from(f, "mean_pe", "wa_window")))
            bad_series.append(dict(name=wl, pts=series_from(f, "mean_pe", "bad_grown")))
    charts.append(svg_lines(wa_series, "mean P/E cycles (scaled: rated = 1000)", "write amplification (window)", title="Write amplification vs wear, 7 % over-provisioning"))
    charts.append(svg_lines(bad_series, "mean P/E cycles (scaled: rated = 1000)", "grown-bad blocks", title="Bad-block consumption vs wear"))
    sp = []
    for op in (70, 150, 280):
        f = os.path.join(a.endurance, f"uniform_op{op}.csv")
        if os.path.exists(f): sp.append(dict(name=f"{op/10:.0f} % OP", pts=smooth(series_from(f, "mean_pe", "free_blocks"))))
    charts.append(svg_lines(sp, "mean P/E cycles (scaled)", "free blocks (9-sample average)", title="Free (spare) blocks vs wear (uniform random)"))
    for tag, title in (("ablate_hotcold_wlnone", "Erase counts, hot/cold, NO wear levelling"), ("ablate_hotcold_wlstatic", "Erase counts, hot/cold, dynamic + static wear levelling")):
        f = os.path.join(a.endurance, tag + "_hist.csv")
        if os.path.exists(f): charts.append(svg_hist(f, title))

ecc_html = ""
if a.analysis and os.path.exists(a.analysis):
    d = json.load(open(a.analysis))
    for name, rows in d["ecc_trend"].items():
        ecc_html += f"<h3>profile <code>{esc(name)}</code></h3><table><tr><th>P/E ÷ rated</th><th>retention</th><th>RBER</th><th>bit errors / codeword</th><th>P(codeword uncorrectable)</th></tr>"
        for r in rows:
            if r["retention_hours"] in (0.0, 8760.0) and r["pe_fraction_of_rated"] in (0.0, 0.5, 1.0, 2.0, 3.0):
                ecc_html += (f"<tr><td>{r['pe_fraction_of_rated']:.2f}</td><td>{'1 y' if r['retention_hours'] else '0'}</td><td>{r['rber']:.2e}{' (clamped)' if r.get('clamped') else ''}</td>"
                             f"<td>{r['expected_bit_errors_per_codeword']:.3g}</td><td>{r['p_codeword_uncorrectable']:.2e}</td></tr>")
        ecc_html += "</table>"

bench_html = ""
if a.bench and os.path.exists(a.bench):
    b = json.load(open(a.bench))
    bench_html = "<table><tr><th>workload</th><th>QD</th><th>blocks/cmd</th><th>cmds</th><th>MB/s*</th><th>IOPS*</th><th>lat p50</th><th>p95</th><th>p99</th><th>p99.9</th><th>max</th></tr>"
    for r in b.get("phases", []):
        bench_html += (f"<tr><td>{esc(r['name'])}</td><td>{r['qd']}</td><td>{r['len']}</td><td>{r['cmds']}</td><td>{r['mb_s']:.2f}</td><td>{r['iops']:.0f}</td>"
                       f"<td>{r['lat_p50_us']:.1f}</td><td>{r['lat_p95_us']:.1f}</td><td>{r['lat_p99_us']:.1f}</td><td>{r['lat_p999_us']:.1f}</td><td>{r['lat_max_us']:.1f}</td></tr>")
    bench_html += "</table><p class='note'>* simulation cycles converted at an ASSUMED 100 MHz core clock (latencies in µs on the same assumption). NAND array times in the twin were scaled 1/10 for simulation speed. Not hardware measurements.</p>"

css = """
:root{--bg:#f6f7f9;--fg:#1d232b;--mut:#5c6673;--card:#fff;--bd:#d8dde4;--acc:#1f6feb;--warn:#b26a00;--bad:#b3261e;--c0:#1f6feb;--c1:#c2410c;--c2:#15803d;--c3:#7e22ce;--c4:#0f766e;--c5:#a16207}
@media (prefers-color-scheme:dark){:root{--bg:#12161c;--fg:#e6e9ee;--mut:#9aa5b4;--card:#1a2029;--bd:#2c3542;--acc:#5aa2ff;--warn:#e0a23a;--bad:#ff8077;--c0:#5aa2ff;--c1:#fb923c;--c2:#4ade80;--c3:#c084fc;--c4:#2dd4bf;--c5:#facc15}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:15px/1.5 system-ui,Segoe UI,Roboto,sans-serif}
main{max-width:1100px;margin:0 auto;padding:24px 16px 48px}h1{font-size:22px;margin:0 0 4px}h2{font-size:17px;margin:32px 0 10px;border-bottom:1px solid var(--bd);padding-bottom:6px}h3{font-size:14px;margin:16px 0 6px}
.banner{background:var(--card);border:1px solid var(--warn);border-left:4px solid var(--warn);padding:10px 14px;border-radius:6px;color:var(--fg);margin:12px 0 4px}
.tiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:10px}.tile{background:var(--card);border:1px solid var(--bd);border-radius:8px;padding:10px 12px}
.tile.warn{border-color:var(--warn)}.tile.bad{border-color:var(--bad)}.tl{font-size:12px;color:var(--mut)}.tv{font-size:20px;font-weight:600;margin:2px 0}.tn{font-size:12px;color:var(--mut)}
.charts{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:14px}.charts svg{width:100%;height:auto;background:var(--card);border:1px solid var(--bd);border-radius:8px}
.ct{font:600 12px system-ui;fill:var(--fg)}.ax{font:11px system-ui;fill:var(--mut)}.grid{stroke:var(--bd);stroke-width:1}.ln{stroke-width:2}.bar{fill:var(--acc)}
.c0{stroke:var(--c0)}.c1{stroke:var(--c1)}.c2{stroke:var(--c2)}.c3{stroke:var(--c3)}.c4{stroke:var(--c4)}.c5{stroke:var(--c5)}
.c0t{fill:var(--c0)}.c1t{fill:var(--c1)}.c2t{fill:var(--c2)}.c3t{fill:var(--c3)}.c4t{fill:var(--c4)}.c5t{fill:var(--c5)}.lg{font:11px system-ui}
table{border-collapse:collapse;background:var(--card);width:100%;font-size:13px}th,td{border:1px solid var(--bd);padding:5px 8px;text-align:right}th:first-child,td:first-child{text-align:left}th{background:var(--bg)}
.note{color:var(--mut);font-size:12px}code{background:var(--card);padding:1px 4px;border-radius:3px;border:1px solid var(--bd)}
"""
doc = f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SilicaFlux-STORE health dashboard</title><style>{css}</style></head><body><main>
<h1>SilicaFlux-STORE storage health dashboard</h1>
<div class="banner"><b>Simulation data only.</b> Telemetry is the controller's GET_LOG page from an RTL simulation against the NAND digital twin; endurance
charts come from a host simulation of the production FTL with an uncalibrated wear model and a <i>scaled</i> rated endurance. Nothing here is a hardware
measurement or a drive endurance rating.</div>
<h2>Drive health (GET_LOG)</h2>
{('<div class="tiles">' + ''.join(tiles) + '</div>') if tiles else '<p class="note">No GET_LOG dump supplied.</p>'}
<h2>Endurance and wear (model)</h2><div class="charts">{''.join(charts)}</div>
<h2>ECC consequence of wear (analytic, BCH t = 8)</h2>{ecc_html or '<p class="note">no analysis supplied</p>'}
<h2>Performance (RTL simulation)</h2>{bench_html or '<p class="note">no benchmark supplied</p>'}
</main></body></html>"""
os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
open(a.out, "w").write(doc)
print("wrote", a.out, f"({len(doc)//1024} KiB)")
