# 10 — DFT and manufacturing readiness

Authoritative text: [`../dft/README.md`](../dft/README.md), [`../dft/test_strategy.md`](../dft/test_strategy.md), [`../dft/functional_test_plan.md`](../dft/functional_test_plan.md).

Summary: a JTAG TAP + test-mode controller + register bridge (TestCore P07) is integrated and exercised (IDCODE `0x15F07001`, **placeholder manufacturer field**); reset/power sequencing and the power-fail filter are integrated; the full-chip regression doubles as the functional production-test vector set. **MBIST is not wired to the SoC SRAMs** (engine instantiated, bank bus tied off — documented gap), **no scan insertion, no ATPG, no fault-coverage number, no boundary scan, no wafer/package test, no DRC/LVS, no qualification** have been executed for this design. Those items are strategy only; none may be claimed.
