# 09 — Physical design (open-source flow, sky130hd, one block, NOT signoff)

> **Scope in one sentence:** the *page-engine block* (`sfx_page_engine` = BCH t = 8 ECC engine from P54 + XTS-AES-256 core + SFB2 pump, the P60-specific datapath) was taken through
> Yosys → OpenROAD (floorplan, I/O placement, power grid, global placement, clock-tree synthesis, timing repair, global routing; a bounded detailed route was attempted and **did not converge**) on the **open SkyWater sky130hd** views,
> typical corner only, with placeholder constraints. The **full chip was not placed and routed**. **No DRC, LVS, extraction signoff, multi-corner timing, IR drop, EM, antenna or foundry signoff was run, and none is claimed.**

## 1. Technology data (legal, open)
`pd/pdk/` holds the sky130hd Liberty (`tt_025C_1v80`), the merged cell LEF and the tech LEF — open SkyWater PDK views (Apache-2.0) copied from the OpenROAD repository test data, with hashes in `pd/pdk/SHA256SUMS` and provenance in `pd/pdk/NOTICE.md`. No proprietary foundry data, no NDA material and no fabricated "signoff" decks are included. A real tape-out would use the foundry PDK, SRAM compilers/macros, I/O library and PLL, none of which are available here (see `11_KNOWN_LIMITATIONS.md`).
The P40 floorplan archive in the original repository is incomplete (its `physical/` pipeline and Nangate45 files are absent — `audit/support_blocks_audit.md`), so this flow was rebuilt on the views that exist.

## 2. Flow (`pd/run_block_pd.sh`, `make pd`)
1. Yosys 0.33: `synth -flatten`, `dfflegalize` + `dfflibmap` (sky130hd flops), `abc -D <period>` mapping to the Liberty, `setundef -zero`, `splitnets`, `hilomap` (one `conb_1` tie cell per constant), `insbuf` (buffers for assign aliases), `check -assert`.
2. OpenROAD 26Q3: `initialize_floorplan -utilization 40`, `place_pins`, `pdngen` (met1 follow-pins + met4/met5 straps), `global_placement`, `repair_design`, `detailed_placement`, `clock_tree_synthesis` (TritonCTS), `repair_timing -setup`, `global_route` (layer adjustment 0.3), then `detailed_route` with an **iteration cap** (the cap keeps the run time bounded; a non-zero violation count at the end is reported, not hidden).
3. Constraints (`pd.sdc`, generated): one clock, **15 ns (66.7 MHz) — a placeholder**, I/O delays 30 % of the period, `rst_n` false-path. They are not derived from any system requirement.
4. Reports are written at the global-route stage (before the slow, least predictable detailed route) and again after it; in this release only the global-route-stage reports exist.

## 3. Results

Block `sfx_page_engine` (flattened: BCH t = 8 encoder/decoder with its page buffers, XTS-AES-256 core, SFB2 pump). Typical corner (`tt_025C_1v80`), 15 ns placeholder clock. Raw reports: `reports/logs/pd_*`.

| Item | Value |
|---|---|
| Synthesis (Yosys + abc, sky130hd) | cell area **824 737 µm²** (0.825 mm²); 94 648 instances at floorplan; 16 308 flip-flops |
| Floorplan | die 1 452 × 1 452 µm, core 2.057 mm² at 40 % target utilisation, 193 I/O pins |
| After placement, CTS and timing repair | 100 456 cells, design area **936 361 µm² (46 % utilisation)**: sequential 16 308 cells / 339 613 µm², combinational 78 077 / 487 277 µm², clock buffers 2 672 + clock inverters 1 361 (75 664 µm²), timing-repair buffers 1 775 (32 719 µm²); 0 placement failures |
| Clock tree (TritonCTS) | one clock net, 16 308 sinks, 2 327 clock buffers, 6 buffer levels, setup skew −0.13 ns |
| Setup timing, 15 ns, global-route parasitic estimates | `repair_timing`: *no setup violations*; WNS 0.00 / TNS 0.00; worst slack **+2.92 ns** — the three worst paths are the combinational register-read path `rb_addr → rb_rdata` under the 30 % I/O-delay constraint, so register-to-register paths have ≥ 3.0 ns of slack (≈ 83 MHz capability at this corner and estimate quality) |
| Hold timing | worst slack **+0.445 ns** (met) |
| Power (vectorless default activity, typical corner) | **0.105 W**: clock 49.5 % (51.8 mW), sequential 41.8 % (43.8 mW), combinational 8.8 % (9.2 mW), leakage ≈ 0 |
| Global routing | completed; guides written (`route.guide`) |
| Detailed routing | **NOT COMPLETED.** The bounded detailed route (cap 4 iterations) was started and stopped by hand: violations were 54 885 after iteration 0 and 27 642 after iteration 1 (≈ 45 min per iteration on one core), i.e. **the block was not routed DRC-clean**. No post-route timing, no final DRC count and no routed database exist; all timing/power/area figures above are from the stage before detailed routing. Likely contributors: ≈ 100 k cells with ≈ 16 k flop-array flops, `set_global_routing_layer_adjustment 0.3`, and a pin-access-heavy sky130hd netlist; a real flow would use SRAM macros (far fewer cells) and routing-driven floorplan iteration. |

Reading: the numbers are **post-placement/global-route estimates for one block with placeholder constraints**; they say the flow works on this block and that timing is not the problem at 15 ns on sky130hd typical — they are not a frequency, area or power claim for any product. The power figure uses default switching activity (no simulation vectors) and is only useful for the *relative* split (half of it is the clock tree because of 16 k flops).

## 4. Failures hit on the way (kept because they show the state of the flow)
| Problem | Cause | Fix |
|---|---|---|
| "undriven outputs" from `check -assert` | liberty cells unknown when read without `-lib` | `read_liberty -overwrite -setattr liberty_cell -lib` |
| OpenROAD `RSZ-0089` | no wire RC set | `set_wire_rc -signal -layer met2 / -clock -layer met5` |
| `DRT-0305: Net zero_ of signal type GROUND is not routable` | the synthesised netlist contained `1'bx` bits (out-of-range selects in P54's key-equation solver, `sfecc_bch_kes.sv:146`) that OpenROAD turns into a constant net | `setundef -zero`, `splitnets`, `hilomap` without `-singleton`, `insbuf` |
| `STA-0566` on `report_design_area > file` | OpenROAD-native reports do not support `>` | no redirect; values taken from the log |
| Detailed route not finishing in reasonable time | ≈ 95 k instances / 16 k clock sinks, ≈ 55 k violations after iteration 0 | reports moved to the global-route stage; iteration cap |

## 4a. Observations that matter for a real implementation
* The block is **large for what it does** because P54's page decoder keeps its codeword/correction buffers as **flop arrays** (Yosys: "Replacing memory … with list of registers"; ≈ 16 k flops, 49.5 % of the estimated power is the clock tree). With SRAM macros (or BRAM on FPGA) the flop count and area fall substantially. This is the single most useful PD lesson of the exercise.
* `sfecc_bch_kes.sv:146` has out-of-range part-selects (`Range [-1:-8] select out of bounds`) that a 2-state simulator evaluates as zero and Yosys as `x`; the bit-exact RTL-vs-reference results in simulation were not affected, but the logic that consumes them must be reviewed and cleaned in P54 before an ASIC flow (reported here; the vendored RTL was not changed).
* No SRAM macros exist in this flow: the ≈ 112 KiB of ControlCore/buffer memories of the full chip are flop arrays in the generic backend and would be compiler macros in a real flow; IMEM/DMEM/buffer macro placement, MBIST wrapping and the power grid for them are untouched.

## 5. What would be required for a signoff claim (not done)
Full-chip synthesis with macros; floorplan with I/O ring and PLL; DFT insertion (scan/MBIST) and ATPG; multi-corner multi-mode STA with extracted parasitics (SPEF); IR-drop/EM; clock-gating verification; DRC/LVS/antenna on the foundry deck; formal equivalence of netlists; gate-level simulation with SDF; power-intent (UPF) checks. None of these has been run.
