# 04 — SecureStore (new in P60): data-at-rest encryption, keys, integrity

Project 59 does not exist in the repository (`00_AUDIT_P51_P59.md`), so this block was written for P60.

## What is implemented
* **`sfx_aes_xts`** — XTS-AES (IEEE 1619-2007 / NIST SP 800-38E), no ciphertext stealing, whole 16-byte blocks. `KEYBITS` = 128 or 256 per key
  (XTS-AES-128: 256-bit key; **XTS-AES-256: 512-bit key — the SoC build**). Iterative AES, 12 cycles/block (128) or 16 (256); key expansion 85/109 cycles.
* Tweak = physical page number (so the same plaintext at two locations differs; GC re-encrypts on relocation because the FTL always
  handles plaintext). Only the 512 data bytes are encrypted; the 16-B FTL spare record is not (the FTL scans it at mount).
* **Key handling.** Key words are written through a **write-only register window** (reads return 0); schedules are expanded into registers with no read path to any
  output; `KEY_ZEROIZE`/reset clears raw key, schedules, tweak and state. The key is supplied by the host after every boot (mailbox
  `KEY_LOAD` ×3 + `KEY_COMMIT`); the firmware's staging copy is zeroised; nothing is stored in NAND. There is **no key hierarchy, no KDF, no TRNG, no OTP/eFuse, no
  secure boot** (P28 is not integrated) and **no authentication of the host or of the firmware** (CRC32 only).
* **Policy tests (XTS firmware, `scenario=security`/`keypolicy`).** (a) the plaintext of a written LBA is absent from the NAND medium in XTS mode and
  present in plain mode; (b) after a power cycle with a **wrong key** the FTL cannot mount (metadata decrypts to garbage), the controller refuses to serve,
  and the medium is untouched; the right key then mounts and all data is intact; (c) after `KEY_ZEROIZE` (crypto-erase) reads fail explicitly
  (`MEDIA_UNREC`) rather than returning data; (d) an independent Python check (`tools/check_xts_nand.py`) recomputes XTS of the plaintext from the
  oracle and compares it with the raw bytes on the simulated medium (key and tweak = physical page).

## Verification of the core (details: `rtl/security/README.md`)
Icarus and Verilator at both key sizes (3.2 M / 4.0 M and 8.6 M / 10.8 M checks): FIPS-197 / SP 800-38A known answers on the standalone AES core, 310
random units per key size against python `cryptography` (OpenSSL) as encrypt, decrypt and round trip, gap/back-pressure, `key_zeroize` injected at every
cycle of a 3-block unit and at 32–40 points of key expansion, reset mid-unit, hierarchical proof that all key-bearing registers read zero after zeroize,
21/21 injected RTL bugs caught. **Not verified:** only IEEE-1619 vectors 1–3 carry hard-coded published ciphertexts (typed from memory); no NIST CAVP
files were available offline; no timing/side-channel analysis, no formal, no gate-level run. The page engine adds 124 339 checks per configuration.

## Limits stated plainly
* A hash of each plaintext page (CRC-32) and the LPN/SEQ sit in the clear in the spare area (see `03_DATAPATH_AND_DURABILITY.md`); a keyed MAC would be the fix.
* XTS gives confidentiality only; it is malleable at 16-byte granularity. Integrity comes from the FTL CRC-32 (accidental corruption), not from a MAC.
* Whole-device mode chosen at firmware build (`p60_fw` vs `p60_fw_xts`); the mode is not recorded on the medium.
* No TCG Opal / NVMe Security Send/Receive; the key arrives over a mailbox from a host that is itself trusted.
