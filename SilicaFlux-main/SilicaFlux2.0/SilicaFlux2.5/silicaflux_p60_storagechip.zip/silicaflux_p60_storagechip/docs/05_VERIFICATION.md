# 05 — Verification: what was run, what it proves, what it does not

All numbers in this document come from runs executed in this container (Verilator 5.020, Icarus 12, Yosys 0.33/0.70, SymbiYosys, riscv64-unknown-elf-gcc 13.2).
Results are **simulation** results; nothing here is FPGA, silicon or real-NAND evidence.

## 1. Layers

| Layer | What | Independent reference | Where |
|---|---|---|---|
| L0 inherited | P51 SoC, P52 twin, P54 BCH, P56/P58 FTL, P07 TestCore were re-run by auditors before use | their own testbenches / Python models | `docs/audit/` |
| L1 unit | `sfx_page_engine` (BCH enc/dec over the SFB2 master, XTS in place) vs P54 golden vectors for the new `N512T8U16` layout and vs Python XTS; stall/latency sweeps for XTS-128 and -256 | P54 Python/galois reference; `cryptography` (OpenSSL) XTS | `tb/storage/` (`make unit-engine`) |
| L1 unit | `sfx_aes_xts` (AES-128/256 core, key schedule, XTS-AES; no ciphertext stealing by design: unit length is a multiple of 16 bytes): known-answer vectors, random vectors, long units; Icarus + Verilator + lint + Yosys | Python golden model + OpenSSL | `tb/security/` (`make unit-security`) |
| L1 unit | FPGA UART bridge + host-memory BRAM | self-checking TB | `fpga/tb/` (`make unit-fpga`, 13 checks) |
| L2 formal | SFB2 host-BAR splitter (single outstanding request, no local request reaches the SoC, local access uses the capture register, responses occur — cover); power-fail glitch filter (k-induction, covers) | SymbiYosys (`abc pdr`, `smtbmc z3`) | `formal/` |
| L3 full chip | `silicaflux_storage_top` (RTL ControlCore running the **real firmware**, SFB2 fabric, page engine, buffer SRAM, NAND sequencer) + P52 NAND twin + host-queue driver with a **per-LBA oracle** (last acknowledged generation, in-flight generation, in-flight TRIM) | the oracle in the testbench (written independently of the firmware); Python XTS cross-check of the NAND contents | `tb/soc/`, `scripts/regress.py` |
| L4 model | endurance / wear (host simulation of the production FTL on the twin rules) and analytic ECC consequence | exact binomial tail; Poisson cross-check | `endurance/`, `reports/ENDURANCE.md` |

Not used: cocotb (the full-chip bench is a Verilator-native SystemVerilog testbench driving the real BAR protocol); concurrent SVA is **not** bound into the chip RTL — assertions
live in the formal harnesses (`formal/`) and as testbench checks (n.b. immediate assertions, not concurrent properties). No UVM, no emulation.

## 2. Full-chip scenario set (what each one is for)

| scenario | purpose | notable checks |
|---|---|---|
| `smoke` | definition of done for the datapath: command → DMA → integrity → ECC → NAND program/read → completion | IDENTIFY, write/read/overwrite/unwritten-reads-zero |
| `integrity` | full sequential fill + verify, then a seeded mixed workload (60 % writes of 1–4 LBAs, a quarter of them FUA; 30 % reads; 5 % TRIM; 5 % FLUSH) that drives GC and overwrite | every read compared with the oracle; full-namespace verify before and after |
| `random` (3 runs, one with the `stress` NAND profile) | seeded constrained-random commands (lengths 1–16 = up to MDTS), up to 6 commands in flight on non-conflicting LBA ranges, TRIM, flush | oracle; no dropped/duplicate/unknown completions |
| `ecc` | k = 0..8 injected raw bit errors per page are corrected exactly; k = 9..12 reports `MEDIA_UNREC` with the NAND-ECC error code — **never wrong data**; neighbours unaffected; rewrite repairs | GET_LOG counters (corrected bits, uncorrectable pages) |
| `invalid` | unknown opcode, reserved flag bit, LEN = 0, LEN > MDTS, first LBA past the end, range straddling the end, misaligned host buffer, physical addressing while disabled, address bits above the implemented width: each rejected with the specified status/error code; data intact afterwards | status + error codes |
| `concurrency` | queue depth = number of tags (8) in flight; no drops, no duplicates | per-TID completion accounting |
| `backpressure` | host-memory model stalls (50 % back-pressure, up to 8 cycles latency) for reads and writes; completion queue deliberately filled (HQD−1 commands) before the host reaps | every queued command completes exactly once; data intact |
| `ctrlreset` | controller reset (CTRL.EN 1→0) with commands in flight, then re-enable | in-flight commands are aborted and reported, acknowledged data remain |
| `plp` | power-fail (brown-out) pin asserted with writes in flight: STOP policy — firmware quiesces, WP# asserted, in-flight commands aborted with `ABORT_PWR_LOSS`; remount after restore; no hold-up energy assumed | completion status vs medium contents (oracle) |
| `top` | top-level: JTAG IDCODE read through the real TAP, TestCore registers via the BAR, scan/test pins, perf counters, IRQ/event paths | |
| `badblock` | factory-bad blocks (13, 41), forced program failure (block 25, after 3 programs), forced erase failure (block 30) configured in the twin | firmware retires blocks, data intact, counters in GET_LOG |
| `security` (XTS firmware) | key load/commit, ciphertext on the NAND ≠ plaintext and = Python XTS, key policy: wrong key → controller refuses (never serves garbage), right key → data back, KEY_ZEROIZE → explicit error | `tools/check_xts_nand.py` on the NAND dump |
| `noformat` | **boot policy**: checkpoint+journal pages destroyed on a non-blank medium → controller not ready, FATAL stage, medium bit-for-bit untouched; wrong-magic REBUILD/FORMAT rejected; explicit REBUILD recovers every acknowledged LBA; REBUILD/FORMAT refused while mounted; explicit FORMAT gives an empty device | image hash before/after |
| `crash` | **power-loss campaign**: random workload (queue depth 1–4, writes/TRIM/flush on a 24-LBA working set after a full prefill), supply cut (SoC reset + NAND Vcc drop, the twin tears the in-flight program/erase) at a random cycle, re-boot; with probability 1/3 per re-boot a *nested* cut while the firmware recovers (repeatable; not in XTS mode); after every re-boot each LBA with an in-flight command, plus a sample of the rest (all LBAs on every 4th and the last cycle), must hold the last acknowledged generation or the in-flight generation (never an older one, never a mix) | `lost-acked` counter must stay 0 |
| `bench` | performance and recovery-overhead measurement (see `06`) | |

Properties checked implicitly in every run: no completion for an unknown TID, no duplicate completion, no missing completion (timeout), 0 NAND protocol errors and 0 AC-timing violations
from the twin's rule checker, firmware `SHUTDOWN` reports 0 firmware errors and the testbench failure count agrees with the firmware's view.

**Durability rule being tested:** a write is acknowledged only after the page program has been confirmed by NAND status and the mapping updated; each page carries LPN + 48-bit sequence + CRC-32
in its spare record, so acknowledged data survive without any checkpoint (roll-forward). The crash campaign is the evidence for that sentence; it is statistical (random cut points), not exhaustive.

## 3. Defects found by this verification (and fixed)

Real bugs that the testing exposed, in order of discovery — listed because they show what the tests are able to catch and because two of them were **firmware correctness** problems, not test problems.

| # | Found by | Defect | Fix |
|---|---|---|---|
| 1 | crash campaign, first boot after the first power cut | The NAND's *volatile timing mode* returns to mode 0 at power-up, but the HAL kept programming mode-5 timings → every NAND access after a power cycle ran out of spec; the FTL saw an unreadable device | HAL programs ONFI mode-0 timings (`TIMING0=0x05050505`, `TIMING1=0x00001414`) at every boot; the twin starts in mode 0 |
| 2 | same campaign, consequence of 1 | **Unsafe boot policy**: "no checkpoint → rebuild from spare records → format if nothing is recovered" turned the timing fault into a **format of good data** | boot policy made strictly conservative (never format a non-blank medium; explicit REBUILD / FORMAT management commands) — see `03_DATAPATH_AND_DURABILITY.md` §4, scenario `noformat` |
| 3 | crash campaign | A rebuild-mount **writes a checkpoint**, so an automatic rebuild on a merely unreadable medium would leave a valid *empty* checkpoint and the next boot would serve an empty device over unreadable data | rebuild only on explicit command; blank check performed before any write |
| 4 | auditor (P56) | One damaged newest checkpoint-commit page left the volume unmountable in 166/300 seeds | closed by using the P58 "1.1" library (A/B checkpoint retention) |
| 5 | testbench, while debugging 1–3 | The testbench's own `srv_do_cmd` kept the first command's TID across calls; after a reboot cleared the `seen` table every command appeared to hang (the firmware had in fact completed it — confirmed from the HIF `submitted/completed` counters and the sleeping CPU). **A testbench defect, not a design defect**, but it cost several debugging cycles and showed that "command did not complete" needs the diagnostics now built in (firmware PC, HIF counters) | single-TID wait without a persistent queue |
| 6 | first full-chip scenario runs | `SFS_SQE_FLAG_PHYS` is a bit index, not a mask (literal used in the TB) | testbench fix |
| 7 | synthesis | Yosys cannot parse `import pkg::*;` in module headers; the P51 flow's package-hoisting is reproduced in `scripts/synth.py` | flow fix |
| 8 | first complete matrix | `security_xts` failed 2 checks: the new refusal path printed a console line that the testbench's "mount failure reported" counter did not match (the failure then propagated into the firmware's end-of-run flag, which carries the testbench failure count). Test/firmware message mismatch, no data-path effect | firmware message aligned (`[ftl] boot failed: …`); the complete matrix was re-run on the final binaries |

## 4. Results

(Verbatim from `reports/regression_summary.md`, generated by `scripts/regress.py`; per-run logs are under `reports/logs/`.)

Binaries: testbench `build/tb_fin/v/Vtb` (sha256 57f211e3442a…), firmware `p60_fw.hex` (sha256 feed76323e64…), `p60_fw_xts.hex` (sha256 ecea8c9efb76…). Run: 2026-11-13 05:55 UTC.

| run | scenario | seed | checks | failures | cycles | wall s | verdict |
|---|---|---|---|---|---|---|---|
| smoke | smoke | +seed=1 | 32 | 0 | 5095789 | 31 | **PASS** |
| invalid | invalid | +seed=1 | 48 | 0 | 5183984 | 32 | **PASS** |
| top | top | +seed=1 | 61 | 0 | 5392157 | 32 | **PASS** |
| ecc | ecc | +seed=1 | 77 | 0 | 6404995 | 47 | **PASS** |
| concurrency | concurrency | +seed=1 | 94 | 0 | 6869849 | 51 | **PASS** |
| backpressure | backpressure | +seed=1 | 95 | 0 | 6706473 | 50 | **PASS** |
| ctrlreset | ctrlreset | +seed=1 | 800 | 0 | 10954285 | 104 | **PASS** |
| plp | plp | +seed=1 | 800 | 0 | 16096250 | 202 | **PASS** |
| integrity | integrity | +seed=1 | 2278 | 0 | 92787257 | 1002 | **PASS** |
| random_s1 | random | +seed=1 | 2066 | 0 | 54368242 | 531 | **PASS** |
| random_s2 | random | +seed=2 | 2032 | 0 | 61138519 | 554 | **PASS** |
| random_stress | random | +seed=3 | 1762 | 0 | 44697495 | 673 | **PASS** |
| badblock | badblock | +seed=1 | 3173 | 0 | 134237892 | 1794 | **PASS** |
| security_xts | security | +seed=1 | 960 | 0 | 24129975 | 422 | **PASS** |
| noformat | noformat | +seed=1 | 2517 | 0 | 42121557 | 698 | **PASS** |
| crash_s1 | crash | +seed=1 | 1896 | 0 | 100444852 | 1166 | **PASS** |
| crash_s2 | crash | +seed=2 | 1894 | 0 | 105414973 | 957 | **PASS** |
| crash_s3 | crash | +seed=3 | 1884 | 0 | 108488670 | 785 | **PASS** |
| crash_xts_s4 | crash | +seed=4 | 1004 | 0 | 59378082 | 480 | **PASS** |

Line items not in the table (each executed in this container; logs under `reports/logs/`):

| check | result |
|---|---|
| page engine unit bench (`make unit-engine`): XTS-AES-256 and -128 × three stall/latency settings, BCH enc/dec vs P54 golden vectors (`N512T8U16`) | 6 runs × 124 339 checks, 0 errors |
| XTS-AES core unit benches (`make unit-security`): golden-model self-test, lint, Icarus, Verilator, Yosys statistics | Icarus 3 225 996 / 3 995 181 checks (128/256-bit keys), Verilator 8 553 876 / 10 776 452 checks, lint 0 warnings; ALL PASS |
| FPGA UART bridge + host-memory BRAM (`make unit-fpga`) | 13/13 |
| formal (`make formal`): splitter and power-fail filter, tasks bmc / prove / cover | 6/6 PASS |
| ciphertext on the NAND vs OpenSSL XTS-AES-256 (`tools/check_xts_nand.py` on the `security` run) | 48 pages, 0 mismatches, 0 pages equal to plaintext |
| whole-top lint (`verilator --lint-only -Wall`) | 0 errors; 8 warnings, all in vendored ControlCore files |

Notes on the table: the `crash_*` rows are the power-loss campaigns (`crash_xts_s4` runs the XTS firmware; nested cuts are disabled there because the key must be re-provisioned after each boot).
A first complete matrix was run before the final firmware/testbench and showed one failure (`security_xts`, defect 8 in §3: the testbench counted a console message the new boot policy words differently; every other run passed); it is kept as
`reports/logs/regression_prelim_before_final_firmware.md`. The table above is the complete re-run on the final binaries named in its header.


## 5. Coverage

* **Functional counters** (printed as `TB COV:` lines and collected in the regression summary): injected-error histogram k = 0..12, transfer-length histogram 1..16, operation mix, number of in-flight commands at each power cut, nested crashes, unacknowledged commands that had taken effect.
* **Line coverage** of the Verilated RTL (`reports/COVERAGE_RTL.md`; Verilator `--coverage-line`, 15 coverage runs merged — all PASS, list in `reports/logs/coverage_runs.txt`; a "line" is a statement/branch point, covered = every point on the line hit). **Not signoff coverage, no toggle/FSM/assertion coverage.**

| scope | fully covered | note |
|---|---|---|
| **P60-authored RTL** (`rtl/`: top, page engine, XTS-AES core, subsystem glue) | **187 / 217 (86 %)** | XTS core 97–100 %, page engine 85 %, top control 74 % |
| vendored P51 subsystem (`vendor/p51/rtl`: host IF, command controller, DMA, NAND sequencer, sys regs) | 335 / 417 (80 %) | |
| vendored P54 BCH ECC | 135 / 174 (78 %) | |
| vendored ControlCore / DataFabric / SRAM library | 800 / 1 188 (67 %) | CPU features (e.g. CSR/trap corners) the firmware does not use |
| vendored P07 TestCore | 89 / 307 (29 %) | JTAG/MBIST/test-mode controller are exercised only by the `top` scenario's IDCODE and register reads; the MBIST bank bus is tied off |

  **Uncovered in P60-authored RTL, by cause:** (1) *register paths the firmware never uses* — page-engine counter-clear register (`sfx_page_engine.sv:296`), top-control IRQ-raw, BAR-counter, power-fail-counter reads and the reset-cause W1C merge with a concurrent event (`sfx_top_ctrl.sv:116–157`); (2) *invalid-operation rejection in the page engine* (`:312`, the firmware never issues an out-of-range opcode — a directed negative test is a gap); (3) *FSM `default:` safety branches* that are unreachable by construction (`sfx_page_engine.sv:436`, `sfx_hb_split.sv:84`, `sfx_aes_xts.sv:218`). The first two are **real, small test gaps** rather than dead code.
* **Scenarios known NOT covered** (stated so that nobody assumes otherwise): multi-channel operation; queue depth > 8 and HQD wrap under load beyond the random scenario; XTS with nested crashes; NAND read-disturb/retention behaviour beyond what the twin models; ECC miscorrection beyond the CRC-16 backstop (probability analysed, not exhaustively tested); firmware-bug-induced early acknowledgement (there is no independent hardware completion gate; only the oracle would notice); SRAM macro faults (flop-array SRAM); real PCIe/NVMe; power-fail during checkpoint with *hold-up energy* (no PLP exists); EMI/voltage-droop effects; multi-die; temperature.

## 6. Limits of the evidence
* The oracle is written by the same team as the firmware; it is independent code but not an independent *specification*.
* The NAND twin is synthetic: it is a faithful *rule checker* for the command protocol but its error and wear behaviour is illustrative, so ECC strength (t = 8) and endurance results are model statements.
* Random campaigns establish *absence of observed failure* in the sampled space, not a proof. Mutation testing was done by P58 on its own library; **no mutation campaign was run on the P60 integration layer** (HAL, page engine, command executor).
