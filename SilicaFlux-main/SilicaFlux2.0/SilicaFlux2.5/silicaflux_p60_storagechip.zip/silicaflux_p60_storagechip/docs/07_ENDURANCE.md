# 07 — Endurance and wear model (model output, not a rating)

Results: [`../reports/ENDURANCE.md`](../reports/ENDURANCE.md) (+ `../reports/endurance.json`, dashboard charts). Reproduce: `make endurance` (≈ minutes; `endurance/run_endurance.sh`).

## What the model is
* The **production FTL** (P58 "1.1" library, the same C sources as the firmware) runs on the host against a simulated NAND (`endurance/endurance.c`) that applies the NAND-twin rules (erase-before-program, in-order programming, NOP limits) and **wear-dependent program/erase failure probabilities from the twin's formulas** (illustrative, uncalibrated coefficients).
* Rated endurance is **scaled to 1000 P/E cycles** so that end of life is reachable in seconds; the failure model is driven by the *mean* P/E of the device, so wear levelling does not "extend" the modelled life — the wear-levelling ablation therefore reports the *spread* of erase counts, not lifetime.
* Workloads: uniform random, hot/cold 90/10, sequential, and a JESD219-**style** mix (LBA-zone skew and transfer-size mix reproduced from memory; **JESD218/JESD219 were not accessible**, so conformance is not claimed). Over-provisioning 7/15/28 %, wear levelling none/dynamic/dynamic+static.
* ECC consequence: analytic RBER(P/E, retention) from the twin formulas → exact binomial tail P(more than t = 8 errors in a 4 344-bit codeword) (`1 − CDF` branch when the mean exceeds t; RBER clamped at 0.5), validated against a Poisson approximation.

## What it supports saying
Write amplification falls steeply with over-provisioning; static+dynamic wear levelling narrows the erase-count spread (290 → 245 vs 631 with none, hot/cold at 7 % OP); end of life in the model arrives when grown-bad blocks exhaust the spare pool (`ENOSPC`); the FTL never violated a NAND programming rule in any run (0 rule violations). 

## What it does **not** support
A drive-endurance rating, TBW/DWPD numbers, retention guarantees, or JEDEC compliance. A simulator with uncalibrated coefficients cannot certify any of those; they need characterisation of the real NAND (P/E cycling with bake, RBER vs cycles, read disturb) and the qualification flow of JESD218/219/47. Under the twin's deliberately harsh `stress` profile BCH t = 8 is **not** sufficient: P(codeword uncorrectable) ≈ 0.5 at 1× rated wear even without retention, and ≈ 1 at 0.5× rated wear after one year of retention (`reports/ENDURANCE.md`). That is a property of the *illustrative* coefficients, not of any real NAND, but it shows how the ECC choice must be re-derived from real RBER data.
