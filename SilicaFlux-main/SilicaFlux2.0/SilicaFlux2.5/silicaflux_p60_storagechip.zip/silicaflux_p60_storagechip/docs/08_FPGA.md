# 08 — FPGA prototype (board-independent wrapper; NO hardware results)

See [`../fpga/README.md`](../fpga/README.md) (status table + bring-up checklist) and [`../reports/fpga_resource_estimate.md`](../reports/fpga_resource_estimate.md).

* `fpga/rtl/silicaflux_store_fpga_top.sv` wraps `silicaflux_storage_top` (`SRAM_BACKEND = 1`, block-RAM inference) with a UART host bridge, a block-RAM host memory (DMA target; there is no PCIe) and tri-state NAND pins. `fpga/host_uart.py` is the bring-up host. `fpga/constraints/` contains **templates** with placeholder pins.
* **Evidence that exists:** wrapper RTL lints clean; UART bridge + host-memory unit test 13/13; Yosys pre-place-and-route resource estimates for 7-series and ECP5 (whole top, without the wrapper).
* **Evidence that does not exist:** place-and-route, timing closure, bitstream, board bring-up, data-integrity soak, any measured utilisation or frequency. The 20 ns period in `silicaflux_store.sdc` is a placeholder. The firmware's NAND timing registers were chosen for the simulated twin and must be re-derived from the target NAND datasheet.
* Full-chip firmware has **not** been run through the UART bridge (the full-chip testbench drives the BAR directly).
