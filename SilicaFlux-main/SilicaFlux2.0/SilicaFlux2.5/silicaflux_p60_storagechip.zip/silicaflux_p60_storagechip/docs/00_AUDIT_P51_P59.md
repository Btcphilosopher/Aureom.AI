# 00 — Repository audit of projects 51–59

*Audit date 2026-11-12/13. Evidence class: every "verified" entry below was re-run in this container by an auditor (a
sub-agent working from a brief that forbade accepting README claims) — commands, counts and wall times are in the full
per-project reports in [`audit/`](audit/). Anything not re-run is marked as such.*

## 1. Where the projects live

The programme sits in `SilicaFlux-main/` (nested `SilicaFlux2.0/SilicaFlux2.5/`) as zip archives. Nine projects are
numbered 51–59. **Eight exist; Project 59 (SecureStore) does not.** An exhaustive search found no SecureStore, no
storage encryption engine (no AES/XTS/GCM/HMAC RTL anywhere), no T10-PI implementation, no roadmap entry for a P59, in:
every member name of 400 zips (nested to depth 4, 49 341 members), the text of 37 PDFs, the full git history, and a
recursive extraction of all SilicaFlux archives (32 746 files) — see [`audit/p59_audit.md`](audit/p59_audit.md). The sibling
projects state the same (P51 "no encryption at rest, no key management"; P55 "`CRYPTO_EN` … explicitly **not a cipher**";
P57 "no protection information"). **P60 therefore had to create SecureStore** (`rtl/security/`), not integrate it.

Two archives exist for P58 (`powersafe-p58.zip` and `powersafe-p58 (1.1).zip`). They are **not** a version and an update:
they are independent implementations of the same brief (different source branches off one commit; only 14 of 80 files are
identical, all inherited from P56). They clash on RTL module names, register maps, C API and on-flash format. P60 uses
"1.1" (reasons in §3).

## 2. Status of each project (legend: V verified here · PV partially · M missing · X incompatible with a single top · S simulation-only · E depends on external/licensed IP)

| # | Project | Implemented | What was re-run here and passed | Gaps found | Used by P60? |
|---|---|---|---|---|---|
| 51 | StorageCore | yes — ControlCore (RV32IM) SoC, SQ/CQ host IF, command controller, DMA, DataFabric, buffer SRAM, NAND sequencer, firmware FTL | firmware rebuilds bit-identical (CRC32 `f7d46dd3`); register-map generator + 20/20 illegal-map rejections; subsystem TB on Icarus **and** Verilator for 3 configs (345/315/554 checks); full SoC TB with real firmware on the RTL CPU (152/142/195/152 checks, 2.03 M cycles, cycle-identical to the shipped logs); Verilator -Wall clean — **V** | FTL: 256 LBAs/channel, **no GC, no wear levelling, non-atomic checkpoint**; ECC = per-word SECDED (not NAND-grade); no authentication; private host ABI on a private bus; one-outstanding fabric (~1 word / 4 cycles); sim-only (**S**); SRAMs are flop arrays (**E** for macros) | **Yes — the base SoC** (ControlCore, host IF, cmd controller, DMA, fabric, buffer SRAM, NAND sequencer); subsystem patched (+page engine) |
| 52 | NAND Digital Twin | yes — pin-level SV model (non-synthesisable) **and** bit-exact Python twin, ONFI-style x8 SDR, persistence, torn programs/erases, fault injection | 32/32 Python tests; 128/128 SV checks on two simulators with exact SV-vs-Python replay; 35/35 pytest — **V** | **Entirely synthetic** (not calibrated to any device; ONFI timings transcribed from memory); regression-clean at one geometry only (512+16 B); a page-size change to 2048+64 B passes co-simulation bit-exactly but 2 statistical checks failed and were not root-caused (**PV**); no multi-plane/cache/DDR | **Yes — the chip-level media model**; one back-door (`bd_flip`) added by a documented patch |
| 53 | FlashLink | yes — synthesisable ONFI-style channel controller, run-time geometry discovery | lint 0 warnings on 7 parameter sets; 771/771 protocol checks over 7 configs — **V** | verified at one geometry and the error-free profile only; pin boundary is a simulation placeholder (**S**, no PHY); **never co-simulated with P54 or P51**; SDR only; 66–85 MHz on ECP5 | **No** — P51's NAND sequencer (verified together with the CPU firmware) is used; FlashLink remains a candidate channel controller |
| 54 | ECCCore | yes — synthesisable BCH engine (t=4/8/40) + page engine, CRC-16 miscorrection backstop, LDPC proof-of-concept | RTL vs Python reference bit-exact on 38 554 / 6 037 / 6 073 / 600 codewords with back-pressure and mid-traffic resets (0 errors); page engine 60/60/60/20 pages; twin campaign; lint of 14 tops; Yosys check clean — **V** | LDPC is a 128-bit PoC, simulation-only; t=40 decoder never routed; **spare area budget is exactly full in every shipped configuration** (no room for FTL metadata); stream interface (8-bit, spare-first) differs from P51/P53; never integrated | **Yes — the ECC engine**; new configuration `N512T8U16` added (512+32 B, 16 B metadata) and re-verified with P54's own page testbench |
| 55 | BufferCore | yes — banked parity SRAM buffer, DMA, CRC-32C + LBA tag, placeholder "crypt" stage | lint 9 configs; `make sim` 16 403 checks (+2 seeds); integration bench with FlashLink + NANDLab + MemoryBridge 1 059 checks — **V** | ECC placeholder SECDED(72,64); "crypt" is a keyed XOR, **not a cipher**; page image has **no room for the FTL's 16-B spare record** and duplicates the CRC; only small geometry exercised against a NAND model; DRAM adapter targets a simulated controller only (**E**) | **No** — format conflict with the FTL and with P54; P51's buffer path used instead |
| 56 | Flash Translation Engine | yes — page-mapping FTL in freestanding C99: GC, wear levelling, bad-block management, checkpoints, roll-forward recovery; HAL for P51 | host suite 27/27 (4 882 checks, incl. power cuts at 1 200 consecutive device operations); ASan/UBSan clean; 11/12 mutants killed; clean RV32 rebuild identical — **V**. The FTL-on-ControlCore RTL run did not complete in the auditor's time box (booted, formatted, filled and verified, 29.5 M of a claimed 345 M cycles) — **PV** | **Auditor finding: one damaged newest checkpoint-commit page left the volume unmountable in 166/300 seeds**, and the README boot snippet would then format (destroy) the medium; RAM-resident L2P (4 B/page); single-threaded, one channel | **Yes — as the algorithmic base**, through the P58 hardening below |
| 57 | NVMe HostCore | yes — NVMe-subset front end (SQ/CQ, PRP, doorbells, admin set) as a *simulation-grade* TL model on the P51 SoC | unit TB 12/12 runs (Verilator) + Icarus; full-SoC 49/49 and 335/335 checks; perf logs byte-identical — **V** | **No PCIe** (self-written transaction-layer model; no endpoint IP — **E**); not NVMe-conformant (no SGL/MSI-X, SMART fields read 0, placeholder VID); integrated top never synthesised; ~56 k LUT4 front end; 32-bit window | **No** — kept as the HPC-config candidate; not integrated (see `11_KNOWN_LIMITATIONS.md`) |
| 58 | PowerSafe (two archives) | yes — durable-write protocol (spare record + journal + commit-last checkpoints), completion gate, crash-injection framework, capacitor PLP *model* | P58: 15/15 campaigns, 4 569 checks, 3 418 runs, 4 002 injected crashes recovered, 0 violations. P58 "1.1": crash suite 5 497 checks, RTL+firmware co-simulation 4/4 (561 recovery boots), mutants 16/16 RTL + 10/10 firmware — **V** | The two archives are incompatible forks; **neither provides physical PLP** (`PLP_PRESENT=0`; capacitor models use placeholder values); neither firmware ever ran on the ControlCore RTL; "1.1" has no journal mirroring (an acknowledged TRIM can be lost if a journal page is damaged afterwards) | **Yes — "1.1" FTL library** (A/B checkpoint retention, schema 2, event log); the hardware completion-gate controller is **not** integrated |
| 59 | SecureStore | **no — does not exist** | — | — | **Created in P60** (XTS-AES core) |

Supporting blocks used by P60 (ControlCore P21, DataFabric P03, SRAM library, RAS P26, TestCore P07, SecureBoot P28,
DFTGrid P39, P40 floorplan build) are audited in [`audit/support_blocks_audit.md`](audit/support_blocks_audit.md):
ControlCore, DataFabric, sramlib, RAS and TestCore r2 re-ran clean; **the P40 floorplan archive is incomplete and cannot run**
(its `physical/` pipeline and the Nangate45 files are absent), so P60's physical-design flow was rebuilt on the
sky130hd views that *are* present.

## 3. Decisions that follow from the audit

1. **Base = P51**, the only member proven end-to-end with real firmware on the RTL CPU. Everything else plugs into it.
2. **FTL = P58 "1.1" library** (P56 core + A/B checkpoint retention). Chosen over P58 because it is the one wired to the
   P51 command types; it closes the P56 mount-failure finding (0/300 in the auditor's probe). Boot policy in
   `fw/app/ftl_glue.c` additionally **never formats a medium that is not verifiably blank** (explicit REBUILD / FORMAT management commands instead; see `03_DATAPATH_AND_DURABILITY.md` §4).
3. **ECC = P54 BCH t=8** with a new `N512T8U16` page layout, because the FTL needs 16 B of metadata under ECC and every shipped
   P54 configuration has zero spare slack. The new layout passes P54's own RTL-vs-reference page testbench.
4. **Media = P52 twin.** It speaks the same `00h…30h` / `80h…10h` protocol as P51's NAND sequencer; this had **no prior
   evidence** and works (0 protocol errors, 0 AC-timing violations in every P60 run).
5. **P55, P53, P57 and the P58 completion-gate RTL are not integrated** (reasons above). This is a scope decision, stated in the release report.
6. **Licensing:** no licence file exists anywhere in the repository; P54 bundles a GPL-2.0 `bch.c` used only as a software
   cross-check (not part of any P60 artefact). The owner must choose a licence before any redistribution.

## 4. Classification summary (P60 view)

| Class | Items |
|---|---|
| Implemented **and** verified in the P60 build | P51 SoC, P52 media, P54 BCH (new layout), P56/P58 FTL, P07 TestCore TAP |
| Implemented, verified only standalone | P53, P55, P57, P58 RTL controller, LDPC (P54) |
| Missing | P59 (created), physical PLP, PCIe/NVMe link, calibrated NAND, DRAM, SRAM macros |
| Incompatible (needs adaptation) | P55 page image vs FTL/P54; P58 vs P58 "1.1"; P54 stream interface vs P53 SFB2 |
| Simulation-only | everything (no FPGA/silicon/real NAND evidence exists for any project) |
| Depends on external/licensed IP | PCIe endpoint, DDR PHY/controller, SRAM macros, real NAND device/ONFI conformance |
