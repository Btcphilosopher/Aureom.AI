# Project 56 "FlashMap" (Flash Translation Engine) -- integration audit

Auditor environment: container, Verilator 5.020, Icarus 12, Yosys 0.33, gcc 13, `riscv64-unknown-elf-gcc` 13.2, Python 3.13.
Pristine extract: `$SP/audit/p56_flashmap/silicaflux-flashmap` (never built in). Work copies: `$SP/work/p56` (host tests/bench/mutation),
`$SP/work/p56_fwclean` (clean RV32 rebuild + RTL run). Raw logs: `$SP/audit_out/p56/`.
`SP=/tmp/claude-0/-home-user-Aureom-AI/c80a8d5d-1b1f-56e3-9758-b78cee890e29/scratchpad`.

**Environment caveat for every wall time below:** the 4-core container was shared with a dozen unrelated jobs
(load average 12 -> 29 while this audit ran), so all wall times are inflated (roughly 2-6x) and are not performance data.

---------------------------------------------------------------------------------------------------------------------

## 1. Summary verdict

* **What it is.** A real, compact, page-mapping FTL in freestanding C99 (`firmware/silicaflux_ftl/`, 10 source files, ~29.6 KB of RV32IM
  `.text`, 0 `.data`/`.bss`, no malloc) with a 5-function NAND HAL, a simulated-NAND HAL (host) and a HAL for the **P51** `sfs_nand_ctrl`
  register interface (ControlCore). It is **not** a C-model-only artefact: a RISC-V ELF/image exists, and I rebuilt it from clean and got a
  bit-identical `.img`.
* **VERIFIED by me (ran in this container, saw pass):** host suite 27/27 tests, 4 882 checks (incl. power cut at each of 1 200
  consecutive device operations, every operation of a recovery mount, 400 random cuts, 240 randomised runs); quick suite 27/27 under
  ASan+UBSan with 0 reports; mutation check 11/12 killed (the survivor is the one the README names); the performance bench
  reproduces the shipped `PERF.md` byte-for-byte (deterministic; write amplification 6.01 / 3.16 / 2.03 / 1.39 at 7/15/25/40 % OP).
* **NOT fully verified:** the FTL firmware on the ControlCore+P51 RTL (`make rtl`) did not complete in the 8-minute time-box (the shipped log
  says 13 m 52 s on an idle machine). I observed the real RV32 image boot through the ControlCore boot ROM (CRC 0x7bee70e7 accepted),
  initialise the P51 NAND controller (READ_ID 10a1da5f, 528-B ECC page), detect the two factory-bad blocks (13, 41), format, and pass
  "verify after sequential fill: 744 LBAs, 0 mismatches" at RTL cycle 29.5 M of a claimed 344.8 M. The rest (GC, TRIM, clean/unclean restart, grown
  bad block, SECDED errors on the RTL) is **not reproduced**.
* **Auditor finding (new, reproduced independently of the P58 documents):** a **single unreadable newest checkpoint-commit page makes the
  device unmountable (`SFFTL_ENOFS`) in 166 / 300 seeds** on the P51-class geometry with a TRIM-heavy workload (5 / 300 on a 128-block
  device; 0 / 300 on a few other geometries). Data is never returned wrongly (fails safe) but the volume is gone, and the README's
  boot snippet (`if (sfftl_mount()==SFFTL_ENOFS) sfftl_format()`) would then **erase the user's data**. Both P58 variants fix the mount
  failure (0 / 300 in the same probe).
* **Geometry reality check:** the only HAL that talks to hardware (`hal/sfs`) is hard-wired to the **P51** controller, 1 channel, 64 blocks x
  16 pages x 512 B (+16 B FTL spare inside one 528-B ECC codeword). It does **not** talk to the P53 FlashLink controller or the P55 BufferCore;
  nothing in it is multi-channel, asynchronous or DRAM-backed.
* **Reuse verdict:** reuse the FTL core (`src/`, `include/`) as the algorithmic base **together with the P58 hardening** (see p58_audit.md); do
  not reuse `hal/sfs` as is for a P53/P55 platform; the RAM-resident L2P (4 B/page, ~0.93 MiB per GiB at 4 KiB pages) needs a DRAM/demand-paged
  map for anything beyond a few thousand pages on the 32 KiB DMEM ControlCore.

---------------------------------------------------------------------------------------------------------------------

## 2. Classification table

One primary status per row. Columns: **Impl** = implemented, not verified by me beyond build; **Ver** = VERIFIED by me (command + result in
section 3); **Part** = partially verified; **Miss** = missing; **Inc** = incompatible with another reuse target; **Sim** = simulation-only; **IP** = external-IP dependent.

| Function / feature | Impl | Ver | Part | Miss | Inc | Sim | IP | Note |
|---|---|---|---|---|---|---|---|---|
| Page-level L2P (LBA -> LPN -> PPN), 4 B/entry, unmapped reads zeros | | X | | | | | | `geometry_and_range`, `random_overwrite`, `sequential`, `subpage_rmw` PASS (E1) |
| Out-of-place write (alloc, program, confirm, commit, retire old) | | X | | | | | | `random_overwrite`, `program_failures`, mutation "map committed on failed program" killed (E1, E5) |
| Read-modify-write for sub-page writes | | X | | | | | | `subpage_rmw` PASS |
| TRIM / deallocate (journal page before ack) | | X | | | | | | `trim`, `restart_*`, `powercut_*`; mutation "TRIM acked without journal" killed |
| Free-space accounting / allocator (deterministic) | | X | | | | | | `sfftl_check()` invariant used by all tests |
| Garbage collection (greedy, cost-benefit, paced, foreground, background) | | X | | | | | | `gc_policies`, `full_device`, mutation "GC erases victim with valid page" killed; bench WA reproduced (E6) |
| Wear levelling (none / dynamic / dynamic+static) | | X | | | | | | `wear_levelling` PASS; bench max/mean 1.74 -> 1.28 -> 1.07 reproduced byte-identical |
| Factory bad blocks (marker majority rule, markers preserved) | | X | | | | | | `factory_bad_blocks`; marker-read before any erase |
| Grown bad blocks (program/erase/read failure, retire, strand) | | X | | | | X | | tests use the P56 simulated NAND only; no real/vendor NAND |
| Crash consistency: spare-record roll-forward + commit-last checkpoints + journal | | X | | | | | | 1 200-point cut sweep, mount sweep (212+ ops), 400 random, 240 randomised: all PASS (E1) |
| Survive one damaged metadata page (newest commit unreadable) | | | X | | | | | **Fails safe but loses the volume**: 166/300 `ENOFS` in my probe (E9). Fixed in P58 / P58b |
| Survive one damaged journal page (acked TRIM) | | | X | | | | | Journal not mirrored in P56 (trimmed data may reappear); fixed only in P58 (mirror) -- not probed by me |
| PowerSafe hooks `sfftl_ps_warn/power_fail/restored` | | X | | | | | | `powersafe` test (14 checks) PASS; **no controller is wired to it** (P56 has no PowerSafe hardware) |
| Volatile write buffering / flush semantics | | | | X | | | | By design none: every `sfftl_write` ack is durable; `sfftl_flush` only flushes erase-count journal records |
| Atomic multi-page write | | | | X | | | | Only per-logical-page atomicity (documented) |
| Host build (gcc, -Wall -Wextra -Werror -Wshadow -Wconversion) | | X | | | | | | built clean (E1) |
| RV32IM library + image build (ControlCore) | | X | | | | | | clean rebuild: `.img` sha256 identical to shipped; ELF32 RISC-V entry 0x10100 (E4) |
| FTL firmware executing on ControlCore RTL + P51 NAND ctrl | | | X | | | X | | boot/format/fill-verify observed, full run DNC at 8 min (E7) |
| HAL `hal/sfs` (P51 `sfs_nand_ctrl` registers, 528-B page) | | | X | | X | | | exercised in the partial RTL run only; incompatible with P53/P55 geometry & API |
| HAL `hal/sim` simulated NAND | | X | | | | X | | NANDLab *rules* re-implemented in C; not bit-exact with NANDLab statistics |
| Multi-channel / multi-LUN / multi-plane, async I/O | | | | X | | | | single-threaded synchronous by design |
| DRAM-resident / demand-paged L2P | | | | X | | | | RAM-resident only (E8: 8.3 KiB for P51 device, 4.1 MiB @16 GiB raw, 31 MiB @128 GiB) |
| NAND-grade ECC | | | | | | | X | relies on controller ECC; P51 SECDED is a placeholder; FTL adds CRC-32 + LPN check |
| Hardware CRC accelerator | | | | X | | | | specified (docs/10 s4.3), not built |
| Lifetime / endurance / TBW figures | | | | X | | | | explicitly not claimed (correctly) |

---------------------------------------------------------------------------------------------------------------------

## 3. Evidence log

All commands run with the shown cwd; `rc` = exit status; times are wall times under heavy shared load. Raw logs in `$SP/audit_out/p56/`.

| # | Command (cwd) | rc | Key output | Wall |
|---|---|---|---|---|
| E1 | `make test` (`work/p56`) -> `make_test.log` | 0 | `SUMMARY 27 tests, 0 failed, 4882 checks, 0 failed checks`; `powercut_sweep PASS 2400 checks` ("1200 consecutive cut points tested"); `powercut_mount_sweep PASS 427`; `powercut_random PASS 934`; `powercut_with_faults PASS 302`; `repeated_random PASS 480` (240 runs) | 37.1 s |
| E2 | `make quick` (`work/p56`) -> `make_quick.log` | 0 | `27 tests, 0 failed, 1794 checks (quick)` | 9.3 s |
| E3 | `make sanitize` (`work/p56`) -> `make_sanitize.log` | 0 | ASan+UBSan build, `27 tests, 0 failed, 1794 checks (quick)`; `grep -ci "runtime error\|AddressSanitizer"` = 0. (Note: only the *quick* suite is run under sanitizers, as the Makefile specifies) | 32.4 s |
| E4 | `make fw` (`work/p56`) -> `make_fw.log` : a **no-op**, the archive ships pre-built `fw/build/*`. So: `rm -rf firmware/silicaflux_ftl/fw/build; make fw` (`work/p56_fwclean`) -> `make_fw_clean.log`, `readelf_fw.txt`, `pristine_fw_hashes.txt` | 0 | `size`: text 39548, data 8, bss 19864; `mkimage: flashmap_fw.img 39812 B (60% of IMEM) entry 0x00010100 crc32 0x7bee70e7`; **`.img` sha256 `fb935db0...` identical to the shipped one**; `.elf` differs only by build-path debug info (`d3df8fd4...` vs `43e0c296...`); library total text 29 552, data 0, bss 0; ELF32 RISC-V | 5.2 s |
| E5 | `make mutation` (`work/p56`) -> `make_mutation.log` | 2 (script exits non-zero because one mutant survived) | `11 / 12 mutations killed`; survivor: "checkpoint body CRC not verified at mount" (matches README) | 147.9 s |
| E6 | `make bench` (`work/p56`) -> `make_bench.log` | 0 | regenerated `reports/perf/PERF.md`, `runs.csv`, `erase_counts_wl_static.csv` are **byte-identical** to the shipped files (`diff`/`cmp`). Uniform random WA 6.01, OP 15/25/40 % -> 3.16/2.03/1.39, cost-benefit hot/cold 3.78, WL max/mean 1.74/1.28/1.07 | 201 s |
| E7 | `make rtl` (`work/p56_fwclean`) -> `make_rtl.log` | **124 -- DID NOT COMPLETE (8 min)** | Verilator build of P51 SoC + tb OK; firmware booted: `ROM: start 00010100 crc 7bee70e7`, `[fw] NAND ch0: CH_INFO page 528 B, ECC 1, READ_ID 10a1da5f -> 0`, `layout: arena 8488 B ... 5 metadata blocks, checkpoint 9 pages`, `formatted: 744 LBAs x 512 B, factory-bad blocks 2 (expected 2: 13, 41)`, `verify after sequential fill: 744 LBAs, 0 mismatches @29493953`. Killed before the claimed 344 820 395-cycle end | 480 s |
| E8 | RAM probe: `layout_probe.c` calling `sfftl_layout_info()` (no device) -> `probe_layout_ram.txt` | 0 | page 512/16 ppb/64 blk (P51): arena **8 488 B** (L2P 3 096); 4 KiB/64/1024 (0.25 GiB raw): 287.6 KiB; 4 KiB/256/8192 (8 GiB raw): 8 101 KiB (L2P 7.4 MB); 16 KiB/256/4096 (16 GiB raw): 4 103 KiB; 16 KiB/512/16384 (128 GiB raw): 31.9 MiB. `sizeof(sfftl_t)` = 808 B | <1 s |
| E9 | **Auditor probe** `probe_f2.c` (copy in `audit_out/p56/`): workload (writes 1-4 LBA, 45 % TRIM), stop at a random point in the life of the newest checkpoint, `simnand_corrupt_page(newest commit)`, fresh `sfftl_mount()`, compare every LBA with the model. Pristine P56 sources, 300 seeds per row -> `probe_f2_all.txt`, `probe_f2_p56_rc.txt` | 0 | P56: 512 B/16/64 trim45 default ckpt interval **166 mount failures (rc -7 `no valid FTL metadata`)**, 0 data mismatches after successful mounts; trim60: 182; 512/8/64: 198; 512/16/128: 5; ckpt interval 4 or 2 KiB pages: 0. Same probe on P58 FTL (DUAL_CKPT+MIRROR): **0/300 in every row**; P58b FTL: **0/300 in every row** | ~3 min total |
| E10 | Vendoring check: SHA-256 of every file under `third_party/` vs every file of all *other* project archives in `$SP/audit/all_extract` | n/a | 85/85 vendored RTL/C/script files byte-identical to upstream (P51 StorageCore subset); `reports/vendor_check.txt` claims 90/90 (the extra 5 are README/hash files I did not compare) | <1 s |
| E11 | Module-name collision scan over all `.sv/.v` in all pristine projects | n/a | no differing-content duplicate module among the files P56 vendors; P56's P51 subset is identical to the P51 archive for `sfs_*` modules (see section 6) | <1 s |

---------------------------------------------------------------------------------------------------------------------

## 4. Doc claims NOT reproduced / not substantiated

| Claim (source) | Status |
|---|---|
| "FTL firmware on ControlCore + P51 RTL: PASS, 164/164 checks, 8/8 TB checks, 344.8 M cycles" (README, RTL_RUN.md) | **Not reproduced**: DNC at the 8-min limit; only the first ~29.5 M cycles (boot, format, sequential-fill verify) observed. The shipped `rtl_run.log` itself records 13 m 52 s. |
| "ControlCore cycles per host LBA write / read 86 965 / 12 219 (RTL)" | Not reproduced (needs the RTL run). |
| "Mount: clean 92 / unclean 381 device operations" | The bench numbers are in the byte-identical `PERF.md`, so reproduced *as modelled on the simulated NAND*; the RTL-side `clean_mount_cycles` not reproduced. |
| "Sanitizers: 27/27 PASS" | Reproduced only for the `--quick` suite (1 794 checks), which is what `make sanitize` runs; the full suite was not run under ASan/UBSan. |
| "Vendor check 90/90" | Equivalent hash comparison done for the 85 code/script files; the 5 documentation files not compared. |
| Latency numbers (p99 5.2 ms, etc.), "WA", "mount time ms" | Reproduced byte-identically, but they are **modelled** on NANDLab's *illustrative* SLC times; no device-lifetime or real-NAND figure is, or can be, derived (README says so). |
| README boot snippet (`mount()==ENOFS -> format()`) is annotated "virgin device only" | Not safe: my probe shows `ENOFS` also arises on a *used* device after one damaged commit page (E9). |
| Claim that persistence is robust ("crash-consistent mapping persistence", docs/07 s6 argument) | True for power cuts (verified), but the argument does not cover media damage of the newest checkpoint after ring wrap (E9). |
| "No PowerSafe project exists; this project defines the interface" | Accurate; nothing connects `sfftl_ps_*` to hardware in P56. |

---------------------------------------------------------------------------------------------------------------------

## 5. Reusable interface reference

### 5.1 FTL design facts (answers to the brief)

| Topic | Fact |
|---|---|
| Mapping granularity | One L2P entry per **logical page = the data area of one physical NAND page** (`spp = page_data_bytes / lba_bytes` LBAs per entry). Sub-page writes are read-modify-write. |
| L2P layout / RAM | `uint32_t l2p[nlpn]` (PPN, `0xFFFFFFFF` = unmapped); valid-page bitmap 1 bit/physical page; block table 16 B/block {erase count, close_seq, valid, wp, state, flags, stream}; 3 page buffers; journal queue; mount scratch 20 B/metadata page. All in one caller-provided arena (`sfftl_mem_required()`); no malloc. |
| L2P persistence | Checkpoint = body pages (L2P words then 2 words/physical block) + ONE commit page written last, in a **metadata ring** (first `meta_blocks` good blocks by factory marker); between checkpoints, mapping is recoverable from the 16-B spare record (LPN, 48-bit SEQ, CRC-32) of every data page by roll-forward; TRIM/ERASE-count/RETIRE events go to journal pages. |
| Block allocation | States FREE/OPEN/CLOSED/META/BAD; 3 write streams (HOST, RELOC, COLD); erase-on-allocate unless already erased; free block chosen by wear policy; deterministic (no randomness). |
| GC | Victim: RETIRE-flagged, then REFRESH-flagged, then policy (GREEDY = fewest valid, or COST_BENEFIT (1-u)*age/2u in integer math). Modes: paced (per host page), foreground (blocking safety net), background (`sfftl_background`). A victim is erased only at valid count 0; optional PARANOID L2P scan, optional VERIFY_GC_COPY read-back. |
| Wear levelling | Per-block erase count in RAM + checkpoint + `J_ERASE` journal; NONE / DYNAMIC (lowest EC free block) / DYNAMIC_STATIC (cold data moved onto most-worn blocks when EC spread > `wl_static_threshold`). Erase counts can under-count after a crash, never over-count. |
| Bad blocks | Factory: marker byte (spare byte 0) of pages 0 and last, >=4 zero bits => bad, read raw before any erase, never programmed/erased. Grown: program fail -> retry elsewhere + RETIRE flag + journal; erase fail -> retire; read uncorrectable -> EIO + RETIRE; no spare pool, over-provisioning absorbs; metadata-ring block failure -> skipped; ring exhausted -> read-only mount. |
| Write buffering / flush | None. `sfftl_write` returns OK only after every page is programmed, status confirmed, mapping committed (page is durable via spare record). `sfftl_flush` = flush buffered erase-count records; FUA is implicit. |
| Own crash-consistency guarantee | Acknowledged write/TRIM survives any power cut (incl. cuts inside GC, checkpoint, mount); each logical page old-or-new if not acknowledged; multi-page requests not atomic; reads never return wrong data (CRC + LPN check, EIO instead). **Not guaranteed:** surviving a damaged newest checkpoint commit after ring wrap (E9), a damaged journal page (acked TRIM can come back), controller-refused NAND operations while powered (the hazards P58 fixed). |
| Geometry limits (`sfftl_geom_t`) | `page_data_bytes` power of two 512..16384; `page_spare_bytes >= 16`; `pages_per_block` power of two 4..1024; `blocks` 16..65535 (flat PBN); `lba_bytes` power of two 512..page; `op_permille` 1..499; metadata zone auto-sized (>= 2*ceil(ckpt/ppb)+3, min 4). |
| NAND access | Exclusively through `sfftl_hal_t` (5 callbacks, flat `ppn = pbn*ppb+page`, synchronous). |
| RAM footprint | P51 device (512 B x 16 x 64): 8 488 B arena + 808 B instance. Scales ~ 4 B per logical page (0.93 MiB / GiB @4 KiB pages). |
| Runs on ControlCore? | Yes by construction: freestanding, RV32IM, 29.6 KB text, 0 data/bss, image 39.8 KB (61 % of 64 KiB IMEM), 19.9 KB DMEM of 32 KiB. Executed on the ControlCore RTL only inside P56's own `rtl_sim` (P51 SoC); only partially reproduced by me. |

### 5.2 C API (`include/sfftl.h`, version `0x00560100`)

```c
enum sfftl_rc { SFFTL_OK=0, SFFTL_EINVAL=-1, SFFTL_ERANGE=-2, SFFTL_EIO=-3, SFFTL_ENOSPC=-4, SFFTL_EROFS=-5,
                SFFTL_EPOWER=-6, SFFTL_ENOFS=-7, SFFTL_ECORRUPT=-8, SFFTL_ENOMEM=-9, SFFTL_EGEOM=-10, SFFTL_ESTATE=-11 };
typedef struct { uint32_t page_data_bytes, page_spare_bytes, pages_per_block, blocks; } sfftl_geom_t;
typedef struct { uint32_t lba_bytes; uint64_t nlba; uint32_t op_permille, meta_blocks, gc_reserve_blocks,
                 gc_fg_free_blocks, gc_bg_free_blocks; sfftl_gc_policy_t gc_policy; sfftl_wl_policy_t wl_policy;
                 uint32_t wl_static_threshold, wl_static_interval, ckpt_interval_blocks, read_retries,
                 refresh_bitflips, flags; } sfftl_cfg_t;
/* flags */ SFFTL_F_VERIFY_GC_COPY(1<<0) SFFTL_F_PARANOID(1<<1) SFFTL_F_VERIFY_READ_CRC(1<<2) SFFTL_F_ALLOW_REBUILD(1<<3) SFFTL_F_PACED_GC(1<<4)
void   sfftl_cfg_default(sfftl_cfg_t*);                         /* 512-B LBA, OP 70 permille, GC reserve 2/fg 3/bg 6, greedy, dyn+static WL */
size_t sfftl_mem_required(const sfftl_geom_t*, const sfftl_cfg_t*);
int    sfftl_layout_info(const sfftl_geom_t*, const sfftl_cfg_t*, sfftl_layout_t*);
int    sfftl_format(sfftl_t*, const sfftl_geom_t*, const sfftl_cfg_t*, const sfftl_hal_t*, void *arena, size_t arena_bytes);
int    sfftl_mount (sfftl_t*, const sfftl_geom_t*, const sfftl_cfg_t*, const sfftl_hal_t*, void *arena, size_t arena_bytes);
int    sfftl_read (sfftl_t*, uint64_t lba, uint32_t nlb, void *buf);
int    sfftl_write(sfftl_t*, uint64_t lba, uint32_t nlb, const void *buf);
int    sfftl_trim (sfftl_t*, uint64_t lba, uint32_t nlb);
int    sfftl_flush(sfftl_t*);  int sfftl_checkpoint(sfftl_t*);  int sfftl_shutdown(sfftl_t*);
int    sfftl_background(sfftl_t*, uint32_t budget_pages);
uint64_t sfftl_capacity_lba(const sfftl_t*);  const sfftl_stats_t *sfftl_stats(const sfftl_t*);
void   sfftl_space(const sfftl_t*, sfftl_space_t*);  int sfftl_check(sfftl_t*);  const char *sfftl_strerror(int);
/* sfftl_powersafe.h */ void sfftl_ps_warn(sfftl_t*) /*ISR-safe flag*/; int sfftl_ps_power_fail(sfftl_t*, uint32_t flags /*SFFTL_PS_FLUSH_JOURNAL*/);
                        int sfftl_ps_power_restored(sfftl_t*); int sfftl_ps_state(const sfftl_t*); void sfftl_ps_worst_case_ops(const sfftl_t*, sfftl_ps_budget_t*);
```
`sfftl_t` is 808 B and must be allocated by the caller (declared in the header). Page-buffer arena must be 8-byte aligned.

### 5.3 NAND HAL contract (`include/sfftl_hal.h`)

```c
typedef struct sfftl_hal { void *ctx;
  int (*read)(void *ctx, uint32_t ppn, void *data, void *spare, uint32_t *bitflips);   /* data=page_data_bytes, spare=16 B, either may be NULL; ECC covers data+spare */
  int (*program)(void *ctx, uint32_t ppn, const void *data, const void *spare);          /* data+16-B spare in ONE program op; pages ascending, once per erase */
  int (*erase)(void *ctx, uint32_t pbn);
  int (*read_marker)(void *ctx, uint32_t ppn, uint8_t *marker);                          /* raw (no ECC) read of spare byte 0 (bad-block marker) */
  void (*write_protect)(void *ctx, int enable);                                          /* optional */
} sfftl_hal_t;
/* status: OK=0, CORRECTED=1, UNCORRECTABLE=2, PROGRAM_FAIL=3, ERASE_FAIL=4, WRITE_PROTECT=5, POWER_LOSS=6, TIMEOUT=7, INVALID=8 */
#define SFFTL_OOB_BYTES 16u   #define SFFTL_BBM_OFFSET 0u
```
Hard requirement for a new HAL: data **and** the FTL's 16-byte spare must be programmed in one operation and be under the same ECC; read-marker must be a raw read.

### 5.4 On-NAND metadata formats (`include/sfftl_schema.h`, schema version 1, little endian, byte-wise codec)

* **Spare record (16 B, every FTL page):** `[0]` BBM = 0xFF (never written) | `[1]` TYPE 0xD1 host data / 0xD2 relocated data / 0xE1 metadata | `[2..5]` TAG = LPN (data) or `kind<<24|index` (metadata) | `[6..11]` SEQ, 48-bit global sequence number | `[12..15]` CRC-32 (IEEE reflected, init/xorout 0xFFFFFFFF) over `page data || spare[1..11]`. All-0xFF spare = erased.
* **Metadata page header (16 B):** magic `'SFMT'` 0x544D4653 | kind u16 (1 body, 2 commit, 3 journal) | schema u16 (=1) | gen u32 | index u32.
* **Checkpoint body:** words packed `(page_data_bytes-16)/4` per page: `nlpn` L2P entries, then per physical block two words (erase count; `state | flags<<8 | wp<<16`).
* **Commit page payload (word offsets):** 0-1 CKPT_SEQ, 2-3 NEXT_SEQ, 4 page_data, 5 page_spare, 6 ppb, 7 blocks, 8 lba_bytes, 9-10 nlba, 11 nlpn, 12 meta_blocks, 13 flags (`CLEAN`=1), 14 body pages, 15 body CRC, 16 nruns, 17.. runs {start PPN, count} (max 32), then 4x2-word lifetime counters (host LBAs, programs, erases, mounts). Commit is written last.
* **Journal page payload:** word0 = record count, then 3-word records `{type,a,b}`: TRIM(1: first LPN,count), ERASE(2: pbn, ec), RETIRE(3: pbn, reason 1 prog/2 erase/3 read), PRETIRE(4: pbn), MOUNT(5: mount count).
* **Recovery order:** zone discovery by factory marker -> catalogue -> newest loadable checkpoint (else older; none => `ENOFS`, or empty map + full rebuild with `ALLOW_REBUILD`) -> journal pass 1 -> roll-forward of data pages with SEQ > ckpt_seq (newest SEQ wins) -> journal pass 2 (TRIM only if newer than surviving data) -> rebuild VBM -> fresh ring block + immediate checkpoint after an unclean shutdown.

### 5.5 P51 HAL (`hal/sfs/hal_sfs.h`)
`sfs_hal_init(sfs_hal_t*, ch, buf_slot_addr, &id0)`, `sfs_hal_bind(sfs_hal_t*, sfftl_hal_t*)`; constants: `SFS_HAL_DATA_BYTES 512`, user bytes 528 (512 + 16), `SFS_HAL_PPB 16`, `SFS_HAL_BLOCKS 64`, marker at raw column 640 (word 128 x 5 B with ECC), page moved through a reserved buffer-SRAM slot by 32-bit CPU copies, ops RESET/READ_ID/READ_PAGE/PROGRAM/ERASE via `OP_ROW/COL/BUF/LEN/SUBMIT {op, ECC_EN, tag 0xB0}` and `CPL_HEAD/INFO0/POP` polling (8 M-cycle poll limit). Instantiates P51 with `NAND_PAGE_BYTES=528`, a parameter value P51 itself never verified.

---------------------------------------------------------------------------------------------------------------------

## 6. Integration risks / incompatibilities

1. **R1 -- HAL targets P51, not P53/P55.** `hal/sfs` speaks P51 `sfs_nand_ctrl` registers with fixed geometry (64x16x512 B). Any P53 FlashLink / P55 BufferCore platform needs a new HAL; the P55 page image (see p55_audit.md) puts ECC check bytes and `{CRC32C, LBA}` OOB in its own layout, with no slot for the FTL's 16-B spare record, and its CRC-32C duplicates the FTL's CRC-32.
2. **R2 -- Fragile metadata (E9).** One damaged newest commit page can brick the volume (`ENOFS`); auto-format-on-ENOFS patterns (README snippet) would destroy data. Prefer the P58 / P58b FTL (A/B retention) -- see p58_audit.md for which.
3. **R3 -- RAM-resident L2P.** 4 B / logical page: 8.3 KiB for the toy P51 device but ~0.93 MiB per GiB of 4-KiB pages; ControlCore DMEM is 32 KiB. A DRAM map or demand paging is required beyond ~4-5 k pages.
4. **R4 -- Single-threaded, synchronous, single channel.** No overlap of channels/LUNs/planes; a P53 multi-channel controller would be underused; GC and checkpoints run inline (paced GC mitigates tail latency).
5. **R5 -- ECC dependency.** The FTL assumes the controller ECC covers data + the 16-B spare; P51's SECDED is a placeholder; no BCH/LDPC integration (P54 ECCCore is not connected).
6. **R6 -- Mount time scales with device size** (page 0 of every block read on an unclean mount; bounded by `ckpt_interval_blocks`).
7. **R7 -- Everything is simulation.** Simulated NAND (NANDLab rules re-implemented in C), no real/vendor NAND, no FPGA; timing numbers are illustrative.
8. **R8 -- Two FTL forks exist** (P58, P58b) with **different on-flash schemas and APIs** from this P56 baseline; choose exactly one for the integration (see p58_audit.md). Measured cross-mount matrix (auditor probe `xmount.c`, 3 writers x 3 readers, clean and unclean media, `audit_out/p58/xmount_matrix.txt`): a P56-config medium mounts and verifies (0 mismatching LBAs) on P56 and on P58 **without** its DUAL flags, but is refused with `EGEOM` by P58-with-DUAL and by P58b (their metadata zone is 3*need+3 blocks, P56's 2*need+3); a P58-DUAL medium is refused (`EGEOM`) by P56 and by P58-without-flags, but mounts and verifies on P58b; a P58b (schema 2) medium cannot be read by P56 or P58 (`ENOFS`). So the "P58 media mount on P56 code" claim holds only for the P56 configuration, not for P58's DUAL_CKPT configuration.
9. **R9 -- PowerSafe interface is a contract only.** Nothing drives `sfftl_ps_warn()` in P56.
10. **R10 -- Shipped prebuilt binaries.** The archive contains `fw/build/*.elf/.img/.hex/.a`; a no-op `make fw` will silently reuse them. Rebuild from clean for the real toolchain (done: identical image).

---------------------------------------------------------------------------------------------------------------------

## 7. Licensing notes

* **No licence file anywhere** in the archive or in the vendored P51/ControlCore subset (`PROVENANCE.md` states "No licence file exists in the repository"); no SPDX headers; no copyright notices in the sources. Rights status is therefore *undefined* -- obtain the owner's explicit licence before any redistribution or commercial reuse.
* Vendored material is all from the same repository (P51 StorageCore subset, ControlCore P21 runtime incl. `crt0.S`, `fw.ld`, `mkimage.py`; SilicaFlux-V / MCU-I / DataFabric / sramlib RTL subsets) and thus carries the same unknown terms (verified byte-identical to those archives).
* Toolchain licences (not shipped): `riscv64-unknown-elf-gcc` (GPL; firmware links `libgcc` -- GCC Runtime Library Exception applies), Verilator (LGPL/Artistic), Icarus (GPL), Yosys (ISC).
