# Project 55 "BufferCore" (SRAM/DRAM page buffer + DMA) -- integration audit

Auditor environment: container, Verilator 5.020, Icarus 12, Yosys 0.33, gcc 13, Python 3.13.
Pristine extract: `$SP/audit/p55_buffercore/silicaflux-buffercore` (untouched). Work copy: `$SP/work/p55`. Raw logs: `$SP/audit_out/p55/`.
`SP=/tmp/claude-0/-home-user-Aureom-AI/c80a8d5d-1b1f-56e3-9758-b78cee890e29/scratchpad`.

**Environment caveat for every wall time below:** the 4-core container was shared with a dozen unrelated jobs (load average 12 -> 33 while
this audit ran). Verilator builds that the README sizes at "~1 min" took 5 min, and several of my own commands hit the 8-minute time-box
purely because of contention. Where that happened it is marked "DID NOT COMPLETE (contention)" -- these are not project failures.

---------------------------------------------------------------------------------------------------------------------

## 1. Summary verdict

* **What it is.** A synthesizable SystemVerilog buffer subsystem (`silicaflux_storage_buffer`, 16 RTL modules) that moves data between a
  host-memory SFB2 master, a banked 72-bit parity SRAM (data slots + NAND page-image slots), ECC/CRC engines, a NAND-controller SFB2 slave
  port (made for P53 FlashLink's `sfnc_buf_master`), a 32-bit firmware port (CSR/BUF/DRAM windows) and an optional external-DRAM metadata window.
* **VERIFIED by me (ran in this container, saw pass):**
  `make lint` (9 configs x 2 views: 0 synth-view warnings, 5/5 illegal parameter sets rejected by Verilator and Icarus);
  `make sim` -> `TB RESULT: PASS (16403 checks)` (16-test scenario suite, base config, Verilator, seed 1 -- identical check count to the shipped report);
  `make integ` -> `TB DoD ... MET`, `TB RESULT: PASS (1059 checks)` (BufferCore + unmodified P53 FlashLink + P52 NANDLab + P24 MemoryBridge, Verilator);
  generated C header regenerates byte-identically and the firmware example compiles with `-std=c11 -Wall -Wextra -Werror -pedantic`;
  `MANIFEST.sha256` (171/171 OK, on the pristine extract) and `third_party/SHA256SUMS` (47/47) verify; all 47 vendored files are byte-identical to the upstream archives.
  Further results (other configurations, Icarus, mutation, synthesis, performance) are in the evidence log with their own status.
* **Not simulation-complete:** only the *base* configuration (LB 512 x 4 per page) and, for the integration bench, only the *small* geometry
  (LB 128 x 4, page image 616 B, NANDLab page 512+128 B) have been exercised against a NAND model. The default 2 344-byte page image has
  never been programmed through FlashLink/NANDLab.
* **Hard limits for reuse:** ECC is a placeholder SECDED (72,64) (one bit per 8 bytes), crypt is a keyed XOR (explicitly not a cipher), SRAM
  protection is detect-only parity, no PCIe/NVMe/PRP, 32-bit host addresses, SFB2 rev-2.0 single-beat transactions (one outstanding on the
  crossbar), DRAM adapter targets only the *simulated* P24 controller (no DDR PHY), ASIC SRAM macros are black boxes (vendor models not shipped).
* **Reuse verdict:** reuse as the buffer/DMA integration point for a P53-based NAND path; keep its page-image/OOB format and CRC-32C/LBA tag
  as *its own* integrity scheme. It is **not** layout-compatible with P54 ECCCore or with the FTL spare record of P56/P58 without an adapter.

---------------------------------------------------------------------------------------------------------------------

## 2. Classification table

One primary status per row. **Impl** = implemented, not verified by me beyond build/lint; **Ver** = VERIFIED by me; **Part** = partially verified;
**Miss** = missing; **Inc** = incompatible with another reuse target; **Sim** = simulation-only; **IP** = external-IP dependent.

| Function / feature | Impl | Ver | Part | Miss | Inc | Sim | IP | Note |
|---|---|---|---|---|---|---|---|---|
| Banked SRAM buffer (data slots + page slots), 72-bit words, per-byte parity, init sweep | | X | | | | | | `make sim` PASS (E2) |
| Bank crossbar + per-bank arbiter (aging > NAND HIGH > NORMAL), `AGE_LIMIT+7` bound | | X | | | | | | `t_arb` inside the 16403-check run |
| Buffer manager: slot FSMs, locks, DIRTY, ownership checks, metadata buffer | | X | | | | | | `t_owner/t_durable/t_cache` inside E2 |
| Descriptor DMA engines H2B/B2H/ENC/DEC + validation + TID + completion-after-commit | | X | | | | | | E2 (commit monitor 167/167 completions, 0 violations) |
| End-to-end CRC-32C (G1/V1/V2/V3) + LBA tag + poison containment | | X | | | | | | E2; mutation M03 (V3 disabled) status in E6 |
| Codeword ECC framing (SECDED(72,64) per beat, erased-page handling) | | X | | | | | | E2 `t_ecc`, E3 (NAND errors through real FlashLink) |
| Definition of done: host -> buffer -> ECC -> FlashLink P53 -> NANDLab P52 -> back, byte exact | | X | | | | X | | E3, Verilator only; simulation models, LB128 geometry |
| Same suite on Icarus 12 (second simulator) | | | X | | | | | all 16 scenario tests PASS individually on Icarus, base config, 15 933 checks (E7); the combined Icarus run and the Icarus DoD bench (~10-20 min) were not run |
| Other configurations (small, wide, lb64, mo4, dram, nocrypt, plp), extra seeds | | | X | | | | | base seeds 2, 3 PASS (E4); `small` PASS 7 243 checks (E5); wide/lb64/mo4/dram/nocrypt/plp builds did not fit the time-box under load |
| NAND port serving FlashLink `sfnc_buf_master` (64-bit SFB2 slave, ownership-checked) | | X | | | | X | | E3 |
| Firmware CSR/BUF/DRAM windows, 38 perf counters, register map | | X | | | | | | `t_regs`; header regenerates identically (E8) |
| Clean read cache (CAM, LRU eviction, coherence on host write / TRIM) | | X | | | | | | `t_cache` |
| Write-through metadata cache + external DRAM window | | | X | | | X | X | `dram` config / integration "dram" section vs *simulated* P24 MC only; no DDR PHY |
| Crypt stage (`CRYPTO_EN`) | | X | | | | X | | placeholder keyed XOR, not a cipher (docs/09) |
| Early-ack rule `early_ack_ok = WCE | PLP_PRESENT`, `plp_dirty`, power-fail refusal | | X | | | X | | `t_durable`; `PLP_PRESENT` is only a parameter, no energy model |
| SRAM generic backend (flops) | | X | | | | X | | simulation / early synthesis only; "never use for silicon storage" |
| SRAM ASIC backend (IHP SG13G2 / SKY130 / GF180 macros) | | | | | | | X | only pin-only black boxes shipped; behavioural vendor models are **not** in the archive |
| SRAM FPGA backend (inference template) | | | X | | | | | Yosys `synth_ecp5` estimate only (E-synth) |
| Yosys synthesis estimates (ASIC generic cells / ECP5) | | | X | | | | | `small` mem and ASIC flows regenerated byte-identical to the shipped stat/check files (0 problems); other flows DNC (E-synth) |
| Mutation testing (15 mutants) | | | X | | | | | 4 of 15 (M03, M05, M10, M15) re-checked on copies with faster builds: all killed (A3); the project's own `mutate.py` DNC under load |
| Performance counters / measured throughput | | | X | | | | | `make perf` not run; counters exist (`t_perf` inside E2, DoD cycle count 35 929 / 71 709); throughput figures not re-measured |
| BCH/LDPC ECC | | | | X | | | | none in P55; P54 ECCCore exists but is **not connected** and has an incompatible page layout |
| Real cipher (AES-XTS) | | | | X | | | | |
| PCIe/NVMe host, PRP/SGL, 64-bit host addresses | | | | X | | | | host side is a 32-bit SFB2 master |
| Multi-channel NAND port | | | | X | | | | single NAND-port transaction at a time (>=4 cycles per 8-byte beat) |
| Formal proofs / coverage closure | | | | X | | | | README: "No formal proofs were run"; no coverage numbers are claimed |
| Layout compatibility with P56/P58 FTL (16-B spare record) | | | | | X | | | P55 page image has no field for it; duplicate CRC schemes (see section 6) |

---------------------------------------------------------------------------------------------------------------------

## 3. Evidence log

(`rc` = exit status; cwd `work/p55` unless stated; logs in `$SP/audit_out/p55/`.)

| # | Command | rc | Key output | Wall |
|---|---|---|---|---|
| E1 | `make lint` -> `make_lint.log` | 0 | 9 configs (base, small, wide, lb64, max, mo4, dram, nocrypt, plp): `verilator synth 0 warnings, sim 1 warning, icarus rc=0`; 5 illegal sets (banks3, lb100, page_lbs3, fifo3, too_big) `rejected=True` for both tools. The single sim-view warning is from the vendored SRAM library's assertion block (as documented). | 22.6 s |
| E2 | `make sim` (Verilator build + `+TEST=all +SEED=1`) -> `make_sim.log` | 0 | `tb_sfsb: banks=4 LB=512 page_lbs=4 dslots=8 pslots=4 ... page image 293 beats (2344 B)`; `commit monitor checked 167 completions, 0 violations`; `accepted 168 descriptors, 167 completions, protocol violations fw/nand/host/dram = 0/0/0/0`; **`TB RESULT: PASS (16403 checks)`** (README table: 16403 for base seed 1 -- identical) | 297 s (mostly Verilator/g++ build under load) |
| E3 | `make integ` -> `make_integ.log` | 0 | `tb_sfsb_nand: buffer LB=128 x 4, page image 616 B; NANDLab page 512+128 B`; `DoD round trip ... in 35929 cycles`; sections nand-errors, prog-fail, dram, final; `NANDLab reads 6 programs 4 erases 2; monitor checks 61197; descriptors 17`; `DRAM controller commands rd 16 wr 32`; **`TB DoD: ... -- MET`, `TB RESULT: PASS (1059 checks)`** | 223 s |
| E4 | `build/vl_suite/vtb +TEST=all +SEED=2` / `+SEED=3` (re-uses E2 binary) -> `base_seed2.log`, `base_seed3.log` | 0 / 0 | `TB RESULT: PASS (16184 checks)` / `PASS (16336 checks)`, 0 SFB2 violations -- identical to the shipped `regression.md` | 2.3 s each |
| E5 | `python3 scripts/regress.py --no-icarus --only small,lb64,plp` ; `--only base` ; `--only small` ; (logs `regress_*.log`) | 124 ; 124 ; **0** | the first two: **DID NOT COMPLETE (contention)**. `--only small`: `build small: rc=0 175 s`, `verilator small seed 1: TB RESULT: PASS (7243 checks)` (= shipped value) | 480 s ; 480 s ; 176 s |
| E6 | `python3 scripts/mutate.py --only M03` (twice: `mutate_M03.log`, `mutate_M03_retry.log`) | 124 ; 124 | **DID NOT COMPLETE (contention)** (each mutant needs a full Verilator build + suite). Replaced by auditor hypothesis tests on COPIES, see A3 in 3.1 | 480 s each |
| E7 | `make sim-iv TEST=basic` then, with the same `build/tb_sfsb.vvp`, `vvp -n build/tb_sfsb.vvp +TEST=<t> +SEED=1` for t in regs partial concurrent backpressure exhaust invalid ecc corrupt owner cache durable crypt arb reset random (`sim_iv_basic.log`, `iv_test_*.log`) | 0 each | 16 / 16 tests `TB RESULT: PASS`, 0 protocol violations; checks: regs 21, basic 341, partial 710, concurrent 1 041, backpressure 7 143, exhaust 297, invalid 442, ecc 627, corrupt 646, owner 132, cache 313, durable 305, crypt 360, arb 583, reset 316, random 2 656 = **15 933** | 1.6-50 s each |
| E8 | `gcc -std=c11 -Wall -Wextra -Werror -pedantic -Isw/include -c sw/example/sfsb_write_page.c` ; `python3 scripts/gen_header.py` then `diff` against the shipped header | 0 / 0 | example compiles; regenerated `sfsb_regs.h` **identical** to the shipped file | <1 s |
| E-manifest | `sha256sum -c MANIFEST.sha256`; `(cd third_party; sha256sum -c SHA256SUMS)` | 0 | `MANIFEST.sha256`: 171/171 OK; `third_party/SHA256SUMS`: 47/47 OK | <1 s |
| E-vendor | SHA-256 of every file in `third_party/` vs files of all *other* project archives under `$SP/audit/all_extract` | n/a | 47/47 identical to upstream archives (sramlib, RAS SECDED, DataFabric checker, FlashLink+NANDLab, MemoryBridge) | <1 s |
| E-collide | module-name collision scan over all `.sv/.v` in all pristine projects | n/a | no differing-content duplicate among P55's vendored modules; see section 6 for P55 vs P56/P58 | <1 s |

### 3.1 Additional evidence (synthesis, hypothesis tests)

| # | Command | rc | Key output | Wall |
|---|---|---|---|---|
| E-synth | `make synth` -> `make_synth.log` (cwd `work/p55`) | 124 DNC | `small / mem` rc 0 (42.8 s); `small / asic` rc 0 (326 s); then killed during `small / ecp5`. The regenerated `synth/yosys/small_asic_stat.txt` and `small_asic_check.txt` are **byte-identical** to the shipped files; `check -assert`: "Found and reported 0 problems" | 480 s |
| A2 (hypothesis, COPY) | `make integ` in `work/p55_lb512`: testbench `tb_sfsb_nand.sv` localparams `LB_BYTES 128->512`, `PD 512->2048`, `PSP 128->320` and `config/nandlab_p55/nandlab.svcfg` `page_data_bytes 2048`, `page_spare_bytes 320` (nothing else changed) | 0 | `buffer LB=512 x 4, page image 2344 B; NANDLab page 2048+320 B`; `DoD round trip ... in 71709 cycles`; **`TB DoD: ... -- MET`, `TB RESULT: PASS (1536 checks)`** -> the default 2 344-byte page image also round-trips through unmodified FlashLink + NANDLab (but still only on a NANDLab config chosen to fit it) | 348 s |
| A3 (hypothesis, COPIES) | Mutants M03 (B2H CRC check V3 off), M05 (LBA tag check off), M10 (host mux switches a presented request: SFB2 R2), M15 (H2B completes before its writes are acknowledged): each applied with `audit_out/p55/mk_mut.py` (the project's own mutant table loaded read-only, pattern replaced exactly once) in a *copy* of `work/p55`, Verilator build with `OPT_FAST/SLOW/GLOBAL=-O0` (163-399 s under load, vs DNC with the project's `-Os` flow), then `+TEST=all +SEED=1` (`hypothesis_M*_run*.log`) | 0 each | **all four KILLED**: M03 `ERROR (corrupt): parity-invisible SRAM corruption -> CRC at egress (V3)`, `TB RESULT: FAIL (1 of 16403 checks failed)`; M05 `ERROR (ecc): LBA tag mismatch (misdirected read) -> LBA`, `FAIL (1 of 16335)`; M10 `sfb_protocol_checker.sv:90 ... [host] R2: request payload changed before acceptance` (`$stop`); M15 `ERROR (commit monitor): H2B completed with 255/256 writes acked of 256` (x4). Messages match the shipped `mutation.md` | 163-399 s build, 6-17 s run |

---------------------------------------------------------------------------------------------------------------------

## 4. Doc claims NOT reproduced / not substantiated

| Claim | Status |
|---|---|
| "15 / 15 regression runs PASS ... 171,246 checks; 8 configurations on Verilator, 2 on Icarus, plus DoD on both" (README) | Reproduced for Verilator base seeds 1-3 (16 403 / 16 184 / 16 336), `small` seed 1 (7 243) and the DoD bench (1 059) -- all check counts identical to the shipped report -- plus all 16 scenario tests individually on Icarus (15 933 checks). **Not reproduced:** wide, lb64, mo4, dram, nocrypt, plp configurations (Verilator builds did not fit the time-box under load), the Icarus `small` run, and the Icarus DoD bench (documented ~10-20 min). The total "171,246 checks / 15 runs" is therefore not re-derived. |
| "make integ-iv ... ~20 min" / "make sim-iv ~10 min" | `integ-iv` not run; `sim-iv` replaced by 16 per-test Icarus runs (E7). |
| "15 / 15 mutants detected" | Project script DNC under load (E6); four mutants (M03, M05, M10, M15) re-checked by hypothesis tests on copies (A3), all killed with the shipped messages. The other 11 are **not re-run**. |
| "Performance: 0.111 -> 0.955 beats/cycle ..., ENC 0.818 / DEC 0.845" | `make perf` not run (needs several more Verilator builds); **not reproduced**. |
| "Yosys: base 20 IHP macros (71 % used), 120 k cells, 12.6 k FF, 0 latches" | Only the `small` ASIC flow re-run: stat and check outputs byte-identical to shipped (E-synth). The `base` numbers (and ECP5 numbers) are **not reproduced**. |
| "NAND port ... ~200 MB/s at 100 MHz" | Derived from "one transaction at a time, >= 4 cycles per beat"; not measured by me. |
| "Reuse: 47/47 vendored files byte-identical" | **Reproduced** (E-vendor). |
| "Firmware interface: C header generated from RTL defines (up to date)" | **Reproduced** (E8). |
| "Definition of done met" | Reproduced on Verilator only, at LB=128 geometry with `profile ideal` NANDLab, 4-bit-ECC-capable device config (`ecc_bits 4`), SDR timing, a *derived* NANDLab config (spare 16 -> 128). No ONFI-compliance, vendor model, FPGA or silicon claim exists or could be substantiated. |
| README "Quick start ... make vendor-check REPO=<checkout>" | Needs the Aureom.AI checkout, which was off-limits; replaced by the hash comparison above. |

---------------------------------------------------------------------------------------------------------------------

## 5. Reusable interface reference

### 5.1 Buffer organisation (from `silicaflux_storage_buffer.sv`, docs/01-03)

* Parameters: `NUM_BANKS` 2/4/8 (default 4), `LB_BYTES` 64..4096 pow2 (512), `PAGE_LBS` 1/2/4/8 (4), `NUM_DSLOTS` 1..32 (8), `NUM_PSLOTS` 1..32 (4),
  `DQ_DEPTH` 4, `CQ_DEPTH` 8, `ENG_FIFO` 8, `HOST_MAX_OUT` 1..16 (1), `MAX_BURST` 16, `AGE_LIMIT` 16, `CRYPTO_EN` 1, `EXT_DRAM_EN` 0, `MC_SETS` 16, `DRAM_WIN` 1 MiB,
  `DRAM_BASE` 0x8000_0000, `ND_BASE` 0, `PLP_PRESENT` 0, `PERF_EN` 1, `SRAM_BACKEND` generic, `SRAM_MACRO` 0. Illegal sets stop elaboration in Verilator, Icarus, Yosys.
* Memory = `NUM_BANKS` x `sfsb_sram_bank` (`sram_sp`, 72-bit = 8 lanes x (8 data + 1 odd parity), low-order word interleave, 1RW, latency 1, byte-lane write mask, write ack).
  **Data slots** `NUM_DSLOTS x PAGE_LBS x LB_BYTES` (host ingress/egress, GC staging, clean read cache); **page slots** `NUM_PSLOTS x page image` (NAND page buffer = ECC encoder output / decoder input);
  **metadata buffer** in flip-flops, one `{VALID, POISON, LBA[31:0], CRC32C[31:0]}` per data-slot logical block.
  Base: 4 banks x 808 x 72 b = 25.25 KiB payload; small: 2 x 245.
* **Page image** (64-bit beats; `CWB = LB_BEATS + LB_BEATS/8`): for codeword j: data beats then check-byte beats (byte `i%8` of beat `i/8` = SECDED check byte of data beat i); then OOB = `PAGE_LBS*CWB` : `OOB+j = {CRC32C[63:32], LBA[31:0]}`, `OOB+PAGE_LBS` = OOB parity beat. Base: 4 x 72 + 5 = 293 beats = **2 344 B**; LB 128: **616 B**. Erased page (all-ones) is a valid codeword and decodes as `ERASED`.
* ECC: RAS `sfras_secded_enc/dec` K=64 (1-bit correct / 2-bit detect per 64 bits, 12.5 % overhead), inversion mask for erased pages. Miscorrection of >= 3 bit errors caught by V2 CRC. CRC-32C (Castagnoli 0x82F63B78, init/final 0xFFFFFFFF) generated on host ingress (G1), re-verified before encode (V1), after decode (V2) and on egress (V3); LBA tag verified at V2. Per-byte parity on every SRAM read.
* Backpressure: engines issue reads only when response space is reserved; every stage uses valid/ready so a stalled host port/bank/CQ stalls the pipeline without loss; CQ full stalls completion posting (`CQ_FULL` counter); descriptor queue full -> `QFULL` rejection; no hidden queueing of conflicting slot locks (`BUSY` returned).
* Arbitration: bank arbiter AGED > HIGH(NAND) > NORMAL, round robin, worst wait `AGE_LIMIT+7` cycles (23 default, checked each run); host mux burst-owner with `MAX_BURST` <= 16 beats, never across 4 KiB; HOST/GC weighted round robin (`W_HOST:W_GC` = 4:1 default).

### 5.2 Top-level ports (`silicaflux_storage_buffer`)

```
input  clk, rst_n (async assert / sync release provided by integrator)
// firmware: SFB2 slave 32-bit (CSR 0x000000, BUF 0x100000, DRAM window 0x800000; 16 MiB region)
input  fw_req_valid, fw_req_write, [31:0] fw_req_addr, [31:0] fw_req_wdata, [3:0] fw_req_wstrb, fw_rsp_ready
output fw_req_ready, fw_rsp_valid, [31:0] fw_rsp_rdata, fw_rsp_error
// NAND controller: SFB2 slave 64-bit (FlashLink sfnc_buf_master BUF_DW=64); only page slots owned by NAND (P2NAND)
input  nd_req_valid, nd_req_write, [31:0] nd_req_addr, [63:0] nd_req_wdata, [7:0] nd_req_wstrb, nd_rsp_ready
output nd_req_ready, nd_rsp_valid, [63:0] nd_rsp_rdata, nd_rsp_error
// host memory: SFB2 master 64-bit (hm_*), same signal set mirrored (outputs hm_req_*, inputs hm_req_ready, hm_rsp_*)
// external DRAM / MemoryBridge P24 upstream: SFB2 master 64-bit (xm_*), id=0,len=0,last=1
input  pwr_fail_i (async)      output irq, busy, init_done, plp_dirty
```
SFB2 rev 2.0 rules (DataFabric PROTOCOL.md): one beat per transaction (no native bursts), a presented request may not be withdrawn (R2), exactly one in-order response per request, responses never in the acceptance cycle (R5), at most one transaction per crossbar port (R6), write response after the write is performed (R7), `rsp_error=1` => `rdata=0` (R8), DW-aligned addresses (R9), reset cancels in-flight transactions without responses (R11).
Firmware interface: `sw/include/sfsb_regs.h` (generated from `rtl/sfsb_defs.svh`): ID `0x53465342`, VERSION `0x37010000`; descriptor DESC0..3 + SUBMIT (`OPC` 1 H2B / 2 B2H / 3 ENC / 4 DEC, CLASS HOST/GC, CRYPT, TID, LB_FIRST, LB_COUNT, DSLOT/PSLOT, 32-bit 8-byte-aligned host address, LBA); completion CPL0..2 + CPL_POP; slot commands ALLOC_D/FREE_D/COMMIT_D/CACHE_D/CLAIM_D/LOOKUP/INVAL/ALLOC_P/FREE_P/P2NAND/P2FW; submission codes (`SFSB_SUB_*`, 0x0-0xF), completion status (`SFSB_ST_*`: OK, CORRECTED, ERASED, UNCORR 0x10, CRC 0x11, LBA 0x12, BUF_PAR 0x13, HOST_ERR 0x14, META_UE 0x15), 38 performance counters at 0x200+4i.

### 5.3 Integration facts needed by a FlashLink / FTL user

* FlashLink `BUF_DW` must be 64; the NAND port base is `ND_BASE`; the controller may only touch page slots the firmware has handed over with `P2NAND`, otherwise `rsp_error`.
* DoD geometry: `LB_BYTES=128, PAGE_LBS=4, NUM_BANKS=2` => 616-byte page image; NANDLab `page_data_bytes 512, page_spare_bytes 128, ppb 16, blocks_per_lun 64, luns 2, planes 2, ecc_bits 4, profile ideal`.
* The firmware (testbench) drives: reset NAND, read ONFI parameter page into a NAND-owned page slot, set `CTRL.WP_N`, erase, H2B -> ENC -> `P2NAND` -> FlashLink PROGRAM -> READ_PAGE -> `P2FW` -> DEC -> B2H; on program failure keep slot DIRTY and re-program elsewhere; `COMMIT_D` only after PROGRAM success.

---------------------------------------------------------------------------------------------------------------------

## 6. Integration risks / incompatibilities

1. **Page-format conflict with the FTLs (P56/P58/P58b).** The FTL expects `page_data_bytes + 16-byte spare record {BBM=FFh, type, LPN, 48-bit SEQ, CRC-32}` programmed in ONE operation under one ECC. P55's NAND image is `data + check bytes + {CRC32C, LBA} OOB` with its own codeword framing; there is nowhere to carry the FTL spare record, and two different CRCs (CRC-32C here, IEEE CRC-32 in the FTL) would both be computed. An adapter (or a redesigned image) is required; P55's LBA tag is per logical block while the FTL tags per logical page (LPN) and 48-bit SEQ.
2. **ECC mismatch.** P55 uses RAS SECDED(72,64); P54 ECCCore (BCH/LDPC, split-OOB layout, CRC-16) is a different engine/layout and is not wired to P55 (P55 predates it; its audit says "nothing in the repository"). Integration means replacing `sfsb_ecc64` and the page image.
3. **Geometry coverage gap.** DoD run only for LB 128 x 4 (616 B) on a derived 512+128 NANDLab page. The default 2 344-byte image, real page sizes (4/8/16 KiB + OOB), multi-LUN/channel, vendor models: untested.
4. **SFB2 rev 2.0 limits.** One beat per transaction, one outstanding on crossbar ports; host throughput is latency-bound (docs/06: 0.111 beats/cycle at 8-cycle latency with `HOST_MAX_OUT=1`; needs point-to-point pipelined endpoint to scale). The NAND port serves one transaction at a time.
5. **External IP not present.** ASIC SRAM macros are pin-only black boxes (IHP SG13G2 `RM_IHPSG13_1P_*_bm_bist`; SKY130/GF180 stubs; "commercial 28/65/130 nm: PENDING"); vendor behavioural models must be fetched (`scripts/mem/fetch_open_macros.sh`, not in archive). The 9-bit-lane (72-bit) word needs bit-granular write masks (IHP `_bm_`); SKY130 byte-mask macros are rejected at elaboration. Generic backend becomes flip-flops in synthesis (120 k generic cells / 12.6 k FF for 25 KiB).
6. **DRAM is simulation-only.** The adapter targets P24 MemoryBridge verified only against its *simulated* controller (`extmem_sim_mc`); no DDR PHY/controller exists.
7. **Volatile buffer; durability is firmware's job.** H2B completion = "committed in volatile buffer". Early acknowledgement permitted by `WCE | PLP_PRESENT`; `PLP_PRESENT` is just a parameter (no hold-up energy model, no qualification gate -- compare P58's completion gate). Reset or power loss discards all slots.
8. **Detect-only SRAM protection.** Parity + CRC detect; dirty data corrupted in the buffer is lost (poisoned); no scrubbing.
9. **Scalability of metadata.** Slot metadata and the read-cache CAM are flip-flops (~40 % of logic): fine for tens of slots, not for MB-scale buffers.
10. **Placeholder crypto / information leak.** Plaintext CRC in OOB leaks 32 bits/block if a real cipher is added.
11. **Simulator-specific coding.** Written to pass Verilator 5.020 *and* Icarus 12 (e.g. testbench restructured for Icarus limits); the integration bench with Icarus takes ~20 min. Different simulator versions may behave differently.
12. **Duplicate third-party module names.** P55's vendored `sram_*`, `sfras_*`, `sfnc_*`, `extmem_*`, `sfb_protocol_checker` are identical to the upstream archives; no differing-content duplicates were found against P56/P58/P58b (those carry only `sfs_*`/`sfv_*`/`cc_*` from P51/ControlCore). A real conflict exists only between the two P58 variants (see p58_audit.md).

---------------------------------------------------------------------------------------------------------------------

## 7. Licensing notes

* **No licence file** in the archive or in any vendored subtree (`third_party/PROVENANCE.md`: "No licence file exists in the repository"); no SPDX or copyright headers in the sources. Rights status is *undefined*; obtain explicit licensing before redistribution.
* The SRAM library's ASIC black-box stubs state that the port lists were copied from vendor Verilog models "(Apache-2.0 sources)" (IHP / SkyWater / GF180 open macros); those models are **not shipped** and must be fetched separately under their own licences. Foundry macros/PDKs bring their own terms.
* FlashLink, NANDLab, MemoryBridge, RAS, DataFabric files are vendored from the same repository (same unknown terms).
* Tools: Verilator (LGPL/Artistic), Icarus (GPL), Yosys (ISC) -- used only as tools.
