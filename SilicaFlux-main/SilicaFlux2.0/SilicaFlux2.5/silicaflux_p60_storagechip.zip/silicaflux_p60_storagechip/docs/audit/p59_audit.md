# Task A -- Is Project 59 (SecureStore) in the repository?

Audit date: 2026-11-12. Repository: `/home/user/Aureom.AI` (read-only; nothing in it was modified).
Raw logs and scan outputs: `/tmp/claude-0/-home-user-Aureom-AI/c80a8d5d-1b1f-56e3-9758-b78cee890e29/scratchpad/audit_out/x_support/`.

## 1. Definitive finding

**NOT FOUND.** There is no Project 59, no "SecureStore", no storage encryption-at-rest engine (AES, XTS-AES, AES-GCM or any
other cipher), no storage key-management block, and no T10 PI/DIF implementation anywhere in the repository, including every
nested zip. The sibling storage projects explicitly state that this functionality does not exist in the repository
(quotes in section 4). Projects 51-58 are present; 59 is absent.

| Storage project | Present? | Where |
|---|---|---|
| 51 StorageCore | yes | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-storagecore-p51.zip` |
| 52 NAND Digital Twin (NANDLab) | yes | `.../SilicaFlux2.5/silicaflux-nandlab-v0.1.0.zip` |
| 53 FlashLink | yes | `.../SilicaFlux2.5/silicaflux-flashlink-p53.zip` |
| 54 ECCCore | yes | `SilicaFlux-main/silicaflux-ecccore-p54.zip` |
| 55 BufferCore | yes | `.../SilicaFlux2.5/silicaflux-buffercore-p55.zip` |
| 56 Flash Translation Engine (FlashMap) | yes | `.../SilicaFlux2.5/silicaflux-flashmap-p56.zip` |
| 57 NVMe HostCore | yes | `.../SilicaFlux2.5/silicaflux-nvme-hostcore-p57.zip` |
| 58 PowerSafe | yes (two versions) | `.../SilicaFlux2.5/silicaflux-powersafe-p58.zip`, `silicaflux-powersafe-p58 (1.1).zip` |
| **59 SecureStore** | **NO** | nothing |

## 2. What was searched (evidence of exhaustiveness)

All commands were run by me in this container. Counts are from the logs in `x_support/`.

| # | Search | Scope | Result |
|---|---|---|---|
| 1 | Member-name inventory of every zip, recursively through nested zips (`inventory.py`; `inventory_silicaflux_main.txt` 36 704 lines, `inventory_root_silica_zips.txt` 963 lines) | all 100 zips under `SilicaFlux-main/` (incl. `SilicaFlux2.0/SilicaFlux2.5/`) + root `SilicaFlux ThermalLab (1).zip`, `SilicaFlux-main.zip`, `SilicaFluxML.zip`, `silicaflux-p40-floorplanbuild.zip`, `silicafluxai.zip`, `silicafluxbitcoinasic.zip` | no member named `*securestor*`, `*p59*`, `*xts*`, `*aes*` (cipher), `*encrypt*`, `*hmac*`, `*key*mgmt*`. Only name hits are SHA-256 hashing (bitcoin ASIC, SecureBoot P28), `sha256` *checksum manifests*, and an R/TypeScript `sha256-learn-r-asic-ml-optimizer.zip` (mining-ASIC ML simulator, software only). |
| 2 | Full recursive extraction of all 105 zips + `soc_integration.tar.gz` (32 746 files, 1.6 GB, `all_extract/`) followed by `grep -r -I -i` for `secure[-_ ]?stor`, `project 59`, `\bp-?59\b` (word-bounded, base64 lines excluded) | all text in those trees | **0 matches** (`grep_p59_securestore_clean.txt` is empty). Sanity: the same greps find `storagecore` in 215 files and `p58` in 103 files, so the search is working. |
| 3 | Stream scan of **every** zip under `/home/user/Aureom.AI` (400 zips, 49 341 members, 363 MB of text, nested zips up to depth 4) for the same names and for RTL `module` names matching aes/xts/gcm/hmac/sha*/sha3/keccak/chacha/sm4 (`all_repo_zip_content_scan.txt`) | whole repo | 40 hits, **all** SHA-256 RTL (bitcoin ASIC x2 copies, SecureBoot P28). **No** AES/XTS/GCM/HMAC/ChaCha module in any zip, and 0 name hits for SecureStore/p59. |
| 4 | `find` for `*securestor*`, `*secure-stor*`, `*secure_stor*`, `*p59*`, `*xts*`, `*encrypt*` over the working tree (excluding `.git`) | whole repo | 0 files |
| 5 | Plain-text grep of the repo working tree (non-zip) for `secure[-_ ]?stor(e\|age)` | whole repo | 3 hits, all `Apple/*.swift` (iOS app code defining `SecureStorageFactory`: an unrelated Swift keychain wrapper, not SilicaFlux hardware). |
| 6 | `git log --all --name-only` filtered for `secure.?stor` / `p59` (50 commits, branches `main`, `claude/funny-sagan-l1saat`) | git history | 0 |
| 7 | `pdftotext -layout` of **all 37 PDFs** (23 under `SilicaFlux-main/` incl. `SilicaFlux_Update 03-11-26.pdf`, `SilicaFlux Codebase Research Report.pdf`, `ASIC Fabrication Audit`, `Production Test & Qualification Plan`, RTL-to-GDSII report; plus the 14 root-level PDFs) | all PDFs | 0 hits for SecureStore / P59 / "Project 59". The only SSD/NAND/AES/encrypt words are generic ("3D NAND" trends; "encrypted LEF/DEF" for foundry IP). No PDF mentions an SSD controller programme. |
| 8 | Term search (`encrypt|decrypt|crypto|cipher|xts|aes-*|hmac|gcm|chacha|ed25519|key wrap/management/derivation/vault/slot|t10|dif|pi guard|self-encrypt|crypto erase|opal|tcg`) over the extracted trees (`grep_crypto_terms_all.txt`, 757 lines after removing SoftFloat/Monocypher/plotly noise) | all extracted text | Hits are concentrated in exactly three places: SecureBoot P28 (359), BufferCore P55 (125 - the placeholder crypt stage and its tests), PowerSafe/FlashMap (`sanitize` = ASan/UBSan, noise). The remaining hits are `T10` test-case labels, `sanitize`, Android `aes` CPU-feature flags (`silicon-forge`) and "cryptographic checksum" text in a web UI (`twinlab`) - none is hardware or storage crypto. |

Duplicate-copy check: `silicafluxbitcoinasic.zip` (root) is byte-identical to `SilicaFlux-main/SilicaFlux2.0/silicafluxbitcoinasic.zip` (SHA-256 prefix `0704b1de777ecdcc`), likewise `silicafluxai.zip` and `SilicaFluxML.zip`, so no hidden second version exists.

## 3. Roadmap and numbering evidence

No document lists a Project 59 or a future "SecureStore". The highest storage project number referenced anywhere is 58
(`Project 58` appears ~150 times; `p59` only occurs inside base64 image data in HTML reports and was excluded as noise).
No PDF contains a project/roadmap table for the 51-59 programme.

## 4. What the sibling projects themselves say about security / encryption (verbatim evidence)

| Project | Statement | File |
|---|---|---|
| P51 StorageCore | "Firmware images are CRC32-checked by the ControlCore boot ROM; there is **no authentication**, no encryption at rest, no key management." | `silicaflux-storagecore/docs/08_LIMITATIONS.md` line 27 |
| P55 BufferCore | "Encryption (AES / XTS) - **Nothing** (Project 28 has SHA-256 only) ... `CRYPTO_EN` provides a keyed, LBA-tweaked XOR transform that is explicitly **not a cipher**." | `silicaflux-buffercore/docs/00_AUDIT.md` |
| P55 BufferCore | `sfsb_keystream`: "THIS IS NOT A CIPHER ... No AES/XTS engine exists in the repository" | `silicaflux-buffercore/rtl/sfsb_funcs.svh` |
| P57 NVMe HostCore | Optional admin commands "none (Format NVM, Firmware Commit/Download, ... **Security Send/Receive, Sanitize** ...) -> Invalid Opcode; OACS = 0"; namespaces: "one, 512-byte LBA format, **no metadata, no protection information**" | `silicaflux-nvme-hostcore/docs/10_LIMITATIONS.md` |
| P54 ECCCore | "End-to-end protection (host-generated guard tags, T10-DIF style) is outside this engine." | `silicaflux-ecccore/docs/04_FAILURE_MODES.md` |
| P28 SecureBoot | "The device holds no secret"; keys in `keys/` are test keys "derived from published labels"; no OTP/eFuse (a register *model*); anti-rollback is **not** persistent | `silicaflux-secureboot/docs/05_CRYPTOGRAPHY.md`, `13_LIMITATIONS.md` |
| P07 TestCore | debug unlock is a password interlock; "Replace password unlock with challenge-response (HMAC/ECDSA debug certificates) and per-device keys" is listed as an open gap | `docs/13_production_readiness_gaps.md` |

## 5. What crypto / integrity DOES exist, and what it actually provides

### 5.1 Summary table

| Item | Where | Algorithm | Real? | Storage-usable as-is? |
|---|---|---|---|---|
| SHA-256 hardware core + streaming wrapper | P28 `silicaflux-secureboot-p28.zip`: `rtl/sb_sha256_wrapper.sv`, `rtl/sb_sha256_stream.sv`, vendored `third_party/secworks-sha256/rtl/sha256_core.v` (+`sha256_w_mem.v`, `sha256_k_constants.v`) | SHA-256 (FIPS 180-4), SHA-224 mode bit exists in the core | Yes - **VERIFIED by me** (below) | Only as a hash primitive (digest, HMAC/HKDF building block after wrapping). Not an integrity engine, not a cipher. |
| Ed25519 signature verify | P28 `firmware/sb/sb_policy.c` + vendored Monocypher 4.0.2 | Ed25519 (RFC 8032), **software on the RV32 ControlCore ROM** | Yes (software; vectors 9 214/9 214 recorded by project, not re-run by me) | No hardware; 6.4 M cycles per verify (~257 ms @ 25 MHz) - boot-time only |
| SHA-256 mining compressor / pipeline | `silicafluxbitcoinasic.zip`: `rtl/sha256/*.sv`, `rtl/pipeline/sha256_pipeline.sv` | SHA-256 compression: iterative (1 round/clk, 64 clk/block) or 7 unrolled pipeline depths; double-hash with midstate | Yes - **partly VERIFIED by me** (below) | Block-level compression only (caller supplies padded 512-bit block + state); Bitcoin-specific wrapper (nonce, target); no licence |
| `sha256-learn-r-asic-ml-optimizer.zip` | R + TypeScript | SHA-256 in software (R) + a JS "ASIC engine" simulator | Software only | No (not RTL) |
| Placeholder "crypt" stage | P55 BufferCore: `rtl/sfsb_funcs.svh::sfsb_keystream`, `sfsb_eng_enc.sv`, `sfsb_eng_dec.sv` (`CRYPTO_EN`, regs `KEY_LO/HI`, descriptor flag `CRYPT`) | keyed xorshift/rotate XOR mask tweaked by (LBA, beat) - **explicitly not a cipher** | Real RTL, **not cryptography** | It is the right *pipeline slot* for an XTS engine (see 5.3), nothing more |
| CRC-32C per logical block + LBA tag in OOB | P55 BufferCore (G1/V1/V2/V3 integrity points), `docs/02_DATA_PATH.md` §4 | CRC-32C (Castagnoli 0x82F63B78, RFC 3720); odd byte parity on SRAM lanes | Real, simulated (project's claim; not re-run by me) | A T10-PI-like *guard+reference tag* concept, but **not** the T10 DIF format (16-bit CRC-T10 guard); NVMe P57 exposes no PI |
| SECDED per 64-bit beat | P26 RAS `sfras_secded_enc/dec` (reused by P55) | extended Hamming, any K | Real (see Task B) | error correction, not security |
| CRC-32 firmware image check | ControlCore `firmware/common/crc32.c`, boot ROM | CRC-32 | Real | integrity only, "no authentication" |
| BCH / LDPC golden models | P54 ECCCore (`ext/linux_bch/bch.c` **GPL-2.0**, `ext/pyldpc`) | BCH/LDPC (software reference) | ECC, not security | licence caution: GPL-2.0 file bundled |

Not present anywhere: AES (any mode, any implementation), XTS tweak/GF(2^128) multiplier, GCM/GHASH, HMAC-SHA256 RTL, KDF (HKDF/PBKDF), TRNG/DRBG, key wrapping, secure key RAM/OTP, T10 PI generation/verification, NVMe Security Send/Receive, TCG Opal/SED command set, sanitize/crypto-erase, secure erase of NAND key material.

### 5.2 Audit of the SHA-256 core(s)

**P28 SecureBoot SHA-256 (secworks core + SilicaFlux wrapper)**

* Interface of `sb_sha256_wrapper` (all verified by reading the RTL): `clk, rst_n, start, in_valid, in_ready, in_data[31:0], in_nbytes[2:0], finish, busy, done, digest[255:0], kat_done, kat_ok`. A 32-bit word stream with byte-granular tail; padding and length are added in `sb_sha256_stream` (FIPS 180-4 §5.1.1).
* Core `sha256_core`: `init, next, mode, block[511:0] -> ready, digest[255:0], digest_valid`; one round per clock (64 rounds + overhead per block). Wrapper adds a **power-on known-answer self-test** ("abc" and the 448-bit FIPS vector) and fails closed if it breaks.
* Synthesizable: yes. Project's Yosys 0.33 `synth_ecp5` estimate (not re-run by me): `sha256_core` 4 735 LUT4 / 1 034 FF; `sb_sha256_wrapper` 5 965 LUT4 / 1 859 FF; no timing, no P&R.
* **VERIFIED BY ME:** `python3 scripts/unit_sb.py` on a copy at `$SP/work/secureboot` (Verilator 5.020, exit 0, log `x_support/secureboot_unit_sb.log`, report `work/secureboot/reports/unit_sb.md`):
  * `tb_sb_sha256` vs NIST CAVP SHA256ShortMsg + LongMsg (129 messages) + Monte (100 checkpoints x 1 000 chained hashes = 100 000 hashes) + power-on KAT: **PASS, 230 checks, 0 fails**
  * same with 40 % random input stalls: **PASS, 130 checks**
  * injected stuck-at fault during KAT: `kat_ok = 0`, client held off (fail closed): **PASS**
  * `tb_sb_dma_guard` 200 000 random descriptors vs reference: **PASS, 798 136 checks**; `tb_sb_core` **PASS, 45 checks**
  * Caveat: the CAVP vector files are the ones shipped in the zip (`vectors/nist_cavp_sha256/`, plus the project's `gen_sha_vectors.py`); I did not independently download them. The expected digests are the NIST ones, so the pass is meaningful, but provenance of the vector files is the project's.
* Throughput: ~172.6 cycles per Monte hash (each = 2 compressions) -> ~86 cycles per 512-bit block incl. wrapper overhead (my derivation from the log) = about 6 bits/clk, i.e. roughly 0.35 GB/s at 500 MHz *per core*. Fine for key derivation, metadata MACs and boot; **not** a per-sector hash at NVMe line rate without replication.
* Licence: secworks `sha256` BSD-2-Clause (compatible, keep notice); wrapper = project code ("internal Aureom.AI", no licence file in the repository).

**Bitcoin SHA-256 ASIC** (`silicafluxbitcoinasic.zip`, identical copy under `SilicaFlux2.0/`)

* Modules: `sha256_pkg`, `sha256_ch/maj/sigma/round/schedule_step/message_schedule`, `sha256_compressor` (iterative, `start, state_in[255:0], block_bits[511:0] -> busy, done, state_out[255:0]`, 64 clk/block), `sha256_pipeline` (unrolled, 7 depths), `sha256_double_hash` (midstate reuse), plus nonce/target/control for mining. The top-level SilicaFlux generator and Python model are Bitcoin-specific.
* No padding/streaming/IV handling in the compressor (the caller supplies the state and padded block), no KAT, no HMAC.
* Project claim: 25/25 simulation runs against a Python golden model (+ real Bitcoin genesis block hash). **My re-run (partial):** `PYTHONPATH=.:python python3 -m silicaflux_bitcoin.verify` on a copy (Icarus 12), 8-minute time-box on a heavily loaded host: Python model self-consistency up to 10 000 vectors PASS; RTL `tb_sha256_{sigma,round,message_schedule,schedule_step,compressor,double_hash}` and `tb_sha256_pipeline` depths 64/32/16/8/4 PASS (the harness's own 90 s timeout hit `schedule_step` under load, re-run with a longer timeout: PASS); nonce allocator and target compare PASS. Not completed: pipeline depths 2 and 1, hash-core/array/miner-top testbenches, 100 000-vector Python run. So the SHA-256 datapath of the mining design is **partially verified by me**; details in `support_blocks_audit.md` section 2.9, logs `x_support/btcasic_verify.log`, `btcasic2_rest.log`.
* Licence: none in repository; no third-party code.
* Verdict: a second SHA-256 implementation with a *different* (mining) architecture. For storage it adds nothing the P28 core does not already provide, and the P28 core is the better-wrapped one (padding, stream, KAT, BSD-2 provenance).

### 5.3 Can any of this serve as storage encryption/integrity? (XTS-AES vs just hashing)

* **XTS-AES (data at rest): no.** There is no block cipher in the repository. SHA-256 cannot replace it (hash, not a cipher; XTS needs an AES-128/256 core, a tweak generator `AES_K2(sector)` and GF(2^128) alpha-multiplication per 16-byte block, with 512-byte or 4 KiB data units). A SecureStore project would have to **bring an AES core in as external IP or new RTL, plus the XTS wrapper, test against IEEE 1619 / NIST CAVP XTS vectors (verifying with e.g. OpenSSL as an independent reference)**. None of that exists here. (I have not evaluated third-party AES IP; any choice carries its own licence and verification burden.)
* **Where it would plug in (this is real and useful):** BufferCore P55 already defines the contract an encryption engine must meet and has the slot and tests for it (all in `silicaflux-buffercore`):
  * write path `... CRC(plaintext) -> crypt -> SECDED ECC -> page image -> NAND`; read path `ECC decode -> decrypt -> CRC + LBA check`;
  * descriptor flag `CRYPT`, key registers `KEY_LO/HI`, 64-bit data beat (`sfsb_keystream(kk, lba, beat)` gives the (key, LBA, beat) tweak inputs an XTS engine would use);
  * integrity values are computed/verified on **plaintext**, ECC protects the stored ciphertext, wrong key is caught at V2 (`t_crypt` test); their own note that the plaintext CRC in the OOB leaks 32 bits per block and a real design must encrypt the OOB or use a keyed MAC.
  * Constraint to carry forward: the placeholder is 64 bits/beat, the XOR mask is length-preserving. A real XTS engine is also length-preserving (no expansion) so no layout change is needed, but a 128-bit block cipher will need a 2-beat or 128-bit beat adaptation and a latency/throughput match with the 64-bit engine FIFOs. Authenticated modes (GCM/AEAD) would need a per-page/per-block tag slot: the current page image (docs/02 §2) has per-codeword SECDED check bytes and one 64-bit OOB metadata beat per logical block `{CRC32C[63:32], LBA[31:0]}`, with no field reserved for an authentication tag or key/epoch identifier.
* **Integrity (CRC/PI/hash): partially.** CRC-32C per logical block with LBA binding exists and is simulated (P55), SECDED per beat (P26), CRC32 firmware check; SHA-256 is available for hashing metadata/firmware (P28). Missing: T10 PI format/PRACT/PRCHK handling in NVMe (P57 says none), keyed MAC (HMAC/GMAC) for tamper detection.
* **Key management: no.** P28 holds only *public* root keys in ROM and a non-persistent fuse model. There is no device key hierarchy, no key wrap, no TRNG, no KEK/DEK store, no secure key RAM, no crypto-erase. Ed25519 verify in software is usable for signed firmware/config updates only.

### 5.4 Bottom line for the integration effort

* P59 does not exist: it must be **designed from scratch**, not integrated.
* Reusable today: SHA-256 (P28 wrapper, BSD-2 core), Ed25519-verify firmware (Monocypher, BSD-2/CC0) for signed-firmware/boot, the P55 crypt pipeline slot + CRC-32C/LBA integrity scheme, P28's lifecycle/DMA-guard concepts, P07/P39 debug-lock hooks.
* Not reusable (does not exist): any cipher, XTS, GCM, HMAC RTL, KDF, TRNG, key store/OTP, PI, Opal/Security Send, sanitize.

## 6. Reproduction notes and limits of this audit

* VERIFIED = I ran it here and saw it pass. Everything labelled "project claim" is quoted from the project's own reports and was not re-run by me.
* My bitcoin-ASIC `verify` result is recorded in `x_support/btcasic_verify.log` / `btcasic2_rest.log` and summarised in `support_blocks_audit.md` section 2.9, including the steps cut by my 8-minute time-box.
* Searches cover text files and PDFs. Binary-only content (images, `.hex/.elf` blobs, the `Screencast ... .webm`) was not searched for the string, but the sibling documentation consistently states the functionality does not exist, and no RTL, firmware source or script implements it.
* Absence of evidence is the finding here, supported by (a) 400-zip exhaustive scan, (b) PDFs, (c) git history, and (d) explicit "does not exist" statements in P51/P55/P57/P54/P28 docs.
