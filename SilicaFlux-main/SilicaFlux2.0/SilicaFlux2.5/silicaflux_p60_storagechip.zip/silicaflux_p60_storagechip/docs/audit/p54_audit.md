# Audit of Project 54 — "ECCCore" BCH/LDPC NAND ECC engine (silicaflux-ecccore)

Auditor environment: Linux container, 4 cores shared with other concurrent sessions (load average 8-33 during the runs; **wall times are inflated**; the project
itself says `make regress` takes ~1.5 h and `make synth` ~2 h, so I ran a time-boxed subset, each command under an 8-minute cap), Python 3.13.18 in a dedicated
venv (`$SP/venv_p54`: galois 0.4.11, numba 0.68.1, numpy 2.5.4, scipy 1.18.1, pytest), Verilator 5.020, Icarus 12.0, Yosys 0.33, nextpnr-ecp5 0.6, gcc 13.
Pristine source `$SP/audit/p54_ecccore/silicaflux-ecccore`; runs in a copy `$SP/work/p54/silicaflux-ecccore`
(`SP=/tmp/claude-0/-home-user-Aureom-AI/c80a8d5d-1b1f-56e3-9758-b78cee890e29/scratchpad`). Raw logs `$SP/audit_out/p54/`. No project file was patched.
(`NUMBA_NUM_THREADS=1`, as the Makefile does.)

## 1. Summary verdict

**P54 is a substantial, internally consistent and genuinely synthesizable BCH ECC engine with an unusually strong verification set-up — and every shipped number I re-ran matched the project's reports exactly (check counts, latencies, error counts within ~1 %).** The Python golden model is validated against three independent sources (65/65 checks reproduced), and the RTL is bit-exact against it on 38,554 (t=4, BCH(255,223)), 6,037 (t=4/512 B), 6,073 (t=8/512 B) and 600 (t=40/1 KiB) codewords with random back-pressure and mid-traffic resets (2.36 M / 6.48 M / 6.48 M / 1.61 M checks, **0 errors**), plus the full page engine on 60/60/60/20 pages and the LDPC proof of concept; the same engine passed the P52 pin-level NAND twin with directed faults (0 RTL-vs-reference mismatches, 0 NAND protocol/timing violations). Verilator `-Wall` lint of 14 tops: 0 RTL warnings; Yosys `synth -flatten; check -assert` of the full page engine: 0 problems, no latches. Mutation re-runs: MUTATION_SUMMARY.

What it **is** good for: SLC / light-MLC class NAND with **t = 4 or t = 8 correctable bits per 512-byte sector (BCH over GF(2^13), 4212 / 4216-bit shortened codewords, 16-byte spare)**, with erased-page handling, CRC-16 miscorrection backstop, bad-block-marker protection, statistics registers and RAS events.

What it is **not**: (1) **Not an LDPC solution** — the LDPC is a 128-bit, rate-1/2, single-word, non-pipelined proof of concept (~9 MHz on ECP5, hard decisions only from the page engine), simulation-only; (2) **not sufficient for TLC/QLC** (stated by the project); (3) the **t = 40 / 1 KiB decoder never routed** on an LFE5U-85F (84 k gates, 56 k LUT4; pre-route 19.6 MHz); (4) **not integrated** with P53 FlashLink or P51 and never run against anything but P52's illustrative twin; (5) data path is 8 bits/cycle (~0.98 B/cycle, enough for SDR x8 only); (6) its guarantees are for the tested error models only (independent errors, directed patterns, P52 `stress` physics) — BCH beyond t miscorrects a fraction of patterns (solid 10-bit bursts on BCH(255,223) always).

Interface caveats that matter for the integrated top: the engine wants the page **spare-first**, speaks **8-bit ready/valid streams** (not SFB2), has **zero spare slack** in every shipped configuration, and its geometry is compile-time while P53 learns geometry at run time.

## 2. Classification table

Legend as in the P52 audit (Impl / Verified = I ran it and saw it pass / Partial / Missing / Incompat / SimOnly / ExtIP). One primary status per row.

| Function / feature | Impl | Verified | Partial | Missing | Incompat | SimOnly | ExtIP | Note / evidence |
|---|---|---|---|---|---|---|---|---|
| Python golden model (GF(2^m), BCH enc/dec, page format, CRC) validated against independent sources | | X | | | | | | E3 `make check-ref`: **65/65** (published BCH(255,k) table, `galois`, Linux `lib/bch.c`, 3 key-equation solvers, exhaustive 1-/2-bit patterns). |
| BCH core RTL, BCH(255,223) t=4 baseline (`B255T4`) vs reference | | X | | | | | | E7: 38,554 records, 2,360,800 checks, 0 errors (random back-pressure 30 %, 12 mid-traffic resets, framing test). |
| BCH core RTL, 512 B sector t=4 (`N512T4`, GF(2^13), n=4212) | | X | | | | | | E7: 6,037 records (every one of 4,212 single-bit positions), 6,478,401 checks, 0 errors. |
| BCH core RTL, 512 B sector t=8 (`N512T8`, n=4216) | | X | | | | | | E7: 6,073 records, 6,478,836 checks, 0 errors. |
| BCH core RTL, 1 KiB sector t=40 (`N8KT40`, GF(2^14), n=8928) functional correctness | | X | | | | | | E7: 600 records, 1,611,442 checks, 0 errors (Verilator only; Icarus limited to 120 records by the project). |
| t=40 decoder implementability (area / routing / Fmax) | | | X | | | | | Project: 84 k gates, 56 k LUT4 (66 % of LFE5U-85F), **did not route**, Fmax pre-route 19.6 MHz. Not re-run (hours). |
| Page engine `silicaflux_storage_ecc` (layout, CRC-16, OOB budget, BBM, erased pages, miscorrection detection, registers, IRQ) at 512+16 (t=4, t=8), 2048+64 (t=8, 4 codewords), 8192+744 (t=40, 8 codewords) | | X | | | | | | E6: 60/60/60/20 pages, 92,086 / 91,576 / 369,562 / 843,227 checks, 0 errors. |
| Decoder status classes CLEAN / CORRECTED / ERASED / UNCORRECTABLE / INTEGRITY_FAIL | | X | | | | | | E6 page TB (all five outcomes bit-exact vs reference, incl. constructed miscorrections). |
| Erased-page (coset MASK) handling, <= t flips -> ERASED | | X | | | | | | E6, E10 (twin: erased with 0 / 1 / t+1 flips). |
| Bad-block-marker byte protection (`rd_pst_bbm`) | | X | | | | | | E6; E10 twin (stuck BBM bit -> bbm=0x7F, sectors CLEAN). |
| Register window (ID/VERSION/CFG0-2/CTRL/STATUS/IRQ/statistics) | | X | | | | | | Read and checked in the page TB (E6). |
| Spare-first read path against the P52 pin-level model (00h-30h at column PAGE_DATA, 05h-E0h back to 0) | | X | | | | | | E10: `nand_protocol_errors=0 nand_timing_violations=0 errors=0` on N2KT8 and N512T4. |
| NAND-twin directed fault injection (0 / 1 / t / t+1 / burst / random / erased / BBM) | | X | | | | | | E10: both configs PASS, 0 RTL-vs-ref mismatches; outcome totals N2KT8 CLEAN 17 / CORRECTED 10 / ERASED 11 / UNCORRECTABLE 2; N512T4 2 / 3 / 2 / 3 (= shipped). |
| NAND-twin retention bakes (RTL) and statistical campaign (Python) | | | X | | | | | E10b (`--quick`: 32 pages = 128 codewords, 4 bakes) 0 mismatches, every codeword <= t corrected / > t detected; E10c (`--quick`) 0 undetected in 12 rows. Full-size campaigns (96 pages, 256 pages) not re-run. Error model = P52 `stress` profile (uncalibrated). |
| LDPC proof of concept (QC-LDPC(128,64)): reference validation, RTL vs fixed-point reference, page engine with LDPC codec | | X | | | | | | E5 7/7; E8 1,646 records / 55,964 checks 0 errors; E6 L24 200 pages / 22,251 checks 0 errors. |
| NAND-grade LDPC (1-4 KiB codewords, pipelined decoder, soft reads from NAND, read-retry integration, error floor) | | | | X | | | | PoC only (128 bits, ~9 MHz, single word, hard decisions from the page engine); research notes only (docs/05). |
| Mutation check (9 mutants) | | X | | | | | | E12: M1-M8 **killed** (M7 needed a re-run after an interrupted first attempt), **M9 survived** exactly as the project reports (argued equivalent; not proven by me). |
| Lint, Verilator `-Wall`, 14 tops | | X | | | | | | E9: 0 RTL warnings (6 warnings/top in the thin wrapper file only; 8 in-source `lint_off` waivers, all UNUSEDSIGNAL/UNUSEDPARAM). |
| Synthesizability (Yosys 0.33 `synth -flatten` + `check -assert`) of the full page engine | | X | | | | | | E11: `syn_ecc_N2KT8` 0 problems, 43,459 generic cells, no latches. |
| Yosys/ECP5 per-block area and Fmax numbers (docs/07 table) | | | X | | | | | E14: SYNTH_SUMMARY |
| Code coverage (line 93.6 %, toggle 89.2 %) | X | | | | | | | Not re-run (8 instrumented builds). |
| Second simulator (Icarus 12) on core/page/LDPC vectors | | | X | | | | | E15: IV_SUMMARY |
| Vector generation (counts reproduce the shipped set) | | X | | | | | | E4: 38,554 / 6,037 / 6,073 / 600 core records, 60/60/60/20 page vectors, 1,646 LDPC records = shipped counts (content not diffed). |
| Integration with P53 FlashLink (stream adapter, spare-first read via SFB2 buffer) | | | | X | X | | | Never built or simulated; P53 data interface is SFB2, P54's is 8-bit streams. |
| Integration with P51 `sfs_nand_ctrl`, FTL policy (retry, scrub, relocate) | | | | X | | | | Specified in docs/00 §4, docs/03 §6, docs/08; "not executed". |
| Sufficiency for TLC/QLC NAND, endurance/UBER claims | | | | X | | | | Explicitly not claimed. |
| Cross-check dependencies: `galois`, Linux `lib/bch.c` (GPL-2.0-only), `pyldpc` (BSD-3) | | | | | | | X | Test/validation only; no RTL or `ref/` dependency (see section 8). |

## 3. What the engine is (item-5 questions)

**Codes.** Binary primitive narrow-sense BCH over GF(2^m), one codeword per sector, shortened. All parameters are elaboration-time (`silicaflux_storage_ecc` parameters; named sets in `rtl/generated/sfecc_cfg.svh`, generated by `scripts/gen_cfg.py` from `ref/sfecc_configs.py`):

| Config | Page (data+spare) | Sectors / page | Data B per codeword | GF / primitive poly | t (correctable bits / codeword) | n, k (bits) | Parity | Stored codeword (sector+meta+CRC+parity) | Spare use (per slot) | Parity overhead |
|---|---|---|---|---|---|---|---|---|---|---|
| `B255T4` (core only, no page format) | n/a | n/a | 28 B msg (1 leading pad bit) | GF(2^8) 0x11D | **4** | 255, 223 | 32 b = 4 B | 32 B | n/a | 12.5 % |
| `N512T4` | 512 + 16 | 1 | **512** | GF(2^13) 0x201B | **4** | **4212, 4160** (BCH(8191,8139) shortened by 3979) | 52 b -> 7 B (TPAD 4 ones) | 527 B | 1 RSVD/BBM + 6 user meta + 2 CRC-16 + 7 = 16/16 | 1.37 % |
| `N512T8` | 512 + 16 | 1 | **512** | GF(2^13) 0x201B | **8** | **4216, 4112** (BCH(8191,8087) shortened by 3975) | 104 b = 13 B | 527 B | 1 + 0 + 2 + 13 = 16/16 | 2.54 % |
| `N2KT8` | 2048 + 64 | 4 | **512** | GF(2^13) 0x201B | **8** | 4216, 4112 | 13 B | 527 B | 16 B/slot x 4 = 64/64 | 2.54 % |
| `N8KT40` (scaling study) | 8192 + 744 | 8 | **1024** | GF(2^14) 0x402B | **40** | 8928, 8368 | 560 b = 70 B | 1116 B | 1 + 20 meta + 2 + 70 = 93 B x 8 = 744/744 | 6.84 % |
| `L24` (LDPC demo) | 24 + 44 | 4 | 6 | QC-LDPC(128,64), Z=16 | no fixed t | 128, 64 | 8 B | 16 B | 1+0+2+8 = 11 B/slot | rate 1/2 |

Default parameters of the top module `silicaflux_storage_ecc` equal `N2KT8` (GF_M 13, T 8, R 104, MSG_BYTES 514, PAGE_DATA 2048, PAGE_SPARE 64, SECTOR 512, UMETA 0, CRC_EN 1, NBANKS 2, FLIP_THR 6).
OOB budget is enforced at elaboration (`SFECC_CFG_FATAL`) and in the Python `PageFormat`; examples that do not fit are rejected (t = 9 on 512+16).

**Page layout (split "ECC in OOB").** Data area untouched `sector0 | sector1 | ...`; spare area `slot0 | slot1 | ...` with `slot i = RSVD(1) | UMETA | CRC-16 | PARITY`, `SLOT_STRIDE = PAGE_SPARE / sectors`. Codeword i = `sector_i || UMETA_i || CRC_i || PARITY_i`.
RSVD of slot 0 = spare byte 0 = bad-block-marker byte: outside every codeword, always programmed 0xFF, reported as read (`rd_pst_bbm`). Erased pages are handled by a constant coset MASK (stored parity = p(u) xor MASK, MASK = p(1^k) xor 1^r), so an all-0xFF page is a valid codeword and
decodes `ERASED` even with <= t 1->0 flips. CRC-16/CCITT-FALSE (poly 1021h, init FFFFh) over sector||UMETA, inside the codeword, is the miscorrection check (`INTEGRITY_FAIL`).
**The read path expects the raw page spare-first**: PAGE_SPARE bytes, then PAGE_DATA bytes (`rd_raw_*`); the program path emits column order (data then spare).

**Decoder.** Three-stage pipeline per codeword, 8 bits/cycle: SYN (t odd syndromes, Horner) -> KES (simplified inversionless Berlekamp-Massey, 2 cycles/iteration, 2t+2 cycles) -> Chien (8 positions/cycle) merged with correction, store-and-forward with NBANKS codeword buffers (default 2).
Failure detection: roots in range == L. **Encoder:** unrolled 8-step LFSR, one byte/cycle, no bubbles.
Latency / throughput (from the project's PERF phases; the page-level numbers I reproduced, see E6): decoder first byte in -> first byte out 36 cycles (B255T4), **531 cycles (527 B codeword, N512T4/T8)**, 1120 (N8KT40); first byte in -> status 68 / **1058** / 2236 cycles; sustained 0.927-0.981 B/cycle per decoder; page engine decode 0.856 raw B/cycle (1-codeword 512+16 pages) / 0.928 (2048+64), encode 0.97 B/cycle.
At the project's post-route ECP5 estimate of 74-78 MHz that is about 72 MB/s (>> an ONFI SDR x8 bus <= 50 MB/s); NV-DDR rates would need several codecs per channel or 16/32-bit datapaths (not built).
Cycle latency to correct a 512 B sector: ~1058 cycles (~14 us at 74 MHz) after the last byte arrives, vs tR = 25 us in the twin.

**Correctable bits / codeword length / data per codeword (the numbers to wire to):** t = 4 or 8 per 512 B sector (n = 4212 / 4216 bits = 527 B stored), t = 40 per 1 KiB (n = 8928 bits = 1116 B), baseline t = 4 (255, 223).

**LDPC status: proof of concept only.** Single code QC-LDPC(128,64) (rate 1/2, Z = 16, base matrix 4x8, girth 6); layered offset-min-sum, 5-bit channel LLRs (soft via `in_llr`, or hard +-15), 8-bit posteriors, <= 20 iterations; one 16-byte word at a time (not pipelined), 1 word per `16+1+5*iter+9` cycles; **~9 MHz on ECP5** (the entire layer is one combinational cycle, 183 gate levels). The page engine feeds it **hard decisions only**; soft LLR input exists at codec level only and is fed by the codec testbench, not by NAND soft reads.
It is **not NAND-grade** (no 1-4 KiB codewords, no error-floor characterisation, no soft-read plumbing, no read-retry integration) and is **simulation/estimate-only** (no board, no silicon). BCH is the only production-intent path; the project's own text says BCH t<=8 is not claimed sufficient for TLC/QLC.

**Is the decoder genuinely synthesizable and correct?** Synthesizable: `scripts/lint.py` (Verilator -Wall) and Yosys `synth -flatten` + `check -assert` on the **full page engine** (E11: 0 problems, 0 latches inferred) and the per-block synth tops (E12). RTL uses no `initial`/delays/real; the only `$fatal` is the elaboration-time configuration check.
Correct: the golden Python reference is validated against three independent sources (published BCH table, `galois`, Linux `lib/bch.c`) (E3: 65/65) and the RTL is compared **bit-exactly** to it on every vector (E6-E8). Correctness is for the *tested error models*; BCH beyond t miscorrects a fraction of patterns (documented, measured 3-5 % for BCH(255,223); **every solid 10-bit burst on BCH(255,223) is miscorrected**), and the CRC-16 is the backstop (residual 2^-16).

**Register/port interface:** section 6.

## 4. Evidence log (what I ran)

`cwd = $SP/work/p54/silicaflux-ecccore`, `PY = $SP/venv_p54/bin/python`, `NUMBA_NUM_THREADS=1` (as the Makefile), each command under `timeout 480`. Several `make` targets (`regress`, `synth`, `coverage`) were run **piecewise** (same scripts / same commands as `run_regress.py` via a thin driver `tools/p54_driver.py` that imports the project's own `vl_build`/`run_sim` helpers) because the project quotes ~1.5 h / ~2 h for them.

| # | Command | Exit | Key output | Wall | Log (`$SP/audit_out/p54/`) |
|---|---|---|---|---|---|
| E1 | `python scripts/gen_cfg.py --check` (= part of `make gen`) | 0 | `generated files up to date` | 0.3 s | `01_gen_cfg_check.log` |
| E2 | `python scripts/check_vendor.py` (`make vendor-check`) | 0 | `14/14 vendored files verified unmodified` (P52 files, `ext/linux_bch`, `ext/pyldpc`) | 0.1 s | `02_check_vendor.log` |
| E3 | `python scripts/validate_ref.py` (`make check-ref`) | 0 | **`65/65 checks pass in 441.1 s`** (GF tables, BCH(255,k) published table, `galois` for B255T4/N512T4/N512T8/N8KT40, Linux `lib/bch.c` for 5 geometries, 3 key-equation solvers, exhaustive 1-/2-bit patterns, erased-codeword and CRC checks) | 7 m 22.7 s (cap was 8 min) | `03_check_ref.log` |
| E4 | `python scripts/gen_vectors.py <cfg>` for N512T4, N512T8, N8KT40, B255T4; `gen_vectors.py --page`; `gen_ldpc_vectors.py 700` (= `make vectors`) | 0 each | 6,037 / 6,073 / 600 / 38,554 core records; page vectors N512T4/N512T8/N2KT8 (60 pages each), N8KT40 (20), L24 (200); 1,646 LDPC records | 72 / 113 / 105 / 25 / 49 / 19 s | `10_vec_*.log` |
| E5 | `python scripts/validate_ldpc.py` (`make check-ldpc`) | 0 | `7/7 checks pass` (GF(2) rank 64, H c = 0, girth 6, float BP == pyldpc on 300 frames, 128/128 single errors, soft >= hard) | 153 s | `11_check_ldpc.log` |
| E6 | Verilator build + run of `tb_sfecc_page` per config (same command as `run_regress.py` step 6): N512T8, N512T4, N2KT8, N8KT40, L24 | 0 each | `pages=60 checks=91576 errors=0`; `60 / 92086 / 0`; `60 / 369562 / 0`; `20 / 843227 / 0`; `200 / 22251 / 0`; PERF: decode 0.856 raw B/cycle (512+16) and 0.928 (2048+64), encode 0.970 / 0.972 | 77 / 80 / 87 / 256 / 84 s | `12_vl_page_*.log` |
| E7 | Verilator build + run of `tb_sfecc_bch` (step 5): B255T4 NBANKS 2 bp 30 %, N512T4, N512T8, N8KT40 | 0 each | `records=38554 checks=2360800 errors=0`; `6037 / 6478401 / 0`; `6073 / 6478836 / 0`; `600 / 1611442 / 0`. TB lines: `PERF ... first-byte-in -> first-byte-out 36 / 531 / 531 / 1120 cycles, -> first status 68 / 1058 / 1058 / 2236 cycles, 0.927 / 0.981 / 0.981 / 0.956 stored bytes/cycle`; `RESET 12 mid-traffic resets, clean re-run`; `FRAME misplaced in_last flagged`; truth classification B255T4: correct 35,932, detected 2,445, **miscorrected 177**; N512T4/N512T8/N8KT40: **0 miscorrected** | 70 / 90 / 161 / 276 s | `13_vl_core_*.log` |
| E8 | Verilator `tb_sfecc_ldpc` (step 7) | 0 | `records=1646 checks=55964 errors=0` | 95 s | `14_vl_ldpc.log` |
| E9 | `python scripts/lint.py` (`make lint`) | 0 | 14 tops: `RTL warnings 0`, wrapper warnings 6 each | 41 s | `15_lint.log` |
| E10 | `python scripts/nand_twin_campaign.py directed` | 0 | N2KT8 and N512T4 `TB RESULT tb_sfecc_nand_twin phase=0 ... nand_protocol_errors=0 nand_timing_violations=0 errors=0 -> PASS`, `mismatches 0`; outcome counts equal the shipped report | 236 s | `21_twin_directed.log` |
| E10b | `... nand_twin_campaign.py retention --quick` (96-page run reduced to 32 pages / 128 codewords) | 0 | raw errors/codeword 0.22 -> 4.4 -> 8.6 -> 16.8 over 4 bakes; every step `mismatches 0`; <= t corrected, > t UNCORRECTABLE (detected), none undetected | 177 s | `21_twin_retention_quick.log` |
| E10c | `... nand_twin_campaign.py statistical --quick` (Python twin + reference decoder) | 0 | 12 rows (N512T4, N2KT8 at 0-6000 h), `undetected 0` in every row | 22 s | `21_twin_statistical_quick.log` |
| E11 | `yosys -l ... audit_out/p54/25_yosys_check.ys` = `read_verilog -sv -DSYNTHESIS ...; hierarchy -check -top syn_ecc_N2KT8; synth -flatten; check -assert; stat` (my own script; the project's `synth.py` does not run `check -assert`) | 0 | `Found and reported 0 problems`; 43,459 cells (memories mapped to FFs); no latches inferred; 13 benign warnings (dead-branch out-of-range selects at KES k=0, memories replaced by registers) | 4 m 59 s | `25_yosys_check_syn_ecc_N2KT8.log` |
| E12 | `python scripts/run_mutants.py Mx` for M1..M9 (each = Verilator build of a mutated copy of `rtl/` + the full vector set; the script writes `build/mutants/` and overwrites `reports/mutation.md` in my copy) | 0 each | **M1 KILLED (78,731 errors)** (shipped 78,731); **M2 KILLED (872)** (872); **M3 KILLED (20,098)** (20,191); **M4 KILLED (20,373)** (20,473); **M5 KILLED (1,512)** (1,498); **M6 KILLED (650)** (650); **M7 KILLED (87)** (87; first attempt returned `KILLED (does not compile)` because the Verilator build was interrupted — the script labels any build failure as a kill, so I discarded it and re-ran: `20_mutant_M7_attempt1_INCONCLUSIVE_no_sim_binary.log`); **M8 KILLED (7,305)** (7,276); **M9 SURVIVED** (as shipped, "equivalent mutant"). Error counts of M3/M4/M5/M8 differ by 0.4-1.1 % from the shipped report (not deterministic run to run); verdicts identical. | 41-129 s each | `20_mutant_M*.log` |
| E13 | **Namespace smoke test**: `verilator --lint-only` and `iverilog -g2012 -s silicaflux_storage_ecc -s silicaflux_nand_controller -s nand_flash_device` on P54 RTL + P53 RTL (+multichannel, +io_sdr) + P52 model together | 0 / 0 | no duplicate module / package / macro definitions | < 1 min | `26_integrated_namespace_smoke.log` |
| E14 | `python scripts/synth.py <tops> --jobs 1 [--no-pnr]` (generic Yosys + `synth_ecp5` + optional nextpnr) | SYNTH_EXIT | SYNTH_TEXT | | `22_*.log`, `22b_*.log`, `22c_*.log`, `23_*.log` |
| E15 | Icarus 12 subset: `tb_sfecc_bch` B255T4 first 3,000 records (`subset_vectors.py`), `tb_sfecc_page` N512T4, `tb_sfecc_ldpc` (all vectors) | IV_EXIT | IV_TEXT | | `24_iv_*.log` |

Not run: `make coverage` (8 instrumented builds), full Icarus runs (project: 10 / 26 / 49 / 28 min for B255T4 / N512T4 / N512T8 / N8KT40), the t=40 decoder place-and-route (project: aborted after ~100 min), full `make synth` (~2 h).

## 5. Doc claims not reproduced / not substantiated

**Reproduced exactly (same numbers as the shipped reports):** 65/65 reference-validation checks; 7/7 LDPC validation checks; all vector record counts; **every RTL-vs-reference check count** (core: 2,360,800 / 6,478,401 / 6,478,836 / 1,611,442; page: 92,086 / 91,576 / 369,562 / 843,227 / 22,251; LDPC 55,964) with 0 errors; the cycle-accurate PERF numbers (decoder 36 / 68, 531 / 1058, 1120 / 2236 cycles; 0.927 / 0.981 / 0.956 B/cycle; page engine 0.856 / 0.928 raw B/cycle decode, 0.970 / 0.972 encode); lint 0 RTL warnings on 14 tops; NAND-twin directed outcome totals; the 8/9 mutation result (M9 surviving as documented); synthesizability (0 problems) of the full engine; SHA-256 of the vendored P52 files.

**Partially reproduced / not reproduced:**
* **Icarus parity** — E15: IV_CLAIM
* **ECP5 area/Fmax table (docs/07)** — E14: SYNTH_CLAIM
* **Full-size NAND-twin campaigns** (96-page retention run, 256-page statistical run) — only `--quick` versions re-run; consistent with the shipped tables (0 mismatches, 0 undetected) but smaller samples.
* **Code coverage 93.6 % / 89.2 %** — not re-run.
* **t = 40 decoder "does not route"** and its 19.6 MHz pre-route estimate — not re-run (project: ~100 min).
* **M9 is an equivalent mutant** — I confirmed it survives the full vector set with NBANKS=3 and 80 % back-pressure; I did not prove equivalence (the argument is in `reports/mutation.md`).
* **Mutant error counts** for M3/M4/M5/M8 differ by 0.4-1.1 % from the shipped report (run-to-run variation), verdicts unchanged.

**Not substantiated by the project (by design, stated in its own limitations):** sufficiency for any real NAND (no device data; all error evidence comes from P52's illustrative `stress` physics with independent per-cell errors); SSD endurance/UBER; behaviour with correlated (bit-line / word-line) defects beyond the documented 10-bit-burst miscorrection on BCH(255,223); LDPC performance beyond the 128-bit PoC; timing closure at the clocks quoted for P53/P51 integration; integration with P51/P53 at all.

**Doc inconsistencies (minor):** README says "65 / 65" reference checks, `docs/06_VERIFICATION.md` diagram says "64 checks" (I got 65); `ref/sfecc_configs.py` docstring names the 1 KiB / t=40 config `N1KT40` while code, RTL macros and all reports call it `N8KT40`; README's `ext/` note says "GPL-2.0" for `lib/bch.c` — the SPDX tag is more precisely **GPL-2.0-only**; the README says the whole archive is "delivered as an archive; nothing was committed" while `scripts/package.sh` zips `ext/linux_bch` (GPL source) into the delivery.

## 6. Reusable interface reference

### 6.1 Top: `module silicaflux_storage_ecc` (`rtl/silicaflux_storage_ecc.sv`; compile order `rtl/files.f`; include dirs `rtl`, `rtl/generated`; `` `include "sfecc_defs.svh"``)

Parameters: `CODEC` (0 BCH, 1 LDPC), `GF_M`, `GF_PRIM`, `T`, `R` (parity bits = GF_M*T for these codes), `GPOLY [R:0]`, `MSG_BYTES` (sector+umeta+crc), `LPAD`, `MASK [R-1:0]`, `PAGE_DATA`, `PAGE_SPARE`, `SECTOR`, `UMETA`, `CRC_EN`, `NBANKS` (2..3), `FLIP_THR`.
Use a named set, e.g. `silicaflux_storage_ecc #(`SFECC_PAGE_N512T8) u_ecc (...)` (macro from `rtl/generated/sfecc_cfg.svh`), or copy the parameter list. One clock, async active-low reset. All data ports are AXI-Stream-like: transfer when `valid && ready`, `valid` never depends on `ready`.

| Port | Dir | Width | Meaning |
|---|---|---|---|
| `clk`, `rst_n` | in | 1 | clock; async assert, sync release upstream |
| `rb_sel`, `rb_we`, `rb_addr[7:0]`, `rb_wdata[31:0]` -> `rb_rdata[31:0]` | in/out | | register window (word index `rb_addr[7:2]`), single cycle; `rb_rdata` is declared `output reg` but driven combinationally (case on `rb_addr`), so it is valid in the same cycle as `rb_addr` |
| `wr_pay_valid/ready/data[7:0]/last` | in/out/in/in | | program path: payload bytes, PAGE_DATA per page, `last` on the page's last byte |
| `wr_um_valid/ready/data[7:0]` | in/out/in | | user metadata, UMETA bytes per sector, requested after that sector's payload (unused if UMETA = 0) |
| `wr_raw_valid/ready/data[7:0]/last` | out/in/out/out | | raw page in **column order** (PAGE_DATA + PAGE_SPARE bytes) to the NAND data-in path |
| `rd_raw_valid/ready/data[7:0]/last` | in/out/in/in | | raw page from NAND, **spare area first**, then data area; `last` on the page's last byte |
| `rd_pay_valid/ready/data[7:0]/last` | out/in/out/out | | corrected payload, page order |
| `rd_um_valid/ready/data[7:0]` | out/in/out | | corrected user metadata |
| `rd_sst_valid/ready`, `rd_sst_code[2:0]`, `rd_sst_nerr[7:0]`, `rd_sst_aux[7:0]`, `rd_sst_sector[7:0]`, `rd_sst_crc_ok` | | | one status word per codeword, **after** that sector's data; may arrive after the next sector's data has started |
| `rd_pst_valid/ready`, `rd_pst_n_corr/n_uncorr/n_integ/n_erased[7:0]`, `rd_pst_max_flips[7:0]`, `rd_pst_tot_flips[15:0]`, `rd_pst_all_erased`, `rd_pst_bbm[7:0]`, `rd_pst_ok`, `rd_pst_scrub`, `rd_pst_frame_err` | | | one page status word per page |
| `ev_corrected`, `ev_uncorr`, `ev_integrity`, `ev_scrub` | out | 1 | one-cycle RAS event pulses |
| `irq`, `enc_busy`, `dec_busy` | out | 1 | `irq` = (IRQ pending && enable); busy flags |

Status codes (`rtl/sfecc_defs.svh`): codec `CLEAN 0, CORRECTED 1, ERASED 2, UNCORR 3`; sector adds `INTEGRITY 4`. `nerr` = bits corrected (also for ERASED: flips corrected), 0 when uncorrectable. Failing sectors pass the raw word (or the word with the roots found applied) through — **check status before using data**.

Register window (`rb_addr[7:2]` word index; byte offsets): `0x00 ID = 0x53454343 "SECC"`; `0x04 VERSION = 0x00010000`; `0x08 CFG0 {[31:20] sectors/page, [19:16] codec, [15:8] t, [7:0] m}`; `0x0C CFG1 {[31:24] umeta B, [23:16] parity B, [15:0] sector B}`; `0x10 CFG2 {[31:16] spare B, [15:0] data B}`;
`0x14 CTRL {[0] W1 clear stats, [8] IRQ enable, [23:16] scrub flip threshold, reset (3t+3)/4}`; `0x18 STATUS {[0] enc busy, [1] dec busy, [2] enc framing error}`; `0x1C IRQ [0] pending (W1C: a sector was UNCORRECTABLE or INTEGRITY_FAIL)`;
`0x20 PAGES_ENC, 0x24 PAGES_DEC, 0x28 CW_DEC, 0x2C CW_CORRECTED, 0x30 BITS_CORRECTED, 0x34 CW_UNCORR, 0x38 CW_INTEGRITY, 0x3C CW_ERASED, 0x40 PAGES_SCRUB` (RO, 32-bit); `0x44 LAST_FAIL {page[20:0], code[2:0], sector[7:0]}`; `0x48 MAX_FLIPS`.

### 6.2 Codec-level modules (replaceable interface)
`sfecc_codec_enc #(CODEC, GF_M, GF_PRIM, T, R, GPOLY, MSG_BYTES, LPAD, MASK)`: `clk, rst_n, in_valid, in_ready, in_data[7:0], in_last, out_valid, out_ready, out_data[7:0], out_last, frame_err` (message bytes in; stored codeword = message || parity out).
`sfecc_codec_dec #(CODEC, GF_M, GF_PRIM, T, R, MSG_BYTES, LPAD, MASK, NBANKS, LLR_W=5, SOFT_EN)`: `clk, rst_n, in_valid, in_ready, in_data[7:0], in_last, in_llr[8*LLR_W-1:0], out_valid, out_ready, out_data[7:0], out_last, st_valid, st_ready, st_code[1:0], st_nerr[7:0], st_aux[7:0], st_frame_err, busy` (`in_llr` ignored by BCH; positive = '0' more likely). Direct BCH blocks: `sfecc_bch_enc`, `sfecc_bch_dec` (= `sfecc_bch_syn` + `sfecc_bch_kes` + `sfecc_bch_chien`), LDPC PoC `sfecc_ldpc_enc` / `sfecc_ldpc_dec #(LLR_W, SOFT_EN)`.

### 6.3 Python reference (`ref/`)
`sfecc_gf.py` (GF(2^m)), `sfecc_bch.py` (`BCHCode`, `BCHFormat.encode/decode`), `sfecc_page.py` (`PageFormat`, `crc16_ccitt_false`), `sfecc_ldpc.py`, `sfecc_configs.py` (`CORE_CONFIGS`, `PAGE_CONFIGS`, `core(name)`, `page(name)`).

## 7. Integration risks / incompatibilities

**Cross-project geometry matrix (what each project assumes):**

| | P52 default (`slc_tiny`) | P52 `slc_1gbit_class` | P53 FlashLink | P54 ECCCore |
|---|---|---|---|---|
| Data B / page | 512 | 2048 | discovered, <= 16384; verified 512 (HYP: 2048) | 512 (N512T4/T8), 2048 (N2KT8), 8192 (N8KT40) |
| Spare B / page | 16 | 64 | discovered, <= 2048; verified 16 | 16 / 16 / 64 / 744 (budget exactly full) |
| Pages/block, blocks/LUN | 16, 64 | 64, 1024 | <= 1024, <= 65536 | irrelevant to ECC (P54's own twin tests: 16 ppb, 8 blocks/LUN) |
| LUNs/target, CE/channel, channels | 2, 2, 2 | 1, 2, 4 | 1..8 LUN, 1..8 CE, NUM_CH <= 8 (verified 2 LUN, 1-2 CE, 2 ch x 1 CE) | P54 twin tests: 1 LUN, 1 CE, 1 ch |
| Data interface | pin level x8 SDR | same | SFB2 memory buffer | 8-bit ready/valid streams, spare-first read |
| ECC | ONFI param page "ECC bits = 4" | 4 | none | BCH t = 4 / 8 per 512 B, t = 40 per 1 KiB; 16-bit CRC; no metadata room at 512+16/t=8 |

Risks specific to wiring P54 between P53 (FlashLink) and P52 (NAND twin):

1. **No P53<->P54 co-simulation exists.** P54's NAND-twin tests drive the P52 model through P52's `nand_ctrl_bfm` (a task-based BFM, 1 target, **1 LUN**, tiny 8-block device, stress profile); P53's tests contain no ECC. P54's own integration plan (docs/00 §4, docs/03 §6) targets **P51's `sfs_nand_ctrl`** (per-word SECDED), not P53. The only evidence that the three can coexist is a name/elaboration smoke test I ran (E13: all three RTL sets + the P52 model compile together in Verilator and Icarus, no duplicate module/package/macro names).
2. **Interface mismatch (adapter needed):** P53 = SFB2 memory-mapped buffer + request/completion queues; P54 = 8-bit ready/valid streams (`wr_raw_*`, `rd_raw_*`) + sector/page status words + `rb_*` register window. A buffer<->stream DMA/adapter (and a completion-status merge: P53 `cpl_*` + P54 `rd_sst/rd_pst`) must be written; neither project provides one.
3. **Spare-first read order.** P54's decoder needs PAGE_SPARE bytes first, then PAGE_DATA bytes, to avoid a page buffer. P53's `OP_READ_PAGE` reads one `(col,len)` window per array read (always `30h` then `05h col E0h`). With P53 you either read the whole page to the SFB2 buffer and replay it spare-first (the buffer P54 wanted to avoid) or issue two reads (2 x tR = 50 us in the twin).
4. **Zero OOB slack.** Spare budget is exactly full in every shipped configuration (16/16, 64/64, 744/744). N512T8 and N2KT8 leave **0 user-metadata bytes**; N512T4 leaves 6. Anything the FTL wants in OOB (LBA tag, sequence number, block state) is impossible at t=8/512 B on 16-B spare without dropping to t=4 or shrinking the CRC.
5. **Bad-block marker.** P52 writes 00h to spare byte 0 of the first and last page of a factory-bad block; P54 reserves spare byte 0 of slot 0 (RSVD) outside every codeword and reports it in `rd_pst_bbm` — consistent. The other slots' RSVD bytes (spare bytes 16, 32, 48 on N2KT8) are programmed 0xFF and not checked.
6. **Geometry is compile-time in P54 and run-time in P53.** Nothing cross-checks them; add a bring-up check `P53 GEO0 == {P54 CFG2.spare, P54 CFG2.data}` and `sectors = data/512`.
7. **ONFI "ECC bits required = 4" (P52) is advertised per page, with no codeword size**; P54 chooses t=4 or t=8 per 512 B; the t=8 variants exceed the advertised requirement (fine) but the mapping is by convention only.
8. **Uncorrectable handling is not defined end to end.** P54 returns `UNCORRECTABLE`/`INTEGRITY_FAIL` and passes data through unchanged; the retry loop (P52 SET FEATURES A0h level -> P53 re-READ -> P54 re-decode) and the scrub/relocate policy exist nowhere. P54 `scrub` (max flips >= 3t/4) is only a hint bit.
9. **Error evidence is for the P52 `stress` profile only** (non-calibrated; independent per-cell errors; asymmetric 0->1 retention and 1->0 disturb). Real NAND errors are correlated (bit-line/word-line defects) — P54's own docs warn that the random-error miscorrection estimate is not a bound (solid 10-bit bursts on BCH(255,223) are always miscorrected). CRC-16 residual 2^-16 of miscorrections.
10. **Clock / throughput.** Full engine 74-78 MHz post-route (ECP5-85F-6, out of context, seed 1); P53 66/85 MHz (45F). The bare t=8 decoder is 81 MHz; **N8KT40 decoder (84 k gates, 56 k LUT4) never routed**, so t=40 is not an implementable data point on ECP5-85F. One decoder = ~0.98 B/cycle: adequate for SDR x8; not for NV-DDR.
11. **Status ordering:** `rd_sst_*` (per codeword) may arrive after the next sector's data has begun; integrators must treat data and status as two in-order channels and must not release a page to the host until `rd_pst` arrives.
12. **Name/ID hygiene:** modules `sfecc_*`, `silicaflux_storage_ecc`, macros `SFECC_*` and include guards `SFECC_DEFS_SVH`/`SFECC_CFG_SVH` do not collide with P52/P53 (E13) or with any other extracted project (scan of all `audit/*`). Register IDs differ: P54 `0x53454343` ("SECC"), P53 `0x53463533` ("SF53"). Both use `` `default_nettype none`` and restore `wire` at the end of each file; P54 files set `` `timescale 1ns/1ps`` (P53 RTL has none and inherits it).

## 8. Licensing notes

* **`ext/linux_bch/bch.c`, `bch.h` — GPL-2.0-only** (`bch.h` carries `SPDX-License-Identifier: GPL-2.0-only`; `bch.c` header "GNU General Public License version 2", no "or later"; Copyright (C) 2011 Parrot S.A., author Ivan Djelic; full `COPYING` shipped). Vendored byte-for-byte (SHA256SUMS verified, E2).
  * **Use: cross-check only.** `scripts/validate_ref.py::build_linux()` compiles it with `gcc -O2 -shared -fPIC` into `build/libbch_linux.so` and calls it through `ctypes` to compare parity bytes and error locations with the Python reference. I verified by grep that **no RTL file, no `ref/` file, no testbench and no vector generator includes, links or copies it**; the RTL and Python reference contain none of its identifiers (`prim_poly_tab` appears only in a comment). The decoders implement textbook BM + Chien (the Linux library uses BM + BTZ root finding, i.e. a different algorithm).
  * **What this means:** the RTL deliverable is not linked to GPL code and is not a derivative of it. Items to keep clean: (a) `scripts/package.sh` zips the **whole tree including `ext/linux_bch`** into the delivery archive, so the archive as built redistributes GPL-2.0 source — keep it in a separate, clearly licensed directory or drop it from deliverables; (b) the locally built `libbch_linux.so` is a GPL-2.0 binary — do not ship it; (c) `ref/sfecc_gf.py` uses the same default primitive polynomials as the Linux table (m = 5..15; these are mathematical constants, listed in textbooks) and the erased-page "ECC mask" idea follows Linux `nand_bch` (a method, no code) — worth an attribution note, not a licence problem.
* `ext/pyldpc` — BSD-3-Clause (Hicham Janati, 2019), vendored (SHA256SUMS verified), used only by `scripts/validate_ldpc.py` (test-only); retain the notice if redistributed.
* `third_party/silicaflux-nandlab` — Project 52 (own code), vendored unmodified (E2: 14/14 files match; hash-identical to P52). No licence file.
* Python test dependencies not bundled: galois (MIT), numba (BSD-2-Clause), numpy / scipy (BSD-3-Clause). Tools: Verilator, Icarus (GPL-2, tool only), Yosys / nextpnr (ISC).
* **P54 itself ships no LICENSE file** (headers: "Aureom.AI | SilicaFlux-STORE"); a licence for the P54 code must be chosen by the owner before any redistribution mix with the GPL archive.
