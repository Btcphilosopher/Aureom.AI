# Project 58 "PowerSafe" (power-loss protection / crash recovery) -- integration audit, including "p58" vs "p58 (1.1)"

Two archives were audited. To keep names short: **P58** = `silicaflux-powersafe-p58` (pristine `$SP/audit/p58_powersafe/silicaflux-powersafe`, work copy `$SP/work/p58`),
**P58b** = `silicaflux-powersafe-p58 (1.1)` (pristine `$SP/audit/p58b_powersafe_1_1/silicaflux-powersafe`, work copy `$SP/work/p58b`).
`SP=/tmp/claude-0/-home-user-Aureom-AI/c80a8d5d-1b1f-56e3-9758-b78cee890e29/scratchpad`. Raw logs: `$SP/audit_out/p58/` (both variants; prefix `p58_` / `p58b_`).
Tools: Verilator 5.020, Icarus 12, Yosys 0.33, gcc 13, `riscv64-unknown-elf-gcc` 13.2, Python 3.13.

**Environment caveat for every wall time:** the 4-core container was shared with a dozen unrelated jobs (load average 12 -> 33). Wall times are inflated 2-6x;
several commands hit the 8-minute time-box purely because of that (marked "DID NOT COMPLETE (contention)") and were re-run in smaller pieces (each piece is its own command with its own 8-minute budget).

---------------------------------------------------------------------------------------------------------------------

## 1. Summary verdict

* **The "1.1" archive is NOT a newer version, update or superset of P58. It is an independent second implementation of the same brief.** Evidence:
  (a) each archive's own `docs/00_AUDIT.md` records a different source branch (`claude/inspiring-albattani-uo15g5` vs `claude/great-cray-aqwcdz`) off the same commit `4173a23`;
  (b) of the 80 non-report files in P58 only **14** are byte-identical to P58b -- all of them inherited unchanged from P56 (`hal/sfs`, `fw/`, `bench`, `ftl_check.c`, `ftl_wear.c`, `refmodel.*`, `sfftl_hal.h`, Makefile); **no P58-authored file is shared**;
  (c) the FTL changes over P56 are 308 changed lines (P58) vs 333 (P58b) and 631 between the two -- i.e. essentially disjoint; the RTL top module, register map, firmware API, crash-injection framework, tests and docs numbering all differ (section 3).
* **They conflict if combined.** Same RTL module / package names with different contents (`silicaflux_storage_recovery`, `sfpr_crash_inj`, `sfpr_regs_pkg`), same C header guard and symbols (`sfps.h`, `sfps_init`, `sfps_t`), different register maps (ID `0x52504653` vs `0x53465052`), different FTL APIs (`sfftl_cfg_t.evt` vs `sfftl_set_hook()/sfftl_format_ex()`, `SFFTL_F_VERIFY_WRITE` vs `SFFTL_F_VERIFY_HOST_WRITE`), and **different on-flash formats** (P58 = schema 1 + commit extension; P58b = schema 2). Pick one tree; do not merge directories.
* **Both reproduce their headline claims in my runs** (details in section 4): P58: 15/15 campaigns, 4 569 checks, 3 418 system runs, 4 002 injected crashes recovered, 0 violations (exact match to README; run as 15 separate commands because the single `make test` did not fit the time-box under load), RTL testbench 17 tests x 8 runs PASS on Verilator+Icarus, P56 suite 27/27 with and without P58 flags, ASan/UBSan clean, 15/15 mutants run caught.
  P58b: crash suite 13 tests, 5 497 checks, 0 failed (3 352 crash runs all fired; 200 real controller *processes* killed and recovered from a persistent medium file), RTL+firmware co-simulation 4/4 PASS with 561 recovery boots, P56 suite 27/27 (4 932 checks) on the modified FTL, ASan/UBSan clean, upgrade test PASS; RTL unit testbench: 14 Icarus runs PASS (the 7 Verilator runs did not complete under load).
* **Which to reuse -- recommendation: P58b ("1.1") as the PowerSafe baseline**, with one backport.
  Why: (1) it is the only one wired to the real P51 command path (`sfs_cmd_t`/`sfs_cpl_t` ports, `quiesce_o` -> `sfs_cmd_ctrl.plp_quiesce`, `nand_inhibit_o`, `wp_force_o`) and its co-simulation instantiates the *unmodified* P51 `sfs_cmd_ctrl`; P58's controller has a private port list and its own docs state "P51 integration not done" (proposed MMIO address `0x4000B000`);
  (2) deeper, more realistic fault model (supply loss at any cycle of a timed NAND busy window, persistent medium shared across killed processes, 31 named crash points incl. crashes in recovery, volatile write cache with FLUSH dependency tracking, shutdown notification, persistent event log + GET_LOG 0x58);
  (3) ships a `MANIFEST.sha256` that verifies (206/206 OK) and its mutation results reproduce (RTL 16/16, firmware 10/10); (4) its FTL can mount P58's v1 DUAL-checkpoint media and upgrade P56-6-block media (my matrix, section 5.5).
  Costs / gaps of P58b: **schema 2 cannot be read by P56 or P58** (no downgrade); **journal pages are not mirrored** (a journal page damaged after write can lose an acknowledged TRIM -- documented; P58 mirrors them); its firmware has not run on the ControlCore RTL (host C linked to Verilated RTL); `fw-size` builds only.
  **Backport worth doing from P58:** `SFFTL_F_JOURNAL_MIRROR` (the one protection P58b lacks; P58 also has the optional DIAG policy that spends <= `PF_BUDGET` NAND ops on one diagnostics journal page after a warning, which P58b deliberately does not do). Choose **P58 instead** only if you need media that P56 firmware can still mount (P56-config, i.e. without DUAL_CKPT) or a small standalone controller with its own tag-tracker and no P51 types.
* **Neither provides real power-loss protection.** `PLP_PRESENT = 0` in both; the capacitor models are research with placeholder electrical values (both re-run: they print hold-up tables from assumed inputs); no hold-up energy is assumed anywhere for correctness. Durability = spare-record roll-forward + journal + checkpoints.
* **Not run on the ControlCore RTL:** neither PowerSafe firmware executes on the MCU-I CPU RTL; P58's `make fw` produces only a library / relocatable object (no ELF, no image), P58b's `make fw-size` links only the P56 *FTL self-test* image (rebuilt with the P58b FTL library: 42 224 B text, ELF32 RISC-V) and measures the PowerSafe layer as library objects; that image was not run.

---------------------------------------------------------------------------------------------------------------------

## 2. What each one is (durability protocol, contract, crash injection, PLP model)

| Topic | P58 | P58b ("1.1") |
|---|---|---|
| Durability protocol | FTL (P56 + P58): every data page programmed with a 16-B spare record `{FFh, type, LPN, 48-bit SEQ, CRC-32}`; TRIM = journal page programmed *before* unmap; commit-last checkpoints in a metadata ring; mount = newest loadable checkpoint + journal pass + roll-forward by SEQ. P58 adds **dual checkpoint** (previous checkpoint + all later metadata pages kept live, `SFFTL_F_DUAL_CKPT`), **journal mirror** (every journal page programmed twice), **write verify** (`SFFTL_F_VERIFY_WRITE`), persistent diagnostics (`J_PFAIL`, `J_RECOVERY`, in the commit extension). **Schema stays 1.** | Same base mechanism. Adds **A/B checkpoint retention** (always on; ring = 3*need+3 blocks), **schema 2** (event area of 8 header words + 8 events x 8 words appended to every checkpoint body; commit words `PREV_BODY`, `EVT_WORDS`), `SFFTL_F_VERIFY_HOST_WRITE`, damaged-metadata classification (a damaged page followed by a valid page in the same block = media damage, not a tear), recovery telemetry. **No journal mirror.** |
| Hardware contract | Controller `silicaflux_storage_recovery` + `sfpr_tag_tracker`: per-tag phase chain ACCEPTED -> BUFFERED -> PROGRAMMED -> VERIFIED -> MAPPED -> DURABLE; **ack gate**: SUCCESS of WRITE/TRIM/FLUSH released only at DURABLE (FLUSH also needs `VACKED == 0`), premature SUCCESS refused (`ERR.ACK_BEFORE_DURABLE`); error completions always released. | Controller with slot table: phases ACCEPTED, STARTED, BUFFERED, PROGRAMMED, VERIFIED, MAP_COMMITTED, DURABLE; completion gate holds premature SUCCESS (not delivered; RTL assertion in sim); FLUSH SUCCESS only when every write volatile-acknowledged *before the FLUSH was admitted* is durable (dependency mask); phases strictly increase. |
| "Ack only after ..." | **DURABLE**: all pages programmed with PASS (+ read-back if VERIFY_WRITE) and mapping committed; TRIM: journal page programmed; FLUSH: pending journal records on NAND and no volatile-acked write outstanding. Exception: early (volatile) ack of a non-FUA WRITE only while `CFG.WCE` (host enabled volatile cache) or `PLP_EFFECTIVE` (`PLP_PRESENT` & `PLP_QUAL` & `cap_ok` & not revoked). | Same rule; durable-class SUCCESS never before DURABLE; volatile SUCCESS only with WCE (or PLP) at admission, no FUA, BUFFERED reached, no power fault active. Firmware implements an 8-page volatile write cache (destage on eviction/FLUSH/idle/overlap). |
| Unacknowledged commands after a crash | each logical page old **or** new (atomic per page); multi-page commands not atomic; value stable once read | same |
| Power-fault policy (no PLP) | **STOP** (default): admission closed in the cycle the filtered fault registers, NAND op in flight finishes, **no new program/erase**, WP# asserted when NAND idle, outstanding tags swept once (DURABLE -> SUCCESS, rest `ABORT_PWR_LOSS`); optional **DIAG** (<= `PF_BUDGET` ops for one diagnostics journal page after `PF_ACK`); brown-out: remount (default) or resume in place. Records the finding "P51's drain+checkpoint sequence assumes energy that does not exist". | Admission closed, unstarted commands aborted by hardware, `nand_inhibit_o` refuses new program/erase, WP# forced once NAND idle, `sfftl_ps_warn()` stops FTL loops at page boundaries, **no drain/checkpoint/flush/destage**; brown-out: full recovery (default) or `FAST_RESUME` only if no NAND op was in flight; clean shutdown path (`shn_req_i`, SHUT_DONE). |
| Crash injection | `sfpr_crash_inj.sv` (RTL) + C `sfci` + Verilator co-sim: points PRE/IN/POST_PROGRAM, PRE_MAP, POST_MAP, PRE/IN_JOURNAL, PRE_COMPLETION, TRIM_PRE_UNMAP, GC_IN_COPY/POST_COPY/PRE_ERASE, IN_ERASE, WL_POST_COPY, CKPT_BODY/PRE_COMMIT/IN_COMMIT/POST_COMMIT, MOUNT_SCAN/MOUNT_CKPT, META_ERASE; actions CUT_NOW, CUT_NEXT_PROG (next program/erase *tears*), CPU_RESET, CUT_NEXT_OP; plus a NAND-op sweep (cut at each of N consecutive device operations; in-flight op torn: not-started / completed-unseen / almost-done / torn with/without spare, ECC pass/fail) and nested crashes during recovery (<= 3 deep). The firmware is abandoned with `longjmp` (RAM lost). Reference model `rrm.c` (acknowledged value, one command in doubt, atomic per page). | 31 named points (hook events + synthetic `before_completion`, `destage`, `flush_done`), k-th hit selected, replay with `sfps_tests --replay <geometry> <seed> <point> <k>`; back-ends: in-process, **forked process + file-backed `MAP_SHARED` medium killed with `_exit()` at the cut**, and **RTL co-sim** (supply loss at any cycle, tear inside the busy window, RTL event crashes, brown-outs, controller resets, shutdowns) with the real P51 `sfs_cmd_ctrl`; torn outcomes `during_program` / `_eccpass` (ECC "corrects" garbage; only CRC saves it) / `_almost`; `mount_at_op` = crash at each of the 236 NAND ops of a recovery mount. Reference model `sfref.c`. |
| PLP (capacitor energy) model | `plp_model/plp_model.py`: E_req = P_shutdown * t_flush / eta * margin, t_flush = detect + in-flight + ceil(dirty/parallel)*(tPROG+xfer) + journal + erases; E_avail = 1/2 C_eff (V_hold^2 - V_low^2); C_eff with tolerance, temperature derating, ageing (doubling per 10 C); V_low includes UVLO and ESR; corners -40..85 C, 0..10 y; two NAND timing sets. **All inputs are placeholders.** | `plp/plp_model.py`: closed-form hold-up through a buck (eta 0.85-0.92 curve), Monte-Carlo over capacitance tolerance, temperature, ageing, shutdown power 1.5-4 W, supervisor latency 20-80 us; three example banks (tantalum-polymer, Al-polymer, supercap) x SLC/TLC-class NAND x policies finish / drain / checkpoint. **All inputs are assumptions.** RTL qualification gate: `PLP_PRESENT=1` refuses to elaborate without a non-zero `PLP_QUALIFICATION_ID`. |
| P51 / ControlCore integration | not integrated (private ports, proposed MMIO `0x4000B000`); not run on the CPU RTL | `sfs_cmd_t`/`sfs_cpl_t` command-path ports, drives `sfs_cmd_ctrl` in co-sim; firmware main loop `sfps_fw` drives P51 FWQ/tag window/CPL_POST; not run on the CPU RTL |

### 2.1 Relation of the P58 FTL to P56's FTL (answer to the brief)
Both P58 and P58b are **forks of the P56 FTL with additive changes** (same file set, same HAL, same 16-B spare record, same geometry limits). Verified: P58's own `third_party/p56_baseline/SHA256SUMS.p56-ftl` lists 31 P56 files; 15 are still byte-identical in P58 and 16 are modified (`simnand.*`, `sfftl.h`, `sfftl_powersafe.h`, `sfftl_schema.h`, `ftl_alloc/bbm/gc/io/meta/mount/util.c`, `sfftl_internal.h`, `tests/harness.*`, `tests/test_main.c`) (E13). P58b ships the unmodified P56 library in `firmware/tools/p56_original/` (14/14 hashes OK; byte-identical to this audit's P56 `src/` and `include/`) and modifies 12 files (`simnand.*`, `sfftl.h`, `sfftl_schema.h`, `sfftl_internal.h`, `ftl_alloc/gc/io/map/meta/mount/util.c`), adds `ftl_event.c`, and leaves `ftl_bbm.c`, `ftl_check.c`, `ftl_wear.c`, `sfftl_powersafe.h` and the P56 tests untouched (diff -rq, E13). P58 changes 308 lines of `src/`+`include/`, P58b 333, the two differ by 631.

---------------------------------------------------------------------------------------------------------------------

## 3. Precise P58 vs P58 (1.1) comparison

| Dimension | P58 | P58b (1.1) |
|---|---|---|
| Files (excl. `reports/`) | 80 (114 incl. reports) | 144 (207 incl. reports) |
| Byte-identical files | 14 (all unchanged P56 files) | same 14 |
| Source branch / commit (own audit doc) | `claude/inspiring-albattani-uo15g5` @ `4173a23` | `claude/great-cray-aqwcdz` @ `4173a23` |
| Integrity manifest | none (only `third_party/p56_baseline/SHA256SUMS.p56-ftl`) | `MANIFEST.sha256`: 206/206 OK (E-manifest) |
| RTL files | `silicaflux_storage_recovery.sv` (698 l) + `sfpr_tag_tracker.sv` (359 l) + `sfpr_crash_inj.sv` (105 l) + generated `sfpr_regs_pkg.sv`/`.svh` | `silicaflux_storage_recovery.sv` (925 l, slot table inside) + `sfpr_crash_inj.sv` (149 l) + generated `sfpr_regs_pkg.sv` (196 l); no tag tracker file |
| Controller parameters | `NTAGS` 2..16 (8), `PLP_PRESENT`, `PF_FILTER` 2, `RESET_HOLD_CYCLES` 16 | `N_SLOTS` 2..32 (16), `HWQ_DEPTH` 4, `PLP_PRESENT`, `PLP_QUALIFICATION_ID`, `CRASH_INJ_EN` |
| Controller ports | `por_ni`, `rst_ni`, `pwr_fail_ni`, `cap_ok_i`, `host_rst_req_i`, `wdt_rst_req_i`, `sub_rst_no`, `rb_*`, private admission port `cmd_valid_i/cmd_kind_i[2:0]/cmd_fua_i -> cmd_accept_o/cmd_tag_o/cmd_reject_o`, phase port `ev_*`, completion `cq_valid_o/cq_tag_o/cq_status_o`, NAND `nand_busy_i/start_i/kind_i`, `nand_prog_ok_o/nand_read_ok_o/wp_no`, `host_status_o[5:0]`, `irq_o`, `crash_req_o/crash_action_o` | `por_n`, `rst_n`, `pwr_fail_ni`, `shn_req_i`, **P51 types** `cmd_in/cpl_out/cmd_out/cpl_in` (`sfs_cmd_t`/`sfs_cpl_t` with valid/ready), `rb_*`, `nand_busy_i`, `nand_inhibit_o`, `wp_force_o`, `quiesce_o`, `rdy_o/ro_o/fatal_o/pf_active_o/shst_o/irq_o`, `ci_crash_o/ci_pf_o/ci_warm_o` |
| FSM states | POR_INIT, RECOVERY, RUN, RUN_RO, PF_DRAIN, PF_SAFE, PF_RESTORE, RESET_DRAIN, RESET_HOLD, SHUTDOWN, FAILED | RESET, INIT, RECOVER, READY, READONLY, PF_QUIESCE, PF_SAFE, FAILED, SHUTDOWN, SHUT_DONE |
| Register page | ID `0x52504653`, VERSION `0x00580100`, CMD_SUBMIT 0x40, PHASE_EV 0x48, CPL_REQ 0x4C, COMMIT_SEQ 0x60..., 60 regs | ID `0x53465052`, VERSION `0x00580100`, CAPS 0x008, PHASE 0x028, RECOV_DONE 0x024, COMMIT_SEQ 0x044..., 60 regs; **different offsets throughout** |
| Firmware layer | `sfps.c` (359 l): `sfps_bus_t` MMIO/ctx, `sfps_boot/format/submit/write/read/trim/flush/isr/service/poll/resume/shutdown`, no write cache | `sfps.c` (333 l) + `sfps_fw.c` (142 l): `sfps_ctrl_t` callbacks, `sfps_exec`, 8-page volatile write cache, `sfps_fw_boot/poll`, GET_LOG 0x58 telemetry |
| FTL public API additions | `SFFTL_F_VERIFY_WRITE|DUAL_CKPT|JOURNAL_MIRROR`; `cfg.evt` hook (`SFFTL_EV_*` 1-21 = controller crash-point ids); `sfftl_diag_t`, `sfftl_diag()`, `sfftl_log_recovery()`, `sfftl_ps_set_diag()` | `SFFTL_F_VERIFY_HOST_WRITE`; `sfftl_hook_fn`/`sfftl_ev_t` event stream (PROG_BEGIN/END, MAP_COMMIT, UNMAP, ERASE_BEGIN/END, GC_VICTIM, CKPT_*, JOURNAL_*, MOUNT_*); `sfftl_format_ex/mount_ex`, `sfftl_opts_t`, `sfftl_set_hook`, `sfftl_event_add/get`, `sfftl_persist` |
| On-flash | schema 1, commit extension magic `0x58383550` "P58X" after `SFFTL_CK_W_END` (97 words), journal `J_PFAIL`=6 / `J_RECOVERY`=7, mirrored journal pages, ring 3*need+3 when DUAL | schema 2 (header `schema` u16 = 2, accepts 1 and 2), event area `'EVT1'` at end of checkpoint body, commit words `PREV_BODY`, `EVT_WORDS`, ring 3*need+3 |
| Persistent test medium | in-memory `simnand` (+`simnand_reseed`) | file-backed `MAP_SHARED` medium (`simnand_open_file`), power-loss callback, forced torn-outcome modes |
| Tests | `test_recovery.c` (1 204 l, 15 tests) + `tb_storage_recovery.sv` (1 028 l, 17 tests) | `test_powersafe.c` (807 l, 13 tests) + `cosim_main.cpp` (4 campaigns) + `tb_sfpr.sv` (1 102 l, 11 tests) + `rtl_regress.py` |
| Mutation checks | 23 planted (R1-R8, L1-L12, ...) | 16 RTL + 10 firmware/FTL |
| Docs | 00-10 + REGISTERS (`01_SPECIFICATION`, `04_PERSISTENT_METADATA`, `07_PLP_RESEARCH`) | 00-11 + REGISTERS (`01_ARCHITECTURE`, `04_FIRMWARE`, `05_PERSISTENT_METADATA`, `08_PLP_MODEL`) |
| Mount a P56-config medium | yes (flags off) | **no** (`EGEOM`: zone too small) unless formatted with the 6-block zone (`upgrade_v1`) |
| Mount the other's medium | P58-DUAL medium: **P58b mounts it** (v1 read); P58b medium: no | -- |

---------------------------------------------------------------------------------------------------------------------

## 4. Classification tables

Columns: Impl = implemented, not verified by me beyond build; **Ver** = VERIFIED by me (command + result in section 5); Part = partially verified; Miss = missing; Inc = incompatible; Sim = simulation-only; IP = external-IP dependent. One primary status per row.

### 4.1 P58 (original)

| Function / feature | Impl | Ver | Part | Miss | Inc | Sim | IP | Note |
|---|---|---|---|---|---|---|---|---|
| Recovery controller RTL (FSM, admission, tags, NAND gating, WP#, reset sequencing, retention) | | X | | | | | | RTL unit tb 17 tests x 6 Verilator + 2 Icarus runs PASS (E6); lint (E2); Yosys 15 723 cells, 0 latches (E9) |
| Acknowledgement gate (no SUCCESS before DURABLE) | | X | | | | | | tb scoreboard, `gate_defense` (72 runs, 71 premature SUCCESS refused), mutant R1 caught |
| Power-fault STOP / DIAG policy | | X | | | | | | `power_fault` 192 runs / 288 crashes PASS; mutants R2-R5 caught |
| Crash campaigns on firmware-level crash points x 3 actions | | X | | | | X | | `crash_points` 570 runs/570 crashes PASS |
| Cut at each of 1 200 NAND operations (torn in-flight op) | | X | | | | X | | `nand_op_sweep` 1 200/1 200 |
| Crashes inside recovery (nested <= 3) | | X | | | | X | | `repeated_recovery` 80 runs, 238 crashes |
| Random campaigns (6 geometries, GC/WL/ckpt, NAND faults) | | X | | | | X | | `random` 160 runs / 650 crashes |
| Full-device / GC / wear-levelling crash campaigns | | X | | | | X | | `full_device` 168, `gc_wl` 288 runs |
| Metadata damage tolerance (dual ckpt, journal mirror) | | X | | | | | | `metadata_corruption` 200 checks (P56 config fails 19/60 and 3/20 in the same test); my independent probe P58 0/300 vs P56 up to 166/300 (E12) |
| FTL hardening for refused NAND ops (5 hazards) | | X | | | | | | mutants L4, L5, L6, L9 caught; `aborted_trim` PASS |
| Persistent diagnostics (`J_PFAIL`, `J_RECOVERY`, commit extension) | | X | | | | | | `diagnostics` 12 cuts -> 12 records |
| P56 regression on the modified FTL | | X | | | | | | 27/27 with and without P58 flags (4 882 / 4 930 checks) |
| ASan + UBSan | | X | | | | | | 15 tests, 0 reports (quick) |
| Capacitor PLP model | | | | | | X | | runs; **placeholder inputs**; no hold-up hardware |
| Physical PLP / qualified hold-up | | | | X | | | | `PLP_PRESENT = 0` |
| Integration into P51 command path | | | | X | | | | docs/10: "P51 integration not done" |
| Firmware executing on ControlCore RTL / RV32 linked image | | | | X | | | | `make fw`: library + relocatable object only (36 981 B text, 0 data, 0 bss) |
| Write-back volatile cache implementation | | | | X | | | | WCE only permits early ack in the controller |
| Mutation check (R1-R8, L1-L12 ...) | | | X | | | | | 15 of 20 ids re-run: 15/15 caught (R6,R7,R8,L7,L10 not re-run) |
| Performance numbers (latency, recovery time) | | | X | | | X | | `make perf` reproduces shipped `PERF.md` (E15); numbers are modelled on illustrative NAND |

### 4.2 P58b (1.1)

| Function / feature | Impl | Ver | Part | Miss | Inc | Sim | IP | Note |
|---|---|---|---|---|---|---|---|---|
| Recovery controller RTL with P51 `sfs_cmd_t/cpl_t` ports | | X | | | | | | Icarus unit tb: 14 runs PASS (10 seeds N8, N4, N16, N32, PLP); Verilated in the co-sim (4/4 PASS); lint clean (E-b2); Yosys 33 068 cells, 0 latches (E-b9). The 7 Verilator unit-tb runs of `rtl_regress.py` DNC under load |
| Completion gate / FLUSH dependency masks | | X | | | | | | Icarus tb scoreboard + RTL mutants 'durable-class SUCCESS not gated', 'FLUSH ignores its dependencies', 'FUA dropped' detected (E-b11) |
| RTL + firmware + unmodified P51 `sfs_cmd_ctrl` co-simulation | | X | | | | X | | `make cosim` 4/4 PASS: 561 recovery boots, 0 NAND rule violations, 0 mismatches |
| Crash suite on 31 named points x 3 geometries | | X | | | | X | | `point_sweep` 3 367 checks / 3 352 runs, all fired |
| Cut at each of 236 NAND ops of a recovery mount | | X | | | | X | | `mount_sweep` 237 checks PASS |
| Real process death on persistent file medium (200 processes) | | X | | | | X | | `process_crash` 202 checks, 188 323 LBA checks |
| A/B checkpoint retention (fix of the P56 gap) | | X | | | | | | `fallback_after_wrap` 300 PASS; `metadata_corruption` 354; my probe 0/300 (E12) |
| Persistent event log / GET_LOG 0x58 telemetry | | X | | | | | | `event_log` PASS |
| Volatile write cache + FLUSH/FUA contract | | X | | | | X | | `wce_contract`, `no_plp_policy` PASS |
| Schema-1 upgrade, EGEOM refusal of P56 5-block medium | | X | | | | | | `upgrade_v1` PASS; my matrix (E14) |
| Journal-page damage tolerance | | | | X | | | | no mirroring; documented limit |
| P56 regression on modified FTL; ASan+UBSan | | X | | | | | | 27/27, 4 932 checks; 27 tests quick under sanitizers; crash suite quick under sanitizers 13/13 (1 011 checks), 0 reports |
| Capacitor PLP model + qualification gate | | | | | | X | | model re-run (placeholders); `PLP_PRESENT=1` without id rejected by lint |
| Physical PLP | | | | X | | | | |
| Firmware on ControlCore CPU RTL | | | | X | | | | `fw-size`: build only (E-b10) |
| Mutation check (16 RTL, 10 FTL/firmware) | | X | | | | | | 16/16 and 10/10 detected (E-b11); co-sim defence-in-depth mutation not re-run |

---------------------------------------------------------------------------------------------------------------------

## 5. Evidence log

(`rc` = exit status; times are wall times under heavy shared load; logs in `$SP/audit_out/p58/`.)

### 5.1 P58 (cwd `work/p58`)

| # | Command | rc | Key output | Wall |
|---|---|---|---|---|
| E1 | `make ftl-test` (`p58_make_ftl-test.log`) | 0 | `SUMMARY 27 tests, 0 failed, 4882 checks` (P56 suite, no P58 flags); `27 tests, 0 failed, 4930 checks` with `--p58` | 93 s |
| E2 | `make lint` | 0 | Verilator `-Wall` clean in 4 parameter sets x {simulation, synthesis} views (0 warnings), Icarus elaborates PLP 0/1 (11 notes), `gen_regs.py --check`: up to date | 2.4 s |
| E3 | `make cosim` (build) | 0 | Verilated `silicaflux_storage_recovery` + C firmware linked, `-Wall -Wextra -Werror` clean | 24.8 s |
| E4 | `make quick` | 0 | 15 tests, 0 failed, 1 333 checks (quick) | 89 s |
| E5 | `make test` (single command) | **124 DID NOT COMPLETE (contention; README says ~3 min idle)** | -- | 480 s |
| E5b | the same 15 campaigns, one command each: `./build/test_recovery --csv build/campaign_<t>.csv <t>` (`p58_full_<t>.log`) | all 0 | smoke 1; crash_points 1 141 checks / 570 runs / 570 crashes; nand_op_sweep 1 201 / 1 200 / 1 200; repeated_recovery 81 / 80 / 238; random 160 / 160 / 650; power_fault 193 / 192 / 288; metadata_corruption 200 / 400 / 0; ring_invariants 38; aborted_trim 12 / 12 / 12; full_device 337 / 168 / 168; gc_wl 578 / 288 / 288; gate_defense 147 / 72 / 72; cpu_reset 61 / 60 / 300; diagnostics 4; p56_config 415 / 216 / 216. **Sum: 15 tests, 0 failed, 4 569 checks, 3 418 system runs, 4 002 crashes injected and recovered** = README totals exactly | 0.2-152 s each (~11 min total) |
| E6 | `make tb` ; `make tb-iv` | 0 ; 0 | Verilator: 6 runs (PLP 0/1 x seeds 1-3) `TB RESULT PASS tests=17 checks=1934/2053/2112 and 1942/2061/2120 errors=0`; Icarus PLP 0/1: `PASS tests=17 checks=2054 / 2062 errors=0` | 227 s ; 12 s |
| E7 | `make sanitize` | 0 | `test_recovery_san --quick`: 15 tests, 0 failed, 1 333 checks; no ASan/UBSan report | 202 s |
| E8 | `make plp` | 0 | STOP: 0 mJ; DIAG (SLC) 23.2 mJ; PLP cache 16/64/256 dirty pages (SLC) 38/85/257 mJ; TLC-class 114/185/405/1 212 mJ; placeholder bank "INSUFFICIENT" where marked | 0.4 s |
| E9 | `make synth` | 0 | NTAGS=8 PLP=0: 15 723 cells, 3 904 FF, 0 latches; PLP=1: 15 724 / 3 908; NTAGS=16: 21 020 / 4 570 | 219 s |
| E10 | `make fw` | 0 | RV32IM `-Os`, `-Wall -Wextra -Werror`: totals text 36 981, data 0, bss 0 (`ftl_mount.o` 9 556, `sfps.o` 4 896); **builds a library and a relocatable object only -- no ELF/image** | 6.7 s |
| E11 | `python3 -B scripts/mutation.py R1 R2 R3`; `L1 L2 L3 L4`; `L5 L6 L8 L9`; `R4 R5 L11 L12` | 0 each | all 15 **caught** (R1 ack gate, R2 STOP, R3 admission, R4 sweep, R5 WP#, L1 TRIM journal, L2 dual ckpt, L3 mirror, L4 refused program, L5 aborted TRIM, L6 verify refusal, L8 SEQ order, L9 refusal as media error, L11 CRC on replay, L12 SEQ resume). Not re-run: R6, R7, R8, L7 (equivalent), L10 (redundant) | 371 + 131 + 129 + 375 s |
| E12 | **Auditor probe** `probe_f2.c` (damage newest checkpoint commit at a random point of its life; 300 seeds per row; copy in `audit_out/p56/probe_f2.c`; results `audit_out/p56/probe_f2_all.txt`) | 0 | P51-class geometry (512 B/16/64), 45 % TRIM, default checkpoint interval: **P56 166 unmountable (ENOFS), P58 0, P58b 0**; 60 % TRIM: 182 / 0 / 0; 512/8/64: 198 / 0 / 0; 512/16/128: 5 / 0 / 0; no data mismatch after any successful mount | ~3 min |
| E13 | Fork evidence: `sha256sum -c third_party/p56_baseline/SHA256SUMS.p56-ftl` in `work/p58/firmware/silicaflux_ftl`; `diff -rq` P56/P58/P58b; changed-line counts (`audit_out/p58/fork_evidence.txt`, `p58_vs_p58b_overlap.txt`, `diff_rq.txt`) | -- | 15 of 31 baseline files identical, 16 modified; P56->P58 308 lines, P56->P58b 333, P58->P58b 631; 14 of 80 files byte-identical between P58 and P58b | <1 s |
| E14 | **Auditor probe** `xmount.c` (`audit_out/p58/xmount_matrix.txt`): writer variant formats + 1 500 random write/TRIM ops (clean and unclean end) on a file-backed medium (512 B/16/64), reader variant mounts and compares every LBA; 3 writers x readers | 0 | P56 -> P56 / P58(no flags): OK, 0 mismatches; P56 -> P58(DUAL) / P58b: `EGEOM`. P58(DUAL) -> P58b: **OK, 0 mismatches** (clean and unclean); P58(DUAL) -> P56 / P58(no flags): `EGEOM`. P58b -> P58b: OK; P58b -> P56 / P58: `ENOFS`. | <1 min |
| E15 | `make perf` (`p58_make_perf.log`) | 0 | `perf: wrote reports/perf/PERF.md (PASS)`; regenerated `PERF.md` is byte-identical to the shipped file except the 'run time' line (8.8 s vs 8.0 s) -- deterministic; numbers are modelled on illustrative NAND times | 27 s |
| E-manifest | -- | -- | P58 has no manifest. | -- |

### 5.2 P58b (cwd `work/p58b`)

| # | Command | rc | Key output | Wall |
|---|---|---|---|---|
| E-b1 | SHA-256 of all 206 files vs `MANIFEST.sha256` | 0 | 206/206 OK (before any build) | <1 s |
| E-b2 | `make lint` | 0 | `verilator --lint-only -Wall` clean for default and `N_SLOTS=32 CRASH_INJ_EN=1` | 2.7 s |
| E-b3 | `make fw-test` (single command, `p58b_make_fw-test.log`) | **124 DID NOT COMPLETE (contention)** at the last step; before the cut: `upgrade_v1 PASS`, full `sfps_tests` **13 tests, 0 failed, 5 497 checks** (`point_sweep` 3 367 checks 165 s; `mount_sweep` 237; `random_campaign` 600; `faults_and_crashes` 200; `metadata_corruption` 354; `fallback_after_wrap` 300; `full_storage` 81; `gc_wl_interaction` 81; `wce_contract` 41; `no_plp_policy` 5; `event_log` 19; `process_crash` 202; `upgrade_v1` 10), sanitizer quick suite `13 tests, 0 failed, 1 011 checks`, 0 sanitizer reports | 480 s |
| E-b4 | `make build/sfftl_tests && ./build/sfftl_tests` and `... sfftl_tests_san --quick` in `firmware/silicaflux_ftl` (the cut-off tail of E-b3) | 0 ; 0 | P56 regression on the modified FTL: `27 tests, 0 failed, 4932 checks`; sanitizers (quick) `27 tests, 0 failed, 1846 checks` | 101 s ; 71 s |
| E-b5 | `make cosim` (`p58b_make_cosim.log`) | 0 | 4 campaigns `COSIM RESULT: PASS` (wce1 seed1 200 ep: 172 recovery boots; wce0 seed2 200 ep: 175; wce1 seed3 120 ep: 107; wce0 seed4 120 ep: 107 = **561 boots**), "NAND rule violations: 0", controller RECOVER state 2 107-15 582 cycles (hardware measured), 151 600 LBAs verified in the first campaign; e.g. campaign 1: supply losses 65, named firmware points 63 scheduled (**37 fired**), RTL event crashes 16 (11 fired), brown-outs 28, controller resets 21, clean shutdowns 7 | 427 s |
| E-b6 | `make rtl-test` (single command) | **124 DID NOT COMPLETE (contention)** -- only the first of five Verilator builds finished | 480 s |
| E-b7 | Icarus half of `scripts/rtl_regress.py`, replicated command by command (`p58b_iv_*.log`): `iverilog -P tb_sfpr.NS=<n> ...; vvp +SEED=<s> +ITER=<i>` | 0 each | N_SLOTS=8 seeds 1-10: `TB RESULT: 11 tests, 0 failed, 1 726-1 841 checks`; N_SLOTS=4 (1 270), 16 (1 211), 32 (1 309); PLP research build (12 checks, 1 test) -- **14 runs, all PASS** | 0.2-7 s each |
| E-b8 | `make plp` | 0 | model re-run; tables for 3 banks x SLC/TLC x finish/drain/checkpoint; e.g. bank B (4 x 220 uF Al-polymer) TLC-class drain: margin 0.67, P(success) 94.8 %; checkpoint 8.7 % | 0.5 s |
| E-b9 | `make synth` (`p58b_make_synth.log`) | 0 | production (N_SLOTS=16): **33 068 cells, 4 922 FF, 0 latches**; with crash injection 34 225 / 5 095; N_SLOTS=8: 20 815 / 3 312; N_SLOTS=32: 61 129 / 8 509 (README: ~33 k cells, ~4.9 k FF) | 338 s |
| E-b10 | `make fw-size` (`p58b_make_fw-size.log`) | 0 | RV32IM `-Os`: FTL 32 564 B + PowerSafe layer/main loop 9 394 B = **41 958 B text**, data/bss 0 for every object; RAM plan 23 152 B of 32 KiB DMEM; self-test image rebuilt with the P58b library `text 42224 data 8 bss 20224` | 11.5 s |
| E-b11 | `python3 scripts/mutation.py --rtl` ; `--fw` (`p58b_mut_rtl.log`, `p58b_mut_fw.log`) | 0 ; 0 | RTL (Icarus, `SYNTHESIS` defined so the RTL's own assertion is off, 2 seeds): baseline clean, **16 / 16 mutants detected** (ack gate, FUA, FLUSH deps, PF sweep, WP#, admission, NAND inhibit, ...); firmware/FTL: baseline clean, **10 / 10 detected** (A/B retention off, TRIM before journal, no CRC on replay, SEQ not resumed, FLUSH without destage, FUA to cache, ...). The `--cosim` defence-in-depth rows (gate removed -> acknowledged writes lost and detected) were **not** re-run by me; they appear in the shipped table the script re-emitted | 43 s ; 223 s |

---------------------------------------------------------------------------------------------------------------------

## 6. Doc claims NOT reproduced / not substantiated

| Claim | Status |
|---|---|
| P58: "`make test` runs the full campaigns (about 3 min)" | Single command DNC under load; the 15 campaigns re-run individually reproduce every number (E5b). |
| P58: "Mutation check: 23 planted defects, 20/21 caught, 2 equivalent, 1 redundant" | Only 15 of the 20 R/L ids re-run (all caught); equivalence/redundancy verdicts for L7/L10 not re-checked. |
| P58: "Performance: write completion p50 4.27 / p99 10.89 ms, recovery 11.7 / 13.7 / 22.8 ms" | Reproduced byte-for-byte (E15) -- but these are *modelled* on NANDLab's illustrative times, so they are not hardware performance. |
| P58: "RV32IM firmware 37.0 KB" | Reproduced as a *library* size. There is no linked firmware image; docs/10 admits it did not run on the ControlCore. |
| P58: "metadata_corruption ... P56: damaged journal page 14/80, double fault 83/240" | Same direction reproduced by the P58 test itself (P56 config 19/60 and 3/20) and by my independent probe (E12); the exact counts depend on workload/geometry. |
| P58 doc 04: "P58 media mount on P56 code and vice versa" | **Only for the P56 configuration.** With `SFFTL_F_DUAL_CKPT` (the P58 configuration) the metadata zone is 3*need+3 blocks and P56 refuses the medium with `EGEOM` (E14). |
| P58b: "640 episodes ... named firmware crash points fired by the RTL's crash-injection unit" | In the 4 co-simulation campaigns 37 of 63, 37 of 57, 22 of 42 and 20 of 37 scheduled named points actually fired (RTL event crashes: 11/16, 18/30, 11/16, 15/21); the remaining crashes in those episodes were supply losses / brown-outs / resets. All episodes passed. |
| P58b: "Recovery controller unit testbench 21/21 runs PASS (Verilator + Icarus)" | 14/21 reproduced (all Icarus runs); the 7 Verilator runs did not complete (builds too slow under load). |
| P58b: "mutation 16/16 RTL, 10/10 firmware" | **Reproduced** (E-b11). The co-simulation 'defence in depth' mutation (gate removed -> loss) was not re-run. "`make all` ~45 min": not run as one command. |
| P58b `fallback_after_wrap` comment "Project 56 without A/B retention: ~5 % unmountable" and audit text "16/300" | Not part of its own run (only the P58b result is printed). My probe (E12) found 5/300 on a 128-block device and 166/300 on the P51-class geometry: i.e. the severity depends strongly on geometry/checkpoint interval. Direction confirmed. |
| Both: "no hardware PLP is claimed" | Consistent and correct; the capacitor models are not evidence of any real hold-up. |
| Both: firmware verified | Firmware is host C (register accesses as RTL bus cycles); neither ran on the RV32 CPU RTL. |
| P58 README "Definition of done met in simulation" | Reproduced (E5b); simulation only. |

---------------------------------------------------------------------------------------------------------------------

## 7. Reusable interface reference

### 7.1 FTL (both): inherited from P56 (see p56_audit.md section 5): `sfftl_geom_t` (page_data pow2 512..16384, spare >= 16, ppb pow2 4..1024, blocks 16..65535), `sfftl_hal_t` (read/program/erase/read_marker/write_protect), 16-B spare record, SEQ 48-bit, status codes (`SFFTL_OK` 0 ... `SFFTL_ESTATE` -11).

### 7.2 P58 additions (`include/sfftl.h`, `sfftl_powersafe.h`, `sfftl_schema.h`; `SFFTL_VERSION 0x00580100`)

```c
#define SFFTL_F_VERIFY_WRITE   (1u<<5)  /* read back every host page before its mapping commit */
#define SFFTL_F_DUAL_CKPT      (1u<<6)  /* previous checkpoint stays live (FORMAT-time option: zone = 3*need+3 blocks) */
#define SFFTL_F_JOURNAL_MIRROR (1u<<7)  /* every journal page programmed twice */
typedef void (*sfftl_evt_fn)(void *ctx, uint32_t ev, uint32_t arg);       /* set sfftl_cfg_t.evt / .evt_ctx */
/* SFFTL_EV_*: PRE_PROGRAM 1, IN_PROGRAM 2, POST_PROGRAM 3, PRE_MAP 4, PRE_JOURNAL 5, IN_JOURNAL 6, GC_POST_COPY 8, GC_IN_COPY 9, GC_PRE_ERASE 10,
   IN_ERASE 11, CKPT_BODY 12, CKPT_PRE_COMMIT 13, CKPT_IN_COMMIT 14, CKPT_POST_COMMIT 15, MOUNT_SCAN 16, MOUNT_CKPT 17, TRIM_PRE_UNMAP 18,
   WL_POST_COPY 19, META_ERASE 20, POST_MAP 21  (= controller crash-point ids) */
typedef struct { uint32_t unclean_mounts, pfail_count, last_pfail_info, recov_count, last_recov_info; } sfftl_diag_t;
const sfftl_diag_t *sfftl_diag(const sfftl_t*);   int sfftl_log_recovery(sfftl_t*, uint32_t info);   void sfftl_ps_set_diag(sfftl_t*, uint32_t info);
/* stats additions: journal_mirror_pages, verify_write_reads, verify_write_fail, last_mount_kind (0 clean/1 unclean/2 rebuild),
   last_mount_ckpt_rejected, last_mount_programs, last_mount_erases */
```
On-flash (schema 1): commit page words after `SFFTL_CK_W_END`: `SFFTL_CK_X_MAGIC` = `0x58383550` ("P58X"), `PREV_FIRST` (first body PPN of previous checkpoint or ~0), `PREV_GEN`, `UNCLEAN`, `PF_COUNT`, `PF_INFO`, `RC_COUNT`, `RC_INFO` (97 words total, fits 512-B page = 124 words); journal record types `J_PFAIL`=6 (a = power-fault record no., b = firmware snapshot), `J_RECOVERY`=7; a P56 mount ignores the extension and the new record types.

Firmware layer (`firmware/powersafe/include/sfps.h`, `SFPS_VERSION 0x00580100`): `sfps_bus_t{rd,wr,irq,ctx}`; `sfps_cfg_t{forward_events,pf_mode,pf_budget,remount_on_restore,wce,recov_tmo,drain_tmo,ack_durable_on_pf,bug_ack_before_durable}`; `sfps_init`, `sfps_boot`, `sfps_format`, `sfps_submit(kind,fua,&status) -> tag`, `sfps_write/read/trim/flush(tag,...) -> status`, `sfps_isr`, `sfps_service`, `sfps_poll`, `sfps_resume`, `sfps_shutdown`, `sfps_background`, `sfps_telemetry`; completion status values `SFPS_ST_SUCCESS 0, DATA_XFER_ERR 4, ABORT_PWR_LOSS 5, INTERNAL_ERR 6, ABORT_RESET 7, LBA_RANGE 8, CAPACITY 9, MEDIA_UNREC 0x10, MEDIA_WRITE 0x11, WRITE_PROT 0x14` (P51 `sfs_status_e`).

Controller RTL (`rtl/silicaflux_storage_recovery.sv`): see section 3 (ports); register map `docs/REGISTERS.md` (ID `0x52504653`: STATE 0x010, CTRL 0x014, CFG 0x018, ERR 0x030, CMD_SUBMIT 0x040, CMD_RESULT 0x044, PHASE_EV 0x048, CPL_REQ 0x04C, CPL_RESULT 0x050, OUTSTANDING 0x054, TAG_INFO 0x05C, COMMIT_SEQ 0x060/064, CKPT_GEN 0x068, CP_EVENT 0x070, CI_* 0x080-0x08C, RET_* 0x0A0-0x0B8, telemetry `T_*` 0x100-0x158). Parameters `NTAGS`, `PLP_PRESENT`, `PF_FILTER`, `RESET_HOLD_CYCLES`. Phases `SFPR_PHASE_*` ACCEPTED..DURABLE; PF modes STOP / DIAG / PLP_FLUSH (degrades to STOP without PLP).

### 7.3 P58b additions (`include/sfftl.h`, `sfftl_schema.h`; `SFFTL_VERSION 0x00580100`)

```c
#define SFFTL_F_VERIFY_HOST_WRITE (1u<<5)
typedef struct { uint32_t kind, a, b, c; } sfftl_ev_t;  typedef void (*sfftl_hook_fn)(void *ctx, const sfftl_ev_t *ev);
/* kinds: PROG_BEGIN 1, PROG_END, MAP_COMMIT, UNMAP, ERASE_BEGIN, ERASE_END, GC_VICTIM, CKPT_BEGIN, CKPT_BODY, CKPT_COMMIT, CKPT_END,
   JOURNAL_BEGIN, JOURNAL_END, MOUNT_BEGIN, MOUNT_CKPT, MOUNT_REPLAY, MOUNT_END; page classes SFFTL_PGC_{HOST,RELOC,COLD,META_BODY,META_COMMIT,META_JOURNAL}; erase causes SFFTL_ERC_{OPEN,GC,META,FORMAT} */
typedef struct { sfftl_hook_fn hook; void *hook_ctx; uint32_t diag_valid, diag_type, diag[5]; } sfftl_opts_t;
int  sfftl_format_ex(sfftl_t*, const sfftl_geom_t*, const sfftl_cfg_t*, const sfftl_hal_t*, void *arena, size_t, const sfftl_opts_t*);
int  sfftl_mount_ex (same signature);   void sfftl_set_hook(sfftl_t*, sfftl_hook_fn, void*);
void sfftl_event_add(sfftl_t*, uint32_t type, const uint32_t data[5]);   int sfftl_event_get(const sfftl_t*, uint32_t i, sfftl_event_t*);   void sfftl_persist(const sfftl_t*, sfftl_persist_t*);
/* persistent event types: FORMAT 1, RECOVERY 2, POWER_FAULT 3, BROWNOUT 4, READONLY 5, UPGRADE 6, META_DAMAGE 7 */
```
On-flash (schema 2): metadata page header `schema` = 2 (mount reads 1 and 2); checkpoint body = L2P | block records | **event area** (`'EVT1'` 0x31545645; header words: magic, events total, unsafe shutdowns, recoveries, fallback mounts, meta damage, torn pages, pf events; then ring of 8 events x 8 words {type, SEQ, mount count, 5 data words}); commit adds `SFFTL_CK_W_PREV_BODY` and `SFFTL_CK_W_EVT_WORDS` after `SFFTL_CK_W_END`; ring = 3*need+3 blocks; journal types unchanged (1-5).
Firmware: `sfps_ctrl_t{ctx,phase,retire,inhibited}`, `sfps_init(p, ctrl, wc_buf, wc_pages)`, `sfps_attach`, `sfps_hook`, `sfps_exec(p, sfps_cmd_t{op,fua,slot,lba,nlb,buf}, sfps_cpl_t{status,err,vol})`, `sfps_flush_cache`, `sfps_idle`, `sfps_set_wce`, `sfps_power_fault`, `sfps_drop_cache`; platform `sfps_plat_t{ctx,rec_rd,rec_wr,cmd_rd,cmd_wr,dma_in,dma_out,alive}`; `sfps_fw_init/boot/poll`, `sfps_fw_telemetry(page512)` (GET_LOG 0x58, magic `'SFPT'`); P51 op codes FLUSH 0, WRITE 1, READ 2, DEALLOCATE 9, IDENTIFY 0x80, GET_LOG 0x81.
Controller (`N_SLOTS` 2..32, `HWQ_DEPTH`, `PLP_PRESENT`, `PLP_QUALIFICATION_ID`, `CRASH_INJ_EN`; ports in section 3). Registers ID `0x53465052`: CAPS 0x008, STATE 0x00C, CTRL 0x010, CFG 0x014, GATE_TIMEOUT 0x018, RECOV_TIMEOUT 0x01C, RECOV_DONE 0x024, PHASE 0x028, PHASE_RESULT 0x02C, RETIRE 0x030, ERR_STATUS 0x034, IRQ_* 0x03C/0x040, COMMIT_SEQ 0x044/048, counters 0x04C-0x074 ...; phases `SFPR_PH_{ACCEPTED 1, STARTED 2, BUFFERED 3, PROGRAMMED 4, VERIFIED 5, MAP_COMMITTED 6, DURABLE 7}`; states RESET 0, INIT 1, RECOVER 2, READY 3, READONLY 4, PF_QUIESCE 5, PF_SAFE 6, FAILED 7, SHUTDOWN 8, SHUT_DONE 9.

---------------------------------------------------------------------------------------------------------------------

## 8. Integration risks / incompatibilities

1. **Two incompatible implementations of one project.** Same names, different contents; only one may enter a tree (section 3). Within P58b vs P58 the media are not interchangeable in one direction (P58b media unreadable by P56/P58).
2. **P56 FTL weakness is real and severe on small geometries (E12)**: one damaged newest checkpoint-commit page leaves a P56-FTL volume unmountable in up to 55 % of probe seeds. Both P58 variants close it; do not integrate raw P56 persistence.
3. **P58b: acknowledged TRIM can be lost if a journal page is damaged on the media** (no mirror). P58: mirrored (2x journal programs, ~+3 % NAND programs at 6 % TRIM).
4. **Gate trusts the firmware's DURABLE report** (both docs). A firmware that lies defeats the gate; mutation tests show data loss is then found only by the reference model. The gate is defence in depth, not proof.
5. **No firmware execution on the ControlCore CPU RTL** for either variant; interrupt latency assumed (P58: 0-3 NAND ops or 64 clocks; P58b: co-sim compresses NAND times, 1 cycle = 1 us). Real hold-up/interrupt latency unmeasured; **no physical PLP**.
6. **P58 controller is not in the P51 command path** (private admission/phase/completion ports, proposed MMIO address). P58b's ports are P51-typed but have been integrated only in simulation, with the **unmodified** P51 `sfs_cmd_ctrl`; the P55 BufferCore and P53/P54 blocks are not involved.
7. **Interface to P55:** P55's `H2B completion` only means "committed in the volatile buffer"; P55's `early_ack_ok = WCE | PLP_PRESENT` has no qualification gate -- compose it with P58b's completion gate and `PLP_PRESENT=0` so that early acknowledgement can only be a host-enabled volatile cache.
8. **Geometry** inherited from P56: `page_data_bytes` pow2 512..16384, spare >= 16 (the 16-B record must be under the same ECC), ppb pow2 4..1024, blocks <= 65535, flat PBN, one synchronous channel, L2P in RAM (4 B/page). The metadata zone is 3*need+3 blocks in both (P56: 2*need+3) -- +1 block (1.9 % of a 64-block device; 0.4 % at 256 blocks).
9. **Crash-injection units are debug features** (RTL `CI_*`/`ci_*` outputs, `CRASH_INJ_EN`); tie off in production.
10. **Retention domains are flops**: `RET_*`/`STK_*` survive resets the controller sequences, not a real supply loss; durable diagnostics live only in the NAND event/journal records.
11. **Single command in firmware at a time**; N tags/slots tracked by hardware but NAND work serialised.
12. **Simulation only**: simulated NAND (`simnand`, NANDLab rules in C), Verilator/Icarus RTL; no FPGA/silicon/real NAND; NAND times illustrative.

---------------------------------------------------------------------------------------------------------------------

## 9. Licensing notes

* **No licence file, no SPDX/copyright headers** in either archive (verified by search); third-party provenance files (`PROVENANCE.md`) state "No licence file exists in the repository". P58 vendors only `sfv_common.sv` (SilicaFlux-V); P58b vendors a P51 StorageCore RTL subset + ControlCore runtime (19 files) and the unmodified P56 library (`firmware/tools/p56_original/`, with `SHA256SUMS`). All vendored content is byte-identical to files of other archives of the same repository (E-vendor: P58 1/1, P58b 19/19) and thus under the same undefined terms. Obtain an explicit licence before redistributing.
* Toolchains (not shipped): riscv64 gcc (GPL; `libgcc` runtime exception), Verilator (LGPL/Artistic), Icarus (GPL), Yosys (ISC).
