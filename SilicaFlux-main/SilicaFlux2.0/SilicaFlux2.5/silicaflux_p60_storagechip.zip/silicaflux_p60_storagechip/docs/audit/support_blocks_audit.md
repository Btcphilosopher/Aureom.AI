# Task B -- Audit of the supporting blocks for the new top-level

Audit date: 2026-11-12. Repository (read-only, untouched): `/home/user/Aureom.AI`. Work copies: `$SP/work/<block>`; pristine extracts: `$SP/audit/x_*`.
`SP=/tmp/claude-0/-home-user-Aureom-AI/c80a8d5d-1b1f-56e3-9758-b78cee890e29/scratchpad`. Raw logs: `$SP/audit_out/x_support/` (names quoted below are relative to that directory).

## 0. How to read this document

* **VERIFIED = I ran the command in this container and saw it pass.** A project's own recorded report (e.g. "231/231") that I did not re-run is a *claim*, listed separately.
* The container was shared with other sessions and ran at load average 16-33 on 4 cores for the whole audit. I held every command to an 8-minute time-box. Several long suites therefore did **not finish**; they are reported as **partial** with exactly what finished, not as passes. Where a result is a subset of a project's regression, the subset is named.
* I patched nothing in the projects. Where I called a project's own functions from a small driver script (kept in `$SP/scripts/`), the project code was unchanged and the driver only selected tests or raised a timeout; each is flagged.
* Evidence classes for the classification tables: **Implemented** (RTL/firmware/scripts exist), **Verified** (by me, command + result), **Partial** (I ran part), **Missing** (absent from the repository), **Incompatible** (conflicts with the target integration), **Sim-only** (no FPGA/silicon/PnR evidence), **Ext-IP** (needs IP/PDK/tool that is not in the repository).

## 1. Summary verdicts

| Block | Zip (under `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/` unless noted) | Verdict | My evidence |
|---|---|---|---|
| ControlCore P21 | `silicaflux-controlcore.zip` | **Usable.** RV32IM_Zicsr M-mode CPU, runs C firmware built with the installed riscv64-unknown-elf-gcc. Simulation-only. No authentication. | firmware clean-rebuild bit-identical; 6/6 system scenarios PASS; 19/19 cocotb PASS; riscv-tests 63/63 PASS (reduced matrix); lint PASS |
| DataFabric P03 | `silicaflux-datafabric.zip` (same bytes also at `SilicaFlux-main/`) | **Usable, performance-limited** (one outstanding transaction per port, no bursts, no IDs). | lint 25/25; 11 unit runs + 2 cocotb v1-compat + 2 SoC firmware runs PASS; formal `skid_buffer` proved; rest partial |
| SRAM library P01 | `silicaflux-sramlib.zip` | **Usable.** No ECC inside (ECC is P26). Real vendor macros are not bundled but are fetchable and the library matches their models. | mem-lint 47/47 PASS; GENERIC-vs-vendor-macro equivalence 11/11 PASS; 10/10 mutants killed; sim sweep partial |
| RAS P26 | `silicaflux-ras-project26.zip` | **Usable.** SECDED ECC SRAM wrapper, scrub, event controller, fault injection. | lint PASS; Icarus 18/19 tests PASS (details in 2.4); Verilator partial |
| TestCore (r1) | `silicaflux-testcore.zip` | **Usable, older lineage.** JTAG TAP + 35-cell BSR, MBIST, demo LBIST, scan-prep. No formal, no OpenROAD evidence. | full `scripts/regress.py` 16/16 PASS |
| TestCore r2 (P07) | `silicaflux-testcore-p07.zip` | **Preferred** (vendored by P39). TAP (no BSR), MBIST, test-mode controller, formal, sky130hd synthesis/STA/scan/placement. | 12 of 15 recorded steps re-run, all PASS (incl. sby formal, OpenROAD scan insertion, OpenSTA, OpenOCD bridge) |
| DFTGrid P39 | `silicaflux-dftgrid-p39.zip` | **Usable.** Lifecycle-gated test access + per-group MBIST sequencer; vendors P07. | static suite 5/5; sim subset 2/2; formal 2 of 3 unbounded proofs; synth + scan insertion + placement PASS |
| P40 floorplan build | `silicaflux-p40-floorplanbuild.zip` (repo root; byte-identical copy under 2.5) | **Incomplete archive; pipeline cannot run.** 46 files; the entire `physical/silicaflux/` tree (config, `sfpd` Python pipeline, OpenROAD Tcl, Nangate45 files, results) is absent. Only stand-in RTL, TB, tests and docs are present. | pytest: collection error `No module named 'sfpd'`; stand-in RTL sim PASS (186 checks); lint clean |
| ThermalLab P09 | `SilicaFlux ThermalLab (1).zip` (repo root; identical copy under 2.5) | **Inventory only** (per request): Python finite-volume thermal solver; all inputs are demonstration values. | not run |

## 2. Per-block audit

### 2.1 ControlCore (Project 21)

**Summary.** `silicaflux_control_core` = `mcu_cpu` (RV32I + M + Zicsr + Zifencei, machine mode only, little-endian, simple in-order core from MCU-I) + 8 KiB mask-ROM boot + 64 KiB IMEM + 32 KiB DMEM (byte parity) + SFB2 control crossbar + INTC (16 level sources, priority 0..7) + MTIMER + WDT + system DMA + host mailbox/console + PMU + RAS + perf counters + security status page. It boots, loads and CRC32-checks firmware, drives the real FP32 vector tile and INT8 tensor unit through register ABIs, and serves a host mailbox. **It is a CPU that runs C firmware**: `firmware/` is GNU C compiled for `-march=rv32im_zicsr_zifencei -mabi=ilp32 -ffreestanding -nostdlib` with its own `libc_min.c`, start-up assembly, linker script, trap handler (`firmware/common/*.S`, `fw.ld`) and a 14-group self-test.

**Toolchain assumption.** Ubuntu `gcc-riscv64-unknown-elf` 13.2 (rv32im/ilp32 multilib), python3-yaml; cocotb 1.9.2; verilator 5.020, iverilog 12, yosys 0.33, nextpnr-ecp5 + Project Trellis for the optional FPGA flow. `make isa` clones riscv-software-src/riscv-tests at run time. `apt-get install -y gcc-riscv64-unknown-elf` here: *already installed* (13.2.0-11ubuntu1+12, binutils 2.42); see section 4.

**Address map (v1.0 as shipped; byte addresses, little-endian, 32-bit register accesses only on register pages)**

| Region | Base | Size | Notes |
|---|---|---|---|
| BOOTROM | `0x0000_0000` | 8 KiB | reset vector `0x0`; read/execute only |
| IMEM | `0x0001_0000` | 64 KiB | firmware image; host- and DMA-loadable; parity |
| DMEM | `0x0002_0000` | 32 KiB | .data/.bss/stack; execute-never; parity |
| EXT | `0x2000_0000` | 512 MiB | SFB2 master window to the SoC (reference: DEVMEM 1 MiB at `0x2000_0000`, TILE_SPM 64 KiB at `0x3000_0000`); execute-never |
| PERIPH | `0x4000_0000` | 128 KiB | 32 x 4 KiB register pages: 0 SYSCTRL, 1 INTC, 2 MTIMER, 3 WDT, 4 DMA, 5 MAILBOX, 6 PERF, 7 PMU, 8 VECTOR, 9 TENSOR, 10-15 ACC (forwarded to accelerator port), 16 RAS, 17 SECURITY; 18-31 bus error |
| other | - | - | unmapped -> bus error, logged by RAS (`BUS_DECODE`) |

IRQ ids: 0 FATAL(7), 1 WDT(6), 2 RAS_WARN(5), 3 DMA(4), 4 TENSOR(3), 5 VECTOR(3), 6 HOST(2). CPU: MEI/MSI/MTI only. Source of truth: `config/cc_memmap.yaml` -> generated SV/C/Python/Markdown (`make memmap`). **P28 changes this**: ControlCore v2 (map v2.0, 32 KiB secure ROM) is a different integration target; pick one version per top level.

**Bus interfaces (from `silicaflux_control_core` ports)**

| Interface | Ports | Protocol |
|---|---|---|
| Host access port (slave) | `hs_req_valid/ready/write/addr[31:0]/wdata/wstrb[3:0]`, `hs_rsp_valid/ready/rdata/error`, `host_irq_o`, `host_ready_o`, `cmdproc_ready_o`, `ras_fatal_o` | SFB2 (DataFabric rev 2.0), one transaction at a time |
| External data port (master) | `ext_req_*` / `ext_rsp_*` (same signal set) | SFB2 master via `cc_sfb_gate`; to the storage fabric/DevMem |
| Accelerator register port | `acc_rb_sel/we/addr[15:0]/wdata/rdata/err` | SilicaFlux-V register bus (rb), 16 pages |
| Accelerator domain | `acc_clk_o`, `acc_rst_no`, `acc_{vec,tsu}_{irq,busy}_i`, `acc_tsu_halted_i` | gated clock + reset + status |
| SoC RAS in | `ext_warn_i`, `ext_fatal_i` | level inputs into `cc_ras` |
| Misc | `clk, rst_ni, test_mode, boot_mode_i[1:0], host_rst_req_i, diag_*, test_done/fail/code, cpu_sleep_o` | |

Parameters: `RV32M` (0 RV32I, 1 iterative M = default, 2 fast MUL), `SRAM_PARITY`, `SRAM_BACKEND`, `DMA_MAX_LEN_LOG2` (20), `MIMPID`.

**Classification**

| Item | Implemented | Verified (by me) | Partial | Missing | Incompatible | Sim-only | Ext-IP |
|---|---|---|---|---|---|---|---|
| RV32IM_Zicsr CPU, M-mode | yes | riscv-tests rv32ui+um+mi **63/63 PASS** (`PROFILES=100:1 SEEDS=1 scripts/run_riscv_tests.sh 1`, riscv-tests @ `3df703c`, 86 s; `controlcore_isa_reduced.log`) | project's matrix is 3 bus profiles x 2 seeds; I ran 1 x 1 | C, A, F, D, Zb*, PMP, S/U, MMU, HW misaligned access, debug module; no riscv-arch-test (no compliance claim) | `mul/div` take 35 cycles; 3 tests excluded by design (ma_data, pmpaddr, breakpoint) | yes | - |
| C firmware toolchain | yes | `rm -rf firmware/build; make fw` with riscv64-unknown-elf-gcc 13.2 -> firmware `.hex` and ROM image **sha256-identical to the shipped files** (`cc_fw_clean_rebuild.log`, `cc_fw_shipped.sha`, `cc_fw_rebuilt.sha`); `.elf` is ELF32 RISC-V; text 31 304 B (48 % of IMEM) | - | libc (project uses `libc_min.c`, freestanding) | - | - | - |
| System scenarios (ControlCore + real vector tile + tensor unit, firmware on RTL CPU) | yes | `make sim` Verilator build OK (407 s, `controlcore_sim.log`); `regress.py` matrix **6/6 PASS**: boot_host bp0 and bp40 (231 fw checks, 0 fails), boot_ext bp0 and bp25 (82 checks), bad_image (corrupted image rejected -> replaced -> cold boot), wdt_reset (38 checks) (`cc_scenario_results.txt`, `controlcore_regress.log`) | scenarios were re-run in two batches because my first 8-min batch was killed by load; each run completed on its own | - | - | yes | - |
| cocotb unit tests (7 new blocks, ControlCore alone with Python mocks) | yes | `make unit` (cocotb 1.9.2, Verilator): cc_ras 6, cc_mailbox 2, cc_sysctrl 3, cc_sfb_gate 3, cc_misc 4, `boot_without_accelerators` 1 = **19/19 PASS** (`controlcore_unit.log`, `controlcore_unit_mocks.log`; the last test needed a second 330 s run) | - | - | - | yes | - |
| Lint | yes | `make lint`: 0 warnings in new RTL, firmware+ROM `-Wall -Wextra` 0 warnings (`controlcore_lint.log`) | - | - | - | - | - |
| Address map validator | yes | `make check-map` 18/18 PASS; `make vendor` 160 files, 0 problems (`controlcore_checkmap.log`, `controlcore_vendor.log`) | - | - | - | - | - |
| FPGA (ULX3S LFE5U-85F) | yes (harness) | not run (needs `ecppack`, not installed; nextpnr-ecp5 smoke test only, section 4) | project: 27.4 MHz post-route, 18 791 cells (22 %), **never on a board**; full system ~99 k cells does not fit | - | - | yes | Lattice board |
| Authentication / secure boot | **no** (P28 adds) | - | - | firmware authentication, key storage, debug authentication ("`SECURITY.AUTH_HOOK` reserved") | - | - | - |
| Debug port | no | - | - | no RISC-V debug module, no JTAG in ControlCore (P28 vendors an `sfv_jtag`) | - | - | - |
| Memory protection | no | - | - | no PMP, M-mode only: no isolation between firmware parts | - | - | - |

**Integration risks.** (1) 64 KiB IMEM / 32 KiB DMEM and execute-only-from-ROM/IMEM: a storage FTL + NVMe + secure-store firmware set must fit or be split across ControlCore instances; EXT is execute-never. (2) No caches, 35-cycle mul/div, one outstanding host transaction, SFB2 one-outstanding on EXT: throughput-critical paths (CRC, XTS, ECC) must be hardware. (3) No PMP: a firmware bug in one module can corrupt key material in DMEM. (4) v1 vs P28 v2 memory map divergence (boot ROM 8 -> 32 KiB; `SECURITY` HW_VERSION 2.0 vs SYSCTRL 1.0). (5) A host access in flight during a ControlCore reset is lost. (6) Host write lock is coarse and set-only until system reset. (7) Mailbox handles one command at a time. (8) `make regress` rebuilds the simulator every time (phony `fw` dependency) - budget about 7 minutes under load. (9) Never run on silicon or a board; accelerator correctness relies on their own verification.

**Licensing.** All first-party RTL/firmware: no licence file in the repository ("internal Aureom.AI sources; owner must add a license before external distribution", `third_party/PROVENANCE.md`). Third party at run time: riscv-tests (BSD, cloned on demand). Nothing GPL bundled.

### 2.2 DataFabric (Project 03) - the on-chip protocol is **SFB2**

**Protocol.** SFB2 extends SilicaFlux-V's OBI-style SFB bus: request channel `req_valid/ready/write/addr[31:0]/wdata[DW]/wstrb[DW/8]`; response channel `rsp_valid/ready/rdata[DW]/error` (response back-pressure added); `DW` in {32, 64, 128}; little-endian; byte address `AW = 32`, DW-aligned (misaligned -> decode error); **exactly one response per request, in order; at most one outstanding transaction per crossbar master/slave port (rule R6); no native bursts (a burst = sequence of single beats); no transaction IDs; reset cancels in-flight transactions; write response only after the write has been performed**. Errors: unmapped address, access-matrix denial, misalignment, ROM write, poisoned access -> `rsp_error=1`, `rsp_rdata=0`. IDs/multiple outstanding are a documented roadmap item (PROTOCOL.md section 8).

**Reusable modules**

| Module | Parameters | Ports (summary) |
|---|---|---|
| `sfb_crossbar` | `NM, NS, AW=32, DW=32, ARB_MODE (0 fixed, 1 RR), CHECK_ALIGN, SLV_BASE, SLV_MASK, MST_SLV_EN` | `m_req_*`/`m_rsp_*` per master (flattened), `s_req_*`/`s_rsp_*` per slave, `err_evt/err_addr/err_master/err_write`, per-master `ev_req_accept/stall/arb_loss/rsp_stall` |
| `sfb_reg_slice`, `sfb_skid_buffer` | `REQ_SLICE, RSP_SLICE, DW` | protocol-transparent pipeline stages |
| `sfb_v1_slave_adapter` | - | legacy SFB slave behind SFB2 |
| `silicaflux_dma` | `DW, ENGINE (0 simple / 1 buffered), FIFO_DEPTH, BURST, DUAL_PORT, MAX_OUT, MAX_LEN_LOG2, PERF` | `rb_*` register-bus slave (12-bit addr), `irq`, `m_req_*`/`m_rsp_*` (1 or 2 ports), `busy, ev_done, bytes_done, fifo_level` |
| `sfb_sram_slave`, `sfb_sram_1r1w_slave` | - | SFB2 slave over the SRAM library |
| `sfv_soc_df` | `ARB_MODE, DMA_ENGINE, PERF, SRAM_IMPL` | SilicaFlux-V SoC + DataFabric; real CPU runs firmware |

**Classification**

| Item | Implemented | Verified (by me) | Partial | Missing | Incompatible | Sim-only | Ext-IP |
|---|---|---|---|---|---|---|---|
| Crossbar/arbiter/skid/slice/DMA RTL | yes | `scripts/datafabric/lint.py` **25/25 PASS** (Verilator -Wall, Yosys 0.33 elab+latch, memmap) after installing PyYAML (`datafabric_lint.log`; the first run 24/25 failed only because that venv lacked `yaml`) | - | - | - | yes | - |
| Unit/protocol regressions | yes | project's own `build_and_run()` on 4 of its 19 builds: DMA simple engine (3 seeds, bp 0-40), DMA buffered engine (3 seeds), reg-slice (3 seeds, 16.8 k transfers each), crossbar+SRAM `xsram_s2_l2_d64` (2 seeds, 20 k cycles, resets): **11/11 runs PASS, 0 protocol violations** (`df_c1_unit_subset.log`, driver `scripts/df_subset.py unit`) | 4 of 19 builds; `xbar_regress.py`, `xbar_mutants.py` not run | - | - | yes | - |
| SFB v1 compatibility (unmodified silicaflux-v crossbar cocotb test) | yes | cocotb 2.1 + Icarus: fixed-priority and round-robin **2/2 PASS** (`df_c2_cocotb_v1compat.log`) | - | - | - | yes | - |
| SoC with firmware on the real CPU | yes | `build default` (75 s) then `sfv_rom_post_selftest` **PASS** and `dma_demo_sram_boot` **PASS** (firmware line `SFV-DF RESULT PASS checks=177 fails=0`, 3.85 M cycles) (`df_c4_soc_subset.log`; clang/lld firmware rebuilt with `make -B -C firmware`, exit 0) | 2 of 18 SoC scenarios | - | SoC CPU is the SilicaFlux-V RV32I core, not ControlCore's mcu_cpu | yes | - |
| Formal | yes | `run_formal.py skid_buffer`: **BMC depth 30 PASS + unbounded ABC-PDR PROVED** (131 s; Yosys 0.33 + z3) (`df_c3b_formal_skid_buffer.log`) | `arbiter_rr_n3` did not finish in 8 min under load (no verdict); other jobs not run; project: DMA engines are *bounded only* (PDR budget exhausted) | - | - | - | - |
| Synthesis/GLS/benchmark/PPA | yes | not run | project's numbers are Yosys generic only | no PDK synthesis, STA, P&R, power | - | yes | PDK |
| Throughput | - | - | - | bursts, outstanding > 1, IDs, QoS | **crossbar: ~1 DMA word per 4 cycles (P51's measurement)**; NAND/NVMe/XTS-rate paths will be fabric-bound | - | - |

**Integration risks.** One-outstanding SFB2 caps bandwidth; 32-bit addresses; no end-to-end data protection (P26 adds parity link and ECC slave); DMA is single-channel; `silicaflux-datafabric-noc.zip` (P34) is a separate, unaudited NoC variant.

**Licensing.** First-party, no licence file. Vendors SilicaFlux-V and sramlib unmodified (`third_party/SHA256SUMS`).

### 2.3 SRAM Wrapper Library (Project 01)

**What it gives.** Technology-independent memory interfaces over three backends: `GENERIC` (behavioural, sim/formal, with fault injection and X-poisoning), `FPGA` (block-RAM inference), `ASIC` (real macros tiled to any width/depth, never falls back to flops). Modules: `sram_sp` (1RW), `sram_1r1w`, `sram_tdp` (2RW), `sram_bank_controller` (N masters x B banks, interleave, RR/fixed arbitration, ID-ordered responses), `sram_rsp_path`, `sram_mbist_march` + `sram_mbist_adapter` (TestCore-compatible), FPGA self-test top.

`sram_sp` ports: `clk, rst_n`; request `req_valid/ready/we/addr[AW]/wdata[DATA_WIDTH]/wmask[MASK_WIDTH]/id`; response `rsp_valid/ready/rdata/err/we/id` (in-order, `READ_LATENCY` cycles, credit-bounded FIFO); MBIST `tst_active/ce/we/addr/wdata -> tst_rdata` (raw array); `busy`. Parameters: `DATA_WIDTH, DEPTH, MASK_WIDTH, READ_LATENCY, BACKEND, MACRO, RSP_FIFO_DEPTH, WRITE_ACK, ID_WIDTH, TEST_EN, INIT_FILE`. `sram_bank_controller`: `NUM_MASTERS, NUM_BANKS, DATA_WIDTH, BANK_DEPTH, READ_LATENCY, ARB, INTERLEAVE, ADDR_MODE, ID_WIDTH, ...`.

**ECC?** **No** ECC or parity inside the library. ECC/poison/scrub is `sfras_ecc_sram` (P26) wrapped around the raw `sram_backend_1rw`; ControlCore adds byte parity itself.

**Macros (technology files)**: `manifests/` holds 34 macro manifests (SKY130 OpenRAM 1RW1R, GF180MCU 1RW, IHP SG13G2 1P/2P) + 3 *commercial placeholders that fail elaboration until licensed compiler output exists*. The macro views themselves (Verilog models, LEF) are **not bundled**; `scripts/mem/fetch_open_macros.sh` sparse-fetches them from public repos at pinned commits (liberty/GDS are listed but not fetched).

| Item | Implemented | Verified (by me) | Partial | Missing | Incompatible | Sim-only | Ext-IP |
|---|---|---|---|---|---|---|---|
| Interfaces, generic/FPGA backends | yes | `make mem-lint`: **47 PASS / 0 FAIL** incl. negative elaboration tests (394 s, `sramlib_lint.log`) | - | - | - | yes | - |
| Self-checking sim sweep | yes | `run_regress.py --suite sim --quick`: 8 of 17 configurations **PASS** before my time-box (sp DW 8/32/128, lat 1-3, GENERIC+FPGA backends, 1R1W STALL/READ_OLD) (`sram_c1_sim_quick.log`) | 8/17 of the *quick* matrix; full matrix not run | - | - | yes | - |
| ASIC backend vs real vendor macro models | yes | `git` sparse-fetch of efabless/sky130_sram_macros@ebfbf57, google GF180MCU SRAM@9c41192, IHP-Open-PDK@5e6d592 (6 s), then `--suite equiv`: **11/11 PASS** (sky130 1RW native/tiled/posted, 1R1W; gf180 bit-mask/tiled; ihp 1P tiled, 2P 2RW/1R1W; 4-bank controller) (`sram_c2_fetch_macros.log`, `sram_c3_equiv.log`) | - | - | - | yes | **real macros are external** (Apache-2.0 repos), no commercial macros |
| Testbench quality (mutation) | yes | `--suite mutants`: first run 8 killed + 2 "mutant did not build"; re-ran those two with the project's own table/helpers (`scripts/sram_mut2.py`): both **killed** -> **10/10 killed** (`sram_c4_mutants.log`, `sram_c5_mutants_rerun.log`). The two build failures had an empty log (transient, probably memory pressure) | - | - | - | - | - |
| Formal, synth, cocotb, integration, bench | yes | not run | project claims only | - | - | - | - |
| Commercial 130/65/28 nm macros | placeholders | - | - | licensed compiler outputs | - | - | **required** |

**Integration risks.** `sram_sp` read data has no ECC: storage buffers must use `sfras_ecc_sram` or be parity-checked externally; macro latency/timing for real macros is unknown (OpenRAM sky130 macro misses 50 MHz per P07 docs); generic backend is not a macro.

**Licensing.** Library: first-party, no licence. Fetched macro repos: Apache-2.0 (per project docs; I did not read their licence files, only fetched them into `work/sramlib/build/ext`, not redistributed).

### 2.4 RAS (Project 26)

**What it gives.** (a) `sfras_secded_enc/dec`: extended Hamming SECDED for any data width `K` (`R = clog2(K + clog2(K+1) + 1)`, `N = K+R+1`; inversion mask `INV` for erased-page-friendly all-ones codewords): `data_i[K] -> cw_o[N]`; decoder outputs `data_o, cw_corr_o, none_o, ce_o, ue_o, ue_inval_o, ce_data_o, err_idx_o, syn_o`. (b) `sfras_ecc_sram`: ECC SRAM wrapper over the sramlib `sram_sp` contract (`K, DEPTH, READ_LATENCY, BACKEND, MACRO, BYTE_EN (RMW), POISON_MODE, INIT_ON_RESET, TEST_EN, FI_EN, ...`) with ports `req_*/rsp_*` (+`rsp_ce, rsp_poison`), scrub port, init port, raw-N-bit MBIST port, RAS event port `ev_*`, fault-injection port. (c) `sfras_scrub`, `sfras_event_ctrl`, `sfras_watchdog`, `sfras_thermal_mon`, `sfras_timeout_mon`, `sfras_dma_mon`, `sfras_bus_parity` (parity link), `sfras_sfb_ecc_slave`, `sfras_sfb_fault_inj`, `sfras_fi_ctrl`. (d) `silicaflux_ras` top: register page (`rb_*`, 12-bit, `rb_priv`), `NEXT` external event ports, `NMEM` ECC-memory event/scrub/init/FI ports, `NBUS` bus fault injectors, thermal input, IRQ and `cc_warn_o/cc_fatal_o/contain_o`. (e) C driver `sw/silicaflux_ras.{h,c}` + generated register header.

| Item | Implemented | Verified (by me) | Partial | Missing | Incompatible | Sim-only | Ext-IP |
|---|---|---|---|---|---|---|---|
| SECDED codec | yes | Icarus: all 10 `secded_k{8,11,16,32,57,64,128}` kinds incl. `inv0`/`invd` **PASS** (vectors from the independent `model/gen_secded_vectors.py`); Verilator: same 10 **PASS** (`ras_icarus.log`, `ras_c5_*`, `$SP/work/ras/build/logs/*.log`) | - | - | - | yes | - |
| ECC SRAM wrapper | yes | Icarus `ecc_sram_{k64_bit, k64_sig, k64_none_lat2_pipe, k32_sig_np2, k32_word_only}` **PASS** | `ecc_sram_k128_bit_lat3` (Icarus) did not finish in my time-box; Verilator ecc_sram runs not completed | - | - | yes | - |
| Event controller, RAS system (`tb_ras_system`, prod lock-down) | yes | Icarus `event_ctrl`, `ras_system`, `ras_system_prod` **PASS**; Verilator `event_ctrl` **PASS** | Verilator `ras_system`/`ras_system_prod`, firmware co-simulation `sw_cosim`, mutation (22 mutants), synthesis (Yosys, 18 blocks) not completed by me | - | - | yes | - |
| Lint / reg-map | yes | `make regs`, `make lint` exit 0 (12 s) (`ras_regs.log`, `ras_lint.log`) | - | - | - | - | - |
| FIT/SER, timing, power | no | - | - | explicitly not claimed by the project | - | - | process data |
| Applied to other memories | partly | - | - | encode/decode hooks in MemoryCore, HPC scratchpad and ControlCore SRAMs are *specified, not applied* | - | - | - |

Evidence note: of the 22 Icarus/Verilator logs in `work/ras/build/logs/` the ones counted above are those whose log contains the project's `PASS` tag (`run_regress.py` rule); logs without it are listed as not finished, not failed.

**Integration risks.** SECDED only: >= 3-bit errors may miscorrect (project quantifies in docs/09); NAND-grade BCH/LDPC is P54; SFB2 segments outside parity links are a documented SPOF; fault injection must be locked in production (`fi_allow_i`).

**Licensing.** First-party, no licence; vendors sramlib and DataFabric DMA unmodified (`third_party/SHA256SUMS`).

### 2.5 TestCore - two different lineages ship in the repo

`silicaflux-testcore.zip` ("r1": `rtl/tc_*.sv`, `python/sftestcore`, `dft/`) and `silicaflux-testcore-p07.zip` ("r2": `rtl/testcore/sftc_*`, `python/testcore`, `asic/`, `formal/`, nested `.git`) are **not the same code** (`diff -rq` shows disjoint source trees). P39 DFTGrid vendors r2.

| | r1 (`silicaflux-testcore.zip`) | r2 (`silicaflux-testcore-p07.zip`) |
|---|---|---|
| TAP | IEEE-1149.1-**style**, IR 5 bits, 35-cell BSR, EXTEST/SAMPLE/CLAMP/HIGHZ, BSDL template; IDCODE `0x15F10001` (JEP106 **placeholder**) | IR 5 bits, IDCODE/BYPASS/TC regs; **no BSR** (EXTEST/SAMPLE reserved -> BYPASS), no BSDL; JEP106 placeholder |
| MBIST | March C-/MATS+ and others, registry, bank select, fail log, ROM MISR | word-oriented: March C-, MATS+, checkerboard, inverse, walking 1/0; per-bank fail log; ownership/quiesce/re-init (`sftc_mem_owner`); sramlib/SFB2 shims |
| Other | demo LBIST (max 85.46 % stuck-at in its own fault sim), scan-prep (test-enable/clock/reset/isolation/ICG TE/pin mux), debug halt/resume/GPR/trace, ATPG collateral (unvalidated Tessent/TestMAX scripts) | test-mode controller (lifecycle/unlock: **password interlock only**), JTAG<->system CDC register bridge, OpenOCD remote_bitbang bridge, boot-time MBIST C driver, SymbiYosys formal (6 harnesses), Yosys+OpenSTA, OpenROAD scan insertion + placement, in-house ATPG experiment |
| Interfaces | `tc_top` | `sftc_testcore_top` (`BANK_COUNT, MAX_W, MAX_DEPTH, BANK_WIDTHS/DEPTHS/FLAGS, ALG_MASK, LOG_DEPTH, CNT_W, TIMEOUT, PIPE_REQ/RSP`; ports: JTAG `tck/trst_n/tms/tdi/tdo/tdo_oe`, `clk/rst_n`, `hw_dbg_en/hw_test_en/cpu_halted/scan_mode_pin/scan_en_pin`, system reg port `s_req/we/addr[11:0]/wdata/gnt/rdata/err`, bank buses `b_req/we/addr/wdata/gnt/rvalid/rdata/rerr`, ownership coupling, `mode/scan_mode/scan_en/irq/test_done_o/test_pass_o`) |
| Not provided (both) | no IEEE 1149.1 compliance claim, no ATPG coverage, no silicon/FPGA, no memory repair; security = password/unlock only | same, plus no BSR |

**Classification (r1)**

| Item | Implemented | Verified (by me) | Partial | Missing | Incompatible | Sim-only | Ext-IP |
|---|---|---|---|---|---|---|---|
| Full regression | yes | `python3 scripts/regress.py` (copy, venv with pytest): **16/16 PASS** (404 s): spec check, traceability (60 req), Verilator -Wall 0 warnings, Yosys synth `tc_top` 13 670 cells / 2 723 flops / 1 latch (ICG), `tb_tap_fsm` 14 924 checks, `tb_tap_bsr` 27, `tb_mbist` 207, `tb_rst_clk` 52, `tb_mode_sec` 165, `tb_dft_iso` 31, `tb_debug` 165, **pytest 40 passed** (RTL vector replay), scan-readiness screen, LBIST eval (plateau 85.46 %), ATPG-collateral generation, SCAN_TEST entry replay on RTL (107 TCK cycles, 0 mismatches) (`tc_main_regress.log`, `work/testcore/docs/generated/regression_results.md`) | - | the project's 17th row (RV32I scan screen) needs a sibling `RISC-V CPU.zip`; not present in my copy layout | LBIST/ATPG are demonstration; ATPG scripts for commercial tools unvalidated | yes | Tessent/TestMAX/Modus for production |
| Formal / OpenROAD / sky130 | no | - | - | none in r1 | - | - | - |

**Classification (r2 / P07)**

| Item | Implemented | Verified (by me) | Partial | Missing | Incompatible | Sim-only | Ext-IP |
|---|---|---|---|---|---|---|---|
| Regression subset (12 of the project's 15 recorded steps) | yes | `scripts/regress.py --only ...` with the Nix tools (`source scripts/env.sh`): unit tests, Verilator lint, Yosys elab/latch, JTAG TAP+CDC sim, DataFabric-path sim, **formal 6/6 harnesses PASS** (fv_mbist, fv_sramlib_wrap, fv_mode_ctrl, fv_regs, fv_tap, fv_bridge; all reach points REACHED; sby 0.70), **synthesis sky130hd** (variants A0 8 368 um^2 ... E 50 853 um^2, 0 latches), **OpenROAD scan insertion** (7 chains: 6 x 176 flops on `clk` rising + 1 x 7 on `tck` falling; `SCAN_CHAIN_RESULT PASS errors=0`), **OpenSTA per test mode** (hold -0.13 ns in scan modes with ideal clocks: documented), **placement experiment** (45 % util.), SilicaFlux-V `sfv_sram_slave` integration sim PASS (132 s), **OpenOCD remote_bitbang bridge + SVF playback PASS** (59 s) (`tc07_quick.log`, `tc07_c2_sfv_openocd.log`) | not re-run by me: MBIST fault-injection campaign (187 s in project's run), host-library system sim (97 s), ATPG experiment (145 s) | no BSR/BSDL, no LBIST | JEP106 ID placeholder; no OTP/lifecycle; unlock = password interlock | yes | sky130hd views (Apache-2.0) bundled in `third_party/pdk`; production scan/ATPG needs commercial tools; macro BIST timing needs foundry/macro models |

**Integration risks.** TestCore must be wired into the SoC top by hand (`docs/testcore/sram_integration.md` section 2; the project did not edit sources). No scan chains exist in the SoC RTL yet (chip-level scan is planning only). Negative hold in scan modes with ideal clocks needs repair after CTS. MBIST sees raw N-bit words, so ECC/parity columns must be exposed through collars (P39 does this).

**Licensing.** First-party, no licence. sky130hd views: Apache-2.0 (`third_party/pdk/NOTICE.md`, hashes in `SHA256SUMS`); `scripts/fetch_pdk.sh` re-fetches from OpenROAD test data.

### 2.6 DFTGrid (Project 39)

**What it gives.** `silicaflux_test_access` (params `NG` groups <= 7, `MAXNB, MAXSW, MAXRAW, G_NB/G_SW/G_DEPTH/G_BW/G_BD/G_LAT/G_INIT/G_KIND, ALG_MASK, ENG_TIMEOUT, OWN_TIMEOUT, SCAN_CHAINS`): JTAG TAP (r2), lifecycle policy fed by P28 (`lc_valid, lc_state[3:0], sb_debug_en, sb_test_mode_en, otp_ift_en`), per-group collar + sequencer for MBIST (quiesce/ack/block handshakes, raw `tst_*` bus per group), scan-mode/clock/reset test controls for the P35 clock tree, RAS P26 event port, system register port (`s_req/we/priv/addr/wdata -> gnt/rdata/err`). Lifecycle: DEV open; PROV/PROD/RECOVERY closed except firmware MBIST when fuse `otp_ift_en` = 1; no authenticated unlock/RMA.

| Item | Implemented | Verified (by me) | Partial | Missing | Incompatible | Sim-only | Ext-IP |
|---|---|---|---|---|---|---|---|
| Static suite | yes | `regress.py --only tools,hashes,regmap,lint,illegal`: **5/5 PASS** - vendored-source hashes (README: 404 files), reg-map up to date, Verilator -Wall (synth + sim view), Icarus, Yosys 0.33 **and** 0.70 elaboration, **10/10 illegal parameter sets refused** (48 s) (`dftgrid_static.log`) | - | - | - | - | - |
| System simulation | yes | `build/tb_ta_sys.vvp` built; tests `lc_policy` and `secure_debug`: `TB_TA_SYS SUMMARY tests=1 failed=0` each (`dft_c4_sim_subset.log`) | `algorithms` did not finish within 8 min; 11 of 14 tests, the Verilator pass, cross-simulation, coverage, mutation (26 mutants), codecov not run | - | - | yes | - |
| Formal (SymbiYosys 0.70, ABC PDR) | yes | `fv_collar` **PASS** (2.1 s, 4/4 reach points REACHED), `fv_collar_self` **PASS** (2.0 s, 4/4) (`dft_c1_formal_unbounded.log`) | **`fv_seq`: ABC-PDR had not converged after 8 minutes (frame ~160)**, whereas the project records PASS in 18.8 s; unresolved discrepancy (CPU starvation does not obviously explain a >20x gap). `fv_ta_bmc` (whole-block bounded check) not run | - | - | - | - |
| Synthesis (Yosys 0.70 -> sky130hd + OpenSTA) | yes | `regress.py --only synth`: PASS, **13 291 cells, 146 309 um^2** (matches the project's number exactly), its pre-placement OpenSTA report shows worst max slack -2.421 ns / TNS -818 ns (identical to the shipped `reports/synth/sta.rpt`, i.e. reproducible; unbuffered netlist, so *not* timing-clean at this stage; the README's +1.5 ns figures are post-placement) (`dft_c2_synth.log`) | - | - | - | yes | sky130hd (bundled) |
| Scan insertion + chain continuity | yes | `--only scan`: **17 chains, `SCAN_CHAIN_RESULT PASS errors=0`** (OpenROAD 26Q3 + gate-level sim) (`dft_c3_scan_place.log`) | chip-level scan is planning only | no ATPG, no coverage number | - | yes | - |
| Placement experiment | yes | `--only place`: PASS (`SFTA_PLACE_DONE`, setup/hold groups reported) | estimated parasitics, no CTS/route | - | - | yes | - |

Caveat: `regress.py` and `gen_docs.py` merge previously recorded results into `reports/regression.json`/README, so the "15/15 sim PASS / 26/26 mutants" text that appears in my copy is the **project's** record; only the lines in my logs count as mine.

**Integration risks.** Depends on P28's lifecycle signals and P07 r2; group parameterisation (`G_SW` = stored-word width incl. ECC columns) must match each memory. Production parts cannot be re-opened (no RMA). `fv_seq` discrepancy above.

**Licensing.** First-party, no licence; vendors P07/P33/P35/P31/P26/sramlib unmodified (`third_party/SHA256SUMS`, 404 files); sky130hd NOTICE (Apache-2.0).

### 2.7 P40 FLOORPLANBUILD (`silicaflux-p40-floorplanbuild.zip`)

**Finding: the archive is incomplete.** The Makefile and README drive `physical/silicaflux/{config,scripts/sfpd,scripts/tcl,tech/nangate45,constraints,results,reports,plots}`; **none of that exists in the zip** (66 KB, 46 files: `rtl/` 29 files, `tb/` 1, `tests/` 10, `docs/` 4, CI workflow, Makefile, README, requirements). Consequences:

| Item | Implemented | Verified (by me) | Partial | Missing | Incompatible | Sim-only | Ext-IP |
|---|---|---|---|---|---|---|---|
| Stand-in DieTop RTL + wrapper + tb | yes (11 stand-in modules, wrapper, behavioural and Nangate45-bound SRAM/ICG bindings, sim models) | Icarus: behavioural **and** tech-bound (fakeram45 / CLKGATETST_X1 sim models) both `TB_RESULT PASS checks=186` (matches README MIN claim); Verilator `-Wall` + project waivers (absolute paths so globs match): **0 warnings** (`p40_rtl_behavioural.log`) | - | - | - | yes | - |
| pytest (65 tests) | yes | `pytest tests/physical`: **ImportError - `No module named 'sfpd'`** (`conftest.py` imports it) (`p40_pytest.log`) | - | the `sfpd` package | - | - | - |
| Floorplan/PDN/place/CTS/global-route pipeline, OpenROAD Tcl, config YAMLs | claimed | not runnable | - | **all of it** | - | - | OpenROAD, Nangate45 |
| Nangate45 / FreePDK45 / fakeram45 technology files | referenced | - | only simulation models (`nangate45_sim_models.sv`) | **no .lib/.lef/.tlef anywhere in the repo** (inventory in section 3) | - | - | needs OpenROAD-flow-scripts `bfcc1895` platform files |
| Reported results (CTS complete, post-GR slack, ...) | claimed in README | **unverifiable** | - | results/ missing | - | - | - |

Also: README says "none of Projects 31-39 found; DieTop is a STAND-IN". In this repository P31-P39 *do* exist (`silicaflux-dietop-p31.zip`, `computecluster-p32`, `sramgrid-p33`, `noc-spine-p34`, `clocktree-p35`, `powerfabric-p36`, `ioshell-p37`, `timingflow`, `dftgrid-p39`), so the stand-in premise is stale; P40's `rtl.dietop_source: external` switch is in the missing config tree. The stand-in control core is a behavioural stub, not the RV32 ControlCore.

**Licensing.** First-party, no licence. Nangate45/ORFS are Apache-2.0/BSD-style per project docs but not bundled.

### 2.8 ThermalLab (`SilicaFlux ThermalLab (1).zip`, inventory only)

Outer zip (10 MB): `FINAL_ENGINEERING_REPORT.md` + `silicaflux-thermallab-0.1.0.zip`, which holds `asic/thermallab/` (204 files, 23 MB unpacked): Python package `thermallab` (42 modules; `pyproject.toml`: Python >= 3.12; numpy, scipy, pandas, pydantic, PyYAML, matplotlib, plotly; optional fastapi/pyvista), 30 test files, configs (`silicaflux_v.yaml`, `mcu_i.yaml`, `package_reference.yaml`, `reference_slab.yaml`, `thermal_sweep.yaml`, `materials.yaml`), pre-generated reports and HTML dashboard, `MANIFEST.sha256`. Function: 3-D finite-volume conduction (steady/transient), package/cooler models, electrothermal coupling, hotspot detection, thermal-aware floorplan optimisation, HotSpot 7.0 / 3D-ICE 4.0 comparison (not bundled; built on request by `scripts/build_externals.sh`).
Status per its own report: solver validated (16/16 analytical cases; 3D-ICE agrees within 19 mK; **HotSpot comparison disagrees by 0.81 K / 12 %**); **all geometry/power/package inputs are demonstration values** (`NO_REPOSITORY_ACCESSIBLE`), 14 gates PASS, 2 PARTIAL, 1 NOT_MET (no real floorplan geometry); no measurements. Not run by me. **Licences:** deps BSD/MIT/PSF; Hypothesis MPL-2.0 (tests); HotSpot UVA licence; **3D-ICE GPL-3.0** (invoked as a separate process, never linked); Google Fonts SIL OFL fetched by the dashboard; ThermalLab itself no licence file.

### 2.9 Supplementary: bitcoin SHA-256 ASIC re-run (for Task A)

`PYTHONPATH=.:python python3 -m silicaflux_bitcoin.verify` on a copy (Icarus 12): Python golden model self-consistency 10/100/1 000/10 000 vectors PASS (the 100 000-vector step did not finish in the 8-minute box); RTL: `tb_sha256_sigma`, `_round`, `_message_schedule`, `tb_nonce_allocator` (NUM_CORES 1/3/4/8/16/64), `tb_target_compare`, `tb_sha256_compressor`, `tb_sha256_double_hash`, `tb_sha256_pipeline` depth 64 and 32 **PASS** (`btcasic_verify.log`). The harness's own 90 s timeout hit `tb_sha256_schedule_step` under load (reported FAIL = TIMEOUT); I re-ran it with a 400 s timeout using the project's `_run_one()` helper unchanged: **PASS** (159 s); pipeline depths 16, 8, 4 **PASS** (`btcasic2_rest.log`). Not completed: pipeline depths 2 and 1, `tb_hash_core`, `tb_hash_core_array`, `tb_miner_top`, `tb_formal_checker_selftest`.

## 3. Technology / PDK / OpenROAD material: present vs referenced

Inventory by `find` over all 105 extracted zips (`tech_files_found.txt`, `tcl_by_project.txt`):

| Technology | Files actually present in the repository | Where | Referenced but **absent** |
|---|---|---|---|
| **sky130hd** (SkyWater, Apache-2.0) | `sky130_fd_sc_hd__tt_025C_1v80.lib` (12.8 MB), `sky130_fd_sc_hd_merged.lef` (1.5 MB), `sky130hd.tlef` | `silicaflux-testcore-p07/third_party/pdk/`, `dftgrid-p39/third_party/silicaflux-testcore/pdk/`, `tensorcore01/third_party/` (lib only) | sky130 **SRAM** macro views (OpenRAM): only RTL leaf stubs `sram_leaf_sky130.sv` and JSON abstracts; macros are fetched on demand |
| **IHP SG13G2** (Apache-2.0) | `sg13g2_stdcell.lef`, `sg13g2_tech.lef`, std-cell liberty fast/typ/slow, IO cell LEF/lib (typ/fast/slow), bondpad LEF | `silicaflux-clocktree-p35/third_party/ihp-sg13g2/`, `silicaflux-ioshell-p37/third_party/ihp-sg13g2/` | IHP SRAM macro views (fetched on demand) |
| **GF180MCU** | only RTL leaf stubs and JSON abstracts (`gf180mcu_fd_ip_sram__*.json`) | `sramlib`, `sramgrid-p33` | LEF/lib/GDS |
| **Nangate45 / FreePDK45 / fakeram45** | **none** (no `.lib/.lef/.tlef`, no `*nangate*`, `*fakeram*`, `*freepdk*` file in any zip) | - | everything P40 needs (`physical/silicaflux/tech/nangate45` is not in the zip) |
| **asap7** | none | - | - |
| Commercial PDK / compilers | none | - | placeholders only (sramlib `PENDING` manifests, `asic_ddr5_axi_licensed.json` in extmem) |

OpenROAD/OpenSTA **scripts** do exist, but for sky130hd/IHP, not Nangate45: P07 (`asic/dft/run_scan.tcl`, `asic/floorplan/place_compare.tcl`, STA scripts - **run by me**, section 2.5), P39 (`asic/{synth,dft,floorplan,sta}` - **run by me**), `floorplanlab` (38 Tcl, Python pipeline), `timingflow` (18 Tcl: `or_flow.tcl`, `sta_*.tcl`), `timinglab` (`flow/openroad/pnr.tcl`), `sramgrid-p33` (`macro_place.tcl` x8, `openroad_place_check.tcl`), `clocktree-p35` (`cts/*.tcl`), `computecluster-p32` (region check), `ioshell-p37` (`padring.tcl`), `powerfabric-p36` (`pf_pi.tcl`, UPF), SilicaFlux-V `or_place.tcl`. Several earlier projects state "no OpenROAD/PDK in this environment" (e.g. StorageCore `synth/openroad/` was never run). I ran none of floorplanlab/timingflow/timinglab/sramgrid/clocktree/ioshell/powerfabric.

## 4. Toolchain availability (exactly what could be installed / used here)

| Tool | Result | How |
|---|---|---|
| **RISC-V GCC** | **Installed and used.** `gcc-riscv64-unknown-elf` 13.2.0-11ubuntu1+12 + `binutils-riscv64-unknown-elf` 2.42 (`apt-get install -y gcc-riscv64-unknown-elf` -> "already the newest version", `apt_install_riscv.log`). Multilib includes `rv32i/ilp32`, `rv32im/ilp32`, `rv32imac`, `rv32imafdc`, `rv64`, ... (`-print-multi-lib`). Compiled an rv32im test file; rebuilt ControlCore firmware + ROM bit-identically; built/ran 63 riscv-tests. No newlib/picolibc installed (apt candidate `picolibc-riscv64-unknown-elf` 1.8.6-2 exists); the projects are freestanding. Also present: clang/lld 18 (DataFabric firmware `--target=riscv32-unknown-elf`, `make -B -C firmware` exit 0). |
| **OpenROAD** | **Usable, but not from apt.** `apt-cache policy openroad` empty; `apt-cache search -n openroad` no result. PyPI has `openroad 0.0.1` (a 46 MB manylinux_2_38 *Python-extension* wheel, published 2025-09-16, no author field, homepage = the official repo): I downloaded and listed it but did **not** install or execute it (unverifiable provenance, not a CLI). What worked: the image already has **Nix 2.34.6** (Determinate installer; `/etc/nix/nix.conf`); `nix-store --realise /nix/store/6qbn5zjnnnyna6md4rsmiqw4y26y8556-openroad-26Q3` substituted a 209-path closure from `https://cache.nixos.org` (signature-verified by Nix; 1.9 GB `/nix/store` total) in about 2 minutes (`nix_realise_openroad_sby.log`). `openroad -version` -> `26Q3`; Tcl smoke test OK (`nix_tools_smoke.log`); it then ran the P07/P39 scan-insertion and placement flows above. (I also ran `apt-get install nix-bin`, which added Ubuntu's Nix 2.18 that is not on PATH - redundant.) |
| **sta (OpenSTA)** | **Usable.** No apt package (`opensta` has no candidate). Shipped in the same Nix openroad output: `sta -version` -> `3.1.0`; used by P07 (`timing_modes`) and P39 (`synth`). |
| **sby (SymbiYosys)** | **Usable, not from apt** (`symbiyosys`/`sby` no candidate; no PyPI package named `sby`/`symbiyosys`). Nix path `/nix/store/hmrimr3nwb4d2di2jm9s5r9g70cc6zix-sby-0.70` (55-path closure, drags in Yosys 0.70). It ran the P07 formal suite (6/6 PASS) and P39 `fv_collar`/`fv_collar_self` PASS. Solvers: apt `z3` 4.8.12 and `boolector` installed by me; `abc pdr` engine comes with Yosys. (A `git clone` of github.com/YosysHQ/sby also works through the proxy - `git ls-remote` returned refs - but I did not need it.) |
| **yosys** | **Used.** apt 0.33 (`/usr/bin/yosys`, what the projects target) and Nix 0.70 (`yosys -V` -> 0.70, includes `yosys-smtbmc`, `yosys-abc`). |
| **verilator** | **Used.** apt 5.020 (`/usr/bin/verilator`). (A pip `verilator 5.48.0` exists in an unrelated scratch venv; not on PATH, not used.) |
| **iverilog** | **Used.** 12.0 (apt). |
| **nextpnr** | **Installed by me and smoke-tested.** `apt-get install nextpnr-ice40 nextpnr-ecp5 z3` (exit 0, `apt_install_nextpnr_z3.log`): nextpnr-ecp5 and -ice40 0.6-3build5; a tiny counter through `synth_ecp5` + `nextpnr-ecp5 --25k --package CABGA256` and `synth_ice40` + `nextpnr-ice40 --hx8k` ran to completion (`nextpnr_smoke.log`). Bitstream packers (`ecppack` in `fpga-trellis` 1.4-2build4, `icepack` in `fpga-icestorm`) have apt candidates but are **not installed**, so ControlCore's `make fpga` bitstream step was not run. |
| Other | `openocd` 0.12 installed via apt (used by P07 OpenOCD bridge, PASS); cocotb 1.9.2 (ControlCore) and 2.1.0 (DataFabric) in separate venvs; clang-18/lld present. |

Network reachability through the agent proxy: `github.com` HTML/release/codeload URLs -> **403**; `git clone`/`git ls-remote` over HTTPS to github.com -> **works** (OpenROAD, OpenSTA, sby, riscv-tests, the three open SRAM macro repos); `raw.githubusercontent.com` -> 200; `cache.nixos.org` -> 200 (`nixos.org` 403); `conda.anaconda.org` -> 200; PyPI OK. So prebuilt GitHub *release* binaries cannot be downloaded; Nix cache, apt, PyPI and git clones can. No untrusted install script was run as root; the only privileged installs were Ubuntu `apt-get` packages and Nix substitutions of signed store paths.

## 5. Cross-cutting findings for the integration plan

1. **Everything is simulation/synthesis-estimate evidence.** No block has FPGA-on-board, silicon, or signoff results. ControlCore (FPGA bitstream only for the harness), P07/P39 (sky130hd synthesis/scan/placement, no CTS/route).
2. **Two TestCore lineages and two ControlCore memory-map versions (P21 v1.0, P28 v2.0)**: choose one set and record it.
3. **The documented one-outstanding SFB2 fabric is the first bottleneck** for any storage data path; use it for control/metadata only, or plan the burst/ID extension.
4. **ECC/parity policy is fragmented**: ControlCore byte parity, RAS SECDED wrapper, BufferCore parity+CRC32C; sramlib has none.
5. **No security hardware primitives for storage** (see `p59_audit.md`): no AES/XTS/HMAC/KDF/TRNG/key store; P28 gives SHA-256 hardware + Ed25519 software verify only; lifecycle/fuse state is a power-loss-volatile model.
6. **P40 cannot be used as delivered**: the physical-design pipeline and Nangate45 files must be re-supplied. Meanwhile OpenROAD 26Q3/OpenSTA/sby are available here via the Nix cache, and sky130hd/IHP std-cell files are in the repo, so a new floorplan flow could be built on those instead.
7. **Licensing**: no LICENSE anywhere in the repository (root, `SilicaFlux-main/`, or any block); each block's own docs say "internal, owner must add a licence". Third-party present: secworks sha256 (BSD-2), Monocypher (BSD-2/CC0), sky130hd (Apache-2.0), IHP SG13G2 (Apache-2.0), **`silicaflux-ecccore/ext/linux_bch/bch.c` GPL-2.0** (P54, software golden model; keep out of any shipped firmware). Tool licences (not redistributed): Yosys/sby/nextpnr ISC, Verilator LGPL-3/Artistic, Icarus GPL-2, OpenROAD BSD-3-Clause and OpenSTA GPL-3.0 (from general knowledge; I did not read the store licence files).

## 6. Process disclosure

* While shutting down my own timed-out batch queues I used `pkill -f` with generic patterns (`scripts/regress.py`, `run_regress.py`, `unit_regress.py`, ...) at about 21:15 UTC. In a container shared with other sessions this may have interrupted some other session's regression processes that matched those names. I could not tell which, and I did not touch any repository file. I then restricted myself to targeted kills.
* Installed in the container (not the repository): apt `nextpnr-ice40`, `nextpnr-ecp5`, `z3`, `boolector`, `openocd`, `nix-bin`; Nix store paths for OpenROAD 26Q3, sby 0.70, Yosys 0.70; Python venvs under `$SP` (`venv_cc192`, `venv_df`, `venv_tc`).
* Driver scripts (project code untouched): `$SP/scripts/{df_subset.py, btc_rest.py, sram_mut2.py, run_steps.sh, chunk.sh, cc_runs.sh, inventory.py, scan_all_zips_content.py}`.
