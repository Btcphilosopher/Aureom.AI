# Audit: Project 51 "StorageCore" (silicaflux-storagecore)

Audited tree (pristine): `scratchpad/audit/p51_storagecore/silicaflux-storagecore`
Working copy used for all runs: `scratchpad/work/p51/silicaflux-storagecore`
Raw logs: `scratchpad/audit_out/p51/*.log` (every log starts with `### CMD`, `### CWD`, and ends with `### EXIT`, `### WALL_SECONDS`)
Auditor driver scripts (outside the project tree, they only load project code unmodified): `scratchpad/audit_scripts/`, `scratchpad/runlog.sh`

Environment: Verilator 5.020 (Debian), Icarus 12.0, Yosys 0.33, Python 3.13 + PyYAML 6.0.3. `gcc-riscv64-unknown-elf` 13.2 was missing and was installed with `apt-get install gcc-riscv64-unknown-elf` (log `00_apt_install_riscv.log`). The container is shared with other audit jobs: load average was 12-32 on 4 cores for the whole session, so **all wall times below are inflated 3-6x** relative to an idle machine and several default-flag builds hit the 8-minute cap (see Evidence log).

---

## 1. Summary verdict

P51 is a real, self-consistent, simulation-complete storage SoC. Every functional claim that I re-ran reproduced **bit-exactly** (identical check counts and identical cycle counts to the shipped reports): the firmware rebuilds to a byte-identical image (CRC32 `f7d46dd3`), the register-map generator is current and rejects 20/20 illegal maps, the subsystem testbench passes on Icarus **and** Verilator for all three configurations (345 / 315 / 554 checks), the full-SoC testbench (unmodified ControlCore RV32IM CPU running the real C firmware/FTL against a behavioural NAND model) passes for all three configurations plus the second host-memory seed (152 / 142 / 195 / 152 checks, 2.03 M / 1.83 M / 2.01 M / 2.03 M cycles), Verilator `-Wall` is clean on the new RTL, and the first Yosys rows I re-ran reproduce exactly. What it is **not**: it is not NVMe/PCIe/ONFI-conformant, it has no PCIe or DRAM or NAND IP, no board or FPGA P&R or ASIC run exists, the media model is self-written, the FTL is minimal (256 LBAs per channel, no GC/wear levelling), ECC is per-word SECDED (not NAND-grade), and there is no firmware authentication. For integration, the key point is that P51 is not a leaf block: it is a **ControlCore-centred SoC** whose firmware, IRQ slots, register pages 8..15, EXT window and boot flow are bound to a specific unmodified ControlCore instance; the host side is a private SQ/CQ-in-controller-memory ABI on a private SFB2 bus (single outstanding transaction, no bursts).

Classification legend used below: **V** = Verified by me (command + result in Evidence log); **PV** = partially verified by me; **I** = implemented but not re-run by me; **M** = missing; **X** = incompatible with a single integrated top (as shipped); **S** = simulation-only; **E** = external-IP-dependent.

---

## 2. Classification table

One primary status per row; the note carries the nuance. "Ev" numbers refer to the Evidence log (section 3).

| # | Function / feature | Implemented | Verified (by ME) | Partially verified | Missing | Incompatible | Simulation-only | External-IP-dep. | Primary | Note |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Host interface `sfs_host_if` (SQ/CQ rings in controller memory behind BAR, doorbells, phase tags, EN/RDY, shutdown, IRQ) | x | x | | | | | | **V** | Unit (all 3 cfgs, Icarus+Verilator) and SoC scenarios pass (Ev 3, 4, 10-15). The "host" is a testbench driver on an SFB2 slave port; no PCIe. |
| 2 | Command controller `sfs_cmd_ctrl` (13 hardware validation rules, tag table, FWQ, completion posting) | x | x | | | | | | **V** | Unit group `invalid` (13 cases) + SoC `invalid`; same evidence as row 1. |
| 3 | Storage DMA `sfs_dma` (descriptor queue, tagged completions, abort, bus errors) | x | x | | | | | | **V** | Unit `dma`, SoC back-pressure scenario. Throughput limited by SFB2 R6 (about 1 word / 4 cycles); no perf report exists in P51 to verify. |
| 4 | NAND channel controller `sfs_nand_ctrl` (ONFI-style async SDR sequencer, inline SECDED, WP#, timeout) | x | | x | | | | | **PV** | Passes against the project's own behavioural model only; no vendor model, no timing sign-off, no NV-DDR/Toggle. Real parts will need re-tuned timing and a parameter-page/geometry source. |
| 5 | NAND flash model (`tb/models/sfs_nand_flash_model.sv`) | x | | | | | x | | **S** | Behavioural, uses `initial`, `#` delays, `inout`, `realtime`; not synthesizable by design. Geometry is 64 blocks x 16 pages x 512 B (user) per channel. |
| 6 | Buffer SRAM with SECDED (`sfras_sfb_ecc_slave`, P26) and plain `sfb_sram_slave` | x | x | | | | | | **V** | Generic (flop/inferred-array) backend only (`SRAM_BACKEND_GENERIC`). The ASIC macro path exists in sramlib but is E (needs foundry/OpenRAM macros) and was not exercised. |
| 7 | Page ECC: per-32/64-bit-word SECDED, interleaved ECC beat | x | x | | | | | | **V** | Correct 1-bit / detect 2-bit verified in unit `ecc` and SoC `ecc`. Not NAND-grade; see row 8. |
| 8 | NAND-grade ECC (BCH/LDPC over 512 B-1 KiB codewords) | | | | x | | | | **M** | Stated limitation. Layout is the "integration point". P54 BCH/LDPC is not wired in. |
| 9 | ControlCore (RV32IM_Zicsr CPU, boot ROM + CRC32 image check, IMEM 64 KiB / DMEM 32 KiB, INTC, WDT, mailbox, RAS, PMU) | x | x | | | | | | **V** | Re-exercised by the real firmware in every SoC run. The ControlCore's own evidence (riscv-tests 63/63, formal, 231 self-checks) is **not** reproducible from this tree and was not re-run. |
| 10 | Storage firmware (C, RV32IM, `-Wall -Wextra -Werror`) | x | x | | | | | | **V** | Rebuilt here: text 14068 B, bss 7808 B, image 14324 B, CRC32 `0xf7d46dd3`; byte-identical to shipped `.hex/.img/.payload.bin` (Ev 2). |
| 11 | FTL: page-mapped L2P (16-bit entries) in DMEM, pre-erase, bad-block retirement, checkpoint on FLUSH/FUA/shutdown/power-loss | x | x | | | | | | **V** | SoC scenarios incl. power loss, checkpoint, reboot. Capacity 256 LBAs (128 KiB) per channel. |
| 12 | Garbage collection, wear levelling, read-disturb, A/B metadata blocks | | | | x | | | | **M** | Stated limitation (an interrupted metadata-block erase loses the previous checkpoint). |
| 13 | Power-loss protection (quiesce, drain, checkpoint, WP#) | x | x | | | | | | **V** | SoC `plp` scenario (log: "[plp] drained, FTL checkpoint ... FW_SAFE (WP# asserted)"). Hold-up energy is not modelled. |
| 14 | Controller reset in flight (EN 1->0 with owned tags), back-pressure, full CQ, concurrency (out-of-order completion) | x | x | | | | | | **V** | SoC log: "8 commands in flight, 7 completed out of submission order"; "[hif] controller reset requested ... aborting 4 command(s)". |
| 15 | Security: management lock, ControlCore host write lock, PHYSICAL commands gated by `SEC_CTRL.PHYS_EN` | x | x | | | | | | **V** | SoC `security`, `flush_phys`. Access control only. |
| 16 | Firmware authentication / secure boot / encryption | | | | x | | | | **M** | Firmware banner: "image integrity = CRC32 only; NO authentication is implemented". P28 not integrated. |
| 17 | Address-map generator (`gen_map.py`: SV pkg, enums, configs, C header, Markdown) | x | x | | | | | | **V** | `--check` 5/5 outputs up to date; `--selftest` 20/20 illegal maps rejected (Ev 1). |
| 18 | Multi-channel research config (4 ch x16, 64-bit DMA, 16 tags, 40-bit addr) | x | x | | | | | | **V** | Unit 554/554 (Icarus + Verilator) and SoC 195/195 (Ev 3, 12, 13). Fabric-bound (one outstanding transaction per port). |
| 19 | Verilator `-Wall` lint, 2 tops x 3 cfgs; illegal parameters rejected | x | x | | | | | | **V** | 0 new-RTL warnings; 82 (subsystem) / 363 (SoC) warnings in unmodified third_party (not counted; 279 of the 363 are UNUSEDPARAM, 77 TIMESCALEMOD). 20 scoped `lint_off` pragmas exist in new RTL. (Ev 7) |
| 20 | Yosys generic + ECP5 size estimates, `check -assert` | x | | x | | | | | **PV** | Re-ran 5 of the 12 (config, top, target) combinations: min1ch subsystem (generic + ECP5), noecc1ch subsystem (generic + ECP5), min1ch SoC (generic; its ECP5 run did not complete in 8 min) - every number identical to the shipped report. The other 7 combinations were not reproduced within the time-box. See Ev 8, 16, 17. |
| 21 | FPGA P&R, timing closure, board bring-up | | | | x | | | | **M** | None exists. `nextpnr-ecp5` is now installed on the box but P51 ships no P&R script and claims none. |
| 22 | ASIC/OpenROAD flow (`synth/openroad/`) | | | | x | | | x | **M** | Config prepared, "not executed"; needs OpenROAD, IHP SG13G2 PDK and SRAM macros. |
| 23 | PCIe endpoint / NVMe compliance | | | | x | | | x | **M** | Host side is an SFB2 slave port. P57 provides the NVMe front end on top. |
| 24 | Host reference driver (`sw/host`) | x | | x | | | | | **PV** | Compiles clean (`gcc -std=c11 -Wall -Wextra -Werror -pedantic`, Ev 18); never executed against anything. |
| 25 | Vendored third_party = unmodified upstream | x | | x | | | | | **PV** | Local manifest 69/69 OK; contents also equal the independently extracted `x_controlcore`, `x_ras`, `x_datafabric`, `x_sramlib` trees where paths overlap. The "vs archive in Aureom.AI" check (`check_vendor.py --repo`) was **not** run (repo is off-limits for this audit). |
| 26 | Clock/reset/CDC: one clock, `sfv_rst_sync`, `sfv_sync` on R/B# and power-fail | x | | x | | | | | **PV** | Exercised in sim only; no CDC/reset-domain static check was run; no PCIe/NAND-clock CDC exists. |
| 27 | Performance numbers | | | | x | | | | **M** | P51 gives no perf report. Only "about 1 DMA word per 4 cycles". (P57 measures SoC throughput: 7-11 MB/s.) |
| 28 | Exit-code based CI | | | | x | | | | **M** | Testbenches call `$finish` on pass and on fail, so `make unit/soc` returns 0 even on failures; success is only the printed verdict line (`scripts/regress.py` parses it). Wrap before using in CI. |

---

## 3. Evidence log

All commands were run in the **work copy** `scratchpad/work/p51/silicaflux-storagecore` (called `$W`). Logs are in `scratchpad/audit_out/p51/`. "-O0" rows are the **same Verilator command line as the Makefile target** except `-MAKEFLAGS OPT_FAST=-O0` (C++ compile optimisation) and a different `-Mdir`; used only because the default `-Os` compile of the single 5 MB generated `DepSet__0.cpp` could not finish in 8 minutes under the load described above. RTL, testbench, firmware and defines are unchanged.

| Ev | Command (cwd `$W` unless noted) | Exit | Wall | Key output |
|---|---|---|---|---|
| 0 | `apt-get update; apt-get install -y gcc-riscv64-unknown-elf` (log `00_apt_install_riscv.log`) | 0 | - | riscv64-unknown-elf-gcc 13.2.0 installed |
| 1 | `make check-map` (`01_check_map.log`) | 0 | 0 s | `gen_map --check: 5/5 outputs up to date`; `map selftest: 20/20 PASS` |
| 2 | `make fw` (`02_fw.log`) | 0 | 1 s | text 14068, bss 7808; `mkimage: sfs_fw.img 14324 B (21% of IMEM) entry 0x00010100 crc32 0xf7d46dd3`; `cmp` of rebuilt `sfs_fw.hex/.img/.payload.bin` vs shipped copies: identical |
| 3 | `make unit CFG=min1ch` / `noecc1ch` / `research4ch` (Icarus; `03_unit_icarus_*.log`) | 0,0,0 | 7 s, 4 s, 22 s | `tb_sfs_subsys min1ch: 345 checks, 0 failures -> PASS`; `noecc1ch: 315 ... PASS`; `research4ch: 554 ... PASS` |
| 4 | `make soc CFG=min1ch SCENARIO=full` (default flags; `04_soc_min1ch_full.log`) | 0 | 348 s | `TB DoD: command accepted, NAND model accessed, tagged results returned -- MET`; `HOST READY at cycle 638219: channels=1 capacity=256`; `FW| SHUTDOWN: commands 73 ... firmware errors 0 ... -> PASS`; **`tb_storage_soc min1ch full: 152 checks, 0 failures, 2026505 cycles -> PASS`** (console diff vs shipped `soc_min1ch_full.log`: empty) |
| 5 | `make soc CFG=noecc1ch SCENARIO=full` (default flags; `05_*.log`, `05b_*_resume.log`) | 124, 124 | 480 s, 480 s | **did not complete** (8-min cap, twice; stuck in the single `DepSet__0.o` C++ compile under load 26-32) |
| 6 | `scripts/regress.py --unit -j 2` (`06_regress_unit.log`) | 124 | 480 s | **did not complete** (concurrent with Ev 5); only first row printed: icarus min1ch PASS (345). `make regress` as a whole was therefore **not run**; its constituent targets were run individually (Ev 3, 4, 9-11, 15-16) |
| 7 | `make lint` (`07_lint.log`) | 0 | 45 s | 6 rows `0` new-RTL Verilator warnings (third_party 82 / 363 warnings not counted); Icarus elaborates all 6; `CHANNEL_DATA_WIDTH=12` and `DMA_DATA_WIDTH=48` rejected by both tools; `Result: PASS` |
| 8 | `make synth` (all 12 rows; `08_synth.log`) | 124 | 480 s | **did not complete** as a single command; only row 1 printed: `min1ch / sfs_storage_subsys: 24433 cells, 2957 FF, 14 $mem, PASS, 6634 LUT4, 3086 FF, 10 DP16KD` = shipped values |
| 9 | `make unit-vl CFG=min1ch` (default flags; `09_unit_vl_min1ch.log`) | 124 | 480 s | **did not complete** (8-min cap, C++ compile under load) |
| 10 | Verilator unit TB, `-O0` C++: `p51_vl_O0.sh $W unit min1ch` (`10_*.log`) | 0 | 120 s | `tb_sfs_subsys min1ch: 345 checks, 0 failures -> PASS` |
| 11 | same, `unit noecc1ch` (`14_*.log`) | 0 | 147 s | `315 checks, 0 failures -> PASS` |
| 12 | same, `unit research4ch` (`15_*.log`) | 0 | 207 s | `554 checks, 0 failures -> PASS` |
| 13 | Verilator SoC TB, `-O0` C++, `p51_vl_O0.sh $W soc research4ch` (`11_*.log`) | 0 | 380 s | 4 channels enumerated (`ch0..ch3 ... NAND ID 10a1da5f`); `DoD ... MET`; `SHUTDOWN: commands 105 ... firmware errors 0 -> PASS`; **`research4ch full: 195 checks, 0 failures, 2013494 cycles -> PASS`** |
| 14 | same, `soc noecc1ch` (`16_*.log`) | 0 | 225 s | **`noecc1ch full: 142 checks, 0 failures, 1829066 cycles -> PASS`** |
| 15 | `./build/v_soc_min1ch/Vtb +scenario=full +fw=firmware/build/sfs_fw.hex +hm_seed=2` (built in Ev 4; `17_*.log`) | 0 | 26 s | **`min1ch full: 152 checks, 0 failures, 2029904 cycles -> PASS`** (= shipped seed-2 run) |
| 16 | `python3 -B $SP/audit_scripts/p51_synth_one.py $W noecc1ch sfs_storage_subsys` (calls the project's own `scripts/synth.py` `run()`; `19_*.log`) | 0 | 190 s | generic 20574 cells / 2526 FF / 14 $mem; ECP5 5288 LUT4 / 2656 FF / 8 DP16KD = shipped values |
| 17 | same, `min1ch silicaflux_storage_soc` (`18_*.log`) | 124 | 480 s | generic finished in 199 s: 56660 cells / 6784 FF / 21 $mem = shipped; **ECP5 run did not complete** within the 8-min cap |
| 18 | `gcc -std=c11 -Wall -Wextra -Werror -pedantic -Isw/include/generated -c sw/host/sfs_host.c` (`12_host_driver_compile.log`) | 0 | 0 s | compiles clean |
| 19 | `cd third_party; sha256sum -c SHA256SUMS` (`13_vendor_manifest_check.log`) | 0 | 0 s | 69/69 OK (self-referential manifest) |
| 20 | `diff -rq` of P51 third_party vs `x_controlcore`, `x_ras`, `x_datafabric`, `x_sramlib` (common paths) | - | - | no differing files |
| 21 | `./build/v_soc_min1ch/Vtb +scenario=dod +fw=firmware/build/sfs_fw.hex` (`20_soc_min1ch_dod.log`) | 0 | 8 s | `tb_storage_soc min1ch dod: 30 checks, 0 failures, 825162 cycles -> PASS` (the figure P57 docs/00 quotes for P51) |

Not run (and why): `make vendor-check REPO=<Aureom.AI checkout>` (the repository is out of scope for this audit); `synth/openroad/` (OpenROAD/PDK absent, project says not executed either); nextpnr P&R (project ships none); remaining 7 Yosys (config,top,target) combinations (time-box); `make regress` as one command (time-box; constituents run).

### 3b. Yosys notes
* `scripts/synth.py` computes a latch count but discards it (`ok_g, st_g, _, err_g = run(...)`); my driver printed it as ~226 because the regex also matches `$dlatch` in Yosys log chatter. In the final `stat` section of the subsystem logs there are **0** latch cells; the SoC log shows one inferred latch (`sfv_clkgate.en_l`, the ControlCore ICG), which the project's own docs call the only intentional latch. `check -assert` does not flag latches, so "no latches" in README is supported only by this manual reading, not by the script.
* Generic flow keeps SRAMs as `$mem` (21 in SoC min1ch). Area is therefore only meaningful for logic; memories are in the ECP5 DP16KD column.

---

## 4. Doc claims NOT reproduced / not substantiated

| Claim (where) | Status |
|---|---|
| "Vendored sources byte-identical to the repository archives, 69/69" (README, PROVENANCE.md) | Not reproduced: needs `check_vendor.py --repo <Aureom.AI>`; I only confirmed the local SHA256SUMS manifest (69/69) and equality with the `x_*` project copies. `third_party/silicaflux-controlcore/third_party/PROVENANCE_CC.md` still says "SHA256SUMS lists all 160 files ... commit 8158b9d ... 160 files, 0 problems", i.e. it describes P21's full vendor tree, not the 69-file subset actually shipped here; P51's own PROVENANCE cites commit e1f75e3. |
| ControlCore evidence: riscv-tests 63/63, 6/6 system scenarios, 231 firmware self-checks, formal proofs (docs/00_AUDIT.md, quoted from P21/P26/DataFabric) | Not reproducible from this tree (the CPU testbenches, riscv-tests fetch script and formal scripts are not vendored). Only "the CPU runs the real firmware" is verified by me. |
| "Synthesis: all 6 rows `check -assert` clean ... full SoC incl. CPU about 18 k LUT4, 6.9 k FF, 58 DP16KD" | Reproduced for 5 of 12 (config,top,target) combinations (identical numbers); the other 7 not re-run (min1ch SoC ECP5 did not complete in the 8-min cap). The README's "no latches" is not enforced by the script (see 3b). |
| "make soc builds in about 10-15 min C++ compile" (README) vs P57 docs "built in 2 min 43 s" | Mine: 348 s wall under 3-6x CPU contention (about 1.5-2 min equivalent). README figure appears pessimistic; either way it is a build-time claim only. |
| docs numbering | `docs/08_LIMITATIONS.md` has heading "# 09 - Limitations"; `docs/07_LINT_SYNTHESIS.md` has heading "# 08 - Lint..."; cross-references "docs/08" in text mean the limitations file. Cosmetic. |
| Timing "100 MHz" | Simulation clock only (`CLK` period in TB); no timing analysis exists anywhere. |
| FPGA fit "within LFE5U-85F by resource count" | Pure arithmetic from Yosys estimates; no P&R. (P51 states this itself.) |
| "Concurrency 8/16 commands in flight, 7/14 out of order" | min1ch confirmed in my log (`8 commands in flight, 7 completed out of submission order`); research4ch value (14) not separately grepped. |

---

## 5. Reusable interface reference

All SilicaFlux on-chip buses are **SFB2** (DataFabric `PROTOCOL.md`): `req_valid/req_ready/req_write/req_addr[31:0]/req_wdata[DW-1:0]/req_wstrb[DW/8-1:0]` and `rsp_valid/rsp_ready/rsp_rdata[DW-1:0]/rsp_error`; one beat per transaction, DW-aligned address, **one outstanding transaction per port** (R6), no bursts, responses in order, write response after the write is performed (R7), little-endian, async-assert/sync-release reset shared with the fabric. DW in {32,64,128}.
Register pages use the SilicaFlux-V "rb" register bus: `sel, we, addr, wdata, rdata, err`, one-cycle strobe, same-cycle read data, word accesses only.
Clock: one `clk` (100 MHz in sim). Reset: `rst_ni` async active-low (synchronised inside ControlCore with `sfv_rst_sync`; storage flops use `always_ff @(posedge clk or negedge rst_n)`).

### 5.1 `silicaflux_storage_soc` (top)  -  `rtl/silicaflux_storage_soc.sv`

Parameters (defaults = `min1ch`): `NUM_NAND_CHANNELS`=1 (1..8), `CHANNEL_DATA_WIDTH`=8 (8|16), `BUFFER_SIZE_BYTES`=16384 (pow2, 4 KiB..16 MiB), `DMA_DATA_WIDTH`=32 (32|64), `ADDRESS_WIDTH`=32 (16..64), `CMD_QUEUE_DEPTH`=8 (pow2 2..64; = tags; SQ/CQ entries = 2x, <=64), `ENABLE_ECC`=1, `ENABLE_RAS`=1, `NAND_PAGE_BYTES`=512 (pow2 64..16384; = logical block), `SRAM_BACKEND`=`SRAM_BACKEND_GENERIC`. Illegal sets `$fatal` at elaboration (both simulators). Other shipped sets: `noecc1ch` (ECC=0, RAS=0), `research4ch` (4 ch, x16, 64 KiB, DMA 64, ADDRESS_WIDTH 40, 16 tags). Packages needed: `sfs_map_pkg`, `silicaflux_storage_pkg`. Includes: `sram_defs.svh`, generated `sfs_proto_enums.svh`, `sfras_defs.svh`.

| Port | Dir | Width | Meaning |
|---|---|---|---|
| `clk`, `rst_ni` | in | 1 | clock, async active-low reset |
| `test_mode` | in | 1 | DFT/test (sync-reset bypass in `sfv_rst_sync`) |
| `boot_mode_i` | in | 2 | ControlCore boot source; **HOST (image written through BAR)** is the only flow used/tested |
| `host_rst_req_i` | in | 1 | host-requested ControlCore reset (async, synchronised) |
| `pwr_fail_ni` | in | 1 | power-fail warning, active-low, async (2-flop sync) |
| `hb_req_*` / `hb_rsp_*` | slave | 32-bit addr/data, 4 strobe | **host BAR, SFB2 slave.** `0x0000_0000..0x7FFF_FFFF` = MGMT (ControlCore host port: firmware image load, mailbox), `0x8000_0000..0x8000_FFFF` = SHC (queue controller). BAR is split by an internal `sfb_crossbar` |
| `hm_req_*` / `hm_rsp_*` | master | 32-bit addr, `DW` data, `DW/8` strobe | **host-memory master, SFB2.** Address = fabric `0x3000_0000+X` -> `X` (256 MiB window; 32-bit host addresses only). Refused unless the host set `CTRL.EN` |
| `host_irq_o` | out | 1 | level: `INT_CTRL[0]&CQ-pending | INT_CTRL[1]&EVT` |
| `mgmt_irq_o` | out | 1 | ControlCore mailbox F2H doorbell |
| `host_ready_o`, `cmdproc_ready_o` | out | 1 | firmware boot-stage pins |
| `ras_fatal_o` | out | 1 | ControlCore RAS fatal |
| `nand_ce_n, nand_cle, nand_ale, nand_we_n, nand_re_n, nand_wp_n` | out | `[NCH-1:0]` | NAND control pins per channel (single CE per channel) |
| `nand_dq_o`, `nand_dq_oe`, `nand_dq_i` | out/out/in | `[NCH*CDW-1:0]`, `[NCH-1:0]`, `[NCH*CDW-1:0]` | bidirectional DQ split into o/oe/i (no tri-state inside) |
| `nand_rb_n` | in | `[NCH-1:0]` | R/B#, async, synchronised (`sfv_sync`) |
| `diag_valid_o`, `diag_char_o[7:0]` | out | | firmware console byte stream (UART-less; TB prints `FW|` lines) |
| `test_done_o`, `test_fail_o`, `test_code_o[15:0]` | out | | `SYSCTRL.TEST_CTRL` verdict from firmware |
| `cpu_sleep_o` | out | 1 | WFI status |

### 5.2 `sfs_storage_subsys` (everything storage-specific, no CPU)  -  `rtl/sfs_storage_subsys.sv`

Same parameters as the SoC. Ports: `clk, rst_n`; `x_*` (ControlCore EXT, SFB2 slave 32-bit); `rb_sel, rb_we, rb_addr[15:0], rb_wdata, rb_rdata, rb_err` (ControlCore accelerator register port; `rb_addr[15]`=1, `[14:12]` = page-8, `[11:0]` = offset); `s_*` (SHC window, SFB2 slave 32-bit, address relative to SHC base) + `host_irq`; `hm_*` (SFB2 master, DW); NAND pins as above; `pwr_fail_ni`, `ev_sec_viol` (from SoC management gate); outputs `mgmt_lock, irq_io, irq_evt, busy_nand, busy_io, ext_warn, ext_fatal`.
Internal fabric (`sfb_crossbar`, AW=32, DW=`DMA_DATA_WIDTH`, NM=2+NCH, NS=2): masters m0 ControlCore EXT (via `sfs_sfb_upsizer` if DW>32), m1 `sfs_dma`, m2+c `sfs_nand_ctrl[c]` (BUF only); slaves s0 BUF (`0x2000_0000`, 16 MiB window; `BUFFER_SIZE_BYTES` implemented at the bottom, above = decode error), s1 HOSTMEM (`0x3000_0000`, 256 MiB, through `sfs_sfb_gate`).

### 5.3 Host-facing: `sfs_host_if`  -  `rtl/sfs_host_if.sv`

Parameters `SQD`=16, `CQD`=16 (entries; subsystem passes `HQD=min(2*CMD_QUEUE_DEPTH,64)`), `CMD_QUEUE_DEPTH`, `ADDRESS_WIDTH`. Ports: `clk, rst_n`; host SFB2 slave `h_*` (32-bit); firmware page `rb_sel, rb_we, rb_addr[11:0], rb_wdata, rb_rdata, rb_err`; `irq_hif`; command channel out `cmd_valid, cmd_ready, cmd (sfs_cmd_t)`; completion channel in `cpl_valid, cpl_ready, cpl (sfs_cpl_t)`; in `capacity[63:0], mdts[15:0], outstanding_zero, plp_quiesce`; out `en_o, rdy_o, resetting_o, ev_fetch, ev_cpl, ev_cq_stall, ev_db_err`.

**Host registers** (BAR `0x8000_0000` + offset; 32-bit word access only): `ID`0x000 (`0x53465348` "SFSH") · `VERSION`0x004 (`0x00010000`) · `CAP`0x008 `[7:0]` SQ entries `[15:8]` CQ entries `[23:16]` CMD_QUEUE_DEPTH `[31:24]` LBA bytes/64 · `CAP2`0x00C `[15:0]` MDTS blocks `[23:16]` ADDRESS_WIDTH · `CAPACITY_LO/HI`0x010/0x014 (published by firmware) · `CTRL`0x020 `[0]` EN `[1]` SHN · `STATUS`0x024 `[0]` RDY `[1]` CFS `[3:2]` SHST `[4]` PLP `[5]` RESETTING `[8]` DB_ERR · `INT_CTRL`0x028 `[0]` CQ irq en `[1]` event irq en · `INT_STATUS`0x02C (W1C; `[0]` CQ_PEND level, `[1]` EVT) · `SQ_TAIL`0x040 (value >= SQ entries ignored + DB_ERR) · `SQ_HEAD`0x044 · `CQ_HEAD`0x048 · `CQ_TAIL`0x04C · `SUBMITTED`0x060 · `COMPLETED`0x064. SQ ring: entry `s` word `w` at `0x1000 + 32*s + 4*w` (RW); CQ ring: entry `c` word `w` at `0x2000 + 16*c + 4*w` (RO).
**Bring-up:** write `INT_CTRL`, set `CTRL.EN=1`, poll `STATUS.RDY` (firmware raises it after boot), read `CAPACITY_LO`. Reset: `EN` 1->0 (aborts owned tags, clears queues/phase), then `EN`=1. Shutdown: `CTRL.SHN`, wait `SHST`=2.

### 5.4 Command / completion format (`silicaflux_storage_pkg`, protocol v1.0 = `0x0001_0000`)

**SQ entry, 8 x 32 bit** (host writes at the SQ ring, then `SQ_TAIL`):

| Word | Bits | Field |
|---|---|---|
| W0 | `[7:0]` | opcode |
| | `[8]` | ADDR_TYPE (0 logical LBA, 1 physical `{ch[31:24], block[23:8], page[7:0]}`) |
| | `[9]` | FUA |
| | `[15:10]` | reserved, **must be 0** (else INVALID_FIELD/RSVD_FIELD) |
| | `[31:16]` | TID (transaction id, echoed in completion; a TID still owned -> CID_CONFLICT) |
| W1 | | aux (IDENTIFY: CNS) |
| W2, W3 | | ADDR[31:0], ADDR[63:32] (`ADDRESS_WIDTH` bits implemented) |
| W4 | | LEN in logical blocks, 1-based (0 invalid for data commands; > MDTS invalid) |
| W5, W6 | | host buffer address (32 bits implemented; must be DW-aligned and inside the 256 MiB window) |
| W7 | | reserved, **must be 0** |

Internal `sfs_cmd_t` = 259 bits packed MSB-first `{opcode[8], addr_type[1], dir[2], flags[8], tid[16], addr[64], len[32], host_addr[64], aux[32], rsvd[32]}`. **Opcodes:** FLUSH `00h`, WRITE `01h`, READ `02h`, DEALLOCATE `09h` (TRIM), IDENTIFY `80h` (512 B to host buffer), GET_LOG `81h` (512 B), ERASE `90h` (PHYSICAL only, needs `SEC_CTRL.PHYS_EN`). Logical block = `NAND_PAGE_BYTES` = 512 B.

**CQ entry, 4 x 32 bit** (host reads at the CQ ring, advances `CQ_HEAD`; phase starts 1, flips at each wrap, cleared on controller reset): W0 RESULT0 (blocks transferred) · W1 RESULT1 (ECC bits corrected) · W2 `[15:0]` SQ head · W3 `[15:0]` TID, `[16]` phase, `[23:17]` status, `[31:24]` error. Internal `sfs_cpl_t` = 95 bits `{tid[16], status[7], err[8], result0[32], result1[32]}`.

**Status (`sfs_status_e`)**: SUCCESS 00, INVALID_OPCODE 01, INVALID_FIELD 02, CID_CONFLICT 03, DATA_XFER_ERR 04, ABORT_PWR_LOSS 05, INTERNAL_ERR 06, ABORT_RESET 07, LBA_RANGE 08, CAPACITY 09, ACCESS_DENIED 0A, MEDIA_UNREC 10, MEDIA_WRITE 11, MEDIA_ERASE 12, MEDIA_TIMEOUT 13.
**Error (`sfs_err_e`)**: NONE 00, HOST_ADDR 01, LEN_ZERO 02, LEN_MAX 03, ADDR_WIDTH 04, ADDR_TYPE 05, RSVD_FIELD 06, DMA_READ 07, DMA_WRITE 08, NAND_ECC_UE 09, NAND_FAIL 0A, NAND_TIMEOUT 0B, BUF_ECC_UE 0C, FW 0D, QUIESCED 0E, NOT_READY 0F, NAND_WP 10, NAND_BUS 11.
Hardware validation order (first hit wins): opcode supported; reserved bits; power-loss quiesce; controller resetting; address-type rules; PHYS_EN; ADDR width; LEN=0; LEN>MDTS; host buffer alignment/window; LBA range (ADDR+LEN <= capacity); TID conflict.
**IDENTIFY data (512 B words)**: w0 `0x53465354`, w1 proto ver, w2 HW ver, w3 FW ver (`0x00510100`), w4/5 capacity LBAs, w6 LBA bytes, w7 MDTS, w8 channels, w9 tags, w10 page bytes, w11 ECC|RAS<<1, w12 buffer bytes, w13 device ID0, w14 blocks, w15 pages/block, w16..23 model string, w24 CONFIG0, w25 CONFIG2, w26 security caps, w27 = 0 (no authentication). **GET_LOG**: w0 `0x474F4C53` "SLOG", w1 cmds done, w2 cmds errored, w3 FTL writes, w4 reads, w5 unmapped reads, w6/7 NAND CE/UE, w8/9 buf CE/UE, w10 PLP events, w11 ckpt seq, w12 ckpt count, w13 prog fails, w14 erase fails, w15 retired blocks, w16 mapped LBAs, w17.. perf counters, w25 RAS status, w26 fw errors, w27 sec status, w28 CQ-full cycles, w29 fabric stalls, w30 NAND busy cycles, w31 HIF CQ stalls.

### 5.5 `sfs_cmd_ctrl`  -  `rtl/sfs_cmd_ctrl.sv`

Parameters `CMD_QUEUE_DEPTH`=8, `ADDRESS_WIDTH`=32, `HBUF_ALIGN`=4 (= DW/8), `MDTS_RESET`=16. Ports: `clk, rst_n`; `cmd_valid/ready, cmd (sfs_cmd_t)` in; `cpl_valid/ready, cpl (sfs_cpl_t)` out; firmware page `rb_*` (12-bit offset); `phys_en, plp_quiesce, resetting` in; `capacity[63:0], mdts[15:0], outstanding_zero, irq_cmd, ev_fw_err, ev_lat_valid, ev_lat[31:0]` out. Handshake: valid held until ready; `valid` never depends on `ready`.
**Firmware page CMD (ControlCore page 11, `0x4000_B000`)**: `INFO`000, `FWQ_HEAD`004 (`[31]` VALID `[7:0]` tag), `FWQ_POP`008 (WO), `CPL_RESULT0/1`00C/010, `CPL_POST`014 (WO `[7:0]` tag `[14:8]` status `[23:16]` error), `STATUS`018 (W1C FW_ERR, CPL_DROPPED), `TAGS_BUSY`020, `MDTS`024 (reset 16), `CAP_LO/HI`028/02C, counters 030..040. The command body for a tag is read from the tag window (SQ-entry layout).

### 5.6 `sfs_dma`  -  `rtl/sfs_dma.sv`

Parameters `DW`=32, `QD`=4, `CD`=4. Ports: `clk, rst_n`; `rb_*` (12-bit); SFB2 master `m_req_*/m_rsp_*` (DW); `irq_dma, busy, ev_word, ev_err, ev_fw_err`. **Page DMA (page 12, `0x4000_C000`)**: `INFO`000, `STATUS`004, `CTRL`008 (`[0]` ABORT `[1]` CLR_OVF), `SRC`010, `DST`014 (fabric addresses, DW-aligned), `LEN`018 (bytes, multiple of DW/8), `SUBMIT`01C (WO tag), `CPL_HEAD`020 (`[31]` VALID `[23:16]` tag `[15:8]` DST_*), `CPL_INFO`024, `CPL_POP`028, `BYTES/DESCS/ERRORS`030..038. DST_*: OK 0, READ_ERR 1, WRITE_ERR 2, INVALID 3, ABORTED 4.

### 5.7 `sfs_nand_ctrl` (one per channel)  -  `rtl/sfs_nand_ctrl.sv`

Parameters `CH`, `CDW`=8, `DW`=32, `PAGE_BYTES`=512, `ENABLE_ECC`=1, `OQD`=4, `CQD`=4. Ports: `clk, rst_n`; `rb_*` (8-bit offset = 256-byte channel slice); SFB2 master to BUF; pins `nand_ce_n, nand_cle, nand_ale, nand_we_n, nand_re_n, nand_wp_n, nand_dq_o[CDW], nand_dq_oe, nand_dq_i[CDW], nand_rb_n`; `wp_force` (PLP); `irq, busy, ev_rd_page, ev_prog, ev_erase, ev_ce, ev_ue, ev_tmo, ev_fw_err`.
**Page NAND (page 13, `0x4000_D000 + 0x100*ch`)**: `CH_INFO`000, `CH_STATUS`004, `CH_CTRL`008 (`[0]` WP_N `[1]` CE_EN `[2]` IRQ_EN), `TIMING0`00C (reset `0x02020202`: tWP,tWH,tRP,tREH in cycles), `TIMING1`010 (tWHR/tADL, tWB), `TIMEOUT`014 (cycles), `OP_ROW`018, `OP_COL`01C, `OP_BUF`020 (buffer fabric address), `OP_LEN`024, `OP_SUBMIT`028 (WO: `[3:0]` op `[8]` ECC_EN `[23:16]` tag), `CPL_HEAD`02C (`[31]` VALID `[23:16]` tag `[15:8]` NST_* `[7:0]` NAND status), `CPL_INFO0/1`030/034, `CPL_POP`038, `Q_STATUS`03C, `STAT_*`040..04C.
**NAND ops (`SFS_NOP_*`)**: RESET 0 (FFh), READ_ID 1 (90h 00h, 5 bytes), READ_STATUS 2 (70h), READ_PAGE 3 (00h C1 C2 R1 R2 R3 30h, tR wait, data-out + ECC decode to buffer), PROGRAM 4 (80h addr, data in with ECC encode, 10h, tPROG, 70h), ERASE 5 (60h R1 R2 R3 D0h, tBERS, 70h). **NST_***: OK 0, CORRECTED 1, UNCORR 2, PROG_FAIL 3, ERASE_FAIL 4, TIMEOUT 5, BUS_ERR 6, INVALID 7, WP 8. Raw page on bus = user bytes x (1 + CDW/DW): each DW word is followed by one ECC beat (SECDED check bits; all-ones data+ECC = erased word, not decoded). Cycle-timed async SDR only (5-address-cycle, 8/16-bit); no NV-DDR/Toggle, no DQS, no ONFI parameter page, no multi-plane/cache/multi-LUN, no CE select beyond the one pin.

### 5.8 System page and the rest of the ControlCore-side map

SYS page 10 (`0x4000_A000`): `ID`000 (`0x53465354`), `HW_VERSION`004, `PROTO_VERSION`008, `MAP_VERSION`00C, `CONFIG0/1/2`010/014/018, `BUF_BASE`01C, `HOSTMEM_BASE/SIZE`020/024, `READY`030, `IRQ_STATUS`040, `IRQ_EN_IO/EVT`044/048, `PLP_STATUS/CTRL/EVENTS`050/054/058, `SEC_CTRL/STATUS`060/064, `RAS_STATUS/WARN_EN/FATAL_EN`070/074/078, ECC counters 07C..08C, `BUF_FI_*`090..098 (fault injection), `FAB_ERR_ADDR`09C, `PERF_*`0C0..0F0. HIF page 14 (`0x4000_E000`): `STATE`000, `CTRL`004 (`[0]` RDY `[1]` CFS `[3:2]` SHST), `EVT_STATUS/EN`008/00C, `DB_ERR_INFO`010, `CQ_STALLS`014. Pages 8, 9, 15 answer a bus error. Full bit-level text: `docs/MEMORY_MAP.md` (generated; I verified it is current with `make check-map`) and `sw/include/generated/sfs_map.h`.
Storage IRQs occupy ControlCore INTC slots **4 (TENSOR) = storage IO** and **5 (VECTOR) = storage EVENT**.

### 5.9 Firmware / boot contract

Boot (ControlCore ROM, `boot_mode_i`=HOST): host writes `sfs_fw.hex` (3581 words) into IMEM through the MGMT BAR window, writes `H2F_MSG0=IMAGE_READY`, rings the mailbox; ROM checks header and CRC32 and jumps to `0x0001_0100`. In my SoC run the image is written by cycle 302 448 and HOST READY is reached at cycle 638 219. Firmware image header: `mkimage.py ... --version 0x00510100 --name sfs_storagecore_fw`. Firmware reads real parameters from `SFS_SYS.CONFIG0..2`, so one image runs on all three configurations. Mailbox commands: PING, `0x51` SET_PHYS_EN, `0x52` STATS, SHUTDOWN. Tags `0x80|ch` (pre-erase), `0x90` (checkpoint), `0xA0` (boot) are firmware-internal. Buffer slot `t` (`0x2000_0000 + 512*t`) belongs to tag `t`; slot `tags` is the checkpoint page, slot `tags+1` is zeros.

---

## 6. Integration risks / incompatibilities

1. **Not a leaf block: it is a ControlCore SoC.** `silicaflux_storage_soc` instantiates `silicaflux_control_core` (RV32IM, 64 KiB IMEM / 32 KiB DMEM) and the storage firmware replaces the ControlCore application image. Storage blocks hang off ControlCore register pages 10..14 (pages 8, 9, 15 error), EXT window `0x2000_0000..0x3FFF_FFFF`, INTC slots 4/5 (named TENSOR/VECTOR in the ControlCore header), `acc_rst_no`, `ext_warn/ext_fatal`. If the integrated top already uses a ControlCore for accelerator control, there is a collision for pages, IRQ slots, EXT window and firmware image; you either dedicate a ControlCore instance to storage or re-home the register pages.
2. **Firmware load path is simulation-only.** The firmware image enters through the host BAR MGMT window (testbench `load_image()`); there is no SPI/flash/ROM boot source RTL, no key/auth (CRC32 only), and the host can reach the loader. A product needs a boot master and secure boot (P28 not integrated).
3. **Host interface is a private ABI on a private bus.** NVMe-inspired SQ/CQ with 32-byte SQE / 16-byte CQE in *controller* memory, 32-bit BAR, 32-bit host addresses inside a 256 MiB window, DW-aligned host buffers. It is not NVMe (P57 replaces the front end instead of using this one) and not AXI/PCIe. SFB2 allows one outstanding transaction per port, no bursts: about 1 DMA word / 4 cycles, so SoC bandwidth is a few MB/s (P57 measured 7-11 MB/s) and the 64-bit `research4ch` is fabric-bound.
4. **Width/protocol mismatches inside the family.** P51 SHC/BAR is 32-bit; `research4ch` uses a 64-bit fabric/DMA and `sfs_sfb_upsizer` (32-bit CPU writes into the 64-bit ECC SRAM become read-modify-write). P57 hard-wires a 32-bit window (`DW = 32`) and one channel, so `research4ch` cannot sit behind P57 without a wider window.
5. **Module-name collisions (verified by scanning all extracted projects).** `silicaflux_control_core`, `cc_memmap_pkg`, `sfv_bootrom_image` exist in a second, **different** version inside the secure-boot project (`x_secureboot/silicaflux-secureboot/rtl/`: 374 / 207 / 6307 lines of `diff` output respectively); two ControlCore variants cannot be compiled together. `sfv_clkgate` has four content variants (default behavioural ICG plus sky130/ihp_sg13g2/FPGA substitutions - intentional "same module name, same ports" target substitution; choose one per build). `sfb_crossbar` (40 copies) and `sram_generic_1rw` (51 copies) are byte-identical everywhere, so multi-project compiles are safe for those as long as only one copy is on the file list. Within P51 itself, `synth/yosys/sfs_rtl_yosys.sv` is a generated flattened duplicate of every `sfs_*` module (and package bodies) - exclude it from file lists.
6. **Global package/macro namespace.** Packages `sfs_map_pkg`, `silicaflux_storage_pkg` (plus `cc_memmap_pkg`, `mcu_memmap_pkg` from ControlCore) and include-file macros (`sram_defs.svh`, `sfras_defs.svh`, `SFS_CFG_*`, `SFS_MULTI`) are global; `files.f` relies on `+incdir+` ordering with the generated map first. The firmware reads values from `SFS_SYS.CONFIG*`, but the RTL parameters must still be changed consistently in the top.
7. **Yosys/SV tooling.** Yosys 0.33 has no SV `import`; the synth flow hoists the two package bodies into `$unit` scope in a generated copy. Any other flow (vendor FPGA, DC) will need packages supported natively. The RTL avoids `return`, `$bits(type)`, struct function args purely for Yosys 0.33.
8. **Clocking/reset conventions.** Single clock; async-assert/sync-release resets only inside ControlCore and the BAR splitter. The storage subsystem runs on ControlCore's accelerator-domain reset (`acc_rst_no`), so firmware/PMU resets it; a PCIe endpoint user clock would require CDC FIFOs at `sfs_host_if` and the `hm_*` port (not provided). ICG latch (`sfv_clkgate`) is in the ControlCore but its gated clock is unused here (`acc_clk_o` left open).
9. **Memory/IP dependencies.** All SRAMs (buffer, IMEM, DMEM, boot ROM image) use the generic flop/array backend. ASIC silicon needs sramlib macro backends (OpenRAM/foundry macros; commercial entries are "PENDING" placeholders that fail elaboration by design). The boot ROM is a generated RTL table (`sfv_bootrom_image.sv`, 6307 diff lines vs. the secure-boot variant), not a macro.
10. **Capacity/geometry.** Logical block fixed 512 B = page user size; 256 LBAs per channel; L2P in 32 KiB DMEM (16-bit entries); NAND geometry from a firmware table keyed on the READ_ID of the model (one entry). Larger/real flash needs FTL and DMEM redesign.
11. **Test-harness limits for CI.** Pass/fail only via printed verdict (exit status 0 regardless); default `make soc` C++ build is one 5 MB translation unit (about 6 min wall under load; consider `-MAKEFLAGS OPT_FAST=-O0` for CI).
12. **Self-written NAND model is the only media reference.** Any change in geometry/timing needs validation against a vendor model or silicon.

---

## 7. Licensing notes

* **No licence file anywhere** in P51 (README, PROVENANCE, third_party). `third_party/PROVENANCE.md`: "The repository contains no licence file; reuse here is within the same repository owner's project family." ControlCore's PROVENANCE_CC.md: "internal Aureom.AI sources. The owner must add a license before any external distribution." Treat all code as **all-rights-reserved / internal until the owner adds a licence**.
* No SPDX headers or copyright lines in any source (grep over `.sv/.c/.h/.py/.S/.ld/.md`).
* Third-party items referenced but **not bundled**: riscv-tests (BSD-licensed; fetched by the ControlCore script `scripts/run_riscv_tests.sh` into `deps/`, which is not shipped here). sramlib ASIC black boxes mention vendor models "(Apache-2.0 sources)" (SKY130 OpenRAM macros) - the black boxes carry port lists only; the vendor models are not included and a fetch script (`scripts/mem/fetch_open_macros.sh`) is referenced but not shipped in this subset. Commercial macros are "PENDING" placeholders (no licensed compiler output exists).
* No GPL/LGPL code was found in the shipped tree (grep for GPL/GNU/MIT/BSD/Apache returned only the above and "GNU-compiled C" / the `riscv64-unknown-elf-gcc` toolchain mention). The toolchain (GNU GCC) is used to **build** the firmware; the firmware links only `libgcc` (GCC runtime library exception applies); its own sources (`crt0.S`, `libc_min` subset in `platform.c`) are project-authored.
* Tools used in the flow: Verilator (LGPL-3.0/Artistic-2.0), Icarus Verilog (GPL-2.0, outputs unencumbered), Yosys (ISC), PyYAML (MIT).
