# Audit: Project 57 "NVMe HostCore" (silicaflux-nvme-hostcore)

Audited tree (pristine): `scratchpad/audit/p57_nvme/silicaflux-nvme-hostcore`
Working copy used for all runs: `scratchpad/work/p57/silicaflux-nvme-hostcore` (called `$W`)
Raw logs: `scratchpad/audit_out/p57/*.log` (each starts with `### CMD`, `### CWD`; ends with `### EXIT`, `### WALL_SECONDS`)
Auditor driver scripts (outside the project tree; they only load project code unmodified or mirror the Makefile): `scratchpad/audit_scripts/`, `scratchpad/p57_unit_O0.sh`, `scratchpad/p57_soc_build_O0.sh`, `scratchpad/runlog.sh`

Environment: Verilator 5.020 (Debian), Icarus 12.0, Yosys 0.33, Python 3.13. `gcc-riscv64-unknown-elf` 13.2 was installed from apt for the P51 half of this audit (log `../p51/00_apt_install_riscv.log`). The container is shared with other audit jobs: load average 12-32 on 4 cores throughout, so **all wall times are inflated 3-6x** and several default-flag builds hit the 8-minute cap (see Evidence log).

---

## 1. Summary verdict

P57 is a substantial, carefully tested **simulation-grade NVMe command front end** (about 3.5 kLOC RTL) bolted onto the unmodified P51 StorageCore/ControlCore SoC. Everything I re-ran reproduced exactly: the P51 firmware rebuilds to the identical image (CRC32 `f7d46dd3`); the unit testbench passes on all three configurations and all four seeds on Verilator (base 955, multi 1267, noext 891 checks each; 12/12 runs) and on Icarus (base seed 1: 955 checks); the full-SoC testbench with the real ControlCore CPU + P51 firmware/FTL/ECC/NAND model passes both scenarios (`dod` 49/49, `full` 335/335, 4,775,289 cycles, cycle-identical to the shipped log); Verilator `-Wall` is clean on all P57 RTL; and all 32 unit + 21 SoC performance lines are byte-identical to the shipped perf logs (deterministic cycle-accurate simulation). What it is **not**: there is **no PCIe** (the PCIe side is a self-written transaction-layer simulation model; no endpoint IP, no link/PHY/data-link/credits/config-space RTL), it is **not NVMe-conformant** (documented subset: no SGL, no MSI-X, 2 features, SMART fields read 0, VID `FFFEh` placeholder), the spec text was never available to the author, no OS driver (Linux/QEMU) was ever used, back-end throughput is 7-11 MB/s (one NAND channel, firmware FTL, SFB2 single-outstanding DMA), the integrated top `silicaflux_nvme_ssd` has **never been synthesized** (only the NVMe front end alone was), the front end is large (about 56 k LUT4 on ECP5 per the project's own estimate, 60 % of flip-flops in window buffers Yosys did not map to RAM), and every performance figure is simulation cycles at an assumed clock (250 MHz front end / 100 MHz SoC) with no timing analysis behind the clock. The SoC inherits P51's integration constraints (ControlCore-centred, single NAND channel in this composition, 256 LBAs).

Legend: **V** = Verified by me (command + result in Evidence log); **PV** = partially verified by me; **I** = implemented but not re-run by me; **M** = missing; **X** = incompatible with a single integrated top as shipped; **S** = simulation-only; **E** = external-IP-dependent.

---

## 2. Classification table

| # | Function / feature | Implemented | Verified (by ME) | Partially verified | Missing | Incompatible | Simulation-only | External-IP-dep. | Primary | Note |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | NVMe controller registers (CAP, VS, INTMS/MC, CC, CSTS, AQA, ASQ, ACQ) + doorbells, enable/disable/reset/FLR/shutdown state machine (`sfn_regs`, controller) | x | x | | | | | | **V** | Unit groups `regs`, `enable`, `reset`, `flr`, `shutdown` pass in all 3 configs (Ev 3-8,16). Encodings spot-checked by me against the NVMe base spec as I know it (opcodes, SC/SCT values, CC mask `00FF_FFF1`, CSTS, AQA, doorbell stride); not a conformance review. |
| 2 | SQ/CQ management: phase tag, wrap, SQHD, CQ-full hold, doorbell validation, up to 8 I/O pairs (`sfn_queue_mgr`) | x | x | | | | | | **V** | Unit `wrap`, `random`, `queues`; SoC `wrap`. `multi` (4 pairs, shared CQ) 1267 checks pass. |
| 3 | Command fetch (round robin, 64 B SQE, 4 in flight) and decode (opcode/FUSE/PSDT/NSID/MDTS/LBA-range/CID checks) | x | x | | | | | | **V** | Unit `invalid`, `io`; SoC `errors`. |
| 4 | PRP data pointers: lists, chaining, offset checks, 4 KiB pages | x | x | | | | | | **V** | Unit `prp` (10 layouts + errors); SoC `prp`. |
| 5 | SGL data pointers | | | | x | | | | **M** | PSDT != 0 -> Invalid Field; Identify SGLS = 0. |
| 6 | Admin commands: Identify (CNS 0/1/2/3), Create/Delete I/O SQ/CQ, Get Log Page (01h, 02h, 03h, C0h) | x | x | | | | | | **V** | Unit `identify`, `queues`, `logs`. |
| 7 | Admin phase 2: Set/Get Features (FID 07h, 06h only), Abort (always "not aborted"), AER (error events only) | x | x | | | | | | **V** | Unit `ext` group; `noext` config (891 checks) rejects them. 8 mandatory features absent -> not conformant. |
| 8 | NVM commands Read / Write (+FUA) / Flush | x | x | | | | | | **V** | Unit `io`, `random`; SoC DoD + `random` (80 cmds, 8 in flight). Dataset Mgmt, Write Zeroes, Compare etc. absent (ONCS = 0). |
| 9 | Interrupts: pin-based INTx and MSI (single/multiple message), INTMS/INTMC | x | x | | | | | | **V** | Unit `irq`. |
| 10 | MSI-X, interrupt coalescing, SMART/health measurement | | | | x | | | | **M** | SMART fields (temp, spare, wear, power cycles, unsafe shutdowns) read 0. |
| 11 | PCIe endpoint adapter RTL (`sfn_ep_adapter`: completer BAR0 MMIO, requester with tags / MPS / MRRS / 4 KiB split / reassembly / timeout) | x | | x | | | | | **PV** | Passes against the project's own TL model with a TLP rule checker (0 violations in my runs); never connected to real hard IP. Vendor mapping (Xilinx CQ/CC/RQ/RC, Intel Avalon-ST) is tabulated, "none instantiated, compiled or simulated". |
| 12 | Physical PCIe: PHY, link training, DLL, credits, config space, endpoint IP, class code/IDs | | | | x | | | x | **M** | Needs vendor endpoint IP (+ SERDES). VID/SSVID `FFFEh`, SN, NQN are placeholders. |
| 13 | PCIe transport simulation model (`tb/common/sfn_tb_pcie_host.sv`) and NVMe host driver (`sfn_tb_nvme_driver.svh`) | x | x | | | | x | | **S** | Testbench code (`initial`, `#`, fork/join); host memory 4 MiB + IOMMU model. Not synthesizable by design. |
| 14 | Host-memory window `sfn_hostwin` (PRP translation, streaming prefetch 1 KiB, 2 x 256 B write combining, ordering vs CQE) | x | x | | | | | | **V** | Unit `dma`/`prp`/`io`, SoC all data tests; mutants `prefetch_bound`, `cqe_before_data` catch regressions (project claim). Deviates from SFB2 rule R7 (posted-write ack) on this port only. |
| 15 | P51 back end behind NVMe (`sfn_storage_backend` + unmodified ControlCore + firmware FTL + ECC + NAND model) | x | x | | | | | | **V** | SoC `dod` 49/49 and `full` 335/335 (Ev 9,10). |
| 16 | Persistence contract (VWC = 1; Flush/FUA/shutdown/power-loss warning -> FTL checkpoint; unflushed data lost on abrupt cut) | x | x | | | | | | **V** | SoC `power`, `shutdown` pass (both power-cycle flavours with firmware reboot). |
| 17 | Garbage collection / wear levelling / P56 FlashMap FTL in the command firmware | | | | x | | | | **M** | 256 LBAs (128 KiB), about 1000 page writes per channel before Capacity Exceeded. |
| 18 | Multi-channel NAND (P51 `research4ch`) behind NVMe | | | | | x | | | **X** | `silicaflux_nvme_ssd` hard-wires `DW = 32` and the window is 32-bit; only 1 channel is tested. |
| 19 | Verilator `-Wall` lint (6 parameter sets + SoC), illegal parameters rejected | x | x | | | | | | **V** | 0 warnings in P57 files; 358 in unmodified vendored files (not suppressed). 15 scoped `lint_off` pragma lines in P57 RTL (6 of them in `sfn_storage_backend.sv`). (Ev 11) |
| 20 | Yosys synthesis (generic + ECP5) of the NVMe front end, 3 parameter sets | x | | x | | | | | **PV** | See Ev 12-13: SYNTHESIS_RESULT_PLACEHOLDER |
| 21 | Synthesis / P&R of the integrated top `silicaflux_nvme_ssd` or of the SoC | | | | x | | | | **M** | `scripts/synth.py` synthesizes only `silicaflux_nvme_controller` (README table says so in the footnote: "the P51 back end and the ControlCore were synthesised by their own projects"). The composition `sfn_storage_backend` + `sfn_hif_regs` + `sfn_hostwin` has no synth result. |
| 22 | Timing closure at the assumed clocks (250 MHz front end, 100 MHz SoC) / FPGA board | | | | x | | | | **M** | No SDC, no P&R, no board. All MB/s and IOPS figures use these assumed clocks. |
| 23 | Mutation check (16 planted bugs, claimed 15/16 killed) | x | | x | | | | | **PV** | MUTATION_RESULT_PLACEHOLDER |
| 24 | Performance sweeps (unit + SoC) | x | x | | | | x | | **V** | `+perf` unit: 32/32 PERF lines identical; SoC: 21/21 identical (Ev 14,15). Valid as simulation cycle counts only. |
| 25 | NVMe conformance suites (UNH-IOL etc.), Linux `nvme` driver, QEMU co-sim | | | | x | | | x | **M** | Not available (licensed / need hardware). NVMe spec text was **not** available to the author. |
| 26 | Vendored P51 sources unmodified | x | x | | | | | | **V** | 103 files: manifest 103/103 OK; `diff -rq` against the P51 tree: 0 differences (rtl, third_party, firmware/app, sw, tb/models). The "vs archive in Aureom.AI" check was not run (repo off-limits). |
| 27 | Firmware build (unmodified P51 firmware) | x | x | | | | | | **V** | `make fw`: image 14324 B, CRC32 `0xf7d46dd3`; `sfs_fw.hex` byte-identical to the one I built in P51. |
| 28 | Exit-code based CI | | | | x | | | | **M** | Testbenches `$finish` on pass and on fail; `make unit/soc` return 0 regardless. Success = printed verdict line (the regress/mutate scripts parse it). |

---

## 3. Evidence log

All commands in `$W` unless noted. "-O0" rows are the **same Verilator command as the Makefile rule** except `-MAKEFLAGS OPT_FAST=-O0` (default P57 uses `OPT_FAST=-O1`) and a different `-Mdir`, used only because the single giant `DepSet__0.cpp` compile did not finish in 8 minutes under the load. RTL/TB/firmware/defines unchanged.

| Ev | Command | Exit | Wall | Key output |
|---|---|---|---|---|
| 1 | `make fw` (`01_fw.log`) | 0 | 3 s | `mkimage: ... sfs_fw.img 14324 B (21% of IMEM) entry 0x00010100 crc32 0xf7d46dd3`; `cmp` with P51-built `sfs_fw.hex`: identical |
| 2 | `make unit CFG=base SEED=1` (default flags, `02_unit_base_seed1.log`) | 124 | 480 s | **did not complete** (8-min cap; stuck compiling `Vtb_nvme_ctrl___024root__DepSet_*__0.o` under load 29) |
| 3 | Verilator unit TB, -O0: `p57_unit_O0.sh $W` (base, seed 1; `03_*.log`) | 0 | 237 s | `tb_nvme_ctrl NIOQ=1 EXT=1 seed=1: 955 checks, 0 failures, 659980 cycles -> PASS` |
| 4 | same, `p57_unit_cfg_O0.sh $W multi` (`09_*.log`) | 0 | 180 s | `NIOQ=4 EXT=1 seed=1: 1267 checks, 0 failures, 673244 cycles -> PASS` |
| 5 | same, `noext` (`12_*.log`) | 0 | 198 s | `NIOQ=1 EXT=0 seed=1: 891 checks, 0 failures, 680535 cycles -> PASS` |
| 6 | `p57_seeds.sh $W` = seeds 2,3,4 on the three -O0 binaries (`18_*.log`) | 0 | 199 s | 9/9 `PASS`: base 955 checks, multi 1267, noext 891, 0 failures; cycle counts equal to shipped regression table |
| 7 | `make unit-iv CFG=base SEED=1` (Icarus; `16_*.log`) | 0 | 375 s | `tb_nvme_ctrl NIOQ=1 EXT=1 seed=1: 955 checks, 0 failures, 617624 cycles -> PASS` (cycles identical to shipped Icarus run) |
| 8 | SoC build, -O0: `p57_soc_build_O0.sh $W` (`04_*.log`) | 0 | 117 s | `build/v_soc_O0/Vtb` built (same sources as Makefile `build/v_soc/Vtb`) |
| 9 | `./build/v_soc_O0/Vtb +scenario=dod +fw=build/fw/sfs_fw.hex` (`05_*.log`) | 0 | 37 s | `TB DoD: simulated NVMe host initialised the controller, wrote, read and flushed blocks ... -- MET`; **`tb_nvme_ssd dod: 49 checks, 0 failures, 838645 cycles -> PASS`** |
| 10 | `./build/v_soc_O0/Vtb +scenario=full +fw=build/fw/sfs_fw.hex` (`06_*.log`) | 0 | 282 s | `firmware HOST READY at cycle 645398 ... checkpoint seq 0`; re-boots after the two power cycles (checkpoint seq 23, 24); **`tb_nvme_ssd full: 335 checks, 0 failures, 4775289 cycles -> PASS`** (includes `firmware TEST_CTRL done`, `firmware verdict (no firmware errors)`, `PCIe TLP rule violations = 0`, `IOMMU faults = 0`). Note: console echo of firmware (`FW|` lines) needs `+con`; I did not use it, verdicts are checks inside the 335 |
| 11 | `make lint` (`07_lint.log`) | 0 | 17 s | 6 parameter sets: 0 warnings each; SoC: 0 in P57 files / 358 in vendored; 6 illegal parameter sets rejected by Verilator and Icarus; Icarus elaborates `silicaflux_nvme_controller` and `silicaflux_nvme_ssd`; `Overall: clean` |
| 12 | `make synth` (all 6 rows; `08_synth.log`) | 2 | 12 s | **aborted by me** after 12 s (I terminated it: generic+ECP5 x 3 configs + hierarchy run = about 40 min unloaded per shipped timings: 198 s, 449 s, 203 s, 428 s, 310 s, 834 s) |
| 13 | `python3 -B $SP/audit_scripts/p57_synth_one.py $W base generic` (calls the project's own `scripts/synth.py` `flat()/script()/stat()`; `08b_*.log`, retry `17_*.log`) | 124 / see below | 480 s / see below | SYNTH_EV_PLACEHOLDER |
| 14 | `./build/v_unit_base_O0/Vtb +perf` (`13_*.log`) | 0 | 216 s | 32 `PERF` lines; `diff` against shipped `reports/perf/perf_unit.log` PERF lines: **0 differences** |
| 15 | `./build/v_soc_O0/Vtb +perf +fw=build/fw/sfs_fw.hex` (`14_*.log`) | 0 | 387 s | 21 `PERF soc` lines; `diff` vs shipped `perf_soc.log`: **0 differences**; e.g. `read 512 B QD1: lat_avg=7835.9 cycles (78 us at 100 MHz)`, `flush QD1: 40888 cycles/cmd`; `tb_nvme_ssd full: 19 checks, 0 failures, 8368659 cycles -> PASS` |
| 16 | `python3 -B scripts/check_vendor.py` (manifest only; `10_*.log`) | 0 | 0 s | `manifest: 103 / 103 files match third_party/SHA256SUMS` |
| 17 | `diff -rq` P51 tree vs `third_party/silicaflux-storagecore-p51/{rtl,third_party,firmware/app,sw,tb/models}` (`11_*.log`) | 0 | 0 s | 0 differing/missing files (103 files vendored) |
| 18 | Mutation: `scripts/mutate_O0.py -j 2 --only cq_phase,fua_dropped` (copy of `scripts/mutate.py` with `OPT_FAST=-O0`; `15_*.log`) | MUT_EXIT | MUT_WALL | MUT_RESULT |

Cross-check against P51 (same container): `./build/v_soc_min1ch/Vtb +scenario=dod` on P51 gives `30 checks, 0 failures, 825162 cycles -> PASS` (`../p51/20_soc_min1ch_dod.log`) = the figure quoted in P57 `docs/00_AUDIT.md`.

Not run (and why): `make regress`, `make mutation` (full 16 mutants), `make synth` (all rows), `make perf` as one command (time-box; constituents run, see above); `make vendor-check REPO=` against the Aureom.AI archive (repository off-limits); no PCIe/NVMe conformance suite (none available); no OS/QEMU co-simulation (none exists in the project).

---

## 4. Doc claims NOT reproduced / not substantiated

| Claim (where) | Status |
|---|---|
| "103 / 103 vendored P51/ControlCore files byte-identical to the repository archive" (README) | Only the local manifest (103/103) and equality with the P51 tree were verified by me, not the archive. |
| "Unit testbench: 15/15 runs (3 cfg x 4 seeds Verilator + 1 Icarus each)" | Reproduced 12 Verilator runs and 1 Icarus run (base). Icarus `multi` and `noext` (137-145 s unloaded each) not re-run. |
| "Mutation: 15/16 killed; survivor `tlp_4k_cross` is equivalent" | MUTATION_CLAIM_PLACEHOLDER |
| "Synthesis: 6/6 ok, `check -assert` clean, base about 55.8 k LUT4 + 24.8 k FF + 2 DP16KD on ECP5" | SYNTH_CLAIM_PLACEHOLDER. Scope caveat: front end only (`silicaflux_nvme_controller`); not the SoC top, not the back end. "0 latches" is checked in the script's output table but `check -assert` itself does not flag latches. |
| Performance: "950 / 655 MB/s read/write 32 KiB, 6.85 M commands/s (flush QD 8), 3.8 B/cycle" (README, docs/09) | The cycle counts reproduce exactly. The **MB/s and IOPS are conversions at an assumed 250 MHz** clock; no timing analysis, SDC or P&R supports 250 MHz (the front end alone is about 56 k LUT4 / 25 k FF on ECP5 by the project's own estimate). Treat as cycles, not hardware throughput. SoC figures (7-11 MB/s) assume 100 MHz. |
| "Build takes 0.5-2 min; SoC full scenario about 15 s" (README) | Wall times not comparable (shared machine at load 12-32; I used `-O0`): SoC full 282 s, dod 37 s here. Cycle counts match exactly. |
| NVMe register/command encodings "written from the published specifications as known to the author" (docs/00, docs/10 sec. 3) | No spec text was available to the author, and none to me; my spot-check (opcodes, SC/SCT numbers, CC/CSTS/AQA layouts, doorbell offsets, VS 1.4.0 = `0x00010400`) agreed, but encodings are **not independently verified**. Zero conformance or real-driver testing. |
| "P51 baseline re-run: SoC testbench built in 2 min 43 s, 30 checks, 825 162 cycles" (docs/00) | Check count and cycle count reproduced (P51 `dod`, Ev cross-check); build time not comparable. |
| Identify VER = 1.4.0 while docs reference NVMe 2.x | Self-acknowledged compatibility compromise, not a claim of conformance. |
| FPGA/board/hardware | No claim, none exists. |

---

## 5. Reusable interface reference

Buses used: **SFN-TL** (private 32-bit transaction-layer interface to a PCIe endpoint, below), **SFB2** (DataFabric: `req_valid/ready/write/addr[31:0]/wdata/wstrb`, `rsp_valid/ready/rdata/error`, one outstanding transaction per port, DW-aligned, little-endian) for the window, management and back-end ports, and P51's `sfs_cmd_t` / `sfs_cpl_t` ready/valid channels. One clock `clk` (simulated as the PCIe user clock; 250 MHz front end / 100 MHz SoC are assumptions). Reset `rst_n` is active-low and used as an asynchronous-assert reset in the flops (`always_ff @(posedge clk or negedge rst_n)`); the SoC top drives it from `sfv_rst_sync` (async assert, sync release). P51 uses the same style.

### 5.1 `silicaflux_nvme_controller` (NVMe front end)  -  `rtl/silicaflux_nvme_controller.sv`

Packages: `silicaflux_nvme_pkg`, `silicaflux_storage_pkg` (P51), `sfs_map_pkg` (P51 map package, needed for the protocol package).
Parameters (default): `NUM_IOQ`=1 (1..8 I/O queue pairs), `NCTX`=8 (commands in flight, pow2 2..32; **in the SoC = P51 tags = `CMD_QUEUE_DEPTH`**), `MQES`=1023 (CAP.MQES, 0's based), `NUM_VEC`=8 (1..32), `MAX_XFER_LOG2`=15 (13..17; transfer limit 32 KiB; SoC uses 13 = 8 KiB), `NTAG`=8 / `RSLOT_BYTES`=512 (non-posted read tags / reassembly per tag), `MPS_CAP`=256, `CPL_TIMEOUT`=65536 cycles, `PF_BYTES`=1024 / `PF_CHUNK`=256 / `PF_INF`=4 (window read-ahead), `WC_BYTES`=256 / `WC_IDLE`=16 (write combining), `FETCH_OUT`=4, `ENABLE_EXT_ADMIN`=1 (Set/Get Features, Abort, AER), `NERR`=4, `AERL`=1, `CAP_TO`=15 (500 ms units), `BUSY_CYC_PER_MIN`=6,000,000,000, `PCI_VID`/`PCI_SSVID`=`FFFEh` (**placeholders**). Illegal values `$fatal` at elaboration (guarded `ifndef SYNTHESIS`).

| Port group | Dir | Width | Meaning |
|---|---|---|---|
| `clk`, `rst_n` | in | 1 | clock, reset (everything) |
| **Completer request `cq_*`** (host -> device MMIO) | in | `cq_valid/ready`, `cq_write`, `cq_bar[2:0]`, `cq_addr[63:0]`, `cq_len_dw[10:0]`, `cq_first_be/last_be[3:0]`, `cq_tag[7:0]`, `cq_req_id[15:0]`, `cq_data[31:0]`, `cq_last` | one TLP = header held constant + 32-bit beats, `last` marks the final beat. BAR0 only (16 KiB, 64-bit non-prefetchable); other BAR -> UR |
| **Completer completion `cc_*`** (device -> host) | out | `cc_valid/ready`, `cc_tag[7:0]`, `cc_req_id[15:0]`, `cc_status[2:0]` (000 SC, 001 UR, 100 CA), `cc_byte_count[12:0]`, `cc_lower_addr[6:0]`, `cc_len_dw[10:0]`, `cc_data[31:0]`, `cc_last` | MMIO read data. 1-2 DW reads served; longer -> CA |
| **Requester request `rq_*`** (device -> host DMA) | out | `rq_valid/ready`, `rq_write`, `rq_addr[63:0]`, `rq_len_dw[10:0]`, `rq_first_be/last_be[3:0]`, `rq_tag[7:0]`, `rq_data[31:0]`, `rq_last` | SQE / PRP-list / data reads (<= MRRS, tag per read), CQE / data / (MSI path separate) writes (<= MPS, never crossing 4 KiB). Not emitted with BME = 0 |
| **Requester completion `rc_*`** | in | `rc_valid`, `rc_ready` (out, always 1), `rc_tag[7:0]`, `rc_status[2:0]`, `rc_byte_count[12:0]`, `rc_lower_addr[6:0]`, `rc_len_dw[10:0]`, `rc_data[31:0]`, `rc_last` | read data; RCB-split and cross-tag interleaved completions handled; per-tag reassembly buffer |
| Endpoint config `cfg_*` | in | `cfg_bme`, `cfg_mps[2:0]`, `cfg_mrrs[2:0]`, `cfg_msi_en`, `cfg_msi_mme[2:0]`, `cfg_intx_dis`, `cfg_flr` (pulse) | exported by the endpoint |
| Interrupts | out/in | `msi_valid` / `msi_ready`, `msi_vector[4:0]`, `intx_assert` | MSI must be emitted after earlier accepted posted writes (requirement E4) |
| **Back end** `be_cmd_*` | out | `be_cmd_valid`, `be_cmd_ready` (in), `be_cmd` (`sfs_cmd_t`, 259 b) | one P51 command per Read/Write/Flush |
| `be_cpl_*` | in | `be_cpl_valid`, `be_cpl_ready` (out), `be_cpl` (`sfs_cpl_t`, 95 b) | completion with echoed TID |
| back-end state in | in | `be_capacity[63:0]` (512 B blocks), `be_mdts[15:0]` (blocks), `be_idle`, `be_rdy`, `be_shst[1:0]`, `be_cfs` | published by firmware |
| front-end state out | out | `fe_en`, `fe_shn`, `fe_resetting`, `fe_reset_done` (pulse), `fe_db_err` (pulse) | drive the P51 HIF page (`sfn_hif_regs`) |
| **Host-memory window `hw_*`** | in/out | SFB2 slave, 32-bit: `hw_req_valid/ready/write`, `hw_req_addr[31:0]`, `hw_req_wdata[31:0]`, `hw_req_wstrb[3:0]`, `hw_rsp_valid/ready`, `hw_rsp_rdata[31:0]`, `hw_rsp_error` | the back end's DMA master. Address = `context << 20 + byte offset` (1 MiB slot per command context); posted-write response is given on buffering (documented deviation from SFB2 R7) |
| status | out | `dbg_state[2:0]`, `perf[32*32-1:0]` | 32 x 32-bit performance counters (also vendor log page C0h) |

### 5.2 `silicaflux_nvme_ssd` (SoC top)  -  `rtl/soc/silicaflux_nvme_ssd.sv`

Parameters: `NUM_IOQ`=1, `NUM_VEC`=8, `CPL_TIMEOUT`=65536, `ENABLE_EXT_ADMIN`=1, then P51's `NUM_NAND_CHANNELS`=1, `CHANNEL_DATA_WIDTH`=8, `BUFFER_SIZE_BYTES`=16384, `ADDRESS_WIDTH`=32, `CMD_QUEUE_DEPTH`=8, `ENABLE_ECC`=1, `ENABLE_RAS`=1, `NAND_PAGE_BYTES`=512, `SRAM_BACKEND`; `DW` is a **localparam = 32**. Ports: `clk`, `rst_ni` (power-on, whole device), **`ep_rst_ni`** (endpoint user reset: hot reset/link down; resets the front end only), `test_mode`, `boot_mode_i[1:0]`, `pwr_fail_ni`; SFN-TL `cq_*`, `cc_*`, `rq_*`, `rc_*`, `cfg_*`, `msi_*`, `intx_assert` exactly as 5.1; **management/boot port `mg_*`** (SFB2 slave 32-bit into the ControlCore host port through a management gate; *not reachable through PCIe*; used to load the firmware image and for the mailbox; no SPI/flash loader RTL); `mgmt_irq_o`, `host_ready_o`, `cmdproc_ready_o`, `ras_fatal_o`; NAND pins `nand_ce_n/cle/ale/we_n/re_n/wp_n[NCH]`, `nand_dq_o/oe/i`, `nand_rb_n` (as P51); diagnostics `diag_valid_o`, `diag_char_o[7:0]`, `test_done_o`, `test_fail_o`, `test_code_o[15:0]`, `cpu_sleep_o`; `nvme_state_o[2:0]`, `nvme_perf_o[1023:0]`.
Composition: `sfn_storage_backend` (copy of P51 `sfs_storage_subsys` with `sfs_host_if` removed; about 77 changed lines versus the vendored original, verified by `diff`) + `sfn_hif_regs` (register-compatible replacement of P51's HIF firmware page driven by `fe_*`, so the P51 firmware runs unmodified) + unmodified `silicaflux_control_core` (MIMPID `0x0057_0001`, `host_rst_req_i` tied 0) + `silicaflux_nvme_controller` (`NCTX = CMD_QUEUE_DEPTH`, `MAX_XFER_LOG2` = 13). `fe_cq_stall` into the back end is tied 0 (P51 CQ-stall counters unused).

### 5.3 BAR0 register map (NVMe controller registers; 16 KiB, offsets in bytes, DSTRD = 0)

| Offset | Reg | Value / meaning |
|---|---|---|
| `0x000` / `0x004` | CAP lo/hi | MQES = `MQES`; CQR = 1; AMS = 00b; TO = `CAP_TO`; DSTRD = 0; NSSRS = 0; CSS = `0000_0001b`; MPSMIN = MPSMAX = 0 (4 KiB pages only) |
| `0x008` | VS | `0x0001_0400` (1.4.0; not a conformance claim) |
| `0x00C` / `0x010` | INTMS / INTMC | per-vector mask set/clear (bits >= `NUM_VEC` read 0) |
| `0x014` | CC | writable mask `0x00FF_FFF1`: EN[0], CSS[6:4] = 0, MPS[10:7] = 0, AMS[13:11] = 0, SHN[15:14], IOSQES[19:16] (must be 6), IOCQES[23:20] (must be 4) |
| `0x01C` | CSTS | RDY[0] (raised by P51 firmware via HIF), CFS[1], SHST[3:2] (from back end) |
| `0x020` | NSSR | reserved (no subsystem reset) |
| `0x024` | AQA | mask `0x0FFF_0FFF`; zero sizes -> CFS at enable |
| `0x028`/`0x02C`, `0x030`/`0x034` | ASQ, ACQ | base [63:12]; queue wrap past 2^64 -> CFS |
| `0x038`..`0xFFF` | CMB/PMR/BP... | read 0, writes ignored |
| `0x1000 + 8y` / `0x1004 + 8y` | SQyTDBL / CQyHDBL | write-only; invalid value (queue absent, value[31:16] != 0, > size-1, head passing posted tail) ignored, raises AER (AEI 01h/02h) and `fe_db_err` |

BAR0 sizing in the sim transport: config offsets 10h/14h return `FFFFC004h` for a 16 KiB 64-bit BAR. Bring-up order used by the testbench driver: enumerate (class code 01 08 02), size/assign BAR (64-bit, above 4 GiB), set MPS/MRRS, enable MSE/BME, program MSI or INTx, CC.EN = 0 (wait RDY = 0), AQA/ASQ/ACQ, CC (IOSQES 6, IOCQES 4, EN), wait RDY, Identify, (Set Features Number of Queues), Create I/O CQ then SQ.

### 5.4 Command formats and status

Standard 64-byte SQE (host memory, physically contiguous queues, CQR = 1, entry sizes SQES = 66h / CQES = 44h) and 16-byte CQE (`DW0` command specific, `DW1` 0, `DW2` {SQID, SQHD}, `DW3` {DNR, M = 0, CRD = 00, SCT, SC, P, CID} = `cqe_dw3()` in `silicaflux_nvme_pkg`). Status encoded internally as 12 bits `{DNR, SCT[2:0], SC[7:0]}`.

| Admin opcode | Command | Notes |
|---|---|---|
| 00h / 04h | Delete I/O SQ / CQ | CQ in use -> `1/0C` |
| 01h / 05h | Create I/O SQ / CQ | QID 1..`NUM_IOQ`; CC.IOSQES = 6 / IOCQES = 4; PC must be 1; QPRIO ignored; IV >= `NUM_VEC` -> `1/08` |
| 02h | Get Log Page | LID 01h Error (NERR x 64 B), 02h SMART (512 B, mostly zero), 03h FW slot, C0h vendor perf (32 counters) |
| 06h | Identify | CNS 00h (NS 1), 01h (controller), 02h, 03h (empty); 4096 B via PRP1/PRP2 |
| 08h / 09h / 0Ah / 0Ch | Abort / Set Features / Get Features / AER | phase 2; FID 07h (Number of Queues), 06h (VWC; WCE = 0 forces FUA on every write) |

| NVM opcode | Command | Mapping to P51 `sfs_cmd_t` |
|---|---|---|
| 02h Read | NSID = 1, DTYPE = 0, PSDT = 0 | `opcode = SFS_OP_READ (02h)`, `addr_type = LOGICAL`, `dir = TO_HOST`, `addr = {CDW11, CDW10}` (SLBA), `len = (CDW12 & 0xFFFF) + 1` blocks of 512 B, `host_addr = context << 20`, `tid = {generation[7:0], context[7:0]}` |
| 01h Write | same; FUA = CDW12 bit 30 | `SFS_OP_WRITE (01h)`, `dir = FROM_HOST`, `flags[1] = FUA or !VWC.WCE`, rest as Read |
| 00h Flush | NSID 1 or FFFFFFFFh | `SFS_OP_FLUSH (00h)` -> FTL checkpoint |

Front-end checks (before the back end): FUSE != 0 -> `0/02`; PSDT != 0 -> `0/02`; CID in flight on the same SQ -> `0/03`; NSID != 1 -> `0/0B`; SLBA + NLB + 1 > NSZE -> `0/80` (65-bit compare); transfer > MDTS (SoC: 8 KiB) -> `0/02`; PRP1 bits[1:0] != 0, PRP2 not page/QW aligned or any list entry not page aligned -> `0/13`. **P51 status -> NVMe status**: SUCCESS -> `0/00`; INVALID_FIELD -> `0/02` DNR; DATA_XFER_ERR -> `0/04`; ABORT_PWR_LOSS -> `0/05`; LBA_RANGE -> `0/80` DNR; CAPACITY -> `0/81` DNR; ACCESS_DENIED -> `2/86` DNR; MEDIA_UNREC -> `2/81` DNR; MEDIA_WRITE/ERASE -> `2/80` DNR; MEDIA_TIMEOUT -> `2/81` (Read) / `2/80`; other -> `0/06`. Stale completions (generation mismatch / reset) are dropped and counted (log C0h counter 27).
Identify values: MDTS = log2(min(front end, back end)/4 KiB) (P51: 1 = 8 KiB), NN = 1, NSZE = NCAP = NUSE = back-end capacity (256 blocks), LBADS = 9, VWC = 07h, SQES 66h, CQES 44h, ONCS = 0, OACS = 0, SGLS = 0, SN `SFP57-SIM-0000000001`, MN `SilicaFlux NVMe HostCore P57 (sim)`, FR `P57-0100`, SUBNQN `nqn.2026-11.ai.aureom:silicaflux-p57:sim-00001` (all placeholders).

### 5.5 `sfn_hostwin`, `sfn_hif_regs`, `sfn_storage_backend`

* `sfn_hostwin` (parameters `CW`, `WIN_LOG2`=20, `XLW`, `PW`, `PF_BYTES`, `PF_CHUNK`, `PF_INF`, `WC_BYTES`, `WC_IDLE`): SFB2 slave `s_*` (32-bit), combinational context lookup ports `lk_*`/`lk2_*` (slot, page, ok, direction, length, PRP1 offset, host page address), DMA read request `rd_req_{valid,ready,addr[63:0],len[12:0]}` + data `rd_rsp_{valid,data,err,last}` (in request order), DMA write `wr_{valid,ready,addr,len,data,last}`, control `flush_req, kill, inval_v, inval_slot`, status `wc_empty, idle, ev_*`. Translation: `host_addr = PRPtable[ctx][(PRP1[11:0] + off) >> 12] + ((PRP1[11:0] + off)[11:0])`; accesses outside the command's length, wrong direction, or for contexts not owned by the back end answer `rsp_error` with no host effect.
* `sfn_hif_regs` ports: `clk, rst_n`, firmware page `rb_sel/we/addr[11:0]/wdata/rdata/err`, `irq_hif`, in `fe_en, fe_shn, fe_resetting, fe_reset_done, fe_db_err, fe_db_info[15:0], cq_stall`, out `rdy_o, cfs_o, shst_o[1:0]`. It reproduces P51's HIF page (`STATE`, `CTRL`, `EVT_STATUS` W1C, `EVT_EN`, `DB_ERR_INFO`, `CQ_STALLS`); queue-pointer fields in `STATE` read 0.
* `sfn_storage_backend` ports: P51 `sfs_storage_subsys` minus `s_*`/`host_irq`; plus `cmd_*`/`cpl_*` channels, `capacity`, `mdts`, `outstanding_zero`, `fe_*`, `be_rdy`, `be_cfs`, `be_shst`. Firmware pages 10..14 on `rb_*`; `hm_*` (DW = 32) master to the window.
* Firmware handshake: `fe_en` rising -> HIF EN_RISE -> firmware raises RDY (= CSTS.RDY). `fe_en` falling -> EN_FALL -> firmware aborts its tags -> RESET_DONE after queues clear. `fe_shn` -> checkpoint -> SHST 01b then 10b. `pwr_fail_ni` low -> P51 PLP: new commands complete `0/05`, drain, checkpoint, WP#.

---

## 6. Integration risks / incompatibilities

1. **No physical PCIe. The only host-facing interface is the private 32-bit SFN-TL**, with a mapping to vendor endpoint IP tabulated but never built. Any vendor core (UltraScale+ CQ/CC/RQ/RC AXI-Stream, Intel Avalon-ST, wider than 32 bit) needs a shim plus a CDC/width converter that does not exist (P57 docs E9 / limitation "No CDC"). VID/SSVID `FFFEh`, serial, NQN are placeholders (assigned IDs and class code 01 08 02 required for any hardware use).
2. **Inherits all of P51's SoC coupling.** The firmware-driven FTL needs a ControlCore with its boot flow (image via `mg_*`, no flash loader RTL), ControlCore pages 10..14, EXT window, INTC slots 4/5 and `acc_rst_no`; HIF handshake in `sfn_hif_regs` depends on the P51 firmware's exact register behaviour (the firmware is unmodified, so the HIF page must stay register-for-register compatible forever).
3. **Fork of P51 code.** `sfn_storage_backend` is a modified copy of `sfs_storage_subsys` (not parameterised from it). Changes to the P51 subsystem will not propagate. P57 also vendors the **entire** P51 tree (103 files, including a full ControlCore copy) next to P51's own copy: compiling both in one top would define each module twice (identical content: verified by diff, so only the file list must be deduplicated).
4. **Width/protocol mismatches.** Window and back end are 32-bit only (`DW` hard-wired), single NAND channel in the tested composition; P51 `research4ch` (64-bit DMA, 4 ch x16) is incompatible without a wider window. Window addressing = `context << 20`, so at most 32 contexts x 1 MiB of window; PRP pages must be translated per word (one SFB2 word per transaction). Posted-write ack at the window deviates from SFB2 R7 (confined to this port, compensated by "CQE only after write buffers empty").
5. **Module-name collisions** (scanned across all extracted projects). All P57-defined modules (`sfn_*`, `silicaflux_nvme_controller`, `silicaflux_nvme_ssd`, `silicaflux_nvme_pkg`) are unique within P57 (110 modules/packages, 0 duplicate definitions) and did not collide with any other project. Vendored names collide only with *different* variants of `silicaflux_control_core`, `cc_memmap_pkg`, `sfv_bootrom_image` in `x_secureboot` (374 / 207 / 6307 lines of `diff` output), and with tech-variant `sfv_clkgate` files; `sfb_crossbar`, `sram_generic_1rw` are byte-identical in every copy. Do not mix the secure-boot ControlCore with P57/P51 without choosing one.
6. **Area/timing.** Front end estimated at about 56 k LUT4 + 25 k FF on ECP5 (project's own Yosys estimate; 4 queue pairs / 16 contexts about 91 k LUT4); 60 % of flip-flops are `sfn_hostwin` buffers written inside reset-qualified `always_ff` (not inferred as RAM) and 64-byte SQE per context. No timing constraints exist; the 250 MHz assumption behind all throughput numbers is unsubstantiated. ASIC use needs RAM mapping of these buffers (a code change to verified RTL).
7. **Verification gaps that matter for integration.** No Linux/QEMU/real host, no conformance suite, no formal, no coverage tool; reference models (NAND, host, IOMMU, back-end) are all self-written. A real host that exercises mandatory features that are rejected here (Features 01h, 02h, 04h, 05h, 08h-0Bh; Abort semantics; SMART contents; DSM; MSI-X) may refuse to bind or misbehave.
8. **Persistence semantics.** VWC = 1 with checkpoint-on-flush; unflushed writes are lost on an abrupt cut (by design). P51 FTL has no GC/wear leveling (about 1000 page writes per channel before Capacity Exceeded) and capacity 256 LBAs; a real SSD capacity/endurance needs P56-class FTL in the firmware, not integrated.
9. **Clock/reset conventions.** Front end has its own `ep_rst_ni`-derived synchronised reset; the ControlCore/back end use `rst_ni` (POR). Both resets and the single clock are in one domain; a real endpoint user clock is another domain. `host_rst_req_i` tied 0.
10. **Test-harness limits for CI.** Verdict-line-only pass/fail (exit status 0 regardless); `make mutation` and `make synth` are very long (about 40 min unloaded for synth); the default Verilator C++ compile is slow under load (use `OPT_FAST=-O0`).
11. **Yosys 0.33.** No SV `import`; synth hoists three package bodies into `$unit` (generated `synth/yosys/sfn_rtl_yosys.sv`, a duplicate of all modules; exclude it from file lists).

---

## 7. Licensing notes

* **No licence file** in P57 or in the vendored P51/ControlCore tree. `third_party/PROVENANCE.md`: "No licence file exists in the repository; the same terms as the rest of the repository apply." P51/ControlCore PROVENANCE: "internal Aureom.AI sources. The owner must add a license before any external distribution." Treat everything as **internal / all rights reserved** until the owner licenses it.
* No SPDX headers or copyright lines in any source file (grep of `.sv/.c/.h/.py/.S/.ld/.md/Makefile`).
* No GPL/LGPL code is bundled. The firmware is built with GNU GCC (`riscv64-unknown-elf-gcc`), linked only with `libgcc`; sources are project-authored. riscv-tests (BSD) is referenced by the ControlCore project but not bundled; sramlib ASIC black boxes reference vendor SRAM models (Apache-2.0) that are not bundled; commercial macros are "PENDING" placeholders.
* **No third-party IP** (no PCIe endpoint, no DDR/PHY, no foundry macros) is used in P57; it explicitly depends on *absent* external IP for any hardware PCIe link (vendor endpoint core + SERDES device), for a real NAND (device or vendor model), and for silicon SRAM macros.
* NVMe / PCIe specifications: implemented from memory of the public specs (not bundled). PCI-SIG/NVMe conformance programmes (UNH-IOL etc.) are licensed/hardware-bound and were not used; using "NVMe" branding/logos requires the NVM Express trademark terms, VID/DID require a PCI-SIG assigned Vendor ID.
* Tools: Verilator (LGPL-3.0/Artistic-2.0), Icarus Verilog (GPL-2.0), Yosys (ISC), GNU GCC (GPL-3.0 with runtime exception).
