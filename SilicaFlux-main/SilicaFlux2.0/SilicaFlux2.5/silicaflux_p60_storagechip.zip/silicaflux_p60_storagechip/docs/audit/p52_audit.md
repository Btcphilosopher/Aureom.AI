# Audit of Project 52 — "NAND Digital Twin" / NANDLab (silicaflux-nandlab v0.1.0)

Auditor environment: Linux container, 4 cores shared with other concurrent sessions (load average 8-20 during the
runs, so **all wall times below are inflated, mostly by Verilator C++ compiles**), Python 3.13.18, numpy 2.5.3
(system) / 2.5.4 (venv), pytest 9.2.0 (venv), Verilator 5.020, Icarus Verilog 12.0 (stable), Yosys 0.33.
Pristine source: `$SP/audit/p52_nandlab/silicaflux-nandlab`; all runs were done in a copy
`$SP/work/p52/silicaflux-nandlab` (`SP=/tmp/claude-0/-home-user-Aureom-AI/c80a8d5d-1b1f-56e3-9758-b78cee890e29/scratchpad`).
Raw logs: `$SP/audit_out/p52/`. Nothing in the project was patched to make anything pass; hypothesis tests were done
on separate copies and are labelled **HYP**.

## 1. Summary verdict

**P52 is a sound, self-consistent, simulation-only NAND device model: a pin-level SystemVerilog target model and a
bit-exact Python twin of the same SLC device, with persistence, fault injection and an ONFI-style command subset.
Everything it claims about itself that I re-ran held up (32/32 Python tests, 128/128 SV checks on two simulators with
exact SV-vs-Python replay, 35/35 pytest, demo numbers reproduced to the digit).** It is the best-verified of the three
projects. It is, however, **entirely synthetic**: no coefficient, timing or reliability figure is calibrated to any
real device (the project says so itself and I found nothing contradicting that), and ONFI conformance is explicitly not
claimed (subset only; ONFI timing table is "transcribed", unchecked against a spec).

What it is good for: functional bring-up of a NAND controller and an ECC engine; deterministic, reproducible fault
injection (including power cuts, torn programs/erases, retention bakes, read retry); a golden scoreboard (Python)
for SV runs. What it is not: a source of credible RBER/endurance/UBER numbers, a multi-plane/cache/DDR device, or a
conformance reference.

Main caveats an integrator must know:
1. Geometry is **parameterised** (SV parameters + `nandlab.svcfg` + Python JSON) but the shipped testbench is only
   regression-clean at one geometry (512+16 B, 16 pages/block, 64 blocks/LUN, 2 LUNs). HYP with a page-size-only change
   to 2048+64 B (E6): SV-vs-Python co-simulation stays bit-exact in all 6 phases (incl. 11,379 replayed bit errors) and
   126 of 128 TB checks pass; the 2 failing checks are statistical checks in phase `faults_bake` that I did **not**
   root-cause (0 protocol errors, 0 timing violations). The `slc_1gbit_class` config (1 LUN/target, 1024 blocks/LUN)
   cannot be run through the shipped TB because the TB hard-codes ID bytes, LUN1 and other small-device assumptions (E5).
2. x8 asynchronous SDR only; no cache, multi-plane (SV), copyback, NV-DDR/Toggle, program/erase suspend.
3. Policy `invalid_transition_policy = reject` (default) makes the device fail a PROGRAM that requests any 0->1 bit —
   real NAND would silently AND. That is deliberate (catches controller bugs) but is a behavioural difference.
4. The SV model is non-synthesizable (file I/O, `real` maths, `$value$plusargs`); the store is a text journal.

## 2. Classification table

Legend: **Impl** = implemented (and no stronger statement is supported), **Verified** = I ran it here and saw it pass,
**Partial** = partially verified, **Missing**, **Incompat** = incompatible with an integrated top as shipped,
**SimOnly** = simulation-only by nature and not otherwise verified, **ExtIP** = depends on licensed/external IP.
One primary status per row (marked `X`).

| Function / feature | Impl | Verified | Partial | Missing | Incompat | SimOnly | ExtIP | Note / evidence |
|---|---|---|---|---|---|---|---|---|
| SV pin-level NAND target model (`nand_flash_model`, per-CE, N LUNs): SLC array rules (erase->1, 1->0 program, NOP, sequential-page rule, WP#, status, bad blocks) | | X | | | | | | E2 (Verilator 5.020: 128/128) and E3 (Icarus 12: 128/128). Behavioural/non-synthesizable by nature. |
| Python reference twin `nand_flash_twin.py` + 32 reference tests | | X | | | | | | E1: 32/32 PASS, 1.1 s. |
| SV == Python bit-exact co-simulation (data, injected errors, status, busy time, journal) at default geometry | | X | | | | | | E2/E3: 634 array ops, 8,893 injected bit errors, `co-sim EXACT` in all 6 phases on both simulators. |
| SV == Python co-simulation at other geometries | | | X | | | | | HYP E6: page size 2048+64 -> co-sim EXACT in all 6 phases, TB 126/128 (2 statistical `faults_bake` checks fail, not root-caused); HYP E5: `slc_1gbit_class` -> co-sim EXACT but 36 of 113 TB checks fail on TB assumptions. |
| pytest wrapper (`make test`: 32 ref + numpy/pure-python equivalence + 2 SV regressions) | | X | | | | | | E4: 35 passed, 465.9 s (loaded host). |
| Persistence: NLSF journal, controller reset, process restart, killed writer, torn tail, compaction, power loss | | X | | | | | | E1 tests `process_restart`, `crash_consistency_subprocess`, `torn_journal_tail`, `compaction_equivalence`, `power_cut_*`; SV phases `restart`, `powercut`. |
| ONFI-style command subset: FFh, 90h(00/20), ECh, 00h-30h, 05h-E0h, 80h/85h-10h, 60h-D0h, 70h/78h, EFh/EEh | | | X | | | | | Verified against the project's own spec/TB; **no ONFI conformance** exists or is claimed. |
| ONFI parameter page (256 B x3, signature "ONFI", CRC-16 poly 8005h init 4F4Eh) | | X | | | | | | E1 `parameter_page`; P53 parses it independently (see P53 audit). |
| Multi-LUN interleave (idle LUN accepts commands while another is busy) | | X | | | | | | E2/E3 phase `fresh`; E4. |
| Error model: wear / retention / read-disturb / read noise, charge-direction (0->1 retention, 1->0 disturb), seeded & reproducible | | X | | | | | | E1 `bit_error_statistics` (565 observed vs 540.7 expected), `error_physics_direction`, `error_reproducibility`, `nested_monotonic_retention`; E2 `faults_bake` (8,852 errors replayed exactly). Mechanics verified, numbers are illustrative. |
| Program / erase failure models, factory bad blocks, stuck cells, interrupted (power-cut) program/erase | | X | | | | | | E1 `endurance_degradation`, `stuck_bits_and_directed_failures`, `power_cut_during_program/erase`, `factory_bad_blocks`; E2 phases `powercut`, `faults`. |
| Read retry (SET FEATURES A0h, model-specific, +-7 levels) | | X | | | | | | E1 `read_retry_recovers_retention`; E2 `faults_bake` check "read retry (+3) recovers most retention errors". **Not an ONFI feature address.** |
| ONFI async timing modes 0-5 table + AC timing checker (tWP,tWH,tWC,tRP,tREH,tRC,tCLS,tALS,tDS,tWHR,tADL,tRR,tCCS) | | | X | | | | | Checker fires/passes consistently (P53 negative test), but the table is a "transcription", not checked against ONFI or a datasheet. |
| Array timing tR/tPROG/tBERS/tRST/tFEAT, wear-scaled | | | X | | | | | `busy_times_and_wp` passes; values are "illustrative SLC-datasheet-range" (25 us / 200 us / 2 ms). |
| Calibration against a real device datasheet / measured RBER, timing, bad-block rates | | | | X | | | | Absent by design (`MODEL_LIMITATIONS.md`, `_sources` labels = `illustrative_model`). |
| Multi-plane concurrency, shared program time | | | X | | | | | Python latency engine only; **absent in SV** (README table: SV "-"). Not cross-checked SV vs Python. |
| Latency / contention engine (`ArraySimulator`, FIFO vs LUN-interleave, read-retry-driven re-reads) | | | X | | | | | E1 `latency_contention`, `read_retry_latency`; E7 demo reproduces read p50 18.5 ms / 1.1 ms / 40 us. Python only. |
| Cache read/program, copyback, unique-ID, program/erase suspend, LUN reset | | | | X | | | | Stated "not modelled". |
| NV-DDR / Toggle / x16 / ZQ / ODT | | | | X | | | | Stated "not modelled". |
| MLC/TLC/QLC device semantics | | | | X | | | | SLC only (`bits_per_cell` must be 1). |
| Research Vt (threshold-voltage) model SLC..QLC | | | | | | X | | E1 `vt_model_consistency` passes (13 internal checks); explicitly "research, unvalidated"; not connected to the device model. |
| Geometry parameterisation (SV params, `nandlab.svcfg`, JSON) | | | X | | | | | See section 3 and E5/E6. |
| Shared-channel wrapper `nand_flash_device` (inout DQ, 2 targets on one bus) | | X | | | | | | E2/E3 `tb_nand_channel` 13/13; P53 uses it heavily. |
| Controller BFM (`tb/nand_ctrl_bfm.sv`) | | X | | | | | | Exercised by every phase and by P54 (see P54 audit). Not synthesizable by design. |
| Viewer / report / demo (`make demo`) | | X | | | | | | E7: fault-scenario error counts reproduced exactly (see section 5). Viewer HTML has no external URLs (static check). |
| README "mutation check" (breaking erase / read retry fails tests) | | | X | | | | | No script shipped; I reproduced both mutants on copies (E8): erase mutant -> 5 tests fail, retry mutant -> 2 tests fail. |
| External IP / licences | | | | | | | | None required. No LICENSE file shipped. |

## 3. What is actually modelled (item-3 questions)

**Geometry (all configurable).** Hierarchy `channels -> packages -> targets (CE#) -> dies -> LUNs -> planes -> blocks ->
pages (data + spare)`. One SV instance = one target (CE#) with `LUNS` LUNs.
* `config/slc_tiny.json` (default, and the one the SV TB/regression uses): 2 ch x 1 pkg x 2 CE x 2 dies x 1 LUN, 2
  planes/LUN, 32 blocks/plane (= 64 blocks/LUN), 16 pages/block, **512 B data + 16 B spare**; 4 MiB user data in total.
  SV defaults: `PAGE_DATA_BYTES=512, PAGE_SPARE_BYTES=16, PAGES_PER_BLOCK=16, BLOCKS_PER_PLANE=32, PLANES_PER_LUN=2,
  LUNS=2`. Bad-block marker = spare byte 0 (`bad_block_marker_byte 0`), value 00h, first and last page of the block.
* `config/slc_1gbit_class.json`: 4 ch x 1 pkg x 2 CE x 1 die x 1 LUN, 2 planes, 512 blocks/plane (1024/LUN),
  64 pages/block, **2048 + 64 B** (Python; for the SV model set `POOL_PAGES`).
* Addressing: 2 column cycles + 3 row cycles; row = page | block << ceil(log2 ppb) | lun << (page+block bits);
  plane = low block bits. Limits checked by `Geometry.validate()`: row <= 24 bits, page+spare <= 65535.

**Command set (ONFI-like, async SDR, x8 only).** FFh reset; 90h/00h (5 ID bytes `00 5A 00 15 00`) and 90h/20h ("ONFI");
ECh/00h parameter page; 00h-addr x5-30h read + 05h-E0h change read column; 80h-addr x5-data-10h program (+85h change write
column); 60h-addr x3-D0h erase; 70h / 78h(+3 row cycles) status; EFh/EEh set/get features (01h = timing mode 0-5, A0h =
read-retry level, model-specific). Status bits: FAIL 01h, FAILC 02h, ARDY 20h, RDY 40h, WP# 80h; erased-OK status E0h.
Not modelled: cache, multi-plane (SV), copyback, unique ID, suspend, NV-DDR/Toggle.

**Timing.** Per-mode AC table (modes 0-5: e.g. mode 0 tWC 100 ns, tRC 100 ns, tADL 200 ns, tWHR 120 ns; mode 5 tWC 20 ns,
tRC 20 ns, tREA 16 ns, tADL 70 ns) used as an *input timing checker* (violations counted in `n_timing_violations`,
optionally fatal). Array times default: tR 25 us, tPROG 200 us (shrinks with wear down to 0.6x), tBERS 2 ms (grows with wear),
tRST 5 us idle / 10 us in program / 500 us in erase / 1 ms power-on, tFEAT 1 us, tWB <= 200 ns, tCCS 500 ns. Failed ops run 3x
longer; policy-rejected ops take 2 us.

**Error model (all `illustrative_model`; seeded splitmix64, same integer + IEEE-754 expressions in SV and Python).**
Per cell fixed weakness `u`; with `c = P/E / rated_endurance (100 000)`:
`p_wear = rber_fresh + rber_wear_at_rated*c^2`; `p_ret = retention_rber_ref*(age/ref_h)^1 *(1+50c)` (0->1, Arrhenius Ea 1.1 eV, ref 40 C);
`p_rd = read_disturb_rber_ref*(reads/1e5)*(1+10c)` (1->0); optional per-read noise; read-retry level `r` scales retention by
`g^r`, disturb by `g^-r` (g = 0.5). Profiles: `ideal` (all zero), `nominal` (rber_fresh 1e-10, wear 1e-7 at rated, retention 1e-8 at
8760 h, disturb 1e-8 at 1e5 reads, factory-bad 2 %, prog-fail 1e-4 and erase-fail 1e-3 at rated), `stress`
(rber_fresh 2e-5, wear 2e-3, retention 1e-3 at 1000 h, disturb 1e-3 at 1000 reads, noise 2e-5, factory-bad 5 %,
prog-fail 5 %, erase-fail 10 % at rated). Program/erase fail = `fresh + at_rated*c^3`, leave partial data, flag the block;
erase failure sticky; erase refused beyond 3x rated endurance. Factory bad blocks: seeded rate (block 0 always good, capped at the
ONFI "max bad blocks per LUN") plus explicit list. Directed faults: forced program/erase failure per address, stuck-at cells.
Power loss: partial program/erase proportional to elapsed busy time, flagged unstable, persisted.

**SV and Python both exist and are consistent.** `nand_flash_model.sv` (SV package `nand_flash_pkg`, modules `nand_flash_model`,
`nand_flash_device`) and `nand_flash_twin.py` implement the same semantics, write/read the same NLSF journal format, and the SV
model writes a trace that `replay_trace()` re-executes in Python (E2/E3). Parameters: SV via module parameters + run-time
`nandlab.svcfg`; Python via JSON `Config`. SV and Python are **kept in sync by hand** (hash domain constants, formulas), checked
only by the co-sim regression.

**Calibrated or synthetic?** **Synthetic.** `MODEL_LIMITATIONS.md`: "It has not been compared with any physical NAND device";
every config value carries a `_sources` provenance label (`illustrative_datasheet`, `illustrative_model`, `model_choice`,
`onfi_timing`, `jedec_ea`). Only the Arrhenius activation energy (1.1 eV, JESD218) and the ONFI structure encodings are
"external" numbers, and the ONFI timing values are a from-memory transcription ("verify against the ONFI revision / datasheet").
READ ID manufacturer byte is 00h ("not a valid JEP106 code") and `ecc_bits_required = 4`.

## 4. Evidence log (what I ran)

All commands in `$SP/work/p52/silicaflux-nandlab` unless noted. "Wall" = `time` real. Host heavily loaded.

| # | Command | Exit | Key output | Wall | Log |
|---|---|---|---|---|---|
| E1 | `make verify` (= `python3 nand_flash_twin.py verify --json outputs/verification/python_reference.json`) | 0 | `SilicaFlux NANDLab 0.1.0 reference verification (numpy: True)` ... `32/32 passed` | 1.13 s | `p52/01_make_verify.log` |
| E2 | `make sv` (= `nand_flash_twin.py sv-regress --sim verilator --out outputs/sv_regression`) Verilator 5.020 `--binary --timing` | 0 | fresh 78/0, restart 14/0, powercut 13/0, faults 7/0, faults_bake 3/0, channel 13/0 -> `RESULT: PASS (128 TB checks)`; co-sim EXACT every phase: 321+9+12+205+82+5 = **634 ops**, 41+8,852 = **8,893 bit errors replayed** | 3 m 49 s (compile-dominated) | `p52/02_make_sv_verilator5.020.log` |
| E3 | `make sv-iverilog` (Icarus 12.0 `-g2012`) | 0 | same six phases, 128/128, co-sim EXACT, 634 ops / 8,893 errors; `RESULT: PASS (128 TB checks)` | 35.3 s | `p52/03_make_sv_iverilog12.log` |
| E4 | `make test PY=$SP/venv_p54/bin/python` (pytest 9.2.0, numpy present) | 0 | `35 passed in 465.87s` (32 reference + numpy-vs-pure-python + SV verilator + SV iverilog) | 7 m 46.6 s | `p52/04_make_test_pytest.log` |
| E5 | **HYP** (copy `work/p52_hyp`): `sv_regress("iverilog", ..., base_cfg=config/slc_1gbit_class.json)` | 0 (script) / `NOT OK` | co-sim EXACT in all 6 phases (2141 ops in `fresh`), but 36 of 113 TB checks fail: READ ID != 5A (config ID byte is 5B), TB uses LUN1 on a 1-LUN device, hard-coded counts. **Conclusion: TB is not geometry-generic; this is not a model failure and not proof of one.** | 3 m 37 s | `p52/05_HYP_iverilog_slc_1gbit_class_geometry.log` |
| E6 | **HYP** (copy `work/p52_hyp2`): slc_tiny with only `page_data_bytes=2048, page_spare_bytes=64`; same Icarus regression (`sv_regress(..., base_cfg=...)`) | 0 (script) / `NOT OK` | fresh 78/0, restart 14/0, powercut 13/0, faults 7/0, channel 13/0 pass; faults_bake 1 pass / 2 fail (`retention bake causes mostly 0->1 errors (0 vs 61)`, `read retry (+3) recovers most retention errors`); **co-sim EXACT in all 6 phases** (e.g. 11,379 bit errors replayed in faults_bake), 0 protocol errors, 0 timing violations. Total 126/128 TB checks. Cause of the 2 TB failures not investigated (TB statistic sees 0 charge-loss errors although the replay shows thousands of bit errors). | 3 m 31 s | `p52/05b_HYP_iverilog_tiny_with_2048+64_pages.log` |
| E7 | `make demo PY=$SP/venv_p54/bin/python` (copy `work/p52_demo`) | 0 | fault-scenario read sweep `{'wear': 5757, 'retention': 73487, 'read_disturb': 88, 'noise': 67, 'stuck': 0}` = README figures; latency p50 FIFO/mode0 18,515 us, interleave/mode0 1,105 us, interleave/mode5 40 us, multi-plane/mode5 73 us, stress+bake 31 retries | 3 m 04 s | `p52/07_make_demo.log` |
| E8 | **HYP** mutants on copies `work/p52_mut_erase`, `work/p52_mut_retry`: (a) `_apply_erase_ok` no longer pops pages; (b) `rber_components` ignores read-retry level; then `python3 nand_flash_twin.py verify` | 1 / 1 | (a) `27/32 passed` (FAIL block_erase, factory_bad_blocks, controller_reset_preserves_array, compaction_equivalence, power_cut_during_erase); (b) `30/32 passed` (FAIL read_retry_recovers_retention, read_retry_latency) | ~1 s each | `p52/06_HYP_mutant_erase_verify.log`, `..._retry_verify.log` |
| E9 | static: `sha256sum` of `nand_flash_model.sv` in P52, P53 `tb/models/`, P54 `third_party/`; `nand_flash_twin.py` in P52 and P54 | - | model: `070651e01b6d6bbc2f6374cae2c93e96508a8624e557f8ac56bd8062136652cb` in all three; twin: `4d2e4012e6ff5bbda9237c0af66000d3a2cd46fb8b3d7fc0fa87659c13635324` in P52 and P54 -> **P53/P54 really do use the unmodified P52 model** | - | (inline) |

Environment fixes: none needed for P52 (system `python3` has numpy but not pytest; used the venv python only for `make test`/`make demo`).

## 5. Doc claims not reproduced / not substantiated

* **Reproduced:** 32/32 Python tests; 128/128 SV checks on both simulators; 634 ops / 8,893 injected bit errors / "all 1,533 journal
  records match" (the journal-record count was not separately counted by me, but every phase's `journal_equal`/`semantic_equal`
  gate is part of the `ok` condition that printed EXACT); 35/35 pytest; fault-scenario counts 73,487 / 5,757 / 88 / 67; read p50 18.5 ms
  -> 1.1 ms -> 40 us; 9.2 -> 18.5 MB/s multi-plane was not individually checked.
* **Not re-run / not checked:** the "13/13 threshold-model checks" individually (the single `vt_model_consistency` test passes);
  "31 read retries recover most pages; 5 remain uncorrectable for a 4-bit/512-B ECC" and "158 block erases, p99 2.2 ms" (demo-internal
  numbers, `outputs/report/NANDLAB_REPORT.md` regenerated by E7 but not diffed line by line); viewer interactivity (HTML opened by no browser).
* **Not substantiated:** "During development, deliberately breaking erase or read retry made the relevant tests fail" — no script
  shipped; **I reproduced it for two mutants (E8)**, which supports the claim but is not the authors' evidence.
* **Not substantiated and not substantiable here:** the ONFI timing mode table values (transcription, no spec available), "illustrative
  SLC-datasheet-range" array times, the Arrhenius/JESD218 statement. These are labelled illustrative by the authors, so no overclaim.
* **Doc inconsistency (minor):** `config/slc_tiny.json` description says "64 blocks/LUN" while the key is `blocks_per_plane: 32` x 2 planes
  — consistent, just easy to misread. The README says "2 ch x 1 pkg x 2 CE x 2 dies (1 LUN each)", so a target has **2 LUNs** (SV default `LUNS=2`).

## 6. Reusable interface reference

### 6.1 SystemVerilog

File `nand_flash_model.sv` (compile with `` `timescale 1ns/1ps`` already set inside; Verilator `--binary --timing`, flags
`-Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN`; Icarus `-g2012`, **always pass `-s <top>`**).

`package nand_flash_pkg` — command opcodes `CMD_READ1=00h CMD_READ2=30h CMD_CRC1=05h CMD_CRC2=E0h CMD_PROG1=80h CMD_PROG2=10h
CMD_CWC=85h CMD_ERASE1=60h CMD_ERASE2=D0h CMD_STATUS=70h CMD_STATUS_ENH=78h CMD_READID=90h CMD_PARAM=ECh CMD_GETF=EEh CMD_SETF=EFh
CMD_RESET=FFh`; status `ST_FAIL=01h ST_FAILC=02h ST_ARDY=20h ST_RDY=40h ST_WP_N=80h`; features `FEAT_TIMING_MODE=01h FEAT_READ_RETRY=A0h`;
page flags `PF_PROG_FAILED=02h PF_PROG_INTERRUPTED=04h PF_FACTORY_MARKER=08h PF_PARTIAL_ERASE=10h`; block flags
`BF_FACTORY_BAD=01h BF_ERASE_FAILED=02h BF_PROG_FAILED=04h BF_WORN_OUT=08h BF_MARGINAL=10h BF_ERASE_INTERRUPTED=20h`; internal
result codes `RC_OK=0 RC_FAIL_RANDOM=1 RC_FAIL_FORCED=2 RC_FAIL_BAD_BLOCK=3 RC_FAIL_WORN=4 RC_REJECT_TRANSITION=5 RC_REJECT_NOP=6
RC_REJECT_SEQUENCE=7 RC_REJECT_ADDRESS=8 RC_WP=9`.

`module nand_flash_model #(PAGE_DATA_BYTES=512, PAGE_SPARE_BYTES=16, PAGES_PER_BLOCK=16, BLOCKS_PER_PLANE=32, PLANES_PER_LUN=2,
LUNS=2, TARGET_ID=0, POOL_PAGES=0)` — one target (one CE#), x8, SDR. `POOL_PAGES=0` = room for every page; set lower for big devices.

| Port | Dir | Width | Meaning |
|---|---|---|---|
| `ce_n` | in | 1 | chip enable, active low |
| `cle`, `ale` | in | 1 | command / address latch enable |
| `we_n`, `re_n` | in | 1 | write / read strobe, active low |
| `wp_n` | in | 1 | write protect, low = program/erase report FAIL |
| `dq_in` | in | 8 | data from controller |
| `dq_out` | out | 8 | data to controller (driven tREA after RE# low) |
| `dq_oe` | out | 1 | output enable for `dq_out` |
| `rb_n` | out | 1 | ready/busy, push-pull (AND externally for a shared open-drain R/B#), low while unpowered |
| `vcc_ok` | in | 1 | power-good; falling edge = power loss (partial program/erase committed) |

`module nand_flash_device` — same parameters; ports `ce_n, cle, ale, we_n, re_n, wp_n, vcc_ok` (in), `inout wire [7:0] dq`, `rb_n` (out);
releases DQ ~15 ns after RE# rises so several devices (different `TARGET_ID`) can share one DQ bus.

Observability: `n_proto_errors`, `n_timing_violations`, `n_reads`, `n_programs`, `n_erases`, `n_bit_flips`, `n_torn` (hierarchical int
counters; regressions should assert the first two are 0). Back door: `bd_peek(lun,blk,pg,col)`, `bd_erase_count`, `bd_block_flags`,
`bd_block_reads`, `bd_page_flags`, `bd_page_nop`, `bd_clock()`, `bd_bake(hours,temp_c)`, `bd_checkpoint()`.
Plusargs: `+NANDLAB_DIR=<dir>` (reads `<dir>/nandlab.svcfg`, creates `<dir>/target<ID>.nlsf` and `.trace`), `+NANDLAB_BAKE_HOURS`,
`+NANDLAB_BAKE_TEMP_C`, `+NANDLAB_NOTRACE`, `+NANDLAB_QUIET`. Without a svcfg the built-in defaults equal the Python `nominal` profile.
Generate geometry/config for a run: `python3 nand_flash_twin.py export-sv --config config/slc_tiny.json --out <dir>` (writes `nandlab.svcfg` + `nandlab_geom.svh`
with `` `define NANDLAB_PAGE_DATA_BYTES/…_SPARE_BYTES/…_PAGES_PER_BLOCK/…_BLOCKS_PER_PLANE/…_PLANES_PER_LUN/…_LUNS``).
`nandlab.svcfg` is a flat `key value` text file (`nandlab_svcfg 1`, geometry keys, `seed`, `profile`, policy, ident, timing, fault coefficients,
`factory_bad t l b`, `force_prog_fail t l b pg`, `force_erase_fail t l b`, `stuck_bit t l b pg bit val`, `end`); values are run-time, no recompile.
**The svcfg geometry must equal the module parameters.**

### 6.2 Bus protocol the model expects (as driven by `tb/nand_ctrl_bfm.sv`)
* After power-up (and `vcc_ok` rising) the device **requires FFh** before anything except 70h (`policy.require_reset_after_power_on`); first reset busy 1 ms.
* Address: `00h` + 2 column bytes (LSB first) + 3 row bytes (LSB first) + `30h`; wait for R/B# (tWB <= 200 ns after 30h), then data out from the column.
* Program: `80h` col(2) row(3) tADL data `10h`; status via `70h`/`78h`+row(3). Erase: `60h` row(3) `D0h`. Reset: `FFh`.
* A model-specific rule: **one column pointer per target** (a command to another LUN between 30h and data-out moves it) — P53 works around it with 05h-E0h.

### 6.3 Python
`nand_flash_twin.py` — `Config`/`load_config(path, profile, overrides)`, `Geometry`, `NandFlashTwin(cfg, store_dir)` (channels x packages x targets), `NandTarget`
(`begin_read/program/erase`, `read_status`, `reset`, `power_off/on`, `scan_bad_block_markers`, ...), `BackingStore`/NLSF, `FaultModel`, `ArraySimulator` (latency),
`replay_trace`, `sv_regress`, `build_parameter_page`, `export_svcfg`, `export_sv_geometry`. CLI: `init-configs create info read program erase bake compact export-sv workload vt
verify sv-regress cosim demo`. NLSF format: `docs/NLSF_STORE_FORMAT.md` (text journal: `NLSF 1 <data> <spare> <ppb> <blocks/LUN> <planes> <LUNs> <seed> <target> ;`, then `M/C/B/R/E/P` records).

## 7. Integration risks / incompatibilities

**Cross-project geometry matrix (what each project assumes):**

| | P52 default (`slc_tiny`, SV defaults) | P52 `slc_1gbit_class` | P53 FlashLink | P54 ECCCore |
|---|---|---|---|---|
| Data B / page | 512 | 2048 | discovered from param page (<= 16384); **verified at 512 only** | 512 (N512T4, N512T8), 2048 (N2KT8), 8192 (N8KT40) |
| Spare (OOB) B / page | 16 | 64 | discovered (<= 2048); verified at 16 | 16 / 16 / 64 / 744 (**exactly the budget**; 0 B spare left) |
| Pages / block | 16 | 64 | <= 1024; verified 16 | ECC is page-local (n/a); P54 twin tests use 16 |
| Blocks / LUN | 64 (2 planes x 32) | 1024 | <= 65536; verified 64 | P54 twin tests use 8 (2 planes x 4) |
| LUNs / target | **2** | 1 | `NUM_LUN_MAX` 2 default (1..8); verified 2 | twin tests use **1** |
| Targets (CE#) / channel | 2 | 2 | `NUM_CE` 1..8; verified 1 and 2 | 1 |
| Channels | 2 | 4 | multichannel wrapper; verified 2 x (1 CE) | 1 |
| Bus | x8 SDR | x8 SDR | x8 verified; x16 elaborated only | byte stream |
| ECC | ONFI param page says 4 bits (per 512 B, no codeword size) | same | none | BCH t=4 / t=8 per 512 B; t=40 per 1 KiB |

Specific risks seen from P52's side:
1. **Spare budget is exact.** P54 N512T4/N512T8 use 16/16 spare bytes (1 BBM + 6 user-meta + 2 CRC + 7 parity, or 1+0+2+13). Any metadata a P53/P51 FTL wants in OOB has no room (N512T8 has zero metadata bytes).
2. **Bad-block marker** is spare byte 0, value 00h, first and last page. P54 reserves exactly that byte (RSVD, outside every codeword); consistent. But a factory-bad page programmed/erased as an ECC page will read `UNCORRECTABLE`/BBM!=FF — the FTL must scan markers before trusting ECC status.
3. **`invalid_transition_policy=reject`** makes a PROGRAM fail if any loaded byte needs 0->1. An ECC engine always programs a full page once (fine) but re-programming an already-programmed page (NOP>1) with new parity would fail; use whole-page programs only.
4. **Read retry** is a P52-specific SET FEATURES A0h; P53 can issue it (OP_SET_FEATURES) but never does so automatically and its regression never exercised it; P54 only reports UNCORRECTABLE/scrub. The retry loop (A0h level -> re-read -> re-decode) does not exist anywhere.
5. **Single column pointer per target** — see 6.2; any alternate controller must re-issue 05h-E0h.
6. **Model reliability numbers are not predictive**: sizing t (4 vs 8 vs 40) from these profiles is meaningless. `nominal` RBER (1e-10..1e-7) means a 4224-bit codeword essentially never errs; `stress` (2e-5..2e-3 + retention) is what exercises ECC. Neither is calibrated.
7. `slc_1gbit_class` SV runs need `POOL_PAGES` and a TB that is not hard-coded to the 4 MiB device.
8. SV model uses `` `timescale 1ns/1ps`` inside the file and non-synthesizable constructs: must stay in the testbench filelist only. Module names (`nand_flash_pkg`, `nand_flash_model`, `nand_flash_device`, `nand_ctrl_bfm`) do not collide with P53/P54 names (scanned all extracted projects); the same file is vendored byte-identically in P53 (`tb/models/`), P54 (`third_party/`) and P55 (`third_party/silicaflux-flashlink/tb/models/`) -> an integrated filelist must include it **once**.

## 8. Licensing notes
* No LICENSE/COPYING file in the archive; all headers say "Aureom.AI | SilicaFlux-STORE". No third-party code is bundled in P52. Optional runtime dependency numpy (BSD) and pytest (MIT) only.
* P52 itself contains no GPL code. (P54 bundles a copy of P52 under `third_party/`, hash-identical.)
