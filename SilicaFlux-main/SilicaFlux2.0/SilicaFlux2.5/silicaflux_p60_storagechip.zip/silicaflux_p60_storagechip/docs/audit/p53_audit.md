# Audit of Project 53 — "FlashLink" NAND channel controller (silicaflux-flashlink)

Auditor environment: Linux container, 4 cores shared with other concurrent sessions (load average 8-33 during the runs;
**all wall times are inflated, mostly by Verilator C++ builds**, and the Icarus runs, which the project itself timed at 3-11 min
each on an unloaded machine, were run under my 8-minute-per-command cap), Python 3.13.18, Verilator 5.020, Icarus 12.0, Yosys 0.33,
nextpnr-ecp5 0.6-3build5. Pristine source `$SP/audit/p53_flashlink/silicaflux-flashlink`; runs in a copy `$SP/work/p53/silicaflux-flashlink`
(`SP=/tmp/claude-0/-home-user-Aureom-AI/c80a8d5d-1b1f-56e3-9758-b78cee890e29/scratchpad`). Raw logs `$SP/audit_out/p53/`. No project file was patched
to get anything to pass; the hypothesis test (**HYP**) used a patched COPY (`$SP/work/p53_hyp`).

## 1. Summary verdict

**P53 is a real, synthesizable, well-structured ONFI-style asynchronous NAND channel controller whose claims I could largely reproduce.**
Verilator lint (`-Wall`, 0 warnings on 7 parameter sets) and the Verilator protocol regression (771/771 checks across 7 configurations, 0 model
protocol errors, 0 AC-timing violations, 0 independent-monitor violations) pass here; the negative test proves the checkers are live. It
discovers geometry from the NAND's ONFI parameter page, so it is parameterised in principle.

What it is **not**: a PHY (the pin boundary `sfnc_io_sdr` is a simulation-only placeholder that refuses to elaborate for an ASIC/technology
build); a DDR/Toggle controller (SDR modes 0-5 only); an ECC engine or FTL; a design verified against any real NAND (only against P52's
*illustrative* model, with **timing table, monitor table and device model all transcriptions of the same values** — a stated common-mode risk).
It was verified at essentially **one geometry** (512+16 B, 16 pages/block, 64 blocks/LUN, 2 LUNs) and only with the **`ideal` (error-free) fault
profile** plus a few directed program/erase failures: no random bit errors, no read-retry, no power-loss traffic ever flowed through it.
The 100 MHz clock used in most simulations is **not** met on ECP5 (project reports 66 MHz at -6 / 85 MHz at -8; see E10).

Biggest integration facts: (1) its page-data interface is an **SFB2 memory-mapped buffer master**, while P54's ECC engine speaks ready/valid
**byte streams** and wants the page **spare-area first** — an adapter + re-order is needed and there is no way to get spare-then-data from one array
read through `OP_READ_PAGE`; (2) multi-channel was verified only with 1 CE per channel; (3) x16 / 64-bit buffer are lint/synth-only.

## 2. Classification table

Legend as in the P52 audit (Impl / Verified = I ran it and saw it pass / Partial / Missing / Incompat / SimOnly / ExtIP). One primary status per row.

| Function / feature | Impl | Verified | Partial | Missing | Incompat | SimOnly | ExtIP | Note / evidence |
|---|---|---|---|---|---|---|---|---|
| Channel controller RTL `silicaflux_nand_controller` is lint-clean | | X | | | | | | E1 `make lint`: 7/7 configs, Verilator `-Wall` 0 warnings + Icarus elaborates; 13.7 s. |
| Protocol regression, single target (2 LUNs), 100 MHz, 4 slots (`base`) | | X | | | | | | E2: Verilator 141/141, wall 172 s. |
| 2 targets on one channel, per-CE R/B# (`ce2`) | | X | | | | | | E2: Verilator 156/156. |
| 2 targets sharing one wired-AND R/B# (`ce2_rbshared`) | | X | | | | | | E2: Verilator 156/156. |
| Controller clock 200 MHz / 8 slots (`clk200_q8`) and 50 MHz (`clk50`) | | X | | | | | | E2: see table (145 / 141). |
| Multi-channel wrapper `silicaflux_nand_multichannel` (2 ch x 1 CE) | | X | | | | | | E2: Verilator 28/28. Only NUM_CE=1 per channel simulated; 4ch x 2CE is lint/synth-only. |
| Negative test (mis-programmed tWP/tWH/tRP/tREH must trip model + monitor) | | X | | | | | | E2: Verilator 4/4; monitor 93 checks / 22 violations as intended. |
| Independent pin-level ONFI monitor (`sfnc_onfi_monitor`) | | X | | | | | | E2: `MONITOR MON checks 226958 violations 0` (base), 272,108 / 0 (ce2). |
| Second simulator (Icarus 12) regression, 771 checks | | | X | | | | | E3: `negative` 4/4 and `multichannel` 28/28 pass; `base` DNC at 480 s; other 4 configs not attempted (32/771 checks re-run). |
| Operation set: RESET, READ ID, READ PARAM, READ STATUS (70h/78h), READ PAGE (+05h-E0h), PROGRAM PAGE, ERASE BLOCK, SET/GET FEATURES | | X | | | | | | Covered by the suite (E2). Verified against P52 only; **no ONFI conformance**. |
| Parameter-page parser (CRC-16, up to 3 copies) -> geometry, address cycles, timing-mode mask, tR/tBERS/tPROG/tCCS | | | X | | | | | Suite verifies 512+16/16/64/2 LUN; HYP E6 (Icarus demo, 19/19) shows 2048+64 geometry loads into GEO0..3 and full-page program/read works. Full suite not run at 2048+64. |
| SDR timing modes 0-5 incl. run-time switching via SET FEATURES | | X | | | | | | E2 timing-mode sweep (PERF lines reproduce the docs: mode 0 read 8,089 cycles = 80.9 us, mode 5 4,241 = 42.4 us @100 MHz). Common-mode table risk. |
| NV-DDR / NV-DDR2/3 / Toggle | | | | X | | | | Not implemented, not claimed. |
| Physical NAND I/O (`sfnc_io_sdr` TECH branch, pads, SDC, I/O timing, capture calibration) | | | | X | | | | `TECH="SIM"` only; any other value -> `$error`. `CAPTURE_MARGIN_PS=2000` is a simulation value. |
| `sfnc_io_sdr` behavioural tri-state layer | | | | | | X | | Simulation model; `SFNC_ASIC_IMPL` stops elaboration. |
| R/B# 2-FF synchroniser (`sfnc_sync`) | X | | | | | | | Placeholder for a characterised library sync (stated). Exercised in sim only. |
| Multi-LUN interleaving, read-priority arbitration + starvation bound, per-LUN ordering | | X | | | | | | In suite (E2). |
| Timeouts, fault recovery (TIMEOUT -> RESET), completion/error codes, request validation with no bus traffic | | X | | | | | | In suite (E2). |
| Sequential-program check / WP# handling | | X | | | | | | In suite; check is partial (1 tracked block per LUN, stated). |
| SFB2 (DataFabric rev 2.0) buffer master | | | X | | | | | Verified only against the project's own SFB2 memory model with random stalls/latency/errors; not against a real DataFabric crossbar. |
| x16 bus (`DQ_WIDTH=16`) and 64-bit buffer (`BUF_DW=64`) | | | X | | | | | Lint (E1) + Yosys only; **never simulated** (no x16 model exists). |
| ECC / read-retry policy / bad-block table / FTL | | | | X | | | | Out of scope by design. A0h read-retry is reachable through OP_SET_FEATURES but never exercised. |
| Random bit errors / read retry / power loss through the controller | | | | X | | | | All regression runs use P52 profile `ideal`; `vcc_ok` never dropped. |
| Geometry other than 512+16 / 16 ppb / 64 blk / 2 LUN | | | X | | | | | HYP E6: 2048+64 demo passes (see above); 8192+744 and 1-LUN devices untested. |
| Gate-level simulation of the Yosys netlist | | GLS_ROW | | | | | | E8. |
| Yosys synthesis, 0 latches (5 configs) | | SYNTH_ROW | | | | | | E9. |
| ECP5 place-and-route (LFE5U-45F) | | PNR_ROW | | | | | | E9. |
| Waveform demo / SVG generation (`make demo`) | | X | | | | | | E4: 15/15 demo checks, 9 SVGs rendered, MEASUREMENTS.md byte-identical to shipped. |
| External IP / licences | | | | | | | | None needed. Uses P52 model (vendored, hash-identical). No LICENSE file shipped. |

## 3. What the design is (item-4 questions)

* **Channels:** `silicaflux_nand_controller` = **one** asynchronous channel with `NUM_CE` (1..8) chip enables and up to `NUM_LUN_MAX` (1..8) LUNs per target.
  `silicaflux_nand_multichannel` instantiates `NUM_CH` of them (`req_ch` is 3 bits; `csr_addr[10:8]` selects the channel window) with a round-robin completion merge,
  one SFB2 master and one pin set per channel. Verified with NUM_CH=2, NUM_CE=1.
* **Command set (abstract ops, `req_op`):** `OP_RESET 0` (FFh, wait, 70h), `OP_READ_ID 1` (90h addr), `OP_READ_PARAM 2` (ECh 00h, 256 B x up to 3 copies), `OP_READ_STATUS 3` (70h or 78h+row),
  `OP_READ_PAGE 4` (00h col row 30h, wait, 70h/78h poll, **05h col E0h**, tCCS, data out -> buffer), `OP_PROGRAM_PAGE 5` (80h col row, tADL, data <- buffer, 10h, wait, status),
  `OP_ERASE_BLOCK 6` (60h row D0h), `OP_SET_FEATURES 7` (EFh fa P1..P4), `OP_GET_FEATURES 8` (EEh fa). **Not implemented:** cache read/program, multi-plane, copyback, change write
  column (85h), read unique ID, LUN reset, suspend, volume addressing.
* **Timing handling:** a pure-digital layer that knows only "micro-ops" (command/address/data in/out/delay/CE select) and a timing engine that converts the ONFI-style async table (25 parameters x modes 0-5,
  `silicaflux_nand_timing_pkg::onfi_ns`) into controller-clock cycle counts at elaboration (`CLK_PERIOD_PS`), run-time overridable through `TIM0..TIM3`/`TMODE`. tR/tPROG/tBERS are **not** waited as fixed delays: the
  sequencer waits for R/B# (a hint) or polls READ STATUS 70h/78h after programmable first-poll and interval delays (`POLL_RD/PG/ER/IV`, default 10/100/1000/5 us) with per-class timeouts
  (`TMO_*`, default 2/10/50/10 ms; derived from the parameter page when `CTRL.AUTO_TMO`). Device busy time is reported per completion (`cpl_dev_time`). tWB/tRR/tCCS are sequencer `U_DELAY` micro-ops;
  tWHR/tADL/tRHW/tCS/tCH/tWW and pulse widths are enforced by the timing engine. Read data are sampled on the edge that raises RE# (needs tRP >= tREA + `CAPTURE_MARGIN_PS`, 2 ns).
* **SDR vs DDR:** asynchronous **SDR only** (modes 0-5; throughput ceiling about 33 MB/s read, 50 MB/s write at mode 5 with this capture scheme). No NV-DDR/Toggle.
* **How it talks to the NAND model:** controller pins `nand_ce_n[NUM_CE-1:0], nand_cle, nand_ale, nand_we_n, nand_re_n, nand_wp_n, nand_dq_o[DQ_WIDTH-1:0], nand_dq_oe, nand_dq_i, nand_rb_n[NUM_RB-1:0]`
  -> `sfnc_io_sdr` (SIM tri-state) -> shared `tri [7:0]` DQ bus -> one `nand_flash_device` (P52, unmodified; `tb/models/nand_flash_model.sv` hash-identical to P52's) per CE#, `TARGET_ID = CE index`.
  A device configuration `config/nandlab_regress.svcfg` (P52 profile `ideal`, tBERS 1 ms, factory-bad blocks, one forced program failure and one forced erase failure) is copied into each run directory.
* **Upstream handshake:** request channel `req_valid/req_ready` with op, tag, CE, LUN, block, page, column, length, buffer address, feature fields (a request is accepted at most every second cycle); completion channel
  `cpl_valid/cpl_ready` FIFO (`CPL_DEPTH`) with tag, op, status, NAND status byte, info0/info1, latency and device time; single-cycle CSR port; optional `irq`; SFB2 master for page data; `busy`, `timing_mode` status outputs.
* **Physical vs behavioural:** *synthesizable and verified in RTL/gate-level:* controller, timing engine, buffer master, FIFO, multichannel wrapper. *Placeholder / simulation-only:* `sfnc_io_sdr` (pads), the 2-FF R/B# sync,
  `CAPTURE_MARGIN_PS`. *Not present:* IO cells, SDC, I/O timing, board model, DQS/PHY calibration.

## 4. Evidence log (what I ran)

`cwd = $SP/work/p53/silicaflux-flashlink` unless stated. The regression runner builds one configuration per invocation here (same `scripts/regress.py`, `--only <cfg>`), so each command stays under the 8-minute cap.

| # | Command | Exit | Key output | Wall | Log |
|---|---|---|---|---|---|
| E1 | `make lint` | 0 | `LINT CLEAN`; table identical to the pristine `reports/lint.md` (7 configs: 0 Verilator warnings, 0 errors, Icarus elaboration ok) | 13.7 s | `p53/01_make_lint.log` |
| E2 | `python3 scripts/regress.py --sim verilator --only <cfg> --out audit_out/p53/reports_verilator_<cfg>` for cfg in base, negative, ce2, ce2_rbshared, clk200_q8, clk50, multichannel (the same code path as `make regress`/`make sim`) | all 0 | see table E2 below | per cfg 166-360 s, mostly build | `p53/02_regress_verilator_*.log` |
| E3 | same with `--sim icarus`, each config under `timeout 480` | `negative` 0, `multichannel` 0, `base` 124 (timeout) | see below | 21 s / 398 s / 480 s | `p53/02_regress_icarus_*.log` |
| E6 | **HYP** `work/p53_hyp` (patched COPY of the TB: `PD=2048, PS=64`, svcfg 2048+64, full-page program/read in the demo, plus 4 added CSR checks): Icarus `+TEST=demo`. (A Verilator build of the same copy hit my 480 s cap under load: `05_HYP_verilator_build_2048+64.log`, did not complete.) | 0 | **`[TB] demo: 19 passed, 0 failed`**: `GEO0 = {64 OOB, 2048 data}`, `GEO1 = 16`, `GEO2 = 64`, `GEO3[7:0] = 2 LUNs` loaded from the P52 parameter page; full 2,112-byte PROGRAM + READ-back exact at timing mode 0 and 5; LUN1 erase interleaved with LUN0 reads; **model protocol/timing = 0, monitor 73,301 checks / 0 violations**. The full `suite` was **not** run at 2048+64 (it hard-codes 512+16 expectations). | 133 s (run) | `p53/05_HYP_icarus_*`, `p53/05_HYP_result_demo_icarus_2048+64.txt` |
| E8 | `make gls` | GLS_EXIT | GLS_TEXT | GLS_WALL | `p53/03_make_gls.log` |
| E9 | **Not run as `make synth`** (5 Yosys runs + 3 nextpnr place-and-routes cannot fit one 480 s command on this host). Instead the same Yosys / nextpnr commands that `scripts/synth.py` issues were run as separate commands in copy `work/p53_synth`: (a) `yosys -p "read_verilog -sv <rtl/files.f>; hierarchy -check -top silicaflux_nand_controller; synth -flatten -top silicaflux_nand_controller; check -assert; stat"`; (b) `synth_ecp5 -top sfnc_fpga_harness`; (c) `nextpnr-ecp5 --45k --speed 8 ...`; (d) `--speed 6` | (a) 0 (b) 0 | (a) `Found and reported 0 problems`, **29,657 cells, 4,812 FF, 0 latches** (= project report); (b)+(c)+(d) PNR_TEXT | (a) 95 s (b) 111 s PNR_WALL | `p53/04_synth_*.log` |

E2 results (Verilator 5.020; pristine project report: identical counts):

| cfg | Parameters | Checks pass | Fail | Simulated time | Monitor checks / violations | Verilator wall (build+run) |
|---|---|---|---|---|---|---|
| `base` | defaults (1 CE, 2 LUN, 100 MHz, 4 slots) | **141** | 0 | 15.94 ms | 226,958 / 0 | 172 s (sim 7.3 s) |
| `negative` | defaults, mis-programmed timing | **4** | 0 | 1.00 ms | 93 / **22 (intended)** | 166 s |
| `ce2` | `NUM_CE=2` | **156** | 0 | 19.47 ms | 272,108 / 0 | 297 s |
| `ce2_rbshared` | `NUM_CE=2, RB_SHARED=1` | **156** | 0 | 19.47 ms | 272,108 / 0 | 356 s |
| `clk200_q8` | `CLK_PS=5000, QD=8` | **145** | 0 | 16.08 ms | 247,433 / 0 | 325 s |
| `clk50` | `CLK_PS=20000` | **141** | 0 | 16.21 ms | 224,996 / 0 | 291 s |
| `multichannel` | 2 channels x 1 CE | **28** | 0 | - | - | 208 s (re-run; see note) |
| **Total** | | **771 / 771** | 0 | | | |

Note: the first Verilator `multichannel` attempt was terminated by SIGTERM (exit 143) 11 s after it started — not a test failure (the process was killed from outside; other sessions share this host); log kept as `02_regress_verilator_multichannel_attempt1_KILLED_exit143.log`, re-run passed. All counts equal the pristine `reports/regression_both.md` row by row.

E3 (Icarus 12, each config under `timeout 480`): `negative` **4/4** (21 s), `multichannel` **28/28** (397 s); `base` **did not complete within the 480 s box** (the project's own report shows 193 s unloaded; the host was loaded 25-30x). `ce2`, `ce2_rbshared`, `clk200_q8` (project: 224 s / 215 s / 636 s) and `clk50` (91 s) were not attempted because of the time budget. So the "771/771 on Icarus" claim is **partially verified only (32 of 771 checks re-run)**.

E4 (`make demo PY=$SP/venv_p54/bin/python` in copy `work/p53_demo`, needs matplotlib 3.11.2 installed in the venv): Icarus demo simulation `[TB] demo: 15 passed, 0 failed`, `waves.py` rendered 9 waveforms; regenerated `docs/waveforms/MEASUREMENTS.md` is **byte-identical** to the shipped one (tWHR 120 ns, tADL 250 ns, tWB 200 ns, R/B# low 200.0 us for tPROG, tCCS 630 ns, mode-5 read cycle 30 ns, write cycle 20 ns, tADL 80 ns, erase R/B# low 1000.0 us), `marks.txt` identical; wall 3 m 35 s. Log `p53/06_make_demo.log`.

E5 (namespace smoke test, E13 of the P54 audit): `verilator --lint-only` and `iverilog -g2012` of P54 RTL + P53 RTL (+multichannel, +io_sdr) + the P52 model in one compilation: exit 0, no duplicate module/package/macro (`p54/26_integrated_namespace_smoke.log`).

## 5. Doc claims not reproduced / not substantiated

**Reproduced exactly (same numbers as the shipped reports):** lint 7/7 clean; Verilator regression 771/771 over 7 configs with identical per-config check counts, simulated times and monitor check counts (226,958 / 272,108 / 247,433 / 224,996, 0 violations); negative test (22 intended violations); `PERF` lines (read 8,089 cycles = 80.9 us at mode 0 and 4,241 cycles = 42.4 us at mode 5 at 100 MHz; program 25,484 / 21,136 cycles; 528-byte read data phase 5,342 cycles = 9.9 MB/s at mode 0 and 1,618 cycles = 32.6 MB/s at mode 5; whole-suite counters `CYCLES 328,999`, `BUS_BUSY 44,569`, 148 polls / 134 misses); waveform measurements (byte-identical `MEASUREMENTS.md`); generic Yosys numbers for the baseline (29,657 cells / 4,812 FF / 0 latches); "P52 model vendored unmodified, SHA-256 `070651e0...52cb`" (hash re-computed: identical in P52, P53, P54, P55).

**Not reproduced / not fully reproduced:**
* **"771/771 on Icarus Verilog 12"** — only `negative` (4/4) and `multichannel` (28/28) completed here; `base` did not finish within 480 s; `ce2`, `ce2_rbshared`, `clk200_q8`, `clk50` not attempted. Evidence for Icarus parity is therefore 32/771 checks re-run.
* **"Synthesis: ... 4 other configurations (noperf, 4CE/8 slots, x16/64-bit buffer, 2-channel wrapper)"** — not re-run (only the baseline).
* **ECP5 numbers (66.2 MHz -6 / 84.9 MHz -8; 25F placement failure)** — see E9 for what finished; the 25F run was not attempted.
* **Gate-level simulation 141/141** — see E8.
* **`x16` and `BUF_DW=64` operation** — not simulable (no x16 device model); only lint.
* **"Zero violations in ~227,000 monitor checks"** — true (reproduced), but only for the shipped stimulus; it never exercised bit errors, power loss, read retry, or any geometry other than 512+16.

**Not substantiated by the project:** correctness of the ONFI-style timing table against any ONFI revision or datasheet — "transcribed"; controller table, monitor table and P52 model are the same values, so passing the checkers is **common-mode** and says nothing about a real part (the project states this itself). `docs/03` §1 says "where the two transcriptions differed (tWHR in modes 3-5) the larger value is used", but the shipped P52 and P53 tables are both 80 ns for modes 1-5 (the BFM uses 100 ns), so that sentence cannot be checked from the sources.

**Doc inconsistencies (minor):** the README's "two concurrent channels" is true but only with one CE per channel; the README quick-start lists nextpnr-ecp5 as needed for `make synth` (it is). No contradictions found in the reproduced numbers.

## 6. Reusable interface reference

### 6.1 `module silicaflux_nand_controller` (file `rtl/silicaflux_nand_controller.sv`; compile list `rtl/files.f`: `silicaflux_nand_pkg.sv, silicaflux_nand_timing_pkg.sv, sfnc_sync.sv, sfnc_fifo.sv, sfnc_timing_engine.sv, sfnc_buf_master.sv, silicaflux_nand_controller.sv`)

Parameters (default): `DQ_WIDTH 8` (8|16), `NUM_CE 1` (1..8), `RB_SHARED 0`, `NUM_LUN_MAX 2` (1..8), `QUEUE_DEPTH 4` (2..16), `CPL_DEPTH 4` (pow2), `TAG_W 8`, `BUF_DW 32` (32|64),
`CLK_PERIOD_PS 10000`, `CAPTURE_MARGIN_PS 2000`, `TIMING_MODE_RST 0`, `PAGE_BYTES_MAX 16384`, `OOB_BYTES_MAX 2048`, `PAGES_PER_BLOCK_MAX 1024`, `BLOCKS_PER_LUN_MAX 65536`,
`DEF_PAGE_BYTES 512`, `DEF_OOB_BYTES 16`, `DEF_PAGES_PER_BLOCK 16`, `DEF_BLOCKS_PER_LUN 64`, `DEF_LUNS 1`, `DEF_ROW_CYCLES 3`, `DEF_COL_CYCLES 2`, `TMO_READ_US 2000`, `TMO_PROG_US 10000`,
`TMO_ERASE_US 50000`, `TMO_TGT_US 10000`, `POLL_READ_US 10`, `POLL_PROG_US 100`, `POLL_ERASE_US 1000`, `POLL_IV_US 5`, `ENABLE_PERF 1`. (`NUM_RB = RB_SHARED ? 1 : NUM_CE`.)

| Port | Dir | Width | Meaning |
|---|---|---|---|
| `clk`, `rst_n` | in | 1 | single clock; reset async-assert / sync-release by the integrator |
| `req_valid` / `req_ready` | in / out | 1 | request handshake (ready low one cycle after each accept) |
| `req_op` | in | 4 | `OP_*` (see 6.3) |
| `req_tag` | in | TAG_W | returned in completion |
| `req_ce`, `req_lun` | in | 3, 3 | target and LUN |
| `req_block` | in | 24 | block within the LUN |
| `req_page` | in | 16 | page within block |
| `req_col`, `req_len` | in | 16, 16 | byte column (data + OOB), byte length; READ_ID: count (0 -> 5); READ_PARAM: non-zero -> store 256 B in buffer |
| `req_buf` | in | 32 | buffer byte address, `BUF_DW/8`-aligned; page byte i at `req_buf + i` |
| `req_faddr`, `req_fdata` | in | 8, 32 | feature / READ ID address; SET FEATURES P1..P4 (P1 in [7:0]) |
| `cpl_valid` / `cpl_ready` | out / in | 1 | completion handshake |
| `cpl_tag`, `cpl_op`, `cpl_status`, `cpl_nand_status` | out | TAG_W, 4, 4, 8 | tag, op, `CS_*` code, NAND status byte |
| `cpl_ce`, `cpl_lun` | out | 3, 3 | |
| `cpl_info0`, `cpl_info1` | out | 32, 32 | per-op (READ_ID: ID bytes 3..0 / 7..4; READ_PARAM: data / `{LUNs,addr cycles,copy,sig_ok,crc_ok,supported,loaded,timing modes}`; READ_STATUS: status; READ/PROGRAM: bytes, row address; GET_FEATURES: P4..P1) |
| `cpl_latency`, `cpl_dev_time` | out | 32, 32 | accept->completion cycles; confirm->ready cycles |
| `csr_sel`, `csr_we`, `csr_addr[7:0]`, `csr_wdata[31:0]` | in | | single-cycle CSR write/read |
| `csr_rdata[31:0]`, `csr_err` | out | | combinational read data, unmapped/RO-write error |
| `m_req_valid/ready/write`, `m_req_addr[31:0]`, `m_req_wdata[BUF_DW-1:0]`, `m_req_wstrb[BUF_DW/8-1:0]`, `m_rsp_valid/ready`, `m_rsp_rdata[BUF_DW-1:0]`, `m_rsp_error` | | | SFB2 master (one outstanding single-beat transaction; byte strobes; `m_rsp_ready` held 1) |
| `nand_ce_n[NUM_CE-1:0]`, `nand_cle`, `nand_ale`, `nand_we_n`, `nand_re_n`, `nand_wp_n` | out | | registered pins |
| `nand_dq_o[DQ_WIDTH-1:0]`, `nand_dq_oe`, `nand_dq_i[DQ_WIDTH-1:0]` | out/out/in | | split bidirectional DQ |
| `nand_rb_n[NUM_RB-1:0]` | in | | R/B# (asynchronous; synchronised internally) |
| `irq`, `busy`, `timing_mode[2:0]` | out | | status |

### 6.2 `module silicaflux_nand_multichannel` (+ `rtl/silicaflux_nand_multichannel.sv`)
Parameters `NUM_CH 2, DQ_WIDTH 8, NUM_CE 1, RB_SHARED 0, NUM_LUN_MAX 2, QUEUE_DEPTH 4, CPL_DEPTH 4, TAG_W 8, BUF_DW 32, CLK_PERIOD_PS 10000, DEF_LUNS 1`. Same request/completion/CSR ports as above plus
`req_ch[2:0]` (in), `cpl_ch[2:0]` (out), `csr_addr[10:8]` = channel; SFB2 and pin ports flattened `[NUM_CH*...]`. A request for a missing channel completes with `BAD_ADDR`.

### 6.3 Encodings
* `req_op`: RESET 0, READ_ID 1, READ_PARAM 2, READ_STATUS 3, READ_PAGE 4, PROGRAM_PAGE 5, ERASE_BLOCK 6, SET_FEATURES 7, GET_FEATURES 8.
* `cpl_status` (`CS_*`): OK 0, DEV_FAIL 1, TIMEOUT 2, BAD_OP 3, BAD_ADDR 4, ALIGN 5, WP 6, NOT_RESET 7, PROG_ORDER 8, BUF_ERR 9, PARAM_CRC 10, UNSUPPORTED 11, NOT_READY 12.
* NAND opcodes emitted: 00h/30h read, 05h/E0h change read column, 80h/10h program, 60h/D0h erase, 70h/78h status, 90h ID, ECh param page, EEh/EFh get/set features, FFh reset; feature address `01h` = timing mode (`FA_TIMING_MODE`).
* NAND status bits used: FAIL(0), FAILC(1), ARDY(5), RDY(6), WP#(7).
* CSR map (byte offsets; source of truth `silicaflux_nand_pkg.sv`, doc `docs/REGISTERS.md`): `0x00 ID = 0x53463533 ("SF53")`, `0x04 VERSION {0x0100, DQ_WIDTH, NUM_CE}`, `0x08 CONFIG`, `0x0C CTRL (reset 0x000417C1)`,
  `0x10 STATUS`, `0x14 TMODE`, `0x18..0x24 TIM0..TIM3`, `0x28 GEO0 {OOB, page}`, `0x2C GEO1 pages/block`, `0x30 GEO2 blocks/LUN`, `0x34 GEO3 {mode mask, col cycles, row cycles, LUNs}`, `0x38 GEO4 {tCCS, tR}`, `0x3C GEO5 {tBERS, tPROG}`,
  `0x40..0x4C TMO_*`, `0x50..0x5C POLL_*`, `0x60 PERF_CTRL`, `0x64+4n PERF[0..22]`, `0xC0 ERR (RW1C)`, `0xC4 TGT`, `0xC8 GEO6`. CTRL bits: EN0 WP_N1 INTERLEAVE2 RD_PRIO3 USE_ENH4 MULTI_LUN5 AUTO_GEO6 AUTO_TIM7 AUTO_TMO8 ORDER_CHK9 POLL_EN10 IRQ_EN11 TMO_EN12, STARVE[19:16].
  **Reset value has WP_N = 0 and INTERLEAVE = 0**: a bring-up sequence must set `WP_N` before PROGRAM/ERASE and `INTERLEAVE` for concurrency.
* Bring-up order verified by the TB: `CTRL.EN`, RESET every target (all other ops except READ_STATUS return `NOT_RESET` until then), `OP_READ_PARAM` (loads geometry/timing/timeouts if `AUTO_GEO`), optional SET FEATURES timing mode (all targets first on multi-CE channels).
* Address cycles: row = `page | block << ceil(log2 ppb) | lun << (page bits + block bits)`, `rowc` (2/3) and `colc` (1/2) cycles from the parameter page, LSB first.

### 6.4 `sfnc_io_sdr` (SIM) pin boundary
`#(DQW, NUM_CE, NUM_RB, TECH="SIM")`: controller side `c_ce_n, c_cle, c_ale, c_we_n, c_re_n, c_wp_n, c_dq_o, c_dq_oe, c_dq_i, c_rb_n`; pad side `pad_ce_n ... pad_dq (inout), pad_rb_n`.

## 7. Integration risks / incompatibilities

Geometry matrix: see the P52 audit section 7 (identical table reproduced in the P54 audit). From P53's side:

1. **P54 data path mismatch.** P53 moves page bytes between NAND and an **SFB2 memory** (`req_buf`, 32/64-bit words, byte strobes); P54 consumes/produces **8-bit ready/valid streams** (`rd_raw_*`, `wr_raw_*`). Needs an SFB2<->stream DMA adapter (not written anywhere; P53 docs/01 §6 and P54 docs/00 §4 both target P51's `sfs_nand_ctrl`, not each other).
2. **Spare-first read order (P54) vs P53's READ_PAGE.** P54's decoder wants PAGE_SPARE bytes first, then PAGE_DATA, so that no page buffer is needed. `OP_READ_PAGE` takes one `(col,len)` window per array read and always follows `30h` with `05h col E0h`. To get spare-first you must either (a) read the whole 528/2112-byte page into the SFB2 buffer and have the adapter replay it spare-first (a page buffer exists anyway), or (b) issue two READ_PAGEs (2 x tR). Neither has been simulated.
3. **P54 is not wired to P53 anywhere**; P54's NAND-twin tests use P52's `nand_ctrl_bfm`, P53's tests use no ECC. The combination P52+P53+P54 has **zero** simulation evidence.
4. **Geometry evidence is thin:** verified 512+16 / 16 ppb / 64 blk / 2 LUN. P54's N2KT8 (2048+64) / N8KT40 (8192+744) layouts and P52's `slc_1gbit_class` were not run through P53 by its authors. HYP E6 below gives partial evidence for 2048+64.
5. **Runtime vs compile-time geometry.** P53 learns geometry at run time (parameter page, `GEO0..3`); P54's page format (`PAGE_DATA/PAGE_SPARE/SECTOR/T`) is elaboration-time. Nothing cross-checks them; add a bring-up assertion `P53.GEO0 == {P54.CFG2.spare, P54.CFG2.data}`.
6. **No error traffic ever tested** (ideal profile); P53 reports `DEV_FAIL`/`TIMEOUT` but has no read-retry sequencing; UNCORRECTABLE handling (SET FEATURES A0h + re-READ) must be firmware or a new block.
7. **Clock:** ECP5 implementation reaches only 66/85 MHz vs the 100 MHz used in sims; P54 full engine 74-78 MHz. Compatible only at <= ~74 MHz, or with CLK_PERIOD_PS matched to the real clock.
8. **Resource names:** modules `silicaflux_nand_controller`, `silicaflux_nand_multichannel`, `sfnc_*`, packages `silicaflux_nand_pkg`, `silicaflux_nand_timing_pkg`, include guards `SILICAFLUX_NAND_PKG_SV`/`SILICAFLUX_NAND_TIMING_PKG_SV`: no collision with P52/P54 (scan of all extracted projects). P55 vendors **byte-identical** copies of these files under `third_party/silicaflux-flashlink` — an integrated filelist must include each file once.
9. **Compile-order/timescale:** P53 RTL files carry no `` `timescale``; they inherit whatever the previously compiled file set (P52/P54 files set 1ns/1ps). Verilator needs `-Wno-TIMESCALEMOD` (the project's scripts pass it). Each P53 file restores `` `default_nettype wire`` at its end (safe).
10. **Packages referenced as `pkg::NAME`** (Yosys 0.33 limitation) — no `import` — fine for mixed integration; requires the package files first in the compile order.
11. **SFB2 only.** Anything else on the buffer side needs an adapter. One outstanding transaction, >= 3 cycles per 32-bit word.

## 8. Licensing notes
* No LICENSE/COPYING in the archive; headers say "Aureom.AI | SilicaFlux-STORE". No third-party source bundled except the vendored P52 model (same owner). Tools: Verilator (LGPL-3/Artistic), Icarus (GPL-2, tool only), Yosys (ISC), nextpnr (ISC).
* No GPL code in the RTL deliverable. docs/00_AUDIT.md itself says "No licence file exists in the repository".
