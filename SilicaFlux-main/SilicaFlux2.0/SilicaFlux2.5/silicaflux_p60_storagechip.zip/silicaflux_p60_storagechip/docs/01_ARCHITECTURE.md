# 01 — Architecture of SilicaFlux-STORE (P60)

## 1. Block diagram (SILICAFLUX_STORE_MIN, as built and verified)

```
                      host (simulated NVMe-like driver; UART bridge on FPGA)
         BAR (SFB2 slave 32 b)  │                       ▲ host memory master (DMA, SFB2)        ▲ irq_o / host_irq_o
 ┌──────────────────────────────▼───────────────────────┼──────────────────────────────────────┼────────────────────┐
 │ silicaflux_storage_top                               │                                      │                    │
 │  por_n ─► sfx_rst_sync        pwr_fail_n ─► sfx_pwr_cond (2-FF sync + glitch filter)                              │
 │  sfx_hb_split ──┬── 0xC000_0000 ► sfx_top_ctrl  (chip IRQ controller, pin-level perf counters, reset cause, DFT)   │
 │                 │                  └─ 0xC000_1000 ► sftc_testcore_top  (P07: JTAG TAP, test-mode ctl, MBIST engine)│
 │                 └── silicaflux_storage_soc                                                                         │
 │   ┌─────────────────────────────────────────────────────────────────────────────────────────────────────────┐    │
 │   │ ControlCore (P21) RV32IM · boot ROM · IMEM 64 KiB · DMEM 32 KiB · INTC · MTIMER · WDT · PMU · perf · RAS │    │
 │   │ mailbox · secmon                                         runs the P60 firmware (C)                        │    │
 │   ├─────────────────────────────────────────────────────────────────────────────────────────────────────────┤    │
 │   │ sfs_storage_subsys (P51, P60-patched)                                                                     │    │
 │   │  sfs_host_if (SQ/CQ rings, doorbells)  ─ cmd ─► sfs_cmd_ctrl (validation, tag table, FWQ, completions)    │    │
 │   │  Storage DataFabric (sfb_crossbar):  masters  m0 ControlCore EXT · m1 sfs_dma (host DMA) ·                │    │
 │   │                                               m2 sfs_nand_ctrl ch0 · m3 sfx_page_engine (P60)            │    │
 │   │                                      slaves   s0 BUFFER SRAM 16 KiB (SECDED, RAS) · s1 host-memory window │    │
 │   │  sfs_nand_ctrl : ONFI-style x8 SDR sequencer (raw page transfer; inline ECC disabled)                     │    │
 │   │  sfx_page_engine: ECCCore BCH t=8 (P54, config N512T8U16)  +  SecureStore XTS-AES-256 (P60, new)         │    │
 │   │  sfs_sys_regs  : IRQ aggregation, power-fail/quiesce/WP#, security locks, RAS, perf counters              │    │
 │   └─────────────────────────────────────────────────────────────────────────────────────────────────────────┘    │
 └─────────────────────────────────────────────────────────────────────────────┬────────────────────────────────────┘
                                                      CE# CLE ALE WE# RE# WP# DQ[7:0] R/B#      │ JTAG (TAP)
                                                                                 NAND device (P52 digital twin in simulation)
```

## 2. Provenance of every block

| Block | Source | Status in P60 |
|---|---|---|
| ControlCore, DataFabric, sramlib, RAS, host IF, cmd controller, DMA, NAND sequencer, sys regs | P51 (vendored under `vendor/p51/`) | unmodified |
| `sfs_storage_subsys.sv` | P51 | **patched** by `scripts/make_subsys.py` (+1 fabric master, +register page 15, +idle/event wiring); delta in `patches/subsys_page_engine.patch` (33 added lines) |
| BCH ECC engine + page format | P54 (`vendor/p54/`) | unmodified RTL; **new configuration `N512T8U16`** added to `vendor/p54/ref/sfecc_configs.py` (+ the page plan in `vendor/p54/scripts/gen_vectors.py`; originals kept as `*.p54orig`) and regenerated (`vendor/p54/rtl/generated/sfecc_cfg.svh`, `vendor/p54/docs/OOB_BUDGET.md`) |
| XTS-AES core, S-box, key expansion | **new** (`rtl/security/`) — P59 does not exist | new |
| Page engine (`sfx_page_engine`) | **new** (`rtl/storage/`) | new |
| TestCore (JTAG TAP, test-mode controller, MBIST engine) | P07 (`vendor/p07_testcore/`) | unmodified, 14 files |
| Top, reset sync, power conditioning, host-BAR splitter, chip control | **new** (`rtl/top/`) | new |
| NAND model (testbench) | P52 (`vendor/p52/`) | `tb/models/nand_flash_model_p60.sv` = P52 + one back door (`bd_flip`), patch in `patches/nand_model_bd_flip.patch` |
| FTL library | P58 "1.1" (`vendor/p58b/firmware/silicaflux_ftl/`) | unmodified |
| Firmware (HAL, executor, boot policy, main) | **new** (`fw/app/`); platform layer from P51 | new |

## 3. Clocking, reset, power

* One clock `clk` (100 MHz assumed in simulation; the FPGA wrapper uses the board clock directly, no PLL).
* `por_n`: asynchronous assertion, synchronous release (2 flops, `sfx_rst_sync`); bypassed in scan mode so scan can control it.
* `pwr_fail_n`: 2-flop synchroniser + glitch filter (`PF_FILTER` = 4 cycles); a supply glitch shorter than that is ignored.
  On a sustained fault: hardware refuses new commands (`ABORT_PWR_LOSS / QUIESCED`), firmware stops starting NAND program/erase
  (STOP policy), asserts WP#, and after the supply returns **remounts the FTL** (recovery path). **No hold-up energy is assumed
  anywhere; durability never depends on it.**
* Power gating and multiple clock domains: none (see limitations).

## 4. Address map

| Space | Base | Content |
|---|---|---|
| Host BAR, management | `0x0000_0000` | ControlCore host port: boot ROM, IMEM `0x0001_0000`, DMEM, mailbox, sysctrl (firmware image is loaded here) |
| Host BAR, controller | `0x8000_0000` | SQ ring `+0x1000` (32 B entries), CQ ring `+0x2000` (16 B entries), doorbells/status/capacity (`SFS_SHC_*`) |
| Host BAR, chip local | `0xC000_0000` | `sfx_top_ctrl` (offset 0x0000–0x0FFF), TestCore registers (0x1000–0x1FFF) |
| ControlCore registers | `0x4000_0000` + page·4 KiB | pages 10–14 SYS/CMD/DMA/NAND/HIF (P51), **page 15 = page engine** (`0x4000_F000`) |
| Storage fabric | BUF `0x2000_0000`, HOSTMEM `0x3000_0000` | buffer slots (544 B stride): 0 = plain page (S), 1 = raw page (R), 2 = host staging / identify / log |

## 5. Configurations

| | SILICAFLUX_STORE_MIN (implemented, verified) | SILICAFLUX_STORE_HPC (partial) |
|---|---|---|
| NAND channels | 1 (x8 SDR) | RTL elaborates 1–4 (P51 generic) — **firmware/HAL/verification: MIN only** |
| Host interface | SQ/CQ ABI on an SFB2 BAR; simulated host | would use P57's NVMe front end (**not integrated**); PCIe endpoint: **no IP available** |
| Buffer | 16 KiB SECDED SRAM | larger SRAM/DRAM: P55 DRAM adapter is simulation-only (**not integrated**) |
| ECC | BCH t=8 / 512 B + CRC-16 (+ FTL CRC-32) | "advanced ECC research" = P54 LDPC PoC (simulation-only, **not integrated**) |
| Telemetry | GET_LOG page 0 (72 words), chip perf counters | enterprise telemetry: not implemented beyond GET_LOG |
| FTL | firmware page-mapping FTL, GC, WL, crash recovery | L2P is RAM-resident (4 B/page): a DRAM-backed map is required beyond ~5 k pages |

## 6. Repository layout (this archive)

```
rtl/{top,soc,storage,security}/  vendor/{p51,p52,p54,p58b,p07_testcore}/  fw/  tb/{soc,storage,security,models}/
fpga/  dft/  pd/  endurance/  bench/  dashboard/  scripts/  patches/  reports/  docs/
```
