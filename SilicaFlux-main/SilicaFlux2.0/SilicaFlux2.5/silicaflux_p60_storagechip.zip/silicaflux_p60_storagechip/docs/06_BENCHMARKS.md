# 06 — Benchmarks (simulation only)

Results and the honest reading notes are in [`../reports/BENCH.md`](../reports/BENCH.md) (machine-readable: `../reports/bench.json`; the dashboard embeds them).

## Method (reproducible)
```bash
make tb                  # Verilated full chip (build/tb/v/Vtb) + firmware
make bench               # scripts/run_tb.sh bench bench  &&  python3 bench/parse_bench.py build/run/bench/run.log reports
```
* Scenario `bench` (`tb/soc/tb_p60_scenarios.svh`): the device is **filled once** (steady-state precondition), then phases run in a fixed order: sequential read (8-LBA), random read at QD 1/2/4/8, sequential write, random write at QD 1/4/8, mixed 70/30 at QD 4, random write after TRIM of half the namespace, random write in steady-state GC; finally a clean shutdown + remount and a power cut + recovery (**recovery overhead**).
* Numbers are **RTL simulation cycles**. Time = cycles ÷ an **assumed 100 MHz** core clock (`--clk-mhz`). The twin's NAND array times (read/program/erase) are **scaled ×1/10** to keep simulation tractable; bus timings are real (ONFI mode 0 programmed by the firmware).
* Latency percentiles come from a **hardware monitor** in the command controller (command accepted → completion posted), not from the testbench. Phases have 40–400 samples; P99/P99.9 are essentially the maximum.
* Throughput = payload bytes ÷ simulated time; IOPS = commands ÷ simulated time; write amplification = NAND programs (host + GC relocation + metadata) ÷ host LBAs written, from the controller's GET_LOG counters; channel utilisation = NAND R/B# low cycles ÷ cycles (chip-level counter); error counts and ECC corrections from GET_LOG.

## What is *not* measured, and why
Multi-channel scaling (the firmware drives one channel), buffer-occupancy under load (fixed 3-slot working set), ECC latency versus injected-error count, tail latency at realistic sample sizes, any host-interface bandwidth (no PCIe; host memory is a simulation model). These are listed in `reports/BENCH.md` and `11_KNOWN_LIMITATIONS.md`.
**No number in this repository is a hardware measurement, and none may be quoted as a product specification.**
