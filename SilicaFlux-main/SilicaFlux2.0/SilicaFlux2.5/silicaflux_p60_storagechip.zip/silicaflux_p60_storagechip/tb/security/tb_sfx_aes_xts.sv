// -----------------------------------------------------------------------------
// tb_sfx_aes_xts -- self-checking testbench for sfx_aes_xts / sfx_aes_core
// Project: SilicaFlux-STORE P60 (SecureStore)
//
// Parameter KEYBITS (128|256) selects XTS-AES-128 / XTS-AES-256 (size of EACH key).
// Vectors come from gen_xts_vectors.py ($readmemh files in +VECDIR, default ".").
// Plusargs: +VECDIR=<dir>  +LONGN=<blocks> (long-unit test, 0 = skip, default 0)
//           +GROUPS=<hex mask> run only some test groups (debug aid; default all: core,keyexp,
//           latency,xts,stress,protocol,zeroize = bits 0..6)
//
// Prints "TB_PASS checks=N" or "TB_FAIL checks=N fails=M" as its last line.
//
// Driving discipline (race-free in both Icarus and Verilator 5.020): a process snapshots
// the DUT outputs 1 ns before each rising edge; tasks wait for the edge, then 1 ns, then
// read the snapshots (= the values at the edge) and drive new inputs with blocking
// assignments (the DUT has sampled the old inputs at the edge).  Plain NBAs from
// initial-block tasks are executed as blocking by Verilator and race with the DUT.
// -----------------------------------------------------------------------------
`timescale 1ns/1ps

module tb_sfx_aes_xts;
  parameter int KEYBITS = 128;

  localparam int NK         = KEYBITS/32;
  localparam int NR         = NK + 6;
  localparam int NW         = 4*(NR+1);
  localparam int KH         = KEYBITS/128;          // 128-bit vector words per key
  localparam int KS         = 2*KH;                 // key words per xts record
  localparam int RKW        = 32*NW;
  localparam int VMEM_N     = 262144;
  // documented timing (README): cycle numbers relative to the cycle in which start is high
  localparam int KEYEXP_CYC = 2*(NW-NK) + 5;        // key_commit cycle -> first key_ready cycle
  localparam int LAT_IN     = NR + 2;               // start -> first in_ready
  localparam int LAT_OUT    = 2*NR + 3;             // start -> first out_valid (unstalled)
  localparam int PERIOD     = NR + 2;               // cycles per block (unstalled)

  // ------------------------------------------------------------------ DUT
  logic         clk = 1'b0;
  logic         rst_n;
  logic         key_we, key_commit, key_zeroize;
  logic [4:0]   key_widx;
  logic [31:0]  key_wdata;
  logic         start, decrypt;
  logic [127:0] tweak;
  logic [15:0]  nblocks;
  logic         in_valid, out_ready;
  logic [127:0] in_data;
  wire          key_ready_o, start_err_o, in_ready_o, out_valid_o, out_last_o, busy_o;
  wire  [127:0] out_data_o;
  // Snapshots of the DUT outputs, taken 1 ns before every rising clock edge: all TB code
  // (tasks and monitor) reads these, i.e. the values the DUT/handshake sees AT the edge.
  logic         key_ready, start_err, in_ready, out_valid, out_last, busy;
  logic [127:0] out_data;

  sfx_aes_xts #(.KEYBITS(KEYBITS)) dut (
    .clk(clk), .rst_n(rst_n),
    .key_we(key_we), .key_widx(key_widx), .key_wdata(key_wdata),
    .key_commit(key_commit), .key_zeroize(key_zeroize), .key_ready(key_ready_o),
    .start(start), .decrypt(decrypt), .tweak(tweak), .nblocks(nblocks), .start_err(start_err_o),
    .in_valid(in_valid), .in_ready(in_ready_o), .in_data(in_data),
    .out_valid(out_valid_o), .out_ready(out_ready), .out_data(out_data_o), .out_last(out_last_o),
    .busy(busy_o)
  );

  // standalone AES core (direct FIPS-197 tests)
  logic            c_clr, c_start, c_dec;
  logic [127:0]    c_blk;
  logic [RKW-1:0]  c_rk;
  wire             c_busy_o, c_vld_o;
  wire  [127:0]    c_out_o;
  logic            c_busy, c_vld;
  logic [127:0]    c_out;

  sfx_aes_core #(.KEYBITS(KEYBITS)) ucore (
    .clk(clk), .rst_n(rst_n), .clr(c_clr), .rk(c_rk),
    .start(c_start), .dec(c_dec), .blk_in(c_blk),
    .busy(c_busy_o), .vld(c_vld_o), .blk_out(c_out_o)
  );

  always #5 clk = ~clk;                  // posedge at 5, 15, 25 ... ns

  always @(negedge clk) begin
    #4;                                   // 1 ns before the next posedge
    key_ready = key_ready_o; start_err = start_err_o; in_ready = in_ready_o;
    out_valid = out_valid_o; out_last = out_last_o;   busy     = busy_o;
    out_data  = out_data_o;
    c_busy    = c_busy_o;    c_vld    = c_vld_o;      c_out    = c_out_o;
  end

  // ------------------------------------------------------------------ bookkeeping
  integer n_checks = 0;
  integer n_fail   = 0;
  integer g_chk0, g_fail0;
  string  g_name;

  // assertion-style check counters
  integer a1_n = 0, a2_n = 0, a3_n = 0, a4_n = 0, a5_n = 0;
  integer n_units = 0, n_beats = 0;

  task chk(input logic cond, input string what);
    begin
      n_checks = n_checks + 1;
      if (!cond) begin
        n_fail = n_fail + 1;
        if (n_fail <= 40) $display("FAIL [%0t] %s", $time, what);
      end
    end
  endtask

  task grp_begin(input string name);
    begin
      g_name = name; g_chk0 = n_checks; g_fail0 = n_fail;
    end
  endtask

  task grp_end;
    begin
      $display("GROUP %-34s checks=%0d fails=%0d", g_name, n_checks - g_chk0, n_fail - g_fail0);
    end
  endtask

  // deterministic xorshift32 (identical sequence in every simulator)
  logic [31:0] rng = 32'h2545F491;
  function [31:0] rnd32(input integer dummy);
    begin
      rng = rng ^ (rng << 13);
      rng = rng ^ (rng >> 17);
      rng = rng ^ (rng << 5);
      rnd32 = rng + dummy;
    end
  endfunction

  logic [127:0] tmp128;
  task rnd128(output logic [127:0] r);
    logic [31:0] a, b, c, d;
    begin
      a = rnd32(0); b = rnd32(0); c = rnd32(0); d = rnd32(0);
      r = {a, b, c, d};
    end
  endtask

  // wait for the next rising edge, then 1 ns: the DUT has sampled our inputs, so we may
  // change them now; the snapshot variables still hold the pre-edge DUT outputs.
  task tick;
    begin
      @(posedge clk);
      #1;
    end
  endtask

  // ------------------------------------------------------------------ vector memories
  logic [127:0] vmem   [0:VMEM_N-1];     // xts records
  logic [127:0] amem   [0:4095];         // aes records
  logic [127:0] capbuf [0:65535];        // captured output of the last encrypt run
  integer       rbase  [0:1023];
  integer       abase  [0:255];
  integer       nrec, narec;
  string        vecdir;
  integer       longn;

  function integer rec_n(input integer rb);
    rec_n = vmem[rb][15:0];
  endfunction

  function integer rec_cat(input integer rb);
    rec_cat = vmem[rb][23:16];
  endfunction

  task index_xts;
    integer i;
    begin
      nrec = vmem[0][31:0];
      rbase[0] = 1;
      for (i = 0; i < nrec && i < 1023; i = i + 1)
        rbase[i+1] = rbase[i] + 2 + KS + 2*rec_n(rbase[i]);
    end
  endtask

  task index_aes;
    integer i;
    begin
      narec = amem[0][31:0];
      abase[0] = 1;
      for (i = 0; i < narec && i < 255; i = i + 1)
        abase[i+1] = abase[i] + 1 + KH + (NR+1) + 2;
    end
  endtask

  // ------------------------------------------------------------------ stimulus helpers
  integer burst_left [0:1];
  logic   burst_val  [0:1];

  // profile: 0 always, 1 = 6/8, 2 = 4/8, 3 = 1/8, 4 = bursty, 5 = never
  function logic pick(input integer prof, input integer ch);
    logic [31:0] r;
    begin
      r = rnd32(0);
      case (prof)
        0: pick = 1'b1;
        1: pick = (r[2:0] < 3'd6);
        2: pick = (r[2:0] < 3'd4);
        3: pick = (r[2:0] == 3'd0);
        5: pick = 1'b0;
        default: begin
          if (burst_left[ch] <= 0) begin
            burst_val[ch]  = r[8];
            burst_left[ch] = 1 + r[7:3];
          end
          burst_left[ch] = burst_left[ch] - 1;
          pick = burst_val[ch];
        end
      endcase
    end
  endfunction

  task idle_inputs;
    begin
      key_we = 1'b0; key_commit = 1'b0; key_zeroize = 1'b0; key_widx = 5'd0; key_wdata = 32'h0;
      start = 1'b0; decrypt = 1'b0; tweak = 128'h0; nblocks = 16'h0;
      in_valid = 1'b0; in_data = 128'h0; out_ready = 1'b0;
      c_clr = 1'b0; c_start = 1'b0; c_dec = 1'b0; c_blk = 128'h0;
    end
  endtask

  task do_reset(input integer ncyc);
    integer i;
    begin
      idle_inputs;
      rst_n = 1'b0;
      for (i = 0; i < ncyc; i = i + 1) tick;
      rst_n = 1'b1;
      tick;
    end
  endtask

  // all key-bearing registers of the DUT (hierarchical references)
  function logic regs_all_zero(input integer dummy);
    begin
      regs_all_zero = (dut.rk1_q === {RKW{1'b0}}) && (dut.rk2_q === {RKW{1'b0}}) &&
                      (dut.t_q === 128'h0) && (dut.u_kx.win_q === {KEYBITS{1'b0}}) &&
                      (dut.u_core.state_q === 128'h0) && (dut.kmask_q === {2*NK{1'b0}});
    end
  endfunction

  task chk_regs_zero(input string tag);
    begin
      chk(dut.rk1_q === {RKW{1'b0}},        {tag, ": rk1 (key1 + schedule) all zero"});
      chk(dut.rk2_q === {RKW{1'b0}},        {tag, ": rk2 (key2 + schedule) all zero"});
      chk(dut.t_q === 128'h0,               {tag, ": tweak state T all zero"});
      chk(dut.u_kx.win_q === {KEYBITS{1'b0}}, {tag, ": key-expander window all zero"});
      chk(dut.u_core.state_q === 128'h0,    {tag, ": AES state all zero"});
      chk(dut.kmask_q === {2*NK{1'b0}},     {tag, ": key-written mask zero"});
      chk(key_ready === 1'b0,               {tag, ": key_ready low"});
    end
  endtask

  // write one 32-bit key word (one cycle)
  task key_word(input integer w, input logic [31:0] d);
    begin
      key_we = 1'b1; key_widx = w[4:0]; key_wdata = d;
      tick;
      key_we = 1'b0; key_widx = 5'd0; key_wdata = 32'h0;
    end
  endtask

  // key word w (0..2*NK-1, key1||key2) of xts record rb
  function logic [31:0] xts_keyword(input integer rb, input integer w);
    logic [127:0] x;
    begin
      x = vmem[rb + 1 + w/4];
      xts_keyword = x[32*(w%4) +: 32];
    end
  endfunction

  function logic [31:0] aes_keyword(input integer ab, input integer w);   // w in 0..NK-1
    logic [127:0] x;
    begin
      x = amem[ab + 1 + w/4];
      aes_keyword = x[32*(w%4) +: 32];
    end
  endfunction

  // pulse key_commit, wait for key_ready; returns cycles from the commit cycle
  integer r_kcyc;
  task commit_and_wait(input integer limit);
    begin
      key_commit = 1'b1;
      tick;                         // edge ending the commit cycle (cycle 0)
      key_commit = 1'b0;
      r_kcyc = 0;
      while (!key_ready && r_kcyc < limit) begin
        tick;
        r_kcyc = r_kcyc + 1;
      end
    end
  endtask

  // load keys of xts record rb through the key interface, commit, wait
  task key_setup(input integer rb);
    integer w;
    begin
      for (w = 0; w < 2*NK; w = w + 1) key_word(w, xts_keyword(rb, w));
      commit_and_wait(4*KEYEXP_CYC);
      chk(key_ready === 1'b1, "key_ready after commit");
      chk(r_kcyc == KEYEXP_CYC, "key expansion latency == documented");
      for (w = 0; w < NK; w = w + 1) begin
        chk(dut.rk1_q[32*w +: 32] === xts_keyword(rb, w),      "key1 word retained in schedule");
        chk(dut.rk2_q[32*w +: 32] === xts_keyword(rb, NK + w), "key2 word retained in schedule");
      end
      chk(dut.u_kx.win_q === {KEYBITS{1'b0}}, "key expander window cleared after expansion");
    end
  endtask

  // one-cycle start request; returns whether start_err pulsed in the following cycle
  logic r_err;
  task try_start(input logic d, input integer n, input logic [127:0] tw);
    begin
      start = 1'b1; decrypt = d; tweak = tw; nblocks = n[15:0];
      tick;
      start = 1'b0;
      tick;                          // edge ending the cycle after start: start_err visible here
      r_err = start_err;
    end
  endtask

  // ------------------------------------------------------------------ unit runner
  // knobs (restored to defaults at the end of every run_unit)
  integer k_abort_at = -1;   // pulse key_zeroize in this cycle (relative to the start cycle)
  integer k_rst_at   = -1;   // hold rst_n low from this cycle ...
  integer k_rst_len  = 1;    // ... for this many cycles
  integer k_inj_at   = -1;   // inject a forbidden request in this cycle
  integer k_inj_kind = 0;    // 0 start, 1 key_commit, 2 key_we
  integer k_nover    = 0;    // nonzero: start the unit with this many blocks (prefix of the record)
  integer k_cap      = 0;    // capture output beats into capbuf
  integer k_pre      = 0;    // assert in_valid this many cycles before start
  integer k_drain    = 3;    // cycles run after the last beat
  integer k_stall_chk = 0;   // abort test with never-ready output: check data stable

  // run state
  integer       ru_n, ru_pin, ru_pout, ru_srck, ru_pbase, ru_cbase, ru_in_i, ru_out_i;
  logic         ru_dec;
  logic [127:0] ru_tw;
  integer       r_beats, r_cycles;
  logic         r_aborted;
  logic [127:0] ru_w;

  task ru_src(input integer j);
    begin
      if (ru_srck == 0)      ru_w = vmem[ru_pbase + j];
      else if (ru_srck == 1) ru_w = vmem[ru_cbase + j];
      else                   ru_w = capbuf[j];
    end
  endtask

  // drive the inputs of cycle c (called at the edge that ends cycle c-1)
  task ru_drive(input integer c);
    logic [31:0] r1, r2;
    logic [127:0] rr;
    begin
      // ---- unit control
      if (c == 0) begin
        start = 1'b1; decrypt = ru_dec; tweak = ru_tw; nblocks = ru_n[15:0];
      end else begin
        r1 = rnd32(0);
        rnd128(rr);
        start = 1'b0; decrypt = r1[0]; tweak = rr; nblocks = r1[31:16];  // scrambled: must be latched
      end
      // ---- forbidden requests injected while busy
      key_we = 1'b0; key_commit = 1'b0;
      if (c == k_inj_at) begin
        r1 = rnd32(0); r2 = rnd32(0);
        case (k_inj_kind)
          0: begin start = 1'b1; decrypt = ~ru_dec; nblocks = {r1[15:1], 1'b1}; end
          1: key_commit = 1'b1;
          default: begin key_we = 1'b1; key_widx = {1'b0, r1[3:0]} % (2*NK); key_wdata = r2; end
        endcase
      end
      // ---- zeroize / reset
      key_zeroize = (c == k_abort_at);
      rst_n = !((k_rst_at >= 0) && (c >= k_rst_at) && (c < k_rst_at + k_rst_len));
      // ---- input stream
      if (in_valid && !in_ready) begin
        // hold valid + data until accepted
      end else if (ru_in_i < ru_n && pick(ru_pin, 0)) begin
        in_valid = 1'b1;
        ru_src(ru_in_i);
        in_data = ru_w;
      end else begin
        in_valid = 1'b0;
        rnd128(rr);
        in_data = rr;                 // garbage while not valid
      end
      // ---- output side
      out_ready = pick(ru_pout, 1);
    end
  endtask

  // run one data unit.  src: 0 = P, 1 = C (record), 2 = capbuf.  expk: 0 = expect P, 1 = expect C
  task run_unit(input integer rb, input logic dec, input integer srck, input integer expk,
                input integer pin, input integer pout);
    integer cyc, tmo, drain, ab_at, hdr_n;
    logic   aborted, fin, ab_rst, timing_chk;
    logic [127:0] exp_w, rr;
    begin
      hdr_n    = rec_n(rb);
      ru_n     = (k_nover != 0) ? k_nover : hdr_n;
      ru_pin   = pin; ru_pout = pout; ru_srck = srck; ru_dec = dec;
      ru_pbase = rb + 2 + KS; ru_cbase = ru_pbase + hdr_n;
      ru_tw    = vmem[rb + 1 + KS];
      ru_in_i  = 0; ru_out_i = 0;
      aborted  = 1'b0; fin = 1'b0; drain = 0; cyc = 0;
      ab_rst   = (k_abort_at < 0);
      ab_at    = (k_abort_at >= 0) ? k_abort_at : k_rst_at;
      tmo      = 4000 + ru_n * (PERIOD + 70);
      timing_chk = (pin == 0) && (pout == 0) && (ab_at < 0) && (k_inj_at < 0) && (k_pre == 0);
      r_beats = 0; r_aborted = 1'b0;

      if (k_pre != 0) begin               // in_valid asserted before start: must not be accepted
        in_valid = 1'b1; ru_src(0); in_data = ru_w;
        tick;
      end
      ru_drive(0);
      while (!fin) begin
        tick;                              // edge ending cycle `cyc`: sampled values = cycle cyc
        // ---------------- transfers of cycle cyc
        if (in_valid && in_ready) begin
          if (timing_chk) chk(cyc == LAT_IN + ru_in_i*PERIOD, "in beat accepted at documented cycle");
          chk(ru_in_i < ru_n, "no more input beats accepted than nblocks");
          ru_in_i = ru_in_i + 1;
        end
        if (out_valid && out_ready) begin
          if (ru_out_i < ru_n) begin
            exp_w = (expk == 0) ? vmem[ru_pbase + ru_out_i] : vmem[ru_cbase + ru_out_i];
            if (out_data !== exp_w) begin
              if (n_fail < 20) $display("  MISMATCH rec@%0d beat %0d dec=%0b got=%h exp=%h", rb, ru_out_i, dec, out_data, exp_w);
            end
            chk(out_data === exp_w, "out_data matches golden");
            chk(out_last === (ru_out_i == ru_n - 1), "out_last only on final block");
            if (timing_chk) chk(cyc == LAT_OUT + ru_out_i*PERIOD, "out beat at documented cycle");
            if (k_cap != 0 && ru_out_i < 65536) capbuf[ru_out_i] = out_data;
          end else begin
            chk(1'b0, "unexpected extra output beat");
          end
          ru_out_i = ru_out_i + 1;
          r_beats  = r_beats + 1;
        end
        // ---------------- per-cycle invariants
        if (!aborted && !(ab_at >= 0 && cyc >= ab_at)) chk(key_ready === 1'b1, "key_ready stays high during a unit");
        if (k_abort_at >= 0 && cyc == k_abort_at) begin
          chk(!out_valid && !in_ready, "no handshake offered in the zeroize cycle");
          aborted = 1'b1;
        end
        if (k_abort_at >= 0 && cyc == k_abort_at - 1 && cyc >= 1) begin
          chk(dut.rk1_q !== {RKW{1'b0}} && dut.rk2_q !== {RKW{1'b0}}, "key schedules non-zero before zeroize");
          chk(dut.u_core.state_q !== 128'h0, "AES state non-zero before zeroize");
          if (cyc >= LAT_IN) chk(dut.t_q !== 128'h0, "tweak state T non-zero before zeroize");
        end
        if (k_rst_at >= 0 && k_abort_at < 0 && cyc == k_rst_at) aborted = 1'b1;
        if (aborted && cyc > ab_at) begin
          chk(busy === 1'b0 && out_valid === 1'b0 && in_ready === 1'b0, "aborted: busy/out_valid/in_ready low");
          chk(out_data === 128'h0, "aborted: out_data zero");
          chk(out_last === 1'b0, "aborted: out_last low");
          if (ab_rst) begin
            if (cyc >= ab_at + k_rst_len) chk(key_ready === 1'b0, "aborted: key_ready low");
          end else begin
            chk(key_ready === 1'b0, "aborted: key_ready low");
          end
          if (cyc == ab_at + 1 && !(ab_rst && k_rst_len > 1)) chk_regs_zero("after abort");
          if (ab_rst && cyc == ab_at + k_rst_len) chk_regs_zero("after reset");
        end
        // ---------------- termination
        if (aborted) begin
          if (cyc >= ab_at + k_rst_len + 70) fin = 1'b1;
        end else if (ru_out_i >= ru_n) begin
          if (drain == 0) chk(1'b1, "unit complete");
          drain = drain + 1;
          if (drain > 1) chk(busy === 1'b0, "busy low after unit");
          if (drain > k_drain) fin = 1'b1;
        end else if (cyc > tmo) begin
          chk(1'b0, "TIMEOUT waiting for output beats");
          fin = 1'b1;
        end
        // ---------------- next cycle
        if (!fin) begin
          cyc = cyc + 1;
          ru_drive(cyc);
        end
      end
      r_cycles  = cyc;
      r_aborted = aborted;
      n_units   = n_units + 1;
      n_beats   = n_beats + r_beats;
      if (!aborted) chk(ru_out_i == ru_n, "all output beats received");
      // back to idle
      idle_inputs;
      rst_n = 1'b1;
      // restore knobs
      k_abort_at = -1; k_rst_at = -1; k_rst_len = 1; k_inj_at = -1; k_inj_kind = 0;
      k_nover = 0; k_cap = 0; k_pre = 0; k_drain = 3;
      if (aborted) begin tick; end
    end
  endtask

  // enc, dec and DUT-roundtrip of record rb with the given stream profiles
  task run_triple(input integer rb, input integer pin, input integer pout);
    begin
      k_cap = 1;
      run_unit(rb, 1'b0, 0, 1, pin, pout);     // encrypt P, expect C
      run_unit(rb, 1'b1, 1, 0, pin, pout);     // decrypt C (from file), expect P
      run_unit(rb, 1'b1, 2, 0, pin, pout);     // decrypt the DUT's own ciphertext: round trip, expect P
    end
  endtask

  // ------------------------------------------------------------------ protocol monitor
  // Assertion-style checks running on every clock:
  //  A1  out_data/out_last stable and out_valid held while out_valid && !out_ready
  //  A2  no output beat before its input beat (out beat j only after in beat j accepted)
  //  A3  exactly one out_last per unit, on the nblocks-th beat; no beat beyond nblocks
  //  A4  busy high from the accepted start to the last output beat; low in the next cycle;
  //      in_ready/out_valid only while busy
  //  A5  start_err pulses (in the cycle after) exactly for a start that was not accepted
  logic         m_en = 1'b0;
  logic         m_pv_ov, m_pv_or, m_pv_last, m_pv_busy, m_pv_start, m_pv_clr, m_pv_rstn;
  logic [127:0] m_pv_od;
  logic [15:0]  m_pv_nb;
  logic         m_active, m_expect_idle;
  integer       m_in_cnt, m_out_cnt, m_last_cnt, m_nb;
  logic         m_clr_now;
  integer       gcyc = 0;

  initial begin
    m_pv_ov = 0; m_pv_or = 0; m_pv_last = 0; m_pv_busy = 0; m_pv_start = 0; m_pv_clr = 0; m_pv_rstn = 0;
    m_pv_od = 0; m_pv_nb = 0; m_active = 0; m_expect_idle = 0;
    m_in_cnt = 0; m_out_cnt = 0; m_last_cnt = 0; m_nb = 0;
  end

  always @(posedge clk) begin
    gcyc <= gcyc + 1;
    if (m_en) begin
      m_clr_now = !rst_n || key_zeroize;
      // A1: stability of a stalled output
      if (m_pv_ov && !m_pv_or && !m_pv_clr && !key_zeroize && m_pv_rstn) begin   // abort (zeroize/reset) may drop the output
        a1_n = a1_n + 1;
        chk(out_valid === 1'b1 && out_data === m_pv_od && out_last === m_pv_last,
            "A1 out_valid/out_data/out_last stable while stalled");
      end
      // A5: start_err relation
      if (m_pv_rstn) begin
        a5_n = a5_n + 1;
        chk(start_err === (m_pv_start && !(busy && !m_pv_busy)), "A5 start_err iff start not accepted");
      end
      // unit begin: busy rises, the start was in the previous cycle
      if (busy && !m_pv_busy && !m_active) begin
        m_active = 1'b1; m_nb = m_pv_nb; m_in_cnt = 0; m_out_cnt = 0; m_last_cnt = 0;
      end
      if (m_active) begin
        a4_n = a4_n + 1;
        chk(busy === 1'b1, "A4 busy high until the last beat is consumed");
        if (out_valid) begin
          a2_n = a2_n + 1;
          chk(m_in_cnt > m_out_cnt, "A2 output beat presented before its input beat was accepted");
        end
        if (in_ready) begin
          a3_n = a3_n + 1;
          chk(m_in_cnt < m_nb, "A3 in_ready requested more beats than nblocks");
        end
        if (out_valid && out_ready) begin
          a3_n = a3_n + 1;
          chk(out_last === (m_out_cnt + 1 == m_nb), "A3 out_last exactly on the nblocks-th beat");
          if (out_last) m_last_cnt = m_last_cnt + 1;
          m_out_cnt = m_out_cnt + 1;
          if (m_out_cnt == m_nb) begin
            chk(m_last_cnt == 1, "A3 out_last count == 1 per unit");
            m_active = 1'b0; m_expect_idle = 1'b1;
          end
        end
        if (in_valid && in_ready) m_in_cnt = m_in_cnt + 1;
      end else begin
        if (m_expect_idle) begin
          a4_n = a4_n + 1;
          chk(busy === 1'b0, "A4 busy low in the cycle after the last beat");
          m_expect_idle = 1'b0;
        end
        if (!busy) begin
          a4_n = a4_n + 1;
          chk(!out_valid && !in_ready, "A4 no in_ready/out_valid while idle");
        end
      end
      if (m_clr_now) begin m_active = 1'b0; m_expect_idle = 1'b0; end
      // remember this cycle
      m_pv_ov = out_valid; m_pv_or = out_ready; m_pv_od = out_data; m_pv_last = out_last;
      m_pv_busy = busy; m_pv_start = start; m_pv_nb = nblocks; m_pv_clr = key_zeroize; m_pv_rstn = rst_n;
    end
  end

  // ------------------------------------------------------------------ test groups
  // ---- standalone AES core against FIPS-197 / SP 800-38A / random ECB vectors
  logic [127:0] c_res;
  integer       c_lat;
  logic         c_seq_ok;

  task core_op(input logic d, input logic [127:0] b);
    integer cyc;
    logic [127:0] rr;
    begin
      c_start = 1'b1; c_dec = d; c_blk = b;
      tick;                                    // end of cycle 0 (start cycle)
      rnd128(rr);
      c_start = 1'b0; c_dec = ~d; c_blk = rr;  // must have been latched/consumed
      tick;                                    // end of cycle 1
      cyc = 1; c_seq_ok = 1'b1;
      while (!c_vld && cyc < 60) begin
        if (!c_busy) c_seq_ok = 1'b0;
        tick; cyc = cyc + 1;
      end
      c_lat = cyc;
      c_res = c_out;
      if (c_busy) c_seq_ok = 1'b0;
    end
  endtask

  task t_core;
    integer i, r, ab;
    logic [127:0] pt, ct, res;
    begin
      grp_begin("AES core vs FIPS-197/random KATs");
      for (i = 0; i < narec; i = i + 1) begin
        ab = abase[i];
        for (r = 0; r <= NR; r = r + 1) c_rk[128*r +: 128] = amem[ab + 1 + KH + r];
        pt = amem[ab + 1 + KH + NR + 1];
        ct = amem[ab + 1 + KH + NR + 2];
        core_op(1'b0, pt);
        chk(c_res === ct, "core encrypt == ciphertext KAT");
        chk(c_lat == NR + 1 && c_seq_ok, "core latency Nr+1 cycles, busy during rounds");
        tick;
        chk(c_vld === 1'b1 && c_out === ct, "core result held while vld");
        core_op(1'b1, ct);
        chk(c_res === pt, "core decrypt == plaintext KAT");
        chk(c_lat == NR + 1 && c_seq_ok, "core decrypt latency Nr+1 cycles");
      end
      // start while busy is ignored
      ab = abase[0];
      for (r = 0; r <= NR; r = r + 1) c_rk[128*r +: 128] = amem[ab + 1 + KH + r];
      pt = amem[ab + 1 + KH + NR + 1]; ct = amem[ab + 1 + KH + NR + 2];
      c_start = 1'b1; c_dec = 1'b0; c_blk = pt; tick;
      c_start = 1'b0; tick; tick; tick;
      c_start = 1'b1; c_dec = 1'b1; c_blk = ~pt; tick;      // while busy: ignored
      c_start = 1'b0;
      while (!c_vld) tick;
      chk(c_out === ct, "core: start while busy ignored");
      // clr aborts
      c_start = 1'b1; c_dec = 1'b0; c_blk = pt; tick; c_start = 1'b0; tick; tick;
      c_clr = 1'b1; tick; c_clr = 1'b0; tick;
      chk(c_vld === 1'b0 && c_busy === 1'b0 && c_out === 128'h0, "core: clr clears state/busy/vld");
      repeat (NR + 4) tick;
      chk(c_vld === 1'b0 && c_out === 128'h0, "core: no result after clr");
      grp_end;
    end
  endtask

  // ---- RTL key expansion vs python FIPS-197 schedule
  task t_keyexp;
    integer i, j, r, w, ab, bb;
    logic [RKW-1:0] ex1, ex2;
    begin
      grp_begin("RTL key expansion vs python");
      for (i = 0; i < narec; i = i + 1) begin
        ab = abase[i];
        bb = abase[(i + 7) % narec];
        for (w = 0; w < NK; w = w + 1) key_word(w, aes_keyword(ab, w));
        for (w = 0; w < NK; w = w + 1) key_word(NK + w, aes_keyword(bb, w));
        commit_and_wait(4*KEYEXP_CYC);
        for (r = 0; r <= NR; r = r + 1) begin
          ex1[128*r +: 128] = amem[ab + 1 + KH + r];
          ex2[128*r +: 128] = amem[bb + 1 + KH + r];
        end
        chk(r_kcyc == KEYEXP_CYC, "key expansion latency == documented");
        chk(dut.rk1_q === ex1, "key1 schedule == python FIPS-197 expansion");
        chk(dut.rk2_q === ex2, "key2 schedule == python FIPS-197 expansion");
        chk(key_ready === 1'b1, "key_ready after expansion");
      end
      grp_end;
    end
  endtask

  // ---- XTS vectors
  task t_xts_vectors;
    integer i, rb, c0, c1, c2;
    begin
      grp_begin("XTS std+random: enc/dec/roundtrip");
      c0 = 0; c1 = 0; c2 = 0;
      for (i = 0; i < nrec; i = i + 1) begin
        rb = rbase[i];
        case (rec_cat(rb))
          0: c0 = c0 + 1;
          1: c1 = c1 + 1;
          default: c2 = c2 + 1;
        endcase
        key_setup(rb);
        run_triple(rb, 0, 0);
      end
      $display("INFO  XTS units tested: standard=%0d random=%0d special=%0d (each enc + dec + DUT roundtrip, no stalls)", c0, c1, c2);
      grp_end;
    end
  endtask

  // ---- random gaps / back-pressure
  task t_stress;
    integer i, rb, n, pi_, po, cnt;
    begin
      grp_begin("XTS stalls/gaps (random profiles)");
      cnt = 0;
      for (i = 0; i < nrec; i = i + 1) begin
        rb = rbase[i];
        n = rec_n(rb);
        if ((n <= 32 && (i % 2 == 0)) || (n > 32 && (i % 9 == 0))) begin
          pi_ = 1 + (i % 4);
          po  = 1 + ((i / 4) % 4);
          key_setup(rb);
          run_triple(rb, pi_, po);
          cnt = cnt + 1;
        end
      end
      $display("INFO  stall/gap profile units: %0d (x3 runs: enc, dec, roundtrip)", cnt);
      // extreme profiles on a few units
      for (i = 0; i < nrec && i < 40; i = i + 3) begin
        rb = rbase[i];
        key_setup(rb);
        run_unit(rb, 1'b0, 0, 1, 3, 3);       // sparse input, mostly-blocked output
        run_unit(rb, 1'b1, 1, 0, 4, 4);       // bursty both
        run_unit(rb, 1'b0, 0, 1, 3, 0);
        run_unit(rb, 1'b1, 1, 0, 0, 3);
        k_pre = 1; run_unit(rb, 1'b0, 0, 1, 0, 0);   // in_valid asserted before start
        k_pre = 1; run_unit(rb, 1'b0, 0, 1, 4, 2);
      end
      grp_end;
    end
  endtask

  // ---- documented latency numbers (explicit)
  task t_latency;
    integer i, rb, n, found;
    begin
      grp_begin("documented timing (cycles)");
      found = 0;
      for (i = 0; i < nrec && found < 3; i = i + 1) begin
        rb = rbase[i];
        n = rec_n(rb);
        if (rec_cat(rb) == 1 && n == found + 1) begin
          key_setup(rb);
          run_unit(rb, 1'b0, 0, 1, 0, 0);   // timing_chk inside: LAT_IN, LAT_OUT, PERIOD
          chk(r_cycles >= LAT_OUT + (n-1)*PERIOD, "unit cycle count sane");
          $display("INFO  n=%0d: last beat consumed in cycle %0d (formula %0d); first in_ready cycle %0d, first out_valid cycle %0d, %0d cycles/block",
                   n, LAT_OUT + (n-1)*PERIOD, LAT_OUT + (n-1)*PERIOD, LAT_IN, LAT_OUT, PERIOD);
          found = found + 1;
        end
      end
      chk(found == 3, "found latency records");
      grp_end;
    end
  endtask

  // ---- protocol / reject behaviour
  task t_protocol;
    integer i, rb, rbA, rbB, w, n, cyc;
    logic [RKW-1:0] s1, s2;
    logic [127:0] tw;
    begin
      grp_begin("protocol: rejects/ignores");
      rbA = rbase[nrec - 1];           // a random multi-block unit
      for (i = 0; i < nrec; i = i + 1) if (rec_n(rbase[i]) == 3 && rec_cat(rbase[i]) == 1) rbB = rbase[i];
      rnd128(tw);

      // after reset: no keys -> start rejected
      do_reset(2);
      chk(key_ready === 1'b0 && busy === 1'b0 && out_valid === 1'b0 && in_ready === 1'b0, "idle state after reset");
      try_start(1'b0, 3, tw);
      chk(r_err === 1'b1, "start before any key: start_err");
      chk(busy === 1'b0 && in_ready === 1'b0 && out_valid === 1'b0, "start before any key: rejected");
      // commit with no key written is ignored
      commit_and_wait(2*KEYEXP_CYC);
      chk(key_ready === 1'b0, "commit without key words ignored (key_ready stays low)");
      // partial key + commit
      for (w = 0; w < 2*NK - 1; w = w + 1) key_word(w, xts_keyword(rbB, w));
      commit_and_wait(2*KEYEXP_CYC);
      chk(key_ready === 1'b0, "commit with incomplete key ignored");
      try_start(1'b0, 3, tw);
      chk(r_err === 1'b1 && busy === 1'b0, "start with incomplete key rejected");
      // out-of-range key word index is ignored
      key_word(2*NK, 32'hdeadbeef);
      key_word(31, 32'hdeadbeef);
      key_word(2*NK - 1, xts_keyword(rbB, 2*NK - 1));
      commit_and_wait(4*KEYEXP_CYC);
      chk(key_ready === 1'b1 && r_kcyc == KEYEXP_CYC, "full key + commit -> key_ready");
      // keys valid, but start before ready isn't possible now; nblocks == 0 rejected
      try_start(1'b0, 0, tw);
      chk(r_err === 1'b1 && busy === 1'b0, "nblocks==0 rejected with start_err");
      // key_we while idle invalidates key_ready
      key_word(0, xts_keyword(rbB, 0));
      tick;
      chk(key_ready === 1'b0, "key_we invalidates key_ready");
      try_start(1'b0, 3, tw);
      chk(r_err === 1'b1 && busy === 1'b0, "start after key_we (not re-committed) rejected");
      commit_and_wait(4*KEYEXP_CYC);
      chk(key_ready === 1'b1, "re-commit restores key_ready");
      // start immediately followed by valid unit: result still correct
      run_triple(rbB, 0, 0);

      // start + key_we same cycle: start rejected, key_we accepted (rewrite same value)
      start = 1'b1; decrypt = 1'b0; tweak = tw; nblocks = 16'd3;
      key_we = 1'b1; key_widx = 5'd1; key_wdata = xts_keyword(rbB, 1);
      tick; start = 1'b0; key_we = 1'b0; tick;
      chk(start_err === 1'b1 && busy === 1'b0, "start+key_we same cycle: start rejected, err");
      chk(key_ready === 1'b0, "start+key_we same cycle: key_ready dropped");
      commit_and_wait(4*KEYEXP_CYC);
      chk(key_ready === 1'b1, "recommit after start+key_we");
      // start + key_commit same cycle
      start = 1'b1; decrypt = 1'b0; tweak = tw; nblocks = 16'd3; key_commit = 1'b1;
      tick; start = 1'b0; key_commit = 1'b0; tick;
      chk(start_err === 1'b1 && busy === 1'b0, "start+key_commit same cycle: start rejected, err");
      cyc = 0; while (!key_ready && cyc < 4*KEYEXP_CYC) begin tick; cyc = cyc + 1; end
      chk(key_ready === 1'b1, "commit (same cycle as rejected start) completes");
      run_triple(rbB, 0, 0);

      // key_commit / key_we during expansion are ignored
      for (w = 0; w < 2*NK; w = w + 1) key_word(w, xts_keyword(rbA, w));
      key_commit = 1'b1; tick; key_commit = 1'b0;
      repeat (9) tick;
      key_commit = 1'b1; tick; key_commit = 1'b0;                 // re-commit while expanding
      repeat (7) tick;
      key_word(0, 32'hdeadbeef); key_word(NK, 32'hcafef00d);         // garbage key writes while expanding
      cyc = 0; while (!key_ready && cyc < 4*KEYEXP_CYC) begin tick; cyc = cyc + 1; end
      chk(key_ready === 1'b1, "expansion completes despite commit/key_we during expansion");
      chk(dut.rk1_q[31:0] === xts_keyword(rbA, 0) && dut.rk2_q[31:0] === xts_keyword(rbA, NK),
          "key_we during expansion ignored");
      run_triple(rbA, 0, 0);

      // forbidden requests while a unit is busy, at many phases
      key_setup(rbB);
      s1 = dut.rk1_q; s2 = dut.rk2_q;
      for (i = 0; i < 3; i = i + 1) begin
        for (w = 1; w <= LAT_OUT + 2*PERIOD; w = w + ((w < 4*PERIOD) ? 1 : 7)) begin
          k_inj_kind = i; k_inj_at = w;
          run_unit(rbB, 1'b0, 0, 1, 0, (w % 3 == 0) ? 3 : 0);
          chk(dut.rk1_q === s1 && dut.rk2_q === s2, "key registers unchanged by requests during a unit");
          chk(key_ready === 1'b1, "key_ready still high after forbidden requests");
        end
      end
      // unit still decrypts correctly afterwards
      run_triple(rbB, 0, 0);
      // start in the cycle of the last output beat (busy still high) is rejected ...
      k_inj_kind = 0; k_inj_at = LAT_OUT + 2*PERIOD;
      k_cap = 1;
      run_unit(rbB, 1'b0, 0, 1, 0, 0);
      // ... and a start in the very next cycle (busy just fell) is accepted: back-to-back units
      k_drain = 0;
      run_unit(rbB, 1'b1, 1, 0, 0, 0);
      k_drain = 0;
      run_unit(rbB, 1'b0, 0, 1, 0, 0);
      k_drain = 0;
      run_unit(rbB, 1'b1, 1, 0, 3, 3);
      grp_end;
    end
  endtask

  // ---- zeroize
  task t_zeroize;
    integer x, rbA, rbB, i, endc, cnt, w, w2;
    logic [127:0] tw;
    begin
      grp_begin("key_zeroize / reset");
      rbA = rbase[0];
      rbB = -1;
      for (i = 0; i < nrec; i = i + 1) begin           // two different random 3-block units
        if (rec_n(rbase[i]) == 3 && rec_cat(rbase[i]) == 1) begin
          if (rbB < 0) rbB = rbase[i];
          rbA = rbase[i];
        end
      end
      rnd128(tw);
      endc = LAT_OUT + 2*PERIOD;       // last beat of a 3-block unit
      cnt = 0;
      // --- zeroize in every cycle of a 3-block unit (T0 phase, waiting, rounds, output)
      for (x = 0; x <= endc; x = x + 1) begin
        key_setup(rbA);
        k_abort_at = x;
        run_unit(rbA, x[0], x[0] ? 1 : 0, x[0] ? 0 : 1, 0, (x % 4 == 1) ? 3 : 0);
        chk(r_aborted === 1'b1, "unit aborted by zeroize");
        chk(r_beats <= 3, "no extra beats after zeroize");
        // start rejected afterwards, err pulsed
        try_start(1'b0, 3, tw);
        chk(r_err === 1'b1 && busy === 1'b0 && in_ready === 1'b0 && out_valid === 1'b0, "start after zeroize rejected (start_err)");
        // commit without reloading the key is ignored
        commit_and_wait(2*KEYEXP_CYC);
        chk(key_ready === 1'b0, "commit after zeroize without reload ignored");
        chk(regs_all_zero(0), "key registers still zero (no key reloaded)");
        // re-loading works
        key_setup(rbB);
        run_triple(rbB, 0, 0);
        cnt = cnt + 1;
      end
      $display("INFO  zeroize injected at %0d different cycles of a 3-block unit", cnt);
      // --- zeroize while output is stalled (out_valid held high), stable data until zeroize
      for (x = LAT_OUT; x <= LAT_OUT + 6; x = x + 3) begin
        key_setup(rbA);
        k_abort_at = x;
        run_unit(rbA, 1'b0, 0, 1, 0, 5);          // never ready
        chk(r_aborted === 1'b1 && r_beats == 0, "stalled output: zeroize aborts, no beat delivered");
        key_setup(rbB);
        run_triple(rbB, 0, 0);
      end
      // --- zeroize in the same cycle as start (start rejected, nothing stored)
      key_setup(rbA);
      k_abort_at = 0;
      run_unit(rbA, 1'b0, 0, 1, 0, 0);
      chk(r_aborted === 1'b1 && r_beats == 0, "zeroize+start same cycle: nothing runs");
      chk(regs_all_zero(0), "zeroize+start same cycle: registers zero");
      // --- zeroize while idle with keys ready
      key_setup(rbA);
      chk(dut.rk1_q !== {RKW{1'b0}} && dut.rk2_q !== {RKW{1'b0}}, "keys present before idle zeroize");
      key_zeroize = 1'b1; tick; key_zeroize = 1'b0; tick;
      chk_regs_zero("idle zeroize");
      try_start(1'b0, 3, tw);
      chk(r_err === 1'b1 && busy === 1'b0, "start after idle zeroize rejected");
      // --- zeroize during key expansion (every 3rd cycle + edge cycles)
      cnt = 0;
      for (x = 1; x < KEYEXP_CYC; x = x + 1) begin
        if (x % 3 == 0 || x < 4 || x > KEYEXP_CYC - 4) begin
          for (w = 0; w < 2*NK; w = w + 1) key_word(w, xts_keyword(rbA, w));
          key_commit = 1'b1; tick; key_commit = 1'b0;           // commit cycle = 0
          for (w2 = 1; w2 < x; w2 = w2 + 1) tick;
          chk(x < 2 || key_ready === 1'b0, "key_ready low during expansion");
          // expander active (window loaded) in cycles [2, W+1] (key1) and [W+4, 2W+3] (key2); hierarchical reads here see cycle x
          if ((x >= 2 && x <= (NW-NK)+1) || (x >= (NW-NK)+4 && x <= 2*(NW-NK)+3))
            chk(dut.u_kx.win_q !== {KEYBITS{1'b0}}, "expander window holds key material before zeroize");
          key_zeroize = 1'b1; tick; key_zeroize = 1'b0; tick;
          chk_regs_zero("zeroize during key expansion");
          repeat (4) tick;
          chk(key_ready === 1'b0 && busy === 1'b0, "no expansion resumes after zeroize");
          chk(regs_all_zero(0), "registers remain zero after aborted expansion");
          commit_and_wait(KEYEXP_CYC + 20);
          chk(key_ready === 1'b0, "commit after aborted expansion ignored");
          key_setup(rbB);
          run_unit(rbB, 1'b0, 0, 1, 0, 0);
          cnt = cnt + 1;
        end
      end
      $display("INFO  zeroize injected at %0d different cycles of key expansion", cnt);
      // --- reset mid-unit (1 and 3 cycle resets) at many cycles
      cnt = 0;
      for (x = 0; x <= endc; x = x + 2) begin
        key_setup(rbA);
        k_rst_at = x; k_rst_len = (x % 4 == 0) ? 1 : 3;
        run_unit(rbA, 1'b0, 0, 1, 0, (x % 3 == 1) ? 3 : 0);
        chk(r_aborted === 1'b1, "unit aborted by reset");
        try_start(1'b0, 3, tw);
        chk(r_err === 1'b1 && busy === 1'b0, "start after reset rejected");
        key_setup(rbB);
        run_unit(rbB, 1'b1, 1, 0, 0, 0);
        cnt = cnt + 1;
      end
      $display("INFO  reset injected at %0d different cycles of a 3-block unit", cnt);
      // --- reset while idle, keys ready
      key_setup(rbA);
      rst_n = 1'b0; tick; rst_n = 1'b1; tick;
      chk_regs_zero("reset while idle");
      grp_end;
    end
  endtask

  // ---- long unit (nblocks up to 65535)
  task t_long;
    integer rb;
    begin
      grp_begin("long unit");
      $readmemh($sformatf("%s/vec_long_%0d.hex", vecdir, KEYBITS), vmem);
      rb = 1;
      chk(vmem[0][31:0] == 1, "long vector file loaded");
      chk(rec_n(rb) >= longn, "long vector big enough");
      key_setup(rb);
      k_cap = 0; k_nover = longn;
      run_unit(rb, 1'b0, 0, 1, 0, 0);              // timing check for every block
      k_nover = longn;
      run_unit(rb, 1'b1, 1, 0, 0, 0);
      k_nover = (longn > 3000) ? 3000 : longn;
      run_unit(rb, 1'b0, 0, 1, 4, 4);              // stalls on a long prefix
      $display("INFO  long unit: nblocks=%0d (enc + dec, every beat compared)", longn);
      grp_end;
    end
  endtask

  // ------------------------------------------------------------------ main
  integer tmp_i;
  logic [7:0] groups;
  initial begin
    burst_left[0] = 0; burst_left[1] = 0; burst_val[0] = 0; burst_val[1] = 0;
    vecdir = ".";
    void'($value$plusargs("VECDIR=%s", vecdir));
    longn = 0;
    void'($value$plusargs("LONGN=%d", longn));
    groups = 'hFF;                                   // +GROUPS=<mask> selects groups (debug aid)
    void'($value$plusargs("GROUPS=%h", groups));
    $readmemh($sformatf("%s/vec_xts_%0d.hex", vecdir, KEYBITS), vmem);
    $readmemh($sformatf("%s/vec_aes_%0d.hex", vecdir, KEYBITS), amem);
    index_xts;
    index_aes;
    $display("INFO  KEYBITS=%0d: %0d XTS records, %0d AES KAT records; documented: key expansion %0d cyc, in_ready@%0d, out_valid@%0d, %0d cyc/block",
             KEYBITS, nrec, narec, KEYEXP_CYC, LAT_IN, LAT_OUT, PERIOD);
    rst_n = 1'b0;
    idle_inputs;
    c_rk = {RKW{1'b0}};
    m_en = 1'b0;
    repeat (3) tick;
    rst_n = 1'b1;
    repeat (2) tick;
    m_en = 1'b1;
    tick;

    chk(key_ready === 1'b0 && busy === 1'b0 && out_valid === 1'b0 && in_ready === 1'b0 && start_err === 1'b0,
        "outputs idle after reset");

    if (groups[0]) t_core;
    if (groups[1]) t_keyexp;
    if (groups[2]) t_latency;
    if (groups[3]) t_xts_vectors;
    if (groups[4]) t_stress;
    if (groups[5]) t_protocol;
    if (groups[6]) t_zeroize;
    if (longn > 0) t_long;

    tick; tick;
    $display("INFO  assertion-style checks executed: A1(stall stable)=%0d A2(no output before input)=%0d A3(out_last count / nblocks)=%0d A4(busy)=%0d A5(start_err)=%0d",
             a1_n, a2_n, a3_n, a4_n, a5_n);
    $display("INFO  units run: %0d, output beats compared: %0d", n_units, n_beats);
    chk(a1_n > 0 && a2_n > 0 && a3_n > 0 && a4_n > 0 && a5_n > 0, "all assertion monitors exercised");
    if (n_fail == 0) $display("TB_PASS KEYBITS=%0d checks=%0d", KEYBITS, n_checks);
    else             $display("TB_FAIL KEYBITS=%0d checks=%0d fails=%0d", KEYBITS, n_checks, n_fail);
    $finish;
  end

  // global watchdog
  initial begin
    #3000000000;
    $display("TB_FAIL watchdog timeout (checks=%0d fails=%0d)", n_checks, n_fail);
    $finish;
  end

endmodule
