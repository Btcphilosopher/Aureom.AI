#!/usr/bin/env bash
# run_security.sh -- build and run the sfx_aes_xts verification (SilicaFlux-STORE P60)
#
#   1. python golden-model self-test + vector generation
#   2. Verilator -Wall --lint-only on the RTL (KEYBITS 128 and 256, plus sfx_aes_core alone)
#   3. Icarus Verilog (iverilog -g2012 / vvp) testbench runs, KEYBITS 128 and 256 (sequential)
#   4. Verilator (--binary --timing) testbench runs, KEYBITS 128 and 256
#   5. Yosys synthesis statistics (synth -flatten; stat), KEYBITS 128 and 256
# Exits non-zero if anything fails.
#
# Environment knobs:
#   KEYBITS_LIST   (default "128 256")
#   LONGN_IV       long-unit length for Icarus runs      (default 5000; 0 = skip)
#   LONGN_VL       long-unit length for Verilator runs   (default 65535 = maximum nblocks)
#   SKIP_IVERILOG / SKIP_VERILATOR / SKIP_YOSYS = 1  to skip a step
set -u -o pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
P=$(cd "$HERE/../.." && pwd)
RTL=$P/rtl/security
B=$HERE/build
KEYBITS_LIST=${KEYBITS_LIST:-"128 256"}
LONGN_IV=${LONGN_IV:-5000}
LONGN_VL=${LONGN_VL:-65535}
RTLF="$RTL/sfx_aes_sbox.sv $RTL/sfx_aes_core.sv $RTL/sfx_aes_keyexp.sv $RTL/sfx_aes_xts.sv"
TBF="$HERE/tb_sfx_aes_xts.sv"

mkdir -p "$B"
FAIL=0
SUMMARY=()
note() { SUMMARY+=("$1"); }
bad()  { FAIL=1; note "FAIL  $1"; }
ok()   { note "ok    $1"; }

echo "== [1] golden model self-test + vector generation"
if python3 -I "$P/model/xts_ref.py" --random 500 > "$B/xts_ref_selftest.log" 2>&1; then
  ok "xts_ref self-test ($(tail -1 "$B/xts_ref_selftest.log"))"
else
  bad "xts_ref self-test (see $B/xts_ref_selftest.log)"
fi
if python3 -I "$HERE/gen_xts_vectors.py" "$B" > "$B/gen_vectors.log" 2>&1; then
  ok "vector generation: $(tr '\n' ' ' < "$B/gen_vectors.log")"
else
  bad "vector generation (see $B/gen_vectors.log)"
  cat "$B/gen_vectors.log"
  printf '%s\n' "${SUMMARY[@]}"; exit 1
fi

echo "== [2] Verilator -Wall --lint-only"
for K in $KEYBITS_LIST; do
  if verilator --lint-only -Wall -GKEYBITS=$K --top-module sfx_aes_xts $RTLF > "$B/lint_$K.log" 2>&1 \
     && [ ! -s "$B/lint_$K.log" ]; then
    ok "lint -Wall sfx_aes_xts KEYBITS=$K: clean (0 warnings)"
  else
    bad "lint -Wall sfx_aes_xts KEYBITS=$K"; cat "$B/lint_$K.log"
  fi
  if verilator --lint-only -Wall -GKEYBITS=$K --top-module sfx_aes_core $RTL/sfx_aes_sbox.sv $RTL/sfx_aes_core.sv \
       > "$B/lint_core_$K.log" 2>&1 && [ ! -s "$B/lint_core_$K.log" ]; then
    ok "lint -Wall sfx_aes_core KEYBITS=$K: clean"
  else
    bad "lint -Wall sfx_aes_core KEYBITS=$K"; cat "$B/lint_core_$K.log"
  fi
done

check_tb_log() {  # $1 = log, $2 = label
  if grep -q '^TB_PASS' "$1" && ! grep -q 'TB_FAIL' "$1" && ! grep -q '^FAIL' "$1"; then
    ok "$2: $(grep '^TB_PASS' "$1")"
  else
    bad "$2 (see $1)"; grep -E '^(FAIL|TB_FAIL|  MISMATCH)' "$1" | head -20
  fi
}

if [ "${SKIP_IVERILOG:-0}" != "1" ]; then
  echo "== [3] Icarus Verilog (iverilog -g2012, vvp)  -- runs one simulation at a time"
  for K in $KEYBITS_LIST; do
    if iverilog -g2012 -o "$B/sim_iv_$K.vvp" -s tb_sfx_aes_xts -Ptb_sfx_aes_xts.KEYBITS=$K \
         "$TBF" $RTLF > "$B/iv_build_$K.log" 2>&1; then
      ( cd "$B" && vvp "sim_iv_$K.vvp" +VECDIR=. +LONGN=$LONGN_IV > "iv_run_$K.log" 2>&1 )
      check_tb_log "$B/iv_run_$K.log" "iverilog KEYBITS=$K"
    else
      bad "iverilog build KEYBITS=$K"; cat "$B/iv_build_$K.log"
    fi
  done
fi

if [ "${SKIP_VERILATOR:-0}" != "1" ]; then
  echo "== [4] Verilator (--binary --timing)  -- one build/simulation at a time"
  for K in $KEYBITS_LIST; do
    if verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style -Wno-UNOPTFLAT -Wno-WIDTH \
         --top-module tb_sfx_aes_xts -GKEYBITS=$K -Mdir "$B/obj_vl_$K" -o Vtb \
         "$TBF" $RTLF > "$B/vl_build_$K.log" 2>&1; then
      ( cd "$B" && stdbuf -oL "obj_vl_$K/Vtb" +VECDIR=. +LONGN=$LONGN_VL > "vl_run_$K.log" 2>&1 )
      check_tb_log "$B/vl_run_$K.log" "verilator KEYBITS=$K"
    else
      bad "verilator build KEYBITS=$K"; tail -30 "$B/vl_build_$K.log"
    fi
  done
fi

if [ "${SKIP_YOSYS:-0}" != "1" ]; then
  echo "== [5] Yosys synthesis statistics (needs ~2 GB RAM per run, one at a time)"
  for K in $KEYBITS_LIST; do
    L="$B/yosys_$K.log"
    yosys -p "read_verilog -sv $RTLF; hierarchy -top sfx_aes_xts -chparam KEYBITS $K; synth -top sfx_aes_xts -flatten; check; stat" \
        > "$L" 2>&1
    if grep -q 'Found and reported 0 problems' "$L" && grep -q 'Number of cells' "$L"; then
      cells=$(grep 'Number of cells' "$L" | tail -1 | awk '{print $NF}')
      ffs=$(awk '/Printing statistics/ {s=0} /^ +\$_S?DFF/ {s+=$2} END {print s}' "$L")
      ok "yosys KEYBITS=$K: $cells cells, $ffs flip-flops (see $L)"
    else
      bad "yosys synth KEYBITS=$K (see $L)"
    fi
  done
fi

echo
echo "================ SUMMARY ================"
printf '%s\n' "${SUMMARY[@]}"
if [ $FAIL -eq 0 ]; then echo "RUN_SECURITY: ALL PASS"; else echo "RUN_SECURITY: FAILURES"; fi
exit $FAIL
