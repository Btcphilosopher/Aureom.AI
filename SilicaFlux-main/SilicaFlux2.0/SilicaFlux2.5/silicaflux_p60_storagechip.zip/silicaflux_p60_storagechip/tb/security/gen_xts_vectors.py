#!/usr/bin/env python3
"""Vector generator for tb_sfx_aes_xts.

usage: gen_xts_vectors.py OUTDIR [--seed N] [--long-blocks N]

Writes, for K in (128, 256)  (K = size of EACH of the two AES keys):
  vec_xts_K.hex   published/standard units + >=300 random units (enc & dec expected values)
  vec_aes_K.hex   single-block AES KATs with the expanded key schedule (for sfx_aes_core
                  and for checking the RTL key expansion)
  vec_long_K.hex  one long data unit (default 65535 blocks, the maximum nblocks)

All files are $readmemh files of 128-bit words (32 hex digits, one per line).
A 128-bit word W encodes a 16-byte string b as W = int.from_bytes(b, "little"),
so byte i of the string is W[8*i +: 8]  -- exactly the RTL's data-bus layout.

Word 0 of every file is the number of records.  Record layouts:

  xts / long record:  [hdr] [key1 words][key2 words] [tweak] [P_0..P_{n-1}] [C_0..C_{n-1}]
      hdr = nblocks | (category << 16);  category 0 = published/standard, 1 = random,
      2 = special patterns.  C = XTS-AES encryption of P (from python `cryptography`;
      key1==key2 cases from the pure-python model).  Decrypt reference is the inverse
      (checked: lib decrypt(C) == P).
  aes record:         [hdr] [key words (K/128)] [round keys 0..Nr (Nr+1 words)] [pt] [ct]

Every vector written is cross-checked against the independent pure-python XTS/AES.
"""
import argparse
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "model"))
import xts_ref as X  # noqa: E402

# (length in blocks, number of random units) -- 310 random units per key size
LEN_PLAN = [(1, 60), (2, 60), (3, 60), (31, 50), (32, 50), (256, 30)]


def w128(b: bytes) -> str:
    assert len(b) == 16
    return "%032x" % int.from_bytes(b, "little")


def words(b: bytes):
    assert len(b) % 16 == 0
    return [w128(b[i:i + 16]) for i in range(0, len(b), 16)]


def hdr(n, cat):
    return "%032x" % (n | (cat << 16))


def record_xts(key, tweak, pt, ct, cat):
    h = len(key) // 2
    out = [hdr(len(pt) // 16, cat)]
    out += words(key[:h]) + words(key[h:])
    out.append(w128(tweak))
    out += words(pt) + words(ct)
    return out


def crosscheck(key, tweak, pt, ct, name, full=True):
    # lib decrypt == pt, python model agrees on both directions
    if X.HAVE_LIB and key[:len(key) // 2] != key[len(key) // 2:]:
        assert X.lib_xts_decrypt(key, tweak, ct) == pt, "lib dec mismatch " + name
    n = len(pt) if full else 16 * 64
    assert X.py_xts_encrypt(key, tweak, pt[:n]) == ct[:n], "py enc mismatch " + name
    assert X.py_xts_decrypt(key, tweak, ct[:n]) == pt[:n], "py dec mismatch " + name


def gen_xts(kbits, rnd, outdir):
    kb = kbits // 8
    recs = []
    cats = [0, 0, 0]

    def add(key, tweak, pt, cat, name):
        ct = X.ref_xts(key, tweak, pt, False)
        crosscheck(key, tweak, pt, ct, name)
        recs.append(record_xts(key, tweak, pt, ct, cat))
        cats[cat] += 1

    # published / standard-structure units
    for name, key, tweak, pt in X.std_units():
        if len(key) == 2 * kb:
            add(key, tweak, pt, 0, name)
            # the published ciphertexts (IEEE v1..v3) are checked in xts_ref.selftest

    # special patterns
    sp = []
    top = (1 << 127).to_bytes(16, "little")
    ones = b"\xff" * 16
    zero = b"\x00" * 16
    for tw in (zero, ones, top, (0x87).to_bytes(16, "little"),
               ((1 << 127) | 0x87).to_bytes(16, "little")):
        sp.append(tw)
    for tw in sp:
        for pt_pat in (b"\x00", b"\xff", None):
            key = rnd.randbytes(2 * kb)
            nb = rnd.choice((1, 2, 3, 5))
            pt = rnd.randbytes(16 * nb) if pt_pat is None else pt_pat * (16 * nb)
            add(key, tw, pt, 2, "special")
    # all-ones key halves differing in one bit (key1 != key2)
    add(b"\xff" * kb + b"\xfe" * kb, ones, b"\xff" * 64, 2, "special-ffkey")

    # random units
    for nb, cnt in LEN_PLAN:
        for _ in range(cnt):
            key = rnd.randbytes(2 * kb)
            r = rnd.random()
            if r < 0.5:
                tweak = rnd.randbytes(16)
            elif r < 0.8:
                tweak = rnd.getrandbits(40).to_bytes(16, "little")  # real-world LBA-like
            else:
                tweak = rnd.getrandbits(128).to_bytes(16, "little")
            add(key, tweak, rnd.randbytes(16 * nb), 1, "rand-%d" % nb)

    with open(os.path.join(outdir, "vec_xts_%d.hex" % kbits), "w") as f:
        f.write("%032x\n" % len(recs))
        for r in recs:
            f.write("\n".join(r) + "\n")
    return len(recs), cats


def gen_aes(kbits, rnd, outdir):
    kb = kbits // 8
    recs = []
    kats = [(n, k, p, c) for n, k, p, c in X.AES_KATS if len(k) == kb]
    for _ in range(40):
        k = rnd.randbytes(kb)
        p = rnd.randbytes(16)
        kats.append(("rand", k, p, X.lib_ecb(k, p)))
    for _ in range(4):  # extremes
        k = rnd.choice((b"\x00", b"\xff")) * kb
        p = rnd.choice((b"\x00", b"\xff")) * 16
        kats.append(("ext", k, p, X.lib_ecb(k, p)))
    for name, k, p, c in kats:
        rks = X.round_keys(k)
        assert X.aes_encrypt_block(rks, p) == c and X.aes_decrypt_block(rks, c) == p, name
        assert X.lib_ecb(k, c, True) == p, name
        # per-round key words must equal the flat FIPS-197 expansion
        rec = [hdr(0, 0)] + words(k) + [w128(r) for r in rks] + [w128(p), w128(c)]
        recs.append(rec)
    with open(os.path.join(outdir, "vec_aes_%d.hex" % kbits), "w") as f:
        f.write("%032x\n" % len(recs))
        for r in recs:
            f.write("\n".join(r) + "\n")
    return len(recs)


def gen_long(kbits, rnd, outdir, nblocks):
    kb = kbits // 8
    key = rnd.randbytes(2 * kb)
    tweak = rnd.randbytes(16)
    pt = rnd.randbytes(16 * nblocks)
    ct = X.lib_xts_encrypt(key, tweak, pt)
    assert X.lib_xts_decrypt(key, tweak, ct) == pt
    # pure-python cross-check of the first 64 blocks (XTS is block-sequential)
    crosscheck(key, tweak, pt, ct, "long", full=False)
    with open(os.path.join(outdir, "vec_long_%d.hex" % kbits), "w") as f:
        f.write("%032x\n" % 1)
        f.write("\n".join(record_xts(key, tweak, pt, ct, 1)) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("outdir")
    ap.add_argument("--seed", type=int, default=20260312)
    ap.add_argument("--long-blocks", type=int, default=65535)
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    for kbits in (128, 256):
        rnd = random.Random(a.seed * 1000 + kbits)
        n, cats = gen_xts(kbits, rnd, a.outdir)
        na = gen_aes(kbits, rnd, a.outdir)
        gen_long(kbits, rnd, a.outdir, a.long_blocks)
        print("K=%d: %d XTS units (published=%d random=%d special=%d), %d AES KAT records, "
              "long unit %d blocks" % (kbits, n, cats[0], cats[1], cats[2], na, a.long_blocks))
    return 0


if __name__ == "__main__":
    sys.exit(main())
