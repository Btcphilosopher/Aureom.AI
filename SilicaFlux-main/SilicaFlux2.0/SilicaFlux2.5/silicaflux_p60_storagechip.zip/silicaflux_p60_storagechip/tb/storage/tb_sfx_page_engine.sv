// =============================================================================
// SilicaFlux-STORE P60 :: tb_sfx_page_engine -- unit testbench of the page engine
//
//   * SFB2 memory slave with random request stalls and response latency, optional error injection
//   * BCH_ENC / BCH_DEC against P54's golden page vectors (ref/sfecc_page.py): raw page byte for byte,
//     corrected data + metadata, sector/page status incl. scrub hint, bad-block marker
//   * XTS_ENC / XTS_DEC against python `cryptography` (independent of the RTL), keys loaded through
//     the write-only register window; key zeroization; XTS without key; keys never readable
//   * full chain used by firmware:  XTS_ENC -> BCH_ENC -> inject bit errors -> BCH_DEC -> XTS_DEC
//   * protocol/robustness: submit while busy, bad opcode, fabric error (op still completes), mid-op reset,
//     register-page errors
// plusargs: +VEC=<p54 vec dir> +XVEC=<xts vec dir> +SEED=n +STALL=max_req_stall +LAT=max_rsp_latency
// =============================================================================
`timescale 1ns/1ps
`include "sfecc_defs.svh"
`include "sfecc_cfg.svh"
`include "tb_page_cfg.svh"
`include "xts_cfg.svh"
`default_nettype none

module tb_sfx_page_engine;
  localparam int KEYBITS = `PE_KEYBITS;
  localparam int NX      = `PE_NXTS;
  localparam int DATA    = `TBP_DATA;                // 512
  localparam int SPARE   = `TBP_SPARE;               // 32
  localparam int UM      = `TBP_UMETA;               // 16
  localparam int NP      = `TBP_NPAGE;
  localparam int RAW     = DATA + SPARE;             // 544
  localparam int PB      = 2 * DATA + 2 * UM + 2 * RAW;
  localparam int O_UMI = DATA, O_RAW = DATA + UM, O_RX = O_RAW + RAW, O_PAY = O_RX + RAW, O_UMO = O_PAY + DATA;
  localparam int SW_     = 4;                        // status words per page (1 sector + 3)
  localparam logic [31:0] S_BASE = 32'h0000_0100;
  localparam logic [31:0] R_BASE = 32'h0000_0800;
  localparam int XB      = 8 + 2 * DATA;             // bytes per xts record

  reg clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  integer cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  // ------------------------------------------------------------------ DUT
  reg         rb_sel = 1'b0, rb_we = 1'b0;
  reg  [11:0] rb_addr = '0;
  reg  [31:0] rb_wdata = '0;
  wire [31:0] rb_rdata;
  wire        rb_err;
  wire        m_req_valid, m_req_write;
  reg         m_req_ready = 1'b0;
  wire [31:0] m_req_addr, m_req_wdata;
  wire [3:0]  m_req_wstrb;
  reg         m_rsp_valid = 1'b0, m_rsp_error = 1'b0;
  wire        m_rsp_ready;
  reg  [31:0] m_rsp_rdata = '0;
  wire        busy, ev_corr, ev_unc, ev_int, ev_scrub, ev_fault;

  sfx_page_engine #(.XTS_KEYBITS(KEYBITS)) dut (
    .clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
    .busy, .ev_ecc_corr(ev_corr), .ev_ecc_unc(ev_unc), .ev_integrity(ev_int), .ev_scrub(ev_scrub), .ev_fault);

  // ------------------------------------------------------------------ SFB2 memory slave
  reg [7:0] mem [0:4095];
  integer stall_max = 3, lat_max = 3;
  reg        err_en = 1'b0;
  reg [31:0] err_addr = '0;
  integer    sst = 0, dly = 0, n_rd = 0, n_wr = 0;
  reg        c_wr;
  reg [31:0] c_addr, c_wdata;
  integer    rseed;
  function automatic integer rnd(input integer n);   // 0..n-1
    begin rnd = (n <= 1) ? 0 : ($urandom % n); end
  endfunction
  always @(posedge clk) begin
    m_req_ready <= 1'b0;
    m_rsp_valid <= 1'b0;
    m_rsp_error <= 1'b0;
    if (!rst_n) sst <= 0;
    else case (sst)
      0: if (m_req_valid) begin dly <= rnd(stall_max + 1); sst <= 1; end
      1: if (dly == 0) begin m_req_ready <= 1'b1; sst <= 2; end else dly <= dly - 1;
      2: begin
        c_wr <= m_req_write; c_addr <= m_req_addr; c_wdata <= m_req_wdata;
        if (m_req_write) begin
          mem[m_req_addr[11:0] + 0] <= m_req_wdata[7:0];
          mem[m_req_addr[11:0] + 1] <= m_req_wdata[15:8];
          mem[m_req_addr[11:0] + 2] <= m_req_wdata[23:16];
          mem[m_req_addr[11:0] + 3] <= m_req_wdata[31:24];
          n_wr <= n_wr + 1;
        end else n_rd <= n_rd + 1;
        dly <= rnd(lat_max + 1); sst <= 3;
      end
      3: if (dly == 0) begin
        m_rsp_valid <= 1'b1;
        m_rsp_error <= err_en && (c_addr == err_addr);
        m_rsp_rdata <= c_wr ? 32'h0 : {mem[c_addr[11:0] + 3], mem[c_addr[11:0] + 2], mem[c_addr[11:0] + 1], mem[c_addr[11:0]]};
        sst <= 0;
      end else dly <= dly - 1;
      default: sst <= 0;
    endcase
  end
  // protocol checkers: request held until accepted (R2), at most one outstanding
  reg        pv = 1'b0;
  reg [67:0] pq;
  integer    proto_err = 0;
  always @(posedge clk) if (rst_n) begin
    if (pv && !m_req_valid) proto_err <= proto_err + 1;                    // withdrawn
    if (pv && m_req_valid && pq !== {m_req_write, m_req_addr, m_req_wdata}) proto_err <= proto_err + 1;   // changed
    pv <= m_req_valid && !m_req_ready;
    pq <= {m_req_write, m_req_addr, m_req_wdata};
  end

  // ------------------------------------------------------------------ vectors
  reg [7:0]  vb  [0:NP*PB-1];
  reg [31:0] vs  [0:NP*SW_-1];
  reg [7:0]  xv  [0:NX*XB-1];
  reg [7:0]  xkey [0:2*KEYBITS/8-1];
  string vdir, xdir;
  integer checks = 0, errors = 0;

  task automatic fail(input string what, input integer a, input integer got, input integer exp);
    begin
      errors = errors + 1;
      if (errors <= 25) $display("TB FAIL %0s idx=%0d got=%0h exp=%0h (cycle %0d)", what, a, got, exp, cyc);
    end
  endtask
  task automatic chk(input string what, input integer a, input integer got, input integer exp);
    begin checks = checks + 1; if (got !== exp) fail(what, a, got, exp); end
  endtask

  // ------------------------------------------------------------------ register access
  task automatic rw(input [11:0] a, input [31:0] d);
    begin @(negedge clk); rb_sel = 1'b1; rb_we = 1'b1; rb_addr = a; rb_wdata = d; @(negedge clk); rb_sel = 1'b0; rb_we = 1'b0; end
  endtask
  task automatic rr(input [11:0] a, output [31:0] d);
    begin @(negedge clk); rb_sel = 1'b1; rb_we = 1'b0; rb_addr = a; #1 d = rb_rdata; @(negedge clk); rb_sel = 1'b0; end
  endtask
  reg [31:0] t0;
  task automatic status(output [31:0] st);
    begin rr(12'h014, st); end
  endtask
  // run one operation to completion; returns STATUS
  task automatic run_op(input [3:0] op, output [31:0] st, output integer cycles);
    integer c;
    begin
      rw(12'h018, S_BASE); rw(12'h01C, R_BASE);
      rw(12'h028, {28'h0, op});
      c = 0; st = 32'h0;
      while (!st[1] && c < 40000) begin status(st); c = c + 1; end
      cycles = c;
      if (!st[1]) begin errors = errors + 1; $display("TB FAIL op %0d did not complete (STATUS=%08x)", op, st); end
    end
  endtask

  // memory helpers
  task automatic mem_fill(input [31:0] base, input integer n, input [7:0] v);
    integer i; begin for (i = 0; i < n; i = i + 1) mem[base[11:0] + i] = v; end
  endtask

  // ------------------------------------------------------------------ BCH vector test
  reg [31:0] st, r0v, r1v;
  integer opc, pg, i, e0;
  integer n_cat [0:7];
  task automatic bch_vectors;
    reg [31:0] v, a, b, c;
    begin
      for (pg = 0; pg < NP; pg = pg + 1) begin
        // ------------- program path
        for (i = 0; i < DATA; i = i + 1) mem[S_BASE[11:0] + i] = vb[pg * PB + i];
        for (i = 0; i < UM; i = i + 1)   mem[S_BASE[11:0] + DATA + i] = vb[pg * PB + O_UMI + i];
        mem_fill(R_BASE, RAW + 16, 8'hAA);
        run_op(4'd1, st, opc);
        chk("enc status err", pg, st[2], 1'b0);
        e0 = errors;
        for (i = 0; i < RAW; i = i + 1) chk("raw byte", pg * 1000 + i, mem[R_BASE[11:0] + i], vb[pg * PB + O_RAW + i]);
        chk("enc overrun (guard)", pg, mem[R_BASE[11:0] + RAW], 8'hAA);
        if (errors != e0) $display("TB: page %0d encode mismatch", pg);
        // ------------- read path
        for (i = 0; i < RAW; i = i + 1) mem[R_BASE[11:0] + i] = vb[pg * PB + O_RX + i];
        mem_fill(S_BASE, DATA + UM + 16, 8'h55);
        run_op(4'd2, st, opc);
        chk("dec status err", pg, st[2], 1'b0);
        for (i = 0; i < DATA; i = i + 1) chk("dec data", pg * 1000 + i, mem[S_BASE[11:0] + i], vb[pg * PB + O_PAY + i]);
        for (i = 0; i < UM; i = i + 1)   chk("dec meta", pg * 100 + i, mem[S_BASE[11:0] + DATA + i], vb[pg * PB + O_UMO + i]);
        chk("dec overrun (guard)", pg, mem[S_BASE[11:0] + DATA + UM], 8'h55);
        rr(12'h02C, r0v); rr(12'h030, r1v);
        v = vs[pg * SW_ + 0]; a = vs[pg * SW_ + 1]; b = vs[pg * SW_ + 2]; c = vs[pg * SW_ + 3];
        chk("sector code", pg, r0v[2:0], v[2:0]);
        chk("sector nerr", pg, r0v[15:8], v[15:8]);
        chk("sector crc_ok", pg, r0v[20], v[16]);
        chk("page all_erased", pg, r0v[16], b[24]);
        chk("page ok", pg, r0v[17], b[25]);
        chk("page scrub", pg, r0v[18], b[26]);
        chk("page frame_err", pg, r0v[19], 1'b0);
        chk("page bbm", pg, r0v[31:24], c[7:0]);
        chk("page max_flips", pg, r1v[31:24], b[7:0]);
        chk("page tot_flips", pg, r1v[15:0], b[23:8]);
        n_cat[v[2:0]] = n_cat[v[2:0]] + 1;
        if (a === 32'hx) fail("page counts", pg, 0, 0);
      end
    end
  endtask

  // ------------------------------------------------------------------ XTS tests
  integer k, w;
  reg [63:0] tw;
  task automatic load_key;
    begin
      for (k = 0; k < 2 * KEYBITS / 32; k = k + 1)
        rw(12'h080 + 12'(4 * k), {xkey[4 * k + 3], xkey[4 * k + 2], xkey[4 * k + 1], xkey[4 * k]});
      rw(12'h040, 32'h1);                                     // commit
      w = 0; r0v = 0;
      while (!r0v[0] && w < 2000) begin rr(12'h044, r0v); w = w + 1; end
      chk("key_ready after commit", 0, r0v[0], 1'b1);
    end
  endtask
  task automatic xts_vectors;
    integer x;
    begin
      for (x = 0; x < NX; x = x + 1) begin
        tw = {xv[x * XB + 7], xv[x * XB + 6], xv[x * XB + 5], xv[x * XB + 4], xv[x * XB + 3], xv[x * XB + 2],
              xv[x * XB + 1], xv[x * XB + 0]};
        rw(12'h020, tw[31:0]); rw(12'h024, tw[63:32]);
        for (i = 0; i < DATA; i = i + 1) mem[S_BASE[11:0] + i] = xv[x * XB + 8 + i];
        mem_fill(S_BASE + DATA, 16, 8'h5A);
        run_op(4'd3, st, opc);
        chk("xts enc status", x, st[2], 1'b0);
        for (i = 0; i < DATA; i = i + 1) chk("xts ciphertext", x * 1000 + i, mem[S_BASE[11:0] + i], xv[x * XB + 8 + DATA + i]);
        chk("xts enc guard", x, mem[S_BASE[11:0] + DATA], 8'h5A);
        run_op(4'd4, st, opc);
        chk("xts dec status", x, st[2], 1'b0);
        for (i = 0; i < DATA; i = i + 1) chk("xts plaintext", x * 1000 + i, mem[S_BASE[11:0] + i], xv[x * XB + 8 + i]);
      end
    end
  endtask

  // ------------------------------------------------------------------ chain test: XTS -> BCH -> errors -> BCH -> XTS
  reg [7:0] plain [0:DATA-1];
  integer n_chain_ok = 0, n_chain_unc = 0;
  task automatic chain(input integer nflip, input integer cnum);
    integer f, pos, bit_;
    reg [31:0] v;
    reg [7:0] um_in [0:UM-1];
    begin
      tw = {$urandom, $urandom};
      rw(12'h020, tw[31:0]); rw(12'h024, tw[63:32]);
      for (i = 0; i < DATA; i = i + 1) begin plain[i] = $urandom; mem[S_BASE[11:0] + i] = plain[i]; end
      for (i = 0; i < UM; i = i + 1)   begin um_in[i] = $urandom; mem[S_BASE[11:0] + DATA + i] = um_in[i]; end
      run_op(4'd3, st, opc);                                   // XTS encrypt (in place)
      run_op(4'd1, st, opc);                                   // BCH encode  S -> R
      chk("chain enc err", cnum, st[2], 1'b0);
      // inject nflip distinct bit errors into the codeword area (data bytes + spare bytes 1..31; not the BBM byte)
      for (f = 0; f < nflip; f = f + 1) begin
        pos = 1 + rnd(RAW - 1);
        if (pos == DATA) pos = DATA + 1;                       // skip the bad-block marker byte (outside the codeword)
        bit_ = rnd(8);
        mem[R_BASE[11:0] + pos] = mem[R_BASE[11:0] + pos] ^ (8'h1 << bit_);
      end
      mem_fill(S_BASE, DATA + UM, 8'h00);
      run_op(4'd2, st, opc);                                   // BCH decode  R -> S
      rr(12'h02C, r0v);
      if (nflip <= 8) begin
        chk("chain sector code", cnum, r0v[2:0], (nflip == 0) ? 3'd0 : 3'd1);
        chk("chain nerr (distinct flips may share bits => <=)", cnum, (r0v[15:8] <= nflip[7:0]) ? 1 : 0, 1);
        chk("chain crc", cnum, r0v[20], 1'b1);
        run_op(4'd4, st, opc);                                 // XTS decrypt
        for (i = 0; i < DATA; i = i + 1) chk("chain plaintext", cnum * 1000 + i, mem[S_BASE[11:0] + i], plain[i]);
        for (i = 0; i < UM; i = i + 1)   chk("chain meta", cnum * 100 + i, mem[S_BASE[11:0] + DATA + i], um_in[i]);
        n_chain_ok = n_chain_ok + 1;
      end else begin
        v = r0v;
        chk("chain beyond-t flagged (uncorrectable/integrity)", cnum, (v[2:0] == 3'd3 || v[2:0] == 3'd4) ? 1 : 0, 1);
        n_chain_unc = n_chain_unc + 1;
      end
    end
  endtask

  // ------------------------------------------------------------------ main
  integer seed_i, x2;
  reg [31:0] sv;
  integer chain_n;
  initial begin
    if (!$value$plusargs("VEC=%s", vdir)) vdir = "vec";
    if (!$value$plusargs("XVEC=%s", xdir)) xdir = "xvec";
    if ($value$plusargs("STALL=%d", stall_max)) ;
    if ($value$plusargs("LAT=%d", lat_max)) ;
    if ($value$plusargs("SEED=%d", seed_i)) x2 = $urandom(seed_i);
    for (i = 0; i < 8; i = i + 1) n_cat[i] = 0;
    for (i = 0; i < 4096; i = i + 1) mem[i] = 8'h00;
    $readmemh({vdir, "/page_bytes.memh"}, vb);
    $readmemh({vdir, "/page_st.memh"}, vs);
    $readmemh({xdir, "/xts_vec.memh"}, xv);
    $readmemh({xdir, "/xts_key.memh"}, xkey);
    repeat (4) @(negedge clk);
    rst_n = 1'b1;
    repeat (4) @(negedge clk);

    // ---------------- identity / register page
    rr(12'h000, r0v); chk("ID", 0, r0v, 32'h53465850);
    rr(12'h008, r0v); chk("CAPS0", 0, r0v, {16'(SPARE), 16'(DATA)});
    rr(12'h100, r0v); chk("ECC window ID", 0, r0v, 32'h53454343);
    rr(12'h014, r0v); chk("STATUS idle", 0, r0v[3:0], 4'h0);
    @(negedge clk); rb_sel = 1'b1; rb_we = 1'b0; rb_addr = 12'h0F0; #1 chk("unknown offset raises rb_err", 0, rb_err, 1'b1); @(negedge clk); rb_sel = 1'b0;

    // ---------------- BCH against P54 golden vectors
    $display("TB: BCH vectors (%0d pages), stall<=%0d lat<=%0d", NP, stall_max, lat_max);
    bch_vectors;

    // ---------------- XTS without a key is refused
    rw(12'h020, 32'h1); rw(12'h024, 32'h0);
    run_op(4'd3, st, opc);
    chk("xts without key: err", 0, st[2], 1'b1);
    chk("xts without key: code 3", 0, st[15:12], 4'd3);
    chk("xts without key: not busy", 0, st[0], 1'b0);

    // ---------------- key load, XTS vectors, zeroize
    load_key;
    // the key window is write-only
    rr(12'h080, r0v); chk("key window reads 0", 0, r0v, 32'h0);
    rr(12'h084, r0v); chk("key window reads 0 (w1)", 0, r0v, 32'h0);
    $display("TB: XTS-AES-%0d vectors (%0d records)", KEYBITS, NX);
    xts_vectors;
    // key bytes are inside the DUT only: zeroize and prove it
    rw(12'h040, 32'h2);
    repeat (4) @(negedge clk);
    rr(12'h044, r0v); chk("key_ready low after zeroize", 0, r0v[0], 1'b0);
    run_op(4'd3, st, opc);
    chk("xts after zeroize refused", 0, st[2], 1'b1);
    chk("xts after zeroize code", 0, st[15:12], 4'd3);

    // ---------------- chain test with bit errors (needs the key again)
    load_key;
    $display("TB: chain XTS->BCH->errors->BCH->XTS");
    chain_n = 0;
    for (k = 0; k <= 8; k = k + 1) begin chain(k, chain_n); chain_n = chain_n + 1; end
    for (k = 0; k < 12; k = k + 1) begin chain(1 + rnd(8), chain_n); chain_n = chain_n + 1; end
    for (k = 9; k <= 14; k = k + 1) begin chain(k, chain_n); chain_n = chain_n + 1; end

    // ---------------- robustness
    // opcode error
    rw(12'h018, S_BASE); rw(12'h01C, R_BASE); rw(12'h028, 32'h7);
    status(sv); chk("bad opcode err", 0, sv[2], 1'b1); chk("bad opcode code", 0, sv[15:12], 4'd2); chk("bad opcode done", 0, sv[1], 1'b1);
    // submit while busy: ignored, flagged, running op unaffected
    for (i = 0; i < DATA; i = i + 1) mem[S_BASE[11:0] + i] = vb[i];
    for (i = 0; i < UM; i = i + 1)   mem[S_BASE[11:0] + DATA + i] = vb[O_UMI + i];
    rw(12'h028, 32'h1);
    rw(12'h028, 32'h1);
    status(sv); chk("busy submit flagged", 0, sv[15:12], 4'd1);
    w = 0; sv = 0; while (!sv[1] && w < 40000) begin status(sv); w = w + 1; end
    for (i = 0; i < RAW; i = i + 1) chk("raw after dup submit", i, mem[R_BASE[11:0] + i], vb[O_RAW + i]);
    // fabric error: operation still completes, error recorded, engine stays usable
    err_en = 1'b1; err_addr = S_BASE + 32'd8;
    rw(12'h028, 32'h1);
    w = 0; sv = 0; while (!sv[1] && w < 40000) begin status(sv); w = w + 1; end
    chk("fabric error completes", 0, sv[1], 1'b1); chk("fabric error flagged", 0, sv[2], 1'b1); chk("fabric error code", 0, sv[15:12], 4'd4);
    err_en = 1'b0;
    for (i = 0; i < DATA; i = i + 1) mem[S_BASE[11:0] + i] = vb[i];
    run_op(4'd1, sv, opc);
    chk("clean op after fabric error", 0, sv[2], 1'b0);
    for (i = 0; i < RAW; i = i + 1) chk("raw after fabric error", i, mem[R_BASE[11:0] + i], vb[O_RAW + i]);
    // mid-operation reset, then a clean operation
    rw(12'h028, 32'h2);
    repeat (40) @(negedge clk);
    rst_n = 1'b0; repeat (3) @(negedge clk); rst_n = 1'b1; repeat (3) @(negedge clk);
    status(sv); chk("idle after reset", 0, sv[0], 1'b0);
    for (i = 0; i < RAW; i = i + 1) mem[R_BASE[11:0] + i] = vb[O_RX + i];
    run_op(4'd2, sv, opc);
    for (i = 0; i < DATA; i = i + 1) chk("dec after reset", i, mem[S_BASE[11:0] + i], vb[O_PAY + i]);
    // counters
    rr(12'h0C0, r0v); $display("TB counters: bch_enc=%0d", r0v);
    rr(12'h0C4, r1v); $display("TB counters: bch_dec=%0d", r1v);
    // counters are cleared by reset: since the mid-op reset exactly one decode (and no encode) has completed
    chk("enc counter since reset", 0, r0v, 32'd0);
    chk("dec counter since reset", 0, r1v, 32'd1);

    chk("SFB2 protocol violations", 0, proto_err, 0);
    $display("TB categories decoded: clean=%0d corrected=%0d erased=%0d uncorr=%0d integrity=%0d; chain ok=%0d beyond-t=%0d; fabric reads=%0d writes=%0d",
             n_cat[0], n_cat[1], n_cat[2], n_cat[3], n_cat[4], n_chain_ok, n_chain_unc, n_rd, n_wr);
    $display("TB RESULT tb_sfx_page_engine keybits=%0d stall=%0d lat=%0d checks=%0d errors=%0d -> %s", KEYBITS, stall_max, lat_max, checks, errors,
             (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
  // global watchdog
  initial begin #200000000; $display("TB RESULT tb_sfx_page_engine TIMEOUT -> FAIL"); $finish; end
endmodule

`default_nettype wire
