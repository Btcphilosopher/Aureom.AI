#!/bin/bash
# Build and run the page-engine unit testbench (Verilator) for XTS-AES-128 and -256 and several
# SFB2 stall/latency settings.  Needs: P54 vectors (vendor/p54/build/vec/N512T8U16, see Makefile
# target `vectors`) and XTS vectors (gen_pe_vectors.py).  Exit status 0 only if every run PASSes.
set -u
HERE=$(cd "$(dirname "$0")" && pwd); P60=$(cd "$HERE/../.." && pwd)
P54=$P60/vendor/p54; B=$P60/build/pe; mkdir -p "$B"
PY=${PY:-python3}
VEC=$P54/build/vec/N512T8U16
[ -f "$VEC/page_bytes.memh" ] || { echo "missing P54 vectors: run 'make vectors'"; exit 2; }
RTL54=$(grep -v '^//' $P54/rtl/files.f | grep -v '^$' | sed "s#^rtl/#$P54/rtl/#")
SEC="$P60/rtl/security/sfx_aes_sbox.sv $P60/rtl/security/sfx_aes_keyexp.sv $P60/rtl/security/sfx_aes_core.sv $P60/rtl/security/sfx_aes_xts.sv"
rc=0
for KB in 256 128; do
  XV=$B/xvec$KB; $PY "$HERE/gen_pe_vectors.py" "$XV" $KB 24 >/dev/null || exit 2
  M=$B/vl_$KB
  verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD -O2 --top-module tb_sfx_page_engine \
    -I$P54/rtl -I$P54/rtl/generated -I$VEC -I$XV --Mdir $M -o sim $RTL54 $SEC \
    $P60/rtl/storage/sfx_page_engine.sv $HERE/tb_sfx_page_engine.sv > $B/build_$KB.log 2>&1 || { echo "BUILD FAIL keybits=$KB (see $B/build_$KB.log)"; rc=1; continue; }
  for CFG in "0 0 1" "3 3 2" "8 12 3"; do
    set -- $CFG
    out=$($M/sim +VEC=$VEC +XVEC=$XV +STALL=$1 +LAT=$2 +SEED=$3 2>&1)
    echo "$out" | grep -E "TB (FAIL|RESULT|categories)" | head -30
    echo "$out" | grep -q -- "-> PASS" || rc=1
  done
done
exit $rc
