#!/usr/bin/env python3
"""
gen_pe_vectors.py -- reference vectors for tb_sfx_page_engine (SilicaFlux-STORE P60).

XTS-AES vectors come from the python `cryptography` package (OpenSSL), i.e. an
implementation independent of the RTL.  BCH vectors are P54's own (ref/sfecc_page.py,
cross-validated by P54 against three independent sources); this script also writes
chain vectors: plaintext -> XTS -> BCH encode (reference) -> flip bits -> expected decode.

usage: gen_pe_vectors.py <out_dir> <keybits 128|256> [n_xts] [seed]
"""
import os, sys, random
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

out = sys.argv[1]
kb = int(sys.argv[2])
nx = int(sys.argv[3]) if len(sys.argv) > 3 else 24
seed = int(sys.argv[4]) if len(sys.argv) > 4 else 60
assert kb in (128, 256)
os.makedirs(out, exist_ok=True)
rnd = random.Random(seed)

def xts(key, tweak16, data, decrypt):
    c = Cipher(algorithms.AES(key), modes.XTS(tweak16))
    op = c.decryptor() if decrypt else c.encryptor()
    return op.update(data) + op.finalize()

key = bytes(rnd.getrandbits(8) for _ in range(2 * kb // 8))      # key1 || key2
with open(os.path.join(out, "xts_key.memh"), "w") as f:
    f.write("\n".join(f"{b:02x}" for b in key) + "\n")

recs = []
for i in range(nx):
    ppn = rnd.getrandbits(64) if i % 3 == 0 else rnd.randrange(0, 1 << 16)
    kind = i % 4
    if kind == 0:   data = bytes(rnd.getrandbits(8) for _ in range(512))
    elif kind == 1: data = bytes(512)                        # all zero
    elif kind == 2: data = b"\xff" * 512                     # all ones
    else:           data = bytes((j * 7 + i) & 0xFF for j in range(512))
    tw = ppn.to_bytes(16, "little")
    ct = xts(key, tw, data, False)
    assert xts(key, tw, ct, True) == data
    recs.append((ppn, data, ct))
with open(os.path.join(out, "xts_vec.memh"), "w") as f:
    for ppn, data, ct in recs:
        blob = ppn.to_bytes(8, "little") + data + ct
        f.write("\n".join(f"{b:02x}" for b in blob) + "\n")
with open(os.path.join(out, "xts_cfg.svh"), "w") as f:
    f.write(f"`define PE_NXTS {nx}\n`define PE_KEYBITS {kb}\n")
print(f"wrote {nx} XTS records, keybits={kb}")
