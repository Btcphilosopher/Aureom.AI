// =============================================================================
// SilicaFlux-STORE P60 :: tb_p60_scenarios.svh -- scenario tasks included into tb_p60_soc
// (invalid commands, concurrency, back-pressure, controller reset, power-fail pin, security, bad blocks,
//  constrained-random workload, end-of-test checks)
// =============================================================================

  // ---------------------------------------------------------------- invalid commands (hardware validation + firmware refusals)
  task automatic s_invalid();
    int t, st;
    grp = "invalid";
    wr(10, 2, 0, st);
    do_cmd(8'h55, 0, 64'd0, 1, hbuf(1), SFS_ST_INVALID_OPCODE, t);                         // unknown opcode
    do_cmd(SFS_OP_READ, 8'h80, 64'd0, 1, hbuf(1), SFS_ST_INVALID_FIELD, t);                 // reserved flag bit
    do_cmd(SFS_OP_READ, 0, 64'd0, 0, hbuf(1), SFS_ST_INVALID_FIELD, t);                     // LEN = 0
    check("LEN_ZERO error code", 64'(err_of(t)), SFS_ERR_LEN_ZERO);
    do_cmd(SFS_OP_READ, 0, 64'd0, 17, hbuf(1), SFS_ST_INVALID_FIELD, t);                    // LEN > MDTS
    check("LEN_MAX error code", 64'(err_of(t)), SFS_ERR_LEN_MAX);
    do_cmd(SFS_OP_READ, 0, 64'(cap_lba), 1, hbuf(1), SFS_ST_LBA_RANGE, t);                  // first LBA past the end
    do_cmd(SFS_OP_WRITE, 0, 64'(cap_lba - 1), 2, hbuf(1), SFS_ST_LBA_RANGE, t);             // straddles the end
    do_cmd(SFS_OP_READ, 0, 64'd0, 1, hbuf(1) + 2, SFS_ST_INVALID_FIELD, t);                 // misaligned host buffer
    check("HOST_ADDR error code", 64'(err_of(t)), SFS_ERR_HOST_ADDR);
    do_cmd(SFS_OP_READ, 8'h01, 64'd0, 1, hbuf(1), SFS_ST_ACCESS_DENIED, t);     // physical addressing not enabled
    do_cmd(SFS_OP_READ, 0, 64'(32'h1) << 40, 1, hbuf(1), SFS_ST_INVALID_FIELD, t);          // address bits above the implemented width
    // after all that the device still serves correct data
    rd_check(10, 2, "data intact after invalid commands", st);
    check("read status after invalid commands", 64'(st), SFS_ST_SUCCESS);
    do_cmd(SFS_OP_READ, 0, 64'(cap_lba - 1), 1, hbuf(1), SFS_ST_SUCCESS, t);                // last valid LBA
  endtask

  // ---------------------------------------------------------------- concurrency: queue depth = tags, no drops / duplicates
  task automatic s_concurrency();
    int tids [$], kind [int], lbas [int], ns [int], g0s [int], st, nreap, ooo;
    grp = "concurrency";
    cpl_order.delete();
    for (int i = 0; i < NT; i++) begin
      int t, g0; t = new_tid();
      lbas[t] = 200 + i * 8; ns[t] = 4 + (i % 4);
      g0 = gen_ctr + 1; g0s[t] = g0;
      fill_host_gen(hbuf(i), lbas[t], ns[t], g0);
      for (int j = 0; j < ns[t]; j++) gpend[lbas[t] + j] = g0 + j;
      gen_ctr += ns[t];
      submit(SFS_OP_WRITE, 0, t, 64'(lbas[t]), ns[t], hbuf(i), SFS_ST_SUCCESS);
      tids.push_back(t);
    end
    ring();
    wait_tids(tids, 30_000_000);
    foreach (tids[i]) for (int j = 0; j < ns[tids[i]]; j++) begin gexp[lbas[tids[i]] + j] = g0s[tids[i]] + j; gpend[lbas[tids[i]] + j] = -1; end
    check("all commands completed once", 64'(cpl_order.size()), NT);
    ooo = 0; for (int i = 1; i < cpl_order.size(); i++) if (cpl_order[i] < cpl_order[i - 1]) ooo++;
    $display("TB concurrency: %0d writes in flight, %0d completions, %0d out of submission order", NT, cpl_order.size(), ooo);
    // eight reads in flight, each verified
    tids.delete();
    for (int i = 0; i < NT; i++) begin
      int t; t = new_tid(); lbas[t] = 200 + i * 8; ns[t] = 4 + (i % 4);
      clear_host(hbuf(i), ns[t]);
      submit(SFS_OP_READ, 0, t, 64'(lbas[t]), ns[t], hbuf(i), SFS_ST_SUCCESS);
      tids.push_back(t); kind[t] = i;
    end
    ring();
    wait_tids(tids, 30_000_000);
    foreach (tids[i]) for (int j = 0; j < ns[tids[i]]; j++)
      check($sformatf("concurrent read TID %04h LBA %0d", tids[i], lbas[tids[i]] + j), 64'(cmp_block(hbuf(kind[tids[i]]), j, lbas[tids[i]] + j, gexp[lbas[tids[i]] + j])), 0);
    rd_check(200, 1, "post-concurrency", st);
  endtask

  // ---------------------------------------------------------------- back-pressure: slow host memory, full CQ
  task automatic s_backpressure();
    int st, tids [$], t;
    grp = "backpressure";
    bp_pct = 50; lat_max = 8;
    for (int i = 0; i < 6; i++) begin wr(300 + i * 5, 5, 0, st); check("write under host back-pressure", 64'(st), SFS_ST_SUCCESS); end
    for (int i = 0; i < 6; i++) begin rd_check(300 + i * 5, 5, "read under host back-pressure", st); check("read under back-pressure", 64'(st), SFS_ST_SUCCESS); end
    bp_pct = 0; lat_max = 2;
    // fill the completion queue without reaping: HQD-1 commands outstanding
    for (int i = 0; i < HQD - 1; i++) begin
      t = new_tid(); submit(SFS_OP_READ, 0, t, 64'(300 + (i % 20)), 1, hbuf(2 + (i % 4)), SFS_ST_SUCCESS); tids.push_back(t);
    end
    ring();
    repeat (200_000) @(posedge clk);                         // let the controller run into the full CQ before the host looks
    wait_tids(tids, 40_000_000);
    check("every queued command completed once", 64'(tids.size()), HQD - 1);
    rd_check(300, 5, "data intact after CQ-full back-pressure", st);
  endtask

  // ---------------------------------------------------------------- controller reset (CC.EN 1 -> 0) with commands in flight
  task automatic s_ctrlreset();
    int tids [$], st; logic [31:0] v; longint t0;
    grp = "ctrlreset";
    for (int i = 0; i < 4; i++) begin
      int t, g0; t = new_tid(); g0 = gen_ctr + 1; gen_ctr += 8;
      fill_host_gen(hbuf(i), 120 + i * 8, 8, g0);
      for (int j = 0; j < 8; j++) gpend[120 + i * 8 + j] = g0 + j;
      submit(SFS_OP_WRITE, 0, t, 64'(120 + i * 8), 8, hbuf(i), -1);
      tids.push_back(t);
    end
    ring();
    repeat (3000) @(posedge clk);
    bw(SHC + SFS_SHC_CTRL, 32'h0);                           // controller reset with commands in flight
    t0 = cyc;
    do br(SHC + SFS_SHC_STATUS, v); while ((v[0] || v[5]) && cyc - t0 < 20_000_000);
    check("reset completed: RDY = 0", 64'(v[0]), 0);
    check("reset completed: not RESETTING", 64'(v[5]), 0);
    br(SHC + SFS_SHC_CQ_TAIL, v); check("queues cleared", v, 0);
    foreach (tids[i]) seen[tids[i]] = 1;                     // aborted commands are not reported after a reset
    enable_ctrl();
    begin int t; do_cmd(SFS_OP_IDENTIFY, 0, 0, 0, 32'h3000, SFS_ST_SUCCESS, t); check("controller usable after reset", hmem.rd32(32'h3000), SFS_SYS_ID_VALUE); end
    crash_verify(0);                                         // aborted writes are either fully applied or not; older data must be intact
    rd_check(0, 4, "earlier data survives a controller reset", st);
  endtask

  // ---------------------------------------------------------------- power-fail pin (brown-out): STOP policy, WP#, remount
  task automatic s_plp();
    int tids [$], q [$], st, t; logic [31:0] v; longint t0;
    grp = "plp";
    for (int l = 0; l < 64; l += 8) wr(l, 8, 0, st);
    for (int i = 0; i < 3; i++) begin
      int tt, g0; tt = new_tid(); g0 = gen_ctr + 1; gen_ctr += 8;
      fill_host_gen(hbuf(i), 64 + i * 8, 8, g0);
      for (int j = 0; j < 8; j++) gpend[64 + i * 8 + j] = g0 + j;
      submit(SFS_OP_WRITE, 0, tt, 64'(64 + i * 8), 8, hbuf(i), -1);
      tids.push_back(tt);
    end
    ring();
    repeat (6000) @(posedge clk);
    pwr_fail_n = 0;                                          // power-fail pin (asynchronous)
    wait_tids(tids, 30_000_000);                             // each: SUCCESS (finished before the fault) or ABORT_PWR_LOSS
    foreach (tids[i]) begin
      int s0; s0 = st_of(tids[i]);
      check($sformatf("TID %04h: SUCCESS or ABORT_PWR_LOSS", tids[i]), 64'(s0 == SFS_ST_SUCCESS || s0 == SFS_ST_ABORT_PWR_LOSS), 1);
      if (s0 == SFS_ST_SUCCESS) for (int j = 0; j < 8; j++) begin gexp[64 + i * 8 + j] = gpend[64 + i * 8 + j]; gpend[64 + i * 8 + j] = -1; end
    end
    t = new_tid(); submit(SFS_OP_WRITE, 0, t, 64'd200, 1, hbuf(1), SFS_ST_ABORT_PWR_LOSS); q.push_back(t);
    ring(); wait_tids(q, 20_000_000);
    check("new write refused with QUIESCED", 64'(err_of(t)), SFS_ERR_QUIESCED);
    br(SHC + SFS_SHC_STATUS, v); check("host sees PLP", 64'(v[4]), 1);
    t0 = cyc;
    while (wp_n[0] && cyc - t0 < 20_000_000) @(posedge clk);
    check("NAND WP# asserted (FW_SAFE)", 64'(wp_n[0]), 0);
    pwr_fail_n = 1;
    t0 = cyc;
    while (!wp_n[0] && cyc - t0 < 20_000_000) @(posedge clk);
    check("WP# released after power restore", 64'(wp_n[0]), 1);
    do br(SHC + SFS_SHC_STATUS, v); while (v[4] && cyc - t0 < 20_000_000);
    // the firmware remounts the FTL (recovery); wait for the controller to serve again
    begin
      bit ok = 0;
      for (int i = 0; i < 40 && !ok; i++) begin
        t = new_tid(); submit(SFS_OP_IDENTIFY, 0, t, 64'd0, 0, 32'h3000, -1); ring(); q.delete(); q.push_back(t); wait_tids(q, 20_000_000);
        ok = (st_of(t) == SFS_ST_SUCCESS);
        if (!ok) repeat (20_000) @(posedge clk);
      end
      check_true("serving again after the power event", ok);
    end
    crash_verify(0);                                         // acknowledged data survived; in-flight data old-or-new
    wr(200, 1, 0, st); check("write after the power event", 64'(st), SFS_ST_SUCCESS);
  endtask

  // ---------------------------------------------------------------- security: data at rest, key policy
  task automatic s_security();
    int st, found_plain, blk, pg, fd, t;
    logic [255:0] sig;
    grp = "security";
    for (int l = 0; l < 48; l++) begin wr(l, 1, 0, st); check("security: write", 64'(st), SFS_ST_SUCCESS); end
    verify_all("security: round trip");
    // scan the raw medium for the plaintext of LBA 5 (first 16 bytes)
    found_plain = 0;
    for (int b = 0; b < NBLK; b++) for (int p = 0; p < PPB; p++) begin
      bit m = 1;
      for (int w = 0; w < 4 && m; w++) begin
        logic [31:0] x;
        x = pat(5, w, gexp[5]);
        for (int by = 0; by < 4; by++) if (flash.bd_peek(0, b, p, w * 4 + by) !== x[8*by +: 8]) m = 0;
      end
      if (m) found_plain++;
    end
    if (xts_mode != 0) check("XTS: plaintext of LBA 5 not present on the medium", 64'(found_plain), 0);
    else               check("plain mode: plaintext of LBA 5 present on the medium", 64'(found_plain), 1);
    // dump (key, ppn, plaintext, raw data bytes) for an independent XTS check (tools/check_xts_nand.py)
    if (xts_mode != 0) begin
      scan_map();
      fd = $fopen("xts_dump.txt", "w");
      $fdisplay(fd, "KEY %s", $sformatf("%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x%08x",
        test_key[0], test_key[1], test_key[2], test_key[3], test_key[4], test_key[5], test_key[6], test_key[7],
        test_key[8], test_key[9], test_key[10], test_key[11], test_key[12], test_key[13], test_key[14], test_key[15]));
      for (int l = 0; l < 48; l++) if (find_phys(l, blk, pg)) begin
        string s_pl = "", s_raw = "";
        for (int w = 0; w < 128; w++) begin
          logic [31:0] x; x = pat(l, w, gexp[l]);
          s_pl = {s_pl, $sformatf("%02x%02x%02x%02x", x[7:0], x[15:8], x[23:16], x[31:24])};
        end
        for (int by = 0; by < 512; by++) s_raw = {s_raw, $sformatf("%02x", flash.bd_peek(0, blk, pg, by))};
        $fdisplay(fd, "PAGE %0d %s %s", blk * PPB + pg, s_pl, s_raw);
      end
      $fclose(fd);
      $display("TB security: wrote xts_dump.txt for tools/check_xts_nand.py");
    end
  endtask

  // key-policy tests (XTS firmware only): wrong key refused, right key serves, crypto-erase makes data unreadable
  task automatic s_keypolicy();
    int st, t;
    grp = "keypolicy";
    if (xts_mode == 0) return;
    for (int l = 0; l < 24; l++) wr(l, 1, 0, st);
    // 1. power cycle, WRONG key: the FTL cannot mount (metadata decrypts to garbage) and the controller refuses to serve
    power_cycle(100);
    n_con_unc = 0;
    boot(1'b0, 1'b1);
    check("wrong key: controller never becomes ready", 64'(last_boot_ok), 0);
    check_true("wrong key: firmware reported the mount failure", n_con_unc >= 1);
    // 2. power cycle, right key: everything is back
    power_cycle(100);
    boot();
    enable_ctrl();
    tid_next += 16; exp_st.delete(); seen.delete();
    for (int l = 0; l < 24; l++) begin rd_check(l, 1, "right key after wrong key", st); check("read after right key", 64'(st), SFS_ST_SUCCESS); end
    // 3. crypto-erase: zeroize the key; the stored data becomes unreadable (explicit error, never garbage)
    mbox_cmd(32'h56, 0, 2_000_000);
    check("KEY_ZEROIZE ok", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_OK);
    do_cmd(SFS_OP_READ, 0, 64'd3, 1, hbuf(1), -1, t);
    check("after crypto-erase: read fails explicitly", 64'(st_of(t)), SFS_ST_MEDIA_UNREC);
  endtask

  // ---------------------------------------------------------------- bad blocks (factory-bad + forced program/erase failures configured in the twin)
  task automatic s_badblock();
    int st, t, nops; logic [31:0] bf, bg, pf, ef;
    grp = "badblock";
    if (!$value$plusargs("nops=%d", nops)) nops = 300;
    s_integrity(nops);
    do_cmd(SFS_OP_GET_LOG, 0, 0, 0, 32'hE000, SFS_ST_SUCCESS, t);
    bf = hmem.rd32(32'hE000 + 30 * 4); bg = hmem.rd32(32'hE000 + 31 * 4);
    pf = hmem.rd32(32'hE000 + 17 * 4); ef = hmem.rd32(32'hE000 + 18 * 4);
    $display("TB badblock: factory-bad %0d, grown-bad %0d, program failures %0d, erase failures %0d, blocks retired %0d", bf, bg, pf, ef, hmem.rd32(32'hE000 + 16 * 4));
    if ($test$plusargs("badcfg")) begin
      check_true("factory bad blocks detected", bf >= 2);
      check_true("a forced program failure was handled", pf >= 1);
      check_true("a forced erase failure was handled", ef >= 1);
      check_true("grown bad block recorded", bg >= 1);
    end
    verify_all("badblock: final");
  endtask

  // ---------------------------------------------------------------- constrained-random workload with queue depth up to 6
  task automatic s_random(input int nops);
    int act [6], kind [6], lba_s [6], n_s [6], g0_s [6], tid_s [6], st, nreap, issued = 0, lenhist = 0, nb;
    int ntot, op, n, lba, slot, flags;
    grp = "random";
    for (int i = 0; i < 6; i++) act[i] = 0;
    for (int l = 0; l < 128; l += 8) wr(l, 8, 0, st);          // seed some data
    ntot = 0;
    while (ntot < nops || (act[0] | act[1] | act[2] | act[3] | act[4] | act[5]) != 0) begin
      // issue a new command into every free slot (while ops remain)
      for (slot = 0; slot < 6 && ntot < nops; slot++) if (!act[slot] && rnd(3) != 0) begin
        bit conflict;
        op = rnd(100);
        n = 1 + rnd(8); if (rnd(10) == 0) n = 9 + rnd(8);       // up to MDTS = 16
        lba = rnd(cap_lba - n + 1);
        conflict = 0;
        for (int o = 0; o < 6; o++) if (act[o] && o != slot && lba < lba_s[o] + n_s[o] && lba_s[o] < lba + n && (kind[o] != 1 || op < 50 ? 1'b1 : 1'b1)) conflict = 1;
        if (conflict) continue;
        tid_s[slot] = new_tid(); lba_s[slot] = lba; n_s[slot] = n; act[slot] = 1; ntot++;
        cov_len[n]++;
        if (op < 50) begin                                      // write
          flags = (rnd(8) == 0) ? FLAG_FUA : 0;
          g0_s[slot] = gen_ctr + 1; gen_ctr += n; kind[slot] = 0;
          fill_host_gen(hbuf(slot), lba, n, g0_s[slot]);
          for (int i = 0; i < n; i++) gpend[lba + i] = g0_s[slot] + i;
          submit(SFS_OP_WRITE, flags, tid_s[slot], 64'(lba), n, hbuf(slot), SFS_ST_SUCCESS);
          cov_op[0]++;
        end else if (op < 88) begin                             // read
          kind[slot] = 1; clear_host(hbuf(slot), n);
          submit(SFS_OP_READ, 0, tid_s[slot], 64'(lba), n, hbuf(slot), SFS_ST_SUCCESS);
          cov_op[1]++;
        end else if (op < 95) begin                             // trim
          kind[slot] = 2;
          for (int i = 0; i < n; i++) tpend[lba + i] = 1;
          submit(SFS_OP_DEALLOCATE, 0, tid_s[slot], 64'(lba), n, 32'h0, SFS_ST_SUCCESS);
          cov_op[2]++;
        end else begin                                          // flush
          kind[slot] = 3; n_s[slot] = 0;
          submit(SFS_OP_FLUSH, 0, tid_s[slot], 64'd0, 0, 32'h0, SFS_ST_SUCCESS);
          cov_op[3]++;
        end
        issued++;
      end
      ring();
      repeat (200) @(posedge clk);
      reap(nreap);
      // retire completed slots: update the oracle / verify reads
      for (slot = 0; slot < 6; slot++) if (act[slot] && seen[tid_s[slot]]) begin
        if (st_of(tid_s[slot]) == SFS_ST_SUCCESS) begin
          case (kind[slot])
            0: for (int i = 0; i < n_s[slot]; i++) begin gexp[lba_s[slot] + i] = g0_s[slot] + i; gpend[lba_s[slot] + i] = -1; end
            1: for (int i = 0; i < n_s[slot]; i++) begin
                 if (cmp_block(hbuf(slot), i, lba_s[slot] + i, gexp[lba_s[slot] + i]) != 0) begin
                   n_fail++; $display("[%0d] FAIL random: read data mismatch LBA %0d (gen %0d)", cyc, lba_s[slot] + i, gexp[lba_s[slot] + i]);
                 end else n_pass++;
               end
            2: for (int i = 0; i < n_s[slot]; i++) begin gexp[lba_s[slot] + i] = 0; tpend[lba_s[slot] + i] = 0; end
            default: ;
          endcase
        end else begin
          for (int i = 0; i < n_s[slot]; i++) begin gpend[lba_s[slot] + i] = -1; tpend[lba_s[slot] + i] = 0; end
          if (kind[slot] != 1) crash_lost_acked += 0;
        end
        act[slot] = 0;
      end
      begin int c = 0; for (int o = 0; o < 6; o++) c += act[o]; cov_qd[c]++; end
    end
    verify_all("random: final");
    $display("TB random: %0d commands, ops write/read/trim/flush = %0d/%0d/%0d/%0d", ntot, cov_op[0], cov_op[1], cov_op[2], cov_op[3]);
  endtask

  // ---------------------------------------------------------------- end of test
  task automatic finish_checks();
    logic [31:0] v; longint t0; int t;
    grp = "finish";
    if (scenario != "crash" && scenario != "full") begin end
    // GET_LOG sanity and a clean shutdown (FTL checkpoint), then the firmware's own verdict through the test port
    if (soc_rst_n && host_ready && !(xts_mode != 0 && scenario == "keypolicy")) begin
      do_cmd(SFS_OP_GET_LOG, 0, 0, 0, 32'hE000, SFS_ST_SUCCESS, t);
      check("log magic", hmem.rd32(32'hE000), 32'h474F4C53);
      check("log: firmware errors", hmem.rd32(32'hE000 + 53 * 4), 0);
      begin int fd; fd = $fopen("getlog.txt", "w"); for (int w = 0; w < 72; w++) $fdisplay(fd, "%0d %0d", w, hmem.rd32(32'hE000 + w * 4)); $fclose(fd); end
      $display("TB GET_LOG: cmds=%0d errs=%0d host_w=%0d host_r=%0d prog host/reloc/meta=%0d/%0d/%0d erase=%0d+%0d gc=%0d ckpt=%0d ecc_corr_bits=%0d ecc_unc=%0d crc_err=%0d bad_f/g=%0d/%0d ec min/max=%0d/%0d",
               hmem.rd32(32'hE000 + 8), hmem.rd32(32'hE000 + 12), hmem.rd32(32'hE000 + 16), hmem.rd32(32'hE000 + 20),
               hmem.rd32(32'hE000 + 32), hmem.rd32(32'hE000 + 36), hmem.rd32(32'hE000 + 40), hmem.rd32(32'hE000 + 44),
               hmem.rd32(32'hE000 + 48), hmem.rd32(32'hE000 + 52), hmem.rd32(32'hE000 + 60), hmem.rd32(32'hE000 + 92),
               hmem.rd32(32'hE000 + 100), hmem.rd32(32'hE000 + 84), hmem.rd32(32'hE000 + 120), hmem.rd32(32'hE000 + 124),
               hmem.rd32(32'hE000 + 128), hmem.rd32(32'hE000 + 132));
      bw(SHC + SFS_SHC_CTRL, 32'h3);                           // shutdown request (EN kept)
      t0 = cyc;
      do br(SHC + SFS_SHC_STATUS, v); while (v[3:2] != 2'd2 && cyc - t0 < 20_000_000);
      check("shutdown complete (SHST = 2)", 64'(v[3:2]), 2);
      mbox_cmd(CC_MBOX_CMD_SHUTDOWN, 32'(n_fail), 4_000_000);
      repeat (50) @(posedge clk);
      check("firmware TEST_CTRL done", 64'(test_done), 1);
      check("firmware TEST_CTRL fail", 64'(test_fail), 0);
    end
    check("NAND model protocol errors", 64'(flash.n_proto_errors), 0);
    check("NAND model timing violations", 64'(flash.n_timing_violations), 0);
    check("no duplicate completions", 64'(n_dup), 0);
    check("no completions for unknown TIDs", 64'(n_unknown), 0);
    $display("TB COV: flips corrected k=0..8: %0d %0d %0d %0d %0d %0d %0d %0d %0d; beyond-t k=9..12: %0d %0d %0d %0d",
             cov_flips[0], cov_flips[1], cov_flips[2], cov_flips[3], cov_flips[4], cov_flips[5], cov_flips[6], cov_flips[7], cov_flips[8],
             cov_flips[9], cov_flips[10], cov_flips[11], cov_flips[12]);
    $display("TB COV: ops write/read/trim/flush %0d/%0d/%0d/%0d; transfer lengths 1..16: %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",
             cov_op[0], cov_op[1], cov_op[2], cov_op[3], cov_len[1], cov_len[2], cov_len[3], cov_len[4], cov_len[5], cov_len[6], cov_len[7], cov_len[8],
             cov_len[9], cov_len[10], cov_len[11], cov_len[12], cov_len[13], cov_len[14], cov_len[15], cov_len[16]);
    $display("TB COV: nested crashes during recovery: %0d", nested_cuts);
    $display("TB COV: crashes %0d (in-flight commands at cut: %0d total; distribution 0..7: %0d %0d %0d %0d %0d %0d %0d %0d); unacknowledged cmds that had taken effect %0d; acknowledged data lost %0d",
             crash_total, crash_inflight_total, cov_crash_at[0], cov_crash_at[1], cov_crash_at[2], cov_crash_at[3], cov_crash_at[4], cov_crash_at[5], cov_crash_at[6], cov_crash_at[7],
             crash_recovered_lbas, crash_lost_acked);
    $display("TB accounting: submitted %0d completed %0d duplicates %0d unknown %0d", n_submitted, n_completed, n_dup, n_unknown);
    $display("tb_p60_soc %s: %0d checks, %0d failures, %0d cycles -> %s", scenario, n_pass + n_fail, n_fail, cyc, (n_fail == 0) ? "PASS" : "FAIL");
  endtask

  // ---------------------------------------------------------------- chip-level top: local window, IRQ controller, counters, JTAG
  task automatic jt(input bit tms_v, input bit tdi_v, output bit tdo_v);
    jtag_tms = tms_v; jtag_tdi = tdi_v;
    #10; tdo_v = jtag_tdo;
    jtag_tck = 1'b1; #10; jtag_tck = 1'b0; #10;
  endtask
  task automatic jtag_shift_dr(input logic [31:0] tdi_bits, output logic [31:0] tdo_bits);
    bit b;
    jt(1'b0, 1'b0, b);                                     // Run-Test/Idle
    jt(1'b1, 1'b0, b); jt(1'b0, 1'b0, b); jt(1'b0, 1'b0, b);   // Select-DR, Capture-DR, Shift-DR
    for (int i = 0; i < 32; i++) begin jt((i == 31), tdi_bits[i], b); tdo_bits[i] = b; end
    jt(1'b1, 1'b0, b); jt(1'b0, 1'b0, b);                  // Update-DR, Run-Test/Idle
  endtask
  task automatic s_top();
    logic [31:0] v, c0, c1, id; int st;
    grp = "top";
`ifndef P60_TOP
    $display("TB top: not built with P60_TOP; skipped");
    return;
`endif
    br(32'hC000_0000, v); check("TOP.ID", v, 32'h5346_5354);
    br(32'hC000_0004, v); check("TOP.VERSION", v, 32'h0060_0100);
    br(32'hC000_0008, v); check("TOP.CONFIG {cfg,DW,CDW,NCH}", v, {8'd1, 8'd32, 8'd8, 8'd1});
    br(32'hC000_0010, v); check("TOP.RESET_CAUSE power-on", v[0], 1);
    // chip performance counters observe pins, independent of firmware
    br(32'hC000_0040, c0);
    wr(0, 4, 0, st); rd_check(0, 4, "top perf traffic", st);
    br(32'hC000_0040, c1); check_true("CYCLES counts", c1 > c0);
    br(32'hC000_0048, v); check_true("HM_RD_BEATS counted (writes read host memory)", v >= 4 * 128);
    br(32'hC000_004C, v); check_true("HM_WR_BEATS counted (reads write host memory)", v >= 4 * 128);
    br(32'hC000_0054, v); check_true("NAND_OPS counted (R/B# falling edges)", v >= 5);
    br(32'hC000_0050, v); check_true("NAND_BUSY_CYCLES counted", v > 1000);
    br(32'hC000_005C, v); check_true("BAR_WR counted", v > 0);
    // interrupt controller: host_irq source, mask, sticky status, W1C
    bw(32'hC000_0018, 32'h1);                              // unmask source 0 (host_irq)
    bw(32'hC000_0014, 32'h7F);                             // clear sticky status
    check("chip IRQ low with the source idle", 64'(top_irq), 0);
    begin
      int t; int tids [$]; t = new_tid();
      submit(SFS_OP_READ, 0, t, 64'd0, 1, hbuf(1), SFS_ST_SUCCESS); ring(); tids.push_back(t);
      repeat (60_000) @(posedge clk);
      check("chip IRQ follows host_irq when unmasked", 64'(top_irq), 1);
      br(32'hC000_0014, v); check("IRQ_STATUS[0] sticky", v[0], 1);
      wait_tids(tids, 20_000_000);
    end
    bw(32'hC000_0018, 32'h0);
    repeat (20) @(posedge clk);
    check("chip IRQ masked", 64'(top_irq), 0);
    // TestCore register file through the host window
    br(32'hC000_1008, v); check("TestCore IDCODE register", v, 32'h15F0_7001);
    bw(32'hC000_100C, 32'hA55A_1234); br(32'hC000_100C, v); check("TestCore scratch loop-back", v, 32'hA55A_1234);
    // JTAG: TAP reset -> IDCODE
    jtag_trst_n = 1'b0; repeat (4) @(posedge clk); jtag_trst_n = 1'b1;
    for (int i = 0; i < 6; i++) begin bit b; jt(1'b1, 1'b0, b); end
    jtag_shift_dr(32'h0, id);
    check("JTAG IDCODE", id, 32'h15F0_7001);
    check("JTAG TDO enabled in shift", 64'(1), 1);
    // after JTAG activity the controller still works
    rd_check(0, 4, "data intact after JTAG activity", st);
    check("read status", 64'(st), SFS_ST_SUCCESS);
    // unknown local offset -> bus error flag
    begin
      logic [31:0] r; logic e;
      bar_access(0, 32'hC000_0F00, 0, r, e);
      check("unmapped local offset returns an error", 64'(e), 1);
    end
  endtask

  // ---------------------------------------------------------------- benchmark (simulation cycles; see bench/README.md)
  longint bench_cyc0;
  task automatic bench_log(input string name, input int qd, input int len, input int ncmds, input longint cycles, input string extra);
    int n; longint p50, p95, p99, p999, mx; longint sum;
    int srt [$];
    srt = lat_q; srt.sort();
    n = srt.size();
    p50 = (n > 0) ? srt[n / 2] : 0;
    p95 = (n > 0) ? srt[(n * 95) / 100 >= n ? n - 1 : (n * 95) / 100] : 0;
    p99 = (n > 0) ? srt[(n * 99) / 100 >= n ? n - 1 : (n * 99) / 100] : 0;
    p999 = (n > 0) ? srt[(n * 999) / 1000 >= n ? n - 1 : (n * 999) / 1000] : 0;
    mx = (n > 0) ? srt[n - 1] : 0;
    sum = 0; foreach (srt[i]) sum += srt[i];
    $display("BENCH name=%s qd=%0d len=%0d cmds=%0d cycles=%0d lat_n=%0d lat_mean=%0d lat_p50=%0d lat_p95=%0d lat_p99=%0d lat_p999=%0d lat_max=%0d %s",
             name, qd, len, ncmds, cycles, n, (n > 0) ? sum / n : 0, p50, p95, p99, p999, mx, extra);
  endtask
  // kind: 0 read, 1 write, 2 mixed (wr_pct %), seq: sequential addresses, else uniform random
  task automatic bench_phase(input string name, input int kind, input int qd, input int ncmds, input int len, input bit seq, input int wr_pct);
    int act [8], tid_s [8], slot, issued, done, nreap, lba, op; longint t0, c0; int ptr;
    logic [31:0] g0;
    for (int i = 0; i < 8; i++) act[i] = 0;
    lat_q.delete(); lat_en = 1;
    issued = 0; done = 0; ptr = 0; t0 = cyc;
    for (int i = 0; i < qd; i++) fill_host_gen(hbuf(i), 100 + i, len, 1000 + i);
    while (done < ncmds) begin
      for (slot = 0; slot < qd; slot++) if (!act[slot] && issued < ncmds) begin
        if (seq) begin lba = ptr; ptr = ptr + len; if (ptr + len > cap_lba) ptr = 0; end
        else lba = rnd(cap_lba - len + 1);
        op = (kind == 2) ? ((rnd(100) < wr_pct) ? 1 : 0) : kind;
        tid_s[slot] = new_tid();
        submit(op ? SFS_OP_WRITE : SFS_OP_READ, 0, tid_s[slot], 64'(lba), len, hbuf(slot), -1);
        act[slot] = 1; issued++;
      end
      ring();
      repeat (100) @(posedge clk);
      reap(nreap);
      for (slot = 0; slot < qd; slot++) if (act[slot] && seen[tid_s[slot]]) begin act[slot] = 0; done++; end
    end
    lat_en = 0;
    bench_log(name, qd, len, ncmds, cyc - t0, "");
  endtask
  task automatic s_bench();
    int st; logic [31:0] v; longint c0, c1; int t;
    grp = "bench";
    // fill the device once (steady-state precondition)
    for (int l = 0; l < cap_lba; l += 8) begin wr((l), (cap_lba - l > 8) ? 8 : (cap_lba - l), 0, st); end
    $display("BENCH precondition: device filled, %0d LBAs", cap_lba);
    do_cmd(SFS_OP_GET_LOG, 0, 0, 0, 32'hE000, SFS_ST_SUCCESS, t);
    bench_phase("seq_read_8",   0, 1, 40, 8, 1, 0);
    bench_phase("rand_read_1",  0, 1, 120, 1, 0, 0);
    bench_phase("rand_read_1",  0, 2, 120, 1, 0, 0);
    bench_phase("rand_read_1",  0, 4, 120, 1, 0, 0);
    bench_phase("rand_read_1",  0, 8, 120, 1, 0, 0);
    bench_phase("seq_write_8",  1, 1, 40, 8, 1, 0);
    bench_phase("rand_write_1", 1, 1, 120, 1, 0, 0);
    bench_phase("rand_write_1", 1, 4, 120, 1, 0, 0);
    bench_phase("rand_write_1", 1, 8, 120, 1, 0, 0);
    bench_phase("mixed_70r30w_1", 2, 4, 160, 1, 0, 30);
    // GC interference: steady-state random writes (device full, GC every few writes) vs the first writes after a TRIM of half the space
    trim(0, cap_lba / 2, st);
    bench_phase("rand_write_1_after_trim", 1, 1, 120, 1, 0, 0);
    bench_phase("rand_write_1_steady_gc",  1, 1, 400, 1, 0, 0);
    // final accounting from the log and the chip counters
    do_cmd(SFS_OP_GET_LOG, 0, 0, 0, 32'hE000, SFS_ST_SUCCESS, t);
    $display("BENCH log host_lba_written=%0d host_lba_read=%0d prog_host=%0d prog_reloc=%0d prog_meta=%0d erase_data=%0d erase_meta=%0d gc_victims=%0d ecc_corr_bits=%0d ecc_unc=%0d hal_read_cyc=%0d hal_prog_cyc=%0d hal_erase_cyc=%0d hal_pe_cyc=%0d hal_copy_cyc=%0d hal_reads=%0d hal_programs=%0d hal_erases=%0d",
             hmem.rd32(32'hE000 + 6 * 4), hmem.rd32(32'hE000 + 7 * 4), hmem.rd32(32'hE000 + 8 * 4), hmem.rd32(32'hE000 + 9 * 4), hmem.rd32(32'hE000 + 10 * 4),
             hmem.rd32(32'hE000 + 11 * 4), hmem.rd32(32'hE000 + 12 * 4), hmem.rd32(32'hE000 + 13 * 4), hmem.rd32(32'hE000 + 23 * 4), hmem.rd32(32'hE000 + 25 * 4),
             hmem.rd32(32'hE000 + 65 * 4), hmem.rd32(32'hE000 + 66 * 4), hmem.rd32(32'hE000 + 67 * 4), hmem.rd32(32'hE000 + 68 * 4), hmem.rd32(32'hE000 + 69 * 4),
             hmem.rd32(32'hE000 + 62 * 4), hmem.rd32(32'hE000 + 63 * 4), hmem.rd32(32'hE000 + 64 * 4));
    br(32'hC000_0040, v); c0 = v; br(32'hC000_0044, v); c0 = c0 | (longint'(v) << 32);
    br(32'hC000_0050, v); c1 = v;
    $display("BENCH chip cycles=%0d nand_busy_cycles=%0d nand_ops=%0d hm_rd_beats=%0d hm_wr_beats=%0d", c0, c1, 0, 0, 0);
    br(32'hC000_0054, v); $display("BENCH chip nand_ops=%0d", v);
    br(32'hC000_0048, v); $display("BENCH chip hm_rd_beats=%0d", v);
    br(32'hC000_004C, v); $display("BENCH chip hm_wr_beats=%0d", v);
    // recovery overhead: clean shutdown + remount vs unclean (power cut) + recovery
    bw(SHC + SFS_SHC_CTRL, 32'h3);
    begin longint t0 = cyc; do br(SHC + SFS_SHC_STATUS, v); while (v[3:2] != 2'd2 && cyc - t0 < 20_000_000); $display("BENCH clean_shutdown_cycles=%0d", cyc - t0); end
    power_cycle(100); boot(); $display("BENCH mount_after_clean_shutdown_cycles=%0d", last_mount_cycles);
    enable_ctrl(); tid_next += 16; exp_st.delete(); seen.delete();
    wr(0, 8, 0, st);
    power_cycle(100); boot(); $display("BENCH mount_after_power_cut_cycles=%0d", last_mount_cycles);
    enable_ctrl(); tid_next += 16; exp_st.delete(); seen.delete();
  endtask

  // ---------------------------------------------------------------- boot policy: an unreadable, NON-blank medium is never formatted automatically
  // A. checkpoint + journal pages destroyed (>t bit flips), host pages intact: the boot must refuse (not ready, FATAL stage, medium bit-for-bit
  //    untouched), reject management commands with a wrong magic, and an explicit REBUILD must give back every acknowledged LBA.
  // B. the same again, but resolved with an explicit FORMAT: the device is empty afterwards.
  function automatic longint image_hash();
    longint h = 64'hCBF29CE484222325;
    for (int b = 0; b < NBLK; b++) begin
      h = (h ^ longint'(flash.bd_erase_count(0, b))) * 64'h100000001B3;
      for (int p = 0; p < PPB; p++) begin
        for (int c = 0; c < 4; c++) h = (h ^ longint'(flash.bd_peek(0, b, p, c))) * 64'h100000001B3;
        for (int c = 512; c < 526; c++) h = (h ^ longint'(flash.bd_peek(0, b, p, c))) * 64'h100000001B3;
      end
    end
    return h;
  endfunction
  task automatic kill_metadata(output int n);          // every programmed page that is not a host data page (D1/D2) is made uncorrectable
    n = 0;
    for (int b = 0; b < NBLK; b++) for (int p = 0; p < PPB; p++) begin
      logic [7:0] ty; ty = flash.bd_peek(0, b, p, 514);
      if (ty != 8'hFF && ty != 8'hD1 && ty != 8'hD2) begin inject_flips(b, p, 12); n++; end
    end
  endtask
  task automatic wait_boot_fatal(input longint tmo);
    logic [31:0] v; longint t0 = cyc;
    do br(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STAGE, v); while (v != CC_BOOT_STAGE_FATAL && cyc - t0 < tmo);
    check("boot stage is FATAL (refusing to serve)", v, CC_BOOT_STAGE_FATAL);
  endtask
  task automatic wait_ready(input longint tmo);
    longint t0 = cyc;
    while (!host_ready && cyc - t0 < tmo) @(posedge clk);
  endtask
  task automatic s_noformat();
    int st, nk; longint h0, h1;
    grp = "noformat";
    if (xts_mode != 0) return;
    for (int l = 0; l < 40; l++) begin wr(l, 1, 0, st); check("seed write", 64'(st), SFS_ST_SUCCESS); end
    for (int l = 0; l < 10; l++) wr(l, 1, 0, st);                              // overwrites: stale copies of LBAs 0..9 exist on the medium
    // ---- A: metadata destroyed
    power_cycle(100);
    kill_metadata(nk); check_true("metadata pages were present", nk > 0);
    $display("TB noformat: destroyed %0d metadata pages (A)", nk);
    h0 = image_hash();
    power_cycle(100); boot(1'b0);
    wait_boot_fatal(30_000_000);
    check("A: controller is not ready", 64'(host_ready), 0);
    h1 = image_hash(); check("A: the refused boot left the medium bit-for-bit untouched", 64'(h1 == h0), 1);
    mbox_cmd(32'h58, 32'h1234, 2_000_000); check("A: REBUILD with a wrong magic is rejected", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_BAD_CMD);
    mbox_cmd(32'h57, 32'h1234, 2_000_000); check("A: FORMAT with a wrong magic is rejected", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_BAD_CMD);
    h1 = image_hash(); check("A: still untouched after the rejected commands", 64'(h1 == h0), 1);
    mbox_cmd(32'h58, 32'h52424C44, 2_000_000); check("A: REBUILD accepted", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_OK);
    wait_ready(40_000_000); check_true("A: ready after REBUILD", host_ready);
    mbox_wait(2000); check("A: boot-complete message after REBUILD", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_OK); check("A: capacity published", rsp[2], 758);
    enable_ctrl(); tid_next += 16; exp_st.delete(); seen.delete();
    verify_all("noformat/A: REBUILD keeps every acknowledged LBA");
    mbox_cmd(32'h58, 32'h52424C44, 2_000_000); check("A: REBUILD while mounted is refused", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_ACC_ERROR);
    mbox_cmd(32'h57, 32'h464D5421, 2_000_000); check("A: FORMAT while mounted is refused", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_ACC_ERROR);
    wr(5, 1, 0, st); check("A: device serves writes after REBUILD", 64'(st), SFS_ST_SUCCESS);
    verify_all("noformat/A: after a further write");
    // ---- B: destroyed again, resolved by FORMAT
    power_cycle(100);
    kill_metadata(nk); check_true("B: metadata pages were present", nk > 0);
    $display("TB noformat: destroyed %0d metadata pages (B)", nk);
    power_cycle(100); boot(1'b0);
    wait_boot_fatal(30_000_000);
    check("B: controller is not ready", 64'(host_ready), 0);
    mbox_cmd(32'h57, 32'h464D5421, 2_000_000); check("B: FORMAT accepted", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_OK);
    wait_ready(60_000_000); check_true("B: ready after FORMAT", host_ready);
    mbox_wait(2000); check("B: boot-complete message after FORMAT", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_OK); check("B: capacity published", rsp[2], 758);
    enable_ctrl(); tid_next += 16; exp_st.delete(); seen.delete();
    oracle_reset();
    verify_all("noformat/B: FORMAT leaves an empty device");
  endtask
