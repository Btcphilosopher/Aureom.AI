// Verilator main for the coverage build: identical to the generated --binary main, plus a coverage.dat write at exit
// (the generated main of Verilator 5.020 does not write coverage data).
#include "verilated.h"
#include "verilated_cov.h"
#include "Vtb_p60_soc.h"
int main(int argc, char** argv, char**) {
  Verilated::debug(0);
  const std::unique_ptr<VerilatedContext> contextp{new VerilatedContext};
  contextp->commandArgs(argc, argv);
  const std::unique_ptr<Vtb_p60_soc> topp{new Vtb_p60_soc{contextp.get()}};
  while (!contextp->gotFinish()) {
    topp->eval();
    if (!topp->eventsPending()) break;
    contextp->time(topp->nextTimeSlot());
  }
  topp->final();
  contextp->coveragep()->write("coverage.dat");
  return 0;
}
