// =============================================================================
// SilicaFlux-STORE P60 :: tb_p60_soc -- full-chip testbench, real firmware on the RTL CPU
//
// DUT   : silicaflux_storage_soc (P51 base: ControlCore RV32IM + storage subsystem, P60 patched with the page
//         engine = BCH t=8 ECC + XTS-AES), running the P60 firmware (FTL = P58 1.1 / P56).
// Media : the P52 NAND digital twin (pin level, x8 SDR, ONFI-style, power-loss tearing), 512+32 B pages.
// Host  : simulated NVMe-like host on the SFB2 BAR (SQ/CQ in controller memory), host memory model.
// Oracle: independent LBA -> generation table; every read returns data derived from (lba, word, generation).
//
// Scenarios (+scenario=<name>): smoke integrity ecc crash invalid concurrency backpressure ctrlreset plp
//                                security badblock random full
// Plusargs: +fw=<hex> +seed=<n> +ncrash=<n> +nops=<n> +xts=<0|1> +timeout=<cycles> +NANDLAB_DIR=<dir>
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_p60_soc;
  import silicaflux_storage_pkg::*;
  import sfs_map_pkg::*;
  import cc_memmap_pkg::*;

  localparam int NCH  = 1;
  localparam int CDW  = 8;
  localparam int BUFB = 16384;
  localparam int DW   = 32;
  localparam int AWID = 32;
  localparam int NT   = 8;
  localparam int PAGE = 544;                         // NAND_PAGE_BYTES = raw page slot stride
  localparam int LBAB = 512;                         // logical block
  localparam int SB   = DW / 8;
  localparam int HQD  = (2 * NT > 64) ? 64 : 2 * NT;
  localparam int PPB  = 16;
  localparam int NBLK = 64;
  localparam logic [31:0] SHC = SFS_BAR_SHC_BASE;
  localparam int MAXLBA = 1024;
  localparam int FLAG_FUA = 2;
  string scenario;
  int    xts_mode = 0;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;                       // 100 MHz core clock
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  // ---------------------------------------------------------------- DUT
  logic        hb_req_valid = 0, hb_req_write = 0, hb_req_ready, hb_rsp_valid, hb_rsp_error;
  logic [31:0] hb_req_addr = 0, hb_req_wdata = 0, hb_rsp_rdata;
  logic [3:0]  hb_req_wstrb = 4'hF;
  logic        hm_req_valid, hm_req_ready, hm_req_write, hm_rsp_valid, hm_rsp_ready, hm_rsp_error;
  logic [31:0] hm_req_addr;
  logic [DW-1:0] hm_req_wdata, hm_rsp_rdata;
  logic [SB-1:0] hm_req_wstrb;
  logic        host_irq, mgmt_irq, host_ready, cmdproc_ready, ras_fatal;
  logic [NCH-1:0] ce_n, cle, ale, we_n, re_n, wp_n, dq_oe, rb_n;
  logic [NCH*CDW-1:0] dq_o, dq_i;
  logic        pwr_fail_n = 1'b1, host_rst_req = 1'b0;
  logic        diag_valid, test_done, test_fail, cpu_sleep;
  logic [7:0]  diag_char;
  logic [15:0] test_code;
  int          bp_pct = 0, lat_max = 2;
  logic        soc_rst_n = 1'b0;               // SoC reset (power cycle); the NAND has its own supply
  logic        nand_vcc = 1'b0;

  // JTAG / DFT pins of the top
  logic jtag_tck = 1'b0, jtag_trst_n = 1'b0, jtag_tms = 1'b1, jtag_tdi = 1'b0, jtag_tdo, jtag_tdo_oe, top_irq;
`ifdef P60_TOP
  silicaflux_storage_top #(
    .NUM_NAND_CHANNELS(NCH), .CHANNEL_DATA_WIDTH(CDW), .BUFFER_SIZE_BYTES(BUFB), .DMA_DATA_WIDTH(DW),
    .ADDRESS_WIDTH(AWID), .CMD_QUEUE_DEPTH(NT), .NAND_PAGE_BYTES(PAGE)
  ) dut (
    .clk, .por_n(soc_rst_n), .pwr_fail_n(pwr_fail_n), .boot_mode(2'(CC_BOOT_MODE_HOST)), .host_rst_req(host_rst_req),
    .hb_req_valid, .hb_req_ready, .hb_req_write, .hb_req_addr, .hb_req_wdata, .hb_req_wstrb,
    .hb_rsp_valid, .hb_rsp_ready(1'b1), .hb_rsp_rdata, .hb_rsp_error,
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error,
    .nand_ce_n(ce_n), .nand_cle(cle), .nand_ale(ale), .nand_we_n(we_n), .nand_re_n(re_n), .nand_wp_n(wp_n),
    .nand_dq_o(dq_o), .nand_dq_oe(dq_oe), .nand_dq_i(dq_i), .nand_rb_n(rb_n),
    .tck(jtag_tck), .trst_n(jtag_trst_n), .tms(jtag_tms), .tdi(jtag_tdi), .tdo(jtag_tdo), .tdo_oe(jtag_tdo_oe),
    .hw_dbg_en(1'b1), .hw_test_en(1'b1), .scan_mode_pin(1'b0), .scan_en_pin(1'b0),
    .irq_o(top_irq), .host_irq_o(host_irq), .mgmt_irq_o(mgmt_irq), .host_ready_o(host_ready), .cmdproc_ready_o(cmdproc_ready),
    .ras_fatal_o(ras_fatal), .diag_valid_o(diag_valid), .diag_char_o(diag_char), .test_done_o(test_done), .test_fail_o(test_fail),
    .test_code_o(test_code), .cpu_sleep_o(cpu_sleep)
  );
`else
  silicaflux_storage_soc #(
    .NUM_NAND_CHANNELS(NCH), .CHANNEL_DATA_WIDTH(CDW), .BUFFER_SIZE_BYTES(BUFB), .DMA_DATA_WIDTH(DW),
    .ADDRESS_WIDTH(AWID), .CMD_QUEUE_DEPTH(NT), .ENABLE_ECC(0), .ENABLE_RAS(1), .NAND_PAGE_BYTES(PAGE)
  ) dut (
    .clk, .rst_ni(soc_rst_n), .test_mode(1'b0), .boot_mode_i(2'(CC_BOOT_MODE_HOST)), .host_rst_req_i(host_rst_req),
    .pwr_fail_ni(pwr_fail_n),
    .hb_req_valid, .hb_req_ready, .hb_req_write, .hb_req_addr, .hb_req_wdata, .hb_req_wstrb,
    .hb_rsp_valid, .hb_rsp_ready(1'b1), .hb_rsp_rdata, .hb_rsp_error,
    .hm_req_valid, .hm_req_ready, .hm_req_write, .hm_req_addr, .hm_req_wdata, .hm_req_wstrb,
    .hm_rsp_valid, .hm_rsp_ready, .hm_rsp_rdata, .hm_rsp_error,
    .host_irq_o(host_irq), .mgmt_irq_o(mgmt_irq), .host_ready_o(host_ready), .cmdproc_ready_o(cmdproc_ready),
    .ras_fatal_o(ras_fatal),
    .nand_ce_n(ce_n), .nand_cle(cle), .nand_ale(ale), .nand_we_n(we_n), .nand_re_n(re_n), .nand_wp_n(wp_n),
    .nand_dq_o(dq_o), .nand_dq_oe(dq_oe), .nand_dq_i(dq_i), .nand_rb_n(rb_n),
    .diag_valid_o(diag_valid), .diag_char_o(diag_char), .test_done_o(test_done), .test_fail_o(test_fail),
    .test_code_o(test_code), .cpu_sleep_o(cpu_sleep)
  );

`endif

  sfs_tb_hostmem #(.DW(DW), .SIZE(1 << 20)) hmem (
    .clk, .rst_n(soc_rst_n), .req_valid(hm_req_valid), .req_ready(hm_req_ready), .req_write(hm_req_write),
    .req_addr(hm_req_addr), .req_wdata(hm_req_wdata), .req_wstrb(hm_req_wstrb), .rsp_valid(hm_rsp_valid),
    .rsp_ready(hm_rsp_ready), .rsp_rdata(hm_rsp_rdata), .rsp_error(hm_rsp_error), .bp_pct, .lat_max
  );

  // ---------------------------------------------------------------- media: P52 NAND digital twin (one target, x8)
  wire [7:0] nd_out;
  wire       nd_oe, nd_rb;
  nand_flash_model #(.PAGE_DATA_BYTES(512), .PAGE_SPARE_BYTES(32), .PAGES_PER_BLOCK(PPB), .BLOCKS_PER_PLANE(32),
                     .PLANES_PER_LUN(2), .LUNS(1), .TARGET_ID(0)) flash (
    .ce_n(ce_n[0]), .cle(cle[0]), .ale(ale[0]), .we_n(we_n[0]), .re_n(re_n[0]), .wp_n(wp_n[0]),
    .dq_in(dq_o[7:0]), .dq_out(nd_out), .dq_oe(nd_oe), .rb_n(nd_rb), .vcc_ok(nand_vcc)
  );
  assign dq_i = nd_oe ? nd_out : dq_o;
  assign rb_n = nd_rb;

  // ---------------------------------------------------------------- hardware command-latency monitor (sfs_cmd_ctrl, cycles accept -> completion post)
  int lat_q [$];
  bit lat_en = 0;
`ifdef P60_TOP
  always @(posedge clk) if (lat_en && dut.u_soc.u_stor.pe_lat_valid) lat_q.push_back(int'(dut.u_soc.u_stor.pe_lat));
`endif

  // ---------------------------------------------------------------- firmware console
  string con_line = "";
  bit con_echo;
  int n_con_mount = 0, n_con_format = 0, n_con_unc = 0;
  initial con_echo = $test$plusargs("con");
  always @(posedge clk) if (diag_valid) begin
    if (diag_char == 8'h0A) begin
      if (con_echo) $display("FW| %s", con_line);
      if (con_line.len() > 6 && con_line.substr(0, 5) == "[ftl] ") begin
        if (con_line.len() > 14 && con_line.substr(6, 12) == "mounted") n_con_mount++;
        if (con_line.len() > 20 && con_line.substr(6, 20) == "rebuild recovered no") n_con_format++;
        if (con_line.len() > 12 && con_line.substr(6, 11) == "boot f") n_con_unc++;
      end
      con_line = "";
    end else con_line = {con_line, string'(diag_char)};
  end

  // ---------------------------------------------------------------- scoreboard
  int n_pass = 0, n_fail = 0;
  string grp = "";
  task automatic check(input string what, input logic [63:0] got, input logic [63:0] exp);
    if (got === exp) n_pass++;
    else begin n_fail++; $display("[%0d] FAIL %s/%s: got 0x%0h expected 0x%0h", cyc, grp, what, got, exp); end
  endtask
  task automatic check_true(input string what, input bit c);
    check(what, 64'(c), 64'd1);
  endtask

  // ---------------------------------------------------------------- host BAR BFM (one process performs every BAR transaction)
  bit          bfm_wr, bfm_err, bfm_busy = 0;
  logic [31:0] bfm_a, bfm_wd, bfm_rd;
  event        bfm_go, bfm_fin;
  always begin
    @(bfm_go);
    @(negedge clk);
    hb_req_valid = 1; hb_req_write = bfm_wr; hb_req_addr = bfm_a; hb_req_wdata = bfm_wd; hb_req_wstrb = 4'hF;
    #4; while (!hb_req_ready) begin @(negedge clk); #4; end
    @(posedge clk); #1;
    hb_req_valid = 0;
    @(negedge clk); #4; while (!hb_rsp_valid) begin @(negedge clk); #4; end
    bfm_rd = hb_rsp_rdata; bfm_err = hb_rsp_error;
    @(posedge clk); #1;
    -> bfm_fin;
  end
  task automatic bar_access(input bit wr, input logic [31:0] a, input logic [31:0] wd,
                            output logic [31:0] rd, output logic err);
    while (bfm_busy) @(posedge clk);
    bfm_busy = 1; bfm_wr = wr; bfm_a = a; bfm_wd = wd;
    #1 -> bfm_go;
    @(bfm_fin);
    rd = bfm_rd; err = bfm_err; bfm_busy = 0;
  endtask
  task automatic bw(input logic [31:0] a, input logic [31:0] d);
    logic [31:0] r; logic e;
    bar_access(1, a, d, r, e);
    if (e) begin n_fail++; $display("[%0d] FAIL %s: BAR write error @%08h", cyc, grp, a); end
  endtask
  task automatic br(input logic [31:0] a, output logic [31:0] d);
    logic e;
    bar_access(0, a, 0, d, e);
    if (e) begin n_fail++; $display("[%0d] FAIL %s: BAR read error @%08h", cyc, grp, a); end
  endtask

  // ---------------------------------------------------------------- boot (ControlCore host-load flow) + key provisioning
  logic [31:0] img [$];
  logic [31:0] rsp [8];
  logic [31:0] test_key [16];
  longint boot_count = 0, t_boot_start = 0;
  int nested_cuts = 0;
  longint t_img_ready = 0, last_mount_cycles = 0;
  task automatic mbox_wait(input longint tmo);
    longint t0 = cyc;
    while (!mgmt_irq && cyc - t0 < tmo) @(posedge clk);
    if (!mgmt_irq) begin n_fail++; $display("[%0d] FAIL %s: mailbox timeout", cyc, grp); end
    for (int i = 0; i < 8; i++) begin logic [31:0] v; br(CC_MAILBOX_BASE + CC_MBOX_F2H_MSG0 + 32'(4 * i), v); rsp[i] = v; end
    bw(CC_MAILBOX_BASE + CC_MBOX_F2H_ACK, 0);
  endtask
  task automatic mbox_cmd7(input logic [31:0] cmd, input logic [31:0] w1, input logic [31:0] w2, input logic [31:0] w3,
                           input logic [31:0] w4, input logic [31:0] w5, input logic [31:0] w6, input logic [31:0] w7,
                           input longint tmo);
    bw(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 4, w1);  bw(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 8, w2);
    bw(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 12, w3); bw(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 16, w4);
    bw(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 20, w5); bw(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 24, w6);
    bw(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0 + 28, w7);
    bw(CC_MAILBOX_BASE + CC_MBOX_H2F_MSG0, cmd);
    bw(CC_MAILBOX_BASE + CC_MBOX_H2F_RING, cmd);
    mbox_wait(tmo);
  endtask
  task automatic mbox_cmd(input logic [31:0] cmd, input logic [31:0] a1, input longint tmo);
    mbox_cmd7(cmd, a1, 0, 0, 0, 0, 0, 0, tmo);
  endtask
  task automatic load_image();
    string fw; int fd; logic [31:0] w;
    if (img.size() == 0) begin
      if (!$value$plusargs("fw=%s", fw)) fw = (xts_mode != 0) ? "fw/build/p60_fw_xts.hex" : "fw/build/p60_fw.hex";
      fd = $fopen(fw, "r");
      if (fd == 0) $fatal(1, "cannot open firmware image %s", fw);
      while ($fscanf(fd, "%h\n", w) == 1) img.push_back(w);
      $fclose(fd);
      $display("TB host: firmware image %s, %0d words", fw, img.size());
    end
  endtask
  // key provisioning (XTS firmware waits for it): 3 KEY_LOAD messages + KEY_COMMIT
  task automatic provision_key(input bit wrong);
    logic [31:0] k [16];
    for (int i = 0; i < 16; i++) k[i] = test_key[i] ^ (wrong ? 32'h0000_0100 : 32'h0);
    mbox_cmd7(32'h54, 0, k[0], k[1], k[2], k[3], k[4], k[5], 2_000_000);   check("KEY_LOAD0 ok", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_OK);
    mbox_cmd7(32'h54, 6, k[6], k[7], k[8], k[9], k[10], k[11], 2_000_000); check("KEY_LOAD1 ok", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_OK);
    mbox_cmd7(32'h54, 10, k[10], k[11], k[12], k[13], k[14], k[15], 2_000_000); check("KEY_LOAD2 ok", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_OK);
    mbox_cmd(32'h55, 0, 2_000_000);                                         check("KEY_COMMIT ok", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_OK);
    check("engine reports key_ready", rsp[1], 1);
  endtask
  // returns 1 when the firmware reached HOST READY, 0 when it refused (e.g. wrong key -> mount failure)
  bit last_boot_ok;
  task automatic boot(input bit expect_ok = 1'b1, input bit wrong_key = 1'b0, input int cut_after = 0);
    logic [31:0] v; longint t0;
    grp = "boot";
    load_image();
    t_boot_start = cyc;
    t0 = cyc;
    do br(CC_SYSCTRL_BASE + CC_SYSCTRL_BOOT_STAGE, v); while (v != CC_BOOT_STAGE_WAIT_IMAGE && cyc - t0 < 2_000_000);
    check("ROM waits for the image", v, CC_BOOT_STAGE_WAIT_IMAGE);
    for (int i = 0; i < img.size(); i++) bw(CC_IMEM_BASE + 32'(4 * i), img[i]);
    mbox_cmd(CC_MBOX_CMD_IMAGE_READY, 0, 3_000_000);
    check("boot ROM accepted the image", 64'(rsp[0] & 32'hFF), CC_MBOX_STS_OK);
    t_img_ready = cyc;
    if (xts_mode != 0) provision_key(wrong_key);
    if (cut_after > 0) begin                       // nested crash: lose power again while the firmware is mounting/recovering
      repeat (cut_after) @(posedge clk);
      power_cycle(30 + rnd(200));
      nested_cuts++;
      return;
    end
    t0 = cyc;
    while (!host_ready && cyc - t0 < 40_000_000 && !(expect_ok == 1'b0 && cyc - t0 > 6_000_000)) @(posedge clk);
    last_boot_ok = host_ready;
    if (expect_ok) begin
      check_true("host_ready pin", host_ready);
      mbox_wait(1000);
      boot_count++;
      last_mount_cycles = cyc - t_img_ready;
      $display("TB boot: firmware start to host-ready %0d cycles (boot %0d)", last_mount_cycles, boot_count);
      $display("TB host: HOST READY at cycle %0d (boot %0d, %0d cycles): capacity=%0d xts=%0d", cyc, boot_count, cyc - t_boot_start, rsp[2], rsp[6]);
    end
  endtask
  // full power cycle: SoC reset + NAND supply drop (the model tears an in-flight program/erase); then power up again
  task automatic power_cycle(input int hold_cycles);
    nand_vcc = 1'b0;
    soc_rst_n = 1'b0;
    pwr_fail_n = 1'b1;
    repeat (hold_cycles) @(posedge clk);
    nand_vcc = 1'b1;
    repeat (20) @(posedge clk);
    soc_rst_n = 1'b1;
    repeat (20) @(posedge clk);
  endtask

  // ---------------------------------------------------------------- host driver: queues
  int sq_tail_s = 0, cq_head_s = 0; bit phase_s = 1;
  int cap_lba = 0;
  int  exp_st [int];
  bit  seen [int];
  logic [127:0] cqe_of [int];
  int  cpl_order [$];
  longint n_submitted = 0, n_completed = 0, n_dup = 0, n_unknown = 0;

  task automatic enable_ctrl();
    logic [31:0] v; longint t0;
    bw(SHC + SFS_SHC_INT_CTRL, 32'h3);
    bw(SHC + SFS_SHC_CTRL, 32'h1);
    t0 = cyc;
    do br(SHC + SFS_SHC_STATUS, v); while (!v[0] && cyc - t0 < 40_000_000);
    check("controller RDY", 64'(v[0]), 1);
    br(SHC + SFS_SHC_CAPACITY_LO, v); cap_lba = int'(v);
    sq_tail_s = 0; cq_head_s = 0; phase_s = 1;
    bw(SHC + SFS_SHC_INT_STATUS, 32'h2);
  endtask
  task automatic srv_submit(input int op, input int flags, input int tid, input logic [63:0] addr, input int len,
                            input logic [31:0] hbuf, input int expect_status);
    logic [31:0] w [8];
    w[0] = 32'(op) | (32'(flags) << 8) | (32'(tid) << 16); w[1] = 0; w[2] = addr[31:0]; w[3] = addr[63:32];
    w[4] = 32'(len); w[5] = hbuf; w[6] = 0; w[7] = 0;
    if (dbg_q) $display("[%0d] TB q: submit tid=%0h op=%0d lba=%0d len=%0d sq_slot=%0d", cyc, tid, op, addr[31:0], len, sq_tail_s);
    for (int k = 0; k < 8; k++) bw(SHC + SFS_SHC_SQ_RING + 32'(sq_tail_s * 32 + k * 4), w[k]);
    sq_tail_s = (sq_tail_s + 1) % HQD;
    exp_st[tid] = expect_status;
    seen[tid] = 0;
    n_submitted++;
  endtask
  task automatic srv_ring();
    bw(SHC + SFS_SHC_SQ_TAIL, 32'(sq_tail_s));
  endtask
  task automatic srv_reap(output int n);
    logic [31:0] w3, w;
    logic [127:0] c;
    n = 0;
    br(SHC + SFS_SHC_CQ_RING + 32'(cq_head_s * 16 + 12), w3);
    while (w3[16] == phase_s) begin
      int tid;
      c = '0;
      for (int k = 0; k < 3; k++) begin br(SHC + SFS_SHC_CQ_RING + 32'(cq_head_s * 16 + k * 4), w); c[k*32 +: 32] = w; end
      c[96 +: 32] = w3;
      tid = int'(w3[15:0]);
      if (!exp_st.exists(tid)) begin
        n_fail++; n_unknown++; $display("[%0d] FAIL %s: completion for unknown TID %04h", cyc, grp, tid);
      end else begin
        if (seen[tid]) begin n_fail++; n_dup++; $display("[%0d] FAIL %s: duplicate completion TID %04h", cyc, grp, tid); end
        else n_completed++;
        seen[tid] = 1;
        cqe_of[tid] = c;
        cpl_order.push_back(tid);
        if (exp_st[tid] >= 0) check($sformatf("status of TID %04h", tid), 64'(w3[23:17]), 64'(exp_st[tid]));
      end
      cq_head_s = (cq_head_s + 1) % HQD;
      if (cq_head_s == 0) phase_s = !phase_s;
      n++;
      br(SHC + SFS_SHC_CQ_RING + 32'(cq_head_s * 16 + 12), w3);
    end
    if (n) bw(SHC + SFS_SHC_CQ_HEAD, 32'(cq_head_s));
  endtask
  // ---- host-queue server: ONE process performs submit / ring / reap (Verilator inlines every timed task at its call
  // sites; 8 BAR writes per submit, repeated at hundreds of call sites, made the generated C++ unusably large).
  int   q_kind, q_op, q_flags, q_tid, q_len, q_exp, q_n, q_tid_out;
  int   q_tids [$];
  longint q_tmo;
  logic [63:0] q_addr;
  logic [31:0] q_hbuf;
  event q_go, q_fin;
  bit   q_busy = 0;
  always begin
    @(q_go);
    case (q_kind)
      0: srv_submit(q_op, q_flags, q_tid, q_addr, q_len, q_hbuf, q_exp);
      1: srv_ring();
      3: srv_do_cmd(q_op, q_flags, q_addr, q_len, q_hbuf, q_exp, q_tid_out);
      4: srv_wait_tids(q_tids, q_tmo);
      5: srv_wr(q_lba, q_nn, q_flags, q_st);
      6: srv_rd_check(q_lba, q_nn, q_what, q_st);
      7: srv_trim(q_lba, q_nn, q_st);
      default: srv_reap(q_n);
    endcase
    -> q_fin;
  end
  task automatic q_call();
    #1 -> q_go;
    @(q_fin);
    q_busy = 0;
  endtask
  task automatic submit(input int op, input int flags, input int tid, input logic [63:0] addr, input int len,
                        input logic [31:0] hbuf, input int expect_status);
    while (q_busy) @(posedge clk);
    q_busy = 1; q_kind = 0; q_op = op; q_flags = flags; q_tid = tid; q_addr = addr; q_len = len; q_hbuf = hbuf; q_exp = expect_status;
    q_call();
  endtask
  task automatic ring();
    while (q_busy) @(posedge clk);
    q_busy = 1; q_kind = 1;
    q_call();
  endtask
  task automatic wait_tids(input int tids [$], input longint tmo);
    while (q_busy) @(posedge clk);
    q_busy = 1; q_kind = 4; q_tids = tids; q_tmo = tmo;
    q_call();
  endtask
  task automatic do_cmd(input int op, input int flags, input logic [63:0] addr, input int len, input logic [31:0] hb,
                        input int expect_status, output int tid);
    while (q_busy) @(posedge clk);
    q_busy = 1; q_kind = 3; q_op = op; q_flags = flags; q_addr = addr; q_len = len; q_hbuf = hb; q_exp = expect_status;
    q_call();
    tid = q_tid_out;
  endtask
  task automatic reap(output int n);
    while (q_busy) @(posedge clk);
    q_busy = 1; q_kind = 2;
    q_call();
    n = q_n;
  endtask
  task automatic srv_wait_tids(input int tids [$], input longint tmo);
    longint t0 = cyc; int n, left;
    forever begin
      left = 0;
      foreach (tids[i]) if (!(seen.exists(tids[i]) && seen[tids[i]])) left++;
      if (left == 0) break;
      if (cyc - t0 > tmo) begin
        n_fail++; $display("[%0d] FAIL %s: %0d command(s) did not complete", cyc, grp, left);
        foreach (tids[i]) if (!(seen.exists(tids[i]) && seen[tids[i]])) $display("      missing TID %04h (dec %0d)", tids[i], tids[i]);
        // diagnosis aid: where is the firmware?  (fetch PC sampled twice; map with `riscv64-unknown-elf-addr2line -f -e fw/build/p60_fw.elf`)
        begin
          logic [31:0] pc0, pc1;
          pc0 = dut.u_soc.u_cc.u_cpu.f_pc_q; repeat (997) @(posedge clk); pc1 = dut.u_soc.u_cc.u_cpu.f_pc_q;
          $display("      firmware fetch pc %08h .. %08h, cpu_sleep %0b, host_irq %0b", pc0, pc1, cpu_sleep, host_irq);
        end
        begin
          logic [31:0] r_st, r_sh, r_ct, r_cq, r_is, r_ic, r_sb, r_cp;
          br(SHC + SFS_SHC_STATUS, r_st); br(SHC + SFS_SHC_SQ_HEAD, r_sh); br(SHC + SFS_SHC_CTRL, r_ct); br(SHC + SFS_SHC_CQ_TAIL, r_cq);
          br(SHC + SFS_SHC_INT_STATUS, r_is); br(SHC + SFS_SHC_INT_CTRL, r_ic); br(SHC + SFS_SHC_SUBMITTED, r_sb); br(SHC + SFS_SHC_COMPLETED, r_cp);
          $display("      HIF: status %08h ctrl %08h sq_head %0d cq_tail %0d int_status %08h int_ctrl %08h submitted %0d completed %0d | host sq_tail %0d cq_head %0d phase %0b", r_st, r_ct, r_sh, r_cq, r_is, r_ic, r_sb, r_cp, sq_tail_s, cq_head_s, phase_s);
        end
        if (failfast) $finish;
        break;
      end
      if (!host_irq) @(posedge host_irq or posedge cpu_sleep);
      srv_reap(n);
      if (n == 0) repeat (50) @(posedge clk);
    end
  endtask
  function automatic int st_of(input int tid);  return int'(cqe_of[tid][113 +: 7]); endfunction
  function automatic int err_of(input int tid); return int'(cqe_of[tid][120 +: 8]); endfunction
  function automatic logic [31:0] r0_of(input int tid); return cqe_of[tid][0 +: 32]; endfunction
  function automatic logic [31:0] r1_of(input int tid); return cqe_of[tid][32 +: 32]; endfunction

  // ---------------------------------------------------------------- deterministic random (xorshift32)
  logic [31:0] rng = 32'h6C0FFEE1;
  function automatic logic [31:0] rnd32();
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return rng;
  endfunction
  function automatic int rnd(input int n);        // 0 .. n-1
    return (n <= 1) ? 0 : int'(rnd32() % 32'(n));
  endfunction

  // ---------------------------------------------------------------- data patterns and the LBA oracle
  // generation 0 = never written / deallocated -> reads as zeros
  function automatic logic [31:0] pat(input int lba, input int w, input int gen);
    logic [31:0] x;
    if (gen == 0) return 32'h0;
    x = (32'(lba) * 32'h9E3779B1) ^ (32'(gen) * 32'h85EBCA6B) ^ (32'(w) * 32'hC2B2AE35) ^ 32'h5A5A1234;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5; x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    return x ^ 32'(w);
  endfunction
  int gexp  [0:MAXLBA-1];                          // last acknowledged generation per LBA
  int gpend [0:MAXLBA-1];                          // generation of an in-flight (unacknowledged) write, -1 = none
  bit tpend [0:MAXLBA-1];                          // an in-flight TRIM covers this LBA
  int gen_ctr = 0;
  int ever_wrote [0:MAXLBA-1];                     // bitmask-ish: number of writes ever acknowledged (coverage)
  task automatic oracle_reset();
    for (int i = 0; i < MAXLBA; i++) begin gexp[i] = 0; gpend[i] = -1; tpend[i] = 0; ever_wrote[i] = 0; end
  endtask
  task automatic fill_host_gen(input logic [31:0] hb, input int lba0, input int n, input int g0);
    for (int b = 0; b < n; b++) for (int w = 0; w < LBAB / 4; w++) hmem.wr32(int'(hb) + b * LBAB + w * 4, pat(lba0 + b, w, g0 + b));
  endtask
  task automatic clear_host(input logic [31:0] hb, input int n);
    for (int b = 0; b < n; b++) for (int w = 0; w < LBAB / 4; w++) hmem.wr32(int'(hb) + b * LBAB + w * 4, 32'hDEAD_BEEF);
  endtask
  // compares block b of a host buffer with the pattern of generation g; returns mismatching word count
  function automatic int cmp_block(input logic [31:0] hb, input int b, input int lba, input int g);
    int bad = 0;
    for (int w = 0; w < LBAB / 4; w++) if (hmem.rd32(int'(hb) + b * LBAB + w * 4) !== pat(lba, w, g)) bad++;
    return bad;
  endfunction
  localparam logic [31:0] HB0 = 32'h0001_0000;     // host buffer slots: HB0 + slot * 0x2000 (16 LBAs)
  function automatic logic [31:0] hbuf(input int slot); return HB0 + 32'(slot) * 32'h2000; endfunction

  bit dbg_q = 0, failfast = 0; int cmd_tmo = 12_000_000;
  initial begin if ($test$plusargs("dbgq")) dbg_q = 1; if ($test$plusargs("failfast")) failfast = 1; void'($value$plusargs("cmdtmo=%d", cmd_tmo)); end
  int tid_next = 16'h1000;
  function automatic int new_tid(); tid_next++; return tid_next; endfunction
  task automatic srv_do_cmd(input int op, input int flags, input logic [63:0] addr, input int len, input logic [31:0] hb,
                        input int expect_status, output int tid);
    tid = new_tid();
    srv_submit(op, flags, tid, addr, len, hb, expect_status);
    srv_ring();
    srv_wait_one(tid, longint'(cmd_tmo));
  endtask
  // single-TID wait (no queue: a queue local to this task was found to keep the first command's TID across calls, which made every
  // command after a `seen.delete()` (reboot) wait for TID 0x1001 -- a testbench defect, not a firmware one)
  task automatic srv_wait_one(input int tid, input longint tmo);
    longint t0; int n;
    t0 = cyc;
    forever begin
      if (seen.exists(tid) && seen[tid]) break;
      if (cyc - t0 > tmo) begin
        n_fail++; $display("[%0d] FAIL %s: command TID %04h did not complete", cyc, grp, tid);
        if (failfast) $finish;
        break;
      end
      if (!host_irq) @(posedge host_irq or posedge cpu_sleep);
      srv_reap(n);
      if (n == 0) repeat (50) @(posedge clk);
    end
  endtask

  // oracle-tracked operations (single outstanding command)
  task automatic srv_wr(input int lba, input int n, input int flags, output int st);
    int t, g0;
    g0 = gen_ctr + 1;
    fill_host_gen(hbuf(0), lba, n, g0);
    for (int i = 0; i < n; i++) gpend[lba + i] = g0 + i;
    gen_ctr += n;
    srv_do_cmd(SFS_OP_WRITE, flags, 64'(lba), n, hbuf(0), -1, t);
    st = st_of(t);
    for (int i = 0; i < n; i++) begin
      if (st == SFS_ST_SUCCESS) begin gexp[lba + i] = g0 + i; ever_wrote[lba + i]++; end
      gpend[lba + i] = -1;
    end
  endtask
  // read n LBAs and compare against the oracle; returns the completion status; mismatches are counted as failures
  task automatic srv_rd_check(input int lba, input int n, input string what, output int st);
    int t, bad;
    clear_host(hbuf(1), n);
    srv_do_cmd(SFS_OP_READ, 0, 64'(lba), n, hbuf(1), -1, t);
    st = st_of(t);
    if (st == SFS_ST_SUCCESS) begin
      for (int i = 0; i < n; i++) begin
        bad = cmp_block(hbuf(1), i, lba + i, gexp[lba + i]);
        if (bad) begin n_fail++; $display("[%0d] FAIL %s/%s: LBA %0d read-back mismatch (%0d words, oracle gen %0d)", cyc, grp, what, lba + i, bad, gexp[lba + i]); end
        else n_pass++;
      end
    end
  endtask
  task automatic srv_trim(input int lba, input int n, output int st);
    int t;
    for (int i = 0; i < n; i++) tpend[lba + i] = 1;
    srv_do_cmd(SFS_OP_DEALLOCATE, 0, 64'(lba), n, 32'h0, -1, t);
    st = st_of(t);
    for (int i = 0; i < n; i++) begin if (st == SFS_ST_SUCCESS) gexp[lba + i] = 0; tpend[lba + i] = 0; end
  endtask
  // thin wrappers (see the server comment above)
  string q_what;
  int    q_lba, q_nn, q_st;
  task automatic wr(input int lba, input int n, input int flags, output int st);
    while (q_busy) @(posedge clk);
    q_busy = 1; q_kind = 5; q_lba = lba; q_nn = n; q_flags = flags;
    q_call(); st = q_st;
  endtask
  task automatic rd_check(input int lba, input int n, input string what, output int st);
    while (q_busy) @(posedge clk);
    q_busy = 1; q_kind = 6; q_lba = lba; q_nn = n; q_what = what;
    q_call(); st = q_st;
  endtask
  task automatic trim(input int lba, input int n, output int st);
    while (q_busy) @(posedge clk);
    q_busy = 1; q_kind = 7; q_lba = lba; q_nn = n;
    q_call(); st = q_st;
  endtask
  task automatic verify_all(input string what);
    int st, lo, nn;
    lo = 0;
    while (lo < cap_lba) begin
      nn = (cap_lba - lo > 16) ? 16 : (cap_lba - lo);
      rd_check(lo, nn, what, st);
      check($sformatf("%s: read status LBA %0d..", what, lo), 64'(st), SFS_ST_SUCCESS);
      lo += nn;
    end
  endtask

  // ---------------------------------------------------------------- physical-page lookup in the twin (for error injection)
  // finds the newest host page holding LPN `lba` by scanning the spare records (stored in clear: type @514, LPN @515..518, SEQ @519..524)
  int map_blk [0:MAXLBA-1];
  int map_pg  [0:MAXLBA-1];
  task automatic scan_map();
    longint best [0:MAXLBA-1];
    for (int i = 0; i < MAXLBA; i++) begin map_blk[i] = -1; map_pg[i] = 0; best[i] = -1; end
    for (int b = 0; b < NBLK; b++) for (int p = 0; p < PPB; p++) begin
      logic [7:0] ty; logic [31:0] lpn; longint seq;
      ty = flash.bd_peek(0, b, p, 514);
      if (ty == 8'hD1 || ty == 8'hD2) begin
        lpn = {flash.bd_peek(0, b, p, 518), flash.bd_peek(0, b, p, 517), flash.bd_peek(0, b, p, 516), flash.bd_peek(0, b, p, 515)};
        seq = 0;
        for (int i = 5; i >= 0; i--) seq = (seq << 8) | longint'(flash.bd_peek(0, b, p, 519 + i));
        if (lpn < MAXLBA && seq > best[lpn]) begin best[lpn] = seq; map_blk[lpn] = b; map_pg[lpn] = p; end
      end
    end
  endtask
  function automatic bit find_phys(input int lba, output int blk, output int pg);
    blk = map_blk[lba]; pg = map_pg[lba];
    return (blk >= 0);
  endfunction
  // flip k distinct bits inside the BCH codeword area (data bytes 0..511, spare bytes 513..543)
  task automatic inject_flips(input int blk, input int pg, input int k);
    int bits [$]; int bitpos, byt;
    while (bits.size() < k) begin
      byt = rnd(512 + 31);
      byt = (byt < 512) ? byt : (513 + (byt - 512));
      bitpos = byt * 8 + rnd(8);
      begin bit dup = 0; foreach (bits[i]) if (bits[i] == bitpos) dup = 1; if (!dup) bits.push_back(bitpos); end
    end
    foreach (bits[i]) begin bit ok; ok = flash.bd_flip(0, blk, pg, bits[i]); if (!ok) $display("TB: bd_flip failed at blk %0d pg %0d", blk, pg); end
  endtask

  // ---------------------------------------------------------------- coverage counters (functional)
  int cov_flips [0:15];            // reads served with k injected raw bit errors
  int cov_len   [0:16];            // transfer length histogram
  int cov_op    [0:15];
  int cov_crash_at [0:7];          // crash phases (bucketed by what the workload was doing)
  int cov_qd    [0:16];
  initial begin
    for (int i = 0; i < 16; i++) begin cov_flips[i] = 0; cov_op[i] = 0; end
    for (int i = 0; i < 17; i++) begin cov_len[i] = 0; cov_qd[i] = 0; end
    for (int i = 0; i < 8; i++) cov_crash_at[i] = 0;
  end

  // ======================================================================== scenarios
  task automatic s_smoke();
    int t, st, bad;
    grp = "smoke";
    do_cmd(SFS_OP_IDENTIFY, 0, 0, 0, 32'h3000, SFS_ST_SUCCESS, t);
    check("IDENTIFY id", hmem.rd32(32'h3000), SFS_SYS_ID_VALUE);
    check("IDENTIFY capacity", hmem.rd32(32'h3000 + 16), 32'(cap_lba));
    check("IDENTIFY LBA size", hmem.rd32(32'h3000 + 24), 512);
    wr(0, 4, 0, st); check("write 4 LBAs", 64'(st), SFS_ST_SUCCESS);
    rd_check(0, 4, "smoke read-back", st); check("read status", 64'(st), SFS_ST_SUCCESS);
    wr(2, 1, 0, st); rd_check(0, 4, "smoke overwrite", st);          // overwrite LBA 2
    rd_check(100, 2, "unwritten reads zero", st); check("unwritten read status", 64'(st), SFS_ST_SUCCESS);
    $display("TB smoke: DoD (command -> DMA -> integrity -> ECC -> NAND program/read -> completion) done at cycle %0d", cyc);
  endtask

  // sequential fill, full verify, random overwrite / trim with GC, full verify
  task automatic s_integrity(input int nops);
    int st, lba, n, op, k;
    grp = "integrity";
    for (int l = 0; l < cap_lba; l += 8) begin
      n = (cap_lba - l > 8) ? 8 : (cap_lba - l);
      wr(l, n, 0, st); check($sformatf("fill LBA %0d", l), 64'(st), SFS_ST_SUCCESS);
    end
    verify_all("after sequential fill");
    for (int i = 0; i < nops; i++) begin
      op = rnd(100);
      n = 1 + rnd(4);
      lba = rnd(cap_lba - n + 1);
      if (op < 60) begin wr(lba, n, (rnd(4) == 0) ? FLAG_FUA : 0, st); check("random write", 64'(st), SFS_ST_SUCCESS); end
      else if (op < 90) begin rd_check(lba, n, "random read", st); check("random read status", 64'(st), SFS_ST_SUCCESS); end
      else if (op < 95) begin trim(lba, n, st); check("random trim", 64'(st), SFS_ST_SUCCESS); end
      else begin do_cmd(SFS_OP_FLUSH, 0, 0, 0, 32'h0, SFS_ST_SUCCESS, k); end
    end
    verify_all("after random overwrite/trim (GC exercised)");
  endtask

  task automatic s_ecc();
    int st, blk, pg, t, k, lba, ok_cnt, unc_cnt;
    logic [31:0] ce0, ce1;
    grp = "ecc";
    for (int l = 0; l < 40; l++) begin wr(l, 1, 0, st); end
    scan_map();
    // k = 0..8 raw bit errors are corrected: data exact, exact corrected-bit count reported
    for (k = 0; k <= 8; k++) begin
      lba = 4 + k;
      if (!find_phys(lba, blk, pg)) begin n_fail++; $display("FAIL ecc: cannot locate LBA %0d on the medium", lba); continue; end
      inject_flips(blk, pg, k);
      clear_host(hbuf(1), 1);
      do_cmd(SFS_OP_READ, 0, 64'(lba), 1, hbuf(1), SFS_ST_SUCCESS, t);
      check($sformatf("k=%0d data exact", k), 64'(cmp_block(hbuf(1), 0, lba, gexp[lba])), 0);
      check($sformatf("k=%0d corrected bits reported", k), r1_of(t), 32'(k));
      cov_flips[k]++;
    end
    // k = 9..12: beyond t -> explicit uncorrectable completion, never wrong data
    unc_cnt = 0;
    for (k = 9; k <= 12; k++) begin
      lba = 20 + k;
      if (!find_phys(lba, blk, pg)) continue;
      inject_flips(blk, pg, k);
      clear_host(hbuf(1), 1);
      do_cmd(SFS_OP_READ, 0, 64'(lba), 1, hbuf(1), -1, t);
      check($sformatf("k=%0d reports MEDIA_UNREC", k), 64'(st_of(t)), SFS_ST_MEDIA_UNREC);
      check($sformatf("k=%0d error code", k), 64'(err_of(t)), SFS_ERR_NAND_ECC_UE);
      if (st_of(t) == SFS_ST_MEDIA_UNREC) unc_cnt++;
      cov_flips[k]++;
    end
    // the log counts them
    do_cmd(SFS_OP_GET_LOG, 0, 0, 0, 32'hE000, SFS_ST_SUCCESS, t);
    check("GET_LOG magic", hmem.rd32(32'hE000), 32'h474F4C53);
    check_true("log: corrected bits >= sum 1..8", hmem.rd32(32'hE000 + 23 * 4) >= 36);
    check_true("log: uncorrectable pages >= 4", hmem.rd32(32'hE000 + 25 * 4) >= unc_cnt);
    // an uncorrectable page does not poison the rest of the device
    rd_check(0, 4, "neighbours unaffected", st);
    // a rewrite of an uncorrectable LBA gives it back
    lba = 21; wr(lba, 1, 0, st); check("rewrite status", 64'(st), SFS_ST_SUCCESS); rd_check(lba, 1, "rewritten after UE", st);
    gexp[29] = gexp[29]; // LBA 29..32 stay UE (not checked further)
  endtask

  // ---------------------------------------------------------------- crash campaign
  // Workload: random 1..3-LBA writes (+ occasional trim/flush) on a working set, queue depth 1..4.  At a random cycle the
  // supply is cut (SoC reset + NAND vcc drop).  After re-boot every LBA must hold a generation that was acknowledged
  // (or one that was in flight when the supply was cut), never an older one and never a mix of two generations.
  int crash_total = 0, crash_inflight_total = 0, crash_recovered_lbas = 0, crash_lost_acked = 0;
  task automatic crash_verify(input int sample_only);
    int st, lo, nn, bad_old, observed, stride;
    // every LBA with an in-flight command, plus a sample of the rest (full coverage every 'full' pass)
    for (int l = 0; l < cap_lba; l++) begin
      bit need;
      need = (gpend[l] >= 0) || tpend[l] || (sample_only == 0) || (rnd(16) == 0);
      if (!need) continue;
      begin
        int t; bit match_exp = 0, match_pend = 0, match_zero = 0;
        clear_host(hbuf(1), 1);
        do_cmd(SFS_OP_READ, 0, 64'(l), 1, hbuf(1), -1, t);
        if (st_of(t) != SFS_ST_SUCCESS) begin
          n_fail++; $display("[%0d] FAIL crash: LBA %0d unreadable after recovery (status %0h)", cyc, l, st_of(t));
          continue;
        end
        match_exp  = (cmp_block(hbuf(1), 0, l, gexp[l]) == 0);
        match_pend = (gpend[l] >= 0) && (cmp_block(hbuf(1), 0, l, gpend[l]) == 0);
        match_zero = tpend[l] && (cmp_block(hbuf(1), 0, l, 0) == 0);
        if (match_exp || match_pend || match_zero) begin
          n_pass++;
          if (!match_exp && (gpend[l] >= 0 || tpend[l])) crash_recovered_lbas++;   // the unacknowledged command had taken effect
          if (match_pend) gexp[l] = gpend[l];
          else if (match_zero) gexp[l] = 0;
        end else begin
          n_fail++; crash_lost_acked++;
          $display("[%0d] FAIL crash: LBA %0d holds neither the acknowledged generation %0d nor an in-flight one (pend %0d trim %0d)", cyc, l, gexp[l], gpend[l], tpend[l]);
        end
        gpend[l] = -1; tpend[l] = 0;
      end
    end
  endtask

  task automatic s_crash(input int ncrash, input int nwset);
    int ws [$];
    int st, t, n, lba, op, qd, issued, tids [$], pend_tid [int], pend_lba [int], pend_n [int], pend_kind [int], pend_g0 [int];
    longint cut_at, t0;
    grp = "crash";
    // working set + a full prefill so that GC and wear-levelling are in play
    for (int i = 0; i < nwset; i++) ws.push_back(rnd(cap_lba - 3));
    begin int pf; if (!$value$plusargs("prefill=%d", pf)) pf = cap_lba; if (pf > cap_lba) pf = cap_lba;
      for (int l = 0; l < pf; l += 8) begin n = (pf - l > 8) ? 8 : (pf - l); wr(l, n, 0, st); end end
    for (int c = 0; c < ncrash; c++) begin
      int k_resolved;
      pend_tid.delete(); pend_lba.delete(); pend_n.delete(); pend_kind.delete(); pend_g0.delete();
      cut_at = cyc + 20_000 + longint'(rnd(700_000));
      issued = 0;
      // issue commands until the cut; completions are reaped as they arrive
      while (cyc < cut_at) begin
        int left;
        qd = 1 + rnd(4);
        // submit up to qd commands on disjoint LBAs
        for (int q = 0; q < qd && cyc < cut_at; q++) begin
          bit busy_l;
          n = 1 + rnd(3);
          lba = ws[rnd(ws.size())];
          busy_l = 0;
          foreach (pend_tid[x]) if (!seen[x] && lba < pend_lba[x] + pend_n[x] && pend_lba[x] < lba + n) busy_l = 1;
          if (busy_l) continue;
          op = rnd(100);
          t = new_tid();
          if (op < 88) begin
            int g0; g0 = gen_ctr + 1;
            fill_host_gen(hbuf(q + 2), lba, n, g0);
            for (int i = 0; i < n; i++) gpend[lba + i] = g0 + i;
            gen_ctr += n;
            submit(SFS_OP_WRITE, 0, t, 64'(lba), n, hbuf(q + 2), -1);
            pend_kind[t] = 0; pend_g0[t] = g0;
          end else if (op < 96) begin
            for (int i = 0; i < n; i++) tpend[lba + i] = 1;
            submit(SFS_OP_DEALLOCATE, 0, t, 64'(lba), n, 32'h0, -1);
            pend_kind[t] = 1; pend_g0[t] = 0;
          end else begin
            submit(SFS_OP_FLUSH, 0, t, 64'd0, 0, 32'h0, -1);
            pend_kind[t] = 2; pend_g0[t] = 0; n = 0;
          end
          pend_tid[t] = t; pend_lba[t] = lba; pend_n[t] = n;
          issued++;
        end
        ring();
        cov_qd[(qd > 16) ? 16 : qd]++;
        // wait for the batch (or the cut)
        t0 = cyc;
        begin
          int nreap;
          while (cyc < cut_at) begin
            left = 0;
            foreach (pend_tid[x]) if (!seen[x]) left++;
            if (left == 0) break;
            reap(nreap);
            if (nreap == 0) repeat (40) @(posedge clk);
          end
        end
        // account completed commands in the oracle
        foreach (pend_tid[x]) if (seen[x] && pend_tid[x] >= 0) begin
          int stc; stc = st_of(x);
          if (stc == SFS_ST_SUCCESS) begin
            if (pend_kind[x] == 0) for (int i = 0; i < pend_n[x]; i++) begin gexp[pend_lba[x] + i] = pend_g0[x] + i; gpend[pend_lba[x] + i] = -1; ever_wrote[pend_lba[x] + i]++; end
            else if (pend_kind[x] == 1) for (int i = 0; i < pend_n[x]; i++) begin gexp[pend_lba[x] + i] = 0; tpend[pend_lba[x] + i] = 0; end
          end else if (pend_kind[x] == 0) for (int i = 0; i < pend_n[x]; i++) gpend[pend_lba[x] + i] = -1;
          else if (pend_kind[x] == 1) for (int i = 0; i < pend_n[x]; i++) tpend[pend_lba[x] + i] = 0;
          pend_tid[x] = -1;
        end
      end
      // ---------------------------------------------- power cut
      begin
        int infl = 0; foreach (pend_tid[x]) if (pend_tid[x] >= 0 && !seen[x]) infl++;
        crash_inflight_total += infl;
        cov_crash_at[(infl > 7) ? 7 : infl]++;
        foreach (pend_tid[x]) if (pend_tid[x] >= 0 && seen[x]) begin  // completed but not yet accounted
          int stc; stc = st_of(x);
          if (stc == SFS_ST_SUCCESS) begin
            if (pend_kind[x] == 0) for (int i = 0; i < pend_n[x]; i++) begin gexp[pend_lba[x] + i] = pend_g0[x] + i; gpend[pend_lba[x] + i] = -1; end
            else if (pend_kind[x] == 1) for (int i = 0; i < pend_n[x]; i++) begin gexp[pend_lba[x] + i] = 0; tpend[pend_lba[x] + i] = 0; end
          end
        end
      end
      crash_total++;
      power_cycle(40 + rnd(400));
      // sometimes lose power again while the firmware is recovering (nested crash), up to twice in a row
      while (xts_mode == 0 && rnd(3) == 0) boot(1'b1, 1'b0, 100_000 + rnd(2_500_000));
      boot();
      enable_ctrl();
      tid_next += 16;
      exp_st.delete(); seen.delete();
      crash_verify((c % 4 == 3 || c == ncrash - 1) ? 0 : 1);
      $display("TB crash %0d/%0d: cut with in-flight commands, recovered; cycle %0d, lost-acked so far %0d", c + 1, ncrash, cyc, crash_lost_acked);
    end
  endtask

  // ---------------------------------------------------------------- remaining scenarios are in tb_p60_scenarios.svh
  `include "tb_p60_scenarios.svh"

  // ---------------------------------------------------------------- main
  initial begin
    int seed_v, nc, nop;
    if (!$value$plusargs("scenario=%s", scenario)) scenario = "smoke";
    if (!$value$plusargs("seed=%d", seed_v)) seed_v = 1;
    if (!$value$plusargs("ncrash=%d", nc)) nc = 12;
    if (!$value$plusargs("nops=%d", nop)) nop = 300;
    if (!$value$plusargs("xts=%d", xts_mode)) xts_mode = 0;
    rng = 32'h6C0FFEE1 ^ (32'(seed_v) * 32'h9E3779B1);
    if (rng == 0) rng = 1;
    for (int i = 0; i < 16; i++) test_key[i] = 32'hA5C30000 + 32'(i) * 32'h01010101 + 32'(seed_v);
    oracle_reset();
    $display("tb_p60_soc: scenario %s seed %0d xts %0d ncrash %0d nops %0d", scenario, seed_v, xts_mode, nc, nop);
    nand_vcc = 1'b0; repeat (20) @(posedge clk);
    nand_vcc = 1'b1; repeat (10) @(posedge clk);
    soc_rst_n = 1'b1; rst_n = 1'b1;
    boot();
    grp = "enable"; enable_ctrl();
    check_true("capacity published", cap_lba > 0);
    $display("TB host: namespace %0d LBAs x 512 B", cap_lba);
    s_smoke();
    case (scenario)
      "smoke": ;
      "integrity": s_integrity(nop);
      "ecc": s_ecc();
      "crash": s_crash(nc, 24);
      "invalid": s_invalid();
      "concurrency": s_concurrency();
      "backpressure": s_backpressure();
      "ctrlreset": s_ctrlreset();
      "plp": s_plp();
      "security": begin s_security(); s_keypolicy(); end
      "bench": s_bench();
      "noformat": s_noformat();
      "badblock": s_badblock();
      "random": s_random(nop);
      "top": s_top();
      "full": begin s_integrity(nop); s_ecc(); s_invalid(); s_concurrency(); s_backpressure(); s_ctrlreset(); s_plp(); s_badblock(); s_random(nop); s_noformat(); s_crash(nc, 24); end
      default: begin n_fail++; $display("unknown scenario %s", scenario); end
    endcase
    finish_checks();
    $finish;
  end
  initial begin
    longint tmo;
    if (!$value$plusargs("timeout=%d", tmo)) tmo = 400_000_000;
    while (cyc < tmo) @(posedge clk);
    $display("tb_p60_soc %s: TIMEOUT at cycle %0d (group %s) -> FAIL", scenario, cyc, grp);
    $finish;
  end
endmodule

`default_nettype wire
