#!/usr/bin/env python3
"""
analyze.py -- summarise the endurance sweep and compute the ECC consequence analytically.

usage: analyze.py <results_dir> <out_dir>
  reads <results_dir>/*.json (endurance.c summaries) and *_hist.csv / *.csv time series
  writes <out_dir>/endurance.json and <out_dir>/ENDURANCE.md

Everything here is a MODEL: coefficients are the P52 NANDLab twin's illustrative values (uncalibrated), the rated endurance of the
simulated device is scaled (default 1000 cycles), and no drive endurance rating (JESD218) can be derived from it.
"""
import glob, json, math, os, sys

res, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)

# ----- ECC consequence: probability that a 512-B BCH codeword (n = 4344 bits, t = 8) is uncorrectable at a given RBER
N, T = 4344, 8
def _logpmf(k, rber):
    return math.lgamma(N + 1) - math.lgamma(k + 1) - math.lgamma(N - k + 1) + k * math.log(rber) + (N - k) * math.log1p(-rber)
def p_uncorr(rber):
    """P(more than T bit errors in an N-bit codeword), exact binomial.  Tail sum when the mean is below T (terms fall away fast);
    1 - CDF(T) when the mean is above T (the tail is then most of the mass and a truncated tail sum would be wrong)."""
    if rber <= 0: return 0.0
    if N * rber <= T:
        return min(1.0, sum(math.exp(_logpmf(k, rber)) for k in range(T + 1, N + 1) if _logpmf(k, rber) > -745))
    return max(0.0, 1.0 - sum(math.exp(_logpmf(k, rber)) for k in range(0, T + 1)))

PROFILES = {   # P52 fault_profiles.json values (illustrative): rber_fresh, rber_wear_at_rated, retention_rber_ref @ ref hours, wear gain on retention
    "nominal": dict(fresh=1e-10, wear=1e-7, ret_ref=1e-8, ret_h=8760.0, ret_gain=50.0),
    "stress":  dict(fresh=2e-5,  wear=2e-3, ret_ref=1e-3, ret_h=1000.0, ret_gain=50.0),
}
def rber(profile, c, hours):
    p = PROFILES[profile]
    return min(0.5, p["fresh"] + p["wear"] * c * c + p["ret_ref"] * (hours / p["ret_h"]) * (1 + p["ret_gain"] * c))   # clamp: a bit cannot be worse than a coin flip

trend = {}
for name in PROFILES:
    rows = []
    for c in (0.0, 0.1, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0):
        for hours in (0.0, 8760.0):
            r = rber(name, c, hours)
            pu = p_uncorr(r)
            rows.append(dict(pe_fraction_of_rated=c, retention_hours=hours, rber=r, expected_bit_errors_per_codeword=N * r,
                             p_codeword_uncorrectable=pu, clamped=(r >= 0.5)))
    trend[name] = rows

# ----- runs
runs = []
for f in sorted(glob.glob(os.path.join(res, "*.json"))):
    d = json.load(open(f)); d["file"] = os.path.basename(f)[:-5]; runs.append(d)

def row(d):
    dw = d["host_pages_written"] / d["nlba"]
    return dict(run=d["file"], workload=d["workload"], op_permille=d["op_permille"], wl=d["wear_leveling"], gc=d["gc"],
                wa=d["write_amplification"], mean_pe_at_end=d["mean_pe"], pe_min=d["pe_min"], pe_max=d["pe_max"],
                grown_bad=d["blocks_bad_grown"], factory_bad=d["blocks_bad_factory"], prog_fail=d["prog_fail"], erase_fail=d["erase_fail"],
                drive_writes_until_end=dw, end_of_life=d["end_of_life"], eol_code=d["eol_reason_code"],
                nand_rule_violations=d["nand_violations"], rated_scaled=d["rated_endurance_scaled"])
table = [row(d) for d in runs]
json.dump(dict(runs=table, ecc_trend=trend, model="NANDLab slc_tiny illustrative coefficients; rated endurance scaled; NOT a rating"),
          open(os.path.join(out, "endurance.json"), "w"), indent=1)

# ----- markdown
L = ["# Endurance model results", "",
     "> **Model output, not a rating.** Host simulation of the production FTL (vendor/p58b) on the NANDLab-rules simulated NAND with wear-dependent",
     "> program/erase failure rates from the twin's *illustrative, uncalibrated* coefficients; rated endurance scaled to 1000 cycles so end of life",
     "> is reachable in seconds. Shapes and ratios are meaningful; absolute cycle counts are not. A NAND simulator cannot certify a drive endurance rating;",
     "> JESD218/JESD219 were **not accessible** here and the JESD219-style workload is reproduced from memory of its published shape (LBA-zone skew, transfer-size mix).", "",
     "## Runs (device: 256 blocks × 64 pages × 512 B, BCH t = 8, 2 % factory-bad)", "",
     "| run | workload | OP ‰ | WL | WA | mean P/E at end | P/E min–max | grown-bad | drive-writes | end of life | NAND rule violations |", "|---|---|---|---|---|---|---|---|---|---|---|"]
wln = {0: "none", 1: "dynamic", 2: "dyn+static"}
for r in table:
    L.append(f"| {r['run']} | {r['workload']} | {r['op_permille']} | {wln.get(r['wl'], r['wl'])} | {r['wa']:.2f} | {r['mean_pe_at_end']:.0f} | {r['pe_min']}–{r['pe_max']} | {r['grown_bad']} | {r['drive_writes_until_end']:.0f} | "
             f"{'spare exhausted (ENOSPC)' if r['end_of_life'] and r['eol_code'] == 4 else ('read-only' if r['end_of_life'] else 'not reached')} | {r['nand_rule_violations']} |")
L += ["", "Reading: write amplification falls steeply with over-provisioning (uniform random 7/15/28 %: see rows) and end of life arrives when the grown-bad blocks exhaust the spare pool",
      "(factory-bad + over-provisioning), the FTL then returns `ENOSPC`; `NAND rule violations` must be 0 (the FTL never breaks NAND programming rules).", "",
      "## Wear levelling ablation (hot/cold 90/10, 7 % OP)", "", "| policy | P/E min–max | spread | WA | grown-bad |", "|---|---|---|---|---|"]
for r in table:
    if r["run"].startswith("ablate_"):
        L.append(f"| {wln.get(r['wl'], r['wl'])} | {r['pe_min']}–{r['pe_max']} | {r['pe_max'] - r['pe_min']} | {r['wa']:.2f} | {r['grown_bad']} |")
L += ["", "## ECC consequence of wear (analytic; BCH t = 8 over a 4 344-bit codeword)", "",
      "RBER(c, hours) = fresh + wear·c² + retention_ref·(hours/ref_h)·(1 + 50c), c = P/E ÷ rated (twin formulas). The `stress` profile is the twin's deliberately harsh one.", ""]
for name, rows in trend.items():
    L += [f"### profile `{name}`", "", "| P/E ÷ rated | retention | RBER | mean bit errors / codeword | P(codeword uncorrectable) |", "|---|---|---|---|---|"]
    for r in rows:
        L.append(f"| {r['pe_fraction_of_rated']:.2f} | {'1 y' if r['retention_hours'] else '0'} | {r['rber']:.2e}{' (clamped)' if r['clamped'] else ''} | {r['expected_bit_errors_per_codeword']:.3g} | {r['p_codeword_uncorrectable']:.2e} |")
    L.append("")
L += ["Observation: under the `nominal` profile t = 8 is overwhelmingly sufficient to the rated life; under `stress` the codeword failure probability becomes significant",
      "near rated endurance with one year of retention, which is where read-retry, scrubbing/refresh (`refresh_bitflips` in the FTL) and a stronger code are needed.",
      "None of this is calibrated; `t` must be re-derived from real device characterisation."]
open(os.path.join(out, "ENDURANCE.md"), "w").write("\n".join(L) + "\n")
print(f"{len(table)} runs summarised -> {out}")
