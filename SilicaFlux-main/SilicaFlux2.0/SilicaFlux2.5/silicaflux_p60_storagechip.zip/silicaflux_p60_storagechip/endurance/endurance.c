/* =============================================================================
 * SilicaFlux-STORE P60 -- wear / endurance simulation on the production FTL
 *
 * The SAME FTL library that runs on the ControlCore (vendor/p58b, P56 core + P58 hardening) is driven on the host
 * against the simulated NAND (hal/sim/simnand.c, NANDLab rules), with a wear-dependent fault model taken from the
 * NANDLab twin's documented formulas (docs/MODEL_LIMITATIONS.md of P52; ALL coefficients are illustrative and NOT
 * calibrated to any device):
 *      c = mean P/E cycles / rated endurance
 *      program failure probability  = pf_fresh + pf_rated * c^3         (per program)
 *      erase failure probability    = ef_fresh + ef_rated * c^3         (per erase, sticky -> the FTL retires the block)
 * Bit-error rate per cell (RBER) is NOT injected here (simnand has no wear-dependent RBER); the ECC consequence is
 * computed analytically by endurance/analyze.py from the same formulas and the BCH t = 8 / 4344-bit codeword.
 *
 * Because a real 100k-cycle SLC endurance cannot be simulated, `--rated N` scales the rated endurance (default
 * 1000): wear-out behaviour (bad-block growth, spare exhaustion, end of life) appears within minutes.  Shapes and
 * ratios (write amplification, wear spread, spare consumption per cycle fraction) are meaningful; absolute cycle
 * counts are NOT a rating.  A NAND simulator does not certify a drive endurance rating.
 *
 * usage: endurance --out <prefix> [--blocks 256] [--ppb 64] [--op 70] [--workload uniform|hotcold|jesd219|seq]
 *                  [--rated 1000] [--maxpe 3000] [--seed 1] [--gc greedy|cb] [--wl none|dyn|static]
 * output: <prefix>.csv (time series), <prefix>_hist.csv (final erase-count histogram), <prefix>.json (summary)
 * ===========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <inttypes.h>
#include "sfftl.h"
#include "simnand.h"

static uint64_t rs = 88172645463325252ull;
static uint64_t rnd64(void) { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
static double   rndu(void) { return (double)(rnd64() >> 11) / 9007199254740992.0; }

typedef enum { W_UNIFORM, W_HOTCOLD, W_JESD219, W_SEQ } wl_t;
static const char *WLN[] = { "uniform", "hotcold", "jesd219", "seq" };

/* JESD219-style enterprise workload shape (transfer-size mix and LBA-zone skew) -- written from memory of the
 * standard's description; NOT checked against the (paywalled) specification text.  Sizes are in 512-byte units. */
static uint32_t jesd_size(uint32_t lba_per_page) {
  static const struct { double p; uint32_t sz; } T[] = {
    { 0.04, 1 }, { 0.01, 2 }, { 0.01, 3 }, { 0.01, 4 }, { 0.01, 5 }, { 0.01, 6 }, { 0.01, 7 }, { 0.67, 8 },
    { 0.10, 16 }, { 0.07, 32 }, { 0.03, 64 }, { 0.03, 128 } };
  double u = rndu(), a = 0;
  for (unsigned i = 0; i < sizeof(T) / sizeof(T[0]); i++) { a += T[i].p; if (u < a) return (T[i].sz + lba_per_page - 1) / lba_per_page; }
  return 1;
}
static uint64_t jesd_lba(uint64_t nlba) {
  double u = rndu();
  if (u < 0.50) return (uint64_t)(rndu() * 0.05 * (double)nlba);                       /* 50% of accesses -> first 5% */
  if (u < 0.80) return (uint64_t)((0.05 + rndu() * 0.15) * (double)nlba);              /* 30% -> next 15%             */
  return (uint64_t)((0.20 + rndu() * 0.80) * (double)nlba);                            /* 20% -> remaining 80%        */
}

int main(int argc, char **argv) {
  const char *out = "endurance"; uint32_t blocks = 256, ppb = 64, op = 70, maxpe = 3000; double rated = 1000;
  wl_t wl = W_UNIFORM; uint64_t seed = 1; sfftl_gc_policy_t gcp = SFFTL_GC_GREEDY; sfftl_wl_policy_t wlp = SFFTL_WL_DYNAMIC_STATIC;
  double pf_fresh = 1e-7, pf_rated = 1e-4, ef_fresh = 1e-6, ef_rated = 1e-3;
  const uint32_t page = 512;
  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--out") && i + 1 < argc) out = argv[++i];
    else if (!strcmp(argv[i], "--blocks") && i + 1 < argc) blocks = (uint32_t)atoi(argv[++i]);
    else if (!strcmp(argv[i], "--ppb") && i + 1 < argc) ppb = (uint32_t)atoi(argv[++i]);
    else if (!strcmp(argv[i], "--op") && i + 1 < argc) op = (uint32_t)atoi(argv[++i]);
    else if (!strcmp(argv[i], "--rated") && i + 1 < argc) rated = atof(argv[++i]);
    else if (!strcmp(argv[i], "--maxpe") && i + 1 < argc) maxpe = (uint32_t)atoi(argv[++i]);
    else if (!strcmp(argv[i], "--seed") && i + 1 < argc) seed = (uint64_t)atoll(argv[++i]);
    else if (!strcmp(argv[i], "--workload") && i + 1 < argc) { const char *w = argv[++i]; for (int k = 0; k < 4; k++) if (!strcmp(w, WLN[k])) wl = (wl_t)k; }
    else if (!strcmp(argv[i], "--gc") && i + 1 < argc) gcp = !strcmp(argv[++i], "cb") ? SFFTL_GC_COST_BENEFIT : SFFTL_GC_GREEDY;
    else if (!strcmp(argv[i], "--wl") && i + 1 < argc) { const char *w = argv[++i]; wlp = !strcmp(w, "none") ? SFFTL_WL_NONE : !strcmp(w, "dyn") ? SFFTL_WL_DYNAMIC : SFFTL_WL_DYNAMIC_STATIC; }
    else { fprintf(stderr, "bad argument %s\n", argv[i]); return 2; }
  }
  rs ^= seed * 0x9E3779B97F4A7C15ull; if (!rs) rs = 1;

  simnand_cfg_t nc;
  simnand_cfg_default(&nc, page, ppb, blocks);
  nc.ecc_bits = 8;                                   /* BCH t = 8 (P54 N512T8U16) */
  nc.factory_bad_permille = 20;                      /* NANDLab: 2 % factory-bad blocks */
  nc.page_spare_bytes = 32;
  simnand_t *n = simnand_create(&nc, seed);
  simnand_manufacture(n);
  sfftl_hal_t hal; simnand_hal(n, &hal);
  sfftl_geom_t g = { page, 32, ppb, blocks };
  sfftl_cfg_t c; sfftl_cfg_default(&c);
  c.lba_bytes = page; c.op_permille = op; c.gc_policy = gcp; c.wl_policy = wlp; c.flags |= SFFTL_F_PACED_GC;
  size_t need = sfftl_mem_required(&g, &c);
  void *arena = aligned_alloc(8, (need + 7) & ~(size_t)7);
  sfftl_t *f = (sfftl_t *)calloc(1, sizeof(sfftl_t));
  int rc = sfftl_format(f, &g, &c, &hal, arena, need);
  if (rc) { fprintf(stderr, "format failed: %s\n", sfftl_strerror(rc)); return 1; }
  uint64_t nlba = sfftl_capacity_lba(f);
  uint8_t *buf = (uint8_t *)malloc(128u * page);
  for (size_t i = 0; i < 128u * page; i++) buf[i] = (uint8_t)rnd64();

  char path[512];
  snprintf(path, sizeof path, "%s.csv", out);
  FILE *csv = fopen(path, "w");
  fprintf(csv, "host_pages,host_gib_equiv,mean_pe,pe_frac_rated,wa_cum,wa_window,pe_min,pe_max,pe_sd,bad_grown,free_blocks,prog_fail,erase_fail,gc_victims,read_only\n");

  /* fill (sequential, once) */
  for (uint64_t l = 0; l < nlba; l += 64) { uint32_t k = (nlba - l > 64) ? 64 : (uint32_t)(nlba - l); if (sfftl_write(f, l, k, buf)) { fprintf(stderr, "fill failed\n"); return 1; } }
  simnand_reset_stats(n);
  sfftl_stats_t s0 = *sfftl_stats(f);

  uint64_t host_pages = 0, win_host = 0, next_sample = nlba / 2, seq_ptr = 0, last_erases = 0, eol_host = 0;
  uint32_t eol_reason = 0; int eol = 0;
  double mean_pe = 0;
  const uint64_t hot_end = (uint64_t)((double)nlba * 0.10);
  uint64_t prev_phys = 0;
  sfftl_space_t sp;
  while (!eol) {
    uint64_t lba; uint32_t cnt = 1;
    switch (wl) {
      case W_UNIFORM: lba = rnd64() % nlba; break;
      case W_HOTCOLD: lba = (rndu() < 0.9) ? (rnd64() % hot_end) : (hot_end + rnd64() % (nlba - hot_end)); break;
      case W_JESD219: lba = jesd_lba(nlba); cnt = jesd_size(1); break;
      default: lba = seq_ptr; cnt = 8; seq_ptr = (seq_ptr + cnt) % nlba; break;
    }
    if (lba + cnt > nlba) { if (lba >= nlba) lba = nlba - 1; cnt = (uint32_t)(nlba - lba); if (cnt > 128) cnt = 128; }
    if (cnt > 128) cnt = 128;
    rc = sfftl_write(f, lba, cnt, buf);
    if (rc) { eol = 1; eol_host = host_pages; eol_reason = (uint32_t)(-rc); break; }
    host_pages += cnt; win_host += cnt;
    /* wear-dependent fault rates, refreshed every ~256 erases */
    const simnand_stats_t *ns = simnand_stats(n);
    if (ns->erases >= last_erases + 256) {
      last_erases = ns->erases;
      sfftl_space(f, &sp);
      mean_pe = sp.ec_blocks ? (double)sp.ec_sum / (double)sp.ec_blocks : 0;
      double cc = mean_pe / rated, c3 = cc * cc * cc;
      uint32_t pp = (uint32_t)(1e6 * (pf_fresh + pf_rated * c3)), ep = (uint32_t)(1e6 * (ef_fresh + ef_rated * c3));
      simnand_set_random(n, pp, ep, 0, 0);
    }
    if (host_pages >= next_sample) {
      const sfftl_stats_t *s = sfftl_stats(f);
      sfftl_space(f, &sp);
      mean_pe = sp.ec_blocks ? (double)sp.ec_sum / (double)sp.ec_blocks : 0;
      uint64_t phys = (s->nand_prog_host + s->nand_prog_reloc + s->nand_prog_meta) - (s0.nand_prog_host + s0.nand_prog_reloc + s0.nand_prog_meta);
      double wa = host_pages ? (double)phys / (double)host_pages : 0, waw = win_host ? (double)(phys - prev_phys) / (double)win_host : 0;
      /* wear spread over blocks that are not bad */
      double sum = 0, sq = 0; uint32_t cntb = 0;
      for (uint32_t b = 0; b < blocks; b++) if (!simnand_is_factory_bad(n, b)) { double e = simnand_erase_count(n, b); sum += e; sq += e * e; cntb++; }
      double m = cntb ? sum / cntb : 0, sd = cntb ? sqrt(fmax(0, sq / cntb - m * m)) : 0;
      fprintf(csv, "%" PRIu64 ",%.4f,%.2f,%.5f,%.4f,%.4f,%u,%u,%.2f,%u,%u,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%u\n",
              host_pages, (double)host_pages / (double)nlba, mean_pe, mean_pe / rated, wa, waw, sp.ec_min, sp.ec_max, sd,
              sp.blocks_bad_grown, sp.blocks_free, s->prog_fail, s->erase_fail, s->gc_victims, sp.read_only);
      prev_phys = phys; win_host = 0;
      next_sample = host_pages + nlba * 2;
      if (mean_pe >= (double)maxpe) break;
      if (sp.read_only) { eol = 1; eol_host = host_pages; eol_reason = 99; }
    }
  }
  fclose(csv);
  const sfftl_stats_t *s = sfftl_stats(f);
  sfftl_space(f, &sp);
  mean_pe = sp.ec_blocks ? (double)sp.ec_sum / (double)sp.ec_blocks : 0;
  uint64_t phys = (s->nand_prog_host + s->nand_prog_reloc + s->nand_prog_meta) - (s0.nand_prog_host + s0.nand_prog_reloc + s0.nand_prog_meta);

  snprintf(path, sizeof path, "%s_hist.csv", out);
  FILE *h = fopen(path, "w");
  fprintf(h, "block,erase_count,factory_bad\n");
  uint32_t good = 0, mx = 0, mn = ~0u;
  for (uint32_t b = 0; b < blocks; b++) {
    uint32_t e = simnand_erase_count(n, b), fb = (uint32_t)simnand_is_factory_bad(n, b);
    fprintf(h, "%u,%u,%u\n", b, e, fb);
    if (!fb) { good++; if (e > mx) mx = e; if (e < mn) mn = e; }
  }
  fclose(h);
  snprintf(path, sizeof path, "%s.json", out);
  FILE *j = fopen(path, "w");
  fprintf(j, "{\n \"workload\": \"%s\", \"blocks\": %u, \"pages_per_block\": %u, \"page_bytes\": %u, \"op_permille\": %u,\n"
             " \"gc\": \"%s\", \"wear_leveling\": %d, \"rated_endurance_scaled\": %.0f, \"seed\": %" PRIu64 ",\n"
             " \"nlba\": %" PRIu64 ", \"host_pages_written\": %" PRIu64 ", \"phys_pages_programmed\": %" PRIu64 ", \"write_amplification\": %.4f,\n"
             " \"mean_pe\": %.2f, \"pe_min\": %u, \"pe_max\": %u, \"blocks_good_at_start\": %u, \"blocks_bad_grown\": %u, \"blocks_bad_factory\": %u,\n"
             " \"prog_fail\": %" PRIu64 ", \"erase_fail\": %" PRIu64 ", \"gc_victims\": %" PRIu64 ", \"gc_pages_moved\": %" PRIu64 ", \"ckpts\": %" PRIu64 ",\n"
             " \"end_of_life\": %s, \"eol_reason_code\": %u, \"eol_host_pages\": %" PRIu64 ", \"read_only\": %u,\n"
             " \"nand_violations\": %" PRIu64 ",\n"
             " \"disclaimer\": \"simulation with illustrative, uncalibrated coefficients and a scaled rated endurance; NOT a drive endurance rating\"\n}\n",
          WLN[wl], blocks, ppb, page, op, gcp == SFFTL_GC_GREEDY ? "greedy" : "cost-benefit", (int)wlp, rated, seed,
          nlba, host_pages, phys, host_pages ? (double)phys / (double)host_pages : 0.0, mean_pe, mn == ~0u ? 0 : mn, mx, good,
          sp.blocks_bad_grown, sp.blocks_bad_factory, s->prog_fail, s->erase_fail, s->gc_victims, s->gc_pages_moved, s->ckpt_count,
          eol ? "true" : "false", eol_reason, eol_host, sp.read_only, simnand_stats(n)->violations);
  fclose(j);
  printf("%s: %s  host pages %" PRIu64 "  WA %.3f  mean PE %.1f (min %u max %u)  grown-bad %u  eol=%d(%u)  violations %" PRIu64 "\n",
         out, WLN[wl], host_pages, host_pages ? (double)phys / (double)host_pages : 0.0, mean_pe, mn == ~0u ? 0 : mn, mx, sp.blocks_bad_grown, eol, eol_reason,
         simnand_stats(n)->violations);
  return 0;
}
