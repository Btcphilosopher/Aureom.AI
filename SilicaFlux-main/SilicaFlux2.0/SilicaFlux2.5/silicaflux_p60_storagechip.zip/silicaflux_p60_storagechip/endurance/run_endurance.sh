#!/bin/bash
# Reproducible endurance sweep (host simulation of the production FTL; see endurance.c for the model and its limits)
# usage: run_endurance.sh <outdir> [maxpe]      -> <outdir>/<workload>_op<NN>.{csv,json}, _hist.csv  and  summary.tsv
set -e
HERE=$(cd "$(dirname "$0")" && pwd); P60=$(cd "$HERE/.." && pwd); OUT=${1:-$P60/build/endurance/results}; MAXPE=${2:-1500}
F=$P60/vendor/p58b/firmware/silicaflux_ftl
mkdir -p "$OUT" "$P60/build/endurance"
gcc -std=c11 -O2 -g -Wall -Wextra -I$F/include -I$F/src -I$F/hal/sim $F/src/*.c $F/hal/sim/simnand.c "$HERE/endurance.c" -lm -o "$P60/build/endurance/endurance"
: > "$OUT/summary.tsv"
for WL in uniform hotcold jesd219 seq; do
  for OP in 70 150 280; do
    "$P60/build/endurance/endurance" --out "$OUT/${WL}_op${OP}" --workload $WL --op $OP --blocks 256 --ppb 64 --rated 1000 --maxpe $MAXPE --seed 7 | tee -a "$OUT/summary.tsv"
  done
done
# wear-levelling ablation (uniform and hot/cold, 7 % OP): none vs dynamic vs dynamic+static
for WLP in none dyn static; do
  for WL in hotcold; do
    "$P60/build/endurance/endurance" --out "$OUT/ablate_${WL}_wl${WLP}" --workload $WL --op 70 --wl $WLP --blocks 256 --ppb 64 --rated 1000 --maxpe $MAXPE --seed 7 | tee -a "$OUT/summary.tsv"
  done
done
