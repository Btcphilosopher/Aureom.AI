# DFT and manufacturing readiness (what exists, what does not)

## Integrated and exercised in simulation
* **JTAG TAP + test-mode controller + register bridge** (TestCore P07 `sftc_testcore_top`) instantiated in `silicaflux_storage_top`.
  Verified through the full-chip testbench (`scenario=top`): JTAG IDCODE read through the real TAP = `0x15F07001` (version 1, part `5F07`; the **manufacturer field is a
  PLACEHOLDER** — no JEDEC ID is allocated), TestCore registers reachable from the host BAR (`0xC000_1000`, scratch loop-back), `scan_mode` / `scan_en` / `test_done/pass/fail` outputs present.
  P07's own regression (TAP, MBIST, formal, sky130hd scan insertion, OpenOCD bridge) was re-run by the auditor (12 of 15 steps, all PASS) — see `docs/audit/support_blocks_audit.md`.
* **Reset/power sequencing**: asynchronous-assert/synchronous-release reset, scan-mode bypass, power-fail glitch filter (`rtl/top/`).
* **Functional production-test vectors**: the full-chip regression itself (smoke, ECC injection, integrity, crash) is the functional vector set; `dft/functional_test_plan.md` maps it to a wafer-sort/package-test sequence.

## Planned but NOT done (do not claim)
| Item | State |
|---|---|
| **MBIST for the SoC SRAMs** | The TestCore MBIST engine is instantiated but its bank bus is tied off: **no SRAM of this design is MBIST-wrapped.** IMEM/DMEM live inside the vendored ControlCore, the 16 KiB buffer inside the P26 ECC slave (which exposes a `tst_*` port usable by `sram_mbist_adapter`), and in this release all are flop arrays (generic backend). Silicon needs SRAM macros (not available) and the adapters wired. |
| **Scan insertion / ATPG** | Not run on the P60 design. P07 demonstrated OpenROAD scan insertion on TestCore itself (sky130hd). ATPG coverage: **none claimed.** No scan chains, no compression, no fault-coverage number. |
| PLL/clock test, PHY interface tests | No PLL, no PHY exist (clock from the pad; NAND pins are plain I/O). Planned: PLL bypass + lock-detect observation via TestCore status once a PLL exists. |
| Boundary scan | P07's TAP has **no boundary-scan register** (EXTEST/SAMPLE map to BYPASS). |
| Wafer probe / package test / yield & reliability monitors | Strategy only — see `dft/test_strategy.md`; nothing executed. No yield or reliability data exists. |
| DRC/LVS, ATPG coverage, silicon qualification | **Not executed — no claim.** |
