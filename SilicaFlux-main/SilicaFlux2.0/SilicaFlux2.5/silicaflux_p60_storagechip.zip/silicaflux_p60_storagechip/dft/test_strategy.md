# Production-test strategy (plan; nothing here has been executed)

1. **Wafer probe (sort)**: power-up sequencing check (POR → `rst_n` release, `host_ready`); JTAG IDCODE + TestCore register walk; scan (once inserted) at slow clock;
   MBIST on every SRAM macro (once wrapped) with `fail_log` readout; leakage/IDDQ screen at the foundry-recommended vectors; PLL lock/bypass (when present).
2. **Package test**: functional vector set = the full-chip regression subset (boot ROM image load over the host port → firmware → IDENTIFY → write/read-verify a small
   region against an on-tester NAND emulator or a known-good NAND) at speed; NAND pin DC/AC parametric; host-interface (PCIe, when present) loopback.
3. **Burn-in / reliability monitors**: ring-oscillator and temperature sensors are NOT in the design; add them to the TestCore status chain before a yield-learning run.
4. **Yield learning**: bin on {scan, MBIST, functional, parametric}; correlate with wafer map. Needs foundry data — none exists.
Gates before any manufacturing statement: scan + ATPG coverage numbers, MBIST on all memories, DRC/LVS clean on a full-chip layout, signoff STA at all corners, IR/EM signoff,
reliability qualification (HTOL, ESD, latch-up). **None of these has been done.**
