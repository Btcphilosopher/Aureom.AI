# Functional production-test vectors — mapping of existing tests

| Test step | Source in this repository | What it proves |
|---|---|---|
| Boot + enumerate | `tb/soc/tb_p60_soc.sv` `boot()`, scenario `smoke` | ROM boot, firmware start, FTL format/mount, IDENTIFY |
| Media + ECC path | scenario `ecc` | BCH correct k = 0..8, explicit UE for k > 8, counters |
| Data integrity | scenario `integrity` | full-device write/verify, GC, trim |
| Power-loss | scenario `crash` | recovery of acknowledged data |
| DFT access | scenario `top` | JTAG IDCODE, TestCore regs, IRQ/perf counters |
Run on the tester with a golden NAND model or a characterised NAND; cycle counts of the simulation are in `reports/`.
