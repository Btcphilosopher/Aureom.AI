#!/usr/bin/env python3
"""Golden model for sfx_aes_xts (SilicaFlux-STORE P60, "SecureStore").

Two independent implementations of XTS-AES (IEEE Std 1619-2007 / NIST SP 800-38E,
whole 16-byte blocks only, no ciphertext stealing):

  * lib_xts_*   : python `cryptography` (OpenSSL) -- the primary reference
  * py_xts_*    : pure-python AES + XTS written here from FIPS-197 -- cross-check

Conventions (identical to the RTL):
  - key bytes   : XTS key = key1 || key2 (each KEYBITS/8 bytes)
  - tweak       : 16-byte string, tweak[i] = byte i of the 128-bit little-endian
                  data-unit number
  - T_j = T_0 * alpha^j in GF(2^128), x^128+x^7+x^2+x+1, little-endian
  - C_j = AES_Enc(key1, P_j ^ T_j) ^ T_j      (decrypt: AES_Dec)

`python3 xts_ref.py` runs the self-test (FIPS-197 / SP 800-38A / IEEE 1619
published vectors, then thousands of random lib-vs-pure-python cross-checks).
"""
import os
import random
import sys

# --------------------------------------------------------------------------
# Pure-python AES (FIPS-197)
# --------------------------------------------------------------------------


def _build_sbox():
    sbox = [0] * 256
    p = q = 1
    while True:
        # p *= 3 in GF(2^8)
        p = p ^ ((p << 1) & 0xFF) ^ (0x1B if p & 0x80 else 0)
        # q /= 3 in GF(2^8)
        q ^= (q << 1) & 0xFF
        q ^= (q << 2) & 0xFF
        q ^= (q << 4) & 0xFF
        if q & 0x80:
            q ^= 0x09
        rot = lambda x, n: ((x << n) | (x >> (8 - n))) & 0xFF
        sbox[p] = q ^ rot(q, 1) ^ rot(q, 2) ^ rot(q, 3) ^ rot(q, 4) ^ 0x63
        if p == 1:
            break
    sbox[0] = 0x63
    return sbox


SBOX = _build_sbox()
INV_SBOX = [0] * 256
for _i, _v in enumerate(SBOX):
    INV_SBOX[_v] = _i
assert SBOX[0x00] == 0x63 and SBOX[0x53] == 0xED and SBOX[0xFF] == 0x16


def _xt(b):
    return ((b << 1) & 0xFF) ^ (0x1B if b & 0x80 else 0)


def _mul(a, b):
    r = 0
    while b:
        if b & 1:
            r ^= a
        a = _xt(a)
        b >>= 1
    return r


def key_expand_words(key: bytes):
    """FIPS-197 KeyExpansion. Returns list of 4*(Nr+1) words, each a 4-byte list."""
    nk = len(key) // 4
    assert len(key) in (16, 24, 32)
    nr = nk + 6
    w = [list(key[4 * i:4 * i + 4]) for i in range(nk)]
    rcon = 1
    for i in range(nk, 4 * (nr + 1)):
        t = list(w[i - 1])
        if i % nk == 0:
            t = t[1:] + t[:1]
            t = [SBOX[x] for x in t]
            t[0] ^= rcon
            rcon = _xt(rcon)
        elif nk > 6 and i % nk == 4:
            t = [SBOX[x] for x in t]
        w.append([w[i - nk][k] ^ t[k] for k in range(4)])
    return w


def round_keys(key: bytes):
    """List of Nr+1 16-byte round keys."""
    w = key_expand_words(key)
    return [bytes(sum(w[4 * r:4 * r + 4], [])) for r in range(len(w) // 4)]


def _shift_rows(s):
    return [s[4 * ((c + r) % 4) + r] for c in range(4) for r in range(4)]


def _inv_shift_rows(s):
    return [s[4 * ((c - r) % 4) + r] for c in range(4) for r in range(4)]


_MULT = {m: [_mul(x, m) for x in range(256)] for m in (1, 2, 3, 9, 11, 13, 14)}


def _mix(s, m):
    """Column mixing with circulant matrix first row m (MixColumns / InvMixColumns)."""
    t = [_MULT[x] for x in m]
    out = []
    for c in range(4):
        a0, a1, a2, a3 = s[4 * c:4 * c + 4]
        out += [t[0][a0] ^ t[1][a1] ^ t[2][a2] ^ t[3][a3],
                t[3][a0] ^ t[0][a1] ^ t[1][a2] ^ t[2][a3],
                t[2][a0] ^ t[3][a1] ^ t[0][a2] ^ t[1][a3],
                t[1][a0] ^ t[2][a1] ^ t[3][a2] ^ t[0][a3]]
    return out


_MIX = (2, 3, 1, 1)
_INV_MIX = (14, 11, 13, 9)


def aes_encrypt_block(rks, block: bytes) -> bytes:
    nr = len(rks) - 1
    s = [a ^ b for a, b in zip(block, rks[0])]
    for r in range(1, nr + 1):
        s = _shift_rows([SBOX[x] for x in s])
        if r != nr:
            s = _mix(s, _MIX)
        s = [a ^ b for a, b in zip(s, rks[r])]
    return bytes(s)


def aes_decrypt_block(rks, block: bytes) -> bytes:
    nr = len(rks) - 1
    s = [a ^ b for a, b in zip(block, rks[nr])]
    for r in range(nr - 1, -1, -1):
        s = [INV_SBOX[x] for x in _inv_shift_rows(s)]
        s = [a ^ b for a, b in zip(s, rks[r])]
        if r != 0:
            s = _mix(s, _INV_MIX)
    return bytes(s)


# --------------------------------------------------------------------------
# XTS
# --------------------------------------------------------------------------
MASK128 = (1 << 128) - 1


def gf_mul_alpha(t: int) -> int:
    """Multiply by alpha in GF(2^128); t is the little-endian integer value."""
    carry = t >> 127
    t = (t << 1) & MASK128
    return t ^ 0x87 if carry else t


def py_xts(key: bytes, tweak: bytes, data: bytes, decrypt: bool) -> bytes:
    assert len(key) in (32, 64) and len(tweak) == 16 and len(data) % 16 == 0
    h = len(key) // 2
    rk1 = round_keys(key[:h])
    rk2 = round_keys(key[h:])
    t = int.from_bytes(aes_encrypt_block(rk2, tweak), "little")
    out = bytearray()
    for j in range(0, len(data), 16):
        tb = t.to_bytes(16, "little")
        x = bytes(a ^ b for a, b in zip(data[j:j + 16], tb))
        y = aes_decrypt_block(rk1, x) if decrypt else aes_encrypt_block(rk1, x)
        out += bytes(a ^ b for a, b in zip(y, tb))
        t = gf_mul_alpha(t)
    return bytes(out)


def py_xts_encrypt(key, tweak, pt):
    return py_xts(key, tweak, pt, False)


def py_xts_decrypt(key, tweak, ct):
    return py_xts(key, tweak, ct, True)


# ---- `cryptography` (OpenSSL) reference ----------------------------------
try:
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    HAVE_LIB = True
except Exception:  # pragma: no cover
    HAVE_LIB = False


def lib_xts(key: bytes, tweak: bytes, data: bytes, decrypt: bool) -> bytes:
    c = Cipher(algorithms.AES(key), modes.XTS(tweak))
    op = c.decryptor() if decrypt else c.encryptor()
    return op.update(data) + op.finalize()


def lib_xts_encrypt(key, tweak, pt):
    return lib_xts(key, tweak, pt, False)


def lib_xts_decrypt(key, tweak, ct):
    return lib_xts(key, tweak, ct, True)


def lib_ecb(key: bytes, data: bytes, decrypt: bool = False) -> bytes:
    c = Cipher(algorithms.AES(key), modes.ECB())
    op = c.decryptor() if decrypt else c.encryptor()
    return op.update(data) + op.finalize()


def ref_xts(key, tweak, data, decrypt):
    """Primary reference = `cryptography`. OpenSSL refuses key1 == key2 (FIPS
    rule), in which case fall back to the pure-python model."""
    if HAVE_LIB and key[:len(key) // 2] != key[len(key) // 2:]:
        return lib_xts(key, tweak, data, decrypt)
    return py_xts(key, tweak, data, decrypt)


# --------------------------------------------------------------------------
# Published vectors
# --------------------------------------------------------------------------
H = bytes.fromhex

# FIPS-197 Appendix B / C, NIST SP 800-38A F.1 (ECB)
AES_KATS = [
    # name, key, pt, ct
    ("FIPS197-B AES-128", H("2b7e151628aed2a6abf7158809cf4f3c"),
     H("3243f6a8885a308d313198a2e0370734"), H("3925841d02dc09fbdc118597196a0b32")),
    ("FIPS197-C.1 AES-128", H("000102030405060708090a0b0c0d0e0f"),
     H("00112233445566778899aabbccddeeff"), H("69c4e0d86a7b0430d8cdb78070b4c55a")),
    ("FIPS197-C.3 AES-256",
     H("000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f"),
     H("00112233445566778899aabbccddeeff"), H("8ea2b7ca516745bfeafc49904b496089")),
    ("SP800-38A F.1.1 AES-128", H("2b7e151628aed2a6abf7158809cf4f3c"),
     H("6bc1bee22e409f96e93d7e117393172a"), H("3ad77bb40d7a3660a89ecaf32466ef97")),
    ("SP800-38A F.1.5 AES-256",
     H("603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4"),
     H("6bc1bee22e409f96e93d7e117393172a"), H("f3eed1bdb5d2a03c064b5a7e3db181f8")),
]

# FIPS-197 Appendix A: last words of the expanded key
KS_LAST_WORD = {
    H("2b7e151628aed2a6abf7158809cf4f3c"): (43, "b6630ca6"),
    H("603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4"): (59, "706c631e"),
}

# IEEE Std 1619-2007 Annex B vectors 1..3 (XTS-AES-128, 32-byte data units).
# (key1, key2, data-unit sequence number, plaintext, ciphertext).  The DUS is a
# 128-bit little-endian integer: "3333333333" in the standard means 0x3333333333.
IEEE1619_128 = [
    ("IEEE1619-v1", H("00" * 16), H("00" * 16), 0, H("00" * 32),
     H("917cf69ebd68b2ec9b9fe9a3eadda692cd43d2f59598ed858c02c2652fbf922e")),
    ("IEEE1619-v2", H("11" * 16), H("22" * 16), 0x3333333333, H("44" * 32),
     H("c454185e6a16936e39334038acef838bfb186fff7480adc4289382ecd6d394f0")),
    ("IEEE1619-v3", H("fffefdfcfbfaf9f8f7f6f5f4f3f2f1f0"), H("22" * 16), 0x3333333333, H("44" * 32),
     H("af85336b597afc1a900b2eb21ec949d292df4c047e0b21532186a5971a227a89")),
]

# Key / plaintext patterns of the larger IEEE 1619 vectors (512-byte units,
# plaintext = 00..ff,00..ff).  Expected values for these come from the
# reference implementations (cross-checked); only the first block of the
# DUS=0 XTS-AES-128 case is compared against the published ciphertext prefix.
E_KEY = H("27182818284590452353602874713526")
PI_KEY = H("31415926535897932384626433832795")
E_KEY256 = H("2718281828459045235360287471352662497757247093699959574966967627")
PI_KEY256 = H("3141592653589793238462643383279502884197169399375105820974944592")
PTX512 = bytes(range(256)) * 2
IEEE1619_V10_CT_PREFIX = H("27a7479befa1d476489f308cd4cfa6e2a96e4bbe3208ff25287dd3819616e89c")


def std_units():
    """(name, key(bytes), tweak(16 bytes), plaintext) for the standard-style units
    of both key sizes."""
    u = []
    for name, k1, k2, dus, pt, _ in IEEE1619_128:
        u.append((name, k1 + k2, dus.to_bytes(16, "little"), pt))
    for dus in (0x00, 0x01, 0x02, 0xFD, 0xFE, 0xFF):
        u.append(("IEEE1619-e/pi AES-128 dus=%02x" % dus, E_KEY + PI_KEY,
                  dus.to_bytes(16, "little"), PTX512))
    for dus in (0x00, 0x01, 0xFF):
        u.append(("IEEE1619-e/pi AES-256 dus=%02x" % dus, E_KEY256 + PI_KEY256,
                  dus.to_bytes(16, "little"), PTX512))
    # AES-256 32-byte units with the IEEE v2/v3 style structure
    u.append(("AES-256 32B 1111../2222..", H("11" * 32) + H("22" * 32),
              (0x3333333333).to_bytes(16, "little"), H("44" * 32)))
    u.append(("AES-256 32B all-zero-ish", H("00" * 31 + "01") + H("00" * 31 + "02"),
              (0).to_bytes(16, "little"), H("00" * 32)))
    return u


def selftest(n_random=3000, seed=1619):
    ok = True

    def check(cond, msg):
        nonlocal ok
        if not cond:
            ok = False
            print("SELFTEST FAIL:", msg)

    # AES KATs: pure python and library
    for name, k, pt, ct in AES_KATS:
        rks = round_keys(k)
        check(aes_encrypt_block(rks, pt) == ct, "py AES enc " + name)
        check(aes_decrypt_block(rks, ct) == pt, "py AES dec " + name)
        if HAVE_LIB:
            check(lib_ecb(k, pt) == ct, "lib AES enc " + name)
            check(lib_ecb(k, ct, True) == pt, "lib AES dec " + name)
    for k, (idx, wd) in KS_LAST_WORD.items():
        w = key_expand_words(k)
        check(bytes(w[idx]).hex() == wd, "key schedule last word %d" % idx)

    # IEEE 1619 v1..3: published ciphertext vs both implementations
    for name, k1, k2, dus, pt, ct in IEEE1619_128:
        key, tw = k1 + k2, dus.to_bytes(16, "little")
        check(py_xts_encrypt(key, tw, pt) == ct, "py XTS enc " + name)
        check(py_xts_decrypt(key, tw, ct) == pt, "py XTS dec " + name)
        if HAVE_LIB and k1 != k2:
            check(lib_xts_encrypt(key, tw, pt) == ct, "lib XTS enc " + name)
            check(lib_xts_decrypt(key, tw, ct) == pt, "lib XTS dec " + name)
        elif HAVE_LIB:
            print("note: %s has key1==key2 -> OpenSSL refuses; pure-python model only" % name)
    c = ref_xts(E_KEY + PI_KEY, (0).to_bytes(16, "little"), PTX512, False)
    check(c[:32] == IEEE1619_V10_CT_PREFIX, "IEEE1619 e/pi dus=0 512B ciphertext prefix")

    # random cross-check lib vs pure python
    rnd = random.Random(seed)
    if HAVE_LIB:
        for i in range(n_random):
            kb = rnd.choice((16, 32))
            key = rnd.randbytes(2 * kb)
            tw = rnd.randbytes(16)
            nb = rnd.choice((1, 2, 3, 4, 7, 31, 32))
            pt = rnd.randbytes(16 * nb)
            ct = lib_xts_encrypt(key, tw, pt)
            check(py_xts_encrypt(key, tw, pt) == ct, "random enc #%d" % i)
            check(py_xts_decrypt(key, tw, ct) == pt, "random dec #%d" % i)
            check(lib_xts_decrypt(key, tw, ct) == pt, "lib roundtrip #%d" % i)
    print("xts_ref selftest:", "PASS" if ok else "FAIL",
          "(lib=%s, random=%d)" % (HAVE_LIB, n_random if HAVE_LIB else 0))
    return ok


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="xts_ref self-test")
    ap.add_argument("--random", type=int, default=3000, help="number of random lib-vs-python cross-checks")
    sys.exit(0 if selftest(ap.parse_args().random) else 1)
