read_lef <P60>/pd/pdk/sky130hd.tlef
read_lef <P60>/pd/pdk/sky130_fd_sc_hd_merged.lef
read_liberty <P60>/pd/pdk/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog <P60>/build/pd/block_15ns/netlist.v
link_design sfx_page_engine
read_sdc <P60>/build/pd/block_15ns/pd.sdc
set_wire_rc -signal -layer met2
set_wire_rc -clock  -layer met5
initialize_floorplan -utilization 40 -aspect_ratio 1.0 -core_space 8 -site unithd
make_tracks
place_pins -hor_layers met3 -ver_layers met2
# minimal power grid (VDD/VSS straps) so that routing and power analysis have rails
add_global_connection -net VDD -pin_pattern {^VPWR$} -power
add_global_connection -net VDD -pin_pattern {^VPB$} -power
add_global_connection -net VSS -pin_pattern {^VGND$} -ground
add_global_connection -net VSS -pin_pattern {^VNB$} -ground
global_connect
set_voltage_domain -name CORE -power VDD -ground VSS
define_pdn_grid -name grid -voltage_domains CORE
add_pdn_stripe -layer met1 -followpins -width 0.48
add_pdn_stripe -layer met4 -width 1.6 -pitch 54 -offset 10
add_pdn_stripe -layer met5 -width 1.6 -pitch 54 -offset 10
add_pdn_connect -layers {met1 met4}
add_pdn_connect -layers {met4 met5}
pdngen
global_placement -density 0.55 -pad_left 1 -pad_right 1
estimate_parasitics -placement
repair_design
detailed_placement
clock_tree_synthesis -root_buf sky130_fd_sc_hd__clkbuf_16 -buf_list sky130_fd_sc_hd__clkbuf_8
set_propagated_clock [all_clocks]
detailed_placement
estimate_parasitics -placement
repair_timing -setup -max_buffer_percent 20
detailed_placement
write_db <P60>/build/pd/block_15ns/block_cts.odb
set_global_routing_layer_adjustment met1-met5 0.3
global_route -guide_file <P60>/build/pd/block_15ns/route.guide -congestion_report_file <P60>/build/pd/block_15ns/congestion.rpt
estimate_parasitics -global_routing
# ---- results at global-route stage (written BEFORE detailed routing, which is the slow and least predictable step)
report_design_area
report_checks -path_delay max -group_path_count 3 -format full_clock_expanded -digits 3 > <P60>/build/pd/block_15ns/timing_setup_gr.rpt
report_checks -path_delay min -group_path_count 1 -digits 3 > <P60>/build/pd/block_15ns/timing_hold_gr.rpt
report_wns > <P60>/build/pd/block_15ns/wns_gr.rpt
report_tns >> <P60>/build/pd/block_15ns/wns_gr.rpt
report_power > <P60>/build/pd/block_15ns/power_gr.rpt
report_clock_skew > <P60>/build/pd/block_15ns/skew_gr.rpt
report_cell_usage
write_db <P60>/build/pd/block_15ns/block_gr.odb
# ---- detailed routing, bounded (the iteration cap keeps the run time predictable; a non-zero DRC count at the end is REPORTED, not hidden)
detailed_route -output_drc <P60>/build/pd/block_15ns/drc.rpt -droute_end_iter 4
estimate_parasitics -global_routing
report_design_area
report_checks -path_delay max -group_path_count 3 -format full_clock_expanded -digits 3 > <P60>/build/pd/block_15ns/timing_setup.rpt
report_checks -path_delay min -group_path_count 1 -digits 3 > <P60>/build/pd/block_15ns/timing_hold.rpt
report_wns > <P60>/build/pd/block_15ns/wns.rpt
report_tns >> <P60>/build/pd/block_15ns/wns.rpt
report_power > <P60>/build/pd/block_15ns/power.rpt
report_clock_skew > <P60>/build/pd/block_15ns/skew.rpt
report_cell_usage
write_db <P60>/build/pd/block_15ns/block.odb
exit
