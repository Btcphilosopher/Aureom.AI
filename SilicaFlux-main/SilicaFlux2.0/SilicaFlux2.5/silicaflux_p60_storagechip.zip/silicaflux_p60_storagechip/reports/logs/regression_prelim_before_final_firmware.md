# Full-chip regression summary

Verilated RTL (silicaflux_storage_top) + real firmware on the RTL CPU + P52 NAND twin. Cycles are simulation cycles.

| run | scenario | seed | checks | failures | cycles | wall s | verdict |
|---|---|---|---|---|---|---|---|
| smoke | smoke | +seed=1 | 32 | 0 | 5095644 | 47 | **PASS** |
| invalid | invalid | +seed=1 | 48 | 0 | 5183874 | 49 | **PASS** |
| top | top | +seed=1 | 61 | 0 | 5391962 | 50 | **PASS** |
| ecc | ecc | +seed=1 | 77 | 0 | 6404843 | 83 | **PASS** |
| concurrency | concurrency | +seed=1 | 94 | 0 | 6869679 | 94 | **PASS** |
| backpressure | backpressure | +seed=1 | 95 | 0 | 6706319 | 91 | **PASS** |
| ctrlreset | ctrlreset | +seed=1 | 800 | 0 | 10952786 | 164 | **PASS** |
| plp | plp | +seed=1 | 800 | 0 | 16095629 | 205 | **PASS** |
| integrity | integrity | +seed=1 | 2278 | 0 | 92784799 | 1186 | **PASS** |
| random_s1 | random | +seed=1 | 2125 | 0 | 56413682 | 623 | **PASS** |
| random_s2 | random | +seed=2 | 2076 | 0 | 57458162 | 676 | **PASS** |
| random_stress | random | +seed=3 | 1788 | 0 | 46513248 | 643 | **PASS** |
| badblock | badblock | +seed=1 | 3173 | 0 | 134236250 | 1487 | **PASS** |
| security_xts | security | +seed=1 | 960 | 2 | 24129536 | 272 | **FAIL** |
| crash_s1 | crash | +seed=1 | 1896 | 0 | 100444830 | 1015 | **PASS** |
| crash_s2 | crash | +seed=2 | 1894 | 0 | 105414228 | 1048 | **PASS** |
| crash_s3 | crash | +seed=3 | 1884 | 0 | 108488670 | 688 | **PASS** |
| crash_xts_s4 | crash | +seed=4 | 1004 | 0 | 59378082 | 377 | **PASS** |

17/18 runs PASS; 21085 checks in total.

* smoke: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* invalid: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* top: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* ecc: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* concurrency: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* backpressure: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* ctrlreset: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 1; acknowledged data lost 0
* plp: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* integrity: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* random_s1: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* random_s2: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* random_stress: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* badblock: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* security_xts: crashes 0 (in-flight commands at cut: 0 total; distribution 0..7: 0 0 0 0 0 0 0 0); unacknowledged cmds that had taken effect 0; acknowledged data lost 0
* crash_s1: crashes 8 (in-flight commands at cut: 12 total; distribution 0..7: 0 5 2 1 0 0 0 0); unacknowledged cmds that had taken effect 9; acknowledged data lost 0
* crash_s2: crashes 8 (in-flight commands at cut: 10 total; distribution 0..7: 0 6 2 0 0 0 0 0); unacknowledged cmds that had taken effect 8; acknowledged data lost 0
* crash_s3: crashes 8 (in-flight commands at cut: 14 total; distribution 0..7: 0 4 2 2 0 0 0 0); unacknowledged cmds that had taken effect 6; acknowledged data lost 0
* crash_xts_s4: crashes 4 (in-flight commands at cut: 10 total; distribution 0..7: 0 0 2 2 0 0 0 0); unacknowledged cmds that had taken effect 4; acknowledged data lost 0
