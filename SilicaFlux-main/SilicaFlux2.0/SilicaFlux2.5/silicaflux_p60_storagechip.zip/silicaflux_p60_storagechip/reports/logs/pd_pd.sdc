create_clock -name clk -period 15 [get_ports clk]
set_input_delay  [expr 15 * 0.3] -clock clk [all_inputs]
set_output_delay [expr 15 * 0.3] -clock clk [all_outputs]
set_false_path -from [get_ports rst_n]
