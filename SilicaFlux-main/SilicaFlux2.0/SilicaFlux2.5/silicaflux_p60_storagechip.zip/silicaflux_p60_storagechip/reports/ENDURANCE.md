# Endurance model results

> **Model output, not a rating.** Host simulation of the production FTL (vendor/p58b) on the NANDLab-rules simulated NAND with wear-dependent
> program/erase failure rates from the twin's *illustrative, uncalibrated* coefficients; rated endurance scaled to 1000 cycles so end of life
> is reachable in seconds. Shapes and ratios are meaningful; absolute cycle counts are not. A NAND simulator cannot certify a drive endurance rating;
> JESD218/JESD219 were **not accessible** here and the JESD219-style workload is reproduced from memory of its published shape (LBA-zone skew, transfer-size mix).

## Runs (device: 256 blocks × 64 pages × 512 B, BCH t = 8, 2 % factory-bad)

| run | workload | OP ‰ | WL | WA | mean P/E at end | P/E min–max | grown-bad | drive-writes | end of life | NAND rule violations |
|---|---|---|---|---|---|---|---|---|---|---|
| ablate_hotcold_wldyn | hotcold | 70 | dynamic | 7.78 | 488 | 247–537 | 21 | 72 | spare exhausted (ENOSPC) | 0 |
| ablate_hotcold_wlnone | hotcold | 70 | none | 7.80 | 489 | 1–632 | 21 | 72 | spare exhausted (ENOSPC) | 0 |
| ablate_hotcold_wlstatic | hotcold | 70 | dyn+static | 7.88 | 480 | 274–519 | 20 | 70 | spare exhausted (ENOSPC) | 0 |
| hotcold_op150 | hotcold | 150 | dyn+static | 4.35 | 579 | 259–615 | 41 | 164 | spare exhausted (ENOSPC) | 0 |
| hotcold_op280 | hotcold | 280 | dyn+static | 2.64 | 686 | 278–733 | 70 | 370 | spare exhausted (ENOSPC) | 0 |
| hotcold_op70 | hotcold | 70 | dyn+static | 7.88 | 480 | 274–519 | 20 | 70 | spare exhausted (ENOSPC) | 0 |
| jesd219_op150 | jesd219 | 150 | dyn+static | 3.09 | 564 | 255–602 | 39 | 227 | spare exhausted (ENOSPC) | 0 |
| jesd219_op280 | jesd219 | 280 | dyn+static | 2.11 | 709 | 120–749 | 73 | 471 | spare exhausted (ENOSPC) | 0 |
| jesd219_op70 | jesd219 | 70 | dyn+static | 5.20 | 502 | 264–544 | 21 | 111 | spare exhausted (ENOSPC) | 0 |
| seq_op150 | seq | 150 | dyn+static | 1.04 | 585 | 268–662 | 41 | 695 | spare exhausted (ENOSPC) | 0 |
| seq_op280 | seq | 280 | dyn+static | 1.03 | 706 | 269–853 | 70 | 975 | spare exhausted (ENOSPC) | 0 |
| seq_op70 | seq | 70 | dyn+static | 1.06 | 509 | 267–715 | 21 | 549 | spare exhausted (ENOSPC) | 0 |
| uniform_op150 | uniform | 150 | dyn+static | 3.90 | 576 | 268–596 | 39 | 183 | spare exhausted (ENOSPC) | 0 |
| uniform_op280 | uniform | 280 | dyn+static | 2.37 | 704 | 239–737 | 71 | 418 | spare exhausted (ENOSPC) | 0 |
| uniform_op70 | uniform | 70 | dyn+static | 7.26 | 504 | 156–521 | 23 | 79 | spare exhausted (ENOSPC) | 0 |

Reading: write amplification falls steeply with over-provisioning (uniform random 7/15/28 %: see rows) and end of life arrives when the grown-bad blocks exhaust the spare pool
(factory-bad + over-provisioning), the FTL then returns `ENOSPC`; `NAND rule violations` must be 0 (the FTL never breaks NAND programming rules).

## Wear levelling ablation (hot/cold 90/10, 7 % OP)

| policy | P/E min–max | spread | WA | grown-bad |
|---|---|---|---|---|
| dynamic | 247–537 | 290 | 7.78 | 21 |
| none | 1–632 | 631 | 7.80 | 21 |
| dyn+static | 274–519 | 245 | 7.88 | 20 |

## ECC consequence of wear (analytic; BCH t = 8 over a 4 344-bit codeword)

RBER(c, hours) = fresh + wear·c² + retention_ref·(hours/ref_h)·(1 + 50c), c = P/E ÷ rated (twin formulas). The `stress` profile is the twin's deliberately harsh one.

### profile `nominal`

| P/E ÷ rated | retention | RBER | mean bit errors / codeword | P(codeword uncorrectable) |
|---|---|---|---|---|
| 0.00 | 0 | 1.00e-10 | 4.34e-07 | 1.51e-63 |
| 0.00 | 1 y | 1.01e-08 | 4.39e-05 | 1.65e-45 |
| 0.10 | 0 | 1.10e-09 | 4.78e-06 | 3.55e-54 |
| 0.10 | 1 y | 6.11e-08 | 0.000265 | 1.79e-38 |
| 0.25 | 0 | 6.35e-09 | 2.76e-05 | 2.53e-47 |
| 0.25 | 1 y | 1.41e-07 | 0.000614 | 3.39e-35 |
| 0.50 | 0 | 2.51e-08 | 0.000109 | 5.95e-42 |
| 0.50 | 1 y | 2.85e-07 | 0.00124 | 1.87e-32 |
| 0.75 | 0 | 5.63e-08 | 0.000245 | 8.62e-39 |
| 0.75 | 1 y | 4.41e-07 | 0.00192 | 9.55e-31 |
| 1.00 | 0 | 1.00e-07 | 0.000435 | 1.52e-36 |
| 1.00 | 1 y | 6.10e-07 | 0.00265 | 1.76e-29 |
| 1.50 | 0 | 2.25e-07 | 0.000978 | 2.23e-33 |
| 1.50 | 1 y | 9.85e-07 | 0.00428 | 1.31e-27 |
| 2.00 | 0 | 4.00e-07 | 0.00174 | 3.95e-31 |
| 2.00 | 1 y | 1.41e-06 | 0.00613 | 3.30e-26 |
| 3.00 | 0 | 9.00e-07 | 0.00391 | 5.82e-28 |
| 3.00 | 1 y | 2.41e-06 | 0.0105 | 4.09e-24 |

### profile `stress`

| P/E ÷ rated | retention | RBER | mean bit errors / codeword | P(codeword uncorrectable) |
|---|---|---|---|---|
| 0.00 | 0 | 2.00e-05 | 0.0869 | 7.13e-16 |
| 0.00 | 1 y | 8.78e-03 | 38.1 | 1.00e+00 |
| 0.10 | 0 | 4.00e-05 | 0.174 | 3.38e-13 |
| 0.10 | 1 y | 5.26e-02 | 228 | 1.00e+00 |
| 0.25 | 0 | 1.45e-04 | 0.63 | 2.43e-08 |
| 0.25 | 1 y | 1.18e-01 | 514 | 1.00e+00 |
| 0.50 | 0 | 5.20e-04 | 2.26 | 5.63e-04 |
| 0.50 | 1 y | 2.28e-01 | 992 | 1.00e+00 |
| 0.75 | 0 | 1.15e-03 | 4.97 | 6.63e-02 |
| 0.75 | 1 y | 3.38e-01 | 1.47e+03 | 1.00e+00 |
| 1.00 | 0 | 2.02e-03 | 8.77 | 5.14e-01 |
| 1.00 | 1 y | 4.49e-01 | 1.95e+03 | 1.00e+00 |
| 1.50 | 0 | 4.52e-03 | 19.6 | 9.97e-01 |
| 1.50 | 1 y | 5.00e-01 (clamped) | 2.17e+03 | 1.00e+00 |
| 2.00 | 0 | 8.02e-03 | 34.8 | 1.00e+00 |
| 2.00 | 1 y | 5.00e-01 (clamped) | 2.17e+03 | 1.00e+00 |
| 3.00 | 0 | 1.80e-02 | 78.3 | 1.00e+00 |
| 3.00 | 1 y | 5.00e-01 (clamped) | 2.17e+03 | 1.00e+00 |

Observation: under the `nominal` profile t = 8 is overwhelmingly sufficient to the rated life; under `stress` the codeword failure probability becomes significant
near rated endurance with one year of retention, which is where read-retry, scrubbing/refresh (`refresh_bitflips` in the FTL) and a stronger code are needed.
None of this is calibrated; `t` must be re-derived from real device characterisation.
