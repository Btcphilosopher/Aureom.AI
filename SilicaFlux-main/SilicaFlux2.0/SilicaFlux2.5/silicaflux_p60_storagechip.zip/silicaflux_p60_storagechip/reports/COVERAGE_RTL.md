# RTL line coverage (Verilator `--coverage-line`, merged over the coverage scenario set in `scripts/run_cov.sh`; per-run results in `reports/logs/coverage_runs.txt`)

Line coverage of the Verilated full-chip testbench. **Not functional coverage; not signoff.** Lines = coverage points (statements/branches) per source line;
covered = every point on the line hit, partial = some points hit. Uncovered ranges are listed so that they can be reviewed (some are unreachable by construction: error branches for conditions the testbench cannot create, test-mode paths, vendor features P60 does not use).

**Overall: 1546/2303 lines fully covered (67.1 %)** over the 71 files below.

| file | lines | covered | partial | uncovered | covered % |
|---|---|---|---|---|---|
| `rtl/security/sfx_aes_core.sv` | 22 | 22 | 0 | 0 | 100 |
| `rtl/security/sfx_aes_keyexp.sv` | 6 | 6 | 0 | 0 | 100 |
| `rtl/security/sfx_aes_xts.sv` | 29 | 28 | 0 | 1 | 97 |
| `rtl/soc/sfs_storage_subsys.sv` | 13 | 11 | 0 | 2 | 85 |
| `rtl/storage/sfx_page_engine.sv` | 86 | 73 | 10 | 3 | 85 |
| `rtl/top/sfx_hb_split.sv` | 13 | 10 | 2 | 1 | 77 |
| `rtl/top/sfx_pwr_cond.sv` | 4 | 4 | 0 | 0 | 100 |
| `rtl/top/sfx_rst_sync.sv` | 2 | 2 | 0 | 0 | 100 |
| `rtl/top/sfx_top_ctrl.sv` | 42 | 31 | 2 | 9 | 74 |
| `vendor/p07_testcore/rtl/sftc_consts.svh` | 47 | 0 | 6 | 41 | 0 |
| `vendor/p07_testcore/rtl/sftc_jtag_reg_bridge.sv` | 21 | 6 | 6 | 9 | 29 |
| `vendor/p07_testcore/rtl/sftc_jtag_tap.sv` | 23 | 10 | 6 | 7 | 43 |
| `vendor/p07_testcore/rtl/sftc_mbist_addr_gen.sv` | 8 | 4 | 3 | 1 | 50 |
| `vendor/p07_testcore/rtl/sftc_mbist_bank_mux.sv` | 9 | 7 | 1 | 1 | 78 |
| `vendor/p07_testcore/rtl/sftc_mbist_fail_log.sv` | 23 | 9 | 9 | 5 | 39 |
| `vendor/p07_testcore/rtl/sftc_mbist_pattern.sv` | 8 | 5 | 1 | 2 | 62 |
| `vendor/p07_testcore/rtl/sftc_regs.sv` | 67 | 19 | 5 | 43 | 28 |
| `vendor/p07_testcore/rtl/sftc_sync.sv` | 2 | 2 | 0 | 0 | 100 |
| `vendor/p07_testcore/rtl/sftc_testcore_top.sv` | 13 | 11 | 2 | 0 | 85 |
| `vendor/p07_testcore/rtl/silicaflux_mbist.sv` | 49 | 9 | 13 | 27 | 18 |
| `vendor/p07_testcore/rtl/silicaflux_test_mode_controller.sv` | 37 | 7 | 5 | 25 | 19 |
| `vendor/p51/rtl/sfs_cmd_ctrl.sv` | 68 | 59 | 4 | 5 | 87 |
| `vendor/p51/rtl/sfs_dma.sv` | 44 | 33 | 6 | 5 | 75 |
| `vendor/p51/rtl/sfs_fifo.sv` | 11 | 10 | 1 | 0 | 91 |
| `vendor/p51/rtl/sfs_host_if.sv` | 69 | 51 | 9 | 9 | 74 |
| `vendor/p51/rtl/sfs_nand_ctrl.sv` | 136 | 113 | 12 | 11 | 83 |
| `vendor/p51/rtl/sfs_sfb_gate.sv` | 6 | 6 | 0 | 0 | 100 |
| `vendor/p51/rtl/sfs_sys_regs.sv` | 83 | 63 | 9 | 11 | 76 |
| `vendor/p51/third_party/silicaflux-controlcore/rtl/cc_mailbox.sv` | 25 | 21 | 2 | 2 | 84 |
| `vendor/p51/third_party/silicaflux-controlcore/rtl/cc_perf.sv` | 16 | 12 | 2 | 2 | 75 |
| `vendor/p51/third_party/silicaflux-controlcore/rtl/cc_pmu.sv` | 13 | 11 | 2 | 0 | 85 |
| `vendor/p51/third_party/silicaflux-controlcore/rtl/cc_ras.sv` | 44 | 36 | 2 | 6 | 82 |
| `vendor/p51/third_party/silicaflux-controlcore/rtl/cc_secmon.sv` | 17 | 14 | 2 | 1 | 82 |
| `vendor/p51/third_party/silicaflux-controlcore/rtl/cc_sfb_gate.sv` | 6 | 4 | 1 | 1 | 67 |
| `vendor/p51/third_party/silicaflux-controlcore/rtl/cc_sysctrl.sv` | 42 | 35 | 6 | 1 | 83 |
| `vendor/p51/third_party/silicaflux-controlcore/rtl/generated/sfv_bootrom_image.sv` | 519 | 343 | 0 | 176 | 66 |
| `vendor/p51/third_party/silicaflux-controlcore/rtl/silicaflux_control_core.sv` | 11 | 11 | 0 | 0 | 100 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-datafabric/rtl/interconnect/sfb_addr_decoder.sv` | 5 | 2 | 3 | 0 | 40 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-datafabric/rtl/interconnect/sfb_arbiter.sv` | 11 | 3 | 8 | 0 | 27 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-datafabric/rtl/interconnect/sfb_crossbar.sv` | 16 | 14 | 2 | 0 | 88 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-datafabric/rtl/interconnect/sfb_error_slave.sv` | 2 | 2 | 0 | 0 | 100 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-datafabric/rtl/interconnect/sfb_req_mux.sv` | 2 | 2 | 0 | 0 | 100 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-datafabric/rtl/interconnect/sfb_rsp_router.sv` | 5 | 5 | 0 | 0 | 100 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-datafabric/rtl/interconnect/sfb_skid_buffer.sv` | 8 | 4 | 3 | 1 | 50 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-datafabric/rtl/interconnect/sfb_v1_slave_adapter.sv` | 7 | 3 | 2 | 2 | 43 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-mcu-i/rtl/cpu/mcu_cpu.sv` | 131 | 103 | 5 | 23 | 79 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-mcu-i/rtl/dma/mcu_dma.sv` | 68 | 28 | 6 | 34 | 41 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-mcu-i/rtl/interrupts/mcu_intc.sv` | 24 | 23 | 0 | 1 | 96 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-mcu-i/rtl/mem/mcu_sram_bank.sv` | 12 | 9 | 3 | 0 | 75 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-mcu-i/rtl/watchdog/mcu_wdt.sv` | 27 | 20 | 6 | 1 | 74 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1rw.sv` | 22 | 14 | 4 | 4 | 64 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-sramlib/rtl/mem/sram_rsp_path.sv` | 14 | 8 | 3 | 3 | 57 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-sramlib/rtl/mem/sram_sp.sv` | 4 | 3 | 1 | 0 | 75 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-v/rtl/bus/sfv_periph_bridge.sv` | 4 | 4 | 0 | 0 | 100 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-v/rtl/common/sfv_clkgate.sv` | 2 | 2 | 0 | 0 | 100 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-v/rtl/common/sfv_common.sv` | 4 | 4 | 0 | 0 | 100 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-v/rtl/mem/sfv_mem_slaves.sv` | 3 | 3 | 0 | 0 | 100 |
| `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-v/rtl/periph/sfv_periph_misc.sv` | 19 | 14 | 1 | 4 | 74 |
| `vendor/p51/third_party/silicaflux-ras/rtl/sfras_ecc_funcs.svh` | 18 | 0 | 0 | 18 | 0 |
| `vendor/p51/third_party/silicaflux-ras/rtl/sfras_ecc_sram.sv` | 85 | 42 | 11 | 32 | 49 |
| `vendor/p51/third_party/silicaflux-ras/rtl/sfras_secded_dec.sv` | 2 | 1 | 1 | 0 | 50 |
| `vendor/p54/rtl/sfecc_bch_chien.sv` | 22 | 22 | 0 | 0 | 100 |
| `vendor/p54/rtl/sfecc_bch_dec.sv` | 11 | 9 | 0 | 2 | 82 |
| `vendor/p54/rtl/sfecc_bch_enc.sv` | 16 | 10 | 2 | 4 | 62 |
| `vendor/p54/rtl/sfecc_bch_kes.sv` | 20 | 15 | 1 | 4 | 75 |
| `vendor/p54/rtl/sfecc_bch_syn.sv` | 2 | 2 | 0 | 0 | 100 |
| `vendor/p54/rtl/sfecc_crc16.svh` | 2 | 2 | 0 | 0 | 100 |
| `vendor/p54/rtl/sfecc_gf_funcs.svh` | 16 | 0 | 3 | 13 | 0 |
| `vendor/p54/rtl/sfecc_page_dec.sv` | 27 | 23 | 4 | 0 | 85 |
| `vendor/p54/rtl/sfecc_page_enc.sv` | 19 | 18 | 1 | 0 | 95 |
| `vendor/p54/rtl/silicaflux_storage_ecc.sv` | 39 | 34 | 5 | 0 | 87 |

## Uncovered line ranges (files below 100 %)

* `rtl/security/sfx_aes_xts.sv`: 218
* `rtl/soc/sfs_storage_subsys.sv`: 177, 181
* `rtl/storage/sfx_page_engine.sv`: 296, 312, 436
* `rtl/top/sfx_hb_split.sv`: 84
* `rtl/top/sfx_top_ctrl.sv`: 116, 119, 145-146, 148, 153, 155-157
* `vendor/p07_testcore/rtl/sftc_consts.svh`: 66-71, 73, 75-78, 80-83, 85-88, 90-92, 94-96, 98, 176-190
* `vendor/p07_testcore/rtl/sftc_jtag_reg_bridge.sv`: 95-97, 110-113, 140-141
* `vendor/p07_testcore/rtl/sftc_jtag_tap.sv`: 48-49, 60, 74, 88, 90-91
* `vendor/p07_testcore/rtl/sftc_mbist_addr_gen.sv`: 33
* `vendor/p07_testcore/rtl/sftc_mbist_bank_mux.sv`: 100
* `vendor/p07_testcore/rtl/sftc_mbist_fail_log.sv`: 55, 66-67, 86, 99
* `vendor/p07_testcore/rtl/sftc_mbist_pattern.sv`: 68, 73
* `vendor/p07_testcore/rtl/sftc_regs.sv`: 139, 141-143, 145-149, 151, 156-177, 216-219, 226, 228-233
* `vendor/p07_testcore/rtl/silicaflux_mbist.sv`: 231, 234, 257, 264, 292-293, 295, 303, 307, 309-310, 317-318, 321, 325-326, 328, 331, 333, 335, 338, 340, 350, 358, 368-369, 371
* `vendor/p07_testcore/rtl/silicaflux_test_mode_controller.sv`: 83-86, 88-93, 95-98, 100-104, 106, 118, 122, 125-126, 130
* `vendor/p51/rtl/sfs_cmd_ctrl.sv`: 109, 112, 305-307
* `vendor/p51/rtl/sfs_dma.sv`: 123, 158, 174-176
* `vendor/p51/rtl/sfs_host_if.sv`: 152-155, 157, 163, 166-168
* `vendor/p51/rtl/sfs_nand_ctrl.sv`: 211, 325, 390, 405, 462, 464, 466, 468-469, 476, 516
* `vendor/p51/rtl/sfs_sys_regs.sv`: 222, 227-229, 231, 236, 281, 283, 305-307
* `vendor/p51/third_party/silicaflux-controlcore/rtl/cc_mailbox.sv`: 107-108
* `vendor/p51/third_party/silicaflux-controlcore/rtl/cc_perf.sv`: 51, 53
* `vendor/p51/third_party/silicaflux-controlcore/rtl/cc_ras.sv`: 107-111, 172
* `vendor/p51/third_party/silicaflux-controlcore/rtl/cc_secmon.sv`: 53
* `vendor/p51/third_party/silicaflux-controlcore/rtl/cc_sfb_gate.sv`: 79
* `vendor/p51/third_party/silicaflux-controlcore/rtl/cc_sysctrl.sv`: 78
* `vendor/p51/third_party/silicaflux-controlcore/rtl/generated/sfv_bootrom_image.sv`: 29-36, 60-85, 97-118, 211-242, 290-291, 309-315, 324-347, 372-391, 404, 479-487, 492-499, 505-507, 513-526
* `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-datafabric/rtl/interconnect/sfb_skid_buffer.sv`: 39
* `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-datafabric/rtl/interconnect/sfb_v1_slave_adapter.sv`: 59-60
* `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-mcu-i/rtl/cpu/mcu_cpu.sv`: 372, 380, 383, 385-389, 435, 439, 441, 443, 520, 623, 627, 629, 633-638, 756
* `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-mcu-i/rtl/dma/mcu_dma.sv`: 115-118, 140-145, 147-149, 185-186, 188, 190, 197-198, 200, 205-207, 209, 216-218, 223-225, 227, 229, 239-240
* `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-mcu-i/rtl/interrupts/mcu_intc.sv`: 68
* `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-mcu-i/rtl/watchdog/mcu_wdt.sv`: 84
* `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1rw.sv`: 101-104
* `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-sramlib/rtl/mem/sram_rsp_path.sv`: 82, 90, 137
* `vendor/p51/third_party/silicaflux-controlcore/third_party/silicaflux-v/rtl/periph/sfv_periph_misc.sv`: 101-102, 105, 107
* `vendor/p51/third_party/silicaflux-ras/rtl/sfras_ecc_funcs.svh`: 36, 40-41, 46, 50-51, 57, 61-62, 68, 72, 78, 82, 92, 111, 119-120, 124
* `vendor/p51/third_party/silicaflux-ras/rtl/sfras_ecc_sram.sv`: 333, 371, 374, 378, 380, 382, 387-388, 390, 393, 420, 423, 447-448, 456, 459, 463, 465, 482, 484, 527, 537, 549, 565, 596, 602, 604, 635-639
* `vendor/p54/rtl/sfecc_bch_dec.sv`: 75, 79
* `vendor/p54/rtl/sfecc_bch_enc.sv`: 55, 59, 62, 64
* `vendor/p54/rtl/sfecc_bch_kes.sv`: 56, 60, 64, 68
* `vendor/p54/rtl/sfecc_gf_funcs.svh`: 45, 50-51, 53, 60, 64, 67-68, 78, 82-85
