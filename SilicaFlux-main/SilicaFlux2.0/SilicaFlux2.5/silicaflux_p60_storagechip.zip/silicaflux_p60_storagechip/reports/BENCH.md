# Benchmarks (RTL simulation)

> **Simulation data.** Cycles from the Verilated full chip (RTL ControlCore running the real firmware, P52 NAND twin with array times scaled ×1/10 for speed), converted at an **assumed 100 MHz** clock.
> Latency is the hardware command-latency monitor (accept → completion post). No wall-clock or hardware number is claimed. One NAND channel; the 512-B logical block means "MB/s" figures are small-block numbers.

| workload | QD | blocks/cmd | cmds | MB/s | IOPS | p50 µs | p95 | p99 | p99.9 | max |
|---|---|---|---|---|---|---|---|---|---|---|
| seq_read_8 | 1 | 8 | 40 | 2.723 | 665 | 1504 | 1511 | 1513 | 1513 | 1513 |
| rand_read_1 | 1 | 1 | 120 | 2.688 | 5250 | 190 | 191 | 192 | 192 | 192 |
| rand_read_1 | 2 | 1 | 120 | 2.709 | 5291 | 378 | 380 | 380 | 380 | 380 |
| rand_read_1 | 4 | 1 | 120 | 2.710 | 5294 | 755 | 760 | 760 | 760 | 760 |
| rand_read_1 | 8 | 1 | 120 | 2.708 | 5289 | 1510 | 1520 | 1521 | 1522 | 1522 |
| seq_write_8 | 1 | 8 | 40 | 2.209 | 539 | 1690 | 1910 | 4694 | 4694 | 4694 |
| rand_write_1 | 1 | 1 | 120 | 0.947 | 1851 | 213 | 1445 | 1458 | 4263 | 4263 |
| rand_write_1 | 4 | 1 | 120 | 0.397 | 774 | 5207 | 7270 | 8221 | 8222 | 8222 |
| rand_write_1 | 8 | 1 | 120 | 0.408 | 796 | 10090 | 13438 | 13447 | 13447 | 13447 |
| mixed_70r30w_1 | 4 | 1 | 160 | 1.048 | 2047 | 1807 | 3945 | 5930 | 5933 | 5933 |
| rand_write_1_after_trim | 1 | 1 | 120 | 2.176 | 4251 | 213 | 428 | 808 | 828 | 828 |
| rand_write_1_steady_gc | 1 | 1 | 400 | 1.390 | 2714 | 213 | 762 | 775 | 3623 | 3623 |

Percentiles use between 40 and 400 samples per phase: **P99/P99.9 are therefore coarse (essentially the maximum)**.

## Counters over the whole run

* write amplification (NAND programs ÷ host LBAs written) = **1.57** (host 2004, GC relocation 1038, metadata 110); erases data/metadata 195/12; GC victims 110
* ECC: corrected bits 0, uncorrectable 0 (no errors injected in this scenario)
* firmware HAL cycles: read 22143554, program 37766478, erase 4196368; of which page engine (BCH+XTS) 6320985, buffer copies 7948284 over 2099 reads / 3152 programs / 207 erases
* NAND channel utilisation (R/B# low cycles ÷ cycles) = **10.3 %**; chip counters: NAND ops 5599, host-memory read/write beats 256512/119296

## Power-loss recovery overhead

* clean shutdown (checkpoint): 303114 cycles = 3031 µs
* firmware start → host ready after a clean shutdown (fast mount): 1928332 cycles = 19.28 ms
* firmware start → host ready after a power cut (unclean: scan + roll-forward): 3555422 cycles = 35.55 ms

## Reading the numbers (honest notes)

* **Queue depth buys latency, not throughput.** The firmware is a *synchronous* command executor on one NAND channel: it completes one command before starting the next. Read IOPS is flat from QD1 to QD8 (≈ 5.3 k) while latency grows linearly with QD (190 → 1 510 µs): commands wait in the submission queue. The QD sweep therefore shows queueing, not parallelism; real QD scaling needs a firmware with overlapped NAND operations and several channels (not built).
* **Write phases are not directly comparable.** They run in a fixed order on one device; later phases start with the device in a different garbage-collection state (the device is filled once, then overwritten), so the lower QD4/QD8 random-write throughput mostly reflects GC in progress, not queue depth. `rand_write_1_after_trim` vs `rand_write_1_steady_gc` shows the GC effect directly: free space (after TRIM of half the namespace) gives about 1.6× the steady-state throughput.
* **Small blocks, one channel, scaled NAND times**: 512-B logical blocks and a x8 SDR channel at the twin's timing; MB/s figures are tiny in absolute terms and are only meaningful relative to each other.
* **Where the time goes** (firmware-observed cycles over the whole run): NAND program/read/erase waits dominate; the BCH page engine accounts for ≈ 1204 cycles per page operation (encode or decode, as seen by the polling firmware, XTS off); buffer-slot copies by the CPU are a comparable cost to the ECC (a DMA-based copy would remove it).

## Not measurable on this build

* **NAND channel scaling**: the MIN firmware/HAL drive one channel only; multi-channel scaling can only be discussed analytically (it was not built or measured).
* **Buffer occupancy**: the firmware uses a fixed 3 of 30 buffer slots (S, R, host staging); the SECDED SRAM is not otherwise exercised, so occupancy is static, not a workload metric.
* **ECC latency vs error count**: the benchmark injects no errors (`ecc_corr_bits = 0`); latency with errors is covered by the P54 page testbench (`vendor/p54`) and by the `ecc` scenario for correctness only.
