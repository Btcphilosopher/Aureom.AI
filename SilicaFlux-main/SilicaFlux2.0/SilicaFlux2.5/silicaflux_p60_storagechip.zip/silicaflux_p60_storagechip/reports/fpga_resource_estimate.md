# FPGA resource ESTIMATE (Yosys, pre-place-and-route)

> **Estimate only.** Output of `yosys synth_xilinx -family xc7 -flatten` and `synth_ecp5` (Yosys 0.33) on the *whole* `silicaflux_storage_top`
> (ControlCore + StorageCore subsystem + page engine / BCH t=8 / XTS-AES-256 + top control + TestCore), reproduced with
> `python3 scripts/synth.py --fpga xilinx|ecp5` (raw statistics: `fpga_synth_xilinx7_stat.txt`, `fpga_synth_ecp5_stat.txt`).
> It excludes the FPGA wrapper (`fpga/rtl/`: UART bridge + host-memory BRAM), uses the generic SRAM backend (Yosys infers the RAMs as block RAM),
> and says **nothing about timing**: no place-and-route, no static timing, no bitstream, no board. **No FPGA result of any kind exists for this project.**

## Xilinx 7-series mapping (LUT6)

| resource | count | notes |
|---|---|---|
| LUT (LUT1..LUT6) | 27 517 | LUT2 8 029 · LUT3 3 034 · LUT4 2 281 · LUT5 3 309 · LUT6 10 732 · LUT1 132 |
| distributed RAM | 445 × RAM32M + 12 × RAM64M | ≈ 1 830 additional LUTs (4 per primitive) |
| **LUT total (approx.)** | **≈ 29 300** | |
| flip-flops | 14 759 | FDCE 9 353 · FDRE 5 193 · FDPE 206 · FDCE_1 7 |
| block RAM | 29 × RAMB36E1 + 1 × RAMB18E1 | ≈ 29.5 RAMB36 (IMEM 64 KiB, DMEM 32 KiB, buffer SRAM, ECC/page-engine FIFOs) |
| carry / wide muxes | 1 405 CARRY4 · 1 113 MUXF7 · 211 MUXF8 | |
| DSP48 | 0 | |
| I/O buffers | 129 IBUF · 157 OBUF | top-level ports (not all would be pinned out on a board) |

Fraction of example parts (by count only): XC7A100T (63 400 LUT, 135 RAMB36) ≈ 46 % LUT, ≈ 22 % RAMB36; XC7K325T (203 800 LUT, 445 RAMB36) ≈ 14 % LUT, ≈ 7 % RAMB36.

## Lattice ECP5 mapping (LUT4)

| resource | count |
|---|---|
| LUT4 | 42 290 |
| CCU2C (carry; 2 LUT4 each) | 3 004 (≈ 6 000 LUT4 equivalents) |
| TRELLIS_DPR16X4 (distributed RAM) | 836 |
| TRELLIS_FF | 14 840 |
| DP16KD (18 kbit EBR) | 59 |
| PFUMX / L6MUX21 | 8 567 / 2 352 (slice-internal muxes) |

LUT4-equivalent total ≈ 49 000 – 55 000 (LUT4 + carry + distributed-RAM slices), i.e. roughly **60 – 65 % of an ECP5-85F (83 640 LUT4, 208 EBR)** by count.
An earlier statement in this project that "the full SoC does not fit an ECP5-85F" is **not supported by this estimate** and has been removed; whether it closes
timing on an ECP5 (the P51 audit measured 66 – 85 MHz for a smaller design) is unknown and would need place-and-route.

## Caveats
* Yosys pre-P&R counts are typically within ±20 % of the post-implementation numbers; nothing here is a vendor-tool result.
* The flop count includes the generic-SRAM-backed parity/ECC structures as inferred by Yosys; a macro/BRAM-specific backend (`SRAM_BACKEND=1`, `fpga/`) changes the split between LUT-RAM and BRAM.
* The page engine (BCH t=8 decoder with Chien search, XTS-AES-256 with a 14-round iterative core) is the largest P60-specific addition; a per-module breakdown was not produced for this release.
* Power, clocking (single clock, the PLL/MMCM is board-specific) and the NAND I/O timing against a real device are untouched.
