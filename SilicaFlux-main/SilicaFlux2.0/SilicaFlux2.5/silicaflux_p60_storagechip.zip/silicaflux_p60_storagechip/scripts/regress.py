#!/usr/bin/env python3
"""
regress.py -- run the full-chip scenario matrix (Verilated testbench, real firmware on the RTL CPU) in parallel and write
reports/regression_summary.md.  Every run is deterministic for a given (scenario, seed, config).

usage: regress.py [--jobs 3] [--quick] [--only name,name] [--out reports]
Needs build/tb/v/Vtb (scripts/build_tb.sh) and fw/build/*.hex (make -C fw).
"""
import argparse, concurrent.futures as cf, hashlib, os, re, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

VTB = os.environ.get("VTB") or next((p for p in (os.path.join(ROOT, "build", d, "v", "Vtb") for d in ("tb_fin", "tb")) if os.path.exists(p)), "")
def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()[:12] if os.path.exists(p) else "n/a"
# name, scenario, env, extra plusargs, nand cfg
MATRIX = [
    ("smoke",               "smoke",        {}, [], ""),
    ("invalid",             "invalid",      {}, [], ""),
    ("top",                 "top",          {}, [], ""),
    ("ecc",                 "ecc",          {}, [], ""),
    ("concurrency",         "concurrency",  {}, [], ""),
    ("backpressure",        "backpressure", {}, [], ""),
    ("ctrlreset",           "ctrlreset",    {}, [], ""),
    ("plp",                 "plp",          {}, [], ""),
    ("integrity",           "integrity",    {}, ["+nops=300"], ""),
    ("random_s1",           "random",       {}, ["+seed=1", "+nops=400"], ""),
    ("random_s2",           "random",       {}, ["+seed=2", "+nops=400"], ""),
    ("random_stress",       "random",       {"PROFILE": "stress"}, ["+seed=3", "+nops=300"], ""),
    ("badblock",            "badblock",     {"NANDARGS": "--bad 13,41 --force-prog-fail 25:3 --force-erase-fail 30"}, ["+badcfg=1", "+nops=400"], ""),
    ("security_xts",        "security",     {"XTS": "1"}, [], ""),
    ("noformat",            "noformat",     {}, [], ""),
    ("crash_s1",            "crash",        {}, ["+seed=1", "+ncrash=8"], ""),
    ("crash_s2",            "crash",        {}, ["+seed=2", "+ncrash=8"], ""),
    ("crash_s3",            "crash",        {}, ["+seed=3", "+ncrash=8"], ""),
    ("crash_xts_s4",        "crash",        {"XTS": "1"}, ["+seed=4", "+ncrash=4"], ""),
]
QUICK = {"smoke", "invalid", "top", "ecc", "concurrency", "plp", "ctrlreset", "noformat"}

def run(item):
    name, sc, env, args, _ = item
    t0 = time.time()
    e = dict(os.environ); e.update(env); e.setdefault("VTB", VTB)
    r = subprocess.run([os.path.join(ROOT, "scripts/run_tb.sh"), sc, name] + args + ["+timeout=3000000000"], capture_output=True, text=True, env=e)
    log = os.path.join(ROOT, "build/run", name, "run.log")
    txt = open(log).read() if os.path.exists(log) else r.stdout + r.stderr
    m = re.search(r"^tb_p60_soc \S+: (\d+) checks, (\d+) failures, (\d+) cycles -> (PASS|FAIL)", txt, re.M)
    cov = [l for l in txt.splitlines() if l.startswith("TB COV: crashes")]
    return dict(name=name, scenario=sc, seed=next((a for a in args if a.startswith("+seed")), "+seed=1"), checks=int(m.group(1)) if m else 0,
                failures=int(m.group(2)) if m else -1, cycles=int(m.group(3)) if m else 0, verdict=m.group(4) if m else "NO RESULT",
                wall=time.time() - t0, cov=cov[0] if cov else "")

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--jobs", type=int, default=3); ap.add_argument("--quick", action="store_true")
    ap.add_argument("--only", default=""); ap.add_argument("--out", default=os.path.join(ROOT, "reports"))
    a = ap.parse_args()
    items = [m for m in MATRIX if (not a.quick or m[0] in QUICK) and (not a.only or m[0] in a.only.split(","))]
    os.makedirs(a.out, exist_ok=True)
    with cf.ThreadPoolExecutor(a.jobs) as ex: res = list(ex.map(run, items))
    L = ["# Full-chip regression summary", "", "Verilated RTL (silicaflux_storage_top) + real firmware on the RTL CPU + P52 NAND twin. Cycles are simulation cycles.", "",
         f"Binaries: testbench `{os.path.relpath(VTB, ROOT)}` (sha256 {sha(VTB)}…), firmware `p60_fw.hex` (sha256 {sha(os.path.join(ROOT, 'fw/build/p60_fw.hex'))}…), `p60_fw_xts.hex` (sha256 {sha(os.path.join(ROOT, 'fw/build/p60_fw_xts.hex'))}…). Run: {time.strftime('%Y-%m-%d %H:%M UTC', time.gmtime())}.", "",
         "| run | scenario | seed | checks | failures | cycles | wall s | verdict |", "|---|---|---|---|---|---|---|---|"]
    for r in res: L.append(f"| {r['name']} | {r['scenario']} | {r['seed']} | {r['checks']} | {r['failures']} | {r['cycles']} | {r['wall']:.0f} | **{r['verdict']}** |")
    L += ["", f"{sum(r['verdict'] == 'PASS' for r in res)}/{len(res)} runs PASS; {sum(r['checks'] for r in res)} checks in total.", ""]
    for r in res:
        if r["cov"]: L.append(f"* {r['name']}: {r['cov'][len('TB COV: '):]}")
    open(os.path.join(a.out, "regression_summary.md"), "w").write("\n".join(L) + "\n")
    print("\n".join(L))
    sys.exit(0 if all(r["verdict"] == "PASS" for r in res) else 1)
main()
