#!/usr/bin/env python3
"""
gen_nand_cfg.py -- write the P52 NAND digital-twin run configuration (nandlab.svcfg) for the P60 testbench.

Geometry (fixed by the SoC build): 1 channel x 1 target x 1 LUN, 2 planes x 32 blocks = 64 blocks, 16 pages/block,
512 B data + 32 B spare (BCH slot: BBM 1 + FTL record 16 + CRC-16 2 + parity 13).  Timing mode 0 (the real power-on default; the controller runs mode-0 timings), array times
divided by --time-scale (simulation economy; the scale is reported by every run).  Reliability profile: the twin's
own `ideal` (no random errors; errors are injected deterministically), `nominal` or `stress` (statistical errors,
NOT calibrated to any device).
usage: gen_nand_cfg.py OUTDIR [--profile ideal|nominal|stress] [--time-scale N] [--bad 13,41]
                              [--force-prog-fail blk:pg,...] [--force-erase-fail blk,...] [--seed N] [--rated N]
"""
import argparse, os, sys, json
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "vendor/p52"))
import nand_flash_twin as T

ap = argparse.ArgumentParser()
ap.add_argument("out")
ap.add_argument("--profile", default="ideal")
ap.add_argument("--time-scale", type=float, default=10.0)
ap.add_argument("--bad", default="")
ap.add_argument("--force-prog-fail", default="")
ap.add_argument("--force-erase-fail", default="")
ap.add_argument("--seed", type=int, default=60)
ap.add_argument("--rated", type=float, default=0.0, help="rated endurance cycles (0 = twin default)")
a = ap.parse_args()
os.makedirs(a.out, exist_ok=True)
s = a.time_scale
ov = {
    "geometry": {"channels": 1, "packages_per_channel": 1, "targets_per_package": 1, "dies_per_target": 1,
                 "luns_per_die": 1, "planes_per_lun": 2, "blocks_per_plane": 32, "pages_per_block": 16,
                 "page_data_bytes": 512, "page_spare_bytes": 32},
    "timing": {"timing_mode": 0, "t_r_ns": 25000.0 / s, "t_prog_ns": 200000.0 / s, "t_bers_ns": 2000000.0 / s,
               "t_rst_poweron_ns": 1000000.0 / s, "t_rst_erase_ns": 500000.0 / s},
    "faults": {"factory_bad_blocks": [[0, 0, int(b)] for b in a.bad.split(",") if b], "factory_bad_block_rate": 0.0,
               "seed": a.seed},
    "directed": {"force_prog_fail": [[0, 0, int(x.split(":")[0]), int(x.split(":")[1])] for x in a.force_prog_fail.split(",") if x],
                 "force_erase_fail": [[0, 0, int(b)] for b in a.force_erase_fail.split(",") if b]},
}
if a.rated > 0:
    ov["faults"]["rated_endurance_cycles"] = a.rated
cfg = T.load_config(os.path.join(ROOT, "vendor/p52/config/slc_tiny.json"), profile=a.profile, overrides=ov)
T.export_svcfg(cfg, os.path.join(a.out, "nandlab.svcfg"))
print(f"nandlab.svcfg: profile={a.profile} time-scale=1/{s:g} bad={a.bad or '-'} "
      f"force_prog_fail={a.force_prog_fail or '-'} force_erase_fail={a.force_erase_fail or '-'}")
