#!/bin/bash
# Run one scenario:  run_tb.sh <scenario> [tag] [extra plusargs...]   env: PROFILE (ideal) TIMESCALE (10) NANDARGS ("") XTS (0)
set -u
HERE=$(cd "$(dirname "$0")" && pwd); P60=$(cd "$HERE/.." && pwd)
SC=${1:-smoke}; TAG=${2:-$SC}; shift; shift 2>/dev/null
RUN=$P60/build/run/$TAG; rm -rf "$RUN"; mkdir -p "$RUN"
python3 "$HERE/gen_nand_cfg.py" "$RUN/nand" --profile ${PROFILE:-ideal} --time-scale ${TIMESCALE:-10} ${NANDARGS:-} > "$RUN/nand_cfg.txt" || exit 2
FW=$P60/fw/build/p60_fw.hex; [ "${XTS:-0}" = 1 ] && FW=$P60/fw/build/p60_fw_xts.hex
cd "$RUN"
( time stdbuf -oL "${VTB:-$P60/build/tb/v/Vtb}" +scenario=$SC +fw=$FW +xts=${XTS:-0} +NANDLAB_DIR=$RUN/nand +NANDLAB_QUIET +NANDLAB_NOTRACE "$@" ) > run.log 2>&1
grep -E "^tb_p60_soc|TB (FAIL|crash|COV|GET_LOG|smoke|concurrency|random|badblock|security|accounting)|FAIL|real" run.log | head -${HEADN:-60}
grep -q -- "-> PASS" run.log
