#!/bin/bash
# release zip of the P60 source tree + reports (see package.py for what is excluded). Does not touch git.
exec python3 "$(cd "$(dirname "$0")" && pwd)/package.py" "$@"
