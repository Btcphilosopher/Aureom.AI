#!/bin/bash
# Formal checks (SymbiYosys): SFB2 host-BAR splitter and power-fail glitch filter.  Tasks: bmc, prove, cover.
#   SBY=/path/to/sby  YOSYS_BIN=/path/to/yosys/bin  (defaults: PATH, else the Nix store paths used for the reported results: sby 0.70 / yosys 0.70 / z3)
set -u
HERE=$(cd "$(dirname "$0")" && pwd); P60=$(cd "$HERE/.." && pwd); cd "$P60/formal"
SBY=${SBY:-$(command -v sby || ls /nix/store/*-sby-*/bin/sby 2>/dev/null | head -1)}
[ -x "${SBY:-}" ] || { echo "sby not found (set SBY=...)"; exit 2; }
Y=${YOSYS_BIN:-$(ls -d /nix/store/*-yosys-0.70/bin 2>/dev/null | head -1)}; [ -n "$Y" ] && export PATH="$Y:$PATH"
rc=0
for f in fv_hb_split fv_pwr_cond; do
  "$SBY" -f "$f.sby" > "$f.log" 2>&1
  for t in bmc prove cover; do
    st=$(cat "${f}_$t/status" 2>/dev/null | head -1); echo "$f/$t: ${st:-NO RESULT}"
    [ "${st%% *}" = PASS ] || rc=1
  done
done
exit $rc
