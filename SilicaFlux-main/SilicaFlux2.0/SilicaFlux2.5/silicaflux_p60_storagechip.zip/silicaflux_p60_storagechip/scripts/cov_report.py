#!/usr/bin/env python3
"""
cov_report.py -- summarise Verilator line coverage (coverage.dat, merged over runs) per RTL file and list uncovered line ranges.

  cov_report.py merged.dat [--root P60] [--out reports/COVERAGE_RTL.md] [--only substring,substring]

A "point" is one Verilator coverage entry (a line/branch block).  A source line is COVERED if every point on it was hit at least once,
PARTIAL if some were, UNCOVERED if none.  Only files under the chosen prefixes are reported (default: the P60-owned RTL, the page engine,
the AES-XTS core and the vendored blocks that the firmware actually exercises); the testbench is excluded.
This is simulation line coverage of the Verilated full-chip testbench.  It is NOT functional coverage and NOT toggle/branch signoff coverage.
"""
import argparse, collections, os, re, sys
ap = argparse.ArgumentParser()
ap.add_argument("dat"); ap.add_argument("--root", default=os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ap.add_argument("--out", default=""); ap.add_argument("--only", default="")
a = ap.parse_args()
pts = collections.defaultdict(lambda: collections.defaultdict(list))        # file -> line -> [hit counts]
for line in open(a.dat, errors="replace"):
    if not line.startswith("C '"): continue
    body, _, cnt = line[3:].rpartition("' ")
    try: cnt = int(cnt)
    except ValueError: continue
    kv = {}
    for part in body.split("\x01"):
        if "\x02" in part:
            k, v = part.split("\x02", 1); kv[k] = v
    f, l = kv.get("f"), kv.get("l")
    if not f or not l or kv.get("t") not in ("line", "branch", "expr", None): continue
    try: l = int(l)
    except ValueError: continue
    pts[f][l].append(cnt)
prefixes = [p for p in a.only.split(",") if p] or ["rtl/", "vendor/p54/rtl/", "vendor/p51/rtl/", "vendor/p07_testcore/rtl/", "vendor/p58b/", "third_party/", "fpga/"]
rows, tot_c, tot_l = [], 0, 0
for f in sorted(pts):
    ff = os.path.relpath(f, a.root) if os.path.isabs(f) else f
    if "tb/" in ff and ff.startswith("tb/"): continue
    if not any(ff.startswith(p) or ("/" + p) in ("/" + ff) for p in prefixes) and not any(p in ff for p in prefixes): continue
    lines = pts[f]
    cov = sum(1 for l, c in lines.items() if all(x > 0 for x in c))
    par = sum(1 for l, c in lines.items() if any(x > 0 for x in c) and not all(x > 0 for x in c))
    unc = sorted(l for l, c in lines.items() if not any(x > 0 for x in c))
    ranges, s = [], None
    for l in unc:
        if s and l == s[1] + 1: s[1] = l
        else:
            if s: ranges.append(tuple(s))
            s = [l, l]
    if s: ranges.append(tuple(s))
    rows.append((ff, len(lines), cov, par, len(unc), ranges)); tot_c += cov; tot_l += len(lines)
L = ["# RTL line coverage (Verilator `--coverage-line`, merged over the coverage scenario set in `scripts/run_cov.sh`; per-run results in `reports/logs/coverage_runs.txt`)", "",
     "Line coverage of the Verilated full-chip testbench. **Not functional coverage; not signoff.** Lines = coverage points (statements/branches) per source line;",
     "covered = every point on the line hit, partial = some points hit. Uncovered ranges are listed so that they can be reviewed (some are unreachable by construction: error"
     " branches for conditions the testbench cannot create, test-mode paths, vendor features P60 does not use).", "",
     f"**Overall: {tot_c}/{tot_l} lines fully covered ({100.0 * tot_c / max(tot_l, 1):.1f} %)** over the {len(rows)} files below.", "",
     "| file | lines | covered | partial | uncovered | covered % |", "|---|---|---|---|---|---|"]
for ff, n, c, p, u, _ in rows: L.append(f"| `{ff}` | {n} | {c} | {p} | {u} | {100.0 * c / max(n, 1):.0f} |")
L += ["", "## Uncovered line ranges (files below 100 %)", ""]
for ff, n, c, p, u, rg in rows:
    if u:
        txt = ", ".join(f"{x}" if x == y else f"{x}-{y}" for x, y in rg[:40]) + (" ..." if len(rg) > 40 else "")
        L.append(f"* `{ff}`: {txt}")
out = "\n".join(L) + "\n"
if a.out: open(a.out, "w").write(out)
print(out)
