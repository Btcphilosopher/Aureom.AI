#!/usr/bin/env python3
"""make_fpga_filelist.py -- fpga/files.f: rtl/files.f (with the FPGA SRAM backend instead of the ASIC one) + FPGA wrapper RTL."""
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out = []
for l in open(os.path.join(ROOT, "rtl/files.f")):
    out.append(l.rstrip("\n"))
    if l.strip().endswith("backends/generic/sram_generic_1rw.sv"):
        out.append(l.strip().replace("backends/generic/sram_generic_1rw.sv", "backends/fpga/sram_fpga_1rw.sv"))
out += ["${P60}/fpga/rtl/" + f for f in ("sfx_uart.sv", "sfx_hostmem_bram.sv", "sfx_uart_bridge.sv", "silicaflux_store_fpga_top.sv")]
open(os.path.join(ROOT, "fpga/files.f"), "w").write("\n".join(out) + "\n")
print(len(out), "entries")
