#!/usr/bin/env python3
"""make_nandmodel.py -- derive tb/models/nand_flash_model_p60.sv from the vendored Project 52 NAND digital twin.
One testbench back door is added (next to bd_peek): bd_flip(lun, blk, pg, bit) flips one STORED bit of a
programmed page, so the ECC tests can place exactly k raw bit errors in a chosen page (the twin's own error
model only injects statistical errors).  Delta: patches/nand_model_bd_flip.patch."""
import difflib, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = os.path.join(ROOT, "vendor/p52/nand_flash_model.sv"); dst = os.path.join(ROOT, "tb/models/nand_flash_model_p60.sv")
s = open(src).read(); o = s
anchor = "  function automatic bit [7:0] bd_peek(input int lun, input int blk, input int pg, input int c);\n"
assert s.count(anchor) == 1
s = s.replace(anchor, '''  // P60 testbench back door: flip one stored bit of an allocated (programmed) page; returns 1 if flipped
  function automatic bit bd_flip(input int lun, input int blk, input int pg, input int bit_idx);
    int pi; bit [7:0] v;
    pi = pidx(lun, blk, pg);
    if (slot_of[pi] < 0 || bit_idx < 0 || bit_idx >= PAGE_BYTES * 8) return 1'b0;
    v = pool[slot_of[pi] * PAGE_BYTES + (bit_idx >> 3)];
    v[bit_idx & 7] = ~v[bit_idx & 7];
    pool[slot_of[pi] * PAGE_BYTES + (bit_idx >> 3)] = v;
    return 1'b1;
  endfunction
''' + anchor)
open(dst, "w").write(s)
d = "".join(difflib.unified_diff(o.splitlines(True), s.splitlines(True), "p52/nand_flash_model.sv", "p60/nand_flash_model_p60.sv"))
open(os.path.join(ROOT, "patches/nand_model_bd_flip.patch"), "w").write(d)
print("ok")
