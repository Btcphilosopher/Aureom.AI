#!/bin/bash
# Line coverage of the Verilated RTL over a representative scenario set.
#   scripts/run_cov.sh        (needs: COVMAIN=1 TBNAME=tb_cov VFLAGS=--coverage-line scripts/build_tb.sh  ->  build/tb_cov/v/Vtb)
# Runs three chains in parallel, merges the per-run coverage.dat files and writes reports/COVERAGE_RTL.md.
set -u
HERE=$(cd "$(dirname "$0")" && pwd); P60=$(cd "$HERE/.." && pwd)
export VTB=$P60/build/tb_cov/v/Vtb
[ -x "$VTB" ] || { echo "build the coverage testbench first (see header)"; exit 2; }
run() { name=$1; shift; XTS=${XTS:-0} bash "$HERE/run_tb.sh" "$@" > /dev/null 2>&1; echo "$name: $(grep -E '^tb_p60_soc .*->' "$P60/build/run/cov_$name/run.log" | cut -c1-100)"; }
chainA() {
  run smoke        smoke        cov_smoke        +timeout=900000000
  run invalid      invalid      cov_invalid      +timeout=900000000
  run top          top          cov_top          +timeout=900000000
  run ecc          ecc          cov_ecc          +timeout=900000000
  run concurrency  concurrency  cov_concurrency  +timeout=900000000
  run backpressure backpressure cov_backpressure +timeout=900000000
  run ctrlreset    ctrlreset    cov_ctrlreset    +timeout=900000000
  run plp          plp          cov_plp          +timeout=900000000
  run noformat     noformat     cov_noformat     +timeout=900000000
  run random       random       cov_random       +seed=5 +nops=200 +timeout=3000000000
}
chainB() {
  run integrity    integrity    cov_integrity    +nops=150 +timeout=3000000000
  NANDARGS="--bad 13,41 --force-prog-fail 25:3 --force-erase-fail 30" run badblock badblock cov_badblock +badcfg=1 +nops=200 +timeout=3000000000
}
chainC() {
  XTS=1 run security security cov_security +timeout=900000000
  run crash        crash        cov_crash        +ncrash=4 +seed=7 +prefill=200 +timeout=3000000000
  XTS=1 run crash_xts crash     cov_crash_xts    +ncrash=2 +seed=8 +prefill=100 +timeout=3000000000
}
rm -f "$P60"/build/run/cov_*/coverage.dat
chainA & chainB & chainC & wait
files=$(ls "$P60"/build/run/cov_*/coverage.dat 2>/dev/null)
[ -n "$files" ] || { echo "no coverage.dat produced"; exit 1; }
verilator_coverage --write "$P60/build/cov_merged.dat" $files > /dev/null 2>&1
python3 "$HERE/cov_report.py" "$P60/build/cov_merged.dat" --root "$P60" --out "$P60/reports/COVERAGE_RTL.md" | head -12
