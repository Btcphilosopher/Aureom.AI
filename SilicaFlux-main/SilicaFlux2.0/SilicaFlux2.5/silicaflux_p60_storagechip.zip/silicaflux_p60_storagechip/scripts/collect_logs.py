#!/usr/bin/env python3
"""
collect_logs.py -- copy the evidence logs the reports cite into reports/logs/ (local absolute paths replaced by <P60>).
Run after the regression / bench / unit / formal / PD steps.  Missing inputs are skipped and listed.
"""
import glob, os, re, shutil, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "reports", "logs"); os.makedirs(OUT, exist_ok=True)
scrub = lambda t: t.replace(ROOT, "<P60>")
def put(src, dst, filt=None):
    if not os.path.exists(src): print("missing:", os.path.relpath(src, ROOT)); return
    t = open(src, errors="replace").read()
    if filt: t = "\n".join(l for l in t.splitlines() if filt(l)) + "\n"
    open(os.path.join(OUT, dst), "w").write(scrub(t))
for r in ("smoke invalid top ecc concurrency backpressure ctrlreset plp noformat integrity random_s1 random_s2 random_stress badblock "
          "security_xts crash_s1 crash_s2 crash_s3 crash_xts_s4").split():
    put(f"{ROOT}/build/run/{r}/run.log", f"regress_{r}.log")
put(f"{ROOT}/build/run/security_xts/xts_dump.txt", "xts_dump.txt")
put(f"{ROOT}/build/logs/lint_full.txt", "lint_full.txt") if os.path.exists(f"{ROOT}/build/logs/lint_full.txt") else put(f"{ROOT}/build/lint_full.txt", "lint_full.txt")
for u in ("unit_engine", "unit_fpga", "unit_security"): put(f"{ROOT}/build/logs/{u}.txt", f"{u}.txt")
for f in glob.glob(f"{ROOT}/formal/*.log"): put(f, "formal_" + os.path.basename(f))
for f in glob.glob(f"{ROOT}/formal/fv_*_*/status"): put(f, "formal_status_" + os.path.basename(os.path.dirname(f)) + ".txt")
put(f"{ROOT}/build/run/bench_final/run.log", "bench_run.log", lambda l: l.startswith(("BENCH", "tb_p60_soc", "TB boot", "TB host: HOST READY")))
put(f"{ROOT}/build/logs/cov_run.out", "coverage_runs.txt")
d = f"{ROOT}/build/pd/block_15ns"
for f in ("synth_stat.txt", "timing_setup_gr.rpt", "timing_hold_gr.rpt", "wns_gr.rpt", "power_gr.rpt", "skew_gr.rpt", "pd.sdc", "pd.tcl", "synth.ys"):
    put(f"{d}/{f}", "pd_" + f)
put(f"{d}/openroad.log", "pd_openroad_log.txt", lambda l: "Found unsupported expression" not in l and "DRT-0349" not in l)
for f in ("timing_setup.rpt", "timing_hold.rpt", "wns.rpt", "power.rpt", "skew.rpt", "drc.rpt"): put(f"{d}/{f}", "pd_" + f)
if os.path.exists(f"{ROOT}/build/logs/regression_prelim_before_final_firmware.md"):
    shutil.copy(f"{ROOT}/build/logs/regression_prelim_before_final_firmware.md", f"{ROOT}/reports/logs/regression_prelim_before_final_firmware.md")
print("collected", len(os.listdir(OUT)), "files into reports/logs")
