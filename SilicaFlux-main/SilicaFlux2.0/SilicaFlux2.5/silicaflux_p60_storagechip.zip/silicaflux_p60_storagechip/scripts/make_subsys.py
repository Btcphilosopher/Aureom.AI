#!/usr/bin/env python3
"""
make_subsys.py -- derive rtl/soc/sfs_storage_subsys.sv (P60) from the vendored P51 file.

The P60 subsystem is P51's sfs_storage_subsys with ONE addition: the page engine
(sfx_page_engine: BCH ECC + XTS-AES) as a fourth kind of storage-fabric master and a
register page (page 15).  Every edit below is an exact-match replacement that must hit
exactly once; the resulting delta is written to patches/subsys_page_engine.patch.
"""
import difflib, os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
SRC = os.path.join(ROOT, "vendor/p51/rtl/sfs_storage_subsys.sv")
DST = os.path.join(ROOT, "rtl/soc/sfs_storage_subsys.sv")
s = open(SRC).read()
orig = s

def rep(old, new):
    global s
    n = s.count(old)
    if n != 1:
        sys.exit(f"make_subsys: expected exactly 1 match, found {n} for:\n{old}")
    s = s.replace(old, new)

rep("// SilicaFlux StorageCore :: sfs_storage_subsys -- everything storage-specific\n",
    "// SilicaFlux StorageCore :: sfs_storage_subsys -- everything storage-specific\n"
    "//   *** P60 (SilicaFlux-STORE) variant: derived from the Project 51 file by scripts/make_subsys.py ***\n"
    "//   Adds the page engine (sfx_page_engine: BCH ECC + XTS-AES) as storage-fabric master M_PE (BUF only)\n"
    "//   with register page 15 (0x4000_F000).  See patches/subsys_page_engine.patch for the exact delta.\n")

# register page decode
rep("  wire sel_hif  = rb_sel && fidx == 3'(SFS_PG_HIF  - 8);\n  logic [31:0] rd_sys, rd_cmd, rd_dma, rd_hif, rd_nand;\n  logic        er_sys, er_cmd, er_dma, er_hif, er_nand;\n",
    "  wire sel_hif  = rb_sel && fidx == 3'(SFS_PG_HIF  - 8);\n"
    "  localparam int SFX_PG_PE = 15;                      // P60: page engine register page\n"
    "  wire sel_pe   = rb_sel && fidx == 3'(SFX_PG_PE - 8);\n"
    "  logic [31:0] rd_sys, rd_cmd, rd_dma, rd_hif, rd_nand, rd_pe;\n  logic        er_sys, er_cmd, er_dma, er_hif, er_nand, er_pe;\n")
rep("    rb_err   = 1'b1;                     // pages 8, 9, 15: absent in the storage SoC\n",
    "    rb_err   = 1'b1;                     // pages 8, 9: absent in the storage SoC\n")
rep("    if (fidx == 3'(SFS_PG_HIF - 8))  begin rb_rdata = rd_hif;  rb_err = er_hif;  end\n",
    "    if (fidx == 3'(SFS_PG_HIF - 8))  begin rb_rdata = rd_hif;  rb_err = er_hif;  end\n"
    "    if (fidx == 3'(SFX_PG_PE - 8))   begin rb_rdata = rd_pe;   rb_err = er_pe;   end\n")

# fabric: one more master after the NAND channels
rep("  localparam int NM = 2 + NCH;\n", "  localparam int M_PE = 2 + NCH;                      // P60: page engine master index\n  localparam int NM = 3 + NCH;\n")
rep("    for (int c = 0; c < NCH; c++) f_en[(2 + c)*NS + 0] = 1'b1;   // NAND -> BUF only\n",
    "    for (int c = 0; c < NCH; c++) f_en[(2 + c)*NS + 0] = 1'b1;   // NAND -> BUF only\n"
    "    f_en[M_PE*NS + 0] = 1'b1;                                    // P60 page engine -> BUF only\n")

# page engine instance, before the NAND channel block
rep("  // ---------------------------------------------------------------- m2+c: NAND channels\n",
    "  // ---------------------------------------------------------------- m(2+NCH): P60 page engine (BCH ECC + XTS-AES)\n"
    "  logic pe_busy, pe_ev_corr, pe_ev_unc, pe_ev_int, pe_fault;\n"
    "  /* verilator lint_off UNUSEDSIGNAL */\n"
    "  logic pe_ev_scrub_u;\n"
    "  /* verilator lint_on UNUSEDSIGNAL */\n"
    "  sfx_page_engine #(.XTS_KEYBITS(256)) u_pe (\n"
    "    .clk, .rst_n,\n"
    "    .rb_sel(sel_pe), .rb_we, .rb_addr(roff), .rb_wdata, .rb_rdata(rd_pe), .rb_err(er_pe),\n"
    "    .m_req_valid(m_req_valid[M_PE]), .m_req_ready(m_req_ready[M_PE]), .m_req_write(m_req_write[M_PE]),\n"
    "    .m_req_addr(m_req_addr[M_PE*32 +: 32]), .m_req_wdata(m_req_wdata[M_PE*DW +: 32]),\n"
    "    .m_req_wstrb(m_req_wstrb[M_PE*SB +: 4]), .m_rsp_valid(m_rsp_valid[M_PE]), .m_rsp_ready(m_rsp_ready[M_PE]),\n"
    "    .m_rsp_rdata(m_rsp_rdata[M_PE*DW +: 32]), .m_rsp_error(m_rsp_error[M_PE]),\n"
    "    .busy(pe_busy), .ev_ecc_corr(pe_ev_corr), .ev_ecc_unc(pe_ev_unc), .ev_integrity(pe_ev_int),\n"
    "    .ev_scrub(pe_ev_scrub_u), .ev_fault(pe_fault)\n"
    "  );\n"
    "\n"
    "  // ---------------------------------------------------------------- m2+c: NAND channels\n")

# system page wiring: events and idle
rep("    .buf_ready, .nand_idle(ch_busy == '0), .dma_idle(!dma_busy), .hif_en, .hif_rdy, .cmd_idle(outstanding_zero),",
    "    .buf_ready, .nand_idle(ch_busy == '0), .dma_idle(!dma_busy && !pe_busy), .hif_en, .hif_rdy, .cmd_idle(outstanding_zero),")
rep("    .ev_nand_ce_n(popc(ch_ce)), .ev_nand_ue_n(popc(ch_ue)),\n    .ev_dma_err(ev_dma_err || hm_refused),",
    "    .ev_nand_ce_n(popc(ch_ce) + 4'(pe_ev_corr)), .ev_nand_ue_n(popc(ch_ue) + 4'(pe_ev_unc || pe_ev_int)),\n    .ev_dma_err(ev_dma_err || hm_refused || pe_fault),")
rep("  assign busy_io   = dma_busy || !outstanding_zero;", "  assign busy_io   = dma_busy || pe_busy || !outstanding_zero;")
open(DST, "w").write(s)
d = "".join(difflib.unified_diff(orig.splitlines(True), s.splitlines(True), "p51/sfs_storage_subsys.sv", "p60/sfs_storage_subsys.sv"))
os.makedirs(os.path.join(ROOT, "patches"), exist_ok=True)
open(os.path.join(ROOT, "patches/subsys_page_engine.patch"), "w").write(d)
print(f"wrote {DST} ({d.count(chr(10)+'+')} added lines in patch)")
