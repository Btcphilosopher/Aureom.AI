#!/bin/bash
# Build the full-chip testbench (Verilator).  Output: build/tb/Vtb  (build takes ~3-4 min on 4 cores)
set -e
HERE=$(cd "$(dirname "$0")" && pwd); export P60=$(cd "$HERE/.." && pwd)
python3 "$HERE/make_filelist.py" >/dev/null
python3 "$HERE/make_subsys.py" >/dev/null
python3 "$HERE/make_nandmodel.py" >/dev/null
TBNAME=${TBNAME:-tb}
mkdir -p "$P60/build/$TBNAME"; cd "$P60/build/$TBNAME"
if [ -n "${COVMAIN:-}" ]; then MODE="--cc --exe --build $P60/tb/soc/cov_main.cpp"; else MODE="--binary"; fi
verilator $MODE --timing -O2 -j ${JOBS:-4} -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD -Wno-MULTIDRIVEN \
  +define+P60_TOP ${VFLAGS:-} -f "$P60/rtl/files.f" \
  "$P60/vendor/p51/tb/models/sfs_tb_hostmem.sv" "$P60/tb/models/nand_flash_model_p60.sv" \
  -I"$P60/tb/soc" "$P60/tb/soc/tb_p60_soc.sv" --top-module tb_p60_soc -Mdir v -o Vtb > build.log 2>&1 \
  || { grep -E "^%Error" -A4 build.log | head -40; echo "BUILD FAILED (see build/$TBNAME/build.log)"; exit 1; }
echo "built build/$TBNAME/v/Vtb"
