#!/usr/bin/env python3
"""
check_xts_nand.py -- independent check of the data stored on the simulated NAND in XTS mode.

The testbench (scenario `security`, +xts=1) writes xts_dump.txt: the 512-bit XTS-AES-256 key it provisioned and, for every
logical block, the plaintext it sent (from the oracle) and the 512 raw data bytes found in the NAND twin's array (back door).
This script recomputes AES-256-XTS (python `cryptography`/OpenSSL; tweak = physical page number, 16-byte little endian) and
compares.  Exit status 0 only if every page matches AND no page equals its plaintext.
usage: check_xts_nand.py xts_dump.txt
"""
import sys
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

key = None; n = 0; bad = 0; same = 0
for line in open(sys.argv[1]):
    p = line.split()
    if not p: continue
    if p[0] == "KEY":
        words = [int(p[1][i:i + 8], 16) for i in range(0, 128, 8)]
        key = b"".join(w.to_bytes(4, "little") for w in words)          # register words are little endian
    elif p[0] == "PAGE":
        ppn, plain, raw = int(p[1]), bytes.fromhex(p[2]), bytes.fromhex(p[3])
        exp = Cipher(algorithms.AES(key), modes.XTS(ppn.to_bytes(16, "little"))).encryptor().update(plain)
        n += 1
        if exp != raw: bad += 1; print(f"MISMATCH ppn {ppn}")
        if raw == plain: same += 1
print(f"check_xts_nand: {n} pages, {bad} mismatches, {same} pages equal to plaintext -> {'PASS' if n and not bad and not same else 'FAIL'}")
sys.exit(0 if n and not bad and not same else 1)
