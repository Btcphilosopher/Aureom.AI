/* =============================================================================
 * SilicaFlux-STORE P60 -- page engine register map (register page 15, 0x4000_F000)
 * Hand-maintained mirror of rtl/storage/sfx_page_engine.sv (header comment is the source of truth;
 * tb/storage/tb_sfx_page_engine.sv checks these offsets).
 * ===========================================================================*/
#ifndef SFX_REGS_H
#define SFX_REGS_H

#define SFX_PE_BASE        0x4000f000u
#define SFX_PE_ID          0x000u   /* RO "SFXP" 0x53465850 */
#define SFX_PE_VERSION     0x004u
#define SFX_PE_CAPS0       0x008u   /* {SPARE[15:0], DATA[15:0]} bytes */
#define SFX_PE_CAPS1       0x00cu   /* {XTS key bits[31:16], T[15:8], UMETA[7:0]} */
#define SFX_PE_CTRL        0x010u   /* W1 bit0: clear counters */
#define SFX_PE_STATUS      0x014u   /* [0] BUSY [1] DONE [2] ERR [3] KEY_READY [11:8] LAST_OP [15:12] ERR_CODE */
#define SFX_PE_S_BASE      0x018u
#define SFX_PE_R_BASE      0x01cu
#define SFX_PE_TWEAK_LO    0x020u
#define SFX_PE_TWEAK_HI    0x024u
#define SFX_PE_SUBMIT      0x028u
#define SFX_PE_RESULT0     0x02cu
#define SFX_PE_RESULT1     0x030u
#define SFX_PE_KEY_CTRL    0x040u   /* [0] commit [1] zeroize */
#define SFX_PE_KEY_STATUS  0x044u   /* [0] key ready [1] engine busy */
#define SFX_PE_KEY_W(i)    (0x080u + 4u * (i))
#define SFX_PE_N_ENC       0x0c0u
#define SFX_PE_N_DEC       0x0c4u
#define SFX_PE_N_XTS       0x0c8u
#define SFX_PE_N_ERR       0x0ccu
#define SFX_PE_ECC_WIN     0x100u   /* ECCCore (P54) register window: ID "SECC", CW_CORRECTED 0x2c, BITS_CORRECTED 0x30, ... */

#define SFX_OP_BCH_ENC     1u       /* S -> R */
#define SFX_OP_BCH_DEC     2u       /* R -> S */
#define SFX_OP_XTS_ENC     3u       /* S in place */
#define SFX_OP_XTS_DEC     4u

#define SFX_ST_BUSY        (1u << 0)
#define SFX_ST_DONE        (1u << 1)
#define SFX_ST_ERR         (1u << 2)
#define SFX_ST_KEY_READY   (1u << 3)

/* sector status codes in RESULT0[2:0] */
#define SFX_SS_CLEAN       0u
#define SFX_SS_CORRECTED   1u
#define SFX_SS_ERASED      2u
#define SFX_SS_UNCORR      3u
#define SFX_SS_INTEGRITY   4u

/* ---- raw page image: 512 B data | 32 B spare = RSVD/BBM(1) UMETA(16) CRC-16(2) parity(13) */
#define SFX_PAGE_DATA      512u
#define SFX_PAGE_SPARE     32u
#define SFX_RAW_BYTES      (SFX_PAGE_DATA + SFX_PAGE_SPARE)
#define SFX_PLAIN_BYTES    (SFX_PAGE_DATA + 16u)      /* data + 16-B FTL spare record */
#define SFX_BBM_COL        SFX_PAGE_DATA              /* bad-block marker: first spare byte */

#endif
