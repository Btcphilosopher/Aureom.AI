/* =============================================================================
 * SilicaFlux-STORE P60 firmware -- bring-up and main event loop
 * (framework derived from the Project 51 firmware; FTL, executor and HAL are P60)
 *
 * Boot (after the ControlCore boot ROM accepted the image):
 *   FW_INIT        platform: INTC priorities, timer tick, watchdog, RAS enables
 *   ACC_DISCOVERY  subsystem + page-engine discovery
 *   (XTS build)    wait for the data-at-rest key: mailbox KEY_LOAD x3, KEY_COMMIT (never stored, never readable)
 *   SELF_TEST      buffer pattern test, FTL mount with roll-forward recovery (or format of a blank medium)
 *   CMDPROC_READY  capacity / MDTS published, host-interface events enabled, locks set
 *   HOST_READY     host_ready pin; RDY follows the host's CTRL.EN
 * Main loop: events, then commands; WFI with the command / event interrupt sources armed.
 * Power fail (PLP): new commands are refused by hardware; firmware stops starting NAND program/erase (HAL),
 * asserts FW_SAFE (NAND WP#), and after the supply returns REMOUNTS the FTL (recovery path).  No hold-up energy
 * is assumed: durability never depends on it.
 * ===========================================================================*/
#include "fw.h"
#include "sfftl.h"
#include "hal_sfx.h"

#ifndef SFX_XTS_MODE
#define SFX_XTS_MODE 0
#endif

extern sfx_hal_t g_hw;
extern int g_ftl_up, g_xts_mode, g_fw_verify_write;

volatile uint32_t g_resetting;
static uint32_t g_plp, g_ras_events, g_db_errs, g_down, g_mbox_seq, g_shn_n;
static int      g_selftest_fail;
static uint32_t g_keystage[16];
static volatile uint32_t g_format_req, g_rebuild_req;

#define MBOX_CMD_SET_PHYS_EN  0x51u
#define MBOX_CMD_STATS        0x52u
#define MBOX_CMD_KEY_LOAD     0x54u      /* arg1 = first word index, arg2..arg7 = up to 6 key words */
#define MBOX_CMD_KEY_COMMIT   0x55u      /* expand the key schedules; encryption becomes usable */
#define MBOX_CMD_KEY_ZEROIZE  0x56u      /* crypto-erase: key material destroyed */
#define MBOX_CMD_FORMAT       0x57u      /* arg1 = 0x464D5421 ("FMT!"): format the medium; only accepted while the FTL is not mounted */
#define MBOX_CMD_REBUILD      0x58u      /* arg1 = 0x52424C44 ("RBLD"): rebuild the map from the page spare records; only while the FTL is not mounted */
#define FORMAT_MAGIC          0x464D5421u
#define REBUILD_MAGIC         0x52424C44u
#define PLP_ST_FAIL           0x4u

static void mbox_reply(uint32_t sts, uint32_t cmd, const uint32_t *d, int n) {
  for (int i = 0; i < 7; i++) MBOX_F2H(1 + i) = (i < n) ? d[i] : 0u;
  MBOX_F2H(0) = sts | (cmd << 8) | ((g_mbox_seq & 0xFFFFu) << 16);
  MBOX(CC_MBOX_F2H_RING) = cmd;
}
static void hif_set_rdy(int on) { uint32_t c = HIF(SFS_HIF_CTRL); HIF(SFS_HIF_CTRL) = on ? (c | 1u) : (c & ~1u); }
static void hif_set_shst(uint32_t s) { HIF(SFS_HIF_CTRL) = (HIF(SFS_HIF_CTRL) & ~0xCu) | (s << 2); }

/* hook used by the HAL: stop starting NAND program/erase once a power fault is observed */
int sfx_power_fault(void) { return (SYS(SFS_SYS_PLP_STATUS) & PLP_ST_FAIL) != 0u; }

/* ---------------------------------------------------------------- mailbox */
static int mbox_service(void) {
  if (!g_mbox_pending) return 0;
  g_mbox_pending = 0;
  g_mbox_seq++;
  uint32_t cmd = g_mbox[0] & 0xFFu;
  if (cmd == CC_MBOX_CMD_PING) {
    uint32_t d[2] = { g_mbox[1], FW_VERSION };
    mbox_reply(CC_MBOX_STS_OK, cmd, d, 2);
  } else if (cmd == MBOX_CMD_SET_PHYS_EN) {
    SYS(SFS_SYS_SEC_CTRL) = (g_mbox[1] ? 1u : 0u) | 2u;
    mbox_reply(CC_MBOX_STS_OK, cmd, 0, 0);
  } else if (cmd == MBOX_CMD_STATS) {
    const sfftl_stats_t *s = sfftl_stats(&g_ftl_inst);
    uint32_t d[6] = { g_cmd_done, g_cmd_err, (uint32_t)s->nand_prog_host, (uint32_t)s->nand_prog_reloc, g_fw_errors, g_ras_events };
    mbox_reply(CC_MBOX_STS_OK, cmd, d, 6);
  } else if (cmd == MBOX_CMD_KEY_LOAD) {
    uint32_t idx = g_mbox[1];
    if (idx > 10u) { mbox_reply(CC_MBOX_STS_BAD_CMD, cmd, 0, 0); return 1; }
    for (uint32_t i = 0; i < 6u && idx + i < 16u; i++) g_keystage[idx + i] = g_mbox[2 + i];
    mbox_reply(CC_MBOX_STS_OK, cmd, 0, 0);
  } else if (cmd == MBOX_CMD_KEY_COMMIT) {
    int rc = sfx_key_load(g_keystage, 16u);
    for (uint32_t i = 0; i < 16u; i++) g_keystage[i] = 0u;               /* staging copy destroyed */
    uint32_t d[1] = { PE(SFX_PE_KEY_STATUS) & 1u };
    mbox_reply(rc ? CC_MBOX_STS_ACC_ERROR : CC_MBOX_STS_OK, cmd, d, 1);
    cprintf("[sec] key committed: engine key_ready=%u\n", d[0]);
  } else if (cmd == MBOX_CMD_KEY_ZEROIZE) {
    sfx_key_zeroize();
    for (uint32_t i = 0; i < 16u; i++) g_keystage[i] = 0u;
    cprintf("[sec] key zeroized (crypto-erase): XTS data on the medium is now unreadable\n");
    mbox_reply(CC_MBOX_STS_OK, cmd, 0, 0);
  } else if (cmd == MBOX_CMD_FORMAT) {
    if (g_mbox[1] != FORMAT_MAGIC) mbox_reply(CC_MBOX_STS_BAD_CMD, cmd, 0, 0);
    else if (g_ftl_up) { cprintf("[mgmt] FORMAT refused: the FTL is mounted\n"); mbox_reply(CC_MBOX_STS_ACC_ERROR, cmd, 0, 0); }
    else { g_format_req = 1; mbox_reply(CC_MBOX_STS_OK, cmd, 0, 0); }
  } else if (cmd == MBOX_CMD_REBUILD) {
    if (g_mbox[1] != REBUILD_MAGIC) mbox_reply(CC_MBOX_STS_BAD_CMD, cmd, 0, 0);
    else if (g_ftl_up) { cprintf("[mgmt] REBUILD refused: the FTL is mounted\n"); mbox_reply(CC_MBOX_STS_ACC_ERROR, cmd, 0, 0); }
    else { g_rebuild_req = 1; mbox_reply(CC_MBOX_STS_OK, cmd, 0, 0); }
  } else if (cmd == CC_MBOX_CMD_SHUTDOWN) {
    g_down = 1;
  } else {
    mbox_reply(CC_MBOX_STS_BAD_CMD, cmd, 0, 0);
  }
  return 1;
}

/* ---------------------------------------------------------------- events */
static int events(void) {
  int n = 0;
  uint32_t ev = HIF(SFS_HIF_EVT_STATUS);
  if (ev) {
    HIF(SFS_HIF_EVT_STATUS) = ev;
    n++;
    if (ev & (1u << SFS_HEVT_EN_FALL)) {
      g_resetting = 1;
      cmd_abort_pending(SFS_ST_ABORT_RESET, SFS_ERR_NOT_READY);
      cprintf("[hif] controller reset requested (EN 1->0)\n");
    }
    if (ev & (1u << SFS_HEVT_RESET_DONE)) { g_resetting = 0; cprintf("[hif] controller reset complete\n"); }
    if (ev & (1u << SFS_HEVT_SHN)) {
      g_shn_n++;
      hif_set_shst(1u);
      cprintf("[hif] shutdown requested: clean checkpoint\n");
      int rc = ftl_shutdown_clean();
      hif_set_shst(2u);
      cprintf("[hif] shutdown complete (rc %d)\n", rc);
    }
    if (ev & (1u << SFS_HEVT_DB_ERR)) { g_db_errs++; cprintf("[hif] invalid doorbell %08x\n", HIF(SFS_HIF_DB_ERR_INFO)); }
  }
  uint32_t s = HIF(SFS_HIF_STATE);
  if (!g_resetting && (s & 1u) && !(s & 4u) && !(s & 8u)) {
    if (!g_ftl_up && g_plp == 0) {                                   /* re-enable after a clean shutdown: remount */
      if (ftl_boot() == 0) { CMDR(SFS_CMD_CAP_LO) = (uint32_t)ftl_capacity(); CMDR(SFS_CMD_CAP_HI) = 0u; }
    }
    hif_set_rdy(1);
    cprintf("[hif] controller enabled -> RDY\n");
    n++;
  }

  /* power fail: hardware has stopped new commands; the executor is synchronous so nothing is in flight here */
  uint32_t ps = SYS(SFS_SYS_PLP_STATUS);
  if (g_plp == 0 && (ps & PLP_ST_FAIL) && !(ps & 0x10u)) {
    g_plp = 1;
    cmd_abort_pending(SFS_ST_ABORT_PWR_LOSS, SFS_ERR_QUIESCED);
    SYS(SFS_SYS_PLP_CTRL) = 0x5u;                                    /* FW_SAFE | AUTO_WP -> NAND WP# asserted */
    cprintf("[plp] power fail: commands refused, WP# asserted, no checkpoint (no hold-up energy assumed)\n");
    n++;
  }
  if (g_plp == 1 && !(ps & 1u)) {
    SYS(SFS_SYS_PLP_CTRL) = 0x104u;                                  /* CLR, keep AUTO_WP */
    g_plp = 0;
    cprintf("[plp] power restored: remounting the FTL (recovery)\n");
    g_ftl_up = 0;
    if (ftl_boot() == 0) { CMDR(SFS_CMD_CAP_LO) = (uint32_t)ftl_capacity(); CMDR(SFS_CMD_CAP_HI) = 0u; }
    n++;
  }

  /* storage RAS (sticky): log, clear, re-enable the ControlCore SOC sources masked by isr_ras */
  uint32_t r = SYS(SFS_SYS_RAS_STATUS) & (SYS(SFS_SYS_RAS_WARN_EN) | SYS(SFS_SYS_RAS_FATAL_EN));
  if (r) {
    g_ras_events++;
    cprintf("[ras] storage RAS status %03x\n", r);
    SYS(SFS_SYS_RAS_STATUS) = r;
    RAS(CC_RAS_WARN_EN) = RAS(CC_RAS_WARN_EN) | (1u << CC_RAS_SRC_EXT_WARN);
    RAS(CC_RAS_FATAL_EN) = RAS(CC_RAS_FATAL_EN) | (1u << (CC_RAS_SRC_EXT_FATAL - 8));
    n++;
  }
  n += mbox_service();
  if (g_down == 1) {
    g_down = 2;
    int fail = g_selftest_fail || g_fw_errors != 0u || g_mbox[1] != 0u;
    const sfftl_stats_t *st = sfftl_stats(&g_ftl_inst);
    cprintf("SHUTDOWN: commands %u (errors reported to host %u), FTL host LBAs written %u read %u, GC victims %u, "
            "firmware errors %u, host-reported failures %u -> %s\n", g_cmd_done, g_cmd_err, (uint32_t)st->host_lba_written,
            (uint32_t)st->host_lba_read, (uint32_t)st->gc_victims, g_fw_errors, g_mbox[1], fail ? "FAIL" : "PASS");
    uint32_t d[4] = { g_cmd_done, g_cmd_err, (uint32_t)st->host_lba_written, g_fw_errors };
    mbox_reply(fail ? CC_MBOX_STS_ACC_ERROR : CC_MBOX_STS_OK, CC_MBOX_CMD_SHUTDOWN, d, 4);
    boot_stage(CC_BOOT_STAGE_SHUTDOWN);
    SYSCTRL(CC_SYSCTRL_TEST_CTRL) = 0x80000000u | (fail ? 0x40000000u : 0u) | (g_cmd_done & 0xFFFFu);
  }
  return n;
}

static void selftest(void) {
  uint32_t a = SLOT_ADDR(SLOT_HOST);
  for (uint32_t i = 0; i < 16u; i++) BUFW(a + 4u * i) = 0xA5A50000u ^ (a + 4u * i);
  for (uint32_t i = 0; i < 16u; i++) if (BUFW(a + 4u * i) != (0xA5A50000u ^ (a + 4u * i))) g_selftest_fail++;
  if (g_selftest_fail) cprintf("[st] buffer pattern test FAILED\n");
}

int main(void) {
  boot_stage(CC_BOOT_STAGE_FW_INIT);
  platform_init();
  uint32_t cause = SYSCTRL(CC_SYSCTRL_RESET_CAUSE);
  SYSCTRL(CC_SYSCTRL_RESET_CAUSE) = cause;
  SYSCTRL(CC_SYSCTRL_FW_VERSION) = FW_VERSION;
  cprintf("\nSilicaFlux-STORE P60 firmware %08x on ControlCore %08x (reset cause %x), XTS mode %d\n", FW_VERSION,
          SYSCTRL(CC_SYSCTRL_HW_VERSION), cause, SFX_XTS_MODE);
  cprintf("SECURITY: firmware image integrity = CRC32 only; NO authentication; data-at-rest key supplied by the host\n");
  g_xts_mode = SFX_XTS_MODE;
#ifdef SFX_VERIFY_WRITE
  g_fw_verify_write = 1;
#endif

  boot_stage(CC_BOOT_STAGE_ACC_DISCOVERY);
  if (hal_init() != 0) {
    cprintf("[sfs] no usable storage: staying in FATAL\n");
    HIF(SFS_HIF_CTRL) = 0x2u;
    boot_stage(CC_BOOT_STAGE_FATAL);
    for (;;) wfi();
  }
  irqs_rearm();
  if (g_xts_mode) {
    cprintf("[sec] XTS-AES data-at-rest: waiting for the key (mailbox KEY_LOAD / KEY_COMMIT)\n");
    while (!(PE(SFX_PE_KEY_STATUS) & 1u)) {
      if (!mbox_service()) { uint32_t m = irq_save(); if (!g_mbox_pending) wfi(); irq_restore(m); }
    }
  }

  boot_stage(CC_BOOT_STAGE_SELF_TEST);
  selftest();
  int frc = ftl_boot();
  while (frc != 0) {                                      /* never serve, never touch the medium, until an explicit REBUILD or FORMAT */
    cprintf("[ftl] FATAL: cannot mount (%d): refusing to serve, medium untouched; mailbox REBUILD or FORMAT (magic) is required\n", frc);
    HIF(SFS_HIF_CTRL) = 0x2u;
    boot_stage(CC_BOOT_STAGE_FATAL);
    while (!g_format_req && !g_rebuild_req) { if (!mbox_service()) { uint32_t m = irq_save(); if (!g_mbox_pending) wfi(); irq_restore(m); } }
    if (g_rebuild_req) { g_rebuild_req = 0; cprintf("[mgmt] explicit REBUILD requested\n"); frc = ftl_rebuild_explicit(); }
    else { g_format_req = 0; cprintf("[mgmt] explicit FORMAT requested\n"); frc = ftl_format_explicit(); }
    if (frc == 0) HIF(SFS_HIF_CTRL) = HIF(SFS_HIF_CTRL) & ~0x2u;
  }

  CMDR(SFS_CMD_CAP_LO) = (uint32_t)ftl_capacity();
  CMDR(SFS_CMD_CAP_HI) = 0u;
  CMDR(SFS_CMD_MDTS) = 16u;
  HIF(SFS_HIF_EVT_EN) = 0x1Fu;
  SYS(SFS_SYS_RAS_STATUS) = 0x3FFu;
  SYS(SFS_SYS_RAS_WARN_EN) = (1u << SFS_RAS_NAND_UE) | (1u << SFS_RAS_DMA_ERR) | (1u << SFS_RAS_NAND_TMO) |
                             (1u << SFS_RAS_FW_PROTO) | (1u << SFS_RAS_SEC_VIOL) | (1u << SFS_RAS_FABRIC_DEC);
  SYS(SFS_SYS_RAS_FATAL_EN) = (1u << SFS_RAS_BUF_UE);
  SYS(SFS_SYS_PLP_CTRL) = 0x4u;                           /* AUTO_WP */
  SYS(SFS_SYS_SEC_CTRL) = 0x2u;                           /* HOST_MGMT_LOCK; PHYS_EN off */
  SEC(CC_SEC_CTRL) = 1u;                                  /* ControlCore host write lock (IMEM/DMEM/ROM) */
  irqs_rearm();

  boot_stage(CC_BOOT_STAGE_CMDPROC_READY);
  SYSCTRL(CC_SYSCTRL_HOST_STATUS) = CC_HOST_STATUS_FW_RUNNING | CC_HOST_STATUS_CMDPROC_READY;
  boot_stage(CC_BOOT_STAGE_HOST_READY);
  {
    uint32_t d[6] = { 1u, (uint32_t)ftl_capacity(), SYS(SFS_SYS_CONFIG0), cause, FW_VERSION, (uint32_t)SFX_XTS_MODE };
    mbox_reply(CC_MBOX_STS_OK, 0u, d, 6);
  }
  SYSCTRL(CC_SYSCTRL_HOST_STATUS) = SYSCTRL(CC_SYSCTRL_HOST_STATUS) | CC_HOST_STATUS_HOST_READY;
  cprintf("[sfs] HOST READY: %u LBAs x %u B, %u tag(s)\n", (uint32_t)ftl_capacity(), SFX_LBA_BYTES, g_cfg.tags);

  for (;;) {
    int n;
    do {
      n = events();
      if (g_ftl_up && !g_resetting && g_plp == 0) n += cmd_service();
      else if (g_plp != 0 || g_resetting) { /* commands that slip in are refused */ cmd_abort_pending(g_plp ? SFS_ST_ABORT_PWR_LOSS : SFS_ST_ABORT_RESET, g_plp ? SFS_ERR_QUIESCED : SFS_ERR_NOT_READY); }
    } while (n);
    uint32_t m = irq_save();
    if (!g_mbox_pending) {
      SYS(SFS_SYS_IRQ_EN_IO) = IO_SOURCES;
      SYS(SFS_SYS_IRQ_EN_EVT) = (g_plp == 1) ? (EVT_SOURCES & ~(1u << SFS_IRQ_PLP)) : EVT_SOURCES;
      wfi();
    }
    irq_restore(m);
  }
}
