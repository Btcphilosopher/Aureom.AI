/* =============================================================================
 * SilicaFlux-STORE P60 firmware -- subsystem discovery and DMA helpers
 * (framework derived from Project 51 firmware/app/hal.c)
 * ===========================================================================*/
#include "fw.h"

sfs_cfg_t g_cfg;

int dma_free(void) { return (int)((SDMA(SFS_DMA_STATUS) >> 12) & 0xFu); }

void dma_submit(uint32_t src, uint32_t dst, uint32_t len, uint32_t tag) {
  SDMA(SFS_DMA_SRC) = src;
  SDMA(SFS_DMA_DST) = dst;
  SDMA(SFS_DMA_LEN) = len;
  SDMA(SFS_DMA_SUBMIT) = tag & 0xFFu;
}

/* synchronous DMA: returns 0 or an SFS_DST_* code (0xFF = timeout) */
int dma_sync(uint32_t src, uint32_t dst, uint32_t len) {
  uint32_t t0 = cycles(), h;
  while (!dma_free()) if (cycles() - t0 > 4000000u) return 0xFF;
  dma_submit(src, dst, len, 0xC0u);
  while (!((h = SDMA(SFS_DMA_CPL_HEAD)) & 0x80000000u)) if (cycles() - t0 > 8000000u) return 0xFF;
  SDMA(SFS_DMA_CPL_POP) = 0u;
  return (int)((h >> 8) & 0xFFu);
}

int hal_init(void) {
  if (SYS(SFS_SYS_ID) != SFS_SYS_ID_VALUE) { cprintf("[sfs] storage system page missing\n"); return -1; }
  uint32_t pv = SYS(SFS_SYS_PROTO_VERSION);
  if ((pv >> 16) != (SFS_PROTO_VERSION >> 16)) { cprintf("[sfs] protocol major %u unsupported\n", pv >> 16); return -1; }
  uint32_t c0 = SYS(SFS_SYS_CONFIG0), c2 = SYS(SFS_SYS_CONFIG2);
  g_cfg.nch       = c0 & 0xFu;
  g_cfg.cdw       = ((c0 >> 8) & 0xFu) * 8u;
  g_cfg.dw_bytes  = (c0 >> 12) & 0xFFu;
  g_cfg.tags      = (c0 >> 20) & 0xFFu;
  g_cfg.ecc       = (c0 >> 28) & 1u;
  g_cfg.ras       = (c0 >> 29) & 1u;
  g_cfg.buf_bytes = SYS(SFS_SYS_CONFIG1);
  g_cfg.page      = c2 & 0xFFFFu;
  g_cfg.aw        = (c2 >> 16) & 0xFFu;
  g_cfg.hqd       = c2 >> 24;
  cprintf("[sfs] StorageCore hw %08x proto %08x: %u ch x%u, buffer %u B, DMA %u-bit, %u tags, slot %u B, inline-ECC %u RAS %u\n",
          SYS(SFS_SYS_HW_VERSION), pv, g_cfg.nch, g_cfg.cdw, g_cfg.buf_bytes, g_cfg.dw_bytes * 8u, g_cfg.tags, g_cfg.page,
          g_cfg.ecc, g_cfg.ras);
  if (g_cfg.nch != 1u || g_cfg.page != SFX_SLOT_STRIDE || g_cfg.buf_bytes < 4u * SFX_SLOT_STRIDE) {
    cprintf("[sfs] unsupported configuration (need 1 channel, NAND_PAGE_BYTES=%u)\n", SFX_SLOT_STRIDE);
    return -2;
  }
  if (PE(SFX_PE_ID) != 0x53465850u) { cprintf("[sfs] page engine missing (ID %08x)\n", PE(SFX_PE_ID)); return -3; }
  cprintf("[sfs] page engine v%08x: data %u B, spare %u B, XTS key bits %u\n", PE(SFX_PE_VERSION),
          PE(SFX_PE_CAPS0) & 0xFFFFu, PE(SFX_PE_CAPS0) >> 16, PE(SFX_PE_CAPS1) >> 16);
  uint32_t t0 = cycles();
  while (!(SYS(SFS_SYS_READY) & 1u)) if (cycles() - t0 > 2000000u) { cprintf("[sfs] buffer not ready\n"); return -4; }
  return 0;
}
