/* =============================================================================
 * SilicaFlux-STORE P60 -- FTL NAND HAL (see hal_sfx.h)
 * ===========================================================================*/
#include "fw.h"
#include "hal_sfx.h"

int sfx_power_fault(void);                  /* main.c: PLP fail input observed */
#define HAL_TAG     0xB0u
#define POLL_LIMIT  8000000u
#define PE_LIMIT    400000u

typedef uint32_t __attribute__((__may_alias__)) u32a;

/* one NAND operation, synchronously; returns the NST_* status or 0xFF on a poll timeout */
static uint32_t nand_op(sfx_hal_t *h, uint32_t op, uint32_t row, uint32_t col, uint32_t len, uint32_t *info0) {
  NAND(h->ch, SFS_NAND_OP_ROW) = row;
  NAND(h->ch, SFS_NAND_OP_COL) = col;
  NAND(h->ch, SFS_NAND_OP_BUF) = SLOT_ADDR(SLOT_RAW);
  NAND(h->ch, SFS_NAND_OP_LEN) = len;
  NAND(h->ch, SFS_NAND_OP_SUBMIT) = op | (HAL_TAG << 16);                 /* ECC_EN = 0: raw transfer */
  uint32_t t0 = cycles(), head;
  while (!((head = NAND(h->ch, SFS_NAND_CPL_HEAD)) & 0x80000000u)) {
    if (cycles() - t0 > POLL_LIMIT) { h->nand_timeouts++; return 0xFFu; }
  }
  if (info0) *info0 = NAND(h->ch, SFS_NAND_CPL_INFO0);
  NAND(h->ch, SFS_NAND_CPL_POP) = 0u;
  return (head >> 8) & 0xFFu;
}

/* one page-engine operation; returns STATUS, or 0 on timeout */
static uint32_t pe_run(sfx_hal_t *h, uint32_t op) {
  uint32_t t0 = cycles(), st;
  PE(SFX_PE_SUBMIT) = op;
  while (!((st = PE(SFX_PE_STATUS)) & SFX_ST_DONE)) {
    if (cycles() - t0 > PE_LIMIT) { h->pe_errors++; return 0u; }
  }
  h->cyc_pe += cycles() - t0;
  if (st & SFX_ST_ERR) h->pe_errors++;
  return st;
}

static void copy_in(sfx_hal_t *h, const void *data, const void *spare) {
  uint32_t t0 = cycles();
  volatile uint32_t *b = (volatile uint32_t *)(uintptr_t)SLOT_ADDR(SLOT_PLAIN);
  const uint8_t *d = (const uint8_t *)data, *s = (const uint8_t *)spare;
  if (!((uintptr_t)d & 3u)) {
    const u32a *w = (const u32a *)(const void *)d;
    for (uint32_t i = 0; i < SFX_PAGE_DATA / 4u; i++) b[i] = w[i];
  } else {
    for (uint32_t i = 0; i < SFX_PAGE_DATA / 4u; i++, d += 4)
      b[i] = (uint32_t)d[0] | ((uint32_t)d[1] << 8) | ((uint32_t)d[2] << 16) | ((uint32_t)d[3] << 24);
  }
  for (uint32_t i = 0; i < SFFTL_OOB_BYTES / 4u; i++, s += 4)
    b[SFX_PAGE_DATA / 4u + i] = (uint32_t)s[0] | ((uint32_t)s[1] << 8) | ((uint32_t)s[2] << 16) | ((uint32_t)s[3] << 24);
  h->cyc_copy += cycles() - t0;
}

static void copy_out(sfx_hal_t *h, void *data, void *spare) {
  uint32_t t0 = cycles();
  volatile uint32_t *b = (volatile uint32_t *)(uintptr_t)SLOT_ADDR(SLOT_PLAIN);
  if (data) {
    if (!((uintptr_t)data & 3u)) {
      u32a *w = (u32a *)data;
      for (uint32_t i = 0; i < SFX_PAGE_DATA / 4u; i++) w[i] = b[i];
    } else {
      uint8_t *d = (uint8_t *)data;
      for (uint32_t i = 0; i < SFX_PAGE_DATA / 4u; i++, d += 4) {
        uint32_t w = b[i];
        d[0] = (uint8_t)w; d[1] = (uint8_t)(w >> 8); d[2] = (uint8_t)(w >> 16); d[3] = (uint8_t)(w >> 24);
      }
    }
  }
  if (spare) {
    uint8_t *s = (uint8_t *)spare;
    for (uint32_t i = 0; i < SFFTL_OOB_BYTES / 4u; i++, s += 4) {
      uint32_t w = b[SFX_PAGE_DATA / 4u + i];
      s[0] = (uint8_t)w; s[1] = (uint8_t)(w >> 8); s[2] = (uint8_t)(w >> 16); s[3] = (uint8_t)(w >> 24);
    }
  }
  h->cyc_copy += cycles() - t0;
}

static void pe_tweak(uint32_t ppn) { PE(SFX_PE_TWEAK_LO) = ppn; PE(SFX_PE_TWEAK_HI) = 0u; }

static int h_read(void *ctx, uint32_t ppn, void *data, void *spare, uint32_t *bitflips) {
  sfx_hal_t *h = (sfx_hal_t *)ctx;
  uint32_t t0 = cycles(), info = 0;
  h->reads++;
  uint32_t st = nand_op(h, SFS_NOP_READ_PAGE, ppn, 0u, SFX_RAW_BYTES, &info);
  int rc;
  if (st != SFS_NST_OK) {
    rc = (st == 0xFFu || st == SFS_NST_TIMEOUT) ? SFFTL_HAL_TIMEOUT : SFFTL_HAL_INVALID;
    goto out;
  }
  {
    uint32_t ps = pe_run(h, SFX_OP_BCH_DEC);
    if (!(ps & SFX_ST_DONE) || (ps & SFX_ST_ERR)) { rc = SFFTL_HAL_INVALID; goto out; }
    uint32_t r0 = PE(SFX_PE_RESULT0), code = r0 & 7u, nerr = (r0 >> 8) & 0xFFu;
    if (code == SFX_SS_UNCORR || code == SFX_SS_INTEGRITY) {
      if (code == SFX_SS_UNCORR) h->uncorrectable++; else h->integrity_fail++;
      copy_out(h, data, spare);
      rc = SFFTL_HAL_UNCORRECTABLE;
      goto out;
    }
    if (code == SFX_SS_ERASED) {
      h->erased_reads++;                               /* an erased page is all 0xFF: never decrypted */
    } else if (h->xts) {
      pe_tweak(ppn);
      ps = pe_run(h, SFX_OP_XTS_DEC);
      h->xts_ops++;
      if (!(ps & SFX_ST_DONE) || (ps & SFX_ST_ERR)) { rc = SFFTL_HAL_INVALID; goto out; }
    }
    copy_out(h, data, spare);
    if (bitflips) *bitflips = nerr;
    h->corrected_bits += nerr;
    if (code == SFX_SS_CORRECTED) { h->corrected_pages++; rc = SFFTL_HAL_CORRECTED; } else rc = SFFTL_HAL_OK;
  }
out:
  h->cyc_read += cycles() - t0;
  return rc;
}

static int h_program(void *ctx, uint32_t ppn, const void *data, const void *spare) {
  sfx_hal_t *h = (sfx_hal_t *)ctx;
  uint32_t t0 = cycles();
  if (sfx_power_fault()) return SFFTL_HAL_POWER_LOSS;      /* STOP policy: no program starts after a power fault */
  h->programs++;
  int rc;
  copy_in(h, data, spare);
  if (h->xts) {
    pe_tweak(ppn);
    uint32_t ps = pe_run(h, SFX_OP_XTS_ENC);
    h->xts_ops++;
    if (!(ps & SFX_ST_DONE) || (ps & SFX_ST_ERR)) { rc = SFFTL_HAL_INVALID; goto out; }
  }
  {
    uint32_t ps = pe_run(h, SFX_OP_BCH_ENC);
    if (!(ps & SFX_ST_DONE) || (ps & SFX_ST_ERR)) { rc = SFFTL_HAL_INVALID; goto out; }
    uint32_t st = nand_op(h, SFS_NOP_PROGRAM, ppn, 0u, SFX_RAW_BYTES, 0);
    if (st == SFS_NST_OK) rc = SFFTL_HAL_OK;
    else if (st == SFS_NST_PROG_FAIL) { h->nand_fail++; rc = SFFTL_HAL_PROGRAM_FAIL; }
    else if (st == SFS_NST_WP) rc = SFFTL_HAL_WRITE_PROTECT;
    else rc = (st == 0xFFu || st == SFS_NST_TIMEOUT) ? SFFTL_HAL_TIMEOUT : SFFTL_HAL_INVALID;
  }
out:
  h->cyc_prog += cycles() - t0;
  return rc;
}

static int h_erase(void *ctx, uint32_t pbn) {
  sfx_hal_t *h = (sfx_hal_t *)ctx;
  uint32_t t0 = cycles();
  if (sfx_power_fault()) return SFFTL_HAL_POWER_LOSS;      /* STOP policy: no erase starts after a power fault */
  h->erases++;
  uint32_t st = nand_op(h, SFS_NOP_ERASE, pbn * SFX_PPB, 0u, 0u, 0);
  h->cyc_erase += cycles() - t0;
  if (st == SFS_NST_OK) return SFFTL_HAL_OK;
  if (st == SFS_NST_ERASE_FAIL) { h->nand_fail++; return SFFTL_HAL_ERASE_FAIL; }
  if (st == SFS_NST_WP) return SFFTL_HAL_WRITE_PROTECT;
  return (st == 0xFFu || st == SFS_NST_TIMEOUT) ? SFFTL_HAL_TIMEOUT : SFFTL_HAL_INVALID;
}

static int h_marker(void *ctx, uint32_t ppn, uint8_t *m) {
  sfx_hal_t *h = (sfx_hal_t *)ctx;
  h->markers++;
  uint32_t st = nand_op(h, SFS_NOP_READ_PAGE, ppn, SFX_BBM_COL, 4u, 0);        /* raw: no ECC, outside every codeword */
  if (st != SFS_NST_OK) return SFFTL_HAL_INVALID;
  *m = (uint8_t)REG32(SLOT_ADDR(SLOT_RAW));
  return SFFTL_HAL_OK;
}

static void h_wp(void *ctx, int on) {
  sfx_hal_t *h = (sfx_hal_t *)ctx;
  uint32_t c = 0x2u | (on ? 0u : 1u);                                            /* CH_CTRL: CE_EN | WP_N */
  NAND(h->ch, SFS_NAND_CH_CTRL) = c;
}

int sfx_hal_init(sfx_hal_t *h, uint32_t ch, uint32_t *id0) {
  h->ch = ch;
  /* NAND bus timing: ONFI asynchronous timing MODE 0, the device's power-on default (the mode is volatile: it is mode 0 again after every
   * power cycle, and the P51 sequencer cannot issue SET FEATURES).  @100 MHz (10 ns): tWP = tRP = 50 ns, tWH = tREH = 50 ns (tWC = tRC = 100 ns),
   * tADL = 200 ns, tWHR = 120 ns, tWB covered by 20 cycles.  Found by the crash campaign: a faster setting works on the first power-up only. */
  NAND(ch, SFS_NAND_TIMING0) = 0x05050505u;
  NAND(ch, SFS_NAND_TIMING1) = 0x00001414u;          /* [7:0] tWHR/tADL = 20 cycles, [15:8] tWB = 20 cycles */
  NAND(ch, SFS_NAND_TIMEOUT) = 0x00200000u;
  NAND(ch, SFS_NAND_CH_CTRL) = 0x3u;                 /* WP_N, CE_EN (completion polled, no IRQ) */
  PE(SFX_PE_S_BASE) = SLOT_ADDR(SLOT_PLAIN);
  PE(SFX_PE_R_BASE) = SLOT_ADDR(SLOT_RAW);
  if (nand_op(h, SFS_NOP_RESET, 0, 0, 0, 0) != SFS_NST_OK) return -3;
  if (nand_op(h, SFS_NOP_READ_ID, 0, 0, 0, id0) != SFS_NST_OK) return -4;
  return 0;
}

void sfx_hal_bind(sfx_hal_t *h, sfftl_hal_t *hal) {
  hal->ctx = h;
  hal->read = h_read;
  hal->program = h_program;
  hal->erase = h_erase;
  hal->read_marker = h_marker;
  hal->write_protect = h_wp;
}

int sfx_key_load(const uint32_t *words, uint32_t nwords) {
  for (uint32_t i = 0; i < nwords && i < 16u; i++) PE(SFX_PE_KEY_W(i)) = words[i];
  PE(SFX_PE_KEY_CTRL) = 1u;                          /* commit: expand key schedules */
  uint32_t t0 = cycles();
  while (!(PE(SFX_PE_KEY_STATUS) & 1u)) if (cycles() - t0 > 100000u) return -1;
  return 0;
}
void sfx_key_zeroize(void) { PE(SFX_PE_KEY_CTRL) = 2u; }
