/* =============================================================================
 * SilicaFlux-STORE P60 firmware -- shared declarations
 *
 * Runs on the unmodified ControlCore RV32IM CPU.  Reuses the ControlCore runtime (crt0.S, trap_entry.S,
 * fw.ld, crc32.c, cc_hw.h, boot ROM, image format).  Derived from the Project 51 firmware framework
 * (platform / discovery / event handling); the FTL is the Project 58 (1.1) library (P56 core), the
 * command executor is new and synchronous, the NAND HAL drives the P60 page engine.
 * ===========================================================================*/
#ifndef SFX_FW_H
#define SFX_FW_H

#include <stdarg.h>
#include "cc_hw.h"
#include "sfs_map.h"
#include "sfx_regs.h"

#define FW_VERSION      0x00600100u          /* Project 60, firmware 1.0 */
#define TICK_CYCLES     20000u
#define WDT_PRESCALE    63u
#define WDT_LOAD        50000u
#define WDT_EWI         5000u

#define SYS(o)          REG32(SFS_SYS_BASE + (o))
#define CMDR(o)         REG32(SFS_CMD_BASE + (o))
#define SDMA(o)         REG32(SFS_DMA_BASE + (o))
#define NAND(c, o)      REG32(SFS_NAND_BASE + (uint32_t)(c) * SFS_NAND_CH_STRIDE + (o))
#define HIF(o)          REG32(SFS_HIF_BASE + (o))
#define PE(o)           REG32(SFX_PE_BASE + (o))
#define BUFW(a)         REG32(a)

#define SFS_CC_IRQ_IO   CC_IRQ_TENSOR
#define SFS_CC_IRQ_EVT  CC_IRQ_VECTOR
#define IO_SOURCES      (1u << SFS_IRQ_CMD)                   /* synchronous executor: only a new command wakes the CPU */
#define EVT_SOURCES     ((1u << SFS_IRQ_HIF) | (1u << SFS_IRQ_PLP) | (1u << SFS_IRQ_RAS))

/* ---- NAND device geometry (one channel, one LUN; the twin is configured to match, see scripts/gen_nand_cfg.py) */
#ifndef SFX_BLOCKS
#define SFX_BLOCKS      64u
#endif
#define SFX_PPB         16u
#define SFX_LBA_BYTES   512u
#define SFX_SLOT_STRIDE 544u                          /* NAND_PAGE_BYTES of the SoC build */
#define SLOT_PLAIN      0u                            /* S slot: data + 16-B spare record  */
#define SLOT_RAW        1u                            /* R slot: BCH raw page image        */
#define SLOT_HOST       2u                            /* host DMA staging / identify / log */
#define SLOT_ADDR(n)    (SFS_BUF_BASE + (uint32_t)(n) * SFX_SLOT_STRIDE)

typedef struct {
  uint32_t nch, cdw, dw_bytes, tags, ecc, ras, buf_bytes, page, aw, hqd;
} sfs_cfg_t;
extern sfs_cfg_t g_cfg;

void *memcpy(void *d, const void *s, size_t n);
void *memset(void *d, int c, size_t n);
int   memcmp(const void *a, const void *b, size_t n);
void  con_putc(char c);
void  con_puts(const char *s);
void  cprintf(const char *fmt, ...);
#include "cc_crc32.h"

extern volatile uint32_t g_io_irqs, g_evt_irqs, g_ticks, g_mbox_pending;
extern volatile uint32_t g_mbox[8];
void     platform_init(void);
uint32_t cycles(void);
void     wdt_service(void);
void     irqs_rearm(void);

/* ---- discovery / channel bring-up (hal.c) */
int  hal_init(void);                       /* 0 = ok */
int  dma_free(void);
void dma_submit(uint32_t src, uint32_t dst, uint32_t len, uint32_t tag);
int  dma_sync(uint32_t src, uint32_t dst, uint32_t len);   /* 0 ok, else SFS_DST_* */

/* ---- command executor (cmd.c) */
int  cmd_service(void);
void cmd_abort_pending(uint32_t st, uint32_t err);
extern uint32_t g_cmd_done, g_cmd_err, g_fw_errors;
extern volatile uint32_t g_resetting;

/* ---- FTL glue (ftl_glue.c) */
struct sfftl;
extern struct sfftl g_ftl_inst;
int  ftl_boot(void);                       /* mount (roll-forward recovery) or format a verifiably blank medium; 0 = ok, -100 = not blank */
int  ftl_format_explicit(void);            /* management FORMAT (only while not mounted) */
int  ftl_rebuild_explicit(void);           /* management REBUILD from the page spare records (only while not mounted) */
int  ftl_shutdown_clean(void);
uint64_t ftl_capacity(void);

#endif
