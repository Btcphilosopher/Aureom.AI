/* =============================================================================
 * SilicaFlux-STORE P60 firmware -- command executor (synchronous)
 *
 * Every command the hardware command controller accepted (validation, tag table) is popped from the
 * firmware queue and executed to completion before the next one starts; the hardware queues, tag table
 * and host SQ/CQ still provide queue depth (up to CMD_QUEUE_DEPTH commands outstanding at the host).
 *   READ        per LBA: sfftl_read -> staging slot -> DMA -> host        (unmapped LBA reads as zeros)
 *   WRITE       per LBA: DMA host -> staging slot -> sfftl_write            (ack only after program + map)
 *   FLUSH/FUA   sfftl_flush: pending journal records on the medium (page data is already durable)
 *   DEALLOCATE  sfftl_trim (acknowledged after its journal record is programmed)
 *   IDENTIFY / GET_LOG   512-byte structures -> DMA -> host
 *   PHYSICAL addressing, physical ERASE: refused (INVALID_FIELD) -- the FTL owns the medium
 * Completion status mapping: docs/02_HOST_INTERFACE.md.
 * ===========================================================================*/
#include "fw.h"
#include "sfftl.h"
#include "hal_sfx.h"

extern sfx_hal_t g_hw;
extern int g_ftl_up, g_xts_mode;

uint32_t g_cmd_done, g_cmd_err, g_fw_errors;
static uint32_t g_buf[128] __attribute__((aligned(4)));

static void finish(uint32_t tag, uint32_t nblk, uint32_t ce_bits, uint32_t st, uint32_t err) {
  CMDR(SFS_CMD_CPL_RESULT0) = nblk;                        /* blocks transferred */
  CMDR(SFS_CMD_CPL_RESULT1) = ce_bits;                     /* ECC bits corrected while serving the command */
  CMDR(SFS_CMD_CPL_POST) = tag | (st << 8) | (err << 16);
  g_cmd_done++;
  if (st != SFS_ST_SUCCESS) g_cmd_err++;
}

static void map_rc(int rc, uint32_t *st, uint32_t *err) {
  *err = SFS_ERR_NONE;
  switch (rc) {
    case SFFTL_OK:     *st = SFS_ST_SUCCESS; break;
    case SFFTL_ERANGE: *st = SFS_ST_LBA_RANGE; break;
    case SFFTL_EIO:    *st = SFS_ST_MEDIA_UNREC; *err = SFS_ERR_NAND_ECC_UE; break;
    case SFFTL_ENOSPC: *st = SFS_ST_CAPACITY; *err = SFS_ERR_FW; break;
    case SFFTL_EROFS:  *st = SFS_ST_MEDIA_WRITE; *err = SFS_ERR_NAND_FAIL; break;
    case SFFTL_EPOWER: *st = SFS_ST_ABORT_PWR_LOSS; *err = SFS_ERR_QUIESCED; break;
    case SFFTL_ESTATE: *st = SFS_ST_INTERNAL_ERR; *err = SFS_ERR_NOT_READY; break;
    default:           *st = SFS_ST_INTERNAL_ERR; *err = SFS_ERR_FW; g_fw_errors++; break;
  }
}

static void build_identify(uint32_t a) {
  uint32_t w[128];
  static const char model[32] = "SilicaFlux-STORE P60 MIN";
  memset(w, 0, sizeof(w));
  w[0] = SFS_SYS_ID_VALUE; w[1] = SYS(SFS_SYS_PROTO_VERSION); w[2] = SYS(SFS_SYS_HW_VERSION); w[3] = FW_VERSION;
  w[4] = (uint32_t)ftl_capacity(); w[5] = 0; w[6] = SFX_LBA_BYTES; w[7] = CMDR(SFS_CMD_MDTS);
  w[8] = g_cfg.nch; w[9] = g_cfg.tags; w[10] = SFX_PAGE_DATA; w[11] = SFX_PAGE_SPARE;
  w[12] = g_cfg.buf_bytes; w[13] = PE(SFX_PE_CAPS1); w[14] = SFX_BLOCKS; w[15] = SFX_PPB;
  memcpy(&w[16], model, sizeof(model));
  w[24] = SYS(SFS_SYS_CONFIG0); w[25] = SYS(SFS_SYS_CONFIG2);
  w[26] = (uint32_t)g_xts_mode | ((PE(SFX_PE_STATUS) & SFX_ST_KEY_READY) ? 2u : 0u);   /* XTS mode, key loaded */
  w[27] = 0;                                                                            /* no authentication */
  for (uint32_t i = 0; i < 128u; i++) BUFW(a + 4u * i) = w[i];
}

/* GET_LOG page 0x00: health / telemetry (layout: docs/02_HOST_INTERFACE.md, consumed by dashboard/) */
static void build_log(uint32_t a) {
  uint32_t w[128];
  const sfftl_stats_t *s = sfftl_stats(&g_ftl_inst);
  sfftl_space_t sp;
  memset(w, 0, sizeof(w));
  if (g_ftl_up) sfftl_space(&g_ftl_inst, &sp); else memset(&sp, 0, sizeof(sp));
  w[0] = 0x474F4C53u; w[1] = 0x00600001u;                                          /* "SLOG", layout version */
  w[2] = g_cmd_done; w[3] = g_cmd_err;
  w[4] = (uint32_t)s->host_write_cmds; w[5] = (uint32_t)s->host_read_cmds;
  w[6] = (uint32_t)s->host_lba_written; w[7] = (uint32_t)s->host_lba_read;
  w[8] = (uint32_t)s->nand_prog_host; w[9] = (uint32_t)s->nand_prog_reloc; w[10] = (uint32_t)s->nand_prog_meta;
  w[11] = (uint32_t)s->nand_erase_data; w[12] = (uint32_t)s->nand_erase_meta;
  w[13] = (uint32_t)s->gc_victims; w[14] = (uint32_t)s->gc_pages_moved; w[15] = (uint32_t)s->ckpt_count;
  w[16] = (uint32_t)s->blocks_retired; w[17] = (uint32_t)s->prog_fail; w[18] = (uint32_t)s->erase_fail;
  w[19] = (uint32_t)s->read_uncorrectable; w[20] = (uint32_t)s->read_corrected;
  w[21] = (uint32_t)s->crc_errors; w[22] = (uint32_t)s->lpn_mismatch;
  w[23] = g_hw.corrected_bits; w[24] = g_hw.corrected_pages; w[25] = g_hw.uncorrectable; w[26] = g_hw.integrity_fail;
  w[27] = g_hw.erased_reads;
  w[28] = sp.blocks_free; w[29] = sp.blocks_closed; w[30] = sp.blocks_bad_factory; w[31] = sp.blocks_bad_grown;
  w[32] = sp.ec_min; w[33] = sp.ec_max; w[34] = (uint32_t)sp.ec_sum; w[35] = sp.ec_blocks;
  w[36] = (uint32_t)sp.pages_valid; w[37] = (uint32_t)sp.nlba;
  w[38] = (uint32_t)s->mount_clean | ((uint32_t)s->mount_unclean << 8) | ((uint32_t)s->mount_rebuild << 16);
  w[39] = s->last_mount_pages_replayed; w[40] = s->last_mount_torn; w[41] = s->last_mount_fallback;
  w[42] = sp.read_only;
  w[43] = (uint32_t)g_xts_mode | ((PE(SFX_PE_STATUS) & SFX_ST_KEY_READY) ? 2u : 0u);
  w[44] = PE(SFX_PE_N_ENC); w[45] = PE(SFX_PE_N_DEC); w[46] = PE(SFX_PE_N_XTS); w[47] = PE(SFX_PE_N_ERR);
  w[48] = SYS(SFS_SYS_NAND_CE_COUNT); w[49] = SYS(SFS_SYS_NAND_UE_COUNT);
  w[50] = SYS(SFS_SYS_BUF_CE_COUNT); w[51] = SYS(SFS_SYS_BUF_UE_COUNT);
  w[52] = SYS(SFS_SYS_RAS_STATUS); w[53] = g_fw_errors;
  w[54] = SYS(SFS_SYS_PERF_CYCLES); w[55] = SYS(SFS_SYS_PERF_HOST_CMDS); w[56] = SYS(SFS_SYS_PERF_DMA_BYTES);
  w[57] = SYS(SFS_SYS_PERF_NAND_RD); w[58] = SYS(SFS_SYS_PERF_NAND_PG); w[59] = SYS(SFS_SYS_PERF_NAND_ER);
  w[60] = SYS(SFS_SYS_PERF_CMD_LATMAX); w[61] = SYS(SFS_SYS_PERF_NAND_BUSY);
  w[62] = g_hw.reads; w[63] = g_hw.programs; w[64] = g_hw.erases;
  w[65] = g_hw.cyc_read; w[66] = g_hw.cyc_prog; w[67] = g_hw.cyc_erase; w[68] = g_hw.cyc_pe; w[69] = g_hw.cyc_copy;
  w[70] = g_hw.nand_timeouts; w[71] = g_hw.pe_errors;
  for (uint32_t i = 0; i < 128u; i++) BUFW(a + 4u * i) = w[i];
}

static void cpu_load_block(uint32_t slot_addr, uint32_t *dst) {          /* staging slot -> RAM */
  for (uint32_t i = 0; i < 128u; i++) dst[i] = BUFW(slot_addr + 4u * i);
}
static void cpu_store_block(uint32_t slot_addr, const uint32_t *src) {   /* RAM -> staging slot */
  for (uint32_t i = 0; i < 128u; i++) BUFW(slot_addr + 4u * i) = src[i];
}

static void exec(uint32_t tag, uint32_t op, uint32_t flags, uint32_t lba, uint32_t nlb, uint32_t hbuf) {
  const uint32_t slot = SLOT_ADDR(SLOT_HOST);
  uint32_t st = SFS_ST_SUCCESS, err = SFS_ERR_NONE, i = 0, ce0 = g_hw.corrected_bits;
  if (g_resetting) { finish(tag, 0, 0, SFS_ST_ABORT_RESET, SFS_ERR_NOT_READY); return; }
  if (flags & SFS_SQE_FLAG_PHYS) { finish(tag, 0, 0, SFS_ST_INVALID_FIELD, SFS_ERR_ADDR_TYPE); return; }
  if (!g_ftl_up && op != SFS_OP_IDENTIFY && op != SFS_OP_GET_LOG) { finish(tag, 0, 0, SFS_ST_INTERNAL_ERR, SFS_ERR_NOT_READY); return; }
  switch (op) {
    case SFS_OP_READ:
      for (i = 0; i < nlb; i++) {
        int rc = sfftl_read(&g_ftl_inst, (uint64_t)lba + i, 1u, g_buf);
        if (rc != SFFTL_OK) { map_rc(rc, &st, &err); break; }
        cpu_store_block(slot, g_buf);
        if (dma_sync(slot, SFS_HOSTMEM_BASE + hbuf + i * SFX_LBA_BYTES, SFX_LBA_BYTES) != 0) {
          st = SFS_ST_DATA_XFER_ERR; err = SFS_ERR_DMA_WRITE; break;
        }
      }
      break;
    case SFS_OP_WRITE:
      for (i = 0; i < nlb; i++) {
        if (dma_sync(SFS_HOSTMEM_BASE + hbuf + i * SFX_LBA_BYTES, slot, SFX_LBA_BYTES) != 0) {
          st = SFS_ST_DATA_XFER_ERR; err = SFS_ERR_DMA_READ; break;
        }
        cpu_load_block(slot, g_buf);
        int rc = sfftl_write(&g_ftl_inst, (uint64_t)lba + i, 1u, g_buf);
        if (rc != SFFTL_OK) { map_rc(rc, &st, &err); break; }
      }
      if (st == SFS_ST_SUCCESS && (flags & SFS_SQE_FLAG_FUA)) {
        int rc = sfftl_flush(&g_ftl_inst);
        if (rc != SFFTL_OK) map_rc(rc, &st, &err);
      }
      break;
    case SFS_OP_FLUSH: { int rc = sfftl_flush(&g_ftl_inst); map_rc(rc, &st, &err); i = 0; break; }
    case SFS_OP_DEALLOCATE: {
      int rc = sfftl_trim(&g_ftl_inst, (uint64_t)lba, nlb);
      map_rc(rc, &st, &err);
      i = (rc == SFFTL_OK) ? nlb : 0u;
      break;
    }
    case SFS_OP_IDENTIFY:
    case SFS_OP_GET_LOG:
      if (op == SFS_OP_IDENTIFY) build_identify(slot); else build_log(slot);
      if (dma_sync(slot, SFS_HOSTMEM_BASE + hbuf, SFX_LBA_BYTES) != 0) { st = SFS_ST_DATA_XFER_ERR; err = SFS_ERR_DMA_WRITE; }
      i = 1;
      break;
    default: st = SFS_ST_INVALID_OPCODE; err = SFS_ERR_FW; break;
  }
  finish(tag, i, g_hw.corrected_bits - ce0, st, err);
}

int cmd_service(void) {
  int n = 0;
  uint32_t h;
  while ((h = CMDR(SFS_CMD_FWQ_HEAD)) & 0x80000000u) {
    uint32_t tag = h & 0xFFu, base = SFS_CMD_TAG_WIN + tag * SFS_CMD_TAG_STRIDE;
    uint32_t w0 = CMDR(base + 0u);
    uint32_t op = w0 & 0xFFu, flags = (w0 >> 8) & 0xFFu;
    uint32_t lba = CMDR(base + 8u), nlb = CMDR(base + 16u), hbuf = CMDR(base + 20u);
    CMDR(SFS_CMD_FWQ_POP) = 0u;
    exec(tag, op, flags, lba, nlb, hbuf);
    n++;
  }
  return n;
}

/* complete every command still queued (controller reset / shutdown) */
void cmd_abort_pending(uint32_t st, uint32_t err) {
  uint32_t h;
  while ((h = CMDR(SFS_CMD_FWQ_HEAD)) & 0x80000000u) {
    uint32_t tag = h & 0xFFu;
    CMDR(SFS_CMD_FWQ_POP) = 0u;
    finish(tag, 0, 0, st, err);
  }
}
