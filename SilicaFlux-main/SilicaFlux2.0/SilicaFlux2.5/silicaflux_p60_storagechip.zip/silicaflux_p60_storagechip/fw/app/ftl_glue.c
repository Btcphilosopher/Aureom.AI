/* =============================================================================
 * SilicaFlux-STORE P60 firmware -- FTL instance, boot policy, clean shutdown
 *
 * Automatic boot is strictly conservative -- it never destroys, and never silently "recovers into emptiness":
 *   1. sfftl_mount()   newest valid checkpoint (A/B retention) + journal + roll-forward of per-page spare records.  This is the normal
 *                      path after every clean or unclean shutdown.
 *   2. ENOFS (no loadable checkpoint):
 *        - the medium is VERIFIABLY BLANK (page 0 and the last page of every block read as erased; pages are programmed in order, so an
 *          erased page 0 means the block was never programmed after its erase)  ->  format (first boot of a new device)
 *        - anything else  ->  FTL_NOT_BLANK: the controller stays not-ready, the medium is untouched, and an explicit management command
 *          is required:  REBUILD (mount from the page spare records alone; recovers data if any survives; WRITES a recovery checkpoint)  or
 *          FORMAT (destroys content).  Reasons: a rebuild mount writes a checkpoint, so doing it automatically on a failed read path
 *          would leave a valid *empty* checkpoint and the next boot would serve an empty device over unreadable data; an earlier version
 *          of this firmware formatted whenever the rebuild found nothing, and the crash campaign turned a NAND-timing fault into data loss.
 * Durability: sfftl_write returns OK only after the page is programmed (status confirmed) and mapped; every page carries LPN + SEQ + CRC-32
 * in its spare record, so an acknowledged write survives power loss without any checkpoint (roll-forward).  No hold-up energy is assumed.
 * ===========================================================================*/
#include "fw.h"
#include "sfftl.h"
#include "hal_sfx.h"

#define ARENA_BYTES 12288u
static uint64_t g_arena[ARENA_BYTES / 8u];
struct sfftl g_ftl_inst;
sfx_hal_t g_hw;
static sfftl_hal_t g_hal;
static sfftl_cfg_t g_fcfg;
static const sfftl_geom_t g_geom = { SFX_PAGE_DATA, SFX_PAGE_SPARE, SFX_PPB, SFX_BLOCKS };
int g_ftl_up, g_fw_verify_write = 0;
int g_xts_mode;                                   /* set by main before ftl_boot */

uint64_t ftl_capacity(void) { return sfftl_capacity_lba(&g_ftl_inst); }

static void log_mount(void) {
  const sfftl_stats_t *s = sfftl_stats(&g_ftl_inst);
  sfftl_space_t sp;
  sfftl_space(&g_ftl_inst, &sp);
  cprintf("[ftl] mounted: %u LBAs, clean=%u, scanned %u replayed %u torn %u fallback %u incomplete %u meta-damaged %u, "
          "rebuild %u, valid pages %u, bad blocks %u+%u\n",
          (uint32_t)sp.nlba, s->last_mount_clean, s->last_mount_pages_scanned, s->last_mount_pages_replayed,
          s->last_mount_torn, s->last_mount_fallback, s->last_mount_incomplete, s->last_mount_meta_damaged,
          (uint32_t)s->mount_rebuild, (uint32_t)sp.pages_valid, sp.blocks_bad_factory, sp.blocks_bad_grown);
}

#define FTL_NOT_BLANK (-100)

static int ftl_prepare(void) {
  uint32_t id0 = 0;
  g_hw.xts = g_xts_mode;
  int hrc = sfx_hal_init(&g_hw, 0, &id0);
  cprintf("[ftl] NAND ch0: READ_ID %08x -> %d\n", id0, hrc);
  if (hrc) return -1;
  sfx_hal_bind(&g_hw, &g_hal);
  sfftl_cfg_default(&g_fcfg);
  g_fcfg.lba_bytes = SFX_LBA_BYTES;
  g_fcfg.flags |= SFFTL_F_VERIFY_READ_CRC;       /* end-to-end: CRC-32 of the plain data checked on every host read */
  if (g_fw_verify_write) g_fcfg.flags |= SFFTL_F_VERIFY_HOST_WRITE;
  sfftl_layout_t L;
  if (sfftl_layout_info(&g_geom, &g_fcfg, &L) != SFFTL_OK || L.total_bytes > sizeof(g_arena)) {
    cprintf("[ftl] arena too small: need %u have %u\n", (uint32_t)L.total_bytes, (uint32_t)sizeof(g_arena));
    return -2;
  }
  return 0;
}

/* 1 = every probed page reads as erased (data and spare all 0xFF, no ECC event); 0 = anything else */
static int medium_is_blank(void) {
  static uint32_t d[SFX_PAGE_DATA / 4u];
  uint32_t sp[SFFTL_OOB_BYTES / 4u];
  for (uint32_t b = 0; b < SFX_BLOCKS; b++) {
    for (uint32_t k = 0; k < 2u; k++) {
      uint32_t ppn = b * SFX_PPB + (k ? SFX_PPB - 1u : 0u), fl = 0;
      int st = g_hal.read(g_hal.ctx, ppn, d, sp, &fl);
      if (st != SFFTL_HAL_OK) { cprintf("[ftl] blank check: block %u page %u read status %d (not a clean erased page)\n", b, ppn % SFX_PPB, st); return 0; }
      for (uint32_t i = 0; i < SFX_PAGE_DATA / 4u; i++) if (d[i] != 0xFFFFFFFFu) { cprintf("[ftl] blank check: block %u page %u data word %u = %08x\n", b, ppn % SFX_PPB, i, d[i]); return 0; }
      for (uint32_t i = 0; i < SFFTL_OOB_BYTES / 4u; i++) if (sp[i] != 0xFFFFFFFFu) { cprintf("[ftl] blank check: block %u page %u spare word %u = %08x\n", b, ppn % SFX_PPB, i, sp[i]); return 0; }
    }
  }
  return 1;
}

int ftl_boot(void) {
  int rc = ftl_prepare();
  if (rc) return rc;
  rc = sfftl_mount(&g_ftl_inst, &g_geom, &g_fcfg, &g_hal, g_arena, sizeof(g_arena));
  if (rc == SFFTL_ENOFS) {
    if (medium_is_blank()) {
      cprintf("[ftl] no checkpoint and the medium is verified blank (page 0 / last page of every block erased): first-boot format\n");
      rc = sfftl_format(&g_ftl_inst, &g_geom, &g_fcfg, &g_hal, g_arena, sizeof(g_arena));
    } else {
      cprintf("[ftl] boot failed: no valid checkpoint on a medium that is NOT blank; refusing to format or rebuild automatically\n");
      g_ftl_up = 0;
      return FTL_NOT_BLANK;
    }
  }
  if (rc != SFFTL_OK) { cprintf("[ftl] boot failed: %s (%d)\n", sfftl_strerror(rc), rc); g_ftl_up = 0; return rc; }
  g_ftl_up = 1;
  log_mount();
  return 0;
}

/* management REBUILD (mailbox): mount from the page spare records alone; keeps whatever data survives; writes a recovery checkpoint */
int ftl_rebuild_explicit(void) {
  if (g_ftl_up) return -1;
  int rc = ftl_prepare();
  if (rc) return rc;
  sfftl_cfg_t rb = g_fcfg;
  rb.flags |= SFFTL_F_ALLOW_REBUILD;
  rc = sfftl_mount(&g_ftl_inst, &g_geom, &rb, &g_hal, g_arena, sizeof(g_arena));
  if (rc != SFFTL_OK) { cprintf("[ftl] explicit rebuild failed: %s\n", sfftl_strerror(rc)); return rc; }
  g_ftl_up = 1;
  log_mount();
  return 0;
}

/* management FORMAT (mailbox, guarded by a magic value): destroys the medium content, only while the FTL is not mounted */
int ftl_format_explicit(void) {
  if (g_ftl_up) return -1;
  int rc = ftl_prepare();
  if (rc) return rc;
  rc = sfftl_format(&g_ftl_inst, &g_geom, &g_fcfg, &g_hal, g_arena, sizeof(g_arena));
  if (rc != SFFTL_OK) { cprintf("[ftl] explicit format failed: %s\n", sfftl_strerror(rc)); return rc; }
  g_ftl_up = 1;
  log_mount();
  return 0;
}

int ftl_shutdown_clean(void) {
  if (!g_ftl_up) return 0;
  int rc = sfftl_shutdown(&g_ftl_inst);
  g_ftl_up = 0;
  return rc;
}
