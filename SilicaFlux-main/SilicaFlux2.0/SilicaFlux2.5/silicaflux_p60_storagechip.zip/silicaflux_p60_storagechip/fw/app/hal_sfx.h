/* =============================================================================
 * SilicaFlux-STORE P60 -- NAND HAL for the FTL (sfftl_hal.h contract) over
 *   sfs_nand_ctrl (raw page transfer, inline ECC off)  +  sfx_page_engine (XTS-AES, BCH t=8)
 *
 *   program: S slot <- data + 16-B FTL spare record;  [XTS_ENC];  BCH_ENC  S -> R;  PROGRAM raw R (544 B)
 *   read   : READ_PAGE raw -> R;  BCH_DEC  R -> S;  [XTS_DEC unless the page is erased];  S -> caller
 * The 16-B spare record is protected by the same BCH codeword as the data (FTL contract); it is NOT
 * encrypted (the FTL scans it at mount before any key policy could apply); the data is.
 * ===========================================================================*/
#ifndef SFX_HAL_H
#define SFX_HAL_H
#include <stdint.h>
#include "sfftl_hal.h"

typedef struct {
  uint32_t ch;
  int      xts;                       /* encrypt page data (key must be loaded) */
  /* statistics (also exported through GET_LOG) */
  uint32_t reads, programs, erases, markers;
  uint32_t corrected_pages, corrected_bits, uncorrectable, integrity_fail, erased_reads;
  uint32_t nand_timeouts, nand_fail, pe_errors, xts_ops;
  uint32_t cyc_read, cyc_prog, cyc_erase, cyc_pe, cyc_copy;
} sfx_hal_t;

int  sfx_hal_init(sfx_hal_t *h, uint32_t ch, uint32_t *id0);   /* channel reset + READ_ID, page engine slots */
void sfx_hal_bind(sfx_hal_t *h, sfftl_hal_t *hal);
int  sfx_key_load(const uint32_t *words, uint32_t nwords);     /* write key words, commit; 0 = ready */
void sfx_key_zeroize(void);
#endif
