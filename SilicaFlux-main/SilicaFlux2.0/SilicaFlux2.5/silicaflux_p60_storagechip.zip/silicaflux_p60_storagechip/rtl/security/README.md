# sfx_aes_xts -- XTS-AES storage encryption core ("SecureStore", SilicaFlux-STORE P60)

XTS-AES per IEEE Std 1619-2007 / NIST SP 800-38E, **whole 16-byte blocks only (no ciphertext
stealing)**, data unit = 1..65535 blocks. Plain SystemVerilog (no packages/imports/interfaces),
synthesizes with Yosys 0.33, `verilator --lint-only -Wall` clean, runs in Icarus 12 and Verilator 5.020.

```
T0 = AES_Enc(key2, tweak);  T_j = T0 * alpha^j  (GF(2^128), x^128+x^7+x^2+x+1, little-endian,
                                                  multiply-by-alpha = 128-bit left shift, 0x87 into byte 0)
C_j = AES_Enc(key1, P_j ^ T_j) ^ T_j            (decrypt: AES_Dec)
```

## Files

| file | content |
|---|---|
| `rtl/security/sfx_aes_xts.sv` | top: key register files, control FSM, T-register, stream handshake |
| `rtl/security/sfx_aes_core.sv` | iterative AES-128/256 encrypt+decrypt, 1 round/clock; schedule is an *input* |
| `rtl/security/sfx_aes_keyexp.sv` | iterative key-schedule generator (1 word/clock) |
| `rtl/security/sfx_aes_sbox.sv` | S-box / inverse S-box (constant table, generated from `model/xts_ref.py`) |
| `model/xts_ref.py` | golden model: python `cryptography` (OpenSSL) + independent pure-python AES/XTS, self-test |
| `tb/security/gen_xts_vectors.py` | writes the `$readmemh` vector files (cross-checks every vector with the pure-python model) |
| `tb/security/tb_sfx_aes_xts.sv` | self-checking testbench (`TB_PASS checks=N` / `TB_FAIL`) |
| `tb/security/run_security.sh` | generates vectors, Verilator `-Wall` lint, Icarus + Verilator runs (KEYBITS 128 and 256), Yosys stats; non-zero exit on failure |

## Interface (`sfx_aes_xts #(parameter int KEYBITS = 128)`; KEYBITS = size of EACH of the two keys: 128 or 256)

Port names/widths are exactly as specified; no deviations.

| port | dir | meaning |
|---|---|---|
| `clk`, `rst_n` | in | clock; synchronous active-low reset (clears everything incl. key material, needs a clock edge) |
| `key_we`, `key_widx[4:0]`, `key_wdata[31:0]` | in | write one key word. Words `0..KEYBITS/32-1` = key1 (data key), `KEYBITS/32..2*KEYBITS/32-1` = key2 (tweak key). `key = le32(w0)\|\|le32(w1)\|\|...` = key1\|\|key2 as the byte string given to python `cryptography` XTS. Write-only; no read path to any output. |
| `key_commit` | in | pulse: expand both schedules; `key_ready` drops until done |
| `key_zeroize` | in | pulse, highest priority: clears raw keys, both schedules, T/tweak state, AES state, expander window; `key_ready=0`; aborts any unit |
| `key_ready` | out | 1 = expanded keys valid |
| `start`, `decrypt`, `tweak[127:0]`, `nblocks[15:0]` | in | start a unit (sampled **only in the start cycle**). `tweak` = 128-bit little-endian sector number (tweak byte i = `tweak[8*i+:8]`) |
| `start_err` | out | registered 1-cycle pulse in the cycle after a rejected `start` |
| `in_valid`, `in_ready`, `in_data[127:0]` | in/out | input beats, byte i of the block = `in_data[8*i+:8]` |
| `out_valid`, `out_ready`, `out_data[127:0]`, `out_last` | out/in | output beats; `out_last` with the final block |
| `busy` | out | from the cycle after an accepted start until the last output beat has been consumed |

### Behaviour that the spec left open (all tested)

* **start accepted** only if: idle (no unit, no key expansion), `key_ready`, `nblocks != 0`, and no `key_we`/`key_commit`/`key_zeroize` in the same cycle. Otherwise ignored + `start_err` (one cycle later). `nblocks==0` is therefore rejected.
* **key_we** is accepted only when idle (not busy, not expanding) and `key_widx < 2*KEYBITS/32`; otherwise ignored. An accepted write drops `key_ready` (schedule no longer matches the key) -> re-commit needed.
* **key_commit** is accepted only when idle, not in the same cycle as `key_we`, and **all 2*KEYBITS/32 key words have been written since the last reset/zeroize**; otherwise silently ignored (so a zeroized all-zero key can never be committed by accident). `key_commit` while busy or while expanding is ignored.
* Priority in one cycle: `key_zeroize` > `key_we` > `key_commit` > `start`.
* **Zeroize/reset mid-unit**: state is cleared at the next clock edge; `busy=0`, `key_ready=0`. `in_ready` and `out_valid` are additionally gated *combinationally* by `key_zeroize`, so no beat is transferred in the zeroize cycle. `out_data` and `out_last` are 0 whenever `out_valid=0`.
* `tweak`, `decrypt`, `nblocks` need only be valid in the start cycle (the TB scrambles them afterwards). `in_data` is sampled only on `in_valid && in_ready`.
* Outputs may be back-pressured and inputs may have gaps; the engine holds `out_data/out_last` stable while `out_valid && !out_ready`.

## Timing (cycle 0 = the cycle in which `start` is high; measured & checked by the TB on every unstalled unit)

| | KEYBITS=128 (Nr=10) | KEYBITS=256 (Nr=14) |
|---|---|---|
| key_commit cycle -> first `key_ready` cycle | 85 (=2*40+5) | 109 (=2*52+5) |
| AES core latency (start cycle -> result valid) | 11 (=Nr+1) | 15 |
| first `in_ready` (T0 computed) | cycle 12 (=Nr+2) | 16 |
| first `out_valid` (unstalled) | cycle 23 (=2Nr+3) | 31 |
| **cycles per block (unstalled)** | **12 (=Nr+2)** | **16** |
| last beat of an N-block unit | 23 + 12(N-1) | 31 + 16(N-1) |
| 512 B (32 blocks) / 4 KiB (256 blocks), start -> last beat | 395 / 3083 | 527 / 4111 |
| throughput | 1.33 B/cycle (667 MB/s @ 500 MHz) | 1.00 B/cycle (500 MB/s @ 500 MHz) |

`busy` is low in the cycle after the last beat; a new `start` in that very cycle is accepted (tested). Clock frequency
was not evaluated (no timing analysis); the MB/s figures are arithmetic only. One block is processed at a time (no
pipelining / no overlap of block j+1 with the output of block j) -- the simplest handshake-safe structure.

## Architecture / resource estimate

`sfx_aes_core`: 16 S-boxes + 16 inverse S-boxes, ShiftRows/MixColumns/inverse, 1 round per clock, round-key
index counted up (enc) or down (dec) from the registered schedule (FIPS-197 straightforward inverse cipher). T0 uses
the same core with the key2 schedule. `sfx_aes_keyexp`: 4 S-boxes, one schedule word per clock, shared by key1 and key2
(key2 first expanded after key1). Key words are written straight into words 0..Nk-1 of the two schedule register
files (`rk1_q`, `rk2_q`); the expander fills the rest in place.

Yosys 0.33: `read_verilog -sv <4 files>; synth -top sfx_aes_xts -flatten; stat` (generic gate library, `check`: 0 problems):

| | cells | flip-flops | of which |
|---|---|---|---|
| KEYBITS=128 | **28068** | **3262** | rk1/rk2 schedules 2816, T 128, AES state 128, expander window 128, control ~60; `$_MUX_` 15439, `$_XOR_/XNOR_` 2595, `$_NOT_` 3985 |
| KEYBITS=256 | **31636** | **4422** | schedules 3840, T 128, state 128, window 256, control ~70; `$_MUX_` 16733, `$_XOR_/XNOR_` 2594, `$_NOT_` 5009 |

The LUT S-boxes (36 instances, ~420 cells each) dominate the logic; a composite-field S-box would shrink this a lot
(not done). Yosys needs about 2-4 GB RAM and ~1 min per run for this RTL (the S-box is written as a constant-vector
table; the equivalent `case` ROM needs far less memory but Yosys' `memory_dff` then retimes the AES state register
into 264 duplicated S-box output flops, which would inflate the flop count).

## Verification (all numbers from `run_security.sh`, last full run: ALL PASS)

| check | Icarus 12 (KEYBITS 128 / 256) | Verilator 5.020 (128 / 256) |
|---|---|---|
| total checks, `TB_PASS` | 3,225,996 / 3,995,181 | 8,553,876 / 10,776,452 |
| `sfx_aes_core` vs FIPS-197 App. B/C.1/C.3, SP 800-38A F.1.1/F.1.5 + random ECB (cryptography): 47 / 46 records, enc+dec, latency Nr+1, busy/vld pattern, start-while-busy ignored, clr | 2,650 / 3,347 | same |
| RTL key expansion vs python FIPS-197 schedule (both keys, every record; also expansion latency) | 9,024 / 11,776 | same |
| documented timing (first in_ready, out_valid, cycles/block, per beat on every unstalled unit) | 1,021 / 1,345 | same |
| XTS: 9 / 5 standard-structure units (IEEE 1619 v1-v3 + e/pi-key 512 B units), **310 random** units per key size (lengths 1,2,3,31,32,256 blocks: 60,60,60,50,50,30) + 16 special (tweak 0, all-ones, top-bit, 0x87; data 00/ff), each **encrypt, decrypt, and DUT-encrypt->DUT-decrypt round trip** vs `cryptography`: 335 / 331 units x 3 runs | 1,628,345 / 2,057,533 | same |
| back-pressure/gaps: 157 / 154 units x3 runs with random in_valid gaps and out_ready stalls (6 profiles incl. bursty, sparse, in_valid asserted before start) + extremes | 668,155 / 710,386 | same |
| protocol: start before key / incomplete key / nblocks=0 / after key_we rejected (+`start_err`), out-of-range key_widx ignored, start+key_we and start+key_commit same cycle, key_commit/key_we during expansion ignored, start/key_commit/key_we injected at every cycle of a busy unit (key registers unchanged, unit result still correct), start in last-beat cycle rejected, back-to-back units | 68,459 / 96,915 | same |
| key_zeroize at **every** cycle of a 3-block unit (48 / 64 points; also with output held stalled), same cycle as start, while idle, at 32 / 40 points of key expansion; reset (1 and 3 cycles) at 24 / 32 points; after each: busy/valid/ready low, no more beats, start rejected + `start_err`, commit without reload ignored, reload + full unit correct | 142,502 / 228,729 | same |
| **hierarchical check that key registers read zero** after zeroize/reset: `dut.rk1_q`, `dut.rk2_q` (raw keys + schedules), `dut.t_q`, `dut.u_kx.win_q`, `dut.u_core.state_q`, `dut.kmask_q` all `== 0` (and checked non-zero immediately before) | included above | included above |
| long unit (every beat compared, every beat's cycle checked) | 5000 blocks: 705,833 / 885,143 | **65535 blocks**: 6,033,713 / 7,666,414 |

Assertion-style monitors run on every clock (Icarus K=128 counts): A1 out_data/out_last/out_valid stable while stalled (66,295),
A2 no output beat before its input beat (124,735), A3 exactly one `out_last`, on the nblocks-th beat, and no beat beyond nblocks
(124,757), A4 `busy` high until the last beat consumed and low in the next cycle, no in_ready/out_valid while idle (898,402),
A5 `start_err` iff a start was not accepted (896,418).

Testbench sanity (mutation check): `tb/security/build/mut/run_mutants.py` (private helper, not a deliverable) injects 21 single-point RTL bugs
(T not advanced, zeroize leaving key2 / T / AES state, un-gated out_valid, start accepted while busy, key_we while busy, decrypt not latched,
out_last off by one, busy dropping early, start_err missing, commit without full key, nblocks==0 accepted, wrong Rcon / InvMixColumns / alpha
feedback, T0 with key1, AES core +1 cycle, in_valid or out_ready ignored, ...) and requires `TB_FAIL` from a subset of the TB groups: **21/21 detected**
(two first-draft mutants were equivalent no-ops and were replaced by real ones).

Reproduce: `tb/security/run_security.sh` (about 22 min on an idle core: Icarus ~15 min, Verilator builds ~3 min each).
Env knobs: `KEYBITS_LIST`, `LONGN_IV`, `LONGN_VL`, `SKIP_IVERILOG|SKIP_VERILATOR|SKIP_YOSYS=1`.
The TB accepts `+GROUPS=<hex>` to run a subset (bits: core, keyexp, latency, xts, stress, protocol, zeroize).

## Limits / not verified

* No ciphertext stealing: unit length must be a multiple of 16 bytes; max 65535 blocks (just under 1 MiB) per unit; AES-192 not supported.
* Published ciphertexts are hard-coded only for IEEE 1619 vectors 1-3 (typed in from the standard; cross-checked identical against the pure-python model, and v2/v3 against OpenSSL; v1 has key1==key2, which OpenSSL refuses, so v1 is checked against the pure-python model only) and the first 32 bytes of the 512-byte DUS=0 vector. All other expected values come from `cryptography` and are cross-checked with the independent pure-python XTS. No NIST CAVP files were available offline, so those are not run.
* Randomised, simulation-only verification; no formal proof, no gate-level / timing simulation, no clock-frequency or power estimate. Cell counts are Yosys generic gates, not a technology mapping.
* No side-channel or fault-injection countermeasures (LUT S-box, data-dependent switching); keys live in ordinary flip-flops and are cleared only while the clock runs.
* The zeroize pulse is combinationally visible on `in_ready`/`out_valid`; drive it from a register.
* Icarus prints harmless `$readmemh ... Not enough words in the file` warnings (memories are larger than the vector files).
