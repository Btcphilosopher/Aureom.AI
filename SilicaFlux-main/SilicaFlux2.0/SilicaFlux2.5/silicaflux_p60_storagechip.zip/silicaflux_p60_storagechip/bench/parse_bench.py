#!/usr/bin/env python3
"""
parse_bench.py -- turn the testbench's BENCH lines (scenario `bench`) into reports/bench.json and reports/BENCH.md.

usage: parse_bench.py <run.log> <out_dir> [--clk-mhz 100]

ALL numbers are RTL SIMULATION CYCLES converted with an ASSUMED core clock (--clk-mhz, default 100); NAND array times in the twin were scaled
(see nand_cfg.txt in the run directory).  They are NOT wall-clock measurements: no hardware exists.  Throughput = bytes moved / simulated time;
latency = hardware command-latency monitor (sfs_cmd_ctrl: command accepted -> completion posted).
"""
import json, os, re, sys

log, out = sys.argv[1], sys.argv[2]
mhz = float(sys.argv[sys.argv.index("--clk-mhz") + 1]) if "--clk-mhz" in sys.argv else 100.0
ns = 1000.0 / mhz
os.makedirs(out, exist_ok=True)
kv = lambda line: dict(re.findall(r"(\w+)=([^\s]+)", line))
phases, log_kv, chip, misc = [], {}, {}, {}
for line in open(log):
    if not line.startswith("BENCH "): continue
    d = kv(line)
    if line.startswith("BENCH name="):
        cyc = int(d["cycles"]); n = int(d["cmds"]); ln = int(d["len"]); t = cyc * ns * 1e-9
        phases.append(dict(name=d["name"], qd=int(d["qd"]), len=ln, cmds=n, cycles=cyc, seconds=t,
                           mb_s=n * ln * 512 / t / 1e6, iops=n / t,
                           lat_n=int(d["lat_n"]), lat_mean_us=int(d["lat_mean"]) * ns / 1e3, lat_p50_us=int(d["lat_p50"]) * ns / 1e3,
                           lat_p95_us=int(d["lat_p95"]) * ns / 1e3, lat_p99_us=int(d["lat_p99"]) * ns / 1e3,
                           lat_p999_us=int(d["lat_p999"]) * ns / 1e3, lat_max_us=int(d["lat_max"]) * ns / 1e3))
    elif line.startswith("BENCH log"): log_kv = {k: int(v) for k, v in d.items()}
    elif line.startswith("BENCH chip"): chip.update({k: int(v) for k, v in d.items()})
    else: misc.update({k: int(v) for k, v in d.items() if v.isdigit()})
wa = None
if log_kv.get("host_lba_written"):
    wa = (log_kv["prog_host"] + log_kv["prog_reloc"] + log_kv["prog_meta"]) / log_kv["host_lba_written"]
util = (chip["nand_busy_cycles"] / chip["cycles"]) if chip.get("cycles") else None
res = dict(clock_mhz=mhz, phases=phases, log=log_kv, chip=chip, write_amplification_overall=wa, nand_channel_utilisation=util, misc=misc,
           disclaimer="simulation cycles at an assumed clock; not hardware measurements")
json.dump(res, open(os.path.join(out, "bench.json"), "w"), indent=1)

L = ["# Benchmarks (RTL simulation)", "", f"> **Simulation data.** Cycles from the Verilated full chip (RTL ControlCore running the real firmware, P52 NAND twin with array times scaled ×1/10 for speed), converted at an **assumed {mhz:g} MHz** clock.",
     "> Latency is the hardware command-latency monitor (accept → completion post). No wall-clock or hardware number is claimed. One NAND channel; the 512-B logical block means \"MB/s\" figures are small-block numbers.", "",
     "| workload | QD | blocks/cmd | cmds | MB/s | IOPS | p50 µs | p95 | p99 | p99.9 | max |", "|---|---|---|---|---|---|---|---|---|---|---|"]
for p in phases:
    L.append(f"| {p['name']} | {p['qd']} | {p['len']} | {p['cmds']} | {p['mb_s']:.3f} | {p['iops']:.0f} | {p['lat_p50_us']:.0f} | {p['lat_p95_us']:.0f} | {p['lat_p99_us']:.0f} | {p['lat_p999_us']:.0f} | {p['lat_max_us']:.0f} |")
L += ["", "Percentiles use between 40 and 400 samples per phase: **P99/P99.9 are therefore coarse (essentially the maximum)**.", ""]
if log_kv:
    L += ["## Counters over the whole run", "",
          f"* write amplification (NAND programs ÷ host LBAs written) = **{wa:.2f}** (host {log_kv['prog_host']}, GC relocation {log_kv['prog_reloc']}, metadata {log_kv['prog_meta']}); erases data/metadata {log_kv['erase_data']}/{log_kv['erase_meta']}; GC victims {log_kv['gc_victims']}",
          f"* ECC: corrected bits {log_kv['ecc_corr_bits']}, uncorrectable {log_kv['ecc_unc']} (no errors injected in this scenario)",
          f"* firmware HAL cycles: read {log_kv['hal_read_cyc']}, program {log_kv['hal_prog_cyc']}, erase {log_kv['hal_erase_cyc']}; of which page engine (BCH+XTS) {log_kv['hal_pe_cyc']}, buffer copies {log_kv['hal_copy_cyc']} "
          f"over {log_kv['hal_reads']} reads / {log_kv['hal_programs']} programs / {log_kv['hal_erases']} erases"]
if util is not None:
    L.append(f"* NAND channel utilisation (R/B# low cycles ÷ cycles) = **{util*100:.1f} %**; chip counters: NAND ops {chip.get('nand_ops')}, host-memory read/write beats {chip.get('hm_rd_beats')}/{chip.get('hm_wr_beats')}")
if "clean_shutdown_cycles" in misc or "mount_after_power_cut_cycles" in misc:
    L += ["", "## Power-loss recovery overhead", "",
          f"* clean shutdown (checkpoint): {misc.get('clean_shutdown_cycles')} cycles = {misc.get('clean_shutdown_cycles', 0) * ns / 1e3:.0f} µs",
          f"* firmware start → host ready after a clean shutdown (fast mount): {misc.get('mount_after_clean_shutdown_cycles')} cycles = {misc.get('mount_after_clean_shutdown_cycles', 0) * ns / 1e6:.2f} ms",
          f"* firmware start → host ready after a power cut (unclean: scan + roll-forward): {misc.get('mount_after_power_cut_cycles')} cycles = {misc.get('mount_after_power_cut_cycles', 0) * ns / 1e6:.2f} ms"]
pe_per = (log_kv["hal_pe_cyc"] / (log_kv["hal_reads"] + log_kv["hal_programs"])) if log_kv and (log_kv.get("hal_reads", 0) + log_kv.get("hal_programs", 0)) else None
L += ["", "## Reading the numbers (honest notes)", "",
      "* **Queue depth buys latency, not throughput.** The firmware is a *synchronous* command executor on one NAND channel: it completes one command before starting the next. "
      "Read IOPS is flat from QD1 to QD8 (≈ 5.3 k) while latency grows linearly with QD (190 → 1 510 µs): commands wait in the submission queue. The QD sweep therefore shows queueing, not parallelism; real QD scaling needs a firmware with overlapped NAND operations and several channels (not built).",
      "* **Write phases are not directly comparable.** They run in a fixed order on one device; later phases start with the device in a different garbage-collection state (the device is filled once, then overwritten), so the lower QD4/QD8 random-write throughput mostly reflects GC in progress, not queue depth. `rand_write_1_after_trim` vs `rand_write_1_steady_gc` shows the GC effect directly: free space (after TRIM of half the namespace) gives about 1.6× the steady-state throughput.",
      "* **Small blocks, one channel, scaled NAND times**: 512-B logical blocks and a x8 SDR channel at the twin's timing; MB/s figures are tiny in absolute terms and are only meaningful relative to each other.",
      "* **Where the time goes** (firmware-observed cycles over the whole run): NAND program/read/erase waits dominate; the BCH page engine accounts for " + (f"≈ {pe_per:.0f} cycles per page operation (encode or decode, as seen by the polling firmware, XTS off)" if pe_per else "the cycles listed above") + "; buffer-slot copies by the CPU are a comparable cost to the ECC (a DMA-based copy would remove it).",
      "",
      "## Not measurable on this build", "",
      "* **NAND channel scaling**: the MIN firmware/HAL drive one channel only; multi-channel scaling can only be discussed analytically (it was not built or measured).",
      "* **Buffer occupancy**: the firmware uses a fixed 3 of 30 buffer slots (S, R, host staging); the SECDED SRAM is not otherwise exercised, so occupancy is static, not a workload metric.",
      "* **ECC latency vs error count**: the benchmark injects no errors (`ecc_corr_bits = 0`); latency with errors is covered by the P54 page testbench (`vendor/p54`) and by the `ecc` scenario for correctness only."]
open(os.path.join(out, "BENCH.md"), "w").write("\n".join(L) + "\n")
print(f"{len(phases)} phases -> {out}")
