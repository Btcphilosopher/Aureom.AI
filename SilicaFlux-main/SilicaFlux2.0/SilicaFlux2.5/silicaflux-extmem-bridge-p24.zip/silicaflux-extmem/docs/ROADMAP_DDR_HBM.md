# DDR / HBM integration roadmap

What exists today: a verified-in-simulation bridge (single clock and with a
controller-clock crossing), a generic controller contract (SFMC), a simulation
controller model, and design notes for three adapter families.  What does
**not** exist: any real controller, PHY, adapter for real IP, FPGA bitstream
with DRAM, hardware run, or calibration evidence.  This roadmap lists the work
between the two, in order, with the evidence each step must produce before it
can be claimed.

All standard parameters in §4 and §5 are public summary values (JEDEC press
releases, vendor product briefs, the Aureom HBM digital-twin tables).  They
are for planning; re-check every number against the licensed JEDEC documents
(JESD79-3/-4/-5, JESD209-4/-5, JESD235D, JESD238, JESD270-4) and the chosen
vendor's datasheets before using it in a design decision.

## 1. Phases

| Phase | Content | Status | Exit evidence |
|---|---|---|---|
| P0 | Single-clock bridge + simulation controller model, full regression | **done** | `reports/regression.md`, `reports/mutation.md`, cross-simulation identity |
| P1 | Controller-clock crossing (`ASYNC = 1`), DataFabric integration (real crossbar + DMA) | **done in simulation** | async configs in the regression; `reports/df_integration.log`; CDC constraints are templates only |
| P2 | First real controller on an FPGA (§2) | not started — needs a board + toolchain decision | adapter TB against the vendor's own DRAM simulation model; timing closure report; hardware calibration log; memory-test log |
| P3 | Bandwidth path on the DataFabric: SFB2-X masters (DMA bursts) or crossbar §8 (IDs, multiple outstanding per slave port) | not started | DMA SRAM↔EXT copy at ≥ 0.9 beat/cycle in simulation (today ≈ 5 % of peak behind the rev 2.0 crossbar) |
| P4 | ASIC DDR with licensed controller + PHY (§3) | research | IP selection matrix, AXI4 adapter with C9 hazard tracking, PHY training firmware plan, I/O ring / package plan |
| P5 | HBM integration study (§5) | research | per-stack architecture, interposer/package plan, power/thermal budget, IP quotes |

## 2. P2 — first FPGA DDR controller ("when available")

### 2.1 Board / controller options

| Option | Memory | Controller | Toolchain | Pros | Cons |
|---|---|---|---|---|---|
| **A** Digilent Arty A7-100T | DDR3L x16, 256 MiB | Xilinx MIG 7-series UI (part of Vivado, no extra licence for 7-series) | Vivado (free edition covers XC7A100T) | mature IP, vendor DRAM sim model, calibration status pin; repo already has an Arty A7-100T constraint file | vendor flow (SilicaFlux FPGA work so far is open-tool only); UI read path cannot stall (adapter credit) |
| **B** ECP5 board with DDR3 (e.g. LambdaConcept ECPIX-5, OrangeCrab) | DDR3 / DDR3L | LiteDRAM (open source) | Yosys + nextpnr (the SilicaFlux flow) | same open flow as SilicaFlux-V; DDR | LiteX/Migen generation step; init/calibration via LiteX firmware; new board |
| **C** ULX3S (already the SilicaFlux board) | 16-bit **SDR** SDRAM | LiteDRAM SDR PHY | open flow | no new hardware; first real external-memory traffic through the bridge | **not DDR**; low bandwidth; proves the adapter / error / reset path only |

Recommendation: **C first** (cheapest proof of the adapter boundary on hardware
the project already uses), then **A or B** for the DDR target.  Template
configurations: `config/templates/fpga_ulx3s_sdram_litedram.json`,
`config/templates/fpga_arty_a7_ddr3l_mig.json`.

### 2.2 Steps and acceptance criteria

1. **Adapter RTL** (`rtl/adapters/extmem_<ip>_adapter.sv`) implementing
   docs/MC_INTERFACE.md §5.x, including tag FIFO, burst splitting, address-unit
   conversion, strobe/mask polarity, write-response generation and C9.
2. **Adapter verification in simulation against the vendor's own model**:
   MIG example design + the DRAM vendor's DDR3 Verilog model, or LiteDRAM's
   simulation; run `tb/extmem_mc_checker.sv` on the SFMC side and the existing
   test list (`run_regress.py` with a new controller kind).
3. **Timing closure** in the vendor tool / nextpnr with the CDC constraints of
   `constraints/` (convert the template, check every query matches), report
   attached.
4. **Hardware bring-up**: read `STATUS` through the SilicaFlux-V CPU / JTAG
   SBA; `READY` must follow the controller's own calibration flag.  Only a
   captured log of that flag on the board may be quoted as calibration
   evidence.
5. **Memory test firmware** (walking 1/0, address-in-address, random with
   read-back over the whole device, DMA copies, concurrent CPU + DMA), with
   results captured from the UART; error counters (`ERR_COUNT`, `PERF`) read
   back.
6. **Reset / fault paths on hardware**: `CONTROL.MC_RESET` during traffic,
   bridge reset during traffic; confirm recovery and data integrity of
   post-recovery writes.

Until steps 4–5 are done the correct statement is: *"verified in simulation
against a behavioural controller model; not validated on hardware".*

## 3. P4 — ASIC DDR (licensed controller + PHY)

* **IP**: a controller + PHY pair from one vendor (e.g. Synopsys, Cadence,
  Rambus controller + partner PHY), controller↔PHY over **DFI**, user side
  **AXI4** (one or more ports).  The bridge connects through the AXI4 adapter
  (§5.3 of MC_INTERFACE.md); C9 is not guaranteed by AXI and must be provided
  by the adapter or a future bridge mode.
* **Process node**: DDR/LPDDR PHYs are hard macros qualified per foundry node.
  SilicaFlux's PPA templates target 130 / 65 / 28 nm (DataFabric
  `synth/asic/`); DDR5 / LPDDR5 PHYs are typically offered at much smaller
  nodes, so the standard follows the node (older nodes → DDR3/DDR4/LPDDR2-4
  class).  Confirm availability with vendors before choosing the standard.
* **Integration work**: PHY training firmware (on an embedded controller or
  the SilicaFlux-V CPU), PHY test/BIST hooks into SilicaFlux DFT, I/O ring
  with the PHY's dedicated pad cells, package substrate routing, SI/PI
  simulation, board design, ECC policy (side-band or inline), refresh /
  thermal management, power states.
* **Address space**: the 32-bit SFB2 address limits the window to < 4 GiB
  (2 GiB at `0x8000_0000`).  Larger DRAM needs 40+-bit addresses in SFB2-X
  (the bridge's `MC_AW` already supports up to 48) or a page/window register.
* Template: `config/templates/asic_ddr5_axi_licensed.json` (placeholders).

### 3.1 DRAM standards (planning values)

| Standard | Data rate (MT/s) | Device / channel width | Burst | I/O voltage | Peak per channel |
|---|---|---|---|---|---|
| DDR3 / DDR3L | 800 – 2133 | x4/x8/x16; 64-bit DIMM channel | BL8 (BC4) | 1.5 V / 1.35 V | 17 GB/s @ 2133, 64 bit |
| DDR4 | 1600 – 3200 | x4/x8/x16; 64(+8)-bit channel | BL8 | 1.2 V | 25.6 GB/s @ 3200 |
| DDR5 | 4800 – 8800 | two independent 32(+8)-bit subchannels per DIMM | BL16 | 1.1 V | 19.2 GB/s per subchannel @ 4800 |
| LPDDR4 / 4X | up to 4266 | 16-bit channels | BL16/32 | 1.1 V / 0.6 V | 8.5 GB/s per x16 channel |
| LPDDR5 / 5X | up to 6400 / 8533 | 16-bit channels | BL16/32 | 0.5 V-class | 12.8 / 17 GB/s per x16 channel |

Bridge sizing: one bridge saturates one channel when
`DW × f_fabric ≥ channel peak` and `MAX_RD_OUT × burst ≥ round-trip latency × 1 beat/cycle`
(measured in reports/throughput.md §1: sustained = Little's-law bound within 0.8 %).
Example: DDR4-3200 x64 (25.6 GB/s) → DW = 256 at 800 MHz, or DW = 512 at 400 MHz.

## 4. HBM generations (planning values, per stack)

| | HBM2 | HBM2E | HBM3 | HBM3E | HBM4 |
|---|---|---|---|---|---|
| JEDEC document | JESD235A/B | JESD235C/D | JESD238 (2022) | vendor extensions of HBM3 | JESD270-4 (2025) |
| Interface width | 1024 bit | 1024 bit | 1024 bit | 1024 bit | 2048 bit |
| Channels × width | 8 × 128 | 8 × 128 | 16 × 64 | 16 × 64 | 32 × 64 |
| Pseudo-channels | 16 × 64 | 16 × 64 | 32 × 32 | 32 × 32 | 64 × 32 |
| Data rate / pin | ≤ 2.0 Gb/s | ≤ 3.2–3.6 Gb/s | ≤ 6.4 Gb/s | ~8–9.8 Gb/s (vendor) | ≤ 8 Gb/s (JEDEC; vendors announce higher) |
| Peak per stack | 256 GB/s | 410–460 GB/s | 819 GB/s | ~1.0–1.25 TB/s | 2 TB/s at 8 Gb/s |
| Burst | BL2/BL4 (pseudo-channel mode BL4) | BL4 | BL8 | BL8 | BL8 |
| Access granule per pseudo-channel | 32 B | 32 B | 32 B | 32 B | 32 B |
| Stack height / capacity | up to 8-Hi / 8 GB | up to 12-Hi / 24 GB | up to 16-Hi / 64 GB | 8/12-Hi, 24/36 GB | 4–16-Hi, up to 64 GB |
| I/O voltage (VDDQ) | 1.2 V | 1.2 V | 0.4 V (VDD 1.1 V) | 0.4 V class | 0.7–0.9 V options (VDDC 1.0/1.05 V) |

## 5. P5 — abstract HBM integration contract

### 5.1 Structure

```
 SFB2-X masters ──► address-interleaving crossbar (new) ──► N × silicaflux_extmem_bridge
                                                            (one per pseudo-channel or PC group)
                                                                 │ SFMC → AXI4 adapter
                                                                 ▼
                                    licensed HBM controller (AXI4 ports, per-PC queues, refresh,
                                    ECC, training) ── DFI ──► HBM PHY (die edge) ── interposer ──► HBM stack
```

* One bridge per pseudo-channel keeps each bridge simple (one address space,
  one tag space, independent ordering).  Interleaving granule ≥ 32 B (PC
  access) and ≤ `2^BOUND_LOG2`, chosen with the controller's address map.
* Sizing (HBM3, 6.4 Gb/s): per PC 32 bit × 6.4 Gb/s = 25.6 GB/s ⇒ bridge
  `DW = 256` at 800 MHz (25.6 GB/s per direction) — 32 bridges per stack
  (`config/templates/hbm3_research.json`).  `MAX_RD_OUT` from Little's law
  with the controller's loaded latency (tens to hundreds of ns).
* Per-channel status: each PC's `mc_init_done` / `mc_fatal` and a
  per-channel fault isolation (a failed PC returns `UNAVAIL` for its address
  range only) — the bridge already isolates failures per instance.

### 5.2 Contract additions needed beyond today's SFMC

| Item | Why |
|---|---|
| ≥ 40-bit addresses on SFB2-X | a stack is up to 64 GB |
| per-beat poison / ECC status (`mc_rd_error` today) + corrected-error counter | HBM controllers report CE/UE separately |
| thermal / refresh-rate status (`mc_temp_hi`) | HBM refresh doubles above ~85 °C; software throttling |
| power-state request/ack | self-refresh / power-down entry for idle channels |
| `MC_UNORDERED` mode in the bridge | AXI ports do not order reads against writes (C9) |
| burst coalescing / 32-B granule alignment | single-beat SFB2 traffic wastes most of each 32-B access |

### 5.3 Physical integration (study items, not implemented)

* **Package**: 2.5D silicon interposer (e.g. CoWoS-class), organic RDL
  interposer or silicon bridges (EMIB-class).  Micro-bump pitch in the
  tens of µm; on the order of 1 000–2 000+ signal connections per stack
  (HBM4 roughly doubles the data I/O).  PHY must sit on the die edge facing
  the stack (shoreline), with short (mm-scale) interposer routes.
* **Power**: interface power ≈ bandwidth × energy/bit.  Example only:
  819 GB/s × 8 bit/B × 3 pJ/bit ≈ 20 W per HBM3 stack at full bandwidth (the
  3 pJ/bit is an **assumed** literature-order value; get vendor numbers under
  NDA).  Plus PHY idle power, refresh, controller logic.
* **Thermal**: stack temperature limits and refresh derating; HBM sits next
  to the hottest die — thermal co-design with SilicaFlux ThermalLab.
* **Test / yield**: known-good-stack-die (KGSD) procurement, IEEE 1500 test
  port on the HBM, PHY loopback / BIST, interposer test; repair (spare rows /
  lanes) flows from the controller vendor.
* **Licensing / supply**: HBM controller and PHY are licensed IP (several
  vendors offer HBM3/3E/4 controller and/or PHY); HBM stacks are bought from
  the DRAM vendors (allocation-constrained); interposer assembly at an OSAT /
  foundry advanced-packaging line.

## 6. Bridge features to add before P3–P5

| Feature | Reason | Notes |
|---|---|---|
| SFB2-X DMA (bursts, IDs) or crossbar §8 | bandwidth on today's fabric is latency bound | measured 0.21 B/cycle vs 4 B/cycle peak |
| `MC_UNORDERED` mode | AXI / relaxed-ordering controllers | hazard check against issued-but-incomplete slots |
| registered-read buffer option | ASIC SRAM macros for large `MAX_*_OUT × MAX_BURST` | +1 pipeline stage |
| burst splitting at boundaries (instead of rejecting) | masters that cannot respect 4 KiB | split completion in the ROB |
| burst coalescing | single-beat traffic to 32-B-granule memories | needs a split-response path |
| width converter in the bridge | controllers with a native width ≠ fabric DW | today: adapter |
| formal proofs (no lost / duplicate response, no tag reuse) | complement simulation + mutation | Yosys-SMTBMC as in DataFabric |
