# SFMC — generic memory-controller interface

The contract between the portable bridge and a **controller adapter**.  The
bridge drives the master side; an adapter (one per controller family) turns it
into the controller's native user interface.  The only implementation of the
slave side in this release is the simulation model `sim/models/extmem_sim_mc.sv`;
the passive checker `tb/extmem_mc_checker.sv` encodes the rules below and can be
reused unchanged in front of a vendor controller's simulation model.

## 1. Signals (bridge = master)

| Group | Signal | Width | Dir (bridge) | Meaning |
|---|---|---|---|---|
| status | `mc_rst_n` | 1 | out | controller reset request, active low (held for `RST_HOLD` fabric cycles; synchronised to `mc_clk` when `ASYNC = 1`) |
| | `mc_init_done` | 1 | in | controller initialised and **calibrated** (level) |
| | `mc_fatal` | 1 | in | unrecoverable controller error (level) |
| command | `mc_cmd_valid` / `mc_cmd_ready` | 1 / 1 | out / in | command handshake |
| | `mc_cmd_write` | 1 | out | 1 = write |
| | `mc_cmd_addr` | MC_AW | out | **byte** offset inside the window, DW aligned |
| | `mc_cmd_len` | LW | out | beats − 1 (≤ MAX_BURST − 1), INCR, never crosses 2^BOUND_LOG2 |
| | `mc_cmd_tag` | TW | out | transaction tag (read and write tags are separate name spaces) |
| write data | `mc_wd_valid` / `mc_wd_ready` | 1 / 1 | out / in | beat handshake |
| | `mc_wd_data` / `mc_wd_strb` | DW / DW/8 | out | data, byte enables (1 = write byte) |
| | `mc_wd_last` | 1 | out | last beat of the write command |
| read data | `mc_rd_valid` / `mc_rd_ready` | 1 / 1 | in / out | beat handshake (the bridge keeps `ready = 1`) |
| | `mc_rd_data` | DW | in | data |
| | `mc_rd_tag`, `mc_rd_last`, `mc_rd_error` | TW, 1, 1 | in | tag, last beat of that tag, beat failed |
| write response | `mc_wr_valid` / `mc_wr_ready` | 1 / 1 | in / out | handshake (the bridge keeps `ready = 1`) |
| | `mc_wr_tag`, `mc_wr_error` | TW, 1 | in | tag, write failed |

`TW = max(log2 MAX_RD_OUT, log2 MAX_WR_OUT)`.  All signals are synchronous to
`clk` (`ASYNC = 0`) or `mc_clk` (`ASYNC = 1`).

## 2. Rules (checked by `extmem_mc_checker`, IDs C1–C8)

| # | Rule |
|---|---|
| C1/C2/C3 | valid/ready on every channel: a presented beat keeps `valid` and its payload until accepted (also for the controller's responses). Exception: while `mc_rst_n = 0` everything is discarded. |
| C4 | The bridge never re-issues a tag that is still live (live = issued and its last read beat / write response not yet returned). |
| C5 | Each read tag returns exactly `len + 1` beats with `rd_last` on the final one. Beats of different tags **may interleave** and tags may complete **in any order**. |
| C6 | Each write tag returns exactly one write response, after all its data beats were accepted, and only once the write has reached the controller's ordering point. |
| C7 | Write data is sent in write-command order, never interleaved between commands, `wd_last` on each command's final beat. At the bridge-core side data follows its command's acceptance; behind the CDC (`ASYNC = 1`) a data beat may become visible up to one controller cycle **before** its command — the controller/adapter must buffer it. |
| C8 | No X/Z on valid/ready out of reset. |
| C9 | **Ordering point:** accesses whose byte ranges overlap take effect in command-acceptance order (a read accepted after a write sees it; a write accepted after a read does not affect it), regardless of completion order. *An adapter for a controller without this guarantee must add the hazard tracking itself (§5.3).* |
| C10 | Deadlock freedom: the controller accepts write commands without waiting for their data, and accepts write data for accepted commands without waiting for further commands. The bridge never waits for a response to issue a command it already holds. |
| C11 | `mc_init_done` may drop at any time (calibration loss); the bridge treats it as a fault (flush) and resets the controller. `mc_fatal` likewise. |

## 3. What the bridge guarantees to the adapter

* `mc_rd_ready = mc_wr_ready = 1` in the single-clock core: buffer space for
  every beat of every issued read is reserved, so an adapter for a controller
  whose read path cannot stall (Xilinx MIG UI) needs no read buffer of its own
  when `ASYNC = 0`.
* At most `MAX_RD_OUT` reads and `MAX_WR_OUT` writes are live.
* Commands never cross `2^BOUND_LOG2` bytes or the window end.
* After `mc_rst_n` rises nothing is issued until `mc_init_done = 1`.

## 4. Error semantics

`mc_rd_error` marks a failed beat (bridge reports `MC_RD`, beat data is
replaced by 0).  `mc_wr_error` fails the whole write (`MC_WR`).  Whether a
failed write left partial data is controller-defined; the bridge reports the
error and makes no claim.

## 5. Adapter mappings (design notes — no adapter for real IP is delivered)

None of the controllers below is available in this project (no Vivado, no MIG
netlist, no LiteDRAM build, no licensed ASIC IP; docs/AUDIT.md §6).  The
tables state what an adapter must do; they are taken from the public interface
documentation and must be re-checked against the exact IP version used.

### 5.1 Xilinx 7-series MIG, native User Interface (UG586)

Typical target: Arty A7-100T (DDR3L x16, 4:1 controller ⇒ `APP_DATA_WIDTH = 2·4·16 = 128`).

| SFMC | MIG UI | Adapter work |
|---|---|---|
| `mc_rst_n` | `sys_rst` (polarity per IP option), plus wait for `ui_clk_sync_rst` low | reset sequencing; `mc_clk = ui_clk` (`ASYNC = 1`) |
| `mc_init_done` | `init_calib_complete` | direct |
| `mc_fatal` | — | tie 0 (or a timeout of the adapter's own) |
| `mc_cmd_*` | `app_en`, `app_cmd` (000 write / 001 read), `app_addr`, `app_rdy` | a burst of `len+1` beats → `len+1` UI commands (one UI word = one BL8 burst); `app_addr` is in DQ-width units: byte offset / 2 for x16, +8 per UI word; command accepted on `app_en && app_rdy` |
| `mc_wd_*` | `app_wdf_wren`, `app_wdf_data`, `app_wdf_mask`, `app_wdf_end`, `app_wdf_rdy` | **`app_wdf_mask = ~strb`** (mask 1 = byte not written); `app_wdf_end = 1` on every word in 4:1 mode |
| `mc_rd_*` | `app_rd_data`, `app_rd_data_valid`, `app_rd_data_end` | **no ready on the UI read path**: with `ASYNC = 1` the adapter needs a read buffer sized for all outstanding reads (credit) or must limit issue; tags restored from an in-order tag FIFO (UI returns reads in request order) |
| `mc_wr_*` | — (no write response) | generate when the last data word and the command are both accepted; requires C9 to hold in MIG — use `ORDERING = "STRICT"` unless the read-after-write behaviour of "NORM" is confirmed for the IP version |
| width | 128-bit UI | configure the bridge `DW = 128`, or add a width converter in the adapter |

### 5.2 LiteDRAM native user port (open source, `litedram` / LiteX)

Relevant because SilicaFlux's FPGA flow is open (Yosys / nextpnr / ECP5):
LiteDRAM supports ECP5 DDR3 boards and, through its SDR PHY, the ULX3S SDRAM.

| SFMC | LiteDRAM native port | Adapter work |
|---|---|---|
| `mc_cmd_*` | `cmd.valid/ready/we/addr/last` | one native command per beat (address in port-word units); burst → sequence |
| `mc_wd_*` | `wdata.valid/ready/data/we` | `we` = byte enables |
| `mc_rd_*` | `rdata.valid/ready/data` | in order: tag FIFO, beat counter for `last` |
| `mc_wr_*` | — | generate after data accepted; port-level ordering of LiteDRAM must be confirmed for C9 |
| `mc_init_done` | SoC-level init/calibration done (LiteX software-driven init) | requires LiteX BIOS/firmware or a hardware init sequence |

### 5.3 AXI4 (MIG-AXI, Versal NoC/DDRMC, LiteDRAM-AXI, licensed ASIC controllers)

| SFMC | AXI4 | Adapter work |
|---|---|---|
| `mc_cmd_*` write / read | AW / AR: `AxADDR = base + addr`, `AxLEN = len`, `AxSIZE = log2(DW/8)`, `AxBURST = INCR`, `AxID = tag` | split by `mc_cmd_write`; keep `BOUND_LOG2 ≤ 12` (AXI 4 KiB rule) |
| `mc_wd_*` | W (`WSTRB`, `WLAST`) | direct (AXI4 has no WID; order = AW order, same as C7) |
| `mc_rd_*` | R (`RID`, `RLAST`, `RRESP`) | `error = RRESP[1]`; interleaving across IDs allowed by both |
| `mc_wr_*` | B (`BID`, `BRESP`) | `error = BRESP[1]` |
| C9 | **not guaranteed by AXI** between the read and write channels | the adapter must hold a read overlapping an un-acknowledged write (and vice versa) until the B / last R response — or the bridge's planned `MC_UNORDERED` mode (ROADMAP) does it |

Licensed ASIC DDR/LPDDR/HBM controllers (e.g. from Synopsys, Cadence, Rambus)
typically expose one or more AXI4 ports and connect to the PHY through DFI; the
AXI4 adapter is therefore the ASIC integration path for both DDR and HBM.

## 6. Clocking options

| Case | Configuration |
|---|---|
| controller user clock = fabric clock | `ASYNC = 0` |
| controller user clock (e.g. MIG `ui_clk`) ≠ fabric clock | `ASYNC = 1`, `CDC_DEPTH` ≥ 8, `RST_HOLD` per `scripts/extmem_cfg.py`, constraints in `constraints/` |
| HBM: one controller per (pseudo-)channel | one bridge per channel group + an address-interleaving crossbar (ROADMAP), or an AXI4 multi-port controller |
