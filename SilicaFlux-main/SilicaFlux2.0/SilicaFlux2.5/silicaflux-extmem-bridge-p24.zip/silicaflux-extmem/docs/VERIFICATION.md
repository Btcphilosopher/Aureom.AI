# Verification

## 1. Environment

```
            tb_extmem (self-checking, Verilator 5.020 and Icarus 12, cycle-identical)
 ┌──────────────────────────────────────────────────────────────────────────────────────┐
 │ SFB2-X driver ─► silicaflux_extmem_bridge ─► extmem_sim_mc (SIMULATION-ONLY model)    │
 │   │  ▲              ▲          ▲                 ▲        │ mem[] (end-state compare) │
 │   │  │ responses    │ err_evt  │ perf counters   │        │                           │
 │   ▼  │              │          │                 │        ▼                           │
 │ reference model ── scoreboard ─┴── checks ───────┘  model contract checks             │
 │ (bytes + known flags,  extmem_sfbx_checker (upstream)    extmem_mc_checker (MC side)   │
 │  acceptance order)     sfb_protocol_checker (DataFabric, unmodified, SFB2 configs)     │
 └──────────────────────────────────────────────────────────────────────────────────────┘
 tb_df_integration: bridge behind the unmodified DataFabric sfb_crossbar + dma_burst_engine / dma_transfer_engine
```

**Independent DRAM transaction model.**  The reference model is a byte array
plus a per-byte *known* flag, updated only from the upstream transaction
stream in acceptance order — the semantics a master is promised
(PROTOCOL_SFB2X.md X10).  It never looks into the bridge or the controller
model.  Read data is predicted at acceptance; at the end the controller
model's storage is compared byte-for-byte with every known reference byte, so
lost writes, misdirected writes and wrong strobes are caught even if never
read back.  A byte becomes *unknown* only where the outcome is legitimately
undefined (writes accepted while the controller fails or the bridge resets —
SFB2 R11).  Expected errors are predicted independently from the
specification (RANGE / ALIGN / LEN / BOUNDARY / PROTO / UNAVAIL / poisoned
range) and the error **code** reported on the capture sideband is checked
against the predicted cause.

**Simulation controller model** (`sim/models/extmem_sim_mc.sv`, labelled
SIMULATION ONLY): calibration delay, command and write-data back-pressure,
in-order execution (C9), per-bank timelines + shared data-bus slot reservation
(genuinely out-of-order completion), random latency, optional beat
interleaving, poisoned range, random read errors with garbage data, and
failure injection (`tb_cal_drop`, `tb_hang`, `tb_fatal`).

**Determinism.**  All randomness comes from xorshift32 generators drawn in
plain statements (never inside expressions), so a seed reproduces the run
exactly and Verilator and Icarus produce byte-identical output (verdict,
statistics, all 32 performance counters) — a cross-check of 2-state vs
4-state semantics and of simulator scheduling.

## 2. Requirement traceability

| Requirement (brief §9) | Test(s) | What is checked |
|---|---|---|
| Short reads | `short_reads`, `smoke`, `sfb2_compat` | single-beat reads after streamed writes; data per byte |
| Long bursts | `long_bursts`, `big_burst` config (64 × 256-bit) | max-length bursts both directions, framing, data |
| Partial writes | `partial_writes`, every test (`strb_mode` 2) | random / sparse / empty strobes; byte-exact reference and end-state |
| Concurrent reads/writes | `concurrent_rw` (hot 512 B and 128 B regions, all IDs, command back-log), `soak` | RAW / WAR / WAW ordering through queues, scheduler and controller |
| Random controller latency | `random_latency` (1–200 cycles, 40 % ready on every channel) | no loss / duplication / misassociation under heavy jitter |
| Out-of-order responses | `ooo`, configs `mc_ooo_inorder_up`, `ooo_full`, `rprio_batch`, `odd_slots` | controller completes and interleaves out of order; in-order upstream restored (SFB2 R5) or per-ID order (UP_OOO = 1) |
| Reset during traffic | `reset_traffic` (4 random resets of 1–20 cycles mid-traffic) | no response during / after reset for pre-reset transactions, recovery, post-reset integrity |
| Controller unavailable | `unavail` (before calibration), `mc_unavailable` (calibration loss ×3 incl. with commands stuck, controller hang → watchdog, fatal flag, calibration timeout → CALFAIL → reset request), `quiesce_reset`, `stall_policy` config | UNAVAIL errors, flush, every accepted transaction answered exactly once, recovery |
| Response errors | `mc_errors` (poisoned range, random read errors with garbage data) | error beats, rdata = 0, no side effect of failed writes, codes MC_RD / MC_WR |
| Address bounds | `addr_bounds` (random illegal kinds + deterministic window edges: one beat past the end, overrun by one beat, one beat below base, last legal beat, top of address space) | RANGE / ALIGN / LEN / BOUNDARY with the correct code, no controller access |
| Write/read data integrity | every test | per-byte read prediction + end-state memory comparison |
| Back-pressure | `backpressure` (upstream ready 10 %, controller ready 5 %), bubbles in every test | no overflow, held payloads (X1/X2, C1–C3) |
| Burst framing errors | `proto_err` | PROTO error, write not performed |
| CSR / error status / counters | `csr`, `check_perf` in every test | register map, RO/W1C/sub-word rules, error capture, freeze/clear, counters = scoreboard |
| Clock-domain crossing | configs `async_fast_mc` (137 MHz), `async_slow_mc` (43.5 MHz), all tests | async FIFOs, reset/status synchronisers, flush across domains |
| DataFabric integration | `tb_df_integration` (2 DMA engines × 2 latencies) | real crossbar + DMA: byte-exact SRAM→EXT→SRAM copies, concurrent host traffic, WRITE_BUS / READ_BUS propagation, CSR via crossbar, DataFabric checker on 6 ports |

## 3. Checkers

| Checker | Rules |
|---|---|
| scoreboard (`tb_extmem`) | exactly one response per transaction; none unsolicited / duplicated; order (global or per ID); contiguous response beats; beat count / `rsp_last`; `rsp_write`; must / may / must-not error per beat; error code vs cause; data of known bytes; end-state memory; counters vs scoreboard; bridge idle at the end |
| `extmem_sfbx_checker` | X1 request held, X2 response held, X3 rdata = 0 on error/write, X4 single-beat write response, X5 no X/Z |
| `sfb_protocol_checker` (DataFabric) | SFB2 R2, R4, R5, R6, R8, X/Z — SFB2 configurations and every port of the integration TB |
| `extmem_mc_checker` | C1–C8 of MC_INTERFACE.md (stability, tag uniqueness, beat counts, write data before response, framing) |
| `extmem_sim_mc` | tag reuse, payload changes under back-pressure, data without command (strict), framing, address range |

## 4. Mutation testing

`scripts/mutate.py` injects 33 realistic design bugs (one text substitution
each, across frontend, tracker, scheduler, ROB, link FSM and CDC FIFO) and
requires the suite to fail.  Survivors of the first rounds exposed real
holes, all closed (docs/ISSUES.md "Findings"): missing error-code check,
missing directed window-edge cases, no command back-log, a sticky-flag bug in
the watchdog test, redundant zeroing.  One mutant is a documented equivalent
(range check off by one *byte*: an aligned burst can never end there).
Results: `reports/mutation.md`.

## 5. Not covered

* No real controller, PHY or DRAM; no hardware.
* No formal proofs; no CDC structural analysis (lint / metastability
  injection) — the binary-pointer CDC mutant was killed only through its
  functional side effect.
* No gate-level simulation of the bridge.
* The controller model is not timing-accurate to any DRAM standard.

## 6. Results

| Report | Content |
|---|---|
| `reports/regression.md` / `.json` | full matrix: 12 configurations × 17 tests × 3 seeds (Verilator) + Icarus identical-output runs |
| `reports/df_integration.log` | DataFabric crossbar + DMA integration |
| `reports/mutation.md` | mutation results |
| `reports/lint.md` | Verilator -Wall over 21 parameter sets, Icarus elaboration |
| `reports/throughput.md` | performance characterisation |
| `reports/synth.md` | Yosys / nextpnr-ecp5 |
