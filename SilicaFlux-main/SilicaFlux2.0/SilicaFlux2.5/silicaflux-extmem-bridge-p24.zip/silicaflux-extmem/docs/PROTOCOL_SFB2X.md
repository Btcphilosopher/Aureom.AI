# SFB2-X — the bridge's upstream transaction interface

SFB2-X is SFB2 rev 2.0 (DataFabric, `third_party/silicaflux-datafabric/docs/datafabric/PROTOCOL.md`)
plus the **additive** extension that DataFabric's PROTOCOL.md §8 already plans:
transaction IDs, bursts and several outstanding transactions.  With
`req_len = 0`, `req_last = 1`, `req_id = 0` and in-order responses it *is*
SFB2 rev 2.0: the bridge then plugs into an `sfb_crossbar` slave port
unchanged (verified with the unmodified DataFabric crossbar, DMA engines and
`sfb_protocol_checker`, `tb/tb_df_integration.sv`).

## 1. Signals (bridge = slave)

| Signal | Width | Dir (at bridge) | Meaning | SFB2 rev 2.0 |
|---|---|---|---|---|
| `up_req_valid` / `up_req_ready` | 1 / 1 | in / out | request beat handshake | same |
| `up_req_write` | 1 | in | 1 = write | same |
| `up_req_addr` | AW = 32 | in | **byte** address of the first beat, DW aligned | same |
| `up_req_wdata` / `up_req_wstrb` | DW / DW/8 | in | write data / byte enables of this beat | same |
| `up_req_id` | IDW | in | transaction ID | new (tie 0) |
| `up_req_len` | LW | in | beats − 1 (reads: response beats; writes: request beats) | new (tie 0) |
| `up_req_last` | 1 | in | last request beat of a write burst | new (tie 1) |
| `up_rsp_valid` / `up_rsp_ready` | 1 / 1 | out / in | response beat handshake | same |
| `up_rsp_rdata` | DW | out | read data; 0 on error beats and write responses | same |
| `up_rsp_error` | 1 | out | this beat failed | same |
| `up_rsp_id` | IDW | out | ID of the transaction this beat belongs to | new |
| `up_rsp_last` | 1 | out | last beat of the response (always 1 for writes) | new |
| `up_rsp_write` | 1 | out | the response belongs to a write | new (informative) |

## 2. Address and data semantics

* Byte addresses, little-endian: byte lane *b* (`[8b+7:8b]`) of beat *k*
  carries address `addr + k·DW/8 + b`.
* `addr` must be DW-aligned (SFB2 R9).  Burst type is incrementing.
* Sub-word / unaligned **data** is supported only through byte strobes on an
  aligned beat (any pattern, including none and sparse); reads always return
  whole beats.  A misaligned **address** is rejected with `ALIGN` — there is
  no unaligned-address mechanism, by design (the requirement: "only through an
  explicitly verified mechanism"; strobes are that mechanism and are verified
  by `partial_writes` and the reference model byte-by-byte).
* The window is `[EXT_BASE, EXT_BASE + EXT_SIZE)`; the controller sees the
  byte offset `addr − EXT_BASE` on `MC_AW` bits.  Addresses outside are never
  aliased.
* A burst must lie inside the window and inside one `2^BOUND_LOG2`-byte
  region (4 KiB by default, the AXI rule).  It is not split.

## 3. Rules

| # | Rule |
|---|---|
| X1 | A request beat transfers on `req_valid && req_ready`; a held beat keeps `valid` and its payload until accepted (SFB2 R2). |
| X2 | A read is **one** request beat; `req_len + 1` response beats follow. `req_last` is ignored for reads. |
| X3 | A write is `req_len + 1` request beats, sent contiguously (no other transaction's beat in between; idle cycles allowed). Only beat 0's `write/addr/id/len` are used; later beats carry `wdata/wstrb/last`, the rest is don't-care. |
| X4 | The write burst ends at the first beat with `req_last = 1` or at beat `req_len`, whichever comes first. If they disagree the write is answered `PROTO` and **not performed**. |
| X5 | Exactly one response per transaction: `len+1` beats for a read (`rsp_last` on the final one), one beat for a write. Beats of one response are contiguous. |
| X6 | `UP_OOO = 0`: responses in acceptance order over all IDs and both directions (SFB2 R5). `UP_OOO = 1`: per-ID acceptance order; different IDs may complete out of order. |
| X7 | A response is held stable while `rsp_valid && !rsp_ready` and `rsp_valid` never depends on `rsp_ready` (SFB2 R4). `req_ready` depends only on `req_write`, registered state and (with `UNAVAIL_POLICY = 1`) the controller status inputs `mc_init_done` / `mc_fatal`. |
| X8 | `rsp_error = 1` ⇒ `rsp_rdata = 0`; writes always return `rsp_rdata = 0` (SFB2 R8). |
| X9 | Write completion: the write response is returned only after the controller reported the write done (its ordering point), so later reads of any master see it (SFB2 R7). |
| X10 | Memory semantics: a read returns, for every byte, the value of the last write to that byte accepted before the read (in-order execution semantics), whatever the scheduler or controller completion order. |
| X11 | Reset (asynchronous assert) cancels every transaction: no response is delivered for it; a write accepted before reset may or may not have been performed (SFB2 R11). |

## 4. Errors

`rsp_error` marks failed beats.  The cause is captured in the CSR page
(`ERR_STATUS.CODE`, `ERR_ADDR`, `ERR_COUNT`) and on the `err_*` sideband:

| Code | Name | Detected by | Side effect | Beats returned |
|---|---|---|---|---|
| 1 | RANGE | frontend: burst not inside the window | none | all beats error |
| 2 | ALIGN | frontend: address not DW aligned | none | all |
| 3 | LEN | frontend: `len + 1 > MAX_BURST` | none | all (`len + 1` beats) |
| 4 | BOUNDARY | frontend: burst crosses `2^BOUND_LOG2` | none | all |
| 5 | UNAVAIL | frontend: link not READY (`UNAVAIL_POLICY = 0`) | none | all |
| 6 | MC_RD | controller read-data error (e.g. uncorrectable ECC) | none | the failing beats |
| 7 | MC_WR | controller write-response error | controller-defined | 1 |
| 8 | FLUSH | controller fault / watchdog: incomplete transaction aborted | write: undefined | the beats not yet received |
| 9 | PROTO | write framing error (X4) | none | 1 |

Errors detected by the frontend never reach the controller.

## 5. Back-pressure and capacity

* A first beat is accepted only if a ROB entry and (for a legal transaction)
  a slot of the right direction are free; inside a write burst the bridge is
  always ready (buffer space reserved at the first beat).
* Upstream response back-pressure (`rsp_ready = 0`) stalls only the ROB
  output; read data keeps arriving into the slot buffers, so the controller
  is never back-pressured by the bridge.
* Up to `ROB_DEPTH` accepted transactions (default `MAX_RD_OUT + MAX_WR_OUT + 2`)
  plus one in the response register can be outstanding at the port.

## 6. Connecting to the DataFabric today

| Upstream | Configuration | Notes |
|---|---|---|
| `sfb_crossbar` slave port (rev 2.0) | tie `req_id = 0`, `req_len = 0`, `req_last = 1`; `UP_OOO = 0` | crossbar allows one outstanding per slave port -> latency bound (reports/throughput.md §5) |
| DataFabric buffered DMA, direct | as above (`dma_burst_engine` tracks `MAX_OUT`) | several outstanding single beats, in order |
| SFB2-X master (future DMA / HPC tile) | bursts + IDs, `UP_OOO` per master capability | full bandwidth |
