# Configuration schema

One JSON file describes one bridge instance and the controller behind it.

* Schema: `config/extmem_config.schema.json` (JSON Schema 2020-12).
* Validator / generator: `scripts/extmem_cfg.py` (no third-party packages).

```bash
python3 scripts/extmem_cfg.py validate config/regress/*.json config/templates/*.json
python3 scripts/extmem_cfg.py params config/templates/fpga_arty_a7_ddr3l_mig.json --fmt sv          # instance overrides
python3 scripts/extmem_cfg.py params config/regress/base.json --fmt tb-verilator                     # testbench -G flags
```

## Sections

| Key | Content |
|---|---|
| `status` | `verified-in-simulation` (in the regression, simulation model only) · `template-unvalidated` (real target, never built) · `research` (study) |
| `upstream.protocol` | `SFB2` (DataFabric rev 2.0 crossbar slave) or `SFB2-X` |
| `bridge` | RTL parameters (docs/ARCHITECTURE.md §9); `EXT_BASE` / `EXT_SIZE` as hex strings |
| `clocks` | `fabric_mhz`, `mc_mhz` (controller user clock) |
| `controller` | `kind` (`sim_model`, `xilinx_mig7_ui`, `litedram_native`, `axi4_licensed`, `hbm_research`), `available`, simulation-model knobs |
| `memory` | standard, capacity, data rate, width, channels and **provenance** of those numbers |
| `regression` | tests, seeds, transactions, Icarus cross-check |

## Cross-field rules enforced by the validator

| Rule | Reason |
|---|---|
| `MAX_BURST` power of two, ≤ 2^`LW` | buffer indexing, length field |
| `EXT_BASE`, `EXT_SIZE` multiples of DW/8, size > 0, base + size ≤ 2^32 | SFB2 alignment, 32-bit map |
| 2^`MC_AW` ≥ `EXT_SIZE` | controller offset must fit |
| `MAX_BURST` × DW/8 ≤ 2^`BOUND_LOG2` | a maximum burst must fit in one boundary region |
| `BOUND_LOG2` ≤ 12 for MIG / AXI controllers | AXI 4 KiB rule |
| `WR_LO` < `WR_HI` when `SCHED_MODE = 1` | batching hysteresis |
| `UP_OOO = 0` for `SFB2` upstream | SFB2 R5 |
| `ASYNC = 0` ⇒ `mc_mhz == fabric_mhz` | single clock |
| `RST_HOLD` ≥ `CDC_SYNC` + 2 + ⌈(`CDC_SYNC`+1)·f_fab/f_mc⌉ when `ASYNC = 1` | stale `init_done` must be flushed through the synchroniser before CAL |
| `available` must be false for every non-simulation controller | no vendor controller exists in the project (docs/AUDIT.md §6) |
| `verified-in-simulation` ⇒ `sim_model`, base `0x8000_0000`, `EXT_SIZE` = 2^`MC_AW` ≤ 1 MiB | testbench constraints |
| SFB2 regression configs: ROB depth + 1 ≤ 8 | lets the unmodified DataFabric checker run its R8 check |

## Files

| Directory | Files |
|---|---|
| `config/regress/` | 12 configurations run by `scripts/run_regress.py` |
| `config/templates/` | `fpga_ulx3s_sdram_litedram`, `fpga_arty_a7_ddr3l_mig`, `asic_ddr5_axi_licensed` (template-unvalidated), `hbm3_research` (research) |
