# Known issues, limitations and findings

## Open limitations of the bridge

| ID | Item | Impact | Plan |
|---|---|---|---|
| XM-1 | No real controller adapter (MIG / LiteDRAM / AXI4) | bridge proven only against a behavioural model | ROADMAP P2 |
| XM-2 | No hardware run, no DRAM calibration evidence | nothing about DRAM operation can be claimed | ROADMAP P2 steps 4–6 |
| XM-3 | Bursts crossing `2^BOUND_LOG2` or the window end are rejected, not split | masters must respect 4 KiB | ROADMAP §6 |
| XM-4 | Misaligned addresses rejected (`ALIGN`); unaligned data only via strobes | by design (SFB2 R9) | — |
| XM-5 | Controller must order overlapping accesses (contract C9); AXI does not | AXI4 adapter must track hazards | `MC_UNORDERED` mode, ROADMAP §6 |
| XM-6 | 32-bit upstream addresses: window < 4 GiB | large DDR / HBM need wider addresses | ROADMAP §3, §5.2 |
| XM-7 | ECP5-85F post-route Fmax 27.4–57.0 MHz (reports/synth.md). Critical path = the ROB's combinational entry selection → read-buffer address / error capture → response register; with `UP_OOO = 1` the per-ID "no older entry with the same ID" comparison over all ROB entries makes it the slowest configuration (27.4 MHz, just above the 25 MHz SilicaFlux-V SoC clock) | all configurations meet the current 25 MHz ULX3S SoC clock, none a 100 MHz fabric | pre-compute the next selection one cycle ahead (registered candidate) and register the error-capture inputs; cap the ROB depth for `UP_OOO = 1` |
| XM-8 | Buffers use asynchronous-read RAM (LUT RAM) | large ASIC configurations want 1R1W SRAM macros | registered-read option, ROADMAP §6 |
| XM-9 | CDC verified by simulation only (no CDC lint, no metastability injection) | structural CDC bugs could escape (the binary-pointer mutant was caught only through its functional side effect) | run a CDC tool on the ASYNC configuration; validate constraints in Vivado |
| XM-10 | No formal proofs | simulation + mutation only | Yosys-SMTBMC properties (no lost / duplicate response, tag uniqueness) |
| XM-11 | Behind the DataFabric rev 2.0 crossbar only one transaction is outstanding | external-memory bandwidth ≈ 5 % of the port peak (measured) | SFB2-X DMA or crossbar §8 (ROADMAP P3) |
| XM-12 | Performance counters are 32-bit saturating; latency timestamps 16-bit | latencies > 65 535 cycles wrap in `*_LAT_*` | widen if needed |
| XM-13 | Experimental scheduler (`SCHED_MODE = 1`) shows no robust benefit in the model (−2.7 % … +1.7 %) | FIFO remains the default | re-evaluate only against a real controller |

## Findings during development (all fixed before the final runs)

| Finding | Found by | Fix |
|---|---|---|
| Verilator re-orders / duplicates calls of impure functions (functions that update module state), so Verilator and Icarus consumed the PRNG differently; the model's `timing()`/`pick()` were impure too | Verilator-vs-Icarus output diff | all side-effecting helpers turned into tasks; runs now byte-identical across simulators |
| Side-effecting calls inside `&&` / `?:` (short-circuit evaluation differs between simulators) | same | random draws as plain statements |
| MC checker dropped write-data beats that arrive before their command (legal behind the CDC) | false C6 violations in the async configurations | early beats queued and matched in command order |
| DataFabric checker `MAX_OUT` must be ROB depth + 1 (the registered response stage holds one more) | DataFabric checker R6 | TB parameter |
| TB generated multi-beat / `len > 0` error requests in the SFB2-only configuration (impossible for a rev 2.0 master) | DataFabric checker R5/R8 | `SFB2_ONLY` stimulus mode |
| 4-state power-up: monitors evaluated X resets as "out of reset" | Icarus run | `rst_n !== 1` treated as reset in verification code; TB asserts reset as an X→0 edge |
| Simulation model's single data-bus timeline made completion order equal to command order, hiding any out-of-order latency effect | identical results for different ordering modes in the throughput sweep | per-bank timelines + data-bus slot reservation; model now completes genuinely out of order |
| Watchdog test waited on a *sticky* fault flag set by an earlier phase | surviving mutant `CT_NO_WDOG` | wait for a new fault event |
| Testbench never checked the error **code**, only the error bit | surviving mutant `FE_RANGE_*` | `err_evt` sideband checked against the predicted cause |
| Hazard / scheduler bugs not exercised without a command back-log | surviving mutants `SC_FIFO_ORDER`, `SC_NO_WAR` | back-log phase (slow controller, 128-byte hot region) |
| Redundant double zeroing of error data hid a bug class | surviving mutant `RB_ZERO_ERR` | single zeroing point in the response register |
| DMA `done`/`fail` are one-cycle pulses missed by a multi-cycle host loop | integration TB timeout | latched in the TB |
