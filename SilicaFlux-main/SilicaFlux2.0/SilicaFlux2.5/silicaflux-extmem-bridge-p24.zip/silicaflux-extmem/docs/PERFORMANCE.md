# Performance — theoretical vs sustained

Source data: `reports/throughput.md` / `.json` (`scripts/run_perf.py`),
`reports/df_integration.log`, `reports/synth.md`.  All measurements are RTL
cycle counts against the **simulation-only** controller model; they describe
the bridge (latency hiding, stalls, overheads), not a DRAM device.

## 1. Metrics provided by the bridge (`extmem_perf`, CSR 0x080…)

| Requirement | Counter(s) |
|---|---|
| requests accepted | `RD_REQ`, `WR_REQ` |
| read / write throughput | `RD_BEATS`, `WR_BEATS`, `MC_RD_BEATS`, `MC_WD_BEATS` ÷ `CYCLES` |
| transaction latency | `RD_LAT_SUM/MAX`, `WR_LAT_SUM/MAX` ÷ `RD_DONE`, `WR_DONE` |
| queue occupancy | `RQ_OCC_SUM`, `WQ_OCC_SUM`, `RD_OUT_SUM/MAX`, `WR_OUT_SUM/MAX` |
| arbitration stalls | `ARB_BYPASS`, `HAZARD_STALL`, `DIR_SWITCH`, `MC_CMD_STALL` |
| effective burst utilisation | `MC_RD_BEATS / MC_RD_CMD / MAX_BURST` (same for writes) |
| back-pressure cycles | `UP_REQ_STALL`, `NOSLOT_STALL`, `UP_RSP_STALL`, `MC_CMD_STALL`, `MC_WD_STALL` |
| availability | `UNAVAIL_CYC`, `ERR_TXN`, `MC_PROTO` |

Every counter is cross-checked against the testbench scoreboard at the end of
every regression run (`check_perf`).

## 2. Theoretical peaks

| Path | Peak | DW 64 @ 100 MHz | DW 32 @ 25 MHz (SilicaFlux-V on ULX3S) |
|---|---|---|---|
| upstream read data | 1 beat / cycle | 800 MB/s | 100 MB/s |
| upstream write data | 1 beat / cycle | 800 MB/s | 100 MB/s |
| MC interface | 1 beat / cycle per direction | 800 MB/s each | 100 MB/s each |

For comparison (planning only): a DDR3L x16 at 650 MT/s (Arty A7 class)
peaks at 1.3 GB/s; DDR4-3200 x64 at 25.6 GB/s; one HBM3 pseudo-channel at
25.6 GB/s.  Matching them needs `DW × f_fabric` of that order (ROADMAP §3.1,
§5.1).

## 3. Sustained vs theoretical (bridge only)

* **Latency hiding follows Little's law exactly.**  With 16-beat reads the
  sustained rate equals `min(1, MAX_RD_OUT × 16 / round-trip)` within 0.8 % for
  every point measured (1–16 slots, model latency 10 and 40).  Four read slots
  reach 97–99.5 % of the port peak; one slot reaches 26–50 %.  The bridge adds no
  hidden stall beyond its pipeline.
* **Round trip of a 16-beat read with one slot**: 31.8 cycles at model latency
  10 = 10 (model latency) + 16 (beat transfer) + ≈ 6 cycles of pipeline
  (command register, model command acceptance / execution, read-buffer write,
  response register).
* **Burst length** is the second lever: with 8 slots and latency 40, 1-beat
  reads sustain 17 %, 4-beat 63 %, ≥ 8-beat 99 % of peak.  Single-beat traffic
  uses 1/16 of each MC command's capacity (burst utilisation 0.06).
* **Out-of-order completion** pays off when latency varies: with 5–120 cycles
  of random latency, per-ID out-of-order responses (`UP_OOO = 1`) give +20 %
  throughput and −17 % average latency over strict in-order responses, because
  completed reads no longer wait behind slower older ones holding slots.
* **Scheduler experiments**: with a deep-queue controller the bridge's queues
  stay empty (occupancy ≈ 0.1–0.3), so FIFO and read-priority/batching are
  cycle-identical.  With a shallow-queue controller (40 % command acceptance)
  read-priority/batching ranges from −2.7 % to +1.7 % — no robust gain in this
  model.  The FIFO baseline stays the default; DRAM-aware scheduling belongs in
  the controller, which sees banks and rows (no row-buffer claim is made).
* **Behind the DataFabric rev 2.0 crossbar** (one transaction per slave port)
  the bridge sees one transaction at a time: the real DataFabric DMA copies
  SRAM→EXT at 0.18–0.21 B/cycle with model latency 4–20 cycles (≈ 5 % of the
  4 B/cycle peak) and 0.06 B/cycle at 40–80 cycles.  This, not the bridge, is
  the bandwidth limit of today's SoC — hence ROADMAP P3 (SFB2-X DMA or
  crossbar IDs).

## 4. Clock frequency

Post-route on ECP5-85F (speed 6, nextpnr-ecp5 0.6, the ULX3S device), single
clock, bridge in an out-of-context harness (`reports/synth.md`):

| Configuration | Fmax |
|---|---|
| SFB2 slave (DW 32, 3 + 2 slots) | 57.0 MHz |
| base (DW 64, 16-beat bursts, 8 + 8 slots), no perf counters | 46.7 MHz |
| base with perf counters | 40.5 MHz |
| base + out-of-order upstream + read-priority scheduler | 27.4 MHz |

All meet the 25 MHz SilicaFlux-V SoC clock on ULX3S; the out-of-order
configuration only just.  The critical path is the ROB's combinational entry
selection (with `UP_OOO = 1` the per-ID comparison over all entries) feeding
the read-buffer address and error capture (docs/ISSUES.md XM-7).  At 40 MHz a
64-bit bridge peaks at 320 MB/s per direction.
