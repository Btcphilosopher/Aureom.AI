# Repository audit (Project 24 start)

Repository: `btcphilosopher/Aureom.AI`, branch `claude/peaceful-cannon-1xjfsy`
(as cloned 2026-11-10).  SilicaFlux content lives in `SilicaFlux-main/` almost
entirely as zip archives (one per project); they were extracted read-only for
this audit.  Nothing in the repository was modified.

## 1. DataFabric NoC (`SilicaFlux-main/silicaflux-datafabric.zip`, identical copy in `SilicaFlux2.0/SilicaFlux2.5/`)

| Item | Finding | Consequence for the bridge |
|---|---|---|
| Protocol | **SFB2 rev 2.0**: valid/ready request (`write, addr[31:0], wdata[DW], wstrb`) and response (`rdata, error`) with back-pressure; DW 32/64/128 | upstream port = SFB2 superset |
| Transfers | one beat per transaction, **no bursts, no IDs** (R10) | bursts/IDs added as an additive extension (SFB2-X) |
| Ordering | exactly one response per request, in order (R5) | `UP_OOO = 0` default |
| Outstanding | crossbar: **one** transaction per master port and per slave port (R6); §8 plans IDs + owner FIFOs | behind today's crossbar the bridge is latency bound (measured, reports/throughput.md §5) |
| Alignment | DW-aligned addresses, sub-word via `wstrb` (R9) | same rule, misaligned → `ALIGN` error |
| Write completion | response only after the write is performed (R7) | write response only after the controller's write response |
| Errors | `rsp_error`, `rdata = 0` on errors (R8); no side effect for failed writes | same; error causes captured in CSR |
| Reset | async assert / sync release, reset cancels transactions (R11) | same |
| Coding rules | flat ports, no structs/interfaces/package imports; Verilator 5.020 + Icarus 12 + Yosys 0.33; sized literals in parameters | followed; same tool versions installed here |
| Verification assets | `sfb_protocol_checker` (supports `MAX_OUT > 1`), formal (yosys-smtbmc) | checker reused unmodified (third_party/) |

## 2. DMA controllers

| Engine | Location | Interface | Notes |
|---|---|---|---|
| `dma_transfer_engine` (simple) | DataFabric `rtl/dma` | SFB2 master, 1 transaction in flight | reused unmodified in `tb/tb_df_integration.sv` |
| `dma_burst_engine` (buffered, single/dual port, `MAX_OUT`) | DataFabric `rtl/dma` | SFB2 master(s), several single-beat transactions outstanding | reused unmodified (dual port) |
| `hpc_dma_adapter` | `silicaflux-hpc-m05-dma-adapter.zip` | wraps the DataFabric engines; tagged descriptor/completion streams; SFB2, "no AXI concept introduced" | future SFB2-X master candidate |
| `sf_dma` | `silicaflux-memoryflow.zip` | SF-MEM valid/ready (MemoryFlow's own protocol) | separate research project, not on the DataFabric |

No DMA engine issues bursts or multiple IDs today.

## 3. Shared memory subsystem

* SilicaFlux-V: 4 × 32 KiB SRAM banks at `0x1000_0000`, 16 KiB tile scratchpad
  (TSPM) at `0x2000_0000` (DataFabric memory map).
* `silicaflux-hpc-m04-scratchpad`: banked scratchpad, `NUM_PORTS` ready/valid
  ports, tagged in-order responses, SRAM Wrapper Library backends.
* SRAM Wrapper Library (`silicaflux-sramlib`): generic / FPGA / ASIC-macro
  backends — the model for this bridge's `extmem_ram` wrapper.

## 4. Address maps

`memmap/silicaflux_v_datafabric.yaml` (single source of truth) defines
ROM `0x0000_0000`, SRAM `0x1000_0000`–`0x1001_FFFF`, TSPM `0x2000_0000`,
PERIPH `0x4000_0000` (pages 0–7, 16, 17 used).  **`0x8000_0000` and above are
unmapped**; BandwidthLab's hypothetical `configs/silicaflux_full.yaml` already
places a 256 MiB "dram" region at `0x8000_0000`.  The bridge therefore defaults
to `EXT_BASE = 0x8000_0000`, and `docs/memmap_extmem.yaml` proposes the
additions (EXTMEM region, CSR on free PERIPH page 8 at `0x4000_8000`,
crossbar slave port, access matrix) in the YAML's own format — not applied to
the DataFabric repository.

## 5. Clock domains

SilicaFlux-V: one functional clock + JTAG `tck`; resets via `sfv_rst_sync`
(async assert, sync release); no clock-domain crossing anywhere on the
DataFabric.  BandwidthLab models a separate DRAM clock (200 MHz) with a 2-stage
synchroniser.  ⇒ phase 1 of this project is single clock (`ASYNC = 0`); the
controller-clock crossing (`ASYNC = 1`) is provided for vendor controllers whose
user clock is not the fabric clock.

## 6. FPGA flow, board and memory-controller IP

| Question | Finding |
|---|---|
| "FPGAFlow" | No project of that name exists in the repository (all archives listed and searched). The FPGA flow in use is SilicaFlux-V's `fpga/ulx3s/Makefile`: Yosys `synth_ecp5` → nextpnr-ecp5 → ecppack (open tools, no vendor licence). |
| Selected board | **Radiona ULX3S, ECP5 LFE5U-85F** (SilicaFlux-V, MCU-I, ControlCore, HPC tile). SilicaFlux-V's FPGA.md: bitstream built, **never tested on hardware**. |
| External memory on that board | ULX3S carries a 16-bit **SDR SDRAM** (32 MB on common board revisions — check yours) — **not DDR**. No SilicaFlux LPF maps its pins; no project uses it. |
| Other boards referenced | Arty A7-100T (DDR3L x16) appears only in an SRAM-library self-test constraint file and an older `silicaflux/synth/vivado` script; no DDR is used. |
| Vendor DDR controller IP | **None**: no Vivado/Quartus/Diamond project, no MIG/EMIF/Lattice DDR IP, no LiteDRAM, no licence files. |
| Existing "memory controllers" | all on-chip SRAM controllers (`silicaflux/rtl/memory_controller.sv`, `memory_controller.sf`, scratchpads). `memory_cache_repo/rtl/memory_controller.sv` is a toy SDRAM-style ACT/CAS/PRE/REFRESH FSM behind a cache — no PHY, no calibration, not JEDEC-accurate, not usable as an FPGA DDR controller. |
| HBM | `aureom.ai-hbm-digital-twin.zip` is a TypeScript/Angular visualisation app (HBM2…HBM4 spec tables, thermal/PDN toy solvers) — no RTL. BandwidthLab `dram.py` is a simplified Python controller model (labelled not JEDEC accurate). |

**Decision (per the brief):** no compatible board + licensed/available DDR
controller exists, so the controller side is an **explicitly labelled
simulation model** (`sim/models/extmem_sim_mc.sv`), and the vendor
integration is specified as an adapter contract (docs/MC_INTERFACE.md §5)
rather than delivered as unvalidated RTL.  No claim of DRAM calibration,
DRAM timing or hardware operation is made anywhere in this package.

## 7. Tools available in this environment

Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33, nextpnr-ecp5 0.6, Trellis
(installed from the distribution, the same Verilator/Icarus/Yosys versions as
the DataFabric project).  Not available: Vivado, Quartus, Diamond, any PDK, any
CDC lint tool, any formal tool beyond Yosys.
