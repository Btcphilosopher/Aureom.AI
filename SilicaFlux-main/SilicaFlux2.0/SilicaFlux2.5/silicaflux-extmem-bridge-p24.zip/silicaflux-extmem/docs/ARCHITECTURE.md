# MemoryBridge architecture — `silicaflux_extmem_bridge`

## 1. Position in the system

```
 DataFabric masters (CPU, DMA engines, HPC tile DMA adapter)
        │  SFB2 (rev 2.0)                         SFB2-X (bursts + IDs, docs/PROTOCOL_SFB2X.md)
        ▼                                          ▼
 sfb_crossbar slave port  ── or ──  direct master connection
        │
        ▼
┌───────────────────────────── silicaflux_extmem_bridge ─────────────────────────────┐
│ extmem_core (fabric clock)                                                         │
│   frontend ─► slots/tracker ─► scheduler (rq/wq) ─► cmd register ─► mc_cmd_*        │
│      │            ▲               └► write-data sequencer ◄─ wbuf ─► mc_wd_*        │
│      └► ROB ◄─────┴──── rbuf ◄── tracker ◄── mc_rd_* / mc_wr_*                      │
│   ctrl FSM (mc_rst_n, mc_init_done, mc_fatal, flush)   perf counters   CSR page     │
│ [ASYNC = 1] extmem_mc_cdc: async FIFOs + synchronisers to mc_clk                    │
└────────────────────────────────────────────────────────────────────────────────────┘
        │  generic memory-controller interface "SFMC" (docs/MC_INTERFACE.md)
        ▼
 controller adapter (replaceable, vendor specific)   ◄── NOT in this release except the
        │                                               simulation model
        ▼
 vendor / licensed DDR or HBM controller + PHY  ──►  external DRAM
```

The portable part ends at the SFMC interface.  Everything vendor specific —
address unit conversion, data-width conversion, the controller's own command
encoding, calibration status pins, ECC reporting — lives in an adapter
(docs/MC_INTERFACE.md §5 gives the mapping for Xilinx MIG 7-series UI,
LiteDRAM native ports and AXI4 controllers).  No adapter for real IP is
delivered because no such IP is available in the project (docs/AUDIT.md §6).

## 2. Blocks

| Block | File | Function |
|---|---|---|
| top | `rtl/silicaflux_extmem_bridge.sv` | core + optional CDC (`ASYNC`) |
| core | `rtl/extmem_core.sv` | wiring, parameter checks, buffers, perf, CSR |
| frontend | `rtl/extmem_frontend.sv` | decode, first-beat checks, write-burst framing, slot allocation, store-and-forward of write data |
| tracker | `rtl/extmem_tracker.sv` | slot state (ownership, issue, completion, flush), MC response legality, read-buffer writes |
| scheduler | `rtl/extmem_sched.sv` | read/write command queues, FIFO or read-priority/batching selection, RAW/WAR protection, command register, write-data sequencer |
| ROB | `rtl/extmem_rob.sv` | response order (in order or per-ID), one response per transaction, read cut-through, registered response stage |
| ctrl | `rtl/extmem_ctrl.sv` | controller reset / calibration / fault / quiesce sequencing, response watchdog |
| perf | `rtl/extmem_perf.sv` | 32 saturating counters (`rtl/extmem_defs.svh`) |
| CSR | `rtl/extmem_csr.sv` | SFB2 register page: ID, INFO, STATUS, CONTROL, error capture, counters |
| buffers | `rtl/extmem_ram.sv` | 1W1R RAM wrapper (async read); write buffer `MAX_WR_OUT × MAX_BURST × (DW+DW/8)`, read buffer `MAX_RD_OUT × MAX_BURST × (DW+1)` |
| CDC | `rtl/cdc/*.sv` | `extmem_mc_cdc`, `extmem_async_fifo` (Gray pointers), `extmem_sync`, `extmem_rst_sync` |

All RTL follows the SilicaFlux coding rules (flat ports, no structs /
interfaces / package imports, `always_ff`/`always_comb`, asynchronous-assert
resets, vendor cells behind wrappers) and is lint-clean under Verilator 5.020
`-Wall` in 21 parameter sets (every configuration file plus corner cases, `reports/lint.md`) and latch-free in Yosys 0.33.

## 3. Transaction life cycle

**Read.**  First (only) request beat accepted → checks pass → read slot *r*
allocated (owns read-buffer beats `r*MB … r*MB+MB-1` and MC read tag *r*) →
ROB entry appended → command queued → issued on `mc_cmd_*` (tag *r*) →
read beats arrive on `mc_rd_*` with tag *r* in any order relative to other
tags and are written to the read buffer → the ROB streams beats upstream as
soon as the first is present (cut-through) → on the last beat the ROB entry
retires and slot *r* is freed.

**Write.**  First beat accepted → write slot *w* allocated → every beat is
stored in the write buffer → on the last beat (store and forward) the command
is queued and the ROB entry appended → command issued with tag *w* → after the
controller accepted the command, the write-data sequencer streams the beats
from the buffer → the controller returns one write response for tag *w* (after
the write reached its ordering point) → the ROB emits one write response → slot
freed.

**Local error.**  A request failing a first-beat check gets a ROB entry with
the error code and no slot; its write beats are consumed and discarded; the
ROB answers it in order (reads: `len+1` error beats; writes: one error
response).  It never reaches the controller.

## 4. Ownership and the "no lost / no duplicate" argument

* A slot is the only owner of its buffer region and MC tag; it is allocated
  from the free set and returns to it only when the ROB has delivered the
  transaction's last response beat.  So a tag is never live twice, and a
  late or stray controller response can never be attributed to another
  transaction.
* The tracker accepts a controller response only for a tag in the right phase
  (issued, incomplete, and for writes: all data sent).  Anything else is
  dropped and counted (`MC_PROTO`), never written into a buffer.
* The ROB holds exactly one entry per accepted transaction; the only way an
  entry leaves is by emitting its final response beat; an entry can be
  selected only when its data / completion is present.  Hence exactly one
  response per transaction.
* Buffer space is reserved when the slot is allocated (credit by
  construction): no overflow, and the bridge never back-pressures the
  controller's read data or write responses (`mc_rd_ready = mc_wr_ready = 1`).

Mutation testing (`reports/mutation.md`) injects bugs in exactly these
mechanisms (slot not freed, wrong tag, duplicated response, early
completion, …) and checks the testbench catches each one.

## 5. Ordering

| Path | Rule |
|---|---|
| Upstream, `UP_OOO = 0` (SFB2 R5) | responses in acceptance order across all IDs, reads and writes |
| Upstream, `UP_OOO = 1` | per-ID acceptance order; different IDs may complete out of order |
| Upstream, read bursts | beats of one burst are contiguous (never interleaved with another response) |
| Scheduler, `SCHED_MODE = 0` | global arrival order |
| Scheduler, `SCHED_MODE = 1` | reads before writes unless batching / fairness; a command may bypass older commands of the other direction only if no byte range overlaps |
| Controller (contract) | overlapping accesses take effect in command-acceptance order; completion order is free (tags) |

Together these give upstream masters the memory semantics of in-order
execution (a read returns the data of every earlier-accepted write to the
same bytes).  The testbench's reference model checks exactly that.

## 6. Scheduler

Baseline FIFO (`SCHED_MODE = 0`): one command per cycle, oldest first.

Experimental (`SCHED_MODE = 1`):
* **read priority** — a waiting read is issued before queued writes;
* **write batching** — when `WR_HI` writes are queued, writes are drained
  until `WR_LO` remain (fewer read↔write direction switches; counted by
  `DIR_SWITCH`);
* **fairness** — a queue head bypassed `AGE_CAP` times is forced next;
* **hazard protection** — byte-range overlap check of the bypassing head
  against every older command of the other direction (`HAZARD_STALL`).

Not implemented, deliberately: row-buffer / bank-aware reordering (the
bridge has no visibility of the controller's address mapping or open rows and
no real controller to validate against), and burst coalescing (it would merge
several upstream transactions into one MC command and needs a split
completion path; see ROADMAP).

## 7. Controller link state machine

See `rtl/extmem_ctrl.sv` header.  States: RESET (controller held in reset
`RST_HOLD` cycles) → CAL (wait `mc_init_done`, optional `CAL_TIMEOUT` →
CALFAIL) → READY ⇄ QUIESCE (requested reset: drain, then RESET) and FAULT
(`!mc_init_done`, `mc_fatal` or the response watchdog `RESP_TIMEOUT` while
READY/QUIESCE).  FAULT flushes: every incomplete slot completes with an error,
queues and the command register are cleared, and the controller is held in
reset from the next edge so no response of the old epoch can arrive.  With
`AUTO_RECOVER = 1` the link restarts automatically.

While the link is not READY new requests are answered `UNAVAIL`
(`UNAVAIL_POLICY = 0`, default: never hangs the fabric) or stalled
(`UNAVAIL_POLICY = 1`).  The bridge never reports READY on its own: READY
follows the controller's `mc_init_done`.

## 8. Clocking and reset

* `ASYNC = 0`: one clock.  The MC interface runs on the fabric clock (the
  first-phase target of this project).
* `ASYNC = 1`: `extmem_mc_cdc` carries the four MC channels through Gray-code
  async FIFOs (`CDC_DEPTH`, `CDC_SYNC` stages), synchronises `mc_init_done` /
  `mc_fatal` into the fabric clock and produces `mc_rst_n` in the controller
  clock (asynchronous assert, synchronous release).  Both FIFO halves are reset
  with the controller, so no command/response of an earlier epoch survives.
* Resets: active-low asynchronous assert / synchronous release, as in
  SilicaFlux-V.  A bridge reset cancels every transaction (SFB2 R11) and also
  resets the controller through `mc_rst_n`.

## 9. Parameters

| Parameter | Default | Meaning |
|---|---|---|
| `DW` | 64 | data width (32 … 512) of the upstream port and the MC interface |
| `IDW`, `LW` | 4, 8 | ID width; burst-length field width (len = beats − 1) |
| `MAX_BURST` | 16 | longest burst accepted (power of two ≤ 2^LW) |
| `MAX_RD_OUT`, `MAX_WR_OUT` | 8, 8 | read / write slots = outstanding transactions at the controller |
| `ROB_DEPTH` | 0 → RD+WR+2 | accepted-but-unanswered transactions (incl. local errors) |
| `EXT_BASE`, `EXT_SIZE` | 0x8000_0000, 256 MiB | external-memory window (byte addresses) |
| `MC_AW` | 28 | MC byte-address width (offset inside the window) |
| `BOUND_LOG2` | 12 | bursts may not cross 2^BOUND_LOG2 bytes (4 KiB, AXI-compatible) |
| `UP_OOO` | 0 | out-of-order responses across IDs |
| `SCHED_MODE`, `WR_HI`, `WR_LO`, `AGE_CAP` | 0, 6, 2, 16 | scheduler (§6) |
| `UNAVAIL_POLICY` | 0 | error vs stall while the link is not READY |
| `RST_HOLD`, `CAL_TIMEOUT`, `RESP_TIMEOUT`, `AUTO_RECOVER` | 16, 0, 0, 1 | link FSM |
| `PERF` | 1 | performance counters |
| `ASYNC`, `CDC_DEPTH`, `CDC_SYNC` | 0, 8, 2 | controller clock crossing |

Validation rules: `scripts/extmem_cfg.py` and `docs/CONFIGURATION.md`.

## 10. Known limitations (see also docs/ISSUES.md)

* Unaligned transfers are supported only through byte strobes on an aligned
  address (SFB2 R9); a misaligned address is rejected (`ALIGN`).
* A burst may not cross `2^BOUND_LOG2` bytes or the window end (rejected, not
  split).
* Data-width conversion to a controller's native width is the adapter's job.
* Timing: the ROB selection is combinational (27–57 MHz post-route on ECP5,
  docs/ISSUES.md XM-7).
* Buffers use asynchronous-read RAM (LUT RAM on FPGA); large ASIC
  configurations should map them to 1R1W macros with a registered read
  (one extra pipeline stage in the ROB / write-data sequencer).
