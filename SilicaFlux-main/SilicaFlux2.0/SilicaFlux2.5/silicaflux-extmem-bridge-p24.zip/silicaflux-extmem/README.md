# SilicaFlux MemoryBridge — Project 24

**External DDR / future HBM memory bridge for the SilicaFlux DataFabric.**
Primary RTL: [`rtl/silicaflux_extmem_bridge.sv`](rtl/silicaflux_extmem_bridge.sv) · Aureom.AI / SilicaFlux-HPC

```
DataFabric (SFB2 / SFB2-X) ─► silicaflux_extmem_bridge ─► generic MC interface (SFMC) ─► adapter ─► vendor controller + PHY ─► DRAM
                              decode · slots · scheduler · ROB · link FSM · perf · CSR · [CDC]
```

> **Status — read this first.**  The bridge is **verified in simulation against
> an explicitly simulated controller** (`sim/models/extmem_sim_mc.sv`, a
> behavioural model with hypothetical latencies) and inside the real,
> unmodified DataFabric crossbar + DMA engines.  **No vendor DDR controller,
> PHY, FPGA board run or DRAM calibration exists in this release**: the
> repository contains no DDR controller IP, no vendor toolchain, and its FPGA
> board (ULX3S) has SDR SDRAM, not DDR ([docs/AUDIT.md](docs/AUDIT.md) §6).
> HBM is a research study only.  Nothing here claims DRAM timing, calibration
> or row-buffer behaviour.

## Results (from `reports/`, final run on the frozen RTL)

<!-- RESULTS -->
| Check | Result | Report |
|---|---|---|
| Full regression (Verilator, 12 configs × 17 tests × 3 seeds + Icarus) | **663 / 663** pass — 777,408 transactions, 11,846,403 cycles | [reports/regression.md](reports/regression.md) |
| Cross-simulation Icarus vs Verilator (same seed) | **51 / 51** byte-identical (verdict, statistics, 32 counters) | [reports/regression.md](reports/regression.md) |
| Lint: Verilator -Wall (all config files + corner sets), Icarus elaboration | **21 / 21** clean, 0 Icarus errors | [reports/lint.md](reports/lint.md) |
| Integration: unmodified DataFabric crossbar + DMA engines (2 engines × 2 latencies) | **4 / 4** pass — byte-exact SRAM→EXT→SRAM copies, error propagation, CSR via crossbar | [reports/df_integration.log](reports/df_integration.log) |
| Mutation testing (injected design bugs) | **32 / 33** killed, 1 documented equivalent, 0 surviving | [reports/mutation.md](reports/mutation.md) |
| Throughput vs theoretical (simulation model) | peak sustained 0.995 beat/cycle; Little's-law bound matched within 0.8 %; out-of-order upstream +20 % throughput under 5–120-cycle latency | [reports/throughput.md](reports/throughput.md) |
| Synthesis (Yosys 0.33) and place & route (nextpnr-ecp5 0.6) | 5 / 5 configurations latch-free, `check -assert` clean; ECP5-85F post-route Fmax 27.4–57.0 MHz (SoC clock on ULX3S: 25 MHz); base config 5218 LUT / 3485 FF (Yosys xc7) | [reports/synth.md](reports/synth.md) |
| Vendor DDR controller / PHY / FPGA hardware / calibration | **none available — not claimed** | [docs/AUDIT.md](docs/AUDIT.md) |

## What is in the box

| Deliverable | Files |
|---|---|
| Bridge RTL (synthesizable, SilicaFlux coding rules) | `rtl/silicaflux_extmem_bridge.sv` (top), `rtl/extmem_core.sv`, `extmem_frontend.sv`, `extmem_tracker.sv`, `extmem_sched.sv`, `extmem_rob.sv`, `extmem_ctrl.sv`, `extmem_perf.sv`, `extmem_csr.sv`, `extmem_ram.sv`, `extmem_defs.svh` |
| Clock-domain crossing | `rtl/cdc/extmem_mc_cdc.sv`, `extmem_async_fifo.sv`, `extmem_sync.sv`, `extmem_rst_sync.sv`; constraint templates in `constraints/` |
| Generic memory-controller interface | [docs/MC_INTERFACE.md](docs/MC_INTERFACE.md) (contract C1–C11, adapter mappings for MIG UI, LiteDRAM, AXI4) + `tb/extmem_mc_checker.sv` |
| Upstream transaction interface | [docs/PROTOCOL_SFB2X.md](docs/PROTOCOL_SFB2X.md) — SFB2 rev 2.0 superset (bursts, IDs, outstanding) |
| FPGA vendor adapter | **not delivered — no vendor controller is genuinely available** (docs/AUDIT.md §6); mapping and plan in docs/MC_INTERFACE.md §5 and docs/ROADMAP_DDR_HBM.md §2 |
| Simulation DRAM model | `sim/models/extmem_sim_mc.sv` (SIMULATION ONLY) |
| Test suite | `tb/tb_extmem.sv` (17 tests, independent reference model), `tb/tb_df_integration.sv`, checkers, `scripts/run_regress.py`, `scripts/mutate.py` |
| Configuration schema | `config/extmem_config.schema.json`, `scripts/extmem_cfg.py`, `config/regress/` (12), `config/templates/` (4) — [docs/CONFIGURATION.md](docs/CONFIGURATION.md) |
| Throughput reports | `reports/throughput.md`, [docs/PERFORMANCE.md](docs/PERFORMANCE.md), `scripts/run_perf.py` |
| DDR / HBM roadmap | [docs/ROADMAP_DDR_HBM.md](docs/ROADMAP_DDR_HBM.md) |
| Audit, architecture, verification, issues | [docs/AUDIT.md](docs/AUDIT.md), [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md), [docs/VERIFICATION.md](docs/VERIFICATION.md), [docs/ISSUES.md](docs/ISSUES.md) |
| Memory-map proposal | `docs/memmap_extmem.yaml` (DataFabric YAML format, not applied) |
| Reused DataFabric sources | `third_party/silicaflux-datafabric/` — unmodified, `SHA256SUMS`, `PROVENANCE.md` |

## Quick start

```bash
make config        # validate all configurations
make lint          # Verilator -Wall over 21 parameter sets + Icarus elaboration
make test-quick    # 12 configs x 17 tests, 1 seed (~2 min on 4 cores)
make test          # full regression + Icarus identical-output cross-check
make integration   # bridge inside the real DataFabric crossbar + DMA
make mutation      # 33 injected bugs
make perf          # throughput characterisation
make synth         # Yosys generic / xc7 / ECP5 + nextpnr-ecp5
```

Tools: Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33, nextpnr-ecp5 0.6,
Python 3 (standard library only) — the versions the DataFabric project uses.

## Key design points

* **Ownership by slots**: a read/write slot owns its buffer space and MC tag
  from allocation until its response has been delivered upstream — no tag is
  ever live twice, buffers cannot overflow, and the controller is never
  back-pressured on read data.
* **One response per transaction by construction**: a ROB entry per accepted
  transaction, removed only by emitting its last response beat.
* **Ordering**: in-order upstream (SFB2 R5) by default, per-ID out-of-order
  optional; the scheduler never reorders overlapping read/write pairs.
* **Controller link FSM**: reset hold, calibration wait (+timeout), fault
  flush with controller held in reset, quiesced reset on request, response
  watchdog, UNAVAIL errors (or stall) while not READY.  READY only ever
  follows the controller's own `mc_init_done`.
* **Portable**: everything vendor specific is behind the SFMC contract; the
  CDC is optional (`ASYNC`), the buffers sit behind a RAM wrapper.
