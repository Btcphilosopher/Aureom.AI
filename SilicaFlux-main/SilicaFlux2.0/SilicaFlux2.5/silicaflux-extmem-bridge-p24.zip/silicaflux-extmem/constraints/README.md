# Timing constraints (templates)

| File | Tool | Status |
|---|---|---|
| `extmem_cdc.xdc` | Vivado (Xilinx 7-series / UltraScale) | **template, never read by Vivado** |
| `extmem_cdc.sdc` | ASIC STA (OpenSTA / PrimeTime / Tempus) | **template, no PDK flow exists** |

Only needed with `ASYNC = 1`.  With `ASYNC = 0` the bridge is a single-clock
synchronous design and needs only the fabric `create_clock`.

What *was* run (reports/synth.md): Yosys generic / xc7 / ECP5 synthesis and
nextpnr-ecp5 place-and-route of the single-clock bridge for post-route Fmax.
nextpnr-ecp5 0.6 has no max-delay / false-path constraint language for
cross-domain paths; it does not analyse clk -> mc_clk paths at all, so the
asynchronous configuration has no timing evidence in this release.

Rules the constraints encode (and that a CDC lint tool should confirm):
1. Only Gray-coded pointers, level signals (init_done, fatal) and the reset
   cross between `clk` and `mc_clk` -- through `extmem_sync` /
   `extmem_rst_sync` (2+ flops, ASYNC_REG).
2. FIFO data is captured in the destination domain only via storage that
   was written >= CDC_SYNC destination cycles before its pointer arrives.
3. Bounded skew (`set_max_delay -datapath_only`) on multi-bit Gray pointers;
   never a blanket `set_clock_groups -asynchronous`.
4. `RST_HOLD` (fabric cycles) >= CDC_SYNC + 2 + ceil((CDC_SYNC + 1) * f_fabric / f_mc),
   enforced by `scripts/extmem_cfg.py`.
