# =============================================================================
# SilicaFlux MemoryBridge -- Vivado CDC constraints TEMPLATE for ASYNC = 1
#
# STATUS: NOT VALIDATED.  No Vivado was available to this project; this file
# has never been read by Vivado.  Hierarchy names follow the RTL instance
# names (u_core, g_cdc.u_cdc, u_cmd/u_wd/u_rd/u_wr, u_s_w2r/u_s_r2w, u_mrst,
# u_st); adjust the leading path to where silicaflux_extmem_bridge sits in
# your design and check every query returns objects (Vivado warns on empty
# lists -- treat that as an error).
#
# Assumptions: `clk` = fabric clock, `mc_clk` = controller user clock (e.g.
# MIG ui_clk).  Both are already defined by create_clock / the MIG IP.
# =============================================================================
set BR   [get_cells -hier -filter {REF_NAME == silicaflux_extmem_bridge || ORIG_REF_NAME == silicaflux_extmem_bridge}]
set CDC  [get_cells -hier -filter "NAME =~ */g_cdc.u_cdc"]
set T_FAB [get_property PERIOD [get_clocks -of_objects [get_pins -of_objects $BR -filter {REF_PIN_NAME == clk}]]]
set T_MC  [get_property PERIOD [get_clocks -of_objects [get_pins -of_objects $BR -filter {REF_PIN_NAME == mc_clk}]]]
set T_MIN [expr {min($T_FAB, $T_MC)}]

# 1. Gray-coded FIFO pointers: bound the skew between pointer bits (one bit
#    changes per increment, so the synchroniser sees an old or a new value as
#    long as all bits arrive within one destination period).
set_max_delay -datapath_only $T_MIN \
  -from [get_cells -hier -filter {NAME =~ */g_cdc.u_cdc/*/wgray_q_reg*}] \
  -to   [get_cells -hier -filter {NAME =~ */g_cdc.u_cdc/*/u_s_w2r/s_reg[0]*}]
set_max_delay -datapath_only $T_MIN \
  -from [get_cells -hier -filter {NAME =~ */g_cdc.u_cdc/*/rgray_q_reg*}] \
  -to   [get_cells -hier -filter {NAME =~ */g_cdc.u_cdc/*/u_s_r2w/s_reg[0]*}]

# 2. FIFO storage written in the source domain and read combinationally in the
#    destination domain: the data must settle before the synchronised pointer
#    (>= CDC_SYNC destination cycles later) can select it.
set_max_delay -datapath_only $T_MIN \
  -from [get_cells -hier -filter {NAME =~ */g_cdc.u_cdc/*/mem_reg*}]

# 3. Level synchronisers of mc_init_done / mc_fatal and the reset synchroniser:
#    the first stage is the asynchronous capture point.
set_false_path -to [get_cells -hier -filter {NAME =~ */g_cdc.u_cdc/u_st/s_reg[0]*}]
set_false_path -to [get_pins  -hier -filter {NAME =~ */g_cdc.u_cdc/u_mrst/s_reg*/CLR}]
set_false_path -to [get_pins  -hier -filter {NAME =~ */g_cdc.u_cdc/u_mrst/s_reg*/PRE}]

# 4. The synchroniser flops carry ASYNC_REG = TRUE in the RTL (extmem_sync /
#    extmem_rst_sync); keep them in one slice:
#    set_property ASYNC_REG TRUE [get_cells -hier -filter {NAME =~ */g_cdc.u_cdc/*s_reg*}]

# 5. Do NOT use set_clock_groups -asynchronous between clk and mc_clk for the
#    whole design: it would also remove the max-delay bounds above.
