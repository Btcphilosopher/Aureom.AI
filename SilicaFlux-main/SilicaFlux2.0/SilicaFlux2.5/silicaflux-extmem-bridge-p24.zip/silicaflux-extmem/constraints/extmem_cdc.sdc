# =============================================================================
# SilicaFlux MemoryBridge -- generic SDC CDC constraints TEMPLATE (ASIC STA,
# e.g. OpenSTA / PrimeTime / Tempus) for ASYNC = 1.   STATUS: NOT VALIDATED.
# The repository has no PDK-based synthesis or STA flow for this block yet.
# Replace FAB_CLK / MC_CLK with your clock names and the instance path prefix.
# =============================================================================
set FAB_CLK clk
set MC_CLK  mc_clk
set P       "*/g_cdc.u_cdc"
set T_MIN   [expr {min([get_attribute [get_clocks $FAB_CLK] period], [get_attribute [get_clocks $MC_CLK] period])}]

# Gray pointers and FIFO storage: bounded skew instead of a false path
set_max_delay $T_MIN -ignore_clock_latency -from [get_cells "$P/*/wgray_q_reg*"] -to [get_cells "$P/*/u_s_w2r/s_reg_0_*"]
set_max_delay $T_MIN -ignore_clock_latency -from [get_cells "$P/*/rgray_q_reg*"] -to [get_cells "$P/*/u_s_r2w/s_reg_0_*"]
set_max_delay $T_MIN -ignore_clock_latency -from [get_cells "$P/*/mem_reg*"]
set_min_delay 0 -from [get_cells "$P/*/mem_reg*"]

# First synchroniser stages and reset-synchroniser asynchronous pins
set_false_path -to [get_cells "$P/u_st/s_reg_0_*"]
set_false_path -to [get_pins "$P/u_mrst/s_reg*/RN"]

# Synchroniser cells: replace extmem_sync / extmem_rst_sync flops by the
# library's characterised synchroniser cells (MTBF) and mark them dont_touch
# set_dont_touch [get_cells "$P/*/u_s_*/s_reg*"]
