// =============================================================================
// SilicaFlux MemoryBridge :: extmem_mc_checker -- generic MC-interface monitor
//
// Verification only (never synthesised).  Passive checker of the contract in
// docs/MC_INTERFACE.md, usable unchanged in front of a vendor-controller
// simulation model when one becomes available.  Rules (Cn):
//   C1 cmd payload stable while cmd_valid && !cmd_ready (not withdrawn)
//   C2 wd payload stable while wd_valid && !wd_ready
//   C3 rd / wr response payload stable while valid && !ready
//   C4 a tag is not re-issued while a transaction with that tag is live
//   C5 every read beat belongs to a live read tag; beats per tag = len+1;
//      rd_last exactly on the final beat
//   C6 every write response belongs to a live write tag whose data has been
//      fully transferred (one response per write)
//   C7 write data in command order, wd_last exactly on each command's final beat;
//      STRICT_WD = 1: only for already-accepted commands (bridge-core side);
//      STRICT_WD = 0: a beat may precede its command (controller side of the CDC)
//   C8 no X/Z on valid/ready while out of reset
// All state is cleared while rst_n (the controller reset) is low.
// =============================================================================
`default_nettype none

module extmem_mc_checker #(
  parameter int DW        = 64,
  parameter int MC_AW     = 28,
  parameter int LW        = 8,
  parameter int TW        = 3,
  parameter int STRICT_WD = 1,
  parameter     NAME      = "mc",
  localparam int SB       = DW / 8,
  localparam int NTAG     = 1 << TW,
  localparam int WQ       = 512
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             cmd_valid,
  input  wire logic             cmd_ready,
  input  wire logic             cmd_write,
  input  wire logic [MC_AW-1:0] cmd_addr,
  input  wire logic [LW-1:0]    cmd_len,
  input  wire logic [TW-1:0]    cmd_tag,
  input  wire logic             wd_valid,
  input  wire logic             wd_ready,
  input  wire logic [DW-1:0]    wd_data,
  input  wire logic [SB-1:0]    wd_strb,
  input  wire logic             wd_last,
  input  wire logic             rd_valid,
  input  wire logic             rd_ready,
  input  wire logic [DW-1:0]    rd_data,
  input  wire logic [TW-1:0]    rd_tag,
  input  wire logic             rd_last,
  input  wire logic             rd_error,
  input  wire logic             wr_valid,
  input  wire logic             wr_ready,
  input  wire logic [TW-1:0]    wr_tag,
  input  wire logic             wr_error,
  output int                    violations,
  output int                    n_rd_cmd,
  output int                    n_wr_cmd,
  output int                    n_rd_beats,
  output int                    n_wr_rsp
);
  logic          rlive [NTAG];
  int            rlen  [NTAG];
  int            rcnt  [NTAG];
  logic          wlive [NTAG];
  logic          wdat  [NTAG];
  // write commands awaiting data, in command order
  int            wq_tag [WQ];
  int            wq_len [WQ];
  int            wq_hd, wq_n, wbeat;
  // write-data beats not yet matched to a command
  logic          eb_last [WQ];
  int            eb_hd, eb_n;
  // previous-cycle holds
  logic          ph_cmd, ph_wd, ph_rd, ph_wr;
  logic [1+MC_AW+LW+TW-1:0] pv_cmd;
  logic [DW+SB:0]           pv_wd;
  logic [DW+TW+1:0]         pv_rd;
  logic [TW:0]              pv_wr;

  task automatic fail(input [8*72-1:0] msg);
    violations = violations + 1;
    $display("[%0t] %0s MC-CHECK VIOLATION: %0s", $time, NAME, msg);
  endtask

  initial begin
    violations = 0; n_rd_cmd = 0; n_wr_cmd = 0; n_rd_beats = 0; n_wr_rsp = 0;
  end

  always @(posedge clk or negedge rst_n) begin
    if (rst_n !== 1'b1) begin      // X during 4-state power-up counts as reset
      for (int i = 0; i < NTAG; i++) begin
        rlive[i] = 1'b0; wlive[i] = 1'b0; wdat[i] = 1'b0; rlen[i] = 0; rcnt[i] = 0;
      end
      wq_hd = 0; wq_n = 0; wbeat = 0; eb_hd = 0; eb_n = 0;
      ph_cmd = 1'b0; ph_wd = 1'b0; ph_rd = 1'b0; ph_wr = 1'b0;
    end else begin
      // C8
      if ((cmd_valid !== 1'b0 && cmd_valid !== 1'b1) || (wd_valid !== 1'b0 && wd_valid !== 1'b1) ||
          (rd_valid !== 1'b0 && rd_valid !== 1'b1) || (wr_valid !== 1'b0 && wr_valid !== 1'b1) ||
          (cmd_ready !== 1'b0 && cmd_ready !== 1'b1) || (wd_ready !== 1'b0 && wd_ready !== 1'b1) ||
          (rd_ready !== 1'b0 && rd_ready !== 1'b1) || (wr_ready !== 1'b0 && wr_ready !== 1'b1))
        fail("C8 X/Z on a handshake signal");
      // C1..C3
      if (ph_cmd && (!cmd_valid || {cmd_write, cmd_addr, cmd_len, cmd_tag} !== pv_cmd)) fail("C1 command not held");
      if (ph_wd && (!wd_valid || {wd_data, wd_strb, wd_last} !== pv_wd))                fail("C2 write data not held");
      if (ph_rd && (!rd_valid || {rd_data, rd_tag, rd_last, rd_error} !== pv_rd))         fail("C3 read data not held");
      if (ph_wr && (!wr_valid || {wr_tag, wr_error} !== pv_wr))                           fail("C3 write response not held");
      // responses first (a tag may be reused in the cycle after its completion)
      if (rd_valid && rd_ready) begin
        n_rd_beats = n_rd_beats + 1;
        if (!rlive[rd_tag]) fail("C5 read beat for a tag that is not live");
        else begin
          if (rd_last !== (rcnt[rd_tag] == rlen[rd_tag])) fail("C5 rd_last framing");
          rcnt[rd_tag] = rcnt[rd_tag] + 1;
          if (rcnt[rd_tag] > rlen[rd_tag]) rlive[rd_tag] = 1'b0;
        end
      end
      if (wr_valid && wr_ready) begin
        n_wr_rsp = n_wr_rsp + 1;
        if (!wlive[wr_tag])     fail("C6 write response for a tag that is not live");
        else if (!wdat[wr_tag]) fail("C6 write response before all write data was transferred");
        wlive[wr_tag] = 1'b0;
        wdat[wr_tag]  = 1'b0;
      end
      if (cmd_valid && cmd_ready) begin
        if (cmd_write) begin
          n_wr_cmd = n_wr_cmd + 1;
          if (wlive[cmd_tag]) fail("C4 write tag re-issued while live");
          wlive[cmd_tag] = 1'b1;
          wdat[cmd_tag]  = 1'b0;
          if (wq_n < WQ) begin
            wq_tag[(wq_hd + wq_n) % WQ] = int'(cmd_tag);
            wq_len[(wq_hd + wq_n) % WQ] = int'(cmd_len);
            wq_n = wq_n + 1;
          end
        end else begin
          n_rd_cmd = n_rd_cmd + 1;
          if (rlive[cmd_tag]) fail("C4 read tag re-issued while live");
          rlive[cmd_tag] = 1'b1;
          rlen[cmd_tag]  = int'(cmd_len);
          rcnt[cmd_tag]  = 0;
        end
      end
      if (wd_valid && wd_ready) begin
        if (STRICT_WD != 0 && wq_n == 0) fail("C7 write data without an accepted write command");
        if (eb_n < WQ) begin
          eb_last[(eb_hd + eb_n) % WQ] = wd_last;
          eb_n = eb_n + 1;
        end
      end
      // match data beats to write commands in command order (with STRICT_WD = 0 a beat may
      // arrive before its command, e.g. behind the clock-domain crossing)
      while (wq_n > 0 && eb_n > 0) begin
        if (eb_last[eb_hd] !== (wbeat == wq_len[wq_hd])) fail("C7 wd_last framing");
        if (wbeat == wq_len[wq_hd]) begin
          wdat[wq_tag[wq_hd]] = 1'b1;
          wq_hd = (wq_hd + 1) % WQ;
          wq_n  = wq_n - 1;
          wbeat = 0;
        end else begin
          wbeat = wbeat + 1;
        end
        eb_hd = (eb_hd + 1) % WQ;
        eb_n  = eb_n - 1;
      end
      ph_cmd = cmd_valid && !cmd_ready;
      ph_wd  = wd_valid && !wd_ready;
      ph_rd  = rd_valid && !rd_ready;
      ph_wr  = wr_valid && !wr_ready;
      pv_cmd = {cmd_write, cmd_addr, cmd_len, cmd_tag};
      pv_wd  = {wd_data, wd_strb, wd_last};
      pv_rd  = {rd_data, rd_tag, rd_last, rd_error};
      pv_wr  = {wr_tag, wr_error};
    end
  end
endmodule

`default_nettype wire
