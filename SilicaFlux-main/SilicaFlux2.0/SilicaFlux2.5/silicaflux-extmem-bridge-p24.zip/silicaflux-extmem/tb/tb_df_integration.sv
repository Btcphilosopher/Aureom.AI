// =============================================================================
// SilicaFlux MemoryBridge :: tb_df_integration -- bridge inside the real DataFabric
//
//   master 0: TB host (CPU-like, single SFB2 transactions)
//   master 1: DataFabric DMA read port   } dma_burst_engine (DUAL_PORT = 1) or
//   master 2: DataFabric DMA write port  } dma_transfer_engine (DMA_KIND = 0)
//        |
//   sfb_crossbar (DataFabric, UNMODIFIED, round robin)
//        |
//   slave 0: SRAM  0x1000_0000 / 64 KiB (TB SFB2 slave model)
//   slave 1: EXTMEM 0x8000_0000 / 256 MiB window -> silicaflux_extmem_bridge
//                                              -> extmem_sim_mc (SIMULATION ONLY, 64 KiB)
//   slave 2: EXTMEM CSR page 0x4000_8000 (bridge CSR port; DMA denied)
//
// The bridge's upstream port is used in plain SFB2 rev 2.0 mode (len 0,
// last 1, id 0); the crossbar guarantees one outstanding transaction per slave
// port.  Checks: byte-exact copies SRAM -> EXT -> SRAM (DMA), concurrent host
// traffic to EXT against a reference, DMA error propagation from the bridge
// (window overflow -> WRITE_BUS, controller read error -> READ_BUS), CSR access
// through the crossbar, DataFabric sfb_protocol_checker on every port, MC
// checker on the controller side.  Prints copy throughput (bytes / cycle).
// =============================================================================
`timescale 1ps/1ps
`include "extmem_defs.svh"
`include "dma_defs.svh"
`default_nettype none

module tb_df_integration #(
  parameter int DMA_KIND = 1,          // 0 simple engine, 1 buffered dual-port engine
  parameter int LAT_MIN  = 4,
  parameter int LAT_MAX  = 20,
  parameter int COPY     = 16384       // bytes per DMA copy
);
  localparam int DW = 32, SB = 4, NM = 3, NS = 3, AW = 32;
  localparam int MEMB = 65536;
  localparam logic [31:0] SRAM_B = 32'h1000_0000, EXT_B = 32'h8000_0000, CSR_B = 32'h4000_8000;

  logic clk = 1'b0, rst_n;
  always #5000 clk = ~clk;

  // ------------------------------------------------------------ crossbar
  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NM*AW-1:0] m_req_addr;
  logic [NM*DW-1:0] m_req_wdata, m_rsp_rdata;
  logic [NM*SB-1:0] m_req_wstrb;
  logic [NS-1:0]    s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
  logic [NS*AW-1:0] s_req_addr;
  logic [NS*DW-1:0] s_req_wdata, s_rsp_rdata;
  logic [NS*SB-1:0] s_req_wstrb;
  logic             x_err_evt, x_err_write;
  logic [AW-1:0]    x_err_addr;
  logic [1:0]       x_err_master;
  logic [NM-1:0]    ev_acc, ev_stall, ev_loss, ev_rstall;

  sfb_crossbar #(
    .NM(NM), .NS(NS), .AW(AW), .DW(DW), .ARB_MODE(1), .CHECK_ALIGN(1),
    .SLV_BASE({CSR_B, EXT_B, SRAM_B}),
    .SLV_MASK({32'hFFFF_F000, 32'hF000_0000, 32'hFFFF_0000}),
    .MST_SLV_EN(9'b0_1101_1111)                         // DMA ports may not reach the CSR page
  ) u_xbar (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error,
    .err_evt(x_err_evt), .err_addr(x_err_addr), .err_master(x_err_master), .err_write(x_err_write),
    .ev_req_accept(ev_acc), .ev_req_stall(ev_stall), .ev_arb_loss(ev_loss), .ev_rsp_stall(ev_rstall)
  );

  // ------------------------------------------------------------ slave 0: SRAM model (SFB2, 1-cycle)
  logic [7:0] sram [MEMB];
  logic       sr_v;
  logic [31:0] sr_d;
  logic       sr_e;
  assign s_req_ready[0]     = !sr_v || s_rsp_ready[0];
  assign s_rsp_valid[0]     = sr_v;
  assign s_rsp_rdata[31:0]  = sr_d;
  assign s_rsp_error[0]     = sr_e;
  always @(posedge clk or negedge rst_n) begin
    if (rst_n !== 1'b1) begin
      sr_v <= 1'b0; sr_d <= '0; sr_e <= 1'b0;
    end else begin
      if (s_req_valid[0] && s_req_ready[0]) begin : acc
        int o;
        o = int'(s_req_addr[31:0] - SRAM_B);
        sr_v <= 1'b1;
        sr_e <= 1'b0;
        sr_d <= '0;
        if (s_req_write[0]) begin
          for (int y = 0; y < 4; y++) if (s_req_wstrb[y]) sram[o + y] = s_req_wdata[8*y +: 8];
        end else begin
          sr_d <= {sram[o + 3], sram[o + 2], sram[o + 1], sram[o]};
        end
      end else if (s_rsp_ready[0]) begin
        sr_v <= 1'b0;
      end
    end
  end

  // ------------------------------------------------------------ slave 1 + 2: the bridge
  logic             mc_rst_n, mc_init_done, mc_fatal;
  logic             mc_cmd_valid, mc_cmd_ready, mc_cmd_write;
  logic [15:0]      mc_cmd_addr;
  logic [7:0]       mc_cmd_len;
  logic [1:0]       mc_cmd_tag;
  logic             mc_wd_valid, mc_wd_ready, mc_wd_last;
  logic [31:0]      mc_wd_data;
  logic [3:0]       mc_wd_strb;
  logic             mc_rd_valid, mc_rd_ready, mc_rd_last, mc_rd_error;
  logic [31:0]      mc_rd_data;
  logic [1:0]       mc_rd_tag;
  logic             mc_wr_valid, mc_wr_ready, mc_wr_error;
  logic [1:0]       mc_wr_tag;
  logic [2:0]       st_state;
  logic             st_ready, st_cal_fail, st_fault_seen, st_idle, err_evt, err_write;
  logic [3:0]       err_code;
  logic [31:0]      err_addr;
  logic [0:0]       err_id, rsp_id_unused;
  logic             rsp_last_unused, rsp_write_unused;
  logic [`XM_PERF_N*32-1:0] perf_cnt;

  silicaflux_extmem_bridge #(
    .DW(32), .IDW(1), .LW(8), .MAX_BURST(8), .MAX_RD_OUT(4), .MAX_WR_OUT(4), .MC_AW(16),
    .EXT_BASE(EXT_B), .EXT_SIZE(33'(MEMB)), .BOUND_LOG2(12), .RESP_TIMEOUT(4000), .CAL_TIMEOUT(5000)
  ) u_bridge (
    .clk, .rst_n, .mc_clk(clk),
    .up_req_valid(s_req_valid[1]), .up_req_ready(s_req_ready[1]), .up_req_write(s_req_write[1]),
    .up_req_addr(s_req_addr[63:32]), .up_req_wdata(s_req_wdata[63:32]), .up_req_wstrb(s_req_wstrb[7:4]),
    .up_req_id(1'b0), .up_req_len(8'd0), .up_req_last(1'b1),
    .up_rsp_valid(s_rsp_valid[1]), .up_rsp_ready(s_rsp_ready[1]), .up_rsp_rdata(s_rsp_rdata[63:32]),
    .up_rsp_error(s_rsp_error[1]), .up_rsp_id(rsp_id_unused), .up_rsp_last(rsp_last_unused),
    .up_rsp_write(rsp_write_unused),
    .csr_req_valid(s_req_valid[2]), .csr_req_ready(s_req_ready[2]), .csr_req_write(s_req_write[2]),
    .csr_req_addr(s_req_addr[95:64]), .csr_req_wdata(s_req_wdata[95:64]), .csr_req_wstrb(s_req_wstrb[11:8]),
    .csr_rsp_valid(s_rsp_valid[2]), .csr_rsp_ready(s_rsp_ready[2]), .csr_rsp_rdata(s_rsp_rdata[95:64]),
    .csr_rsp_error(s_rsp_error[2]),
    .mc_rst_n, .mc_init_done, .mc_fatal,
    .mc_cmd_valid, .mc_cmd_ready, .mc_cmd_write, .mc_cmd_addr, .mc_cmd_len, .mc_cmd_tag,
    .mc_wd_valid, .mc_wd_ready, .mc_wd_data, .mc_wd_strb, .mc_wd_last,
    .mc_rd_valid, .mc_rd_ready, .mc_rd_data, .mc_rd_tag, .mc_rd_last, .mc_rd_error,
    .mc_wr_valid, .mc_wr_ready, .mc_wr_tag, .mc_wr_error,
    .ctl_mc_reset_req(1'b0), .st_state, .st_ready, .st_cal_fail, .st_fault_seen, .st_idle,
    .err_evt, .err_code, .err_addr, .err_id, .err_write, .perf_cnt
  );

  logic        tb_poison_en = 1'b0;
  logic [31:0] tb_poison_lo = 0, tb_poison_hi = 0;
  int m_viol, m_rc, m_wc, m_rb, m_wb, m_re, m_wp, m_h, m_m;
  extmem_sim_mc #(.DW(32), .MC_AW(16), .LW(8), .TW(2), .MB(8), .MEM_BYTES(MEMB), .OOO(1), .CAL_CYCLES(60), .SEED(3)) u_mc (
    .clk, .rst_n(mc_rst_n), .init_done(mc_init_done), .fatal(mc_fatal),
    .cmd_valid(mc_cmd_valid), .cmd_ready(mc_cmd_ready), .cmd_write(mc_cmd_write), .cmd_addr(mc_cmd_addr),
    .cmd_len(mc_cmd_len), .cmd_tag(mc_cmd_tag),
    .wd_valid(mc_wd_valid), .wd_ready(mc_wd_ready), .wd_data(mc_wd_data), .wd_strb(mc_wd_strb), .wd_last(mc_wd_last),
    .rd_valid(mc_rd_valid), .rd_ready(mc_rd_ready), .rd_data(mc_rd_data), .rd_tag(mc_rd_tag),
    .rd_last(mc_rd_last), .rd_error(mc_rd_error),
    .wr_valid(mc_wr_valid), .wr_ready(mc_wr_ready), .wr_tag(mc_wr_tag), .wr_error(mc_wr_error),
    .tb_cal_drop(1'b0), .tb_hang(1'b0), .tb_fatal(1'b0), .tb_poison_en, .tb_poison_lo, .tb_poison_hi,
    .tb_rderr_p16(32'd0), .tb_lat_min(32'(LAT_MIN)), .tb_lat_max(32'(LAT_MAX)), .tb_cmd_rdy_pct(32'd90),
    .tb_wd_rdy_pct(32'd90), .tb_rsp_pct(32'd90),
    .st_violations(m_viol), .st_rd_cmds(m_rc), .st_wr_cmds(m_wc), .st_rd_beats(m_rb), .st_wr_beats(m_wb),
    .st_rderr_inj(m_re), .st_wr_poisoned(m_wp), .st_row_hits(m_h), .st_row_miss(m_m)
  );

  // ------------------------------------------------------------ checkers
  int c_viol, c_a, c_b, c_c, c_d;
  extmem_mc_checker #(.DW(32), .MC_AW(16), .LW(8), .TW(2), .NAME("mc")) u_mchk (
    .clk, .rst_n(mc_rst_n),
    .cmd_valid(mc_cmd_valid), .cmd_ready(mc_cmd_ready), .cmd_write(mc_cmd_write), .cmd_addr(mc_cmd_addr),
    .cmd_len(mc_cmd_len), .cmd_tag(mc_cmd_tag),
    .wd_valid(mc_wd_valid), .wd_ready(mc_wd_ready), .wd_data(mc_wd_data), .wd_strb(mc_wd_strb), .wd_last(mc_wd_last),
    .rd_valid(mc_rd_valid), .rd_ready(mc_rd_ready), .rd_data(mc_rd_data), .rd_tag(mc_rd_tag),
    .rd_last(mc_rd_last), .rd_error(mc_rd_error),
    .wr_valid(mc_wr_valid), .wr_ready(mc_wr_ready), .wr_tag(mc_wr_tag), .wr_error(mc_wr_error),
    .violations(c_viol), .n_rd_cmd(c_a), .n_wr_cmd(c_b), .n_rd_beats(c_c), .n_wr_rsp(c_d)
  );
  logic [31:0] pv [NM+NS];
  logic [31:0] pn0 [NM+NS], pn1 [NM+NS], pn2 [NM+NS];
  genvar gi;
  for (gi = 0; gi < NM; gi++) begin : g_mchk
    sfb_protocol_checker #(.AW(AW), .DW(DW), .MAX_OUT((gi == 0) ? 1 : 2), .NAME("df_master")) u_c (
      .clk, .rst_n, .req_valid(m_req_valid[gi]), .req_ready(m_req_ready[gi]), .req_write(m_req_write[gi]),
      .req_addr(m_req_addr[gi*AW +: AW]), .req_wdata(m_req_wdata[gi*DW +: DW]), .req_wstrb(m_req_wstrb[gi*SB +: SB]),
      .rsp_valid(m_rsp_valid[gi]), .rsp_ready(m_rsp_ready[gi]), .rsp_rdata(m_rsp_rdata[gi*DW +: DW]),
      .rsp_error(m_rsp_error[gi]), .violations(pv[gi]), .n_req(pn0[gi]), .n_rsp(pn1[gi]), .outstanding(pn2[gi]));
  end
  for (gi = 0; gi < NS; gi++) begin : g_schk
    sfb_protocol_checker #(.AW(AW), .DW(DW), .MAX_OUT(1), .NAME("df_slave")) u_c (
      .clk, .rst_n, .req_valid(s_req_valid[gi]), .req_ready(s_req_ready[gi]), .req_write(s_req_write[gi]),
      .req_addr(s_req_addr[gi*AW +: AW]), .req_wdata(s_req_wdata[gi*DW +: DW]), .req_wstrb(s_req_wstrb[gi*SB +: SB]),
      .rsp_valid(s_rsp_valid[gi]), .rsp_ready(s_rsp_ready[gi]), .rsp_rdata(s_rsp_rdata[gi*DW +: DW]),
      .rsp_error(s_rsp_error[gi]), .violations(pv[NM+gi]), .n_req(pn0[NM+gi]), .n_rsp(pn1[NM+gi]),
      .outstanding(pn2[NM+gi]));
  end

  // ------------------------------------------------------------ DataFabric DMA engine
  logic        d_start, d_abort, d_busy, d_done, d_fail, d_stall;
  logic [31:0] d_src, d_dst, d_len, d_eaddr, d_bytes;
  logic [3:0]  d_ecode;
  logic [2:0]  d_state;
  logic [7:0]  d_fifo;
  generate
    if (DMA_KIND != 0) begin : g_buf
      dma_burst_engine #(.DW(32), .MAX_LEN_LOG2(24), .FIFO_DEPTH(8), .BURST(8), .DUAL_PORT(1), .MAX_OUT(2)) u_dma (
        .clk, .rst_n, .start(d_start), .abort(d_abort), .cfg_src(d_src), .cfg_dst(d_dst), .cfg_len(d_len),
        .busy(d_busy), .done(d_done), .fail(d_fail), .err_code(d_ecode), .err_addr(d_eaddr), .bytes_done(d_bytes),
        .state(d_state), .ev_stall(d_stall), .fifo_level(d_fifo),
        .req_valid(m_req_valid[2:1]), .req_ready(m_req_ready[2:1]), .req_write(m_req_write[2:1]),
        .req_addr(m_req_addr[95:32]), .req_wdata(m_req_wdata[95:32]), .req_wstrb(m_req_wstrb[11:4]),
        .rsp_valid(m_rsp_valid[2:1]), .rsp_ready(m_rsp_ready[2:1]), .rsp_rdata(m_rsp_rdata[95:32]),
        .rsp_error(m_rsp_error[2:1]));
    end else begin : g_simple
      dma_transfer_engine #(.DW(32), .MAX_LEN_LOG2(24)) u_dma (
        .clk, .rst_n, .start(d_start), .abort(d_abort), .cfg_src(d_src), .cfg_dst(d_dst), .cfg_len(d_len),
        .busy(d_busy), .done(d_done), .fail(d_fail), .err_code(d_ecode), .err_addr(d_eaddr), .bytes_done(d_bytes),
        .state(d_state), .ev_stall(d_stall),
        .req_valid(m_req_valid[1]), .req_ready(m_req_ready[1]), .req_write(m_req_write[1]),
        .req_addr(m_req_addr[63:32]), .req_wdata(m_req_wdata[63:32]), .req_wstrb(m_req_wstrb[7:4]),
        .rsp_valid(m_rsp_valid[1]), .rsp_ready(m_rsp_ready[1]), .rsp_rdata(m_rsp_rdata[63:32]),
        .rsp_error(m_rsp_error[1]));
      assign m_req_valid[2] = 1'b0; assign m_req_write[2] = 1'b0; assign m_req_addr[95:64] = '0;
      assign m_req_wdata[95:64] = '0; assign m_req_wstrb[11:8] = '0; assign m_rsp_ready[2] = 1'b1;
      assign d_fifo = '0;
    end
  endgenerate

  // ------------------------------------------------------------ host master (port 0)
  logic        h_valid, h_write;
  logic [31:0] h_addr, h_wdata;
  logic [3:0]  h_strb;
  assign m_req_valid[0]   = h_valid;
  assign m_req_write[0]   = h_write;
  assign m_req_addr[31:0] = h_addr;
  assign m_req_wdata[31:0]= h_wdata;
  assign m_req_wstrb[3:0] = h_strb;
  assign m_rsp_ready[0]   = 1'b1;
  logic [31:0] h_q;
  logic        h_e;
  task automatic host(input logic wr, input logic [31:0] a, input logic [31:0] d, input logic [3:0] s);
    @(negedge clk);
    h_valid = 1'b1; h_write = wr; h_addr = a; h_wdata = d; h_strb = s;
    @(posedge clk);
    while (!m_req_ready[0]) @(posedge clk);
    @(negedge clk);
    h_valid = 1'b0;
    while (!m_rsp_valid[0]) @(negedge clk);
    h_q = m_rsp_rdata[31:0];
    h_e = m_rsp_error[0];
  endtask

  // ------------------------------------------------------------ program
  int errors = 0, cyc = 0, t0, t1;
  logic [7:0] href [4096];
  always @(posedge clk) cyc++;
  task automatic fail(input [8*80-1:0] m);
    errors++;
    if (errors < 20) $display("[%0t] TB ERROR: %0s", $time, m);
  endtask

  task automatic dma(input logic [31:0] s, input logic [31:0] d, input logic [31:0] n, output int cycles);
    @(negedge clk);
    d_src = s; d_dst = d; d_len = n; d_start = 1'b1;
    @(negedge clk);
    d_start = 1'b0;
    cycles = cyc;
    @(negedge clk);
    while (!(d_done_s || d_fail_s)) @(negedge clk);
    cycles = cyc - cycles;
  endtask

  // DMA done / fail are one-cycle pulses: latch them
  logic d_done_s, d_fail_s;
  always @(posedge clk) begin
    if (d_start)     begin d_done_s <= 1'b0; d_fail_s <= 1'b0; end
    else begin
      if (d_done) d_done_s <= 1'b1;
      if (d_fail) d_fail_s <= 1'b1;
    end
  end

  int unsigned rs = 32'h2545F491;
  task automatic t_rnd(output int unsigned v);
    rs = rs ^ (rs << 13); rs = rs ^ (rs >> 17); rs = rs ^ (rs << 5); v = rs;
  endtask

  int unsigned v;
  int c1, c2, hostops;
  logic copy_fail;
  initial begin
    h_valid = 1'b0; h_write = 1'b0; h_addr = '0; h_wdata = '0; h_strb = '0;
    d_start = 1'b0; d_abort = 1'b0; d_src = '0; d_dst = '0; d_len = '0;
    #1 rst_n = 1'b0;
    for (int i = 0; i < MEMB; i++) begin t_rnd(v); sram[i] = v[7:0]; end
    repeat (5) @(negedge clk);
    rst_n = 1'b1;
    while (!st_ready) @(negedge clk);

    // ---- CSR through the crossbar
    host(1'b0, CSR_B + 32'h0, 0, 4'hF);  if (h_e || h_q != 32'h5346584D) fail("CSR ID via crossbar");
    host(1'b0, CSR_B + 32'h18, 0, 4'hF); if (h_e || !h_q[3]) fail("CSR STATUS.READY via crossbar");

    // ---- DMA: SRAM[0 .. COPY) -> EXT[0 .. COPY)
    dma(SRAM_B, EXT_B, COPY, c1);
    if (!d_done_s || d_fail_s) fail("DMA SRAM->EXT failed");
    for (int i = 0; i < COPY; i++) if (u_mc.mem[i] !== sram[i]) begin fail("EXT content != SRAM source"); break; end

    // ---- DMA: EXT[0 .. COPY) -> SRAM[0x8000 ..) while the host hammers EXT[0x8000 .. 0x9000)
    for (int i = 0; i < 4096; i++) href[i] = u_mc.mem[32768 + i];
    @(negedge clk);
    d_src = EXT_B; d_dst = SRAM_B + 32'h8000; d_len = COPY; d_start = 1'b1;
    @(negedge clk);
    d_start = 1'b0;
    t0 = cyc;
    hostops = 0;
    @(negedge clk);
    while (!(d_done_s || d_fail_s)) begin : hammer
      int o;
      logic [31:0] w;
      t_rnd(v); o = int'(v % 1024) * 4;
      t_rnd(v); w = v;
      if (v[0]) begin
        host(1'b1, EXT_B + 32'h8000 + 32'(o), w, w[7:4]);
        if (h_e) fail("host write to EXT failed");
        for (int y = 0; y < 4; y++) if (w[4 + y]) href[o + y] = w[8*y +: 8];
      end else begin
        host(1'b0, EXT_B + 32'h8000 + 32'(o), 0, 4'hF);
        if (h_e || h_q != {href[o+3], href[o+2], href[o+1], href[o]}) fail("host read of EXT mismatched");
      end
      hostops++;
    end
    c2 = cyc - t0;
    if (!d_done_s || d_fail_s) fail("DMA EXT->SRAM failed");
    copy_fail = 1'b0;
    for (int i = 0; i < COPY; i++) if (sram[32768 + i] !== sram[i]) copy_fail = 1'b1;
    if (copy_fail) fail("round-trip copy SRAM->EXT->SRAM mismatched");
    for (int i = 0; i < 4096; i++) if (u_mc.mem[32768 + i] !== href[i]) begin fail("host region in EXT corrupted"); break; end

    // ---- error propagation: DMA write beyond the 64 KiB controller (inside the 256 MiB crossbar window)
    dma(SRAM_B, EXT_B + 32'(MEMB) - 32'd64, 128, t1);
    if (!d_fail_s || d_ecode != `DMA_ERR_WRITE_BUS) fail("DMA did not report WRITE_BUS for an out-of-range EXT write");
    if (d_eaddr != EXT_B + 32'(MEMB)) fail("DMA error address != first out-of-range address");
    host(1'b0, CSR_B + 32'h24, 0, 4'hF);
    if (!h_q[0] || h_q[7:4] != `XM_ERR_RANGE) fail("bridge ERR_STATUS did not capture the RANGE error");
    if (h_q[0]) host(1'b1, CSR_B + 32'h24, 32'h3, 4'hF);
    // ---- error propagation: controller read error (poisoned range) -> READ_BUS
    tb_poison_en = 1'b1; tb_poison_lo = 32'h100; tb_poison_hi = 32'h104;
    dma(EXT_B, SRAM_B + 32'hC000, 512, t1);
    if (!d_fail_s || d_ecode != `DMA_ERR_READ_BUS || d_eaddr != EXT_B + 32'h100)
      fail("DMA did not report READ_BUS at the poisoned EXT address");
    tb_poison_en = 1'b0;

    repeat (50) @(negedge clk);
    for (int i = 0; i < NM + NS; i++) if (pv[i] != 0) fail("DataFabric SFB2 protocol checker violation");
    if (c_viol != 0 || m_viol != 0) fail("MC-interface / model violation");
    if (perf_cnt[`XM_P_MC_PROTO*32 +: 32] != 0) fail("controller protocol violations seen by the bridge");

    $display("XFER dma_kind=%0d copy_bytes=%0d sram_to_ext_cycles=%0d ext_to_sram_cycles=%0d host_ops_during_copy=%0d",
             DMA_KIND, COPY, c1, c2, hostops);
    $display("XFER bytes_per_cycle sram_to_ext=%0.3f ext_to_sram=%0.3f (crossbar: one outstanding per slave port)",
             real'(COPY) / real'(c1), real'(COPY) / real'(c2));
    $display("RESULT %s test=df_integration dma_kind=%0d errors=%0d cycles=%0d", (errors == 0) ? "PASS" : "FAIL",
             DMA_KIND, errors, cyc);
    $finish;
  end
  initial begin
    #(64'd40_000_000_000);
    $display("RESULT FAIL test=df_integration errors=timeout");
    $finish;
  end
endmodule

`default_nettype wire
