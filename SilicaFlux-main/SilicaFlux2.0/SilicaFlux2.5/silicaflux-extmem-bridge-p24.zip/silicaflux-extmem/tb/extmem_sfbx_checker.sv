// =============================================================================
// SilicaFlux MemoryBridge :: extmem_sfbx_checker -- SFB2-X port monitor
//
// Verification only.  Passive checks of docs/PROTOCOL_SFB2X.md on one port:
//   X1 a held request (valid && !ready) stays valid with an unchanged payload
//      (write, addr, wdata, wstrb, id, len, last)                   [SFB2 R2]
//   X2 a held response stays valid with an unchanged payload         [SFB2 R4]
//   X3 rsp_rdata == 0 on error beats and on write responses          [SFB2 R8]
//   X4 a write response is a single beat (rsp_last = 1)
//   X5 no X/Z on valid / ready after reset
// Transaction-level rules (exactly one response per transaction, per-ID or
// global order, beat counts, data) are checked by the testbench scoreboard.
// =============================================================================
`default_nettype none

module extmem_sfbx_checker #(
  parameter int AW   = 32,
  parameter int DW   = 64,
  parameter int IDW  = 4,
  parameter int LW   = 8,
  parameter     NAME = "sfbx",
  localparam int SB  = DW / 8
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic           req_valid,
  input  wire logic           req_ready,
  input  wire logic           req_write,
  input  wire logic [AW-1:0]  req_addr,
  input  wire logic [DW-1:0]  req_wdata,
  input  wire logic [SB-1:0]  req_wstrb,
  input  wire logic [IDW-1:0] req_id,
  input  wire logic [LW-1:0]  req_len,
  input  wire logic           req_last,
  input  wire logic           rsp_valid,
  input  wire logic           rsp_ready,
  input  wire logic [DW-1:0]  rsp_rdata,
  input  wire logic           rsp_error,
  input  wire logic [IDW-1:0] rsp_id,
  input  wire logic           rsp_last,
  input  wire logic           rsp_write,
  output int                  violations
);
  logic ph_req, ph_rsp;
  logic [1+AW+DW+SB+IDW+LW:0] pv_req;
  logic [DW+IDW+2:0]          pv_rsp;

  task automatic fail(input [8*64-1:0] msg);
    violations = violations + 1;
    $display("[%0t] %0s SFB2-X VIOLATION: %0s", $time, NAME, msg);
  endtask

  initial violations = 0;

  always @(posedge clk or negedge rst_n) begin
    if (rst_n !== 1'b1) begin      // X during 4-state power-up counts as reset
      ph_req = 1'b0;
      ph_rsp = 1'b0;
    end else begin
      if ((req_valid !== 1'b0 && req_valid !== 1'b1) || (req_ready !== 1'b0 && req_ready !== 1'b1) ||
          (rsp_valid !== 1'b0 && rsp_valid !== 1'b1) || (rsp_ready !== 1'b0 && rsp_ready !== 1'b1))
        fail("X5 X/Z on a handshake signal");
      if (ph_req && (!req_valid ||
                     {req_write, req_addr, req_wdata, req_wstrb, req_id, req_len, req_last} !== pv_req))
        fail("X1 request not held");
      if (ph_rsp && (!rsp_valid || {rsp_rdata, rsp_error, rsp_id, rsp_last, rsp_write} !== pv_rsp))
        fail("X2 response not held");
      if (rsp_valid && (rsp_error || rsp_write) && rsp_rdata !== '0) fail("X3 rdata not zero on error/write");
      if (rsp_valid && rsp_write && !rsp_last) fail("X4 write response without rsp_last");
      ph_req = req_valid && !req_ready;
      ph_rsp = rsp_valid && !rsp_ready;
      pv_req = {req_write, req_addr, req_wdata, req_wstrb, req_id, req_len, req_last};
      pv_rsp = {rsp_rdata, rsp_error, rsp_id, rsp_last, rsp_write};
    end
  end
endmodule

`default_nettype wire
