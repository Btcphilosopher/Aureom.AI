// =============================================================================
// SilicaFlux MemoryBridge :: tb_extmem -- self-checking testbench
//
//   TB master (SFB2-X) --> silicaflux_extmem_bridge --> extmem_sim_mc (SIM ONLY)
//        |   ^                        |                         |
//        |   +-- scoreboard <---------+ responses               | mem[] (end-state)
//        +--> reference model (independent DRAM transaction model)
//
// Reference model: a byte array + "known" flags, updated purely from the
// upstream transaction stream in acceptance order (the memory semantics the
// bridge must provide).  It never looks inside the bridge or the controller
// model.  Read data is predicted at acceptance; a byte becomes "unknown" only
// where the outcome is legitimately undefined (a write accepted while the
// controller fails / the bridge resets).  At the end the controller model's
// storage is compared byte for byte with every known reference byte.
//
// Checks: exactly one response per transaction (none lost, none duplicated,
// none unsolicited), beat count and rsp_last framing, per-ID or global order,
// no interleaving of response beats, rsp_write type, expected / allowed
// errors, rdata = 0 on errors, read data of every known byte, end-state
// memory, protocol checkers on both interfaces (SFB2-X, DataFabric SFB2
// checker in SFB2-compatible configs, MC-interface checker, model checks),
// performance-counter consistency with the scoreboard.
//
// Plusargs: +TEST=<name> +SEED=<n> +NTXN=<n> (+bench knobs, see test "bench")
// Prints one line "RESULT PASS|FAIL ..." and "PERF <idx> <value>" lines.
// =============================================================================
`timescale 1ps/1ps
`include "extmem_defs.svh"
`default_nettype none

module tb_extmem #(
  parameter int DW             = 64,
  parameter int IDW            = 4,
  parameter int LW             = 8,
  parameter int MAX_BURST      = 16,
  parameter int MAX_RD_OUT     = 8,
  parameter int MAX_WR_OUT     = 8,
  parameter int ROB_DEPTH      = 0,
  parameter int UP_OOO         = 0,
  parameter int SCHED_MODE     = 0,
  parameter int WR_HI          = 6,
  parameter int WR_LO          = 2,
  parameter int AGE_CAP        = 16,
  parameter int UNAVAIL_POLICY = 0,
  parameter int RST_HOLD       = 16,
  parameter int CAL_TIMEOUT    = 3000,
  parameter int RESP_TIMEOUT   = 2000,
  parameter int AUTO_RECOVER   = 1,
  parameter int ASYNC          = 0,
  parameter int CDC_DEPTH      = 8,
  parameter int CLK_PS         = 10000,
  parameter int MC_PS          = 10000,
  parameter int MC_OOO         = 0,
  parameter int MC_INTERLEAVE  = 0,
  parameter int MEM_BYTES      = 65536,
  parameter int CAL_CYCLES     = 40,
  parameter int BOUND_LOG2     = 12,
  parameter int SFB2_ONLY      = 0      // 1: stimulus restricted to what a DataFabric SFB2 rev 2.0 master can issue
);
  localparam int          AW    = 32;
  localparam int          SB    = DW / 8;
  localparam int          OFF   = $clog2(SB);
  localparam int          MB    = MAX_BURST;
  localparam int          NROB  = (ROB_DEPTH > 0) ? ROB_DEPTH : (MAX_RD_OUT + MAX_WR_OUT + 2);
  localparam int          MC_AW = $clog2(MEM_BYTES);
  localparam logic [31:0] BASE  = 32'h8000_0000;
  localparam int          RTW   = (MAX_RD_OUT > 1) ? $clog2(MAX_RD_OUT) : 1;
  localparam int          WTW   = (MAX_WR_OUT > 1) ? $clog2(MAX_WR_OUT) : 1;
  localparam int          TW    = (RTW > WTW) ? RTW : WTW;
  localparam int          NID   = 1 << IDW;
  localparam int          MAXT  = 128;
  localparam int          MAXB  = 1 << LW;           // longest request the bus can express

  // ------------------------------------------------------------ clocks / reset
  logic clk = 1'b0, mc_clk = 1'b0, rst_n;       // rst_n: X -> 0 edge at 1 ps (async reset event)
  always #(CLK_PS / 2) clk = ~clk;
  always #(MC_PS / 2) mc_clk = ~mc_clk;

  // ------------------------------------------------------------ DUT signals
  logic             up_req_valid, up_req_ready, up_req_write, up_req_last;
  logic [AW-1:0]    up_req_addr;
  logic [DW-1:0]    up_req_wdata;
  logic [SB-1:0]    up_req_wstrb;
  logic [IDW-1:0]   up_req_id;
  logic [LW-1:0]    up_req_len;
  logic             up_rsp_valid, up_rsp_ready, up_rsp_error, up_rsp_last, up_rsp_write;
  logic [DW-1:0]    up_rsp_rdata;
  logic [IDW-1:0]   up_rsp_id;
  logic             csr_req_valid, csr_req_ready, csr_req_write, csr_rsp_valid, csr_rsp_ready, csr_rsp_error;
  logic [31:0]      csr_req_addr, csr_req_wdata, csr_rsp_rdata;
  logic [3:0]       csr_req_wstrb;
  logic             mc_rst_n, mc_init_done, mc_fatal;
  logic             mc_cmd_valid, mc_cmd_ready, mc_cmd_write;
  logic [MC_AW-1:0] mc_cmd_addr;
  logic [LW-1:0]    mc_cmd_len;
  logic [TW-1:0]    mc_cmd_tag;
  logic             mc_wd_valid, mc_wd_ready, mc_wd_last;
  logic [DW-1:0]    mc_wd_data;
  logic [SB-1:0]    mc_wd_strb;
  logic             mc_rd_valid, mc_rd_ready, mc_rd_last, mc_rd_error;
  logic [DW-1:0]    mc_rd_data;
  logic [TW-1:0]    mc_rd_tag;
  logic             mc_wr_valid, mc_wr_ready, mc_wr_error;
  logic [TW-1:0]    mc_wr_tag;
  logic             ctl_mc_reset_req;
  logic [2:0]       st_state;
  logic             st_ready, st_cal_fail, st_fault_seen, st_idle;
  logic             err_evt, err_write;
  logic [3:0]       err_code;
  logic [AW-1:0]    err_addr;
  logic [IDW-1:0]   err_id;
  logic [`XM_PERF_N*32-1:0] perf_cnt;

  silicaflux_extmem_bridge #(
    .AW(AW), .DW(DW), .IDW(IDW), .LW(LW), .MAX_BURST(MAX_BURST), .MAX_RD_OUT(MAX_RD_OUT),
    .MAX_WR_OUT(MAX_WR_OUT), .ROB_DEPTH(ROB_DEPTH), .MC_AW(MC_AW), .EXT_BASE(BASE),
    .EXT_SIZE(33'(MEM_BYTES)), .BOUND_LOG2(BOUND_LOG2), .UP_OOO(UP_OOO), .SCHED_MODE(SCHED_MODE),
    .WR_HI(WR_HI), .WR_LO(WR_LO), .AGE_CAP(AGE_CAP), .UNAVAIL_POLICY(UNAVAIL_POLICY),
    .RST_HOLD(RST_HOLD), .CAL_TIMEOUT(CAL_TIMEOUT), .RESP_TIMEOUT(RESP_TIMEOUT),
    .AUTO_RECOVER(AUTO_RECOVER), .PERF(1), .ASYNC(ASYNC), .CDC_DEPTH(CDC_DEPTH)
  ) dut (
    .clk, .rst_n, .mc_clk,
    .up_req_valid, .up_req_ready, .up_req_write, .up_req_addr, .up_req_wdata, .up_req_wstrb,
    .up_req_id, .up_req_len, .up_req_last,
    .up_rsp_valid, .up_rsp_ready, .up_rsp_rdata, .up_rsp_error, .up_rsp_id, .up_rsp_last, .up_rsp_write,
    .csr_req_valid, .csr_req_ready, .csr_req_write, .csr_req_addr, .csr_req_wdata, .csr_req_wstrb,
    .csr_rsp_valid, .csr_rsp_ready, .csr_rsp_rdata, .csr_rsp_error,
    .mc_rst_n, .mc_init_done, .mc_fatal,
    .mc_cmd_valid, .mc_cmd_ready, .mc_cmd_write, .mc_cmd_addr, .mc_cmd_len, .mc_cmd_tag,
    .mc_wd_valid, .mc_wd_ready, .mc_wd_data, .mc_wd_strb, .mc_wd_last,
    .mc_rd_valid, .mc_rd_ready, .mc_rd_data, .mc_rd_tag, .mc_rd_last, .mc_rd_error,
    .mc_wr_valid, .mc_wr_ready, .mc_wr_tag, .mc_wr_error,
    .ctl_mc_reset_req, .st_state, .st_ready, .st_cal_fail, .st_fault_seen, .st_idle,
    .err_evt, .err_code, .err_addr, .err_id, .err_write, .perf_cnt
  );

  // ------------------------------------------------------------ simulated controller (SIM ONLY)
  logic        tb_cal_drop = 1'b0, tb_hang = 1'b0, tb_fatal = 1'b0, tb_poison_en = 1'b0;
  logic [31:0] tb_poison_lo = 0, tb_poison_hi = 0, tb_rderr_p16 = 0;
  logic [31:0] tb_lat_min = 2, tb_lat_max = 12, tb_cmd_rdy_pct = 100, tb_wd_rdy_pct = 100, tb_rsp_pct = 100;
  int m_viol, m_rd_cmds, m_wr_cmds, m_rd_beats, m_wr_beats, m_rderr, m_wpois, m_hits, m_miss;
  wire mclk = (ASYNC != 0) ? mc_clk : clk;

  extmem_sim_mc #(
    .DW(DW), .MC_AW(MC_AW), .LW(LW), .TW(TW), .MB(MB), .MEM_BYTES(MEM_BYTES), .OOO(MC_OOO),
    .INTERLEAVE(MC_INTERLEAVE), .CAL_CYCLES(CAL_CYCLES), .STRICT_WD((ASYNC != 0) ? 0 : 1),
    .SEED(7)
  ) u_mc (
    .clk(mclk), .rst_n(mc_rst_n), .init_done(mc_init_done), .fatal(mc_fatal),
    .cmd_valid(mc_cmd_valid), .cmd_ready(mc_cmd_ready), .cmd_write(mc_cmd_write), .cmd_addr(mc_cmd_addr),
    .cmd_len(mc_cmd_len), .cmd_tag(mc_cmd_tag),
    .wd_valid(mc_wd_valid), .wd_ready(mc_wd_ready), .wd_data(mc_wd_data), .wd_strb(mc_wd_strb),
    .wd_last(mc_wd_last),
    .rd_valid(mc_rd_valid), .rd_ready(mc_rd_ready), .rd_data(mc_rd_data), .rd_tag(mc_rd_tag),
    .rd_last(mc_rd_last), .rd_error(mc_rd_error),
    .wr_valid(mc_wr_valid), .wr_ready(mc_wr_ready), .wr_tag(mc_wr_tag), .wr_error(mc_wr_error),
    .tb_cal_drop, .tb_hang, .tb_fatal, .tb_poison_en, .tb_poison_lo, .tb_poison_hi, .tb_rderr_p16,
    .tb_lat_min, .tb_lat_max, .tb_cmd_rdy_pct, .tb_wd_rdy_pct, .tb_rsp_pct,
    .st_violations(m_viol), .st_rd_cmds(m_rd_cmds), .st_wr_cmds(m_wr_cmds), .st_rd_beats(m_rd_beats),
    .st_wr_beats(m_wr_beats), .st_rderr_inj(m_rderr), .st_wr_poisoned(m_wpois), .st_row_hits(m_hits),
    .st_row_miss(m_miss)
  );

  // ------------------------------------------------------------ protocol checkers
  int x_viol, c_viol, c_rd_cmd, c_wr_cmd, c_rd_beats, c_wr_rsp;
  extmem_sfbx_checker #(.AW(AW), .DW(DW), .IDW(IDW), .LW(LW), .NAME("up")) u_xchk (
    .clk, .rst_n, .req_valid(up_req_valid), .req_ready(up_req_ready), .req_write(up_req_write),
    .req_addr(up_req_addr), .req_wdata(up_req_wdata), .req_wstrb(up_req_wstrb), .req_id(up_req_id),
    .req_len(up_req_len), .req_last(up_req_last), .rsp_valid(up_rsp_valid), .rsp_ready(up_rsp_ready),
    .rsp_rdata(up_rsp_rdata), .rsp_error(up_rsp_error), .rsp_id(up_rsp_id), .rsp_last(up_rsp_last),
    .rsp_write(up_rsp_write), .violations(x_viol)
  );
  extmem_mc_checker #(.DW(DW), .MC_AW(MC_AW), .LW(LW), .TW(TW), .STRICT_WD((ASYNC != 0) ? 0 : 1),
                      .NAME("mc")) u_mchk (
    .clk(mclk), .rst_n(mc_rst_n),
    .cmd_valid(mc_cmd_valid), .cmd_ready(mc_cmd_ready), .cmd_write(mc_cmd_write), .cmd_addr(mc_cmd_addr),
    .cmd_len(mc_cmd_len), .cmd_tag(mc_cmd_tag),
    .wd_valid(mc_wd_valid), .wd_ready(mc_wd_ready), .wd_data(mc_wd_data), .wd_strb(mc_wd_strb),
    .wd_last(mc_wd_last),
    .rd_valid(mc_rd_valid), .rd_ready(mc_rd_ready), .rd_data(mc_rd_data), .rd_tag(mc_rd_tag),
    .rd_last(mc_rd_last), .rd_error(mc_rd_error),
    .wr_valid(mc_wr_valid), .wr_ready(mc_wr_ready), .wr_tag(mc_wr_tag), .wr_error(mc_wr_error),
    .violations(c_viol), .n_rd_cmd(c_rd_cmd), .n_wr_cmd(c_wr_cmd), .n_rd_beats(c_rd_beats), .n_wr_rsp(c_wr_rsp)
  );

  // DataFabric's own SFB2 checker (unmodified, third_party) on SFB2-compatible configurations
  logic [31:0] df_viol, df_nreq, df_nrsp, df_out;
  generate
    if (SFB2_ONLY != 0) begin : g_dfchk
      // the bridge holds up to NROB transactions plus one in its response register
      sfb_protocol_checker #(.AW(AW), .DW(DW), .MAX_OUT(NROB + 1), .CHECK_RDATA_ZERO((NROB + 1 <= 8) ? 1 : 0),
                             .NAME("up_sfb2")) u_dfchk (
        .clk, .rst_n, .req_valid(up_req_valid), .req_ready(up_req_ready), .req_write(up_req_write),
        .req_addr(up_req_addr), .req_wdata(up_req_wdata), .req_wstrb(up_req_wstrb),
        .rsp_valid(up_rsp_valid), .rsp_ready(up_rsp_ready), .rsp_rdata(up_rsp_rdata), .rsp_error(up_rsp_error),
        .violations(df_viol), .n_req(df_nreq), .n_rsp(df_nrsp), .outstanding(df_out)
      );
    end else begin : g_nodfchk
      assign df_viol = 0; assign df_nreq = 0; assign df_nrsp = 0; assign df_out = 0;
    end
  endgenerate

  // ------------------------------------------------------------ PRNG
  // Pure xorshift32 + tasks: every draw is a statement, never a side effect inside an
  // expression (Verilator may reorder / duplicate impure function calls), so Verilator and
  // Icarus consume the same random stream in the same order -> cycle-identical runs.
  int unsigned rs = 1;
  function automatic int unsigned xs32(input int unsigned x);
    int unsigned y;
    y = x ^ (x << 13);
    y = y ^ (y >> 17);
    y = y ^ (y << 5);
    xs32 = y;
  endfunction
  task automatic t_rnd(output int unsigned v);
    rs = xs32(rs);
    v  = rs;
  endtask
  task automatic t_rr(input int lo, input int hi, output int r);      // inclusive
    int unsigned v;
    if (hi <= lo) r = lo;
    else begin
      t_rnd(v);
      r = lo + int'(v % (hi - lo + 1));
    end
  endtask
  task automatic t_pct(input int p, output logic r);
    int unsigned v;
    t_rnd(v);
    r = (int'(v % 100) < p);
  endtask

  // ------------------------------------------------------------ reference model
  logic [7:0] ref_mem   [MEM_BYTES];
  logic       ref_known [MEM_BYTES];

  // ------------------------------------------------------------ transaction records
  logic          t_used  [MAXT];
  logic          t_wr    [MAXT];
  int            t_id    [MAXT];
  int            t_len   [MAXT];
  logic [31:0]   t_addr  [MAXT];
  int            t_beat  [MAXT];
  int            t_werr  [MAXT];          // writes: 0 must be OK, 1 must fail, 2 either
  logic          t_allerr[MAXT];          // reads: every beat must fail
  logic          t_anyerr[MAXT];
  int            t_code  [MAXT];
  logic [1:0]    t_berr  [MAXT*MB];       // reads: per beat 0/1/2
  logic [DW-1:0] t_bdata [MAXT*MB];       // reads: predicted data; writes: data sent
  logic [SB-1:0] t_bknown[MAXT*MB];       // reads: known bytes; writes: strobes
  // order queues
  int            gq [MAXT];
  int            gq_hd, gq_n;
  int            iq [NID*MAXT];
  int            iq_hd [NID];
  int            iq_n  [NID];
  int            n_live, stream_t;

  // ------------------------------------------------------------ knobs (set by the test program at negedge)
  logic gen_on = 1'b0;
  int   target = 0, started = 0;
  int   wr_pct = 50, max_len = 0, min_len = 0, addr_mode = 0, rlo = 0, rhi = MEM_BYTES, strb_mode = 0;
  int   rsp_rdy_pct = 100, bubble_pct = 0, err_pct = 0, err_kind = -1, proto_pct = 0, n_ids = 1, max_out_tb = 64;
  logic win_may = 1'b0;
  int   seq_ptr = 0;

  // ------------------------------------------------------------ statistics / results
  int errors = 0, cyc = 0;
  int n_rd_acc, n_wr_acc, n_rd_done, n_wr_done, n_err_txn, n_rd_beats_ok, n_wr_beats_up;
  int tot_txn = 0, tot_err_rsp = 0, tot_must_err = 0, tot_resets = 0, tot_faults = 0;

  task automatic fail(input [8*96-1:0] msg);
    errors = errors + 1;
    if (errors <= 20) $display("[%0t] TB ERROR: %0s", $time, msg);
  endtask

  // ------------------------------------------------------------ helpers
  function automatic int static_err(input logic wr, input logic [31:0] a, input int len);
    longint unsigned s, e, lim;
    static_err = `XM_ERR_NONE;
    s   = longint'(a);
    e   = s + longint'((len + 1) * SB) - 1;
    lim = longint'(BASE) + longint'(MEM_BYTES) - 1;
    if (len > MB - 1)                                  static_err = `XM_ERR_LEN;
    else if ((a % SB) != 0)                            static_err = `XM_ERR_ALIGN;
    else if (s < longint'(BASE) || e > lim)            static_err = `XM_ERR_RANGE;
    else if ((s >> BOUND_LOG2) != (e >> BOUND_LOG2))   static_err = `XM_ERR_BOUNDARY;
  endfunction

  function automatic int alloc_t();
    alloc_t = -1;
    for (int i = MAXT - 1; i >= 0; i--) if (!t_used[i]) alloc_t = i;
  endfunction

  function automatic logic poison_hit(input int off, input int nbytes);
    poison_hit = tb_poison_en && (off < int'(tb_poison_hi)) && (int'(tb_poison_lo) < off + nbytes);
  endfunction

  task automatic disrupt();
    for (int i = 0; i < MEM_BYTES; i++) ref_known[i] = 1'b0;
    for (int t = 0; t < MAXT; t++) begin
      if (t_used[t]) begin
        if (t_werr[t] == 0) t_werr[t] = 2;
        for (int b = 0; b < MB; b++) if (t_berr[t*MB+b] == 2'd0) t_berr[t*MB+b] = 2'd2;
      end
    end
  endtask

  task automatic clear_records();
    for (int t = 0; t < MAXT; t++) t_used[t] = 1'b0;
    gq_hd = 0; gq_n = 0; n_live = 0; stream_t = -1;
    for (int i = 0; i < NID; i++) begin iq_hd[i] = 0; iq_n[i] = 0; end
  endtask

  task automatic clear_counts();
    n_rd_acc = 0; n_wr_acc = 0; n_rd_done = 0; n_wr_done = 0; n_err_txn = 0; n_rd_beats_ok = 0;
    n_wr_beats_up = 0;
  endtask

  // ------------------------------------------------------------ prediction at acceptance
  task automatic predict_read(input int t, input logic unav);
    int code, off;
    code = static_err(1'b0, t_addr[t], t_len[t]);
    t_code[t]   = code;
    t_allerr[t] = 1'b0;
    // link not READY at acceptance -> the bridge must answer UNAVAIL (deterministic, policy 0)
    if (code != `XM_ERR_NONE || (unav && UNAVAIL_POLICY == 0)) begin
      t_allerr[t] = 1'b1;
      tot_must_err = tot_must_err + 1;
    end
    for (int b = 0; b < MB; b++) begin
      t_berr[t*MB+b]   = 2'd0;
      t_bknown[t*MB+b] = '0;
      t_bdata[t*MB+b]  = '0;
      if (b <= t_len[t] && !t_allerr[t]) begin
        off = int'(t_addr[t] - BASE) + b * SB;
        if (win_may || unav)                 t_berr[t*MB+b] = 2'd2;
        else if (poison_hit(off, SB))        t_berr[t*MB+b] = 2'd1;
        else if (tb_rderr_p16 != 0)          t_berr[t*MB+b] = 2'd2;
        for (int y = 0; y < SB; y++) begin
          t_bdata[t*MB+b][8*y +: 8] = ref_mem[off + y];
          t_bknown[t*MB+b][y]       = ref_known[off + y];
        end
      end
    end
  endtask

  task automatic apply_write(input int t, input logic unav, input logic proto);
    int code, off;
    code = static_err(1'b1, t_addr[t], t_len[t]);
    if (code == `XM_ERR_NONE && proto) code = `XM_ERR_PROTO;
    t_code[t] = code;
    if (code != `XM_ERR_NONE || (unav && UNAVAIL_POLICY == 0)) begin
      t_werr[t] = 1;                                   // never performed
      tot_must_err = tot_must_err + 1;
    end else if (win_may || unav) begin
      t_werr[t] = 2;                                   // may or may not be performed
      for (int b = 0; b <= t_len[t]; b++) begin
        off = int'(t_addr[t] - BASE) + b * SB;
        for (int y = 0; y < SB; y++) if (t_bknown[t*MB+b][y]) ref_known[off + y] = 1'b0;
      end
    end else if (poison_hit(int'(t_addr[t] - BASE), (t_len[t] + 1) * SB)) begin
      t_werr[t] = 1;                                   // controller error, not performed
      tot_must_err = tot_must_err + 1;
    end else begin
      t_werr[t] = 0;
      for (int b = 0; b <= t_len[t]; b++) begin
        off = int'(t_addr[t] - BASE) + b * SB;
        for (int y = 0; y < SB; y++) begin
          if (t_bknown[t*MB+b][y]) begin             // strobe
            ref_mem[off + y]   = t_bdata[t*MB+b][8*y +: 8];
            ref_known[off + y] = 1'b1;
          end
        end
      end
    end
  endtask

  // ------------------------------------------------------------ driver state
  logic        d_act, d_inb, d_wr;
  logic [31:0] d_addr;
  int          d_id, d_len, d_beat, d_nb, d_t, d_proto;
  logic        d_unav;

  task automatic gen_beat_payload(input int b);
    logic [DW-1:0] w;
    logic [SB-1:0] s;
    int unsigned   v;
    logic          r;
    for (int i = 0; i < DW / 32; i++) begin
      t_rnd(v);
      w[32*i +: 32] = v;
    end
    s = '1;
    if (strb_mode == 1) begin
      for (int i = 0; i < SB; i++) begin t_pct(50, r); s[i] = r; end
    end else if (strb_mode >= 2) begin
      t_pct(50, r);
      if (!r) for (int i = 0; i < SB; i++) begin t_pct(50, r); s[i] = r; end
    end
    up_req_wdata <= w;
    up_req_wstrb <= s;
    up_req_last  <= (d_proto == 2) ? 1'b0 : (b == d_nb - 1);
    if (b > 0) begin
      // header fields are don't-care after the first beat of a write burst: scramble them
      t_rnd(v);
      up_req_addr  <= v;
      up_req_id    <= IDW'(v >> 8);
      up_req_len   <= LW'(v >> 16);
      up_req_write <= v[31];
    end
  endtask

  // choose a new transaction: legal by default, illegal with err_pct
  task automatic gen_txn();
    int len, off, kind, lim, q;
    logic r_err, r_pro;
    t_pct(wr_pct, d_wr);
    t_rr(0, n_ids - 1, d_id);
    d_proto = 0;
    t_rr(min_len, max_len, len);
    case (addr_mode)
      1: begin                                         // sequential stream
        off = seq_ptr;
        if (off + (len + 1) * SB > rhi) off = rlo;
      end
      default: begin t_rr(rlo / SB, (rhi - SB) / SB, off); off = off * SB; end
    endcase
    // keep legal bursts inside the region and the 2^BOUND_LOG2 boundary
    lim = ((off >> BOUND_LOG2) + 1) << BOUND_LOG2;
    if (lim > rhi) lim = rhi;
    if (off + (len + 1) * SB > lim) len = (lim - off) / SB - 1;
    if (len < 0) len = 0;
    if (addr_mode == 1) seq_ptr = off + (len + 1) * SB;
    d_addr = BASE + 32'(off);
    // (random draws are made in plain statements, never inside && / ?: -- simulators differ in
    //  short-circuit evaluation of side-effecting calls, which would desynchronise the PRNG)
    t_pct(err_pct, r_err);
    if (err_pct > 0 && r_err) begin
      if (err_kind >= 0) kind = err_kind;
      else               t_rr(0, 9, kind);
      case (kind)
        0: begin t_rr(1, SB - 1, q); d_addr = d_addr + 32'(q); end                    // misaligned
        1: begin t_rr(0, 64, q); d_addr = BASE + 32'(MEM_BYTES) + 32'(q * SB); end     // past the end
        2: begin t_rr(0, 64, q); d_addr = BASE - 32'((q + 1) * SB); end                // below the base
        3: if (MB < MAXB) t_rr(MB, MAXB - 1, len);                                     // too long
        4: if (MB > 1) begin                                                            // boundary crossing
             t_rr(1, MEM_BYTES >> BOUND_LOG2, q);
             d_addr = BASE + 32'(((q - 1) << BOUND_LOG2) + (1 << BOUND_LOG2) - SB);
             t_rr(1, MB - 1, len);
             if (d_addr - BASE + 32'((len + 1) * SB) > 32'(MEM_BYTES)) d_addr = BASE + 32'(MEM_BYTES) - 32'(SB);
           end
        5: d_addr = 32'hFFFF_FFFF - 32'(SB - 1);                            // top of the address space
        6: begin d_addr = BASE + 32'(MEM_BYTES); len = 0; end              // first beat past the end
        7: begin d_addr = BASE + 32'(MEM_BYTES) - 32'(SB); len = (MB > 1) ? 1 : 0; end // overruns by one beat
        8: begin d_addr = BASE - 32'(SB); len = 0; end                      // last beat below the base
        default: begin d_addr = BASE + 32'(MEM_BYTES) - 32'(SB); len = 0; end // last legal beat
      endcase
    end
    if (SFB2_ONLY != 0) begin                       // SFB2 rev 2.0: single beat, ID 0
      len  = 0;
      d_id = 0;
    end
    d_len = len;
    d_nb  = d_wr ? len + 1 : 1;
    t_pct(proto_pct, r_pro);
    if (d_wr && len > 0 && proto_pct > 0 && r_pro) begin
      t_rr(1, 2, d_proto);
      if (d_proto == 1) t_rr(1, len, d_nb);             // early last after d_nb beats
    end
    d_beat = 0;
    d_act  = 1'b1;
    d_inb  = 1'b0;
    started = started + 1;
    up_req_valid <= 1'b1;
    up_req_write <= d_wr;
    up_req_addr  <= d_addr;
    up_req_id    <= IDW'(d_id);
    up_req_len   <= LW'(len);
    if (d_wr) gen_beat_payload(0);
    else begin
      up_req_wdata <= '0;
      up_req_wstrb <= '0;
      up_req_last  <= 1'b1;
    end
  endtask

  // ------------------------------------------------------------ request acceptance
  task automatic on_req_accept();
    int t;
    logic last_sent;
    if (!d_inb) begin
      t = alloc_t();
      if (t < 0) begin
        fail("TB record pool exhausted");
        t = 0;
      end
      t_used[t] = 1'b1; t_wr[t] = d_wr; t_id[t] = d_id; t_len[t] = d_len; t_addr[t] = d_addr;
      t_beat[t] = 0; t_werr[t] = 0; t_anyerr[t] = 1'b0; t_allerr[t] = 1'b0; t_code[t] = `XM_ERR_NONE;
      d_unav = !st_ready;
      if (UNAVAIL_POLICY != 0 && !st_ready) fail("first beat accepted while the link was not READY (stall policy)");
      if (UP_OOO != 0) begin
        iq[d_id*MAXT + (iq_hd[d_id] + iq_n[d_id]) % MAXT] = t;
        iq_n[d_id] = iq_n[d_id] + 1;
      end else begin
        gq[(gq_hd + gq_n) % MAXT] = t;
        gq_n = gq_n + 1;
      end
      n_live = n_live + 1;
      tot_txn = tot_txn + 1;
      d_t = t;
      if (d_wr) n_wr_acc = n_wr_acc + 1; else n_rd_acc = n_rd_acc + 1;
    end
    t = d_t;
    if (!d_wr) begin
      predict_read(t, d_unav);
      d_act = 1'b0;
    end else begin
      n_wr_beats_up = n_wr_beats_up + 1;
      if (d_beat < MB) begin
        t_bdata[t*MB + d_beat]  = up_req_wdata;
        t_bknown[t*MB + d_beat] = up_req_wstrb;
      end
      last_sent = (d_beat == d_nb - 1);
      if (last_sent) begin
        apply_write(t, d_unav, d_proto != 0);
        d_act = 1'b0;
        d_inb = 1'b0;
      end else begin
        d_inb  = 1'b1;
        d_beat = d_beat + 1;
      end
    end
  endtask

  // ------------------------------------------------------------ response check
  task automatic on_rsp();
    int t, b, e, off;
    logic exp_last, mism;
    t = -1;
    if (UP_OOO != 0) begin
      if (iq_n[up_rsp_id] == 0) fail("response for an ID with nothing outstanding (unsolicited / duplicate)");
      else t = iq[int'(up_rsp_id)*MAXT + iq_hd[up_rsp_id]];
    end else begin
      if (gq_n == 0) fail("response with nothing outstanding (unsolicited / duplicate)");
      else begin
        t = gq[gq_hd];
        if (int'(up_rsp_id) != t_id[t]) fail("response ID differs from the oldest transaction (order)");
      end
    end
    if (t >= 0) begin
    if (stream_t >= 0 && t != stream_t) fail("response beats of two transactions interleaved");
    if (up_rsp_write != t_wr[t]) fail("rsp_write does not match the transaction type");
    b = t_beat[t];
    exp_last = t_wr[t] ? 1'b1 : (b == t_len[t]);
    if (up_rsp_last != exp_last) fail("rsp_last framing wrong (lost / extra beats)");
    if (t_wr[t])          e = t_werr[t];
    else if (t_allerr[t]) e = 1;
    else if (b < MB)      e = int'(t_berr[t*MB+b]);
    else                  e = 2;
    if (e == 1 && !up_rsp_error) fail("expected an error response, got OK");
    if (e == 0 && up_rsp_error)  fail("unexpected error response");
    if ((up_rsp_error || up_rsp_write) && up_rsp_rdata != '0) fail("rdata not zero on error/write response");
    if (!t_wr[t] && !up_rsp_error && b < MB) begin
      mism = 1'b0;
      for (int y = 0; y < SB; y++) begin
        if (!mism && t_bknown[t*MB+b][y] && up_rsp_rdata[8*y +: 8] !== t_bdata[t*MB+b][8*y +: 8]) begin
          mism = 1'b1;
          fail("read data mismatch");
          $display("        addr=%h beat=%0d byte=%0d got=%h exp=%h", t_addr[t], b, y,
                   up_rsp_rdata[8*y +: 8], t_bdata[t*MB+b][8*y +: 8]);
        end
      end
    end
    if (up_rsp_error) begin
      t_anyerr[t] = 1'b1;
      tot_err_rsp = tot_err_rsp + 1;
    end else if (!t_wr[t]) begin
      n_rd_beats_ok = n_rd_beats_ok + 1;
    end
    t_beat[t] = b + 1;
    if (exp_last || up_rsp_last) begin
      stream_t = -1;
      if (UP_OOO != 0) begin
        iq_hd[t_id[t]] = (iq_hd[t_id[t]] + 1) % MAXT;
        iq_n[t_id[t]]  = iq_n[t_id[t]] - 1;
      end else begin
        gq_hd = (gq_hd + 1) % MAXT;
        gq_n  = gq_n - 1;
      end
      n_live = n_live - 1;
      if (t_anyerr[t]) n_err_txn = n_err_txn + 1;
      if (t_wr[t]) n_wr_done = n_wr_done + 1; else n_rd_done = n_rd_done + 1;
      t_used[t] = 1'b0;
    end else begin
      stream_t = t;
    end
    end
  endtask

  // ------------------------------------------------------------ error-capture sideband check
  // every err_evt must belong to a live transaction with the same address / ID / type, and a
  // locally detected code (RANGE, ALIGN, LEN, BOUNDARY, PROTO) must equal the TB's prediction
  int n_err_evt = 0;
  task automatic check_err_evt();
    logic found, ok, local_code;
    found = 1'b0; ok = 1'b0;
    local_code = (err_code == `XM_ERR_RANGE || err_code == `XM_ERR_ALIGN || err_code == `XM_ERR_LEN ||
                  err_code == `XM_ERR_BOUNDARY || err_code == `XM_ERR_PROTO);
    n_err_evt = n_err_evt + 1;
    for (int t = 0; t < MAXT; t++) begin
      if (t_used[t] && t_addr[t] == err_addr && t_wr[t] == err_write && t_id[t] == int'(err_id)) begin
        found = 1'b1;
        if (local_code ? (t_code[t] == int'(err_code)) : (t_code[t] == `XM_ERR_NONE)) ok = 1'b1;
      end
    end
    if (!found) fail("err_evt for no live transaction");
    else if (!ok) begin
      fail("error code differs from the predicted cause");
      $display("        err_code=%0d addr=%h write=%b", err_code, err_addr, err_write);
    end
  endtask

  // fault events (entries into FAULT), independent of the sticky status bit
  int n_fault_ev = 0;
  logic [2:0] st_prev = 3'd0;
  always @(posedge clk) begin
    if (st_state == `XM_ST_FAULT && st_prev != `XM_ST_FAULT) n_fault_ev = n_fault_ev + 1;
    st_prev = st_state;
  end

  // ------------------------------------------------------------ driver / monitor process
  logic r_bub, r_rdy;
  logic trace_on = 1'b0;
  initial if ($test$plusargs("TRACE")) trace_on = 1'b1;
  always @(posedge clk) begin
    if (rst_n !== 1'b1) begin
      up_req_valid <= 1'b0;
      up_rsp_ready <= 1'b0;
      d_act = 1'b0;
      d_inb = 1'b0;
    end else begin
      cyc = cyc + 1;
      if (trace_on) $display("T %0d rq=%b%b w=%b a=%h l=%0d rs=%b%b e=%b st=%0d mc=%b%b%b%b%b%b rs=%h",
                             cyc, up_req_valid, up_req_ready, up_req_write, up_req_addr, up_req_len,
                             up_rsp_valid, up_rsp_ready, up_rsp_error, st_state,
                             mc_cmd_valid, mc_cmd_ready, mc_wd_valid, mc_wd_ready, mc_rd_valid, mc_wr_valid, rs);
      if (err_evt) check_err_evt();
      if (up_rsp_valid && up_rsp_ready) on_rsp();
      if (up_req_valid && up_req_ready) on_req_accept();
      t_pct(bubble_pct, r_bub);
      t_pct(rsp_rdy_pct, r_rdy);
      if (!(up_req_valid && !up_req_ready)) begin
        if (d_act && d_inb) begin                        // next beat of the current write burst
          if (bubble_pct > 0 && r_bub) up_req_valid <= 1'b0;
          else begin
            up_req_valid <= 1'b1;
            gen_beat_payload(d_beat);
          end
        end else if (d_act && !d_inb && !(up_req_valid && up_req_ready)) begin
          up_req_valid <= 1'b1;                          // first beat after a bubble
        end else if (gen_on && started < target && n_live < max_out_tb &&
                     !(bubble_pct > 0 && r_bub)) begin
          gen_txn();
        end else begin
          up_req_valid <= 1'b0;
        end
      end
      up_rsp_ready <= r_rdy;
    end
  end

  // ------------------------------------------------------------ CSR access (program side)
  logic [31:0] csr_q;
  logic        csr_e;
  task automatic csr(input logic wr, input logic [31:0] a, input logic [31:0] d, input logic [3:0] s);
    @(negedge clk);
    csr_req_valid = 1'b1; csr_req_write = wr; csr_req_addr = a; csr_req_wdata = d; csr_req_wstrb = s;
    @(posedge clk);
    while (!csr_req_ready) @(posedge clk);
    @(negedge clk);
    csr_req_valid = 1'b0;
    while (!csr_rsp_valid) @(negedge clk);
    csr_q = csr_rsp_rdata;
    csr_e = csr_rsp_error;
  endtask

  // ------------------------------------------------------------ program helpers
  task automatic wait_cycles(input int n);
    repeat (n) @(negedge clk);
  endtask

  task automatic wait_ready(input int limit);
    int k;
    k = 0;
    while (!st_ready && k < limit) begin
      @(negedge clk);
      k++;
    end
    if (!st_ready) fail("bridge did not reach READY");
  endtask

  task automatic bridge_reset(input int n);
    @(negedge clk);
    rst_n = 1'b0;
    gen_on = 1'b0;
    disrupt();
    clear_records();
    clear_counts();
    tot_resets = tot_resets + 1;
    repeat (n) begin
      @(negedge clk);
      if (up_rsp_valid) fail("response while the bridge is in reset");
    end
    rst_n = 1'b1;
  endtask

  // run `n` transactions with the current knobs, then wait until all responses arrived
  task automatic traffic(input int n);
    @(negedge clk);
    target  = started + n;
    gen_on  = 1'b1;
    while (started < target) @(negedge clk);
    gen_on = 1'b0;
    drain(200000);
  endtask

  task automatic drain(input int limit);
    int k;
    k = 0;
    while ((n_live > 0 || d_act) && k < limit) begin
      @(negedge clk);
      k++;
    end
    if (n_live > 0) begin
      fail("responses lost: transactions still outstanding after drain");
      $display("        n_live=%0d state=%0d", n_live, st_state);
    end
  endtask

  task automatic knobs_default();
    wr_pct = 50; min_len = 0; max_len = MB - 1; addr_mode = 0; rlo = 0; rhi = MEM_BYTES; strb_mode = 2;
    rsp_rdy_pct = 90; bubble_pct = 5; err_pct = 0; proto_pct = 0; n_ids = (NID < 8) ? NID : 8;
    max_out_tb = 64;
    tb_lat_min = 2; tb_lat_max = 12; tb_cmd_rdy_pct = 90; tb_wd_rdy_pct = 90; tb_rsp_pct = 90;
    tb_rderr_p16 = 0; tb_poison_en = 1'b0;
  endtask

  function automatic logic [31:0] perf(input int i);
    perf = perf_cnt[i*32 +: 32];
  endfunction

  task automatic check_perf();
    if (perf(`XM_P_RD_REQ) != 32'(n_rd_acc)) fail("perf RD_REQ != scoreboard");
    if (perf(`XM_P_WR_REQ) != 32'(n_wr_acc)) fail("perf WR_REQ != scoreboard");
    if (perf(`XM_P_RD_DONE) != 32'(n_rd_done)) fail("perf RD_DONE != scoreboard");
    if (perf(`XM_P_WR_DONE) != 32'(n_wr_done)) fail("perf WR_DONE != scoreboard");
    if (perf(`XM_P_ERR_TXN) != 32'(n_err_txn)) fail("perf ERR_TXN != scoreboard");
    if (perf(`XM_P_RD_BEATS) != 32'(n_rd_beats_ok)) fail("perf RD_BEATS != scoreboard");
    if (perf(`XM_P_WR_BEATS) != 32'(n_wr_beats_up)) fail("perf WR_BEATS != scoreboard");
    if (perf(`XM_P_MC_PROTO) != 0) fail("bridge flagged controller protocol violations");
  endtask

  task automatic check_memory();
    int bad;
    bad = 0;
    for (int i = 0; i < MEM_BYTES; i++) begin
      if (ref_known[i] && u_mc.mem[i] !== ref_mem[i]) begin
        bad++;
        if (bad <= 4) $display("        mem[%0h] model=%h ref=%h", i, u_mc.mem[i], ref_mem[i]);
      end
    end
    if (bad != 0) fail("end-state memory differs from the reference model");
  endtask

  // ------------------------------------------------------------ test program
  reg [8*32-1:0] test;
  int seed, ntxn, known_cnt, pq;
  int b_rd, b_len, b_mode, b_lmin, b_lmax, b_rdy, b_lmx, b_crdy;

  initial begin
    #1 rst_n = 1'b0;
    if (!$value$plusargs("TEST=%s", test)) test = "smoke";
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    if (!$value$plusargs("NTXN=%d", ntxn)) ntxn = 2000;
    rs = 32'h1234_5677 ^ (32'(seed) * 32'h9E37_79B9);
    if (rs == 0) rs = 1;
    up_req_valid = 1'b0; up_req_write = 1'b0; up_req_addr = '0; up_req_wdata = '0; up_req_wstrb = '0;
    up_req_id = '0; up_req_len = '0; up_req_last = 1'b0; up_rsp_ready = 1'b0;
    csr_req_valid = 1'b0; csr_req_write = 1'b0; csr_req_addr = '0; csr_req_wdata = '0; csr_req_wstrb = '0;
    csr_rsp_ready = 1'b1; ctl_mc_reset_req = 1'b0;
    d_act = 1'b0; d_inb = 1'b0;
    for (int i = 0; i < MEM_BYTES; i++) begin
      ref_mem[i]   = 8'(i * 7 + 3);                       // the model's documented power-up pattern
      ref_known[i] = 1'b1;
    end
    clear_records();
    clear_counts();
    knobs_default();
    repeat (5) @(negedge clk);
    rst_n = 1'b1;

    // ---------------------------------------------------- "unavailable before calibration"
    if (test == "unavail") begin
      // traffic immediately after reset: everything before READY must fail UNAVAIL
      wr_pct = 50; max_len = MB - 1;
      if (UNAVAIL_POLICY == 0) traffic(50);
    end
    wait_ready(20000);

    case (test)
      "smoke": begin
        traffic(ntxn / 4);
      end
      "short_reads": begin
        wr_pct = 100; max_len = 0; strb_mode = 0; addr_mode = 1; traffic(ntxn / 4);
        wr_pct = 0;   max_len = 0; addr_mode = 0; traffic(ntxn);
      end
      "long_bursts": begin
        min_len = MB - 1; max_len = MB - 1; addr_mode = 1; strb_mode = 0;
        wr_pct = 100; traffic(ntxn / 8);
        wr_pct = 0;   traffic(ntxn / 8);
        wr_pct = 50;  addr_mode = 0; traffic(ntxn / 4);
      end
      "partial_writes": begin
        strb_mode = 1; rlo = 0; rhi = 4096; traffic(ntxn);
        strb_mode = 2; wr_pct = 0; traffic(ntxn / 4);
      end
      "concurrent_rw": begin
        rlo = 0; rhi = 512; n_ids = NID; traffic(ntxn);           // hot region: RAW/WAR/WAW hazards
        // command back-log: a slow controller keeps both queues full, so a younger command
        // could only be issued ahead of an older overlapping one if the scheduler were wrong
        rlo = 0; rhi = 128; tb_cmd_rdy_pct = 15; max_len = (MB > 4) ? 3 : MB - 1; traffic(ntxn);
        tb_cmd_rdy_pct = 90; max_len = MB - 1;
        rlo = 0; rhi = MEM_BYTES; traffic(ntxn);
      end
      "random_latency": begin
        tb_lat_min = 1; tb_lat_max = 200; tb_cmd_rdy_pct = 40; tb_wd_rdy_pct = 40; tb_rsp_pct = 40;
        rsp_rdy_pct = 50; bubble_pct = 20; traffic(ntxn / 2);
        tb_lat_min = 0; tb_lat_max = 0; tb_cmd_rdy_pct = 100; tb_wd_rdy_pct = 100; tb_rsp_pct = 100;
        rsp_rdy_pct = 100; bubble_pct = 0; traffic(ntxn / 2);
      end
      "backpressure": begin
        rsp_rdy_pct = 10; traffic(ntxn / 4);                      // upstream barely drains responses
        rsp_rdy_pct = 100; tb_cmd_rdy_pct = 5; tb_wd_rdy_pct = 5; traffic(ntxn / 4);
      end
      "ooo": begin
        n_ids = NID; tb_lat_min = 1; tb_lat_max = 80; rlo = 0; rhi = 2048; traffic(ntxn);
      end
      "addr_bounds": begin
        err_pct = 40; traffic(ntxn);
        // directed edge cases
        @(negedge clk);
        err_pct = 0; wr_pct = 50;
        rlo = MEM_BYTES - MB * SB; rhi = MEM_BYTES; traffic(64);  // last bursts of the window
        rlo = 0; rhi = MB * SB; traffic(64);                       // first bursts
        err_pct = 100;                                              // deterministic window edges
        for (int k = 6; k <= 9; k++) begin
          err_kind = k; traffic(8);
        end
        err_kind = -1; err_pct = 0;
      end
      "proto_err": begin
        wr_pct = 100; proto_pct = 50; rlo = 0; rhi = 8192; traffic(ntxn / 2);
        wr_pct = 0; proto_pct = 0; traffic(ntxn / 4);              // read back: no side effect
      end
      "mc_errors": begin
        tb_poison_en = 1'b1; tb_poison_lo = 32'(MEM_BYTES / 2); tb_poison_hi = 32'(MEM_BYTES / 2 + 1024);
        rlo = MEM_BYTES / 2 - 2048; rhi = MEM_BYTES / 2 + 2048; traffic(ntxn / 2);
        tb_poison_en = 1'b0; tb_rderr_p16 = 2000; rlo = 0; rhi = MEM_BYTES; traffic(ntxn / 2);
        tb_rderr_p16 = 0;
      end
      "reset_traffic": begin
        for (int k = 0; k < 4; k++) begin
          @(negedge clk);
          target = started + ntxn; gen_on = 1'b1;
          t_rr(50, 800, pq); wait_cycles(pq);
          t_rr(1, 20, pq); bridge_reset(pq);
          wait_ready(20000);
        end
        traffic(ntxn / 2);
      end
      "mc_unavailable": begin
        // (a) calibration lost mid-traffic -> flush, auto recovery
        for (int k = 0; k < 3; k++) begin
          @(negedge clk);
          target = started + ntxn; gen_on = 1'b1;
          t_rr(100, 600, pq); wait_cycles(pq);
          if (k == 1) begin                                   // fault while commands are stuck
            tb_cmd_rdy_pct = 0; tb_wd_rdy_pct = 0; wait_cycles(40);
          end
          win_may = 1'b1; disrupt(); tb_cal_drop = 1'b1; tot_faults++;
          t_rr(10, 300, pq); wait_cycles(pq);
          tb_cal_drop = 1'b0; tb_cmd_rdy_pct = 90; tb_wd_rdy_pct = 90;
          wait_cycles(RST_HOLD + 4);
          wait_ready(20000);
          gen_on = 1'b0; drain(200000);
          win_may = 1'b0;
        end
        // (b) controller hangs with init_done = 1 -> response watchdog
        if (RESP_TIMEOUT != 0) begin
          @(negedge clk);
          target = started + ntxn; gen_on = 1'b1;
          wait_cycles(200);
          pq = n_fault_ev;
          win_may = 1'b1; disrupt(); tb_hang = 1'b1; tot_faults++;
          while (n_fault_ev == pq) @(negedge clk);           // only the response watchdog can end this
          tb_hang = 1'b0;
          wait_cycles(RST_HOLD + 4);
          wait_ready(20000);
          gen_on = 1'b0; drain(200000);
          win_may = 1'b0;
        end
        // (c) fatal error flag
        @(negedge clk);
        target = started + ntxn; gen_on = 1'b1;
        wait_cycles(150);
        win_may = 1'b1; disrupt(); tb_fatal = 1'b1; tot_faults++;
        wait_cycles(3);
        tb_fatal = 1'b0;
        wait_cycles(RST_HOLD + 4);
        wait_ready(20000);
        gen_on = 1'b0; drain(200000);
        win_may = 1'b0;
        // (d) calibration never completes -> CALFAIL, recovered by a reset request
        if (CAL_TIMEOUT != 0) begin
          @(negedge clk);
          win_may = 1'b1; disrupt(); tb_cal_drop = 1'b1; tot_faults++;
          while (!st_cal_fail) @(negedge clk);
          target = started + 50; gen_on = 1'b1;              // requests while CALFAIL
          if (UNAVAIL_POLICY == 0) begin
            while (started < target) @(negedge clk);
            gen_on = 1'b0; drain(20000);
          end else begin
            wait_cycles(200);
            if (n_live != 0) fail("stall policy accepted requests while CALFAIL");
            gen_on = 1'b0;
          end
          tb_cal_drop = 1'b0;
          @(negedge clk); ctl_mc_reset_req = 1'b1; @(negedge clk); ctl_mc_reset_req = 1'b0;
          wait_ready(20000);
          if (UNAVAIL_POLICY != 0) drain(200000);
          win_may = 1'b0;
        end
        traffic(ntxn / 2);
      end
      "quiesce_reset": begin
        // controller reset requested while traffic runs: in-flight transactions complete normally
        for (int k = 0; k < 3; k++) begin
          @(negedge clk);
          target = started + ntxn; gen_on = 1'b1;
          t_rr(100, 500, pq); wait_cycles(pq);
          win_may = 1'b1;                     // new requests during QUIESCE/RESET/CAL may fail UNAVAIL
          ctl_mc_reset_req = 1'b1; @(negedge clk); ctl_mc_reset_req = 1'b0;
          while (st_ready) @(negedge clk);
          wait_ready(20000);
          @(negedge clk); win_may = 1'b0;
          wait_cycles(100);
          gen_on = 1'b0; drain(200000);
        end
        if (st_fault_seen) fail("quiesced reset must not be a fault");
        traffic(ntxn / 2);
      end
      "unavail": begin
        traffic(ntxn / 4);
      end
      "csr": begin
        csr(1'b0, 32'h0, 0, 4'hF);  if (csr_q != 32'h5346584D || csr_e) fail("CSR ID");
        csr(1'b0, 32'h4, 0, 4'hF);
        if (csr_q != {8'(MAX_WR_OUT), 8'(MAX_RD_OUT), 8'(MB - 1), 8'(SB)}) fail("CSR INFO0");
        csr(1'b0, 32'h18, 0, 4'hF); if (csr_q[3] != 1'b1 || csr_q[2:0] != `XM_ST_READY) fail("CSR STATUS ready");
        csr(1'b1, 32'h0, 32'h1, 4'hF); if (!csr_e) fail("CSR write to RO must fail");
        csr(1'b1, 32'h20, 32'h0, 4'h1); if (!csr_e) fail("CSR sub-word write must fail");
        csr(1'b0, 32'h100, 0, 4'hF); if (!csr_e) fail("CSR undefined offset must fail");
        // freeze / resume counters
        csr(1'b1, 32'h20, 32'h0, 4'hF);
        csr(1'b0, 32'h80, 0, 4'hF); known_cnt = int'(csr_q);
        wait_cycles(20);
        csr(1'b0, 32'h80, 0, 4'hF); if (int'(csr_q) != known_cnt) fail("PERF_ENABLE=0 must freeze counters");
        csr(1'b1, 32'h20, 32'h1, 4'hF);
        csr(1'b1, 32'h1C, 32'h4, 4'hF);                         // PERF_CLEAR
        csr(1'b0, 32'h80 + 4 * `XM_P_RD_REQ, 0, 4'hF); if (csr_q != 0) fail("PERF_CLEAR");
        clear_counts();
        // error capture: two failing requests
        err_pct = 100; err_kind = 1; wr_pct = 0; traffic(2); err_kind = -1;
        csr(1'b0, 32'h24, 0, 4'hF);
        if (!csr_q[0] || !csr_q[1]) fail("ERR_STATUS VALID/OVERFLOW after two errors");
        csr(1'b0, 32'h2C, 0, 4'hF); if (csr_q != 2) fail("ERR_COUNT");
        csr(1'b1, 32'h24, 32'h3, 4'hF);
        csr(1'b0, 32'h24, 0, 4'hF); if (csr_q[1:0] != 2'b00) fail("ERR_STATUS W1C");
        err_pct = 0; wr_pct = 50; traffic(ntxn / 4);
        csr(1'b0, 32'h80 + 4 * `XM_P_RD_REQ, 0, 4'hF);
        if (csr_q != 32'(n_rd_acc)) fail("CSR PERF RD_REQ != scoreboard");
        // controller reset through CONTROL.MC_RESET
        csr(1'b1, 32'h1C, 32'h1, 4'hF);
        wait_cycles(2);
        csr(1'b0, 32'h18, 0, 4'hF);
        if (csr_q[3]) fail("CONTROL.MC_RESET did not leave READY");
        wait_ready(20000);
        csr(1'b0, 32'h18, 0, 4'hF); if (csr_q[5]) fail("MC_RESET must not set FAULT_SEEN");
        traffic(ntxn / 4);
      end
      "soak": begin
        n_ids = NID; err_pct = 5; proto_pct = 5; tb_lat_min = 1; tb_lat_max = 60; rlo = 0; rhi = 8192;
        traffic(ntxn);
        rhi = MEM_BYTES; traffic(ntxn);
      end
      "bench": begin
        // throughput sweep point: +RDPCT +LMIN +LMAX +AMODE +LAT +RDY (no checks relaxed)
        if (!$value$plusargs("RDPCT=%d", b_rd))  b_rd = 100;
        if (!$value$plusargs("LMIN=%d", b_lmin)) b_lmin = MB - 1;
        if (!$value$plusargs("LMAX=%d", b_lmax)) b_lmax = MB - 1;
        if (!$value$plusargs("AMODE=%d", b_mode)) b_mode = 1;
        if (!$value$plusargs("LAT=%d", b_len))   b_len = 10;
        if (!$value$plusargs("RDY=%d", b_rdy))   b_rdy = 100;
        if (!$value$plusargs("LATMAX=%d", b_lmx)) b_lmx = b_len;
        if (!$value$plusargs("CMDRDY=%d", b_crdy)) b_crdy = b_rdy;
        wr_pct = 100 - b_rd; min_len = b_lmin; max_len = b_lmax; addr_mode = b_mode; strb_mode = 0;
        rsp_rdy_pct = 100; bubble_pct = 0; n_ids = NID; max_out_tb = 128;
        tb_lat_min = 32'(b_len); tb_lat_max = 32'(b_lmx); tb_cmd_rdy_pct = 32'(b_crdy);
        tb_wd_rdy_pct = 32'(b_rdy); tb_rsp_pct = 32'(b_rdy);
        @(negedge clk);
        csr(1'b1, 32'h1C, 32'h4, 4'hF);                          // PERF_CLEAR at the start of the window
        clear_counts();
        traffic(ntxn);
      end
      default: begin
        fail("unknown test");
      end
    endcase

    // ---------------------------------------------------- final checks
    gen_on = 1'b0;
    drain(200000);
    wait_cycles(20);
    if (!st_idle) fail("bridge not idle at the end");
    check_memory();
    check_perf();
    if (x_viol != 0)  fail("SFB2-X checker violations");
    if (c_viol != 0)  fail("MC-interface checker violations");
    if (m_viol != 0)  fail("controller-model contract violations");
    if (df_viol != 0) fail("DataFabric SFB2 checker violations");
    known_cnt = 0;
    for (int i = 0; i < MEM_BYTES; i++) if (ref_known[i]) known_cnt++;
    for (int i = 0; i < `XM_PERF_N; i++) $display("PERF %0d %0d", i, perf(i));
    $display("STAT err_evts=%0d fault_evts=%0d txns=%0d err_rsp_beats=%0d must_err=%0d resets=%0d faults=%0d mc_rd_cmds=%0d mc_wr_cmds=%0d rderr_inj=%0d wr_poisoned=%0d row_hits=%0d row_miss=%0d known_bytes=%0d cycles=%0d",
             n_err_evt, n_fault_ev, tot_txn, tot_err_rsp, tot_must_err, tot_resets, tot_faults, c_rd_cmd, c_wr_cmd, m_rderr, m_wpois,
             m_hits, m_miss, known_cnt, cyc);
    $display("RESULT %s test=%0s seed=%0d errors=%0d txns=%0d cycles=%0d",
             (errors == 0) ? "PASS" : "FAIL", test, seed, errors, tot_txn, cyc);
    $finish;
  end

  // global watchdog
  initial begin
    #(64'd2_000_000_000 * 64'(CLK_PS) / 64'd1000);
    $display("RESULT FAIL test=%0s seed=%0d errors=timeout", test, seed);
    $finish;
  end
endmodule

`default_nettype wire
