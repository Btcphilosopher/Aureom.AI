// =============================================================================
// SilicaFlux MemoryBridge :: extmem_sim_mc -- SIMULATION-ONLY memory controller
//                                             + DRAM storage model
//
//  ***  THIS IS NOT A DRAM CONTROLLER, NOT A PHY AND NOT SYNTHESIZABLE.  ***
//  It is a behavioural stand-in for "vendor controller + PHY + DRAM" behind
//  the generic memory-controller interface (docs/MC_INTERFACE.md), used to
//  verify the bridge.  No JEDEC timing is modelled; every latency parameter
//  is a HYPOTHETICAL cycle count chosen to stress the bridge, not a device
//  value.  Nothing measured with it is a DRAM performance result.
//
// What it does model (to exercise the bridge):
//   * calibration: mc_init_done rises CAL_CYCLES after reset release;
//   * a command queue with random back-pressure; write data FIFO with random
//     back-pressure;
//   * in-order execution in command-acceptance order (the MC-interface
//     ordering contract): a read executes after every earlier write has
//     received all its data, so overlapping accesses behave in order;
//   * completion latency = random [lat_min, lat_max] + a toy open-row model
//     (row hit / miss extra cycles per bank), per-bank timelines and a shared
//     data bus (one beat per cycle, slot reservations, read/write turnaround
//     gap) -- requests to different banks genuinely complete out of order;
//   * in-order (OOO = 0) or out-of-order (OOO = 1) completion by tag,
//     optionally with read beats of different tags interleaved (INTERLEAVE);
//   * error injection: a poisoned byte range (reads -> error beats, writes ->
//     error response and NOT performed) and random per-beat read errors
//     (memory unaffected);
//   * failure injection: tb_cal_drop (init_done falls, controller freezes),
//     tb_hang (freezes with init_done = 1), tb_fatal (fatal flag);
//   * storage (`mem`, byte array) survives reset, like DRAM contents survive
//     a controller reset in this model -- real controllers may overwrite
//     memory during recalibration.
// Contract checks performed here (violations counter): tag reuse while live,
// command/data payload change under back-pressure, write data without a
// command (STRICT_WD), wrong wd_last framing, address out of the model.
// =============================================================================
`default_nettype none

module extmem_sim_mc #(
  parameter int DW          = 64,
  parameter int MC_AW       = 28,
  parameter int LW          = 8,
  parameter int TW          = 3,
  parameter int MB          = 16,
  parameter int MEM_BYTES   = 65536,
  parameter int CMDQ        = 16,
  parameter int POOL        = 32,
  parameter int OOO         = 0,
  parameter int INTERLEAVE  = 0,
  parameter int ROW_BYTES   = 1024,
  parameter int BANKS       = 8,
  parameter int T_ROW_HIT   = 0,
  parameter int T_ROW_MISS  = 6,
  parameter int T_TURN      = 2,
  parameter int CAL_CYCLES  = 40,
  parameter int STRICT_WD   = 1,
  parameter int SEED        = 1,
  localparam int SB         = DW / 8,
  localparam int WDQ        = CMDQ * MB + 4,   // holds the data of a full command queue
  localparam int NTAG       = 1 << TW
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  output logic                  init_done,
  output logic                  fatal,
  input  wire logic             cmd_valid,
  output logic                  cmd_ready,
  input  wire logic             cmd_write,
  input  wire logic [MC_AW-1:0] cmd_addr,
  input  wire logic [LW-1:0]    cmd_len,
  input  wire logic [TW-1:0]    cmd_tag,
  input  wire logic             wd_valid,
  output logic                  wd_ready,
  input  wire logic [DW-1:0]    wd_data,
  input  wire logic [SB-1:0]    wd_strb,
  input  wire logic             wd_last,
  output logic                  rd_valid,
  input  wire logic             rd_ready,
  output logic [DW-1:0]         rd_data,
  output logic [TW-1:0]         rd_tag,
  output logic                  rd_last,
  output logic                  rd_error,
  output logic                  wr_valid,
  input  wire logic             wr_ready,
  output logic [TW-1:0]         wr_tag,
  output logic                  wr_error,
  // ---------------------------------------------------------------- testbench knobs
  input  wire logic             tb_cal_drop,
  input  wire logic             tb_hang,
  input  wire logic             tb_fatal,
  input  wire logic             tb_poison_en,
  input  wire logic [31:0]      tb_poison_lo,
  input  wire logic [31:0]      tb_poison_hi,
  input  wire logic [31:0]      tb_rderr_p16,      // per-beat read error probability / 65536
  input  wire logic [31:0]      tb_lat_min,
  input  wire logic [31:0]      tb_lat_max,
  input  wire logic [31:0]      tb_cmd_rdy_pct,
  input  wire logic [31:0]      tb_wd_rdy_pct,
  input  wire logic [31:0]      tb_rsp_pct,
  // ---------------------------------------------------------------- statistics
  output int                    st_violations,
  output int                    st_rd_cmds,
  output int                    st_wr_cmds,
  output int                    st_rd_beats,
  output int                    st_wr_beats,
  output int                    st_rderr_inj,
  output int                    st_wr_poisoned,
  output int                    st_row_hits,
  output int                    st_row_miss
);
  // ------------------------------------------------------------ storage
  logic [7:0] mem [MEM_BYTES];

  // ------------------------------------------------------------ PRNG (xorshift32, simulator independent)
  // Draws are statements (tasks), never side effects inside expressions.
  int unsigned rs;
  function automatic int unsigned xs32(input int unsigned x);
    int unsigned y;
    y = x ^ (x << 13);
    y = y ^ (y >> 17);
    y = y ^ (y << 5);
    xs32 = y;
  endfunction
  task automatic t_rnd(output int unsigned v);
    rs = xs32(rs);
    v  = rs;
  endtask
  task automatic t_pct(input int p, output logic r);
    int unsigned v;
    t_rnd(v);
    r = (int'(v % 100) < p);
  endtask

  // ------------------------------------------------------------ state
  int          now;
  int          cal_cnt;
  // execution queue
  logic        cq_w    [CMDQ];
  int          cq_addr [CMDQ];
  int          cq_len  [CMDQ];
  int          cq_tag  [CMDQ];
  int          cq_hd, cq_n;
  // write data FIFO
  logic [DW-1:0] wf_data [WDQ];
  logic [SB-1:0] wf_strb [WDQ];
  logic          wf_last [WDQ];
  int            wf_hd, wf_n;
  int            wd_expect;           // data beats owed by accepted write commands
  // completion pool
  logic          pl_v    [POOL];
  logic          pl_w    [POOL];
  int            pl_tag  [POOL];
  int            pl_len  [POOL];
  int            pl_t    [POOL];
  int            pl_seq  [POOL];
  int            pl_beat [POOL];
  logic          pl_werr [POOL];
  logic [DW-1:0] pl_data [POOL*MB];
  logic          pl_err  [POOL*MB];
  int            seq_ctr;
  // timing model
  localparam int RING = 8192;
  logic [1:0]    bus_rsv  [RING];      // 0 free, 1 read, 2 write (data-bus slot reservations)
  int            bank_free[BANKS];
  int            open_row [BANKS];
  // live tags
  logic          rlive [NTAG];
  logic          wlive [NTAG];
  // response channel registers
  int            rd_cur, wr_cur;
  logic          rd_v_q, wr_v_q, cmd_rdy_q, wd_rdy_q;
  // previous-cycle values for stability checks
  logic          p_cmd_hold, p_wd_hold;
  logic          p_cmd_w;
  logic [MC_AW-1:0] p_cmd_a;
  logic [LW-1:0] p_cmd_l;
  logic [TW-1:0] p_cmd_t;
  logic [DW-1:0] p_wd_d;
  logic [SB-1:0] p_wd_s;
  logic          p_wd_l;

  assign cmd_ready = cmd_rdy_q;
  assign wd_ready  = wd_rdy_q;
  assign rd_valid  = rd_v_q;
  assign wr_valid  = wr_v_q;

  initial begin
    rs = 32'h9E37_79B9 ^ SEED;
    if (rs == 0) rs = 1;
    for (int i = 0; i < MEM_BYTES; i++) mem[i] = 8'(i * 7 + 3);
    st_violations = 0; st_rd_cmds = 0; st_wr_cmds = 0; st_rd_beats = 0; st_wr_beats = 0;
    st_rderr_inj = 0; st_wr_poisoned = 0; st_row_hits = 0; st_row_miss = 0;
  end

  task automatic viol(input [8*64-1:0] msg);
    st_violations = st_violations + 1;
    $display("[%0t] SIM_MC VIOLATION: %0s", $time, msg);
  endtask

  function automatic logic poisoned(input int a, input int nbytes);
    poisoned = tb_poison_en && (a < int'(tb_poison_hi)) && (int'(tb_poison_lo) < a + nbytes);
  endfunction

  // completion time from the toy timing model (HYPOTHETICAL cycle counts); a task because it
  // updates the bank / bus state.
  //  * each bank has its own timeline (bank_free) and open row: requests to different banks
  //    with different random latencies complete out of order, as in a real controller;
  //  * the shared data bus is a reservation ring: a burst occupies len+1 consecutive free
  //    slots, with T_TURN idle slots required next to a slot of the opposite direction
  //    (read/write turnaround).  The earliest legal window at or after the bank's ready time
  //    is taken, so a later short request may fill a gap before an earlier long one.
  task automatic timing(input int a, input int len, input logic is_w, output int t_done);
    int lat, bank, row, t, guard;
    int unsigned v;
    logic ok;
    lat  = int'(tb_lat_min);
    if (tb_lat_max > tb_lat_min) begin
      t_rnd(v);
      lat = lat + int'(v % (tb_lat_max - tb_lat_min + 1));
    end
    bank = (a / ROW_BYTES) % BANKS;
    row  = a / (ROW_BYTES * BANKS);
    if (open_row[bank] == row) begin
      lat = lat + T_ROW_HIT;
      st_row_hits = st_row_hits + 1;
    end else begin
      lat = lat + T_ROW_MISS;
      open_row[bank] = row;
      st_row_miss = st_row_miss + 1;
    end
    t = now + lat;
    if (t < bank_free[bank]) t = bank_free[bank];
    guard = 0;
    ok = 1'b0;
    while (!ok && guard < RING - 2 * MB - 4 * T_TURN - 8) begin
      ok = 1'b1;
      for (int k = 0; k <= len; k++) if (bus_rsv[(t + k) % RING] != 2'd0) ok = 1'b0;
      for (int k = 1; k <= T_TURN; k++) begin
        if (bus_rsv[(t - k + RING) % RING] == (is_w ? 2'd1 : 2'd2)) ok = 1'b0;
        if (bus_rsv[(t + len + k) % RING] == (is_w ? 2'd1 : 2'd2)) ok = 1'b0;
      end
      if (!ok) begin
        t++;
        guard++;
      end
    end
    for (int k = 0; k <= len; k++) bus_rsv[(t + k) % RING] = is_w ? 2'd2 : 2'd1;
    bank_free[bank] = t + len + 1;
    t_done = is_w ? (t + len + 1) : (t + 1);
  endtask

  function automatic int free_pool();
    free_pool = -1;
    for (int i = POOL - 1; i >= 0; i--) if (!pl_v[i]) free_pool = i;
  endfunction

  // pick a pool entry to answer: in order = oldest of that kind (must be ready);
  // out of order = a random ready one
  task automatic pick(input logic want_w, output int best);
    int nready, k, cnt;
    int unsigned v;
    best = -1;
    if (OOO == 0) begin
      for (int i = 0; i < POOL; i++)
        if (pl_v[i] && pl_w[i] == want_w && (best < 0 || pl_seq[i] < pl_seq[best])) best = i;
      if (best >= 0 && pl_t[best] > now) best = -1;
    end else begin
      nready = 0;
      for (int i = 0; i < POOL; i++) if (pl_v[i] && pl_w[i] == want_w && pl_t[i] <= now) nready++;
      if (nready > 0) begin
        t_rnd(v);
        k = int'(v % nready);
        cnt = 0;
        for (int i = 0; i < POOL; i++) begin
          if (pl_v[i] && pl_w[i] == want_w && pl_t[i] <= now) begin
            if (cnt == k) best = i;
            cnt++;
          end
        end
      end
    end
  endtask

  // ------------------------------------------------------------ main process
  always @(posedge clk or negedge rst_n) begin
    if (rst_n !== 1'b1) begin      // X during 4-state power-up counts as reset
      now = 0; cal_cnt = 0; cq_hd = 0; cq_n = 0; wf_hd = 0; wf_n = 0; wd_expect = 0;
      seq_ctr = 0; rd_cur = -1; wr_cur = -1;
      for (int i = 0; i < RING; i++) bus_rsv[i] = 2'd0;
      for (int i = 0; i < POOL; i++) pl_v[i] = 1'b0;
      for (int i = 0; i < NTAG; i++) begin rlive[i] = 1'b0; wlive[i] = 1'b0; end
      for (int i = 0; i < BANKS; i++) begin open_row[i] = -1; bank_free[i] = 0; end
      p_cmd_hold = 1'b0; p_wd_hold = 1'b0;
      rd_v_q    <= 1'b0; wr_v_q <= 1'b0; cmd_rdy_q <= 1'b0; wd_rdy_q <= 1'b0;
      rd_data   <= '0; rd_tag <= '0; rd_last <= 1'b0; rd_error <= 1'b0;
      wr_tag    <= '0; wr_error <= 1'b0;
      init_done <= 1'b0; fatal <= 1'b0;
    end else begin : step
      logic frozen, rd_v_n, wr_v_n, r_rd, r_wr, r_cmd, r_wd;
      int   e, b, a, slot, sel;
      int unsigned r_err;
      logic ok, perr;
      // all per-cycle random draws first, in a fixed order (simulator-independent stream)
      t_pct(int'(tb_rsp_pct), r_rd);
      t_pct(int'(tb_rsp_pct), r_wr);
      t_pct(int'(tb_cmd_rdy_pct), r_cmd);
      t_pct(int'(tb_wd_rdy_pct), r_wd);
      bus_rsv[(now + RING - T_TURN - 1) % RING] = 2'd0;   // forget slots behind the turnaround window
      now    = now + 1;
      frozen = tb_cal_drop || tb_hang;
      rd_v_n = rd_v_q;
      wr_v_n = wr_v_q;

      // -------------------------------------------------- stability checks (bridge side)
      if (p_cmd_hold && (!cmd_valid || cmd_write !== p_cmd_w || cmd_addr !== p_cmd_a ||
                         cmd_len !== p_cmd_l || cmd_tag !== p_cmd_t))
        viol("command changed/withdrawn under back-pressure");
      if (p_wd_hold && (!wd_valid || wd_data !== p_wd_d || wd_strb !== p_wd_s || wd_last !== p_wd_l))
        viol("write data changed/withdrawn under back-pressure");

      // -------------------------------------------------- response handshakes
      if (rd_v_q && rd_ready) begin
        rd_v_n = 1'b0;
        pl_beat[rd_cur] = pl_beat[rd_cur] + 1;
        st_rd_beats = st_rd_beats + 1;
        if (pl_beat[rd_cur] > pl_len[rd_cur]) begin
          rlive[pl_tag[rd_cur]] = 1'b0;
          pl_v[rd_cur] = 1'b0;
          rd_cur = -1;
        end else if (INTERLEAVE != 0) begin
          rd_cur = -1;            // may switch to another tag for the next beat
        end
      end
      if (wr_v_q && wr_ready) begin
        wr_v_n = 1'b0;
        wlive[pl_tag[wr_cur]] = 1'b0;
        pl_v[wr_cur] = 1'b0;
        wr_cur = -1;
      end

      // -------------------------------------------------- request handshakes
      if (cmd_valid && cmd_rdy_q) begin
        a = int'(cmd_addr);
        if (cmd_write ? wlive[cmd_tag] : rlive[cmd_tag]) viol("tag reused while live");
        if (int'(cmd_len) >= MB) viol("command length > MB");
        if (a % SB != 0 || a + (int'(cmd_len) + 1) * SB > MEM_BYTES) viol("command address outside model");
        if (cmd_write) begin
          wlive[cmd_tag] = 1'b1;
          wd_expect = wd_expect + int'(cmd_len) + 1;
          st_wr_cmds = st_wr_cmds + 1;
        end else begin
          rlive[cmd_tag] = 1'b1;
          st_rd_cmds = st_rd_cmds + 1;
        end
        slot = (cq_hd + cq_n) % CMDQ;
        cq_w[slot] = cmd_write; cq_addr[slot] = a; cq_len[slot] = int'(cmd_len); cq_tag[slot] = int'(cmd_tag);
        cq_n = cq_n + 1;
      end
      if (wd_valid && wd_rdy_q) begin
        if (STRICT_WD != 0 && wd_expect <= 0) viol("write data beat without an accepted command");
        wd_expect = wd_expect - 1;
        slot = (wf_hd + wf_n) % WDQ;
        wf_data[slot] = wd_data; wf_strb[slot] = wd_strb; wf_last[slot] = wd_last;
        wf_n = wf_n + 1;
        st_wr_beats = st_wr_beats + 1;
      end

      // -------------------------------------------------- execute one command (in order)
      if (!frozen && cq_n > 0) begin
        e = free_pool();
        a = cq_addr[cq_hd];
        if (e >= 0 && (!cq_w[cq_hd] || wf_n >= cq_len[cq_hd] + 1)) begin
          pl_v[e] = 1'b1; pl_w[e] = cq_w[cq_hd]; pl_tag[e] = cq_tag[cq_hd]; pl_len[e] = cq_len[cq_hd];
          pl_seq[e] = seq_ctr; pl_beat[e] = 0; pl_werr[e] = 1'b0;
          seq_ctr = seq_ctr + 1;
          if (cq_w[cq_hd]) begin
            perr = poisoned(a, (cq_len[cq_hd] + 1) * SB);
            for (int k = 0; k <= cq_len[cq_hd]; k++) begin
              b = (wf_hd + k) % WDQ;
              if (wf_last[b] !== (k == cq_len[cq_hd])) viol("wd_last framing mismatch");
              if (!perr) begin
                for (int y = 0; y < SB; y++) begin
                  if (wf_strb[b][y] && a + k * SB + y < MEM_BYTES) mem[a + k * SB + y] = wf_data[b][8*y +: 8];
                end
              end
            end
            wf_hd = (wf_hd + cq_len[cq_hd] + 1) % WDQ;
            wf_n  = wf_n - (cq_len[cq_hd] + 1);
            pl_werr[e] = perr;
            if (perr) st_wr_poisoned = st_wr_poisoned + 1;
          end else begin
            for (int k = 0; k <= cq_len[cq_hd]; k++) begin
              ok = !poisoned(a + k * SB, SB);
              t_rnd(r_err);
              r_err = r_err % 65536;
              if (ok && tb_rderr_p16 != 0 && r_err < tb_rderr_p16) begin
                ok = 1'b0;
                st_rderr_inj = st_rderr_inj + 1;
              end
              pl_err[e*MB + k] = !ok;
              for (int y = 0; y < SB; y++) begin
                // an error beat carries garbage (as real hardware may): the bridge must zero it
                pl_data[e*MB + k][8*y +: 8] = (ok && a + k * SB + y < MEM_BYTES) ? mem[a + k * SB + y] : 8'(8'hE5 + y);
              end
            end
          end
          timing(a, cq_len[cq_hd], cq_w[cq_hd], pl_t[e]);
          cq_hd = (cq_hd + 1) % CMDQ;
          cq_n  = cq_n - 1;
        end
      end

      // -------------------------------------------------- present responses
      if (!frozen && !rd_v_n && r_rd) begin
        sel = rd_cur;
        if (sel < 0) pick(1'b0, sel);     // INTERLEAVE: rd_cur is cleared after every beat
        if (sel >= 0 && pl_t[sel] <= now) begin
          rd_cur = sel;
          rd_v_n = 1'b1;
          rd_data  <= pl_data[sel*MB + pl_beat[sel]];
          rd_error <= pl_err[sel*MB + pl_beat[sel]];
          rd_last  <= (pl_beat[sel] == pl_len[sel]);
          rd_tag   <= TW'(pl_tag[sel]);
        end
      end
      if (!frozen && !wr_v_n && r_wr) begin
        pick(1'b1, sel);
        if (sel >= 0) begin
          wr_cur = sel;
          wr_v_n = 1'b1;
          wr_tag   <= TW'(pl_tag[sel]);
          wr_error <= pl_werr[sel];
        end
      end
      rd_v_q <= rd_v_n;
      wr_v_q <= wr_v_n;

      // -------------------------------------------------- calibration / ready
      if (cal_cnt < CAL_CYCLES) cal_cnt = cal_cnt + 1;
      init_done <= (cal_cnt >= CAL_CYCLES) && !tb_cal_drop;
      fatal     <= tb_fatal;
      cmd_rdy_q <= !frozen && (cal_cnt >= CAL_CYCLES) && (cq_n < CMDQ - 1) && r_cmd;
      wd_rdy_q  <= !frozen && (wf_n < WDQ - 1) && r_wd;

      // -------------------------------------------------- remember payloads for the stability check
      p_cmd_hold = cmd_valid && !cmd_rdy_q;
      p_wd_hold  = wd_valid && !wd_rdy_q;
      p_cmd_w = cmd_write; p_cmd_a = cmd_addr; p_cmd_l = cmd_len; p_cmd_t = cmd_tag;
      p_wd_d  = wd_data;   p_wd_s  = wd_strb;  p_wd_l  = wd_last;
    end
  end
endmodule

`default_nettype wire
