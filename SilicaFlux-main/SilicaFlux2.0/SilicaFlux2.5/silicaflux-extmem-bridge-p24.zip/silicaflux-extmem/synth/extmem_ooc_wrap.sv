// =============================================================================
// SilicaFlux MemoryBridge :: extmem_ooc_wrap -- out-of-context synthesis harness
//
// FPGA place-and-route needs the design to fit the package pins; the bridge
// alone has ~2 000 port bits.  This harness (synthesis/P&R only, never used in
// a product) drives every bridge input from a serial shift chain and folds
// every bridge output into a registered XOR tree, so all bridge logic stays
// observable and every bridge port is registered on both sides: the reported
// Fmax is the bridge's internal register-to-register timing plus one level of
// harness logic.  It says nothing about a real board's I/O timing.
// =============================================================================
`include "extmem_defs.svh"
`default_nettype none

module extmem_ooc_wrap #(
  parameter int DW         = 64,
  parameter int IDW        = 4,
  parameter int MAX_BURST  = 16,
  parameter int MAX_RD_OUT = 8,
  parameter int MAX_WR_OUT = 8,
  parameter int UP_OOO     = 0,
  parameter int SCHED_MODE = 0,
  parameter int PERF       = 1,
  parameter int ASYNC      = 0,
  localparam int LW        = 8,
  localparam int MC_AW     = 28,
  localparam int SB        = DW / 8,
  localparam int RTW       = (MAX_RD_OUT > 1) ? $clog2(MAX_RD_OUT) : 1,
  localparam int WTW       = (MAX_WR_OUT > 1) ? $clog2(MAX_WR_OUT) : 1,
  localparam int TW        = (RTW > WTW) ? RTW : WTW,
  // input bits: up req (2+32+DW+SB+IDW+LW+1) + up rsp_ready + csr (1+1+32+32+4+1)
  //             + mc (2 status + cmd_ready + wd_ready + rd (1+DW+TW+2) + wr (1+TW+1)) + ctl
  localparam int NIN       = (2 + 32 + DW + SB + IDW + LW + 1) + 1 + 71 + (4 + 1 + DW + TW + 2 + 1 + TW + 1) + 1,
  // output bits
  localparam int NOUT      = 1 + (1 + DW + 1 + IDW + 2) + (1 + 1 + 32 + 1) + 1 + (1 + 1 + MC_AW + LW + TW)
                             + (1 + DW + SB + 1) + 1 + 1 + (3 + 4 + 1 + 4 + 32 + IDW + 1) + `XM_PERF_N * 32
) (
  input  wire logic clk,
  input  wire logic mc_clk,
  input  wire logic rst_n,
  input  wire logic sin,
  output logic      sout
);
  logic [NIN-1:0] in_q;
  always_ff @(posedge clk) in_q <= {in_q[NIN-2:0], sin};

  logic [NOUT-1:0] o;
  logic [SB-1:0]   wstrb;
  logic [TW-1:0]   cmd_tag;
  logic [3:0]      err_code;
  logic [IDW-1:0]  err_id;
  logic [31:0]     err_addr;
  logic [2:0]      st_state;

  // slice the input vector (order is irrelevant for synthesis)
  localparam int P0 = 0;
  localparam int P1 = P0 + 2 + 32 + DW + SB + IDW + LW + 1;
  localparam int P2 = P1 + 1;
  localparam int P3 = P2 + 71;

  silicaflux_extmem_bridge #(
    .DW(DW), .IDW(IDW), .LW(LW), .MAX_BURST(MAX_BURST), .MAX_RD_OUT(MAX_RD_OUT), .MAX_WR_OUT(MAX_WR_OUT),
    .MC_AW(MC_AW), .EXT_BASE(32'h8000_0000), .EXT_SIZE(33'h0_1000_0000), .UP_OOO(UP_OOO), .SCHED_MODE(SCHED_MODE),
    .RESP_TIMEOUT(4096), .CAL_TIMEOUT(1 << 20), .PERF(PERF), .ASYNC(ASYNC)
  ) u_br (
    .clk, .rst_n, .mc_clk,
    .up_req_valid(in_q[P0]), .up_req_ready(o[0]), .up_req_write(in_q[P0+1]), .up_req_addr(in_q[P0+2 +: 32]),
    .up_req_wdata(in_q[P0+34 +: DW]), .up_req_wstrb(in_q[P0+34+DW +: SB]), .up_req_id(in_q[P0+34+DW+SB +: IDW]),
    .up_req_len(in_q[P0+34+DW+SB+IDW +: LW]), .up_req_last(in_q[P0+34+DW+SB+IDW+LW]),
    .up_rsp_valid(o[1]), .up_rsp_ready(in_q[P1]), .up_rsp_rdata(o[2 +: DW]), .up_rsp_error(o[2+DW]),
    .up_rsp_id(o[3+DW +: IDW]), .up_rsp_last(o[3+DW+IDW]), .up_rsp_write(o[4+DW+IDW]),
    .csr_req_valid(in_q[P2]), .csr_req_ready(o[5+DW+IDW]), .csr_req_write(in_q[P2+1]),
    .csr_req_addr(in_q[P2+2 +: 32]), .csr_req_wdata(in_q[P2+34 +: 32]), .csr_req_wstrb(in_q[P2+66 +: 4]),
    .csr_rsp_valid(o[6+DW+IDW]), .csr_rsp_ready(in_q[P2+70]), .csr_rsp_rdata(o[7+DW+IDW +: 32]),
    .csr_rsp_error(o[39+DW+IDW]),
    .mc_rst_n(o[40+DW+IDW]), .mc_init_done(in_q[P3]), .mc_fatal(in_q[P3+1]),
    .mc_cmd_valid(o[41+DW+IDW]), .mc_cmd_ready(in_q[P3+2]), .mc_cmd_write(o[42+DW+IDW]),
    .mc_cmd_addr(o[43+DW+IDW +: MC_AW]), .mc_cmd_len(o[43+DW+IDW+MC_AW +: LW]), .mc_cmd_tag(cmd_tag),
    .mc_wd_valid(o[43+DW+IDW+MC_AW+LW]), .mc_wd_ready(in_q[P3+3]), .mc_wd_data(o[44+DW+IDW+MC_AW+LW +: DW]),
    .mc_wd_strb(wstrb), .mc_wd_last(o[44+2*DW+IDW+MC_AW+LW]),
    .mc_rd_valid(in_q[P3+4]), .mc_rd_ready(o[45+2*DW+IDW+MC_AW+LW]), .mc_rd_data(in_q[P3+5 +: DW]),
    .mc_rd_tag(in_q[P3+5+DW +: TW]), .mc_rd_last(in_q[P3+5+DW+TW]), .mc_rd_error(in_q[P3+6+DW+TW]),
    .mc_wr_valid(in_q[P3+7+DW+TW]), .mc_wr_ready(o[46+2*DW+IDW+MC_AW+LW]), .mc_wr_tag(in_q[P3+8+DW+TW +: TW]),
    .mc_wr_error(in_q[P3+8+DW+2*TW]),
    .ctl_mc_reset_req(in_q[P3+9+DW+2*TW]),
    .st_state, .st_ready(o[47+2*DW+IDW+MC_AW+LW]), .st_cal_fail(o[48+2*DW+IDW+MC_AW+LW]),
    .st_fault_seen(o[49+2*DW+IDW+MC_AW+LW]), .st_idle(o[50+2*DW+IDW+MC_AW+LW]),
    .err_evt(o[51+2*DW+IDW+MC_AW+LW]), .err_code, .err_addr, .err_id, .err_write(o[52+2*DW+IDW+MC_AW+LW]),
    .perf_cnt(o[NOUT-`XM_PERF_N*32 +: `XM_PERF_N*32])
  );
  assign o[53+2*DW+IDW+MC_AW+LW +: TW+SB+3+4+32+IDW] = {cmd_tag, wstrb, st_state, err_code, err_addr, err_id};
  // any bits left between the explicit slices and the perf counters are tied low
  localparam int USED = 53 + 2*DW + IDW + MC_AW + LW + TW + SB + 3 + 4 + 32 + IDW;
  generate
    if (NOUT - `XM_PERF_N*32 > USED) begin : g_pad
      assign o[USED +: NOUT - `XM_PERF_N*32 - USED] = '0;
    end
  endgenerate

  // registered XOR fold of all outputs (keeps every output cone)
  logic [31:0] fold_q;
  logic [31:0] fold;
  always_comb begin
    fold = '0;
    for (int i = 0; i < NOUT; i++) fold[i % 32] = fold[i % 32] ^ o[i];
  end
  always_ff @(posedge clk) fold_q <= fold;
  assign sout = ^fold_q;
endmodule

`default_nettype wire
