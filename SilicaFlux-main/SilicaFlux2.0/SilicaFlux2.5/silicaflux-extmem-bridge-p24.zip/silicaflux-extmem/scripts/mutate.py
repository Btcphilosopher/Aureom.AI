#!/usr/bin/env python3
"""SilicaFlux MemoryBridge -- mutation testing of the verification environment.

Each mutant injects one realistic design bug into a copy of rtl/ (exact text
substitution, which must match exactly once), rebuilds tb_extmem for the
mutant's configuration and runs a short test list.  The mutant is KILLED when
at least one test fails.  A surviving mutant is either a hole in the
verification or an equivalent mutant; both are reported with a reason.
Writes reports/mutation.json / reports/mutation.md.
"""
from __future__ import annotations

import concurrent.futures as cf
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import extmem_cfg  # noqa: E402

TB = ["sim/models/extmem_sim_mc.sv", "tb/extmem_mc_checker.sv", "tb/extmem_sfbx_checker.sv",
      "third_party/silicaflux-datafabric/tb/common/sfb_protocol_checker.sv", "tb/tb_extmem.sv"]
DEF_TESTS = ["smoke", "concurrent_rw", "partial_writes", "long_bursts", "addr_bounds", "proto_err", "mc_errors",
             "reset_traffic", "mc_unavailable", "quiesce_reset", "unavail", "ooo", "backpressure", "random_latency"]

# (id, file, original, mutated, config, description)
M = [
 ("FE_RANGE_OBO", "extmem_frontend.sv", "(last_x <= LIM_X)", "(last_x <= LIM_X + {{AW{1'b0}}, 1'b1})", "base",
  "range check off by one BYTE at the window top -- EQUIVALENT: an aligned burst ends at SB-1 mod SB, never at LIM+1"),
 ("FE_RANGE_BEAT", "extmem_frontend.sv", "(last_x <= LIM_X)", "(last_x <= LIM_X + (AW+1)'(SB))", "base",
  "range check off by one BEAT at the top of the window"),
 ("FE_NO_ALIGN", "extmem_frontend.sv", "wire        aln_ok  = (up_req_addr[OFF-1:0] == '0);", "wire        aln_ok  = 1'b1;", "base",
  "misaligned addresses not rejected"),
 ("FE_NO_BOUND", "extmem_frontend.sv", "wire        bnd_ok  = ((a_x >> BOUND_LOG2) == (last_x >> BOUND_LOG2));",
  "wire        bnd_ok  = 1'b1;", "base", "boundary-crossing bursts not rejected"),
 ("FE_NO_PROTO", "extmem_frontend.sv", "wire           proto   = (up_req_last != by_len);", "wire           proto   = 1'b0;", "base",
  "write-burst framing errors not detected"),
 ("FE_MCADDR", "extmem_frontend.sv", "wire [MC_AW-1:0] dmca = off_a[MC_AW-1:0];",
  "wire [MC_AW-1:0] dmca = off_a[MC_AW-1:0] ^ MC_AW'(SB);", "base", "wrong controller address translation"),
 ("FE_WBUF_BEAT", "extmem_frontend.sv", "wbuf_waddr     = WBA'(w_slot) * WBA'(MB) + WBA'(w_beat);",
  "wbuf_waddr     = WBA'(w_slot) * WBA'(MB);", "base", "all write beats stored in the same buffer entry"),
 ("FE_NO_UNAVAIL", "extmem_frontend.sv", "    else if (!accept_ok) dcode = `XM_ERR_UNAVAIL;", "", "base",
  "requests not refused while the controller is unavailable"),
 ("FE_STRB", "extmem_frontend.sv", "wbuf_wdata     = {up_req_wstrb, up_req_wdata};", "wbuf_wdata     = {{SB{1'b1}}, up_req_wdata};", "base",
  "byte enables ignored"),
 ("FE_WID", "extmem_frontend.sv", "rob_id    = first ? up_req_id : cur_id_q;", "rob_id    = up_req_id;", "ooo_full",
  "write ID taken from the last beat instead of the first"),
 ("TR_NO_RD_FREE", "extmem_tracker.sv", "        rbusy[rd_retire_idx]  <= 1'b0;\n", "", "base",
  "read slot never released (resource leak)"),
 ("TR_FLUSH_RD", "extmem_tracker.sv", "          if (rbusy[r] && !rcomp[r]) rflush[r] <= 1'b1;", "          if (rbusy[r] && !rcomp[r]) rflush[r] <= 1'b0;", "base",
  "fault flush does not complete outstanding reads"),
 ("TR_WERR", "extmem_tracker.sv", "        werr[wt]  <= mc_wr_error;", "        werr[wt]  <= 1'b0;", "base",
  "controller write errors dropped"),
 ("TR_RBUF_BEAT", "extmem_tracker.sv", "RBA'(rt) * RBA'(MB) + RBA'(rcnt[rt][BW-1:0]);", "RBA'(rt) * RBA'(MB);", "base",
  "read beats written to the same buffer entry"),
 ("TR_RERR", "extmem_tracker.sv", "assign rbuf_werr  = mc_rd_error ||", "assign rbuf_werr  = 1'b0 ||", "base",
  "controller read errors dropped"),
 ("TR_EARLY_COMP", "extmem_tracker.sv", "(rcnt[r] == {1'b0, rlen[r]} + {{BW{1'b0}}, 1'b1})", "(rcnt[r] == {1'b0, rlen[r]})", "base",
  "read considered complete one beat early"),
 ("SC_FIFO_ORDER", "extmem_sched.sv", "      pick_r = r_older;\n      pick_w = !r_older && wh;", "      pick_r = rh;\n      pick_w = !rh && wh;", "base",
  "FIFO scheduler lets reads bypass older writes (RAW hazard)"),
 ("SC_NO_HAZARD", "extmem_sched.sv", "ovl(wq_addr[i], wq_len[i], rq_addr[rq_hd], rq_len[rq_hd])) haz_r = 1'b1;",
  "ovl(wq_addr[i], wq_len[i], rq_addr[rq_hd], rq_len[rq_hd])) haz_r = 1'b0;", "rprio_batch",
  "read-priority scheduler ignores read-after-write hazards"),
 ("SC_NO_WAR", "extmem_sched.sv", "ovl(rq_addr[i], rq_len[i], wq_addr[wq_hd], wq_len[wq_hd])) haz_w = 1'b1;",
  "ovl(rq_addr[i], rq_len[i], wq_addr[wq_hd], wq_len[wq_hd])) haz_w = 1'b0;", "rprio_batch",
  "write batching ignores write-after-read hazards"),
 ("SC_WD_BEAT", "extmem_sched.sv", "assign wbuf_raddr  = WBA'(ds_slot[ds_hd]) * WBA'(MB) + WBA'(ds_beat_q);",
  "assign wbuf_raddr  = WBA'(ds_slot[ds_hd]) * WBA'(MB);", "base", "write data beats sent from the wrong buffer entry"),
 ("SC_TAG", "extmem_sched.sv", "cmd_t_q <= pick_w ? TW'(wq_slot[wq_hd]) : TW'(rq_slot[rq_hd]);",
  "cmd_t_q <= pick_w ? TW'(wq_slot[wq_hd]) : TW'(rq_hd);", "mc_ooo_inorder_up", "read tag = queue index instead of slot (misassociation)"),
 ("SC_FLUSH_CMD", "extmem_sched.sv", "      ds_hd <= '0; ds_tl <= '0; ds_cnt <= '0; ds_beat_q <= '0;\n      cmd_v_q <= 1'b0;",
  "      ds_hd <= '0; ds_tl <= '0; ds_cnt <= '0; ds_beat_q <= '0;", "base", "stale command survives a controller fault"),
 ("RB_INORDER", "extmem_rob.sv", "        if (k != 0) cand[k] = 1'b0;\n", "", "mc_ooo_inorder_up",
  "in-order (SFB2 R5) upstream receives out-of-order responses"),
 ("RB_SAME_ID", "extmem_rob.sv", "          if (QW'(j) < cnt_q && e_id[j] == e_id[k]) cand[k] = 1'b0;\n", "", "ooo_full",
  "out-of-order mode breaks per-ID order"),
 ("RB_ZERO_ERR", "extmem_rob.sv", "        rd_q  <= (b_err || c_wr) ? '0 : b_data;", "        rd_q  <= c_wr ? '0 : b_data;", "base",
  "error beats carry controller garbage instead of 0 (SFB2 R8)"),
 ("RB_FLUSH_OK", "extmem_rob.sv", "      end else if (c_rfl) begin\n        avail  = 1'b1;\n        b_err  = 1'b1;",
  "      end else if (c_rfl) begin\n        avail  = 1'b1;\n        b_err  = 1'b0;", "base", "flushed read beats reported as OK"),
 ("RB_NO_WR_FREE", "extmem_rob.sv", "  assign wr_retire     = ret && !c_lerr && c_wr;", "  assign wr_retire     = 1'b0;", "base",
  "write slot never released"),
 ("RB_DUP_RSP", "extmem_rob.sv", "  wire ret    = load && b_last;", "  wire ret    = load && b_last && !(c_wr && e_id[cur] == '0 && !lock_q && ob_q == '0 && rv_q);", "base",
  "a write response can be emitted twice (duplicate completion)"),
 ("CT_ACCEPT", "extmem_ctrl.sv", "  assign accept_ok = (st_q == `XM_ST_READY) && !fault_cond;", "  assign accept_ok = 1'b1;", "base",
  "requests sent to a controller that is not calibrated"),
 ("CT_NO_WDOG", "extmem_ctrl.sv", "  wire wdog_hit   = (RESP_TIMEOUT != 0) && (wd_q >= 32'(RESP_TIMEOUT));", "  wire wdog_hit   = 1'b0;", "base",
  "hung controller never detected"),
 ("CT_NO_MCRST", "extmem_ctrl.sv", "  assign mc_rst_n  = mrst_q;", "  assign mc_rst_n  = 1'b1;", "base",
  "controller reset never driven (stale commands / responses survive a fault)"),
 ("CDC_FULL", "cdc/extmem_async_fifo.sv", "assign w_ready = ((wbin_q - rbin_w) != (A+1)'(DEPTH));", "assign w_ready = ((wbin_q - rbin_w) != (A+1)'(DEPTH + 1));",
  "async_slow_mc", "async FIFO overflows (full flag one entry late)"),
 ("CDC_GRAY", "cdc/extmem_async_fifo.sv", "      wgray_q <= wbin_n ^ (wbin_n >> 1);", "      wgray_q <= wbin_n;", "async_fast_mc",
  "binary instead of Gray pointer crossing (a CDC structural bug)"),
]


def run(mid, fname, orig, mut, cfgname, desc):
    work = ROOT / "build" / "mutants" / mid
    if work.exists():
        shutil.rmtree(work)
    shutil.copytree(ROOT / "rtl", work / "rtl")
    f = work / "rtl" / fname
    src = f.read_text()
    if src.count(orig) != 1:
        return {"id": mid, "status": "INVALID", "desc": desc, "why": f"pattern found {src.count(orig)} times"}
    f.write_text(src.replace(orig, mut))
    cfg = extmem_cfg.load(ROOT / "config" / "regress" / f"{cfgname}.json")
    rtl = [str(work / p) for p in (ROOT / "scripts" / "rtl_files.txt").read_text().split()]
    g = [f"-G{k}={v}" for k, v in extmem_cfg.tb_params(cfg).items()]
    r = subprocess.run(["verilator", "--binary", "--timing", "-j", "2", "-Wno-fatal", "-Wno-MULTIDRIVEN", "-Wno-WIDTH",
                        "-Wno-UNUSED", "-Wno-INITIALDLY", "-Wno-BLKANDNBLK", "-Wno-CASEINCOMPLETE",
                        f"-I{work/'rtl'}", *rtl, *TB, "--top-module", "tb_extmem", "-Mdir", str(work / "v"), "-o", "sim", *g],
                       cwd=ROOT, capture_output=True, text=True)
    if r.returncode != 0:
        return {"id": mid, "status": "BUILD_FAIL", "desc": desc, "why": r.stderr[-400:]}
    killed_by = None
    for t in DEF_TESTS:
        try:
            o = subprocess.run([str(work / "v" / "sim"), f"+TEST={t}", "+SEED=1", "+NTXN=400"], cwd=ROOT,
                               capture_output=True, text=True, timeout=240).stdout
        except subprocess.TimeoutExpired:
            o = "RESULT FAIL timeout"
        if "RESULT PASS" not in o:
            first = next((l for l in o.splitlines() if "ERROR" in l or "VIOLATION" in l or "RESULT FAIL" in l), "")
            killed_by = f"{t}: {first.strip()[:140]}"
            break
    shutil.rmtree(work / "v", ignore_errors=True)
    st = "KILLED" if killed_by else ("EQUIVALENT" if "EQUIVALENT" in desc else "SURVIVED")
    return {"id": mid, "file": fname, "config": cfgname, "desc": desc, "status": st, "by": killed_by or ""}


def main():
    t0 = time.time()
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        res = list(ex.map(lambda m: run(*m), M))
    killed = sum(r["status"] == "KILLED" for r in res)
    equiv = sum(r["status"] == "EQUIVALENT" for r in res)
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports" / "mutation.json").write_text(json.dumps(res, indent=1))
    lines = ["# Mutation testing", "",
             f"`scripts/mutate.py`: {len(res)} injected design bugs, **{killed} killed** by the test suite, "
             f"{equiv} documented equivalent mutant(s), {len(res) - killed - equiv} surviving "
             f"(tests: {', '.join(DEF_TESTS)}; seed 1, 400 transactions each; {time.time()-t0:.0f} s).", "",
             "| Mutant | File | Bug | Config | Result | First failure |", "|---|---|---|---|---|---|"]
    for r in res:
        lines.append(f"| {r['id']} | {r.get('file','')} | {r['desc']} | {r.get('config','')} | **{r['status']}** | "
                     f"{(r.get('by') or r.get('why') or '').replace('|', '/')} |")
    (ROOT / "reports" / "mutation.md").write_text("\n".join(lines) + "\n")
    for r in res:
        print(f"{r['status']:9s} {r['id']:14s} {r.get('by') or r.get('why','')}")
    print(f"{killed}/{len(res)} killed, {equiv} equivalent")


if __name__ == "__main__":
    main()
