#!/usr/bin/env python3
"""Verilator -Wall lint of the synthesizable RTL over every regression / template
configuration plus corner parameter sets, and Icarus -g2012 elaboration.
Writes reports/lint.md / reports/lint.json."""
import json, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import extmem_cfg  # noqa: E402
RTL = (ROOT / "scripts" / "rtl_files.txt").read_text().split()
sets = []
for f in sorted((ROOT / "config").glob("*/*.json")):
    c = extmem_cfg.load(f)
    p = extmem_cfg.bridge_params(c)
    p["EXT_BASE"] = f"32'h{p['EXT_BASE']:08X}"
    p["EXT_SIZE"] = f"33'h{p['EXT_SIZE']:09X}"
    sets.append((f.stem, p))
corners = {
    "corner_dw512_mb2": dict(DW=512, MAX_BURST=2, MAX_RD_OUT=2, MAX_WR_OUT=2),
    "corner_nr1_nw16": dict(MAX_RD_OUT=1, MAX_WR_OUT=16, SCHED_MODE=1, WR_HI=8, WR_LO=4),
    "corner_lw4_mb16": dict(LW=4, MAX_BURST=16),
    "corner_idw16_ooo": dict(IDW=16, UP_OOO=1, ROB_DEPTH=40),
    "corner_policy1_noperf": dict(UNAVAIL_POLICY=1, PERF=0, AUTO_RECOVER=0),
}
sets += list(corners.items())
res = []
for name, p in sets:
    g = [f"-G{k}={v}" for k, v in p.items()]
    r = subprocess.run(["verilator", "--lint-only", "-Wall", "-Irtl", *RTL, "--top-module", "silicaflux_extmem_bridge", *g],
                       cwd=ROOT, capture_output=True, text=True)
    warn = [l for l in (r.stdout + r.stderr).splitlines() if l.startswith("%")]
    res.append({"config": name, "verilator_wall": r.returncode == 0 and not warn, "messages": warn[:10]})
    print(name, "clean" if res[-1]["verilator_wall"] else warn[:3])
ri = subprocess.run(["iverilog", "-g2012", "-Irtl", "-o", "/dev/null", *RTL, "-s", "silicaflux_extmem_bridge"],
                    cwd=ROOT, capture_output=True, text=True)
ivl = [l for l in (ri.stdout + ri.stderr).splitlines() if "error" in l.lower()]
(ROOT / "reports").mkdir(exist_ok=True)
(ROOT / "reports" / "lint.json").write_text(json.dumps({"verilator": res, "icarus_errors": ivl}, indent=1))
L = ["# Lint", "", "`scripts/lint.py`: Verilator 5.020 `--lint-only -Wall` (no waivers on the command line; the few in-source",
     "waivers are commented) on the synthesizable RTL for every configuration file plus corner parameter sets;",
     "Icarus 12 `-g2012` elaboration.", "",
     f"* Verilator -Wall clean: **{sum(r['verilator_wall'] for r in res)} / {len(res)}** parameter sets",
     f"* Icarus elaboration errors: **{len(ivl)}** (Icarus prints 'sorry: constant selects in always_*' notes -- a",
     "  sensitivity-list limitation of Icarus, not an error)", "", "| Parameter set | Verilator -Wall |", "|---|---|"]
L += [f"| {r['config']} | {'clean' if r['verilator_wall'] else 'WARN: ' + '; '.join(r['messages'][:2])} |" for r in res]
(ROOT / "reports" / "lint.md").write_text("\n".join(L) + "\n")
sys.exit(0 if all(r["verilator_wall"] for r in res) and not ivl else 1)
