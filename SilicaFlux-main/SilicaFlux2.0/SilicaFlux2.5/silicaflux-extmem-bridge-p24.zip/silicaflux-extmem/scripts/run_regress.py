#!/usr/bin/env python3
"""SilicaFlux MemoryBridge -- regression runner.

For every config/regress/*.json (validated by extmem_cfg.py):
  * build tb_extmem with Verilator (--binary --timing) using the config's parameters;
  * run every listed test x seeds in parallel;
  * if "icarus": true, build with Icarus Verilog and require byte-identical
    RESULT/STAT/PERF output to Verilator for every test (seed 1).
Writes reports/regression.json and reports/regression.md.

    run_regress.py [--configs a,b] [--seeds N] [--ntxn N] [--jobs N] [--quick]
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import extmem_cfg  # noqa: E402

RTL = (ROOT / "scripts" / "rtl_files.txt").read_text().split()
TB = ["sim/models/extmem_sim_mc.sv", "tb/extmem_mc_checker.sv", "tb/extmem_sfbx_checker.sv",
      "third_party/silicaflux-datafabric/tb/common/sfb_protocol_checker.sv", "tb/tb_extmem.sv"]
VFLAGS = ["--binary", "--timing", "-j", "4", "-Wno-fatal", "-Wno-MULTIDRIVEN", "-Wno-WIDTH", "-Wno-UNUSED",
          "-Wno-INITIALDLY", "-Wno-BLKANDNBLK", "-Wno-CASEINCOMPLETE", "-Irtl"]


def sh(cmd, timeout=1800):
    return subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout)


def build_verilator(cfg, bdir: Path):
    bdir.mkdir(parents=True, exist_ok=True)
    g = [f"-G{k}={v}" for k, v in extmem_cfg.tb_params(cfg).items()]
    r = sh(["verilator", *VFLAGS, *RTL, *TB, "--top-module", "tb_extmem", "-Mdir", str(bdir / "v"), "-o", "sim", *g])
    (bdir / "verilator_build.log").write_text(r.stdout + r.stderr)
    if r.returncode != 0:
        raise RuntimeError(f"verilator build failed for {cfg['name']}")
    return bdir / "v" / "sim"


def build_icarus(cfg, bdir: Path):
    p = []
    for k, v in extmem_cfg.tb_params(cfg).items():
        p += [f"-Ptb_extmem.{k}={v}"]
    out = bdir / "ivl.vvp"
    r = sh(["iverilog", "-g2012", "-Irtl", "-o", str(out), *p, *RTL, *TB, "-s", "tb_extmem"])
    (bdir / "icarus_build.log").write_text(r.stdout + r.stderr)
    if r.returncode != 0:
        raise RuntimeError(f"icarus build failed for {cfg['name']}")
    return out


def run_one(cmd, timeout=900):
    t0 = time.time()
    try:
        r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
        out = r.stdout + r.stderr
    except subprocess.TimeoutExpired:
        out = "RESULT FAIL timeout(runner)"
    keep = "\n".join(l for l in out.splitlines() if l.startswith(("RESULT", "STAT", "PERF")))
    m = re.search(r"^RESULT (PASS|FAIL).*?errors=(\S+)(?: txns=(\d+) cycles=(\d+))?", out, re.M)
    res = {"pass": bool(m and m.group(1) == "PASS"), "secs": round(time.time() - t0, 2),
           "txns": int(m.group(3)) if m and m.group(3) else 0, "cycles": int(m.group(4)) if m and m.group(4) else 0}
    if not res["pass"]:
        res["log_tail"] = "\n".join(l for l in out.splitlines() if "ERROR" in l or "VIOLATION" in l or "RESULT" in l)[-2000:]
    return res, keep


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", default="")
    ap.add_argument("--seeds", type=int, default=0)
    ap.add_argument("--ntxn", type=int, default=0)
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 4)
    ap.add_argument("--quick", action="store_true")
    a = ap.parse_args()

    files = sorted((ROOT / "config" / "regress").glob("*.json"))
    if a.configs:
        want = set(a.configs.split(","))
        files = [f for f in files if f.stem in want]
    cfgs = [extmem_cfg.load(f) for f in files]
    broot = ROOT / "build" / "regress"
    t_start = time.time()

    # ------------------------------------------------ builds (parallel)
    with cf.ThreadPoolExecutor(max_workers=max(1, a.jobs // 4)) as ex:
        vbin = dict(zip([c["name"] for c in cfgs], ex.map(lambda c: build_verilator(c, broot / c["name"]), cfgs)))
        icfg = [c for c in cfgs if c.get("regression", {}).get("icarus")]
        ibin = dict(zip([c["name"] for c in icfg], ex.map(lambda c: build_icarus(c, broot / c["name"]), icfg)))

    # ------------------------------------------------ runs
    jobs = []
    for c in cfgs:
        rg = c.get("regression", {})
        seeds = a.seeds or (1 if a.quick else rg.get("seeds", 3))
        ntxn = a.ntxn or (300 if a.quick else rg.get("ntxn", 1000))
        for t in rg.get("tests", ["smoke"]):
            for s in range(1, seeds + 1):
                jobs.append((c["name"], t, s, "verilator",
                             [str(vbin[c["name"]]), f"+TEST={t}", f"+SEED={s}", f"+NTXN={ntxn}"]))
            if c["name"] in ibin:
                jobs.append((c["name"], t, 1, "icarus",
                             ["vvp", "-n", str(ibin[c["name"]]), f"+TEST={t}", "+SEED=1", f"+NTXN={ntxn}"]))
    results = []
    outs = {}
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        futs = {ex.submit(run_one, j[4]): j for j in jobs}
        for f in cf.as_completed(futs):
            name, t, s, sim, _ = futs[f]
            res, keep = f.result()
            res.update(config=name, test=t, seed=s, sim=sim)
            outs[(name, t, s, sim)] = keep
            results.append(res)
            if not res["pass"]:
                print(f"FAIL {name} {t} seed={s} {sim}\n{res.get('log_tail', '')}")

    # ------------------------------------------------ cross-simulation identity
    xsim = []
    for (name, t, s, sim), keep in outs.items():
        if sim == "icarus":
            v = outs.get((name, t, 1, "verilator"))
            xsim.append({"config": name, "test": t, "identical": v == keep})

    results.sort(key=lambda r: (r["config"], r["test"], r["sim"], r["seed"]))
    summary = {
        "date": time.strftime("%Y-%m-%d %H:%M:%S"),
        "tools": {"verilator": sh(["verilator", "--version"]).stdout.strip(),
                  "icarus": sh(["iverilog", "-V"]).stdout.splitlines()[0].strip()},
        "runs": len(results), "passed": sum(r["pass"] for r in results),
        "transactions": sum(r["txns"] for r in results), "cycles": sum(r["cycles"] for r in results),
        "xsim_checked": len(xsim), "xsim_identical": sum(x["identical"] for x in xsim),
        "wall_secs": round(time.time() - t_start, 1),
        "configs": [{"name": c["name"], "description": c["description"]} for c in cfgs],
    }
    rep = ROOT / "reports"
    rep.mkdir(exist_ok=True)
    tag = "_quick" if a.quick else ""
    (rep / f"regression{tag}.json").write_text(json.dumps({"summary": summary, "xsim": xsim, "runs": results}, indent=1))

    # ------------------------------------------------ markdown
    tests = sorted({r["test"] for r in results})
    lines = [f"# Regression results{' (quick)' if a.quick else ''}", "",
             f"Generated by `scripts/run_regress.py` on {summary['date']} -- {summary['tools']['verilator']}, "
             f"{summary['tools']['icarus']}.", "",
             f"* **{summary['passed']} / {summary['runs']}** simulation runs pass "
             f"({summary['transactions']:,} upstream transactions, {summary['cycles']:,} fabric cycles).",
             f"* Cross-simulation: **{summary['xsim_identical']} / {summary['xsim_checked']}** Icarus runs produce output "
             f"byte-identical to Verilator (verdict, statistics and all 32 performance counters).",
             "* Controller = `extmem_sim_mc` (SIMULATION-ONLY model).  No vendor controller, no PHY, no hardware.", "",
             "| Config | " + " | ".join(tests) + " |", "|---|" + "---|" * len(tests)]
    for c in cfgs:
        row = [c["name"]]
        for t in tests:
            rr = [r for r in results if r["config"] == c["name"] and r["test"] == t]
            if not rr:
                row.append("–")
            else:
                row.append(f"{sum(r['pass'] for r in rr)}/{len(rr)}")
        lines.append("| " + " | ".join(row) + " |")
    lines += ["", "Cells: passed / runs (Verilator seeds + one Icarus run where enabled).", "", "## Configurations", ""]
    for c in cfgs:
        lines.append(f"* `{c['name']}` -- {c['description']}")
    fails = [r for r in results if not r["pass"]]
    if fails:
        lines += ["", "## Failures", ""] + [f"* {r['config']} {r['test']} seed {r['seed']} ({r['sim']})" for r in fails]
    (rep / f"regression{tag}.md").write_text("\n".join(lines) + "\n")
    print(f"{summary['passed']}/{summary['runs']} pass, xsim identical {summary['xsim_identical']}/{summary['xsim_checked']}, "
          f"{summary['wall_secs']} s")
    return 0 if summary["passed"] == summary["runs"] and summary["xsim_identical"] == summary["xsim_checked"] else 1


if __name__ == "__main__":
    sys.exit(main())
