#!/usr/bin/env bash
# usage: build_sims.sh <outdir> <extra verilator -G args...>
set -e
cd "$(dirname "$0")/.."
out=$1; shift
mkdir -p "$out"
RTL=$(cat scripts/rtl_files.txt)
TB="sim/models/extmem_sim_mc.sv tb/extmem_mc_checker.sv tb/extmem_sfbx_checker.sv third_party/silicaflux-datafabric/tb/common/sfb_protocol_checker.sv tb/tb_extmem.sv"
verilator --binary --timing -j 8 -Wno-fatal -Wno-MULTIDRIVEN -Wno-WIDTH -Wno-UNUSED -Wno-INITIALDLY \
  -Wno-BLKANDNBLK -Wno-CASEINCOMPLETE -Irtl $RTL $TB --top-module tb_extmem -Mdir "$out/v" -o sim "$@" > "$out.vbuild.log" 2>&1
