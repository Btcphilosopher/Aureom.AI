#!/usr/bin/env bash
# Builds and runs tb/tb_df_integration.sv (bridge behind the unmodified DataFabric crossbar
# and DMA engines) for both DMA engines; writes reports/df_integration.log
set -e
cd "$(dirname "$0")/.."
RTL=$(cat scripts/rtl_files.txt)
DF=third_party/silicaflux-datafabric
DFRTL="$DF/rtl/interconnect/sfb_crossbar.sv $DF/rtl/interconnect/sfb_addr_decoder.sv $DF/rtl/interconnect/sfb_arbiter.sv
       $DF/rtl/interconnect/sfb_req_mux.sv $DF/rtl/interconnect/sfb_rsp_router.sv $DF/rtl/interconnect/sfb_error_slave.sv
       $DF/rtl/dma/dma_burst_engine.sv $DF/rtl/dma/dma_transfer_engine.sv $DF/rtl/dma/dma_fifo.sv $DF/rtl/dma/dma_validate.sv"
mkdir -p reports build
: > reports/df_integration.log
for k in 1 0; do
  for lat in "4 20" "40 80"; do
    set -- $lat
    d=build/dfi_k${k}_l$1
    mkdir -p $d
    verilator --binary --timing -j 4 -Wno-fatal -Wno-MULTIDRIVEN -Wno-WIDTH -Wno-UNUSED -Wno-INITIALDLY \
      -Wno-BLKANDNBLK -Wno-CASEINCOMPLETE -Wno-PINCONNECTEMPTY -Irtl -I$DF/rtl/dma $RTL $DFRTL \
      sim/models/extmem_sim_mc.sv tb/extmem_mc_checker.sv $DF/tb/common/sfb_protocol_checker.sv tb/tb_df_integration.sv \
      --top-module tb_df_integration -GDMA_KIND=$k -GLAT_MIN=$1 -GLAT_MAX=$2 -Mdir $d -o sim > $d.build.log 2>&1
    echo "== DMA_KIND=$k model latency $1..$2 cycles" >> reports/df_integration.log
    timeout 900 $d/sim | grep -E 'XFER|RESULT|ERROR|VIOLATION' >> reports/df_integration.log
  done
done
cat reports/df_integration.log
! grep -q 'RESULT FAIL' reports/df_integration.log
