#!/usr/bin/env python3
"""SilicaFlux MemoryBridge -- throughput / latency characterisation.

Runs the self-checking `bench` test of tb/tb_extmem.sv (all scoreboard checks
stay active) for a set of bridge variants and traffic points, reads the
bridge's own performance counters and compares sustained against theoretical
bandwidth.  Every number is a cycle count from RTL simulation against the
SIMULATION-ONLY controller model; latencies of that model are hypothetical.
Writes reports/throughput.json and reports/throughput.md.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import extmem_cfg  # noqa: E402

RTL = (ROOT / "scripts" / "rtl_files.txt").read_text().split()
TB = ["sim/models/extmem_sim_mc.sv", "tb/extmem_mc_checker.sv", "tb/extmem_sfbx_checker.sv",
      "third_party/silicaflux-datafabric/tb/common/sfb_protocol_checker.sv", "tb/tb_extmem.sv"]
P = ["CYCLES", "RD_REQ", "WR_REQ", "RD_BEATS", "WR_BEATS", "ERR_TXN", "UP_REQ_STALL", "UP_RSP_STALL", "MC_RD_CMD",
     "MC_WR_CMD", "MC_CMD_STALL", "MC_WD_BEATS", "MC_WD_STALL", "MC_RD_BEATS", "HAZARD_STALL", "ARB_BYPASS",
     "DIR_SWITCH", "RQ_OCC_SUM", "WQ_OCC_SUM", "RD_OUT_SUM", "WR_OUT_SUM", "RD_OUT_MAX", "WR_OUT_MAX",
     "RD_LAT_SUM", "RD_LAT_MAX", "WR_LAT_SUM", "WR_LAT_MAX", "RD_DONE", "WR_DONE", "NOSLOT_STALL", "UNAVAIL_CYC",
     "MC_PROTO"]
BASE = extmem_cfg.tb_params(extmem_cfg.load(ROOT / "config" / "regress" / "base.json"))
F_FAB_MHZ = 100.0     # used only to express beats/cycle in MB/s for planning


def build(name, over):
    p = dict(BASE, **over)
    d = ROOT / "build" / "perf" / name
    d.mkdir(parents=True, exist_ok=True)
    exe = d / "v" / "sim"
    if not exe.exists():
        r = subprocess.run(["verilator", "--binary", "--timing", "-j", "4", "-Wno-fatal", "-Wno-MULTIDRIVEN", "-Wno-WIDTH",
                            "-Wno-UNUSED", "-Wno-INITIALDLY", "-Wno-BLKANDNBLK", "-Wno-CASEINCOMPLETE", "-Irtl", *RTL, *TB,
                            "--top-module", "tb_extmem", "-Mdir", str(d / "v"), "-o", "sim",
                            *[f"-G{k}={v}" for k, v in p.items()]], cwd=ROOT, capture_output=True, text=True)
        if r.returncode:
            raise RuntimeError(r.stderr[-1000:])
    return exe, p


def bench(exe, p, ntxn, **kn):
    args = [str(exe), "+TEST=bench", "+SEED=1", f"+NTXN={ntxn}"] + [f"+{k}={v}" for k, v in kn.items()]
    out = subprocess.run(args, cwd=ROOT, capture_output=True, text=True, timeout=1800).stdout
    if "RESULT PASS" not in out:
        raise RuntimeError("bench run failed (scoreboard): " + " ".join(args) + "\n" + out[-1500:])
    c = {P[int(m.group(1))]: int(m.group(2)) for m in re.finditer(r"^PERF (\d+) (\d+)", out, re.M)}
    sb = p["DW"] // 8
    cyc = max(c["CYCLES"], 1)
    rd_bpc = c["RD_BEATS"] / cyc
    wr_bpc = c["WR_BEATS"] / cyc
    m = {
        "cycles": cyc,
        "rd_beats_per_cycle": round(rd_bpc, 4),
        "wr_beats_per_cycle": round(wr_bpc, 4),
        "total_beats_per_cycle": round(rd_bpc + wr_bpc, 4),
        "rd_MBps_at_100MHz": round(rd_bpc * sb * F_FAB_MHZ, 1),
        "wr_MBps_at_100MHz": round(wr_bpc * sb * F_FAB_MHZ, 1),
        "rd_lat_avg": round(c["RD_LAT_SUM"] / c["RD_DONE"], 1) if c["RD_DONE"] else None,
        "rd_lat_max": c["RD_LAT_MAX"],
        "wr_lat_avg": round(c["WR_LAT_SUM"] / c["WR_DONE"], 1) if c["WR_DONE"] else None,
        "wr_lat_max": c["WR_LAT_MAX"],
        "rd_out_avg": round(c["RD_OUT_SUM"] / cyc, 2), "rd_out_max": c["RD_OUT_MAX"],
        "wr_out_avg": round(c["WR_OUT_SUM"] / cyc, 2), "wr_out_max": c["WR_OUT_MAX"],
        "rq_occ_avg": round(c["RQ_OCC_SUM"] / cyc, 2), "wq_occ_avg": round(c["WQ_OCC_SUM"] / cyc, 2),
        "up_req_stall_frac": round(c["UP_REQ_STALL"] / cyc, 3), "noslot_stall_frac": round(c["NOSLOT_STALL"] / cyc, 3),
        "up_rsp_backpressure_frac": round(c["UP_RSP_STALL"] / cyc, 3),
        "mc_cmd_stall_frac": round(c["MC_CMD_STALL"] / cyc, 3), "mc_wd_stall_frac": round(c["MC_WD_STALL"] / cyc, 3),
        "arb_bypass": c["ARB_BYPASS"], "hazard_stall": c["HAZARD_STALL"], "dir_switch": c["DIR_SWITCH"],
        "rd_burst_util": round(c["MC_RD_BEATS"] / c["MC_RD_CMD"] / p["MAX_BURST"], 3) if c["MC_RD_CMD"] else None,
        "wr_burst_util": round(c["MC_WD_BEATS"] / c["MC_WR_CMD"] / p["MAX_BURST"], 3) if c["MC_WR_CMD"] else None,
        "avg_rd_burst": round(c["MC_RD_BEATS"] / c["MC_RD_CMD"], 2) if c["MC_RD_CMD"] else None,
        "mc_data_beats_per_cycle": round((c["MC_RD_BEATS"] + c["MC_WD_BEATS"]) / cyc, 4),
        "row_hits": int(re.search(r"row_hits=(\d+)", out).group(1)),
        "row_miss": int(re.search(r"row_miss=(\d+)", out).group(1)),
    }
    m["counters"] = c
    return m


def main():
    res = {"note": "RTL cycle simulation against extmem_sim_mc (SIMULATION-ONLY, hypothetical latencies). "
                   "MB/s columns assume a 100 MHz fabric clock for planning only.", "sweeps": {}}

    # ---- 1. outstanding reads vs latency (Little's law), 16-beat sequential reads
    sw = []
    for nr in (1, 2, 4, 8, 16):
        exe, p = build(f"nr{nr}", {"MAX_RD_OUT": nr})
        for lat in (10, 40):
            m = bench(exe, p, 600, RDPCT=100, LMIN=15, LMAX=15, AMODE=1, LAT=lat)
            rt = m["rd_lat_avg"]
            pred = min(1.0, nr * 16 / rt) if rt else None    # Little: throughput <= N * B / round trip
            sw.append(dict(MAX_RD_OUT=nr, model_lat=lat, little_pred=round(pred, 3), **{k: v for k, v in m.items() if k != "counters"}))
            print("nr", nr, lat, m["rd_beats_per_cycle"], rt)
    res["sweeps"]["outstanding"] = sw

    # ---- 2. burst length (8 read slots, latency 40)
    exe, p = build("nr8", {"MAX_RD_OUT": 8})
    sw = []
    for blen in (1, 2, 4, 8, 16):
        m = bench(exe, p, max(300, 9600 // blen), RDPCT=100, LMIN=blen - 1, LMAX=blen - 1, AMODE=1, LAT=40)
        sw.append(dict(burst=blen, **{k: v for k, v in m.items() if k != "counters"}))
        print("burst", blen, m["rd_beats_per_cycle"])
    res["sweeps"]["burst"] = sw

    # ---- 3. read / write mix, FIFO vs read-priority+batching (random addresses, 4-beat bursts)
    exe0, p0 = build("fifo_ooo", {"MC_OOO": 1})
    exe1, p1 = build("rprio_ooo", {"MC_OOO": 1, "SCHED_MODE": 1, "WR_HI": 6, "WR_LO": 2, "AGE_CAP": 16})
    sw = []
    for crdy in (100, 40):
        for rd in (100, 75, 50, 25, 0):
            for nm, (e, pp) in (("FIFO", (exe0, p0)), ("RPRIO+BATCH", (exe1, p1))):
                m = bench(e, pp, 1500, RDPCT=rd, LMIN=3, LMAX=3, AMODE=0, LAT=20, CMDRDY=crdy)
                sw.append(dict(read_pct=rd, sched=nm, cmd_rdy=crdy, **{k: v for k, v in m.items() if k != "counters"}))
                print("mix", crdy, rd, nm, m["total_beats_per_cycle"], m["dir_switch"])
    res["sweeps"]["mix_sched"] = sw

    # ---- 4. upstream ordering with a widely varying controller latency
    exe2, p2 = build("ooo_up", {"MC_OOO": 1, "UP_OOO": 1})
    sw = []
    for nm, (e, pp) in (("UP_OOO=0 (in order)", (exe0, p0)), ("UP_OOO=1 (per-ID)", (exe2, p2))):
        m = bench(e, pp, 1500, RDPCT=100, LMIN=3, LMAX=3, AMODE=0, LAT=5, LATMAX=120)
        sw.append(dict(mode=nm, **{k: v for k, v in m.items() if k != "counters"}))
        print("order", nm, m["rd_beats_per_cycle"], m["rd_lat_avg"])
    res["sweeps"]["ordering"] = sw

    # ---- 5. single-beat (SFB2-style) traffic: the DataFabric-crossbar use case
    exe3, p3 = build("sfb2", {"DW": 32, "IDW": 1, "MAX_BURST": 1, "MAX_RD_OUT": 3, "MAX_WR_OUT": 2, "SFB2_ONLY": 1})
    sw = []
    for lat in (4, 20, 40):
        m = bench(exe3, p3, 3000, RDPCT=100, LMIN=0, LMAX=0, AMODE=1, LAT=lat)
        sw.append(dict(model_lat=lat, **{k: v for k, v in m.items() if k != "counters"}))
    res["sweeps"]["sfb2_single_beat"] = sw

    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports" / "throughput.json").write_text(json.dumps(res, indent=1))
    write_md(res)


def write_md(res):
    S = res["sweeps"]
    L = ["# Throughput, latency and utilisation", "",
         "All numbers: RTL cycle simulation (`scripts/run_perf.py`, test `bench` of `tb/tb_extmem.sv` with every",
         "scoreboard check active) against `extmem_sim_mc`, a **simulation-only** controller model whose latencies are",
         "hypothetical cycle counts.  They characterise the **bridge** (how much latency it hides, where it stalls), not",
         "any DRAM device.  Counters come from the bridge's own `extmem_perf` block.  MB/s columns assume a 100 MHz fabric",
         "clock for planning only.", "",
         "## Theoretical peaks of the bridge", "",
         "| Path | Peak | DW = 64 at 100 MHz |", "|---|---|---|",
         "| upstream read data (rsp channel) | 1 beat / cycle | 800 MB/s |",
         "| upstream write data (req channel) | 1 beat / cycle | 800 MB/s |",
         "| MC interface read data / write data | 1 beat / cycle each (separate channels) | 800 MB/s each |",
         "| simulated controller data bus (model, half-duplex) | 1 beat / cycle shared + turnaround | 800 MB/s total |",
         "| latency hiding (Little's law) | sustained <= MAX_RD_OUT x burst / round trip | |", "",
         "## 1. Outstanding reads vs controller latency (16-beat sequential reads)", "",
         "| MAX_RD_OUT | model latency | sustained rd beats/cycle | Little's-law bound | avg read latency (cycles) | avg busy read slots | MB/s @100 MHz |",
         "|---|---|---|---|---|---|---|"]
    for r in S["outstanding"]:
        L.append(f"| {r['MAX_RD_OUT']} | {r['model_lat']} | {r['rd_beats_per_cycle']:.3f} | {r['little_pred']:.3f} | "
                 f"{r['rd_lat_avg']} | {r['rd_out_avg']} | {r['rd_MBps_at_100MHz']} |")
    L += ["", "Round-trip latency = upstream acceptance to last beat delivered (includes the model latency, the data",
          "transfer and the bridge's own pipeline: command register, read buffer, response register).",
          "", "## 2. Burst length (8 read slots, model latency 40)", "",
          "| burst (beats) | rd beats/cycle | avg read latency | MC burst utilisation (beats per command / MAX_BURST) | MB/s @100 MHz |",
          "|---|---|---|---|---|"]
    for r in S["burst"]:
        L.append(f"| {r['burst']} | {r['rd_beats_per_cycle']:.3f} | {r['rd_lat_avg']} | {r['rd_burst_util']} | {r['rd_MBps_at_100MHz']} |")
    L += ["", "## 3. Read/write mix: FIFO baseline vs read priority + write batching", "",
          "Random addresses over 64 KiB, 4-beat bursts, model latency 20 (+ toy row/bank timing), out-of-order controller.",
          "`cmd_rdy` = probability per cycle that the controller accepts a command: 100 % models a controller with a deep",
          "command queue (it absorbs everything, the bridge's queues stay empty), 40 % one with a shallow queue (commands",
          "back up in the bridge, so its scheduler has a choice).  The model charges a 2-slot read/write turnaround on its",
          "shared data bus; any difference therefore reflects that **model** property, not a measured DRAM effect.", "",
          "| cmd_rdy | read % | scheduler | total beats/cycle | rd lat avg | wr lat avg | direction switches | arbitration bypasses | hazard stalls | avg rd-queue occupancy |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for r in S["mix_sched"]:
        L.append(f"| {r['cmd_rdy']} % | {r['read_pct']} | {r['sched']} | {r['total_beats_per_cycle']:.3f} | {r['rd_lat_avg']} | "
                 f"{r['wr_lat_avg']} | {r['dir_switch']} | {r['arb_bypass']} | {r['hazard_stall']} | {r['rq_occ_avg']} |")
    L += ["", "## 4. Response ordering with a widely varying latency (5..120 cycles, 4-beat random reads)", "",
          "| upstream ordering | rd beats/cycle | avg read latency | max read latency |", "|---|---|---|---|"]
    for r in S["ordering"]:
        L.append(f"| {r['mode']} | {r['rd_beats_per_cycle']:.3f} | {r['rd_lat_avg']} | {r['rd_lat_max']} |")
    L += ["", "## 5. Single-beat SFB2 traffic (DataFabric crossbar style: DW 32, MAX_BURST 1, 3 read slots)", "",
          "| model latency | rd beats/cycle | avg read latency | MB/s @100 MHz |", "|---|---|---|---|"]
    for r in S["sfb2_single_beat"]:
        L.append(f"| {r['model_lat']} | {r['rd_beats_per_cycle']:.3f} | {r['rd_lat_avg']} | {r['rd_MBps_at_100MHz']} |")
    L += ["", "Behind the DataFabric `sfb_crossbar` (rev 2.0: one outstanding transaction per slave port) the bridge sees",
          "a single transaction at a time; `reports/df_integration.log` measures 0.21 B/cycle (DMA SRAM->EXT, model latency",
          "4..20) against 4 B/cycle peak for DW = 32.  Bandwidth from external DRAM therefore requires the SFB2-X direct",
          "port (bursts + multiple outstanding) or the crossbar extension planned in DataFabric PROTOCOL.md section 8.", ""]
    (ROOT / "reports" / "throughput.md").write_text("\n".join(L) + "\n")


if __name__ == "__main__":
    main()
