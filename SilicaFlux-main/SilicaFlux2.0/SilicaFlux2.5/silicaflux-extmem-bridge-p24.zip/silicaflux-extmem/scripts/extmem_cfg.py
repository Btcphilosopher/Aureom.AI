#!/usr/bin/env python3
"""SilicaFlux MemoryBridge -- configuration validator and parameter generator.

    extmem_cfg.py validate <cfg.json>...        schema + cross-field rules
    extmem_cfg.py params <cfg.json> --fmt verilator|icarus|sv|tb-verilator|tb-icarus

No third-party packages: implements the subset of JSON Schema used by
config/extmem_config.schema.json (type, enum, minimum, maximum,
exclusiveMinimum, pattern, required, properties, additionalProperties, items)
and then the cross-field rules of docs/CONFIGURATION.md.
"""
from __future__ import annotations

import json
import math
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCHEMA = ROOT / "config" / "extmem_config.schema.json"
TB_BASE = 0x8000_0000          # fixed window base of tb/tb_extmem.sv

DEFAULTS = {
    "ROB_DEPTH": 0, "BOUND_LOG2": 12, "UP_OOO": 0, "SCHED_MODE": 0, "WR_HI": 6, "WR_LO": 2, "AGE_CAP": 16,
    "UNAVAIL_POLICY": 0, "RST_HOLD": 16, "CAL_TIMEOUT": 0, "RESP_TIMEOUT": 0, "AUTO_RECOVER": 1, "PERF": 1,
    "ASYNC": 0, "CDC_DEPTH": 8, "CDC_SYNC": 2,
}
BRIDGE_PARAMS = ["DW", "IDW", "LW", "MAX_BURST", "MAX_RD_OUT", "MAX_WR_OUT", "ROB_DEPTH", "MC_AW", "EXT_BASE",
                 "EXT_SIZE", "BOUND_LOG2", "UP_OOO", "SCHED_MODE", "WR_HI", "WR_LO", "AGE_CAP", "UNAVAIL_POLICY",
                 "RST_HOLD", "CAL_TIMEOUT", "RESP_TIMEOUT", "AUTO_RECOVER", "PERF", "ASYNC", "CDC_DEPTH", "CDC_SYNC"]
TB_FROM_BRIDGE = ["DW", "IDW", "LW", "MAX_BURST", "MAX_RD_OUT", "MAX_WR_OUT", "ROB_DEPTH", "UP_OOO", "SCHED_MODE",
                  "WR_HI", "WR_LO", "AGE_CAP", "UNAVAIL_POLICY", "RST_HOLD", "CAL_TIMEOUT", "RESP_TIMEOUT",
                  "AUTO_RECOVER", "ASYNC", "CDC_DEPTH", "BOUND_LOG2"]


class ConfigError(Exception):
    pass


# ---------------------------------------------------------------- minimal JSON-Schema subset
_TYPES = {"object": dict, "array": list, "string": str, "boolean": bool}


def _check(node, sch, path, errs):
    t = sch.get("type")
    if t == "integer":
        if not (isinstance(node, int) and not isinstance(node, bool)):
            errs.append(f"{path}: expected integer")
            return
    elif t == "number":
        if not (isinstance(node, (int, float)) and not isinstance(node, bool)):
            errs.append(f"{path}: expected number")
            return
    elif t in _TYPES and not isinstance(node, _TYPES[t]):
        errs.append(f"{path}: expected {t}")
        return
    if "enum" in sch and node not in sch["enum"]:
        errs.append(f"{path}: {node!r} not in {sch['enum']}")
    if "minimum" in sch and node < sch["minimum"]:
        errs.append(f"{path}: {node} < minimum {sch['minimum']}")
    if "maximum" in sch and node > sch["maximum"]:
        errs.append(f"{path}: {node} > maximum {sch['maximum']}")
    if "exclusiveMinimum" in sch and node <= sch["exclusiveMinimum"]:
        errs.append(f"{path}: {node} <= {sch['exclusiveMinimum']}")
    if "pattern" in sch and not re.search(sch["pattern"], node):
        errs.append(f"{path}: {node!r} does not match {sch['pattern']}")
    if t == "object":
        for r in sch.get("required", []):
            if r not in node:
                errs.append(f"{path}: missing '{r}'")
        props = sch.get("properties", {})
        for k, v in node.items():
            if k in props:
                _check(v, props[k], f"{path}.{k}", errs)
            elif sch.get("additionalProperties", True) is False:
                errs.append(f"{path}: unknown key '{k}'")
    if t == "array" and "items" in sch:
        for i, v in enumerate(node):
            _check(v, sch["items"], f"{path}[{i}]", errs)


def _pow2(x: int) -> bool:
    return x > 0 and (x & (x - 1)) == 0


def load(path: str | Path) -> dict:
    cfg = json.loads(Path(path).read_text())
    errs: list[str] = []
    _check(cfg, json.loads(SCHEMA.read_text()), "$", errs)
    if errs:
        raise ConfigError("; ".join(errs))
    b = dict(DEFAULTS)
    b.update(cfg["bridge"])
    b["EXT_BASE"] = int(cfg["bridge"]["EXT_BASE"], 16)
    b["EXT_SIZE"] = int(cfg["bridge"]["EXT_SIZE"], 16)
    cfg["_b"] = b
    cross_check(cfg)
    return cfg


def rst_hold_min(b: dict, clk: dict) -> int:
    """RST_HOLD must cover the init_done synchroniser and the controller-side reset synchroniser."""
    if not b["ASYNC"]:
        return 2
    s = b["CDC_SYNC"]
    return s + 2 + math.ceil((s + 1) * clk["fabric_mhz"] / clk["mc_mhz"])


def cross_check(cfg: dict) -> None:
    b, clk, errs = cfg["_b"], cfg["clocks"], []
    sb = b["DW"] // 8
    nrob = b["ROB_DEPTH"] or (b["MAX_RD_OUT"] + b["MAX_WR_OUT"] + 2)
    if not _pow2(b["MAX_BURST"]) or b["MAX_BURST"] > (1 << b["LW"]):
        errs.append("MAX_BURST must be a power of two <= 2^LW")
    if b["EXT_BASE"] % sb or b["EXT_SIZE"] % sb or b["EXT_SIZE"] == 0:
        errs.append("EXT_BASE / EXT_SIZE must be multiples of DW/8 and SIZE > 0")
    if b["EXT_BASE"] + b["EXT_SIZE"] > (1 << 32):
        errs.append("window exceeds the 32-bit address space")
    if b["EXT_SIZE"] > (1 << b["MC_AW"]):
        errs.append("2^MC_AW < EXT_SIZE")
    if b["MAX_BURST"] * sb > (1 << b["BOUND_LOG2"]):
        errs.append("a maximum burst (MAX_BURST*DW/8 bytes) does not fit in a 2^BOUND_LOG2 region")
    if b["BOUND_LOG2"] > 12 and cfg["controller"]["kind"] in ("axi4_licensed", "xilinx_mig7_ui"):
        errs.append("AXI-class controllers forbid bursts crossing 4 KiB: BOUND_LOG2 must be <= 12")
    if b["SCHED_MODE"] and not (b["WR_LO"] < b["WR_HI"]):
        errs.append("WR_LO < WR_HI required")
    if cfg["upstream"]["protocol"] == "SFB2" and b["UP_OOO"]:
        errs.append("SFB2 (rev 2.0) requires in-order responses: UP_OOO = 0")
    if cfg["upstream"]["protocol"] == "SFB2" and cfg["status"] == "verified-in-simulation" and nrob + 1 > 8:
        errs.append("SFB2 regression config: ROB depth + 1 must be <= 8 for the DataFabric checker's R8 check")
    if not b["ASYNC"] and abs(clk["fabric_mhz"] - clk["mc_mhz"]) > 1e-9:
        errs.append("ASYNC = 0 requires mc_mhz == fabric_mhz")
    if b["RST_HOLD"] < rst_hold_min(b, clk):
        errs.append(f"RST_HOLD {b['RST_HOLD']} < {rst_hold_min(b, clk)} (CDC synchroniser latency)")
    if nrob < 1:
        errs.append("ROB depth must be >= 1")
    if cfg["status"] == "verified-in-simulation":
        if cfg["controller"]["kind"] != "sim_model":
            errs.append("only sim_model configurations can be 'verified-in-simulation' here")
        if b["EXT_BASE"] != TB_BASE:
            errs.append("testbench window base is fixed at 0x80000000")
        if not _pow2(b["EXT_SIZE"]) or (1 << b["MC_AW"]) != b["EXT_SIZE"]:
            errs.append("simulation configs: EXT_SIZE power of two and MC_AW = log2(EXT_SIZE)")
        if b["EXT_SIZE"] > (1 << 20):
            errs.append("simulation model memory limited to 1 MiB")
    if cfg["controller"]["kind"] != "sim_model" and cfg["controller"]["available"]:
        errs.append("no vendor controller is available in this project: 'available' must be false")
    if errs:
        raise ConfigError("; ".join(errs))


def bridge_params(cfg: dict) -> dict:
    b = cfg["_b"]
    return {k: b[k] for k in BRIDGE_PARAMS}


def tb_params(cfg: dict) -> dict:
    b, clk = cfg["_b"], cfg["clocks"]
    sim = cfg["controller"].get("sim", {})
    p = {k: b[k] for k in TB_FROM_BRIDGE}
    p["MEM_BYTES"] = b["EXT_SIZE"]
    p["CLK_PS"] = int(round(1e6 / clk["fabric_mhz"] / 2)) * 2
    p["MC_PS"] = int(round(1e6 / clk["mc_mhz"] / 2)) * 2
    p["MC_OOO"] = sim.get("OOO", 0)
    p["MC_INTERLEAVE"] = sim.get("INTERLEAVE", 0)
    p["CAL_CYCLES"] = sim.get("CAL_CYCLES", 40)
    p["SFB2_ONLY"] = 1 if cfg["upstream"]["protocol"] == "SFB2" else 0
    return p


def fmt(params: dict, style: str) -> str:
    if style == "verilator":
        return " ".join(f"-G{k}={v}" for k, v in params.items())
    if style == "icarus":
        return " ".join(f"-Ptb_extmem.{k}={v}" for k, v in params.items())
    if style == "sv":
        def lit(k, v):
            if k == "EXT_BASE":
                return f"32'h{v:08X}"
            if k == "EXT_SIZE":
                return f"33'h{v:09X}"
            return str(v)
        return ",\n".join(f"  .{k}({lit(k, v)})" for k, v in params.items())
    raise ValueError(style)


def main(argv: list[str]) -> int:
    if len(argv) < 2 or argv[0] not in ("validate", "params"):
        print(__doc__)
        return 2
    if argv[0] == "validate":
        bad = 0
        for f in argv[1:]:
            try:
                c = load(f)
                print(f"OK    {f}  [{c['status']}]")
            except (ConfigError, json.JSONDecodeError) as e:
                bad += 1
                print(f"FAIL  {f}: {e}")
        return 1 if bad else 0
    cfg = load(argv[1])
    style = argv[argv.index("--fmt") + 1] if "--fmt" in argv else "sv"
    if style.startswith("tb-"):
        print(fmt(tb_params(cfg), style[3:]))
    else:
        print(fmt(bridge_params(cfg), style))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
