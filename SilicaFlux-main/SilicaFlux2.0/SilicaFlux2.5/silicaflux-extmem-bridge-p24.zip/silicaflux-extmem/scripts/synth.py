#!/usr/bin/env python3
"""SilicaFlux MemoryBridge -- synthesis / place-and-route characterisation (open tools only).

For each configuration:
  1. Yosys generic synthesis of silicaflux_extmem_bridge: check -assert, no latches, cell count.
  2. Yosys synth_xilinx -family xc7 (Artix-7 class, e.g. the Arty A7-100T the repo already
     constrains for the SRAM self-test): LUT / FF / LUTRAM counts.  No Vivado: no timing.
  3. Yosys synth_ecp5 -abc9 + nextpnr-ecp5 --85k (ECP5-85F, the ULX3S device used by
     SilicaFlux-V) on extmem_ooc_wrap: post-route Fmax of the bridge logic (single clock).
Writes reports/synth.json and reports/synth.md.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RTL = (ROOT / "scripts" / "rtl_files.txt").read_text().split()
OUT = ROOT / "build" / "synth"

CONFIGS = [
    ("sfb2_slave", "DataFabric SFB2 slave: DW32, MAX_BURST 1, 3 rd / 2 wr slots, FIFO, in order",
     dict(DW=32, IDW=1, MAX_BURST=1, MAX_RD_OUT=3, MAX_WR_OUT=2, UP_OOO=0, SCHED_MODE=0, PERF=1, ASYNC=0)),
    ("base", "DW64, 16-beat bursts, 8 rd / 8 wr slots, FIFO scheduler, in order",
     dict(DW=64, IDW=4, MAX_BURST=16, MAX_RD_OUT=8, MAX_WR_OUT=8, UP_OOO=0, SCHED_MODE=0, PERF=1, ASYNC=0)),
    ("base_noperf", "as base, performance counters removed (PERF = 0)",
     dict(DW=64, IDW=4, MAX_BURST=16, MAX_RD_OUT=8, MAX_WR_OUT=8, UP_OOO=0, SCHED_MODE=0, PERF=0, ASYNC=0)),
    ("ooo_rprio", "as base + out-of-order upstream + read-priority / batching scheduler",
     dict(DW=64, IDW=4, MAX_BURST=16, MAX_RD_OUT=8, MAX_WR_OUT=8, UP_OOO=1, SCHED_MODE=1, PERF=1, ASYNC=0)),
    ("base_async", "as base + ASYNC = 1 (async FIFOs to the controller clock); no P&R (two clocks)",
     dict(DW=64, IDW=4, MAX_BURST=16, MAX_RD_OUT=8, MAX_WR_OUT=8, UP_OOO=0, SCHED_MODE=0, PERF=1, ASYNC=1)),
]
BRIDGE_FIXED = dict(LW=8, MC_AW=28)


def yosys(script: str, log: Path):
    r = subprocess.run(["yosys", "-p", script], cwd=ROOT, capture_output=True, text=True, timeout=3600)
    log.write_text(r.stdout + r.stderr)
    return r


def cells(text: str, names):
    out = {}
    for n in names:
        m = re.findall(rf"^\s+{re.escape(n)}\s+(\d+)\s*$", text, re.M)
        out[n] = int(m[-1]) if m else 0
    return out


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rtl = " ".join(RTL)
    res = []
    for name, desc, p in CONFIGS:
        t0 = time.time()
        bp = dict(p, **BRIDGE_FIXED)
        chp = " ".join(f"-set {k} {v}" for k, v in bp.items())
        r = {"name": name, "desc": desc, "params": p}
        # 1. generic
        lg = OUT / f"{name}_generic.log"
        y = yosys(f"read_verilog -sv -DSYNTHESIS -Irtl {rtl}; chparam {chp} silicaflux_extmem_bridge; "
                  f"hierarchy -check -top silicaflux_extmem_bridge; proc; flatten; opt; "
                  f"select -assert-none t:$dlatch t:$adlatch t:$dlatchsr; synth -top silicaflux_extmem_bridge; "
                  f"check -assert; stat", lg)
        r["generic_ok"] = y.returncode == 0
        m = re.findall(r"Number of cells:\s+(\d+)", y.stdout)
        r["generic_cells"] = int(m[-1]) if m else None
        # 2. xilinx 7-series
        lg = OUT / f"{name}_xc7.log"
        y = yosys(f"read_verilog -sv -DSYNTHESIS -Irtl {rtl}; chparam {chp} silicaflux_extmem_bridge; "
                  f"synth_xilinx -family xc7 -top silicaflux_extmem_bridge; stat", lg)
        c = cells(y.stdout, ["LUT1", "LUT2", "LUT3", "LUT4", "LUT5", "LUT6", "FDCE", "FDPE", "FDRE", "FDSE",
                             "RAM32M", "RAM64M", "RAM32X1D", "RAM64X1D", "RAM128X1D", "MUXF7", "MUXF8", "CARRY4", "RAMB18E1", "RAMB36E1"])
        r["xc7_ok"] = y.returncode == 0
        r["xc7_lut"] = sum(c[k] for k in c if k.startswith("LUT"))
        r["xc7_ff"] = c["FDCE"] + c["FDPE"] + c["FDRE"] + c["FDSE"]
        r["xc7_lutram"] = c["RAM32M"] + c["RAM64M"] + c["RAM32X1D"] + c["RAM64X1D"] + c["RAM128X1D"]
        r["xc7_bram"] = c["RAMB18E1"] + c["RAMB36E1"]
        # 3. ECP5 + nextpnr (single-clock configurations)
        wp = " ".join(f"-set {k} {v}" for k, v in p.items())
        js = OUT / f"{name}_ecp5.json"
        lg = OUT / f"{name}_ecp5_yosys.log"
        y = yosys(f"read_verilog -sv -DSYNTHESIS -Irtl {rtl} synth/extmem_ooc_wrap.sv; chparam {wp} extmem_ooc_wrap; "
                  f"synth_ecp5 -abc9 -top extmem_ooc_wrap -json {js}; stat", lg)
        c = cells(y.stdout, ["LUT4", "TRELLIS_FF", "TRELLIS_DPR16X4", "DP16KD", "CCU2C", "PFUMX", "L6MUX21"])
        r["ecp5_lut4"], r["ecp5_ff"], r["ecp5_dpr16x4"], r["ecp5_dp16kd"] = (
            c["LUT4"], c["TRELLIS_FF"], c["TRELLIS_DPR16X4"], c["DP16KD"])
        r["ecp5_note"] = "includes the OOC harness shift chain / XOR fold registers"
        if p["ASYNC"] == 0 and y.returncode == 0:
            lg = OUT / f"{name}_nextpnr.log"
            n = subprocess.run(["nextpnr-ecp5", "--85k", "--package", "CABGA381", "--speed", "6", "--json", str(js),
                                "--freq", "100", "--seed", "1", "--timing-allow-fail", "--report",
                                str(OUT / f"{name}_nextpnr_report.json")],
                               cwd=ROOT, capture_output=True, text=True, timeout=7200)
            lg.write_text(n.stdout + n.stderr)
            fm = re.findall(r"Max frequency for clock\s+'([^']+)':\s+([\d.]+) MHz", n.stderr)
            r["ecp5_fmax_mhz"] = float(fm[-1][1]) if fm else None
            u = re.search(r"TRELLIS_SLICE:\s+(\d+)/\s*(\d+)", n.stderr)
            r["ecp5_slices"] = f"{u.group(1)}/{u.group(2)}" if u else None
            r["nextpnr_ok"] = n.returncode == 0
        r["secs"] = round(time.time() - t0, 1)
        res.append(r)
        print(json.dumps(r))
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports" / "synth.json").write_text(json.dumps(res, indent=1))
    L = ["# Synthesis and place-and-route characterisation", "",
         "Open-source flow only (Yosys 0.33, nextpnr-ecp5 0.6, Trellis).  No vendor tool (Vivado / Diamond / Quartus) was",
         "available, so there is no vendor timing sign-off; the Xilinx numbers are Yosys `synth_xilinx` mapping counts.",
         "ECP5 Fmax: post-route, ECP5-85F speed 6 (the ULX3S device used by SilicaFlux-V), bridge inside the",
         "out-of-context harness `synth/extmem_ooc_wrap.sv` (all ports registered), single clock, seed 1.",
         "MC_AW = 28 (256 MiB window), LW = 8.", "",
         "| Config | Generic: latch-free, check -assert | Generic cells | xc7 LUT | xc7 FF | xc7 LUTRAM | ECP5 LUT4* | ECP5 FF* | ECP5 DPR16X4 | ECP5 Fmax (MHz) |",
         "|---|---|---|---|---|---|---|---|---|---|"]
    for r in res:
        fmax = f"{r['ecp5_fmax_mhz']:.1f}" if r.get("ecp5_fmax_mhz") else "n/a (two clocks)"
        L.append(f"| `{r['name']}` | {'PASS' if r['generic_ok'] else 'FAIL'} | {r['generic_cells']} | {r['xc7_lut']} | "
                 f"{r['xc7_ff']} | {r['xc7_lutram']} | {r['ecp5_lut4']} | {r['ecp5_ff']} | {r['ecp5_dpr16x4']} | {fmax} |")
    L += ["", "\\* ECP5 counts include the harness (input shift chain and output fold registers).", ""]
    for r in res:
        L.append(f"* `{r['name']}`: {r['desc']}")
    (ROOT / "reports" / "synth.md").write_text("\n".join(L) + "\n")


if __name__ == "__main__":
    sys.exit(main())
