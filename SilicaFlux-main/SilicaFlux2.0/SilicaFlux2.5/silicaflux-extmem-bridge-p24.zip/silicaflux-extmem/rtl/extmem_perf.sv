// =============================================================================
// SilicaFlux MemoryBridge :: extmem_perf -- performance counters
//
// `XM_PERF_N saturating CW-bit counters, indices in extmem_defs.svh.  Event
// counters add 1, occupancy counters add the instantaneous level every cycle
// (average = SUM / CYCLES), latency counters add the latency of each
// completed transaction (average = LAT_SUM / *_DONE), *_MAX keep the maximum.
// `en` = 0 freezes all counters (consistent multi-register read-out), `clr`
// zeroes them.  Removed entirely by PERF = 0 in the bridge top.
// =============================================================================
`include "extmem_defs.svh"
`default_nettype none

module extmem_perf #(
  parameter int  CW  = 32,
  parameter int  OW  = 8,      // width of occupancy inputs
  parameter int  TSW = 16
) (
  input  wire logic                       clk,
  input  wire logic                       rst_n,
  input  wire logic                       en,
  input  wire logic                       clr,
  input  wire logic                       ev_rd_req,
  input  wire logic                       ev_wr_req,
  input  wire logic                       ev_rd_beat_ok,
  input  wire logic                       ev_wbeat,
  input  wire logic                       ev_err_txn,
  input  wire logic                       ev_up_req_stall,
  input  wire logic                       ev_up_rsp_stall,
  input  wire logic                       ev_mc_rd_cmd,
  input  wire logic                       ev_mc_wr_cmd,
  input  wire logic                       ev_mc_cmd_stall,
  input  wire logic                       ev_mc_wd_beat,
  input  wire logic                       ev_mc_wd_stall,
  input  wire logic                       ev_mc_rd_beat,
  input  wire logic                       ev_hazard,
  input  wire logic                       ev_bypass,
  input  wire logic                       ev_switch,
  input  wire logic [OW-1:0]              rq_occ,
  input  wire logic [OW-1:0]              wq_occ,
  input  wire logic [OW-1:0]              rd_out,
  input  wire logic [OW-1:0]              wr_out,
  input  wire logic                       ev_rd_done,
  input  wire logic                       ev_wr_done,
  input  wire logic [TSW-1:0]             lat,
  input  wire logic                       ev_noslot,
  input  wire logic                       unavail,
  input  wire logic                       ev_mc_proto,
  output logic [`XM_PERF_N*CW-1:0]        cnt_flat
);
  logic [CW-1:0] c [`XM_PERF_N];
  logic [CW-1:0] add [`XM_PERF_N];
  logic [`XM_PERF_N-1:0] is_max;

  always_comb begin
    for (int i = 0; i < `XM_PERF_N; i++) begin
      add[i]    = '0;
      is_max[i] = 1'b0;
    end
    add[`XM_P_CYCLES]       = CW'(1);
    add[`XM_P_RD_REQ]       = CW'(ev_rd_req);
    add[`XM_P_WR_REQ]       = CW'(ev_wr_req);
    add[`XM_P_RD_BEATS]     = CW'(ev_rd_beat_ok);
    add[`XM_P_WR_BEATS]     = CW'(ev_wbeat);
    add[`XM_P_ERR_TXN]      = CW'(ev_err_txn);
    add[`XM_P_UP_REQ_STALL] = CW'(ev_up_req_stall);
    add[`XM_P_UP_RSP_STALL] = CW'(ev_up_rsp_stall);
    add[`XM_P_MC_RD_CMD]    = CW'(ev_mc_rd_cmd);
    add[`XM_P_MC_WR_CMD]    = CW'(ev_mc_wr_cmd);
    add[`XM_P_MC_CMD_STALL] = CW'(ev_mc_cmd_stall);
    add[`XM_P_MC_WD_BEATS]  = CW'(ev_mc_wd_beat);
    add[`XM_P_MC_WD_STALL]  = CW'(ev_mc_wd_stall);
    add[`XM_P_MC_RD_BEATS]  = CW'(ev_mc_rd_beat);
    add[`XM_P_HAZARD_STALL] = CW'(ev_hazard);
    add[`XM_P_ARB_BYPASS]   = CW'(ev_bypass);
    add[`XM_P_DIR_SWITCH]   = CW'(ev_switch);
    add[`XM_P_RQ_OCC_SUM]   = CW'(rq_occ);
    add[`XM_P_WQ_OCC_SUM]   = CW'(wq_occ);
    add[`XM_P_RD_OUT_SUM]   = CW'(rd_out);
    add[`XM_P_WR_OUT_SUM]   = CW'(wr_out);
    add[`XM_P_RD_OUT_MAX]   = CW'(rd_out);          is_max[`XM_P_RD_OUT_MAX] = 1'b1;
    add[`XM_P_WR_OUT_MAX]   = CW'(wr_out);          is_max[`XM_P_WR_OUT_MAX] = 1'b1;
    add[`XM_P_RD_LAT_SUM]   = ev_rd_done ? CW'(lat) : '0;
    add[`XM_P_RD_LAT_MAX]   = ev_rd_done ? CW'(lat) : '0; is_max[`XM_P_RD_LAT_MAX] = 1'b1;
    add[`XM_P_WR_LAT_SUM]   = ev_wr_done ? CW'(lat) : '0;
    add[`XM_P_WR_LAT_MAX]   = ev_wr_done ? CW'(lat) : '0; is_max[`XM_P_WR_LAT_MAX] = 1'b1;
    add[`XM_P_RD_DONE]      = CW'(ev_rd_done);
    add[`XM_P_WR_DONE]      = CW'(ev_wr_done);
    add[`XM_P_NOSLOT_STALL] = CW'(ev_noslot);
    add[`XM_P_UNAVAIL_CYC]  = CW'(unavail);
    add[`XM_P_MC_PROTO]     = CW'(ev_mc_proto);
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < `XM_PERF_N; i++) c[i] <= '0;
    end else if (clr) begin
      for (int i = 0; i < `XM_PERF_N; i++) c[i] <= '0;
    end else if (en) begin
      for (int i = 0; i < `XM_PERF_N; i++) begin
        if (is_max[i]) begin
          if (add[i] > c[i]) c[i] <= add[i];
        end else if ({1'b0, c[i]} + {1'b0, add[i]} > {1'b0, {CW{1'b1}}}) begin
          c[i] <= {CW{1'b1}};                       // saturate
        end else begin
          c[i] <= c[i] + add[i];
        end
      end
    end
  end

  always_comb begin
    for (int i = 0; i < `XM_PERF_N; i++) cnt_flat[i*CW +: CW] = c[i];
  end
endmodule

`default_nettype wire
