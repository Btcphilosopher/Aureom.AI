// =============================================================================
// SilicaFlux MemoryBridge :: extmem_ram -- 1 write / 1 read buffer RAM
//
// Technology-independent contract (SilicaFlux RTL rule 5): synchronous write,
// asynchronous (combinational) read.  On FPGA this infers distributed /
// LUT RAM; for an ASIC with large buffers replace the body by a 1R1W macro
// from the SilicaFlux SRAM Wrapper Library (with a registered read and one
// extra pipeline stage in the consumers) -- the contract is the only thing the
// bridge depends on.  Storage is datapath (valid-qualified by the slot
// tables), so it has no reset (rule 4).
// =============================================================================
`default_nettype none

module extmem_ram #(
  parameter int  W   = 32,
  parameter int  D   = 16,
  localparam int AWI = (D > 1) ? $clog2(D) : 1
) (
  input  wire logic           clk,
  input  wire logic           we,
  input  wire logic [AWI-1:0] waddr,
  input  wire logic [W-1:0]   wdata,
  input  wire logic [AWI-1:0] raddr,
  output logic      [W-1:0]   rdata
);
  logic [W-1:0] mem [D];

  always_ff @(posedge clk) begin
    if (we) mem[waddr] <= wdata;
  end

  assign rdata = mem[raddr];
endmodule

`default_nettype wire
