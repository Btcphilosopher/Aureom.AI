// =============================================================================
// SilicaFlux MemoryBridge :: extmem_sched -- request scheduler / command issue
//
// Two command queues (reads: NR entries, writes: NW entries -- one per slot,
// so they can never overflow).  Every command carries a global sequence
// number (age).  Selection, one command per cycle into the registered MC
// command output (held stable until mc_cmd_ready):
//
//   SCHED_MODE = 0  FIFO (baseline): the older of the two queue heads, i.e.
//                   strict global arrival order.  No address comparison.
//   SCHED_MODE = 1  read priority + write batching + fairness:
//                   * reads are preferred; a write "drain" (batch) starts when
//                     WR_HI writes are queued and stops at WR_LO;
//                   * a head bypassed AGE_CAP times by the other direction is
//                     forced next (bounded waiting for both directions);
//                   * a head may bypass older commands of the other direction
//                     only if its byte range overlaps none of them (RAW / WAR
//                     protection).  The globally oldest head is always legal,
//                     so the scheduler can never deadlock.
//
// Ordering contract with the controller (docs/MC_INTERFACE.md): accesses to
// overlapping addresses take effect in command-acceptance order.  The
// scheduler never reorders overlapping read/write pairs, so the memory
// semantics seen upstream are those of in-order execution.  It makes NO
// claim about DRAM row-buffer locality: it has no visibility of the
// controller's bank/row mapping.
//
// Write data: when a write command is accepted by the controller its slot is
// queued in the write-data sequencer, which streams the slot's beats from the
// write buffer (contract: data only for already-accepted commands, in command
// order, no interleaving).
// =============================================================================
`default_nettype none

module extmem_sched #(
  parameter int  NR         = 8,
  parameter int  NW         = 8,
  parameter int  MB         = 16,
  parameter int  MC_AW      = 28,
  parameter int  LW         = 8,
  parameter int  TW         = 3,
  parameter int  SB         = 8,           // bytes per beat
  parameter int  SCHED_MODE = 0,
  parameter int  WR_HI      = 6,
  parameter int  WR_LO      = 2,
  parameter int  AGE_CAP    = 16,
  localparam int BW         = (MB > 1) ? $clog2(MB) : 1,
  localparam int RTW        = (NR > 1) ? $clog2(NR) : 1,
  localparam int WTW        = (NW > 1) ? $clog2(NW) : 1,
  localparam int WBA        = (NW * MB > 1) ? $clog2(NW * MB) : 1,
  localparam int SQW        = $clog2(NR + NW) + 2,
  localparam int OFF        = $clog2(SB)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             flush,
  input  wire logic             issue_en,
  // ---------------------------------------------------------------- queue push (frontend)
  input  wire logic             rq_push,
  input  wire logic             wq_push,
  input  wire logic [TW-1:0]    q_slot,
  input  wire logic [MC_AW-1:0] q_addr,
  input  wire logic [BW-1:0]    q_len,
  // ---------------------------------------------------------------- MC command channel
  output logic                  mc_cmd_valid,
  input  wire logic             mc_cmd_ready,
  output logic                  mc_cmd_write,
  output logic [MC_AW-1:0]      mc_cmd_addr,
  output logic [LW-1:0]         mc_cmd_len,
  output logic [TW-1:0]         mc_cmd_tag,
  // ---------------------------------------------------------------- MC write-data channel (control)
  output logic                  mc_wd_valid,
  input  wire logic             mc_wd_ready,
  output logic                  mc_wd_last,
  output logic [WBA-1:0]        wbuf_raddr,
  // ---------------------------------------------------------------- progress (to tracker)
  output logic                  rd_issue,
  output logic [RTW-1:0]        rd_issue_idx,
  output logic                  wr_issue,
  output logic [WTW-1:0]        wr_issue_idx,
  output logic                  wd_done,
  output logic [WTW-1:0]        wd_done_idx,
  // ---------------------------------------------------------------- status / events
  output logic                  idle,
  output logic [RTW:0]          rq_cnt_o,
  output logic [WTW:0]          wq_cnt_o,
  output logic                  ev_hazard,
  output logic                  ev_bypass,
  output logic                  ev_switch
);
  // ------------------------------------------------------------ queues
  logic [RTW-1:0]   rq_slot [NR];
  logic [MC_AW-1:0] rq_addr [NR];
  logic [BW-1:0]    rq_len  [NR];
  logic [SQW-1:0]   rq_seq  [NR];
  logic [RTW-1:0]   rq_hd, rq_tl;
  logic [RTW:0]     rq_cnt;
  logic [WTW-1:0]   wq_slot [NW];
  logic [MC_AW-1:0] wq_addr [NW];
  logic [BW-1:0]    wq_len  [NW];
  logic [SQW-1:0]   wq_seq  [NW];
  logic [WTW-1:0]   wq_hd, wq_tl;
  logic [WTW:0]     wq_cnt;
  logic [SQW-1:0]   seq_q;

  function automatic logic [RTW-1:0] rinc(input logic [RTW-1:0] p);
    rinc = ({1'b0, p} == (RTW+1)'(NR - 1)) ? '0 : p + RTW'(1);
  endfunction
  function automatic logic [WTW-1:0] winc(input logic [WTW-1:0] p);
    winc = ({1'b0, p} == (WTW+1)'(NW - 1)) ? '0 : p + WTW'(1);
  endfunction
  // a older than b (wrap-safe: live sequence numbers span < 2^(SQW-1))
  function automatic logic seq_lt(input logic [SQW-1:0] a, input logic [SQW-1:0] b);
    logic [SQW-1:0] d;
    d = a - b;
    seq_lt = d[SQW-1];
  endfunction
  // byte ranges [a, a+(la+1)*SB) and [b, b+(lb+1)*SB) overlap
  function automatic logic ovl(input logic [MC_AW-1:0] a, input logic [BW-1:0] la,
                               input logic [MC_AW-1:0] b, input logic [BW-1:0] lb);
    logic [MC_AW:0] ae, be;
    ae  = {1'b0, a} + (({{(MC_AW-BW){1'b0}}, 1'b0, la} + {{MC_AW{1'b0}}, 1'b1}) << OFF);
    be  = {1'b0, b} + (({{(MC_AW-BW){1'b0}}, 1'b0, lb} + {{MC_AW{1'b0}}, 1'b1}) << OFF);
    ovl = ({1'b0, a} < be) && ({1'b0, b} < ae);
  endfunction

  wire rh = (rq_cnt != '0);
  wire wh = (wq_cnt != '0);

  // valid masks (entry i holds a queued command)
  logic [NR-1:0] rq_v;
  logic [NW-1:0] wq_v;
  // distance of entry i from the head (circular, no modulo operator)
  always_comb begin
    for (int i = 0; i < NR; i++) begin
      if ((RTW+1)'(i) >= {1'b0, rq_hd}) rq_v[i] = ((RTW+1)'(i) - {1'b0, rq_hd}) < rq_cnt;
      else rq_v[i] = ((RTW+1)'(i) + (RTW+1)'(NR) - {1'b0, rq_hd}) < rq_cnt;
    end
    for (int i = 0; i < NW; i++) begin
      if ((WTW+1)'(i) >= {1'b0, wq_hd}) wq_v[i] = ((WTW+1)'(i) - {1'b0, wq_hd}) < wq_cnt;
      else wq_v[i] = ((WTW+1)'(i) + (WTW+1)'(NW) - {1'b0, wq_hd}) < wq_cnt;
    end
  end

  // ------------------------------------------------------------ hazards
  logic haz_r, haz_w;
  always_comb begin
    haz_r = 1'b0;
    haz_w = 1'b0;
    if (SCHED_MODE != 0) begin
      for (int i = 0; i < NW; i++) begin
        if (wq_v[i] && seq_lt(wq_seq[i], rq_seq[rq_hd]) &&
            ovl(wq_addr[i], wq_len[i], rq_addr[rq_hd], rq_len[rq_hd])) haz_r = 1'b1;
      end
      for (int i = 0; i < NR; i++) begin
        if (rq_v[i] && seq_lt(rq_seq[i], wq_seq[wq_hd]) &&
            ovl(rq_addr[i], rq_len[i], wq_addr[wq_hd], wq_len[wq_hd])) haz_w = 1'b1;
      end
    end
  end

  // ------------------------------------------------------------ selection
  logic        drain_q, last_wr_q, any_issued_q;
  logic [$clog2(AGE_CAP+1)-1:0] r_wait_q, w_wait_q;
  logic        pick_r, pick_w, pref_w, r_ok, w_ok;
  wire         r_older = rh && (!wh || seq_lt(rq_seq[rq_hd], wq_seq[wq_hd]));
  wire         r_starve = (r_wait_q >= ($clog2(AGE_CAP+1))'(AGE_CAP));
  wire         w_starve = (w_wait_q >= ($clog2(AGE_CAP+1))'(AGE_CAP));

  always_comb begin
    r_ok   = rh && !haz_r;
    w_ok   = wh && !haz_w;
    pref_w = 1'b0;
    pick_r = 1'b0;
    pick_w = 1'b0;
    if (SCHED_MODE == 0) begin
      pick_r = r_older;
      pick_w = !r_older && wh;
    end else begin
      if (w_starve)      pref_w = 1'b1;
      else if (r_starve) pref_w = 1'b0;
      else               pref_w = drain_q;
      if (pref_w) begin
        pick_w = w_ok;
        pick_r = !w_ok && r_ok;
      end else begin
        pick_r = r_ok;
        pick_w = !r_ok && w_ok;
      end
    end
  end

  // ------------------------------------------------------------ command output register
  logic             cmd_v_q, cmd_w_q;
  logic [MC_AW-1:0] cmd_a_q;
  logic [BW-1:0]    cmd_l_q;
  logic [TW-1:0]    cmd_t_q;
  wire cmd_hs   = cmd_v_q && mc_cmd_ready;
  wire cmd_load = issue_en && !flush && (!cmd_v_q || mc_cmd_ready) && (pick_r || pick_w);
  wire pop_r    = cmd_load && pick_r;
  wire pop_w    = cmd_load && pick_w;

  assign mc_cmd_valid = cmd_v_q;
  assign mc_cmd_write = cmd_w_q;
  assign mc_cmd_addr  = cmd_a_q;
  assign mc_cmd_len   = LW'(cmd_l_q);
  assign mc_cmd_tag   = cmd_t_q;

  assign rd_issue     = cmd_hs && !cmd_w_q;
  assign rd_issue_idx = cmd_t_q[RTW-1:0];
  assign wr_issue     = cmd_hs && cmd_w_q;
  assign wr_issue_idx = cmd_t_q[WTW-1:0];

  // ------------------------------------------------------------ write-data sequencer
  logic [WTW-1:0] ds_slot [NW];
  logic [BW-1:0]  ds_len  [NW];
  logic [WTW-1:0] ds_hd, ds_tl;
  logic [WTW:0]   ds_cnt;
  logic [BW-1:0]  ds_beat_q;
  wire ds_v     = (ds_cnt != '0);
  wire ds_last  = (ds_beat_q == ds_len[ds_hd]);
  wire wd_hs    = ds_v && mc_wd_ready;
  wire ds_push  = cmd_hs && cmd_w_q;
  wire ds_pop   = wd_hs && ds_last;

  assign mc_wd_valid = ds_v;
  assign mc_wd_last  = ds_last;
  assign wbuf_raddr  = WBA'(ds_slot[ds_hd]) * WBA'(MB) + WBA'(ds_beat_q);
  assign wd_done     = ds_pop;
  assign wd_done_idx = ds_slot[ds_hd];

  // ------------------------------------------------------------ sequential
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rq_hd <= '0; rq_tl <= '0; rq_cnt <= '0;
      wq_hd <= '0; wq_tl <= '0; wq_cnt <= '0;
      ds_hd <= '0; ds_tl <= '0; ds_cnt <= '0; ds_beat_q <= '0;
      seq_q <= '0;
      cmd_v_q <= 1'b0; cmd_w_q <= 1'b0; cmd_a_q <= '0; cmd_l_q <= '0; cmd_t_q <= '0;
      drain_q <= 1'b0; last_wr_q <= 1'b0; any_issued_q <= 1'b0;
      r_wait_q <= '0; w_wait_q <= '0;
      // queue entries are datapath, valid-qualified by the counts: no reset (RTL rule 4)
    end else if (flush) begin
      rq_hd <= '0; rq_tl <= '0; rq_cnt <= '0;
      wq_hd <= '0; wq_tl <= '0; wq_cnt <= '0;
      ds_hd <= '0; ds_tl <= '0; ds_cnt <= '0; ds_beat_q <= '0;
      cmd_v_q <= 1'b0;
      drain_q <= 1'b0;
      r_wait_q <= '0; w_wait_q <= '0;
    end else begin
      // -------------------------------------------------- queue push
      if (rq_push) begin
        rq_slot[rq_tl] <= q_slot[RTW-1:0];
        rq_addr[rq_tl] <= q_addr;
        rq_len[rq_tl]  <= q_len;
        rq_seq[rq_tl]  <= seq_q;
        rq_tl          <= rinc(rq_tl);
      end
      if (wq_push) begin
        wq_slot[wq_tl] <= q_slot[WTW-1:0];
        wq_addr[wq_tl] <= q_addr;
        wq_len[wq_tl]  <= q_len;
        wq_seq[wq_tl]  <= seq_q;
        wq_tl          <= winc(wq_tl);
      end
      if (rq_push || wq_push) seq_q <= seq_q + SQW'(1);
      if (pop_r) rq_hd <= rinc(rq_hd);
      if (pop_w) wq_hd <= winc(wq_hd);
      rq_cnt <= rq_cnt + (RTW+1)'(rq_push) - (RTW+1)'(pop_r);
      wq_cnt <= wq_cnt + (WTW+1)'(wq_push) - (WTW+1)'(pop_w);

      // -------------------------------------------------- command register
      if (cmd_load) begin
        cmd_v_q <= 1'b1;
        cmd_w_q <= pick_w;
        cmd_a_q <= pick_w ? wq_addr[wq_hd] : rq_addr[rq_hd];
        cmd_l_q <= pick_w ? wq_len[wq_hd]  : rq_len[rq_hd];
        cmd_t_q <= pick_w ? TW'(wq_slot[wq_hd]) : TW'(rq_slot[rq_hd]);
        last_wr_q    <= pick_w;
        any_issued_q <= 1'b1;
      end else if (cmd_hs) begin
        cmd_v_q <= 1'b0;
      end

      // -------------------------------------------------- batching / fairness state
      if (SCHED_MODE != 0) begin
        if (!drain_q && ({1'b0, wq_cnt} >= (WTW+2)'(WR_HI))) drain_q <= 1'b1;
        else if (drain_q && ({1'b0, wq_cnt} <= (WTW+2)'(WR_LO))) drain_q <= 1'b0;
        if (pop_w)           w_wait_q <= '0;
        else if (pop_r && wh && !w_starve) w_wait_q <= w_wait_q + 1'b1;
        if (pop_r)           r_wait_q <= '0;
        else if (pop_w && rh && !r_starve) r_wait_q <= r_wait_q + 1'b1;
      end

      // -------------------------------------------------- write-data sequencer
      if (ds_push) begin
        ds_slot[ds_tl] <= cmd_t_q[WTW-1:0];
        ds_len[ds_tl]  <= cmd_l_q;
        ds_tl          <= winc(ds_tl);
      end
      if (wd_hs) begin
        if (ds_last) begin
          ds_beat_q <= '0;
          ds_hd     <= winc(ds_hd);
        end else begin
          ds_beat_q <= ds_beat_q + BW'(1);
        end
      end
      ds_cnt <= ds_cnt + (WTW+1)'(ds_push) - (WTW+1)'(ds_pop);
    end
  end

  // ------------------------------------------------------------ status / events
  assign idle     = !rh && !wh && !cmd_v_q && !ds_v;
  assign rq_cnt_o = rq_cnt;
  assign wq_cnt_o = wq_cnt;
  // preferred head blocked by an older overlapping command of the other direction
  assign ev_hazard = (SCHED_MODE != 0) && issue_en && (!cmd_v_q || mc_cmd_ready) &&
                     ((pref_w && wh && haz_w) || (!pref_w && rh && haz_r));
  // a head waited while the other direction issued
  assign ev_bypass = (pop_r && wh) || (pop_w && rh);
  assign ev_switch = cmd_load && any_issued_q && (pick_w != last_wr_q);
endmodule

`default_nettype wire
