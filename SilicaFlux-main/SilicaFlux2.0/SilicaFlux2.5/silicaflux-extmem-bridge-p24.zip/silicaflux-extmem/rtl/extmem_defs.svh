// =============================================================================
// SilicaFlux MemoryBridge (Project 24) :: extmem_defs.svh
// Shared constants of silicaflux_extmem_bridge.  Plain `define macros (the
// SilicaFlux RTL coding rules forbid package imports in synthesizable RTL).
// =============================================================================
`ifndef EXTMEM_DEFS_SVH
`define EXTMEM_DEFS_SVH

// ---------------------------------------------------------------- error codes
// Reported in the error-capture sideband / CSR ERR_STATUS.CODE.  On the bus a
// failed beat is signalled by rsp_error = 1 with rsp_rdata = 0 (SFB2 rule R8).
`define XM_ERR_NONE      4'd0
`define XM_ERR_RANGE     4'd1   // [addr, addr+bytes) not inside the external-memory window
`define XM_ERR_ALIGN     4'd2   // addr not DW-aligned (SFB2 R9)
`define XM_ERR_LEN       4'd3   // req_len+1 > MAX_BURST
`define XM_ERR_BOUNDARY  4'd4   // burst crosses a 2^BOUND_LOG2-byte boundary
`define XM_ERR_UNAVAIL   4'd5   // controller not calibrated / in reset / faulted / quiescing
`define XM_ERR_MC_RD     4'd6   // controller returned a read-data error
`define XM_ERR_MC_WR     4'd7   // controller returned a write-response error
`define XM_ERR_FLUSH     4'd8   // transaction aborted by a controller fault (flush)
`define XM_ERR_PROTO     4'd9   // upstream write-burst framing error (req_last vs req_len)
`define XM_ERR_MC_PROTO  4'd10  // controller response broke the MC-interface contract

// ---------------------------------------------------------------- controller-link state
`define XM_ST_RESET      3'd0   // controller held in reset (RST_HOLD cycles)
`define XM_ST_CAL        3'd1   // waiting for mc_init_done (calibration)
`define XM_ST_READY      3'd2   // normal operation
`define XM_ST_QUIESCE    3'd3   // draining before a requested controller reset
`define XM_ST_FAULT      3'd4   // controller failed: transactions flushed, controller in reset
`define XM_ST_CALFAIL    3'd5   // calibration timeout (waits for a reset request)

// ---------------------------------------------------------------- performance counters
`define XM_PERF_N             32
`define XM_P_CYCLES           0   // cycles counted (enable = 1)
`define XM_P_RD_REQ           1   // upstream read transactions accepted (incl. errors)
`define XM_P_WR_REQ           2   // upstream write transactions accepted (incl. errors)
`define XM_P_RD_BEATS         3   // read beats returned upstream without error
`define XM_P_WR_BEATS         4   // write data beats accepted upstream
`define XM_P_ERR_TXN          5   // transactions completed with at least one error beat
`define XM_P_UP_REQ_STALL     6   // up_req_valid && !up_req_ready
`define XM_P_UP_RSP_STALL     7   // up_rsp_valid && !up_rsp_ready (upstream back-pressure)
`define XM_P_MC_RD_CMD        8   // read commands accepted by the controller
`define XM_P_MC_WR_CMD        9   // write commands accepted by the controller
`define XM_P_MC_CMD_STALL     10  // mc_cmd_valid && !mc_cmd_ready
`define XM_P_MC_WD_BEATS      11  // write-data beats accepted by the controller
`define XM_P_MC_WD_STALL      12  // mc_wd_valid && !mc_wd_ready
`define XM_P_MC_RD_BEATS      13  // read-data beats received from the controller
`define XM_P_HAZARD_STALL     14  // preferred queue head blocked by an address hazard
`define XM_P_ARB_BYPASS       15  // a queue head waited while the other direction issued
`define XM_P_DIR_SWITCH       16  // read<->write direction changes on the command channel
`define XM_P_RQ_OCC_SUM       17  // sum over cycles of read-queue occupancy
`define XM_P_WQ_OCC_SUM       18  // sum over cycles of write-queue occupancy
`define XM_P_RD_OUT_SUM       19  // sum over cycles of busy read slots
`define XM_P_WR_OUT_SUM       20  // sum over cycles of busy write slots
`define XM_P_RD_OUT_MAX       21  // maximum busy read slots
`define XM_P_WR_OUT_MAX       22  // maximum busy write slots
`define XM_P_RD_LAT_SUM       23  // sum of read latency (accept -> last beat handshake)
`define XM_P_RD_LAT_MAX       24
`define XM_P_WR_LAT_SUM       25  // sum of write latency (last data beat -> response handshake)
`define XM_P_WR_LAT_MAX       26
`define XM_P_RD_DONE          27  // read transactions whose last beat was delivered
`define XM_P_WR_DONE          28  // write transactions whose response was delivered
`define XM_P_NOSLOT_STALL     29  // first beat stalled: no slot / ROB entry (subset of 6)
`define XM_P_UNAVAIL_CYC      30  // cycles the controller link was not READY
`define XM_P_MC_PROTO         31  // controller responses that broke the contract (dropped)

`endif
