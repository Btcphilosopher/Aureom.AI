// =============================================================================
// SilicaFlux MemoryBridge :: extmem_csr -- SFB2 register slave (32-bit)
//
// One 4 KiB page (proposed: PERIPH page 8, 0x4000_8000 -- docs/memmap_extmem.yaml).
// SFB2 rev 2.0 slave: one transaction outstanding, response one cycle after
// acceptance, accept-while-retiring (req_ready = !rsp_valid || rsp_ready).
// Word access only: a write with wstrb != 4'hF, a write to a read-only
// register or an access to an undefined offset is answered with rsp_error
// and has no side effect (SFB2 R8).
//
//   0x000 ID          ro  0x5346584D "SFXM"
//   0x004 INFO0       ro  [7:0] DW bytes  [15:8] MAX_BURST-1  [23:16] MAX_RD_OUT  [31:24] MAX_WR_OUT
//   0x008 INFO1       ro  [0] UP_OOO [1] ASYNC [2] SCHED_MODE [3] UNAVAIL_POLICY [4] PERF
//                         [11:8] ID_W  [23:16] ROB_DEPTH  [31:24] VERSION (1)
//   0x00C BASE        ro  window base (byte address)
//   0x010 SIZE_LO     ro  window size in bytes, bits [31:0]
//   0x014 SIZE_HI     ro  window size in bytes, bit 32
//   0x018 STATUS      ro  [2:0] STATE [3] READY [4] CAL_FAIL [5] FAULT_SEEN (sticky) [6] IN_FLIGHT
//   0x01C CONTROL     wo  [0] MC_RESET (w1s: quiesce, reset and recalibrate the controller)
//                         [1] CLR_STICKY (w1s)  [2] PERF_CLEAR (w1s)
//   0x020 PERF_CTRL   rw  [0] PERF_ENABLE (reset 1; 0 freezes counters for a consistent read-out)
//   0x024 ERR_STATUS  rw  [0] VALID (w1c) [1] OVERFLOW (w1c) [7:4] CODE [8] WRITE [31:16] ID
//   0x028 ERR_ADDR    ro  address of the first captured failing transaction
//   0x02C ERR_COUNT   ro  failed transactions since reset (saturating)
//   0x080 + 4*i PERF[i] ro  performance counter i (extmem_defs.svh), i < 32
// =============================================================================
`include "extmem_defs.svh"
`default_nettype none

module extmem_csr #(
  parameter int             AW         = 32,
  parameter int             IDW        = 4,
  parameter logic [31:0]    INFO0      = 32'h0,
  parameter logic [31:0]    INFO1      = 32'h0,
  parameter logic [31:0]    BASE_W     = 32'h0,
  parameter logic [63:0]    SIZE_W     = 64'h0,
  parameter int             CW         = 32
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  // ---------------------------------------------------------------- SFB2 slave
  input  wire logic                    req_valid,
  output logic                         req_ready,
  input  wire logic                    req_write,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [31:0]             req_addr,
  /* verilator lint_on UNUSEDSIGNAL */
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [31:0]             req_wdata,      // only control bits are used
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [3:0]              req_wstrb,
  output logic                         rsp_valid,
  input  wire logic                    rsp_ready,
  output logic [31:0]                  rsp_rdata,
  output logic                         rsp_error,
  // ---------------------------------------------------------------- bridge status / control
  input  wire logic [2:0]              st_state,
  input  wire logic                    st_ready,
  input  wire logic                    st_cal_fail,
  input  wire logic                    st_fault_seen,
  input  wire logic                    st_inflight,
  output logic                         ctl_mc_reset,
  output logic                         ctl_clr_sticky,
  output logic                         perf_en,
  output logic                         perf_clr,
  input  wire logic                    err_evt,
  input  wire logic [3:0]              err_code,
  input  wire logic [AW-1:0]           err_addr,
  input  wire logic [IDW-1:0]          err_id,
  input  wire logic                    err_write,
  input  wire logic [`XM_PERF_N*CW-1:0] perf_cnt
);
  logic        rv_q, re_q, pen_q;
  logic [31:0] rd_q;
  logic        ev_q, eo_q, ew_q;
  logic [3:0]  ec_q;
  logic [15:0] ei_q;
  logic [31:0] ea_q, ecnt_q;

  assign req_ready = !rv_q || rsp_ready;
  wire   hs        = req_valid && req_ready;
  wire [11:0] off  = {req_addr[11:2], 2'b00};
  wire   full_w    = (req_wstrb == 4'hF);
  /* verilator lint_off UNUSEDSIGNAL */
  wire [11:0] pofs  = off - 12'h080;
  /* verilator lint_on UNUSEDSIGNAL */
  wire [4:0]  pidx  = pofs[6:2];

  // ------------------------------------------------------------ decode
  logic        dec_ok, dec_ro;
  logic [31:0] dec_rd;
  always_comb begin
    dec_ok = 1'b1;
    dec_ro = 1'b1;
    dec_rd = '0;
    case (off)
      12'h000: dec_rd = 32'h5346584D;
      12'h004: dec_rd = INFO0;
      12'h008: dec_rd = INFO1;
      12'h00C: dec_rd = BASE_W;
      12'h010: dec_rd = SIZE_W[31:0];
      12'h014: dec_rd = SIZE_W[63:32];
      12'h018: dec_rd = {25'd0, st_inflight, st_fault_seen, st_cal_fail, st_ready, st_state};
      12'h01C: begin dec_rd = '0; dec_ro = 1'b0; end
      12'h020: begin dec_rd = {31'd0, pen_q}; dec_ro = 1'b0; end
      12'h024: begin dec_rd = {ei_q, 7'd0, ew_q, ec_q, 2'd0, eo_q, ev_q}; dec_ro = 1'b0; end
      12'h028: dec_rd = ea_q;
      12'h02C: dec_rd = ecnt_q;
      default: begin
        if (off >= 12'h080 && off < 12'h080 + 12'(4 * `XM_PERF_N)) begin
          dec_rd = perf_cnt[32'(pidx) * CW +: 32];
        end else begin
          dec_ok = 1'b0;
        end
      end
    endcase
  end

  wire acc_err = !dec_ok || (req_write && (dec_ro || !full_w));
  wire wr_ok   = hs && req_write && !acc_err;

  assign ctl_mc_reset   = wr_ok && off == 12'h01C && req_wdata[0];
  assign ctl_clr_sticky = wr_ok && off == 12'h01C && req_wdata[1];
  assign perf_clr       = wr_ok && off == 12'h01C && req_wdata[2];
  assign perf_en        = pen_q;

  assign rsp_valid = rv_q;
  assign rsp_error = re_q;
  assign rsp_rdata = rd_q;

  wire [15:0] err_id16 = 16'(err_id);
  wire clr_v = wr_ok && off == 12'h024 && req_wdata[0];
  wire clr_o = wr_ok && off == 12'h024 && req_wdata[1];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rv_q   <= 1'b0;
      re_q   <= 1'b0;
      rd_q   <= '0;
      pen_q  <= 1'b1;
      ev_q   <= 1'b0;
      eo_q   <= 1'b0;
      ew_q   <= 1'b0;
      ec_q   <= '0;
      ei_q   <= '0;
      ea_q   <= '0;
      ecnt_q <= '0;
    end else begin
      if (hs) begin
        rv_q <= 1'b1;
        re_q <= acc_err;
        rd_q <= (acc_err || req_write) ? '0 : dec_rd;
      end else if (rsp_ready) begin
        rv_q <= 1'b0;
      end
      if (wr_ok && off == 12'h020) pen_q <= req_wdata[0];
      // -------------------------------------------------- error capture (first error sticky)
      if (clr_v) ev_q <= 1'b0;
      if (clr_o) eo_q <= 1'b0;
      if (err_evt) begin
        if (ecnt_q != 32'hFFFF_FFFF) ecnt_q <= ecnt_q + 32'd1;
        if (!ev_q || clr_v) begin
          ev_q <= 1'b1;
          ec_q <= err_code;
          ew_q <= err_write;
          ei_q <= err_id16;
          ea_q <= 32'(err_addr);
        end else begin
          eo_q <= 1'b1;
        end
      end
    end
  end
endmodule

`default_nettype wire
