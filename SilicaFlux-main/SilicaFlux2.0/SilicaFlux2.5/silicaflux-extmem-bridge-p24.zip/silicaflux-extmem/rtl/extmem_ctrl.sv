// =============================================================================
// SilicaFlux MemoryBridge :: extmem_ctrl -- controller reset / calibration /
// fault sequencing
//
//            bridge reset
//                 |
//                 v
//   +-------> RESET  (mc_rst_n = 0 for RST_HOLD cycles)
//   |             |
//   |             v
//   |          CAL   (mc_rst_n = 1, wait mc_init_done)  --timeout--> CALFAIL
//   |             |                                                 (parked,
//   |             v                                                  reset req
//   |  +----->  READY  <- normal operation                           -> RESET)
//   |  |          |  \
//   |  |   reset  |   \ fault: !mc_init_done | mc_fatal | response watchdog
//   |  |   request|    \
//   |  |          v     v
//   |  |     QUIESCE --fault--> FAULT (flush: every incomplete transaction is
//   |  |   (no new requests;     completed with an error; mc_rst_n = 0 from
//   |  |    drain in-flight)     the next edge so no late response can arrive)
//   |  |          | idle             | AUTO_RECOVER or reset request
//   +--+----------+------------------+
//
// accept_ok : new upstream transactions may target the controller (READY and
//             no fault this cycle).  Otherwise the frontend answers UNAVAIL
//             (or stalls, UNAVAIL_POLICY = 1).
// issue_en  : the scheduler may issue commands (READY / QUIESCE).
// rsp_en    : controller responses are processed (READY / QUIESCE, no flush).
// The bridge never claims calibration success: READY only follows the
// controller's own mc_init_done.
// =============================================================================
`include "extmem_defs.svh"
`default_nettype none

module extmem_ctrl #(
  parameter int RST_HOLD     = 16,
  parameter int CAL_TIMEOUT  = 0,       // cycles; 0 = wait forever
  parameter int RESP_TIMEOUT = 0,       // cycles without controller progress while busy; 0 = off
  parameter int AUTO_RECOVER = 1
) (
  input  wire logic       clk,
  input  wire logic       rst_n,
  input  wire logic       mc_init_done,     // fabric-clock domain (synchronised if async)
  input  wire logic       mc_fatal,
  input  wire logic       ctl_reset_req,    // request a (quiesced) controller reset
  input  wire logic       ctl_clr_sticky,
  input  wire logic       any_inflight,     // commands issued and not complete
  input  wire logic       mc_progress,      // a controller response was taken this cycle
  input  wire logic       idle,             // nothing queued, issued or arriving
  output logic            mc_rst_n,
  output logic [2:0]      state,
  output logic            flush,
  output logic            accept_ok,
  output logic            issue_en,
  output logic            rsp_en,
  output logic            st_ready,
  output logic            st_cal_fail,
  output logic            st_fault_seen,
  output logic            ev_fault
);
  logic [2:0]  st_q;
  logic [31:0] cnt_q, wd_q;
  logic        mrst_q, fseen_q;

  wire active     = (st_q == `XM_ST_READY) || (st_q == `XM_ST_QUIESCE);
  wire wdog_hit   = (RESP_TIMEOUT != 0) && (wd_q >= 32'(RESP_TIMEOUT));
  wire fault_cond = !mc_init_done || mc_fatal || wdog_hit;

  assign flush     = active && fault_cond;
  assign accept_ok = (st_q == `XM_ST_READY) && !fault_cond;
  assign issue_en  = active;
  assign rsp_en    = active && !fault_cond;
  assign mc_rst_n  = mrst_q;
  assign state     = st_q;
  assign st_ready      = (st_q == `XM_ST_READY);
  assign st_cal_fail   = (st_q == `XM_ST_CALFAIL);
  assign st_fault_seen = fseen_q;
  assign ev_fault      = flush;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q    <= `XM_ST_RESET;
      cnt_q   <= '0;
      wd_q    <= '0;
      mrst_q  <= 1'b0;
      fseen_q <= 1'b0;
    end else begin
      // -------------------------------------------------- response watchdog
      if (!active || !any_inflight || mc_progress) wd_q <= '0;
      else if (!wdog_hit)                          wd_q <= wd_q + 32'd1;
      if (ctl_clr_sticky) fseen_q <= 1'b0;

      case (st_q)
        `XM_ST_RESET: begin
          mrst_q <= 1'b0;
          if (cnt_q >= 32'(RST_HOLD - 1)) begin
            st_q   <= `XM_ST_CAL;
            cnt_q  <= '0;
            mrst_q <= 1'b1;
          end else begin
            cnt_q <= cnt_q + 32'd1;
          end
        end
        `XM_ST_CAL: begin
          if (ctl_reset_req) begin
            st_q   <= `XM_ST_RESET;
            cnt_q  <= '0;
            mrst_q <= 1'b0;
          end else if (mc_init_done && !mc_fatal) begin
            st_q  <= `XM_ST_READY;
            cnt_q <= '0;
          end else if (CAL_TIMEOUT != 0 && cnt_q >= 32'(CAL_TIMEOUT)) begin
            st_q   <= `XM_ST_CALFAIL;
            mrst_q <= 1'b0;                // park the controller
          end else begin
            cnt_q <= cnt_q + 32'd1;
          end
        end
        `XM_ST_READY: begin
          if (fault_cond) begin
            st_q    <= `XM_ST_FAULT;
            mrst_q  <= 1'b0;
            fseen_q <= 1'b1;
          end else if (ctl_reset_req) begin
            st_q <= `XM_ST_QUIESCE;
          end
        end
        `XM_ST_QUIESCE: begin
          if (fault_cond) begin
            st_q    <= `XM_ST_FAULT;
            mrst_q  <= 1'b0;
            fseen_q <= 1'b1;
          end else if (idle) begin
            st_q   <= `XM_ST_RESET;
            cnt_q  <= '0;
            mrst_q <= 1'b0;
          end
        end
        `XM_ST_FAULT: begin
          mrst_q <= 1'b0;
          if (AUTO_RECOVER != 0 || ctl_reset_req) begin
            st_q  <= `XM_ST_RESET;
            cnt_q <= '0;
          end
        end
        `XM_ST_CALFAIL: begin
          mrst_q <= 1'b0;
          if (ctl_reset_req) begin
            st_q  <= `XM_ST_RESET;
            cnt_q <= '0;
          end
        end
        default: begin
          st_q   <= `XM_ST_RESET;
          cnt_q  <= '0;
          mrst_q <= 1'b0;
        end
      endcase
    end
  end
endmodule

`default_nettype wire
