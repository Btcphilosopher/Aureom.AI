// =============================================================================
// SilicaFlux MemoryBridge :: extmem_rob -- response ordering buffer
//
// One entry per accepted upstream transaction, kept in acceptance order
// (index 0 = oldest; collapsing array: an entry can retire from any position).
// The entry records the transaction's ID, length, slot (or a local error) and
// is the single place where a response is generated, so every accepted
// transaction produces exactly one response (len+1 beats for a read, one beat
// for a write) and is then removed: no lost and no duplicate completions.
//
// Selection of the next transaction to answer:
//   UP_OOO = 0  (SFB2 R5, default): strictly the oldest entry.
//   UP_OOO = 1  (SFB2-X with IDs): the oldest entry that is ready and has no
//               older entry with the same ID (per-ID order kept, different
//               IDs may complete out of order -- only enable when the upstream
//               master is able to accept that).
// A read response may start as soon as its first beat is in the read buffer
// (cut-through) and then owns the response channel until its last beat (beats
// of different transactions are never interleaved upstream).  If the slot was
// flushed, the beats not yet received are returned with rsp_error = 1.
//
// Output: one registered response stage (rsp_valid does not depend on
// rsp_ready, payload held stable under back-pressure -- SFB2 R4), one beat per
// cycle.  rsp_rdata = 0 on error beats and write responses (SFB2 R8).
// =============================================================================
`include "extmem_defs.svh"
`default_nettype none

module extmem_rob #(
  parameter int  AW     = 32,
  parameter int  DW     = 64,
  parameter int  IDW    = 4,
  parameter int  LW     = 8,
  parameter int  MB     = 16,
  parameter int  NR     = 8,
  parameter int  NW     = 8,
  parameter int  TW     = 3,
  parameter int  NROB   = 18,
  parameter int  UP_OOO = 0,
  parameter int  TSW    = 16,
  localparam int BW     = (MB > 1) ? $clog2(MB) : 1,
  localparam int RTW    = (NR > 1) ? $clog2(NR) : 1,
  localparam int WTW    = (NW > 1) ? $clog2(NW) : 1,
  localparam int RBA    = (NR * MB > 1) ? $clog2(NR * MB) : 1,
  localparam int QW     = $clog2(NROB + 1),
  localparam int XW     = (NROB > 1) ? $clog2(NROB) : 1
) (
  input  wire logic               clk,
  input  wire logic               rst_n,
  input  wire logic [TSW-1:0]     ts_now,
  // ---------------------------------------------------------------- push (frontend)
  input  wire logic               push,
  input  wire logic               p_is_wr,
  input  wire logic [IDW-1:0]     p_id,
  input  wire logic [LW-1:0]      p_len,
  input  wire logic [TW-1:0]      p_slot,
  input  wire logic               p_lerr,
  input  wire logic [3:0]         p_code,
  input  wire logic [AW-1:0]      p_addr,
  output logic                    space,
  output logic [QW-1:0]           count,
  // ---------------------------------------------------------------- slot state (tracker)
  input  wire logic [NR*(BW+1)-1:0] rcnt_flat,
  input  wire logic [NR-1:0]      rflush,
  input  wire logic [NW-1:0]      wdone,
  input  wire logic [NW-1:0]      werr,
  input  wire logic [NW-1:0]      wflush,
  // ---------------------------------------------------------------- read buffer
  output logic [RBA-1:0]          rbuf_raddr,
  input  wire logic [DW:0]        rbuf_rdata,     // {err, data}
  // ---------------------------------------------------------------- retire (tracker)
  output logic                    rd_retire,
  output logic [RTW-1:0]          rd_retire_idx,
  output logic                    wr_retire,
  output logic [WTW-1:0]          wr_retire_idx,
  // ---------------------------------------------------------------- SFB2-X response channel
  output logic                    up_rsp_valid,
  input  wire logic               up_rsp_ready,
  output logic [DW-1:0]           up_rsp_rdata,
  output logic                    up_rsp_error,
  output logic [IDW-1:0]          up_rsp_id,
  output logic                    up_rsp_last,
  output logic                    up_rsp_write,
  // ---------------------------------------------------------------- error capture / perf
  output logic                    err_evt,
  output logic [3:0]              err_code,
  output logic [AW-1:0]           err_addr,
  output logic [IDW-1:0]          err_id,
  output logic                    err_write,
  output logic                    ev_rd_done,
  output logic                    ev_wr_done,
  output logic [TSW-1:0]          ev_lat,
  output logic                    ev_rd_beat_ok
);
  // ------------------------------------------------------------ entry storage
  // One packed word per entry, held in a per-entry register (generate block below);
  // the field arrays are combinational views of it.  Entries are valid-qualified by
  // cnt_q (datapath storage, no reset -- RTL rule 4).
  localparam int EW = 1 + IDW + LW + TW + 1 + 4 + AW + TSW;
  logic           e_wr   [NROB];
  logic [IDW-1:0] e_id   [NROB];
  logic [LW-1:0]  e_len  [NROB];
  logic [TW-1:0]  e_slot [NROB];
  logic           e_lerr [NROB];
  logic [3:0]     e_code [NROB];
  logic [AW-1:0]  e_addr [NROB];
  logic [TSW-1:0] e_ts   [NROB];
  logic [NROB*EW-1:0] ent_flat;
  logic [QW-1:0]  cnt_q;
  always_comb begin
    for (int k = 0; k < NROB; k++) begin
      {e_wr[k], e_id[k], e_len[k], e_slot[k], e_lerr[k], e_code[k], e_addr[k], e_ts[k]} = ent_flat[k*EW +: EW];
    end
  end

  logic           lock_q;
  logic [XW-1:0]  lock_idx_q;
  logic [LW-1:0]  ob_q;
  logic           terr_q;

  assign space = (cnt_q < QW'(NROB));
  assign count = cnt_q;

  function automatic logic [BW:0] rcnt_of(input logic [RTW-1:0] s, input logic [NR*(BW+1)-1:0] f);
    rcnt_of = f[s*(BW+1) +: (BW+1)];
  endfunction

  // ------------------------------------------------------------ readiness and selection
  logic [NROB-1:0] rdy, cand;
  logic            sel_any;
  logic [XW-1:0]   sel_idx;
  always_comb begin
    for (int k = 0; k < NROB; k++) begin
      rdy[k] = (QW'(k) < cnt_q) &&
               (e_lerr[k] ||
                (e_wr[k] ? wdone[e_slot[k][WTW-1:0]]
                         : (rcnt_of(e_slot[k][RTW-1:0], rcnt_flat) != '0 || rflush[e_slot[k][RTW-1:0]])));
    end
    for (int k = 0; k < NROB; k++) begin
      cand[k] = rdy[k];
      if (UP_OOO == 0) begin
        if (k != 0) cand[k] = 1'b0;
      end else begin
        for (int j = 0; j < k; j++) begin
          if (QW'(j) < cnt_q && e_id[j] == e_id[k]) cand[k] = 1'b0;
        end
      end
    end
    sel_any = 1'b0;
    sel_idx = '0;
    for (int k = NROB - 1; k >= 0; k--) begin
      if (cand[k]) begin
        sel_any = 1'b1;
        sel_idx = XW'(k);
      end
    end
  end

  wire [XW-1:0]  cur      = lock_q ? lock_idx_q : sel_idx;
  wire           cur_v    = lock_q || sel_any;
  wire [LW-1:0]  beat     = lock_q ? ob_q : '0;
  wire           c_wr     = e_wr[cur];
  wire           c_lerr   = e_lerr[cur];
  wire [TW-1:0]  c_slot   = e_slot[cur];
  wire [BW:0]    c_rcnt   = rcnt_of(c_slot[RTW-1:0], rcnt_flat);
  wire           c_rfl    = rflush[c_slot[RTW-1:0]];
  wire           c_inbuf  = (32'(c_rcnt) > 32'(beat));

  assign rbuf_raddr = RBA'(c_slot[RTW-1:0]) * RBA'(MB) + RBA'(beat[BW-1:0]);

  logic          avail, b_err, b_last;
  logic [DW-1:0] b_data;
  logic [3:0]    b_code;
  always_comb begin
    avail  = 1'b0;
    b_err  = 1'b0;
    b_data = '0;
    b_last = 1'b1;
    b_code = `XM_ERR_NONE;
    if (c_lerr) begin
      avail  = 1'b1;
      b_err  = 1'b1;
      b_last = c_wr || (beat == e_len[cur]);
      b_code = e_code[cur];
    end else if (c_wr) begin
      avail  = wdone[c_slot[WTW-1:0]];
      b_err  = werr[c_slot[WTW-1:0]];
      b_code = wflush[c_slot[WTW-1:0]] ? `XM_ERR_FLUSH : `XM_ERR_MC_WR;
    end else begin
      b_last = (beat == e_len[cur]);
      b_code = c_rfl ? `XM_ERR_FLUSH : `XM_ERR_MC_RD;
      if (c_inbuf) begin
        avail  = 1'b1;
        b_err  = rbuf_rdata[DW];
        b_data = rbuf_rdata[DW-1:0];                 // zeroed in the output register if b_err
      end else if (c_rfl) begin
        avail  = 1'b1;
        b_err  = 1'b1;
        b_code = `XM_ERR_FLUSH;
      end
    end
  end

  // ------------------------------------------------------------ output register
  logic           rv_q, re_q, rl_q, rw_q;
  logic [DW-1:0]  rd_q;
  logic [IDW-1:0] ri_q;
  logic [TSW-1:0] rts_q;

  wire load   = cur_v && avail && (!rv_q || up_rsp_ready);
  wire ret    = load && b_last;
  wire rsp_hs = rv_q && up_rsp_ready;

  assign up_rsp_valid = rv_q;
  assign up_rsp_rdata = rd_q;
  assign up_rsp_error = re_q;
  assign up_rsp_id    = ri_q;
  assign up_rsp_last  = rl_q;
  assign up_rsp_write = rw_q;

  assign rd_retire     = ret && !c_lerr && !c_wr;
  assign rd_retire_idx = c_slot[RTW-1:0];
  assign wr_retire     = ret && !c_lerr && c_wr;
  assign wr_retire_idx = c_slot[WTW-1:0];

  assign err_evt   = ret && (terr_q || b_err);
  assign err_code  = (b_err || c_lerr) ? b_code : (c_rfl ? `XM_ERR_FLUSH : `XM_ERR_MC_RD);
  assign err_addr  = e_addr[cur];
  assign err_id    = e_id[cur];
  assign err_write = c_wr;

  assign ev_rd_done    = rsp_hs && rl_q && !rw_q;
  assign ev_wr_done    = rsp_hs && rw_q;
  assign ev_lat        = ts_now - rts_q;
  assign ev_rd_beat_ok = rsp_hs && !rw_q && !re_q;

  // ------------------------------------------------------------ sequential
  wire [QW-1:0] cnt_ret = cnt_q - QW'(ret);
  wire [XW-1:0] pidx    = XW'(cnt_ret);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cnt_q      <= '0;
      lock_q     <= 1'b0;
      lock_idx_q <= '0;
      ob_q       <= '0;
      terr_q     <= 1'b0;
      rv_q       <= 1'b0;
      re_q       <= 1'b0;
      rl_q       <= 1'b0;
      rw_q       <= 1'b0;
      rd_q       <= '0;
      ri_q       <= '0;
      rts_q      <= '0;
    end else begin
      // -------------------------------------------------- response register
      if (load) begin
        rv_q  <= 1'b1;
        re_q  <= b_err;
        rd_q  <= (b_err || c_wr) ? '0 : b_data;
        rl_q  <= b_last;
        rw_q  <= c_wr;
        ri_q  <= e_id[cur];
        rts_q <= e_ts[cur];
      end else if (rsp_hs) begin
        rv_q <= 1'b0;
      end
      if (load) begin
        if (b_last) begin
          lock_q <= 1'b0;
          ob_q   <= '0;
          terr_q <= 1'b0;
        end else begin
          lock_q     <= 1'b1;
          lock_idx_q <= cur;
          ob_q       <= beat + LW'(1);
          terr_q     <= terr_q || b_err;
        end
      end
      cnt_q <= cnt_ret + QW'(push);
    end
  end

  // ------------------------------------------------------------ entries: collapse (retire) then append (push)
  // entry i takes entry i+1 when an entry at or below i retires; the pushed entry
  // lands at cnt_ret (push has priority).  Push happens only when space: cnt_ret < NROB.
  wire [EW-1:0] p_ent = {p_is_wr, p_id, p_len, p_slot, p_lerr, p_code, p_addr, ts_now};
  genvar gi;
  for (gi = 0; gi < NROB; gi++) begin : g_ent
    logic [EW-1:0] q;
    logic [EW-1:0] nxt;
    if (gi + 1 < NROB) begin : g_mid
      assign nxt = ent_flat[(gi+1)*EW +: EW];
    end else begin : g_top
      assign nxt = q;
    end
    /* verilator lint_off CMPCONST */          // top entry of a power-of-two ROB: gi >= cur always
    always_ff @(posedge clk) begin
      if (push && pidx == XW'(gi))      q <= p_ent;
      else if (ret && XW'(gi) >= cur)   q <= nxt;
    end
    /* verilator lint_on CMPCONST */
    assign ent_flat[gi*EW +: EW] = q;
  end
endmodule

`default_nettype wire
