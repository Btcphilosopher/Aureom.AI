// =============================================================================
// SilicaFlux MemoryBridge :: extmem_tracker -- outstanding-transaction slots
//
// A slot is the bridge's ownership record of one transaction that touches the
// controller.  Read slot r owns read-buffer beats [r*MB, r*MB+MB) and MC read
// tag r; write slot w owns write-buffer beats [w*MB, w*MB+MB) and MC write tag
// w.  Read and write tags are separate name spaces (separate MC channels).
//
// Life cycle (read):  alloc -> issue (cmd accepted by MC) -> beats received
//                     (rcnt) -> complete (rcnt == len+1, or rflush) -> retire
// Life cycle (write): alloc -> [data in buffer] -> issue -> data sent
//                     (wdat) -> response (wdone, werr) -> retire
//   * a slot is reused only after the ROB has delivered its response upstream
//     (retire) -> a tag is never live twice: no response misassociation;
//   * buffer space is owned per slot -> no buffer overflow by construction;
//   * a controller response is accepted only for a tag in the right phase
//     (issued, not complete, write data fully sent); anything else is dropped
//     and flagged (ev_mc_proto) -> no duplicate completion;
//   * flush (controller fault) completes every incomplete slot with an error;
//     the controller is held in reset from the next edge, so no late response
//     can arrive.  Response processing is disabled in the flush cycle.
//   * early mc_rd_last (fewer beats than requested) completes the slot as
//     flushed (remaining beats -> error); a missing mc_rd_last on the final
//     beat marks that beat as an error.  Both raise ev_mc_proto.
// =============================================================================
`default_nettype none

module extmem_tracker #(
  parameter int  NR  = 8,
  parameter int  NW  = 8,
  parameter int  MB  = 16,
  parameter int  TW  = 3,
  localparam int BW  = (MB > 1) ? $clog2(MB) : 1,
  localparam int RTW = (NR > 1) ? $clog2(NR) : 1,
  localparam int WTW = (NW > 1) ? $clog2(NW) : 1,
  localparam int RBA = (NR * MB > 1) ? $clog2(NR * MB) : 1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              flush,
  input  wire logic              rsp_en,        // process controller responses (link READY/QUIESCE, no flush)
  // ---------------------------------------------------------------- allocation / release
  input  wire logic              rd_alloc,
  input  wire logic [RTW-1:0]    rd_alloc_idx,
  input  wire logic [BW-1:0]     rd_alloc_len,
  input  wire logic              wr_alloc,
  input  wire logic [WTW-1:0]    wr_alloc_idx,
  input  wire logic              wr_release,
  input  wire logic [WTW-1:0]    wr_release_idx,
  input  wire logic              rd_retire,
  input  wire logic [RTW-1:0]    rd_retire_idx,
  input  wire logic              wr_retire,
  input  wire logic [WTW-1:0]    wr_retire_idx,
  // ---------------------------------------------------------------- issue progress (scheduler)
  input  wire logic              rd_issue,
  input  wire logic [RTW-1:0]    rd_issue_idx,
  input  wire logic              wr_issue,
  input  wire logic [WTW-1:0]    wr_issue_idx,
  input  wire logic              wd_done,
  input  wire logic [WTW-1:0]    wd_done_idx,
  // ---------------------------------------------------------------- controller responses
  input  wire logic              mc_rd_valid,
  input  wire logic [TW-1:0]     mc_rd_tag,
  input  wire logic              mc_rd_last,
  input  wire logic              mc_rd_error,
  input  wire logic              mc_wr_valid,
  input  wire logic [TW-1:0]     mc_wr_tag,
  input  wire logic              mc_wr_error,
  // ---------------------------------------------------------------- read buffer write port
  output logic                   rbuf_we,
  output logic [RBA-1:0]         rbuf_waddr,
  output logic                   rbuf_werr,
  // ---------------------------------------------------------------- slot state (to frontend / ROB)
  output logic                   rd_free_any,
  output logic [RTW-1:0]         rd_free_idx,
  output logic                   wr_free_any,
  output logic [WTW-1:0]         wr_free_idx,
  output logic [NR*(BW+1)-1:0]   rcnt_flat,
  output logic [NR-1:0]          rflush_o,
  output logic [NW-1:0]          wdone_o,
  output logic [NW-1:0]          werr_o,
  output logic [NW-1:0]          wflush_o,
  output logic                   any_inflight,
  output logic [RTW:0]           rd_busy_cnt,
  output logic [WTW:0]           wr_busy_cnt,
  output logic                   ev_mc_proto
);
  logic [NR-1:0] rbusy, riss, rflush;
  logic [BW-1:0] rlen [NR];
  logic [BW:0]   rcnt [NR];
  logic [NW-1:0] wbusy, wiss, wdat, wdone, werr, wflush;

  // ------------------------------------------------------------ completion / free search
  logic [NR-1:0] rcomp;
  always_comb begin
    for (int r = 0; r < NR; r++) begin
      rcomp[r] = rflush[r] || (rcnt[r] == {1'b0, rlen[r]} + {{BW{1'b0}}, 1'b1});
    end
  end

  always_comb begin
    rd_free_any = 1'b0;
    rd_free_idx = '0;
    for (int r = NR - 1; r >= 0; r--) begin
      if (!rbusy[r]) begin
        rd_free_any = 1'b1;
        rd_free_idx = RTW'(r);
      end
    end
    wr_free_any = 1'b0;
    wr_free_idx = '0;
    for (int w = NW - 1; w >= 0; w--) begin
      if (!wbusy[w]) begin
        wr_free_any = 1'b1;
        wr_free_idx = WTW'(w);
      end
    end
  end

  always_comb begin
    rd_busy_cnt = '0;
    wr_busy_cnt = '0;
    for (int r = 0; r < NR; r++) rd_busy_cnt = rd_busy_cnt + (RTW+1)'(rbusy[r]);
    for (int w = 0; w < NW; w++) wr_busy_cnt = wr_busy_cnt + (WTW+1)'(wbusy[w]);
  end

  assign any_inflight = |(riss & ~rcomp) || |(wiss & ~wdone);

  // ------------------------------------------------------------ response legality
  wire [RTW-1:0] rt = mc_rd_tag[RTW-1:0];
  wire [WTW-1:0] wt = mc_wr_tag[WTW-1:0];
  wire rt_hi_ok = (TW == RTW) ? 1'b1 : (mc_rd_tag >> RTW) == '0;
  wire wt_hi_ok = (TW == WTW) ? 1'b1 : (mc_wr_tag >> WTW) == '0;
  wire rt_rng   = rt_hi_ok && ({1'b0, rt} < (RTW+1)'(NR));
  wire wt_rng   = wt_hi_ok && ({1'b0, wt} < (WTW+1)'(NW));
  wire rd_legal = rt_rng && rbusy[rt] && riss[rt] && !rcomp[rt];
  wire wr_legal = wt_rng && wbusy[wt] && wiss[wt] && wdat[wt] && !wdone[wt];
  wire rd_take  = rsp_en && mc_rd_valid && rd_legal;
  wire wr_take  = rsp_en && mc_wr_valid && wr_legal;
  wire rd_final = rd_legal && (rcnt[rt] == {1'b0, rlen[rt]});
  wire rd_early = rd_take && mc_rd_last && !rd_final;
  wire rd_nolast = rd_take && rd_final && !mc_rd_last;

  assign ev_mc_proto = (rsp_en && mc_rd_valid && !rd_legal) || (rsp_en && mc_wr_valid && !wr_legal) ||
                       rd_early || rd_nolast;

  assign rbuf_we    = rd_take;
  assign rbuf_waddr = RBA'(rt) * RBA'(MB) + RBA'(rcnt[rt][BW-1:0]);
  assign rbuf_werr  = mc_rd_error || !mc_rd_last && rd_final;

  // ------------------------------------------------------------ slot state
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rbusy  <= '0;
      riss   <= '0;
      rflush <= '0;
      wbusy  <= '0;
      wiss   <= '0;
      wdat   <= '0;
      wdone  <= '0;
      werr   <= '0;
      wflush <= '0;
      // rlen / rcnt are datapath: (re)initialised at allocation, read only for busy slots
    end else begin
      // -------------------------------------------------- reads
      if (rd_take) begin
        rcnt[rt] <= rcnt[rt] + {{BW{1'b0}}, 1'b1};
        if (rd_early) rflush[rt] <= 1'b1;
      end
      if (rd_issue) riss[rd_issue_idx] <= 1'b1;
      if (flush) begin
        for (int r = 0; r < NR; r++) begin
          if (rbusy[r] && !rcomp[r]) rflush[r] <= 1'b1;
        end
      end
      if (rd_alloc) begin
        rbusy[rd_alloc_idx]  <= 1'b1;
        riss[rd_alloc_idx]   <= 1'b0;
        rflush[rd_alloc_idx] <= 1'b0;
        rlen[rd_alloc_idx]   <= rd_alloc_len;
        rcnt[rd_alloc_idx]   <= '0;
      end
      if (rd_retire) begin
        rbusy[rd_retire_idx]  <= 1'b0;
        riss[rd_retire_idx]   <= 1'b0;
        rflush[rd_retire_idx] <= 1'b0;
        rcnt[rd_retire_idx]   <= '0;
      end
      // -------------------------------------------------- writes
      if (wr_take) begin
        wdone[wt] <= 1'b1;
        werr[wt]  <= mc_wr_error;
      end
      if (wr_issue)   wiss[wr_issue_idx] <= 1'b1;
      if (wd_done)    wdat[wd_done_idx]  <= 1'b1;
      if (flush) begin
        for (int w = 0; w < NW; w++) begin
          if (wbusy[w] && !wdone[w]) begin
            wdone[w]  <= 1'b1;
            werr[w]   <= 1'b1;
            wflush[w] <= 1'b1;
          end
        end
      end
      if (wr_alloc) begin
        wbusy[wr_alloc_idx]  <= 1'b1;
        wiss[wr_alloc_idx]   <= 1'b0;
        wdat[wr_alloc_idx]   <= 1'b0;
        wdone[wr_alloc_idx]  <= 1'b0;
        werr[wr_alloc_idx]   <= 1'b0;
        wflush[wr_alloc_idx] <= 1'b0;
      end
      if (wr_release) begin
        wbusy[wr_release_idx]  <= 1'b0;
        wiss[wr_release_idx]   <= 1'b0;
        wdat[wr_release_idx]   <= 1'b0;
        wdone[wr_release_idx]  <= 1'b0;
        werr[wr_release_idx]   <= 1'b0;
        wflush[wr_release_idx] <= 1'b0;
      end
      if (wr_retire) begin
        wbusy[wr_retire_idx]  <= 1'b0;
        wiss[wr_retire_idx]   <= 1'b0;
        wdat[wr_retire_idx]   <= 1'b0;
        wdone[wr_retire_idx]  <= 1'b0;
        werr[wr_retire_idx]   <= 1'b0;
        wflush[wr_retire_idx] <= 1'b0;
      end
    end
  end

  // ------------------------------------------------------------ outputs
  always_comb begin
    for (int r = 0; r < NR; r++) rcnt_flat[r*(BW+1) +: (BW+1)] = rcnt[r];
  end
  assign rflush_o = rflush;
  assign wdone_o  = wdone;
  assign werr_o   = werr;
  assign wflush_o = wflush;
endmodule

`default_nettype wire
