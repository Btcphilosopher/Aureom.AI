// =============================================================================
// SilicaFlux MemoryBridge (Project 24) :: silicaflux_extmem_bridge
// Aureom.AI / SilicaFlux-HPC -- external DDR (and future HBM) memory bridge
//
//   DataFabric (SFB2 / SFB2-X, fabric clock `clk`)
//     -> extmem_core: request decode + checks, outstanding-transaction slots,
//        FIFO / read-priority scheduler, write/read buffers, response ROB,
//        controller reset / calibration / fault sequencing, perf counters, CSR
//     -> [ASYNC = 1: extmem_mc_cdc, async FIFOs to the controller clock]
//     -> generic memory-controller interface (SFMC, docs/MC_INTERFACE.md)
//     -> controller adapter (replaceable; NOT part of this module)
//     -> vendor / licensed DDR or HBM controller + PHY -> external DRAM
//
// What this module is NOT: a DRAM controller or PHY.  It contains no DRAM
// timing, refresh, training or PHY logic and makes no claim about calibration
// or row-buffer behaviour; those belong to the (vendor) controller behind the
// adapter.  In this release the only controller it has been connected to is
// the explicitly simulated model sim/models/extmem_sim_mc.sv.
//
// Clocking:
//   ASYNC = 0  single clock: the MC interface runs on `clk` (mc_clk unused).
//   ASYNC = 1  the MC interface ports (mc_*) are in the `mc_clk` domain and
//              mc_rst_n is synchronised to mc_clk.
//
// Upstream compatibility: with up_req_len = 0, up_req_last = 1 and
// up_req_id = 0 the upstream port is a plain SFB2 rev 2.0 slave and can be
// attached to a DataFabric sfb_crossbar slave port (verified with the
// unmodified DataFabric crossbar, DMA engine and protocol checker).
// =============================================================================
`include "extmem_defs.svh"
`default_nettype none

module silicaflux_extmem_bridge #(
  parameter int             AW             = 32,
  parameter int             DW             = 64,
  parameter int             IDW            = 4,
  parameter int             LW             = 8,
  parameter int             MAX_BURST      = 16,
  parameter int             MAX_RD_OUT     = 8,
  parameter int             MAX_WR_OUT     = 8,
  parameter int             ROB_DEPTH      = 0,
  parameter int             MC_AW          = 28,
  parameter logic [AW-1:0]  EXT_BASE       = 32'h8000_0000,
  parameter logic [AW:0]    EXT_SIZE       = 33'h0_1000_0000,
  parameter int             BOUND_LOG2     = 12,
  parameter int             UP_OOO         = 0,
  parameter int             SCHED_MODE     = 0,
  parameter int             WR_HI          = 6,
  parameter int             WR_LO          = 2,
  parameter int             AGE_CAP        = 16,
  parameter int             UNAVAIL_POLICY = 0,
  parameter int             RST_HOLD       = 16,
  parameter int             CAL_TIMEOUT    = 0,
  parameter int             RESP_TIMEOUT   = 0,
  parameter int             AUTO_RECOVER   = 1,
  parameter int             PERF           = 1,
  parameter int             ASYNC          = 0,
  parameter int             CDC_DEPTH      = 8,
  parameter int             CDC_SYNC       = 2,
  localparam int            SB             = DW / 8,
  localparam int            RTW            = (MAX_RD_OUT > 1) ? $clog2(MAX_RD_OUT) : 1,
  localparam int            WTW            = (MAX_WR_OUT > 1) ? $clog2(MAX_WR_OUT) : 1,
  localparam int            TW             = (RTW > WTW) ? RTW : WTW,
  localparam int            CW             = 32
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  input  wire logic                    mc_clk,          // used only when ASYNC = 1
  // ---------------------------------------------------------------- SFB2-X upstream port
  input  wire logic                    up_req_valid,
  output logic                         up_req_ready,
  input  wire logic                    up_req_write,
  input  wire logic [AW-1:0]           up_req_addr,
  input  wire logic [DW-1:0]           up_req_wdata,
  input  wire logic [SB-1:0]           up_req_wstrb,
  input  wire logic [IDW-1:0]          up_req_id,
  input  wire logic [LW-1:0]           up_req_len,
  input  wire logic                    up_req_last,
  output logic                         up_rsp_valid,
  input  wire logic                    up_rsp_ready,
  output logic [DW-1:0]                up_rsp_rdata,
  output logic                         up_rsp_error,
  output logic [IDW-1:0]               up_rsp_id,
  output logic                         up_rsp_last,
  output logic                         up_rsp_write,
  // ---------------------------------------------------------------- SFB2 CSR port
  input  wire logic                    csr_req_valid,
  output logic                         csr_req_ready,
  input  wire logic                    csr_req_write,
  input  wire logic [31:0]             csr_req_addr,
  input  wire logic [31:0]             csr_req_wdata,
  input  wire logic [3:0]              csr_req_wstrb,
  output logic                         csr_rsp_valid,
  input  wire logic                    csr_rsp_ready,
  output logic [31:0]                  csr_rsp_rdata,
  output logic                         csr_rsp_error,
  // ---------------------------------------------------------------- generic MC interface (clk or mc_clk)
  output logic                         mc_rst_n,
  input  wire logic                    mc_init_done,
  input  wire logic                    mc_fatal,
  output logic                         mc_cmd_valid,
  input  wire logic                    mc_cmd_ready,
  output logic                         mc_cmd_write,
  output logic [MC_AW-1:0]             mc_cmd_addr,
  output logic [LW-1:0]                mc_cmd_len,
  output logic [TW-1:0]                mc_cmd_tag,
  output logic                         mc_wd_valid,
  input  wire logic                    mc_wd_ready,
  output logic [DW-1:0]                mc_wd_data,
  output logic [SB-1:0]                mc_wd_strb,
  output logic                         mc_wd_last,
  input  wire logic                    mc_rd_valid,
  output logic                         mc_rd_ready,
  input  wire logic [DW-1:0]           mc_rd_data,
  input  wire logic [TW-1:0]           mc_rd_tag,
  input  wire logic                    mc_rd_last,
  input  wire logic                    mc_rd_error,
  input  wire logic                    mc_wr_valid,
  output logic                         mc_wr_ready,
  input  wire logic [TW-1:0]           mc_wr_tag,
  input  wire logic                    mc_wr_error,
  // ---------------------------------------------------------------- sideband (clk domain)
  input  wire logic                    ctl_mc_reset_req,
  output logic [2:0]                   st_state,
  output logic                         st_ready,
  output logic                         st_cal_fail,
  output logic                         st_fault_seen,
  output logic                         st_idle,
  output logic                         err_evt,
  output logic [3:0]                   err_code,
  output logic [AW-1:0]                err_addr,
  output logic [IDW-1:0]               err_id,
  output logic                         err_write,
  output logic [`XM_PERF_N*CW-1:0]     perf_cnt
);
  // core-side (fabric clock) MC interface
  logic             c_rst_n, c_init_done, c_fatal;
  logic             c_cmd_valid, c_cmd_ready, c_cmd_write;
  logic [MC_AW-1:0] c_cmd_addr;
  logic [LW-1:0]    c_cmd_len;
  logic [TW-1:0]    c_cmd_tag;
  logic             c_wd_valid, c_wd_ready, c_wd_last;
  logic [DW-1:0]    c_wd_data;
  logic [SB-1:0]    c_wd_strb;
  logic             c_rd_valid, c_rd_ready, c_rd_last, c_rd_error;
  logic [DW-1:0]    c_rd_data;
  logic [TW-1:0]    c_rd_tag;
  logic             c_wr_valid, c_wr_ready, c_wr_error;
  logic [TW-1:0]    c_wr_tag;

  extmem_core #(
    .AW(AW), .DW(DW), .IDW(IDW), .LW(LW), .MAX_BURST(MAX_BURST), .MAX_RD_OUT(MAX_RD_OUT),
    .MAX_WR_OUT(MAX_WR_OUT), .ROB_DEPTH(ROB_DEPTH), .MC_AW(MC_AW), .EXT_BASE(EXT_BASE),
    .EXT_SIZE(EXT_SIZE), .BOUND_LOG2(BOUND_LOG2), .UP_OOO(UP_OOO), .SCHED_MODE(SCHED_MODE),
    .WR_HI(WR_HI), .WR_LO(WR_LO), .AGE_CAP(AGE_CAP), .UNAVAIL_POLICY(UNAVAIL_POLICY),
    .RST_HOLD(RST_HOLD), .CAL_TIMEOUT(CAL_TIMEOUT), .RESP_TIMEOUT(RESP_TIMEOUT),
    .AUTO_RECOVER(AUTO_RECOVER), .PERF(PERF), .ASYNC_INFO(ASYNC)
  ) u_core (
    .clk, .rst_n,
    .up_req_valid, .up_req_ready, .up_req_write, .up_req_addr, .up_req_wdata, .up_req_wstrb,
    .up_req_id, .up_req_len, .up_req_last,
    .up_rsp_valid, .up_rsp_ready, .up_rsp_rdata, .up_rsp_error, .up_rsp_id, .up_rsp_last, .up_rsp_write,
    .csr_req_valid, .csr_req_ready, .csr_req_write, .csr_req_addr, .csr_req_wdata, .csr_req_wstrb,
    .csr_rsp_valid, .csr_rsp_ready, .csr_rsp_rdata, .csr_rsp_error,
    .mc_rst_n(c_rst_n), .mc_init_done(c_init_done), .mc_fatal(c_fatal),
    .mc_cmd_valid(c_cmd_valid), .mc_cmd_ready(c_cmd_ready), .mc_cmd_write(c_cmd_write),
    .mc_cmd_addr(c_cmd_addr), .mc_cmd_len(c_cmd_len), .mc_cmd_tag(c_cmd_tag),
    .mc_wd_valid(c_wd_valid), .mc_wd_ready(c_wd_ready), .mc_wd_data(c_wd_data),
    .mc_wd_strb(c_wd_strb), .mc_wd_last(c_wd_last),
    .mc_rd_valid(c_rd_valid), .mc_rd_ready(c_rd_ready), .mc_rd_data(c_rd_data),
    .mc_rd_tag(c_rd_tag), .mc_rd_last(c_rd_last), .mc_rd_error(c_rd_error),
    .mc_wr_valid(c_wr_valid), .mc_wr_ready(c_wr_ready), .mc_wr_tag(c_wr_tag), .mc_wr_error(c_wr_error),
    .ctl_mc_reset_req, .st_state, .st_ready, .st_cal_fail, .st_fault_seen, .st_idle,
    .err_evt, .err_code, .err_addr, .err_id, .err_write, .perf_cnt
  );

  generate
    if (ASYNC != 0) begin : g_cdc
      extmem_mc_cdc #(
        .DW(DW), .MC_AW(MC_AW), .LW(LW), .TW(TW), .DEPTH(CDC_DEPTH), .SYNC(CDC_SYNC)
      ) u_cdc (
        .clk, .rst_n, .f_mc_rst_n(c_rst_n), .f_init_done(c_init_done), .f_fatal(c_fatal),
        .f_cmd_valid(c_cmd_valid), .f_cmd_ready(c_cmd_ready), .f_cmd_write(c_cmd_write),
        .f_cmd_addr(c_cmd_addr), .f_cmd_len(c_cmd_len), .f_cmd_tag(c_cmd_tag),
        .f_wd_valid(c_wd_valid), .f_wd_ready(c_wd_ready), .f_wd_data(c_wd_data),
        .f_wd_strb(c_wd_strb), .f_wd_last(c_wd_last),
        .f_rd_valid(c_rd_valid), .f_rd_ready(c_rd_ready), .f_rd_data(c_rd_data),
        .f_rd_tag(c_rd_tag), .f_rd_last(c_rd_last), .f_rd_error(c_rd_error),
        .f_wr_valid(c_wr_valid), .f_wr_ready(c_wr_ready), .f_wr_tag(c_wr_tag), .f_wr_error(c_wr_error),
        .mc_clk, .m_rst_n(mc_rst_n), .m_init_done(mc_init_done), .m_fatal(mc_fatal),
        .m_cmd_valid(mc_cmd_valid), .m_cmd_ready(mc_cmd_ready), .m_cmd_write(mc_cmd_write),
        .m_cmd_addr(mc_cmd_addr), .m_cmd_len(mc_cmd_len), .m_cmd_tag(mc_cmd_tag),
        .m_wd_valid(mc_wd_valid), .m_wd_ready(mc_wd_ready), .m_wd_data(mc_wd_data),
        .m_wd_strb(mc_wd_strb), .m_wd_last(mc_wd_last),
        .m_rd_valid(mc_rd_valid), .m_rd_ready(mc_rd_ready), .m_rd_data(mc_rd_data),
        .m_rd_tag(mc_rd_tag), .m_rd_last(mc_rd_last), .m_rd_error(mc_rd_error),
        .m_wr_valid(mc_wr_valid), .m_wr_ready(mc_wr_ready), .m_wr_tag(mc_wr_tag), .m_wr_error(mc_wr_error)
      );
    end else begin : g_sync
      assign mc_rst_n     = c_rst_n;
      assign c_init_done  = mc_init_done;
      assign c_fatal      = mc_fatal;
      assign mc_cmd_valid = c_cmd_valid;
      assign c_cmd_ready  = mc_cmd_ready;
      assign mc_cmd_write = c_cmd_write;
      assign mc_cmd_addr  = c_cmd_addr;
      assign mc_cmd_len   = c_cmd_len;
      assign mc_cmd_tag   = c_cmd_tag;
      assign mc_wd_valid  = c_wd_valid;
      assign c_wd_ready   = mc_wd_ready;
      assign mc_wd_data   = c_wd_data;
      assign mc_wd_strb   = c_wd_strb;
      assign mc_wd_last   = c_wd_last;
      assign c_rd_valid   = mc_rd_valid;
      assign mc_rd_ready  = c_rd_ready;
      assign c_rd_data    = mc_rd_data;
      assign c_rd_tag     = mc_rd_tag;
      assign c_rd_last    = mc_rd_last;
      assign c_rd_error   = mc_rd_error;
      assign c_wr_valid   = mc_wr_valid;
      assign mc_wr_ready  = c_wr_ready;
      assign c_wr_tag     = mc_wr_tag;
      assign c_wr_error   = mc_wr_error;
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_mc_clk = mc_clk;
      /* verilator lint_on UNUSEDSIGNAL */
    end
  endgenerate
endmodule

`default_nettype wire
