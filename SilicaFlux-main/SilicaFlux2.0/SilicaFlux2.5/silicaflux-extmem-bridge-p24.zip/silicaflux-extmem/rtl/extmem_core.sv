// =============================================================================
// SilicaFlux MemoryBridge :: extmem_core -- single-clock bridge core
//
//   DataFabric (SFB2 / SFB2-X)                     generic MC interface (SFMC)
//   up_req_* --> frontend --+--> sched (rq/wq) --> mc_cmd_*  (tags = slot ids)
//                           |        \--> wd sequencer --> mc_wd_*  <- wbuf
//                           +--> wbuf (slot x beat)
//                           +--> ROB (acceptance order)
//   up_rsp_* <-- ROB <------ rbuf (slot x beat) <-- tracker <-- mc_rd_* / mc_wr_*
//                    ctrl FSM: mc_rst_n, mc_init_done, mc_fatal, flush
//
// Everything here runs on `clk`.  silicaflux_extmem_bridge adds the optional
// clock-domain crossing to a controller clock.  Parameters are documented and
// validated in docs/ARCHITECTURE.md and scripts/extmem_cfg.py.
// =============================================================================
`include "extmem_defs.svh"
`default_nettype none

module extmem_core #(
  parameter int             AW             = 32,
  parameter int             DW             = 64,
  parameter int             IDW            = 4,
  parameter int             LW             = 8,
  parameter int             MAX_BURST      = 16,
  parameter int             MAX_RD_OUT     = 8,
  parameter int             MAX_WR_OUT     = 8,
  parameter int             ROB_DEPTH      = 0,          // 0 -> MAX_RD_OUT + MAX_WR_OUT + 2
  parameter int             MC_AW          = 28,
  parameter logic [AW-1:0]  EXT_BASE       = 32'h8000_0000,
  parameter logic [AW:0]    EXT_SIZE       = 33'h0_1000_0000,
  parameter int             BOUND_LOG2     = 12,
  parameter int             UP_OOO         = 0,
  parameter int             SCHED_MODE     = 0,
  parameter int             WR_HI          = 6,
  parameter int             WR_LO          = 2,
  parameter int             AGE_CAP        = 16,
  parameter int             UNAVAIL_POLICY = 0,
  parameter int             RST_HOLD       = 16,
  parameter int             CAL_TIMEOUT    = 0,
  parameter int             RESP_TIMEOUT   = 0,
  parameter int             AUTO_RECOVER   = 1,
  parameter int             PERF           = 1,
  parameter int             ASYNC_INFO     = 0,          // reported in CSR INFO1 only
  localparam int            SB             = DW / 8,
  localparam int            NR             = MAX_RD_OUT,
  localparam int            NW             = MAX_WR_OUT,
  localparam int            MB             = MAX_BURST,
  localparam int            NROB           = (ROB_DEPTH > 0) ? ROB_DEPTH : (NR + NW + 2),
  localparam int            BW             = (MB > 1) ? $clog2(MB) : 1,
  localparam int            RTW            = (NR > 1) ? $clog2(NR) : 1,
  localparam int            WTW            = (NW > 1) ? $clog2(NW) : 1,
  localparam int            TW             = (RTW > WTW) ? RTW : WTW,
  localparam int            WBA            = (NW * MB > 1) ? $clog2(NW * MB) : 1,
  localparam int            RBA            = (NR * MB > 1) ? $clog2(NR * MB) : 1,
  localparam int            TSW            = 16,
  localparam int            CW             = 32
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  // ---------------------------------------------------------------- SFB2-X upstream port (slave)
  input  wire logic                    up_req_valid,
  output logic                         up_req_ready,
  input  wire logic                    up_req_write,
  input  wire logic [AW-1:0]           up_req_addr,
  input  wire logic [DW-1:0]           up_req_wdata,
  input  wire logic [SB-1:0]           up_req_wstrb,
  input  wire logic [IDW-1:0]          up_req_id,
  input  wire logic [LW-1:0]           up_req_len,
  input  wire logic                    up_req_last,
  output logic                         up_rsp_valid,
  input  wire logic                    up_rsp_ready,
  output logic [DW-1:0]                up_rsp_rdata,
  output logic                         up_rsp_error,
  output logic [IDW-1:0]               up_rsp_id,
  output logic                         up_rsp_last,
  output logic                         up_rsp_write,
  // ---------------------------------------------------------------- SFB2 CSR port (32-bit slave)
  input  wire logic                    csr_req_valid,
  output logic                         csr_req_ready,
  input  wire logic                    csr_req_write,
  input  wire logic [31:0]             csr_req_addr,
  input  wire logic [31:0]             csr_req_wdata,
  input  wire logic [3:0]              csr_req_wstrb,
  output logic                         csr_rsp_valid,
  input  wire logic                    csr_rsp_ready,
  output logic [31:0]                  csr_rsp_rdata,
  output logic                         csr_rsp_error,
  // ---------------------------------------------------------------- generic memory-controller interface
  output logic                         mc_rst_n,
  input  wire logic                    mc_init_done,
  input  wire logic                    mc_fatal,
  output logic                         mc_cmd_valid,
  input  wire logic                    mc_cmd_ready,
  output logic                         mc_cmd_write,
  output logic [MC_AW-1:0]             mc_cmd_addr,
  output logic [LW-1:0]                mc_cmd_len,
  output logic [TW-1:0]                mc_cmd_tag,
  output logic                         mc_wd_valid,
  input  wire logic                    mc_wd_ready,
  output logic [DW-1:0]                mc_wd_data,
  output logic [SB-1:0]                mc_wd_strb,
  output logic                         mc_wd_last,
  input  wire logic                    mc_rd_valid,
  output logic                         mc_rd_ready,
  input  wire logic [DW-1:0]           mc_rd_data,
  input  wire logic [TW-1:0]           mc_rd_tag,
  input  wire logic                    mc_rd_last,
  input  wire logic                    mc_rd_error,
  input  wire logic                    mc_wr_valid,
  output logic                         mc_wr_ready,
  input  wire logic [TW-1:0]           mc_wr_tag,
  input  wire logic                    mc_wr_error,
  // ---------------------------------------------------------------- sideband control / status
  input  wire logic                    ctl_mc_reset_req,
  output logic [2:0]                   st_state,
  output logic                         st_ready,
  output logic                         st_cal_fail,
  output logic                         st_fault_seen,
  output logic                         st_idle,
  output logic                         err_evt,
  output logic [3:0]                   err_code,
  output logic [AW-1:0]                err_addr,
  output logic [IDW-1:0]               err_id,
  output logic                         err_write,
  output logic [`XM_PERF_N*CW-1:0]     perf_cnt
);
  // ------------------------------------------------------------ parameter checks (simulation)
`ifndef SYNTHESIS
  initial begin
    if (!(DW == 32 || DW == 64 || DW == 128 || DW == 256 || DW == 512))
      $fatal(1, "extmem: DW must be 32/64/128/256/512");
    if (MB < 1 || (MB & (MB - 1)) != 0 || MB > (1 << LW))
      $fatal(1, "extmem: MAX_BURST must be a power of two <= 2^LW");
    if (NR < 1 || NW < 1 || NR > 255 || NW > 255) $fatal(1, "extmem: MAX_RD_OUT/MAX_WR_OUT 1..255");
    if (IDW < 1 || IDW > 16) $fatal(1, "extmem: IDW 1..16");
    if ((EXT_BASE % AW'(SB)) != 0 || (EXT_SIZE % (AW+1)'(SB)) != 0 || EXT_SIZE == 0)
      $fatal(1, "extmem: EXT_BASE / EXT_SIZE must be DW aligned, SIZE > 0");
    if ({1'b0, EXT_BASE} + EXT_SIZE > (1 << AW)) $fatal(1, "extmem: window exceeds the address space");
    if (MC_AW < AW && EXT_SIZE > ((AW+1)'(1) << MC_AW)) $fatal(1, "extmem: MC_AW too small for EXT_SIZE");
    if (BOUND_LOG2 < $clog2(SB) || BOUND_LOG2 > AW) $fatal(1, "extmem: BOUND_LOG2 out of range");
    if (SCHED_MODE != 0 && (WR_LO >= WR_HI || AGE_CAP < 1)) $fatal(1, "extmem: WR_LO < WR_HI, AGE_CAP >= 1");
    if (RST_HOLD < 2) $fatal(1, "extmem: RST_HOLD >= 2");
  end
`endif

  // ------------------------------------------------------------ interconnect
  logic             flush, accept_ok, issue_en, rsp_en;
  logic             rd_free_any, wr_free_any, rob_space;
  logic [RTW-1:0]   rd_free_idx;
  logic [WTW-1:0]   wr_free_idx;
  logic             rd_alloc, wr_alloc, wr_release;
  logic [RTW-1:0]   rd_alloc_idx;
  logic [BW-1:0]    rd_alloc_len;
  logic [WTW-1:0]   wr_alloc_idx, wr_release_idx;
  logic             wbuf_we;
  logic [WBA-1:0]   wbuf_waddr, wbuf_raddr;
  logic [DW+SB-1:0] wbuf_wdata, wbuf_rdata;
  logic             rq_push, wq_push;
  logic [TW-1:0]    q_slot;
  logic [MC_AW-1:0] q_addr;
  logic [BW-1:0]    q_len;
  logic             rob_push, rob_is_wr, rob_lerr;
  logic [IDW-1:0]   rob_id;
  logic [LW-1:0]    rob_len;
  logic [TW-1:0]    rob_slot;
  logic [3:0]       rob_code;
  logic [AW-1:0]    rob_addr;
  logic             in_burst;
  logic             ev_rd_req, ev_wr_req, ev_wbeat, ev_req_stall, ev_noslot;
  logic             rd_issue, wr_issue, wd_done;
  logic [RTW-1:0]   rd_issue_idx;
  logic [WTW-1:0]   wr_issue_idx, wd_done_idx;
  logic             sched_idle, ev_hazard, ev_bypass, ev_switch;
  logic [RTW:0]     rq_cnt;
  logic [WTW:0]     wq_cnt;
  logic             rbuf_we, rbuf_werr;
  logic [RBA-1:0]   rbuf_waddr, rbuf_raddr;
  logic [DW:0]      rbuf_rdata;
  logic [NR*(BW+1)-1:0] rcnt_flat;
  logic [NR-1:0]    rflush;
  logic [NW-1:0]    wdone, werr, wflush;
  logic             any_inflight, ev_mc_proto;
  logic [RTW:0]     rd_busy_cnt;
  logic [WTW:0]     wr_busy_cnt;
  logic             rd_retire, wr_retire;
  logic [RTW-1:0]   rd_retire_idx;
  logic [WTW-1:0]   wr_retire_idx;
  logic             ev_rd_done, ev_wr_done, ev_rd_beat_ok;
  logic [TSW-1:0]   ev_lat, ts_q;
  logic             csr_mc_reset, csr_clr_sticky, perf_en, perf_clr;
  logic             ev_fault;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [$clog2(NROB+1)-1:0] rob_count;
  /* verilator lint_on UNUSEDSIGNAL */

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) ts_q <= '0;
    else        ts_q <= ts_q + TSW'(1);
  end

  // ------------------------------------------------------------ link control
  extmem_ctrl #(
    .RST_HOLD(RST_HOLD), .CAL_TIMEOUT(CAL_TIMEOUT), .RESP_TIMEOUT(RESP_TIMEOUT),
    .AUTO_RECOVER(AUTO_RECOVER)
  ) u_ctrl (
    .clk, .rst_n, .mc_init_done, .mc_fatal,
    .ctl_reset_req(ctl_mc_reset_req || csr_mc_reset), .ctl_clr_sticky(csr_clr_sticky),
    .any_inflight, .mc_progress(rsp_en && (mc_rd_valid || mc_wr_valid)),
    .idle(sched_idle && !in_burst && !any_inflight),
    .mc_rst_n, .state(st_state), .flush, .accept_ok, .issue_en, .rsp_en,
    .st_ready, .st_cal_fail, .st_fault_seen, .ev_fault
  );

  // ------------------------------------------------------------ frontend
  extmem_frontend #(
    .AW(AW), .DW(DW), .IDW(IDW), .LW(LW), .MB(MB), .NR(NR), .NW(NW), .MC_AW(MC_AW),
    .BASE(EXT_BASE), .SIZE(EXT_SIZE), .BOUND_LOG2(BOUND_LOG2), .UNAVAIL_POLICY(UNAVAIL_POLICY)
  ) u_fe (
    .clk, .rst_n,
    .up_req_valid, .up_req_ready, .up_req_write, .up_req_addr, .up_req_wdata, .up_req_wstrb,
    .up_req_id, .up_req_len, .up_req_last,
    .accept_ok, .flush, .rd_free_any, .rd_free_idx, .wr_free_any, .wr_free_idx, .rob_space,
    .rd_alloc, .rd_alloc_idx, .rd_alloc_len, .wr_alloc, .wr_alloc_idx, .wr_release, .wr_release_idx,
    .wbuf_we, .wbuf_waddr, .wbuf_wdata,
    .rq_push, .wq_push, .q_slot, .q_addr, .q_len,
    .rob_push, .rob_is_wr, .rob_id, .rob_len, .rob_slot, .rob_lerr, .rob_code, .rob_addr,
    .in_burst, .ev_rd_req, .ev_wr_req, .ev_wbeat, .ev_req_stall, .ev_noslot
  );

  // ------------------------------------------------------------ buffers
  extmem_ram #(.W(DW + SB), .D(NW * MB)) u_wbuf (
    .clk, .we(wbuf_we), .waddr(wbuf_waddr), .wdata(wbuf_wdata), .raddr(wbuf_raddr), .rdata(wbuf_rdata)
  );
  extmem_ram #(.W(DW + 1), .D(NR * MB)) u_rbuf (
    .clk, .we(rbuf_we), .waddr(rbuf_waddr), .wdata({rbuf_werr, mc_rd_data}), .raddr(rbuf_raddr),
    .rdata(rbuf_rdata)
  );

  // ------------------------------------------------------------ scheduler
  extmem_sched #(
    .NR(NR), .NW(NW), .MB(MB), .MC_AW(MC_AW), .LW(LW), .TW(TW), .SB(SB),
    .SCHED_MODE(SCHED_MODE), .WR_HI(WR_HI), .WR_LO(WR_LO), .AGE_CAP(AGE_CAP)
  ) u_sched (
    .clk, .rst_n, .flush, .issue_en,
    .rq_push, .wq_push, .q_slot, .q_addr, .q_len,
    .mc_cmd_valid, .mc_cmd_ready, .mc_cmd_write, .mc_cmd_addr, .mc_cmd_len, .mc_cmd_tag,
    .mc_wd_valid, .mc_wd_ready, .mc_wd_last, .wbuf_raddr,
    .rd_issue, .rd_issue_idx, .wr_issue, .wr_issue_idx, .wd_done, .wd_done_idx,
    .idle(sched_idle), .rq_cnt_o(rq_cnt), .wq_cnt_o(wq_cnt),
    .ev_hazard, .ev_bypass, .ev_switch
  );
  assign mc_wd_data = wbuf_rdata[DW-1:0];
  assign mc_wd_strb = wbuf_rdata[DW +: SB];

  // ------------------------------------------------------------ slot tracker
  extmem_tracker #(.NR(NR), .NW(NW), .MB(MB), .TW(TW)) u_trk (
    .clk, .rst_n, .flush, .rsp_en,
    .rd_alloc, .rd_alloc_idx, .rd_alloc_len, .wr_alloc, .wr_alloc_idx, .wr_release, .wr_release_idx,
    .rd_retire, .rd_retire_idx, .wr_retire, .wr_retire_idx,
    .rd_issue, .rd_issue_idx, .wr_issue, .wr_issue_idx, .wd_done, .wd_done_idx,
    .mc_rd_valid, .mc_rd_tag, .mc_rd_last, .mc_rd_error,
    .mc_wr_valid, .mc_wr_tag, .mc_wr_error,
    .rbuf_we, .rbuf_waddr, .rbuf_werr,
    .rd_free_any, .rd_free_idx, .wr_free_any, .wr_free_idx,
    .rcnt_flat, .rflush_o(rflush), .wdone_o(wdone), .werr_o(werr), .wflush_o(wflush),
    .any_inflight, .rd_busy_cnt, .wr_busy_cnt, .ev_mc_proto
  );
  // read data / write responses are never back-pressured: buffer space is
  // reserved per slot before a command is issued (credit by construction)
  assign mc_rd_ready = 1'b1;
  assign mc_wr_ready = 1'b1;

  // ------------------------------------------------------------ response ordering
  extmem_rob #(
    .AW(AW), .DW(DW), .IDW(IDW), .LW(LW), .MB(MB), .NR(NR), .NW(NW), .TW(TW), .NROB(NROB),
    .UP_OOO(UP_OOO), .TSW(TSW)
  ) u_rob (
    .clk, .rst_n, .ts_now(ts_q),
    .push(rob_push), .p_is_wr(rob_is_wr), .p_id(rob_id), .p_len(rob_len), .p_slot(rob_slot),
    .p_lerr(rob_lerr), .p_code(rob_code), .p_addr(rob_addr), .space(rob_space), .count(rob_count),
    .rcnt_flat, .rflush, .wdone, .werr, .wflush,
    .rbuf_raddr, .rbuf_rdata,
    .rd_retire, .rd_retire_idx, .wr_retire, .wr_retire_idx,
    .up_rsp_valid, .up_rsp_ready, .up_rsp_rdata, .up_rsp_error, .up_rsp_id, .up_rsp_last, .up_rsp_write,
    .err_evt, .err_code, .err_addr, .err_id, .err_write,
    .ev_rd_done, .ev_wr_done, .ev_lat, .ev_rd_beat_ok
  );

  assign st_idle = sched_idle && !in_burst && !any_inflight && (rob_count == '0);

  // ------------------------------------------------------------ performance counters
  logic [`XM_PERF_N*CW-1:0] perf_raw;
  generate
    if (PERF != 0) begin : g_perf
      extmem_perf #(.CW(CW), .OW(8), .TSW(TSW)) u_perf (
        .clk, .rst_n, .en(perf_en), .clr(perf_clr),
        .ev_rd_req, .ev_wr_req, .ev_rd_beat_ok, .ev_wbeat, .ev_err_txn(err_evt),
        .ev_up_req_stall(ev_req_stall), .ev_up_rsp_stall(up_rsp_valid && !up_rsp_ready),
        .ev_mc_rd_cmd(rd_issue), .ev_mc_wr_cmd(wr_issue),
        .ev_mc_cmd_stall(mc_cmd_valid && !mc_cmd_ready),
        .ev_mc_wd_beat(mc_wd_valid && mc_wd_ready), .ev_mc_wd_stall(mc_wd_valid && !mc_wd_ready),
        .ev_mc_rd_beat(rbuf_we), .ev_hazard, .ev_bypass, .ev_switch,
        .rq_occ(8'(rq_cnt)), .wq_occ(8'(wq_cnt)), .rd_out(8'(rd_busy_cnt)), .wr_out(8'(wr_busy_cnt)),
        .ev_rd_done, .ev_wr_done, .lat(ev_lat), .ev_noslot,
        .unavail(!st_ready), .ev_mc_proto, .cnt_flat(perf_raw)
      );
    end else begin : g_noperf
      assign perf_raw = '0;
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_perf = ^{ev_rd_req, ev_wr_req, ev_wbeat, ev_req_stall, ev_noslot, ev_hazard, ev_bypass,
                           ev_switch, rq_cnt, wq_cnt, ev_mc_proto, rd_busy_cnt, wr_busy_cnt, ev_rd_done,
                           ev_wr_done, ev_rd_beat_ok, ev_lat, perf_en, perf_clr};
      /* verilator lint_on UNUSEDSIGNAL */
    end
  endgenerate
  assign perf_cnt = perf_raw;

  // ------------------------------------------------------------ CSR page
  localparam logic [31:0] INFO0 = {8'(NW), 8'(NR), 8'(MB - 1), 8'(SB)};
  localparam logic [31:0] INFO1 = {8'd1, 8'(NROB), 4'd0, 4'(IDW), 3'd0, 1'(PERF != 0),
                                   1'(UNAVAIL_POLICY != 0), 1'(SCHED_MODE != 0), 1'(ASYNC_INFO != 0),
                                   1'(UP_OOO != 0)};
  extmem_csr #(
    .AW(AW), .IDW(IDW), .INFO0(INFO0), .INFO1(INFO1), .BASE_W(32'(EXT_BASE)),
    .SIZE_W(64'(EXT_SIZE)), .CW(CW)
  ) u_csr (
    .clk, .rst_n,
    .req_valid(csr_req_valid), .req_ready(csr_req_ready), .req_write(csr_req_write),
    .req_addr(csr_req_addr), .req_wdata(csr_req_wdata), .req_wstrb(csr_req_wstrb),
    .rsp_valid(csr_rsp_valid), .rsp_ready(csr_rsp_ready), .rsp_rdata(csr_rsp_rdata),
    .rsp_error(csr_rsp_error),
    .st_state, .st_ready, .st_cal_fail, .st_fault_seen, .st_inflight(any_inflight),
    .ctl_mc_reset(csr_mc_reset), .ctl_clr_sticky(csr_clr_sticky), .perf_en, .perf_clr,
    .err_evt, .err_code, .err_addr, .err_id, .err_write, .perf_cnt(perf_raw)
  );

  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_ok = ^{ev_fault};
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
