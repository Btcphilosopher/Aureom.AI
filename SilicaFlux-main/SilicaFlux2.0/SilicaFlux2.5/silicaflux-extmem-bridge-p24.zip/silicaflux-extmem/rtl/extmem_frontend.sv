// =============================================================================
// SilicaFlux MemoryBridge :: extmem_frontend -- upstream request decode
//
// Accepts SFB2-X request beats (docs/PROTOCOL_SFB2X.md) and turns them into
//   * a ROB entry per transaction (response order / ownership record),
//   * a slot allocation (read or write slot = buffer region + MC tag),
//   * write-data beats into the write buffer (slot*MAX_BURST + beat),
//   * a command for the scheduler (reads: at acceptance; writes: when the last
//     data beat has been accepted -- store and forward, so the controller
//     never waits for upstream write data).
//
// First-beat checks (priority order) -> local error, no slot, no controller
// access, no side effect:
//   LEN (len+1 > MB), ALIGN (addr not DW aligned), RANGE (burst not inside
//   [BASE, BASE+SIZE)), BOUNDARY (burst crosses 2^BOUND_LOG2 bytes),
//   UNAVAIL (controller link not READY; UNAVAIL_POLICY = 0).
// With UNAVAIL_POLICY = 1 a request is stalled (req_ready = 0) instead of
// being answered UNAVAIL while the link is not READY.
//
// Write-burst framing: the burst ends at the first beat with req_last = 1 or
// with beat index == req_len, whichever comes first.  If the two disagree the
// write is answered XM_ERR_PROTO and is NOT performed.  On beats after the
// first only wdata / wstrb / last are used.  Reads are one request beat
// (req_last is ignored) and return req_len+1 response beats.
//
// req_ready is 1 inside a write burst (its buffer space is reserved at the
// first beat); for a first beat it depends on req_write, registered state
// (ROB space, a free slot of the right kind) and, with UNAVAIL_POLICY = 1,
// on accept_ok (which follows mc_init_done / mc_fatal).
// =============================================================================
`include "extmem_defs.svh"
`default_nettype none

module extmem_frontend #(
  parameter int             AW             = 32,
  parameter int             DW             = 64,
  parameter int             IDW            = 4,
  parameter int             LW             = 8,
  parameter int             MB             = 16,
  parameter int             NR             = 8,
  parameter int             NW             = 8,
  parameter int             MC_AW          = 28,
  parameter logic [AW-1:0]  BASE           = {1'b1, {(AW-1){1'b0}}},
  parameter logic [AW:0]    SIZE           = {{(AW-27){1'b0}}, 1'b1, {27{1'b0}}},
  parameter int             BOUND_LOG2     = 12,
  parameter int             UNAVAIL_POLICY = 0,
  localparam int            SB             = DW / 8,
  localparam int            OFF            = $clog2(SB),
  localparam int            BW             = (MB > 1) ? $clog2(MB) : 1,
  localparam int            RTW            = (NR > 1) ? $clog2(NR) : 1,
  localparam int            WTW            = (NW > 1) ? $clog2(NW) : 1,
  localparam int            TW             = (RTW > WTW) ? RTW : WTW,
  localparam int            WBA            = (NW * MB > 1) ? $clog2(NW * MB) : 1
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ---------------------------------------------------------------- SFB2-X request channel
  input  wire logic             up_req_valid,
  output logic                  up_req_ready,
  input  wire logic             up_req_write,
  input  wire logic [AW-1:0]    up_req_addr,
  input  wire logic [DW-1:0]    up_req_wdata,
  input  wire logic [SB-1:0]    up_req_wstrb,
  input  wire logic [IDW-1:0]   up_req_id,
  input  wire logic [LW-1:0]    up_req_len,
  input  wire logic             up_req_last,
  // ---------------------------------------------------------------- link state / resources
  input  wire logic             accept_ok,       // link READY and no flush this cycle
  input  wire logic             flush,
  input  wire logic             rd_free_any,
  input  wire logic [RTW-1:0]   rd_free_idx,
  input  wire logic             wr_free_any,
  input  wire logic [WTW-1:0]   wr_free_idx,
  input  wire logic             rob_space,
  // ---------------------------------------------------------------- slot management
  output logic                  rd_alloc,
  output logic [RTW-1:0]        rd_alloc_idx,
  output logic [BW-1:0]         rd_alloc_len,
  output logic                  wr_alloc,
  output logic [WTW-1:0]        wr_alloc_idx,
  output logic                  wr_release,
  output logic [WTW-1:0]        wr_release_idx,
  // ---------------------------------------------------------------- write buffer
  output logic                  wbuf_we,
  output logic [WBA-1:0]        wbuf_waddr,
  output logic [DW+SB-1:0]      wbuf_wdata,      // {strb, data}
  // ---------------------------------------------------------------- scheduler queues
  output logic                  rq_push,
  output logic                  wq_push,
  output logic [TW-1:0]         q_slot,
  output logic [MC_AW-1:0]      q_addr,
  output logic [BW-1:0]         q_len,
  // ---------------------------------------------------------------- ROB push
  output logic                  rob_push,
  output logic                  rob_is_wr,
  output logic [IDW-1:0]        rob_id,
  output logic [LW-1:0]         rob_len,
  output logic [TW-1:0]         rob_slot,
  output logic                  rob_lerr,
  output logic [3:0]            rob_code,
  output logic [AW-1:0]         rob_addr,
  // ---------------------------------------------------------------- status / events
  output logic                  in_burst,
  output logic                  ev_rd_req,
  output logic                  ev_wr_req,
  output logic                  ev_wbeat,
  output logic                  ev_req_stall,
  output logic                  ev_noslot
);
  // ------------------------------------------------------------ burst state
  logic             in_burst_q, cur_drop_q;
  logic [WTW-1:0]   cur_slot_q;
  logic [LW-1:0]    cur_len_q, cur_beat_q;
  logic [3:0]       cur_code_q;
  logic [IDW-1:0]   cur_id_q;
  logic [AW-1:0]    cur_addr_q;
  logic [MC_AW-1:0] cur_mca_q;

  // ------------------------------------------------------------ first-beat decode
  localparam logic [AW:0] BASE_X = {1'b0, BASE};
  localparam logic [AW:0] LIM_X  = BASE_X + SIZE - {{AW{1'b0}}, 1'b1};

  wire [AW:0] a_x     = {1'b0, up_req_addr};
  wire [AW:0] nbytes  = ({{(AW+1-LW){1'b0}}, up_req_len} + {{AW{1'b0}}, 1'b1}) << OFF;
  wire [AW:0] last_x  = a_x + nbytes - {{AW{1'b0}}, 1'b1};
  /* verilator lint_off CMPCONST */
  wire        len_ok  = (up_req_len <= LW'(MB - 1));   // constant 1 when MB == 2^LW
  /* verilator lint_on CMPCONST */
  wire        aln_ok  = (up_req_addr[OFF-1:0] == '0);
  wire        rng_ok  = (a_x >= BASE_X) && (last_x <= LIM_X);
  wire        bnd_ok  = ((a_x >> BOUND_LOG2) == (last_x >> BOUND_LOG2));
  /* verilator lint_off UNUSEDSIGNAL */
  wire [AW-1:0] off_a = up_req_addr - BASE;     // bits >= MC_AW are zero inside the window
  /* verilator lint_on UNUSEDSIGNAL */
  wire [MC_AW-1:0] dmca = off_a[MC_AW-1:0];

  logic [3:0] dcode;
  always_comb begin
    dcode = `XM_ERR_NONE;
    if (!len_ok)         dcode = `XM_ERR_LEN;
    else if (!aln_ok)    dcode = `XM_ERR_ALIGN;
    else if (!rng_ok)    dcode = `XM_ERR_RANGE;
    else if (!bnd_ok)    dcode = `XM_ERR_BOUNDARY;
    else if (!accept_ok) dcode = `XM_ERR_UNAVAIL;
  end

  wire first      = !in_burst_q;
  wire unav_stall = (UNAVAIL_POLICY != 0) && !accept_ok;
  wire free_ok    = up_req_write ? wr_free_any : rd_free_any;
  assign up_req_ready = in_burst_q || (rob_space && free_ok && !unav_stall);
  assign in_burst     = in_burst_q;

  wire hs = up_req_valid && up_req_ready;

  // ------------------------------------------------------------ per-beat view of the write burst
  wire [LW-1:0]  w_beat  = first ? '0 : cur_beat_q;
  wire [LW-1:0]  w_len   = first ? up_req_len : cur_len_q;
  wire [3:0]     w_code  = first ? dcode : cur_code_q;
  wire [WTW-1:0] w_slot  = first ? wr_free_idx : cur_slot_q;
  wire           w_drop  = first ? 1'b0 : cur_drop_q;
  wire           w_norm  = (w_code == `XM_ERR_NONE);
  wire           by_len  = (w_beat == w_len);
  wire           endb    = up_req_last || by_len;
  wire           proto   = (up_req_last != by_len);

  always_comb begin
    rd_alloc       = 1'b0;
    rd_alloc_idx   = rd_free_idx;
    rd_alloc_len   = up_req_len[BW-1:0];
    wr_alloc       = 1'b0;
    wr_alloc_idx   = wr_free_idx;
    wr_release     = 1'b0;
    wr_release_idx = cur_slot_q;
    wbuf_we        = 1'b0;
    wbuf_waddr     = WBA'(w_slot) * WBA'(MB) + WBA'(w_beat);
    wbuf_wdata     = {up_req_wstrb, up_req_wdata};
    rq_push        = 1'b0;
    wq_push        = 1'b0;
    q_slot         = TW'(rd_free_idx);
    q_addr         = dmca;
    q_len          = up_req_len[BW-1:0];
    rob_push       = 1'b0;
    rob_is_wr      = up_req_write;
    rob_id         = up_req_id;
    rob_len        = up_req_len;
    rob_slot       = TW'(rd_free_idx);
    rob_lerr       = 1'b0;
    rob_code       = dcode;
    rob_addr       = up_req_addr;

    if (hs && first && !up_req_write) begin
      // ---------------------------------------------------- read: one request beat
      rob_push = 1'b1;
      if (dcode == `XM_ERR_NONE) begin
        rd_alloc = 1'b1;
        rq_push  = 1'b1;
      end else begin
        rob_lerr = 1'b1;
      end
    end else if (hs && (up_req_write || !first)) begin
      // ---------------------------------------------------- write beat
      if (w_norm) wbuf_we = 1'b1;
      if (first && w_norm && !(endb && (proto || flush))) begin
        wr_alloc = 1'b1;
      end
      if (endb) begin
        rob_push  = 1'b1;
        rob_is_wr = 1'b1;
        rob_id    = first ? up_req_id : cur_id_q;
        rob_len   = w_len;
        rob_addr  = first ? up_req_addr : cur_addr_q;
        rob_slot  = TW'(w_slot);
        q_slot    = TW'(w_slot);
        q_addr    = first ? dmca : cur_mca_q;
        q_len     = w_len[BW-1:0];
        if (!w_norm) begin
          rob_lerr = 1'b1;
          rob_code = w_code;
        end else if (proto) begin
          rob_lerr   = 1'b1;
          rob_code   = `XM_ERR_PROTO;
          wr_release = !first;
        end else if (w_drop || flush) begin
          rob_lerr   = 1'b1;
          rob_code   = `XM_ERR_FLUSH;
          wr_release = !first;
        end else begin
          wq_push  = 1'b1;
          rob_code = `XM_ERR_NONE;
        end
      end
    end
  end

  // ------------------------------------------------------------ burst state
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      in_burst_q <= 1'b0;
      cur_drop_q <= 1'b0;
      cur_slot_q <= '0;
      cur_len_q  <= '0;
      cur_beat_q <= '0;
      cur_code_q <= `XM_ERR_NONE;
      cur_id_q   <= '0;
      cur_addr_q <= '0;
      cur_mca_q  <= '0;
    end else begin
      if (hs && (up_req_write || !first)) begin
        if (endb) begin
          in_burst_q <= 1'b0;
          cur_drop_q <= 1'b0;
        end else begin
          in_burst_q <= 1'b1;
          cur_beat_q <= w_beat + LW'(1);
          cur_drop_q <= w_drop || (flush && w_norm);
          if (first) begin
            cur_slot_q <= wr_free_idx;
            cur_len_q  <= up_req_len;
            cur_code_q <= dcode;
            cur_id_q   <= up_req_id;
            cur_addr_q <= up_req_addr;
            cur_mca_q  <= dmca;
          end
        end
      end else if (in_burst_q && flush && cur_code_q == `XM_ERR_NONE) begin
        cur_drop_q <= 1'b1;
      end
    end
  end

  // ------------------------------------------------------------ events
  assign ev_rd_req    = hs && first && !up_req_write;
  assign ev_wr_req    = hs && first && up_req_write;
  assign ev_wbeat     = hs && (up_req_write || !first);
  assign ev_req_stall = up_req_valid && !up_req_ready;
  assign ev_noslot    = up_req_valid && first && !(rob_space && free_ok);
endmodule

`default_nettype wire
