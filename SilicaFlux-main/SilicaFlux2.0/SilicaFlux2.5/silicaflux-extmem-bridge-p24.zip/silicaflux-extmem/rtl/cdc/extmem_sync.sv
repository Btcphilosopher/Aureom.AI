// =============================================================================
// SilicaFlux MemoryBridge :: extmem_sync (CDC cell, technology wrapper -- RTL rule 5)
//
//   extmem_sync      N-stage synchroniser for a level / Gray-coded vector
//   extmem_rst_sync  reset synchroniser: asynchronous assert, synchronous
//                    de-assert in the destination clock
//   extmem_async_fifo  dual-clock FIFO, Gray-coded pointers (one bit changes
//                    per increment, so a multi-bit pointer may be synchronised
//                    with extmem_sync), flop storage written in the write
//                    domain and read combinationally in the read domain; a
//                    slot is read only after its write pointer update has been
//                    synchronised, i.e. >= SYNC destination cycles after the
//                    write -- see constraints/ for the max-delay rules.
//
// For an ASIC replace extmem_sync's flops by the library's synchroniser cell
// (MTBF-characterised); for Xilinx keep the ASYNC_REG attribute.
// =============================================================================
`default_nettype none

module extmem_sync #(
  parameter int       W      = 1,
  parameter int       STAGES = 2,
  parameter logic     RSTV   = 1'b0
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic [W-1:0] d,
  output logic      [W-1:0] q
);
  (* ASYNC_REG = "TRUE" *) logic [W-1:0] s [STAGES];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < STAGES; i++) s[i] <= {W{RSTV}};
    end else begin
      s[0] <= d;
      for (int i = 1; i < STAGES; i++) s[i] <= s[i-1];
    end
  end
  assign q = s[STAGES-1];
endmodule

`default_nettype wire
