// =============================================================================
// SilicaFlux MemoryBridge :: extmem_rst_sync (CDC cell, technology wrapper -- RTL rule 5)
//
//   extmem_sync      N-stage synchroniser for a level / Gray-coded vector
//   extmem_rst_sync  reset synchroniser: asynchronous assert, synchronous
//                    de-assert in the destination clock
//   extmem_async_fifo  dual-clock FIFO, Gray-coded pointers (one bit changes
//                    per increment, so a multi-bit pointer may be synchronised
//                    with extmem_sync), flop storage written in the write
//                    domain and read combinationally in the read domain; a
//                    slot is read only after its write pointer update has been
//                    synchronised, i.e. >= SYNC destination cycles after the
//                    write -- see constraints/ for the max-delay rules.
//
// For an ASIC replace extmem_sync's flops by the library's synchroniser cell
// (MTBF-characterised); for Xilinx keep the ASYNC_REG attribute.
// =============================================================================
`default_nettype none

module extmem_rst_sync #(
  parameter int STAGES = 2
) (
  input  wire logic clk,
  input  wire logic rst_ni,      // asynchronous, any domain
  output logic      rst_no       // asserted asynchronously, released on clk
);
  (* ASYNC_REG = "TRUE" *) logic [STAGES-1:0] s;

  always_ff @(posedge clk or negedge rst_ni) begin
    if (!rst_ni) s <= '0;
    else         s <= {s[STAGES-2:0], 1'b1};
  end
  assign rst_no = s[STAGES-1];
endmodule

`default_nettype wire
