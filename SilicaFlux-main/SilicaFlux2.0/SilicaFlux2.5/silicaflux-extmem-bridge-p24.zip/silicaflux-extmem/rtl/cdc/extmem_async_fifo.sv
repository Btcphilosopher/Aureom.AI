// =============================================================================
// SilicaFlux MemoryBridge :: extmem_async_fifo (CDC cell, technology wrapper -- RTL rule 5)
//
//   extmem_sync      N-stage synchroniser for a level / Gray-coded vector
//   extmem_rst_sync  reset synchroniser: asynchronous assert, synchronous
//                    de-assert in the destination clock
//   extmem_async_fifo  dual-clock FIFO, Gray-coded pointers (one bit changes
//                    per increment, so a multi-bit pointer may be synchronised
//                    with extmem_sync), flop storage written in the write
//                    domain and read combinationally in the read domain; a
//                    slot is read only after its write pointer update has been
//                    synchronised, i.e. >= SYNC destination cycles after the
//                    write -- see constraints/ for the max-delay rules.
//
// For an ASIC replace extmem_sync's flops by the library's synchroniser cell
// (MTBF-characterised); for Xilinx keep the ASYNC_REG attribute.
// =============================================================================
`default_nettype none

module extmem_async_fifo #(
  parameter int  W     = 8,
  parameter int  DEPTH = 8,            // power of two >= 2
  parameter int  SYNC  = 2,
  localparam int A     = $clog2(DEPTH)
) (
  input  wire logic         wclk,
  input  wire logic         wrst_n,
  input  wire logic         w_valid,
  output logic              w_ready,
  input  wire logic [W-1:0] w_data,
  input  wire logic         rclk,
  input  wire logic         rrst_n,
  output logic              r_valid,
  input  wire logic         r_ready,
  output logic      [W-1:0] r_data
);
  logic [W-1:0] mem [DEPTH];
  logic [A:0]   wbin_q, wgray_q, rbin_q, rgray_q;
  logic [A:0]   rgray_w, wgray_r;

  function automatic logic [A:0] g2b(input logic [A:0] g);
    logic [A:0] b;
    b[A] = g[A];
    for (int i = A - 1; i >= 0; i--) b[i] = b[i+1] ^ g[i];
    g2b = b;
  endfunction

  // ------------------------------------------------------------ write domain
  extmem_sync #(.W(A + 1), .STAGES(SYNC)) u_s_r2w (.clk(wclk), .rst_n(wrst_n), .d(rgray_q), .q(rgray_w));
  wire [A:0] rbin_w = g2b(rgray_w);
  assign w_ready = ((wbin_q - rbin_w) != (A+1)'(DEPTH));
  wire       w_hs  = w_valid && w_ready;
  wire [A:0] wbin_n = wbin_q + (A+1)'(1);

  always_ff @(posedge wclk) begin
    if (w_hs) mem[wbin_q[A-1:0]] <= w_data;
  end
  always_ff @(posedge wclk or negedge wrst_n) begin
    if (!wrst_n) begin
      wbin_q  <= '0;
      wgray_q <= '0;
    end else if (w_hs) begin
      wbin_q  <= wbin_n;
      wgray_q <= wbin_n ^ (wbin_n >> 1);
    end
  end

  // ------------------------------------------------------------ read domain
  extmem_sync #(.W(A + 1), .STAGES(SYNC)) u_s_w2r (.clk(rclk), .rst_n(rrst_n), .d(wgray_q), .q(wgray_r));
  wire [A:0] wbin_r = g2b(wgray_r);
  assign r_valid = (wbin_r != rbin_q);
  assign r_data  = mem[rbin_q[A-1:0]];
  wire       r_hs   = r_valid && r_ready;
  wire [A:0] rbin_n = rbin_q + (A+1)'(1);

  always_ff @(posedge rclk or negedge rrst_n) begin
    if (!rrst_n) begin
      rbin_q  <= '0;
      rgray_q <= '0;
    end else if (r_hs) begin
      rbin_q  <= rbin_n;
      rgray_q <= rbin_n ^ (rbin_n >> 1);
    end
  end
endmodule

`default_nettype wire
