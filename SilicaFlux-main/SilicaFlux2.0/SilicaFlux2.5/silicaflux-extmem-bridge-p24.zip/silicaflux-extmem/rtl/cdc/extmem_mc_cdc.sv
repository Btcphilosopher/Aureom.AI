// =============================================================================
// SilicaFlux MemoryBridge :: extmem_mc_cdc -- MC-interface clock-domain crossing
//
// Carries the generic memory-controller interface (docs/MC_INTERFACE.md) from
// the fabric clock (bridge core) to the controller's user-interface clock
// (e.g. a vendor controller's ui_clk):
//
//   f_cmd_*  --async FIFO-->  m_cmd_*          f_rd_*  <--async FIFO--  m_rd_*
//   f_wd_*   --async FIFO-->  m_wd_*           f_wr_*  <--async FIFO--  m_wr_*
//   f_init_done / f_fatal  <--synchroniser--  m_init_done / m_fatal
//   m_rst_n (to controller) <--reset synchroniser-- (rst_n & f_mc_rst_n)
//
// Reset: the core holds f_mc_rst_n low for RST_HOLD fabric cycles whenever the
// controller must be (re)started.  The fabric halves of the FIFOs are reset by
// (rst_n & f_mc_rst_n) directly, the controller halves and the controller by
// the same signal through extmem_rst_sync, so both halves are empty when the
// link restarts and no command / response of an earlier epoch survives.
// Requirement (checked by scripts/extmem_cfg.py): RST_HOLD covers the
// synchroniser latency of init_done and of the controller reset, i.e.
// RST_HOLD >= SYNC + 2 + ceil((SYNC + 1) * T_mc / T_fabric).
//
// Ordering note: write-data beats travel in a different FIFO from their
// command, so at the controller side a data beat can become visible up to one
// controller cycle before its command; the MC contract allows this (an
// adapter must buffer write data that precedes its command).
// =============================================================================
`default_nettype none

module extmem_mc_cdc #(
  parameter int  DW    = 64,
  parameter int  MC_AW = 28,
  parameter int  LW    = 8,
  parameter int  TW    = 3,
  parameter int  DEPTH = 8,
  parameter int  SYNC  = 2,
  localparam int SB    = DW / 8,
  localparam int CMDW  = 1 + MC_AW + LW + TW,
  localparam int WDW   = DW + SB + 1,
  localparam int RDW   = DW + TW + 2,
  localparam int WRW   = TW + 1
) (
  // ---------------------------------------------------------------- fabric side (bridge core)
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             f_mc_rst_n,
  output logic                  f_init_done,
  output logic                  f_fatal,
  input  wire logic             f_cmd_valid,
  output logic                  f_cmd_ready,
  input  wire logic             f_cmd_write,
  input  wire logic [MC_AW-1:0] f_cmd_addr,
  input  wire logic [LW-1:0]    f_cmd_len,
  input  wire logic [TW-1:0]    f_cmd_tag,
  input  wire logic             f_wd_valid,
  output logic                  f_wd_ready,
  input  wire logic [DW-1:0]    f_wd_data,
  input  wire logic [SB-1:0]    f_wd_strb,
  input  wire logic             f_wd_last,
  output logic                  f_rd_valid,
  input  wire logic             f_rd_ready,
  output logic [DW-1:0]         f_rd_data,
  output logic [TW-1:0]         f_rd_tag,
  output logic                  f_rd_last,
  output logic                  f_rd_error,
  output logic                  f_wr_valid,
  input  wire logic             f_wr_ready,
  output logic [TW-1:0]         f_wr_tag,
  output logic                  f_wr_error,
  // ---------------------------------------------------------------- controller side
  input  wire logic             mc_clk,
  output logic                  m_rst_n,
  input  wire logic             m_init_done,
  input  wire logic             m_fatal,
  output logic                  m_cmd_valid,
  input  wire logic             m_cmd_ready,
  output logic                  m_cmd_write,
  output logic [MC_AW-1:0]      m_cmd_addr,
  output logic [LW-1:0]         m_cmd_len,
  output logic [TW-1:0]         m_cmd_tag,
  output logic                  m_wd_valid,
  input  wire logic             m_wd_ready,
  output logic [DW-1:0]         m_wd_data,
  output logic [SB-1:0]         m_wd_strb,
  output logic                  m_wd_last,
  input  wire logic             m_rd_valid,
  output logic                  m_rd_ready,
  input  wire logic [DW-1:0]    m_rd_data,
  input  wire logic [TW-1:0]    m_rd_tag,
  input  wire logic             m_rd_last,
  input  wire logic             m_rd_error,
  input  wire logic             m_wr_valid,
  output logic                  m_wr_ready,
  input  wire logic [TW-1:0]    m_wr_tag,
  input  wire logic             m_wr_error
);
  // ------------------------------------------------------------ resets
  wire f_link_rst_n = rst_n && f_mc_rst_n;            // fabric-domain flops only
  extmem_rst_sync #(.STAGES(SYNC)) u_mrst (.clk(mc_clk), .rst_ni(f_link_rst_n), .rst_no(m_rst_n));

  // ------------------------------------------------------------ status: controller -> fabric
  extmem_sync #(.W(2), .STAGES(SYNC)) u_st (
    .clk, .rst_n(f_link_rst_n), .d({m_fatal, m_init_done}), .q({f_fatal, f_init_done}));

  // ------------------------------------------------------------ command
  logic [CMDW-1:0] cmd_r;
  extmem_async_fifo #(.W(CMDW), .DEPTH(DEPTH), .SYNC(SYNC)) u_cmd (
    .wclk(clk), .wrst_n(f_link_rst_n), .w_valid(f_cmd_valid), .w_ready(f_cmd_ready),
    .w_data({f_cmd_write, f_cmd_addr, f_cmd_len, f_cmd_tag}),
    .rclk(mc_clk), .rrst_n(m_rst_n), .r_valid(m_cmd_valid), .r_ready(m_cmd_ready), .r_data(cmd_r));
  assign {m_cmd_write, m_cmd_addr, m_cmd_len, m_cmd_tag} = cmd_r;

  // ------------------------------------------------------------ write data
  logic [WDW-1:0] wd_r;
  extmem_async_fifo #(.W(WDW), .DEPTH(DEPTH), .SYNC(SYNC)) u_wd (
    .wclk(clk), .wrst_n(f_link_rst_n), .w_valid(f_wd_valid), .w_ready(f_wd_ready),
    .w_data({f_wd_data, f_wd_strb, f_wd_last}),
    .rclk(mc_clk), .rrst_n(m_rst_n), .r_valid(m_wd_valid), .r_ready(m_wd_ready), .r_data(wd_r));
  assign {m_wd_data, m_wd_strb, m_wd_last} = wd_r;

  // ------------------------------------------------------------ read data
  logic [RDW-1:0] rd_f;
  extmem_async_fifo #(.W(RDW), .DEPTH(DEPTH), .SYNC(SYNC)) u_rd (
    .wclk(mc_clk), .wrst_n(m_rst_n), .w_valid(m_rd_valid), .w_ready(m_rd_ready),
    .w_data({m_rd_data, m_rd_tag, m_rd_last, m_rd_error}),
    .rclk(clk), .rrst_n(f_link_rst_n), .r_valid(f_rd_valid), .r_ready(f_rd_ready), .r_data(rd_f));
  assign {f_rd_data, f_rd_tag, f_rd_last, f_rd_error} = rd_f;

  // ------------------------------------------------------------ write responses
  logic [WRW-1:0] wr_f;
  extmem_async_fifo #(.W(WRW), .DEPTH(DEPTH), .SYNC(SYNC)) u_wr (
    .wclk(mc_clk), .wrst_n(m_rst_n), .w_valid(m_wr_valid), .w_ready(m_wr_ready),
    .w_data({m_wr_tag, m_wr_error}),
    .rclk(clk), .rrst_n(f_link_rst_n), .r_valid(f_wr_valid), .r_ready(f_wr_ready), .r_data(wr_f));
  assign {f_wr_tag, f_wr_error} = wr_f;
endmodule

`default_nettype wire
