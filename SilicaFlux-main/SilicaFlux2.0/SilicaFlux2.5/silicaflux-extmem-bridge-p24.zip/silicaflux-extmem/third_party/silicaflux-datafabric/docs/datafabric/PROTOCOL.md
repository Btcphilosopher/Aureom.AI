# SFB2 — SilicaFlux Bus, revision 2 (DataFabric)

SFB2 is the on-chip request/response protocol of SilicaFlux DataFabric. It
**extends** the SilicaFlux-V release-1 SFB (`third_party/silicaflux-v/docs/BUS.md`, an
OBI-style req/gnt + rvalid protocol) instead of introducing a competing protocol:

* the request channel is SFB's, renamed to valid/ready terms;
* the response channel gains **back-pressure** (`rsp_ready`);
* the data width becomes a parameter (32/64/128);
* legacy SFB slaves keep working unmodified behind `sfb_v1_slave_adapter`, and
  legacy SFB masters connect by tying `rsp_ready = 1`.

Backward compatibility is demonstrated: silicaflux-v's **unmodified** crossbar cocotb
test (`tb/interconnect/v1compat/test_xbar.py`, byte-identical) passes against
`sfb_crossbar`, and the six release-1 SoC firmware scenarios run on `sfv_soc_df` with
**cycle-identical** results (`reports/datafabric/soc_regression.md`).

## 1. Signals (master view)

| Signal | Width | Dir | Meaning | SFB v1 name |
|---|---|---|---|---|
| `req_valid` | 1 | out | request valid | `req` |
| `req_ready` | 1 | in | request accepted this cycle | `gnt` |
| `req_write` | 1 | out | 1 = write | `we` |
| `req_addr` | AW (32) | out | byte address | `addr` |
| `req_wdata` | DW | out | write data (don't care for reads) | `wdata` |
| `req_wstrb` | DW/8 | out | byte write enables (don't care for reads) | `be` |
| `rsp_valid` | 1 | in | response valid | `rvalid` |
| `rsp_ready` | 1 | out | response accepted this cycle | — (always 1) |
| `rsp_rdata` | DW | in | read data; 0 for writes and errors | `rdata` |
| `rsp_error` | 1 | in | transaction failed | `err` |

`AW = 32`. `DW ∈ {32, 64, 128}` (any power-of-two multiple of 8 elaborates).
`CLOCK_FREQUENCY` is **not** an RTL parameter: it is set by the SDC/physical
constraints. Software-visible layout is **little-endian**: byte lane `b` of
`req_wdata`/`rsp_rdata` is bits `[8b+7:8b]` and holds address `A + b` of the
DW-aligned word at `A`.

## 2. Rules

| # | Rule |
|---|---|
| R1 | A request transfers on a rising edge where `req_valid && req_ready`; a response where `rsp_valid && rsp_ready`. |
| R2 | Once `req_valid` is asserted it stays asserted, with `req_write/addr/wstrb` (and `wdata` for writes) unchanged, until accepted. **No cancellation**: a master may not withdraw a presented request. (Fabric tolerance: the crossbar never samples an un-accepted payload, so the legacy CPU instruction port's documented behaviour — silicaflux-v ISS-017 — remains harmless; the arbiter is verified with withdrawn requests.) |
| R3 | `req_valid` must not depend combinationally on `req_ready`. `req_ready` may depend combinationally on `req_valid`/`req_addr` (as in SFB v1). |
| R4 | `rsp_valid` must not depend combinationally on `rsp_ready`; a response held (`rsp_valid && !rsp_ready`) stays valid with unchanged `rsp_rdata`/`rsp_error`. `rsp_ready` may depend on `rsp_valid`, but **not** on `req_ready`. A slave's `req_ready` may depend on its own `rsp_ready` (accept-while-retiring). |
| R5 | Exactly one response per accepted request, in acceptance order, never in the acceptance cycle (≥ 1 cycle later). |
| R6 | **Outstanding limit (rev 2.0):** every `sfb_crossbar` master port and slave port carries at most **one** transaction. A master may present its next request while its previous response is pending; the crossbar accepts it no earlier than the cycle in which that response is accepted (full throughput, one transaction per cycle per port with 1-cycle slaves). A master connected *directly* to a slave must itself limit its outstanding count to what it can track (the buffered DMA tracks `MAX_OUT`). |
| R7 | **Write completion:** the response to a write is issued only after the write has been performed by the target (array written / register side effect taken). `sfb_v1_slave_adapter`, `sfb_sram_slave` and `sfb_sram_1r1w_slave` all respond strictly after the write edge. Completion of a DMA therefore implies all of its writes have completed. |
| R8 | `rsp_error = 1` marks a failed transaction; `rsp_rdata` is then 0. Causes: unmapped address, access-matrix denial, misaligned address (fabric decode error); ROM write, peripheral sub-word write, out-of-range SRAM word, poisoned access (slave errors). A write answered with an error has **no side effect** for every DataFabric and SilicaFlux-V slave. |
| R9 | **Alignment:** `req_addr` is DW-aligned (`addr[log2(DW/8)-1:0] = 0`). With `CHECK_ALIGN = 1` (default) the crossbar answers a misaligned request with a decode error and no slave sees it. |
| R10 | **Transfer size:** one data beat per transaction; 1..DW/8 bytes via `req_wstrb` (any pattern, including sparse). Reads always return the full word. SFB2 has **no native bursts**; a "burst" is a sequence of single-beat transactions (the buffered DMA issues them back to back). |
| R11 | **Reset:** asynchronous assert, synchronous release (`sfv_rst_sync`), shared by masters, fabric and slaves (`sys_rst_n`). Reset cancels every transaction in flight: no response is delivered for it; an accepted write may or may not have been performed (a write still inside an `sfb_reg_slice` is dropped). During reset `req_ready`/`rsp_valid` of the fabric are 0, so reset can generate no transfer. |
| R12 | **Ordering/latency:** responses per master are in order (R5 + R6). The crossbar adds **0 cycles** in both directions; `sfb_reg_slice` adds one cycle per sliced direction. Slave latency is arbitrary (≥ 1 cycle), e.g. SRAM-library READ_LATENCY 1..N. |

## 3. Combinational paths and loop freedom

Crossbar paths: `m_req_* → s_req_*`, `s_req_ready → m_req_ready`, `s_rsp_* → m_rsp_*`,
`m_rsp_ready → s_rsp_ready`, and `m_rsp_ready, s_rsp_valid → s_req_valid` (a slave is
freed in the cycle its response is accepted). With R3/R4 these form no cycle: every
loop would need a `valid` that depends on its own `ready`, or a slave `rsp_valid`
that depends on `req_valid` in the same cycle (forbidden by R5). Insert
`sfb_reg_slice` to cut long paths; it registers both valid/data and ready.

## 4. Arbitration and fairness

`sfb_arbiter`, one per slave port: `ARB_MODE = 0` fixed priority (master 0 highest),
`1` round robin (pointer moves past the winner only on **acceptance**). A granted
request that was presented to the slave but not accepted keeps the grant next
cycle (**grant lock**), so the slave-side payload is stable (R2 at the slave port).
Proven (ABC PDR, unbounded): exclusive one-hot grant, work conservation, lock, and
round-robin bounded waiting (≤ N−1 other acceptances while a request waits).
Fixed priority starves lower masters under sustained contention (demonstrated in
`reports/datafabric/benchmark.md`); SilicaFlux-V uses round robin.

## 5. Errors

| Source | Detected by | Response | Side effect |
|---|---|---|---|
| Unmapped address | crossbar decoder | error, 1 cycle after acceptance | none |
| Access-matrix denial (`MST_SLV_EN`) | crossbar decoder | error | none |
| Misaligned address (`CHECK_ALIGN`) | crossbar decoder | error | none |
| ROM write / peripheral sub-word write / bad page | SilicaFlux-V slaves | error | none |
| SRAM word ≥ DEPTH | `sram_sp` | error | none |

The first decode error of each cycle is exported (`err_evt/err_addr/err_master/err_write`)
for SilicaFlux-V's `SYSCTRL.BUSERR_*` capture registers.

## 6. Memory map

Single source of truth: `memmap/silicaflux_v_datafabric.yaml`, generated into SV, C,
Python and `docs/datafabric/MEMORY_MAP.md`. Unmapped addresses are never aliased.

## 7. Register slices and outstanding transactions

`sfb_reg_slice` is protocol-transparent but stores up to one transaction per sliced
channel. Between a crossbar slave port and its slave (the intended place: long
wires to SRAM macros) the crossbar's one-outstanding rule still holds end to end.
Between a master and a crossbar master port it lets the master have one more
transaction in flight than the crossbar sees — only acceptable for masters that
track their own outstanding count.

## 8. Route to transaction IDs and multiple outstanding transactions

Not implemented in rev 2.0 (deliberately: correctness first). The planned extension
is additive and keeps rev-2.0 components legal:

1. add `req_id`/`rsp_id` (ID_W bits, default 0) — SRAM-library cores already carry an ID;
2. replace the crossbar's per-slave `owner_q` register by an owner FIFO of depth
   `SLV_MAX_OUT` and the per-master `out_q` bit by a counter (`MST_MAX_OUT`);
3. per-master response ordering stays in-order per ID; responses of different
   slaves to one master are re-ordered only if IDs differ (otherwise the crossbar
   blocks a master from targeting a second slave while one is outstanding);
4. `sfb_protocol_checker` already supports `MAX_OUT > 1` and tracks write/read
   types per outstanding transaction.

## 9. Tool-portability rules learnt in this project

* **Never use unsized fill literals (`'0`, `'1`) in parameter defaults or
  overrides.** Yosys 0.33 sizes an overriding `'1` to one bit: `.MST_SLV_EN('1)`
  enabled only master 0 → slave 0 in synthesis while every simulator was correct.
  Found by inconsistent synthesis results; now prevented by sized literals and by
  gate-level simulation (`make datafabric-gls`).
* No `int'()` casts in RTL (Yosys 0.33 front end rejects them); no local variable
  declarations in unnamed blocks of formal harnesses.
* The rules of `third_party/silicaflux-v/docs/RTL_CODING_RULES.md` apply unchanged
  (flat ports, no interfaces/structs/package imports in synthesizable RTL).
  `tb/common/sfb_protocol_checker.sv` is the verification-only counterpart of an
  `sfb_if` interface bundle.
