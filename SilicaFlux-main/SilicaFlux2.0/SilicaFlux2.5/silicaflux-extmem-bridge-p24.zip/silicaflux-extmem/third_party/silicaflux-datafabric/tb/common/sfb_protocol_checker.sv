// =============================================================================
// SilicaFlux DataFabric :: sfb_protocol_checker -- SFB2 port monitor/assertions
//
// Bind or instantiate on any SFB2 port (all inputs).  Checks, every cycle
// after reset (rule numbers refer to docs/datafabric/PROTOCOL.md):
//   R2  a request held (valid && !ready) stays valid with an unchanged payload
//       in the next cycle (waived when ALLOW_REQ_CHANGE = 1: legacy CPU
//       instruction port, silicaflux-v ISS-017);
//   R4  a response held (valid && !ready) stays valid and unchanged;
//   R5  no response without an outstanding request (outstanding counted from
//       request and response handshakes; responses >= 1 cycle after accept);
//   R6  outstanding transactions never exceed MAX_OUT;
//   R8  error responses and write responses carry rsp_rdata == 0
//       (CHECK_RDATA_ZERO = 1; requires MAX_OUT <= 8 for the type FIFO);
//   X   no X/Z on req_valid / rsp_valid / ready after reset (simulation).
// `violations` counts failures (simulation and synthesis-free); each failure
// also prints an $error message in simulation.  Under `FORMAL` the same
// conditions are emitted as immediate `assert` statements.
// Verification only (lives in tb/common): never instantiate in synthesizable RTL.
// =============================================================================
`default_nettype none

module sfb_protocol_checker #(
  parameter int AW               = 32,
  parameter int DW               = 32,
  parameter int MAX_OUT          = 1,
  parameter int ALLOW_REQ_CHANGE = 0,
  parameter int CHECK_RDATA_ZERO = 1,
  parameter     NAME             = "sfb",
  localparam int SB              = DW / 8
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          req_valid,
  input  wire logic          req_ready,
  input  wire logic          req_write,
  input  wire logic [AW-1:0] req_addr,
  input  wire logic [DW-1:0] req_wdata,
  input  wire logic [SB-1:0] req_wstrb,
  input  wire logic          rsp_valid,
  input  wire logic          rsp_ready,
  input  wire logic [DW-1:0] rsp_rdata,
  input  wire logic          rsp_error,
  output logic [31:0]        violations,
  output logic [31:0]        n_req,
  output logic [31:0]        n_rsp,
  output logic [31:0]        outstanding
);
  logic          p_req_hold, p_rsp_hold;
  logic          p_write;
  logic [AW-1:0] p_addr;
  logic [DW-1:0] p_wdata, p_rdata;
  logic [SB-1:0] p_wstrb;
  logic          p_err;
  logic [7:0]    wtype;              // FIFO of write flags of outstanding requests
  logic [31:0]   viol;

  wire req_hs = req_valid && req_ready;
  wire rsp_hs = rsp_valid && rsp_ready;

  function automatic logic is_x(input logic v);
    is_x = (v !== 1'b0) && (v !== 1'b1);
  endfunction

`ifndef SYNTHESIS
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      p_req_hold  <= 1'b0;
      p_rsp_hold  <= 1'b0;
      outstanding <= 0;
      viol         = 0;
      violations  <= 0;
      n_req       <= 0;
      n_rsp       <= 0;
      wtype       <= '0;
    end else begin
      // ---------------------------------------------------------- X checks
      if (is_x(req_valid) || is_x(rsp_valid) || is_x(req_ready) || is_x(rsp_ready)) begin
        viol = viol + 1;
        $error("[%s] X/Z on a handshake signal", NAME);
      end
      // ---------------------------------------------------------- R2
      if (p_req_hold && ALLOW_REQ_CHANGE == 0) begin
        if (!req_valid) begin
          viol = viol + 1;
          $error("[%s] R2: req_valid dropped before acceptance", NAME);
        end else if (req_write !== p_write || req_addr !== p_addr || req_wstrb !== p_wstrb ||
                     (p_write && req_wdata !== p_wdata)) begin
          viol = viol + 1;
          $error("[%s] R2: request payload changed before acceptance", NAME);
        end
      end
      // ---------------------------------------------------------- R4
      if (p_rsp_hold) begin
        if (!rsp_valid) begin
          viol = viol + 1;
          $error("[%s] R4: rsp_valid dropped before acceptance", NAME);
        end else if (rsp_rdata !== p_rdata || rsp_error !== p_err) begin
          viol = viol + 1;
          $error("[%s] R4: response payload changed before acceptance", NAME);
        end
      end
      // ---------------------------------------------------------- R5 / R6
      if (rsp_valid && outstanding == 0) begin
        viol = viol + 1;
        $error("[%s] R5: response without an outstanding request", NAME);
      end
      // ---------------------------------------------------------- R8
      if (CHECK_RDATA_ZERO != 0 && rsp_hs && outstanding != 0 &&
          (rsp_error || wtype[0]) && rsp_rdata != '0) begin
        viol = viol + 1;
        $error("[%s] R8: rsp_rdata not zero on an error/write response", NAME);
      end
      if (req_hs && rsp_hs) begin
        // shift out the retiring entry, append the new one
        wtype <= (wtype >> 1) | (8'(req_write) << (outstanding - 1));
      end else if (req_hs) begin
        wtype <= wtype | (8'(req_write) << outstanding);
      end else if (rsp_hs) begin
        wtype <= wtype >> 1;
      end
      if (int'(outstanding) + int'(req_hs) - int'(rsp_hs && outstanding != 0) > MAX_OUT) begin
        viol = viol + 1;
        $error("[%s] R6: more than %0d transactions outstanding", NAME, MAX_OUT);
      end
      outstanding <= outstanding + (req_hs ? 1 : 0) - ((rsp_hs && outstanding != 0) ? 1 : 0);
      n_req       <= n_req + (req_hs ? 1 : 0);
      n_rsp       <= n_rsp + (rsp_hs ? 1 : 0);
      p_req_hold  <= req_valid && !req_ready;
      p_rsp_hold  <= rsp_valid && !rsp_ready;
      p_write     <= req_write;
      p_addr      <= req_addr;
      p_wdata     <= req_wdata;
      p_wstrb     <= req_wstrb;
      p_rdata     <= rsp_rdata;
      p_err       <= rsp_error;
      violations  <= viol;
    end
  end
`else
  assign violations  = 0;
  assign n_req       = 0;
  assign n_rsp       = 0;
  assign outstanding = 0;
`endif
endmodule

`default_nettype wire
