# Vendored: SilicaFlux DataFabric (Project 03) -- unmodified subset

Source: `btcphilosopher/Aureom.AI`, file `SilicaFlux-main/silicaflux-datafabric.zip`
(sha256 `9f1f37357c8e25e00c214227894bca37c45e18ae9d7a993f87039a7679b665fb`,
last changed in commit `531137f247ae5ead1678d730e4ac0f5f1238c118`), directory
`silicaflux-datafabric/`.  Files are byte-identical copies; `SHA256SUMS` lists
them (`sha256sum -c SHA256SUMS`).

| File | Used for |
|---|---|
| `rtl/interconnect/sfb_*.sv` | real SFB2 crossbar in `tb/tb_df_integration.sv` (bridge as a crossbar slave) |
| `rtl/dma/dma_burst_engine.sv`, `dma_fifo.sv`, `dma_validate.sv`, `dma_defs.svh` | real DataFabric DMA engine (buffered, dual port) moving data SRAM <-> external memory |
| `rtl/dma/dma_transfer_engine.sv` | simple (baseline) DataFabric DMA engine, second integration configuration |
| `tb/common/sfb_protocol_checker.sv` | DataFabric's own SFB2 port checker on the bridge's upstream port (SFB2-compatible configurations) |
| `docs/datafabric/PROTOCOL.md` | the SFB2 rev 2.0 specification the upstream port extends |

Nothing here is modified; the bridge does not depend on these files for
synthesis.
