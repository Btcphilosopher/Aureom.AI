# Throughput, latency and utilisation

All numbers: RTL cycle simulation (`scripts/run_perf.py`, test `bench` of `tb/tb_extmem.sv` with every
scoreboard check active) against `extmem_sim_mc`, a **simulation-only** controller model whose latencies are
hypothetical cycle counts.  They characterise the **bridge** (how much latency it hides, where it stalls), not
any DRAM device.  Counters come from the bridge's own `extmem_perf` block.  MB/s columns assume a 100 MHz fabric
clock for planning only.

## Theoretical peaks of the bridge

| Path | Peak | DW = 64 at 100 MHz |
|---|---|---|
| upstream read data (rsp channel) | 1 beat / cycle | 800 MB/s |
| upstream write data (req channel) | 1 beat / cycle | 800 MB/s |
| MC interface read data / write data | 1 beat / cycle each (separate channels) | 800 MB/s each |
| simulated controller data bus (model, half-duplex) | 1 beat / cycle shared + turnaround | 800 MB/s total |
| latency hiding (Little's law) | sustained <= MAX_RD_OUT x burst / round trip | |

## 1. Outstanding reads vs controller latency (16-beat sequential reads)

| MAX_RD_OUT | model latency | sustained rd beats/cycle | Little's-law bound | avg read latency (cycles) | avg busy read slots | MB/s @100 MHz |
|---|---|---|---|---|---|---|
| 1 | 10 | 0.503 | 0.503 | 31.8 | 0.97 | 402.7 |
| 1 | 40 | 0.259 | 0.259 | 61.8 | 0.98 | 207.2 |
| 2 | 10 | 0.959 | 0.961 | 33.3 | 1.93 | 766.9 |
| 2 | 40 | 0.511 | 0.512 | 62.5 | 1.96 | 408.7 |
| 4 | 10 | 0.995 | 1.000 | 64.0 | 3.92 | 796.4 |
| 4 | 40 | 0.970 | 0.974 | 65.7 | 3.92 | 776.1 |
| 8 | 10 | 0.995 | 1.000 | 127.5 | 7.87 | 796.4 |
| 8 | 40 | 0.992 | 1.000 | 127.9 | 7.87 | 793.9 |
| 16 | 10 | 0.995 | 1.000 | 253.2 | 15.69 | 796.4 |
| 16 | 40 | 0.992 | 1.000 | 254.0 | 15.69 | 793.9 |

Round-trip latency = upstream acceptance to last beat delivered (includes the model latency, the data
transfer and the bridge's own pipeline: command register, read buffer, response register).

## 2. Burst length (8 read slots, model latency 40)

| burst (beats) | rd beats/cycle | avg read latency | MC burst utilisation (beats per command / MAX_BURST) | MB/s @100 MHz |
|---|---|---|---|---|
| 1 | 0.172 | 46.4 | 0.062 | 137.9 |
| 2 | 0.335 | 47.8 | 0.125 | 267.7 |
| 4 | 0.631 | 50.5 | 0.25 | 505.2 |
| 8 | 0.992 | 64.1 | 0.5 | 793.9 |
| 16 | 0.992 | 127.9 | 1.0 | 793.9 |

## 3. Read/write mix: FIFO baseline vs read priority + write batching

Random addresses over 64 KiB, 4-beat bursts, model latency 20 (+ toy row/bank timing), out-of-order controller.
`cmd_rdy` = probability per cycle that the controller accepts a command: 100 % models a controller with a deep
command queue (it absorbs everything, the bridge's queues stay empty), 40 % one with a shallow queue (commands
back up in the bridge, so its scheduler has a choice).  The model charges a 2-slot read/write turnaround on its
shared data bus; any difference therefore reflects that **model** property, not a measured DRAM effect.

| cmd_rdy | read % | scheduler | total beats/cycle | rd lat avg | wr lat avg | direction switches | arbitration bypasses | hazard stalls | avg rd-queue occupancy |
|---|---|---|---|---|---|---|---|---|---|
| 100 % | 100 | FIFO | 0.906 | 35.0 | None | 0 | 0 | 0 | 0.23 |
| 100 % | 100 | RPRIO+BATCH | 0.906 | 35.0 | None | 0 | 0 | 0 | 0.23 |
| 100 % | 75 | FIFO | 0.824 | 49.3 | 51.2 | 529 | 0 | 0 | 0.16 |
| 100 % | 75 | RPRIO+BATCH | 0.824 | 49.3 | 51.2 | 529 | 0 | 0 | 0.16 |
| 100 % | 50 | FIFO | 0.787 | 66.3 | 64.4 | 758 | 0 | 0 | 0.1 |
| 100 % | 50 | RPRIO+BATCH | 0.787 | 66.3 | 64.4 | 758 | 0 | 0 | 0.1 |
| 100 % | 25 | FIFO | 0.793 | 55.9 | 49.1 | 565 | 0 | 0 | 0.05 |
| 100 % | 25 | RPRIO+BATCH | 0.793 | 55.9 | 49.1 | 565 | 0 | 0 | 0.05 |
| 100 % | 0 | FIFO | 0.758 | None | 38.8 | 0 | 0 | 0 | 0.0 |
| 100 % | 0 | RPRIO+BATCH | 0.758 | None | 38.8 | 0 | 0 | 0 | 0.0 |
| 40 % | 100 | FIFO | 0.830 | 38.3 | None | 0 | 0 | 0 | 0.3 |
| 40 % | 100 | RPRIO+BATCH | 0.830 | 38.3 | None | 0 | 0 | 0 | 0.3 |
| 40 % | 75 | FIFO | 0.808 | 49.7 | 50.8 | 512 | 110 | 0 | 0.35 |
| 40 % | 75 | RPRIO+BATCH | 0.786 | 52.4 | 54.5 | 526 | 189 | 0 | 0.29 |
| 40 % | 50 | FIFO | 0.790 | 65.5 | 63.1 | 741 | 192 | 0 | 0.35 |
| 40 % | 50 | RPRIO+BATCH | 0.798 | 64.5 | 61.1 | 683 | 212 | 0 | 0.27 |
| 40 % | 25 | FIFO | 0.768 | 56.9 | 50.5 | 541 | 114 | 0 | 0.15 |
| 40 % | 25 | RPRIO+BATCH | 0.781 | 57.3 | 50.5 | 527 | 116 | 0 | 0.15 |
| 40 % | 0 | FIFO | 0.715 | None | 41.4 | 0 | 0 | 0 | 0.0 |
| 40 % | 0 | RPRIO+BATCH | 0.715 | None | 41.4 | 0 | 0 | 0 | 0.0 |

## 4. Response ordering with a widely varying latency (5..120 cycles, 4-beat random reads)

| upstream ordering | rd beats/cycle | avg read latency | max read latency |
|---|---|---|---|
| UP_OOO=0 (in order) | 0.304 | 104.3 | 150 |
| UP_OOO=1 (per-ID) | 0.366 | 86.7 | 135 |

## 5. Single-beat SFB2 traffic (DataFabric crossbar style: DW 32, MAX_BURST 1, 3 read slots)

| model latency | rd beats/cycle | avg read latency | MB/s @100 MHz |
|---|---|---|---|
| 4 | 0.298 | 10.0 | 119.1 |
| 20 | 0.115 | 26.0 | 46.0 |
| 40 | 0.065 | 46.0 | 26.1 |

Behind the DataFabric `sfb_crossbar` (rev 2.0: one outstanding transaction per slave port) the bridge sees
a single transaction at a time; `reports/df_integration.log` measures 0.21 B/cycle (DMA SRAM->EXT, model latency
4..20) against 4 B/cycle peak for DW = 32.  Bandwidth from external DRAM therefore requires the SFB2-X direct
port (bursts + multiple outstanding) or the crossbar extension planned in DataFabric PROTOCOL.md section 8.

