# Lint

`scripts/lint.py`: Verilator 5.020 `--lint-only -Wall` (no waivers on the command line; the few in-source
waivers are commented) on the synthesizable RTL for every configuration file plus corner parameter sets;
Icarus 12 `-g2012` elaboration.

* Verilator -Wall clean: **21 / 21** parameter sets
* Icarus elaboration errors: **0** (Icarus prints 'sorry: constant selects in always_*' notes -- a
  sensitivity-list limitation of Icarus, not an error)

| Parameter set | Verilator -Wall |
|---|---|
| async_fast_mc | clean |
| async_slow_mc | clean |
| base | clean |
| big_burst | clean |
| mc_ooo_inorder_up | clean |
| min | clean |
| odd_slots | clean |
| ooo_full | clean |
| rprio_batch | clean |
| sfb2_compat | clean |
| stall_policy | clean |
| wide_tight | clean |
| asic_ddr5_axi_licensed | clean |
| fpga_arty_a7_ddr3l_mig | clean |
| fpga_ulx3s_sdram_litedram | clean |
| hbm3_research | clean |
| corner_dw512_mb2 | clean |
| corner_nr1_nw16 | clean |
| corner_lw4_mb16 | clean |
| corner_idw16_ooo | clean |
| corner_policy1_noperf | clean |
