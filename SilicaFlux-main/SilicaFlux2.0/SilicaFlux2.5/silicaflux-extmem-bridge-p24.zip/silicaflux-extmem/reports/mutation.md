# Mutation testing

`scripts/mutate.py`: 33 injected design bugs, **32 killed** by the test suite, 1 documented equivalent mutant(s), 0 surviving (tests: smoke, concurrent_rw, partial_writes, long_bursts, addr_bounds, proto_err, mc_errors, reset_traffic, mc_unavailable, quiesce_reset, unavail, ooo, backpressure, random_latency; seed 1, 400 transactions each; 205 s).

| Mutant | File | Bug | Config | Result | First failure |
|---|---|---|---|---|---|
| FE_RANGE_OBO | extmem_frontend.sv | range check off by one BYTE at the window top -- EQUIVALENT: an aligned burst ends at SB-1 mod SB, never at LIM+1 | base | **EQUIVALENT** |  |
| FE_RANGE_BEAT | extmem_frontend.sv | range check off by one BEAT at the top of the window | base | **KILLED** | addr_bounds: [3725000] TB ERROR: expected an error response, got OK |
| FE_NO_ALIGN | extmem_frontend.sv | misaligned addresses not rejected | base | **KILLED** | addr_bounds: [3165000] SIM_MC VIOLATION: command address outside model |
| FE_NO_BOUND | extmem_frontend.sv | boundary-crossing bursts not rejected | base | **KILLED** | addr_bounds: [5475000] TB ERROR: expected an error response, got OK |
| FE_NO_PROTO | extmem_frontend.sv | write-burst framing errors not detected | base | **KILLED** | proto_err: [985000] TB ERROR: expected an error response, got OK |
| FE_MCADDR | extmem_frontend.sv | wrong controller address translation | base | **KILLED** | smoke: [865000] TB ERROR: read data mismatch |
| FE_WBUF_BEAT | extmem_frontend.sv | all write beats stored in the same buffer entry | base | **KILLED** | smoke: [5515000] TB ERROR: read data mismatch |
| FE_NO_UNAVAIL | extmem_frontend.sv | requests not refused while the controller is unavailable | base | **KILLED** | mc_unavailable: [9115000] TB ERROR: expected an error response, got OK |
| FE_STRB | extmem_frontend.sv | byte enables ignored | base | **KILLED** | smoke: [5535000] TB ERROR: read data mismatch |
| FE_WID | extmem_frontend.sv | write ID taken from the last beat instead of the first | ooo_full | **KILLED** | smoke: [1205000] TB ERROR: response for an ID with nothing outstanding (unsolicited / duplicate) |
| TR_NO_RD_FREE | extmem_tracker.sv | read slot never released (resource leak) | base | **KILLED** | smoke: RESULT FAIL test=smoke seed=1 errors=timeout |
| TR_FLUSH_RD | extmem_tracker.sv | fault flush does not complete outstanding reads | base | **KILLED** | mc_unavailable: [2009110000] TB ERROR: responses lost: transactions still outstanding after drain |
| TR_WERR | extmem_tracker.sv | controller write errors dropped | base | **KILLED** | mc_errors: [965000] TB ERROR: expected an error response, got OK |
| TR_RBUF_BEAT | extmem_tracker.sv | read beats written to the same buffer entry | base | **KILLED** | smoke: [1015000] TB ERROR: read data mismatch |
| TR_RERR | extmem_tracker.sv | controller read errors dropped | base | **KILLED** | mc_errors: [1375000] TB ERROR: expected an error response, got OK |
| TR_EARLY_COMP | extmem_tracker.sv | read considered complete one beat early | base | **KILLED** | smoke: RESULT FAIL test=smoke seed=1 errors=timeout |
| SC_FIFO_ORDER | extmem_sched.sv | FIFO scheduler lets reads bypass older writes (RAW hazard) | base | **KILLED** | concurrent_rw: [35895000] TB ERROR: read data mismatch |
| SC_NO_HAZARD | extmem_sched.sv | read-priority scheduler ignores read-after-write hazards | rprio_batch | **KILLED** | concurrent_rw: [42945000] TB ERROR: read data mismatch |
| SC_NO_WAR | extmem_sched.sv | write batching ignores write-after-read hazards | rprio_batch | **KILLED** | concurrent_rw: [37935000] TB ERROR: read data mismatch |
| SC_WD_BEAT | extmem_sched.sv | write data beats sent from the wrong buffer entry | base | **KILLED** | smoke: [5525000] TB ERROR: read data mismatch |
| SC_TAG | extmem_sched.sv | read tag = queue index instead of slot (misassociation) | mc_ooo_inorder_up | **KILLED** | smoke: [9245000] TB ERROR: read data mismatch |
| SC_FLUSH_CMD | extmem_sched.sv | stale command survives a controller fault | base | **KILLED** | mc_unavailable: [99900000] TB ERROR: bridge flagged controller protocol violations |
| RB_INORDER | extmem_rob.sv | in-order (SFB2 R5) upstream receives out-of-order responses | mc_ooo_inorder_up | **KILLED** | concurrent_rw: [15965000] TB ERROR: rsp_last framing wrong (lost / extra beats) |
| RB_SAME_ID | extmem_rob.sv | out-of-order mode breaks per-ID order | ooo_full | **KILLED** | concurrent_rw: [15965000] TB ERROR: rsp_last framing wrong (lost / extra beats) |
| RB_ZERO_ERR | extmem_rob.sv | error beats carry controller garbage instead of 0 (SFB2 R8) | base | **KILLED** | mc_errors: [1375000] up SFB2-X VIOLATION: X3 rdata not zero on error/write |
| RB_FLUSH_OK | extmem_rob.sv | flushed read beats reported as OK | base | **KILLED** | mc_unavailable: [6395000] TB ERROR: read data mismatch |
| RB_NO_WR_FREE | extmem_rob.sv | write slot never released | base | **KILLED** | smoke: RESULT FAIL test=smoke seed=1 errors=timeout |
| RB_DUP_RSP | extmem_rob.sv | a write response can be emitted twice (duplicate completion) | base | **KILLED** | concurrent_rw: [41025000] TB ERROR: response ID differs from the oldest transaction (order) |
| CT_ACCEPT | extmem_ctrl.sv | requests sent to a controller that is not calibrated | base | **KILLED** | mc_unavailable: [9115000] TB ERROR: expected an error response, got OK |
| CT_NO_WDOG | extmem_ctrl.sv | hung controller never detected | base | **KILLED** | mc_unavailable: RESULT FAIL test=mc_unavailable seed=1 errors=timeout |
| CT_NO_MCRST | extmem_ctrl.sv | controller reset never driven (stale commands / responses survive a fault) | base | **KILLED** | smoke: [15000] mc MC-CHECK VIOLATION: C5 read beat for a tag that is not live |
| CDC_FULL | cdc/extmem_async_fifo.sv | async FIFO overflows (full flag one entry late) | async_slow_mc | **KILLED** | smoke: [1896510] mc MC-CHECK VIOLATION: C7 wd_last framing |
| CDC_GRAY | cdc/extmem_async_fifo.sv | binary instead of Gray pointer crossing (a CDC structural bug) | async_fast_mc | **KILLED** | smoke: [806650] mc MC-CHECK VIOLATION: C4 write tag re-issued while live |
