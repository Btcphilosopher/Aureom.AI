# Synthesis and place-and-route characterisation

Open-source flow only (Yosys 0.33, nextpnr-ecp5 0.6, Trellis).  No vendor tool (Vivado / Diamond / Quartus) was
available, so there is no vendor timing sign-off; the Xilinx numbers are Yosys `synth_xilinx` mapping counts.
ECP5 Fmax: post-route, ECP5-85F speed 6 (the ULX3S device used by SilicaFlux-V), bridge inside the
out-of-context harness `synth/extmem_ooc_wrap.sv` (all ports registered), single clock, seed 1.
MC_AW = 28 (256 MiB window), LW = 8.

| Config | Generic: latch-free, check -assert | Generic cells | xc7 LUT | xc7 FF | xc7 LUTRAM | ECP5 LUT4* | ECP5 FF* | ECP5 DPR16X4 | ECP5 Fmax (MHz) |
|---|---|---|---|---|---|---|---|---|---|
| `sfb2_slave` | PASS | 12675 | 3377 | 1984 | 12 | 4443 | 2204 | 18 | 57.0 |
| `base` | PASS | 63240 | 5218 | 3485 | 92 | 7882 | 3781 | 280 | 40.5 |
| `base_noperf` | PASS | 54511 | 3958 | 2541 | 92 | 7566 | 2555 | 280 | 46.7 |
| `ooo_rprio` | PASS | 73115 | 7045 | 3513 | 92 | 9452 | 3840 | 280 | 27.4 |
| `base_async` | PASS | 66417 | 5302 | 3611 | 125 | 7853 | 3907 | 328 | n/a (two clocks) |

\* ECP5 counts include the harness (input shift chain and output fold registers).

* `sfb2_slave`: DataFabric SFB2 slave: DW32, MAX_BURST 1, 3 rd / 2 wr slots, FIFO, in order
* `base`: DW64, 16-beat bursts, 8 rd / 8 wr slots, FIFO scheduler, in order
* `base_noperf`: as base, performance counters removed (PERF = 0)
* `ooo_rprio`: as base + out-of-order upstream + read-priority / batching scheduler
* `base_async`: as base + ASYNC = 1 (async FIFOs to the controller clock); no P&R (two clocks)
