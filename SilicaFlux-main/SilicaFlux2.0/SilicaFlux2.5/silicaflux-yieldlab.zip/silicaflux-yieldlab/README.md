# SilicaFlux YieldLab (Project 12)

Wafer geometry · defect statistics · Monte Carlo fabrication · manufacturing test · cost per good die
— Aureom.AI | SilicaFlux Semiconductor Engineering

YieldLab links the **measured** SilicaFlux-V physical design (FloorplanLab OpenDB exports) to exact wafer geometry,
spatial defect processes, functional-region fatality, SRAM repair scenarios, TestCore-based test detection, binning,
parametric variation, packaging and stage-by-stage economics - with reproducible seeds, lot-aware uncertainty and
input provenance on every number.

> **Every yield in this package is SIMULATED.** No SilicaFlux silicon, wafer map, defect density, foundry quote or
> statistical process data exists in the repository (see `asic/yieldlab/docs/AUDIT.md`). Hypothetical inputs are
> labelled HYPOTHETICAL, missing ones are NOT AVAILABLE and cannot be used by any calculation, and every result carries
> the label "SIMULATED - HYPOTHETICAL SCENARIO". Passing the quality gates demonstrates a working simulator, not
> manufacturability, foundry acceptance or commercial yield.

## Quick start

```bash
pip install -r requirements.txt
```

```bash
make yieldlab-test          # 115 deterministic tests (tests A-R, property tests), junit in asic/yieldlab/reports/ci
```

```bash
make yieldlab-all           # geometry, costs, studies, 1000-wafer run, reports + reproducibility re-run, gates, dashboards
```

Direct CLI (from `asic/yieldlab`, with `PYTHONPATH=python`):

```bash
python -m yieldlab geometry --config configs/silicaflux_v.yaml
```

```bash
python -m yieldlab simulate --config configs/silicaflux_v.yaml --wafers 1000 --seed 42 --costs configs/costs/example_costs.yaml
```

```bash
python -m yieldlab compare --config configs/defect_models.yaml
```

```bash
python -m yieldlab optimise --config configs/area_yield_sweep.yaml
```

```bash
python -m yieldlab report --run-dir reports/<RUN_ID> --verify
```

```bash
python -m yieldlab dashboard --run-dir reports/<RUN_ID>
```

Other commands: `audit --repo`, `poisson`, `clusters`, `cost`, `sweep`, `experiments`, `nodes`, `import`, `calibrate`,
`gates`. Make targets: `yieldlab-test geometry poisson clusters wafer lot cost sweep optimise experiments nodes report
dashboard gates ci all clean` (all prefixed `yieldlab-`).

## What is in the box

```
README.md  Makefile  requirements.txt  pyproject.toml  .github/workflows/yieldlab.yml  ci/
scripts/intake.py            vendor evidence from the repository archives (+ --verify hashes)
scripts/clean_reports.py     scoped removal of generated report directories
third_party/                 63 evidence files (FloorplanLab runs, MCU-I synthesis, TestCore coverage, ...) + SHA256SUMS + PROVENANCE.json
asic/yieldlab/
  python/yieldlab/           engine (geometry, yield models, defects, mapping, regions, SRAM, test, bins, parametric,
                             Monte Carlo, statistics, costs, optimisation, chiplets, calibration, imports, plots,
                             dashboard, report, gates, audit, CLI)
  configs/                   scenarios (silicaflux_v, _300mm, _all_generators, _critical_area, mcu_i), designs/, wafers/,
                             defects/, tests/, bins/, process/ (parametric, nodes), costs/, defect_models.yaml, area_yield_sweep.yaml
  tests/                     pytest + Hypothesis suite
  docs/                      AUDIT, MODELS, LIMITATIONS, MISSING_FOUNDRY_PARAMETERS, EXPERIMENTS, FINAL_ANSWERS, CHANGES
  examples/                  API example, synthetic wafer-map fixture (never labelled verified)
  reports/                   sample runs (report.md, figures, dashboard.html, gates.json), studies/, logs/, audit/, ci/
```

## Sample runs included

| run | wafers | what |
|---|---|---|
| `reports/sfv_baseline_200mm__seed42__40x25__a9658295de/` | 1000 (40 lots x 25) | SilicaFlux-V baseline, hypothetical costs; open `dashboard.html` |
| `reports/mcu_i_industrial_200mm__seed42__4x25__ba05b294e6/` | 100 | MCU-I on its planning-estimate die (gate 2 FAILS by design: no physical die) |
| `reports/sfv_all_generators__seed7__2x6__108106ee5c/` | 12 | every spatial generator A-I + region-class fatality |
| `reports/studies/*.json` | - | model comparison, clusters, sensitivity, optimisation, experiments A-J, nodes, costs |
| `reports/logs/*.log` | - | execution logs of every make target |

The dashboards are single self-contained HTML files (Plotly embedded, offline): 20 views including an interactive wafer
map (8 layers, zoom / pan, wafer gallery, click a die for its coordinates, defects, regions, test status, bin, repair and
cost metadata).

## Repository branch note

The brief asked for a branch `feature/silicaflux-yieldlab`; per the request this deliverable is a zip and was **not**
committed or pushed. To add it to the repository, unzip it into `SilicaFlux-main/` (or keep it as an archive, like the
other SilicaFlux projects) on that branch.
