# ASIC preparation -- 180 / 130 / 65 nm

**What exists:** Yosys logic synthesis of both variants onto three public PDK standard-cell libraries, with the
SRAM banks mapped to real foundry SRAM macros (as black boxes) by the SRAM Wrapper Library, plus generated
OpenSTA scripts, SDC constraints and ICG technology wrappers.

**What does not exist:** placement, clock-tree synthesis, routing, parasitic extraction, static timing analysis,
power analysis, DRC, LVS, antenna, IR-drop/EM.  OpenROAD/OpenSTA could not be installed in this environment (the
permission policy blocked downloading the conda-packaged binaries), so those steps were not run.  **A public-PDK
synthesis result does not show that the design is ready for a commercial 130 nm or 180 nm foundry**; production
needs licensed process data and the foundry IP below.

## Flow

```bash
make mcu-deps                                       # fetch PDK data (OpenROAD-flow-scripts platforms)
export PLATFORMS=$PWD/deps/orfs/flow/platforms
asic/scripts/run_synth.sh ihp_sg13g2 industrial     # or sky130hd / gf180mcu, basic / industrial
STA=sta asic/scripts/run_synth.sh ...               # + OpenSTA pre-layout timing/power if installed
```
`run_synth.sh`: read Liberty (std cells + SRAM macros) -> read RTL with the target ICG wrapper and the SRAM library
ASIC backend (macro stubs) -> `synth -flatten` -> `dfflibmap` -> `abc -liberty -D <period>` -> tie cells,
buffers -> `stat -liberty` (area), `ltp` (logic depth), netlist, `sta.tcl` (run only if OpenSTA exists).
Constraints: `asic/constraints/mcu_soc.sdc` (50 MHz target at 130 nm, 40 MHz at 180 nm -- targets, not results).

### Remaining physical-design steps (scripts to be added when OpenROAD is available)
floorplan (macro placement of 8-24 SRAM macros with halos, IO placement) -> power grid -> global/detailed
placement -> CTS (ICG-aware) -> global/detailed routing -> RC extraction -> MCMM STA (ss/tt/ff, temperature) ->
DRC/LVS/antenna (KLayout/Magic/Netgen for public PDKs; foundry decks for production) -> IR/EM.  The
OpenROAD-flow-scripts `config.mk` for the IHP platform needs: `DESIGN_NAME=mcu_top`, the netlist or RTL list,
`SDC_FILE=asic/constraints/mcu_soc.sdc`, `ADDITIONAL_LEFS/LIBS` for `RM_IHPSG13_1P_4096x16_c3_bm_bist`,
`MACRO_PLACE_HALO`, `CORE_UTILIZATION` (start at 0.5).

## Results (Yosys pre-layout, typical corners)

| PDK (library, corner) | Variant | Std-cell area | SRAM macros (black boxes) | SRAM macro area | Cells | Flip-flops | ICGs |
|---|---|---|---|---|---|---|---|
| IHP SG13G2 (typ 1.20 V 25 C) | BASIC | 0.366 mm^2 | 8 x `RM_IHPSG13_1P_4096x16_c3_bm_bist` | 2.061 mm^2 | 20982 | 3495 | 4 |
| IHP SG13G2 | INDUSTRIAL | 0.658 mm^2 | 24 x `RM_IHPSG13_1P_4096x16_c3_bm_bist` | 6.183 mm^2 | 39248 | 6182 | 10 |
| SKY130 HD (tt 1.80 V 25 C) | BASIC | 0.200 mm^2 | 32 x `sky130_sram_2kbyte_1rw1r_32x512_8` | not included | 21230 | 3498 | 4 |
| SKY130 HD | INDUSTRIAL (no parity, comparison only) | 0.361 mm^2 | 64 x `sky130_sram_2kbyte_1rw1r_32x512_8` | not included | 39765 | 6153 | 10 |
| GF180MCU 7-track (tt 3.30 V 25 C) | BASIC | 0.610 mm^2 | 128 x `gf180mcu_fd_ip_sram__sram512x8m8wm1` | not included | 20778 | 3498 | 4 |
| GF180MCU | INDUSTRIAL | 1.108 mm^2 | 320 x `gf180mcu_fd_ip_sram__sram512x8m8wm1` | not included | 39391 | 6185 | 10 |

Notes:
* Standard-cell area includes the CPU, bus, all peripherals, the logic boot ROM (2 KiB content), MBIST and ICGs.
* IHP SG13G2 is the only run with SRAM macro Liberty files (area of `RM_IHPSG13_1P_4096x16`: 257,609 um^2 each):
  SRAM is ~85-90 % of logic+memory area -- the SRAM macro choice dominates die size and cost.
* SKY130/GF180 SRAM counts are with the small public macros (`sky130_sram_2kbyte_1rw1r_32x512_8`,
  `gf180mcu_fd_ip_sram__sram512x8m8wm1`); 32-320 macros are impractical -- a production SRAM compiler is required.
* INDUSTRIAL with parity cannot use the SKY130 OpenRAM macro (8-bit write mask vs 9-bit parity lanes; correctly
  refused by the SRAM library); the SKY130 INDUSTRIAL row is therefore synthesised **without parity** for
  comparison only (`make mcu-synth` generates `build/asic_cfg/mcu_cfg_industrial_noparity_pkg.sv` with
  `SRAM_PARITY = 0` and writes `build/asic/sky130hd/industrial_noparity/`).
* No timing numbers are reported because no STA ran.  The only timing evidence is the FPGA post-route result
  (FPGA.md) and the logic depth (`ltp`).

### Planning estimate of die size (NOT a physical result)
Assumptions: standard cells at 60 % utilisation, SRAM macros x 1.15 for halos/channels, 0.35 mm I/O ring per side.
IHP SG13G2: BASIC core ~ (0.37/0.6 + 2.06 x 1.15) ~ 3.0 mm^2 -> die ~ (1.7 + 0.7)^2 ~ 5.9 mm^2;
INDUSTRIAL core ~ (0.66/0.6 + 6.18 x 1.15) ~ 8.2 mm^2 -> die ~ (2.9 + 0.7)^2 ~ 12.7 mm^2.  Only a floorplan and P&R
in the target PDK can replace these numbers.

## Process-node comparison

| Aspect | 180 nm (e.g. GF180MCU class) | 130 nm (IHP SG13G2 / SKY130 class) | 65 nm (commercial only) |
|---|---|---|---|
| Measured here | std-cell area (GF180 7-track, 3.3 V) | std-cell area + IHP SRAM macro area | nothing (no public PDK; template config only) |
| Embedded NVM | some foundries offer OTP/eFlash options at 180 nm (licensed) | OTP/eFuse typical, eFlash rare | eFlash on special processes only |
| SRAM | public macros tiny (512x8); compiler needed | IHP compiled macros usable; SKY130 OpenRAM small/area-inefficient | compiler from foundry/IP vendor |
| I/O | 3.3 V and 5 V-tolerant I/O common -- attractive for industrial | 3.3 V I/O (1.2-1.8 V core) | 1.8/2.5/3.3 V I/O, thick-oxide devices |
| Analogue (POR, BOR, OSC, PLL) | widely available as licensed IP | available per foundry | available, more expensive |
| ESD / pads | foundry library | foundry library | foundry library |
| Cost structure | lowest mask cost, larger die | moderate | higher mask cost, smaller die, lower leakage-per-gate scaling benefits less relevant for SRAM-dominated die |

Recommendation: 130 nm or 180 nm with a production SRAM compiler, 3.3 V (or 5 V-tolerant at 180 nm) I/O, and
licensed POR/BOR + RC oscillator; choose by SRAM density and I/O voltage needs, after obtaining NDA PDK data.

## Packages (candidates, not confirmed)

| Variant | Signal pins | Supply pins (assumption: 2 core VDD/VSS pairs + 2 I/O VDD/VSS pairs, to be confirmed by power-integrity analysis) | Total | Candidate |
|---|---|---|---|---|
| BASIC | 31 (+2 optional status) | ~8 | ~39-41 | QFN-48 (7-9 spare) |
| INDUSTRIAL, as is | 60 (+2) | ~10-12 | ~70-74 | does not fit QFN-64 -> QFN-80/LQFP-80 or IOMUX |
| INDUSTRIAL with an IOMUX (UART1/SPI1/I2C/PWM on GPIO) | ~47 | ~10-12 | ~57-59 | QFN-64 |

The package choice must follow from the real pad ring (foundry pad library, supply count from IR analysis),
thermal estimate (no power numbers exist yet) and the assembly house's capabilities.

## Foundry-specific IP required for fabrication

| IP | Why | Status |
|---|---|---|
| SRAM compiler macros (1RW, 36-bit, bit or 9-bit byte masks) | 64-128 KiB | public IHP macros used for synthesis; production compiler needed |
| I/O pad library (GPIO, open-drain for I2C, 5 V tolerance if required), ESD, power/ground pads, corner cells | every pin | not present |
| POR / brown-out detector | supervision (`pwr_ok_i` provision) | not present (analogue) |
| Crystal or RC oscillator, optional PLL | clock source | not present (external clock assumed) |
| OTP / eFuse | device ID, secure boot keys, trimming | not present |
| Library synchroniser cells, ICG cells | CDC MTBF, clock gating | ICG mapped (3 libraries); synchronisers generic |
| Optional ROM macro | if a mask-ROM is preferred to the logic ROM | logic ROM used |
