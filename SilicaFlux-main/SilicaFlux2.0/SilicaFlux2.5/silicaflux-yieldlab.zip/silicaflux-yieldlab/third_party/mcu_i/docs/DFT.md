# Design for test

## Provisions in the RTL

| Provision | Status | Where |
|---|---|---|
| JTAG TAP (IEEE 1149.1-style state machine, IDCODE, BYPASS) | implemented | `rtl/debug/mcu_jtag.sv` |
| Boundary scan (EXTEST/SAMPLE/PRELOAD, BSR, BSDL) | **not implemented** (needs the pad ring) | upstream ISS-004 |
| Test mode pin | implemented: forces all ICGs open, routes every reset to the pin | `test_mode` -> `sfv_rst_sync`, `sfv_clkgate` |
| Scan-compatible clocking | single functional clock + TCK; gated clocks only through ICG cells with test enable; no derived/divided clocks; no combinational clock gating | CLOCK_RESET.md |
| Scan-compatible resets | asynchronous resets controllable from the pin in test mode; synchronous release flops bypassed | `sfv_rst_sync` |
| Latches | none except the ICG enable latch (verified by lint and synthesis: 0 other latches) | reports/lint, reports/asic |
| Scan insertion / ATPG | **not done** -- requires a scan-capable flow (commercial DFT tool or OpenROAD/Fault-style flow) and the target cell library | - |
| SRAM MBIST | March C- (`sfv_mbist`, upstream), all 4 banks in parallel, solid or checkerboard background, fail bank/address/element capture, SYSCTRL control + interrupt; also run by the boot ROM at every boot | SYSCTRL.MBIST_* |
| Parity column test | MBIST writes valid parity but does not compare parity bits; covered by software (PARITY_CTRL.INJECT + read) on sampled words only -- **coverage gap** | MEMORY_AND_BOOT.md |
| Peripheral loopback | UART LOOPBACK bit; SPI/UART loopback through the board (tests 04, 06); I2C devices on the board | PERIPHERALS.md |
| Watchdog test | WDT can be exercised in seconds (short LOAD), reset cause readable after reset; `07_watchdog` | SAFETY.md |
| CPU diagnostics | ROM banner (CHIP_ID, FEATURES, reset cause), mcycle/minstret, riscv-tests can run from SRAM via JTAG load | CPU.md |
| Reset diagnostics | RESET_CAUSE (POR/SOFT/JTAG/WDT + WDT count), BOOT_STATUS codes, fault log (POR domain) | CLOCK_RESET.md |
| Manufacturing identification | CHIP_ID (revision), JTAG IDCODE (JEDEC manufacturer field placeholder), mimpid; **no unique die ID** (needs OTP/eFuse) | SECURITY.md |
| Test access separation | JTAG debug functions lockable by firmware; `test_mode` is a separate pin | SECURITY.md |
| At-speed test | no on-chip clock controller (OCC) | ISSUES.md |

## Targets (not achieved -- no ATPG was run)

| Metric | Target for production | Achieved |
|---|---|---|
| Stuck-at fault coverage (logic, scan) | >= 98 % | **not measured** |
| Transition-delay coverage | >= 85 % (needs OCC) | **not measured** |
| SRAM test | March C- (+ retention/address-decoder tests per foundry guidance) | March C- implemented, verified in simulation with injected stuck-at faults upstream |
| IDDQ | foundry-dependent | not applicable yet |

## DFT readiness checklist

| # | Item | State |
|---|---|---|
| 1 | All flops clocked by a primary clock or an ICG output | yes (by construction; check with the DFT tool) |
| 2 | Asynchronous resets controllable in test mode | yes |
| 3 | No intentional latches outside ICGs | yes (lint + synthesis) |
| 4 | No combinational loops | yes (Verilator/Yosys checks) |
| 5 | Scan chains inserted, stitched, balanced | **open** |
| 6 | ATPG patterns generated, coverage report | **open** |
| 7 | Compression (EDT/OPMISR-style) for tester time | **open** |
| 8 | OCC for at-speed capture | **open** |
| 9 | Boundary scan + BSDL | **open** |
| 10 | MBIST on every memory incl. parity column, retention test | partial |
| 11 | ROM signature test (read-out over JTAG/CPU and CRC) | possible with existing logic (JTAG SBA read), test program not written |
| 12 | Analogue/IO test (pads, POR/BOR) | depends on foundry IP -- **open** |
| 13 | Test-mode entry protected for the field | test_mode pin must be tied/bonded per product decision -- **open** |
| 14 | Production test plan and tester program | **open** |
