#!/usr/bin/env python3
"""Vendor SilicaFlux evidence files into ``third_party/`` with full provenance.

YieldLab never reads design dimensions from memory or from prose.  Every
physical input it uses is a file produced by another SilicaFlux project
(FloorplanLab OpenDB exports, MCU-I Yosys summaries, TestCore fault-injection
reports, ...).  Those projects live inside nested zip archives in the
``btcphilosopher/Aureom.AI`` repository, so this script opens the archives in
memory, copies the selected members byte-for-byte and records, for each file:

* the repository-relative path of the outer archive and its SHA-256,
* the member path inside the archive (and inner archive, if nested),
* the SHA-256 of the extracted bytes.

Usage::

    python scripts/intake.py --repo /path/to/Aureom.AI            # (re)vendor
    python scripts/intake.py --verify                              # check hashes

``--verify`` only re-hashes the vendored copies against ``SHA256SUMS``; it
does not need the repository.
"""
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import io
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TP = ROOT / "third_party"

# (outer archive relative to repo root, optional inner archive member, list of
#  (member glob, destination sub-directory))
SOURCES = [
    (
        "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-floorplanlab.zip",
        None,
        [
            ("silicaflux-floorplanlab/reports/runs/*/geometry.json", "floorplanlab/runs"),
            ("silicaflux-floorplanlab/reports/runs/*/route_metrics.json", "floorplanlab/runs"),
            ("silicaflux-floorplanlab/reports/experiments/ppa_table.csv", "floorplanlab/experiments"),
            ("silicaflux-floorplanlab/reports/experiments/summary.md", "floorplanlab/experiments"),
            ("silicaflux-floorplanlab/docs/RESULTS.md", "floorplanlab/docs"),
            ("silicaflux-floorplanlab/docs/FABRICATION_DEPENDENCIES.md", "floorplanlab/docs"),
            ("silicaflux-floorplanlab/configs/mcu_i/design.yaml", "floorplanlab/configs/mcu_i"),
            ("silicaflux-floorplanlab/configs/full_silicaflux/design.yaml", "floorplanlab/configs/full_silicaflux"),
            ("silicaflux-floorplanlab/platforms/commercial_130/profile.yaml", "floorplanlab/platforms/commercial_130"),
            ("silicaflux-floorplanlab/platforms/commercial_65/profile.yaml", "floorplanlab/platforms/commercial_65"),
            ("silicaflux-floorplanlab/platforms/commercial_28/profile.yaml", "floorplanlab/platforms/commercial_28"),
        ],
    ),
    (
        "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-mcu-i.zip",
        None,
        [
            ("silicaflux-mcu-i/reports/asic/*/*/summary.json", "mcu_i/asic"),
            ("silicaflux-mcu-i/docs/ASIC.md", "mcu_i/docs"),
            ("silicaflux-mcu-i/docs/DFT.md", "mcu_i/docs"),
        ],
    ),
    (
        "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-testcore-p07.zip",
        None,
        [
            ("silicaflux-testcore/reports/testcore/mbist/summary.json", "testcore_r2/mbist"),
            ("silicaflux-testcore/reports/testcore/atpg/summary.json", "testcore_r2/atpg"),
            ("silicaflux-testcore/docs/testcore/generated/fault_coverage.md", "testcore_r2/docs"),
            ("silicaflux-testcore/docs/testcore/generated/dft_results.md", "testcore_r2/docs"),
            ("silicaflux-testcore/docs/testcore/bringup_and_manufacturing.md", "testcore_r2/docs"),
            ("silicaflux-testcore/docs/testcore/mbist.md", "testcore_r2/docs"),
            ("silicaflux-testcore/docs/testcore/limitations_and_blockers.md", "testcore_r2/docs"),
        ],
    ),
    (
        "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-testcore.zip",
        None,
        [
            ("silicaflux-testcore/logs/examples/lot_steps.csv", "testcore_r1/logs"),
            ("silicaflux-testcore/logs/examples/lot_failures.csv", "testcore_r1/logs"),
            ("silicaflux-testcore/docs/generated/lbist_evaluation.md", "testcore_r1/docs"),
            ("silicaflux-testcore/docs/10_host_automation.md", "testcore_r1/docs"),
            ("silicaflux-testcore/docs/04_mbist.md", "testcore_r1/docs"),
        ],
    ),
    (
        "SilicaFlux-main/silicaflux-v-release1.zip",
        None,
        [
            ("silicaflux-v/docs/PROCESS_NODE_COMPARISON.md", "silicaflux_v/docs"),
            ("silicaflux-v/docs/DFT.md", "silicaflux_v/docs"),
            ("silicaflux-v/docs/ARCHITECTURE.md", "silicaflux_v/docs"),
            ("silicaflux-v/docs/MEMORY_MAP.md", "silicaflux_v/docs"),
        ],
    ),
    (
        "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-timingflow.zip",
        None,
        [("silicaflux-timingflow/README.md", "timingflow")],
    ),
    (
        "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/SilicaFlux ThermalLab (1).zip",
        "silicaflux-thermallab-0.1.0.zip",
        [("asic/thermallab/examples/def_demo/top.def", "thermallab/def_demo")],
    ),
]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def vendor(repo: Path) -> int:
    records = []
    sums = []
    for outer_rel, inner, rules in SOURCES:
        outer = repo / outer_rel
        if not outer.exists():
            print(f"MISSING archive: {outer_rel}", file=sys.stderr)
            return 2
        outer_bytes = outer.read_bytes()
        zf = zipfile.ZipFile(io.BytesIO(outer_bytes))
        inner_sha = None
        if inner is not None:
            inner_bytes = zf.read(inner)
            inner_sha = sha256(inner_bytes)
            zf = zipfile.ZipFile(io.BytesIO(inner_bytes))
        names = zf.namelist()
        for pattern, dest in rules:
            hits = [n for n in names if fnmatch.fnmatch(n, pattern) and not n.endswith("/")]
            if not hits:
                print(f"NO MATCH: {outer_rel}::{pattern}", file=sys.stderr)
                return 3
            for member in sorted(hits):
                data = zf.read(member)
                # keep the run id / variant directory components that follow the glob root
                parts = Path(member).parts
                glob_parts = Path(pattern).parts
                keep = [p for p, g in zip(parts, glob_parts) if "*" in g]
                out = TP / dest / Path(*keep) / parts[-1] if keep else TP / dest / parts[-1]
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_bytes(data)
                rel = out.relative_to(TP).as_posix()
                digest = sha256(data)
                sums.append(f"{digest}  {rel}")
                records.append(
                    {
                        "vendored_path": rel,
                        "sha256": digest,
                        "source_repository": "btcphilosopher/Aureom.AI",
                        "outer_archive": outer_rel,
                        "outer_archive_sha256": sha256(outer_bytes),
                        "inner_archive": inner,
                        "inner_archive_sha256": inner_sha,
                        "member": member,
                    }
                )
    (TP / "SHA256SUMS").write_text("\n".join(sorted(sums)) + "\n")
    (TP / "PROVENANCE.json").write_text(json.dumps({"files": records}, indent=1) + "\n")
    print(f"vendored {len(records)} files into {TP}")
    return 0


def verify() -> int:
    bad = 0
    lines = (TP / "SHA256SUMS").read_text().splitlines()
    for line in lines:
        digest, rel = line.split("  ", 1)
        p = TP / rel
        if not p.exists() or sha256(p.read_bytes()) != digest:
            print(f"HASH MISMATCH / MISSING: {rel}")
            bad += 1
    print(f"verified {len(lines) - bad}/{len(lines)} vendored files")
    return 1 if bad else 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--repo", type=Path, help="path to a checkout of btcphilosopher/Aureom.AI")
    ap.add_argument("--verify", action="store_true")
    a = ap.parse_args()
    if a.verify:
        return verify()
    if not a.repo:
        ap.error("--repo is required unless --verify is given")
    return vendor(a.repo)


if __name__ == "__main__":
    sys.exit(main())
