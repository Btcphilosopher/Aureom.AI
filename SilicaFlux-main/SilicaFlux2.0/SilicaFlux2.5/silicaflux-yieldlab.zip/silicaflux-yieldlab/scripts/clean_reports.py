#!/usr/bin/env python3
"""Remove generated YieldLab report directories -- and nothing else.

Only direct children of asic/yieldlab/reports whose names match the generated
patterns (``*__seed*`` run directories, ``studies``, ``geometry``, ``ci``) are
removed, after checking that they resolve inside that reports directory.
"""
import shutil
import sys
from pathlib import Path

REPORTS = (Path(__file__).resolve().parents[1] / "asic" / "yieldlab" / "reports").resolve()


def main() -> int:
    if not REPORTS.is_dir():
        print(f"nothing to clean: {REPORTS} does not exist")
        return 0
    targets = [p for p in REPORTS.iterdir() if p.is_dir() and ("__seed" in p.name or p.name in ("studies", "geometry", "ci"))]
    for p in targets:
        rp = p.resolve()
        if rp.parent != REPORTS:
            print(f"refusing to remove {rp}: outside {REPORTS}")
            return 1
        shutil.rmtree(rp)
        print(f"removed {rp.relative_to(REPORTS.parent)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
