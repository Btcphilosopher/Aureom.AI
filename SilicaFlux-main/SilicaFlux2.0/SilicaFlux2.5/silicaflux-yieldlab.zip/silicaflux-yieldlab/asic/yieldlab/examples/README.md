# Examples

* `synthetic_wafer_map_fixture.csv` - a **synthetic** prober-style bin map (2 lots x 6 wafers, column
  `data_origin = synthetic_example`) for exercising import, retest policy and calibration. Because it declares a
  non-measured origin, the importer labels it `SYNTHETIC TEST FIXTURE - NOT MANUFACTURING DATA`; it can never become
  `VERIFIED IMPORTED DATA`.

```bash
cd asic/yieldlab
PYTHONPATH=python python -m yieldlab import --data examples/synthetic_wafer_map_fixture.csv --good-bins 1 --valid-bins 1 2 3 --retest-policy LAST
```

* `example_api.py` - using the engine from Python (geometry, analytical models, a 10-wafer simulation, statistics).
