"""Minimal programmatic use of YieldLab (run from asic/yieldlab with PYTHONPATH=python)."""
from yieldlab import statistics as st, yield_models as ym
from yieldlab.analysis import geometry_analysis
from yieldlab.config import load_scenario
from yieldlab.monte_carlo import run_simulation

scn = load_scenario("configs/silicaflux_v.yaml", {"wafer.edge_exclusion_mm": 3.0})
geo = geometry_analysis(scn, optimise=False)
print("eligible FULL dies per wafer:", geo["eligible"], geo["site_counts"])
a_cm2 = geo["die_area_mm2"] / 100
print("Poisson / NB(alpha=3) yield at a HYPOTHETICAL D0 = 0.25:",
      ym.poisson_yield(a_cm2, 0.25), ym.negative_binomial_yield(a_cm2, 0.25, 3.0))
sim = run_simulation(scn, lots=2, wafers_per_lot=5, keep_maps=0)
df = st.add_derived(sim.wafers)
print(st.mean_ci(df, "outcome_TRUE_GOOD_PASS"))
print("90 % PI next wafer:", st.predictive_interval(df["outcome_TRUE_GOOD_PASS"], 0.9))
