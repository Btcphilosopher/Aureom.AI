r"""Statistical analysis of Monte Carlo (or measured) wafer outcomes.

Two different questions, two different intervals -- never interchanged:

* **Confidence interval (CI)** for the *expected* value (e.g. mean good dies per
  wafer under the model).  It shrinks as more wafers are simulated.
* **Predictive interval (PI)** for the outcome of *one future wafer* (or lot).
  It does not shrink with more simulation; it describes wafer-to-wafer spread.

Correlation structure: wafers of the same lot share the lot-level latent
variables, so the wafer is **not** the independent sampling unit when lot
variation is modelled.  ``mean_ci`` therefore uses the lot as the cluster:
a t-interval on lot means (equal wafers per lot) and a two-stage cluster
bootstrap (resample lots, then wafers within the resampled lots).  The naive
wafer-level t-interval is reported only for comparison together with the
intraclass correlation and design effect, so the error of treating correlated
wafers as independent is visible.  Dies are never treated as independent units.

Monte Carlo convergence: running mean and batch-means Monte Carlo standard
error (MCSE).  A result is declared CONVERGED only when n >= ``n_min`` and the
relative MCSE is below ``rel_tol``; otherwise INSUFFICIENT -- no convergence
claim is made from small samples.
"""
from __future__ import annotations

import math
from typing import Optional

import numpy as np
import pandas as pd
from scipy import stats

#: every yield-type metric: (numerator column, denominator column, definition)
YIELD_METRICS: dict[str, tuple[str, str, str]] = {
    "site_utilisation": ("eligible", "gross_sites",
                         "eligible FULL-DIE sites / all die sites touching the wafer"),
    "defect_limited_yield": ("_good_raw", "eligible",
                             "eligible dies without a fatal defect (before any repair) / eligible dies"),
    "functional_yield": ("_good_func", "eligible",
                         "eligible dies functional after IMPLEMENTED repair / eligible dies"),
    "true_good_yield": ("outcome_TRUE_GOOD_PASS", "eligible",
                        "conforming dies that passed every probe step / eligible dies"),
    "observed_probe_yield": ("probe_pass", "tested",
                             "dies passing every probe step (incl. escapes) / tested dies"),
    "probe_escape_fraction": ("outcome_DEFECTIVE_ESCAPED", "probe_pass",
                              "nonconforming dies that passed probe / dies that passed probe"),
    "false_reject_fraction": ("outcome_GOOD_REJECTED", "conforming_wafer",
                              "conforming dies rejected at probe / conforming dies"),
    "delivered_conforming_yield": ("delivered_conforming", "eligible",
                                   "conforming dies delivered after packaging + final test / eligible dies"),
    "shipped_escape_fraction": ("delivered_escape", "delivered",
                                "nonconforming dies among delivered dies / delivered dies"),
}


def add_derived(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["_good_raw"] = df["eligible"] - df["functional_fail_raw"]
    df["_good_func"] = df["eligible"] - df["functional_fail"]
    for name, (num, den, _) in YIELD_METRICS.items():
        d = df[den].to_numpy(float)
        df[name] = np.where(d > 0, df[num].to_numpy(float) / np.where(d > 0, d, 1), np.nan)
    return df


def describe(x) -> dict:
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return {"n": 0}
    return {
        "n": int(x.size), "mean": float(x.mean()), "sd": float(x.std(ddof=1)) if x.size > 1 else 0.0,
        "median": float(np.median(x)), "p5": float(np.percentile(x, 5)), "p50": float(np.percentile(x, 50)),
        "p95": float(np.percentile(x, 95)), "min": float(x.min()), "max": float(x.max()),
    }


def t_interval(x, level: float = 0.95) -> tuple[float, float]:
    x = np.asarray(x, float)
    n = x.size
    if n < 2:
        return (float("nan"), float("nan"))
    m, se = x.mean(), x.std(ddof=1) / math.sqrt(n)
    q = stats.t.ppf(0.5 + level / 2, n - 1)
    return (float(m - q * se), float(m + q * se))


def icc_oneway(df: pd.DataFrame, value: str, group: str = "lot") -> dict:
    """One-way ANOVA intraclass correlation (between-lot share of variance) and design effect."""
    g = df.groupby(group)[value]
    k = g.ngroups
    sizes = g.size().to_numpy()
    n = len(df)
    if k < 2 or n <= k:
        return {"icc": float("nan"), "design_effect": float("nan"), "lots": int(k)}
    grand = df[value].mean()
    ssb = float((sizes * (g.mean() - grand) ** 2).sum())
    ssw = float(((df[value] - g.transform("mean")) ** 2).sum())
    msb, msw = ssb / (k - 1), ssw / (n - k)
    m0 = (n - (sizes**2).sum() / n) / (k - 1)
    icc = (msb - msw) / (msb + (m0 - 1) * msw) if (msb + (m0 - 1) * msw) > 0 else 0.0
    icc = max(0.0, float(icc))
    return {"icc": icc, "design_effect": 1 + (m0 - 1) * icc, "lots": int(k), "wafers_per_lot": float(m0)}


def cluster_bootstrap(df: pd.DataFrame, value: str, rng: np.random.Generator, B: int = 2000,
                      level: float = 0.95, group: str = "lot") -> tuple[float, float]:
    """Two-stage bootstrap: resample lots, then wafers within each resampled lot."""
    groups = [g[value].to_numpy(float) for _, g in df.groupby(group)]
    k = len(groups)
    means = np.empty(B)
    for b in range(B):
        pick = rng.integers(0, k, k)
        vals = [groups[i][rng.integers(0, groups[i].size, groups[i].size)] for i in pick]
        means[b] = np.concatenate(vals).mean()
    a = (1 - level) / 2
    return (float(np.quantile(means, a)), float(np.quantile(means, 1 - a)))


def mean_ci(df: pd.DataFrame, value: str, level: float = 0.95, seed: int = 0, B: int = 2000) -> dict:
    lots = df["lot"].nunique()
    lot_means = df.groupby("lot")[value].mean().to_numpy()
    out = {"estimate": float(df[value].mean()), "level": level, "lots": int(lots), "wafers": int(len(df))}
    out["ci_naive_wafer_t"] = t_interval(df[value].to_numpy(), level)
    if lots >= 2:
        out["ci_lot_cluster_t"] = t_interval(lot_means, level)
        out["ci_cluster_bootstrap"] = cluster_bootstrap(df, value, np.random.default_rng(seed), B, level)
        out["method"] = "lot-cluster t-interval on lot means (primary) + two-stage cluster bootstrap"
    else:
        out["method"] = "single lot: wafer-level t-interval (valid only if no lot-level variation is modelled)"
    out.update({f"icc_{k}": v for k, v in icc_oneway(df, value).items()})
    return out


def predictive_interval(x, level: float = 0.90) -> tuple[float, float]:
    x = np.asarray(x, float)
    a = (1 - level) / 2
    return (float(np.quantile(x, a)), float(np.quantile(x, 1 - a)))


def lot_totals(df: pd.DataFrame, value: str) -> np.ndarray:
    return df.groupby("lot")[value].sum().to_numpy(float)


def prob_at_least(x, target: float) -> dict:
    x = np.asarray(x, float)
    n = x.size
    k = int((x >= target).sum())
    p = k / n if n else float("nan")
    z = 1.959963984540054
    den = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return {"target": target, "p": p, "k": k, "n": n, "wilson95": (max(0.0, centre - half), min(1.0, centre + half))}


def batch_means_mcse(x, n_batches: int = 20) -> float:
    x = np.asarray(x, float)
    n = x.size
    if n < 2 * n_batches:
        return float(x.std(ddof=1) / math.sqrt(n)) if n > 1 else float("nan")
    b = n // n_batches
    means = x[: b * n_batches].reshape(n_batches, b).mean(axis=1)
    return float(means.std(ddof=1) / math.sqrt(n_batches))


def convergence(x, rel_tol: float = 0.01, n_min: int = 100, unit: str = "wafer") -> dict:
    x = np.asarray(x, float)
    n = x.size
    running = np.cumsum(x) / np.arange(1, n + 1)
    mcse = batch_means_mcse(x)
    mean = float(x.mean()) if n else float("nan")
    rel = mcse / abs(mean) if mean else float("inf")
    status = "CONVERGED" if (n >= n_min and rel <= rel_tol) else "INSUFFICIENT"
    return {"n": int(n), "unit": unit, "mean": mean, "mcse": mcse, "relative_mcse": rel, "rel_tol": rel_tol,
            "n_min": n_min, "status": status, "running_mean": running.tolist()}


def paired_difference(a: pd.DataFrame, b: pd.DataFrame, value: str, level: float = 0.95, seed: int = 0) -> dict:
    """Difference b - a for two scenarios simulated with common random numbers (same seed / lots / wafers).

    Pairing unit = (lot, wafer); uncertainty from lot-cluster t-interval of the paired lot-mean differences
    and a cluster bootstrap of the paired differences."""
    m = a[["lot", "wafer", value]].merge(b[["lot", "wafer", value]], on=["lot", "wafer"], suffixes=("_a", "_b"))
    m["diff"] = m[f"{value}_b"] - m[f"{value}_a"]
    out = {"value": value, "mean_a": float(m[f"{value}_a"].mean()), "mean_b": float(m[f"{value}_b"].mean()),
           "mean_diff": float(m["diff"].mean()), "pairs": int(len(m)),
           "pairing": "common random numbers: identical (seed, lot, wafer, stream) keys"}
    if m["lot"].nunique() >= 2:
        out["ci_lot_cluster_t"] = t_interval(m.groupby("lot")["diff"].mean().to_numpy(), level)
        out["ci_cluster_bootstrap"] = cluster_bootstrap(m, "diff", np.random.default_rng(seed), 2000, level)
    else:
        out["ci_wafer_t"] = t_interval(m["diff"].to_numpy(), level)
    out["predictive_interval_wafer_diff_90"] = predictive_interval(m["diff"].to_numpy(), 0.90)
    return out


def summary_table(df: pd.DataFrame, columns: list[str], level: float = 0.95, seed: int = 0) -> list[dict]:
    rows = []
    for c in columns:
        d = describe(df[c])
        ci = mean_ci(df, c, level, seed)
        pi_w = predictive_interval(df[c], 0.90)
        tot = lot_totals(df, c)
        rows.append({
            "metric": c, **{k: d.get(k) for k in ("n", "mean", "sd", "median", "p5", "p50", "p95")},
            "ci95_mean": ci.get("ci_lot_cluster_t", ci["ci_naive_wafer_t"]),
            "ci95_mean_bootstrap": ci.get("ci_cluster_bootstrap"),
            "ci95_naive_wafer_iid": ci["ci_naive_wafer_t"],
            "icc_lot": ci.get("icc_icc"), "design_effect": ci.get("icc_design_effect"),
            "pi90_next_wafer": pi_w,
            # lot totals are only meaningful for counts, not for ratio (yield) metrics
            "pi90_next_lot_total": predictive_interval(tot, 0.90) if tot.size >= 2 and c not in YIELD_METRICS else None,
            "ci_method": ci["method"],
        })
    return rows
