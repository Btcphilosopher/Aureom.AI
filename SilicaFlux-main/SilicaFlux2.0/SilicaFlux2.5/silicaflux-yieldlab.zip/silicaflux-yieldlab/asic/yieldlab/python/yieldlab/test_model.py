r"""Manufacturing test model (wafer probe + final test).

Fault population and detection model
------------------------------------
The *fault population* is the set of fatal hits produced by the defect /
fatality / SRAM models: each fault has a region (name and kind) and, for SRAM
macros, a fault type.  A test step detects a fault with probability
``coverage(step, fault)``; coverage values are looked up, most specific first:

    "<region>:<fault_type>"  ->  "<kind>:<fault_type>"  ->  "<region>"  ->  "<kind>"  ->  "*"

and a fault with no matching key is *not* detected by that step.  A coverage
entry that is NOT_AVAILABLE raises MissingInputError: a step cannot be run on
an unknown coverage.  Detection of different faults is assumed independent
(stated assumption).  A fault detected once is detected again on retest.

Every step also has a false-reject probability for *any* die (contact,
handling, tester noise).  On a ``retestable`` step a false reject triggers up to
``max_retests`` retests (the policy is explicit and recorded); a real
detection fails every retest.

The flow is stop-on-fail in the order the steps are listed; the first failing
step decides the bin.  Parametric steps compare a *measured* value (true value
+ gauge noise) with the specification, which produces both parametric false
rejects and parametric escapes.

Final, mutually exclusive classification of every eligible die:

=========================  ===============================================================
UNTESTED                   not probed (probe sampling) or test incomplete
TRUE_GOOD_PASS             conforming (no functional failure, parametrically in spec,
                           no repair needed or implemented repair) and passed every step
CONDITIONAL_GOOD_PASS      passes only because of a HYPOTHETICAL repair / harvest capability
GOOD_REJECTED              conforming but rejected (false reject or gauge error)
DEFECTIVE_DETECTED         nonconforming and rejected
DEFECTIVE_ESCAPED          nonconforming but passed every step (test escape)
=========================  ===============================================================
"""
from __future__ import annotations

from enum import IntEnum
from typing import Literal, Optional

import numpy as np
from pydantic import BaseModel, ConfigDict, Field

from .provenance import MissingInputError, Source, Sourced


class Outcome(IntEnum):
    UNTESTED = 0
    TRUE_GOOD_PASS = 1
    CONDITIONAL_GOOD_PASS = 2
    GOOD_REJECTED = 3
    DEFECTIVE_DETECTED = 4
    DEFECTIVE_ESCAPED = 5


OUTCOME_LABELS = {o: o.name for o in Outcome}


class Coverage(BaseModel):
    model_config = ConfigDict(extra="forbid")
    value: Optional[float] = Field(default=None, ge=0, le=1)
    source: Source
    reference: str

    def sourced(self) -> Sourced:
        return Sourced(value=self.value, source=self.source, reference=self.reference)


class TestStep(BaseModel):
    __test__ = False          # not a pytest class
    model_config = ConfigDict(extra="forbid")
    name: str
    insertion: Literal["wafer_probe", "final_test"] = "wafer_probe"
    category: Literal["electrical", "functional", "memory", "parametric", "debug"]
    enabled: bool = True
    coverage: dict[str, Coverage] = Field(default_factory=dict)
    parameter: Optional[str] = None      # for parametric steps
    false_reject: Coverage = Field(default_factory=lambda: Coverage(
        value=0.0, source=Source.HYPOTHETICAL, reference="no false-reject data; zero assumed"))
    retestable: bool = False
    testcore_soft_bin: Optional[int] = None
    testcore_hard_bin: Optional[int] = None


class TestPlan(BaseModel):
    __test__ = False          # not a pytest class
    model_config = ConfigDict(extra="forbid")
    name: str
    steps: list[TestStep]
    max_retests: int = Field(1, ge=0)
    retest_policy: str = "retest only steps marked retestable; a die passes if any attempt passes; real faults fail every attempt"
    probe_fraction: float = Field(1.0, ge=0, le=1)
    incomplete_probability: Coverage = Field(default_factory=lambda: Coverage(
        value=0.0, source=Source.HYPOTHETICAL, reference="no test-incomplete data; zero assumed"))
    assembly_yield: Optional[Coverage] = Field(
        default=None, description="probability a sellable die survives packaging; None = packaging not modelled "
                                  "(results are bare-die / known-good-die at wafer sort)")

    def enabled_steps(self, insertion: Optional[str] = None) -> list[TestStep]:
        return [s for s in self.steps if s.enabled and (insertion is None or s.insertion == insertion)]

    def coverage_matrix(self, steps: list[TestStep], region_names: list[str], region_kinds: list[str],
                        fault_types: list[str]) -> np.ndarray:
        """cov[step, region, fault_type] (fault_type index len(fault_types) = 'logic / not SRAM')."""
        S, R, T = len(steps), len(region_names), len(fault_types) + 1
        cov = np.zeros((S, R, T))
        for si, st in enumerate(steps):
            if st.category == "parametric":
                continue
            for r in range(R):
                for t in range(T):
                    ft = fault_types[t] if t < len(fault_types) else None
                    keys = []
                    if ft:
                        keys += [f"{region_names[r]}:{ft}", f"{region_kinds[r]}:{ft}"]
                    keys += [region_names[r], region_kinds[r], "*"]
                    for k in keys:
                        if k in st.coverage:
                            c = st.coverage[k]
                            if c.value is None or c.source is Source.NOT_AVAILABLE:
                                raise MissingInputError(
                                    f"test step {st.name!r}: coverage for {k!r} is NOT AVAILABLE ({c.reference}); "
                                    "disable the step or supply an explicitly HYPOTHETICAL value")
                            cov[si, r, t] = c.value
                            break
        return cov


def run_tests(plan: TestPlan, steps: list[TestStep], cov: np.ndarray, n_dies: int,
              fault_die: np.ndarray, fault_region: np.ndarray, fault_type: np.ndarray,
              param_true: dict[str, np.ndarray], param_spec_ok: np.ndarray, param_measure,
              rng: np.random.Generator, fault_active: np.ndarray | None = None) -> dict:
    """Apply the stop-on-fail flow to *n_dies* dies.

    fault_* arrays describe every fatal fault (die index local to the eligible
    set); ``fault_active`` masks out faults removed by repair.  Returns per-die arrays: first failing step (-1 = none),
    whether the first failure was a false reject, retest counts, measured
    parameter values.
    """
    S = len(steps)
    big = S + 1
    first_detect = np.full(n_dies, big)
    if fault_die.size and S:
        # uniforms are drawn for every fault, active or not, so scenarios that remove faults (repair)
        # consume the same random numbers -> common-random-number pairing is preserved
        u = rng.random((fault_die.size, S))
        p = cov[:, fault_region, fault_type].T          # (faults, S)
        det = u < p
        if fault_active is not None:
            det &= fault_active[:, None]
        step_idx = np.where(det, np.arange(S)[None, :], big)
        first_per_fault = step_idx.min(axis=1)
        np.minimum.at(first_detect, fault_die, first_per_fault)
    first_fail = first_detect.copy()
    false_reject_step = np.full(n_dies, big)
    retests = np.zeros(n_dies, dtype=int)
    measured: dict[str, np.ndarray] = {}
    for si, st in enumerate(steps):
        pending = first_fail > si
        if st.category == "parametric":
            if st.parameter is None or st.parameter not in param_true:
                raise MissingInputError(f"parametric step {st.name!r}: parameter {st.parameter!r} not modelled")
            meas = param_measure(st.parameter, param_true[st.parameter], rng)
            measured[st.parameter] = meas
            fail = pending & ~param_measure.in_spec(st.parameter, meas)
            first_fail[fail] = np.minimum(first_fail[fail], si)
        p_fr = st.false_reject.value or 0.0
        if p_fr > 0:
            fr = pending & (rng.random(n_dies) < p_fr)
            if st.retestable and plan.max_retests > 0:
                for _ in range(plan.max_retests):
                    retests[fr] += 1
                    fr &= rng.random(n_dies) < p_fr
            newly = fr & (first_fail > si)
            false_reject_step[newly] = si
            first_fail[newly] = si
    first_fail[first_fail == big] = -1
    first_detect[first_detect == big] = -1
    false_reject_step[false_reject_step == big] = -1
    return {"first_fail": first_fail, "first_detect": first_detect, "false_reject_step": false_reject_step,
            "retests": retests, "measured": measured}


def classify(n_dies: int, tested: np.ndarray, incomplete: np.ndarray, functional_fail: np.ndarray,
             conditional: np.ndarray, param_ok: np.ndarray, first_fail: np.ndarray) -> np.ndarray:
    """Mutually exclusive final classification (see module docstring)."""
    out = np.full(n_dies, Outcome.UNTESTED, dtype=np.int8)
    # strict conformity: a die that only works thanks to a HYPOTHETICAL repair is NOT conforming
    conforming = ~functional_fail & param_ok & ~conditional
    conditional_ok = conditional & ~functional_fail & param_ok
    passed = first_fail < 0
    t = tested & ~incomplete
    out[t & conforming & passed] = Outcome.TRUE_GOOD_PASS
    out[t & conditional_ok & passed] = Outcome.CONDITIONAL_GOOD_PASS
    out[t & conforming & ~passed] = Outcome.GOOD_REJECTED
    out[t & ~conforming & ~passed] = Outcome.DEFECTIVE_DETECTED
    out[t & ~conforming & ~conditional_ok & passed] = Outcome.DEFECTIVE_ESCAPED
    return out
