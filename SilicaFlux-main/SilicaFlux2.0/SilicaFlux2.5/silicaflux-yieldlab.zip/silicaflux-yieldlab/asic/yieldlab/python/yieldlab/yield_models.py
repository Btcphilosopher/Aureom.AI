r"""Analytical defect-limited yield models and their independent Monte Carlo counterparts.

All models give the probability that a die of effective defect-sensitive area
``A`` (cm^2) has **zero fatal defects** when the mean fatal-defect density is
``D0`` (cm^-2).  They differ only in the assumed distribution of the defect
density ``D`` seen by a die:

.. math::  Y = \int_0^\infty e^{-A D} f(D)\,dD

=================  ============================================  =====================================
model              f(D)                                          Y
=================  ============================================  =====================================
Poisson            delta(D - D0)                                 exp(-A D0)
negative binomial  Gamma(shape=alpha, scale=D0/alpha)            (1 + A D0 / alpha)^(-alpha)
Seeds              exponential, mean D0 (= NB with alpha = 1)    1 / (1 + A D0)
Murphy (triangle)  triangular on [0, 2 D0], mode D0              ((1 - e^{-A D0}) / (A D0))^2
Murphy (uniform)   uniform on [0, 2 D0]                          (1 - e^{-2 A D0}) / (2 A D0)
=================  ============================================  =====================================

The Murphy expressions are evaluated with ``-expm1(-x)/x`` and a series
expansion for x < 1e-6, so the A D0 -> 0 limit (Y -> 1) is numerically stable.

Negative binomial (gamma-Poisson) details: with lambda ~ Gamma(alpha, D0/alpha)
and N | lambda ~ Poisson(lambda A):  E[lambda] = D0, Var[lambda] = D0^2/alpha,
E[N] = mu = A D0, Var[N] = mu + mu^2/alpha, P(N = 0) = (1 + mu/alpha)^(-alpha);
alpha -> infinity recovers the Poisson model.  The *level* at which lambda is
shared (die, wafer, lot, region) does not change these marginal formulas but
changes the correlation between dies -- see spatial_defects / monte_carlo.

None of these models is "the most accurate" in general; the choice must be
made from observed dispersion in real manufacturing data (calibration.py).
"""
from __future__ import annotations

import math
from typing import Callable

import numpy as np

from .units import UnitError, require_nonneg, require_pos


def _check(area_cm2: float, d0_per_cm2: float) -> tuple[np.ndarray, np.ndarray]:
    a = np.asarray(area_cm2, dtype=float)
    d = np.asarray(d0_per_cm2, dtype=float)
    if not (np.all(np.isfinite(a)) and np.all(np.isfinite(d))):
        raise UnitError("area and defect density must be finite")
    if np.any(a < 0):
        raise UnitError(f"effective area must be >= 0 cm^2, got {area_cm2}")
    if np.any(d < 0):
        raise UnitError(f"defect density must be >= 0 /cm^2, got {d0_per_cm2}")
    return a, d


def _scalar(x: np.ndarray):
    return float(x) if np.ndim(x) == 0 else x


def poisson_yield(area_cm2, d0_per_cm2):
    a, d = _check(area_cm2, d0_per_cm2)
    return _scalar(np.exp(-a * d))


def negative_binomial_yield(area_cm2, d0_per_cm2, alpha: float):
    a, d = _check(area_cm2, d0_per_cm2)
    if alpha is not None and math.isinf(alpha) and alpha > 0:
        return _scalar(np.exp(-a * d))          # the Poisson limit, exactly
    alpha = require_pos(alpha, "alpha")
    # (1 + x/alpha)^(-alpha) = exp(-alpha * log1p(x/alpha)) -- stable for large alpha
    return _scalar(np.exp(-alpha * np.log1p(a * d / alpha)))


def seeds_yield(area_cm2, d0_per_cm2):
    return negative_binomial_yield(area_cm2, d0_per_cm2, 1.0)


def _one_minus_exp_over_x(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    out = np.empty_like(x)
    small = x < 1e-6
    out[small] = 1.0 - x[small] / 2.0 + x[small] ** 2 / 6.0
    xs = x[~small]
    out[~small] = -np.expm1(-xs) / xs
    return out


def murphy_yield(area_cm2, d0_per_cm2):
    """Murphy (1964) with a triangular defect-density distribution on [0, 2 D0]."""
    a, d = _check(area_cm2, d0_per_cm2)
    return _scalar(_one_minus_exp_over_x(np.atleast_1d(a * d)).reshape(np.shape(a * d)) ** 2)


def murphy_uniform_yield(area_cm2, d0_per_cm2):
    """Murphy with a uniform defect-density distribution on [0, 2 D0]."""
    a, d = _check(area_cm2, d0_per_cm2)
    return _scalar(_one_minus_exp_over_x(np.atleast_1d(2.0 * a * d)).reshape(np.shape(a * d)))


MODELS: dict[str, Callable] = {
    "poisson": poisson_yield,
    "negative_binomial": negative_binomial_yield,
    "seeds": seeds_yield,
    "murphy": murphy_yield,
    "murphy_uniform": murphy_uniform_yield,
}

ASSUMPTIONS = {
    "poisson": "defect density identical for every die (no clustering); fatal defects independent",
    "negative_binomial": "per-unit defect density ~ Gamma(alpha, D0/alpha); alpha = clustering parameter",
    "seeds": "per-die defect density exponentially distributed (NB with alpha = 1)",
    "murphy": "per-die defect density triangular on [0, 2 D0] (Murphy 1964)",
    "murphy_uniform": "per-die defect density uniform on [0, 2 D0]",
    "empirical": "parameters fitted to measured wafer data (calibration.py); requires imported data",
}


def evaluate(model: str, area_cm2, d0_per_cm2, alpha: float | None = None):
    if model == "negative_binomial":
        if alpha is None:
            raise UnitError("negative_binomial needs alpha")
        return negative_binomial_yield(area_cm2, d0_per_cm2, alpha)
    if model not in MODELS:
        raise KeyError(f"unknown yield model {model!r}; known: {sorted(MODELS)}")
    return MODELS[model](area_cm2, d0_per_cm2)


# --------------------------------------------------------------------------- Monte Carlo counterparts

def sample_defect_counts(model: str, n: int, area_cm2: float, d0_per_cm2: float, rng: np.random.Generator,
                         alpha: float | None = None) -> np.ndarray:
    """Sample fatal-defect counts for *n* independent dies (die-level intensity variation).

    The latent intensity is sampled per die, then the count conditionally on
    it.  This is the model *implied by the analytical formula* -- it is NOT a
    spatially clustered wafer model (see spatial_defects for that).
    """
    a = require_nonneg(area_cm2, "area_cm2")
    d0 = require_nonneg(d0_per_cm2, "d0_per_cm2")
    if model == "poisson":
        lam = np.full(n, d0)
    elif model in ("negative_binomial", "seeds"):
        al = 1.0 if model == "seeds" else require_pos(alpha, "alpha")
        lam = rng.gamma(shape=al, scale=d0 / al, size=n) if d0 > 0 else np.zeros(n)
    elif model == "murphy":
        lam = rng.triangular(0.0, d0, 2 * d0, size=n) if d0 > 0 else np.zeros(n)
    elif model == "murphy_uniform":
        lam = rng.uniform(0.0, 2 * d0, size=n)
    else:
        raise KeyError(model)
    return rng.poisson(lam * a)


def monte_carlo_yield(model: str, n: int, area_cm2: float, d0_per_cm2: float, rng: np.random.Generator,
                      alpha: float | None = None) -> tuple[float, float]:
    """Return (estimated yield, binomial standard error)."""
    k = sample_defect_counts(model, n, area_cm2, d0_per_cm2, rng, alpha)
    p = float(np.mean(k == 0))
    return p, math.sqrt(max(p * (1 - p), 1e-300) / n)


def nb_moments(area_cm2: float, d0_per_cm2: float, alpha: float) -> dict[str, float]:
    mu = area_cm2 * d0_per_cm2
    return {
        "mean_density": d0_per_cm2,
        "var_density": d0_per_cm2**2 / alpha,
        "mean_count": mu,
        "var_count": mu + mu * mu / alpha,
        "dispersion_index": 1 + mu / alpha,
        "p_zero": negative_binomial_yield(area_cm2, d0_per_cm2, alpha),
    }


def comparison_table(areas_cm2, d0_per_cm2: float, alpha: float) -> list[dict]:
    rows = []
    for a in np.atleast_1d(areas_cm2):
        rows.append(
            {
                "area_cm2": float(a),
                "poisson": poisson_yield(a, d0_per_cm2),
                f"negative_binomial(alpha={alpha:g})": negative_binomial_yield(a, d0_per_cm2, alpha),
                "seeds": seeds_yield(a, d0_per_cm2),
                "murphy": murphy_yield(a, d0_per_cm2),
                "murphy_uniform": murphy_uniform_yield(a, d0_per_cm2),
            }
        )
    return rows
