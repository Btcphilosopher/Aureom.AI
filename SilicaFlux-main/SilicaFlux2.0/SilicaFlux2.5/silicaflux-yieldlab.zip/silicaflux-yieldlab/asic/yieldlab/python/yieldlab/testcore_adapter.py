"""TestCore integration: evidence traceability and log import.

* :func:`march_coverage` parses TestCore r2 ``fault_coverage.md`` (generated from
  the RTL fault-injection regression) into a per-algorithm, per-fault-class table.
  The population is an enumerated SYNTHETIC single-fault set on an 8 x 16 model
  memory -- it is proxy evidence for MBIST detection, not silicon defect coverage.
* :func:`atpg_summary` reads TestCore r2 ``atpg/summary.json`` (in-house ATPG
  experiment on TestCore itself, not on SilicaFlux-V).
* :func:`load_session_logs` reads TestCore r1 ``lot_steps.csv`` / ``lot_failures.csv``
  host logs.  The example sessions in the repository were produced with the
  *simulation transport* (station ``sim-example``); they are labelled
  SIMULATED TESTCORE SESSION and can never become verified manufacturing data.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import pandas as pd

from .floorplan_adapter import THIRD_PARTY, _provenance_of

TC2 = THIRD_PARTY / "testcore_r2"
TC1 = THIRD_PARTY / "testcore_r1"


def march_coverage(path: Path = TC2 / "docs" / "fault_coverage.md") -> dict:
    text = path.read_text()
    lines = [l for l in text.splitlines() if l.startswith("|")]
    header = [h.strip() for h in lines[0].strip("|").split("|")]
    algos = header[1:]
    table = {}
    for l in lines[2:]:
        cells = [c.strip().strip("*") for c in l.strip("|").split("|")]
        cls = cells[0]
        table[cls] = {}
        for a, c in zip(algos, cells[1:]):
            m = re.match(r"(\d+)/(\d+)", c)
            if m:
                k, n = int(m.group(1)), int(m.group(2))
                table[cls][a] = {"detected": k, "injected": n, "coverage": k / n}
    cfg = re.search(r"Configuration `([^`]+)`", text)
    return {"algorithms": algos, "table": table, "configuration": cfg.group(1) if cfg else None,
            "population": "enumerated SYNTHETIC single-fault population (not silicon defect coverage)",
            "reference": _provenance_of(path)}


def atpg_summary(path: Path = TC2 / "atpg" / "summary.json") -> dict:
    d = json.loads(path.read_text())
    return {"fault_coverage_pct": d.get("fault_coverage_pct"), "test_coverage_pct": d.get("test_coverage_pct"),
            "faults_total": d.get("faults_total"), "classification": d.get("classification"),
            "scope": "TestCore r2 logic only (in-house research ATPG, NOT production ATPG, NOT SilicaFlux-V)",
            "reference": _provenance_of(path)}


def load_session_logs(steps: Path = TC1 / "logs" / "lot_steps.csv",
                      failures: Path = TC1 / "logs" / "lot_failures.csv") -> dict:
    s = pd.read_csv(steps)
    f = pd.read_csv(failures)
    simulated = bool(s["station"].astype(str).str.contains("sim").any())
    per_device = s.groupby("session_id").agg(ecid=("ecid", "first"), soft_bin=("soft_bin", "max"),
                                             hard_bin=("hard_bin", "max"), steps=("step", "size"),
                                             failed_steps=("status", lambda x: int((x != "PASS").sum())))
    return {"devices": per_device.reset_index().to_dict("records"),
            "mbist_failures": f.to_dict("records"),
            "label": "SIMULATED TESTCORE SESSION (sim transport) - not silicon" if simulated else "IMPORTED (unverified)",
            "reference": _provenance_of(steps)}
