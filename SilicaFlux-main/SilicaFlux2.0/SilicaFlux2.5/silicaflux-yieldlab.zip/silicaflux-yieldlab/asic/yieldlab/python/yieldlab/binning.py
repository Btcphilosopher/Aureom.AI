"""Configurable, reproducible test binning.

Bins are defined in YAML (configs/bins/*.yaml).  Each bin has a code, a name,
a priority (lower = evaluated first), a ``when`` condition and flags.  The
condition language is deliberately tiny and declarative -- no ``eval``:

    when: {all: [ {field: passed_all, eq: true}, {field: speed_grade, eq: "A"} ]}
    when: {any: [ {field: first_fail_category, in: [electrical]} ]}
    when: {not: {field: tested, eq: true}}
    when: {always: true}

Available die fields: tested, incomplete, passed_all, first_fail_step,
first_fail_category, speed_grade, conditional_repair, sram_fail_only,
repairable_under_hypothetical, reduced_config_candidate.

A bin that ``requires_capability`` is only active when that capability is
listed in ``active_capabilities`` -- reduced-functionality bins can never be
used for SilicaFlux-V because no such capability exists (audit).  Every die is
assigned exactly one bin; if no bin matches, the run fails (bins must be
exhaustive, enforced by the mandatory ``always`` fallback).
"""
from __future__ import annotations

from typing import Any, Optional

import numpy as np
from pydantic import BaseModel, ConfigDict, Field, model_validator


class BinDef(BaseModel):
    model_config = ConfigDict(extra="forbid")
    code: int
    name: str
    priority: int
    when: dict[str, Any]
    sellable: bool = False
    product: Optional[str] = None
    requires_capability: Optional[str] = None
    testcore_hard_bin: Optional[int] = None
    note: str = ""


class BinTable(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str
    reference: str = ""
    active_capabilities: list[str] = Field(default_factory=list)
    bins: list[BinDef]

    @model_validator(mode="after")
    def _check(self) -> "BinTable":
        codes = [b.code for b in self.bins]
        if len(codes) != len(set(codes)):
            raise ValueError("duplicate bin codes")
        if not any(b.when.get("always") for b in self.bins):
            raise ValueError("bin table needs a fallback bin with when: {always: true}")
        return self

    def active(self) -> list[BinDef]:
        bins = [b for b in self.bins if b.requires_capability is None or b.requires_capability in self.active_capabilities]
        return sorted(bins, key=lambda b: b.priority)


def _eval(cond: dict, fields: dict[str, np.ndarray], n: int) -> np.ndarray:
    if "always" in cond:
        return np.full(n, bool(cond["always"]))
    if "all" in cond:
        out = np.ones(n, bool)
        for c in cond["all"]:
            out &= _eval(c, fields, n)
        return out
    if "any" in cond:
        out = np.zeros(n, bool)
        for c in cond["any"]:
            out |= _eval(c, fields, n)
        return out
    if "not" in cond:
        return ~_eval(cond["not"], fields, n)
    if "field" in cond:
        f = cond["field"]
        if f not in fields:
            raise KeyError(f"bin condition uses unknown field {f!r}; known: {sorted(fields)}")
        v = fields[f]
        if "eq" in cond:
            return np.asarray(v == cond["eq"], bool)
        if "ne" in cond:
            return np.asarray(v != cond["ne"], bool)
        if "in" in cond:
            return np.isin(v, cond["in"])
        raise ValueError(f"bin condition needs eq / ne / in: {cond}")
    raise ValueError(f"malformed bin condition: {cond}")


def assign_bins(table: BinTable, fields: dict[str, np.ndarray], n: int) -> np.ndarray:
    codes = np.full(n, -1, dtype=int)
    for b in table.active():
        m = (codes < 0) & _eval(b.when, fields, n)
        codes[m] = b.code
    if (codes < 0).any():
        raise RuntimeError("bin table is not exhaustive")
    return codes
