"""Measured manufacturing-data ingestion (wafer maps, prober bin maps, defect lists, lot summaries).

Rules enforced here:

* original coordinates and bin codes are preserved (``orig_*`` columns);
* coordinate transforms (flip, rotate in 90 deg steps, offset, notch alignment)
  are explicit parameters and recorded;
* duplicate records, invalid / unknown bins, invalid measurements and missing
  dies are reported, never silently fixed;
* retests: if any die has more than one attempt for an insertion, a retest
  policy MUST be given (FIRST, LAST, WORST, or BEST -- BEST is accepted only
  with ``allow_best=True`` and is flagged as optimistic).  There is no default;
* the dataset label is ``VERIFIED IMPORTED DATA`` only when every validation
  check passes, otherwise ``IMPORTED - VALIDATION FAILED``.  Simulated data can
  never carry either label;
* data is treated as confidential: nothing is uploaded, and reports include
  only aggregates unless the caller explicitly asks for raw maps.

STDF: a parser is only used if ``pystdf`` is installed; otherwise STDF import is
reported as NOT AVAILABLE (convert to CSV with the ATE vendor tool first).
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal, Optional

import numpy as np
import pandas as pd

from .provenance import Source, Sourced

RetestPolicy = Literal["FIRST", "LAST", "WORST", "BEST"]
VERIFIED = "VERIFIED IMPORTED DATA"
FAILED = "IMPORTED - VALIDATION FAILED"
FIXTURE = "SYNTHETIC TEST FIXTURE - NOT MANUFACTURING DATA"
REQUIRED = ["lot", "wafer", "die_x", "die_y", "hard_bin"]


@dataclass
class ImportResult:
    data: pd.DataFrame
    label: str
    issues: list[dict] = field(default_factory=list)
    transform: dict = field(default_factory=dict)
    retest_policy: Optional[str] = None
    source_file: str = ""
    confidential: bool = True

    @property
    def verified(self) -> bool:
        return self.label == VERIFIED

    def summary(self) -> dict:
        d = self.data
        return {"label": self.label, "source_file": self.source_file, "records": int(len(d)),
                "lots": int(d["lot"].nunique()) if len(d) else 0,
                "wafers": int(d.groupby(["lot", "wafer"]).ngroups) if len(d) else 0,
                "issues": self.issues, "transform": self.transform, "retest_policy": self.retest_policy,
                "confidential": self.confidential}


def transform_coords(x: np.ndarray, y: np.ndarray, flip_x: bool = False, flip_y: bool = False, rotate_deg: int = 0,
                     offset: tuple[int, int] = (0, 0)) -> tuple[np.ndarray, np.ndarray]:
    """Prober die coordinates -> YieldLab die indices.  Order: flip, rotate (CCW), offset."""
    if rotate_deg % 90:
        raise ValueError("rotation must be a multiple of 90 degrees")
    x = np.asarray(x).copy()
    y = np.asarray(y).copy()
    if flip_x:
        x = -x
    if flip_y:
        y = -y
    for _ in range((rotate_deg // 90) % 4):
        x, y = -y, x
    return x + offset[0], y + offset[1]


def load_wafer_map_csv(path: str | Path, good_bins: list[int], valid_bins: Optional[list[int]] = None,
                       retest_policy: Optional[RetestPolicy] = None, allow_best: bool = False,
                       column_map: Optional[dict[str, str]] = None, flip_x: bool = False, flip_y: bool = False,
                       rotate_deg: int = 0, offset: tuple[int, int] = (0, 0),
                       expected_sites: Optional[set[tuple[int, int]]] = None,
                       insertion: Optional[str] = None) -> ImportResult:
    df = pd.read_csv(path)
    if column_map:
        df = df.rename(columns={v: k for k, v in column_map.items()})
    issues: list[dict] = []
    missing_cols = [c for c in REQUIRED if c not in df.columns]
    if missing_cols:
        raise ValueError(f"{path}: missing required columns {missing_cols} (have {list(df.columns)})")
    if "insertion" not in df.columns:
        df["insertion"] = "probe"
    if insertion:
        df = df[df["insertion"] == insertion]
    if "attempt" not in df.columns:
        df["attempt"] = 1
    # invalid measurements
    for c in ("die_x", "die_y", "hard_bin", "attempt"):
        bad = pd.to_numeric(df[c], errors="coerce").isna()
        if bad.any():
            issues.append({"check": "invalid_value", "column": c, "rows": df.index[bad].tolist()[:20],
                           "count": int(bad.sum())})
    df = df[~df[["die_x", "die_y", "hard_bin", "attempt"]].apply(pd.to_numeric, errors="coerce").isna().any(axis=1)]
    df = df.astype({"die_x": int, "die_y": int, "hard_bin": int, "attempt": int})
    df["orig_die_x"], df["orig_die_y"], df["orig_hard_bin"] = df["die_x"], df["die_y"], df["hard_bin"]
    # exact duplicates of (lot, wafer, x, y, insertion, attempt)
    key = ["lot", "wafer", "die_x", "die_y", "insertion", "attempt"]
    dup = df.duplicated(key, keep=False)
    if dup.any():
        issues.append({"check": "duplicate_records", "count": int(dup.sum()),
                       "examples": df[dup].head(5)[key].to_dict("records")})
    # invalid bins
    if valid_bins is not None:
        inv = ~df["hard_bin"].isin(valid_bins)
        if inv.any():
            issues.append({"check": "unknown_bin", "count": int(inv.sum()),
                           "bins": sorted(df.loc[inv, "hard_bin"].unique().tolist())})
    # retests
    multi = df.groupby(["lot", "wafer", "die_x", "die_y", "insertion"])["attempt"].nunique()
    has_retest = bool((multi > 1).any())
    if has_retest:
        if retest_policy is None:
            raise ValueError(f"{path}: {int((multi > 1).sum())} dies have retests; an explicit retest_policy "
                             "(FIRST, LAST, WORST or BEST) is required - none is chosen silently")
        if retest_policy == "BEST" and not allow_best:
            raise ValueError("retest_policy BEST selects the most favourable result; pass allow_best=True to accept")
        df["_good"] = df["hard_bin"].isin(good_bins)
        df = df.sort_values(["lot", "wafer", "die_x", "die_y", "insertion", "attempt"])
        g = df.groupby(["lot", "wafer", "die_x", "die_y", "insertion"], sort=False)
        if retest_policy == "FIRST":
            df = g.head(1)
        elif retest_policy == "LAST":
            df = g.tail(1)
        elif retest_policy == "WORST":
            df = df.sort_values("_good", kind="stable").groupby(["lot", "wafer", "die_x", "die_y", "insertion"]).head(1)
        else:
            df = df.sort_values("_good", ascending=False, kind="stable").groupby(
                ["lot", "wafer", "die_x", "die_y", "insertion"]).head(1)
            issues.append({"check": "retest_policy_optimistic", "count": int((multi > 1).sum()),
                           "note": "BEST retest policy inflates yield"})
        df = df.drop(columns="_good")
    x, y = transform_coords(df["die_x"].to_numpy(), df["die_y"].to_numpy(), flip_x, flip_y, rotate_deg, offset)
    df["die_x"], df["die_y"] = x, y
    df["good"] = df["hard_bin"].isin(good_bins)
    if expected_sites is not None:
        for (lot, wafer), grp in df.groupby(["lot", "wafer"]):
            have = set(zip(grp["die_x"], grp["die_y"]))
            miss = expected_sites - have
            extra = have - expected_sites
            if miss:
                issues.append({"check": "missing_dies", "lot": lot, "wafer": wafer, "count": len(miss)})
            if extra:
                issues.append({"check": "dies_outside_expected_map", "lot": lot, "wafer": wafer, "count": len(extra)})
    blocking = {"invalid_value", "duplicate_records", "unknown_bin", "missing_dies", "dies_outside_expected_map"}
    label = FAILED if any(i["check"] in blocking for i in issues) else VERIFIED
    # a file that declares itself non-measured (data_origin column) can never be labelled verified data
    if "data_origin" in df.columns and (df["data_origin"].astype(str).str.lower() != "measured").any():
        label = FIXTURE if label == VERIFIED else FAILED
        issues.append({"check": "data_origin_not_measured", "values": sorted(df["data_origin"].astype(str).unique())})
    return ImportResult(df.reset_index(drop=True), label, issues,
                        {"flip_x": flip_x, "flip_y": flip_y, "rotate_deg": rotate_deg, "offset": list(offset)},
                        retest_policy if has_retest else None, str(path))


def wafer_counts(res: ImportResult, allow_fixture: bool = False) -> pd.DataFrame:
    """Per-wafer good / total counts for calibration (only from verified data).

    ``allow_fixture`` lets a SYNTHETIC TEST FIXTURE be used to demonstrate the calibration code; the
    result keeps the fixture label and is never manufacturing evidence."""
    if not (res.verified or (allow_fixture and res.label == FIXTURE)):
        raise ValueError(f"dataset is not verified ({res.label}); fix the reported issues before calibration")
    g = res.data.groupby(["lot", "wafer"])
    return pd.DataFrame({"good": g["good"].sum(), "total": g.size()}).reset_index()


def load_defect_json(path: str | Path) -> dict:
    """Inspection defect list: {"lot":..,"wafer":..,"defects":[{"x_mm":..,"y_mm":..,"size_um":..,"class":..}]}.

    These are INSPECTION particles, not fatal defects: a defect-to-failure model is still needed."""
    d = json.loads(Path(path).read_text())
    defs = d.get("defects", [])
    issues = []
    xs, ys = [], []
    for i, rec in enumerate(defs):
        try:
            xs.append(float(rec["x_mm"]))
            ys.append(float(rec["y_mm"]))
        except (KeyError, TypeError, ValueError):
            issues.append({"check": "invalid_defect_record", "index": i})
    return {"lot": d.get("lot"), "wafer": d.get("wafer"), "x": np.array(xs), "y": np.array(ys),
            "classes": [r.get("class", "unknown") for r in defs], "issues": issues,
            "label": VERIFIED if not issues else FAILED, "kind": "inspection particles (NOT fatal defects)"}


def load_lot_summary_csv(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    need = {"lot", "wafer", "good", "total"}
    if not need <= set(df.columns):
        raise ValueError(f"lot summary needs columns {sorted(need)}")
    if (df["good"] > df["total"]).any() or (df["good"] < 0).any():
        raise ValueError("lot summary has good > total or negative counts")
    return df


def stdf_status() -> Sourced:
    try:  # pragma: no cover
        import pystdf  # noqa: F401

        return Sourced(value=True, source=Source.DESIGN_INPUT, reference="pystdf importable")
    except Exception:
        return Sourced.na("STDF parser (pystdf)", "not installed; convert STDF to CSV with the ATE tools")
