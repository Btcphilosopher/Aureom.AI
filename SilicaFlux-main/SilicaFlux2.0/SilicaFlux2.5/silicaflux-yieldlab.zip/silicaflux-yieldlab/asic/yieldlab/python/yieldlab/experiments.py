"""Experiment / scenario manager: controlled, paired comparisons A-J and sensitivity studies.

Pairing method (common random numbers): both arms of a comparison use the same
seed, lot and wafer indices, and the per-mechanism random streams of
monte_carlo.py.  Arms that change only test coverage, repair or fatality see
identical defect maps; arms that change the die see identical wafer-level
defect point processes.  Differences are reported with lot-cluster confidence
intervals of the paired differences (statistics.paired_difference), never as
bare point estimates.
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Any, Callable, Optional

import numpy as np

from . import statistics as st, yield_models as ym
from .chiplets import PackageSpec, monolithic_vs_chiplets
from .cluster_analysis import analyse
from .config import CONFIG_ROOT, Scenario, load_scenario, load_yaml
from .costs import StageCounts, full_wafer_cost, load_costs, mpw_cost
from .die_layout import DieSpec, LayoutSpec, ReticleSpec, layout_wafer
from .memory_repair import RepairCapability
from .monte_carlo import build_runtime, run_simulation
from .optimisation import architecture_variants, constraints, evaluate, floorplan_run_candidates, pareto_front
from .process_profiles import availability_table, compare as node_compare, load_nodes
from .provenance import Source
from .spatial_defects import Cluster, Uniform
from .test_model import Coverage
from .wafer_geometry import WaferSpec

BASE = CONFIG_ROOT / "silicaflux_v.yaml"
METRICS = ["outcome_TRUE_GOOD_PASS", "functional_fail_raw", "outcome_DEFECTIVE_ESCAPED", "delivered_conforming"]


def _no_param(s: Scenario) -> Scenario:
    return s


def paired(a: Scenario, b: Scenario, lots: int, wpl: int, names=("A", "B")) -> dict:
    ra = run_simulation(a, lots=lots, wafers_per_lot=wpl, keep_maps=0)
    rb = run_simulation(b, lots=lots, wafers_per_lot=wpl, keep_maps=0)
    out = {"arms": {names[0]: a.name, names[1]: b.name}, "lots": lots, "wafers_per_lot": wpl,
           "seed": a.monte_carlo.seed, "eligible": {names[0]: int(ra.wafers["eligible"].iloc[0]),
                                                    names[1]: int(rb.wafers["eligible"].iloc[0])},
           "differences": [st.paired_difference(ra.wafers, rb.wafers, m, seed=a.monte_carlo.seed) for m in METRICS]}
    for nm, r in zip(names, (ra, rb)):
        df = st.add_derived(r.wafers)
        out[f"means_{nm}"] = {m: float(df[m].mean()) for m in METRICS + ["true_good_yield", "defect_limited_yield"]}
        out[f"sd_{nm}"] = {m: float(df[m].std(ddof=1)) for m in METRICS}
    return out


def scn(**ov) -> Scenario:
    return load_scenario(BASE, ov)


# --------------------------------------------------------------------------- A-J

def exp_A(lots, wpl):
    """Small vs large die: FloorplanLab SA_01 (smallest completed die) vs L_west_east_columns (largest)."""
    a = scn(**{"design.floorplan_run": "SA_01"})
    b = scn(**{"design.floorplan_run": "L_west_east_columns"})
    a.name, b.name = "die_SA_01_7.44mm2", "die_L_west_east_10.38mm2"
    r = paired(a, b, lots, wpl, ("small", "large"))
    r["note"] = ("both dies MEASURED (FloorplanLab, same netlist); SA_01 fails timing (GRT WNS -6.12 ns) and "
                 "L_west_east_columns too (-7.25 ns) - geometric/yield comparison only")
    return r


def exp_B(lots, wpl):
    """Poisson vs negative binomial: same mean fatal density, wafer-level gamma intensity (alpha 2) vs none."""
    a = scn(**{"defects": load_yaml(CONFIG_ROOT / "defects/uniform_fatal.yaml")["defects"]})
    b = a.model_copy(deep=True)
    b.defects.variation.alpha_wafer = 2.0
    a.name, b.name = "poisson_uniform", "nb_wafer_alpha2"
    r = paired(a, b, lots, wpl, ("poisson", "nb"))
    area = build_runtime(a).die.area_cm2
    d0 = a.defects.components[0].density_per_cm2
    r["analytical"] = {"poisson": ym.poisson_yield(area, d0), "nb_alpha2": ym.negative_binomial_yield(area, d0, 2.0)}
    r["note"] = "the MEAN good-die count barely moves; wafer-to-wafer spread (sd, PI) grows with clustering"
    return r


def exp_C(lots, wpl):
    """Uniform vs clustered defects at equal mean intensity (Thomas process, 10 offspring, sigma 3 mm)."""
    a = scn(**{"defects": load_yaml(CONFIG_ROOT / "defects/uniform_fatal.yaml")["defects"]})
    b = a.model_copy(deep=True)
    d0 = a.defects.components[0].density_per_cm2
    b.defects.components = [Cluster(name="clusters", parent_density_per_cm2=d0 / 10, mean_offspring=10, sigma_mm=3.0)]
    a.name, b.name = "uniform", "clustered"
    return paired(a, b, lots, wpl, ("uniform", "clustered"))


def exp_D(lots, wpl):
    """Edge-exclusion sensitivity (geometry + MC)."""
    rows = []
    for e in (1.5, 2.0, 3.0, 5.0, 8.0):
        s = scn(**{"wafer.edge_exclusion_mm": e})
        r = run_simulation(s, lots=lots, wafers_per_lot=wpl, keep_maps=0)
        df = r.wafers
        rows.append({"edge_exclusion_mm": e, "eligible": int(df["eligible"].iloc[0]),
                     "true_good_mean": float(df["outcome_TRUE_GOOD_PASS"].mean()),
                     "true_good_ci95": st.mean_ci(df, "outcome_TRUE_GOOD_PASS")["ci_lot_cluster_t"]})
    return {"rows": rows, "note": "edge exclusion is HYPOTHETICAL (no foundry value); defects near the edge are "
                                  "partly removed together with the excluded dies"}


def exp_E(lots, wpl):
    """SRAM redundancy (hypothetical rows+cols, 4+4 per macro) vs no repair."""
    a = scn()
    b = a.model_copy(deep=True)
    b.sram.repair = RepairCapability(scheme="rows_cols", spare_rows=4, spare_cols=4, area_overhead_fraction_of_sram=0.03)
    a.name, b.name = "no_repair", "hyp_rows_cols_4x4"
    r = paired(a, b, lots, wpl, ("none", "rows_cols"))
    ra = run_simulation(b, lots=lots, wafers_per_lot=wpl, keep_maps=0).wafers
    r["conditional_dies_per_wafer"] = float(ra["repaired_conditional"].mean())
    r["conditional_good_pass_per_wafer"] = float(ra["outcome_CONDITIONAL_GOOD_PASS"].mean())
    ecc = a.model_copy(deep=True)
    ecc.sram.repair = RepairCapability(scheme="ecc")
    re_ = run_simulation(ecc, lots=lots, wafers_per_lot=wpl, keep_maps=0).wafers
    r["ecc_conditional_dies_per_wafer"] = float(re_["repaired_conditional"].mean())
    r["note"] = ("repair is CONDITIONAL: no SilicaFlux macro has spare rows/cols, no fuses, CAPS.REPAIR = 0; true good "
                 "dies are unchanged and the potential gain appears only as CONDITIONAL_GOOD_PASS. Area overhead of "
                 "redundancy is not included in the die here (see optimisation VAR:sram_spare_rows).")
    return r


def exp_F(lots, wpl):
    """High vs low MBIST sensitivity: March C- (TestCore r2: 93.3 % all classes) vs MATS+ (76.8 %)."""
    a = scn()
    b = a.model_copy(deep=True)
    for stp in b.tests.steps:
        if stp.name == "mbist":
            stp.coverage["sram:bit"] = Coverage(value=1824 / 2376, source=Source.MEASURED_TOOL_OUTPUT,
                                                reference="TestCore r2 fault_coverage.md MATS+ all classes 1824/2376 (synthetic)")
            stp.coverage["sram:column"] = Coverage(value=1.0, source=Source.MEASURED_TOOL_OUTPUT,
                                                   reference="MATS+ data-line stuck 16/16")
    a.name, b.name = "march_c_minus", "mats_plus"
    r = paired(a, b, lots, wpl, ("march_c-", "mats+"))
    r["note"] = "coverage values from TestCore r2 RTL fault injection on a SYNTHETIC population (proxy evidence)"
    return r


def exp_G(d0_grid=(0.1, 0.25, 0.5, 1.0)):
    """130 nm vs 65 nm: only what the repository supports (die size); D0 / prices NOT AVAILABLE."""
    nodes = load_nodes()
    wafer = WaferSpec(diameter_mm=200, edge_exclusion_mm=3)
    return {"availability": availability_table(nodes),
            "comparison": node_compare(nodes, wafer, 80, list(d0_grid), 3.0),
            "note": "same HYPOTHETICAL D0 grid for every node (no node-specific D0 exists); 65 nm die is a "
                    "PLANNING_ESTIMATE; no node can be ranked on cost: every wafer / MPW price is NOT AVAILABLE"}


def exp_H(sim_counts: Optional[dict] = None):
    """MPW prototypes vs dedicated-wafer economics (HYPOTHETICAL prices from configs/costs/example_costs.yaml)."""
    c = load_yaml(CONFIG_ROOT / "costs/example_costs.yaml")["costs"]
    fw, mp, _ = load_costs(c)
    s = scn()
    r = run_simulation(s, lots=1, wafers_per_lot=25, keep_maps=0)
    df = r.wafers
    y = float(df["outcome_TRUE_GOOD_PASS"].sum() / df["eligible"].sum())
    out = {"die_yield_used": y, "mpw": mpw_cost(mp, r.runtime.die.area_mm2, y, "SIMULATED - HYPOTHETICAL")}
    rows = []
    for n_w in (1, 5, 25, 100):
        k = n_w / len(df)
        counts = StageCounts(**{f: getattr(StageCounts.from_wafers(df), f) * k for f in
                                ("wafers", "eligible", "tested", "probe_pass", "true_good_at_probe", "packaged",
                                 "delivered", "delivered_conforming", "delivered_escape")})
        fwc = fw.model_copy(update={"nre_amortisation_units": None})
        res = full_wafer_cost(fwc, counts)
        rows.append({"wafers": n_w, "delivered_conforming": counts.delivered_conforming, "total_cost": res["total_cost"],
                     "cost_per_conforming_die_incl_nre": res["cost_per_delivered_conforming_die"],
                     "recurring_cost_per_conforming_die": res["recurring_cost_per_delivered_conforming_die"]})
    out["dedicated"] = rows
    out["note"] = ("MPW buys a tile on shared wafers (quoted samples); a dedicated run buys whole wafers + a mask set. "
                   "All prices HYPOTHETICAL; the comparison shows structure, not a quote")
    return out


def exp_I(d0: float = 0.25, alpha: float = 3.0):
    """Monolithic SilicaFlux-V vs a hypothetical 2-chiplet split (compute + memory)."""
    rt = build_runtime(scn())
    mono = rt.die.area_mm2
    sram = sum(r.located_area_um2 for r in rt.rm.regions if r.kind == "sram") / 1e6
    pad = next(r for r in rt.rm.regions if r.name == "io_pads").located_area_um2 / 1e6
    rest = mono - sram - pad
    wafer = WaferSpec(diameter_mm=200, edge_exclusion_mm=3)

    def gross(area_mm2):
        side = math.sqrt(area_mm2) * 1000
        d = DieSpec(name="x", width_um=side, height_um=side, source=Source.HYPOTHETICAL, reference="chiplet",
                    scribe_x_um=80, scribe_y_um=80)
        return layout_wafer(wafer, d, ReticleSpec(enabled=False), LayoutSpec()).n_full

    pkg = PackageSpec(bond_yield_per_interface=0.995, n_interfaces=1, interposer_yield=1.0, assembly_yield=0.98,
                      final_test_coverage=0.95, interposer_cost=0.0, assembly_cost=1.5, final_test_cost=0.4)
    # each chiplet carries its own pad ring share: half the monolithic ring area each (HYPOTHETICAL)
    res = monolithic_vs_chiplets(mono, [("compute+io", rest + pad / 2), ("sram", sram + pad / 2)], 0.6, d0, alpha,
                                 2500.0, gross, pkg, mono_pkg_cost=0.85, test_escape=0.004)
    res["assumptions"] = {"d0_per_cm2": d0, "alpha": alpha, "d2d_overhead_mm2_each": 0.6, "wafer_cost": 2500.0,
                          "status": "ALL HYPOTHETICAL - research comparison, not part of the SilicaFlux-V flow"}
    return res


def exp_J(d0_grid=(0.1, 0.25, 0.5, 1.0)):
    """Reduced tensor array vs full tensor (die from estimate rule; analytical + geometry)."""
    cands = [c for c in floorplan_run_candidates() if c.name == "FLP:C_sram_near_compute"] + \
        [c for c in architecture_variants() if c.name in ("VAR:tensor_2x2",)]
    rows = evaluate(cands, WaferSpec(diameter_mm=200, edge_exclusion_mm=3), 300, 80, list(d0_grid), 3.0, 2500.0, 0.9)
    for r in rows:
        r["violations"] = constraints(r)
    return {"rows": rows, "note": "the 2x2 tensor die is an ESTIMATE (no RTL, no FloorplanLab run); it also loses "
                                  "75 % of peak MAC throughput - fails the required-functionality constraint"}


EXPERIMENTS: dict[str, Callable] = {"A": exp_A, "B": exp_B, "C": exp_C, "D": exp_D, "E": exp_E, "F": exp_F,
                                    "G": exp_G, "H": exp_H, "I": exp_I, "J": exp_J}
MC_EXPERIMENTS = {"A", "B", "C", "D", "E", "F"}


def run_experiments(which: str = "ABCDEFGHIJ", lots: int = 6, wpl: int = 10) -> dict:
    out = {}
    for k in which:
        f = EXPERIMENTS[k]
        out[k] = {"title": f.__doc__.strip().splitlines()[0], **(f(lots, wpl) if k in MC_EXPERIMENTS else f())}
    return out


# --------------------------------------------------------------------------- studies

def d0_sensitivity(d0_grid=(0.05, 0.1, 0.25, 0.5, 1.0, 2.0), alphas=(0.5, 2.0, 10.0), lots=3, wpl=8) -> dict:
    s = scn(**{"defects": load_yaml(CONFIG_ROOT / "defects/uniform_fatal.yaml")["defects"]})
    rt = build_runtime(s)
    a = rt.die.area_cm2
    rows = []
    for d0 in d0_grid:
        sd = s.model_copy(deep=True)
        sd.defects.components[0].density_per_cm2 = d0
        df = run_simulation(sd, lots=lots, wafers_per_lot=wpl, keep_maps=0, runtime=None).wafers
        y_mc = float((df["eligible"] - df["functional_fail_raw"]).sum() / df["eligible"].sum())
        row = {"d0_per_cm2": d0, "poisson": ym.poisson_yield(a, d0), "murphy": ym.murphy_yield(a, d0),
               "seeds": ym.seeds_yield(a, d0), "simulated_uniform": y_mc,
               "true_good_per_wafer": float(df["outcome_TRUE_GOOD_PASS"].mean())}
        for al in alphas:
            row[f"nb_alpha_{al:g}"] = ym.negative_binomial_yield(a, d0, al)
        rows.append(row)
    return {"die_area_cm2": a, "eligible": int(rt.elig.size), "rows": rows,
            "note": "D0 values are a HYPOTHETICAL sweep; no SilicaFlux D0 exists"}


def nb_wafer_rel_sd(n: int, area_cm2: float, d0: float, alpha: float) -> float:
    """Relative sd of good dies per wafer when the wafer intensity is Gamma(alpha, d0/alpha) (exact moments):
    Var(G) = N (E[p] - E[p^2]) + N^2 Var(p),  E[p^k] = (1 + k A D0 / alpha)^-alpha."""
    e1 = (1 + area_cm2 * d0 / alpha) ** -alpha
    e2 = (1 + 2 * area_cm2 * d0 / alpha) ** -alpha
    var = n * (e1 - e2) + n * n * (e2 - e1 * e1)
    return math.sqrt(max(var, 0.0)) / (n * e1) if n * e1 > 0 else float("inf")


def optimisation_study(d0: float = 0.25, alpha: float = 3.0, wafer_cost: float = 2500.0, per_die: float = 0.9) -> dict:
    cands = floorplan_run_candidates() + architecture_variants()
    rows = evaluate(cands, WaferSpec(diameter_mm=200, edge_exclusion_mm=3), 300, 80, [d0], alpha, wafer_cost, per_die)
    for r in rows:
        r["violations"] = constraints(r)
        r["violations_strict"] = constraints(r, strict_routability=True)
        r["feasible"] = not r["violations"]
        r["rel_sd_good_per_wafer"] = nb_wafer_rel_sd(r["gross_die"], r["die_area_mm2"] / 100, d0, alpha)
    feas = [r for r in rows if r["feasible"]]
    front = pareto_front(feas, {"good_die_nb": "max", "cost_per_good_die_nb": "min", "die_area_mm2": "min",
                                "rel_sd_good_per_wafer": "min"}) if feas else []
    return {"rows": rows, "feasible": [r["candidate"] for r in feas],
            "pareto": [feas[i]["candidate"] for i in front],
            "strict_feasible": [r["candidate"] for r in rows if not r["violations_strict"]],
            "assumptions": {"d0_per_cm2": d0, "alpha": alpha, "wafer_cost": wafer_cost, "per_die_cost": per_die,
                            "pad_ring_um": 300, "scribe_um": 80, "wafer": "200 mm, 3 mm exclusion",
                            "status": "HYPOTHETICAL economics; die sizes MEASURED (FLP) or ESTIMATED (VAR)"}}


def cluster_study(lots=1, wpl=4) -> dict:
    s = load_scenario(CONFIG_ROOT / "silicaflux_v_all_generators.yaml")
    r = run_simulation(s, lots=lots, wafers_per_lot=wpl, keep_maps=wpl)
    out = []
    rt = r.runtime
    nfx, nfy = rt.wmap.dies_per_field
    field = (nfx * rt.wmap.pitch_mm[0], nfy * rt.wmap.pitch_mm[1])
    origin = (rt.wmap.offset_mm[0] - rt.wmap.pitch_mm[0] / 2, rt.wmap.offset_mm[1] - rt.wmap.pitch_mm[1] / 2)
    for key, m in sorted(r.maps.items()):
        x = np.asarray(m["defects"]["x"])
        y = np.asarray(m["defects"]["y"])
        a = analyse(x, y, rt.geo.R, "SIMULATED", field, origin)
        out.append({"wafer": list(key), **{k: v for k, v in a.items() if k != "labels"},
                    "cluster_labels": a["labels"].tolist(),
                    "true_generators": m["defects"]["generators"], "gen_of_point": m["defects"]["gen"],
                    "x": m["defects"]["x"], "y": m["defects"]["y"]})
    return {"scenario": s.name, "wafers": out, "label": "SIMULATED (synthetic generators A-I)"}
