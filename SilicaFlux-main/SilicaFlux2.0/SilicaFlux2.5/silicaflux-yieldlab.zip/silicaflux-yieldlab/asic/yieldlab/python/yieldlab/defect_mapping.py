"""Exact mapping of defects to die sites and to functional regions inside the die.

* Point / finite-size defects are discs of diameter ``size_um``.  A defect hits
  a die when the disc overlaps the **die rectangle** (not the street, not the
  bounding pitch cell) -- computed exactly from the closest point of the
  rectangle to the disc centre.  A large defect can hit up to four dies; each
  overlap is a separate hit with the same event id.
* Extended defects (scratches, polygons) are Shapely geometries; dies are found
  with an STR-tree and exact ``intersects``.  The intersection with each die is
  sampled every ``sample_spacing_um`` (lines: along the path; polygons: on a
  grid) so the defect can be attributed to every region it crosses.  All
  samples of one extended defect in one die share an event id.
* Region attribution uses the point of the defect inside the die that is
  closest to the defect centre (for discs) or the sample points (extended).

Counting rules: ``defect_count`` per die = number of distinct *events* that hit
it (a scratch crossing a die is one defect); a die is failed once, however
many fatal defects it has (no double counting in failed-die counts).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import shapely
from shapely.ops import nearest_points
from shapely.strtree import STRtree

from .fatality import FatalityModel
from .regions import RegionModel
from .spatial_defects import DefectSet


@dataclass
class Hits:
    site: np.ndarray        # index into the wafer map site arrays
    event: np.ndarray       # defect event id (unique per wafer)
    rid: np.ndarray         # region id
    macro: np.ndarray       # macro index or -1
    lx_um: np.ndarray       # die-local position (um, region-model frame)
    ly_um: np.ndarray
    cls: np.ndarray
    layer: np.ndarray
    size_um: np.ndarray
    severity: np.ndarray
    gen: np.ndarray
    fatal: np.ndarray

    @property
    def n(self) -> int:
        return int(self.site.size)

    @classmethod
    def empty(cls) -> "Hits":
        z = np.zeros(0, int)
        f = np.zeros(0)
        return cls(z, z, z, z, f, f, z, z, f, f, z, np.zeros(0, bool))


def _concat(parts: list[Hits]) -> Hits:
    parts = [p for p in parts if p.n]
    if not parts:
        return Hits.empty()
    return Hits(*[np.concatenate([getattr(p, f) for p in parts]) for f in Hits.__dataclass_fields__])


def _to_local(wmap, site: np.ndarray, px: np.ndarray, py: np.ndarray, rm: RegionModel):
    """Wafer mm -> die-local um in the region-model frame (handles 90 deg die rotation)."""
    u = (px - wmap.dx0[site]) * 1000.0
    v = (py - wmap.dy0[site]) * 1000.0
    if wmap.die.rotation_deg == 90:
        # die rotated +90 deg on the wafer: local (u, v) on wafer -> design frame (v, W_design - u)
        u, v = v, rm.die_h_um - u
        u = np.clip(u, 0, rm.die_w_um)
    return u, v


def map_points(ds: DefectSet, wmap, rm: RegionModel, rng: np.random.Generator) -> Hits:
    if ds.n_points == 0:
        return Hits.empty()
    px, py = wmap.pitch_mm
    ox, oy = wmap.offset_mm
    # site lookup table (ix, iy) -> site index
    imin, jmin = int(wmap.ix.min()), int(wmap.iy.min())
    nx, ny = int(wmap.ix.max()) - imin + 1, int(wmap.iy.max()) - jmin + 1
    lut = np.full((nx, ny), -1, dtype=int)
    lut[wmap.ix - imin, wmap.iy - jmin] = np.arange(wmap.n_sites)
    ci = np.rint((ds.x - ox) / px).astype(int)
    cj = np.rint((ds.y - oy) / py).astype(int)
    rad = ds.size_um / 2000.0                    # radius in mm
    parts_site, parts_def, parts_x, parts_y = [], [], [], []
    for di in (-1, 0, 1):
        for dj in (-1, 0, 1):
            ii = ci + di - imin
            jj = cj + dj - jmin
            ok = (ii >= 0) & (ii < nx) & (jj >= 0) & (jj < ny)
            site = np.full(ds.n_points, -1)
            site[ok] = lut[ii[ok], jj[ok]]
            ok &= site >= 0
            if not ok.any():
                continue
            d = np.nonzero(ok)[0]
            s = site[d]
            qx = np.clip(ds.x[d], wmap.dx0[s], wmap.dx1[s])
            qy = np.clip(ds.y[d], wmap.dy0[s], wmap.dy1[s])
            dist2 = (qx - ds.x[d]) ** 2 + (qy - ds.y[d]) ** 2
            inside = (ds.x[d] >= wmap.dx0[s]) & (ds.x[d] <= wmap.dx1[s]) & (ds.y[d] >= wmap.dy0[s]) & (ds.y[d] <= wmap.dy1[s])
            hit = inside | (dist2 < rad[d] ** 2)
            parts_site.append(s[hit])
            parts_def.append(d[hit])
            parts_x.append(qx[hit])
            parts_y.append(qy[hit])
    if not parts_site:
        return Hits.empty()
    site = np.concatenate(parts_site)
    dfi = np.concatenate(parts_def)
    qx = np.concatenate(parts_x)
    qy = np.concatenate(parts_y)
    lx, ly = _to_local(wmap, site, qx, qy, rm)
    rid, macro = rm.locate(lx, ly, rng)
    return Hits(site, dfi, rid, macro, lx, ly, ds.cls[dfi], ds.layer[dfi], ds.size_um[dfi], ds.severity[dfi],
                ds.gen[dfi], np.zeros(site.size, bool))


def map_extended(ds: DefectSet, wmap, rm: RegionModel, rng: np.random.Generator, sample_spacing_um: float = 50.0,
                 tree: STRtree | None = None) -> Hits:
    if not ds.extended:
        return Hits.empty()
    boxes = shapely.box(wmap.dx0, wmap.dy0, wmap.dx1, wmap.dy1)
    tree = tree or STRtree(boxes)
    parts = []
    base_event = ds.n_points
    step = sample_spacing_um / 1000.0
    for k, e in enumerate(ds.extended):
        geom = e["geom"]
        width_mm = e.get("width_um", 0.0) / 1000.0
        g = geom.buffer(width_mm / 2) if width_mm > 0 and geom.geom_type in ("LineString", "MultiLineString") else geom
        cand = tree.query(g, predicate="intersects")
        for s in cand:
            inter = shapely.intersection(geom, boxes[s]) if geom.geom_type != "Polygon" else geom.intersection(boxes[s])
            pts = _sample(inter, step)
            if pts.size == 0:        # width-only overlap: use the closest point of the die to the scratch
                p = nearest_points(boxes[s], geom)[0]
                pts = np.array([[p.x, p.y]])
            site = np.full(len(pts), s)
            lx, ly = _to_local(wmap, site, pts[:, 0], pts[:, 1], rm)
            rid, macro = rm.locate(lx, ly, rng)
            m = len(pts)
            parts.append(Hits(site, np.full(m, base_event + k), rid, macro, lx, ly, np.full(m, e["cls"]),
                              np.full(m, e["layer"]), np.full(m, max(e.get("width_um", 1.0), 1e-3)),
                              np.full(m, e["severity"]), np.full(m, e["gen"]), np.zeros(m, bool)))
    return _concat(parts)


def _sample(geom, step: float) -> np.ndarray:
    if geom.is_empty:
        return np.zeros((0, 2))
    if geom.geom_type in ("LineString", "MultiLineString"):
        lines = [geom] if geom.geom_type == "LineString" else list(geom.geoms)
        pts = []
        for ln in lines:
            n = max(int(np.ceil(ln.length / step)), 1)
            for t in np.linspace(0, ln.length, n + 1):
                p = ln.interpolate(t)
                pts.append((p.x, p.y))
        return np.array(pts)
    if geom.geom_type in ("Polygon", "MultiPolygon"):
        x0, y0, x1, y1 = geom.bounds
        gx, gy = np.meshgrid(np.arange(x0 + step / 2, x1, step), np.arange(y0 + step / 2, y1, step))
        gx, gy = gx.ravel(), gy.ravel()
        inside = shapely.contains_xy(geom, gx, gy)
        pts = np.c_[gx[inside], gy[inside]]
        if pts.size == 0:
            c = geom.representative_point()
            pts = np.array([[c.x, c.y]])
        return pts
    if geom.geom_type == "Point":
        return np.array([[geom.x, geom.y]])
    if hasattr(geom, "geoms"):
        arrs = [_sample(g, step) for g in geom.geoms]
        arrs = [a for a in arrs if a.size]
        return np.vstack(arrs) if arrs else np.zeros((0, 2))
    return np.zeros((0, 2))


def map_defects(ds: DefectSet, wmap, rm: RegionModel, fat: FatalityModel, rng: np.random.Generator,
                sample_spacing_um: float = 50.0, rng_fatal: np.random.Generator | None = None,
                tree: STRtree | None = None) -> Hits:
    """Map every defect to dies and regions, then draw fatality.

    ``rng`` drives region attribution; ``rng_fatal`` (default: ``rng``) drives the
    kill draws, so a change of fatality model does not perturb the geometry
    stream (common random numbers)."""
    h = _concat([map_points(ds, wmap, rm, rng), map_extended(ds, wmap, rm, rng, sample_spacing_um, tree)])
    if h.n:
        names = [r.name for r in rm.regions]
        kinds = [r.kind for r in rm.regions]
        p = fat.kill_probability(names, kinds, ds.classes, h.rid, h.cls, h.size_um, h.severity)
        h.fatal = (rng_fatal or rng).random(h.n) < p
    return h


def per_die_counts(h: Hits, n_sites: int) -> tuple[np.ndarray, np.ndarray]:
    """(distinct defect events per site, distinct fatal events per site)."""
    if h.n == 0:
        return np.zeros(n_sites, int), np.zeros(n_sites, int)
    key = np.unique(np.c_[h.site, h.event], axis=0)
    events = np.bincount(key[:, 0], minlength=n_sites)
    fk = np.unique(np.c_[h.site[h.fatal], h.event[h.fatal]], axis=0) if h.fatal.any() else np.zeros((0, 2), int)
    fatal = np.bincount(fk[:, 0], minlength=n_sites) if fk.size else np.zeros(n_sites, int)
    return events, fatal
