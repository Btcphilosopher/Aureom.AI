"""Physical-design import adapters (FloorplanLab / OpenDB exports, DEF, MCU-I synthesis).

Sources, in order of preference:

1. FloorplanLab ``geometry.json`` -- written by FloorplanLab's OpenROAD script
   ``scripts/analysis/export_geometry.tcl`` straight from the placed OpenDB
   (``3_place.odb``): die / core boxes, every hard macro with master, bbox and
   orientation, logical-group cell areas and extents, the 64 x 64 std-cell
   density grid.  Vendored under ``third_party/floorplanlab/runs/<run>/``.
2. FloorplanLab ``ppa_table.csv`` -- per-run die / core / macro / std-cell areas,
   timing and routability (all runs, including failed ones).
3. DEF (``DIEAREA`` + ``COMPONENTS``) -- minimal reader; macro sizes need the LEF.
4. OpenDB directly -- requires the OpenROAD Python module (``odb``).  It is not
   installed in this environment; :func:`opendb_status` reports NOT AVAILABLE
   instead of guessing.
5. MCU-I Yosys summaries -- areas only.  MCU-I has **no** floorplan; its die size
   exists only as a planning estimate in MCU-I ``docs/ASIC.md``.

No die dimension is ever inferred from standard-cell area alone.
"""
from __future__ import annotations

import csv
import hashlib
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .provenance import Source, Sourced

PKG_ROOT = Path(__file__).resolve().parents[4]          # silicaflux-yieldlab/
THIRD_PARTY = PKG_ROOT / "third_party"
FLP_RUNS = THIRD_PARTY / "floorplanlab" / "runs"
FLP_PPA = THIRD_PARTY / "floorplanlab" / "experiments" / "ppa_table.csv"


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _provenance_of(path: Path) -> str:
    prov = THIRD_PARTY / "PROVENANCE.json"
    try:
        rel = path.resolve().relative_to(THIRD_PARTY.resolve()).as_posix()
    except ValueError:
        return str(path)
    if prov.exists():
        for rec in json.loads(prov.read_text())["files"]:
            if rec["vendored_path"] == rel:
                inner = f"::{rec['inner_archive']}" if rec["inner_archive"] else ""
                return f"{rec['outer_archive']}{inner}::{rec['member']} (sha256 {rec['sha256'][:12]})"
    return f"third_party/{rel}"


@dataclass
class Macro:
    name: str
    master: str
    bbox_um: tuple[float, float, float, float]
    orient: str
    group: str

    @property
    def w_um(self) -> float:
        return self.bbox_um[2] - self.bbox_um[0]

    @property
    def h_um(self) -> float:
        return self.bbox_um[3] - self.bbox_um[1]

    @property
    def area_um2(self) -> float:
        return self.w_um * self.h_um


@dataclass
class LogicGroup:
    name: str
    cells: int
    area_um2: float
    bbox_um: tuple[float, float, float, float]
    centroid_um: tuple[float, float]


@dataclass
class FloorplanGeometry:
    run_id: str
    die_um: tuple[float, float, float, float]
    core_um: tuple[float, float, float, float]
    macros: list[Macro]
    groups: dict[str, LogicGroup]
    density_bins: int
    density_bin_um: tuple[float, float]
    density_origin_um: tuple[float, float]
    density: list[list[float]]
    n_io_pins: int
    source_file: str
    reference: str
    extra: dict = field(default_factory=dict)

    @property
    def die_w_um(self) -> float:
        return self.die_um[2] - self.die_um[0]

    @property
    def die_h_um(self) -> float:
        return self.die_um[3] - self.die_um[1]

    @property
    def die_area_mm2(self) -> float:
        return self.die_w_um * self.die_h_um / 1e6

    @property
    def core_area_mm2(self) -> float:
        c = self.core_um
        return (c[2] - c[0]) * (c[3] - c[1]) / 1e6

    @property
    def macro_area_mm2(self) -> float:
        return sum(m.area_um2 for m in self.macros) / 1e6

    @property
    def logic_cell_area_mm2(self) -> float:
        return sum(g.area_um2 for g in self.groups.values()) / 1e6

    def sourced_die(self) -> Sourced:
        return Sourced(value=(self.die_w_um, self.die_h_um), source=Source.MEASURED_TOOL_OUTPUT,
                       reference=self.reference,
                       note="FloorplanLab OpenDB export after global placement (pre-CTS); no pad ring")


def available_runs() -> list[str]:
    return sorted(p.name for p in FLP_RUNS.iterdir() if (p / "geometry.json").exists()) if FLP_RUNS.exists() else []


def load_geometry(run: str | Path) -> FloorplanGeometry:
    path = Path(run)
    if not path.suffix:
        path = FLP_RUNS / str(run) / "geometry.json"
    if not path.exists():
        raise FileNotFoundError(
            f"FloorplanLab geometry not found: {path}. Available runs: {available_runs()} "
            "(re-vendor with scripts/intake.py --repo <Aureom.AI checkout>)"
        )
    g = json.loads(path.read_text())
    run_id = path.parent.name
    macros = [Macro(m["name"], m["master"], tuple(m["bbox"]), m.get("orient", "R0"), m.get("group", "")) for m in g["macros"]]
    groups = {
        k: LogicGroup(k, int(v["cells"]), float(v["area_um2"]), tuple(v["bbox_um"]), tuple(v["centroid_um"]))
        for k, v in g.get("groups", {}).items()
    }
    dg = g.get("density_grid") or {}
    return FloorplanGeometry(
        run_id=run_id,
        die_um=tuple(g["die_um"]),
        core_um=tuple(g["core_um"]),
        macros=macros,
        groups=groups,
        density_bins=int(dg.get("bins", 0)),
        density_bin_um=(float(dg.get("bin_w_um", 0)), float(dg.get("bin_h_um", 0))),
        density_origin_um=tuple(dg.get("origin_um", (0.0, 0.0))),
        density=dg.get("utilisation", []),
        n_io_pins=len(g.get("io_pins", [])),
        source_file=str(path),
        reference=_provenance_of(path),
    )


def load_ppa_table(path: Path = FLP_PPA) -> list[dict]:
    with open(path, newline="") as fh:
        rows = list(csv.DictReader(fh))
    for r in rows:
        r["_reference"] = _provenance_of(path)
    return rows


def _f(x: str) -> Optional[float]:
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def floorplan_candidates() -> list[dict]:
    """Every FloorplanLab run as a die-size candidate, with its gate status kept visible."""
    out = []
    for r in load_ppa_table():
        out.append(
            {
                "run_id": r["run_id"],
                "status": r["status"],
                "physically_valid": r["physically_valid"] == "True",
                "failure_reason": r.get("failure_reason", ""),
                "die_w_um": _f(r["die_w_um"]),
                "die_h_um": _f(r["die_h_um"]),
                "die_area_mm2": _f(r["die_area_mm2"]),
                "core_area_mm2": _f(r["core_area_mm2"]),
                "macro_area_um2": _f(r["macro_area_um2"]),
                "std_cell_area_placed_um2": _f(r["std_cell_area_placed_um2"]),
                "grt_overflow": _f(r["grt_overflow"]),
                "grt_wns_ns": _f(r["grt_wns_ns"]),
                "wns_ns_preroute": _f(r["wns_ns"]),
                "netlist_sha256": r["netlist_sha256"],
                "arrangement": r["arrangement"],
                "target_util": _f(r["target_util"]),
                "description": r["description"],
                "has_geometry": (FLP_RUNS / r["run_id"] / "geometry.json").exists(),
                "reference": r["_reference"],
            }
        )
    return out


# --------------------------------------------------------------------------- DEF


def parse_def(path: str | Path) -> dict:
    """Minimal DEF reader: UNITS, DIEAREA, COMPONENTS (placement only)."""
    text = Path(path).read_text()
    m = re.search(r"UNITS\s+DISTANCE\s+MICRONS\s+(\d+)", text)
    dbu = int(m.group(1)) if m else 1000
    m = re.search(r"DIEAREA\s+((?:\(\s*-?\d+\s+-?\d+\s*\)\s*)+);", text)
    if not m:
        raise ValueError(f"{path}: no DIEAREA statement")
    pts = [(int(a) / dbu, int(b) / dbu) for a, b in re.findall(r"\(\s*(-?\d+)\s+(-?\d+)\s*\)", m.group(1))]
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    comps = []
    cm = re.search(r"COMPONENTS\s+\d+\s*;(.*?)END\s+COMPONENTS", text, re.S)
    if cm:
        for stmt in cm.group(1).split(";"):
            s = stmt.strip()
            if not s.startswith("-"):
                continue
            mm = re.match(r"-\s+(\S+)\s+(\S+)(.*)", s, re.S)
            if not mm:
                continue
            name, master, rest = mm.groups()
            pm = re.search(r"\+\s*(PLACED|FIXED|COVER)\s*\(\s*(-?\d+)\s+(-?\d+)\s*\)\s*(\S+)", rest)
            comps.append(
                {
                    "name": name,
                    "master": master,
                    "status": pm.group(1) if pm else "UNPLACED",
                    "origin_um": (int(pm.group(2)) / dbu, int(pm.group(3)) / dbu) if pm else None,
                    "orient": pm.group(4) if pm else None,
                }
            )
    return {
        "dbu": dbu,
        "die_polygon_um": pts,
        "die_bbox_um": (min(xs), min(ys), max(xs), max(ys)),
        "components": comps,
        "note": "macro footprints require the corresponding LEF; only origins are read from DEF",
        "reference": _provenance_of(Path(path)),
    }


def opendb_status() -> Sourced:
    try:  # pragma: no cover - depends on an OpenROAD installation
        import odb  # noqa: F401

        return Sourced(value=True, source=Source.DESIGN_INPUT, reference="OpenROAD odb module importable")
    except Exception:
        return Sourced.na("OpenDB (OpenROAD 'odb' Python module)",
                          "not installed here; FloorplanLab geometry.json (an OpenDB export) is used instead")


# --------------------------------------------------------------------------- MCU-I

MCU_I_ASIC = THIRD_PARTY / "mcu_i" / "asic"

#: MCU-I docs/ASIC.md "Planning estimate of die size (NOT a physical result)", IHP SG13G2 only
MCU_I_DIE_PLANNING_ESTIMATE_MM2 = {"basic": 5.9, "industrial": 12.7}


def load_mcu_i_summary(pdk: str = "ihp_sg13g2", variant: str = "industrial") -> dict:
    p = MCU_I_ASIC / pdk / variant / "summary.json"
    if not p.exists():
        raise FileNotFoundError(f"MCU-I synthesis summary not found: {p}")
    d = json.loads(p.read_text())
    d["_reference"] = _provenance_of(p)
    return d


def mcu_i_die(variant: str = "industrial") -> Sourced:
    """MCU-I die area: only a planning estimate exists (square die assumed by the estimate)."""
    if variant not in MCU_I_DIE_PLANNING_ESTIMATE_MM2:
        return Sourced.na(f"MCU-I {variant} die size", "no floorplan and no planning estimate")
    a = MCU_I_DIE_PLANNING_ESTIMATE_MM2[variant]
    side = a ** 0.5 * 1000.0
    return Sourced(value=(side, side), source=Source.PLANNING_ESTIMATE,
                   reference="silicaflux-mcu-i docs/ASIC.md 'Planning estimate of die size (NOT a physical result)', IHP SG13G2",
                   note=f"{a} mm^2 incl. 0.35 mm I/O ring per side, square aspect assumed; no placement/routing exists")
