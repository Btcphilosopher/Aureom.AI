"""SilicaFlux functional-region model: where on the die a defect lands, and what it hits.

The die used for yield is the FloorplanLab die (OpenDB export, no pad ring)
surrounded by a pad ring of configurable width (an explicit planning estimate --
FloorplanLab places logical pins only).  Die-local coordinates are micrometres
with the origin at the lower-left corner of the *yield die*.

Point location, in priority order:

1. pad ring (4 rectangles)                               -> region ``io_pads``
2. hard macros (exact OpenDB bounding boxes)             -> SRAM regions, per macro
3. core area: std-cell logic groups, using the FloorplanLab 64 x 64 placement
   density grid.  In each bin, P(cells) = std-cell area / non-macro bin area;
   the cell area is split between the logical groups whose placement extent
   (bbox) contains the bin, weighted by group cell area / extent area.
   This is an *attribution approximation*: FloorplanLab exports group extents,
   not per-cell positions, and extents overlap.  The spatially attributed area
   of every group is reported next to its exact OpenDB cell area.
4. everything else (core whitespace, die margin)         -> ``routing_whitespace``

Fatality is *not* decided here; see :mod:`yieldlab.fatality`.
"""
from __future__ import annotations

import fnmatch
import re
from dataclasses import dataclass, field
from typing import Literal, Optional

import numpy as np
import shapely
from pydantic import BaseModel, ConfigDict, Field
from shapely.geometry import box
from shapely.ops import unary_union

from .floorplan_adapter import FloorplanGeometry, load_geometry
from .provenance import Source, Sourced

Criticality = Literal["fatal", "fatal_unless_repaired", "disable_candidate", "non_functional"]


class RegionSpec(BaseModel):
    """Attributes of one functional region (YAML ``regions:`` entry)."""

    model_config = ConfigDict(extra="forbid")
    function: str
    groups: list[str] = Field(default_factory=list, description="FloorplanLab logical groups")
    macros: list[str] = Field(default_factory=list, description="fnmatch patterns on macro master names")
    kind: Literal["logic", "sram", "io", "whitespace"] = "logic"
    criticality: Criticality = "fatal"
    redundancy: str = "none (audit: no redundancy in SilicaFlux-V)"
    disable_support: str = "none (audit: no accelerator / bank disable hardware)"
    failure_model: str = "any fatal defect causes functional failure of the die"
    detected_by: list[str] = Field(default_factory=list)
    coverage_source: str = "NOT AVAILABLE"


class PadRingSpec(BaseModel):
    model_config = ConfigDict(extra="forbid")
    width_um: float = Field(ge=0)
    source: Source = Source.PLANNING_ESTIMATE
    reference: str = ""


class DesignSpec(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str
    revision: str
    floorplan_run: Optional[str] = None
    die_override_um: Optional[tuple[float, float]] = None
    die_override_source: Source = Source.PLANNING_ESTIMATE
    die_override_reference: str = ""
    pad_ring: PadRingSpec
    regions: dict[str, RegionSpec]
    status_note: str = ""


@dataclass
class Region:
    rid: int
    name: str
    spec: RegionSpec
    rects_um: list[tuple[float, float, float, float]] = field(default_factory=list)
    cell_area_um2: float = 0.0          # OpenDB cell area (logic) or macro area (SRAM)
    located_area_um2: float = 0.0       # area the point-locator attributes to the region
    macro_info: list[dict] = field(default_factory=list)

    @property
    def kind(self) -> str:
        return self.spec.kind


_MACRO_RE = re.compile(r"RM_IHPSG13_1P_(\d+)x(\d+)_c(\d+)")


def macro_organisation(master: str) -> Sourced:
    m = _MACRO_RE.search(master)
    if not m:
        return Sourced.na(f"array organisation of {master}", "macro name not recognised; supply a datasheet")
    words, bits, mux = (int(x) for x in m.groups())
    return Sourced(
        value={"words": words, "bits": bits, "column_mux": mux, "rows": words // mux, "cols": bits * mux},
        source=Source.DESIGN_INPUT,
        reference=f"derived from IHP macro name {master} (words x bits, column mux c{mux})",
        note="physical row/column organisation inferred from the naming convention; confirm with the macro datasheet",
    )


def _bank_of(name: str) -> str:
    m = re.search(r"g_sram\\?\[(\d+)\\?\]", name)
    if m:
        return f"main_bank{m.group(1)}"
    m = re.search(r"g_bank\\?\[(\d+)\\?\]", name)
    if m:
        return f"tspm_bank{m.group(1)}"
    return "unknown_bank"


class RegionModel:
    def __init__(self, design: DesignSpec, geo: Optional[FloorplanGeometry] = None):
        self.design = design
        if design.floorplan_run is None:
            raise ValueError(f"design {design.name}: no FloorplanLab run -> no region geometry available")
        self.geo = geo or load_geometry(design.floorplan_run)
        p = design.pad_ring.width_um
        self.pad_um = p
        g = self.geo
        self.W = g.die_w_um + 2 * p
        self.H = g.die_h_um + 2 * p
        self.off = (p - g.die_um[0], p - g.die_um[1])
        self.regions: list[Region] = []
        self._name_to_id: dict[str, int] = {}
        for name, spec in design.regions.items():
            self._add(name, spec)
        for req in ("io_pads", "routing_whitespace"):
            if req not in self._name_to_id:
                raise ValueError(f"design {design.name}: region {req!r} must be defined")
        self._build()

    # ------------------------------------------------------------------ construction
    def _add(self, name: str, spec: RegionSpec) -> Region:
        r = Region(len(self.regions), name, spec)
        self.regions.append(r)
        self._name_to_id[name] = r.rid
        return r

    def rid(self, name: str) -> int:
        return self._name_to_id[name]

    def _shift(self, b):
        return (b[0] + self.off[0], b[1] + self.off[1], b[2] + self.off[0], b[3] + self.off[1])

    def _build(self) -> None:
        g, p = self.geo, self.pad_um
        W, H = self.W, self.H
        # 1. pad ring
        pad = self.regions[self.rid("io_pads")]
        if p > 0:
            pad.rects_um = [(0, 0, W, p), (0, H - p, W, H), (0, p, p, H - p), (W - p, p, W, H - p)]
        pad.cell_area_um2 = pad.located_area_um2 = W * H - (W - 2 * p) * (H - 2 * p)
        # 2. macros
        self._macro_rects = []
        self._macro_region = []
        self._macro_index = []
        sram_regions = [r for r in self.regions if r.kind == "sram"]
        for mi, m in enumerate(g.macros):
            owner = None
            for r in sram_regions:
                if any(fnmatch.fnmatch(m.master, pat) for pat in r.spec.macros):
                    owner = r
                    break
            if owner is None:
                raise ValueError(f"macro {m.master} ({m.name}) is not assigned to any SRAM region")
            rect = self._shift(m.bbox_um)
            owner.rects_um.append(rect)
            owner.cell_area_um2 += m.area_um2
            owner.located_area_um2 += m.area_um2
            owner.macro_info.append({"index": mi, "name": m.name, "master": m.master, "bank": _bank_of(m.name),
                                     "bbox_um": rect, "organisation": macro_organisation(m.master)})
            self._macro_rects.append(rect)
            self._macro_region.append(owner.rid)
            self._macro_index.append(mi)
        self._macro_rects = np.array(self._macro_rects, dtype=float).reshape(-1, 4)
        self._macro_region = np.array(self._macro_region, dtype=int)
        self._macro_index = np.array(self._macro_index, dtype=int)
        # 3. logic groups -> regions
        group_region = {}
        for r in self.regions:
            for grp in r.spec.groups:
                if grp in group_region:
                    raise ValueError(f"logical group {grp!r} assigned to two regions")
                group_region[grp] = r.rid
        missing = sorted(set(g.groups) - set(group_region))
        if missing:
            raise ValueError(f"FloorplanLab groups without a region: {missing}")
        for grp, lg in g.groups.items():
            self.regions[group_region[grp]].cell_area_um2 += lg.area_um2
        self._group_names = sorted(g.groups)
        self._group_region = np.array([group_region[k] for k in self._group_names], dtype=int)
        self._build_density(group_region)

    def _build_density(self, group_region: dict) -> None:
        g = self.geo
        nb = g.density_bins
        if nb == 0:
            raise ValueError("FloorplanLab geometry has no density grid")
        bw, bh = g.density_bin_um
        ox, oy = g.density_origin_um
        ox, oy = ox + self.off[0], oy + self.off[1]
        self._grid = (nb, bw, bh, ox, oy)
        util = np.clip(np.array(g.density, dtype=float), 0.0, None)          # [row = y][col = x]
        macros_union = unary_union([box(*r) for r in self._macro_rects]) if len(self._macro_rects) else None
        cols, rows = np.meshgrid(np.arange(nb), np.arange(nb))
        bx0 = ox + cols * bw
        by0 = oy + rows * bh
        bins = shapely.box(bx0.ravel(), by0.ravel(), (bx0 + bw).ravel(), (by0 + bh).ravel())
        if macros_union is not None:
            macro_frac = (shapely.area(shapely.intersection(bins, macros_union)) / (bw * bh)).reshape(nb, nb)
        else:
            macro_frac = np.zeros((nb, nb))
        free = np.clip(1.0 - macro_frac, 0.0, 1.0)
        with np.errstate(divide="ignore", invalid="ignore"):
            u_eff = np.where(free > 1e-9, np.minimum(util / np.maximum(free, 1e-12), 1.0), 0.0)
        # group weights: area / non-macro extent area
        core = box(*self._shift(g.core_um))
        free_core = core.difference(macros_union) if macros_union is not None else core
        cx = bx0 + bw / 2
        cy = by0 + bh / 2
        G = len(self._group_names)
        weights = np.zeros((G, nb, nb))
        for k, name in enumerate(self._group_names):
            lg = g.groups[name]
            ext = box(*self._shift(lg.bbox_um)).intersection(free_core)
            if ext.area <= 0:
                continue
            x0, y0, x1, y1 = self._shift(lg.bbox_um)
            inside = (cx >= x0) & (cx <= x1) & (cy >= y0) & (cy <= y1)
            weights[k][inside] = lg.area_um2 / ext.area
        wsum = weights.sum(axis=0)
        # bins with cells but no group extent -> attribute to the 'top' group if present
        fallback = self._group_names.index("top") if "top" in self._group_names else 0
        orphan = (wsum <= 0) & (u_eff > 0)
        weights[fallback][orphan] = 1.0
        wsum = weights.sum(axis=0)
        probs = np.zeros((G + 1, nb, nb))
        with np.errstate(divide="ignore", invalid="ignore"):
            probs[:G] = np.where(wsum > 0, u_eff * weights / np.maximum(wsum, 1e-300), 0.0)
        probs[G] = 1.0 - probs[:G].sum(axis=0)
        self._cum = np.cumsum(probs, axis=0)                       # (G+1, nb, nb)
        self._cum[-1] = 1.0
        # located areas
        bin_free_area = free * bw * bh
        for k in range(G):
            rid = self._group_region[k]
            self.regions[rid].located_area_um2 += float((probs[k] * bin_free_area).sum())
        ws = self.regions[self.rid("routing_whitespace")]
        die_inner = (self.W - 2 * self.pad_um) * (self.H - 2 * self.pad_um)
        logic_located = sum(r.located_area_um2 for r in self.regions if r.kind == "logic")
        ws.located_area_um2 = die_inner - self._macro_rects_area() - logic_located
        ws.cell_area_um2 = ws.located_area_um2
        self.u_eff = u_eff

    def _macro_rects_area(self) -> float:
        r = self._macro_rects
        return float(((r[:, 2] - r[:, 0]) * (r[:, 3] - r[:, 1])).sum()) if len(r) else 0.0

    # ------------------------------------------------------------------ queries
    @property
    def die_w_um(self) -> float:
        return self.W

    @property
    def die_h_um(self) -> float:
        return self.H

    @property
    def die_area_cm2(self) -> float:
        return self.W * self.H / 1e8

    def locate(self, x_um: np.ndarray, y_um: np.ndarray, rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray]:
        """Region id and macro index (-1 if none) for die-local points (vectorised, stochastic for logic)."""
        x = np.asarray(x_um, dtype=float)
        y = np.asarray(y_um, dtype=float)
        n = x.size
        out = np.full(n, self.rid("routing_whitespace"), dtype=int)
        macro = np.full(n, -1, dtype=int)
        todo = np.ones(n, dtype=bool)
        p = self.pad_um
        if p > 0:
            ring = (x < p) | (x > self.W - p) | (y < p) | (y > self.H - p)
            out[ring] = self.rid("io_pads")
            todo &= ~ring
        if len(self._macro_rects):
            for k, (x0, y0, x1, y1) in enumerate(self._macro_rects):
                hit = todo & (x >= x0) & (x <= x1) & (y >= y0) & (y <= y1)
                out[hit] = self._macro_region[k]
                macro[hit] = self._macro_index[k]
                todo &= ~hit
        nb, bw, bh, ox, oy = self._grid
        ci = np.floor((x - ox) / bw).astype(int)
        ri = np.floor((y - oy) / bh).astype(int)
        ingrid = todo & (ci >= 0) & (ci < nb) & (ri >= 0) & (ri < nb)
        idx = np.nonzero(ingrid)[0]
        if idx.size:
            u = rng.random(idx.size)
            cum = self._cum[:, ri[idx], ci[idx]]          # (G+1, m)
            k = (u[None, :] > cum).sum(axis=0)
            G = len(self._group_names)
            is_cell = k < G
            out[idx[is_cell]] = self._group_region[k[is_cell]]
        return out, macro

    def table(self) -> list[dict]:
        rows = []
        die_um2 = self.W * self.H
        for r in self.regions:
            rows.append(
                {
                    "region": r.name,
                    "function": r.spec.function,
                    "kind": r.kind,
                    "opendb_area_mm2": r.cell_area_um2 / 1e6,
                    "located_area_mm2": r.located_area_um2 / 1e6,
                    "fraction_of_die": r.located_area_um2 / die_um2,
                    "criticality": r.spec.criticality,
                    "redundancy": r.spec.redundancy,
                    "disable_support": r.spec.disable_support,
                    "failure_model": r.spec.failure_model,
                    "detected_by": ", ".join(r.spec.detected_by) or "none",
                    "coverage_source": r.spec.coverage_source,
                    "area_source": ("MEASURED_TOOL_OUTPUT (FloorplanLab OpenDB)" if r.kind in ("logic", "sram")
                                    else f"{self.design.pad_ring.source.value} (pad ring)" if r.kind == "io"
                                    else "DERIVED (die - macros - located cells)"),
                }
            )
        return rows

    def macro_list(self) -> list[dict]:
        out = []
        for r in self.regions:
            for m in r.macro_info:
                out.append({**m, "region": r.name, "rid": r.rid})
        out.sort(key=lambda d: d["index"])
        return out


class SimpleRegionModel:
    """Area-fraction region model for a design without floorplan geometry.

    Used for MCU-I, whose die exists only as a planning estimate: a defect that
    lands in the die is attributed to a region with probability equal to the
    region's area fraction (no spatial structure inside the die).  SRAM hits get
    no macro / array coordinates, so physical repair analysis is refused.
    """

    def __init__(self, design: DesignSpec, fractions: list, die_w_um: float, die_h_um: float):
        self.design = design
        self.W, self.H = float(die_w_um), float(die_h_um)
        self.pad_um = 0.0
        tot = sum(f.area_fraction for f in fractions)
        if abs(tot - 1.0) > 1e-6:
            raise ValueError(f"simple region area fractions must sum to 1 (got {tot})")
        self.regions: list[Region] = []
        self._name_to_id = {}
        for f in fractions:
            spec = design.regions.get(f.name) or RegionSpec(function=f.name, kind=f.kind)
            r = Region(len(self.regions), f.name, spec)
            r.cell_area_um2 = r.located_area_um2 = f.area_fraction * self.W * self.H
            self.regions.append(r)
            self._name_to_id[f.name] = r.rid
        self._p = np.array([f.area_fraction for f in fractions])
        self._macro_rects = np.zeros((0, 4))
        self.geo = None
        self.simplified = True

    def rid(self, name: str) -> int:
        return self._name_to_id[name]

    @property
    def die_w_um(self) -> float:
        return self.W

    @property
    def die_h_um(self) -> float:
        return self.H

    @property
    def die_area_cm2(self) -> float:
        return self.W * self.H / 1e8

    def locate(self, x_um, y_um, rng):
        n = np.asarray(x_um).size
        return rng.choice(len(self.regions), size=n, p=self._p), np.full(n, -1, dtype=int)

    def table(self) -> list[dict]:
        rows = []
        for r in self.regions:
            rows.append({"region": r.name, "function": r.spec.function, "kind": r.kind,
                         "opendb_area_mm2": float("nan"), "located_area_mm2": r.located_area_um2 / 1e6,
                         "fraction_of_die": r.located_area_um2 / (self.W * self.H),
                         "criticality": r.spec.criticality, "redundancy": r.spec.redundancy,
                         "disable_support": r.spec.disable_support, "failure_model": r.spec.failure_model,
                         "detected_by": ", ".join(r.spec.detected_by) or "none",
                         "coverage_source": r.spec.coverage_source,
                         "area_source": "PLANNING_ESTIMATE (area fraction; no floorplan)"})
        return rows

    def macro_list(self) -> list[dict]:
        return []
