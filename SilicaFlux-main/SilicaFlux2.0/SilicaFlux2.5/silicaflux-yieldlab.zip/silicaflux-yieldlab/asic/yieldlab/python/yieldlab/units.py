"""Strict unit handling.

Internal conventions (used everywhere in the engine):

* lengths on the wafer: **millimetres** (``*_mm``)
* lengths inside a die / from physical-design tools: **micrometres** (``*_um``)
* die / critical areas for yield models: **square centimetres** (``*_cm2``)
* defect densities: **per square centimetre** (``*_per_cm2``)

Every public function and config field carries its unit in its name.  The
conversion helpers below are the only place where scale factors appear, so a
unit slip (e.g. passing mm^2 where cm^2 is expected, a factor of 100) is caught
by the dedicated unit tests rather than hidden in arithmetic.
"""
from __future__ import annotations

import math
from typing import Iterable

import numpy as np

UM_PER_MM = 1000.0
MM_PER_CM = 10.0
MM2_PER_CM2 = 100.0
UM2_PER_MM2 = 1.0e6
UM2_PER_CM2 = 1.0e8


class UnitError(ValueError):
    """Invalid physical quantity (negative, non-finite, wrong range)."""


def um_to_mm(x_um: float) -> float:
    return x_um / UM_PER_MM


def mm_to_um(x_mm: float) -> float:
    return x_mm * UM_PER_MM


def mm2_to_cm2(a_mm2: float) -> float:
    return a_mm2 / MM2_PER_CM2


def cm2_to_mm2(a_cm2: float) -> float:
    return a_cm2 * MM2_PER_CM2


def um2_to_mm2(a_um2: float) -> float:
    return a_um2 / UM2_PER_MM2


def um2_to_cm2(a_um2: float) -> float:
    return a_um2 / UM2_PER_CM2


def rect_area_cm2_from_um(w_um: float, h_um: float) -> float:
    return um2_to_cm2(require_nonneg(w_um, "width_um") * require_nonneg(h_um, "height_um"))


def require_finite(x: float, name: str) -> float:
    if x is None or not math.isfinite(float(x)):
        raise UnitError(f"{name} must be a finite number, got {x!r}")
    return float(x)


def require_nonneg(x: float, name: str) -> float:
    x = require_finite(x, name)
    if x < 0:
        raise UnitError(f"{name} must be >= 0, got {x}")
    return x


def require_pos(x: float, name: str) -> float:
    x = require_finite(x, name)
    if x <= 0:
        raise UnitError(f"{name} must be > 0, got {x}")
    return x


def require_prob(p: float, name: str) -> float:
    p = require_finite(p, name)
    if not 0.0 <= p <= 1.0:
        raise UnitError(f"{name} must be a probability in [0, 1], got {p}")
    return p


def require_nonneg_array(a: Iterable[float] | np.ndarray, name: str) -> np.ndarray:
    arr = np.asarray(a, dtype=float)
    if not np.all(np.isfinite(arr)):
        raise UnitError(f"{name} contains non-finite values")
    if np.any(arr < 0):
        raise UnitError(f"{name} contains negative values")
    return arr
