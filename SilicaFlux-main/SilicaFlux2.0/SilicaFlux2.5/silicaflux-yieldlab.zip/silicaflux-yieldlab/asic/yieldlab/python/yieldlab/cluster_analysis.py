"""Spatial defect-pattern analysis (statistical classification, NOT root-cause attribution).

* DBSCAN (scikit-learn) on defect coordinates -> clusters with size, centroid,
  extent and a shape descriptor (PCA elongation: scratch-like if >> 1).
* Radial density profile in equal-area annuli and an edge-enrichment ratio.
* Ring indicator: an interior annulus whose density exceeds both neighbours by
  ``ring_factor`` (and the overall mean).
* Reticle-repeat indicator: defects folded into within-field coordinates; a
  within-field cell holding defects from >= ``min_fields`` different fields is
  flagged.
* Wafer-level yield gradient: logistic regression of die failure on (r/R)^2.

A pattern found here is a *statistical classification* of the map.  A ring on a
wafer map does not prove a deposition, etch or lithography cause -- root-cause
attribution needs process evidence (tool history, inline metrology).
Simulated and measured maps are analysed with the same code but keep their
labels.
"""
from __future__ import annotations

import math
from typing import Optional

import numpy as np

CAVEAT = ("Statistical pattern classification only; it does not identify a fabrication root cause "
          "(that requires process evidence).")


def dbscan_clusters(x: np.ndarray, y: np.ndarray, eps_mm: float = 3.0, min_samples: int = 5) -> dict:
    from sklearn.cluster import DBSCAN

    pts = np.c_[x, y]
    if len(pts) == 0:
        return {"labels": np.zeros(0, int), "clusters": [], "noise": 0}
    lab = DBSCAN(eps=eps_mm, min_samples=min_samples).fit_predict(pts)
    clusters = []
    for k in sorted(set(lab) - {-1}):
        p = pts[lab == k]
        c = p.mean(axis=0)
        if len(p) >= 3:
            ev = np.sort(np.linalg.eigvalsh(np.cov(p.T)))[::-1]
            elong = math.sqrt(ev[0] / max(ev[1], 1e-12))
        else:
            elong = 1.0
        clusters.append({"id": int(k), "size": int(len(p)), "centroid_mm": c.round(3).tolist(),
                         "radius_mm": float(np.hypot(*c)),
                         "extent_mm": float(np.max(np.hypot(*(p - c).T))),
                         "elongation": float(elong),
                         "shape": "linear (scratch-like)" if elong > 4 else "compact (hotspot-like)"})
    return {"labels": lab, "clusters": clusters, "noise": int((lab == -1).sum()),
            "parameters": {"eps_mm": eps_mm, "min_samples": min_samples}}


def radial_profile(x: np.ndarray, y: np.ndarray, radius_mm: float, n_rings: int = 16) -> dict:
    r = np.hypot(x, y)
    edges = radius_mm * np.sqrt(np.linspace(0, 1, n_rings + 1))          # equal-area annuli
    counts = np.histogram(r, edges)[0]
    area_cm2 = math.pi * (edges[1:] ** 2 - edges[:-1] ** 2) / 100.0
    dens = counts / area_cm2
    mean = len(x) / (math.pi * radius_mm**2 / 100.0) if len(x) else 0.0
    return {"edges_mm": edges.tolist(), "counts": counts.tolist(), "density_per_cm2": dens.tolist(),
            "mean_density_per_cm2": mean,
            "edge_enrichment": float(dens[-1] / mean) if mean else float("nan")}


def ring_indicator(profile: dict, ring_factor: float = 1.8) -> Optional[dict]:
    """Interior local maximum of the radial density that exceeds the overall mean and the annuli two
    bins away by ``ring_factor`` (a ring usually straddles two adjacent annuli).  The two outermost
    annuli are excluded so edge enhancement is not mistaken for a ring."""
    d = np.asarray(profile["density_per_cm2"])
    best = None
    for i in range(2, len(d) - 2):
        if d[i] < d[i - 1] or d[i] < d[i + 1]:
            continue
        if d[i] > ring_factor * max(d[i - 2], d[i + 2], 1e-12) and d[i] > ring_factor * profile["mean_density_per_cm2"]:
            if best is None or d[i] > d[best]:
                best = i
    if best is None:
        return None
    e = profile["edges_mm"]
    lo = best - 1 if d[best - 1] >= d[best + 1] else best
    return {"ring_inner_mm": e[lo], "ring_outer_mm": e[lo + 2], "density": float(d[best])}


def reticle_repeat(x: np.ndarray, y: np.ndarray, field_w_mm: float, field_h_mm: float, origin=(0.0, 0.0),
                   cell_mm: float = 0.5, min_fields: int = 4) -> list[dict]:
    if len(x) == 0:
        return []
    fx = np.floor((x - origin[0]) / field_w_mm).astype(int)
    fy = np.floor((y - origin[1]) / field_h_mm).astype(int)
    u = (x - origin[0]) - fx * field_w_mm
    v = (y - origin[1]) - fy * field_h_mm
    cu = np.floor(u / cell_mm).astype(int)
    cv = np.floor(v / cell_mm).astype(int)
    hits = {}
    for a, b, f1, f2 in zip(cu, cv, fx, fy):
        hits.setdefault((a, b), set()).add((f1, f2))
    out = [{"within_field_mm": [(a + 0.5) * cell_mm, (b + 0.5) * cell_mm], "fields": len(s)}
           for (a, b), s in hits.items() if len(s) >= min_fields]
    return sorted(out, key=lambda d: -d["fields"])


def yield_gradient(cx: np.ndarray, cy: np.ndarray, fail: np.ndarray, radius_mm: float) -> dict:
    from sklearn.linear_model import LogisticRegression

    r2 = (np.hypot(cx, cy) / radius_mm) ** 2
    if fail.all() or (~fail).all():
        return {"coef_r2": 0.0, "note": "no variation in pass/fail"}
    m = LogisticRegression(C=1e6, max_iter=1000).fit(r2.reshape(-1, 1), fail.astype(int))
    p_c = 1 / (1 + math.exp(-m.intercept_[0]))
    p_e = 1 / (1 + math.exp(-(m.intercept_[0] + m.coef_[0][0])))
    return {"coef_r2": float(m.coef_[0][0]), "p_fail_centre": p_c, "p_fail_edge": p_e,
            "interpretation": "positive coefficient = failures increase towards the edge"}


def analyse(x: np.ndarray, y: np.ndarray, radius_mm: float, label: str, field_mm: Optional[tuple] = None,
            field_origin=(0.0, 0.0), eps_mm: float = 3.0, min_samples: int = 5) -> dict:
    db = dbscan_clusters(x, y, eps_mm, min_samples)
    prof = radial_profile(x, y, radius_mm)
    out = {"data_label": label, "caveat": CAVEAT, "n_defects": int(len(x)),
           "dbscan": {k: v for k, v in db.items() if k != "labels"}, "radial_profile": prof,
           "ring": ring_indicator(prof)}
    if field_mm:
        out["reticle_repeat"] = reticle_repeat(x, y, field_mm[0], field_mm[1], field_origin)
    classes = []
    if prof["edge_enrichment"] == prof["edge_enrichment"] and prof["edge_enrichment"] > 2:
        classes.append("edge-enhanced")
    if out["ring"]:
        classes.append("ring-like")
    if any(c["shape"].startswith("linear") for c in db["clusters"]):
        classes.append("linear (scratch-like)")
    if any(c["shape"].startswith("compact") and c["size"] >= 2 * min_samples for c in db["clusters"]):
        classes.append("local hotspot(s)")
    if field_mm and out["reticle_repeat"]:
        classes.append("reticle-repeat-like")
    out["pattern_classes"] = classes or ["no dominant pattern (random-like)"]
    out["labels"] = db["labels"]
    return out
