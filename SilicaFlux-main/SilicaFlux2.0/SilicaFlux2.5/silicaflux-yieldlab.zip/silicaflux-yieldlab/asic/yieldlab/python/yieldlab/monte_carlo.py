"""Reproducible multi-wafer / multi-lot Monte Carlo engine.

Per wafer (lot l, wafer w):

1. die grid (fixed per scenario, built once)
2. defects: lot multiplier (shared by the lot) x wafer multiplier x excursion, then spatial generators
3. defect -> die -> region mapping (exact intersection)
4. fatality draws -> fatal faults; SRAM faults get a fault type and array coordinates
5. repair scheme (implemented or CONDITIONAL hypothetical)
6. parametric values (hierarchical, hypothetical unless calibrated)
7. wafer-probe flow (stop-on-fail, retests) -> outcome classes and bins
8. packaging (assembly yield) and final test of the sellable dies
9. counts per wafer; full die / defect maps kept for the first ``keep_maps`` wafers only

Random numbers: ``SeedSequence(seed, spawn_key=(lot, wafer, stream))`` with one
independent stream per mechanism (defects, region attribution, fatality, SRAM,
test, parametric, packaging).  A wafer's result depends only on (seed, lot,
wafer, scenario), never on worker count or scheduling.  Because mechanisms use
separate streams, two scenarios that differ only in, e.g., MBIST coverage see
*identical* defect maps -- this is the common-random-numbers pairing used by
the experiment manager (docs/MODELS.md section 9).
"""
from __future__ import annotations

import os
import platform
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field
from typing import Optional

import numpy as np
import pandas as pd
from shapely.strtree import STRtree
import shapely

from . import __version__
from .config import Scenario
from .defect_mapping import Hits, map_defects
from .die_layout import DieSpec, SiteClass, layout_wafer
from .memory_repair import FAULT_TYPES, assign_faults, evaluate_die_memories
from .parametric import Measurement, speed_grade
from .regions import RegionModel, SimpleRegionModel
from .spatial_defects import DefectGenerator
from .test_model import Outcome, run_tests, classify
from .wafer_geometry import WaferGeometry
from .provenance import Source
from .binning import assign_bins

STREAMS = {"defects": 0, "locate": 1, "fatal": 2, "sram": 3, "test": 4, "parametric": 5, "packaging": 6}
LOT_STREAM = 10**6
RUN_STREAM = 10**7


def rng_for(seed: int, *key: int) -> np.random.Generator:
    return np.random.default_rng(np.random.SeedSequence(seed, spawn_key=tuple(int(k) for k in key)))


@dataclass
class Runtime:
    scn: Scenario
    geo: WaferGeometry
    die: DieSpec
    wmap: object
    rm: object
    gen: DefectGenerator
    elig: np.ndarray
    site_to_elig: np.ndarray
    probe_steps: list
    final_steps: list
    cov_probe: np.ndarray
    cov_final: np.ndarray
    macro_bbox: np.ndarray
    orgs: list
    bank_of: list
    reticle_offsets: dict
    tree: object
    region_names: list
    region_kinds: list
    assembly_rid: int
    meta: dict = field(default_factory=dict)


def build_die(scn: Scenario, rm) -> DieSpec:
    if isinstance(rm, SimpleRegionModel):
        src, ref = scn.design.die_override_source, scn.design.die_override_reference
    else:
        src = Source.MEASURED_TOOL_OUTPUT if rm.pad_um == 0 else Source.DERIVED
        ref = (f"FloorplanLab {rm.geo.run_id} die {rm.geo.die_w_um:.2f} x {rm.geo.die_h_um:.2f} um "
               f"({rm.geo.reference}) + pad ring {rm.pad_um} um/side ({rm.design.pad_ring.source.value})")
    return DieSpec(name=scn.design.name, width_um=rm.die_w_um, height_um=rm.die_h_um, source=src, reference=ref,
                   scribe_x_um=scn.die.scribe_x_um, scribe_y_um=scn.die.scribe_y_um,
                   scribe_source=scn.die.scribe_source, scribe_reference=scn.die.scribe_reference,
                   rotation_deg=scn.die.rotation_deg)


def build_region_model(scn: Scenario):
    if scn.design.floorplan_run:
        return RegionModel(scn.design)
    if scn.simple_regions and scn.design.die_override_um:
        w, h = scn.design.die_override_um
        return SimpleRegionModel(scn.design, scn.simple_regions, w, h)
    raise ValueError(f"design {scn.design.name}: neither a FloorplanLab run nor (die_override_um + simple_regions)")


def build_runtime(scn: Scenario) -> Runtime:
    rm = build_region_model(scn)
    geo = WaferGeometry(scn.wafer)
    die = build_die(scn, rm)
    wmap = layout_wafer(geo, die, scn.reticle, scn.layout)
    gen = DefectGenerator(scn.defects, geo, wmap)
    elig = wmap.eligible_index()
    s2e = np.full(wmap.n_sites, -1)
    s2e[elig] = np.arange(elig.size)
    names = [r.name for r in rm.regions] + ["assembly"]
    kinds = [r.kind for r in rm.regions] + ["assembly"]
    probe = scn.tests.enabled_steps("wafer_probe")
    final = scn.tests.enabled_steps("final_test")
    cov_p = scn.tests.coverage_matrix(probe, names, kinds, FAULT_TYPES)
    cov_f = scn.tests.coverage_matrix(final, names, kinds, FAULT_TYPES)
    macros = rm.macro_list()
    macro_bbox = np.array([m["bbox_um"] for m in macros], float).reshape(-1, 4)
    orgs, banks = [], []
    for m in macros:
        org = m["organisation"]
        orgs.append(org.value if org.available else {"words": 1, "bits": 1, "column_mux": 1, "rows": 1, "cols": 1})
        banks.append(m["bank"])
    if scn.sram.repair.scheme not in ("none",) and not macros:
        raise ValueError("SRAM repair analysis needs macro geometry (FloorplanLab); this design has none")
    if scn.sram.repair.scheme not in ("none", "bank_disable"):
        for m in macros:
            m["organisation"].value  # raises MissingInputError if the organisation is unknown
    nslots = wmap.dies_per_field if wmap.reticle_enabled else (1, 1)
    ret_off = scn.parametric.reticle_offsets(nslots, rng_for(scn.monte_carlo.seed, RUN_STREAM, 1))
    tree = STRtree(shapely.box(wmap.dx0, wmap.dy0, wmap.dx1, wmap.dy1))
    return Runtime(scn, geo, die, wmap, rm, gen, elig, s2e, probe, final, cov_p, cov_f, macro_bbox, orgs, banks,
                   ret_off, tree, names, kinds, len(rm.regions))


# --------------------------------------------------------------------------- one wafer

def simulate_wafer(rt: Runtime, lot: int, wafer: int, keep: bool = False) -> dict:
    scn = rt.scn
    seed = scn.monte_carlo.seed
    rngs = {k: rng_for(seed, lot, wafer, v) for k, v in STREAMS.items()}
    lot_rng = rng_for(seed, lot, LOT_STREAM)
    lot_mult = scn.defects.variation.lot_multiplier(lot_rng)
    lot_par = scn.parametric.lot_effects(lot_rng)
    w_mult, excursion = scn.defects.variation.wafer_multiplier(rngs["defects"])
    ds = rt.gen.generate(rngs["defects"], multiplier=lot_mult * w_mult, excursion=excursion)
    hits = map_defects(ds, rt.wmap, rt.rm, scn.fatality, rngs["locate"], scn.monte_carlo.sample_spacing_um,
                       rngs["fatal"], rt.tree)
    wm = rt.wmap
    E = rt.elig.size
    R = len(rt.rm.regions)
    eh = rt.site_to_elig[hits.site] if hits.n else np.zeros(0, int)
    in_e = eh >= 0
    # ---- defect / fatal events per eligible die (distinct events, no double counting)
    def _distinct(mask):
        if not mask.any():
            return np.zeros(E, int)
        key = np.unique(np.c_[eh[mask], hits.event[mask]], axis=0)
        return np.bincount(key[:, 0], minlength=E)

    ev = _distinct(in_e)
    fatal_mask = in_e & hits.fatal
    fev = _distinct(fatal_mask)
    phys_defect = ev > 0
    raw_fail = fev > 0
    # ---- per region fatal dies
    region_hit = np.zeros((E, R), bool)
    if fatal_mask.any():
        region_hit[eh[fatal_mask], hits.rid[fatal_mask]] = True
    # ---- SRAM faults
    sram_mask = fatal_mask & (hits.macro >= 0)
    f_die = eh[fatal_mask]
    f_rid = hits.rid[fatal_mask]
    f_type = np.full(f_die.size, len(FAULT_TYPES))          # 'logic / non-SRAM'
    is_sram_region = np.array([k == "sram" for k in rt.region_kinds[:R]])
    sram_like = is_sram_region[f_rid] if f_die.size else np.zeros(0, bool)
    idx_sram = np.nonzero(sram_like)[0]
    removed = np.zeros(f_die.size, bool)
    repaired = np.zeros(E, bool)
    reduced_candidate = np.zeros(E, bool)
    sram_only = np.zeros(E, bool)
    repairable_hyp = np.zeros(E, bool)
    sram_fault_dies = np.zeros(E, bool)
    if idx_sram.size:
        mac = hits.macro[fatal_mask][idx_sram]
        has_macro = mac >= 0
        t = rngs["sram"].choice(len(FAULT_TYPES), size=idx_sram.size, p=scn.sram.fault_mix.probs())
        r_ = np.zeros(idx_sram.size, int)
        c_ = np.zeros(idx_sram.size, int)
        if has_macro.any():
            t2, r2, c2 = assign_faults(scn.sram, hits.lx_um[fatal_mask][idx_sram][has_macro],
                                       hits.ly_um[fatal_mask][idx_sram][has_macro], rt.macro_bbox, rt.orgs,
                                       mac[has_macro], rngs["sram"])
            t[has_macro], r_[has_macro], c_[has_macro] = t2, r2, c2
        f_type[idx_sram] = t
        cap = scn.sram.repair
        dies = np.unique(f_die[idx_sram])
        sram_fault_dies[dies] = True
        logic_fault_dies = np.zeros(E, bool)
        logic_fault_dies[f_die[~sram_like]] = True
        for d in dies:
            sel = idx_sram[f_die[idx_sram] == d]
            loc = np.searchsorted(idx_sram, sel)
            res = evaluate_die_memories(t[loc], r_[loc], c_[loc], mac[loc], rt.orgs, rt.bank_of, cap) \
                if (mac[loc] >= 0).all() else {"repairable_under_scheme": False, "failed_banks": ["unknown"]}
            only_sram = not logic_fault_dies[d]
            sram_only[d] = only_sram
            if res["repairable_under_scheme"] and cap.scheme != "none":
                repairable_hyp[d] = only_sram
                if only_sram:
                    repaired[d] = True
                    removed[sel] = True
            if cap.scheme == "bank_disable" and only_sram and res["failed_banks"]:
                reduced_candidate[d] = True
    cap_impl = scn.sram.repair.implemented
    conditional = repaired & (not cap_impl)
    functional_fail = raw_fail & ~repaired
    # ---- parametric
    rng_p = rngs["parametric"]
    es = rt.elig
    if scn.parametric.enabled and scn.parametric.parameters:
        ptrue = scn.parametric.sample(wm.cx[es], wm.cy[es], rt.geo.R, wm.slot_x[es], wm.slot_y[es],
                                      rt.reticle_offsets, lot_par, rng_p)
        param_ok = scn.parametric.all_in_spec(ptrue, E)
    else:
        ptrue, param_ok = {}, np.ones(E, bool)
    meas = Measurement(scn.parametric)
    # ---- wafer probe
    rng_t = rngs["test"]
    tested = rng_t.random(E) < scn.tests.probe_fraction
    p_inc = scn.tests.incomplete_probability.value or 0.0
    incomplete = tested & (rng_t.random(E) < p_inc)
    keep_f = ~removed
    pr = run_tests(scn.tests, rt.probe_steps, rt.cov_probe, E, f_die, f_rid, f_type, ptrue, param_ok, meas, rng_t,
                   fault_active=keep_f)
    fd, fr, ft = f_die[keep_f], f_rid[keep_f], f_type[keep_f]
    ff = pr["first_fail"]
    ff_eff = np.where(tested & ~incomplete, ff, -2)
    outcome = classify(E, tested, incomplete, functional_fail, conditional, param_ok, ff)
    # ---- bins
    names = np.array([s.name for s in rt.probe_steps] + [""], dtype=object)
    cats = np.array([s.category for s in rt.probe_steps] + [""], dtype=object)
    first_step = np.where(ff >= 0, names[ff], "")
    first_cat = np.where(ff >= 0, cats[ff], "")
    grade = speed_grade(scn.parametric, pr["measured"], E)
    grades_defined = [g.name for g in scn.parametric.speed_grades if g.product_defined]
    top = grades_defined[0] if grades_defined else None
    passed_all = tested & ~incomplete & (ff < 0)
    fields = {
        "tested": tested,
        "incomplete": incomplete,
        "passed_all": passed_all,
        "first_fail_step": first_step,
        "first_fail_category": first_cat,
        "speed_grade": grade,
        "meets_top_grade": passed_all & ((grade == top) if top else np.ones(E, bool)),
        "lower_grade": passed_all & (grade != top) & (grade != "") if top else np.zeros(E, bool),
        "conditional_repair": conditional,
        "sram_fail_only": sram_only & functional_fail,
        "repairable_under_hypothetical": repairable_hyp,
        "reduced_config_candidate": reduced_candidate,
    }
    bins = assign_bins(scn.bins, fields, E)
    sellable_codes = {b.code for b in scn.bins.active() if b.sellable}
    sellable = np.isin(bins, list(sellable_codes)) & passed_all
    # ---- packaging + final test
    rng_k = rngs["packaging"]
    asm_yield = scn.tests.assembly_yield.value if scn.tests.assembly_yield is not None else 1.0
    packaged = sellable.copy()
    asm_fail = packaged & (rng_k.random(E) >= asm_yield)
    conforming_wafer = ~functional_fail & param_ok & ~conditional
    if rt.final_steps:
        fdie = np.concatenate([fd, np.nonzero(asm_fail)[0]])
        freg = np.concatenate([fr, np.full(int(asm_fail.sum()), rt.assembly_rid)])
        ftyp = np.concatenate([ft, np.full(int(asm_fail.sum()), len(FAULT_TYPES))])
        live = packaged[fdie] if fdie.size else np.zeros(0, bool)
        pf = run_tests(scn.tests, rt.final_steps, rt.cov_final, E, fdie[live], freg[live], ftyp[live], ptrue,
                       param_ok, meas, rng_k)
        final_fail = packaged & (pf["first_fail"] >= 0)
    else:
        final_fail = np.zeros(E, bool)
    delivered = packaged & ~final_fail
    conforming_final = conforming_wafer & ~asm_fail
    row = {
        "lot": lot, "wafer": wafer, "lot_multiplier": lot_mult, "wafer_multiplier": w_mult,
        "excursion": bool(excursion), "defect_points": ds.n_points, "extended_defects": len(ds.extended),
        "gross_sites": wm.n_sites, "eligible": E,
        "phys_defect_dies": int(phys_defect.sum()),
        "functional_fail_raw": int(raw_fail.sum()),
        "sram_fault_dies": int(sram_fault_dies.sum()),
        "repaired_implemented": int((repaired & cap_impl).sum()),
        "repaired_conditional": int(conditional.sum()),
        "functional_fail": int(functional_fail.sum()),
        "param_fail": int((~param_ok).sum()),
        "param_fail_only": int((~param_ok & ~functional_fail & ~conditional).sum()),
        "conforming_wafer": int(conforming_wafer.sum()),
        "tested": int((tested & ~incomplete).sum()),
        "untested": int((~tested | incomplete).sum()),
        "retested_dies": int((pr["retests"] > 0).sum()),
        "false_reject_dies": int((pr["false_reject_step"] >= 0).sum()),
        "probe_pass": int(passed_all.sum()),
        "sellable_bin": int(sellable.sum()),
        "packaged": int(packaged.sum()),
        "assembly_fail": int(asm_fail.sum()),
        "final_reject": int(final_fail.sum()),
        "delivered": int(delivered.sum()),
        "delivered_conforming": int((delivered & conforming_final).sum()),
        "delivered_escape": int((delivered & ~conforming_final).sum()),
    }
    for o in Outcome:
        row[f"outcome_{o.name}"] = int((outcome == o).sum())
    for b in scn.bins.bins:
        row[f"bin_{b.code}"] = int((bins == b.code).sum())
    for r in range(R):
        nm = rt.region_names[r]
        killed = region_hit[:, r]
        others = region_hit.sum(axis=1) - killed
        row[f"kill_{nm}"] = int(killed.sum())
        row[f"sole_{nm}"] = int((killed & (others == 0)).sum())
    esc = outcome == Outcome.DEFECTIVE_ESCAPED
    for r in range(R):
        row[f"escape_{rt.region_names[r]}"] = int((esc & region_hit[:, r]).sum())
    per_gen = ds.summary()["per_generator"]
    for g, n in per_gen.items():
        row[f"gen_{g}"] = n
    result = {"row": row}
    if keep:
        result["map"] = _wafer_map_payload(rt, ds, hits, eh, ev, fev, outcome, bins, functional_fail, conditional,
                                           param_ok, ptrue, grade, first_step, region_hit, sram_fault_dies,
                                           repaired, delivered, conforming_final)
    return result


def _wafer_map_payload(rt, ds, hits, eh, ev, fev, outcome, bins, functional_fail, conditional, param_ok, ptrue,
                       grade, first_step, region_hit, sram_fault_dies, repaired, delivered, conforming_final) -> dict:
    wm = rt.wmap
    n = wm.n_sites
    E = rt.elig.size
    def full(arr, fill):
        out = np.full(n, fill, dtype=object if isinstance(fill, str) else type(fill))
        out[rt.elig] = arr
        return out
    all_ev = np.zeros(n, int)
    if hits.n:
        key = np.unique(np.c_[hits.site, hits.event], axis=0)
        all_ev = np.bincount(key[:, 0], minlength=n)
    regions = [";".join(rt.region_names[r] for r in np.nonzero(region_hit[i])[0]) for i in range(E)]
    classes_hit = [""] * n
    if hits.n:
        for s in np.unique(hits.site):
            classes_hit[s] = ";".join(sorted({ds.classes[c] for c in hits.cls[hits.site == s]}))
    payload = {
        "sites": {
            "ix": wm.ix.tolist(), "iy": wm.iy.tolist(),
            "cx": np.round(wm.cx, 4).tolist(), "cy": np.round(wm.cy, 4).tolist(),
            "site_class": wm.cls.tolist(), "eligible": wm.eligible.tolist(),
            "field": np.c_[wm.field_x, wm.field_y].tolist(),
            "defect_events": all_ev.tolist(), "defect_classes": classes_hit,
            "fatal_events": full(fev, -1).tolist(),
            "outcome": full(outcome.astype(int), -1).tolist(),
            "bin": full(bins, -1).tolist(),
            "functional_fail": full(functional_fail.astype(int), -1).tolist(),
            "conditional_repair": full(conditional.astype(int), -1).tolist(),
            "param_ok": full(param_ok.astype(int), -1).tolist(),
            "speed_grade": full(np.asarray(grade, dtype=object), "").tolist(),
            "first_fail_step": full(np.asarray(first_step, dtype=object), "").tolist(),
            "fatal_regions": full(np.asarray(regions, dtype=object), "").tolist(),
            "sram_fault": full(sram_fault_dies.astype(int), -1).tolist(),
            "repaired": full(repaired.astype(int), -1).tolist(),
            "delivered": full(delivered.astype(int), -1).tolist(),
            "delivered_conforming": full((delivered & conforming_final).astype(int), -1).tolist(),
        },
        "params": {k: full(np.round(v, 4), float("nan")).tolist() for k, v in ptrue.items()},
        "defects": {
            "x": np.round(ds.x, 4).tolist(), "y": np.round(ds.y, 4).tolist(),
            "size_um": np.round(ds.size_um, 3).tolist(), "cls": ds.cls.tolist(), "gen": ds.gen.tolist(),
            "cluster": ds.cluster.tolist(), "classes": ds.classes, "generators": ds.gen_names,
            "extended": [{"coords": _coords(e["geom"]), "cls": ds.classes[e["cls"]], "gen": ds.gen_names[e["gen"]]}
                         for e in ds.extended],
        },
    }
    return payload


def _coords(geom) -> list:
    if geom.geom_type == "LineString":
        return [list(map(lambda p: [round(p[0], 4), round(p[1], 4)], geom.coords))]
    if hasattr(geom, "geoms"):
        out = []
        for g in geom.geoms:
            out.extend(_coords(g))
        return out
    if geom.geom_type == "Polygon":
        return [[[round(x, 4), round(y, 4)] for x, y in geom.exterior.coords]]
    return []


# --------------------------------------------------------------------------- many wafers

_RT: Optional[Runtime] = None


def _init_worker(scn_json: str) -> None:
    global _RT
    _RT = build_runtime(Scenario.model_validate_json(scn_json))


def _work(task: tuple[int, int, bool]) -> dict:
    lot, wafer, keep = task
    return simulate_wafer(_RT, lot, wafer, keep)


@dataclass
class SimulationResult:
    scenario: Scenario
    wafers: pd.DataFrame
    maps: dict
    meta: dict
    runtime: Runtime


def software_versions() -> dict:
    import matplotlib
    import plotly
    import pydantic
    import scipy
    import shapely as _sh

    return {"yieldlab": __version__, "python": platform.python_version(), "numpy": np.__version__,
            "scipy": scipy.__version__, "pandas": pd.__version__, "shapely": _sh.__version__,
            "pydantic": pydantic.__version__, "matplotlib": matplotlib.__version__, "plotly": plotly.__version__,
            "platform": platform.platform()}


def run_simulation(scn: Scenario, lots: Optional[int] = None, wafers_per_lot: Optional[int] = None,
                   workers: Optional[int] = None, keep_maps: Optional[int] = None,
                   runtime: Optional[Runtime] = None) -> SimulationResult:
    mc = scn.monte_carlo
    lots = lots or mc.lots
    wpl = wafers_per_lot or mc.wafers_per_lot
    workers = workers or mc.workers
    keep_n = mc.keep_maps if keep_maps is None else keep_maps
    total = lots * wpl
    if total > mc.max_wafers_in_memory:
        raise ValueError(f"{total} wafers exceeds max_wafers_in_memory={mc.max_wafers_in_memory}")
    tasks = [(l, w, (l * wpl + w) < keep_n) for l in range(lots) for w in range(wpl)]
    t0 = time.time()
    rt = runtime or build_runtime(scn)
    if workers > 1 and total > 1:
        with ProcessPoolExecutor(max_workers=min(workers, os.cpu_count() or 1), initializer=_init_worker,
                                 initargs=(scn.model_dump_json(),)) as ex:
            results = list(ex.map(_work, tasks, chunksize=max(1, total // (4 * workers))))
    else:
        results = [simulate_wafer(rt, l, w, k) for l, w, k in tasks]
    rows = [r["row"] for r in results]
    maps = {(r["row"]["lot"], r["row"]["wafer"]): r["map"] for r in results if "map" in r}
    df = pd.DataFrame(rows).sort_values(["lot", "wafer"]).reset_index(drop=True)
    meta = {
        "scenario": scn.name, "scenario_sha256": scn.digest(), "seed": mc.seed, "lots": lots,
        "wafers_per_lot": wpl, "wafers": total, "workers": workers, "seconds": round(time.time() - t0, 3),
        "rng": "numpy PCG64 via SeedSequence(seed, spawn_key=(lot, wafer, stream)); streams " + str(STREAMS),
        "versions": software_versions(),
        "die_um": [rt.die.width_um, rt.die.height_um], "die_area_cm2": rt.die.area_cm2,
        "pitch_mm": list(rt.wmap.pitch_mm), "eligible_sites": int(rt.elig.size),
        "site_counts": rt.wmap.counts(), "repair": scn.sram.repair.label(),
        "fatality_mode": scn.fatality.mode, "defect_model": scn.defects.name,
        "density_kind": scn.defects.density_kind,
    }
    return SimulationResult(scn, df, maps, meta, rt)
