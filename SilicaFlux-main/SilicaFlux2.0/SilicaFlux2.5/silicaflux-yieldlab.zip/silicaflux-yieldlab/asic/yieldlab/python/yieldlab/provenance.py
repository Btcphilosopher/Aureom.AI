"""Input provenance: every number YieldLab uses carries where it came from.

The single most important rule of this project is that a simulated result must
never be mistaken for a measured one, and that missing foundry data must never
be silently replaced by a plausible-looking default.  This module enforces
that rule in code:

* :class:`Source` classifies an input (tool-measured, design input, standard
  reference, planning estimate, document citation, hypothetical, NOT AVAILABLE).
* :class:`Sourced` wraps a value with its source and a human-readable
  reference.  Reading ``.value`` of a NOT_AVAILABLE input raises
  :class:`MissingInputError` -- there is no code path that turns "unknown" into
  a number.
* :class:`ProvenanceLedger` collects every input actually consumed by a run so
  the report can state, per result, whether any hypothetical or estimated input
  was involved (results are then labelled accordingly).
"""
from __future__ import annotations

from enum import Enum
from typing import Any, Iterable

from pydantic import BaseModel, ConfigDict, Field, model_validator


class MissingInputError(RuntimeError):
    """Raised when a calculation needs an input whose source is NOT_AVAILABLE."""


class Source(str, Enum):
    #: read from a tool output in the SilicaFlux repository (OpenROAD, Yosys, fault simulation ...)
    MEASURED_TOOL_OUTPUT = "MEASURED_TOOL_OUTPUT"
    #: measured manufacturing data that passed import validation
    MEASURED_MANUFACTURING = "MEASURED_MANUFACTURING"
    #: a design decision / specification in the repository (e.g. memory map, bank count)
    DESIGN_INPUT = "DESIGN_INPUT"
    #: published industry standard value (e.g. SEMI M1 wafer notch) -- confirm with the supplier
    STANDARD_REFERENCE = "STANDARD_REFERENCE"
    #: an engineering estimate written down in a SilicaFlux document (marked [E] there)
    PLANNING_ESTIMATE = "PLANNING_ESTIMATE"
    #: a figure quoted inside a repository document from a third party, not verified as a quote
    DOCUMENT_CITED_UNVERIFIED = "DOCUMENT_CITED_UNVERIFIED"
    #: explicitly hypothetical scenario parameter chosen for a sensitivity study
    HYPOTHETICAL = "HYPOTHETICAL"
    #: value derived by YieldLab from other sourced inputs (inherits the weakest source)
    DERIVED = "DERIVED"
    #: required but not available -- any attempt to use it raises MissingInputError
    NOT_AVAILABLE = "NOT_AVAILABLE"


#: ordering from strongest to weakest evidence; DERIVED values take the weakest of their inputs
_STRENGTH = [
    Source.MEASURED_MANUFACTURING,
    Source.MEASURED_TOOL_OUTPUT,
    Source.DESIGN_INPUT,
    Source.STANDARD_REFERENCE,
    Source.PLANNING_ESTIMATE,
    Source.DOCUMENT_CITED_UNVERIFIED,
    Source.HYPOTHETICAL,
    Source.NOT_AVAILABLE,
]

#: sources whose use forces the "HYPOTHETICAL / SCENARIO" label on a result
SCENARIO_SOURCES = {Source.HYPOTHETICAL, Source.DOCUMENT_CITED_UNVERIFIED, Source.PLANNING_ESTIMATE}


def weakest(sources: Iterable[Source]) -> Source:
    srcs = [s for s in sources if s is not Source.DERIVED]
    if not srcs:
        return Source.DERIVED
    return max(srcs, key=_STRENGTH.index)


class Sourced(BaseModel):
    """A value with mandatory provenance."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    raw: Any = Field(default=None, alias="value")
    source: Source
    reference: str = Field(min_length=1, description="file / document / reason")
    note: str = ""

    @model_validator(mode="after")
    def _check(self) -> "Sourced":
        if self.source is Source.NOT_AVAILABLE and self.raw is not None:
            raise ValueError("a NOT_AVAILABLE input must not carry a value")
        if self.source is not Source.NOT_AVAILABLE and self.raw is None:
            raise ValueError(f"input with source {self.source.value} needs a value ({self.reference})")
        return self

    @property
    def available(self) -> bool:
        return self.source is not Source.NOT_AVAILABLE

    @property
    def value(self) -> Any:
        if self.source is Source.NOT_AVAILABLE:
            raise MissingInputError(f"input not available: {self.reference} {self.note}".strip())
        return self.raw

    @property
    def is_scenario(self) -> bool:
        return self.source in SCENARIO_SOURCES

    def label(self) -> str:
        return f"{self.source.value}: {self.reference}"

    @classmethod
    def na(cls, reference: str, note: str = "") -> "Sourced":
        return cls(value=None, source=Source.NOT_AVAILABLE, reference=reference, note=note)

    @classmethod
    def hyp(cls, value: Any, reference: str, note: str = "") -> "Sourced":
        return cls(value=value, source=Source.HYPOTHETICAL, reference=reference, note=note)


class ProvenanceLedger:
    """Records every sourced input consumed during a calculation."""

    def __init__(self) -> None:
        self._entries: dict[str, Sourced] = {}

    def use(self, name: str, item: Sourced) -> Any:
        """Register *item* under *name* and return its value (raises if NOT_AVAILABLE)."""
        self._entries[name] = item
        return item.value

    def record(self, name: str, item: Sourced) -> None:
        self._entries[name] = item

    def merge(self, other: "ProvenanceLedger", prefix: str = "") -> None:
        for k, v in other._entries.items():
            self._entries[prefix + k] = v

    @property
    def entries(self) -> dict[str, Sourced]:
        return dict(self._entries)

    def overall(self) -> Source:
        return weakest(e.source for e in self._entries.values()) if self._entries else Source.DERIVED

    def result_label(self) -> str:
        """Label attached to every output derived from this ledger."""
        srcs = {e.source for e in self._entries.values()}
        if Source.MEASURED_MANUFACTURING in srcs and not (srcs & SCENARIO_SOURCES):
            return "DERIVED FROM VERIFIED IMPORTED DATA"
        if srcs & SCENARIO_SOURCES:
            return "SIMULATED - HYPOTHETICAL SCENARIO (uses hypothetical / estimated inputs)"
        return "SIMULATED"

    def to_table(self) -> list[dict[str, str]]:
        rows = []
        for k, v in sorted(self._entries.items()):
            rows.append(
                {
                    "input": k,
                    "value": "NOT AVAILABLE" if not v.available else repr(v.raw),
                    "source": v.source.value,
                    "reference": v.reference,
                    "note": v.note,
                }
            )
        return rows
