r"""Die-size / architecture candidates and area-yield-cost multi-objective screening.

Candidates come from two very different evidence classes and are never mixed
silently:

* **FloorplanLab runs** -- real OpenROAD placements of the *same* SilicaFlux-V
  netlist (MEASURED die size, routability and timing with global-route parasitics).
* **Architecture variants** (smaller tensor array, fewer vector lanes, less SRAM,
  narrower pad ring, optional redundancy) -- no RTL variant and no physical run
  exist, so their die size is an ESTIMATE derived from a measured base run with
  an explicit rule, and every one is flagged "re-run FloorplanLab".  In
  particular removing SRAM is not assumed to shrink the die proportionally: in
  the manual arrangements the die *width* is set by four 784 um macros plus
  PDN channels (FloorplanLab RESULTS.md section 4 Q3), so logic removal only
  shrinks the height, and removing a macro *row* removes that row's height.

Mandatory constraints (candidates failing them are rejected, never ranked):
physically valid placement, required SRAM capacity, required functionality,
timing feasibility (GRT WNS >= 0 at the typical corner, the only routed timing
evidence) and -- in ``strict`` mode -- zero global-route overflow.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .die_layout import DieSpec, LayoutSpec, ReticleSpec, layout_wafer
from .floorplan_adapter import floorplan_candidates, load_geometry
from .provenance import Source
from .wafer_geometry import WaferGeometry, WaferSpec
from . import yield_models as ym


@dataclass
class Candidate:
    name: str
    evidence: str                 # MEASURED_TOOL_OUTPUT (FloorplanLab) or ESTIMATE
    die_w_um: float               # without pad ring
    die_h_um: float
    sram_kib: int
    tensor_macs_per_cycle: int
    vector_lanes: int
    grt_overflow: Optional[float]
    grt_wns_ns: Optional[float]
    physically_valid: bool
    rtl_exists: bool
    test_complexity: str
    engineering_risk: str
    notes: list[str] = field(default_factory=list)
    redundancy: str = "none"


SFV_BASE = {"sram_kib": 128, "tensor_macs_per_cycle": 16, "vector_lanes": 4}


def floorplan_run_candidates() -> list[Candidate]:
    out = []
    for r in floorplan_candidates():
        if r["die_w_um"] is None:
            continue
        valid = r["physically_valid"]
        out.append(Candidate(
            name=f"FLP:{r['run_id']}", evidence="MEASURED_TOOL_OUTPUT", die_w_um=r["die_w_um"], die_h_um=r["die_h_um"],
            sram_kib=128, tensor_macs_per_cycle=16, vector_lanes=4,
            grt_overflow=r["grt_overflow"], grt_wns_ns=r["grt_wns_ns"], physically_valid=valid, rtl_exists=True,
            test_complexity="baseline (same netlist)",
            engineering_risk="low (placement change only)" if valid else "run failed FloorplanLab gates",
            notes=[r["description"], f"status={r['status']}" + (f" ({r['failure_reason']})" if r["failure_reason"] else "")],
        ))
    return out


def architecture_variants(base_run: str = "C_sram_near_compute") -> list[Candidate]:
    """Estimated variants derived from a measured base run (explicit rules, flagged)."""
    g = load_geometry(base_run)
    util = None
    for r in floorplan_candidates():
        if r["run_id"] == base_run:
            util = r["std_cell_area_placed_um2"] / (r["core_area_mm2"] * 1e6 - r["macro_area_um2"])
    core_w = g.core_um[2] - g.core_um[0]
    base = dict(die_w_um=g.die_w_um, grt_overflow=None, grt_wns_ns=None, physically_valid=True, rtl_exists=False)
    tensor = g.groups["tensor"].area_um2
    vector = g.groups["vector"].area_um2
    out = []

    def shrink_logic(cell_um2: float) -> float:
        return (cell_um2 / util) / core_w          # removed core area / core width = height reduction (um)

    dh = shrink_logic(0.75 * tensor)
    out.append(Candidate("VAR:tensor_2x2", "ESTIMATE", die_h_um=g.die_h_um - dh, sram_kib=128,
                         tensor_macs_per_cycle=4, vector_lanes=4, test_complexity="lower (smaller MAC array)",
                         engineering_risk="medium: new RTL + re-verification + FloorplanLab/TimingFlow re-run",
                         notes=[f"tensor std-cell area {tensor/1e6:.3f} mm^2 x 0.75 removed (MAC array assumed to "
                                f"scale with MAC count; control not), at measured row utilisation {util:.3f}; "
                                f"height -{dh:.0f} um, width unchanged (set by 4 x 784 um SRAM macros)"], **base))
    dh = shrink_logic(0.5 * vector)
    out.append(Candidate("VAR:vector_2_lanes", "ESTIMATE", die_h_um=g.die_h_um - dh, sram_kib=128,
                         tensor_macs_per_cycle=16, vector_lanes=2, test_complexity="lower",
                         engineering_risk="medium: new RTL + re-verification + physical re-run",
                         notes=[f"vector std-cell area x 0.5 removed; height -{dh:.0f} um (estimate)"], **base))
    # remove one main-SRAM macro row (4 x 2048x64 = 64 KiB): in C the top row spans y 1591.38..2218.08
    macros = sorted({(m.bbox_um[1], m.bbox_um[3]) for m in g.macros if "2048x64" in m.master})
    row_h = macros[-1][1] - macros[-1][0]
    gap = macros[-1][0] - max(m.bbox_um[3] for m in g.macros if m.bbox_um[3] <= macros[-1][0])
    dh = row_h + 0.5 * gap
    out.append(Candidate("VAR:sram_64KiB", "ESTIMATE", die_h_um=g.die_h_um - dh, sram_kib=64,
                         tensor_macs_per_cycle=16, vector_lanes=4, test_complexity="lower (half the MBIST time)",
                         engineering_risk="medium: memory map change, firmware, physical re-run",
                         notes=[f"one 4-macro row removed: macro height {row_h:.2f} um + half the channel "
                                f"({gap:.1f} um) -> height -{dh:.0f} um; NOT proportional to SRAM area"], **base))
    out.append(Candidate("VAR:tensor_2x2+sram_64KiB", "ESTIMATE",
                         die_h_um=g.die_h_um - dh - shrink_logic(0.75 * tensor), sram_kib=64,
                         tensor_macs_per_cycle=4, vector_lanes=4, test_complexity="lowest",
                         engineering_risk="high: two architectural changes", notes=["sum of the two estimates"], **base))
    # spare rows on every macro: +area (hypothetical capability)
    out.append(Candidate("VAR:sram_spare_rows", "ESTIMATE", die_h_um=g.die_h_um + 0.02 * row_h * 2, sram_kib=128,
                         tensor_macs_per_cycle=16, vector_lanes=4, test_complexity="higher (BIRA, fuse programming)",
                         engineering_risk="high: no macro with redundancy exists (IHP); needs compiler + fuses + BIRA",
                         redundancy="spare rows (HYPOTHETICAL)",
                         notes=["+2 % macro height per row of macros assumed for spare rows + repair logic (HYPOTHETICAL)"],
                         **base))
    return out


def evaluate(cands: list[Candidate], wafer: WaferSpec, pad_ring_um: float, scribe_um: float,
             d0_grid: list[float], alpha: float, wafer_cost: Optional[float], per_die_cost: Optional[float],
             reticle: Optional[ReticleSpec] = None) -> list[dict]:
    geo = WaferGeometry(wafer)
    rows = []
    for c in cands:
        w = c.die_w_um + 2 * pad_ring_um
        h = c.die_h_um + 2 * pad_ring_um
        die = DieSpec(name=c.name, width_um=w, height_um=h,
                      source=Source.MEASURED_TOOL_OUTPUT if c.evidence.startswith("MEASURED") else Source.PLANNING_ESTIMATE,
                      reference=c.evidence, scribe_x_um=scribe_um, scribe_y_um=scribe_um)
        wm = layout_wafer(geo, die, reticle or ReticleSpec(enabled=False), LayoutSpec())
        gross = wm.n_full
        a_cm2 = w * h / 1e8
        for d0 in d0_grid:
            yp = ym.poisson_yield(a_cm2, d0)
            yn = ym.negative_binomial_yield(a_cm2, d0, alpha)
            good_p, good_n = gross * yp, gross * yn
            cost = None
            if wafer_cost is not None and per_die_cost is not None and good_n > 0:
                cost = (wafer_cost + gross * per_die_cost) / good_n
            rows.append({
                "candidate": c.name, "evidence": c.evidence, "die_w_mm": w / 1000, "die_h_mm": h / 1000,
                "die_area_mm2": w * h / 1e6, "gross_die": gross, "d0_per_cm2": d0,
                "yield_poisson": yp, f"yield_nb_a{alpha:g}": yn,
                "good_die_poisson": good_p, "good_die_nb": good_n, "cost_per_good_die_nb": cost,
                "sram_kib": c.sram_kib, "tensor_macs_per_cycle": c.tensor_macs_per_cycle,
                "vector_lanes": c.vector_lanes, "grt_overflow": c.grt_overflow, "grt_wns_ns": c.grt_wns_ns,
                "physically_valid": c.physically_valid, "rtl_exists": c.rtl_exists, "redundancy": c.redundancy,
                "test_complexity": c.test_complexity, "engineering_risk": c.engineering_risk,
                "notes": " | ".join(c.notes),
            })
    return rows


def constraints(row: dict, required_sram_kib: int = 128, required_macs: int = 16, required_lanes: int = 4,
                strict_routability: bool = False, overflow_screen: float = 5000.0) -> list[str]:
    """Return the list of violated mandatory constraints (empty = feasible)."""
    v = []
    if not row["physically_valid"]:
        v.append("physically invalid (FloorplanLab gates)")
    if row["sram_kib"] < required_sram_kib:
        v.append(f"SRAM {row['sram_kib']} KiB < required {required_sram_kib}")
    if row["tensor_macs_per_cycle"] < required_macs:
        v.append(f"tensor {row['tensor_macs_per_cycle']} MAC/cycle < required {required_macs}")
    if row["vector_lanes"] < required_lanes:
        v.append(f"vector lanes {row['vector_lanes']} < required {required_lanes}")
    if row["evidence"] == "MEASURED_TOOL_OUTPUT":
        if row["grt_wns_ns"] is None or row["grt_wns_ns"] < 0:
            v.append("timing: GRT WNS < 0 at typical corner")
        if row["grt_overflow"] is None:
            v.append("no global route")
        elif strict_routability and row["grt_overflow"] > 0:
            v.append(f"routability: GRT overflow {row['grt_overflow']:.0f} > 0")
        elif row["grt_overflow"] > overflow_screen:
            v.append(f"routability screen: overflow {row['grt_overflow']:.0f} > {overflow_screen:.0f}")
    else:
        v.append("no physical implementation (estimate only) - re-run FloorplanLab/TimingFlow before deciding")
    return v


def pareto_front(rows: list[dict], objectives: dict[str, str]) -> list[int]:
    """Indices of non-dominated rows. objectives: column -> 'max' | 'min'."""
    pts = np.array([[(-1 if s == "max" else 1) * float(r[k]) for k, s in objectives.items()] for r in rows])
    n = len(rows)
    keep = []
    for i in range(n):
        dominated = False
        for j in range(n):
            if i != j and np.all(pts[j] <= pts[i]) and np.any(pts[j] < pts[i]):
                dominated = True
                break
        if not dominated:
            keep.append(i)
    return keep
