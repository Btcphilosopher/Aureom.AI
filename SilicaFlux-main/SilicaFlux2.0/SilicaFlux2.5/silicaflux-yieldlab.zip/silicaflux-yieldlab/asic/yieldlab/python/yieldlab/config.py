"""Scenario configuration: YAML loading, includes, overrides and strict validation.

A scenario file composes sections; a section may be inline or a path to
another YAML file (relative to the including file, then to ``configs/``)::

    scenario:
      name: sfv_baseline_200mm
      design: designs/silicaflux_v.yaml
      wafer: wafers/wafer_200mm.yaml
      defects: defects/baseline_mixture.yaml
      ...
    overrides:
      defects.components.0.density_per_cm2: 0.5

Unknown keys are errors (pydantic ``extra="forbid"``), so a typo cannot
silently fall back to a default.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Any, Literal, Optional

import yaml
from pydantic import BaseModel, ConfigDict, Field

from .binning import BinTable
from .die_layout import LayoutSpec, ReticleSpec
from .fatality import FatalityModel
from .memory_repair import SramModel
from .parametric import ParametricModel
from .provenance import Source
from .regions import DesignSpec
from .spatial_defects import DefectModel
from .test_model import TestPlan
from .wafer_geometry import WaferSpec

CONFIG_ROOT = Path(__file__).resolve().parents[2] / "configs"


class DieOptions(BaseModel):
    model_config = ConfigDict(extra="forbid")
    scribe_x_um: float = Field(ge=0)
    scribe_y_um: float = Field(ge=0)
    scribe_source: Source = Source.HYPOTHETICAL
    scribe_reference: str = "hypothetical scribe street (incl. seal ring allowance); no foundry rule supplied"
    rotation_deg: Literal[0, 90] = 0


class MCSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")
    lots: int = Field(1, ge=1)
    wafers_per_lot: int = Field(1, ge=1)
    seed: int = Field(42, ge=0)
    keep_maps: int = Field(4, ge=0)
    workers: int = Field(1, ge=1)
    sample_spacing_um: float = Field(50.0, gt=0)
    max_wafers_in_memory: int = Field(100000, ge=1)


class SimpleRegionSpec(BaseModel):
    """Area-fraction region model for designs without floorplan geometry (e.g. MCU-I)."""

    model_config = ConfigDict(extra="forbid")
    name: str
    kind: Literal["logic", "sram", "io", "whitespace"]
    area_fraction: float = Field(ge=0, le=1)
    source: Source
    reference: str


class Scenario(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str
    description: str = ""
    design: DesignSpec
    wafer: WaferSpec
    die: DieOptions
    reticle: ReticleSpec = Field(default_factory=ReticleSpec)
    layout: LayoutSpec = Field(default_factory=LayoutSpec)
    defects: DefectModel
    fatality: FatalityModel = Field(default_factory=FatalityModel)
    sram: SramModel = Field(default_factory=SramModel)
    tests: TestPlan
    bins: BinTable
    parametric: ParametricModel = Field(default_factory=ParametricModel)
    monte_carlo: MCSettings = Field(default_factory=MCSettings)
    costs: Optional[dict[str, Any]] = None
    process: Optional[dict[str, Any]] = None
    simple_regions: Optional[list[SimpleRegionSpec]] = None

    def digest(self) -> str:
        return hashlib.sha256(json.dumps(self.model_dump(mode="json"), sort_keys=True).encode()).hexdigest()


def load_yaml(path: str | Path) -> Any:
    with open(path) as fh:
        return yaml.safe_load(fh)


def _resolve_path(p: str, base: Path) -> Path:
    for cand in (base / p, CONFIG_ROOT / p):
        if cand.exists():
            return cand.resolve()
    raise FileNotFoundError(f"config include not found: {p} (searched {base} and {CONFIG_ROOT})")


def deep_merge(a: Any, b: Any) -> Any:
    if isinstance(a, dict) and isinstance(b, dict):
        out = dict(a)
        for k, v in b.items():
            out[k] = deep_merge(a.get(k), v) if k in a else copy.deepcopy(v)
        return out
    return copy.deepcopy(b)


def _resolve_section(name: str, value: Any, base: Path) -> Any:
    if isinstance(value, str) and value.endswith((".yaml", ".yml")):
        path = _resolve_path(value, base)
        data = load_yaml(path)
        if isinstance(data, dict) and len(data) == 1 and name in data:
            data = data[name]
        return _resolve_section(name, data, path.parent)
    if isinstance(value, dict) and "include" in value:
        inc = value["include"]
        rest = {k: v for k, v in value.items() if k != "include"}
        return deep_merge(_resolve_section(name, inc, base), rest)
    return value


def set_dotted(d: dict, dotted: str, value: Any) -> None:
    keys = dotted.split(".")
    cur: Any = d
    for k in keys[:-1]:
        cur = cur[int(k)] if isinstance(cur, list) else cur.setdefault(k, {})
    last = keys[-1]
    if isinstance(cur, list):
        cur[int(last)] = value
    else:
        cur[last] = value


def load_scenario_dict(path: str | Path, overrides: Optional[dict[str, Any]] = None) -> dict:
    path = Path(path)
    if not path.exists():
        path = _resolve_path(str(path), Path.cwd())
    raw = load_yaml(path)
    if "scenario" not in raw:
        raise ValueError(f"{path}: top-level key 'scenario' missing")
    scn = dict(raw["scenario"])
    if "extends" in scn:
        parent = load_scenario_dict(_resolve_path(scn.pop("extends"), path.parent))
        scn = deep_merge(parent, {k: _resolve_section(k, v, path.parent) for k, v in scn.items()})
    for k in list(scn):
        scn[k] = _resolve_section(k, scn[k], path.parent)
    for dotted, val in {**(raw.get("overrides") or {}), **(overrides or {})}.items():
        set_dotted(scn, dotted, val)
    return scn


def load_scenario(path: str | Path, overrides: Optional[dict[str, Any]] = None) -> Scenario:
    return Scenario(**load_scenario_dict(path, overrides))
