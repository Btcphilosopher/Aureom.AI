"""Reproducible run directories and Markdown engineering reports.

``run_scenario`` executes geometry + Monte Carlo + statistics (+ costs) and
writes everything needed to audit and regenerate the result::

    reports/<run_id>/
      scenario.resolved.yaml   exact inputs after includes / overrides
      meta.json                seed, RNG scheme, software versions, timings, scenario sha256
      wafers.csv               one row per simulated wafer (all counts)
      summary.json             statistics, CI / PI, convergence, region breakdown, provenance table
      geometry.json            site counts, approximations, area accounting
      model_comparison.json    analytical vs Monte Carlo yield models
      costs.json               stage accounting (if a cost file is given)
      maps/wafer_<lot>_<wafer>.json   full die / defect maps of the kept wafers
      layout/wafer_layout.{json,svg,png}
      figures/*.png
      report.md
      run.log

The run id is derived from the scenario hash and the sampling settings, so the
same inputs always map to the same directory.
"""
from __future__ import annotations

import json
import logging
import math
import time
from pathlib import Path
from typing import Optional

import numpy as np
import yaml

from . import plots, statistics as st, yield_models as ym
from .analysis import cost_analysis, geometry_analysis, model_comparison, summarise
from .config import Scenario, load_scenario
from .monte_carlo import run_simulation

log = logging.getLogger("yieldlab")
REPORTS = Path(__file__).resolve().parents[2] / "reports"


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, tuple):
        return list(o)
    return str(o)


def dump(obj, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=1, default=_json_default))
    return path


def run_id(scn: Scenario, lots: int, wpl: int) -> str:
    return f"{scn.name}__seed{scn.monte_carlo.seed}__{lots}x{wpl}__{scn.digest()[:10]}"


def run_scenario(config: str | Path, lots: Optional[int] = None, wafers_per_lot: Optional[int] = None,
                 seed: Optional[int] = None, workers: Optional[int] = None, costs: Optional[str | Path] = None,
                 out_root: Path = REPORTS, overrides: Optional[dict] = None, figures: bool = True) -> Path:
    ov = dict(overrides or {})
    if seed is not None:
        ov["monte_carlo.seed"] = seed
    scn = load_scenario(config, ov)
    lots = lots or scn.monte_carlo.lots
    wpl = wafers_per_lot or scn.monte_carlo.wafers_per_lot
    if costs:
        from .config import load_yaml

        scn = scn.model_copy(update={"costs": load_yaml(costs)["costs"]})
    rid = run_id(scn, lots, wpl)
    out = Path(out_root) / rid
    out.mkdir(parents=True, exist_ok=True)
    fh = logging.FileHandler(out / "run.log", mode="w")
    fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    log.addHandler(fh)
    log.setLevel(logging.INFO)
    try:
        t0 = time.time()
        log.info("scenario %s (sha256 %s) lots=%d wafers/lot=%d seed=%d", scn.name, scn.digest(), lots, wpl,
                 scn.monte_carlo.seed)
        (out / "scenario.resolved.yaml").write_text(yaml.safe_dump(scn.model_dump(mode="json"), sort_keys=False))
        geo = geometry_analysis(scn)
        dump(geo, out / "geometry.json")
        log.info("geometry: %s eligible, counts %s", geo["eligible"], geo["site_counts"])
        sim = run_simulation(scn, lots=lots, wafers_per_lot=wpl, workers=workers)
        log.info("monte carlo: %d wafers in %.1f s", len(sim.wafers), sim.meta["seconds"])
        sim.wafers.to_csv(out / "wafers.csv", index=False)
        summ = summarise(sim)
        dump(summ, out / "summary.json")
        dump(sim.meta, out / "meta.json")
        eff = summ["effective_density"]
        alpha = scn.defects.variation.alpha_wafer or 3.0
        mc = model_comparison(sim.runtime.die.area_cm2, max(eff["poisson_equivalent_d0_per_cm2"], 1e-6), alpha,
                              np.random.default_rng(scn.monte_carlo.seed))
        dump(mc, out / "model_comparison.json")
        for (l, w), payload in sim.maps.items():
            dump(payload, out / "maps" / f"wafer_{l}_{w}.json")
        if scn.costs:
            ca = cost_analysis(sim, scn.costs)
            dump(ca, out / "costs.json")
        wm = sim.runtime.wmap
        plots.wafer_json(wm, out / "layout" / "wafer_layout.json", {"scenario": scn.name, "label": "SIMULATED LAYOUT"})
        plots.wafer_svg(wm, out / "layout" / "wafer_layout.svg", label="SIMULATED LAYOUT")
        if figures:
            make_figures(out, sim, summ, mc, geo)
        (out / "report.md").write_text(markdown_report(out))
        log.info("done in %.1f s -> %s", time.time() - t0, out)
    finally:
        log.removeHandler(fh)
        fh.close()
    return out


def make_figures(out: Path, sim, summ: dict, mc: dict, geo: dict) -> None:
    f = out / "figures"
    label = summ["label"].split(" (")[0]
    wm = sim.runtime.wmap
    plots.wafer_map(wm, f / "wafer_geometry.png", "geometry", title="Die placement and site classes", label="SIMULATED LAYOUT")
    if sim.maps:
        key = sorted(sim.maps)[0]
        p = sim.maps[key]
        plots.wafer_map(wm, f / "wafer_defects.png", "defects", p, f"Wafer {key}: synthetic defects per die", label)
        plots.wafer_map(wm, f / "wafer_outcomes.png", "outcome", p, f"Wafer {key}: test outcome classes", label)
        plots.wafer_map(wm, f / "wafer_bins.png", "bins", p, f"Wafer {key}: probe bins", label)
    df = st.add_derived(sim.wafers)
    row = next(r for r in summ["summary"] if r["metric"] == "outcome_TRUE_GOOD_PASS")
    plots.histogram_with_intervals(df["outcome_TRUE_GOOD_PASS"], f / "good_die_distribution.png",
                                   "True good dies per wafer", "true good dies (TRUE_GOOD_PASS)",
                                   row["ci95_mean"], row["pi90_next_wafer"], label)
    plots.lot_boxplot(df, "outcome_TRUE_GOOD_PASS", f / "lot_distribution.png", "True good dies per wafer by lot", label)
    c = summ["convergence"]["outcome_TRUE_GOOD_PASS"]
    plots.convergence_plot({**c, "running_mean": summ["running_means"]["outcome_TRUE_GOOD_PASS"]},
                           f / "convergence.png", "Monte Carlo convergence of mean true good dies", label)
    rb = [r for r in summ["region_breakdown"] if r["dies_with_fatal_defect_in_region"] > 0]
    if rb:
        plots.hbar([r["region"] for r in rb], [100 * r["yield_loss_fraction"] for r in rb], f / "region_loss.png",
                   "Yield loss by functional region (dies with a fatal defect in the region)",
                   "% of eligible dies", label)
    area = sim.runtime.die.area_cm2
    d0 = mc["d0_per_cm2"]
    grid = ym.comparison_table(np.linspace(0.01, 1.0, 60), d0, mc["alpha"])
    plots.yield_vs_area(grid, f / "yield_models.png", round(d0, 3), mc["alpha"], area)
    wf = summ["waterfall"]
    plots.hbar([w["step"] for w in wf], [abs(w["dies_per_wafer"]) for w in wf], f / "loss_waterfall.png",
               "Mean dies per wafer through the flow", "dies per wafer", label, color=plots.SERIES[4])
    maps = list(sim.maps.values())
    if maps and maps[0]["params"]:
        fm = np.concatenate([np.asarray(m["params"]["fmax_mhz"], float) for m in maps])
        lk = np.concatenate([np.asarray(m["params"]["leakage_ua"], float) for m in maps])
        ok = np.isfinite(fm)
        sc = sim.scenario.parametric
        spec_f = sc.by_name("fmax_mhz").spec_min
        spec_l = sc.by_name("leakage_ua").spec_max
        good = (fm >= spec_f) & (lk <= spec_l)
        plots.param_scatter(fm[ok], lk[ok], good[ok], f / "parametric.png", spec_f, spec_l, "SIMULATED - HYPOTHETICAL")


def _fmt(v, nd=1):
    if v is None:
        return "n/a"
    if isinstance(v, (list, tuple)):
        return "[" + ", ".join(_fmt(x, nd) for x in v) + "]"
    if isinstance(v, float):
        if not math.isfinite(v):
            return "n/a"
        return f"{v:,.{nd}f}" if abs(v) >= 1 or v == 0 else f"{v:.4g}"
    return str(v)


def markdown_report(run_dir: Path) -> str:
    run_dir = Path(run_dir)
    S = json.loads((run_dir / "summary.json").read_text())
    G = json.loads((run_dir / "geometry.json").read_text())
    M = json.loads((run_dir / "model_comparison.json").read_text())
    meta = S["meta"]
    lines = [f"# SilicaFlux YieldLab run `{run_dir.name}`", "",
             f"> **{S['label']}**  ", "> Synthetic wafer maps and yields - NOT measured foundry data. "
             "Passing these checks does not establish manufacturability or commercial yield.", "",
             "## Reproducibility", "",
             f"* scenario `{meta['scenario']}` sha256 `{meta['scenario_sha256']}`",
             f"* seed {meta['seed']}, {meta['lots']} lots x {meta['wafers_per_lot']} wafers = {meta['wafers']} wafers; "
             f"{meta['workers']} worker(s); {meta['seconds']} s",
             f"* RNG: {meta['rng']}",
             f"* software: " + ", ".join(f"{k} {v}" for k, v in meta["versions"].items() if k != "platform"),
             f"* repair: {meta['repair']}; fatality model: {meta['fatality_mode']}; defect model: "
             f"{meta['defect_model']} ({meta['density_kind']})", "",
             "## Die and wafer geometry", "",
             f"* die {G['die_um'][0]:.2f} x {G['die_um'][1]:.2f} um = {G['die_area_mm2']:.3f} mm^2 "
             f"({G['die_source']}: {G['die_reference']})",
             f"* pitch {G['pitch_mm'][0]:.4f} x {G['pitch_mm'][1]:.4f} mm, footprint convention `{G['footprint_convention']}`",
             f"* wafer {G['wafer']['diameter_mm']} mm, edge exclusion {G['wafer']['edge_exclusion_mm']} mm "
             f"({G['wafer']['edge_exclusion_source']})", "",
             "| site class | count |", "|---|---|"]
    lines += [f"| {k} | {v} |" for k, v in G["site_counts"].items()]
    lines += ["", f"**Eligible (FULL DIE) sites: {G['eligible']}**"
              + (f"; dies per reticle field {G['dies_per_reticle_field']}" if G.get("dies_per_reticle_field") else ""), "",
              "| method | value | geometry count | difference |", "|---|---|---|---|"]
    for r in G["approximations"]:
        lines.append(f"| {r['method']} ({r['kind']}) | {r['value']:.1f} | {r['geometry_count']} | "
                     f"{r['difference']:+.1f} ({100 * r['relative_difference']:+.2f} %) |")
    acc = G["area_accounting"]
    lines += ["", f"Geometric loss: {100 * acc['geometric_loss_fraction']:.1f} % of the wafer area is not eligible die "
                  f"silicon (edge band + notch {acc['edge_exclusion_and_notch_area_mm2']:.0f} mm^2, streets "
                  f"{acc['eligible_die_street_area_mm2']:.0f} mm^2, boundary cells "
                  f"{acc['usable_area_not_in_full_sites_mm2']:.0f} mm^2).",
              f"Footprint-convention sensitivity: {G['footprint_sensitivity']}."]
    if "optimised_grid_offset" in G:
        o = G["optimised_grid_offset"]
        lines.append(f"Best grid translation found: ({o['offset_x_mm']:.3f}, {o['offset_y_mm']:.3f}) mm -> "
                     f"{o['full_dies']} full dies ({o['gain_vs_configured']:+d} vs configured).")
    lines += ["", "## Yield definitions (every denominator explicit)", "", "| metric | numerator / denominator |", "|---|---|"]
    lines += [f"| {k} | {v['definition']} |" for k, v in S["yield_definitions"].items()]
    lines += ["", "## Results per wafer", "",
              "CI = 95 % confidence interval of the *expected* value (lot-cluster t on lot means). "
              "PI = 90 % predictive interval for *one future wafer* / lot total. They are not interchangeable.", "",
              "| metric | mean | sd | P5 | P50 | P95 | 95 % CI (mean) | naive iid CI | ICC(lot) | 90 % PI next wafer |",
              "|---|---|---|---|---|---|---|---|---|---|"]
    for r in S["summary"]:
        lines.append(f"| {r['metric']} | {_fmt(r['mean'], 2)} | {_fmt(r['sd'], 2)} | {_fmt(r['p5'], 2)} | "
                     f"{_fmt(r['p50'], 2)} | {_fmt(r['p95'], 2)} | {_fmt(r['ci95_mean'], 2)} | "
                     f"{_fmt(r['ci95_naive_wafer_iid'], 2)} | {_fmt(r['icc_lot'], 3)} | {_fmt(r['pi90_next_wafer'], 1)} |")
    p = S["probability_target_true_good_per_wafer"]
    lines += ["", f"P(true good dies per wafer >= {p['target']:.0f}) = {p['p']:.3f} (Wilson 95 % {_fmt(p['wilson95'], 3)}).", ""]
    lines += ["### Monte Carlo convergence", "", "| quantity | n | MCSE | relative MCSE | status |", "|---|---|---|---|---|"]
    for k, c in S["convergence"].items():
        lines.append(f"| {k} | {c['n']} | {c['mcse']:.3f} | {c['relative_mcse']:.4f} | {c['status']} |")
    e = S["effective_density"]
    lines += ["", f"Simulated defect-limited yield {e['simulated_defect_limited_yield']:.4f}; Poisson-equivalent D0 "
                  f"{e['poisson_equivalent_d0_per_cm2']:.4f} /cm^2; wafer-yield sd {e['wafer_yield_sd']:.4f} vs "
                  f"{e['binomial_sd_if_poisson']:.4f} if dies were independent (Poisson).", "",
              "## Yield-model comparison at the simulated mean density", "",
              "| model | assumption | analytical | Monte Carlo (+/- SE) |", "|---|---|---|---|"]
    for r in M["rows"]:
        if r["analytical_yield"] is None:
            lines.append(f"| {r['model']} | {r['assumption']} | {r.get('status', 'n/a')} | |")
        else:
            lines.append(f"| {r['model']} | {r['assumption']} | {r['analytical_yield']:.5f} | "
                         f"{r['monte_carlo_yield']:.5f} +/- {r['mc_standard_error']:.5f} |")
    lines += ["", "## Yield loss by functional region", "",
              "| region | area mm^2 | % of die | % dies lost | sole-cause dies (all wafers) | escapes (all wafers) | detected by | coverage source |",
              "|---|---|---|---|---|---|---|---|"]
    for r in S["region_breakdown"]:
        lines.append(f"| {r['region']} | {r['located_area_mm2']:.3f} | {100 * r['area_fraction']:.1f} | "
                     f"{100 * r['yield_loss_fraction']:.3f} | {r['sole_cause_dies']} | "
                     f"{r['escaped_dies_with_fault_in_region']} | {r['detected_by']} | {r['coverage_source']} |")
    lines += ["", "## Flow (mean dies per wafer)", "", "| step | dies / wafer |", "|---|---|"]
    lines += [f"| {w['step']} | {w['dies_per_wafer']:.1f} |" for w in S["waterfall"]]
    cpath = run_dir / "costs.json"
    if cpath.exists():
        C = json.loads(cpath.read_text())
        fw = C.get("full_wafer", {})
        lines += ["", "## Economics", ""]
        if "total_cost" in fw:
            lines += [f"**{fw['label']}**", "", "| stage | in | out | cost |", "|---|---|---|---|"]
            lines += [f"| {s['stage']} | {s['in']:.0f} | {s['out']:.0f} | {s['cost']:,.0f} {fw['currency']} |"
                      for s in fw["stages"]]
            lines += ["", f"* cost per delivered CONFORMING die: **{fw['cost_per_delivered_conforming_die']:.3f} "
                          f"{fw['currency']}** ({fw['nre_rule']})",
                      f"* escapes delivered: {fw['quality_risk']['delivered_escapes']:.0f} "
                      f"({fw['quality_risk']['escape_dppm']:.0f} DPPM) - excluded from the denominator"]
            pw = C.get("per_wafer_recurring_cost_per_conforming_die")
            if pw:
                lines.append(f"* recurring cost per conforming die, per wafer: mean {pw['mean']:.3f}, "
                             f"90 % PI {_fmt(pw['pi90'], 3)}")
        else:
            lines.append(f"Full-wafer cost: {fw.get('status')} - {fw.get('reason')}")
        if "mpw" in C and "total_cost" in C["mpw"]:
            m = C["mpw"]
            lines.append(f"* MPW: {m['total_cost']:,.0f} {m['currency']} for {m['packaged']} packaged prototypes, "
                         f"{m['expected_good_prototypes']:.1f} expected good -> {m['cost_per_good_prototype']:,.0f} "
                         f"per good prototype ({m['label']})")
        if "first_silicon" in C and "scenarios" in C["first_silicon"]:
            fs = C["first_silicon"]
            lines.append("* first silicon (" + fs["measure"] + "): " + "; ".join(
                f"{r['respins']} re-spin(s): {r['program_cost']:,.0f} -> {r['cost_per_usable_prototype']:,.0f} per usable"
                for r in fs["scenarios"]))
    lines += ["", "## Input provenance", "", "| input | value | source | reference |", "|---|---|---|---|"]
    for r in S["inputs"]:
        lines.append(f"| {r['input']} | {str(r['value'])[:60]} | {r['source']} | {r['reference'][:140]} |")
    lines += ["", "## Figures", ""]
    for p in sorted((run_dir / "figures").glob("*.png")):
        lines.append(f"![{p.stem}](figures/{p.name})")
    return "\n".join(lines) + "\n"
