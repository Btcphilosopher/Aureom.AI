"""Self-contained interactive engineering dashboard (single HTML file, works offline).

Built only from files of a run directory plus the study JSONs in
``reports/studies`` -- nothing is computed in the browser except presentation.
Plotly.js is embedded from the installed ``plotly`` Python package.

Labelling: every view shows the run's data label.  Simulated runs carry a
persistent SIMULATED banner; the VERIFIED IMPORTED DATA label can only come
from imports.py after validation and is never produced for a simulation.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import pandas as pd

from .report import _json_default

VIEWS = [
    ("geometry", "1 Wafer geometry"), ("placement", "2 Die placement"), ("defects", "3 Defect map"),
    ("clusters", "4 Spatial clustering"), ("functional", "5 Functional yield"), ("mbist", "6 MBIST & scan detection"),
    ("bins", "7 Wafer probe & bins"), ("mc", "8 Multi-wafer Monte Carlo"), ("lots", "9 Lot yield distribution"),
    ("models", "10 Yield-model comparison"), ("area", "11 Area vs yield"), ("cost", "12 Cost per known-good die"),
    ("nodes", "13 Process-node comparison"), ("repair", "14 Redundancy & repair"), ("param", "15 Parametric yield"),
    ("mpw", "16 MPW / first-silicon economics"), ("sens", "17 Sensitivity analysis"), ("pareto", "18 Pareto optimisation"),
    ("prov", "19 Input provenance"), ("reports", "20 Engineering reports"),
]


def _load(p: Path):
    return json.loads(p.read_text()) if p.exists() else None


def build(run_dir: Path, studies: Path, out: Optional[Path] = None, max_maps: int = 6) -> Path:
    run_dir = Path(run_dir)
    S = _load(run_dir / "summary.json")
    if S is None:
        raise FileNotFoundError(f"{run_dir}/summary.json missing - run `python -m yieldlab simulate` first")
    wafers = pd.read_csv(run_dir / "wafers.csv")
    maps = {}
    for p in sorted((run_dir / "maps").glob("wafer_*.json"))[:max_maps]:
        maps[p.stem.replace("wafer_", "")] = _load(p)
    layout = _load(run_dir / "layout" / "wafer_layout.json")
    data = {
        "run": run_dir.name, "label": S["label"], "meta": S["meta"],
        "geometry": _load(run_dir / "geometry.json"),
        "summary": {k: v for k, v in S.items() if k not in ("meta",)},
        "wafers": wafers.to_dict("records"),
        "maps": maps, "layout": layout,
        "model_comparison": _load(run_dir / "model_comparison.json"),
        "costs": _load(run_dir / "costs.json"),
        "scenario_yaml": (run_dir / "scenario.resolved.yaml").read_text(),
        "report_md": (run_dir / "report.md").read_text() if (run_dir / "report.md").exists() else "",
        "gates": _load(run_dir / "gates.json"),
        "studies": {p.stem: _load(p) for p in sorted(Path(studies).glob("*.json"))} if Path(studies).exists() else {},
        "views": VIEWS,
    }
    from plotly.offline import get_plotlyjs

    html = TEMPLATE.replace("/*__PLOTLY__*/", get_plotlyjs()).replace(
        "/*__DATA__*/", json.dumps(data, default=_json_default, separators=(",", ":")).replace("</", "<\\/"))
    out = out or run_dir / "dashboard.html"
    out.write_text(html)
    return out


TEMPLATE = r"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SilicaFlux YieldLab</title>
<style>
:root{--navy:#0c1528;--panel:#111d36;--panel2:#16244a;--grid:#22314f;--ink:#eef2fa;--ink2:#a9b4cc;--muted:#6b7a99;
--gold:#d4af37;--cyan:#1ba3c6;--gold-d:#b5841a;--violet:#8b78e8;--coral:#d65f45;--blue:#5b7ff0;--magenta:#c9559a;
--good:#3fb27f;--warn:#e3b341;--serious:#e8833a;--crit:#e5484d;--neutral:#4a5878}
*{box-sizing:border-box}html,body{margin:0;background:var(--navy);color:var(--ink);
font:13px/1.45 "Inter","Segoe UI",system-ui,sans-serif}
body{background-image:linear-gradient(var(--grid) 1px,transparent 1px),linear-gradient(90deg,var(--grid) 1px,transparent 1px);
background-size:48px 48px;background-attachment:fixed}
header{position:sticky;top:0;z-index:5;display:flex;align-items:center;gap:16px;padding:10px 18px;
background:rgba(12,21,40,.96);border-bottom:1px solid var(--grid)}
header h1{font-size:16px;margin:0;color:var(--gold);letter-spacing:.06em;font-weight:600}
header .sub{color:var(--ink2);font-size:12px}
.badge{margin-left:auto;border:1px solid var(--gold);color:var(--gold);padding:4px 10px;border-radius:4px;
font:600 11px/1 ui-monospace,monospace;letter-spacing:.05em;white-space:nowrap}
.wrap{display:flex;min-height:calc(100vh - 50px)}
nav{width:236px;flex:none;padding:10px 8px;border-right:1px solid var(--grid);background:rgba(12,21,40,.85)}
nav button{display:block;width:100%;text-align:left;background:none;border:0;color:var(--ink2);padding:6px 10px;
border-radius:4px;font:inherit;cursor:pointer}
nav button:hover{background:var(--panel)}nav button.on{background:var(--panel2);color:var(--ink);box-shadow:inset 2px 0 var(--cyan)}
main{flex:1;min-width:0;padding:16px 20px 60px}
h2{font-size:15px;margin:0 0 4px;color:var(--ink)}h3{font-size:13px;margin:16px 0 6px;color:var(--gold)}
.note{color:var(--ink2);font-size:12px;max-width:1100px}.warn{color:var(--warn)}
.card{background:rgba(17,29,54,.92);border:1px solid var(--grid);border-radius:6px;padding:12px 14px;margin:10px 0}
.grid2{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(0,1fr);gap:12px}
.grid3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
@media (max-width:1100px){.grid2,.grid3{grid-template-columns:1fr}nav{width:180px}}
@media (max-width:700px){.wrap{flex-direction:column}nav{width:100%;display:flex;overflow-x:auto}nav button{white-space:nowrap}}
.tile .v{font-size:22px;font-weight:600;color:var(--ink)}.tile .k{color:var(--ink2);font-size:11px;text-transform:uppercase;letter-spacing:.06em}
table{border-collapse:collapse;width:100%;font-size:12px}th,td{border-bottom:1px solid var(--grid);padding:4px 6px;
text-align:left;vertical-align:top}th{color:var(--ink2);font-weight:500;position:sticky;top:0;background:var(--panel)}
td.num{text-align:right;font-variant-numeric:tabular-nums}.scroll{max-height:460px;overflow:auto}
.src{font:600 10px/1 ui-monospace,monospace;padding:2px 5px;border-radius:3px;border:1px solid var(--grid);white-space:nowrap}
.src.MEASURED_TOOL_OUTPUT{color:var(--good);border-color:var(--good)}.src.HYPOTHETICAL{color:var(--warn);border-color:var(--warn)}
.src.NOT_AVAILABLE{color:var(--crit);border-color:var(--crit)}.src.PLANNING_ESTIMATE,.src.DOCUMENT_CITED_UNVERIFIED{color:var(--serious);border-color:var(--serious)}
.src.STANDARD_REFERENCE,.src.DESIGN_INPUT,.src.DERIVED{color:var(--cyan);border-color:var(--cyan)}
select,input{background:var(--panel2);color:var(--ink);border:1px solid var(--grid);border-radius:4px;padding:3px 6px;font:inherit}
.toolbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:6px 0}
.wafer{position:relative;background:#0b1325;border:1px solid var(--grid);border-radius:6px}
.wafer svg{width:100%;height:auto;display:block;cursor:grab}
.wm{position:absolute;right:10px;bottom:8px;color:var(--gold);font:600 11px ui-monospace,monospace;border:1px solid var(--gold);
padding:2px 6px;border-radius:3px;background:var(--navy);pointer-events:none}
.legend{display:flex;flex-wrap:wrap;gap:10px;margin:6px 0;color:var(--ink2);font-size:11px}
.legend i{display:inline-block;width:11px;height:11px;border-radius:2px;margin-right:4px;vertical-align:-1px}
.gallery{display:flex;gap:8px;flex-wrap:wrap}.gallery button{background:var(--panel2);border:1px solid var(--grid);color:var(--ink2);
border-radius:4px;padding:4px;cursor:pointer;font:11px ui-monospace,monospace}.gallery button.on{border-color:var(--cyan);color:var(--ink)}
.gallery svg{width:92px;height:92px;display:block}
.kv{display:grid;grid-template-columns:150px 1fr;gap:3px 10px;font-size:12px}.kv div:nth-child(odd){color:var(--ink2)}
.plot{width:100%;height:380px}.plot.tall{height:480px}pre{white-space:pre-wrap;color:var(--ink2);font-size:11px}
.md table{margin:6px 0}.md h1{font-size:16px;color:var(--gold)}.md h2{margin-top:18px}.md blockquote{border-left:3px solid var(--gold);margin:6px 0;padding:2px 10px;color:var(--gold)}
.md img{max-width:100%;border:1px solid var(--grid);border-radius:4px}.pill{padding:1px 6px;border-radius:3px;font-size:11px}
</style></head><body>
<header><h1>SILICAFLUX YIELDLAB</h1><span class="sub" id="hsub"></span><span class="badge" id="badge"></span></header>
<div class="wrap"><nav id="nav"></nav><main id="main"></main></div>
<script>/*__PLOTLY__*/</script>
<script>
const D=/*__DATA__*/;
const C={navy:'#0c1528',panel:'#111d36',grid:'#22314f',ink:'#eef2fa',ink2:'#a9b4cc',muted:'#6b7a99',gold:'#d4af37',
 s:['#1ba3c6','#b5841a','#8b78e8','#d65f45','#5b7ff0','#c9559a'],good:'#3fb27f',warn:'#e3b341',serious:'#e8833a',crit:'#e5484d',neutral:'#4a5878'};
const LBL=D.label.startsWith('SIMULATED')?'SIMULATED':D.label;
document.getElementById('badge').textContent=D.label.split(' (')[0]+' - NOT MEASURED FOUNDRY DATA';
document.getElementById('hsub').textContent=`run ${D.run}  |  ${D.meta.wafers} wafers, seed ${D.meta.seed}`;
const $=s=>document.querySelector(s);const fmt=(v,d=2)=>v==null||!isFinite(v)?'n/a':(Number.isInteger(v)||Math.abs(v)>=1000?v.toLocaleString(undefined,{maximumFractionDigits:0}):(+v).toFixed(d));
const esc=s=>String(s??'').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
const src=s=>`<span class="src ${esc(s)}">${esc(s)}</span>`;
function L(extra={}){return Object.assign({paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:C.panel,font:{color:C.ink2,size:11,family:'Inter,system-ui,sans-serif'},
 margin:{l:56,r:16,t:30,b:44},xaxis:{gridcolor:C.grid,zerolinecolor:C.grid,linecolor:C.grid},yaxis:{gridcolor:C.grid,zerolinecolor:C.grid,linecolor:C.grid},
 legend:{orientation:'h',y:-0.2,font:{size:10}},hoverlabel:{bgcolor:C.navy,bordercolor:C.gold,font:{color:C.ink}},
 annotations:[{text:LBL,xref:'paper',yref:'paper',x:1,y:1.06,showarrow:false,font:{color:C.gold,size:10,family:'monospace'}}]},extra)}
function P(id,traces,lay){Plotly.newPlot(id,traces,L(lay),{displaylogo:false,responsive:true})}
function table(rows,cols,opts={}){if(!rows||!rows.length)return '<p class="note">no data</p>';cols=cols||Object.keys(rows[0]);
 return `<div class="scroll"><table><thead><tr>${cols.map(c=>`<th>${esc(c)}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${cols.map(c=>{
 let v=r[c];if(opts.src&&c===opts.src)return `<td>${src(v)}</td>`;if(typeof v==='number')return `<td class="num">${fmt(v,opts.d??3)}</td>`;
 if(Array.isArray(v))v=v.map(x=>typeof x==='number'?fmt(x,2):x).join(', ');return `<td>${esc(typeof v==='object'&&v?JSON.stringify(v):v)}</td>`}).join('')}</tr>`).join('')}</tbody></table></div>`}
const missing=name=>`<div class="card note warn">Study <b>${name}</b> not generated for this dashboard. Run <code>make yieldlab-sweep</code> / <code>make yieldlab-report</code> and rebuild.</div>`;
const W=D.wafers, SUM=D.summary, G=D.geometry, ST=D.studies||{};
function metric(m){return SUM.summary.find(r=>r.metric===m)}
/* ------------------------------------------------------------------ wafer viewer */
const SITE_COL=['#1ba3c6','#2a3754','#3c4a68','#1a2440','#8b78e8'],SITE_NAME=['FULL DIE','PARTIAL / EDGE-STRADDLING','EDGE-EXCLUDED','UNPRINTABLE','VALID TEST SITE'];
const OUT_COL={'-1':'#2a3754',0:C.neutral,1:C.good,2:C.warn,3:C.serious,4:C.crit,5:'#ff8fa3'};
const OUT_NAME={'-1':'not eligible',0:'untested',1:'true good (pass)',2:'conditional (hypothetical repair)',3:'good rejected',4:'defective detected',5:'defective ESCAPED'};
const SEQ=['#0f2a3d','#114a63','#13708f','#1ba3c6','#6fd0e6','#c4eef7'];
const LAYERS=['GEOMETRY','RANDOM DEFECTS','CLUSTERED DEFECTS','FUNCTIONAL FAILURES','MBIST RESULTS','PARAMETRIC BINS','SELLABLE DIE','COST IMPACT'];
const MAPKEYS=Object.keys(D.maps);
let viewer={map:MAPKEYS[0],layer:'GEOMETRY',sel:null,vb:null,fields:false};
const sites=D.layout.sites;
function bbox(i){return sites[i].die_bbox_mm}
function dieColor(i,m,layer){const s=m&&m.sites;const cls=['FULL DIE','PARTIAL / EDGE-STRADDLING','EDGE-EXCLUDED','UNPRINTABLE','VALID TEST SITE'].indexOf(sites[i].site_class);
 if(layer==='GEOMETRY'||!s)return SITE_COL[cls];if(!sites[i].eligible)return '#1a2440';
 if(layer==='RANDOM DEFECTS'||layer==='CLUSTERED DEFECTS'){const n=s.defect_events[i];return SEQ[Math.min(n,SEQ.length-1)]}
 if(layer==='FUNCTIONAL FAILURES')return s.functional_fail[i]?C.crit:(s.conditional_repair[i]?C.warn:C.good);
 if(layer==='MBIST RESULTS'){if(!s.sram_fault[i])return '#203054';return s.first_fail_step[i]==='mbist'?C.serious:(s.outcome[i]===5?'#ff8fa3':C.s[2])}
 if(layer==='PARAMETRIC BINS'){if(!s.param_ok[i])return C.crit;const g=s.speed_grade[i];return g==='A'?C.good:(g?C.s[2]:C.neutral)}
 if(layer==='SELLABLE DIE')return s.delivered_conforming[i]?C.good:(s.delivered[i]?'#ff8fa3':'#203054');
 if(layer==='COST IMPACT'){const o=s.outcome[i];if(o===1||o===2)return s.delivered[i]?C.good:C.serious;if(o===5)return '#ff8fa3';return s.first_fail_step[i]?C.crit:C.neutral}
 return SITE_COL[cls]}
function layerLegend(layer){const L={'GEOMETRY':SITE_NAME.map((n,k)=>[SITE_COL[k],`${n} (${G.site_counts[n]})`]),
 'RANDOM DEFECTS':SEQ.map((c,k)=>[c,`${k}${k==5?'+':''} defect events`]),'CLUSTERED DEFECTS':[[C.s[3],'points: cluster generator'],[C.ink,'points: other generators'],[SEQ[3],'die defect count']],
 'FUNCTIONAL FAILURES':[[C.good,'functional'],[C.crit,'functional failure'],[C.warn,'functional only via hypothetical repair']],
 'MBIST RESULTS':[[C.serious,'SRAM fault - failed MBIST'],['#ff8fa3','SRAM fault - escaped'],[C.s[2],'SRAM fault - failed another step first'],['#203054','no SRAM fault']],
 'PARAMETRIC BINS':[[C.good,'grade A (>= 50 MHz)'],[C.crit,'out of spec (true value)'],[C.neutral,'no grade']],
 'SELLABLE DIE':[[C.good,'delivered conforming'],['#ff8fa3','delivered ESCAPE (quality risk)'],['#203054','not delivered']],
 'COST IMPACT':[[C.good,'cost recovered (delivered)'],[C.crit,'lost at probe: wafer + probe cost sunk'],[C.serious,'lost after packaging: + package + final test sunk'],['#ff8fa3','escape: shipped, quality risk']]}[layer]||[];
 return `<div class="legend">${L.map(([c,t])=>`<span><i style="background:${c}"></i>${esc(t)}</span>`).join('')}</div>`}
function waferSVG(mkey,layer,small){const m=D.maps[mkey];const R=G.wafer.diameter_mm/2;const pad=R*1.04;
 let h=`<svg viewBox="${-pad} ${-pad} ${2*pad} ${2*pad}" ${small?'':'id="wsvg"'} xmlns="http://www.w3.org/2000/svg"><g transform="scale(1,-1)">`;
 h+=`<circle cx="0" cy="0" r="${R}" fill="#0e1a31" stroke="${C.ink2}" stroke-width="${small?1:0.35}"/>`;
 const e=G.wafer.edge_exclusion_mm;h+=`<circle cx="0" cy="0" r="${R-e}" fill="none" stroke="${C.gold}" stroke-width="0.3" stroke-dasharray="1.5 1.5"/>`;
 for(let i=0;i<sites.length;i++){const b=bbox(i);h+=`<rect data-i="${i}" x="${b[0]}" y="${b[1]}" width="${(b[2]-b[0]).toFixed(4)}" height="${(b[3]-b[1]).toFixed(4)}" fill="${dieColor(i,m,layer)}"/>`}
 if(!small&&viewer.fields&&D.geometry.dies_per_reticle_field){const seen={};sites.forEach((s,i)=>{if(!s.reticle_field)return;const k=s.reticle_field.join(',');
   const b=s.footprint_bbox_mm;if(!seen[k])seen[k]=[b[0],b[1],b[2],b[3]];else{const q=seen[k];q[0]=Math.min(q[0],b[0]);q[1]=Math.min(q[1],b[1]);q[2]=Math.max(q[2],b[2]);q[3]=Math.max(q[3],b[3])}});
   for(const q of Object.values(seen))h+=`<rect x="${q[0]}" y="${q[1]}" width="${q[2]-q[0]}" height="${q[3]-q[1]}" fill="none" stroke="${C.gold}" stroke-width="0.25"/>`}
 if(m&&(layer==='RANDOM DEFECTS'||layer==='CLUSTERED DEFECTS')){const d=m.defects;const cg=d.generators.findIndex(g=>/cluster/i.test(g));
   for(let k=0;k<d.x.length;k++){const isC=d.gen[k]===cg;const op=(layer==='CLUSTERED DEFECTS'&&!isC)?0.25:0.9;
     h+=`<circle cx="${d.x[k]}" cy="${d.y[k]}" r="${small?1.2:(isC?0.5:0.35)}" fill="${isC?C.s[3]:C.ink}" opacity="${op}"/>`}
   for(const e2 of d.extended)for(const line of e2.coords)h+=`<polyline points="${line.map(p=>p.join(',')).join(' ')}" fill="none" stroke="${C.s[3]}" stroke-width="${small?1.5:0.4}"/>`}
 if(!small&&viewer.sel!=null){const b=bbox(viewer.sel);h+=`<rect x="${b[0]}" y="${b[1]}" width="${b[2]-b[0]}" height="${b[3]-b[1]}" fill="none" stroke="${C.gold}" stroke-width="0.6"/>`}
 return h+'</g></svg>'}
function dieInfo(i){if(i==null)return '<p class="note">Click a die for details.</p>';const s=sites[i];const m=D.maps[viewer.map];const x=m&&m.sites;
 const fw=(D.costs&&D.costs.full_wafer&&D.costs.full_wafer.inputs)||[];const unit=n=>{const r=fw.find(q=>q.input===n);return r?r.value:'n/a'};
 const rows=[['die index (X, Y)',`(${s.die_ix}, ${s.die_iy})`],['centre (mm)',s.centre_mm.map(v=>v.toFixed(3)).join(', ')],['bbox (mm)',s.die_bbox_mm.map(v=>v.toFixed(3)).join(', ')],
 ['site class',s.site_class],['reticle field / slot',`${s.reticle_field||'-'} / ${s.reticle_slot||'-'}`],['edge distance (mm)',s.edge_distance_mm.toFixed(3)],['eligible',s.eligible]];
 if(x){rows.push(['defect events',x.defect_events[i]],['defect classes',x.defect_classes[i]||'-'],['fatal events',x.fatal_events[i]<0?'-':x.fatal_events[i]],
  ['regions with fatal defect',x.fatal_regions[i]||'-'],['functional status',x.functional_fail[i]<0?'-':(x.functional_fail[i]?'FUNCTIONAL FAILURE':'functional')],
  ['test status (first failing step)',x.first_fail_step[i]||(x.outcome[i]>=0?'passed all probe steps':'-')],['outcome class',OUT_NAME[x.outcome[i]]],['bin',x.bin[i]<0?'-':x.bin[i]],
  ['repair status',x.repaired[i]>0?'repaired (scheme: '+D.meta.repair+')':(x.sram_fault[i]>0?'SRAM fault, not repaired':'-')],
  ['Fmax / leakage',(D.maps[viewer.map].params.fmax_mhz?`${fmt(D.maps[viewer.map].params.fmax_mhz[i],1)} MHz / ${fmt(D.maps[viewer.map].params.leakage_ua[i],1)} uA (HYPOTHETICAL)`:'-')],
  ['speed grade',x.speed_grade[i]||'-'],['delivered',x.delivered[i]<0?'-':(x.delivered_conforming[i]?'yes - conforming':(x.delivered[i]?'yes - ESCAPE (quality risk)':'no'))],
  ['cost metadata',`wafer ${unit('wafer_cost')} / probe ${unit('probe_cost_per_die')} per die / package ${unit('packaging_cost_per_unit')} (HYPOTHETICAL)`]);}
 return `<div class="kv">${rows.map(([k,v])=>`<div>${esc(k)}</div><div>${esc(v)}</div>`).join('')}</div>`}
function renderViewer(el,defLayer){viewer.layer=defLayer||viewer.layer;
 el.innerHTML=`<div class="toolbar"><label>layer <select id="lay">${LAYERS.map(l=>`<option ${l===viewer.layer?'selected':''}>${l}</option>`).join('')}</select></label>
 <label><input type="checkbox" id="flds" ${viewer.fields?'checked':''}> reticle fields</label><button id="zr" class="gallery">reset zoom</button>
 <span class="note">wheel = zoom, drag = pan, click = die details</span></div>
 <div class="grid2"><div><div class="wafer" id="wbox">${waferSVG(viewer.map,viewer.layer)}<span class="wm">${esc(LBL)}</span></div>${layerLegend(viewer.layer)}
 <h3>Wafer gallery (kept maps)</h3><div class="gallery">${MAPKEYS.map(k=>`<button data-k="${k}" class="${k===viewer.map?'on':''}">${waferSVG(k,viewer.layer==='GEOMETRY'?'FUNCTIONAL FAILURES':viewer.layer,true)}lot/wafer ${k.replace('_','/')}</button>`).join('')}</div></div>
 <div class="card"><h3>Die details - wafer ${viewer.map.replace('_','/')}</h3><div id="dinfo">${dieInfo(viewer.sel)}</div></div></div>`;
 const svg=$('#wsvg');const R=G.wafer.diameter_mm/2*1.04;let vb=viewer.vb||[-R,-R,2*R,2*R];const setvb=()=>{svg.setAttribute('viewBox',vb.join(' '));viewer.vb=vb};setvb();
 svg.addEventListener('wheel',ev=>{ev.preventDefault();const r=svg.getBoundingClientRect();const fx=(ev.clientX-r.left)/r.width,fy=(ev.clientY-r.top)/r.height;
  const k=ev.deltaY>0?1.2:1/1.2;const nw=Math.min(vb[2]*k,2*R),nh=Math.min(vb[3]*k,2*R);vb=[vb[0]+(vb[2]-nw)*fx,vb[1]+(vb[3]-nh)*fy,nw,nh];setvb()},{passive:false});
 let drag=null;svg.addEventListener('mousedown',ev=>{drag=[ev.clientX,ev.clientY,vb[0],vb[1],false]});
 window.onmousemove=ev=>{if(!drag)return;const r=svg.getBoundingClientRect();const dx=(ev.clientX-drag[0])/r.width*vb[2],dy=(ev.clientY-drag[1])/r.height*vb[3];
  if(Math.abs(dx)+Math.abs(dy)>0.5)drag[4]=true;vb=[drag[2]-dx,drag[3]-dy,vb[2],vb[3]];setvb()};
 window.onmouseup=ev=>{if(drag&&!drag[4]&&ev.target.dataset&&ev.target.dataset.i!=null){viewer.sel=+ev.target.dataset.i;$('#dinfo').innerHTML=dieInfo(viewer.sel);
   svg.querySelectorAll('.selbox').forEach(n=>n.remove());const b=bbox(viewer.sel);const ns='http://www.w3.org/2000/svg';const r=document.createElementNS(ns,'rect');
   r.setAttribute('class','selbox');r.setAttribute('x',b[0]);r.setAttribute('y',b[1]);r.setAttribute('width',b[2]-b[0]);r.setAttribute('height',b[3]-b[1]);
   r.setAttribute('fill','none');r.setAttribute('stroke',C.gold);r.setAttribute('stroke-width','0.6');svg.querySelector('g').appendChild(r)}drag=null};
 $('#lay').onchange=e=>{viewer.layer=e.target.value;renderViewer(el)};$('#flds').onchange=e=>{viewer.fields=e.target.checked;renderViewer(el)};
 $('#zr').onclick=()=>{viewer.vb=null;renderViewer(el)};el.querySelectorAll('.gallery button[data-k]').forEach(b=>b.onclick=()=>{viewer.map=b.dataset.k;renderViewer(el)})}
/* ------------------------------------------------------------------ views */
const V={};
V.geometry=el=>{el.innerHTML=`<h2>Wafer geometry</h2><p class="note">Exact rectangle-in-region containment (not centre-point). Die ${G.die_um.map(v=>v.toFixed(2)).join(' x ')} um = ${fmt(G.die_area_mm2,3)} mm&sup2; ${src(G.die_source)} ${esc(G.die_reference)}</p>
 <div class="grid3">${[['eligible FULL dies',G.eligible],['gross sites touching wafer',Object.values(G.site_counts).reduce((a,b)=>a+b,0)],['geometric loss of wafer area',fmt(100*G.area_accounting.geometric_loss_fraction,1)+' %']].map(([k,v])=>`<div class="card tile"><div class="k">${k}</div><div class="v">${v}</div></div>`).join('')}</div>
 <div id="vw"></div><div class="grid2"><div class="card"><h3>Gross die: geometry vs approximations</h3>${table(G.approximations,['method','kind','value','geometry_count','difference','relative_difference'])}</div>
 <div class="card"><h3>Area accounting (mm&sup2;)</h3>${table(Object.entries(G.area_accounting).map(([k,v])=>({item:k,value:v})))}</div></div>`;viewer.vb=null;renderViewer($('#vw'),'GEOMETRY')};
V.placement=el=>{viewer.fields=true;el.innerHTML=`<h2>Die placement and reticle fields</h2><p class="note">Pitch ${G.pitch_mm.map(v=>v.toFixed(4)).join(' x ')} mm, footprint convention <b>${esc(G.footprint_convention)}</b>; dies per reticle field ${G.dies_per_reticle_field||'reticle disabled'}.</p>
 <div id="vw"></div><div class="grid2"><div class="card"><h3>Footprint-convention sensitivity (FULL dies)</h3>${table(Object.entries(G.footprint_sensitivity).map(([k,v])=>({footprint:k,full_dies:v})))}</div>
 <div class="card"><h3>Grid translation optimisation</h3>${G.optimised_grid_offset?table([G.optimised_grid_offset]):'not run'}</div></div>`;renderViewer($('#vw'),'GEOMETRY')};
V.defects=el=>{el.innerHTML=`<h2>Defect map (synthetic)</h2><p class="note">Defects are SIMULATED from the configured generators; they are not inspection findings. Select layers below for functional, MBIST, parametric, sellable and cost views.</p><div id="vw"></div>`;renderViewer($('#vw'),'RANDOM DEFECTS')};
V.clusters=el=>{const c=ST.clusters;if(!c){el.innerHTML=missing('clusters');return}
 el.innerHTML=`<h2>Spatial clustering</h2><p class="note">${esc(c.wafers[0]?.caveat)} Label: ${esc(c.label)}.</p><div class="toolbar"><label>wafer <select id="cw">${c.wafers.map((w,k)=>`<option value="${k}">${w.wafer.join('/')}</option>`).join('')}</select></label></div>
 <div class="grid2"><div class="card"><div id="cp" class="plot tall"></div></div><div class="card"><div id="rp" class="plot"></div><div id="ct"></div></div></div>`;
 const draw=k=>{const w=c.wafers[k];const lab=w.cluster_labels;const sizes={};lab.forEach(l=>{if(l>=0)sizes[l]=(sizes[l]||0)+1});const top=Object.entries(sizes).sort((a,b)=>b[1]-a[1]).slice(0,5).map(e=>+e[0]);
  const tr=[];const grp=(name,idx,col,sym)=>tr.push({type:'scattergl',mode:'markers',name,x:idx.map(i=>w.x[i]),y:idx.map(i=>w.y[i]),marker:{color:col,size:5,symbol:sym}});
  grp('noise',lab.map((l,i)=>l<0?i:-1).filter(i=>i>=0),C.muted,'circle');top.forEach((t,j)=>grp(`cluster ${t} (${sizes[t]})`,lab.map((l,i)=>l===t?i:-1).filter(i=>i>=0),C.s[j],'circle'));
  const other=lab.map((l,i)=>l>=0&&!top.includes(l)?i:-1).filter(i=>i>=0);if(other.length)grp('other clusters',other,C.ink2,'diamond');
  const R=G.wafer.diameter_mm/2;P('cp',tr,{title:{text:`DBSCAN clusters (eps ${w.dbscan.parameters.eps_mm} mm)`,font:{size:12,color:C.ink}},xaxis:{range:[-R,R],gridcolor:C.grid,title:'x (mm)'},yaxis:{range:[-R,R],scaleanchor:'x',gridcolor:C.grid,title:'y (mm)'},
   shapes:[{type:'circle',x0:-R,y0:-R,x1:R,y1:R,line:{color:C.ink2,width:1}}]});
  const rp=w.radial_profile;P('rp',[{type:'bar',x:rp.edges_mm.slice(1).map((e,i)=>((rp.edges_mm[i]+e)/2).toFixed(1)),y:rp.density_per_cm2,marker:{color:C.s[0]},name:'density'}],{title:{text:'Radial defect density (equal-area rings)',font:{size:12,color:C.ink}},xaxis:{title:'ring centre radius (mm)',gridcolor:C.grid},yaxis:{title:'defects / cm²',gridcolor:C.grid}});
  $('#ct').innerHTML=`<p><b>Pattern classes:</b> ${w.pattern_classes.map(esc).join(', ')}; edge enrichment ${fmt(rp.edge_enrichment)}; ring ${w.ring?`${fmt(w.ring.ring_inner_mm,1)}-${fmt(w.ring.ring_outer_mm,1)} mm (density ${fmt(w.ring.density,2)} /cm²)`:'none'}; reticle-repeat cells ${(w.reticle_repeat||[]).length}</p>
  <p class="note">True synthetic generators on this wafer: ${w.true_generators.map(esc).join(', ')}</p>${table(w.dbscan.clusters.slice(0,12),['id','size','centroid_mm','radius_mm','extent_mm','elongation','shape'])}`};
 $('#cw').onchange=e=>draw(+e.target.value);draw(0)};
V.functional=el=>{const rb=SUM.region_breakdown;el.innerHTML=`<h2>Functional yield by region</h2><p class="note">Fatality model <b>${esc(D.meta.fatality_mode)}</b>; region attribution from FloorplanLab OpenDB geometry (macros exact; logic by placement-density / group-extent attribution).</p>
 <div class="grid2"><div class="card"><div id="rl" class="plot tall"></div></div><div class="card"><h3>Mean dies per wafer through the flow</h3>${table(SUM.waterfall)}</div></div><div class="card">${table(rb,['region','function','located_area_mm2','area_fraction','dies_with_fatal_defect_in_region','yield_loss_fraction','sole_cause_dies','escaped_dies_with_fault_in_region','redundancy'])}</div>`;
 const r=rb.filter(x=>x.dies_with_fatal_defect_in_region>0).reverse();P('rl',[{type:'bar',orientation:'h',y:r.map(x=>x.region),x:r.map(x=>100*x.yield_loss_fraction),marker:{color:C.s[0]},text:r.map(x=>(100*x.yield_loss_fraction).toFixed(3)+' %'),textposition:'outside',hovertemplate:'%{y}: %{x:.4f} % of eligible dies<extra></extra>'}],
 {title:{text:'% of eligible dies with a fatal defect in the region',font:{size:12,color:C.ink}},margin:{l:130,r:40,t:30,b:40},xaxis:{gridcolor:C.grid}})};
V.mbist=el=>{const cov=SUM.inputs.filter(r=>r.input.startsWith('coverage.'));const rb=SUM.region_breakdown.filter(r=>r.dies_with_fatal_defect_in_region>0);
 el.innerHTML=`<h2>MBIST and logic-test detection</h2><p class="note">Physical defect exists &ne; causes failure &ne; detected &ne; rejected. Escapes are counted as nonconforming, never as good. Scan / ATPG for SilicaFlux-V is <b>NOT AVAILABLE</b> (step disabled).</p>
 <div class="grid2"><div class="card"><div id="dp" class="plot tall"></div></div><div class="card"><h3>Outcome classes (mean per wafer)</h3>${table(['TRUE_GOOD_PASS','CONDITIONAL_GOOD_PASS','GOOD_REJECTED','DEFECTIVE_DETECTED','DEFECTIVE_ESCAPED','UNTESTED'].map(o=>({outcome:o,mean_per_wafer:metric('outcome_'+o)?.mean??W.reduce((a,w)=>a+w['outcome_'+o],0)/W.length})))}</div></div>
 <div class="card"><h3>Coverage inputs and their evidence</h3>${table(cov,['input','value','source','reference'],{src:'source'})}</div>`;
 P('dp',[{type:'bar',name:'detected at probe',y:rb.map(r=>r.region),x:rb.map(r=>r.dies_with_fatal_defect_in_region-r.escaped_dies_with_fault_in_region),orientation:'h',marker:{color:C.s[0]}},
 {type:'bar',name:'escaped probe',y:rb.map(r=>r.region),x:rb.map(r=>r.escaped_dies_with_fault_in_region),orientation:'h',marker:{color:C.s[3]}}],{barmode:'stack',margin:{l:130,r:20,t:30,b:60},title:{text:'Dies with a fatal fault per region: detected vs escaped (all wafers)',font:{size:12,color:C.ink}}})};
V.bins=el=>{const codes=Object.keys(W[0]).filter(k=>k.startsWith('bin_')).map(k=>k.slice(4));const tot=codes.map(c=>({bin:c,total:W.reduce((a,w)=>a+w['bin_'+c],0)}));
 el.innerHTML=`<h2>Wafer probe and bins</h2><p class="note">Bins from <code>configs/bins</code>; first matching bin by priority. BIN 2 / 3 require capabilities that do not exist for SilicaFlux-V and stay empty. Bin 99 is the must-stay-empty fallback.</p>
 <div class="grid2"><div class="card"><div id="bp" class="plot tall"></div></div><div class="card"><h3>Totals over all wafers</h3>${table(tot)}</div></div>`;
 const fail=codes.filter(c=>c!=='1');P('bp',fail.map((c,k)=>({type:'bar',name:'bin '+c,x:W.map((w,i)=>i),y:W.map(w=>w['bin_'+c]),marker:{color:C.s[k%6]}})),{barmode:'stack',title:{text:'Non-BIN-1 dies per wafer',font:{size:12,color:C.ink}},xaxis:{title:'wafer index',gridcolor:C.grid},yaxis:{title:'dies',gridcolor:C.grid}})};
V.mc=el=>{const r=metric('outcome_TRUE_GOOD_PASS');const cv=SUM.convergence;el.innerHTML=`<h2>Multi-wafer Monte Carlo</h2><p class="note">CI = uncertainty of the <b>expected</b> value (lot-cluster). PI = range for <b>one future wafer</b>. Not interchangeable.</p>
 <div class="grid3">${[['mean true good / wafer',fmt(r.mean,1)],['95 % CI of mean',r.ci95_mean.map(v=>fmt(v,1)).join(' - ')],['90 % PI next wafer',r.pi90_next_wafer.map(v=>fmt(v,0)).join(' - ')]].map(([k,v])=>`<div class="card tile"><div class="k">${k}</div><div class="v">${v}</div></div>`).join('')}</div>
 <div class="grid2"><div class="card"><div id="hg" class="plot"></div></div><div class="card"><div id="cvp" class="plot"></div></div></div><div class="card">${table(SUM.summary,['metric','mean','sd','p5','p50','p95','ci95_mean','ci95_naive_wafer_iid','icc_lot','design_effect','pi90_next_wafer'])}</div>
 <div class="card"><h3>Convergence</h3>${table(Object.entries(cv).map(([k,v])=>({quantity:k,...v})),['quantity','n','mean','mcse','relative_mcse','status'])}</div>`;
 const x=W.map(w=>w.outcome_TRUE_GOOD_PASS);P('hg',[{type:'histogram',x,marker:{color:C.s[0],line:{color:C.panel,width:1}},name:'wafers'}],{title:{text:'True good dies per wafer',font:{size:12,color:C.ink}},
 shapes:[{type:'rect',xref:'x',yref:'paper',x0:r.pi90_next_wafer[0],x1:r.pi90_next_wafer[1],y0:0,y1:1,fillcolor:C.s[2],opacity:.12,line:{width:0}},{type:'line',xref:'x',yref:'paper',x0:r.mean,x1:r.mean,y0:0,y1:1,line:{color:C.gold,width:2}}]});
 const rm=SUM.running_means.outcome_TRUE_GOOD_PASS;P('cvp',[{type:'scatter',mode:'lines',y:rm,x:rm.map((_,i)=>i+1),line:{color:C.s[0],width:2},name:'running mean'}],{title:{text:`Running mean - ${cv.outcome_TRUE_GOOD_PASS.status}`,font:{size:12,color:C.ink}},xaxis:{title:'wafers simulated',gridcolor:C.grid}})};
V.lots=el=>{const lots=[...new Set(W.map(w=>w.lot))];const tot=SUM.lot_totals_true_good;el.innerHTML=`<h2>Lot yield distribution</h2><p class="note">Wafers of a lot share the lot-level latent defect multiplier (and parametric lot effect) - they are correlated.</p>
 <div class="grid2"><div class="card"><div id="lb" class="plot tall"></div></div><div class="card"><div id="lt" class="plot"></div><p class="note">ICC(lot) of true good dies: ${fmt(metric('outcome_TRUE_GOOD_PASS').icc_lot,3)}; design effect ${fmt(metric('outcome_TRUE_GOOD_PASS').design_effect,2)}. 90 % PI of a future lot total: ${(metric('outcome_TRUE_GOOD_PASS').pi90_next_lot_total||[]).map(v=>fmt(v,0)).join(' - ')}</p></div></div>`;
 P('lb',lots.map((l,k)=>({type:'box',name:'lot '+l,y:W.filter(w=>w.lot===l).map(w=>w.outcome_TRUE_GOOD_PASS),marker:{color:C.s[0]},line:{color:C.s[0]},boxpoints:'all',jitter:.4,pointpos:0})),{showlegend:false,title:{text:'True good dies per wafer, by lot',font:{size:12,color:C.ink}}});
 P('lt',[{type:'bar',x:tot.map((_,i)=>'lot '+i),y:tot,marker:{color:C.s[4]}}],{title:{text:'Lot totals of true good dies',font:{size:12,color:C.ink}}})};
V.models=el=>{const mc=D.model_comparison;const st=ST.defect_model_comparison;el.innerHTML=`<h2>Yield-model comparison</h2><p class="note">${esc(mc.note)}. Evaluated at the simulation's Poisson-equivalent D0 = ${fmt(mc.d0_per_cm2,4)} /cm² (derived from a HYPOTHETICAL defect scenario).</p>
 <div class="grid2"><div class="card"><div id="ym" class="plot tall"></div></div><div class="card">${table(mc.rows,['model','assumption','analytical_yield','monte_carlo_yield','mc_standard_error','z'],{d:5})}</div></div>${st?`<div class="card"><h3>Paired spatial simulation of defect scenarios</h3>${st.paired.map(p=>table(p.differences,['value','mean_a','mean_b','mean_diff','ci_lot_cluster_t','predictive_interval_wafer_diff_90'])).join('')}</div>`:missing('defect_model_comparison')}`;
 const A=[...Array(60)].map((_,i)=>0.01+i*0.99/59),d=mc.d0_per_cm2,al=mc.alpha;const f={poisson:a=>Math.exp(-a*d),[`NB alpha=${al}`]:a=>Math.pow(1+a*d/al,-al),seeds:a=>1/(1+a*d),murphy:a=>{const x=a*d;return x<1e-9?1:Math.pow((1-Math.exp(-x))/x,2)}};
 P('ym',Object.entries(f).map(([n,fn],k)=>({type:'scatter',mode:'lines',name:n,x:A,y:A.map(fn),line:{color:C.s[k],width:2}})),{title:{text:'P(zero fatal defects) vs effective area',font:{size:12,color:C.ink}},xaxis:{title:'area (cm²)',gridcolor:C.grid},yaxis:{title:'yield',gridcolor:C.grid},
 shapes:[{type:'line',x0:D.meta.die_area_cm2,x1:D.meta.die_area_cm2,yref:'paper',y0:0,y1:1,line:{color:C.gold,dash:'dot'}}]})};
V.area=el=>{const o=ST.optimisation;if(!o){el.innerHTML=missing('optimisation');return}const d0s=[...new Set(o.rows.map(r=>r.d0_per_cm2))];
 el.innerHTML=`<h2>Area versus yield</h2><p class="note">Circles: FloorplanLab runs (MEASURED die, same netlist). Triangles: architecture variants (ESTIMATED die, no RTL). D0 is HYPOTHETICAL.</p><div class="toolbar"><label>D0 <select id="ad">${d0s.map(d=>`<option>${d}</option>`).join('')}</select></label></div><div class="card"><div id="ap" class="plot tall"></div></div>`;
 const draw=d=>{const r=o.rows.filter(x=>x.d0_per_cm2==d);const m=r.filter(x=>x.evidence.startsWith('MEASURED')),e=r.filter(x=>!x.evidence.startsWith('MEASURED'));
  P('ap',[{type:'scatter',mode:'markers+text',name:'FloorplanLab (measured)',x:m.map(x=>x.die_area_mm2),y:m.map(x=>x.good_die_nb),text:m.map(x=>x.candidate.split(':')[1]),textposition:'top center',textfont:{size:9,color:C.ink2},marker:{color:C.s[0],size:10,symbol:'circle'}},
   {type:'scatter',mode:'markers+text',name:'variant (estimated)',x:e.map(x=>x.die_area_mm2),y:e.map(x=>x.good_die_nb),text:e.map(x=>x.candidate.split(':')[1]),textposition:'bottom center',textfont:{size:9,color:C.ink2},marker:{color:C.s[1],size:11,symbol:'triangle-up'}}],
   {title:{text:`Expected good dies per 200 mm wafer (NB) vs die area incl. pad ring, D0 = ${d}`,font:{size:12,color:C.ink}},xaxis:{title:'die area (mm²)',gridcolor:C.grid},yaxis:{title:'good dies / wafer',gridcolor:C.grid}})};$('#ad').onchange=e=>draw(e.target.value);draw(d0s[0])};
V.cost=el=>{const c=D.costs;if(!c||!c.full_wafer||!c.full_wafer.stages){el.innerHTML=`<h2>Cost per known-good die</h2><div class="card warn">${esc(c?JSON.stringify(c.full_wafer):'no cost file supplied for this run')}</div>`;return}
 const f=c.full_wafer;el.innerHTML=`<h2>Cost per delivered conforming (known-good) die</h2><p class="note"><b>${esc(f.label)}</b>. All prices are illustrative HYPOTHETICAL inputs - not quotes. Escapes are excluded from the denominator.</p>
 <div class="grid3">${[['cost / delivered conforming die',fmt(f.cost_per_delivered_conforming_die,3)+' '+f.currency],['recurring only',fmt(f.recurring_cost_per_delivered_conforming_die,3)+' '+f.currency],['escapes shipped (quality risk)',fmt(f.quality_risk.escape_dppm,0)+' DPPM']].map(([k,v])=>`<div class="card tile"><div class="k">${k}</div><div class="v">${v}</div></div>`).join('')}</div>
 <div class="grid2"><div class="card"><div id="cs" class="plot"></div>${table(f.stages)}</div><div class="card"><div id="ct" class="plot tall"></div></div></div><div class="card"><h3>Inputs</h3>${table(f.inputs,['input','value','source','reference'],{src:'source'})}</div>`;
 P('cs',[{type:'bar',x:f.stages.map(s=>s.stage),y:f.stages.map(s=>s.cost),marker:{color:C.s[0]}}],{title:{text:`Cost by stage (${f.currency}), NRE charged ${fmt(f.nre_charged,0)}`,font:{size:12,color:C.ink}}});
 const t=c.tornado||[];P('ct',[{type:'bar',orientation:'h',name:'input -25 %',y:t.map(r=>r.item),x:t.map(r=>r.low-r.base),base:t.map(r=>r.base),marker:{color:C.s[0]}},{type:'bar',orientation:'h',name:'input +25 %',y:t.map(r=>r.item),x:t.map(r=>r.high-r.base),base:t.map(r=>r.base),marker:{color:C.s[3]}}],
  {barmode:'overlay',margin:{l:170,r:20,t:30,b:60},title:{text:'One-at-a-time sensitivity of cost / conforming die',font:{size:12,color:C.ink}},yaxis:{autorange:'reversed',gridcolor:C.grid}})};
V.nodes=el=>{const n=ST.nodes;if(!n){el.innerHTML=missing('nodes');return}const cols=['node','nm','status','sfv_die_um','pad_ring_um','sram_macro_area_mm2','wafer_diameter_mm','defect_density_per_cm2','wafer_price','mpw_price','mask_nre','packaging','test_cost','timing','engineering_risk'];
 const cell=v=>String(v).startsWith('NOT AVAILABLE')?`<td><span class="pill" style="color:${C.crit};border:1px solid ${C.crit}">NOT AVAILABLE</span></td>`:`<td>${esc(v)}</td>`;
 el.innerHTML=`<h2>Process-node comparison</h2><p class="note">${esc(n.note)}</p><div class="card scroll"><table><thead><tr>${cols.map(c=>`<th>${c}</th>`).join('')}</tr></thead><tbody>${n.availability.map(r=>`<tr>${cols.map(c=>cell(r[c])).join('')}</tr>`).join('')}</tbody></table></div><div class="card"><div id="np" class="plot"></div></div>`;
 const r=n.comparison.filter(x=>x.gross_die_sim_wafer);const nodes=[...new Set(r.map(x=>x.node))];P('np',nodes.map((nd,k)=>{const q=r.filter(x=>x.node===nd);return {type:'scatter',mode:'lines+markers',name:nd+' ('+q[0].die_source+')',x:q.map(x=>x.d0_per_cm2_hypothetical),y:q.map(x=>x.good_die_nb),line:{color:C.s[k]}}}),
 {title:{text:'Good dies per simulated 200 mm wafer vs HYPOTHETICAL D0 (same D0 for every node)',font:{size:12,color:C.ink}},xaxis:{title:'D0 (/cm²)',gridcolor:C.grid},yaxis:{title:'good dies',gridcolor:C.grid}})};
V.repair=el=>{const e=ST.experiments&&ST.experiments.E;el.innerHTML=`<h2>Redundancy, repair and harvesting</h2><p class="note">Implemented in SilicaFlux-V: <b>${esc(D.meta.repair)}</b>. No macro has spare rows/columns; TestCore CAPS.REPAIR = 0; no ECC / parity; no bank or accelerator disable. Repair studies are CONDITIONAL.</p>${e?`<div class="card">${table(e.differences,['value','mean_a','mean_b','mean_diff','ci_lot_cluster_t'])}
 <p>Conditional (hypothetical) repaired dies per wafer: <b>${fmt(e.conditional_dies_per_wafer,2)}</b>; conditional good passes: ${fmt(e.conditional_good_pass_per_wafer,2)}; with hypothetical SECDED ECC: ${fmt(e.ecc_conditional_dies_per_wafer,2)}.</p><p class="note">${esc(e.note)}</p></div>`:missing('experiments')}
 <div class="card"><h3>Harvesting readiness (all six conditions required)</h3>${table([['architecture supports the feature','NO'],['fault can be isolated','NOT ANALYSED'],['hardware control exists','NO'],['firmware support','NO'],['validation tests','NO'],['reduced product specification','NO']].map(([a,b])=>({condition:a,silicaflux_v:b})))}</div>`};
V.param=el=>{const ks=MAPKEYS;const fm=[],lk=[],ok=[];ks.forEach(k=>{const p=D.maps[k].params;if(!p.fmax_mhz)return;p.fmax_mhz.forEach((v,i)=>{if(v!=null&&isFinite(v)){fm.push(v);lk.push(p.leakage_ua[i]);ok.push(D.maps[k].sites.param_ok[i])}})});
 el.innerHTML=`<h2>Parametric yield</h2><p class="note warn">HYPOTHETICAL distributions - no SilicaFlux statistical process data exist. PVT corners from TimingFlow are not probability distributions. Parametric failures are reported separately from random-defect failures.</p>
 <div class="grid3">${[['parametric-only failures / wafer',fmt(metric('param_fail_only').mean,2)],['Fmax spec','>= 50 MHz (release-1 target)'],['leakage spec','<= 150 uA (HYPOTHETICAL)']].map(([k,v])=>`<div class="card tile"><div class="k">${k}</div><div class="v">${v}</div></div>`).join('')}</div><div class="grid2"><div class="card"><div id="ps" class="plot tall"></div></div><div class="card"><div id="ph" class="plot tall"></div></div></div>`;
 if(!fm.length)return;const gi=ok.map((o,i)=>o?i:-1).filter(i=>i>=0),bi=ok.map((o,i)=>!o?i:-1).filter(i=>i>=0);
 P('ps',[{type:'scattergl',mode:'markers',name:'in spec',x:gi.map(i=>fm[i]),y:gi.map(i=>lk[i]),marker:{color:C.s[0],size:3,opacity:.5}},{type:'scattergl',mode:'markers',name:'out of spec',x:bi.map(i=>fm[i]),y:bi.map(i=>lk[i]),marker:{color:C.crit,size:6,symbol:'x'}}],
 {title:{text:'Fmax vs leakage (true values, kept wafers)',font:{size:12,color:C.ink}},xaxis:{title:'Fmax (MHz)',gridcolor:C.grid},yaxis:{title:'leakage (uA)',gridcolor:C.grid},shapes:[{type:'line',x0:50,x1:50,yref:'paper',y0:0,y1:1,line:{color:C.gold,dash:'dot'}}]});
 P('ph',[{type:'histogram',x:fm,marker:{color:C.s[4]},name:'Fmax'}],{title:{text:'Fmax distribution',font:{size:12,color:C.ink}},xaxis:{title:'MHz',gridcolor:C.grid}})};
V.mpw=el=>{const c=D.costs||{};const h=ST.experiments&&ST.experiments.H;el.innerHTML=`<h2>MPW and first-silicon economics</h2><p class="note">Engineering prototype cost per usable chip and volume cost per known-good die are different measures. All prices HYPOTHETICAL.</p>
 <div class="grid2"><div class="card"><h3>MPW shuttle</h3>${c.mpw&&c.mpw.total_cost?table(Object.entries(c.mpw).filter(([k])=>k!=='inputs').map(([k,v])=>({item:k,value:v}))):esc(JSON.stringify(c.mpw||'not supplied'))}</div>
 <div class="card"><h3>First silicon - program cost per usable prototype</h3>${c.first_silicon&&c.first_silicon.scenarios?table(c.first_silicon.scenarios)+`<p class="note">${esc(c.first_silicon.measure)}</p>`:'not supplied'}</div></div>
 ${h?`<div class="card"><h3>Dedicated wafers (same HYPOTHETICAL prices)</h3>${table(h.dedicated)}<p class="note">${esc(h.note)}</p></div>`:''}`};
V.sens=el=>{const s=ST.sensitivity;if(!s){el.innerHTML=missing('sensitivity');return}const r=s.d0.rows;el.innerHTML=`<h2>Sensitivity analysis</h2><p class="note">${esc(s.d0.note)}</p><div class="grid2"><div class="card"><div id="sd" class="plot tall"></div></div><div class="card"><div id="se" class="plot tall"></div></div></div><div class="card">${table(r)}</div>`;
 const keys=Object.keys(r[0]).filter(k=>!['d0_per_cm2','true_good_per_wafer'].includes(k));P('sd',keys.map((k,i)=>({type:'scatter',mode:'lines+markers',name:k,x:r.map(x=>x.d0_per_cm2),y:r.map(x=>x[k]),line:{color:i<6?C.s[i]:C.ink2,dash:k==='simulated_uniform'?'dot':'solid'}})),
 {title:{text:'Defect-limited yield of the SilicaFlux-V die vs D0',font:{size:12,color:C.ink}},xaxis:{title:'D0 (/cm²)',type:'log',gridcolor:C.grid},yaxis:{title:'yield',gridcolor:C.grid}});
 const e=s.edge_exclusion.rows;P('se',[{type:'bar',x:e.map(x=>x.edge_exclusion_mm+' mm'),y:e.map(x=>x.eligible),name:'eligible sites',marker:{color:C.s[0]}},{type:'bar',x:e.map(x=>x.edge_exclusion_mm+' mm'),y:e.map(x=>x.true_good_mean),name:'true good / wafer',marker:{color:C.s[1]}}],{barmode:'group',title:{text:'Edge-exclusion sensitivity',font:{size:12,color:C.ink}}})};
V.pareto=el=>{const o=ST.optimisation;if(!o){el.innerHTML=missing('optimisation');return}const d0=Object.keys(o.by_d0)[1]||Object.keys(o.by_d0)[0];const r=o.rows.filter(x=>String(x.d0_per_cm2)===d0);const pf=o.by_d0[d0].pareto;
 el.innerHTML=`<h2>Pareto optimisation</h2><p class="note">Mandatory constraints reject candidates before ranking. Strictly feasible (overflow 0 + timing + functionality): <b>${o.by_d0[d0].strict_feasible.length?o.by_d0[d0].strict_feasible.join(', '):'NONE'}</b>. Preliminary screen (overflow &le; ${o.config.overflow_screen}): ${o.by_d0[d0].feasible.join(', ')||'none'}. D0 = ${d0} (HYPOTHETICAL).</p>
 <div class="card"><div id="pp" class="plot tall"></div></div><div class="card">${table(r.map(x=>({candidate:x.candidate,evidence:x.evidence,die_area_mm2:x.die_area_mm2,gross_die:x.gross_die,good_die_nb:x.good_die_nb,cost_per_good_die_nb:x.cost_per_good_die_nb,rel_sd:x.rel_sd_good_per_wafer,violations:x.violations.join('; ')||'none',pareto:pf.includes(x.candidate)?'YES':''})))}</div>`;
 const fe=r.filter(x=>!x.violations.length),inf=r.filter(x=>x.violations.length);P('pp',[{type:'scatter',mode:'markers',name:'rejected (constraint)',x:inf.map(x=>x.good_die_nb),y:inf.map(x=>x.cost_per_good_die_nb),text:inf.map(x=>x.candidate+'<br>'+x.violations.join('<br>')),marker:{color:C.muted,size:8,symbol:'x'},hovertemplate:'%{text}<extra></extra>'},
 {type:'scatter',mode:'markers+text',name:'feasible (screen)',x:fe.map(x=>x.good_die_nb),y:fe.map(x=>x.cost_per_good_die_nb),text:fe.map(x=>x.candidate.split(':')[1]),textposition:fe.map((_,i)=>['top center','bottom center','middle right'][i%3]),textfont:{size:9,color:C.ink2},marker:{color:fe.map(x=>pf.includes(x.candidate)?C.gold:C.s[0]),size:11,line:{color:C.panel,width:2}}}],
 {title:{text:'Cost per good die vs good dies per wafer (gold = non-dominated; double-click to show all)',font:{size:12,color:C.ink}},
  xaxis:{title:'expected good dies / wafer',gridcolor:C.grid,range:fe.length?[Math.min(...fe.map(x=>x.good_die_nb))*0.93,Math.max(...r.map(x=>x.good_die_nb))*1.02]:undefined},
  yaxis:{title:'cost / good die (HYPOTHETICAL)',gridcolor:C.grid,range:fe.length?[Math.min(...r.map(x=>x.cost_per_good_die_nb))*0.97,Math.max(...fe.map(x=>x.cost_per_good_die_nb))*1.12]:undefined}})};
V.prov=el=>{el.innerHTML=`<h2>Input provenance</h2><p class="note">Every input of this run with its source class. NOT_AVAILABLE inputs cannot be used by any calculation (MissingInputError).</p><div class="card">${table(SUM.inputs,['input','value','source','reference','note'],{src:'source'})}</div>
 <div class="card"><h3>Functional regions</h3>${table(SUM.regions,['region','function','kind','opendb_area_mm2','located_area_mm2','criticality','redundancy','disable_support','detected_by','coverage_source','area_source'])}</div><div class="card"><h3>Resolved scenario</h3><pre>${esc(D.scenario_yaml)}</pre></div>`};
function md(t){const lines=t.split('\n');let h='',inT=false;for(const l of lines){if(l.startsWith('|')){const cells=l.slice(1,-1).split('|').map(c=>c.trim());if(cells.every(c=>/^-+$/.test(c)))continue;
 if(!inT){h+='<div class="scroll"><table><tr>'+cells.map(c=>`<th>${esc(c)}</th>`).join('')+'</tr>';inT=true}else h+='<tr>'+cells.map(c=>`<td>${esc(c)}</td>`).join('')+'</tr>';continue}
 if(inT){h+='</table></div>';inT=false}if(l.startsWith('# '))h+=`<h1>${esc(l.slice(2))}</h1>`;else if(l.startsWith('## '))h+=`<h2>${esc(l.slice(3))}</h2>`;else if(l.startsWith('### '))h+=`<h3>${esc(l.slice(4))}</h3>`;
 else if(l.startsWith('> '))h+=`<blockquote>${esc(l.slice(2))}</blockquote>`;else if(l.startsWith('* '))h+=`<li>${esc(l.slice(2))}</li>`;else if(l.startsWith('!['))h+=`<img src="${esc(l.match(/\((.*)\)/)[1])}" alt="">`;else if(l.trim())h+=`<p>${esc(l)}</p>`}return h+(inT?'</table></div>':'')}
V.reports=el=>{const g=D.gates;el.innerHTML=`<h2>Engineering reports</h2>${g?`<div class="card"><h3>Quality gates</h3>${table(g.gates)}<p class="note">${esc(g.disclaimer)}</p></div>`:''}<div class="card md">${md(D.report_md)}</div>`};
const nav=$('#nav');nav.innerHTML=D.views.map(([k,t])=>`<button data-v="${k}">${esc(t)}</button>`).join('');
function show(k){nav.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.dataset.v===k));const m=$('#main');m.innerHTML='';try{V[k](m)}catch(e){m.innerHTML=`<div class="card warn">view failed: ${esc(e.message)}</div>`;console.error(e)}
 try{localStorage.setItem('yl-view',k)}catch(e){}}
nav.onclick=e=>{const b=e.target.closest('button');if(b)show(b.dataset.v)};let start='geometry';try{start=localStorage.getItem('yl-view')||'geometry'}catch(e){}show(V[start]?start:'geometry');
</script></body></html>
"""
