"""Reproducible repository audit: what actually exists inside the SilicaFlux archives.

The Aureom.AI repository stores most SilicaFlux projects as (nested) zip /
tar.gz archives.  This module opens every archive in memory (recursively, up to
``max_depth``), counts members by type and records which physical-design
artefacts exist.  It never executes anything from the archives.

Output: ``reports/audit/repository_audit.json`` and ``inventory.md``.  The
interpretive audit (design status, die dimensions, gaps) is docs/AUDIT.md,
whose numbers come from the vendored evidence files in third_party/.
"""
from __future__ import annotations

import io
import json
import tarfile
import zipfile
from collections import Counter
from pathlib import Path

HDL = {".sf": "sf (SystemVerilog source, SilicaFlux naming)", ".sv": "sv", ".v": "v", ".svh": "svh",
       ".sfx": "sfx (SilicaFlux assembly)"}
PHYS = {".def": "DEF", ".gds": "GDSII", ".gds2": "GDSII", ".oas": "OASIS", ".odb": "OpenDB", ".lef": "LEF",
        ".lib": "Liberty", ".spef": "SPEF", ".sdc": "SDC"}
INTEREST = ("floorplan", "testcore", "sramlib", "timingflow", "timinglab", "datafabric", "mcu-i", "thermallab",
            "powerlink", "memorylab", "bandwidthlab", "memoryflow", "silicaflux-v", "fabtwin", "twinlab")


def _ext(name: str) -> str:
    n = name.lower()
    if n.endswith(".tar.gz"):
        return ".tar.gz"
    i = n.rfind(".")
    return n[i:] if i >= 0 else ""


def _scan_bytes(data: bytes, name: str, depth: int, max_depth: int, rec: dict) -> None:
    members = []
    try:
        if name.lower().endswith(".zip"):
            zf = zipfile.ZipFile(io.BytesIO(data))
            members = [(i.filename, (lambda i=i: zf.read(i))) for i in zf.infolist() if not i.is_dir()]
        elif name.lower().endswith((".tar.gz", ".tgz")):
            tf = tarfile.open(fileobj=io.BytesIO(data), mode="r:gz")
            members = [(m.name, (lambda m=m: tf.extractfile(m).read())) for m in tf.getmembers() if m.isfile()]
    except Exception as e:  # corrupt / unsupported archive: recorded, not fatal
        rec["errors"].append(f"{name}: {e}")
        return
    for mname, reader in members:
        e = _ext(mname)
        rec["files"] += 1
        rec["ext"][e] += 1
        if e in PHYS:
            rec["physical"].append(mname)
        if e in (".zip", ".tar.gz", ".tgz") and depth < max_depth:
            try:
                sub = {"files": 0, "ext": Counter(), "physical": [], "errors": [], "nested": []}
                _scan_bytes(reader(), mname, depth + 1, max_depth, sub)
                rec["nested"].append({"archive": mname, "files": sub["files"], "ext": dict(sub["ext"]),
                                      "physical": sub["physical"][:50], "nested": sub["nested"]})
                rec["files"] += sub["files"]
                rec["ext"].update(sub["ext"])
                rec["physical"].extend(f"{mname}::{p}" for p in sub["physical"])
                rec["errors"].extend(sub["errors"])
            except Exception as ex:
                rec["errors"].append(f"{mname}: {ex}")


def run_audit(repo: Path, out: Path, max_depth: int = 3) -> dict:
    repo = Path(repo)
    root = repo / "SilicaFlux-main"
    if not root.exists():
        raise FileNotFoundError(f"{root} not found - pass the Aureom.AI checkout with --repo")
    archives = []
    loose = Counter()
    for p in sorted(root.rglob("*")):
        if p.is_dir():
            continue
        e = _ext(p.name)
        if e in (".zip", ".tar.gz", ".tgz"):
            rec = {"files": 0, "ext": Counter(), "physical": [], "errors": [], "nested": []}
            _scan_bytes(p.read_bytes(), p.name, 0, max_depth, rec)
            archives.append({"archive": str(p.relative_to(repo)), "bytes": p.stat().st_size, "files": rec["files"],
                             "hdl": {HDL[k]: v for k, v in rec["ext"].items() if k in HDL},
                             "physical": {PHYS[k]: v for k, v in rec["ext"].items() if k in PHYS},
                             "physical_files": rec["physical"][:40], "errors": rec["errors"][:10],
                             "project_of_interest": any(k in p.name.lower() for k in INTEREST)})
        else:
            loose[e] += 1
    hdl = Counter()
    phys = Counter()
    for a in archives:
        hdl.update(a["hdl"])
        phys.update(a["physical"])
    for k, v in loose.items():
        if k in HDL:
            hdl[HDL[k] + " (loose files)"] += v
    res = {"repository": "btcphilosopher/Aureom.AI", "root": "SilicaFlux-main", "archives_scanned": len(archives),
           "files_total": sum(a["files"] for a in archives) + sum(loose.values()),
           "hdl_counts": dict(hdl), "physical_counts": dict(phys), "loose_file_types": dict(loose),
           "archives": archives,
           "note": "counts include duplicated / vendored copies across archives; GDSII and OpenDB files: see physical_counts"}
    out.mkdir(parents=True, exist_ok=True)
    (out / "repository_audit.json").write_text(json.dumps(res, indent=1))
    lines = ["# Repository inventory (generated by `python -m yieldlab audit`)", "",
             f"Archives scanned: {res['archives_scanned']}; files: {res['files_total']}", "",
             f"HDL: {res['hdl_counts']}", "", f"Physical-design files: {res['physical_counts']}", "",
             "| archive | files | HDL | physical | of interest |", "|---|---|---|---|---|"]
    for a in archives:
        lines.append(f"| {a['archive']} | {a['files']} | {a['hdl']} | {a['physical']} | {a['project_of_interest']} |")
    (out / "inventory.md").write_text("\n".join(lines) + "\n")
    return res
