"""YieldLab command-line interface:  python -m yieldlab <command> [options]

Commands
  audit        repository audit (counts HDL / physical files inside the nested archives)
  geometry     wafer layout, site classes, gross-die count vs approximations, SVG/PNG/JSON export
  poisson      analytical yield models vs Monte Carlo + spatial convergence check
  clusters     run every spatial generator and the DBSCAN / pattern analysis
  simulate     multi-wafer / multi-lot Monte Carlo -> reproducible run directory
  compare      defect-model comparison (configs/defect_models.yaml)
  cost         cost analysis of a scenario (needs a cost file)
  sweep        D0 sensitivity and edge-exclusion sweep
  optimise     area-yield-cost candidates, constraints and Pareto front (configs/area_yield_sweep.yaml)
  experiments  controlled paired experiments A-J
  nodes        process-node availability table and sensitivity comparison
  calibrate    fit D0 / alpha to a VERIFIED imported wafer-map CSV
  import       validate a measured wafer-map CSV
  report       regenerate report.md (and optionally verify reproducibility) for a run directory
  dashboard    build the interactive HTML dashboard for a run directory
  gates        evaluate engineering quality gates 1-20 for a run directory
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np

from .provenance import MissingInputError

ROOT = Path(__file__).resolve().parents[2]
REPORTS = ROOT / "reports"
STUDIES = REPORTS / "studies"


def _p(obj) -> None:
    from .report import _json_default

    print(json.dumps(obj, indent=1, default=_json_default))


def cmd_audit(a):
    from .audit import run_audit

    res = run_audit(Path(a.repo), REPORTS / "audit")
    print(f"audited {res['archives_scanned']} archives, {res['files_total']} files; "
          f"HDL: {res['hdl_counts']}; physical: {res['physical_counts']}")
    print(f"-> {REPORTS / 'audit'}")


def cmd_geometry(a):
    from .analysis import geometry_analysis
    from .config import load_scenario
    from .monte_carlo import build_runtime
    from . import plots
    from .report import dump

    scn = load_scenario(a.config, _ov(a))
    g = geometry_analysis(scn, optimise=not a.no_optimise)
    out = REPORTS / "geometry" / scn.name
    rt = build_runtime(scn)
    dump(g, out / "geometry.json")
    plots.wafer_json(rt.wmap, out / "wafer_layout.json", {"scenario": scn.name, "label": "SIMULATED LAYOUT"})
    plots.wafer_svg(rt.wmap, out / "wafer_layout.svg", label="SIMULATED LAYOUT")
    plots.wafer_map(rt.wmap, out / "wafer_layout.png", "geometry", title=f"{scn.name}: die placement",
                    label="SIMULATED LAYOUT")
    print(f"die {g['die_um'][0]:.2f} x {g['die_um'][1]:.2f} um ({g['die_area_mm2']:.3f} mm^2, {g['die_source']})")
    print(f"pitch {g['pitch_mm'][0]:.4f} x {g['pitch_mm'][1]:.4f} mm; footprint {g['footprint_convention']}")
    for k, v in g["site_counts"].items():
        print(f"  {k:28s} {v}")
    print(f"ELIGIBLE (FULL DIE): {g['eligible']}")
    for r in g["approximations"]:
        print(f"  {r['method']:16s} {r['value']:10.1f}  diff {r['difference']:+8.1f} ({100 * r['relative_difference']:+.2f} %)")
    if "optimised_grid_offset" in g:
        o = g["optimised_grid_offset"]
        print(f"best grid offset ({o['offset_x_mm']:.3f}, {o['offset_y_mm']:.3f}) mm -> {o['full_dies']} ({o['gain_vs_configured']:+d})")
    print(f"geometric loss {100 * g['area_accounting']['geometric_loss_fraction']:.2f} % of wafer area -> {out}")


def cmd_poisson(a):
    from . import yield_models as ym
    from .analysis import model_comparison
    from .report import dump

    rng = np.random.default_rng(a.seed)
    res = model_comparison(a.area_cm2, a.d0, a.alpha, rng, n_mc=a.samples)
    print(f"A = {a.area_cm2} cm^2, D0 = {a.d0} /cm^2 (HYPOTHETICAL), alpha = {a.alpha}")
    for r in res["rows"]:
        if r["analytical_yield"] is None:
            print(f"  {r['model']:18s} {r['status']}")
        else:
            print(f"  {r['model']:18s} analytical {r['analytical_yield']:.6f}  MC {r['monte_carlo_yield']:.6f} "
                  f"+/- {r['mc_standard_error']:.6f}  z = {r['z']:+.2f}")
    al = [0.5, 1, 2, 5, 20, 100, 1000, 1e5]
    print("NB -> Poisson as alpha grows:", ", ".join(f"a={x:g}: {ym.negative_binomial_yield(a.area_cm2, a.d0, x):.6f}"
                                                    for x in al), f"| Poisson {ym.poisson_yield(a.area_cm2, a.d0):.6f}")
    dump(res, STUDIES / "poisson_models.json")


def cmd_clusters(a):
    from .experiments import cluster_study
    from .report import dump

    res = cluster_study(wpl=a.wafers)
    for w in res["wafers"]:
        print(f"wafer {w['wafer']}: {w['n_defects']} defects; classes {w['pattern_classes']}; "
              f"{len(w['dbscan']['clusters'])} DBSCAN clusters; ring {w['ring']}")
    print("NOTE:", res["wafers"][0]["caveat"] if res["wafers"] else "")
    dump(res, STUDIES / "clusters.json")


def _ov(a) -> dict:
    ov = {}
    for item in getattr(a, "set", None) or []:
        k, v = item.split("=", 1)
        try:
            v = json.loads(v)
        except json.JSONDecodeError:
            pass
        ov[k] = v
    return ov


def cmd_simulate(a):
    from .config import load_scenario
    from .report import run_scenario

    scn = load_scenario(a.config, _ov(a))
    lots = a.lots or scn.monte_carlo.lots
    wpl = a.wafers_per_lot or scn.monte_carlo.wafers_per_lot
    if a.wafers:
        if a.lots is None and a.wafers_per_lot is None:
            wpl = scn.monte_carlo.wafers_per_lot
        lots = max(1, math.ceil(a.wafers / wpl))
    out = run_scenario(a.config, lots=lots, wafers_per_lot=wpl, seed=a.seed, workers=a.workers, costs=a.costs,
                       overrides=_ov(a), out_root=Path(a.out) if a.out else REPORTS)
    S = json.loads((out / "summary.json").read_text())
    print(S["label"])
    for r in S["summary"]:
        if r["metric"] in ("eligible", "functional_fail_raw", "outcome_TRUE_GOOD_PASS", "outcome_DEFECTIVE_ESCAPED",
                           "delivered_conforming", "true_good_yield"):
            print(f"  {r['metric']:28s} mean {r['mean']:10.4f}  95% CI {r['ci95_mean']}  90% PI {r['pi90_next_wafer']}")
    print(f"-> {out}")


def cmd_compare(a):
    from .config import CONFIG_ROOT, load_scenario, load_yaml
    from . import yield_models as ym
    from .experiments import paired
    from .monte_carlo import build_runtime
    from .report import dump

    c = load_yaml(a.config)["compare"]
    an = c["analytical"]
    table = ym.comparison_table(an["area_grid_cm2"], an["d0_per_cm2"], an["alpha"])
    base = Path(a.config).parent / c["base_scenario"]
    names = list(c["defect_scenarios"])
    scns = []
    for n in names:
        s = load_scenario(base, {"defects": load_yaml(CONFIG_ROOT / c["defect_scenarios"][n])["defects"]})
        s.name = n
        scns.append(s)
    res = {"analytical": table, "analytical_params": an, "paired": []}
    for i in range(1, len(scns)):
        res["paired"].append(paired(scns[0], scns[i], c["lots"], c["wafers_per_lot"], (names[0], names[i])))
    a_cm2 = build_runtime(scns[0]).die.area_cm2
    print(f"SilicaFlux-V die {a_cm2:.4f} cm^2; D0 = {an['d0_per_cm2']} (HYPOTHETICAL), alpha = {an['alpha']}")
    for k, v in ym.comparison_table([a_cm2], an["d0_per_cm2"], an["alpha"])[0].items():
        print(f"  {k:32s} {v:.5f}")
    for p in res["paired"]:
        for d in p["differences"]:
            ci = d.get("ci_lot_cluster_t", d.get("ci_wafer_t"))
            print(f"  {p['arms']} {d['value']:28s} diff {d['mean_diff']:+8.2f}  95% CI {ci}")
        print(f"    wafer sd: {p['sd_' + names[0]]['outcome_TRUE_GOOD_PASS']:.1f} vs "
              f"{list(p.values())[-1]['outcome_TRUE_GOOD_PASS']:.1f}")
    dump(res, STUDIES / "defect_model_comparison.json")


def cmd_cost(a):
    from .analysis import cost_analysis
    from .config import load_scenario, load_yaml
    from .monte_carlo import run_simulation
    from .report import dump

    scn = load_scenario(a.config, _ov(a))
    scn = scn.model_copy(update={"costs": load_yaml(a.costs)["costs"]})
    sim = run_simulation(scn, lots=a.lots, wafers_per_lot=a.wafers_per_lot, keep_maps=0)
    res = cost_analysis(sim, scn.costs)
    fw = res.get("full_wafer", {})
    if "total_cost" in fw:
        print(fw["label"])
        for s in fw["stages"]:
            print(f"  {s['stage']:11s} in {s['in']:>10.0f} out {s['out']:>10.0f}  cost {s['cost']:>12,.0f} {fw['currency']}")
        print(f"  cost per delivered conforming die: {fw['cost_per_delivered_conforming_die']:.4f} {fw['currency']} "
              f"({fw['nre_rule']}); escapes {fw['quality_risk']['escape_dppm']:.0f} DPPM (excluded)")
    else:
        print("full-wafer cost:", fw)
    for k in ("mpw", "first_silicon"):
        if k in res:
            v = res[k]
            print(f"{k}:", {kk: vv for kk, vv in v.items() if kk not in ("inputs",)})
    dump(res, STUDIES / f"costs_{scn.name}.json")


def cmd_sweep(a):
    from .experiments import d0_sensitivity, exp_D
    from .report import dump

    d = d0_sensitivity(lots=a.lots, wpl=a.wafers_per_lot)
    print(f"die {d['die_area_cm2']:.4f} cm^2, {d['eligible']} eligible; {d['note']}")
    for r in d["rows"]:
        print("  " + "  ".join(f"{k}={v:.4f}" if isinstance(v, float) else f"{k}={v}" for k, v in r.items()))
    e = exp_D(a.lots, a.wafers_per_lot)
    for r in e["rows"]:
        print(f"  edge exclusion {r['edge_exclusion_mm']} mm: eligible {r['eligible']}, true good {r['true_good_mean']:.1f}")
    dump({"d0": d, "edge_exclusion": e}, STUDIES / "sensitivity.json")


def cmd_optimise(a):
    from .config import load_yaml
    from .experiments import nb_wafer_rel_sd
    from .optimisation import architecture_variants, constraints, evaluate, floorplan_run_candidates, pareto_front
    from .report import dump
    from .wafer_geometry import WaferSpec
    from .config import CONFIG_ROOT

    o = load_yaml(a.config)["optimise"]
    wafer = WaferSpec(**load_yaml(CONFIG_ROOT / o["wafer"])["wafer"])
    cands = floorplan_run_candidates() + architecture_variants()
    rows = evaluate(cands, wafer, o["pad_ring_um"], o["scribe_um"], o["d0_per_cm2"], o["alpha"], o["wafer_cost"],
                    o["per_die_cost"])
    for r in rows:
        r["violations"] = constraints(r, o["required_sram_kib"], o["required_tensor_macs"], o["required_vector_lanes"],
                                      overflow_screen=o["overflow_screen"])
        r["violations_strict"] = constraints(r, o["required_sram_kib"], o["required_tensor_macs"],
                                             o["required_vector_lanes"], strict_routability=True)
        r["rel_sd_good_per_wafer"] = nb_wafer_rel_sd(r["gross_die"], r["die_area_mm2"] / 100, r["d0_per_cm2"], o["alpha"])
    out = {"config": o, "rows": rows, "by_d0": {}}
    for d0 in o["d0_per_cm2"]:
        sub = [r for r in rows if r["d0_per_cm2"] == d0]
        feas = [r for r in sub if not r["violations"]]
        front = pareto_front(feas, {"good_die_nb": "max", "cost_per_good_die_nb": "min", "die_area_mm2": "min",
                                    "rel_sd_good_per_wafer": "min"}) if feas else []
        out["by_d0"][str(d0)] = {"feasible": [r["candidate"] for r in feas], "pareto": [feas[i]["candidate"] for i in front],
                                 "strict_feasible": [r["candidate"] for r in sub if not r["violations_strict"]]}
        print(f"D0 = {d0} (HYPOTHETICAL): feasible (preliminary screen) {out['by_d0'][str(d0)]['feasible']}")
        print(f"   Pareto: {out['by_d0'][str(d0)]['pareto']};  strict (overflow 0 + timing): "
              f"{out['by_d0'][str(d0)]['strict_feasible'] or 'NONE'}")
    dump(out, STUDIES / "optimisation.json")


def cmd_experiments(a):
    from .experiments import run_experiments
    from .report import dump

    res = run_experiments(a.which, a.lots, a.wafers_per_lot)
    for k, v in res.items():
        print(f"[{k}] {v['title']}")
        for d in v.get("differences", []):
            ci = d.get("ci_lot_cluster_t", d.get("ci_wafer_t"))
            print(f"      {d['value']:28s} {d['mean_a']:10.2f} -> {d['mean_b']:10.2f}  diff {d['mean_diff']:+8.2f}  95% CI {ci}")
        if "note" in v:
            print("      note:", v["note"])
    dump(res, STUDIES / "experiments.json")


def cmd_nodes(a):
    from .experiments import exp_G
    from .report import dump

    res = exp_G()
    for r in res["availability"]:
        print(f"{r['node']:18s} {r['status']:32s} die {r['sfv_die_um']:<60.60s} D0 {r['defect_density_per_cm2']} "
              f"wafer {r['wafer_price']}")
    print("NOTE:", res["note"])
    dump(res, STUDIES / "nodes.json")


def cmd_import(a):
    from .imports import load_wafer_map_csv

    r = load_wafer_map_csv(a.data, good_bins=a.good_bins, valid_bins=a.valid_bins, retest_policy=a.retest_policy,
                           allow_best=a.allow_best, flip_x=a.flip_x, flip_y=a.flip_y, rotate_deg=a.rotate)
    _p(r.summary())


def cmd_calibrate(a):
    from . import calibration as cal
    from .imports import load_wafer_map_csv, wafer_counts

    r = load_wafer_map_csv(a.data, good_bins=a.good_bins, valid_bins=a.valid_bins, retest_policy=a.retest_policy)
    c = wafer_counts(r, allow_fixture=a.allow_fixture)
    rng = np.random.default_rng(a.seed)
    fit = cal.fit_nb_wafer(c["good"].to_numpy(), c["total"].to_numpy(), a.area_cm2)
    tr, va = cal.holdout_split(len(c), 0.3, rng)
    fit_tr = cal.fit_nb_wafer(c["good"].to_numpy()[tr], c["total"].to_numpy()[tr], a.area_cm2)
    _p({"data_label": r.label, "fit_all": fit,
        "holdout": cal.validate_nb(fit_tr, c["good"].to_numpy()[va], c["total"].to_numpy()[va], a.area_cm2, rng),
        "gof": cal.gof_wafer_yields(fit, c["good"].to_numpy(), c["total"].to_numpy(), a.area_cm2, rng)})


def cmd_report(a):
    from .report import markdown_report

    rd = Path(a.run_dir)
    (rd / "report.md").write_text(markdown_report(rd))
    print(f"report regenerated: {rd / 'report.md'}")
    if a.verify:
        from .gates import verify_reproducible

        ok, msg = verify_reproducible(rd)
        print(("REPRODUCIBLE: " if ok else "NOT REPRODUCIBLE: ") + msg)
        if not ok:
            sys.exit(1)


def cmd_dashboard(a):
    from .dashboard import build

    out = build(Path(a.run_dir), STUDIES, Path(a.out) if a.out else None)
    print(f"dashboard -> {out}")


def cmd_gates(a):
    from .gates import evaluate_gates

    res = evaluate_gates(Path(a.run_dir), Path(a.junit) if a.junit else None, verify=not a.no_verify)
    from .report import dump

    dump(res, Path(a.run_dir) / "gates.json")
    for g in res["gates"]:
        print(f"GATE {g['gate']:2d} {g['status']:8s} {g['name']}: {g['evidence']}")
    print(res["disclaimer"])


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="yieldlab", description="SilicaFlux YieldLab")
    sp = ap.add_subparsers(dest="cmd", required=True)

    def add(name, fn, **kw):
        p = sp.add_parser(name, help=fn.__doc__ or name, **kw)
        p.set_defaults(fn=fn)
        return p

    p = add("audit", cmd_audit)
    p.add_argument("--repo", required=True, help="path to a btcphilosopher/Aureom.AI checkout")
    for name, fn in (("geometry", cmd_geometry),):
        p = add(name, fn)
        p.add_argument("--config", required=True)
        p.add_argument("--no-optimise", action="store_true")
        p.add_argument("--set", action="append", help="override, e.g. wafer.edge_exclusion_mm=5")
    p = add("poisson", cmd_poisson)
    p.add_argument("--area-cm2", type=float, default=0.1179)
    p.add_argument("--d0", type=float, default=0.25)
    p.add_argument("--alpha", type=float, default=3.0)
    p.add_argument("--samples", type=int, default=400000)
    p.add_argument("--seed", type=int, default=42)
    p = add("clusters", cmd_clusters)
    p.add_argument("--config", default=None)
    p.add_argument("--wafers", type=int, default=4)
    for name, fn in (("simulate", cmd_simulate), ("wafer", cmd_simulate), ("lot", cmd_simulate)):
        p = add(name, fn)
        p.add_argument("--config", required=True)
        p.add_argument("--wafers", type=int, default=None, help="total wafers (lots derived)")
        p.add_argument("--lots", type=int, default=None)
        p.add_argument("--wafers-per-lot", type=int, default=None)
        p.add_argument("--seed", type=int, default=None)
        p.add_argument("--workers", type=int, default=None)
        p.add_argument("--costs", default=None)
        p.add_argument("--out", default=None)
        p.add_argument("--set", action="append")
    p = add("compare", cmd_compare)
    p.add_argument("--config", required=True)
    p = add("cost", cmd_cost)
    p.add_argument("--config", required=True)
    p.add_argument("--costs", required=True)
    p.add_argument("--lots", type=int, default=4)
    p.add_argument("--wafers-per-lot", type=int, default=25)
    p.add_argument("--set", action="append")
    p = add("sweep", cmd_sweep)
    p.add_argument("--lots", type=int, default=3)
    p.add_argument("--wafers-per-lot", type=int, default=8)
    p = add("optimise", cmd_optimise)
    p.add_argument("--config", required=True)
    p = add("experiments", cmd_experiments)
    p.add_argument("--which", default="ABCDEFGHIJ")
    p.add_argument("--lots", type=int, default=6)
    p.add_argument("--wafers-per-lot", type=int, default=10)
    add("nodes", cmd_nodes)
    for name, fn in (("import", cmd_import), ("calibrate", cmd_calibrate)):
        p = add(name, fn)
        p.add_argument("--data", required=True)
        p.add_argument("--good-bins", type=int, nargs="+", default=[1])
        p.add_argument("--valid-bins", type=int, nargs="+", default=None)
        p.add_argument("--retest-policy", choices=["FIRST", "LAST", "WORST", "BEST"], default=None)
        p.add_argument("--allow-best", action="store_true")
        p.add_argument("--flip-x", action="store_true")
        p.add_argument("--flip-y", action="store_true")
        p.add_argument("--rotate", type=int, default=0)
        p.add_argument("--area-cm2", type=float, default=0.1179)
        p.add_argument("--seed", type=int, default=0)
        p.add_argument("--allow-fixture", action="store_true", help="calibrate a SYNTHETIC TEST FIXTURE (demo only)")
    p = add("report", cmd_report)
    p.add_argument("--run-dir", required=True)
    p.add_argument("--verify", action="store_true", help="re-run from scenario.resolved.yaml and compare wafers.csv")
    p = add("dashboard", cmd_dashboard)
    p.add_argument("--run-dir", required=True)
    p.add_argument("--out", default=None)
    p = add("gates", cmd_gates)
    p.add_argument("--run-dir", required=True)
    p.add_argument("--junit", default=None)
    p.add_argument("--no-verify", action="store_true", help="skip the re-run reproducibility check (GATE 18 NOT_RUN)")
    a = ap.parse_args(argv)
    try:
        a.fn(a)
    except MissingInputError as e:
        print(f"ERROR - missing input (nothing was substituted): {e}", file=sys.stderr)
        return 2
    except (ValueError, FileNotFoundError) as e:
        print(f"ERROR - {type(e).__name__}: {e}", file=sys.stderr)
        return 2
    return 0
