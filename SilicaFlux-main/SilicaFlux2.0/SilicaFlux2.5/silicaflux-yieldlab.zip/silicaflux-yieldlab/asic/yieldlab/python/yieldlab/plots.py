"""Static figures (PNG via matplotlib) and wafer-layout exports (SVG / PNG / JSON).

Every figure is drawn from simulation (or imported) results passed in -- no
number is typed into a plot.  Simulated content carries a persistent
"SIMULATED" stamp; imported data carries the import label it was given.

Palette (validated with the dataviz validator on the #0c1528 navy surface:
lightness band, chroma, adjacent CVD separation >= 8, normal-vision >= 15,
contrast >= 3:1): cyan, gold, violet, coral, blue, magenta -- in that fixed
order.  Status colours (good / warning / serious / critical) are reserved and
always paired with a text label.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.collections import PatchCollection  # noqa: E402
from matplotlib.patches import Polygon as MplPolygon, Rectangle  # noqa: E402

from .die_layout import SITE_LABELS, SiteClass  # noqa: E402

NAVY = "#0c1528"
PANEL = "#111d36"
GRID = "#22314f"
INK = "#eef2fa"
INK2 = "#a9b4cc"
MUTED = "#6b7a99"
GOLD_UI = "#d4af37"
SERIES = ["#1ba3c6", "#b5841a", "#8b78e8", "#d65f45", "#5b7ff0", "#c9559a"]
STATUS = {"good": "#3fb27f", "warning": "#e3b341", "serious": "#e8833a", "critical": "#e5484d", "neutral": "#4a5878"}
SEQ_CYAN = ["#0f2a3d", "#114a63", "#13708f", "#1ba3c6", "#6fd0e6", "#c4eef7"]

SITE_COLORS = {SiteClass.FULL_DIE: SERIES[0], SiteClass.PARTIAL: "#2a3754", SiteClass.EDGE_EXCLUDED: "#3c4a68",
               SiteClass.UNPRINTABLE: "#1a2440", SiteClass.VALID_TEST_SITE: SERIES[2]}
OUTCOME_COLORS = {-1: "#2a3754", 0: STATUS["neutral"], 1: STATUS["good"], 2: STATUS["warning"], 3: STATUS["serious"],
                  4: STATUS["critical"], 5: "#ff8fa3"}
OUTCOME_NAMES = {-1: "not eligible", 0: "untested", 1: "true good (pass)", 2: "conditional (hyp. repair)",
                 3: "good rejected", 4: "defective detected", 5: "defective ESCAPED"}


def style(ax, title: str = "", xlabel: str = "", ylabel: str = "") -> None:
    ax.set_facecolor(PANEL)
    for s in ax.spines.values():
        s.set_color(GRID)
    ax.tick_params(colors=INK2, labelsize=8)
    ax.grid(True, color=GRID, lw=0.6, alpha=0.8)
    ax.set_axisbelow(True)
    if title:
        ax.set_title(title, color=INK, fontsize=10, loc="left", pad=8)
    ax.set_xlabel(xlabel, color=INK2, fontsize=8)
    ax.set_ylabel(ylabel, color=INK2, fontsize=8)


def figure(w=8, h=5):
    fig, ax = plt.subplots(figsize=(w, h), dpi=130)
    fig.patch.set_facecolor(NAVY)
    return fig, ax


def stamp(fig, label: str = "SIMULATED") -> None:
    fig.text(0.995, 0.005, label, ha="right", va="bottom", color=GOLD_UI, fontsize=7, family="monospace",
             bbox=dict(boxstyle="round,pad=0.25", fc=NAVY, ec=GOLD_UI, lw=0.6))


def save(fig, path: Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, facecolor=fig.get_facecolor(), bbox_inches="tight")
    plt.close(fig)
    return path


def legend(ax, **kw):
    lg = ax.legend(frameon=False, fontsize=7, labelcolor=INK2, **kw)
    return lg


# --------------------------------------------------------------------------- wafer maps

def _wafer_outline(ax, geo):
    wp = geo.wafer_polygon()
    ax.add_patch(MplPolygon(np.asarray(wp.exterior.coords), closed=True, fc="#0e1a31", ec=INK2, lw=0.9, zorder=0))
    up = geo.usable_polygon()
    ax.add_patch(MplPolygon(np.asarray(up.exterior.coords), closed=True, fill=False, ec=GOLD_UI, lw=0.6, ls="--",
                            zorder=4))


def wafer_map(wmap, path: Path, layer: str = "geometry", payload: Optional[dict] = None, title: str = "",
              label: str = "SIMULATED") -> Path:
    fig, ax = plt.subplots(figsize=(7.2, 7.6), dpi=140)
    fig.patch.set_facecolor(NAVY)
    ax.set_facecolor(NAVY)
    _wafer_outline(ax, wmap.geometry)
    rects, colors = [], []
    s = payload["sites"] if payload else None
    for k in range(wmap.n_sites):
        rects.append(Rectangle((wmap.dx0[k], wmap.dy0[k]), wmap.dx1[k] - wmap.dx0[k], wmap.dy1[k] - wmap.dy0[k]))
        if layer == "geometry" or s is None:
            colors.append(SITE_COLORS[SiteClass(int(wmap.cls[k]))])
        elif layer == "outcome":
            colors.append(OUTCOME_COLORS[int(s["outcome"][k])])
        elif layer == "defects":
            n = s["defect_events"][k]
            colors.append(SEQ_CYAN[min(n, len(SEQ_CYAN) - 1)] if wmap.eligible[k] else "#1a2440")
        elif layer == "bins":
            b = s["bin"][k]
            colors.append({1: STATUS["good"], 4: STATUS["warning"], 5: STATUS["serious"], 6: STATUS["critical"],
                           7: SERIES[2], 8: STATUS["neutral"]}.get(b, "#1a2440"))
        else:
            colors.append(SITE_COLORS[SiteClass(int(wmap.cls[k]))])
    pc = PatchCollection(rects, facecolor=colors, edgecolor=NAVY, linewidth=0.15, zorder=2)
    ax.add_collection(pc)
    if wmap.reticle_enabled and layer == "geometry":
        nfx, nfy = wmap.dies_per_field
        px, py = wmap.pitch_mm
        ox, oy = wmap.offset_mm
        ret = wmap.reticle
        for fx, fy in sorted(set(zip(wmap.field_x.tolist(), wmap.field_y.tolist()))):
            x0 = (fx * nfx + ret.field_phase_x) * px + ox - px / 2
            y0 = (fy * nfy + ret.field_phase_y) * py + oy - py / 2
            ax.add_patch(Rectangle((x0, y0), nfx * px, nfy * py, fill=False, ec=GOLD_UI, lw=0.35, alpha=0.6, zorder=3))
    if payload and layer in ("defects", "outcome"):
        d = payload["defects"]
        if d["x"]:
            ax.scatter(d["x"], d["y"], s=3, c=INK, lw=0, zorder=5, alpha=0.85)
        for e in d["extended"]:
            for line in e["coords"]:
                a = np.asarray(line)
                ax.plot(a[:, 0], a[:, 1], color=SERIES[3], lw=1.0, zorder=6)
    R = wmap.geometry.R
    ax.set_xlim(-R * 1.04, R * 1.04)
    ax.set_ylim(-R * 1.04, R * 1.04)
    ax.set_aspect("equal")
    ax.tick_params(colors=INK2, labelsize=7)
    for sp in ax.spines.values():
        sp.set_color(GRID)
    ax.set_xlabel("x (mm)", color=INK2, fontsize=8)
    ax.set_ylabel("y (mm)", color=INK2, fontsize=8)
    ax.set_title(title or f"Wafer map - {layer}", color=INK, fontsize=10, loc="left")
    # legend
    from matplotlib.patches import Patch
    if layer == "geometry":
        handles = [Patch(fc=SITE_COLORS[c], ec=INK2, lw=0.3, label=f"{SITE_LABELS[c]} ({wmap.count(c)})") for c in SiteClass]
    elif layer == "outcome":
        vals = s["outcome"]
        handles = [Patch(fc=OUTCOME_COLORS[o], label=f"{OUTCOME_NAMES[o]} ({vals.count(o)})") for o in OUTCOME_COLORS]
    elif layer == "defects":
        handles = [Patch(fc=SEQ_CYAN[i], label=f"{i}{'+' if i == len(SEQ_CYAN) - 1 else ''} defect events")
                   for i in range(len(SEQ_CYAN))]
    else:
        handles = []
    if handles:
        ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, -0.08), ncol=3, frameon=False, fontsize=7,
                  labelcolor=INK2)
    stamp(fig, label)
    return save(fig, path)


def wafer_svg(wmap, path: Path, payload: Optional[dict] = None, layer: str = "geometry", label: str = "SIMULATED") -> Path:
    R = wmap.geometry.R
    sc = 4.0
    size = 2 * R * 1.05 * sc
    def tx(x):
        return (x + R * 1.05) * sc

    def ty(y):
        return (R * 1.05 - y) * sc
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size:.1f} {size:.1f}" width="{size:.0f}" '
           f'height="{size:.0f}" style="background:{NAVY}">']
    wp = np.asarray(wmap.geometry.wafer_polygon().exterior.coords)
    out.append('<polygon points="' + " ".join(f"{tx(x):.2f},{ty(y):.2f}" for x, y in wp)
               + f'" fill="#0e1a31" stroke="{INK2}" stroke-width="1"/>')
    s = payload["sites"] if payload else None
    for k in range(wmap.n_sites):
        if layer == "outcome" and s:
            col = OUTCOME_COLORS[int(s["outcome"][k])]
        else:
            col = SITE_COLORS[SiteClass(int(wmap.cls[k]))]
        w = (wmap.dx1[k] - wmap.dx0[k]) * sc
        h = (wmap.dy1[k] - wmap.dy0[k]) * sc
        out.append(f'<rect x="{tx(wmap.dx0[k]):.2f}" y="{ty(wmap.dy1[k]):.2f}" width="{w:.2f}" height="{h:.2f}" '
                   f'fill="{col}"><title>die ({int(wmap.ix[k])},{int(wmap.iy[k])}) '
                   f'{SITE_LABELS[SiteClass(int(wmap.cls[k]))]}</title></rect>')
    out.append(f'<text x="{size - 8:.0f}" y="{size - 8:.0f}" fill="{GOLD_UI}" font-family="monospace" font-size="14" '
               f'text-anchor="end">{label}</text></svg>')
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text("\n".join(out))
    return Path(path)


def wafer_json(wmap, path: Path, meta: dict) -> Path:
    data = {"meta": meta, "convention": "eligible = FULL DIE only (see docs/MODELS.md section 1)",
            "counts": wmap.counts(), "sites": wmap.to_records()}
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(data, indent=1))
    return Path(path)


# --------------------------------------------------------------------------- analysis charts

def yield_vs_area(rows: list[dict], path: Path, d0: float, alpha: float, marker_area: Optional[float] = None,
                  label: str = "ANALYTICAL - HYPOTHETICAL D0") -> Path:
    fig, ax = figure(8, 4.8)
    a = [r["area_cm2"] for r in rows]
    keys = [k for k in rows[0] if k != "area_cm2"]
    for i, k in enumerate(keys):
        ax.plot(a, [r[k] for r in rows], color=SERIES[i % len(SERIES)], lw=2, label=k)
    if marker_area:
        ax.axvline(marker_area, color=GOLD_UI, lw=1, ls=":")
        ax.text(marker_area, 0.02, " SilicaFlux-V die", color=GOLD_UI, fontsize=7, rotation=90, va="bottom")
    style(ax, f"Defect-limited yield vs effective area (D0 = {d0} /cm^2, alpha = {alpha})",
          "effective defect-sensitive area (cm^2)", "P(zero fatal defects)")
    ax.set_ylim(0, 1.02)
    legend(ax, loc="lower left")
    stamp(fig, label)
    return save(fig, path)


def histogram_with_intervals(x, path: Path, title: str, xlabel: str, ci: tuple, pi: tuple,
                             label: str = "SIMULATED") -> Path:
    fig, ax = figure(8, 4.2)
    ax.hist(x, bins=40, color=SERIES[0], edgecolor=PANEL, lw=1.5)
    ax.axvspan(pi[0], pi[1], color=SERIES[2], alpha=0.12, label=f"90% predictive interval, next wafer [{pi[0]:.0f}, {pi[1]:.0f}]")
    ax.axvline(np.mean(x), color=GOLD_UI, lw=1.5, label=f"mean {np.mean(x):.1f}; 95% CI of mean [{ci[0]:.1f}, {ci[1]:.1f}]")
    style(ax, title, xlabel, "wafers")
    legend(ax, loc="upper left")
    stamp(fig, label)
    return save(fig, path)


def lot_boxplot(df, value: str, path: Path, title: str, label: str = "SIMULATED") -> Path:
    fig, ax = figure(9, 4.2)
    lots = sorted(df["lot"].unique())
    data = [df.loc[df["lot"] == l, value].to_numpy() for l in lots]
    bp = ax.boxplot(data, patch_artist=True, widths=0.55)
    for b in bp["boxes"]:
        b.set(facecolor=SERIES[0], edgecolor=INK2, alpha=0.85)
    for k in ("whiskers", "caps", "medians", "fliers"):
        for el in bp[k]:
            el.set(color=INK2 if k != "medians" else GOLD_UI)
    ax.set_xticks(range(1, len(lots) + 1), [f"lot {l}" for l in lots])
    style(ax, title, "", value.replace("_", " "))
    stamp(fig, label)
    return save(fig, path)


def convergence_plot(conv: dict, path: Path, title: str, label: str = "SIMULATED") -> Path:
    fig, ax = figure(8, 3.6)
    rm = np.asarray(conv["running_mean"])
    ax.plot(np.arange(1, len(rm) + 1), rm, color=SERIES[0], lw=2)
    ax.axhline(conv["mean"], color=GOLD_UI, lw=1, ls=":")
    style(ax, f"{title} - {conv['status']} (rel. MCSE {conv['relative_mcse']:.4f}, n = {conv['n']})",
          f"number of simulated {conv['unit']}s", "running mean")
    stamp(fig, label)
    return save(fig, path)


def hbar(names: list[str], values: list[float], path: Path, title: str, xlabel: str, label: str = "SIMULATED",
         color: str = SERIES[0]) -> Path:
    fig, ax = figure(8, max(2.5, 0.32 * len(names) + 1))
    y = np.arange(len(names))
    ax.barh(y, values, color=color, height=0.62, edgecolor=PANEL)
    ax.set_yticks(y, names)
    ax.invert_yaxis()
    for yi, v in zip(y, values):
        ax.text(v, yi, f" {v:,.3g}", va="center", color=INK2, fontsize=7)
    style(ax, title, xlabel)
    ax.grid(axis="y", visible=False)
    stamp(fig, label)
    return save(fig, path)


def tornado_plot(rows: list[dict], path: Path, currency: str, label: str) -> Path:
    fig, ax = figure(8, max(2.5, 0.4 * len(rows) + 1))
    base = rows[0]["base"] if rows else 0
    y = np.arange(len(rows))
    for i, r in enumerate(rows):
        ax.barh(i, r["low"] - base, left=base, color=SERIES[0], height=0.6)
        ax.barh(i, r["high"] - base, left=base, color=SERIES[3], height=0.6)
    ax.axvline(base, color=GOLD_UI, lw=1)
    ax.set_yticks(y, [r["item"] for r in rows])
    ax.invert_yaxis()
    style(ax, "Cost per delivered conforming die: +/-25 % one-at-a-time sensitivity", f"{currency} per die")
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(fc=SERIES[0], label="input -25 %"), Patch(fc=SERIES[3], label="input +25 %")],
              frameon=False, fontsize=7, labelcolor=INK2, loc="lower right")
    stamp(fig, label)
    return save(fig, path)


def scatter_pareto(rows: list[dict], front: list[int], x: str, y: str, path: Path, title: str, label: str) -> Path:
    fig, ax = figure(8, 5)
    xs = [r[x] for r in rows]
    ys = [r[y] for r in rows]
    meas = [i for i, r in enumerate(rows) if r["evidence"].startswith("MEASURED")]
    est = [i for i, r in enumerate(rows) if not r["evidence"].startswith("MEASURED")]
    ax.scatter([xs[i] for i in meas], [ys[i] for i in meas], s=40, c=SERIES[0], marker="o",
               edgecolor=PANEL, lw=1.5, label="FloorplanLab run (measured die)")
    ax.scatter([xs[i] for i in est], [ys[i] for i in est], s=50, c=SERIES[1], marker="^",
               edgecolor=PANEL, lw=1.5, label="architecture variant (ESTIMATED die)")
    fr = sorted(front, key=lambda i: xs[i])
    ax.plot([xs[i] for i in fr], [ys[i] for i in fr], color=GOLD_UI, lw=1.2, ls="--", label="non-dominated set")
    for i in fr:
        ax.annotate(rows[i]["candidate"].split(":")[1], (xs[i], ys[i]), fontsize=6.5, color=INK2,
                    xytext=(4, 4), textcoords="offset points")
    style(ax, title, x.replace("_", " "), y.replace("_", " "))
    legend(ax, loc="best")
    stamp(fig, label)
    return save(fig, path)


def lines(xs, series: dict[str, list], path: Path, title: str, xlabel: str, ylabel: str, label: str,
          logy: bool = False) -> Path:
    fig, ax = figure(8, 4.5)
    for i, (name, ys) in enumerate(series.items()):
        ax.plot(xs, ys, color=SERIES[i % len(SERIES)], lw=2, marker="o", ms=4, label=name)
    if logy:
        ax.set_yscale("log")
    style(ax, title, xlabel, ylabel)
    legend(ax, loc="best")
    stamp(fig, label)
    return save(fig, path)


def param_scatter(fmax, leak, ok, path: Path, spec_f: float, spec_l: float, label: str) -> Path:
    fig, ax = figure(7, 5)
    fmax, leak, ok = np.asarray(fmax), np.asarray(leak), np.asarray(ok, bool)
    ax.scatter(fmax[ok], leak[ok], s=4, c=SERIES[0], lw=0, alpha=0.6, label="in spec")
    ax.scatter(fmax[~ok], leak[~ok], s=10, c=STATUS["critical"], marker="x", lw=0.8, label="out of spec")
    ax.axvline(spec_f, color=GOLD_UI, lw=1, ls=":")
    ax.axhline(spec_l, color=GOLD_UI, lw=1, ls=":")
    style(ax, "Parametric scatter (HYPOTHETICAL distributions)", "Fmax (MHz)", "leakage (uA)")
    legend(ax, loc="upper left")
    stamp(fig, label)
    return save(fig, path)
