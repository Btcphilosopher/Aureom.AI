"""Gross die per wafer: geometry-derived count versus analytical approximations.

The **geometry count** (``die_layout.layout_wafer``) is the authoritative number
for a fully specified configuration (die size, scribe, grid translation,
reticle plan, edge exclusion, notch / flat, exclusion zones).

The approximations below are *only* for quick feasibility estimates and sanity
checks.  None of them knows about the grid translation, the reticle plan, the
notch or exclusion zones, so they are expected to differ from the geometry
count; the difference is reported, never hidden.

* ``area_ratio``          N = pi R_u^2 / S                       (upper bound, ignores edge loss)
* ``edge_corrected``      N = pi d^2 / (4 S) - pi d / sqrt(2 S)  (the commonly quoted textbook
                          approximation; d = usable diameter, S = die pitch area)
* ``row_chord``           semi-analytical: for every row of the grid (fixed y translation) count
                          floor(chord / pitch_x) where the chord is the usable width at the row's
                          worse edge.  Lets every row choose its own x alignment, so it is an
                          upper bound on the fixed-grid count for a plain disc.
"""
from __future__ import annotations

import math

import numpy as np

from .die_layout import DieSpec


def area_ratio(usable_radius_mm: float, pitch_x_mm: float, pitch_y_mm: float) -> float:
    s = pitch_x_mm * pitch_y_mm
    return math.pi * usable_radius_mm**2 / s


def edge_corrected(usable_radius_mm: float, pitch_x_mm: float, pitch_y_mm: float) -> float:
    s = pitch_x_mm * pitch_y_mm
    d = 2.0 * usable_radius_mm
    return max(0.0, math.pi * d * d / (4.0 * s) - math.pi * d / math.sqrt(2.0 * s))


def row_chord(usable_radius_mm: float, pitch_x_mm: float, pitch_y_mm: float, offset_y_mm: float = 0.0,
              cell_w_mm: float | None = None, cell_h_mm: float | None = None) -> int:
    """Row-by-row chord count for a disc of radius ``usable_radius_mm``.

    ``cell_*`` is the rectangle that must fit (default: the pitch cell).
    """
    r = usable_radius_mm
    cw = pitch_x_mm if cell_w_mm is None else cell_w_mm
    ch = pitch_y_mm if cell_h_mm is None else cell_h_mm
    n = 0
    jmax = int(math.ceil((r + abs(offset_y_mm)) / pitch_y_mm)) + 1
    for j in range(-jmax, jmax + 1):
        yc = offset_y_mm + j * pitch_y_mm
        y_far = max(abs(yc - ch / 2), abs(yc + ch / 2))
        if y_far >= r:
            continue
        chord = 2.0 * math.sqrt(r * r - y_far * y_far)
        if chord < cw:
            continue
        # k cells + (k-1) gaps of (pitch - cell) must fit in the chord
        k = int(math.floor((chord + (pitch_x_mm - cw)) / pitch_x_mm + 1e-12))
        n += max(k, 0)
    return n


def compare(geometry_count: int, usable_radius_mm: float, die: DieSpec, footprint_w_mm: float,
            footprint_h_mm: float, offset_y_mm: float = 0.0) -> list[dict]:
    px, py = die.pitch_x_mm, die.pitch_y_mm
    rows = []
    for name, val, kind in (
        ("area_ratio", area_ratio(usable_radius_mm, px, py), "approximation (upper bound)"),
        ("edge_corrected", edge_corrected(usable_radius_mm, px, py), "approximation"),
        ("row_chord", float(row_chord(usable_radius_mm, px, py, offset_y_mm, footprint_w_mm, footprint_h_mm)),
         "semi-analytical upper bound (disc only)"),
    ):
        rows.append(
            {
                "method": name,
                "kind": kind,
                "value": val,
                "geometry_count": geometry_count,
                "difference": val - geometry_count,
                "relative_difference": (val - geometry_count) / geometry_count if geometry_count else float("nan"),
            }
        )
    return rows


def area_accounting(wmap, wafer_area_mm2: float, usable_area_mm2: float) -> dict:
    """Where the wafer area goes (mm^2).  All terms add up to the physical wafer area."""
    from .die_layout import SiteClass

    die_area = wmap.die_mm[0] * wmap.die_mm[1]
    cell_area = wmap.pitch_mm[0] * wmap.pitch_mm[1]
    full = wmap.count(SiteClass.FULL_DIE)
    test = wmap.count(SiteClass.VALID_TEST_SITE)
    full_die_area = full * die_area
    full_street = full * (cell_area - die_area)
    test_area = test * cell_area
    edge_band = wafer_area_mm2 - usable_area_mm2
    # usable area not covered by eligible / test pitch cells: partial cells along the usable boundary,
    # unprintable fields, exclusion zones
    other_usable = usable_area_mm2 - (full + test) * cell_area
    return {
        "wafer_area_mm2": wafer_area_mm2,
        "edge_exclusion_and_notch_area_mm2": edge_band,
        "usable_area_mm2": usable_area_mm2,
        "eligible_die_silicon_area_mm2": full_die_area,
        "eligible_die_street_area_mm2": full_street,
        "test_site_area_mm2": test_area,
        "usable_area_not_in_full_sites_mm2": other_usable,
        "die_area_utilisation_of_wafer": full_die_area / wafer_area_mm2,
        "geometric_loss_fraction": 1.0 - full_die_area / wafer_area_mm2,
    }
