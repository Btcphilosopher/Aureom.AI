r"""Defect-to-failure (fatality) models.

A physical defect inside a die is not automatically a functional failure.  The
active model -- recorded in every run -- decides the kill probability of each
defect hit:

``all_fatal``      every defect that intersects a die (any region, incl. pads and whitespace) is
                   fatal.  Simplified baseline; with it the configured density *is* the fatal D0.
``class_kill``     P(kill) = k[class]
``region_class``   P(kill) = k[region kind or region name][class]   (region overrides kind)
``critical_area``  size-dependent parallel-wire model per region kind:
                     P_short(x) = rho * clip((x - s) / (w + s), 0, 1)
                     P_open(x)  = rho * clip((x - w) / (w + s), 0, 1)
                     P(kill)    = 1 - (1 - P_short)(1 - P_open)
                   with wire width w, space s (um) and critical-pattern density rho.  The (w, s, rho)
                   values are HYPOTHETICAL: no layout critical-area extraction exists for SilicaFlux-V.

``severity_scaling: true`` multiplies the kill probability by the defect severity.
Fatal SRAM-macro hits are then given a fault type (bit / row / column /
decoder / periphery) by :mod:`yieldlab.memory_repair`.
"""
from __future__ import annotations

from typing import Literal, Optional

import numpy as np
from pydantic import BaseModel, ConfigDict, Field


class WirePattern(BaseModel):
    model_config = ConfigDict(extra="forbid")
    width_um: float = Field(gt=0)
    space_um: float = Field(gt=0)
    density: float = Field(ge=0, le=1)


class FatalityModel(BaseModel):
    model_config = ConfigDict(extra="forbid")
    mode: Literal["all_fatal", "class_kill", "region_class", "critical_area"] = "all_fatal"
    source: str = "HYPOTHETICAL"
    reference: str = "hypothetical kill probabilities; no SilicaFlux defect-to-failure data exists"
    class_kill: dict[str, float] = Field(default_factory=dict)
    region_kill: dict[str, dict[str, float]] = Field(default_factory=dict,
                                                     description="key = region kind or region name")
    default_kill: float = Field(1.0, ge=0, le=1)
    critical_area: dict[str, WirePattern] = Field(default_factory=dict, description="key = region kind or name")
    severity_scaling: bool = False

    def kill_probability(self, region_names: list[str], region_kinds: list[str], classes: list[str],
                         rid: np.ndarray, cls: np.ndarray, size_um: np.ndarray, severity: np.ndarray) -> np.ndarray:
        n = rid.size
        if self.mode == "all_fatal":
            p = np.ones(n)
        elif self.mode == "class_kill":
            table = np.array([self.class_kill.get(c, self.default_kill) for c in classes])
            p = table[cls] if n else np.zeros(0)
        elif self.mode == "region_class":
            R, C = len(region_names), len(classes)
            table = np.full((R, C), self.default_kill)
            for r in range(R):
                for key in (region_kinds[r], region_names[r]):       # name overrides kind
                    if key in self.region_kill:
                        for c in range(C):
                            if classes[c] in self.region_kill[key]:
                                table[r, c] = self.region_kill[key][classes[c]]
            p = table[rid, cls] if n else np.zeros(0)
        else:
            p = np.zeros(n)
            for r, (name, kind) in enumerate(zip(region_names, region_kinds)):
                pat: Optional[WirePattern] = self.critical_area.get(name) or self.critical_area.get(kind)
                sel = rid == r
                if pat is None or not sel.any():
                    continue
                x = size_um[sel]
                pitch = pat.width_um + pat.space_um
                ps = pat.density * np.clip((x - pat.space_um) / pitch, 0.0, 1.0)
                po = pat.density * np.clip((x - pat.width_um) / pitch, 0.0, 1.0)
                p[sel] = 1.0 - (1.0 - ps) * (1.0 - po)
        if self.severity_scaling:
            p = p * severity
        return np.clip(p, 0.0, 1.0)

    def mean_kill_area(self, region_table: list[dict], size_samples: np.ndarray, classes: list[str],
                       class_weights: np.ndarray) -> float:
        """Effective defect-sensitive fraction of the die (for the analytical comparison).

        sum_r (area_r / die) * E[P(kill)] over the class mix and size distribution.
        """
        names = [r["region"] for r in region_table]
        kinds = [r["kind"] for r in region_table]
        total = sum(r["located_area_mm2"] for r in region_table)
        frac = 0.0
        m = size_samples.size
        for ri, r in enumerate(region_table):
            w_r = r["located_area_mm2"] / total
            for ci, c in enumerate(classes):
                if class_weights[ci] == 0:
                    continue
                pk = self.kill_probability(names, kinds, classes, np.full(m, ri), np.full(m, ci), size_samples,
                                           np.ones(m))
                frac += w_r * class_weights[ci] * float(pk.mean())
        return frac
