r"""Parametric (electrical) yield and wafer-level process variation.

Each electrical parameter of a die is modelled hierarchically (in value units
for ``normal``, in natural-log units for ``lognormal``):

    v(die) = m + L(lot) + W(wafer) + c (r / R)^p + S(x, y) + T(reticle slot) + e(die)

* L ~ N(0, lot_sd^2), shared by all wafers of a lot;  W ~ N(0, wafer_sd^2) per wafer
* c (r/R)^p: systematic radial term (bowl / dome)
* S: zero-mean Gaussian random field (sd ``spatial_sd``, correlation length ``corr_length_mm``)
* T: systematic within-field offset, one value per reticle slot, drawn ONCE per run
  (a lens / mask signature is not re-randomised per wafer)
* e ~ N(0, die_sd^2); the die-level terms of different parameters are correlated
  through ``die_correlation`` (e.g. fast dies leak more)

**No SilicaFlux statistical process data exists.**  TimingFlow and FloorplanLab
provide deterministic PVT-corner timing only (typ / slow / fast Liberty) and a
corner is not a probability distribution, so every parametric configuration in
this repository is HYPOTHETICAL and its results are labelled so.  Parametric
failures are reported separately from random-defect failures; a die that has a
functional failure is classified as a functional failure first, so the same
die is never counted twice.
"""
from __future__ import annotations

from typing import Literal, Optional

import numpy as np
from pydantic import BaseModel, ConfigDict, Field, model_validator

from .random_fields import GaussianField


class ParamDef(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str
    unit: str
    distribution: Literal["normal", "lognormal"] = "normal"
    centre: float = Field(description="normal: mean; lognormal: median value")
    die_sd: float = Field(0.0, ge=0)
    wafer_sd: float = Field(0.0, ge=0)
    lot_sd: float = Field(0.0, ge=0)
    radial_coef: float = 0.0
    radial_power: float = Field(2.0, gt=0)
    spatial_sd: float = Field(0.0, ge=0)
    corr_length_mm: float = Field(20.0, gt=0)
    reticle_slot_sd: float = Field(0.0, ge=0)
    spec_min: Optional[float] = None
    spec_max: Optional[float] = None
    spec_source: str = "HYPOTHETICAL"
    measurement_sd: float = Field(0.0, ge=0, description="gauge noise, value units")


class SpeedGrade(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str
    parameter: str
    min: float
    product_defined: bool = False
    reference: str = ""


class ParametricModel(BaseModel):
    model_config = ConfigDict(extra="forbid")
    enabled: bool = True
    source: str = "HYPOTHETICAL"
    reference: str = "hypothetical parametric distributions; no SilicaFlux statistical process data"
    parameters: list[ParamDef] = Field(default_factory=list)
    die_correlation: Optional[list[list[float]]] = None
    speed_grades: list[SpeedGrade] = Field(default_factory=list)

    @model_validator(mode="after")
    def _check(self) -> "ParametricModel":
        k = len(self.parameters)
        if self.die_correlation is not None:
            c = np.asarray(self.die_correlation, float)
            if c.shape != (k, k) or not np.allclose(c, c.T) or np.any(np.diag(c) != 1):
                raise ValueError("die_correlation must be a symmetric k x k matrix with unit diagonal")
            if np.min(np.linalg.eigvalsh(c)) < -1e-10:
                raise ValueError("die_correlation is not positive semi-definite")
        names = [p.name for p in self.parameters]
        for g in self.speed_grades:
            if g.parameter not in names:
                raise ValueError(f"speed grade {g.name} uses unknown parameter {g.parameter}")
        return self

    def names(self) -> list[str]:
        return [p.name for p in self.parameters]

    def by_name(self, name: str) -> ParamDef:
        for p in self.parameters:
            if p.name == name:
                return p
        raise KeyError(name)

    def reticle_offsets(self, n_slots: tuple[int, int], rng: np.random.Generator) -> dict[str, np.ndarray]:
        return {p.name: rng.normal(0.0, p.reticle_slot_sd, n_slots) if p.reticle_slot_sd > 0 else np.zeros(n_slots)
                for p in self.parameters}

    def lot_effects(self, rng: np.random.Generator) -> dict[str, float]:
        return {p.name: float(rng.normal(0.0, p.lot_sd)) if p.lot_sd > 0 else 0.0 for p in self.parameters}

    def sample(self, x_mm: np.ndarray, y_mm: np.ndarray, radius_mm: float, slot_x: np.ndarray, slot_y: np.ndarray,
               reticle_offsets: dict[str, np.ndarray], lot_effect: dict[str, float],
               rng: np.random.Generator) -> dict[str, np.ndarray]:
        n = x_mm.size
        k = len(self.parameters)
        if k == 0:
            return {}
        z = rng.standard_normal((n, k))
        if self.die_correlation is not None:
            L = np.linalg.cholesky(np.asarray(self.die_correlation) + 1e-12 * np.eye(k))
            z = z @ L.T
        r = np.hypot(x_mm, y_mm) / radius_mm
        out = {}
        for j, p in enumerate(self.parameters):
            base = np.log(p.centre) if p.distribution == "lognormal" else p.centre
            v = base + lot_effect.get(p.name, 0.0)
            if p.wafer_sd > 0:
                v = v + rng.normal(0.0, p.wafer_sd)
            v = v + p.radial_coef * r ** p.radial_power
            if p.spatial_sd > 0:
                field = GaussianField(radius_mm, p.corr_length_mm, rng)
                v = v + p.spatial_sd * field(x_mm, y_mm)
            ro = reticle_offsets.get(p.name)
            if ro is not None and ro.size > 1:
                v = v + ro[np.clip(slot_x, 0, ro.shape[0] - 1), np.clip(slot_y, 0, ro.shape[1] - 1)]
            v = v + p.die_sd * z[:, j]
            out[p.name] = np.exp(v) if p.distribution == "lognormal" else v
        return out

    def in_spec(self, name: str, values: np.ndarray) -> np.ndarray:
        p = self.by_name(name)
        ok = np.ones(values.shape, bool)
        if p.spec_min is not None:
            ok &= values >= p.spec_min
        if p.spec_max is not None:
            ok &= values <= p.spec_max
        return ok

    def all_in_spec(self, values: dict[str, np.ndarray], n: int) -> np.ndarray:
        ok = np.ones(n, bool)
        for name, v in values.items():
            ok &= self.in_spec(name, v)
        return ok


class Measurement:
    """Gauge model: measured = true + N(0, measurement_sd^2)."""

    def __init__(self, model: ParametricModel):
        self.model = model

    def __call__(self, name: str, true: np.ndarray, rng: np.random.Generator) -> np.ndarray:
        sd = self.model.by_name(name).measurement_sd
        return true + rng.normal(0.0, sd, true.shape) if sd > 0 else true.copy()

    def in_spec(self, name: str, values: np.ndarray) -> np.ndarray:
        return self.model.in_spec(name, values)


def speed_grade(model: ParametricModel, measured: dict[str, np.ndarray], n: int) -> np.ndarray:
    """Highest grade whose minimum the *measured* value meets; '' if none / not defined."""
    grade = np.full(n, "", dtype=object)
    for g in model.speed_grades:
        if not g.product_defined:
            continue
        v = measured.get(g.parameter)
        if v is None:
            continue
        sel = (grade == "") & (v >= g.min)
        grade[sel] = g.name
    return grade
