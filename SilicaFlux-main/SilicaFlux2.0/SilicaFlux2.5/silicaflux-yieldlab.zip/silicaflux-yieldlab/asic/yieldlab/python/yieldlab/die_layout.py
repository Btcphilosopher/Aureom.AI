"""Die grid placement, reticle step-and-repeat and site classification.

Site classification convention (documented in docs/MODELS.md, section 1):

=====================  ===================================================================
class                  rule (evaluated in this order)
=====================  ===================================================================
UNPRINTABLE            site touches the wafer but its reticle field is not exposed by the
                       stepping plan, or its footprint overlaps a layout exclusion zone
PARTIAL                required footprint is not entirely on the physical wafer
EDGE_EXCLUDED          footprint on the wafer but overlaps the edge-exclusion band or the
                       notch keep-out
VALID_TEST_SITE        full site reserved for process-control / test structures
FULL_DIE               everything else: full footprint inside the usable area
=====================  ===================================================================

Only FULL_DIE sites are *eligible* for yield calculations.  Candidate grid
positions that do not touch the wafer at all are not sites and are not stored.

The "required footprint" is configurable (``footprint``):

* ``die``                   -- the die outline only (seal ring included in the die size);
* ``die_plus_half_street``  -- the die plus half a scribe street on every side, i.e. the
                               step-and-repeat cell owned by the die (default);
* ``die_plus_full_street``  -- the die plus a full street on every side (most conservative).
"""
from __future__ import annotations

from enum import IntEnum
from typing import Literal, Optional

import numpy as np
from pydantic import BaseModel, ConfigDict, Field, model_validator

from .provenance import Source
from .wafer_geometry import WaferGeometry, WaferSpec


class SiteClass(IntEnum):
    FULL_DIE = 0
    PARTIAL = 1
    EDGE_EXCLUDED = 2
    UNPRINTABLE = 3
    VALID_TEST_SITE = 4


SITE_LABELS = {
    SiteClass.FULL_DIE: "FULL DIE",
    SiteClass.PARTIAL: "PARTIAL / EDGE-STRADDLING",
    SiteClass.EDGE_EXCLUDED: "EDGE-EXCLUDED",
    SiteClass.UNPRINTABLE: "UNPRINTABLE",
    SiteClass.VALID_TEST_SITE: "VALID TEST SITE",
}

Footprint = Literal["die", "die_plus_half_street", "die_plus_full_street"]


class DieSpec(BaseModel):
    """Physical die outline and scribe allowance (micrometres)."""

    model_config = ConfigDict(extra="forbid")
    name: str
    width_um: float = Field(gt=0)
    height_um: float = Field(gt=0)
    source: Source
    reference: str
    scribe_x_um: float = Field(ge=0)
    scribe_y_um: float = Field(ge=0)
    scribe_source: Source = Source.HYPOTHETICAL
    scribe_reference: str = "hypothetical scribe street; no foundry design rule supplied"
    rotation_deg: Literal[0, 90] = 0

    @property
    def w_um(self) -> float:
        return self.height_um if self.rotation_deg == 90 else self.width_um

    @property
    def h_um(self) -> float:
        return self.width_um if self.rotation_deg == 90 else self.height_um

    @property
    def sx_um(self) -> float:
        return self.scribe_y_um if self.rotation_deg == 90 else self.scribe_x_um

    @property
    def sy_um(self) -> float:
        return self.scribe_x_um if self.rotation_deg == 90 else self.scribe_y_um

    @property
    def pitch_x_mm(self) -> float:
        return (self.w_um + self.sx_um) / 1000.0

    @property
    def pitch_y_mm(self) -> float:
        return (self.h_um + self.sy_um) / 1000.0

    @property
    def area_mm2(self) -> float:
        return self.width_um * self.height_um / 1e6

    @property
    def area_cm2(self) -> float:
        return self.width_um * self.height_um / 1e8

    @property
    def pitch_area_mm2(self) -> float:
        return self.pitch_x_mm * self.pitch_y_mm


class ReticleSpec(BaseModel):
    """Step-and-repeat field definition.

    ``max_field_*`` is the exposure-tool field limit (26 x 33 mm is typical of
    current scanners -- a hypothetical default here, confirm with the foundry).
    The number of dies per field is the largest array whose dies *and*
    inter-die streets fit inside the field, unless given explicitly.
    """

    model_config = ConfigDict(extra="forbid")
    enabled: bool = True
    max_field_w_mm: float = Field(26.0, gt=0)
    max_field_h_mm: float = Field(33.0, gt=0)
    field_source: Source = Source.HYPOTHETICAL
    field_reference: str = "typical scanner field limit; confirm the reticle size with the foundry"
    dies_per_field_x: Optional[int] = Field(default=None, ge=1)
    dies_per_field_y: Optional[int] = Field(default=None, ge=1)
    field_phase_x: int = 0
    field_phase_y: int = 0
    stepping: Literal["all_intersecting", "fields_with_full_die", "full_fields_only"] = "all_intersecting"
    test_site_slots: list[tuple[int, int]] = Field(default_factory=list,
                                                   description="(slot_x, slot_y) inside every field reserved for test structures")
    excluded_fields: list[tuple[int, int]] = Field(default_factory=list)


class LayoutSpec(BaseModel):
    model_config = ConfigDict(extra="forbid")
    footprint: Footprint = "die_plus_half_street"
    offset_x_mm: float = 0.0
    offset_y_mm: float = 0.0
    grid_origin: Literal["die_centred", "street_centred", "explicit"] = "die_centred"
    test_site_dies: list[tuple[int, int]] = Field(default_factory=list)

    @model_validator(mode="after")
    def _origin(self) -> "LayoutSpec":
        return self


class WaferMap:
    """All die sites of one wafer layout (struct of arrays, mm)."""

    def __init__(self, **arrays):
        self.__dict__.update(arrays)

    # attributes set by layout_wafer: ix, iy, cx, cy, dx0, dy0, dx1, dy1 (die), fx0, fy0, fx1, fy1
    # (footprint), cls, field_x, field_y, slot_x, slot_y, edge_dist, eligible, plus meta

    @property
    def n_sites(self) -> int:
        return int(self.ix.size)

    def count(self, cls: SiteClass) -> int:
        return int(np.count_nonzero(self.cls == cls))

    def counts(self) -> dict[str, int]:
        return {SITE_LABELS[c]: self.count(c) for c in SiteClass}

    @property
    def n_full(self) -> int:
        return self.count(SiteClass.FULL_DIE)

    def eligible_index(self) -> np.ndarray:
        return np.nonzero(self.eligible)[0]

    def to_records(self) -> list[dict]:
        out = []
        for k in range(self.n_sites):
            out.append(
                {
                    "die_ix": int(self.ix[k]),
                    "die_iy": int(self.iy[k]),
                    "centre_mm": [round(float(self.cx[k]), 6), round(float(self.cy[k]), 6)],
                    "die_bbox_mm": [round(float(v), 6) for v in (self.dx0[k], self.dy0[k], self.dx1[k], self.dy1[k])],
                    "footprint_bbox_mm": [round(float(v), 6) for v in (self.fx0[k], self.fy0[k], self.fx1[k], self.fy1[k])],
                    "site_class": SITE_LABELS[SiteClass(int(self.cls[k]))],
                    "reticle_field": [int(self.field_x[k]), int(self.field_y[k])] if self.reticle_enabled else None,
                    "reticle_slot": [int(self.slot_x[k]), int(self.slot_y[k])] if self.reticle_enabled else None,
                    "edge_distance_mm": round(float(self.edge_dist[k]), 6),
                    "eligible": bool(self.eligible[k]),
                }
            )
        return out


def dies_per_field(die: DieSpec, ret: ReticleSpec) -> tuple[int, int]:
    if ret.dies_per_field_x and ret.dies_per_field_y:
        nx, ny = ret.dies_per_field_x, ret.dies_per_field_y
    else:
        # n dies + (n-1) streets <= field  ->  n <= (field + street) / pitch
        nx = int(np.floor((ret.max_field_w_mm + die.sx_um / 1000) / die.pitch_x_mm + 1e-9))
        ny = int(np.floor((ret.max_field_h_mm + die.sy_um / 1000) / die.pitch_y_mm + 1e-9))
    if nx < 1 or ny < 1:
        raise ValueError(
            f"die {die.name} ({die.w_um} x {die.h_um} um) does not fit in the reticle field "
            f"{ret.max_field_w_mm} x {ret.max_field_h_mm} mm"
        )
    fw = nx * die.pitch_x_mm - die.sx_um / 1000
    fh = ny * die.pitch_y_mm - die.sy_um / 1000
    if fw > ret.max_field_w_mm + 1e-9 or fh > ret.max_field_h_mm + 1e-9:
        raise ValueError(f"{nx} x {ny} dies ({fw:.3f} x {fh:.3f} mm) exceed the reticle field limit")
    return nx, ny


def _grid_offset(die: DieSpec, lay: LayoutSpec) -> tuple[float, float]:
    if lay.grid_origin == "die_centred":
        base = (0.0, 0.0)
    elif lay.grid_origin == "street_centred":
        base = (die.pitch_x_mm / 2, die.pitch_y_mm / 2)
    else:
        base = (0.0, 0.0)
    return base[0] + lay.offset_x_mm, base[1] + lay.offset_y_mm


def layout_wafer(wafer: WaferSpec | WaferGeometry, die: DieSpec, reticle: Optional[ReticleSpec] = None,
                 layout: Optional[LayoutSpec] = None) -> WaferMap:
    geo = wafer if isinstance(wafer, WaferGeometry) else WaferGeometry(wafer)
    reticle = reticle or ReticleSpec(enabled=False)
    layout = layout or LayoutSpec()
    px, py = die.pitch_x_mm, die.pitch_y_mm
    w, h = die.w_um / 1000, die.h_um / 1000
    sx, sy = die.sx_um / 1000, die.sy_um / 1000
    ox, oy = _grid_offset(die, layout)
    R = geo.R
    nmax_x = int(np.ceil((R + abs(ox)) / px)) + 2
    nmax_y = int(np.ceil((R + abs(oy)) / py)) + 2
    I, J = np.meshgrid(np.arange(-nmax_x, nmax_x + 1), np.arange(-nmax_y, nmax_y + 1))
    I, J = I.ravel(), J.ravel()
    cx = ox + I * px
    cy = oy + J * py
    dx0, dx1 = cx - w / 2, cx + w / 2
    dy0, dy1 = cy - h / 2, cy + h / 2
    if layout.footprint == "die":
        mx, my = 0.0, 0.0
    elif layout.footprint == "die_plus_half_street":
        mx, my = sx / 2, sy / 2
    else:
        mx, my = sx, sy
    fx0, fx1, fy0, fy1 = dx0 - mx, dx1 + mx, dy0 - my, dy1 + my

    touches = geo.intersects_physical(fx0, fy0, fx1, fy1)
    keep = np.nonzero(touches)[0]
    I, J, cx, cy = I[keep], J[keep], cx[keep], cy[keep]
    dx0, dx1, dy0, dy1 = dx0[keep], dx1[keep], dy0[keep], dy1[keep]
    fx0, fx1, fy0, fy1 = fx0[keep], fx1[keep], fy0[keep], fy1[keep]

    on_wafer = geo.contains_physical(fx0, fy0, fx1, fy1)
    usable = geo.contains_usable(fx0, fy0, fx1, fy1)
    in_zone = geo.hits_exclusion_zone(fx0, fy0, fx1, fy1)

    n = I.size
    field_x = np.zeros(n, dtype=int)
    field_y = np.zeros(n, dtype=int)
    slot_x = np.zeros(n, dtype=int)
    slot_y = np.zeros(n, dtype=int)
    exposed = np.ones(n, dtype=bool)
    nfx = nfy = 1
    if reticle.enabled:
        nfx, nfy = dies_per_field(die, reticle)
        rel_x = I - reticle.field_phase_x
        rel_y = J - reticle.field_phase_y
        field_x = np.floor_divide(rel_x, nfx)
        field_y = np.floor_divide(rel_y, nfy)
        slot_x = rel_x - field_x * nfx
        slot_y = rel_y - field_y * nfy
        fkey = field_x * 100003 + field_y
        if reticle.stepping == "full_fields_only":
            # field rectangle = union of its die footprints (streets inside the field included)
            fx_min = (field_x * nfx + reticle.field_phase_x) * px + ox - px / 2
            fy_min = (field_y * nfy + reticle.field_phase_y) * py + oy - py / 2
            fx_max = fx_min + nfx * px
            fy_max = fy_min + nfy * py
            exposed = geo.contains_usable(fx_min, fy_min, fx_max, fy_max)
        elif reticle.stepping == "fields_with_full_die":
            good_keys = set(fkey[usable & ~in_zone].tolist())
            exposed = np.array([k in good_keys for k in fkey.tolist()], dtype=bool)
        for fxi, fyi in reticle.excluded_fields:
            exposed &= ~((field_x == fxi) & (field_y == fyi))

    cls = np.full(n, SiteClass.FULL_DIE, dtype=np.int8)
    test_site = np.zeros(n, dtype=bool)
    if reticle.enabled and reticle.test_site_slots:
        for sxi, syi in reticle.test_site_slots:
            test_site |= (slot_x == sxi) & (slot_y == syi)
    for di, dj in layout.test_site_dies:
        test_site |= (I == di) & (J == dj)
    cls[test_site] = SiteClass.VALID_TEST_SITE
    cls[~usable] = SiteClass.EDGE_EXCLUDED
    cls[~on_wafer] = SiteClass.PARTIAL
    cls[~exposed | in_zone] = SiteClass.UNPRINTABLE
    edge = geo.edge_distance(fx0, fy0, fx1, fy1)

    return WaferMap(
        ix=I, iy=J, cx=cx, cy=cy, dx0=dx0, dy0=dy0, dx1=dx1, dy1=dy1,
        fx0=fx0, fy0=fy0, fx1=fx1, fy1=fy1, cls=cls, field_x=field_x, field_y=field_y,
        slot_x=slot_x, slot_y=slot_y, edge_dist=edge, eligible=(cls == SiteClass.FULL_DIE),
        reticle_enabled=reticle.enabled, dies_per_field=(nfx, nfy), pitch_mm=(px, py),
        die_mm=(w, h), street_mm=(sx, sy), offset_mm=(ox, oy), footprint=layout.footprint,
        geometry=geo, die=die, reticle=reticle, layout=layout,
    )


def optimise_offset(wafer: WaferSpec | WaferGeometry, die: DieSpec, reticle: Optional[ReticleSpec] = None,
                    layout: Optional[LayoutSpec] = None, steps: int = 21) -> tuple[float, float, int]:
    """Exhaustive search of the grid translation (one pitch, ``steps`` x ``steps``) maximising FULL dies.

    Returns (offset_x_mm, offset_y_mm, n_full).  Ties are broken by the smallest
    |offset| so the result is deterministic.
    """
    geo = wafer if isinstance(wafer, WaferGeometry) else WaferGeometry(wafer)
    base = (layout or LayoutSpec()).model_copy()
    best = (0.0, 0.0, -1)
    for ax in np.linspace(0, die.pitch_x_mm, steps, endpoint=False):
        for ay in np.linspace(0, die.pitch_y_mm, steps, endpoint=False):
            lay = base.model_copy(update={"offset_x_mm": float(ax), "offset_y_mm": float(ay), "grid_origin": "explicit"})
            n = layout_wafer(geo, die, reticle, lay).n_full
            key = (n, -(ax * ax + ay * ay))
            if key > (best[2], -(best[0] ** 2 + best[1] ** 2)):
                best = (float(ax), float(ay), n)
    return best
