r"""Advanced research module: multi-chiplet package yield and cost (separate from the SilicaFlux-V flow).

Probability model (stated, not silent):

    P(package good) = prod_i q_i^{n_i} * y_bond^{n_bond} * y_interposer * y_assembly

* ``q_i`` is the probability that a chiplet of type i is good *when it is assembled*:
  - pretested (known-good die): q_i = 1 - (escapes / passes) of its wafer-sort test;
  - untested: q_i = die yield.
* bonding failures are independent per die-to-die interface; interposer and
  final assembly are single events.
* **Independence between components is an assumption.**  ``simulate`` can add
  correlation by drawing every chiplet's defect intensity from a shared gamma
  multiplier (chiplets from the same lot).  Positive correlation makes
  P(all good) differ from the product of the marginal yields (by Jensen's
  inequality it is larger than the product); the MC reports the correlated
  result next to the independent formula so the assumption's effect is visible.

Final-package test detects a bad package with probability ``final_test_coverage``;
undetected bad packages are escapes (quality risk), not good packages.

Cost per good package = all money spent (chiplets incl. those lost in bad packages,
interposer, assembly, test) / good packages.  Chiplets are NOT assumed cheaper
than a monolithic die: the comparison is computed, with the D2D-interface
area overhead and assembly yields as explicit (hypothetical) inputs.
"""
from __future__ import annotations

from typing import Optional

import numpy as np
from pydantic import BaseModel, ConfigDict, Field

from . import yield_models as ym


class ChipletType(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str
    area_mm2: float = Field(gt=0)
    count: int = Field(1, ge=1)
    pretested: bool = True
    test_escape_fraction: float = Field(0.0, ge=0, le=1, description="escapes / passed dies at wafer sort")
    wafer_cost_per_good_die: Optional[float] = Field(default=None, ge=0)
    area_source: str = "ESTIMATE"


class PackageSpec(BaseModel):
    model_config = ConfigDict(extra="forbid")
    bond_yield_per_interface: float = Field(ge=0, le=1)
    n_interfaces: int = Field(ge=0)
    interposer_yield: float = Field(1.0, ge=0, le=1)
    assembly_yield: float = Field(ge=0, le=1)
    final_test_coverage: float = Field(ge=0, le=1)
    interposer_cost: float = Field(0.0, ge=0)
    assembly_cost: float = Field(0.0, ge=0)
    final_test_cost: float = Field(0.0, ge=0)
    source: str = "HYPOTHETICAL"


def chiplet_q(c: ChipletType, d0: float, alpha: Optional[float]) -> float:
    a = c.area_mm2 / 100.0
    y = ym.negative_binomial_yield(a, d0, alpha) if alpha else ym.poisson_yield(a, d0)
    return (1.0 - c.test_escape_fraction) if c.pretested else y


def package_yield(chiplets: list[ChipletType], pkg: PackageSpec, d0: float, alpha: Optional[float] = None) -> dict:
    q = {c.name: chiplet_q(c, d0, alpha) for c in chiplets}
    p_chips = float(np.prod([q[c.name] ** c.count for c in chiplets]))
    p_bond = pkg.bond_yield_per_interface ** pkg.n_interfaces
    p_good = p_chips * p_bond * pkg.interposer_yield * pkg.assembly_yield
    p_bad = 1.0 - p_good
    return {
        "q_per_chiplet": q, "p_all_chiplets_good": p_chips, "p_bonds_good": p_bond,
        "p_package_good": p_good, "p_shipped_bad": p_bad * (1 - pkg.final_test_coverage),
        "p_rejected": p_bad * pkg.final_test_coverage,
        "assumption": "independent chiplets, bonds, interposer and assembly",
    }


def package_cost(chiplets: list[ChipletType], pkg: PackageSpec, d0: float, alpha: Optional[float] = None) -> dict:
    py = package_yield(chiplets, pkg, d0, alpha)
    chip_cost = 0.0
    for c in chiplets:
        if c.wafer_cost_per_good_die is None:
            raise ValueError(f"chiplet {c.name}: wafer cost per (tested) die not supplied")
        chip_cost += c.count * c.wafer_cost_per_good_die
    spent = chip_cost + pkg.interposer_cost + pkg.assembly_cost + pkg.final_test_cost
    return {**py, "spent_per_package_built": spent,
            "cost_per_good_package": spent / py["p_package_good"] if py["p_package_good"] > 0 else float("inf")}


def simulate(chiplets: list[ChipletType], pkg: PackageSpec, d0: float, n_packages: int, rng: np.random.Generator,
             lot_alpha: Optional[float] = None, packages_per_lot: int = 100) -> dict:
    """Monte Carlo package yield; optional shared lot multiplier for untested chiplets (correlation)."""
    good = np.ones(n_packages, bool)
    lots = np.arange(n_packages) // packages_per_lot
    nl = int(lots.max()) + 1
    mult = rng.gamma(lot_alpha, 1.0 / lot_alpha, nl)[lots] if lot_alpha else np.ones(n_packages)
    for c in chiplets:
        for _ in range(c.count):
            if c.pretested:
                good &= rng.random(n_packages) >= c.test_escape_fraction
            else:
                lam = d0 * mult * c.area_mm2 / 100.0
                good &= rng.poisson(lam) == 0
    if pkg.n_interfaces:
        bonds = rng.random((n_packages, pkg.n_interfaces)) < pkg.bond_yield_per_interface
        good &= bonds.all(axis=1)
    good &= rng.random(n_packages) < pkg.interposer_yield
    good &= rng.random(n_packages) < pkg.assembly_yield
    p = good.mean()
    return {"p_package_good_mc": float(p), "mcse": float(np.sqrt(p * (1 - p) / n_packages)),
            "lot_correlation": f"gamma(alpha={lot_alpha}) shared by {packages_per_lot} packages" if lot_alpha else "none"}


def monolithic_vs_chiplets(mono_area_mm2: float, split: list[tuple[str, float]], d2d_overhead_mm2: float,
                           d0: float, alpha: Optional[float], wafer_cost: float, gross_fn, pkg: PackageSpec,
                           mono_pkg_cost: float, test_escape: float) -> dict:
    """Compare a monolithic die with a split into chiplets (each gets the D2D overhead).

    ``gross_fn(area_mm2) -> gross dies per wafer`` must come from the geometry engine."""
    a = mono_area_mm2 / 100
    y_mono = ym.negative_binomial_yield(a, d0, alpha) if alpha else ym.poisson_yield(a, d0)
    g_mono = gross_fn(mono_area_mm2)
    mono_cost = (wafer_cost / (g_mono * y_mono)) + mono_pkg_cost
    chips = []
    for name, area in split:
        ar = area + d2d_overhead_mm2
        y = ym.negative_binomial_yield(ar / 100, d0, alpha) if alpha else ym.poisson_yield(ar / 100, d0)
        g = gross_fn(ar)
        chips.append(ChipletType(name=name, area_mm2=ar, pretested=True, test_escape_fraction=test_escape,
                                 wafer_cost_per_good_die=wafer_cost / (g * y)))
    pc = package_cost(chips, pkg, d0, alpha)
    return {"monolithic": {"area_mm2": mono_area_mm2, "yield": y_mono, "gross": g_mono,
                           "cost_per_good_packaged_die": mono_cost / pkg.assembly_yield},
            "chiplets": {"parts": [c.model_dump() for c in chips], **pc},
            "note": "research comparison with HYPOTHETICAL interface overhead, bond / assembly yields and costs"}
