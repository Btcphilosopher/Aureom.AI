"""Analyses built on the engine (pure functions returning JSON-serialisable dicts)."""
from __future__ import annotations

import math
from typing import Optional

import numpy as np
import pandas as pd

from . import gross_die, statistics as st, yield_models as ym
from .config import Scenario
from .costs import StageCounts, first_silicon, full_wafer_cost, load_costs, mpw_cost, tornado
from .die_layout import LayoutSpec, layout_wafer, optimise_offset
from .monte_carlo import SimulationResult, build_runtime, run_simulation
from .provenance import ProvenanceLedger, Sourced, Source

KEY_METRICS = ["eligible", "phys_defect_dies", "functional_fail_raw", "functional_fail", "param_fail_only",
               "outcome_TRUE_GOOD_PASS", "outcome_DEFECTIVE_DETECTED", "outcome_DEFECTIVE_ESCAPED",
               "outcome_GOOD_REJECTED", "probe_pass", "delivered", "delivered_conforming", "delivered_escape"]


def ledger_for(scn: Scenario, rt) -> ProvenanceLedger:
    led = ProvenanceLedger()
    if hasattr(rt.rm, "geo") and rt.rm.geo is not None:
        led.record("die_floorplan", rt.rm.geo.sourced_die())
        led.record("pad_ring_um", Sourced(value=scn.design.pad_ring.width_um, source=scn.design.pad_ring.source,
                                          reference=scn.design.pad_ring.reference))
    else:
        led.record("die_outline", Sourced(value=scn.design.die_override_um, source=scn.design.die_override_source,
                                          reference=scn.design.die_override_reference or "die override"))
    led.record("scribe_um", Sourced(value=(scn.die.scribe_x_um, scn.die.scribe_y_um), source=scn.die.scribe_source,
                                    reference=scn.die.scribe_reference))
    led.record("edge_exclusion_mm", scn.wafer.edge_exclusion_sourced())
    if scn.wafer.orientation is not None:
        o = scn.wafer.orientation
        led.record("orientation_feature", Sourced(value=o.kind, source=o.source, reference=o.reference))
    if scn.reticle.enabled:
        led.record("reticle_field_mm", Sourced(value=(scn.reticle.max_field_w_mm, scn.reticle.max_field_h_mm),
                                               source=scn.reticle.field_source, reference=scn.reticle.field_reference))
    led.record("defect_model", Sourced(value=scn.defects.name, source=Source(scn.defects.source)
                                       if scn.defects.source in Source.__members__ else Source.HYPOTHETICAL,
                                       reference=scn.defects.reference))
    led.record("fatality_model", Sourced(value=scn.fatality.mode, source=Source.HYPOTHETICAL,
                                         reference=scn.fatality.reference))
    led.record("sram_fault_mix", Sourced(value=scn.sram.fault_mix.model_dump(exclude={"source", "reference"}),
                                         source=Source.HYPOTHETICAL, reference=scn.sram.fault_mix.reference))
    for stp in scn.tests.steps:
        if not stp.enabled:
            continue
        for k, c in stp.coverage.items():
            led.record(f"coverage.{stp.name}.{k}", Sourced(value=c.value, source=c.source, reference=c.reference)
                       if c.value is not None else Sourced.na(c.reference))
    if scn.parametric.enabled:
        led.record("parametric_model", Sourced(value=[p.name for p in scn.parametric.parameters],
                                               source=Source.HYPOTHETICAL, reference=scn.parametric.reference))
    if scn.tests.assembly_yield is not None:
        led.record("assembly_yield", scn.tests.assembly_yield.sourced())
    return led


def geometry_analysis(scn: Scenario, optimise: bool = True) -> dict:
    rt = build_runtime(scn)
    wm = rt.wmap
    g = rt.geo
    acc = gross_die.area_accounting(wm, g.wafer_area_mm2(), g.usable_area_mm2())
    fp_w = wm.fx1[0] - wm.fx0[0]
    fp_h = wm.fy1[0] - wm.fy0[0]
    approx = gross_die.compare(wm.n_full, g.R - g.e, rt.die, fp_w, fp_h, wm.offset_mm[1])
    footprints = {}
    for fp in ("die", "die_plus_half_street", "die_plus_full_street"):
        footprints[fp] = layout_wafer(g, rt.die, scn.reticle, scn.layout.model_copy(update={"footprint": fp})).n_full
    out = {
        "die_um": [rt.die.width_um, rt.die.height_um], "die_area_mm2": rt.die.area_mm2,
        "die_source": rt.die.source.value, "die_reference": rt.die.reference,
        "pitch_mm": list(wm.pitch_mm), "footprint_convention": scn.layout.footprint,
        "site_counts": wm.counts(), "eligible": int(wm.n_full),
        "dies_per_reticle_field": list(wm.dies_per_field) if wm.reticle_enabled else None,
        "area_accounting": acc, "approximations": approx, "footprint_sensitivity": footprints,
        "wafer": scn.wafer.model_dump(mode="json"),
    }
    if optimise:
        ox, oy, n = optimise_offset(g, rt.die, scn.reticle, scn.layout, steps=15)
        out["optimised_grid_offset"] = {"offset_x_mm": ox, "offset_y_mm": oy, "full_dies": n,
                                        "gain_vs_configured": n - int(wm.n_full),
                                        "method": "exhaustive 15 x 15 search over one pitch"}
    return out


def model_comparison(area_cm2: float, d0: float, alpha: float, rng: np.random.Generator, n_mc: int = 200000) -> dict:
    rows = []
    for m in ("poisson", "negative_binomial", "seeds", "murphy", "murphy_uniform"):
        a = alpha if m == "negative_binomial" else None
        y = ym.evaluate(m, area_cm2, d0, a)
        p, se = ym.monte_carlo_yield(m, n_mc, area_cm2, d0, rng, a)
        rows.append({"model": m, "assumption": ym.ASSUMPTIONS[m], "analytical_yield": y, "monte_carlo_yield": p,
                     "mc_standard_error": se, "z": (p - y) / se if se > 0 else 0.0})
    rows.append({"model": "empirical", "assumption": ym.ASSUMPTIONS["empirical"], "analytical_yield": None,
                 "monte_carlo_yield": None, "mc_standard_error": None,
                 "z": None, "status": "NOT AVAILABLE - no measured SilicaFlux wafer data to fit"})
    return {"area_cm2": area_cm2, "d0_per_cm2": d0, "alpha": alpha, "rows": rows,
            "note": "no model is universally most accurate; selection requires measured dispersion"}


def effective_fatal_density(df: pd.DataFrame, die_area_cm2: float) -> dict:
    """Empirical defect-limited yield of the simulation and the equivalent Poisson / NB parameters."""
    elig = df["eligible"].sum()
    good = (df["eligible"] - df["functional_fail_raw"]).sum()
    y = good / elig
    d0_equiv = -math.log(y) / die_area_cm2 if 0 < y < 1 else 0.0
    wy = (df["eligible"] - df["functional_fail_raw"]) / df["eligible"]
    return {"simulated_defect_limited_yield": y, "poisson_equivalent_d0_per_cm2": d0_equiv,
            "wafer_yield_sd": float(wy.std(ddof=1)) if len(wy) > 1 else 0.0,
            "binomial_sd_if_poisson": math.sqrt(y * (1 - y) / df["eligible"].mean()),
            "note": "Poisson-equivalent D0 is the density that reproduces the simulated mean yield with exp(-A D0)"}


def region_breakdown(df: pd.DataFrame, rt) -> list[dict]:
    elig = df["eligible"].sum()
    rows = []
    for r in rt.rm.regions:
        k = df.get(f"kill_{r.name}", pd.Series([0])).sum()
        sole = df.get(f"sole_{r.name}", pd.Series([0])).sum()
        esc = df.get(f"escape_{r.name}", pd.Series([0])).sum()
        rows.append({"region": r.name, "kind": r.kind, "function": r.spec.function,
                     "located_area_mm2": r.located_area_um2 / 1e6,
                     "area_fraction": r.located_area_um2 / (rt.rm.W * rt.rm.H),
                     "dies_with_fatal_defect_in_region": int(k), "yield_loss_fraction": k / elig,
                     "sole_cause_dies": int(sole), "escaped_dies_with_fault_in_region": int(esc),
                     "detected_by": ", ".join(r.spec.detected_by) or "none",
                     "coverage_source": r.spec.coverage_source, "redundancy": r.spec.redundancy})
    rows.sort(key=lambda d: -d["yield_loss_fraction"])
    return rows


def loss_waterfall(df: pd.DataFrame) -> list[dict]:
    """Mean dies per wafer lost at each mechanism (mutually exclusive, in flow order)."""
    m = df.mean(numeric_only=True)
    steps = [
        ("gross die sites touching the wafer", m["gross_sites"]),
        ("- partial / edge-excluded / unprintable / test sites", -(m["gross_sites"] - m["eligible"])),
        ("= eligible FULL dies", m["eligible"]),
        ("- functional failures (random defects, after implemented repair)", -m["functional_fail"]),
        ("- conditional (hypothetical repair only)", -m["repaired_conditional"]),
        ("- parametric-only failures", -m["param_fail_only"]),
        ("= conforming dies", m["conforming_wafer"]),
        ("- good dies rejected at probe", -m["outcome_GOOD_REJECTED"]),
        ("- untested", -m["untested"] + 0.0),
        ("= true good dies passing probe", m["outcome_TRUE_GOOD_PASS"]),
        ("  (escapes also passing probe - quality risk, not good)", m["outcome_DEFECTIVE_ESCAPED"]),
        ("= delivered conforming after packaging + final test", m["delivered_conforming"]),
    ]
    return [{"step": s, "dies_per_wafer": float(v)} for s, v in steps]


def summarise(sim: SimulationResult, target_good: Optional[float] = None) -> dict:
    df = st.add_derived(sim.wafers)
    rt = sim.runtime
    cols = KEY_METRICS + list(st.YIELD_METRICS)
    table = st.summary_table(df, cols, seed=sim.scenario.monte_carlo.seed)
    conv = {c: st.convergence(df[c].to_numpy(float), rel_tol=0.01, n_min=100)
            for c in ("outcome_TRUE_GOOD_PASS", "delivered_conforming", "functional_fail_raw")}
    for c in conv.values():
        c.pop("running_mean_full", None)
    good = df["outcome_TRUE_GOOD_PASS"].to_numpy(float)
    target = target_good if target_good is not None else float(np.percentile(good, 10))
    out = {
        "meta": sim.meta,
        "label": ledger_for(sim.scenario, rt).result_label(),
        "yield_definitions": {k: {"numerator": v[0], "denominator": v[1], "definition": v[2]}
                              for k, v in st.YIELD_METRICS.items()},
        "summary": table,
        "convergence": {k: {kk: vv for kk, vv in v.items() if kk != "running_mean"} for k, v in conv.items()},
        "running_means": {k: v["running_mean"] for k, v in conv.items()},
        "probability_target_true_good_per_wafer": st.prob_at_least(good, target),
        "lot_totals_true_good": st.lot_totals(df, "outcome_TRUE_GOOD_PASS").tolist(),
        "effective_density": effective_fatal_density(df, rt.die.area_cm2),
        "region_breakdown": region_breakdown(df, rt),
        "waterfall": loss_waterfall(df),
        "inputs": ledger_for(sim.scenario, rt).to_table(),
        "regions": rt.rm.table(),
    }
    return out


def cost_analysis(sim: SimulationResult, costs: dict) -> dict:
    fw, mp, fs = load_costs(costs)
    df = sim.wafers
    out: dict = {}
    counts = StageCounts.from_wafers(df)
    die_yield = float((df["outcome_TRUE_GOOD_PASS"].sum()) / df["eligible"].sum())
    label = ledger_for(sim.scenario, sim.runtime).result_label()
    if fw:
        try:
            out["full_wafer"] = full_wafer_cost(fw, counts)
            out["tornado"] = tornado(fw, counts)
            # per-wafer cost distribution (recurring only) -> uncertainty of cost per good die
            per = []
            for _, row in df.iterrows():
                c1 = StageCounts.from_wafers(pd.DataFrame([row]))
                r = full_wafer_cost(fw.model_copy(update={"include_nre": []}), c1)
                per.append(r["cost_per_delivered_conforming_die"])
            per = np.asarray(per)
            out["per_wafer_recurring_cost_per_conforming_die"] = {
                **st.describe(per), "pi90": st.predictive_interval(per, 0.9)}
        except Exception as e:  # MissingInputError -> reported, never replaced
            out["full_wafer"] = {"status": "NOT AVAILABLE", "reason": str(e)}
    if mp:
        try:
            out["mpw"] = mpw_cost(mp, sim.runtime.die.area_mm2, die_yield, label)
        except Exception as e:
            out["mpw"] = {"status": "NOT AVAILABLE", "reason": str(e)}
    if fs:
        try:
            out["first_silicon"] = first_silicon(fs, die_yield, label)
        except Exception as e:
            out["first_silicon"] = {"status": "NOT AVAILABLE", "reason": str(e)}
    out["die_yield_used"] = die_yield
    return out
