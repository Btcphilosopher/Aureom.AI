"""Process-technology profiles and the node comparison.

The comparison computes only what the evidence supports:

* gross dies per wafer -- for nodes with a (measured or estimated) die size, on a
  *simulation* wafer diameter chosen by the user (the foundry's diameter is
  NOT AVAILABLE for every node);
* defect-limited yield and good dies -- as a **sensitivity** over a common grid
  of hypothetical D0 values (no node-specific D0 exists; none is invented);
* cost -- NOT AVAILABLE unless a price is supplied; document-cited prices are
  shown with their status and never used as quotes.

Nodes are never ranked by yield or cost on unsourced inputs.
"""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict

from .config import CONFIG_ROOT, load_yaml
from .die_layout import DieSpec, LayoutSpec, ReticleSpec, layout_wafer
from .provenance import Source, Sourced
from .wafer_geometry import WaferGeometry, WaferSpec
from . import yield_models as ym

FIELDS = ["sfv_die_um", "pad_ring_um", "sram_macro_area_mm2", "std_cell_area_mm2", "wafer_diameter_mm",
          "edge_exclusion_mm", "scribe_um", "defect_density_per_cm2", "wafer_price", "mpw_price", "mask_nre",
          "packaging", "test_cost", "mpw_access", "timing"]


class NodeProfile(BaseModel):
    model_config = ConfigDict(extra="forbid")
    id: str
    node_nm: int
    platform: str
    status: str
    engineering_risk: str
    sfv_die_um: Sourced
    pad_ring_um: Sourced
    sram_macro_area_mm2: Sourced
    std_cell_area_mm2: Sourced
    wafer_diameter_mm: Sourced
    edge_exclusion_mm: Sourced
    scribe_um: Sourced
    defect_density_per_cm2: Sourced
    wafer_price: Sourced
    mpw_price: Sourced
    mask_nre: Sourced
    packaging: Sourced
    test_cost: Sourced
    mpw_access: Sourced
    timing: Sourced


def load_nodes(path=None) -> list[NodeProfile]:
    data = load_yaml(path or CONFIG_ROOT / "process" / "nodes.yaml")
    out = []
    for n in data["nodes"]:
        d = dict(n)
        for f in FIELDS:
            v = d[f]
            if not v.get("reference"):
                v = {**v, "reference": "not in the repository"}
            d[f] = Sourced(**v)
        out.append(NodeProfile(**d))
    return out


def availability_table(nodes: list[NodeProfile]) -> list[dict]:
    rows = []
    for n in nodes:
        row: dict[str, Any] = {"node": n.id, "nm": n.node_nm, "platform": n.platform, "status": n.status}
        for f in FIELDS:
            s: Sourced = getattr(n, f)
            row[f] = "NOT AVAILABLE" if not s.available else f"{s.raw} [{s.source.value}]"
        row["engineering_risk"] = n.engineering_risk
        rows.append(row)
    return rows


def compare(nodes: list[NodeProfile], sim_wafer: WaferSpec, sim_scribe_um: float, d0_grid: list[float],
            alpha: float) -> list[dict]:
    """Gross die + yield sensitivity for nodes with a die size.  Simulation wafer/scribe are HYPOTHETICAL."""
    geo = WaferGeometry(sim_wafer)
    rows = []
    for n in nodes:
        if not n.sfv_die_um.available:
            rows.append({"node": n.id, "status": "NOT AVAILABLE", "reason": n.sfv_die_um.reference})
            continue
        w, h = n.sfv_die_um.value
        pad = n.pad_ring_um.value if n.pad_ring_um.available else 0.0
        W, H = w + 2 * pad, h + 2 * pad
        die = DieSpec(name=n.id, width_um=W, height_um=H, source=n.sfv_die_um.source, reference=n.sfv_die_um.reference,
                      scribe_x_um=sim_scribe_um, scribe_y_um=sim_scribe_um)
        wm = layout_wafer(geo, die, ReticleSpec(enabled=False), LayoutSpec())
        a = W * H / 1e8
        for d0 in d0_grid:
            rows.append({
                "node": n.id, "nm": n.node_nm, "die_source": n.sfv_die_um.source.value,
                "die_area_mm2": W * H / 1e6, "gross_die_sim_wafer": wm.n_full, "d0_per_cm2_hypothetical": d0,
                "yield_poisson": ym.poisson_yield(a, d0), "yield_nb": ym.negative_binomial_yield(a, d0, alpha),
                "good_die_nb": wm.n_full * ym.negative_binomial_yield(a, d0, alpha),
                "wafer_price": "NOT AVAILABLE" if not n.wafer_price.available else n.wafer_price.raw,
                "cost_per_good_die": "NOT AVAILABLE (no wafer price)" if not n.wafer_price.available or
                n.wafer_price.source is not Source.MEASURED_MANUFACTURING else None,
                "status": n.status,
            })
    return rows
