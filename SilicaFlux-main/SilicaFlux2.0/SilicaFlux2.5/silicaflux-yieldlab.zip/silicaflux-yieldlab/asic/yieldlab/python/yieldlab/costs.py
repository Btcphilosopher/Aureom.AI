r"""Manufacturing economics: stage accounting, cost per known-good die, MPW and first silicon.

Stage flow (counts come from the Monte Carlo or from analytical expectations)::

    FAB         wafers in  = N_w                         cost = N_w * wafer_cost
    PROBE       dies in    = tested dies                 cost = dies_in * probe_cost_per_die + N_w * probe_cost_per_wafer
    DICING      wafers                                   cost = N_w * dicing_cost_per_wafer
    PACKAGING   dies in    = dies that PASSED probe in a sellable bin   (screened-out dies are NOT packaged)
                                                         cost = dies_in * packaging_cost_per_unit
    FINAL TEST  dies in    = packaged                    cost = dies_in * final_test_cost_per_unit
    SHIP        dies in    = delivered                   cost = dies_in * shipping_cost_per_unit
    NRE         one-time: masks, probe card, test program, engineering, qualification (each optional, explicit)

    cost per delivered conforming die = total relevant cost / delivered CONFORMING dies

Delivered dies that are nonconforming (test escapes) are **excluded** from the
denominator and reported separately as a quality-risk category (count, DPPM).

No cost item has a default value.  An item is either a number with a source
(QUOTE, DOCUMENT_CITED_UNVERIFIED, HYPOTHETICAL, ...) or NOT_AVAILABLE; a
calculation that needs a NOT_AVAILABLE item raises MissingInputError.  The
repository contains no foundry quote, wafer price, packaging or test price for
SilicaFlux, so every example in configs/costs is HYPOTHETICAL.

MPW (shuttle) economics are modelled separately: the customer buys a tile of
area A on shared wafers and receives a quoted number of dies -- it does not own
the wafers, so full-wafer gross-die counts do not apply.
"""
from __future__ import annotations

from typing import Literal, Optional

import numpy as np
from pydantic import BaseModel, ConfigDict, Field

from .provenance import MissingInputError, ProvenanceLedger, Source, Sourced


class CostItem(BaseModel):
    model_config = ConfigDict(extra="forbid")
    value: Optional[float] = Field(default=None, ge=0)
    source: Source
    reference: str

    def sourced(self) -> Sourced:
        return Sourced(value=self.value, source=self.source, reference=self.reference)


def _na(ref: str) -> CostItem:
    return CostItem(value=None, source=Source.NOT_AVAILABLE, reference=ref)


class FullWaferCosts(BaseModel):
    model_config = ConfigDict(extra="forbid")
    currency: str = "EUR"
    wafer_cost: CostItem = Field(default_factory=lambda: _na("full-wafer price (foundry quote)"))
    probe_cost_per_die: CostItem = Field(default_factory=lambda: _na("wafer-probe cost per die"))
    probe_cost_per_wafer: CostItem = Field(default_factory=lambda: _na("wafer-probe cost per wafer"))
    dicing_cost_per_wafer: CostItem = Field(default_factory=lambda: _na("dicing / saw cost per wafer"))
    packaging_cost_per_unit: CostItem = Field(default_factory=lambda: _na("package + assembly cost per unit"))
    final_test_cost_per_unit: CostItem = Field(default_factory=lambda: _na("final test cost per unit"))
    shipping_cost_per_unit: CostItem = Field(default_factory=lambda: _na("shipping / handling per unit"))
    mask_set_nre: CostItem = Field(default_factory=lambda: _na("mask set NRE"))
    probe_card_nre: CostItem = Field(default_factory=lambda: _na("probe card NRE"))
    test_program_nre: CostItem = Field(default_factory=lambda: _na("test program development NRE"))
    engineering_nre: CostItem = Field(default_factory=lambda: _na("engineering design NRE"))
    qualification_cost: CostItem = Field(default_factory=lambda: _na("qualification cost"))
    include_nre: list[str] = Field(default_factory=list,
                                   description="NRE items included in the unit cost (explicit list)")
    nre_amortisation_units: Optional[int] = Field(default=None, ge=1,
                                                  description="if set, included NRE is spread over this many "
                                                              "delivered conforming units instead of this lot only")


class StageCounts(BaseModel):
    """Dies entering / leaving each stage (expected or simulated totals)."""

    model_config = ConfigDict(extra="forbid")
    wafers: float = Field(ge=0)
    eligible: float = Field(ge=0)
    tested: float = Field(ge=0)
    probe_pass: float = Field(ge=0)
    true_good_at_probe: float = Field(ge=0)
    packaged: float = Field(ge=0)
    delivered: float = Field(ge=0)
    delivered_conforming: float = Field(ge=0)
    delivered_escape: float = Field(ge=0)
    source: str = "simulated"

    @classmethod
    def from_wafers(cls, df, source: str = "SIMULATED") -> "StageCounts":
        return cls(wafers=len(df), eligible=float(df["eligible"].sum()), tested=float(df["tested"].sum()),
                   probe_pass=float(df["probe_pass"].sum()),
                   true_good_at_probe=float(df["outcome_TRUE_GOOD_PASS"].sum()),
                   packaged=float(df["packaged"].sum()), delivered=float(df["delivered"].sum()),
                   delivered_conforming=float(df["delivered_conforming"].sum()),
                   delivered_escape=float(df["delivered_escape"].sum()), source=source)


def full_wafer_cost(c: FullWaferCosts, n: StageCounts) -> dict:
    led = ProvenanceLedger()
    stages = []

    def item(name: str, ci: CostItem) -> float:
        return float(led.use(name, ci.sourced()))

    fab = n.wafers * item("wafer_cost", c.wafer_cost)
    stages.append({"stage": "FAB", "unit": "wafer", "in": n.wafers, "out": n.wafers, "cost": fab})
    probe = n.tested * item("probe_cost_per_die", c.probe_cost_per_die) + \
        n.wafers * item("probe_cost_per_wafer", c.probe_cost_per_wafer)
    stages.append({"stage": "PROBE", "unit": "die", "in": n.tested, "out": n.probe_pass, "cost": probe})
    dicing = n.wafers * item("dicing_cost_per_wafer", c.dicing_cost_per_wafer)
    stages.append({"stage": "DICING", "unit": "wafer", "in": n.wafers, "out": n.wafers, "cost": dicing})
    pkg = n.packaged * item("packaging_cost_per_unit", c.packaging_cost_per_unit)
    stages.append({"stage": "PACKAGING", "unit": "die", "in": n.packaged, "out": n.packaged, "cost": pkg})
    ft = n.packaged * item("final_test_cost_per_unit", c.final_test_cost_per_unit)
    stages.append({"stage": "FINAL_TEST", "unit": "die", "in": n.packaged, "out": n.delivered, "cost": ft})
    ship = n.delivered * item("shipping_cost_per_unit", c.shipping_cost_per_unit)
    stages.append({"stage": "SHIP", "unit": "die", "in": n.delivered, "out": n.delivered, "cost": ship})
    recurring = fab + probe + dicing + pkg + ft + ship
    nre_items = {}
    for name in c.include_nre:
        if name not in ("mask_set_nre", "probe_card_nre", "test_program_nre", "engineering_nre", "qualification_cost"):
            raise KeyError(f"unknown NRE item {name}")
        nre_items[name] = item(name, getattr(c, name))
    nre = sum(nre_items.values())
    if c.nre_amortisation_units:
        nre_share = nre * min(1.0, n.delivered_conforming / c.nre_amortisation_units)
        nre_rule = f"NRE spread over {c.nre_amortisation_units} delivered conforming units"
    else:
        nre_share = nre
        nre_rule = "NRE charged entirely to this production quantity"
    total = recurring + nre_share
    if n.delivered_conforming <= 0:
        cpkgd = float("inf")
    else:
        cpkgd = total / n.delivered_conforming
    return {
        "currency": c.currency,
        "stages": stages,
        "recurring_cost": recurring,
        "nre_included": nre_items,
        "nre_charged": nre_share,
        "nre_rule": nre_rule,
        "total_cost": total,
        "delivered_conforming": n.delivered_conforming,
        "cost_per_delivered_conforming_die": cpkgd,
        "recurring_cost_per_delivered_conforming_die": recurring / n.delivered_conforming if n.delivered_conforming else float("inf"),
        "silicon_cost_per_true_good_die_at_probe": (fab + probe) / n.true_good_at_probe if n.true_good_at_probe else float("inf"),
        "quality_risk": {
            "delivered_escapes": n.delivered_escape,
            "escape_dppm": 1e6 * n.delivered_escape / n.delivered if n.delivered else float("nan"),
            "note": "escapes are excluded from the known-good denominator; they are a quality risk, not product",
        },
        "label": led.result_label(),
        "inputs": led.to_table(),
        "counts_source": n.source,
    }


def tornado(c: FullWaferCosts, n: StageCounts, rel: float = 0.25) -> list[dict]:
    """One-at-a-time +/- rel sensitivity of cost per delivered conforming die."""
    base = full_wafer_cost(c, n)["cost_per_delivered_conforming_die"]
    rows = []
    for name in FullWaferCosts.model_fields:
        ci = getattr(c, name)
        if not isinstance(ci, CostItem) or not ci.value:
            continue
        if name.endswith(("_nre", "qualification_cost")) and name not in c.include_nre:
            continue
        lo = c.model_copy(update={name: ci.model_copy(update={"value": ci.value * (1 - rel)})})
        hi = c.model_copy(update={name: ci.model_copy(update={"value": ci.value * (1 + rel)})})
        rows.append({"item": name, "low": full_wafer_cost(lo, n)["cost_per_delivered_conforming_die"],
                     "high": full_wafer_cost(hi, n)["cost_per_delivered_conforming_die"], "base": base})
    rows.sort(key=lambda r: -(r["high"] - r["low"]))
    return rows


# --------------------------------------------------------------------------- MPW

class MPWQuote(BaseModel):
    model_config = ConfigDict(extra="forbid")
    currency: str = "EUR"
    fee: CostItem = Field(default_factory=lambda: _na("MPW shuttle fee (broker / foundry quote)"))
    tile_area_mm2: CostItem = Field(default_factory=lambda: _na("purchased MPW tile area"))
    dies_supplied: CostItem = Field(default_factory=lambda: _na("number of dies the shuttle delivers"))
    packaging_cost_per_unit: CostItem = Field(default_factory=lambda: _na("prototype packaging per unit"))
    test_cost_per_unit: CostItem = Field(default_factory=lambda: _na("prototype bench / ATE test per unit"))
    packaged_units: CostItem = Field(default_factory=lambda: _na("number of dies packaged"))


def mpw_cost(q: MPWQuote, die_area_mm2: float, die_yield: float, yield_label: str) -> dict:
    led = ProvenanceLedger()
    area = led.use("tile_area_mm2", q.tile_area_mm2.sourced())
    if die_area_mm2 > area:
        raise ValueError(f"die ({die_area_mm2:.2f} mm^2) does not fit the purchased MPW tile ({area} mm^2)")
    fee = led.use("fee", q.fee.sourced())
    n_dies = led.use("dies_supplied", q.dies_supplied.sourced())
    n_pkg = min(led.use("packaged_units", q.packaged_units.sourced()), n_dies)
    pkg = n_pkg * led.use("packaging_cost_per_unit", q.packaging_cost_per_unit.sourced())
    tst = n_pkg * led.use("test_cost_per_unit", q.test_cost_per_unit.sourced())
    total = fee + pkg + tst
    exp_good = n_pkg * die_yield
    # binomial spread of good prototypes among the packaged units
    lo = max(0.0, exp_good - 1.645 * np.sqrt(n_pkg * die_yield * (1 - die_yield)))
    hi = exp_good + 1.645 * np.sqrt(n_pkg * die_yield * (1 - die_yield))
    return {
        "currency": q.currency, "total_cost": total, "fee": fee, "packaging": pkg, "test": tst,
        "dies_supplied": n_dies, "packaged": n_pkg, "die_yield_used": die_yield, "die_yield_label": yield_label,
        "expected_good_prototypes": exp_good, "good_prototypes_90pct_binomial": (lo, hi),
        "cost_per_good_prototype": total / exp_good if exp_good > 0 else float("inf"),
        "note": "MPW economics: shuttle fee for a tile on SHARED wafers; not comparable to volume cost per KGD",
        "label": led.result_label(), "inputs": led.to_table(),
    }


# --------------------------------------------------------------------------- first silicon

class FirstSiliconPlan(BaseModel):
    model_config = ConfigDict(extra="forbid")
    currency: str = "EUR"
    engineering_person_months: CostItem
    cost_per_person_month: CostItem
    per_run_fixed: dict[str, CostItem] = Field(description="mask / shuttle fee, foundry services, probe card ...")
    prototypes_per_run: CostItem
    packaging_cost_per_unit: CostItem
    test_cost_per_unit: CostItem
    validation_cost_per_run: CostItem
    respin_engineering_person_months: CostItem
    respin_scenarios: list[int] = Field(default_factory=lambda: [0, 1, 2])
    respin_weights: Optional[dict[int, float]] = Field(
        default=None, description="ASSUMED scenario weights (not measured probabilities); optional")
    respin_weights_reference: str = ""


def first_silicon(plan: FirstSiliconPlan, die_yield: float, yield_label: str) -> dict:
    led = ProvenanceLedger()
    pm = led.use("engineering_person_months", plan.engineering_person_months.sourced())
    rate = led.use("cost_per_person_month", plan.cost_per_person_month.sourced())
    per_run = sum(led.use(f"per_run.{k}", v.sourced()) for k, v in plan.per_run_fixed.items())
    n_proto = led.use("prototypes_per_run", plan.prototypes_per_run.sourced())
    unit = led.use("packaging_cost_per_unit", plan.packaging_cost_per_unit.sourced()) + \
        led.use("test_cost_per_unit", plan.test_cost_per_unit.sourced())
    val = led.use("validation_cost_per_run", plan.validation_cost_per_run.sourced())
    respin_pm = led.use("respin_engineering_person_months", plan.respin_engineering_person_months.sourced())
    rows = []
    for k in plan.respin_scenarios:
        runs = 1 + k
        cost = pm * rate + runs * (per_run + n_proto * unit + val) + k * respin_pm * rate
        usable = n_proto * die_yield            # only the final (working) run's prototypes are usable
        rows.append({"respins": k, "fabrication_runs": runs, "program_cost": cost,
                     "expected_usable_prototypes_final_run": usable,
                     "cost_per_usable_prototype": cost / usable if usable > 0 else float("inf")})
    out = {"currency": plan.currency, "scenarios": rows, "die_yield_used": die_yield, "die_yield_label": yield_label,
           "measure": "ENGINEERING PROTOTYPE cost per usable chip (program cost / usable prototypes) - "
                      "NOT comparable to volume cost per known-good die",
           "label": led.result_label(), "inputs": led.to_table()}
    if plan.respin_weights:
        w = plan.respin_weights
        tot = sum(w.values())
        exp = sum(w[r["respins"]] / tot * r["program_cost"] for r in rows if r["respins"] in w)
        out["weighted_program_cost"] = exp
        out["weights_note"] = ("ASSUMED scenario weights, not measured re-spin probabilities: "
                               + (plan.respin_weights_reference or "no reference"))
    return out


def load_costs(d: dict) -> tuple[Optional[FullWaferCosts], Optional[MPWQuote], Optional[FirstSiliconPlan]]:
    fw = FullWaferCosts(**d["full_wafer"]) if d.get("full_wafer") else None
    mp = MPWQuote(**d["mpw"]) if d.get("mpw") else None
    fs = FirstSiliconPlan(**d["first_silicon"]) if d.get("first_silicon") else None
    return fw, mp, fs
