r"""Two-dimensional wafer defect generators (all synthetic -- never labelled as inspection data).

Every generator is a spatial point process with a documented intensity
lambda(x, y) in defects / cm^2 (positions in mm on the wafer):

A ``uniform``        homogeneous Poisson process, lambda = D
B ``radial``         lambda(r) = D * (1 + a (r/R)^p)                    (thinning)
C ``edge``           lambda(r) = D_edge * exp(-(R - r) / L)             (thinning)
D ``cluster``        Thomas process: parents ~ PPP(kappa) on the disc dilated by 4 sigma, each parent
                     has Poisson(mu) offspring displaced by N(0, sigma^2 I).  Mean intensity kappa*mu.
D' ``lgcp``          log-Gaussian Cox process: lambda(x) = D exp(s Z(x) - s^2/2), Z a unit GRF with
                     correlation length l (spatially correlated intensity field; mean D)
E ``scratch``        N ~ Poisson(rate) line segments / arcs; start uniform on the wafer, direction
                     uniform, length ~ U(Lmin, Lmax), curvature radius optional; width w
F ``ring``           lambda(r) = D_ring * exp(-(r - r0)^2 / (2 w^2))
G ``reticle_repeat`` systematic defect at fixed within-field coordinates, printed in each exposed
                     field with probability p_print (mask / reticle defect)
H excursion          wafer-level: with probability p, all intensities x factor  (``WaferVariation``)
I lot variation      lot multiplier ~ Gamma(alpha_lot, 1/alpha_lot) shared by every wafer of a lot,
                     wafer multiplier ~ Gamma(alpha_wafer, 1/alpha_wafer)  (``WaferVariation``)

Every defect gets a size (diameter, um) from  f(x) ~ x^-p  for x >= x0  (the
classic inverse-power size distribution, p = 3 by default), a class, a layer
and a severity in [0, 1].  Scratches and polygon defects are *extended
defects*: they are stored as geometries and mapped to dies by exact
intersection (defect_mapping.py).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Annotated, Literal, Optional, Union

import numpy as np
from pydantic import BaseModel, ConfigDict, Field
from shapely.geometry import LineString, Polygon

from .random_fields import GaussianField


class SizeDist(BaseModel):
    model_config = ConfigDict(extra="forbid")
    x0_um: float = Field(0.1, gt=0)
    power: float = Field(3.0, gt=1)
    max_um: float = Field(50.0, gt=0)

    def sample(self, n: int, rng: np.random.Generator) -> np.ndarray:
        # inverse CDF of f(x) = (p-1) x0^(p-1) x^-p, truncated at max_um
        u = rng.random(n)
        fmax = 1.0 - (self.x0_um / self.max_um) ** (self.power - 1)
        return self.x0_um * (1.0 - u * fmax) ** (-1.0 / (self.power - 1))


class _Base(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = ""
    defect_class: str = "particle"
    layer: str = "any"
    severity: tuple[float, float] = (1.0, 1.0)
    size: SizeDist = Field(default_factory=SizeDist)
    scale_with_variation: bool = True


class Uniform(_Base):
    kind: Literal["uniform"] = "uniform"
    density_per_cm2: float = Field(ge=0)


class Radial(_Base):
    kind: Literal["radial"] = "radial"
    centre_density_per_cm2: float = Field(ge=0)
    a: float = Field(ge=-1)
    p: float = Field(2.0, gt=0)


class Edge(_Base):
    kind: Literal["edge"] = "edge"
    edge_density_per_cm2: float = Field(ge=0)
    decay_mm: float = Field(gt=0)


class Cluster(_Base):
    kind: Literal["cluster"] = "cluster"
    parent_density_per_cm2: float = Field(ge=0)
    mean_offspring: float = Field(gt=0)
    sigma_mm: float = Field(gt=0)


class LGCP(_Base):
    kind: Literal["lgcp"] = "lgcp"
    mean_density_per_cm2: float = Field(ge=0)
    log_sigma: float = Field(gt=0)
    corr_length_mm: float = Field(gt=0)


class Scratch(_Base):
    kind: Literal["scratch"] = "scratch"
    defect_class: str = "scratch"
    rate_per_wafer: float = Field(ge=0)
    length_mm: tuple[float, float] = (10.0, 60.0)
    width_um: float = Field(20.0, gt=0)
    curvature_radius_mm: Optional[float] = None


class Ring(_Base):
    kind: Literal["ring"] = "ring"
    peak_density_per_cm2: float = Field(ge=0)
    radius_mm: float = Field(gt=0)
    width_mm: float = Field(gt=0)


class ReticleRepeat(_Base):
    kind: Literal["reticle_repeat"] = "reticle_repeat"
    defect_class: str = "reticle_systematic"
    positions_in_field_mm: list[tuple[float, float]] = Field(min_length=1)
    print_probability: float = Field(1.0, ge=0, le=1)
    scale_with_variation: bool = False


Component = Annotated[Union[Uniform, Radial, Edge, Cluster, LGCP, Scratch, Ring, ReticleRepeat],
                      Field(discriminator="kind")]


class WaferVariation(BaseModel):
    """Hierarchical intensity multipliers (H, I).  ``None`` alpha = no variation at that level."""

    model_config = ConfigDict(extra="forbid")
    alpha_lot: Optional[float] = Field(default=None, gt=0)
    alpha_wafer: Optional[float] = Field(default=None, gt=0)
    excursion_probability: float = Field(0.0, ge=0, le=1)
    excursion_factor: float = Field(1.0, ge=1)

    def lot_multiplier(self, rng: np.random.Generator) -> float:
        return float(rng.gamma(self.alpha_lot, 1.0 / self.alpha_lot)) if self.alpha_lot else 1.0

    def wafer_multiplier(self, rng: np.random.Generator) -> tuple[float, bool]:
        m = float(rng.gamma(self.alpha_wafer, 1.0 / self.alpha_wafer)) if self.alpha_wafer else 1.0
        exc = bool(self.excursion_probability > 0 and rng.random() < self.excursion_probability)
        return (m * self.excursion_factor if exc else m), exc


class DefectModel(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str
    density_kind: Literal["fatal", "inspection_particles"] = "fatal"
    source: str = "HYPOTHETICAL"
    reference: str = "hypothetical defect scenario; no measured SilicaFlux defect data exists"
    components: list[Component]
    variation: WaferVariation = Field(default_factory=WaferVariation)


@dataclass
class DefectSet:
    """Point-like defects (struct of arrays) + extended defects (geometries)."""

    x: np.ndarray
    y: np.ndarray
    size_um: np.ndarray
    cls: np.ndarray            # index into classes
    layer: np.ndarray          # index into layers
    severity: np.ndarray
    gen: np.ndarray            # component index
    cluster: np.ndarray        # cluster id (-1 = none)
    classes: list[str]
    layers: list[str]
    gen_names: list[str]
    extended: list[dict] = field(default_factory=list)   # {"geom", "cls", "layer", "severity", "gen", "width_um"}
    multiplier: float = 1.0
    excursion: bool = False

    @property
    def n_points(self) -> int:
        return int(self.x.size)

    @property
    def n_events(self) -> int:
        return self.n_points + len(self.extended)

    def summary(self) -> dict:
        per_gen = np.bincount(self.gen, minlength=len(self.gen_names)) if self.n_points else np.zeros(len(self.gen_names), int)
        ext = {}
        for e in self.extended:
            ext[self.gen_names[e["gen"]]] = ext.get(self.gen_names[e["gen"]], 0) + 1
        return {
            "points": self.n_points,
            "extended": len(self.extended),
            "per_generator": {n: int(per_gen[i]) + ext.get(n, 0) for i, n in enumerate(self.gen_names)},
            "multiplier": self.multiplier,
            "excursion": self.excursion,
        }


def _uniform_disc(n: int, R: float, rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray]:
    r = R * np.sqrt(rng.random(n))
    t = rng.random(n) * 2 * np.pi
    return r * np.cos(t), r * np.sin(t)


class DefectGenerator:
    def __init__(self, model: DefectModel, geometry, wmap=None):
        self.model = model
        self.geo = geometry
        self.wmap = wmap
        self.R = geometry.R
        self.area_cm2 = math.pi * self.R**2 / 100.0      # disc area; points outside the wafer are rejected
        cls, lay = [], []
        for c in model.components:
            if c.defect_class not in cls:
                cls.append(c.defect_class)
            if c.layer not in lay:
                lay.append(c.layer)
        self.classes, self.layers = cls, lay
        self.gen_names = [c.name or f"{c.kind}_{i}" for i, c in enumerate(model.components)]
        if any(isinstance(c, ReticleRepeat) for c in model.components) and (wmap is None or not wmap.reticle_enabled):
            raise ValueError("reticle_repeat defects need a wafer map with reticle fields enabled")

    # ------------------------------------------------------------------ main entry
    def generate(self, rng: np.random.Generator, multiplier: float = 1.0, excursion: bool = False) -> DefectSet:
        xs, ys, gens, clus = [], [], [], []
        extended: list[dict] = []
        cluster_base = 0
        for gi, comp in enumerate(self.model.components):
            m = multiplier if comp.scale_with_variation else 1.0
            if isinstance(comp, Scratch):
                for geom in self._scratches(comp, m, rng):
                    sev = rng.uniform(*comp.severity)
                    extended.append({"geom": geom, "cls": self.classes.index(comp.defect_class),
                                     "layer": self.layers.index(comp.layer), "severity": float(sev), "gen": gi,
                                     "width_um": comp.width_um, "kind": "scratch"})
                continue
            x, y, c = self._points(comp, m, rng)
            if isinstance(comp, Cluster) and c.size:
                c = c + cluster_base
                cluster_base = int(c.max()) + 1
            xs.append(x)
            ys.append(y)
            gens.append(np.full(x.size, gi, dtype=int))
            clus.append(c)
        x = np.concatenate(xs) if xs else np.zeros(0)
        y = np.concatenate(ys) if ys else np.zeros(0)
        gen = np.concatenate(gens) if gens else np.zeros(0, int)
        clu = np.concatenate(clus) if clus else np.zeros(0, int)
        keep = self._on_wafer(x, y)
        x, y, gen, clu = x[keep], y[keep], gen[keep], clu[keep]
        n = x.size
        size = np.empty(n)
        sev = np.empty(n)
        cls = np.empty(n, dtype=int)
        lay = np.empty(n, dtype=int)
        for gi, comp in enumerate(self.model.components):
            sel = gen == gi
            k = int(sel.sum())
            if not k:
                continue
            size[sel] = comp.size.sample(k, rng)
            sev[sel] = rng.uniform(comp.severity[0], comp.severity[1], k)
            cls[sel] = self.classes.index(comp.defect_class)
            lay[sel] = self.layers.index(comp.layer)
        return DefectSet(x, y, size, cls, lay, sev, gen, clu, self.classes, self.layers, self.gen_names,
                         extended, multiplier, excursion)

    def _on_wafer(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        if x.size == 0:
            return np.zeros(0, bool)
        ok = x * x + y * y <= self.R**2
        g = self.geo
        if g.flat is not None:
            nx, ny = g._flat_n
            ok &= nx * x + ny * y >= -g._flat_d
        if g._notch_tri is not None:
            import shapely

            ok &= ~shapely.contains_xy(g._notch_tri, x, y)
        return ok

    # ------------------------------------------------------------------ point processes
    def _hppp(self, density_per_cm2: float, rng: np.random.Generator):
        n = rng.poisson(density_per_cm2 * self.area_cm2) if density_per_cm2 > 0 else 0
        return _uniform_disc(n, self.R, rng)

    def _thin(self, lam_max: float, lam_fn, rng: np.random.Generator):
        x, y = self._hppp(lam_max, rng)
        if x.size == 0:
            return x, y
        keep = rng.random(x.size) * lam_max < lam_fn(x, y)
        return x[keep], y[keep]

    def _points(self, comp, m: float, rng: np.random.Generator):
        R = self.R
        none = np.zeros(0, int)
        if isinstance(comp, Uniform):
            x, y = self._hppp(comp.density_per_cm2 * m, rng)
            return x, y, np.full(x.size, -1)
        if isinstance(comp, Radial):
            d0 = comp.centre_density_per_cm2 * m
            lmax = d0 * max(1.0, 1.0 + comp.a)
            fn = lambda x, y: d0 * (1.0 + comp.a * (np.hypot(x, y) / R) ** comp.p)
            x, y = self._thin(lmax, fn, rng)
            return x, y, np.full(x.size, -1)
        if isinstance(comp, Edge):
            de = comp.edge_density_per_cm2 * m
            fn = lambda x, y: de * np.exp(-(R - np.hypot(x, y)) / comp.decay_mm)
            x, y = self._thin(de, fn, rng)
            return x, y, np.full(x.size, -1)
        if isinstance(comp, Ring):
            dp = comp.peak_density_per_cm2 * m
            fn = lambda x, y: dp * np.exp(-((np.hypot(x, y) - comp.radius_mm) ** 2) / (2 * comp.width_mm**2))
            x, y = self._thin(dp, fn, rng)
            return x, y, np.full(x.size, -1)
        if isinstance(comp, LGCP):
            field = GaussianField(R, comp.corr_length_mm, rng)
            d0, s = comp.mean_density_per_cm2 * m, comp.log_sigma
            lmax = d0 * math.exp(s * field.max_value() - s * s / 2)
            fn = lambda x, y: d0 * np.exp(s * field(x, y) - s * s / 2)
            x, y = self._thin(lmax, fn, rng)
            return x, y, np.full(x.size, -1)
        if isinstance(comp, Cluster):
            Rp = R + 4 * comp.sigma_mm
            area = math.pi * Rp**2 / 100.0
            npar = rng.poisson(comp.parent_density_per_cm2 * m * area)
            px, py = _uniform_disc(npar, Rp, rng)
            kids = rng.poisson(comp.mean_offspring, npar)
            cid = np.repeat(np.arange(npar), kids)
            x = np.repeat(px, kids) + rng.normal(0, comp.sigma_mm, cid.size)
            y = np.repeat(py, kids) + rng.normal(0, comp.sigma_mm, cid.size)
            return x, y, cid
        if isinstance(comp, ReticleRepeat):
            return self._reticle(comp, rng)
        raise TypeError(comp)

    def _reticle(self, comp: ReticleRepeat, rng: np.random.Generator):
        w = self.wmap
        nfx, nfy = w.dies_per_field
        px, py = w.pitch_mm
        ox, oy = w.offset_mm
        ret = w.reticle
        fields = sorted(set(zip(w.field_x[w.cls != 3].tolist(), w.field_y[w.cls != 3].tolist())))
        xs, ys = [], []
        for fx, fy in fields:
            x0 = (fx * nfx + ret.field_phase_x) * px + ox - px / 2
            y0 = (fy * nfy + ret.field_phase_y) * py + oy - py / 2
            for (dx, dy) in comp.positions_in_field_mm:
                if rng.random() < comp.print_probability:
                    xs.append(x0 + dx)
                    ys.append(y0 + dy)
        x, y = np.array(xs, float), np.array(ys, float)
        return x, y, np.full(x.size, -1)

    def _scratches(self, comp: Scratch, m: float, rng: np.random.Generator) -> list:
        n = rng.poisson(comp.rate_per_wafer * m) if comp.rate_per_wafer > 0 else 0
        out = []
        wp = self.geo.wafer_polygon()
        for _ in range(n):
            sx, sy = _uniform_disc(1, self.R, rng)
            theta = rng.uniform(0, 2 * np.pi)
            length = rng.uniform(*comp.length_mm)
            if comp.curvature_radius_mm:
                rc = comp.curvature_radius_mm * (1 if rng.random() < 0.5 else -1)
                phi = length / abs(rc)
                t = np.linspace(0, phi, 32)
                cx = sx[0] - rc * math.sin(theta)
                cy = sy[0] + rc * math.cos(theta)
                pts = np.c_[cx + rc * np.sin(theta + np.sign(rc) * t), cy - rc * np.cos(theta + np.sign(rc) * t)]
            else:
                pts = np.array([[sx[0], sy[0]], [sx[0] + length * math.cos(theta), sy[0] + length * math.sin(theta)]])
            line = LineString(pts).intersection(wp)
            if not line.is_empty and line.length > 0:
                out.append(line)
        return out


def polygon_defect(points_mm: list[tuple[float, float]], defect_class: str = "residue", severity: float = 1.0) -> dict:
    """Helper to inject a polygonal extended defect (e.g. from imported inspection data)."""
    return {"geom": Polygon(points_mm), "cls_name": defect_class, "severity": severity, "kind": "polygon"}
