"""Engineering quality gates 1-20, evaluated from evidence (test results + run artefacts).

A gate PASSes only on evidence; missing evidence is NOT_RUN, never PASS.
Passing every gate demonstrates a functioning yield simulator.  It does NOT
establish manufacturability, foundry acceptance or commercial yield.
"""
from __future__ import annotations

import hashlib
import io
import json
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional

import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[2]
DISCLAIMER = ("Passing these gates demonstrates a functioning yield simulator. It does not establish actual "
              "manufacturability, foundry acceptance or guaranteed commercial yields.")


def verify_reproducible(run_dir: Path) -> tuple[bool, str]:
    from .config import Scenario
    from .monte_carlo import run_simulation

    meta = json.loads((run_dir / "meta.json").read_text())
    scn = Scenario(**yaml.safe_load((run_dir / "scenario.resolved.yaml").read_text()))
    if scn.digest() != meta["scenario_sha256"]:
        return False, "scenario hash differs from meta.json"
    sim = run_simulation(scn, lots=meta["lots"], wafers_per_lot=meta["wafers_per_lot"], keep_maps=0, workers=1)
    buf = io.StringIO()
    sim.wafers.to_csv(buf, index=False)
    new = hashlib.sha256(buf.getvalue().encode()).hexdigest()
    old = hashlib.sha256((run_dir / "wafers.csv").read_bytes()).hexdigest()
    return new == old, f"wafers.csv sha256 {old[:16]} vs re-run {new[:16]} ({meta['wafers']} wafers, seed {meta['seed']})"


def _junit(path: Optional[Path]) -> dict[str, str]:
    if path is None or not path.exists():
        return {}
    res = {}
    for tc in ET.parse(path).getroot().iter("testcase"):
        name = tc.get("name", "")
        failed = any(ch.tag in ("failure", "error") for ch in tc)
        skipped = any(ch.tag == "skipped" for ch in tc)
        res[name] = "FAIL" if failed else ("SKIP" if skipped else "PASS")
    return res


def _tests(j: dict, prefixes: list[str]) -> tuple[str, str]:
    hits = {k: v for k, v in j.items() if any(k.startswith(p) for p in prefixes)}
    if not j:
        return "NOT_RUN", "no junit results supplied (run make yieldlab-test)"
    if not hits:
        return "NOT_RUN", f"no tests matching {prefixes}"
    bad = [k for k, v in hits.items() if v != "PASS"]
    return ("FAIL", f"failed: {bad}") if bad else ("PASS", f"{len(hits)} tests passed: " + ", ".join(sorted(hits))[:200])


def evaluate_gates(run_dir: Path, junit: Optional[Path] = None, verify: bool = True) -> dict:
    run_dir = Path(run_dir)
    j = _junit(junit or ROOT / "reports" / "ci" / "junit.xml")
    S = json.loads((run_dir / "summary.json").read_text())
    G = json.loads((run_dir / "geometry.json").read_text())
    df = pd.read_csv(run_dir / "wafers.csv")
    gates = []

    def add(n, name, status, evidence):
        gates.append({"gate": n, "name": name, "status": status, "evidence": evidence})

    audit = ROOT / "reports" / "audit" / "repository_audit.json"
    add(1, "Source audit completed", "PASS" if audit.exists() and (ROOT / "docs" / "AUDIT.md").exists() else "NOT_RUN",
        f"{audit.relative_to(ROOT)} + docs/AUDIT.md")
    st, ev = _tests(j, ["test_classification_matches_shapely_reference", "test_property_full_dies", "test_usable_area"])
    add(2, "Physical geometry validated", st if G["die_source"] in ("MEASURED_TOOL_OUTPUT", "DERIVED") else "FAIL",
        f"die source {G['die_source']}; {ev}")
    add(3, "Wafer layout correct", *_tests(j, ["test_H_", "test_notch", "test_reticle", "test_exclusion_zone", "test_edge"]))
    add(4, "Gross die count verified", *_tests(j, ["test_I_", "test_tiny_case", "test_approximations"]))
    add(5, "Poisson implementation validated", *_tests(j, ["test_A_", "test_B_", "test_C_", "test_monte_carlo_counterparts"]))
    add(6, "Negative-binomial implementation validated", *_tests(j, ["test_D_", "test_E_", "test_F_"]))
    add(7, "Spatial defect simulation validated", *_tests(j, ["test_G_", "test_uniform_intensity", "test_cluster_process",
                                                            "test_radial_and_edge", "test_ring", "test_reticle_repeat_same",
                                                            "test_gaussian_field"]))
    add(8, "Die intersection verified", *_tests(j, ["test_street_defect", "test_defect_inside", "test_no_double",
                                                   "test_scratch_intersection", "test_polygon_defect"]))
    scn = yaml.safe_load((run_dir / "scenario.resolved.yaml").read_text())
    fat = scn["fatality"]
    add(9, "Fatality assumptions documented", "PASS" if fat.get("reference") and fat.get("mode") else "FAIL",
        f"mode {fat.get('mode')}: {fat.get('reference')}")
    st, ev = _tests(j, ["test_P_", "test_none_scheme", "test_rows_cols_bira", "test_ecc_rules", "test_capability_gating"])
    add(10, "SRAM redundancy assumptions validated", st, f"repair: {S['meta']['repair']}; {ev}")
    cov = [r for r in S["inputs"] if r["input"].startswith("coverage.")]
    untraced = [r["input"] for r in cov if not r["reference"] or r["source"] == "NOT_AVAILABLE"]
    add(11, "Test coverage inputs traced", "PASS" if cov and not untraced else "FAIL",
        f"{len(cov)} coverage inputs, each with source + reference; " +
        f"{sum(r['source'] == 'HYPOTHETICAL' for r in cov)} HYPOTHETICAL, "
        f"{sum(r['source'] == 'MEASURED_TOOL_OUTPUT' for r in cov)} from TestCore fault injection (proxy)")
    outc = df[[c for c in df.columns if c.startswith("outcome_")]].sum(axis=1)
    bins = df[[c for c in df.columns if c.startswith("bin_")]].sum(axis=1)
    acct = bool((outc == df["eligible"]).all() and (bins == df["eligible"]).all())
    st, ev = _tests(j, ["test_L_", "test_K_"])
    add(12, "Binning accounting validated", "PASS" if acct and st == "PASS" else ("FAIL" if not acct else st),
        f"outcomes and bins sum to eligible on all {len(df)} wafers: {acct}; {ev}")
    conv = S["convergence"]
    status = {k: v["status"] for k, v in conv.items()}
    add(13, "Monte Carlo convergence checked",
        "PASS" if all(v == "CONVERGED" for v in status.values()) else "WARN",
        f"{status} (rel. MCSE <= 1 % and n >= 100 wafers required for CONVERGED)")
    row = next(r for r in S["summary"] if r["metric"] == "outcome_TRUE_GOOD_PASS")
    st, ev = _tests(j, ["test_N_"])
    add(14, "Correlated uncertainty handled correctly", st,
        f"CI method: {row['ci_method']}; ICC(lot) {row['icc_lot']}; design effect {row['design_effect']}; {ev}")
    st, ev = _tests(j, ["test_Q_", "test_O_", "test_escapes_excluded"])
    add(15, "Cost accounting validated", st, ev + ("; costs.json present" if (run_dir / "costs.json").exists() else ""))
    st, ev = _tests(j, ["test_R_", "test_not_available"])
    add(16, "Process and foundry inputs traceable", st, f"{len(S['inputs'])} inputs in provenance table; {ev}")
    figs = list((run_dir / "figures").glob("*.png"))
    add(17, "Visualisations derived from simulation results", "PASS" if figs else "NOT_RUN",
        f"{len(figs)} figures generated by report.make_figures from this run's data")
    if verify:
        ok, msg = verify_reproducible(run_dir)
        add(18, "Reports reproducible", "PASS" if ok else "FAIL", msg)
    else:
        add(18, "Reports reproducible", "NOT_RUN", "verification skipped")
    lim = ROOT / "docs" / "LIMITATIONS.md"
    add(19, "Uncertainty and model limitations documented", "PASS" if lim.exists() and "pi90_next_wafer" in row else "FAIL",
        "docs/LIMITATIONS.md + CI and PI in summary.json")
    lab = S["label"]
    add(20, "No simulated yield represented as measured foundry yield",
        "PASS" if lab.startswith("SIMULATED") and "VERIFIED IMPORTED" not in lab else "FAIL", f"run label: {lab}")
    return {"run": run_dir.name, "gates": gates, "disclaimer": DISCLAIMER}
