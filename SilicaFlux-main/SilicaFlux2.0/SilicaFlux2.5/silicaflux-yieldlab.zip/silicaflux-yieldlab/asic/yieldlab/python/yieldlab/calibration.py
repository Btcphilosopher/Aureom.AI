r"""Statistical calibration of yield-model parameters from (measured) wafer data.

Only meaningful with real manufacturing data.  The functions are validated on
synthetic data generated with known parameters (tests/test_calibration.py),
which demonstrates *identifiability under the model*, not real-world accuracy.

Models fitted
-------------
* **Poisson D0** from die pass/fail (equal effective area A):
  P(good) = exp(-A D0)  ->  MLE  D0 = -ln(k/n) / A,  95 % CI by transforming the Wilson
  interval of k/n (monotone transform).
* **Wafer-level negative binomial (gamma-Poisson)**: wafer intensity
  lambda_w ~ Gamma(alpha, D0/alpha); good dies on wafer w ~ Binomial(n_w, exp(-A lambda_w)).
  Marginal likelihood by per-wafer Gauss-Legendre quadrature over lambda; MLE of (D0, alpha) with
  bounds; CIs from the profile likelihood (chi^2_1 cut-off 3.84, end points by root finding).  A likelihood-ratio test
  against the Poisson / binomial model uses the boundary-corrected 50:50 chi-bar^2 mixture.
* **Window method** (Stapper) for within-wafer clustering: yield of k-die blocks
  Y_k = (1 + k A D0 / alpha)^-alpha fitted to observed block yields.
* **Binomial rates** (test detection probability, packaging yield) with Wilson CIs.
* **Parametric variance components**: lot / wafer / die by nested method of moments.
* **Yield-learning curve** D(t) = D_inf + (D_0 - D_inf) exp(-t / tau) -- refused with fewer
  than 4 measured runs.

Guards: fewer than ``MIN_WAFERS`` wafers or fewer than ``MIN_FAILS`` failing dies
-> the result carries an ``identifiability`` warning; calibration and validation
wafers are split explicitly (``holdout_split``) and the validation log-likelihood
and predictive-interval coverage are reported.
"""
from __future__ import annotations

import math
from typing import Optional

import numpy as np
from scipy import optimize, special, stats

MIN_WAFERS = 10
MIN_FAILS = 30


def wilson(k: int, n: int, level: float = 0.95) -> tuple[float, float]:
    if n == 0:
        return (float("nan"), float("nan"))
    z = stats.norm.ppf(0.5 + level / 2)
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (max(0.0, c - h), min(1.0, c + h))


def fit_poisson_d0(n_good: int, n_total: int, area_cm2: float) -> dict:
    if not 0 < n_good <= n_total:
        raise ValueError("need 0 < n_good <= n_total")
    p = n_good / n_total
    lo, hi = wilson(n_good, n_total)
    d0 = -math.log(p) / area_cm2
    out = {"model": "poisson", "d0_per_cm2": d0,
           "ci95": (-math.log(hi) / area_cm2, -math.log(max(lo, 1e-300)) / area_cm2),
           "n_dies": n_total, "n_fail": n_total - n_good, "method": "MLE + Wilson interval transformed"}
    if n_total - n_good < MIN_FAILS:
        out["identifiability"] = f"only {n_total - n_good} failing dies: D0 poorly constrained"
    return out


_GL_T, _GL_W = np.polynomial.legendre.leggauss(96)


def _nb_wafer_loglik(d0: float, alpha: float, good: np.ndarray, n: np.ndarray, area_cm2: float) -> float:
    """sum_w log integral Binom(good_w | n_w, exp(-A lam)) Gamma(lam | alpha, d0/alpha) dlam.

    Each wafer's integral is evaluated with 96-point Gauss-Legendre quadrature on
    an interval centred on that wafer's binomial-likelihood peak (+-20 standard
    deviations, at least 40 / (n A) wide), so wafers whose likelihood peaks in
    the tail of the gamma distribution are integrated as accurately as typical
    ones (checked against adaptive quadrature in tests/test_calibration.py)."""
    g = np.asarray(good, float)
    n = np.asarray(n, float)
    p_hat = np.clip(g / n, 0.5 / n, 1 - 0.5 / n)
    lam_hat = -np.log(p_hat) / area_cm2
    sd = np.sqrt((1 - p_hat) / (n * p_hat)) / area_cm2
    half = np.maximum(20 * sd, 20.0 / (n * area_cm2))
    lo = np.maximum(lam_hat - half, 0.0)
    hi = lam_hat + half
    lam = lo[:, None] + (hi - lo)[:, None] * (_GL_T[None, :] + 1) / 2          # (W, Q)
    jac = (hi - lo)[:, None] / 2
    p = np.exp(-area_cm2 * lam)
    logbin = (special.gammaln(n + 1) - special.gammaln(g + 1) - special.gammaln(n - g + 1))[:, None] \
        + g[:, None] * np.log(np.clip(p, 1e-300, 1)) + (n - g)[:, None] * np.log(np.clip(1 - p, 1e-300, 1))
    theta = d0 / alpha
    loggam = (alpha - 1) * np.log(np.maximum(lam, 1e-300)) - lam / theta - special.gammaln(alpha) - alpha * np.log(theta)
    t = logbin + loggam
    m = t.max(axis=1, keepdims=True)
    integ = np.log((np.exp(t - m) * _GL_W[None, :] * jac).sum(axis=1)) + m[:, 0]
    return float(integ.sum())


def fit_nb_wafer(good: np.ndarray, n: np.ndarray, area_cm2: float, alpha_bounds=(0.05, 500.0)) -> dict:
    good = np.asarray(good, float)
    n = np.asarray(n, float)
    k_fail = float((n - good).sum())
    if k_fail <= 0:
        raise ValueError("no failing dies: D0 not identifiable")
    p_pool = good.sum() / n.sum()
    d0_init = -math.log(p_pool) / area_cm2

    def nll(v):
        return -_nb_wafer_loglik(math.exp(v[0]), math.exp(v[1]), good, n, area_cm2)

    best = None
    for a0 in (0.5, 2.0, 10.0, 50.0):
        r = optimize.minimize(nll, [math.log(d0_init), math.log(a0)], method="L-BFGS-B",
                              bounds=[(math.log(d0_init / 50), math.log(d0_init * 50)),
                                      (math.log(alpha_bounds[0]), math.log(alpha_bounds[1]))])
        if best is None or r.fun < best.fun:
            best = r
    # polish with a derivative-free search (L-BFGS-B occasionally stops short on this surface)
    nm = optimize.minimize(nll, best.x, method="Nelder-Mead", options={"xatol": 1e-9, "fatol": 1e-10, "maxiter": 4000},
                           bounds=[(math.log(d0_init / 50), math.log(d0_init * 50)),
                                   (math.log(alpha_bounds[0]), math.log(alpha_bounds[1]))])
    if nm.fun < best.fun:
        best = nm
    d0_hat, a_hat = math.exp(best.x[0]), math.exp(best.x[1])
    ll_hat = -best.fun

    lb = [math.log(d0_init / 50), math.log(alpha_bounds[0])]
    ub = [math.log(d0_init * 50), math.log(alpha_bounds[1])]

    def prof(idx: int, logval: float) -> float:
        """Profile log-likelihood with parameter idx fixed at exp(logval)."""
        def f(v):
            x = [0.0, 0.0]
            x[idx] = logval
            x[1 - idx] = v[0]
            return nll(x)
        rr = optimize.minimize(f, [best.x[1 - idx]], method="L-BFGS-B", bounds=[(lb[1 - idx], ub[1 - idx])])
        return -rr.fun

    cut = stats.chi2.ppf(0.95, 1) / 2

    def ci(idx: int) -> tuple[float, float]:
        h = best.x[idx]
        g = lambda lv: prof(idx, lv) - (ll_hat - cut)
        out = []
        for bound in (lb[idx], ub[idx]):
            if abs(bound - h) < 1e-9 or g(bound) > 0:
                out.append(math.exp(bound))          # interval reaches the parameter bound
            else:
                out.append(math.exp(optimize.brentq(g, min(h, bound), max(h, bound), xtol=1e-6)))
        return (out[0], out[1])

    d_ci = ci(0)
    a_ci = ci(1)
    # Poisson (no wafer variation): binomial with common p
    ll_pois = float(stats.binom.logpmf(good, n, p_pool).sum())
    lr = max(0.0, 2 * (ll_hat - ll_pois))
    p_lr = 0.5 * stats.chi2.sf(lr, 1) if lr > 0 else 1.0
    out = {"model": "negative_binomial (wafer-level gamma intensity)", "d0_per_cm2": d0_hat, "alpha": a_hat,
           "d0_ci95_profile": d_ci, "alpha_ci95_profile": a_ci, "loglik": ll_hat, "loglik_poisson": ll_pois,
           "lr_stat_vs_poisson": lr, "p_value_vs_poisson_chibar2": p_lr, "wafers": int(len(n)),
           "alpha_at_bound": bool(a_ci[1] >= alpha_bounds[1] * 0.99),
           "note": "alpha CI reaching the upper bound means no detectable wafer-level dispersion (Poisson-like)"}
    if len(n) < MIN_WAFERS:
        out["identifiability"] = f"only {len(n)} wafers: alpha (dispersion) is poorly identifiable"
    if k_fail < MIN_FAILS:
        out.setdefault("identifiability", "")
        out["identifiability"] += f"; only {int(k_fail)} failing dies"
    return out


def window_method(pass_grids: list[np.ndarray], area_cm2: float, ks=((1, 1), (1, 2), (2, 2), (2, 3), (3, 3))) -> dict:
    """Block yields from die pass/fail grids (NaN = no die).  Fits Y_k = (1 + k A D0 / alpha)^-alpha."""
    rows = []
    for bx, by in ks:
        n = g = 0
        for grid in pass_grids:
            H, W = grid.shape
            for i in range(0, H - by + 1, by):
                for j in range(0, W - bx + 1, bx):
                    blk = grid[i:i + by, j:j + bx]
                    if np.isnan(blk).any():
                        continue
                    n += 1
                    g += int(blk.all())
        if n:
            rows.append({"k": bx * by, "blocks": n, "block_yield": g / n})
    k = np.array([r["k"] for r in rows], float)
    y = np.array([r["block_yield"] for r in rows], float)
    w = np.array([r["blocks"] for r in rows], float)

    def resid(v):
        d0, al = math.exp(v[0]), math.exp(v[1])
        return np.sqrt(w) * (np.log(np.clip(y, 1e-12, 1)) + al * np.log1p(k * area_cm2 * d0 / al))

    d_init = max(-math.log(max(y[0], 1e-9)) / area_cm2, 1e-4)
    r = optimize.least_squares(resid, [math.log(d_init), math.log(2.0)],
                               bounds=([math.log(1e-6), math.log(0.01)], [math.log(1e3), math.log(1e4)]))
    return {"blocks": rows, "d0_per_cm2": math.exp(r.x[0]), "alpha": math.exp(r.x[1]),
            "method": "weighted least squares on log block yield (Stapper window method)",
            "note": "estimates WITHIN-wafer clustering; one synthetic wafer cannot establish clustering"}


def holdout_split(n_wafers: int, frac_validation: float, rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray]:
    idx = rng.permutation(n_wafers)
    nv = max(1, int(round(frac_validation * n_wafers)))
    return np.sort(idx[nv:]), np.sort(idx[:nv])


def validate_nb(fit: dict, good: np.ndarray, n: np.ndarray, area_cm2: float, rng: np.random.Generator,
                draws: int = 4000) -> dict:
    """Predictive check on validation wafers: log-likelihood and 90 % PI coverage of wafer yield."""
    ll = _nb_wafer_loglik(fit["d0_per_cm2"], fit["alpha"], np.asarray(good, float), np.asarray(n, float), area_cm2)
    lam = rng.gamma(fit["alpha"], fit["d0_per_cm2"] / fit["alpha"], draws)
    covered = 0
    for gw, nw in zip(good, n):
        sim = rng.binomial(int(nw), np.exp(-area_cm2 * lam))
        lo, hi = np.quantile(sim, [0.05, 0.95])
        covered += int(lo <= gw <= hi)
    return {"validation_loglik": ll, "pi90_coverage": covered / len(good), "validation_wafers": int(len(good))}


def gof_wafer_yields(fit: dict, good: np.ndarray, n: np.ndarray, area_cm2: float, rng: np.random.Generator,
                     bins: int = 5, draws: int = 20000) -> dict:
    """Pearson chi-square of observed wafer yields against the fitted model's predictive distribution."""
    lam = rng.gamma(fit["alpha"], fit["d0_per_cm2"] / fit["alpha"], draws)
    nbar = int(np.round(np.mean(n)))
    sim = rng.binomial(nbar, np.exp(-area_cm2 * lam)) / nbar
    edges = np.quantile(sim, np.linspace(0, 1, bins + 1))
    edges[0], edges[-1] = -np.inf, np.inf
    obs = np.histogram(np.asarray(good) / np.asarray(n), edges)[0]
    exp = np.full(bins, len(good) / bins)
    chi2 = float(((obs - exp) ** 2 / exp).sum())
    dof = bins - 1 - 2
    return {"chi2": chi2, "dof": dof, "p_value": float(stats.chi2.sf(chi2, dof)) if dof > 0 else float("nan"),
            "observed": obs.tolist(), "expected": exp.tolist(),
            "warning": "low power with few wafers" if len(good) < 5 * bins else ""}


def binomial_rate(k: int, n: int, name: str) -> dict:
    return {"parameter": name, "estimate": k / n if n else float("nan"), "ci95_wilson": wilson(k, n), "k": k, "n": n}


def variance_components(values: np.ndarray, lot: np.ndarray, wafer: np.ndarray) -> dict:
    """Nested one-way method-of-moments: total = lot + wafer(lot) + die(wafer)."""
    import pandas as pd

    df = pd.DataFrame({"v": values, "lot": lot, "w": wafer})
    df["lw"] = df["lot"].astype(str) + "/" + df["w"].astype(str)
    die_var = df.groupby("lw")["v"].var(ddof=1).mean()
    wm = df.groupby("lw").agg(v=("v", "mean"), lot=("lot", "first"), n=("v", "size"))
    nbar = wm["n"].mean()
    wafer_var = max(0.0, wm.groupby("lot")["v"].var(ddof=1).mean() - die_var / nbar)
    lm = wm.groupby("lot")["v"].mean()
    wpl = wm.groupby("lot").size().mean()
    lot_var = max(0.0, lm.var(ddof=1) - (wafer_var + die_var / nbar) / wpl) if len(lm) > 1 else float("nan")
    return {"mean": float(df["v"].mean()), "lot_sd": math.sqrt(lot_var) if lot_var == lot_var else float("nan"),
            "wafer_sd": math.sqrt(wafer_var), "die_sd": math.sqrt(die_var), "lots": int(len(lm)),
            "method": "nested method of moments (balanced-design approximation)"}


def fit_learning_curve(t: np.ndarray, d0: np.ndarray) -> dict:
    t = np.asarray(t, float)
    d0 = np.asarray(d0, float)
    if t.size < 4:
        return {"status": "REFUSED", "reason": f"{t.size} measured runs < 4: a learning curve would be a "
                                               "hypothetical scenario, not a fit"}

    def f(tt, dinf, dstart, tau):
        return dinf + (dstart - dinf) * np.exp(-tt / tau)

    p0 = [d0.min() * 0.8, d0.max(), max(float(np.ptp(t)), 1.0) / 2]
    popt, pcov = optimize.curve_fit(f, t, d0, p0=p0, bounds=([0, 0, 1e-6], [np.inf, np.inf, np.inf]), maxfev=20000)
    se = np.sqrt(np.diag(pcov))
    return {"status": "FITTED", "d_inf": popt[0], "d_start": popt[1], "tau": popt[2], "se": se.tolist(),
            "note": "empirical fit to measured runs only; extrapolation beyond the data is not a forecast"}
