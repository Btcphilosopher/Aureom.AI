r"""SRAM defect, fault-type and repair model.

1. A fatal defect inside an SRAM macro becomes one **fault** whose type is drawn
   from a configurable mixture (bit-cell, row / word-line, column / bit-line,
   address decoder, periphery / access port).  The mixture is HYPOTHETICAL for
   SilicaFlux (no macro failure-mode data from IHP is in the repository).
   Retention faults are only produced if ``retention`` has a non-zero weight and
   are only detectable by the RETENTION algorithm (TestCore r1 docs/04_mbist.md).
2. Bit / row / column faults get array coordinates from the defect position
   inside the macro bounding box and the macro organisation (rows x cols from the
   IHP macro name, e.g. 2048x64_c2 -> 1024 rows x 128 columns).
3. A repair **scheme** decides whether the macro still works:

   ``none``      any fault -> macro fails
   ``rows``      k spare rows / macro; bit and row faults need a row, column faults are unrepairable
   ``cols``      k spare columns; bit and column faults need a column, row faults are unrepairable
   ``rows_cols`` exact small-case BIRA (must-repair, then exhaustive allocation of bit faults)
   ``ecc``       SECDED per data word: correctable iff every codeword has <= 1 faulty bit.
                 Row, decoder and periphery faults are never correctable.  Using ECC to mask
                 manufacturing faults consumes the soft-error margin -> reported as a quality risk.
   ``bank_disable``  failed banks are disabled; the die becomes a *reduced-capacity* product.

4. Every scheme other than ``none`` needs a :class:`RepairCapability`.  It is
   applied in *implemented* mode only when hardware, configuration storage
   (fuse / OTP) where needed, BIRA/firmware, validation and (for capacity
   binning) a product specification are all evidenced.  Otherwise results are
   labelled CONDITIONAL / HYPOTHETICAL and are never counted as true good die.

Audit finding for SilicaFlux-V: none of the macros has spare rows or columns,
there is no fuse/OTP repair path, TestCore reports CAPS.REPAIR = 0, there is no
ECC or parity and no bank disable.  The only implemented scheme is ``none``.
"""
from __future__ import annotations

import itertools
from typing import Literal, Optional

import numpy as np
from pydantic import BaseModel, ConfigDict, Field, model_validator

FAULT_TYPES = ["bit", "row", "column", "decoder", "periphery", "retention"]


class SramFaultMix(BaseModel):
    model_config = ConfigDict(extra="forbid")
    bit: float = Field(0.60, ge=0)
    row: float = Field(0.15, ge=0)
    column: float = Field(0.15, ge=0)
    decoder: float = Field(0.05, ge=0)
    periphery: float = Field(0.05, ge=0)
    retention: float = Field(0.0, ge=0)
    source: str = "HYPOTHETICAL"
    reference: str = "hypothetical SRAM fault-type mixture; no macro failure-mode data available"

    def probs(self) -> np.ndarray:
        p = np.array([self.bit, self.row, self.column, self.decoder, self.periphery, self.retention], float)
        if p.sum() <= 0:
            raise ValueError("SRAM fault mixture must have positive weight")
        return p / p.sum()


class Evidence(BaseModel):
    model_config = ConfigDict(extra="forbid")
    status: Literal["implemented", "hypothetical", "absent"] = "absent"
    reference: str = ""


class RepairCapability(BaseModel):
    model_config = ConfigDict(extra="forbid")
    scheme: Literal["none", "rows", "cols", "rows_cols", "ecc", "bank_disable"] = "none"
    spare_rows: int = Field(0, ge=0)
    spare_cols: int = Field(0, ge=0)
    hardware: Evidence = Field(default_factory=Evidence)
    configuration_storage: Evidence = Field(default_factory=Evidence)
    bira_or_firmware: Evidence = Field(default_factory=Evidence)
    validation: Evidence = Field(default_factory=Evidence)
    product_spec: Evidence = Field(default_factory=Evidence)
    area_overhead_fraction_of_sram: float = Field(0.0, ge=0)
    area_overhead_source: str = "HYPOTHETICAL"

    @model_validator(mode="after")
    def _check(self) -> "RepairCapability":
        if self.scheme in ("rows", "rows_cols") and self.spare_rows == 0:
            raise ValueError("row repair needs spare_rows > 0")
        if self.scheme in ("cols", "rows_cols") and self.spare_cols == 0:
            raise ValueError("column repair needs spare_cols > 0")
        return self

    def required(self) -> list[str]:
        if self.scheme == "none":
            return []
        req = ["hardware", "bira_or_firmware", "validation"]
        if self.scheme in ("rows", "cols", "rows_cols", "bank_disable"):
            req.append("configuration_storage")
        if self.scheme == "bank_disable":
            req.append("product_spec")
        return req

    @property
    def implemented(self) -> bool:
        return all(getattr(self, r).status == "implemented" for r in self.required())

    def missing(self) -> list[str]:
        return [r for r in self.required() if getattr(self, r).status != "implemented"]

    def label(self) -> str:
        if self.scheme == "none":
            return "NO REPAIR (implemented)"
        return f"{self.scheme.upper()} ({'implemented' if self.implemented else 'CONDITIONAL - hypothetical capability: missing ' + ', '.join(self.missing())})"


class SramModel(BaseModel):
    model_config = ConfigDict(extra="forbid")
    fault_mix: SramFaultMix = Field(default_factory=SramFaultMix)
    repair: RepairCapability = Field(default_factory=RepairCapability)


# --------------------------------------------------------------------------- repair analysis per macro

def _rows_cols_repairable(bits: list[tuple[int, int]], rows: set[int], cols: set[int], kr: int, kc: int) -> bool:
    """Exact BIRA for small fault sets: row faults use rows, column faults use cols, bits use either."""
    kr -= len(rows)
    kc -= len(cols)
    if kr < 0 or kc < 0:
        return False
    bits = [(r, c) for r, c in bits if r not in rows and c not in cols]
    # must-repair, one decision at a time: a row with more faulty bits than the remaining spare
    # columns needs a spare row (and vice versa); repaired bits are removed before the next decision
    rows_used, cols_used = set(), set()
    while True:
        rem_r, rem_c = kr - len(rows_used), kc - len(cols_used)
        if rem_r < 0 or rem_c < 0:
            return False
        by_row: dict[int, int] = {}
        by_col: dict[int, int] = {}
        for r, c in bits:
            by_row[r] = by_row.get(r, 0) + 1
            by_col[c] = by_col.get(c, 0) + 1
        must_r = next((r for r, n in by_row.items() if n > rem_c), None)
        if must_r is not None:
            rows_used.add(must_r)
            bits = [(r, c) for r, c in bits if r != must_r]
            continue
        must_c = next((c for c, n in by_col.items() if n > rem_r), None)
        if must_c is not None:
            cols_used.add(must_c)
            bits = [(r, c) for r, c in bits if c != must_c]
            continue
        break
    kr -= len(rows_used)
    kc -= len(cols_used)
    if not bits:
        return True
    urows = sorted({r for r, _ in bits})
    if len(urows) > 14:
        return False   # conservative: treat very large fault sets as unrepairable
    for nr in range(min(kr, len(urows)) + 1):
        for chosen in itertools.combinations(urows, nr):
            rest_cols = {c for r, c in bits if r not in chosen}
            if len(rest_cols) <= kc:
                return True
    return False


def macro_repairable(faults: list[tuple], org: dict, cap: RepairCapability) -> bool:
    """faults: (type, row, col).  Returns True if the macro works after the repair scheme."""
    if not faults:
        return True
    scheme = cap.scheme
    if scheme == "none" or scheme == "bank_disable":
        return False
    types = {f[0] for f in faults}
    if types & {"decoder", "periphery", "retention"} and scheme != "ecc":
        return False
    if scheme == "ecc":
        if types & {"row", "decoder", "periphery"}:
            return False
        mux = org["column_mux"]
        # codeword = (row, column mod mux); count faulty bits per codeword
        cols_faulty = {c for t, r, c in faults if t == "column"}
        counts: dict[tuple[int, int], int] = {}
        for t, r, c in faults:
            if t in ("bit", "retention"):
                counts[(r, c % mux)] = counts.get((r, c % mux), 0) + 1
        # each faulty column adds one bad bit to every codeword of its word-select
        col_sel: dict[int, int] = {}
        for c in cols_faulty:
            col_sel[c % mux] = col_sel.get(c % mux, 0) + 1
        if any(n >= 2 for n in col_sel.values()):
            return False
        for (r, sel), n in counts.items():
            if n + col_sel.get(sel, 0) >= 2:
                return False
        return True
    rows = {r for t, r, c in faults if t == "row"}
    cols = {c for t, r, c in faults if t == "column"}
    bits = [(r, c) for t, r, c in faults if t == "bit"]
    if scheme == "rows":
        if cols:
            return False
        return len(rows | {r for r, _ in bits}) <= cap.spare_rows
    if scheme == "cols":
        if rows:
            return False
        return len(cols | {c for _, c in bits}) <= cap.spare_cols
    return _rows_cols_repairable(bits, rows, cols, cap.spare_rows, cap.spare_cols)


def assign_faults(model: SramModel, lx_um: np.ndarray, ly_um: np.ndarray, macro_bbox_um: np.ndarray,
                  orgs: list[dict], macro_idx: np.ndarray, rng: np.random.Generator):
    """Draw fault type and array coordinates for fatal SRAM hits (vectorised)."""
    n = macro_idx.size
    t = rng.choice(len(FAULT_TYPES), size=n, p=model.fault_mix.probs())
    bb = macro_bbox_um[macro_idx]
    fx = np.clip((lx_um - bb[:, 0]) / np.maximum(bb[:, 2] - bb[:, 0], 1e-9), 0, 1 - 1e-12)
    fy = np.clip((ly_um - bb[:, 1]) / np.maximum(bb[:, 3] - bb[:, 1], 1e-9), 0, 1 - 1e-12)
    rows = np.array([orgs[m]["rows"] for m in macro_idx], dtype=int) if n else np.zeros(0, int)
    cols = np.array([orgs[m]["cols"] for m in macro_idx], dtype=int) if n else np.zeros(0, int)
    r = np.floor(fy * rows).astype(int)
    c = np.floor(fx * cols).astype(int)
    return t, r, c


def evaluate_die_memories(fault_t: np.ndarray, fault_r: np.ndarray, fault_c: np.ndarray, macro_idx: np.ndarray,
                          orgs: list[dict], bank_of: list[str], cap: RepairCapability) -> dict:
    """Outcome for one die's SRAM faults under the repair capability."""
    if macro_idx.size == 0:
        return {"sram_faulty": False, "sram_fail_unrepaired": False, "repaired": False,
                "failed_banks": [], "fault_types": [], "repairable_under_scheme": True}
    failed_macros = []
    by_macro: dict[int, list] = {}
    for t, r, c, m in zip(fault_t, fault_r, fault_c, macro_idx):
        by_macro.setdefault(int(m), []).append((FAULT_TYPES[int(t)], int(r), int(c)))
    for m, faults in by_macro.items():
        if not macro_repairable(faults, orgs[m], cap):
            failed_macros.append(m)
    failed_banks = sorted({bank_of[m] for m in failed_macros})
    repairable = not failed_macros
    if cap.scheme == "bank_disable":
        # all failing banks can be disabled -> reduced capacity product (not a full product)
        repairable = False
    return {
        "sram_faulty": True,
        "sram_fail_unrepaired": True,                   # before applying any repair
        "repaired": repairable and cap.scheme != "none",
        "failed_banks": failed_banks,
        "fault_types": sorted({FAULT_TYPES[int(t)] for t in fault_t}),
        "repairable_under_scheme": repairable,
    }


def ecc_area_overhead(data_bits: int) -> float:
    """SECDED check bits for a data word: smallest r with 2^r >= data_bits + r + 1, plus 1 parity bit."""
    r = 1
    while 2**r < data_bits + r + 1:
        r += 1
    return (r + 1) / data_bits
