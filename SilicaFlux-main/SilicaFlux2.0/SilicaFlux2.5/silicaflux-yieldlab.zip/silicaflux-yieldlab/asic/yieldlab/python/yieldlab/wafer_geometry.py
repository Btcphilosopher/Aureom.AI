"""Circular wafer geometry with edge exclusion, notch / flat and exclusion zones.

Coordinate system: wafer centre at (0, 0), millimetres, +x right, +y up.  The
orientation feature (notch or flat) is placed at ``orientation_deg`` measured
counter-clockwise from +x (270 deg = bottom, the usual "notch down" view).

Containment is **exact** (not centre-point based):

* disc and flat: the usable region ``disc(R - e)  intersect  {n.p >= -d + e}`` is convex,
  so an axis-aligned rectangle lies inside it iff its four corners do.  This
  is evaluated analytically and vectorised.
* notch and user exclusion zones (non-convex cut-outs): tested with Shapely
  against the exclusion polygon buffered by the edge-exclusion distance.  The
  buffer arcs are approximated with ``quad_segs = 64`` segments per quarter
  circle; the worst-case radial error is ``e * (1 - cos(pi / 256))``, i.e.
  0.23 um for e = 3 mm.  Only sites within reach of a cut-out are sent to
  Shapely, so the cost is negligible.

The wafer diameters offered (100/150/200/300 mm) are simulation choices, not a
statement that a given foundry runs that diameter.
"""
from __future__ import annotations

import math
from typing import Literal, Optional

import numpy as np
import shapely
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from shapely.geometry import Polygon, box

from .provenance import Source, Sourced

STANDARD_DIAMETERS_MM = (100.0, 150.0, 200.0, 300.0)
_QUAD_SEGS = 64


class NotchSpec(BaseModel):
    """V-notch (SEMI M1 style).  Nominal SEMI M1: depth 1.00 mm, 90 deg opening."""

    model_config = ConfigDict(extra="forbid")
    kind: Literal["notch"] = "notch"
    depth_mm: float = Field(gt=0, le=5)
    angle_deg: float = Field(gt=0, lt=180)
    orientation_deg: float = 270.0
    source: Source = Source.STANDARD_REFERENCE
    reference: str = "SEMI M1 nominal notch; confirm against the wafer supplier specification"


class FlatSpec(BaseModel):
    """Primary flat, given by its chord length."""

    model_config = ConfigDict(extra="forbid")
    kind: Literal["flat"] = "flat"
    length_mm: float = Field(gt=0)
    orientation_deg: float = 270.0
    source: Source = Source.STANDARD_REFERENCE
    reference: str = "SEMI M1 nominal primary flat; confirm against the wafer supplier specification"


class ExclusionZone(BaseModel):
    """Additional layout exclusion zone (laser mark, clamp ring, PCM area...) as a polygon in mm."""

    model_config = ConfigDict(extra="forbid")
    name: str
    polygon_mm: list[tuple[float, float]] = Field(min_length=3)
    reference: str = "user configuration"


class WaferSpec(BaseModel):
    model_config = ConfigDict(extra="forbid")

    diameter_mm: float = Field(gt=0)
    edge_exclusion_mm: float = Field(ge=0)
    edge_exclusion_source: Source = Source.HYPOTHETICAL
    edge_exclusion_reference: str = "hypothetical edge exclusion; no foundry value supplied"
    orientation: Optional[NotchSpec | FlatSpec] = Field(default=None, discriminator="kind")
    exclusion_zones: list[ExclusionZone] = Field(default_factory=list)
    allow_nonstandard_diameter: bool = False

    @field_validator("diameter_mm")
    @classmethod
    def _diam(cls, v: float) -> float:
        return float(v)

    @model_validator(mode="after")
    def _validate(self) -> "WaferSpec":
        if not self.allow_nonstandard_diameter and self.diameter_mm not in STANDARD_DIAMETERS_MM:
            raise ValueError(
                f"wafer diameter {self.diameter_mm} mm is not one of the supported simulation diameters "
                f"{STANDARD_DIAMETERS_MM}; set allow_nonstandard_diameter: true to override"
            )
        r = self.diameter_mm / 2
        if self.edge_exclusion_mm >= r:
            raise ValueError("edge exclusion must be smaller than the wafer radius")
        if isinstance(self.orientation, FlatSpec) and self.orientation.length_mm >= self.diameter_mm:
            raise ValueError("flat length must be shorter than the wafer diameter")
        if isinstance(self.orientation, NotchSpec) and self.orientation.depth_mm >= r / 4:
            raise ValueError("notch depth is implausibly large for this wafer")
        return self

    @property
    def radius_mm(self) -> float:
        return self.diameter_mm / 2.0

    def edge_exclusion_sourced(self) -> Sourced:
        return Sourced(value=self.edge_exclusion_mm, source=self.edge_exclusion_source,
                       reference=self.edge_exclusion_reference)


def _unit(deg: float) -> tuple[float, float]:
    a = math.radians(deg)
    return math.cos(a), math.sin(a)


class WaferGeometry:
    """Exact containment / intersection queries for rectangles on a wafer."""

    def __init__(self, spec: WaferSpec):
        self.spec = spec
        self.R = spec.radius_mm
        self.e = spec.edge_exclusion_mm
        self.flat = spec.orientation if isinstance(spec.orientation, FlatSpec) else None
        self.notch = spec.orientation if isinstance(spec.orientation, NotchSpec) else None
        # flat: wafer = {p : n.p >= -d}, n = unit vector from the flat towards the centre
        if self.flat is not None:
            ux, uy = _unit(self.flat.orientation_deg)
            self._flat_n = (-ux, -uy)
            self._flat_d = math.sqrt(self.R**2 - (self.flat.length_mm / 2) ** 2)
        self._notch_tri: Optional[Polygon] = None
        self._notch_keepout: Optional[Polygon] = None
        if self.notch is not None:
            self._notch_tri = self._make_notch_triangle()
            self._notch_keepout = self._notch_tri.buffer(self.e, quad_segs=_QUAD_SEGS) if self.e > 0 else self._notch_tri
        self._zones = [Polygon(z.polygon_mm) for z in spec.exclusion_zones]
        for z, p in zip(spec.exclusion_zones, self._zones):
            if not p.is_valid:
                raise ValueError(f"exclusion zone {z.name!r} is not a valid polygon")
        self._wafer_poly: Optional[Polygon] = None
        self._usable_poly: Optional[Polygon] = None

    # ------------------------------------------------------------------ features
    def _make_notch_triangle(self) -> Polygon:
        n = self.notch
        ux, uy = _unit(n.orientation_deg)
        vx, vy = -uy, ux
        apex = ((self.R - n.depth_mm) * ux, (self.R - n.depth_mm) * uy)
        half = math.radians(n.angle_deg / 2)
        reach = 3.0 * n.depth_mm / math.cos(half) + 1.0
        p1 = (apex[0] + reach * (ux * math.cos(half) + vx * math.sin(half)),
              apex[1] + reach * (uy * math.cos(half) + vy * math.sin(half)))
        p2 = (apex[0] + reach * (ux * math.cos(half) - vx * math.sin(half)),
              apex[1] + reach * (uy * math.cos(half) - vy * math.sin(half)))
        return Polygon([apex, p1, p2])

    def notch_triangle(self) -> Optional[Polygon]:
        return self._notch_tri

    # ------------------------------------------------------------------ polygons (plotting / reference)
    def _disc(self, r: float, n: int = 4096) -> Polygon:
        t = np.linspace(0, 2 * np.pi, n, endpoint=False)
        return Polygon(np.c_[r * np.cos(t), r * np.sin(t)])

    def wafer_polygon(self) -> Polygon:
        if self._wafer_poly is None:
            p = self._disc(self.R)
            if self.flat is not None:
                p = p.intersection(self._halfplane_poly(0.0))
            if self._notch_tri is not None:
                p = p.difference(self._notch_tri)
            self._wafer_poly = p
        return self._wafer_poly

    def usable_polygon(self) -> Polygon:
        if self._usable_poly is None:
            p = self._disc(self.R - self.e)
            if self.flat is not None:
                p = p.intersection(self._halfplane_poly(self.e))
            if self._notch_keepout is not None:
                p = p.difference(self._notch_keepout)
            self._usable_poly = p
        return self._usable_poly

    def _halfplane_poly(self, inset: float) -> Polygon:
        nx, ny = self._flat_n
        d = self._flat_d - inset
        big = 4 * self.R
        # points p with n.p >= -d : build a big square on that side
        tx, ty = -ny, nx
        base = (-d * nx, -d * ny)
        return Polygon([
            (base[0] + big * tx, base[1] + big * ty),
            (base[0] + big * tx + big * nx, base[1] + big * ty + big * ny),
            (base[0] - big * tx + big * nx, base[1] - big * ty + big * ny),
            (base[0] - big * tx, base[1] - big * ty),
        ])

    def usable_area_mm2(self) -> float:
        return float(self.usable_polygon().area)

    def wafer_area_mm2(self) -> float:
        return float(self.wafer_polygon().area)

    # ------------------------------------------------------------------ vectorised rectangle queries
    @staticmethod
    def _corners(x0, y0, x1, y1):
        return [(x0, y0), (x1, y0), (x0, y1), (x1, y1)]

    def _corner_test(self, x0, y0, x1, y1, inset: float) -> np.ndarray:
        r = self.R - inset
        ok = np.ones(np.shape(x0), dtype=bool)
        for cx, cy in self._corners(x0, y0, x1, y1):
            ok &= (cx * cx + cy * cy) <= r * r
        if self.flat is not None:
            nx, ny = self._flat_n
            d = self._flat_d - inset
            for cx, cy in self._corners(x0, y0, x1, y1):
                ok &= (nx * cx + ny * cy) >= -d
        return ok

    def _rect_hits_poly(self, x0, y0, x1, y1, poly: Polygon, candidates: np.ndarray) -> np.ndarray:
        """True where the rectangle overlaps *poly* with positive area (exact, Shapely)."""
        hit = np.zeros(np.shape(x0), dtype=bool)
        idx = np.nonzero(candidates)[0]
        if idx.size == 0:
            return hit
        boxes = shapely.box(x0[idx], y0[idx], x1[idx], y1[idx])
        inter = shapely.intersection(boxes, poly)
        hit[idx] = shapely.area(inter) > 1e-12
        return hit

    def _near(self, x0, y0, x1, y1, poly: Polygon, margin: float = 0.0) -> np.ndarray:
        bx0, by0, bx1, by1 = poly.bounds
        return (x1 >= bx0 - margin) & (x0 <= bx1 + margin) & (y1 >= by0 - margin) & (y0 <= by1 + margin)

    def contains_usable(self, x0, y0, x1, y1) -> np.ndarray:
        """Rectangle entirely inside the usable area (edge exclusion + notch keep-out applied)."""
        x0, y0, x1, y1 = map(np.asarray, (x0, y0, x1, y1))
        ok = self._corner_test(x0, y0, x1, y1, self.e)
        if self._notch_keepout is not None:
            cand = ok & self._near(x0, y0, x1, y1, self._notch_keepout)
            ok &= ~self._rect_hits_poly(x0, y0, x1, y1, self._notch_keepout, cand)
        return ok

    def contains_physical(self, x0, y0, x1, y1) -> np.ndarray:
        """Rectangle entirely on the physical wafer (no edge exclusion)."""
        x0, y0, x1, y1 = map(np.asarray, (x0, y0, x1, y1))
        ok = self._corner_test(x0, y0, x1, y1, 0.0)
        if self._notch_tri is not None:
            cand = ok & self._near(x0, y0, x1, y1, self._notch_tri)
            ok &= ~self._rect_hits_poly(x0, y0, x1, y1, self._notch_tri, cand)
        return ok

    def intersects_physical(self, x0, y0, x1, y1) -> np.ndarray:
        """Rectangle overlaps the physical wafer with positive area."""
        x0, y0, x1, y1 = map(np.asarray, (x0, y0, x1, y1))
        # distance from the origin to the rectangle
        dx = np.maximum(np.maximum(x0, -x1), 0.0)
        dy = np.maximum(np.maximum(y0, -y1), 0.0)
        hit = (dx * dx + dy * dy) < self.R * self.R
        if self.flat is not None or self._notch_tri is not None:
            # refine every candidate that is not fully inside, exactly, with Shapely
            inside = self.contains_physical(x0, y0, x1, y1)
            cand = hit & ~inside
            wp = self.wafer_polygon()
            refined = self._rect_hits_poly(x0, y0, x1, y1, wp, cand)
            hit = inside | refined
        return hit

    def hits_exclusion_zone(self, x0, y0, x1, y1) -> np.ndarray:
        x0, y0, x1, y1 = map(np.asarray, (x0, y0, x1, y1))
        hit = np.zeros(np.shape(x0), dtype=bool)
        for z in self._zones:
            hit |= self._rect_hits_poly(x0, y0, x1, y1, z, self._near(x0, y0, x1, y1, z))
        return hit

    def edge_distance(self, x0, y0, x1, y1) -> np.ndarray:
        """Shortest distance (mm) from the rectangle to the physical wafer edge.

        Positive when the rectangle lies on the wafer; negative values give the
        protrusion beyond the edge.  Notch distances are exact (Shapely)."""
        x0, y0, x1, y1 = map(np.asarray, (x0, y0, x1, y1))
        maxr = np.zeros(np.shape(x0))
        for cx, cy in self._corners(x0, y0, x1, y1):
            maxr = np.maximum(maxr, np.hypot(cx, cy))
        dist = self.R - maxr
        if self.flat is not None:
            nx, ny = self._flat_n
            mn = np.full(np.shape(x0), np.inf)
            for cx, cy in self._corners(x0, y0, x1, y1):
                mn = np.minimum(mn, nx * cx + ny * cy)
            dist = np.minimum(dist, mn + self._flat_d)
        if self._notch_tri is not None:
            cand = self._near(x0, y0, x1, y1, self._notch_tri, margin=self.R / 10)
            idx = np.nonzero(cand)[0]
            if idx.size:
                boxes = shapely.box(x0[idx], y0[idx], x1[idx], y1[idx])
                dn = shapely.distance(boxes, self._notch_tri)
                dist[idx] = np.minimum(dist[idx], dn)
        return dist


def standard_orientation(diameter_mm: float) -> Optional[NotchSpec | FlatSpec]:
    """SEMI M1 nominal orientation feature for the supported diameters.

    100 mm: primary flat 32.5 mm; 150 mm: primary flat 57.5 mm; 200 / 300 mm:
    notch 1.00 mm deep, 90 deg.  These are standard reference values, not data
    from a SilicaFlux foundry; they are only applied when a config asks for them.
    """
    if diameter_mm == 100.0:
        return FlatSpec(length_mm=32.5)
    if diameter_mm == 150.0:
        return FlatSpec(length_mm=57.5)
    if diameter_mm in (200.0, 300.0):
        return NotchSpec(depth_mm=1.0, angle_deg=90.0)
    return None


def box_poly(x0: float, y0: float, x1: float, y1: float) -> Polygon:
    return box(x0, y0, x1, y1)
