# SilicaFlux YieldLab run `mcu_i_industrial_200mm__seed42__4x25__ba05b294e6`

> **SIMULATED - HYPOTHETICAL SCENARIO (uses hypothetical / estimated inputs)**  
> Synthetic wafer maps and yields - NOT measured foundry data. Passing these checks does not establish manufacturability or commercial yield.

## Reproducibility

* scenario `mcu_i_industrial_200mm` sha256 `ba05b294e6af6cda25573da4e53af6c02160864e540540ef2eac589e50ced1da`
* seed 42, 4 lots x 25 wafers = 100 wafers; 1 worker(s); 0.358 s
* RNG: numpy PCG64 via SeedSequence(seed, spawn_key=(lot, wafer, stream)); streams {'defects': 0, 'locate': 1, 'fatal': 2, 'sram': 3, 'test': 4, 'parametric': 5, 'packaging': 6}
* software: yieldlab 0.1.0, python 3.13.18, numpy 2.5.3, scipy 1.18.1, pandas 3.0.5, shapely 2.2.0, pydantic 2.13.5, matplotlib 3.11.2, plotly 7.1.0
* repair: NO REPAIR (implemented); fatality model: all_fatal; defect model: baseline_mixture (fatal)

## Die and wafer geometry

* die 3563.70 x 3563.70 um = 12.700 mm^2 (PLANNING_ESTIMATE: silicaflux-mcu-i docs/ASIC.md planning estimate 12.7 mm^2 (IHP SG13G2), square assumed)
* pitch 3.6437 x 3.6437 mm, footprint convention `die_plus_half_street`
* wafer 200.0 mm, edge exclusion 3.0 mm (HYPOTHETICAL)

| site class | count |
|---|---|
| FULL DIE | 2128 |
| PARTIAL / EDGE-STRADDLING | 216 |
| EDGE-EXCLUDED | 113 |
| UNPRINTABLE | 0 |
| VALID TEST SITE | 0 |

**Eligible (FULL DIE) sites: 2128**; dies per reticle field [7, 9]

| method | value | geometry count | difference |
|---|---|---|---|
| area_ratio (approximation (upper bound)) | 2226.4 | 2128 | +98.4 (+4.63 %) |
| edge_corrected (approximation) | 2108.1 | 2128 | -19.9 (-0.93 %) |
| row_chord (semi-analytical upper bound (disc only)) | 2153.0 | 2128 | +25.0 (+1.17 %) |

Geometric loss: 14.0 % of the wafer area is not eligible die silicon (edge band + notch 1859 mm^2, streets 1227 mm^2, boundary cells 1304 mm^2).
Footprint-convention sensitivity: {'die': 2128, 'die_plus_half_street': 2128, 'die_plus_full_street': 2110}.
Best grid translation found: (0.000, 0.000) mm -> 2128 full dies (+0 vs configured).

## Yield definitions (every denominator explicit)

| metric | numerator / denominator |
|---|---|
| site_utilisation | eligible FULL-DIE sites / all die sites touching the wafer |
| defect_limited_yield | eligible dies without a fatal defect (before any repair) / eligible dies |
| functional_yield | eligible dies functional after IMPLEMENTED repair / eligible dies |
| true_good_yield | conforming dies that passed every probe step / eligible dies |
| observed_probe_yield | dies passing every probe step (incl. escapes) / tested dies |
| probe_escape_fraction | nonconforming dies that passed probe / dies that passed probe |
| false_reject_fraction | conforming dies rejected at probe / conforming dies |
| delivered_conforming_yield | conforming dies delivered after packaging + final test / eligible dies |
| shipped_escape_fraction | nonconforming dies among delivered dies / delivered dies |

## Results per wafer

CI = 95 % confidence interval of the *expected* value (lot-cluster t on lot means). PI = 90 % predictive interval for *one future wafer* / lot total. They are not interchangeable.

| metric | mean | sd | P5 | P50 | P95 | 95 % CI (mean) | naive iid CI | ICC(lot) | 90 % PI next wafer |
|---|---|---|---|---|---|---|---|---|---|
| eligible | 2,128.00 | 0.00 | 2,128.00 | 2,128.00 | 2,128.00 | [2,128.00, 2,128.00] | [2,128.00, 2,128.00] | 0.000 | [2,128.0, 2,128.0] |
| phys_defect_dies | 66.19 | 29.67 | 23.80 | 64.50 | 115.25 | [38.57, 93.81] | [60.30, 72.08] | 0.2897 | [23.8, 115.2] |
| functional_fail_raw | 66.19 | 29.67 | 23.80 | 64.50 | 115.25 | [38.57, 93.81] | [60.30, 72.08] | 0.2897 | [23.8, 115.2] |
| functional_fail | 66.19 | 29.67 | 23.80 | 64.50 | 115.25 | [38.57, 93.81] | [60.30, 72.08] | 0.2897 | [23.8, 115.2] |
| param_fail_only | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | [0.00, 0.00] | [0.00, 0.00] | 0.000 | [0.0, 0.0] |
| outcome_TRUE_GOOD_PASS | 2,061.80 | 29.68 | 2,012.75 | 2,063.50 | 2,104.20 | [2,034.18, 2,089.42] | [2,055.91, 2,067.69] | 0.2896 | [2,012.8, 2,104.2] |
| outcome_DEFECTIVE_DETECTED | 60.83 | 27.49 | 18.95 | 59.00 | 106.05 | [35.39, 86.27] | [55.38, 66.28] | 0.2863 | [18.9, 106.0] |
| outcome_DEFECTIVE_ESCAPED | 5.36 | 3.18 | 1.00 | 5.00 | 10.05 | [3.14, 7.58] | [4.73, 5.99] | 0.1527 | [1.0, 10.0] |
| outcome_GOOD_REJECTED | 0.01 | 0.1 | 0.00 | 0.00 | 0.00 | [-0.02182, 0.04182] | [-0.009842, 0.02984] | 0.000 | [0.0, 0.0] |
| probe_pass | 2,067.16 | 27.50 | 2,021.95 | 2,069.00 | 2,109.05 | [2,041.72, 2,092.60] | [2,061.70, 2,072.62] | 0.2861 | [2,022.0, 2,109.1] |
| delivered | 2,045.67 | 28.93 | 1,995.85 | 2,047.00 | 2,091.00 | [2,018.53, 2,072.81] | [2,039.93, 2,051.41] | 0.2945 | [1,995.8, 2,091.0] |
| delivered_conforming | 2,040.60 | 30.12 | 1,991.40 | 2,042.50 | 2,085.15 | [2,012.14, 2,069.06] | [2,034.62, 2,046.58] | 0.2991 | [1,991.4, 2,085.2] |
| delivered_escape | 5.07 | 2.53 | 2.00 | 5.00 | 10.00 | [3.68, 6.46] | [4.57, 5.57] | 0.08049 | [2.0, 10.0] |
| site_utilisation | 0.8661 | 1.116e-16 | 0.8661 | 0.8661 | 0.8661 | [0.8661, 0.8661] | [0.8661, 0.8661] | 1.000 | [0.8661, 0.8661] |
| defect_limited_yield | 0.9689 | 0.01394 | 0.9458 | 0.9697 | 0.9888 | [0.9559, 0.9819] | [0.9661, 0.9717] | 0.2897 | [0.9458, 0.9888] |
| functional_yield | 0.9689 | 0.01394 | 0.9458 | 0.9697 | 0.9888 | [0.9559, 0.9819] | [0.9661, 0.9717] | 0.2897 | [0.9458, 0.9888] |
| true_good_yield | 0.9689 | 0.01395 | 0.9458 | 0.9697 | 0.9888 | [0.9559, 0.9819] | [0.9661, 0.9717] | 0.2896 | [0.9458, 0.9888] |
| observed_probe_yield | 0.9714 | 0.01292 | 0.9502 | 0.9723 | 0.9911 | [0.9595, 0.9834] | [0.9688, 0.974] | 0.2861 | [0.9502, 0.9911] |
| probe_escape_fraction | 0.002607 | 0.001569 | 0.0004757 | 0.002417 | 0.005009 | [0.001488, 0.003726] | [0.002295, 0.002918] | 0.1595 | [0.0004757, 0.005009] |
| false_reject_fraction | 4.9e-06 | 4.9e-05 | 0.00 | 0.00 | 0.00 | [-1.069e-05, 2.049e-05] | [-4.822e-06, 1.462e-05] | 1.378e-17 | [0.0, 0.0] |
| delivered_conforming_yield | 0.9589 | 0.01415 | 0.9358 | 0.9598 | 0.9799 | [0.9456, 0.9723] | [0.9561, 0.9617] | 0.2991 | [0.9358, 0.9799] |
| shipped_escape_fraction | 0.002487 | 0.00126 | 0.0009612 | 0.002417 | 0.004964 | [0.001768, 0.003205] | [0.002237, 0.002736] | 0.08941 | [0.0009612, 0.004964] |

P(true good dies per wafer >= 2023) = 0.900 (Wilson 95 % [0.8256, 0.9448]).

### Monte Carlo convergence

| quantity | n | MCSE | relative MCSE | status |
|---|---|---|---|---|
| outcome_TRUE_GOOD_PASS | 100 | 4.338 | 0.0021 | CONVERGED |
| delivered_conforming | 100 | 4.531 | 0.0022 | CONVERGED |
| functional_fail_raw | 100 | 4.337 | 0.0655 | INSUFFICIENT |

Simulated defect-limited yield 0.9689; Poisson-equivalent D0 0.2488 /cm^2; wafer-yield sd 0.0139 vs 0.0038 if dies were independent (Poisson).

## Yield-model comparison at the simulated mean density

| model | assumption | analytical | Monte Carlo (+/- SE) |
|---|---|---|---|
| poisson | defect density identical for every die (no clustering); fatal defects independent | 0.96890 | 0.96879 +/- 0.00039 |
| negative_binomial | per-unit defect density ~ Gamma(alpha, D0/alpha); alpha = clustering parameter | 0.96898 | 0.96903 +/- 0.00039 |
| seeds | per-die defect density exponentially distributed (NB with alpha = 1) | 0.96937 | 0.96972 +/- 0.00038 |
| murphy | per-die defect density triangular on [0, 2 D0] (Murphy 1964) | 0.96898 | 0.96872 +/- 0.00039 |
| murphy_uniform | per-die defect density uniform on [0, 2 D0] | 0.96906 | 0.96903 +/- 0.00039 |
| empirical | parameters fitted to measured wafer data (calibration.py); requires imported data | NOT AVAILABLE - no measured SilicaFlux wafer data to fit | |

## Yield loss by functional region

| region | area mm^2 | % of die | % dies lost | sole-cause dies (all wafers) | escapes (all wafers) | detected by | coverage source |
|---|---|---|---|---|---|---|---|
| mcu_sram | 7.112 | 56.0 | 1.816 | 3497 | 151 | mbist | TestCore r2 March C- synthetic population (proxy); raw 36-bit storage incl. parity column tested |
| io_pads | 4.483 | 35.3 | 1.195 | 2183 | 222 | continuity | NOT AVAILABLE |
| mcu_logic | 1.105 | 8.7 | 0.369 | 545 | 165 | functional_selftest | NOT AVAILABLE - no scan / fault simulation for MCU-I |

## Flow (mean dies per wafer)

| step | dies / wafer |
|---|---|
| gross die sites touching the wafer | 2457.0 |
| - partial / edge-excluded / unprintable / test sites | -329.0 |
| = eligible FULL dies | 2128.0 |
| - functional failures (random defects, after implemented repair) | -66.2 |
| - conditional (hypothetical repair only) | -0.0 |
| - parametric-only failures | -0.0 |
| = conforming dies | 2061.8 |
| - good dies rejected at probe | -0.0 |
| - untested | 0.0 |
| = true good dies passing probe | 2061.8 |
|   (escapes also passing probe - quality risk, not good) | 5.4 |
| = delivered conforming after packaging + final test | 2040.6 |

## Economics

**SIMULATED - HYPOTHETICAL SCENARIO (uses hypothetical / estimated inputs)**

| stage | in | out | cost |
|---|---|---|---|
| FAB | 100 | 100 | 250,000 EUR |
| PROBE | 212800 | 206716 | 12,512 EUR |
| DICING | 100 | 100 | 3,000 EUR |
| PACKAGING | 206716 | 206716 | 124,030 EUR |
| FINAL_TEST | 206716 | 204567 | 51,679 EUR |
| SHIP | 204567 | 204567 | 4,091 EUR |

* cost per delivered CONFORMING die: **2.586 EUR** (NRE spread over 500000 delivered conforming units)
* escapes delivered: 507 (2478 DPPM) - excluded from the denominator
* recurring cost per conforming die, per wafer: mean 2.183, 90 % PI [2.155, 2.218]
* MPW: 53,400 EUR for 40.0 packaged prototypes, 38.8 expected good -> 1,378 per good prototype (SIMULATED - HYPOTHETICAL SCENARIO (uses hypothetical / estimated inputs))
* first silicon (ENGINEERING PROTOTYPE cost per usable chip (program cost / usable prototypes) - NOT comparable to volume cost per known-good die): 0 re-spin(s): 528,400 -> 13,634 per usable; 1 re-spin(s): 696,800 -> 17,979 per usable; 2 re-spin(s): 865,200 -> 22,324 per usable

## Input provenance

| input | value | source | reference |
|---|---|---|---|
| assembly_yield | 0.99 | HYPOTHETICAL | no assembly-house data |
| coverage.continuity.io | 0.9 | HYPOTHETICAL | no pad library / test program |
| coverage.final_functional.* | 0.3 | HYPOTHETICAL | residual |
| coverage.final_functional.assembly | 0.95 | HYPOTHETICAL | package test |
| coverage.functional_selftest.logic | 0.7 | HYPOTHETICAL | firmware self-test; no fault simulation |
| coverage.mbist.sram:bit | 0.933 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- all classes (synthetic, proxy) |
| coverage.mbist.sram:column | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- data-line stuck |
| coverage.mbist.sram:decoder | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- address decoder |
| coverage.mbist.sram:periphery | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- read path / error flag |
| coverage.mbist.sram:retention | 0.0 | MEASURED_TOOL_OUTPUT | March C- misses retention faults |
| coverage.mbist.sram:row | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- address decoder |
| defect_model | 'baseline_mixture' | HYPOTHETICAL | hypothetical mixture for SilicaFlux-V planning; no measured defect density, clustering or excursion data |
| die_outline | (3563.7, 3563.7) | PLANNING_ESTIMATE | silicaflux-mcu-i docs/ASIC.md planning estimate 12.7 mm^2 (IHP SG13G2), square assumed |
| edge_exclusion_mm | 3.0 | HYPOTHETICAL | hypothetical 3 mm edge exclusion; no foundry value supplied |
| fatality_model | 'all_fatal' | HYPOTHETICAL | hypothetical kill probabilities; no SilicaFlux defect-to-failure data exists |
| orientation_feature | 'notch' | STANDARD_REFERENCE | SEMI M1 nominal notch; confirm against the wafer supplier specification |
| reticle_field_mm | (26.0, 33.0) | HYPOTHETICAL | typical scanner field limit; confirm the reticle size with the foundry |
| scribe_um | (80.0, 80.0) | HYPOTHETICAL | hypothetical scribe street (incl. seal ring allowance); no foundry rule supplied |
| sram_fault_mix | {'bit': 0.6, 'row': 0.15, 'column': 0.15, 'decoder': 0.05, ' | HYPOTHETICAL | hypothetical SRAM fault-type mixture; no macro failure-mode data available |

## Figures

![convergence](figures/convergence.png)
![good_die_distribution](figures/good_die_distribution.png)
![loss_waterfall](figures/loss_waterfall.png)
![lot_distribution](figures/lot_distribution.png)
![region_loss](figures/region_loss.png)
![wafer_bins](figures/wafer_bins.png)
![wafer_defects](figures/wafer_defects.png)
![wafer_geometry](figures/wafer_geometry.png)
![wafer_outcomes](figures/wafer_outcomes.png)
![yield_models](figures/yield_models.png)
