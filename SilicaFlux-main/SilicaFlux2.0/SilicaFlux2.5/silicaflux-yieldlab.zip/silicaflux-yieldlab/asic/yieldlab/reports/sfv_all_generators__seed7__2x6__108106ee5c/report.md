# SilicaFlux YieldLab run `sfv_all_generators__seed7__2x6__108106ee5c`

> **SIMULATED - HYPOTHETICAL SCENARIO (uses hypothetical / estimated inputs)**  
> Synthetic wafer maps and yields - NOT measured foundry data. Passing these checks does not establish manufacturability or commercial yield.

## Reproducibility

* scenario `sfv_all_generators` sha256 `108106ee5c16baeb4d0582c69bb57d268f62f68787706a35282626e540324ae8`
* seed 7, 2 lots x 6 wafers = 12 wafers; 1 worker(s); 0.33 s
* RNG: numpy PCG64 via SeedSequence(seed, spawn_key=(lot, wafer, stream)); streams {'defects': 0, 'locate': 1, 'fatal': 2, 'sram': 3, 'test': 4, 'parametric': 5, 'packaging': 6}
* software: yieldlab 0.1.0, python 3.13.18, numpy 2.5.3, scipy 1.18.1, pandas 3.0.5, shapely 2.2.0, pydantic 2.13.5, matplotlib 3.11.2, plotly 7.1.0
* repair: NO REPAIR (implemented); fatality model: region_class; defect model: all_generators (inspection_particles)

## Die and wafer geometry

* die 4094.88 x 2879.34 um = 11.791 mm^2 (DERIVED: FloorplanLab C_sram_near_compute die 3494.88 x 2279.34 um (SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-floorplanlab.zip::silicaflux-floorplanlab/reports/runs/C_sram_near_compute/geometry.json (sha256 3ead0b0b9619)) + pad ring 300.0 um/side (PLANNING_ESTIMATE))
* pitch 4.1749 x 2.9593 mm, footprint convention `die_plus_half_street`
* wafer 200.0 mm, edge exclusion 3.0 mm (HYPOTHETICAL)

| site class | count |
|---|---|
| FULL DIE | 2280 |
| PARTIAL / EDGE-STRADDLING | 233 |
| EDGE-EXCLUDED | 156 |
| UNPRINTABLE | 0 |
| VALID TEST SITE | 0 |

**Eligible (FULL DIE) sites: 2280**; dies per reticle field [6, 11]

| method | value | geometry count | difference |
|---|---|---|---|
| area_ratio (approximation (upper bound)) | 2392.5 | 2280 | +112.5 (+4.93 %) |
| edge_corrected (approximation) | 2269.9 | 2280 | -10.1 (-0.44 %) |
| row_chord (semi-analytical upper bound (disc only)) | 2320.0 | 2280 | +40.0 (+1.75 %) |

Geometric loss: 14.4 % of the wafer area is not eligible die silicon (edge band + notch 1859 mm^2, streets 1287 mm^2, boundary cells 1387 mm^2).
Footprint-convention sensitivity: {'die': 2284, 'die_plus_half_street': 2280, 'die_plus_full_street': 2276}.
Best grid translation found: (1.948, 0.197) mm -> 2287 full dies (+7 vs configured).

## Yield definitions (every denominator explicit)

| metric | numerator / denominator |
|---|---|
| site_utilisation | eligible FULL-DIE sites / all die sites touching the wafer |
| defect_limited_yield | eligible dies without a fatal defect (before any repair) / eligible dies |
| functional_yield | eligible dies functional after IMPLEMENTED repair / eligible dies |
| true_good_yield | conforming dies that passed every probe step / eligible dies |
| observed_probe_yield | dies passing every probe step (incl. escapes) / tested dies |
| probe_escape_fraction | nonconforming dies that passed probe / dies that passed probe |
| false_reject_fraction | conforming dies rejected at probe / conforming dies |
| delivered_conforming_yield | conforming dies delivered after packaging + final test / eligible dies |
| shipped_escape_fraction | nonconforming dies among delivered dies / delivered dies |

## Results per wafer

CI = 95 % confidence interval of the *expected* value (lot-cluster t on lot means). PI = 90 % predictive interval for *one future wafer* / lot total. They are not interchangeable.

| metric | mean | sd | P5 | P50 | P95 | 95 % CI (mean) | naive iid CI | ICC(lot) | 90 % PI next wafer |
|---|---|---|---|---|---|---|---|---|---|
| eligible | 2,280.00 | 0.00 | 2,280.00 | 2,280.00 | 2,280.00 | [2,280.00, 2,280.00] | [2,280.00, 2,280.00] | 0.000 | [2,280.0, 2,280.0] |
| phys_defect_dies | 261.08 | 129.58 | 119.95 | 224.00 | 465.75 | [-318.11, 840.27] | [178.75, 343.41] | 0.08547 | [120.0, 465.7] |
| functional_fail_raw | 148.92 | 75.97 | 71.00 | 126.00 | 274.60 | [-161.33, 459.16] | [100.65, 197.19] | 0.04306 | [71.0, 274.6] |
| functional_fail | 148.92 | 75.97 | 71.00 | 126.00 | 274.60 | [-161.33, 459.16] | [100.65, 197.19] | 0.04306 | [71.0, 274.6] |
| param_fail_only | 1.00 | 2.56 | 0.00 | 0.00 | 4.60 | [-11.71, 13.71] | [-0.6255, 2.63] | 0.1429 | [0.0, 4.6] |
| outcome_TRUE_GOOD_PASS | 2,129.58 | 76.93 | 2,005.40 | 2,153.00 | 2,208.45 | [1,804.52, 2,454.65] | [2,080.70, 2,178.47] | 0.05835 | [2,005.4, 2,208.4] |
| outcome_DEFECTIVE_DETECTED | 132.33 | 72.58 | 58.75 | 109.50 | 246.40 | [-174.73, 439.40] | [86.22, 178.45] | 0.05897 | [58.8, 246.4] |
| outcome_DEFECTIVE_ESCAPED | 17.58 | 5.93 | 10.00 | 17.00 | 27.80 | [1.70, 33.47] | [13.82, 21.35] | 0.000 | [10.0, 27.8] |
| outcome_GOOD_REJECTED | 0.5 | 1.17 | 0.00 | 0.00 | 2.35 | [-1.62, 2.62] | [-0.242, 1.24] | 0.000 | [0.0, 2.3] |
| probe_pass | 2,147.17 | 72.79 | 2,033.60 | 2,170.50 | 2,220.80 | [1,837.98, 2,456.35] | [2,100.92, 2,193.42] | 0.06078 | [2,033.6, 2,220.8] |
| delivered | 2,124.58 | 74.11 | 2,006.10 | 2,141.00 | 2,205.05 | [1,782.57, 2,466.59] | [2,077.50, 2,171.67] | 0.1019 | [2,006.1, 2,205.1] |
| delivered_conforming | 2,111.42 | 75.70 | 1,988.55 | 2,128.50 | 2,194.35 | [1,767.29, 2,455.54] | [2,063.32, 2,159.51] | 0.09406 | [1,988.5, 2,194.3] |
| delivered_escape | 13.17 | 3.41 | 8.55 | 14.00 | 17.45 | [11.05, 15.28] | [11.00, 15.33] | 0.000 | [8.6, 17.4] |
| site_utilisation | 0.8543 | 1.16e-16 | 0.8543 | 0.8543 | 0.8543 | [0.8543, 0.8543] | [0.8543, 0.8543] | 1.000 | [0.8543, 0.8543] |
| defect_limited_yield | 0.9347 | 0.03332 | 0.8796 | 0.9447 | 0.9689 | [0.7986, 1.07] | [0.9135, 0.9559] | 0.04306 | [0.8796, 0.9689] |
| functional_yield | 0.9347 | 0.03332 | 0.8796 | 0.9447 | 0.9689 | [0.7986, 1.07] | [0.9135, 0.9559] | 0.04306 | [0.8796, 0.9689] |
| true_good_yield | 0.934 | 0.03374 | 0.8796 | 0.9443 | 0.9686 | [0.7915, 1.08] | [0.9126, 0.9555] | 0.05835 | [0.8796, 0.9686] |
| observed_probe_yield | 0.9417 | 0.03193 | 0.8919 | 0.952 | 0.974 | [0.8061, 1.08] | [0.9215, 0.962] | 0.06078 | [0.8919, 0.974] |
| probe_escape_fraction | 0.008258 | 0.003026 | 0.004547 | 0.008127 | 0.01371 | [7.975e-06, 0.01651] | [0.006336, 0.01018] | 0.000 | [0.004547, 0.01371] |
| false_reject_fraction | 0.000238 | 0.0005661 | 0.00 | 0.00 | 0.001127 | [-0.0008621, 0.001338] | [-0.0001217, 0.0005977] | 0.000 | [0.0, 0.001127] |
| delivered_conforming_yield | 0.9261 | 0.0332 | 0.8722 | 0.9336 | 0.9624 | [0.7751, 1.08] | [0.905, 0.9472] | 0.09406 | [0.8722, 0.9624] |
| shipped_escape_fraction | 0.006228 | 0.001731 | 0.003927 | 0.006374 | 0.008724 | [0.004383, 0.008074] | [0.005128, 0.007329] | 0.000 | [0.003927, 0.008724] |

P(true good dies per wafer >= 2037) = 0.833 (Wilson 95 % [0.552, 0.953]).

### Monte Carlo convergence

| quantity | n | MCSE | relative MCSE | status |
|---|---|---|---|---|
| outcome_TRUE_GOOD_PASS | 12 | 22.209 | 0.0104 | INSUFFICIENT |
| delivered_conforming | 12 | 21.853 | 0.0103 | INSUFFICIENT |
| functional_fail_raw | 12 | 21.931 | 0.1473 | INSUFFICIENT |

Simulated defect-limited yield 0.9347; Poisson-equivalent D0 0.5729 /cm^2; wafer-yield sd 0.0333 vs 0.0052 if dies were independent (Poisson).

## Yield-model comparison at the simulated mean density

| model | assumption | analytical | Monte Carlo (+/- SE) |
|---|---|---|---|
| poisson | defect density identical for every die (no clustering); fatal defects independent | 0.93469 | 0.93602 +/- 0.00055 |
| negative_binomial | per-unit defect density ~ Gamma(alpha, D0/alpha); alpha = clustering parameter | 0.93521 | 0.93603 +/- 0.00055 |
| seeds | per-die defect density exponentially distributed (NB with alpha = 1) | 0.93673 | 0.93678 +/- 0.00054 |
| murphy | per-die defect density triangular on [0, 2 D0] (Murphy 1964) | 0.93504 | 0.93503 +/- 0.00055 |
| murphy_uniform | per-die defect density uniform on [0, 2 D0] | 0.93540 | 0.93566 +/- 0.00055 |
| empirical | parameters fitted to measured wafer data (calibration.py); requires imported data | NOT AVAILABLE - no measured SilicaFlux wafer data to fit | |

## Yield loss by functional region

| region | area mm^2 | % of die | % dies lost | sole-cause dies (all wafers) | escapes (all wafers) | detected by | coverage source |
|---|---|---|---|---|---|---|---|
| main_sram | 3.933 | 33.4 | 3.512 | 626 | 16 | mbist | TestCore r2 fault_coverage.md: March C- 93.3 % of an enumerated SYNTHETIC fault population (8x16 model), not silicon coverage |
| routing_whitespace | 2.324 | 19.7 | 1.890 | 250 | 103 | functional_selftest, scan_atpg, continuity | NOT AVAILABLE |
| io_pads | 3.825 | 32.4 | 1.674 | 187 | 13 | continuity, iddq_leakage | NOT AVAILABLE - no pad ring / no electrical test program |
| tensor | 0.277 | 2.3 | 0.914 | 119 | 35 | tensor_arith_test, scan_atpg | NOT AVAILABLE - no fault-simulated tensor test exists |
| vector | 0.337 | 2.9 | 0.749 | 93 | 26 | vector_arith_test, scan_atpg | NOT AVAILABLE - no fault-simulated vector test exists |
| tile_spm | 0.600 | 5.1 | 0.735 | 83 | 1 | mbist | TestCore r2 fault_coverage.md (synthetic population) |
| top_glue | 0.105 | 0.9 | 0.406 | 24 | 11 | functional_selftest, scan_atpg | NOT AVAILABLE |
| cpu | 0.160 | 1.4 | 0.281 | 14 | 3 | functional_selftest, scan_atpg | NOT AVAILABLE - no scan inserted / no ATPG run on SilicaFlux-V (TestCore r2 ran scan+ATPG on TestCore only) |
| datafabric | 0.067 | 0.6 | 0.186 | 5 | 0 | functional_selftest, scan_atpg | NOT AVAILABLE |
| peripherals | 0.045 | 0.4 | 0.164 | 2 | 1 | peripheral_diag, scan_atpg | NOT AVAILABLE |
| dma | 0.041 | 0.4 | 0.157 | 7 | 2 | functional_selftest, scan_atpg | NOT AVAILABLE |
| sram_ctrl | 0.024 | 0.2 | 0.084 | 1 | 0 | mbist, scan_atpg | NOT AVAILABLE |
| boot_rom | 0.017 | 0.1 | 0.077 | 4 | 0 | rom_signature, functional_selftest | TestCore r1/r2 ROM MISR signature check exists in RTL; no fault simulation of the logic ROM |
| tile_ctrl | 0.017 | 0.1 | 0.069 | 1 | 0 | tensor_arith_test, vector_arith_test, scan_atpg | NOT AVAILABLE |
| testcore_jtag | 0.012 | 0.1 | 0.033 | 0 | 0 | jtag_diag | TestCore r1 tb_tap_fsm (14 924 RTL checks) - functional, not a fault-coverage figure |
| testcore_mbist | 0.007 | 0.1 | 0.026 | 1 | 1 | mbist, scan_atpg | NOT AVAILABLE |

## Flow (mean dies per wafer)

| step | dies / wafer |
|---|---|
| gross die sites touching the wafer | 2669.0 |
| - partial / edge-excluded / unprintable / test sites | -389.0 |
| = eligible FULL dies | 2280.0 |
| - functional failures (random defects, after implemented repair) | -148.9 |
| - conditional (hypothetical repair only) | -0.0 |
| - parametric-only failures | -1.0 |
| = conforming dies | 2130.1 |
| - good dies rejected at probe | -0.5 |
| - untested | 0.0 |
| = true good dies passing probe | 2129.6 |
|   (escapes also passing probe - quality risk, not good) | 17.6 |
| = delivered conforming after packaging + final test | 2111.4 |

## Input provenance

| input | value | source | reference |
|---|---|---|---|
| assembly_yield | 0.99 | HYPOTHETICAL | no assembly-house data; 99 % assumed for sensitivity |
| coverage.continuity.io_pads | 0.9 | HYPOTHETICAL | open/short continuity on pads; no pad library / test program |
| coverage.continuity.routing_whitespace | 0.05 | HYPOTHETICAL | supply-net shorts seen at continuity |
| coverage.final_functional.* | 0.3 | HYPOTHETICAL | residual detection of probe escapes at final test |
| coverage.final_functional.assembly | 0.95 | HYPOTHETICAL | package open/short + functional test after assembly |
| coverage.functional_selftest.cpu | 0.7 | HYPOTHETICAL | firmware POST / riscv-tests at probe; no fault simulation |
| coverage.functional_selftest.datafabric | 0.6 | HYPOTHETICAL | crossbar traffic test; no fault simulation |
| coverage.functional_selftest.dma | 0.5 | HYPOTHETICAL | firmware DMA copy test; no fault simulation |
| coverage.functional_selftest.routing_whitespace | 0.5 | HYPOTHETICAL | global-net faults usually visible functionally |
| coverage.functional_selftest.sram_ctrl | 0.3 | HYPOTHETICAL | partial |
| coverage.functional_selftest.tile_ctrl | 0.4 | HYPOTHETICAL | partial |
| coverage.functional_selftest.top_glue | 0.6 | HYPOTHETICAL | clock/reset/glue exercised by any functional test |
| coverage.iddq.* | 0.2 | HYPOTHETICAL | IDDQ bridging-defect sensitivity; no IDDQ limit or data |
| coverage.jtag_id.testcore_jtag | 0.9 | HYPOTHETICAL | TAP/IDCODE/BYPASS checks are RTL-verified (TestCore r1 tb_tap_fsm) but not fault-simulated |
| coverage.mbist.sram:bit | 0.933 | MEASURED_TOOL_OUTPUT | TestCore r2 fault_coverage.md March C- 'all classes' 2216/2376 on a SYNTHETIC 8x16 population (proxy; bit faults assumed to follow that clas |
| coverage.mbist.sram:column | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- data-line stuck 16/16 (proxy for bit-line faults) |
| coverage.mbist.sram:decoder | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- address-decoder 496/496 |
| coverage.mbist.sram:periphery | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- read-path inversion 128/128 + memory error flag 16/16 (proxy) |
| coverage.mbist.sram:retention | 0.0 | MEASURED_TOOL_OUTPUT | TestCore r1 docs/04_mbist.md: data-retention fault missed by March C- (needs RETENTION algorithm) |
| coverage.mbist.sram:row | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- address-decoder 496/496 (proxy for word-line faults) |
| coverage.mbist.sram_ctrl | 0.5 | HYPOTHETICAL | MBIST exercises bank-control logic partially; not fault-simulated |
| coverage.mbist.testcore_mbist | 0.5 | HYPOTHETICAL | MBIST controller self-exercise; not fault-simulated |
| coverage.peripheral_diag.peripherals | 0.5 | HYPOTHETICAL | loop-back UART/SPI/GPIO tests; no fault simulation |
| coverage.rom_signature.boot_rom | 0.95 | HYPOTHETICAL | ROM MISR signature exists in RTL (TestCore); logic-ROM fault coverage not simulated |
| coverage.tensor_arith_test.tensor | 0.6 | HYPOTHETICAL | golden-matrix MAC test; no fault simulation |
| coverage.tensor_arith_test.tile_ctrl | 0.3 | HYPOTHETICAL | partial |
| coverage.vector_arith_test.tile_ctrl | 0.3 | HYPOTHETICAL | partial |
| coverage.vector_arith_test.vector | 0.6 | HYPOTHETICAL | golden-vector SIMD test; no fault simulation |
| defect_model | 'all_generators' | HYPOTHETICAL | demonstration of generators A-I; intensities chosen for visibility, not realism |
| die_floorplan | (3494.88, 2279.34) | MEASURED_TOOL_OUTPUT | SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-floorplanlab.zip::silicaflux-floorplanlab/reports/runs/C_sram_near_compute/geometry.j |
| edge_exclusion_mm | 3.0 | HYPOTHETICAL | hypothetical 3 mm edge exclusion; no foundry value supplied |
| fatality_model | 'region_class' | HYPOTHETICAL | hypothetical kill probabilities; no SilicaFlux critical-area extraction or defect-to-failure data |
| orientation_feature | 'notch' | STANDARD_REFERENCE | SEMI M1 nominal notch; confirm against the wafer supplier specification |
| pad_ring_um | 300.0 | PLANNING_ESTIMATE | silicaflux-v docs/PROCESS_NODE_COMPARISON.md: '[E] ~11 mm^2 with a 0.3 mm wire-bond pad ring'. No I/O library is in the FloorplanLab ORFS re |
| parametric_model | ['fmax_mhz', 'leakage_ua'] | HYPOTHETICAL | hypothetical distributions; no SilicaFlux statistical process data; corners are context only |
| reticle_field_mm | (26.0, 33.0) | HYPOTHETICAL | typical scanner field limit; IHP / foundry reticle size not in the repository |
| scribe_um | (80.0, 80.0) | HYPOTHETICAL | hypothetical 80 um street incl. seal-ring allowance; no foundry scribe rule supplied |
| sram_fault_mix | {'bit': 0.6, 'row': 0.15, 'column': 0.15, 'decoder': 0.05, ' | HYPOTHETICAL | hypothetical SRAM fault-type mixture; no macro failure-mode data available |

## Figures

![convergence](figures/convergence.png)
![good_die_distribution](figures/good_die_distribution.png)
![loss_waterfall](figures/loss_waterfall.png)
![lot_distribution](figures/lot_distribution.png)
![parametric](figures/parametric.png)
![region_loss](figures/region_loss.png)
![wafer_bins](figures/wafer_bins.png)
![wafer_defects](figures/wafer_defects.png)
![wafer_geometry](figures/wafer_geometry.png)
![wafer_outcomes](figures/wafer_outcomes.png)
![yield_models](figures/yield_models.png)
