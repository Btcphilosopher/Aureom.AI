# SilicaFlux YieldLab run `sfv_baseline_200mm__seed1__2x5__02fed5a02c`

> **SIMULATED - HYPOTHETICAL SCENARIO (uses hypothetical / estimated inputs)**  
> Synthetic wafer maps and yields - NOT measured foundry data. Passing these checks does not establish manufacturability or commercial yield.

## Reproducibility

* scenario `sfv_baseline_200mm` sha256 `02fed5a02cd3b00fb345e43f8c4a475aad3dff24e53a854f1690440c11484b39`
* seed 1, 2 lots x 5 wafers = 10 wafers; 1 worker(s); 0.175 s
* RNG: numpy PCG64 via SeedSequence(seed, spawn_key=(lot, wafer, stream)); streams {'defects': 0, 'locate': 1, 'fatal': 2, 'sram': 3, 'test': 4, 'parametric': 5, 'packaging': 6}
* software: yieldlab 0.1.0, python 3.13.18, numpy 2.5.3, scipy 1.18.1, pandas 3.0.5, shapely 2.2.0, pydantic 2.13.5, matplotlib 3.11.2, plotly 7.1.0
* repair: NO REPAIR (implemented); fatality model: all_fatal; defect model: baseline_mixture (fatal)

## Die and wafer geometry

* die 4094.88 x 2879.34 um = 11.791 mm^2 (DERIVED: FloorplanLab C_sram_near_compute die 3494.88 x 2279.34 um (SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-floorplanlab.zip::silicaflux-floorplanlab/reports/runs/C_sram_near_compute/geometry.json (sha256 3ead0b0b9619)) + pad ring 300.0 um/side (PLANNING_ESTIMATE))
* pitch 4.1749 x 2.9593 mm, footprint convention `die_plus_half_street`
* wafer 200.0 mm, edge exclusion 3.0 mm (HYPOTHETICAL)

| site class | count |
|---|---|
| FULL DIE | 2280 |
| PARTIAL / EDGE-STRADDLING | 233 |
| EDGE-EXCLUDED | 156 |
| UNPRINTABLE | 0 |
| VALID TEST SITE | 0 |

**Eligible (FULL DIE) sites: 2280**; dies per reticle field [6, 11]

| method | value | geometry count | difference |
|---|---|---|---|
| area_ratio (approximation (upper bound)) | 2392.5 | 2280 | +112.5 (+4.93 %) |
| edge_corrected (approximation) | 2269.9 | 2280 | -10.1 (-0.44 %) |
| row_chord (semi-analytical upper bound (disc only)) | 2320.0 | 2280 | +40.0 (+1.75 %) |

Geometric loss: 14.4 % of the wafer area is not eligible die silicon (edge band + notch 1859 mm^2, streets 1287 mm^2, boundary cells 1387 mm^2).
Footprint-convention sensitivity: {'die': 2284, 'die_plus_half_street': 2280, 'die_plus_full_street': 2276}.
Best grid translation found: (1.948, 0.197) mm -> 2287 full dies (+7 vs configured).

## Yield definitions (every denominator explicit)

| metric | numerator / denominator |
|---|---|
| site_utilisation | eligible FULL-DIE sites / all die sites touching the wafer |
| defect_limited_yield | eligible dies without a fatal defect (before any repair) / eligible dies |
| functional_yield | eligible dies functional after IMPLEMENTED repair / eligible dies |
| true_good_yield | conforming dies that passed every probe step / eligible dies |
| observed_probe_yield | dies passing every probe step (incl. escapes) / tested dies |
| probe_escape_fraction | nonconforming dies that passed probe / dies that passed probe |
| false_reject_fraction | conforming dies rejected at probe / conforming dies |
| delivered_conforming_yield | conforming dies delivered after packaging + final test / eligible dies |
| shipped_escape_fraction | nonconforming dies among delivered dies / delivered dies |

## Results per wafer

CI = 95 % confidence interval of the *expected* value (lot-cluster t on lot means). PI = 90 % predictive interval for *one future wafer* / lot total. They are not interchangeable.

| metric | mean | sd | P5 | P50 | P95 | 95 % CI (mean) | naive iid CI | ICC(lot) | 90 % PI next wafer |
|---|---|---|---|---|---|---|---|---|---|
| eligible | 2,280.00 | 0.00 | 2,280.00 | 2,280.00 | 2,280.00 | [2,280.00, 2,280.00] | [2,280.00, 2,280.00] | 0.000 | [2,280.0, 2,280.0] |
| phys_defect_dies | 67.80 | 28.81 | 29.40 | 67.00 | 110.85 | [-82.13, 217.73] | [47.19, 88.41] | 0.1429 | [29.4, 110.8] |
| functional_fail_raw | 67.80 | 28.81 | 29.40 | 67.00 | 110.85 | [-82.13, 217.73] | [47.19, 88.41] | 0.1429 | [29.4, 110.8] |
| functional_fail | 67.80 | 28.81 | 29.40 | 67.00 | 110.85 | [-82.13, 217.73] | [47.19, 88.41] | 0.1429 | [29.4, 110.8] |
| param_fail_only | 8.60 | 9.09 | 0.45 | 4.00 | 23.05 | [-37.14, 54.34] | [2.09, 15.11] | 0.1207 | [0.45, 23.0] |
| outcome_TRUE_GOOD_PASS | 2,202.20 | 27.40 | 2,160.25 | 2,206.50 | 2,238.75 | [1,996.36, 2,408.04] | [2,182.60, 2,221.80] | 0.4495 | [2,160.2, 2,238.8] |
| outcome_DEFECTIVE_DETECTED | 65.80 | 23.31 | 34.35 | 63.50 | 99.75 | [-94.30, 225.90] | [49.13, 82.47] | 0.3628 | [34.4, 99.8] |
| outcome_DEFECTIVE_ESCAPED | 10.60 | 4.99 | 5.45 | 9.00 | 18.55 | [-24.98, 46.18] | [7.03, 14.17] | 0.3973 | [5.5, 18.5] |
| outcome_GOOD_REJECTED | 1.40 | 1.51 | 0.00 | 1.00 | 3.55 | [-8.76, 11.56] | [0.323, 2.48] | 0.347 | [0.0, 3.5] |
| probe_pass | 2,212.80 | 23.47 | 2,178.70 | 2,215.00 | 2,244.30 | [2,042.54, 2,383.06] | [2,196.01, 2,229.59] | 0.4145 | [2,178.7, 2,244.3] |
| delivered | 2,189.10 | 25.23 | 2,153.35 | 2,189.50 | 2,224.20 | [2,035.35, 2,342.85] | [2,171.05, 2,207.15] | 0.2589 | [2,153.3, 2,224.2] |
| delivered_conforming | 2,180.50 | 27.79 | 2,139.25 | 2,182.00 | 2,218.40 | [1,991.18, 2,369.82] | [2,160.62, 2,200.38] | 0.3551 | [2,139.2, 2,218.4] |
| delivered_escape | 8.60 | 4.12 | 4.00 | 8.00 | 14.55 | [-26.98, 44.18] | [5.66, 11.54] | 0.5992 | [4.0, 14.5] |
| site_utilisation | 0.8543 | 1.17e-16 | 0.8543 | 0.8543 | 0.8543 | [0.8543, 0.8543] | [0.8543, 0.8543] | 0.000 | [0.8543, 0.8543] |
| defect_limited_yield | 0.9703 | 0.01263 | 0.9514 | 0.9706 | 0.9871 | [0.9045, 1.04] | [0.9612, 0.9793] | 0.1429 | [0.9514, 0.9871] |
| functional_yield | 0.9703 | 0.01263 | 0.9514 | 0.9706 | 0.9871 | [0.9045, 1.04] | [0.9612, 0.9793] | 0.1429 | [0.9514, 0.9871] |
| true_good_yield | 0.9659 | 0.01202 | 0.9475 | 0.9678 | 0.9819 | [0.8756, 1.06] | [0.9573, 0.9745] | 0.4495 | [0.9475, 0.9819] |
| observed_probe_yield | 0.9705 | 0.0103 | 0.9556 | 0.9715 | 0.9843 | [0.8958, 1.05] | [0.9632, 0.9779] | 0.4145 | [0.9556, 0.9843] |
| probe_escape_fraction | 0.004807 | 0.002307 | 0.002429 | 0.00406 | 0.008512 | [-0.01173, 0.02135] | [0.003157, 0.006457] | 0.4034 | [0.002429, 0.008512] |
| false_reject_fraction | 0.0006361 | 0.0006824 | 0.00 | 0.0004568 | 0.001614 | [-0.004041, 0.005313] | [0.0001479, 0.001124] | 0.3608 | [0.0, 0.001614] |
| delivered_conforming_yield | 0.9564 | 0.01219 | 0.9383 | 0.957 | 0.973 | [0.8733, 1.04] | [0.9476, 0.9651] | 0.3551 | [0.9383, 0.973] |
| shipped_escape_fraction | 0.00394 | 0.001916 | 0.001819 | 0.003619 | 0.006713 | [-0.01268, 0.02056] | [0.002569, 0.005311] | 0.6025 | [0.001819, 0.006713] |

P(true good dies per wafer >= 2162) = 0.900 (Wilson 95 % [0.5958, 0.9821]).

### Monte Carlo convergence

| quantity | n | MCSE | relative MCSE | status |
|---|---|---|---|---|
| outcome_TRUE_GOOD_PASS | 10 | 8.664 | 0.0039 | INSUFFICIENT |
| delivered_conforming | 10 | 8.789 | 0.0040 | INSUFFICIENT |
| functional_fail_raw | 10 | 9.109 | 0.1344 | INSUFFICIENT |

Simulated defect-limited yield 0.9703; Poisson-equivalent D0 0.2560 /cm^2; wafer-yield sd 0.0126 vs 0.0036 if dies were independent (Poisson).

## Yield-model comparison at the simulated mean density

| model | assumption | analytical | Monte Carlo (+/- SE) |
|---|---|---|---|
| poisson | defect density identical for every die (no clustering); fatal defects independent | 0.97026 | 0.97076 +/- 0.00038 |
| negative_binomial | per-unit defect density ~ Gamma(alpha, D0/alpha); alpha = clustering parameter | 0.97034 | 0.97037 +/- 0.00038 |
| seeds | per-die defect density exponentially distributed (NB with alpha = 1) | 0.97070 | 0.97055 +/- 0.00038 |
| murphy | per-die defect density triangular on [0, 2 D0] (Murphy 1964) | 0.97034 | 0.97069 +/- 0.00038 |
| murphy_uniform | per-die defect density uniform on [0, 2 D0] | 0.97041 | 0.97027 +/- 0.00038 |
| empirical | parameters fitted to measured wafer data (calibration.py); requires imported data | NOT AVAILABLE - no measured SilicaFlux wafer data to fit | |

## Yield loss by functional region

| region | area mm^2 | % of die | % dies lost | sole-cause dies (all wafers) | escapes (all wafers) | detected by | coverage source |
|---|---|---|---|---|---|---|---|
| main_sram | 3.933 | 33.4 | 1.101 | 204 | 7 | mbist | TestCore r2 fault_coverage.md: March C- 93.3 % of an enumerated SYNTHETIC fault population (8x16 model), not silicon coverage |
| io_pads | 3.825 | 32.4 | 1.035 | 186 | 16 | continuity, iddq_leakage | NOT AVAILABLE - no pad ring / no electrical test program |
| routing_whitespace | 2.324 | 19.7 | 0.768 | 129 | 54 | functional_selftest, scan_atpg, continuity | NOT AVAILABLE |
| tile_spm | 0.600 | 5.1 | 0.219 | 32 | 1 | mbist | TestCore r2 fault_coverage.md (synthetic population) |
| vector | 0.337 | 2.9 | 0.167 | 21 | 5 | vector_arith_test, scan_atpg | NOT AVAILABLE - no fault-simulated vector test exists |
| tensor | 0.277 | 2.3 | 0.136 | 13 | 5 | tensor_arith_test, scan_atpg | NOT AVAILABLE - no fault-simulated tensor test exists |
| top_glue | 0.105 | 0.9 | 0.088 | 9 | 1 | functional_selftest, scan_atpg | NOT AVAILABLE |
| cpu | 0.160 | 1.4 | 0.066 | 6 | 1 | functional_selftest, scan_atpg | NOT AVAILABLE - no scan inserted / no ATPG run on SilicaFlux-V (TestCore r2 ran scan+ATPG on TestCore only) |
| dma | 0.041 | 0.4 | 0.044 | 5 | 2 | functional_selftest, scan_atpg | NOT AVAILABLE |
| datafabric | 0.067 | 0.6 | 0.031 | 2 | 1 | functional_selftest, scan_atpg | NOT AVAILABLE |
| peripherals | 0.045 | 0.4 | 0.022 | 1 | 0 | peripheral_diag, scan_atpg | NOT AVAILABLE |
| sram_ctrl | 0.024 | 0.2 | 0.018 | 2 | 0 | mbist, scan_atpg | NOT AVAILABLE |
| boot_rom | 0.017 | 0.1 | 0.018 | 1 | 0 | rom_signature, functional_selftest | TestCore r1/r2 ROM MISR signature check exists in RTL; no fault simulation of the logic ROM |
| tile_ctrl | 0.017 | 0.1 | 0.013 | 2 | 0 | tensor_arith_test, vector_arith_test, scan_atpg | NOT AVAILABLE |
| testcore_jtag | 0.012 | 0.1 | 0.013 | 1 | 0 | jtag_diag | TestCore r1 tb_tap_fsm (14 924 RTL checks) - functional, not a fault-coverage figure |
| testcore_mbist | 0.007 | 0.1 | 0.009 | 1 | 0 | mbist, scan_atpg | NOT AVAILABLE |

## Flow (mean dies per wafer)

| step | dies / wafer |
|---|---|
| gross die sites touching the wafer | 2669.0 |
| - partial / edge-excluded / unprintable / test sites | -389.0 |
| = eligible FULL dies | 2280.0 |
| - functional failures (random defects, after implemented repair) | -67.8 |
| - conditional (hypothetical repair only) | -0.0 |
| - parametric-only failures | -8.6 |
| = conforming dies | 2203.6 |
| - good dies rejected at probe | -1.4 |
| - untested | 0.0 |
| = true good dies passing probe | 2202.2 |
|   (escapes also passing probe - quality risk, not good) | 10.6 |
| = delivered conforming after packaging + final test | 2180.5 |

## Input provenance

| input | value | source | reference |
|---|---|---|---|
| assembly_yield | 0.99 | HYPOTHETICAL | no assembly-house data; 99 % assumed for sensitivity |
| coverage.continuity.io_pads | 0.9 | HYPOTHETICAL | open/short continuity on pads; no pad library / test program |
| coverage.continuity.routing_whitespace | 0.05 | HYPOTHETICAL | supply-net shorts seen at continuity |
| coverage.final_functional.* | 0.3 | HYPOTHETICAL | residual detection of probe escapes at final test |
| coverage.final_functional.assembly | 0.95 | HYPOTHETICAL | package open/short + functional test after assembly |
| coverage.functional_selftest.cpu | 0.7 | HYPOTHETICAL | firmware POST / riscv-tests at probe; no fault simulation |
| coverage.functional_selftest.datafabric | 0.6 | HYPOTHETICAL | crossbar traffic test; no fault simulation |
| coverage.functional_selftest.dma | 0.5 | HYPOTHETICAL | firmware DMA copy test; no fault simulation |
| coverage.functional_selftest.routing_whitespace | 0.5 | HYPOTHETICAL | global-net faults usually visible functionally |
| coverage.functional_selftest.sram_ctrl | 0.3 | HYPOTHETICAL | partial |
| coverage.functional_selftest.tile_ctrl | 0.4 | HYPOTHETICAL | partial |
| coverage.functional_selftest.top_glue | 0.6 | HYPOTHETICAL | clock/reset/glue exercised by any functional test |
| coverage.iddq.* | 0.2 | HYPOTHETICAL | IDDQ bridging-defect sensitivity; no IDDQ limit or data |
| coverage.jtag_id.testcore_jtag | 0.9 | HYPOTHETICAL | TAP/IDCODE/BYPASS checks are RTL-verified (TestCore r1 tb_tap_fsm) but not fault-simulated |
| coverage.mbist.sram:bit | 0.933 | MEASURED_TOOL_OUTPUT | TestCore r2 fault_coverage.md March C- 'all classes' 2216/2376 on a SYNTHETIC 8x16 population (proxy; bit faults assumed to follow that clas |
| coverage.mbist.sram:column | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- data-line stuck 16/16 (proxy for bit-line faults) |
| coverage.mbist.sram:decoder | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- address-decoder 496/496 |
| coverage.mbist.sram:periphery | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- read-path inversion 128/128 + memory error flag 16/16 (proxy) |
| coverage.mbist.sram:retention | 0.0 | MEASURED_TOOL_OUTPUT | TestCore r1 docs/04_mbist.md: data-retention fault missed by March C- (needs RETENTION algorithm) |
| coverage.mbist.sram:row | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- address-decoder 496/496 (proxy for word-line faults) |
| coverage.mbist.sram_ctrl | 0.5 | HYPOTHETICAL | MBIST exercises bank-control logic partially; not fault-simulated |
| coverage.mbist.testcore_mbist | 0.5 | HYPOTHETICAL | MBIST controller self-exercise; not fault-simulated |
| coverage.peripheral_diag.peripherals | 0.5 | HYPOTHETICAL | loop-back UART/SPI/GPIO tests; no fault simulation |
| coverage.rom_signature.boot_rom | 0.95 | HYPOTHETICAL | ROM MISR signature exists in RTL (TestCore); logic-ROM fault coverage not simulated |
| coverage.tensor_arith_test.tensor | 0.6 | HYPOTHETICAL | golden-matrix MAC test; no fault simulation |
| coverage.tensor_arith_test.tile_ctrl | 0.3 | HYPOTHETICAL | partial |
| coverage.vector_arith_test.tile_ctrl | 0.3 | HYPOTHETICAL | partial |
| coverage.vector_arith_test.vector | 0.6 | HYPOTHETICAL | golden-vector SIMD test; no fault simulation |
| defect_model | 'baseline_mixture' | HYPOTHETICAL | hypothetical mixture for SilicaFlux-V planning; no measured defect density, clustering or excursion data |
| die_floorplan | (3494.88, 2279.34) | MEASURED_TOOL_OUTPUT | SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-floorplanlab.zip::silicaflux-floorplanlab/reports/runs/C_sram_near_compute/geometry.j |
| edge_exclusion_mm | 3.0 | HYPOTHETICAL | hypothetical 3 mm edge exclusion; no foundry value supplied |
| fatality_model | 'all_fatal' | HYPOTHETICAL | simplified baseline: every defect hitting a die is fatal (density = fatal D0) |
| orientation_feature | 'notch' | STANDARD_REFERENCE | SEMI M1 nominal notch; confirm against the wafer supplier specification |
| pad_ring_um | 300.0 | PLANNING_ESTIMATE | silicaflux-v docs/PROCESS_NODE_COMPARISON.md: '[E] ~11 mm^2 with a 0.3 mm wire-bond pad ring'. No I/O library is in the FloorplanLab ORFS re |
| parametric_model | ['fmax_mhz', 'leakage_ua'] | HYPOTHETICAL | hypothetical distributions; no SilicaFlux statistical process data; corners are context only |
| reticle_field_mm | (26.0, 33.0) | HYPOTHETICAL | typical scanner field limit; IHP / foundry reticle size not in the repository |
| scribe_um | (80.0, 80.0) | HYPOTHETICAL | hypothetical 80 um street incl. seal-ring allowance; no foundry scribe rule supplied |
| sram_fault_mix | {'bit': 0.6, 'row': 0.15, 'column': 0.15, 'decoder': 0.05, ' | HYPOTHETICAL | hypothetical SRAM fault-type mixture; no macro failure-mode data available |

## Figures

![convergence](figures/convergence.png)
![good_die_distribution](figures/good_die_distribution.png)
![loss_waterfall](figures/loss_waterfall.png)
![lot_distribution](figures/lot_distribution.png)
![parametric](figures/parametric.png)
![region_loss](figures/region_loss.png)
![wafer_bins](figures/wafer_bins.png)
![wafer_defects](figures/wafer_defects.png)
![wafer_geometry](figures/wafer_geometry.png)
![wafer_outcomes](figures/wafer_outcomes.png)
![yield_models](figures/yield_models.png)
