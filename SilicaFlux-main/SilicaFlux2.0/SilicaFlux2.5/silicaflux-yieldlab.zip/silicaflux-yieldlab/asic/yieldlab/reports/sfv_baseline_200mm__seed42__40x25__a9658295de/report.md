# SilicaFlux YieldLab run `sfv_baseline_200mm__seed42__40x25__a9658295de`

> **SIMULATED - HYPOTHETICAL SCENARIO (uses hypothetical / estimated inputs)**  
> Synthetic wafer maps and yields - NOT measured foundry data. Passing these checks does not establish manufacturability or commercial yield.

## Reproducibility

* scenario `sfv_baseline_200mm` sha256 `a9658295de92d97d2f6fa40e2ae1901d2e4ba059fdd629accf7d6a1980d36318`
* seed 42, 40 lots x 25 wafers = 1000 wafers; 1 worker(s); 6.504 s
* RNG: numpy PCG64 via SeedSequence(seed, spawn_key=(lot, wafer, stream)); streams {'defects': 0, 'locate': 1, 'fatal': 2, 'sram': 3, 'test': 4, 'parametric': 5, 'packaging': 6}
* software: yieldlab 0.1.0, python 3.13.18, numpy 2.5.3, scipy 1.18.1, pandas 3.0.5, shapely 2.2.0, pydantic 2.13.5, matplotlib 3.11.2, plotly 7.1.0
* repair: NO REPAIR (implemented); fatality model: all_fatal; defect model: baseline_mixture (fatal)

## Die and wafer geometry

* die 4094.88 x 2879.34 um = 11.791 mm^2 (DERIVED: FloorplanLab C_sram_near_compute die 3494.88 x 2279.34 um (SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-floorplanlab.zip::silicaflux-floorplanlab/reports/runs/C_sram_near_compute/geometry.json (sha256 3ead0b0b9619)) + pad ring 300.0 um/side (PLANNING_ESTIMATE))
* pitch 4.1749 x 2.9593 mm, footprint convention `die_plus_half_street`
* wafer 200.0 mm, edge exclusion 3.0 mm (HYPOTHETICAL)

| site class | count |
|---|---|
| FULL DIE | 2280 |
| PARTIAL / EDGE-STRADDLING | 233 |
| EDGE-EXCLUDED | 156 |
| UNPRINTABLE | 0 |
| VALID TEST SITE | 0 |

**Eligible (FULL DIE) sites: 2280**; dies per reticle field [6, 11]

| method | value | geometry count | difference |
|---|---|---|---|
| area_ratio (approximation (upper bound)) | 2392.5 | 2280 | +112.5 (+4.93 %) |
| edge_corrected (approximation) | 2269.9 | 2280 | -10.1 (-0.44 %) |
| row_chord (semi-analytical upper bound (disc only)) | 2320.0 | 2280 | +40.0 (+1.75 %) |

Geometric loss: 14.4 % of the wafer area is not eligible die silicon (edge band + notch 1859 mm^2, streets 1287 mm^2, boundary cells 1387 mm^2).
Footprint-convention sensitivity: {'die': 2284, 'die_plus_half_street': 2280, 'die_plus_full_street': 2276}.
Best grid translation found: (1.948, 0.197) mm -> 2287 full dies (+7 vs configured).

## Yield definitions (every denominator explicit)

| metric | numerator / denominator |
|---|---|
| site_utilisation | eligible FULL-DIE sites / all die sites touching the wafer |
| defect_limited_yield | eligible dies without a fatal defect (before any repair) / eligible dies |
| functional_yield | eligible dies functional after IMPLEMENTED repair / eligible dies |
| true_good_yield | conforming dies that passed every probe step / eligible dies |
| observed_probe_yield | dies passing every probe step (incl. escapes) / tested dies |
| probe_escape_fraction | nonconforming dies that passed probe / dies that passed probe |
| false_reject_fraction | conforming dies rejected at probe / conforming dies |
| delivered_conforming_yield | conforming dies delivered after packaging + final test / eligible dies |
| shipped_escape_fraction | nonconforming dies among delivered dies / delivered dies |

## Results per wafer

CI = 95 % confidence interval of the *expected* value (lot-cluster t on lot means). PI = 90 % predictive interval for *one future wafer* / lot total. They are not interchangeable.

| metric | mean | sd | P5 | P50 | P95 | 95 % CI (mean) | naive iid CI | ICC(lot) | 90 % PI next wafer |
|---|---|---|---|---|---|---|---|---|---|
| eligible | 2,280.00 | 0.00 | 2,280.00 | 2,280.00 | 2,280.00 | [2,280.00, 2,280.00] | [2,280.00, 2,280.00] | 0.000 | [2,280.0, 2,280.0] |
| phys_defect_dies | 72.89 | 49.65 | 22.00 | 63.00 | 153.05 | [64.38, 81.41] | [69.81, 75.97] | 0.2562 | [22.0, 153.0] |
| functional_fail_raw | 72.89 | 49.65 | 22.00 | 63.00 | 153.05 | [64.38, 81.41] | [69.81, 75.97] | 0.2562 | [22.0, 153.0] |
| functional_fail | 72.89 | 49.65 | 22.00 | 63.00 | 153.05 | [64.38, 81.41] | [69.81, 75.97] | 0.2562 | [22.0, 153.0] |
| param_fail_only | 17.91 | 56.21 | 0.00 | 2.00 | 80.00 | [5.75, 30.08] | [14.42, 21.40] | 0.4303 | [0.0, 80.0] |
| outcome_TRUE_GOOD_PASS | 2,185.97 | 82.97 | 2,054.60 | 2,207.00 | 2,255.00 | [2,169.20, 2,202.74] | [2,180.82, 2,191.12] | 0.3707 | [2,054.6, 2,255.0] |
| outcome_DEFECTIVE_DETECTED | 79.28 | 69.46 | 21.00 | 62.00 | 184.15 | [65.41, 93.14] | [74.96, 83.59] | 0.3605 | [21.0, 184.1] |
| outcome_DEFECTIVE_ESCAPED | 11.53 | 9.06 | 3.00 | 9.00 | 27.05 | [9.89, 13.17] | [10.97, 12.09] | 0.2884 | [3.0, 27.0] |
| outcome_GOOD_REJECTED | 3.22 | 7.23 | 0.00 | 1.00 | 16.00 | [1.65, 4.80] | [2.78, 3.67] | 0.4353 | [0.0, 16.0] |
| probe_pass | 2,197.50 | 74.88 | 2,080.80 | 2,216.50 | 2,258.05 | [2,182.32, 2,212.68] | [2,192.85, 2,202.15] | 0.3733 | [2,080.8, 2,258.1] |
| delivered | 2,173.83 | 75.43 | 2,051.00 | 2,193.00 | 2,236.00 | [2,158.59, 2,189.08] | [2,169.15, 2,178.51] | 0.3706 | [2,051.0, 2,236.0] |
| delivered_conforming | 2,164.03 | 82.34 | 2,027.75 | 2,185.00 | 2,232.00 | [2,147.38, 2,180.68] | [2,158.92, 2,169.14] | 0.3712 | [2,027.8, 2,232.0] |
| delivered_escape | 9.80 | 7.65 | 2.00 | 8.00 | 24.00 | [8.38, 11.23] | [9.33, 10.28] | 0.3078 | [2.0, 24.0] |
| site_utilisation | 0.8543 | 3.332e-16 | 0.8543 | 0.8543 | 0.8543 | [0.8543, 0.8543] | [0.8543, 0.8543] | 1.000 | [0.8543, 0.8543] |
| defect_limited_yield | 0.968 | 0.02177 | 0.9329 | 0.9724 | 0.9904 | [0.9643, 0.9718] | [0.9667, 0.9694] | 0.2562 | [0.9329, 0.9904] |
| functional_yield | 0.968 | 0.02177 | 0.9329 | 0.9724 | 0.9904 | [0.9643, 0.9718] | [0.9667, 0.9694] | 0.2562 | [0.9329, 0.9904] |
| true_good_yield | 0.9588 | 0.03639 | 0.9011 | 0.968 | 0.989 | [0.9514, 0.9661] | [0.9565, 0.961] | 0.3707 | [0.9011, 0.989] |
| observed_probe_yield | 0.9638 | 0.03284 | 0.9126 | 0.9721 | 0.9904 | [0.9572, 0.9705] | [0.9618, 0.9659] | 0.3733 | [0.9126, 0.9904] |
| probe_escape_fraction | 0.005397 | 0.00482 | 0.001327 | 0.00407 | 0.01332 | [0.004529, 0.006265] | [0.005098, 0.005696] | 0.2863 | [0.001327, 0.01332] |
| false_reject_fraction | 0.001574 | 0.00384 | 0.00 | 0.0004458 | 0.007452 | [0.0007444, 0.002404] | [0.001336, 0.001812] | 0.429 | [0.0, 0.007452] |
| delivered_conforming_yield | 0.9491 | 0.03611 | 0.8894 | 0.9583 | 0.9789 | [0.9418, 0.9564] | [0.9469, 0.9514] | 0.3712 | [0.8894, 0.9789] |
| shipped_escape_fraction | 0.004642 | 0.00417 | 0.0009001 | 0.003655 | 0.01146 | [0.003864, 0.005421] | [0.004384, 0.004901] | 0.3108 | [0.0009001, 0.01146] |

P(true good dies per wafer >= 2119) = 0.900 (Wilson 95 % [0.8798, 0.9171]).

### Monte Carlo convergence

| quantity | n | MCSE | relative MCSE | status |
|---|---|---|---|---|
| outcome_TRUE_GOOD_PASS | 1000 | 8.809 | 0.0040 | CONVERGED |
| delivered_conforming | 1000 | 8.729 | 0.0040 | CONVERGED |
| functional_fail_raw | 1000 | 3.630 | 0.0498 | INSUFFICIENT |

Simulated defect-limited yield 0.9680; Poisson-equivalent D0 0.2756 /cm^2; wafer-yield sd 0.0218 vs 0.0037 if dies were independent (Poisson).

## Yield-model comparison at the simulated mean density

| model | assumption | analytical | Monte Carlo (+/- SE) |
|---|---|---|---|
| poisson | defect density identical for every die (no clustering); fatal defects independent | 0.96803 | 0.96796 +/- 0.00039 |
| negative_binomial | per-unit defect density ~ Gamma(alpha, D0/alpha); alpha = clustering parameter | 0.96811 | 0.96813 +/- 0.00039 |
| seeds | per-die defect density exponentially distributed (NB with alpha = 1) | 0.96853 | 0.96888 +/- 0.00039 |
| murphy | per-die defect density triangular on [0, 2 D0] (Murphy 1964) | 0.96811 | 0.96776 +/- 0.00039 |
| murphy_uniform | per-die defect density uniform on [0, 2 D0] | 0.96820 | 0.96833 +/- 0.00039 |
| empirical | parameters fitted to measured wafer data (calibration.py); requires imported data | NOT AVAILABLE - no measured SilicaFlux wafer data to fit | |

## Yield loss by functional region

| region | area mm^2 | % of die | % dies lost | sole-cause dies (all wafers) | escapes (all wafers) | detected by | coverage source |
|---|---|---|---|---|---|---|---|
| main_sram | 3.933 | 33.4 | 1.145 | 22915 | 727 | mbist | TestCore r2 fault_coverage.md: March C- 93.3 % of an enumerated SYNTHETIC fault population (8x16 model), not silicon coverage |
| io_pads | 3.825 | 32.4 | 1.129 | 22431 | 1664 | continuity, iddq_leakage | NOT AVAILABLE - no pad ring / no electrical test program |
| routing_whitespace | 2.324 | 19.7 | 0.706 | 13243 | 4906 | functional_selftest, scan_atpg, continuity | NOT AVAILABLE |
| tile_spm | 0.600 | 5.1 | 0.190 | 3406 | 115 | mbist | TestCore r2 fault_coverage.md (synthetic population) |
| vector | 0.337 | 2.9 | 0.129 | 1916 | 596 | vector_arith_test, scan_atpg | NOT AVAILABLE - no fault-simulated vector test exists |
| tensor | 0.277 | 2.3 | 0.117 | 1618 | 532 | tensor_arith_test, scan_atpg | NOT AVAILABLE - no fault-simulated tensor test exists |
| cpu | 0.160 | 1.4 | 0.064 | 966 | 218 | functional_selftest, scan_atpg | NOT AVAILABLE - no scan inserted / no ATPG run on SilicaFlux-V (TestCore r2 ran scan+ATPG on TestCore only) |
| top_glue | 0.105 | 0.9 | 0.057 | 633 | 200 | functional_selftest, scan_atpg | NOT AVAILABLE |
| datafabric | 0.067 | 0.6 | 0.032 | 375 | 131 | functional_selftest, scan_atpg | NOT AVAILABLE |
| peripherals | 0.045 | 0.4 | 0.023 | 249 | 108 | peripheral_diag, scan_atpg | NOT AVAILABLE |
| dma | 0.041 | 0.4 | 0.022 | 270 | 105 | functional_selftest, scan_atpg | NOT AVAILABLE |
| sram_ctrl | 0.024 | 0.2 | 0.015 | 149 | 36 | mbist, scan_atpg | NOT AVAILABLE |
| tile_ctrl | 0.017 | 0.1 | 0.012 | 116 | 20 | tensor_arith_test, vector_arith_test, scan_atpg | NOT AVAILABLE |
| boot_rom | 0.017 | 0.1 | 0.010 | 107 | 7 | rom_signature, functional_selftest | TestCore r1/r2 ROM MISR signature check exists in RTL; no fault simulation of the logic ROM |
| testcore_jtag | 0.012 | 0.1 | 0.007 | 69 | 7 | jtag_diag | TestCore r1 tb_tap_fsm (14 924 RTL checks) - functional, not a fault-coverage figure |
| testcore_mbist | 0.007 | 0.1 | 0.004 | 35 | 16 | mbist, scan_atpg | NOT AVAILABLE |

## Flow (mean dies per wafer)

| step | dies / wafer |
|---|---|
| gross die sites touching the wafer | 2669.0 |
| - partial / edge-excluded / unprintable / test sites | -389.0 |
| = eligible FULL dies | 2280.0 |
| - functional failures (random defects, after implemented repair) | -72.9 |
| - conditional (hypothetical repair only) | -0.0 |
| - parametric-only failures | -17.9 |
| = conforming dies | 2189.2 |
| - good dies rejected at probe | -3.2 |
| - untested | 0.0 |
| = true good dies passing probe | 2186.0 |
|   (escapes also passing probe - quality risk, not good) | 11.5 |
| = delivered conforming after packaging + final test | 2164.0 |

## Economics

**SIMULATED - HYPOTHETICAL SCENARIO (uses hypothetical / estimated inputs)**

| stage | in | out | cost |
|---|---|---|---|
| FAB | 1000 | 1000 | 2,500,000 EUR |
| PROBE | 2280000 | 2197501 | 131,200 EUR |
| DICING | 1000 | 1000 | 30,000 EUR |
| PACKAGING | 2197501 | 2197501 | 1,318,501 EUR |
| FINAL_TEST | 2197501 | 2173832 | 549,375 EUR |
| SHIP | 2173832 | 2173832 | 43,477 EUR |

* cost per delivered CONFORMING die: **2.206 EUR** (NRE spread over 500000 delivered conforming units)
* escapes delivered: 9803 (4510 DPPM) - excluded from the denominator
* recurring cost per conforming die, per wafer: mean 2.115, 90 % PI [2.071, 2.206]
* MPW: 53,400 EUR for 40.0 packaged prototypes, 38.4 expected good -> 1,392 per good prototype (SIMULATED - HYPOTHETICAL SCENARIO (uses hypothetical / estimated inputs))
* first silicon (ENGINEERING PROTOTYPE cost per usable chip (program cost / usable prototypes) - NOT comparable to volume cost per known-good die): 0 re-spin(s): 528,400 -> 13,778 per usable; 1 re-spin(s): 696,800 -> 18,169 per usable; 2 re-spin(s): 865,200 -> 22,560 per usable

## Input provenance

| input | value | source | reference |
|---|---|---|---|
| assembly_yield | 0.99 | HYPOTHETICAL | no assembly-house data; 99 % assumed for sensitivity |
| coverage.continuity.io_pads | 0.9 | HYPOTHETICAL | open/short continuity on pads; no pad library / test program |
| coverage.continuity.routing_whitespace | 0.05 | HYPOTHETICAL | supply-net shorts seen at continuity |
| coverage.final_functional.* | 0.3 | HYPOTHETICAL | residual detection of probe escapes at final test |
| coverage.final_functional.assembly | 0.95 | HYPOTHETICAL | package open/short + functional test after assembly |
| coverage.functional_selftest.cpu | 0.7 | HYPOTHETICAL | firmware POST / riscv-tests at probe; no fault simulation |
| coverage.functional_selftest.datafabric | 0.6 | HYPOTHETICAL | crossbar traffic test; no fault simulation |
| coverage.functional_selftest.dma | 0.5 | HYPOTHETICAL | firmware DMA copy test; no fault simulation |
| coverage.functional_selftest.routing_whitespace | 0.5 | HYPOTHETICAL | global-net faults usually visible functionally |
| coverage.functional_selftest.sram_ctrl | 0.3 | HYPOTHETICAL | partial |
| coverage.functional_selftest.tile_ctrl | 0.4 | HYPOTHETICAL | partial |
| coverage.functional_selftest.top_glue | 0.6 | HYPOTHETICAL | clock/reset/glue exercised by any functional test |
| coverage.iddq.* | 0.2 | HYPOTHETICAL | IDDQ bridging-defect sensitivity; no IDDQ limit or data |
| coverage.jtag_id.testcore_jtag | 0.9 | HYPOTHETICAL | TAP/IDCODE/BYPASS checks are RTL-verified (TestCore r1 tb_tap_fsm) but not fault-simulated |
| coverage.mbist.sram:bit | 0.933 | MEASURED_TOOL_OUTPUT | TestCore r2 fault_coverage.md March C- 'all classes' 2216/2376 on a SYNTHETIC 8x16 population (proxy; bit faults assumed to follow that clas |
| coverage.mbist.sram:column | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- data-line stuck 16/16 (proxy for bit-line faults) |
| coverage.mbist.sram:decoder | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- address-decoder 496/496 |
| coverage.mbist.sram:periphery | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- read-path inversion 128/128 + memory error flag 16/16 (proxy) |
| coverage.mbist.sram:retention | 0.0 | MEASURED_TOOL_OUTPUT | TestCore r1 docs/04_mbist.md: data-retention fault missed by March C- (needs RETENTION algorithm) |
| coverage.mbist.sram:row | 1.0 | MEASURED_TOOL_OUTPUT | TestCore r2 March C- address-decoder 496/496 (proxy for word-line faults) |
| coverage.mbist.sram_ctrl | 0.5 | HYPOTHETICAL | MBIST exercises bank-control logic partially; not fault-simulated |
| coverage.mbist.testcore_mbist | 0.5 | HYPOTHETICAL | MBIST controller self-exercise; not fault-simulated |
| coverage.peripheral_diag.peripherals | 0.5 | HYPOTHETICAL | loop-back UART/SPI/GPIO tests; no fault simulation |
| coverage.rom_signature.boot_rom | 0.95 | HYPOTHETICAL | ROM MISR signature exists in RTL (TestCore); logic-ROM fault coverage not simulated |
| coverage.tensor_arith_test.tensor | 0.6 | HYPOTHETICAL | golden-matrix MAC test; no fault simulation |
| coverage.tensor_arith_test.tile_ctrl | 0.3 | HYPOTHETICAL | partial |
| coverage.vector_arith_test.tile_ctrl | 0.3 | HYPOTHETICAL | partial |
| coverage.vector_arith_test.vector | 0.6 | HYPOTHETICAL | golden-vector SIMD test; no fault simulation |
| defect_model | 'baseline_mixture' | HYPOTHETICAL | hypothetical mixture for SilicaFlux-V planning; no measured defect density, clustering or excursion data |
| die_floorplan | (3494.88, 2279.34) | MEASURED_TOOL_OUTPUT | SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-floorplanlab.zip::silicaflux-floorplanlab/reports/runs/C_sram_near_compute/geometry.j |
| edge_exclusion_mm | 3.0 | HYPOTHETICAL | hypothetical 3 mm edge exclusion; no foundry value supplied |
| fatality_model | 'all_fatal' | HYPOTHETICAL | simplified baseline: every defect hitting a die is fatal (density = fatal D0) |
| orientation_feature | 'notch' | STANDARD_REFERENCE | SEMI M1 nominal notch; confirm against the wafer supplier specification |
| pad_ring_um | 300.0 | PLANNING_ESTIMATE | silicaflux-v docs/PROCESS_NODE_COMPARISON.md: '[E] ~11 mm^2 with a 0.3 mm wire-bond pad ring'. No I/O library is in the FloorplanLab ORFS re |
| parametric_model | ['fmax_mhz', 'leakage_ua'] | HYPOTHETICAL | hypothetical distributions; no SilicaFlux statistical process data; corners are context only |
| reticle_field_mm | (26.0, 33.0) | HYPOTHETICAL | typical scanner field limit; IHP / foundry reticle size not in the repository |
| scribe_um | (80.0, 80.0) | HYPOTHETICAL | hypothetical 80 um street incl. seal-ring allowance; no foundry scribe rule supplied |
| sram_fault_mix | {'bit': 0.6, 'row': 0.15, 'column': 0.15, 'decoder': 0.05, ' | HYPOTHETICAL | hypothetical SRAM fault-type mixture; no macro failure-mode data available |

## Figures

![convergence](figures/convergence.png)
![good_die_distribution](figures/good_die_distribution.png)
![loss_waterfall](figures/loss_waterfall.png)
![lot_distribution](figures/lot_distribution.png)
![parametric](figures/parametric.png)
![region_loss](figures/region_loss.png)
![wafer_bins](figures/wafer_bins.png)
![wafer_defects](figures/wafer_defects.png)
![wafer_geometry](figures/wafer_geometry.png)
![wafer_outcomes](figures/wafer_outcomes.png)
![yield_models](figures/yield_models.png)
