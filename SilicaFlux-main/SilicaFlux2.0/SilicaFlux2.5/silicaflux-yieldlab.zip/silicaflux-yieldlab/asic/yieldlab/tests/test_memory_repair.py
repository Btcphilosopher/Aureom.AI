"""SRAM repair: TEST P (repair never raises yield without a modelled capability), BIRA, ECC."""
import numpy as np
import pytest

from yieldlab.memory_repair import (Evidence, RepairCapability, ecc_area_overhead, macro_repairable)
from yieldlab.monte_carlo import build_runtime, run_simulation

ORG = {"words": 2048, "bits": 64, "column_mux": 2, "rows": 1024, "cols": 128}


def test_none_scheme_never_repairs():
    cap = RepairCapability(scheme="none")
    assert not macro_repairable([("bit", 1, 1)], ORG, cap)
    assert macro_repairable([], ORG, cap)


def test_rows_cols_bira_exact_cases():
    cap = RepairCapability(scheme="rows_cols", spare_rows=1, spare_cols=1)
    assert macro_repairable([("bit", 5, 5), ("bit", 5, 9)], ORG, cap)          # one spare row
    assert macro_repairable([("bit", 5, 5), ("bit", 9, 5)], ORG, cap)          # one spare column
    assert macro_repairable([("bit", 5, 5), ("bit", 9, 7)], ORG, cap)          # row + column
    assert not macro_repairable([("bit", 1, 1), ("bit", 2, 2), ("bit", 3, 3)], ORG, cap)
    assert not macro_repairable([("decoder", 0, 0)], ORG, cap)
    assert not macro_repairable([("row", 3, 0), ("row", 4, 0)], ORG, cap)
    rows_only = RepairCapability(scheme="rows", spare_rows=2)
    assert not macro_repairable([("column", 0, 3)], ORG, rows_only)
    assert macro_repairable([("row", 3, 0), ("bit", 9, 9)], ORG, rows_only)


def test_ecc_rules():
    cap = RepairCapability(scheme="ecc")
    assert macro_repairable([("bit", 1, 1), ("bit", 2, 1)], ORG, cap)          # different words
    assert not macro_repairable([("bit", 1, 1), ("bit", 1, 3)], ORG, cap)      # same row, same mux select -> same word
    assert macro_repairable([("bit", 1, 1), ("bit", 1, 2)], ORG, cap)          # same row, other word (mux 2)
    assert macro_repairable([("column", 0, 4)], ORG, cap)                       # one bit per word
    assert not macro_repairable([("column", 0, 4), ("bit", 7, 6)], ORG, cap)   # col 4 and col 6 -> same word sel
    assert not macro_repairable([("row", 1, 0)], ORG, cap)                      # whole word bad
    assert not macro_repairable([("periphery", 0, 0)], ORG, cap)                # catastrophic: never correctable
    assert ecc_area_overhead(64) == pytest.approx(8 / 64)


def test_capability_gating():
    hyp = RepairCapability(scheme="rows", spare_rows=2)
    assert not hyp.implemented and "hardware" in hyp.missing()
    impl = RepairCapability(scheme="rows", spare_rows=2, **{k: Evidence(status="implemented", reference="x") for k in
                                                           ("hardware", "configuration_storage", "bira_or_firmware",
                                                            "validation")})
    assert impl.implemented
    with pytest.raises(ValueError):
        RepairCapability(scheme="rows", spare_rows=0)


def test_P_repair_never_increases_true_yield_without_capability(baseline_scenario):
    """TEST P: a hypothetical repair scheme leaves TRUE good dies unchanged (CRN-paired); only CONDITIONAL rises."""
    base = baseline_scenario.model_copy(deep=True)
    base.monte_carlo.keep_maps = 0
    hyp = base.model_copy(deep=True)
    hyp.sram.repair = RepairCapability(scheme="rows_cols", spare_rows=4, spare_cols=4)
    a = run_simulation(base, lots=2, wafers_per_lot=5).wafers
    b = run_simulation(hyp, lots=2, wafers_per_lot=5).wafers
    assert (b["outcome_TRUE_GOOD_PASS"] <= a["outcome_TRUE_GOOD_PASS"]).all()
    assert (b["functional_fail_raw"] == a["functional_fail_raw"]).all()        # identical defects (CRN)
    assert b["repaired_conditional"].sum() > 0
    assert (b["repaired_implemented"] == 0).all()
    assert (a["outcome_CONDITIONAL_GOOD_PASS"] == 0).all()
    # with an implemented capability the repaired dies become true good dies
    impl = hyp.model_copy(deep=True)
    for k in ("hardware", "configuration_storage", "bira_or_firmware", "validation"):
        setattr(impl.sram.repair, k, Evidence(status="implemented", reference="what-if"))
    c = run_simulation(impl, lots=2, wafers_per_lot=5).wafers
    assert c["outcome_TRUE_GOOD_PASS"].sum() >= a["outcome_TRUE_GOOD_PASS"].sum()
    assert c["repaired_implemented"].sum() == b["repaired_conditional"].sum()
