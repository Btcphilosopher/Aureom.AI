"""Measured-data import: retest policy, duplicates, transforms, labels."""
import json

import numpy as np
import pandas as pd
import pytest

from yieldlab import imports as im
from yieldlab.testcore_adapter import atpg_summary, load_session_logs, march_coverage


def write(tmp_path, rows):
    p = tmp_path / "map.csv"
    pd.DataFrame(rows).to_csv(p, index=False)
    return p


def rows_basic():
    return [{"lot": "L1", "wafer": 1, "die_x": x, "die_y": y, "hard_bin": 1 if (x + y) % 3 else 3}
            for x in range(-2, 3) for y in range(-2, 3)]


def test_verified_import(tmp_path):
    r = im.load_wafer_map_csv(write(tmp_path, rows_basic()), good_bins=[1], valid_bins=[1, 2, 3, 9])
    assert r.label == im.VERIFIED and r.verified
    c = im.wafer_counts(r)
    assert c["total"].iloc[0] == 25


def test_retest_policy_required(tmp_path):
    # die (0, 1) is bin 1 on the first attempt; the retest reports bin 3
    rows = rows_basic() + [{"lot": "L1", "wafer": 1, "die_x": 0, "die_y": 1, "hard_bin": 3, "attempt": 2}]
    for r in rows:
        r.setdefault("attempt", 1)
    p = write(tmp_path, rows)
    with pytest.raises(ValueError, match="retest_policy"):
        im.load_wafer_map_csv(p, good_bins=[1])
    with pytest.raises(ValueError, match="allow_best"):
        im.load_wafer_map_csv(p, good_bins=[1], retest_policy="BEST")
    first = im.load_wafer_map_csv(p, good_bins=[1], retest_policy="FIRST")
    last = im.load_wafer_map_csv(p, good_bins=[1], retest_policy="LAST")
    pick = lambda r: r.data[(r.data.orig_die_x == 0) & (r.data.orig_die_y == 1)]["hard_bin"].iloc[0]
    assert pick(first) == 1 and pick(last) == 3
    assert len(first.data) == 25 and first.retest_policy == "FIRST"


def test_duplicates_and_unknown_bins_fail_validation(tmp_path):
    rows = rows_basic() + [rows_basic()[0]]
    r = im.load_wafer_map_csv(write(tmp_path, rows), good_bins=[1], valid_bins=[1, 3])
    assert r.label == im.FAILED
    assert any(i["check"] == "duplicate_records" for i in r.issues)
    rows = rows_basic()
    rows[0]["hard_bin"] = 77
    r = im.load_wafer_map_csv(write(tmp_path, rows), good_bins=[1], valid_bins=[1, 3])
    assert r.label == im.FAILED
    with pytest.raises(ValueError):
        im.wafer_counts(r)


def test_missing_dies_reported(tmp_path):
    expected = {(x, y) for x in range(-3, 4) for y in range(-3, 4)}
    r = im.load_wafer_map_csv(write(tmp_path, rows_basic()), good_bins=[1], expected_sites=expected)
    assert any(i["check"] == "missing_dies" for i in r.issues)


def test_coordinate_transform():
    x, y = im.transform_coords(np.array([1]), np.array([0]), rotate_deg=90)
    assert (x[0], y[0]) == (0, 1)
    x, y = im.transform_coords(np.array([1]), np.array([2]), flip_x=True, offset=(10, 0))
    assert (x[0], y[0]) == (9, 2)
    with pytest.raises(ValueError):
        im.transform_coords(np.array([1]), np.array([2]), rotate_deg=45)


def test_defect_json(tmp_path):
    p = tmp_path / "d.json"
    p.write_text(json.dumps({"lot": "L", "wafer": 1, "defects": [{"x_mm": 1, "y_mm": 2, "class": "p"}, {"x": 1}]}))
    d = im.load_defect_json(p)
    assert d["label"] == im.FAILED and len(d["x"]) == 1
    assert "NOT fatal" in d["kind"]


def test_stdf_not_available_reported():
    s = im.stdf_status()
    assert not s.available


def test_testcore_evidence_parsed():
    m = march_coverage()
    assert m["table"]["**all classes" if "**all classes" in m["table"] else "all classes"]["march_c_minus"]["coverage"] \
        == pytest.approx(2216 / 2376)
    assert m["table"]["stuck-at"]["march_c_minus"]["coverage"] == 1.0
    a = atpg_summary()
    assert a["fault_coverage_pct"] == pytest.approx(75.277)
    logs = load_session_logs()
    assert logs["label"].startswith("SIMULATED")


def test_synthetic_fixture_never_verified():
    from pathlib import Path
    p = Path(__file__).resolve().parents[1] / "examples" / "synthetic_wafer_map_fixture.csv"
    r = im.load_wafer_map_csv(p, good_bins=[1], valid_bins=[1, 2, 3], retest_policy="LAST")
    assert r.label == im.FIXTURE and not r.verified
    with pytest.raises(ValueError):
        im.wafer_counts(r)
