"""Statistics: TEST J (denominators), TEST M (reproducibility), TEST N (lot correlation), intervals."""
import numpy as np
import pandas as pd
import pytest

from yieldlab import statistics as st
from yieldlab.monte_carlo import run_simulation


def test_J_every_yield_has_an_explicit_denominator(baseline_scenario):
    """TEST J: every reported yield metric names its numerator and denominator, both present in the data."""
    df = st.add_derived(run_simulation(baseline_scenario.model_copy(deep=True), lots=1, wafers_per_lot=2,
                                       keep_maps=0).wafers)
    for name, (num, den, definition) in st.YIELD_METRICS.items():
        assert num in df.columns and den in df.columns, name
        assert "/" in definition
        assert ((df[name] >= 0) & (df[name] <= 1)).all(), name


def test_M_fixed_seed_reproducible_and_worker_independent(baseline_scenario):
    """TEST M: same seed -> identical results, independent of the number of worker processes."""
    s = baseline_scenario.model_copy(deep=True)
    a = run_simulation(s, lots=2, wafers_per_lot=3, keep_maps=1, workers=1)
    b = run_simulation(s, lots=2, wafers_per_lot=3, keep_maps=1, workers=1)
    c = run_simulation(s, lots=2, wafers_per_lot=3, keep_maps=1, workers=2)
    pd.testing.assert_frame_equal(a.wafers, b.wafers)
    pd.testing.assert_frame_equal(a.wafers, c.wafers)
    assert a.maps[(0, 0)]["defects"]["x"] == c.maps[(0, 0)]["defects"]["x"]
    s2 = s.model_copy(deep=True)
    s2.monte_carlo.seed = 43
    d = run_simulation(s2, lots=2, wafers_per_lot=3, keep_maps=0)
    assert not a.wafers["functional_fail_raw"].equals(d.wafers["functional_fail_raw"])


def test_N_lot_correlation_widens_predictive_uncertainty(baseline_scenario):
    """TEST N: with the same marginal wafer variance, lot-level correlation widens the lot-total PI and the
    honest CI of the mean, and the naive iid interval under-covers."""
    def run(alpha_lot, alpha_wafer):
        s = baseline_scenario.model_copy(deep=True)
        s.defects.variation.alpha_lot = alpha_lot
        s.defects.variation.alpha_wafer = alpha_wafer
        s.defects.variation.excursion_probability = 0.0
        s.parametric.enabled = False
        s.tests.steps = [t for t in s.tests.steps if t.category != "parametric"]
        return run_simulation(s, lots=12, wafers_per_lot=10, keep_maps=0).wafers
    # total multiplier variance matched: Var(LW) = (1+1/a_l)(1+1/a_w) - 1
    corr = run(2.0, None)              # all variation shared by the lot  -> Var = 0.5
    indep = run(None, 2.0)             # all variation per wafer          -> Var = 0.5
    v = "functional_fail_raw"
    sd_lot_corr = np.std(st.lot_totals(corr, v))
    sd_lot_ind = np.std(st.lot_totals(indep, v))
    assert sd_lot_corr > 1.8 * sd_lot_ind
    ci_c = st.mean_ci(corr, v)
    assert ci_c["icc_icc"] > 0.3
    w_cluster = np.diff(ci_c["ci_lot_cluster_t"])[0]
    w_naive = np.diff(ci_c["ci_naive_wafer_t"])[0]
    assert w_cluster > 1.5 * w_naive                # treating correlated wafers as iid understates uncertainty
    ci_i = st.mean_ci(indep, v)
    assert ci_i["icc_icc"] < 0.2


def test_ci_vs_pi_behaviour(rng):
    df = pd.DataFrame({"lot": np.repeat(np.arange(40), 5), "wafer": np.tile(np.arange(5), 40),
                       "x": rng.normal(100, 10, 200)})
    ci = st.mean_ci(df, "x")
    pi = st.predictive_interval(df["x"], 0.9)
    assert np.diff(ci["ci_lot_cluster_t"])[0] < np.diff(pi)[0] / 5      # CI for the mean << PI for a wafer
    assert pi[0] < 100 < pi[1]


def test_convergence_requires_sample_size(rng):
    small = st.convergence(rng.normal(100, 10, 20))
    assert small["status"] == "INSUFFICIENT"
    big = st.convergence(rng.normal(100, 10, 2000), rel_tol=0.01, n_min=100)
    assert big["status"] == "CONVERGED"


def test_prob_target_and_paired_difference(baseline_scenario):
    s = baseline_scenario.model_copy(deep=True)
    a = run_simulation(s, lots=2, wafers_per_lot=4, keep_maps=0).wafers
    p = st.prob_at_least(a["outcome_TRUE_GOOD_PASS"], a["outcome_TRUE_GOOD_PASS"].median())
    assert 0.4 <= p["p"] <= 1.0 and p["wilson95"][0] <= p["p"] <= p["wilson95"][1]
    d = st.paired_difference(a, a, "outcome_TRUE_GOOD_PASS")
    assert d["mean_diff"] == 0 and d["ci_lot_cluster_t"] == (0.0, 0.0)
