"""Cluster analysis: statistical classification of synthetic patterns (not root cause)."""
import numpy as np

from yieldlab.cluster_analysis import analyse, radial_profile, reticle_repeat, ring_indicator


def test_dbscan_finds_planted_cluster_and_line(rng):
    bg = rng.uniform(-90, 90, (200, 2))
    bg = bg[np.hypot(*bg.T) < 95]
    blob = rng.normal([30, -20], 1.0, (40, 2))
    t = np.linspace(0, 1, 60)
    line = np.c_[-60 + 50 * t, 10 + 5 * t] + rng.normal(0, 0.15, (60, 2))
    pts = np.vstack([bg, blob, line])
    res = analyse(pts[:, 0], pts[:, 1], 100.0, "SIMULATED")
    shapes = [c["shape"] for c in res["dbscan"]["clusters"]]
    assert any(s.startswith("linear") for s in shapes)
    assert any(s.startswith("compact") for s in shapes)
    assert "root cause" in res["caveat"]


def test_ring_and_edge_detection(rng):
    r = np.concatenate([rng.normal(70, 1.5, 400), 100 * np.sqrt(rng.random(300))])
    th = rng.uniform(0, 2 * np.pi, r.size)
    prof = radial_profile(r * np.cos(th), r * np.sin(th), 100.0)
    ring = ring_indicator(prof)
    assert ring and ring["ring_inner_mm"] < 70 < ring["ring_outer_mm"]
    r2 = 100 - rng.exponential(3, 500)
    th2 = rng.uniform(0, 2 * np.pi, r2.size)
    assert radial_profile(r2 * np.cos(th2), r2 * np.sin(th2), 100.0)["edge_enrichment"] > 2


def test_reticle_repeat_detected():
    fx, fy = np.meshgrid(np.arange(-3, 3), np.arange(-2, 2))
    x = fx.ravel() * 20.0 + 5.2
    y = fy.ravel() * 30.0 + 7.7
    hits = reticle_repeat(x, y, 20.0, 30.0)
    assert hits and hits[0]["fields"] == x.size
