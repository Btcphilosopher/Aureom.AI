import sys
from pathlib import Path

import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))
CONFIGS = ROOT / "configs"


@pytest.fixture
def rng():
    return np.random.default_rng(12345)


@pytest.fixture(scope="session")
def baseline_scenario():
    from yieldlab.config import load_scenario
    return load_scenario(CONFIGS / "silicaflux_v.yaml")


@pytest.fixture(scope="session")
def baseline_runtime(baseline_scenario):
    from yieldlab.monte_carlo import build_runtime
    return build_runtime(baseline_scenario)
