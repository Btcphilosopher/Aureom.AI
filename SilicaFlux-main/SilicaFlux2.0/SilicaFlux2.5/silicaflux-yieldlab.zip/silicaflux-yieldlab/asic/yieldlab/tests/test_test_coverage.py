"""Test model: TEST K (escapes / detected never counted as true good), coverage gating, retest."""
import numpy as np
import pytest

from yieldlab.monte_carlo import run_simulation
from yieldlab.provenance import MissingInputError, Source
from yieldlab.test_model import Coverage, Outcome, TestPlan, TestStep, classify


def test_K_classification_rules():
    n = 6
    tested = np.ones(n, bool)
    inc = np.zeros(n, bool)
    func_fail = np.array([0, 1, 1, 0, 0, 0], bool)
    cond = np.zeros(n, bool)
    param_ok = np.array([1, 1, 1, 1, 0, 1], bool)
    first_fail = np.array([-1, 3, -1, 2, -1, -1])
    out = classify(n, tested, inc, func_fail, cond, param_ok, first_fail)
    assert out.tolist() == [Outcome.TRUE_GOOD_PASS, Outcome.DEFECTIVE_DETECTED, Outcome.DEFECTIVE_ESCAPED,
                            Outcome.GOOD_REJECTED, Outcome.DEFECTIVE_ESCAPED, Outcome.TRUE_GOOD_PASS]


def test_K_in_simulation(baseline_scenario):
    df = run_simulation(baseline_scenario.model_copy(deep=True), lots=2, wafers_per_lot=4, keep_maps=2).wafers
    # TRUE_GOOD_PASS can never exceed the conforming dies, and escapes / detected are disjoint from it
    assert (df["outcome_TRUE_GOOD_PASS"] + df["outcome_GOOD_REJECTED"] <= df["conforming_wafer"]).all()
    assert (df["outcome_TRUE_GOOD_PASS"] + df["outcome_DEFECTIVE_ESCAPED"] == df["probe_pass"]).all()
    # all dies tested, no hypothetical repair: nonconforming = detected + escaped
    assert (df["untested"] == 0).all() and (df["repaired_conditional"] == 0).all()
    assert (df["outcome_DEFECTIVE_DETECTED"] + df["outcome_DEFECTIVE_ESCAPED"]
            == df["eligible"] - df["conforming_wafer"]).all()
    assert df["outcome_DEFECTIVE_ESCAPED"].sum() > 0       # imperfect coverage produces escapes


def test_perfect_coverage_no_escapes(baseline_scenario):
    s = baseline_scenario.model_copy(deep=True)
    for st in s.tests.steps:
        if st.category != "parametric" and st.enabled:
            st.coverage = {"*": Coverage(value=1.0, source=Source.HYPOTHETICAL, reference="ideal")}
        st.false_reject = Coverage(value=0.0, source=Source.HYPOTHETICAL, reference="none")
    for p in s.parametric.parameters:
        p.measurement_sd = 0.0
    df = run_simulation(s, lots=1, wafers_per_lot=4, keep_maps=0).wafers
    assert df["outcome_DEFECTIVE_ESCAPED"].sum() == 0
    assert df["outcome_GOOD_REJECTED"].sum() == 0


def test_zero_coverage_everything_escapes(baseline_scenario):
    s = baseline_scenario.model_copy(deep=True)
    for st in s.tests.steps:
        st.coverage = {}
        st.false_reject = Coverage(value=0.0, source=Source.HYPOTHETICAL, reference="none")
    s.parametric.enabled = False
    s.tests.steps = [st for st in s.tests.steps if st.category != "parametric"]
    df = run_simulation(s, lots=1, wafers_per_lot=3, keep_maps=0).wafers
    assert (df["outcome_DEFECTIVE_DETECTED"] == 0).all()
    assert (df["outcome_DEFECTIVE_ESCAPED"] == df["functional_fail"]).all()


def test_not_available_coverage_refused(baseline_scenario):
    s = baseline_scenario.model_copy(deep=True)
    for st in s.tests.steps:
        if st.name == "scan_atpg":
            st.enabled = True
    with pytest.raises(MissingInputError):
        run_simulation(s, lots=1, wafers_per_lot=1)


def test_retest_reduces_false_rejects(baseline_scenario):
    def run(retests):
        s = baseline_scenario.model_copy(deep=True)
        s.tests.max_retests = retests
        for st in s.tests.steps:
            if st.name == "continuity":
                st.false_reject = Coverage(value=0.05, source=Source.HYPOTHETICAL, reference="t")
        return run_simulation(s, lots=1, wafers_per_lot=3, keep_maps=0).wafers
    a, b = run(0), run(2)
    assert b["false_reject_dies"].sum() < a["false_reject_dies"].sum()
