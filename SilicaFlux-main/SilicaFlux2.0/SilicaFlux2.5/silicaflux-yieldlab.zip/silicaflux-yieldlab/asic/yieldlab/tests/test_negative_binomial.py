"""Negative binomial: moments (TEST D), zero probability (TEST E), Poisson limit (TEST F)."""
import math

import numpy as np
import pytest
from scipy import stats

from yieldlab import yield_models as ym


@pytest.mark.parametrize("a,d0,alpha", [(1.0, 0.5, 0.5), (0.12, 1.0, 2.0), (2.0, 0.3, 10.0)])
def test_D_mean_and_variance(rng, a, d0, alpha):
    """TEST D: sampled counts reproduce E[N] = A D0 and Var[N] = mu + mu^2 / alpha."""
    n = 400000
    k = ym.sample_defect_counts("negative_binomial", n, a, d0, rng, alpha)
    th = ym.nb_moments(a, d0, alpha)
    se_mean = math.sqrt(th["var_count"] / n)
    assert abs(k.mean() - th["mean_count"]) < 5 * se_mean
    # variance: compare with a generous relative tolerance driven by the 4th moment
    assert k.var() == pytest.approx(th["var_count"], rel=0.03)
    # also matches scipy's NB parameterisation
    p = alpha / (alpha + th["mean_count"])
    assert stats.nbinom.var(alpha, p) == pytest.approx(th["var_count"])


@pytest.mark.parametrize("a,d0,alpha", [(1.0, 0.5, 0.5), (0.12, 1.0, 2.0), (2.0, 0.3, 10.0)])
def test_E_zero_probability(rng, a, d0, alpha):
    """TEST E: simulated P(N = 0) matches (1 + A D0 / alpha)^-alpha."""
    n = 300000
    p, se = ym.monte_carlo_yield("negative_binomial", n, a, d0, rng, alpha)
    th = ym.negative_binomial_yield(a, d0, alpha)
    assert abs(p - th) < 5 * se
    p2 = alpha / (alpha + a * d0)
    assert stats.nbinom.pmf(0, alpha, p2) == pytest.approx(th)


def test_F_converges_to_poisson():
    """TEST F: alpha -> infinity recovers exp(-A D0); the error decreases monotonically."""
    a, d0 = 0.5, 1.2
    target = ym.poisson_yield(a, d0)
    errs = [abs(ym.negative_binomial_yield(a, d0, al) - target) for al in (0.5, 1, 5, 50, 500, 5e4, 5e6)]
    assert all(e2 < e1 for e1, e2 in zip(errs, errs[1:]))
    assert errs[-1] < 1e-7
    assert ym.negative_binomial_yield(a, d0, float("inf")) == target


def test_seeds_is_nb_alpha_one():
    assert ym.seeds_yield(0.7, 0.9) == pytest.approx(1 / (1 + 0.63))


def test_model_ordering_for_same_mean_density():
    """Clustering (finite alpha) raises zero-defect probability vs Poisson at equal mean density (Jensen)."""
    a, d0 = 1.0, 1.0
    assert ym.negative_binomial_yield(a, d0, 1.0) > ym.murphy_yield(a, d0) > ym.poisson_yield(a, d0)
