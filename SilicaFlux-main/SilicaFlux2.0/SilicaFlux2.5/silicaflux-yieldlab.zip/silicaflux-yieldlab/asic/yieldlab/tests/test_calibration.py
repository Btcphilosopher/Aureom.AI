"""Calibration: recover known parameters from synthetic data; identifiability warnings; holdout."""
import numpy as np
import pytest

from yieldlab import calibration as cal


def synth(rng, wafers, n, area, d0, alpha):
    lam = rng.gamma(alpha, d0 / alpha, wafers)
    good = rng.binomial(n, np.exp(-area * lam))
    return good, np.full(wafers, n)


def test_poisson_fit_recovers_d0(rng):
    area, d0, n = 0.5, 0.8, 20000
    good = rng.binomial(n, np.exp(-area * d0))
    f = cal.fit_poisson_d0(int(good), n, area)
    assert f["ci95"][0] < d0 < f["ci95"][1]


def test_nb_fit_recovers_parameters(rng):
    area, d0, alpha = 0.12, 1.0, 3.0
    good, n = synth(rng, 200, 2000, area, d0, alpha)
    f = cal.fit_nb_wafer(good, n, area)
    assert f["d0_ci95_profile"][0] < d0 < f["d0_ci95_profile"][1]
    assert f["alpha_ci95_profile"][0] < alpha < f["alpha_ci95_profile"][1]
    assert f["p_value_vs_poisson_chibar2"] < 1e-6        # strong wafer-level dispersion detected


def test_nb_fit_poisson_data_alpha_unbounded(rng):
    area, d0 = 0.12, 1.0
    n = np.full(60, 2000)
    good = rng.binomial(n, np.exp(-area * d0))
    f = cal.fit_nb_wafer(good, n, area)
    assert f["p_value_vs_poisson_chibar2"] > 0.01
    assert f["alpha_ci95_profile"][1] > 50


def test_small_dataset_flagged(rng):
    good, n = synth(rng, 4, 500, 0.1, 0.5, 2.0)
    f = cal.fit_nb_wafer(good, n, 0.1)
    assert "identifiability" in f


def test_holdout_and_gof(rng):
    area, d0, alpha = 0.12, 1.0, 3.0
    good, n = synth(rng, 120, 2000, area, d0, alpha)
    tr, va = cal.holdout_split(len(n), 0.3, rng)
    assert set(tr).isdisjoint(va) and len(tr) + len(va) == len(n)
    f = cal.fit_nb_wafer(good[tr], n[tr], area)
    v = cal.validate_nb(f, good[va], n[va], area, rng)
    assert 0.75 <= v["pi90_coverage"] <= 1.0
    g = cal.gof_wafer_yields(f, good, n, area, rng)
    assert g["p_value"] > 0.001


def test_window_method_detects_clustering(rng):
    from yieldlab.die_layout import DieSpec, layout_wafer
    # independent pass/fail grid -> alpha large; clustered (block-shared intensity) -> alpha small
    area, d0 = 0.1, 1.5
    indep = [(rng.random((30, 30)) < np.exp(-area * d0)).astype(float) for _ in range(4)]
    f_ind = cal.window_method(indep, area)
    clustered = []
    for _ in range(4):
        lam = np.kron(rng.gamma(0.5, d0 / 0.5, (10, 10)), np.ones((3, 3)))
        clustered.append((rng.random((30, 30)) < np.exp(-area * lam)).astype(float))
    f_cl = cal.window_method(clustered, area)
    assert f_cl["alpha"] < f_ind["alpha"]


def test_learning_curve_refused_without_data():
    assert cal.fit_learning_curve(np.array([1, 2]), np.array([1.0, 0.8]))["status"] == "REFUSED"
    t = np.array([0, 1, 2, 3, 4, 5.0])
    d = 0.2 + 0.8 * np.exp(-t / 2)
    f = cal.fit_learning_curve(t, d)
    assert f["status"] == "FITTED" and f["tau"] == pytest.approx(2.0, rel=0.05)


def test_variance_components(rng):
    lots, wafers, dies = 12, 8, 300
    v, lot, waf = [], [], []
    for l in range(lots):
        L = rng.normal(0, 2.0)
        for w in range(wafers):
            W = rng.normal(0, 1.0)
            v.append(60 + L + W + rng.normal(0, 3.0, dies))
            lot += [l] * dies
            waf += [w] * dies
    vc = cal.variance_components(np.concatenate(v), np.array(lot), np.array(waf))
    assert vc["die_sd"] == pytest.approx(3.0, rel=0.05)
    assert vc["wafer_sd"] == pytest.approx(1.0, rel=0.35)
    assert vc["lot_sd"] == pytest.approx(2.0, rel=0.5)


def test_nb_likelihood_quadrature_matches_adaptive_integration():
    import math
    from scipy import integrate, stats
    area = 0.12
    good = np.array([1990.0, 1800.0, 1500.0, 1100.0, 700.0, 2000.0])     # includes gamma-tail wafers
    n = np.full(6, 2000.0)
    exact = 0.0
    for g, nn in zip(good, n):
        f = lambda l: stats.binom.pmf(g, nn, math.exp(-area * l)) * stats.gamma.pdf(l, 3.0, scale=1.0 / 3.0)
        v, _ = integrate.quad(f, 0, 60, limit=1000, points=[-math.log(max(g, 0.5) / nn) / area],
                              epsabs=0, epsrel=1e-10)
        exact += math.log(v)
    assert cal._nb_wafer_loglik(1.0, 3.0, good, n, area) == pytest.approx(exact, abs=1e-5)
