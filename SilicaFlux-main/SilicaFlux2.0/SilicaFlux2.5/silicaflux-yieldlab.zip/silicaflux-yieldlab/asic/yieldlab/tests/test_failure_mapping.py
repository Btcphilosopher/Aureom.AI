"""Defect-to-die intersection, fatality models, no double counting."""
import numpy as np
import pytest

from yieldlab.defect_mapping import Hits, map_defects, map_points, per_die_counts
from yieldlab.fatality import FatalityModel
from yieldlab.spatial_defects import DefectSet
from shapely.geometry import LineString, Polygon


def make_ds(x, y, size_um, cls=None, extended=()):
    n = len(x)
    return DefectSet(np.array(x, float), np.array(y, float), np.array(size_um, float),
                     np.zeros(n, int) if cls is None else np.array(cls), np.zeros(n, int), np.ones(n),
                     np.zeros(n, int), np.full(n, -1), ["particle", "scratch"], ["any"], ["g0", "g1"], list(extended))


def test_street_defect_hits_no_die_and_large_defect_hits_two(baseline_runtime, rng):
    rt = baseline_runtime
    wm = rt.wmap
    s = rt.elig[len(rt.elig) // 2]
    # find right-hand neighbour
    nb = np.nonzero((wm.ix == wm.ix[s] + 1) & (wm.iy == wm.iy[s]))[0][0]
    street_x = (wm.dx1[s] + wm.dx0[nb]) / 2
    yc = wm.cy[s]
    ds = make_ds([street_x, street_x], [yc, yc], [1.0, 200.0])     # 1 um in the street; 200 um spans both dies
    h = map_points(ds, wm, rt.rm, rng)
    assert set(h.site[h.event == 0]) == set()
    assert set(h.site[h.event == 1]) == {s, nb}


def test_defect_inside_die_hits_exactly_that_die(baseline_runtime, rng):
    rt = baseline_runtime
    wm = rt.wmap
    s = rt.elig[10]
    ds = make_ds([wm.cx[s]], [wm.cy[s]], [0.5])
    h = map_points(ds, wm, rt.rm, rng)
    assert h.site.tolist() == [s]
    assert 0 <= h.lx_um[0] <= rt.rm.die_w_um and 0 <= h.ly_um[0] <= rt.rm.die_h_um


def test_no_double_counting(baseline_runtime, rng):
    rt = baseline_runtime
    wm = rt.wmap
    s = rt.elig[20]
    ds = make_ds([wm.cx[s]] * 5, [wm.cy[s]] * 5, [0.2] * 5)
    h = map_defects(ds, wm, rt.rm, FatalityModel(mode="all_fatal"), rng)
    ev, fev = per_die_counts(h, wm.n_sites)
    assert ev[s] == 5 and fev[s] == 5
    failed_dies = int((fev[rt.elig] > 0).sum())
    assert failed_dies == 1                         # 5 fatal defects, 1 failed die


def test_scratch_intersection_exact(baseline_runtime, rng):
    rt = baseline_runtime
    wm = rt.wmap
    s = rt.elig[30]
    line = LineString([(wm.dx0[s] - 1, wm.cy[s]), (wm.dx1[s] + 1, wm.cy[s])])   # crosses die s and its street
    ds = make_ds([], [], [], extended=[{"geom": line, "cls": 1, "layer": 0, "severity": 1.0, "gen": 1, "width_um": 10}])
    h = map_defects(ds, wm, rt.rm, FatalityModel(mode="all_fatal"), rng)
    hit_sites = set(h.site.tolist())
    assert s in hit_sites
    for t in hit_sites:
        assert wm.dy0[t] <= wm.cy[s] <= wm.dy1[t]
    ev, _ = per_die_counts(h, wm.n_sites)
    assert ev[s] == 1                               # one scratch = one defect event per die
    assert len(set(h.rid[h.site == s].tolist())) >= 2   # crosses several functional regions


def test_polygon_defect(baseline_runtime, rng):
    rt = baseline_runtime
    wm = rt.wmap
    s = rt.elig[40]
    poly = Polygon([(wm.cx[s] - 0.2, wm.cy[s] - 0.2), (wm.cx[s] + 0.2, wm.cy[s] - 0.2), (wm.cx[s], wm.cy[s] + 0.3)])
    ds = make_ds([], [], [], extended=[{"geom": poly, "cls": 0, "layer": 0, "severity": 1.0, "gen": 0}])
    h = map_defects(ds, wm, rt.rm, FatalityModel(mode="all_fatal"), rng)
    assert set(h.site.tolist()) == {s}


def test_fatality_models():
    names, kinds, classes = ["sram_a", "logic_b", "pads"], ["sram", "logic", "io"], ["particle", "scratch"]
    rid = np.array([0, 1, 2, 2])
    cls = np.array([0, 0, 0, 1])
    size = np.array([0.1, 0.1, 0.1, 0.1])
    sev = np.array([1.0, 1.0, 0.5, 1.0])
    assert np.all(FatalityModel(mode="all_fatal").kill_probability(names, kinds, classes, rid, cls, size, sev) == 1)
    fm = FatalityModel(mode="class_kill", class_kill={"particle": 0.3, "scratch": 0.9})
    assert fm.kill_probability(names, kinds, classes, rid, cls, size, sev).tolist() == [0.3, 0.3, 0.3, 0.9]
    fm = FatalityModel(mode="region_class", default_kill=0.5, region_kill={"io": {"particle": 0.1}, "pads": {"scratch": 0.2}},
                       severity_scaling=True)
    p = fm.kill_probability(names, kinds, classes, rid, cls, size, sev)
    assert p.tolist() == pytest.approx([0.5, 0.5, 0.05, 0.2])
    fm = FatalityModel(mode="critical_area", critical_area={"sram": {"width_um": 0.2, "space_um": 0.2, "density": 1.0}})
    big = fm.kill_probability(names, kinds, classes, np.array([0, 0, 0]), np.zeros(3, int), np.array([0.1, 0.4, 2.0]), np.ones(3))
    assert big[0] == 0 and 0 < big[1] < 1 and big[2] == 1
    assert fm.kill_probability(names, kinds, classes, np.array([1]), np.zeros(1, int), np.array([5.0]), np.ones(1))[0] == 0


def test_region_model_areas_add_up(baseline_runtime):
    rm = baseline_runtime.rm
    tot = sum(r.located_area_um2 for r in rm.regions)
    assert tot == pytest.approx(rm.W * rm.H, rel=1e-9)
    sram = sum(r.cell_area_um2 for r in rm.regions if r.kind == "sram")
    assert sram == pytest.approx(4533478.5, rel=1e-3)          # FloorplanLab macro area (ppa_table)
    assert len(rm.macro_list()) == 12
