"""Edge exclusion: monotonicity and exactness."""
import numpy as np

from yieldlab.die_layout import DieSpec, layout_wafer, SiteClass
from yieldlab.provenance import Source
from yieldlab.wafer_geometry import WaferSpec, NotchSpec


def d():
    return DieSpec(name="t", width_um=2000, height_um=2000, source=Source.HYPOTHETICAL, reference="t",
                   scribe_x_um=80, scribe_y_um=80)


def test_more_exclusion_never_more_full_dies():
    counts = [layout_wafer(WaferSpec(diameter_mm=200, edge_exclusion_mm=e), d()).n_full for e in (0, 1, 2, 3, 5, 8)]
    assert counts == sorted(counts, reverse=True)


def test_zero_exclusion_has_no_edge_excluded_sites_without_notch():
    m = layout_wafer(WaferSpec(diameter_mm=200, edge_exclusion_mm=0), d())
    assert m.count(SiteClass.EDGE_EXCLUDED) == 0


def test_notch_keepout_buffered_by_exclusion():
    w = WaferSpec(diameter_mm=200, edge_exclusion_mm=3, orientation=NotchSpec(depth_mm=1, angle_deg=90))
    m = layout_wafer(w, d())
    g = m.geometry
    # the notch apex is at (0, -99); every FULL die is >= e away from the notch triangle
    import shapely
    full = m.eligible
    dist = shapely.distance(shapely.box(m.fx0[full], m.fy0[full], m.fx1[full], m.fy1[full]), g.notch_triangle())
    assert np.all(dist >= 3 - 1e-3)


def test_usable_area_analytic():
    w = WaferSpec(diameter_mm=200, edge_exclusion_mm=3)
    from yieldlab.wafer_geometry import WaferGeometry
    g = WaferGeometry(w)
    assert abs(g.usable_area_mm2() - np.pi * 97**2) / (np.pi * 97**2) < 1e-5
