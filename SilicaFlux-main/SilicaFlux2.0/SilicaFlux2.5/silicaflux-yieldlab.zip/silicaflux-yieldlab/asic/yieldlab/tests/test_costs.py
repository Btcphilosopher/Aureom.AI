"""Cost engine: TEST Q (independent hand calculation), TEST O (zero packaging loss), TEST R (no silent inputs)."""
import pytest
import yaml

from yieldlab.costs import (CostItem, FirstSiliconPlan, FullWaferCosts, MPWQuote, StageCounts, first_silicon,
                            full_wafer_cost, load_costs, mpw_cost, tornado)
from yieldlab.monte_carlo import run_simulation
from yieldlab.provenance import MissingInputError, Source
from yieldlab.test_model import Coverage

from conftest import CONFIGS


def H(v):
    return CostItem(value=v, source=Source.HYPOTHETICAL, reference="test")


def costs(**kw):
    base = dict(wafer_cost=H(1000), probe_cost_per_die=H(0.1), probe_cost_per_wafer=H(10),
                dicing_cost_per_wafer=H(5), packaging_cost_per_unit=H(1.0), final_test_cost_per_unit=H(0.5),
                shipping_cost_per_unit=H(0.0), mask_set_nre=H(10000), include_nre=[])
    base.update(kw)
    return FullWaferCosts(**base)


def test_Q_hand_calculated_example():
    """TEST Q: 10 wafers x 500 tested dies, 450 pass probe, 450 packaged, 440 delivered, 436 conforming."""
    n = StageCounts(wafers=10, eligible=5000, tested=5000, probe_pass=4500, true_good_at_probe=4480, packaged=4500,
                    delivered=4400, delivered_conforming=4360, delivered_escape=40)
    r = full_wafer_cost(costs(), n)
    # by hand: fab 10*1000 = 10000; probe 5000*0.1 + 10*10 = 600; dicing 50; packaging 4500*1 = 4500;
    # final test 4500*0.5 = 2250; ship 0  -> total 17400; per conforming die 17400 / 4360
    assert r["total_cost"] == pytest.approx(17400.0)
    assert r["cost_per_delivered_conforming_die"] == pytest.approx(17400.0 / 4360)
    assert r["silicon_cost_per_true_good_die_at_probe"] == pytest.approx(10600 / 4480)
    assert r["quality_risk"]["escape_dppm"] == pytest.approx(1e6 * 40 / 4400)
    stages = {s["stage"]: s for s in r["stages"]}
    assert stages["PACKAGING"]["in"] == 4500            # screened-out dies are not packaged
    # with NRE amortised over 100 000 units: + 10000 * 4360 / 100000
    r2 = full_wafer_cost(costs(include_nre=["mask_set_nre"], nre_amortisation_units=100000), n)
    assert r2["total_cost"] == pytest.approx(17400 + 10000 * 0.0436)


def test_escapes_excluded_from_denominator():
    n = StageCounts(wafers=1, eligible=100, tested=100, probe_pass=90, true_good_at_probe=80, packaged=90,
                    delivered=90, delivered_conforming=80, delivered_escape=10)
    r = full_wafer_cost(costs(), n)
    assert r["cost_per_delivered_conforming_die"] == pytest.approx(r["total_cost"] / 80)


def test_R_missing_inputs_refused():
    """TEST R: a NOT_AVAILABLE input is never silently replaced."""
    tmpl = yaml.safe_load(open(CONFIGS / "costs" / "quote_template.yaml"))["costs"]
    fw, mp, _ = load_costs(tmpl)
    n = StageCounts(wafers=1, eligible=1, tested=1, probe_pass=1, true_good_at_probe=1, packaged=1, delivered=1,
                    delivered_conforming=1, delivered_escape=0)
    with pytest.raises(MissingInputError):
        full_wafer_cost(fw, n)
    with pytest.raises(MissingInputError):
        mpw_cost(mp, 10.0, 0.9, "x")
    # a default-constructed cost model has no numbers at all
    with pytest.raises(MissingInputError):
        full_wafer_cost(FullWaferCosts(), n)


def test_R_node_profiles_never_invent_d0():
    from yieldlab.process_profiles import load_nodes
    for n in load_nodes():
        assert not n.defect_density_per_cm2.available
        assert not n.wafer_price.available


def test_O_zero_packaging_loss_preserves_good_dies(baseline_scenario):
    """TEST O: assembly yield 1 and no final-test false rejects -> every packaged conforming die is delivered."""
    s = baseline_scenario.model_copy(deep=True)
    s.tests.assembly_yield = Coverage(value=1.0, source=Source.HYPOTHETICAL, reference="t")
    for st in s.tests.steps:
        if st.insertion == "final_test":
            st.false_reject = Coverage(value=0.0, source=Source.HYPOTHETICAL, reference="t")
    df = run_simulation(s, lots=1, wafers_per_lot=4, keep_maps=0).wafers
    assert (df["assembly_fail"] == 0).all()
    assert (df["delivered_conforming"] == df["outcome_TRUE_GOOD_PASS"]).all()


def test_mpw_and_first_silicon_examples():
    d = yaml.safe_load(open(CONFIGS / "costs" / "example_costs.yaml"))["costs"]
    fw, mp, fs = load_costs(d)
    r = mpw_cost(mp, 11.79, 0.95, "test")
    assert r["total_cost"] == pytest.approx(50000 + 40 * 85)
    assert r["expected_good_prototypes"] == pytest.approx(38.0)
    with pytest.raises(ValueError):
        mpw_cost(mp, 20.0, 0.9, "x")                    # die larger than the purchased tile
    f = first_silicon(fs, 0.95, "test")
    rows = {r["respins"]: r for r in f["scenarios"]}
    run = 63000 + 40 * 85 + 30000
    assert rows[0]["program_cost"] == pytest.approx(36 * 12000 + run)
    assert rows[1]["program_cost"] == pytest.approx(36 * 12000 + 2 * run + 6 * 12000)
    assert "NOT comparable" in f["measure"]
    assert f["label"].startswith("SIMULATED - HYPOTHETICAL")


def test_tornado_orders_by_impact():
    n = StageCounts(wafers=10, eligible=5000, tested=5000, probe_pass=4500, true_good_at_probe=4480, packaged=4500,
                    delivered=4400, delivered_conforming=4360, delivered_escape=40)
    rows = tornado(costs(), n)
    spans = [r["high"] - r["low"] for r in rows]
    assert spans == sorted(spans, reverse=True)
    assert rows[0]["item"] == "wafer_cost"
