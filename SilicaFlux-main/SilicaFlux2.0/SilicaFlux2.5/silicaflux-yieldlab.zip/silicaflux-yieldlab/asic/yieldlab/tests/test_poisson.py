"""Poisson model: limits (TEST A, B), units, spatial convergence (TEST C)."""
import math

import numpy as np
import pytest
from hypothesis import given, strategies as st

from yieldlab import yield_models as ym
from yieldlab.units import UnitError, mm2_to_cm2, um2_to_cm2


def test_A_zero_density_or_area_gives_unit_yield():
    assert ym.poisson_yield(1.0, 0.0) == 1.0
    assert ym.poisson_yield(0.0, 5.0) == 1.0
    for m in ("poisson", "seeds", "murphy", "murphy_uniform"):
        assert ym.evaluate(m, 0.7, 0.0) == pytest.approx(1.0)
    assert ym.negative_binomial_yield(0.7, 0.0, 2.0) == 1.0


@given(a=st.floats(0.01, 5), d=st.floats(0.01, 5), k=st.floats(1.01, 3))
def test_B_monotone_decreasing(a, d, k):
    """TEST B: more density (or area) -> lower yield, for every model."""
    for m in ("poisson", "seeds", "murphy", "murphy_uniform"):
        assert ym.evaluate(m, a, d * k) < ym.evaluate(m, a, d)
        assert ym.evaluate(m, a * k, d) < ym.evaluate(m, a, d)
    assert ym.negative_binomial_yield(a, d * k, 2.0) < ym.negative_binomial_yield(a, d, 2.0)


def test_rejects_negative_and_nonfinite():
    for bad in ((-1, 0.1), (1, -0.1), (float("nan"), 0.1), (1, float("inf"))):
        with pytest.raises(UnitError):
            ym.poisson_yield(*bad)
    with pytest.raises(UnitError):
        ym.negative_binomial_yield(1, 0.1, 0.0)


def test_unit_conversions():
    assert mm2_to_cm2(100.0) == 1.0
    assert um2_to_cm2(1e8) == 1.0
    # an SFV-size die: 11.79 mm^2 -> 0.1179 cm^2 (a factor-100 slip would change Y at D0 = 0.5 from 0.943 to 0.003)
    assert ym.poisson_yield(mm2_to_cm2(11.79), 0.5) == pytest.approx(math.exp(-0.05895))


def test_C_spatial_simulation_converges_to_exp(rng):
    """TEST C: homogeneous PPP on a wafer, fraction of defect-free dies -> exp(-A D0) (all dies interior)."""
    from yieldlab.die_layout import DieSpec, layout_wafer
    from yieldlab.provenance import Source
    from yieldlab.wafer_geometry import WaferSpec, WaferGeometry
    from yieldlab.spatial_defects import DefectGenerator, DefectModel, Uniform, SizeDist

    d0 = 0.5
    die = DieSpec(name="t", width_um=4000, height_um=3000, source=Source.HYPOTHETICAL, reference="t",
                  scribe_x_um=100, scribe_y_um=100)
    geo = WaferGeometry(WaferSpec(diameter_mm=200, edge_exclusion_mm=3))
    wm = layout_wafer(geo, die)
    tiny = SizeDist(x0_um=1e-4, power=3, max_um=1e-3)          # point-like defects
    gen = DefectGenerator(DefectModel(name="u", components=[Uniform(density_per_cm2=d0, size=tiny)]), geo, wm)
    e = wm.eligible
    zero = n = 0
    for _ in range(60):
        ds = gen.generate(rng)
        # count defects per die rectangle by brute force (independent of defect_mapping)
        hit = np.zeros(wm.n_sites, int)
        for x, y in zip(ds.x, ds.y):
            i = np.nonzero((x >= wm.dx0) & (x <= wm.dx1) & (y >= wm.dy0) & (y <= wm.dy1))[0]
            hit[i] += 1
        zero += int((hit[e] == 0).sum())
        n += int(e.sum())
    y_sim = zero / n
    y_th = math.exp(-die.area_cm2 * d0)
    se = math.sqrt(y_th * (1 - y_th) / n)
    assert abs(y_sim - y_th) < 4 * se, (y_sim, y_th, se)


def test_monte_carlo_counterparts_match(rng):
    for model in ("poisson", "seeds", "murphy", "murphy_uniform"):
        p, se = ym.monte_carlo_yield(model, 200000, 0.8, 0.9, rng)
        assert abs(p - ym.evaluate(model, 0.8, 0.9)) < 4.5 * se


def test_murphy_small_x_stable():
    for x in (1e-14, 1e-10, 1e-7, 1e-6, 1e-5):
        y = ym.murphy_yield(x, 1.0)
        assert 0.0 < y <= 1.0
        assert y == pytest.approx(1 - x + 7 * x * x / 12, rel=1e-6, abs=1e-12)
