"""Provenance and configuration: NOT_AVAILABLE can never become a number; labels; strict configs."""
import pytest
from pydantic import ValidationError

from yieldlab.config import load_scenario, set_dotted
from yieldlab.provenance import MissingInputError, ProvenanceLedger, Source, Sourced

from conftest import CONFIGS


def test_not_available_raises():
    s = Sourced.na("wafer price")
    with pytest.raises(MissingInputError):
        _ = s.value
    with pytest.raises(ValueError):
        Sourced(value=1.0, source=Source.NOT_AVAILABLE, reference="x")
    with pytest.raises(ValueError):
        Sourced(value=None, source=Source.HYPOTHETICAL, reference="x")


def test_ledger_labels():
    led = ProvenanceLedger()
    led.use("die", Sourced(value=1, source=Source.MEASURED_TOOL_OUTPUT, reference="flp"))
    assert led.result_label() == "SIMULATED"
    led.use("d0", Sourced(value=0.2, source=Source.HYPOTHETICAL, reference="x"))
    assert "HYPOTHETICAL" in led.result_label()
    m = ProvenanceLedger()
    m.use("map", Sourced(value=1, source=Source.MEASURED_MANUFACTURING, reference="lot"))
    assert m.result_label() == "DERIVED FROM VERIFIED IMPORTED DATA"


def test_unknown_config_key_rejected(tmp_path):
    p = tmp_path / "s.yaml"
    p.write_text((CONFIGS / "silicaflux_v.yaml").read_text() + "\noverrides:\n  wafer.edge_exclution_mm: 2\n")
    with pytest.raises(ValidationError):
        load_scenario(p)


def test_overrides_apply():
    s = load_scenario(CONFIGS / "silicaflux_v.yaml", {"wafer.edge_exclusion_mm": 5.0,
                                                      "defects.components.0.density_per_cm2": 0.9})
    assert s.wafer.edge_exclusion_mm == 5.0
    assert s.defects.components[0].density_per_cm2 == 0.9


def test_every_shipped_config_loads():
    for p in sorted(CONFIGS.glob("*.yaml")) + sorted((CONFIGS / "experiments").glob("*.yaml")):
        from yieldlab.config import load_yaml
        d = load_yaml(p)
        if "scenario" in d:
            load_scenario(p)
