"""Binning: TEST L (mutually exclusive classifications add up), exhaustive bins, inactive capabilities."""
import numpy as np
import pytest

from yieldlab.binning import BinDef, BinTable, assign_bins
from yieldlab.monte_carlo import run_simulation
from yieldlab.test_model import Outcome


def test_L_outcomes_and_bins_partition_eligible(baseline_scenario):
    """TEST L: every eligible die has exactly one outcome and one bin; both sum to the eligible count."""
    s = baseline_scenario.model_copy(deep=True)
    df = run_simulation(s, lots=2, wafers_per_lot=5, keep_maps=0).wafers
    outc = df[[f"outcome_{o.name}" for o in Outcome]].sum(axis=1)
    bins = df[[c for c in df.columns if c.startswith("bin_")]].sum(axis=1)
    assert (outc == df["eligible"]).all()
    assert (bins == df["eligible"]).all()
    assert (df["bin_99"] == 0).all()                 # fallback must stay empty
    assert (df["bin_2"] == 0).all() and (df["bin_3"] == 0).all()   # inactive: no capability


def test_bin_priority_and_conditions():
    t = BinTable(name="t", bins=[
        BinDef(code=1, name="good", priority=1, when={"field": "passed_all", "eq": True}, sellable=True),
        BinDef(code=5, name="elec", priority=2, when={"field": "cat", "in": ["electrical"]}),
        BinDef(code=9, name="rest", priority=9, when={"always": True})])
    f = {"passed_all": np.array([True, False, False]), "cat": np.array(["", "electrical", "memory"], dtype=object)}
    assert assign_bins(t, f, 3).tolist() == [1, 5, 9]


def test_bin_table_validation():
    with pytest.raises(ValueError):
        BinTable(name="t", bins=[BinDef(code=1, name="a", priority=1, when={"field": "x", "eq": 1})])
    with pytest.raises(ValueError):
        BinTable(name="t", bins=[BinDef(code=1, name="a", priority=1, when={"always": True}),
                                 BinDef(code=1, name="b", priority=2, when={"always": True})])


def test_capability_gated_bin_inactive():
    t = BinTable(name="t", bins=[
        BinDef(code=3, name="reduced", priority=1, requires_capability="reduced_config_product",
               when={"always": True}, sellable=True),
        BinDef(code=9, name="rest", priority=9, when={"always": True})])
    assert assign_bins(t, {}, 2).tolist() == [9, 9]
    t.active_capabilities = ["reduced_config_product"]
    assert assign_bins(t, {}, 2).tolist() == [3, 3]
