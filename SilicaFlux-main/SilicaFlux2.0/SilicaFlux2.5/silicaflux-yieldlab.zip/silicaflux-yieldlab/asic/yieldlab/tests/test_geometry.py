"""Wafer geometry: exact containment (TEST H), site classification, property-based invariants."""
import math

import numpy as np
import pytest
import shapely
from hypothesis import given, settings, strategies as st

from yieldlab.die_layout import DieSpec, LayoutSpec, ReticleSpec, SiteClass, layout_wafer
from yieldlab.provenance import Source
from yieldlab.wafer_geometry import FlatSpec, NotchSpec, WaferGeometry, WaferSpec, ExclusionZone


def die(w=3000, h=2000, s=100, rot=0):
    return DieSpec(name="t", width_um=w, height_um=h, source=Source.HYPOTHETICAL, reference="test",
                   scribe_x_um=s, scribe_y_um=s, rotation_deg=rot)


@pytest.mark.parametrize("diam,orient", [(100, FlatSpec(length_mm=32.5)), (150, FlatSpec(length_mm=57.5)),
                                         (200, NotchSpec(depth_mm=1, angle_deg=90)),
                                         (300, NotchSpec(depth_mm=1, angle_deg=90)), (200, None)])
def test_H_full_dies_inside_usable_area(diam, orient):
    """TEST H: no die marked FULL lies outside the permitted wafer geometry (independent Shapely check)."""
    w = WaferSpec(diameter_mm=diam, edge_exclusion_mm=3, orientation=orient)
    m = layout_wafer(w, die())
    geo = m.geometry
    full = m.cls == SiteClass.FULL_DIE
    boxes = shapely.box(m.fx0[full], m.fy0[full], m.fx1[full], m.fy1[full])
    assert np.all(shapely.contains(geo.usable_polygon().buffer(1e-6), boxes))
    # every corner of every full die footprint within R - e
    for cx, cy in ((m.fx0, m.fy0), (m.fx1, m.fy0), (m.fx0, m.fy1), (m.fx1, m.fy1)):
        assert np.all(np.hypot(cx[full], cy[full]) <= geo.R - geo.e + 1e-9)


def test_classification_matches_shapely_reference():
    w = WaferSpec(diameter_mm=200, edge_exclusion_mm=5, orientation=NotchSpec(depth_mm=1, angle_deg=90))
    m = layout_wafer(w, die(2500, 2500, 80))
    g = m.geometry
    boxes = shapely.box(m.fx0, m.fy0, m.fx1, m.fy1)
    ref_usable = shapely.contains(g.usable_polygon(), boxes)
    ref_physical = shapely.contains(g.wafer_polygon(), boxes)
    assert np.array_equal(ref_usable, g.contains_usable(m.fx0, m.fy0, m.fx1, m.fy1))
    assert np.array_equal(ref_physical, g.contains_physical(m.fx0, m.fy0, m.fx1, m.fy1))
    assert np.all((m.cls == SiteClass.PARTIAL) == ~ref_physical)
    assert np.all(shapely.intersects(g.wafer_polygon(), boxes))     # stored sites all touch the wafer


def test_notch_and_flat_remove_sites():
    plain = layout_wafer(WaferSpec(diameter_mm=200, edge_exclusion_mm=3), die(1000, 1000, 50)).n_full
    notch = layout_wafer(WaferSpec(diameter_mm=200, edge_exclusion_mm=3,
                                   orientation=NotchSpec(depth_mm=1, angle_deg=90)), die(1000, 1000, 50)).n_full
    flat = layout_wafer(WaferSpec(diameter_mm=150, edge_exclusion_mm=3, orientation=FlatSpec(length_mm=57.5)),
                        die(1000, 1000, 50)).n_full
    flat_none = layout_wafer(WaferSpec(diameter_mm=150, edge_exclusion_mm=3), die(1000, 1000, 50)).n_full
    assert notch <= plain
    assert flat < flat_none


def test_invalid_configurations_rejected():
    with pytest.raises(ValueError):
        WaferSpec(diameter_mm=250, edge_exclusion_mm=3)
    with pytest.raises(ValueError):
        WaferSpec(diameter_mm=100, edge_exclusion_mm=60)
    with pytest.raises(ValueError):
        WaferSpec(diameter_mm=100, edge_exclusion_mm=3, orientation=FlatSpec(length_mm=120))
    with pytest.raises(ValueError):
        layout_wafer(WaferSpec(diameter_mm=200, edge_exclusion_mm=3), die(30000, 30000), ReticleSpec())


def test_reticle_fields_and_test_sites():
    d = die(3000, 2000, 100)
    m = layout_wafer(WaferSpec(diameter_mm=200, edge_exclusion_mm=3), d, ReticleSpec(test_site_slots=[(0, 0)]))
    nx, ny = m.dies_per_field
    assert nx == math.floor((26 + 0.1) / 3.1) and ny == math.floor((33 + 0.1) / 2.1)
    assert m.count(SiteClass.VALID_TEST_SITE) > 0
    assert np.all(m.slot_x[m.cls == SiteClass.VALID_TEST_SITE] == 0)
    full_only = layout_wafer(WaferSpec(diameter_mm=200, edge_exclusion_mm=3), d, ReticleSpec(stepping="full_fields_only"))
    assert full_only.count(SiteClass.UNPRINTABLE) > 0
    assert full_only.n_full < m.n_full + m.count(SiteClass.VALID_TEST_SITE)


def test_exclusion_zone_marks_unprintable():
    zone = ExclusionZone(name="laser_mark", polygon_mm=[(-10, 80), (10, 80), (10, 95), (-10, 95)])
    m = layout_wafer(WaferSpec(diameter_mm=200, edge_exclusion_mm=3, exclusion_zones=[zone]), die(2000, 2000, 50))
    un = m.cls == SiteClass.UNPRINTABLE
    assert un.sum() > 0
    assert np.all(shapely.intersects(shapely.box(m.fx0[un], m.fy0[un], m.fx1[un], m.fy1[un]),
                                     shapely.Polygon(zone.polygon_mm)))


def test_rotation_swaps_pitch():
    a = layout_wafer(WaferSpec(diameter_mm=150, edge_exclusion_mm=3), die(4000, 1500, 60, 0))
    b = layout_wafer(WaferSpec(diameter_mm=150, edge_exclusion_mm=3), die(4000, 1500, 60, 90))
    assert a.pitch_mm == pytest.approx(b.pitch_mm[::-1])
    assert a.n_full == b.n_full          # a disc without notch/flat is rotation invariant (die-centred grid)


@settings(max_examples=40, deadline=None)
@given(w=st.floats(500, 12000), h=st.floats(500, 12000), s=st.floats(0, 200), e=st.floats(0, 8),
       ox=st.floats(-5, 5), oy=st.floats(-5, 5))
def test_property_full_dies_inside_and_counts_consistent(w, h, s, e, ox, oy):
    """Property: FULL dies always inside R - e; class counts add up; usable area bounds the die area."""
    wafer = WaferSpec(diameter_mm=150, edge_exclusion_mm=e)
    m = layout_wafer(wafer, die(w, h, s), None, LayoutSpec(offset_x_mm=ox, offset_y_mm=oy, grid_origin="explicit"))
    g = m.geometry
    full = m.cls == SiteClass.FULL_DIE
    for cx, cy in ((m.fx0, m.fy0), (m.fx1, m.fy0), (m.fx0, m.fy1), (m.fx1, m.fy1)):
        assert np.all(np.hypot(cx[full], cy[full]) <= g.R - g.e + 1e-9)
    assert sum(m.counts().values()) == m.n_sites
    assert m.n_full * (w * h / 1e6) <= math.pi * (g.R - g.e) ** 2 + 1e-6
    # no two footprints overlap: centres differ by at least one pitch
    assert len(set(zip(m.ix.tolist(), m.iy.tolist()))) == m.n_sites


def test_edge_distance_positive_for_full_dies():
    m = layout_wafer(WaferSpec(diameter_mm=200, edge_exclusion_mm=3,
                               orientation=NotchSpec(depth_mm=1, angle_deg=90)), die())
    assert np.all(m.edge_dist[m.eligible] >= 3 - 1e-6)
    assert np.all(m.edge_dist[m.cls == SiteClass.PARTIAL] < 1e-9)
