"""Gross die: geometry count vs independent references (TEST I) and approximations."""
import itertools
import math

import pytest

from yieldlab import gross_die
from yieldlab.die_layout import DieSpec, LayoutSpec, layout_wafer
from yieldlab.provenance import Source
from yieldlab.wafer_geometry import WaferSpec


def brute_force(R, w, h, sx, sy, ox, oy, footprint="die_plus_half_street"):
    """Independent reference: enumerate grid cells, test 4 corners of the footprint against the disc."""
    px, py = (w + sx), (h + sy)
    mx, my = (sx / 2, sy / 2) if footprint == "die_plus_half_street" else (0, 0)
    n = 0
    k = int(R / min(px, py)) + 3
    for i, j in itertools.product(range(-k, k + 1), repeat=2):
        cx, cy = ox + i * px, oy + j * py
        corners = [(cx + a * (w / 2 + mx), cy + b * (h / 2 + my)) for a in (-1, 1) for b in (-1, 1)]
        if all(x * x + y * y <= R * R for x, y in corners):
            n += 1
    return n


@pytest.mark.parametrize("w,h,s,e,ox,oy", [(5, 5, 0.1, 3, 0, 0), (3.5, 2.3, 0.08, 3, 0.4, -0.7),
                                          (10, 7, 0.1, 5, 1.0, 2.0), (1, 1, 0, 0, 0.5, 0.5)])
def test_I_matches_brute_force_small_cases(w, h, s, e, ox, oy):
    """TEST I: geometry count equals an independent brute-force reference."""
    d = DieSpec(name="t", width_um=w * 1000, height_um=h * 1000, source=Source.HYPOTHETICAL, reference="t",
                scribe_x_um=s * 1000, scribe_y_um=s * 1000)
    m = layout_wafer(WaferSpec(diameter_mm=100, edge_exclusion_mm=e), d, None,
                     LayoutSpec(offset_x_mm=ox, offset_y_mm=oy, grid_origin="explicit"))
    assert m.n_full == brute_force(50 - e, w, h, s, s, ox, oy)


def test_tiny_case_by_hand():
    # 100 mm wafer, 0 exclusion, 50 x 50 mm die without scribe centred: corners at (+-25, +-25) -> r = 35.4 < 50
    # neighbours at x = +-50 have far corners at 79 > 50 -> exactly 1 die.  Street-centred grid: dies at
    # (+-25, +-25) reach the corner (50, 50), r = 70.7 > 50 -> 0 dies (grid translation matters)
    d = DieSpec(name="t", width_um=50000, height_um=50000, source=Source.HYPOTHETICAL, reference="t",
                scribe_x_um=0, scribe_y_um=0)
    assert layout_wafer(WaferSpec(diameter_mm=100, edge_exclusion_mm=0), d).n_full == 1
    assert layout_wafer(WaferSpec(diameter_mm=100, edge_exclusion_mm=0), d, None,
                        LayoutSpec(grid_origin="street_centred")).n_full == 0


def test_approximations_reported_not_equal_and_bounds_hold():
    d = DieSpec(name="t", width_um=3494.88 + 600, height_um=2279.34 + 600, source=Source.HYPOTHETICAL, reference="t",
                scribe_x_um=80, scribe_y_um=80)
    m = layout_wafer(WaferSpec(diameter_mm=200, edge_exclusion_mm=3), d)
    rows = gross_die.compare(m.n_full, 97.0, d, m.fx1[0] - m.fx0[0], m.fy1[0] - m.fy0[0])
    by = {r["method"]: r for r in rows}
    assert by["area_ratio"]["value"] >= m.n_full                 # upper bound
    assert by["row_chord"]["value"] >= m.n_full                  # row alignment freedom -> upper bound
    assert abs(by["edge_corrected"]["relative_difference"]) < 0.1
    for r in rows:
        assert r["difference"] == pytest.approx(r["value"] - m.n_full)


def test_area_accounting_adds_up():
    d = DieSpec(name="t", width_um=4000, height_um=3000, source=Source.HYPOTHETICAL, reference="t",
                scribe_x_um=100, scribe_y_um=100)
    m = layout_wafer(WaferSpec(diameter_mm=200, edge_exclusion_mm=3), d)
    g = m.geometry
    acc = gross_die.area_accounting(m, g.wafer_area_mm2(), g.usable_area_mm2())
    total = (acc["edge_exclusion_and_notch_area_mm2"] + acc["eligible_die_silicon_area_mm2"]
             + acc["eligible_die_street_area_mm2"] + acc["test_site_area_mm2"] + acc["usable_area_not_in_full_sites_mm2"])
    assert total == pytest.approx(acc["wafer_area_mm2"], rel=1e-9)
    assert 0 < acc["geometric_loss_fraction"] < 1
