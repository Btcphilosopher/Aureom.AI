"""Spatial generators: valid locations (TEST G), intensities, clustering, reproducibility."""
import math

import numpy as np
import pytest

from yieldlab.die_layout import DieSpec, ReticleSpec, layout_wafer
from yieldlab.provenance import Source
from yieldlab.random_fields import GaussianField
from yieldlab.spatial_defects import (Cluster, DefectGenerator, DefectModel, Edge, LGCP, Radial, ReticleRepeat, Ring,
                                      Scratch, SizeDist, Uniform, WaferVariation)
from yieldlab.wafer_geometry import NotchSpec, WaferGeometry, WaferSpec
from yieldlab.config import load_scenario
import shapely

GEO = WaferGeometry(WaferSpec(diameter_mm=200, edge_exclusion_mm=3, orientation=NotchSpec(depth_mm=1, angle_deg=90)))
DIE = DieSpec(name="t", width_um=4000, height_um=3000, source=Source.HYPOTHETICAL, reference="t",
              scribe_x_um=100, scribe_y_um=100)
WM = layout_wafer(GEO, DIE, ReticleSpec())


def gen(*comps, variation=None):
    return DefectGenerator(DefectModel(name="t", components=list(comps), variation=variation or WaferVariation()),
                           GEO, WM)


def test_G_every_defect_on_the_wafer(rng):
    """TEST G: every simulated defect has a valid location on the physical wafer."""
    g = gen(Uniform(density_per_cm2=0.5), Radial(centre_density_per_cm2=0.2, a=2), Edge(edge_density_per_cm2=2,
            decay_mm=3), Cluster(parent_density_per_cm2=0.05, mean_offspring=8, sigma_mm=4),
            LGCP(mean_density_per_cm2=0.2, log_sigma=1, corr_length_mm=10), Ring(peak_density_per_cm2=1,
            radius_mm=60, width_mm=3), ReticleRepeat(positions_in_field_mm=[(1.0, 1.0)]),
            Scratch(rate_per_wafer=3, length_mm=(20, 80), curvature_radius_mm=100))
    wp = GEO.wafer_polygon()
    for _ in range(5):
        ds = g.generate(rng)
        assert np.all(np.isfinite(ds.x)) and np.all(np.isfinite(ds.y))
        assert np.all(np.hypot(ds.x, ds.y) <= GEO.R + 1e-9)
        assert not shapely.contains_xy(GEO.notch_triangle(), ds.x, ds.y).any()
        for e in ds.extended:
            assert wp.buffer(1e-6).contains(e["geom"])
        assert np.all(ds.size_um > 0)


def test_uniform_intensity_matches_density(rng):
    d0 = 1.0
    g = gen(Uniform(density_per_cm2=d0))
    counts = [g.generate(rng).n_points for _ in range(200)]
    expected = d0 * GEO.wafer_area_mm2() / 100.0
    assert np.mean(counts) == pytest.approx(expected, rel=0.01)
    assert np.var(counts) == pytest.approx(expected, rel=0.25)       # Poisson: var = mean


def test_cluster_process_is_overdispersed(rng):
    g = gen(Cluster(parent_density_per_cm2=0.05, mean_offspring=10, sigma_mm=3))
    counts = np.array([g.generate(rng).n_points for _ in range(200)])
    assert counts.var() > 3 * counts.mean()
    ds = g.generate(rng)
    assert ds.cluster.min() >= 0


def test_radial_and_edge_profiles(rng):
    gr = gen(Radial(centre_density_per_cm2=0.5, a=4, p=2))
    ge = gen(Edge(edge_density_per_cm2=5, decay_mm=3))
    sets = [gr.generate(rng) for _ in range(20)]
    xs = np.concatenate([d.x for d in sets])
    ys = np.concatenate([d.y for d in sets])
    r = np.hypot(xs, ys)
    inner = (r < 50).sum() / (math.pi * 50**2)
    outer = ((r > 80) & (r < 100)).sum() / (math.pi * (100**2 - 80**2))
    assert outer > 2.5 * inner
    de = ge.generate(rng)
    assert np.median(GEO.R - np.hypot(de.x, de.y)) < 5


def test_ring_concentrated(rng):
    ds = gen(Ring(peak_density_per_cm2=3, radius_mm=60, width_mm=2)).generate(rng)
    r = np.hypot(ds.x, ds.y)
    assert np.mean(np.abs(r - 60) < 6) > 0.9


def test_reticle_repeat_same_within_field_position(rng):
    ds = gen(ReticleRepeat(positions_in_field_mm=[(2.0, 3.0)], print_probability=1.0)).generate(rng)
    nfx, nfy = WM.dies_per_field
    fx = (nfx * WM.pitch_mm[0])
    fy = (nfy * WM.pitch_mm[1])
    u = np.mod(ds.x - (WM.offset_mm[0] - WM.pitch_mm[0] / 2), fx)
    v = np.mod(ds.y - (WM.offset_mm[1] - WM.pitch_mm[1] / 2), fy)
    assert np.allclose(u, 2.0) and np.allclose(v, 3.0)
    assert ds.n_points >= 10


def test_gaussian_field_unit_variance_and_correlation(rng):
    f = GaussianField(100, 10.0, rng)
    x = rng.uniform(-80, 80, 4000)
    y = rng.uniform(-80, 80, 4000)
    z = f(x, y)
    assert abs(z.mean()) < 0.35 and 0.6 < z.var() < 1.4
    zz = f(x + 10.0, y)                      # C(10) = exp(-1) ~ 0.37
    rho = np.corrcoef(z, zz)[0, 1]
    assert 0.15 < rho < 0.6
    far = f(x + 60, y)
    assert abs(np.corrcoef(z, far)[0, 1]) < 0.2


def test_lot_and_wafer_multipliers_mean_one(rng):
    v = WaferVariation(alpha_lot=4, alpha_wafer=6)
    lots = [v.lot_multiplier(rng) for _ in range(20000)]
    assert np.mean(lots) == pytest.approx(1.0, abs=0.02)
    assert np.var(lots) == pytest.approx(1 / 4, rel=0.08)


def test_size_distribution_power_law(rng):
    s = SizeDist(x0_um=0.1, power=3, max_um=1e6).sample(200000, rng)
    assert s.min() >= 0.1
    # P(X > 0.2) = (0.1/0.2)^2 = 0.25
    assert np.mean(s > 0.2) == pytest.approx(0.25, abs=0.005)


def test_reticle_repeat_requires_fields():
    wm = layout_wafer(GEO, DIE, ReticleSpec(enabled=False))
    with pytest.raises(ValueError):
        DefectGenerator(DefectModel(name="t", components=[ReticleRepeat(positions_in_field_mm=[(1, 1)])]), GEO, wm)
