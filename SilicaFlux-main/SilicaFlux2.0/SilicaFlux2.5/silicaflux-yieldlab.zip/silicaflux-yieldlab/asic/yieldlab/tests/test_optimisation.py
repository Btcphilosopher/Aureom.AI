"""Optimisation: candidates, constraints, Pareto front; chiplet module."""
import numpy as np
import pytest

from yieldlab import chiplets as ch
from yieldlab.optimisation import (architecture_variants, constraints, evaluate, floorplan_run_candidates,
                                   pareto_front)
from yieldlab.wafer_geometry import WaferSpec


def test_floorplan_candidates_are_measured_and_keep_failures():
    c = floorplan_run_candidates()
    names = {x.name for x in c}
    assert "FLP:C_sram_near_compute" in names and "FLP:SA_00" in names
    sa00 = next(x for x in c if x.name == "FLP:SA_00")
    assert not sa00.physically_valid
    cc = next(x for x in c if x.name == "FLP:C_sram_near_compute")
    assert cc.die_w_um == pytest.approx(3494.88) and cc.die_h_um == pytest.approx(2279.34)


def test_variants_are_estimates_and_flagged():
    v = architecture_variants()
    for c in v:
        assert c.evidence == "ESTIMATE" and not c.rtl_exists
        assert c.die_w_um == pytest.approx(3494.88)          # width set by SRAM macros: unchanged
    t = next(c for c in v if c.name == "VAR:tensor_2x2")
    assert 2000 < t.die_h_um < 2279.34
    s = next(c for c in v if c.name == "VAR:sram_64KiB")
    # NOT proportional: halving SRAM (4.53 -> ~2.5 mm^2 of macros) removes far less than half the die
    assert s.die_h_um > 0.6 * 2279.34


def test_constraints_and_pareto():
    rows = evaluate(floorplan_run_candidates() + architecture_variants(),
                    WaferSpec(diameter_mm=200, edge_exclusion_mm=3), 300, 80, [0.5], 3.0, 2500.0, 0.5)
    for r in rows:
        v = constraints(r)
        if r["evidence"] == "ESTIMATE":
            assert any("re-run" in x for x in v)
        if r["candidate"] == "FLP:B_core_area_plus":
            assert any("timing" in x for x in v)
    strict = [r for r in rows if not constraints(r, strict_routability=True)]
    assert strict == []                       # no SilicaFlux-V placement is overflow-free AND timing-clean
    feas = [r for r in rows if not constraints(r)]
    idx = pareto_front(feas, {"good_die_nb": "max", "die_area_mm2": "min"})
    assert len(idx) >= 1
    for i in idx:
        for j, r in enumerate(feas):
            assert not (r["good_die_nb"] > feas[i]["good_die_nb"] and r["die_area_mm2"] < feas[i]["die_area_mm2"])


def test_chiplet_package_yield_formula():
    chips = [ch.ChipletType(name="compute", area_mm2=4, count=1, pretested=True, test_escape_fraction=0.01),
             ch.ChipletType(name="mem", area_mm2=5, count=2, pretested=False)]
    pkg = ch.PackageSpec(bond_yield_per_interface=0.999, n_interfaces=2, interposer_yield=0.98, assembly_yield=0.99,
                         final_test_coverage=0.9)
    r = ch.package_yield(chips, pkg, d0=0.5)
    y_mem = np.exp(-0.05 * 0.5)
    assert r["p_package_good"] == pytest.approx(0.99 * y_mem**2 * 0.999**2 * 0.98 * 0.99)
    mc = ch.simulate(chips, pkg, 0.5, 400000, np.random.default_rng(1))
    assert abs(mc["p_package_good_mc"] - r["p_package_good"]) < 5 * mc["mcse"]
    # correlated (shared lot intensity) untested chiplets: P(all good) above the independent product (Jensen)
    mc_c = ch.simulate(chips, pkg, 0.5, 400000, np.random.default_rng(2), lot_alpha=0.5, packages_per_lot=50)
    assert mc_c["p_package_good_mc"] > r["p_package_good"]
