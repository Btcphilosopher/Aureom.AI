# Final answers

Source of every number: the recorded runs in `reports/` (seeded, re-run verified bit-for-bit) and `reports/studies/`.
Main run: `sfv_baseline_200mm__seed42__40x25__a9658295de` = SilicaFlux-V, 1000 wafers (40 lots x 25), seed 42.
**All yields and costs are SIMULATED - HYPOTHETICAL SCENARIO**: no defect density, clustering, parametric, packaging or
price input is measured. They show how the design responds to the assumptions, not what a foundry would deliver.

**1. Actual SilicaFlux-V die dimensions?** Known only from FloorplanLab placements of netlist `14a43bb27555` on IHP SG13G2
(pre-CTS, preliminary global route, **no pad ring**): C_sram_near_compute **3494.88 x 2279.34 um = 7.966 mm^2** (FloorplanLab's
recommended trade-off, used as baseline), A_baseline 2819.04 x 2823.66 um = 7.960 mm^2; completed runs span 7.438-10.379 mm^2.
With the 0.3 mm/side wire-bond ring from the SilicaFlux-V `[E]` estimate the yield die is 4094.88 x 2879.34 um = 11.79 mm^2.
Neither is a final die: overflow > 0, slow-corner timing not closed, pads not placed.

**2. How many valid die footprints fit?** 200 mm wafer, 3 mm exclusion, SEMI M1 notch, 80 um streets, die-centred grid,
die + half-street footprint (all HYPOTHETICAL process choices): **2 280 FULL DIE sites** (233 partial, 156 edge-excluded;
6 x 11 dies per 26 x 33 mm field). The best grid translation gives 2 287 (+7). 300 mm: 5 318 (best 5 335). Textbook
approximation 2 269.9 (-0.44 %), area ratio 2 392.5 (+4.9 %), row-chord bound 2 320. 14.4 % of the 200 mm wafer area is not
eligible die silicon. MCU-I (planning-estimate 12.7 mm^2): 2 128.

**3. Area assumptions.** Die 11.79 mm^2 = measured 7.966 mm^2 + estimated ring; regions from the OpenDB export: SRAM macros
4.533 mm^2 (exact), std-cell logic 1.109 mm^2 (exact cell area; spatial attribution via density grid), pad ring 3.825 mm^2
(estimate), whitespace/routing 2.324 mm^2 (derived). Baseline effective defect-sensitive area = the whole die (simplified
`all_fatal`); region/class and critical-area fatality modes are available but use hypothetical parameters (no critical-area
extraction exists).

**4. Defect densities?** **None measured.** Baseline hypothetical mixture: uniform 0.18 /cm^2, Thomas clusters (0.01 parents
/cm^2 x 4), edge term 1.5 /cm^2 e^{-(R-r)/4 mm}, 0.15 scratches / wafer, lot alpha 8, wafer alpha 6, 2 % excursions x 4.
Resulting Poisson-equivalent fatal D0 on eligible dies: 0.276 /cm^2. Sweeps cover 0.05-2 /cm^2.

**5. Yield by statistical model.** At A = 0.1179 cm^2 and D0 = 0.276 the models agree to < 0.1 point (Poisson 0.9680,
NB(alpha 6) 0.9681, Murphy 0.9681, Seeds 0.9685), each matched by its Monte Carlo counterpart. They separate at high A D0:
D0 = 2 -> Poisson 0.790, Murphy 0.794, Seeds 0.809, NB(alpha 0.5) 0.824. For a die this small the model choice moves the
*mean* little but changes the *spread*: with the same mean, wafer-level gamma (alpha 2) doubles the sd of good dies per
wafer (49.8 vs 25.0, experiment B). Which model is right needs measured dispersion.

**6. Variability across wafers.** True good dies per wafer: mean 2 186, sd 83, P5 2 055, P50 2 207, P95 2 255. Wafer
defect-limited-yield sd 0.022 vs 0.0037 if dies were independent; ICC(lot) 0.37, design effect 9.9.

**7. Yield loss per mechanism (mean dies / wafer).** Geometry: 389 of 2 669 sites. Random defects: 72.9 (3.2 % of eligible;
by region SRAM main 1.15 %, pad ring 1.13 %, routing/whitespace 0.71 %, tile scratchpad 0.19 %, vector 0.13 %, tensor 0.12 %,
CPU 0.06 %, rest < 0.06 % each). Parametric-only (hypothetical): 17.9 (heavy-tailed: lot effects). Good dies rejected at probe:
3.2. Packaging (assumed 0.99) + final test: 2 186 -> 2 164 delivered conforming.

**8. Synthetic or imported patterns?** All synthetic. No measured wafer map, bin map or inspection file exists; the import
path is implemented and a synthetic fixture can never be labelled VERIFIED IMPORTED DATA.

**9. Effect of SRAM redundancy?** **None on real yield**: SilicaFlux-V has no spare rows/columns, no fuses, CAPS.REPAIR = 0,
no ECC. Paired experiment E: true good dies unchanged (diff 0, CI [0, 0]). If 4+4 spare rows/columns existed, 22.9 dies/wafer
(~1.0 % of eligible) would be repairable - CONDITIONAL, area overhead not yet charged; SECDED would cover 19.0/wafer.

**10. What TestCore detects / misses.** Proxy evidence (TestCore r2 RTL fault injection, synthetic population): March C-
bit faults 93.3 %, row / column / decoder / periphery 100 %, retention 0 %. Using MATS+ instead adds 2.15 escapes/wafer
(CI [1.73, 2.57], experiment F). Logic: scan/ATPG NOT AVAILABLE for SilicaFlux-V; functional coverage hypothetical.
Escapes: 11.5/wafer at probe (0.54 % of passing dies), 9.8 delivered (~4 500 DPPM); most come from regions without
evidence-based coverage (routing/whitespace, pad ring, logic).

**11. Simulated delivered good dies.** 2 164 delivered conforming per wafer (90 % PI next wafer 2 028-2 232); next 25-wafer lot
52 732-55 270; 2.16 million over the 1 000 simulated wafers.

**12. Expected cost per good die.** With illustrative HYPOTHETICAL prices (no quote exists): **2.21 EUR per delivered
conforming die** incl. NRE spread over 500 k units (recurring 2.11; wafer + probe only 1.20 per true good die); per-wafer
90 % PI of recurring cost 2.07-2.21. Wafer price dominates (+/-25 % -> 1.92-2.50). MPW prototypes ~1 370-1 390 EUR per good
prototype; first-silicon program 0.53-0.87 M EUR -> 13.8-22.6 k EUR per usable prototype for 0-2 re-spins. These are cost
structures, not budgets; the quote template is refused until real quotes are entered.

**13. Confidence and predictive intervals.** Mean true good dies/wafer 2 186: 95 % CI 2 169-2 203 (lot-cluster t; bootstrap
2 168-2 201; the naive iid interval 2 181-2 191 is ~3x too narrow). 90 % PI next wafer 2 055-2 255. True-good yield 0.959
(CI 0.951-0.966, PI 0.901-0.989). Mean true good dies converged (relative MCSE 0.4 %); raw failure counts did not reach the
1 % criterion (5.0 %) and are flagged INSUFFICIENT (gate 13 WARN).

**14. Does reducing the tensor array help?** Barely, and it is not a feasible option today. Estimated 2x2-tensor die 11.08 vs
11.79 mm^2 (width fixed by four 784 um SRAM macros), 2 421 vs 2 281 gross dies (+6.1 %), -3.3 % cost per good die at D0 =
0.25 - but 75 % of peak MAC throughput is lost, no RTL or physical run exists, so it fails the mandatory constraints. The
tensor logic is only ~2.3 % of the yield die; SRAM and the pad ring dominate area, yield loss and cost.

**15. Best feasible die size?** No candidate passes the strict gate (zero overflow + non-negative routed timing): the only
overflow-free run (U_00) misses timing by 3.87 ns. Under the preliminary screen (overflow <= 5 000, GRT WNS >= 0) the feasible
set is A_baseline, C_sram_near_compute, R_00; A_baseline is non-dominated (2 304 vs 2 280 gross dies, ~1 % lower cost) while
FloorplanLab prefers C for its deterministic macro arrangement and routability trend. The ~1 % difference is smaller than the
change expected from closing the floorplan: pick C + the E corridors (FloorplanLab's next experiment), close routing, then
re-run YieldLab on the new `geometry.json`.

**16. Which node comparison is backed by foundry inputs?** **None.** Only IHP SG13G2 has a measured SilicaFlux-V die; the SKY130
die is measured but fails macro legality (37.4 mm^2 incl. ring -> 709 gross dies on 200 mm); 65 nm is a planning estimate
(~3.8 mm^2, pad-limited); 28 nm has nothing but a document-cited, unverified price. No node has a D0, wafer price or MPW quote,
so nodes are compared only on a common hypothetical D0 grid and never ranked on cost.

**17. Missing manufacturing data.** See `MISSING_FOUNDRY_PARAMETERS.md` (20 items): process / foundry choice, wafer and reticle
rules, scribe, pad library, D0 and clustering, critical-area extraction, SRAM failure modes and redundancy, scan/ATPG coverage,
statistical process data, product specs, all prices, assembly yield, any measured wafer data.

**18. Decisions before SilicaFlux-V tapeout.**
1. Foundry route (IHP SG13G2 open PDK vs a commercial 130 nm NDA PDK) and MPW vs dedicated run.
2. Close the floorplan: C + E corridors, zero overflow, CTS, detailed route, slow-corner timing, DRC/LVS.
3. Pad ring / package (the ring is a third of the yield die today).
4. SRAM strategy: keep no-repair, or buy a redundancy-capable compiler / add SECDED - decide with the area overhead and, ideally,
   first-silicon bitmaps (MBIST incl. RETENTION).
5. DFT: scan insertion + production ATPG on SilicaFlux-V (TestCore r2 path) so logic escapes stop being hypothetical.
6. Product specification: speed grades, leakage limit, what is sellable (bins 2 / 3 stay inactive until defined).
7. Test structures (PCM / defect monitors) in a reticle slot and a wafer-map data plan, so calibration can replace the
   hypothetical defect model after first silicon.
