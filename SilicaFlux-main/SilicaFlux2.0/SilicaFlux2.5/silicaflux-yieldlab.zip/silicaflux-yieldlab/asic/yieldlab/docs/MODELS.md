# YieldLab models, conventions and stated assumptions

Units: wafer coordinates mm (centre at 0,0); die-internal coordinates um; areas for yield in cm^2; densities per cm^2
(`units.py` is the only place with scale factors; a factor-100 mm^2/cm^2 slip is caught by `test_unit_conversions`).

## 1. Wafer geometry and site classification (`wafer_geometry.py`, `die_layout.py`)

* Wafer: disc of radius R; optional primary flat (chord of length L, wafer = disc AND {n.p >= -d}, d = sqrt(R^2 - L^2/4))
  or V-notch (depth, opening angle; SEMI M1 nominal 1.00 mm / 90 deg, applied only when configured).
* Usable area = erosion of the wafer by the edge exclusion e: disc(R - e) AND {n.p >= -d + e} MINUS (notch triangle
  dilated by e). Erosion of an intersection of convex sets is the intersection of the erosions; erosion of a difference
  removes the dilated cut-out - both exact.
* Containment is exact: a rectangle lies in a convex region iff its four corners do (analytic, vectorised); the notch
  and user exclusion zones are tested with Shapely (`intersection area > 0`), buffer arcs with 64 segments per quarter
  circle (radial error <= e (1 - cos(pi/256)) = 0.23 um at e = 3 mm). Agreement with an independent Shapely
  `contains` reference is tested site-by-site (`test_classification_matches_shapely_reference`).
* Grid: die pitch = die + street; grid origin die-centred, street-centred or explicit; die rotation 0/90 deg.
* Reticle: dies per field = largest n with n dies + (n - 1) streets <= field limit; field phase configurable; stepping
  policy `all_intersecting` | `fields_with_full_die` | `full_fields_only`; test-structure slots per field.
* Required footprint: `die`, `die_plus_half_street` (default, the step cell owned by the die) or `die_plus_full_street`.
* Class order: UNPRINTABLE (field not exposed or exclusion zone) -> PARTIAL (footprint not entirely on the physical
  wafer) -> EDGE-EXCLUDED (on wafer but touches the edge band / notch keep-out) -> VALID TEST SITE -> FULL DIE.
  **Only FULL DIE sites are eligible for yield.** Positions not touching the wafer are not sites.

## 2. Gross die (`gross_die.py`)

Authoritative = geometry count. Approximations reported with their difference: area ratio pi R_u^2 / S (upper bound),
textbook edge-corrected pi d^2/(4S) - pi d / sqrt(2S), and a row-chord count (upper bound for a disc because each row may
choose its own x alignment). Area accounting splits the wafer into edge band + notch, eligible die silicon, streets,
test sites and usable area outside full sites (sums to the wafer area, tested).

## 3. Yield models (`yield_models.py`)

Y = integral exp(-A D) f(D) dD with A = effective defect-sensitive area (cm^2), D0 = mean fatal-defect density:

| model | f(D) | Y |
|---|---|---|
| Poisson | delta(D - D0) | exp(-A D0) |
| negative binomial | Gamma(shape alpha, scale D0/alpha) | (1 + A D0/alpha)^(-alpha) |
| Seeds | exponential (NB alpha = 1) | 1/(1 + A D0) |
| Murphy | triangular on [0, 2 D0], mode D0 | ((1 - e^{-A D0}) / (A D0))^2 |
| Murphy (uniform) | uniform on [0, 2 D0] | (1 - e^{-2 A D0}) / (2 A D0) |

Murphy derivation (triangle): integral_0^{D0} (D/D0^2) e^{-AD} dD + integral_{D0}^{2D0} ((2D0 - D)/D0^2) e^{-AD} dD
= (1 - e^{-A D0})^2 / (A D0)^2. Evaluated as (-expm1(-x)/x)^2 with the series 1 - x/2 + x^2/6 below x = 1e-6, so
Y -> 1 smoothly (tested to x = 1e-14). NB: lambda ~ Gamma(alpha, D0/alpha), N | lambda ~ Poisson(lambda A):
E[lambda] = D0, Var[lambda] = D0^2/alpha, E[N] = mu = A D0, Var[N] = mu + mu^2/alpha, P(N = 0) = (1 + mu/alpha)^-alpha,
alpha -> infinity gives Poisson (exactly at alpha = inf). Independent Monte Carlo counterparts sample the latent
density per die then the count (tests D, E, F). **No model is declared universally best**; selection needs measured
dispersion (`calibration.py`). The "empirical" model is NOT AVAILABLE until verified wafer data are imported.

*Level of intensity variation.* The same NB marginal arises when lambda varies between dies, wafers, lots or regions,
but the correlation between dies differs. YieldLab's analytical NB is die-level; the spatial engine puts gamma
multipliers at wafer and lot level (`WaferVariation`) and uses explicit cluster processes / correlated fields for
within-wafer clustering. Independent per-die NB samples are never called a spatially clustered wafer model.

## 4. Spatial defect generators (`spatial_defects.py`, `random_fields.py`)

All are point processes on the physical wafer (points in the notch / beyond a flat are rejected, so the process is the
restriction to the wafer). Intensities in /cm^2:
A uniform HPPP; B radial D (1 + a (r/R)^p) by thinning; C edge D_e exp(-(R - r)/L); D Thomas cluster process (parents
PPP(kappa) on the disc dilated by 4 sigma, Poisson(mu) offspring, N(0, sigma^2 I) displacement; mean intensity kappa mu);
D' LGCP D exp(s Z - s^2/2) with Z a unit-variance Gaussian field of squared-exponential covariance exp(-h^2/l^2) (FFT
filtering of white noise with kernel sd l/2, 4 l padding, renormalised; variance and correlation tested); E scratches
(Poisson count, uniform start / direction, U(Lmin, Lmax) length, optional circular arc, width w, clipped to the wafer);
F ring D_r exp(-(r - r0)^2/(2 w^2)); G reticle-repeat (fixed within-field coordinates, printed per exposed field with
probability p); H wafer excursion (probability p, intensity x factor); I lot / wafer gamma multipliers of mean 1.
Size: inverse power law f(x) ~ x^-p for x >= x0 (truncated), tested P(X > 2 x0) = 2^-(p-1).

## 5. Defect -> die -> region, fatality (`defect_mapping.py`, `regions.py`, `fatality.py`)

* Discs hit a die when they overlap the **die rectangle** (street hits are not die hits); a large disc can hit up to four
  dies. Extended defects use an STR-tree + exact `intersects`, then are sampled along the path / over the area so every
  region crossed is seen. One extended defect = one defect event per die. Failed dies are counted once.
* Regions: pad ring (planning estimate), 12 SRAM macros (exact OpenDB boxes), logic groups via the FloorplanLab density
  grid (P(cells) = std-cell area / non-macro bin area; split between groups whose placement extent covers the bin,
  weighted by cell area / extent area), whitespace. Located areas sum exactly to the die area (tested); the logic
  attribution is an approximation and its located area is reported next to the exact OpenDB cell area.
* Fatality modes: `all_fatal` (baseline; density = fatal D0), `class_kill`, `region_class`, `critical_area`
  (parallel-wire short/open model with HYPOTHETICAL (w, s, rho)). Inspection particles are never treated as fatal
  defects unless the model says so (`density_kind`).

## 6. SRAM faults and repair (`memory_repair.py`)

Fault-type mixture (HYPOTHETICAL), array coordinates from the defect position and the macro organisation (IHP name:
2048x64_c2 -> 1024 rows x 128 columns). Schemes: none, rows, cols, rows_cols (exact small-case BIRA: must-repair one
decision at a time, then exhaustive allocation), SECDED ECC per (row, column-mux select) codeword (row / decoder /
periphery never correctable), bank disable (reduced-capacity product only). Any scheme other than `none` needs evidence of
hardware, configuration storage, BIRA/firmware, validation (and product spec for capacity binning); without it, repaired
dies are CONDITIONAL and never true good dies (TEST P).

## 7. Test, binning, parametric (`test_model.py`, `binning.py`, `parametric.py`)

Fault population = fatal, unrepaired faults with (region, fault type). Step coverage looked up most-specific first;
NOT_AVAILABLE coverage aborts the run. Independence of detection between faults is an assumption. Stop-on-fail order,
false rejects, explicit retest policy (real faults fail every retest). Parametric steps compare measured = true + gauge
noise to the spec. Final classes UNTESTED / TRUE_GOOD_PASS / CONDITIONAL_GOOD_PASS / GOOD_REJECTED / DEFECTIVE_DETECTED /
DEFECTIVE_ESCAPED partition the eligible dies (TEST L). Bins: declarative conditions, priority order, capability-gated
bins, mandatory fallback that must stay empty. Parametric: v = m + L_lot + W_wafer + c (r/R)^p + S(x,y) + T(slot) + e_die
with correlated die terms; T is drawn once per run. HYPOTHETICAL until calibrated; a die with a functional failure is a
functional failure first (no double counting of parametric loss).

## 8. Monte Carlo and random numbers (`monte_carlo.py`)

`SeedSequence(seed, spawn_key=(lot, wafer, stream))`, PCG64, one stream per mechanism (defects, locate, fatal, sram,
test, parametric, packaging) and a lot stream `(lot, 10^6)`. Results depend only on (scenario, seed, lot, wafer):
identical for 1 or N worker processes (TEST M). Test-detection uniforms are drawn for every fault, active or repaired,
so repair scenarios consume identical random numbers (common random numbers; found and fixed via TEST P). Memory is
bounded: per-wafer counts for all wafers, full maps only for `keep_maps` wafers.

## 9. Statistics (`statistics.py`)

CI for the expected value: lot-cluster t-interval on lot means + two-stage cluster bootstrap (lots, then wafers within
lots); the naive iid wafer interval is reported only beside ICC and design effect. PI: empirical quantiles of simulated
wafers / lot totals. P(target): Wilson interval. Convergence: batch-means MCSE; CONVERGED only if n >= 100 and relative
MCSE <= 1 %. Paired differences use the CRN pairing (same seed / lot / wafer / stream keys) with lot-cluster CIs.

## 10. Economics (`costs.py`)

Stage accounting FAB -> PROBE -> DICING -> PACKAGING (only probe-passing sellable dies) -> FINAL TEST -> SHIP + explicit
NRE list and amortisation rule. Cost per delivered **conforming** die excludes escapes (reported as DPPM quality risk).
MPW: shuttle fee for a tile on shared wafers, quoted samples, binomial spread of good prototypes - never mixed with
full-wafer economics. First silicon: program cost (engineering + runs + packaging + test + validation + re-spin effort)
per usable prototype for 0/1/2 re-spins; optional scenario weights are labelled ASSUMED. No cost item has a default.

## 11. Chiplets (`chiplets.py`) - research module

P(package good) = prod q_i^{n_i} y_bond^{n_b} y_interposer y_assembly with q_i = 1 - escape fraction (pretested) or die
yield (untested); independence stated; MC with an optional shared lot multiplier shows the effect of correlation.

## 12. Calibration (`calibration.py`)

Poisson D0 (MLE + Wilson), wafer-level gamma-Poisson (D0, alpha) by marginal likelihood with per-wafer 96-point
Gauss-Legendre quadrature centred on each wafer's binomial peak (matches adaptive quadrature to 1e-5, incl. tail wafers),
L-BFGS-B multistart + bounded Nelder-Mead polish, profile-likelihood CIs by root finding (empirical coverage 0.93 / 0.92
for alpha / D0 over 60 synthetic replications at nominal 0.95), chi-bar^2 LR test vs Poisson, Stapper window method,
holdout validation (PI coverage), Pearson GOF, variance components, learning curve refused with < 4 runs.
