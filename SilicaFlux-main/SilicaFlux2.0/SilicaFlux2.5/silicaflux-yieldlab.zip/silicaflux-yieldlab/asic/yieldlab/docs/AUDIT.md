# SilicaFlux repository audit (GATE 1)

Repository: `btcphilosopher/Aureom.AI`, branch `claude/silicaflux-yieldlab-simulator-oc8qrb` (HEAD `4ffed54`), audited 2026-11-06.
Nothing here is assumed from earlier briefs: every statement points to a file. The SilicaFlux projects live as
**nested zip archives** under `SilicaFlux-main/`; they were opened read-only. The machine-readable inventory is
`reports/audit/repository_audit.json` (regenerate: `make yieldlab-audit REPO=/path/to/Aureom.AI`); the evidence files
YieldLab consumes are vendored byte-for-byte in `third_party/` with SHA-256 and archive/member provenance
(`third_party/PROVENANCE.json`, check: `python scripts/intake.py --verify`).

## 1. File inventory (from `python -m yieldlab audit`)

| type | count | where |
|---|---|---|
| `.sv` SystemVerilog | 1 030 (incl. vendored duplicates across projects) | 45 archives |
| `.sf` | 33 loose (`SilicaFlux-main/*.sf`, `SilicaFlux2.0/SilicaFlux2.5/*.sf`) + 57 inside archives | |
| `.svh` | 80 | |
| `.v` | 13 (generated netlists / harnesses) | |
| `.sfx` SilicaFlux assembly | 4 loose + 16 in archives | |
| **GDSII / OASIS** | **0** | none anywhere |
| **OpenDB `.odb`** | **0** | FloorplanLab keeps `results/` out of version control; only its JSON exports are packaged |
| DEF | 1 | `SilicaFlux ThermalLab (1).zip` -> `asic/thermallab/examples/def_demo/top.def` - a 5-component synthetic demo, not SilicaFlux |
| LEF / Liberty | 1 / 1 | SKY130 std-cell views vendored in TestCore r2 `third_party/pdk` |

**Meaning of `.sf`:** plain SystemVerilog source with a SilicaFlux file extension (headers say
`Language : Silica Flux-2017`; content is ordinary `module ... endmodule`, e.g. `silicaflux_top.sf:29 module silicaflux_top`).
**`.sfx`** is SilicaFlux assembly. **Source conversion tools found:** `SilicaFlux2.5/sfx_asm.py` (assembler: `.sfx` ->
`$readmemh`/bin/MIF/COE, and the normative ISA tables); `silicafluxai.zip` (`silicaflux-ai` YAML -> RTL generator);
`silicafluxbitcoinasic.zip` (IR -> SV emitter). No `.sf`-to-`.sv` converter is needed or exists.

## 2. Designs

| | SilicaFlux-V | MCU-I | Full SilicaFlux (2.x / 2.5) | Chiplets |
|---|---|---|---|---|
| source | `SilicaFlux-main/silicaflux-v-release1.zip` (`silicaflux-v/rtl/top/sfv_soc.sv`); physical top `sfv_soc_df` from `silicaflux-datafabric.zip` (`rtl/soc/sfv_soc_df.sv`) | `SilicaFlux2.5/silicaflux-mcu-i.zip` (`rtl/`, top `mcu_top`) | `SilicaFlux2.5/silicaflux_top.sf` + `silicaflux_rtl*.zip` | none |
| top-level module | `sfv_soc` / `sfv_soc_df` | `mcu_top` | `silicaflux_top` | - |
| architecture | RV32I_Zicsr CPU, 4-lane vector engine, 4x4 INT8 tensor engine, 16 KiB tile scratchpad, 128 KiB SRAM (4 banks), 4 KiB boot ROM, SFB2 crossbar + DMA, UART/SPI/GPIO/timer/INTC, JTAG + SBA, March C- MBIST (README) | RV32I(M)_Zicsr MCU, 64 / 128 KiB SRAM (parity in INDUSTRIAL), DMA, DSP/MAC (README) | multi-core compute cluster, NoC, behavioural memories | - |
| RTL status | synthesis-ready; firmware boot verified in simulation; "NOT tape-out ready" (README) | passes simulation, formal, FPGA bitstreams; "not tape-out ready" (README) | TimingFlow: **BLOCKED** (Yosys parser) | - |
| synthesis | Yosys on IHP SG13G2: 95 096 cells, 4 512 FFs, std-cell 1.168 mm^2 (FloorplanLab RESULTS.md Q1); SKY130 0.561 mm^2 | Yosys on IHP / SKY130 / GF180 (MCU-I `docs/ASIC.md`): IHP INDUSTRIAL 0.658 mm^2 std cells + 6.183 mm^2 SRAM | not run (blocked) | - |
| physical design | **FloorplanLab**: 17 OpenROAD runs on IHP SG13G2, 14 placed + preliminary global route; pre-CTS, no detailed route, no DRC/LVS; GRT overflow > 0 in every run except U_00 | **none** (no placement / routing / STA) | not enabled: no SRAM macro mapping (FloorplanLab `configs/full_silicaflux/design.yaml`) | - |
| die dimensions | MEASURED per run, e.g. C_sram_near_compute **3494.88 x 2279.34 um = 7.966 mm^2**, A_baseline 2819.04 x 2823.66 um = 7.960 mm^2 (`ppa_table.csv`) - **without pad ring** | planning estimate only: ~5.9 mm^2 BASIC / ~12.7 mm^2 INDUSTRIAL "NOT a physical result" (`docs/ASIC.md`) | NOT AVAILABLE | NOT AVAILABLE |
| macro dimensions | 8 x `RM_IHPSG13_1P_2048x64_c2_bm_bist` 784.48 x 626.70 um; 4 x `RM_IHPSG13_1P_512x64_c2_bm_bist` 784.48 x 191.34 um; 4.533 mm^2 total (OpenDB export `geometry.json`) | 8 / 24 x `RM_IHPSG13_1P_4096x16_c3_bm_bist`, 257 609 um^2 each (Liberty area) | - | - |
| target technology | IHP SG13G2 130 nm (recommended first silicon, `PROCESS_NODE_COMPARISON.md`); SKY130 run fails GATE 6; commercial 130/65 are templates | IHP SG13G2 / SKY130 / GF180 (synthesis) | - | - |
| verification | lint, riscv-tests, SoC firmware sims, cocotb, SymbiYosys (README); TimingFlow SoC post-GRT slow-corner WNS **-7.388 ns** (not closed) | riscv-tests, cocotb, formal, FPGA build | - | - |
| unresolved dependencies | pad ring / I/O library / ESD / seal ring; CTS + detailed route; overflow-free floorplan; slow-corner timing; DRC/LVS; SRAM power; scan insertion + ATPG; foundry PDK for commercial nodes | everything physical; production SRAM compiler; pads | SRAM wrappers, parser fixes | - |

Stale statements found and corrected here: FloorplanLab (`configs/mcu_i/design.yaml`) and TimingFlow report
"MCU-I NOT FOUND"; MCU-I *does* exist now (`silicaflux-mcu-i.zip`), it simply has no physical design.

## 3. Supporting projects

| project | archive | status relevant to yield | used by YieldLab |
|---|---|---|---|
| FloorplanLab | `silicaflux-floorplanlab.zip` | measured die/core/macros/logic-group areas, density grid per run (`reports/runs/<id>/geometry.json`), PPA table incl. failed runs | **die outline, macro geometry, functional regions, candidate die sizes** |
| SRAM Wrapper Library | `silicaflux-sramlib.zip` | GENERIC / FPGA / ASIC backends; real IHP, SKY130, GF180 adapters; commercial adapters fail elaboration; **no ECC (planned P1), no redundancy** | macro organisation (from IHP names), repair = none |
| TestCore r1 | `silicaflux-testcore.zip` | JTAG/BSR, March MBIST, LBIST demo (85.46 % stuck-at on a demo ALU), host software, soft/hard bin proposal; **CAPS.REPAIR = 0**; scan/ATPG not run | bin proposal, MBIST fault-model notes, example host logs (SIMULATED sessions) |
| TestCore r2 (P07) | `silicaflux-testcore-p07.zip` | MBIST RTL fault injection: March C- **93.3 %** of a synthetic 2 376-fault population (MATS+ 76.8 %); OpenROAD scan on TestCore; in-house ATPG experiment 75.3 % fault / 91.6 % test coverage **on TestCore only**; no silicon; "no macro with redundancy exists" | **MBIST coverage (proxy evidence)** |
| DataFabric | `silicaflux-datafabric.zip` | SFB2 crossbar + DMA; `sfv_soc_df` physical top | region names |
| TimingFlow | `silicaflux-timingflow.zip` | real OpenSTA/OpenROAD; deterministic typ/slow/fast corners only | context for the HYPOTHETICAL parametric model |
| PowerGrid | - | **no project named PowerGrid**; the power-delivery project is `silicaflux-powerlink.zip` (PowerLink: PDN / package / PCB models) | not used (no yield data) |
| ThermalLab | `SilicaFlux ThermalLab (1).zip` | thermal model; contains the only DEF (demo) | DEF reader test fixture |
| FPGAFlow | - | **no separate project**; FPGA (ULX3S) flows inside `silicaflux-v` and `silicaflux-mcu-i` | not used |
| TwinLab | `silicaflux-twinlab.zip` | TypeScript wafer-economics view: labels the textbook gross-die *approximation* "Exact geometric equation", unseeded `Math.random`, defaults D0 = 0.12 /cm^2, wafer EUR/USD 2 400, mask 250 000 - **no source for any of them** | not reused (superseded; findings recorded) |
| FABTWIN | `FABTWIN-main.zip` | Python fab twin: default D0 0.12, 8 x 8 mm die, no scribe / notch, independent per-die parametric loss; docstring calls exp(-D0 A) "Murphy/Seeds-style" | not reused (no SilicaFlux-specific data) |
| PDFs | `SilicaFlux-main/*.pdf` | narrative reports; `foundry procurement ... .pdf` cites "EUROPRACTICE GF 28SLPe ~EUR 12,430 per mm^2" with an unresolvable citation marker and calls it both a mask and an MPW cost | recorded as DOCUMENT_CITED_UNVERIFIED for 28 nm only; never used as a quote |

## 4. Existing wafer, cost, test and fault-injection analysis

* Wafer / yield: only TwinLab (TS) and FABTWIN (Python) - generic models with unsourced defaults (section 3).
* Cost: no foundry quote, wafer price, MPW price, packaging or test price exists anywhere in the repository.
* Defect density, clustering, excursion, parametric distributions, packaging yield: **no data exists**.
* Test: TestCore fault-injection coverage (synthetic), LBIST demo coverage, ATPG experiment on TestCore, simulated host
  session logs (`station = sim-example`).

## 5. Consequences for YieldLab

1. SilicaFlux-V is the only design with measured physical dimensions; it is the reference design.
2. Its die outline excludes the pad ring; YieldLab adds the 0.3 mm/side ring from the SilicaFlux-V `[E]` estimate and labels
   the result DERIVED (measured + planning estimate).
3. MCU-I runs on its planning-estimate die with an area-fraction region model; Full SilicaFlux and chiplets cannot be
   simulated physically (NOT AVAILABLE).
4. Every defect, fatality, parametric, packaging and cost input is HYPOTHETICAL and every result is labelled
   "SIMULATED - HYPOTHETICAL SCENARIO".
5. SRAM repair, ECC, bank disable and accelerator harvesting are **not implemented** in SilicaFlux-V; they are modelled
   only as CONDITIONAL research scenarios.
6. MBIST detection uses TestCore r2 coverage as proxy evidence; logic-test (scan/ATPG) coverage for SilicaFlux-V is
   NOT AVAILABLE and the step is disabled.
