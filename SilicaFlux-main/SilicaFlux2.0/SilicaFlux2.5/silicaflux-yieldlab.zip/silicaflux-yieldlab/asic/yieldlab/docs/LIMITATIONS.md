# Known model limitations (GATE 19)

**No result of YieldLab is a measured or predicted foundry yield.** All defect, fatality, parametric, packaging and cost
inputs are HYPOTHETICAL (no SilicaFlux manufacturing data exist) and every run is labelled accordingly.

## Physical inputs
* The SilicaFlux-V die is a *pre-CTS, globally routed* FloorplanLab placement on IHP SG13G2; the final die will change
  (overflow > 0, slow-corner timing not closed, no pad ring placed). The 0.3 mm pad ring is a SilicaFlux-V `[E]`
  estimate; it is 32 % of the yield die area, so it dominates the I/O region's share of defect loss. Sensitivity: change
  `design.pad_ring.width_um`.
* Scribe width (80 um), edge exclusion (3 mm), reticle field (26 x 33 mm), stepping plan and wafer diameter are
  simulation choices, not foundry rules.
* Logic-region attribution uses FloorplanLab group *extents* and the 64 x 64 density grid, not per-cell positions;
  located group areas differ from OpenDB cell areas by up to ~30 % per group (both are reported). Clock and reset
  distribution are not separable before CTS.
* MCU-I has no floorplan: its die is a planning estimate and its regions are area fractions without spatial structure.
* Critical area is not extracted from layout; the critical-area fatality mode uses hypothetical wire geometry.

## Statistical models
* Defect-to-failure, SRAM fault mixture, test coverage (except the MBIST proxy) and false-reject rates are hypothetical.
* MBIST coverage comes from TestCore r2 fault injection on a synthetic single-fault population of an 8 x 16 model memory,
  applied as proxy for SilicaFlux-V's native March C- engine; multi-fault interactions and silicon defect behaviour are
  not represented. Scan/ATPG coverage for SilicaFlux-V is NOT AVAILABLE.
* Detection of different faults on one die is assumed independent; real fault masking / correlation is not modelled.
* The parametric model is hierarchical-Gaussian with hypothetical parameters; TimingFlow corners are not distributions.
  Parametric and defect mechanisms are independent unless a shared spatial term is configured.
* Wafer- and lot-level gamma multipliers create correlation; the true correlation structure of a SilicaFlux line is
  unknown. Excursion probability and factor are invented for sensitivity only.
* Finite-size defects are attributed to a region at the point of the die closest to the defect centre (extended defects
  are sampled every 50 um).
* Convergence statements are made only for the simulated quantities and sample sizes listed in each report; tail
  probabilities (e.g. DPPM) need far more wafers than means.
* Calibration code is validated on synthetic data; with < 10 wafers or < 30 failing dies the parameters are flagged as
  poorly identifiable. One synthetic wafer map cannot establish clustering.

## Economics
* Every price is illustrative. MPW and first-silicon results describe cost *structure*, not a budget.
* NRE amortisation volume, re-spin count and engineering effort are scenario inputs, not forecasts.
* Chiplet results are a research comparison with hypothetical D2D overhead, bond and assembly yields.

## Architecture studies
* Reduced tensor / vector / SRAM variants have no RTL and no physical run; die sizes are rule-based estimates and every
  such candidate fails the "physical implementation exists" constraint until FloorplanLab / TimingFlow are re-run.
* Redundancy, ECC, bank disable and harvesting are not implemented in SilicaFlux-V; their results are CONDITIONAL.

## Software
* OpenDB and STDF readers are NOT AVAILABLE in this environment (no `odb`, no `pystdf`); FloorplanLab's OpenDB export and
  CSV import are used instead. KLayout, PostgreSQL, FastAPI/React and Streamlit were not used; the dashboard is a single
  self-contained HTML file.
