# Missing manufacturing and foundry parameters

Each item is NOT AVAILABLE in the repository. YieldLab refuses to compute anything that needs one of them
(`MissingInputError`) unless an explicitly labelled hypothetical value is supplied for a sensitivity study.

| # | parameter | needed for | who can supply it | current YieldLab treatment |
|---|---|---|---|---|
| 1 | foundry / process choice (IHP SG13G2 vs commercial 130 nm) | everything below | Aureom.AI decision | IHP SG13G2 geometry used (only physical data) |
| 2 | wafer diameter of the chosen line | gross die | foundry | 200 mm / 300 mm simulation choices |
| 3 | edge exclusion, notch / flat specification | gross die | foundry / wafer spec | 3 mm hypothetical, SEMI M1 nominal notch |
| 4 | scribe-street width and seal-ring rule | die pitch | foundry DRM | 80 um hypothetical |
| 5 | reticle field size, stepping plan, PCM / test-structure sites | gross die, reticle effects | foundry | 26 x 33 mm hypothetical, no test sites |
| 6 | pad library, pad pitch, ESD, final pad ring | die outline | foundry IP / physical design | 0.3 mm/side planning estimate |
| 7 | fatal defect density D0 (by layer / module) and its trend | defect-limited yield | foundry yield data (often NDA) | hypothetical sweeps 0.05-2 /cm^2 |
| 8 | defect clustering (alpha), spatial signatures, excursion rate | yield spread, lot risk | foundry / own wafer maps | hypothetical gamma multipliers + generators |
| 9 | critical-area extraction of the final layout | defect sensitivity per layer | physical design (e.g. KLayout / commercial CAA) | gross-area or hypothetical critical-area model |
| 10 | SRAM macro failure modes; redundancy-capable compiler | SRAM yield, repair | memory compiler vendor | hypothetical mixture; repair = none |
| 11 | scan insertion + production ATPG coverage for SilicaFlux-V | logic escapes | DFT flow (TestCore r2 path) | scan step disabled; functional coverage hypothetical |
| 12 | silicon-correlated MBIST coverage | memory escapes | TestCore + silicon | TestCore r2 synthetic-population proxy |
| 13 | statistical process data (Fmax, leakage, SRAM timing) | parametric yield | foundry SPICE MC / silicon | hypothetical hierarchical model |
| 14 | product specifications (speed grades, leakage limit, reduced configurations) | binning | Aureom.AI product definition | 50 MHz grade only; leakage limit hypothetical |
| 15 | wafer price / MPW quote / mask NRE | cost per good die | foundry or MPW broker quote | illustrative values; quote template refuses NOT_AVAILABLE |
| 16 | probe, final-test and packaging prices; probe card NRE | cost per good die | test / assembly houses | illustrative values |
| 17 | assembly (packaging) yield | delivered good dies | assembly house | 0.99 hypothetical |
| 18 | qualification cost and plan | program cost | quality / foundry | illustrative |
| 19 | measured wafer maps, bin maps, inspection data | calibration, model selection | first silicon | import + calibration code ready; no data |
| 20 | 65 nm / 28 nm PDKs, SRAM compilers, prices | node comparison | foundries (NDA) | 65 nm die = planning estimate; 28 nm NOT AVAILABLE |
