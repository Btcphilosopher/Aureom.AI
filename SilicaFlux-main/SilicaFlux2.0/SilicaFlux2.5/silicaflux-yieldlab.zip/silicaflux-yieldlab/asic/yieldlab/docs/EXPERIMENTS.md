# Experiments

## A. Controlled simulation experiments (implemented: `python -m yieldlab experiments`)

All Monte Carlo experiments use common random numbers (same seed, lot / wafer indices and per-mechanism streams) and
report paired differences with lot-cluster 95 % CIs (`reports/studies/experiments.json`).

| id | comparison | arms | evidence class |
|---|---|---|---|
| A | small vs large die | FloorplanLab SA_01 (7.44 mm^2) vs L_west_east_columns (10.38 mm^2) | dies MEASURED, defects HYPOTHETICAL |
| B | Poisson vs negative binomial | uniform fatal defects, no variation vs wafer-level gamma alpha = 2 (same mean) | HYPOTHETICAL |
| C | uniform vs clustered | uniform vs Thomas process with equal mean intensity | HYPOTHETICAL |
| D | edge-exclusion sensitivity | 1.5 / 2 / 3 / 5 / 8 mm | HYPOTHETICAL exclusion |
| E | SRAM redundancy vs none | none vs rows + cols (4 + 4 per macro) and SECDED (CONDITIONAL) | capability absent |
| F | high vs low MBIST sensitivity | March C- vs MATS+ coverage from TestCore r2 fault injection | proxy evidence |
| G | 130 nm vs 65 nm | availability matrix + gross die / yield sensitivity on a common hypothetical D0 grid | 65 nm die = PLANNING_ESTIMATE |
| H | MPW vs dedicated wafers | cost structure at 1 / 5 / 25 / 100 wafers vs a shuttle | prices HYPOTHETICAL |
| I | monolithic vs chiplets | SilicaFlux-V vs compute+I/O / SRAM split with D2D overhead | research, HYPOTHETICAL |
| J | reduced vs full tensor array | C_sram_near_compute vs estimated 2x2 tensor die | variant ESTIMATED, no RTL |

## B. Recommended SilicaFlux-V manufacturing experiments (to replace hypothetical inputs with data)

1. **Close the floorplan first.** Apply the E-corridor change to C_sram_near_compute (the next FloorplanLab experiment
   it names), reach zero global-route overflow, CTS, detailed route, then re-export `geometry.json`; YieldLab's die
   outline, region model and gross-die counts update automatically (`design.floorplan_run`).
2. **Pad ring decision.** Select the I/O library and power-pad count; replace the 0.3 mm estimate with the real ring -
   it is a third of the current yield die area.
3. **Obtain foundry inputs** listed in `MISSING_FOUNDRY_PARAMETERS.md` (scribe, edge exclusion, reticle, D0 trend under
   NDA, wafer / MPW quote) and re-run with `source: MEASURED_MANUFACTURING` or a quote reference.
4. **First-silicon test vehicle.** Place PCM / defect-monitor structures (comb / serpentine) in a reticle slot
   (`reticle.test_site_slots`) to measure layer defect densities directly - SilicaFlux-V die yield alone cannot separate
   D0 from clustering with tens of MPW samples.
5. **Wafer-map collection.** Probe every die with full bin and soft-bin logging (TestCore host software already writes
   `lot_steps.csv` / `lot_failures.csv`); import with an explicit retest policy and calibrate D0 / alpha with holdout
   wafers. Do not fit clustering from fewer than ~10 wafers (the calibration flags it).
6. **MBIST silicon correlation.** Run March C-, MATS+ and RETENTION on every die and keep failure bitmaps; this measures
   the SRAM fault-type mixture that is currently hypothetical and shows whether row/column redundancy would pay off.
7. **Scan insertion + production ATPG** on SilicaFlux-V (TestCore r2 path) to replace the hypothetical logic coverage;
   then quantify escapes with the test model.
8. **Speed / leakage characterisation** across wafers and lots to fit the hierarchical parametric model (variance
   components lot / wafer / die, radial term) instead of using corner timing.
9. **Assembly yield** from the first packaging lot (open / short at final test) to replace the 0.99 assumption.
10. **Only then** evaluate redundancy, ECC or reduced-capacity products with measured fault data and the area overhead
    from a redundancy-capable SRAM compiler.
