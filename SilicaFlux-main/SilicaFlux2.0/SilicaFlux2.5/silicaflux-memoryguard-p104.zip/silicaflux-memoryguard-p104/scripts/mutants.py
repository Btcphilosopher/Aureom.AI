#!/usr/bin/env python3
"""MemoryGuard mutation table.  Each mutant is one planted RTL defect: (id, file, old text, new text, occurrences to replace, description,
formal jobs expected to catch it).  Used by scripts/formal.py (formal kill) and scripts/mutate.py (simulation kill).  A mutant is KILLED when
a formal job FAILS on it / a simulation run does NOT print TB_RESULT: PASS."""
C = "sf_memory_guard_checker.sv"; G = "sf_memory_guard_regions.sv"; P = "sf_memory_guard_port.sv"; S = "sf_memory_guard_regs.sv"; T = "sf_memory_guard.sv"; F = "sf_memory_guard_faults.sv"
# id, file, old, new, count (0 = all), description, formal harness jobs expected to kill it
MUTANTS = [
 ("C01", C, "ge = (c_addr >= b);", "ge = 1'b1;", 0, "lower bound of the region ignored (access below the base is granted)", ["chk"]),
 ("C02", C, "le = (a_end <= en);", "le = ({1'b0, c_addr} < en);", 0, "only the FIRST byte is checked against the end of the region (the classic bug the brief warns about)", ["chk"]),
 ("C03", C, "wire ovf         = a_end[AW] && (|a_end[AW-1:0]);", "wire ovf         = 1'b0;", 1, "address overflow not detected", ["chk"]),
 ("C04", C, "wire allow_sel = |(dsel & allow);", "wire allow_sel = 1'b1;", 1, "trusted port binding ignored (any port may claim any domain)", ["chk"]),
 ("C05", C, "rt = op_wr ? t_w[e] : t_r[e];", "rt = t_r[e];", 1, "a WRITE is checked against the READ right", ["chk"]),
 ("C06", C, "dv = !t_devn[e] || t_dev[e*NP + PIDX];", "dv = 1'b1;", 1, "device permissions ignored", ["chk"]),
 ("C07", C, "wire len_zero    = (c_len == '0);", "wire len_zero    = 1'b0;", 1, "zero-length transfers accepted", ["chk"]),
 ("C08", C, "ds = dsel[e / NR];", "ds = 1'b1;", 1, "a region of ANY domain grants the access (no domain isolation)", ["chk"]),
 ("C09", C, "wire dom_ok    = |dsel;", "wire dom_ok    = 1'b1;", 1, "invalid domain numbers accepted as a valid domain", ["chk"]),
 ("C10", C, "wire len_big     = (c_len > LW'(MAXLEN));", "wire len_big     = 1'b0;", 1, "over-long transfers accepted", ["chk"]),
 ("R01", G, "else if (ovl_bad)                      cm_err = CE_OVERLAP;", "else if (1'b0)                      cm_err = CE_OVERLAP;", 1, "overlapping regions are accepted at install time", ["regions", "cfg"]),
 ("R02", G, "wire          sum_in     = (sum65 <= {{(64 - AW){1'b0}}, space});", "wire          sum_in     = 1'b1;", 1, "base + size may leave the address space", ["regions", "cfg"]),
 ("R03", G, "if (hit && (e != self_e) && (same_dom || (STRICT != 0))) ovl_bad = 1'b1;", "if (hit && (same_dom || (STRICT != 0))) ovl_bad = 1'b1;", 1, "re-installing a slot over itself is reported as an overlap", ["regions"]),
 ("R04", G, "wire do_wr = cm_en && cm_ok;", "wire do_wr = cm_en;", 1, "an invalid command is written to the table when cm_en is raised", ["regions"]),
 ("P01", P, "assign m_valid = act_valid && act_permit && fwd_room;", "assign m_valid = act_valid && fwd_room;", 1, "the verdict is not consulted: every request reaches the memory", ["port"]),
 ("P02", P, "wire deny_ok   = act_valid && !act_permit && !err_valid_q && (fwd_cnt_q == '0);", "wire deny_ok   = act_valid && !act_permit && !err_valid_q;", 1, "an error response may overtake earlier responses", ["port"]),
 ("P03", P, "assign m_be    = (m_valid && wr) ? (act_be & lane_mask) : '0;", "assign m_be    = (m_valid && wr) ? act_be : '0;", 1, "byte enables are not clipped to the length", ["port"]),
 ("P04", P, "assign m_wdata = (m_valid && wr) ? act_wdata : '0;", "assign m_wdata = wr ? act_wdata : '0;", 1, "write data of a DENIED request is driven onto the memory side", ["port"]),
 ("P05", P, "assign r_ready = !blk && (!a_valid || a_leave);", "assign r_ready = (!a_valid || a_leave);", 1, "ingress is not blocked during a configuration drain", ["port"]),
 ("P06", P, "wire d_ok   = d_valid && (fwd_cnt_q != '0);", "wire d_ok   = d_valid;", 1, "an orphan memory response is delivered to the requester", ["port:port_orphan0"]),
 ("P07", P, "assign idle = !a_valid && !b_valid && (fwd_cnt_q == '0) && !err_valid_q;", "assign idle = !a_valid && !b_valid && (fwd_cnt_q == '0);", 1, "idle ignores a pending error response (the drain can commit under a request)", ["port"]),
 ("P08", P, "err_st_q <= is_proto(act_fault) ? ST_PROTO : ST_DENIED;", "err_st_q <= ST_DENIED;", 1, "malformed requests are answered DENIED instead of PROTO", ["port"]),
 ("P09", P, "assign m_addr  = m_valid ? act_addr : '0;", "assign m_addr  = act_addr;", 1, "the address of a denied request is driven onto the memory side", ["port"]),
 ("P10", P, "wire fwd_room = (fwd_cnt_q != OW'(MAXOUT)) && !err_valid_q;", "wire fwd_room = (fwd_cnt_q != OW'(MAXOUT));", 1, "a request is forwarded while an error response is still pending (response reordering)", ["port"]),
 ("P11", P, "assign s_rdata  = err_valid_q ? '0 : d_rdata;", "assign s_rdata  = d_rdata;", 1, "an error response carries memory data", ["port"]),
 ("S01", S, "assign cm_en   = in_drain && blk_q && drained;", "assign cm_en   = in_drain && blk_q;", 1, "the table is committed without waiting for the datapath to drain (TOCTOU)", ["cfg", "top"]),
 ("S02", S, "wire c_locked  = acc && cfg_req_priv && a_ok && cfg_req_write && full && !is_ro_w && is_cfg_w && lock_q;", "wire c_locked  = 1'b0;", 1, "the configuration lock does not lock", ["cfg"]),
 ("S03", S, "wire c_do      = acc && cfg_req_priv && a_ok && !c_wbad && !c_locked && !c_busy;", "wire c_do      = acc && a_ok && !c_wbad && !c_locked && !c_busy;", 1, "unprivileged accesses are performed (privilege not checked)", ["cfg"]),
 ("S04", S, "busy_q <= 1'b1; blk_q <= 1'b1; cmd_q <= cfg_req_wdata[3:0];", "busy_q <= 1'b1; blk_q <= 1'b0; cmd_q <= cfg_req_wdata[3:0];", 1, "ingress is not blocked while a command drains", ["cfg"]),
 ("S05", S, "wire cmd_go    = w_cmd && cm_ok;", "wire cmd_go    = w_cmd;", 1, "an invalid command starts a drain and commits", ["cfg"]),
 ("S06", S, ["if (lock_set) lock_q <= 1'b1;", "wire c_locked  = acc && cfg_req_priv && a_ok && cfg_req_write && full && !is_ro_w && is_cfg_w && lock_q;"], ["if (w_ctrl) lock_q <= cfg_req_wdata[CTRL_LOCK];", "wire c_locked  = acc && cfg_req_priv && a_ok && cfg_req_write && full && !is_ro_w && is_cfg_w && lock_q && (widx != 5'(R_CTRL));"], 1, "the lock can be cleared by a write to CTRL", ["cfg"]),
 ("T01", T, "assign drained    = &p_idle;", "assign drained    = |p_idle;", 1, "drained = ANY port idle (instead of all)", ["top"]),
 ("F01", F, "wire push_ok = any_req && (cnt_q != CW'(DEPTH));", "wire push_ok = any_req;", 1, "the fault log overwrites when full", []),
]

# Survivors of the SIMULATION campaign that are not observable at the interfaces of the integrated design; each is killed by the formal harness
# named.  A survivor is reported as such -- these notes only say why.
EQUIVALENT_IN_SIM = {
 "R04": "redundant defence in depth: in the integrated design cm_en is raised only for a command the engine has validated, so no simulation can reach it; killed formally by fv_mg_regions (cm_en free)",
 "P10": "internal-invariant mutant: forwarding while an error response is pending is masked at the interface by the response multiplexer (the error response keeps priority, so order is preserved); killed formally by fv_mg_port (invariant R4: an error response only exists with nothing outstanding)",
}
