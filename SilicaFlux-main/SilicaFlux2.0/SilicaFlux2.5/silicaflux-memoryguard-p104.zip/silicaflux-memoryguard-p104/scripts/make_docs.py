#!/usr/bin/env python3
"""Compose docs/memory_guard/08_VERIFICATION.md and 09_PHYSICAL.md and README.md numbers from the machine-generated reports, so that every number
in the documents is the number in reports/ (regenerate the reports first: make regress formal mutate synth bench).   usage: scripts/make_docs.py"""
import json, os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RP = os.path.join(ROOT, "reports")
BR = os.path.join(ROOT, "benchmarks", "memory_guard", "results")
D = os.path.join(ROOT, "docs", "memory_guard")

def load(p, default=None):
    try: return json.load(open(p))
    except Exception: return default

reg = load(os.path.join(RP, "regression.json"), [])
fv = load(os.path.join(RP, "formal.json"), [])
mu = load(os.path.join(RP, "mutation.json"), [])
sy = load(os.path.join(BR, "synth.json"), [])
be = load(os.path.join(BR, "bench.json"), [])

# ------------------------------------------------------------------ 08 verification
def sec_regression():
    out = ["| run | parameters | checks | result | what it covers |", "|---|---|---:|---|---|"]
    for r in reg:
        out.append(f"| {r['name']} | {', '.join(f'{k}={v}' for k, v in r['params'].items() if not k.startswith('_')) or 'defaults'} | {r['checks']} | **{r['status']}** | {r['claim']} |")
    tot = sum(r["checks"] for r in reg); ok = sum(r["status"] == "PASS" for r in reg)
    out.append(f"\n**{ok} / {len(reg)} runs pass, {tot:,} checks.**")
    return "\n".join(out), ok, len(reg), tot

def sec_formal():
    proofs = [x for x in fv if x["kind"] in ("comb", "prove")]
    out = ["| job | kind | parameters | result | s | establishes |", "|---|---|---|---|---:|---|"]
    for x in proofs:
        out.append(f"| {x['name']} | {x['kind']} | {', '.join(f'{k}={v}' for k, v in x['params'].items())} | **{x['status']}** | {x['secs']} | {x['claim']} |")
    vac = [x for x in fv if x["kind"] == "vac"]
    mut = [x for x in fv if x["kind"] == "mut"]
    return "\n".join(out), len(proofs), sum(x["status"] == "PASSED" for x in proofs), len(vac), sum(x["status"] == "WITNESSED" for x in vac), len(mut), sum(x["status"] == "KILLED" for x in mut)

def write_08():
    rt, rok, rn, rtot = sec_regression()
    ft, np_, npass, nv, nvok, nm, nmk = sec_formal()
    ms = sorted(mu, key=lambda r: r["id"])
    mrows = ["| mutant | defect | killed by | result |", "|---|---|---|---|"]
    for r in ms:
        note = r.get("note", "")
        mrows.append(f"| {r['id']} | {r['desc']} | {r['killed_by'] or '-'} | **{r['status']}**{(' — ' + note) if note else ''} |")
    mk = sum(r["status"] == "KILLED" for r in ms)
    txt = f"""# 08 — Verification: what was run, what it proves, what it does not

Everything here is machine-generated into `reports/` and reproducible (`make regress formal mutate`). Tools: Verilator 5.020, Yosys 0.33, `yosys-smtbmc` + z3 5.x.

## 1. The argument in one page

The security statement of the brief — *no unauthorised request can modify protected memory; every forbidden operation produces a reproducible error report* — is established by an
**assume-guarantee composition** of unbounded proofs, then exercised end to end by simulation:

```
 fv_mg_checker  (all inputs)     permit = independent specification; invalid domains, overflow, whole-range containment
        │ used by
 fv_mg_port     (unbounded)      ASSUME E1 E2 E4 (+E3)  ──►  GUARANTEE  m_valid ⇒ oldest accepted request, permitted by the specification for the table
        │                                                            memory-side request = accepted request, bit for bit;  nothing on m_* unless m_valid
        │                                                            one response per request, in order, DENIED / PROTO / OKAY / SLVERR, orphans never delivered
 fv_mg_cfg      (unbounded)      proves E4: the table changes only after a commit made with every port idle and ingress blocked,
        │                                    only after a privileged, unlocked, error-free R_CMD write, never after the lock
 fv_mg_regions  (unbounded)      the table never holds two overlapping valid regions; installs are validated; changes only on commit
 fv_mg_top      (unbounded)      E4 holds on the COMPOSED design; a commit never happens under any accepted-unanswered request (assumes port G6, proved above)
```

`E4` is the only assumption the port proof makes about the world around it that the *guard itself* must discharge, and it is discharged by `fv_mg_cfg` / `fv_mg_top`.
The other assumptions (E1 requester holds, E2 memory holds, E3 memory echoes) are protocol obligations of the neighbours (`10`).

## 2. Properties of the brief → evidence

| brief (§10) | property | evidence |
|---|---|---|
| denied writes produce no protected-memory modification | G1, G3: nothing is on `m_*` unless the specification permitted the request; M1/M2/M3 monitors; memory-image canary E1/E2 | `fv_mg_port` + `mm_random*` + `rnd_*` |
| invalid domains cannot issue authorised requests | S1 (all inputs), G1 | `fv_mg_checker`, `fv_mg_port` |
| address overflow never grants access | S2 (all inputs); directed T06 | `fv_mg_checker`, `tb_mg_directed` |
| cross-boundary requests are correctly checked | S3: one region contains the first byte, the last byte and any middle byte; directed T05 boundary sweep | `fv_mg_checker` |
| configuration is changed only by trusted control | C1–C4, W1, R2 | `fv_mg_cfg`, `fv_mg_top`, `fv_mg_regions` |
| invalid requests receive explicit failure responses | G5: every response is the right one, in order, with the request's id and no data on an error; no response without a request (**safety**) — that a response *arrives* (**liveness**) is checked by simulation only: every run ends by checking that every accepted request was answered | `fv_mg_port`, M4, E-checks |
| no unauthorised alternate path bypasses the checker | G1 + G3 inside the guard (a theorem); R1 around it (an integration rule) | `fv_mg_port`; `03` |

## 3. Simulation

{rt}

Stimulus is adversarial (`tests/memory_guard/README.md`): the random runs issue 140–400 thousand requests each, **most of them denied by construction**, from four ports at once, with a
background agent changing the policy while they run (about 900 commits per run, ~99 % with traffic in flight).

## 4. Formal

{ft}

* **{npass} / {np_}** proofs pass. `comb` = proved for **all** inputs. `prove` = base case from reset + k-induction: **unbounded**, on the stated tiny configuration.
* **{nvok} / {nv}** reachability witnesses fail as they must: the environment assumptions leave permitted writes, denials of every class, full outstanding windows, held-back requests,
  commits with regions installed, timeouts and locks reachable — the proofs are not vacuous.
* **{nmk} / {nm}** formal mutant checks were killed (`reports/formal.md`).

## 5. Mutation campaign (simulation)

One planted RTL defect each (`scripts/mutants.py`). **{mk} / {len(ms)} killed.**

{chr(10).join(mrows)}

Survivors are reported, not hidden. Both are **not observable at the interfaces of the integrated design** and both **are killed by the formal harnesses**:
**R04** plants a defect in a *redundant* guard (the table also refuses an invalid command inside the regions module, in addition to the engine that raises `cm_en` only for a
validated command), unreachable in the integrated design; killed by `fv_mg_regions`, where `cm_en` is a free input. **P10** lets a port forward a request while an earlier error
response is still pending: the response multiplexer keeps the error response first, so the order seen by the requester is unchanged and no simulation can see it; killed by
`fv_mg_port` through the invariant *an error response only exists with nothing outstanding*. The whole-design mutation kill list is in `reports/formal.md` (35 formal kills of 33 mutants).

## 6. What was NOT verified

* **Liveness** (a response always arrives; a drain always ends) — simulation evidence only; the drain has a timeout by design.
* The fault log / counters — simulation only (directed T13, random E3 tallies, mutant F01).
* **Full-size** instances as single formal problems: the proofs use `ND ≤ 4`, `NR ≤ 4`, `NP ≤ 3`, `AW ≤ 10` (the checker also at `AW = 63`). The 4 × 4 × 32-bit checker is covered by 240 000 Python-model vectors and by simulation.
* The **composition** is proved only for W1–W5 (E4, blocking, no commit under work); the full-system statement is the assume-guarantee argument of §1, not a monolithic proof.
* No gate-level or post-synthesis simulation; no second RTL simulator as oracle; no silicon.
"""
    open(os.path.join(D, "08_VERIFICATION.md"), "w").write(txt)

# ------------------------------------------------------------------ 09 physical
def find(name):
    return next((r for r in sy if r["name"] == name), None)

def write_09():
    chk = [r for r in sy if r["name"].startswith("chk_nd")]
    rows = ["| ND | NR | lookup | diag | gates | GE | gate depth | LUT6 | LUT depth |", "|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for r in sorted(chk, key=lambda r: (r["params"]["LOOKUP_ARCH"], r["params"]["DIAG_PRECISE"], r["params"]["NR"], r["params"]["ND"])):
        p = r["params"]
        rows.append(f"| {p['ND']} | {p['NR']} | {p['LOOKUP_ARCH']} | {p['DIAG_PRECISE']} | {r['gates']} | {r['ge']} | {r['gate_depth']} | {r['lut6']} | {r['lut_depth']} |")
    aw = [r for r in sy if r["name"].startswith("chk_aw")]
    awr = ["| AW | gates | GE | gate depth | LUT6 | LUT depth |", "|---:|---:|---:|---:|---:|---:|"] + [f"| {r['params']['AW']} | {r['gates']} | {r['ge']} | {r['gate_depth']} | {r['lut6']} | {r['lut_depth']} |" for r in aw]
    top = [r for r in sy if r["name"].startswith(("top_", "port_"))]
    tr = ["| config | gates | flops | GE | gate depth | LUT6 | LUT depth |", "|---|---:|---:|---:|---:|---:|---:|"] + [f"| {r['name']} | {r['gates']} | {r['flops']} | {r['ge']} | {r['gate_depth']} | {r['lut6']} | {r['lut_depth']} |" for r in top]
    # bench tables
    def g(pipe, mo, L, den, ports, arch=0):
        return next((r for r in be if r["CHK_PIPE"] == pipe and r["MAXOUT"] == mo and r["ARCH"] == arch and r["memlat"] == L and r["den"] == den and r["ports"] == ports and r["thr"] is not None), None)
    br = ["| CHK_PIPE | MAXOUT | L = 1 | L = 2 | L = 4 | L = 8 |", "|---:|---:|---|---|---|---|"]
    for pipe in (0, 1):
        for mo in (1, 2, 4, 8):
            cells = []
            for L in (1, 2, 4, 8):
                r = g(pipe, mo, L, 0, 4)
                cells.append(f"{r['thr']:.2f} / {r['lat']:.1f}" if r else "-")
            br.append(f"| {pipe} | {mo} | " + " | ".join(cells) + " |")
    dr = ["| CHK_PIPE | denied % | ports | responses / cycle / port | latency |", "|---:|---:|---:|---:|---:|"]
    for pipe in (0, 1):
        for den in (50, 100):
            for ports in (1, 4):
                r = g(pipe, 4, 1, den, ports)
                if r: dr.append(f"| {pipe} | {den} | {ports} | {r['thr']:.3f} | {r['lat']:.2f} |")
    txt = f"""# 09 — Physical implications: area, depth, latency, throughput

> **All numbers are estimates.** Yosys 0.33, technology independent (`synth -flatten`, ABC to generic 2-input gates / LUT6). **No ASIC library or PDK exists in the repository**, no place-and-route
> or timing run was made, nothing here is a silicon measurement. They are for comparing configurations against each other. `GE` = NAND2-equivalent estimate with the weights in
> `benchmarks/memory_guard/synth.py` (flop = 5 GE). `gate depth` = longest combinational path (`ltp`) in generic gates; ABC does not optimise for depth here, so absolute depths are pessimistic.

## 1. The checker of one port — parallel region comparators (default AW 32, NP 4)

Each region entry costs two wide comparators for the decision (`addr ≥ base`, `addr + len ≤ end`) and two more only for the diagnosis. `DIAG_PRECISE = 0` removes the latter.

{chr(10).join(rows)}

Reading the table: area grows **linearly with `ND·NR`** for lookup 0 (every entry compares in parallel, results gated by the domain decode) and with `NR` plus an `ND`-wide AND-OR multiplexer
over the stored entries for lookup 1. The multiplexer moves cost from comparators to wiring: it wins when `ND` is large; with few domains the parallel structure is simpler. `DIAG_PRECISE = 0` is the cheapest way to cut
area — at the cost of reporting `FT_SPAN` as `FT_NOMAP` (the decision is unchanged, proved).

Address width (comparators are `AW` bits):

{chr(10).join(awr)}

## 2. The whole guard — growth with domains and ports

The checker is **per port** (the decision must be available to every port every cycle), so area also grows with `NP`; the region table itself (flops) grows with `ND·NR·(2·AW+…)`; the
fault log and the counter bank are fixed costs. The `CHK_PIPE = 1` configurations add a second request register per port and the registered verdict.

{chr(10).join(tr)}

Reading the table (the numbers above are generated from `benchmarks/memory_guard/results/synth.json`):

* **One port = one checker.** A single port (`port_p0`) is about 10 k gates, of which the checker is nearly all; four ports are therefore ≈ 4 × that (`top_nd4_np4_*` is about 55 k gates, 93 k GE, 4 k flops). Area scales ≈ **linearly with `NP`**.
* **Domain count and regions.** With the parallel lookup (`LOOKUP_ARCH` 0) one port's checker grows ≈ linearly with `ND·NR` (ND 2 → 16 at NR 4: see the first table); the multiplexed lookup (1) grows much more slowly (ND 2 → 16 at NR 4: ×7.8 for lookup 0, ×3.3 for lookup 1), because it compares only the `NR` entries of the claimed domain and pays an `ND`-wide AND-OR multiplexer instead. The whole guard also grows with `ND·NR·(2·AW + …)` table flops. With `LOOKUP_ARCH = 1` the default guard is **≈ 38 % smaller** than with 0 (35 k vs 55 k gates).
* **Diagnostics are the cheapest area lever**: `DIAG_PRECISE = 0` removes about **45 %** of the parallel checker (the two extra comparators per entry), at the price of reporting `FT_SPAN` as `FT_NOMAP`; the decision is proved unchanged.
* **Address width** moves comparator size linearly (§1, second table).
* **Registered verdict** (`CHK_PIPE = 1`) costs ≈ 130 extra flops per port (a second request register) and **+1 cycle** of latency. What it buys is structural: with 0, the checker sits on the register → output path (request register → checker → `m_valid`, and through `act_retire` → `r_ready`); with 1, the verdict comes from a register, so the checker moves onto an internal register → register path (request register → checker → verdict register). **Yosys 0.33 `ltp` reports only the single longest path of the design, which is the same comparator chain in both configurations (58 vs 63 gates for one port), so this study does not measure the output-path benefit** — a timing-driven synthesis with a real library is needed for that. The longest path of the *whole* guard (134 gates) is **not** the checker but the configuration path (65-bit region validation, overlap compare against every entry, saturating counters); it is off the request datapath and would be multicycled or pipelined in a physical design.
* **Throughput does not depend on the check** for permitted traffic (§3); a denied request costs more cycles (it waits for the earlier responses and for the fault-log grant).
* **Fixed overhead**: the 33 × 32-bit counter bank and the 8-record fault FIFO are about 1.9 k flops of the default guard; `CNTW` and `FLOG_DEPTH` can be narrowed.

## 3. Throughput and latency of the protected path (simulation)

4000-cycle window after warm-up; every port streams 8-byte requests at full rate into an always-ready memory of fixed latency `L`; `latency` is accept edge → response edge (the memory alone would show about `L`).
Permitted traffic, 4 ports, **responses / cycle / port  /  average latency (cycles)**:

{chr(10).join(br)}

Denied traffic (`MAXOUT` 4, `L` = 1):

{chr(10).join(dr)}

(`benchmarks/memory_guard/results/bench.md` has every combination.)

* Permitted traffic: **one response per cycle per port** once the outstanding window covers the memory round trip: the measured throughput is `min(1, MAXOUT / (L + 1))` for both `CHK_PIPE` values — the **check never limits throughput**, the window does.
* The registered verdict adds exactly **one cycle** of latency (2 → 3 cycles at `L` = 1) and costs no throughput.
* A **denied** request is the slow path by design: it waits for every earlier response (ordering), for a fault-log grant, and its error response must be taken before the next denial retires. Measured: **one denied request every 2 cycles per port**, and **one per cycle in total** across ports (the fault log has one write port, so four ports that deny continuously get 0.25 each).
  By construction a port's denials never delay another port's *permitted* requests (the ports share only the table, the fault-log arbiter that only denied requests use, and the drain); this was not measured separately.
* Configuration commands stall **every** port for the length of the drain (§`05`); in the random runs about 900 commits are absorbed per 150 000 cycles with no lost requests.

## 4. What was not studied

* real timing (no PDK), power, placement; a larger `AW` than 48; the effect of `FLOG_DEPTH` and `CNTW` (fixed overhead: about 1 000 flops of the default guard are the 33 × 32-bit counters and the fault FIFO — they can be narrowed);
* sharing one checker between ports (one verdict per cycle for four ports would serialise them; not built);
* reducing the unreset payload flops of the table (already unreset) or using a RAM for the table (would add a read latency to every check).
"""
    open(os.path.join(D, "09_PHYSICAL.md"), "w").write(txt)

def write_readme():
    rt, rok, rn, rtot = sec_regression()
    ft, np_, npass, nv, nvok, nm, nmk = sec_formal()
    mk = sum(r["status"] == "KILLED" for r in mu)
    surv = [r["id"] for r in mu if r["status"] != "KILLED"]
    blk = f"""| evidence | result |
|---|---|
| simulation regression (directed, adversarial random, Python-model vectors, adapters, **real MemoryMatrix behind the guard**) | **{rok} / {rn} runs pass, {rtot:,} checks** |
| formal proofs (k-induction / all-input, z3) | **{npass} / {np_} pass** — checker S0–S5 for all inputs; table invariants; configuration engine; one port (unbounded); the composition |
| formal non-vacuity witnesses | **{nvok} / {nv}** reachable |
| formal mutation checks | **{nmk} / {nm}** planted defects caught |
| simulation mutation campaign | **{mk} / {len(mu)}** killed{(' (survivor(s): ' + ', '.join(surv) + ' — not observable at the interfaces of the integrated design, both killed formally; see 08)') if surv else ''} |"""
    p = os.path.join(ROOT, "README.md")
    s = open(p).read()
    s = re.sub(r"<!-- RESULTS-BEGIN -->.*?<!-- RESULTS-END -->", lambda m: "<!-- RESULTS-BEGIN -->\n" + blk + "\n<!-- RESULTS-END -->", s, flags=re.S)
    open(p, "w").write(s)

if __name__ == "__main__":
    if not os.path.isdir(D): os.makedirs(D)
    write_08()
    if sy and be: write_09()
    write_readme()
    print("docs written")
