#!/bin/bash
# usage: scripts/run_sim.sh <tb.sv> <outdir> [-Gparam=value | +define+X | -f file.f ...]   (Verilator 5, --binary --timing)
# MG_RTL=<dir> uses another copy of the rtl/ directory (the mutation campaign).
ROOT=$(cd "$(dirname "$0")/.." && pwd)
TB=$(realpath "$1"); OUT=$(realpath -m "$2"); shift 2
RTLDIR=${MG_RTL:-$ROOT/rtl}
mkdir -p "$OUT"
TOP=$(basename "$TB" .sv)
cd "$RTLDIR"
verilator --binary --timing -Wno-fatal -Wno-WIDTH -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM -Wno-DECLFILENAME -Wno-PINCONNECTEMPTY -Wno-CASEINCOMPLETE -Wno-TIMESCALEMOD \
  --x-initial 0 --assert -j 4 --Mdir "$OUT/obj" --top-module "$TOP" -o "$TOP" \
  -I"$ROOT/tests/memory_guard" "$@" -f files.f "$TB" > "$OUT/build.log" 2>&1 || { tail -40 "$OUT/build.log"; exit 1; }
"$OUT/obj/$TOP" +verilator+rand+reset+0 > "$OUT/run.log" 2>&1
echo "exit=$?" >> "$OUT/run.log"
grep -E "TB_RESULT|FAIL" "$OUT/run.log" | head -20
tail -2 "$OUT/run.log"
