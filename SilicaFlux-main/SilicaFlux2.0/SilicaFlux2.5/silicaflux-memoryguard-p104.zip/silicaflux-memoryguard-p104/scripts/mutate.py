#!/usr/bin/env python3
"""Simulation mutation campaign: every mutant of scripts/mutants.py is built into a copy of rtl/ and run against the random adversarial testbench
(then, if it survives, the directed testbench; checker mutants also against the Python vectors).  A mutant is KILLED when a run does not print
`TB_RESULT: PASS`.  A SURVIVOR is reported, never hidden.   usage: scripts/mutate.py [--jobs N] [--only ID ...]   -> reports/mutation.md / .json"""
import argparse, json, os, shutil, subprocess, sys, time, tempfile
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import mutants as MU
OUT = os.environ.get("MG_OUT", os.path.join(ROOT, "out")) + "/mut"
R = os.path.join(ROOT, "rtl")
TB = os.path.join(ROOT, "tests", "memory_guard")

def sim(rtl_dir, tb, wd, args):
    """returns (passed, log, built): a testbench that does not even build is an ERROR of the campaign, never a kill"""
    env = dict(os.environ, MG_RTL=rtl_dir)
    p = subprocess.run([os.path.join(ROOT, "scripts", "run_sim.sh"), os.path.join(TB, tb), wd] + args, capture_output=True, text=True, env=env)
    built = os.path.exists(os.path.join(wd, "run.log"))
    log = open(os.path.join(wd, "run.log")).read() if built else p.stdout + p.stderr
    return "TB_RESULT: PASS" in log, log, built

def run(m):
    mid, fname, old, new, cnt, desc, _ = m
    wd = os.path.join(OUT, mid)
    shutil.rmtree(wd, ignore_errors=True); os.makedirs(wd)
    rtl = os.path.join(wd, "rtl"); shutil.copytree(R, rtl)
    f = os.path.join(rtl, "memory_guard", fname)
    src = open(f).read()
    for o_, n_ in zip(old if isinstance(old, list) else [old], new if isinstance(new, list) else [new]):
        assert src.count(o_) >= 1, f"{mid}: pattern not found"
        src = src.replace(o_, n_) if cnt == 0 else src.replace(o_, n_, cnt)
    open(f, "w").write(src)
    t0 = time.time()
    killed_by = None
    stages = []
    if fname == "sf_memory_guard_checker.sv":                      # fastest killer first: the Python vectors
        vec = os.path.join(wd, "v.vec")
        subprocess.run([sys.executable, os.path.join(TB, "gen_vectors.py"), vec, "--tables", "60", "--queries", "400"], check=True, capture_output=True)
        cmd = (f"cd {rtl} && verilator --binary --timing -Wno-fatal -Wno-WIDTH -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM -Wno-DECLFILENAME -Wno-TIMESCALEMOD --Mdir {wd}/vobj "
               f"--top-module tb_checker_vec -o tb_checker_vec -f files.f {TB}/tb_checker_vec.sv > {wd}/vbuild.log 2>&1 && {wd}/vobj/tb_checker_vec +vec={vec} > {wd}/vrun.log 2>&1")
        subprocess.run(["bash", "-c", cmd])
        if not os.path.exists(f"{wd}/vrun.log"):
            return dict(id=mid, file=fname, desc=desc, status="BUILD-ERROR", killed_by="", stages=stages, secs=round(time.time() - t0, 1))
        ok = "TB_RESULT: PASS" in open(f"{wd}/vrun.log").read()
        stages.append(("vectors", not ok))
        if not ok: killed_by = "tb_checker_vec (Python vectors)"
    if not killed_by:
        os.makedirs(f"{wd}/r", exist_ok=True)
        ok, log, built = sim(rtl, "tb_mg_random.sv", f"{wd}/r", ["-GNCYC=40000", "-GSEED=11"])
        if not built:
            return dict(id=mid, file=fname, desc=desc, status="BUILD-ERROR", killed_by="", stages=stages, secs=round(time.time() - t0, 1))
        stages.append(("random", not ok))
        if not ok: killed_by = "tb_mg_random"
    if not killed_by:
        os.makedirs(f"{wd}/d", exist_ok=True)
        ok, log, built = sim(rtl, "tb_mg_directed.sv", f"{wd}/d", [])
        if not built:
            return dict(id=mid, file=fname, desc=desc, status="BUILD-ERROR", killed_by="", stages=stages, secs=round(time.time() - t0, 1))
        stages.append(("directed", not ok))
        if not ok: killed_by = "tb_mg_directed"
    shutil.rmtree(f"{wd}/obj", ignore_errors=True)
    for d in ("r", "d"): shutil.rmtree(f"{wd}/{d}/obj", ignore_errors=True)
    return dict(id=mid, file=fname, desc=desc, status="KILLED" if killed_by else "SURVIVED", killed_by=killed_by or "", stages=stages, secs=round(time.time() - t0, 1),
                note=(MU.EQUIVALENT_IN_SIM.get(mid, "") if not killed_by else ""))

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--jobs", type=int, default=3); ap.add_argument("--only", nargs="*")
    ap.add_argument("--report-only", action="store_true", help="re-write reports/mutation.md from reports/mutation.json")
    a = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)
    ms = [m for m in MU.MUTANTS if not a.only or m[0] in a.only]
    if a.report_only:
        res = json.load(open(os.path.join(ROOT, "reports", "mutation.json")))
        for r in res: r["note"] = MU.EQUIVALENT_IN_SIM.get(r["id"], "") if r["status"] != "KILLED" else ""
    else:
      with ThreadPoolExecutor(a.jobs) as ex:
        res = []
        for r in ex.map(run, ms):
            res.append(r); print(f"{r['status']:9} {r['id']:4} {r['secs']:6.1f}s  {r['killed_by']:38} {r['desc'][:70]}", flush=True)
    rd = os.path.join(ROOT, "reports"); os.makedirs(rd, exist_ok=True)
    json.dump(res, open(os.path.join(rd, "mutation.json"), "w"), indent=1)
    with open(os.path.join(rd, "mutation.md"), "w") as f:
        f.write("# Mutation campaign (simulation)\n\nOne planted RTL defect each (`scripts/mutants.py`).  A mutant is run against the random adversarial testbench (checker mutants first against the "
                "Python vectors); if it survives, against the directed testbench.  KILLED = a run did not print `TB_RESULT: PASS`.\n\n| mutant | file | killed by | result | defect |\n|---|---|---|---|---|\n")
        for r in res: f.write(f"| {r['id']} | {r['file']} | {r['killed_by'] or '-'} | **{r['status']}** | {r['desc']}{(' — ' + r['note']) if r.get('note') else ''} |\n")
        f.write(f"\n{sum(r['status']=='KILLED' for r in res)} / {len(res)} mutants killed.\n")
    sys.exit(0 if all(r["status"] == "KILLED" for r in res) else 1)

if __name__ == "__main__":
    main()
