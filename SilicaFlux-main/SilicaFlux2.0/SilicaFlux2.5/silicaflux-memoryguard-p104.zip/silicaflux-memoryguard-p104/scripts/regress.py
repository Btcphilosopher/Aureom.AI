#!/usr/bin/env python3
"""MemoryGuard simulation regression: builds and runs the testbenches over a configuration matrix (Verilator 5, --binary --timing).

    scripts/regress.py [--jobs N] [--quick] [--only NAME ...] [--list]

A run PASSES iff its log contains `TB_RESULT: PASS`.  Results are written to reports/regression.md and reports/regression.json.
"""
import argparse, json, os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor, as_completed
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.environ.get("MG_OUT", os.path.join(ROOT, "out"))
TB = os.path.join(ROOT, "tests", "memory_guard")

D = "tb_mg_directed.sv"
R = "tb_mg_random.sv"
V = "tb_checker_vec.sv"
A = "tb_mg_adapters.sv"
B = "tb_abi_check.sv"
# name, tb, parameter overrides, claim
RUNS = [
 ("dir_default",        D, {}, "default configuration: 4 domains x 4 regions, 4 ports, AW 16, DW 64"),
 ("dir_pipe1",          D, {"CHK_PIPE": 1}, "registered verdict stage (+1 cycle)"),
 ("dir_lookup1",        D, {"LOOKUP_ARCH": 1}, "domain-first multiplexed lookup"),
 ("dir_strict",         D, {"STRICT": 1}, "strict partition (no byte mapped for two domains)"),
 ("dir_pow2_nodiag",    D, {"LEN_POW2": 1, "DIAG_PRECISE": 0}, "power-of-two lengths only; imprecise diagnostics"),
 ("dir_out1",           D, {"MAXOUT": 1}, "one outstanding memory transaction per port"),
 ("dir_dw256_pipe",     D, {"DW": 256, "CHK_PIPE": 1, "LOOKUP_ARCH": 1}, "256-bit data bus (MemoryMatrix width), registered, muxed"),
 ("dir_nr8_log2",       D, {"NR": 8, "FLOG_DEPTH": 2}, "8 regions per domain, 2-entry fault log"),
 # checker vs the independent Python model: (rtl parameters, generator arguments)
 ("vec_default",        V, ({}, ["--tables", "400", "--queries", "600"]), "240k queries, AW 32, 4 x 4 table, both lookup architectures, fault codes included"),
 ("vec_aw48_nd3_np5",   V, ({"ND": 3, "NR": 3, "NP": 5, "AW": 48}, ["--nd", "3", "--nr", "3", "--np", "5", "--aw", "48", "--tables", "300", "--queries", "600", "--seed", "2"]), "3 domains, 5 ports, 48-bit addresses"),
 ("vec_pow2_nodiag",    V, ({"AW": 20, "LEN_POW2": 1, "DIAG": 0}, ["--aw", "20", "--pow2", "--nodiag", "--tables", "300", "--queries", "600", "--seed", "3"]), "power-of-two lengths, imprecise diagnostics"),
 ("vec_maxlen32",       V, ({"AW": 16, "NR": 8, "MAXLEN": 32, "LW": 6}, ["--aw", "16", "--nr", "8", "--maxlen", "32", "--tables", "300", "--queries", "600", "--seed", "4"]), "32-byte beats (256-bit bus), 8 regions per domain"),
 ("vec_aw63",           V, ({"AW": 63, "NP": 2}, ["--aw", "63", "--np", "2", "--tables", "300", "--queries", "600", "--seed", "5"]), "63-bit address space (largest supported)"),
 ("rnd_default",        R, {"SEED": 1}, "adversarial random, default configuration"),
 ("rnd_default_s2",     R, {"SEED": 2}, "adversarial random, seed 2"),
 ("rnd_pipe1",          R, {"SEED": 3, "CHK_PIPE": 1}, "random, registered verdict"),
 ("rnd_lookup1",        R, {"SEED": 4, "LOOKUP_ARCH": 1}, "random, muxed lookup"),
 ("rnd_strict",         R, {"SEED": 5, "STRICT": 1}, "random, strict partition"),
 ("rnd_pow2",           R, {"SEED": 6, "LEN_POW2": 1, "DIAG_PRECISE": 0}, "random, power-of-two lengths, imprecise diagnostics"),
 ("rnd_out1",           R, {"SEED": 7, "MAXOUT": 1, "CHK_PIPE": 1}, "random, one outstanding per port, registered"),
 ("rnd_2x2x2",          R, {"SEED": 8, "ND": 2, "NR": 2, "NP": 2}, "2 domains, 2 regions, 2 ports"),
 ("rnd_3x3x3",          R, {"SEED": 9, "ND": 3, "NR": 3, "NP": 3}, "3 domains (not a power of two), 3 regions, 3 ports"),
 ("rnd_8x2x8",          R, {"SEED": 10, "ND": 8, "NR": 2, "NP": 8}, "8 domains (no invalid encodings), 8 ports"),
 ("rnd_5x4x6_pipe_lk",  R, {"SEED": 11, "ND": 5, "NR": 4, "NP": 6, "CHK_PIPE": 1, "LOOKUP_ARCH": 1}, "5 domains, 6 ports, registered + muxed"),
 ("rnd_dw128",          R, {"SEED": 12, "DW": 128}, "128-bit data bus"),
 ("rnd_dw32",           R, {"SEED": 15, "DW": 32, "MAXOUT": 2}, "32-bit data bus, 2 outstanding"),
 ("mm_random",          R, {"SEED": 21, "LEN_POW2": 1, "DIAG_PRECISE": 0, "NCYC": 60000, "_args": ["+define+MG_EXT_MEM", "-f", "files_mm.f"]}, "INTEGRATION: the guard in front of the REAL MemoryMatrix (P101, 4 banks, 64 KiB), 4 requesters + host port; end-to-end memory image check"),
 ("mm_random_ecc_pipe", R, {"SEED": 22, "LEN_POW2": 1, "NCYC": 60000, "CHK_PIPE": 1, "MM_ECC": 1, "_args": ["+define+MG_EXT_MEM", "-f", "files_mm.f"]}, "INTEGRATION: MemoryMatrix with SECDED ECC, registered verdict"),
 ("adapters",           A, {}, "check-only adapters: MeridianQoS grd_* and StreamDMA / CloudDMA IOMMU contracts vs the oracle (in-order registered verdicts, fault mapping, pa = addr)"),
 ("adapters_pipe_lk",   A, {"LOOKUP_ARCH": 1, "DIAG_PRECISE": 0}, "the same, multiplexed lookup, imprecise diagnostics"),
 ("abi_check",          B, {}, "op codes, response status codes and the fault code points of the grd_* adapter equal the vendored P102 package"),
 ("rnd_midreset",       R, {"SEED": 13, "MIDRESET": 1}, "reset under load in the middle of the run"),
 ("rnd_deep_strict_pipe", R, {"SEED": 14, "STRICT": 1, "CHK_PIPE": 1, "NCYC": 400000}, "400k cycles, strict, registered"),
]

def run_vec(name, tb, spec, claim):
    params, genargs = spec
    wd = os.path.join(OUT, name)
    os.makedirs(wd, exist_ok=True)
    t0 = time.time()
    vec = os.path.join(wd, "vectors.vec")
    subprocess.run([sys.executable, os.path.join(TB, "gen_vectors.py"), vec] + genargs, check=True, capture_output=True)
    cmd = (f"cd {ROOT}/rtl && verilator --binary --timing -Wno-fatal -Wno-WIDTH -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM -Wno-DECLFILENAME -Wno-TIMESCALEMOD "
           f"--Mdir {wd}/obj --top-module tb_checker_vec -o tb_checker_vec " + " ".join(f"-G{k}={v}" for k, v in params.items()) +
           f" -f files.f {TB}/{tb} > {wd}/build.log 2>&1 && {wd}/obj/tb_checker_vec +vec={vec} > {wd}/run.log 2>&1")
    subprocess.run(["bash", "-c", cmd])
    log = open(os.path.join(wd, "run.log")).read() if os.path.exists(os.path.join(wd, "run.log")) else ""
    ok = "TB_RESULT: PASS" in log
    m = re.search(r"(\d+) queries, (\d+) mismatches", log)
    return {"name": name, "tb": tb, "params": params, "claim": claim, "status": "PASS" if ok else "FAIL", "checks": int(m.group(1)) if m else 0,
            "secs": round(time.time() - t0, 1), "detail": "" if ok else log[-600:]}

def run_abi(name, tb, claim):
    wd = os.path.join(OUT, name); os.makedirs(wd, exist_ok=True); t0 = time.time()
    cmd = (f"cd {ROOT}/rtl && verilator --binary --timing -Wno-fatal -Wno-WIDTH -Wno-UNUSEDSIGNAL -Wno-DECLFILENAME -Wno-TIMESCALEMOD --Mdir {wd}/obj --top-module tb_abi_check "
           f"-o tb_abi_check memory_guard/sf_memory_guard_pkg.sv ../third_party/p102/sf_meridian_qos_pkg.sv {TB}/{tb} > {wd}/build.log 2>&1 && {wd}/obj/tb_abi_check > {wd}/run.log 2>&1")
    subprocess.run(["bash", "-c", cmd])
    log = open(os.path.join(wd, "run.log")).read() if os.path.exists(os.path.join(wd, "run.log")) else ""
    ok = "TB_RESULT: PASS" in log
    m = re.search(r"(\d+) constants compared", log)
    return {"name": name, "tb": tb, "params": {}, "claim": claim, "status": "PASS" if ok else "FAIL", "checks": int(m.group(1)) if m else 0, "secs": round(time.time() - t0, 1), "detail": "" if ok else log[-400:]}

def run(name, tb, params, claim, quick):
    if tb == B:
        return run_abi(name, tb, claim)
    if tb == V:
        return run_vec(name, tb, params, claim)
    wd = os.path.join(OUT, name)
    os.makedirs(wd, exist_ok=True)
    pr = dict(params)
    if quick and "NCYC" in pr:
        pr["NCYC"] = 50000
    elif quick and tb == R:
        pr["NCYC"] = 40000
    extra = pr.pop("_args", [])
    args = [os.path.join(ROOT, "scripts", "run_sim.sh"), os.path.join(TB, tb), wd] + [f"-G{k}={v}" for k, v in pr.items()] + extra
    t0 = time.time()
    p = subprocess.run(args, capture_output=True, text=True, timeout=3600)
    log = ""
    try:
        log = open(os.path.join(wd, "run.log")).read()
    except Exception:
        pass
    ok = "TB_RESULT: PASS" in log
    m = re.search(r"(\d+) checks, (\d+) errors", log)
    checks = int(m.group(1)) if m else 0
    return {"name": name, "tb": tb, "params": pr, "claim": claim, "status": "PASS" if ok else "FAIL", "checks": checks,
            "secs": round(time.time() - t0, 1), "detail": "" if ok else (p.stdout + p.stderr + log)[-600:]}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()
    runs = [r for r in RUNS if not a.only or r[0] in a.only]
    if a.list:
        for r in runs: print(r[0], r[2], "-", r[3]); return
    res = []
    with ThreadPoolExecutor(a.jobs) as ex:
        futs = {ex.submit(run, *r, a.quick): r[0] for r in runs}
        for f in as_completed(futs):
            r = f.result(); res.append(r)
            print(f"{r['status']:5} {r['name']:22} {r['checks']:8} checks  {r['secs']:6.1f}s", flush=True)
            if r["status"] != "PASS": print(r["detail"])
    res.sort(key=lambda r: [x[0] for x in RUNS].index(r["name"]))
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, "reports", "regression.json"), "w"), indent=1)
    with open(os.path.join(ROOT, "reports", "regression.md"), "w") as f:
        f.write("# Simulation regression\n\nVerilator 5.020, `--binary --timing`; a run passes iff its log contains `TB_RESULT: PASS`. "
                "Regenerate with `scripts/regress.py`.\n\n| run | testbench | parameters | checks | result | s | what it covers |\n|---|---|---|---:|---|---:|---|\n")
        for r in res:
            f.write(f"| {r['name']} | {r['tb']} | {', '.join(f'{k}={v}' for k,v in r['params'].items()) or 'defaults'} | {r['checks']} | **{r['status']}** | {r['secs']} | {r['claim']} |\n")
        f.write(f"\n{sum(r['status']=='PASS' for r in res)} / {len(res)} runs passed, {sum(r['checks'] for r in res)} checks in total.\n")
    sys.exit(0 if all(r["status"] == "PASS" for r in res) else 1)

if __name__ == "__main__":
    main()
