#!/usr/bin/env python3
"""Build the delivery archive: MANIFEST.sha256 (SHA-256 of every shipped file) and ../silicaflux-memoryguard-p104.zip.

    scripts/make_zip.py [--manifest-only]

The archive contains the sources, tests, formal harnesses, docs, scripts, reports and benchmark results -- not the generated work directories
(`out/`).  Nothing is committed anywhere: the project is delivered as this archive."""
import hashlib, os, sys, zipfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NAME = os.path.basename(ROOT)
SKIP_DIRS = {"out", "__pycache__", ".git"}
SKIP_FILES = {"MANIFEST.sha256"}

def files():
    for d, dirs, fs in os.walk(ROOT):
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS)
        for f in sorted(fs):
            if f in SKIP_FILES or f.endswith(".pyc"):
                continue
            yield os.path.relpath(os.path.join(d, f), ROOT)

def manifest():
    lines = []
    for rel in files():
        h = hashlib.sha256(open(os.path.join(ROOT, rel), "rb").read()).hexdigest()
        lines.append(f"{h}  {rel}")
    open(os.path.join(ROOT, "MANIFEST.sha256"), "w").write("\n".join(lines) + "\n")
    return len(lines)

def main():
    n = manifest()
    print(f"MANIFEST.sha256: {n} files")
    if "--manifest-only" in sys.argv:
        return
    out = os.path.join(os.path.dirname(ROOT), NAME + ".zip")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel in list(files()) + ["MANIFEST.sha256"]:
            z.write(os.path.join(ROOT, rel), os.path.join(NAME, rel))
    print(f"{out}: {os.path.getsize(out)} bytes")

if __name__ == "__main__":
    main()
