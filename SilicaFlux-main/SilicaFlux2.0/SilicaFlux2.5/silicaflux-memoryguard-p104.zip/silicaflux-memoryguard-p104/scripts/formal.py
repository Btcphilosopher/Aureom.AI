#!/usr/bin/env python3
"""MemoryGuard formal driver: Yosys -> SMT2 -> yosys-smtbmc + z3.

    scripts/formal.py [--only NAME ...] [--jobs N] [--list] [--mutants]

Job kinds
   comb   a purely combinational harness: depth-1 check is a complete proof for ALL inputs ("PASSED" = proved)
   prove  k-induction ("PASSED" = UNBOUNDED proof; base case from reset + induction step)
   bmc    bounded model check from reset ("PASSED" = no violation within DEPTH cycles; NOT an unbounded proof)
   vac    a reachability witness: the assertion MUST fail ("WITNESSED" = the situation is reachable, the proof is not vacuous)
   mut    the same harness on an RTL copy with one planted defect: it MUST fail ("KILLED")
Results: reports/formal.md and reports/formal.json.
"""
import argparse, json, os, re, shutil, subprocess, sys, time, tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import mutants as MU
R = os.path.join(ROOT, "rtl", "memory_guard")
F = os.path.join(ROOT, "formal", "memory_guard")
OUT = os.environ.get("MG_FV_OUT", os.path.join(ROOT, "out", "formal"))
def rtl(*n): return [f"{n_}" for n_ in n]
PKG = "sf_memory_guard_pkg.sv"
GROUPS = {   # harness group -> (top, rtl files, formal files)
  "chk":     ("fv_mg_checker", [PKG, "sf_memory_guard_checker.sv"], ["fv_mg_checker.sv"]),
  "regions": ("fv_mg_regions", [PKG, "sf_memory_guard_regions.sv"], ["fv_mg_regions.sv"]),
  "cfg":     ("fv_mg_cfg", [PKG, "sf_memory_guard_regions.sv", "sf_memory_guard_regs.sv"], ["fv_mg_cfg.sv"]),
  "port":    ("fv_mg_port", [PKG, "sf_memory_guard_checker.sv", "sf_memory_guard_port.sv"], ["fv_mg_spec.sv", "fv_mg_port.sv"]),
  "top":     ("fv_mg_top", [PKG, "sf_memory_guard_checker.sv", "sf_memory_guard_regions.sv", "sf_memory_guard_faults.sv", "sf_memory_guard_regs.sv",
                            "sf_memory_guard_port.sv", "sf_memory_guard.sv"], ["fv_mg_top.sv"]),
}
CHK0 = dict(ND=4, NR=2, NP=3, AW=8, LW=3, PIDX=1, MAXLEN=5, ARCH=0, DIAG=1)
# name, kind, group, chparams, depth, claim
JOBS = [
 # ---- checker: combinational, for ALL inputs
 ("chk_arch0",    "comb", "chk", dict(CHK0), 1, "S0..S5: permit and fault code = independent specification; invalid domains, overflow, whole-range containment (first AND last AND any byte), right and device permission; arch 1 and imprecise diagnostics agree"),
 ("chk_arch1",    "comb", "chk", dict(CHK0, ARCH=1), 1, "the same with the domain-first multiplexed lookup as the design under proof"),
 ("chk_nd3",      "comb", "chk", dict(ND=3, NR=3, NP=4, AW=10, LW=3, PIDX=3, MAXLEN=6, ARCH=0, DIAG=0), 1, "3 domains (not a power of two), 3 regions, 4 ports, imprecise diagnostics"),
 ("chk_pow2",     "comb", "chk", dict(ND=2, NR=3, NP=2, AW=9, LW=4, PIDX=0, MAXLEN=8, ARCH=1, DIAG=1, LEN_POW2=1), 1, "power-of-two lengths only"),
 ("chk_nr4",      "comb", "chk", dict(ND=2, NR=4, NP=3, AW=10, LW=4, PIDX=2, MAXLEN=8, ARCH=0, DIAG=1), 1, "4 regions per domain, 10-bit addresses (the full 4 x 4 x 32-bit instance is beyond z3 -- see docs/memory_guard/08_VERIFICATION.md; the Python vectors cover it by simulation)"),
 ("chk_aw63",     "comb", "chk", dict(ND=2, NR=2, NP=2, AW=63, LW=4, PIDX=1, MAXLEN=8, ARCH=1, DIAG=1), 1, "63-bit address space (largest supported)"),
 # ---- table
 ("regions_ns",   "prove", "regions", dict(ND=3, NR=2, NP=3, AW=6, STRICT=0), 6, "R0..R5: default deny, table invariant (no overlap within a domain, well-formed regions), changes only on commit, validation = specification, effect of each command"),
 ("regions_st",   "prove", "regions", dict(ND=3, NR=2, NP=3, AW=6, STRICT=1), 6, "the same with STRICT partition (no overlap across domains either)"),
 ("regions_big",  "prove", "regions", dict(ND=4, NR=3, NP=4, AW=8, STRICT=0), 6, "4 domains x 3 regions, 4 ports, AW 8"),
 # ---- configuration engine
 ("cfg_ns",       "prove", "cfg", dict(ND=3, NR=2, NP=2, AW=6, STRICT=0), 12, "C1..C7: drain-then-commit, trusted control, lock, privilege, abort, ingress block"),
 ("cfg_st",       "prove", "cfg", dict(ND=3, NR=2, NP=2, AW=6, STRICT=1), 12, "the same with STRICT partition"),
 # ---- one port
 ("port_p0_a0",   "prove", "port", dict(CHK_PIPE=0, ARCH=0), 10, "G1..G7, unbounded: only permitted requests reach the memory, bit for bit; denials; ordered responses; blocking; idle"),
 ("port_p0_a1",   "prove", "port", dict(CHK_PIPE=0, ARCH=1), 10, "the same with the multiplexed lookup"),
 ("port_p1_a0",   "prove", "port", dict(CHK_PIPE=1, ARCH=0), 10, "the same with the registered verdict stage (two requests held)"),
 ("port_p1_a1",   "prove", "port", dict(CHK_PIPE=1, ARCH=1), 10, "registered verdict, multiplexed lookup"),
 ("port_orphan0", "prove", "port", dict(CHK_PIPE=0, ORPHAN=1), 10, "orphan memory responses are drained and never delivered (the memory is NOT assumed well behaved)"),
 ("port_orphan1", "prove", "port", dict(CHK_PIPE=1, ORPHAN=1), 10, "the same with the registered verdict stage"),
 ("port_pow2",    "prove", "port", dict(CHK_PIPE=1, LEN_POW2=1, DIAG=0, MAXOUT=1), 10, "power-of-two lengths, imprecise diagnostics, one outstanding transaction"),
 ("port_big",     "prove", "port", dict(CHK_PIPE=0, ND=4, NR=2, NP=3, AW=8, DW=32, IDW=3, LW=3, MAXLEN=4, MAXOUT=3, PIDX=2), 10, "4 domains, 3 ports, AW 8, 32-bit data, 3 outstanding"),
 # ---- composition
 ("top_p0",       "prove", "top", dict(CHK_PIPE=0), 10, "W1..W5 on the composed design: the table changes only after a commit with every port idle and ingress blocked; no commit under any accepted-unanswered request; blocking_o => not ready"),
 ("top_p1",       "prove", "top", dict(CHK_PIPE=1), 10, "the same with the registered verdict stage"),
 ("top_st",       "prove", "top", dict(CHK_PIPE=0, STRICT=1), 10, "the same with STRICT partition"),
]
# reachability witnesses (the assertion MUST fail)
for v, what in [(1,"a permitted request exists"),(2,"a permitted WRITE reaches the memory"),(3,"a denial is requested"),(4,"a DENIED response"),(5,"a PROTO response"),(6,"an SLVERR passes through"),(8,"ingress block holds a request back"),(9,"the outstanding window fills"),(10,"a denial is retired")]:
    JOBS.append((f"vac_port_{v}", "vac", "port", dict(CHK_PIPE=0, VAC=v), 12, f"witness: {what}"))
JOBS.append(("vac_port_7", "vac", "port", dict(CHK_PIPE=1, VAC=7), 12, "witness: two requests held at once"))
for v, what in [(1,"a command commits"),(2,"a drain times out"),(3,"the lock is set"),(4,"an unprivileged access is refused"),(5,"a commit with regions installed")]:
    JOBS.append((f"vac_cfg_{v}", "vac", "cfg", dict(VAC=v), 18, f"witness: {what}"))
for v, what in [(1,"a region is installed"),(2,"an overlap is refused"),(3,"an out-of-range region is refused"),(4,"a port is bound"),(5,"an install is valid with other regions present")]:
    JOBS.append((f"vac_regions_{v}", "vac", "regions", dict(VAC=v), 8, f"witness: {what}"))
for v, what in [(1,"a permitted request"),(2,"a PERM denial"),(3,"a SPAN denial"),(4,"a DEVICE denial"),(5,"a permitted WRITE"),(6,"a SPOOF denial"),(7,"an OVERFLOW denial"),(8,"a NOMAP denial"),(9,"a grant ending exactly at the top of the address space")]:
    JOBS.append((f"vac_chk_{v}", "vac", "chk", dict(CHK0, VAC=v), 1, f"witness: {what}"))

# mutants: harness job used to catch each (the cheapest configuration of that group)
CATCH = {"chk": "chk_arch0", "regions": "regions_ns", "cfg": "cfg_ns", "port": "port_p0_a0", "top": "top_p0"}


def flow(group, params, files_rtl, outdir, name):
    top, _, ffiles = GROUPS[group]
    chp = " ".join(f"-chparam {k} {v}" for k, v in params.items())
    files = " ".join([os.path.join(files_rtl, f) for f in GROUPS[group][1]] + [os.path.join(F, f) for f in ffiles])
    smt = os.path.join(outdir, name + ".smt2")
    ys = (f"read_verilog -sv -formal -DFORMAL {files}; hierarchy -check -top {top} {chp}; prep -flatten -nordff -top {top}; "
          f"async2sync; dffunmap; opt_clean; write_smt2 -wires {smt}")
    r = subprocess.run(["yosys", "-q", "-p", ys], capture_output=True, text=True)
    return r, smt


def smtbmc(kind, smt, depth, outdir, name):
    cmd = ["yosys-smtbmc", "-s", "z3", "-t", str(depth)] + (["-i"] if kind == "prove" else []) + [smt]
    p = subprocess.run(["bash", "-c", "ulimit -v 12000000; exec timeout 3000 \"$@\"", "_"] + cmd, capture_output=True, text=True)
    out = (p.stdout + p.stderr).replace("\r", "\n")
    open(os.path.join(outdir, name + ".log"), "w").write(out)
    st = re.findall(r"Status: (\w+)", out)
    det = re.search(r"Assert failed in [^\n(]*", out).group(0) if "Assert failed" in out else ""
    det = re.sub(r"(?:/[\w.\-]+)+/(formal/memory_guard/[\w.\-]+)", r"\1", det)          # no absolute paths in the reports
    return (st[-1] if st else "UNKNOWN"), det


def run_job(job):
    name, kind, group, params, depth, claim = job[:6]
    os.makedirs(OUT, exist_ok=True)
    t0 = time.time()
    r, smt = flow(group, params, R, OUT, name)
    if r.returncode != 0:
        return dict(name=name, kind=kind, group=group, params=params, claim=claim, status="ERROR", detail=(r.stdout + r.stderr)[-300:], secs=time.time() - t0, depth=depth)
    st, det = smtbmc("prove" if kind in ("prove",) else "bmc", smt, depth, OUT, name)
    if kind in ("comb", "prove"): status = "PASSED" if st == "PASSED" else ("FAILED" if st == "FAILED" else "UNKNOWN")
    elif kind == "vac":           status = "WITNESSED" if st == "FAILED" else ("NOT-REACHABLE" if st == "PASSED" else st)
    else:                         status = st
    os.remove(smt)
    return dict(name=name, kind=kind, group=group, params=params, claim=claim, status=status, detail=det, secs=round(time.time() - t0, 1), depth=depth)


def run_mutant(m):
    mid, fname, old, new, cnt, desc, groups = m
    res = []
    for g0 in groups:
        g, _, jn = g0.partition(":")
        job = next(j for j in JOBS if j[0] == (jn or CATCH[g]))
        tmp = tempfile.mkdtemp(prefix=f"mut_{mid}_", dir=OUT)
        for f in os.listdir(R): shutil.copy(os.path.join(R, f), tmp)
        src = open(os.path.join(tmp, fname)).read()
        for o_, n_ in zip(old if isinstance(old, list) else [old], new if isinstance(new, list) else [new]):
            assert src.count(o_) >= 1, f"{mid}: pattern not found"
            src = src.replace(o_, n_) if cnt == 0 else src.replace(o_, n_, cnt)
        open(os.path.join(tmp, fname), "w").write(src)
        t0 = time.time()
        r, smt = flow(job[2], job[3], tmp, tmp, "m")
        if r.returncode != 0:
            res.append(dict(name=f"mut_{mid}", kind="mut", group=g, claim=desc, status="ERROR", detail=(r.stdout + r.stderr)[-300:], secs=time.time() - t0)); continue
        st, det = smtbmc("prove" if job[1] == "prove" else "bmc", smt, job[4], tmp, "m")
        res.append(dict(name=f"mut_{mid}", kind="mut", group=g, claim=desc, caught_by=job[0], status="KILLED" if st == "FAILED" else ("SURVIVED" if st == "PASSED" else st),
                        detail=det, secs=round(time.time() - t0, 1)))
        shutil.rmtree(tmp, ignore_errors=True)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*"); ap.add_argument("--jobs", type=int, default=2); ap.add_argument("--list", action="store_true")
    ap.add_argument("--mutants", action="store_true", help="also run the mutation campaign"); ap.add_argument("--mutants-only", action="store_true")
    a = ap.parse_args()
    os.makedirs(OUT, exist_ok=True)
    jobs = [j for j in JOBS if (not a.only or j[0] in a.only)] if not a.mutants_only else []
    if a.list:
        for j in JOBS: print(j[0], j[1], j[2], j[3], "-", j[5]); return
    results = []
    with ThreadPoolExecutor(a.jobs) as ex:
        futs = [ex.submit(run_job, j) for j in jobs]
        if a.mutants or a.mutants_only:
            futs += [ex.submit(run_mutant, m) for m in MU.MUTANTS if m[6] and (not a.only or m[0] in a.only)]
        for f in as_completed(futs):
            r = f.result()
            for x in (r if isinstance(r, list) else [r]):
                results.append(x)
                print(f"{x['status']:14} {x['name']:18} {x['secs']:7.1f}s  {x.get('detail','')[:90]}", flush=True)
    order = {j[0]: i for i, j in enumerate(JOBS)}
    results.sort(key=lambda x: (x["kind"] == "mut", order.get(x["name"], 1000), x["name"]))
    rd = os.path.join(ROOT, "reports"); os.makedirs(rd, exist_ok=True)
    prev = {}
    if os.path.exists(os.path.join(rd, "formal.json")) and a.only:
        for x in json.load(open(os.path.join(rd, "formal.json"))): prev[(x["name"], x.get("group"))] = x
    for x in results: prev[(x["name"], x.get("group"))] = x
    allr = sorted(prev.values(), key=lambda x: (x["kind"] == "mut", order.get(x["name"], 1000), x["name"]))
    json.dump(allr, open(os.path.join(rd, "formal.json"), "w"), indent=1)
    with open(os.path.join(rd, "formal.md"), "w") as f:
        f.write("# Formal verification results\n\nYosys 0.33 -> SMT2 -> `yosys-smtbmc` + z3.  Regenerate with `scripts/formal.py --mutants`.\n\n"
                "* **PASSED** on a `comb` job: proved for ALL inputs.  **PASSED** on a `prove` job: UNBOUNDED proof (base case + k-induction).\n"
                "* **WITNESSED**: a reachability witness failed as it must (the harness is not vacuous).  **KILLED**: a planted defect was caught.\n\n"
                "| job | kind | harness | parameters | depth | result | s | what it establishes |\n|---|---|---|---|---:|---|---:|---|\n")
        for x in allr:
            if x["kind"] == "mut": continue
            f.write(f"| {x['name']} | {x['kind']} | {x['group']} | {', '.join(f'{k}={v}' for k,v in x['params'].items())} | {x.get('depth','')} | **{x['status']}** | {x['secs']} | {x['claim']} |\n")
        muts = [x for x in allr if x["kind"] == "mut"]
        if muts:
            f.write("\n## Mutation campaign (formal)\n\nOne planted RTL defect each; the harness named must FAIL.\n\n| mutant | harness | caught by | result | defect |\n|---|---|---|---|---|\n")
            for x in muts: f.write(f"| {x['name']} | {x['group']} | {x.get('caught_by','')} | **{x['status']}** | {x['claim']} |\n")
        ok = [x for x in allr if x["kind"] != "mut"]
        bad = [x for x in allr if x["status"] in ("FAILED", "UNKNOWN", "ERROR", "SURVIVED", "NOT-REACHABLE")]
        f.write(f"\n{len(allr)} jobs, {len(bad)} not as expected.\n")
    sys.exit(1 if any(x["status"] in ("FAILED", "UNKNOWN", "ERROR", "SURVIVED", "NOT-REACHABLE") for x in results) else 0)

if __name__ == "__main__":
    main()
