#!/usr/bin/env python3
"""Area / logic-depth study of MemoryGuard with Yosys 0.33 -- TECHNOLOGY-INDEPENDENT (no liberty file or PDK exists in the repository).

For every configuration the design is flattened and mapped three ways:
   gates   `synth` + `abc -g AND,NAND,OR,NOR,XOR,XNOR,ANDNOT,ORNOT,MUX`   -> generic 2-input cells (+ MUX), flops separate
   lut6    `synth` + `abc -lut 6`                                          -> LUT6 count (an FPGA-style proxy)
   depth   `ltp -noff` of both mapped netlists                             -> longest combinational path in gates / in LUT6 levels
`ge` = NAND2-equivalent estimate with the weights in WEIGHTS (NAND/NOR 1.0, AND/OR 1.33, XOR 2.33, MUX 2.33, NOT 0.67); a flop counts 5 GE.  These are
ESTIMATES for comparing configurations; they are not post-layout numbers and nothing here is a silicon measurement.
usage: synth.py [--quick]     writes benchmarks/memory_guard/results/synth.json and synth.md
"""
import itertools, json, os, re, subprocess, sys
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
R = os.path.join(ROOT, "rtl", "memory_guard")
FILES = ["sf_memory_guard_pkg.sv", "sf_memory_guard_checker.sv", "sf_memory_guard_regions.sv", "sf_memory_guard_faults.sv", "sf_memory_guard_regs.sv",
         "sf_memory_guard_port.sv", "sf_memory_guard.sv"]
WEIGHTS = {"$_AND_": 1.33, "$_OR_": 1.33, "$_NAND_": 1.0, "$_NOR_": 1.0, "$_XOR_": 2.33, "$_XNOR_": 2.33, "$_ANDNOT_": 1.33, "$_ORNOT_": 1.33, "$_NOT_": 0.67, "$_MUX_": 2.33}
FLOP_GE = 5.0
OUT = os.environ.get("MG_OUT", os.path.join(ROOT, "out")) + "/synth"

def yosys(top, params, mapcmd, tag):
    chp = " ".join(f"-chparam {k} {v}" for k, v in params.items())
    files = " ".join(os.path.join(R, f) for f in FILES)
    ys = (f"read_verilog -sv {files}; hierarchy -check -top {top} {chp}; synth -flatten -top {top}; {mapcmd}; opt_clean -purge; tee -o {OUT}/{tag}.stat stat; tee -o {OUT}/{tag}.ltp ltp -noff")
    r = subprocess.run(["yosys", "-q", "-p", ys], capture_output=True, text=True)
    st = open(f"{OUT}/{tag}.stat").read(); lt = open(f"{OUT}/{tag}.ltp").read()
    return st, lt

def parse(st, lt):
    cells = {m.group(1): int(m.group(2)) for m in re.finditer(r"^\s+(\$\w+)\s+(\d+)\s*$", st, re.M)}
    flops = sum(n for c, n in cells.items() if "DFF" in c)
    comb = {c: n for c, n in cells.items() if "DFF" not in c}
    ge = sum(WEIGHTS.get(c, 1.5) * n for c, n in comb.items()) + FLOP_GE * flops
    depth = re.search(r"Longest topological path in .*? \(length=(\d+)\)", lt)
    return dict(comb=sum(comb.values()), flops=flops, ge=round(ge), depth=int(depth.group(1)) if depth else None, cells=cells)

def one(cfg):
    name, top, params = cfg
    os.makedirs(OUT, exist_ok=True)
    g = parse(*yosys(top, params, "abc -g AND,NAND,OR,NOR,XOR,XNOR,ANDNOT,ORNOT,MUX", name + "_g"))
    l = parse(*yosys(top, params, "abc -lut 6", name + "_l"))
    lut = sum(n for c, n in l["cells"].items() if "lut" in c.lower())
    return dict(name=name, top=top, params=params, gates=g["comb"], flops=g["flops"], ge=g["ge"], gate_depth=g["depth"], lut6=lut, lut_depth=l["depth"])

def main():
    quick = "--quick" in sys.argv
    cfgs = []
    # (1) the checker of ONE port: parallel comparators, area growth with domains and regions, lookup architecture, diagnostic precision
    for nd, nr, arch, diag in itertools.product([2, 4, 8, 16], [2, 4, 8], [0, 1], [0, 1]):
        if quick and (nd, nr) not in ((4, 4), (8, 4)): continue
        cfgs.append((f"chk_nd{nd}_nr{nr}_a{arch}_d{diag}", "sf_memory_guard_checker", dict(ND=nd, NR=nr, NP=4, AW=32, LW=4, DOMW=4 if nd > 8 else 3, PIDX=0, MAXLEN=8, LOOKUP_ARCH=arch, DIAG_PRECISE=diag)))
    for aw in (24, 32, 40, 48):
        cfgs.append((f"chk_aw{aw}", "sf_memory_guard_checker", dict(ND=4, NR=4, NP=4, AW=aw, LW=4, DOMW=3, PIDX=0, MAXLEN=8, LOOKUP_ARCH=0, DIAG_PRECISE=1)))
    # (2) the whole guard
    for nd, np_, pipe, arch in itertools.product([2, 4, 8], [2, 4, 8], [0, 1], [0, 1]):
        if (nd, np_) not in ((2, 4), (4, 2), (4, 4), (4, 8), (8, 4)): continue
        if arch == 1 and (nd, np_) != (4, 4): continue
        if quick and (nd, np_) not in ((4, 4),): continue
        cfgs.append((f"top_nd{nd}_np{np_}_p{pipe}_a{arch}", "sf_memory_guard", dict(ND=nd, NR=4, NP=np_, AW=32, DW=64, IDW=8, DOMW=3, MAXOUT=4, CHK_PIPE=pipe, LOOKUP_ARCH=arch, DIAG_PRECISE=1, FLOG_DEPTH=8)))
    for nr in (2, 4, 8):
        cfgs.append((f"top_nr{nr}", "sf_memory_guard", dict(ND=4, NR=nr, NP=4, AW=32, DW=64, IDW=8, DOMW=3, MAXOUT=4, CHK_PIPE=0, LOOKUP_ARCH=0, DIAG_PRECISE=1, FLOG_DEPTH=8)))
    for dw in (32, 64, 128, 256):
        cfgs.append((f"top_dw{dw}", "sf_memory_guard", dict(ND=4, NR=4, NP=4, AW=32, DW=dw, IDW=8, DOMW=3, MAXOUT=4, CHK_PIPE=0, LOOKUP_ARCH=0, DIAG_PRECISE=1, FLOG_DEPTH=8)))
    with ThreadPoolExecutor(3) as ex: res = list(ex.map(one, cfgs))
    write_outputs(res)

def write_outputs(res):
        rd = os.path.join(ROOT, "benchmarks", "memory_guard", "results"); os.makedirs(rd, exist_ok=True)
        json.dump(res, open(os.path.join(rd, "synth.json"), "w"), indent=1)
        with open(os.path.join(rd, "synth.md"), "w") as f:
            f.write("# Synthesis study (Yosys 0.33, technology independent)\n\n`gates` = generic 2-input cells + MUX after ABC; `flops`; `ge` = NAND2-equivalent estimate (weights in synth.py, flop = 5 GE); "
                    "`gate depth` = longest combinational path in those cells; `lut6` / `lut depth` = ABC `-lut 6` mapping.  **Estimates for comparison only: no ASIC library or PDK exists in the repository, "
                    "no timing was measured, nothing here is a silicon number.**\n\n| config | gates | flops | ge | gate depth | lut6 | lut depth |\n|---|---:|---:|---:|---:|---:|---:|\n")
            for r in res: f.write(f"| {r['name']} | {r['gates']} | {r['flops']} | {r['ge']} | {r['gate_depth']} | {r['lut6']} | {r['lut_depth']} |\n")


def reparse(extra=True):
    """re-read the saved Yosys reports (LUT counts) and add the per-port gate configurations; used after the long sweep"""
    rd = os.path.join(ROOT, "benchmarks", "memory_guard", "results")
    res = json.load(open(os.path.join(rd, "synth.json")))
    for r in res:
        l = parse(open(f"{OUT}/{r['name']}_l.stat").read(), open(f"{OUT}/{r['name']}_l.ltp").read())
        r["lut6"] = sum(n for c, n in l["cells"].items() if "lut" in c.lower())
    if extra:
        for pipe in (0, 1):
            r = one((f"port_p{pipe}", "sf_memory_guard_port", dict(ND=4, NR=4, NP=4, AW=32, DW=64, IDW=8, LW=4, DOMW=3, PIDX=0, MAXLEN=8, MAXOUT=4, CHK_PIPE=pipe, LOOKUP_ARCH=0, DIAG_PRECISE=1, LEN_POW2=0)))
            res = [x for x in res if x["name"] != r["name"]] + [r]
    write_outputs(res)

if __name__ == "__main__":
    if "--reparse" in sys.argv: reparse()
    else: main()
