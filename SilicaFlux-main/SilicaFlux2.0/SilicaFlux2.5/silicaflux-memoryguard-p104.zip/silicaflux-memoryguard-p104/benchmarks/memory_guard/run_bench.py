#!/usr/bin/env python3
"""Throughput / latency of the protected path: builds tests/memory_guard/tb_mg_bench.sv for each (CHK_PIPE, MAXOUT) and sweeps the memory
latency and the denied fraction at run time.  Output: benchmarks/memory_guard/results/bench.md / bench.json."""
import itertools, json, os, re, subprocess, sys
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.environ.get("MG_OUT", os.path.join(ROOT, "out")) + "/bench"
def build(pipe, maxout, arch):
    wd = f"{OUT}/p{pipe}_o{maxout}_a{arch}"; os.makedirs(wd, exist_ok=True)
    subprocess.run([f"{ROOT}/scripts/run_sim.sh", f"{ROOT}/tests/memory_guard/tb_mg_bench.sv", wd, f"-GCHK_PIPE={pipe}", f"-GMAXOUT={maxout}", f"-GLOOKUP_ARCH={arch}"], capture_output=True, text=True)
    return pipe, maxout, arch, f"{wd}/obj/tb_mg_bench"
def runs(b):
    pipe, maxout, arch, exe = b
    res = []
    for memlat, den, npn in itertools.product([1, 2, 4, 8], [0, 50, 100], [1, 4]):
        o = subprocess.run([exe, f"+memlat={memlat}", f"+den={den}", f"+nports={npn}"], capture_output=True, text=True).stdout
        m = re.search(r"BENCH .*resp_per_cycle_per_port=([\d.]+) latency_avg=([\d.]+)", o)
        if m and "TB_RESULT: PASS" in o: res.append(dict(CHK_PIPE=pipe, MAXOUT=maxout, ARCH=arch, memlat=memlat, den=den, ports=npn, thr=float(m.group(1)), lat=float(m.group(2))))
        else: res.append(dict(CHK_PIPE=pipe, MAXOUT=maxout, ARCH=arch, memlat=memlat, den=den, ports=npn, thr=None, lat=None, err=o[-200:]))
    return res
def main():
    cfgs = [(p, o, 0) for p in (0, 1) for o in (1, 2, 4, 8)] + [(0, 4, 1), (1, 4, 1)]
    with ThreadPoolExecutor(3) as ex: builds = list(ex.map(lambda c: build(*c), cfgs))
    with ThreadPoolExecutor(3) as ex: results = [r for rs in ex.map(runs, builds) for r in rs]
    os.makedirs(f"{ROOT}/benchmarks/memory_guard/results", exist_ok=True)
    json.dump(results, open(f"{ROOT}/benchmarks/memory_guard/results/bench.json", "w"), indent=1)
    with open(f"{ROOT}/benchmarks/memory_guard/results/bench.md", "w") as f:
        f.write("# Throughput and latency of the protected path\n\nVerilator, 4000-cycle window after warm-up, 8-byte requests at full rate, always-ready memory of fixed latency L.\n"
                "`thr` = responses per cycle per port; `lat` = accept edge to response edge (cycles), average over the window.\n\n| CHK_PIPE | MAXOUT | lookup | ports | L | denied % | thr | lat |\n|---:|---:|---:|---:|---:|---:|---:|---:|\n")
        for r in results:
            f.write(f"| {r['CHK_PIPE']} | {r['MAXOUT']} | {r['ARCH']} | {r['ports']} | {r['memlat']} | {r['den']} | {r['thr'] if r['thr'] is not None else 'ERR'} | {r['lat'] if r['lat'] is not None else 'ERR'} |\n")
if __name__ == "__main__":
    main()
