// =============================================================================
// MemoryGuard formal harness: the COMPOSITION (sf_memory_guard = ports + table + configuration engine + fault log).
// Proves the properties that exist only at system level, by k-induction (z3):
//   W1  assumption E4 of fv_mg_port holds on the real composition: the table (valid bits, bindings, base, end of every region) changes
//       only in a cycle that follows a commit, and a commit happens only with EVERY port idle and ingress blocked
//   W2  blocking_o => no port accepts a request (r_ready = 0 everywhere)
//   W3  (assume-guarantee) with the port-level guarantee G6 -- idle <=> nothing accepted and unanswered, proved in fv_mg_port --
//       a commit never happens while ANY request, on ANY port, is accepted and unanswered (counted on the top-level handshakes only)
//   W4  (see fv_mg_cfg C2: a commit is always the consequence of an accepted, privileged, error-free R_CMD write)
//   W5  an unprivileged access always answers with the error flag and zero data
// Together with fv_mg_port (authorisation, provenance, ordered responses: for every table that obeys E4), fv_mg_cfg (the engine that
// guarantees E4), fv_mg_checker (permit = specification) and fv_mg_regions (table invariant), this is the assume-guarantee proof of
// docs/memory_guard/08_VERIFICATION.md.  The composed design is additionally exercised by the simulations (monitors M1..M6).
// =============================================================================
`default_nettype none
module fv_mg_top #(
  parameter ND = 3, parameter NR = 2, parameter NP = 2, parameter AW = 5, parameter DW = 16, parameter IDW = 2, parameter DOMW = 3,
  parameter MAXOUT = 2, parameter CHK_PIPE = 0, parameter STRICT = 0,
  localparam BW = DW / 8, LW = $clog2(BW + 1), NE = ND * NR
) (
  input wire clk, input wire rst_n,
  input wire [NP-1:0] r_valid, input wire [NP*2-1:0] r_op, input wire [NP*AW-1:0] r_addr, input wire [NP*LW-1:0] r_len,
  input wire [NP*DW-1:0] r_wdata, input wire [NP*BW-1:0] r_be, input wire [NP*IDW-1:0] r_id, input wire [NP*DOMW-1:0] r_dom,
  input wire [NP-1:0] s_ready, input wire [NP-1:0] m_ready,
  input wire [NP-1:0] d_valid, input wire [NP*DW-1:0] d_rdata, input wire [NP*IDW-1:0] d_id, input wire [NP-1:0] d_we, input wire [NP-1:0] d_err,
  input wire cfg_req_valid, input wire cfg_req_write, input wire [7:0] cfg_req_addr, input wire [31:0] cfg_req_wdata, input wire [3:0] cfg_req_wstrb,
  input wire cfg_req_priv, input wire cfg_rsp_ready
);
  wire [NP-1:0] r_ready, s_valid, s_we, m_valid, m_we, d_ready; wire [NP*DW-1:0] s_rdata, m_wdata; wire [NP*IDW-1:0] s_id, m_id; wire [NP*3-1:0] s_status;
  wire [NP*AW-1:0] m_addr; wire [NP*LW-1:0] m_len; wire [NP*BW-1:0] m_be; wire [NP*DOMW-1:0] m_dom;
  wire cfg_req_ready, cfg_rsp_valid, cfg_rsp_error; wire [31:0] cfg_rsp_rdata; wire idle_o, blocking_o;
  wire [NP-1:0] fv_p_idle; wire fv_cm_en; wire [NE-1:0] fv_t_valid; wire [NP*ND-1:0] fv_t_allow; wire [NE*AW-1:0] fv_t_base; wire [NE*(AW+1)-1:0] fv_t_end;
  sf_memory_guard #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .DW(DW), .IDW(IDW), .DOMW(DOMW), .MAXOUT(MAXOUT), .CHK_PIPE(CHK_PIPE), .STRICT(STRICT),
                    .FLOG_DEPTH(2), .CNTW(2)) dut (
    .clk(clk), .rst_n(rst_n), .r_valid(r_valid), .r_ready(r_ready), .r_op(r_op), .r_addr(r_addr), .r_len(r_len), .r_wdata(r_wdata), .r_be(r_be), .r_id(r_id),
    .r_dom(r_dom), .s_valid(s_valid), .s_ready(s_ready), .s_rdata(s_rdata), .s_id(s_id), .s_we(s_we), .s_status(s_status),
    .m_valid(m_valid), .m_ready(m_ready), .m_we(m_we), .m_addr(m_addr), .m_len(m_len), .m_wdata(m_wdata), .m_be(m_be), .m_id(m_id), .m_dom(m_dom),
    .d_valid(d_valid), .d_ready(d_ready), .d_rdata(d_rdata), .d_id(d_id), .d_we(d_we), .d_err(d_err),
    .cfg_req_valid(cfg_req_valid), .cfg_req_ready(cfg_req_ready), .cfg_req_write(cfg_req_write), .cfg_req_addr(cfg_req_addr), .cfg_req_wdata(cfg_req_wdata),
    .cfg_req_wstrb(cfg_req_wstrb), .cfg_req_priv(cfg_req_priv), .cfg_rsp_valid(cfg_rsp_valid), .cfg_rsp_ready(cfg_rsp_ready), .cfg_rsp_rdata(cfg_rsp_rdata),
    .cfg_rsp_error(cfg_rsp_error), .idle_o(idle_o), .blocking_o(blocking_o),
    .fv_p_idle(fv_p_idle), .fv_cm_en(fv_cm_en), .fv_t_valid(fv_t_valid), .fv_t_allow(fv_t_allow), .fv_t_base(fv_t_base), .fv_t_end(fv_t_end));

  reg f_init = 1'b1;
  always @(posedge clk) f_init <= 1'b0;
  always @(*) if (f_init) assume(!rst_n); else assume(rst_n);
  reg p_cv, p_cr; reg [1+8+32+4+1-1:0] p_creq; wire [1+8+32+4+1-1:0] creq = {cfg_req_write, cfg_req_addr, cfg_req_wdata, cfg_req_wstrb, cfg_req_priv};
  always @(posedge clk) begin p_cv <= cfg_req_valid; p_cr <= cfg_req_ready; p_creq <= creq; end
  always @(*) if (!f_init && p_cv && !p_cr) begin assume(cfg_req_valid); assume(creq == p_creq); end

  // ---- ghosts on the top-level handshakes: accepted-and-unanswered requests per port
  reg [3:0] n_out [0:NP-1]; integer p;
  always @(posedge clk) begin
    for (p = 0; p < NP; p = p + 1) begin
      if (f_init) n_out[p] <= 4'd0;
      else n_out[p] <= n_out[p] + {3'd0, (r_valid[p] && r_ready[p])} - {3'd0, (s_valid[p] && s_ready[p])};
    end
  end
  always @(*) if (!f_init) for (p = 0; p < NP; p = p + 1) assume(fv_p_idle[p] == (n_out[p] == 4'd0));    // G6 of fv_mg_port (assume-guarantee)

  // ---- bus ghosts
  wire acc = cfg_req_valid && cfg_req_ready;
  reg p_acc_unpriv;
  always @(posedge clk) p_acc_unpriv <= !f_init && acc && !cfg_req_priv;

  reg [NE-1:0] p_tv; reg [NP*ND-1:0] p_ta; reg [NE*AW-1:0] p_tb; reg [NE*(AW+1)-1:0] p_te; reg p_cm, p_blk; reg [NP-1:0] p_idle_v; reg p_init1;
  always @(posedge clk) begin p_tv <= fv_t_valid; p_ta <= fv_t_allow; p_tb <= fv_t_base; p_te <= fv_t_end; p_cm <= fv_cm_en; p_blk <= blocking_o; p_idle_v <= fv_p_idle; p_init1 <= f_init; end
  integer j;
  always @(*) if (!f_init && !p_init1) begin
    // W1: the table changes only after a commit; a commit needs everything idle and ingress blocked
    if (!p_cm) begin
      assert(fv_t_valid == p_tv); assert(fv_t_allow == p_ta);
      for (j = 0; j < NE; j = j + 1) if (p_tv[j]) begin
        assert(fv_t_base[j*AW +: AW] == p_tb[j*AW +: AW]); assert(fv_t_end[j*(AW+1) +: (AW+1)] == p_te[j*(AW+1) +: (AW+1)]);
      end
    end
    if (fv_cm_en) begin assert(&fv_p_idle); assert(blocking_o); end
  end
  always @(*) if (!f_init) begin
    // W2
    if (blocking_o) assert(r_ready == {NP{1'b0}});
    // W3: from the top-level handshakes alone
    if (fv_cm_en) for (p = 0; p < NP; p = p + 1) assert(n_out[p] == 4'd0);
    // W5
    if (p_acc_unpriv && cfg_rsp_valid) begin assert(cfg_rsp_error); assert(cfg_rsp_rdata == 32'd0); end
  end
endmodule
`default_nettype wire
