// =============================================================================
// MemoryGuard formal harness: the trusted configuration path = sf_memory_guard_regs + sf_memory_guard_regions, driven by a FREE
// configuration bus, a FREE `drained` signal and free diagnostics.  Proved UNBOUNDED by k-induction (z3).
//
//   C1  drain-then-commit    the table changes only in a cycle with cm_en; cm_en only when every port is idle (drained) AND ingress is
//                            blocked (blk), and only for a command that validated against the current table  (this DISCHARGES assumption
//                            E4 of fv_mg_port: the table cannot change under a request that is held or outstanding)
//   C2  trusted control      cm_en only after a privileged, unlocked, error-free write of R_CMD (observed on the bus, not inside the design)
//   C3  lock                 after an error-free privileged write of CTRL.LOCK, nothing ever commits again
//   C4  privilege            an unprivileged access always answers with the error flag and zero data
//   C5  abort                a drain timeout leaves the table unchanged and releases ingress
//   C6  ingress block        blk is high exactly while a command is draining, and falls with the commit / abort
//   C7  region invariant     (embedded in sf_memory_guard_regions) no two valid regions overlap; every region is well formed
// =============================================================================
`default_nettype none
module fv_mg_cfg #(
  parameter ND = 3, parameter NR = 2, parameter NP = 2, parameter AW = 6, parameter STRICT = 0, parameter IDW = 2, parameter LW = 2,
  parameter DOMW = 3, parameter MAXOUT = 2, parameter FDEPTH = 2, parameter CNTW = 4, parameter VAC = 0,
  localparam NE = ND * NR, PW = (NP > 1) ? $clog2(NP) : 1, CW = (FDEPTH + 1 > 1) ? $clog2(FDEPTH + 1) : 1, NCNT = 9 + 2 * NP + 16
) (
  input wire         clk,
  input wire         rst_n,
  input wire         cfg_req_valid,
  input wire         cfg_req_write,
  input wire [7:0]   cfg_req_addr,
  input wire [31:0]  cfg_req_wdata,
  input wire [3:0]   cfg_req_wstrb,
  input wire         cfg_req_priv,
  input wire         cfg_rsp_ready,
  input wire         drained,
  input wire [CW-1:0] fl_cnt,
  input wire [IDW-1:0] fl_id,
  input wire [AW-1:0] fl_addr,
  input wire [LW-1:0] fl_len,
  input wire [3:0]   fl_fault,
  input wire [1:0]   fl_op,
  input wire [PW-1:0] fl_port,
  input wire [DOMW-1:0] fl_dom,
  input wire [15:0]  fl_gen,
  input wire [31:0]  fl_seq,
  input wire [15:0]  fl_dropped16,
  input wire [NCNT*CNTW-1:0] cnt_flat,
  input wire         fl_ev_drop, fl_ev_orphan, fl_ev_fault
);
  wire cfg_req_ready, cfg_rsp_valid, cfg_rsp_error; wire [31:0] cfg_rsp_rdata;
  wire cm_en, cm_ok, cm_r, cm_w, cm_devn; wire [3:0] cm_kind, cm_dom, cm_idx, cm_port, cm_err; wire [63:0] cm_base, cm_size; wire [7:0] cm_dev; wire [15:0] cm_allow;
  wire [3:0] rd_dom, rd_idx, rd_port; wire rd_valid, rd_r, rd_w, rd_devn; wire [63:0] rd_base, rd_end; wire [7:0] rd_dev; wire [15:0] rd_allow;
  wire fv_lock, fv_busy;
  wire blk, fl_pop, ev_sec, ev_lockrej, ev_commit, ev_cmdrej, ev_tmo; wire [15:0] gen16;
  wire [NE-1:0] t_valid, t_r, t_w, t_devn; wire [NE*AW-1:0] t_base; wire [NE*(AW+1)-1:0] t_end; wire [NE*NP-1:0] t_dev; wire [NP*ND-1:0] t_allow;

  sf_memory_guard_regions #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .STRICT(STRICT)) u_reg (
    .clk(clk), .rst_n(rst_n), .cm_en(cm_en), .cm_kind(cm_kind), .cm_dom(cm_dom), .cm_idx(cm_idx), .cm_port(cm_port), .cm_base(cm_base), .cm_size(cm_size),
    .cm_r(cm_r), .cm_w(cm_w), .cm_devn(cm_devn), .cm_dev(cm_dev), .cm_allow(cm_allow), .cm_ok(cm_ok), .cm_err(cm_err),
    .rd_dom(rd_dom), .rd_idx(rd_idx), .rd_port(rd_port), .rd_valid(rd_valid), .rd_base(rd_base), .rd_end(rd_end), .rd_r(rd_r), .rd_w(rd_w), .rd_devn(rd_devn),
    .rd_dev(rd_dev), .rd_allow(rd_allow),
    .t_valid(t_valid), .t_base(t_base), .t_end(t_end), .t_r(t_r), .t_w(t_w), .t_devn(t_devn), .t_dev(t_dev), .t_allow(t_allow));
  sf_memory_guard_regs #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .DBYTES(2), .IDW(IDW), .LW(LW), .DOMW(DOMW), .MAXOUT(MAXOUT), .FDEPTH(FDEPTH), .CNTW(CNTW),
                         .STRICT(STRICT), .CHK_PIPE(0)) u_regs (
    .clk(clk), .rst_n(rst_n),
    .cfg_req_valid(cfg_req_valid), .cfg_req_ready(cfg_req_ready), .cfg_req_write(cfg_req_write), .cfg_req_addr(cfg_req_addr), .cfg_req_wdata(cfg_req_wdata),
    .cfg_req_wstrb(cfg_req_wstrb), .cfg_req_priv(cfg_req_priv), .cfg_rsp_valid(cfg_rsp_valid), .cfg_rsp_ready(cfg_rsp_ready), .cfg_rsp_rdata(cfg_rsp_rdata),
    .cfg_rsp_error(cfg_rsp_error),
    .cm_en(cm_en), .cm_kind(cm_kind), .cm_dom(cm_dom), .cm_idx(cm_idx), .cm_port(cm_port), .cm_base(cm_base), .cm_size(cm_size), .cm_r(cm_r), .cm_w(cm_w),
    .cm_devn(cm_devn), .cm_dev(cm_dev), .cm_allow(cm_allow), .cm_ok(cm_ok), .cm_err(cm_err),
    .rd_dom(rd_dom), .rd_idx(rd_idx), .rd_port(rd_port), .rd_valid(rd_valid), .rd_base(rd_base), .rd_end(rd_end), .rd_r(rd_r), .rd_w(rd_w), .rd_devn(rd_devn),
    .rd_dev(rd_dev), .rd_allow(rd_allow), .blk(blk), .drained(drained), .gen16(gen16),
    .fl_cnt(fl_cnt), .fl_id(fl_id), .fl_addr(fl_addr), .fl_len(fl_len), .fl_fault(fl_fault), .fl_op(fl_op), .fl_port(fl_port), .fl_dom(fl_dom), .fl_gen(fl_gen),
    .fl_seq(fl_seq), .fl_dropped16(fl_dropped16), .fl_pop(fl_pop), .cnt_flat(cnt_flat), .fl_ev_drop(fl_ev_drop), .fl_ev_orphan(fl_ev_orphan), .fl_ev_fault(fl_ev_fault),
    .ev_sec(ev_sec), .ev_lockrej(ev_lockrej), .ev_commit(ev_commit), .ev_cmdrej(ev_cmdrej), .ev_tmo(ev_tmo), .fv_lock(fv_lock), .fv_busy(fv_busy));

  reg f_init = 1'b1;
  always @(posedge clk) f_init <= 1'b0;
  always @(*) if (f_init) assume(!rst_n); else assume(rst_n);

  // bus protocol: a request is held, unchanged, until accepted
  reg p_valid, p_ready; reg [1+8+32+4+1-1:0] p_req;
  wire [1+8+32+4+1-1:0] req = {cfg_req_write, cfg_req_addr, cfg_req_wdata, cfg_req_wstrb, cfg_req_priv};
  always @(posedge clk) begin p_valid <= cfg_req_valid; p_ready <= cfg_req_ready; p_req <= req; end
  always @(*) if (!f_init && p_valid && !p_ready) begin assume(cfg_req_valid); assume(req == p_req); end

  // ------------------------------------------------------------------ black-box ghosts, observed ONLY on the bus
  localparam [4:0] W_CMD = 5'd14, W_CTRL = 5'd2;
  wire acc = cfg_req_valid && cfg_req_ready;
  reg p_acc_cmd, p_acc_lock, p_acc_unpriv;
  always @(posedge clk) begin
    p_acc_cmd    <= !f_init && acc && cfg_req_priv && cfg_req_write && cfg_req_addr == {1'b0, W_CMD, 2'b00} && cfg_req_wstrb == 4'hF;
    p_acc_lock   <= !f_init && acc && cfg_req_priv && cfg_req_write && cfg_req_addr == {1'b0, W_CTRL, 2'b00} && cfg_req_wstrb == 4'hF && cfg_req_wdata[31];
    p_acc_unpriv <= !f_init && acc && !cfg_req_priv;
  end
  wire cmd_ok_now  = p_acc_cmd  && cfg_rsp_valid && !cfg_rsp_error;       // the response to a privileged R_CMD write says: accepted
  wire lock_ok_now = p_acc_lock && cfg_rsp_valid && !cfg_rsp_error;
  reg g_pend, g_lock;
  always @(posedge clk) begin
    if (f_init) begin g_pend <= 1'b0; g_lock <= 1'b0; end
    else begin
      g_pend <= (g_pend || cmd_ok_now) && !(cm_en || ev_tmo);
      g_lock <= g_lock || lock_ok_now;
    end
  end

  // previous-cycle table / blocking, for "changes only on commit"
  reg [NE-1:0] p_tv; reg [NP*ND-1:0] p_ta; reg [NE*AW-1:0] p_tb; reg [NE*(AW+1)-1:0] p_te; reg p_cm_en, p_blk, p_tmo;
  always @(posedge clk) begin p_tv <= t_valid; p_ta <= t_allow; p_tb <= t_base; p_te <= t_end; p_cm_en <= cm_en; p_blk <= blk; p_tmo <= ev_tmo; end
  integer j;

  always @(*) if (!f_init) begin
    // C1
    assert(!(cm_en && !drained));
    assert(!(cm_en && !blk));
    assert(!(cm_en && !cm_ok));
    // C2: a commit is always the consequence of an accepted, privileged, error-free R_CMD write
    assert(!blk || g_pend || cmd_ok_now);
    assert(!cm_en || g_pend || cmd_ok_now);
    // refinement of the black-box ghosts onto the design
    assert(!g_lock || fv_lock);
    assert(!g_pend || fv_busy);
    assert(blk == fv_busy);
    // C3
    assert(!(g_lock && cm_en));
    assert(!(g_lock && blk));
    assert(!(lock_ok_now && blk));
    // C4
    if (p_acc_unpriv && cfg_rsp_valid) begin assert(cfg_rsp_error); assert(cfg_rsp_rdata == 32'd0); end
  end
  always @(*) if (!f_init && !f_prev_init) begin
    // C1 (table): nothing changes without a commit in the previous cycle
    if (!p_cm_en) begin
      assert(t_valid == p_tv); assert(t_allow == p_ta);
      for (j = 0; j < NE; j = j + 1) if (p_tv[j]) begin
        assert(t_base[j*AW +: AW] == p_tb[j*AW +: AW]);
        assert(t_end[j*(AW+1) +: (AW+1)] == p_te[j*(AW+1) +: (AW+1)]);
      end
    end
    // C5 / C6: ingress is released the cycle after a commit or an abort, and not before
    if (p_cm_en || p_tmo) assert(!blk);
    if (p_cm_en) assert(!cm_en);
    if (p_tmo) assert(t_valid == p_tv && t_allow == p_ta);
  end
  reg f_prev_init = 1'b1;
  always @(posedge clk) f_prev_init <= f_init;
  // reachability witnesses (VAC != 0): each MUST fail
  always @(*) if (!f_init && VAC != 0) begin
    case (VAC)
      1: assert(!cm_en);                    // a command commits
      2: assert(!ev_tmo);                   // a drain times out
      3: assert(!g_lock);                   // the lock is set
      4: assert(!(cfg_req_valid && !cfg_req_priv && cfg_rsp_valid && cfg_rsp_error));   // an unprivileged access is refused
      5: assert(!(cm_en && drained && p_blk && t_valid != {NE{1'b0}}));   // a commit happens with regions installed
      default: assert(1'b1);
    endcase
  end
endmodule
`default_nettype wire
