// =============================================================================
// MemoryGuard formal harness: sf_memory_guard_port -- AUTHORISATION, PROVENANCE and RESPONSES of one protected ingress port, proved
// UNBOUNDED by k-induction (z3) through an explicit refinement mapping between the RTL's registers and three ghost queues:
//   AQ  accepted-not-retired requests (= the stage registers)   FQ  forwarded-not-answered (= the outstanding counter)
//   RQ  one expected response per accepted request, in acceptance order, with its expected class
// For ALL request streams, ALL tables and ALL back-pressure patterns.
//
//   E1 requester holds a presented request until accepted        E2 a presented memory response is held, unchanged, until accepted
//   E3 [ORPHAN = 0] the memory answers only forwarded requests, in order, echoing id and direction
//   E4 THE TABLE changes only in a cycle following one in which this port was idle AND ingress was blocked   (the in-flight policy;
//      discharged by fv_mg_cfg: the drain engine commits only when every port is idle, with ingress blocked)
//   E5 a fault-log grant is given only to a requester
//
//   M   refinement mapping   the ghost queue AQ of accepted-not-retired requests is exactly the RTL's stage registers (A, and B when
//                            CHK_PIPE = 1) and the verdict held for the acting request is the specification's verdict
//   G1  m_valid => AQ head, permitted by the INDEPENDENT specification for this port and the table; the memory-side request is that
//       request bit for bit (byte enables clipped to [addr, addr+len); a READ carries no data)
//   G2  ev_req (a denial) => AQ head the specification denies; the fault record is exactly {id, addr, len, specified fault, op, claimed domain}
//   G3  nothing is driven on the memory side unless m_valid
//   G4  m_* and s_* held until accepted; blk => the port accepts nothing; idle <=> nothing accepted and unanswered
//   G5  one response per accepted request, IN ORDER: permitted -> OKAY / SLVERR from the memory, denied -> DENIED, malformed -> PROTO, with the
//       request's id and direction, no data on an error, an error only after every earlier answer; no response without a request
//   G7  [ORPHAN = 1] a memory response with nothing outstanding never reaches the requester
// =============================================================================
`default_nettype none
module fv_mg_port #(
  parameter ND = 3, parameter NR = 2, parameter NP = 2, parameter AW = 6, parameter DW = 16, parameter IDW = 2,
  parameter LW = 2, parameter DOMW = 3, parameter PIDX = 1, parameter MAXLEN = 2, parameter MAXOUT = 2,
  parameter CHK_PIPE = 0, parameter ARCH = 0, parameter DIAG = 1, parameter LEN_POW2 = 0, parameter ORPHAN = 0,
  parameter VAC = 0,                                    // != 0: reachability witnesses -- the assertion MUST fail
  localparam BW = DW / 8, NE = ND * NR, RECW = IDW + AW + LW + 4 + 2 + DOMW, EW = 2 + AW + LW + DW + BW + IDW + DOMW,
  localparam OW = (MAXOUT > 1) ? $clog2(MAXOUT + 1) : 1
) (
  input wire               clk,
  input wire               rst_n,
  input wire               blk,
  input wire               r_valid,
  input wire [1:0]         r_op,
  input wire [AW-1:0]      r_addr,
  input wire [LW-1:0]      r_len,
  input wire [DW-1:0]      r_wdata,
  input wire [BW-1:0]      r_be,
  input wire [IDW-1:0]     r_id,
  input wire [DOMW-1:0]    r_dom,
  input wire               s_ready,
  input wire               m_ready,
  input wire               d_valid,
  input wire [DW-1:0]      d_rdata,
  input wire [IDW-1:0]     d_id,
  input wire               d_we,
  input wire               d_err,
  input wire               ev_gnt,
  input wire [ND-1:0]      allow,
  input wire [NE-1:0]      t_valid,
  input wire [NE*AW-1:0]   t_base,
  input wire [NE*(AW+1)-1:0] t_end,
  input wire [NE-1:0]      t_r, t_w, t_devn,
  input wire [NE*NP-1:0]   t_dev
);
  wire r_ready, s_valid, s_we, m_valid, m_we, d_ready, ev_req, ev_fwd, ev_orphan, idle;
  wire [DW-1:0] s_rdata, m_wdata; wire [IDW-1:0] s_id, m_id; wire [2:0] s_status; wire [AW-1:0] m_addr; wire [LW-1:0] m_len;
  wire [BW-1:0] m_be; wire [DOMW-1:0] m_dom; wire [RECW-1:0] ev_rec;
  wire fv_a_valid, fv_b_valid, fv_err_valid, fv_b_permit, fv_err_we; wire [OW-1:0] fv_fwd_cnt; wire [EW-1:0] fv_a_ent, fv_b_ent; wire [3:0] fv_act_fault;
  wire [IDW-1:0] fv_err_id; wire [2:0] fv_err_st;
  sf_memory_guard_port #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .DW(DW), .IDW(IDW), .LW(LW), .DOMW(DOMW), .PIDX(PIDX), .MAXLEN(MAXLEN),
                         .MAXOUT(MAXOUT), .CHK_PIPE(CHK_PIPE), .LOOKUP_ARCH(ARCH), .DIAG_PRECISE(DIAG), .LEN_POW2(LEN_POW2)) dut (
    .clk(clk), .rst_n(rst_n), .blk(blk),
    .r_valid(r_valid), .r_ready(r_ready), .r_op(r_op), .r_addr(r_addr), .r_len(r_len), .r_wdata(r_wdata), .r_be(r_be), .r_id(r_id), .r_dom(r_dom),
    .s_valid(s_valid), .s_ready(s_ready), .s_rdata(s_rdata), .s_id(s_id), .s_we(s_we), .s_status(s_status),
    .m_valid(m_valid), .m_ready(m_ready), .m_we(m_we), .m_addr(m_addr), .m_len(m_len), .m_wdata(m_wdata), .m_be(m_be), .m_id(m_id), .m_dom(m_dom),
    .d_valid(d_valid), .d_ready(d_ready), .d_rdata(d_rdata), .d_id(d_id), .d_we(d_we), .d_err(d_err),
    .allow(allow), .t_valid(t_valid), .t_base(t_base), .t_end(t_end), .t_r(t_r), .t_w(t_w), .t_devn(t_devn), .t_dev(t_dev),
    .ev_req(ev_req), .ev_gnt(ev_gnt), .ev_rec(ev_rec), .ev_fwd(ev_fwd), .ev_orphan(ev_orphan), .idle(idle),
    .fv_a_valid(fv_a_valid), .fv_b_valid(fv_b_valid), .fv_err_valid(fv_err_valid), .fv_fwd_cnt(fv_fwd_cnt), .fv_a_ent(fv_a_ent),
    .fv_b_ent(fv_b_ent), .fv_b_permit(fv_b_permit), .fv_act_fault(fv_act_fault), .fv_err_id(fv_err_id), .fv_err_st(fv_err_st), .fv_err_we(fv_err_we));

  reg f_init = 1'b1;
  always @(posedge clk) f_init <= 1'b0;
  always @(*) if (f_init) assume(!rst_n); else assume(rst_n);

  wire [EW-1:0] r_ent = {r_op, r_addr, r_len, r_wdata, r_be, r_id, r_dom};
  wire [NE+NE*AW+NE*(AW+1)+3*NE+NE*NP+ND-1:0] tbl = {t_valid, t_base, t_end, t_r, t_w, t_devn, t_dev, allow};
  reg [EW-1:0] p_r_ent; reg p_rvalid, p_rready;
  reg [NE+NE*AW+NE*(AW+1)+3*NE+NE*NP+ND-1:0] p_tbl; reg p_idle, p_blk;
  reg p_mvalid, p_mready, p_dvalid, p_dready, p_svalid, p_sready; reg [DW+IDW+2-1:0] p_dpay; reg [DW+IDW+1+3-1:0] p_spay;
  reg p_mvalid_, p_mready_; reg [1+AW+LW+DW+BW+IDW+DOMW-1:0] p_mpay;
  wire [1+AW+LW+DW+BW+IDW+DOMW-1:0] mpay = {m_we, m_addr, m_len, m_wdata, m_be, m_id, m_dom};
  wire [DW+IDW+1+3-1:0] spay = {s_rdata, s_id, s_we, s_status};
  always @(posedge clk) begin
    p_dvalid <= d_valid; p_dready <= d_ready; p_dpay <= {d_rdata, d_id, d_we, d_err}; p_svalid <= s_valid; p_sready <= s_ready; p_spay <= spay;
    p_r_ent <= r_ent; p_rvalid <= r_valid; p_rready <= r_ready; p_tbl <= tbl; p_idle <= idle; p_blk <= blk;
    p_mvalid <= m_valid; p_mready <= m_ready; p_mpay <= mpay;
  end
  always @(*) if (!f_init) begin
    if (p_rvalid && !p_rready) begin assume(r_valid); assume(r_ent == p_r_ent); end          // E1
    assume((tbl == p_tbl) || (p_idle && p_blk));                                              // E4
    assume(!ev_gnt || ev_req);                                                                // E5
    if (p_dvalid && !p_dready) begin assume(d_valid); assume({d_rdata, d_id, d_we, d_err} == p_dpay); end   // E2
  end

  // ------------------------------------------------------------------ ghost: accepted queue AQ (depth 2)
  reg [EW-1:0] aq0, aq1; reg [1:0] aq_cnt;
  wire acc = r_valid && r_ready;
  wire fwd_fire = m_valid && m_ready;
  wire deny_fire = ev_req && ev_gnt;
  wire pop = fwd_fire || deny_fire;
  always @(posedge clk) begin
    if (f_init) aq_cnt <= 2'd0;
    else begin
      case ({acc, pop})
        2'b10: begin if (aq_cnt == 2'd0) aq0 <= r_ent; else aq1 <= r_ent; aq_cnt <= aq_cnt + 2'd1; end
        2'b01: begin aq0 <= aq1; aq_cnt <= aq_cnt - 2'd1; end
        2'b11: begin if (aq_cnt == 2'd1) aq0 <= r_ent; else begin aq0 <= aq1; aq1 <= r_ent; end end
        default: ;
      endcase
    end
  end
  wire [EW-1:0] h = aq0;
  wire [1:0]        h_op   = h[EW-1 -: 2];
  wire [AW-1:0]     h_addr = h[EW-3 -: AW];
  wire [LW-1:0]     h_len  = h[EW-3-AW -: LW];
  wire [DW-1:0]     h_wd   = h[EW-3-AW-LW -: DW];
  wire [BW-1:0]     h_be   = h[EW-3-AW-LW-DW -: BW];
  wire [IDW-1:0]    h_id   = h[EW-3-AW-LW-DW-BW -: IDW];
  wire [DOMW-1:0]   h_dom  = h[DOMW-1:0];

  wire sp_h_permit; wire [3:0] sp_h_fault;
  fv_mg_spec #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .LW(LW), .DOMW(DOMW), .PIDX(PIDX), .MAXLEN(MAXLEN), .LEN_POW2(LEN_POW2), .DIAG(DIAG)) u_sh (
    .op(h_op), .addr(h_addr), .len(h_len), .dom(h_dom), .allow(allow), .t_valid(t_valid), .t_base(t_base), .t_end(t_end), .t_r(t_r), .t_w(t_w),
    .t_devn(t_devn), .t_dev(t_dev), .permit(sp_h_permit), .fault(sp_h_fault));
  reg [BW-1:0] lane; integer jj;
  always @* for (jj = 0; jj < BW; jj = jj + 1) lane[jj] = (jj < h_len);

  // ------------------------------------------------------------------ ghost: forwarded queue FQ and expected-response queue RQ
  localparam RQD = 2 + MAXOUT;
  reg [IDW:0] fq [0:MAXOUT-1]; reg [3:0] fq_cnt, fq_rp, fq_wp;
  wire d_take = d_valid && d_ready && (fq_cnt != 0);
  always @(posedge clk) begin
    if (f_init) begin fq_cnt <= 0; fq_rp <= 0; fq_wp <= 0; end
    else begin
      if (fwd_fire) begin fq[fq_wp] <= {h_op == 2'd1, h_id}; fq_wp <= (fq_wp == MAXOUT - 1) ? 4'd0 : fq_wp + 4'd1; end
      if (d_take)   begin fq_rp <= (fq_rp == MAXOUT - 1) ? 4'd0 : fq_rp + 4'd1; end
      fq_cnt <= fq_cnt + {3'd0, fwd_fire} - {3'd0, d_take};
    end
  end
  wire [IDW:0] fq_h = fq[fq_rp];
  generate if (ORPHAN == 0) begin : g_e3
    always @(*) if (!f_init && d_valid) begin assume(fq_cnt != 0); assume(d_id == fq_h[IDW-1:0]); assume(d_we == fq_h[IDW]); end   // E3
  end endgenerate

  // RQ entry: {kind[1:0] (0 permitted, 1 denied, 2 malformed), we, id}
  wire sp_i_permit; wire [3:0] sp_i_fault;
  fv_mg_spec #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .LW(LW), .DOMW(DOMW), .PIDX(PIDX), .MAXLEN(MAXLEN), .LEN_POW2(LEN_POW2), .DIAG(DIAG)) u_si (
    .op(r_op), .addr(r_addr), .len(r_len), .dom(r_dom), .allow(allow), .t_valid(t_valid), .t_base(t_base), .t_end(t_end), .t_r(t_r), .t_w(t_w),
    .t_devn(t_devn), .t_dev(t_dev), .permit(sp_i_permit), .fault(sp_i_fault));
  reg [IDW+3:0] rq [0:RQD-1]; reg [3:0] rq_cnt, rq_rp, rq_wp;
  function [1:0] kind_of(input permit, input [3:0] f);
    kind_of = permit ? 2'd0 : ((f == 4'd4 || f == 4'd5 || f == 4'd6 || f == 4'd7 || f == 4'd10) ? 2'd2 : 2'd1);
  endfunction
  wire [1:0] in_kind = kind_of(sp_i_permit, sp_i_fault);
  wire rsp_hs = s_valid && s_ready;
  always @(posedge clk) begin
    if (f_init) begin rq_cnt <= 0; rq_rp <= 0; rq_wp <= 0; end
    else begin
      if (acc) begin rq[rq_wp] <= {in_kind, (r_op == 2'd1), r_id}; rq_wp <= (rq_wp == RQD - 1) ? 4'd0 : rq_wp + 4'd1; end
      if (rsp_hs) rq_rp <= (rq_rp == RQD - 1) ? 4'd0 : rq_rp + 4'd1;
      rq_cnt <= rq_cnt + {3'd0, acc} - {3'd0, rsp_hs};
    end
  end
  wire [IDW+3:0] rq_h = rq[rq_rp];
  wire [1:0]     rq_kind = rq_h[IDW+2:IDW+1];
  wire           rq_we   = rq_h[IDW];
  wire [IDW-1:0] rq_id   = rq_h[IDW-1:0];

  // the specification's class of each held request (the table is stable while anything is held)
  wire sp_a_permit; wire [3:0] sp_a_fault;
  fv_mg_spec #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .LW(LW), .DOMW(DOMW), .PIDX(PIDX), .MAXLEN(MAXLEN), .LEN_POW2(LEN_POW2), .DIAG(DIAG)) u_s1 (
    .op(aq1[EW-1 -: 2]), .addr(aq1[EW-3 -: AW]), .len(aq1[EW-3-AW -: LW]), .dom(aq1[DOMW-1:0]), .allow(allow), .t_valid(t_valid), .t_base(t_base), .t_end(t_end),
    .t_r(t_r), .t_w(t_w), .t_devn(t_devn), .t_dev(t_dev), .permit(sp_a_permit), .fault(sp_a_fault));

  integer jq; reg [IDW+3:0] e; reg [3:0] pos;

  // which stage register is the ACTING one
  wire act_valid = (CHK_PIPE == 0) ? fv_a_valid : fv_b_valid;

  // ------------------------------------------------------------------ refinement mapping (inductive invariants)
  always @(*) if (!f_init) begin
    // M1: the ghost queue is the stage registers
    if (CHK_PIPE == 0) begin
      assert(fv_b_valid == 1'b0);
      assert(aq_cnt == {1'b0, fv_a_valid});
      if (fv_a_valid) assert(aq0 == fv_a_ent);
    end else begin
      assert(aq_cnt == {1'b0, fv_a_valid} + {1'b0, fv_b_valid});
      if (fv_b_valid) begin assert(aq0 == fv_b_ent); if (fv_a_valid) assert(aq1 == fv_a_ent); end
      else if (fv_a_valid) assert(aq0 == fv_a_ent);
    end
    // M2: the verdict that is acted on is the specification's verdict for that request (the table is stable while anything is held)
    if (act_valid) begin
      assert(fv_b_permit == sp_h_permit);
      assert(fv_act_fault == sp_h_fault);
    end
  end

  // ------------------------------------------------------------------ refinement mapping for the response path
  always @(*) if (!f_init) begin
    assert(fq_rp < MAXOUT && fq_wp < MAXOUT && fq_wp == ((fq_rp + fq_cnt) % MAXOUT));        // pointers of the ghost queues
    assert(rq_rp < RQD && rq_wp < RQD && rq_wp == ((rq_rp + rq_cnt) % RQD));
    assert(fq_cnt == {{(4-OW){1'b0}}, fv_fwd_cnt});                                         // R1
    assert(rq_cnt == fq_cnt + {3'd0, fv_err_valid} + {2'd0, aq_cnt});                      // R2: every accepted request is in exactly one place
    assert(!(fv_err_valid && fq_cnt != 0));                                                // R4
    assert(rq_cnt <= RQD && fq_cnt <= MAXOUT);
    // R3: the order of RQ is  [ forwarded ... | pending error | held in the stage registers ... ]
    for (jq = 0; jq < RQD; jq = jq + 1) begin
      e = rq[(rq_rp + jq) % RQD];
      if (jq < fq_cnt) begin
        assert(e[IDW+2:IDW+1] == 2'd0);
        assert(e[IDW:0] == fq[(fq_rp + jq) % MAXOUT]);
      end else if (jq == fq_cnt && fv_err_valid) begin
        assert(e[IDW+2:IDW+1] != 2'd0);
        assert(e[IDW-1:0] == fv_err_id); assert(e[IDW] == fv_err_we);
        assert(fv_err_st == ((e[IDW+2:IDW+1] == 2'd2) ? 3'd5 : 3'd3));
      end
    end
    pos = fq_cnt + {3'd0, fv_err_valid};
    if (aq_cnt >= 2'd1) begin
      e = rq[(rq_rp + pos) % RQD];
      assert(e[IDW-1:0] == h_id); assert(e[IDW] == (h_op == 2'd1)); assert(e[IDW+2:IDW+1] == kind_of(sp_h_permit, sp_h_fault));
    end
    if (aq_cnt == 2'd2) begin
      e = rq[(rq_rp + pos + 4'd1) % RQD];
      assert(e[IDW-1:0] == aq1[EW-3-AW-LW-DW-BW -: IDW]); assert(e[IDW] == (aq1[EW-1 -: 2] == 2'd1)); assert(e[IDW+2:IDW+1] == kind_of(sp_a_permit, sp_a_fault));
    end
    // G4 (responses), G5, G7
    if (p_svalid && !p_sready) begin assert(s_valid); assert(spay == p_spay); end
    assert(idle == (rq_cnt == 4'd0));
    if (s_valid) begin
      assert(rq_cnt != 4'd0);
      if (rq_kind == 2'd0) begin
        assert(fq_cnt != 0);
        if (ORPHAN == 0) begin assert(s_status == (d_err ? 3'd1 : 3'd0)); assert(s_id == rq_id); assert(s_we == rq_we); assert(s_rdata == d_rdata); end
      end else begin
        assert(s_status == ((rq_kind == 2'd2) ? 3'd5 : 3'd3)); assert(s_id == rq_id); assert(s_rdata == {DW{1'b0}}); assert(s_we == rq_we);
        assert(fq_cnt == 0);
      end
    end
    if (fq_cnt == 0 && !fv_err_valid) assert(!s_valid);                                    // G7: an orphan is never delivered
  end

  // ------------------------------------------------------------------ properties
  always @(*) if (!f_init) begin
    // G1
    if (m_valid) begin
      assert(aq_cnt != 2'd0);
      assert(sp_h_permit);
      assert(m_we == (h_op == 2'd1)); assert(m_addr == h_addr); assert(m_len == h_len); assert(m_id == h_id); assert(m_dom == h_dom);
      if (h_op == 2'd1) begin assert(m_wdata == h_wd); assert(m_be == (h_be & lane)); end
      else begin assert(m_wdata == {DW{1'b0}}); assert(m_be == {BW{1'b0}}); end
    end
    // G3
    if (!m_valid) begin
      assert(!m_we); assert(m_addr == {AW{1'b0}}); assert(m_len == {LW{1'b0}}); assert(m_wdata == {DW{1'b0}}); assert(m_be == {BW{1'b0}});
      assert(m_id == {IDW{1'b0}}); assert(m_dom == {DOMW{1'b0}});
    end
    // G2
    if (ev_req) begin
      assert(aq_cnt != 2'd0);
      assert(!sp_h_permit);
      assert(ev_rec == {h_id, h_addr, h_len, sp_h_fault, h_op, h_dom});
    end
    assert(!(m_valid && ev_req));
    assert(!(pop && aq_cnt == 2'd0));
    // G4
    assert(!(blk && r_ready));
    if (p_mvalid && !p_mready) begin assert(m_valid); assert(mpay == p_mpay); end
  end

  // ------------------------------------------------------------------ reachability witnesses (VAC != 0): each assertion MUST fail, proving the
  // proof harness is not vacuous (the environment assumptions leave these situations reachable)
  always @(*) if (!f_init && VAC != 0) begin
    case (VAC)
      1:  assert(!m_valid);                                      // a request is forwarded
      2:  assert(!(m_valid && m_we));                            // a permitted WRITE reaches the memory
      3:  assert(!ev_req);                                       // a denial is requested
      4:  assert(!(s_valid && s_status == 3'd3));                // a DENIED response
      5:  assert(!(s_valid && s_status == 3'd5));                // a PROTO response
      6:  assert(!(s_valid && s_status == 3'd1));                // an SLVERR response passes through
      7:  assert(!(aq_cnt == 2'd2));                             // two requests held at once (CHK_PIPE = 1)
      8:  assert(!(blk && r_valid));                             // a request is held back by the drain block
      9:  assert(!(m_valid && m_ready && fq_cnt == (MAXOUT - 1)));   // the outstanding window fills
      10: assert(!(ev_req && ev_gnt && fq_cnt == 0 && s_ready));     // a denial is retired
      default: assert(1'b1);
    endcase
  end
endmodule
`default_nettype wire
