// =============================================================================
// MemoryGuard formal harness: sf_memory_guard_checker.  PURELY COMBINATIONAL: the properties hold for ALL requests, ALL tables and
// ALL port bindings (every input is free), i.e. they are proved, not sampled.  Depth 1 is therefore a complete proof.
//
//   S0  verdict equivalence      permit and the native fault code equal an independent specification (64-bit arithmetic, one loop
//                                 over every region of every domain, no code shared with the RTL)
//   S1  invalid domains          permit => the claim is < ND and inside the port's trusted binding
//   S2  address overflow         permit => addr + len <= 2**AW  (computed in 64 bits)  and  1 <= len <= MAXLEN
//   S3  boundary / whole range   permit => ONE valid region of the claimed domain contains the first byte AND the last byte AND every
//                                 byte (a free byte offset k < len is checked too), grants the right and the device permission
//   S4  decision / diagnosis     permit <=> fault == FT_NONE
//   S5  lookup architectures     LOOKUP_ARCH 0 and 1 give identical permit, fault and domain; DIAG_PRECISE changes only FT_SPAN <-> FT_NOMAP
//   V*  vacuity                  (VAC != 0) the same harness with an assertion that MUST FAIL: permit, FT_PERM, FT_SPAN, FT_DEVICE, ... are reachable
// =============================================================================
`default_nettype none
module fv_mg_checker #(
  parameter ND = 4, parameter NR = 2, parameter NP = 3, parameter AW = 8, parameter LW = 3, parameter DOMW = 3,
  parameter PIDX = 1, parameter MAXLEN = 5, parameter LEN_POW2 = 0, parameter ARCH = 0, parameter DIAG = 1,
  parameter VAC = 0,
  localparam NE = ND * NR
) (
  input wire [1:0]            op,
  input wire [AW-1:0]         addr,
  input wire [LW-1:0]         len,
  input wire [DOMW-1:0]       dom,
  input wire [ND-1:0]         allow,
  input wire [NE-1:0]         t_valid,
  input wire [NE*AW-1:0]      t_base,
  input wire [NE*(AW+1)-1:0]  t_end,
  input wire [NE-1:0]         t_r, t_w, t_devn,
  input wire [NE*NP-1:0]      t_dev,
  input wire [LW-1:0]         k                 // a free byte offset
);
  wire permit, permit_o, permit_nd;
  wire [3:0] fault, fault_o, fault_nd;
  wire [DOMW-1:0] edom, edom_o, edom_nd;
  sf_memory_guard_checker #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .LW(LW), .DOMW(DOMW), .PIDX(PIDX), .MAXLEN(MAXLEN), .LEN_POW2(LEN_POW2),
                            .LOOKUP_ARCH(ARCH), .DIAG_PRECISE(DIAG)) dut (
    .c_op(op), .c_addr(addr), .c_len(len), .c_dom(dom), .allow(allow), .t_valid(t_valid), .t_base(t_base), .t_end(t_end),
    .t_r(t_r), .t_w(t_w), .t_devn(t_devn), .t_dev(t_dev), .permit(permit), .fault(fault), .edom(edom));
  sf_memory_guard_checker #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .LW(LW), .DOMW(DOMW), .PIDX(PIDX), .MAXLEN(MAXLEN), .LEN_POW2(LEN_POW2),
                            .LOOKUP_ARCH(1 - ARCH), .DIAG_PRECISE(DIAG)) other (
    .c_op(op), .c_addr(addr), .c_len(len), .c_dom(dom), .allow(allow), .t_valid(t_valid), .t_base(t_base), .t_end(t_end),
    .t_r(t_r), .t_w(t_w), .t_devn(t_devn), .t_dev(t_dev), .permit(permit_o), .fault(fault_o), .edom(edom_o));
  sf_memory_guard_checker #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .LW(LW), .DOMW(DOMW), .PIDX(PIDX), .MAXLEN(MAXLEN), .LEN_POW2(LEN_POW2),
                            .LOOKUP_ARCH(ARCH), .DIAG_PRECISE(1 - DIAG)) nodiag (
    .c_op(op), .c_addr(addr), .c_len(len), .c_dom(dom), .allow(allow), .t_valid(t_valid), .t_base(t_base), .t_end(t_end),
    .t_r(t_r), .t_w(t_w), .t_devn(t_devn), .t_dev(t_dev), .permit(permit_nd), .fault(fault_nd), .edom(edom_nd));

  // ------------------------------------------------------------------ independent specification
  reg  [63:0] a, l, e, sp;
  reg         sp_permit, any_perm, any_cont, any_cont_dev, any_ovl, gcov, byte_ok;
  reg  [3:0]  sp_fault;
  reg  [63:0] bs, en;
  integer     ee;
  always @* begin
    a = {{(64-AW){1'b0}}, addr}; l = {{(64-LW){1'b0}}, len}; e = a + l; sp = 64'd1 << AW;
    any_perm = 0; any_cont = 0; any_cont_dev = 0; any_ovl = 0; gcov = 0;
    for (ee = 0; ee < NE; ee = ee + 1) begin
      bs = {{(64-AW){1'b0}}, t_base[ee*AW +: AW]};
      en = {{(63-AW){1'b0}}, t_end[ee*(AW+1) +: (AW+1)]};
      if (t_valid[ee] && ((ee / NR) == dom)) begin
        if (a >= bs && e <= en) begin
          any_cont = 1;
          if (!t_devn[ee] || t_dev[ee*NP + PIDX]) begin
            any_cont_dev = 1;
            if (op == 2'd1 ? t_w[ee] : t_r[ee]) begin
              any_perm = 1;
              // S3 witness: this region contains the first byte, the last byte and the free byte a + k (if k < len)
              byte_ok = (k >= len) || ((a + {{(64-LW){1'b0}}, k}) >= bs && (a + {{(64-LW){1'b0}}, k}) < en);
              if (a >= bs && (a + l - 64'd1) < en && byte_ok) gcov = 1;
            end
          end
        end else if (a < en && bs < e) any_ovl = 1;
      end
    end
    if      (op > 2'd1)                                               sp_fault = 4'd6;     // BADOP
    else if (len == 0)                                                sp_fault = 4'd5;     // ZEROLEN
    else if (len > MAXLEN || (LEN_POW2 != 0 && (len & (len - 1)) != 0)) sp_fault = 4'd10;  // BADLEN
    else if (e > sp)                                                  sp_fault = 4'd4;     // OVERFLOW
    else if (dom >= ND)                                               sp_fault = 4'd7;     // BADDOM
    else if (!allow[dom])                                             sp_fault = 4'd8;     // SPOOF
    else if (any_perm)                                                sp_fault = 4'd0;
    else if (any_cont && !any_cont_dev)                               sp_fault = 4'd9;     // DEVICE
    else if (any_cont)                                                sp_fault = 4'd2;     // PERM
    else if (DIAG != 0 && any_ovl)                                    sp_fault = 4'd3;     // SPAN
    else                                                              sp_fault = 4'd1;     // NOMAP
    sp_permit = (sp_fault == 4'd0);
  end

  // ------------------------------------------------------------------ properties
  always @* begin
    if (VAC == 0) begin
      assert(permit == sp_permit);                                    // S0
      assert(fault == sp_fault);                                      // S0 (the diagnosis too)
      assert(edom == dom);
      if (permit) begin
        assert(dom < ND);                                             // S1
        assert(allow[dom]);
        assert(e <= sp);                                              // S2
        assert(len >= 1 && len <= MAXLEN);
        assert(gcov);                                                 // S3: one region contains the whole range, grants right + device
      end
      assert(permit == (fault == 4'd0));                              // S4
      assert(permit == permit_o && fault == fault_o && edom == edom_o);        // S5: lookup architectures agree exactly
      assert(permit == permit_nd);                                    // S5: precise diagnostics never change the decision
      assert(fault == fault_nd || (fault == 4'd3 && fault_nd == 4'd1) || (fault == 4'd1 && fault_nd == 4'd3));
    end else begin
      case (VAC)
        1: assert(!permit);                                           // a permitted request exists
        2: assert(fault != 4'd2);                                     // PERM reachable
        3: assert(fault != 4'd3);                                     // SPAN reachable
        4: assert(fault != 4'd9);                                     // DEVICE reachable
        5: assert(!(permit && op == 2'd1));                           // a permitted WRITE exists
        6: assert(fault != 4'd8);                                     // SPOOF reachable
        7: assert(fault != 4'd4);                                     // OVERFLOW reachable
        8: assert(fault != 4'd1);                                     // NOMAP reachable
        9: assert(!(permit && (a + l) == sp));                        // a grant ending exactly at the top of the address space exists
        default: assert(1'b1);
      endcase
    end
  end
endmodule
`default_nettype wire
