// =============================================================================
// MemoryGuard formal harness: sf_memory_guard_regions (the permission table).  Every command input is FREE and the clock runs
// from reset; k-induction closes because the table invariant I-TBL (embedded in the RTL under `ifdef FORMAL`) is inductive.
//
//   R0  reset                the table is empty and no port is bound (default deny)
//   R1  I-TBL (embedded)     no two valid regions overlap (within a domain; across domains when STRICT); every valid region has
//                             base < end <= 2**AW    => lookup needs no priority: at most one region of a domain matches a byte
//   R2  changes only on commit  the table (valid bits, bindings AND the payload of every valid region) is identical to the previous
//                             cycle unless the previous cycle had cm_en && cm_ok
//   R3  validation soundness   cm_ok and cm_err equal an independent specification of the command rules (64-bit arithmetic)
//   R4  effect               a committed SET_REGION leaves exactly the staged region in the slot; CLR / BIND / CLEAR_ALL do exactly
//                             what they say and nothing else
//   R5  refusal              a command that is not valid never changes the table, even when cm_en is forced
// =============================================================================
`default_nettype none
module fv_mg_regions #(
  parameter ND = 3, parameter NR = 2, parameter NP = 3, parameter AW = 6, parameter STRICT = 0, parameter VAC = 0,
  localparam NE = ND * NR
) (
  input wire         clk,
  input wire         rst_n,
  input wire         cm_en,
  input wire [3:0]   cm_kind, cm_dom, cm_idx, cm_port,
  input wire [63:0]  cm_base, cm_size,
  input wire         cm_r, cm_w, cm_devn,
  input wire [7:0]   cm_dev,
  input wire [15:0]  cm_allow
);
  wire cm_ok; wire [3:0] cm_err;
  wire [NE-1:0] t_valid, t_r, t_w, t_devn; wire [NE*AW-1:0] t_base; wire [NE*(AW+1)-1:0] t_end; wire [NE*NP-1:0] t_dev; wire [NP*ND-1:0] t_allow;
  wire rd_valid, rd_r, rd_w, rd_devn; wire [63:0] rd_base, rd_end; wire [7:0] rd_dev; wire [15:0] rd_allow;
  sf_memory_guard_regions #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .STRICT(STRICT)) dut (
    .clk(clk), .rst_n(rst_n), .cm_en(cm_en), .cm_kind(cm_kind), .cm_dom(cm_dom), .cm_idx(cm_idx), .cm_port(cm_port), .cm_base(cm_base),
    .cm_size(cm_size), .cm_r(cm_r), .cm_w(cm_w), .cm_devn(cm_devn), .cm_dev(cm_dev), .cm_allow(cm_allow), .cm_ok(cm_ok), .cm_err(cm_err),
    .rd_dom(4'd0), .rd_idx(4'd0), .rd_port(4'd0), .rd_valid(rd_valid), .rd_base(rd_base), .rd_end(rd_end), .rd_r(rd_r), .rd_w(rd_w),
    .rd_devn(rd_devn), .rd_dev(rd_dev), .rd_allow(rd_allow),
    .t_valid(t_valid), .t_base(t_base), .t_end(t_end), .t_r(t_r), .t_w(t_w), .t_devn(t_devn), .t_dev(t_dev), .t_allow(t_allow));

  // reset in the first cycle only
  reg f_init = 1'b1;
  always @(posedge clk) f_init <= 1'b0;
  always @(*) if (f_init) assume(!rst_n); else assume(rst_n);

  // ------------------------------------------------------------------ independent specification of the command rules
  localparam [63:0] SPACE = 64'd1 << AW;
  reg         sp_ok; reg [3:0] sp_err;
  reg [63:0]  nb, ne_;
  reg         ovl;
  integer     e, slot;
  always @* begin
    nb = cm_base; ne_ = cm_base + cm_size; slot = cm_dom * NR + cm_idx;
    ovl = 0;
    if (cm_kind == 4'd1) begin
      for (e = 0; e < NE; e = e + 1)
        if (t_valid[e] && e != slot && ((e / NR) == cm_dom || STRICT != 0) &&
            nb < {63'd0, t_end[e*(AW+1) +: (AW+1)]} && {{(64-AW){1'b0}}, t_base[e*AW +: AW]} < ne_) ovl = 1;
    end
    sp_ok = 0; sp_err = 4'd8;
    case (cm_kind)
      4'd1: begin   // SET_REGION
        if (cm_dom >= ND || cm_idx >= NR || (NP < 8 && (cm_dev >> NP) != 0))        sp_err = 4'd3;
        else if (cm_size == 0 || cm_base >= SPACE || (cm_base + cm_size) > SPACE || (cm_base + cm_size) < cm_base) sp_err = 4'd1;
        else if (ovl)                                                                sp_err = 4'd2;
        else begin sp_ok = 1; sp_err = 4'd0; end
      end
      4'd2: begin   // CLR_REGION
        if (cm_dom >= ND || cm_idx >= NR) sp_err = 4'd3; else begin sp_ok = 1; sp_err = 4'd0; end
      end
      4'd3: begin   // BIND_PORT
        if (cm_port >= NP || (ND < 16 && (cm_allow >> ND) != 0)) sp_err = 4'd3; else begin sp_ok = 1; sp_err = 4'd0; end
      end
      4'd4: begin sp_ok = 1; sp_err = 4'd0; end   // CLEAR_ALL
      default: begin sp_ok = 0; sp_err = 4'd8; end
    endcase
  end

  // ------------------------------------------------------------------ history
  reg [NE-1:0] p_valid, p_r, p_w, p_devn; reg [NE*AW-1:0] p_base; reg [NE*(AW+1)-1:0] p_end; reg [NE*NP-1:0] p_dev; reg [NP*ND-1:0] p_allow;
  reg p_commit, p_ok; reg [3:0] p_kind, p_dom, p_idx, p_port; reg [63:0] p_nb, p_ne; reg p_cr, p_cw, p_cdevn; reg [7:0] p_cdev; reg [15:0] p_callow;
  reg p_valid_hist;
  always @(posedge clk) begin
    p_valid <= t_valid; p_r <= t_r; p_w <= t_w; p_devn <= t_devn; p_base <= t_base; p_end <= t_end; p_dev <= t_dev; p_allow <= t_allow;
    p_commit <= cm_en && cm_ok; p_ok <= cm_ok; p_kind <= cm_kind; p_dom <= cm_dom; p_idx <= cm_idx; p_port <= cm_port;
    p_nb <= cm_base; p_ne <= cm_base + cm_size; p_cr <= cm_r; p_cw <= cm_w; p_cdevn <= cm_devn; p_cdev <= cm_dev; p_callow <= cm_allow;
    p_valid_hist <= !f_init;
  end

  integer j, s2;
  always @(*) if (!f_init) begin
    assert(cm_ok == sp_ok);                                                      // R3
    if (!cm_ok) assert(cm_err == sp_err);
    if (cm_ok)  assert(cm_err == 4'd0);
  end

  always @(*) if (p_valid_hist && rst_n) begin
    s2 = p_dom * NR + p_idx;
    if (!p_commit) begin                                                         // R2 / R5: nothing changes without a valid commit
      assert(t_valid == p_valid);
      assert(t_allow == p_allow);
      for (j = 0; j < NE; j = j + 1) if (p_valid[j]) begin
        assert(t_base[j*AW +: AW] == p_base[j*AW +: AW]);
        assert(t_end[j*(AW+1) +: (AW+1)] == p_end[j*(AW+1) +: (AW+1)]);
        assert(t_r[j] == p_r[j] && t_w[j] == p_w[j] && t_devn[j] == p_devn[j]);
        assert(t_dev[j*NP +: NP] == p_dev[j*NP +: NP]);
      end
    end else begin                                                               // R4: the effect of exactly the committed command
      case (p_kind)
        4'd1: begin
          assert(t_valid[s2]);
          assert({1'b0, t_base[s2*AW +: AW]} == p_nb[AW:0] && t_end[s2*(AW+1) +: (AW+1)] == p_ne[AW:0]);
          assert(t_r[s2] == p_cr && t_w[s2] == p_cw && t_devn[s2] == p_cdevn);
          assert(t_dev[s2*NP +: NP] == p_cdev[NP-1:0]);
          for (j = 0; j < NE; j = j + 1) if (j != s2) begin
            assert(t_valid[j] == p_valid[j]);
            if (p_valid[j]) begin
              assert(t_base[j*AW +: AW] == p_base[j*AW +: AW]);
              assert(t_end[j*(AW+1) +: (AW+1)] == p_end[j*(AW+1) +: (AW+1)]);
            end
          end
          assert(t_allow == p_allow);
        end
        4'd2: begin
          assert(!t_valid[s2]);
          for (j = 0; j < NE; j = j + 1) if (j != s2) assert(t_valid[j] == p_valid[j]);
          assert(t_allow == p_allow);
        end
        4'd3: begin
          assert(t_valid == p_valid);
          for (j = 0; j < NP; j = j + 1) begin
            if (j == p_port) assert(t_allow[j*ND +: ND] == p_callow[ND-1:0]);
            else             assert(t_allow[j*ND +: ND] == p_allow[j*ND +: ND]);
          end
        end
        4'd4: begin assert(t_valid == {NE{1'b0}}); assert(t_allow == p_allow); end
        default: assert(0);                                                      // a committed command is one of the four
      endcase
    end
  end

  // R0: the state after the reset cycle is the default-deny state
  reg f_after_reset = 1'b0;
  always @(posedge clk) f_after_reset <= f_init;
  always @(*) if (f_after_reset) begin
    assert(t_valid == {NE{1'b0}});
    assert(t_allow == {(NP*ND){1'b0}});
  end
  // reachability witnesses (VAC != 0): each MUST fail
  always @(*) if (!f_init && VAC != 0) begin
    case (VAC)
      1: assert(!(p_commit && p_kind == 4'd1));                   // a region is installed
      2: assert(!(cm_err == 4'd2));                              // an overlap is refused
      3: assert(!(cm_err == 4'd1));                              // an out-of-range region is refused
      4: assert(!(p_commit && p_kind == 4'd3));                  // a port is bound
      5: assert(!(cm_ok && cm_kind == 4'd1 && (t_valid != {NE{1'b0}})));   // an install is valid with other regions present
      default: assert(1'b1);
    endcase
  end
endmodule
`default_nettype wire
