// =============================================================================
// MemoryGuard formal specification of the permission decision, written independently of the RTL (64-bit arithmetic, one loop over
// every region of every domain).  Used by the port / top harnesses as the oracle for "was this request allowed?" and "why not?".
// Purely combinational.  Proved equivalent to sf_memory_guard_checker in fv_mg_checker.sv (S0).
// =============================================================================
`default_nettype none
module fv_mg_spec #(
  parameter ND = 3, parameter NR = 2, parameter NP = 2, parameter AW = 6, parameter LW = 2, parameter DOMW = 3,
  parameter PIDX = 0, parameter MAXLEN = 2, parameter LEN_POW2 = 0, parameter DIAG = 1,
  localparam NE = ND * NR
) (
  input  wire [1:0]            op,
  input  wire [AW-1:0]         addr,
  input  wire [LW-1:0]         len,
  input  wire [DOMW-1:0]       dom,
  input  wire [ND-1:0]         allow,
  input  wire [NE-1:0]         t_valid,
  input  wire [NE*AW-1:0]      t_base,
  input  wire [NE*(AW+1)-1:0]  t_end,
  input  wire [NE-1:0]         t_r, t_w, t_devn,
  input  wire [NE*NP-1:0]      t_dev,
  output reg                   permit,
  output reg  [3:0]            fault
);
  reg  [63:0] a, l, e, sp, bs, en;
  reg         any_perm, any_cont, any_cont_dev, any_ovl;
  integer     ee;
  always @* begin
    a = {{(64-AW){1'b0}}, addr}; l = {{(64-LW){1'b0}}, len}; e = a + l; sp = 64'd1 << AW;
    any_perm = 0; any_cont = 0; any_cont_dev = 0; any_ovl = 0;
    for (ee = 0; ee < NE; ee = ee + 1) begin
      bs = {{(64-AW){1'b0}}, t_base[ee*AW +: AW]};
      en = {{(63-AW){1'b0}}, t_end[ee*(AW+1) +: (AW+1)]};
      if (t_valid[ee] && ((ee / NR) == dom)) begin
        if (a >= bs && e <= en) begin
          any_cont = 1;
          if (!t_devn[ee] || t_dev[ee*NP + PIDX]) begin
            any_cont_dev = 1;
            if (op == 2'd1 ? t_w[ee] : t_r[ee]) any_perm = 1;
          end
        end else if (a < en && bs < e) any_ovl = 1;
      end
    end
    if      (op > 2'd1)                                               fault = 4'd6;
    else if (len == 0)                                                fault = 4'd5;
    else if (len > MAXLEN || (LEN_POW2 != 0 && (len & (len - 1)) != 0)) fault = 4'd10;
    else if (e > sp)                                                  fault = 4'd4;
    else if (dom >= ND)                                               fault = 4'd7;
    else if (!allow[dom])                                             fault = 4'd8;
    else if (any_perm)                                                fault = 4'd0;
    else if (any_cont && !any_cont_dev)                               fault = 4'd9;
    else if (any_cont)                                                fault = 4'd2;
    else if (DIAG != 0 && any_ovl)                                    fault = 4'd3;
    else                                                              fault = 4'd1;
    permit = (fault == 4'd0);
  end
endmodule
`default_nettype wire
