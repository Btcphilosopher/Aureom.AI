# formal/memory_guard — formal verification

Run: `make formal` → `reports/formal.md`. Flow: Yosys (`read_verilog -sv -formal -DFORMAL`, `prep`, `async2sync`) → SMT2 → `yosys-smtbmc` + **z3**. (SymbiYosys is not installed; ABC `pdr` was tried on the
port harness and did not converge in 15 minutes — k-induction with an explicit refinement mapping did.)

| file | what it holds |
|---|---|
| `fv_mg_spec.sv` | the **independent specification** of the permission decision (64-bit arithmetic, one loop over every region of every domain) |
| `fv_mg_checker.sv` | `sf_memory_guard_checker`, combinational, **all inputs**: S0 verdict = specification (decision and diagnosis), S1 invalid domains, S2 address overflow, S3 whole-range containment (first byte, last byte, a free middle byte), S4 decision ⇔ diagnosis, S5 both lookup architectures equal; plus reachability witnesses |
| `fv_mg_regions.sv` | the table: default deny, the **overlap invariant** (embedded in the RTL under `FORMAL`), changes only on commit, validation = specification, effect of each command |
| `fv_mg_cfg.sv` | regs + table with a free bus: drain-then-commit, trusted control, lock, privilege, abort, ingress block — **discharges assumption E4** |
| `fv_mg_port.sv` | one port, unbounded: authorisation, provenance, ordered responses, orphan handling (G1–G7) through a **refinement mapping** onto the RTL's registers (observation ports under `FORMAL`) |
| `fv_mg_top.sv` | the composition: the table changes only after a commit with every port idle and ingress blocked; no commit under any accepted-unanswered request (assume-guarantee on G6) |

`scripts/formal.py` lists every job. **comb** = depth-1 proof for all inputs; **prove** = base case + k-induction (unbounded); **vac** = a reachability witness that must FAIL (the environment
assumptions leave the interesting situations reachable, so the proofs are not vacuous); **mut** = the same harness on an RTL copy with one planted defect — it must FAIL. The assume-guarantee
argument that turns these into the system-level statement is in `docs/memory_guard/08_VERIFICATION.md`.
