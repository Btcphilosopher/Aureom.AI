# SilicaFlux Project 104 — MemoryGuard

### Hardware memory protection for cloud compute · Aureom.AI / SilicaFlux Semiconductor Systems

A synthesizable, **region-based memory protection engine** with four domains and four protected ingress ports (DMA, network, storage, compute accelerator). It sits *between the
requesters and the memory* and is the only path from one to the other: a request reaches memory only after its whole byte range has been checked against the region table of the
domain its **physical port** is entitled to. It is protection, **not translation** — it is not an IOMMU and does not claim to be (`docs/memory_guard/10_LIMITATIONS.md`).

**Primary RTL: `rtl/memory_guard/sf_memory_guard.sv`.**

```
 Request → trusted domain identification → address & length validation → permission lookup → allow | reject → memory transaction
```

## Deliverables (the brief's file list → where it is)

| brief | here |
|---|---|
| `sf_memory_guard.sv` | `rtl/memory_guard/sf_memory_guard.sv` |
| `sf_memory_guard_regions.sv` | `rtl/memory_guard/sf_memory_guard_regions.sv` |
| `sf_memory_guard_checker.sv` | `rtl/memory_guard/sf_memory_guard_checker.sv` |
| `sf_memory_guard_regs.sv` | `rtl/memory_guard/sf_memory_guard_regs.sv` |
| `sf_memory_guard_faults.sv` | `rtl/memory_guard/sf_memory_guard_faults.sv` |
| `tests/memory_guard/` | `tests/memory_guard/` (+ `README.md`) |
| `formal/memory_guard/` | `formal/memory_guard/` (+ `README.md`) |
| `docs/memory_guard/` | `docs/memory_guard/` — start with `00_AUDIT.md` and `08_VERIFICATION.md` |

Additional RTL (all in `rtl/memory_guard/`): `sf_memory_guard_port.sv` (the per-port **enforcement point**), `sf_memory_guard_pkg.sv`, and two check-only adapters,
`sf_memory_guard_grd_if.sv` (MeridianQoS `grd_*`) and `sf_memory_guard_iommu_if.sv` (StreamDMA / CloudDMA IOMMU contract).

## What it does

* **Domain model.** `ND` domains (default 4) × `NR` regions each (default 4); a region is `{valid, base, end, R, W, optional device mask}`, byte granular.
* **Trusted identity.** Authority is the *binding of the physical port* (programmed only through the privileged bus). The request's domain field is a **claim** that must lie inside it; a spoofed or invalid claim is denied and logged against the real port.
* **Range checking.** The **whole** transfer is checked in `AW+1` bits: overflow, zero length, oversize, unsupported operation, invalid domain, out-of-range, partial overlap and boundary-spanning transfers are all denied; the last byte must lie in the **same** region as the first.
* **Overlap decision.** Overlapping regions are *rejected at install time* (no priority). With `STRICT = 1` no byte may be mapped for two domains.
* **In-flight policy.** *Drain-then-commit*: a valid configuration command blocks ingress, waits until every port is idle, and only then changes the table. No transaction ever lives across a policy change. Proved.
* **Enforcement.** A denied request leaves **no trace** on the memory side (not even its address); it gets one explicit error response (`DENIED` / `PROTO`, no reason) and one privileged fault record
  `{port, domain, address, length, op, fault, transaction id, policy generation, sequence}`.
* **Configuration.** Privileged SFB2-style bus (ControlCore `ext_*` compatible), staging registers, atomic validated commits, `CTRL.LOCK` (set-only), privileged diagnostics, saturating counters.

## Verification at a glance

The numbers below are generated into `reports/` (`make regress formal mutate`); the argument is in `docs/memory_guard/08_VERIFICATION.md`.

<!-- RESULTS-BEGIN -->
| evidence | result |
|---|---|
| simulation regression (directed, adversarial random, Python-model vectors, adapters, **real MemoryMatrix behind the guard**) | **33 / 33 runs pass, 3,716,597 checks** |
| formal proofs (k-induction / all-input, z3) | **22 / 22 pass** — checker S0–S5 for all inputs; table invariants; configuration engine; one port (unbounded); the composition |
| formal non-vacuity witnesses | **29 / 29** reachable |
| formal mutation checks | **35 / 35** planted defects caught |
| simulation mutation campaign | **31 / 33** killed (survivor(s): R04, P10 — not observable at the interfaces of the integrated design, both killed formally; see 08) |
<!-- RESULTS-END -->

## Quick start

```bash
make lint                    # Verilator -Wall + Yosys elaboration
make regress                 # all simulations  -> reports/regression.md
make formal                  # all proofs       -> reports/formal.md
make mutate                  # mutation campaign-> reports/mutation.md
make synth bench             # area / depth / throughput studies -> benchmarks/memory_guard/results/
make zip                     # rebuild the archive
```

Tools: Verilator 5.020, Yosys 0.33, `yosys-smtbmc`, z3, Python 3 (Icarus 12 elaborates the RTL but was not used to simulate).

## Honest boundaries (full list in `docs/memory_guard/10_LIMITATIONS.md`)

* **Not an IOMMU.** No translation. (A translation-capable block already exists: DomainGuard, Project 97.)
* **The privilege of the configuration bus is a label.** Isolation is only as strong as the physical exclusivity of that bus (ControlCore claims no authentication; SecureSilicon's OTP is a model).
* **Inline versus check-only.** Only the inline port enforces without a cooperating master; the two adapters are advisory contracts (quiesce before revoking).
* **Connected for real:** MemoryMatrix (P101), simulated behind the guard. **Not instantiated:** StreamDMA, MeridianQoS, TensorCore, VirtualIO RTL (adapters and contract tests / mapping only); **PacketForge does not exist** in the repository.
* **Proofs are on tiny configurations**, unbounded in time but not in size; liveness and the fault log are simulation-only; the composed design is verified by assume-guarantee plus simulation, not by one monolithic proof.
* **No silicon, no PDK, no timing.** Area and depth are Yosys technology-independent estimates.

## Layout

```
rtl/memory_guard/    the design (7 core files, 2 adapters)       rtl/files.f, rtl/files_mm.f (MemoryMatrix for the integration test)
tests/memory_guard/  testbenches, Python reference model, vectors   formal/memory_guard/  harnesses
docs/memory_guard/   00 audit · 01 architecture · 02 interfaces · 03 enforcement · 04 regions · 05 in-flight policy · 06 identity & config ·
                     07 faults · 08 verification · 09 physical · 10 limitations
benchmarks/memory_guard/   synth.py, run_bench.py, results/       reports/   regression, formal, mutation (generated)
scripts/             run_sim.sh, regress.py, formal.py, mutate.py, mutants.py, alias_pkg.py, make_docs.py, make_zip.py
third_party/p101/    MemoryMatrix (P101) RTL, byte-identical      third_party/p102/  the P102 package (ABI check)       MANIFEST.sha256
```

Nothing in this project was committed to any repository; it is delivered as an archive.
