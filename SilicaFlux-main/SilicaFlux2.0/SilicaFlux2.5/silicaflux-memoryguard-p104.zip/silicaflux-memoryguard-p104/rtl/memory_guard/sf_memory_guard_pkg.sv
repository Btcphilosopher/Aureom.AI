// =============================================================================
// SilicaFlux -- Project 104 -- MemoryGuard :: sf_memory_guard_pkg
//
// Constants of MemoryGuard.
//
//  * Section 1 (ABI) is the transaction contract of Project 83 / 102 (the Albion transaction format as carried by
//    Meridian): op codes and the 3-bit response status have IDENTICAL numeric values; tests/memory_guard/tb_abi_check.sv
//    compiles this package together with the vendored P102 package and fails if a shared constant differs.
//  * Section 2 is the NATIVE fault-code space of the guard (4 bit).  The guard reports the detailed code only to the
//    privileged fault log.  The requester sees only the coarse status (ST_DENIED or ST_PROTO).
//  * Sections 3.. are the configuration-command, status and register map.
//
// Tool rules (same as Projects 22 / 83 / 102 so Verilator, Yosys and Icarus elaborate the RTL identically): localparams
// and "assign to the function name" functions only -- no structs, typedefs or `return`.
// =============================================================================
package sf_memory_guard_pkg;
  /* verilator lint_off UNUSEDPARAM */

  // ============================================================ 1. ABI (identical to Projects 83 / 102)
  localparam logic [1:0]  OP_READ    = 2'd0;
  localparam logic [1:0]  OP_WRITE   = 2'd1;    // 2 and 3 are UNSUPPORTED operations -> FT_BADOP

  localparam logic [2:0]  ST_OKAY    = 3'd0;
  localparam logic [2:0]  ST_SLVERR  = 3'd1;    // the memory reported an error for a PERMITTED request
  localparam logic [2:0]  ST_DECERR  = 3'd2;    // part of the ABI; not produced by the guard
  localparam logic [2:0]  ST_DENIED  = 3'd3;    // policy denial (coarse: no reason is given to the requester)
  localparam logic [2:0]  ST_TIMEOUT = 3'd4;    // part of the ABI; not produced by the guard
  localparam logic [2:0]  ST_PROTO   = 3'd5;    // malformed request (zero / oversize length, unsupported op, wrap, bad domain)

  // ============================================================ 2. native fault codes
  localparam logic [3:0]  FT_NONE     = 4'd0;   // permitted
  localparam logic [3:0]  FT_NOMAP    = 4'd1;   // no region of the domain touches the transfer
  localparam logic [3:0]  FT_PERM     = 4'd2;   // contained in one region, but the read / write right is missing
  localparam logic [3:0]  FT_SPAN     = 4'd3;   // partial overlap / boundary-spanning: no single region contains the transfer
  localparam logic [3:0]  FT_OVERFLOW = 4'd4;   // addr + len exceeds the address space (would wrap)
  localparam logic [3:0]  FT_ZEROLEN  = 4'd5;   // len == 0
  localparam logic [3:0]  FT_BADOP    = 4'd6;   // unsupported operation
  localparam logic [3:0]  FT_BADDOM   = 4'd7;   // domain id >= ND
  localparam logic [3:0]  FT_SPOOF    = 4'd8;   // domain claim not permitted for this physical port (trusted binding)
  localparam logic [3:0]  FT_DEVICE   = 4'd9;   // region matches but this port / device is not in the region's device mask
  localparam logic [3:0]  FT_BADLEN   = 4'd10;  // len > MAXLEN (or not a power of two when LEN_POW2 = 1)
  localparam int          NFT         = 11;     // number of defined fault codes (0..10)

  // faults that are properties of the REQUEST alone (independent of any configured policy): status ST_PROTO.
  // everything else is policy dependent: status ST_DENIED, with no reason (no layout oracle).
  function automatic logic ft_is_proto(input logic [3:0] f);
    begin
      ft_is_proto = (f == FT_OVERFLOW) || (f == FT_ZEROLEN) || (f == FT_BADOP) || (f == FT_BADDOM) || (f == FT_BADLEN);
    end
  endfunction

  // ============================================================ 3. configuration commands (R_CMD) and errors
  localparam logic [3:0]  CMD_SET_REGION = 4'd1; // install the staged region descriptor into slot (dom, idx)
  localparam logic [3:0]  CMD_CLR_REGION = 4'd2; // invalidate slot (dom, idx)
  localparam logic [3:0]  CMD_BIND_PORT  = 4'd3; // install the staged allow mask as the trusted binding of port
  localparam logic [3:0]  CMD_CLEAR_ALL  = 4'd4; // invalidate every region (port bindings are kept)

  localparam logic [3:0]  CE_OK       = 4'd0;
  localparam logic [3:0]  CE_RANGE    = 4'd1;   // zero size, base outside the address space, base + size wraps
  localparam logic [3:0]  CE_OVERLAP  = 4'd2;   // the new region overlaps a valid region (same domain; any domain if STRICT)
  localparam logic [3:0]  CE_INDEX    = 4'd3;   // domain / region / port index or a reserved field out of range
  localparam logic [3:0]  CE_PRIV     = 4'd4;   // not privileged
  localparam logic [3:0]  CE_LOCKED   = 4'd5;   // configuration lock is set
  localparam logic [3:0]  CE_BUSY     = 4'd6;   // a command is draining / committing
  localparam logic [3:0]  CE_TMO      = 4'd7;   // drain timeout: the command was NOT applied
  localparam logic [3:0]  CE_CMD      = 4'd8;   // unknown command / bad register address / partial write

  // ============================================================ 4. register map (word offsets, byte address = 4 * offset)
  localparam int R_ID         = 0;   // RO   [31:16] magic "MG"  [15:12] ND  [11:8] NR  [7:4] NP  [1] CHK_PIPE  [0] STRICT_PARTITION
  localparam int R_VERSION    = 1;   // RO
  localparam int R_CTRL       = 2;   // RW   [31] LOCK (set only; cleared by reset only)
  localparam int R_STATUS     = 3;   // RW1C sticky flags (STAT_*)
  localparam int R_STATE      = 4;   // RO   [0] busy [1] blocking [2] locked [3] in-flight [11:8] last config error (CE_*)
  localparam int R_GEN        = 5;   // RO   policy generation: +1 for every committed change
  localparam int R_DRAIN_TMO  = 6;   // RW   drain timeout in cycles, 0 = wait forever (writable until locked)
  localparam int R_SEL        = 7;   // RW   [3:0] domain  [11:8] region index  [19:16] port
  localparam int R_BASE_LO    = 8;   // RW   staged region base [31:0]
  localparam int R_BASE_HI    = 9;   // RW   staged region base [63:32]
  localparam int R_SIZE_LO    = 10;  // RW   staged region size [31:0]  (bytes, 1 .. 2**AW)
  localparam int R_SIZE_HI    = 11;  // RW   staged region size [63:32]
  localparam int R_ATTR       = 12;  // RW   [0] R  [1] W  [2] DEV_EN  [15:8] DEV_MASK (bit p = port p)
  localparam int R_ALLOW      = 13;  // RW   staged allow mask for CMD_BIND_PORT (bit d = domain d)
  localparam int R_CMD        = 14;  // WO   [3:0] CMD_*
  localparam int R_RD_BASE_LO = 15;  // RO   installed entry (dom, idx) of R_SEL, base
  localparam int R_RD_BASE_HI = 16;  // RO
  localparam int R_RD_END_LO  = 17;  // RO   exclusive end
  localparam int R_RD_END_HI  = 18;  // RO
  localparam int R_RD_ATTR    = 19;  // RO   [31] VALID  [0] R  [1] W  [2] DEV_EN  [15:8] DEV_MASK
  localparam int R_RD_ALLOW   = 20;  // RO   installed binding of the port in R_SEL
  localparam int R_FLOG_CNT   = 21;  // RO   [7:0] records held  [15:8] log depth  [31:16] records dropped (saturating)
  localparam int R_FLOG_W0    = 22;  // RO   head record: [15:0] transaction id  [31:16] len
  localparam int R_FLOG_W1    = 23;  // RO   fault address [31:0]
  localparam int R_FLOG_W2    = 24;  // RO   fault address [63:32]
  localparam int R_FLOG_W3    = 25;  // RO   [3:0] fault  [5:4] op  [11:8] requester port  [15:12] domain (claimed)  [31:16] policy generation
  localparam int R_FLOG_SEQ   = 26;  // RO   head record: fault sequence number
  localparam int R_FLOG_POP   = 27;  // WO   [0] drop the head record
  localparam int R_CNT_SEL    = 28;  // RW   counter index
  localparam int R_CNT_DATA   = 29;  // RO   selected counter (saturating, never wraps)
  localparam int R_NCNT       = 30;  // RO   number of counters
  localparam int R_CAPS       = 31;  // RO   [7:0] AW  [15:8] bytes per beat  [23:16] IDW  [27:24] MAXOUT
  localparam int NREG         = 32;

  localparam int CTRL_LOCK    = 31;

  localparam int STAT_SEC      = 0;   // an unprivileged access was rejected
  localparam int STAT_LOCKED   = 1;   // a write was rejected by the configuration lock
  localparam int STAT_BUSY     = 2;   // a write was rejected because a command is in progress
  localparam int STAT_ERANGE   = 3;
  localparam int STAT_EOVERLAP = 4;
  localparam int STAT_EINDEX   = 5;
  localparam int STAT_ECMD     = 6;   // unknown command / partial write / read-only register written
  localparam int STAT_TMO      = 7;   // a drain timed out (command not applied)
  localparam int STAT_DONE     = 8;   // a command was committed
  localparam int STAT_FDROP    = 9;   // a fault record was dropped (log full)
  localparam int STAT_ORPHAN   = 10;  // a memory response arrived with nothing outstanding and was discarded
  localparam int STAT_FAULT    = 11;  // a request was denied
  localparam int STAT_BADADDR  = 12;  // register address outside the map
  localparam int STAT_FNE      = 31;  // RO mirror: the fault log holds a record

  localparam logic [15:0] ID_MAGIC = 16'h4D47;     // "MG"
  localparam logic [31:0] VERSION  = 32'h0001_0000;

  // ============================================================ 5. counter map (read through R_CNT_SEL / R_CNT_DATA)
  localparam int CN_FAULTS    = 0;   // every denied / malformed request (logged or dropped)
  localparam int CN_SEC       = 1;   // unprivileged configuration accesses rejected
  localparam int CN_LOCKREJ   = 2;   // writes rejected by the lock
  localparam int CN_COMMIT    = 3;   // commands committed
  localparam int CN_CMDREJ    = 4;   // commands refused by validation
  localparam int CN_TMO       = 5;   // drain timeouts
  localparam int CN_ORPHAN    = 6;   // orphan memory responses discarded
  localparam int CN_FDROP     = 7;   // fault records dropped (log full)
  localparam int CN_FWD       = 8;   // permitted requests forwarded (all ports)
  localparam int CN_G         = 9;   // number of global counters; then NP per-port forwarded, NP per-port faulted, 16 per fault code
  function automatic integer cn_pfwd(input integer p);  begin cn_pfwd  = CN_G + p; end endfunction
  function automatic integer cn_pflt(input integer np, input integer p); begin cn_pflt = CN_G + np + p; end endfunction
  function automatic integer cn_ft(input integer np, input integer f);   begin cn_ft   = CN_G + 2 * np + f; end endfunction
  function automatic integer cn_n(input integer np);                      begin cn_n    = CN_G + 2 * np + 16; end endfunction

  // ============================================================ helpers
  function automatic integer clog2c(input integer n);   // width of an index into n things (>= 1)
    begin
      if (n > 1) clog2c = $clog2(n);
      else       clog2c = 1;
    end
  endfunction

  function automatic integer imax(input integer a, input integer b);
    begin if (a > b) imax = a; else imax = b; end
  endfunction

  /* verilator lint_on UNUSEDPARAM */
endpackage
