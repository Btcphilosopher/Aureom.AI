// =============================================================================
// SilicaFlux -- Project 104 -- MemoryGuard :: sf_memory_guard_port
//
// ONE protected ingress port: the enforcement point between a requester (DMA / network / storage / accelerator) and the
// memory.  The requester's request channel ends in a register; the memory's request channel starts at the output of
// that register AFTER the permission check.  There is no other path from `r_*` to `m_*` (docs/memory_guard/03, rule R1).
//
//   r_* --> [ stage A : request register ] --(CHK_PIPE=1: [ stage B : request + registered verdict ])--> act
//                                                   |                                                       |
//                                            sf_memory_guard_checker (combinational, trusted binding + table)
//   act & permit & room  -->  m_* (memory request; payload is ZERO unless m_valid)
//   act & !permit        -->  one error response + one fault-log record; NOTHING is presented on m_*
//   d_* (memory response) --> s_* (requester response), in order;  error responses wait for all earlier answers
//
// REQUEST ENCODING (superset of the MemoryMatrix master port, docs/memory_guard/02):
//   r_op READ/WRITE (others: unsupported), r_addr (byte), r_len (bytes, 1..MAXLEN), r_wdata/r_be (lane j = byte addr+j),
//   r_id (opaque, echoed), r_dom (CLAIMED domain: a claim, never authority -- see the checker).
//   The transfer is a single beat: write data travels WITH the request, so a denied write has no second channel to leak
//   through and "authorise, then move data" can never be split.
//
// TOCTOU.  The verdict is computed from (stage register, table).  The table cannot change while this port holds a request
// or an unanswered memory transaction: sf_memory_guard_regs drains every port (idle) with ingress blocked before it
// commits (docs/memory_guard/05).  Hence verdict(at check) == verdict(at use) == the table state the request was accepted under.
//
// PROTOCOL.  m_valid never depends on m_ready and, once asserted, holds with an unchanged payload until accepted: it is a
// function of registers and of fwd_cnt_q, which can only fall while a request waits.  r_ready depends on m_ready (accept
// while retiring); it never depends on r_valid.  Responses return in acceptance order (the memory returns them in order;
// an error response is issued only when nothing is outstanding and blocks later forwards until it has been taken).
// =============================================================================
`default_nettype none

module sf_memory_guard_port #(
  parameter int ND           = 4,
  parameter int NR           = 4,
  parameter int NP           = 4,
  parameter int AW           = 32,
  parameter int DW           = 64,
  parameter int IDW          = 8,
  parameter int LW           = 4,
  parameter int DOMW         = 3,
  parameter int PIDX         = 0,
  parameter int MAXLEN       = DW / 8,
  parameter int MAXOUT       = 4,
  parameter int CHK_PIPE     = 0,
  parameter int LOOKUP_ARCH  = 0,
  parameter int DIAG_PRECISE = 1,
  parameter int LEN_POW2     = 0,
  localparam int BW          = DW / 8,
  localparam int NE          = ND * NR,
  localparam int OW          = sf_memory_guard_pkg::clog2c(MAXOUT + 1),
  localparam int RECW        = IDW + AW + LW + 4 + 2 + DOMW
) (
  input  wire logic                     clk,
  input  wire logic                     rst_n,
  input  wire logic                     blk,            // ingress blocked (a configuration command is draining)
  // ---- requester side
  input  wire logic                     r_valid,
  output logic                          r_ready,
  input  wire logic [1:0]               r_op,
  input  wire logic [AW-1:0]            r_addr,
  input  wire logic [LW-1:0]            r_len,
  input  wire logic [DW-1:0]            r_wdata,
  input  wire logic [BW-1:0]            r_be,
  input  wire logic [IDW-1:0]           r_id,
  input  wire logic [DOMW-1:0]          r_dom,
  output logic                          s_valid,
  input  wire logic                     s_ready,
  output logic [DW-1:0]                 s_rdata,
  output logic [IDW-1:0]                s_id,
  output logic                          s_we,
  output logic [2:0]                    s_status,
  // ---- memory side
  output logic                          m_valid,
  input  wire logic                     m_ready,
  output logic                          m_we,
  output logic [AW-1:0]                 m_addr,
  output logic [LW-1:0]                 m_len,
  output logic [DW-1:0]                 m_wdata,
  output logic [BW-1:0]                 m_be,
  output logic [IDW-1:0]                m_id,
  output logic [DOMW-1:0]               m_dom,          // the VERIFIED domain the request was permitted for
  input  wire logic                     d_valid,
  output logic                          d_ready,
  input  wire logic [DW-1:0]            d_rdata,
  input  wire logic [IDW-1:0]           d_id,
  input  wire logic                     d_we,
  input  wire logic                     d_err,
  // ---- policy (shared table + this port's trusted binding)
  input  wire logic [ND-1:0]            allow,
  input  wire logic [NE-1:0]            t_valid,
  input  wire logic [NE*AW-1:0]         t_base,
  input  wire logic [NE*(AW+1)-1:0]     t_end,
  input  wire logic [NE-1:0]            t_r,
  input  wire logic [NE-1:0]            t_w,
  input  wire logic [NE-1:0]            t_devn,
  input  wire logic [NE*NP-1:0]         t_dev,
  // ---- fault log / counters
  output logic                          ev_req,
  input  wire logic                     ev_gnt,
  output logic [RECW-1:0]               ev_rec,
  output logic                          ev_fwd,
  output logic                          ev_orphan,
  // ---- drain
  output logic                          idle            // nothing accepted and not yet answered
`ifdef FORMAL
  // ---- observation points for the formal refinement mapping (absent from the synthesised design)
  , output logic                         fv_a_valid, fv_b_valid, fv_err_valid
  , output logic [OW-1:0]                fv_fwd_cnt
  , output logic [2+AW+LW+DW+BW+IDW+DOMW-1:0] fv_a_ent, fv_b_ent
  , output logic                         fv_b_permit
  , output logic [3:0]                   fv_act_fault
  , output logic [IDW-1:0]               fv_err_id
  , output logic [2:0]                   fv_err_st
  , output logic                         fv_err_we
`endif
);
  // PKG-ALIASES-BEGIN (generated by scripts/alias_pkg.py)
  localparam logic [3:0] FT_BADDOM = sf_memory_guard_pkg::FT_BADDOM;
  localparam logic [3:0] FT_BADLEN = sf_memory_guard_pkg::FT_BADLEN;
  localparam logic [3:0] FT_BADOP = sf_memory_guard_pkg::FT_BADOP;
  localparam logic [3:0] FT_OVERFLOW = sf_memory_guard_pkg::FT_OVERFLOW;
  localparam logic [3:0] FT_ZEROLEN = sf_memory_guard_pkg::FT_ZEROLEN;
  localparam logic [1:0] OP_WRITE = sf_memory_guard_pkg::OP_WRITE;
  localparam logic [2:0] ST_DENIED = sf_memory_guard_pkg::ST_DENIED;
  localparam logic [2:0] ST_OKAY = sf_memory_guard_pkg::ST_OKAY;
  localparam logic [2:0] ST_PROTO = sf_memory_guard_pkg::ST_PROTO;
  localparam logic [2:0] ST_SLVERR = sf_memory_guard_pkg::ST_SLVERR;
  // PKG-ALIASES-END

  // faults that are properties of the request alone (no policy involved): status ST_PROTO; the rest: ST_DENIED, no reason
  function automatic logic is_proto(input logic [3:0] f);
    begin
      is_proto = (f == FT_OVERFLOW) || (f == FT_ZEROLEN) || (f == FT_BADOP) || (f == FT_BADDOM) || (f == FT_BADLEN);
    end
  endfunction

  // ------------------------------------------------------------------ stage A: the accepted request
  logic                a_valid;
  logic [1:0]          a_op;
  logic [AW-1:0]       a_addr;
  logic [LW-1:0]       a_len;
  logic [DW-1:0]       a_wdata;
  logic [BW-1:0]       a_be;
  logic [IDW-1:0]      a_id;
  logic [DOMW-1:0]     a_dom;

  // ------------------------------------------------------------------ the checker, on stage A
  logic                a_permit;
  logic [3:0]          a_fault;
  logic [DOMW-1:0]     a_edom;
  sf_memory_guard_checker #(
    .ND(ND), .NR(NR), .NP(NP), .AW(AW), .LW(LW), .DOMW(DOMW), .PIDX(PIDX), .MAXLEN(MAXLEN), .LEN_POW2(LEN_POW2),
    .LOOKUP_ARCH(LOOKUP_ARCH), .DIAG_PRECISE(DIAG_PRECISE)
  ) u_chk (
    .c_op(a_op), .c_addr(a_addr), .c_len(a_len), .c_dom(a_dom), .allow(allow),
    .t_valid(t_valid), .t_base(t_base), .t_end(t_end), .t_r(t_r), .t_w(t_w), .t_devn(t_devn), .t_dev(t_dev),
    .permit(a_permit), .fault(a_fault), .edom(a_edom)
  );

  // ------------------------------------------------------------------ acting stage: A (CHK_PIPE=0) or B (CHK_PIPE=1)
  logic                act_valid, act_permit, act_retire;
  logic [3:0]          act_fault;
  logic [1:0]          act_op;
  logic [AW-1:0]       act_addr;
  logic [LW-1:0]       act_len;
  logic [DW-1:0]       act_wdata;
  logic [BW-1:0]       act_be;
  logic [IDW-1:0]      act_id;
  logic [DOMW-1:0]     act_dom;
  logic                b_valid;
  logic                a_leave;        // the request in stage A moves on / retires this cycle

  generate
    if (CHK_PIPE == 0) begin : g_p0
      assign act_valid  = a_valid;
      assign act_permit = a_permit;
      assign act_fault  = a_fault;
      assign act_op     = a_op;
      assign act_addr   = a_addr;
      assign act_len    = a_len;
      assign act_wdata  = a_wdata;
      assign act_be     = a_be;
      assign act_id     = a_id;
      assign act_dom    = a_edom;
      assign b_valid    = 1'b0;
      assign a_leave    = act_retire;
    end else begin : g_p1
      // stage B holds the request together with the REGISTERED verdict of stage A
      logic                b_permit;
      logic [3:0]          b_fault;
      logic [1:0]          b_op;
      logic [AW-1:0]       b_addr;
      logic [LW-1:0]       b_len;
      logic [DW-1:0]       b_wdata;
      logic [BW-1:0]       b_be;
      logic [IDW-1:0]      b_id;
      logic [DOMW-1:0]     b_dom;
      wire b_free = !b_valid || act_retire;
      assign a_leave = a_valid && b_free;
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)          b_valid <= 1'b0;
        else if (a_leave)    b_valid <= 1'b1;
        else if (act_retire) b_valid <= 1'b0;
      end
      always_ff @(posedge clk) begin
        if (a_leave) begin
          b_permit <= a_permit; b_fault <= a_fault; b_op <= a_op; b_addr <= a_addr; b_len <= a_len;
          b_wdata <= a_wdata; b_be <= a_be; b_id <= a_id; b_dom <= a_edom;
        end
      end
      assign act_valid  = b_valid;
      assign act_permit = b_permit;
      assign act_fault  = b_fault;
      assign act_op     = b_op;
      assign act_addr   = b_addr;
      assign act_len    = b_len;
      assign act_wdata  = b_wdata;
      assign act_be     = b_be;
      assign act_id     = b_id;
      assign act_dom    = b_dom;
    end
  endgenerate

  // stage A load / clear.  r_ready never depends on r_valid; it depends on blk and on whether A is free or leaving.
  assign r_ready = !blk && (!a_valid || a_leave);
  wire a_load = r_valid && r_ready;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)       a_valid <= 1'b0;
    else if (a_load)  a_valid <= 1'b1;
    else if (a_leave) a_valid <= 1'b0;
  end
  always_ff @(posedge clk) begin
    if (a_load) begin
      a_op <= r_op; a_addr <= r_addr; a_len <= r_len; a_wdata <= r_wdata; a_be <= r_be; a_id <= r_id; a_dom <= r_dom;
    end
  end

  // ------------------------------------------------------------------ forwarding, denial, outstanding count
  logic [OW-1:0] fwd_cnt_q;
  logic          err_valid_q, err_we_q;
  logic [IDW-1:0] err_id_q;
  logic [2:0]    err_st_q;

  wire fwd_room = (fwd_cnt_q != OW'(MAXOUT)) && !err_valid_q;
  assign m_valid = act_valid && act_permit && fwd_room;
  wire fwd_fire  = m_valid && m_ready;

  wire deny_ok   = act_valid && !act_permit && !err_valid_q && (fwd_cnt_q == '0);
  assign ev_req  = deny_ok;
  wire deny_fire = deny_ok && ev_gnt;
  assign act_retire = fwd_fire || deny_fire;
  assign ev_fwd  = fwd_fire;

  // memory request: payload is ZERO unless m_valid (a denied request never drives its address or data onto the memory side)
  wire wr = (act_op == OP_WRITE);
  logic [BW-1:0] lane_mask;
  always_comb begin
    for (int j = 0; j < BW; j++) lane_mask[j] = (LW'(j) < act_len);
  end
  assign m_we    = m_valid && wr;
  assign m_addr  = m_valid ? act_addr : '0;
  assign m_len   = m_valid ? act_len  : '0;
  assign m_wdata = (m_valid && wr) ? act_wdata : '0;
  assign m_be    = (m_valid && wr) ? (act_be & lane_mask) : '0;      // clipped to [addr, addr+len): defence in depth
  assign m_id    = m_valid ? act_id   : '0;
  assign m_dom   = m_valid ? act_dom  : '0;

  assign ev_rec  = {act_id, act_addr, act_len, act_fault, act_op, act_dom};

  // response path
  wire d_ok   = d_valid && (fwd_cnt_q != '0);
  wire d_take = d_ok && s_ready && !err_valid_q;
  assign s_valid  = err_valid_q || d_ok;
  assign s_rdata  = err_valid_q ? '0 : d_rdata;
  assign s_id     = err_valid_q ? err_id_q : d_id;
  assign s_we     = err_valid_q ? err_we_q : d_we;
  assign s_status = err_valid_q ? err_st_q : (d_err ? ST_SLVERR : ST_OKAY);
  assign d_ready  = (fwd_cnt_q == '0) || (s_ready && !err_valid_q);
  assign ev_orphan = d_valid && d_ready && (fwd_cnt_q == '0);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      fwd_cnt_q <= '0; err_valid_q <= 1'b0;
    end else begin
      case ({fwd_fire, d_take})
        2'b10:   fwd_cnt_q <= fwd_cnt_q + OW'(1);
        2'b01:   fwd_cnt_q <= fwd_cnt_q - OW'(1);
        default: ;
      endcase
      if (deny_fire)                    err_valid_q <= 1'b1;
      else if (err_valid_q && s_ready)  err_valid_q <= 1'b0;
    end
  end
  always_ff @(posedge clk) begin
    if (deny_fire) begin
      err_id_q <= act_id;
      err_we_q <= wr;
      err_st_q <= is_proto(act_fault) ? ST_PROTO : ST_DENIED;
    end
  end

  assign idle = !a_valid && !b_valid && (fwd_cnt_q == '0) && !err_valid_q;

  initial begin
    if (MAXOUT < 1) $fatal(1, "sf_memory_guard_port: MAXOUT >= 1");
  end

`ifdef FORMAL
  assign fv_a_valid   = a_valid;
  assign fv_b_valid   = b_valid;
  assign fv_err_valid = err_valid_q;
  assign fv_fwd_cnt   = fwd_cnt_q;
  assign fv_a_ent     = {a_op, a_addr, a_len, a_wdata, a_be, a_id, a_dom};
  assign fv_b_ent     = {act_op, act_addr, act_len, act_wdata, act_be, act_id, act_dom};
  assign fv_b_permit  = act_permit;
  assign fv_act_fault = act_fault;
  assign fv_err_id    = err_id_q;
  assign fv_err_st    = err_st_q;
  assign fv_err_we    = err_we_q;
  // ---- internal invariants of the gate (inductive)
  always @(*) if (rst_n) begin
    assert(fwd_cnt_q <= OW'(MAXOUT));
    assert(!(err_valid_q && fwd_cnt_q != '0));                      // an error response only exists with nothing outstanding
    assert(!m_valid || (act_valid && act_permit));                  // memory side only for a permitted, held request
    assert(!(m_valid && deny_ok));
  end
`endif
endmodule

`default_nettype wire
