// =============================================================================
// SilicaFlux -- Project 104 -- MemoryGuard :: sf_memory_guard_iommu_if
//
// The IOMMU request / response CONTRACT of CloudDMA (Project 64) and StreamDMA (Project 103: `guard_req_*` / `guard_rsp_*`) implemented
// on the MemoryGuard permission table, for ONE client (the DMA).  Port names are P103's.
//
//   request   guard_req_valid/ready, guard_req_domain, guard_req_asid (memory type: ignored), guard_req_write, guard_req_addr,
//             guard_req_bytes (1 .. MAXB, the envelope of one burst), guard_req_id
//   response  guard_rsp_valid/ready, guard_rsp_id, guard_rsp_ok, guard_rsp_fault, guard_rsp_pa  -- in order, one per request, one cycle later
//   guard_rsp_pa = guard_req_addr: THERE IS NO ADDRESS TRANSLATION.  This block is region PROTECTION; it is not an IOMMU and does not claim to be.
//   fault map (P64 FAULT_*)  NOMAP -> 1   PERM / DEVICE -> 2   SPAN / OVERFLOW -> 4 (RANGE)   ZEROLEN / BADLEN / BADOP -> 7 (LEN, contract)
//                            BADDOM / SPOOF -> 1 ("a real guard reports NO_MAP for a foreign domain": the reason is not disclosed)
//
// ADVISORY, like every check-only interface: the DMA enforces the verdict on its own AR/AW channels; the in-flight policy cannot see a burst
// that was granted and is still in flight, so unmap only after quiescing the DMA (P103 docs/03_PROTECTION.md).  For enforcement that does not
// rely on the master, place the master's memory-side port behind an INLINE port of sf_memory_guard instead.
// =============================================================================
`default_nettype none
/* verilator lint_off UNUSEDSIGNAL */
module sf_memory_guard_iommu_if #(
  parameter int ND           = 4,
  parameter int NR           = 4,
  parameter int NP           = 4,
  parameter int AW           = 32,
  parameter int DOMW         = 3,
  parameter int MAXB         = 4096,
  parameter int BW           = 16,       // width of guard_req_bytes
  parameter int PORT         = 0,        // row of the port-binding table that belongs to this DMA
  parameter int LOOKUP_ARCH  = 0,
  parameter int DIAG_PRECISE = 0,
  localparam int NE          = ND * NR
) (
  input  wire logic                     clk,
  input  wire logic                     rst_n,
  input  wire logic [NE-1:0]            t_valid,
  input  wire logic [NE*AW-1:0]         t_base,
  input  wire logic [NE*(AW+1)-1:0]     t_end,
  input  wire logic [NE-1:0]            t_r,
  input  wire logic [NE-1:0]            t_w,
  input  wire logic [NE-1:0]            t_devn,
  input  wire logic [NE*NP-1:0]         t_dev,
  input  wire logic [NP*ND-1:0]         t_allow,
  input  wire logic                     guard_req_valid,
  output logic                          guard_req_ready,
  input  wire logic [DOMW-1:0]          guard_req_domain,
  input  wire logic [3:0]               guard_req_asid,
  input  wire logic                     guard_req_write,
  input  wire logic [AW-1:0]            guard_req_addr,
  input  wire logic [BW-1:0]            guard_req_bytes,
  input  wire logic                     guard_req_id,
  output logic                          guard_rsp_valid,
  input  wire logic                     guard_rsp_ready,
  output logic                          guard_rsp_id,
  output logic                          guard_rsp_ok,
  output logic [3:0]                    guard_rsp_fault,
  output logic [AW-1:0]                 guard_rsp_pa
);
  localparam logic [3:0] FT_NONE = 4'd0, FT_NOMAP = 4'd1, FT_PERM = 4'd2, FT_SPAN = 4'd3, FT_OVERFLOW = 4'd4, FT_ZEROLEN = 4'd5, FT_BADOP = 4'd6,
                         FT_BADDOM = 4'd7, FT_SPOOF = 4'd8, FT_DEVICE = 4'd9, FT_BADLEN = 4'd10;
  /* verilator lint_off UNUSEDSIGNAL */
  wire [3:0] unused_asid = guard_req_asid;
  wire       unused_rr   = guard_rsp_ready;      // the contract: ready is constant 1; every response is consumed in the cycle it is presented
  /* verilator lint_on UNUSEDSIGNAL */
  assign guard_req_ready = 1'b1;
  logic        permit;
  logic [3:0]  fault, f1;
  logic [DOMW-1:0] ed;
  sf_memory_guard_checker #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .LW(BW), .DOMW(DOMW), .PIDX(PORT), .MAXLEN(MAXB), .LEN_POW2(0),
                            .LOOKUP_ARCH(LOOKUP_ARCH), .DIAG_PRECISE(DIAG_PRECISE)) u_chk (
    .c_op({1'b0, guard_req_write}), .c_addr(guard_req_addr), .c_len(guard_req_bytes), .c_dom(guard_req_domain), .allow(t_allow[PORT*ND +: ND]),
    .t_valid(t_valid), .t_base(t_base), .t_end(t_end), .t_r(t_r), .t_w(t_w), .t_devn(t_devn), .t_dev(t_dev),
    .permit(permit), .fault(fault), .edom(ed));
  always_comb begin
    case (fault)
      FT_NONE:                                   f1 = 4'd0;
      FT_PERM, FT_DEVICE:                        f1 = 4'd2;
      FT_SPAN, FT_OVERFLOW:                      f1 = 4'd4;
      FT_ZEROLEN, FT_BADLEN, FT_BADOP:           f1 = 4'd7;
      default:                                   f1 = 4'd1;     // NOMAP, BADDOM, SPOOF
    endcase
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin guard_rsp_valid <= 1'b0; guard_rsp_id <= 1'b0; guard_rsp_ok <= 1'b0; guard_rsp_fault <= 4'd0; guard_rsp_pa <= '0; end
    else begin
      guard_rsp_valid <= guard_req_valid;
      guard_rsp_id    <= guard_req_id;
      guard_rsp_ok    <= guard_req_valid && permit;
      guard_rsp_fault <= guard_req_valid ? f1 : 4'd0;
      guard_rsp_pa    <= (guard_req_valid && permit) ? guard_req_addr : '0;     // identity: no translation; no address leaves on a denial
    end
  end
endmodule
`default_nettype wire
