// =============================================================================
// SilicaFlux -- Project 104 -- MemoryGuard :: sf_memory_guard_regs
//
// The trusted, privileged configuration + diagnostic interface, and the IN-FLIGHT POLICY ENGINE.
//
// BUS (SFB2-style, 32 bit, single outstanding; the ControlCore `ext_*` master port connects as is):
//   cfg_req_valid/ready, cfg_req_write, cfg_req_addr[7:0] (byte; word index = [6:2]), cfg_req_wdata, cfg_req_wstrb
//   cfg_req_priv   -- TRUSTED PRIVILEGE QUALIFIER.  It must be driven by the management plane (ControlCore behind the
//                    secure-boot gate) and by nothing a tenant can reach.  It is a label: the control is that the port is
//                    physically reachable only from the management plane (Citadel integration rule R6, docs/memory_guard/06).
//   cfg_rsp_valid/ready, cfg_rsp_rdata, cfg_rsp_error   (error = the access had NO effect / returned no data)
//
// ACCESS RULES (every access, read or write)
//   !priv                      -> error, STAT_SEC, CN_SEC.  A write has no effect, a read returns 0 (no leak to an unprivileged reader)
//   address outside the map    -> error, STAT_BADADDR
//   write with wstrb != 0xF, or to a read-only register -> error, STAT_ECMD
//   after CTRL.LOCK            -> every write except R_STATUS / R_FLOG_POP / R_CNT_SEL / R_SEL is rejected: error, STAT_LOCKED
//   while a command is in progress -> writes to the staging registers / R_SEL / R_CMD / R_CTRL / R_DRAIN_TMO are rejected: STAT_BUSY
//
// COMMAND PROTOCOL.  Software stages {R_SEL, R_BASE, R_SIZE, R_ATTR, R_ALLOW}, then writes R_CMD.  The command is validated
// at once against the current table (sf_memory_guard_regions).  An invalid command is refused immediately: error response,
// STAT_E*, the table is untouched, the datapath is NOT blocked.  A valid command starts the DRAIN sequence:
//
//   IDLE --valid CMD--> DRAIN      blk = 1  (every port stops ACCEPTING; requests already accepted keep going)
//   DRAIN: when every port is idle (nothing held, nothing outstanding, no error response pending) -> COMMIT:
//          cm_en for ONE cycle, the table changes at the end of that cycle, gen++, blk = 0, STAT_DONE.
//          if R_DRAIN_TMO != 0 and the drain has not finished within R_DRAIN_TMO cycles -> ABORT: the command is NOT applied,
//          blk = 0, STAT_TMO.  (A requester that never takes its response can delay a revocation, never make it unsafe.)
//
// WHY THIS IS TOCTOU-SAFE: the table is written only in a cycle where blk = 1 (so no port accepts a request in that cycle) and
// every port is idle (so no earlier request is still held, being checked or awaiting its memory response).  Hence no request
// ever lives across a change of the table; each request is checked, forwarded and answered under ONE policy generation.
// =============================================================================
`default_nettype none

module sf_memory_guard_regs #(
  parameter int ND     = 4,
  parameter int NR     = 4,
  parameter int NP     = 4,
  parameter int AW     = 32,
  parameter int DBYTES = 8,
  parameter int IDW    = 8,
  parameter int LW     = 4,
  parameter int DOMW   = 3,
  parameter int MAXOUT = 4,
  parameter int FDEPTH = 8,
  parameter int CNTW   = 32,
  parameter int STRICT = 0,
  parameter int CHK_PIPE = 0,
  localparam int PW    = sf_memory_guard_pkg::clog2c(NP),
  localparam int CW    = sf_memory_guard_pkg::clog2c(FDEPTH + 1),
  localparam int NCNT  = 9 + 2 * NP + 16
) (
  input  wire logic                     clk,
  input  wire logic                     rst_n,
  // ---- configuration bus
  input  wire logic                     cfg_req_valid,
  output logic                          cfg_req_ready,
  input  wire logic                     cfg_req_write,
  input  wire logic [7:0]               cfg_req_addr,
  input  wire logic [31:0]              cfg_req_wdata,
  input  wire logic [3:0]               cfg_req_wstrb,
  input  wire logic                     cfg_req_priv,
  output logic                          cfg_rsp_valid,
  input  wire logic                     cfg_rsp_ready,
  output logic [31:0]                   cfg_rsp_rdata,
  output logic                          cfg_rsp_error,
  // ---- to the table
  output logic                          cm_en,
  output logic [3:0]                    cm_kind,
  output logic [3:0]                    cm_dom,
  output logic [3:0]                    cm_idx,
  output logic [3:0]                    cm_port,
  output logic [63:0]                   cm_base,
  output logic [63:0]                   cm_size,
  output logic                          cm_r,
  output logic                          cm_w,
  output logic                          cm_devn,
  output logic [7:0]                    cm_dev,
  output logic [15:0]                   cm_allow,
  input  wire logic                     cm_ok,
  input  wire logic [3:0]               cm_err,
  output logic [3:0]                    rd_dom,
  output logic [3:0]                    rd_idx,
  output logic [3:0]                    rd_port,
  input  wire logic                     rd_valid,
  input  wire logic [63:0]              rd_base,
  input  wire logic [63:0]              rd_end,
  input  wire logic                     rd_r,
  input  wire logic                     rd_w,
  input  wire logic                     rd_devn,
  input  wire logic [7:0]               rd_dev,
  input  wire logic [15:0]              rd_allow,
  // ---- datapath control
  output logic                          blk,
  input  wire logic                     drained,
  output logic [15:0]                   gen16,
  // ---- fault log / counters (privileged read side)
  input  wire logic [CW-1:0]            fl_cnt,
  input  wire logic [IDW-1:0]           fl_id,
  input  wire logic [AW-1:0]            fl_addr,
  input  wire logic [LW-1:0]            fl_len,
  input  wire logic [3:0]               fl_fault,
  input  wire logic [1:0]               fl_op,
  input  wire logic [PW-1:0]            fl_port,
  input  wire logic [DOMW-1:0]          fl_dom,
  input  wire logic [15:0]              fl_gen,
  input  wire logic [31:0]              fl_seq,
  input  wire logic [15:0]              fl_dropped16,
  output logic                          fl_pop,
  input  wire logic [NCNT*CNTW-1:0]     cnt_flat,
  input  wire logic                     fl_ev_drop,
  input  wire logic                     fl_ev_orphan,
  input  wire logic                     fl_ev_fault,
  output logic                          ev_sec,
  output logic                          ev_lockrej,
  output logic                          ev_commit,
  output logic                          ev_cmdrej,
  output logic                          ev_tmo
`ifdef FORMAL
  , output logic                         fv_lock, fv_busy      // observation points for the formal harness
`endif
);
  // PKG-ALIASES-BEGIN (generated by scripts/alias_pkg.py)
  localparam logic [3:0] CE_INDEX = sf_memory_guard_pkg::CE_INDEX;
  localparam logic [3:0] CE_OK = sf_memory_guard_pkg::CE_OK;
  localparam logic [3:0] CE_OVERLAP = sf_memory_guard_pkg::CE_OVERLAP;
  localparam logic [3:0] CE_RANGE = sf_memory_guard_pkg::CE_RANGE;
  localparam logic [3:0] CE_TMO = sf_memory_guard_pkg::CE_TMO;
  localparam int CTRL_LOCK = sf_memory_guard_pkg::CTRL_LOCK;
  localparam logic [15:0] ID_MAGIC = sf_memory_guard_pkg::ID_MAGIC;
  localparam int R_ALLOW = sf_memory_guard_pkg::R_ALLOW;
  localparam int R_ATTR = sf_memory_guard_pkg::R_ATTR;
  localparam int R_BASE_HI = sf_memory_guard_pkg::R_BASE_HI;
  localparam int R_BASE_LO = sf_memory_guard_pkg::R_BASE_LO;
  localparam int R_CAPS = sf_memory_guard_pkg::R_CAPS;
  localparam int R_CMD = sf_memory_guard_pkg::R_CMD;
  localparam int R_CNT_DATA = sf_memory_guard_pkg::R_CNT_DATA;
  localparam int R_CNT_SEL = sf_memory_guard_pkg::R_CNT_SEL;
  localparam int R_CTRL = sf_memory_guard_pkg::R_CTRL;
  localparam int R_DRAIN_TMO = sf_memory_guard_pkg::R_DRAIN_TMO;
  localparam int R_FLOG_CNT = sf_memory_guard_pkg::R_FLOG_CNT;
  localparam int R_FLOG_POP = sf_memory_guard_pkg::R_FLOG_POP;
  localparam int R_FLOG_SEQ = sf_memory_guard_pkg::R_FLOG_SEQ;
  localparam int R_FLOG_W0 = sf_memory_guard_pkg::R_FLOG_W0;
  localparam int R_FLOG_W1 = sf_memory_guard_pkg::R_FLOG_W1;
  localparam int R_FLOG_W2 = sf_memory_guard_pkg::R_FLOG_W2;
  localparam int R_FLOG_W3 = sf_memory_guard_pkg::R_FLOG_W3;
  localparam int R_GEN = sf_memory_guard_pkg::R_GEN;
  localparam int R_ID = sf_memory_guard_pkg::R_ID;
  localparam int R_NCNT = sf_memory_guard_pkg::R_NCNT;
  localparam int R_RD_ALLOW = sf_memory_guard_pkg::R_RD_ALLOW;
  localparam int R_RD_ATTR = sf_memory_guard_pkg::R_RD_ATTR;
  localparam int R_RD_BASE_HI = sf_memory_guard_pkg::R_RD_BASE_HI;
  localparam int R_RD_BASE_LO = sf_memory_guard_pkg::R_RD_BASE_LO;
  localparam int R_RD_END_HI = sf_memory_guard_pkg::R_RD_END_HI;
  localparam int R_RD_END_LO = sf_memory_guard_pkg::R_RD_END_LO;
  localparam int R_SEL = sf_memory_guard_pkg::R_SEL;
  localparam int R_SIZE_HI = sf_memory_guard_pkg::R_SIZE_HI;
  localparam int R_SIZE_LO = sf_memory_guard_pkg::R_SIZE_LO;
  localparam int R_STATE = sf_memory_guard_pkg::R_STATE;
  localparam int R_STATUS = sf_memory_guard_pkg::R_STATUS;
  localparam int R_VERSION = sf_memory_guard_pkg::R_VERSION;
  localparam int STAT_BADADDR = sf_memory_guard_pkg::STAT_BADADDR;
  localparam int STAT_BUSY = sf_memory_guard_pkg::STAT_BUSY;
  localparam int STAT_DONE = sf_memory_guard_pkg::STAT_DONE;
  localparam int STAT_ECMD = sf_memory_guard_pkg::STAT_ECMD;
  localparam int STAT_EINDEX = sf_memory_guard_pkg::STAT_EINDEX;
  localparam int STAT_EOVERLAP = sf_memory_guard_pkg::STAT_EOVERLAP;
  localparam int STAT_ERANGE = sf_memory_guard_pkg::STAT_ERANGE;
  localparam int STAT_FAULT = sf_memory_guard_pkg::STAT_FAULT;
  localparam int STAT_FDROP = sf_memory_guard_pkg::STAT_FDROP;
  localparam int STAT_LOCKED = sf_memory_guard_pkg::STAT_LOCKED;
  localparam int STAT_ORPHAN = sf_memory_guard_pkg::STAT_ORPHAN;
  localparam int STAT_SEC = sf_memory_guard_pkg::STAT_SEC;
  localparam int STAT_TMO = sf_memory_guard_pkg::STAT_TMO;
  localparam logic [31:0] VERSION = sf_memory_guard_pkg::VERSION;
  // PKG-ALIASES-END

  // ------------------------------------------------------------------ state
  logic        lock_q, busy_q, blk_q;
  logic [3:0]  cmd_q, last_err_q;
  logic [31:0] tmo_reg_q, tmo_cnt_q, gen_q;
  logic [12:0] status_q;
  logic [3:0]  sel_dom_q, sel_idx_q, sel_port_q;
  logic [31:0] base_lo_q, base_hi_q, size_lo_q, size_hi_q;
  logic        attr_r_q, attr_w_q, attr_devn_q;
  logic [7:0]  attr_dev_q;
  logic [15:0] allow_q;
  logic [7:0]  cnt_sel_q;
  logic        rsp_v_q, rsp_e_q;
  logic [31:0] rsp_d_q;

  assign blk   = blk_q;
  assign gen16 = gen_q[15:0];

  // staging -> table command
  assign cm_dom   = sel_dom_q;
  assign cm_idx   = sel_idx_q;
  assign cm_port  = sel_port_q;
  assign cm_base  = {base_hi_q, base_lo_q};
  assign cm_size  = {size_hi_q, size_lo_q};
  assign cm_r     = attr_r_q;
  assign cm_w     = attr_w_q;
  assign cm_devn  = attr_devn_q;
  assign cm_dev   = attr_dev_q;
  assign cm_allow = allow_q;
  assign cm_kind  = busy_q ? cmd_q : cfg_req_wdata[3:0];     // idle: the command being validated; busy: the latched command
  assign rd_dom   = sel_dom_q;
  assign rd_idx   = sel_idx_q;
  assign rd_port  = sel_port_q;

  // ------------------------------------------------------------------ access classification
  assign cfg_req_ready = !rsp_v_q;
  wire        acc     = cfg_req_valid && cfg_req_ready;
  wire [4:0]  widx    = cfg_req_addr[6:2];
  wire        a_ok    = (cfg_req_addr[1:0] == 2'b00) && !cfg_req_addr[7];
  wire        full    = (cfg_req_wstrb == 4'hF);

  wire is_diag_w = (widx == 5'(R_STATUS)) || (widx == 5'(R_FLOG_POP)) || (widx == 5'(R_CNT_SEL));
  wire is_sel_w  = (widx == 5'(R_SEL));
  wire is_cfg_w  = (widx == 5'(R_CTRL)) || (widx == 5'(R_DRAIN_TMO)) ||
                   (widx >= 5'(R_BASE_LO) && widx <= 5'(R_CMD));
  wire is_ro_w   = !(is_diag_w || is_sel_w || is_cfg_w);

  wire c_sec     = acc && !cfg_req_priv;
  wire c_badaddr = acc && cfg_req_priv && !a_ok;
  wire c_wbad    = acc && cfg_req_priv && a_ok && cfg_req_write && (!full || is_ro_w);
  wire c_locked  = acc && cfg_req_priv && a_ok && cfg_req_write && full && !is_ro_w && is_cfg_w && lock_q;
  wire c_busy    = acc && cfg_req_priv && a_ok && cfg_req_write && full && !is_ro_w && !lock_q && busy_q && (is_cfg_w || is_sel_w);
  wire c_do      = acc && cfg_req_priv && a_ok && !c_wbad && !c_locked && !c_busy;   // the access is performed
  wire c_do_w    = c_do && cfg_req_write;
  wire c_do_r    = c_do && !cfg_req_write;

  wire w_ctrl    = c_do_w && widx == 5'(R_CTRL);
  wire w_status  = c_do_w && widx == 5'(R_STATUS);
  wire w_tmo     = c_do_w && widx == 5'(R_DRAIN_TMO);
  wire w_sel     = c_do_w && widx == 5'(R_SEL);
  wire w_cmd     = c_do_w && widx == 5'(R_CMD);
  wire w_pop     = c_do_w && widx == 5'(R_FLOG_POP) && cfg_req_wdata[0];
  wire w_cntsel  = c_do_w && widx == 5'(R_CNT_SEL);

  // command start / refusal.  A command is accepted only while idle (busy writes are refused above).
  wire cmd_go    = w_cmd && cm_ok;
  wire cmd_bad   = w_cmd && !cm_ok;
  wire lock_set  = w_ctrl && cfg_req_wdata[CTRL_LOCK];

  // drain / commit
  wire in_drain  = busy_q;
  assign cm_en   = in_drain && blk_q && drained;                       // COMMIT cycle
  wire   tmo_hit = in_drain && !drained && (tmo_reg_q != 32'd0) && (tmo_cnt_q == 32'd0);

  assign ev_sec     = c_sec;
  assign ev_lockrej = c_locked;
  assign ev_commit  = cm_en && cm_ok;
  assign ev_cmdrej  = cmd_bad;
  assign ev_tmo     = tmo_hit;
  assign fl_pop     = w_pop;

  // ------------------------------------------------------------------ sequential state
  logic [12:0] st_set, st_clr;
  always_comb begin
    st_set = '0;
    if (c_sec)     st_set[STAT_SEC]      = 1'b1;
    if (c_locked)  st_set[STAT_LOCKED]   = 1'b1;
    if (c_busy)    st_set[STAT_BUSY]     = 1'b1;
    if (c_badaddr) st_set[STAT_BADADDR]  = 1'b1;
    if (c_wbad)    st_set[STAT_ECMD]     = 1'b1;
    if (cmd_bad) begin
      if (cm_err == CE_RANGE)   st_set[STAT_ERANGE]   = 1'b1;
      else if (cm_err == CE_OVERLAP) st_set[STAT_EOVERLAP] = 1'b1;
      else if (cm_err == CE_INDEX)   st_set[STAT_EINDEX]   = 1'b1;
      else                            st_set[STAT_ECMD]     = 1'b1;
    end
    if (tmo_hit)        st_set[STAT_TMO]    = 1'b1;
    if (cm_en && cm_ok) st_set[STAT_DONE]   = 1'b1;
    if (fl_ev_drop)     st_set[STAT_FDROP]  = 1'b1;
    if (fl_ev_orphan)   st_set[STAT_ORPHAN] = 1'b1;
    if (fl_ev_fault)    st_set[STAT_FAULT]  = 1'b1;
    st_clr = w_status ? cfg_req_wdata[12:0] : 13'd0;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      lock_q <= 1'b0; busy_q <= 1'b0; blk_q <= 1'b0; cmd_q <= 4'd0; last_err_q <= CE_OK;
      tmo_reg_q <= 32'd0; tmo_cnt_q <= 32'd0; gen_q <= 32'd0; status_q <= 13'd0;
      sel_dom_q <= 4'd0; sel_idx_q <= 4'd0; sel_port_q <= 4'd0;
      base_lo_q <= 32'd0; base_hi_q <= 32'd0; size_lo_q <= 32'd0; size_hi_q <= 32'd0;
      attr_r_q <= 1'b0; attr_w_q <= 1'b0; attr_devn_q <= 1'b0; attr_dev_q <= 8'd0; allow_q <= 16'd0;
      cnt_sel_q <= 8'd0;
    end else begin
      status_q <= (status_q | st_set) & ~st_clr;
      if (lock_set) lock_q <= 1'b1;
      if (w_tmo)    tmo_reg_q <= cfg_req_wdata;
      if (w_sel)    begin sel_dom_q <= cfg_req_wdata[3:0]; sel_idx_q <= cfg_req_wdata[11:8]; sel_port_q <= cfg_req_wdata[19:16]; end
      if (w_cntsel) cnt_sel_q <= cfg_req_wdata[7:0];
      if (c_do_w) begin
        case (widx)
          5'(R_BASE_LO): base_lo_q <= cfg_req_wdata;
          5'(R_BASE_HI): base_hi_q <= cfg_req_wdata;
          5'(R_SIZE_LO): size_lo_q <= cfg_req_wdata;
          5'(R_SIZE_HI): size_hi_q <= cfg_req_wdata;
          5'(R_ATTR):    begin attr_r_q <= cfg_req_wdata[0]; attr_w_q <= cfg_req_wdata[1]; attr_devn_q <= cfg_req_wdata[2]; attr_dev_q <= cfg_req_wdata[15:8]; end
          5'(R_ALLOW):   allow_q <= cfg_req_wdata[15:0];
          default: ;
        endcase
      end
      // command / drain state machine
      if (cmd_go) begin
        busy_q <= 1'b1; blk_q <= 1'b1; cmd_q <= cfg_req_wdata[3:0]; tmo_cnt_q <= tmo_reg_q;
      end else if (cmd_bad) begin
        last_err_q <= cm_err;
      end else if (busy_q) begin
        if (cm_en) begin                                   // COMMIT
          busy_q <= 1'b0; blk_q <= 1'b0; gen_q <= gen_q + 32'd1; last_err_q <= CE_OK;
        end else if (tmo_hit) begin                        // ABORT: not applied
          busy_q <= 1'b0; blk_q <= 1'b0; last_err_q <= CE_TMO;
        end else if (tmo_cnt_q != 32'd0) begin
          tmo_cnt_q <= tmo_cnt_q - 32'd1;
        end
      end
    end
  end

  // ------------------------------------------------------------------ read data
  logic [31:0] rdata;
  logic [31:0] cnt_val;
  always_comb begin
    cnt_val = 32'd0;
    for (int c = 0; c < NCNT; c++) if (8'(c) == cnt_sel_q) cnt_val = 32'(cnt_flat[c*CNTW +: CNTW]);
  end
  always_comb begin
    rdata = 32'd0;
    case (widx)
      5'(R_ID):         rdata = {ID_MAGIC, 4'(ND), 4'(NR), 4'(NP), 2'b00, 1'(CHK_PIPE != 0), 1'(STRICT != 0)};
      5'(R_VERSION):    rdata = VERSION;
      5'(R_CTRL):       rdata = {lock_q, 31'd0};
      5'(R_STATUS):     rdata = {(fl_cnt != '0), 18'd0, status_q};
      5'(R_STATE):      rdata = {20'd0, last_err_q, 4'd0, !drained, lock_q, blk_q, busy_q};
      5'(R_GEN):        rdata = gen_q;
      5'(R_DRAIN_TMO):  rdata = tmo_reg_q;
      5'(R_SEL):        rdata = {12'd0, sel_port_q, 4'd0, sel_idx_q, 4'd0, sel_dom_q};
      5'(R_BASE_LO):    rdata = base_lo_q;
      5'(R_BASE_HI):    rdata = base_hi_q;
      5'(R_SIZE_LO):    rdata = size_lo_q;
      5'(R_SIZE_HI):    rdata = size_hi_q;
      5'(R_ATTR):       rdata = {16'd0, attr_dev_q, 5'd0, attr_devn_q, attr_w_q, attr_r_q};
      5'(R_ALLOW):      rdata = {16'd0, allow_q};
      5'(R_CMD):        rdata = 32'd0;
      5'(R_RD_BASE_LO): rdata = rd_base[31:0];
      5'(R_RD_BASE_HI): rdata = rd_base[63:32];
      5'(R_RD_END_LO):  rdata = rd_end[31:0];
      5'(R_RD_END_HI):  rdata = rd_end[63:32];
      5'(R_RD_ATTR):    rdata = {rd_valid, 15'd0, rd_dev, 5'd0, rd_devn, rd_w, rd_r};
      5'(R_RD_ALLOW):   rdata = {16'd0, rd_allow};
      5'(R_FLOG_CNT):   rdata = {fl_dropped16, 8'(FDEPTH), 8'(fl_cnt)};
      5'(R_FLOG_W0):    rdata = {16'(fl_len), 16'(fl_id)};
      5'(R_FLOG_W1):    rdata = 32'(fl_addr);
      5'(R_FLOG_W2):    rdata = 32'(64'(fl_addr) >> 32);
      5'(R_FLOG_W3):    rdata = {fl_gen, 4'(fl_dom), 4'(fl_port), 2'b00, fl_op, fl_fault};
      5'(R_FLOG_SEQ):   rdata = fl_seq;
      5'(R_FLOG_POP):   rdata = 32'd0;
      5'(R_CNT_SEL):    rdata = {24'd0, cnt_sel_q};
      5'(R_CNT_DATA):   rdata = cnt_val;
      5'(R_NCNT):       rdata = 32'(NCNT);
      5'(R_CAPS):       rdata = {4'd0, 4'(MAXOUT), 8'(IDW), 8'(DBYTES), 8'(AW)};
      default:          rdata = 32'd0;
    endcase
  end

  // ------------------------------------------------------------------ response register
  wire rsp_err = acc && (!cfg_req_priv || !a_ok || c_wbad || c_locked || c_busy || cmd_bad);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rsp_v_q <= 1'b0; rsp_e_q <= 1'b0; rsp_d_q <= 32'd0;
    end else begin
      if (acc) begin
        rsp_v_q <= 1'b1;
        rsp_e_q <= rsp_err;
        rsp_d_q <= (c_do_r) ? rdata : 32'd0;          // unprivileged / bad reads return zero
      end else if (rsp_v_q && cfg_rsp_ready) begin
        rsp_v_q <= 1'b0;
      end
    end
  end
  assign cfg_rsp_valid = rsp_v_q;
  assign cfg_rsp_rdata = rsp_d_q;
  assign cfg_rsp_error = rsp_e_q;

`ifdef FORMAL
  assign fv_lock = lock_q;
  assign fv_busy = busy_q;
  // ---- inductive invariants of the in-flight policy engine
  always @(*) if (rst_n) begin
    assert(blk_q == busy_q);                       // ingress is blocked exactly while a command is draining
    assert(!(cm_en && !drained));                  // the table changes only with every port idle ...
    assert(!(cm_en && !blk_q));                    // ... and with ingress blocked
    assert(!(cm_en && lock_q));                    // never after the lock
    assert(!(busy_q && lock_q));                   // the lock cannot be set (nor a command started) in the same state
    assert(!busy_q || cm_ok);                      // the staged command, validated when it started, stays valid until it commits
  end
`endif
endmodule

`default_nettype wire
