// =============================================================================
// SilicaFlux -- Project 104 -- MemoryGuard :: sf_memory_guard
//
// Region-based hardware memory protection for cloud compute.  NP protected ingress ports (default four: DMA, network,
// storage, compute accelerator) sit between the requesters and the memory.  A request reaches memory only through its port's
// enforcement point:
//
//   Request -> trusted domain identification -> address and length validation -> permission lookup -> allow | reject
//           -> memory transaction
//
// This is region-based PROTECTION, not address translation: addresses are never translated (a genuine IOMMU is out of scope
// and is not claimed; docs/memory_guard/07).  Isolation = the verdict of ONE shared table on the whole byte range of every
// transfer, enforced in the datapath.
//
//   NP x sf_memory_guard_port      per-port gate: request register, checker, forward / deny, in-order responses
//   sf_memory_guard_regions        ND x NR region table + trusted port bindings, validated installs, overlap rejection
//   sf_memory_guard_regs           privileged configuration bus, lock, drain-then-commit in-flight policy, diagnostics
//   sf_memory_guard_faults         fault log (port, id, address, op, fault, domain, generation) + saturating counters
//
// PORT INDICES (default wiring of the SilicaFlux cloud stack; any assignment works, the binding register defines identity):
//   0  DMA      StreamDMA          1  NETWORK  PacketCore / PacketForge     2  STORAGE  VirtualIO       3  COMPUTE  TensorCore
//
// ENFORCEMENT RULE (integration rule R1): every master that can reach protected memory is wired to ONE `r_*` port and the
// memory's matching master input is wired to that port's `m_*`.  The guard has no other memory-side output, no bypass input
// and no configuration option that lets a request skip the checker.
// =============================================================================
`default_nettype none

module sf_memory_guard #(
  parameter int ND           = 4,                 // protection domains
  parameter int NR           = 4,                 // regions per domain
  parameter int NP           = 4,                 // protected ingress ports (<= 8)
  parameter int AW           = 32,                // byte address width (<= 63)
  parameter int DW           = 64,                // data bus width in bits; largest legal transfer = DW/8 bytes
  parameter int IDW          = 8,                 // transaction id width (<= 16)
  parameter int DOMW         = 3,                 // width of the domain-claim sideband (values >= ND are INVALID domains)
  parameter int MAXOUT       = 4,                 // outstanding memory transactions per port
  parameter int CHK_PIPE     = 0,                 // 0: verdict in the acting cycle (combinational) | 1: registered verdict (+1 cycle)
  parameter int LOOKUP_ARCH  = 0,                 // 0: ND*NR parallel comparator sets | 1: domain-first multiplex, NR sets
  parameter int DIAG_PRECISE = 1,                 // 1: tell FT_SPAN from FT_NOMAP (extra comparators); never affects permit
  parameter int STRICT       = 0,                 // 1: overlap is rejected across domains too (strict partition)
  parameter int LEN_POW2     = 0,                 // 1: only power-of-two lengths are legal (MemoryMatrix `size` encoding)
  parameter int FLOG_DEPTH   = 8,                 // fault log records
  parameter int CNTW         = 32,                // counter width (<= 32)
  localparam int BW          = DW / 8,
  localparam int LW          = sf_memory_guard_pkg::clog2c(DW / 8 + 1),   // bits to hold 0..DW/8 (and one more above)
  localparam int NE          = ND * NR,
  localparam int PW          = sf_memory_guard_pkg::clog2c(NP),
  localparam int CW          = sf_memory_guard_pkg::clog2c(FLOG_DEPTH + 1),
  localparam int RECW        = IDW + AW + LW + 4 + 2 + DOMW,
  localparam int NCNT        = 9 + 2 * NP + 16
) (
  input  wire logic                     clk,
  input  wire logic                     rst_n,
  // ================================ requester side (one port per physical master)
  input  wire logic [NP-1:0]            r_valid,
  output logic [NP-1:0]                 r_ready,
  input  wire logic [NP*2-1:0]          r_op,           // 0 READ, 1 WRITE, 2/3 unsupported
  input  wire logic [NP*AW-1:0]         r_addr,
  input  wire logic [NP*LW-1:0]         r_len,          // bytes, 1 .. DW/8
  input  wire logic [NP*DW-1:0]         r_wdata,
  input  wire logic [NP*BW-1:0]         r_be,
  input  wire logic [NP*IDW-1:0]        r_id,
  input  wire logic [NP*DOMW-1:0]       r_dom,          // domain CLAIM from the device context (validated against the binding)
  output logic [NP-1:0]                 s_valid,
  input  wire logic [NP-1:0]            s_ready,
  output logic [NP*DW-1:0]              s_rdata,
  output logic [NP*IDW-1:0]             s_id,
  output logic [NP-1:0]                 s_we,
  output logic [NP*3-1:0]               s_status,       // ST_OKAY / ST_SLVERR / ST_DENIED / ST_PROTO
  // ================================ memory side (one master input per port)
  output logic [NP-1:0]                 m_valid,
  input  wire logic [NP-1:0]            m_ready,
  output logic [NP-1:0]                 m_we,
  output logic [NP*AW-1:0]              m_addr,
  output logic [NP*LW-1:0]              m_len,
  output logic [NP*DW-1:0]              m_wdata,
  output logic [NP*BW-1:0]              m_be,
  output logic [NP*IDW-1:0]             m_id,
  output logic [NP*DOMW-1:0]            m_dom,          // verified domain of the permitted request (trusted stamp)
  input  wire logic [NP-1:0]            d_valid,
  output logic [NP-1:0]                 d_ready,
  input  wire logic [NP*DW-1:0]         d_rdata,
  input  wire logic [NP*IDW-1:0]        d_id,
  input  wire logic [NP-1:0]            d_we,
  input  wire logic [NP-1:0]            d_err,
  // ================================ trusted privileged configuration bus (management plane only)
  input  wire logic                     cfg_req_valid,
  output logic                          cfg_req_ready,
  input  wire logic                     cfg_req_write,
  input  wire logic [7:0]               cfg_req_addr,
  input  wire logic [31:0]              cfg_req_wdata,
  input  wire logic [3:0]               cfg_req_wstrb,
  input  wire logic                     cfg_req_priv,
  output logic                          cfg_rsp_valid,
  input  wire logic                     cfg_rsp_ready,
  output logic [31:0]                   cfg_rsp_rdata,
  output logic                          cfg_rsp_error,
  // ================================ status
  output logic                          idle_o,         // no request held or outstanding anywhere
  output logic                          blocking_o,     // ingress blocked by a draining configuration command
  // ================================ read-only export of the policy, for the check-only adapters (sf_memory_guard_grd_if / _iommu_if)
  output logic [NE-1:0]                 o_t_valid,
  output logic [NE*AW-1:0]              o_t_base,
  output logic [NE*(AW+1)-1:0]          o_t_end,
  output logic [NE-1:0]                 o_t_r,
  output logic [NE-1:0]                 o_t_w,
  output logic [NE-1:0]                 o_t_devn,
  output logic [NE*NP-1:0]              o_t_dev,
  output logic [NP*ND-1:0]              o_t_allow
`ifdef FORMAL
  // ---- observation points for the formal harness (absent from the synthesised design)
  , output logic [NP-1:0]               fv_p_idle
  , output logic                        fv_cm_en
  , output logic [NE-1:0]               fv_t_valid
  , output logic [NP*ND-1:0]            fv_t_allow
  , output logic [NE*AW-1:0]            fv_t_base
  , output logic [NE*(AW+1)-1:0]        fv_t_end
`endif
);
  // PKG-ALIASES-BEGIN (generated by scripts/alias_pkg.py)
  // PKG-ALIASES-END

  // ------------------------------------------------------------------ shared policy
  logic [NE-1:0]            t_valid, t_r, t_w, t_devn;
  logic [NE*AW-1:0]         t_base;
  logic [NE*(AW+1)-1:0]     t_end;
  logic [NE*NP-1:0]         t_dev;
  logic [NP*ND-1:0]         t_allow;

  logic                     cm_en, cm_ok, cm_r, cm_w, cm_devn;
  logic [3:0]               cm_kind, cm_dom, cm_idx, cm_port, cm_err;
  logic [63:0]              cm_base, cm_size;
  logic [7:0]               cm_dev;
  logic [15:0]              cm_allow;
  logic [3:0]               rd_dom, rd_idx, rd_port;
  logic                     rd_valid, rd_r, rd_w, rd_devn;
  logic [63:0]              rd_base, rd_end;
  logic [7:0]               rd_dev;
  logic [15:0]              rd_allow;

  sf_memory_guard_regions #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .STRICT(STRICT)) u_regions (
    .clk(clk), .rst_n(rst_n),
    .cm_en(cm_en), .cm_kind(cm_kind), .cm_dom(cm_dom), .cm_idx(cm_idx), .cm_port(cm_port), .cm_base(cm_base), .cm_size(cm_size),
    .cm_r(cm_r), .cm_w(cm_w), .cm_devn(cm_devn), .cm_dev(cm_dev), .cm_allow(cm_allow), .cm_ok(cm_ok), .cm_err(cm_err),
    .rd_dom(rd_dom), .rd_idx(rd_idx), .rd_port(rd_port), .rd_valid(rd_valid), .rd_base(rd_base), .rd_end(rd_end),
    .rd_r(rd_r), .rd_w(rd_w), .rd_devn(rd_devn), .rd_dev(rd_dev), .rd_allow(rd_allow),
    .t_valid(t_valid), .t_base(t_base), .t_end(t_end), .t_r(t_r), .t_w(t_w), .t_devn(t_devn), .t_dev(t_dev), .t_allow(t_allow)
  );

  // ------------------------------------------------------------------ ports
  assign o_t_valid = t_valid; assign o_t_base = t_base; assign o_t_end = t_end; assign o_t_r = t_r; assign o_t_w = t_w;
  assign o_t_devn = t_devn; assign o_t_dev = t_dev; assign o_t_allow = t_allow;

  logic                     blk, drained;
  logic [NP-1:0]            p_idle, ev_req, ev_gnt, ev_fwd, ev_orphan;
  logic [NP*RECW-1:0]       ev_rec;
  assign drained    = &p_idle;
  assign idle_o     = drained;
  assign blocking_o = blk;

`ifdef FORMAL
  assign fv_p_idle = p_idle; assign fv_cm_en = cm_en; assign fv_t_valid = t_valid; assign fv_t_allow = t_allow; assign fv_t_base = t_base; assign fv_t_end = t_end;
`endif

  genvar gp;
  generate
    for (gp = 0; gp < NP; gp++) begin : g_port
      sf_memory_guard_port #(
        .ND(ND), .NR(NR), .NP(NP), .AW(AW), .DW(DW), .IDW(IDW), .LW(LW), .DOMW(DOMW), .PIDX(gp), .MAXLEN(DW / 8),
        .MAXOUT(MAXOUT), .CHK_PIPE(CHK_PIPE), .LOOKUP_ARCH(LOOKUP_ARCH), .DIAG_PRECISE(DIAG_PRECISE), .LEN_POW2(LEN_POW2)
      ) u_port (
        .clk(clk), .rst_n(rst_n), .blk(blk),
        .r_valid(r_valid[gp]), .r_ready(r_ready[gp]), .r_op(r_op[gp*2 +: 2]), .r_addr(r_addr[gp*AW +: AW]),
        .r_len(r_len[gp*LW +: LW]), .r_wdata(r_wdata[gp*DW +: DW]), .r_be(r_be[gp*BW +: BW]), .r_id(r_id[gp*IDW +: IDW]),
        .r_dom(r_dom[gp*DOMW +: DOMW]),
        .s_valid(s_valid[gp]), .s_ready(s_ready[gp]), .s_rdata(s_rdata[gp*DW +: DW]), .s_id(s_id[gp*IDW +: IDW]),
        .s_we(s_we[gp]), .s_status(s_status[gp*3 +: 3]),
        .m_valid(m_valid[gp]), .m_ready(m_ready[gp]), .m_we(m_we[gp]), .m_addr(m_addr[gp*AW +: AW]), .m_len(m_len[gp*LW +: LW]),
        .m_wdata(m_wdata[gp*DW +: DW]), .m_be(m_be[gp*BW +: BW]), .m_id(m_id[gp*IDW +: IDW]), .m_dom(m_dom[gp*DOMW +: DOMW]),
        .d_valid(d_valid[gp]), .d_ready(d_ready[gp]), .d_rdata(d_rdata[gp*DW +: DW]), .d_id(d_id[gp*IDW +: IDW]),
        .d_we(d_we[gp]), .d_err(d_err[gp]),
        .allow(t_allow[gp*ND +: ND]),
        .t_valid(t_valid), .t_base(t_base), .t_end(t_end), .t_r(t_r), .t_w(t_w), .t_devn(t_devn), .t_dev(t_dev),
        .ev_req(ev_req[gp]), .ev_gnt(ev_gnt[gp]), .ev_rec(ev_rec[gp*RECW +: RECW]), .ev_fwd(ev_fwd[gp]),
        .ev_orphan(ev_orphan[gp]), .idle(p_idle[gp])
      );
    end
  endgenerate

  // ------------------------------------------------------------------ faults, configuration
  logic                     ev_sec, ev_lockrej, ev_commit, ev_cmdrej, ev_tmo, fl_pop;
  logic [15:0]              gen16, fl_gen, fl_dropped16;
  logic [CW-1:0]            fl_cnt;
  logic [IDW-1:0]           fl_id;
  logic [AW-1:0]            fl_addr;
  logic [LW-1:0]            fl_len;
  logic [3:0]               fl_fault;
  logic [1:0]               fl_op;
  logic [PW-1:0]            fl_port;
  logic [DOMW-1:0]          fl_dom;
  logic [31:0]              fl_seq;
  logic                     fl_ev_drop, fl_ev_orphan, fl_ev_fault;
  logic [NCNT*CNTW-1:0]     cnt_flat;

  sf_memory_guard_faults #(.NP(NP), .IDW(IDW), .AW(AW), .LW(LW), .DOMW(DOMW), .DEPTH(FLOG_DEPTH), .CNTW(CNTW)) u_faults (
    .clk(clk), .rst_n(rst_n),
    .ev_req(ev_req), .ev_gnt(ev_gnt), .ev_rec(ev_rec), .ev_fwd(ev_fwd), .ev_orphan(ev_orphan),
    .ev_sec(ev_sec), .ev_lockrej(ev_lockrej), .ev_commit(ev_commit), .ev_cmdrej(ev_cmdrej), .ev_tmo(ev_tmo), .gen(gen16),
    .pop(fl_pop), .cnt(fl_cnt), .h_id(fl_id), .h_addr(fl_addr), .h_len(fl_len), .h_fault(fl_fault), .h_op(fl_op),
    .h_port(fl_port), .h_dom(fl_dom), .h_gen(fl_gen), .h_seq(fl_seq), .dropped16(fl_dropped16),
    .ev_drop(fl_ev_drop), .ev_orphan_any(fl_ev_orphan), .ev_fault_any(fl_ev_fault), .cnt_flat(cnt_flat)
  );

  sf_memory_guard_regs #(
    .ND(ND), .NR(NR), .NP(NP), .AW(AW), .DBYTES(DW / 8), .IDW(IDW), .LW(LW), .DOMW(DOMW), .MAXOUT(MAXOUT),
    .FDEPTH(FLOG_DEPTH), .CNTW(CNTW), .STRICT(STRICT), .CHK_PIPE(CHK_PIPE)
  ) u_regs (
    .clk(clk), .rst_n(rst_n),
    .cfg_req_valid(cfg_req_valid), .cfg_req_ready(cfg_req_ready), .cfg_req_write(cfg_req_write), .cfg_req_addr(cfg_req_addr),
    .cfg_req_wdata(cfg_req_wdata), .cfg_req_wstrb(cfg_req_wstrb), .cfg_req_priv(cfg_req_priv),
    .cfg_rsp_valid(cfg_rsp_valid), .cfg_rsp_ready(cfg_rsp_ready), .cfg_rsp_rdata(cfg_rsp_rdata), .cfg_rsp_error(cfg_rsp_error),
    .cm_en(cm_en), .cm_kind(cm_kind), .cm_dom(cm_dom), .cm_idx(cm_idx), .cm_port(cm_port), .cm_base(cm_base), .cm_size(cm_size),
    .cm_r(cm_r), .cm_w(cm_w), .cm_devn(cm_devn), .cm_dev(cm_dev), .cm_allow(cm_allow), .cm_ok(cm_ok), .cm_err(cm_err),
    .rd_dom(rd_dom), .rd_idx(rd_idx), .rd_port(rd_port), .rd_valid(rd_valid), .rd_base(rd_base), .rd_end(rd_end),
    .rd_r(rd_r), .rd_w(rd_w), .rd_devn(rd_devn), .rd_dev(rd_dev), .rd_allow(rd_allow),
    .blk(blk), .drained(drained), .gen16(gen16),
    .fl_cnt(fl_cnt), .fl_id(fl_id), .fl_addr(fl_addr), .fl_len(fl_len), .fl_fault(fl_fault), .fl_op(fl_op), .fl_port(fl_port),
    .fl_dom(fl_dom), .fl_gen(fl_gen), .fl_seq(fl_seq), .fl_dropped16(fl_dropped16), .fl_pop(fl_pop), .cnt_flat(cnt_flat),
    .fl_ev_drop(fl_ev_drop), .fl_ev_orphan(fl_ev_orphan), .fl_ev_fault(fl_ev_fault),
    .ev_sec(ev_sec), .ev_lockrej(ev_lockrej), .ev_commit(ev_commit), .ev_cmdrej(ev_cmdrej), .ev_tmo(ev_tmo)
  );

  initial begin
    if (NP > 8)          $fatal(1, "sf_memory_guard: NP <= 8");
    if (IDW > 16)        $fatal(1, "sf_memory_guard: IDW <= 16");
    if (CNTW > 32)       $fatal(1, "sf_memory_guard: CNTW <= 32");
    if (FLOG_DEPTH > 255) $fatal(1, "sf_memory_guard: FLOG_DEPTH <= 255");
    if (DW < 8 || (DW & (DW - 1)) != 0) $fatal(1, "sf_memory_guard: DW must be a power of two >= 8");
  end
endmodule

`default_nettype wire
