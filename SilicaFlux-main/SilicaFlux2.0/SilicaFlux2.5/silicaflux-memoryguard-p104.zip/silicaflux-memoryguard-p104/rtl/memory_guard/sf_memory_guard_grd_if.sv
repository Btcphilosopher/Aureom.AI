// =============================================================================
// SilicaFlux -- Project 104 -- MemoryGuard :: sf_memory_guard_grd_if
//
// The `grd_*` CHECK interface of MeridianQoS (Project 102) implemented on the MemoryGuard permission table: one query channel and one
// registered, in-order verdict channel per master.  P102's reference guard (sf_meridian_guard_ref) is replaced by this module; the
// port names below are P102's, field for field.
//
//   query    req_valid/ready, req_dom (claim), req_priv, req_write, req_addr       -- one BEAT of BEAT bytes
//   verdict  exactly one rsp per accepted query, IN ORDER, one cycle later (registered): rsp_ok, rsp_fault (P102 F_* codes)
//   fault map  NOMAP / SPAN / OVERFLOW / ZEROLEN / BADLEN -> F_NOMAP (1)    PERM / DEVICE -> F_PERM (2)    BADDOM / SPOOF -> F_DOMAIN (3)
//              BADOP -> F_BADOP (11)
//
// WHAT THIS IS NOT.  A check-only interface is ADVISORY: the fabric (P102's master port) enforces the verdict.  Two consequences, both
// stated in docs/memory_guard/06:
//   * the in-flight policy (drain-then-commit) cannot see transactions that the fabric holds after receiving a grant, so a revocation must be
//     preceded by quiescing the fabric (P102's own rule); `busy_o` only says whether a verdict is pending in this adapter;
//   * `req_priv` is NOT authority and is ignored: the binding of the physical port is.  The guard has no per-region privilege attribute.
// The binding of master m is row PBASE + m of the port-binding table.
// =============================================================================
`default_nettype none
/* verilator lint_off UNUSEDSIGNAL */
module sf_memory_guard_grd_if #(
  parameter int NM           = 2,
  parameter int ND           = 4,
  parameter int NR           = 4,
  parameter int NP           = 4,
  parameter int AW           = 32,
  parameter int DOMW         = 3,
  parameter int BEAT         = 4,        // bytes per query (the fabric's beat)
  parameter int LW           = 4,
  parameter int PBASE        = 0,
  parameter int LOOKUP_ARCH  = 0,
  parameter int DIAG_PRECISE = 0,
  localparam int NE          = ND * NR
) (
  input  wire logic                     clk,
  input  wire logic                     rst_n,
  // policy (from sf_memory_guard: o_t_*)
  input  wire logic [NE-1:0]            t_valid,
  input  wire logic [NE*AW-1:0]         t_base,
  input  wire logic [NE*(AW+1)-1:0]     t_end,
  input  wire logic [NE-1:0]            t_r,
  input  wire logic [NE-1:0]            t_w,
  input  wire logic [NE-1:0]            t_devn,
  input  wire logic [NE*NP-1:0]         t_dev,
  input  wire logic [NP*ND-1:0]         t_allow,
  // MeridianQoS check interface
  input  wire logic [NM-1:0]            req_valid,
  output logic      [NM-1:0]            req_ready,
  input  wire logic [NM*DOMW-1:0]       req_dom,
  input  wire logic [NM-1:0]            req_priv,
  input  wire logic [NM-1:0]            req_write,
  input  wire logic [NM*AW-1:0]         req_addr,
  output logic      [NM-1:0]            rsp_valid,
  output logic      [NM-1:0]            rsp_ok,
  output logic      [NM*4-1:0]          rsp_fault,
  output logic                          busy_o
);
  /* verilator lint_off UNUSEDSIGNAL */
  localparam logic [3:0] F_NOMAP = 4'd1, F_PERM = 4'd2, F_DOMAIN = 4'd3, F_BADOP = 4'd11;
  localparam logic [3:0] FT_NONE = 4'd0, FT_NOMAP = 4'd1, FT_PERM = 4'd2, FT_SPAN = 4'd3, FT_OVERFLOW = 4'd4, FT_ZEROLEN = 4'd5, FT_BADOP = 4'd6,
                         FT_BADDOM = 4'd7, FT_SPOOF = 4'd8, FT_DEVICE = 4'd9, FT_BADLEN = 4'd10;
  assign req_ready = {NM{1'b1}};
  /* verilator lint_off UNUSEDSIGNAL */
  wire [NM-1:0] unused_priv = req_priv;
  /* verilator lint_on UNUSEDSIGNAL */
  genvar m;
  generate for (m = 0; m < NM; m++) begin : g_m
    logic        permit;
    logic [3:0]  fault, f1;
    logic [DOMW-1:0] ed;
    sf_memory_guard_checker #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .LW(LW), .DOMW(DOMW), .PIDX(PBASE + m), .MAXLEN(BEAT), .LEN_POW2(0),
                              .LOOKUP_ARCH(LOOKUP_ARCH), .DIAG_PRECISE(DIAG_PRECISE)) u_chk (
      .c_op({1'b0, req_write[m]}), .c_addr(req_addr[m*AW +: AW]), .c_len(LW'(BEAT)), .c_dom(req_dom[m*DOMW +: DOMW]), .allow(t_allow[(PBASE + m)*ND +: ND]),
      .t_valid(t_valid), .t_base(t_base), .t_end(t_end), .t_r(t_r), .t_w(t_w), .t_devn(t_devn), .t_dev(t_dev),
      .permit(permit), .fault(fault), .edom(ed));
    always_comb begin
      case (fault)
        FT_NONE:                          f1 = 4'd0;
        FT_PERM, FT_DEVICE:               f1 = F_PERM;
        FT_BADDOM, FT_SPOOF:              f1 = F_DOMAIN;
        FT_BADOP:                         f1 = F_BADOP;
        default:                          f1 = F_NOMAP;
      endcase
    end
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin rsp_valid[m] <= 1'b0; rsp_ok[m] <= 1'b0; rsp_fault[m*4 +: 4] <= 4'd0; end
      else begin
        rsp_valid[m] <= req_valid[m];
        rsp_ok[m]    <= req_valid[m] && permit;
        rsp_fault[m*4 +: 4] <= req_valid[m] ? f1 : 4'd0;
      end
    end
  end endgenerate
  assign busy_o = |rsp_valid;
endmodule
`default_nettype wire
