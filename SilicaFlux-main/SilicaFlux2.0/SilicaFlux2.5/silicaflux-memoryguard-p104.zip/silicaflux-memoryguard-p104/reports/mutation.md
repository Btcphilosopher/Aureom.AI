# Mutation campaign (simulation)

One planted RTL defect each (`scripts/mutants.py`).  A mutant is run against the random adversarial testbench (checker mutants first against the Python vectors); if it survives, against the directed testbench.  KILLED = a run did not print `TB_RESULT: PASS`.

| mutant | file | killed by | result | defect |
|---|---|---|---|---|
| C01 | sf_memory_guard_checker.sv | tb_checker_vec (Python vectors) | **KILLED** | lower bound of the region ignored (access below the base is granted) |
| C02 | sf_memory_guard_checker.sv | tb_checker_vec (Python vectors) | **KILLED** | only the FIRST byte is checked against the end of the region (the classic bug the brief warns about) |
| C03 | sf_memory_guard_checker.sv | tb_checker_vec (Python vectors) | **KILLED** | address overflow not detected |
| C04 | sf_memory_guard_checker.sv | tb_checker_vec (Python vectors) | **KILLED** | trusted port binding ignored (any port may claim any domain) |
| C05 | sf_memory_guard_checker.sv | tb_checker_vec (Python vectors) | **KILLED** | a WRITE is checked against the READ right |
| C06 | sf_memory_guard_checker.sv | tb_checker_vec (Python vectors) | **KILLED** | device permissions ignored |
| C07 | sf_memory_guard_checker.sv | tb_checker_vec (Python vectors) | **KILLED** | zero-length transfers accepted |
| C08 | sf_memory_guard_checker.sv | tb_checker_vec (Python vectors) | **KILLED** | a region of ANY domain grants the access (no domain isolation) |
| C09 | sf_memory_guard_checker.sv | tb_checker_vec (Python vectors) | **KILLED** | invalid domain numbers accepted as a valid domain |
| C10 | sf_memory_guard_checker.sv | tb_checker_vec (Python vectors) | **KILLED** | over-long transfers accepted |
| R01 | sf_memory_guard_regions.sv | tb_mg_random | **KILLED** | overlapping regions are accepted at install time |
| R02 | sf_memory_guard_regions.sv | tb_mg_random | **KILLED** | base + size may leave the address space |
| R03 | sf_memory_guard_regions.sv | tb_mg_random | **KILLED** | re-installing a slot over itself is reported as an overlap |
| R04 | sf_memory_guard_regions.sv | - | **SURVIVED** | an invalid command is written to the table when cm_en is raised — redundant defence in depth: in the integrated design cm_en is raised only for a command the engine has validated, so no simulation can reach it; killed formally by fv_mg_regions (cm_en free) |
| P01 | sf_memory_guard_port.sv | tb_mg_random | **KILLED** | the verdict is not consulted: every request reaches the memory |
| P02 | sf_memory_guard_port.sv | tb_mg_random | **KILLED** | an error response may overtake earlier responses |
| P03 | sf_memory_guard_port.sv | tb_mg_random | **KILLED** | byte enables are not clipped to the length |
| P04 | sf_memory_guard_port.sv | tb_mg_random | **KILLED** | write data of a DENIED request is driven onto the memory side |
| P05 | sf_memory_guard_port.sv | tb_mg_random | **KILLED** | ingress is not blocked during a configuration drain |
| P06 | sf_memory_guard_port.sv | tb_mg_directed | **KILLED** | an orphan memory response is delivered to the requester |
| P07 | sf_memory_guard_port.sv | tb_mg_random | **KILLED** | idle ignores a pending error response (the drain can commit under a request) |
| P08 | sf_memory_guard_port.sv | tb_mg_random | **KILLED** | malformed requests are answered DENIED instead of PROTO |
| P09 | sf_memory_guard_port.sv | tb_mg_random | **KILLED** | the address of a denied request is driven onto the memory side |
| P10 | sf_memory_guard_port.sv | - | **SURVIVED** | a request is forwarded while an error response is still pending (response reordering) — internal-invariant mutant: forwarding while an error response is pending is masked at the interface by the response multiplexer (the error response keeps priority, so order is preserved); killed formally by fv_mg_port (invariant R4: an error response only exists with nothing outstanding) |
| P11 | sf_memory_guard_port.sv | tb_mg_random | **KILLED** | an error response carries memory data |
| S01 | sf_memory_guard_regs.sv | tb_mg_random | **KILLED** | the table is committed without waiting for the datapath to drain (TOCTOU) |
| S02 | sf_memory_guard_regs.sv | tb_mg_directed | **KILLED** | the configuration lock does not lock |
| S03 | sf_memory_guard_regs.sv | tb_mg_random | **KILLED** | unprivileged accesses are performed (privilege not checked) |
| S04 | sf_memory_guard_regs.sv | tb_mg_random | **KILLED** | ingress is not blocked while a command drains |
| S05 | sf_memory_guard_regs.sv | tb_mg_random | **KILLED** | an invalid command starts a drain and commits |
| S06 | sf_memory_guard_regs.sv | tb_mg_directed | **KILLED** | the lock can be cleared by a write to CTRL |
| T01 | sf_memory_guard.sv | tb_mg_random | **KILLED** | drained = ANY port idle (instead of all) |
| F01 | sf_memory_guard_faults.sv | tb_mg_random | **KILLED** | the fault log overwrites when full |

31 / 33 mutants killed.
