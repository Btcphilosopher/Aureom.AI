# Simulation regression

Verilator 5.020, `--binary --timing`; a run passes iff its log contains `TB_RESULT: PASS`. Regenerate with `scripts/regress.py`.

| run | testbench | parameters | checks | result | s | what it covers |
|---|---|---|---:|---|---:|---|
| dir_default | tb_mg_directed.sv | defaults | 7021 | **PASS** | 390.3 | default configuration: 4 domains x 4 regions, 4 ports, AW 16, DW 64 |
| dir_pipe1 | tb_mg_directed.sv | CHK_PIPE=1 | 7021 | **PASS** | 390.3 | registered verdict stage (+1 cycle) |
| dir_lookup1 | tb_mg_directed.sv | LOOKUP_ARCH=1 | 7021 | **PASS** | 390.9 | domain-first multiplexed lookup |
| dir_strict | tb_mg_directed.sv | STRICT=1 | 7019 | **PASS** | 384.0 | strict partition (no byte mapped for two domains) |
| dir_pow2_nodiag | tb_mg_directed.sv | LEN_POW2=1, DIAG_PRECISE=0 | 3885 | **PASS** | 387.0 | power-of-two lengths only; imprecise diagnostics |
| dir_out1 | tb_mg_directed.sv | MAXOUT=1 | 7021 | **PASS** | 387.4 | one outstanding memory transaction per port |
| dir_dw256_pipe | tb_mg_directed.sv | DW=256, CHK_PIPE=1, LOOKUP_ARCH=1 | 76213 | **PASS** | 199.2 | 256-bit data bus (MemoryMatrix width), registered, muxed |
| dir_nr8_log2 | tb_mg_directed.sv | NR=8, FLOG_DEPTH=2 | 7029 | **PASS** | 203.4 | 8 regions per domain, 2-entry fault log |
| vec_default | tb_checker_vec.sv | defaults | 240000 | **PASS** | 45.9 | 240k queries, AW 32, 4 x 4 table, both lookup architectures, fault codes included |
| vec_aw48_nd3_np5 | tb_checker_vec.sv | ND=3, NR=3, NP=5, AW=48 | 180000 | **PASS** | 51.7 | 3 domains, 5 ports, 48-bit addresses |
| vec_pow2_nodiag | tb_checker_vec.sv | AW=20, LEN_POW2=1, DIAG=0 | 180000 | **PASS** | 31.5 | power-of-two lengths, imprecise diagnostics |
| vec_maxlen32 | tb_checker_vec.sv | AW=16, NR=8, MAXLEN=32, LW=6 | 180000 | **PASS** | 28.7 | 32-byte beats (256-bit bus), 8 regions per domain |
| vec_aw63 | tb_checker_vec.sv | AW=63, NP=2 | 180000 | **PASS** | 20.9 | 63-bit address space (largest supported) |
| rnd_default | tb_mg_random.sv | SEED=1 | 145123 | **PASS** | 34.4 | adversarial random, default configuration |
| rnd_default_s2 | tb_mg_random.sv | SEED=2 | 142523 | **PASS** | 30.4 | adversarial random, seed 2 |
| rnd_pipe1 | tb_mg_random.sv | SEED=3, CHK_PIPE=1 | 139003 | **PASS** | 31.1 | random, registered verdict |
| rnd_lookup1 | tb_mg_random.sv | SEED=4, LOOKUP_ARCH=1 | 137520 | **PASS** | 32.0 | random, muxed lookup |
| rnd_strict | tb_mg_random.sv | SEED=5, STRICT=1 | 153459 | **PASS** | 32.1 | random, strict partition |
| rnd_pow2 | tb_mg_random.sv | SEED=6, LEN_POW2=1, DIAG_PRECISE=0 | 148035 | **PASS** | 32.5 | random, power-of-two lengths, imprecise diagnostics |
| rnd_out1 | tb_mg_random.sv | SEED=7, MAXOUT=1, CHK_PIPE=1 | 142494 | **PASS** | 31.8 | random, one outstanding per port, registered |
| rnd_2x2x2 | tb_mg_random.sv | SEED=8, ND=2, NR=2, NP=2 | 88266 | **PASS** | 22.8 | 2 domains, 2 regions, 2 ports |
| rnd_3x3x3 | tb_mg_random.sv | SEED=9, ND=3, NR=3, NP=3 | 115634 | **PASS** | 27.1 | 3 domains (not a power of two), 3 regions, 3 ports |
| rnd_8x2x8 | tb_mg_random.sv | SEED=10, ND=8, NR=2, NP=8 | 186209 | **PASS** | 30.5 | 8 domains (no invalid encodings), 8 ports |
| rnd_5x4x6_pipe_lk | tb_mg_random.sv | SEED=11, ND=5, NR=4, NP=6, CHK_PIPE=1, LOOKUP_ARCH=1 | 175051 | **PASS** | 31.0 | 5 domains, 6 ports, registered + muxed |
| rnd_dw128 | tb_mg_random.sv | SEED=12, DW=128 | 138446 | **PASS** | 29.6 | 128-bit data bus |
| rnd_dw32 | tb_mg_random.sv | SEED=15, DW=32, MAXOUT=2 | 141903 | **PASS** | 28.4 | 32-bit data bus, 2 outstanding |
| mm_random | tb_mg_random.sv | SEED=21, LEN_POW2=1, DIAG_PRECISE=0, NCYC=60000 | 61126 | **PASS** | 38.5 | INTEGRATION: the guard in front of the REAL MemoryMatrix (P101, 4 banks, 64 KiB), 4 requesters + host port; end-to-end memory image check |
| mm_random_ecc_pipe | tb_mg_random.sv | SEED=22, LEN_POW2=1, NCYC=60000, CHK_PIPE=1, MM_ECC=1 | 59325 | **PASS** | 42.3 | INTEGRATION: MemoryMatrix with SECDED ECC, registered verdict |
| adapters | tb_mg_adapters.sv | defaults | 63560 | **PASS** | 28.5 | check-only adapters: MeridianQoS grd_* and StreamDMA / CloudDMA IOMMU contracts vs the oracle (in-order registered verdicts, fault mapping, pa = addr) |
| adapters_pipe_lk | tb_mg_adapters.sv | LOOKUP_ARCH=1, DIAG_PRECISE=0 | 63560 | **PASS** | 30.2 | the same, multiplexed lookup, imprecise diagnostics |
| abi_check | tb_abi_check.sv | defaults | 12 | **PASS** | 0.1 | op codes, response status codes and the fault code points of the grd_* adapter equal the vendored P102 package |
| rnd_midreset | tb_mg_random.sv | SEED=13, MIDRESET=1 | 137605 | **PASS** | 35.2 | reset under load in the middle of the run |
| rnd_deep_strict_pipe | tb_mg_random.sv | SEED=14, STRICT=1, CHK_PIPE=1, NCYC=400000 | 395513 | **PASS** | 24.9 | 400k cycles, strict, registered |

33 / 33 runs passed, 3716597 checks in total.
