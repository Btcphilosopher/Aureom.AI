# Formal verification results

Yosys 0.33 -> SMT2 -> `yosys-smtbmc` + z3.  Regenerate with `scripts/formal.py --mutants`.

* **PASSED** on a `comb` job: proved for ALL inputs.  **PASSED** on a `prove` job: UNBOUNDED proof (base case + k-induction).
* **WITNESSED**: a reachability witness failed as it must (the harness is not vacuous).  **KILLED**: a planted defect was caught.

| job | kind | harness | parameters | depth | result | s | what it establishes |
|---|---|---|---|---:|---|---:|---|
| chk_arch0 | comb | chk | ND=4, NR=2, NP=3, AW=8, LW=3, PIDX=1, MAXLEN=5, ARCH=0, DIAG=1 | 1 | **PASSED** | 4.8 | S0..S5: permit and fault code = independent specification; invalid domains, overflow, whole-range containment (first AND last AND any byte), right and device permission; arch 1 and imprecise diagnostics agree |
| chk_arch1 | comb | chk | ND=4, NR=2, NP=3, AW=8, LW=3, PIDX=1, MAXLEN=5, ARCH=1, DIAG=1 | 1 | **PASSED** | 7.6 | the same with the domain-first multiplexed lookup as the design under proof |
| chk_nd3 | comb | chk | ND=3, NR=3, NP=4, AW=10, LW=3, PIDX=3, MAXLEN=6, ARCH=0, DIAG=0 | 1 | **PASSED** | 8.8 | 3 domains (not a power of two), 3 regions, 4 ports, imprecise diagnostics |
| chk_pow2 | comb | chk | ND=2, NR=3, NP=2, AW=9, LW=4, PIDX=0, MAXLEN=8, ARCH=1, DIAG=1, LEN_POW2=1 | 1 | **PASSED** | 15.3 | power-of-two lengths only |
| chk_nr4 | comb | chk | ND=2, NR=4, NP=3, AW=10, LW=4, PIDX=2, MAXLEN=8, ARCH=0, DIAG=1 | 1 | **PASSED** | 67.0 | 4 regions per domain, 10-bit addresses (the full 4 x 4 x 32-bit instance is beyond z3 -- see docs/memory_guard/08_VERIFICATION.md; the Python vectors cover it by simulation) |
| chk_aw63 | comb | chk | ND=2, NR=2, NP=2, AW=63, LW=4, PIDX=1, MAXLEN=8, ARCH=1, DIAG=1 | 1 | **PASSED** | 6.6 | 63-bit address space (largest supported) |
| regions_ns | prove | regions | ND=3, NR=2, NP=3, AW=6, STRICT=0 | 6 | **PASSED** | 1.2 | R0..R5: default deny, table invariant (no overlap within a domain, well-formed regions), changes only on commit, validation = specification, effect of each command |
| regions_st | prove | regions | ND=3, NR=2, NP=3, AW=6, STRICT=1 | 6 | **PASSED** | 5.4 | the same with STRICT partition (no overlap across domains either) |
| regions_big | prove | regions | ND=4, NR=3, NP=4, AW=8, STRICT=0 | 6 | **PASSED** | 3.8 | 4 domains x 3 regions, 4 ports, AW 8 |
| cfg_ns | prove | cfg | ND=3, NR=2, NP=2, AW=6, STRICT=0 | 12 | **PASSED** | 3.6 | C1..C7: drain-then-commit, trusted control, lock, privilege, abort, ingress block |
| cfg_st | prove | cfg | ND=3, NR=2, NP=2, AW=6, STRICT=1 | 12 | **PASSED** | 19.0 | the same with STRICT partition |
| port_p0_a0 | prove | port | CHK_PIPE=0, ARCH=0 | 10 | **PASSED** | 11.3 | G1..G7, unbounded: only permitted requests reach the memory, bit for bit; denials; ordered responses; blocking; idle |
| port_p0_a1 | prove | port | CHK_PIPE=0, ARCH=1 | 10 | **PASSED** | 13.8 | the same with the multiplexed lookup |
| port_p1_a0 | prove | port | CHK_PIPE=1, ARCH=0 | 10 | **PASSED** | 131.9 | the same with the registered verdict stage (two requests held) |
| port_p1_a1 | prove | port | CHK_PIPE=1, ARCH=1 | 10 | **PASSED** | 164.0 | registered verdict, multiplexed lookup |
| port_orphan0 | prove | port | CHK_PIPE=0, ORPHAN=1 | 10 | **PASSED** | 9.8 | orphan memory responses are drained and never delivered (the memory is NOT assumed well behaved) |
| port_orphan1 | prove | port | CHK_PIPE=1, ORPHAN=1 | 10 | **PASSED** | 113.8 | the same with the registered verdict stage |
| port_pow2 | prove | port | CHK_PIPE=1, LEN_POW2=1, DIAG=0, MAXOUT=1 | 10 | **PASSED** | 85.1 | power-of-two lengths, imprecise diagnostics, one outstanding transaction |
| port_big | prove | port | CHK_PIPE=0, ND=4, NR=2, NP=3, AW=8, DW=32, IDW=3, LW=3, MAXLEN=4, MAXOUT=3, PIDX=2 | 10 | **PASSED** | 77.8 | 4 domains, 3 ports, AW 8, 32-bit data, 3 outstanding |
| top_p0 | prove | top | CHK_PIPE=0 | 10 | **PASSED** | 4.4 | W1..W5 on the composed design: the table changes only after a commit with every port idle and ingress blocked; no commit under any accepted-unanswered request; blocking_o => not ready |
| top_p1 | prove | top | CHK_PIPE=1 | 10 | **PASSED** | 4.6 | the same with the registered verdict stage |
| top_st | prove | top | CHK_PIPE=0, STRICT=1 | 10 | **PASSED** | 13.0 | the same with STRICT partition |
| vac_port_1 | vac | port | CHK_PIPE=0, VAC=1 | 12 | **WITNESSED** | 1.2 | witness: a permitted request exists |
| vac_port_2 | vac | port | CHK_PIPE=0, VAC=2 | 12 | **WITNESSED** | 1.5 | witness: a permitted WRITE reaches the memory |
| vac_port_3 | vac | port | CHK_PIPE=0, VAC=3 | 12 | **WITNESSED** | 1.3 | witness: a denial is requested |
| vac_port_4 | vac | port | CHK_PIPE=0, VAC=4 | 12 | **WITNESSED** | 3.1 | witness: a DENIED response |
| vac_port_5 | vac | port | CHK_PIPE=0, VAC=5 | 12 | **WITNESSED** | 2.8 | witness: a PROTO response |
| vac_port_6 | vac | port | CHK_PIPE=0, VAC=6 | 12 | **WITNESSED** | 2.1 | witness: an SLVERR passes through |
| vac_port_8 | vac | port | CHK_PIPE=0, VAC=8 | 12 | **WITNESSED** | 0.8 | witness: ingress block holds a request back |
| vac_port_9 | vac | port | CHK_PIPE=0, VAC=9 | 12 | **WITNESSED** | 1.8 | witness: the outstanding window fills |
| vac_port_10 | vac | port | CHK_PIPE=0, VAC=10 | 12 | **WITNESSED** | 0.8 | witness: a denial is retired |
| vac_port_7 | vac | port | CHK_PIPE=1, VAC=7 | 12 | **WITNESSED** | 1.1 | witness: two requests held at once |
| vac_cfg_1 | vac | cfg | VAC=1 | 18 | **WITNESSED** | 0.7 | witness: a command commits |
| vac_cfg_2 | vac | cfg | VAC=2 | 18 | **WITNESSED** | 0.9 | witness: a drain times out |
| vac_cfg_3 | vac | cfg | VAC=3 | 18 | **WITNESSED** | 0.8 | witness: the lock is set |
| vac_cfg_4 | vac | cfg | VAC=4 | 18 | **WITNESSED** | 0.7 | witness: an unprivileged access is refused |
| vac_cfg_5 | vac | cfg | VAC=5 | 18 | **WITNESSED** | 2.5 | witness: a commit with regions installed |
| vac_regions_1 | vac | regions | VAC=1 | 8 | **WITNESSED** | 0.8 | witness: a region is installed |
| vac_regions_2 | vac | regions | VAC=2 | 8 | **WITNESSED** | 0.9 | witness: an overlap is refused |
| vac_regions_3 | vac | regions | VAC=3 | 8 | **WITNESSED** | 0.8 | witness: an out-of-range region is refused |
| vac_regions_4 | vac | regions | VAC=4 | 8 | **WITNESSED** | 0.8 | witness: a port is bound |
| vac_regions_5 | vac | regions | VAC=5 | 8 | **WITNESSED** | 0.8 | witness: an install is valid with other regions present |
| vac_chk_1 | vac | chk | ND=4, NR=2, NP=3, AW=8, LW=3, PIDX=1, MAXLEN=5, ARCH=0, DIAG=1, VAC=1 | 1 | **WITNESSED** | 0.7 | witness: a permitted request |
| vac_chk_2 | vac | chk | ND=4, NR=2, NP=3, AW=8, LW=3, PIDX=1, MAXLEN=5, ARCH=0, DIAG=1, VAC=2 | 1 | **WITNESSED** | 0.7 | witness: a PERM denial |
| vac_chk_3 | vac | chk | ND=4, NR=2, NP=3, AW=8, LW=3, PIDX=1, MAXLEN=5, ARCH=0, DIAG=1, VAC=3 | 1 | **WITNESSED** | 0.7 | witness: a SPAN denial |
| vac_chk_4 | vac | chk | ND=4, NR=2, NP=3, AW=8, LW=3, PIDX=1, MAXLEN=5, ARCH=0, DIAG=1, VAC=4 | 1 | **WITNESSED** | 0.7 | witness: a DEVICE denial |
| vac_chk_5 | vac | chk | ND=4, NR=2, NP=3, AW=8, LW=3, PIDX=1, MAXLEN=5, ARCH=0, DIAG=1, VAC=5 | 1 | **WITNESSED** | 0.7 | witness: a permitted WRITE |
| vac_chk_6 | vac | chk | ND=4, NR=2, NP=3, AW=8, LW=3, PIDX=1, MAXLEN=5, ARCH=0, DIAG=1, VAC=6 | 1 | **WITNESSED** | 0.7 | witness: a SPOOF denial |
| vac_chk_7 | vac | chk | ND=4, NR=2, NP=3, AW=8, LW=3, PIDX=1, MAXLEN=5, ARCH=0, DIAG=1, VAC=7 | 1 | **WITNESSED** | 0.7 | witness: an OVERFLOW denial |
| vac_chk_8 | vac | chk | ND=4, NR=2, NP=3, AW=8, LW=3, PIDX=1, MAXLEN=5, ARCH=0, DIAG=1, VAC=8 | 1 | **WITNESSED** | 0.7 | witness: a NOMAP denial |
| vac_chk_9 | vac | chk | ND=4, NR=2, NP=3, AW=8, LW=3, PIDX=1, MAXLEN=5, ARCH=0, DIAG=1, VAC=9 | 1 | **WITNESSED** | 0.7 | witness: a grant ending exactly at the top of the address space |

## Mutation campaign (formal)

One planted RTL defect each; the harness named must FAIL.

| mutant | harness | caught by | result | defect |
|---|---|---|---|---|
| mut_C01 | chk | chk_arch0 | **KILLED** | lower bound of the region ignored (access below the base is granted) |
| mut_C02 | chk | chk_arch0 | **KILLED** | only the FIRST byte is checked against the end of the region (the classic bug the brief warns about) |
| mut_C03 | chk | chk_arch0 | **KILLED** | address overflow not detected |
| mut_C04 | chk | chk_arch0 | **KILLED** | trusted port binding ignored (any port may claim any domain) |
| mut_C05 | chk | chk_arch0 | **KILLED** | a WRITE is checked against the READ right |
| mut_C06 | chk | chk_arch0 | **KILLED** | device permissions ignored |
| mut_C07 | chk | chk_arch0 | **KILLED** | zero-length transfers accepted |
| mut_C08 | chk | chk_arch0 | **KILLED** | a region of ANY domain grants the access (no domain isolation) |
| mut_C09 | chk | chk_arch0 | **KILLED** | invalid domain numbers accepted as a valid domain |
| mut_C10 | chk | chk_arch0 | **KILLED** | over-long transfers accepted |
| mut_P01 | port | port_p0_a0 | **KILLED** | the verdict is not consulted: every request reaches the memory |
| mut_P02 | port | port_p0_a0 | **KILLED** | an error response may overtake earlier responses |
| mut_P03 | port | port_p0_a0 | **KILLED** | byte enables are not clipped to the length |
| mut_P04 | port | port_p0_a0 | **KILLED** | write data of a DENIED request is driven onto the memory side |
| mut_P05 | port | port_p0_a0 | **KILLED** | ingress is not blocked during a configuration drain |
| mut_P06 | port | port_orphan0 | **KILLED** | an orphan memory response is delivered to the requester |
| mut_P07 | port | port_p0_a0 | **KILLED** | idle ignores a pending error response (the drain can commit under a request) |
| mut_P08 | port | port_p0_a0 | **KILLED** | malformed requests are answered DENIED instead of PROTO |
| mut_P09 | port | port_p0_a0 | **KILLED** | the address of a denied request is driven onto the memory side |
| mut_P10 | port | port_p0_a0 | **KILLED** | a request is forwarded while an error response is still pending (response reordering) |
| mut_P11 | port | port_p0_a0 | **KILLED** | an error response carries memory data |
| mut_R01 | regions | regions_ns | **KILLED** | overlapping regions are accepted at install time |
| mut_R01 | cfg | cfg_ns | **KILLED** | overlapping regions are accepted at install time |
| mut_R02 | regions | regions_ns | **KILLED** | base + size may leave the address space |
| mut_R02 | cfg | cfg_ns | **KILLED** | base + size may leave the address space |
| mut_R03 | regions | regions_ns | **KILLED** | re-installing a slot over itself is reported as an overlap |
| mut_R04 | regions | regions_ns | **KILLED** | an invalid command is written to the table when cm_en is raised |
| mut_S01 | cfg | cfg_ns | **KILLED** | the table is committed without waiting for the datapath to drain (TOCTOU) |
| mut_S01 | top | top_p0 | **KILLED** | the table is committed without waiting for the datapath to drain (TOCTOU) |
| mut_S02 | cfg | cfg_ns | **KILLED** | the configuration lock does not lock |
| mut_S03 | cfg | cfg_ns | **KILLED** | unprivileged accesses are performed (privilege not checked) |
| mut_S04 | cfg | cfg_ns | **KILLED** | ingress is not blocked while a command drains |
| mut_S05 | cfg | cfg_ns | **KILLED** | an invalid command starts a drain and commits |
| mut_S06 | cfg | cfg_ns | **KILLED** | the lock can be cleared by a write to CTRL |
| mut_T01 | top | top_p0 | **KILLED** | drained = ANY port idle (instead of all) |

86 jobs, 0 not as expected.
