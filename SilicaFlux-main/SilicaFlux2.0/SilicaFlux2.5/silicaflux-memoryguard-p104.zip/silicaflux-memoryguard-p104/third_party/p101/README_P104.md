# Vendored: MemoryMatrix (Project 101) RTL -- byte-identical, unmodified

Source: `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-memorymatrix-p101.zip`, directory `silicaflux-memorymatrix/rtl/memory/`
(including its own `third_party/` with PROVENANCE.md and SHA256SUMS, which are the original files).  It is used ONLY by the integration
test (`tests/memory_guard/tb_mg_random.sv` built with `+define+MG_EXT_MEM`), as the real banked SRAM behind the guard.  Nothing in
`rtl/memory_guard/` depends on it.  `SHA256SUMS.p104` lists the hash of every file as copied (compare with the archive to check).
Licence: none stated in the source archives (see the original PROVENANCE.md).
