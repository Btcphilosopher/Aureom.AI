// =============================================================================
// Check-only adapters: sf_memory_guard_grd_if (MeridianQoS P102 `grd_*` contract) and sf_memory_guard_iommu_if (StreamDMA P103 / CloudDMA
// P64 IOMMU contract), against the independent oracle, on the SAME table the inline ports use (programmed through the trusted bus).
// Contract checks: exactly one verdict per accepted query, in order, one cycle later; default deny after reset; fault-code mapping;
// guard_rsp_pa == addr for a grant and 0 for a denial (no translation, no address leaves on a denial); the id is echoed.
// =============================================================================
`timescale 1ns/1ps
module tb_mg_adapters #(
  parameter int ND = 4, parameter int NR = 4, parameter int NP = 4, parameter int AW = 16, parameter int DW = 64, parameter int IDW = 8,
  parameter int DOMW = 3, parameter int MAXOUT = 4, parameter int CHK_PIPE = 0, parameter int LOOKUP_ARCH = 0,
  parameter int DIAG_PRECISE = 1, parameter int STRICT = 0, parameter int LEN_POW2 = 0, parameter int FLOG_DEPTH = 8, parameter int NQ = 60000
);
`include "tb_common.svh"
  localparam int NM = 2;
  localparam int BEAT = 4;
  logic [NM-1:0] g_valid, g_ready, g_wr, g_rvalid, g_rok;
  logic [NM*DOMW-1:0] g_dom; logic [NM-1:0] g_priv; logic [NM*AW-1:0] g_addr; logic [NM*4-1:0] g_rfault;
  logic        i_valid, i_ready, i_wr, i_id, i_rvalid, i_rid, i_rok; logic [DOMW-1:0] i_dom; logic [AW-1:0] i_addr, i_pa; logic [15:0] i_bytes; logic [3:0] i_rfault;
  sf_memory_guard_grd_if #(.NM(NM), .ND(ND), .NR(NR), .NP(NP), .AW(AW), .DOMW(DOMW), .BEAT(BEAT), .LW(LW), .PBASE(0), .LOOKUP_ARCH(LOOKUP_ARCH), .DIAG_PRECISE(DIAG_PRECISE)) u_grd (
    .clk(clk), .rst_n(rst_n), .t_valid(dut.o_t_valid), .t_base(dut.o_t_base), .t_end(dut.o_t_end), .t_r(dut.o_t_r), .t_w(dut.o_t_w), .t_devn(dut.o_t_devn),
    .t_dev(dut.o_t_dev), .t_allow(dut.o_t_allow), .req_valid(g_valid), .req_ready(g_ready), .req_dom(g_dom), .req_priv(g_priv), .req_write(g_wr), .req_addr(g_addr),
    .rsp_valid(g_rvalid), .rsp_ok(g_rok), .rsp_fault(g_rfault), .busy_o());
  sf_memory_guard_iommu_if #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .DOMW(DOMW), .MAXB(4096), .BW(16), .PORT(2), .LOOKUP_ARCH(LOOKUP_ARCH), .DIAG_PRECISE(DIAG_PRECISE)) u_iommu (
    .clk(clk), .rst_n(rst_n), .t_valid(dut.o_t_valid), .t_base(dut.o_t_base), .t_end(dut.o_t_end), .t_r(dut.o_t_r), .t_w(dut.o_t_w), .t_devn(dut.o_t_devn),
    .t_dev(dut.o_t_dev), .t_allow(dut.o_t_allow), .guard_req_valid(i_valid), .guard_req_ready(i_ready), .guard_req_domain(i_dom), .guard_req_asid(4'd1),
    .guard_req_write(i_wr), .guard_req_addr(i_addr), .guard_req_bytes(i_bytes), .guard_req_id(i_id), .guard_rsp_valid(i_rvalid), .guard_rsp_ready(1'b1),
    .guard_rsp_id(i_rid), .guard_rsp_ok(i_rok), .guard_rsp_fault(i_rfault), .guard_rsp_pa(i_pa));

  function automatic int map_grd(input int f);
    begin case (f) FT_NONE: map_grd = 0; FT_PERM, FT_DEVICE: map_grd = 2; FT_BADDOM, FT_SPOOF: map_grd = 3; FT_BADOP: map_grd = 11; default: map_grd = 1; endcase end
  endfunction
  function automatic int map_iommu(input int f);
    begin case (f) FT_NONE: map_iommu = 0; FT_PERM, FT_DEVICE: map_iommu = 2; FT_SPAN, FT_OVERFLOW: map_iommu = 4; FT_ZEROLEN, FT_BADLEN, FT_BADOP: map_iommu = 7; default: map_iommu = 1; endcase end
  endfunction

  // expected verdicts, computed at the request edge from the oracle, compared one cycle later
  int  e_g_ok [NM], e_g_f [NM]; bit e_g_v [NM];             // expectation made at the request edge (stage 1) ...
  int  d_g_ok [NM], d_g_f [NM]; bit d_g_v [NM];             // ... compared one edge later, when the registered verdict is visible (stage 2)
  int  e_i_ok, e_i_f; bit e_i_v, e_i_id; longint unsigned e_i_addr;
  int  d_i_ok, d_i_f; bit d_i_v, d_i_id; longint unsigned d_i_addr;
  int  nq_g = 0, nq_i = 0, n_grant_g = 0, n_grant_i = 0, n_fault_cls [16];
  bit  run_en = 0;
  longint unsigned pick_edge_a;

  always @(posedge clk) begin
    // ---- check the verdicts of the previous cycle
    for (int m = 0; m < NM; m++) begin
      if (d_g_v[m]) begin
        checks++;
        if (!g_rvalid[m]) fail($sformatf("grd_if %0d: no verdict one cycle after the query", m));
        else if (int'(g_rok[m]) != d_g_ok[m] || int'(g_rfault[m*4 +: 4]) != d_g_f[m]) fail($sformatf("grd_if %0d: verdict %0d/%0d expected %0d/%0d", m, g_rok[m], g_rfault[m*4 +: 4], d_g_ok[m], d_g_f[m]));
      end else if (g_rvalid[m] && rst_n) fail($sformatf("grd_if %0d: verdict without a query", m));
    end
    if (d_i_v) begin
      checks++;
      if (!i_rvalid) fail("iommu_if: no response one cycle after the request");
      else begin
        if (int'(i_rok) != d_i_ok || int'(i_rfault) != d_i_f) fail($sformatf("iommu_if: response %0d/%0d expected %0d/%0d", i_rok, i_rfault, d_i_ok, d_i_f));
        if (i_rid !== d_i_id) fail("iommu_if: id not echoed");
        if (i_pa !== ((d_i_ok != 0) ? AW'(d_i_addr) : '0)) fail($sformatf("iommu_if: pa %0h (identity on a grant, 0 on a denial)", i_pa));
      end
    end else if (i_rvalid && rst_n) fail("iommu_if: response without a request");
    // ---- shift the expectations
    for (int m = 0; m < NM; m++) begin d_g_v[m] = e_g_v[m]; d_g_ok[m] = e_g_ok[m]; d_g_f[m] = e_g_f[m]; end
    d_i_v = e_i_v; d_i_ok = e_i_ok; d_i_f = e_i_f; d_i_id = e_i_id; d_i_addr = e_i_addr;
    // ---- issue new queries
    for (int m = 0; m < NM; m++) e_g_v[m] = 1'b0;
    e_i_v = 1'b0;
    if (rst_n && run_en) begin
      for (int m = 0; m < NM; m++) begin
        if ($urandom % 100 < 70) begin
          longint unsigned a; int d, w, f; int sel;
          a = $urandom % 65536; d = $urandom % 8; w = $urandom % 2;
          sel = $urandom % 100;
          if (sel < 55) begin   // near a region edge
            int dd = $urandom % ND; int i = $urandom % NR;
            if (rv[dd][i]) begin a = ((($urandom % 2) != 0) ? rb[dd][i] : re[dd][i]) + int'($urandom % 13) - 6; a = a & (SPACE - 1); d = (($urandom % 3) != 0) ? m : dd; end
          end else if (sel < 70) a = SPACE - 1 - ($urandom % 10);
          g_valid[m] <= 1'b1; g_wr[m] <= w[0]; g_addr[m*AW +: AW] <= AW'(a); g_dom[m*DOMW +: DOMW] <= DOMW'(d); g_priv[m] <= $urandom % 2;
          ref_maxlen = MAXLEN;
          f = ref_check(m, w, a, BEAT, d);
          e_g_v[m] = 1'b1; e_g_ok[m] = (f == FT_NONE); e_g_f[m] = map_grd(f); nq_g++; if (f == FT_NONE) n_grant_g++; n_fault_cls[f]++;
        end else g_valid[m] <= 1'b0;
      end
      if ($urandom % 100 < 70) begin
        longint unsigned a; int d, w, f, by; int sel;
        a = $urandom % 65536; d = $urandom % 8; w = $urandom % 2; by = 1 + ($urandom % 64);
        sel = $urandom % 100;
        if (sel < 55) begin
          int dd = $urandom % ND; int i = $urandom % NR;
          if (rv[dd][i]) begin a = ((($urandom % 2) != 0) ? rb[dd][i] : re[dd][i]) + int'($urandom % 13) - 6; a = a & (SPACE - 1); d = (($urandom % 3) != 0) ? 2 : dd; by = 1 + ($urandom % 24); end
        end else if (sel < 65) by = ($urandom % 2) ? 4096 + ($urandom % 3) : 0;
        else if (sel < 72) begin a = SPACE - 1 - ($urandom % 10); by = 1 + $urandom % 20; end
        begin bit idv; idv = $urandom % 2; i_valid <= 1'b1; i_wr <= w[0]; i_addr <= AW'(a); i_dom <= DOMW'(d); i_bytes <= 16'(by); i_id <= idv; e_i_id = idv; end
        ref_maxlen = 4096;
        f = ref_check(2, w, a, by, d);
        ref_maxlen = MAXLEN;
        e_i_v = 1'b1; e_i_ok = (f == FT_NONE); e_i_f = map_iommu(f); e_i_addr = a; nq_i++; if (f == FT_NONE) n_grant_i++;
      end else i_valid <= 1'b0;
    end else begin g_valid <= '0; i_valid <= 1'b0; end
  end

  initial begin : main
    wait (rst_n === 1'b0); repeat (3) @(posedge clk);
    do_reset();
    for (int k = 0; k < 16; k++) n_fault_cls[k] = 0;
    for (int m = 0; m < NM; m++) begin e_g_v[m] = 0; d_g_v[m] = 0; end
    e_i_v = 0; d_i_v = 0; i_valid = 0; g_valid = '0;
    $display("tb_mg_adapters: default deny after reset");
    run_en = 1; repeat (200) tick(); run_en = 0; repeat (4) tick();
    expect_eq("grants after reset", n_grant_g + n_grant_i, 0);
    for (int p = 0; p < NP; p++) bind_port(p, 1 << (p % ND));
    for (int d = 0; d < ND; d++) begin set_region(d, 0, 64'h1000 + 64'h1000 * d, 64'h0800, 1, 1); set_region(d, 1, 64'h8000 + 64'h400 * d, 64'h0200, 1, 0); end
    set_region(2, 2, 64'h7000, 64'h0400, 1, 1, 1'b1, 8'b0100);        // device-restricted (port 2 only)
    set_region(0, 2, SPACE - 64'h100, 64'h100, 1, 1);                 // the top of the address space
    $display("tb_mg_adapters: queries against the programmed table");
    for (int blk_ = 0; blk_ < 6; blk_++) begin
      run_en = 1; repeat (NQ / 6 / 2) tick(); run_en = 0; repeat (4) tick();
      // change the policy between blocks: the adapters follow the table (the inline drain protocol is separate, see the docs)
      if (blk_ == 1) bind_port(1, 16'b0011);
      if (blk_ == 2) clr_region(0, 0);
      if (blk_ == 3) set_region(1, 2, 64'h6000, 64'h0100, 1, 1);
      if (blk_ == 4) bind_port(0, 16'b1000);
    end
    $display("  grd_if: %0d queries (%0d grants), iommu_if: %0d requests (%0d grants)", nq_g, n_grant_g, nq_i, n_grant_i);
    checks++; if (n_grant_g < 100 || n_grant_i < 100) fail("coverage: too few grants");
    $display("tb_mg_adapters: %0d checks, %0d errors", checks, errors);
    if (errors == 0) $display("TB_RESULT: PASS tb_mg_adapters"); else $display("TB_RESULT: FAIL tb_mg_adapters errors=%0d", errors);
    $finish;
  end
  initial begin #500000000; $display("TB_RESULT: FAIL tb_mg_adapters TIMEOUT"); $finish; end
endmodule
