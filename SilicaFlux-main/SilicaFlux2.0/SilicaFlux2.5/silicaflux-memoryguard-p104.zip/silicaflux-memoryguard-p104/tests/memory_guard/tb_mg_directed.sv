// =============================================================================
// MemoryGuard directed verification.  Self-checking; every response is also judged by the independent oracle of tb_common.svh.
// Tests (the numbering is used by docs/memory_guard/07_VERIFICATION.md):
//   T01 reset state            T02 allowed reads / writes + byte exactness   T03 denied reads / writes, no side effect
//   T04 multiple domains       T05 address-boundary sweep                    T06 overflow, top of address space, bad lengths
//   T07 privilege violations   T08 configuration lock                        T09 mid-flight policy change (drain, block, timeout)
//   T10 reset during activity  T12 invalid descriptors / requests           T13 fault logging (fields, order, overflow, privilege)
//   T14 device permissions     T15 configuration corner cases                T17 orphan memory response
//   T19 memory error status    T20 unsupported / misaligned configuration accesses
// (T11 concurrent DMA and T16 back-pressure ordering are in tb_mg_random.sv)
// =============================================================================
`timescale 1ns/1ps
module tb_mg_directed #(
  parameter int ND = 4, parameter int NR = 4, parameter int NP = 4, parameter int AW = 16, parameter int DW = 64, parameter int IDW = 8,
  parameter int DOMW = 3, parameter int MAXOUT = 4, parameter int CHK_PIPE = 0, parameter int LOOKUP_ARCH = 0,
  parameter int DIAG_PRECISE = 1, parameter int STRICT = 0, parameter int LEN_POW2 = 0, parameter int FLOG_DEPTH = 8
);
`include "tb_common.svh"

  int          st, ce;
  bit [DW-1:0] rd;
  bit [31:0]   cd;
  bit          ce_err;

  function automatic bit len_legal(input int l);   // false for lengths the configuration refuses (LEN_POW2)
    begin len_legal = (LEN_POW2 == 0) || ((l & (l - 1)) == 0); end
  endfunction

  function automatic bit [DW-1:0] pat64(input int seed);
    bit [DW-1:0] v;
    begin for (int j = 0; j < BW; j++) v[8*j +: 8] = 8'(seed * 17 + j * 31 + 3); pat64 = v; end
  endfunction

  // one port <-> one domain, as the platform would bind them
  task automatic bind_default();
    begin for (int p = 0; p < NP; p++) bind_port(p, 1 << (p % ND)); end
  endtask

  // read the head fault record through the privileged bus
  typedef struct { bit valid; int fault; int port; int dom; int op; int tid; int len; int gen; int seq; longint unsigned addr; } flog_t;
  task automatic read_flog(output flog_t f);
    bit [31:0] w0, w1, w2, w3, w4, c; bit e;
    begin
      crd(R_FLOG_CNT, c, e);
      f.valid = (c[7:0] != 0);
      if (f.valid) begin
        crd(R_FLOG_W0, w0, e); crd(R_FLOG_W1, w1, e); crd(R_FLOG_W2, w2, e); crd(R_FLOG_W3, w3, e); crd(R_FLOG_SEQ, w4, e);
        f.tid = int'(w0[15:0]); f.len = int'(w0[31:16]); f.addr = {w2, w1}; f.fault = int'(w3[3:0]); f.op = int'(w3[5:4]);
        f.port = int'(w3[11:8]); f.dom = int'(w3[15:12]); f.gen = int'(w3[31:16]); f.seq = int'(w4);
      end
    end
  endtask
  task automatic pop_flog();
    bit e; begin cwr(R_FLOG_POP, 32'd1, e); end
  endtask

  // --------------------------------------------------------------------------------------------------------------
  initial begin : main
    int exp_st; longint unsigned a;
    flog_t f;
    bit [31:0] g0, g1;
    bit [DW-1:0] pw;
    longint unsigned base, size;
    wait (rst_n === 1'b0);
    repeat (3) @(posedge clk);
    do_reset();
    $display("tb_mg_directed: ND=%0d NR=%0d NP=%0d AW=%0d DW=%0d CHK_PIPE=%0d LOOKUP_ARCH=%0d STRICT=%0d LEN_POW2=%0d DIAG_PRECISE=%0d",
             ND, NR, NP, AW, DW, CHK_PIPE, LOOKUP_ARCH, STRICT, LEN_POW2, DIAG_PRECISE);

    // ============================================================ T01 reset state
    $display("T01 reset state");
    crd_t(R_ID, cd);
    expect_eq("R_ID magic", cd[31:16], 16'h4D47); expect_eq("R_ID ND", cd[15:12], ND); expect_eq("R_ID NR", cd[11:8], NR); expect_eq("R_ID NP", cd[7:4], NP);
    rchk("R_VERSION", R_VERSION, 32'h0001_0000);
    rchkm("R_STATE", R_STATE, 32'hF, 0);
    rchk("R_GEN", R_GEN, 0);
    rchk("R_STATUS", R_STATUS, 0);
    rchkm("R_FLOG_CNT.count", R_FLOG_CNT, 32'hFF, 0);
    for (int d = 0; d < ND; d++) for (int i = 0; i < NR; i++) begin
      cwr(R_SEL, {12'd0, 4'd0, 4'd0, 4'(i), 4'd0, 4'(d)}, ce_err);
      rchkb("reset: region valid", R_RD_ATTR, 31, 0);
    end
    for (int p = 0; p < NP; p++) begin
      cwr(R_SEL, {12'd0, 4'(p), 16'd0}, ce_err);
      rchk("reset: port binding", R_RD_ALLOW, 0);
    end
    mem_fill(8'hA5);
    for (int p = 0; p < NP; p++) begin
      for (int d = 0; d < ND + 2; d++) begin
        int e_st;
        e_st = (d >= ND) ? 5 : 3;
        xact_expect("T01 default deny (write)", p, 1, 64'h1000, 8, d, pat64(p), '1, e_st, rd);
        xact_expect("T01 default deny (read)",  p, 0, 64'h1000, 8, d, '0, '0, e_st, rd);
        expect_eq("T01 denied read carries no data", rd, 0);
      end
    end
    for (int i = 0; i < MEMSZ; i++) if (mem[i] !== 8'hA5) begin fail("T01: memory modified by a request after reset"); break; end
    expect_eq("T01 no memory-side transaction", n_mem[0] + n_mem[1] + n_mem[2] + n_mem[3], 0);

    // ============================================================ T02 allowed reads and writes
    $display("T02 allowed reads / writes");
    bind_default();
    set_region(0, 0, 64'h1000, 64'h1000, 1, 1);                 // dom0: RW  [0x1000, 0x2000)
    set_region(0, 1, 64'h3000, 64'h0800, 1, 0);                 // dom0: R   [0x3000, 0x3800)
    set_region(1, 0, 64'h2000, 64'h1000, 1, 1);                 // dom1: RW  [0x2000, 0x3000)
    set_region(1, 1, 64'h8000, 64'h4000, 0, 1);                 // dom1: W   [0x8000, 0xC000)
    set_region(2, 0, 64'h4000, 64'h0100, 1, 1);                 // dom2: RW
    set_region(3, 0, 64'h5000, 64'h2000, 1, 1);                 // dom3: RW
    mem_fill(8'hA5);
    for (int p = 0; p < NP; p++) begin
      longint unsigned pb;
      pb = (p == 0) ? 64'h1000 : (p == 1) ? 64'h2000 : (p == 2) ? 64'h4000 : 64'h5000;
      for (int len = 1; len <= BW; len++) for (int off = 0; off < 8; off++) if (len_legal(len)) begin
        bit [DW-1:0] wd; bit [BW-1:0] be;
        wd = pat64(p * 64 + len * 8 + off); be = '1;
        xact_expect("T02 write", p, 1, pb + 16 + off, len, p % ND, wd, be, 0, rd);
        xact_expect("T02 read back", p, 0, pb + 16 + off, len, p % ND, '0, '0, 0, rd);
        for (int j = 0; j < BW; j++) begin
          if (j < len) begin checks++; if (rd[8*j +: 8] !== wd[8*j +: 8]) fail($sformatf("T02 port %0d len %0d off %0d: lane %0d is %0h, expected %0h", p, len, off, j, rd[8*j +: 8], wd[8*j +: 8])); end
          else         begin checks++; if (rd[8*j +: 8] !== 8'h00) fail("T02: read lane beyond len is not zero"); end
        end
        // the bytes around the transfer are untouched; the transfer itself landed
        expect_eq("T02 byte before the transfer", mem[pb + 16 + off - 1], 8'hA5);
        expect_eq("T02 byte after the transfer",  mem[pb + 16 + off + len], 8'hA5);
        for (int j = 0; j < len; j++) begin expect_eq("T02 byte landed", mem[pb + 16 + off + j], wd[8*j +: 8]); mem[pb + 16 + off + j] = 8'hA5; end
      end
    end
    // partial byte enables: only enabled lanes are written
    mem_fill(8'hA5);
    pw = pat64(9);
    xact_expect("T02 partial be write", 0, 1, 64'h1100, BW, 0, pw, {(BW/2){2'b01}}, 0, rd);
    for (int j = 0; j < BW; j++) expect_eq("T02 partial be lane", mem[64'h1100 + j], ((j % 2) == 0) ? pw[8*j +: 8] : 8'hA5);
    // be set beyond len is clipped by the guard: only [addr, addr+len) can change
    mem_fill(8'hA5);
    pw = pat64(5);
    xact_expect("T02 len 3 (2 if pow2) with be=all", 0, 1, 64'h1200, (LEN_POW2 != 0) ? 2 : 3, 0, pw, '1, 0, rd);
    for (int j = 0; j < BW; j++) expect_eq("T02 clip lane", mem[64'h1200 + j], (j < ((LEN_POW2 != 0) ? 2 : 3)) ? pw[8*j +: 8] : 8'hA5);
    // the dom0 read-only region reads, does not write
    xact_expect("T02 read RO region", 0, 0, 64'h3000, 8, 0, '0, '0, 0, rd);
    // write-only region: write ok, read denied
    xact_expect("T02 write WO region", 1, 1, 64'h8000, 8, 1, pat64(1), '1, 0, rd);
    xact_expect("T02 read WO region denied", 1, 0, 64'h8000, 8, 1, '0, '0, 3, rd);

    // ============================================================ T03 denied reads / writes: no side effect
    $display("T03 denied reads / writes");
    mem_fill(8'hA5);
    begin
      longint unsigned nm0 = n_mem[0] + n_mem[1] + n_mem[2] + n_mem[3];
      xact_expect("T03 write RO region", 0, 1, 64'h3000, 8, 0, pat64(3), '1, 3, rd);
      xact_expect("T03 write outside any region", 0, 1, 64'h0000, 8, 0, pat64(3), '1, 3, rd);
      xact_expect("T03 write other domain's region", 0, 1, 64'h2000, 8, 0, pat64(3), '1, 3, rd);
      xact_expect("T03 read other domain's region", 0, 0, 64'h4000, 8, 0, '0, '0, 3, rd);
      expect_eq("T03 denied read data", rd, 0);
      xact_expect("T03 write region end", 0, 1, 64'h1FFC, 8, 0, pat64(3), '1, 3, rd);   // starts inside, ends 4 bytes past the end
      xact_expect("T03 write region start", 0, 1, 64'h0FFC, 8, 0, pat64(3), '1, 3, rd); // starts 4 bytes before, ends inside
      for (int i = 0; i < MEMSZ; i++) if (mem[i] !== 8'hA5) begin fail($sformatf("T03: memory byte 0x%0h modified by a denied write", i)); break; end
      expect_eq("T03 no memory-side transaction for denied requests", n_mem[0] + n_mem[1] + n_mem[2] + n_mem[3], nm0);
    end

    // ============================================================ T04 multiple domains, bindings
    $display("T04 multiple domains / trusted binding");
    mem_fill(8'hA5);
    xact_expect("T04 spoofed domain claim (port 0 claims dom 1)", 0, 1, 64'h2000, 8, 1, pat64(4), '1, 3, rd);
    xact_expect("T04 spoofed domain claim (port 1 claims dom 0)", 1, 0, 64'h1000, 8, 0, '0, '0, 3, rd);
    for (int i = 0; i < MEMSZ; i++) if (mem[i] !== 8'hA5) begin fail("T04: memory modified through a spoofed domain claim"); break; end
    bind_port(0, 16'b0011);                                      // port 0 may now act for domains 0 and 1
    xact_expect("T04 port 0 now acts for dom 1", 0, 1, 64'h2000, 8, 1, pat64(4), '1, 0, rd);
    xact_expect("T04 port 0 still cannot act for dom 2", 0, 1, 64'h4000, 8, 2, pat64(4), '1, 3, rd);
    bind_port(0, 16'b0001);                                      // revoke again
    xact_expect("T04 revoked binding", 0, 1, 64'h2000, 8, 1, pat64(4), '1, 3, rd);
    // shared region across domains (non-strict) or rejected (strict)
    begin
      int ce2;
      do_cmd(CMD_SET_REGION, 1, 2, 0, 64'h1800, 64'h0100, 1, 0, 0, 0, 0, ce2);        // overlaps dom0 region 0 [0x1000,0x2000)
      if (STRICT != 0) expect_eq("T04 strict: cross-domain overlap refused", ce2, CE_OVERLAP);
      else             expect_eq("T04 non-strict: cross-domain overlap accepted", ce2, CE_OK);
      if (STRICT == 0) clr_region(1, 2);
    end
    // a port with no binding is dead
    bind_port(3, 0);
    xact_expect("T04 unbound port denied", 3, 0, 64'h5000, 8, 3, '0, '0, 3, rd);
    bind_port(3, 16'b1000);
    xact_expect("T04 rebound port works", 3, 0, 64'h5000, 8, 3, '0, '0, 0, rd);

    // ============================================================ T05 address-boundary sweep
    $display("T05 boundary sweep");
    mem_fill(8'hA5);
    for (int reg_i = 0; reg_i < 2; reg_i++) begin
      longint unsigned B, E;
      B = (reg_i == 0) ? 64'h1000 : 64'h3000; E = (reg_i == 0) ? 64'h2000 : 64'h3800;
      for (int len = 1; len <= BW; len++) if (len_legal(len)) begin
        for (int s = 0; s < 2; s++) begin
          longint unsigned c0 = (s == 0) ? B : E;
          for (int dlt = -(BW + 1); dlt <= (BW + 1); dlt++) begin
            a = c0 + longint'(dlt);
            exp_st = (a >= B && a + len <= E) ? 0 : 3;
            xact_expect("T05 read", 0, 0, a, len, 0, '0, '0, exp_st, rd);
          end
        end
      end
    end
    // writes around the edge of the RW region: the memory image shows exactly the permitted bytes
    mem_fill(8'hA5);
    for (int len = 1; len <= BW; len++) for (int dlt = -(BW); dlt <= BW; dlt++) if (len_legal(len)) begin
      a = 64'h2000 + longint'(dlt);                               // the upper edge of dom0 region 0
      xact(0, 1, a, len, 0, pat64(len), '1, st, rd);
    end
    for (longint unsigned x = 64'h0F00; x < 64'h2100; x++) begin
      if (x >= 64'h2000 || x < 64'h1000) begin
        if (mem[x] !== 8'hA5) begin fail($sformatf("T05: byte 0x%0h outside the region was written", x)); break; end
      end
    end
    // adjacent regions of one domain: a transfer spanning both is denied (single-region containment)
    set_region(2, 1, 64'h4100, 64'h0100, 1, 1);                   // adjacent to dom2 region 0 [0x4000,0x4100)
    xact_expect("T05 span across adjacent regions of one domain", 2, 0, 64'h40FC, 8, 2, '0, '0, 3, rd);
    xact_expect("T05 wholly in the first", 2, 0, 64'h40F8, 8, 2, '0, '0, 0, rd);
    xact_expect("T05 wholly in the second", 2, 0, 64'h4100, 8, 2, '0, '0, 0, rd);
    clr_region(2, 1);

    // ============================================================ T06 overflow, top of space, lengths
    $display("T06 overflow / length");
    do_cmd(CMD_SET_REGION, 0, 2, 0, SPACE - 64'h100, 64'h100, 1, 1, 0, 0, 0, ce);
    expect_eq("T06 region ending exactly at 2**AW accepted", ce, CE_OK);
    xact_expect("T06 last 8 bytes of the address space", 0, 1, SPACE - 8, 8, 0, pat64(6), '1, 0, rd);
    xact_expect("T06 last byte", 0, 1, SPACE - 1, 1, 0, pat64(6), '1, 0, rd);
    xact_expect("T06 wraps past 2**AW (len 8 at -4)", 0, 1, SPACE - 4, 8, 0, pat64(6), '1, 5, rd);
    xact_expect("T06 wraps past 2**AW (len 2 at -1)", 0, 0, SPACE - 1, 2, 0, '0, '0, 5, rd);
    xact_expect("T06 start inside, end exactly at 2**AW", 0, 0, SPACE - ((LEN_POW2 != 0) ? 4 : 5), (LEN_POW2 != 0) ? 4 : 5, 0, '0, '0, 0, rd);
    xact_expect("T06 low alias of a wrapping transfer is not authorised", 0, 0, 0, 4, 0, '0, '0, 3, rd);
    do_cmd(CMD_SET_REGION, 0, 3, 0, SPACE - 64'h80, 64'h100, 1, 1, 0, 0, 0, ce);   expect_eq("T06 base + size wraps", ce, CE_RANGE);
    do_cmd(CMD_SET_REGION, 0, 3, 0, 64'h6000, 64'h0, 1, 1, 0, 0, 0, ce);            expect_eq("T06 zero-size region", ce, CE_RANGE);
    do_cmd(CMD_SET_REGION, 0, 3, 0, SPACE, 64'h1, 1, 1, 0, 0, 0, ce);               expect_eq("T06 base = 2**AW", ce, CE_RANGE);
    do_cmd(CMD_SET_REGION, 0, 3, 0, 64'h1_0000_0000_0000, 64'h10, 1, 1, 0, 0, 0, ce);  expect_eq("T06 base far outside the space", ce, CE_RANGE);
    do_cmd(CMD_SET_REGION, 0, 3, 0, 64'hFFFF_FFFF_FFFF_FFF0, 64'h20, 1, 1, 0, 0, 0, ce); expect_eq("T06 64-bit wrap in base + size", ce, CE_RANGE);
    do_cmd(CMD_SET_REGION, 0, 3, 0, 64'h0, SPACE + 1, 1, 1, 0, 0, 0, ce);           expect_eq("T06 size > 2**AW", ce, CE_RANGE);
    clr_region(0, 2);
    // lengths
    xact_expect("T06 zero length", 0, 0, 64'h1000, 0, 0, '0, '0, 5, rd);
    xact_expect("T06 zero length write", 0, 1, 64'h1000, 0, 0, pat64(1), '1, 5, rd);
    xact_expect("T06 len MAXLEN+1", 0, 0, 64'h1000, BW + 1, 0, '0, '0, 5, rd);
    xact_expect("T06 len max encodable", 0, 0, 64'h1000, (1 << LW) - 1, 0, '0, '0, 5, rd);
    if (LEN_POW2 != 0) begin
      xact_expect("T06 pow2: len 3 refused", 0, 0, 64'h1000, 3, 0, '0, '0, 5, rd);
      xact_expect("T06 pow2: len 4 ok", 0, 0, 64'h1000, 4, 0, '0, '0, 0, rd);
    end

    // ============================================================ T07 privilege violations
    $display("T07 privilege violations");
    begin
      bit [31:0] rdv; bit err; int cs0; bit [31:0] sz0;
      cnt_get(CN_SEC, cs0);
      crd_t(R_SIZE_LO, sz0);
      crd_t(R_GEN, g0);
      // an unprivileged agent stages and commits a region for itself, reads registers, tries to lock / clear
      cfg_acc(1'b1, R_SEL,     32'h0000_0000, 1'b0, 4'hF, rdv, err); expect_eq("T07 unpriv write -> error", err, 1);
      cfg_acc(1'b1, R_BASE_LO, 32'h0000_0000, 1'b0, 4'hF, rdv, err); expect_eq("T07 unpriv write -> error", err, 1);
      cfg_acc(1'b1, R_SIZE_LO, 32'h0001_0000, 1'b0, 4'hF, rdv, err); expect_eq("T07 unpriv write -> error", err, 1);
      cfg_acc(1'b1, R_ATTR,    32'h0000_0003, 1'b0, 4'hF, rdv, err); expect_eq("T07 unpriv write -> error", err, 1);
      cfg_acc(1'b1, R_CMD,     32'(CMD_SET_REGION), 1'b0, 4'hF, rdv, err); expect_eq("T07 unpriv command -> error", err, 1);
      cfg_acc(1'b1, R_CMD,     32'(CMD_CLEAR_ALL), 1'b0, 4'hF, rdv, err); expect_eq("T07 unpriv clear-all -> error", err, 1);
      cfg_acc(1'b1, R_CTRL,    32'h8000_0000, 1'b0, 4'hF, rdv, err); expect_eq("T07 unpriv lock -> error", err, 1);
      cfg_acc(1'b1, R_DRAIN_TMO, 32'd5, 1'b0, 4'hF, rdv, err); expect_eq("T07 unpriv write -> error", err, 1);
      cfg_acc(1'b1, R_FLOG_POP, 32'd1, 1'b0, 4'hF, rdv, err); expect_eq("T07 unpriv pop -> error", err, 1);
      cfg_acc(1'b1, R_STATUS, 32'hFFFF_FFFF, 1'b0, 4'hF, rdv, err); expect_eq("T07 unpriv status clear -> error", err, 1);
      cfg_acc(1'b0, R_ID, 32'h0, 1'b0, 4'hF, rdv, err);       expect_eq("T07 unpriv read -> error", err, 1); expect_eq("T07 unpriv read returns zero", rdv, 0);
      cfg_acc(1'b0, R_FLOG_W1, 32'h0, 1'b0, 4'hF, rdv, err);  expect_eq("T07 unpriv fault-log read returns zero", rdv, 0);
      cfg_acc(1'b0, R_CNT_DATA, 32'h0, 1'b0, 4'hF, rdv, err); expect_eq("T07 unpriv counter read returns zero", rdv, 0);
      cfg_acc(1'b0, R_RD_BASE_LO, 32'h0, 1'b0, 4'hF, rdv, err); expect_eq("T07 unpriv table read returns zero", rdv, 0);
      rchk("T07 table unchanged: generation", R_GEN, g0);
      rchkb("T07 STATUS.SEC set", R_STATUS, STAT_SEC, 1);
      begin bit [31:0] cs1; cnt_get(CN_SEC, cs1); expect_eq("T07 CN_SEC counted every violation", cs1 - cs0, 14); end
      cwr(R_STATUS, 32'(1 << STAT_SEC), ce_err);
      rchkb("T07 STATUS.SEC cleared by W1C", R_STATUS, STAT_SEC, 0);
      // staging registers unchanged
      rchk("T07 R_SIZE_LO unchanged", R_SIZE_LO, sz0);
      xact_expect("T07 region the unprivileged agent tried to create does not exist", 1, 1, 64'h0000, 8, 1, pat64(7), '1, 3, rd);
    end

    // ============================================================ T15 configuration corner cases
    $display("T15 configuration corner cases");
    begin
      int ce2; bit [31:0] rdv; bit err;
      do_cmd(CMD_SET_REGION, 3, 1, 0, 64'h5800, 64'h0100, 1, 1, 0, 0, 0, ce2);  expect_eq("T15 overlap inside one domain", ce2, CE_OVERLAP);
      do_cmd(CMD_SET_REGION, 3, 1, 0, 64'h7000, 64'h0100, 1, 1, 0, 0, 0, ce2);  expect_eq("T15 adjacent region accepted", ce2, CE_OK);
      do_cmd(CMD_SET_REGION, 3, 1, 0, 64'h7000, 64'h0800, 1, 1, 0, 0, 0, ce2);  expect_eq("T15 re-install over itself accepted", ce2, CE_OK);
      do_cmd(CMD_SET_REGION, 3, 2, 0, 64'h6FFF, 64'h0002, 1, 1, 0, 0, 0, ce2);  expect_eq("T15 one-byte overlap at the end of another", ce2, CE_OVERLAP);
      do_cmd(CMD_SET_REGION, 3, 2, 0, 64'h4FFF, 64'h0001, 1, 1, 0, 0, 0, ce2);  expect_eq("T15 touching (end == base) is not an overlap", ce2, CE_OK);
      do_cmd(CMD_SET_REGION, 3, 3, 0, 64'h4FFE, 64'h0004, 1, 1, 0, 0, 0, ce2);  expect_eq("T15 straddling two regions", ce2, CE_OVERLAP);
      clr_region(3, 2); clr_region(3, 1);
      do_cmd(CMD_SET_REGION, ND, 0, 0, 64'h100, 64'h10, 1, 1, 0, 0, 0, ce2);    expect_eq("T15 bad domain index", ce2, CE_INDEX);
      do_cmd(CMD_SET_REGION, 0, NR, 0, 64'h100, 64'h10, 1, 1, 0, 0, 0, ce2);    expect_eq("T15 bad region index", ce2, CE_INDEX);
      do_cmd(CMD_CLR_REGION, ND, 0, 0, 0, 0, 0, 0, 0, 0, 0, ce2);               expect_eq("T15 clear bad domain", ce2, CE_INDEX);
      do_cmd(CMD_BIND_PORT, 0, 0, NP, 0, 0, 0, 0, 0, 0, 1, ce2);                expect_eq("T15 bad port index", ce2, CE_INDEX);
      do_cmd(CMD_BIND_PORT, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 << ND, ce2);           expect_eq("T15 reserved allow bits", ce2, CE_INDEX);
      if (NP < 8) begin do_cmd(CMD_SET_REGION, 0, 3, 0, 64'h6000, 64'h10, 1, 1, 1, 1 << NP, 0, ce2); expect_eq("T15 reserved device-mask bits", ce2, CE_INDEX); end
      do_cmd(15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ce2);                            expect_eq("T15 unknown command", ce2, CE_CMD);
      do_cmd(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ce2);                             expect_eq("T15 command 0", ce2, CE_CMD);
      // a refused command left the table alone and did not block the datapath
      xact_expect("T15 traffic unaffected by refused commands", 3, 0, 64'h5000, 8, 3, '0, '0, 0, rd);
      // bus-level errors
      cfg_acc(1'b1, R_SEL, 32'h0, 1'b1, 4'h3, rdv, err);     expect_eq("T15 partial-strobe write refused", err, 1);
      cfg_acc(1'b1, R_ID, 32'h0, 1'b1, 4'hF, rdv, err);      expect_eq("T15 write to a read-only register refused", err, 1);
      cfg_acc(1'b1, R_RD_BASE_LO, 32'h0, 1'b1, 4'hF, rdv, err); expect_eq("T15 write to a read-only register refused", err, 1);
      cfg_acc(1'b0, 5'd3, 32'h0, 1'b1, 4'hF, rdv, err);      expect_eq("T15 read ok", err, 0);
      begin
        bit [31:0] d; bit e;
        // unaligned and out-of-map byte addresses
        cfg_acc_b(1'b0, 8'h05, 32'd0, 1'b1, 4'hF, d, e);   expect_eq("T15 unaligned address -> error", e, 1);
        cfg_acc_b(1'b0, 8'h80, 32'd0, 1'b1, 4'hF, d, e);   expect_eq("T15 out-of-map address -> error", e, 1);
        cfg_acc_b(1'b1, 8'h84, 32'd1, 1'b1, 4'hF, d, e);   expect_eq("T15 out-of-map write -> error", e, 1);
        rchkb("T15 STATUS.BADADDR", R_STATUS, STAT_BADADDR, 1);
        cwr(R_STATUS, 32'h1FFF, e);
      end
      // clear-all removes every region but keeps the bindings
      do_cmd(CMD_CLEAR_ALL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ce2);
      xact_expect("T15 after CLEAR_ALL", 0, 0, 64'h1000, 8, 0, '0, '0, 3, rd);
      cwr(R_SEL, {12'd0, 4'd0, 16'd0}, err); rchk("T15 binding survives CLEAR_ALL", R_RD_ALLOW, 1);
      // restore the policy of T02 for the remaining tests
      set_region(0, 0, 64'h1000, 64'h1000, 1, 1);
      set_region(0, 1, 64'h3000, 64'h0800, 1, 0);
      set_region(1, 0, 64'h2000, 64'h1000, 1, 1);
      set_region(1, 1, 64'h8000, 64'h4000, 0, 1);
      set_region(2, 0, 64'h4000, 64'h0100, 1, 1);
      set_region(3, 0, 64'h5000, 64'h2000, 1, 1);
      // table readback of an installed entry
      cwr(R_SEL, {12'd0, 4'd0, 4'd0, 4'd1, 4'd0, 4'd1}, err);
      rchk("T15 readback base", R_RD_BASE_LO, 32'h8000);
      rchk("T15 readback end", R_RD_END_LO, 32'hC000);
      crd_t(R_RD_ATTR, cd); expect_eq("T15 readback valid", cd[31], 1); expect_eq("T15 readback R", cd[0], 0); expect_eq("T15 readback W", cd[1], 1);
    end

    // ============================================================ T12 invalid descriptors / requests
    $display("T12 invalid requests");
    mem_fill(8'hA5);
    begin
      longint unsigned nm0 = n_mem[0] + n_mem[1] + n_mem[2] + n_mem[3];
      for (int p = 0; p < NP; p++) begin
        longint unsigned pb = (p == 0) ? 64'h1000 : (p == 1) ? 64'h2000 : (p == 2) ? 64'h4000 : 64'h5000;
        for (int op = 2; op <= 3; op++) xact_expect("T12 unsupported op", p, op, pb, 8, p % ND, pat64(1), '1, 5, rd);
        xact_expect("T12 zero length", p, 1, pb, 0, p % ND, pat64(1), '1, 5, rd);
        for (int l = BW + 1; l < (1 << LW); l++) xact_expect("T12 oversize", p, 1, pb, l, p % ND, pat64(1), '1, 5, rd);
        for (int d = ND; d < (1 << DOMW); d++) xact_expect("T12 invalid domain", p, 1, pb, 8, d, pat64(1), '1, 5, rd);
        for (int d = 0; d < ND; d++) if (d != p % ND) xact_expect("T12 foreign domain claim", p, 1, pb, 8, d, pat64(1), '1, 3, rd);
      end
      for (int i = 0; i < MEMSZ; i++) if (mem[i] !== 8'hA5) begin fail("T12: memory modified by an invalid request"); break; end
      expect_eq("T12 no memory-side transaction", n_mem[0] + n_mem[1] + n_mem[2] + n_mem[3], nm0);
    end

    // ============================================================ T13 fault logging
    $display("T13 fault logging");
    begin
      bit e; int tid_x; flog_t f2;
      do_reset();
      bind_default();
      set_region(0, 0, 64'h1000, 64'h1000, 1, 0);          // dom0: read only
      cwr(R_STATUS, 32'h1FFF, e);
      rchkm("T13 log empty", R_FLOG_CNT, 32'hFF, 0);
      crd_t(R_GEN, g0);
      // one denial of each class, ids known (xact assigns id_ctr+1)
      tid_x = int'(id_ctr) + 1;
      xact_expect("T13 PERM", 0, 1, 64'h1010, 4, 0, pat64(1), '1, 3, rd);
      read_flog(f);
      expect_eq("T13 fault", f.fault, FT_PERM); expect_eq("T13 port", f.port, 0); expect_eq("T13 dom", f.dom, 0); expect_eq("T13 op", f.op, 1);
      expect_eq("T13 tid", f.tid, tid_x); expect_eq("T13 addr", f.addr, 64'h1010); expect_eq("T13 len", f.len, 4); expect_eq("T13 gen", f.gen, g0); expect_eq("T13 seq", f.seq, 0);
      pop_flog();
      rchkm("T13 log empty after pop", R_FLOG_CNT, 32'hFF, 0);
      tid_x = int'(id_ctr) + 1;
      xact_expect("T13 NOMAP (port 1)", 1, 0, 64'h0200, 2, 1, '0, '0, 3, rd);
      read_flog(f);
      expect_eq("T13 fault", f.fault, FT_NOMAP); expect_eq("T13 port", f.port, 1); expect_eq("T13 dom", f.dom, 1); expect_eq("T13 op", f.op, 0);
      expect_eq("T13 tid", f.tid, tid_x); expect_eq("T13 addr", f.addr, 64'h0200); expect_eq("T13 seq", f.seq, 1);
      pop_flog();
      xact_expect("T13 SPAN", 0, 0, 64'h1FFE, 8, 0, '0, '0, 3, rd);
      read_flog(f); expect_eq("T13 fault SPAN/NOMAP", f.fault, (DIAG_PRECISE != 0) ? FT_SPAN : FT_NOMAP); pop_flog();
      xact_expect("T13 SPOOF", 2, 0, 64'h1000, 8, 0, '0, '0, 3, rd);
      read_flog(f); expect_eq("T13 fault SPOOF", f.fault, FT_SPOOF); expect_eq("T13 port", f.port, 2); expect_eq("T13 dom claimed", f.dom, 0); pop_flog();
      xact_expect("T13 BADDOM", 3, 0, 64'h1000, 8, 7, '0, '0, 5, rd);
      read_flog(f); expect_eq("T13 fault BADDOM", f.fault, FT_BADDOM); expect_eq("T13 dom claimed", f.dom, 7); pop_flog();
      xact_expect("T13 ZEROLEN", 0, 0, 64'h1000, 0, 0, '0, '0, 5, rd);
      read_flog(f); expect_eq("T13 fault ZEROLEN", f.fault, FT_ZEROLEN); pop_flog();
      xact_expect("T13 BADLEN", 0, 0, 64'h1000, BW + 1, 0, '0, '0, 5, rd);
      read_flog(f); expect_eq("T13 fault BADLEN", f.fault, FT_BADLEN); pop_flog();
      xact_expect("T13 BADOP", 0, 2, 64'h1000, 4, 0, '0, '0, 5, rd);
      read_flog(f); expect_eq("T13 fault BADOP", f.fault, FT_BADOP); expect_eq("T13 op", f.op, 2); pop_flog();
      xact_expect("T13 OVERFLOW", 0, 0, SPACE - 2, 4, 0, '0, '0, 5, rd);
      read_flog(f); expect_eq("T13 fault OVERFLOW", f.fault, FT_OVERFLOW); expect_eq("T13 addr", f.addr, SPACE - 2); pop_flog();
      // counters
      cnt_chk("T13 CN_FAULTS", CN_FAULTS, 9);
      cnt_chk("T13 per-port faults, port 0", cn_pflt(NP, 0), 6);
      cnt_chk("T13 per-type PERM", cn_ft(NP, FT_PERM), 1);
      cnt_chk("T13 per-type NOMAP (the SPAN case is NOMAP when DIAG_PRECISE = 0)", cn_ft(NP, FT_NOMAP), (DIAG_PRECISE != 0) ? 1 : 2);
      rchkb("T13 STATUS.FAULT", R_STATUS, STAT_FAULT, 1);
      // overflow of the log: drop-newest, counted
      cwr(R_STATUS, 32'h1FFF, e);
      for (int k = 0; k < FLOG_DEPTH + 3; k++) xact_expect("T13 fill", 0, 1, 64'h1000 + 8 * k, 8, 0, pat64(k), '1, 3, rd);
      crd_t(R_FLOG_CNT, cd); expect_eq("T13 log full", cd[7:0], FLOG_DEPTH); expect_eq("T13 dropped", cd[31:16], 3); expect_eq("T13 depth reported", cd[15:8], FLOG_DEPTH);
      rchkb("T13 STATUS.FDROP", R_STATUS, STAT_FDROP, 1);
      cnt_chk("T13 CN_FDROP", CN_FDROP, 3);
      read_flog(f); expect_eq("T13 oldest kept: addr", f.addr, 64'h1000); expect_eq("T13 oldest kept: seq", f.seq, 9);
      for (int k = 0; k < FLOG_DEPTH; k++) begin read_flog(f2); expect_eq("T13 fifo order", f2.addr, 64'h1000 + 8 * k); expect_eq("T13 seq contiguous", f2.seq, 9 + k); pop_flog(); end
      rchkm("T13 log empty again", R_FLOG_CNT, 32'hFF, 0);
      // privileged only: an unprivileged read of a full log shows nothing
      xact_expect("T13 one more", 0, 1, 64'h1000, 8, 0, pat64(1), '1, 3, rd);
      begin bit [31:0] rdv; bit err2;
        cfg_acc(1'b0, R_FLOG_W1, 32'h0, 1'b0, 4'hF, rdv, err2); expect_eq("T13 unprivileged fault-log read: zero", rdv, 0); expect_eq("T13 unprivileged fault-log read: error", err2, 1);
        cfg_acc(1'b0, R_FLOG_CNT, 32'h0, 1'b0, 4'hF, rdv, err2); expect_eq("T13 unprivileged fault-log count: zero", rdv, 0);
      end
      pop_flog();
      // simultaneous denials on all ports are all logged (arbitrated), each exactly once
      cwr(R_STATUS, 32'h1FFF, e);
      begin
        bit [31:0] c0; bit [31:0] cdd0;
        cnt_get(CN_FAULTS, c0);
        crd_t(R_FLOG_CNT, cdd0);
        fork
          begin for (int k = 0; k < 4; k++) begin int s_; bit [DW-1:0] r_; xact(0, 1, 64'h1000, 8, 0, pat64(k), '1, s_, r_); end end
          begin for (int k = 0; k < 4; k++) begin int s_; bit [DW-1:0] r_; xact(1 % NP, 1, 64'h0000, 8, 1 % ND, pat64(k), '1, s_, r_); end end
          begin for (int k = 0; k < 4; k++) begin int s_; bit [DW-1:0] r_; xact(2 % NP, 0, 64'h0000, 8, 2 % ND, '0, '0, s_, r_); end end
          begin for (int k = 0; k < 4; k++) begin int s_; bit [DW-1:0] r_; xact(3 % NP, 0, 64'h0000, 0, 3 % ND, '0, '0, s_, r_); end end
        join
        begin bit [31:0] cf1; cnt_get(CN_FAULTS, cf1); expect_eq("T13 concurrent denials all counted", cf1 - c0, 16); end
        crd_t(R_FLOG_CNT, cd); expect_eq("T13 concurrent denials: held + dropped", cd[7:0] + (cd[31:16] - cdd0[31:16]), 16);
      end
      cwr(R_STATUS, 32'h1FFF, e);
      for (int k = 0; k < FLOG_DEPTH; k++) pop_flog();
      // restore for the following tests
      set_region(0, 0, 64'h1000, 64'h1000, 1, 1);
      set_region(1, 0, 64'h2000, 64'h1000, 1, 1);
      set_region(2, 0, 64'h4000, 64'h0100, 1, 1);
      set_region(3, 0, 64'h5000, 64'h2000, 1, 1);
    end

    // ============================================================ T14 device permissions
    $display("T14 device permissions");
    begin
      bind_port(0, 16'b0100); bind_port(1, 16'b0100); bind_port(2, 16'b0100); bind_port(3, 16'b0100);   // four ports, one domain (2)
      set_region(2, 1, 64'hD000, 64'h0100, 1, 1, 1'b1, 8'b1010);                                       // device mask: ports 1 and 3 only
      for (int p = 0; p < NP; p++) begin
        exp_st = (p == 1 || p == 3) ? 0 : 3;
        xact_expect("T14 device-masked region", p, 0, 64'hD000, 8, 2, '0, '0, exp_st, rd);
        xact_expect("T14 region without device mask is open to every port of the domain", p, 0, 64'h4000, 8, 2, '0, '0, 0, rd);
      end
      read_flog(f); expect_eq("T14 fault DEVICE", f.fault, FT_DEVICE); pop_flog(); pop_flog();
      bind_default();
      clr_region(2, 1);
    end

    // ============================================================ T17 orphan memory response
    $display("T17 orphan response");
    begin
      bit e; bit [31:0] o0;
      cwr(R_STATUS, 32'h1FFF, e);
      cnt_get(CN_ORPHAN, o0);
      orph_req[1] = 1'b1;
      repeat (6) @(posedge clk);
      begin bit [31:0] co1; cnt_get(CN_ORPHAN, co1); expect_eq("T17 orphan counted", co1 - o0, 1); end
      rchkb("T17 STATUS.ORPHAN", R_STATUS, STAT_ORPHAN, 1);
      expect_eq("T17 not forwarded to the requester (responses seen)", n_rsp[1], n_acc[1]);
    end

    // ============================================================ T19 memory error is reported, not hidden
    $display("T19 memory error");
    begin
      err_addr = 64'h5010;
      xact_expect("T19 permitted write answered with SLVERR", 3, 1, 64'h5010, 8, 3, pat64(2), '1, 1, rd);
      xact_expect("T19 permitted read answered with SLVERR", 3, 0, 64'h5010, 8, 3, '0, '0, 1, rd);
      xact_expect("T19 a denied request keeps its denial", 3, 0, 64'h0010, 8, 3, '0, '0, 3, rd);
      err_addr = 64'hFFFF_FFFF_FFFF_FFFF;
    end

    // ============================================================ T09 mid-flight policy change
    $display("T09 mid-flight policy changes");
    begin
      bit e; int ce2; bit [31:0] dd; longint unsigned t0, t_commit; int blocked_cycles, gotc;
      // ---- (a) revoke a region while four writes are outstanding with a slow memory: the commit waits, ingress is blocked,
      //          the old requests complete under the old policy, the next request is denied under the new one.
      mem_lat_min = 80; mem_lat_max = 80;
      mem_fill(8'hA5);
      begin
        longint unsigned acc0 = n_acc[0], rsp0 = n_rsp[0];
        for (int k = 0; k < 3; k++) begin
          send_only(0, 1, 64'h1000 + 8 * k, 8, 0, IDW'(k), pat64(k), '1);
        end
        // stage a CLR_REGION(0,0) and write the command while the three writes are still outstanding
        t0 = cyc;
        start_cmd(CMD_CLR_REGION, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ce2);
        // the command is accepted; the engine must now be busy / blocking until the writes have been answered
        crd_t(R_STATE, dd);
        expect_eq("T09a engine busy", dd[0], 1); expect_eq("T09a ingress blocked", dd[1], 1); expect_eq("T09a in-flight visible", dd[3], 1);
        // try a request from port 1 during the drain: it must not be accepted before the commit
        blocked_cycles = 0;
        tick();
        r_valid[1] = 1; r_op[1*2 +: 2] = 2'd0; r_addr[1*AW +: AW] = AW'(64'h2000); r_len[1*LW +: LW] = LW'(8); r_id[1*IDW +: IDW] = IDW'(9); r_dom[1*DOMW +: DOMW] = DOMW'(1);
        #8;
        while (!r_ready[1]) begin blocked_cycles++; tick(); #8; end
        tick(); r_valid[1] = 0;
        t_commit = cyc;
        checks++; if (blocked_cycles < 10) fail($sformatf("T09a: port 1 was accepted after only %0d blocked cycles (the drain should take ~80)", blocked_cycles));
        // then a write to the revoked region from port 0 is denied under the new policy
        xact_expect("T09a new policy applies after the commit", 0, 1, 64'h1000, 8, 0, pat64(1), '1, 3, rd);
        wait_cfg_idle(1000);
        expect_eq("T09a three old writes completed", n_rsp[0] - rsp0, 4);
        for (int k = 0; k < 3; k++) begin pw = pat64(k); for (int j = 0; j < 8; j++) expect_eq("T09a old write landed", mem[64'h1000 + 8*k + j], pw[8*j +: 8]); end
        quiesce();
        expect_eq("T09a all oracle-expected requests answered", exp_q[0].size() + exp_q[1].size(), 0);
      end
      mem_lat_min = 1; mem_lat_max = 3;
      set_region(0, 0, 64'h1000, 64'h1000, 1, 1);

      // ---- (b) drain timeout: the memory stops answering; the revocation is NOT applied, ingress is released, the table is intact
      cwr(R_DRAIN_TMO, 32'd60, e);
      mem_freeze = 1;
      send_only(2, 0, 64'h4000, 8, 2, IDW'(1), '0, '0);
      repeat (6) @(posedge clk);
      crd_t(R_GEN, g0);
      cwr(R_STATUS, 32'h1FFF, e);
      start_cmd(CMD_CLR_REGION, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, ce2);
      pend.v = 1'b0;                                                        // the oracle will not apply it: the DUT must abort
      begin
        int w = 0; bit [31:0] ss;
        crd_t(R_STATE, ss); while (ss[0] && w < 400) begin crd_t(R_STATE, ss); w++; end
        checks++; if (w >= 400) fail("T09b: drain timeout never fired");
        expect_eq("T09b last_err = TMO", ss[11:8], CE_TMO);
        expect_eq("T09b ingress released", ss[1], 0);
        rchkb("T09b STATUS.TMO", R_STATUS, STAT_TMO, 1);
        rchk("T09b generation unchanged", R_GEN, g0);
        cnt_chk("T09b CN_TMO", CN_TMO, 1);
      end
      cwr(R_SEL, {12'd0, 4'd0, 4'd0, 4'd0, 4'd0, 4'd2}, e);
      crd_t(R_RD_ATTR, cd); expect_eq("T09b the region was NOT removed", cd[31], 1);
      mem_freeze = 0;                                                       // the memory answers again; the old read completes
      repeat (20) @(posedge clk);
      quiesce();
      // a retry now succeeds (it is a revocation of dom2 region 0 and then a restore)
      do_cmd(CMD_CLR_REGION, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, ce2);
      xact_expect("T09b retry applied: region gone", 2, 0, 64'h4000, 8, 2, '0, '0, 3, rd);
      set_region(2, 0, 64'h4000, 64'h0100, 1, 1);
      cwr(R_DRAIN_TMO, 32'd0, e);

      // ---- (c) a requester that does not take its response delays the commit (cannot make it unsafe)
      s_ready_pct = 0;
      send_only(3, 0, 64'h5000, 8, 3, IDW'(2), '0, '0);
      repeat (10) @(posedge clk);
      start_cmd(CMD_CLR_REGION, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, ce2);
      repeat (50) @(posedge clk);
      crd_t(R_STATE, dd); expect_eq("T09c still draining while the response is not taken", dd[0], 1);
      s_ready_pct = 100;
      wait_cfg_idle(1000);
      xact_expect("T09c commit after the response was taken", 3, 0, 64'h5000, 8, 3, '0, '0, 3, rd);
      set_region(3, 0, 64'h5000, 64'h2000, 1, 1);
    end

    // ============================================================ T08 configuration lock
    $display("T08 configuration lock");
    begin
      bit e; int ce2; bit [31:0] rdv; int c_l0;
      crd_t(R_GEN, g0);
      cnt_get(CN_LOCKREJ, c_l0);
      cwr(R_CTRL, 32'h8000_0000, e); expect_eq("T08 lock write accepted", e, 0);
      rchkb("T08 locked", R_CTRL, 31, 1);
      crd_t(R_STATE, cd); expect_eq("T08 R_STATE.locked", cd[2], 1);
      cwr(R_CTRL, 32'h0000_0000, e); rchkb("T08 lock cannot be cleared", R_CTRL, 31, 1);
      expect_refused = 1'b1;
      do_cmd(CMD_CLR_REGION, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ce2);           // a perfectly valid command: the lock must refuse it
      expect_refused = 1'b0;
      cwr(R_BASE_LO, 32'h1234, e);   expect_eq("T08 staging write refused", e, 1);
      cwr(R_DRAIN_TMO, 32'd9, e);    expect_eq("T08 timeout write refused", e, 1);
      cwr(R_CMD, 32'(CMD_CLEAR_ALL), e); expect_eq("T08 command refused", e, 1);
      rchkb("T08 STATUS.LOCKED", R_STATUS, STAT_LOCKED, 1);
      begin bit [31:0] cl1; cnt_get(CN_LOCKREJ, cl1); expect_eq("T08 CN_LOCKREJ (1 lock clear + 6 staging + 1 command + 3 more)", cl1 - c_l0, 11); end
      rchk("T08 generation unchanged", R_GEN, g0);
      // diagnostics still work under the lock
      cwr(R_STATUS, 32'h1FFF, e); expect_eq("T08 W1C allowed under lock", e, 0);
      cwr(R_CNT_SEL, 32'd3, e);   expect_eq("T08 counter select allowed under lock", e, 0);
      cwr(R_SEL, 32'd0, e);       expect_eq("T08 readback select allowed under lock", e, 0);
      // the policy still enforces
      xact_expect("T08 policy intact under lock", 0, 1, 64'h1000, 8, 0, pat64(1), '1, 0, rd);
      xact_expect("T08 policy intact under lock (denied)", 0, 1, 64'h0000, 8, 0, pat64(1), '1, 3, rd);
    end

    // ============================================================ T10 reset
    $display("T10 reset");
    begin
      // reset while traffic is outstanding: policy, lock, counters, log, generation are all gone; the datapath is default-deny again
      mem_lat_min = 30; mem_lat_max = 30;
      for (int k = 0; k < 2; k++) begin
        send_only(0, 0, 64'h1000, 8, 0, IDW'(k), '0, '0);
      end
      repeat (3) @(posedge clk);
      do_reset(6);
      mem_lat_min = 1; mem_lat_max = 3;
      rchk("T10 R_CTRL.lock cleared", R_CTRL, 0);
      rchk("T10 R_GEN", R_GEN, 0);
      rchk("T10 R_STATUS", R_STATUS, 0);
      rchkm("T10 log empty", R_FLOG_CNT, 32'hFF, 0);
      cnt_chk("T10 CN_FAULTS", CN_FAULTS, 0);
      expect_eq("T10 idle", idle_o, 1);
      for (int d = 0; d < ND; d++) for (int i = 0; i < NR; i++) begin
        bit e; cwr(R_SEL, {12'd0, 4'd0, 4'd0, 4'(i), 4'd0, 4'(d)}, e);
        rchkb("T10 region invalid after reset", R_RD_ATTR, 31, 0);
      end
      for (int p = 0; p < NP; p++) xact_expect("T10 default deny after reset", p, 0, 64'h1000, 8, p % ND, '0, '0, 3, rd);
      // reset during a draining command: the command is lost, the table stays empty
      begin
        int ce2; bit e;
        bind_default();
        set_region(0, 0, 64'h1000, 64'h1000, 1, 1);
        mem_lat_min = 60; mem_lat_max = 60;
        send_only(0, 0, 64'h1000, 8, 0, IDW'(1), '0, '0);
        start_cmd(CMD_CLR_REGION, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ce2);
        repeat (5) @(posedge clk);
        pend.v = 1'b0;
        do_reset(4);
        mem_lat_min = 1; mem_lat_max = 3;
        xact_expect("T10 default deny after a reset during a drain", 0, 0, 64'h1000, 8, 0, '0, '0, 3, rd);
        rchkm("T10 R_STATE idle", R_STATE, 3, 0);
      end
    end

    // ============================================================ T20 summary of observed conditions
    expect_eq("monitor violations (M1/M2/M3/PROTO)", mon_viol, 0);
    $display("tb_mg_directed: %0d checks, %0d errors", checks, errors);
    if (errors == 0) $display("TB_RESULT: PASS tb_mg_directed ND=%0d NR=%0d NP=%0d CHK_PIPE=%0d LOOKUP_ARCH=%0d STRICT=%0d LEN_POW2=%0d DIAG_PRECISE=%0d", ND, NR, NP, CHK_PIPE, LOOKUP_ARCH, STRICT, LEN_POW2, DIAG_PRECISE);
    else             $display("TB_RESULT: FAIL tb_mg_directed errors=%0d", errors);
    $finish;
  end

  initial begin
    #200000000;
    $display("TB_RESULT: FAIL tb_mg_directed TIMEOUT");
    $finish;
  end
endmodule
