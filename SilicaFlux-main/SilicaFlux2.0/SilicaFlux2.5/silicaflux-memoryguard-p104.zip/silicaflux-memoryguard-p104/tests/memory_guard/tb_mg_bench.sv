// =============================================================================
// MemoryGuard throughput / latency bench: how much does protection cost?  Every port streams 8-byte requests at full rate into an
// always-ready memory of fixed latency (+memlat=L); a fraction (+den=P percent) of the requests is denied.  The same stimulus runs on every
// configuration, so the differences are the guard's.  Output: BENCH lines parsed by benchmarks/memory_guard/run_bench.py.
// =============================================================================
`timescale 1ns/1ps
module tb_mg_bench #(
  parameter int ND = 4, parameter int NR = 4, parameter int NP = 4, parameter int AW = 16, parameter int DW = 64, parameter int IDW = 8,
  parameter int DOMW = 3, parameter int MAXOUT = 4, parameter int CHK_PIPE = 0, parameter int LOOKUP_ARCH = 0,
  parameter int DIAG_PRECISE = 1, parameter int STRICT = 0, parameter int LEN_POW2 = 0, parameter int FLOG_DEPTH = 8
);
`include "tb_common.svh"
  int unsigned den_pct = 0, memlat = 1, issue_pct = 100, nports = NP, cmd_every = 0;
  bit gen_en = 0;
  int unsigned rs = 32'hC0FFEE01;
  function automatic int unsigned rnd(); begin rs ^= rs << 13; rs ^= rs >> 17; rs ^= rs << 5; rnd = rs; end endfunction
  longint unsigned issued [NP];

  always @(posedge clk) begin
    if (rst_n && gen_en) for (int p = 0; p < NP; p++) begin
      if (p < nports && (!r_valid[p] || r_ready[p])) begin
        if (rnd() % 100 < issue_pct) begin
          longint unsigned a; bit deny;
          deny = ((rnd() % 100) < den_pct);
          a = 64'h1000 * (p + 1) + 8 * (rnd() % 64);              // inside the port's RW region
          if (deny) a = 64'h0100 + 8 * (rnd() % 64);              // outside every region
          r_valid[p] <= 1'b1; r_op[p*2 +: 2] <= 2'(rnd() % 2); r_addr[p*AW +: AW] <= AW'(a); r_len[p*LW +: LW] <= LW'(8);
          r_wdata[p*DW +: DW] <= {DW{1'b1}}; r_be[p*BW +: BW] <= '1; r_id[p*IDW +: IDW] <= IDW'(issued[p]); r_dom[p*DOMW +: DOMW] <= DOMW'(p % ND);
          issued[p]++;
        end else r_valid[p] <= 1'b0;
      end else if (p >= nports) r_valid[p] <= 1'b0;
    end
  end

  task automatic scenario(input string name);
    longint unsigned a0 [NP], r0 [NP], ls0 [NP], ln0 [NP], c0, cm; int unsigned win;
    real thr, lat;
    begin
      win = 4000;
      gen_en = 1; repeat (300) tick();                                  // warm up
      for (int p = 0; p < NP; p++) begin a0[p] = n_acc[p]; r0[p] = n_rsp[p]; ls0[p] = lat_sum[p]; ln0[p] = lat_n[p]; end
      c0 = cyc;
      repeat (win) tick();
      cm = cyc - c0;
      begin
        longint unsigned acc_t = 0, rsp_t = 0, ls = 0, ln = 0;
        for (int p = 0; p < nports; p++) begin acc_t += n_acc[p] - a0[p]; rsp_t += n_rsp[p] - r0[p]; ls += lat_sum[p] - ls0[p]; ln += lat_n[p] - ln0[p]; end
        thr = real'(rsp_t) / real'(cm) / real'(nports); lat = (ln == 0) ? 0.0 : real'(ls) / real'(ln);
        $display("BENCH name=%s CHK_PIPE=%0d MAXOUT=%0d LOOKUP_ARCH=%0d NP=%0d memlat=%0d den=%0d issue=%0d resp_per_cycle_per_port=%0.4f latency_avg=%0.2f", name, CHK_PIPE, MAXOUT, LOOKUP_ARCH, nports, memlat, den_pct, issue_pct, thr, lat);
      end
      gen_en = 0; tick(); for (int p = 0; p < NP; p++) r_valid[p] = 1'b0;
      repeat (60) tick();
      while (!idle_o) tick();
    end
  endtask

  initial begin : main
    bit e; int ce;
    void'($value$plusargs("memlat=%d", memlat)); void'($value$plusargs("den=%d", den_pct)); void'($value$plusargs("nports=%d", nports));
    wait (rst_n === 1'b0); repeat (3) @(posedge clk);
    do_reset();
    for (int p = 0; p < NP; p++) issued[p] = 0;
    for (int p = 0; p < NP; p++) bind_port(p, 1 << (p % ND));
    for (int p = 0; p < NP; p++) set_region(p % ND, p / ND, 64'h1000 * (p + 1), 64'h0800, 1, 1);
    mem_lat_min = memlat; mem_lat_max = memlat; m_ready_pct = 100; s_ready_pct = 100;
    scenario("stream");
    if (errors != 0) $display("TB_RESULT: FAIL tb_mg_bench errors=%0d", errors); else $display("TB_RESULT: PASS tb_mg_bench");
    $finish;
  end
  initial begin #300000000; $display("TB_RESULT: FAIL tb_mg_bench TIMEOUT"); $finish; end
endmodule
