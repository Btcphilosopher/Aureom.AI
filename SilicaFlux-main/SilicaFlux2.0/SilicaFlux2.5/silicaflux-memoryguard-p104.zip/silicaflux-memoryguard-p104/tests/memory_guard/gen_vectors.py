#!/usr/bin/env python3
"""Independent Python reference model of the MemoryGuard permission decision + test-vector generator.

Written separately from the RTL and from the SystemVerilog oracle: arbitrary-precision integers, a plain list of regions per domain,
no fixed-width arithmetic anywhere (so address wrap-around cannot be got wrong the same way twice).

The vector file is a stream of lines consumed by tb_checker_vec.sv:
    C  ND NR NP AW LW MAXLEN LEN_POW2 DIAG        (header, once)
    X                                             start of a new table: every region invalid, every binding empty
    T  dom idx base end r w devn devmask          install a region (base, exclusive end: hex)
    A  port allow                                 trusted binding of a port (hex)
    Q  port op addr len dom exp_permit exp_fault  one query (addr hex, others decimal)
usage: gen_vectors.py OUT.vec [--tables N] [--queries M] [--seed S] [--aw AW] [--nd ND] [--nr NR] [--np NP] [--pow2] [--nodiag]
"""
import argparse, random

FT = dict(NONE=0, NOMAP=1, PERM=2, SPAN=3, OVERFLOW=4, ZEROLEN=5, BADOP=6, BADDOM=7, SPOOF=8, DEVICE=9, BADLEN=10)

class Model:
    def __init__(s, nd, nr, np_, aw, maxlen, pow2, diag):
        s.nd, s.nr, s.np, s.aw, s.maxlen, s.pow2, s.diag = nd, nr, np_, aw, maxlen, pow2, diag
        s.regions = {d: [] for d in range(nd)}      # dom -> list of (base, end, r, w, devn, devmask)
        s.allow = [0] * np_
    def check(s, port, op, addr, ln, dom):
        if op not in (0, 1): return FT["BADOP"]
        if ln == 0: return FT["ZEROLEN"]
        if ln > s.maxlen or (s.pow2 and (ln & (ln - 1)) != 0): return FT["BADLEN"]
        end = addr + ln
        if end > (1 << s.aw): return FT["OVERFLOW"]
        if dom >= s.nd: return FT["BADDOM"]
        if not (s.allow[port] >> dom) & 1: return FT["SPOOF"]
        contained = [r for r in s.regions[dom] if r[0] <= addr and end <= r[1]]
        touching = [r for r in s.regions[dom] if addr < r[1] and r[0] < end]
        for (b, e, r, w, devn, dm) in contained:
            if (not devn or (dm >> port) & 1) and (w if op == 1 else r):
                return FT["NONE"]
        if contained:
            if all(devn and not (dm >> port) & 1 for (b, e, r, w, devn, dm) in contained):
                return FT["DEVICE"]
            return FT["PERM"]
        if touching and s.diag: return FT["SPAN"]
        return FT["NOMAP"]

def gen_table(rng, m, space):
    """a random table that obeys the install rules: valid intervals, no overlap inside a domain (cross-domain overlap allowed)"""
    for d in range(m.nd):
        for i in range(m.nr):
            if rng.random() < 0.25: continue
            for _ in range(20):
                k = rng.random()
                if k < 0.15: base = space - rng.choice([1, 2, 4, 8, 16, 64]) ; size = space - base
                elif k < 0.3 and m.regions[d]: base = rng.choice(m.regions[d])[1]; size = rng.choice([1, 2, 8, 16, 100])      # touching the previous one
                elif k < 0.4: base = 0; size = rng.choice([1, 8, 64, 4096])
                else:
                    base = rng.randrange(0, space); size = rng.choice([1, 2, 3, 7, 8, 9, 15, 16, 17, 255, 4096, rng.randrange(1, 1 << 16)])
                if base >= space: continue                      # not installable (the table only holds regions inside the address space)
                size = max(1, min(size, space - base))
                end = base + size
                if any(base < r[1] and r[0] < end for r in m.regions[d]): continue
                devn = rng.random() < 0.3
                m.regions[d].append((base, end, rng.random() < 0.8, rng.random() < 0.6, devn, rng.randrange(1 << m.np) if devn else 0))
                break
    for p in range(m.np):
        m.allow[p] = (1 << (p % m.nd)) if rng.random() < 0.7 else rng.randrange(1 << m.nd)
        if rng.random() < 0.3: m.allow[p] |= rng.randrange(1 << m.nd)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out"); ap.add_argument("--tables", type=int, default=300); ap.add_argument("--queries", type=int, default=500)
    ap.add_argument("--seed", type=int, default=1); ap.add_argument("--aw", type=int, default=32); ap.add_argument("--nd", type=int, default=4)
    ap.add_argument("--nr", type=int, default=4); ap.add_argument("--np", type=int, default=4); ap.add_argument("--maxlen", type=int, default=8)
    ap.add_argument("--pow2", action="store_true"); ap.add_argument("--nodiag", action="store_true")
    a = ap.parse_args()
    rng = random.Random(a.seed)
    lw = (a.maxlen).bit_length()          # clog2(maxlen+1)
    space = 1 << a.aw
    nq = 0
    with open(a.out, "w") as f:
        f.write(f"C {a.nd} {a.nr} {a.np} {a.aw} {lw} {a.maxlen} {int(a.pow2)} {int(not a.nodiag)}\n")
        for t in range(a.tables):
            m = Model(a.nd, a.nr, a.np, a.aw, a.maxlen, a.pow2, not a.nodiag)
            gen_table(rng, m, space)
            f.write("X\n")
            for d in range(a.nd):
                for i, (b, e, r, w, devn, dm) in enumerate(m.regions[d]):
                    f.write(f"T {d} {i} {b:x} {e:x} {int(r)} {int(w)} {int(devn)} {dm:x}\n")
            for p in range(a.np): f.write(f"A {p} {m.allow[p]:x}\n")
            edges = [0, space - 1, space]
            for d in range(a.nd):
                for (b, e, *_r) in m.regions[d]: edges += [b, e, e - 1]
            for _ in range(a.queries):
                k = rng.random()
                p = rng.randrange(a.np)
                ln = rng.choice([1, 1, 2, 3, 4, 5, 7, 8, 8, 9, 0, 15, 16]) if rng.random() < 0.9 else rng.randrange(0, 1 << lw)
                ln = min(ln, (1 << lw) - 1)
                if k < 0.55: addr = rng.choice(edges) + rng.randrange(-10, 11)
                elif k < 0.7: addr = space - rng.randrange(1, 20)
                elif k < 0.85 and edges: addr = rng.choice(edges)
                else: addr = rng.randrange(0, space)
                addr %= space
                op = rng.choice([0, 0, 1, 1, 1, 2, 3]) if rng.random() < 0.97 else rng.randrange(4)
                dom = rng.randrange(a.nd) if rng.random() < 0.85 else rng.randrange(8)
                if rng.random() < 0.5 and m.allow[p]:
                    dom = rng.choice([d for d in range(a.nd) if (m.allow[p] >> d) & 1])
                exp = m.check(p, op, addr, ln, dom)
                f.write(f"Q {p} {op} {addr:x} {ln} {dom} {int(exp == 0)} {exp}\n"); nq += 1
    print(f"{a.out}: {a.tables} tables, {nq} queries")

if __name__ == "__main__":
    main()
