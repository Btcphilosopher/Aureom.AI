// =============================================================================
// MemoryGuard adversarial random verification (T11 concurrent DMA, T16 back-pressure ordering, mid-flight policy changes under load).
//
//   * NP ports hammer the guard concurrently with a biased mix: legal requests, region-edge requests (base-1, base, end-len, end-len+1,
//     end), address-space-top / overflow requests, spoofed domain claims, invalid domains, zero / oversize lengths, unsupported ops,
//     random garbage.  Write data of port p at address A is patt(p, A), so any stray byte is attributable.
//   * a background agent reconfigures the guard WHILE the traffic runs: valid and invalid region installs (overlapping, adjacent,
//     wrapping, out of range, bad index), removals, port rebinding, CLEAR_ALL, device masks, unprivileged attempts, fault-log pops.
//   * random ready patterns on both sides and random memory latency.
// Checks: the oracle's expected status for every response (M4), policy at the memory side at the cycle of every transaction (M1),
// transaction provenance (M2), zero memory-side wires without m_valid (M3), blocking (M5), commit only when idle (M6), and at the end
//   E1 canary: a byte differs from its initial value only if a permitted write of exactly that port / value was accepted for it
//   E2 landing: with no reset in the run, every byte of a permitted write landed (value of one of the writers)
//   E3 counters: fault / forward / per-port / per-type / commit / refused-command / security counters equal the testbench tallies
//   E4 coverage: every fault class and every command outcome occurred (the stimulus really was adversarial)
// =============================================================================
`timescale 1ns/1ps
module tb_mg_random #(
  parameter int ND = 4, parameter int NR = 4, parameter int NP = 4, parameter int AW = 16, parameter int DW = 64, parameter int IDW = 8,
  parameter int DOMW = 3, parameter int MAXOUT = 4, parameter int CHK_PIPE = 0, parameter int LOOKUP_ARCH = 0,
  parameter int DIAG_PRECISE = 1, parameter int STRICT = 0, parameter int LEN_POW2 = 0, parameter int FLOG_DEPTH = 8,
  parameter int SEED = 1, parameter int NCYC = 150000, parameter int MIDRESET = 0, parameter int MM_ECC = 0
);
`include "tb_common.svh"

  // ------------------------------------------------------------------ deterministic random numbers (xorshift32)
  int unsigned rs = 32'h2545F491 ^ SEED * 32'h9E3779B1;
  function automatic int unsigned rnd();
    begin rs ^= rs << 13; rs ^= rs >> 17; rs ^= rs << 5; rnd = rs; end
  endfunction
  function automatic int unsigned rndn(input int unsigned n);
    begin rndn = (n == 0) ? 0 : (rnd() % n); end
  endfunction

  bit gen_en = 1'b0;
  int issue_pct [NP];
  longint unsigned n_issued [NP];
  int unsigned wrote_mask [MEMSZ];             // ports that have an accepted, permitted write covering the byte
  int unsigned n_perm_wr = 0, n_perm_rd = 0, n_cmd_ok = 0, n_cmd_ref = 0, n_unpriv = 0, n_popped = 0, n_commit_busy = 0, n_resets = 0;
  int unsigned n_cls [8];
  bit  reset_seen = 0;

  // ------------------------------------------------------------------ request generator (one per port)
  function automatic longint unsigned pick_edge(input int dom);
    int i; longint unsigned c;
    begin
      i = rndn(NR); c = 0;
      for (int k = 0; k < NR; k++) if (rv[dom][(i + k) % NR]) begin
        i = (i + k) % NR;
        c = (rnd() & 1) ? rb[dom][i] : re[dom][i];
        break;
      end
      pick_edge = c;
    end
  endfunction

  // at an accept the oracle also updates the write-landing tally
  always @(posedge clk) begin
    if (rst_n) for (int p = 0; p < NP; p++) begin
      if (r_valid[p] && r_ready[p]) begin
        int op, len, dom; longint unsigned addr; int f;
        op = int'(r_op[p*2 +: 2]); len = int'(r_len[p*LW +: LW]); dom = int'(r_dom[p*DOMW +: DOMW]); addr = longint'(r_addr[p*AW +: AW]);
        f = ref_check(p, op, addr, len, dom);
        if (f == FT_NONE) begin
          if (op == 1) begin
            n_perm_wr++;
            for (int j = 0; j < BW; j++) if (j < len && r_be[p*BW + j] && (addr + j) < MEMSZ) wrote_mask[addr + j] |= (1 << p);
          end else n_perm_rd++;
        end
      end
    end
  end

  always @(posedge clk) begin
    if (rst_n && gen_en) for (int p = 0; p < NP; p++) begin
      if (!r_valid[p] || r_ready[p]) begin
        if (rndn(100) < issue_pct[p]) begin
          int cls, op, len, dom; longint unsigned a; bit [DW-1:0] wd; bit [BW-1:0] be;
          cls = rndn(100);
          op  = (rndn(100) < 55) ? 0 : 1;
          len = 1 + rndn(BW);
          dom = p % ND;
          a   = rndn(1 << 14) + 64'h0800;
          if (cls < 50) begin                                   // a request inside a region of a domain the port may act for
            bit got; got = 0;
            for (int t = 0; t < ND && !got; t++) begin
              int dd; dd = (rndn(ND) + t) % ND;
              if (rallow[p][dd]) for (int i = 0; i < NR && !got; i++) if (rv[dd][i]) begin
                dom = dd; a = rb[dd][i] + rndn(int'(re[dd][i] - rb[dd][i])); got = 1;
              end
            end
            op = rndn(2);
            n_cls[0]++;
          end else if (cls < 75) begin                          // region edges, any domain, any claim
            int dd; dd = rndn(ND);
            dom = (rndn(4) == 0) ? rndn(1 << DOMW) : ((rndn(2) == 0) ? p % ND : dd);
            a = pick_edge(dd);
            a = a + rndn(2 * BW + 3) - (BW + 1);
            a = a & (SPACE - 1);
            n_cls[1]++;
          end else if (cls < 82) begin                          // address-space top / wrap
            a = SPACE - 1 - rndn(BW + 3) + ((rndn(3) == 0) ? 3 : 0);
            a = a & ((SPACE << 1) - 1);
            a = a & (SPACE - 1);
            dom = (rndn(2) == 0) ? p % ND : rndn(1 << DOMW);
            n_cls[2]++;
          end else if (cls < 88) begin                          // spoof / invalid domain claims against valid addresses
            int dd; dd = rndn(ND);
            a = pick_edge(dd) + rndn(8);
            dom = (rndn(2) == 0) ? rndn(1 << DOMW) : (dd + 1 + rndn(ND - 1)) % ND;
            n_cls[3]++;
          end else if (cls < 95) begin                          // bad lengths / ops
            len = (rndn(2) == 0) ? 0 : (BW + 1 + rndn((1 << LW) - BW - 1));
            if (rndn(3) == 0) op = 2 + rndn(2);
            a = pick_edge(p % ND);
            n_cls[4]++;
          end else begin                                        // garbage
            a = rnd(); a = a & (SPACE - 1); len = rndn(1 << LW); op = rndn(4); dom = rndn(1 << DOMW);
            n_cls[5]++;
          end
          if (len > (1 << LW) - 1) len = (1 << LW) - 1;
          for (int j = 0; j < BW; j++) wd[8*j +: 8] = patt(p, (a + j) & 64'hFFFF);
          be = (rndn(100) < 70) ? '1 : BW'(rnd());
          r_valid[p] <= 1'b1; r_op[p*2 +: 2] <= 2'(op); r_addr[p*AW +: AW] <= AW'(a); r_len[p*LW +: LW] <= LW'(len);
          r_wdata[p*DW +: DW] <= wd; r_be[p*BW +: BW] <= be; r_id[p*IDW +: IDW] <= IDW'(n_issued[p]); r_dom[p*DOMW +: DOMW] <= DOMW'(dom);
          n_issued[p]++;
        end else begin
          r_valid[p] <= 1'b0;
        end
      end
    end
  end

  // ------------------------------------------------------------------ background configuration agent
  task automatic rnd_region_cmd();
    int kind, dom, idx, port, dev, allow; longint unsigned base, size; bit r, w, devn; int ce; int sel;
    begin
      sel  = rndn(100);
      if (sel >= 60 && sel < 82 && rndn(3) != 0) sel = rndn(60);          // bindings change less often than regions
      dom  = rndn(ND); idx = rndn(NR); port = rndn(NP);
      r = (rndn(4) != 0); w = (rndn(3) != 0); devn = (rndn(6) == 0); dev = rndn(1 << NP);
      allow = (1 << (port % ND));                                                  // usually the port's own domain ...
      if (rndn(4) == 0) allow |= rndn(1 << ND);                                    // ... sometimes more ...
      if (rndn(12) == 0) allow = rndn(1 << ND);                                    // ... or anything, including nothing
      base = (rndn(1 << 12) << 4) + 64'h0800; size = (rndn(64) + 1) << 4;
      if (sel < 45) begin                                  // install; sometimes next to / over an existing region
        kind = CMD_SET_REGION;
        if (rndn(2) == 0) begin
          int d3 = rndn(ND); int i3 = rndn(NR);
          if (rv[d3][i3]) begin
            case (rndn(4))
              0: base = re[d3][i3];                                          // adjacent after
              1: base = (rb[d3][i3] > size) ? rb[d3][i3] - size : 0;         // adjacent before
              2: begin base = rb[d3][i3] + 1; size = 8; end                  // inside: overlap
              default: begin base = rb[d3][i3]; size = re[d3][i3] - rb[d3][i3]; end   // exact copy (self if same slot)
            endcase
          end
        end
        if (rndn(8) == 0) begin base = SPACE - (rndn(5) << 4); size = ((rndn(5)) << 4) + 16; end     // top of the address space / wrap
      end else if (sel < 60) kind = CMD_CLR_REGION;
      else if (sel < 82) kind = CMD_BIND_PORT;
      else if (sel < 85) kind = CMD_CLEAR_ALL;
      else begin                                           // invalid commands
        case (rndn(6))
          0: begin kind = CMD_SET_REGION; dom = ND + rndn(3); end
          1: begin kind = CMD_SET_REGION; idx = NR + rndn(3); end
          2: begin kind = CMD_SET_REGION; size = 0; end
          3: begin kind = CMD_BIND_PORT; port = NP + rndn(3); end
          4: begin kind = CMD_BIND_PORT; allow = (1 << ND) | rndn(1 << ND); end
          default: kind = 9 + rndn(7);
        endcase
      end
      if (kind == CMD_SET_REGION && dom < ND && idx < NR && NP < 8) dev = dev & ((1 << NP) - 1);
      start_cmd(kind, dom, idx, port, base, size, r, w, devn, dev, allow, ce);
      if (ce == CE_OK) begin n_cmd_ok++; if (!idle_o) n_commit_busy++; wait_cfg_idle(200000); end else n_cmd_ref++;
    end
  endtask

  bit bg_run = 1'b0;
  int bg_active = 0;
  task automatic bg_agent();
    bit e; bit [31:0] d; int k;
    begin
      bg_active++;
      while (bg_run) begin
        repeat (10 + rndn(120)) tick();
        if (!bg_run) break;
        k = rndn(100);
        if (k < 70) rnd_region_cmd();
        else if (k < 80) begin                                       // unprivileged attempts: no effect on anything
          bit [31:0] rdv;
          cfg_acc(1'b1, R_CMD, 32'(CMD_CLEAR_ALL), 1'b0, 4'hF, rdv, e); if (!e) fail("unprivileged CLEAR_ALL did not error"); n_unpriv++;
          cfg_acc(1'b1, R_ALLOW, 32'hFFFF, 1'b0, 4'hF, rdv, e);         if (!e) fail("unprivileged write did not error"); n_unpriv++;
          cfg_acc(1'b0, R_FLOG_W1, 32'd0, 1'b0, 4'hF, rdv, e);          if (!e || rdv != 0) fail("unprivileged fault-log read leaked / did not error"); n_unpriv++;
        end else if (k < 95) begin                                   // drain the fault log (privileged)
          bit [31:0] c;
          crd_t(R_FLOG_CNT, c);
          if (c[7:0] != 0) begin cwr(R_FLOG_POP, 32'd1, e); n_popped++; end
        end else begin                                               // read the whole register file (must never error when privileged)
          for (int r_ = 0; r_ < NREG; r_++) begin crd(r_, d, e); if (e) fail($sformatf("privileged read of register %0d errored", r_)); end
        end
      end
      bg_active--;
    end
  endtask

  // ------------------------------------------------------------------ main
  initial begin : main
    longint unsigned c0, tot_den, tot_mem; bit [31:0] v; int ce;
    void'($urandom(SEED));
    for (int p = 0; p < NP; p++) begin issue_pct[p] = 20 + rndn(70); n_issued[p] = 0; end
    for (int i = 0; i < MEMSZ; i++) wrote_mask[i] = 0;
    for (int i = 0; i < 8; i++) n_cls[i] = 0;
    wait (rst_n === 1'b0);
    repeat (3) @(posedge clk);
    do_reset();
    $display("tb_mg_random: SEED=%0d NCYC=%0d ND=%0d NR=%0d NP=%0d CHK_PIPE=%0d LOOKUP_ARCH=%0d STRICT=%0d LEN_POW2=%0d DIAG_PRECISE=%0d MIDRESET=%0d",
             SEED, NCYC, ND, NR, NP, CHK_PIPE, LOOKUP_ARCH, STRICT, LEN_POW2, DIAG_PRECISE, MIDRESET);
    mem_fill(8'hA5);
`ifdef MG_EXT_MEM
    host_fill(8'hA5);                                              // the real memory (MemoryMatrix) starts with the canary, written through its host port
`endif
    // initial policy: each port bound to its domain, a few regions
    for (int p = 0; p < NP; p++) bind_port(p, 1 << (p % ND));
    for (int d = 0; d < ND; d++) set_region(d, 0, 64'h1000 + 64'h1000 * d, 64'h0800, 1, 1);
    m_ready_pct = 70; s_ready_pct = 75; mem_lat_min = 1; mem_lat_max = 4;
    gen_en = 1'b1; bg_run = 1'b1;
    fork bg_agent(); join_none
    for (int cyc_n = 0; cyc_n < NCYC; cyc_n++) begin
      tick();
      if (cyc_n % 20000 == 0) begin                                  // vary the pressure
        m_ready_pct = 30 + rndn(71); s_ready_pct = 30 + rndn(71);
        mem_lat_min = 1 + rndn(3); mem_lat_max = mem_lat_min + rndn(6);
        for (int p = 0; p < NP; p++) issue_pct[p] = 10 + rndn(91);
      end
      if (MIDRESET != 0 && cyc_n == NCYC / 2) begin                 // reset under load: policy gone, nothing may leak afterwards
        gen_en = 1'b0; bg_run = 1'b0;
        while (bg_active != 0) tick();
        do_reset(5); n_resets++; reset_seen = 1;
        for (int p = 0; p < NP; p++) begin r_valid[p] = 0; end
        for (int p = 0; p < NP; p++) bind_port(p, 1 << (p % ND));
        for (int d = 0; d < ND; d++) set_region(d, 0, 64'h1000 + 64'h1000 * d, 64'h0800, 1, 1);
        gen_en = 1'b1; bg_run = 1'b1;
        fork bg_agent(); join_none
      end
    end
    // ---- stop, drain, final checks
    gen_en = 1'b0; bg_run = 1'b0;
    while (bg_active != 0) tick();
    repeat (200) tick();
    for (int p = 0; p < NP; p++) r_valid[p] = 0;
    m_ready_pct = 100; s_ready_pct = 100; mem_freeze = 0;
    wait_cfg_idle(100000);
    quiesce();
    repeat (20) tick();
`ifdef MG_EXT_MEM
    host_dump();                                                   // read the whole array back through the host port into the image the checks use
`endif
    for (int p = 0; p < NP; p++) begin
      expect_eq($sformatf("port %0d: every accepted request answered", p), exp_q[p].size(), 0);
      expect_eq($sformatf("port %0d: every permitted request reached the memory", p), fwd_q[p].size(), 0);
    end
    // E1 / E2: memory image vs accepted permitted writes
    begin
      int bad1 = 0, bad2 = 0; int unsigned nb = 0, nl = 0;
      for (int x = 0; x < MEMSZ; x++) begin
        bit ok;
        if (mem[x] !== 8'hA5) begin
          ok = 0;
          for (int p = 0; p < NP; p++) if ((wrote_mask[x] >> p) & 1) if (mem[x] === patt(p, x)) ok = 1;
          if (!ok) begin bad1++; if (bad1 < 5) fail($sformatf("E1: byte 0x%0h = 0x%0h was modified without a permitted write of the matching port", x, mem[x])); end
          nb++;
        end else if (wrote_mask[x] != 0 && !reset_seen) begin
          // a permitted write accepted for this byte must have landed, unless its value equals the canary
          ok = 0;
          for (int p = 0; p < NP; p++) if (((wrote_mask[x] >> p) & 1) && patt(p, x) == 8'hA5) ok = 1;
          if (!ok) begin bad2++; if (bad2 < 5) fail($sformatf("E2: byte 0x%0h: a permitted write was accepted but did not land", x)); end
        end
        if (wrote_mask[x] != 0) nl++;
      end
      $display("  E1/E2: %0d modified bytes, %0d bytes covered by permitted writes, canary violations %0d, lost writes %0d", nb, nl, bad1, bad2);
      checks++;
    end
    // E3: counters
    tot_den = 0; tot_mem = 0;
    for (int p = 0; p < NP; p++) begin tot_den += n_den[p]; tot_mem += n_mem[p]; end
    if (!reset_seen) begin
      cnt_chk("E3 CN_FAULTS = denied responses", CN_FAULTS, tot_den);
      cnt_chk("E3 CN_FWD = memory-side transactions", CN_FWD, tot_mem);
      for (int p = 0; p < NP; p++) begin cnt_chk($sformatf("E3 port %0d forwarded", p), cn_pfwd(p), n_mem[p]); cnt_chk($sformatf("E3 port %0d faults", p), cn_pflt(NP, p), n_den[p]); end
      for (int f = 0; f < 16; f++) cnt_chk($sformatf("E3 fault type %0d", f), cn_ft(NP, f), n_ftype[f]);
      cnt_chk("E3 CN_COMMIT = commits", CN_COMMIT, commits_seen);
      cnt_chk("E3 CN_CMDREJ = refused commands", CN_CMDREJ, n_cmd_ref);
      cnt_chk("E3 CN_SEC = unprivileged attempts", CN_SEC, n_unpriv);
      cnt_chk("E3 CN_ORPHAN", CN_ORPHAN, 0);
      cnt_chk("E3 CN_TMO", CN_TMO, 0);
      begin
        bit [31:0] fc, dr; crd_t(R_FLOG_CNT, fc);
        cnt_get(CN_FDROP, dr);
        expect_eq("E3 faults = popped + held + dropped", tot_den, n_popped + fc[7:0] + dr);
        expect_eq("E3 R_FLOG_CNT dropped field = CN_FDROP (16-bit saturating)", fc[31:16], (dr > 32'hFFFF) ? 32'hFFFF : dr);
      end
      rchk("E3 policy generation = commits", R_GEN, commits_seen);
    end
    // E4: coverage
    begin
      int miss = 0;
      for (int f = 1; f <= 10; f++) if (n_ftype[f] == 0) begin
        if (f == FT_SPAN && DIAG_PRECISE == 0) continue;                    // not produced by construction
        if (f == FT_BADDOM && ND == (1 << DOMW)) continue;                  // every encoding is a valid domain
        miss++; fail($sformatf("E4 coverage: fault class %0d was never produced", f));
      end
      checks++;
      $display("  stimulus: issued %0d/%0d/%0d/%0d  permitted rd %0d wr %0d  denied %0d  commits %0d refused %0d unpriv %0d (commits with traffic in flight: %0d) popped %0d resets %0d",
               n_issued[0], n_issued[1 % NP], n_issued[2 % NP], n_issued[3 % NP], n_perm_rd, n_perm_wr, tot_den, commits_seen, n_cmd_ref, n_unpriv, n_commit_busy, n_popped, n_resets);
      $display("  fault classes: NOMAP %0d PERM %0d SPAN %0d OVF %0d ZERO %0d BADOP %0d BADDOM %0d SPOOF %0d DEVICE %0d BADLEN %0d",
               n_ftype[1], n_ftype[2], n_ftype[3], n_ftype[4], n_ftype[5], n_ftype[6], n_ftype[7], n_ftype[8], n_ftype[9], n_ftype[10]);
      if (n_commit_busy == 0) fail("E4 coverage: no command was committed while traffic was in flight");
      checks++;
    end
    expect_eq("monitor violations (M1/M2/M3/PROTO)", mon_viol, 0);
    $display("tb_mg_random: %0d checks, %0d errors", checks, errors);
    if (errors == 0) $display("TB_RESULT: PASS tb_mg_random SEED=%0d ND=%0d NR=%0d NP=%0d CHK_PIPE=%0d LOOKUP_ARCH=%0d STRICT=%0d LEN_POW2=%0d DIAG_PRECISE=%0d MIDRESET=%0d", SEED, ND, NR, NP, CHK_PIPE, LOOKUP_ARCH, STRICT, LEN_POW2, DIAG_PRECISE, MIDRESET);
    else             $display("TB_RESULT: FAIL tb_mg_random errors=%0d SEED=%0d", errors, SEED);
    $finish;
  end

  initial begin
    #2000000000;
    $display("TB_RESULT: FAIL tb_mg_random TIMEOUT");
    $finish;
  end
endmodule
