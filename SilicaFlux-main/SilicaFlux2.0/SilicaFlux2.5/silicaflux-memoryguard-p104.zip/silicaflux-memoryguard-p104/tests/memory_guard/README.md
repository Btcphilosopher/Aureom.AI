# tests/memory_guard — simulation verification

Run: `make regress` (everything) or `scripts/run_sim.sh tests/memory_guard/<tb>.sv out/x [-Gparam=value]`. Verilator 5.020, `--binary --timing`.
A run **passes iff its log contains `TB_RESULT: PASS`**. Results: `reports/regression.md`.

| file | what it is |
|---|---|
| `tb_common.svh` | the verification environment shared by the system testbenches (below) |
| `tb_mg_directed.sv` | directed tests T01–T19 (reset state, allowed / denied reads and writes, domains, boundary sweep, overflow, privilege, lock, **mid-flight policy change**, reset, invalid requests, fault logging, device permissions, orphan response, memory error) |
| `tb_mg_random.sv` | adversarial random: 4 ports hammer the guard while a background agent reconfigures it; random ready / latency; end-to-end canary image check; counter tallies; coverage of every fault class. `+define+MG_EXT_MEM` puts the **real MemoryMatrix** behind it |
| `tb_checker_vec.sv` + `gen_vectors.py` | the checker (both lookup architectures, every port) against an **independent Python model** (arbitrary-precision integers), up to 240 000 boundary-biased queries per run, fault codes included |
| `tb_mg_adapters.sv` | the two check-only adapters against the oracle (in-order registered verdicts, fault mapping, `pa = addr`) |
| `tb_abi_check.sv` | shared constants equal the vendored P102 package |
| `tb_mg_bench.sv` | throughput / latency bench (used by `benchmarks/memory_guard/run_bench.py`) |

## The environment (`tb_common.svh`)

* **Oracle** — an independent behavioural model of the policy (64-bit arithmetic, one loop over every region, no code shared with the RTL), plus an independent re-implementation of command validation. It gives the expected status of every accepted request.
* **Memory model** — one shared byte array, per-port in-order memory with random latency / ready; or the real MemoryMatrix.
* **Monitors** — M1 every memory-side transaction is permitted by the oracle's policy *at that cycle* (a stale verdict = TOCTOU fails here) · M2 every memory-side transaction is exactly the next accepted-and-permitted request of that port (nothing injected, nothing altered, byte enables clipped) · M3 every memory-side wire is 0 unless `m_valid` · M4 every accepted request gets one in-order response with the expected status and id, no data on an error · M5 no port is ready while ingress is blocked · M6 every commit finds the datapath empty and blocked.
* **Driving discipline** — testbench processes change inputs 1 ns after a clock edge and sample 9 ns after it; the always-blocks use non-blocking assignments.

## Adversarial stimulus

Requests are generated from the *current policy*: inside a permitted region; at every region edge (`base-1, base, end-len, end-len+1, end` ± 1 beat); at the top of the address space and across the wrap; with spoofed and invalid domain claims; with zero / oversize lengths and unsupported operations; as garbage. The background agent installs overlapping / adjacent / wrapping / out-of-range regions, bad indices, unknown commands, rebinding, `CLEAR_ALL`, device masks, makes unprivileged attempts, drains the fault log and reads every register — **while the traffic runs**, so most commits happen with requests in flight (`commits with traffic in flight` in the log).

## Tool notes (recorded because they cost time)

* Verilator 5.020 mis-handles an unpacked array of queues whose size is not a power of two (`fwd_q[NP][$]` with `NP = 3`): entries come back zeroed. The testbench pads the array to a power of two (`NPQ`).
* Non-blocking assignments inside tasks called from `initial` execute as blocking ones in Verilator, and a function cannot call a task: hence the `tick()` driving discipline and the `rchk` / `cnt_chk` helper tasks.
* Yosys 0.33 has no `import pkg::*;` — see `scripts/alias_pkg.py`.
