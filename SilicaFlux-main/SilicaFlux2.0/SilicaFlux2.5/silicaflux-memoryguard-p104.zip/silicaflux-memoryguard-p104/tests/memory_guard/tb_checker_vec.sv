// =============================================================================
// Vector test of sf_memory_guard_checker against the INDEPENDENT Python model (gen_vectors.py).
// Both lookup architectures of every port's checker are driven with the same table and every query; permit AND the fault code must
// equal the Python model's.  Parameters must match the vector header (checked).  +vec=<file>
// =============================================================================
`timescale 1ns/1ps
module tb_checker_vec #(
  parameter int ND = 4, parameter int NR = 4, parameter int NP = 4, parameter int AW = 32, parameter int LW = 4, parameter int MAXLEN = 8,
  parameter int LEN_POW2 = 0, parameter int DIAG = 1, parameter int DOMW = 3
);
  localparam int NE = ND * NR;
  logic [NE-1:0]        t_valid, t_r, t_w, t_devn;
  logic [NE*AW-1:0]     t_base;
  logic [NE*(AW+1)-1:0] t_end;
  logic [NE*NP-1:0]     t_dev;
  logic [ND-1:0]        allow [NP];
  logic [1:0]           op;
  logic [AW-1:0]        addr;
  logic [LW-1:0]        len;
  logic [DOMW-1:0]      dom;
  logic [NP-1:0]        permit0, permit1;
  logic [4*NP-1:0]      fault0, fault1;

  genvar g;
  generate for (g = 0; g < NP; g++) begin : g_chk
    logic [DOMW-1:0] e0, e1;
    sf_memory_guard_checker #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .LW(LW), .DOMW(DOMW), .PIDX(g), .MAXLEN(MAXLEN), .LEN_POW2(LEN_POW2),
                              .LOOKUP_ARCH(0), .DIAG_PRECISE(DIAG)) u0 (
      .c_op(op), .c_addr(addr), .c_len(len), .c_dom(dom), .allow(allow[g]), .t_valid(t_valid), .t_base(t_base), .t_end(t_end), .t_r(t_r),
      .t_w(t_w), .t_devn(t_devn), .t_dev(t_dev), .permit(permit0[g]), .fault(fault0[4*g +: 4]), .edom(e0));
    sf_memory_guard_checker #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .LW(LW), .DOMW(DOMW), .PIDX(g), .MAXLEN(MAXLEN), .LEN_POW2(LEN_POW2),
                              .LOOKUP_ARCH(1), .DIAG_PRECISE(DIAG)) u1 (
      .c_op(op), .c_addr(addr), .c_len(len), .c_dom(dom), .allow(allow[g]), .t_valid(t_valid), .t_base(t_base), .t_end(t_end), .t_r(t_r),
      .t_w(t_w), .t_devn(t_devn), .t_dev(t_dev), .permit(permit1[g]), .fault(fault1[4*g +: 4]), .edom(e1));
  end endgenerate

  integer fd, rc, errors, nq, ntab;
  string  tag, path;
  initial begin
    int unsigned c_nd, c_nr, c_np, c_aw, c_lw, c_maxlen, c_pow2, c_diag;
    int unsigned d, i, p, o, l, dm, ep, ef, r, w, dn, dmask; logic [63:0] b, e, a, al;
    errors = 0; nq = 0; ntab = 0;
    if (!$value$plusargs("vec=%s", path)) begin $display("TB_RESULT: FAIL tb_checker_vec (no +vec=)"); $finish; end
    fd = $fopen(path, "r");
    if (fd == 0) begin $display("TB_RESULT: FAIL tb_checker_vec (cannot open %s)", path); $finish; end
    t_valid = '0; t_r = '0; t_w = '0; t_devn = '0; t_base = '0; t_end = '0; t_dev = '0;
    for (int k = 0; k < NP; k++) allow[k] = '0;
    op = 0; addr = 0; len = 1; dom = 0;
    while (!$feof(fd)) begin
      rc = $fscanf(fd, "%s", tag);
      if (rc != 1) break;
      if (tag == "C") begin
        rc = $fscanf(fd, "%d %d %d %d %d %d %d %d\n", c_nd, c_nr, c_np, c_aw, c_lw, c_maxlen, c_pow2, c_diag);
        if (c_nd != ND || c_nr != NR || c_np != NP || c_aw != AW || c_lw != LW || c_maxlen != MAXLEN || c_pow2 != LEN_POW2 || c_diag != DIAG) begin
          $display("TB_RESULT: FAIL tb_checker_vec (vector header does not match the parameters)"); $finish;
        end
      end else if (tag == "X") begin
        t_valid = '0; t_r = '0; t_w = '0; t_devn = '0; t_base = '0; t_end = '0; t_dev = '0;
        for (int k = 0; k < NP; k++) allow[k] = '0;
        ntab++;
      end else if (tag == "T") begin
        rc = $fscanf(fd, "%d %d %h %h %d %d %d %h\n", d, i, b, e, r, w, dn, dmask);
        t_valid[d*NR + i] = 1'b1; t_base[(d*NR + i)*AW +: AW] = b[AW-1:0]; t_end[(d*NR + i)*(AW+1) +: (AW+1)] = e[AW:0];
        t_r[d*NR + i] = r[0]; t_w[d*NR + i] = w[0]; t_devn[d*NR + i] = dn[0]; t_dev[(d*NR + i)*NP +: NP] = dmask[NP-1:0];
      end else if (tag == "A") begin
        rc = $fscanf(fd, "%d %h\n", p, al);
        allow[p] = al[ND-1:0];
      end else if (tag == "Q") begin
        rc = $fscanf(fd, "%d %d %h %d %d %d %d\n", p, o, a, l, dm, ep, ef);
        op = o[1:0]; addr = a[AW-1:0]; len = l[LW-1:0]; dom = dm[DOMW-1:0];
        #1;
        nq++;
        if (permit0[p] !== ep[0] || fault0[4*p +: 4] !== ef[3:0] || permit1[p] !== ep[0] || fault1[4*p +: 4] !== ef[3:0]) begin
          errors++;
          if (errors < 20) $display("MISMATCH table %0d port %0d op %0d addr %0h len %0d dom %0d: RTL arch0 %0d/%0d arch1 %0d/%0d, Python %0d/%0d", ntab, p, o, a, l, dm,
                                    permit0[p], fault0[4*p +: 4], permit1[p], fault1[4*p +: 4], ep, ef);
        end
      end
    end
    $fclose(fd);
    $display("tb_checker_vec: %0d tables, %0d queries, %0d mismatches", ntab, nq, errors);
    if (errors == 0 && nq > 0) $display("TB_RESULT: PASS tb_checker_vec ND=%0d NR=%0d NP=%0d AW=%0d MAXLEN=%0d LEN_POW2=%0d DIAG=%0d queries=%0d", ND, NR, NP, AW, MAXLEN, LEN_POW2, DIAG, nq);
    else $display("TB_RESULT: FAIL tb_checker_vec mismatches=%0d", errors);
    $finish;
  end
endmodule
