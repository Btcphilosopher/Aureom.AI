// =============================================================================
// MemoryGuard verification environment, shared by tb_mg_directed.sv and tb_mg_random.sv (`include d inside the module body).
//
//   DUT                  sf_memory_guard, parameters from the including module
//   reference model     an INDEPENDENT behavioural model of the policy: wide (64-bit) arithmetic, a loop over every region, no
//                        shared code with the RTL.  It is the oracle for the expected status of every accepted request and for
//                        what the memory side may legally see.  It also re-implements command validation.
//   memory model         one shared byte array, per-port in-order memory with random latency / back-pressure; writes happen at
//                        the cycle the request is accepted on the memory side
//   monitors             M1  every memory-side transaction is permitted by the reference policy AT THAT CYCLE (TOCTOU check)
//                        M2  every memory-side transaction is exactly the next accepted-and-permitted request of that port
//                            (nothing injected, nothing altered: the "no alternate path / no bypass" check, end to end)
//                        M3  a denied request never causes any memory-side activity (implied by M2, also counted)
//                        M4  a response for every accepted request, in order, with the expected status, id and rdata == 0 on errors
//   cfg tasks            privileged / unprivileged register access, commands with an expected outcome from the reference model
// =============================================================================
  import sf_memory_guard_pkg::*;

  localparam int BW     = DW / 8;
  localparam int LW     = $clog2(BW + 1);
  localparam int NE     = ND * NR;
  localparam int MAXLEN = BW;
  localparam longint unsigned SPACE = 64'd1 << AW;
  int ref_maxlen = MAXLEN;                // the oracle's largest legal length (the IOMMU-contract adapter test raises it to 4096)

  // ------------------------------------------------------------------ clock, reset
  logic clk = 1'b0;
  logic rst_n;
  always #5 clk = ~clk;

  int errors = 0;
  int checks = 0;
  task automatic fail(input string msg);
    begin errors++; $display("[%0t] FAIL: %s", $time, msg); end
  endtask
  task automatic expect_eq(input string what, input longint unsigned got, input longint unsigned exp);
    begin
      checks++;
      if (got !== exp) begin errors++; $display("[%0t] FAIL: %s: got 0x%0h expected 0x%0h", $time, what, got, exp); end
    end
  endtask

  // ------------------------------------------------------------------ DUT
  logic [NP-1:0]        r_valid, r_ready, s_valid, s_ready, s_we, m_valid, m_ready, m_we, d_valid, d_ready, d_we, d_err;
  logic [NP*2-1:0]      r_op;
  logic [NP*AW-1:0]     r_addr, m_addr;
  logic [NP*LW-1:0]     r_len, m_len;
  logic [NP*DW-1:0]     r_wdata, s_rdata, m_wdata, d_rdata;
  logic [NP*BW-1:0]     r_be, m_be;
  logic [NP*IDW-1:0]    r_id, s_id, m_id, d_id;
  logic [NP*DOMW-1:0]   r_dom, m_dom;
  logic [NP*3-1:0]      s_status;
  logic                 cfg_req_valid, cfg_req_ready, cfg_req_write, cfg_req_priv, cfg_rsp_valid, cfg_rsp_ready, cfg_rsp_error;
  logic [7:0]           cfg_req_addr;
  logic [31:0]          cfg_req_wdata, cfg_rsp_rdata;
  logic [3:0]           cfg_req_wstrb;
  logic                 idle_o, blocking_o;

  sf_memory_guard #(.ND(ND), .NR(NR), .NP(NP), .AW(AW), .DW(DW), .IDW(IDW), .DOMW(DOMW), .MAXOUT(MAXOUT), .CHK_PIPE(CHK_PIPE),
                    .LOOKUP_ARCH(LOOKUP_ARCH), .DIAG_PRECISE(DIAG_PRECISE), .STRICT(STRICT), .LEN_POW2(LEN_POW2),
                    .FLOG_DEPTH(FLOG_DEPTH)) dut (
    .clk(clk), .rst_n(rst_n),
    .r_valid(r_valid), .r_ready(r_ready), .r_op(r_op), .r_addr(r_addr), .r_len(r_len), .r_wdata(r_wdata), .r_be(r_be),
    .r_id(r_id), .r_dom(r_dom), .s_valid(s_valid), .s_ready(s_ready), .s_rdata(s_rdata), .s_id(s_id), .s_we(s_we),
    .s_status(s_status), .m_valid(m_valid), .m_ready(m_ready), .m_we(m_we), .m_addr(m_addr), .m_len(m_len), .m_wdata(m_wdata),
    .m_be(m_be), .m_id(m_id), .m_dom(m_dom), .d_valid(d_valid), .d_ready(d_ready), .d_rdata(d_rdata), .d_id(d_id),
    .d_we(d_we), .d_err(d_err),
    .cfg_req_valid(cfg_req_valid), .cfg_req_ready(cfg_req_ready), .cfg_req_write(cfg_req_write), .cfg_req_addr(cfg_req_addr),
    .cfg_req_wdata(cfg_req_wdata), .cfg_req_wstrb(cfg_req_wstrb), .cfg_req_priv(cfg_req_priv),
    .cfg_rsp_valid(cfg_rsp_valid), .cfg_rsp_ready(cfg_rsp_ready), .cfg_rsp_rdata(cfg_rsp_rdata), .cfg_rsp_error(cfg_rsp_error),
    .idle_o(idle_o), .blocking_o(blocking_o));

  // ------------------------------------------------------------------ reference model: policy state
  bit                    rv  [ND][NR];
  longint unsigned       rb  [ND][NR];
  longint unsigned       re  [ND][NR];
  bit                    rr_ [ND][NR];
  bit                    rw_ [ND][NR];
  bit                    rdn [ND][NR];
  bit [7:0]              rdv [ND][NR];
  bit [15:0]             rallow [NP];
  int unsigned           ref_gen = 0;

  task automatic ref_reset();
    begin
      for (int d = 0; d < ND; d++) for (int i = 0; i < NR; i++) begin rv[d][i] = 0; rb[d][i] = 0; re[d][i] = 0; end
      for (int p = 0; p < NP; p++) rallow[p] = 16'd0;
      ref_gen = 0;
    end
  endtask

  // the oracle: returns the native fault code (0 = permit).  No code shared with the RTL.
  function automatic int ref_check(input int p, input int op, input longint unsigned addr, input int len, input int dom);
    bit any_perm, any_cont, any_cont_dev, any_ovl;
    longint unsigned e;
    begin
      if (op != 0 && op != 1)                         return FT_BADOP;
      if (len == 0)                                   return FT_ZEROLEN;
      if (len > ref_maxlen)                           return FT_BADLEN;
      if (LEN_POW2 != 0 && (len & (len - 1)) != 0)    return FT_BADLEN;
      e = addr + len;
      if (e > SPACE)                                  return FT_OVERFLOW;
      if (dom >= ND)                                  return FT_BADDOM;
      if (!rallow[p][dom])                            return FT_SPOOF;
      any_perm = 0; any_cont = 0; any_cont_dev = 0; any_ovl = 0;
      for (int i = 0; i < NR; i++) begin
        if (rv[dom][i]) begin
          if (addr >= rb[dom][i] && e <= re[dom][i]) begin
            any_cont = 1;
            if (!rdn[dom][i] || rdv[dom][i][p]) begin
              any_cont_dev = 1;
              if (op == 1 ? rw_[dom][i] : rr_[dom][i]) any_perm = 1;
            end
          end else if (addr < re[dom][i] && rb[dom][i] < e) any_ovl = 1;
        end
      end
      if (any_perm)                       return FT_NONE;
      if (any_cont && !any_cont_dev)      return FT_DEVICE;
      if (any_cont)                       return FT_PERM;
      if (any_ovl && DIAG_PRECISE != 0)   return FT_SPAN;
      return FT_NOMAP;
    end
  endfunction

  function automatic bit ref_is_proto(input int f);
    begin ref_is_proto = (f == FT_OVERFLOW || f == FT_ZEROLEN || f == FT_BADOP || f == FT_BADDOM || f == FT_BADLEN); end
  endfunction

  // command validation (re-implementation).  Returns the CE_* code the DUT must report; applies the command when apply != 0.
  function automatic int ref_cmd(input int kind, input int dom, input int idx, input int port, input longint unsigned base,
                                 input longint unsigned size, input bit r, input bit w, input bit devn, input int dev,
                                 input int allow, input bit apply);
    longint unsigned e;
    begin
      ref_cmd = CE_CMD;
      case (kind)
        CMD_SET_REGION: begin
          e = base + size;
          if (dom >= ND || idx >= NR || (NP < 8 && (dev >> NP) != 0)) ref_cmd = CE_INDEX;
          else if (size == 0 || base >= SPACE || e > SPACE)            ref_cmd = CE_RANGE;
          else begin
            ref_cmd = CE_OK;
            for (int d = 0; d < ND; d++) for (int i = 0; i < NR; i++)
              if (rv[d][i] && !(d == dom && i == idx) && (d == dom || STRICT != 0) && base < re[d][i] && rb[d][i] < e) ref_cmd = CE_OVERLAP;
            if (ref_cmd == CE_OK && apply) begin
              rv[dom][idx] = 1; rb[dom][idx] = base; re[dom][idx] = e; rr_[dom][idx] = r; rw_[dom][idx] = w; rdn[dom][idx] = devn;
              rdv[dom][idx] = 8'(dev);
            end
          end
        end
        CMD_CLR_REGION: begin
          if (dom >= ND || idx >= NR) ref_cmd = CE_INDEX;
          else begin ref_cmd = CE_OK; if (apply) rv[dom][idx] = 0; end
        end
        CMD_BIND_PORT: begin
          if (port >= NP || (ND < 16 && (allow >> ND) != 0)) ref_cmd = CE_INDEX;
          else begin ref_cmd = CE_OK; if (apply) rallow[port] = 16'(allow); end
        end
        CMD_CLEAR_ALL: begin
          ref_cmd = CE_OK;
          if (apply) for (int d = 0; d < ND; d++) for (int i = 0; i < NR; i++) rv[d][i] = 0;
        end
        default: ref_cmd = CE_CMD;
      endcase
    end
  endfunction

  // ------------------------------------------------------------------ memory model
  localparam int MEMSZ = (AW <= 16) ? (1 << AW) : (1 << 16);          // the TB only addresses the low 64 KiB
  logic [7:0] mem [MEMSZ];
  int unsigned mem_lat_min = 1, mem_lat_max = 3;
  int unsigned m_ready_pct = 100, s_ready_pct = 100;
  longint unsigned err_addr = 64'hFFFF_FFFF_FFFF_FFFF;               // a permitted request to this address gets SLVERR
  bit          orph_req [NP];                                         // inject an orphan memory response on port p
  bit          mem_freeze;                                            // memory stops answering (stall test)

  typedef struct {
    bit we; longint unsigned addr; int len; bit [DW-1:0] wdata; bit [BW-1:0] be; bit [IDW-1:0] id; int dom;
  } req_t;
  typedef struct {
    bit we; bit [IDW-1:0] id; bit [DW-1:0] rdata; bit err; longint unsigned t_ready;
  } mrsp_t;
  typedef struct {
    bit [IDW-1:0] id; bit we; int exp_status; int exp_fault; int port; int dom; longint unsigned addr; int len; int op; bit [DW-1:0] wdata; longint unsigned t_acc;
  } exp_t;

  localparam int NPQ = (NP > 1) ? (1 << $clog2(NP)) : 1;     // (Verilator 5.020 mis-handles arrays of queues whose size is not a power of two)
  req_t   fwd_q  [NPQ][$];       // accepted by the guard and PERMITTED by the oracle: what the memory side may see, in order
  mrsp_t  mrsp_q [NPQ][$];       // memory responses in flight
  exp_t   exp_q  [NPQ][$];       // expected requester responses
  longint unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  // observed statistics
  longint unsigned n_acc [NP], n_mem [NP], n_rsp [NP], n_den [NP], n_fault_exp [NP];
  longint unsigned n_ftype [16];
  int  last_status [NP]; bit [DW-1:0] last_rdata [NP]; bit [IDW-1:0] last_id [NP]; bit last_we [NP];
  longint unsigned rsp_cnt [NP];
  longint unsigned lat_sum [NP], lat_n [NP], lat_max [NP];     // accept-edge to response-handshake-edge, in cycles, per port
  int  mon_viol = 0;                                                   // M1 / M2 violations (also counted in errors)

  // request monitor: at every accept compute the expected result from the oracle
  always @(posedge clk) begin
    if (rst_n) for (int p = 0; p < NP; p++) begin
      if (r_valid[p] && r_ready[p]) begin
        exp_t e; req_t q;
        int op, len, dom; longint unsigned addr; int f;
        op = int'(r_op[p*2 +: 2]); len = int'(r_len[p*LW +: LW]); dom = int'(r_dom[p*DOMW +: DOMW]); addr = longint'(r_addr[p*AW +: AW]);
        f = ref_check(p, op, addr, len, dom);
        e.id = r_id[p*IDW +: IDW]; e.we = (op == 1); e.exp_fault = f; e.port = p; e.dom = dom; e.addr = addr; e.len = len; e.op = op;
        e.wdata = r_wdata[p*DW +: DW]; e.t_acc = cyc;
        if (f == FT_NONE) begin
          e.exp_status = (addr == err_addr) ? 1 : 0;
          q.we = (op == 1); q.addr = addr; q.len = len; q.wdata = r_wdata[p*DW +: DW]; q.be = r_be[p*BW +: BW]; q.id = r_id[p*IDW +: IDW]; q.dom = dom;
          fwd_q[p].push_back(q);
        end else begin
          e.exp_status = ref_is_proto(f) ? 5 : 3;
          n_den[p]++; n_ftype[f]++;
        end
        exp_q[p].push_back(e);
        n_acc[p]++;
      end
    end
  end

  // ------------------------------------------------------------------ memory side: monitors M1/M2/M3 and the memory itself
  // ONE process, explicit order per port: (1) response handshake, (2) memory-side request accept, (3) drive next cycle.
  bit          pv_valid [NP];                       // protocol monitor: previous cycle presented but not accepted
  bit [AW+LW+DW+BW+IDW+DOMW:0] pv_pay [NP];
  always @(posedge clk) begin
    if (!rst_n) begin
      for (int p = 0; p < NP; p++) begin
        mrsp_q[p].delete(); fwd_q[p].delete(); exp_q[p].delete(); pv_valid[p] = 0;
`ifndef MG_EXT_MEM
        d_valid[p] <= 1'b0;
        m_ready[p] <= (($urandom % 100) < m_ready_pct);
`endif
        s_ready[p] <= (($urandom % 100) < s_ready_pct);
      end
    end else begin
      for (int p = 0; p < NP; p++) begin
        // (1) memory response handshake
        if (d_valid[p] && d_ready[p] && mrsp_q[p].size() > 0) void'(mrsp_q[p].pop_front());
        // M3: the memory side carries NOTHING unless m_valid (a denied request never drives address / data / id / domain)
        if (!m_valid[p] && (m_we[p] || m_addr[p*AW +: AW] !== '0 || m_len[p*LW +: LW] !== '0 || m_wdata[p*DW +: DW] !== '0 ||
                            m_be[p*BW +: BW] !== '0 || m_id[p*IDW +: IDW] !== '0 || m_dom[p*DOMW +: DOMW] !== '0)) begin
          mon_viol++; fail($sformatf("M3 port %0d: memory-side wires are not zero while m_valid = 0", p));
        end
        // protocol: a presented memory request is held, unchanged, until accepted
        begin
          bit [AW+LW+DW+BW+IDW+DOMW:0] pay;
          pay = {m_we[p], m_addr[p*AW +: AW], m_len[p*LW +: LW], m_wdata[p*DW +: DW], m_be[p*BW +: BW], m_id[p*IDW +: IDW], m_dom[p*DOMW +: DOMW]};
          if (pv_valid[p] && (!m_valid[p] || pay !== pv_pay[p])) begin mon_viol++; fail($sformatf("PROTO port %0d: m_valid / payload changed before the memory accepted it", p)); end
          pv_valid[p] = m_valid[p] && !m_ready[p];
          pv_pay[p]   = pay;
        end
        // (2) memory request accepted
        if (m_valid[p] && m_ready[p]) begin
          req_t q; longint unsigned a; int l; bit w; int f; mrsp_t r; int dm;
          a = longint'(m_addr[p*AW +: AW]); l = int'(m_len[p*LW +: LW]); w = m_we[p]; dm = int'(m_dom[p*DOMW +: DOMW]);
          n_mem[p]++;
          // M1: permitted by the oracle's CURRENT policy (a request checked under an older policy fails here: TOCTOU)
          f = ref_check(p, w ? 1 : 0, a, l, dm);
          if (f != FT_NONE) begin mon_viol++; fail($sformatf("M1 port %0d: memory-side %s addr 0x%0h len %0d dom %0d is NOT permitted by the policy (fault %0d)", p, w ? "WRITE" : "READ", a, l, dm, f)); end
          // M2: exactly the next permitted request of this port
          if (fwd_q[p].size() == 0) begin mon_viol++; fail($sformatf("M2 port %0d: memory-side transaction with no accepted+permitted request", p)); end
          else begin
            q = fwd_q[p].pop_front();
            if (q.we !== w || q.addr !== a || q.len !== l || q.id !== m_id[p*IDW +: IDW] || q.dom !== dm) begin
              mon_viol++; fail($sformatf("M2 port %0d: memory-side request differs from the accepted one (addr %0h/%0h len %0d/%0d we %0d/%0d dom %0d/%0d)", p, q.addr, a, q.len, l, q.we, w, q.dom, dm));
            end
            if (w) begin
              bit [BW-1:0] exp_be;
              for (int j = 0; j < BW; j++) exp_be[j] = q.be[j] && (j < q.len);
              if (m_be[p*BW +: BW] !== exp_be) begin mon_viol++; fail($sformatf("M2 port %0d: byte enables %0h, expected %0h (clipped to len)", p, m_be[p*BW +: BW], exp_be)); end
              for (int j = 0; j < BW; j++) if (exp_be[j] && m_wdata[p*DW + 8*j +: 8] !== q.wdata[8*j +: 8]) begin mon_viol++; fail($sformatf("M2 port %0d: write data lane %0d altered", p, j)); end
            end else begin
              if (m_be[p*BW +: BW] !== '0 || m_wdata[p*DW +: DW] !== '0) begin mon_viol++; fail($sformatf("M2 port %0d: a READ carries write data / byte enables", p)); end
            end
          end
`ifndef MG_EXT_MEM
          // the memory itself
          r.we = w; r.id = m_id[p*IDW +: IDW]; r.rdata = '0; r.err = (a == err_addr);
          if (w) begin
            if (!r.err) for (int j = 0; j < BW; j++) if (m_be[p*BW + j] && (a + j) < MEMSZ) mem[a + j] = m_wdata[p*DW + 8*j +: 8];
          end else begin
            for (int j = 0; j < BW; j++) if (j < l && (a + j) < MEMSZ) r.rdata[8*j +: 8] = mem[a + j];
          end
          r.t_ready = cyc + mem_lat_min + ($urandom % (mem_lat_max - mem_lat_min + 1));
          if (mrsp_q[p].size() > 0 && r.t_ready < mrsp_q[p][$].t_ready) r.t_ready = mrsp_q[p][$].t_ready;   // in order
          mrsp_q[p].push_back(r);
`endif
        end
        // (3) drive the next cycle: ready signals, then the head response if mature, else an orphan if one was requested
`ifdef MG_EXT_MEM
        s_ready[p] <= (($urandom % 100) < s_ready_pct);     // the memory side is the real MemoryMatrix (see the end of this file)
`else
        m_ready[p] <= (($urandom % 100) < m_ready_pct);
        s_ready[p] <= (($urandom % 100) < s_ready_pct);
        if (!mem_freeze && mrsp_q[p].size() > 0 && mrsp_q[p][0].t_ready <= cyc + 1) begin
          d_valid[p] <= 1'b1;
          d_rdata[p*DW +: DW] <= mrsp_q[p][0].rdata; d_id[p*IDW +: IDW] <= mrsp_q[p][0].id;
          d_we[p] <= mrsp_q[p][0].we; d_err[p] <= mrsp_q[p][0].err;
        end else if (mrsp_q[p].size() == 0 && orph_req[p]) begin
          d_valid[p] <= 1'b1; d_rdata[p*DW +: DW] <= {DW{1'b1}}; d_id[p*IDW +: IDW] <= '1; d_we[p] <= 1'b0; d_err[p] <= 1'b0;
          orph_req[p] = 1'b0;
        end else begin
          d_valid[p] <= 1'b0;
        end
`endif
      end
    end
  end

  // ------------------------------------------------------------------ M4: response scoreboard
  always @(posedge clk) begin
    if (rst_n) for (int p = 0; p < NP; p++) begin
      if (s_valid[p] && s_ready[p]) begin
        exp_t e;
        n_rsp[p]++; rsp_cnt[p]++;
        last_status[p] = int'(s_status[p*3 +: 3]); last_rdata[p] = s_rdata[p*DW +: DW]; last_id[p] = s_id[p*IDW +: IDW]; last_we[p] = s_we[p];
        if (exp_q[p].size() == 0) begin fail($sformatf("M4 port %0d: response with no outstanding request", p)); end
        else begin
          e = exp_q[p].pop_front();
          lat_sum[p] += (cyc - e.t_acc); lat_n[p]++; if ((cyc - e.t_acc) > lat_max[p]) lat_max[p] = cyc - e.t_acc;
          checks++;
          if (int'(s_status[p*3 +: 3]) != e.exp_status) fail($sformatf("M4 port %0d id %0h: status %0d expected %0d (op %0d addr 0x%0h len %0d dom %0d fault %0d)", p, e.id, int'(s_status[p*3 +: 3]), e.exp_status, e.op, e.addr, e.len, e.dom, e.exp_fault));
          if (s_id[p*IDW +: IDW] !== e.id) fail($sformatf("M4 port %0d: response id %0h expected %0h", p, s_id[p*IDW +: IDW], e.id));
          if (e.exp_status >= 3 && s_rdata[p*DW +: DW] !== '0) fail($sformatf("M4 port %0d: error response carries data %0h", p, s_rdata[p*DW +: DW]));
          if (e.exp_status >= 3 && s_we[p] !== e.we && e.op <= 1) fail($sformatf("M4 port %0d: error response we=%0d expected %0d", p, s_we[p], e.we));
        end
      end
    end
  end

  // ------------------------------------------------------------------ driving discipline
  // Testbench processes change DUT inputs 1 ns AFTER a clock edge (blocking assignments) and sample DUT outputs 9 ns after it, i.e.
  // just before the next edge: what they sample is exactly what the DUT sees at that edge.  The always-blocks above use NBAs.
  task automatic tick();
    begin @(posedge clk); #1; end
  endtask

  // ------------------------------------------------------------------ configuration tasks
  task automatic cfg_idle();
    begin cfg_req_valid = 1'b0; cfg_req_write = 1'b0; cfg_req_addr = 8'd0; cfg_req_wdata = 32'd0; cfg_req_wstrb = 4'hF; cfg_req_priv = 1'b0; cfg_rsp_ready = 1'b1; end
  endtask
  // one access by BYTE address; returns data and the error flag
  task automatic cfg_acc_b(input bit wr, input bit [7:0] baddr, input bit [31:0] wdata, input bit priv, input bit [3:0] wstrb, output bit [31:0] rdata, output bit err);
    int g;
    begin
      tick();
      cfg_req_valid = 1'b1; cfg_req_write = wr; cfg_req_addr = baddr; cfg_req_wdata = wdata; cfg_req_wstrb = wstrb; cfg_req_priv = priv; cfg_rsp_ready = 1'b1;
      #8; g = 0;
      while (!cfg_req_ready && g < 100000) begin tick(); #8; g++; end
      tick(); cfg_req_valid = 1'b0;                 // accepted at the edge just passed
      #8; g = 0;
      while (!cfg_rsp_valid && g < 100000) begin tick(); #8; g++; end
      rdata = cfg_rsp_rdata; err = cfg_rsp_error;
    end
  endtask
  task automatic cfg_acc(input bit wr, input int widx, input bit [31:0] wdata, input bit priv, input bit [3:0] wstrb, output bit [31:0] rdata, output bit err);
    begin cfg_acc_b(wr, 8'(widx * 4), wdata, priv, wstrb, rdata, err); end
  endtask
  task automatic cwr(input int widx, input bit [31:0] wdata, output bit err);       // privileged full-word write
    bit [31:0] d;
    begin cfg_acc(1'b1, widx, wdata, 1'b1, 4'hF, d, err); end
  endtask
  task automatic crd(input int widx, output bit [31:0] rdata, output bit err);      // privileged read
    begin cfg_acc(1'b0, widx, 32'd0, 1'b1, 4'hF, rdata, err); end
  endtask
  task automatic crd_t(input int widx, output bit [31:0] rdata);                   // privileged read, the error flag must be 0
    bit e;
    begin crd(widx, rdata, e); if (e) fail($sformatf("privileged read of register %0d returned an error", widx)); end
  endtask
  task automatic rchk(input string what, input int widx, input longint unsigned exp);              // register == exp
    bit [31:0] d;
    begin crd_t(widx, d); expect_eq(what, d, exp); end
  endtask
  task automatic rchkm(input string what, input int widx, input bit [31:0] mask, input longint unsigned exp);   // (register & mask) == exp
    bit [31:0] d;
    begin crd_t(widx, d); expect_eq(what, d & mask, exp); end
  endtask
  task automatic rchkb(input string what, input int widx, input int bitn, input longint unsigned exp);          // register[bit] == exp
    bit [31:0] d;
    begin crd_t(widx, d); expect_eq(what, (d >> bitn) & 32'd1, exp); end
  endtask
  task automatic cnt_get(input int idx, output bit [31:0] v);
    bit e; bit [31:0] d;
    begin cwr(R_CNT_SEL, 32'(idx), e); crd(R_CNT_DATA, d, e); v = d; end
  endtask
  task automatic cnt_chk(input string what, input int idx, input longint unsigned exp);
    bit [31:0] v;
    begin cnt_get(idx, v); expect_eq(what, v, exp); end
  endtask

  // wait until the command engine is idle
  task automatic wait_cfg_idle(input int tmo);
    bit [31:0] d; int n;
    begin
      n = 0; d = 32'd1;
      while (d[0] && n < tmo) begin crd_t(R_STATE, d); n++; end
      if (d[0]) fail("command engine still busy (timeout)");
    end
  endtask

  // ---- commands.  The oracle applies a command at the commit EVENT (the cycle the DUT writes its table), so that traffic that is
  // in flight while a command drains is judged against the right policy.  (dut.cm_en / dut.cm_ok are used only as that timing tag;
  // the content of the change comes from the oracle's own copy of the command.)
  typedef struct { bit v; int kind; int dom; int idx; int port; longint unsigned base; longint unsigned size; bit r; bit w; bit devn; int dev; int allow; } pcmd_t;
  pcmd_t pend;
  int    commits_seen = 0;
  bit    expect_refused = 1'b0;      // the next command is expected to be refused by the bus (e.g. under the lock)
  initial pend.v = 1'b0;
  always @(posedge clk) begin
    if (rst_n && dut.cm_en && dut.cm_ok) begin
      commits_seen++;
      if (!pend.v) fail("DUT committed a command that the TB did not issue / the oracle refused");
      else begin
        // M6: the table changes only with every port idle and ingress blocked, and nothing of the TB's is outstanding
        for (int p = 0; p < NP; p++) begin
          if (fwd_q[p].size() != 0 || mrsp_q[p].size() != 0 || exp_q[p].size() != 0)
            fail($sformatf("M6: commit while port %0d has work in flight (fwd %0d mem %0d exp %0d)", p, fwd_q[p].size(), mrsp_q[p].size(), exp_q[p].size()));
        end
        if (!idle_o || !blocking_o) fail("M6: commit while the datapath is not idle and blocked");
        void'(ref_cmd(pend.kind, pend.dom, pend.idx, pend.port, pend.base, pend.size, pend.r, pend.w, pend.devn, pend.dev, pend.allow, 1'b1));
        ref_gen++;
        pend.v = 1'b0;
      end
    end
    // M5: while ingress is blocked no port accepts anything
    if (rst_n && blocking_o && (r_ready !== '0)) fail("M5: a port is ready while ingress is blocked");
  end

  // stage + write R_CMD; returns the CE_* code the oracle expects; does not wait for the commit
  task automatic start_cmd(input int kind, input int dom, input int idx, input int port, input longint unsigned base, input longint unsigned size,
                           input bit r, input bit w, input bit devn, input int dev, input int allow, output int ce);
    bit err; bit [31:0] d; int exp_ce;
    begin
      cwr(R_SEL, {12'd0, 4'(port), 4'd0, 4'(idx), 4'd0, 4'(dom)}, err);
      cwr(R_BASE_LO, base[31:0], err); cwr(R_BASE_HI, base[63:32], err);
      cwr(R_SIZE_LO, size[31:0], err); cwr(R_SIZE_HI, size[63:32], err);
      cwr(R_ATTR, {16'd0, 8'(dev), 5'd0, devn, w, r}, err);
      cwr(R_ALLOW, 32'(allow), err);
      exp_ce = ref_cmd(kind, dom, idx, port, base, size, r, w, devn, dev, allow, 1'b0);
      if (expect_refused) exp_ce = CE_LOCKED;
      if (exp_ce == CE_OK) begin
        pend.v = 1'b1; pend.kind = kind; pend.dom = dom; pend.idx = idx; pend.port = port; pend.base = base; pend.size = size;
        pend.r = r; pend.w = w; pend.devn = devn; pend.dev = dev; pend.allow = allow;
      end
      cwr(R_CMD, 32'(kind), err);
      checks++;
      if ((exp_ce != CE_OK) != err) fail($sformatf("cmd kind %0d: bus error flag %0d but the oracle expects CE %0d", kind, err, exp_ce));
      if (exp_ce != CE_OK) begin
        crd_t(R_STATE, d);
        if (!expect_refused) expect_eq("R_STATE.last_err after a refused command", d[11:8], exp_ce);
        expect_eq("R_STATE.busy after a refused command", d[0], 0);
      end
      ce = exp_ce;
    end
  endtask

  // stage, command, wait for the commit, check generation / state
  task automatic do_cmd(input int kind, input int dom, input int idx, input int port, input longint unsigned base, input longint unsigned size,
                        input bit r, input bit w, input bit devn, input int dev, input int allow, output int ce);
    bit [31:0] d, gen0;
    begin
      crd_t(R_GEN, gen0);
      start_cmd(kind, dom, idx, port, base, size, r, w, devn, dev, allow, ce);
      if (ce == CE_OK) begin
        wait_cfg_idle(100000);
        crd_t(R_STATE, d);
        expect_eq("R_STATE.last_err after a commit", d[11:8], CE_OK);
        rchk("R_GEN after a commit", R_GEN, gen0 + 1);
      end else begin
        rchk("R_GEN after a refused command", R_GEN, gen0);
      end
    end
  endtask

  task automatic set_region(input int dom, input int idx, input longint unsigned base, input longint unsigned size, input bit r, input bit w,
                            input bit devn = 1'b0, input int dev = 0);
    int ce;
    begin do_cmd(CMD_SET_REGION, dom, idx, 0, base, size, r, w, devn, dev, 0, ce); if (ce != CE_OK) fail($sformatf("set_region(%0d,%0d,0x%0h,0x%0h) refused with CE %0d", dom, idx, base, size, ce)); end
  endtask
  task automatic clr_region(input int dom, input int idx);
    int ce;
    begin do_cmd(CMD_CLR_REGION, dom, idx, 0, 0, 0, 0, 0, 0, 0, 0, ce); end
  endtask
  task automatic bind_port(input int port, input int allow);
    int ce;
    begin do_cmd(CMD_BIND_PORT, 0, 0, port, 0, 0, 0, 0, 0, 0, allow, ce); if (ce != CE_OK) fail($sformatf("bind_port(%0d,0x%0h) refused with CE %0d", port, allow, ce)); end
  endtask

  // ------------------------------------------------------------------ request tasks (directed tests)
  task automatic drive_idle();
    begin
      r_valid = '0; r_op = '0; r_addr = '0; r_len = '0; r_wdata = '0; r_be = '0; r_id = '0; r_dom = '0;
    end
  endtask
  // present a request on port p and return once the guard has accepted it (the response is collected by the scoreboard)
  task automatic send_only(input int p, input int op, input longint unsigned addr, input int len, input int dom, input bit [IDW-1:0] id,
                           input bit [DW-1:0] wdata, input bit [BW-1:0] be);
    int g;
    begin
      tick();
      r_valid[p] = 1'b1; r_op[p*2 +: 2] = 2'(op); r_addr[p*AW +: AW] = AW'(addr); r_len[p*LW +: LW] = LW'(len);
      r_wdata[p*DW +: DW] = wdata; r_be[p*BW +: BW] = be; r_id[p*IDW +: IDW] = id; r_dom[p*DOMW +: DOMW] = DOMW'(dom);
      #8; g = 0;
      while (!r_ready[p] && g < 100000) begin tick(); #8; g++; end
      tick(); r_valid[p] = 1'b0;
    end
  endtask
  // one request on port p; returns when its response has been taken.  The oracle (request monitor + scoreboard) checks the status.
  bit [IDW-1:0] id_ctr = 0;
  task automatic xact(input int p, input int op, input longint unsigned addr, input int len, input int dom, input bit [DW-1:0] wdata, input bit [BW-1:0] be,
                      output int status, output bit [DW-1:0] rdata);
    longint unsigned c0; int guard; bit [IDW-1:0] my_id;
    begin
      id_ctr = id_ctr + 1; my_id = id_ctr;
      c0 = rsp_cnt[p];
      send_only(p, op, addr, len, dom, my_id, wdata, be);
      guard = 0;
      while (rsp_cnt[p] == c0 && guard < 100000) begin tick(); guard++; end
      if (rsp_cnt[p] == c0) fail($sformatf("port %0d: no response", p));
      status = last_status[p]; rdata = last_rdata[p];
    end
  endtask

  // helper: expected-status shortcut used by directed tests (the oracle also checks every response automatically)
  task automatic xact_expect(input string what, input int p, input int op, input longint unsigned addr, input int len, input int dom,
                             input bit [DW-1:0] wdata, input bit [BW-1:0] be, input int exp_status, output bit [DW-1:0] rdata);
    int st;
    begin
      xact(p, op, addr, len, dom, wdata, be, st, rdata);
      checks++;
      if (st != exp_status) fail($sformatf("%s: port %0d op %0d addr 0x%0h len %0d dom %0d: status %0d expected %0d", what, p, op, addr, len, dom, st, exp_status));
    end
  endtask

  task automatic quiesce();   // wait until nothing is held / outstanding
    int g;
    begin g = 0; repeat (4) tick(); while (!idle_o && g < 100000) begin tick(); g++; end if (!idle_o) fail("quiesce timeout"); end
  endtask

  task automatic do_reset(input int cycles = 4);
    begin
      tick(); rst_n = 1'b0; drive_idle(); cfg_idle();
      repeat (cycles) tick();
      ref_reset();
      for (int p = 0; p < NP; p++) begin exp_q[p].delete(); fwd_q[p].delete(); mrsp_q[p].delete(); end
      pend.v = 1'b0;
      rst_n = 1'b1;
      repeat (2) tick();
    end
  endtask

  task automatic mem_fill(input bit [7:0] v);
    begin for (int i = 0; i < MEMSZ; i++) mem[i] = v; end
  endtask
  function automatic bit [7:0] patt(input int p, input longint unsigned a);
    begin patt = 8'(8'h10 * (p + 1) ^ a[7:0] ^ a[15:8]); end
  endfunction

  initial begin
    rst_n = 1'b0; drive_idle(); cfg_idle();
    for (int p = 0; p < NP; p++) begin orph_req[p] = 0; lat_sum[p] = 0; lat_n[p] = 0; lat_max[p] = 0; n_acc[p] = 0; n_mem[p] = 0; n_rsp[p] = 0; n_den[p] = 0; rsp_cnt[p] = 0; end
    for (int f = 0; f < 16; f++) n_ftype[f] = 0;
    mem_freeze = 0;
    ref_reset();
    for (int i = 0; i < MEMSZ; i++) mem[i] = 8'hA5;
  end

`ifdef MG_EXT_MEM
  // ==================================================================== the REAL memory: MemoryMatrix (Project 101, vendored unmodified)
  // guard memory-side port p  ->  MemoryMatrix master p ;  master NP = the platform's own host port (not behind the guard), used to
  // fill the array with a canary and to dump it for the end-to-end image check.  The guard needs LEN_POW2 = 1: MemoryMatrix encodes the
  // size as log2(bytes).
  localparam int MMNM = NP + 1;
  localparam int SZ_MAX = $clog2(BW);
  localparam int SZW    = (SZ_MAX > 0) ? $clog2(SZ_MAX + 1) : 1;
  function automatic int lg2(input int n);
    begin lg2 = 0; while ((1 << lg2) < n) lg2++; end
  endfunction
  logic [MMNM-1:0]        mm_req_valid, mm_req_ready, mm_req_we, mm_rsp_valid, mm_rsp_ready, mm_rsp_we, mm_rsp_ce;
  logic [MMNM*AW-1:0]     mm_req_addr;
  logic [MMNM*SZW-1:0]    mm_req_size;
  logic [MMNM*DW-1:0]     mm_req_wdata, mm_rsp_rdata;
  logic [MMNM*BW-1:0]     mm_req_be;
  logic [MMNM*IDW-1:0]    mm_req_id, mm_rsp_id;
  logic [MMNM*2-1:0]      mm_req_prot;
  logic [MMNM*3-1:0]      mm_rsp_status;
  genvar gq;
  generate for (gq = 0; gq < NP; gq++) begin : g_mm_glue
    assign mm_req_valid[gq]            = m_valid[gq];
    assign mm_req_we[gq]               = m_we[gq];
    assign mm_req_addr[gq*AW +: AW]    = m_addr[gq*AW +: AW];
    assign mm_req_size[gq*SZW +: SZW]  = SZW'(lg2(int'(m_len[gq*LW +: LW])));
    assign mm_req_wdata[gq*DW +: DW]   = m_wdata[gq*DW +: DW];
    assign mm_req_be[gq*BW +: BW]      = m_be[gq*BW +: BW];
    assign mm_req_id[gq*IDW +: IDW]    = m_id[gq*IDW +: IDW];
    assign mm_req_prot[gq*2 +: 2]      = 2'b10;                 // {secure, priv}: the verified domain would select `secure` here
    assign m_ready[gq]                 = mm_req_ready[gq];
    assign d_valid[gq]                 = mm_rsp_valid[gq];
    assign d_rdata[gq*DW +: DW]        = mm_rsp_rdata[gq*DW +: DW];
    assign d_id[gq*IDW +: IDW]         = mm_rsp_id[gq*IDW +: IDW];
    assign d_we[gq]                    = mm_rsp_we[gq];
    assign d_err[gq]                   = (mm_rsp_status[gq*3 +: 3] != 3'd0);
    assign mm_rsp_ready[gq]            = d_ready[gq];
  end endgenerate
  // host master
  logic        h_valid = 1'b0, h_we = 1'b0; logic [AW-1:0] h_addr = '0; logic [DW-1:0] h_wdata = '0;
  assign mm_req_valid[NP] = h_valid; assign mm_req_we[NP] = h_we; assign mm_req_addr[NP*AW +: AW] = h_addr;
  assign mm_req_size[NP*SZW +: SZW] = SZW'(SZ_MAX); assign mm_req_wdata[NP*DW +: DW] = h_wdata; assign mm_req_be[NP*BW +: BW] = '1;
  assign mm_req_id[NP*IDW +: IDW] = '0; assign mm_req_prot[NP*2 +: 2] = 2'b11; assign mm_rsp_ready[NP] = 1'b1;
  logic [31:0] mm_perf_rej;
  sf_memory_matrix #(.NUM_BANKS(4), .BANK_DEPTH((1 << AW) / (4 * (64 / 8))), .WORD_WIDTH(64), .DATA_WIDTH(DW), .NUM_MASTERS(MMNM), .AW(AW), .IDW(IDW),
                     .ENABLE_ECC(MM_ECC), .NSLOT(8), .NUM_REGIONS(0)) u_mm (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(mm_req_valid), .m_req_ready(mm_req_ready), .m_req_we(mm_req_we), .m_req_addr(mm_req_addr), .m_req_size(mm_req_size),
    .m_req_wdata(mm_req_wdata), .m_req_be(mm_req_be), .m_req_id(mm_req_id), .m_req_prot(mm_req_prot),
    .m_rsp_valid(mm_rsp_valid), .m_rsp_ready(mm_rsp_ready), .m_rsp_rdata(mm_rsp_rdata), .m_rsp_id(mm_rsp_id), .m_rsp_we(mm_rsp_we),
    .m_rsp_status(mm_rsp_status), .m_rsp_ce(mm_rsp_ce),
    .rg_base_i('0), .rg_last_i('0), .rg_perm_i('0), .rg_mmask_i('0),
    .flush_i(1'b0), .flush_busy_o(), .quiesce_i(1'b0), .idle_o(), .init_start_i(1'b0), .init_busy_o(), .scrub_en_i(1'b0),
    .ecc_clr_i(1'b0), .ev_ce_o(), .ev_ue_o(), .ev_addr_o(), .ce_cnt_o(), .ue_cnt_o(),
    .perf_clr_i(1'b0), .perf_cycles_o(), .perf_acc_rd_o(), .perf_acc_wr_o(), .perf_conf_o(), .perf_lost_o(), .perf_busy_o(), .perf_mstall_o(),
    .perf_arbstall_o(), .perf_busystall_o(), .perf_selfconf_o(), .perf_starve_o(), .perf_starve_cls_o(), .perf_reqs_o(), .perf_bytes_rd_o(),
    .perf_bytes_wr_o(), .perf_lat_sum_o(), .perf_lat_cnt_o(), .perf_lat_max_o(), .perf_rej_o(mm_perf_rej),
    .trc_acc_o(), .trc_we_o(), .trc_m_o(), .trc_slot_o(), .trc_k_o());

  // host accesses (8-byte words), used while the guard ports are idle
  task automatic host_access(input bit wr, input longint unsigned a, input bit [DW-1:0] d, output bit [DW-1:0] q);
    int g;
    begin
      tick(); h_valid = 1'b1; h_we = wr; h_addr = AW'(a); h_wdata = d;
      #8; g = 0;
      while (!mm_req_ready[NP] && g < 100000) begin tick(); #8; g++; end
      tick(); h_valid = 1'b0;
      #8; g = 0;
      while (!mm_rsp_valid[NP] && g < 100000) begin tick(); #8; g++; end
      q = mm_rsp_rdata[NP*DW +: DW];
    end
  endtask
  task automatic host_fill(input bit [7:0] v);
    bit [DW-1:0] d, q;
    begin for (int j = 0; j < BW; j++) d[8*j +: 8] = v; for (longint unsigned a = 0; a < MEMSZ; a += BW) host_access(1'b1, a, d, q); end
  endtask
  task automatic host_dump();
    bit [DW-1:0] q;
    begin for (longint unsigned a = 0; a < MEMSZ; a += BW) begin host_access(1'b0, a, '0, q); for (int j = 0; j < BW; j++) mem[a + j] = q[8*j +: 8]; end end
  endtask
`endif
