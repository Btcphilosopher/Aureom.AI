// ABI equality check: the constants that MemoryGuard shares with Projects 83 / 102 (op codes, response status codes, fault code points that mean the
// same thing) must be numerically identical to the vendored, unmodified P102 package.  Fails (and prints) on any difference.
module tb_abi_check;
  int n = 0, bad = 0;
  task automatic chk(input string name, input int a, input int b);
    begin n++; if (a !== b) begin bad++; $display("ABI MISMATCH %s: MemoryGuard %0d, P102 %0d", name, a, b); end end
  endtask
  initial begin
    chk("OP_READ",    int'(sf_memory_guard_pkg::OP_READ),    int'(sf_meridian_qos_pkg::OP_READ));
    chk("OP_WRITE",   int'(sf_memory_guard_pkg::OP_WRITE),   int'(sf_meridian_qos_pkg::OP_WRITE));
    chk("ST_OKAY",    int'(sf_memory_guard_pkg::ST_OKAY),    int'(sf_meridian_qos_pkg::ST_OKAY));
    chk("ST_SLVERR",  int'(sf_memory_guard_pkg::ST_SLVERR),  int'(sf_meridian_qos_pkg::ST_SLVERR));
    chk("ST_DECERR",  int'(sf_memory_guard_pkg::ST_DECERR),  int'(sf_meridian_qos_pkg::ST_DECERR));
    chk("ST_DENIED",  int'(sf_memory_guard_pkg::ST_DENIED),  int'(sf_meridian_qos_pkg::ST_DENIED));
    chk("ST_TIMEOUT", int'(sf_memory_guard_pkg::ST_TIMEOUT), int'(sf_meridian_qos_pkg::ST_TIMEOUT));
    chk("ST_PROTO",   int'(sf_memory_guard_pkg::ST_PROTO),   int'(sf_meridian_qos_pkg::ST_PROTO));
    // fault code points that the grd_* adapter maps onto (P102 F_*): the adapter's hard-coded numbers must equal P102's constants
    chk("F_NOMAP",    1,  int'(sf_meridian_qos_pkg::F_NOMAP));
    chk("F_PERM",     2,  int'(sf_meridian_qos_pkg::F_PERM));
    chk("F_DOMAIN",   3,  int'(sf_meridian_qos_pkg::F_DOMAIN));
    chk("F_BADOP",    11, int'(sf_meridian_qos_pkg::F_BADOP));
    $display("tb_abi_check: %0d constants compared, %0d differ", n, bad);
    if (bad == 0) $display("TB_RESULT: PASS tb_abi_check"); else $display("TB_RESULT: FAIL tb_abi_check");
    $finish;
  end
endmodule
