# 07 — Fault reporting and diagnostics

## 1. What a requester learns

Only `s_status`: `OKAY`, `SLVERR` (the memory failed a *permitted* request), `DENIED`, or `PROTO`. **No reason.** In particular a tenant cannot learn from the response whether an
address it may not use is mapped for someone else, unmapped, or merely lacks a right: all are `DENIED`. `PROTO` is reserved for faults that are properties of the request alone (zero or
oversize length, unsupported operation, wrap-around, invalid domain number) and so reveal nothing about the configuration. (Citadel rule R3: the reason goes to privileged audit only.)

## 2. The privileged fault log

One record per denied or malformed request, written **exactly once**, in the cycle the port retires the request:

| field | meaning |
|---|---|
| requester identity | the **physical port** (hard-wired, cannot be spoofed) |
| domain | the domain **claimed** by the request (for `SPOOF` / `BADDOM` this is the false claim) |
| fault address, length | as presented |
| operation | `r_op` (including the unsupported ones) |
| error type | native fault code (`02` §4) |
| transaction id | `r_id` |
| policy generation (16 bit) | `R_GEN` when the verdict was computed — the table was constant from accept to retire, so a record can be replayed against exactly that policy |
| sequence number | counts every denial, including dropped records; gaps between kept records show how many were lost |

* Bounded FIFO (`FLOG_DEPTH`), **drop-newest**: the oldest evidence is kept, a lost record is counted (`CN_FDROP`, `STAT_FDROP`, a saturating 16-bit field in `R_FLOG_CNT`); the data plane never stalls on diagnostics.
* Several ports may deny in the same cycle: a rotating-priority arbiter logs one per cycle; the others retire one cycle later. Only denied traffic ever waits for the log.
* Read through `R_FLOG_CNT`, `R_FLOG_W0..W3`, `R_FLOG_SEQ`; pop with `R_FLOG_POP`. **Every register read is privileged**: an unprivileged read returns 0 and an error (tested: T07, T13, and the random agent).

## 3. Counters (`R_CNT_SEL` / `R_CNT_DATA`, saturating, never wrap)

`CN_FAULTS` (every denial, logged or dropped), `CN_SEC`, `CN_LOCKREJ`, `CN_COMMIT`, `CN_CMDREJ`, `CN_TMO`, `CN_ORPHAN`, `CN_FDROP`, `CN_FWD`, then per port: forwarded, faulted; then per fault code.
The random testbench checks every counter against its own tallies at the end of every run (E3), including the identity *faults = popped + held + dropped*.

## 4. What is not exposed

* no tenant-visible diagnostic path exists at all (no unprivileged counters): a platform that wants a tenant to see *its own* fault count must add a filtered, per-domain view in the management plane;
* the counters are per *port* and per *fault code*, not per claimed domain — a spoofing tenant cannot inflate or quarantine another tenant's count (Citadel finding 2);
* timing is not a diagnostic channel the guard controls: a denial takes longer than a grant (`09`), see `10`.
