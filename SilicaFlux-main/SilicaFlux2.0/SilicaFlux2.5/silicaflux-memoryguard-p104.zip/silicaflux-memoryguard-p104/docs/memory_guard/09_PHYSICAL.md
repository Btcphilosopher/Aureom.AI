# 09 — Physical implications: area, depth, latency, throughput

> **All numbers are estimates.** Yosys 0.33, technology independent (`synth -flatten`, ABC to generic 2-input gates / LUT6). **No ASIC library or PDK exists in the repository**, no place-and-route
> or timing run was made, nothing here is a silicon measurement. They are for comparing configurations against each other. `GE` = NAND2-equivalent estimate with the weights in
> `benchmarks/memory_guard/synth.py` (flop = 5 GE). `gate depth` = longest combinational path (`ltp`) in generic gates; ABC does not optimise for depth here, so absolute depths are pessimistic.

## 1. The checker of one port — parallel region comparators (default AW 32, NP 4)

Each region entry costs two wide comparators for the decision (`addr ≥ base`, `addr + len ≤ end`) and two more only for the diagnosis. `DIAG_PRECISE = 0` removes the latter.

| ND | NR | lookup | diag | gates | GE | gate depth | LUT6 | LUT depth |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2 | 2 | 0 | 0 | 1492 | 2068 | 54 | 379 | 13 |
| 4 | 2 | 0 | 0 | 2917 | 3946 | 55 | 717 | 13 |
| 8 | 2 | 0 | 0 | 5387 | 7425 | 57 | 1390 | 13 |
| 16 | 2 | 0 | 0 | 10727 | 14502 | 57 | 2622 | 14 |
| 2 | 4 | 0 | 0 | 2819 | 3932 | 55 | 711 | 13 |
| 4 | 4 | 0 | 0 | 5377 | 7412 | 59 | 1371 | 14 |
| 8 | 4 | 0 | 0 | 10691 | 14467 | 57 | 2615 | 14 |
| 16 | 4 | 0 | 0 | 21417 | 28627 | 58 | 5137 | 14 |
| 2 | 8 | 0 | 0 | 5374 | 7390 | 59 | 1363 | 14 |
| 4 | 8 | 0 | 0 | 10682 | 14455 | 59 | 2628 | 14 |
| 8 | 8 | 0 | 0 | 21395 | 28613 | 57 | 5089 | 14 |
| 16 | 8 | 0 | 0 | 42597 | 56659 | 59 | 9925 | 15 |
| 2 | 2 | 0 | 1 | 2583 | 3506 | 56 | 651 | 13 |
| 4 | 2 | 0 | 1 | 5038 | 6788 | 58 | 1241 | 14 |
| 8 | 2 | 0 | 1 | 9848 | 13021 | 59 | 2465 | 14 |
| 16 | 2 | 0 | 1 | 19513 | 25682 | 60 | 4769 | 15 |
| 2 | 4 | 0 | 1 | 5034 | 6792 | 58 | 1248 | 14 |
| 4 | 4 | 0 | 1 | 9839 | 13012 | 61 | 2482 | 14 |
| 8 | 4 | 0 | 1 | 19540 | 25813 | 60 | 4784 | 14 |
| 16 | 4 | 0 | 1 | 39010 | 51003 | 60 | 9369 | 15 |
| 2 | 8 | 0 | 1 | 9863 | 13120 | 60 | 2513 | 14 |
| 4 | 8 | 0 | 1 | 19521 | 25767 | 61 | 4707 | 15 |
| 8 | 8 | 0 | 1 | 38982 | 50964 | 60 | 9464 | 15 |
| 16 | 8 | 0 | 1 | 77307 | 101970 | 62 | 18317 | 15 |
| 2 | 2 | 1 | 0 | 1206 | 1511 | 53 | 353 | 12 |
| 4 | 2 | 1 | 0 | 1773 | 2172 | 53 | 474 | 12 |
| 8 | 2 | 1 | 0 | 2914 | 3491 | 51 | 786 | 12 |
| 16 | 2 | 1 | 0 | 5174 | 6130 | 51 | 1354 | 12 |
| 2 | 4 | 1 | 0 | 2275 | 2810 | 54 | 648 | 13 |
| 4 | 4 | 1 | 0 | 3404 | 4123 | 54 | 919 | 13 |
| 8 | 4 | 1 | 0 | 5678 | 6754 | 52 | 1527 | 12 |
| 16 | 4 | 1 | 0 | 10181 | 12003 | 52 | 2673 | 12 |
| 2 | 8 | 1 | 0 | 4407 | 5407 | 55 | 1261 | 13 |
| 4 | 8 | 1 | 0 | 6663 | 8031 | 55 | 1811 | 13 |
| 8 | 8 | 1 | 0 | 11202 | 13280 | 53 | 3090 | 13 |
| 16 | 8 | 1 | 0 | 20180 | 23747 | 53 | 5354 | 13 |
| 2 | 2 | 1 | 1 | 1793 | 2308 | 58 | 467 | 13 |
| 4 | 2 | 1 | 1 | 2363 | 2970 | 55 | 625 | 13 |
| 8 | 2 | 1 | 1 | 3493 | 4277 | 58 | 921 | 13 |
| 16 | 2 | 1 | 1 | 5776 | 6922 | 59 | 1499 | 13 |
| 2 | 4 | 1 | 1 | 3463 | 4413 | 59 | 887 | 13 |
| 4 | 4 | 1 | 1 | 4573 | 5722 | 56 | 1180 | 13 |
| 8 | 4 | 1 | 1 | 6825 | 8309 | 60 | 1748 | 14 |
| 16 | 4 | 1 | 1 | 11347 | 13580 | 60 | 2897 | 14 |
| 2 | 8 | 1 | 1 | 6757 | 8617 | 60 | 1709 | 14 |
| 4 | 8 | 1 | 1 | 8996 | 11221 | 58 | 2295 | 14 |
| 8 | 8 | 1 | 1 | 13496 | 16404 | 60 | 3475 | 14 |
| 16 | 8 | 1 | 1 | 22516 | 26904 | 61 | 5782 | 14 |

Reading the table: area grows **linearly with `ND·NR`** for lookup 0 (every entry compares in parallel, results gated by the domain decode) and with `NR` plus an `ND`-wide AND-OR multiplexer
over the stored entries for lookup 1. The multiplexer moves cost from comparators to wiring: it wins when `ND` is large; with few domains the parallel structure is simpler. `DIAG_PRECISE = 0` is the cheapest way to cut
area — at the cost of reporting `FT_SPAN` as `FT_NOMAP` (the decision is unchanged, proved).

Address width (comparators are `AW` bits):

| AW | gates | GE | gate depth | LUT6 | LUT depth |
|---:|---:|---:|---:|---:|---:|
| 24 | 7350 | 9658 | 54 | 1819 | 13 |
| 32 | 9839 | 13012 | 61 | 2482 | 14 |
| 40 | 12322 | 16463 | 71 | 3026 | 16 |
| 48 | 14866 | 19872 | 79 | 3543 | 18 |

## 2. The whole guard — growth with domains and ports

The checker is **per port** (the decision must be available to every port every cycle), so area also grows with `NP`; the region table itself (flops) grows with `ND·NR·(2·AW+…)`; the
fault log and the counter bank are fixed costs. The `CHK_PIPE = 1` configurations add a second request register per port and the registered verdict.

| config | gates | flops | GE | gate depth | LUT6 | LUT depth |
|---|---:|---:|---:|---:|---:|---:|
| top_nd2_np4_p0_a0 | 31981 | 3409 | 59686 | 134 | 8592 | 28 |
| top_nd2_np4_p1_a0 | 33328 | 3917 | 64301 | 134 | 8571 | 28 |
| top_nd4_np2_p0_a0 | 33313 | 3550 | 62538 | 134 | 8001 | 28 |
| top_nd4_np2_p1_a0 | 33149 | 3804 | 63658 | 134 | 8069 | 28 |
| top_nd4_np4_p0_a0 | 54862 | 4001 | 93542 | 134 | 12780 | 28 |
| top_nd4_np4_p0_a1 | 34032 | 4001 | 64697 | 134 | 9919 | 28 |
| top_nd4_np4_p1_a0 | 55330 | 4509 | 96319 | 134 | 12609 | 28 |
| top_nd4_np4_p1_a1 | 34405 | 4509 | 67745 | 134 | 9726 | 28 |
| top_nd4_np8_p0_a0 | 94001 | 4894 | 150202 | 131 | 24170 | 27 |
| top_nd4_np8_p1_a0 | 93299 | 5910 | 152455 | 134 | 20497 | 28 |
| top_nd8_np4_p0_a0 | 96484 | 5185 | 155155 | 134 | 21454 | 28 |
| top_nd8_np4_p1_a0 | 95867 | 5693 | 154970 | 134 | 20476 | 28 |
| top_nr2 | 32024 | 3417 | 59775 | 134 | 8432 | 28 |
| top_nr4 | 54862 | 4001 | 93542 | 134 | 12780 | 28 |
| top_nr8 | 96419 | 5169 | 155088 | 134 | 21169 | 28 |
| top_dw32 | 54953 | 3845 | 92685 | 132 | 13244 | 27 |
| top_dw64 | 54862 | 4001 | 93542 | 134 | 12780 | 28 |
| top_dw128 | 55641 | 4301 | 96414 | 134 | 13944 | 28 |
| top_dw256 | 56847 | 4889 | 100910 | 134 | 14936 | 28 |
| port_p0 | 9942 | 137 | 13812 | 58 | 2470 | 14 |
| port_p1 | 9652 | 264 | 13756 | 63 | 2673 | 14 |

Reading the table (the numbers above are generated from `benchmarks/memory_guard/results/synth.json`):

* **One port = one checker.** A single port (`port_p0`) is about 10 k gates, of which the checker is nearly all; four ports are therefore ≈ 4 × that (`top_nd4_np4_*` is about 55 k gates, 93 k GE, 4 k flops). Area scales ≈ **linearly with `NP`**.
* **Domain count and regions.** With the parallel lookup (`LOOKUP_ARCH` 0) one port's checker grows ≈ linearly with `ND·NR` (ND 2 → 16 at NR 4: see the first table); the multiplexed lookup (1) grows much more slowly (ND 2 → 16 at NR 4: ×7.8 for lookup 0, ×3.3 for lookup 1), because it compares only the `NR` entries of the claimed domain and pays an `ND`-wide AND-OR multiplexer instead. The whole guard also grows with `ND·NR·(2·AW + …)` table flops. With `LOOKUP_ARCH = 1` the default guard is **≈ 38 % smaller** than with 0 (35 k vs 55 k gates).
* **Diagnostics are the cheapest area lever**: `DIAG_PRECISE = 0` removes about **45 %** of the parallel checker (the two extra comparators per entry), at the price of reporting `FT_SPAN` as `FT_NOMAP`; the decision is proved unchanged.
* **Address width** moves comparator size linearly (§1, second table).
* **Registered verdict** (`CHK_PIPE = 1`) costs ≈ 130 extra flops per port (a second request register) and **+1 cycle** of latency. What it buys is structural: with 0, the checker sits on the register → output path (request register → checker → `m_valid`, and through `act_retire` → `r_ready`); with 1, the verdict comes from a register, so the checker moves onto an internal register → register path (request register → checker → verdict register). **Yosys 0.33 `ltp` reports only the single longest path of the design, which is the same comparator chain in both configurations (58 vs 63 gates for one port), so this study does not measure the output-path benefit** — a timing-driven synthesis with a real library is needed for that. The longest path of the *whole* guard (134 gates) is **not** the checker but the configuration path (65-bit region validation, overlap compare against every entry, saturating counters); it is off the request datapath and would be multicycled or pipelined in a physical design.
* **Throughput does not depend on the check** for permitted traffic (§3); a denied request costs more cycles (it waits for the earlier responses and for the fault-log grant).
* **Fixed overhead**: the 33 × 32-bit counter bank and the 8-record fault FIFO are about 1.9 k flops of the default guard; `CNTW` and `FLOG_DEPTH` can be narrowed.

## 3. Throughput and latency of the protected path (simulation)

4000-cycle window after warm-up; every port streams 8-byte requests at full rate into an always-ready memory of fixed latency `L`; `latency` is accept edge → response edge (the memory alone would show about `L`).
Permitted traffic, 4 ports, **responses / cycle / port  /  average latency (cycles)**:

| CHK_PIPE | MAXOUT | L = 1 | L = 2 | L = 4 | L = 8 |
|---:|---:|---|---|---|---|
| 0 | 1 | 0.50 / 3.0 | 0.33 / 5.0 | 0.20 / 9.0 | 0.11 / 17.0 |
| 0 | 2 | 1.00 / 2.0 | 0.67 / 3.5 | 0.40 / 6.5 | 0.22 / 12.5 |
| 0 | 4 | 1.00 / 2.0 | 1.00 / 3.0 | 0.80 / 5.2 | 0.44 / 10.2 |
| 0 | 8 | 1.00 / 2.0 | 1.00 / 3.0 | 1.00 / 5.0 | 0.89 / 9.1 |
| 1 | 1 | 0.50 / 5.0 | 0.33 / 8.0 | 0.20 / 14.0 | 0.11 / 26.0 |
| 1 | 2 | 1.00 / 3.0 | 0.67 / 5.0 | 0.40 / 9.0 | 0.22 / 17.0 |
| 1 | 4 | 1.00 / 3.0 | 1.00 / 4.0 | 0.80 / 6.5 | 0.44 / 12.5 |
| 1 | 8 | 1.00 / 3.0 | 1.00 / 4.0 | 1.00 / 6.0 | 0.89 / 10.2 |

Denied traffic (`MAXOUT` 4, `L` = 1):

| CHK_PIPE | denied % | ports | responses / cycle / port | latency |
|---:|---:|---:|---:|---:|
| 0 | 50 | 1 | 0.573 | 2.75 |
| 0 | 50 | 4 | 0.462 | 3.16 |
| 0 | 100 | 1 | 0.500 | 3.00 |
| 0 | 100 | 4 | 0.250 | 5.00 |
| 1 | 50 | 1 | 0.573 | 4.49 |
| 1 | 50 | 4 | 0.463 | 5.32 |
| 1 | 100 | 1 | 0.500 | 5.00 |
| 1 | 100 | 4 | 0.250 | 9.00 |

(`benchmarks/memory_guard/results/bench.md` has every combination.)

* Permitted traffic: **one response per cycle per port** once the outstanding window covers the memory round trip: the measured throughput is `min(1, MAXOUT / (L + 1))` for both `CHK_PIPE` values — the **check never limits throughput**, the window does.
* The registered verdict adds exactly **one cycle** of latency (2 → 3 cycles at `L` = 1) and costs no throughput.
* A **denied** request is the slow path by design: it waits for every earlier response (ordering), for a fault-log grant, and its error response must be taken before the next denial retires. Measured: **one denied request every 2 cycles per port**, and **one per cycle in total** across ports (the fault log has one write port, so four ports that deny continuously get 0.25 each).
  By construction a port's denials never delay another port's *permitted* requests (the ports share only the table, the fault-log arbiter that only denied requests use, and the drain); this was not measured separately.
* Configuration commands stall **every** port for the length of the drain (§`05`); in the random runs about 900 commits are absorbed per 150 000 cycles with no lost requests.

## 4. What was not studied

* real timing (no PDK), power, placement; a larger `AW` than 48; the effect of `FLOG_DEPTH` and `CNTW` (fixed overhead: about 1 000 flops of the default guard are the 33 × 32-bit counters and the fault FIFO — they can be narrowed);
* sharing one checker between ports (one verdict per cycle for four ports would serialise them; not built);
* reducing the unreset payload flops of the table (already unreset) or using a RAM for the table (would add a read latency to every check).
