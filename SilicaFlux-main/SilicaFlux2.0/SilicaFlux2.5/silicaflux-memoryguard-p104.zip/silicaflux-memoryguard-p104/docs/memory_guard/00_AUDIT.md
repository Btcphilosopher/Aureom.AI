# 00 — Repository audit (Project 104, MemoryGuard)

Audited: the `Aureom.AI` working tree as cloned. The SilicaFlux RTL lives almost entirely inside zip archives under `SilicaFlux-main/` and
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`; there is no loose RTL for these blocks. Every archive that could hold a memory-protection,
DMA, fabric, boot or control block was extracted into a scratch directory (untrusted data: read, never executed) and read. **Nothing was
committed to the repository; the project is delivered as an archive.** Statements are *found in files* unless marked *(inferred)*.

## 1. The names in the brief, mapped to what exists

| Brief name | What exists | Evidence | Use in Project 104 |
|---|---|---|---|
| **MemoryGuard** | **no module of that name.** Three *interfaces* were defined by earlier projects for it: CloudDMA's `iommu_req/rsp` contract (P64), StreamDMA's `guard_*` (P103), MeridianQoS's `grd_*` (P102) | P103 `docs/03_PROTECTION.md` §1 ("the repository contains no module named MemoryGuard"); P102 `docs/meridian_qos/00_AUDIT.md` §1 | **built here**; the two check contracts are implemented as adapters (`sf_memory_guard_iommu_if`, `sf_memory_guard_grd_if`) |
| **Citadel** | **Project 89**: a real policy engine — domain table, permission checker, enforcement `chk_*` ports, gate, fault manager, secure-boot policy | `silicaflux-citadel-p89.zip`, `docs/citadel/00_AUDIT.md`, `04_ENFORCEMENT.md` | design lessons reused (below); its `sf_citadel_gate` is the closest relative of `sf_memory_guard_port`. Not instantiated |
| **SecureSilicon** | **Project 28** `silicaflux-secureboot-p28.zip`: immutable boot ROM, Ed25519 + SHA-256 verification, `sb_dma_guard`; OTP / lifecycle / anti-rollback are *models* | Citadel `00_AUDIT.md` §1 | the intended source of the **trusted privilege** of the configuration port (Citadel rule R6, here `06_TRUSTED_IDENTITY.md`) |
| **IOMMU interfaces** | CloudDMA `sfdma_perm_checker` + `sfdma_perm_table` (contract; *simulation table*, "not a hardware isolation mechanism on its own"); **DomainGuard** (P97, `sf_albion_iommu`): a real multi-port IOMMU-style unit with 4 KiB page translation, deny-by-default, drain barrier, fault log, privileged atomic admin ("Not a RISC-V IOMMU") | P64 `docs/03_PROTECTION.md`; P97 `README.md` | contracts adapted; **DomainGuard is the translation-capable block and is left alone** — this project is region protection, not translation |
| **Meridian / DataFabric** | Meridian **P83** (cloud interconnect, registered crossbar, Citadel check interface at the master port, error log); DataFabric SFB2/SFB3 (**no access control anywhere in the fabric**: "Region legality is not known to the DMA") | P83 `docs/meridian/`; DataFabric `docs/datafabric/PROTOCOL.md` | transaction contract and status codes reused (`ST_*`, `OP_*`); `tests/memory_guard/tb_abi_check.sv` compares them with P102's copy |
| **MeridianQoS** | **P102**: QoS fabric whose masters query a guard through `grd_*` and **enforce the verdict themselves** | `rtl/meridian_qos/sf_meridian_guard_ref.sv` | `sf_memory_guard_grd_if` implements that port on the MemoryGuard table |
| **CloudDMA** | **P64** AXI4 DMA, documents "a domain number is a label software can lie about" and binds the domain at the command port | P64 `docs/03_PROTECTION.md` | the lesson is the design's starting point (trusted identity, §`06`) |
| **StreamDMA** | **P103** protected scatter-gather DMA; asks the MemoryGuard for every burst; hardware-sideband domain; a bridge to MemoryMatrix | P103 `README.md`, `docs/03_PROTECTION.md`, `10_MEMORYMATRIX_INTEGRATION.md` | contract adapter; the inline port sits behind its MemoryMatrix bridge |
| **MemoryMatrix** | **P101** banked SRAM subsystem; **single-phase master port** (request with data, in-order response, `prot {secure, priv}`) | `rtl/memory/sf_memory_matrix.sv` header | the native port of the guard is a superset of this master port; **P101 is vendored unmodified and run behind the guard** (`mm_random*`) |
| **VirtualIO** | **P63** virtio-blk engine: queue bound to a domain by the hypervisor only, every DMA beat must fall in a window of that domain | P63 `README.md` | integration point = the storage port; its own windows stay as defence in depth |
| **ControlCore** | **P21**: RV32IM core with an SFB2 master `ext_*` (32-bit address/data) and a host mailbox; **"no firmware authentication, secure boot, root of trust or key storage"** | `docs/09_LIMITATIONS.md` | the management plane that drives the configuration bus; **not a trust anchor on its own** |
| **TensorCore** | TC08 (vendored in ControlCore): SFB2 bus master, `MAX_OUT` 4; TC04: no bus (storage ports) | P102 audit §1 | SFB2 → native bridge not built; mapping documented (`03`) |
| **PacketForge** | **not found.** Nearest: **PacketCore P62** — AXI-stream-like, **no memory-side bus**; its P61 test adapter is a 32-bit SFB2 master | P102 audit §1 | mapping documented (`03`), nothing instantiated |
| **StreamDMA, MemoryMatrix, MeridianQoS** as *names in the brief* | exist (P103, P101, P102) | — | see above |

## 2. Findings that shaped the design

1. **A domain number is attacker-controlled** (CloudDMA, Citadel §2). The guard therefore never takes authority from `r_dom`. Authority is the
   *trusted binding of the physical port* (`allow` mask, programmed through the privileged bus). `r_dom` is a *claim* that must lie inside it.
2. **Nothing in the existing fabrics checks access** (DataFabric docs). Enforcement must be added at each master port: that is what an *inline*
   port is (`sf_memory_guard_port`); a check-only interface (P64 / P102 / P103) is advisory and says so.
3. **Every earlier "MemoryGuard" was a model or an interface.** P103 stood in a CloudDMA table; P102 a reference model. This project is the
   first RTL that is both the checker *and* the enforcement point, and it carries formal proofs of the enforcement.
4. **Revocation under load is the hard part** (CloudDMA §2: "quiesce before unmapping"; DomainGuard has a *drain barrier*; Citadel R9). Project 104
   makes the drain part of the design: a configuration change is committed only with every port idle and ingress blocked (`05_INFLIGHT_POLICY.md`).
5. **Test/debug paths bypass any master-port policy** (Citadel finding 6: TestCore's MBIST/JTAG is an alternate path to memory; its unlock key is "an interlock, not security").
   The guard cannot police them; they are an *integration obligation* (`03`, rule R7).
6. **Existing tool facts**: Verilator 5.020 and Yosys 0.33 are the repository's tools (reproduced here); Yosys 0.33 does not support `import pkg::*`
   (the RTL uses the same generated local-alias style as Projects 22/83/102: `scripts/alias_pkg.py`); SymbiYosys is not installed — the proofs
   use `yosys-smtbmc` + z3 directly.
7. **No ASIC library or PDK exists in the repository** (P102 audit §5). Area and depth numbers here are Yosys technology-independent estimates.

## 3. Reuse summary

* **Reused unmodified (vendored):** MemoryMatrix P101 RTL (hash-pinned, `third_party/p101/`), used only by the integration test.
* **Reused as design input (re-implemented, not copied):** Citadel's port-binding discipline, physical-port identity, exact range arithmetic, "gate holds the
  request, forwards only on PERMIT, explicit error response, deny waits for earlier answers"; CloudDMA/P103 check-before-transaction and the `iommu_*`
  contract; P102's `grd_*` contract; P83's status/fault code points; MemoryMatrix's single-phase master port; the SFB2 configuration bus style; P102's
  register-map conventions (RO / RW1C / lock bit 31 set-only).
* **New:** everything in `rtl/memory_guard/`.

## 4. Gaps this project does not close

* no real MemoryGuard *integration* with the StreamDMA / MeridianQoS / TensorCore / VirtualIO RTL (adapters and contract tests only; PacketForge does not exist);
* no address translation — a genuine IOMMU is DomainGuard (P97), out of scope here by the brief;
* no authenticated management plane (ControlCore claims none; SecureSilicon P28's OTP is a model): `cfg_req_priv` is a label whose meaning is
  physical exclusivity (`06`);
* no physical design (no PDK): area / depth are estimates.
