# 10 — Limitations, assumptions, and what is NOT claimed

**Claim (definition of done, scoped):** *in the supported architecture* — every master behind an inline guard port (R1), the configuration bus exclusive to the management plane (R3), an in-order
memory (R6), test access disabled (R7) — **no request that the configured policy denies can modify the memory behind the guard, and every denied request receives an explicit error response and
exactly one fault record.** The evidence is the unbounded proofs G1–G7 / S0–S5 / W1–W5 / C1–C7 / R0–R5 (compositional, `08`), the end-to-end simulations with a real memory, the Python-vector
cross-check and the mutation campaign. Everything below is outside that claim.

## What this is not

| not | detail |
|---|---|
| **an IOMMU / address translation** | the guard authorises byte ranges of the physical address a requester presents. It never translates. Translation is **DomainGuard (P97)**, a separate block. `sf_memory_guard_iommu_if` implements an IOMMU *contract* with an identity `pa`; it is not an IOMMU |
| a secure management plane | `cfg_req_priv` is a label (`06`). If a tenant can drive the configuration bus, it owns the policy. ControlCore claims no authentication and SecureSilicon's OTP is a model |
| side-channel safe | shared checker, shared fault-log arbiter, back-pressure and drain stalls are observable: a denial takes longer than a grant; a configuration drain stalls every port; a tenant that never takes its response delays everyone's reconfiguration (but not its safety) |
| a DoS defence | a tenant can flood the fault log (records are dropped and counted) and keep denied responses queued; there is no per-tenant rate limit or quarantine |
| memory-side protection | a compromised memory or fabric *behind* the guard, a test / debug path to the memory, or a second physical path (R1, R7) is not covered |
| confidentiality of buffers | no scrubbing: a region reassigned from one domain to another keeps its old bytes; the management plane must scrub before re-binding |
| coherent with caches | the guard sees only the traffic that reaches it; a cache upstream of the guard may hold lines for a revoked region |

## Assumptions the proofs rest on (each is checked somewhere, or is an integration obligation)

| id | assumption | where it is discharged |
|---|---|---|
| E1 | a presented request is held until accepted | requester protocol; checked in simulation (the TB drivers obey it) |
| E2 | a presented memory response is held until accepted | memory protocol (MemoryMatrix M-rules) |
| E3 | the memory answers only forwarded requests, in order, echoing id and direction | **not assumed** in `port_orphan*` (orphans are discarded); assumed for response-id equality |
| **E4** | the table changes only after a cycle with the port idle and ingress blocked | **proved** for the composition (`fv_mg_cfg`, `fv_mg_top`) |
| E5 | a log grant is given only to a requester | structural (`sf_memory_guard_faults` arbiter); proved as an assumption of the port, structural in the top |
| A-CTX | the device context that drives `r_dom` is honest *within the port's trusted binding* | the binding bounds a dishonest context; a static one-domain binding removes the assumption |
| G6-as-assumption | in `fv_mg_top` the port-level guarantee *idle ⇔ nothing accepted and unanswered* is assumed (assume-guarantee) | **proved** in `fv_mg_port` (G6) |

## Verification limits (see `08`)

* The proofs are on **tiny configurations** (e.g. `ND=3, NR=2, NP=2, AW=5..8`); parameters scale, the structure does not change, but the 4 × 4 × 32-bit instance of the checker is beyond z3 as a single SAT instance (`chk_nr4` and the 63-bit `chk_aw63` pass; the full size is covered by 240 000 Python-model vectors and by simulation).
* The composition is **not** model-checked end to end beyond W1–W5; the whole-system argument is assume-guarantee (port + configuration engine + checker + table) plus simulation of the integrated design.
* The fault log and counters have simulation evidence (directed T13, random E3 tallies, mutant F01) but **no formal proof**.
* Verilator / Yosys 0.33 / z3 5.x are the tools; no second simulator ran the RTL (Icarus 12 parses it with warnings, but it was not used as an oracle).
* All numbers are simulation or technology-independent synthesis estimates. **No silicon, no PDK, no timing measurement.**

## Known design limits

* single beat per request: a burst is a sequence of requests (each checked); a requester that needs burst-level atomicity must build it above the guard;
* `ND ≤ 16`, `NR ≤ 16`, `NP ≤ 8`, `AW ≤ 63`, `IDW ≤ 16` (register field widths);
* no forced abort of in-flight transactions (`05` §5); a revocation can be delayed, not forced;
* one region may not span two table slots: a transfer over two adjacent regions is denied by design;
* the fault log keeps the *oldest* records when full (drop-newest); the newest evidence is counted but not stored;
* licence: the vendored MemoryMatrix files carry no licence statement in their source archive.
