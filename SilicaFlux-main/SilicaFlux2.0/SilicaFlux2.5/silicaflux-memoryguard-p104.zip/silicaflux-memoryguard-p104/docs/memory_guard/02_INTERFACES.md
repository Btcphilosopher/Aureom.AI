# 02 — Interfaces (ABI)

All ports are flat valid/ready vectors; port `p` occupies bit / slice `p` of every `NP`-wide vector. Names follow Projects 22 / 83 / 102.

## 1. Requester side (per port, `r_*` / `s_*`)

A **superset of the MemoryMatrix master port** (Project 101): one request carries its own data; there is no separate data channel to authorise "later".

| signal | meaning |
|---|---|
| `r_valid/ready` | handshake; `r_ready` never depends on `r_valid`; it is low while ingress is blocked by a drain. The requester holds the request until accepted |
| `r_op[1:0]` | `0` READ, `1` WRITE (P83 codes). `2`, `3` are **unsupported operations** → `FT_BADOP` |
| `r_addr[AW]` | byte address |
| `r_len[LW]` | transfer length in **bytes**, `1 … DW/8`. `0` is **zero-length** → `FT_ZEROLEN`; `> DW/8` → `FT_BADLEN` (with `LEN_POW2`, also a non-power-of-two) |
| `r_wdata[DW]`, `r_be[DW/8]` | write data and byte enables; lane `j` is the byte at `addr + j`. Ignored for reads |
| `r_id[IDW]` | opaque transaction id, echoed on the response and recorded with every fault |
| `r_dom[DOMW]` | the **domain claim** from the device's trusted context. It is a claim, never authority: it must be `< ND` (else `FT_BADDOM`) and inside the port's trusted binding (else `FT_SPOOF`) |
| `s_valid/ready`, `s_rdata`, `s_id`, `s_we`, `s_status[3]` | one response per accepted request, **in acceptance order**, held stable until taken |

`s_status` (P83/P102 numeric codes): `0 OKAY`, `1 SLVERR` (the *memory* failed a permitted request), `3 DENIED` (policy denial — **no reason is given**), `5 PROTO` (malformed request: zero / oversize length, unsupported op, wrap-around, invalid domain). `2 DECERR` and `4 TIMEOUT` are in the ABI but never produced. An error response carries `s_rdata = 0` and `s_we` = the request's direction. `tests/memory_guard/tb_abi_check.sv` compiles this package with the vendored P102 package and fails if a shared constant differs.

## 2. Memory side (per port, `m_*` / `d_*`)

| signal | meaning |
|---|---|
| `m_valid/ready` | handshake. `m_valid` never depends on `m_ready`; once asserted, the request is held **unchanged** until accepted (formal G4) |
| `m_we`, `m_addr`, `m_len`, `m_wdata`, `m_be`, `m_id` | the permitted request, bit for bit; `m_be` is **clipped to the low `len` lanes** and is 0 for a read; `m_wdata` is 0 for a read |
| `m_dom[DOMW]` | the **verified** domain, stamped by the guard (a trusted sideband for a second check downstream, e.g. MemoryMatrix `prot.secure`) |
| `d_valid/ready`, `d_rdata`, `d_id`, `d_we`, `d_err` | the memory's in-order response; `d_ready` may depend on `s_ready` (pass-through back-pressure). A response with nothing outstanding is **discarded and counted** (`CN_ORPHAN`, `STAT_ORPHAN`), never forwarded |

**Every memory-side wire is 0 unless `m_valid`** (formal G3): a denied request leaves no trace — neither data nor address — on the memory side.

## 3. Configuration bus (`cfg_*`) — SFB2 style, 32 bit, single outstanding

`cfg_req_valid/ready/write/addr[7:0]/wdata/wstrb/priv`, `cfg_rsp_valid/ready/rdata/error`. The word index is `addr[6:2]`. `cfg_req_priv` is the **trusted privilege qualifier**: it must be driven by the management plane and by nothing a tenant can reach (`06`). `cfg_rsp_error = 1` means the access had **no effect** (and a read returned 0).

| rule | result |
|---|---|
| `!priv` (read or write) | error, `STAT_SEC`, `CN_SEC`; a write does nothing, a read returns **0** |
| address outside the map / unaligned | error, `STAT_BADADDR` |
| `wstrb != 0xF`, or write to a read-only register | error, `STAT_ECMD` |
| after `CTRL.LOCK` | every write except `R_STATUS`, `R_FLOG_POP`, `R_CNT_SEL`, `R_SEL` is refused: error, `STAT_LOCKED`; the lock is **never cleared except by reset** |
| a command is draining | writes to staging registers, `R_SEL`, `R_CMD`, `R_CTRL`, `R_DRAIN_TMO` are refused: error, `STAT_BUSY` |

### Register map (word offsets; byte address = 4 ×)

| off | name | access | content |
|---:|---|---|---|
| 0 | `R_ID` | RO | `[31:16]` "MG", `[15:12]` ND, `[11:8]` NR, `[7:4]` NP, `[1]` CHK_PIPE, `[0]` STRICT |
| 1 | `R_VERSION` | RO | `0x0001_0000` |
| 2 | `R_CTRL` | RW | `[31]` LOCK (set only) |
| 3 | `R_STATUS` | RW1C | sticky: `0` SEC, `1` LOCKED, `2` BUSY, `3` ERANGE, `4` EOVERLAP, `5` EINDEX, `6` ECMD, `7` TMO, `8` DONE, `9` FDROP, `10` ORPHAN, `11` FAULT, `12` BADADDR; `[31]` log non-empty (RO) |
| 4 | `R_STATE` | RO | `[0]` busy, `[1]` blocking, `[2]` locked, `[3]` in flight, `[11:8]` last command error (`CE_*`) |
| 5 | `R_GEN` | RO | policy generation: +1 per committed change |
| 6 | `R_DRAIN_TMO` | RW | drain timeout in cycles, 0 = wait forever |
| 7 | `R_SEL` | RW | `[3:0]` domain, `[11:8]` region index, `[19:16]` port |
| 8–11 | `R_BASE_LO/HI`, `R_SIZE_LO/HI` | RW | staged region base / size (bytes, `1 … 2^AW`) |
| 12 | `R_ATTR` | RW | `[0]` R, `[1]` W, `[2]` DEV_EN, `[15:8]` DEV_MASK (bit p = port p) |
| 13 | `R_ALLOW` | RW | staged allow mask (bit d = domain d) |
| 14 | `R_CMD` | WO | `1` SET_REGION, `2` CLR_REGION, `3` BIND_PORT, `4` CLEAR_ALL |
| 15–20 | `R_RD_*` | RO | installed entry (dom, idx) / binding (port) selected by `R_SEL` |
| 21–26 | `R_FLOG_*` | RO | fault log: count / dropped, then head record words, sequence number |
| 27 | `R_FLOG_POP` | WO | drop the head record |
| 28–30 | `R_CNT_SEL/DATA`, `R_NCNT` | RW/RO | counter bank (saturating) |
| 31 | `R_CAPS` | RO | AW, bytes per beat, IDW, MAXOUT |

Command errors (`CE_*`, also in `R_STATE[11:8]`): `1` RANGE (zero size, base outside the space, base + size wraps), `2` OVERLAP, `3` INDEX (domain / region / port out of range, reserved bits), `7` TMO (drain timed out: **not applied**), `8` CMD (unknown command).

## 4. Native fault codes (privileged only)

`0` NONE · `1` NOMAP · `2` PERM · `3` SPAN (partial overlap / boundary-spanning) · `4` OVERFLOW · `5` ZEROLEN · `6` BADOP · `7` BADDOM · `8` SPOOF · `9` DEVICE · `10` BADLEN.
Mapped to `ST_PROTO` for `OVERFLOW, ZEROLEN, BADOP, BADDOM, BADLEN` (properties of the request alone) and to `ST_DENIED` for the rest.

## 5. Check-only adapters

| adapter | contract | mapping |
|---|---|---|
| `sf_memory_guard_grd_if` | MeridianQoS (P102) `grd_*`: one query / registered in-order verdict per master | `NOMAP, SPAN, OVERFLOW, ZEROLEN, BADLEN → F_NOMAP(1)`, `PERM, DEVICE → F_PERM(2)`, `BADDOM, SPOOF → F_DOMAIN(3)`, `BADOP → F_BADOP(11)`; `req_priv` is ignored (a label is not authority) |
| `sf_memory_guard_iommu_if` | StreamDMA (P103) / CloudDMA (P64) `guard_*` / `iommu_*` | `NOMAP, BADDOM, SPOOF → 1`, `PERM, DEVICE → 2`, `SPAN, OVERFLOW → 4`, `ZEROLEN, BADLEN, BADOP → 7`; **`guard_rsp_pa = guard_req_addr` on a grant, 0 on a denial — there is no translation** |

Both are **advisory** (`03`): the master enforces the verdict.
