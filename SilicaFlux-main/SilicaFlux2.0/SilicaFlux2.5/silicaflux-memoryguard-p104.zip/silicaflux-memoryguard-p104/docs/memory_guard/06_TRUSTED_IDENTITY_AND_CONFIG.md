# 06 — Trusted identity and the trusted configuration interface

## 1. Where the domain comes from

> *A tenant ID alone does not provide isolation.* A domain number in a descriptor is a label software can lie about. (Project 64, Citadel §2)

The guard takes **no authority** from `r_dom`. It takes authority from the **physical port**:

* port `p` has a **trusted binding** `allow[p]` (an `ND`-bit mask), programmed only through the privileged bus (`CMD_BIND_PORT`) and applied only through drain-then-commit;
* the request's `r_dom` is a *claim*: it must be `< ND` (else `FT_BADDOM`, `ST_PROTO`) and a member of `allow[p]` (else `FT_SPOOF`, `ST_DENIED`); only then is the region table of **that domain** consulted;
* the verified domain is stamped on the memory-side request (`m_dom`) for downstream second checks (e.g. MemoryMatrix `prot.secure`);
* reset clears every binding: a port is **dead** until the management plane binds it.

Typical use: a statically bound port (one domain, `allow` one-hot): any other claim is a `FT_SPOOF` event, logged against the physical port — the attempt itself is evidence. A port that
serves several domains (a shared DMA engine with a per-queue context) gets the set it may serve; its device context then chooses among them — assumption **A-CTX**: the
context that drives `r_dom` is trusted *within the binding*. The binding is the bound on what a compromised context can do.

Per-region **device permissions** (`DEV_EN`, `DEV_MASK`) add a second bound: even inside its domain, a region may be restricted to particular ports (e.g. the network port may write a receive buffer but the accelerator may not).

## 2. The privileged configuration interface

`cfg_*` is an SFB2-style 32-bit bus (the ControlCore `ext_*` master connects unchanged). Its **privilege qualifier** `cfg_req_priv` must be driven by the management plane only.

> **`cfg_req_priv` is a label. The control is physical exclusivity** (Citadel integration rule R6): the bus must be reachable only from the management plane, and the qualifier must come from a
> source a tenant cannot influence — ControlCore behind the secure-boot gate. The guard enforces the qualifier on every access (unprivileged: error, no effect, a read returns 0, counted); it
> cannot make a bus that a tenant can drive trustworthy.

What the repository offers as a root of trust is limited, and stated plainly:

| piece | what it is |
|---|---|
| ControlCore (P21) | "no firmware authentication, secure boot, root of trust or key storage" (its `09_LIMITATIONS.md`); the host and firmware share a mailbox the register bus cannot tell apart |
| SecureSilicon (P28) | Ed25519 + SHA-256 verification in simulation; OTP / lifecycle / anti-rollback are **models** ("not OTP / eFUSE hardware") |
| Citadel (P89) | a policy engine; reads "root of trust present" from a platform tie-off, not a register |

Therefore: **the guard's isolation is only as strong as the exclusivity of its configuration bus.** The guard adds three things on top:

1. **Validated, atomic updates** (`04`, `05`): a command is checked against the current table, then committed atomically with nothing in flight; staging registers freeze while it drains.
2. **Lock** (`CTRL.LOCK`, bit 31, set only): after it, no configuration write is accepted (except diagnostics) until reset. A platform that programs the guard once at boot and locks it has no runtime configuration attack surface at all.
3. **Evidence**: every refused access sets a sticky status bit and a saturating counter (`CN_SEC`, `CN_LOCKREJ`, `CN_CMDREJ`, `CN_TMO`); `R_GEN` counts committed changes so an auditor can see that the policy did (not) change.

## 3. Boot sequence (recommended)

1. Reset: every region invalid, every port unbound, lock clear (default deny).
2. The management plane (after secure boot) writes bindings, installs regions (`R_SEL`, `R_BASE`, `R_SIZE`, `R_ATTR`, `R_ALLOW`, `R_CMD`), polls `R_STATE.busy` and `R_GEN`, reads back the table (`R_RD_*`) to confirm.
3. Optionally set `R_DRAIN_TMO` and write `CTRL.LOCK`. Only then release the requesters' resets.
