# 01 — Architecture

```
 requester p (DMA | network | storage | accelerator)                         trusted management plane (ControlCore + secure-boot gate)
        │ r_*  (op, addr, len, data, id, domain CLAIM)                                        │ cfg_*  (SFB2 style, cfg_req_priv)
        ▼                                                                                   ▼
 ┌────────────────────────── sf_memory_guard ───────────────────────────────────────────────────────────────────────────┐
 │  NP × sf_memory_guard_port                                                        sf_memory_guard_regs                    │
 │   [A: request register] ──► sf_memory_guard_checker ◄── trusted binding of port p  privileged bus, LOCK, drain FSM ───┐   │
 │            │  (CHK_PIPE=1: [B: request + registered verdict])      ▲ region table                                    │   │
 │            │                                                       │                                                 │   │
 │   permit ──┴─► m_* (memory request, zero unless m_valid)    sf_memory_guard_regions ◄── validated, atomic installs ◄───┘   │
 │   deny   ───► one error response (+ one fault record) ───►  sf_memory_guard_faults  (privileged log + counters)           │
 └─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
        │ m_*  (verified domain stamped on every request)                                  responses: in order, per port
        ▼
   MemoryMatrix (or any memory with the same single-phase master port)
```

**Request → trusted domain identification → address and length validation → permission lookup → allow | reject → memory transaction.**
No other path from `r_*` to `m_*` exists in the design (`03`, formal property G1 / G3).

## Files

| file | role |
|---|---|
| `sf_memory_guard.sv` | top: ports, shared table, configuration engine, fault log; read-only export of the table for the adapters |
| `sf_memory_guard_port.sv` | **the enforcement point of one ingress port**: request register(s), checker, forward / deny, in-order responses, outstanding count, drain `idle` |
| `sf_memory_guard_checker.sv` | purely combinational verdict: `{permit, fault, domain}` from (request, port binding, region table) |
| `sf_memory_guard_regions.sv` | `ND × NR` region table, trusted port bindings, **validated** installs, overlap rejection, readback |
| `sf_memory_guard_regs.sv` | privileged configuration + diagnostic bus, lock, staging registers, **drain-then-commit** FSM |
| `sf_memory_guard_faults.sv` | fault log (FIFO), arbiter, saturating counters |
| `sf_memory_guard_pkg.sv` | codes (ABI, faults, commands, register map, counters) |
| `sf_memory_guard_grd_if.sv`, `sf_memory_guard_iommu_if.sv` | check-only adapters for the MeridianQoS and StreamDMA / CloudDMA contracts |

## Parameters (defaults in bold)

| parameter | meaning |
|---|---|
| `ND` (**4**), `NR` (**4**), `NP` (**4**, ≤ 8) | domains, regions per domain, protected ingress ports (default: DMA, network, storage, accelerator) |
| `AW` (**32**, ≤ 63), `DW` (**64**), `IDW` (**8**), `DOMW` (**3**) | byte-address width; data bus width (largest transfer = `DW/8` bytes); transaction id width; width of the domain-claim sideband (claims ≥ `ND` are *invalid domains*) |
| `MAXOUT` (**4**) | outstanding memory transactions per port |
| `CHK_PIPE` (**0**) | 0: verdict in the acting cycle (combinational from the request register); 1: registered verdict stage (+1 cycle, shorter path) |
| `LOOKUP_ARCH` (**0**) | 0: `ND·NR` parallel comparator sets, gated by the domain decode; 1: the claimed domain's `NR` entries are multiplexed out first, then `NR` comparator sets. Same function (proved equal) |
| `DIAG_PRECISE` (**1**) | 1: tell `FT_SPAN` from `FT_NOMAP` (two extra comparators per entry); never affects the decision |
| `STRICT` (**0**) | 1: overlapping regions are rejected across domains as well (strict partition; no shared memory) |
| `LEN_POW2` (**0**) | 1: only power-of-two lengths are legal (MemoryMatrix encodes the size as log2) |
| `FLOG_DEPTH` (**8**), `CNTW` (**32**) | fault-log records; counter width (saturating) |

## One request, step by step (`CHK_PIPE = 0`)

1. Cycle 0: `r_valid && r_ready` — the request (op, address, length, data, byte enables, id, domain claim) is captured in the **request register**. `r_ready` is low while ingress is blocked by a configuration drain.
2. Cycle 1: the checker evaluates the *registered* request against the *registered* table and the port's trusted binding. If it permits and an outstanding slot is free, `m_valid` rises with the payload (byte enables clipped to the length, the verified domain stamped); otherwise the port raises a denial.
3. Permitted: the memory answers in order; the response passes through (`OKAY`, or `SLVERR` if the memory failed). Denied: after every earlier response has been taken, **one** error response is issued (`DENIED` for a policy denial with no reason, `PROTO` for a malformed request), the data is `0`, and **one** fault record is written. Nothing was ever presented on `m_*` for a denied request, not even its address (formal G3).
4. A configuration command that arrives meanwhile blocks ingress, waits until every port is idle, and only then changes the table (`05`).
