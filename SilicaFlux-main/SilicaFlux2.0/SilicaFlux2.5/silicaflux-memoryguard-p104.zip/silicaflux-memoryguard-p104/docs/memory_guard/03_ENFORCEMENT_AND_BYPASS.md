# 03 — Enforcement, bypass prevention, and what connects where

## 1. The enforcement rule

Every master that can reach protected memory is wired to **one** ingress port `r_*`, and the memory's matching master input is wired to that port's
`m_*`. The guard has no other memory-side output, no bypass input and no parameter that lets a request skip the checker.

What the design gives, and what it proves (`08_VERIFICATION.md`):

| property | how it is established |
|---|---|
| `m_valid` ⇒ the oldest accepted request, which an **independent specification** permits for this port and the table; the memory-side request is that request bit for bit (G1) | k-induction, `fv_mg_port` (unbounded), through a refinement mapping onto the stage registers |
| every memory-side wire is 0 unless `m_valid` (G3) | same |
| the specification = the checker, for all inputs (S0) | `fv_mg_checker`, all inputs, depth 1 |
| the table changes only after a commit made with **every** port idle and ingress blocked (W1, C1) | `fv_mg_cfg`, `fv_mg_top` |
| the same properties hold end to end with a *real* memory behind the guard | `mm_random*` (MemoryMatrix), monitors M1–M6, memory-image canary |

"No unauthorised alternate path **inside** the guard" is therefore a theorem; "no unauthorised alternate path **to the memory**" is an integration
obligation, listed next.

## 2. Integration rules (things the guard cannot verify from inside)

| # | rule | why |
|---|---|---|
| **R1** | Every master reaches protected memory **only** through its guard port. No second port, no side-band, no debug master on the same memory without its own guard port | the guard has one downstream port per upstream port; the rest is wiring |
| **R2** | One physical master per guard port (the port index is the identity). Two masters may share a port only if they are entitled to the same domains | the domain claim is attacker-controlled; the **port** is the anchor |
| **R3** | `cfg_*` is physically reachable **only** from the management plane; drive `cfg_req_priv` from the ControlCore behind the secure-boot gate (Citadel R6) | `priv` is a label; physical exclusivity is the control |
| **R4** | `s_status` goes to the requester; the fault log and counters go to **privileged** software only | otherwise a tenant gets a layout oracle (`07`) |
| **R5** | A requester must not present a new request on a port whose response path it refuses to drain forever **if** it expects its own revocation to complete (`05` §4) | the drain waits for responses to be taken; `R_DRAIN_TMO` bounds the wait |
| **R6** | The memory returns responses **in order per port** (MemoryMatrix contract M2) and only for requests it accepted | the guard answers in order; an orphan response is dropped and counted, but a misordering memory would mis-pair ids |
| **R7** | Test / debug access to the memory (MBIST, JTAG, TestCore's unlock) must be disabled in production lifecycle states | it is an alternate path no master-port policy can see (Citadel finding 6) |
| **R8** | One reset for the guard and everything behind it; deassert synchronously | policy survives nothing across reset (default deny), and no transaction may survive it |
| **R9** | Check-only adapters are advisory: quiesce the master before revoking (the in-flight policy cannot see a grant held by an external master) | see `05` §5 |

## 3. What connects to what (honest status)

| block | interface it has | connection | status in this project |
|---|---|---|---|
| **MemoryMatrix** (P101) | single-phase master port, in-order, `size = log2` | guard `m_*` → matrix master `p`; `size = log2(len)` (`LEN_POW2 = 1`), `prot` from the verified domain, `status != 0 → d_err` | **built and run**: `mm_random` (4 banks, 64 KiB), `mm_random_ecc_pipe` (SECDED). End-to-end memory image equals the oracle |
| **StreamDMA** (P103) | AXI4 bursts via `sf_stream_dma_mm_bridge` → MemoryMatrix; `guard_*` check contract | (a) **inline**: guard port 0 between the bridge's master port and the matrix; (b) **check contract**: `sf_memory_guard_iommu_if` (bursts up to 4 KiB, identity `pa`) | adapter built and tested against the oracle (`adapters`); P103 RTL **not instantiated** here |
| **MeridianQoS** (P102) | `grd_*` check interface per fabric master; the fabric holds / denies | `sf_memory_guard_grd_if` replaces `sf_meridian_guard_ref` | adapter built and tested; P102 RTL **not instantiated**. Advisory (the fabric enforces) |
| **TensorCore** (TC08 SFB2 master) | SFB2 `req_write/addr/wdata/wstrb`, `MAX_OUT` ≤ 4 | an SFB2 → native bridge: `r_op = write`, `r_len = DW/8`, `r_be = wstrb`, response `rsp_error ← s_status != 0`; guard port 3 | **bridge not built** (mapping only) |
| **PacketForge** | **does not exist.** PacketCore (P62) is AXI-stream-like with no memory bus | a packet DMA front end would be a guard master on port 1 | **nothing to connect** |
| **VirtualIO** (P63) | its DMA backend master; windows bound per queue by the hypervisor | guard port 2 (storage), `r_dom` = the queue's hypervisor-bound domain | not built; its own windows stay as defence in depth |
| **ControlCore** (P21) | SFB2 master `ext_*` (32-bit) | drives `cfg_*`; `cfg_req_priv` from the secure-boot gate | bus-compatible; not instantiated |

## 4. Check-only versus inline

A **check-only** interface (P64 / P102 / P103 / the two adapters) returns a verdict; the *master* decides to obey it. Its guarantee is
exactly as strong as the master. An **inline** port (`sf_memory_guard_port`) is the only thing between the request and the memory, so it
needs nobody's cooperation: that is what "real, enforceable hardware isolation" means here, and what carries the proofs.
