# 08 — Verification: what was run, what it proves, what it does not

Everything here is machine-generated into `reports/` and reproducible (`make regress formal mutate`). Tools: Verilator 5.020, Yosys 0.33, `yosys-smtbmc` + z3 5.x.

## 1. The argument in one page

The security statement of the brief — *no unauthorised request can modify protected memory; every forbidden operation produces a reproducible error report* — is established by an
**assume-guarantee composition** of unbounded proofs, then exercised end to end by simulation:

```
 fv_mg_checker  (all inputs)     permit = independent specification; invalid domains, overflow, whole-range containment
        │ used by
 fv_mg_port     (unbounded)      ASSUME E1 E2 E4 (+E3)  ──►  GUARANTEE  m_valid ⇒ oldest accepted request, permitted by the specification for the table
        │                                                            memory-side request = accepted request, bit for bit;  nothing on m_* unless m_valid
        │                                                            one response per request, in order, DENIED / PROTO / OKAY / SLVERR, orphans never delivered
 fv_mg_cfg      (unbounded)      proves E4: the table changes only after a commit made with every port idle and ingress blocked,
        │                                    only after a privileged, unlocked, error-free R_CMD write, never after the lock
 fv_mg_regions  (unbounded)      the table never holds two overlapping valid regions; installs are validated; changes only on commit
 fv_mg_top      (unbounded)      E4 holds on the COMPOSED design; a commit never happens under any accepted-unanswered request (assumes port G6, proved above)
```

`E4` is the only assumption the port proof makes about the world around it that the *guard itself* must discharge, and it is discharged by `fv_mg_cfg` / `fv_mg_top`.
The other assumptions (E1 requester holds, E2 memory holds, E3 memory echoes) are protocol obligations of the neighbours (`10`).

## 2. Properties of the brief → evidence

| brief (§10) | property | evidence |
|---|---|---|
| denied writes produce no protected-memory modification | G1, G3: nothing is on `m_*` unless the specification permitted the request; M1/M2/M3 monitors; memory-image canary E1/E2 | `fv_mg_port` + `mm_random*` + `rnd_*` |
| invalid domains cannot issue authorised requests | S1 (all inputs), G1 | `fv_mg_checker`, `fv_mg_port` |
| address overflow never grants access | S2 (all inputs); directed T06 | `fv_mg_checker`, `tb_mg_directed` |
| cross-boundary requests are correctly checked | S3: one region contains the first byte, the last byte and any middle byte; directed T05 boundary sweep | `fv_mg_checker` |
| configuration is changed only by trusted control | C1–C4, W1, R2 | `fv_mg_cfg`, `fv_mg_top`, `fv_mg_regions` |
| invalid requests receive explicit failure responses | G5: every response is the right one, in order, with the request's id and no data on an error; no response without a request (**safety**) — that a response *arrives* (**liveness**) is checked by simulation only: every run ends by checking that every accepted request was answered | `fv_mg_port`, M4, E-checks |
| no unauthorised alternate path bypasses the checker | G1 + G3 inside the guard (a theorem); R1 around it (an integration rule) | `fv_mg_port`; `03` |

## 3. Simulation

| run | parameters | checks | result | what it covers |
|---|---|---:|---|---|
| dir_default | defaults | 7021 | **PASS** | default configuration: 4 domains x 4 regions, 4 ports, AW 16, DW 64 |
| dir_pipe1 | CHK_PIPE=1 | 7021 | **PASS** | registered verdict stage (+1 cycle) |
| dir_lookup1 | LOOKUP_ARCH=1 | 7021 | **PASS** | domain-first multiplexed lookup |
| dir_strict | STRICT=1 | 7019 | **PASS** | strict partition (no byte mapped for two domains) |
| dir_pow2_nodiag | LEN_POW2=1, DIAG_PRECISE=0 | 3885 | **PASS** | power-of-two lengths only; imprecise diagnostics |
| dir_out1 | MAXOUT=1 | 7021 | **PASS** | one outstanding memory transaction per port |
| dir_dw256_pipe | DW=256, CHK_PIPE=1, LOOKUP_ARCH=1 | 76213 | **PASS** | 256-bit data bus (MemoryMatrix width), registered, muxed |
| dir_nr8_log2 | NR=8, FLOG_DEPTH=2 | 7029 | **PASS** | 8 regions per domain, 2-entry fault log |
| vec_default | defaults | 240000 | **PASS** | 240k queries, AW 32, 4 x 4 table, both lookup architectures, fault codes included |
| vec_aw48_nd3_np5 | ND=3, NR=3, NP=5, AW=48 | 180000 | **PASS** | 3 domains, 5 ports, 48-bit addresses |
| vec_pow2_nodiag | AW=20, LEN_POW2=1, DIAG=0 | 180000 | **PASS** | power-of-two lengths, imprecise diagnostics |
| vec_maxlen32 | AW=16, NR=8, MAXLEN=32, LW=6 | 180000 | **PASS** | 32-byte beats (256-bit bus), 8 regions per domain |
| vec_aw63 | AW=63, NP=2 | 180000 | **PASS** | 63-bit address space (largest supported) |
| rnd_default | SEED=1 | 145123 | **PASS** | adversarial random, default configuration |
| rnd_default_s2 | SEED=2 | 142523 | **PASS** | adversarial random, seed 2 |
| rnd_pipe1 | SEED=3, CHK_PIPE=1 | 139003 | **PASS** | random, registered verdict |
| rnd_lookup1 | SEED=4, LOOKUP_ARCH=1 | 137520 | **PASS** | random, muxed lookup |
| rnd_strict | SEED=5, STRICT=1 | 153459 | **PASS** | random, strict partition |
| rnd_pow2 | SEED=6, LEN_POW2=1, DIAG_PRECISE=0 | 148035 | **PASS** | random, power-of-two lengths, imprecise diagnostics |
| rnd_out1 | SEED=7, MAXOUT=1, CHK_PIPE=1 | 142494 | **PASS** | random, one outstanding per port, registered |
| rnd_2x2x2 | SEED=8, ND=2, NR=2, NP=2 | 88266 | **PASS** | 2 domains, 2 regions, 2 ports |
| rnd_3x3x3 | SEED=9, ND=3, NR=3, NP=3 | 115634 | **PASS** | 3 domains (not a power of two), 3 regions, 3 ports |
| rnd_8x2x8 | SEED=10, ND=8, NR=2, NP=8 | 186209 | **PASS** | 8 domains (no invalid encodings), 8 ports |
| rnd_5x4x6_pipe_lk | SEED=11, ND=5, NR=4, NP=6, CHK_PIPE=1, LOOKUP_ARCH=1 | 175051 | **PASS** | 5 domains, 6 ports, registered + muxed |
| rnd_dw128 | SEED=12, DW=128 | 138446 | **PASS** | 128-bit data bus |
| rnd_dw32 | SEED=15, DW=32, MAXOUT=2 | 141903 | **PASS** | 32-bit data bus, 2 outstanding |
| mm_random | SEED=21, LEN_POW2=1, DIAG_PRECISE=0, NCYC=60000 | 61126 | **PASS** | INTEGRATION: the guard in front of the REAL MemoryMatrix (P101, 4 banks, 64 KiB), 4 requesters + host port; end-to-end memory image check |
| mm_random_ecc_pipe | SEED=22, LEN_POW2=1, NCYC=60000, CHK_PIPE=1, MM_ECC=1 | 59325 | **PASS** | INTEGRATION: MemoryMatrix with SECDED ECC, registered verdict |
| adapters | defaults | 63560 | **PASS** | check-only adapters: MeridianQoS grd_* and StreamDMA / CloudDMA IOMMU contracts vs the oracle (in-order registered verdicts, fault mapping, pa = addr) |
| adapters_pipe_lk | LOOKUP_ARCH=1, DIAG_PRECISE=0 | 63560 | **PASS** | the same, multiplexed lookup, imprecise diagnostics |
| abi_check | defaults | 12 | **PASS** | op codes, response status codes and the fault code points of the grd_* adapter equal the vendored P102 package |
| rnd_midreset | SEED=13, MIDRESET=1 | 137605 | **PASS** | reset under load in the middle of the run |
| rnd_deep_strict_pipe | SEED=14, STRICT=1, CHK_PIPE=1, NCYC=400000 | 395513 | **PASS** | 400k cycles, strict, registered |

**33 / 33 runs pass, 3,716,597 checks.**

Stimulus is adversarial (`tests/memory_guard/README.md`): the random runs issue 140–400 thousand requests each, **most of them denied by construction**, from four ports at once, with a
background agent changing the policy while they run (about 900 commits per run, ~99 % with traffic in flight).

## 4. Formal

| job | kind | parameters | result | s | establishes |
|---|---|---|---|---:|---|
| chk_arch0 | comb | ND=4, NR=2, NP=3, AW=8, LW=3, PIDX=1, MAXLEN=5, ARCH=0, DIAG=1 | **PASSED** | 4.8 | S0..S5: permit and fault code = independent specification; invalid domains, overflow, whole-range containment (first AND last AND any byte), right and device permission; arch 1 and imprecise diagnostics agree |
| chk_arch1 | comb | ND=4, NR=2, NP=3, AW=8, LW=3, PIDX=1, MAXLEN=5, ARCH=1, DIAG=1 | **PASSED** | 7.6 | the same with the domain-first multiplexed lookup as the design under proof |
| chk_nd3 | comb | ND=3, NR=3, NP=4, AW=10, LW=3, PIDX=3, MAXLEN=6, ARCH=0, DIAG=0 | **PASSED** | 8.8 | 3 domains (not a power of two), 3 regions, 4 ports, imprecise diagnostics |
| chk_pow2 | comb | ND=2, NR=3, NP=2, AW=9, LW=4, PIDX=0, MAXLEN=8, ARCH=1, DIAG=1, LEN_POW2=1 | **PASSED** | 15.3 | power-of-two lengths only |
| chk_nr4 | comb | ND=2, NR=4, NP=3, AW=10, LW=4, PIDX=2, MAXLEN=8, ARCH=0, DIAG=1 | **PASSED** | 67.0 | 4 regions per domain, 10-bit addresses (the full 4 x 4 x 32-bit instance is beyond z3 -- see docs/memory_guard/08_VERIFICATION.md; the Python vectors cover it by simulation) |
| chk_aw63 | comb | ND=2, NR=2, NP=2, AW=63, LW=4, PIDX=1, MAXLEN=8, ARCH=1, DIAG=1 | **PASSED** | 6.6 | 63-bit address space (largest supported) |
| regions_ns | prove | ND=3, NR=2, NP=3, AW=6, STRICT=0 | **PASSED** | 1.2 | R0..R5: default deny, table invariant (no overlap within a domain, well-formed regions), changes only on commit, validation = specification, effect of each command |
| regions_st | prove | ND=3, NR=2, NP=3, AW=6, STRICT=1 | **PASSED** | 5.4 | the same with STRICT partition (no overlap across domains either) |
| regions_big | prove | ND=4, NR=3, NP=4, AW=8, STRICT=0 | **PASSED** | 3.8 | 4 domains x 3 regions, 4 ports, AW 8 |
| cfg_ns | prove | ND=3, NR=2, NP=2, AW=6, STRICT=0 | **PASSED** | 3.6 | C1..C7: drain-then-commit, trusted control, lock, privilege, abort, ingress block |
| cfg_st | prove | ND=3, NR=2, NP=2, AW=6, STRICT=1 | **PASSED** | 19.0 | the same with STRICT partition |
| port_p0_a0 | prove | CHK_PIPE=0, ARCH=0 | **PASSED** | 11.3 | G1..G7, unbounded: only permitted requests reach the memory, bit for bit; denials; ordered responses; blocking; idle |
| port_p0_a1 | prove | CHK_PIPE=0, ARCH=1 | **PASSED** | 13.8 | the same with the multiplexed lookup |
| port_p1_a0 | prove | CHK_PIPE=1, ARCH=0 | **PASSED** | 131.9 | the same with the registered verdict stage (two requests held) |
| port_p1_a1 | prove | CHK_PIPE=1, ARCH=1 | **PASSED** | 164.0 | registered verdict, multiplexed lookup |
| port_orphan0 | prove | CHK_PIPE=0, ORPHAN=1 | **PASSED** | 9.8 | orphan memory responses are drained and never delivered (the memory is NOT assumed well behaved) |
| port_orphan1 | prove | CHK_PIPE=1, ORPHAN=1 | **PASSED** | 113.8 | the same with the registered verdict stage |
| port_pow2 | prove | CHK_PIPE=1, LEN_POW2=1, DIAG=0, MAXOUT=1 | **PASSED** | 85.1 | power-of-two lengths, imprecise diagnostics, one outstanding transaction |
| port_big | prove | CHK_PIPE=0, ND=4, NR=2, NP=3, AW=8, DW=32, IDW=3, LW=3, MAXLEN=4, MAXOUT=3, PIDX=2 | **PASSED** | 77.8 | 4 domains, 3 ports, AW 8, 32-bit data, 3 outstanding |
| top_p0 | prove | CHK_PIPE=0 | **PASSED** | 4.4 | W1..W5 on the composed design: the table changes only after a commit with every port idle and ingress blocked; no commit under any accepted-unanswered request; blocking_o => not ready |
| top_p1 | prove | CHK_PIPE=1 | **PASSED** | 4.6 | the same with the registered verdict stage |
| top_st | prove | CHK_PIPE=0, STRICT=1 | **PASSED** | 13.0 | the same with STRICT partition |

* **22 / 22** proofs pass. `comb` = proved for **all** inputs. `prove` = base case from reset + k-induction: **unbounded**, on the stated tiny configuration.
* **29 / 29** reachability witnesses fail as they must: the environment assumptions leave permitted writes, denials of every class, full outstanding windows, held-back requests,
  commits with regions installed, timeouts and locks reachable — the proofs are not vacuous.
* **35 / 35** formal mutant checks were killed (`reports/formal.md`).

## 5. Mutation campaign (simulation)

One planted RTL defect each (`scripts/mutants.py`). **31 / 33 killed.**

| mutant | defect | killed by | result |
|---|---|---|---|
| C01 | lower bound of the region ignored (access below the base is granted) | tb_checker_vec (Python vectors) | **KILLED** |
| C02 | only the FIRST byte is checked against the end of the region (the classic bug the brief warns about) | tb_checker_vec (Python vectors) | **KILLED** |
| C03 | address overflow not detected | tb_checker_vec (Python vectors) | **KILLED** |
| C04 | trusted port binding ignored (any port may claim any domain) | tb_checker_vec (Python vectors) | **KILLED** |
| C05 | a WRITE is checked against the READ right | tb_checker_vec (Python vectors) | **KILLED** |
| C06 | device permissions ignored | tb_checker_vec (Python vectors) | **KILLED** |
| C07 | zero-length transfers accepted | tb_checker_vec (Python vectors) | **KILLED** |
| C08 | a region of ANY domain grants the access (no domain isolation) | tb_checker_vec (Python vectors) | **KILLED** |
| C09 | invalid domain numbers accepted as a valid domain | tb_checker_vec (Python vectors) | **KILLED** |
| C10 | over-long transfers accepted | tb_checker_vec (Python vectors) | **KILLED** |
| F01 | the fault log overwrites when full | tb_mg_random | **KILLED** |
| P01 | the verdict is not consulted: every request reaches the memory | tb_mg_random | **KILLED** |
| P02 | an error response may overtake earlier responses | tb_mg_random | **KILLED** |
| P03 | byte enables are not clipped to the length | tb_mg_random | **KILLED** |
| P04 | write data of a DENIED request is driven onto the memory side | tb_mg_random | **KILLED** |
| P05 | ingress is not blocked during a configuration drain | tb_mg_random | **KILLED** |
| P06 | an orphan memory response is delivered to the requester | tb_mg_directed | **KILLED** |
| P07 | idle ignores a pending error response (the drain can commit under a request) | tb_mg_random | **KILLED** |
| P08 | malformed requests are answered DENIED instead of PROTO | tb_mg_random | **KILLED** |
| P09 | the address of a denied request is driven onto the memory side | tb_mg_random | **KILLED** |
| P10 | a request is forwarded while an error response is still pending (response reordering) | - | **SURVIVED** — internal-invariant mutant: forwarding while an error response is pending is masked at the interface by the response multiplexer (the error response keeps priority, so order is preserved); killed formally by fv_mg_port (invariant R4: an error response only exists with nothing outstanding) |
| P11 | an error response carries memory data | tb_mg_random | **KILLED** |
| R01 | overlapping regions are accepted at install time | tb_mg_random | **KILLED** |
| R02 | base + size may leave the address space | tb_mg_random | **KILLED** |
| R03 | re-installing a slot over itself is reported as an overlap | tb_mg_random | **KILLED** |
| R04 | an invalid command is written to the table when cm_en is raised | - | **SURVIVED** — redundant defence in depth: in the integrated design cm_en is raised only for a command the engine has validated, so no simulation can reach it; killed formally by fv_mg_regions (cm_en free) |
| S01 | the table is committed without waiting for the datapath to drain (TOCTOU) | tb_mg_random | **KILLED** |
| S02 | the configuration lock does not lock | tb_mg_directed | **KILLED** |
| S03 | unprivileged accesses are performed (privilege not checked) | tb_mg_random | **KILLED** |
| S04 | ingress is not blocked while a command drains | tb_mg_random | **KILLED** |
| S05 | an invalid command starts a drain and commits | tb_mg_random | **KILLED** |
| S06 | the lock can be cleared by a write to CTRL | tb_mg_directed | **KILLED** |
| T01 | drained = ANY port idle (instead of all) | tb_mg_random | **KILLED** |

Survivors are reported, not hidden. Both are **not observable at the interfaces of the integrated design** and both **are killed by the formal harnesses**:
**R04** plants a defect in a *redundant* guard (the table also refuses an invalid command inside the regions module, in addition to the engine that raises `cm_en` only for a
validated command), unreachable in the integrated design; killed by `fv_mg_regions`, where `cm_en` is a free input. **P10** lets a port forward a request while an earlier error
response is still pending: the response multiplexer keeps the error response first, so the order seen by the requester is unchanged and no simulation can see it; killed by
`fv_mg_port` through the invariant *an error response only exists with nothing outstanding*. The whole-design mutation kill list is in `reports/formal.md` (35 formal kills of 33 mutants).

## 6. What was NOT verified

* **Liveness** (a response always arrives; a drain always ends) — simulation evidence only; the drain has a timeout by design.
* The fault log / counters — simulation only (directed T13, random E3 tallies, mutant F01).
* **Full-size** instances as single formal problems: the proofs use `ND ≤ 4`, `NR ≤ 4`, `NP ≤ 3`, `AW ≤ 10` (the checker also at `AW = 63`). The 4 × 4 × 32-bit checker is covered by 240 000 Python-model vectors and by simulation.
* The **composition** is proved only for W1–W5 (E4, blocking, no commit under work); the full-system statement is the assume-guarantee argument of §1, not a monolithic proof.
* No gate-level or post-synthesis simulation; no second RTL simulator as oracle; no silicon.
