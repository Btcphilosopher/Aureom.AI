# 04 — Regions, range checking, and the overlap decision

## 1. Region descriptor

`{ valid, base[AW], end[AW+1] (exclusive), R, W, DEV_EN, DEV_MASK[NP] }`, `ND × NR` entries, byte granular. The table stores `end = base + size`,
computed (in 65 bits) and validated **at install time**, so the lookup compares two numbers per entry and never adds.

Installing a region is a *command* (`R_CMD`), validated against the current table before anything is written:

| check | refusal |
|---|---|
| domain `< ND`, region `< NR`, reserved device bits zero | `CE_INDEX` |
| `size ≥ 1`, `base < 2^AW`, `base + size ≤ 2^AW` (65-bit sum, no wrap) | `CE_RANGE` |
| no overlap with another valid region (same domain; any domain with `STRICT`) | `CE_OVERLAP` |

A refused command changes nothing and does not block the datapath. Reset clears every `valid` bit and every binding: **default deny**.

## 2. The decision (single-region containment)

A request `(op, addr, len, domain claim)` from port `p` is permitted iff **all** hold (`sf_memory_guard_checker`, header):

1. `op` is READ or WRITE; 2. `1 ≤ len ≤ DW/8` (power of two with `LEN_POW2`); 3. `addr + len ≤ 2^AW` — computed in **`AW+1` bits**, so a wrapping transfer can never alias a low address;
4. the claim is `< ND`; 5. the claim is inside the **trusted binding of port `p`**; 6. **one** valid region of that domain contains **the whole transfer**: `base ≤ addr` and `addr + len ≤ end`;
7. if the region has device permissions, port `p`'s bit is set; 8. the region grants the right (read or write).

A request is never authorised by its first byte: the last byte `addr + len - 1` must lie in the **same** region (S3 proves the first byte, the last byte and a free byte
in between). **Boundary-spanning and partially overlapping transfers are denied** (`FT_SPAN`), including a transfer that spans two *adjacent* regions of one domain — to
allow it, program one larger region. The diagnosis (`FT_NOMAP` vs `FT_SPAN`) is first-match and never changes the decision (S5).

Fault priority (first match wins): `BADOP > ZEROLEN > BADLEN > OVERFLOW > BADDOM > SPOOF > (permit) > DEVICE > PERM > SPAN > NOMAP`.

## 3. The overlap decision (priority vs rejection)

**Decision: overlapping regions are rejected at install time; there is no priority.** Reasons: a priority rule makes the *effective* policy depend on slot order — a
classic source of "the deny region was shadowed" mistakes; with rejection, within one domain **at most one region can contain any byte**, the lookup is a pure OR, and the
table has an inductive invariant (`I-TBL`, proved) that a reviewer can state in one line.

* `STRICT = 0` (default): the rule is per domain; two *different* domains may map the same bytes (shared read-only model weights, a shared mailbox). Each domain still sees a conflict-free table.
* `STRICT = 1`: the rule is global — **no byte is ever mapped for two domains** (a strict partition; no sharing). This gives the strongest cross-domain isolation statement the table can make.
* Re-installing a slot over itself is allowed (that is how a region is resized); adjacent (`end == base`) regions are not an overlap.

## 4. Parallel comparators and the two lookup structures

Each entry has comparators `addr ≥ base` and `addr + len ≤ end` (the *decision*), plus — only for the diagnosis — `addr < end` and `base < addr + len`.

| `LOOKUP_ARCH` | structure | area | logic depth |
|---|---|---|---|
| 0 | `ND·NR` comparator sets in parallel, results gated by the one-hot domain decode | grows with `ND·NR` | one comparator + an OR tree |
| 1 | the `NR` entries of the claimed domain are multiplexed out (AND-OR over `ND`), then `NR` comparator sets | grows with `NR` + `ND·NR·width` mux bits | a mux level + a comparator + an OR |

The two are **proved equal for all inputs** (S5). `09_PHYSICAL.md` measures both.
