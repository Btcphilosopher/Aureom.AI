# 05 — In-flight permissions: the policy, why, and what it costs

## 1. The problem

A request is *checked* at one time and *used* (reaches the memory, or returns data) at a later time. If the permission table can change in between, three
time-of-check / time-of-use bypasses exist:

* a **revoked** region is still written by a request that was checked before the revocation;
* a **new** (narrower or different) table is applied to a request that was accepted under the old one, so the request's verdict is not the verdict anyone configured;
* a **read** whose data was fetched before the revocation is delivered after it.

## 2. The options considered

| option | idea | verdict |
|---|---|---|
| **A. drain, then commit** *(chosen)* | block ingress, let everything in flight finish, change the table in a cycle with nothing in flight, release | simple; the strongest statement ("no transaction ever lives across a table change"); cost = a stall of the datapath for the length of the drain, **only** while a valid command is pending |
| B. versioned snapshot | stamp each request with a table generation; keep the old generation readable until its requests retire | needs two copies of the table (or copy-on-write) and per-request tags; **a revoked region keeps working for in-flight requests** — the exact TOCTOU the brief forbids |
| C. per-domain / per-port drain | block only the ports that can act for the changed domain | a smaller stall, but needs the binding-to-domain relation in the drain logic and a proof per case; not needed for a first, provable engine |
| D. squash / abort in-flight | cancel what is outstanding | cannot cancel a write the memory has accepted; needs poison / zero-strobe completion of partial bursts; deferred |

## 3. The implemented policy (A), exactly

`sf_memory_guard_regs`, states `IDLE` and `DRAIN` (`R_STATE.busy`):

```
IDLE  --(privileged, unlocked, error-free write of R_CMD, validated against the table)-->  DRAIN
        blk = 1 from the NEXT cycle: no port accepts a request.  Requests already accepted keep going.
DRAIN: every port idle? (nothing held, nothing outstanding at the memory, no error response pending)
        yes -> COMMIT: cm_en for ONE cycle; the table changes at the end of that cycle; gen++; blk = 0; STAT_DONE
        no  -> wait; if R_DRAIN_TMO != 0 and R_DRAIN_TMO cycles passed -> ABORT: nothing changes, blk = 0, STAT_TMO, last_err = CE_TMO
```

* `blk` is a **register**; `r_ready = !blk && …`. So in the commit cycle (blk = 1) no request can be accepted, and every port is idle: **no request is in flight at the moment the table changes.** The first request accepted afterwards is checked against the new table.
* "idle" counts the request register(s), the **outstanding memory transactions until their responses have been taken by the requester**, and a pending error response. A read's data is therefore delivered before the revocation commits.
* Commands that are **invalid** are refused at once (error response, `STAT_E*`) and do **not** block the datapath. Staging registers and `R_SEL` are frozen while a command drains (writes are refused with `STAT_BUSY`), so the validated command is the committed command.
* The lock cannot be set while a command is draining; a command cannot start after the lock.

## 4. What is proved (see `08`)

* **E4 / W1 / C1**: the table (valid bits, bindings, base, end) changes only in a cycle following a commit; a commit happens only with every port idle and `blk` = 1, only for a command that validates against the current table, only after an accepted privileged R_CMD write, never after the lock.
* **G1–G7 under E4** (`fv_mg_port`, unbounded): a request's verdict is the specification's verdict for *the table it was accepted under*, and it is still that table when the request is used — because nothing changes in between.
* In simulation: monitor **M1** re-evaluates every memory-side transaction against the oracle's policy *at that cycle* (a stale verdict would fail), **M6** checks that every commit finds the TB's queues empty; mutants S01 (commit without drain), S04 (no block), S05, T01, P07 are killed (`reports/mutation.md`, `reports/formal.md`).
* In the directed test T09: a revocation with four slow writes outstanding commits only after they finish; a request offered during the drain waits ≈ the whole drain; the old writes land, the next write is denied.

## 5. Honest limits

1. **A requester that never takes its response, or a memory that never answers, delays the commit.** This cannot make the table unsafe, but it can make a *revocation* late. `R_DRAIN_TMO` bounds the wait: on expiry the change is **not applied** (so the old, wider policy stays in force) and ingress is released; the management plane then decides (reset the requester, retry, or reset the guard). There is no forced squash (option D).
2. While a command drains, **all ports stall**, including ports whose domains are not affected (option C would narrow this). The stall is the drain length, bounded by the outstanding transactions (`MAXOUT` per port) and the memory latency.
3. **Check-only adapters are outside this protocol**: a grant given through `grd_if` / `iommu_if` is held by the *master*, which the guard cannot see. Quiesce those masters before revoking (P102 and P103 say the same).
4. The proof assumes the **memory side is in-order** (MemoryMatrix contract) and, for G5's id equality, that the memory echoes ids; an orphan or misrouted response is discarded, not trusted (`port_orphan*`).
