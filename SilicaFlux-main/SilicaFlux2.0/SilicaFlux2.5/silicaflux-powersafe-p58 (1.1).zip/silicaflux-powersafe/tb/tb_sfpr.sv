// =============================================================================
// SilicaFlux PowerSafe (Project 58) :: tb_sfpr -- unit testbench of
// silicaflux_storage_recovery.  Runs on Verilator (--binary --timing) and on
// Icarus Verilog 12 (-g2012).
//
// The bench plays three roles around the DUT:
//   host        submits commands (unique id in ADDR), collects completions with
//               random back-pressure;
//   queue       accepts forwarded commands with random back-pressure (stands
//               in for sfs_cmd_ctrl; the co-simulation uses the real one);
//   firmware    reports phases, posts completions, drives the control page.
// A scoreboard, independent of the DUT, checks every host completion:
//   - exactly one completion per admitted command, tagged with its host TID;
//   - SUCCESS of a durability-requiring command only after the bench reported
//     DURABLE for it; a volatile SUCCESS only with WCE at admission, no FUA and
//     BUFFERED reported; a FLUSH SUCCESS only when every write acknowledged-
//     volatile before the FLUSH was admitted had been reported DURABLE;
//   - ready/valid protocol on both output channels (payload stable, no
//     withdrawal).
// Plusargs: +TEST=<name|all> +SEED=<n> +ITER=<n> (random test iterations)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sfpr;
  import silicaflux_storage_pkg::*;
  import sfpr_regs_pkg::*;

  parameter int NS   = 8;
  parameter bit PLP  = 1'b0;
  parameter int PLPQ = 0;

  // ---------------------------------------------------------------- DUT
  logic clk = 1'b0, por_n = 1'b0, rst_n = 1'b0, pwr_fail_n = 1'b1, shn = 1'b0;
  logic cmd_in_valid = 1'b0, cpl_out_ready = 1'b1, cmd_out_ready = 1'b1, cpl_in_valid = 1'b0;
  logic cmd_in_ready, cpl_out_valid, cmd_out_valid, cpl_in_ready;
  sfs_cmd_t cmd_in, cmd_out;
  sfs_cpl_t cpl_out, cpl_in;
  logic rb_sel = 1'b0, rb_we = 1'b0;
  logic [11:0] rb_addr = '0;
  logic [31:0] rb_wdata = '0, rb_rdata;
  logic rb_err, nand_busy = 1'b0, nand_inhibit, wp_force, quiesce, rdy, ro, fatal, pf_active, irq;
  logic [1:0] shst;
  logic ci_crash, ci_pf, ci_warm;

  always #5 clk = ~clk;

  silicaflux_storage_recovery #(.N_SLOTS(NS), .HWQ_DEPTH(4), .PLP_PRESENT(PLP), .PLP_QUALIFICATION_ID(PLPQ),
                                .CRASH_INJ_EN(1'b1)) dut (
    .clk, .por_n, .rst_n, .pwr_fail_ni(pwr_fail_n), .shn_req_i(shn),
    .cmd_in_valid, .cmd_in_ready, .cmd_in, .cpl_out_valid, .cpl_out_ready, .cpl_out,
    .cmd_out_valid, .cmd_out_ready, .cmd_out, .cpl_in_valid, .cpl_in_ready, .cpl_in,
    .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .nand_busy_i(nand_busy), .nand_inhibit_o(nand_inhibit), .wp_force_o(wp_force), .quiesce_o(quiesce),
    .rdy_o(rdy), .ro_o(ro), .fatal_o(fatal), .pf_active_o(pf_active), .shst_o(shst), .irq_o(irq),
    .ci_crash_o(ci_crash), .ci_pf_o(ci_pf), .ci_warm_o(ci_warm)
  );

  // ---------------------------------------------------------------- bookkeeping
  int n_checks = 0, n_fail = 0, n_tests = 0, n_tfail = 0;
  reg [8*24-1:0] cur_test;          // packed (Icarus 12 string limitations)
  task check(input bit c, input reg [8*120-1:0] msg);   // static, packed message: Icarus 12 string limitations
    n_checks++;
    if (!c) begin
      n_fail++;
      $display("  FAIL [%0s] %0s (t=%0t)", cur_test, msg, $time);
    end
  endtask

  logic [31:0] rng = 32'h1234_5678;
  function automatic logic [31:0] rnd();
    rng = rng ^ (rng << 13);
    rng = rng ^ (rng >> 17);
    rng = rng ^ (rng << 5);
    return rng;
  endfunction
  function automatic int rint(input int n);   // 0 .. n-1
    return int'(rnd() % 32'(n));
  endfunction

  localparam int MAXID = 4096;
  // per command id (host view)
  logic [2:0]  c_cls   [MAXID];
  logic        c_fua   [MAXID];
  logic        c_wce   [MAXID];
  logic [15:0] c_tid   [MAXID];
  int          c_ncpl  [MAXID];
  logic [6:0]  c_st    [MAXID];
  logic        c_sub   [MAXID];   // submitted (handshake done)
  logic        c_lost  [MAXID];   // outstanding at a controller reset: no completion expected
  logic [2:0]  c_ph    [MAXID];   // highest phase the bench reported
  logic        c_volopen [MAXID]; // host saw a volatile SUCCESS; not yet DURABLE
  logic        c_retired [MAXID];
  int          fdep_n  [MAXID];
  int          fdep    [MAXID][16];
  int          next_id = 1;
  int          tid2id  [1024];
  logic        tid_busy[1024];
  // per slot (queue view)
  logic        q_has   [32];
  int          q_id    [32];
  logic        q_fwdone[32];      // firmware posted its completion
  int          n_hostcpl = 0;
  logic        wce_now = 1'b0;
  int          host_rdy_pct = 100, dn_rdy_pct = 100;

  function automatic logic [2:0] cls_of(input logic [7:0] op);
    case (op)
      8'(SFS_OP_READ):       return SFPR_CLS_READ;
      8'(SFS_OP_WRITE):      return SFPR_CLS_WRITE;
      8'(SFS_OP_DEALLOCATE): return SFPR_CLS_TRIM;
      8'(SFS_OP_FLUSH):      return SFPR_CLS_FLUSH;
      default:               return SFPR_CLS_OTHER;
    endcase
  endfunction

  // ---------------------------------------------------------------- random back-pressure
  always @(negedge clk) begin
    cpl_out_ready <= (rint(100) < host_rdy_pct);
    cmd_out_ready <= (rint(100) < dn_rdy_pct);
  end

  // ---------------------------------------------------------------- queue model: accept forwarded commands
  always @(posedge clk) begin
    if (cmd_out_valid && cmd_out_ready && rst_n && por_n) begin
      int s;
      s = int'(cmd_out.tid);
      if (s >= NS) begin
        n_checks++; n_fail++; $display("  FAIL forwarded TID %0d out of slot range", s);
      end else begin
        if (q_has[s]) begin n_checks++; n_fail++; $display("  FAIL slot %0d forwarded twice", s); end
        q_has[s] <= 1'b1;
        q_id[s]  <= int'(cmd_out.addr[31:0]);
        q_fwdone[s] <= 1'b0;
      end
    end
  end

  // ---------------------------------------------------------------- host completion scoreboard
  always @(posedge clk) begin
    if (cpl_out_valid && cpl_out_ready && rst_n && por_n) begin
      int id;
      logic dur_needed;
      n_hostcpl++;
      id = (int'(cpl_out.tid) < 1024) ? tid2id[cpl_out.tid] : 0;
      n_checks++;
      if (id == 0 || !tid_busy[cpl_out.tid]) begin
        n_fail++; $display("  FAIL [%0s] completion for TID %0d not outstanding", cur_test, cpl_out.tid);
      end else begin
        c_ncpl[id] = c_ncpl[id] + 1;
        c_st[id]   = cpl_out.status;
        tid_busy[cpl_out.tid] = 1'b0;
        if (c_ncpl[id] != 1) begin n_fail++; $display("  FAIL [%0s] id %0d completed %0d times", cur_test, id, c_ncpl[id]); end
        if (cpl_out.status == 7'(SFS_ST_SUCCESS)) begin
          dur_needed = c_cls[id] == SFPR_CLS_TRIM || c_cls[id] == SFPR_CLS_FLUSH ||
                       (c_cls[id] == SFPR_CLS_WRITE && (c_fua[id] || !(c_wce[id] || PLP)));
          n_checks++;
          if (dur_needed && c_ph[id] != SFPR_PH_DURABLE) begin
            n_fail++; $display("  FAIL [%0s] id %0d SUCCESS before DURABLE (phase %0d)", cur_test, id, c_ph[id]);
          end
          if (c_cls[id] == SFPR_CLS_WRITE && !dur_needed) begin
            n_checks++;
            if (c_ph[id] < SFPR_PH_BUFFERED) begin
              n_fail++; $display("  FAIL [%0s] id %0d volatile SUCCESS before BUFFERED", cur_test, id);
            end
            if (c_ph[id] != SFPR_PH_DURABLE) c_volopen[id] = 1'b1;
          end
          if (c_cls[id] == SFPR_CLS_FLUSH) begin
            for (int k = 0; k < fdep_n[id]; k++) begin
              n_checks++;
              if (c_ph[fdep[id][k]] != SFPR_PH_DURABLE) begin
                n_fail++; $display("  FAIL [%0s] FLUSH id %0d SUCCESS with dependency %0d not durable", cur_test, id, fdep[id][k]);
              end
            end
          end
        end
      end
    end
  end

  // ---------------------------------------------------------------- protocol monitors
  logic pv_cpl = 1'b0, pv_cmd = 1'b0;
  sfs_cpl_t p_cpl;
  sfs_cmd_t p_cmd;
  always @(posedge clk) begin
    if (rst_n && por_n) begin
      if (pv_cpl) begin
        n_checks++;
        if (!cpl_out_valid || cpl_out != p_cpl) begin n_fail++; $display("  FAIL [%0s] cpl_out withdrawn / changed while stalled", cur_test); end
      end
      if (pv_cmd) begin
        n_checks++;
        if (!cmd_out_valid || cmd_out != p_cmd) begin n_fail++; $display("  FAIL [%0s] cmd_out withdrawn / changed while stalled", cur_test); end
      end
      pv_cpl <= cpl_out_valid && !cpl_out_ready;
      p_cpl  <= cpl_out;
      pv_cmd <= cmd_out_valid && !cmd_out_ready;
      p_cmd  <= cmd_out;
    end else begin
      pv_cpl <= 1'b0; pv_cmd <= 1'b0;
    end
  end

  // ---------------------------------------------------------------- bus / host / firmware tasks
  task automatic wr(input logic [11:0] a, input logic [31:0] d);
    @(negedge clk);
    rb_sel = 1'b1; rb_we = 1'b1; rb_addr = a; rb_wdata = d;
    @(posedge clk); #1;
    rb_sel = 1'b0; rb_we = 1'b0;
  endtask
  task automatic rd(input logic [11:0] a, output logic [31:0] d);
    @(negedge clk);
    rb_sel = 1'b1; rb_we = 1'b0; rb_addr = a;
    #1 d = rb_rdata;
    @(posedge clk); #1;
    rb_sel = 1'b0;
  endtask
  task automatic rd_err(input logic [11:0] a, input bit we, output logic e);
    @(negedge clk);
    rb_sel = 1'b1; rb_we = we; rb_addr = a; rb_wdata = 32'h0;
    #1 e = rb_err;
    @(posedge clk); #1;
    rb_sel = 1'b0; rb_we = 1'b0;
  endtask
  function automatic logic [3:0] fsm_now();
    return dut.st;
  endfunction
  task automatic cycles(input int n);
    repeat (n) @(posedge clk);
    #1;
  endtask

  // submit; returns the command id (0 if the host had no free TID)
  task automatic submit(input logic [7:0] op, input logic fua, output int id);
    int tid;
    sfs_cmd_t c;
    tid = -1;
    for (int t = 0; t < 1024 && tid < 0; t++) begin
      int u;
      u = (int'(rnd() % 32'd200) + t) % 200 + 1;
      if (!tid_busy[u]) tid = u;
    end
    id = next_id++;
    c = '0;
    c.opcode = op;
    c.dir    = sfs_op_dir(op);
    c.flags  = fua ? 8'h02 : 8'h00;
    c.tid    = 16'(tid);
    c.addr   = 64'(id);
    c.len    = 32'd1;
    c_cls[id] = cls_of(op); c_fua[id] = fua; c_wce[id] = wce_now; c_tid[id] = 16'(tid);
    c_ncpl[id] = 0; c_sub[id] = 1'b0; c_lost[id] = 1'b0; c_ph[id] = SFPR_PH_ACCEPTED; c_volopen[id] = 1'b0;
    c_retired[id] = 1'b0; fdep_n[id] = 0;
    tid2id[tid] = id;
    tid_busy[tid] = 1'b1;
    @(negedge clk);
    cmd_in = c;
    cmd_in_valid = 1'b1;
    begin
      logic hs;
      hs = 1'b0;
      while (!hs) begin
        #1 hs = cmd_in_ready;
        if (hs && cls_of(op) == SFPR_CLS_FLUSH)      // dependencies = volatile acks seen so far
          for (int k = 1; k < id; k++)
            if (c_volopen[k] && !c_retired[k] && fdep_n[id] < 16) begin fdep[id][fdep_n[id]] = k; fdep_n[id]++; end
        @(posedge clk);
        if (!hs) @(negedge clk);
      end
    end
    #1 cmd_in_valid = 1'b0;
    c_sub[id] = 1'b1;
  endtask

  // submit with an explicit host TID (conflict tests)
  task automatic submit_tid(input logic [7:0] op, input int tid, output int id);
    sfs_cmd_t c;
    id = next_id++;
    c = '0; c.opcode = op; c.dir = sfs_op_dir(op); c.tid = 16'(tid); c.addr = 64'(id); c.len = 32'd1;
    c_cls[id] = cls_of(op); c_fua[id] = 1'b0; c_wce[id] = wce_now; c_ncpl[id] = 0; c_ph[id] = SFPR_PH_ACCEPTED;
    c_volopen[id] = 1'b0; c_retired[id] = 1'b0; fdep_n[id] = 0; c_lost[id] = 1'b0;
    tid2id[tid] = id; tid_busy[tid] = 1'b1;    // forced: conflict tests restore the mapping
    @(negedge clk);
    cmd_in = c; cmd_in_valid = 1'b1;
    begin
      logic hs;
      hs = 1'b0;
      while (!hs) begin
        #1 hs = cmd_in_ready;
        @(posedge clk);
        if (!hs) @(negedge clk);
      end
    end
    #1 cmd_in_valid = 1'b0;
  endtask

  function automatic int slot_of(input int id);
    for (int s = 0; s < NS; s++) if (q_has[s] && q_id[s] == id) return s;
    return -1;
  endfunction

  task automatic wait_fwd(input int id, output int s);
    s = slot_of(id);
    for (int k = 0; k < 200 && s < 0; k++) begin @(posedge clk); #1 s = slot_of(id); end
  endtask

  task automatic phase(input int s, input logic [2:0] ph, output logic [2:0] res);
    logic [31:0] r;
    wr(SFPR_PHASE, {21'h0, ph, 8'(s)});
    rd(SFPR_PHASE_RESULT, r);
    res = r[2:0];
    if (res == SFPR_PR_OK && q_has[s] && ph > c_ph[q_id[s]]) c_ph[q_id[s]] = ph;
  endtask
  task automatic phase_ok(input int s, input logic [2:0] ph);
    logic [2:0] r;
    phase(s, ph, r);
    begin if (!(r == SFPR_PR_OK)) $display("    info: phase %0d on slot %0d result %0d", ph, s, r); check(r == SFPR_PR_OK, "phase _ on slot _ result _"); end
  endtask

  task automatic fw_cpl(input int s, input logic [6:0] st, input logic [7:0] er);
    @(negedge clk);
    cpl_in = '0;
    cpl_in.tid = 16'(s);
    cpl_in.status = st;
    cpl_in.err = er;
    cpl_in.result0 = 32'h1;
    cpl_in_valid = 1'b1;
    @(posedge clk); #1;
    cpl_in_valid = 1'b0;
    if (s < NS) begin q_fwdone[s] = 1'b1; end
  endtask

  // the queue forgets a slot when the DUT has freed it
  always @(posedge clk) begin
    for (int s = 0; s < NS; s++)
      if (q_has[s] && q_fwdone[s] && !dut.s_valid[s]) q_has[s] <= 1'b0;
  end

  task automatic wait_cpl(input int id, input int maxc);
    for (int k = 0; k < maxc && c_ncpl[id] == 0; k++) begin @(posedge clk); #1; end
  endtask

  task automatic wait_state(input logic [3:0] s, input int maxc);
    for (int k = 0; k < maxc && fsm_now() != s; k++) begin @(posedge clk); #1; end
  endtask

  // ---------------------------------------------------------------- reset / boot
  task automatic clear_model();
    for (int i = 0; i < 1024; i++) begin tid_busy[i] = 1'b0; tid2id[i] = 0; end
    // a reset loses acknowledged-volatile data that was not durable: no later FLUSH covers it
    for (int k = 0; k < MAXID; k++) c_volopen[k] = 1'b0;
    for (int s = 0; s < 32; s++) begin q_has[s] = 1'b0; q_fwdone[s] = 1'b0; q_id[s] = 0; end
  endtask
  task automatic power_on();
    por_n = 1'b0; rst_n = 1'b0; pwr_fail_n = 1'b1; shn = 1'b0; nand_busy = 1'b0; cmd_in_valid = 1'b0;
    cpl_in_valid = 1'b0; wce_now = 1'b0; host_rdy_pct = 100; dn_rdy_pct = 100;
    clear_model();
    cycles(3);
    @(negedge clk); por_n = 1'b1; rst_n = 1'b1;
    cycles(2);
  endtask
  task automatic warm_reset();
    @(negedge clk); rst_n = 1'b0;
    for (int i = 1; i < next_id; i++) if (c_sub[i] && c_ncpl[i] == 0) c_lost[i] = 1'b1;
    clear_model();
    cycles(3);
    @(negedge clk); rst_n = 1'b1;
    cycles(2);
  endtask
  task automatic boot_ready();
    logic [31:0] v;
    wait_state(SFPR_STATE_INIT, 10);
    wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_BOOT_ACK);
    cycles(5);
    wr(SFPR_RECOV_DONE, 32'(SFPR_RD_OK));
    cycles(1);
    rd(SFPR_STATE, v);
    begin if (!(v[3:0] == SFPR_STATE_READY)) $display("    info: boot -> READY (state %0d)", v[3:0]); check(v[3:0] == SFPR_STATE_READY, "boot -> READY (state _)"); end
  endtask
  task automatic set_wce(input logic w);
    logic [31:0] v;
    rd(SFPR_CFG, v);
    v[SFPR_CFG_WCE] = w;
    wr(SFPR_CFG, v);
    wce_now = w;
  endtask

  // complete a whole write the way firmware does: start, buffer, program ... durable, then post
  task automatic fw_write_durable(input int s, input bit post_first);
    phase_ok(s, SFPR_PH_STARTED);
    phase_ok(s, SFPR_PH_BUFFERED);
    if (post_first) fw_cpl(s, 7'(SFS_ST_SUCCESS), 8'h0);
    phase_ok(s, SFPR_PH_PROGRAMMED);
    phase_ok(s, SFPR_PH_VERIFIED);
    phase_ok(s, SFPR_PH_MAP_COMMITTED);
    phase_ok(s, SFPR_PH_DURABLE);
    if (!post_first) fw_cpl(s, 7'(SFS_ST_SUCCESS), 8'h0);
  endtask

  // ================================================================ tests
  task automatic t_reset_boot();
    logic [31:0] v;
    int id, s;
    power_on();
    rd(SFPR_ID, v);      check(v == SFPR_ID_MAGIC, "ID");
    rd(SFPR_VERSION, v); check(v == SFPR_VERSION_VAL, "VERSION");
    rd(SFPR_CAPS, v);    check(v[7:0] == 8'(NS) && v[9] == 1'b1 && v[8] == PLP, "CAPS");
    rd(SFPR_STATE, v);   check(v[3:0] == SFPR_STATE_INIT, "state INIT after reset");
    rd(SFPR_STK_LAST_CAUSE, v); check(v == 32'(SFPR_CAUSE_POR), "cause POR");
    check(!rdy, "rdy_o low in INIT");
    submit(8'(SFS_OP_READ), 1'b0, id);
    wait_cpl(id, 50);
    check(c_st[id] == 7'(SFS_ST_ABORT_RESET), "INIT: command aborted NOT_READY");
    wr(SFPR_RECOV_DONE, 0);                      // illegal in INIT
    rd(SFPR_ERR_STATUS, v); check(v[SFPR_ERR_SEQ], "RECOV_DONE in INIT -> ERR SEQ");
    wr(SFPR_ERR_STATUS, v);
    rd(SFPR_ERR_STATUS, v); check(v == 0, "ERR_STATUS W1C");
    wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_BOOT_ACK);
    rd(SFPR_STATE, v); check(v[3:0] == SFPR_STATE_RECOVER, "BOOT_ACK -> RECOVER");
    submit(8'(SFS_OP_WRITE), 1'b0, id);
    wait_cpl(id, 50);
    check(c_st[id] == 7'(SFS_ST_ABORT_RESET), "RECOVER: command aborted NOT_READY");
    cycles(40);
    wr(SFPR_RECOV_DONE, 32'(SFPR_RD_OK));
    rd(SFPR_STATE, v); check(v[3:0] == SFPR_STATE_READY && rdy, "RECOV_DONE OK -> READY");
    rd(SFPR_RECOV_CYC_LAST, v); begin if (!(v > 40 && v < 80)) $display("    info: recovery time measured (%0d cycles)", v); check(v > 40 && v < 80, "recovery time measured (_ cycles)"); end
    rd(SFPR_STK_RECOV, v); check(v[2] && v[1:0] == 2'(SFPR_RD_OK), "STK_RECOV result");
    rd(SFPR_CNT_ABORT_STATE, v); check(v == 2, "CNT_ABORT_STATE");
    // unmapped / read-only accesses
    begin
      logic e;
      rd_err(12'h0F0, 1'b0, e); check(e, "unmapped read -> rb_err");
      rd_err(SFPR_STATE, 1'b1, e); check(e, "write to read-only -> rb_err");
      rd_err(SFPR_CFG, 1'b1, e);   check(!e, "write to CFG ok");
      wr(SFPR_CFG, SFPR_CFG_RST);
    end
    // a READ passes straight through, TID remapped downstream and restored upstream
    submit(8'(SFS_OP_READ), 1'b0, id);
    wait_fwd(id, s);
    check(s >= 0, "READ forwarded");
    if (s >= 0) begin
      check(dut.s_tid[s] == c_tid[id], "slot holds the host TID");
      phase_ok(s, SFPR_PH_STARTED);
      fw_cpl(s, 7'(SFS_ST_SUCCESS), 8'h0);
      wait_cpl(id, 20);
      check(c_st[id] == 7'(SFS_ST_SUCCESS), "READ completed SUCCESS with host TID");
    end
  endtask

  task automatic t_write_gate();
    logic [31:0] v;
    int id, s, id2, s2;
    power_on(); boot_ready();
    // firmware posts SUCCESS early: the gate holds it until DURABLE
    submit(8'(SFS_OP_WRITE), 1'b0, id);
    wait_fwd(id, s);
    phase_ok(s, SFPR_PH_STARTED);
    phase_ok(s, SFPR_PH_BUFFERED);
    fw_cpl(s, 7'(SFS_ST_SUCCESS), 8'h0);
    cycles(20);
    check(c_ncpl[id] == 0, "premature SUCCESS held (WCE off)");
    rd(SFPR_SLOT_WIN + 12'(4 * s), v);
    check(v[SFPR_SLOT_CPL_HELD_LSB] && v[2:0] == SFPR_PH_BUFFERED && v[31:16] == 32'(c_tid[id]), "slot window: held, BUFFERED, TID");
    phase_ok(s, SFPR_PH_PROGRAMMED);
    phase_ok(s, SFPR_PH_VERIFIED);
    phase_ok(s, SFPR_PH_MAP_COMMITTED);
    cycles(10);
    check(c_ncpl[id] == 0, "still held at MAP_COMMITTED");
    phase_ok(s, SFPR_PH_DURABLE);
    wait_cpl(id, 20);
    check(c_st[id] == 7'(SFS_ST_SUCCESS), "released at DURABLE");
    rd(SFPR_CNT_GATE_HELD, v); check(v == 1, "CNT_GATE_HELD");
    rd(SFPR_CNT_ACK_DURABLE, v); check(v == 1, "CNT_ACK_DURABLE");
    rd(SFPR_DURABLE_CNT, v); check(v == 1, "DURABLE_CNT");
    rd(SFPR_LAT_DUR_MAX, v); check(v > 20, "durable latency recorded");
    // phases after durable: firmware reports then posts -> immediate release
    submit(8'(SFS_OP_WRITE), 1'b1, id2);
    wait_fwd(id2, s2);
    fw_write_durable(s2, 1'b0);
    wait_cpl(id2, 20);
    check(c_st[id2] == 7'(SFS_ST_SUCCESS), "FUA write SUCCESS after DURABLE");
    // DEALLOCATE also needs DURABLE
    submit(8'(SFS_OP_DEALLOCATE), 1'b0, id);
    wait_fwd(id, s);
    phase_ok(s, SFPR_PH_STARTED);
    fw_cpl(s, 7'(SFS_ST_SUCCESS), 8'h0);
    cycles(10);
    check(c_ncpl[id] == 0, "DEALLOCATE held");
    phase_ok(s, SFPR_PH_PROGRAMMED);
    phase_ok(s, SFPR_PH_DURABLE);
    wait_cpl(id, 20);
    check(c_st[id] == 7'(SFS_ST_SUCCESS), "DEALLOCATE released at DURABLE (skipping phases allowed)");
    // error completions pass immediately
    submit(8'(SFS_OP_WRITE), 1'b0, id);
    wait_fwd(id, s);
    phase_ok(s, SFPR_PH_STARTED);
    fw_cpl(s, 7'(SFS_ST_MEDIA_WRITE), 8'(SFS_ERR_NAND_FAIL));
    wait_cpl(id, 20);
    check(c_st[id] == 7'(SFS_ST_MEDIA_WRITE), "error completion not gated");
    cycles(5);
    rd(SFPR_STATE, v); check(v[23:16] == 0, "all slots free");
  endtask

  task automatic t_phase_rules();
    logic [31:0] v;
    logic [2:0] r;
    int id, s;
    power_on(); boot_ready();
    submit(8'(SFS_OP_WRITE), 1'b0, id);
    wait_fwd(id, s);
    phase(s, SFPR_PH_ACCEPTED, r); check(r == SFPR_PR_REGRESS, "ACCEPTED is hardware-only");
    phase(s, SFPR_PH_FREE, r);     check(r == SFPR_PR_REGRESS, "FREE refused");
    phase(s, SFPR_PH_PROGRAMMED, r); check(r == SFPR_PR_OK, "skip forward allowed");
    phase(s, SFPR_PH_PROGRAMMED, r); check(r == SFPR_PR_OK, "repeat allowed");
    phase(s, SFPR_PH_BUFFERED, r);   check(r == SFPR_PR_REGRESS, "regression refused");
    rd(SFPR_SLOT_WIN + 12'(4 * s), v); check(v[2:0] == SFPR_PH_PROGRAMMED, "phase unchanged by refused report");
    phase(NS - 1 == s ? 0 : NS - 1, SFPR_PH_STARTED, r); check(r == SFPR_PR_BAD_SLOT, "free slot");
    phase(40, SFPR_PH_STARTED, r); check(r == SFPR_PR_BAD_SLOT, "out-of-range slot");
    rd(SFPR_ERR_STATUS, v);
    check(v[SFPR_ERR_PHASE_REGRESS] && v[SFPR_ERR_PHASE_BAD_SLOT], "ERR bits PHASE_REGRESS + BAD_SLOT");
    rd(SFPR_ERR_INFO, v); check(v[7:0] == 8'(SFPR_ERR_PHASE_REGRESS) && v[15:8] == 8'(s), "ERR_INFO = first error");
    check(irq == 1'b0, "irq masked");
    wr(SFPR_IRQ_EN, 32'(1) << SFPR_IRQ_ERR);
    cycles(1); check(irq, "irq on ERR when enabled");
    wr(SFPR_ERR_STATUS, 32'hFFFF_FFFF); cycles(1); check(!irq, "irq clears");
    wr(SFPR_IRQ_EN, 0);
    // unknown / duplicate completions from the queue
    fw_cpl(NS - 1 == s ? 0 : NS - 1, 7'(SFS_ST_SUCCESS), 0);
    rd(SFPR_ERR_STATUS, v); check(v[SFPR_ERR_CPL_UNKNOWN], "completion for free slot -> CPL_UNKNOWN");
    phase_ok(s, SFPR_PH_DURABLE);
    fw_cpl(s, 7'(SFS_ST_SUCCESS), 0);
    fw_cpl(s, 7'(SFS_ST_SUCCESS), 0);
    rd(SFPR_ERR_STATUS, v); check(v[SFPR_ERR_CPL_DUP] || c_ncpl[id] == 1, "duplicate completion flagged or slot already freed");
    wait_cpl(id, 20);
    check(c_ncpl[id] == 1, "exactly one host completion");
    // RETIRE of a non-volatile slot
    wr(SFPR_RETIRE, 32'(s));
    rd(SFPR_ERR_STATUS, v); check(v[SFPR_ERR_RETIRE_BAD], "RETIRE of a non-volatile slot refused");
    wr(SFPR_ERR_STATUS, 32'hFFFF_FFFF);
    // CID conflict with an outstanding command
    begin
      int a, b;
      submit_tid(8'(SFS_OP_READ), 300, a);
      wait_fwd(a, s);
      submit_tid(8'(SFS_OP_READ), 300, b);       // same TID while a is outstanding
      wait_cpl(b, 20);
      check(c_ncpl[b] == 1 && c_st[b] == 7'(SFS_ST_CID_CONFLICT), "second command with an outstanding TID -> CID_CONFLICT");
      check(c_ncpl[a] == 0, "first command unaffected");
      tid_busy[300] = 1'b1; tid2id[300] = a;
      phase_ok(s, SFPR_PH_STARTED);
      fw_cpl(s, 7'(SFS_ST_SUCCESS), 0);
      wait_cpl(a, 20);
      check(c_st[a] == 7'(SFS_ST_SUCCESS), "original command completes");
      rd(SFPR_CNT_REJ_CONFLICT, v); check(v == 1, "CNT_REJ_CONFLICT");
    end
  endtask

  task automatic t_wce_flush();
    logic [31:0] v;
    int w1, w2, w3, f1, s1, s2, s3, sf, id, s;
    power_on(); boot_ready();
    set_wce(1'b1);
    submit(8'(SFS_OP_WRITE), 1'b0, w1); wait_fwd(w1, s1);
    phase_ok(s1, SFPR_PH_STARTED);
    fw_cpl(s1, 7'(SFS_ST_SUCCESS), 0);
    cycles(10);
    check(c_ncpl[w1] == 0, "WCE: SUCCESS held until BUFFERED");
    phase_ok(s1, SFPR_PH_BUFFERED);
    wait_cpl(w1, 20);
    check(c_st[w1] == 7'(SFS_ST_SUCCESS), "WCE: volatile ack at BUFFERED");
    cycles(3);
    rd(SFPR_SLOT_WIN + 12'(4 * s1), v);
    check(v[SFPR_SLOT_VALID_LSB] && v[SFPR_SLOT_ACKED_LSB] && v[SFPR_SLOT_VOL_LSB], "volatile write still tracked");
    rd(SFPR_STATE, v); check(v[31:24] == 1, "STATE: 1 volatile slot");
    // the host may reuse the TID at once
    begin
      int r;
      submit_tid(8'(SFS_OP_READ), int'(c_tid[w1]), r);
      wait_fwd(r, s);
      check(s >= 0 && s != s1, "TID of a volatile-acked write reusable (new slot)");
      phase_ok(s, SFPR_PH_STARTED); fw_cpl(s, 7'(SFS_ST_SUCCESS), 0); wait_cpl(r, 20);
      check(c_st[r] == 7'(SFS_ST_SUCCESS), "reused TID completes");
    end
    // FUA write needs DURABLE even with WCE
    submit(8'(SFS_OP_WRITE), 1'b1, w3); wait_fwd(w3, s3);
    phase_ok(s3, SFPR_PH_STARTED); phase_ok(s3, SFPR_PH_BUFFERED);
    fw_cpl(s3, 7'(SFS_ST_SUCCESS), 0);
    cycles(10);
    check(c_ncpl[w3] == 0, "FUA held at BUFFERED");
    phase_ok(s3, SFPR_PH_DURABLE);
    wait_cpl(w3, 20);
    check(c_st[w3] == 7'(SFS_ST_SUCCESS), "FUA released at DURABLE");
    submit(8'(SFS_OP_WRITE), 1'b0, w2); wait_fwd(w2, s2);
    phase_ok(s2, SFPR_PH_STARTED); phase_ok(s2, SFPR_PH_BUFFERED);
    fw_cpl(s2, 7'(SFS_ST_SUCCESS), 0);
    wait_cpl(w2, 20);
    // FLUSH depends on w1, w2
    submit(8'(SFS_OP_FLUSH), 1'b0, f1); wait_fwd(f1, sf);
    check(fdep_n[f1] == 2, "bench: FLUSH has 2 dependencies");
    phase_ok(sf, SFPR_PH_STARTED);
    phase_ok(sf, SFPR_PH_DURABLE);
    fw_cpl(sf, 7'(SFS_ST_SUCCESS), 0);
    cycles(10);
    rd(SFPR_SLOT_WIN + 12'(4 * sf), v);
    check(c_ncpl[f1] == 0 && v[SFPR_SLOT_DEP_PENDING_LSB], "FLUSH held: dependencies pending");
    // a volatile write acked AFTER the flush was admitted is not a dependency
    submit(8'(SFS_OP_WRITE), 1'b0, id); wait_fwd(id, s);
    phase_ok(s, SFPR_PH_STARTED); phase_ok(s, SFPR_PH_BUFFERED); fw_cpl(s, 7'(SFS_ST_SUCCESS), 0);
    wait_cpl(id, 20);
    phase_ok(s1, SFPR_PH_PROGRAMMED); phase_ok(s1, SFPR_PH_DURABLE);
    cycles(10);
    check(c_ncpl[f1] == 0, "FLUSH still held: one dependency left");
    phase_ok(s2, SFPR_PH_DURABLE);
    wait_cpl(f1, 20);
    check(c_st[f1] == 7'(SFS_ST_SUCCESS), "FLUSH released when its dependencies are durable");
    rd(SFPR_CNT_VOL_DURABLE, v); check(v == 2, "CNT_VOL_DURABLE");
    rd(SFPR_CNT_ACK_VOL, v); check(v == 3, "CNT_ACK_VOL");
    // a dependency that fails: FLUSH -> MEDIA_WRITE
    submit(8'(SFS_OP_FLUSH), 1'b0, f1); wait_fwd(f1, sf);
    phase_ok(sf, SFPR_PH_STARTED); phase_ok(sf, SFPR_PH_DURABLE); fw_cpl(sf, 7'(SFS_ST_SUCCESS), 0);
    cycles(5);
    check(c_ncpl[f1] == 0, "second FLUSH waits for the last volatile write");
    wr(SFPR_RETIRE, 32'(s));
    c_retired[id] = 1'b1;
    wait_cpl(f1, 20);
    check(c_st[f1] == 7'(SFS_ST_MEDIA_WRITE), "FLUSH fails when a dependency is retired");
    rd(SFPR_ERR_STATUS, v); check(v[SFPR_ERR_VOL_FAIL], "ERR VOL_FAIL");
    rd(SFPR_CNT_VOL_FAILED, v); check(v == 1, "CNT_VOL_FAILED");
    wr(SFPR_ERR_STATUS, 32'hFFFF_FFFF);
    cycles(5);
    rd(SFPR_STATE, v); check(v[23:16] == 0, "all slots free");
  endtask

  task automatic t_pf_quiesce();
    logic [31:0] v;
    int wa, wb, wc, wd, we, n0, s, sa, sb, sc, sd;
    power_on(); boot_ready();
    set_wce(1'b1);
    // wd: acknowledged-volatile write (data at risk)
    submit(8'(SFS_OP_WRITE), 1'b0, wd); wait_fwd(wd, sd);
    phase_ok(sd, SFPR_PH_STARTED); phase_ok(sd, SFPR_PH_BUFFERED); fw_cpl(sd, 7'(SFS_ST_SUCCESS), 0);
    wait_cpl(wd, 20);
    set_wce(1'b0);
    // wa: not started; wb: started, in programming; wc: SUCCESS posted, not durable
    submit(8'(SFS_OP_WRITE), 1'b0, wa); wait_fwd(wa, sa);
    submit(8'(SFS_OP_WRITE), 1'b0, wb); wait_fwd(wb, sb);
    submit(8'(SFS_OP_WRITE), 1'b0, wc); wait_fwd(wc, sc);
    phase_ok(sb, SFPR_PH_STARTED); phase_ok(sb, SFPR_PH_BUFFERED);
    phase_ok(sc, SFPR_PH_STARTED); phase_ok(sc, SFPR_PH_PROGRAMMED);
    fw_cpl(sc, 7'(SFS_ST_SUCCESS), 0);
    nand_busy = 1'b1;
    rd(SFPR_COMMIT_SEQ_LO, v);
    wr(SFPR_COMMIT_SEQ_LO, 32'h0000_1234);
    // ---- power-fail warning
    @(negedge clk); pwr_fail_n = 1'b0;
    cycles(4);
    rd(SFPR_STATE, v);
    check(v[3:0] == SFPR_STATE_PF_QUIESCE && v[5] && v[4], "PF_QUIESCE, latched, pin");
    check(nand_inhibit && quiesce && pf_active && !rdy, "nand_inhibit / quiesce / pf_active");
    check(!wp_force, "WP# not forced while a NAND operation is in flight");
    wait_cpl(wa, 20);
    check(c_st[wa] == 7'(SFS_ST_ABORT_PWR_LOSS), "not-started command aborted by hardware");
    wait_cpl(wc, 20);
    check(c_st[wc] == 7'(SFS_ST_ABORT_PWR_LOSS), "held non-durable SUCCESS converted to ABORT_PWR_LOSS");
    submit(8'(SFS_OP_READ), 1'b0, n0);
    wait_cpl(n0, 20);
    check(c_st[n0] == 7'(SFS_ST_ABORT_PWR_LOSS), "new command refused ABORT_PWR_LOSS");
    begin
      logic [2:0] r;
      phase(sa, SFPR_PH_STARTED, r); check(r == SFPR_PR_ABORTED, "firmware cannot start a hw-aborted command");
    end
    fw_cpl(sa, 7'(SFS_ST_ABORT_PWR_LOSS), 8'(SFS_ERR_QUIESCED));      // queue drains it: dropped
    rd(SFPR_CNT_DROP, v); check(v == 1, "queue completion of a hw-aborted command dropped");
    // wb is still active: no PF_SAFE
    cycles(5);
    check(fsm_now() == SFPR_STATE_PF_QUIESCE, "PF_QUIESCE while firmware still owns a command");
    // firmware stops wb at a page boundary: completes it aborted (not acknowledged)
    fw_cpl(sb, 7'(SFS_ST_ABORT_PWR_LOSS), 8'(SFS_ERR_QUIESCED));
    wait_cpl(wb, 20);
    check(c_st[wb] == 7'(SFS_ST_ABORT_PWR_LOSS), "started command aborted by firmware");
    cycles(5);
    check(fsm_now() == SFPR_STATE_PF_QUIESCE, "PF_QUIESCE while the NAND is busy");
    @(negedge clk); nand_busy = 1'b0;
    cycles(3);
    check(wp_force, "WP# forced once the NAND is idle");
    check(fsm_now() == SFPR_STATE_PF_SAFE, "PF_SAFE");
    rd(SFPR_STK_PF_COUNT, v); check(v == 1, "STK_PF_COUNT");
    rd(SFPR_STK_PF_SNAP0, v);
    begin if (!(v[31] && v[3:0] == SFPR_STATE_READY && v[28:24] == 1 && v[12:8] >= 2)) $display("    info: PF snapshot %08x", v); check(v[31] && v[3:0] == SFPR_STATE_READY && v[28:24] == 1 && v[12:8] >= 2, "PF snapshot _"); end
    rd(SFPR_STK_PF_SNAP1, v);
    begin if (!(v[0] && v[1] && v[23:16] == 1 && v[15:8] == 1)) $display("    info: PF snapshot 1 %08x: busy, safe, 1 abort, 1 conversion", v); check(v[0] && v[1] && v[23:16] == 1 && v[15:8] == 1, "PF snapshot 1 _: busy, safe, 1 abort, 1 conversion"); end
    rd(SFPR_STK_PF_COMMIT_SEQ, v); check(v == 32'h1234, "commit seq at the fault");
    rd(SFPR_STK_VOL_LOST, v); check(v == 1, "1 volatile write at risk");
    rd(SFPR_STK_PF_SAFE_CYC, v); check(v > 0, "fault -> safe cycles");
    rd(SFPR_IRQ_STATUS, v); check(v[SFPR_IRQ_PF_EVENT] && v[SFPR_IRQ_VOL_LOST] && v[SFPR_IRQ_PF_SAFE], "IRQ PF_EVENT, VOL_LOST, PF_SAFE");
    rd(SFPR_CNT_ABORT_PF, v); begin if (!(v == 2)) $display("    info: CNT_ABORT_PF = %0d (sweep + admission)", v); check(v == 2, "CNT_ABORT_PF = _ (sweep + admission)"); end
    rd(SFPR_CNT_GATE_CONV, v); check(v == 1, "CNT_GATE_CONV");
    // resume before the supply is good: refused
    wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_PF_RESUME);
    rd(SFPR_ERR_STATUS, v); check(v[SFPR_ERR_SEQ] && fsm_now() == SFPR_STATE_PF_SAFE, "PF_RESUME while the fault persists refused");
    wr(SFPR_ERR_STATUS, 32'hFFFF_FFFF);
    // the volatile write is destaged later, after recovery (RAM survived the brown-out)
    @(negedge clk); pwr_fail_n = 1'b1;
    cycles(70);
    rd(SFPR_STATE, v); check(v[9], "PF_RESTORED after PF_RESTORE_CYCLES");
    wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_PF_RESUME);
    rd(SFPR_STATE, v); check(v[3:0] == SFPR_STATE_RECOVER && !v[5], "resume -> RECOVER (fast resume disabled)");
    check(!nand_inhibit && !wp_force, "inhibit / WP# released");
    rd(SFPR_STK_LAST_CAUSE, v); check(v == 32'(SFPR_CAUSE_PF_RESUME), "cause PF_RESUME");
    wr(SFPR_RECOV_DONE, 32'(SFPR_RD_OK));
    check(fsm_now() == SFPR_STATE_READY, "READY after recovery");
    rd(SFPR_STATE, v); check(v[31:24] == 1, "volatile write still tracked across the brown-out");
    phase_ok(sd, SFPR_PH_DURABLE);
    cycles(3);
    rd(SFPR_STATE, v); check(v[23:16] == 0, "all slots free");
    // command works again
    submit(8'(SFS_OP_READ), 1'b0, we); wait_fwd(we, s);
    phase_ok(s, SFPR_PH_STARTED); fw_cpl(s, 7'(SFS_ST_SUCCESS), 0); wait_cpl(we, 20);
    check(c_st[we] == 7'(SFS_ST_SUCCESS), "commands accepted after resume");
  endtask

  task automatic t_fast_resume();
    logic [31:0] v;
    power_on(); boot_ready();
    wr(SFPR_CFG, SFPR_CFG_RST | (32'(1) << SFPR_CFG_FAST_RESUME_EN));
    wr(SFPR_PF_RESTORE_CYCLES, 8);
    // fault with the NAND idle -> fast resume back to READY
    @(negedge clk); pwr_fail_n = 1'b0;
    cycles(4);
    check(fsm_now() == SFPR_STATE_PF_SAFE && wp_force, "PF_SAFE at once with nothing in flight");
    @(negedge clk); pwr_fail_n = 1'b1;
    cycles(12);
    rd(SFPR_STATE, v); check(v[10], "FAST_RESUME_OK");
    wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_PF_RESUME);
    check(fsm_now() == SFPR_STATE_READY, "fast resume -> READY");
    // fault with the NAND busy -> full recovery even with fast resume enabled
    nand_busy = 1'b1;
    @(negedge clk); pwr_fail_n = 1'b0;
    cycles(3);
    @(negedge clk); nand_busy = 1'b0; pwr_fail_n = 1'b1;
    cycles(12);
    rd(SFPR_STATE, v); check(!v[10], "no fast resume: NAND was busy at the fault");
    wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_PF_RESUME);
    check(fsm_now() == SFPR_STATE_RECOVER, "-> RECOVER");
    wr(SFPR_RECOV_DONE, 32'(SFPR_RD_OK));
    // firmware-forced quiesce (no pin)
    wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_FORCE_PF);
    cycles(3);
    check(fsm_now() == SFPR_STATE_PF_SAFE, "FORCE_PF -> PF_SAFE");
    cycles(10);
    wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_PF_RESUME);
    check(fsm_now() == SFPR_STATE_READY, "FORCE_PF resume");
    rd(SFPR_STK_PF_COUNT, v); check(v == 3, "3 power-fault episodes counted");
  endtask

  task automatic t_warm_reset();
    logic [31:0] v;
    int w, s, id;
    power_on(); boot_ready();
    set_wce(1'b1);
    submit(8'(SFS_OP_WRITE), 1'b0, w); wait_fwd(w, s);
    phase_ok(s, SFPR_PH_STARTED); phase_ok(s, SFPR_PH_BUFFERED); fw_cpl(s, 7'(SFS_ST_SUCCESS), 0);
    wait_cpl(w, 20);
    submit(8'(SFS_OP_READ), 1'b0, id);       // outstanding at the reset
    cycles(3);
    @(negedge clk); pwr_fail_n = 1'b0; cycles(5); @(negedge clk); pwr_fail_n = 1'b1;   // one fault episode
    cycles(5);
    warm_reset();
    rd(SFPR_STATE, v); check(v[3:0] == SFPR_STATE_INIT && v[23:16] == 0, "warm reset: INIT, slot table cleared");
    rd(SFPR_STK_WARM_COUNT, v); check(v == 1, "STK_WARM_COUNT survives");
    rd(SFPR_STK_PF_COUNT, v);   check(v == 1, "STK_PF_COUNT survives");
    rd(SFPR_STK_LAST_CAUSE, v); check(v == 32'(SFPR_CAUSE_WARM), "cause WARM");
    rd(SFPR_STK_RST_SNAP, v);
    begin if (!(v[31] && v[28:24] == 1 && v[3:0] == SFPR_STATE_PF_SAFE)) $display("    info: reset snapshot %08x: 1 volatile, state PF_SAFE", v); check(v[31] && v[28:24] == 1 && v[3:0] == SFPR_STATE_PF_SAFE, "reset snapshot _: 1 volatile, state PF_SAFE"); end
    rd(SFPR_STK_VOL_LOST, v); check(v == 2, "volatile-at-risk counted at the fault and at the reset");
    rd(SFPR_STK_FLAGS, v); check(v[0] && v[1], "STK_FLAGS PF_SEEN WARM_SEEN");
    rd(SFPR_CNT_ADMIT, v); check(v == 0, "controller counters reset");
    rd(SFPR_CFG, v); check(v == SFPR_CFG_RST, "CFG reset");
    boot_ready();
    wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_CLR_STICKY);
    rd(SFPR_STK_WARM_COUNT, v); check(v == 0, "CLR_STICKY");
    warm_reset();
    power_on();
    rd(SFPR_STK_PF_COUNT, v); check(v == 0, "POR clears sticky");
    rd(SFPR_STK_LAST_CAUSE, v); check(v == 32'(SFPR_CAUSE_POR), "cause POR after POR");
  endtask

  task automatic t_shutdown_ro_failed();
    logic [31:0] v;
    int id, s, r;
    power_on(); boot_ready();
    submit(8'(SFS_OP_WRITE), 1'b0, id); wait_fwd(id, s);
    @(negedge clk); shn = 1'b1;
    cycles(3);
    check(shst == 2'd1 && fsm_now() == SFPR_STATE_SHUTDOWN, "SHUTDOWN, SHST in progress");
    submit(8'(SFS_OP_READ), 1'b0, r); wait_cpl(r, 20);
    check(c_st[r] == 7'(SFS_ST_ABORT_RESET), "new command refused during shutdown");
    wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_SHUTDOWN_DONE);
    rd(SFPR_ERR_STATUS, v); check(v[SFPR_ERR_SEQ] && fsm_now() == SFPR_STATE_SHUTDOWN, "SHUTDOWN_DONE refused with a command outstanding");
    wr(SFPR_ERR_STATUS, 32'hFFFF_FFFF);
    fw_write_durable(s, 1'b0);
    wait_cpl(id, 20);
    check(c_st[id] == 7'(SFS_ST_SUCCESS), "outstanding command completes during shutdown");
    cycles(3);
    wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_SHUTDOWN_DONE);
    cycles(2);
    check(shst == 2'd2 && fsm_now() == SFPR_STATE_SHUT_DONE && nand_inhibit && wp_force, "SHUT_DONE: SHST complete, media protected");
    @(negedge clk); shn = 1'b0;
    // READONLY
    power_on();
    wait_state(SFPR_STATE_INIT, 10);
    wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_BOOT_ACK);
    wr(SFPR_RECOV_DONE, 32'(SFPR_RD_READONLY));
    check(fsm_now() == SFPR_STATE_READONLY && ro && rdy, "READONLY");
    submit(8'(SFS_OP_WRITE), 1'b0, id); wait_cpl(id, 20);
    check(c_st[id] == 7'(SFS_ST_ACCESS_DENIED), "WRITE refused in READONLY");
    submit(8'(SFS_OP_DEALLOCATE), 1'b0, id); wait_cpl(id, 20);
    check(c_st[id] == 7'(SFS_ST_ACCESS_DENIED), "DEALLOCATE refused in READONLY");
    submit(8'(SFS_OP_READ), 1'b0, id); wait_fwd(id, s);
    phase_ok(s, SFPR_PH_STARTED); fw_cpl(s, 7'(SFS_ST_SUCCESS), 0); wait_cpl(id, 20);
    check(c_st[id] == 7'(SFS_ST_SUCCESS), "READ served in READONLY");
    // FAILED, retry, recovery timeout
    power_on();
    wait_state(SFPR_STATE_INIT, 10);
    wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_BOOT_ACK);
    wr(SFPR_RECOV_DONE, 32'(SFPR_RD_FAIL));
    check(fsm_now() == SFPR_STATE_FAILED && fatal, "FAILED");
    submit(8'(SFS_OP_READ), 1'b0, id); wait_cpl(id, 20);
    check(c_st[id] == 7'(SFS_ST_INTERNAL_ERR), "commands refused INTERNAL_ERR in FAILED");
    wr(SFPR_RECOV_TIMEOUT, 30);
    wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_RECOVER_RETRY);
    check(fsm_now() == SFPR_STATE_RECOVER, "RECOVER_RETRY");
    rd(SFPR_STK_LAST_CAUSE, v); check(v == 32'(SFPR_CAUSE_RETRY), "cause RETRY");
    cycles(40);
    check(fsm_now() == SFPR_STATE_FAILED, "recovery timeout -> FAILED");
    rd(SFPR_ERR_STATUS, v); check(v[SFPR_ERR_RECOV_TIMEOUT], "ERR RECOV_TIMEOUT");
  endtask

  task automatic t_gate_timeout();
    logic [31:0] v;
    int id, s;
    power_on(); boot_ready();
    wr(SFPR_GATE_TIMEOUT, 50);
    submit(8'(SFS_OP_WRITE), 1'b0, id); wait_fwd(id, s);
    phase_ok(s, SFPR_PH_STARTED);
    fw_cpl(s, 7'(SFS_ST_SUCCESS), 0);       // never becomes durable (firmware bug)
    cycles(30);
    check(c_ncpl[id] == 0, "held before the timeout");
    wait_cpl(id, 80);
    check(c_st[id] == 7'(SFS_ST_INTERNAL_ERR), "converted to INTERNAL_ERR after GATE_TIMEOUT");
    rd(SFPR_ERR_STATUS, v); check(v[SFPR_ERR_GATE_TIMEOUT], "ERR GATE_TIMEOUT");
    rd(SFPR_GATE_HOLD_MAX, v); check(v >= 50, "GATE_HOLD_MAX");
  endtask

  task automatic t_crash_inject();
    logic [31:0] v;
    int id, s;
    // firmware crash-point marks: fire on the 3rd mark with id 7
    power_on(); boot_ready();
    wr(SFPR_CI_COUNT, 3);
    wr(SFPR_CI_CTRL, {16'h0, 8'd7, 4'(SFPR_CIEV_MARK), 1'b0, 2'(SFPR_CIACT_CRASH), 1'b1});
    wr(SFPR_CI_MARK, 7); wr(SFPR_CI_MARK, 9); wr(SFPR_CI_MARK, 7);
    check(!ci_crash, "not yet");
    wr(SFPR_CI_MARK, 7);
    cycles(1);
    check(ci_crash, "ci_crash_o on the 3rd matching mark");
    rd(SFPR_CI_STATUS, v); check(v[1] && !v[0] && v[31:8] == 3, "CI_STATUS fired, 3 events");
    rd(SFPR_CI_LAST_MARK, v); check(v[7:0] == 7 && v[31:8] == 4, "CI_LAST_MARK");
    rd(SFPR_IRQ_STATUS, v); check(v[SFPR_IRQ_CI_FIRED], "IRQ CI_FIRED");
    // phase event with delay -> warm reset request
    power_on(); boot_ready();
    wr(SFPR_CI_COUNT, 1); wr(SFPR_CI_DELAY, 5);
    wr(SFPR_CI_CTRL, {16'h0, 8'(SFPR_PH_PROGRAMMED), 4'(SFPR_CIEV_PHASE), 1'b0, 2'(SFPR_CIACT_WARM), 1'b1});
    submit(8'(SFS_OP_WRITE), 1'b0, id); wait_fwd(id, s);
    phase_ok(s, SFPR_PH_STARTED);
    check(!ci_warm, "not on STARTED");
    phase_ok(s, SFPR_PH_PROGRAMMED);
    cycles(2); check(!ci_warm, "delay pending");
    cycles(6); check(ci_warm, "ci_warm_o after the delay");
    warm_reset();
    check(!ci_warm, "cleared by the reset");
    // internal power-fault action on the 2nd admission
    boot_ready();
    wr(SFPR_CI_COUNT, 2);
    wr(SFPR_CI_CTRL, {16'h0, 8'h0, 4'(SFPR_CIEV_ADMIT), 1'b0, 2'(SFPR_CIACT_PF), 1'b1});
    submit(8'(SFS_OP_READ), 1'b0, id);
    cycles(3); check(fsm_now() == SFPR_STATE_READY, "first admission: no fault");
    submit(8'(SFS_OP_READ), 1'b0, id);
    cycles(3); check(dut.pf_lat, "CIACT_PF latches a power fault");
    // NAND operation start event
    power_on(); boot_ready();
    wr(SFPR_CI_COUNT, 2);
    wr(SFPR_CI_CTRL, {16'h0, 8'h0, 4'(SFPR_CIEV_NANDOP), 1'b0, 2'(SFPR_CIACT_CRASH_PF), 1'b1});
    @(negedge clk); nand_busy = 1'b1; cycles(3); @(negedge clk); nand_busy = 1'b0; cycles(3);
    check(!ci_crash, "first NAND op");
    @(negedge clk); nand_busy = 1'b1; cycles(3);
    check(ci_crash && dut.pf_lat, "CRASH_PF on the 2nd NAND op: crash + warning");
    @(negedge clk); nand_busy = 1'b0;
    // host completion event, cycle event
    power_on(); boot_ready();
    wr(SFPR_CI_COUNT, 100);
    wr(SFPR_CI_CTRL, {16'h0, 8'h0, 4'(SFPR_CIEV_CYCLE), 1'b0, 2'(SFPR_CIACT_CRASH), 1'b1});
    cycles(90); check(!ci_crash, "cycle 90");
    cycles(20); check(ci_crash, "fires on cycle 100");
  endtask

  // ---------------------------------------------------------------- randomized stress
  task automatic t_random(input int iters);
    logic [31:0] v;
    int lost_cnt = 0, pf_cnt = 0, rst_cnt = 0, adm = 0;
    power_on(); boot_ready();
    host_rdy_pct = 70; dn_rdy_pct = 70;
    for (int it = 0; it < iters; it++) begin
      int a;
      a = rint(100);
      if (a < 35) begin                                   // host submits
        int id, nout;
        nout = 0;
        for (int t = 1; t <= 200; t++) if (tid_busy[t]) nout++;
        // the bench is single-threaded: only submit what the DUT can take, or it would block itself
        if (nout < 3 * NS && (dut.have_free || dut.pf_lat || fsm_now() != SFPR_STATE_READY)) begin
          int k;
          logic [7:0] op;
          k = rint(10);
          op = (k < 4) ? 8'(SFS_OP_WRITE) : (k < 7) ? 8'(SFS_OP_READ) : (k < 8) ? 8'(SFS_OP_DEALLOCATE) :
               (k < 9) ? 8'(SFS_OP_FLUSH) : 8'(SFS_OP_IDENTIFY);
          submit(op, rint(4) == 0, id);
          adm++;
        end
      end else if (a < 80) begin                          // firmware works on a forwarded command
        int s;
        s = rint(NS);
        if (q_has[s] && !q_fwdone[s] && dut.s_valid[s] && !dut.s_hwab[s]) begin
          int id;
          logic [2:0] cur, r;
          id = q_id[s];
          cur = dut.s_phase[s];
          if (cur == SFPR_PH_ACCEPTED) begin
            phase(s, SFPR_PH_STARTED, r);
            if (r != SFPR_PR_OK) fw_cpl(s, 7'(SFS_ST_ABORT_PWR_LOSS), 8'(SFS_ERR_QUIESCED));
          end else if (rint(8) == 0) begin
            fw_cpl(s, (rint(2) == 0) ? 7'(SFS_ST_MEDIA_WRITE) : 7'(SFS_ST_SUCCESS), 0);   // possibly premature
          end else if (dut.pf_lat && rint(2) == 0) begin
            fw_cpl(s, 7'(SFS_ST_ABORT_PWR_LOSS), 8'(SFS_ERR_QUIESCED));                 // stop at a page boundary
          end else if (cur < SFPR_PH_DURABLE) begin
            logic [2:0] nx;
            nx = cur + 3'(1 + rint(2));
            if (nx < cur) nx = SFPR_PH_DURABLE;
            if (c_cls[id] != SFPR_CLS_WRITE && nx == SFPR_PH_BUFFERED) nx = SFPR_PH_PROGRAMMED;
            phase(s, nx, r);
            begin if (!(r == SFPR_PR_OK)) $display("    info: random phase %0d->%0d result %0d", cur, nx, r); check(r == SFPR_PR_OK, "random phase _->_ result _"); end
          end else begin
            fw_cpl(s, 7'(SFS_ST_SUCCESS), 0);
          end
        end else if (q_has[s] && !q_fwdone[s] && dut.s_valid[s] && dut.s_hwab[s]) begin
          fw_cpl(s, 7'(SFS_ST_ABORT_PWR_LOSS), 8'(SFS_ERR_QUIESCED));                   // queue drained after a fault
        end else if (dut.s_valid[s] && dut.s_acked[s] && dut.s_vol[s]) begin             // destage
          logic [2:0] r;
          if (rint(15) == 0) begin wr(SFPR_RETIRE, 32'(s)); c_retired[q_id[s]] = 1'b1; end
          else phase(s, SFPR_PH_DURABLE, r);
        end
      end else if (a < 86) begin
        if (dut.pf_lat == 1'b0) set_wce(rint(2) == 0);
      end else if (a < 88) begin                          // power fault, then brown-out recovery
        pf_cnt++;
        @(negedge clk); pwr_fail_n = 1'b0;
        cycles(2 + rint(20));
        @(negedge clk); pwr_fail_n = 1'b1;
      end else if (a < 89 && rint(4) == 0) begin          // controller reset
        rst_cnt++;
        warm_reset();
        boot_ready();
        wce_now = 1'b0;
      end else begin
        cycles(1 + rint(4));
      end
      if (it % 1000 == 999) $display("    random: iteration %0d, state %0d, slots %0d", it + 1, fsm_now(), dut.n_used);
      // service the state machine like firmware would
      if (fsm_now() == SFPR_STATE_PF_SAFE && dut.pf_rest) begin
        wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_PF_RESUME);
        if (fsm_now() == SFPR_STATE_RECOVER) begin cycles(rint(10)); wr(SFPR_RECOV_DONE, 32'(SFPR_RD_OK)); end
      end
    end
    // drain: finish every command, destage every volatile write
    for (int round = 0; round < 400 && !(dut.s_valid == '0 && !cpl_out_valid); round++) begin
      if (fsm_now() == SFPR_STATE_PF_SAFE && dut.pf_rest) begin
        wr(SFPR_CTRL, 32'(1) << SFPR_CTRL_PF_RESUME);
        if (fsm_now() == SFPR_STATE_RECOVER) wr(SFPR_RECOV_DONE, 32'(SFPR_RD_OK));
      end
      for (int s = 0; s < NS; s++) begin
        if (q_has[s] && !q_fwdone[s] && dut.s_valid[s] && !dut.s_hwab[s]) begin
          logic [2:0] r;
          if (dut.s_phase[s] == SFPR_PH_ACCEPTED) phase(s, SFPR_PH_STARTED, r);
          if (dut.s_phase[s] != SFPR_PH_ACCEPTED) begin
            phase(s, SFPR_PH_DURABLE, r);
            fw_cpl(s, 7'(SFS_ST_SUCCESS), 0);
          end else fw_cpl(s, 7'(SFS_ST_ABORT_PWR_LOSS), 0);
        end else if (q_has[s] && !q_fwdone[s] && dut.s_hwab[s]) begin
          fw_cpl(s, 7'(SFS_ST_ABORT_PWR_LOSS), 0);
        end else if (dut.s_valid[s] && dut.s_acked[s] && dut.s_vol[s]) begin
          logic [2:0] r;
          phase(s, SFPR_PH_DURABLE, r);
        end
      end
      cycles(5);
    end
    host_rdy_pct = 100; dn_rdy_pct = 100;
    cycles(20);
    rd(SFPR_STATE, v);
    begin if (!(v[23:16] == 0)) $display("    info: random: all slots free at the end (%0d)", v[23:16]); check(v[23:16] == 0, "random: all slots free at the end (_)"); end
    for (int i = 1; i < next_id; i++)
      if (c_sub[i] && !c_lost[i] && c_ncpl[i] != 1) begin
        lost_cnt++;
        if (lost_cnt < 5) begin n_checks++; n_fail++; $display("  FAIL [%0s] id %0d: %0d completions", cur_test, i, c_ncpl[i]); end
      end
    check(lost_cnt == 0, "random: every command completed exactly once");
    $display("    random: %0d iterations, %0d submissions, %0d host completions, %0d power faults, %0d controller resets",
             iters, adm, n_hostcpl, pf_cnt, rst_cnt);
  endtask

  // PLP research configuration: early acknowledgement without WCE, drain policy
  task automatic t_plp_research();
    logic [31:0] v;
    int w, s;
    power_on(); boot_ready();
    submit(8'(SFS_OP_WRITE), 1'b0, w); wait_fwd(w, s);
    phase_ok(s, SFPR_PH_STARTED); phase_ok(s, SFPR_PH_BUFFERED); fw_cpl(s, 7'(SFS_ST_SUCCESS), 0);
    wait_cpl(w, 20);
    check(c_st[w] == 7'(SFS_ST_SUCCESS), "PLP: early ack at BUFFERED without WCE");
    @(negedge clk); pwr_fail_n = 1'b0;
    cycles(5);
    check(!nand_inhibit, "PLP: NAND not inhibited while draining");
    check(fsm_now() == SFPR_STATE_PF_QUIESCE, "PLP: PF_SAFE waits for the drain");
    phase_ok(s, SFPR_PH_DURABLE);
    cycles(3);
    check(fsm_now() == SFPR_STATE_PF_SAFE && nand_inhibit && wp_force, "PLP: drained -> PF_SAFE, WP#");
    rd(SFPR_CAPS, v); check(v[8] && v[31:16] == 16'(PLPQ), "CAPS PLP_PRESENT + qualification id");
  endtask

  // ================================================================ runner
  task run(input reg [8*24-1:0] name, input reg [8*24-1:0] sel);
    int f0;
    if (sel == "all" || sel == name) begin
      cur_test = name;
      n_tests++;
      f0 = n_fail;
      $display("[ RUN  ] %0s", name);
      case (name)
        "reset_boot":       t_reset_boot();
        "write_gate":       t_write_gate();
        "phase_rules":      t_phase_rules();
        "wce_flush":        t_wce_flush();
        "pf_quiesce":       t_pf_quiesce();
        "fast_resume":      t_fast_resume();
        "warm_reset":       t_warm_reset();
        "shutdown_ro_fail": t_shutdown_ro_failed();
        "gate_timeout":     t_gate_timeout();
        "crash_inject":     t_crash_inject();
        "random":           t_random(iter_n);
        "plp_research":     t_plp_research();
        default: ;
      endcase
      if (n_fail != f0) n_tfail++;
      $display("[ %s ] %0s", (n_fail == f0) ? "PASS" : "FAIL", name);
    end
  endtask

  int iter_n = 3000;
  initial begin
    reg [8*24-1:0] sel;
    int seed;
    if (!$value$plusargs("TEST=%s", sel)) sel = "all";
    if ($value$plusargs("SEED=%d", seed)) rng = 32'(seed) * 32'd2654435761 + 32'd1;
    if (!$value$plusargs("ITER=%d", iter_n)) iter_n = 3000;
    cmd_in = '0; cpl_in = '0;
    if (PLP) begin
      run("plp_research", sel);
    end else begin
      run("reset_boot", sel);
      run("write_gate", sel);
      run("phase_rules", sel);
      run("wce_flush", sel);
      run("pf_quiesce", sel);
      run("fast_resume", sel);
      run("warm_reset", sel);
      run("shutdown_ro_fail", sel);
      run("gate_timeout", sel);
      run("crash_inject", sel);
      run("random", sel);
    end
    $display("TB RESULT: %0d tests, %0d failed, %0d checks, %0d failed checks (N_SLOTS=%0d PLP=%0d)",
             n_tests, n_tfail, n_checks, n_fail, NS, PLP);
    $finish;
  end
  initial begin
    #50_000_000;
    $display("TB RESULT: TIMEOUT");
    $finish;
  end
endmodule

`default_nettype wire
