# SilicaFlux PowerSafe · Project 58 — power-loss protection and storage recovery

**Primary RTL:** [`rtl/silicaflux_storage_recovery.sv`](rtl/silicaflux_storage_recovery.sv) · Aureom.AI | SilicaFlux-STORE

Hardware and firmware that let the SilicaFlux storage controller survive unexpected controller resets and power
interruptions **without losing any acknowledged durable write** — by a software-managed journal/checkpoint recovery
protocol whose acknowledgements are enforced in hardware, **not** by assuming hold-up energy.

```
host ─cmd─► silicaflux_storage_recovery ─cmd (TID:=slot)─► sfs_cmd_ctrl (P51) ─► ControlCore firmware
     ◄─cpl── admission · slot table · completion gate ◄─cpl─┘                     PowerSafe layer (sfps)
             recovery FSM · power-fault latch · NAND inhibit / WP#                FlashMap FTL (P56 + P58):
             POR-domain diagnostics · telemetry · crash injection                 spare records, journal,
                     ▲ phase reports / control page ◄──────────────────────────── A/B checkpoints, event log
```

> **Status — read first.** Simulation only: RTL in Verilator 5.020 / Icarus 12, firmware as host C (its register
> accesses are RTL bus cycles in the co-simulation) and cross-compiled for RV32IM, NAND as the `simnand` behavioural
> model with NANDLab semantics. **No physical power-loss protection is claimed**: `PLP_PRESENT = 0`, and the RTL refuses to
> elaborate `PLP_PRESENT = 1` without a hardware qualification id. The capacitor model in `plp/` is a research estimate —
> no electrical value was measured. NAND times are illustrative. Delivered as an archive; nothing was committed. See
> [docs/11_LIMITATIONS.md](docs/11_LIMITATIONS.md).

## Definition of done — met

*Across reproducible injected crashes, the controller reconstructs a consistent mapping and preserves every
acknowledged durable write.*

| Evidence | Result | Report |
|---|---|---|
| **RTL + firmware co-simulation**: recovery controller + unmodified P51 command controller (Verilated), PowerSafe firmware + FTL driving them over the register bus, timed NAND behind the inhibit gate, host with queue depth 16; 640 episodes of supply loss (0…20 000 cycles of warning), named firmware crash points fired by the RTL's crash-injection unit, RTL event crashes, brown-outs, controller resets, clean shutdowns; after each: every LBA read back **through the RTL path** and checked against the independent reference model | **4 / 4 campaigns PASS** — 561 recovery boots, 485 k LBAs verified, 0 mismatches, 0 NAND rule violations | [reports/cosim/](reports/cosim/), [TESTS.md](reports/TESTS.md) §4 |
| Crash at **31 named points** covering all 8 required positions, every hit index sampled, 3 geometries, recovery then a second random crash (repeated recovery), every LBA verified, FTL invariants checked | **3 352 crash runs, 3 352 fired at their point, 0 failures** | [TESTS.md](reports/TESTS.md) §2 |
| Power cut at **every NAND operation of a recovery mount** (236), then recovery + repeated crash | **PASS** | `mount_sweep` |
| Medium in a **persistent file**; 200 controller **processes**, each recovers the previous one's medium, verifies, runs, and dies at a crash point | **200 / 200** recovered and verified (188 k LBA checks) | `process_crash` |
| Random (seed, point, k) crashes; crashes under NAND program / erase / read faults; full device; GC + static wear levelling; metadata corruption; ring-wrap fallback; write-cache contract; schema-1 upgrade | **all PASS** — 13 tests, 5 497 checks | [TESTS.md](reports/TESTS.md) §2 |
| Recovery controller unit testbench (11 tests incl. randomized power faults / resets), independent scoreboard of the gate | **21 / 21 runs PASS** (30 838 checks) on Verilator and Icarus, N_SLOTS 4…32 + PLP research build, 10 seeds | [reports/rtl_regression.md](reports/rtl_regression.md) |
| Mutation testing: 16 RTL bugs (detected by the testbench with the RTL's own assertion **off**), 10 firmware / FTL bugs | **16 / 16, 10 / 10 detected** | [reports/mutation.md](reports/mutation.md) |
| **Defence in depth**: firmware mutated to acknowledge writes *before programming them* | with the gate: **no data lost** (686–843 premature SUCCESS held per run); gate removed: **acknowledged writes lost, detected** | [reports/mutation.md](reports/mutation.md) |
| P56 FTL regression on the modified library; sanitizers | 27 / 27 (4 932 checks); ASan + UBSan clean | [TESTS.md](reports/TESTS.md) §3 |

## Audit findings that shaped the design

* **F1 — P51's power-loss sequence assumes energy that does not exist** (it drains commands and writes a checkpoint
  after the warning). P58: no new program / erase after the warning (hardware inhibit), unstarted commands aborted by
  hardware, **nothing drained or checkpointed**, WP# as soon as the operation in flight ends ([docs/07](docs/07_POWER_LOSS_POLICY.md)).
* **F2 — P56 recovery could leave the device unmountable after one damaged page** once the metadata ring had wrapped:
  **16 / 300** in a probe. P58 keeps the previous checkpoint protected (A/B retention): **0 / 300**, cost 1 metadata block
  ([docs/05](docs/05_PERSISTENT_METADATA.md)).
* Full audit: [docs/00_AUDIT.md](docs/00_AUDIT.md).

## Key measurements (modelled NAND times)

| | |
|---|---|
| Recovery after a power cut (64 MiB device) | mean 106 → 378 ms, p99 134 → 718 ms for checkpoint intervals 4 → 64 blocks; clean mount 36–50 ms; P58 = P56 within noise |
| Hardware-measured recovery (co-sim RECOVER state) | 2.0 k / 9.4 k / 15.6 k cycles min / mean / max |
| Write completion latency, durable acknowledgement | p50 1.74 ms, p99 3.27 ms (90 % full); read-back verify +150 µs; DEALLOCATE p50 0.32 ms; gate +2 cycles |
| Volatile write cache (host-enabled) | acknowledgement ≈ 0 device time; FLUSH of 16 writes ≈ 22 ms; unflushed data lost at a crash by contract |
| Metadata write amplification / checkpoints | 0.34 → 0.08 metadata pages per host page; 17.4 → 1.1 checkpoints per 1 000 host pages (intervals 4 → 64) |
| Journal overhead | 0.058 journal pages per host page (5 % DEALLOCATE); host writes need none |
| Capacity for recovery structures | 6 metadata blocks (A/B: +1 vs P56 = 1.9 % / 0.4 % of a 64 / 256-block device); 16-B spare record per page |
| Hardware | ≈ 33 k generic cells, ≈ 4.9 k flip-flops, 0 latches (16 slots, Yosys 0.33) |
| Firmware | 42 KB RV32IM code (64 % IMEM); 23.2 KiB of 32 KiB DMEM (co-sim configuration) |

Details: [docs/10](docs/10_PERFORMANCE.md), [reports/perf/PERF.md](reports/perf/PERF.md) (CSV + SVG),
[reports/synth.md](reports/synth.md), [reports/firmware_size.md](reports/firmware_size.md).

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Audit: FTL, NAND model, write buffers, DMA, PowerClock, ControlCore, Flush, journal, reset sequencing | [docs/00_AUDIT.md](docs/00_AUDIT.md) |
| 2 | Accepted / Buffered / Programmed / Verified / Mapping committed / Durable / Acknowledged; no durable ack before NV media (no-PLP) | [docs/02_PERSISTENCE_MODEL.md](docs/02_PERSISTENCE_MODEL.md); enforced by the completion gate |
| 3 | Power-fault input, admission control, outstanding-operation tracking, persistent commit status, recovery-mode control, error / status registers, reset + recovery FSM | [rtl/silicaflux_storage_recovery.sv](rtl/silicaflux_storage_recovery.sv), [docs/03](docs/03_RECOVERY_CONTROLLER.md), [docs/REGISTERS.md](docs/REGISTERS.md) |
| 4 | Versioned checkpoints, journal, generations, commit markers, integrity checks, recovery scanning; torn metadata | [docs/05](docs/05_PERSISTENT_METADATA.md), `firmware/silicaflux_ftl/`, [reports/ftl_delta.md](reports/ftl_delta.md) |
| 5 | Deterministic crashes at the 8 positions, restart, verify | [docs/06](docs/06_CRASH_INJECTION.md), `firmware/crash/`, `t_point_sweep` |
| 6 | Power-fault behaviour: stop unsafe work, in-flight policy, diagnostics, protect metadata, no energy assumed | [docs/07](docs/07_POWER_LOSS_POLICY.md) |
| 7 | Capacitor PLP research model (energy, hold-up voltage, regulator efficiency, shutdown power, flush time, temperature, ageing) — estimates | [plp/PLP_REPORT.md](plp/PLP_REPORT.md), [docs/08](docs/08_PLP_MODEL.md) |
| 8 | Acknowledged durable writes survive; unacknowledged per contract | [docs/02 §5](docs/02_PERSISTENCE_MODEL.md), reference model `firmware/ref/` |
| 9 | Persistent backing store, fault injection, independent reference, random workloads, repeated recovery, corruption, full storage, GC / WL | [docs/09](docs/09_VERIFICATION.md), [reports/TESTS.md](reports/TESTS.md) |
| 10 | Recovery time, completion latency, journal overhead, metadata WA, checkpoint frequency, capacity | [docs/10](docs/10_PERFORMANCE.md), [reports/perf/PERF.md](reports/perf/PERF.md) |
| 11 | Deliverables | below |

## Deliverables

| Deliverable | Files |
|---|---|
| `silicaflux_storage_recovery.sv` | [rtl/silicaflux_storage_recovery.sv](rtl/silicaflux_storage_recovery.sv), [rtl/sfpr_crash_inj.sv](rtl/sfpr_crash_inj.sv), generated [rtl/sfpr_regs_pkg.sv](rtl/sfpr_regs_pkg.sv) (single source: [scripts/gen_regs.py](scripts/gen_regs.py)) |
| FTL persistence integration | `firmware/silicaflux_ftl/` (P56 + P58: hooks, A/B retention, schema 2 event log, telemetry — [reports/ftl_delta.md](reports/ftl_delta.md)); PowerSafe firmware `firmware/powersafe/` (phase reporting, write cache, boot / recovery / power-fault main loop) |
| Crash-injection framework | `firmware/crash/` (31 named points, replay), RTL unit `sfpr_crash_inj.sv`, persistent-medium simulated NAND (`hal/sim/simnand.c`), co-simulation `cosim/` |
| Recovery reference model | `firmware/ref/sfref.c` |
| Power-fault tests | `tb/tb_sfpr.sv`, `firmware/tests/test_powersafe.c`, `cosim/cosim_main.cpp` |
| Recovery telemetry | RTL counters + POR-domain diagnostics ([REGISTERS](docs/REGISTERS.md)), FTL persistent event log, GET_LOG 0x58 page (decoded in `reports/cosim/*.log`) |
| Design specification | [docs/](docs/) 00 – 11 + REGISTERS |
| Reports | [reports/TESTS.md](reports/TESTS.md), rtl_regression, mutation, perf/, synth, firmware_size, ftl_delta, vendor_check |

## Quick start

Tools (Ubuntu 24.04): `verilator` 5.020, `iverilog` 12, `yosys` 0.33, `gcc-riscv64-unknown-elf` 13.2, `gcc`, `python3`.

```bash
sudo apt-get install -y verilator iverilog yosys gcc-riscv64-unknown-elf
```

```bash
make rtl-test
```

```bash
make fw-test
```

```bash
make cosim
```

```bash
make perf synth fw-size plp mutation report
```

`make all` runs everything (~45 min). Replay one crash: `firmware/build/sfps_tests --replay <geometry> <seed> <point> <k>`
(printed with every failure). `make vendor-check REPO=<checkout>` / `make ftl-delta REPO=<checkout>` compare against the
repository archives.

## Layout

```
rtl/          silicaflux_storage_recovery.sv, sfpr_crash_inj.sv, sfpr_regs_pkg.sv (generated), files.f
tb/           tb_sfpr.sv -- unit testbench (Verilator + Icarus)
cosim/        tb_cosim_top.sv + cosim_main.cpp -- RTL + firmware co-simulation (Verilator)
firmware/     silicaflux_ftl/ (FTL P56+P58, simnand, P56 tests, RV32 image build)  powersafe/ (sfps, sfps_fw)
              crash/ (named crash points)  ref/ (reference model)  tests/ (crash suite, benchmarks)
              tools/ (unmodified P56 library + schema-1 medium writer)
plp/          capacitor PLP research model + report
scripts/      gen_regs, rtl_regress, synth, perf, fw_size, mutation, tests_report, check_vendor, ftl_delta
third_party/  P51 RTL subset + ControlCore runtime subset, unmodified
docs/         00 audit ... 11 limitations, REGISTERS
reports/      TESTS, rtl_regression (+ sim logs), cosim logs, mutation, perf, synth, firmware_size, ftl_delta, vendor_check
```
