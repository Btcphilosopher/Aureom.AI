// =============================================================================
// SilicaFlux PowerSafe (Project 58) :: tb_cosim_top -- co-simulation top
//
//   host (C++) --cmd/cpl--> silicaflux_storage_recovery --cmd/cpl--> sfs_cmd_ctrl (P51, unmodified)
//                                     ^ register page                    ^ register page
//                                     +------------- firmware (C: PowerSafe + FlashMap FTL) ----+
//   nand_busy_i <- timed NAND model (C++);  nand_inhibit_o / wp_force_o -> NAND model gate
// Host channel fields are flattened to plain ports for the C++ driver.
// =============================================================================
`default_nettype none

module tb_cosim_top
  import silicaflux_storage_pkg::*;
#(
  parameter int N_SLOTS = 16
) (
  input  wire logic        clk,
  input  wire logic        por_n,
  input  wire logic        rst_n,
  input  wire logic        pwr_fail_ni,
  input  wire logic        shn_req_i,
  // host command channel
  input  wire logic        h_cmd_valid,
  output logic             h_cmd_ready,
  input  wire logic [7:0]  h_op,
  input  wire logic [7:0]  h_flags,
  input  wire logic [15:0] h_tid,
  input  wire logic [63:0] h_addr,
  input  wire logic [31:0] h_len,
  input  wire logic [63:0] h_haddr,
  // host completion channel
  output logic             h_cpl_valid,
  input  wire logic        h_cpl_ready,
  output logic [15:0]      h_cpl_tid,
  output logic [6:0]       h_cpl_status,
  output logic [7:0]       h_cpl_err,
  output logic [31:0]      h_cpl_r0,
  // firmware bus
  input  wire logic        rb_sel_rec,
  input  wire logic        rb_sel_cmd,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  // media / status
  input  wire logic        nand_busy_i,
  output logic             nand_inhibit_o,
  output logic             wp_force_o,
  output logic             rdy_o,
  output logic             pf_active_o,
  output logic [1:0]       shst_o,
  output logic             ci_crash_o,
  output logic             ci_warm_o,
  // observation only (bench statistics across resets): completions the gate had to hold
  output logic [31:0]      dbg_gate_held,
  output logic [31:0]      dbg_gate_conv
);
  assign dbg_gate_held = u_rec.c_gate_held;
  assign dbg_gate_conv = u_rec.c_gate_conv;
  wire crst_n = rst_n & por_n;

  sfs_cmd_t hc, fc;
  sfs_cpl_t hp, fp;
  logic     f_cmd_valid, f_cmd_ready, f_cpl_valid, f_cpl_ready, quiesce;
  logic [31:0] rd_rec, rd_cmd;
  logic        er_rec, er_cmd;

  always_comb begin
    hc           = '0;
    hc.opcode    = h_op;
    hc.addr_type = SFS_ADDR_LOGICAL;
    hc.dir       = sfs_op_dir(h_op);
    hc.flags     = h_flags;
    hc.tid       = h_tid;
    hc.addr      = h_addr;
    hc.len       = h_len;
    hc.host_addr = h_haddr;
  end
  assign h_cpl_tid    = hp.tid;
  assign h_cpl_status = hp.status;
  assign h_cpl_err    = hp.err;
  assign h_cpl_r0     = hp.result0;

  /* verilator lint_off PINCONNECTEMPTY */
  silicaflux_storage_recovery #(.N_SLOTS(N_SLOTS), .HWQ_DEPTH(4), .CRASH_INJ_EN(1'b1)) u_rec (
    .clk, .por_n, .rst_n, .pwr_fail_ni, .shn_req_i,
    .cmd_in_valid(h_cmd_valid), .cmd_in_ready(h_cmd_ready), .cmd_in(hc),
    .cpl_out_valid(h_cpl_valid), .cpl_out_ready(h_cpl_ready), .cpl_out(hp),
    .cmd_out_valid(f_cmd_valid), .cmd_out_ready(f_cmd_ready), .cmd_out(fc),
    .cpl_in_valid(f_cpl_valid), .cpl_in_ready(f_cpl_ready), .cpl_in(fp),
    .rb_sel(rb_sel_rec), .rb_we, .rb_addr, .rb_wdata, .rb_rdata(rd_rec), .rb_err(er_rec),
    .nand_busy_i, .nand_inhibit_o, .wp_force_o, .quiesce_o(quiesce),
    .rdy_o, .ro_o(), .fatal_o(), .pf_active_o, .shst_o, .irq_o(),
    .ci_crash_o, .ci_pf_o(), .ci_warm_o
  );

  sfs_cmd_ctrl #(.CMD_QUEUE_DEPTH(N_SLOTS), .ADDRESS_WIDTH(32), .HBUF_ALIGN(4), .MDTS_RESET(16)) u_cmd (
    .clk, .rst_n(crst_n),
    .cmd_valid(f_cmd_valid), .cmd_ready(f_cmd_ready), .cmd(fc),
    .cpl_valid(f_cpl_valid), .cpl_ready(f_cpl_ready), .cpl(fp),
    .rb_sel(rb_sel_cmd), .rb_we, .rb_addr, .rb_wdata, .rb_rdata(rd_cmd), .rb_err(er_cmd),
    .phys_en(1'b0), .plp_quiesce(quiesce), .resetting(1'b0),
    .capacity(), .mdts(), .outstanding_zero(), .irq_cmd(), .ev_fw_err(), .ev_lat_valid(), .ev_lat()
  );
  /* verilator lint_on PINCONNECTEMPTY */

  assign rb_rdata = rb_sel_cmd ? rd_cmd : rd_rec;
  assign rb_err   = rb_sel_cmd ? er_cmd : (rb_sel_rec ? er_rec : 1'b0);
endmodule

`default_nettype wire
