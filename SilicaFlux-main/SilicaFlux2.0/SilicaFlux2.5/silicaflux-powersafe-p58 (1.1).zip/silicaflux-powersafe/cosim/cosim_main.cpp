// =============================================================================
// SilicaFlux PowerSafe (Project 58) -- RTL + firmware co-simulation
//
// The Verilated RTL (silicaflux_storage_recovery + P51 sfs_cmd_ctrl) runs with
//  - the PowerSafe firmware + FlashMap FTL (C) as the ControlCore: every
//    register access is one bus cycle on the RTL;
//  - a timed NAND device (simnand) behind the controller's inhibit gate;
//  - a host that submits WRITE/READ/DEALLOCATE/FLUSH (FUA) commands with queue
//    depth up to 16, and keeps the independent reference model (sfref);
//  - a power / reset environment injecting, per episode, one of:
//      supply loss at a random cycle with 0 .. HOLD cycles of warning,
//      a named firmware crash point (CI_MARK -> RTL crash-injection unit),
//      an RTL event crash (k-th admission / completion / phase / NAND op),
//      a brown-out (warning, supply returns), a controller reset, or a clean
//      shutdown followed by a power cycle.
// After every crash/reset the host waits for READY and reads every LBA back
// through the RTL path; the reference model decides.
// NAND times are compressed: 1 cycle = 1 us of the illustrative NANDLab SLC
// times (tR 25, tPROG 200, tBERS 2000 cycles), so cycle counts are only
// comparable with each other.
// usage: Vtb_cosim_top [episodes] [seed] [wce 0|1] [hold_max]
// =============================================================================
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cinttypes>
#include <vector>
#include "Vtb_cosim_top.h"
#include "verilated.h"
extern "C" {
#include "sfftl.h"
#include "simnand.h"
#include "sfps_fw.h"
#include "sfcrash.h"
#include "sfref.h"
#include "sfps_regs.h"
}

// ---------------------------------------------------------------- parameters
static const uint32_t QD = 16, MDTS = 16, LBA = 512;
static const uint32_t T_R = 25, T_PROG = 200, T_BERS = 2000;   // cycles
static const uint32_t P51_SFS_OP_FLUSH = 0, OP_WRITE = 1, OP_READ = 2, OP_DEALLOC = 9;

// ---------------------------------------------------------------- simulation state
static Vtb_cosim_top *top;
static uint64_t cyc = 0;
static bool supply = true;          // supply present
static bool dead = false;           // firmware must unwind (supply lost / controller reset)
static int  tear_mode = SIMNAND_CUT_RANDOM;
static uint64_t ev_loss_at = UINT64_MAX, ev_pf_at = UINT64_MAX, ev_pf_off_at = UINT64_MAX, ev_warm_at = UINT64_MAX;
static int  pending_reset = 0;      // 1 power-on, 2 controller reset
static simnand_t *nand;
static uint64_t rng_state = 1;
static uint64_t rnd() {
  uint64_t z = (rng_state += 0x9E3779B97F4A7C15ull);
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
  return z ^ (z >> 31);
}

// ---------------------------------------------------------------- host model
struct HCmd {
  bool used = false, submitted = false;
  uint32_t op = 0, fua = 0, n = 0, refop = 0, flush_mark = 0;
  uint64_t lba = 0, haddr = 0;
  bool verify = false, after_crash = false;
};
static HCmd hq[QD + 1];             // index = host TID (1..QD)
static std::vector<uint8_t> hostmem(QD * MDTS * LBA + 4096);
static std::vector<uint8_t> lba_busy;
static sfref_t ref;
static int wce = 0;
static int presenting = 0;          // TID being presented on the command channel
static uint64_t nlba = 0;
static bool host_gen = false;       // generate random workload (off until the device is up)
static uint32_t verify_next = 0, verify_end = 0, verify_inflight = 0;
static bool verifying = false, verify_after_crash = false;
static char why[400];
static bool failed = false;
static uint64_t backoff_until = 0;  // host backs off after an abort (power loss / not ready)

struct Stats {
  uint64_t submitted, completed, cpl_success, durable_acks, vol_acks, flushes_ok, aborted_pf, rejected_state;
  uint64_t lbas_verified, episodes, losses, named, rtl_events, brownouts, warm, shutdowns, verify_rounds;
  uint64_t recov_cycles_sum, recov_cycles_max, recoveries;
  uint64_t named_fired, rtl_fired, gate_held, gate_conv, vol_lost_hw;
  uint64_t format_cycles, recov_min, unclean_mounts, clean_mounts, fallback_mounts;
} S;

static void host_complete(uint16_t tid, uint32_t status) {
  HCmd &c = hq[tid];
  if (!c.used) { snprintf(why, sizeof(why), "completion for unknown host TID %u", tid); failed = true; return; }
  S.completed++;
  bool ok = status == 0;
  if (ok) S.cpl_success++;
  if (status == 5) S.aborted_pf++;
  if (status == 7 || status == 6 || status == 10) S.rejected_state++;
  if (status == 5 || status == 7 || status == 6) backoff_until = cyc + 500;
  if (c.op == OP_WRITE) {
    int ack = SFREF_ACK_NONE;
    if (ok) ack = (wce && !c.fua) ? SFREF_ACK_VOLATILE : SFREF_ACK_DURABLE;
    if (ack == SFREF_ACK_DURABLE) S.durable_acks++;
    if (ack == SFREF_ACK_VOLATILE) S.vol_acks++;
    sfref_write_end(&ref, c.refop, c.lba, c.n, ack);
  } else if (c.op == OP_DEALLOC) {
    sfref_trim_end(&ref, c.lba, c.n, ok ? SFREF_ACK_DURABLE : SFREF_ACK_NONE);
    if (ok) S.durable_acks++;
  } else if (c.op == P51_SFS_OP_FLUSH) {
    sfref_flush_end(&ref, c.flush_mark, ok);
    if (ok) S.flushes_ok++;
  } else if (c.op == OP_READ && ok) {
    for (uint32_t i = 0; i < c.n; i++) {
      if (sfref_check(&ref, c.lba + i, &hostmem[c.haddr + (size_t)i * LBA], c.after_crash)) {
        snprintf(why, sizeof(why), "cycle %" PRIu64 ": %s", cyc, ref.why);
        failed = true;
      }
    }
    if (c.verify) { S.lbas_verified += c.n; verify_inflight--; }
  } else if (c.op == OP_READ && c.verify) {
    snprintf(why, sizeof(why), "verification read LBA %" PRIu64 "+%u failed: status %u", c.lba, c.n, status);
    failed = true;
    verify_inflight--;
  }
  if (c.op != P51_SFS_OP_FLUSH)
    for (uint32_t i = 0; i < c.n; i++) lba_busy[c.lba + i] = 0;
  c = HCmd();
}

// every in-flight command is lost (the host will never see its completion)
static void host_lose_all() {
  for (uint32_t t = 1; t <= QD; t++) {
    HCmd &c = hq[t];
    if (!c.used) continue;
    if (c.submitted || (int)t == presenting) {
      if (c.op == OP_WRITE) sfref_write_end(&ref, c.refop, c.lba, c.n, SFREF_ACK_NONE);
      if (c.op == OP_DEALLOC) sfref_trim_end(&ref, c.lba, c.n, SFREF_ACK_NONE);
      if (c.verify) verify_inflight--;
    }
    if (c.op != P51_SFS_OP_FLUSH) for (uint32_t i = 0; i < c.n; i++) lba_busy[c.lba + i] = 0;
    c = HCmd();
  }
  presenting = 0;
  top->h_cmd_valid = 0;
}

static int free_tid() {
  for (uint32_t t = 1; t <= QD; t++) if (!hq[t].used) return (int)t;
  return 0;
}

static void host_present(int t) {
  HCmd &c = hq[t];
  top->h_cmd_valid = 1;
  top->h_op = (uint8_t)c.op;
  top->h_flags = c.fua ? 0x02 : 0x00;
  top->h_tid = (uint16_t)t;
  top->h_addr = c.lba;
  top->h_len = c.n;
  top->h_haddr = c.haddr;
  presenting = t;
}

// choose the next command (no two in-flight commands touch the same LBA)
static bool range_free(uint64_t lba, uint32_t n) {
  for (uint32_t i = 0; i < n; i++) if (lba_busy[lba + i]) return false;
  return true;
}
static void host_generate() {
  if (presenting || nlba == 0) return;
  int t = free_tid();
  if (!t) return;
  HCmd c;
  c.used = true;
  c.haddr = (uint64_t)(t - 1) * MDTS * LBA;
  if (verifying) {
    if (verify_next >= verify_end) return;
    c.op = OP_READ;
    c.lba = verify_next;
    c.n = (uint32_t)((verify_end - verify_next) < MDTS ? verify_end - verify_next : MDTS);
    if (!range_free(c.lba, c.n)) return;
    c.verify = true;
    c.after_crash = verify_after_crash;
    verify_next += c.n;
    verify_inflight++;
  } else {
    if (!host_gen || cyc < backoff_until) return;
    uint32_t r = (uint32_t)(rnd() % 100);
    c.n = 1 + (uint32_t)(rnd() % MDTS);
    c.lba = (rnd() % 100 < 30) ? rnd() % (nlba / 8) : rnd() % nlba;
    if (c.lba + c.n > nlba) c.n = (uint32_t)(nlba - c.lba);
    if (r < 8) c.op = P51_SFS_OP_FLUSH, c.n = 0;
    else if (r < 16) c.op = OP_DEALLOC;
    else if (r < 46) c.op = OP_READ;
    else { c.op = OP_WRITE; c.fua = rnd() % 100 < 15; }
    if (c.op != P51_SFS_OP_FLUSH && !range_free(c.lba, c.n)) return;
    if (c.op == OP_WRITE) c.refop = sfref_write_begin(&ref, c.lba, c.n, &hostmem[c.haddr]);
    if (c.op == OP_DEALLOC) sfref_trim_begin(&ref, c.lba, c.n);
    if (c.op == P51_SFS_OP_FLUSH) c.lba = 0;
  }
  if (c.op != P51_SFS_OP_FLUSH) for (uint32_t i = 0; i < c.n; i++) lba_busy[c.lba + i] = 1;
  hq[t] = c;
  host_present(t);
}

// ---------------------------------------------------------------- clock
static void power_loss_now();
static uint32_t last_held = 0, last_conv = 0;
static uint64_t tot_held = 0, tot_conv = 0;      // accumulated across controller resets
static void tick() {
  top->h_cpl_ready = (rnd() % 100) < 85;
  top->eval();
  bool cmd_hs = top->h_cmd_valid && top->h_cmd_ready;
  bool cpl_hs = top->h_cpl_valid && top->h_cpl_ready;
  uint16_t ctid = top->h_cpl_tid;
  uint32_t cst = top->h_cpl_status;
  if (cmd_hs && presenting) {
    HCmd &c = hq[presenting];
    c.submitted = true;
    S.submitted++;
    if (c.op == P51_SFS_OP_FLUSH) c.flush_mark = sfref_flush_begin(&ref);   // covers acks seen so far
  }
  top->clk = 1; top->eval();
  top->clk = 0; top->eval();
  cyc++;
  {
    uint32_t h = top->dbg_gate_held, c = top->dbg_gate_conv;
    if (h >= last_held) tot_held += h - last_held; else tot_held += h;     // counter reset in between
    if (c >= last_conv) tot_conv += c - last_conv; else tot_conv += c;
    last_held = h; last_conv = c;
  }
  if (cmd_hs) { presenting = 0; top->h_cmd_valid = 0; }
  if (cpl_hs && supply && top->por_n && top->rst_n) host_complete(ctid, cst);
  if (supply && top->por_n && top->rst_n) host_generate();
  // power / reset environment
  if (supply && cyc == ev_pf_at) top->pwr_fail_ni = 0;
  if (supply && cyc == ev_pf_off_at) top->pwr_fail_ni = 1;
  if (supply && (cyc == ev_loss_at || top->ci_crash_o)) power_loss_now();
  if (supply && !dead && (cyc == ev_warm_at || top->ci_warm_o)) {
    dead = true;                     // the ControlCore is reset: firmware stops at once
    pending_reset = 2;
    top->rst_n = 0;
  }
}

static void power_loss_now() {
  supply = false;
  dead = true;
  pending_reset = 1;
  top->por_n = 0;
  top->rst_n = 0;
  top->nand_busy_i = 0;
  simnand_power_off(nand);           // ops after this fail; an op in its busy window is torn (below)
}

// ---------------------------------------------------------------- firmware platform (register bus)
static uint32_t bus(int sel, bool we, uint32_t a, uint32_t d) {
  if (dead) return 0;
  top->rb_sel_rec = sel == 0;
  top->rb_sel_cmd = sel == 1;
  top->rb_we = we;
  top->rb_addr = a;
  top->rb_wdata = d;
  top->eval();
  uint32_t v = top->rb_rdata;
  tick();
  top->rb_sel_rec = 0; top->rb_sel_cmd = 0; top->rb_we = 0;
  return v;
}
static uint32_t p_rec_rd(void *, uint32_t a) { return bus(0, false, a, 0); }
static void p_rec_wr(void *, uint32_t a, uint32_t v) { bus(0, true, a, v); }
static uint32_t p_cmd_rd(void *, uint32_t a) { return bus(1, false, a, 0); }
static void p_cmd_wr(void *, uint32_t a, uint32_t v) { bus(1, true, a, v); }
static int p_dma_in(void *, uint64_t ha, void *dst, uint32_t bytes) {
  if (dead || ha + bytes > hostmem.size()) return -1;
  memcpy(dst, &hostmem[ha], bytes);
  for (uint32_t i = 0; i < bytes / 256u && !dead; i++) tick();     // transfer time
  return dead ? -1 : 0;
}
static int p_dma_out(void *, uint64_t ha, const void *src, uint32_t bytes) {
  if (dead || ha + bytes > hostmem.size()) return -1;
  memcpy(&hostmem[ha], src, bytes);
  for (uint32_t i = 0; i < bytes / 256u && !dead; i++) tick();
  return dead ? -1 : 0;
}
static int p_alive(void *) { return !dead; }

// ---------------------------------------------------------------- timed NAND behind the controller's gate
// returns 0 completed, 1 supply lost inside the busy window
static int window(uint32_t cycles) {
  top->nand_busy_i = 1;
  for (uint32_t i = 0; i < cycles; i++) {
    tick();
    if (!supply) { top->nand_busy_i = 0; return 1; }
    // a controller reset does not stop the die: the operation completes
  }
  top->nand_busy_i = 0;
  return 0;
}
static uint64_t inhibit_refusals = 0;
static int n_read(void *, uint32_t ppn, void *d, void *s, uint32_t *bf) {
  if (dead) return SFFTL_HAL_POWER_LOSS;
  if (window(T_R)) return SFFTL_HAL_POWER_LOSS;
  return simnand_read(nand, ppn, (uint8_t *)d, (uint8_t *)s, bf);
}
static int n_prog(void *, uint32_t ppn, const void *d, const void *s) {
  if (dead) return SFFTL_HAL_POWER_LOSS;
  if (top->nand_inhibit_o) { inhibit_refusals++; return SFFTL_HAL_POWER_LOSS; }   // hardware gate: no new program
  if (window(T_PROG)) {
    simnand_power_on(nand);                          // apply the interrupted program's effect ...
    simnand_arm_powercut_mode(nand, 0, tear_mode);
    simnand_program(nand, ppn, (const uint8_t *)d, (const uint8_t *)s);
    return SFFTL_HAL_POWER_LOSS;                     // ... and the supply is gone again
  }
  return simnand_program(nand, ppn, (const uint8_t *)d, (const uint8_t *)s);
}
static int n_erase(void *, uint32_t pbn) {
  if (dead) return SFFTL_HAL_POWER_LOSS;
  if (top->nand_inhibit_o) { inhibit_refusals++; return SFFTL_HAL_POWER_LOSS; }
  if (window(T_BERS)) {
    simnand_power_on(nand);
    simnand_arm_powercut_mode(nand, 0, tear_mode == SIMNAND_CUT_RANDOM ? SIMNAND_CUT_RANDOM : SIMNAND_CUT_PARTIAL);
    simnand_erase(nand, pbn);
    return SFFTL_HAL_POWER_LOSS;
  }
  return simnand_erase(nand, pbn);
}
static int n_marker(void *, uint32_t ppn, uint8_t *m) {
  if (dead) return SFFTL_HAL_POWER_LOSS;
  if (window(T_R)) return SFFTL_HAL_POWER_LOSS;
  return simnand_read_marker(nand, ppn, m);
}
static void n_wp(void *, int on) { simnand_write_protect(nand, on); }

// ---------------------------------------------------------------- firmware instance
static sfps_fw_t fw;
static sfftl_geom_t G = { 512, 16, 16, 64 };
static sfftl_cfg_t CFG;
static std::vector<uint8_t> arena, wcbuf, iobuf;
static sfcrash_t cr;
static int sel_point = CP_NONE;
static bool first_boot = true;

static void cr_on_hit(void *, int p) {
  if (p == sel_point && !dead) {
    bus(0, true, SFPR_CI_MARK, (uint32_t)p);
    if (sfcrash_mode(p) == 0) for (int i = 0; i < 3 && !dead; i++) tick();   // "before": lands before the next NAND op
  }
}

static void fw_new() {
  sfps_plat_t pl;
  memset(&pl, 0, sizeof(pl));
  pl.rec_rd = p_rec_rd; pl.rec_wr = p_rec_wr; pl.cmd_rd = p_cmd_rd; pl.cmd_wr = p_cmd_wr;
  pl.dma_in = p_dma_in; pl.dma_out = p_dma_out; pl.alive = p_alive;
  sfftl_hal_t hal;
  memset(&hal, 0, sizeof(hal));
  hal.read = n_read; hal.program = n_prog; hal.erase = n_erase; hal.read_marker = n_marker; hal.write_protect = n_wp;
  sfps_fw_init(&fw, &pl, &G, &CFG, &hal, arena.data(), arena.size(), wcbuf.data(), 8, iobuf.data(), MDTS);
  fw.allow_format = first_boot;
  fw.wce = wce;
  sfcrash_init(&cr, nand, CP_NONE, 1);
  cr.on_hit = cr_on_hit;
  fw.user_hook = sfcrash_hook;
  fw.user_ctx = &cr;
}

// ---------------------------------------------------------------- reset / boot
static void boot(bool power_cycle) {
  host_gen = false;                  // the host waits for the device (commands now would be refused NOT_READY)
  if (power_cycle) {
    top->por_n = 0; top->rst_n = 0;
    for (int i = 0; i < 4; i++) tick();
    supply = true;
    simnand_power_on(nand);
    simnand_disarm_powercut(nand);
    top->pwr_fail_ni = 1;
    top->por_n = 1;
  } else {
    top->rst_n = 0;
    for (int i = 0; i < 4; i++) tick();
  }
  top->rst_n = 1;
  dead = false;
  pending_reset = 0;
  tick(); tick();
  fw_new();
  bool fb = first_boot;
  int r = sfps_fw_boot(&fw);
  first_boot = false;
  uint64_t rc = (uint64_t)p_rec_rd(nullptr, SFPR_RECOV_CYC_LAST);
  if (fb) S.format_cycles = rc;                       // first boot formats the blank medium
  else {
    S.recov_cycles_sum += rc;
    if (rc > S.recov_cycles_max) S.recov_cycles_max = rc;
    if (S.recov_min == 0 || rc < S.recov_min) S.recov_min = rc;
    S.recoveries++;
    if (fw.ftl.st.last_mount_clean) S.clean_mounts++; else S.unclean_mounts++;
    if (fw.ftl.st.last_mount_fallback || fw.ftl.st.last_mount_incomplete) S.fallback_mounts++;
  }
  if (r != (int)SFPR_RD_OK && !dead) {
    snprintf(why, sizeof(why), "boot: recovery result %d (mount rc %d)", r, (int)fw.st.last_mount_rc);
    failed = true;
  }
}

// run the firmware until `until` cycles passed or the host has nothing left
static void run_cycles(uint64_t n) {
  uint64_t end = cyc + n;
  while (cyc < end && !failed) {
    if (dead) {
      if (pending_reset == 1 || pending_reset == 2) return;
      tick();
      continue;
    }
    int r = sfps_fw_poll(&fw);
    if (r <= 0) tick();
  }
}

static void verify_all(bool after_crash) {
  verifying = true;
  verify_after_crash = after_crash;
  verify_next = 0;
  verify_end = (uint32_t)nlba;
  verify_inflight = 0;
  uint64_t guard = cyc + 4000000;
  while (!failed && (verify_next < verify_end || verify_inflight > 0) && cyc < guard) {
    if (dead) break;
    int r = sfps_fw_poll(&fw);
    if (r <= 0) tick();
  }
  // drain non-verify commands still in flight
  verifying = false;
  if (cyc >= guard) { snprintf(why, sizeof(why), "verification did not finish"); failed = true; }
  if (!failed && after_crash && sfref_check_atomic(&ref)) { snprintf(why, sizeof(why), "%s", ref.why); failed = true; }
  S.verify_rounds++;
}

static void quiesce_host() {
  host_gen = false;
  uint64_t guard = cyc + 2000000;
  for (;;) {
    bool any = false;
    for (uint32_t t = 1; t <= QD; t++) any |= hq[t].used;
    if (!any || dead || failed || cyc > guard) break;
    int r = sfps_fw_poll(&fw);
    if (r <= 0) tick();
  }
}

static void ci_arm(uint32_t ev, uint32_t arg, uint32_t count, uint32_t delay, uint32_t act) {
  p_rec_wr(nullptr, SFPR_CI_COUNT, count);
  p_rec_wr(nullptr, SFPR_CI_DELAY, delay);
  p_rec_wr(nullptr, SFPR_CI_CTRL, 1u | (act << 1) | (ev << 4) | (arg << 8));
}

int main(int argc, char **argv) {
  Verilated::commandArgs(argc, argv);
  int episodes = argc > 1 ? atoi(argv[1]) : 60;
  uint64_t seed = argc > 2 ? strtoull(argv[2], nullptr, 0) : 1;
  wce = argc > 3 ? atoi(argv[3]) : 1;
  uint32_t hold_max = argc > 4 ? (uint32_t)atoi(argv[4]) : 3000;
  rng_state = seed * 0x9E3779B97F4A7C15ull + 1;
  top = new Vtb_cosim_top;
  sfftl_cfg_default(&CFG);
  CFG.lba_bytes = LBA;
  arena.resize(sfftl_mem_required(&G, &CFG) + 64);
  wcbuf.resize(8 * G.page_data_bytes);
  iobuf.resize(MDTS * LBA);
  simnand_cfg_t nc;
  simnand_cfg_default(&nc, G.page_data_bytes, G.pages_per_block, G.blocks);
  nc.page_spare_bytes = G.page_spare_bytes;
  nc.torn_pass_permille = 250;
  nand = simnand_create(&nc, seed * 7919 + 1);
  top->pwr_fail_ni = 1; top->shn_req_i = 0; top->h_cmd_valid = 0; top->nand_busy_i = 0;
  boot(true);
  if (failed) { printf("COSIM RESULT: FAIL %s\n", why); return 1; }
  nlba = sfftl_capacity_lba(&fw.ftl);
  lba_busy.assign(nlba, 0);
  sfref_init(&ref, nlba, LBA, 1, nullptr);
  printf("co-sim: %" PRIu64 " LBAs, WCE %d, queue depth %u, %d episodes, seed %" PRIu64 ", hold-up 0..%u cycles\n",
         nlba, wce, QD, episodes, seed, hold_max);
  for (int ep = 0; ep < episodes && !failed; ep++) {
    S.episodes++;
    host_gen = true;
    uint32_t kind = (uint32_t)(rnd() % 100);
    uint64_t span = 20000 + rnd() % 60000;
    ev_loss_at = ev_pf_at = ev_pf_off_at = ev_warm_at = UINT64_MAX;
    sel_point = CP_NONE;
    tear_mode = SIMNAND_CUT_RANDOM;
    int type;
    if (kind < 30) {                                 // supply loss with 0..hold_max warning (no PLP)
      type = 0;
      uint64_t at = cyc + 2000 + rnd() % span;
      uint32_t hold = (rnd() % 3 == 0) ? 0u : (uint32_t)(rnd() % (hold_max + 1));
      ev_pf_at = at;
      ev_loss_at = at + hold;
      S.losses++;
    } else if (kind < 62) {                          // a named firmware crash point, fired by the RTL
      type = 1;
      sel_point = 1 + (int)(rnd() % (CP_MOUNT_DURING_CKPT - 1));
      if (sel_point == CP_FLUSH_BEFORE_COMPLETION && !wce) sel_point = CP_BEFORE_COMPLETION;
      uint32_t k = 1 + (uint32_t)(rnd() % 12);
      int mode = sfcrash_mode(sel_point);
      tear_mode = mode ? mode : SIMNAND_CUT_RANDOM;
      uint32_t win = (sel_point == CP_GC_DURING_ERASE || sel_point == CP_OPEN_DURING_ERASE || sel_point == CP_META_DURING_ERASE)
                         ? T_BERS : T_PROG;
      uint32_t delay = mode == 0 ? 0u : (mode == SIMNAND_CUT_COMPLETED ? T_PROG + 3u : (uint32_t)(rnd() % (win - 20)) + 5u);
      ci_arm(SFPR_CIEV_MARK, (uint32_t)sel_point, k, delay, SFPR_CIACT_CRASH);
      S.named++;
    } else if (kind < 75) {                          // an RTL event crash
      type = 2;
      static const uint32_t evs[4] = { SFPR_CIEV_ADMIT, SFPR_CIEV_HOSTCPL, SFPR_CIEV_PHASE, SFPR_CIEV_NANDOP };
      uint32_t ev = evs[rnd() % 4];
      uint32_t arg = ev == SFPR_CIEV_PHASE ? (uint32_t)(SFPR_PH_STARTED + rnd() % 6) : 0u;
      ci_arm(ev, arg, 1 + (uint32_t)(rnd() % 60), (uint32_t)(rnd() % 300), (rnd() % 4 == 0) ? SFPR_CIACT_CRASH_PF : SFPR_CIACT_CRASH);
      S.rtl_events++;
    } else if (kind < 87) {                          // brown-out: warning, the supply comes back
      type = 3;
      uint64_t at = cyc + 2000 + rnd() % span;
      ev_pf_at = at;
      ev_pf_off_at = at + 50 + rnd() % 5000;
      S.brownouts++;
    } else if (kind < 97) {                          // controller reset with supply present
      type = 4;
      ev_warm_at = cyc + 2000 + rnd() % span;
      S.warm++;
    } else {                                         // clean shutdown, then power cycle
      type = 5;
      S.shutdowns++;
    }
    if (type == 5) {
      run_cycles(10000 + rnd() % 30000);
      quiesce_host();
      top->shn_req_i = 1;
      for (int i = 0; i < 400000 && !failed && top->shst_o != 2; i++) { int r = sfps_fw_poll(&fw); if (r <= 0) tick(); }
      top->shn_req_i = 0;
      if (top->shst_o != 2) { snprintf(why, sizeof(why), "shutdown did not complete"); failed = true; break; }
      host_lose_all();
      sfref_crash(&ref);
      boot(true);
      if (!failed && !fw.ftl.st.last_mount_clean) { snprintf(why, sizeof(why), "mount after a clean shutdown was not clean"); failed = true; }
      if (!failed) verify_all(true);
      continue;
    }
    run_cycles(span + 30000);
    if (failed) break;
    bool crashed = pending_reset != 0;
    if (type == 1) S.named_fired += crashed;
    if (type == 2) S.rtl_fired += crashed;
    if (!crashed && (type == 0 || type == 4)) {      // event scheduled after the window: force it now
      if (type == 0) power_loss_now(); else { dead = true; pending_reset = 2; top->rst_n = 0; }
      crashed = true;
    }
    if (!crashed && (type == 1 || type == 2)) {      // point not reached: plain power loss
      p_rec_wr(nullptr, SFPR_CI_CTRL, 0);
      power_loss_now();
      crashed = true;
    }
    if (crashed) {
      // read the hardware's view of the fault before the reset destroys it (warm reset keeps STK_*)
      host_lose_all();
      sfref_crash(&ref);
      boot(pending_reset == 1);
      if (!failed) verify_all(true);
    } else {
      // brown-out: no reset; the firmware recovered in place; verify without settling
      quiesce_host();
      if (!failed) verify_all(false);
    }
    if (ep % 10 == 9)
      printf("  episode %d: cycles %" PRIu64 ", host cmds %" PRIu64 ", LBAs verified %" PRIu64 "\n", ep + 1, cyc,
             S.submitted, S.lbas_verified);
  }
  // final telemetry from the RTL
  S.gate_held = tot_held;
  S.gate_conv = tot_conv;
  if (!failed && !dead) {
    // the GET_LOG telemetry page the firmware serves (built from FTL + controller registers)
    uint8_t pg[512];
    sfps_fw_telemetry(&fw, pg);
    auto W = [&](int i) { return (uint32_t)pg[4 * i] | ((uint32_t)pg[4 * i + 1] << 8) | ((uint32_t)pg[4 * i + 2] << 16) | ((uint32_t)pg[4 * i + 3] << 24); };
    printf("telemetry (GET_LOG 0x58): magic %08x, events %u, unsafe shutdowns %u, recoveries %u, fallback mounts %u, "
           "damaged metadata %u, torn pages discarded %u, power faults reported %u\n",
           W(0), W(2), W(3), W(4), W(5), W(6), W(7), W(8));
    printf("  last mount: scanned %u replayed %u torn %u, %u NAND reads, schema %u, clean %u; controller RECOV_CYC_LAST %u, "
           "cause %u\n", W(9) & 0xFFFF, W(9) >> 16, W(10) & 0xFF, W(11), W(12) & 0xFF, W(12) >> 8, W(13), W(15));
    static const char *tn[] = { "?", "FORMAT", "RECOVERY", "POWER_FAULT", "BROWNOUT", "READONLY", "UPGRADE", "META_DAMAGE" };
    for (int i = 0; i < 8; i++) {
      uint32_t ty = W(24 + 8 * i);
      if (!ty) break;
      printf("  event[-%d] %-11s seq %8u mount %4u  %08x %08x %08x %08x %08x\n", i, ty < 8 ? tn[ty] : "?", W(25 + 8 * i),
             W(26 + 8 * i), W(27 + 8 * i), W(28 + 8 * i), W(29 + 8 * i), W(30 + 8 * i), W(31 + 8 * i));
    }
  }
  printf("episodes %" PRIu64 ": supply losses %" PRIu64 ", named firmware points %" PRIu64 " (fired %" PRIu64 "), RTL event crashes %" PRIu64
         " (fired %" PRIu64 "), brown-outs %" PRIu64 ", controller resets %" PRIu64 ", clean shutdowns %" PRIu64 "\n",
         S.episodes, S.losses, S.named, S.named_fired, S.rtl_events, S.rtl_fired, S.brownouts, S.warm, S.shutdowns);
  printf("host: %" PRIu64 " commands submitted, %" PRIu64 " completed (%" PRIu64 " SUCCESS, %" PRIu64 " ABORT_PWR_LOSS), %" PRIu64
         " durable acks, %" PRIu64 " volatile acks, %" PRIu64 " FLUSH ok\n",
         S.submitted, S.completed, S.cpl_success, S.aborted_pf, S.durable_acks, S.vol_acks, S.flushes_ok);
  printf("verification: %" PRIu64 " rounds, %" PRIu64 " LBAs read back through the RTL path, %" PRIu64 " reference checks, "
         "%" PRIu64 " volatile acks lost at crashes (allowed)\n", S.verify_rounds, S.lbas_verified, ref.checks, ref.vol_lost);
  printf("recovery: %" PRIu64 " recovery boots (%" PRIu64 " unclean, %" PRIu64 " clean, %" PRIu64 " used an older checkpoint), "
         "RECOVER state %" PRIu64 " / %" PRIu64 " / %" PRIu64 " cycles min / mean / max (hardware-measured); first-boot format %" PRIu64 " cycles\n",
         S.recoveries, S.unclean_mounts, S.clean_mounts, S.fallback_mounts, S.recov_min,
         S.recoveries ? S.recov_cycles_sum / S.recoveries : 0, S.recov_cycles_max, S.format_cycles);
  printf("controller: gate held %" PRIu64 " SUCCESS completions (all resets), converted %" PRIu64 "; NAND inhibit gate refused %" PRIu64
         " program/erase; simulated %" PRIu64 " cycles\n", S.gate_held, S.gate_conv, inhibit_refusals, cyc);
  printf("NAND rule violations: %" PRIu64 "\n", simnand_stats(nand)->violations);
  if (simnand_stats(nand)->violations) { failed = true; snprintf(why, sizeof(why), "NAND rule violations"); }
  printf("COSIM RESULT: %s%s%s\n", failed ? "FAIL " : "PASS", failed ? "" : "", failed ? why : "");
  top->final();
  delete top;
  return failed ? 1 : 0;
}
