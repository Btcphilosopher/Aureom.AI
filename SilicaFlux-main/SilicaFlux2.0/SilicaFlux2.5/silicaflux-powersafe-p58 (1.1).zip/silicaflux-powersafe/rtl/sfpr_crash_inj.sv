// =============================================================================
// SilicaFlux PowerSafe (Project 58) :: sfpr_crash_inj -- deterministic crash injection
//
// Test-build unit of silicaflux_storage_recovery (CRASH_INJ_EN = 1).  Counts a
// selected event and, on the N-th occurrence (+ optional delay), fires one
// action:
//   CRASH     ci_crash_o (level, until reset): the test bench removes the supply
//             without warning -- NAND operation in flight torn, POR asserted
//   PF        one-cycle internal power-fault warning (as if pwr_fail_ni fell)
//   WARM      ci_warm_o (level): the test bench applies a controller reset
//   CRASH_PF  warning pulse and ci_crash_o: the bench decides the hold-up time
// Events: every cycle, slot admission, accepted phase report of a given phase,
// host completion, NAND operation start, firmware crash-point mark (CI_MARK)
// and the power-fault latch.  Firmware marks are how the named crash points of
// the firmware (docs/06_CRASH_INJECTION.md) reach the hardware: firmware writes
// the point id at each point, and the unit fires on the N-th mark of the
// selected id -- fully deterministic for a given workload.
//
// With EN = 0 every output is 0 and the registers read 0 (nothing synthesised
// beyond constant logic).
// Classification: SYNTHESIZABLE (test feature; tie EN = 0 for production)
// =============================================================================
`default_nettype none

module sfpr_crash_inj
  import sfpr_regs_pkg::*;
#(
  parameter bit EN = 1'b1
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // register access (decoded by the parent: 0x100..0x11F)
  input  wire logic        wr,
  input  wire logic [11:0] addr,
  input  wire logic [31:0] wdata,
  output logic [31:0]      rdata,
  // events
  input  wire logic        ev_admit,
  input  wire logic        ev_hostcpl,
  input  wire logic        ev_nand_start,
  input  wire logic        ev_pf,
  input  wire logic        ev_phase_v,
  input  wire logic [2:0]  ev_phase,
  // actions
  output logic             fire_crash,     // level until reset
  output logic             fire_pf,        // one-cycle pulse
  output logic             fire_warm,      // level until reset
  output logic             fired_pulse     // one-cycle pulse when firing (IRQ)
);
  if (EN) begin : g_ci
    logic        armed, fired, pending, crash_q, warm_q, pf_q;
    logic [1:0]  act;
    logic [3:0]  ev;
    logic [7:0]  arg;
    logic [31:0] count, delay, dcnt;
    logic [23:0] seen;
    logic [7:0]  last_mark;
    logic [23:0] marks;

    wire mark_wr = wr && addr == SFPR_CI_MARK;
    logic match;
    always_comb begin
      case (ev)
        4'(SFPR_CIEV_CYCLE):   match = 1'b1;
        4'(SFPR_CIEV_ADMIT):   match = ev_admit;
        4'(SFPR_CIEV_PHASE):   match = ev_phase_v && ev_phase == arg[2:0];
        4'(SFPR_CIEV_HOSTCPL): match = ev_hostcpl;
        4'(SFPR_CIEV_NANDOP):  match = ev_nand_start;
        4'(SFPR_CIEV_MARK):    match = mark_wr && (arg == 8'hFF || wdata[7:0] == arg);
        4'(SFPR_CIEV_PF):      match = ev_pf;
        default:               match = 1'b0;
      endcase
    end
    wire hit_n = armed && !pending && match && (32'(seen) + 32'd1 >= count);
    wire go    = pending && dcnt == 32'd0;

    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        armed <= 1'b0; fired <= 1'b0; pending <= 1'b0; crash_q <= 1'b0; warm_q <= 1'b0; pf_q <= 1'b0;
        act <= '0; ev <= '0; arg <= '0; count <= 32'd1; delay <= '0; dcnt <= '0; seen <= '0;
        last_mark <= '0; marks <= '0;
      end else begin
        pf_q <= 1'b0;
        if (armed && match && !pending) seen <= seen + 24'd1;
        if (hit_n) begin
          pending <= 1'b1;
          dcnt    <= delay;
        end else if (pending && dcnt != 32'd0) begin
          dcnt <= dcnt - 32'd1;
        end
        if (go) begin
          pending <= 1'b0;
          armed   <= 1'b0;
          fired   <= 1'b1;
          if (act == 2'(SFPR_CIACT_CRASH) || act == 2'(SFPR_CIACT_CRASH_PF)) crash_q <= 1'b1;
          if (act == 2'(SFPR_CIACT_PF) || act == 2'(SFPR_CIACT_CRASH_PF))    pf_q <= 1'b1;
          if (act == 2'(SFPR_CIACT_WARM))                                     warm_q <= 1'b1;
        end
        if (mark_wr) begin
          last_mark <= wdata[7:0];
          marks <= marks + 24'd1;
        end
        if (wr) begin
          case (addr)
            SFPR_CI_CTRL: begin
              armed <= wdata[0];
              act   <= wdata[2:1];
              ev    <= wdata[7:4];
              arg   <= wdata[15:8];
              seen  <= '0;
              fired <= 1'b0;
              pending <= 1'b0;
            end
            SFPR_CI_COUNT: count <= (wdata == 32'd0) ? 32'd1 : wdata;
            SFPR_CI_DELAY: delay <= wdata;
            default: ;
          endcase
        end
      end
    end

    always_comb begin
      case (addr)
        SFPR_CI_CTRL:      rdata = {16'h0, arg, ev, 1'b0, act, armed};
        SFPR_CI_COUNT:     rdata = count;
        SFPR_CI_DELAY:     rdata = delay;
        SFPR_CI_STATUS:    rdata = {seen, 6'h0, fired, armed};
        SFPR_CI_LAST_MARK: rdata = {marks, last_mark};
        default:           rdata = 32'h0;
      endcase
    end
    assign fire_crash  = crash_q;
    assign fire_warm   = warm_q;
    assign fire_pf     = pf_q;
    assign fired_pulse = go;
  end else begin : g_no_ci
    assign rdata = 32'h0;
    assign fire_crash = 1'b0;
    assign fire_warm = 1'b0;
    assign fire_pf = 1'b0;
    assign fired_pulse = 1'b0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused = clk ^ rst_n ^ wr ^ ^addr ^ ^wdata ^ ev_admit ^ ev_hostcpl ^ ev_nand_start ^ ev_pf ^
                  ev_phase_v ^ ^ev_phase;
    /* verilator lint_on UNUSEDSIGNAL */
  end
endmodule

`default_nettype wire
