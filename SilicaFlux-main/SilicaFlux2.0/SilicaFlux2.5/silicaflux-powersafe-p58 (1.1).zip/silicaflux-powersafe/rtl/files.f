// SilicaFlux PowerSafe (Project 58) RTL file list (paths relative to the project root)
third_party/silicaflux-storagecore-p51/rtl/generated/sfs_map_pkg.sv
third_party/silicaflux-storagecore-p51/rtl/silicaflux_storage_pkg.sv
third_party/silicaflux-storagecore-p51/rtl/sfs_fifo.sv
rtl/sfpr_regs_pkg.sv
rtl/sfpr_crash_inj.sv
rtl/silicaflux_storage_recovery.sv
