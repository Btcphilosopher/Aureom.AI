// =============================================================================
// SilicaFlux PowerSafe (Project 58) :: silicaflux_storage_recovery
// Power-loss protection and storage recovery controller
// Aureom.AI | SilicaFlux-STORE
//
// A bump-in-the-wire between the host interface and the StorageCore (P51)
// command controller (sfs_cmd_ctrl), on the P51 ready/valid command and
// completion channels (silicaflux_storage_pkg::sfs_cmd_t / sfs_cpl_t), plus a
// firmware register page for the ControlCore.  It provides:
//
//  * Power-fault input: pwr_fail_ni (asynchronous, active low, 2-flop
//    synchroniser in the power-on-reset domain).  A fault is latched at once
//    (no filter: a spurious warning only costs aborted commands); release
//    needs the supply good for PF_RESTORE_CYCLES.
//  * Admission control: commands enter only in READY (READONLY: no WRITE /
//    DEALLOCATE).  Everything else is completed by hardware without reaching
//    firmware: ABORT_PWR_LOSS (power fault), ABORT_RESET / NOT_READY (INIT,
//    RECOVER, SHUTDOWN), INTERNAL_ERR (FAILED), ACCESS_DENIED (READONLY
//    writes), CID_CONFLICT (host TID still outstanding).
//  * Outstanding-operation tracking: one slot per admitted command, kept until
//    the command is complete AND, for an acknowledged-volatile write, durable.
//    The slot index is the transaction ID seen downstream (TID remapping), so
//    firmware reports progress per slot and a host may reuse a TID as soon as
//    it has its completion.  Each slot records the persistence phase
//    ACCEPTED < STARTED < BUFFERED < PROGRAMMED < VERIFIED < MAP_COMMITTED <
//    DURABLE (firmware reports, strictly increasing; regressions refused).
//  * Completion gate (persistent commit status): a SUCCESS completion from the
//    command queue is delivered to the host only when the persistence model
//    allows it (docs/02_PERSISTENCE_MODEL.md):
//      WRITE + FUA, or WRITE without early-ack permission  -> DURABLE
//      WRITE, early ack permitted (WCE, or PLP_PRESENT)     -> BUFFERED (volatile ack)
//      DEALLOCATE                                         -> DURABLE
//      FLUSH -> DURABLE and every write acknowledged-volatile before the FLUSH
//               was admitted is DURABLE (dependency mask); a dependency that
//               failed turns the FLUSH into MEDIA_WRITE
//    A premature SUCCESS is held (pipelining is legal), never delivered early;
//    on a power fault (without PLP) or after GATE_TIMEOUT it is converted to an
//    error.  Error completions pass immediately.
//  * Recovery-mode control: FSM RESET -> INIT -> RECOVER -> READY / READONLY /
//    FAILED, PF_QUIESCE -> PF_SAFE -> (resume) RECOVER or READY, SHUTDOWN ->
//    SHUT_DONE.  Recovery time is measured in hardware.
//  * Power-fault policy WITHOUT physical PLP (PLP_PRESENT = 0, the only
//    qualified configuration): admission closed; commands firmware has not
//    STARTED are aborted by hardware; started commands stop at the next page
//    boundary (firmware); nand_inhibit_o blocks every NEW program / erase;
//    WP# is forced as soon as no NAND operation is in flight; no drain, no
//    checkpoint, no flush is attempted -- nothing assumes hold-up energy.
//  * Diagnostics preserved across controller resets: STK_* registers live in
//    the power-on-reset domain (por_n) and survive rst_n.
//  * Error / status registers, counters, latency and recovery-time telemetry.
//  * Crash injection (CRASH_INJ_EN, test builds): sfpr_crash_inj.
//
// PLP_PRESENT = 1 selects the research drain policy (early acknowledgement
// allowed, firmware destages acknowledged data on hold-up energy).  It must
// not be set without a qualified electrical design: elaboration fails unless
// PLP_QUALIFICATION_ID names the qualification record (docs/08_PLP_MODEL.md).
//
// Resets: por_n = supply applied (everything, including STK_*); rst_n =
// controller reset (everything except STK_* and the power-fail synchroniser).
// Both asynchronous assert, synchronous release (reset synchronisers upstream,
// as in the P51 SoC).  cpl_in_ready is constant 1.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module silicaflux_storage_recovery
  import silicaflux_storage_pkg::*;
  import sfpr_regs_pkg::*;
#(
  parameter int N_SLOTS              = 16,     // 2..32 tracked commands
  parameter int HWQ_DEPTH            = 4,      // hardware completion FIFO
  parameter bit PLP_PRESENT          = 1'b0,   // physical power-loss protection (needs qualification)
  parameter int PLP_QUALIFICATION_ID = 0,      // id of the PLP qualification record; 0 = none
  parameter bit CRASH_INJ_EN         = 1'b0,   // crash-injection unit (test builds)
  localparam int SW = (N_SLOTS > 1) ? $clog2(N_SLOTS) : 1
) (
  input  wire logic        clk,
  input  wire logic        por_n,
  input  wire logic        rst_n,
  input  wire logic        pwr_fail_ni,      // asynchronous, active low (supervisor warning)
  input  wire logic        shn_req_i,        // host shutdown notification (level, synchronous)
  // ---------------------------------------------------------------- host side
  input  wire logic        cmd_in_valid,
  output logic             cmd_in_ready,
  input  wire sfs_cmd_t    cmd_in,
  output logic             cpl_out_valid,
  input  wire logic        cpl_out_ready,
  output sfs_cpl_t         cpl_out,
  // ---------------------------------------------------------------- command-queue side (P51 sfs_cmd_ctrl)
  output logic             cmd_out_valid,
  input  wire logic        cmd_out_ready,
  output sfs_cmd_t         cmd_out,
  input  wire logic        cpl_in_valid,
  output logic             cpl_in_ready,
  input  wire sfs_cpl_t    cpl_in,
  // ---------------------------------------------------------------- firmware page
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  // ---------------------------------------------------------------- media protection
  input  wire logic        nand_busy_i,      // a NAND operation is in flight (any channel)
  output logic             nand_inhibit_o,   // NAND controller must refuse NEW program / erase
  output logic             wp_force_o,       // drive WP# on every channel
  output logic             quiesce_o,        // to sfs_cmd_ctrl.plp_quiesce
  // ---------------------------------------------------------------- status
  output logic             rdy_o,
  output logic             ro_o,
  output logic             fatal_o,
  output logic             pf_active_o,
  output logic [1:0]       shst_o,
  output logic             irq_o,
  // ---------------------------------------------------------------- crash injection (test builds)
  output logic             ci_crash_o,
  output logic             ci_pf_o,
  output logic             ci_warm_o
);
  localparam int N = N_SLOTS;

  // ================================================================ elaboration checks
  if (N_SLOTS < 2 || N_SLOTS > 32) begin : g_bad_nslots
    sfpr_error_n_slots_must_be_2_to_32 u_err ();
  end
  if (PLP_PRESENT && PLP_QUALIFICATION_ID == 0) begin : g_plp_unqualified
    // Physical power-loss protection may only be claimed with a qualified
    // electrical design (energy budget measured on hardware).  See docs/08.
    sfpr_error_plp_present_requires_qualification_id u_err ();
  end

  wire crst_n = rst_n & por_n;   // controller domain

  // ================================================================ power-fail synchroniser (POR domain)
  logic pf_s1, pf_s2;            // 1 = supply good
  always_ff @(posedge clk or negedge por_n) begin
    if (!por_n) begin pf_s1 <= 1'b1; pf_s2 <= 1'b1; end
    else begin pf_s1 <= pwr_fail_ni; pf_s2 <= pf_s1; end
  end
  wire pf_pin = !pf_s2;

  // ================================================================ registers / state (controller domain)
  logic [3:0]  st, pre_pf_st;
  logic        pf_lat, nand_busy_at_pf, busy_q, shn_q, wp_q;
  logic [31:0] now, recov_cnt, pf_cyc, good_cnt;
  logic [31:0] cfg, gate_to, recov_to, pf_restore;
  logic [2:0]  ph_result;
  logic [31:0] err_status, err_info, irq_sticky, irq_en, commit_lo, commit_hi;
  logic [31:0] c_durable, c_admit, c_abort_pf, c_abort_state, c_rej_conflict, c_cpl_host, c_ack_dur, c_ack_vol;
  logic [31:0] c_gate_held, c_gate_conv, c_drop, c_vol_dur, c_vol_fail, lat_sum, lat_max, lat_vol_max;
  logic [31:0] hold_max, recov_last, recov_max, pf_safe_last, c_phase;

  wire cfg_wce     = cfg[SFPR_CFG_WCE];
  wire cfg_hwab    = cfg[SFPR_CFG_HW_ABORT_UNSTARTED];
  wire cfg_autowp  = cfg[SFPR_CFG_AUTO_WP];
  wire cfg_fastres = cfg[SFPR_CFG_FAST_RESUME_EN];

  // ---------------------------------------------------------------- slot table
  logic [N-1:0] s_valid, s_fua, s_early, s_acked, s_vol, s_hwab, s_held, s_dn, s_rel, s_depfail, s_waited;
  logic [2:0]   s_phase [N];
  logic [2:0]   s_cls   [N];
  logic [15:0]  s_tid   [N];
  logic [6:0]   s_st    [N];
  logic [7:0]   s_err   [N];
  logic [31:0]  s_r0    [N];
  logic [31:0]  s_r1    [N];
  logic [31:0]  s_ts    [N];
  logic [31:0]  s_hts   [N];
  logic [N-1:0] s_dep   [N];

  function automatic logic [2:0] cls_of(input logic [7:0] op);
    case (op)
      8'(SFS_OP_READ):       cls_of = SFPR_CLS_READ;
      8'(SFS_OP_WRITE):      cls_of = SFPR_CLS_WRITE;
      8'(SFS_OP_DEALLOCATE): cls_of = SFPR_CLS_TRIM;
      8'(SFS_OP_FLUSH):      cls_of = SFPR_CLS_FLUSH;
      default:               cls_of = SFPR_CLS_OTHER;
    endcase
  endfunction

  // ================================================================ register-bus decode
  wire bus_wr = rb_sel && rb_we;
  wire wr_ctrl   = bus_wr && rb_addr == SFPR_CTRL;
  wire wr_phase  = bus_wr && rb_addr == SFPR_PHASE;
  wire wr_retire = bus_wr && rb_addr == SFPR_RETIRE;
  wire wr_rdone  = bus_wr && rb_addr == SFPR_RECOV_DONE;
  wire c_boot    = wr_ctrl && rb_wdata[SFPR_CTRL_BOOT_ACK];
  wire c_shdone  = wr_ctrl && rb_wdata[SFPR_CTRL_SHUTDOWN_DONE];
  wire c_resume  = wr_ctrl && rb_wdata[SFPR_CTRL_PF_RESUME];
  wire c_retry   = wr_ctrl && rb_wdata[SFPR_CTRL_RECOVER_RETRY];
  wire c_forcepf = wr_ctrl && rb_wdata[SFPR_CTRL_FORCE_PF];
  wire c_clrstk  = wr_ctrl && rb_wdata[SFPR_CTRL_CLR_STICKY];
  wire c_shreq   = wr_ctrl && rb_wdata[SFPR_CTRL_SHUTDOWN_REQ];

  // ================================================================ derived slot status
  logic [N-1:0] m_out, m_active, m_volp;   // host-outstanding, firmware-active, volatile pending
  logic [5:0]   n_used, n_out, n_active, n_vol;
  always_comb begin
    n_used = '0; n_out = '0; n_active = '0; n_vol = '0;
    for (int i = 0; i < N; i++) begin
      m_out[i]    = s_valid[i] && !s_acked[i];
      m_active[i] = s_valid[i] && !s_acked[i] && !s_hwab[i] && !s_held[i];
      m_volp[i]   = s_valid[i] && s_acked[i] && s_vol[i] && s_phase[i] != SFPR_PH_DURABLE;
      n_used   = n_used + 6'(s_valid[i]);
      n_out    = n_out + 6'(m_out[i]);
      n_active = n_active + 6'(m_active[i]);
      n_vol    = n_vol + 6'(m_volp[i]);
    end
  end

  // ================================================================ admission
  logic          have_free;
  logic [SW-1:0] free_slot;
  always_comb begin
    have_free = 1'b0;
    free_slot = '0;
    for (int i = N - 1; i >= 0; i--) if (!s_valid[i]) begin have_free = 1'b1; free_slot = SW'(i); end
  end

  logic        fwd_v;
  sfs_cmd_t    fwd_cmd;
  wire         fwd_free = !fwd_v || cmd_out_ready;
  assign cmd_out_valid = fwd_v;
  assign cmd_out       = fwd_cmd;
  sfs_cmd_t    fwd_next;               // command as forwarded: TID = slot index
  always_comb begin
    fwd_next     = cmd_in;
    fwd_next.tid = 16'(free_slot);
  end

  logic        conflict;
  always_comb begin
    conflict = 1'b0;
    for (int i = 0; i < N; i++) if (m_out[i] && s_tid[i] == cmd_in.tid) conflict = 1'b1;
  end

  wire [2:0] in_cls = cls_of(cmd_in.opcode);
  logic       adm_rej;
  logic [6:0] rej_st;
  logic [7:0] rej_err;
  logic [1:0] rej_kind;          // 0 power fault, 1 state, 2 conflict
  always_comb begin
    adm_rej = 1'b1; rej_st = 7'(SFS_ST_ABORT_RESET); rej_err = 8'(SFS_ERR_NOT_READY); rej_kind = 2'd1;
    if (pf_lat) begin
      rej_st = 7'(SFS_ST_ABORT_PWR_LOSS); rej_err = 8'(SFS_ERR_QUIESCED); rej_kind = 2'd0;
    end else if (st == 4'(SFPR_STATE_FAILED)) begin
      rej_st = 7'(SFS_ST_INTERNAL_ERR); rej_err = 8'(SFS_ERR_NOT_READY);
    end else if (st == 4'(SFPR_STATE_READY) || st == 4'(SFPR_STATE_READONLY)) begin
      if (st == 4'(SFPR_STATE_READONLY) && (in_cls == SFPR_CLS_WRITE || in_cls == SFPR_CLS_TRIM)) begin
        rej_st = 7'(SFS_ST_ACCESS_DENIED); rej_err = 8'(SFS_ERR_NAND_WP);
      end else if (conflict) begin
        rej_st = 7'(SFS_ST_CID_CONFLICT); rej_err = 8'(SFS_ERR_NONE); rej_kind = 2'd2;
      end else begin
        adm_rej = 1'b0;
      end
    end
  end

  logic hwq_in_ready, hwq_out_valid, hwq_pop;
  logic [30:0] hwq_head;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [$clog2(HWQ_DEPTH + 1)-1:0] hwq_level;
  /* verilator lint_on UNUSEDSIGNAL */

  assign cmd_in_ready = adm_rej ? hwq_in_ready : (have_free && fwd_free);
  wire adm_hs = cmd_in_valid && cmd_in_ready;
  wire alloc  = adm_hs && !adm_rej;
  wire hwrej  = adm_hs && adm_rej;

  sfs_fifo #(.W(31), .DEPTH(HWQ_DEPTH)) u_hwq (
    .clk, .rst_n(crst_n), .clr(1'b0),
    .in_valid(hwrej), .in_ready(hwq_in_ready), .in_data({cmd_in.tid, rej_st, rej_err}),
    .out_valid(hwq_out_valid), .out_ready(hwq_pop), .out_data(hwq_head), .level(hwq_level)
  );

  // ================================================================ completions from the command queue
  assign cpl_in_ready = 1'b1;
  wire [SW-1:0] ci_slot   = cpl_in.tid[SW-1:0];
  wire          ci_inr    = cpl_in.tid < 16'(N);
  wire          ci_known  = cpl_in_valid && ci_inr && s_valid[ci_slot];
  wire          ci_drop   = ci_known && s_hwab[ci_slot] && !s_dn[ci_slot];
  wire          ci_dup    = ci_known && !ci_drop && s_dn[ci_slot];
  wire          ci_store  = ci_known && !ci_drop && !s_dn[ci_slot];
  wire          ci_unk    = cpl_in_valid && !ci_known;

  // ================================================================ phase reports / retire
  wire [7:0]    ph_slot8 = rb_wdata[7:0];
  wire [SW-1:0] ph_slot  = rb_wdata[SW-1:0];
  wire [2:0]    ph_val   = rb_wdata[10:8];
  wire          ph_inr   = ph_slot8 < 8'(N);
  logic [2:0]   ph_res;
  always_comb begin
    if (!ph_inr || !s_valid[ph_slot])                     ph_res = SFPR_PR_BAD_SLOT;
    else if (s_hwab[ph_slot])                             ph_res = SFPR_PR_ABORTED;
    else if (ph_val <= SFPR_PH_ACCEPTED)                  ph_res = SFPR_PR_REGRESS;
    else if (pf_lat && s_phase[ph_slot] == SFPR_PH_ACCEPTED) ph_res = SFPR_PR_QUIESCED;
    else if (ph_val < s_phase[ph_slot])                   ph_res = SFPR_PR_REGRESS;
    else                                                  ph_res = SFPR_PR_OK;
  end
  wire ph_ok = wr_phase && ph_res == SFPR_PR_OK;

  wire [SW-1:0] rt_slot = rb_wdata[SW-1:0];
  wire          rt_ok   = wr_retire && rb_wdata[7:0] < 8'(N) && m_volp[rt_slot];

  // ================================================================ gate: eligibility, conversion, selection
  wire pf_block_vol = pf_lat && !PLP_PRESENT;
  logic [N-1:0] elig, waiting, conv_pf, conv_to;
  logic [N-1:0] g_succ, g_isw, g_need, g_dur, g_vol, g_dep, g_ok;   // per-slot gate terms
  always_comb begin
    for (int i = 0; i < N; i++) begin
      g_succ[i]  = s_st[i] == 7'(SFS_ST_SUCCESS);
      g_isw[i]   = s_cls[i] == SFPR_CLS_WRITE;
      g_need[i]  = (g_isw[i] && (s_fua[i] || !s_early[i])) || s_cls[i] == SFPR_CLS_TRIM || s_cls[i] == SFPR_CLS_FLUSH;
      g_dur[i]   = s_phase[i] == SFPR_PH_DURABLE;
      g_vol[i]   = g_isw[i] && s_early[i] && !s_fua[i] && s_phase[i] >= SFPR_PH_BUFFERED && !pf_block_vol;
      g_dep[i]   = s_cls[i] != SFPR_CLS_FLUSH || s_dep[i] == '0;
      g_ok[i]    = (g_need[i] ? g_dur[i] : (g_isw[i] ? (g_dur[i] || g_vol[i]) : 1'b1)) && g_dep[i];
      elig[i]    = s_valid[i] && s_held[i] && !s_rel[i] && !s_acked[i] && (!g_succ[i] || g_ok[i]);
      waiting[i] = s_valid[i] && s_held[i] && !s_rel[i] && !s_acked[i] && g_succ[i] && !g_ok[i];
      conv_pf[i] = waiting[i] && pf_block_vol;
      conv_to[i] = waiting[i] && !pf_block_vol && gate_to != 32'd0 && (now - s_hts[i]) >= gate_to;
    end
  end

  logic [SW-1:0] rr, sel;
  logic          sel_v;
  // round robin: the first eligible slot at or after rr
  logic [2*N-1:0] elig2;
  always_comb begin
    elig2 = {elig, elig};
    sel_v = 1'b0;
    sel   = '0;
    for (int k = N - 1; k >= 0; k--)
      if (elig2[32'(rr) + k]) begin
        sel_v = 1'b1;
        sel   = (32'(rr) + k >= N) ? SW'(32'(rr) + k - N) : SW'(32'(rr) + k);
      end
  end

  // ================================================================ host completion output register
  logic          ov, o_from_slot, prio_hwq;
  sfs_cpl_t      opl;
  logic [SW-1:0] o_slot;
  wire o_load    = !ov || cpl_out_ready;
  wire take_hwq  = hwq_out_valid && (!sel_v || prio_hwq);
  wire take_slot = sel_v && !take_hwq;
  wire do_load   = o_load && (hwq_out_valid || sel_v);
  assign hwq_pop = do_load && take_hwq;
  wire load_slot = do_load && take_slot;
  wire o_hs      = ov && cpl_out_ready;
  wire fin       = o_hs && o_from_slot;          // finalize slot o_slot this cycle
  assign cpl_out_valid = ov;
  assign cpl_out       = opl;

  // next host completion: hardware rejection or a slot's held completion
  sfs_cpl_t opl_next;
  wire flush_fail = s_cls[sel] == SFPR_CLS_FLUSH && s_depfail[sel] && s_st[sel] == 7'(SFS_ST_SUCCESS);
  always_comb begin
    if (take_hwq) begin
      opl_next.tid     = hwq_head[30:15];
      opl_next.status  = hwq_head[14:8];
      opl_next.err     = hwq_head[7:0];
      opl_next.result0 = '0;
      opl_next.result1 = '0;
    end else begin
      opl_next.tid     = s_tid[sel];
      opl_next.status  = flush_fail ? 7'(SFS_ST_MEDIA_WRITE) : s_st[sel];
      opl_next.err     = flush_fail ? 8'(SFS_ERR_FW) : s_err[sel];
      opl_next.result0 = s_r0[sel];
      opl_next.result1 = s_r1[sel];
    end
  end

  wire        fin_succ = opl.status == 7'(SFS_ST_SUCCESS);
  wire        fin_w    = s_cls[o_slot] == SFPR_CLS_WRITE;
  wire        fin_dur  = s_phase[o_slot] == SFPR_PH_DURABLE;
  wire        fin_vol  = fin && fin_succ && fin_w && !fin_dur;
  wire        fin_dack = fin && fin_succ && fin_dur &&
                         (fin_w || s_cls[o_slot] == SFPR_CLS_TRIM || s_cls[o_slot] == SFPR_CLS_FLUSH);
  wire [31:0] fin_lat  = now - s_ts[o_slot];

  // ================================================================ slot release (free) rules
  logic [N-1:0] free_now, vol_dur_now, retire_mask, fin_vol_mask;
  always_comb begin
    for (int i = 0; i < N; i++) begin
      vol_dur_now[i] = s_valid[i] && s_acked[i] && s_vol[i] && s_phase[i] == SFPR_PH_DURABLE;
      retire_mask[i] = rt_ok && rt_slot == SW'(i);
      fin_vol_mask[i] = fin_vol && o_slot == SW'(i);
      free_now[i]    = (s_valid[i] && s_acked[i] && (!s_vol[i] || s_phase[i] == SFPR_PH_DURABLE) &&
                        (!s_hwab[i] || s_dn[i])) || retire_mask[i];
    end
  end

  // PF sweep: abort commands firmware has not started
  logic [N-1:0] sweep;
  always_comb
    for (int i = 0; i < N; i++)
      sweep[i] = pf_lat && cfg_hwab && s_valid[i] && s_phase[i] == SFPR_PH_ACCEPTED && !s_held[i] && !s_dn[i] &&
                 !s_hwab[i];

  function automatic logic [5:0] popc(input logic [N-1:0] v);
    popc = '0;
    for (int i = 0; i < N; i++) popc = popc + 6'(v[i]);
  endfunction
  wire [5:0] n_sweep   = popc(sweep);
  wire [5:0] n_conv    = popc(conv_pf | conv_to);
  wire [5:0] n_voldur  = popc(vol_dur_now & free_now);

  // ================================================================ FSM support
  wire pf_set    = !pf_lat && (pf_pin || ci_pf_o || c_forcepf);
  wire pf_rest   = pf_lat && good_cnt >= pf_restore;
  wire is_pf_st  = st == 4'(SFPR_STATE_PF_QUIESCE) || st == 4'(SFPR_STATE_PF_SAFE);
  wire fast_ok   = cfg_fastres && !nand_busy_at_pf &&
                   (pre_pf_st == 4'(SFPR_STATE_READY) || pre_pf_st == 4'(SFPR_STATE_READONLY));
  wire safe_cond = n_active == 6'd0 && !nand_busy_i && (!PLP_PRESENT || n_vol == 6'd0);
  wire shn_rise  = shn_req_i && !shn_q;
  wire nand_start = nand_busy_i && !busy_q;

  // state-machine events (same cycle as the transition; also used by the POR-domain diagnostics)
  wire go_safe        = !pf_set && st == 4'(SFPR_STATE_PF_QUIESCE) && safe_cond;
  wire go_resume      = !pf_set && st == 4'(SFPR_STATE_PF_SAFE) && c_resume && pf_rest;
  wire go_resume_full = go_resume && !fast_ok;
  wire go_retry       = !pf_set && st == 4'(SFPR_STATE_FAILED) && c_retry;
  wire go_rdone       = !pf_set && st == 4'(SFPR_STATE_RECOVER) && wr_rdone;

  // error recording
  logic [31:0] err_set;
  logic [7:0]  err_slot;
  always_comb begin
    err_set = '0;
    err_slot = 8'h0;
    if (wr_phase && ph_res == SFPR_PR_BAD_SLOT) begin err_set[SFPR_ERR_PHASE_BAD_SLOT] = 1'b1; err_slot = ph_slot8; end
    if (wr_phase && ph_res == SFPR_PR_REGRESS)  begin err_set[SFPR_ERR_PHASE_REGRESS]  = 1'b1; err_slot = ph_slot8; end
    if (ci_unk)  begin err_set[SFPR_ERR_CPL_UNKNOWN] = 1'b1; err_slot = cpl_in.tid[7:0]; end
    if (ci_dup)  begin err_set[SFPR_ERR_CPL_DUP]     = 1'b1; err_slot = cpl_in.tid[7:0]; end
    if (|conv_to) err_set[SFPR_ERR_GATE_TIMEOUT] = 1'b1;
    if (st == 4'(SFPR_STATE_RECOVER) && recov_to != 32'd0 && recov_cnt >= recov_to) err_set[SFPR_ERR_RECOV_TIMEOUT] = 1'b1;
    if (wr_retire && !rt_ok) begin err_set[SFPR_ERR_RETIRE_BAD] = 1'b1; err_slot = rb_wdata[7:0]; end
    if (rt_ok)   begin err_set[SFPR_ERR_VOL_FAIL] = 1'b1; err_slot = rb_wdata[7:0]; end
    if ((c_boot && st != 4'(SFPR_STATE_INIT)) || (c_shdone && (st != 4'(SFPR_STATE_SHUTDOWN) || n_used != 6'd0)) ||
        (c_resume && !(st == 4'(SFPR_STATE_PF_SAFE) && pf_rest)) || (c_retry && st != 4'(SFPR_STATE_FAILED)) ||
        (wr_rdone && st != 4'(SFPR_STATE_RECOVER)))
      err_set[SFPR_ERR_SEQ] = 1'b1;
    if (pf_set && (st == 4'(SFPR_STATE_INIT) || st == 4'(SFPR_STATE_RECOVER) || st == 4'(SFPR_STATE_SHUTDOWN) ||
                   st == 4'(SFPR_STATE_RESET)))
      err_set[SFPR_ERR_PF_IN_RECOVERY] = 1'b1;
  end
  logic [7:0] err_idx;
  always_comb begin
    err_idx = 8'h0;
    for (int b = 31; b >= 0; b--) if (err_set[b]) err_idx = 8'(b);
  end

  function automatic logic [31:0] sat_add(input logic [31:0] a, input logic [31:0] b);
    logic [32:0] s;
    s = {1'b0, a} + {1'b0, b};
    sat_add = s[32] ? 32'hFFFF_FFFF : s[31:0];
  endfunction
  function automatic logic [31:0] max32(input logic [31:0] a, input logic [31:0] b);
    max32 = (b > a) ? b : a;
  endfunction

  // crash-injection unit
  logic [31:0] ci_rdata;
  logic        ci_fired;
  wire         ci_rng = rb_addr >= SFPR_CI_CTRL && rb_addr <= SFPR_CI_LAST_MARK;
  sfpr_crash_inj #(.EN(CRASH_INJ_EN)) u_ci (
    .clk, .rst_n(crst_n),
    .wr(bus_wr && ci_rng), .addr(rb_addr), .wdata(rb_wdata), .rdata(ci_rdata),
    .ev_admit(alloc), .ev_hostcpl(cpl_out_valid && cpl_out_ready), .ev_nand_start(nand_start), .ev_pf(pf_set),
    .ev_phase_v(ph_ok), .ev_phase(ph_val),
    .fire_crash(ci_crash_o), .fire_pf(ci_pf_o), .fire_warm(ci_warm_o), .fired_pulse(ci_fired)
  );

  // ================================================================ sequential: control, FSM, counters
  always_ff @(posedge clk or negedge crst_n) begin
    if (!crst_n) begin
      st <= 4'(SFPR_STATE_RESET); pre_pf_st <= 4'(SFPR_STATE_INIT);
      pf_lat <= 1'b0; nand_busy_at_pf <= 1'b0; busy_q <= 1'b0; shn_q <= 1'b0; wp_q <= 1'b0;
      now <= '0; recov_cnt <= '0; pf_cyc <= '0; good_cnt <= '0;
      cfg <= SFPR_CFG_RST; gate_to <= SFPR_GATE_TIMEOUT_RST; recov_to <= SFPR_RECOV_TIMEOUT_RST;
      pf_restore <= SFPR_PF_RESTORE_CYCLES_RST;
      ph_result <= '0; err_status <= '0; err_info <= '0; irq_sticky <= '0; irq_en <= '0;
      commit_lo <= '0; commit_hi <= '0;
      c_durable <= '0; c_admit <= '0; c_abort_pf <= '0; c_abort_state <= '0; c_rej_conflict <= '0;
      c_cpl_host <= '0; c_ack_dur <= '0; c_ack_vol <= '0; c_gate_held <= '0; c_gate_conv <= '0; c_drop <= '0;
      c_vol_dur <= '0; c_vol_fail <= '0; lat_sum <= '0; lat_max <= '0; lat_vol_max <= '0; hold_max <= '0;
      recov_last <= '0; recov_max <= '0; pf_safe_last <= '0; c_phase <= '0;
      fwd_v <= 1'b0; fwd_cmd <= '0;
      ov <= 1'b0; o_from_slot <= 1'b0; prio_hwq <= 1'b0; opl <= '0; o_slot <= '0; rr <= '0;
    end else begin
      now     <= now + 32'd1;
      busy_q  <= nand_busy_i;
      shn_q   <= shn_req_i;
      good_cnt <= pf_pin ? 32'd0 : ((good_cnt == 32'hFFFF_FFFF) ? good_cnt : good_cnt + 32'd1);

      // ------------------------------------------------ forward register (to the command queue)
      if (fwd_v && cmd_out_ready) fwd_v <= 1'b0;
      if (alloc) begin
        fwd_v   <= 1'b1;
        fwd_cmd <= fwd_next;
      end

      // ------------------------------------------------ host completion output
      if (o_hs) ov <= 1'b0;
      if (do_load) begin
        ov <= 1'b1;
        prio_hwq <= !take_hwq;
        opl <= opl_next;
        if (take_hwq) begin
          o_from_slot  <= 1'b0;
        end else begin
          o_from_slot  <= 1'b1;
          o_slot       <= sel;
          rr           <= (sel == SW'(N - 1)) ? '0 : sel + SW'(1);
          if (s_waited[sel]) begin
            c_gate_held <= c_gate_held + 32'd1;
            hold_max    <= max32(hold_max, now - s_hts[sel]);
          end
        end
      end

      // ------------------------------------------------ counters
      if (alloc) c_admit <= c_admit + 32'd1;
      if (hwrej) begin
        if (rej_kind == 2'd0) c_abort_pf <= c_abort_pf + 32'd1 + 32'(n_sweep);
        else if (rej_kind == 2'd1) c_abort_state <= c_abort_state + 32'd1;
        else c_rej_conflict <= c_rej_conflict + 32'd1;
      end
      if (!(hwrej && rej_kind == 2'd0) && n_sweep != 6'd0) c_abort_pf <= c_abort_pf + 32'(n_sweep);
      if (o_hs) c_cpl_host <= c_cpl_host + 32'd1;
      if (fin_dack) begin
        c_ack_dur <= c_ack_dur + 32'd1;
        lat_sum   <= sat_add(lat_sum, fin_lat);
        lat_max   <= max32(lat_max, fin_lat);
      end
      if (fin_vol) begin
        c_ack_vol   <= c_ack_vol + 32'd1;
        lat_vol_max <= max32(lat_vol_max, fin_lat);
      end
      if (n_conv != 6'd0) c_gate_conv <= c_gate_conv + 32'(n_conv);
      if (ci_drop) c_drop <= c_drop + 32'd1;
      if (n_voldur != 6'd0) c_vol_dur <= c_vol_dur + 32'(n_voldur);
      if (rt_ok) c_vol_fail <= c_vol_fail + 32'd1;
      if (ph_ok) begin
        c_phase <= c_phase + 32'd1;
        if (ph_val == SFPR_PH_DURABLE && s_phase[ph_slot] != SFPR_PH_DURABLE) c_durable <= c_durable + 32'd1;
      end
      if (wr_phase) ph_result <= ph_res;

      // ------------------------------------------------ errors / irq
      if (err_set != '0) begin
        if (err_status == '0) err_info <= {12'h0, st, err_slot, err_idx};
        err_status <= err_status | err_set;
      end
      if (bus_wr && rb_addr == SFPR_ERR_STATUS) err_status <= (err_status & ~rb_wdata) | err_set;
      if (pf_set) irq_sticky[SFPR_IRQ_PF_EVENT] <= 1'b1;
      if (pf_set && n_vol != 6'd0) irq_sticky[SFPR_IRQ_VOL_LOST] <= 1'b1;
      if (ci_fired) irq_sticky[SFPR_IRQ_CI_FIRED] <= 1'b1;
      if (bus_wr && rb_addr == SFPR_IRQ_STATUS) irq_sticky <= irq_sticky & ~rb_wdata;

      // ------------------------------------------------ configuration registers
      if (bus_wr) begin
        case (rb_addr)
          SFPR_CFG:               cfg <= rb_wdata & 32'hF;
          SFPR_GATE_TIMEOUT:      gate_to <= rb_wdata;
          SFPR_RECOV_TIMEOUT:     recov_to <= rb_wdata;
          SFPR_PF_RESTORE_CYCLES: pf_restore <= rb_wdata;
          SFPR_IRQ_EN:            irq_en <= rb_wdata;
          SFPR_COMMIT_SEQ_LO:     commit_lo <= rb_wdata;
          SFPR_COMMIT_SEQ_HI:     commit_hi <= {16'h0, rb_wdata[15:0]};
          default: ;
        endcase
      end

      // ------------------------------------------------ media protection
      if (nand_inhibit_o) begin
        if (!nand_busy_i && (cfg_autowp || st == 4'(SFPR_STATE_SHUT_DONE) || PLP_PRESENT)) wp_q <= 1'b1;
      end else begin
        wp_q <= 1'b0;
      end

      // ------------------------------------------------ FSM
      if (st == 4'(SFPR_STATE_RECOVER)) recov_cnt <= recov_cnt + 32'd1;
      if (is_pf_st) pf_cyc <= pf_cyc + 32'd1;
      if (pf_set) begin
        pf_lat <= 1'b1;
        pf_cyc <= 32'd0;
        if (!is_pf_st) begin
          pre_pf_st       <= (st == 4'(SFPR_STATE_RESET)) ? 4'(SFPR_STATE_INIT) : st;
          nand_busy_at_pf <= nand_busy_i;
          st              <= 4'(SFPR_STATE_PF_QUIESCE);
        end
      end else begin
        case (st)
          4'(SFPR_STATE_RESET): st <= 4'(SFPR_STATE_INIT);
          4'(SFPR_STATE_INIT):
            if (c_boot) begin st <= 4'(SFPR_STATE_RECOVER); recov_cnt <= '0; end
          4'(SFPR_STATE_RECOVER): begin
            if (wr_rdone) begin
              recov_last   <= recov_cnt;
              recov_max    <= max32(recov_max, recov_cnt);
              case (rb_wdata[1:0])
                2'(SFPR_RD_OK):       st <= 4'(SFPR_STATE_READY);
                2'(SFPR_RD_READONLY): st <= 4'(SFPR_STATE_READONLY);
                default:              st <= 4'(SFPR_STATE_FAILED);
              endcase
            end else if (recov_to != 32'd0 && recov_cnt >= recov_to) begin
              st <= 4'(SFPR_STATE_FAILED);
            end
          end
          4'(SFPR_STATE_READY), 4'(SFPR_STATE_READONLY):
            if (shn_rise || c_shreq) st <= 4'(SFPR_STATE_SHUTDOWN);
          4'(SFPR_STATE_SHUTDOWN):
            if (c_shdone && n_used == 6'd0) st <= 4'(SFPR_STATE_SHUT_DONE);
          4'(SFPR_STATE_FAILED):
            if (c_retry) begin st <= 4'(SFPR_STATE_RECOVER); recov_cnt <= '0; end
          4'(SFPR_STATE_PF_QUIESCE):
            if (safe_cond) begin
              st           <= 4'(SFPR_STATE_PF_SAFE);
              pf_safe_last <= pf_cyc;
            end
          4'(SFPR_STATE_PF_SAFE):
            if (c_resume && pf_rest) begin
              pf_lat <= 1'b0;
              if (fast_ok) st <= pre_pf_st;
              else begin st <= 4'(SFPR_STATE_RECOVER); recov_cnt <= '0; end
            end
          default: ;   // SHUT_DONE: until reset
        endcase
      end
    end
  end

  // ================================================================ sequential: slot table
  always_ff @(posedge clk or negedge crst_n) begin
    if (!crst_n) begin
      s_valid <= '0; s_fua <= '0; s_early <= '0; s_acked <= '0; s_vol <= '0; s_hwab <= '0; s_held <= '0;
      s_dn <= '0; s_rel <= '0; s_depfail <= '0; s_waited <= '0;
      for (int i = 0; i < N; i++) begin
        s_phase[i] <= '0; s_cls[i] <= '0; s_tid[i] <= '0; s_st[i] <= '0; s_err[i] <= '0;
        s_r0[i] <= '0; s_r1[i] <= '0; s_ts[i] <= '0; s_hts[i] <= '0; s_dep[i] <= '0;
      end
    end else begin
      for (int i = 0; i < N; i++) begin
        // dependency bookkeeping (FLUSH): a dependency is satisfied when it is freed
        s_dep[i] <= s_dep[i] & ~free_now;
        if ((s_dep[i] & retire_mask) != '0) s_depfail[i] <= 1'b1;
        if (waiting[i]) s_waited[i] <= 1'b1;

        if (free_now[i]) begin
          s_valid[i] <= 1'b0;
          s_phase[i] <= SFPR_PH_FREE;
          s_acked[i] <= 1'b0; s_vol[i] <= 1'b0; s_hwab[i] <= 1'b0; s_held[i] <= 1'b0; s_dn[i] <= 1'b0;
          s_rel[i] <= 1'b0; s_depfail[i] <= 1'b0; s_waited[i] <= 1'b0; s_dep[i] <= '0;
        end else begin
          // allocation
          if (alloc && free_slot == SW'(i)) begin
            s_valid[i] <= 1'b1;
            s_phase[i] <= SFPR_PH_ACCEPTED;
            s_cls[i]   <= in_cls;
            s_fua[i]   <= cmd_in.flags[SFS_FLAG_FUA];
            s_early[i] <= cfg_wce || PLP_PRESENT;
            s_tid[i]   <= cmd_in.tid;
            s_ts[i]    <= now;
            s_acked[i] <= 1'b0; s_vol[i] <= 1'b0; s_hwab[i] <= 1'b0; s_held[i] <= 1'b0; s_dn[i] <= 1'b0;
            s_rel[i] <= 1'b0; s_depfail[i] <= 1'b0; s_waited[i] <= 1'b0;
            // FLUSH: depends on every write acknowledged-volatile so far (incl. one finalised now)
            s_dep[i]   <= (in_cls == SFPR_CLS_FLUSH) ? ((m_volp | fin_vol_mask) & ~free_now) : '0;
          end
          // phase report
          if (ph_ok && ph_slot == SW'(i) && ph_val > s_phase[i]) s_phase[i] <= ph_val;
          // completion from the command queue
          if (ci_store && ci_slot == SW'(i)) begin
            s_held[i] <= 1'b1;
            s_dn[i]   <= 1'b1;
            s_st[i]   <= cpl_in.status;
            s_err[i]  <= cpl_in.err;
            s_r0[i]   <= cpl_in.result0;
            s_r1[i]   <= cpl_in.result1;
            s_hts[i]  <= now;
          end
          if (ci_drop && ci_slot == SW'(i)) s_dn[i] <= 1'b1;
          // power-fault sweep: hardware aborts a command firmware has not started
          if (sweep[i]) begin
            s_hwab[i] <= 1'b1;
            s_held[i] <= 1'b1;
            s_st[i]   <= 7'(SFS_ST_ABORT_PWR_LOSS);
            s_err[i]  <= 8'(SFS_ERR_QUIESCED);
            s_r0[i]   <= '0;
            s_r1[i]   <= '0;
            s_hts[i]  <= now;
          end
          // gate conversion of a SUCCESS that may no longer be delivered
          if (conv_pf[i]) begin
            s_st[i]  <= 7'(SFS_ST_ABORT_PWR_LOSS);
            s_err[i] <= 8'(SFS_ERR_QUIESCED);
          end else if (conv_to[i]) begin
            s_st[i]  <= 7'(SFS_ST_INTERNAL_ERR);
            s_err[i] <= 8'(SFS_ERR_FW);
          end
          // loaded into the host output register
          if (load_slot && sel == SW'(i)) s_rel[i] <= 1'b1;
          // delivered to the host
          if (fin && o_slot == SW'(i)) begin
            s_acked[i] <= 1'b1;
            s_rel[i]   <= 1'b0;
            s_vol[i]   <= fin_vol;
          end
        end
      end
    end
  end

  // ================================================================ POR domain: sticky diagnostics
  logic [31:0] k_flags, k_pf_count, k_warm_count, k_cause, k_snap0, k_snap1, k_pf_ts, k_safe_cyc, k_pf_seq;
  logic [31:0] k_vol_lost, k_rst_snap, k_recov, k_ts;
  logic        k_alive;
  logic [3:0]  k_st_q;
  logic [4:0]  sh_out, sh_vol;
  logic [3:0]  sh_st;
  function automatic logic [4:0] sat5(input logic [5:0] v);
    sat5 = (v > 6'd31) ? 5'd31 : v[4:0];
  endfunction
  wire wake = k_st_q == 4'(SFPR_STATE_RESET) && st == 4'(SFPR_STATE_INIT);
  always_ff @(posedge clk or negedge por_n) begin
    if (!por_n) begin
      k_flags <= '0; k_pf_count <= '0; k_warm_count <= '0; k_cause <= '0; k_snap0 <= '0; k_snap1 <= '0;
      k_pf_ts <= '0; k_safe_cyc <= '0; k_pf_seq <= '0; k_vol_lost <= '0; k_rst_snap <= '0; k_recov <= '0;
      k_ts <= '0; k_alive <= 1'b0; k_st_q <= 4'(SFPR_STATE_RESET);
      sh_out <= '0; sh_vol <= '0; sh_st <= '0;
    end else begin
      k_ts   <= k_ts + 32'd1;
      k_st_q <= st;
      // shadows of the controller domain: frozen while it is held in reset
      if (st != 4'(SFPR_STATE_RESET)) begin
        sh_st <= st; sh_out <= sat5(n_out); sh_vol <= sat5(n_vol);
      end
      if (wake) begin
        k_alive <= 1'b1;
        if (k_alive) begin                          // controller reset with supply present
          k_warm_count <= k_warm_count + 32'd1;
          k_flags[1]   <= 1'b1;
          k_cause      <= 32'(SFPR_CAUSE_WARM);
          k_rst_snap   <= {1'b1, 2'b0, sh_vol, 11'h0, sh_out, 4'h0, sh_st};
          k_vol_lost   <= k_vol_lost + 32'(sh_vol);
        end else begin
          k_cause      <= 32'(SFPR_CAUSE_POR);
        end
      end
      if (go_resume_full) k_cause <= 32'(SFPR_CAUSE_PF_RESUME);
      if (go_retry)       k_cause <= 32'(SFPR_CAUSE_RETRY);
      if (pf_set) begin
        k_flags[0] <= 1'b1;
        k_pf_count <= k_pf_count + 32'd1;
        k_snap0    <= {1'b1, 2'b0, sat5(n_vol), 3'b0, sat5(n_active), 3'b0, sat5(n_out), 4'h0,
                       (st == 4'(SFPR_STATE_RESET)) ? 4'(SFPR_STATE_INIT) : st};
        k_snap1    <= {31'h0, nand_busy_i};
        k_pf_ts    <= k_ts;
        k_safe_cyc <= '0;
        k_pf_seq   <= commit_lo;
        k_vol_lost <= k_vol_lost + 32'(sat5(n_vol));
      end else if (pf_lat) begin
        if (n_sweep != 6'd0) k_snap1[23:16] <= k_snap1[23:16] + 8'(n_sweep);
        if (n_conv != 6'd0)  k_snap1[15:8]  <= k_snap1[15:8] + 8'(n_conv);
        if (go_safe) begin
          k_snap1[1] <= 1'b1;
          k_safe_cyc <= pf_cyc;
        end
      end
      if (go_rdone) begin
        k_flags[2] <= 1'b1;
        k_recov    <= {recov_cnt[28:0], 1'b1, rb_wdata[1:0]};
      end
      if (c_clrstk) begin
        k_pf_count <= '0; k_warm_count <= '0; k_vol_lost <= '0; k_flags <= '0;
      end
    end
  end

  // ================================================================ outputs
  assign nand_inhibit_o = (!PLP_PRESENT && pf_lat) || (PLP_PRESENT && st == 4'(SFPR_STATE_PF_SAFE)) ||
                          st == 4'(SFPR_STATE_SHUT_DONE);
  assign wp_force_o  = wp_q;
  assign quiesce_o   = pf_lat;
  assign rdy_o       = st == 4'(SFPR_STATE_READY) || st == 4'(SFPR_STATE_READONLY);
  assign ro_o        = st == 4'(SFPR_STATE_READONLY);
  assign fatal_o     = st == 4'(SFPR_STATE_FAILED);
  assign pf_active_o = is_pf_st;
  assign shst_o      = (st == 4'(SFPR_STATE_SHUTDOWN)) ? 2'd1 : (st == 4'(SFPR_STATE_SHUT_DONE)) ? 2'd2 : 2'd0;

  logic [31:0] irq_status;
  always_comb begin
    irq_status = irq_sticky;
    irq_status[SFPR_IRQ_PF_SAFE]     = st == 4'(SFPR_STATE_PF_SAFE);
    irq_status[SFPR_IRQ_PF_RESTORED] = st == 4'(SFPR_STATE_PF_SAFE) && pf_rest;
    irq_status[SFPR_IRQ_ERR]         = err_status != '0;
    irq_status[SFPR_IRQ_CMD_STATE]   = st == 4'(SFPR_STATE_INIT) || st == 4'(SFPR_STATE_SHUTDOWN) ||
                                       (st == 4'(SFPR_STATE_PF_SAFE) && pf_rest);
  end
  assign irq_o = (irq_status & irq_en) != '0;

  // ================================================================ register read
  wire in_slotwin = rb_addr >= SFPR_SLOT_WIN && rb_addr < SFPR_SLOT_WIN + 12'(N * SFPR_SLOT_STRIDE);
  wire [SW-1:0] win_slot = rb_addr[2 +: SW];
  logic [31:0] slot_word;
  always_comb begin
    slot_word = '0;
    slot_word[SFPR_SLOT_PHASE_LSB +: 3]    = s_phase[win_slot];
    slot_word[SFPR_SLOT_VALID_LSB]         = s_valid[win_slot];
    slot_word[SFPR_SLOT_CLS_LSB +: 3]      = s_cls[win_slot];
    slot_word[SFPR_SLOT_FUA_LSB]           = s_fua[win_slot];
    slot_word[SFPR_SLOT_EARLY_OK_LSB]      = s_early[win_slot];
    slot_word[SFPR_SLOT_ACKED_LSB]         = s_acked[win_slot];
    slot_word[SFPR_SLOT_VOL_LSB]           = s_vol[win_slot];
    slot_word[SFPR_SLOT_HWAB_LSB]          = s_hwab[win_slot];
    slot_word[SFPR_SLOT_CPL_HELD_LSB]      = s_held[win_slot];
    slot_word[SFPR_SLOT_DEP_PENDING_LSB]   = s_dep[win_slot] != '0;
    slot_word[SFPR_SLOT_DEP_FAIL_LSB]      = s_depfail[win_slot];
    slot_word[SFPR_SLOT_DN_DONE_LSB]       = s_dn[win_slot];
    slot_word[SFPR_SLOT_HOST_TID_LSB +: 16] = s_tid[win_slot];
  end

  wire [31:0] state_word = {2'b0, n_vol, 2'b0, n_used, 3'b0, shst_o, fast_ok, pf_rest, nand_busy_i, wp_q,
                            nand_inhibit_o, pf_lat, pf_pin, st};
  logic ro_reg, wo_reg;
  always_comb begin
    rb_rdata = 32'h0;
    rb_err   = 1'b0;
    ro_reg   = 1'b0;
    wo_reg   = 1'b0;
    if (in_slotwin) begin
      rb_rdata = slot_word;
      ro_reg   = 1'b1;
    end else if (ci_rng) begin
      rb_rdata = ci_rdata;
      ro_reg   = rb_addr == SFPR_CI_STATUS || rb_addr == SFPR_CI_LAST_MARK;
      wo_reg   = rb_addr == SFPR_CI_MARK;
      if (!CRASH_INJ_EN) rb_err = rb_we;
    end else begin
      case (rb_addr)
        SFPR_ID:                rb_rdata = SFPR_ID_MAGIC;
        SFPR_VERSION:           rb_rdata = SFPR_VERSION_VAL;
        SFPR_CAPS:              rb_rdata = {16'(PLP_QUALIFICATION_ID), 6'h0, CRASH_INJ_EN, PLP_PRESENT, 8'(N)};
        SFPR_STATE:             rb_rdata = state_word;
        SFPR_CFG:               rb_rdata = cfg;
        SFPR_GATE_TIMEOUT:      rb_rdata = gate_to;
        SFPR_RECOV_TIMEOUT:     rb_rdata = recov_to;
        SFPR_PF_RESTORE_CYCLES: rb_rdata = pf_restore;
        SFPR_PHASE_RESULT:      rb_rdata = {29'h0, ph_result};
        SFPR_ERR_STATUS:        rb_rdata = err_status;
        SFPR_ERR_INFO:          rb_rdata = err_info;
        SFPR_IRQ_STATUS:        rb_rdata = irq_status;
        SFPR_IRQ_EN:            rb_rdata = irq_en;
        SFPR_COMMIT_SEQ_LO:     rb_rdata = commit_lo;
        SFPR_COMMIT_SEQ_HI:     rb_rdata = commit_hi;
        SFPR_DURABLE_CNT:       rb_rdata = c_durable;
        SFPR_CNT_ADMIT:         rb_rdata = c_admit;
        SFPR_CNT_ABORT_PF:      rb_rdata = c_abort_pf;
        SFPR_CNT_ABORT_STATE:   rb_rdata = c_abort_state;
        SFPR_CNT_REJ_CONFLICT:  rb_rdata = c_rej_conflict;
        SFPR_CNT_CPL_HOST:      rb_rdata = c_cpl_host;
        SFPR_CNT_ACK_DURABLE:   rb_rdata = c_ack_dur;
        SFPR_CNT_ACK_VOL:       rb_rdata = c_ack_vol;
        SFPR_CNT_GATE_HELD:     rb_rdata = c_gate_held;
        SFPR_CNT_GATE_CONV:     rb_rdata = c_gate_conv;
        SFPR_CNT_DROP:          rb_rdata = c_drop;
        SFPR_CNT_VOL_DURABLE:   rb_rdata = c_vol_dur;
        SFPR_CNT_VOL_FAILED:    rb_rdata = c_vol_fail;
        SFPR_LAT_DUR_SUM:       rb_rdata = lat_sum;
        SFPR_LAT_DUR_MAX:       rb_rdata = lat_max;
        SFPR_LAT_VOL_MAX:       rb_rdata = lat_vol_max;
        SFPR_GATE_HOLD_MAX:     rb_rdata = hold_max;
        SFPR_RECOV_CYC_LAST:    rb_rdata = recov_last;
        SFPR_RECOV_CYC_MAX:     rb_rdata = recov_max;
        SFPR_PF_SAFE_CYC_LAST:  rb_rdata = pf_safe_last;
        SFPR_CNT_PHASE_RPT:     rb_rdata = c_phase;
        SFPR_STK_FLAGS:         rb_rdata = k_flags;
        SFPR_STK_PF_COUNT:      rb_rdata = k_pf_count;
        SFPR_STK_WARM_COUNT:    rb_rdata = k_warm_count;
        SFPR_STK_LAST_CAUSE:    rb_rdata = k_cause;
        SFPR_STK_PF_SNAP0:      rb_rdata = k_snap0;
        SFPR_STK_PF_SNAP1:      rb_rdata = k_snap1;
        SFPR_STK_PF_TS:         rb_rdata = k_pf_ts;
        SFPR_STK_PF_SAFE_CYC:   rb_rdata = k_safe_cyc;
        SFPR_STK_PF_COMMIT_SEQ: rb_rdata = k_pf_seq;
        SFPR_STK_VOL_LOST:      rb_rdata = k_vol_lost;
        SFPR_STK_RST_SNAP:      rb_rdata = k_rst_snap;
        SFPR_STK_RECOV:         rb_rdata = k_recov;
        SFPR_STK_TS_NOW:        rb_rdata = k_ts;
        SFPR_CTRL, SFPR_RECOV_DONE, SFPR_PHASE, SFPR_RETIRE: wo_reg = 1'b1;
        default:                rb_err = rb_sel;
      endcase
      ro_reg = !(rb_addr == SFPR_CTRL || rb_addr == SFPR_CFG || rb_addr == SFPR_GATE_TIMEOUT ||
                 rb_addr == SFPR_RECOV_TIMEOUT || rb_addr == SFPR_PF_RESTORE_CYCLES || rb_addr == SFPR_RECOV_DONE ||
                 rb_addr == SFPR_PHASE || rb_addr == SFPR_RETIRE || rb_addr == SFPR_ERR_STATUS ||
                 rb_addr == SFPR_IRQ_STATUS || rb_addr == SFPR_IRQ_EN || rb_addr == SFPR_COMMIT_SEQ_LO ||
                 rb_addr == SFPR_COMMIT_SEQ_HI);
    end
    if (rb_sel && rb_we && ro_reg) rb_err = 1'b1;
    if (rb_sel && !rb_we && wo_reg) rb_rdata = 32'h0;
  end

`ifndef SYNTHESIS
  // ================================================================ simulation checks
  initial if ($bits(sfs_cmd_t) != SFS_CMD_BITS || $bits(sfs_cpl_t) != SFS_CPL_BITS)
    $fatal(1, "silicaflux_storage_pkg: SFS_CMD_BITS / SFS_CPL_BITS disagree with the struct widths");
  // the fundamental gate property: a SUCCESS for a durability-requiring command
  // is never presented to the host before that command is DURABLE
  // (simulation only: samples the reset as data, hence the waiver)
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) begin
    if (crst_n && do_load && take_slot && s_st[sel] == 7'(SFS_ST_SUCCESS)) begin
      if ((s_cls[sel] == SFPR_CLS_TRIM || s_cls[sel] == SFPR_CLS_FLUSH ||
           (s_cls[sel] == SFPR_CLS_WRITE && (s_fua[sel] || !s_early[sel]))) && s_phase[sel] != SFPR_PH_DURABLE)
        $fatal(1, "sfpr: SUCCESS presented for slot %0d before DURABLE", sel);
      if (s_cls[sel] == SFPR_CLS_FLUSH && s_dep[sel] != '0)
        $fatal(1, "sfpr: FLUSH slot %0d presented with pending dependencies", sel);
    end
  end
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
