# Third-party provenance

All files below are copied **unmodified** from the repository archive
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-storagecore-p51.zip` (StorageCore, Project 51), paths
relative to `silicaflux-storagecore/`. `python3 scripts/check_vendor.py <Aureom.AI checkout>` re-verifies them
(SHA-256, 19 / 19 byte-identical; result in `reports/vendor_check.txt`).

| Files | Used for |
|---|---|
| `rtl/silicaflux_storage_pkg.sv`, `rtl/generated/sfs_proto_enums.svh`, `rtl/generated/sfs_map_pkg.sv` | command / completion types and protocol enumerations on the recovery controller's ports |
| `rtl/sfs_fifo.sv` | the recovery controller's hardware completion FIFO |
| `rtl/sfs_cmd_ctrl.sv` | the real command controller behind the recovery controller in the co-simulation |
| `third_party/silicaflux-controlcore/firmware/**`, `scripts/mkimage.py`, `scripts/generated/cc_memmap.py`, `sw/include/generated/sfs_map.h` | ControlCore runtime (crt0, trap entry, link script, image tool) for the RV32IM firmware image build (`make -C firmware/silicaflux_ftl fw`) |

`firmware/tools/p56_original/` holds the **unmodified** Project 56 FTL sources (`include/`, `src/`, with
`SHA256SUMS` taken from `silicaflux-flashmap-p56.zip`), used only to write schema-1 media for the upgrade test and as
the baseline of the P56-vs-P58 benchmark. `firmware/silicaflux_ftl/` is the P56 FTL **with** the Project 58 changes
(`reports/ftl_delta.md`).
