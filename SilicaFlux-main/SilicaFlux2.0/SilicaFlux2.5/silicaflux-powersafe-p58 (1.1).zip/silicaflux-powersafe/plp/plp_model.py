#!/usr/bin/env python3
"""SilicaFlux PowerSafe (Project 58) -- capacitor-backed PLP RESEARCH model.

    *** Every electrical number in this file is an ESTIMATE / ASSUMPTION. ***
    Nothing here was measured.  The model exists to decide WHAT must be built
    and measured before physical power-loss protection may be claimed
    (silicaflux_storage_recovery PLP_PRESENT = 1).  Until a hardware
    qualification record exists, PLP_PRESENT stays 0 and the controller runs
    the no-PLP policy (no early acknowledgement, nothing drained on a fault).

Model
-----
Hold-up bank C charged to V_hold, discharged through a buck regulator with
efficiency eta(Vin) until the regulator's minimum input V_min:
    E_usable = 1/2 * C_eff * (V_hold^2 - V_min'^2) * eta
    C_eff    = C_nom * tolerance * temp_factor(T) * age_factor(age)
    V_min'   = V_min + I_peak * ESR_eff        (ESR drop at the end of discharge)
    t_holdup = E_usable / P_shutdown  -  t_detect
Required time = work the shutdown policy must complete after the warning,
from the FTL's worst case (sfftl_ps_worst_case_ops) and the cache size:
    no_plp      nothing (Project 58 default): 0
    finish      finish the NAND operation in flight (worst: a block erase) and
                assert WP#
    drain       finish + destage the volatile write cache (W pages) + 1 journal page
    checkpoint  drain + a full checkpoint (needed only if mapping state were
                kept in RAM -- not the case for FlashMap; listed for comparison)
NAND times: NANDLab illustrative SLC (tPROG 200 us, tBERS 2 ms) and an assumed
TLC-class part (tPROG 2 ms, tBERS 10 ms) -- both ASSUMPTIONS.
Monte Carlo over tolerance, temperature, ageing, shutdown power, efficiency
and supervisor latency; deterministic seed.
"""
import csv, math, os, random

HERE = os.path.dirname(os.path.abspath(__file__))
random.seed(58)

# ---------------------------------------------------------------- candidate hold-up banks (ASSUMED datasheet-class values)
BANKS = [
    # name, C_nom [F], V_hold [V], V_min [V], ESR [ohm], temp model, EOL capacitance factor
    dict(name="A: 6 x 470 uF / 35 V tantalum-polymer @ 30 V", C=6 * 470e-6, Vh=30.0, Vmin=6.0, esr=0.025, tech="tantalum", eol=0.85),
    dict(name="B: 4 x 220 uF / 25 V aluminium-polymer @ 20 V", C=4 * 220e-6, Vh=20.0, Vmin=6.0, esr=0.020, tech="al_polymer", eol=0.80),
    dict(name="C: 2 x 1 F / 2.7 V supercap in series @ 5.0 V", C=0.5, Vh=5.0, Vmin=2.9, esr=0.12, tech="supercap", eol=0.70),
]

def temp_factor(tech, T):
    """capacitance vs temperature (ASSUMED shapes): 1.0 at 25 C"""
    if tech == "tantalum":
        return 1.0 + (T - 25.0) * (0.0012 if T > 25 else 0.0015)
    if tech == "al_polymer":
        return 1.0 + (T - 25.0) * (0.0010 if T > 25 else 0.0020)
    return 1.0 + (T - 25.0) * (0.0005 if T > 25 else 0.0045)       # supercap: strong cold loss

def esr_factor(tech, T):
    """ESR vs temperature (ASSUMED): x1 at 25 C, rises in the cold"""
    if T >= 25:
        return 1.0
    k = {"tantalum": 0.012, "al_polymer": 0.015, "supercap": 0.035}[tech]
    return 1.0 + (25.0 - T) * k

def eta(vin, vh, vmin):
    """buck efficiency vs input voltage (ASSUMED 0.92 at the top, 0.85 near drop-out)"""
    x = (vin - vmin) / max(vh - vmin, 1e-9)
    return 0.85 + 0.07 * max(0.0, min(1.0, x))

def holdup(bank, P, T, age, tol, t_detect):
    """constant output power P through eta(V) = a + b*V:  dE/dt = -P / eta  with E = C V^2 / 2
    -> t = (C / P) * integral_{V_end}^{V_hold} V * eta(V) dV   (closed form);
    V_end solves  V - I*ESR = V_min  with  I = P / (eta(V) * V)  (fixed point)"""
    C = bank["C"] * tol * temp_factor(bank["tech"], T) * (1.0 - (1.0 - bank["eol"]) * age)
    esr = bank["esr"] * esr_factor(bank["tech"], T) * (1.0 + 1.0 * age)    # ESR doubles at end of life (ASSUMED)
    vh, vmin = bank["Vh"], bank["Vmin"]
    bb = 0.07 / (vh - vmin)
    aa = 0.85 - bb * vmin
    v = vmin
    for _ in range(50):
        v = vmin + P * esr / (eta(v, vh, vmin) * v)
    if v >= vh or C <= 0:
        return 0.0
    F = lambda x: aa * x * x / 2.0 + bb * x ** 3 / 3.0
    t = C / P * (F(vh) - F(v))
    return max(0.0, t - t_detect)

# ---------------------------------------------------------------- required time per policy (from the FTL worst case)
NAND = {
    "SLC (NANDLab illustrative)": dict(tprog=200e-6, tbers=2e-3, txfer=4096 * 30e-9),
    "TLC-class (assumed)": dict(tprog=2.0e-3, tbers=10e-3, txfer=16384 * 10e-9),
}
CACHE_PAGES = 8          # write cache of the co-simulation configuration (8 logical pages)
DIES = 1                 # pages destaged one at a time (single channel, synchronous FTL)
CKPT_PAGES = 16          # 64 MiB bench device checkpoint (reports/perf/PERF.md)

def required(policy, n):
    finish = max(n["tbers"], n["tprog"] + n["txfer"])                   # op in flight: worst is an erase
    if policy == "no_plp":
        return 0.0
    if policy == "finish":
        return finish
    drain = finish + CACHE_PAGES / DIES * (n["tprog"] + n["txfer"]) + (n["tprog"] + n["txfer"])
    if policy == "drain":
        return drain
    return drain + CKPT_PAGES * (n["tprog"] + n["txfer"]) + n["tbers"]   # checkpoint (+ ring block erase)

POLICIES = ["no_plp", "finish", "drain", "checkpoint"]

# ---------------------------------------------------------------- corners + Monte Carlo
P_RANGE = (1.5, 4.0)       # W during the shutdown work (controller + 1 active die + regulators) -- ASSUMED
T_RANGE = (-40.0, 85.0)    # industrial ambient
DET = (20e-6, 80e-6)       # supervisor detection + firmware reaction -- ASSUMED

rows, mc = [], []
for bank in BANKS:
    nominal = holdup(bank, 2.5, 25.0, 0.0, 1.0, 50e-6)
    worst = holdup(bank, P_RANGE[1], T_RANGE[0], 1.0, 0.8, DET[1])
    hot_old = holdup(bank, P_RANGE[1], T_RANGE[1], 1.0, 0.8, DET[1])
    samples = []
    for _ in range(4000):
        samples.append(holdup(bank, random.uniform(*P_RANGE), random.uniform(*T_RANGE), random.random(),
                              random.uniform(0.8, 1.2), random.uniform(*DET)))
    samples.sort()
    for nname, n in NAND.items():
        for pol in POLICIES:
            req = required(pol, n)
            ok = sum(1 for s in samples if s >= req) / len(samples)
            rows.append(dict(bank=bank["name"], nand=nname, policy=pol, required_ms=req * 1e3, nominal_ms=nominal * 1e3,
                             worst_corner_ms=worst * 1e3, p01_ms=samples[len(samples) // 100] * 1e3,
                             p_success=ok, margin_worst=(worst / req) if req > 0 else float("inf")))
    for s in samples[::40]:
        mc.append(dict(bank=bank["name"], holdup_ms=s * 1e3))

with open(os.path.join(HERE, "plp_results.csv"), "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
    w.writeheader(); w.writerows(rows)

# ---------------------------------------------------------------- chart: hold-up distribution vs required time
W, H, L, R, T, B = 820, 380, 250, 30, 40, 60
o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" font-family="sans-serif" font-size="11">',
     f'<rect width="{W}" height="{H}" fill="#ffffff"/>',
     f'<text x="16" y="22" font-size="13" font-weight="bold">PLP research model (ESTIMATES): hold-up time vs required shutdown work</text>']
lo, hi = math.log10(0.05), math.log10(200.0)
X = lambda ms: L + (math.log10(max(ms, 0.05)) - lo) / (hi - lo) * (W - L - R)
for v in (0.1, 0.3, 1, 3, 10, 30, 100):
    o.append(f'<line x1="{X(v):.1f}" y1="{T}" x2="{X(v):.1f}" y2="{H-B}" stroke="#e5e7eb"/>')
    o.append(f'<text x="{X(v):.1f}" y="{H-B+15}" text-anchor="middle" fill="#6b7280">{v:g}</text>')
o.append(f'<text x="{(L+W-R)/2}" y="{H-25}" text-anchor="middle" fill="#374151">milliseconds (log)</text>')
for i, bank in enumerate(BANKS):
    y = T + 30 + i * 70
    s = sorted(m["holdup_ms"] for m in mc if m["bank"] == bank["name"])
    p1, p50, p99 = s[len(s) // 100], s[len(s) // 2], s[(len(s) * 99) // 100]
    o.append(f'<text x="{L-8}" y="{y+4}" text-anchor="end" fill="#111827">{bank["name"][:34]}</text>')
    o.append(f'<line x1="{X(p1):.1f}" y1="{y}" x2="{X(p99):.1f}" y2="{y}" stroke="#2563eb" stroke-width="10" stroke-opacity="0.35"/>')
    o.append(f'<line x1="{X(p50):.1f}" y1="{y-7}" x2="{X(p50):.1f}" y2="{y+7}" stroke="#2563eb" stroke-width="2"/>')
cols = {"finish": "#059669", "drain": "#d97706", "checkpoint": "#db2777"}
yy = H - B - 18
for nname, n in NAND.items():
    dash = "" if nname.startswith("SLC") else ' stroke-dasharray="5,4"'
    for pol in ("finish", "drain", "checkpoint"):
        r = required(pol, n) * 1e3
        o.append(f'<line x1="{X(r):.1f}" y1="{T+10}" x2="{X(r):.1f}" y2="{H-B}" stroke="{cols[pol]}" stroke-width="1.5"{dash}/>')
o.append(f'<text x="{L}" y="{H-8}" fill="#374151">bars: hold-up p1..p99 (Monte Carlo), tick = median.  vertical lines: required time — '
         f'green finish in-flight, orange drain cache, pink + checkpoint; solid SLC, dashed TLC-class</text>')
o.append("</svg>")
open(os.path.join(HERE, "holdup_vs_policy.svg"), "w").write("\n".join(o))

# ---------------------------------------------------------------- report
def f(x):
    return "∞" if x == float("inf") else f"{x:.2f}"
Lr = ["# Capacitor-backed PLP — research model (ESTIMATES ONLY)", "",
      "Generated by `plp/plp_model.py` (deterministic, seed 58). **No electrical value here was measured.** Capacitor "
      "values are datasheet-class assumptions, shutdown power is an assumed range, NAND times are NANDLab's illustrative "
      "SLC values and an assumed TLC-class part. The model's purpose is to state what has to be built and measured "
      "before `PLP_PRESENT` may be set; it is not a design.", "",
      "## Model", "",
      "* usable energy ½·C_eff·(V_hold² − V_min′²) through a buck with η = 0.85…0.92 (assumed curve);",
      "* C_eff = C_nom × tolerance (0.8…1.2) × temperature factor × ageing factor (end-of-life capacitance "
      "85 % tantalum-polymer, 80 % aluminium-polymer, 70 % supercap — assumed); ESR rises in the cold and doubles at end "
      "of life (assumed); the discharge ends when V − I·ESR reaches V_min;",
      "* shutdown power 1.5…4 W (controller + one programming die + regulator losses — assumed), ambient −40…85 °C, "
      "supervisor + firmware reaction 20…80 µs;",
      "* required work per policy from the FTL's worst case: the operation in flight (worst: a block erase), plus for "
      f"`drain` the {CACHE_PAGES}-page write cache and one journal page, plus for `checkpoint` a {CKPT_PAGES}-page checkpoint "
      "and a ring-block erase.", "",
      "## Results", "",
      "| Bank | NAND | Policy | Required ms | Hold-up nominal ms | Worst corner ms (−40 °C, EOL, −20 %, 4 W) | Monte-Carlo p1 ms | P(success) | Worst-corner margin |",
      "|---|---|---|---|---|---|---|---|---|"]
for r in rows:
    if r["policy"] == "no_plp":
        continue
    Lr.append(f"| {r['bank']} | {r['nand']} | {r['policy']} | {r['required_ms']:.2f} | {r['nominal_ms']:.2f} | "
              f"{r['worst_corner_ms']:.2f} | {r['p01_ms']:.2f} | {r['p_success']*100:.1f} % | {f(r['margin_worst'])} |")
Lr += ["", "![hold-up vs policy](holdup_vs_policy.svg)", "",
       "## Reading the model", "",
       "* **Finishing the operation in flight** is what physical PLP buys first: it removes torn pages and partial erases "
       "(which the no-PLP recovery already tolerates). It is the cheapest policy.",
       "* **Draining the write cache** is the policy that would allow acknowledging writes before they are durable "
       "(`PLP_PRESENT = 1` → early acknowledgement). Its required time scales with the cache size and, for TLC-class "
       "program times, exceeds what small banks deliver at the cold / end-of-life corner — the corner, not the nominal "
       "case, decides.",
       "* **A checkpoint at power loss is not needed** with FlashMap: acknowledged mapping state is never RAM-only "
       "(spare records + journal), so the PowerSafe design never spends hold-up energy on metadata.",
       "* Supercap banks look large nominally but lose most margin in the cold (capacitance and ESR) — a measurement "
       "priority, not a conclusion.", "",
       "## Qualification required before `PLP_PRESENT = 1`", "",
       "1. Schematic + layout of the hold-up circuit (charger / boost, isolation, buck), with the supervisor threshold and "
       "its tolerance; component derating policy.",
       "2. Measured shutdown power of the real controller + NAND at maximum parallelism during a drain, at voltage and "
       "temperature corners (not an estimate).",
       "3. Measured capacitance and ESR of the chosen capacitors across −40…85 °C, and after accelerated life testing; "
       "the end-of-life factor replaces the assumed one.",
       "4. Measured worst-case drain time on the target firmware (cycle counts of `sfftl_ps_worst_case_ops` work + "
       "destage of a full cache, multi-die timing of the actual NAND part).",
       "5. Power-fail injection campaign on hardware: thousands of supply cuts at random points with the drain policy "
       "enabled, verifying every acknowledged write (the same reference-model checks as `firmware/tests`).",
       "6. In-field capacitor health monitoring (periodic discharge test) that automatically drops back to the no-PLP "
       "policy (`CFG` / firmware) when the bank degrades — required, because ageing is the dominant failure mode.",
       "7. Only then: build with `PLP_PRESENT = 1` and `PLP_QUALIFICATION_ID` = the id of that qualification record. "
       "The RTL refuses to elaborate `PLP_PRESENT = 1` without an id (docs/08_PLP_MODEL.md).", "",
       "Raw results: `plp/plp_results.csv`."]
open(os.path.join(HERE, "PLP_REPORT.md"), "w").write("\n".join(Lr) + "\n")
print("\n".join(Lr[:40]))
