# 04 — PowerSafe firmware

Freestanding C99 for the ControlCore (RV32IM), no malloc, no static data: `firmware/powersafe/`.

## 1. `sfps` — command execution and phase reporting (`sfps.h`, `sfps.c`)

`sfps_exec()` executes one command on the FlashMap FTL and reports the command's phases to the recovery controller
through a small ops table (`phase`, `retire`, `inhibited`; all optional, so host tests run without RTL):

* phases come from the FTL's **event hook** at the moment they are reached: `PROG_END` (status PASS) of the command's
  last page → `PROGRAMMED`; `MAP_COMMIT` of the last page → `VERIFIED`, `MAP_COMMITTED`, `DURABLE` (the page carries
  its spare record, so no further metadata is needed). DEALLOCATE: after its journal page; FLUSH: after the cache is
  destaged and the journal flushed.
* **Volatile write cache** (`wce`, host-controlled): a WRITE without FUA is copied into a cache page (whole logical
  pages; partial pages are read-modified-written) and acknowledged at BUFFERED. Each cache page records the
  controller slots whose data it holds; when the page is destaged (an ordinary write-through `sfftl_write`) every
  slot whose last page that was gets `DURABLE`. Destage triggers: eviction (clean pages first, then the oldest dirty),
  FLUSH, a FUA / write-through / DEALLOCATE overlapping it (older cached data reaches the FTL first), idle, cache off.
  A destage that fails for good (media / space) `RETIRE`s the slots — their FLUSH then fails, as NVMe requires.
* A command that fails part-way removes its slot from every cache page, so a later destage can never report progress
  for a slot that has been reused.
* **Power fault**: after `sfps_power_fault()` (or `ftl.ps_warned`, or `inhibited()`), mutating commands are refused at
  once — not even a cache insert. Without PLP nothing is destaged; dirty pages are counted as lost
  (`vol_lost_at_pf`). `t_no_plp_policy`: after the warning the firmware issues **0 programs and 0 erases**.

## 2. `sfps_fw` — main loop on the ControlCore (`sfps_fw.h`, `sfps_fw.c`)

Platform-independent: register pages, DMA and "supply still on" come through `sfps_plat_t`, so the same code runs in
the Verilator co-simulation (each register access is one bus cycle on the RTL) and cross-compiles for RV32IM.

**Boot / recovery** (`sfps_fw_boot`): check `ID`; read the controller's sticky diagnostics (`STK_FLAGS`, cause, fault
and reset snapshots, volatile-lost count); drop the RAM cache; `CTRL.BOOT_ACK` (INIT → RECOVER); recovery mount with
the diagnostics passed to the FTL (`sfftl_mount_ex`, logged as a persistent event); format only on a blank medium and
only when explicitly allowed (first boot); publish capacity / MDTS to `sfs_cmd_ctrl`, `COMMIT_SEQ`, `CFG.WCE`;
`RECOV_DONE` (OK / READONLY / FAIL). Diagnostics are cleared (`CLR_STICKY`) only after a checkpoint that carries them is
on the medium.

**Main loop** (`sfps_fw_poll`), one iteration:

1. `STATE`. Power fault latched → `sfps_power_fault()`; drain the queue (claim refused → post `ABORT_PWR_LOSS`; the
   controller drops these, it already aborted them). In `PF_SAFE` with the supply restored → `PF_RESUME`; if the
   controller chose RECOVER, remount (RAM cache kept — a brown-out did not lose it), log a BROWNOUT event, `RECOV_DONE`;
   if it chose fast resume, `sfftl_ps_power_restored()`.
2. SHUTDOWN → finish queued commands, destage the cache, clean checkpoint (`sfftl_shutdown`), `SHUTDOWN_DONE`.
3. READY / READONLY → one command: `FWQ_HEAD`, `FWQ_POP`, read the 8-word SQE from the tag window, claim
   (`PHASE STARTED`, check `PHASE_RESULT`), DMA in + `BUFFERED` (writes), `sfps_exec`, DMA out (reads), `CPL_POST`.
4. Idle → destage one cache page.

**GET_LOG 0x58 — recovery telemetry** (`sfps_fw_telemetry`): persistent counters (events, unsafe shutdowns,
recoveries, fallback mounts, damaged metadata, torn pages discarded, power faults), last mount statistics, controller
`RECOV_CYC_LAST`, fault count, cause, gate / acknowledgement counters, cache state, commit sequence number, and the 8
most recent persistent events. The co-simulation prints the decoded page at the end of every campaign
(`reports/cosim/*.log`).

## 3. Footprint

`reports/firmware_size.md`: FTL 32.6 KB + PowerSafe 9.4 KB of RV32IM code (-Os), 0 data / bss in every object; RAM for
the co-simulation configuration (P51-class device, 8-page cache, MDTS 16) 23.2 KB of the 32 KiB DMEM. The P56 FTL
self-test image rebuilt with the P58 library: 42.5 KB (64 % of IMEM).
