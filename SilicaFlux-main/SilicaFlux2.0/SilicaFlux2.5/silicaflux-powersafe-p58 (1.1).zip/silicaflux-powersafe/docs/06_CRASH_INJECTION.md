# 06 — Crash injection

## 1. Named crash points

A crash point is a named position in the controller's flow, matched against the FTL / PowerSafe event stream
(`firmware/crash/sfcrash.c`). A crash is fully specified by **(geometry, workload seed, point, k)** — crash at the
k-th time the point is reached — and is replayable: `sfps_tests --replay <geometry> <seed> <point> <k>`.

| Brief item | Points | Action at the k-th hit |
|---|---|---|
| 1 before NAND programming | `host_before_program` | supply off before the program |
| 2 during program operation | `host_during_program` (torn, uncorrectable), `host_during_program_eccpass` (torn, ECC returns garbage as corrected — only the CRC saves it), `host_during_program_almost` (ECC-correctable) | the program is interrupted with that outcome |
| 3 after data programming | `host_after_program` | program completed, status never seen |
| 4 before mapping update | `host_before_map_update` | status PASS seen, L2P not updated |
| 5 during metadata journal update | `journal_before_program`, `journal_during_program`, `journal_after_program`, `journal_before_apply` (journal durable, its RAM effect not applied) | as named |
| 6 before command completion | `before_completion` (command finished, completion not delivered), `flush_before_completion` | supply off |
| 7 during garbage collection | `gc_victim_chosen`, `gc_before_reloc`, `gc_during_reloc`, `gc_before_map_update`, `gc_before_erase`, `gc_during_erase` (partial erase), `wl_during_reloc` (static wear-levelling copy) | as named |
| 8 during checkpoint creation | `ckpt_before_body`, `ckpt_during_body`, `ckpt_between_body`, `ckpt_before_commit`, `ckpt_during_commit`, `ckpt_during_commit_eccpass`, `ckpt_after_commit`, `meta_during_erase` | as named |
| extra | `open_during_erase` (erase-on-allocate), `destage_during_program` (write-cache destage), `mount_during_ckpt` and `mount_at_op` (crash **during recovery**, every NAND operation of a recovery mount) | as named |

31 points. Counting mode (point = none) records how often every point is reached, so a sweep enumerates
k = 1 … hits.

## 2. Execution back-ends

| Back-end | Supply loss | Used by |
|---|---|---|
| in-process | `simnand` goes dead (or the next operation is interrupted with the forced outcome); the FTL unwinds with `EPOWER`; the harness mounts again from the same medium with a fresh FTL arena | `firmware/tests` sweeps, campaigns |
| **forked process + persistent medium** | the medium is a `MAP_SHARED` file; `simnand`'s power-loss callback `_exit()`s the controller process at the cut; the next process opens the file, recovers and verifies against the host's reference model kept in shared memory | `process_crash` |
| **RTL co-simulation** | the firmware writes the selected point's id to `CI_MARK` at every hit; the recovery controller's crash-injection unit fires `ci_crash_o` on the k-th; the bench removes the supply (POR), tears the NAND operation inside its busy window with the point's outcome, and reboots | `cosim/` campaigns |
| RTL events | the crash-injection unit fires on the N-th admission / host completion / phase report / NAND operation start, or every cycle, with a delay; actions crash, warning, warning + crash, controller reset | `tb/tb_sfpr.sv`, `cosim/` |

## 3. Sweep procedure (`t_point_sweep`)

Deterministic workload per (geometry, seed): sequential prefill to ~88 % of the LBA range → random WRITE (partial and
multi-page, 10 % FUA) / READ-verify / DEALLOCATE / FLUSH / WCE toggling / idle (GC pressure, aggressive static wear
levelling) → a scripted power cycle with recovery → more random operations. A counting run records the hits of every
point; then for each point up to 24 values of k spread over [1, hits] are run. Each crash run: crash at (point, k) →
recover (repeating if the crash hits the recovery) → read **every** LBA back and check it against the reference model,
check intra-page atomicity, run the FTL invariant check → continue, crash again at a random operation (repeated
recovery) → verify again → require 0 NAND rule violations. Three geometries: P51-class (512-B pages), 2-KiB pages with
4 LBAs per page (read-modify-write, atomicity), and read-back verification on.
