# 00 — Repository audit (Project 58 PowerSafe)

Audited: `btcphilosopher/Aureom.AI`, branch `claude/great-cray-aqwcdz`, commit `4173a23`. As in every earlier
SilicaFlux project, the hardware and firmware live in zip archives under `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`
(ECCCore P54 under `SilicaFlux-main/`). Extracted and read: `silicaflux-flashmap-p56` (FTL), `silicaflux-storagecore-p51`
(SoC, NAND controller, command controller, PLP registers), `silicaflux-buffercore-p55` (write buffers, DMA),
`silicaflux-flashlink-p53`, `silicaflux-ecccore-p54` / `silicaflux-nandlab-v0.1.0` (NAND model), `silicaflux-controlcore`,
`silicaflux-hostlink-project25`, `silicaflux-ras-project26`, `silicaflux-powerclock`. No Project 57 and no earlier
PowerSafe project exist. "Evidence" means what the owning project recorded; items re-run here are marked.

## 1. Findings per area

| Area | Found | Consequence for Project 58 |
|---|---|---|
| **FTL** (P56 FlashMap) | Page-mapping FTL in C for the ControlCore. Acknowledges a write only after the page — with a self-describing spare record {LPN, 48-bit SEQ, CRC-32} — is programmed and confirmed; TRIM after its journal page; checkpoints commit-last in a metadata ring; roll-forward recovery. Defines a PowerSafe interface (`sfftl_powersafe.h`) that nothing implemented. 27 / 27 tests **re-run here: pass**. | Basis of the firmware. Extended, not replaced: event hooks, A/B checkpoint retention, schema 2 with a persistent event log, recovery telemetry (docs/05, `reports/ftl_delta.md`). |
| **NAND model** | P52 NANDLab (SV + Python twin: erase→1, program 1→0, sequential pages, interrupted operations); P51 behavioural flash model; P56 `simnand.c` (C, NANDLab semantics, power cuts with random outcome). | `simnand` extended: forced outcome of an interrupted operation (not started / completed-unseen / ECC-correctable / torn / torn-but-ECC-passes / partial erase), power-loss callback, **file-backed persistent medium** (mmap) so a controller process can die and another one recover the same medium. |
| **Write buffers** (P55 BufferCore) | Volatile SRAM slots; DIRTY until firmware `COMMIT_D` after the NAND program; rule `early_ack_ok = WCE \| PLP_PRESENT`; FLUSH completes when no DIRTY slot remains; power fail refuses new H2B. | The same rule, now enforced by the completion gate in hardware and generalised (FLUSH depends only on writes acknowledged before it). `PLP_PRESENT` kept at 0 and made un-claimable without a qualification id. |
| **DMA** | P51 `sfs_dma`, P55 descriptor engines (completion after commit), DataFabric DMA. | Unchanged. In the co-simulation the firmware's DMA is a behavioural copy with transfer time; the gate sits on the completion path, after DMA. |
| **PowerClock** | DVFS / clock gating / thermal; no power-loss function. | Nothing to integrate. The power-fail warning comes from a board supervisor pin, as in P51. |
| **ControlCore** | MCU-I RV32IM, 64 KiB IMEM / 32 KiB DMEM, register pages on the accelerator bus, POR / system / accelerator-domain resets (the storage subsystem runs on a firmware-controllable reset). | Recovery controller uses the same register-page convention and two resets (`por_n` / `rst_n`). Firmware footprint checked against IMEM / DMEM (`reports/firmware_size.md`). |
| **NVMe Flush** | P51 opcodes FLUSH / WRITE (+FUA) / READ / DEALLOCATE; P56: FLUSH = journal flush (every acknowledged write is already durable); P55: FLUSH waits for DIRTY == 0. | Formal semantics in docs/02: FLUSH covers writes *completed before it was submitted*; FUA = durable acknowledgement even with the cache on. |
| **Metadata journal** | P56: TRIM / ERASE / RETIRE / PRETIRE / MOUNT records, CRC per page, journal pages in the ring. | Unchanged format; the live region now protects journals back to the previous checkpoint. |
| **Reset sequencing** | P51: power-fail pin synchronised; quiescence; firmware drains and checkpoints, then `FW_SAFE`; WP# forced once drained; `CLR` when power returns. | See finding F1. P58 has its own reset/recovery FSM (docs/03) and keeps diagnostics across controller resets. |

## 2. Findings that changed the design

**F1 — P51's power-loss sequence assumes energy that does not exist.** P51 docs/04 §5: on `pwr_fail_ni` the firmware
*drains every owned command to completion, then writes an FTL checkpoint*, and only then sets `FW_SAFE` (WP# is held
off until then). No hold-up energy is modelled anywhere in the repository (P51 docs/08: "PLP hold-up energy is not
modelled"). With the supply actually failing, this policy starts long NAND programs (a multi-block command, a 9-page
checkpoint) that the supply may not finish, and leaves WP# released during the collapse. **Project 58 policy without
PLP** (docs/07): no new program / erase after the warning (hardware inhibit), unstarted commands aborted by hardware,
started ones stop at the next page boundary, **no drain, no checkpoint, no flush**, WP# forced as soon as the
operation in flight ends. Correctness comes from recovery, not from the warning.

**F2 — P56 recovery could leave the device unmountable after one damaged page.** P56 keeps only the newest checkpoint
in the protected ("live") part of its metadata ring. Once the ring has wrapped, an unreadable newest commit page left
no loadable checkpoint: mount returned `SFFTL_ENOFS` (or, with the opt-in rebuild, lost TRIMs and erase counts). A probe
written for this audit (300 seeds, journal-heavy workload, newest commit destroyed at a random point of its life):
**16 / 300 unmountable with P56, 0 / 300 with P58** (now the regular test `fallback_after_wrap`). P56's own
`metadata_fallback` test corrupts the newest commit before the ring wraps and therefore did not see it. Fixed by A/B
retention (docs/05).

**F3 — P56's PowerSafe interface was never wired.** `sfftl_ps_warn()` / `sfftl_ps_power_fail()` existed; nothing
called them, and `sfftl_ps_power_fail(SFFTL_PS_FLUSH_JOURNAL)` programs a page after the warning. P58 calls
`sfftl_ps_warn()` only (no flag needing energy) and adds an independent firmware-side refusal of new work.

**F4 — a P56 medium with the automatic metadata zone is too small for A/B retention** (2·need+3 blocks vs P58's
3·need+3). P58 refuses it with `SFFTL_EGEOM` without writing anything; a P56 medium formatted with a 6-block zone is
mounted and upgraded to schema 2 (`upgrade_v1` test, using the unmodified P56 library to write the medium).

## 3. Reused unmodified (byte-identical, `scripts/check_vendor.py`)

P51 `silicaflux_storage_pkg.sv`, `sfs_cmd_ctrl.sv`, `sfs_fifo.sv`, generated `sfs_map_pkg.sv` / `sfs_proto_enums.svh`
(5 / 5 against the P51 archive); the ControlCore runtime subset used by the RV32 image build (as vendored by P56); the
original P56 FTL sources in `firmware/tools/p56_original/` (14 files, `SHA256SUMS`) used for the upgrade test and the
P56-vs-P58 benchmark.

## 4. Tools

Verilator 5.020, Icarus Verilog 12, Yosys 0.33, `gcc-riscv64-unknown-elf` 13.2 installed from Ubuntu 24.04 packages
(the versions earlier projects record); host gcc 13; Python 3.13 (no third-party packages; charts are written as SVG
directly).

## 5. Not available / not claimed

No FPGA, silicon, real NAND or power-supply hardware; no electrical measurements of any kind. No PCIe / NVMe host
interface RTL in the co-simulation (the host drives the P51 command channel directly).
