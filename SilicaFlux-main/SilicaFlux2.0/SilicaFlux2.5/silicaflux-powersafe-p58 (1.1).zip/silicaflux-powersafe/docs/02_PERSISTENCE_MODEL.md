# 02 — Write persistence model

This is the contract the whole design is built and verified against. It defines when a write is in each state, when the
controller may acknowledge it, and what a host may rely on after any supported crash.

## 1. States of a write

A command moves through these states in order; a state is never re-entered. The recovery controller records the
firmware-reported ones per command (`SLOT[n].PHASE`, `PH_*` encoding) and refuses regressions.

| State | Reached when | Who records it | Survives power loss? |
|---|---|---|---|
| **Accepted** | the command passed admission control and holds a tracking slot | hardware (`PH_ACCEPTED`) | no |
| *Started* | firmware claimed it; from here hardware no longer aborts it on a power fault | firmware (`PH_STARTED`) | no |
| **Buffered** | the host data is in the controller's volatile buffer (after DMA) | firmware (`PH_BUFFERED`) | **no** |
| **Programmed** | every NAND page program of the command was issued and completed | firmware (`PH_PROGRAMMED`) | not guaranteed: completion ≠ PASS |
| **Verified** | every program returned status PASS (and, with `SFFTL_F_VERIFY_HOST_WRITE`, was read back and compared) | firmware (`PH_VERIFIED`) | yes — data and spare record are on media |
| **Mapping committed** | the FTL's L2P points at the new pages; the persistent form of that mapping is already on media (see §3) | firmware (`PH_MAP_COMMITTED`) | yes |
| **Durable** | the data **and every metadata record recovery needs to find it** are on non-volatile media | firmware (`PH_DURABLE`) | **yes — by construction** |
| **Acknowledged** | the host received the completion | hardware (`SLOT.ACKED`) | — |

Programmed is not Durable: a program can complete with status FAIL (the FTL retires the block and programs again
elsewhere), and a page whose program was interrupted can read back as anything — erased, correct, ECC-correctable,
uncorrectable, or garbage that the ECC "corrects" (the CRC rejects it).

## 2. Acknowledgement classes

| Class | Which completions | Promise |
|---|---|---|
| **Durable acknowledgement** | WRITE with the volatile write cache disabled (`CFG.WCE = 0`, the default); WRITE with FUA; DEALLOCATE; FLUSH | survives every supported crash |
| **Volatile acknowledgement** | WRITE without FUA while the host has enabled the volatile write cache (`WCE = 1`) | none until a FLUSH that was *submitted after* this completion completes successfully; then durable |
| **No acknowledgement** | an error completion, or no completion at all (in flight at the crash) | may or may not have taken effect |

**Initial no-PLP design rule.** Without physical power-loss protection (`PLP_PRESENT = 0`) a write is acknowledged
as durable only when it is Durable. The completion gate in hardware (§4) enforces this regardless of firmware. A
volatile acknowledgement exists only because the host explicitly asked for a volatile cache (NVMe *Volatile Write
Cache*); the device reports the cache as volatile and reports **no** power-loss protection (IDENTIFY byte 18 = 0).

## 3. When each command becomes Durable (FlashMap)

| Command | Durable when | Why that is sufficient |
|---|---|---|
| WRITE (write-through) | every logical page is programmed with status PASS, carrying its spare record {LPN, 48-bit SEQ, CRC-32} | recovery rolls data pages forward from their spare records; the newest SEQ per LPN wins; no checkpoint or journal is needed |
| WRITE (cached, `WCE = 1`) | its cache page(s) have been destaged as above | the destage is a write-through write |
| DEALLOCATE | the TRIM journal page is programmed (before the RAM unmap) | mount applies a TRIM only when newer than the LPN's surviving data |
| FLUSH | every dirty cache page is destaged and pending journal records are programmed | — |

Multi-page commands are durable when their *last* page is: pages are processed in order, earlier pages are already
Durable by then.

## 4. Who enforces what

| Rule | Enforced by |
|---|---|
| a durable-class SUCCESS is never delivered before the command is Durable | **hardware**: completion gate in `silicaflux_storage_recovery` (a premature SUCCESS is held, not delivered; RTL assertion in simulation; testbench scoreboard; mutation-tested) |
| a volatile SUCCESS only with WCE (or PLP) at admission, no FUA, Buffered reached, and no power fault active | hardware gate |
| a FLUSH SUCCESS only when every write acknowledged-volatile before the FLUSH was admitted is Durable; a dependency that can no longer become durable (`RETIRE`) fails the FLUSH (`MEDIA_WRITE`) | hardware gate (dependency mask per FLUSH slot) |
| phases strictly increase; firmware cannot start a command hardware already aborted | hardware (`PHASE_RESULT`) |
| the Durable report is truthful (the data and metadata really are on media) | firmware: reported from FTL events (`sfps_hook`), verified by the crash campaigns |
| nothing acknowledged is lost by recovery | FTL recovery (docs/05), verified against the reference model |

The firmware cannot acknowledge early by mistake: in the co-simulation, firmware deliberately mutated to post SUCCESS
before a write executes still loses no data, because the gate holds the completion until the firmware reports
DURABLE; with the gate removed the same firmware loses acknowledged writes (reports/mutation.md).

## 5. The invariant and what is allowed for everything else

> **Every acknowledged durable write remains correct after any supported crash and recovery sequence.**

Checked per LBA by the reference model (`firmware/ref/sfref.c`) after every recovery: let *d* be the newest
version the host holds a durable acknowledgement for (or a FLUSH made durable). The LBA must read as

* version *d* (or zeros if *d* is a DEALLOCATE / never written), **or**
* any version submitted **after** *d* (an unacknowledged or volatile-acknowledged write that happened to land),
* zeros if a DEALLOCATE was submitted after *d*.

It must never read as an older version than *d*, as another LBA's data, or as garbage.

Further guarantees (also checked):

* **Atomicity**: a logical page (`page_data_bytes`) is written atomically: the sectors one WRITE puts into one logical
  page are either all new or all old after a crash. A multi-page WRITE is not atomic as a whole (each page is).
* **Stability**: once a read after recovery returned a value, further recoveries without new writes return the same
  value (no flip-flopping of in-doubt data).
* **Ordering**: there is no ordering promise between commands in flight at the same time; the host must not have two
  overlapping WRITEs in flight (NVMe leaves the result undefined; the test hosts never do it).
* **Volatile acknowledgements** not covered by a successful FLUSH may be lost at a power loss or controller reset —
  the contract the host accepted by enabling the cache. Turning the cache off (Set Features) destages it first.

## 6. Supported crashes

Supply loss at any instant with any warning time from 0 (no hold-up energy is assumed), including during NAND program
and erase operations (torn pages, partial erases, completed-but-unseen operations, ECC miscorrection of torn pages),
during recovery itself (repeated), controller resets with the supply present, brown-outs, combined with random NAND
program / erase / read failures. **Not supported** (out of scope, docs/11): multi-bit media corruption of *already
acknowledged* metadata beyond what the redundant previous checkpoint covers (detected and reported, not repaired),
firmware bugs that report Durable falsely, and loss of the NAND itself.
