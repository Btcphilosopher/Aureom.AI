# 07 — Power-loss policy (no physical PLP)

The supply supervisor's warning (`pwr_fail_ni` falling) arrives some time before the rails collapse. Without a
qualified hold-up design that time is **unknown and assumed to be zero**: nothing in the policy depends on finishing
any work after the warning. Correctness after a real loss comes entirely from recovery (docs/05), which is verified
with warnings of 0 cycles (`cosim … hold 0`) and with no warning at all (every firmware crash point).

## 1. On the warning

| Step | Who | What | Why |
|---|---|---|---|
| 1 | hardware, same cycle after the 2-flop synchroniser | power fault latched; state → `PF_QUIESCE`; diagnostics snapshot (POR domain) | — |
| 2 | hardware | **admission closed**: every new command completed `ABORT_PWR_LOSS` / `QUIESCED` by hardware | stop accepting unsafe new work |
| 3 | hardware | commands firmware has not `STARTED` are **aborted by hardware** (their later queue completion is dropped); firmware cannot start them (`PHASE_RESULT = ABORTED / QUIESCED`) | no new NAND work for queued commands |
| 4 | hardware | **`nand_inhibit_o`**: the NAND controller refuses to *start* any program / erase | the firmware may not have seen the warning yet — defence in depth |
| 5 | hardware | held SUCCESS completions that are not yet allowed are converted to `ABORT_PWR_LOSS`; no new volatile acknowledgements | nothing becomes "acknowledged" that could still be lost |
| 6 | firmware | `sfftl_ps_warn()`: every FTL loop stops at its next page boundary and returns `EPOWER` (= not acknowledged); new commands, cache inserts, destages, GC, checkpoints refused | the command in progress is not torn into more pages |
| 7 | hardware | **WP# forced as soon as no NAND operation is in flight** (never in the middle of one) | protects the media against spurious program / erase while the rails collapse |
| 8 | hardware | `PF_SAFE` once no firmware-owned command is active and the NAND is idle | — |
| — | nobody | **no drain, no checkpoint, no journal flush, no cache destage** | there is no energy budget for them (audit F1) |

The NAND operation already in flight cannot be stopped: if the supply fails during it, the page is torn or the block
partially erased — exactly the cases recovery is built and tested for (`host_during_program*`, `gc_during_erase`,
`ckpt_during_commit*`, …).

What is lost by contract: acknowledged-volatile writes not yet covered by a FLUSH (only if the host enabled the
volatile cache) — counted in `STK_PF_SNAP0[28:24]`, `STK_VOL_LOST`, `IRQ.VOL_LOST`, `vol_lost_at_pf`; and every command
not acknowledged.

## 2. Supply returns without a reset (brown-out)

`PF_SAFE` → supply good for `PF_RESTORE_CYCLES` → `IRQ.PF_RESTORED` → firmware writes `CTRL.PF_RESUME`:

* **full recovery (default)**: state `RECOVER`; firmware remounts the FTL from the medium (RAM structures rebuilt) while
  keeping its RAM write cache (the RAM did survive), logs a BROWNOUT event, `RECOV_DONE`;
* **fast resume** (`CFG.FAST_RESUME_EN`) only if no NAND operation was in flight when the fault was latched —
  otherwise its outcome is unknown and the hardware forces the full path.

Acknowledged-volatile entries survive a brown-out in both the controller's slot table and the firmware cache; they are
destaged later and FLUSH semantics continue to hold.

## 3. Controller reset with the supply present

`rst_n` resets everything but the `STK_*` diagnostics: the slot table, the firmware and its RAM (write cache) are
gone; the NAND die finishes the operation in flight (its supply is on). Boot is a recovery mount; the diagnostics
(state before the reset, volatile writes lost) go into the persistent event log. `STK_LAST_CAUSE = WARM`.

## 4. Clean shutdown

Host shutdown notification (`shn_req_i`, or `CTRL.SHUTDOWN_REQ`) → `SHUTDOWN` (admission closed, outstanding commands
finish) → firmware destages the cache and writes a clean checkpoint → `SHUTDOWN_DONE` (refused while any slot is in use)
→ `SHUT_DONE` (`SHST = 2`, NAND inhibited, WP#). The next power-on mounts through the clean fast path (verified in the
co-simulation: every clean shutdown is followed by a clean mount).

## 5. Comparison with P51's sequence

| | P51 (docs/04 §5) | P58 without PLP |
|---|---|---|
| new commands | aborted by hardware | aborted by hardware |
| commands not yet started | drained by firmware | aborted by hardware |
| commands in progress | run to completion (multi-page) | stop at the next page boundary, not acknowledged |
| after the warning | FTL checkpoint written | nothing written |
| WP# | after the checkpoint (`FW_SAFE` + `AUTO_WP`) | as soon as the operation in flight ends |
| NAND program / erase after the warning | allowed until `FW_SAFE` | refused by the NAND controller gate |
| assumes hold-up energy | yes (not modelled) | **no** |

With qualified PLP (`PLP_PRESENT = 1`, research only) the policy becomes *drain*: early acknowledgement is allowed, the
NAND is not inhibited until the firmware has destaged every acknowledged-volatile write, `PF_SAFE` waits for that
(docs/08).
