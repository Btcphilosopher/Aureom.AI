# 11 — Limitations and what is not claimed

## Not claimed

* **Physical power-loss protection.** None. `PLP_PRESENT = 0`; the capacitor model is a research estimate (docs/08).
* **Silicon, FPGA, real NAND, real power supplies.** Everything ran in simulation: RTL in Verilator 5.020 / Icarus 12,
  firmware on the host (and cross-compiled, not executed, for RV32IM in this project), NAND as the `simnand` behavioural
  model with NANDLab semantics. No electrical value was measured.
* **Absolute timing.** NAND times are NANDLab's illustrative SLC values; the co-simulation compresses them (1 cycle =
  1 µs of NAND time). Recovery-time and latency numbers are only comparable with each other.
* **Firmware on the ControlCore RTL.** In the co-simulation the firmware is host C code whose register accesses are RTL
  bus cycles; it did not execute on the MCU-I CPU RTL (P56 did that for the FTL alone; the P58 image builds and fits,
  `reports/firmware_size.md`).
* **NVMe compliance.** P51's NVMe-inspired command set; no PCIe, no namespaces, no NVMe admin commands (WCE is a
  firmware variable, Set Features is not implemented), no atomic-write unit beyond one logical page.

## Design limits

* **Journal pages are not mirrored.** A journal page damaged on the media *after* it was written (beyond ECC) is
  detected and reported, but its records (e.g. an acknowledged TRIM) cannot be reconstructed; the trimmed data could
  reappear. Checkpoints are protected by A/B retention; journal mirroring (2 programs per journal page) would close
  this and is measured-cost future work.
* **Damaged-metadata classification is positional.** A damaged page that is the last programmed page of its block is
  indistinguishable from a crash tear and is treated as one (correct for crashes, conservative for media damage).
* **Single command at a time in firmware.** The FTL is synchronous (P56); the controller tracks up to `N_SLOTS`
  commands, but NAND work is serialised. Multi-channel overlap would change only throughput, not the persistence model.
* **Volatile write cache** is small (8 logical pages in the co-simulation) and destages one page per program; no
  coalescing beyond one logical page.
* **Upgrade path**: a P56 medium formatted with P56's automatic metadata zone (2·need+3 blocks) is refused (`EGEOM`)
  rather than migrated; there is no in-place zone resize.
* **Diagnostics after a real power loss** are reconstructed from the medium (unclean shutdown, torn pages, recovery
  statistics); the controller's `STK_*` snapshot survives only controller resets and brown-outs, because there is no
  always-on domain.
* **The gate trusts the firmware's DURABLE report.** It prevents early acknowledgement; it cannot detect a firmware
  that reports DURABLE falsely. The crash campaigns verify the reports' truth for this firmware.
* **Crash points are firmware-level positions.** RTL-level crash timing inside a NAND operation is covered by the
  co-simulation (supply loss at any cycle, tear inside the busy window), not by gate-level fault injection.
* **Yosys numbers are generic-cell estimates** (no technology library, no timing closure); the slot table could be
  made much smaller (16-bit timestamps, results passed through) if area mattered more than telemetry.
* 48-bit sequence numbers, schema-1 compatibility limits and other FTL limits are inherited from P56 (its docs/11).
