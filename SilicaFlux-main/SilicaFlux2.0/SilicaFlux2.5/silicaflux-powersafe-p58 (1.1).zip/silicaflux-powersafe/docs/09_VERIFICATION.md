# 09 — Verification

Results: **[reports/TESTS.md](../reports/TESTS.md)** (generated from the logs). This document describes what each
layer of verification checks and why it is independent of what it checks.

## 1. The reference model (`firmware/ref/sfref.c`)

The host's knowledge only — submitted commands and received completions; it never reads controller, firmware or
NAND state. Every sector carries {LBA, version} + a hash pattern, so a read-back identifies exactly which version
came back and whether it is intact. Per LBA: last durable version *d*, newest submitted version, newest submitted
DEALLOCATE. Rules (docs/02 §5): after a crash an LBA reads *d* or a version submitted after *d* (zeros only if *d* is
zero or a later DEALLOCATE exists); FLUSH promotes the volatile acknowledgements completed before it was submitted;
a crash demotes unflushed volatile acknowledgements to "may be present"; reads after recovery settle the value
(stability); writes are atomic per logical page (sectors changed by a *later* operation are excluded from that check).
A submitted command becomes a candidate at submission — so a controller process that dies mid-command (forked
campaign) is modelled exactly. Its state can live in shared memory.

## 2. Layers

| Layer | What runs | Checks | Independent of |
|---|---|---|---|
| RTL unit (`tb/tb_sfpr.sv`) | recovery controller alone; the bench is host, queue and firmware | 10 directed tests + a randomized stress test (power faults, controller resets, random back-pressure, premature / error completions, WCE toggling); scoreboard: one completion per command with its own TID, durable-class SUCCESS only after the bench reported DURABLE, volatile SUCCESS only with WCE / no FUA / BUFFERED, FLUSH only after its dependencies, ready/valid stability on both channels; all registers, FSM paths, sticky diagnostics across controller reset, crash-injection unit | the RTL's internal assertion (mutants are run with it compiled out) |
| crash suite (`firmware/tests`) | firmware (sfps) + FTL + simnand, host = harness | 31 named points × sampled k × 3 geometries with repeated recovery; recovery-mount sweep; random (seed, point, k); faults + crashes; metadata corruption; ring-wrap fallback; full device; GC + static wear levelling; WCE contract; no-PLP policy; persistent event log; forked controller processes on a file-backed medium; schema-1 upgrade | the controller (reference model + `sfftl_check` invariants + NAND rule-violation counters) |
| P56 regression | the 27 P56 FTL tests on the modified library | everything P56 verified (incl. its own power-cut sweeps and 12-mutant check) | P58 code |
| co-simulation (`cosim/`) | Verilated recovery controller + unmodified P51 `sfs_cmd_ctrl`, firmware C on the RTL bus, timed NAND behind the inhibit gate, host with queue depth 16 | per episode one of: supply loss with 0…3000 / 20000 cycles of warning (no PLP), named firmware crash point fired by the RTL's crash-injection unit, RTL event crash, brown-out, controller reset, clean shutdown; after each: wait for READY, read **every LBA through the RTL path**, reference model, atomicity; NAND rule violations; clean shutdown → clean mount | everything (end to end) |
| mutation | 16 RTL + 10 firmware deliberate bugs; firmware that acknowledges before programming, with and without the gate | each must be detected (RTL ones by the testbench alone) | — |
| sanitizers | crash suite and P56 suite under ASan + UBSan | memory / UB errors | — |

## 3. Brief → evidence

| Brief §9 item | Evidence |
|---|---|
| persistent NAND backing store | `simnand_open_file` (MAP_SHARED medium); `process_crash`: each controller process recovers the medium left by the previous one, dies at a crash point (`_exit` inside the interrupted operation) |
| fault injection | NAND program / erase / read faults (`faults_and_crashes`, P56 `random_faults`), forced outcomes of interrupted operations, metadata corruption, ECC miscorrection |
| independent logical-data reference | `sfref` (§1); in the co-simulation the host owns it and reads through the RTL |
| random workload generation | every campaign; seeds recorded, every crash replayable |
| repeated recovery | second crash after every recovered crash; `mount_sweep` (cut at every NAND operation of a recovery mount); co-simulation (one recovery per episode, hundreds per run) |
| metadata corruption | `metadata_corruption`, `fallback_after_wrap` |
| full-storage conditions | `full_storage` (100 % of the LBAs in use, overwrite, crashes in GC) |
| GC and wear-levelling interaction | GC / WL crash points in every sweep geometry, `gc_wl_interaction` (aggressive static WL: >1 000 migrations, crashes in WL copies, GC copies and erases) |
| crash at the 8 required points | `point_sweep` per-point table (every point reached, every brief item exercised) |
| restart and verify logical contents | every crash run reads every LBA back and checks it |
