# 01 — Architecture

```
            host (NVMe-style queues, P51 protocol: sfs_cmd_t / sfs_cpl_t, ready/valid)
                 │ cmd                                  ▲ cpl (gated)
                 ▼                                      │
   ┌──────────────────────────── silicaflux_storage_recovery ─────────────────────────────┐
   │ admission control ── slot table (N_SLOTS) ── completion gate ── output register      │
   │   state / PF / RO / TID conflict      phase per slot,       durable / volatile /     │
   │   → hardware completion FIFO          FLUSH dependencies    FLUSH rules, conversion  │
   │ recovery FSM (RESET INIT RECOVER READY READONLY PF_QUIESCE PF_SAFE FAILED SHUTDOWN…)  │
   │ pwr_fail_ni ─► 2-FF sync (POR domain) ─► PF latch ─► nand_inhibit_o, wp_force_o       │
   │ STK_* diagnostics (POR domain, survive rst_n) · counters · crash-injection unit      │
   └───────────┬───────────────────────────────▲────────────────────────── firmware page ┘
               │ cmd (TID := slot)             │ cpl (TID = slot)                   ▲
               ▼                               │                                    │
        sfs_cmd_ctrl (P51, unmodified): validation, tags, firmware queue, tag window │
               │ FWQ / tag window / CPL_POST                                          │
               ▼                                                                      │
   ControlCore firmware ──────────────────────────────────────────────────────────────┘
     sfps_fw  : boot / recovery sequencing, main loop, power-fault handling, GET_LOG
     sfps     : command execution, phase reports (from FTL events), volatile write cache
     FlashMap : FTL (P56) + P58 persistence: hooks, A/B checkpoints, schema 2 event log
               │ HAL (read / program / erase)
               ▼
     NAND controller (refuses new program / erase while nand_inhibit_o) ─► NAND (WP#)
```

## Division of responsibility

| Concern | Hardware (`silicaflux_storage_recovery`) | Firmware |
|---|---|---|
| Admission | closes on power fault / not ready / read-only; completes refused commands itself | — |
| Tracking | one slot per command until complete **and** (volatile writes) durable | reports phases per slot |
| When a SUCCESS may reach the host | **decides** (completion gate) | proposes (posts completions, may pipeline) |
| Power fault | latch, admission closed, unstarted aborted, NAND inhibited, WP# when idle, diagnostics snapshot | stops at page boundary, starts nothing, refuses queued work |
| Recovery | FSM, measures recovery time, keeps diagnostics across controller reset | mounts (roll-forward), logs the event persistently, reports the result |
| Persistence | — | data + spare record, journal, checkpoints (FTL) |

The split is deliberate: the property that matters most — *no durable-class acknowledgement before the data is
durable* — is enforced in hardware on the completion path, so a firmware bug cannot violate it (it can only delay
completions; the gate converts a SUCCESS that never becomes eligible to an error after `GATE_TIMEOUT` or a power
fault).

## Documents

| | |
|---|---|
| [00_AUDIT](00_AUDIT.md) | repository audit and the findings that shaped the design |
| [02_PERSISTENCE_MODEL](02_PERSISTENCE_MODEL.md) | states of a write, acknowledgement classes, the invariant |
| [03_RECOVERY_CONTROLLER](03_RECOVERY_CONTROLLER.md) | the RTL: interfaces, slots, gate, FSM, resets, diagnostics, crash injection |
| [04_FIRMWARE](04_FIRMWARE.md) | PowerSafe firmware layer and main loop |
| [05_PERSISTENT_METADATA](05_PERSISTENT_METADATA.md) | FTL integration: checkpoints, journal, A/B retention, schema 2, recovery scan |
| [06_CRASH_INJECTION](06_CRASH_INJECTION.md) | named crash points and the four execution back-ends |
| [07_POWER_LOSS_POLICY](07_POWER_LOSS_POLICY.md) | what happens on a power fault without PLP; brown-out; reset; shutdown |
| [08_PLP_MODEL](08_PLP_MODEL.md) | capacitor-backed PLP research model and the qualification gate |
| [09_VERIFICATION](09_VERIFICATION.md) | test inventory, reference model, results |
| [10_PERFORMANCE](10_PERFORMANCE.md) | recovery time, latency, journal / metadata overhead, capacity |
| [11_LIMITATIONS](11_LIMITATIONS.md) | what is not claimed |
| [REGISTERS](REGISTERS.md) | generated register map |
