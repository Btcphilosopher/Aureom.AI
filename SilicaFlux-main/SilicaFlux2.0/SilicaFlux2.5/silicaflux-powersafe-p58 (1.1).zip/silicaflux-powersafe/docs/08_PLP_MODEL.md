# 08 — Capacitor-backed PLP: research model and qualification gate

**Status: research only. No physical power-loss protection is claimed.** The delivered controller is built with
`PLP_PRESENT = 0` and reports "no PLP" to the host (IDENTIFY byte 18 = 0, `CAPS[8] = 0`).

## 1. Why PLP is optional here

FlashMap never keeps acknowledged mapping state only in RAM (spare records + journal), so physical PLP is **not
needed for correctness**: every durable acknowledgement is already durable when it is sent. What PLP could buy:

1. finishing the NAND operation in flight (fewer torn pages / partial erases — recovery already copes);
2. **acknowledging writes before they are durable** (the write cache drained on hold-up energy) — lower write
   latency (reports/perf: ~1.7 ms p50 → ~0 for a cached write), which is the only reason to build it.

## 2. The model (`plp/plp_model.py` → `plp/PLP_REPORT.md`)

Hold-up time of a capacitor bank discharged through a buck at constant output power, closed form
t = (C/P)·∫ V·η(V) dV from the ESR drop-out voltage to the charge voltage, minus supervisor latency; required time per
shutdown policy from the FTL's worst case (operation in flight = a block erase, plus the 8-page cache and a journal
page for *drain*, plus a checkpoint for comparison); Monte Carlo over capacitance tolerance, temperature
(−40…85 °C capacitance and ESR derating), ageing (end-of-life capacitance, ESR ×2), shutdown power (1.5…4 W) and
supervisor latency. Three example banks (tantalum-polymer, aluminium-polymer, supercap) and two NAND timing sets
(NANDLab illustrative SLC, assumed TLC-class). **Every electrical input is an assumption.**

Illustrative outcome (see the report for the table and chart): a small aluminium-polymer bank covers *finish* and
SLC-*drain* but not TLC-class *drain* at the cold / end-of-life corner (margin 0.67, 94.8 % Monte-Carlo success); the
corner, not the nominal case, decides; supercaps lose most of their margin in the cold.

## 3. Qualification gate (enforced in RTL)

`PLP_PRESENT = 1` does not elaborate unless `PLP_QUALIFICATION_ID` is non-zero — a deliberate, auditable act that names
the hardware qualification record, which must contain (PLP_REPORT.md §"Qualification"): the hold-up circuit design and
supervisor threshold; **measured** shutdown power at corners; **measured** capacitance / ESR across temperature and after
accelerated ageing; **measured** worst-case drain time on the target firmware and NAND; a hardware power-fail
injection campaign verified with the same reference-model checks; and in-field capacitor health monitoring that falls
back to the no-PLP policy when the bank degrades. The research configuration (`PLP_PRESENT = 1`, id 58 in the test
bench only) is exercised by `tb_sfpr` (`plp_research`) to keep the drain branch of the RTL verified.
