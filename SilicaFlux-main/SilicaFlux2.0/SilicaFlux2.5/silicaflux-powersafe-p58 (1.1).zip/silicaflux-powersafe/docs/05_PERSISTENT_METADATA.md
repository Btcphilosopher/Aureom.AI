# 05 — Persistent metadata (FTL integration)

The FlashMap FTL of Project 56 already provided the core mechanisms; Project 58 keeps their on-media format
compatible (schema 1 is still read) and adds what the PowerSafe brief requires. Exact changes:
`reports/ftl_delta.md` (13 files, ≈ 450 lines added) and `reports/ftl_p56_to_p58.diff`.

## 1. What each requested mechanism is

| Requested | Implementation | New in P58 |
|---|---|---|
| **Versioned checkpoints** | header {magic 'SFMT', kind, schema, generation, index} on every metadata page; checkpoint = body pages + ONE commit written last; schema 2 adds the event area and the previous checkpoint's location | schema 2, schema-1 read compatibility + upgrade |
| **Journal records** | TRIM / ERASE / RETIRE / PRETIRE / MOUNT (3-word records), flushed before an acknowledged DEALLOCATE | — |
| **Generation numbers** | checkpoint generation (+1 per commit), carried by body / commit / journal pages | used for "incomplete newer checkpoint" telemetry |
| **Commit markers** | the commit page (body CRC, list of body page runs, geometry, lifetime counters); a checkpoint without a valid commit does not exist | `PREV_BODY`, `EVT_WORDS` words |
| **Integrity checks** | CRC-32 over data ‖ spare on every page; header / kind / index cross-check; body CRC; L2P range checks; geometry fingerprint | damaged-metadata classification |
| **Recovery scanning** | catalogue the zone, newest loadable checkpoint, journal pass 1, roll-forward of data pages newer than the checkpoint (newest SEQ per LPN wins), TRIM pass, rebuild of RAM structures, fresh ring block + immediate checkpoint after an unclean shutdown | A/B fallback, telemetry, persistent RECOVERY event |

## 2. Protection against torn or partially written metadata

* **Commit-last**: an interrupted checkpoint (torn body page, missing or torn commit) leaves the previous checkpoint in
  force. Crash points `ckpt_before_body`, `ckpt_during_body`, `ckpt_between_body`, `ckpt_before_commit`,
  `ckpt_during_commit`, `ckpt_during_commit_eccpass` (torn commit that the ECC "corrects" into garbage: rejected by
  the CRC), `ckpt_after_commit`.
* **Journal pages** are self-contained (CRC); a torn journal page was never acknowledged (the acknowledgement follows
  the program status).
* **Nothing is ever appended after a possibly torn page**: after an unclean shutdown, mount continues in a fresh ring
  block; open data blocks are closed (their erased tail is not reused). The simulated device counts any re-program of an
  interrupted page as a rule violation; every campaign requires 0.
* **The ring never erases the live region**, now extended by **A/B retention** (§3).
* **Interrupted erases** (ring block, GC victim, erase-on-allocate): `meta_during_erase`, `gc_during_erase`,
  `open_during_erase` — partially erased blocks are recognised by their pages' CRCs.

## 3. A/B checkpoint retention (fix for audit finding F2)

The live region now starts at the first body block of the **previous** committed checkpoint. Every journal page
written since that checkpoint therefore survives until the next checkpoint commits, so if the newest checkpoint
proves unloadable (unreadable commit, body page beyond ECC, misdirected / miscorrected page), mount falls back to the
previous one and rolls forward from it with all TRIM records still present — sound by the same argument as P56
docs/07 §6 with the older checkpoint. The commit records where its predecessor is (`PREV_BODY`), so mount restores the
same protection afterwards. Cost: the ring needs room for three checkpoints instead of two (3·need+3 blocks instead of
2·need+3): **+1 block** on both measured devices (1.9 % of a 64-block device, 0.4 % of a 256-block device), no
measurable change in metadata write amplification or recovery time (reports/perf/PERF.md).

Evidence: `fallback_after_wrap` (newest commit destroyed after the ring wrapped: P56 16 / 300 unmountable, P58 0 / 300),
`metadata_corruption` (unreadable commit, body beyond ECC, miscorrected commit: all recovered; every checkpoint
destroyed: mount refuses with `ENOFS` — it never guesses), mutation "A/B retention off" detected.

## 4. Damaged metadata vs crash tears

A crash tear is always the **last** page programmed in its block (nothing is appended after it). A damaged page that
is followed by a valid metadata page in the same block is therefore media damage, not a crash: mount counts it
(`last_mount_meta_damaged`), logs a `META_DAMAGE` event and adds it to the persistent counter. If it was a journal page,
its records cannot be reconstructed (journal pages are not mirrored — docs/11): the device reports it instead of
pretending.

## 5. Persistent event log and recovery telemetry (schema 2)

The checkpoint body ends with an event area: 8 counters {events, unsafe shutdowns, recoveries, fallback mounts,
damaged metadata, torn pages discarded, power faults reported by the controller} and a ring of the 8 most recent
events (FORMAT, RECOVERY, POWER_FAULT, BROWNOUT, READONLY, UPGRADE, META_DAMAGE; 8 words each: type, SEQ, mount count,
5 data words). It is covered by the body CRC and the commit, so it is exactly as crash-safe as the mapping. Every
unclean mount appends a RECOVERY event (pages scanned / replayed, torn pages, fallback depth, damaged pages, mount NAND
reads, controller diagnostics) **before** it writes the checkpoint it always writes — the record of an unclean
shutdown cannot be lost by the next crash. Exposed through `sfftl_event_get` / `sfftl_persist` and GET_LOG 0x58.

## 6. Event hook

`sfftl_set_hook()` / `sfftl_opts_t.hook`: synchronous callback at PROG_BEGIN / PROG_END (with the page class: host,
GC relocation, static wear-levelling copy, checkpoint body, commit, journal), MAP_COMMIT, UNMAP, ERASE_BEGIN / END
(cause: erase-on-allocate, GC, ring, format), GC_VICTIM, CKPT_BEGIN / BODY / COMMIT / END, JOURNAL_BEGIN / END,
MOUNT_BEGIN / CKPT / REPLAY / END. Used for phase reporting (docs/04) and named crash points (docs/06); one pointer
test when unused.

## 7. Compatibility

* Schema-1 media (written by P56) are mounted, rolled forward and upgraded by the next checkpoint (UPGRADE event) — if
  their metadata zone has the P58 size; a P56 medium with the automatic 5-block zone is refused with `SFFTL_EGEOM` and
  left untouched (test `upgrade_v1`, medium written by the unmodified P56 library in `firmware/tools/`).
* P56 firmware cannot read schema-2 media (no downgrade).
* The full P56 regression suite (27 tests, 4 932 checks) passes on the modified library.
