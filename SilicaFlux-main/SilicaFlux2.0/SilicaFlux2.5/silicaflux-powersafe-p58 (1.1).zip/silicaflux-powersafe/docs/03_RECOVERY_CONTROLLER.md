# 03 — Recovery controller: `silicaflux_storage_recovery.sv`

Primary RTL: [`rtl/silicaflux_storage_recovery.sv`](../rtl/silicaflux_storage_recovery.sv) (+ `sfpr_crash_inj.sv`,
generated `sfpr_regs_pkg.sv`). Synthesizable SystemVerilog, lint-clean (Verilator `-Wall`) in every configuration,
elaborates on Icarus 12 and Yosys 0.33 (0 latches).

## 1. Parameters

| Parameter | Default | Meaning |
|---|---|---|
| `N_SLOTS` | 16 | tracked commands (2…32): host-outstanding + acknowledged-volatile-not-durable |
| `HWQ_DEPTH` | 4 | hardware completion FIFO (refused commands) |
| `PLP_PRESENT` | **0** | physical power-loss protection. 1 = research drain policy; **elaboration fails unless `PLP_QUALIFICATION_ID ≠ 0`** |
| `PLP_QUALIFICATION_ID` | 0 | id of the hardware qualification record (docs/08); reported in `CAPS[31:16]` |
| `CRASH_INJ_EN` | 0 | crash-injection unit (test builds) |

## 2. Interfaces

* host side: `cmd_in` / `cpl_out` — P51 `sfs_cmd_t` / `sfs_cpl_t`, ready/valid (P51 protocol rules: payload stable
  while valid, no withdrawal — both are monitored by the testbench).
* command-queue side: `cmd_out` / `cpl_in` to the unmodified P51 `sfs_cmd_ctrl`; `cpl_in_ready` = 1.
* firmware page: `rb_sel/rb_we/rb_addr[11:0]/rb_wdata/rb_rdata/rb_err` (P51 page convention), map in
  [REGISTERS.md](REGISTERS.md) (generated from `scripts/gen_regs.py`, together with the SV package and C header).
* power / media: `pwr_fail_ni` (asynchronous, active low), `nand_busy_i`, `nand_inhibit_o` (the NAND controller must
  refuse new program/erase), `wp_force_o` (WP# on every channel), `quiesce_o` (to `sfs_cmd_ctrl.plp_quiesce`).
* status: `rdy_o ro_o fatal_o pf_active_o shst_o[1:0] irq_o`; crash injection `ci_crash_o ci_pf_o ci_warm_o`.
* resets: `por_n` (supply applied: everything, including `STK_*`), `rst_n` (controller reset: all but `STK_*` and the
  power-fail synchroniser). Asynchronous assertion, synchronous release by the SoC reset tree (as in P51).

## 3. Admission control

| Condition (priority order) | Response, by hardware, no firmware involvement |
|---|---|
| power fault latched | `ABORT_PWR_LOSS` / `QUIESCED` |
| state FAILED | `INTERNAL_ERR` / `NOT_READY` |
| READONLY and WRITE / DEALLOCATE | `ACCESS_DENIED` / `NAND_WP` |
| READY / READONLY and the host TID is still outstanding | `CID_CONFLICT` |
| any other state but READY / READONLY (RESET, INIT, RECOVER, SHUTDOWN, SHUT_DONE) | `ABORT_RESET` / `NOT_READY` |
| otherwise | slot allocated, forwarded through a register stage with `TID := slot` |

Refusals go through a FIFO without needing a slot, so a host keeps receiving fast aborts even when every slot is in
use. A forwarded command never leaves the register stage before the queue accepts it (no withdrawal).

**TID remapping.** The downstream TID is the slot index, unique for the slot's whole life — including the time an
acknowledged-volatile write waits to become durable after the host already received its completion and may reuse its
TID. Phase reports and completions are therefore unambiguous.

## 4. Slot table and phases

Per slot: valid, class (READ / WRITE / TRIM / FLUSH / OTHER), FUA, early-ack permission captured at admission
(`WCE | PLP_PRESENT`), host TID, phase (3 bits), acked, vol (acknowledged before durable), hwab (aborted by hardware),
held completion {status, error, result0, result1}, dn (queue completion received), FLUSH dependency row
(`N_SLOTS` bits) + dependency-failed flag, admission / hold timestamps. Readable through the `SLOT[n]` window.

`PHASE` writes: `{slot, phase}` → `PHASE_RESULT`: `OK`, `BAD_SLOT`, `REGRESS` (lower phase or a hardware-only phase),
`ABORTED` (hardware already aborted it), `QUIESCED` (a command still `ACCEPTED` cannot be started under a power fault).
Firmware claims a command with `STARTED` and must check the result.

A slot is freed when it is acknowledged **and** (not volatile **or** DURABLE) **and** (not hardware-aborted **or** the
queue's completion for it arrived), or when firmware `RETIRE`s an acknowledged-volatile write that can no longer be
made durable.

## 5. Completion gate

A completion from the queue is stored in its slot and released by a round-robin selector into a registered output
stage (alternating with the refusal FIFO). A slot is *eligible* when it holds a completion and either the status is an
error, or the SUCCESS is allowed:

| Class | SUCCESS allowed when |
|---|---|
| WRITE, FUA or no early-ack permission | phase DURABLE |
| WRITE, early-ack permitted, no FUA | DURABLE, or BUFFERED and no power fault (without PLP) → **volatile acknowledgement** |
| DEALLOCATE | DURABLE |
| FLUSH | DURABLE and its dependency row empty (every write acknowledged-volatile before the FLUSH was admitted has become DURABLE); a retired dependency turns the SUCCESS into `MEDIA_WRITE` |
| READ / other | always |

Held SUCCESS completions that are not eligible are converted when a power fault is latched (no PLP: `ABORT_PWR_LOSS`)
or after `GATE_TIMEOUT` cycles (`INTERNAL_ERR`, `ERR_STATUS.GATE_TIMEOUT`). A completion is converted only while it
is still in its slot — once presented on `cpl_out` it never changes (ready/valid rule). Simulation assertion (outside
`SYNTHESIS`): a durable-class SUCCESS is never loaded for a slot that is not DURABLE, and a FLUSH never with pending
dependencies. Cost: every completion takes 2 cycles through store + output register.

## 6. Recovery FSM

```
 por/rst ─► RESET ─► INIT ──BOOT_ACK──► RECOVER ──RECOV_DONE(OK)──► READY ◄────────────┐
                                          │  ├─RECOV_DONE(RO)──► READONLY             │ fast resume
                                          │  └─RECOV_DONE(FAIL) / RECOV_TIMEOUT ─► FAILED ─RECOVER_RETRY─┐
                                          ▲                                           │                  │
                                          └──────────────────────── PF_RESUME (full) ─┤◄─────────────────┘
 any state ──power fault (pin, FORCE_PF, CI)──► PF_QUIESCE ──no firmware-owned command,──► PF_SAFE ─(supply good
                                                               NAND idle (+ vol drained if PLP)       ≥ PF_RESTORE_CYCLES,
 READY / READONLY ──shn_req / SHUTDOWN_REQ──► SHUTDOWN ──SHUTDOWN_DONE (no slot)──► SHUT_DONE           PF_RESUME)
```

* Fast resume (back to READY without a remount) only if `CFG.FAST_RESUME_EN` and **no NAND operation was in flight
  when the fault was latched** (otherwise its outcome is unknown: full recovery). Default: full recovery.
* Illegal control commands are ignored and flagged (`ERR_STATUS.SEQ`); a fault during INIT / RECOVER / SHUTDOWN is
  flagged `PF_IN_RECOVERY` (recovery simply restarts later).
* `RECOV_CYC_LAST / MAX` measure the RECOVER state — the hardware-measured recovery time.

## 7. Media protection

`nand_inhibit_o` = power fault latched (no PLP), or SHUT_DONE (or, research PLP: PF_SAFE). The NAND controller must
refuse to *start* program / erase while it is high; reads continue. `wp_force_o` is set once inhibit is active **and
no NAND operation is in flight** (`CFG.AUTO_WP`), and cleared when inhibit drops: WP# is never asserted in the middle
of an operation (mutation-tested).

## 8. Diagnostics preserved across controller resets

`STK_*` registers are in the `por_n` domain. On a power fault they capture: state, host-outstanding / firmware-active
/ volatile-at-risk counts, NAND busy, cycle timestamp, `COMMIT_SEQ_LO`; then hardware aborts and gate conversions of
that episode and the fault→PF_SAFE time. On a controller reset (detected when the controller domain leaves RESET while
it had been alive), they capture the state before the reset and add its volatile-at-risk count to `STK_VOL_LOST`;
`STK_LAST_CAUSE` = POR / WARM / PF_RESUME / RETRY. They are volatile: after a real loss of supply they are gone — the
firmware copies them into the FTL's persistent event log at the next boot before clearing them (`CTRL.CLR_STICKY`),
and the FTL records every unclean shutdown itself regardless (docs/05).

## 9. Error / status / telemetry

`STATE` (FSM, pin, latch, inhibit, WP, NAND busy, restored, fast-resume-ok, SHST, slots in use, volatile slots),
`ERR_STATUS` (W1C) + `ERR_INFO` (first error: bit, slot, state), `IRQ_STATUS` / `IRQ_EN`, counters (admissions,
power-fault aborts, state refusals, conflicts, completions, durable / volatile acknowledgements, gate holds and
conversions, dropped queue completions, volatile writes durable / failed, durable-completion latency sum / max,
volatile max, gate hold max, recovery cycles, fault→safe cycles, phase reports), `COMMIT_SEQ` (persistent commit
status: highest FTL sequence number known durable, published by firmware) and `DURABLE_CNT`.

## 10. Crash-injection unit (`CRASH_INJ_EN = 1`)

Counts one event — every cycle, admission, accepted phase report of a given phase, host completion, NAND operation
start, firmware `CI_MARK` with a given id, power-fault latch — and on the N-th (+ delay) fires: `CRASH` (bench removes
the supply), `PF` (internal warning), `WARM` (bench applies a controller reset) or `CRASH_PF`. Firmware crash points
reach hardware through `CI_MARK` (docs/06). With `CRASH_INJ_EN = 0` the unit is constant logic and its registers read 0.

## 11. Cost

Yosys 0.33 generic synthesis (reports/synth.md): production configuration (16 slots, no crash injection) ≈ 33 k generic
cells, ≈ 4.9 k flip-flops, 0 latches; the slot table's timestamps and stored result words dominate.
