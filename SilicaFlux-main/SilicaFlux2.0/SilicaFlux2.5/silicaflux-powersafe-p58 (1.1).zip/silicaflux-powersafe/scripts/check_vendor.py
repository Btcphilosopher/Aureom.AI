#!/usr/bin/env python3
"""Verify that third_party/ files are byte-identical to the repository archives.

usage: python3 scripts/check_vendor.py <path to the Aureom.AI checkout>
Reads each source archive directly (zipfile) and compares SHA-256 digests.
The P56 FTL under firmware/silicaflux_ftl/ is NOT vendored unmodified: it is the
P56 library with the Project 58 persistence changes; scripts/ftl_delta.py
reports exactly which files differ from the archive.
"""
import hashlib, os, sys, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ARCH = "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-storagecore-p51.zip"
PREFIX = "silicaflux-storagecore/"
# every file under third_party/silicaflux-storagecore-p51/ (RTL subset + ControlCore runtime subset)
_TP = os.path.join(ROOT, "third_party", "silicaflux-storagecore-p51")
FILES = sorted(os.path.relpath(os.path.join(d, f), _TP) for d, _, fs in os.walk(_TP) for f in fs if "__pycache__" not in d)

def sha(b): return hashlib.sha256(b).hexdigest()

def main():
    if len(sys.argv) < 2:
        print(__doc__); return 2
    repo = sys.argv[1]
    z = zipfile.ZipFile(os.path.join(repo, ARCH))
    ok = 0
    lines = []
    for f in FILES:
        a = z.read(PREFIX + f)
        b = open(os.path.join(ROOT, "third_party", "silicaflux-storagecore-p51", f), "rb").read()
        same = sha(a) == sha(b)
        ok += same
        lines.append(f"{'OK  ' if same else 'DIFF'} {sha(b)}  silicaflux-storagecore-p51/{f}")
    print("\n".join(lines))
    print(f"{ok} / {len(FILES)} vendored files byte-identical to {ARCH}")
    return 0 if ok == len(FILES) else 1

if __name__ == "__main__":
    sys.exit(main())
