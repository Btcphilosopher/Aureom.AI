#!/usr/bin/env python3
"""Mutation testing of SilicaFlux PowerSafe (Project 58).

Plants one deliberate bug at a time in a COPY of the sources and checks that
the verification catches it.
  RTL mutants        tb/tb_sfpr.sv on Icarus 12 (random test 1500 iterations,
                     2 seeds), compiled with SYNTHESIS defined so the RTL's own
                     gate assertion is OFF: the testbench scoreboard has to
                     catch every mutant by itself.
  firmware mutants   firmware/tests sfps_tests (quick subset of tests)
  co-simulation      defence-in-depth experiment: firmware that posts SUCCESS
                     before a write has executed, (a) with the real recovery
                     controller -> must stay correct (the gate holds the
                     completion until DURABLE), (b) with the gate disabled ->
                     the reference model must detect lost acknowledged writes.
Writes reports/mutation.md (+ .json).
usage: python3 scripts/mutation.py [--rtl] [--fw] [--cosim]   (default: all)
"""
import json, os, re, shutil, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = os.path.join(ROOT, "build", "mut")
os.makedirs(B, exist_ok=True)
SEL = [a for a in sys.argv[1:] if a.startswith("--")] or ["--rtl", "--fw", "--cosim"]
RTL = "rtl/silicaflux_storage_recovery.sv"

def sh(cmd, cwd=ROOT, timeout=1800):
    try:
        p = subprocess.run(cmd, shell=True, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
        return p.returncode, p.stdout
    except subprocess.TimeoutExpired as e:
        return 124, (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or "")

def mutate(src, a, b):
    s = open(src).read()
    n = s.count(a)
    if n != 1:
        raise SystemExit(f"mutation anchor found {n} times in {src}: {a[:60]!r}")
    return s.replace(a, b)

# ---------------------------------------------------------------- RTL
RTL_MUTANTS = [
    ("volatile ack before BUFFERED", "s_phase[i] >= SFPR_PH_BUFFERED && !pf_block_vol", "s_phase[i] >= SFPR_PH_ACCEPTED && !pf_block_vol"),
    ("FUA flag dropped at admission", "s_fua[i]   <= cmd_in.flags[SFS_FLAG_FUA];", "s_fua[i]   <= 1'b0;"),
    ("FLUSH ignores its dependencies", "g_dep[i]   = s_cls[i] != SFPR_CLS_FLUSH || s_dep[i] == '0;", "g_dep[i]   = 1'b1;"),
    ("durable-class SUCCESS not gated", "g_ok[i]    = (g_need[i] ? g_dur[i] :", "g_ok[i]    = (g_need[i] ? 1'b1 :"),
    ("no hardware abort of unstarted commands", "sweep[i] = pf_lat && cfg_hwab &&", "sweep[i] = 1'b0 && pf_lat && cfg_hwab &&"),
    ("volatile acks granted under a power fault", "wire pf_block_vol = pf_lat && !PLP_PRESENT;", "wire pf_block_vol = 1'b0;"),
    ("held SUCCESS not converted at a power fault", "conv_pf[i] = waiting[i] && pf_block_vol;", "conv_pf[i] = 1'b0;"),
    ("phase regression accepted", "else if (ph_val < s_phase[ph_slot])                   ph_res = SFPR_PR_REGRESS;",
     "else if (1'b0)                   ph_res = SFPR_PR_REGRESS;"),
    ("WP# forced while a NAND op is in flight", "if (!nand_busy_i && (cfg_autowp", "if ((cfg_autowp"),
    ("sticky diagnostics cleared by controller reset", "always_ff @(posedge clk or negedge por_n) begin\n    if (!por_n) begin\n      k_flags",
     "always_ff @(posedge clk or negedge crst_n) begin\n    if (!crst_n) begin\n      k_flags"),
    ("host TID forwarded instead of the slot", "fwd_next.tid = 16'(free_slot);", "fwd_next.tid = cmd_in.tid;"),
    ("volatile entry freed at acknowledgement", "(!s_vol[i] || s_phase[i] == SFPR_PH_DURABLE)", "(1'b1)"),
    ("READONLY admits writes", "if (st == 4'(SFPR_STATE_READONLY) && (in_cls == SFPR_CLS_WRITE || in_cls == SFPR_CLS_TRIM)) begin",
     "if (1'b0) begin"),
    ("admission open during a power fault", "    if (pf_lat) begin\n      rej_st = 7'(SFS_ST_ABORT_PWR_LOSS);",
     "    if (1'b0) begin\n      rej_st = 7'(SFS_ST_ABORT_PWR_LOSS);"),
    ("NAND inhibit never asserted", "assign nand_inhibit_o = (!PLP_PRESENT && pf_lat) ||", "assign nand_inhibit_o = 1'b0 ||"),
    ("host TID conflict not detected", "if (m_out[i] && s_tid[i] == cmd_in.tid) conflict = 1'b1;", "if (1'b0) conflict = 1'b1;"),
]

def rtl_files(rtl_path):
    fl = [l.strip() for l in open(os.path.join(ROOT, "rtl/files.f")) if l.strip() and not l.startswith("//")]
    return [rtl_path if f == RTL else f for f in fl]

def run_rtl(tag, rtl_path):
    vvp = os.path.join(B, f"{tag}.vvp")
    rc, out = sh(f"iverilog -g2012 -DSYNTHESIS -Ithird_party/silicaflux-storagecore-p51/rtl/generated -s tb_sfpr -o {vvp} "
                 f"{' '.join(rtl_files(rtl_path))} tb/tb_sfpr.sv")
    if rc:
        return "build failed", out[-500:]
    res = []
    for seed in (1, 2):
        rc, out = sh(f"timeout 600 vvp -n {vvp} +SEED={seed} +ITER=1500")
        m = re.search(r"TB RESULT: (\d+) tests, (\d+) failed, (\d+) checks, (\d+) failed checks", out)
        res.append((m.group(2), m.group(4)) if m else ("?", "timeout/crash"))
        if m and int(m.group(4)) > 0:
            first = re.search(r"FAIL \[(\w+)\] (.*)", out)
            return "detected", f"seed {seed}: {m.group(4)} failed checks; first: [{first.group(1)}] {first.group(2)[:90]}" if first else ""
        if not m:
            return "detected", f"seed {seed}: simulation did not finish ({out[-120:].strip()})"
    return "SURVIVED", str(res)

rows = []
if "--rtl" in SEL:
    st, info = run_rtl("baseline", RTL)
    rows.append(dict(kind="RTL", name="baseline (no mutation)", result="clean" if st == "SURVIVED" else "BASELINE FAILS", info=info))
    for name, a, b in RTL_MUTANTS:
        p = os.path.join(B, "rtl_mut.sv")
        open(p, "w").write(mutate(os.path.join(ROOT, RTL), a, b))
        t0 = time.time()
        st, info = run_rtl("rtl_mut", p)
        rows.append(dict(kind="RTL", name=name, result=st, info=info))
        print(f"RTL  {st:9s} {name}  ({time.time()-t0:.0f}s) {info}", flush=True)

# ---------------------------------------------------------------- firmware
FW_MUTANTS = [
    ("A/B checkpoint retention off (P56 behaviour)", "silicaflux_ftl/src/ftl_meta.c",
     "f->mz_live_start = (f->mz_cur_start != SFFTL_NONE) ? f->mz_cur_start : new_start;", "f->mz_live_start = new_start;",
     "fallback_after_wrap"),
    ("TRIM acknowledged before its journal page", "silicaflux_ftl/src/ftl_io.c",
     "      rc = journal_flush(f);\n      if (rc < 0) return rc;\n      for (uint64_t l = first; l < last; l++) map_unmap",
     "      rc = SFFTL_OK;\n      if (rc < 0) return rc;\n      for (uint64_t l = first; l < last; l++) map_unmap", "point_sweep"),
    ("roll-forward without the data CRC", "silicaflux_ftl/src/ftl_mount.c",
     "        r = oob_parse(f, spare, f->buf_host, &o);\n        if (r >= 0) break;",
     "        r = oob_parse(f, spare, NULL, &o);\n        if (r >= 0) break;", "point_sweep"),
    ("sequence numbers not resumed above the medium", "silicaflux_ftl/src/ftl_mount.c",
     "  if (maxseq + 1u > ns) ns = maxseq + 1u;\n  if (dmax + 1u > ns) ns = dmax + 1u;", "", "point_sweep"),
    ("FLUSH completes without destaging the cache", "powersafe/src/sfps.c",
     "        rc = sfps_flush_cache(p);\n        if (rc == SFFTL_OK) rc = sfftl_flush(f);",
     "        rc = SFFTL_OK;\n        if (rc == SFFTL_OK) rc = sfftl_flush(f);", "wce_contract point_sweep"),
    ("FUA write goes to the volatile cache", "powersafe/src/sfps.c",
     "if (p->wce && !c->fua && p->wc_n > 0u) {", "if (p->wce && p->wc_n > 0u) {", "point_sweep"),
    ("write-through does not destage older cached data first", "powersafe/src/sfps.c",
     "  int rc = wc_flush_range(p, first, last);         /* older cached data reaches the FTL first */",
     "  int rc = (first > last) ? wc_flush_range(p, first, last) : SFFTL_OK;", "point_sweep"),
    ("new work accepted after the power-fail warning", "powersafe/src/sfps.c",
     "f->ps_warned || f->ps_state != SFFTL_PS_RUNNING ||", "0 ||", "no_plp_policy"),
    ("event log not loaded at mount", "silicaflux_ftl/src/ftl_mount.c",
     "else if (ej < SFFTL_EVT_HDR_WORDS) f->evt_hdr[ej] = v;", "else if (ej < SFFTL_EVT_HDR_WORDS) (void)v;", "event_log"),
    ("damaged-metadata detection off", "silicaflux_ftl/src/ftl_mount.c", "      damaged += pend_bad;", "      damaged += 0u * pend_bad;",
     "metadata_corruption"),
]
FWD = os.path.join(B, "fw")

def run_fw(tests):
    rc, out = sh("make build/sfps_tests", cwd=FWD, timeout=600)
    if rc:
        return "build failed", out[-400:]
    for t in tests.split():
        rc, out = sh(f"TMPDIR={B} timeout 900 ./build/sfps_tests --quick --test {t}", cwd=FWD)
        if rc:
            first = re.search(r"FAIL \[(\w+)\] (.*)", out)
            return "detected", f"{t}: " + (first.group(2)[:110] if first else out[-120:].strip())
    return "SURVIVED", tests

if "--fw" in SEL:
    if os.path.exists(FWD):
        shutil.rmtree(FWD)
    shutil.copytree(os.path.join(ROOT, "firmware"), FWD, ignore=shutil.ignore_patterns("build", "*.bin"))
    st, info = run_fw("point_sweep wce_contract no_plp_policy event_log metadata_corruption fallback_after_wrap")
    rows.append(dict(kind="firmware", name="baseline (no mutation)", result="clean" if st == "SURVIVED" else "BASELINE FAILS", info=info))
    for name, f, a, b, tests in FW_MUTANTS:
        path = os.path.join(FWD, f)
        orig = open(path).read()
        text = mutate(path, a, b)                       # read before the file is reopened for writing
        open(path, "w").write(text)
        t0 = time.time()
        st, info = run_fw(tests)
        open(path, "w").write(orig)
        rows.append(dict(kind="firmware", name=name, result=st, info=info))
        print(f"FW   {st:9s} {name}  ({time.time()-t0:.0f}s) {info}", flush=True)

# ---------------------------------------------------------------- co-simulation: defence in depth
def build_cosim(tag, rtl_text=None, early_post=False, synth=False):
    d = os.path.join(B, "cosim_" + tag)
    if os.path.exists(d):
        shutil.rmtree(d)
    os.makedirs(d)
    fwsrc = os.path.join(d, "fw")
    shutil.copytree(os.path.join(ROOT, "firmware"), fwsrc, ignore=shutil.ignore_patterns("build", "tools", "*.bin"))
    if early_post:
        p = os.path.join(fwsrc, "powersafe/src/sfps_fw.c")
        s = mutate(p, "    rwr(w, SFPR_PHASE, (SFPR_PH_BUFFERED << 8) | ((uint32_t)c.slot & 0xFFu));\n  }\n  sfps_exec(&w->ps, &c, &cpl);",
                   "    rwr(w, SFPR_PHASE, (SFPR_PH_BUFFERED << 8) | ((uint32_t)c.slot & 0xFFu));\n"
                   "    post(w, tag, SFPS_ST_SUCCESS, 0, c.nlb);          /* MUTATION: acknowledge before programming */\n"
                   "    sfps_exec(&w->ps, &c, &cpl);\n    return 1;\n  }\n  sfps_exec(&w->ps, &c, &cpl);")
        s = mutate_text(s, "  rwr(w, SFPR_CFG, cfg);\n}", "  rwr(w, SFPR_CFG, cfg);\n  rwr(w, SFPR_GATE_TIMEOUT, 400000u);\n}")
        open(p, "w").write(s)
    rtl = os.path.join(d, "silicaflux_storage_recovery.sv")
    open(rtl, "w").write(rtl_text if rtl_text else open(os.path.join(ROOT, RTL)).read())
    mk = open(os.path.join(ROOT, "cosim/Makefile")).read()
    mk = mk.replace("ROOT    := $(abspath ..)", f"ROOT    := {ROOT}").replace("FW      := $(ROOT)/firmware", f"FW      := {fwsrc}")
    mk = mk.replace("BUILD   := $(ROOT)/build/cosim", f"BUILD   := {d}/build")
    mk = mk.replace("$(ROOT)/rtl/silicaflux_storage_recovery.sv", rtl)
    if synth:
        mk = mk.replace("verilator --cc --exe --build -j 4", "verilator --cc --exe --build -j 4 -DSYNTHESIS")
    open(os.path.join(d, "Makefile"), "w").write(mk)
    rc, out = sh(f"make -f {d}/Makefile all", cwd=os.path.join(ROOT, "cosim"), timeout=3000)
    return os.path.join(d, "build", "Vtb_cosim_top") if rc == 0 else None

def mutate_text(s, a, b):
    if s.count(a) != 1:
        raise SystemExit(f"anchor {a[:50]!r}")
    return s.replace(a, b)

if "--cosim" in SEL:
    gate_off = mutate(os.path.join(ROOT, RTL), "g_ok[i]    = (g_need[i] ? g_dur[i] :", "g_ok[i]    = (g_need[i] ? 1'b1 :")
    for tag, rtl_text, early, synth, expect in [
        ("baseline", None, False, False, "PASS"),
        ("early_post_with_gate", None, True, False, "PASS"),
        ("early_post_gate_disabled", gate_off, True, True, "FAIL"),
    ]:
        t0 = time.time()
        exe = build_cosim(tag, rtl_text, early, synth)
        if not exe:
            rows.append(dict(kind="co-sim", name=tag, result="build failed", info=""))
            continue
        res, info = [], []
        for seed in (11, 12, 13):
            rc, out = sh(f"timeout 1800 {exe} 80 {seed} 0 1500")
            m = re.search(r"COSIM RESULT: (\w+)(.*)", out)
            r = m.group(1) if m else "CRASH"
            res.append(r)
            if r != "PASS":
                info.append(f"seed {seed}: {(m.group(2) if m else out[-100:]).strip()[:110]}")
            g = re.search(r"gate held (\d+) SUCCESS completions \(all resets\), converted (\d+)", out)
            if g:
                info.append(f"seed {seed}: gate held {g.group(1)}, converted {g.group(2)}")
        ok = all(r == "PASS" for r in res) if expect == "PASS" else any(r != "PASS" for r in res)
        rows.append(dict(kind="co-sim", name=tag, result=("as expected: " + expect) if ok else "UNEXPECTED: " + "/".join(res),
                         info="; ".join(info)[:300]))
        print(f"COSIM {tag}: {res} ({time.time()-t0:.0f}s)", flush=True)

# ---------------------------------------------------------------- report
old = []
jp = os.path.join(ROOT, "reports", "mutation.json")
if os.path.exists(jp) and SEL != ["--rtl", "--fw", "--cosim"]:
    kmap = {"--rtl": "RTL", "--fw": "firmware", "--cosim": "co-sim"}
    old = [r for r in json.load(open(jp)) if r["kind"] not in {kmap[k] for k in SEL}]
rows = old + rows
json.dump(rows, open(jp, "w"), indent=1)
L = ["# Mutation testing", "", "Generated by `scripts/mutation.py`. One deliberate bug at a time, in a copy of the sources.", "",
     "* **RTL**: unit testbench `tb/tb_sfpr.sv` on Icarus 12 (all tests, random stress 1 500 iterations, 2 seeds), compiled "
     "with `SYNTHESIS` defined so the RTL's internal gate assertion is off — every detection below comes from the "
     "testbench's own scoreboard / directed checks.",
     "* **Firmware**: `sfps_tests --quick` on the listed tests.",
     "* **Co-simulation (defence in depth)**: firmware mutated to post SUCCESS for a WRITE *before* executing it. With the "
     "real recovery controller the completion gate holds it until the firmware reports DURABLE (no data lost); with the "
     "gate disabled the reference model detects acknowledged writes lost at crashes.", ""]
for kind in ("RTL", "firmware", "co-sim"):
    rs = [r for r in rows if r["kind"] == kind]
    if not rs:
        continue
    mut = [r for r in rs if not r["name"].startswith("baseline")]
    det = sum(1 for r in mut if r["result"] == "detected" or r["result"].startswith("as expected"))
    L += [f"## {kind}: {det} / {len(mut)} {'mutants detected' if kind != 'co-sim' else 'cases as expected'}", "",
          "| Mutation | Result | Evidence |", "|---|---|---|"]
    for r in rs:
        L.append(f"| {r['name']} | {r['result']} | {r['info'].replace('|', '/')} |")
    L.append("")
open(os.path.join(ROOT, "reports", "mutation.md"), "w").write("\n".join(L) + "\n")
print("\n".join(L))
