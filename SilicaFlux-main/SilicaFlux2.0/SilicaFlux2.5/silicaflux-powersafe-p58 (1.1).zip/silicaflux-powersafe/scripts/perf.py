#!/usr/bin/env python3
"""Performance measurements of SilicaFlux PowerSafe (Project 58).

Builds and runs:
  firmware/tests/bench_ftl.c  twice: against the UNMODIFIED Project 56 FTL
                              (firmware/tools/p56_original) and the Project 58 FTL
  firmware/tests/bench_ps.c   command completion latency (Project 58 firmware)
and collects the co-simulation's hardware-measured recovery cycles
(reports/cosim/*.log).  Writes reports/perf/{*.csv, PERF.md, *.svg}.
All device times are MODELLED with NANDLab's illustrative SLC values.
usage: python3 scripts/perf.py [samples]
"""
import csv, glob, io, os, re, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FW = os.path.join(ROOT, "firmware")
OUT = os.path.join(ROOT, "reports", "perf")
os.makedirs(OUT, exist_ok=True)
os.makedirs(os.path.join(FW, "build"), exist_ok=True)
SAMPLES = sys.argv[1] if len(sys.argv) > 1 else "60"

def sh(cmd):
    p = subprocess.run(cmd, shell=True, cwd=FW, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if p.returncode:
        print(p.stdout); sys.exit(p.returncode)
    return p.stdout

SIM = "silicaflux_ftl/hal/sim"
sh(f"gcc -std=c11 -O2 -DLIBNAME='\"p58\"' -Isilicaflux_ftl/include -Isilicaflux_ftl/src -I{SIM} silicaflux_ftl/src/*.c "
   f"{SIM}/simnand.c tests/bench_ftl.c -o build/bench_ftl_p58")
sh(f"gcc -std=c11 -O2 -DLIBNAME='\"p56\"' -Itools/p56_original/include -Itools/p56_original/src -I{SIM} "
   f"tools/p56_original/src/*.c {SIM}/simnand.c tests/bench_ftl.c -o build/bench_ftl_p56")
sh(f"gcc -std=c11 -O2 -Isilicaflux_ftl/include -Isilicaflux_ftl/src -I{SIM} -Ipowersafe/include silicaflux_ftl/src/*.c "
   f"{SIM}/simnand.c powersafe/src/sfps.c tests/bench_ps.c -o build/bench_ps")
raw = sh(f"./build/bench_ftl_p56 {SAMPLES}") + sh(f"./build/bench_ftl_p58 {SAMPLES}") + sh(f"./build/bench_ps {OUT}/latency_cdf.csv")
open(os.path.join(OUT, "bench_raw.txt"), "w").write(raw)

wa, rec, lat, pss = [], [], [], []
for line in raw.splitlines():
    if not line.startswith("csv,"):
        continue
    f = line.split(",")[1:]
    if f[0] == "wa":
        wa.append(dict(lib=f[1], geo=f[2], interval=int(f[3]), host=int(f[4]), reloc=int(f[5]), meta=int(f[6]),
                       ckpts=int(f[7]), jpages=int(f[8]), ckpages=int(f[9]), meta_wa=float(f[10]), wa=float(f[11]),
                       ck_per_1000=float(f[12]), meta_blocks=int(f[13]), ckpt_pages=int(f[14]), nlba=int(f[15])))
    elif f[0] == "recovery":
        rec.append(dict(lib=f[1], geo=f[2], interval=int(f[3]), n=int(f[4]), mean=float(f[5]), p50=float(f[6]),
                        p99=float(f[7]), max=float(f[8]), reads=float(f[9]), clean=float(f[10]), clean_reads=int(f[11])))
    elif f[0] == "latency":
        lat.append(dict(mode=f[1], what=f[2], n=int(f[3]), mean=float(f[4]), p50=float(f[5]), p99=float(f[6]),
                        p999=float(f[7]), max=float(f[8])))
    elif f[0] == "psstats":
        pss.append(dict(mode=f[1], destages=int(f[2]), evictions=int(f[3]), flush_destages=int(f[4]), jpages=int(f[5]),
                        verify_reads=int(f[6]), ckpts=int(f[7])))

def wcsv(name, rows):
    if not rows: return
    with open(os.path.join(OUT, name), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
wcsv("write_amplification.csv", wa); wcsv("recovery_time.csv", rec); wcsv("latency.csv", lat); wcsv("ps_stats.csv", pss)

# ---------------------------------------------------------------- co-simulation (hardware-measured recovery cycles)
cosim = []
for path in sorted(glob.glob(os.path.join(ROOT, "reports", "cosim", "*.log"))):
    t = open(path).read()
    m = re.search(r"recovery: (\d+) recovery boots \((\d+) unclean, (\d+) clean, (\d+) used an older checkpoint\), RECOVER state "
                  r"(\d+) / (\d+) / (\d+) cycles", t)
    if m:
        cosim.append(dict(log=os.path.basename(path), boots=int(m.group(1)), unclean=int(m.group(2)), clean=int(m.group(3)),
                          older=int(m.group(4)), cmin=int(m.group(5)), cmean=int(m.group(6)), cmax=int(m.group(7))))

# ---------------------------------------------------------------- SVG charts (no plotting library needed)
PAL = {"p56": "#8a8f98", "p58": "#2563eb", "write_through": "#2563eb", "write_through_verify": "#7c3aed",
       "wce_fua": "#059669", "wce_volatile": "#d97706", "deallocate": "#db2777"}

def svg_lines(path, title, xlabel, ylabel, series, logx=False, logy=False, xticks=None, ymax=None):
    W, H, L, R, T, B = 760, 360, 70, 240, 40, 50
    xs = [x for s in series for x, _ in s["pts"]]
    ys = [y for s in series for _, y in s["pts"]]
    import math
    fx = (lambda v: math.log10(max(v, 1e-9))) if logx else (lambda v: v)
    fy = (lambda v: math.log10(max(v, 1e-9))) if logy else (lambda v: v)
    x0, x1 = min(map(fx, xs)), max(map(fx, xs))
    y0, y1 = (min(map(fy, ys)) if logy else 0.0), (ymax if ymax is not None else max(map(fy, ys)) * (1.0 if logy else 1.1))
    if x1 == x0: x1 = x0 + 1
    if y1 == y0: y1 = y0 + 1
    X = lambda v: L + (fx(v) - x0) / (x1 - x0) * (W - L - R)
    Y = lambda v: H - B - (fy(v) - y0) / (y1 - y0) * (H - T - B)
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" font-family="sans-serif" font-size="11">',
         f'<rect width="{W}" height="{H}" fill="#ffffff"/>',
         f'<text x="{L}" y="22" font-size="13" font-weight="bold" fill="#111827">{title}</text>',
         f'<line x1="{L}" y1="{H-B}" x2="{W-R}" y2="{H-B}" stroke="#374151"/>',
         f'<line x1="{L}" y1="{T}" x2="{L}" y2="{H-B}" stroke="#374151"/>',
         f'<text x="{(L+W-R)/2}" y="{H-12}" text-anchor="middle" fill="#374151">{xlabel}</text>',
         f'<text x="16" y="{(T+H-B)/2}" transform="rotate(-90 16 {(T+H-B)/2})" text-anchor="middle" fill="#374151">{ylabel}</text>']
    for k in range(6):
        v = y0 + (y1 - y0) * k / 5
        yy = H - B - (H - T - B) * k / 5
        lab = f"{10**v:.3g}" if logy else f"{v:.3g}"
        o.append(f'<line x1="{L}" y1="{yy:.1f}" x2="{W-R}" y2="{yy:.1f}" stroke="#e5e7eb"/>')
        o.append(f'<text x="{L-6}" y="{yy+4:.1f}" text-anchor="end" fill="#6b7280">{lab}</text>')
    ticks = xticks if xticks else sorted(set(xs))[:12]
    for v in ticks:
        o.append(f'<text x="{X(v):.1f}" y="{H-B+16}" text-anchor="middle" fill="#6b7280">{v:g}</text>')
    for i, s in enumerate(series):
        pts = " ".join(f"{X(x):.1f},{Y(y):.1f}" for x, y in s["pts"])
        dash = ' stroke-dasharray="5,4"' if s.get("dash") else ""
        o.append(f'<polyline points="{pts}" fill="none" stroke="{s["color"]}" stroke-width="2"{dash}/>')
        if s.get("marks", True):
            for x, y in s["pts"]:
                o.append(f'<circle cx="{X(x):.1f}" cy="{Y(y):.1f}" r="3" fill="{s["color"]}"/>')
        o.append(f'<line x1="{W-R+10}" y1="{T+10+i*18}" x2="{W-R+30}" y2="{T+10+i*18}" stroke="{s["color"]}" stroke-width="2"{dash}/>')
        o.append(f'<text x="{W-R+36}" y="{T+14+i*18}" fill="#111827">{s["name"]}</text>')
    o.append("</svg>")
    open(path, "w").write("\n".join(o))

g = "bench_4KiB"
ser = []
for lib in ("p56", "p58"):
    r = sorted([x for x in rec if x["lib"] == lib and x["geo"] == g], key=lambda x: x["interval"])
    ser.append(dict(name=f"{lib.upper()} mean", color=PAL[lib], pts=[(x["interval"], x["mean"]) for x in r]))
    ser.append(dict(name=f"{lib.upper()} p99", color=PAL[lib], dash=True, pts=[(x["interval"], x["p99"]) for x in r]))
svg_lines(os.path.join(OUT, "recovery_vs_interval.svg"), "Recovery mount after a power cut (64 MiB device, modelled)",
          "checkpoint interval (blocks opened)", "recovery time [ms]", ser, logx=True, xticks=[4, 8, 16, 32, 64])
ser = []
for lib in ("p56", "p58"):
    r = sorted([x for x in wa if x["lib"] == lib and x["geo"] == g], key=lambda x: x["interval"])
    ser.append(dict(name=f"{lib.upper()}", color=PAL[lib], pts=[(x["interval"], x["meta_wa"]) for x in r]))
svg_lines(os.path.join(OUT, "metadata_wa_vs_interval.svg"), "Metadata write amplification (meta programs / host programs)",
          "checkpoint interval (blocks opened)", "metadata WA", ser, logx=True, xticks=[4, 8, 16, 32, 64])
cdf = list(csv.DictReader(open(os.path.join(OUT, "latency_cdf.csv"))))
ser = []
for mode, what, label in (("write_through", "write", "write-through (durable ack)"),
                          ("write_through_verify", "write", "write-through + read-back"),
                          ("wce_fua", "write", "WCE on, FUA write"),
                          ("deallocate", "deallocate", "DEALLOCATE (journal)"),
                          ("wce_volatile", "flush16", "WCE on: FLUSH of 16 writes")):
    pts = [(max(float(r["us"]), 1.0), float(r["quantile"])) for r in cdf if r["mode"] == mode and r["what"] == what]
    ser.append(dict(name=label, color=PAL[mode], pts=pts, marks=False))
svg_lines(os.path.join(OUT, "latency_cdf.svg"), "Command completion latency, modelled device time (4-KiB random, 90 % full)",
          "latency [us] (log)", "fraction of commands", ser, logx=True, xticks=[300, 1000, 3000, 10000, 30000], ymax=1.0)

# ---------------------------------------------------------------- report
def row(cells): return "| " + " | ".join(str(c) for c in cells) + " |"
L = ["# Performance — SilicaFlux PowerSafe (Project 58)", "",
     "Generated by `scripts/perf.py`. **Device times are modelled** with NANDLab's illustrative SLC values "
     "(tR 25 µs, tPROG 200 µs, tBERS 2 ms, 30 ns/byte bus); they are only comparable with each other and are not "
     "measurements of any NAND device. Firmware CPU time is not included. The same benchmark source is built against the "
     "unmodified Project 56 FTL and the Project 58 FTL, so the P56 → P58 columns are measured differences.", "",
     "## 1. Recovery time after a power cut", "",
     f"Repeated power cuts at a random point of a random write/TRIM workload ({SAMPLES} samples per point; the distance "
     "since the last checkpoint is uniform over two checkpoint intervals), then a recovery mount.", "",
     row(["device", "ckpt interval", "P56 mean / p99 / max ms", "P58 mean / p99 / max ms", "P58 mount reads (mean)", "P58 clean mount ms"]),
     row(["---"] * 6)]
for geo in ("p51_512B", "bench_4KiB"):
    for iv in sorted({x["interval"] for x in rec if x["geo"] == geo}):
        a = next((x for x in rec if x["lib"] == "p56" and x["geo"] == geo and x["interval"] == iv), None)
        b = next((x for x in rec if x["lib"] == "p58" and x["geo"] == geo and x["interval"] == iv), None)
        if a and b:
            L.append(row([geo, iv, f"{a['mean']:.1f} / {a['p99']:.1f} / {a['max']:.1f}", f"{b['mean']:.1f} / {b['p99']:.1f} / {b['max']:.1f}",
                          f"{b['reads']:.0f}", f"{b['clean']:.1f}"]))
L += ["", "![recovery](recovery_vs_interval.svg)", "",
      "Recovery time grows with the checkpoint interval (more roll-forward); the interval is the knob that trades "
      "metadata write amplification (§2) against recovery time. P58's recovery mount additionally writes the event log "
      "inside the same checkpoint it always wrote, so its cost is within the noise.", ""]
if cosim:
    L += ["### Hardware-measured recovery (co-simulation)", "",
          "`RECOVER` state duration measured by the recovery controller (`RECOV_CYC_LAST`) in the RTL co-simulation "
          "(P51-class 64-block device; compressed time base 1 cycle = 1 µs of NAND time, so the cycle counts are the "
          "same order as the modelled microseconds).", "",
          row(["campaign", "recovery boots", "unclean", "clean", "used an older checkpoint", "min / mean / max cycles"]),
          row(["---"] * 6)]
    for c in cosim:
        L.append(row([c["log"], c["boots"], c["unclean"], c["clean"], c["older"], f"{c['cmin']} / {c['cmean']} / {c['cmax']}"]))
    L.append("")
L += ["## 2. Metadata write amplification, journal overhead, checkpoint frequency", "",
      "Steady state: uniform random page writes for 2× the capacity, 5 % whole-page DEALLOCATE, FLUSH every 100 commands.", "",
      row(["device", "lib", "ckpt interval", "host pages", "GC pages", "metadata pages", "of which journal", "checkpoints",
           "ckpt / 1000 host pages", "metadata WA", "total WA"]), row(["---"] * 11)]
for geo in ("p51_512B", "bench_4KiB"):
    for x in sorted([x for x in wa if x["geo"] == geo], key=lambda x: (x["interval"], x["lib"])):
        L.append(row([geo, x["lib"].upper(), x["interval"], x["host"], x["reloc"], x["meta"], x["jpages"], x["ckpts"],
                      f"{x['ck_per_1000']:.2f}", f"{x['meta_wa']:.4f}", f"{x['wa']:.3f}"]))
L += ["", "![metadata WA](metadata_wa_vs_interval.svg)", "",
      "Journal pages are written for DEALLOCATE (before its acknowledgement), block retirements, MOUNT records and "
      "FLUSH (buffered erase counts); host writes need no journal (the spare record carries LBA + sequence number). "
      "Checkpoint pages dominate the metadata traffic and scale with 1 / interval.", "",
      "## 3. Command completion latency", "",
      "4-KiB uniform random commands on the 64-MiB bench device at 90 % logical fill (paced GC active), 20 000 commands "
      "per mode. Latency = modelled device time from submission to completion.", "",
      row(["mode", "what", "n", "mean µs", "p50 µs", "p99 µs", "p99.9 µs", "max µs"]), row(["---"] * 8)]
for x in lat:
    L.append(row([x["mode"], x["what"], x["n"], f"{x['mean']:.1f}", f"{x['p50']:.1f}", f"{x['p99']:.1f}", f"{x['p999']:.1f}", f"{x['max']:.1f}"]))
L += ["", "![latency](latency_cdf.svg)", "",
      "* **write-through** (WCE off, the default): the acknowledgement waits for the program status and the mapping "
      "commit — every acknowledged write is durable. The tail is paced GC.",
      "* **WCE on** (host opted into a volatile cache): the acknowledgement costs no device time, but the data is not "
      "durable until a FLUSH; a FLUSH after 16 writes pays for them (destage) — the durability cost moves, it does not "
      "disappear. Without PLP, acknowledged-volatile data is lost at a power cut (by contract).",
      "* **read-back verification** (`SFFTL_F_VERIFY_HOST_WRITE`, VERIFIED phase): one extra page read per write "
      "(≈ +150 µs at 4 KiB).",
      "* **DEALLOCATE**: one journal page programmed before the acknowledgement.",
      "* The recovery controller's completion gate adds 2 clock cycles to every completion (store + output register); "
      "a completion is held longer only when firmware posts it before the command is DURABLE.", ""]
cap = {}
for x in wa:
    cap[(x["lib"], x["geo"])] = x
L += ["## 4. Capacity and memory consumed by the recovery structures", "",
      row(["device", "raw blocks", "P56 metadata blocks", "P58 metadata blocks", "P56 LBAs", "P58 LBAs", "capacity cost of A/B retention",
           "checkpoint pages (P58)"]), row(["---"] * 8)]
for geo, blocks in (("p51_512B", 64), ("bench_4KiB", 256)):
    a, b = cap.get(("p56", geo)), cap.get(("p58", geo))
    if a and b:
        L.append(row([geo, blocks, a["meta_blocks"], b["meta_blocks"], a["nlba"], b["nlba"],
                      f"{(a['nlba'] - b['nlba']) / a['nlba'] * 100:.2f} %", b["ckpt_pages"]]))
L += ["", "* Every page carries the 16-byte FTL spare record {type, LPN, 48-bit SEQ, CRC-32} (unchanged from P56).",
      "* Schema 2 adds 72 words (288 B) to every checkpoint body (event log) and 2 words to the commit.",
      "* Firmware RAM: `sfftl_t` +~330 B (hook, A/B pointers, event area); PowerSafe layer `sfps_t` and the optional "
      "write cache (8 pages × page size) — see `reports/firmware_size.md`.",
      "* Hardware: see `reports/synth.md`.", ""]
open(os.path.join(OUT, "PERF.md"), "w").write("\n".join(L) + "\n")
print("\n".join(L))
