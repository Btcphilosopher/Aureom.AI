#!/usr/bin/env python3
"""SilicaFlux PowerSafe (Project 58) -- register map generator.

Single source of truth for the firmware page of silicaflux_storage_recovery.
Generates:
  rtl/sfpr_regs_pkg.sv                         (SystemVerilog package, localparams)
  firmware/powersafe/include/sfps_regs.h       (C header)
  docs/REGISTERS.md                            (documentation)
Run:  python3 scripts/gen_regs.py            (writes the three files)
      python3 scripts/gen_regs.py --check    (fails if a generated file is stale)
"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

VERSION = 0x00580100          # Project 58, register map 1.0
ID_MAGIC = 0x53465052         # "SFPR"

# --------------------------------------------------------------------------- enumerations
ENUMS = [
    ("STATE", "recovery FSM state (STATE[3:0])", [
        ("RESET", 0, "reset released; one cycle"),
        ("INIT", 1, "waiting for firmware boot (CTRL.BOOT_ACK); host commands aborted NOT_READY"),
        ("RECOVER", 2, "firmware recovery mount in progress; host commands aborted NOT_READY"),
        ("READY", 3, "normal operation"),
        ("READONLY", 4, "degraded: reads served, WRITE/DEALLOCATE refused"),
        ("PF_QUIESCE", 5, "power fault: admission closed, NAND program/erase inhibited, in-flight work stops"),
        ("PF_SAFE", 6, "power fault: no firmware-owned command active, NAND idle, WP# forced"),
        ("FAILED", 7, "recovery failed; commands aborted INTERNAL_ERR; CTRL.RECOVER_RETRY"),
        ("SHUTDOWN", 8, "clean shutdown requested; admission closed"),
        ("SHUT_DONE", 9, "clean shutdown complete; media write-protected until reset"),
    ]),
    ("PH", "persistence phase of a tracked command (strictly increasing)", [
        ("FREE", 0, "slot unused"),
        ("ACCEPTED", 1, "hardware: admitted and forwarded to the command queue"),
        ("STARTED", 2, "firmware: owns the command; hardware will no longer abort it"),
        ("BUFFERED", 3, "firmware: host data held in the controller buffer (volatile)"),
        ("PROGRAMMED", 4, "firmware: every NAND program of the command issued and completed"),
        ("VERIFIED", 5, "firmware: program status PASS confirmed (and read-back compared if enabled)"),
        ("MAP_COMMITTED", 6, "firmware: mapping updated; self-describing spare records / journal on media"),
        ("DURABLE", 7, "firmware: data and every metadata record recovery needs are on non-volatile media"),
    ]),
    ("PR", "PHASE_RESULT codes", [
        ("OK", 0, "phase recorded (or repeated)"),
        ("BAD_SLOT", 1, "slot not in use"),
        ("REGRESS", 2, "phase lower than the recorded one, or a hardware-only phase"),
        ("ABORTED", 3, "hardware already aborted this command (power fault); do not start it"),
        ("QUIESCED", 4, "STARTED refused: power fault active, no new work may start"),
    ]),
    ("CLS", "command class derived from the opcode", [
        ("OTHER", 0, "IDENTIFY, GET_LOG, ERASE, unknown"),
        ("READ", 1, "READ"),
        ("WRITE", 2, "WRITE (FUA flag honoured)"),
        ("TRIM", 3, "DEALLOCATE"),
        ("FLUSH", 4, "FLUSH"),
    ]),
    ("RD", "RECOV_DONE result", [
        ("OK", 0, "recovered, read-write -> READY"),
        ("READONLY", 1, "recovered, degraded -> READONLY"),
        ("FAIL", 2, "unrecoverable -> FAILED"),
    ]),
    ("CAUSE", "STK_LAST_CAUSE: why the controller last entered INIT/RECOVER", [
        ("POR", 0, "power-on reset (supply applied)"),
        ("WARM", 1, "controller reset with supply present"),
        ("PF_RESUME", 2, "power restored after a power fault (brown-out); full recovery"),
        ("RETRY", 3, "firmware retried a failed recovery"),
    ]),
    ("CIEV", "crash-injection event select (CI_CTRL.EVENT)", [
        ("CYCLE", 0, "every clock cycle while armed"),
        ("ADMIT", 1, "a command admitted into a slot"),
        ("PHASE", 2, "a phase report accepted with phase == ARG"),
        ("HOSTCPL", 3, "a completion delivered to the host"),
        ("NANDOP", 4, "a NAND operation started (rising edge of nand_busy_i)"),
        ("MARK", 5, "firmware wrote CI_MARK with id == ARG (ARG = 0xFF: any id)"),
        ("PF", 6, "power-fault latch set"),
    ]),
    ("CIACT", "crash-injection action (CI_CTRL.ACTION)", [
        ("CRASH", 0, "assert ci_crash_o: test bench removes the supply (no warning)"),
        ("PF", 1, "assert the internal power-fault warning (as if pwr_fail_ni fell)"),
        ("WARM", 2, "assert ci_warm_o: test bench applies a controller reset"),
        ("CRASH_PF", 3, "assert ci_pf_o and ci_crash_o: warning then supply loss (hold-up set by the bench)"),
    ]),
]

# ERR_STATUS bits (W1C)
ERR_BITS = [
    ("PHASE_BAD_SLOT", 0, "phase report for a free / out-of-range slot"),
    ("PHASE_REGRESS", 1, "phase report lower than the recorded phase, or FREE/ACCEPTED"),
    ("CPL_UNKNOWN", 2, "completion from the command queue for a free / out-of-range slot (dropped)"),
    ("CPL_DUP", 3, "second completion for a slot (dropped)"),
    ("GATE_TIMEOUT", 4, "a held SUCCESS never became eligible within GATE_TIMEOUT; converted to INTERNAL_ERR"),
    ("RECOV_TIMEOUT", 5, "recovery exceeded RECOV_TIMEOUT cycles -> FAILED"),
    ("RETIRE_BAD", 6, "RETIRE of a slot that is not an acknowledged-volatile write"),
    ("VOL_FAIL", 7, "an acknowledged-volatile write could not be made durable (RETIRE); dependent FLUSH fails"),
    ("SEQ", 8, "CTRL / RECOV_DONE command not legal in the current state (ignored)"),
    ("PF_IN_RECOVERY", 9, "power fault while INIT / RECOVER / SHUTDOWN (recovery will restart)"),
]

IRQ_BITS = [
    ("PF_EVENT", 0, "sticky: power fault latched (W1C)"),
    ("PF_SAFE", 1, "level: state PF_SAFE"),
    ("PF_RESTORED", 2, "level: in PF_SAFE and the supply has been good for PF_RESTORE_CYCLES"),
    ("ERR", 3, "level: ERR_STATUS != 0"),
    ("VOL_LOST", 4, "sticky: acknowledged-volatile data was at risk at a power fault (W1C)"),
    ("CI_FIRED", 5, "sticky: crash injection fired (W1C)"),
    ("CMD_STATE", 6, "level: state needs firmware action (INIT, PF_SAFE+restored, SHUTDOWN)"),
]

CTRL_BITS = [
    ("BOOT_ACK", 0, "INIT -> RECOVER (firmware alive, starting recovery mount)"),
    ("SHUTDOWN_DONE", 1, "SHUTDOWN -> SHUT_DONE (clean checkpoint written; no command outstanding)"),
    ("PF_RESUME", 2, "PF_SAFE (supply restored) -> READY/READONLY (fast) or RECOVER"),
    ("RECOVER_RETRY", 3, "FAILED -> RECOVER"),
    ("FORCE_PF", 4, "latch a power fault without the pin (firmware-initiated emergency quiesce)"),
    ("CLR_STICKY", 5, "clear the sticky diagnostic counters (POR-domain)"),
    ("SHUTDOWN_REQ", 8, "firmware-initiated shutdown (same as shn_req_i rising)"),
]

CFG_BITS = [
    ("WCE", 0, 0, "volatile write cache enabled by the host: WRITE without FUA may be acknowledged at BUFFERED"),
    ("HW_ABORT_UNSTARTED", 1, 1, "power fault: hardware aborts commands not yet STARTED by firmware"),
    ("AUTO_WP", 2, 1, "power fault: force WP# as soon as no NAND operation is in flight"),
    ("FAST_RESUME_EN", 3, 0, "PF_RESUME may return to READY without recovery when no NAND op was in flight at the fault"),
]

# slot window word
SLOT_FIELDS = [
    ("PHASE", 0, 3, "PH_*"),
    ("VALID", 3, 1, "slot in use"),
    ("CLS", 4, 3, "CLS_*"),
    ("FUA", 7, 1, "force unit access"),
    ("EARLY_OK", 8, 1, "admitted while WCE (or PLP) allowed an early acknowledgement"),
    ("ACKED", 9, 1, "completion delivered to the host"),
    ("VOL", 10, 1, "acknowledged before DURABLE (volatile); tracked until DURABLE or RETIRE"),
    ("HWAB", 11, 1, "aborted by hardware (power fault) before firmware started it"),
    ("CPL_HELD", 12, 1, "completion from the command queue held by the gate"),
    ("DEP_PENDING", 13, 1, "FLUSH: acknowledged-volatile writes it depends on are not durable yet"),
    ("DEP_FAIL", 14, 1, "FLUSH: a dependency was retired as failed"),
    ("DN_DONE", 15, 1, "command queue completion received"),
    ("HOST_TID", 16, 16, "host transaction ID"),
]

# --------------------------------------------------------------------------- register map
# (name, offset, access, reset, description)
REGS = [
    ("ID", 0x000, "RO", ID_MAGIC, "magic 'SFPR'"),
    ("VERSION", 0x004, "RO", VERSION, "register map version (Project 58, 1.0)"),
    ("CAPS", 0x008, "RO", None, "[7:0] N_SLOTS [8] PLP_PRESENT [9] CRASH_INJ_EN [31:16] PLP_QUALIFICATION_ID"),
    ("STATE", 0x00C, "RO", None, "[3:0] STATE_* [4] PF_PIN (synchronised, 1 = fault) [5] PF_LATCHED [6] NAND_INHIBIT "
                                 "[7] WP_FORCE [8] NAND_BUSY [9] PF_RESTORED [10] FAST_RESUME_OK [12:11] SHST "
                                 "[23:16] slots in use [31:24] acknowledged-volatile slots not yet durable"),
    ("CTRL", 0x010, "WO", None, "write-1 pulses, see CTRL bits"),
    ("CFG", 0x014, "RW", sum((r << b) for (_, b, r, _) in CFG_BITS), "see CFG bits"),
    ("GATE_TIMEOUT", 0x018, "RW", 0, "cycles a SUCCESS may wait for eligibility before conversion to INTERNAL_ERR (0 = never)"),
    ("RECOV_TIMEOUT", 0x01C, "RW", 0, "cycles allowed in RECOVER before FAILED (0 = never)"),
    ("PF_RESTORE_CYCLES", 0x020, "RW", 64, "supply-good cycles required before PF_RESTORED"),
    ("RECOV_DONE", 0x024, "WO", None, "[1:0] RD_* result of the recovery mount (legal in RECOVER only)"),
    ("PHASE", 0x028, "WO", None, "[7:0] slot [10:8] PH_* reached by the command in that slot"),
    ("PHASE_RESULT", 0x02C, "RO", None, "[2:0] PR_* outcome of the last PHASE write"),
    ("RETIRE", 0x030, "WO", None, "[7:0] slot: an acknowledged-volatile write that cannot be made durable"),
    ("ERR_STATUS", 0x034, "W1C", 0, "error bits, see ERR bits"),
    ("ERR_INFO", 0x038, "RO", 0, "first error since clear: [7:0] ERR bit index [15:8] slot [19:16] state"),
    ("IRQ_STATUS", 0x03C, "W1C", 0, "interrupt sources, see IRQ bits (sticky ones W1C)"),
    ("IRQ_EN", 0x040, "RW", 0, "interrupt enables (irq_o = |(IRQ_STATUS & IRQ_EN))"),
    ("COMMIT_SEQ_LO", 0x044, "RW", 0, "persistent commit status: highest FTL sequence number known durable [31:0]"),
    ("COMMIT_SEQ_HI", 0x048, "RW", 0, "[15:0] sequence number [47:32]"),
    ("DURABLE_CNT", 0x04C, "RO", 0, "commands that reached DURABLE since reset"),
    ("CNT_ADMIT", 0x050, "RO", 0, "commands admitted into a slot"),
    ("CNT_ABORT_PF", 0x054, "RO", 0, "commands completed ABORT_PWR_LOSS by hardware (admission or sweep)"),
    ("CNT_ABORT_STATE", 0x058, "RO", 0, "commands refused because of the state (INIT/RECOVER/FAILED/SHUTDOWN/READONLY)"),
    ("CNT_REJ_CONFLICT", 0x05C, "RO", 0, "commands refused: host TID already outstanding"),
    ("CNT_CPL_HOST", 0x060, "RO", 0, "completions delivered to the host"),
    ("CNT_ACK_DURABLE", 0x064, "RO", 0, "SUCCESS completions delivered with the command DURABLE"),
    ("CNT_ACK_VOL", 0x068, "RO", 0, "SUCCESS completions of WRITE delivered before DURABLE (volatile)"),
    ("CNT_GATE_HELD", 0x06C, "RO", 0, "SUCCESS completions the gate had to hold for at least one cycle"),
    ("CNT_GATE_CONV", 0x070, "RO", 0, "held SUCCESS converted to an error (power fault or timeout)"),
    ("CNT_DROP", 0x074, "RO", 0, "command-queue completions dropped (command already aborted by hardware)"),
    ("CNT_VOL_DURABLE", 0x078, "RO", 0, "acknowledged-volatile writes that later became durable"),
    ("CNT_VOL_FAILED", 0x07C, "RO", 0, "acknowledged-volatile writes retired as failed"),
    ("LAT_DUR_SUM", 0x080, "RO", 0, "sum of admission->completion cycles of CNT_ACK_DURABLE completions (saturating)"),
    ("LAT_DUR_MAX", 0x084, "RO", 0, "maximum of the above"),
    ("LAT_VOL_MAX", 0x088, "RO", 0, "maximum admission->completion cycles of volatile acknowledgements"),
    ("GATE_HOLD_MAX", 0x08C, "RO", 0, "maximum cycles a SUCCESS was held by the gate"),
    ("RECOV_CYC_LAST", 0x090, "RO", 0, "cycles of the last RECOVER state (hardware-measured recovery time)"),
    ("RECOV_CYC_MAX", 0x094, "RO", 0, "maximum RECOVER duration since reset"),
    ("PF_SAFE_CYC_LAST", 0x098, "RO", 0, "cycles from the last power-fault latch to PF_SAFE"),
    ("CNT_PHASE_RPT", 0x09C, "RO", 0, "phase reports accepted"),
    ("STK_FLAGS", 0x0A0, "RO", 0, "POR-domain: [0] PF_SEEN [1] WARM_SEEN [2] RECOV_SEEN"),
    ("STK_PF_COUNT", 0x0A4, "RO", 0, "POR-domain: power faults latched since power-on"),
    ("STK_WARM_COUNT", 0x0A8, "RO", 0, "POR-domain: controller resets survived since power-on"),
    ("STK_LAST_CAUSE", 0x0AC, "RO", 0, "POR-domain: [1:0] CAUSE_* of the last INIT/RECOVER entry"),
    ("STK_PF_SNAP0", 0x0B0, "RO", 0, "POR-domain snapshot at the last power fault: [3:0] state [12:8] host-outstanding "
                                     "[20:16] firmware-active [28:24] volatile-at-risk [31] valid"),
    ("STK_PF_SNAP1", 0x0B4, "RO", 0, "[0] NAND busy at the fault [1] PF_SAFE reached [15:8] completions converted [23:16] commands hw-aborted"),
    ("STK_PF_TS", 0x0B8, "RO", 0, "POR-domain cycle counter value at the last power fault"),
    ("STK_PF_SAFE_CYC", 0x0BC, "RO", 0, "cycles from that fault to PF_SAFE (0 = never reached)"),
    ("STK_PF_COMMIT_SEQ", 0x0C0, "RO", 0, "COMMIT_SEQ_LO at the last power fault"),
    ("STK_VOL_LOST", 0x0C4, "RO", 0, "acknowledged-volatile writes not durable at a power fault or controller reset (cumulative)"),
    ("STK_RST_SNAP", 0x0C8, "RO", 0, "state before the last controller reset: [3:0] state [12:8] host-outstanding [28:24] volatile [31] valid"),
    ("STK_RECOV", 0x0CC, "RO", 0, "[1:0] last RD_* result [2] valid [31:3] its RECOVER cycles"),
    ("STK_TS_NOW", 0x0D0, "RO", 0, "POR-domain free-running cycle counter"),
    ("CI_CTRL", 0x100, "RW", 0, "crash injection: [0] ARM [2:1] CIACT_* [7:4] CIEV_* [15:8] ARG"),
    ("CI_COUNT", 0x104, "RW", 1, "fire on the N-th matching event (1-based)"),
    ("CI_DELAY", 0x108, "RW", 0, "cycles between the N-th event and firing"),
    ("CI_STATUS", 0x10C, "RO", 0, "[0] ARMED [1] FIRED [31:8] matching events seen"),
    ("CI_MARK", 0x110, "WO", None, "[7:0] firmware crash-point id (counted by CIEV_MARK)"),
    ("CI_LAST_MARK", 0x114, "RO", 0, "[7:0] last id written to CI_MARK [31:8] marks written"),
]
SLOT_WIN = 0x200
SLOT_STRIDE = 4
SLOT_MAX = 64


def check():
    offs = set()
    for name, off, acc, rst, desc in REGS:
        assert off % 4 == 0 and off < SLOT_WIN, name
        assert off not in offs, name
        offs.add(off)


def gen_sv():
    L = []
    L.append("// GENERATED by scripts/gen_regs.py -- do not edit.")
    L.append("// SilicaFlux PowerSafe (Project 58) :: firmware page of silicaflux_storage_recovery")
    L.append("// Classification: SYNTHESIZABLE (package)")
    L.append("`default_nettype none")
    L.append("")
    L.append("package sfpr_regs_pkg;")
    L.append("  /* verilator lint_off UNUSEDPARAM */")
    L.append(f"  localparam logic [31:0] SFPR_ID_MAGIC    = 32'h{ID_MAGIC:08x};")
    L.append(f"  localparam logic [31:0] SFPR_VERSION_VAL = 32'h{VERSION:08x};")
    L.append(f"  localparam logic [11:0] SFPR_SLOT_WIN = 12'h{SLOT_WIN:03x};")
    L.append(f"  localparam int          SFPR_SLOT_STRIDE = {SLOT_STRIDE};")
    L.append(f"  localparam int          SFPR_SLOT_MAX = {SLOT_MAX};")
    L.append("")
    for name, off, acc, rst, desc in REGS:
        L.append(f"  localparam logic [11:0] SFPR_{name} = 12'h{off:03x};  // {acc}: {desc[:90]}")
        if rst is not None and acc in ("RW", "W1C"):
            L.append(f"  localparam logic [31:0] SFPR_{name}_RST = 32'h{rst:08x};")
    L.append("")
    for ename, edesc, vals in ENUMS:
        w = max(1, max(v for _, v, _ in vals).bit_length())
        L.append(f"  // {edesc}")
        for n, v, d in vals:
            L.append(f"  localparam logic [{w-1}:0] SFPR_{ename}_{n} = {w}'d{v};  // {d[:80]}")
        L.append("")
    for grp, bits in (("ERR", ERR_BITS), ("IRQ", IRQ_BITS), ("CTRL", CTRL_BITS)):
        for n, b, d in bits:
            L.append(f"  localparam int SFPR_{grp}_{n} = {b};  // {d[:90]}")
        L.append("")
    for n, b, r, d in CFG_BITS:
        L.append(f"  localparam int SFPR_CFG_{n} = {b};  // reset {r}: {d[:80]}")
    L.append("")
    for n, b, w, d in SLOT_FIELDS:
        L.append(f"  localparam int SFPR_SLOT_{n}_LSB = {b};  // width {w}: {d}")
    L.append("  /* verilator lint_on UNUSEDPARAM */")
    L.append("endpackage")
    L.append("")
    L.append("`default_nettype wire")
    return "\n".join(L) + "\n"


def gen_h():
    L = []
    L.append("/* GENERATED by scripts/gen_regs.py -- do not edit.")
    L.append(" * SilicaFlux PowerSafe (Project 58) -- silicaflux_storage_recovery firmware page */")
    L.append("#ifndef SFPS_REGS_H")
    L.append("#define SFPS_REGS_H")
    L.append("")
    L.append(f"#define SFPR_ID_MAGIC      0x{ID_MAGIC:08X}u")
    L.append(f"#define SFPR_VERSION_VAL   0x{VERSION:08X}u")
    L.append(f"#define SFPR_SLOT_WIN      0x{SLOT_WIN:03X}u")
    L.append(f"#define SFPR_SLOT_STRIDE   {SLOT_STRIDE}u")
    L.append(f"#define SFPR_SLOT_MAX      {SLOT_MAX}u")
    L.append("")
    for name, off, acc, rst, desc in REGS:
        L.append(f"#define SFPR_{name:<20} 0x{off:03X}u  /* {acc}: {desc[:70]} */")
    L.append("")
    for ename, edesc, vals in ENUMS:
        L.append(f"/* {edesc} */")
        for n, v, d in vals:
            L.append(f"#define SFPR_{ename}_{n:<16} {v}u")
        L.append("")
    for grp, bits in (("ERR", ERR_BITS), ("IRQ", IRQ_BITS), ("CTRL", CTRL_BITS)):
        for n, b, d in bits:
            L.append(f"#define SFPR_{grp}_{n:<20} (1u << {b})")
        L.append("")
    for n, b, r, d in CFG_BITS:
        L.append(f"#define SFPR_CFG_{n:<20} (1u << {b})")
    L.append("")
    for n, b, w, d in SLOT_FIELDS:
        L.append(f"#define SFPR_SLOT_{n}(w) (((w) >> {b}) & 0x{(1 << w) - 1:X}u)")
    L.append("")
    L.append("/* STATE register fields */")
    L.append("#define SFPR_STATE_FSM(w)        ((w) & 0xFu)")
    L.append("#define SFPR_STATE_PF_PIN        (1u << 4)")
    L.append("#define SFPR_STATE_PF_LATCHED    (1u << 5)")
    L.append("#define SFPR_STATE_NAND_INHIBIT  (1u << 6)")
    L.append("#define SFPR_STATE_WP_FORCE      (1u << 7)")
    L.append("#define SFPR_STATE_NAND_BUSY     (1u << 8)")
    L.append("#define SFPR_STATE_PF_RESTORED   (1u << 9)")
    L.append("#define SFPR_STATE_FAST_RESUME   (1u << 10)")
    L.append("#define SFPR_STATE_SLOTS(w)      (((w) >> 16) & 0xFFu)")
    L.append("#define SFPR_STATE_VOL(w)        (((w) >> 24) & 0xFFu)")
    L.append("")
    L.append("#endif /* SFPS_REGS_H */")
    return "\n".join(L) + "\n"


def gen_md():
    L = []
    L.append("# silicaflux_storage_recovery — firmware register page")
    L.append("")
    L.append("Generated by `scripts/gen_regs.py` (do not edit). 32-bit registers on the ControlCore-style register")
    L.append("bus (`rb_sel/rb_we/rb_addr[11:0]/rb_wdata/rb_rdata/rb_err`, same convention as the P51 pages).")
    L.append("Unmapped addresses and writes to read-only registers set `rb_err`.")
    L.append("")
    L.append(f"`ID` = `0x{ID_MAGIC:08X}`, `VERSION` = `0x{VERSION:08X}`.")
    L.append("")
    L.append("| Offset | Name | Access | Reset | Description |")
    L.append("|---|---|---|---|---|")
    for name, off, acc, rst, desc in REGS:
        r = "—" if rst is None else f"`0x{rst:08X}`"
        L.append(f"| `0x{off:03X}` | `{name}` | {acc} | {r} | {desc} |")
    L.append(f"| `0x{SLOT_WIN:03X}` + 4·*n* | `SLOT[n]` | RO | 0 | slot *n* (n < N_SLOTS): fields below |")
    L.append("")
    L.append("Registers `STK_*` live in the **power-on-reset domain**: a controller (warm) reset does not clear them;")
    L.append("only `por_n` (or `CTRL.CLR_STICKY` for the counters) does. They are volatile: after a real loss of")
    L.append("supply they are gone, which is why recovery firmware copies them into the FTL's persistent event log.")
    L.append("Registers `CI_*` exist only when `CRASH_INJ_EN = 1` (test builds); otherwise they read 0.")
    L.append("")
    for title, bits in (("CTRL bits (write 1)", CTRL_BITS), ("ERR_STATUS bits (W1C)", ERR_BITS), ("IRQ bits", IRQ_BITS)):
        L.append(f"## {title}")
        L.append("")
        L.append("| Bit | Name | Meaning |")
        L.append("|---|---|---|")
        for n, b, d in bits:
            L.append(f"| {b} | `{n}` | {d} |")
        L.append("")
    L.append("## CFG bits")
    L.append("")
    L.append("| Bit | Name | Reset | Meaning |")
    L.append("|---|---|---|---|")
    for n, b, r, d in CFG_BITS:
        L.append(f"| {b} | `{n}` | {r} | {d} |")
    L.append("")
    L.append("## SLOT[n] fields")
    L.append("")
    L.append("| Bits | Field | Meaning |")
    L.append("|---|---|---|")
    for n, b, w, d in SLOT_FIELDS:
        rng = f"{b}" if w == 1 else f"{b + w - 1}:{b}"
        L.append(f"| [{rng}] | `{n}` | {d} |")
    L.append("")
    for ename, edesc, vals in ENUMS:
        L.append(f"## {ename}_* — {edesc}")
        L.append("")
        L.append("| Value | Name | Meaning |")
        L.append("|---|---|---|")
        for n, v, d in vals:
            L.append(f"| {v} | `{ename}_{n}` | {d} |")
        L.append("")
    return "\n".join(L)


def main():
    check()
    outs = {
        os.path.join(ROOT, "rtl", "sfpr_regs_pkg.sv"): gen_sv(),
        os.path.join(ROOT, "firmware", "powersafe", "include", "sfps_regs.h"): gen_h(),
        os.path.join(ROOT, "docs", "REGISTERS.md"): gen_md(),
    }
    if "--check" in sys.argv:
        stale = [p for p, t in outs.items() if not os.path.exists(p) or open(p).read() != t]
        for p in stale:
            print("STALE:", os.path.relpath(p, ROOT))
        print("generated files up to date" if not stale else f"{len(stale)} stale")
        return 1 if stale else 0
    for p, t in outs.items():
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w") as f:
            f.write(t)
        print("wrote", os.path.relpath(p, ROOT))
    return 0


if __name__ == "__main__":
    sys.exit(main())
