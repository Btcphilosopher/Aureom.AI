/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- deterministic crash-injection framework
 *
 * A crash point is a NAMED position in the controller's flow, matched against
 * the FTL / PowerSafe event stream (sfftl_ev_t).  A crash is specified by
 *   (workload seed, point, k)  -- crash at the k-th time the point is reached
 * and is therefore exactly reproducible.  The action removes the supply:
 *   OFF       the supply is gone before the NAND operation that follows
 *   TORN ...  the NAND operation that follows is interrupted with a forced
 *             outcome (simnand_arm_powercut_mode): not started, completed with
 *             the status never seen, ECC-correctable, torn, torn-but-ECC-passes,
 *             partial erase.
 * Counting mode (point = CP_NONE) records how often every point is reached, so
 * a sweep can enumerate k = 1 .. hits for each point.
 *
 * Execution back-ends: in-process (simnand stays dead until power-on; the FTL
 * unwinds with SFFTL_EPOWER), forked process (simnand's power-loss callback
 * _exit()s the controller process; the medium is a MAP_SHARED file), and the
 * Verilator co-simulation (on_fire writes the point id to the recovery
 * controller's CI_MARK register; its crash-injection unit fires).
 * ===========================================================================*/
#ifndef SFCRASH_H
#define SFCRASH_H

#include <stdint.h>
#include "sfftl.h"
#include "simnand.h"

enum sfcrash_point {
  CP_NONE = 0,
  /* --- host write path (brief: before / during / after programming, before mapping update) */
  CP_HOST_BEFORE_PROGRAM,       /* page allocated + spare record built, program not issued     */
  CP_HOST_DURING_PROGRAM,       /* program interrupted: torn page (uncorrectable)               */
  CP_HOST_DURING_PROGRAM_PASS,  /* program torn but ECC "corrects" it: only the CRC can reject  */
  CP_HOST_DURING_PROGRAM_ALMOST,/* program interrupted at the very end: data ECC-correctable    */
  CP_HOST_AFTER_PROGRAM,        /* program completed, status never seen by the firmware         */
  CP_HOST_BEFORE_MAP_UPDATE,    /* status PASS seen, L2P not yet updated                        */
  /* --- metadata journal (brief: during metadata journal update) */
  CP_JOURNAL_BEFORE_PROGRAM,    /* journal page built, not programmed                           */
  CP_JOURNAL_DURING_PROGRAM,    /* journal page torn                                            */
  CP_JOURNAL_AFTER_PROGRAM,     /* journal page programmed, status unseen                       */
  CP_JOURNAL_BEFORE_APPLY,      /* journal page durable, its RAM effect (e.g. TRIM unmap) not applied */
  /* --- completion (brief: before command completion) */
  CP_BEFORE_COMPLETION,         /* command finished (durable), completion not delivered         */
  CP_FLUSH_BEFORE_COMPLETION,   /* FLUSH finished, completion not delivered                     */
  /* --- garbage collection / wear levelling (brief: during garbage collection) */
  CP_GC_VICTIM_CHOSEN,          /* victim selected, nothing relocated yet                       */
  CP_GC_BEFORE_RELOC,           /* relocation copy built, not programmed                        */
  CP_GC_DURING_RELOC,           /* relocation copy torn                                         */
  CP_GC_BEFORE_MAP_UPDATE,      /* copy programmed (PASS), mapping still on the source          */
  CP_GC_BEFORE_ERASE,           /* every page moved, victim not erased                          */
  CP_GC_DURING_ERASE,           /* victim erase interrupted (partial erase)                     */
  CP_WL_DURING_RELOC,           /* static wear-levelling copy torn                              */
  CP_OPEN_DURING_ERASE,         /* erase-on-allocate of a fresh block interrupted               */
  /* --- checkpoint (brief: during checkpoint creation) */
  CP_CKPT_BEFORE_BODY,          /* checkpoint started, nothing programmed                       */
  CP_CKPT_DURING_BODY,          /* a body page torn                                             */
  CP_CKPT_BETWEEN_BODY,         /* k body pages programmed                                      */
  CP_CKPT_BEFORE_COMMIT,        /* body complete, commit not programmed                         */
  CP_CKPT_DURING_COMMIT,        /* commit page torn                                             */
  CP_CKPT_DURING_COMMIT_PASS,   /* commit torn, ECC passes garbage                              */
  CP_CKPT_AFTER_COMMIT,         /* commit programmed, status unseen                             */
  CP_META_DURING_ERASE,         /* metadata-ring block erase interrupted                        */
  /* --- write cache */
  CP_DESTAGE_DURING_PROGRAM,    /* cache page destage torn                                      */
  /* --- recovery itself (repeated recovery) */
  CP_MOUNT_DURING_CKPT,         /* the recovery checkpoint torn                                 */
  CP_MOUNT_AT_OP,               /* the k-th NAND operation of a recovery mount interrupted      */
  CP_COUNT
};

typedef struct {
  simnand_t *nand;
  int        point;               /* CP_NONE: counting only                          */
  uint32_t   k;                   /* fire on the k-th hit of `point` (1-based)       */
  uint32_t   hits[CP_COUNT];
  int        fired, in_mount, in_destage;
  uint32_t   mounts;              /* CP_MOUNT_AT_OP: which mount (1-based) to cut    */
  uint64_t   mount_ops0;          /* counting: NAND operations of the first recovery mount */
  /* optional: replaces the simnand action (co-simulation writes CI_MARK) */
  void      (*on_fire)(void *ctx, int point, int mode);
  void      *on_fire_ctx;
  /* optional: called at EVERY hit of every point (co-simulation: the firmware
   * writes the selected point's id to CI_MARK and the RTL counts to k) */
  void      (*on_hit)(void *ctx, int point);
  /* chained hook */
  sfftl_hook_fn next;
  void      *next_ctx;
} sfcrash_t;

void        sfcrash_init(sfcrash_t *c, simnand_t *nand, int point, uint32_t k);
void        sfcrash_hook(void *ctx, const sfftl_ev_t *ev);
const char *sfcrash_name(int point);
int         sfcrash_mode(int point);          /* SIMNAND_CUT_* applied to the NAND op that follows; 0 = OFF */
int         sfcrash_brief_item(int point);    /* the brief's crash list item (1..8) a point covers, 0 = extra */

#endif /* SFCRASH_H */
