/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- crash-injection framework (sfcrash.h)
 * ===========================================================================*/
#include <string.h>
#include "sfcrash.h"
#include "sfps.h"

static const struct { const char *name; int mode; int brief; } T[CP_COUNT] = {
  [CP_NONE]                     = { "none", 0, 0 },
  [CP_HOST_BEFORE_PROGRAM]      = { "host_before_program", 0, 1 },
  [CP_HOST_DURING_PROGRAM]      = { "host_during_program", SIMNAND_CUT_TORN, 2 },
  [CP_HOST_DURING_PROGRAM_PASS] = { "host_during_program_eccpass", SIMNAND_CUT_TORN_PASS, 2 },
  [CP_HOST_DURING_PROGRAM_ALMOST]={ "host_during_program_almost", SIMNAND_CUT_ALMOST, 2 },
  [CP_HOST_AFTER_PROGRAM]       = { "host_after_program", SIMNAND_CUT_COMPLETED, 3 },
  [CP_HOST_BEFORE_MAP_UPDATE]   = { "host_before_map_update", 0, 4 },
  [CP_JOURNAL_BEFORE_PROGRAM]   = { "journal_before_program", 0, 5 },
  [CP_JOURNAL_DURING_PROGRAM]   = { "journal_during_program", SIMNAND_CUT_TORN, 5 },
  [CP_JOURNAL_AFTER_PROGRAM]    = { "journal_after_program", SIMNAND_CUT_COMPLETED, 5 },
  [CP_JOURNAL_BEFORE_APPLY]     = { "journal_before_apply", 0, 5 },
  [CP_BEFORE_COMPLETION]        = { "before_completion", 0, 6 },
  [CP_FLUSH_BEFORE_COMPLETION]  = { "flush_before_completion", 0, 6 },
  [CP_GC_VICTIM_CHOSEN]         = { "gc_victim_chosen", 0, 7 },
  [CP_GC_BEFORE_RELOC]          = { "gc_before_reloc", 0, 7 },
  [CP_GC_DURING_RELOC]          = { "gc_during_reloc", SIMNAND_CUT_TORN, 7 },
  [CP_GC_BEFORE_MAP_UPDATE]     = { "gc_before_map_update", 0, 7 },
  [CP_GC_BEFORE_ERASE]          = { "gc_before_erase", 0, 7 },
  [CP_GC_DURING_ERASE]          = { "gc_during_erase", SIMNAND_CUT_PARTIAL, 7 },
  [CP_WL_DURING_RELOC]          = { "wl_during_reloc", SIMNAND_CUT_TORN, 7 },
  [CP_OPEN_DURING_ERASE]        = { "open_during_erase", SIMNAND_CUT_PARTIAL, 0 },
  [CP_CKPT_BEFORE_BODY]         = { "ckpt_before_body", 0, 8 },
  [CP_CKPT_DURING_BODY]         = { "ckpt_during_body", SIMNAND_CUT_TORN, 8 },
  [CP_CKPT_BETWEEN_BODY]        = { "ckpt_between_body", 0, 8 },
  [CP_CKPT_BEFORE_COMMIT]       = { "ckpt_before_commit", 0, 8 },
  [CP_CKPT_DURING_COMMIT]       = { "ckpt_during_commit", SIMNAND_CUT_TORN, 8 },
  [CP_CKPT_DURING_COMMIT_PASS]  = { "ckpt_during_commit_eccpass", SIMNAND_CUT_TORN_PASS, 8 },
  [CP_CKPT_AFTER_COMMIT]        = { "ckpt_after_commit", SIMNAND_CUT_COMPLETED, 8 },
  [CP_META_DURING_ERASE]        = { "meta_during_erase", SIMNAND_CUT_PARTIAL, 8 },
  [CP_DESTAGE_DURING_PROGRAM]   = { "destage_during_program", SIMNAND_CUT_TORN, 0 },
  [CP_MOUNT_DURING_CKPT]        = { "mount_during_ckpt", SIMNAND_CUT_TORN, 0 },
  [CP_MOUNT_AT_OP]              = { "mount_at_op", SIMNAND_CUT_RANDOM, 0 },
};

const char *sfcrash_name(int p) { return (p >= 0 && p < CP_COUNT && T[p].name) ? T[p].name : "?"; }
int sfcrash_mode(int p) { return (p >= 0 && p < CP_COUNT) ? T[p].mode : 0; }
int sfcrash_brief_item(int p) { return (p >= 0 && p < CP_COUNT) ? T[p].brief : 0; }

void sfcrash_init(sfcrash_t *c, simnand_t *nand, int point, uint32_t k) {
  memset(c, 0, sizeof(*c));
  c->nand = nand;
  c->point = point;
  c->k = k ? k : 1u;
}

static void fire(sfcrash_t *c, int p) {
  c->fired = 1;
  int mode = T[p].mode;
  if (c->on_fire) { c->on_fire(c->on_fire_ctx, p, mode); return; }
  if (mode == 0) simnand_power_off(c->nand);                /* before the next operation */
  else simnand_arm_powercut_mode(c->nand, 0, mode);         /* the next operation is the one interrupted */
}

/* one hit of point p */
static void hit(sfcrash_t *c, int p) {
  c->hits[p]++;
  if (c->on_hit) c->on_hit(c->on_fire_ctx, p);
  if (!c->fired && c->point == p && c->hits[p] == c->k) fire(c, p);
}

void sfcrash_hook(void *ctx, const sfftl_ev_t *ev) {
  sfcrash_t *c = (sfcrash_t *)ctx;
  switch (ev->kind) {
    case SFFTL_EV_MOUNT_BEGIN:
      c->in_mount = 1;
      c->mounts++;
      if (c->mounts == 1u && c->nand) c->mount_ops0 = simnand_ops(c->nand);
      if (!c->fired && c->point == CP_MOUNT_AT_OP && c->mounts == 1u) {
        /* k-1 operations of this mount complete, the k-th is interrupted */
        c->fired = 1;
        c->hits[CP_MOUNT_AT_OP] = c->k;
        if (c->on_fire) c->on_fire(c->on_fire_ctx, CP_MOUNT_AT_OP, 0);
        else simnand_arm_powercut(c->nand, c->k - 1u);
      }
      break;
    case SFFTL_EV_MOUNT_END:
      c->in_mount = 0;
      if (c->mounts == 1u && c->point == CP_NONE && c->nand)
        c->hits[CP_MOUNT_AT_OP] = (uint32_t)(simnand_ops(c->nand) - c->mount_ops0);
      break;
    case SFFTL_EV_PROG_BEGIN:
      if (c->in_mount) {
        if (ev->c >= SFFTL_PGC_META_BODY) hit(c, CP_MOUNT_DURING_CKPT);
        break;
      }
      switch (ev->c) {
        case SFFTL_PGC_HOST:
          if (c->in_destage) { hit(c, CP_DESTAGE_DURING_PROGRAM); c->in_destage = 0; }
          hit(c, CP_HOST_BEFORE_PROGRAM);
          hit(c, CP_HOST_DURING_PROGRAM);
          hit(c, CP_HOST_DURING_PROGRAM_PASS);
          hit(c, CP_HOST_DURING_PROGRAM_ALMOST);
          hit(c, CP_HOST_AFTER_PROGRAM);
          break;
        case SFFTL_PGC_RELOC:
          hit(c, CP_GC_BEFORE_RELOC);
          hit(c, CP_GC_DURING_RELOC);
          break;
        case SFFTL_PGC_COLD:
          hit(c, CP_WL_DURING_RELOC);
          break;
        case SFFTL_PGC_META_JOURNAL:
          hit(c, CP_JOURNAL_BEFORE_PROGRAM);
          hit(c, CP_JOURNAL_DURING_PROGRAM);
          hit(c, CP_JOURNAL_AFTER_PROGRAM);
          break;
        case SFFTL_PGC_META_BODY:
          hit(c, CP_CKPT_DURING_BODY);
          break;
        case SFFTL_PGC_META_COMMIT:
          hit(c, CP_CKPT_DURING_COMMIT);
          hit(c, CP_CKPT_DURING_COMMIT_PASS);
          hit(c, CP_CKPT_AFTER_COMMIT);
          break;
        default: break;
      }
      break;
    case SFFTL_EV_PROG_END:
      if (c->in_mount || ev->b != SFFTL_HAL_OK) break;
      if (ev->c == SFFTL_PGC_HOST) hit(c, CP_HOST_BEFORE_MAP_UPDATE);
      else if (ev->c == SFFTL_PGC_RELOC || ev->c == SFFTL_PGC_COLD) hit(c, CP_GC_BEFORE_MAP_UPDATE);
      break;
    case SFFTL_EV_JOURNAL_END:
      if (!c->in_mount && ev->b == 0u) hit(c, CP_JOURNAL_BEFORE_APPLY);
      break;
    case SFFTL_EV_GC_VICTIM:
      if (!c->in_mount) hit(c, CP_GC_VICTIM_CHOSEN);
      break;
    case SFFTL_EV_ERASE_BEGIN:
      if (c->in_mount) break;
      if (ev->c == SFFTL_ERC_GC) { hit(c, CP_GC_BEFORE_ERASE); hit(c, CP_GC_DURING_ERASE); }
      else if (ev->c == SFFTL_ERC_OPEN) hit(c, CP_OPEN_DURING_ERASE);
      else if (ev->c == SFFTL_ERC_META) hit(c, CP_META_DURING_ERASE);
      break;
    case SFFTL_EV_CKPT_BEGIN:
      if (!c->in_mount) hit(c, CP_CKPT_BEFORE_BODY);
      break;
    case SFFTL_EV_CKPT_BODY:
      if (!c->in_mount) hit(c, CP_CKPT_BETWEEN_BODY);
      break;
    case SFFTL_EV_CKPT_COMMIT:
      if (!c->in_mount) hit(c, CP_CKPT_BEFORE_COMMIT);
      break;
    case SFPS_EV_BEFORE_CPL:
      if (ev->b == SFPS_ST_SUCCESS) hit(c, CP_BEFORE_COMPLETION);
      break;
    case SFPS_EV_FLUSH_DONE:
      hit(c, CP_FLUSH_BEFORE_COMPLETION);
      break;
    case SFPS_EV_DESTAGE:
      c->in_destage = 1;
      break;
    default:
      break;
  }
  if (c->next) c->next(c->next_ctx, ev);
}
