/* SilicaFlux PowerSafe (Project 58) -- crash-consistency test harness (pharness.h) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include "pharness.h"

void ph_geom(sfftl_geom_t *g, uint32_t page, uint32_t ppb, uint32_t blocks) {
  g->page_data_bytes = page;
  g->page_spare_bytes = page / 32u > SFFTL_OOB_BYTES ? page / 32u : SFFTL_OOB_BYTES;
  g->pages_per_block = ppb;
  g->blocks = blocks;
}

void ph_profile_default(ph_profile_t *p) {
  p->util_permille = 900;
  p->max_len = 6;
  p->pct_trim = 6;
  p->pct_flush = 4;
  p->pct_fua = 10;
  p->pct_read = 20;
  p->pct_wce_toggle = 1;
  p->pct_idle = 3;
  p->hot_pct = 30;
}

uint64_t ph_rand(ph_t *h) {
  uint64_t z = (h->rng += 0x9E3779B97F4A7C15ull);
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
  return z ^ (z >> 31);
}

int ph_alive(const ph_t *h) { return simnand_powered(h->nand); }
int ph_violations(const ph_t *h) { return (int)simnand_stats(h->nand)->violations; }

static void attach(ph_t *h) {
  sfps_attach(&h->ps, &h->ftl);
  sfps_set_user_hook(&h->ps, sfcrash_hook, &h->cr);
}

int ph_init(ph_t *h, const sfftl_geom_t *g, const sfftl_cfg_t *cfg, const simnand_cfg_t *nc, uint64_t seed,
            uint32_t wc_pages, const char *media_path, int create, sfref_t *shared_ref) {
  memset(h, 0, sizeof(*h));
  h->g = *g;
  h->cfg = *cfg;
  h->rng = seed;
  if (nc) h->ncfg = *nc;
  else {
    simnand_cfg_default(&h->ncfg, g->page_data_bytes, g->pages_per_block, g->blocks);
    h->ncfg.torn_pass_permille = 250;
  }
  h->ncfg.page_spare_bytes = g->page_spare_bytes;
  h->nand = media_path ? simnand_open_file(&h->ncfg, seed * 7919u + 1u, media_path, create)
                       : simnand_create(&h->ncfg, seed * 7919u + 1u);
  if (!h->nand) return SFFTL_ENOMEM;
  simnand_hal(h->nand, &h->hal);
  h->arena_bytes = sfftl_mem_required(g, cfg);
  if (!h->arena_bytes) return SFFTL_EINVAL;
  h->arena = aligned_alloc(8, (h->arena_bytes + 7u) & ~(size_t)7u);
  h->wc_pages = wc_pages;
  h->wcbuf = wc_pages ? (uint8_t *)malloc((size_t)wc_pages * g->page_data_bytes) : NULL;
  sfps_init(&h->ps, NULL, h->wcbuf, wc_pages);
  sfcrash_init(&h->cr, h->nand, CP_NONE, 1);
  sfftl_opts_t o;
  memset(&o, 0, sizeof(o));
  o.hook = sfps_hook;
  o.hook_ctx = &h->ps;
  sfps_set_user_hook(&h->ps, sfcrash_hook, &h->cr);
  int rc = (media_path && !create) ? sfftl_mount_ex(&h->ftl, g, cfg, &h->hal, h->arena, h->arena_bytes, &o)
                                   : sfftl_format_ex(&h->ftl, g, cfg, &h->hal, h->arena, h->arena_bytes, &o);
  if (rc < 0) return rc;
  attach(h);
  h->mounted = 1;
  h->nlba = sfftl_capacity_lba(&h->ftl);
  if (shared_ref) h->ref = shared_ref;
  else {
    h->ref = (sfref_t *)calloc(1, sizeof(sfref_t));
    h->own_ref = 1;
    if (sfref_init(h->ref, h->nlba, cfg->lba_bytes, g->page_data_bytes / cfg->lba_bytes, NULL) < 0) return SFFTL_ENOMEM;
  }
  h->io_max = 4u * (g->page_data_bytes / cfg->lba_bytes) + 64u;
  h->io = (uint8_t *)malloc((size_t)h->io_max * cfg->lba_bytes);
  return h->io ? SFFTL_OK : SFFTL_ENOMEM;
}

void ph_free(ph_t *h) {
  simnand_destroy(h->nand);
  free(h->arena);
  free(h->wcbuf);
  free(h->io);
  if (h->own_ref && h->ref) {
    free(h->ref->l); free(h->ref->obs); free(h->ref->obsz); free(h->ref->vol); free(h->ref->ops); free(h->ref->opv);
    free(h->ref);
  }
  memset(h, 0, sizeof(*h));
}

/* ---------------------------------------------------------------- host commands */
static int exec(ph_t *h, uint8_t op, int fua, uint64_t lba, uint32_t n, void *buf, sfps_cpl_t *cpl) {
  sfps_cmd_t c;
  c.op = op; c.fua = (uint8_t)fua; c.slot = -1; c.lba = lba; c.nlb = n; c.buf = buf;
  sfps_exec(&h->ps, &c, cpl);
  h->ops++;
  return ph_alive(h);                 /* 0: the controller died before the completion reached the host */
}

int ph_write(ph_t *h, uint64_t lba, uint32_t n, int fua) {
  sfps_cpl_t cpl;
  uint32_t op = sfref_write_begin(h->ref, lba, n, h->io);
  int delivered = exec(h, SFPS_OP_WRITE, fua, lba, n, h->io, &cpl);
  int ack = SFREF_ACK_NONE;
  if (delivered && cpl.status == SFPS_ST_SUCCESS) ack = (h->wce && !fua) ? SFREF_ACK_VOLATILE : SFREF_ACK_DURABLE;
  if (delivered && cpl.status == SFPS_ST_SUCCESS && !cpl.vol != (ack == SFREF_ACK_DURABLE)) {
    /* firmware claims durability the host did not ask for (or the reverse): fine for
     * correctness, but the host only relies on what it asked for */
  }
  sfref_write_end(h->ref, op, lba, n, ack);
  /* a failed write while the device is alive: resolve its LBAs now (read back), as P56 did */
  if (delivered && cpl.status != SFPS_ST_SUCCESS && ph_alive(h)) { /* resolved by the next crash verify */ }
  return delivered ? cpl.status : SFPS_ST_ABORT_PWR_LOSS;
}

int ph_trim(ph_t *h, uint64_t lba, uint32_t n) {
  sfps_cpl_t cpl;
  sfref_trim_begin(h->ref, lba, n);
  int delivered = exec(h, SFPS_OP_DEALLOCATE, 0, lba, n, NULL, &cpl);
  sfref_trim_end(h->ref, lba, n, (delivered && cpl.status == SFPS_ST_SUCCESS) ? SFREF_ACK_DURABLE : SFREF_ACK_NONE);
  return delivered ? cpl.status : SFPS_ST_ABORT_PWR_LOSS;
}

int ph_flush(ph_t *h) {
  sfps_cpl_t cpl;
  uint32_t mark = sfref_flush_begin(h->ref);
  int delivered = exec(h, SFPS_OP_FLUSH, 0, 0, 0, NULL, &cpl);
  sfref_flush_end(h->ref, mark, delivered && cpl.status == SFPS_ST_SUCCESS);
  return delivered ? cpl.status : SFPS_ST_ABORT_PWR_LOSS;
}

int ph_set_wce(ph_t *h, int on) {
  /* host: Set Features (volatile write cache).  Turning it off flushes first,
   * so it acts like a FLUSH for the volatile acknowledgements so far. */
  uint32_t mark = sfref_flush_begin(h->ref);
  int rc = sfps_set_wce(&h->ps, on);
  int ok = rc == SFFTL_OK && ph_alive(h);
  if (!on && h->wce) sfref_flush_end(h->ref, mark, ok);
  if (ok) h->wce = on;
  return ok ? 0 : -1;
}

int ph_verify(ph_t *h, uint64_t lba, uint32_t n, int after_crash) {
  const uint32_t lb = h->cfg.lba_bytes;
  while (n) {
    uint32_t k = n < h->io_max ? n : h->io_max;
    sfps_cpl_t cpl;
    exec(h, SFPS_OP_READ, 0, lba, k, h->io, &cpl);
    if (cpl.status != SFPS_ST_SUCCESS) {
      snprintf(h->why, sizeof(h->why), "read LBA %" PRIu64 "+%u failed: status %u", lba, k, cpl.status);
      return -1;
    }
    for (uint32_t i = 0; i < k; i++) {
      if (sfref_check(h->ref, lba + i, h->io + (size_t)i * lb, after_crash)) {
        snprintf(h->why, sizeof(h->why), "%s", h->ref->why);
        return 1;
      }
    }
    h->verified_lbas += k;
    lba += k;
    n -= k;
  }
  return 0;
}

int ph_verify_all(ph_t *h, int after_crash) {
  int r = ph_verify(h, 0, (uint32_t)h->nlba, after_crash);
  if (r) return r;
  if (after_crash && sfref_check_atomic(h->ref)) {
    snprintf(h->why, sizeof(h->why), "%s", h->ref->why);
    return 1;
  }
  return 0;
}

int ph_random_op(ph_t *h, const ph_profile_t *p) {
  uint64_t range = h->nlba * p->util_permille / 1000u;
  if (range < 8) range = h->nlba;
  uint32_t r = (uint32_t)(ph_rand(h) % 100u);
  uint32_t len = 1u + (uint32_t)(ph_rand(h) % p->max_len);
  uint64_t lba = ((uint32_t)(ph_rand(h) % 100u) < p->hot_pct) ? ph_rand(h) % (range / 8u ? range / 8u : 1u)
                                                                : ph_rand(h) % range;
  if (lba + len > h->nlba) len = (uint32_t)(h->nlba - lba);
  if (sfref_vol_full(h->ref)) return ph_flush(h) == 0 ? 0 : 0;
  uint32_t a = p->pct_trim, b = a + p->pct_flush, c = b + p->pct_read, d = c + p->pct_wce_toggle, e = d + p->pct_idle;
  if (r < a) { (void)ph_trim(h, lba, len); return 0; }
  if (r < b) { (void)ph_flush(h); return 0; }
  if (r < c) {
    int v = ph_verify(h, lba, len, 0);
    if (!ph_alive(h)) return 0;                      /* a crash during the read itself */
    return v == 1 ? 1000 : (v < 0 ? v : 0);
  }
  if (r < d) { (void)ph_set_wce(h, !h->wce); return 0; }
  if (r < e) { (void)sfps_idle(&h->ps); if (ph_alive(h)) (void)sfftl_background(&h->ftl, 32); return 0; }
  (void)ph_write(h, lba, len, (uint32_t)(ph_rand(h) % 100u) < p->pct_fua);
  return 0;
}

/* ---------------------------------------------------------------- recovery */
int ph_mount(ph_t *h) {
  if (!simnand_powered(h->nand)) simnand_power_on(h->nand);
  simnand_disarm_powercut(h->nand);
  sfps_drop_cache(&h->ps);                         /* controller RAM is gone */
  h->ps.wce = h->wce;
  sfftl_opts_t o;
  memset(&o, 0, sizeof(o));
  o.hook = sfps_hook;
  o.hook_ctx = &h->ps;
  sfps_set_user_hook(&h->ps, sfcrash_hook, &h->cr);
  h->ps.ftl = &h->ftl;
  int rc = sfftl_mount_ex(&h->ftl, &h->g, &h->cfg, &h->hal, h->arena, h->arena_bytes, &o);
  h->mounted = rc == SFFTL_OK;
  if (h->mounted) attach(h);
  else h->mount_fail++;
  return rc;
}

int ph_recover(ph_t *h) {
  h->crashes++;
  sfref_crash(h->ref);                             /* unflushed volatile acks: may be lost now */
  int rc = ph_mount(h);
  if (rc != SFFTL_OK) {
    if (!ph_alive(h)) return 2;                    /* crash during the mount itself: caller recovers again */
    snprintf(h->why, sizeof(h->why), "recovery mount failed: %s", sfftl_strerror(rc));
    return 1;
  }
  h->recoveries++;
  int v = ph_verify_all(h, 1);
  if (!ph_alive(h)) return 2;
  if (v) return 1;
  int ck = sfftl_check(&h->ftl);
  if (ck != SFFTL_OK) {
    snprintf(h->why, sizeof(h->why), "FTL invariant check after recovery: %s", sfftl_strerror(ck));
    return 1;
  }
  return 0;
}
