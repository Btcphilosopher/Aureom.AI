/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- crash-consistency test harness
 *
 * The harness is the HOST: it submits commands to the PowerSafe firmware
 * layer (sfps) running on the FlashMap FTL over the simulated NAND, decides
 * the acknowledgement class of every completion from what a host knows (WCE
 * setting, FUA flag, status, and whether the controller was still alive to
 * deliver the completion), and keeps the reference model (sfref) up to date.
 * A completion is only "received" if the supply was still on after the
 * command returned: a crash inside the command (including the
 * BEFORE_COMPLETION point) means the host never saw it.
 * ===========================================================================*/
#ifndef PHARNESS_H
#define PHARNESS_H

#include <stdint.h>
#include "sfftl.h"
#include "simnand.h"
#include "sfps.h"
#include "sfcrash.h"
#include "sfref.h"

typedef struct {
  uint32_t util_permille;   /* LBA range used: fraction of capacity (GC pressure)  */
  uint32_t max_len;         /* LBAs per command, max                              */
  uint32_t pct_trim, pct_flush, pct_fua, pct_read, pct_wce_toggle, pct_idle;
  uint32_t hot_pct;         /* accesses to the first 1/8 of the range             */
} ph_profile_t;

typedef struct {
  sfftl_geom_t  g;
  sfftl_cfg_t   cfg;
  simnand_cfg_t ncfg;
  simnand_t    *nand;
  sfftl_hal_t   hal;
  sfftl_t       ftl;
  void         *arena;
  size_t        arena_bytes;
  sfps_t        ps;
  uint8_t      *wcbuf;
  uint32_t      wc_pages;
  sfcrash_t     cr;
  sfref_t      *ref;
  int           own_ref;
  uint8_t      *io;
  uint32_t      io_max;
  uint64_t      rng;
  int           wce, mounted;
  uint64_t      nlba;
  char          why[300];
  /* statistics */
  uint64_t      ops, crashes, recoveries, verified_lbas, mount_fail;
} ph_t;

void ph_geom(sfftl_geom_t *g, uint32_t page, uint32_t ppb, uint32_t blocks);
void ph_profile_default(ph_profile_t *p);
/* create device + format (media_path NULL: heap; else file-backed, create/open) */
int  ph_init(ph_t *h, const sfftl_geom_t *g, const sfftl_cfg_t *cfg, const simnand_cfg_t *nc, uint64_t seed,
             uint32_t wc_pages, const char *media_path, int create, sfref_t *shared_ref);
void ph_free(ph_t *h);
uint64_t ph_rand(ph_t *h);
int  ph_alive(const ph_t *h);

/* host commands: return the sfps status (0 = SUCCESS), the reference is updated */
int  ph_write(ph_t *h, uint64_t lba, uint32_t n, int fua);
int  ph_trim(ph_t *h, uint64_t lba, uint32_t n);
int  ph_flush(ph_t *h);
int  ph_set_wce(ph_t *h, int on);
/* read + check against the reference; after_crash resolves in-doubt LBAs */
int  ph_verify(ph_t *h, uint64_t lba, uint32_t n, int after_crash);   /* 0 ok, 1 mismatch, <0 read error */
int  ph_verify_all(ph_t *h, int after_crash);
int  ph_random_op(ph_t *h, const ph_profile_t *p);                    /* <0 / 1000 on a check failure */

/* the supply is gone (crash point fired): power on, recover, verify everything.
 * returns 0 ok, else failure (h->why) */
int  ph_recover(ph_t *h);
int  ph_mount(ph_t *h);                       /* power on + recovery mount only */
int  ph_violations(const ph_t *h);

#endif
