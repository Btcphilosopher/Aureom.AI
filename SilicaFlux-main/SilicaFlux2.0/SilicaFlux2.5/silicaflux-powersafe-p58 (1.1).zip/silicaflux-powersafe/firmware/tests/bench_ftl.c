/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- FTL-level persistence cost benchmark
 *
 * Uses only the API common to the Project 56 library and the Project 58
 * library, so the same source is built twice (tools/p56_original vs
 * silicaflux_ftl) and the cost of the Project 58 persistence changes is
 * measured, not estimated.  For each checkpoint interval:
 *   - steady state: sequential fill, then uniform-random page writes (5 %
 *     whole-page TRIMs, FLUSH every 100 commands) for 2x the capacity
 *   - metadata write amplification, journal pages, checkpoints per 1000
 *     host pages, total write amplification
 *   - recovery: repeatedly run a random number of operations, cut power at a
 *     random NAND operation, mount; the mount's modelled device time (simnand
 *     time model: tR 25 us, tPROG 200 us, tBERS 2 ms, 30 ns/byte) and
 *     operation counts are recorded; also the clean mount
 * Output: CSV lines on stdout (prefix "csv,").
 * Times are MODELLED with the illustrative NANDLab SLC values.
 * ===========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include "sfftl.h"
#include "simnand.h"

#ifndef LIBNAME
#define LIBNAME "p58"
#endif

static uint64_t rs = 1;
static uint64_t rnd(void) {
  uint64_t z = (rs += 0x9E3779B97F4A7C15ull);
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
  return z ^ (z >> 31);
}
static int cmp64(const void *a, const void *b) {
  uint64_t x = *(const uint64_t *)a, y = *(const uint64_t *)b;
  return x < y ? -1 : x > y;
}

typedef struct { const char *name; uint32_t page, ppb, blocks, lba; } geo_t;

static void run(const geo_t *G, uint32_t interval, uint32_t samples) {
  sfftl_geom_t g = { G->page, G->page / 32u > 16u ? G->page / 32u : 16u, G->ppb, G->blocks };
  sfftl_cfg_t c;
  sfftl_cfg_default(&c);
  c.lba_bytes = G->lba;
  c.ckpt_interval_blocks = interval;
  simnand_cfg_t nc;
  simnand_cfg_default(&nc, g.page_data_bytes, g.pages_per_block, g.blocks);
  nc.page_spare_bytes = g.page_spare_bytes;
  simnand_t *n = simnand_create(&nc, 42);
  sfftl_hal_t hal;
  simnand_hal(n, &hal);
  size_t ab = sfftl_mem_required(&g, &c);
  void *arena = aligned_alloc(8, (ab + 7u) & ~(size_t)7u);
  static sfftl_t f;
  if (sfftl_format(&f, &g, &c, &hal, arena, ab) != SFFTL_OK) { printf("format failed\n"); exit(1); }
  const uint64_t nl = sfftl_capacity_lba(&f);
  const uint32_t spp = g.page_data_bytes / c.lba_bytes;
  uint8_t *buf = malloc(g.page_data_bytes);
  memset(buf, 0x5A, g.page_data_bytes);
  for (uint64_t l = 0; l + spp <= nl; l += spp) sfftl_write(&f, l, spp, buf);
  /* steady state for the write-amplification numbers */
  const sfftl_stats_t *s = sfftl_stats(&f);
  uint64_t h0 = s->nand_prog_host, r0 = s->nand_prog_reloc, m0 = s->nand_prog_meta, ck0 = s->ckpt_count,
           jp0 = s->journal_pages, cp0 = s->ckpt_pages;
  uint64_t pages = nl / spp, ops = 2u * pages, trims = 0;
  for (uint64_t i = 0; i < ops; i++) {
    uint64_t lp = rnd() % pages;
    if (rnd() % 100 < 5) { sfftl_trim(&f, lp * spp, spp); trims++; }
    else { buf[0] = (uint8_t)i; sfftl_write(&f, lp * spp, spp, buf); }
    if (i % 100 == 99) sfftl_flush(&f);
  }
  uint64_t hp = s->nand_prog_host - h0, rp = s->nand_prog_reloc - r0, mp = s->nand_prog_meta - m0;
  uint64_t ck = s->ckpt_count - ck0, jp = s->journal_pages - jp0, cpg = s->ckpt_pages - cp0;
  sfftl_layout_t lay;
  sfftl_layout_info(&g, &c, &lay);
  printf("csv,wa,%s,%s,%u,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%.4f,%.4f,%.3f,%u,%u,%" PRIu64 "\n",
         LIBNAME, G->name, interval, hp, rp, mp, ck, jp, cpg, (double)mp / (double)hp, (double)(hp + rp + mp) / (double)hp,
         1000.0 * (double)ck / (double)hp, f.meta_blocks, f.ckpt_pages, (uint64_t)nl);
  /* recovery after a power cut: random distance since the last checkpoint */
  uint64_t *t = calloc(samples, 8), *rd = calloc(samples, 8);
  uint64_t span = (uint64_t)interval * g.pages_per_block * 2u;
  for (uint32_t k = 0; k < samples; k++) {
    uint64_t run_ops = rnd() % (span + 1u);
    for (uint64_t i = 0; i < run_ops; i++) {
      uint64_t lp = rnd() % pages;
      if (rnd() % 100 < 5) sfftl_trim(&f, lp * spp, spp); else sfftl_write(&f, lp * spp, spp, buf);
    }
    simnand_arm_powercut(n, rnd() % 8u);
    for (int i = 0; i < 64 && simnand_powered(n); i++) sfftl_write(&f, (rnd() % pages) * spp, spp, buf);
    simnand_power_on(n);
    simnand_disarm_powercut(n);
    uint64_t t0 = simnand_stats(n)->time_ns, r00 = simnand_stats(n)->reads;
    if (sfftl_mount(&f, &g, &c, &hal, arena, ab) != SFFTL_OK) { printf("mount failed\n"); exit(1); }
    t[k] = simnand_stats(n)->time_ns - t0;
    rd[k] = simnand_stats(n)->reads - r00;
  }
  qsort(t, samples, 8, cmp64);
  uint64_t sum = 0;
  for (uint32_t k = 0; k < samples; k++) sum += t[k];
  uint64_t rsum = 0;
  for (uint32_t k = 0; k < samples; k++) rsum += rd[k];
  sfftl_shutdown(&f);
  uint64_t t0 = simnand_stats(n)->time_ns, rc0 = simnand_stats(n)->reads;
  sfftl_mount(&f, &g, &c, &hal, arena, ab);
  uint64_t clean_t = simnand_stats(n)->time_ns - t0, clean_r = simnand_stats(n)->reads - rc0;
  printf("csv,recovery,%s,%s,%u,%u,%.3f,%.3f,%.3f,%.3f,%.1f,%.3f,%" PRIu64 "\n", LIBNAME, G->name, interval, samples,
         sum / 1e6 / samples, t[samples / 2] / 1e6, t[(samples * 99) / 100] / 1e6, t[samples - 1] / 1e6,
         (double)rsum / samples, clean_t / 1e6, clean_r);
  free(t); free(rd); free(buf); free(arena);
  simnand_destroy(n);
}

int main(int argc, char **argv) {
  uint32_t samples = argc > 1 ? (uint32_t)atoi(argv[1]) : 60u;
  static const geo_t G[] = {
    { "p51_512B", 512, 16, 64, 512 },
    { "bench_4KiB", 4096, 64, 256, 4096 },
  };
  static const uint32_t IV[] = { 4, 8, 16, 32, 64 };
  printf("# lib %s, SFFTL_VERSION %08X, schema %u\n", LIBNAME, SFFTL_VERSION, SFFTL_SCHEMA_VERSION);
  for (int gi = 0; gi < 2; gi++)
    for (int i = 0; i < 5; i++) {
      if (gi == 0 && IV[i] > 16) continue;          /* 64-block device: auto interval is 16 */
      run(&G[gi], IV[i], samples);
    }
  return 0;
}
