/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- crash-consistency test suite
 *
 * Definition of done: across reproducible injected crashes, the controller
 * reconstructs a consistent mapping and preserves every acknowledged durable
 * write.  Every crash below is identified by (geometry, seed, point, k) and is
 * replayable with:  sfps_tests --replay <geom> <seed> <point> <k>
 * ===========================================================================*/
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <time.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include "pharness.h"

static int g_quick = 0, g_verbose = 0;
static uint64_t n_checks = 0, n_fail = 0;
static const char *cur_test = "";
#define CHECK(c, ...) do { n_checks++; if (!(c)) { n_fail++; printf("  FAIL [%s] ", cur_test); printf(__VA_ARGS__); printf("\n"); } } while (0)

static double now_ms(void) {
  struct timespec t;
  clock_gettime(CLOCK_MONOTONIC, &t);
  return (double)t.tv_sec * 1e3 + (double)t.tv_nsec / 1e6;
}

/* ---------------------------------------------------------------- configurations */
typedef struct {
  const char *name;
  uint32_t page, ppb, blocks, lba, wc_pages, nA, nB;
  uint32_t util, wl_thr, flags_extra;
} gcfg_t;

static const gcfg_t G[] = {
  /* P51-class device: 512-B pages, 1 LBA per logical page */
  { "p51_512", 512, 16, 64, 512, 8, 900, 900, 880, 2, 0 },
  /* 2-KiB pages, 4 LBAs per logical page (read-modify-write, atomicity) */
  { "2k_spp4", 2048, 32, 48, 512, 8, 700, 700, 850, 2, 0 },
  /* read-back verification of every host page (VERIFIED phase) */
  { "p51_verify", 512, 16, 64, 512, 8, 600, 600, 880, 6, SFFTL_F_VERIFY_HOST_WRITE },
};
#define NG ((int)(sizeof(G) / sizeof(G[0])))

static void mk_cfg(const gcfg_t *c, sfftl_geom_t *g, sfftl_cfg_t *f) {
  ph_geom(g, c->page, c->ppb, c->blocks);
  sfftl_cfg_default(f);
  f->lba_bytes = c->lba;
  f->wl_static_threshold = c->wl_thr;
  f->wl_static_interval = 4;                         /* aggressive: static wear levelling inside short runs */
  f->flags |= c->flags_extra;
}

static void profile(ph_profile_t *p, const gcfg_t *c) {
  ph_profile_default(p);
  p->util_permille = c->util;
  p->max_len = c->page / c->lba * 2u + 2u;
}

/* ---------------------------------------------------------------- one deterministic run */
typedef struct {
  int fired;          /* the selected crash point was reached and fired       */
  int ok;             /* every check passed                                   */
  uint32_t crashes, recoveries;
  char why[320];
  uint32_t hits[CP_COUNT];
} run_t;

/* recover, tolerating crashes during the recovery itself (they are part of the test) */
static int recover_loop(ph_t *h, run_t *r) {
  for (int i = 0; i < 6; i++) {
    int rc = ph_recover(h);
    r->crashes++;
    if (rc == 0) { r->recoveries++; return 0; }
    if (rc == 1) { snprintf(r->why, sizeof(r->why), "%s", h->why); return 1; }
  }
  snprintf(r->why, sizeof(r->why), "recovery did not complete after 6 attempts");
  return 1;
}

/* run ops until the device dies or n ops are done; 1 = check failure */
static int ops(ph_t *h, const ph_profile_t *p, uint32_t n, run_t *r) {
  for (uint32_t i = 0; i < n; i++) {
    int rc = ph_random_op(h, p);
    if (rc == 1000) { snprintf(r->why, sizeof(r->why), "live read: %s", h->why); return 1; }
    if (!ph_alive(h)) return 0;
  }
  return 0;
}

static void run_one(int gi, uint64_t seed, int point, uint32_t k, run_t *r) {
  const gcfg_t *c = &G[gi];
  sfftl_geom_t g; sfftl_cfg_t f; ph_profile_t p;
  mk_cfg(c, &g, &f);
  profile(&p, c);
  memset(r, 0, sizeof(*r));
  ph_t h;
  if (ph_init(&h, &g, &f, NULL, seed, c->wc_pages, NULL, 1, NULL) != SFFTL_OK) {
    snprintf(r->why, sizeof(r->why), "init failed");
    ph_free(&h);
    return;
  }
  sfcrash_init(&h.cr, h.nand, point, k);
  int stage = 0, fail = 0;
  /* 1. prefill (sequential, write-through) */
  uint64_t range = h.nlba * c->util / 1000u;
  for (uint64_t lba = 0; lba < range && ph_alive(&h); lba += 8u)
    (void)ph_write(&h, lba, (uint32_t)((range - lba) < 8u ? range - lba : 8u), 0);
  /* 2. random operations */
  if (ph_alive(&h)) fail = ops(&h, &p, c->nA, r);
  /* 3. a scripted power cycle (part of the workload) */
  if (!fail && ph_alive(&h)) {
    stage = 1;
    simnand_arm_powercut(h.nand, ph_rand(&h) % 48u);
    for (int i = 0; i < 400 && ph_alive(&h) && !fail; i++) fail = ops(&h, &p, 1, r);
    if (ph_alive(&h)) simnand_power_off(h.nand);
    if (!fail && !h.cr.fired) fail = recover_loop(&h, r);
  }
  /* 4. more random operations */
  if (!fail && ph_alive(&h)) { stage = 2; fail = ops(&h, &p, c->nB, r); }
  if (!fail && !ph_alive(&h)) {
    /* the selected crash (or a crash during its recovery) */
    fail = recover_loop(&h, r);
    if (!fail) {
      /* repeated recovery: continue and crash again at a random operation */
      fail = ops(&h, &p, 150, r);
      if (!fail && ph_alive(&h)) {
        simnand_arm_powercut(h.nand, ph_rand(&h) % 300u);
        for (int i = 0; i < 400 && ph_alive(&h) && !fail; i++) fail = ops(&h, &p, 1, r);
        if (ph_alive(&h)) simnand_power_off(h.nand);
        if (!fail) fail = recover_loop(&h, r);
      }
    }
  }
  if (!fail && ph_violations(&h) != 0) {
    fail = 1;
    snprintf(r->why, sizeof(r->why), "%d NAND rule violations", ph_violations(&h));
  }
  (void)stage;
  r->fired = h.cr.fired;
  r->ok = !fail;
  memcpy(r->hits, h.cr.hits, sizeof(r->hits));
  ph_free(&h);
}

/* ---------------------------------------------------------------- tests */
typedef struct { uint32_t runs, fired, notreached, fails; uint32_t hits; } pstat_t;
static pstat_t g_pstat[NG][CP_COUNT];

static void sweep(int gi, uint64_t seed, uint32_t samples) {
  run_t cnt;
  run_one(gi, seed, CP_NONE, 1, &cnt);
  CHECK(cnt.ok, "%s seed %" PRIu64 ": reference run failed: %s", G[gi].name, seed, cnt.why);
  for (int pt = 1; pt < CP_COUNT; pt++) {
    uint32_t hits = cnt.hits[pt];
    pstat_t *ps = &g_pstat[gi][pt];
    if (hits > ps->hits) ps->hits = hits;
    if (hits == 0) { ps->notreached++; continue; }
    uint32_t ns = hits < samples ? hits : samples;
    for (uint32_t i = 0; i < ns; i++) {
      uint32_t k = (ns == 1) ? 1u : 1u + (uint32_t)((uint64_t)(hits - 1u) * i / (ns - 1u));
      run_t r;
      run_one(gi, seed, pt, k, &r);
      ps->runs++;
      ps->fired += (uint32_t)r.fired;
      n_checks++;
      if (!r.ok) {
        n_fail++;
        ps->fails++;
        if (ps->fails <= 3)
          printf("  FAIL [%s] replay: --replay %d %" PRIu64 " %d %u  (%s k=%u): %s\n", cur_test, gi, seed, pt, k,
                 sfcrash_name(pt), k, r.why);
      }
    }
  }
}

static void t_point_sweep(void) {
  uint32_t samples = g_quick ? 6u : 24u;
  int nseeds = g_quick ? 1 : 2;
  for (int gi = 0; gi < NG; gi++)
    for (int s = 0; s < nseeds; s++) sweep(gi, 1000u + (uint64_t)gi * 17u + (uint64_t)s, gi == 2 ? samples / 2u : samples);
  /* report per point */
  uint32_t tot = 0, fired = 0, nr = 0;
  printf("    %-30s %5s %6s %6s %6s   (per geometry: runs)\n", "crash point", "item", "runs", "fired", "fails");
  for (int pt = 1; pt < CP_COUNT; pt++) {
    uint32_t ru = 0, fi = 0, fa = 0;
    char per[96] = "";
    for (int gi = 0; gi < NG; gi++) {
      ru += g_pstat[gi][pt].runs; fi += g_pstat[gi][pt].fired; fa += g_pstat[gi][pt].fails;
      char b[24];
      snprintf(b, sizeof(b), " %s:%u", G[gi].name, g_pstat[gi][pt].runs);
      strncat(per, b, sizeof(per) - strlen(per) - 1u);
    }
    printf("    %-30s %5d %6u %6u %6u  %s\n", sfcrash_name(pt), sfcrash_brief_item(pt), ru, fi, fa, per);
    tot += ru; fired += fi;
    if (ru == 0) nr++;
  }
  printf("    %u crash runs, %u fired at their point, %u points never reached\n", tot, fired, nr);
  CHECK(nr == 0, "%u crash points never reached by the workload", nr);
  for (int item = 1; item <= 8; item++) {
    uint32_t ru = 0;
    for (int pt = 1; pt < CP_COUNT; pt++) if (sfcrash_brief_item(pt) == item) for (int gi = 0; gi < NG; gi++) ru += g_pstat[gi][pt].fired;
    CHECK(ru > 0, "brief crash item %d not exercised", item);
  }
}

/* crash at every NAND operation of a recovery mount, then recover again */
static void t_mount_sweep(void) {
  run_t cnt;
  run_one(0, 77, CP_NONE, 1, &cnt);
  uint32_t ops = cnt.hits[CP_MOUNT_AT_OP];
  CHECK(ops > 50, "recovery mount operations counted (%u)", ops);
  uint32_t step = g_quick ? (ops / 40u + 1u) : 1u, runs = 0, bad = 0;
  for (uint32_t k = 1; k <= ops; k += step) {
    run_t r;
    run_one(0, 77, CP_MOUNT_AT_OP, k, &r);
    runs++;
    if (!r.ok) { bad++; if (bad <= 3) printf("  FAIL [%s] mount op %u: %s\n", cur_test, k, r.why); }
  }
  n_checks += runs; n_fail += bad;
  printf("    recovery mount = %u NAND operations; power cut at %u of them, then recovery + repeated crash\n", ops, runs);
}

/* many random (point, k) crashes under random NAND faults */
static void t_random_campaign(void) {
  uint32_t n = g_quick ? 120u : 600u, bad = 0, fired = 0;
  ph_t dummy;
  (void)dummy;
  for (uint32_t i = 0; i < n; i++) {
    uint64_t seed = 5000u + i;
    int gi = (int)(i % 2u);
    int pt = 1 + (int)(seed * 2654435761u % (uint64_t)(CP_COUNT - 1));
    uint32_t k = 1u + (uint32_t)(seed * 40503u % 60u);
    run_t r;
    run_one(gi, seed, pt, k, &r);
    fired += (uint32_t)r.fired;
    if (!r.ok) { bad++; if (bad <= 3) printf("  FAIL [%s] --replay %d %" PRIu64 " %d %u: %s\n", cur_test, gi, seed, pt, k, r.why); }
  }
  n_checks += n; n_fail += bad;
  printf("    %u random (seed, point, k) runs, %u reached their point\n", n, fired);
}

/* NAND faults (program / erase / read) together with crashes */
static void t_faults_and_crashes(void) {
  uint32_t n = g_quick ? 40u : 200u, bad = 0, ro = 0;
  for (uint32_t i = 0; i < n; i++) {
    const gcfg_t *c = &G[0];
    sfftl_geom_t g; sfftl_cfg_t f; ph_profile_t p;
    mk_cfg(c, &g, &f);
    profile(&p, c);
    ph_t h;
    if (ph_init(&h, &g, &f, NULL, 9000u + i, c->wc_pages, NULL, 1, NULL)) { bad++; ph_free(&h); continue; }
    simnand_set_random(h.nand, 3000, 3000, 500, 2000);
    run_t r;
    memset(&r, 0, sizeof(r));
    int fail = 0;
    for (int cyc = 0; cyc < 4 && !fail; cyc++) {
      simnand_arm_powercut(h.nand, 50u + ph_rand(&h) % 600u);
      for (int j = 0; j < 800 && ph_alive(&h) && !fail; j++) fail = ops(&h, &p, 1, &r);
      if (ph_alive(&h)) simnand_power_off(h.nand);
      if (!fail) fail = recover_loop(&h, &r);
      sfftl_space_t sp;
      if (!fail && h.mounted) { sfftl_space(&h.ftl, &sp); if (sp.read_only) { ro++; break; } }
    }
    if (fail) { bad++; if (bad <= 3) printf("  FAIL [%s] seed %u: %s\n", cur_test, 9000u + i, r.why); }
    ph_free(&h);
  }
  n_checks += n; n_fail += bad;
  printf("    %u seeds x 4 crashes at fault rates 0.3%% program / 0.3%% erase / 0.05%% uncorrectable read; %u ended read-only\n", n, ro);
}

/* metadata corruption: fallback, detection, refusal -- never silent wrong data */
static int newest_commit(ph_t *h, uint32_t nth, uint32_t *ppn) {
  /* nth = 0 newest commit, 1 the one before (scan the zone; test back door) */
  uint64_t best[2] = { 0, 0 };
  uint32_t bp[2] = { SFFTL_NONE, SFFTL_NONE };
  uint8_t sp[16], *pg = (uint8_t *)malloc(h->g.page_data_bytes);
  for (uint32_t z = 0; z < h->ftl.meta_blocks; z++)
    for (uint32_t pi = 0; pi < h->g.pages_per_block; pi++) {
      uint32_t p = h->ftl.zone[z] * h->g.pages_per_block + pi, bf;
      if (simnand_read(h->nand, p, pg, sp, &bf) > 1 || sp[1] != 0xE1u || pg[4] != 2u) continue;
      uint64_t s = (uint64_t)sp[6] | ((uint64_t)sp[7] << 8) | ((uint64_t)sp[8] << 16) | ((uint64_t)sp[9] << 24) |
                   ((uint64_t)sp[10] << 32) | ((uint64_t)sp[11] << 40);
      if (s > best[0]) { best[1] = best[0]; bp[1] = bp[0]; best[0] = s; bp[0] = p; }
      else if (s > best[1]) { best[1] = s; bp[1] = p; }
    }
  free(pg);
  *ppn = bp[nth];
  return bp[nth] != SFFTL_NONE;
}

static void t_metadata_corruption(void) {
  const gcfg_t *c = &G[0];
  uint32_t ok_fallback = 0, n_fb = g_quick ? 30u : 150u;
  for (uint32_t i = 0; i < n_fb; i++) {
    sfftl_geom_t g; sfftl_cfg_t f; ph_profile_t p;
    mk_cfg(c, &g, &f);
    profile(&p, c);
    p.pct_trim = 30;                                   /* journal-heavy: the ring wraps */
    ph_t h;
    run_t r;
    memset(&r, 0, sizeof(r));
    ph_init(&h, &g, &f, NULL, 300u + i, 0, NULL, 1, NULL);
    (void)ops(&h, &p, 400u + (uint32_t)(ph_rand(&h) % 600u), &r);
    (void)ph_flush(&h);
    uint32_t cp;
    int mode = (int)(i % 3u);
    if (newest_commit(&h, 0, &cp)) {
      if (mode == 0) simnand_corrupt_page(h.nand, cp);               /* newest commit unreadable    */
      else if (mode == 1) simnand_flip_bits(h.nand, cp - 1u, 40);     /* last body page beyond ECC   */
      else simnand_miscorrect(h.nand, cp);                             /* ECC returns a wrong commit  */
    }
    simnand_power_off(h.nand);
    int rc = ph_recover(&h);
    CHECK(rc == 0, "corruption mode %d seed %u: %s", mode, 300u + i, h.why);
    if (rc == 0) {
      const sfftl_stats_t *s = sfftl_stats(&h.ftl);
      /* an unreadable / miscorrected commit never enters the catalogue: it looks
       * exactly like a commit torn by a crash, and the previous checkpoint is the
       * right one to use (reported as an incomplete newer generation).  A valid
       * commit whose body is damaged is a real fallback. */
      if (mode == 1) CHECK(s->last_mount_fallback >= 1u, "fallback reported (body damage: %u)", s->last_mount_fallback);
      else CHECK(s->last_mount_incomplete >= 1u || s->last_mount_fallback >= 1u,
                 "older checkpoint used (mode %d: incomplete %u fallback %u)", mode, s->last_mount_incomplete,
                 s->last_mount_fallback);
      sfftl_persist_t pp;
      sfftl_persist(&h.ftl, &pp);
      if (mode == 1) CHECK(pp.fallback_mounts >= 1u, "fallback counted in the persistent log");
      ok_fallback++;
    }
    ph_free(&h);
  }
  printf("    %u newest-checkpoint corruptions (unreadable commit / body beyond ECC / miscorrected commit): %u recovered by A/B fallback\n",
         n_fb, ok_fallback);
  /* both newest and previous destroyed: mount must refuse, not guess */
  {
    sfftl_geom_t g; sfftl_cfg_t f; ph_profile_t p;
    mk_cfg(c, &g, &f); profile(&p, c);
    ph_t h; run_t r; memset(&r, 0, sizeof(r));
    ph_init(&h, &g, &f, NULL, 4242, 0, NULL, 1, NULL);
    (void)ops(&h, &p, 600, &r);
    uint32_t a, b;
    if (newest_commit(&h, 0, &a) && newest_commit(&h, 1, &b)) {
      simnand_corrupt_page(h.nand, a);
      simnand_corrupt_page(h.nand, b);
      /* and every older commit */
      for (int k = 0; k < 8; k++) { uint32_t x; if (newest_commit(&h, 0, &x)) simnand_corrupt_page(h.nand, x); }
    }
    simnand_power_off(h.nand);
    int rc = ph_mount(&h);
    CHECK(rc == SFFTL_ENOFS, "every checkpoint destroyed -> mount refuses (%s), no silent guess", sfftl_strerror(rc));
    ph_free(&h);
  }
  /* a damaged journal page with valid pages after it: detected and reported */
  {
    sfftl_geom_t g; sfftl_cfg_t f; ph_profile_t p;
    mk_cfg(c, &g, &f); profile(&p, c);
    ph_t h; run_t r; memset(&r, 0, sizeof(r));
    ph_init(&h, &g, &f, NULL, 4343, 0, NULL, 1, NULL);
    (void)ops(&h, &p, 300, &r);
    (void)sfftl_checkpoint(&h.ftl);
    uint32_t j0 = SFFTL_NONE;
    for (int t = 0; t < 4; t++) {                       /* three journal pages after the checkpoint */
      uint64_t l = ph_rand(&h) % (h.nlba - 4u);
      (void)ph_write(&h, l, 1, 0);
      (void)ph_trim(&h, l, 1);
      if (t == 1) j0 = h.ftl.meta_last_ppn;
    }
    if (j0 != SFFTL_NONE) simnand_corrupt_page(h.nand, j0);
    simnand_power_off(h.nand);
    sfref_crash(h.ref);
    int rc = ph_mount(&h);
    CHECK(rc == SFFTL_OK, "mount with a damaged journal page");
    if (rc == SFFTL_OK) {
      CHECK(sfftl_stats(&h.ftl)->last_mount_meta_damaged >= 1u, "damaged metadata page detected (%u)",
            sfftl_stats(&h.ftl)->last_mount_meta_damaged);
      sfftl_event_t e;
      int found = 0;
      for (uint32_t i = 0; sfftl_event_get(&h.ftl, i, &e) == SFFTL_OK; i++) found |= e.w[0] == SFFTL_EVT_META_DAMAGE;
      CHECK(found, "META_DAMAGE event in the persistent log");
    }
    printf("    damaged journal page (media, not a tear): detected, %u page(s) reported; its records are not reconstructible\n",
           rc == SFFTL_OK ? sfftl_stats(&h.ftl)->last_mount_meta_damaged : 0u);
    ph_free(&h);
  }
}

/* the gap found in Project 56: after the metadata ring has wrapped, a damaged
 * NEWEST commit must still leave a mountable device (A/B retention) */
static void t_fallback_after_wrap(void) {
  uint32_t n = g_quick ? 120u : 300u, enofs = 0, bad = 0, runs = 0;
  for (uint32_t seed = 1; seed <= n; seed++) {
    sfftl_geom_t g; sfftl_cfg_t f; ph_profile_t p;
    mk_cfg(&G[0], &g, &f);
    profile(&p, &G[0]);
    p.pct_trim = 45;                                  /* journal-heavy: the ring turns over quickly */
    p.pct_read = 10;
    ph_t h; run_t r; memset(&r, 0, sizeof(r));
    ph_init(&h, &g, &f, NULL, 6000u + seed, 0, NULL, 1, NULL);
    (void)ops(&h, &p, 500, &r);
    /* stop at a random point within the life of the newest checkpoint */
    uint32_t gen0 = h.ftl.gen, stop = 5u + (uint32_t)(ph_rand(&h) % 120u), k = 0;
    int have = 0;
    for (int i = 0; i < 4000; i++) {
      (void)ops(&h, &p, 1, &r);
      if (h.ftl.gen != gen0) { gen0 = h.ftl.gen; have = 1; k = 0; continue; }
      if (have && ++k == stop) break;
    }
    uint32_t cp;
    if (!have || !newest_commit(&h, 0, &cp)) { ph_free(&h); continue; }
    runs++;
    simnand_corrupt_page(h.nand, cp);
    simnand_power_off(h.nand);
    int rc = ph_recover(&h);
    if (rc != 0) {
      if (h.mount_fail) enofs++; else bad++;
      if (enofs + bad <= 3) printf("  FAIL [%s] seed %u: %s\n", cur_test, 6000u + seed, h.why);
    }
    ph_free(&h);
  }
  n_checks += runs;
  n_fail += enofs + bad;
  printf("    %u runs: newest commit destroyed after the ring wrapped -> %u unmountable, %u data errors "
         "(Project 56 without A/B retention: ~5 %% unmountable)\n", runs, enofs, bad);
}

/* full device: every LBA in use, overwrite at 100 % utilisation, crash in GC */
static void t_full_storage(void) {
  uint32_t n = g_quick ? 20u : 80u, bad = 0, fired = 0;
  uint64_t erases = 0;
  for (uint32_t i = 0; i < n; i++) {
    sfftl_geom_t g; sfftl_cfg_t f; ph_profile_t p;
    mk_cfg(&G[0], &g, &f);
    profile(&p, &G[0]);
    p.util_permille = 1000;
    p.pct_trim = 0;
    p.max_len = 4;
    ph_t h; run_t r; memset(&r, 0, sizeof(r));
    ph_init(&h, &g, &f, NULL, 700u + i, 8, NULL, 1, NULL);
    for (uint64_t l = 0; l < h.nlba; l += 4) (void)ph_write(&h, l, (uint32_t)((h.nlba - l) < 4u ? h.nlba - l : 4u), 0);
    int pt = (i % 4u == 0u) ? CP_GC_DURING_RELOC : (i % 4u == 1u) ? CP_GC_DURING_ERASE :
             (i % 4u == 2u) ? CP_GC_BEFORE_MAP_UPDATE : CP_HOST_DURING_PROGRAM;
    sfcrash_init(&h.cr, h.nand, pt, 1u + (uint32_t)(ph_rand(&h) % 40u));
    int fail = ops(&h, &p, 2500, &r);
    if (!fail && !ph_alive(&h)) fail = recover_loop(&h, &r);
    if (!fail) fail = ops(&h, &p, 500, &r);
    if (!fail && !ph_alive(&h)) fail = recover_loop(&h, &r);
    if (!fail) { simnand_power_off(h.nand); fail = recover_loop(&h, &r); }
    erases += simnand_stats(h.nand)->erases;          /* device counter: survives the mounts */
    fired += (uint32_t)h.cr.fired;
    if (fail) { bad++; if (bad <= 3) printf("  FAIL [%s] seed %u point %s: %s\n", cur_test, 700u + i, sfcrash_name(pt), r.why); }
    ph_free(&h);
  }
  n_checks += n; n_fail += bad;
  CHECK(fired == n, "every full-device run reached its crash point (%u / %u)", fired, n);
  printf("    %u runs at 100%% logical utilisation, %" PRIu64 " block erases (GC), crash reached in %u: GC copy / erase / map update, host program\n",
         n, erases, fired);
}

/* GC and wear levelling together: static migrations happen and survive crashes */
static void t_gc_wl_interaction(void) {
  uint32_t n = g_quick ? 20u : 80u, bad = 0;
  uint64_t moves = 0;
  for (uint32_t i = 0; i < n; i++) {
    sfftl_geom_t g; sfftl_cfg_t f; ph_profile_t p;
    mk_cfg(&G[0], &g, &f);
    f.wl_static_threshold = 3;
    f.wl_static_interval = 8;
    profile(&p, &G[0]);
    p.hot_pct = 90;                                    /* hot/cold split drives static wear levelling */
    ph_t h; run_t r; memset(&r, 0, sizeof(r));
    ph_init(&h, &g, &f, NULL, 1300u + i, 8, NULL, 1, NULL);
    int pt = (i % 3u == 0u) ? CP_WL_DURING_RELOC : (i % 3u == 1u) ? CP_GC_DURING_RELOC : CP_GC_DURING_ERASE;
    sfcrash_init(&h.cr, h.nand, pt, 1u + (uint32_t)(ph_rand(&h) % 8u));
    for (uint64_t l = 0; l < h.nlba * 9u / 10u; l += 8) (void)ph_write(&h, l, 8, 0);
    int fail = 0;
    for (int cyc = 0; cyc < 3 && !fail; cyc++) {
      fail = ops(&h, &p, 1500, &r);
      if (!fail && !ph_alive(&h)) fail = recover_loop(&h, &r);
    }
    moves += h.ftl.st.wl_static_moves;
    if (fail) { bad++; if (bad <= 3) printf("  FAIL [%s] seed %u point %s: %s\n", cur_test, 1300u + i, sfcrash_name(pt), r.why); }
    ph_free(&h);
  }
  n_checks += n; n_fail += bad;
  CHECK(moves > 0, "static wear-levelling migrations happened (%" PRIu64 ")", moves);
  printf("    %u runs with aggressive static wear levelling: %" PRIu64 " static migrations, crashes in WL / GC copies and erases\n", n, moves);
}

/* the write-cache contract, case by case */
static void t_wce_contract(void) {
  sfftl_geom_t g; sfftl_cfg_t f;
  mk_cfg(&G[0], &g, &f);
  uint32_t lost = 0, kept = 0;
  for (int i = 0; i < 40; i++) {
    ph_t h;
    ph_init(&h, &g, &f, NULL, 1500u + (uint64_t)i, 8, NULL, 1, NULL);
    ph_set_wce(&h, 1);
    (void)ph_write(&h, 10, 1, 0);                    /* volatile ack */
    (void)ph_write(&h, 20, 1, 1);                    /* FUA: durable */
    (void)ph_write(&h, 30, 1, 0);
    (void)ph_flush(&h);                              /* 30 (and 10) durable now */
    (void)ph_write(&h, 40, 1, 0);                    /* volatile, unflushed */
    if (i & 1) (void)sfps_idle(&h.ps);              /* sometimes destaged anyway */
    simnand_power_off(h.nand);
    CHECK(ph_recover(&h) == 0, "WCE recovery: %s", h.why);
    uint8_t *b = h.io;
    sfps_cpl_t cpl;
    sfps_cmd_t c = { SFPS_OP_READ, 0, -1, 40, 1, b };
    sfps_exec(&h.ps, &c, &cpl);
    if (b[0] == 0 && b[4] == 0) lost++; else kept++;
    ph_free(&h);
  }
  printf("    acknowledged-volatile write not flushed at the crash: lost in %u / 40, present in %u / 40 (both allowed);\n"
         "    FUA, FLUSHed and WCE-off writes verified present in every run\n", lost, kept);
  CHECK(lost > 0, "unflushed volatile writes can be lost (the cache is really volatile)");
}

/* no-PLP policy: after the warning the firmware starts no program / erase */
static void t_no_plp_policy(void) {
  sfftl_geom_t g; sfftl_cfg_t f;
  mk_cfg(&G[0], &g, &f);
  ph_t h;
  run_t r; memset(&r, 0, sizeof(r));
  ph_profile_t p; profile(&p, &G[0]);
  ph_init(&h, &g, &f, NULL, 1700, 8, NULL, 1, NULL);
  ph_set_wce(&h, 1);
  (void)ops(&h, &p, 500, &r);
  uint32_t dirty = sfps_dirty_pages(&h.ps);
  const simnand_stats_t *st = simnand_stats(h.nand);
  uint64_t pr0 = st->programs, er0 = st->erases;
  sfps_power_fault(&h.ps);                          /* the warning */
  uint32_t refused = 0;
  for (int i = 0; i < 50; i++) {
    int s = ph_write(&h, (uint64_t)i, 1, i & 1);
    refused += s == SFPS_ST_ABORT_PWR_LOSS;
    (void)ph_trim(&h, (uint64_t)i + 100u, 1);
    (void)ph_flush(&h);
    (void)sfps_idle(&h.ps);
    (void)sfftl_background(&h.ftl, 64);
    (void)sfftl_checkpoint(&h.ftl);
  }
  CHECK(st->programs == pr0 && st->erases == er0, "no NAND program / erase after the warning (%" PRIu64 " / %" PRIu64 ")",
        st->programs - pr0, st->erases - er0);
  CHECK(refused == 50, "every write refused after the warning (%u)", refused);
  CHECK(ph_verify(&h, 0, 50, 0) == 0, "reads still served after the warning");
  CHECK(h.ps.st.vol_lost_at_pf == dirty, "cached pages at risk counted (%u)", dirty);
  printf("    warning with %u dirty cache pages: 0 programs, 0 erases issued afterwards; writes / trims / flushes refused\n", dirty);
  simnand_power_off(h.nand);
  CHECK(ph_recover(&h) == 0, "recovery after the warning + loss: %s", h.why);
  ph_free(&h);
}

/* persistent recovery telemetry and power-event log */
static void t_event_log(void) {
  sfftl_geom_t g; sfftl_cfg_t f;
  mk_cfg(&G[0], &g, &f);
  ph_t h;
  run_t r; memset(&r, 0, sizeof(r));
  ph_profile_t p; profile(&p, &G[0]);
  ph_init(&h, &g, &f, NULL, 1800, 0, NULL, 1, NULL);
  uint32_t unclean = 0;
  for (int i = 0; i < 12; i++) {
    (void)ops(&h, &p, 120, &r);
    if (i == 5) {                                     /* one clean shutdown in between */
      (void)sfftl_shutdown(&h.ftl);
      CHECK(ph_mount(&h) == SFFTL_OK && h.ftl.st.last_mount_clean, "clean mount");
      continue;
    }
    simnand_power_off(h.nand);
    CHECK(ph_recover(&h) == 0, "recovery %d: %s", i, h.why);
    unclean++;
  }
  sfftl_persist_t pp;
  sfftl_persist(&h.ftl, &pp);
  CHECK(pp.unsafe_shutdowns == unclean, "unsafe shutdowns persisted: %u (expected %u)", pp.unsafe_shutdowns, unclean);
  CHECK(pp.recoveries == unclean, "recoveries persisted: %u", pp.recoveries);
  sfftl_event_t e;
  uint32_t nrec = 0;
  for (uint32_t i = 0; sfftl_event_get(&h.ftl, i, &e) == SFFTL_OK; i++) nrec += e.w[0] == SFFTL_EVT_RECOVERY;
  CHECK(nrec == SFFTL_EVT_RING, "event ring holds the last %u recovery records (%u)", SFFTL_EVT_RING, nrec);
  CHECK(pp.events_total == unclean + 1u, "events recorded: %u (format + recoveries)", pp.events_total);
  /* controller diagnostics travel into the log through mount options */
  {
    sfftl_opts_t o;
    memset(&o, 0, sizeof(o));
    o.diag_valid = 1; o.diag_type = SFFTL_EVT_POWER_FAULT;
    o.diag[0] = 0x81010203u; o.diag[1] = 0x00030003u; o.diag[4] = 0x15u;
    simnand_power_off(h.nand); simnand_power_on(h.nand);
    int rc = sfftl_mount_ex(&h.ftl, &h.g, &h.cfg, &h.hal, h.arena, h.arena_bytes, &o);
    CHECK(rc == SFFTL_OK, "mount with diagnostics");
    sfftl_t *ft = &h.ftl;
    (void)sfftl_shutdown(ft);
    rc = sfftl_mount_ex(ft, &h.g, &h.cfg, &h.hal, h.arena, h.arena_bytes, NULL);
    int found = 0;
    for (uint32_t i = 0; sfftl_event_get(ft, i, &e) == SFFTL_OK; i++)
      if (e.w[0] == SFFTL_EVT_POWER_FAULT && e.w[3] == 0x81010203u && e.w[7] == 0x15u) found = 1;
    CHECK(found, "controller diagnostics persisted in the event log across a later mount");
    sfftl_persist(ft, &pp);
    CHECK(pp.pf_events == 1u, "power-fault events counted (%u)", pp.pf_events);
  }
  printf("    %u unclean + 1 clean restarts: counters, %u-entry event ring and controller diagnostics persisted\n", unclean,
         SFFTL_EVT_RING);
  ph_free(&h);
}

/* the medium in a file, the controller in a separate process that dies at the crash point */
static void *shared_alloc(size_t n) {
  void *p = mmap(NULL, n, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
  return p == MAP_FAILED ? NULL : p;
}
static void die_now(void *ctx) { (void)ctx; _exit(77); }

static void t_process_crash(void) {
  const gcfg_t *c = &G[0];
  sfftl_geom_t g; sfftl_cfg_t f; ph_profile_t p;
  mk_cfg(c, &g, &f);
  profile(&p, c);
  char path[256];
  snprintf(path, sizeof(path), "%s/sfps_media_%d.bin", getenv("TMPDIR") ? getenv("TMPDIR") : "/tmp", (int)getpid());
  /* host state shared with every controller process */
  sfref_t *ref = (sfref_t *)shared_alloc(sizeof(sfref_t));
  uint64_t *shared_wce = (uint64_t *)shared_alloc(4096);
  ph_t h0;
  if (ph_init(&h0, &g, &f, NULL, 1, c->wc_pages, path, 1, NULL) != SFFTL_OK) { CHECK(0, "create medium"); return; }
  sfref_init(ref, h0.nlba, f.lba_bytes, g.page_data_bytes / f.lba_bytes, shared_alloc);
  (void)sfftl_shutdown(&h0.ftl);
  ph_free(&h0);
  uint32_t n = g_quick ? 40u : 200u, deaths = 0, bad = 0;
  for (uint32_t it = 0; it < n; it++) {
    pid_t pid = fork();
    if (pid == 0) {
      ph_t h;
      int rc = ph_init(&h, &g, &f, NULL, 100u + it, c->wc_pages, path, 0, ref);   /* open + recovery mount */
      if (rc != SFFTL_OK) _exit(10);
      h.wce = (int)*shared_wce;
      h.ps.wce = h.wce;
      if (ph_verify_all(&h, 1) != 0) { fprintf(stderr, "child %u verify: %s\n", it, h.why); _exit(11); }
      if (sfftl_check(&h.ftl) != SFFTL_OK) _exit(12);
      simnand_set_power_loss_cb(h.nand, die_now, NULL);
      int pt = 1 + (int)((it * 2654435761u) % (CP_COUNT - 3));
      sfcrash_init(&h.cr, h.nand, pt, 1u + (uint32_t)(ph_rand(&h) % 30u));
      run_t r; memset(&r, 0, sizeof(r));
      for (int i = 0; i < 1500; i++) {
        if (ph_random_op(&h, &p) == 1000) { fprintf(stderr, "child %u live read: %s\n", it, h.why); _exit(13); }
        *shared_wce = (uint64_t)h.wce;
      }
      simnand_power_off(h.nand);                     /* point not reached: plain power loss (exits) */
      _exit(14);
    }
    int st = 0;
    waitpid(pid, &st, 0);
    int code = WIFEXITED(st) ? WEXITSTATUS(st) : -1;
    sfref_crash(ref);
    if (code == 77) deaths++;
    else { bad++; if (bad <= 3) printf("  FAIL [%s] controller process %u exited %d\n", cur_test, it, code); }
  }
  /* final check in this process */
  ph_t h;
  int rc = ph_init(&h, &g, &f, NULL, 999, c->wc_pages, path, 0, ref);
  CHECK(rc == SFFTL_OK, "final mount of the persistent medium");
  if (rc == SFFTL_OK) CHECK(ph_verify_all(&h, 1) == 0, "final verification: %s", h.why);
  ph_free(&h);
  unlink(path);
  n_checks += n; n_fail += bad;
  printf("    %u controller processes, each: open the medium file, recover, verify, run, die (_exit) at a crash point; "
         "%u died at the cut; host knowledge in shared memory; %" PRIu64 " LBA checks\n", n, deaths, ref->checks);
}

/* a medium written by the unmodified Project 56 library (schema 1) */
/* the test modifies the medium: work on a private copy */
static int copy_file(const char *src, char *dst, size_t dn, const char *tag) {
  snprintf(dst, dn, "%s/sfps_%s_%d.bin", getenv("TMPDIR") ? getenv("TMPDIR") : "/tmp", tag, (int)getpid());
  FILE *a = fopen(src, "rb"), *b = fopen(dst, "wb");
  if (!a || !b) { if (a) fclose(a); if (b) fclose(b); return -1; }
  char buf[65536];
  size_t k;
  while ((k = fread(buf, 1, sizeof(buf), a)) > 0) fwrite(buf, 1, k, b);
  fclose(a); fclose(b);
  return 0;
}

static void t_upgrade_v1(void) {
  const char *src = getenv("SFPS_P56_IMAGE");
  if (!src || access(src, R_OK) != 0) { printf("    skipped: SFPS_P56_IMAGE not set (make upgrade-test builds it)\n"); return; }
  char img[300], img2c[300];
  if (copy_file(src, img, sizeof(img), "p56copy") != 0) { CHECK(0, "copy the medium"); return; }
  sfftl_geom_t g; sfftl_cfg_t f;
  mk_cfg(&G[0], &g, &f);
  f.wl_static_threshold = 64; f.wl_static_interval = 64;     /* P56 defaults (configuration must match) */
  simnand_cfg_t nc;
  simnand_cfg_default(&nc, g.page_data_bytes, g.pages_per_block, g.blocks);
  nc.page_spare_bytes = g.page_spare_bytes;
  simnand_t *n = simnand_open_file(&nc, 5, img, 0);
  CHECK(n != NULL, "open the Project 56 medium");
  if (!n) return;
  sfftl_hal_t hal;
  simnand_hal(n, &hal);
  size_t ab = sfftl_mem_required(&g, &f);
  void *arena = aligned_alloc(8, (ab + 7u) & ~(size_t)7u);
  static sfftl_t ft;
  int rc = sfftl_mount(&ft, &g, &f, &hal, arena, ab);
  CHECK(rc == SFFTL_OK, "Project 58 mounts the schema-1 medium (%s)", sfftl_strerror(rc));
  if (rc == SFFTL_OK) {
    CHECK(sfftl_stats(&ft)->last_mount_schema == 1u, "schema 1 checkpoint loaded");
    /* the writer (tools/p56_writer) wrote LBA l with byte pattern (l * 7 + 3) and trimmed every 9th */
    uint8_t buf[512];
    uint32_t bad = 0;
    uint64_t nl = sfftl_capacity_lba(&ft);
    for (uint64_t l = 0; l < nl; l++) {
      if (sfftl_read(&ft, l, 1, buf) != SFFTL_OK) { bad++; continue; }
      uint8_t e = (l % 9u == 0u) ? 0u : (uint8_t)(l * 7u + 3u);
      for (int i = 0; i < 512; i++) if (buf[i] != e) { bad++; break; }
    }
    CHECK(bad == 0, "every LBA written by Project 56 reads back (%u bad)", bad);
    CHECK(sfftl_write(&ft, 1, 1, buf) == SFFTL_OK && sfftl_checkpoint(&ft) == SFFTL_OK, "first schema-2 checkpoint");
    rc = sfftl_mount(&ft, &g, &f, &hal, arena, ab);
    CHECK(rc == SFFTL_OK && sfftl_stats(&ft)->last_mount_schema == 2u, "upgraded to schema 2");
    sfftl_event_t e;
    int up = 0;
    for (uint32_t i = 0; sfftl_event_get(&ft, i, &e) == SFFTL_OK; i++) up |= e.w[0] == SFFTL_EVT_UPGRADE;
    CHECK(up, "UPGRADE event logged");
    printf("    Project 56 medium (%" PRIu64 " LBAs, schema 1) mounted, verified, upgraded to schema 2\n", nl);
  }
  free(arena);
  simnand_destroy(n);
  /* a Project 56 medium with P56's automatic (2*need+3) metadata zone is too
   * small for A/B retention: P58 refuses it (EGEOM) and does not touch it */
  const char *src2 = getenv("SFPS_P56_IMAGE_AUTO");
  const char *img2 = (src2 && access(src2, R_OK) == 0 && copy_file(src2, img2c, sizeof(img2c), "p56auto") == 0) ? img2c : NULL;
  unlink(img);
  if (img2) {
    simnand_t *n2 = simnand_open_file(&nc, 5, img2, 0);
    CHECK(n2 != NULL, "open the Project 56 automatic-zone medium");
    if (n2) {
      simnand_hal(n2, &hal);
      ab = sfftl_mem_required(&g, &f);
      arena = aligned_alloc(8, (ab + 7u) & ~(size_t)7u);
      uint64_t p0 = simnand_stats(n2)->programs, e0 = simnand_stats(n2)->erases;
      rc = sfftl_mount(&ft, &g, &f, &hal, arena, ab);
      CHECK(rc == SFFTL_EGEOM, "5-block P56 zone refused with EGEOM (%s)", sfftl_strerror(rc));
      CHECK(simnand_stats(n2)->programs == p0 && simnand_stats(n2)->erases == e0, "refused medium not modified");
      printf("    Project 56 medium with the automatic 5-block metadata zone: refused (%s), medium untouched\n",
             sfftl_strerror(rc));
      free(arena);
      simnand_destroy(n2);
    }
    unlink(img2);
  }
}

/* ---------------------------------------------------------------- runner */
typedef struct { const char *name; void (*fn)(void); } test_t;
static const test_t TESTS[] = {
  { "point_sweep", t_point_sweep },
  { "mount_sweep", t_mount_sweep },
  { "random_campaign", t_random_campaign },
  { "faults_and_crashes", t_faults_and_crashes },
  { "metadata_corruption", t_metadata_corruption },
  { "fallback_after_wrap", t_fallback_after_wrap },
  { "full_storage", t_full_storage },
  { "gc_wl_interaction", t_gc_wl_interaction },
  { "wce_contract", t_wce_contract },
  { "no_plp_policy", t_no_plp_policy },
  { "event_log", t_event_log },
  { "process_crash", t_process_crash },
  { "upgrade_v1", t_upgrade_v1 },
};

int main(int argc, char **argv) {
  const char *only = NULL;
  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--quick")) g_quick = 1;
    else if (!strcmp(argv[i], "-v")) g_verbose = 1;
    else if (!strcmp(argv[i], "--test") && i + 1 < argc) only = argv[++i];
    else if (!strcmp(argv[i], "--replay") && i + 4 < argc) {
      run_t r;
      int gi = atoi(argv[i + 1]);
      run_one(gi, strtoull(argv[i + 2], NULL, 0), atoi(argv[i + 3]), (uint32_t)strtoul(argv[i + 4], NULL, 0), &r);
      printf("replay %s seed %s point %s k %s: fired %d, %s %s\n", G[gi].name, argv[i + 2], sfcrash_name(atoi(argv[i + 3])),
             argv[i + 4], r.fired, r.ok ? "OK" : "FAIL", r.why);
      return r.ok ? 0 : 1;
    }
  }
  uint32_t nt = 0, tf = 0;
  for (size_t t = 0; t < sizeof(TESTS) / sizeof(TESTS[0]); t++) {
    if (only && strcmp(only, TESTS[t].name)) continue;
    cur_test = TESTS[t].name;
    uint64_t c0 = n_checks, f0 = n_fail;
    double t0 = now_ms();
    printf("[ RUN  ] %s\n", cur_test);
    fflush(stdout);
    TESTS[t].fn();
    nt++;
    if (n_fail != f0) tf++;
    printf("RESULT %-22s %s %7" PRIu64 " checks %9.0f ms\n", cur_test, n_fail == f0 ? "PASS" : "FAIL", n_checks - c0,
           now_ms() - t0);
    fflush(stdout);
  }
  printf("SUMMARY %u tests, %u failed, %" PRIu64 " checks, %" PRIu64 " failed checks%s\n", nt, tf, n_checks, n_fail,
         g_quick ? " (quick)" : "");
  return tf ? 1 : 0;
}
