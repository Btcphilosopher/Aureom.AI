/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- command completion latency benchmark
 *
 * Latency of a command = modelled NAND device time (simnand: tR 25 us,
 * tPROG 200 us, tBERS 2 ms, 30 ns/byte bus) spent between its submission to
 * the PowerSafe layer and its completion (firmware CPU time and the
 * controller's gate cycles are not included; the gate adds 2 clock cycles).
 * Modes, steady state on the 4-KiB bench device (uniform random 4-KiB writes,
 * 90 % logical fill):
 *   write-through (WCE off: every acknowledged write is durable)
 *   WCE on: acknowledged-volatile writes, FLUSH every 16 writes
 *   WCE on + FUA writes
 *   write-through + read-back verification (SFFTL_F_VERIFY_HOST_WRITE)
 *   DEALLOCATE (journal page before acknowledgement)
 * Output: CSV lines (prefix "csv,") with percentiles in microseconds, and a
 * latency CDF per mode for the charts.
 * ===========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include "sfftl.h"
#include "simnand.h"
#include "sfps.h"

static uint64_t rs = 7;
static uint64_t rnd(void) {
  uint64_t z = (rs += 0x9E3779B97F4A7C15ull);
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
  return z ^ (z >> 31);
}
static int cmp64(const void *a, const void *b) {
  uint64_t x = *(const uint64_t *)a, y = *(const uint64_t *)b;
  return x < y ? -1 : x > y;
}

typedef struct { const char *name; int wce, fua, verify, op; } mode_t2;

static void pct(const char *mode, const char *what, uint64_t *v, uint32_t n, FILE *cdf) {
  qsort(v, n, 8, cmp64);
  uint64_t sum = 0;
  for (uint32_t i = 0; i < n; i++) sum += v[i];
  printf("csv,latency,%s,%s,%u,%.1f,%.1f,%.1f,%.1f,%.1f\n", mode, what, n, sum / 1e3 / n, v[n / 2] / 1e3,
         v[(n * 99) / 100] / 1e3, v[(n * 999) / 1000] / 1e3, v[n - 1] / 1e3);
  if (cdf)
    for (uint32_t i = 0; i < 200; i++) {
      uint32_t k = (uint32_t)((uint64_t)i * (n - 1) / 199u);
      fprintf(cdf, "%s,%s,%.4f,%.1f\n", mode, what, (double)i / 199.0, v[k] / 1e3);
    }
}

int main(int argc, char **argv) {
  const char *cdfpath = argc > 1 ? argv[1] : NULL;
  FILE *cdf = cdfpath ? fopen(cdfpath, "w") : NULL;
  if (cdf) fprintf(cdf, "mode,what,quantile,us\n");
  static const mode_t2 M[] = {
    { "write_through", 0, 0, 0, SFPS_OP_WRITE },
    { "wce_volatile", 1, 0, 0, SFPS_OP_WRITE },
    { "wce_fua", 1, 1, 0, SFPS_OP_WRITE },
    { "write_through_verify", 0, 0, 1, SFPS_OP_WRITE },
    { "deallocate", 0, 0, 0, SFPS_OP_DEALLOCATE },
  };
  const uint32_t N = 20000;
  for (int mi = 0; mi < 5; mi++) {
    sfftl_geom_t g = { 4096, 128, 64, 256 };
    sfftl_cfg_t c;
    sfftl_cfg_default(&c);
    c.lba_bytes = 4096;
    if (M[mi].verify) c.flags |= SFFTL_F_VERIFY_HOST_WRITE;
    simnand_cfg_t nc;
    simnand_cfg_default(&nc, g.page_data_bytes, g.pages_per_block, g.blocks);
    nc.page_spare_bytes = g.page_spare_bytes;
    simnand_t *n = simnand_create(&nc, 11);
    sfftl_hal_t hal;
    simnand_hal(n, &hal);
    size_t ab = sfftl_mem_required(&g, &c);
    void *arena = aligned_alloc(8, (ab + 7u) & ~(size_t)7u);
    static sfftl_t f;
    sfftl_format(&f, &g, &c, &hal, arena, ab);
    static uint8_t wc[16 * 4096];
    sfps_t p;
    sfps_init(&p, NULL, wc, 16);
    sfps_attach(&p, &f);
    uint64_t pages = sfftl_capacity_lba(&f) * 9u / 10u;
    uint8_t buf[4096];
    memset(buf, 0x3C, sizeof(buf));
    sfps_cpl_t cpl;
    for (uint64_t l = 0; l < pages; l++) { sfps_cmd_t cm = { SFPS_OP_WRITE, 0, -1, l, 1, buf }; sfps_exec(&p, &cm, &cpl); }
    for (uint64_t i = 0; i < pages; i++) { sfps_cmd_t cm = { SFPS_OP_WRITE, 0, -1, rnd() % pages, 1, buf }; sfps_exec(&p, &cm, &cpl); }
    sfps_set_wce(&p, M[mi].wce);
    uint64_t *lat = calloc(N, 8), *fl = calloc(N, 8);
    uint32_t nf = 0;
    for (uint32_t i = 0; i < N; i++) {
      uint64_t lba = rnd() % pages;
      sfps_cmd_t cm = { (uint8_t)M[mi].op, (uint8_t)M[mi].fua, -1, lba, 1, buf };
      if (M[mi].op == SFPS_OP_DEALLOCATE) {          /* re-write so every DEALLOCATE has something to unmap */
        sfps_cmd_t w = { SFPS_OP_WRITE, 0, -1, lba, 1, buf };
        sfps_exec(&p, &w, &cpl);
      }
      uint64_t t0 = simnand_stats(n)->time_ns;
      sfps_exec(&p, &cm, &cpl);
      lat[i] = simnand_stats(n)->time_ns - t0;
      if (M[mi].wce && i % 16 == 15) {
        sfps_cmd_t fc = { SFPS_OP_FLUSH, 0, -1, 0, 0, NULL };
        t0 = simnand_stats(n)->time_ns;
        sfps_exec(&p, &fc, &cpl);
        fl[nf++] = simnand_stats(n)->time_ns - t0;
      }
    }
    pct(M[mi].name, M[mi].op == SFPS_OP_WRITE ? "write" : "deallocate", lat, N, cdf);
    if (nf) pct(M[mi].name, "flush16", fl, nf, cdf);
    const sfftl_stats_t *s = sfftl_stats(&f);
    printf("csv,psstats,%s,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%" PRIu64 "\n", M[mi].name,
           p.st.destages, p.st.evictions, p.st.flush_destages, s->journal_pages, s->verify_host_reads, s->ckpt_count);
    free(lat); free(fl); free(arena);
    simnand_destroy(n);
  }
  if (cdf) fclose(cdf);
  return 0;
}
