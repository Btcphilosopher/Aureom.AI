/* =============================================================================
 * SilicaFlux FlashMap (Project 56) -- persistence schema (on-NAND formats)
 *
 * Schema version 1.  All multi-byte fields are little endian and are encoded /
 * decoded byte by byte (no structure punning), so the format is identical on
 * the RV32IM firmware and on the host tools.  docs/07_PERSISTENCE.md explains
 * the design; this header is the normative definition.
 *
 * ---------------------------------------------------------------------------
 * 1. Spare (OOB) record -- every page the FTL programs, 16 bytes
 *
 *   off  size  field
 *    0    1    BBM     always 0xFF.  The manufacturer bad-block marker lives
 *                      here (pages 0 and last); the FTL never writes it.
 *    1    1    TYPE    0xD1 host data, 0xD2 relocated data (GC / wear / refresh),
 *                      0xE1 metadata page
 *    2    4    TAG     data: logical page number (LPN)
 *                      metadata: kind << 24 | index
 *    6    6    SEQ     48-bit global sequence number.  Every program of every
 *                      page (data or metadata) takes the next value, so SEQ
 *                      totally orders all events on the medium.
 *   12    4    CRC     CRC-32 (IEEE 802.3 reflected, init/xorout 0xFFFFFFFF)
 *                      over  page data || spare[1..11]
 *
 *   An all-0xFF spare marks an erased page.  A page whose CRC does not match
 *   (interrupted program, interrupted erase, corruption) is ignored.
 *
 * 2. Metadata pages -- page data starts with a 16-byte header
 *
 *    0  4  magic  'SFMT' (0x544D4653)
 *    4  2  kind   1 checkpoint body, 2 checkpoint commit, 3 journal
 *    6  2  schema SFFTL_SCHEMA_VERSION
 *    8  4  gen    checkpoint generation (body / commit: its own; journal:
 *                 generation of the checkpoint it follows)
 *   12  4  index  body: page index inside the body; journal: running counter
 *
 * 3. Checkpoint = body pages followed by ONE commit page (commit written last;
 *    a checkpoint without a valid commit does not exist).
 *    Body payload is a stream of 32-bit words packed (page_data_bytes-16)/4
 *    per page:  nlpn L2P entries (PPN, 0xFFFFFFFF = unmapped), then two words
 *    per physical block: erase count, and state | flags << 8 | wp << 16.
 *    Commit payload: see SFFTL_CK_W_* word offsets below.
 *
 * 4. Journal page payload: word 0 = record count, then 3-word records
 *    { type, a, b } (SFFTL_J_*).  Records describe events that the data pages
 *    do not record themselves: deallocation, erase counts, block retirement.
 * ===========================================================================*/
#ifndef SFFTL_SCHEMA_H
#define SFFTL_SCHEMA_H

#include <stdint.h>

#define SFFTL_SCHEMA_VERSION   1u

/* ---- spare record */
#define SFFTL_OOB_BBM          0u
#define SFFTL_OOB_TYPE         1u
#define SFFTL_OOB_TAG          2u
#define SFFTL_OOB_SEQ          6u
#define SFFTL_OOB_CRC          12u
#define SFFTL_OOB_TYPE_HOST    0xD1u
#define SFFTL_OOB_TYPE_RELOC   0xD2u
#define SFFTL_OOB_TYPE_META    0xE1u
#define SFFTL_SEQ_MASK         0xFFFFFFFFFFFFull   /* 48 bits */

/* ---- metadata page header */
#define SFFTL_META_MAGIC       0x544D4653u         /* "SFMT" */
#define SFFTL_META_HDR_BYTES   16u
#define SFFTL_MK_BODY          1u
#define SFFTL_MK_COMMIT        2u
#define SFFTL_MK_JOURNAL       3u

/* ---- checkpoint commit payload: 32-bit word offsets after the header */
#define SFFTL_CK_W_CKPT_SEQ    0u    /* 2 words: every event with SEQ <= this is in the checkpoint */
#define SFFTL_CK_W_NEXT_SEQ    2u    /* 2 words: first SEQ not yet used when the snapshot was taken */
#define SFFTL_CK_W_PAGE_DATA   4u
#define SFFTL_CK_W_PAGE_SPARE  5u
#define SFFTL_CK_W_PPB         6u
#define SFFTL_CK_W_BLOCKS      7u
#define SFFTL_CK_W_LBA_BYTES   8u
#define SFFTL_CK_W_NLBA        9u    /* 2 words */
#define SFFTL_CK_W_NLPN        11u
#define SFFTL_CK_W_META_BLOCKS 12u
#define SFFTL_CK_W_FLAGS       13u   /* SFFTL_CKF_* */
#define SFFTL_CK_W_BODY_PAGES  14u
#define SFFTL_CK_W_BODY_CRC    15u
#define SFFTL_CK_W_NRUNS       16u
#define SFFTL_CK_W_RUNS        17u   /* NRUNS x { start PPN, page count } */
#define SFFTL_CK_MAX_RUNS      32u
#define SFFTL_CK_W_LIFE        (SFFTL_CK_W_RUNS + 2u * SFFTL_CK_MAX_RUNS)  /* lifetime counters, 2 words each: */
#define SFFTL_CK_LIFE_HOST_LBA 0u    /*   LBAs written by the host            */
#define SFFTL_CK_LIFE_PROG     2u    /*   NAND page programs (all causes)     */
#define SFFTL_CK_LIFE_ERASE    4u    /*   NAND block erases                   */
#define SFFTL_CK_LIFE_MOUNTS   6u    /*   mounts                              */
#define SFFTL_CK_W_END         (SFFTL_CK_W_LIFE + 8u)
#define SFFTL_CKF_CLEAN        0x1u  /* written by shutdown: nothing follows on the medium */

/* ---- checkpoint body: per-block record word 1 */
#define SFFTL_BR_STATE(w)      ((w) & 0xFFu)
#define SFFTL_BR_FLAGS(w)      (((w) >> 8) & 0xFFu)
#define SFFTL_BR_WP(w)         ((w) >> 16)

/* ---- journal records */
#define SFFTL_J_TRIM           1u    /* a = first LPN, b = count            (applied in SEQ order) */
#define SFFTL_J_ERASE          2u    /* a = PBN, b = erase count after the erase                  */
#define SFFTL_J_RETIRE         3u    /* a = PBN, b = reason (SFFTL_RETIRE_*): block is bad now     */
#define SFFTL_J_PRETIRE        4u    /* a = PBN: relocate the block's data, then retire it         */
#define SFFTL_J_MOUNT          5u    /* a = mount count: medium is being modified after a clean shutdown */
#define SFFTL_J_REC_WORDS      3u

#define SFFTL_RETIRE_PROGRAM   1u
#define SFFTL_RETIRE_ERASE     2u
#define SFFTL_RETIRE_READ      3u

#endif /* SFFTL_SCHEMA_H */
