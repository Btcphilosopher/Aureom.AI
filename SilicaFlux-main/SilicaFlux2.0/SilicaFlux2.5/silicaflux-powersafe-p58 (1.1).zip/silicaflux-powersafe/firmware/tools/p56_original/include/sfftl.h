/* =============================================================================
 * SilicaFlux FlashMap (Project 56) -- page-mapping Flash Translation Layer
 * Aureom.AI | SilicaFlux-STORE
 *
 * Public API.  Portable C99, freestanding (no malloc, no libc beyond
 * memcpy/memset), single-threaded, synchronous.  Runs on the ControlCore
 * RV32IM firmware processor (hal/sfs) and on a host (hal/sim).
 *
 * Address translation:  LBA --(/ sectors_per_page)--> logical page (LPN)
 *                       --(L2P table)--> physical page (PPN) --(HAL)--> NAND
 * Mapping granularity: ONE L2P entry per logical page; a logical page is the
 * data area of one physical NAND page (page_data_bytes) and holds
 * page_data_bytes / lba_bytes logical blocks.  Writes smaller than a logical
 * page are read-modify-write.
 *
 * Durability contract (docs/03_WRITE_PATH.md, docs/07_PERSISTENCE.md):
 *   sfftl_write  returns SFFTL_OK only after every page it touched has been
 *                programmed, the program status confirmed and the mapping
 *                committed.  Each page carries its LPN and a global sequence
 *                number in the spare area, so an acknowledged write survives
 *                power loss without a checkpoint (recovered by roll-forward).
 *   sfftl_trim   returns SFFTL_OK only after its journal record is programmed.
 *   Multi-page writes are not atomic as a whole; each logical page is.
 * ===========================================================================*/
#ifndef SFFTL_H
#define SFFTL_H

#include <stdint.h>
#include <stddef.h>
#include "sfftl_hal.h"
#include "sfftl_schema.h"

#define SFFTL_VERSION 0x00560100u  /* Project 56, library 1.0 */

/* ---------------------------------------------------------------- status codes */
enum sfftl_rc {
  SFFTL_OK       = 0,
  SFFTL_EINVAL   = -1,   /* bad argument or configuration                                   */
  SFFTL_ERANGE   = -2,   /* LBA range outside the namespace                                 */
  SFFTL_EIO      = -3,   /* data unreadable (uncorrectable, CRC / LPN mismatch)             */
  SFFTL_ENOSPC   = -4,   /* no physical space: garbage collection cannot make progress      */
  SFFTL_EROFS    = -5,   /* read-only: degraded (bad blocks, metadata zone exhausted)       */
  SFFTL_EPOWER   = -6,   /* power lost / power-fail in progress: operation NOT acknowledged */
  SFFTL_ENOFS    = -7,   /* no valid FTL metadata on the medium                             */
  SFFTL_ECORRUPT = -8,   /* metadata inconsistent or internal invariant violated            */
  SFFTL_ENOMEM   = -9,   /* arena too small                                                 */
  SFFTL_EGEOM    = -10,  /* medium was formatted with a different geometry / configuration  */
  SFFTL_ESTATE   = -11   /* not mounted                                                     */
};

/* ---------------------------------------------------------------- geometry */
typedef struct {
  uint32_t page_data_bytes;   /* user bytes per page: 512 .. 16384, power of two        */
  uint32_t page_spare_bytes;  /* spare bytes per page, >= SFFTL_OOB_BYTES               */
  uint32_t pages_per_block;   /* 4 .. 1024                                              */
  uint32_t blocks;            /* physical blocks behind the HAL (flattened), <= 65535   */
} sfftl_geom_t;

/* ---------------------------------------------------------------- configuration */
typedef enum { SFFTL_GC_GREEDY = 0, SFFTL_GC_COST_BENEFIT = 1 } sfftl_gc_policy_t;
typedef enum {
  SFFTL_WL_NONE           = 0,  /* free block = lowest index (baseline for measurement)  */
  SFFTL_WL_DYNAMIC        = 1,  /* free block = lowest erase count                       */
  SFFTL_WL_DYNAMIC_STATIC = 2   /* dynamic + migrate cold data off low-wear blocks       */
} sfftl_wl_policy_t;

#define SFFTL_F_VERIFY_GC_COPY  (1u << 0)  /* read back every relocated page before commit   */
#define SFFTL_F_PARANOID        (1u << 1)  /* full L2P scan before every erase of a GC victim */
#define SFFTL_F_VERIFY_READ_CRC (1u << 2)  /* check the page CRC on host reads (LPN always)   */
#define SFFTL_F_ALLOW_REBUILD   (1u << 3)  /* mount: rebuild from spare records if no valid checkpoint */
#define SFFTL_F_PACED_GC        (1u << 4)  /* incremental GC interleaved with host writes (bounds tail latency) */

typedef struct {
  uint32_t lba_bytes;            /* logical block size (512, 1024, 2048, 4096...), divides page_data_bytes */
  uint64_t nlba;                 /* namespace capacity in LBAs; 0 = maximum for op_permille */
  uint32_t op_permille;          /* over-provisioning, per mille of the data pages            */
  uint32_t meta_blocks;          /* metadata-log blocks; 0 = automatic (minimum is enforced)  */
  uint32_t gc_reserve_blocks;    /* free blocks only relocation may consume (>= 2)            */
  uint32_t gc_fg_free_blocks;    /* foreground GC before a host block opens at <= this        */
  uint32_t gc_bg_free_blocks;    /* sfftl_background() collects up to this many free blocks   */
  sfftl_gc_policy_t gc_policy;
  sfftl_wl_policy_t wl_policy;
  uint32_t wl_static_threshold;  /* static migration when max EC - min EC (data blocks) > this */
  uint32_t wl_static_interval;   /* erases between two static wear-levelling checks           */
  uint32_t ckpt_interval_blocks; /* automatic checkpoint after this many blocks were opened   */
  uint32_t read_retries;         /* extra read attempts after an uncorrectable read           */
  uint32_t refresh_bitflips;     /* corrected bits that queue a block for refresh (0 = off)   */
  uint32_t flags;                /* SFFTL_F_*                                                 */
} sfftl_cfg_t;

/* ---------------------------------------------------------------- statistics */
typedef struct {
  uint64_t host_write_cmds, host_read_cmds, host_trim_cmds, host_flush_cmds;
  uint64_t host_lba_written, host_lba_read, host_lba_trimmed;
  uint64_t host_pages_written;           /* logical pages programmed for the host (incl. RMW)  */
  uint64_t rmw_reads, unmapped_reads;
  uint64_t nand_prog_host, nand_prog_reloc, nand_prog_meta;
  uint64_t nand_read_host, nand_read_reloc, nand_read_meta, nand_read_mount, nand_read_verify;
  uint64_t nand_erase_data, nand_erase_meta;
  uint64_t gc_victims, gc_pages_moved, gc_fg_runs, gc_bg_runs, gc_zero_valid, gc_paced_victims;
  uint64_t wl_static_moves, wl_static_pages, refresh_moves, retire_moves;
  uint64_t ckpt_count, ckpt_pages, journal_pages, journal_records;
  uint64_t prog_fail, erase_fail, read_uncorrectable, read_corrected, read_retry_ok, crc_errors, lpn_mismatch;
  uint64_t blocks_retired, pages_stranded;
  uint64_t mount_clean, mount_unclean, mount_rebuild;
  uint32_t last_mount_pages_scanned, last_mount_pages_replayed, last_mount_torn, last_mount_reads;
  uint32_t last_mount_journal_records, last_mount_ckpt_gen;
} sfftl_stats_t;

typedef struct {
  uint32_t blocks_total, blocks_meta, blocks_bad_factory, blocks_bad_grown;
  uint32_t blocks_free, blocks_free_erased, blocks_open, blocks_closed, blocks_reserved_gc;
  uint64_t pages_valid, pages_invalid, pages_writable;   /* writable = erased pages in open blocks + free blocks */
  uint64_t nlba, nlpn;
  uint32_t read_only;                                     /* degraded: writes refused, reads served */
  uint32_t ec_min, ec_max;                                /* over non-bad blocks (data + metadata) */
  uint64_t ec_sum;
  uint32_t ec_blocks;
} sfftl_space_t;

/* ---------------------------------------------------------------- FTL instance
 * Treat as opaque.  Declared here so firmware can allocate it statically. */
typedef struct {
  uint32_t ec;         /* erase count                                        */
  uint32_t close_seq;  /* low 32 bits of SEQ when the block was closed (age) */
  uint16_t valid;      /* valid pages                                        */
  uint16_t wp;         /* pages programmed since the last erase              */
  uint8_t  state;      /* SFFTL_BS_*                                         */
  uint8_t  flags;      /* SFFTL_BF_*                                         */
  uint8_t  stream;     /* open stream id                                     */
  uint8_t  rsvd;
} sfftl_blk_t;

#define SFFTL_NSTREAMS 3u   /* host, relocation (GC), cold (static wear levelling) */

typedef struct sfftl {
  sfftl_geom_t g;
  sfftl_cfg_t  cfg;
  sfftl_hal_t  hal;
  uint32_t spp, spp_shift;          /* LBAs per logical page */
  uint32_t nlpn;
  uint64_t nlba;
  uint32_t total_pages, ppb_shift;
  uint32_t meta_blocks, ckpt_pages, body_words_pp, body_words;
  /* arena */
  uint32_t    *l2p;                 /* nlpn entries                                 */
  uint32_t    *vbm;                 /* valid-page bitmap, 1 bit per physical page   */
  sfftl_blk_t *blk;                 /* per physical block                           */
  uint32_t    *zone;                /* metadata zone: PBN of every metadata block   */
  uint8_t     *buf_host;            /* page buffer: host read-modify-write           */
  uint8_t     *buf_gc;              /* page buffer: relocation (GC may run inside a host write) */
  uint8_t     *buf_meta;            /* page buffer: metadata pages, read-back verify */
  uint32_t    *jrec;                /* pending journal records                      */
  uint32_t    *scratch;             /* mount-time scratch                           */
  uint32_t     scratch_words, jcap;
  /* state */
  int      mounted, read_only, ps_state, clean_on_media;
  volatile int ps_warned;           /* set by sfftl_ps_warn() (ISR-safe)            */
  uint64_t next_seq;
  uint32_t gen, jpage_counter;
  uint32_t stream_blk[SFFTL_NSTREAMS];
  uint32_t free_blocks;
  uint32_t mz_head, mz_wp, mz_live_start;  /* metadata ring: zone indices + write page */
  uint32_t meta_last_ppn;           /* PPN of the last metadata page programmed     */
  uint32_t jn, jn_keep;
  uint32_t opened_since_ckpt, erases_since_wl;
  int      ckpt_pending, in_ckpt, in_meta;
  uint32_t ckpt_interval;           /* effective automatic-checkpoint interval      */
  uint32_t gc_victim, gc_cursor, gc_pace;   /* paced GC: victim in progress           */
  uint64_t life_host_lba, life_prog, life_erase, life_mounts;
  sfftl_stats_t st;
} sfftl_t;

/* block states and flags (visible for reporting) */
#define SFFTL_BS_FREE    0u   /* no valid data; erased if SFFTL_BF_ERASED          */
#define SFFTL_BS_OPEN    1u   /* write frontier of a stream                        */
#define SFFTL_BS_CLOSED  2u   /* holds data (some pages may be invalid)            */
#define SFFTL_BS_META    3u   /* metadata zone                                     */
#define SFFTL_BS_BAD     4u   /* factory or grown bad: never programmed or erased  */
#define SFFTL_BF_ERASED  0x01u
#define SFFTL_BF_FACTORY 0x02u
#define SFFTL_BF_GROWN   0x04u
#define SFFTL_BF_RETIRE  0x08u   /* relocate valid data, then retire              */
#define SFFTL_BF_REFRESH 0x10u   /* relocate valid data (high corrected bit count) */

#define SFFTL_NONE 0xFFFFFFFFu

/* memory plan for a geometry + configuration (no device access) */
typedef struct {
  uint32_t meta_blocks;      /* metadata-log blocks                                  */
  uint32_t nlpn_max;         /* logical pages with no factory-bad block              */
  uint32_t ckpt_pages;       /* pages per checkpoint (body + commit) at nlpn_max     */
  size_t   l2p_bytes, vbm_bytes, blk_bytes, buf_bytes, journal_bytes, scratch_bytes, total_bytes;
} sfftl_layout_t;

/* ---------------------------------------------------------------- API */
void        sfftl_cfg_default(sfftl_cfg_t *cfg);
size_t      sfftl_mem_required(const sfftl_geom_t *g, const sfftl_cfg_t *cfg);
int         sfftl_layout_info(const sfftl_geom_t *g, const sfftl_cfg_t *cfg, sfftl_layout_t *out);

/* format: scan factory bad-block markers (before any erase), erase every good
 * block, write generation-1 checkpoint.  The instance is mounted afterwards. */
int sfftl_format(sfftl_t *f, const sfftl_geom_t *g, const sfftl_cfg_t *cfg, const sfftl_hal_t *hal,
                 void *arena, size_t arena_bytes);
/* mount: newest valid checkpoint + journal + roll-forward of the spare records */
int sfftl_mount(sfftl_t *f, const sfftl_geom_t *g, const sfftl_cfg_t *cfg, const sfftl_hal_t *hal,
                void *arena, size_t arena_bytes);

int sfftl_read(sfftl_t *f, uint64_t lba, uint32_t nlb, void *buf);
int sfftl_write(sfftl_t *f, uint64_t lba, uint32_t nlb, const void *buf);
int sfftl_trim(sfftl_t *f, uint64_t lba, uint32_t nlb);
int sfftl_flush(sfftl_t *f);        /* make pending journal records durable (data already is) */
int sfftl_checkpoint(sfftl_t *f);   /* write a full checkpoint now                            */
int sfftl_shutdown(sfftl_t *f);     /* clean checkpoint; instance unmounted                   */
int sfftl_background(sfftl_t *f, uint32_t budget_pages);  /* idle work; returns pages moved or <0 */

uint64_t             sfftl_capacity_lba(const sfftl_t *f);
const sfftl_stats_t *sfftl_stats(const sfftl_t *f);
void                 sfftl_space(const sfftl_t *f, sfftl_space_t *s);
int                  sfftl_check(sfftl_t *f);      /* full invariant check (RAM structures) */
const char          *sfftl_strerror(int rc);

#endif /* SFFTL_H */
