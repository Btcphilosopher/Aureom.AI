/* =============================================================================
 * SilicaFlux FlashMap (Project 56) -- internal declarations shared by the src/ files
 * ===========================================================================*/
#ifndef SFFTL_INTERNAL_H
#define SFFTL_INTERNAL_H

#include "sfftl.h"
#include "sfftl_powersafe.h"

#if defined(__STDC_HOSTED__) && __STDC_HOSTED__
#include <string.h>
#else
void *memcpy(void *d, const void *s, size_t n);
void *memset(void *d, int c, size_t n);
int   memcmp(const void *a, const void *b, size_t n);
#endif

/* streams */
#define ST_HOST  0u
#define ST_RELOC 1u
#define ST_COLD  2u

/* limits */
#define SFFTL_MIN_META_BLOCKS 4u
#define SFFTL_PROG_ATTEMPTS   4u
#define SFFTL_REC_PER_PAGE(f) ((((f)->g.page_data_bytes - SFFTL_META_HDR_BYTES) / 4u - 1u) / SFFTL_J_REC_WORDS)

/* ---------------------------------------------------------------- little-endian helpers */
static inline void le32_put(uint8_t *p, uint32_t v) {
  p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24);
}
static inline uint32_t le32_get(const uint8_t *p) {
  return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static inline void le48_put(uint8_t *p, uint64_t v) {
  le32_put(p, (uint32_t)v);
  p[4] = (uint8_t)(v >> 32); p[5] = (uint8_t)(v >> 40);
}
static inline uint64_t le48_get(const uint8_t *p) {
  return (uint64_t)le32_get(p) | ((uint64_t)p[4] << 32) | ((uint64_t)p[5] << 40);
}

/* ---------------------------------------------------------------- CRC-32 (ftl_util.c) */
uint32_t sfftl_crc32_update(uint32_t crc, const void *data, uint32_t len);
#define SFFTL_CRC_INIT 0xFFFFFFFFu
#define SFFTL_CRC_FINAL(c) ((c) ^ 0xFFFFFFFFu)

/* ---------------------------------------------------------------- address helpers */
static inline uint32_t ppn_blk(const sfftl_t *f, uint32_t ppn) { return ppn >> f->ppb_shift; }
static inline uint32_t ppn_pg(const sfftl_t *f, uint32_t ppn)  { return ppn & (f->g.pages_per_block - 1u); }
static inline uint32_t mk_ppn(const sfftl_t *f, uint32_t b, uint32_t p) { return (b << f->ppb_shift) | p; }
static inline int vbm_get(const sfftl_t *f, uint32_t ppn) { return (int)((f->vbm[ppn >> 5] >> (ppn & 31u)) & 1u); }
static inline void vbm_set(sfftl_t *f, uint32_t ppn) { f->vbm[ppn >> 5] |= 1u << (ppn & 31u); }
static inline void vbm_clr(sfftl_t *f, uint32_t ppn) { f->vbm[ppn >> 5] &= ~(1u << (ppn & 31u)); }

/* ---------------------------------------------------------------- spare record (ftl_util.c) */
typedef struct {
  uint8_t  type;
  uint32_t tag;
  uint64_t seq;
} oob_t;
/* build the 16-byte spare record for `data`; returns the CRC */
void oob_build(const sfftl_t *f, uint8_t *spare, uint8_t type, uint32_t tag, uint64_t seq, const uint8_t *data);
/* 1 = erased, 0 = valid (o filled), -1 = invalid (CRC / format) ; data may be NULL to skip the CRC */
int  oob_parse(const sfftl_t *f, const uint8_t *spare, const uint8_t *data, oob_t *o);
int  oob_erased(const uint8_t *spare);
int  buf_erased(const uint8_t *p, uint32_t n);

/* ---------------------------------------------------------------- NAND wrappers with statistics (ftl_util.c) */
enum { RD_HOST, RD_RELOC, RD_META, RD_MOUNT, RD_VERIFY };
enum { PG_HOST, PG_RELOC, PG_META };
int  nand_read(sfftl_t *f, uint32_t ppn, void *data, void *spare, int cause);  /* HAL status after retries */
int  nand_program(sfftl_t *f, uint32_t ppn, const void *data, const void *spare, int cause);
int  nand_erase(sfftl_t *f, uint32_t pbn);   /* bookkeeping: EC, journal, erased flag; HAL status */
int  hal_rc(int hal_status);                /* map a fatal HAL status to an SFFTL_* code */

/* ---------------------------------------------------------------- mapping (ftl_map.c) */
void map_commit(sfftl_t *f, uint32_t lpn, uint32_t ppn);  /* L2P[lpn] = ppn, retire the previous page */
void map_unmap(sfftl_t *f, uint32_t lpn);
void map_invalidate_ppn(sfftl_t *f, uint32_t ppn);

/* ---------------------------------------------------------------- allocation / free space (ftl_alloc.c) */
int  alloc_page(sfftl_t *f, uint32_t stream, uint32_t *ppn);   /* SFFTL_OK / ENOSPC / EPOWER / EROFS */
int  write_page(sfftl_t *f, uint32_t stream, uint8_t type, uint32_t tag, const uint8_t *data, uint32_t *ppn);
void streams_settle(sfftl_t *f);
void stream_close(sfftl_t *f, uint32_t stream);
void block_close(sfftl_t *f, uint32_t b);
void block_make_free(sfftl_t *f, uint32_t b);
uint32_t free_reserve(const sfftl_t *f);

/* ---------------------------------------------------------------- wear levelling (ftl_wear.c) */
uint32_t wear_pick_free(sfftl_t *f, uint32_t stream);   /* SFFTL_NONE if no free block */
uint32_t wear_static_victim(sfftl_t *f);                /* block to migrate, or SFFTL_NONE */

/* ---------------------------------------------------------------- bad-block manager (ftl_bbm.c) */
int  bbm_is_factory_bad(sfftl_t *f, uint32_t pbn, int *bad);   /* marker majority check of first/last page */
int  bbm_program_failed(sfftl_t *f, uint32_t b);
int  bbm_erase_failed(sfftl_t *f, uint32_t b);
void bbm_read_failed(sfftl_t *f, uint32_t b);
int  bbm_retire(sfftl_t *f, uint32_t b, uint32_t reason);

/* ---------------------------------------------------------------- garbage collection (ftl_gc.c) */
int  gc_collect(sfftl_t *f, uint32_t victim, uint32_t stream);  /* relocate + erase/retire; <0 error */
int  gc_foreground(sfftl_t *f);                                  /* until enough free blocks */
int  gc_background(sfftl_t *f, uint32_t budget);                 /* idle-time collection; pages moved */
int  gc_paced(sfftl_t *f);                                        /* incremental step after a host page */
uint32_t gc_pick_victim(sfftl_t *f);

/* ---------------------------------------------------------------- metadata log (ftl_meta.c) */
int  meta_append(sfftl_t *f, uint32_t kind, uint32_t index, uint32_t gen, uint8_t *page);  /* header, spare, ring */
int  journal_add(sfftl_t *f, uint32_t type, uint32_t a, uint32_t b);  /* buffered */
int  journal_flush(sfftl_t *f);
int  ckpt_write(sfftl_t *f, int clean);
int  meta_ensure_head(sfftl_t *f);           /* keep an erased page available at the head */
int  mark_dirty(sfftl_t *f);                 /* MOUNT record before the first change after a clean checkpoint */
int  maybe_checkpoint(sfftl_t *f);
uint32_t meta_room_blocks(const sfftl_t *f);  /* whole erased-able ring blocks outside the live region */
uint32_t meta_ring_next(const sfftl_t *f, uint32_t zi);

/* ---------------------------------------------------------------- layout (ftl_mount.c) */
int  layout(sfftl_t *f, const sfftl_geom_t *g, const sfftl_cfg_t *cfg, const sfftl_hal_t *hal, void *arena,
            size_t arena_bytes);

/* power-fail check used between page operations */
int  ps_blocked(const sfftl_t *f);

#endif /* SFFTL_INTERNAL_H */
