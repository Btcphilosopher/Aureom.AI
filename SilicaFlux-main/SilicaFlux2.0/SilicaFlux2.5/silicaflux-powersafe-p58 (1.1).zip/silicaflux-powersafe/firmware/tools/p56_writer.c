/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- tools/p56_writer
 * Writes a medium with the UNMODIFIED Project 56 FlashMap library (schema 1)
 * into a file-backed simulated NAND, so the Project 58 build can be tested on
 * it (upgrade path).  Final logical content: LBA l holds bytes (l*7+3), except
 * l % 9 == 0 which is deallocated (zeros).  The medium is left UNCLEAN (no
 * shutdown) so the P58 mount must roll schema-1 metadata forward.
 * usage: p56_writer <file> [meta_blocks]    (0 = P56 automatic zone size)
 * ===========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sfftl.h"
#include "simnand.h"

int main(int argc, char **argv) {
  if (argc < 2) { fprintf(stderr, "usage: %s <file> [meta_blocks]\n", argv[0]); return 2; }
  sfftl_geom_t g = { 512, 16, 16, 64 };
  sfftl_cfg_t c;
  sfftl_cfg_default(&c);
  c.lba_bytes = 512;
  c.meta_blocks = argc > 2 ? (uint32_t)atoi(argv[2]) : 6u;
  simnand_cfg_t nc;
  simnand_cfg_default(&nc, g.page_data_bytes, g.pages_per_block, g.blocks);
  nc.page_spare_bytes = g.page_spare_bytes;
  simnand_t *n = simnand_open_file(&nc, 5, argv[1], 1);
  if (!n) { perror("open"); return 1; }
  sfftl_hal_t hal;
  simnand_hal(n, &hal);
  size_t ab = sfftl_mem_required(&g, &c);
  void *arena = aligned_alloc(8, (ab + 7u) & ~(size_t)7u);
  static sfftl_t f;
  int rc = sfftl_format(&f, &g, &c, &hal, arena, ab);
  if (rc) { fprintf(stderr, "format: %s\n", sfftl_strerror(rc)); return 1; }
  uint64_t nl = sfftl_capacity_lba(&f);
  uint8_t buf[512];
  for (int pass = 0; pass < 3; pass++)                        /* overwrites: GC, journal, checkpoints */
    for (uint64_t l = 0; l < nl; l++) {
      memset(buf, pass == 1 ? 0xA5 : (int)(uint8_t)(l * 7u + 3u), sizeof(buf));
      if ((rc = sfftl_write(&f, l, 1, buf))) { fprintf(stderr, "write: %s\n", sfftl_strerror(rc)); return 1; }
    }
  for (uint64_t l = 0; l < nl; l += 9) if ((rc = sfftl_trim(&f, l, 1))) { fprintf(stderr, "trim: %s\n", sfftl_strerror(rc)); return 1; }
  (void)sfftl_checkpoint(&f);
  for (uint64_t l = 1; l < nl; l += 5) {                    /* after the checkpoint: roll-forward work */
    if (l % 9u == 0u) continue;
    memset(buf, (int)(uint8_t)(l * 7u + 3u), sizeof(buf));
    if ((rc = sfftl_write(&f, l, 1, buf))) { fprintf(stderr, "write2: %s\n", sfftl_strerror(rc)); return 1; }
  }
  printf("p56_writer: Project 56 library %08X, schema %u, %llu LBAs, meta_blocks %u, left unclean -> %s\n",
         SFFTL_VERSION, SFFTL_SCHEMA_VERSION, (unsigned long long)nl, f.meta_blocks, argv[1]);
  simnand_destroy(n);                                        /* no shutdown: unclean */
  free(arena);
  return 0;
}
