/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- firmware main loop (sfps_fw.h)
 *
 * Power-fault policy (no physical PLP, docs/07_POWER_LOSS_POLICY.md):
 *   warning -> sfftl_ps_warn(): every FTL loop stops at its next page
 *   boundary and returns EPOWER (not acknowledged); no checkpoint, no cache
 *   destage, no journal flush is started -- there is no energy budget for it.
 *   Commands still queued are refused (the controller already aborted them).
 *   If the supply comes back (brown-out): PF_RESUME; the controller decides
 *   between a fast resume (no NAND operation was in flight at the fault) and a
 *   full recovery mount.
 * ===========================================================================*/
#include "sfps_fw.h"

#if defined(__STDC_HOSTED__) && __STDC_HOSTED__
#include <string.h>
#else
void *memcpy(void *d, const void *s, size_t n);
void *memset(void *d, int c, size_t n);
#endif

/* P51 sfs_cmd_ctrl page (rtl/generated/sfs_map_pkg.sv) */
#define CMD_INFO        0x000u
#define CMD_FWQ_HEAD    0x004u
#define CMD_FWQ_POP     0x008u
#define CMD_CPL_RESULT0 0x00Cu
#define CMD_CPL_RESULT1 0x010u
#define CMD_CPL_POST    0x014u
#define CMD_MDTS        0x024u
#define CMD_CAP_LO      0x028u
#define CMD_CAP_HI      0x02Cu
#define CMD_TAG_WIN     0x100u
#define CMD_TAG_STRIDE  32u

static int alive(sfps_fw_t *w) { return !w->pl.alive || w->pl.alive(w->pl.ctx); }
static uint32_t rrd(sfps_fw_t *w, uint32_t a) { return w->pl.rec_rd(w->pl.ctx, a); }
static void rwr(sfps_fw_t *w, uint32_t a, uint32_t v) { w->pl.rec_wr(w->pl.ctx, a, v); }

/* ---------------------------------------------------------------- controller ops for sfps */
static void op_phase(void *ctx, int slot, uint32_t ph) {
  sfps_fw_t *w = (sfps_fw_t *)ctx;
  rwr(w, SFPR_PHASE, ((ph & 7u) << 8) | ((uint32_t)slot & 0xFFu));
}
static void op_retire(void *ctx, int slot) {
  sfps_fw_t *w = (sfps_fw_t *)ctx;
  rwr(w, SFPR_RETIRE, (uint32_t)slot & 0xFFu);
}
static int op_inhibited(void *ctx) {
  sfps_fw_t *w = (sfps_fw_t *)ctx;
  if (!alive(w)) return 1;
  return (rrd(w, SFPR_STATE) & SFPR_STATE_NAND_INHIBIT) != 0u;
}

int sfps_fw_init(sfps_fw_t *w, const sfps_plat_t *pl, const sfftl_geom_t *g, const sfftl_cfg_t *cfg,
                 const sfftl_hal_t *hal, void *arena, size_t arena_bytes, void *wc_buf, uint32_t wc_pages,
                 void *io, uint32_t mdts) {
  memset(w, 0, sizeof(*w));
  w->pl = *pl;
  w->g = *g;
  w->cfg = *cfg;
  w->hal = *hal;
  w->arena = arena;
  w->arena_bytes = arena_bytes;
  w->io = (uint8_t *)io;
  w->mdts = mdts;
  sfps_ctrl_t c;
  c.ctx = w;
  c.phase = op_phase;
  c.retire = op_retire;
  c.inhibited = op_inhibited;
  return sfps_init(&w->ps, &c, wc_buf, wc_pages);
}

/* ---------------------------------------------------------------- recovery mount */
static int do_mount(sfps_fw_t *w, int with_diag, uint32_t diag_type) {
  sfftl_opts_t o;
  memset(&o, 0, sizeof(o));
  o.hook = sfps_hook;
  o.hook_ctx = &w->ps;
  if (with_diag) {
    o.diag_valid = 1;
    o.diag_type = diag_type;
    memcpy(o.diag, w->st.last_diag, sizeof(o.diag));
  }
  sfps_set_user_hook(&w->ps, w->user_hook, w->user_ctx);
  w->ps.ftl = &w->ftl;
  int rc = sfftl_mount_ex(&w->ftl, &w->g, &w->cfg, &w->hal, w->arena, w->arena_bytes, &o);
  if (rc == SFFTL_ENOFS && w->allow_format) {
    rc = sfftl_format_ex(&w->ftl, &w->g, &w->cfg, &w->hal, w->arena, w->arena_bytes, &o);
    if (rc == SFFTL_OK) w->st.formats++;
  }
  w->st.last_mount_rc = (uint32_t)rc;
  if (rc != SFFTL_OK) { w->mounted = 0; w->st.mount_fail++; return rc; }
  sfps_attach(&w->ps, &w->ftl);
  w->mounted = 1;
  w->st.recoveries++;
  return SFFTL_OK;
}

static void publish(sfps_fw_t *w) {
  uint64_t cap = sfftl_capacity_lba(&w->ftl);
  w->pl.cmd_wr(w->pl.ctx, CMD_CAP_LO, (uint32_t)cap);
  w->pl.cmd_wr(w->pl.ctx, CMD_CAP_HI, (uint32_t)(cap >> 32));
  w->pl.cmd_wr(w->pl.ctx, CMD_MDTS, w->mdts);
  uint64_t seq = w->ftl.next_seq - 1u;
  rwr(w, SFPR_COMMIT_SEQ_LO, (uint32_t)seq);
  rwr(w, SFPR_COMMIT_SEQ_HI, (uint32_t)(seq >> 32));
  uint32_t cfg = rrd(w, SFPR_CFG);
  cfg = w->wce ? (cfg | SFPR_CFG_WCE) : (cfg & ~SFPR_CFG_WCE);
  rwr(w, SFPR_CFG, cfg);
}

static int finish_recovery(sfps_fw_t *w, int rc) {
  uint32_t res;
  sfftl_space_t sp;
  if (rc != SFFTL_OK) res = SFPR_RD_FAIL;
  else {
    sfftl_space(&w->ftl, &sp);
    res = sp.read_only ? SFPR_RD_READONLY : SFPR_RD_OK;
    if (sp.read_only) sfftl_event_add(&w->ftl, SFFTL_EVT_READONLY, NULL);
    publish(w);
  }
  if (!alive(w)) return -1;
  rwr(w, SFPR_RECOV_DONE, res);
  return (int)res;
}

int sfps_fw_boot(sfps_fw_t *w) {
  if (!alive(w)) return -1;
  w->st.boots++;
  if (rrd(w, SFPR_ID) != SFPR_ID_MAGIC) return SFPR_RD_FAIL;
  for (uint32_t k = 0; k < 16u && SFPR_STATE_FSM(rrd(w, SFPR_STATE)) == SFPR_STATE_RESET; k++) {}
  /* controller diagnostics that survived a controller reset (POR clears them) */
  uint32_t flags = rrd(w, SFPR_STK_FLAGS);
  w->st.last_boot_cause = rrd(w, SFPR_STK_LAST_CAUSE);
  w->st.last_diag[0] = rrd(w, SFPR_STK_PF_SNAP0);
  w->st.last_diag[1] = rrd(w, SFPR_STK_PF_SNAP1);
  w->st.last_diag[2] = rrd(w, SFPR_STK_RST_SNAP);
  w->st.last_diag[3] = rrd(w, SFPR_STK_VOL_LOST);
  w->st.last_diag[4] = (w->st.last_boot_cause & 0xFu) | (rrd(w, SFPR_STK_PF_COUNT) << 4);
  /* RAM contents (write cache) are gone after any reset */
  sfps_drop_cache(&w->ps);
  rwr(w, SFPR_CTRL, SFPR_CTRL_BOOT_ACK);
  int rc = do_mount(w, (flags & 3u) != 0u, SFFTL_EVT_POWER_FAULT);
  if (!alive(w)) return -1;
  if (rc == SFFTL_OK && (flags & 3u)) {
    /* diagnostics must be on the medium before they are cleared: a recovery
     * mount already wrote a checkpoint; a clean mount writes one now */
    if (w->ftl.st.last_mount_clean && !w->ftl.read_only) rc = sfftl_checkpoint(&w->ftl);
    if (!alive(w)) return -1;
    if (rc == SFFTL_OK) rwr(w, SFPR_CTRL, SFPR_CTRL_CLR_STICKY);
    else rc = SFFTL_OK;                             /* keep them for the next boot */
  }
  return finish_recovery(w, rc);
}

/* ---------------------------------------------------------------- commands */
static void post(sfps_fw_t *w, uint32_t tag, uint32_t st, uint32_t err, uint32_t r0) {
  w->pl.cmd_wr(w->pl.ctx, CMD_CPL_RESULT0, r0);
  w->pl.cmd_wr(w->pl.ctx, CMD_CPL_RESULT1, 0);
  w->pl.cmd_wr(w->pl.ctx, CMD_CPL_POST, (tag & 0xFFu) | ((st & 0x7Fu) << 8) | ((err & 0xFFu) << 16));
  w->st.cpl_posted++;
}

static void identify(sfps_fw_t *w, uint8_t *b) {
  memset(b, 0, 512);
  uint64_t cap = sfftl_capacity_lba(&w->ftl);
  for (int i = 0; i < 8; i++) b[i] = (uint8_t)(cap >> (8 * i));
  b[8] = (uint8_t)w->ftl.cfg.lba_bytes; b[9] = (uint8_t)(w->ftl.cfg.lba_bytes >> 8);
  b[16] = 1;                              /* volatile write cache present (host-controlled) */
  b[17] = (uint8_t)w->ps.wce;             /* ...and its current setting                     */
  b[18] = 0;                              /* power-loss protection: NOT present             */
  b[20] = (uint8_t)(SFPS_VERSION >> 8);
}

static void put32(uint8_t *p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24); }

void sfps_fw_telemetry(sfps_fw_t *w, uint8_t *b) {
  uint32_t t[128];
  memset(t, 0, sizeof(t));
  sfftl_persist_t pp;
  sfftl_persist(&w->ftl, &pp);
  const sfftl_stats_t *s = sfftl_stats(&w->ftl);
  t[0] = SFPS_TLM_MAGIC; t[1] = 1u;
  t[2] = pp.events_total; t[3] = pp.unsafe_shutdowns; t[4] = pp.recoveries; t[5] = pp.fallback_mounts;
  t[6] = pp.meta_damage; t[7] = pp.torn_pages; t[8] = pp.pf_events;
  t[9] = (s->last_mount_pages_scanned & 0xFFFFu) | (s->last_mount_pages_replayed << 16);
  t[10] = (s->last_mount_torn & 0xFFu) | ((s->last_mount_fallback & 0xFFu) << 8) | ((s->last_mount_incomplete & 0xFFu) << 16);
  t[11] = (uint32_t)s->nand_read_mount;
  t[12] = s->last_mount_schema | (s->last_mount_clean << 8);
  t[13] = rrd(w, SFPR_RECOV_CYC_LAST);
  t[14] = rrd(w, SFPR_STK_PF_COUNT);
  t[15] = rrd(w, SFPR_STK_LAST_CAUSE);
  t[16] = rrd(w, SFPR_CNT_GATE_HELD);
  t[17] = rrd(w, SFPR_CNT_ACK_VOL);
  t[18] = rrd(w, SFPR_CNT_ACK_DURABLE);
  t[19] = sfps_dirty_pages(&w->ps);
  t[20] = (uint32_t)w->ps.st.vol_lost_at_pf;
  t[21] = (uint32_t)(w->ftl.next_seq - 1u);
  sfftl_event_t e;
  for (uint32_t i = 0; i < SFFTL_EVT_RING && sfftl_event_get(&w->ftl, i, &e) == SFFTL_OK; i++)
    for (uint32_t k = 0; k < SFFTL_EVT_WORDS; k++) t[24 + i * SFFTL_EVT_WORDS + k] = e.w[k];
  for (uint32_t i = 0; i < 128u; i++) put32(b + 4u * i, t[i]);
}

static int one_command(sfps_fw_t *w) {
  uint32_t head = w->pl.cmd_rd(w->pl.ctx, CMD_FWQ_HEAD);
  if (!(head & 0x80000000u)) return 0;
  uint32_t tag = head & 0xFFu;
  w->pl.cmd_wr(w->pl.ctx, CMD_FWQ_POP, 1);
  uint32_t e[8];
  for (uint32_t i = 0; i < 8; i++) e[i] = w->pl.cmd_rd(w->pl.ctx, CMD_TAG_WIN + tag * CMD_TAG_STRIDE + 4u * i);
  if (!alive(w)) return -1;
  sfps_cmd_t c;
  c.op = (uint8_t)(e[0] & 0xFFu);
  c.fua = (uint8_t)((e[0] >> 9) & 1u);
  c.slot = (int)(e[0] >> 16);                         /* downstream TID = recovery-controller slot */
  c.lba = (uint64_t)e[2] | ((uint64_t)e[3] << 32);
  c.nlb = e[4];
  c.buf = w->io;
  uint64_t haddr = (uint64_t)e[5] | ((uint64_t)e[6] << 32);
  w->st.cmds++;
  /* claim it: the controller refuses if it already aborted it (power fault) */
  rwr(w, SFPR_PHASE, (SFPR_PH_STARTED << 8) | ((uint32_t)c.slot & 0xFFu));
  uint32_t res = rrd(w, SFPR_PHASE_RESULT) & 7u;
  if (!alive(w)) return -1;
  if (res != SFPR_PR_OK) {
    w->st.cmds_refused++;
    post(w, tag, SFPS_ST_ABORT_PWR_LOSS, SFPS_ERR_QUIESCED, 0);
    return 1;
  }
  sfps_cpl_t cpl;
  const uint32_t lb = w->ftl.cfg.lba_bytes;
  if (c.op == SFPS_OP_IDENTIFY || c.op == SFPS_OP_GET_LOG) {
    if (c.op == SFPS_OP_GET_LOG && e[1] == SFPS_LOG_TELEMETRY) sfps_fw_telemetry(w, w->io);   /* aux = log id */
    else identify(w, w->io);
    if (w->pl.dma_out) w->pl.dma_out(w->pl.ctx, haddr, w->io, 512);
    post(w, tag, SFPS_ST_SUCCESS, 0, 1);
    return 1;
  }
  if ((c.op == SFPS_OP_WRITE || c.op == SFPS_OP_READ) && c.nlb > w->mdts) {
    post(w, tag, SFPS_ST_INVALID_FIELD, 3u, 0);
    return 1;
  }
  if (c.op == SFPS_OP_WRITE) {
    if (w->pl.dma_in && w->pl.dma_in(w->pl.ctx, haddr, w->io, c.nlb * lb) != 0) {
      post(w, tag, 4u /* DATA_XFER_ERR */, 7u, 0);
      return 1;
    }
    rwr(w, SFPR_PHASE, (SFPR_PH_BUFFERED << 8) | ((uint32_t)c.slot & 0xFFu));
  }
  sfps_exec(&w->ps, &c, &cpl);
  if (!alive(w)) return -1;
  if (c.op == SFPS_OP_READ && cpl.status == SFPS_ST_SUCCESS && w->pl.dma_out) {
    w->pl.dma_out(w->pl.ctx, haddr, w->io, c.nlb * lb);
    rwr(w, SFPR_PHASE, (SFPR_PH_BUFFERED << 8) | ((uint32_t)c.slot & 0xFFu));
  }
  post(w, tag, cpl.status, cpl.err, (cpl.status == SFPS_ST_SUCCESS) ? c.nlb : 0u);
  return 1;
}

/* the controller aborted everything not started; drain what is left in the queue */
static int drain_queue(sfps_fw_t *w) {
  int n = 0;
  for (;;) {
    uint32_t head = w->pl.cmd_rd(w->pl.ctx, CMD_FWQ_HEAD);
    if (!alive(w) || !(head & 0x80000000u)) return n;
    w->pl.cmd_wr(w->pl.ctx, CMD_FWQ_POP, 1);
    post(w, head & 0xFFu, SFPS_ST_ABORT_PWR_LOSS, SFPS_ERR_QUIESCED, 0);
    w->st.cmds_refused++;
    n++;
  }
}

int sfps_fw_poll(sfps_fw_t *w) {
  if (!alive(w)) return -1;
  uint32_t s = rrd(w, SFPR_STATE);
  uint32_t fsm = SFPR_STATE_FSM(s);
  if (!alive(w)) return -1;
  if (s & SFPR_STATE_PF_LATCHED) {
    if (w->mounted && !w->ftl.ps_warned) sfps_power_fault(&w->ps);
    int n = drain_queue(w);
    if (fsm == SFPR_STATE_PF_SAFE && (s & SFPR_STATE_PF_RESTORED)) {
      /* brown-out: the supply is back and the firmware (RAM) survived */
      rwr(w, SFPR_CTRL, SFPR_CTRL_PF_RESUME);
      uint32_t s2 = rrd(w, SFPR_STATE);
      if (!alive(w)) return -1;
      uint32_t d[5] = { rrd(w, SFPR_STK_PF_SNAP0), rrd(w, SFPR_STK_PF_SNAP1), 0u, 0u, 0u };
      memcpy(w->st.last_diag, d, sizeof(d));
      if (SFPR_STATE_FSM(s2) == SFPR_STATE_RECOVER) {
        /* full recovery: rebuild the FTL's RAM from the medium (the cache's
         * acknowledged-volatile data is still in RAM and is kept) */
        w->st.resumes_full++;
        int rc = do_mount(w, 1, SFFTL_EVT_BROWNOUT);
        if (!alive(w)) return -1;
        finish_recovery(w, rc);
      } else {
        w->st.resumes_fast++;
        sfftl_ps_power_restored(&w->ftl);
        sfftl_event_add(&w->ftl, SFFTL_EVT_BROWNOUT, d);
      }
      return 1;
    }
    return n > 0;
  }
  if (fsm == SFPR_STATE_SHUTDOWN) {
    int did = one_command(w);
    if (did != 0) return did;
    if ((SFPR_STATE_SLOTS(rrd(w, SFPR_STATE))) != 0u) {
      int rc = sfps_flush_cache(&w->ps);            /* volatile entries become durable -> freed */
      return rc < 0 ? (alive(w) ? 0 : -1) : 1;
    }
    if (w->mounted) {
      if (sfps_flush_cache(&w->ps) < 0 || !alive(w)) return alive(w) ? 0 : -1;
      if (sfftl_shutdown(&w->ftl) < 0 || !alive(w)) return alive(w) ? 0 : -1;
      w->mounted = 0;
    }
    rwr(w, SFPR_CTRL, SFPR_CTRL_SHUTDOWN_DONE);
    w->st.shutdowns++;
    return 1;
  }
  if (fsm != SFPR_STATE_READY && fsm != SFPR_STATE_READONLY) return 0;
  if (w->ps.wce != w->wce) {
    sfps_set_wce(&w->ps, w->wce);                   /* host changed the cache setting */
    uint32_t cfg = rrd(w, SFPR_CFG);
    rwr(w, SFPR_CFG, w->wce ? (cfg | SFPR_CFG_WCE) : (cfg & ~SFPR_CFG_WCE));
  }
  int did = one_command(w);
  if (did != 0) return did;
  int r = sfps_idle(&w->ps);
  if (r > 0) { w->st.idle_destages++; return 1; }
  return alive(w) ? 0 : -1;
}
