/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- firmware persistence layer (sfps.h)
 * ===========================================================================*/
#include "sfps.h"

#if defined(__STDC_HOSTED__) && __STDC_HOSTED__
#include <string.h>
#else
void *memcpy(void *d, const void *s, size_t n);
void *memset(void *d, int c, size_t n);
#endif

/* ---------------------------------------------------------------- controller reports */
static void report(sfps_t *p, int slot, uint32_t ph) {
  if (slot < 0 || slot >= (int)SFPS_SLOTS_MAX) return;
  p->st.phase_reports++;
  if (p->ctrl.phase) p->ctrl.phase(p->ctrl.ctx, slot, ph);
}

static void emit(sfps_t *p, uint32_t kind, uint32_t a, uint32_t b) {
  if (p->user_hook) {
    sfftl_ev_t ev;
    ev.kind = kind; ev.a = a; ev.b = b; ev.c = 0;
    p->user_hook(p->user_ctx, &ev);
  }
}

/* FTL hook: phases of the command executing now, then the chained hook */
void sfps_hook(void *ctx, const sfftl_ev_t *ev) {
  sfps_t *p = (sfps_t *)ctx;
  if (p->cur_write && p->cur_slot >= 0) {
    if (ev->kind == SFFTL_EV_PROG_BEGIN && ev->c == SFFTL_PGC_HOST) p->cur_prog_lpn = ev->b;
    if (ev->kind == SFFTL_EV_PROG_END && ev->c == SFFTL_PGC_HOST && ev->b == SFFTL_HAL_OK &&
        p->cur_prog_lpn == p->cur_last_lpn && p->cur_ph < SFPR_PH_PROGRAMMED) {
      report(p, p->cur_slot, SFPR_PH_PROGRAMMED);
      p->cur_ph = SFPR_PH_PROGRAMMED;
    }
    if (ev->kind == SFFTL_EV_MAP_COMMIT && ev->c == SFFTL_PGC_HOST && ev->a == p->cur_last_lpn) {
      /* the page carries {LPN, SEQ, CRC} in its spare record: the mapping is
       * persistent with the data, no further metadata is needed -> DURABLE */
      report(p, p->cur_slot, SFPR_PH_VERIFIED);
      report(p, p->cur_slot, SFPR_PH_MAP_COMMITTED);
      report(p, p->cur_slot, SFPR_PH_DURABLE);
      p->cur_ph = SFPR_PH_DURABLE;
      p->cur_durable = 1;
    }
  }
  if (p->user_hook) p->user_hook(p->user_ctx, ev);
}

int sfps_init(sfps_t *p, const sfps_ctrl_t *ctrl, void *wc_buf, uint32_t wc_pages) {
  memset(p, 0, sizeof(*p));
  if (ctrl) p->ctrl = *ctrl;
  if (wc_pages > SFPS_WC_MAX) wc_pages = SFPS_WC_MAX;
  p->wc_n = wc_buf ? wc_pages : 0u;
  p->wc_buf = (uint8_t *)wc_buf;
  p->cur_slot = -1;
  return SFFTL_OK;
}

void sfps_attach(sfps_t *p, sfftl_t *ftl) {
  p->ftl = ftl;
  sfftl_set_hook(ftl, sfps_hook, p);
}

void sfps_set_user_hook(sfps_t *p, sfftl_hook_fn fn, void *ctx) { p->user_hook = fn; p->user_ctx = ctx; }

const char *sfps_phase_name(uint32_t ph) {
  static const char *n[8] = { "FREE", "ACCEPTED", "STARTED", "BUFFERED", "PROGRAMMED", "VERIFIED", "MAP_COMMITTED",
                              "DURABLE" };
  return ph < 8u ? n[ph] : "?";
}

/* ---------------------------------------------------------------- status mapping */
static void set_status(sfps_cpl_t *c, int rc, int is_read) {
  c->err = SFPS_ERR_NONE;
  switch (rc) {
    case SFFTL_OK:     c->status = SFPS_ST_SUCCESS; break;
    case SFFTL_EPOWER: c->status = SFPS_ST_ABORT_PWR_LOSS; c->err = SFPS_ERR_QUIESCED; break;
    case SFFTL_ERANGE: c->status = SFPS_ST_LBA_RANGE; break;
    case SFFTL_ENOSPC: c->status = SFPS_ST_CAPACITY; break;
    case SFFTL_EROFS:  c->status = SFPS_ST_ACCESS_DENIED; c->err = SFPS_ERR_NAND_WP; break;
    case SFFTL_EIO:
      c->status = is_read ? SFPS_ST_MEDIA_UNREC : SFPS_ST_MEDIA_WRITE;
      c->err = is_read ? SFPS_ERR_NAND_ECC_UE : SFPS_ERR_NAND_FAIL;
      break;
    default:           c->status = SFPS_ST_INTERNAL_ERR; c->err = SFPS_ERR_FW; break;
  }
}

/* ---------------------------------------------------------------- write cache */
static uint32_t pbytes(const sfps_t *p) { return p->ftl->g.page_data_bytes; }
static uint8_t *wc_page(const sfps_t *p, uint32_t cs) { return p->wc_buf + (size_t)cs * pbytes(p); }

static int wc_find(const sfps_t *p, uint32_t lpn) {
  for (uint32_t i = 0; i < p->wc_n; i++) if (p->wc_valid[i] && p->wc_lpn[i] == lpn) return (int)i;
  return -1;
}

uint32_t sfps_dirty_pages(const sfps_t *p) {
  uint32_t n = 0;
  for (uint32_t i = 0; i < p->wc_n; i++) n += (p->wc_valid[i] && p->wc_dirty[i]) ? 1u : 0u;
  return n;
}

/* the commands in `mask` lost their data (destage impossible): RETIRE them */
static void wc_retire_mask(sfps_t *p, uint32_t mask) {
  for (uint32_t s = 0; s < SFPS_SLOTS_MAX; s++) {
    if (!(mask & (1u << s))) continue;
    if (p->ctrl.retire) p->ctrl.retire(p->ctrl.ctx, (int)s);
    p->cmd_pend[s] = 0;
    for (uint32_t i = 0; i < p->wc_n; i++) p->wc_mask[i] &= ~(1u << s);
  }
}

static int wc_destage(sfps_t *p, uint32_t cs) {
  if (!p->wc_valid[cs] || !p->wc_dirty[cs]) return SFFTL_OK;
  sfftl_t *f = p->ftl;
  uint32_t lpn = p->wc_lpn[cs];
  emit(p, SFPS_EV_DESTAGE, lpn, cs);
  if (p->ctrl.inhibited && p->ctrl.inhibited(p->ctrl.ctx)) { sfftl_ps_warn(f); return SFFTL_EPOWER; }
  int rc = sfftl_write(f, (uint64_t)lpn << f->spp_shift, f->spp, wc_page(p, cs));
  p->st.destages++;
  if (rc == SFFTL_OK) {
    uint32_t m = p->wc_mask[cs];
    p->wc_dirty[cs] = 0;
    p->wc_mask[cs] = 0;
    for (uint32_t s = 0; s < SFPS_SLOTS_MAX; s++) {
      if (!(m & (1u << s)) || p->cmd_pend[s] == 0) continue;
      if (--p->cmd_pend[s] == 0) report(p, (int)s, SFPR_PH_DURABLE);   /* all of its pages are on the medium */
    }
    return SFFTL_OK;
  }
  if (rc == SFFTL_EPOWER) return rc;               /* data stays dirty in RAM: lost with the supply */
  /* media error / no space / read-only: this data can no longer become durable */
  p->st.destage_fail++;
  wc_retire_mask(p, p->wc_mask[cs]);
  p->wc_mask[cs] = 0;
  p->wc_dirty[cs] = 0;
  p->wc_valid[cs] = 0;
  return rc;
}

/* destage + drop every cached page of [first, last] (the FTL must see the newest data first) */
static int wc_flush_range(sfps_t *p, uint32_t first, uint32_t last) {
  int rc = SFFTL_OK;
  for (uint32_t i = 0; i < p->wc_n; i++) {
    if (!p->wc_valid[i] || p->wc_lpn[i] < first || p->wc_lpn[i] > last) continue;
    if (p->wc_dirty[i]) {
      p->st.overlap_destages++;
      int r = wc_destage(p, i);
      if (r == SFFTL_EPOWER) return r;
      if (r < 0 && rc == SFFTL_OK) rc = r;
    }
    p->wc_valid[i] = 0;
  }
  return rc;
}

/* a cache page for lpn (loaded when the write covers only part of it) */
static int wc_get(sfps_t *p, uint32_t lpn, int whole, int *out) {
  int cs = wc_find(p, lpn);
  if (cs >= 0) { p->st.cache_hits_w++; *out = cs; return SFFTL_OK; }
  uint32_t pick = SFPS_WC_MAX;
  for (uint32_t i = 0; i < p->wc_n && pick == SFPS_WC_MAX; i++) if (!p->wc_valid[i]) pick = i;
  if (pick == SFPS_WC_MAX) {                      /* evict: clean first, else the oldest dirty page */
    uint32_t best = SFPS_WC_MAX, bage = 0;
    for (uint32_t i = 0; i < p->wc_n; i++) {
      uint32_t age = p->tick - p->wc_age[i] + (p->wc_dirty[i] ? 0u : 0x40000000u);
      if (best == SFPS_WC_MAX || age > bage) { best = i; bage = age; }
    }
    pick = best;
    if (p->wc_dirty[pick]) {
      p->st.evictions++;
      int rc = wc_destage(p, pick);
      if (rc < 0 && rc != SFFTL_EIO && rc != SFFTL_ENOSPC && rc != SFFTL_EROFS) return rc;
    }
    p->wc_valid[pick] = 0;
  }
  sfftl_t *f = p->ftl;
  if (!whole) {
    int rc = sfftl_read(f, (uint64_t)lpn << f->spp_shift, f->spp, wc_page(p, pick));
    if (rc < 0) return rc;
  }
  p->wc_valid[pick] = 1;
  p->wc_dirty[pick] = 0;
  p->wc_lpn[pick] = lpn;
  p->wc_mask[pick] = 0;
  p->wc_age[pick] = p->tick++;
  *out = (int)pick;
  return SFFTL_OK;
}

int sfps_flush_cache(sfps_t *p) {
  int rc = SFFTL_OK;
  for (;;) {                                       /* ascending LPN order (deterministic) */
    uint32_t best = SFPS_WC_MAX;
    for (uint32_t i = 0; i < p->wc_n; i++)
      if (p->wc_valid[i] && p->wc_dirty[i] && (best == SFPS_WC_MAX || p->wc_lpn[i] < p->wc_lpn[best])) best = i;
    if (best == SFPS_WC_MAX) break;
    p->st.flush_destages++;
    int r = wc_destage(p, best);
    if (r == SFFTL_EPOWER) return r;
    if (r < 0 && rc == SFFTL_OK) rc = r;
  }
  return rc;
}

int sfps_idle(sfps_t *p) {
  uint32_t best = SFPS_WC_MAX;
  for (uint32_t i = 0; i < p->wc_n; i++)
    if (p->wc_valid[i] && p->wc_dirty[i] && (best == SFPS_WC_MAX || p->tick - p->wc_age[i] > p->tick - p->wc_age[best]))
      best = i;
  if (best == SFPS_WC_MAX) return 0;
  p->st.idle_destages++;
  int rc = wc_destage(p, best);
  return rc < 0 ? rc : 1;
}

int sfps_set_wce(sfps_t *p, int on) {
  if (!on && p->wce) {
    int rc = sfps_flush_cache(p);
    if (rc < 0) return rc;
  }
  p->wce = on ? 1 : 0;
  return SFFTL_OK;
}

void sfps_power_fault(sfps_t *p) {
  if (p->ftl) sfftl_ps_warn(p->ftl);
  if (p->plp) return;                              /* research PLP: the caller destages on hold-up energy */
  p->st.vol_lost_at_pf += sfps_dirty_pages(p);
}

void sfps_drop_cache(sfps_t *p) {
  for (uint32_t i = 0; i < p->wc_n; i++) { p->wc_valid[i] = 0; p->wc_dirty[i] = 0; p->wc_mask[i] = 0; }
  memset(p->cmd_pend, 0, sizeof(p->cmd_pend));
}

/* ---------------------------------------------------------------- commands */
static int write_through(sfps_t *p, const sfps_cmd_t *c, uint32_t first, uint32_t last) {
  sfftl_t *f = p->ftl;
  int rc = wc_flush_range(p, first, last);         /* older cached data reaches the FTL first */
  if (rc < 0) return rc;
  p->cur_slot = c->slot;
  p->cur_last_lpn = last;
  p->cur_prog_lpn = SFFTL_NONE;
  p->cur_write = 1;
  p->cur_durable = 0;
  p->cur_ph = SFPR_PH_BUFFERED;
  rc = sfftl_write(f, c->lba, c->nlb, c->buf);
  p->cur_write = 0;
  if (rc == SFFTL_OK && !p->cur_durable) {         /* (no hook event: e.g. a zero-length range) */
    report(p, c->slot, SFPR_PH_MAP_COMMITTED);
    report(p, c->slot, SFPR_PH_DURABLE);
  }
  p->st.wt_writes++;
  return rc;
}

static int write_cached(sfps_t *p, const sfps_cmd_t *c, uint32_t first, uint32_t last) {
  sfftl_t *f = p->ftl;
  const uint32_t lb = f->cfg.lba_bytes, spp = f->spp;
  const uint8_t *src = (const uint8_t *)c->buf;
  uint64_t lba = c->lba;
  uint32_t nlb = c->nlb;
  for (uint32_t lpn = first; lpn <= last; lpn++) {
    uint32_t off = (uint32_t)(lba & (spp - 1u));
    uint32_t n = (nlb < spp - off) ? nlb : spp - off;
    int cs;
    int rc = wc_get(p, lpn, off == 0 && n == spp, &cs);
    if (rc < 0) {
      /* not acknowledged: forget this command, so a later destage of the pages
       * it did reach never reports progress for a slot that may be reused */
      if (c->slot >= 0 && c->slot < (int)SFPS_SLOTS_MAX) {
        for (uint32_t i = 0; i < p->wc_n; i++) p->wc_mask[i] &= ~(1u << c->slot);
        p->cmd_pend[c->slot] = 0;
      }
      return rc;
    }
    memcpy(wc_page(p, (uint32_t)cs) + (size_t)off * lb, src, (size_t)n * lb);
    p->wc_dirty[cs] = 1;
    p->wc_age[cs] = p->tick++;
    if (c->slot >= 0 && c->slot < (int)SFPS_SLOTS_MAX && !(p->wc_mask[cs] & (1u << c->slot))) {
      p->wc_mask[cs] |= 1u << c->slot;
      p->cmd_pend[c->slot]++;
    }
    src += (size_t)n * lb;
    lba += n;
    nlb -= n;
  }
  p->st.vol_writes++;
  return SFFTL_OK;
}

static int read_cmd(sfps_t *p, const sfps_cmd_t *c) {
  sfftl_t *f = p->ftl;
  const uint32_t lb = f->cfg.lba_bytes, spp = f->spp;
  uint8_t *dst = (uint8_t *)c->buf;
  uint64_t lba = c->lba;
  uint32_t nlb = c->nlb;
  while (nlb) {
    uint32_t lpn = (uint32_t)(lba >> f->spp_shift), off = (uint32_t)(lba & (spp - 1u));
    uint32_t n = (nlb < spp - off) ? nlb : spp - off;
    int cs = wc_find(p, lpn);
    if (cs >= 0) {
      p->st.cache_hits_r++;
      memcpy(dst, wc_page(p, (uint32_t)cs) + (size_t)off * lb, (size_t)n * lb);
    } else {
      int rc = sfftl_read(f, lba, n, dst);
      if (rc < 0) return rc;
    }
    dst += (size_t)n * lb;
    lba += n;
    nlb -= n;
  }
  return SFFTL_OK;
}

void sfps_exec(sfps_t *p, const sfps_cmd_t *c, sfps_cpl_t *cpl) {
  sfftl_t *f = p->ftl;
  int rc = SFFTL_OK, is_read = 0;
  cpl->vol = 0;
  p->st.cmds++;
  const int mutating = c->op == SFPS_OP_WRITE || c->op == SFPS_OP_DEALLOCATE || c->op == SFPS_OP_FLUSH;
  if (mutating && (f->ps_warned || f->ps_state != SFFTL_PS_RUNNING ||
                   (p->ctrl.inhibited && p->ctrl.inhibited(p->ctrl.ctx)))) {
    /* power fault: no new work -- not even a volatile cache write */
    sfftl_ps_warn(f);                              /* power fault: start no new work */
    rc = SFFTL_EPOWER;
  } else if ((c->op == SFPS_OP_WRITE || c->op == SFPS_OP_READ || c->op == SFPS_OP_DEALLOCATE) &&
             (c->nlb == 0 || c->lba >= sfftl_capacity_lba(f) || (uint64_t)c->nlb > sfftl_capacity_lba(f) - c->lba)) {
    rc = SFFTL_ERANGE;
  } else {
    uint32_t first = (uint32_t)(c->lba >> f->spp_shift);
    uint32_t last = (uint32_t)((c->lba + c->nlb - 1u) >> f->spp_shift);
    switch (c->op) {
      case SFPS_OP_WRITE:
        p->st.writes++;
        if (c->fua) p->st.fua_writes++;
        if (p->wce && !c->fua && p->wc_n > 0u) {
          rc = write_cached(p, c, first, last);
          if (rc == SFFTL_OK) cpl->vol = 1;
        } else {
          rc = write_through(p, c, first, last);
        }
        break;
      case SFPS_OP_READ:
        p->st.reads++;
        is_read = 1;
        rc = read_cmd(p, c);
        break;
      case SFPS_OP_DEALLOCATE:
        p->st.trims++;
        rc = wc_flush_range(p, first, last);
        if (rc == SFFTL_OK) rc = sfftl_trim(f, c->lba, c->nlb);
        if (rc == SFFTL_OK) {                      /* journal page programmed before sfftl_trim returned */
          report(p, c->slot, SFPR_PH_PROGRAMMED);
          report(p, c->slot, SFPR_PH_MAP_COMMITTED);
          report(p, c->slot, SFPR_PH_DURABLE);
        }
        break;
      case SFPS_OP_FLUSH:
        p->st.flushes++;
        rc = sfps_flush_cache(p);
        if (rc == SFFTL_OK) rc = sfftl_flush(f);
        if (rc == SFFTL_OK) {
          emit(p, SFPS_EV_FLUSH_DONE, (uint32_t)c->slot, 0);
          report(p, c->slot, SFPR_PH_DURABLE);
        }
        break;
      default:
        rc = SFFTL_EINVAL;
        break;
    }
  }
  set_status(cpl, rc, is_read);
  if (rc == SFFTL_EINVAL) { cpl->status = SFPS_ST_INVALID_OPCODE; cpl->err = SFPS_ERR_NONE; }
  if (rc == SFFTL_EPOWER) p->st.aborted_pf++;
  else if (rc < 0) p->st.errors++;
  emit(p, SFPS_EV_BEFORE_CPL, (uint32_t)c->slot, cpl->status);
}
