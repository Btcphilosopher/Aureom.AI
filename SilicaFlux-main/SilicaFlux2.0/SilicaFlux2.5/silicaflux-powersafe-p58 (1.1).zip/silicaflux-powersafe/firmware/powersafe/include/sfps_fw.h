/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- firmware main loop on the ControlCore
 *
 * Platform-independent: registers, DMA and supply status come through
 * sfps_plat_t, so the same code runs in the Verilator co-simulation (register
 * accesses become RTL bus cycles) and cross-compiles for RV32IM.
 *
 *  boot     read the recovery controller's sticky diagnostics, BOOT_ACK,
 *           mount (recovery), publish capacity, RECOV_DONE
 *  poll     one main-loop iteration: power-fault handling, one command from
 *           the StorageCore command queue (sfs_cmd_ctrl FWQ / tag window /
 *           CPL_POST), shutdown, idle destage
 * ===========================================================================*/
#ifndef SFPS_FW_H
#define SFPS_FW_H

#include "sfps.h"

typedef struct {
  void *ctx;
  uint32_t (*rec_rd)(void *ctx, uint32_t a);              /* recovery-controller page   */
  void     (*rec_wr)(void *ctx, uint32_t a, uint32_t v);
  uint32_t (*cmd_rd)(void *ctx, uint32_t a);              /* sfs_cmd_ctrl page (P51)     */
  void     (*cmd_wr)(void *ctx, uint32_t a, uint32_t v);
  int      (*dma_in)(void *ctx, uint64_t haddr, void *dst, uint32_t bytes);
  int      (*dma_out)(void *ctx, uint64_t haddr, const void *src, uint32_t bytes);
  int      (*alive)(void *ctx);                           /* 0: supply gone -- unwind     */
} sfps_plat_t;

typedef struct {
  uint64_t boots, recoveries, formats, mount_fail, resumes_fast, resumes_full, shutdowns;
  uint64_t cmds, cmds_refused, cpl_posted, idle_destages;
  uint32_t last_mount_rc, last_boot_cause, last_diag[5];
} sfps_fw_stats_t;

typedef struct {
  sfps_plat_t   pl;
  sfps_t        ps;
  sfftl_t       ftl;
  sfftl_geom_t  g;
  sfftl_cfg_t   cfg;
  sfftl_hal_t   hal;
  void         *arena;
  size_t        arena_bytes;
  uint8_t      *io;               /* DMA buffer: mdts * lba_bytes */
  uint32_t      mdts;
  int           allow_format;     /* format a blank medium (first boot only!) */
  int           wce;              /* host setting of the volatile write cache */
  int           mounted;
  sfftl_hook_fn user_hook;
  void         *user_ctx;
  sfps_fw_stats_t st;
} sfps_fw_t;

/* GET_LOG page 0x58 (512 bytes, little endian 32-bit words): recovery telemetry
 *   w0   'SFPT' magic           w1   layout version (1)
 *   w2-8 persistent counters (sfftl_persist_t: events, unsafe shutdowns,
 *        recoveries, fallback mounts, damaged metadata, torn pages, power faults)
 *   w9   last mount: scanned | replayed << 16        w10 torn | fallback << 8 | incomplete << 16
 *   w11  last mount NAND reads                       w12 last mount schema | clean << 8
 *   w13  controller RECOV_CYC_LAST                   w14 controller STK_PF_COUNT
 *   w15  controller STK_LAST_CAUSE                   w16 controller CNT_GATE_HELD
 *   w17  controller CNT_ACK_VOL                      w18 controller CNT_ACK_DURABLE
 *   w19  firmware: cache pages dirty                 w20 firmware: cached pages lost at power faults
 *   w21  FTL commit sequence number [31:0]           w22-23 reserved
 *   w24.. the SFFTL_EVT_RING most recent events, newest first, 8 words each */
#define SFPS_LOG_TELEMETRY 0x58u
#define SFPS_TLM_MAGIC     0x54504653u   /* "SFPT" */
void sfps_fw_telemetry(sfps_fw_t *w, uint8_t *page512);

/* one-time setup (no hardware access) */
int  sfps_fw_init(sfps_fw_t *w, const sfps_plat_t *pl, const sfftl_geom_t *g, const sfftl_cfg_t *cfg,
                  const sfftl_hal_t *hal, void *arena, size_t arena_bytes, void *wc_buf, uint32_t wc_pages,
                  void *io, uint32_t mdts);
/* after a reset / power-on: returns the SFPR_RD_* result reported, or -1 (supply gone) */
int  sfps_fw_boot(sfps_fw_t *w);
/* one main-loop iteration: 1 did work, 0 idle, -1 supply gone */
int  sfps_fw_poll(sfps_fw_t *w);

#endif /* SFPS_FW_H */
