/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- firmware persistence layer
 * Aureom.AI | SilicaFlux-STORE
 *
 * Sits between the command queue and the FlashMap FTL on the ControlCore.
 *  - Executes host commands (WRITE / READ / DEALLOCATE / FLUSH, FUA) and
 *    reports each command's persistence phase to the recovery controller
 *    (silicaflux_storage_recovery PHASE register) at the moment it is
 *    reached, driven by the FTL's event hook:
 *      BUFFERED       host data in the controller buffer (after DMA)
 *      PROGRAMMED     program status of the command's last page PASS
 *      VERIFIED       ...and read-back compared (SFFTL_F_VERIFY_HOST_WRITE)
 *      MAP_COMMITTED  mapping of the last page committed
 *      DURABLE        every page programmed with its self-describing spare
 *                     record; TRIM: journal page programmed; FLUSH: cache
 *                     destaged and journal flushed
 *    The controller's completion gate, not this code, decides when a SUCCESS
 *    may reach the host (docs/02_PERSISTENCE_MODEL.md).
 *  - Optional volatile write cache (host-enabled WCE): a WRITE without FUA is
 *    acknowledged at BUFFERED ("acknowledged-volatile"); its cache page is
 *    destaged later (eviction, FLUSH, FUA overlap, TRIM overlap, idle) and only
 *    then reported DURABLE.  FLUSH destages everything, then completes.
 *  - Power fault without PLP: nothing is drained (no energy is assumed);
 *    cached data is lost and counted.  The research PLP mode destages instead.
 * Freestanding C99, no malloc, single-threaded (same rules as the FTL).
 * ===========================================================================*/
#ifndef SFPS_H
#define SFPS_H

#include <stdint.h>
#include <stddef.h>
#include "sfftl.h"
#include "sfftl_powersafe.h"
#include "sfps_regs.h"

#define SFPS_VERSION 0x00580100u

/* P51 storage protocol values (silicaflux_storage_pkg / sfs_proto_enums.svh) */
#define SFPS_OP_FLUSH       0x00u
#define SFPS_OP_WRITE       0x01u
#define SFPS_OP_READ        0x02u
#define SFPS_OP_DEALLOCATE  0x09u
#define SFPS_OP_IDENTIFY    0x80u
#define SFPS_OP_GET_LOG     0x81u
#define SFPS_ST_SUCCESS        0u
#define SFPS_ST_INVALID_OPCODE 1u
#define SFPS_ST_INVALID_FIELD  2u
#define SFPS_ST_ABORT_PWR_LOSS 5u
#define SFPS_ST_INTERNAL_ERR   6u
#define SFPS_ST_LBA_RANGE      8u
#define SFPS_ST_CAPACITY       9u
#define SFPS_ST_ACCESS_DENIED 10u
#define SFPS_ST_MEDIA_UNREC   16u
#define SFPS_ST_MEDIA_WRITE   17u
#define SFPS_ERR_NONE          0u
#define SFPS_ERR_NAND_ECC_UE   9u
#define SFPS_ERR_NAND_FAIL    10u
#define SFPS_ERR_FW           13u
#define SFPS_ERR_QUIESCED     14u
#define SFPS_ERR_NAND_WP      16u

/* synthetic events this layer adds to the FTL hook stream (crash points) */
#define SFPS_EV_BEFORE_CPL     100u  /* command finished, completion about to be posted (a = slot, b = status) */
#define SFPS_EV_DESTAGE        101u  /* a cache page is about to be destaged (a = LPN)                         */
#define SFPS_EV_FLUSH_DONE     102u  /* FLUSH: cache destaged + journal flushed, before its completion         */

#define SFPS_WC_MAX    32u            /* cache pages, upper bound */
#define SFPS_SLOTS_MAX 32u            /* controller slots tracked (N_SLOTS <= 32) */

/* controller interface; every member may be NULL (host tests without RTL) */
typedef struct {
  void *ctx;
  void (*phase)(void *ctx, int slot, uint32_t ph);   /* SFPR_PH_* reached by the command in `slot`    */
  void (*retire)(void *ctx, int slot);                /* acknowledged-volatile write cannot be durable */
  int  (*inhibited)(void *ctx);                       /* power fault: start no new NAND work           */
} sfps_ctrl_t;

typedef struct {
  uint64_t cmds, writes, reads, trims, flushes, fua_writes, errors, aborted_pf;
  uint64_t wt_writes;              /* write-through (durable before acknowledgement)        */
  uint64_t vol_writes;             /* acknowledged-volatile                                 */
  uint64_t cache_hits_w, cache_hits_r, evictions, destages, destage_fail;
  uint64_t idle_destages, flush_destages, overlap_destages;
  uint64_t vol_lost_at_pf;         /* dirty cache pages at a power fault (no PLP: lost)     */
  uint64_t phase_reports;
} sfps_stats_t;

typedef struct {
  uint8_t  op, fua;
  int      slot;          /* recovery-controller slot (= downstream TID), -1 = untracked */
  uint64_t lba;
  uint32_t nlb;
  void    *buf;           /* data in the controller buffer (nlb * lba_bytes) */
} sfps_cmd_t;

typedef struct {
  uint8_t status, err;
  uint8_t vol;            /* SUCCESS of a WRITE that is NOT yet durable (cache) */
} sfps_cpl_t;

typedef struct {
  sfftl_t     *ftl;
  sfps_ctrl_t  ctrl;
  int          wce;                 /* host enabled the volatile write cache             */
  int          plp;                 /* research PLP mode: destage on power fault         */
  uint32_t     wc_n;                /* cache pages (0 = no cache: always write-through)  */
  uint8_t     *wc_buf;              /* wc_n * page_data_bytes, caller provided           */
  uint32_t     wc_lpn[SFPS_WC_MAX];
  uint32_t     wc_mask[SFPS_WC_MAX];/* controller slots whose data is in the page         */
  uint32_t     wc_age[SFPS_WC_MAX];
  uint8_t      wc_valid[SFPS_WC_MAX], wc_dirty[SFPS_WC_MAX];
  uint8_t      cmd_pend[SFPS_SLOTS_MAX];
  uint32_t     tick;
  /* phase tracking of the command executing now */
  int          cur_slot;
  uint32_t     cur_last_lpn, cur_prog_lpn;
  int          cur_write, cur_durable;
  uint32_t     cur_ph;
  /* chained hook (crash-injection framework, tests) */
  sfftl_hook_fn user_hook;
  void        *user_ctx;
  sfps_stats_t st;
} sfps_t;

int  sfps_init(sfps_t *p, const sfps_ctrl_t *ctrl, void *wc_buf, uint32_t wc_pages);
/* bind to a mounted FTL instance (after every format / mount): installs the hook */
void sfps_attach(sfps_t *p, sfftl_t *ftl);
/* the hook to pass in sfftl_opts_t when mounting (ctx = the sfps_t) */
void sfps_hook(void *ctx, const sfftl_ev_t *ev);
void sfps_set_user_hook(sfps_t *p, sfftl_hook_fn fn, void *ctx);

void sfps_exec(sfps_t *p, const sfps_cmd_t *c, sfps_cpl_t *cpl);
int  sfps_flush_cache(sfps_t *p);         /* destage every dirty page; SFFTL_* rc */
int  sfps_idle(sfps_t *p);                /* destage the oldest dirty page; 1 = did work, 0 = none, <0 rc */
int  sfps_set_wce(sfps_t *p, int on);     /* turning it off destages first */
void sfps_power_fault(sfps_t *p);         /* warning: no-PLP -> stop, count cached data at risk */
void sfps_drop_cache(sfps_t *p);          /* controller reset / supply loss: RAM contents gone */
uint32_t sfps_dirty_pages(const sfps_t *p);
const char *sfps_phase_name(uint32_t ph);

#endif /* SFPS_H */
