/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- recovery reference model (sfref.h)
 * ===========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include "sfref.h"

static uint64_t mix(uint64_t z) {
  z += 0x9E3779B97F4A7C15ull;
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
  return z ^ (z >> 31);
}
static void put32(uint8_t *p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24); }
static uint32_t get32(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }

static void *heap_alloc(size_t n) { return calloc(1, n); }

int sfref_init(sfref_t *r, uint64_t nlba, uint32_t lba_bytes, uint32_t spp, sfref_alloc_fn alloc) {
  if (!alloc) alloc = heap_alloc;
  memset(r, 0, sizeof(*r));
  r->nlba = nlba;
  r->lba_bytes = lba_bytes;
  r->spp = spp ? spp : 1u;
  r->vol_cap = 1u << 16;
  r->ops_cap = 1u << 13;
  r->opv_cap = 1u << 18;
  r->l = (sfref_lba_t *)alloc((size_t)nlba * sizeof(sfref_lba_t));
  r->obs = (uint32_t *)alloc((size_t)nlba * 4u);
  r->obsz = (uint8_t *)alloc((size_t)nlba);
  r->vol = (sfref_vol_t *)alloc((size_t)r->vol_cap * sizeof(sfref_vol_t));
  r->ops = (sfref_op_t *)alloc((size_t)r->ops_cap * sizeof(sfref_op_t));
  r->opv = (uint32_t *)alloc((size_t)r->opv_cap * 4u);
  if (!r->l || !r->obs || !r->obsz || !r->vol || !r->ops || !r->opv) return -1;
  for (uint64_t i = 0; i < nlba; i++) { memset(&r->l[i], 0, sizeof(sfref_lba_t)); r->l[i].dz = 1; }
  return 0;
}

void sfref_reset_stats(sfref_t *r) {
  r->checks = r->mismatches = r->durable_acks = r->volatile_acks = r->failed_ops = r->flush_promotions = 0;
  r->resolved_new = r->resolved_old = r->vol_lost = r->atomic_checks = r->atomic_viol = 0;
}

void sfref_fill(const sfref_t *r, uint64_t lba, uint32_t ver, uint8_t *out) {
  if (ver == 0) { memset(out, 0, r->lba_bytes); return; }
  put32(out, (uint32_t)lba);
  put32(out + 4, ver);
  uint64_t seed = mix(lba * 0x100000001B3ull ^ ((uint64_t)ver << 32) ^ ver);
  for (uint32_t i = 8; i < r->lba_bytes; i += 8) {
    uint64_t w = mix(seed + i);
    memcpy(out + i, &w, 8);
  }
}

/* ---------------------------------------------------------------- unresolved-op list (atomicity) */
static void ops_compact(sfref_t *r) {
  uint32_t n = 0, used = 0;
  for (uint32_t i = 0; i < r->nops; i++) {
    if (!r->ops[i].alive) continue;
    sfref_op_t o = r->ops[i];
    memmove(&r->opv[used], &r->opv[o.v0off], o.n * 4u);
    o.v0off = used;
    used += o.n;
    r->ops[n++] = o;
  }
  r->nops = n;
  r->opv_used = used;
}

static uint32_t ops_add(sfref_t *r, uint64_t lba, uint32_t n) {
  if (r->nops >= r->ops_cap || r->opv_used + n > r->opv_cap) ops_compact(r);
  if (r->nops >= r->ops_cap || r->opv_used + n > r->opv_cap) {
    /* still full (long volatile runs without a crash): stop tracking the oldest half */
    for (uint32_t i = 0; i < r->nops / 2u; i++) r->ops[i].alive = 0;
    ops_compact(r);
  }
  if (r->nops >= r->ops_cap || r->opv_used + n > r->opv_cap) return UINT32_MAX;
  sfref_op_t *o = &r->ops[r->nops];
  o->lba = lba; o->n = n; o->v0off = r->opv_used; o->alive = 1;
  r->opv_used += n;
  return r->nops++;
}

uint32_t sfref_write_begin(sfref_t *r, uint64_t lba, uint32_t n, uint8_t *data) {
  uint32_t op = ops_add(r, lba, n);
  for (uint32_t i = 0; i < n; i++) {
    sfref_lba_t *L = &r->l[lba + i];
    uint32_t v = ++L->nv;
    L->w = v;                        /* submitted: may be on the medium from now on (even if the host
                                        never sees a completion -- the controller may die mid-command) */
    if (op != UINT32_MAX) r->opv[r->ops[op].v0off + i] = v;
    sfref_fill(r, lba + i, v, data + (size_t)i * r->lba_bytes);
  }
  return op;
}

void sfref_write_end(sfref_t *r, uint32_t op, uint64_t lba, uint32_t n, int ack) {
  for (uint32_t i = 0; i < n; i++) {
    sfref_lba_t *L = &r->l[lba + i];
    uint32_t v = L->nv;                                 /* the version this op assigned (no overlap in flight) */
    if (op != UINT32_MAX) v = r->opv[r->ops[op].v0off + i];
    if (v > L->w) L->w = v;
    if (ack == SFREF_ACK_DURABLE) {
      if (v > L->d) { L->d = v; L->dz = 0; }           /* versions only grow: v > d for a new op */
      if (L->zt <= L->d) L->zt = 0;
    } else if (ack == SFREF_ACK_VOLATILE) {
      if (r->nvol < r->vol_cap) { r->vol[r->nvol].lba = (uint32_t)(lba + i); r->vol[r->nvol].ver = v; r->nvol++; }
    }
  }
  if (ack == SFREF_ACK_DURABLE) { r->durable_acks++; if (op != UINT32_MAX) r->ops[op].alive = 0; }
  else if (ack == SFREF_ACK_VOLATILE) r->volatile_acks++;
  else r->failed_ops++;
}

uint32_t sfref_trim_begin(sfref_t *r, uint64_t lba, uint32_t n) {
  for (uint32_t i = 0; i < n; i++) {
    sfref_lba_t *L = &r->l[lba + i];
    L->nv++;
    L->tv = L->nv;
    L->w = L->nv;                    /* submitted: may take effect */
    L->zt = L->nv;
  }
  return 0;
}

void sfref_trim_end(sfref_t *r, uint64_t lba, uint32_t n, int ack) {
  for (uint32_t i = 0; i < n; i++) {
    sfref_lba_t *L = &r->l[lba + i];
    uint32_t v = L->nv;
    if (v > L->w) L->w = v;
    if (ack == SFREF_ACK_DURABLE) { L->d = v; L->dz = 1; L->zt = 0; }
    else if (v > L->zt) L->zt = v;
  }
  if (ack == SFREF_ACK_DURABLE) r->durable_acks++; else r->failed_ops++;
}

uint32_t sfref_flush_begin(const sfref_t *r) { return r->nvol; }
int sfref_vol_full(const sfref_t *r) { return r->nvol + 4096u >= r->vol_cap; }

void sfref_flush_end(sfref_t *r, uint32_t mark, int ok) {
  if (!ok || mark == 0) return;
  if (mark > r->nvol) mark = r->nvol;
  for (uint32_t i = 0; i < mark; i++) {
    sfref_lba_t *L = &r->l[r->vol[i].lba];
    uint32_t v = r->vol[i].ver;
    if (v > L->d) {                                     /* newer than the durable state: now durable */
      L->d = v; L->dz = 0;                              /* (a later unacknowledged trim keeps zt > d) */
      if (L->zt <= L->d) L->zt = 0;
      r->flush_promotions++;
    }
  }
  memmove(r->vol, r->vol + mark, (size_t)(r->nvol - mark) * sizeof(sfref_vol_t));
  r->nvol -= mark;
}

void sfref_crash(sfref_t *r) {
  r->vol_lost += r->nvol;
  r->nvol = 0;
}

static int is_zero(const uint8_t *p, uint32_t n) { for (uint32_t i = 0; i < n; i++) if (p[i]) return 0; return 1; }

int sfref_check(sfref_t *r, uint64_t lba, const uint8_t *data, int after_crash) {
  sfref_lba_t *L = &r->l[lba];
  r->checks++;
  if (is_zero(data, r->lba_bytes)) {
    int ok = L->dz || L->zt > L->d;
    r->obs[lba] = 0; r->obsz[lba] = 1;
    if (!ok) {
      r->mismatches++;
      snprintf(r->why, sizeof(r->why), "LBA %" PRIu64 ": zeros, but version %u is durable (newest %u)", lba, L->d, L->w);
      return 1;
    }
    if (after_crash) {
      if (!L->dz || L->w != L->d) { if (L->w > L->d) r->resolved_old++; }
      L->d = L->w; L->dz = 1; L->zt = 0;              /* settled: zeros until a newer write */
    }
    return 0;
  }
  uint32_t hl = get32(data), v = get32(data + 4);
  uint8_t exp[16384];
  int intact = hl == (uint32_t)lba && v != 0 && v <= L->nv;
  if (intact) { sfref_fill(r, lba, v, exp); intact = memcmp(exp, data, r->lba_bytes) == 0; }
  r->obs[lba] = v; r->obsz[lba] = 0;
  if (!intact) {
    r->mismatches++;
    snprintf(r->why, sizeof(r->why), "LBA %" PRIu64 ": garbage or misdirected data (header lba %u ver %u)", lba, hl, v);
    return 1;
  }
  int ok = (v == L->d && !L->dz) || (v > L->d && v <= L->w);
  if (!ok) {
    r->mismatches++;
    snprintf(r->why, sizeof(r->why), "LBA %" PRIu64 ": version %u, durable %u%s, newest %u", lba, v, L->d,
             L->dz ? " (zeros)" : "", L->w);
    return 1;
  }
  if (after_crash) {
    if (v > L->d || L->dz) r->resolved_new++;
    else if (L->w > L->d) r->resolved_old++;
    L->d = v; L->dz = 0; L->w = v; L->zt = 0;          /* settled: later reads must return v */
  }
  return 0;
}

uint32_t sfref_check_atomic(sfref_t *r) {
  uint32_t viol = 0;
  for (uint32_t i = 0; i < r->nops; i++) {
    sfref_op_t *o = &r->ops[i];
    if (!o->alive) continue;
    uint64_t end = o->lba + o->n;
    uint64_t l = o->lba;
    while (l < end) {
      uint64_t pg_end = (l / r->spp + 1u) * r->spp;
      if (pg_end > end) pg_end = end;
      int first = -1, bad = 0;
      for (uint64_t x = l; x < pg_end; x++) {
        uint32_t v = r->opv[o->v0off + (uint32_t)(x - o->lba)];
        /* a sector a LATER operation changed says nothing about this write:
         * a newer version (later write) or zeros with a later DEALLOCATE */
        if (!r->obsz[x] && r->obs[x] > v) continue;
        if (r->obsz[x] && r->l[x].tv > v) continue;
        int has = !r->obsz[x] && r->obs[x] == v;
        if (first < 0) first = has; else if (has != first) bad = 1;
      }
      if (pg_end - l > 1u) r->atomic_checks++;
      if (bad) {
        viol++;
        snprintf(r->why, sizeof(r->why), "atomicity: write of LBA %" PRIu64 "+%u torn inside the logical page at LBA %" PRIu64,
                 o->lba, o->n, l);
      }
      l = pg_end;
    }
    o->alive = 0;
  }
  r->nops = 0;
  r->opv_used = 0;
  r->atomic_viol += viol;
  return viol;
}
