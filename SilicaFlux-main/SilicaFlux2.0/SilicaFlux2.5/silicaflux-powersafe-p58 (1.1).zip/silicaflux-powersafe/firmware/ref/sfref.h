/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- recovery reference model
 *
 * The host's knowledge of what the device must return after any crash.  It is
 * independent of the controller: it never reads FTL, firmware or RTL state,
 * only what the host submitted and the completions it received.
 *
 * Data: every sector written carries {LBA, version} in its first 8 bytes and
 * a hash pattern of (LBA, version) in the rest, so a read reveals exactly
 * which version came back (and whether it is intact).  Zeros = never written
 * or deallocated.  Versions count per LBA.
 *
 * Contract checked (docs/02_PERSISTENCE_MODEL.md):
 *   acknowledgement classes
 *     DURABLE   WRITE with FUA, or with the volatile write cache disabled;
 *               DEALLOCATE; FLUSH                -> must survive any crash
 *     VOLATILE  WRITE acknowledged with the cache enabled, no FUA
 *               -> becomes DURABLE when a FLUSH submitted after its
 *                  completion completes successfully
 *     NONE      error completion, or in flight at the crash -> may be
 *               present or absent
 *   per LBA after a crash:  value == last DURABLE version, or any version
 *   submitted after it (never an older one, never garbage, never another
 *   LBA's data); zeros only if the durable state is zero or a DEALLOCATE was
 *   submitted after it
 *   stability: once a read after recovery returned a value, later recoveries
 *   (with no new writes) return the same value
 *   atomicity: a write's sectors inside one logical page are all new or all
 *   old (sfref_check_atomic)
 * The state can live in shared memory (alloc callback) so a crash campaign
 * whose controller process dies keeps the host's knowledge.
 * ===========================================================================*/
#ifndef SFREF_H
#define SFREF_H

#include <stdint.h>
#include <stddef.h>

#define SFREF_ACK_NONE     0
#define SFREF_ACK_DURABLE  1
#define SFREF_ACK_VOLATILE 2

typedef struct {
  uint32_t d;          /* version of the last durable state (0 = initial zeros)  */
  uint32_t w;          /* newest version submitted                               */
  uint32_t zt;         /* newest DEALLOCATE version not yet durable (0 = none)   */
  uint32_t nv;         /* version counter                                        */
  uint32_t tv;         /* newest DEALLOCATE version submitted (any outcome)       */
  uint8_t  dz;         /* durable state is zeros                                 */
  uint8_t  rsvd[3];
} sfref_lba_t;

typedef struct { uint32_t lba, ver; } sfref_vol_t;
typedef struct { uint64_t lba; uint32_t n, v0off, alive; } sfref_op_t;   /* unresolved write (atomicity) */

typedef struct {
  uint64_t     nlba;
  uint32_t     lba_bytes, spp;
  sfref_lba_t *l;
  uint32_t    *obs;        /* version observed by the last verification (atomicity) */
  uint8_t     *obsz;
  sfref_vol_t *vol;        /* volatile acknowledgements not yet covered by a FLUSH */
  uint32_t     nvol, vol_cap;
  sfref_op_t  *ops;        /* unresolved writes */
  uint32_t    *opv;        /* their versions (per LBA) */
  uint32_t     nops, ops_cap, opv_used, opv_cap;
  /* statistics */
  uint64_t     checks, mismatches, durable_acks, volatile_acks, failed_ops, flush_promotions;
  uint64_t     resolved_new, resolved_old, vol_lost, atomic_checks, atomic_viol;
  char         why[200];
} sfref_t;

typedef void *(*sfref_alloc_fn)(size_t bytes);
int  sfref_init(sfref_t *r, uint64_t nlba, uint32_t lba_bytes, uint32_t spp, sfref_alloc_fn alloc);
void sfref_reset_stats(sfref_t *r);

/* data generation */
void sfref_fill(const sfref_t *r, uint64_t lba, uint32_t ver, uint8_t *out);  /* ver 0 -> zeros */

/* operations: begin (assign versions, fill data), then end with the
 * acknowledgement class the host received */
uint32_t sfref_write_begin(sfref_t *r, uint64_t lba, uint32_t n, uint8_t *data);  /* returns op handle */
void     sfref_write_end(sfref_t *r, uint32_t op, uint64_t lba, uint32_t n, int ack);
uint32_t sfref_trim_begin(sfref_t *r, uint64_t lba, uint32_t n);
void     sfref_trim_end(sfref_t *r, uint64_t lba, uint32_t n, int ack);
uint32_t sfref_flush_begin(const sfref_t *r);                 /* mark = volatile acks covered */
void     sfref_flush_end(sfref_t *r, uint32_t mark, int ok);
int      sfref_vol_full(const sfref_t *r);                    /* host should FLUSH */

/* verification after a recovery: check one sector, resolve its state.
 * returns 0 ok, 1 mismatch (r->why) */
int  sfref_check(sfref_t *r, uint64_t lba, const uint8_t *data, int after_crash);
/* after a full verification: every unresolved write's sectors within one
 * logical page must agree (all new or all old); clears the list.
 * returns the number of violations */
uint32_t sfref_check_atomic(sfref_t *r);
/* a crash happened: volatile acknowledgements not covered by a FLUSH are now
 * only "may be present" */
void sfref_crash(sfref_t *r);

#endif /* SFREF_H */
