/* =============================================================================
 * SilicaFlux FlashMap -- garbage collector
 *
 * Victim order:  1. blocks flagged RETIRE (failing hardware)
 *                2. blocks flagged REFRESH (high corrected bit count)
 *                3. policy: GREEDY (fewest valid pages; ties lowest EC, then
 *                   lowest index) or COST_BENEFIT (max (1-u)*age / 2u,
 *                   u = valid/pages_per_block, age = SEQ distance since close)
 *
 * Relocation of one valid page (never destroys the last copy):
 *   a. read source page, check ECC status, spare CRC and that its LPN maps
 *      to this very page (VBM says valid; L2P agrees)
 *   b. program a copy (type RELOC, new SEQ) through write_page() -- program
 *      status confirmed, program failures retried on another block
 *   c. optional read-back of the copy (SFFTL_F_VERIFY_GC_COPY)
 *   d. commit the mapping; the source page becomes invalid
 * The source block is erased only when its valid count is zero, i.e. every
 * valid page has a confirmed, committed copy.  Each copy is durable by itself
 * (its spare record: LPN + newer SEQ), so no checkpoint is required before the
 * erase -- recovery prefers the higher SEQ.  With SFFTL_F_PARANOID the whole
 * L2P is also scanned for references into the victim before the erase.
 * ===========================================================================*/
#include "sfftl_internal.h"

static int urgent(const sfftl_blk_t *bk) {
  return bk->state == SFFTL_BS_CLOSED && (bk->flags & (SFFTL_BF_RETIRE | SFFTL_BF_REFRESH));
}

uint32_t gc_pick_victim(sfftl_t *f) {
  const uint32_t ppb = f->g.pages_per_block;
  uint32_t best = SFFTL_NONE;
  for (uint32_t b = 0; b < f->g.blocks; b++)
    if (f->blk[b].state == SFFTL_BS_CLOSED && (f->blk[b].flags & SFFTL_BF_RETIRE)) return b;
  for (uint32_t b = 0; b < f->g.blocks; b++)
    if (f->blk[b].state == SFFTL_BS_CLOSED && (f->blk[b].flags & SFFTL_BF_REFRESH)) return b;
  for (uint32_t b = 0; b < f->g.blocks; b++) {
    const sfftl_blk_t *bk = &f->blk[b];
    if (bk->state != SFFTL_BS_CLOSED || bk->valid >= ppb) continue;
    if (best == SFFTL_NONE) { best = b; continue; }
    const sfftl_blk_t *bb = &f->blk[best];
    if (f->cfg.gc_policy == SFFTL_GC_COST_BENEFIT) {
      /* compare (ppb-v)*age/(2v): cross-multiplied, v = 0 is infinitely good */
      uint64_t age_b = (uint64_t)(uint32_t)((uint32_t)f->next_seq - bk->close_seq) + 1u;
      uint64_t age_o = (uint64_t)(uint32_t)((uint32_t)f->next_seq - bb->close_seq) + 1u;
      uint64_t lhs = (uint64_t)(ppb - bk->valid) * age_b * (uint64_t)(2u * bb->valid);
      uint64_t rhs = (uint64_t)(ppb - bb->valid) * age_o * (uint64_t)(2u * bk->valid);
      if (bk->valid == 0 && bb->valid != 0) best = b;
      else if (bb->valid != 0 && lhs > rhs) best = b;
    } else {
      if (bk->valid < bb->valid || (bk->valid == bb->valid && bk->ec < bb->ec)) best = b;
    }
  }
  return best;
}

static int relocate_page(sfftl_t *f, uint32_t src, uint32_t stream) {
  uint8_t spare[SFFTL_OOB_BYTES], vspare[SFFTL_OOB_BYTES];
  oob_t o;
  uint8_t *buf = f->buf_gc;
  int st = nand_read(f, src, buf, spare, RD_RELOC);
  if (st == SFFTL_HAL_POWER_LOSS) return SFFTL_EPOWER;
  if (st != SFFTL_HAL_OK && st != SFFTL_HAL_CORRECTED) return SFFTL_EIO;     /* unreadable: stays stranded */
  if (oob_parse(f, spare, buf, &o) != 0 || o.type == SFFTL_OOB_TYPE_META) { f->st.crc_errors++; return SFFTL_EIO; }
  if (o.tag >= f->nlpn || f->l2p[o.tag] != src) { f->st.lpn_mismatch++; return SFFTL_ECORRUPT; }
  for (uint32_t attempt = 0; attempt < SFFTL_PROG_ATTEMPTS; attempt++) {
    uint32_t dst;
    int rc = write_page(f, stream, SFFTL_OOB_TYPE_RELOC, o.tag, buf, &dst);
    if (rc < 0) return rc;
    if (f->cfg.flags & SFFTL_F_VERIFY_GC_COPY) {
      oob_t vo;
      int vs = nand_read(f, dst, f->buf_meta, vspare, RD_VERIFY);
      if (vs == SFFTL_HAL_POWER_LOSS) return SFFTL_EPOWER;
      if ((vs != SFFTL_HAL_OK && vs != SFFTL_HAL_CORRECTED) || oob_parse(f, vspare, f->buf_meta, &vo) != 0 ||
          vo.tag != o.tag || memcmp(f->buf_meta, buf, f->g.page_data_bytes) != 0) {
        /* copy does not read back: treat like a program failure, try again */
        f->st.crc_errors++;
        rc = bbm_program_failed(f, ppn_blk(f, dst));
        if (rc < 0) return rc;
        continue;
      }
    }
    map_commit(f, o.tag, dst);
    streams_settle(f);
    f->st.gc_pages_moved++;
    return SFFTL_OK;
  }
  return SFFTL_EIO;
}

static int victim_referenced(const sfftl_t *f, uint32_t v) {
  for (uint32_t l = 0; l < f->nlpn; l++)
    if (f->l2p[l] != SFFTL_NONE && ppn_blk(f, f->l2p[l]) == v) return 1;
  return 0;
}

static void collect_begin(sfftl_t *f, uint32_t v, uint32_t stream) {
  const sfftl_blk_t *bk = &f->blk[v];
  HOOK(f, SFFTL_EV_GC_VICTIM, v, bk->valid, stream == ST_COLD ? SFFTL_PGC_COLD : SFFTL_PGC_RELOC);
  if (bk->flags & SFFTL_BF_RETIRE) f->st.retire_moves++;
  else if (bk->flags & SFFTL_BF_REFRESH) f->st.refresh_moves++;
  else if (stream == ST_COLD) f->st.wl_static_moves++;
  if (bk->valid == 0) f->st.gc_zero_valid++;
}

/* Relocate up to `budget` valid pages of victim v, resuming at *cursor.
 * Returns 1 when the victim is finished (freed + erased, or retired), 0 when
 * valid pages remain, <0 on error.  The victim may become FREE (and even be
 * reused) as soon as its last valid page has moved: the loop stops there. */
static int collect_step(sfftl_t *f, uint32_t v, uint32_t stream, uint32_t budget, uint32_t *cursor) {
  sfftl_blk_t *bk = &f->blk[v];
  const uint32_t ppb = f->g.pages_per_block;
  uint64_t moved0 = f->st.gc_pages_moved;
  while (*cursor < ppb && bk->state == SFFTL_BS_CLOSED && bk->valid > 0 && budget > 0) {
    uint32_t src = mk_ppn(f, v, *cursor);
    if (!vbm_get(f, src)) { (*cursor)++; continue; }
    if (ps_blocked(f)) return SFFTL_EPOWER;
    int rc = relocate_page(f, src, stream);
    (*cursor)++;
    budget--;
    if (rc == SFFTL_EIO) { bk->flags |= SFFTL_BF_RETIRE; continue; }   /* unreadable: stays, block retires */
    if (rc < 0) return rc;
  }
  if (stream == ST_COLD) f->st.wl_static_pages += f->st.gc_pages_moved - moved0;
  if (bk->state == SFFTL_BS_CLOSED && bk->valid > 0 && *cursor < ppb) return 0;
  f->st.gc_victims++;
  if (bk->state == SFFTL_BS_CLOSED && bk->valid > 0)        /* pages that could not be read: stranded */
    return bbm_retire(f, v, SFFTL_RETIRE_READ) < 0 ? SFFTL_EIO : 1;
  if ((f->cfg.flags & SFFTL_F_PARANOID) && (bk->state == SFFTL_BS_CLOSED || bk->state == SFFTL_BS_FREE) &&
      victim_referenced(f, v))
    return SFFTL_ECORRUPT;
  if (bk->state == SFFTL_BS_CLOSED && (bk->flags & SFFTL_BF_RETIRE)) {
    int rc = bbm_retire(f, v, SFFTL_RETIRE_PROGRAM);
    return rc < 0 ? rc : 1;
  }
  if (bk->state == SFFTL_BS_CLOSED) block_make_free(f, v);          /* valid == 0 */
  if (bk->state == SFFTL_BS_FREE && !(bk->flags & SFFTL_BF_ERASED)) {
    if (ps_blocked(f)) return SFFTL_EPOWER;
    f->ev_erc = SFFTL_ERC_GC;
    int st = nand_erase(f, v);                                       /* eager erase: allocation is then cheap */
    if (st == SFFTL_HAL_ERASE_FAIL) { int rc = bbm_erase_failed(f, v); return rc < 0 ? rc : 1; }
    if (st != SFFTL_HAL_OK) return hal_rc(st);
  }
  return 1;
}

int gc_collect(sfftl_t *f, uint32_t v, uint32_t stream) {
  if (f->blk[v].state != SFFTL_BS_CLOSED) return SFFTL_EINVAL;
  if (v == f->gc_victim) f->gc_victim = SFFTL_NONE;               /* a paced collection of it is superseded */
  collect_begin(f, v, stream);
  uint32_t cursor = 0;
  int rc = collect_step(f, v, stream, 0xFFFFFFFFu, &cursor);
  return rc < 0 ? rc : SFFTL_OK;
}

static int gc_static(sfftl_t *f);

/* finish the paced victim, if any (foreground / background GC first do this) */
static int paced_finish(sfftl_t *f) {
  if (f->gc_victim == SFFTL_NONE) return SFFTL_OK;
  uint32_t v = f->gc_victim;
  f->gc_victim = SFFTL_NONE;
  int rc = collect_step(f, v, ST_RELOC, 0xFFFFFFFFu, &f->gc_cursor);
  return rc < 0 ? rc : SFFTL_OK;
}

/* Paced GC (SFFTL_F_PACED_GC): called after every host page.  At
 * gc_fg_free_blocks + 1 free blocks a victim is chosen and ceil(v / (ppb - v)) of
 * its valid pages are moved per host page, so freeing one block is spread
 * over the (ppb - v) host pages it makes room for, instead of stalling one
 * write for the whole relocation.  The blocking foreground GC stays as the
 * safety net at gc_fg_free_blocks. */
int gc_paced(sfftl_t *f) {
  if (!(f->cfg.flags & SFFTL_F_PACED_GC)) return SFFTL_OK;
  const uint32_t ppb = f->g.pages_per_block;
  if (f->gc_victim == SFFTL_NONE) {
    /* start just above the blocking threshold: the pace frees one block per
     * (ppb - v) host pages, i.e. exactly as fast as the host consumes them,
     * so starting earlier would only spend over-provisioning (higher WA) */
    if (f->free_blocks > f->cfg.gc_fg_free_blocks + 1u) return SFFTL_OK;
    uint32_t v = gc_pick_victim(f);
    if (v == SFFTL_NONE || (f->blk[v].valid >= ppb && !urgent(&f->blk[v]))) return SFFTL_OK;
    uint32_t vv = f->blk[v].valid, gain = ppb - vv;
    collect_begin(f, v, ST_RELOC);
    f->gc_victim = v;
    f->gc_cursor = 0;
    f->gc_pace = gain ? (vv + gain - 1u) / gain : ppb;
    if (f->gc_pace == 0) f->gc_pace = 1;
    f->st.gc_paced_victims++;
  }
  int rc = collect_step(f, f->gc_victim, ST_RELOC, f->gc_pace, &f->gc_cursor);
  if (rc != 0) f->gc_victim = SFFTL_NONE;
  if (rc < 0) return rc;
  if (rc == 1) return gc_static(f);              /* wear check at each completed victim */
  return SFFTL_OK;
}

static int gc_static(sfftl_t *f) {
  uint32_t v = wear_static_victim(f);
  if (v == SFFTL_NONE) return SFFTL_OK;
  if (f->free_blocks <= 1u) return SFFTL_OK;
  return gc_collect(f, v, ST_COLD);
}

int gc_foreground(sfftl_t *f) {
  const uint32_t ppb = f->g.pages_per_block;
  uint32_t guard = 2u * f->g.blocks + 8u;
  f->st.gc_fg_runs++;
  int prc = paced_finish(f);
  if (prc < 0) return prc;
  while (f->free_blocks <= f->cfg.gc_fg_free_blocks) {
    if (guard-- == 0u) return SFFTL_ENOSPC;
    uint32_t v = gc_pick_victim(f);
    if (v == SFFTL_NONE) return SFFTL_ENOSPC;
    if (f->blk[v].valid >= ppb && !urgent(&f->blk[v])) return SFFTL_ENOSPC;   /* no invalid page anywhere */
    int rc = gc_collect(f, v, ST_RELOC);
    if (rc < 0) return rc;
  }
  return gc_static(f);
}

int gc_background(sfftl_t *f, uint32_t budget) {
  const uint32_t ppb = f->g.pages_per_block;
  uint64_t m0 = f->st.gc_pages_moved;
  uint32_t guard = 2u * f->g.blocks + 8u;
  int prc = paced_finish(f);
  if (prc < 0) return prc;
  for (;;) {
    if (f->st.gc_pages_moved - m0 >= budget || guard-- == 0u) break;
    int need = f->free_blocks < f->cfg.gc_bg_free_blocks;
    uint32_t v = gc_pick_victim(f);
    if (v == SFFTL_NONE) break;
    if (!urgent(&f->blk[v]) && (!need || f->blk[v].valid >= ppb)) break;
    f->st.gc_bg_runs++;
    int rc = gc_collect(f, v, ST_RELOC);
    if (rc < 0) return rc;
  }
  int rc = gc_static(f);
  if (rc < 0) return rc;
  return (int)(f->st.gc_pages_moved - m0);
}
