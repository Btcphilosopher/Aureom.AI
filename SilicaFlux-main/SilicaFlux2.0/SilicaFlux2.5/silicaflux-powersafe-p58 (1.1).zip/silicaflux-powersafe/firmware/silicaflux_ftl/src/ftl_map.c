/* =============================================================================
 * SilicaFlux FlashMap -- mapping structures
 *
 *   L2P   uint32_t per logical page: PPN, or SFFTL_NONE (unmapped -> reads 0)
 *   VBM   one bit per physical page: page holds the current copy of its LPN
 *   blk[] valid-page count per block (= popcount of the block's VBM bits)
 *
 * The three are updated together, only here, and only AFTER the new page's
 * program status was confirmed (step 4 of the out-of-place write).  Retiring
 * the previous copy (step 5) is the VBM clear + valid-count decrement; the old
 * page stays physically intact until its block is erased.
 * ===========================================================================*/
#include "sfftl_internal.h"

void map_invalidate_ppn(sfftl_t *f, uint32_t ppn) {
  if (!vbm_get(f, ppn)) return;
  vbm_clr(f, ppn);
  uint32_t b = ppn_blk(f, ppn);
  sfftl_blk_t *bk = &f->blk[b];
  bk->valid--;
  /* a closed block whose last valid page went away becomes free at once
   * (erased later, on allocation or by GC); retiring blocks are left to GC */
  if (bk->valid == 0 && bk->state == SFFTL_BS_CLOSED && !(bk->flags & (SFFTL_BF_RETIRE)))
    block_make_free(f, b);
}

void map_commit(sfftl_t *f, uint32_t lpn, uint32_t ppn) {
  uint32_t old = f->l2p[lpn];
  f->l2p[lpn] = ppn;
  vbm_set(f, ppn);
  f->blk[ppn_blk(f, ppn)].valid++;
  if (old != SFFTL_NONE) map_invalidate_ppn(f, old);
  HOOK(f, SFFTL_EV_MAP_COMMIT, lpn, ppn, f->ev_pgc);
}

void map_unmap(sfftl_t *f, uint32_t lpn) {
  uint32_t old = f->l2p[lpn];
  if (old == SFFTL_NONE) return;
  f->l2p[lpn] = SFFTL_NONE;
  map_invalidate_ppn(f, old);
}
