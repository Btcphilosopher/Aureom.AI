/* =============================================================================
 * SilicaFlux FlashMap -- Project 58 persistent event log and hook registration
 *
 * The event area travels inside every checkpoint body (schema 2, see
 * sfftl_schema.h): 8 header words of lifetime counters followed by a ring of
 * the SFFTL_EVT_RING most recent power / recovery events.  It is covered by
 * the body CRC and the commit like the rest of the checkpoint, so it is as
 * crash-safe as the mapping: an event is durable once the checkpoint that
 * carries it has committed.  A recovery mount writes that checkpoint before it
 * returns, so the record of an unclean shutdown cannot be lost by the next
 * crash.  Events added at run time (e.g. a brown-out) persist with the next
 * checkpoint (the firmware may force one).
 * ===========================================================================*/
#include "sfftl_internal.h"

void evt_reset(sfftl_t *f) {
  memset(f->evt_hdr, 0, sizeof(f->evt_hdr));
  memset(f->evt_ring, 0, sizeof(f->evt_ring));
  f->evt_hdr[SFFTL_EH_MAGIC] = SFFTL_EVT_MAGIC;
}

uint32_t evt_body_word(const sfftl_t *f, uint32_t j) {
  if (j == SFFTL_EH_MAGIC) return SFFTL_EVT_MAGIC;
  if (j < SFFTL_EVT_HDR_WORDS) return f->evt_hdr[j];
  j -= SFFTL_EVT_HDR_WORDS;
  return j < SFFTL_EVT_RING * SFFTL_EVT_WORDS ? f->evt_ring[j] : 0u;
}

void sfftl_set_hook(sfftl_t *f, sfftl_hook_fn fn, void *ctx) {
  f->hook = fn;
  f->hook_ctx = ctx;
}

void sfftl_event_add(sfftl_t *f, uint32_t type, const uint32_t data[5]) {
  uint32_t idx = f->evt_hdr[SFFTL_EH_TOTAL] % SFFTL_EVT_RING;
  uint32_t *e = &f->evt_ring[idx * SFFTL_EVT_WORDS];
  e[0] = type;
  e[1] = (uint32_t)f->next_seq;
  e[2] = (uint32_t)f->life_mounts;
  for (uint32_t i = 0; i < 5u; i++) e[3 + i] = data ? data[i] : 0u;
  f->evt_hdr[SFFTL_EH_TOTAL]++;
  if (type == SFFTL_EVT_POWER_FAULT || type == SFFTL_EVT_BROWNOUT) f->evt_hdr[SFFTL_EH_PF_EVENTS]++;
}

int sfftl_event_get(const sfftl_t *f, uint32_t i, sfftl_event_t *e) {
  uint32_t total = f->evt_hdr[SFFTL_EH_TOTAL];
  uint32_t have = total < SFFTL_EVT_RING ? total : SFFTL_EVT_RING;
  if (i >= have) return SFFTL_ERANGE;
  uint32_t idx = (total - 1u - i) % SFFTL_EVT_RING;
  memcpy(e->w, &f->evt_ring[idx * SFFTL_EVT_WORDS], sizeof(e->w));
  return SFFTL_OK;
}

void sfftl_persist(const sfftl_t *f, sfftl_persist_t *p) {
  p->events_total     = f->evt_hdr[SFFTL_EH_TOTAL];
  p->unsafe_shutdowns = f->evt_hdr[SFFTL_EH_UNSAFE];
  p->recoveries       = f->evt_hdr[SFFTL_EH_RECOVERIES];
  p->fallback_mounts  = f->evt_hdr[SFFTL_EH_FALLBACK];
  p->meta_damage      = f->evt_hdr[SFFTL_EH_META_DAMAGE];
  p->torn_pages       = f->evt_hdr[SFFTL_EH_TORN];
  p->pf_events        = f->evt_hdr[SFFTL_EH_PF_EVENTS];
}
