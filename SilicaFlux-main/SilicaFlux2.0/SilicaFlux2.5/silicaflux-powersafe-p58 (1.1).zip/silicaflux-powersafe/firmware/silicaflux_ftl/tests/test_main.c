/* =============================================================================
 * SilicaFlux FlashMap -- host test suite
 *
 *   ./sfftl_tests [filter] [--quick]
 *
 * Every data check goes through the independent reference model (refmodel.c).
 * Every test also requires: zero NAND rule violations reported by the
 * simulated device, and sfftl_check() == OK (RAM invariants) at its checkpoints.
 * ===========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <time.h>
#include "harness.h"

static uint64_t g_checks, g_fails;
static int g_tfail, g_quick;

#define CHECK(c, ...)                                                              \
  do {                                                                             \
    g_checks++;                                                                    \
    if (!(c)) {                                                                    \
      g_fails++;                                                                   \
      if (++g_tfail <= 8) {                                                        \
        printf("    FAIL %s:%d: ", __FILE__, __LINE__);                            \
        printf(__VA_ARGS__);                                                       \
        printf("\n");                                                              \
      }                                                                            \
    }                                                                              \
  } while (0)
#define CHECK_OK(rc, what) CHECK((rc) == SFFTL_OK, "%s -> %s", what, sfftl_strerror(rc))
#define SCALE(n) (g_quick ? ((n) / 4u ? (n) / 4u : 1u) : (n))

static sfftl_cfg_t base_cfg(void) {
  sfftl_cfg_t c;
  sfftl_cfg_default(&c);
  c.flags |= SFFTL_F_VERIFY_GC_COPY | SFFTL_F_PARANOID;
  c.wl_static_threshold = 8;
  c.wl_static_interval = 16;
  return c;
}
/* the StorageCore P51 device: 64 blocks x 16 pages x 512 B (+16 B spare) */
static sfftl_geom_t p51_geom(void) { sfftl_geom_t g; hx_geom(&g, 512, 16, 64); return g; }

static void end_checks(hx_t *h, const char *where) {
  if (h->mounted) CHECK_OK(sfftl_check(&h->ftl), where);
  CHECK(hx_violations(h) == 0, "%s: %d NAND rule violation(s) (order %" PRIu64 " reprog %" PRIu64 " 0->1 %" PRIu64
        " factory %" PRIu64 " wp %" PRIu64 ")", where, hx_violations(h), simnand_stats(h->nand)->v_order,
        simnand_stats(h->nand)->v_reprogram, simnand_stats(h->nand)->v_zero_to_one,
        simnand_stats(h->nand)->v_factory_bad, simnand_stats(h->nand)->v_wp);
}

/* random workload; returns 0 or the first unexpected rc */
static int workload(hx_t *h, uint32_t ops, uint32_t max_len, uint32_t trim_pct, uint32_t hot, uint32_t check_every) {
  for (uint32_t i = 0; i < ops; i++) {
    int rc = hx_random_op(h, max_len, trim_pct, hot);
    if (rc == 1000) { CHECK(0, "op %u: %s", i, h->why); return rc; }
    if (rc < 0) { CHECK(0, "op %u: %s (%s)", i, sfftl_strerror(rc), h->why); return rc; }
    if (check_every && (i % check_every) == 0) {
      int c = sfftl_check(&h->ftl);
      if (c) { CHECK(0, "op %u: sfftl_check %s", i, sfftl_strerror(c)); return c; }
    }
  }
  return 0;
}

/* =============================================================== tests */

static void t_geometry_and_range(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  CHECK(sfftl_mem_required(&g, &c) > 0, "mem_required");
  sfftl_geom_t bad = g; bad.page_data_bytes = 500;
  CHECK(sfftl_mem_required(&bad, &c) == 0, "page size 500 rejected");
  bad = g; bad.page_spare_bytes = 8;
  CHECK(sfftl_mem_required(&bad, &c) == 0, "spare 8 rejected");
  bad = g; bad.pages_per_block = 12;
  CHECK(sfftl_mem_required(&bad, &c) == 0, "ppb 12 rejected");
  sfftl_cfg_t cb = c; cb.lba_bytes = 1024; cb.nlba = 0;
  CHECK(sfftl_mem_required(&g, &cb) == 0, "LBA larger than the page rejected");
  cb = c; cb.nlba = 100000;
  CHECK(sfftl_mem_required(&g, &cb) == 0, "namespace larger than the device rejected");
  cb = c; cb.gc_reserve_blocks = 1;
  CHECK(sfftl_mem_required(&g, &cb) == 0, "GC reserve < 2 rejected");
  int rc = hx_init(&h, &g, &c, NULL, 1);
  CHECK_OK(rc, "format");
  if (rc) return;
  uint64_t n = hx_nlba(&h);
  CHECK(n > 600 && n < 1024, "capacity %" PRIu64 " LBAs for 1024 physical pages", n);
  CHECK(sfftl_read(&h.ftl, n, 1, h.io) == SFFTL_ERANGE, "read past the end");
  CHECK(sfftl_read(&h.ftl, n - 1, 2, h.io) == SFFTL_ERANGE, "read straddling the end");
  CHECK(sfftl_write(&h.ftl, n, 1, h.io) == SFFTL_ERANGE, "write past the end");
  CHECK(sfftl_write(&h.ftl, UINT64_MAX - 1, 4, h.io) == SFFTL_ERANGE, "write with wrapping range");
  CHECK(sfftl_trim(&h.ftl, n - 1, 5) == SFFTL_ERANGE, "trim past the end");
  CHECK(sfftl_write(&h.ftl, 0, 0, h.io) == SFFTL_OK, "zero-length write");
  memset(h.io, 0xA5, 512);
  CHECK_OK(sfftl_read(&h.ftl, 7, 1, h.io), "unmapped read");
  int zero = 1;
  for (int i = 0; i < 512; i++) zero &= h.io[i] == 0;
  CHECK(zero, "unmapped LBA reads as zeros");
  CHECK(hx_verify_all(&h) == 0, "fresh device reads all zeros: %s", h.why);
  sfftl_space_t sp;
  sfftl_space(&h.ftl, &sp);
  CHECK(sp.blocks_meta == h.ftl.meta_blocks && sp.blocks_free + sp.blocks_meta + sp.blocks_bad_factory + sp.blocks_bad_grown == 64,
        "space accounting after format");
  end_checks(&h, "geometry");
  hx_free(&h);
}

/* CRC-32 (slice-by-4 on little-endian hosts and the ControlCore) must be the
 * IEEE CRC-32 the persistence schema specifies, at every alignment */
uint32_t sfftl_crc32_update(uint32_t crc, const void *data, uint32_t len);
static void t_crc32(void) {
  CHECK((sfftl_crc32_update(0xFFFFFFFFu, "123456789", 9) ^ 0xFFFFFFFFu) == 0xCBF43926u, "CRC-32 check value");
  static uint8_t buf[1100];
  uint32_t x = 2463534242u;
  for (int i = 0; i < 1100; i++) { x ^= x << 13; x ^= x >> 17; x ^= x << 5; buf[i] = (uint8_t)x; }
  int bad = 0;
  for (uint32_t off = 0; off < 8; off++)
    for (uint32_t len = 0; len < 1060; len += 3) {
      uint32_t ref = 0xFFFFFFFFu;                       /* bit-serial reference, no tables */
      for (uint32_t i = 0; i < len; i++) {
        ref ^= buf[off + i];
        for (int k = 0; k < 8; k++) ref = (ref & 1u) ? (ref >> 1) ^ 0xEDB88320u : ref >> 1;
      }
      uint32_t half = len / 2;
      uint32_t got = sfftl_crc32_update(sfftl_crc32_update(0xFFFFFFFFu, buf + off, half), buf + off + half, len - half);
      bad += got != ref;
    }
  CHECK(bad == 0, "CRC-32 equals the bit-serial reference at every alignment / split (%d mismatches)", bad);
}

static void t_sequential(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  if (hx_init(&h, &g, &c, NULL, 2)) { CHECK(0, "init"); return; }
  uint64_t n = hx_nlba(&h);
  for (int pass = 0; pass < 3; pass++)
    for (uint64_t l = 0; l < n; l += 8) {
      uint32_t k = (uint32_t)(n - l < 8 ? n - l : 8);
      int rc = hx_write(&h, l, k);
      if (rc) { CHECK_OK(rc, "sequential write"); break; }
    }
  CHECK(hx_verify_all(&h) == 0, "sequential verify: %s", h.why);
  /* sequential rewrites invalidate whole blocks: they are freed without copying */
  CHECK(sfftl_stats(&h.ftl)->gc_pages_moved == 0, "sequential rewrite needs no relocation (%" PRIu64 " moved)",
        sfftl_stats(&h.ftl)->gc_pages_moved);
  end_checks(&h, "sequential");
  hx_free(&h);
}

static void t_random_overwrite(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  if (hx_init(&h, &g, &c, NULL, 3)) { CHECK(0, "init"); return; }
  uint64_t n = hx_nlba(&h);
  /* read-after-write of every single overwrite */
  for (uint32_t i = 0; i < SCALE(6000u); i++) {
    uint64_t l = hx_rand(&h) % n;
    uint32_t k = 1u + (uint32_t)(hx_rand(&h) % 4u);
    if (l + k > n) k = (uint32_t)(n - l);
    int rc = hx_write(&h, l, k);
    if (rc) { CHECK_OK(rc, "overwrite"); break; }
    if (hx_verify(&h, l, k)) { CHECK(0, "read after overwrite %u: %s", i, h.why); break; }
  }
  CHECK(hx_verify_all(&h) == 0, "verify all: %s", h.why);
  end_checks(&h, "random overwrite");
  hx_free(&h);
}

static void t_subpage_rmw(void) {
  /* 2 KiB pages, 512-B LBAs: 4 LBAs per logical page, writes are read-modify-write */
  sfftl_geom_t g; hx_geom(&g, 2048, 32, 96);
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  if (hx_init(&h, &g, &c, NULL, 4)) { CHECK(0, "init"); return; }
  workload(&h, SCALE(8000u), 11, 10, 30, 97);
  CHECK(hx_verify_all(&h) == 0, "verify: %s", h.why);
  CHECK(sfftl_stats(&h.ftl)->rmw_reads > 0, "RMW exercised");
  end_checks(&h, "sub-page RMW");
  hx_free(&h);
}

static void t_trim(void) {
  sfftl_geom_t g; hx_geom(&g, 2048, 16, 64);
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  if (hx_init(&h, &g, &c, NULL, 5)) { CHECK(0, "init"); return; }
  uint64_t n = hx_nlba(&h);
  for (uint64_t l = 0; l < n; l += 16) hx_write(&h, l, (uint32_t)(n - l < 16 ? n - l : 16));
  /* aligned, unaligned head/tail, single sector, whole device */
  CHECK_OK(hx_trim(&h, 8, 64), "aligned trim");
  CHECK_OK(hx_trim(&h, 101, 3), "sub-page trim");
  CHECK_OK(hx_trim(&h, 203, 50), "unaligned trim");
  CHECK(hx_verify_all(&h) == 0, "after trims: %s", h.why);
  CHECK_OK(hx_write(&h, 9, 2), "rewrite inside trimmed range");
  CHECK(hx_verify_all(&h) == 0, "after rewrite: %s", h.why);
  CHECK_OK(hx_crash_mount(&h), "crash mount");
  CHECK(hx_verify_all(&h) == 0, "trim durable across crash: %s", h.why);
  workload(&h, SCALE(5000u), 24, 25, 0, 101);
  CHECK_OK(hx_trim(&h, 0, (uint32_t)n), "trim everything");
  CHECK(hx_verify_all(&h) == 0, "all zero: %s", h.why);
  sfftl_space_t sp; sfftl_space(&h.ftl, &sp);
  CHECK(sp.pages_valid == 0, "no valid pages after full trim (%" PRIu64 ")", sp.pages_valid);
  CHECK_OK(hx_crash_mount(&h), "crash mount 2");
  CHECK(hx_verify_all(&h) == 0, "full trim durable: %s", h.why);
  end_checks(&h, "trim");
  hx_free(&h);
}

static void t_full_device(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  if (hx_init(&h, &g, &c, NULL, 6)) { CHECK(0, "init"); return; }
  uint64_t n = hx_nlba(&h);
  for (uint64_t l = 0; l < n; l++) if (hx_write(&h, l, 1)) { CHECK(0, "fill %" PRIu64, l); break; }
  sfftl_space_t sp; sfftl_space(&h.ftl, &sp);
  CHECK(sp.pages_valid == n, "100%% of the namespace mapped (%" PRIu64 "/%" PRIu64 ")", sp.pages_valid, n);
  uint32_t enospc = 0;
  for (uint64_t i = 0; i < SCALE(8u) * n; i++) {
    int rc = hx_write(&h, hx_rand(&h) % n, 1);
    if (rc == SFFTL_ENOSPC) enospc++;
    else if (rc) { CHECK_OK(rc, "full-device overwrite"); break; }
    if ((i % 997u) == 0 && sfftl_check(&h.ftl)) { CHECK(0, "check at %" PRIu64, i); break; }
  }
  CHECK(enospc == 0, "no ENOSPC at 100%% logical fill (%u)", enospc);
  CHECK(hx_verify_all(&h) == 0, "verify: %s", h.why);
  const sfftl_stats_t *s = sfftl_stats(&h.ftl);
  double wa = (double)(s->nand_prog_host + s->nand_prog_reloc + s->nand_prog_meta) / (double)s->host_lba_written;
  printf("    full device: %" PRIu64 " LBAs, WA %.2f, GC victims %" PRIu64 ", ckpts %" PRIu64 "\n", n, wa, s->gc_victims, s->ckpt_count);
  CHECK(wa < 12.0, "write amplification bounded (%.2f)", wa);
  CHECK_OK(hx_crash_mount(&h), "remount full device");
  CHECK(hx_verify_all(&h) == 0, "verify after remount: %s", h.why);
  end_checks(&h, "full device");
  hx_free(&h);
}

static void t_gc_policies(void) {
  sfftl_gc_policy_t pol[2] = { SFFTL_GC_GREEDY, SFFTL_GC_COST_BENEFIT };
  for (int i = 0; i < 2; i++) {
    sfftl_geom_t g; hx_geom(&g, 512, 32, 128);
    sfftl_cfg_t c = base_cfg();
    c.gc_policy = pol[i];
    hx_t h;
    if (hx_init(&h, &g, &c, NULL, 7 + (uint64_t)i)) { CHECK(0, "init"); return; }
    workload(&h, SCALE(20000u), 8, 5, 70, 499);
    CHECK(hx_verify_all(&h) == 0, "policy %d: %s", i, h.why);
    CHECK(sfftl_stats(&h.ftl)->gc_victims > 10, "policy %d collected", i);
    end_checks(&h, "gc policy");
    hx_free(&h);
  }
}

static void t_factory_bad(void) {
  sfftl_geom_t g; hx_geom(&g, 512, 16, 128);
  sfftl_cfg_t c = base_cfg();
  simnand_cfg_t nc; simnand_cfg_default(&nc, 512, 16, 128);
  nc.factory_bad_permille = 60;
  hx_t h;
  memset(&h, 0, sizeof(h));
  int rc = hx_init(&h, &g, &c, &nc, 8);
  CHECK_OK(rc, "format with factory bad blocks");
  if (rc) { hx_free(&h); return; }
  uint32_t fb = 0;
  for (uint32_t b = 0; b < 128; b++) fb += (uint32_t)simnand_is_factory_bad(h.nand, b);
  sfftl_space_t sp; sfftl_space(&h.ftl, &sp);
  CHECK(fb > 0 && sp.blocks_bad_factory == fb, "factory bad blocks found %u / %u", sp.blocks_bad_factory, fb);
  workload(&h, SCALE(15000u), 8, 5, 50, 0);
  CHECK(hx_verify_all(&h) == 0, "verify: %s", h.why);
  CHECK_OK(hx_crash_mount(&h), "remount");
  CHECK(hx_verify_all(&h) == 0, "verify after remount: %s", h.why);
  /* markers intact after heavy use: the FTL never touched those blocks */
  uint32_t intact = 0;
  for (uint32_t b = 0; b < 128; b++) {
    if (!simnand_is_factory_bad(h.nand, b)) continue;
    uint8_t m0 = 0xFF, m1 = 0xFF;
    simnand_read_marker(h.nand, b * 16u, &m0);
    simnand_read_marker(h.nand, b * 16u + 15u, &m1);
    intact += (m0 == 0 && m1 == 0);
  }
  CHECK(intact == fb, "manufacturer markers preserved (%u / %u)", intact, fb);
  CHECK(simnand_stats(h.nand)->v_factory_bad == 0, "factory-bad blocks never programmed or erased");
  end_checks(&h, "factory bad");
  hx_free(&h);
}

static void t_program_failures(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  if (hx_init(&h, &g, &c, NULL, 9)) { CHECK(0, "init"); return; }
  for (uint32_t round = 0; round < 6; round++) {
    simnand_fail_next_program(h.nand, 8u + (uint32_t)(hx_rand(&h) % 56u));
    if (workload(&h, SCALE(1500u), 6, 5, 40, 211)) break;
  }
  const sfftl_stats_t *s = sfftl_stats(&h.ftl);
  CHECK(s->prog_fail > 0 && s->blocks_retired > 0, "program failures handled (%" PRIu64 " fails, %" PRIu64 " retired)",
        s->prog_fail, s->blocks_retired);
  CHECK(hx_verify_all(&h) == 0, "verify: %s", h.why);
  CHECK_OK(hx_crash_mount(&h), "remount");
  CHECK(hx_verify_all(&h) == 0, "verify after remount: %s", h.why);
  sfftl_space_t sp; sfftl_space(&h.ftl, &sp);
  CHECK(sp.blocks_bad_grown > 0, "grown bad blocks persisted (%u)", sp.blocks_bad_grown);
  end_checks(&h, "program failures");
  hx_free(&h);
}

static void t_erase_failures(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  if (hx_init(&h, &g, &c, NULL, 10)) { CHECK(0, "init"); return; }
  for (uint32_t round = 0; round < 4; round++) {
    simnand_fail_erase(h.nand, 8u + (uint32_t)(hx_rand(&h) % 56u));
    if (workload(&h, SCALE(2000u), 6, 5, 40, 211)) break;
  }
  CHECK(sfftl_stats(&h.ftl)->erase_fail > 0, "erase failures seen");
  CHECK(hx_verify_all(&h) == 0, "verify: %s", h.why);
  CHECK_OK(hx_crash_mount(&h), "remount");
  CHECK(hx_verify_all(&h) == 0, "verify after remount: %s", h.why);
  end_checks(&h, "erase failures");
  hx_free(&h);
}

static void t_read_failures(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  if (hx_init(&h, &g, &c, NULL, 11)) { CHECK(0, "init"); return; }
  uint64_t n = hx_nlba(&h);
  for (uint64_t l = 0; l < n / 2; l++) hx_write(&h, l, 1);
  /* transient: one uncorrectable read, the retry succeeds */
  uint32_t p = h.ftl.l2p[10];
  simnand_fail_read(h.nand, p, 1);
  CHECK(hx_verify(&h, 10, 1) == 0, "transient read error recovered by retry: %s", h.why);
  CHECK(sfftl_stats(&h.ftl)->read_retry_ok == 1, "retry counted");
  /* correctable bit errors */
  simnand_flip_bits(h.nand, h.ftl.l2p[11], 3);
  CHECK(hx_verify(&h, 11, 1) == 0, "corrected read: %s", h.why);
  /* ECC miscorrection: garbage flagged corrected -> CRC catches it, the re-read is good */
  simnand_miscorrect(h.nand, h.ftl.l2p[12]);
  uint64_t crc0 = sfftl_stats(&h.ftl)->crc_errors;
  CHECK(hx_verify(&h, 12, 1) == 0, "miscorrection never returned as data: %s", h.why);
  CHECK(sfftl_stats(&h.ftl)->crc_errors == crc0 + 1u, "CRC mismatch detected and re-read");
  /* misdirected read: the controller returns another page (valid CRC) -> LPN check */
  uint64_t lm0 = sfftl_stats(&h.ftl)->lpn_mismatch;
  simnand_misdirect(h.nand, h.ftl.l2p[13], h.ftl.l2p[14]);
  CHECK(hx_verify(&h, 13, 1) == 0, "misdirected read never returned as data: %s", h.why);
  CHECK(sfftl_stats(&h.ftl)->lpn_mismatch == lm0 + 1u, "LPN mismatch detected and re-read");
  /* permanent: the LBA reports EIO, its neighbours are unaffected */
  uint32_t bad_ppn = h.ftl.l2p[20];
  uint32_t bad_blk = bad_ppn / 16u;
  simnand_fail_read(h.nand, bad_ppn, ~0u);
  CHECK(sfftl_read(&h.ftl, 20, 1, h.io) == SFFTL_EIO, "permanent read error -> EIO");
  CHECK(h.ftl.blk[bad_blk].flags & SFFTL_BF_RETIRE, "block queued for retirement");
  /* GC relocates what it can and retires the block, LBA 20 stays EIO */
  for (int i = 0; i < 8 && sfftl_background(&h.ftl, 1000) >= 0 && h.ftl.blk[bad_blk].state != SFFTL_BS_BAD; i++) {}
  CHECK(h.ftl.blk[bad_blk].state == SFFTL_BS_BAD, "failing block retired");
  CHECK(sfftl_read(&h.ftl, 20, 1, h.io) == SFFTL_EIO, "stranded LBA still EIO (never stale data)");
  for (uint64_t l = 0; l < n; l++) {
    if (l == 20) continue;
    if (hx_verify(&h, l, 1)) { CHECK(0, "neighbour %" PRIu64 ": %s", l, h.why); break; }
  }
  CHECK_OK(hx_write(&h, 20, 1), "rewrite the lost LBA");
  CHECK(hx_verify_all(&h) == 0, "all readable after rewrite: %s", h.why);
  CHECK_OK(hx_crash_mount(&h), "remount");
  CHECK(h.ftl.blk[bad_blk].state == SFFTL_BS_BAD, "retirement persisted");
  CHECK(hx_verify_all(&h) == 0, "verify after remount: %s", h.why);
  end_checks(&h, "read failures");
  hx_free(&h);
}

static void t_random_faults(void) {
  sfftl_geom_t g; hx_geom(&g, 512, 16, 128);
  sfftl_cfg_t c = base_cfg();
  c.refresh_bitflips = 7;
  simnand_cfg_t nc; simnand_cfg_default(&nc, 512, 16, 128);
  nc.factory_bad_permille = 30;
  hx_t h;
  if (hx_init(&h, &g, &c, &nc, 12)) { CHECK(0, "init"); return; }
  simnand_set_random(h.nand, 30, 300, 0, 5000);            /* program 0.003 %, erase 0.03 %, bit flips 0.5 % of reads */
  workload(&h, SCALE(30000u), 8, 5, 50, 997);
  CHECK(hx_verify_all(&h) == 0, "verify: %s", h.why);
  const sfftl_stats_t *s = sfftl_stats(&h.ftl);
  printf("    random faults: prog_fail %" PRIu64 " erase_fail %" PRIu64 " retired %" PRIu64 " corrected %" PRIu64 " refresh %" PRIu64 "\n",
         simnand_stats(h.nand)->prog_fail, simnand_stats(h.nand)->erase_fail, s->blocks_retired, s->read_corrected, s->refresh_moves);
  CHECK_OK(hx_crash_mount(&h), "remount");
  CHECK(hx_verify_all(&h) == 0, "verify after remount: %s", h.why);
  end_checks(&h, "random faults");
  hx_free(&h);
}

static uint32_t ec_spread(hx_t *h) {
  uint32_t mn = 0xFFFFFFFFu, mx = 0;
  for (uint32_t b = 0; b < h->g.blocks; b++) {
    if (h->ftl.blk[b].state == SFFTL_BS_BAD || h->ftl.blk[b].state == SFFTL_BS_META) continue;
    uint32_t e = simnand_erase_count(h->nand, b);
    if (e < mn) mn = e;
    if (e > mx) mx = e;
  }
  return mx - mn;
}

static void t_wear_levelling(void) {
  sfftl_wl_policy_t pol[3] = { SFFTL_WL_NONE, SFFTL_WL_DYNAMIC, SFFTL_WL_DYNAMIC_STATIC };
  uint32_t spread[3] = { 0, 0, 0 };
  for (int i = 0; i < 3; i++) {
    sfftl_geom_t g; hx_geom(&g, 512, 16, 128);
    sfftl_cfg_t c = base_cfg();
    c.wl_policy = pol[i];
    hx_t h;
    if (hx_init(&h, &g, &c, NULL, 13)) { CHECK(0, "init"); return; }
    uint64_t n = hx_nlba(&h);
    for (uint64_t l = 0; l < n; l++) hx_write(&h, l, 1);           /* cold data everywhere */
    for (uint32_t k = 0; k < SCALE(60000u); k++) {                    /* then 10 % of the LBAs take all writes */
      int rc = hx_write(&h, hx_rand(&h) % (n / 10u), 1);
      if (rc) { CHECK_OK(rc, "hot write"); break; }
    }
    CHECK(hx_verify_all(&h) == 0, "verify: %s", h.why);
    spread[i] = ec_spread(&h);
    printf("    wear policy %d: erase-count spread (device ground truth) %u\n", i, spread[i]);
    end_checks(&h, "wear");
    hx_free(&h);
  }
  CHECK(spread[2] < spread[0], "static WL narrows the spread vs. none (%u vs %u)", spread[2], spread[0]);
  CHECK(spread[2] < spread[1], "static WL narrows the spread vs. dynamic only (%u vs %u)", spread[2], spread[1]);
}

static void t_restart_clean(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  if (hx_init(&h, &g, &c, NULL, 14)) { CHECK(0, "init"); return; }
  for (int r = 0; r < 20; r++) {
    if (workload(&h, SCALE(400u), 6, 8, 30, 0)) break;
    uint64_t mounts = sfftl_stats(&h.ftl)->mount_clean;
    int rc = hx_clean_remount(&h);
    CHECK_OK(rc, "clean remount");
    if (rc) break;
    CHECK(sfftl_stats(&h.ftl)->mount_clean == 1 && mounts == (r ? 1u : 0u), "fast (clean) mount path taken");
    CHECK(sfftl_stats(&h.ftl)->last_mount_pages_scanned == 0, "clean mount scans no data pages");
    if (hx_verify_all(&h)) { CHECK(0, "verify after clean remount %d: %s", r, h.why); break; }
  }
  end_checks(&h, "clean restart");
  hx_free(&h);
}

static void t_restart_unclean(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  if (hx_init(&h, &g, &c, NULL, 15)) { CHECK(0, "init"); return; }
  for (int r = 0; r < 60; r++) {
    if (workload(&h, 1u + (uint32_t)(hx_rand(&h) % SCALE(600u)), 6, 8, 30, 0)) break;
    int rc = hx_crash_mount(&h);                                     /* RAM lost, no shutdown */
    CHECK_OK(rc, "unclean mount");
    if (rc) break;
    if (hx_verify_all(&h)) { CHECK(0, "verify after crash %d: %s", r, h.why); break; }
    if (sfftl_check(&h.ftl)) { CHECK(0, "check after crash %d", r); break; }
  }
  CHECK(sfftl_stats(&h.ftl)->mount_unclean == 1, "unclean path taken");
  end_checks(&h, "unclean restart");
  hx_free(&h);
}

/* one power-cut experiment: workload, cut at device op `cut`, mount, verify,
 * mount again (stability), continue, verify */
static int powercut_case(const sfftl_geom_t *g, const sfftl_cfg_t *c, uint64_t seed, uint64_t warm, uint64_t cut,
                         uint32_t ops, int cut_in_mount) {
  hx_t h;
  int fail = 0;
  if (hx_init(&h, g, c, NULL, seed)) { CHECK(0, "init"); return 1; }
  for (uint64_t i = 0; i < warm; i++) hx_random_op(&h, 6, 10, 40);
  simnand_arm_powercut(h.nand, cut);
  for (uint32_t i = 0; i < ops; i++) {
    int rc = hx_random_op(&h, 6, 10, 40);
    if (rc == SFFTL_EPOWER) break;
    if (rc == 1000 || rc < 0) { CHECK(0, "seed %" PRIu64 " cut %" PRIu64 ": op error %d %s", seed, cut, rc, h.why); fail = 1; break; }
  }
  if (!fail && cut_in_mount) {
    /* power fails again while mounting */
    simnand_power_on(h.nand);
    simnand_arm_powercut(h.nand, (uint64_t)cut_in_mount);
    int rc = sfftl_mount(&h.ftl, &h.g, &h.cfg, &h.hal, h.arena, h.arena_bytes);
    CHECK(rc == SFFTL_EPOWER || rc == SFFTL_OK, "mount with power cut: %s", sfftl_strerror(rc));
  }
  for (int m = 0; m < 2 && !fail; m++) {
    int rc = hx_crash_mount(&h);
    if (rc) { CHECK(0, "seed %" PRIu64 " cut %" PRIu64 " mount %d: %s", seed, cut, m, sfftl_strerror(rc)); fail = 1; break; }
    if (sfftl_check(&h.ftl)) { CHECK(0, "seed %" PRIu64 " cut %" PRIu64 ": invariants", seed, cut); fail = 1; break; }
    if (hx_verify_all(&h)) { CHECK(0, "seed %" PRIu64 " cut %" PRIu64 " mount %d: %s", seed, cut, m, h.why); fail = 1; break; }
  }
  if (!fail) {
    if (workload(&h, 300, 6, 10, 40, 0)) fail = 1;
    else if (hx_verify_all(&h)) { CHECK(0, "after resume: %s", h.why); fail = 1; }
  }
  CHECK(hx_violations(&h) == 0, "seed %" PRIu64 " cut %" PRIu64 ": NAND violations %d", seed, cut, hx_violations(&h));
  g_checks++;
  hx_free(&h);
  return fail;
}

static void t_powercut_sweep(void) {
  /* every device operation index in a window is a cut point */
  sfftl_geom_t g; hx_geom(&g, 512, 16, 48);
  sfftl_cfg_t c = base_cfg();
  uint32_t n = SCALE(1200u), fails = 0;
  for (uint64_t cut = 0; cut < n && fails < 3; cut++) fails += (uint32_t)powercut_case(&g, &c, 100 + cut % 7u, 150, cut, 2000, 0);
  printf("    %u consecutive cut points tested\n", n);
}

static void t_powercut_random(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  c.ckpt_interval_blocks = 4;             /* more checkpoints -> more cuts land inside one */
  uint32_t fails = 0, n = SCALE(400u);
  for (uint32_t i = 0; i < n && fails < 3; i++) {
    uint64_t seed = 1000u + i;
    uint64_t warm = 500u + (seed * 37u) % 2500u;
    uint64_t cut = (seed * 7919u) % 6000u;
    fails += (uint32_t)powercut_case(&g, &c, seed, warm, cut, 4000, (i % 3u == 0) ? (int)(1u + (seed % 400u)) : 0);
  }
  printf("    %u random power cuts (1/3 with a second cut during mount)\n", n);
}

static void t_powercut_with_faults(void) {
  /* deliberately exaggerated failure rates (NANDLab "stress"-like): the device
   * may wear out into read-only / no-space; acknowledged data must survive anyway */
  sfftl_geom_t g; hx_geom(&g, 2048, 16, 64);
  sfftl_cfg_t c = base_cfg();
  c.ckpt_interval_blocks = 4;
  uint32_t fails = 0, n = SCALE(150u), degraded = 0;
  for (uint32_t i = 0; i < n && fails < 3; i++) {
    hx_t h;
    uint64_t seed = 5000u + i;
    int dead = 0;
    if (hx_init(&h, &g, &c, NULL, seed)) { CHECK(0, "init"); return; }
    simnand_set_random(h.nand, 2000, 5000, 0, 5000);
    for (int round = 0; round < 4 && !fails && !dead; round++) {
      simnand_arm_powercut(h.nand, hx_rand(&h) % 3000u);
      for (int k = 0; k < 3000; k++) {
        int rc = hx_random_op(&h, 12, 10, 40);
        if (rc == SFFTL_EPOWER) break;
        if (rc == SFFTL_ENOSPC) continue;
        if (rc == SFFTL_EROFS) { dead = 1; break; }
        if (rc) { CHECK(0, "seed %" PRIu64 ": %d %s", seed, rc, h.why); fails++; break; }
      }
      int rc = hx_crash_mount(&h);
      if (rc) { CHECK(0, "seed %" PRIu64 " mount: %s", seed, sfftl_strerror(rc)); fails++; break; }
      if (hx_verify_all(&h)) { CHECK(0, "seed %" PRIu64 " round %d: %s", seed, round, h.why); fails++; break; }
      sfftl_space_t sp; sfftl_space(&h.ftl, &sp);
      if (sp.read_only) {
        dead = 1;
        CHECK(hx_write(&h, 0, 1) == SFFTL_EROFS, "read-only mount refuses writes");
      }
    }
    degraded += (uint32_t)dead;
    end_checks(&h, "power cut + faults");
    hx_free(&h);
  }
  printf("    %u seeds x 4 power cuts under stress fault rates; %u ended read-only (worn out), data intact\n", n, degraded);
}

/* power fails at EVERY device operation of a recovery mount in turn */
static void t_powercut_mount_sweep(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  uint32_t fails = 0, maxk = 0, k;
  for (k = 0; fails < 3; k++) {
    hx_t h;
    if (hx_init(&h, &g, &c, NULL, 4242)) { CHECK(0, "init"); return; }
    workload(&h, 900, 6, 10, 40, 0);
    simnand_power_off(h.nand);                         /* crash with a long roll-forward window */
    simnand_power_on(h.nand);
    uint64_t ops0 = simnand_ops(h.nand);
    simnand_arm_powercut(h.nand, k);
    int rc = sfftl_mount(&h.ftl, &h.g, &h.cfg, &h.hal, h.arena, h.arena_bytes);
    int finished = (rc == SFFTL_OK);
    if (!finished && rc != SFFTL_EPOWER) { CHECK(0, "cut %u: mount %s", k, sfftl_strerror(rc)); fails++; }
    if (finished) maxk = (uint32_t)(simnand_ops(h.nand) - ops0);
    for (int m = 0; m < 2 && !fails; m++) {
      rc = hx_crash_mount(&h);
      if (rc) { CHECK(0, "cut %u remount %d: %s", k, m, sfftl_strerror(rc)); fails++; break; }
      if (hx_verify_all(&h)) { CHECK(0, "cut %u remount %d: %s", k, m, h.why); fails++; break; }
    }
    end_checks(&h, "mount sweep");
    hx_free(&h);
    if (finished) break;                               /* the cut point is past the end of mount */
  }
  printf("    recovery mount = %u device operations; power cut at each of them, then two remounts\n", maxk);
  CHECK(maxk > 50, "mount did real recovery work (%u ops)", maxk);
}

/* blocks fail until over-provisioning is gone: writes stop, data stays readable */
static void t_degraded(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  if (hx_init(&h, &g, &c, NULL, 23)) { CHECK(0, "init"); return; }
  uint64_t n = hx_nlba(&h);
  for (uint64_t l = 0; l < n; l++) hx_write(&h, l, 1);
  int rc = 0;
  uint32_t i;
  for (i = 0; i < 200000u && rc == 0; i++) {
    if ((i % 50u) == 0) simnand_fail_erase(h.nand, (uint32_t)(hx_rand(&h) % 64u));
    rc = hx_write(&h, hx_rand(&h) % n, 1);
  }
  CHECK(rc == SFFTL_ENOSPC || rc == SFFTL_EROFS, "device eventually refuses writes (%s)", sfftl_strerror(rc));
  sfftl_space_t sp; sfftl_space(&h.ftl, &sp);
  printf("    stopped after %u writes: %u grown bad blocks, %s\n", i, sp.blocks_bad_grown, sfftl_strerror(rc));
  CHECK(hx_verify_all(&h) == 0, "every acknowledged LBA still readable: %s", h.why);
  CHECK(sfftl_check(&h.ftl) == SFFTL_OK, "invariants hold when full");
  rc = hx_crash_mount(&h);
  CHECK_OK(rc, "mount a worn-out device");
  CHECK(hx_verify_all(&h) == 0, "readable after remount: %s", h.why);
  end_checks(&h, "degraded");
  hx_free(&h);
}

/* metadata blocks fail until the ring cannot advance: the live checkpoint
 * must never be erased to make room -- the FTL goes read-only instead */
static void t_meta_zone_exhaustion(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  if (hx_init(&h, &g, &c, NULL, 31)) { CHECK(0, "init"); return; }
  workload(&h, 600, 6, 5, 30, 0);
  CHECK_OK(sfftl_checkpoint(&h.ftl), "checkpoint");
  uint32_t live = h.ftl.zone[h.ftl.mz_live_start];
  for (uint32_t z = 0; z < h.ftl.meta_blocks; z++)
    if (h.ftl.zone[z] != live && z != h.ftl.mz_head) simnand_fail_erase(h.nand, h.ftl.zone[z]);
  int rc = 0;
  uint64_t n = hx_nlba(&h);
  for (uint32_t i = 0; i < 20000u && rc == 0; i++) {
    rc = (i & 1u) ? hx_trim(&h, hx_rand(&h) % n, 1) : hx_write(&h, hx_rand(&h) % n, 1);
    if (rc == SFFTL_ENOSPC) rc = 0;
  }
  CHECK(rc == SFFTL_EROFS, "metadata zone exhausted -> read-only (%s)", sfftl_strerror(rc));
  CHECK(hx_verify_all(&h) == 0, "data readable when read-only: %s", h.why);
  rc = hx_crash_mount(&h);
  CHECK_OK(rc, "mount after exhaustion (live checkpoint intact)");
  sfftl_space_t sp; sfftl_space(&h.ftl, &sp);
  CHECK(sp.read_only, "mounted read-only");
  CHECK(hx_verify_all(&h) == 0, "every acknowledged write after remount: %s", h.why);
  end_checks(&h, "meta zone exhaustion");
  hx_free(&h);
}

static void t_metadata_fallback(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  if (hx_init(&h, &g, &c, NULL, 16)) { CHECK(0, "init"); return; }
  workload(&h, 1500, 6, 5, 30, 0);
  CHECK_OK(sfftl_checkpoint(&h.ftl), "checkpoint A");
  workload(&h, 40, 6, 5, 30, 0);
  CHECK_OK(sfftl_checkpoint(&h.ftl), "checkpoint B");
  uint32_t commit_b = h.ftl.meta_last_ppn;
  workload(&h, 200, 6, 5, 30, 0);
  simnand_corrupt_page(h.nand, commit_b);                    /* newest commit unreadable */
  int rc = hx_crash_mount(&h);
  CHECK_OK(rc, "mount falls back to the previous checkpoint");
  CHECK(sfftl_stats(&h.ftl)->last_mount_ckpt_gen + 1u == h.ftl.gen || rc, "older generation used");
  CHECK(hx_verify_all(&h) == 0, "data after fallback: %s", h.why);
  end_checks(&h, "metadata fallback");
  hx_free(&h);
}

static void t_rebuild(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  if (hx_init(&h, &g, &c, NULL, 17)) { CHECK(0, "init"); return; }
  workload(&h, 2500, 6, 0, 30, 0);                           /* no TRIM: rebuild cannot know old TRIMs */
  for (uint32_t z = 0; z < h.ftl.meta_blocks; z++)
    for (uint32_t p = 0; p < 16; p++) simnand_corrupt_page(h.nand, h.ftl.zone[z] * 16u + p);
  int rc = hx_crash_mount(&h);
  CHECK(rc == SFFTL_ENOFS, "no metadata -> ENOFS without rebuild (%s)", sfftl_strerror(rc));
  h.cfg.flags |= SFFTL_F_ALLOW_REBUILD;
  rc = hx_crash_mount(&h);
  CHECK_OK(rc, "rebuild from spare records");
  CHECK(sfftl_stats(&h.ftl)->mount_rebuild == 1, "rebuild path taken");
  CHECK(hx_verify_all(&h) == 0, "data after rebuild: %s", h.why);
  workload(&h, 1000, 6, 5, 30, 0);
  CHECK_OK(hx_crash_mount(&h), "normal mount after rebuild");
  CHECK(hx_verify_all(&h) == 0, "data after second mount: %s", h.why);
  end_checks(&h, "rebuild");
  hx_free(&h);
}

static void t_powersafe(void) {
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = base_cfg();
  hx_t h;
  if (hx_init(&h, &g, &c, NULL, 18)) { CHECK(0, "init"); return; }
  workload(&h, 800, 6, 5, 30, 0);
  sfftl_ps_warn(&h.ftl);
  CHECK(hx_write(&h, 3, 1) == SFFTL_EPOWER, "write refused after the warning");
  CHECK(hx_trim(&h, 5, 1) == SFFTL_EPOWER, "trim refused after the warning");
  CHECK(hx_verify(&h, 0, 16) == 0, "reads still served: %s", h.why);
  uint64_t p0 = simnand_stats(h.nand)->programs;
  int n = sfftl_ps_power_fail(&h.ftl, SFFTL_PS_FLUSH_JOURNAL);
  CHECK(n >= 0 && n <= 1, "at most one page programmed by power_fail (%d)", n);
  CHECK(simnand_stats(h.nand)->programs - p0 <= 1u, "device saw <= 1 program");
  CHECK(sfftl_ps_state(&h.ftl) == SFFTL_PS_SAFE, "safe state");
  sfftl_ps_budget_t b; sfftl_ps_worst_case_ops(&h.ftl, &b);
  CHECK(b.page_programs >= 1 && b.block_erases <= 1, "budget reported");
  /* brown-out recovered */
  CHECK_OK(sfftl_ps_power_restored(&h.ftl), "restored");
  CHECK_OK(hx_write(&h, 3, 1), "write accepted again");
  /* real loss now: warning, then the supply dies */
  sfftl_ps_warn(&h.ftl);
  sfftl_ps_power_fail(&h.ftl, 0);
  simnand_power_off(h.nand);
  CHECK_OK(hx_crash_mount(&h), "mount after power loss");
  CHECK(hx_verify_all(&h) == 0, "every acknowledged write survived: %s", h.why);
  CHECK(simnand_stats(h.nand)->v_wp == 0, "nothing programmed under WP#");
  end_checks(&h, "powersafe");
  hx_free(&h);
}

typedef struct { uint32_t page, ppb, blocks, lba; } cfgv_t;
static const cfgv_t CFGS[] = {
  { 512, 16, 64, 512 },  { 2048, 16, 64, 512 }, { 2048, 32, 96, 2048 }, { 4096, 64, 48, 4096 },
  { 4096, 16, 64, 512 }, { 512, 32, 128, 512 }, { 1024, 8, 160, 512 },
};

static void t_configs(void) {
  for (size_t i = 0; i < sizeof(CFGS) / sizeof(CFGS[0]); i++) {
    sfftl_geom_t g; hx_geom(&g, CFGS[i].page, CFGS[i].ppb, CFGS[i].blocks);
    sfftl_cfg_t c = base_cfg();
    c.lba_bytes = CFGS[i].lba;
    hx_t h;
    int rc = hx_init(&h, &g, &c, NULL, 19 + i);
    if (rc) { CHECK(0, "config %zu init: %s", i, sfftl_strerror(rc)); hx_free(&h); continue; }
    workload(&h, SCALE(6000u), 2u * CFGS[i].page / CFGS[i].lba + 3u, 8, 40, 503);
    CHECK(hx_verify_all(&h) == 0, "config %zu: %s", i, h.why);
    CHECK_OK(hx_crash_mount(&h), "remount");
    CHECK(hx_verify_all(&h) == 0, "config %zu after crash: %s", i, h.why);
    CHECK_OK(hx_clean_remount(&h), "clean remount");
    CHECK(hx_verify_all(&h) == 0, "config %zu after clean remount: %s", i, h.why);
    end_checks(&h, "config");
    hx_free(&h);
  }
}

static void t_repeated_random(void) {
  uint32_t n = SCALE(240u), fails = 0;
  for (uint32_t i = 0; i < n && fails < 3; i++) {
    const cfgv_t *v = &CFGS[i % (sizeof(CFGS) / sizeof(CFGS[0]))];
    sfftl_geom_t g; hx_geom(&g, v->page, v->ppb, v->blocks);
    sfftl_cfg_t c = base_cfg();
    c.lba_bytes = v->lba;
    c.gc_policy = (i & 1u) ? SFFTL_GC_COST_BENEFIT : SFFTL_GC_GREEDY;
    c.wl_policy = (sfftl_wl_policy_t)(i % 3u);
    c.ckpt_interval_blocks = 2u + i % 9u;
    hx_t h;
    uint64_t seed = 77000u + i;
    if (hx_init(&h, &g, &c, NULL, seed)) { CHECK(0, "init %u", i); fails++; continue; }
    const int faulty = (i % 4u == 1u);
    int dead = 0;
    if (faulty) simnand_set_random(h.nand, 500, 3000, 0, 10000);
    for (int round = 0; round < 6 && !fails && !dead; round++) {
      uint32_t what = (uint32_t)(hx_rand(&h) % 3u);
      if (what == 0) simnand_arm_powercut(h.nand, hx_rand(&h) % 1500u);
      for (uint32_t k = 0; k < 600; k++) {
        int rc = hx_random_op(&h, 2u * v->page / v->lba + 5u, 8, 50);
        if (rc == SFFTL_EPOWER) break;
        if (faulty && rc == SFFTL_ENOSPC) continue;
        if (faulty && rc == SFFTL_EROFS) { dead = 1; break; }     /* worn out: verify below, then stop */
        if (rc) { CHECK(0, "iter %u seed %" PRIu64 " round %d: %d %s", i, seed, round, rc, h.why); fails++; break; }
      }
      int rc = (what == 1) ? hx_clean_remount(&h) : hx_crash_mount(&h);
      if (rc == SFFTL_EPOWER || (rc && what == 1)) rc = hx_crash_mount(&h);
      if (rc) { CHECK(0, "iter %u seed %" PRIu64 " mount: %s", i, seed, sfftl_strerror(rc)); fails++; break; }
      if (hx_verify_all(&h)) { CHECK(0, "iter %u seed %" PRIu64 " round %d: %s", i, seed, round, h.why); fails++; break; }
      if (sfftl_check(&h.ftl)) { CHECK(0, "iter %u: invariants", i); fails++; break; }
    }
    end_checks(&h, "repeated random");
    hx_free(&h);
  }
  printf("    %u randomized runs (7 geometries, both GC policies, 3 WL policies, cuts/clean/unclean restarts, faults)\n", n);
}

/* =============================================================== runner */
typedef struct { const char *name; void (*fn)(void); } test_t;
static const test_t TESTS[] = {
  { "geometry_and_range", t_geometry_and_range },
  { "crc32", t_crc32 },
  { "sequential", t_sequential },
  { "random_overwrite", t_random_overwrite },
  { "subpage_rmw", t_subpage_rmw },
  { "trim", t_trim },
  { "full_device", t_full_device },
  { "gc_policies", t_gc_policies },
  { "factory_bad_blocks", t_factory_bad },
  { "program_failures", t_program_failures },
  { "erase_failures", t_erase_failures },
  { "read_failures", t_read_failures },
  { "random_faults", t_random_faults },
  { "wear_levelling", t_wear_levelling },
  { "restart_clean", t_restart_clean },
  { "restart_unclean", t_restart_unclean },
  { "powercut_sweep", t_powercut_sweep },
  { "powercut_random", t_powercut_random },
  { "powercut_with_faults", t_powercut_with_faults },
  { "powercut_mount_sweep", t_powercut_mount_sweep },
  { "degraded_wearout", t_degraded },
  { "metadata_fallback", t_metadata_fallback },
  { "meta_zone_exhaustion", t_meta_zone_exhaustion },
  { "rebuild_from_spare", t_rebuild },
  { "powersafe", t_powersafe },
  { "configs", t_configs },
  { "repeated_random", t_repeated_random },
};

int main(int argc, char **argv) {
  const char *filter = NULL;
  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--quick")) g_quick = 1;
    else filter = argv[i];
  }
  int failed_tests = 0, ran = 0;
  for (size_t i = 0; i < sizeof(TESTS) / sizeof(TESTS[0]); i++) {
    if (filter && !strstr(TESTS[i].name, filter)) continue;
    uint64_t c0 = g_checks;
    g_tfail = 0;
    clock_t t0 = clock();
    printf("[ RUN  ] %s\n", TESTS[i].name);
    fflush(stdout);
    TESTS[i].fn();
    double ms = 1000.0 * (double)(clock() - t0) / CLOCKS_PER_SEC;
    printf("RESULT %-22s %s  %6" PRIu64 " checks  %9.0f ms\n", TESTS[i].name, g_tfail ? "FAIL" : "PASS", g_checks - c0, ms);
    fflush(stdout);
    failed_tests += g_tfail ? 1 : 0;
    ran++;
  }
  printf("SUMMARY %d tests, %d failed, %" PRIu64 " checks, %" PRIu64 " failed checks%s\n", ran, failed_tests, g_checks,
         g_fails, g_quick ? " (quick)" : "");
  return failed_tests ? 1 : 0;
}
