/* =============================================================================
 * SilicaFlux FlashMap (Project 56) -- PowerSafe coordination interface
 *
 * No PowerSafe project exists in the repository yet.  This header is the
 * contract the FTL offers to it (and that the StorageCore P51 power-loss path
 * already maps onto: PLP event -> firmware drain -> WP# forced).  See
 * docs/08_POWERSAFE.md.
 *
 * Key property: the FTL keeps no acknowledged data in RAM.  A write is
 * acknowledged only after its page is programmed with a self-describing spare
 * record; a TRIM only after its journal page is programmed.  On a power-fail
 * warning the FTL therefore needs NO checkpoint and NO data flush.  The only
 * volatile state worth saving is the batch of pending erase-count records
 * (wear statistics, not user data), at most ONE metadata page program.
 *
 * Sequence on the ControlCore (single-threaded main loop):
 *   1. PLP interrupt sets a flag; the ISR does not call the FTL.
 *   2. The main loop finishes the FTL call in progress (synchronous; every
 *      call ends with its NAND operations complete), then calls
 *      sfftl_ps_power_fail().  From here every mutating call returns
 *      SFFTL_EPOWER (not acknowledged), reads still work.
 *   3. sfftl_ps_power_fail() optionally programs one journal page, then asserts
 *      WP# through hal.write_protect and returns.
 *   4. If power is NOT actually lost (brown-out recovered),
 *      sfftl_ps_power_restored() releases WP# and resumes.
 *
 * Worst-case NAND work after the warning, used to size hold-up energy:
 *   in-flight FTL call: bounded by sfftl_ps_worst_case_ops() (one host page:
 *   up to read + program, plus a GC victim if a block had to be opened), then
 *   at most one page program.  The FTL's metadata ring always keeps an erased
 *   page available, so the final journal program never needs an erase.
 * ===========================================================================*/
#ifndef SFFTL_POWERSAFE_H
#define SFFTL_POWERSAFE_H

#include "sfftl.h"

#define SFFTL_PS_RUNNING  0
#define SFFTL_PS_SAFE     1    /* writes refused, WP# asserted (if the HAL can) */

#define SFFTL_PS_FLUSH_JOURNAL 0x1u  /* program pending erase-count records (1 page max) */

typedef struct {
  uint32_t page_programs;   /* NAND page programs                     */
  uint32_t page_reads;      /* NAND page reads                        */
  uint32_t block_erases;    /* NAND block erases                      */
} sfftl_ps_budget_t;

/* ISR-safe: only sets a flag.  Every FTL loop checks it between page
 * operations, so an in-flight multi-page write or GC stops after the current
 * page (returning SFFTL_EPOWER = not acknowledged). */
void sfftl_ps_warn(sfftl_t *f);
/* power-fail warning: stop mutating, optionally flush, assert WP#.
 * Returns the number of NAND programs it issued (0 or 1), or <0. */
int  sfftl_ps_power_fail(sfftl_t *f, uint32_t flags);
/* brown-out recovered: release WP#, accept writes again */
int  sfftl_ps_power_restored(sfftl_t *f);
int  sfftl_ps_state(const sfftl_t *f);
/* worst-case NAND work of ONE in-flight host page operation (the call that
 * may be running when the warning arrives), for hold-up energy sizing */
void sfftl_ps_worst_case_ops(const sfftl_t *f, sfftl_ps_budget_t *b);

#endif /* SFFTL_POWERSAFE_H */
