# 01 — ECC architecture: configurable SECDED

RTL: `rtl/sfras_ecc_funcs.svh` (code definition), `rtl/sfras_secded_enc.sv`, `rtl/sfras_secded_dec.sv`.
Reference: `model/secded_ref.py` (independent; see §7).

## 1. Code family

Extended Hamming SECDED, parameterised by the data width **K** (any K ≥ 1; nothing is hard-coded per macro):

* **R** Hamming check bits, the smallest r with 2^r ≥ K + r + 1. Closed form used in parameter lists (verified for
  K = 1 … 4999): `R = $clog2(K + $clog2(K + 1) + 1)`.
* **1** overall parity bit. Stored width **N = K + R + 1**.

| K | R | N | overhead | note |
|---|---|---|---|---|
| 8 | 4 | 13 | 62.5 % | |
| 16 | 5 | 22 | 37.5 % | |
| 32 | 6 | 39 | 21.9 % | ControlCore / memory-core word |
| 33 | 6 | 40 | — | K = 32 + poison bit |
| 57 | 6 | 64 | 12.3 % | perfect code (no invalid syndromes) |
| 64 | 7 | 72 | 12.5 % | the (72,64) organisation |
| 65 | 7 | 73 | 14.1 % | K = 64 + poison bit |
| 128 | 8 | 137 | 7.0 % | |

## 2. Bit ordering and check-bit placement

**Hamming positions** (the value a syndrome takes to name a bit):

* check bit *j* → position 2^j (j = 0 … R−1);
* data bit *i* → the (i+1)-th integer ≥ 3 that is not a power of two (3, 5, 6, 7, 9, 10, …); closed form
  `p = i + 1; for t in 0..30: if 2^t <= p: p++`;
* overall parity → position 0 (outside the syndrome).

Positions 1 … K+R are each used exactly once.

**Stored (systematic) layout** of the N-bit word `cw`:

```
 cw[K-1:0]      data bits          data bit i at cw[i]
 cw[K+R-1:K]    Hamming check bits check bit j at cw[K+j]
 cw[K+R]        overall parity     even parity over data + check bits
```

Data stays contiguous (a macro column group, or a separate check-bit macro, can hold `cw[N-1:K]`).

**Check-bit inversion `INV`** (R+1 bits, applied to `cw[K+R:K]` after encoding and removed before decoding). It
does not change any error-correcting property (a constant XOR) but selects which stored words are valid. The memory
wrapper default (`INV_SEL = -1`) is computed at elaboration by `sfras_ecc_default_inv(K)`: the first pair of
{check bits, parity} whose inversion makes **both** the all-zero and the all-ones stored word decode as
uncorrectable (even weight ⇒ the all-zero word always decodes s ≠ 0, pe = 0 ⇒ UE). Result: 0x3 for every K tested
except K = 32 (0x9). The Python model recomputes the choice with a brute-force decoder; `tb_secded` checks they agree.
Why: a dead word line, a macro that powers up as zero, or an MBIST zero-scrub must never be read as valid data.

## 3. Encoder

`c[j] = XOR of data bits whose position has bit j set` (one XOR tree of ~K/2 inputs per check bit, built from
elaboration-time masks); `p = ^data ^ ^c`; `cw = {p, c, data} ^ (INV << K)`. Purely combinational.

## 4. Syndrome calculation

```
 c_rx = cw[K+R-1:K] ^ INV[R-1:0]     p_rx = cw[K+R] ^ INV[R]     d_rx = cw[K-1:0]
 s    = encode_checks(d_rx) ^ c_rx                   (R bits)
 pe   = p_rx ^ ^c_rx ^ ^d_rx                         (overall parity of the N un-inverted bits)
 syn  = {pe, s}                                      (reported in events)
```

## 5. Classification (exactly one of NONE / CE / UE)

| s | pe | class | action |
|---|---|---|---|
| 0 | 0 | **NONE** | data as stored |
| 0 | 1 | **CE** | the overall parity bit flipped; data unaffected; `err_idx = K+R` |
| ≠0, ≤ K+R | 1 | **CE** | single error at Hamming position s: a check bit (s = 2^j, `err_idx = K+j`) or data bit i (s = pos(i), flipped back, `err_idx = i`) |
| > K+R | 1 | **UE** (`ue_inval_o`) | **invalid syndrome**: names no bit, so it cannot be a single error (≥ 3 errors); not corrected |
| ≠0 | 0 | **UE** | double (any even number ≥ 2) error |

Guarantees: every single-bit error is corrected; every double-bit error is detected; `ce_o = 1` **only** when exactly
one stored bit was flipped back (`cw_corr_o` differs from `cw_i` in exactly one bit — checked on every vector). On UE
`data_o` / `cw_corr_o` are the stored bits unchanged: the decoder never substitutes data, the caller contains it.
Errors of weight ≥ 3 may alias to a valid syndrome and be **miscorrected**; the exact fractions per K are in
`docs/09` §2, computed by exhaustive enumeration (e.g. (72,64): of all 59 640 3-bit patterns 24.04 % are
detected through invalid syndromes and 75.96 % are miscorrected; 1.10 % of 4-bit patterns are codewords, i.e.
undetected).

## 6. Implementation cost (Yosys 0.33, technology-neutral cells, `reports/synthesis.md`)

Encoder (72,64): 175 cells; decoder + classifier + corrected-word output (72,64): 714 cells; (137,128): 1 375 cells.
Logic depth: encoder = one XOR tree (~log2(K/2) levels); decoder = encoder + R-bit compare per bit + XOR. For tight
timing the memory wrapper offers `DEC_PIPE = 1` (register the raw word before decoding).

## 7. Independent reference and verification

`model/secded_ref.py` builds the parity-check matrix H explicitly and checks every encoded word against it
(`H·cw = 0`); it decodes by **column search** (H·cw = 0 → NONE; H·cw equal to exactly one column → CE at that bit;
otherwise UE), cross-checked against a brute-force nearest-codeword decoder. It has no notion of "valid syndrome",
so it independently tests the RTL's invalid-syndrome rule. `model/gen_secded_vectors.py` produces, per
configuration: every data word for K ≤ 16, the **entire received-word space** for N ≤ 16 (K = 8: 8 192 words,
K = 11: 65 536 words), **every single-bit position** for 64 data patterns, **every bit pair** for 4–8 patterns,
2 000 random triple and 500 random 4–12-bit errors. `tb/tb_secded.sv` compares stored word, corrected data, corrected
word, class, bit index, data/check flag and syndrome **bit-exactly**: 10 configurations (K = 8, 11, 16, 32, 57, 64,
128; default and zero inversion), Icarus and Verilator.
