# 02 — Memory integration: `sfras_ecc_sram`

RTL: `rtl/sfras_ecc_sram.sv` (wrapper), `rtl/sfras_sfb_ecc_slave.sv` (SFB2 slave), on top of the unmodified
`silicaflux-sramlib` raw backend `sram_backend_1rw` (vendored in `third_party/`, SHA-256 listed).

## 1. Where ECC sits

```
 requester ──► sram_sp-compatible port ─┐
 scrub engine ──► scrub port ───────────┤  sfras_ecc_sram: arbitration ─ encode ─► N-bit raw macro
 RAS FI controller ──► fi port ─────────┤                  (lock, RMW) ◄ decode ◄─  (MASK_WIDTH = 1)
 TestCore MBIST ──► raw test port ──────┘                    │
                                                             └─► RAS event port (CE / UE / poison, address, syndrome)
```

* **One encode/decode layer per memory**, directly above the macro. The macro is written with `MASK_WIDTH = 1`:
  check bits can never be out of step with data.
* **No double encoding.** The wrapper must replace, not stack on, an existing protection layer (the byte-parity
  encoders of `sfmem_banked`, `hpc_spm_bank`, `mcu_sram_bank`). A macro with built-in ECC must not be wrapped.
* The functional port is the `sram_sp` contract (valid/ready request, in-order valid/ready response, credit-based
  response FIFO, `WRITE_ACK`, `ID_W`) plus `rsp_ce` and `rsp_poison`; drop-in for `sram_sp` users.

## 2. Parameters

| Parameter | Default | Meaning |
|---|---|---|
| `K` | 64 | data bits (any width; byte lanes when K % 8 = 0) |
| `DEPTH` | 1024 | words (non-power-of-two allowed: out-of-range → error response) |
| `READ_LATENCY` | 1 | macro latency (1 … n) |
| `BACKEND`, `MACRO` | GENERIC, 0 | silicaflux-sramlib backend selection (GENERIC / FPGA / ASIC macro) |
| `BYTE_EN` | 1 | 1: partial writes by read-modify-write; 0: partial strobe refused (`rsp_err`) |
| `WRITE_ACK` | 1 | 1: every write answered; 0: posted (RMW errors then only as events) |
| `RSP_FIFO_DEPTH` | READ_LATENCY+3 | response credits (≥ READ_LATENCY + DEC_PIPE + 2 sustains 1 read/cycle) |
| `DEC_PIPE` | 0 | 1: register the raw word before the decoder (timing) |
| `POISON_MODE` | BIT | NONE / SIG / BIT (§5) |
| `UE_ZERO` | 0 | UE read data: 0 = stored (uncorrected) bits, 1 = zero (legacy convention) — `rsp_err` + `rsp_poison` either way |
| `INV_SEL` | −1 | check-bit inversion (−1 = default: all-zero / all-ones words decode UE) |
| `INIT_ON_RESET`, `REINIT_AFTER_TEST` | 1, 1 | initialisation triggers (§4) |
| `SCRUB_MAX_WAIT` | 16 | scrub starvation guard (cycles) |
| `FI_EN` | 0 | compile in the fault-injection datapath |

## 3. Access types, latency and partial writes

| Access | Array time | Latency to response | Notes |
|---|---|---|---|
| read | 1 cycle | READ_LATENCY + DEC_PIPE + 1 | pipelined, 1 per cycle |
| full write (all strobes) | 1 cycle | same (ack in order) | encode + write at the acceptance edge |
| empty strobe | 0 | same | acknowledged no-op |
| **partial write (RMW)** | 2 cycles + lock | READ_LATENCY + DEC_PIPE + 1 | read → decode/correct → merge → re-encode → write back |
| scrub CHECK / VERIFY | 1 cycle | — | plain read, no lock |
| scrub FIX | 2 cycles + lock | — | read → correct → write back |

**Read-modify-write.** The port is *locked* from the RMW read to its write-back (READ_LATENCY + DEC_PIPE + 1
cycles): no functional, scrub or injection access can be issued in between, so the merged word can never be
overtaken (no RAW hazard, no lost update). Reads accepted before the RMW complete normally (in order). The merge
uses the **corrected** old bytes, so an RMW also scrubs a correctable word. If the old word is uncorrectable or
poisoned, the bytes it contributes are unknown: the write response has `rsp_err = 1`, and

* `POISON_MODE = NONE`: the write is aborted, the word stays as found (still uncorrectable);
* `SIG` / `BIT`: the merged word is stored **poisoned** (§5).

Throughput cost measured in `tb_ecc_sram` P13: 50 % reads / 25 % full writes / 25 % partial writes at 100 % offered
load reaches 0.66 accesses/cycle vs 1.00 with no partial writes. Memories whose writers are word-granular should be
built with `BYTE_EN = 0` (no RMW path at all).

## 4. Initialisation and MBIST

* **Init engine:** writes `encode(0)` (a valid codeword, *not* the all-zero word) to every address, one per cycle,
  after reset (`INIT_ON_RESET`), on `init_req_i` (RAS register `MEM_CTRL.INIT`), and when the MBIST test port is
  released (`REINIT_AFTER_TEST`). Requests are not accepted while it runs (`init_busy_o`); `init_done_o` reports
  completion. Without it, power-up content decodes (correctly) as UE.
* **MBIST:** the test port carries raw **N-bit** stored words, so MBIST tests data *and* check-bit columns (configure
  the TestCore bank width as N). `tst_active` requests the array; `tst_ready` is granted only when nothing is in
  flight (a pending write-back is never dropped). MBIST patterns leave arbitrary check bits; the automatic
  re-initialisation restores valid codewords (verified in `tb_ecc_sram` P11). The final all-zero scrub element of
  TestCore's MBIST is therefore not sufficient on its own — and, thanks to the check-bit inversion, cannot be
  mistaken for valid data either.

## 5. Poison (detail in `docs/05`)

| Mode | Stored width | Poisoned word is | Robustness | Ambiguity |
|---|---|---|---|---|
| NONE | N(K) | — (RMW aborted) | — | — |
| SIG | N(K), e.g. 72 for K=64 | `encode(merged) ^ {two top check bits}` → decodes UE with a fixed syndrome | one more upset in a poisoned word can decode as a (wrong) CE | genuine double errors with the same syndrome read as poison: 8 of 2 556 pairs for (72,64) |
| BIT | N(K+1), e.g. 73 for K=64 | poison flag = code data bit K, set | the flag is itself single-error-corrected | none |

## 6. Integration points in the existing repositories

| Memory | Integration | Status |
|---|---|---|
| DataFabric SFB2 SRAM targets (`sfb_sram_slave`) | `sfras_sfb_ecc_slave`: same request mapping, `WRITE_ACK = 1`, `rsp_error = err | poison`, plus `rsp_poison`, scrub, init, MBIST, event and FI ports | **implemented, verified** with the real DataFabric DMA (`tb_ras_system`) |
| Memory core `sfmem_banked` | replace the parity encoder at `c_wdata` and decoder at `syn/perr` by `sfras_secded_enc/dec` (K = 32 → SW = 39, or 40 with BIT poison); stored-word width `SW` → library `DATA_WIDTH`; partial writes: RMW through the bank controller with a per-bank lock (the arbiter back-pressures the other five ports for READ_LATENCY + 2 cycles); `par_evt/par_syn/par_addr/par_port` → RAS memory event port; `ECC_CTRL.INJECT` → RAS FI | specified, not applied (separate repository) |
| HPC scratchpad `hpc_spm_bank` | SECDED only for `BYTE_WE = 0` banks (no RMW: the scratchpad's banks are throughput-critical); byte parity remains for byte-writable configurations; `rsp_err_code = ECC_UE (5)` on UE, a corrected read stays `OK` with `rsp_ce` | specified, not applied |
| ControlCore `mcu_sram_bank` | IMEM: `sfras_ecc_sram` K = 32, `BYTE_EN = 1` (loader writes words; RMW rare); DMEM: same, RMW for byte stores; `PAR_INJECT` / `PAR_CHK_EN` superseded by RAS FI and the init engine | specified, not applied |
| Tensor buffers / accumulators | not protected (see `docs/09` §6) | open |

Area/latency/throughput trade-offs are quantified in `reports/synthesis.md` (cells), `docs/03` (scrub cost) and
§3 above (RMW cost).
