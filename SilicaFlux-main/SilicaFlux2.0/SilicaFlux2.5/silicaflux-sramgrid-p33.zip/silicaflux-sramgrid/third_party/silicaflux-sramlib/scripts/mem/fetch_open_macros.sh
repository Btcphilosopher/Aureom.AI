#!/usr/bin/env bash
# =============================================================================
# Fetch the PUBLIC open-PDK SRAM macro views used by the ASIC adapters, pinned
# to the exact commits the manifests were generated from (sparse, blob-less
# clones: only Verilog models, LEF, datasheets/spec CSVs and licences are
# downloaded; GDS/Liberty are listed in the manifests but not fetched).
#
#   scripts/mem/fetch_open_macros.sh [dest]        (default: build/ext)
#
# Sources (all Apache-2.0):
#   efabless/sky130_sram_macros                  OpenRAM SKY130 1RW1R macros
#   google/globalfoundries-pdk-ip-gf180mcu_fd_ip_sram   GF180MCU 1RW macros
#   IHP-GmbH/IHP-Open-PDK (ihp-sg13g2/libs.ref/sg13g2_sram)  SG13G2 1P/2P macros
# The fetched files are treated as data (parsed by build_manifests.py,
# compiled as simulation models by the equivalence regression); nothing in
# them is executed as a script.  They are NOT redistributed in this library.
# =============================================================================
set -euo pipefail
DEST="${1:-$(cd "$(dirname "$0")/../.." && pwd)/build/ext}"
mkdir -p "$DEST"

fetch() {   # url dir commit sparse-paths...
  local url="$1" dir="$2" commit="$3"; shift 3
  if [ -d "$DEST/$dir/.git" ] && [ "$(git -C "$DEST/$dir" rev-parse HEAD 2>/dev/null)" = "$commit" ]; then
    echo "[fetch] $dir already at $commit"; return
  fi
  rm -rf "${DEST:?}/$dir"
  git init -q "$DEST/$dir"
  git -C "$DEST/$dir" remote add origin "$url"
  git -C "$DEST/$dir" sparse-checkout set --no-cone "$@"
  git -C "$DEST/$dir" fetch -q --depth 1 --filter=blob:none origin "$commit"
  git -C "$DEST/$dir" checkout -q FETCH_HEAD
  echo "[fetch] $dir @ $(git -C "$DEST/$dir" rev-parse HEAD)"
}

fetch https://github.com/efabless/sky130_sram_macros.git sky130_sram_macros \
  ebfbf5775c8cd433ad38a4d825e46c2275231511 \
  '/LICENSE' '/README.md' '/sky130_sram_*/sky130_sram_*.v' '/sky130_sram_*/*.lef'

fetch https://github.com/google/globalfoundries-pdk-ip-gf180mcu_fd_ip_sram.git gf180_sram \
  9c411928870ce15226228fa52ddb6ecc0ea4ffbe \
  '/LICENSE' '/README.rst' '/cells/*/*.v' '/cells/*/*.lef' '/cells/*/specs/*'

fetch https://github.com/IHP-GmbH/IHP-Open-PDK.git ihp \
  5e6d592e4002946a4616f798c357f0f3c06cf3b6 \
  '/LICENSE' '/ihp-sg13g2/libs.ref/sg13g2_sram/verilog/*' '/ihp-sg13g2/libs.ref/sg13g2_sram/lef/*' \
  '/ihp-sg13g2/libs.ref/sg13g2_sram/doc/*'

echo "[fetch] done: $DEST  (set SRAMLIB_EXT=$DEST or pass --ext to the scripts)"
