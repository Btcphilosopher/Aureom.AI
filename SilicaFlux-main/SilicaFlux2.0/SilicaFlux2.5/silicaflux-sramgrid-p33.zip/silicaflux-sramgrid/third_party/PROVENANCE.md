# third_party — provenance

Every file below `third_party/` is a **byte-for-byte copy** of a file in an archive of `btcphilosopher/Aureom.AI`
(`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`). Nothing is modified. `SHA256SUMS` lists every file; byte identity
with the source archives was checked when the tree was assembled (all files identical).

| Directory | Source archive | Used for |
|---|---|---|
| `silicaflux-sramlib/rtl/mem/` | `silicaflux-sramlib.zip` (`silicaflux-sramlib/rtl/mem/`) | every bank memory (raw backends GENERIC / FPGA / ASIC, `sram_asic_array`, per-family macro leaves, macro catalogue, pin-only black boxes), `sram_mbist_march` (testbench MBIST controller) |
| `silicaflux-sramlib/manifests/` | same archive | macro catalogue facts and file hashes (abstract provenance, fetch verification) |
| `silicaflux-sramlib/scripts/mem/fetch_open_macros.sh` | same archive | pinned fetch of the public SKY130 / GF180MCU / IHP SRAM views (called by `scripts/fetch_macros.sh`) |
| `silicaflux-sramlib/docs/mem/0{1,2,4}_*.md`, `README.upstream.md` | same archive | interface / backend / MBIST contracts referenced by docs/ |
| `silicaflux-ras/rtl/sfras_secded_{enc,dec}.sv`, `sfras_defs.svh`, `sfras_ecc_funcs.svh` | `silicaflux-ras-project26.zip` (`silicaflux-ras/rtl/`) | SECDED encoder / decoder of the grid banks |
| `silicaflux-ras/docs/0{1,2}_*.md` | same archive | code definition and memory-integration contract |

## Not redistributed (fetched at pinned commits by `scripts/fetch_macros.sh`, hash-verified)

| Source | Commit | Used for |
|---|---|---|
| `IHP-GmbH/IHP-Open-PDK` (`ihp-sg13g2/libs.ref/sg13g2_sram`, `sg13g2_stdcell/lef`, `sg13g2_stdcell/lib/..._typ_1p20V_25C.lib`) | `5e6d592e4002946a4616f798c357f0f3c06cf3b6` | SRAM LEF → `physical/abstracts/`; vendor Verilog models (wrapper equivalence); tech / stdcell LEF (site, grid); stdcell Liberty (logic area) |
| `efabless/sky130_sram_macros` | `ebfbf5775c8cd433ad38a4d825e46c2275231511` | LEF → abstracts; Verilog model (wrapper equivalence) |
| `google/globalfoundries-pdk-ip-gf180mcu_fd_ip_sram` | `9c411928870ce15226228fa52ddb6ecc0ea4ffbe` | LEF → abstracts; Verilog model (wrapper equivalence) |

All three are Apache-2.0. `physical/abstracts/*.json` are facts derived from those LEF files (outline, pin
rectangles, obstructions, symmetry) and carry the upstream path, commit and SHA-256 of the file they were read from.
