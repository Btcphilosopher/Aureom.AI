// =============================================================================
// SilicaFlux-HPC Project 33 :: SRAMGRID :: sfx_sg_addr_dec
// Bank address decoder: LOGICAL byte address -> (region, global bank, row)
// or an error code.  Purely combinational; one instance per requester port.
// Aureom.AI | SilicaFlux-HPC.
//
// The logical address space is a set of NR disjoint, size-aligned windows
// (regions).  Inside region r (size 2^L bytes, NB banks of DW-bit words):
//   off  = addr - R_BASE[r]                     (addr inside the window)
//   word = off >> OFF                           OFF = log2(DW/8)
//   LOW  : bank = word[BW-1:0]                     row = word >> BW
//   XOR  : bank = word[BW-1:0] ^ word[2BW-1:BW]    row = word >> BW
//   HIGH : bank = word >> RW                       row = word[RW-1:0]
//   global bank = sum(NB[0..r-1]) + bank
// Every map is a bijection between the 2^(L-OFF) words of the region and its
// NB x 2^RW bank rows: no two addresses alias, no address wraps.  The
// PHYSICAL arrangement (which macros, how many, where) is decided below the
// bank by silicaflux_sram_macro_wrapper and the placement flow; it never
// changes this map.
//
// Errors (priority UNMAPPED > ACCESS > ALIGN > WPROT > STROBE):
//   UNMAPPED : no region contains addr
//   ACCESS   : region r exists but REACH[r] = 0 (port not wired to it)
//   ALIGN    : addr[OFF-1:0] != 0
//   WPROT    : write, R_WP[r] = 1 and wp_lock = 1
//   STROBE   : write whose strobe the region cannot perform:
//              R_ECC = SECDED -> each ECC granule's strobe bits all 1 or all 0
//              otherwise, R_BWE = 0 -> strobe all 1 or all 0
//   An all-zero strobe is a legal write that changes nothing (acknowledged).
// Classification: SYNTHESIZABLE (combinational)
// =============================================================================
`include "sfx_sg_defs.svh"
`default_nettype none

module sfx_sg_addr_dec #(
  parameter int              NR      = 1,
  parameter int              AW      = 32,
  parameter int              DW      = 64,
  parameter int              ECC_G   = 64,
  parameter logic [NR*64-1:0] R_BASE  = '0,
  parameter logic [NR*8-1:0]  R_LOG2B = {NR{8'd15}},
  parameter logic [NR*8-1:0]  R_NB    = {NR{8'd4}},
  parameter logic [NR*8-1:0]  R_MAP   = '0,
  parameter logic [NR*8-1:0]  R_ECC   = '0,
  parameter logic [NR*8-1:0]  R_BWE   = {NR{8'd1}},
  parameter logic [NR*8-1:0]  R_WP    = '0,
  parameter logic [NR-1:0]    REACH   = '1,
  parameter int              BTW     = 2,     // global-bank index width (set by the grid: clog2(total banks), min 1)
  parameter int              RWX     = 10,    // row width (set by the grid: widest region row, min 1)
  // ---------------------------------------------------------- derived (never set)
  localparam int NBY = DW / 8,
  localparam int RIW = (NR > 1) ? $clog2(NR) : 1
) (
  input  wire logic [AW-1:0]   addr,
  input  wire logic            we,
  input  wire logic [NBY-1:0]  wstrb,
  input  wire logic            wp_lock,
  output logic                 ok,          // decoded without error
  output logic [2:0]           err_code,    // SG_ERR_*
  output logic [RIW-1:0]       region,      // matching region (valid unless err_code = UNMAPPED)
  output logic [BTW-1:0]       gbank,       // global bank index (valid when ok)
  output logic [RWX-1:0]       row          // row inside the bank, zero-extended (valid when ok)
);

`include "sfx_sg_cfg_funcs.svh"

  localparam int OFF = sg_off(DW);

  if (BTW != ((sg_nbt(R_NB) > 1) ? sg_clog2(sg_nbt(R_NB)) : 1)) begin : g_err_btw_inconsistent
    `SG_CFG_FATAL("sfx_sg_addr_dec: BTW must be clog2(total banks) (min 1)")
  end
  if (RWX != sg_rwmax(R_LOG2B, R_NB, DW)) begin : g_err_rwx_inconsistent
    `SG_CFG_FATAL("sfx_sg_addr_dec: RWX must be the widest region row width")
  end

  always_comb begin
    logic        found;
    logic [63:0] a64, rel, word;
    int          l, bw, rw, nb, mp;
    /* verilator lint_off UNUSEDSIGNAL */
    logic [31:0] bk, rr;          // upper bits beyond BTW / RWX are zero by construction
    /* verilator lint_on UNUSEDSIGNAL */

    found    = 1'b0;
    l = 0; bw = 0; rw = 0; nb = 1; mp = 0;
    bk = '0; rr = '0; rel = '0; word = '0;
    ok       = 1'b0;
    err_code = `SG_ERR_UNMAPPED;
    region   = '0;
    gbank    = '0;
    row      = '0;
    a64      = 64'(addr);
    for (int r = 0; r < NR; r++) begin
      l  = sg_f8(R_LOG2B, r);
      nb = sg_f8(R_NB, r);
      bw = sg_bw(R_NB, r);
      rw = sg_rw(R_LOG2B, R_NB, DW, r);
      mp = sg_f8(R_MAP, r);
      rel  = a64 - R_BASE[r*64 +: 64];
      word = rel >> OFF;
      if (((a64 ^ R_BASE[r*64 +: 64]) >> l) == 64'd0) begin
        found  = 1'b1;
        region = RIW'(r);
        // bank / row of this region's map
        if (mp == `SG_MAP_HIGH) begin
          bk = 32'(word >> rw);
          rr = 32'(word) & ((32'd1 << rw) - 32'd1);
        end else if (mp == `SG_MAP_XOR) begin
          bk = (32'(word) ^ 32'(word >> bw)) & (32'(nb) - 32'd1);
          rr = 32'(word >> bw);
        end else begin
          bk = 32'(word) & (32'(nb) - 32'd1);
          rr = 32'(word >> bw);
        end
        gbank = BTW'(32'(sg_bofs(R_NB, r)) + bk);
        row   = RWX'(rr);
        // error classification, in priority order
        if (!REACH[r]) begin
          err_code = `SG_ERR_ACCESS;
        end else if (OFF > 0 && (addr & AW'((1 << OFF) - 1)) != '0) begin
          err_code = `SG_ERR_ALIGN;
        end else if (we && sg_f8(R_WP, r) != 0 && wp_lock) begin
          err_code = `SG_ERR_WPROT;
        end else if (we && sg_f8(R_ECC, r) == `SG_ECC_SECDED && !strobe_granular(wstrb, ECC_G / 8)) begin
          err_code = `SG_ERR_STROBE;
        end else if (we && sg_f8(R_ECC, r) != `SG_ECC_SECDED && sg_f8(R_BWE, r) == 0 && !strobe_granular(wstrb, NBY)) begin
          err_code = `SG_ERR_STROBE;
        end else begin
          err_code = `SG_ERR_OK;
          ok       = 1'b1;
        end
      end
    end
    if (!found) err_code = `SG_ERR_UNMAPPED;
  end

  // strobe is all-ones or all-zeros inside every group of gb bytes
  function automatic logic strobe_granular(input logic [NBY-1:0] s, input int gb);
    integer g;
    strobe_granular = 1'b1;
    for (g = 0; g < NBY; g = g + 1) begin
      if ((g % gb) != 0 && s[g] != s[g - (g % gb)]) strobe_granular = 1'b0;
    end
  endfunction

endmodule

`default_nettype wire
