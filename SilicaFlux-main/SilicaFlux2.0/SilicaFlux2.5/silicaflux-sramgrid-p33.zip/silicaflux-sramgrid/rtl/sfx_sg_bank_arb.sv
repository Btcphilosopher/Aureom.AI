// =============================================================================
// SilicaFlux-HPC Project 33 :: SRAMGRID :: sfx_sg_bank_arb
// Per-bank arbiter.  Grants at most as many requests per cycle as the bank's
// memory-port model can perform, and never co-issues two accesses to the same
// row when one of them is a write.  Aureom.AI | SilicaFlux-HPC.
//
//   PORT_MODE 1RW  : one grant (slot A).
//   PORT_MODE 1R1W : one write (slot A = macro write port) AND one read
//                    (slot B = macro read port), picked independently.  A
//                    same-row read/write pair is split by RDW:
//                      WRITE_FIRST : write issues, read deferred (it returns
//                                    the new data one cycle later);
//                      READ_FIRST  : read issues (old data), write deferred.
//                    If the deferred access collides again in the very next
//                    cycle it wins that collision (priority alternates over
//                    back-to-back collisions), so it waits at most one extra
//                    cycle; an isolated collision always follows RDW.
//   PORT_MODE 2RW  : two grants (slots A, B): the second is the next eligible
//                    requester in arbitration order whose access does not
//                    collide with the first (same row with a write).
//
//   ARB RR    : round robin, the pointer moves past the last winner (per
//               channel for 1R1W).  Starvation-free for a continuously
//               requesting port: it waits at most NP-1 grants of its channel.
//   ARB FIXED : port 0 highest priority (may starve higher ports; offered for
//               latency-critical masters, e.g. a tensor operand fetch).
//
// Inputs are qualified by the grid: rq[p] = port p presents a decoded,
// error-free request for THIS bank and has a response credit.  CONN masks the
// ports physically wired to the bank (elaboration constant): an unconnected
// port can never be granted and its logic is removed by synthesis.
// block = 1 (MBIST / init owns the bank) suppresses every grant.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfx_sg_defs.svh"
`default_nettype none

module sfx_sg_bank_arb #(
  parameter int            NP        = 2,
  parameter logic [NP-1:0] CONN      = '1,
  parameter int            PORT_MODE = `SG_PORT_1RW,
  parameter int            ARB       = `SG_ARB_RR,
  parameter int            RDW       = `SG_RDW_WRITE_FIRST,
  parameter int            RW        = 10,
  localparam int           PW        = (NP > 1) ? $clog2(NP) : 1
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic [NP-1:0]    rq,
  input  wire logic [NP-1:0]    rq_we,
  input  wire logic [NP*RW-1:0] rq_row,
  input  wire logic             block,
  output logic      [NP-1:0]    gnt,
  output logic                  a_v,
  output logic      [PW-1:0]    a_sel,
  output logic                  b_v,
  output logic      [PW-1:0]    b_sel,
  output logic                  rdw_split,   // 1R1W: a same-row read/write pair was split this cycle
  output logic      [NP-1:0]    lost         // requested, not granted (bank conflict / port limit)
);

  if (PORT_MODE != `SG_PORT_1RW && PORT_MODE != `SG_PORT_1R1W && PORT_MODE != `SG_PORT_2RW) begin : g_err_unknown_port_mode
    `SG_CFG_FATAL("sfx_sg_bank_arb: unknown PORT_MODE")
  end
  if (ARB != `SG_ARB_RR && ARB != `SG_ARB_FIXED) begin : g_err_unknown_arb
    `SG_CFG_FATAL("sfx_sg_bank_arb: unknown ARB")
  end
  if (RDW != `SG_RDW_WRITE_FIRST && RDW != `SG_RDW_READ_FIRST) begin : g_err_unknown_rdw
    `SG_CFG_FATAL("sfx_sg_bank_arb: unknown RDW")
  end

  // ------------------------------------------------------------ helpers
  // lowest set bit of m (valid = |m)
  function automatic logic [PW-1:0] lsb_idx(input logic [NP-1:0] m);
    integer k;
    lsb_idx = '0;
    for (k = NP - 1; k >= 0; k = k - 1) if (m[k]) lsb_idx = PW'(k);
  endfunction
  // round-robin pick: first set bit strictly after ptr, else the lowest set bit
  function automatic logic [PW-1:0] rr_idx(input logic [NP-1:0] m, input logic [PW-1:0] ptr);
    logic [NP-1:0] hi;
    integer k;
    hi = '0;
    for (k = 0; k < NP; k = k + 1) hi[k] = m[k] && (k > ptr);
    rr_idx = (hi != '0) ? lsb_idx(hi) : lsb_idx(m);
  endfunction
  function automatic logic [PW-1:0] pick(input logic [NP-1:0] m, input logic [PW-1:0] ptr);
    pick = (ARB == `SG_ARB_FIXED) ? lsb_idx(m) : rr_idx(m, ptr);
  endfunction
  function automatic logic [RW-1:0] row_of(input logic [NP*RW-1:0] rows, input logic [PW-1:0] p);
    row_of = rows[p*RW +: RW];
  endfunction

  // ------------------------------------------------------------ state
  logic [PW-1:0] ptr_a_q, ptr_b_q;     // 1RW / 2RW: ptr_a only; 1R1W: a = write channel, b = read channel
  logic          flip_q;               // 1R1W: a collision in the previous cycle was split (the deferred side wins a back-to-back one)

  logic [NP-1:0] m;
  assign m = (block ? '0 : (rq & CONN));

  always_comb begin
    logic [NP-1:0] mw, mr, m2;
    logic [PW-1:0] w, r;
    logic          wv, rv, coll, write_wins;
    mw = '0; mr = '0; m2 = '0; w = '0; r = '0; wv = 1'b0; rv = 1'b0; coll = 1'b0; write_wins = 1'b0;
    a_v = 1'b0; a_sel = '0; b_v = 1'b0; b_sel = '0; rdw_split = 1'b0;
    if (PORT_MODE == `SG_PORT_1R1W) begin
      mw = m & rq_we;
      mr = m & ~rq_we;
      wv = (mw != '0);
      rv = (mr != '0);
      w  = pick(mw, ptr_a_q);
      r  = pick(mr, ptr_b_q);
      coll       = wv && rv && (row_of(rq_row, w) == row_of(rq_row, r));
      write_wins = (RDW == `SG_RDW_WRITE_FIRST) ? !flip_q : flip_q;
      a_v   = wv && !(coll && !write_wins);
      a_sel = w;
      b_v   = rv && !(coll && write_wins);
      b_sel = r;
      rdw_split = coll;
    end else if (PORT_MODE == `SG_PORT_2RW) begin
      a_v   = (m != '0);
      a_sel = pick(m, ptr_a_q);
      for (int q = 0; q < NP; q++) begin
        m2[q] = m[q] && (PW'(q) != a_sel) &&
                !((row_of(rq_row, PW'(q)) == row_of(rq_row, a_sel)) && (rq_we[q] || rq_we[a_sel]));
      end
      b_v   = a_v && (m2 != '0);
      b_sel = pick(m2, ptr_a_q);
    end else begin
      a_v   = (m != '0);
      a_sel = pick(m, ptr_a_q);
    end
  end

  always_comb begin
    gnt = '0;
    if (a_v) gnt[a_sel] = 1'b1;
    if (b_v) gnt[b_sel] = 1'b1;
  end
  assign lost = (rq & CONN) & ~gnt;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ptr_a_q <= PW'(NP - 1);   // first RR grant goes to port 0
      ptr_b_q <= PW'(NP - 1);
      flip_q  <= 1'b0;
    end else begin
      if (PORT_MODE == `SG_PORT_1R1W) begin
        if (a_v) ptr_a_q <= a_sel;
        if (b_v) ptr_b_q <= b_sel;
        flip_q <= rdw_split ? !flip_q : 1'b0;   // consecutive collisions alternate; an isolated one follows RDW
      end else begin
        if (b_v)      ptr_a_q <= b_sel;     // b_sel follows a_sel in arbitration order
        else if (a_v) ptr_a_q <= a_sel;
      end
    end
  end

`ifdef SG_ASSERT
  // checks are enabled from the first edge after reset release (no synchronous use of rst_n)
  logic chk_en_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) chk_en_q <= 1'b0;
    else        chk_en_q <= 1'b1;
  end
  always_ff @(posedge clk) begin
    if (chk_en_q) begin
      assert ((gnt & ~(rq & CONN)) == '0) else $error("%m: grant without request");
      if (PORT_MODE == `SG_PORT_1RW) assert ($countones(gnt) <= 1) else $error("%m: 1RW bank granted twice");
      else                           assert ($countones(gnt) <= 2) else $error("%m: bank granted more than twice");
      if (a_v && b_v)
        assert (!((row_of(rq_row, a_sel) == row_of(rq_row, b_sel)) && (rq_we[a_sel] || rq_we[b_sel])))
          else $error("%m: same-row pair with a write co-issued");
    end
  end
`endif

endmodule

`default_nettype wire
