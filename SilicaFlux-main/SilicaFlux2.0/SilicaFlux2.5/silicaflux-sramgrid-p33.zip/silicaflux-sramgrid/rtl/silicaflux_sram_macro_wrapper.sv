// =============================================================================
// SilicaFlux-HPC Project 33 :: SRAMGRID :: silicaflux_sram_macro_wrapper
// The boundary between one LOGICAL bank and its PHYSICAL memory: everything
// below this module is a memory implementation, everything above it is
// logic.  Aureom.AI | SilicaFlux-HPC.
//
// Implementation (IMPL = SRAM Wrapper Library BACKEND, library used unmodified):
//   SRAM_BACKEND_GENERIC (0) : behavioural / inferred array.  Simulation, formal,
//                              logic synthesis.  An ASIC flow would build it from
//                              flip-flops: it is the SYNTHESIS-INFERENCE flow,
//                              never a silicon memory.
//   SRAM_BACKEND_FPGA    (1) : block-RAM inference template (no vendor IP).
//   SRAM_BACKEND_ASIC    (2) : real open-PDK macros (IHP SG13G2 1P/2P, SKY130
//                              OpenRAM 1RW1R, GF180MCU 1RW) selected by MACRO and
//                              tiled NC x NR by sram_asic_array.  Never falls
//                              back to flip-flops; commercial placeholders and
//                              unknown ids fail elaboration.
//
// Ports
//   port A : PORT_MODE 1RW  -> the read/write port
//            PORT_MODE 1R1W -> the WRITE port (a_ce = write, a_we ignored)
//            PORT_MODE 2RW  -> read/write port a
//   port B : PORT_MODE 1RW  -> unused (b_ce must be 0)
//            PORT_MODE 1R1W -> the READ port (b_ce = read, b_we ignored)
//            PORT_MODE 2RW  -> read/write port b
//   test   : raw access for MBIST (all lanes written, no ECC: the stored word
//            including check bits is what is tested).
//
// ---------------------------------------------------------------- timing
//   Edge t = the rising clock edge that ends cycle t.
//   * Every input (ce, we, wmask, addr, wdata, tst_*) is sampled at edge t.
//   * Write : lanes with wmask = 1 take wdata at edge t (lane l = bits
//             [l*LW +: LW], LW = WIDTH / MASK_WIDTH); other lanes keep their
//             value.  A write produces no read data and no rvalid.
//   * Read  : x_rdata carries the word in cycle t + LATENCY exactly, with
//             x_rvalid = 1 in that cycle; LATENCY = MACRO_LATENCY (1 for every
//             supported macro) + OUT_REG.
//             OUT_REG = 0: x_rdata is the macro output itself and is NOT held
//               (SKY130 OpenRAM drives X one hold time after the next edge;
//               the GENERIC model poisons non-valid cycles with X in
//               simulation).  Consumers must sample it in the rvalid cycle.
//             OUT_REG = 1: x_rdata is a register loaded only in read-return
//               cycles and HELD until the next read returns.  It isolates the
//               macro clock-to-output delay from the downstream logic.
//   * Same port, write then read of the same address at edges t, t+1: the
//     read returns the new data.  Same edge, two ports, same address with a
//     write on either (1R1W / 2RW) is OUTSIDE the contract (SKY130 and IHP 2P
//     define no collision behaviour): the grid's arbiter never issues it; a
//     simulation assertion (SG_ASSERT) reports a violation.
//   * Test  : tst_mode = 1 hands the macro to the test port for that cycle;
//             functional ce is ignored.  1R1W: test writes use the write
//             port, test reads the read port, never both in one cycle.
//             tst_rdata / tst_rvalid follow the read timing above.
//   * Reset : rst_n clears only the rvalid pipeline.  The array is never
//             reset and has no defined power-up content.
//   * Macro test pins (IHP *_BIST_*) are tied off by the library leaf
//     (BIST_EN = 0, DLY = 1): test access goes through the functional pins via
//     this wrapper's test mux.  No macro has sleep / retention / repair pins.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfx_sg_defs.svh"
`default_nettype none

module silicaflux_sram_macro_wrapper #(
  parameter int WIDTH      = 32,                     // stored word width (data + check bits)
  parameter int DEPTH      = 1024,                   // words, >= 2
  parameter int MASK_WIDTH = 4,                      // write-mask lanes, divides WIDTH
  parameter int PORT_MODE  = `SG_PORT_1RW,
  parameter int IMPL       = `SRAM_BACKEND_GENERIC,
  parameter int MACRO      = 0,                      // sram_macro_ids.svh (IMPL = ASIC)
  parameter int OUT_REG    = 0,                      // 0 / 1
  parameter int TEST_EN    = 1,                      // 0 removes the test mux
  localparam int AW        = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int MACRO_LATENCY = 1,                  // every catalogue macro (manifests: read_latency_cycles = 1)
  localparam int LATENCY   = MACRO_LATENCY + OUT_REG
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // ---------------------------------------------------------- port A
  input  wire logic                  a_ce,
  input  wire logic                  a_we,
  input  wire logic [MASK_WIDTH-1:0] a_wmask,
  input  wire logic [AW-1:0]         a_addr,
  input  wire logic [WIDTH-1:0]      a_wdata,
  output logic      [WIDTH-1:0]      a_rdata,
  output logic                       a_rvalid,
  // ---------------------------------------------------------- port B
  input  wire logic                  b_ce,
  input  wire logic                  b_we,
  input  wire logic [MASK_WIDTH-1:0] b_wmask,
  input  wire logic [AW-1:0]         b_addr,
  input  wire logic [WIDTH-1:0]      b_wdata,
  output logic      [WIDTH-1:0]      b_rdata,
  output logic                       b_rvalid,
  // ---------------------------------------------------------- test controls
  input  wire logic                  tst_mode,
  input  wire logic                  tst_ce,
  input  wire logic                  tst_we,
  input  wire logic [AW-1:0]         tst_addr,
  input  wire logic [WIDTH-1:0]      tst_wdata,
  output logic      [WIDTH-1:0]      tst_rdata,
  output logic                       tst_rvalid
);

  `include "sram_macro_funcs.svh"

  // ============================================================ configuration checks
  if (IMPL == `SRAM_BACKEND_ASIC && MACRO != 0 && sram_macro_family(MACRO) == 0) begin : g_err_macro_not_in_catalogue
    `SG_CFG_FATAL("silicaflux_sram_macro_wrapper: MACRO is not an entry of the SRAM library catalogue (sram_macro_ids.svh)")
  end
  if (IMPL == `SRAM_BACKEND_ASIC && sram_macro_family(MACRO) == 9) begin : g_err_macro_pending_no_licensed_compiler_output
    `SG_CFG_FATAL("silicaflux_sram_macro_wrapper: MACRO is a commercial placeholder (PENDING_NO_MACRO): no macro exists")
  end
  if (PORT_MODE != `SG_PORT_1RW && PORT_MODE != `SG_PORT_1R1W && PORT_MODE != `SG_PORT_2RW) begin : g_err_unknown_port_mode
    `SG_CFG_FATAL("silicaflux_sram_macro_wrapper: PORT_MODE must be 0 (1RW), 1 (1R1W) or 2 (2RW)")
  end
  if (IMPL != `SRAM_BACKEND_GENERIC && IMPL != `SRAM_BACKEND_FPGA && IMPL != `SRAM_BACKEND_ASIC) begin : g_err_unknown_impl
    `SG_CFG_FATAL("silicaflux_sram_macro_wrapper: IMPL must be GENERIC (0), FPGA (1) or ASIC (2)")
  end
  if (IMPL == `SRAM_BACKEND_ASIC && MACRO == 0) begin : g_err_asic_needs_macro
    `SG_CFG_FATAL("silicaflux_sram_macro_wrapper: IMPL = ASIC needs a real MACRO id (no flip-flop fallback)")
  end
  if (DEPTH < 2) begin : g_err_depth_lt_2
    `SG_CFG_FATAL("silicaflux_sram_macro_wrapper: DEPTH must be >= 2")
  end
  if (WIDTH < 1 || MASK_WIDTH < 1 || (WIDTH % MASK_WIDTH) != 0) begin : g_err_mask_must_divide_width
    `SG_CFG_FATAL("silicaflux_sram_macro_wrapper: MASK_WIDTH must divide WIDTH")
  end
  if (OUT_REG != 0 && OUT_REG != 1) begin : g_err_out_reg_0_or_1
    `SG_CFG_FATAL("silicaflux_sram_macro_wrapper: OUT_REG must be 0 or 1")
  end
  if (TEST_EN != 0 && TEST_EN != 1) begin : g_err_test_en_0_or_1
    `SG_CFG_FATAL("silicaflux_sram_macro_wrapper: TEST_EN must be 0 or 1")
  end

  // Implementation actually handed to the library.  An ASIC request without a
  // usable macro (none, unknown id, commercial placeholder) is an error (the
  // g_err_* checks above stop Verilator and Yosys at elaboration and Icarus at
  // time 0); the library then receives a harmless GENERIC selection so that
  // Icarus, which cannot stop during elaboration, does not try to tile width-1
  // placeholder "macros".  There is no silent fallback: the fatal always fires.
  localparam int IMPL_LIB = (IMPL == `SRAM_BACKEND_ASIC &&
                             (MACRO == 0 || sram_macro_family(MACRO) == 0 || sram_macro_family(MACRO) == 9))
                            ? `SRAM_BACKEND_GENERIC : IMPL;

  // ============================================================ test mux (port shaping)
  logic                  tm;
  logic                  ma_ce, ma_we, mb_ce, mb_we;
  logic [MASK_WIDTH-1:0] ma_wm, mb_wm;
  logic [AW-1:0]         ma_ad, mb_ad;
  logic [WIDTH-1:0]      ma_wd, mb_wd;
  logic [WIDTH-1:0]      ma_rd, mb_rd;

  assign tm = (TEST_EN != 0) && tst_mode;

  always_comb begin
    ma_ce = a_ce; ma_we = a_we; ma_wm = a_wmask; ma_ad = a_addr; ma_wd = a_wdata;
    mb_ce = b_ce; mb_we = b_we; mb_wm = b_wmask; mb_ad = b_addr; mb_wd = b_wdata;
    if (PORT_MODE == `SG_PORT_1RW) begin
      mb_ce = 1'b0; mb_we = 1'b0;
    end
    if (tm) begin
      if (PORT_MODE == `SG_PORT_1R1W) begin
        ma_ce = tst_ce &&  tst_we; ma_we = 1'b1;
        mb_ce = tst_ce && !tst_we; mb_we = 1'b0;
      end else begin
        ma_ce = tst_ce; ma_we = tst_we;
        mb_ce = 1'b0;   mb_we = 1'b0;
      end
      ma_wm = '1;       ma_ad = tst_addr; ma_wd = tst_wdata;
      mb_wm = '1;       mb_ad = tst_addr; mb_wd = tst_wdata;
    end
  end

  // ============================================================ array (SRAM Wrapper Library, unmodified)
  // The three branches share the block name g_mem so the hierarchy below this
  // wrapper is <wrapper>.g_mem.u_mem.<backend> in every port mode (stable
  // names for the netlist-driven placement scripts and the testbench backdoor).
  if (PORT_MODE == `SG_PORT_1R1W) begin : g_mem
    sram_backend_1r1w #(
      .DATA_WIDTH(WIDTH), .DEPTH(DEPTH), .MASK_WIDTH(MASK_WIDTH), .READ_LATENCY(MACRO_LATENCY),
      .BACKEND(IMPL_LIB), .MACRO(MACRO)
    ) u_mem (
      .clk(clk), .we(ma_ce), .wmask(ma_wm), .waddr(ma_ad), .wdata(ma_wd),
      .re(mb_ce), .raddr(mb_ad), .rdata(mb_rd)
    );
    assign ma_rd = '0;
    wire unused_1r1w = &{1'b0, ma_we, mb_we, mb_wm, mb_wd};
  end else if (PORT_MODE == `SG_PORT_2RW) begin : g_mem
    sram_backend_2rw #(
      .DATA_WIDTH(WIDTH), .DEPTH(DEPTH), .MASK_WIDTH(MASK_WIDTH), .READ_LATENCY(MACRO_LATENCY),
      .BACKEND(IMPL_LIB), .MACRO(MACRO)
    ) u_mem (
      .clk(clk),
      .a_ce(ma_ce), .a_we(ma_we), .a_wmask(ma_wm), .a_addr(ma_ad), .a_wdata(ma_wd), .a_rdata(ma_rd),
      .b_ce(mb_ce), .b_we(mb_we), .b_wmask(mb_wm), .b_addr(mb_ad), .b_wdata(mb_wd), .b_rdata(mb_rd)
    );
  end else begin : g_mem
    sram_backend_1rw #(
      .DATA_WIDTH(WIDTH), .DEPTH(DEPTH), .MASK_WIDTH(MASK_WIDTH), .READ_LATENCY(MACRO_LATENCY),
      .BACKEND(IMPL_LIB), .MACRO(MACRO)
    ) u_mem (
      .clk(clk), .ce(ma_ce), .we(ma_we), .wmask(ma_wm), .addr(ma_ad), .wdata(ma_wd), .rdata(ma_rd)
    );
    assign mb_rd = '0;
    wire unused_1rw = &{1'b0, mb_ce, mb_we, mb_wm, mb_ad, mb_wd};
  end

  // ============================================================ read-valid pipeline
  // Read issued at edge t on port A / B (functional or test).
  logic a_rd, b_rd, a_rd_t, b_rd_t;
  always_comb begin
    if (PORT_MODE == `SG_PORT_1R1W) begin
      a_rd = 1'b0;            b_rd = mb_ce;
    end else if (PORT_MODE == `SG_PORT_2RW) begin
      a_rd = ma_ce && !ma_we; b_rd = mb_ce && !mb_we;
    end else begin
      a_rd = ma_ce && !ma_we; b_rd = 1'b0;
    end
    a_rd_t = a_rd && tm;
    b_rd_t = b_rd && tm;
  end

  logic [LATENCY-1:0] a_vq, b_vq, at_vq, bt_vq;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      a_vq <= '0; b_vq <= '0; at_vq <= '0; bt_vq <= '0;
    end else begin
      a_vq[0] <= a_rd && !tm;  b_vq[0] <= b_rd && !tm;
      at_vq[0] <= a_rd_t;      bt_vq[0] <= b_rd_t;
      for (int k = 1; k < LATENCY; k++) begin
        a_vq[k] <= a_vq[k-1];  b_vq[k] <= b_vq[k-1];
        at_vq[k] <= at_vq[k-1]; bt_vq[k] <= bt_vq[k-1];
      end
    end
  end

  // ============================================================ output stage
  logic [WIDTH-1:0] a_out, b_out;
  if (OUT_REG != 0) begin : g_oreg
    // loaded in the macro's read-return cycle (vq[0]), held until the next one
    logic [WIDTH-1:0] a_q, b_q;
    always_ff @(posedge clk) begin
      if (a_vq[0] || at_vq[0]) a_q <= ma_rd;
      if (b_vq[0] || bt_vq[0]) b_q <= mb_rd;
    end
    assign a_out = a_q;
    assign b_out = b_q;
  end else begin : g_noreg
    assign a_out = ma_rd;
    assign b_out = mb_rd;
  end

  assign a_rdata    = a_out;
  assign b_rdata    = b_out;
  assign a_rvalid   = a_vq[LATENCY-1];
  assign b_rvalid   = b_vq[LATENCY-1];
  assign tst_rdata  = (PORT_MODE == `SG_PORT_1R1W) ? b_out : a_out;
  assign tst_rvalid = at_vq[LATENCY-1] || bt_vq[LATENCY-1];

  // ============================================================ simulation checks
`ifdef SG_ASSERT
  // checks are enabled from the first edge after reset release (no synchronous use of rst_n)
  logic chk_en_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) chk_en_q <= 1'b0;
    else        chk_en_q <= 1'b1;
  end
  always_ff @(posedge clk) begin
    if (chk_en_q) begin
      if (PORT_MODE == `SG_PORT_1RW)
        assert (!b_ce) else $error("%m: port B used on a 1RW macro wrapper");
      if (PORT_MODE == `SG_PORT_1R1W)
        assert (!(ma_ce && mb_ce && ma_ad == mb_ad))
          else $error("%m: same-address read and write in one cycle (outside the macro contract)");
      if (PORT_MODE == `SG_PORT_2RW)
        assert (!(ma_ce && mb_ce && ma_ad == mb_ad && (ma_we || mb_we)))
          else $error("%m: same-address dual-port access with a write (outside the macro contract)");
      if (tm)
        assert (!a_ce && !b_ce) else $error("%m: functional access presented while tst_mode = 1");
    end
  end
`endif

endmodule

`default_nettype wire
