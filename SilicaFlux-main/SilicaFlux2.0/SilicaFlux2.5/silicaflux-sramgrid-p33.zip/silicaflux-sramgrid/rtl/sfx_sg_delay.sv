// =============================================================================
// SilicaFlux-HPC Project 33 :: SRAMGRID :: sfx_sg_delay
// N-stage register delay line (N = 0: wire).  RST = 1: stages reset
// asynchronously to 0 (valid bits); RST = 0: plain data registers (payload,
// never reset - no reset fan-out on wide buses).  Aureom.AI | SilicaFlux-HPC.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfx_sg_delay #(
  parameter int W   = 1,
  parameter int N   = 1,
  parameter int RST = 0
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic [W-1:0] d,
  output logic      [W-1:0] q
);
  if (N == 0) begin : g_wire
    assign q = d;
    wire unused = &{1'b0, clk, rst_n};
  end else begin : g_reg
    logic [W-1:0] r [N];
    if (RST != 0) begin : g_rst
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          for (int k = 0; k < N; k++) r[k] <= '0;
        end else begin
          r[0] <= d;
          for (int k = 1; k < N; k++) r[k] <= r[k-1];
        end
      end
    end else begin : g_norst
      always_ff @(posedge clk) begin
        r[0] <= d;
        for (int k = 1; k < N; k++) r[k] <= r[k-1];
      end
      wire unused = &{1'b0, rst_n};
    end
    assign q = r[N-1];
  end
endmodule

`default_nettype wire
