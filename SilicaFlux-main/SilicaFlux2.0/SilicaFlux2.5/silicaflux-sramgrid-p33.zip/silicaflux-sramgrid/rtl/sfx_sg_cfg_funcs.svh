// =============================================================================
// SilicaFlux-HPC Project 33 :: SRAMGRID :: sfx_sg_cfg_funcs.svh
// Elaboration-time helpers over the packed region table.  Included INSIDE a
// module body that declares NR, DW, ECC_G and the R_* region vectors.  Every
// function takes the vectors as arguments (no hierarchical / free parameter
// references) so Yosys 0.33, Icarus 12 and Verilator 5.020 evaluate them as
// constant functions.
//
// Region table layout (field f of region r = V[r*W +: W]):
//   R_BASE  64 b  byte base, aligned to the region size
//   R_LOG2B  8 b  log2(region bytes)
//   R_NB     8 b  banks (1, 2, 4, 8, 16)
//   R_PM     8 b  bank memory-port model (SG_PORT_*)
//   R_MAP    8 b  address -> bank mapping (SG_MAP_*)
//   R_ECC    8 b  integrity (SG_ECC_*)
//   R_BWE    8 b  1: byte write enables, 0: whole-word writes
//   R_PIPE   8 b  request pipeline stages between arbiter and macro (0..3)
//   R_OREG   8 b  macro output register (0 / 1)
//   R_IMPL   8 b  SRAM_BACKEND_* of the bank memory
//   R_MACRO 16 b  macro id (IMPL = ASIC)
//   R_WP     8 b  1: writes refused while wp_lock = 1
// No include guard on purpose: it is included once per module body.
// =============================================================================

  function automatic int sg_f8(input logic [NR*8-1:0] v, input int r);
    sg_f8 = 0;
    sg_f8[7:0] = v[r*8 +: 8];
  endfunction

  function automatic int sg_f16(input logic [NR*16-1:0] v, input int r);
    sg_f16 = 0;
    sg_f16[15:0] = v[r*16 +: 16];
  endfunction

  function automatic int sg_clog2(input int x);
    int k;
    sg_clog2 = 0;
    for (k = 0; k < 31; k++) if ((1 << k) < x) sg_clog2 = k + 1;
  endfunction

  // log2 of the bank word in bytes
  function automatic int sg_off(input int dw);
    sg_off = sg_clog2(dw / 8);
  endfunction

  // bank-index bits of region r
  function automatic int sg_bw(input logic [NR*8-1:0] nb, input int r);
    sg_bw = sg_clog2(sg_f8(nb, r));
  endfunction

  // row-address bits of region r
  function automatic int sg_rw(input logic [NR*8-1:0] l2b, input logic [NR*8-1:0] nb, input int dw, input int r);
    sg_rw = sg_f8(l2b, r) - sg_off(dw) - sg_bw(nb, r);
  endfunction

  // first global bank index of region r
  function automatic int sg_bofs(input logic [NR*8-1:0] nb, input int r);
    int k;
    sg_bofs = 0;
    for (k = 0; k < NR; k++) if (k < r) sg_bofs = sg_bofs + sg_f8(nb, k);
  endfunction

  // total banks
  function automatic int sg_nbt(input logic [NR*8-1:0] nb);
    sg_nbt = sg_bofs(nb, NR);
  endfunction

  // region of global bank b
  function automatic int sg_bank_region(input logic [NR*8-1:0] nb, input int b);
    int k;
    sg_bank_region = 0;
    for (k = 0; k < NR; k++) if (b >= sg_bofs(nb, k)) sg_bank_region = k;
  endfunction

  // widest row address over all regions (>= 1)
  function automatic int sg_rwmax(input logic [NR*8-1:0] l2b, input logic [NR*8-1:0] nb, input int dw);
    int k;
    sg_rwmax = 1;
    for (k = 0; k < NR; k++) if (sg_rw(l2b, nb, dw, k) > sg_rwmax) sg_rwmax = sg_rw(l2b, nb, dw, k);
  endfunction

  // SECDED check bits for a G-bit granule (smallest r with 2^r >= G + r + 1)
  function automatic int sg_secded_r(input int g);
    int t;
    sg_secded_r = 0;
    for (t = 24; t >= 1; t--) if ((1 << t) >= g + t + 1) sg_secded_r = t;
  endfunction

  // stored word width of a bank with integrity mode e
  function automatic int sg_sw(input int e, input int dw, input int g);
    if (e == `SG_ECC_PARITY)      sg_sw = (dw / 8) * 9;
    else if (e == `SG_ECC_SECDED) sg_sw = (dw / g) * (g + sg_secded_r(g) + 1);
    else                          sg_sw = dw;
  endfunction

  // macro write-mask lanes of a bank
  function automatic int sg_mw(input int e, input int bwe, input int dw, input int g);
    if (e == `SG_ECC_SECDED)      sg_mw = dw / g;            // one lane per ECC granule codeword
    else if (bwe != 0)            sg_mw = dw / 8;            // byte (or 9-bit parity) lanes
    else                          sg_mw = 1;                 // whole-word writes
  endfunction
