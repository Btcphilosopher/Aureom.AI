// =============================================================================
// SilicaFlux-HPC Project 33 :: SRAMGRID :: sfx_sg_bank
// One LOGICAL bank: request pipeline (wire distance), integrity encode,
// silicaflux_sram_macro_wrapper (the physical memory), completion pipeline,
// integrity decode.  Aureom.AI | SilicaFlux-HPC.
//
//   slot A/B request (from the bank arbiter, or init / test injection)
//        |  PIPE register stages (0..3): models arbiter -> macro wire distance
//        v
//   encode (NONE / byte PARITY / SECDED per ECC_G granule, RAS P26 encoder)
//        v
//   silicaflux_sram_macro_wrapper  (read latency 1 + OUT_REG)
//        v
//   decode (PARITY check / SECDED correct, RAS P26 decoder)  -> completion
//
// ---------------------------------------------------------------- timing
//   An access accepted (granted) at edge t reaches the macro at edge t + PIPE
//   and completes in cycle t + LAT, LAT = PIPE + 1 + OUT_REG (computed by the
//   grid, which owns the latency budget): x_o_v = 1 with
//   its meta, we, row and, for reads, the decoded data.  Writes complete at the
//   same latency (acknowledged AFTER the array was written - SFB2 R7).  Every
//   access to the bank traverses the same pipeline, so the bank performs
//   accesses in grant order: a read granted at a later edge than a write to
//   the same row returns the written data.
//   Init writes and MBIST operations enter the same pipeline (slot A) and
//   produce no completion; MBIST read data appears on tst_rdata / tst_rvalid
//   at LAT.
//
// ---------------------------------------------------------------- storage
//   ECC NONE   : SW = DW,          mask lanes = DW/8 (BYTE_WE) or 1
//   ECC PARITY : SW = 9 * DW / 8,  lane = {~^byte, byte} (odd parity: a lane
//                of nine zeros is an error), mask lanes = DW/8 or 1
//   ECC SECDED : SW = (DW/G)*(G+R+1); granule g = {par, chk, data}; mask lane
//                = one granule codeword (the decoder only lets granule-whole
//                strobes through).  Check-bit inversion = RAS default: an
//                all-zero stored word decodes UNCORRECTABLE, so an
//                uninitialised or dead row is never read as valid data.
//                Init writes encode(0) (a valid codeword).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfx_sg_defs.svh"
`include "sfras_defs.svh"
`default_nettype none

module sfx_sg_bank #(
  parameter int DW        = 64,
  parameter int DEPTH     = 1024,
  parameter int PORT_MODE = `SG_PORT_1RW,
  parameter int BYTE_WE   = 1,
  parameter int ECC       = `SG_ECC_NONE,
  parameter int ECC_G     = 64,
  parameter int PIPE      = 0,
  parameter int OUT_REG   = 0,
  parameter int IMPL      = `SRAM_BACKEND_GENERIC,
  parameter int MACRO     = 0,
  parameter int MTW       = 8,                     // completion meta width (port, slot)
  // ---------------------------------------------------------- derived (never set)
  localparam int NBY  = DW / 8,
  localparam int RW   = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int GR   = $clog2(ECC_G + $clog2(ECC_G + 1) + 1),      // SECDED check bits per granule
  localparam int GN   = ECC_G + GR + 1,                               // stored bits per granule
  localparam int NG   = DW / ECC_G,
  localparam int SW   = (ECC == `SG_ECC_SECDED) ? NG * GN : (ECC == `SG_ECC_PARITY) ? NBY * 9 : DW,
  localparam int MW   = (ECC == `SG_ECC_SECDED) ? NG : (BYTE_WE != 0) ? NBY : 1,
  localparam int IDXW = $clog2(GN)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ---------------------------------------------------------- slot A / B requests
  input  wire logic             a_v,
  input  wire logic             a_we,
  input  wire logic [RW-1:0]    a_row,
  input  wire logic [DW-1:0]    a_wdata,
  input  wire logic [NBY-1:0]   a_wstrb,
  input  wire logic [MTW-1:0]   a_meta,
  input  wire logic             b_v,
  input  wire logic             b_we,
  input  wire logic [RW-1:0]    b_row,
  input  wire logic [DW-1:0]    b_wdata,
  input  wire logic [NBY-1:0]   b_wstrb,
  input  wire logic [MTW-1:0]   b_meta,
  // ---------------------------------------------------------- init / test injection (slot A; caller guarantees no functional request)
  input  wire logic             init_v,           // write encode(0) to init_row
  input  wire logic [RW-1:0]    init_row,
  input  wire logic             tst_v,            // raw MBIST operation
  input  wire logic             tst_we,
  input  wire logic [RW-1:0]    tst_row,
  input  wire logic [SW-1:0]    tst_wdata,
  output logic      [SW-1:0]    tst_rdata,
  output logic                  tst_rvalid,
  // ---------------------------------------------------------- completions (cycle t + LAT)
  output logic                  ao_v,
  output logic                  ao_we,
  output logic      [MTW-1:0]   ao_meta,
  output logic      [DW-1:0]    ao_rdata,          // corrected data (reads)
  output logic                  ao_ce,             // SECDED: a bit was corrected
  output logic                  ao_ue,             // SECDED: uncorrectable
  output logic                  ao_perr,           // PARITY: mismatch
  output logic                  bo_v,
  output logic                  bo_we,
  output logic      [MTW-1:0]   bo_meta,
  output logic      [DW-1:0]    bo_rdata,
  output logic                  bo_ce,
  output logic                  bo_ue,
  output logic                  bo_perr,
  // ---------------------------------------------------------- RAS event (one per cycle; slot B first if both)
  output logic                  ev_v,
  output logic                  ev_ce,
  output logic                  ev_ue,
  output logic      [RW-1:0]    ev_row,
  output logic      [8:0]       ev_syn,            // {pe, s} of the first failing granule (SECDED), zero-extended
  output logic      [7:0]       ev_idx,            // stored-bit index inside that granule (SECDED CE)
  output logic      [7:0]       ev_gran,           // granule (SECDED) / byte lane (PARITY) of the first failure
  output logic                  ev_multi           // more than one slot failed this cycle (second not reported)
);

  `include "sfras_ecc_funcs.svh"

  // ============================================================ configuration checks
  if (DW < 8 || (DW % 8) != 0) begin : g_err_dw_not_byte_multiple
    `SG_CFG_FATAL("sfx_sg_bank: DW must be a multiple of 8")
  end
  if (ECC == `SG_ECC_SECDED && (ECC_G != 32 && ECC_G != 64)) begin : g_err_ecc_granule_32_or_64
    `SG_CFG_FATAL("sfx_sg_bank: ECC_G must be 32 or 64")
  end
  if (ECC == `SG_ECC_SECDED && (DW % ECC_G) != 0) begin : g_err_dw_not_multiple_of_granule
    `SG_CFG_FATAL("sfx_sg_bank: DW must be a multiple of ECC_G with SECDED")
  end
  if (PIPE < 0 || PIPE > 3) begin : g_err_pipe_0_to_3
    `SG_CFG_FATAL("sfx_sg_bank: PIPE must be 0..3")
  end
  if (ECC != `SG_ECC_NONE && ECC != `SG_ECC_PARITY && ECC != `SG_ECC_SECDED) begin : g_err_unknown_ecc
    `SG_CFG_FATAL("sfx_sg_bank: unknown ECC mode")
  end

  localparam int INV = sfras_ecc_default_inv(ECC_G);

  // ============================================================ request pipeline (stage 0 = input)
  // valid bits (reset) and payload {we, test, init, row, wdata, wstrb, meta} (not reset)
  localparam int OPW = 3 + RW + DW + NBY + MTW;
  logic           s0_av, s0_bv;
  logic [OPW-1:0] s0_a, s0_b;

  always_comb begin
    // slot A: test > init > functional (the grid never presents more than one)
    if (tst_v) begin
      s0_av = 1'b1;   s0_a = {tst_we, 1'b1, 1'b0, tst_row,  {DW{1'b0}}, {NBY{1'b1}}, {MTW{1'b0}}};
    end else if (init_v) begin
      s0_av = 1'b1;   s0_a = {1'b1,   1'b0, 1'b1, init_row, {DW{1'b0}}, {NBY{1'b1}}, {MTW{1'b0}}};
    end else begin
      s0_av = a_v;    s0_a = {a_we,   1'b0, 1'b0, a_row,    a_wdata,    a_wstrb,     a_meta};
    end
    s0_bv = b_v && !tst_v && !init_v;
    s0_b  = {b_we, 1'b0, 1'b0, b_row, b_wdata, b_wstrb, b_meta};
  end

  logic             mav, mawe, mat, mai, mbv, mbwe;
  logic [RW-1:0]    marow, mbrow;
  logic [DW-1:0]    mawd, mbwd;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NBY-1:0]   mast, mbst;        // only bit 0 used for word-write banks
  /* verilator lint_on UNUSEDSIGNAL */
  logic [MTW-1:0]   mamt, mbmt;
  logic [SW-1:0]    mtd;
  /* verilator lint_off UNUSEDSIGNAL */
  logic             mbt, mbi;          // never set on slot B
  /* verilator lint_on UNUSEDSIGNAL */
  sfx_sg_delay #(.W(1),   .N(PIPE), .RST(1)) u_pipe_av (.clk(clk), .rst_n(rst_n), .d(s0_av), .q(mav));
  sfx_sg_delay #(.W(1),   .N(PIPE), .RST(1)) u_pipe_bv (.clk(clk), .rst_n(rst_n), .d(s0_bv), .q(mbv));
  sfx_sg_delay #(.W(OPW), .N(PIPE), .RST(0)) u_pipe_a  (.clk(clk), .rst_n(rst_n), .d(s0_a),
                                                         .q({mawe, mat, mai, marow, mawd, mast, mamt}));
  sfx_sg_delay #(.W(OPW), .N(PIPE), .RST(0)) u_pipe_b  (.clk(clk), .rst_n(rst_n), .d(s0_b),
                                                         .q({mbwe, mbt, mbi, mbrow, mbwd, mbst, mbmt}));
  sfx_sg_delay #(.W(SW),  .N(PIPE), .RST(0)) u_pipe_t  (.clk(clk), .rst_n(rst_n), .d(tst_wdata), .q(mtd));

  // ============================================================ encode
  logic [SW-1:0] a_sw, b_sw;
  logic [MW-1:0] a_m, b_m;
  if (ECC == `SG_ECC_SECDED) begin : g_enc_secded
    for (genvar g = 0; g < NG; g++) begin : g_gran
      sfras_secded_enc #(.K(ECC_G), .INV(INV)) u_enc_a (.data_i(mawd[g*ECC_G +: ECC_G]), .cw_o(a_sw[g*GN +: GN]));
      sfras_secded_enc #(.K(ECC_G), .INV(INV)) u_enc_b (.data_i(mbwd[g*ECC_G +: ECC_G]), .cw_o(b_sw[g*GN +: GN]));
      assign a_m[g] = mast[g*(ECC_G/8)];
      assign b_m[g] = mbst[g*(ECC_G/8)];
    end
  end else if (ECC == `SG_ECC_PARITY) begin : g_enc_parity
    for (genvar l = 0; l < NBY; l++) begin : g_lane
      assign a_sw[l*9 +: 9] = {~^mawd[l*8 +: 8], mawd[l*8 +: 8]};
      assign b_sw[l*9 +: 9] = {~^mbwd[l*8 +: 8], mbwd[l*8 +: 8]};
    end
    if (BYTE_WE != 0) begin : g_bm
      assign a_m = mast; assign b_m = mbst;
    end else begin : g_wm
      assign a_m = mast[0]; assign b_m = mbst[0];
    end
  end else begin : g_enc_none
    assign a_sw = mawd;
    assign b_sw = mbwd;
    if (BYTE_WE != 0) begin : g_bm
      assign a_m = mast; assign b_m = mbst;
    end else begin : g_wm
      assign a_m = mast[0]; assign b_m = mbst[0];
    end
  end

  // ============================================================ physical memory
  logic [SW-1:0] w_ard, w_brd;
  /* verilator lint_off UNUSEDSIGNAL */
  logic          w_arv, w_brv;          // used by the SG_ASSERT consistency check only
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_sram_macro_wrapper #(
    .WIDTH(SW), .DEPTH(DEPTH), .MASK_WIDTH(MW), .PORT_MODE(PORT_MODE),
    .IMPL(IMPL), .MACRO(MACRO), .OUT_REG(OUT_REG), .TEST_EN(1)
  ) u_mw (
    .clk(clk), .rst_n(rst_n),
    .a_ce(mav && !mat), .a_we(mawe), .a_wmask(a_m), .a_addr(marow), .a_wdata(a_sw), .a_rdata(w_ard), .a_rvalid(w_arv),
    .b_ce(mbv),         .b_we(mbwe), .b_wmask(b_m), .b_addr(mbrow), .b_wdata(b_sw), .b_rdata(w_brd), .b_rvalid(w_brv),
    .tst_mode(mav && mat), .tst_ce(mav && mat), .tst_we(mawe), .tst_addr(marow), .tst_wdata(mtd),
    .tst_rdata(tst_rdata), .tst_rvalid(tst_rvalid)
  );

  // ============================================================ completion pipeline (macro edge -> LAT)
  localparam int CL  = 1 + OUT_REG;
  localparam int CPW = 1 + MTW + RW;          // {we, meta, row}
  logic [RW-1:0] arow_o, brow_o;
  sfx_sg_delay #(.W(1),   .N(CL), .RST(1)) u_cpl_av (.clk(clk), .rst_n(rst_n), .d(mav && !mat && !mai), .q(ao_v));
  sfx_sg_delay #(.W(1),   .N(CL), .RST(1)) u_cpl_bv (.clk(clk), .rst_n(rst_n), .d(mbv), .q(bo_v));
  sfx_sg_delay #(.W(CPW), .N(CL), .RST(0)) u_cpl_a  (.clk(clk), .rst_n(rst_n), .d({mawe, mamt, marow}), .q({ao_we, ao_meta, arow_o}));
  sfx_sg_delay #(.W(CPW), .N(CL), .RST(0)) u_cpl_b  (.clk(clk), .rst_n(rst_n), .d({mbwe, mbmt, mbrow}), .q({bo_we, bo_meta, brow_o}));

  // ============================================================ decode
  logic [DW-1:0] a_dd, b_dd;
  logic          a_ce_d, a_ue_d, a_pe_d, b_ce_d, b_ue_d, b_pe_d;
  logic [8:0]    a_syn, b_syn;
  logic [7:0]    a_idx, b_idx, a_gr, b_gr;
  if (ECC == `SG_ECC_SECDED) begin : g_dec_secded
    logic [NG-1:0]      ace, aue, bce, bue;
    logic [NG*(GR+1)-1:0] asy, bsy;
    logic [NG*IDXW-1:0] aix, bix;
    for (genvar g = 0; g < NG; g++) begin : g_gran
      /* verilator lint_off PINCONNECTEMPTY */
      sfras_secded_dec #(.K(ECC_G), .INV(INV)) u_dec_a (
        .cw_i(w_ard[g*GN +: GN]), .data_o(a_dd[g*ECC_G +: ECC_G]), .cw_corr_o(), .none_o(), .ce_o(ace[g]),
        .ue_o(aue[g]), .ue_inval_o(), .ce_data_o(), .err_idx_o(aix[g*IDXW +: IDXW]), .syn_o(asy[g*(GR+1) +: GR+1]));
      sfras_secded_dec #(.K(ECC_G), .INV(INV)) u_dec_b (
        .cw_i(w_brd[g*GN +: GN]), .data_o(b_dd[g*ECC_G +: ECC_G]), .cw_corr_o(), .none_o(), .ce_o(bce[g]),
        .ue_o(bue[g]), .ue_inval_o(), .ce_data_o(), .err_idx_o(bix[g*IDXW +: IDXW]), .syn_o(bsy[g*(GR+1) +: GR+1]));
      /* verilator lint_on PINCONNECTEMPTY */
    end
    always_comb begin
      a_ce_d = |ace; a_ue_d = |aue; a_pe_d = 1'b0;
      b_ce_d = |bce; b_ue_d = |bue; b_pe_d = 1'b0;
      a_syn = '0; b_syn = '0; a_idx = '0; b_idx = '0; a_gr = '0; b_gr = '0;
      for (int g = NG - 1; g >= 0; g--) begin
        if (ace[g] || aue[g]) begin a_syn = 9'(asy[g*(GR+1) +: GR+1]); a_idx = 8'(aix[g*IDXW +: IDXW]); a_gr = 8'(g); end
        if (bce[g] || bue[g]) begin b_syn = 9'(bsy[g*(GR+1) +: GR+1]); b_idx = 8'(bix[g*IDXW +: IDXW]); b_gr = 8'(g); end
      end
    end
  end else if (ECC == `SG_ECC_PARITY) begin : g_dec_parity
    logic [NBY-1:0] ape, bpe;
    for (genvar l = 0; l < NBY; l++) begin : g_lane
      assign a_dd[l*8 +: 8] = w_ard[l*9 +: 8];
      assign b_dd[l*8 +: 8] = w_brd[l*9 +: 8];
      assign ape[l] = ~^w_ard[l*9 +: 9];     // odd parity: XOR of the 9 stored bits must be 1
      assign bpe[l] = ~^w_brd[l*9 +: 9];
    end
    always_comb begin
      a_ce_d = 1'b0; a_ue_d = 1'b0; a_pe_d = |ape;
      b_ce_d = 1'b0; b_ue_d = 1'b0; b_pe_d = |bpe;
      a_syn = '0; b_syn = '0; a_idx = '0; b_idx = '0; a_gr = '0; b_gr = '0;
      for (int l = NBY - 1; l >= 0; l--) begin
        if (ape[l]) a_gr = 8'(l);
        if (bpe[l]) b_gr = 8'(l);
      end
    end
  end else begin : g_dec_none
    assign a_dd = w_ard;
    assign b_dd = w_brd;
    assign {a_ce_d, a_ue_d, a_pe_d, b_ce_d, b_ue_d, b_pe_d} = '0;
    assign {a_syn, b_syn, a_idx, b_idx, a_gr, b_gr} = '0;
  end

  // integrity flags only for read completions
  assign ao_rdata = a_dd;
  assign bo_rdata = b_dd;
  assign ao_ce    = ao_v && !ao_we && a_ce_d;
  assign ao_ue    = ao_v && !ao_we && a_ue_d;
  assign ao_perr  = ao_v && !ao_we && a_pe_d;
  assign bo_ce    = bo_v && !bo_we && b_ce_d;
  assign bo_ue    = bo_v && !bo_we && b_ue_d;
  assign bo_perr  = bo_v && !bo_we && b_pe_d;

  // ============================================================ RAS event
  logic a_ev, b_ev;
  assign a_ev = ao_ce || ao_ue || ao_perr;
  assign b_ev = bo_ce || bo_ue || bo_perr;
  always_comb begin
    ev_v = a_ev || b_ev;
    ev_multi = a_ev && b_ev;
    if (b_ev) begin
      ev_ce = bo_ce; ev_ue = bo_ue || bo_perr; ev_row = brow_o; ev_syn = b_syn; ev_idx = b_idx; ev_gran = b_gr;
    end else begin
      ev_ce = ao_ce; ev_ue = ao_ue || ao_perr; ev_row = arow_o; ev_syn = a_syn; ev_idx = a_idx; ev_gran = a_gr;
    end
  end

`ifdef SG_ASSERT
  // checks are enabled from the first edge after reset release (no synchronous use of rst_n)
  logic chk_en_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) chk_en_q <= 1'b0;
    else        chk_en_q <= 1'b1;
  end
  always_ff @(posedge clk) begin
    if (chk_en_q) begin
      assert (w_arv == (ao_v && !ao_we && PORT_MODE != `SG_PORT_1R1W))
        else $error("%m: wrapper port-A read-valid disagrees with the completion pipeline");
      assert (w_brv == (bo_v && !bo_we))
        else $error("%m: wrapper port-B read-valid disagrees with the completion pipeline");
      if (PORT_MODE == `SG_PORT_1R1W) begin
        assert (!(mav && !mat && !mawe)) else $error("%m: read presented on the 1R1W write slot");
        assert (!(mbv && mbwe))          else $error("%m: write presented on the 1R1W read slot");
      end
    end
  end
`endif

endmodule

`default_nettype wire
