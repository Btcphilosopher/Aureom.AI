// =============================================================================
// SilicaFlux-HPC Project 33 :: SRAMGRID :: sfx_sg_defs.svh
// Constants of the distributed SRAM grid.  Aureom.AI | SilicaFlux-HPC.
//
// A `define header, not a package, for the same reason as the SRAM Wrapper
// Library's sram_defs.svh: Yosys 0.33 cannot resolve package references in
// module parameter lists, and every synthesizable module here must elaborate
// unaided in Verilator 5.020, Icarus 12 and Yosys 0.33.
//
// Values are part of the public contract (config/schema, scripts/sg_config.py
// emit them): never renumber, only append.
// =============================================================================
`ifndef SFX_SG_DEFS_SVH
`define SFX_SG_DEFS_SVH
`include "sram_defs.svh"

// ------------------------------------------------------------ region kinds
// Informational only (reports, placement grouping).  The RTL treats every
// region the same way; kind never changes behaviour.
`define SG_KIND_SHARED     0   // shared on-chip SRAM, reachable by several clusters
`define SG_KIND_VEC_LOCAL  1   // vector-local scratchpad
`define SG_KIND_TEN_OPND   2   // tensor operand buffer
`define SG_KIND_TEN_ACC    3   // tensor accumulator storage
`define SG_KIND_BOOT       4   // control / boot RAM (write-protectable; NOT a ROM)

// ------------------------------------------------------------ bank memory-port model
// The number of accesses a bank can perform per cycle; it is the limit the
// per-bank arbiter enforces, never exceeded.
//   1RW  : one read OR one write                     (sram_backend_1rw)
//   1R1W : one read AND one write (dedicated ports)  (sram_backend_1r1w)
//   2RW  : two accesses of any kind                  (sram_backend_2rw)
`define SG_PORT_1RW   0
`define SG_PORT_1R1W  1
`define SG_PORT_2RW   2

// ------------------------------------------------------------ address -> bank mapping
// word = (byte_address - region_base) >> log2(DW/8)
// LOW  : bank = word[BW-1:0]                      row = word >> BW
// XOR  : bank = word[BW-1:0] ^ word[2BW-1:BW]     row = word >> BW
// HIGH : bank = word >> RW                        row = word[RW-1:0]
`define SG_MAP_LOW    0
`define SG_MAP_XOR    1
`define SG_MAP_HIGH   2

// ------------------------------------------------------------ arbitration
`define SG_ARB_RR     0     // per-bank round robin (pointer moves past the last winner)
`define SG_ARB_FIXED  1     // per-bank fixed priority, port 0 highest (can starve)

// ------------------------------------------------------------ read-during-write (1R1W banks)
// A read and a write to the same row of the same bank are never issued in the
// same cycle.  WRITE_FIRST: the write issues, the read is deferred one cycle
// and returns the new data.  READ_FIRST: the read issues and returns the old
// data, the write is deferred.  A deferred access that collides again in the
// very next cycle wins (bounded wait); an isolated collision always follows
// the policy.  1RW / 2RW banks serialise colliding accesses in arbitration
// order.
`define SG_RDW_WRITE_FIRST 0
`define SG_RDW_READ_FIRST  1

// ------------------------------------------------------------ integrity
// NONE   : stored width = DW.
// PARITY : one odd-parity bit per byte (9 bits per byte lane); byte writes ok.
// SECDED : per ECC granule G (32 or 64 data bits) an extended Hamming code
//          from RAS Project 26 (sfras_secded_enc/dec): N(G) = G + R + 1
//          stored bits (39 for G=32, 72 for G=64).  Writes are granule-
//          granular: a strobe must be all-ones or all-zeros per granule,
//          anything else is refused with ERR_STROBE (no read-modify-write).
`define SG_ECC_NONE    0
`define SG_ECC_PARITY  1
`define SG_ECC_SECDED  2

// ------------------------------------------------------------ response error codes (3 bits)
// rsp_err = (rsp_err_code != OK).  rsp_rdata = 0 for every error response
// (SFB2 R8).  An errored request never changes memory.  Decode priority:
// UNMAPPED > ACCESS > ALIGN > WPROT > STROBE.
`define SG_ERR_OK        3'd0
`define SG_ERR_UNMAPPED  3'd1   // no region contains the address (never wrapped, no side effect)
`define SG_ERR_ACCESS    3'd2   // region exists but this port is not wired to it
`define SG_ERR_ALIGN     3'd3   // address not aligned to the DW/8-byte word
`define SG_ERR_WPROT     3'd4   // write to a write-protectable region while wp_lock = 1
`define SG_ERR_STROBE    3'd5   // strobe not representable (word-write region / partial ECC granule)
`define SG_ERR_ECC_UE    3'd6   // SECDED uncorrectable error on the read data
`define SG_ERR_PARITY    3'd7   // byte-parity mismatch on the read data

// ------------------------------------------------------------ configuration errors
`ifdef __ICARUS__
  `define SG_CFG_FATAL(msg) initial $fatal(1, msg);
`else
  `define SG_CFG_FATAL(msg) $fatal(1, msg);
`endif

`endif // SFX_SG_DEFS_SVH
