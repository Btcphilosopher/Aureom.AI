// =============================================================================
// SilicaFlux-HPC Project 33 :: SRAMGRID :: sfx_sg_port
// Requester-port front end: request intake (direct or skid buffer), bank
// address decode, response credits and an in-order response (reorder)
// buffer.  Aureom.AI | SilicaFlux-HPC.
//
//   req (valid/ready) -> [skid, SLICE=1] -> head -> sfx_sg_addr_dec
//        head -> bank arbiter of the decoded bank (via the grid) -> h_gnt
//        issue = head leaves the port: granted bank access, or an error
//                request (never touches a bank)
//   every issued request owns one reorder slot (credit) from issue until its
//   response is accepted; bank completions (meta = {port, slot}) fill their
//   slot; the response channel presents slot `head` when filled.
//
// ---------------------------------------------------------------- timing
//   SLICE = 0 : req_ready = issue (combinational from req_valid / req_addr
//               through decode and arbitration; for tightly coupled masters).
//   SLICE = 1 : req_ready = skid buffer empty (a REGISTER: no combinational
//               valid -> ready path, SFB2 rules R3/R4).  The request is
//               decoded from the input when the skid is empty (no added
//               latency) and from the skid otherwise.
//   Issue at edge t (bank access granted, or error request with a free
//   credit).  The bank completes at t + LAT_b (LAT_b = PIPE + 1 + OUT_REG of
//   that bank's region); the slot is filled at that edge; rsp_valid is a
//   register output from cycle t + LAT_b + 1.  Error responses: filled at the
//   issue edge, rsp_valid from cycle t + 1 (still in order behind older
//   requests).  Responses leave strictly in issue (= acceptance) order, so
//   regions with different latencies never reorder a port's responses.
//   Credits: NSLOT outstanding responses per port; a port with all slots in
//   use stops issuing (ev_credit_stall).  A slot is held from the issue edge
//   to the response handshake (LAT_b + 1 cycles) and reusable at the next
//   edge: NSLOT >= LAT_b + 2 sustains one access per cycle into a bank of
//   latency LAT_b with rsp_ready = 1 (measured, docs/07).
//   Reset: drops the skid, every slot and every in-flight response;
//   req_ready = 0 in reset and in the first cycle after it.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfx_sg_defs.svh"
`default_nettype none

module sfx_sg_port #(
  parameter int              NR      = 1,
  parameter int              AW      = 32,
  parameter int              DW      = 64,
  parameter int              TAG_W   = 8,
  parameter int              ECC_G   = 64,
  parameter int              SLICE   = 1,
  parameter int              NSLOT   = 4,          // power of two, 2..16
  parameter int              NC      = 2,          // completion inputs (2 per bank)
  parameter int              BTW     = 2,
  parameter int              RWX     = 10,
  parameter logic [NR*64-1:0] R_BASE  = '0,
  parameter logic [NR*8-1:0]  R_LOG2B = {NR{8'd15}},
  parameter logic [NR*8-1:0]  R_NB    = {NR{8'd4}},
  parameter logic [NR*8-1:0]  R_MAP   = '0,
  parameter logic [NR*8-1:0]  R_ECC   = '0,
  parameter logic [NR*8-1:0]  R_BWE   = {NR{8'd1}},
  parameter logic [NR*8-1:0]  R_WP    = '0,
  parameter logic [NR-1:0]    REACH   = '1,
  localparam int NBY = DW / 8,
  localparam int SLW = (NSLOT > 1) ? $clog2(NSLOT) : 1
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  // ---------------------------------------------------------- requester
  input  wire logic                 req_valid,
  output logic                      req_ready,
  input  wire logic                 req_we,
  input  wire logic [AW-1:0]        req_addr,
  input  wire logic [DW-1:0]        req_wdata,
  input  wire logic [NBY-1:0]       req_wstrb,
  input  wire logic [TAG_W-1:0]     req_tag,
  output logic                      rsp_valid,
  input  wire logic                 rsp_ready,
  output logic      [DW-1:0]        rsp_rdata,
  output logic                      rsp_err,
  output logic      [2:0]           rsp_err_code,
  output logic                      rsp_we,
  output logic                      rsp_ce,           // SECDED corrected a bit in this read
  output logic      [TAG_W-1:0]     rsp_tag,
  // ---------------------------------------------------------- grid side
  input  wire logic                 wp_lock,
  input  wire logic                 block,            // MBIST / init own the banks: no bank issue
  output logic                      h_rq,             // head requests bank h_gbank this cycle
  output logic      [BTW-1:0]       h_gbank,
  output logic      [RWX-1:0]       h_row,
  output logic                      h_we,
  output logic      [DW-1:0]        h_wdata,
  output logic      [NBY-1:0]       h_wstrb,
  output logic      [SLW-1:0]       h_slot,
  input  wire logic                 h_gnt,
  input  wire logic [NC-1:0]        c_v,              // completion k is for this port
  input  wire logic [NC*SLW-1:0]    c_slot,
  input  wire logic [NC*DW-1:0]     c_rdata,
  input  wire logic [NC-1:0]        c_we,
  input  wire logic [NC-1:0]        c_ce,
  input  wire logic [NC-1:0]        c_ue,
  input  wire logic [NC-1:0]        c_perr,
  // ---------------------------------------------------------- events (one-cycle pulses)
  output logic                      ev_accept,
  output logic                      ev_issue,
  output logic                      ev_conflict,      // decodable head with a credit lost bank arbitration
  output logic                      ev_credit_stall,  // head waits for a free reorder slot
  output logic                      ev_block_stall,   // head waits because MBIST / init own the banks
  output logic                      ev_error,         // error request issued
  output logic                      ev_complete,      // response accepted
  output logic      [SLW:0]         outstanding
);

  if (SLICE != 0 && SLICE != 1) begin : g_err_slice_0_or_1
    `SG_CFG_FATAL("sfx_sg_port: SLICE must be 0 or 1")
  end
  if (NSLOT < 2 || NSLOT > 16 || (NSLOT & (NSLOT - 1)) != 0) begin : g_err_nslot_pow2_2_to_16
    `SG_CFG_FATAL("sfx_sg_port: NSLOT must be a power of two between 2 and 16")
  end

  // ============================================================ intake
  localparam int RQW = 1 + AW + DW + NBY + TAG_W;
  logic           hv;
  logic [RQW-1:0] hreq;
  logic           issue;
  logic           run_q;          // 0 in reset and in the first cycle after it: nothing is accepted or issued
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) run_q <= 1'b0;
    else        run_q <= 1'b1;
  end

  if (SLICE != 0) begin : g_skid
    logic           sk_v;
    logic [RQW-1:0] sk_d;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) sk_v <= 1'b0;
      else if (sk_v && issue) sk_v <= 1'b0;
      else if (!sk_v && req_valid && !issue) sk_v <= 1'b1;
    end
    always_ff @(posedge clk) begin
      if (!sk_v && req_valid && !issue) sk_d <= {req_we, req_addr, req_wdata, req_wstrb, req_tag};
    end
    assign req_ready = !sk_v && run_q;
    assign hv        = sk_v || (req_valid && run_q);
    assign hreq      = sk_v ? sk_d : {req_we, req_addr, req_wdata, req_wstrb, req_tag};
  end else begin : g_direct
    assign req_ready = issue;
    assign hv        = req_valid && run_q;
    assign hreq      = {req_we, req_addr, req_wdata, req_wstrb, req_tag};
  end

  logic             hd_we;
  logic [AW-1:0]    hd_addr;
  logic [DW-1:0]    hd_wdata;
  logic [NBY-1:0]   hd_wstrb;
  logic [TAG_W-1:0] hd_tag;
  assign {hd_we, hd_addr, hd_wdata, hd_wstrb, hd_tag} = hreq;

  // ============================================================ decode
  logic        d_ok;
  logic [2:0]  d_err;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [((NR > 1) ? $clog2(NR) : 1)-1:0] d_region;   // reported through events by the grid, unused here
  /* verilator lint_on UNUSEDSIGNAL */
  sfx_sg_addr_dec #(
    .NR(NR), .AW(AW), .DW(DW), .ECC_G(ECC_G), .R_BASE(R_BASE), .R_LOG2B(R_LOG2B), .R_NB(R_NB),
    .R_MAP(R_MAP), .R_ECC(R_ECC), .R_BWE(R_BWE), .R_WP(R_WP), .REACH(REACH), .BTW(BTW), .RWX(RWX)
  ) u_dec (
    .addr(hd_addr), .we(hd_we), .wstrb(hd_wstrb), .wp_lock(wp_lock),
    .ok(d_ok), .err_code(d_err), .region(d_region), .gbank(h_gbank), .row(h_row)
  );

  // ============================================================ reorder buffer
  logic [NSLOT-1:0]  fill_q;               // slot holds a deliverable response
  logic [SLW-1:0]    hd_q, tl_q;           // head (oldest), tail (next to allocate)
  logic [SLW:0]      cnt_q;                // allocated slots
  logic [DW-1:0]     r_data [NSLOT];
  logic [2:0]        r_err  [NSLOT];
  logic              r_we   [NSLOT];
  logic              r_ce   [NSLOT];
  logic [TAG_W-1:0]  r_tag  [NSLOT];

  logic credit;
  assign credit = (cnt_q != (SLW+1)'(NSLOT));

  // head classification
  logic hd_err;
  assign hd_err  = hv && !d_ok;
  assign h_rq    = hv && d_ok && credit && !block;
  assign h_we    = hd_we;
  assign h_wdata = hd_wdata;
  assign h_wstrb = hd_wstrb;
  assign h_slot  = tl_q;
  assign issue   = (h_rq && h_gnt) || (hd_err && credit);

  logic deliver;
  assign deliver = fill_q[hd_q] && rsp_ready;

  // completion -> slot match
  logic [NSLOT-1:0] cfill;
  logic [DW-1:0]    cf_data [NSLOT];
  logic [2:0]       cf_err  [NSLOT];
  logic             cf_ce   [NSLOT];
  always_comb begin
    for (int s = 0; s < NSLOT; s++) begin
      cfill[s] = 1'b0; cf_data[s] = '0; cf_err[s] = `SG_ERR_OK; cf_ce[s] = 1'b0;
      for (int k = 0; k < NC; k++) begin
        if (c_v[k] && c_slot[k*SLW +: SLW] == SLW'(s)) begin
          cfill[s] = 1'b1;
          if (c_ue[k]) begin
            cf_err[s] = `SG_ERR_ECC_UE;  cf_data[s] = '0;
          end else if (c_perr[k]) begin
            cf_err[s] = `SG_ERR_PARITY;  cf_data[s] = '0;
          end else begin
            cf_err[s] = `SG_ERR_OK;      cf_data[s] = c_we[k] ? '0 : c_rdata[k*DW +: DW];
          end
          cf_ce[s] = c_ce[k] && !c_ue[k];
        end
      end
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      fill_q <= '0;
      hd_q   <= '0;
      tl_q   <= '0;
      cnt_q  <= '0;
    end else begin
      for (int s = 0; s < NSLOT; s++) begin
        if (cfill[s]) fill_q[s] <= 1'b1;
      end
      if (issue && hd_err) fill_q[tl_q] <= 1'b1;
      if (deliver) fill_q[hd_q] <= 1'b0;
      if (issue)   tl_q <= tl_q + 1'b1;
      if (deliver) hd_q <= hd_q + 1'b1;
      cnt_q <= cnt_q + (SLW+1)'(issue) - (SLW+1)'(deliver);
    end
  end

  always_ff @(posedge clk) begin
    for (int s = 0; s < NSLOT; s++) begin
      if (cfill[s]) begin
        r_data[s] <= cf_data[s];
        r_err[s]  <= cf_err[s];
        r_ce[s]   <= cf_ce[s];
      end
    end
    if (issue) begin
      r_tag[tl_q] <= hd_tag;
      r_we[tl_q]  <= hd_we;
      if (hd_err) begin
        r_data[tl_q] <= '0;
        r_err[tl_q]  <= d_err;
        r_ce[tl_q]   <= 1'b0;
      end
    end
  end

  assign rsp_valid    = fill_q[hd_q];
  assign rsp_rdata    = r_data[hd_q];
  assign rsp_err_code = r_err[hd_q];
  assign rsp_err      = (r_err[hd_q] != `SG_ERR_OK);
  assign rsp_we       = r_we[hd_q];
  assign rsp_ce       = r_ce[hd_q];
  assign rsp_tag      = r_tag[hd_q];

  // ============================================================ events
  assign ev_accept       = req_valid && req_ready;
  assign ev_issue        = issue;
  assign ev_conflict     = h_rq && !h_gnt;
  assign ev_credit_stall = hv && !credit;
  assign ev_block_stall  = hv && d_ok && credit && block;
  assign ev_error        = issue && hd_err;
  assign ev_complete     = deliver;
  assign outstanding     = cnt_q;

`ifdef SG_ASSERT
  // checks are enabled from the first edge after reset release (no synchronous use of rst_n)
  logic chk_en_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) chk_en_q <= 1'b0;
    else        chk_en_q <= 1'b1;
  end
  always_ff @(posedge clk) begin
    if (chk_en_q) begin
      for (int s = 0; s < NSLOT; s++)
        assert (!(cfill[s] && fill_q[s])) else $error("%m: completion into an already filled slot %0d", s);
      assert (!(issue && hd_err && cfill[tl_q])) else $error("%m: error fill collides with a completion");
      assert (cnt_q <= (SLW+1)'(NSLOT)) else $error("%m: credit counter overflow");
    end
  end
`endif

endmodule

`default_nettype wire
