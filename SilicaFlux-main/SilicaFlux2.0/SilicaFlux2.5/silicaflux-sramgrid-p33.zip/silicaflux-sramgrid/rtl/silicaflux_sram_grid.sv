// =============================================================================
// SilicaFlux-HPC Project 33 :: SRAMGRID :: silicaflux_sram_grid
// Distributed SRAM bank fabric of the SilicaFlux die.  Primary RTL of the
// project.  Aureom.AI | SilicaFlux-HPC.
//
//   NP requester ports (vector clusters, tensor operand / accumulator paths,
//   DMA, control core)          each: req/rsp valid-ready, byte address, tag
//        |
//   sfx_sg_port (per port)    : skid buffer, sfx_sg_addr_dec (logical address
//        |                      -> region / bank / row / error), reorder slots
//        |                      (credits) for in-order responses
//        v
//   sfx_sg_bank_arb (per bank): only the ports wired to the bank's region
//        |                      (P_REACH) compete; grants within the bank's
//        |                      memory-port limit (1RW 1, 1R1W 1R+1W, 2RW 2)
//        v
//   sfx_sg_bank (per bank)    : request pipe (R_PIPE), ECC encode,
//        |                      silicaflux_sram_macro_wrapper (GENERIC / FPGA /
//        |                      real macro), completion pipe, ECC decode
//        v
//   completions routed back to the issuing port's reorder slot
//
// Logical vs physical.  Software sees NR disjoint size-aligned windows
// (regions).  How a region is cut into banks (R_NB, R_MAP), how a bank is
// built from memories (R_IMPL, R_MACRO, tiling inside the wrapper) and where
// those memories sit on the die (scripts/gen_placement.py) are independent
// layers: none of them changes the address map.
//
// Interconnect.  Not a central crossbar: bank b in region r is wired only to
// the ports p with P_REACH[p][r] = 1 (constant; synthesis removes every other
// path).  With per-cluster local regions plus one shared region the number of
// port-bank links is reported by scripts/sg_config.py (docs/04).
//
// ---------------------------------------------------------------- timing
//   Port p, request accepted in cycle t (SLICE = 1: edge t with an empty skid,
//   issue at the same edge when the bank grants; SLICE = 0: accept = issue).
//   Read / write response valid in cycle t_issue + LAT(r) + 1 when the
//   response channel is not stalled, LAT(r) = R_PIPE[r] + 1 + R_OREG[r]
//   (2 cycles for PIPE = 0, OREG = 0).  Error responses: t_issue + 1.
//   Per port, responses are in acceptance order; across ports there is no
//   order except through the banks: a bank performs accesses in grant order,
//   so a read granted at a later edge than a write to the same row (any port)
//   returns the written data.  Same-edge same-row read/write pairs are never
//   co-issued (sfx_sg_bank_arb, RDW policy).
//
// ---------------------------------------------------------------- test / init / reset
//   MBIST bus (TestCore tc_mbist / sramlib sram_mbist_march contract):
//   tst_active hands every bank to the bus (functional issue stops; accepted
//   requests still complete); tst_sel[b] selects bank b; tst_ce / tst_we /
//   tst_addr (row) / tst_wdata (raw stored word: data AND check bits);
//   tst_rdata[b] is the raw word exactly TEST_LAT cycles after a test read
//   (TEST_LAT = max LAT over banks; faster banks are padded).  Rows >= the
//   bank depth are ignored.
//   Init sweep: writes encode(0) (all-zero data with valid check / parity
//   bits) to every row of every bank, one row per bank per cycle, after reset
//   (INIT_ON_RESET), on init_req and when tst_active falls (INIT_AFTER_TEST:
//   MBIST leaves arbitrary check bits).  Functional issue waits (init_busy).
//   Reset (async): drops skid buffers, reorder slots and in-flight accesses;
//   writes already at the macro stay, writes inside a request pipe are lost;
//   arrays are never reset.
//
// ---------------------------------------------------------------- RAS
//   ras_ev_* per region in the RAS Project 26 memory-event format
//   (silicaflux_ras mem_ev_*): valid, ce, ue, poison (always 0: no RMW, no
//   poison storage), org (READ), logical byte address of the word, {pe,s}
//   syndrome, stored-bit index.  One event per region per cycle; a second
//   simultaneous failing read of the region raises ras_ev_lost.
//   PARITY errors are reported as UE (detected, not correctable).
//   No repair: none of the supported macros has spare rows / columns.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfx_sg_defs.svh"
`include "sfras_defs.svh"
`default_nettype none

module silicaflux_sram_grid #(
  parameter int               NP      = 3,                 // requester ports, 1..16
  parameter int               NR      = 1,                 // regions, 1..16
  parameter int               AW      = 32,                // byte-address width
  parameter int               DW      = 64,                // bank word = port data width, power of two 32..512
  parameter int               TAG_W   = 8,
  parameter int               ECC_G   = 64,                // SECDED granule: 32 or 64
  parameter int               NSLOT   = 4,                 // reorder slots (outstanding responses) per port
  parameter int               ARB     = `SG_ARB_RR,
  parameter int               RDW     = `SG_RDW_WRITE_FIRST,
  parameter logic [NR*64-1:0] R_BASE  = '0,
  parameter logic [NR*8-1:0]  R_LOG2B = {NR{8'd15}},
  parameter logic [NR*8-1:0]  R_NB    = {NR{8'd4}},
  parameter logic [NR*8-1:0]  R_PM    = '0,
  parameter logic [NR*8-1:0]  R_MAP   = '0,
  parameter logic [NR*8-1:0]  R_ECC   = '0,
  parameter logic [NR*8-1:0]  R_BWE   = {NR{8'd1}},
  parameter logic [NR*8-1:0]  R_PIPE  = '0,
  parameter logic [NR*8-1:0]  R_OREG  = '0,
  parameter logic [NR*8-1:0]  R_IMPL  = '0,
  parameter logic [NR*16-1:0] R_MACRO = '0,
  parameter logic [NR*8-1:0]  R_WP    = '0,
  parameter logic [NP*NR-1:0] P_REACH = '1,                // bit p*NR + r: port p wired to region r
  parameter logic [NP*8-1:0]  P_SLICE = {NP{8'd1}},
  parameter int               INIT_ON_RESET   = 1,
  parameter int               INIT_AFTER_TEST = 1,
  parameter int               PERF_EN = 1,
  parameter int               CNT_W   = 32,
  // ---------------------------------------------------------- consistency parameters (emitted by scripts/sg_config.py, checked here)
  parameter int               NBT      = 4,                // total banks
  parameter int               RWX      = 10,               // widest bank row address
  parameter int               TSW      = 72,               // widest stored word (MBIST bus width)
  parameter int               TEST_LAT = 2,                // MBIST read latency of the bus
  // ---------------------------------------------------------- derived (never set)
  localparam int NBY  = DW / 8,
  localparam int BTW  = (NBT > 1) ? $clog2(NBT) : 1,
  localparam int PIW  = (NP > 1) ? $clog2(NP) : 1,
  localparam int SLW  = (NSLOT > 1) ? $clog2(NSLOT) : 1,
  localparam int MTW  = PIW + SLW
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // ---------------------------------------------------------- requester ports
  input  wire logic [NP-1:0]          req_valid,
  output logic      [NP-1:0]          req_ready,
  input  wire logic [NP-1:0]          req_we,
  input  wire logic [NP*AW-1:0]       req_addr,
  input  wire logic [NP*DW-1:0]       req_wdata,
  input  wire logic [NP*NBY-1:0]      req_wstrb,
  input  wire logic [NP*TAG_W-1:0]    req_tag,
  output logic      [NP-1:0]          rsp_valid,
  input  wire logic [NP-1:0]          rsp_ready,
  output logic      [NP*DW-1:0]       rsp_rdata,
  output logic      [NP-1:0]          rsp_err,
  output logic      [NP*3-1:0]        rsp_err_code,
  output logic      [NP-1:0]          rsp_we,
  output logic      [NP-1:0]          rsp_ce,
  output logic      [NP*TAG_W-1:0]    rsp_tag,
  // ---------------------------------------------------------- control
  input  wire logic                   wp_lock,             // write-protect R_WP regions (boot RAM after load)
  input  wire logic                   init_req,            // pulse: start an init sweep
  output logic                        init_busy,
  output logic                        init_done,           // high once a sweep completed, until the next starts
  // ---------------------------------------------------------- MBIST bus
  input  wire logic                   tst_active,
  input  wire logic [NBT-1:0]         tst_sel,
  input  wire logic                   tst_ce,
  input  wire logic                   tst_we,
  input  wire logic [RWX-1:0]         tst_addr,
  input  wire logic [TSW-1:0]         tst_wdata,
  output logic      [NBT*TSW-1:0]     tst_rdata,
  // ---------------------------------------------------------- RAS events (per region)
  output logic      [NR-1:0]          ras_ev_valid,
  output logic      [NR-1:0]          ras_ev_ce,
  output logic      [NR-1:0]          ras_ev_ue,
  output logic      [NR-1:0]          ras_ev_poison,
  output logic      [NR*3-1:0]        ras_ev_org,
  output logic      [NR*AW-1:0]       ras_ev_addr,
  output logic      [NR*9-1:0]        ras_ev_syn,
  output logic      [NR*8-1:0]        ras_ev_idx,
  output logic      [NR-1:0]          ras_ev_lost,
  // ---------------------------------------------------------- events (one-cycle pulses)
  output logic      [NP-1:0]          ev_accept,
  output logic      [NP-1:0]          ev_issue,
  output logic      [NP-1:0]          ev_conflict,
  output logic      [NP-1:0]          ev_credit_stall,
  output logic      [NP-1:0]          ev_block_stall,
  output logic      [NP-1:0]          ev_error,
  output logic      [NP-1:0]          ev_complete,
  output logic      [NBT*2-1:0]       ev_bank_ops,         // bank b: accesses this cycle (0..2)
  output logic      [NBT-1:0]         ev_bank_conflict,    // bank b left a requester unserved
  output logic      [NBT-1:0]         ev_rdw_split,
  // ---------------------------------------------------------- performance counters (PERF_EN = 1, else 0)
  input  wire logic                   perf_clear,
  output logic      [CNT_W-1:0]       perf_cycles,
  output logic      [NP*CNT_W-1:0]    perf_issue,
  output logic      [NP*CNT_W-1:0]    perf_conflict,
  output logic      [NP*CNT_W-1:0]    perf_credit_stall,
  output logic      [NP*CNT_W-1:0]    perf_complete,
  output logic      [NBT*CNT_W-1:0]   perf_bank_ops,
  output logic      [NBT*CNT_W-1:0]   perf_bank_conflict,
  output logic      [CNT_W-1:0]       perf_ecc_ce,
  output logic      [CNT_W-1:0]       perf_ecc_ue,
  output logic                        busy
);

`include "sfx_sg_cfg_funcs.svh"

  localparam int OFF = sg_off(DW);

  function automatic int bank_lat(input int b);
    int r;
    r = sg_bank_region(R_NB, b);
    bank_lat = sg_f8(R_PIPE, r) + 1 + sg_f8(R_OREG, r);
  endfunction
  function automatic int max_lat();
    int b;
    max_lat = 1;
    for (b = 0; b < NBT; b++) if (bank_lat(b) > max_lat) max_lat = bank_lat(b);
  endfunction
  function automatic int max_sw();
    int r;
    max_sw = 1;
    for (r = 0; r < NR; r++)
      if (sg_sw(sg_f8(R_ECC, r), DW, ECC_G) > max_sw) max_sw = sg_sw(sg_f8(R_ECC, r), DW, ECC_G);
  endfunction
  function automatic logic regions_overlap();
    int a, b;
    logic [63:0] ea, eb;
    regions_overlap = 1'b0;
    for (a = 0; a < NR; a++) begin
      for (b = a + 1; b < NR; b++) begin
        ea = R_BASE[a*64 +: 64] + (64'd1 << sg_f8(R_LOG2B, a));
        eb = R_BASE[b*64 +: 64] + (64'd1 << sg_f8(R_LOG2B, b));
        if (R_BASE[a*64 +: 64] < eb && R_BASE[b*64 +: 64] < ea) regions_overlap = 1'b1;
      end
    end
  endfunction
  function automatic logic region_field_error();
    int r, nb, l, e;
    region_field_error = 1'b0;
    for (r = 0; r < NR; r++) begin
      nb = sg_f8(R_NB, r);
      l  = sg_f8(R_LOG2B, r);
      e  = sg_f8(R_ECC, r);
      if (nb != 1 && nb != 2 && nb != 4 && nb != 8 && nb != 16)          region_field_error = 1'b1;
      if (l < OFF + sg_bw(R_NB, r) + 1 || l > AW || l > 40)              region_field_error = 1'b1;
      if ((R_BASE[r*64 +: 64] & ((64'd1 << l) - 64'd1)) != 64'd0)         region_field_error = 1'b1;
      if (AW < 64 && (R_BASE[r*64 +: 64] >> AW) != 64'd0)                 region_field_error = 1'b1;
      if (sg_f8(R_PM, r) > 2 || sg_f8(R_MAP, r) > 2 || e > 2)            region_field_error = 1'b1;
      if (sg_f8(R_BWE, r) > 1 || sg_f8(R_OREG, r) > 1 || sg_f8(R_WP, r) > 1) region_field_error = 1'b1;
      if (sg_f8(R_PIPE, r) > 3 || sg_f8(R_IMPL, r) > 2)                   region_field_error = 1'b1;
    end
  endfunction
  function automatic logic region_xor_error();
    int r;
    region_xor_error = 1'b0;
    for (r = 0; r < NR; r++)
      if (sg_f8(R_MAP, r) == `SG_MAP_XOR && sg_rw(R_LOG2B, R_NB, DW, r) < sg_bw(R_NB, r)) region_xor_error = 1'b1;
  endfunction
  function automatic logic region_secded_bwe_error();
    int r;
    region_secded_bwe_error = 1'b0;
    for (r = 0; r < NR; r++)
      if (sg_f8(R_ECC, r) == `SG_ECC_SECDED && sg_f8(R_BWE, r) != 0) region_secded_bwe_error = 1'b1;
  endfunction
  function automatic logic region_asic_error();
    int r;
    region_asic_error = 1'b0;
    for (r = 0; r < NR; r++)
      if (sg_f8(R_IMPL, r) == `SRAM_BACKEND_ASIC && sg_f16(R_MACRO, r) == 0) region_asic_error = 1'b1;
  endfunction
  function automatic logic slice_error();
    int p;
    slice_error = 1'b0;
    for (p = 0; p < NP; p++) if (P_SLICE[p*8 +: 8] > 8'd1) slice_error = 1'b1;
  endfunction

  function automatic logic [NP-1:0] conn_of(input int r);
    int p;
    conn_of = '0;
    for (p = 0; p < NP; p++) conn_of[p] = P_REACH[p*NR + r];
  endfunction
  function automatic int slice_of(input int p);
    slice_of = 0;
    slice_of[7:0] = P_SLICE[p*8 +: 8];
  endfunction

  // ============================================================ configuration checks
  if (NP < 1 || NP > 16) begin : g_err_np_1_to_16
    `SG_CFG_FATAL("silicaflux_sram_grid: NP must be 1..16")
  end
  if (NR < 1 || NR > 16) begin : g_err_nr_1_to_16
    `SG_CFG_FATAL("silicaflux_sram_grid: NR must be 1..16")
  end
  if (DW < 32 || DW > 512 || (DW & (DW - 1)) != 0) begin : g_err_dw_pow2_32_to_512
    `SG_CFG_FATAL("silicaflux_sram_grid: DW must be a power of two between 32 and 512")
  end
  if (AW < 12 || AW > 64) begin : g_err_aw_12_to_64
    `SG_CFG_FATAL("silicaflux_sram_grid: AW must be 12..64")
  end
  if (TAG_W < 1 || TAG_W > 32) begin : g_err_tag_w_1_to_32
    `SG_CFG_FATAL("silicaflux_sram_grid: TAG_W must be 1..32")
  end
  if (ECC_G != 32 && ECC_G != 64) begin : g_err_ecc_g_32_or_64
    `SG_CFG_FATAL("silicaflux_sram_grid: ECC_G must be 32 or 64")
  end
  if (ECC_G > DW) begin : g_err_ecc_g_gt_dw
    `SG_CFG_FATAL("silicaflux_sram_grid: ECC_G must not exceed DW")
  end
  if (NSLOT < 2 || NSLOT > 16 || (NSLOT & (NSLOT - 1)) != 0) begin : g_err_nslot_pow2_2_to_16
    `SG_CFG_FATAL("silicaflux_sram_grid: NSLOT must be a power of two between 2 and 16")
  end
  if (ARB != `SG_ARB_RR && ARB != `SG_ARB_FIXED) begin : g_err_unknown_arb
    `SG_CFG_FATAL("silicaflux_sram_grid: ARB must be 0 (RR) or 1 (FIXED)")
  end
  if (RDW != `SG_RDW_WRITE_FIRST && RDW != `SG_RDW_READ_FIRST) begin : g_err_unknown_rdw
    `SG_CFG_FATAL("silicaflux_sram_grid: RDW must be 0 (WRITE_FIRST) or 1 (READ_FIRST)")
  end
  if (region_field_error()) begin : g_err_region_field_out_of_range
    `SG_CFG_FATAL("silicaflux_sram_grid: a region field is out of range (banks 1/2/4/8/16, size >= 2 rows per bank and <= 2^AW, base aligned, modes in range)")
  end
  if (regions_overlap()) begin : g_err_regions_overlap
    `SG_CFG_FATAL("silicaflux_sram_grid: two regions overlap")
  end
  if (region_xor_error()) begin : g_err_xor_map_needs_rows_ge_banks
    `SG_CFG_FATAL("silicaflux_sram_grid: MAP = XOR needs at least as many row bits as bank bits")
  end
  if (region_secded_bwe_error()) begin : g_err_secded_region_has_byte_we
    `SG_CFG_FATAL("silicaflux_sram_grid: SECDED regions are granule-written (BWE must be 0; byte writes would need read-modify-write)")
  end
  if (region_asic_error()) begin : g_err_asic_region_without_macro
    `SG_CFG_FATAL("silicaflux_sram_grid: IMPL = ASIC needs a macro id (no flip-flop fallback)")
  end
  if (slice_error()) begin : g_err_p_slice_0_or_1
    `SG_CFG_FATAL("silicaflux_sram_grid: P_SLICE entries must be 0 or 1")
  end
  if (NBT != sg_nbt(R_NB)) begin : g_err_nbt_inconsistent
    `SG_CFG_FATAL("silicaflux_sram_grid: NBT must equal the sum of R_NB")
  end
  if (RWX != sg_rwmax(R_LOG2B, R_NB, DW)) begin : g_err_rwx_inconsistent
    `SG_CFG_FATAL("silicaflux_sram_grid: RWX must equal the widest bank row address")
  end
  if (TSW != max_sw()) begin : g_err_tsw_inconsistent
    `SG_CFG_FATAL("silicaflux_sram_grid: TSW must equal the widest stored word")
  end
  if (TEST_LAT != max_lat()) begin : g_err_test_lat_inconsistent
    `SG_CFG_FATAL("silicaflux_sram_grid: TEST_LAT must equal the largest bank latency")
  end
  if (PERF_EN != 0 && (CNT_W < 8 || CNT_W > 64)) begin : g_err_cnt_w_8_to_64
    `SG_CFG_FATAL("silicaflux_sram_grid: CNT_W must be 8..64")
  end

  // ============================================================ init sweep
  logic            init_q, init_done_q, tst_q;
  logic [RWX-1:0]  init_row_q;
  logic            init_start;
  assign init_start = init_req || (INIT_AFTER_TEST != 0 && tst_q && !tst_active);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      init_q      <= (INIT_ON_RESET != 0);
      init_done_q <= 1'b0;
      init_row_q  <= '0;
      tst_q       <= 1'b0;
    end else begin
      tst_q <= tst_active;
      if (tst_active) begin
        init_q <= 1'b0;                        // MBIST owns the banks; a sweep restarts when it ends
      end else if (init_start && !init_q) begin
        init_q      <= 1'b1;
        init_done_q <= 1'b0;
        init_row_q  <= '0;
      end else if (init_q) begin
        if (init_row_q == {RWX{1'b1}}) begin
          init_q      <= 1'b0;
          init_done_q <= 1'b1;
        end
        init_row_q <= init_row_q + 1'b1;
      end
    end
  end
  assign init_busy = init_q;
  assign init_done = init_done_q;

  // Banks are blocked for functional issue while MBIST owns them, during the
  // cycle in which tst_active falls (the post-test init sweep starts at the
  // end of that cycle: without this a request could read raw March patterns -
  // found by tb_sram_grid scenario mbist) and during an init sweep.
  logic blk;
  assign blk = tst_active || tst_q || init_q;

  // ============================================================ ports
  logic [NP-1:0]      h_rq, h_we, h_gnt;
  logic [NP*BTW-1:0]  h_gbank;
  logic [NP*RWX-1:0]  h_row;
  logic [NP*DW-1:0]   h_wdata;
  logic [NP*NBY-1:0]  h_wstrb;
  logic [NP*SLW-1:0]  h_slot;

  // bank completions, flattened k = 2*b + {0: slot A, 1: slot B}
  localparam int NC = 2 * NBT;
  logic [NC-1:0]      c_v, c_we, c_ce, c_ue, c_perr;
  logic [NC*MTW-1:0]  c_meta;
  logic [NC*DW-1:0]   c_rdata;
  logic [NC*SLW-1:0]  c_slot;
  for (genvar k = 0; k < NC; k++) begin : g_cslot
    assign c_slot[k*SLW +: SLW] = c_meta[k*MTW +: SLW];
  end

  logic [NP*(SLW+1)-1:0] outst;

  for (genvar p = 0; p < NP; p++) begin : g_port
    localparam logic [NR-1:0] REACH_P = P_REACH[p*NR +: NR];
    logic [NC-1:0] cv_p;
    for (genvar k = 0; k < NC; k++) begin : g_cv
      localparam int KR = sg_bank_region(R_NB, k / 2);
      if (REACH_P[KR]) begin : g_on
        assign cv_p[k] = c_v[k] && (c_meta[k*MTW + SLW +: PIW] == PIW'(p));
      end else begin : g_off
        assign cv_p[k] = 1'b0;
      end
    end
    sfx_sg_port #(
      .NR(NR), .AW(AW), .DW(DW), .TAG_W(TAG_W), .ECC_G(ECC_G), .SLICE(slice_of(p)), .NSLOT(NSLOT),
      .NC(NC), .BTW(BTW), .RWX(RWX), .R_BASE(R_BASE), .R_LOG2B(R_LOG2B), .R_NB(R_NB), .R_MAP(R_MAP),
      .R_ECC(R_ECC), .R_BWE(R_BWE), .R_WP(R_WP), .REACH(REACH_P)
    ) u_port (
      .clk(clk), .rst_n(rst_n),
      .req_valid(req_valid[p]), .req_ready(req_ready[p]), .req_we(req_we[p]),
      .req_addr(req_addr[p*AW +: AW]), .req_wdata(req_wdata[p*DW +: DW]), .req_wstrb(req_wstrb[p*NBY +: NBY]),
      .req_tag(req_tag[p*TAG_W +: TAG_W]),
      .rsp_valid(rsp_valid[p]), .rsp_ready(rsp_ready[p]), .rsp_rdata(rsp_rdata[p*DW +: DW]),
      .rsp_err(rsp_err[p]), .rsp_err_code(rsp_err_code[p*3 +: 3]), .rsp_we(rsp_we[p]), .rsp_ce(rsp_ce[p]),
      .rsp_tag(rsp_tag[p*TAG_W +: TAG_W]),
      .wp_lock(wp_lock), .block(blk),
      .h_rq(h_rq[p]), .h_gbank(h_gbank[p*BTW +: BTW]), .h_row(h_row[p*RWX +: RWX]), .h_we(h_we[p]),
      .h_wdata(h_wdata[p*DW +: DW]), .h_wstrb(h_wstrb[p*NBY +: NBY]), .h_slot(h_slot[p*SLW +: SLW]),
      .h_gnt(h_gnt[p]),
      .c_v(cv_p), .c_slot(c_slot), .c_rdata(c_rdata), .c_we(c_we), .c_ce(c_ce), .c_ue(c_ue), .c_perr(c_perr),
      .ev_accept(ev_accept[p]), .ev_issue(ev_issue[p]), .ev_conflict(ev_conflict[p]),
      .ev_credit_stall(ev_credit_stall[p]), .ev_block_stall(ev_block_stall[p]), .ev_error(ev_error[p]),
      .ev_complete(ev_complete[p]), .outstanding(outst[p*(SLW+1) +: SLW+1])
    );
  end

  // ============================================================ banks
  logic [NBT*NP-1:0]  gnt_b;               // bank b grants port p: bit b*NP + p
  logic [NBT-1:0]     bev_v, bev_ce, bev_ue, bev_multi;
  logic [NBT*RWX-1:0] bev_row;
  logic [NBT*9-1:0]   bev_syn;
  logic [NBT*8-1:0]   bev_idx;

  for (genvar b = 0; b < NBT; b++) begin : g_bank
    localparam int BR    = sg_bank_region(R_NB, b);
    localparam int BRW   = sg_rw(R_LOG2B, R_NB, DW, BR);
    localparam int BDEP  = 1 << BRW;
    localparam int BPM   = sg_f8(R_PM, BR);
    localparam int BECC  = sg_f8(R_ECC, BR);
    localparam int BSW   = sg_sw(BECC, DW, ECC_G);
    localparam int BLAT  = sg_f8(R_PIPE, BR) + 1 + sg_f8(R_OREG, BR);
    localparam logic [NP-1:0] CONN = conn_of(BR);

    // ---------------------------------------------- requests for this bank
    logic [NP-1:0]     rq;
    logic [NP*RWX-1:0] rq_row;
    for (genvar p = 0; p < NP; p++) begin : g_rq
      if (CONN[p]) begin : g_on
        assign rq[p] = h_rq[p] && (h_gbank[p*BTW +: BTW] == BTW'(b));
      end else begin : g_off
        assign rq[p] = 1'b0;
      end
      assign rq_row[p*RWX +: RWX] = h_row[p*RWX +: RWX];
    end

    logic [NP-1:0]  gnt, lost;
    logic           a_v, b_v, split;
    logic [PIW-1:0] a_sel, b_sel;
    sfx_sg_bank_arb #(
      .NP(NP), .CONN(CONN), .PORT_MODE(BPM), .ARB(ARB), .RDW(RDW), .RW(RWX)
    ) u_arb (
      .clk(clk), .rst_n(rst_n), .rq(rq), .rq_we(h_we), .rq_row(rq_row), .block(blk),
      .gnt(gnt), .a_v(a_v), .a_sel(a_sel), .b_v(b_v), .b_sel(b_sel), .rdw_split(split), .lost(lost)
    );
    assign gnt_b[b*NP +: NP] = gnt;
    assign ev_bank_ops[b*2 +: 2]  = {1'b0, a_v} + {1'b0, b_v};
    assign ev_bank_conflict[b]    = |lost;
    assign ev_rdw_split[b]        = split;

    // ---------------------------------------------- init / test for this bank
    logic          i_v, t_v;
    assign i_v = init_q && ({1'b0, init_row_q} < (RWX+1)'(BDEP)) && !tst_active;
    assign t_v = tst_active && tst_sel[b] && tst_ce && ({1'b0, tst_addr} < (RWX+1)'(BDEP));

    // ---------------------------------------------- the bank
    logic [BSW-1:0] t_rd;
    /* verilator lint_off UNUSEDSIGNAL */
    logic           t_rv;                    // MBIST compares at TEST_LAT; the strobe is informational
    logic [RWX-1:0] ev_row_b;
    /* verilator lint_on UNUSEDSIGNAL */
    logic [7:0]     ev_gran_b;
    sfx_sg_bank #(
      .DW(DW), .DEPTH(BDEP), .PORT_MODE(BPM), .BYTE_WE(sg_f8(R_BWE, BR)), .ECC(BECC), .ECC_G(ECC_G),
      .PIPE(sg_f8(R_PIPE, BR)), .OUT_REG(sg_f8(R_OREG, BR)), .IMPL(sg_f8(R_IMPL, BR)),
      .MACRO(sg_f16(R_MACRO, BR)), .MTW(MTW)
    ) u_bank (
      .clk(clk), .rst_n(rst_n),
      .a_v(a_v), .a_we(h_we[a_sel]), .a_row(BRW'(h_row[a_sel*RWX +: RWX])), .a_wdata(h_wdata[a_sel*DW +: DW]),
      .a_wstrb(h_wstrb[a_sel*NBY +: NBY]), .a_meta({a_sel, h_slot[a_sel*SLW +: SLW]}),
      .b_v(b_v), .b_we(h_we[b_sel]), .b_row(BRW'(h_row[b_sel*RWX +: RWX])), .b_wdata(h_wdata[b_sel*DW +: DW]),
      .b_wstrb(h_wstrb[b_sel*NBY +: NBY]), .b_meta({b_sel, h_slot[b_sel*SLW +: SLW]}),
      .init_v(i_v), .init_row(BRW'(init_row_q)),
      .tst_v(t_v), .tst_we(tst_we), .tst_row(BRW'(tst_addr)), .tst_wdata(tst_wdata[BSW-1:0]),
      .tst_rdata(t_rd), .tst_rvalid(t_rv),
      .ao_v(c_v[2*b]), .ao_we(c_we[2*b]), .ao_meta(c_meta[(2*b)*MTW +: MTW]), .ao_rdata(c_rdata[(2*b)*DW +: DW]),
      .ao_ce(c_ce[2*b]), .ao_ue(c_ue[2*b]), .ao_perr(c_perr[2*b]),
      .bo_v(c_v[2*b+1]), .bo_we(c_we[2*b+1]), .bo_meta(c_meta[(2*b+1)*MTW +: MTW]), .bo_rdata(c_rdata[(2*b+1)*DW +: DW]),
      .bo_ce(c_ce[2*b+1]), .bo_ue(c_ue[2*b+1]), .bo_perr(c_perr[2*b+1]),
      .ev_v(bev_v[b]), .ev_ce(bev_ce[b]), .ev_ue(bev_ue[b]), .ev_row(bev_row[b*RWX +: BRW]),
      .ev_syn(bev_syn[b*9 +: 9]), .ev_idx(bev_idx[b*8 +: 8]), .ev_gran(ev_gran_b), .ev_multi(bev_multi[b])
    );
    if (BRW < RWX) begin : g_rowpad
      assign bev_row[b*RWX + BRW +: RWX - BRW] = '0;
    end
    assign ev_row_b = bev_row[b*RWX +: RWX];
    wire unused_gran = &{1'b0, ev_gran_b};

    // ---------------------------------------------- MBIST read data, padded to TEST_LAT
    logic [BSW-1:0] t_rd_d;
    sfx_sg_delay #(.W(BSW), .N(TEST_LAT - BLAT), .RST(0)) u_tpad (.clk(clk), .rst_n(rst_n), .d(t_rd), .q(t_rd_d));
    assign tst_rdata[b*TSW +: TSW] = TSW'(t_rd_d);
  end

  always_comb begin
    h_gnt = '0;
    for (int b = 0; b < NBT; b++) h_gnt = h_gnt | gnt_b[b*NP +: NP];
  end

  // ============================================================ RAS events per region
  for (genvar r = 0; r < NR; r++) begin : g_ras
    localparam int B0  = sg_bofs(R_NB, r);
    localparam int NBR = sg_f8(R_NB, r);
    localparam int BWR = sg_bw(R_NB, r);
    localparam int RWR = sg_rw(R_LOG2B, R_NB, DW, r);
    localparam int MP  = sg_f8(R_MAP, r);
    always_comb begin
      logic        hit;
      int          cnt;
      logic [63:0] word, lb, rowv;
      hit = 1'b0; cnt = 0; word = '0; lb = '0; rowv = '0;
      ras_ev_valid[r] = 1'b0; ras_ev_ce[r] = 1'b0; ras_ev_ue[r] = 1'b0;
      ras_ev_syn[r*9 +: 9] = '0; ras_ev_idx[r*8 +: 8] = '0; ras_ev_addr[r*AW +: AW] = '0;
      for (int j = NBR - 1; j >= 0; j--) begin
        if (bev_v[B0 + j]) begin
          cnt = cnt + (bev_multi[B0 + j] ? 2 : 1);
          hit = 1'b1;
          lb   = 64'(j);
          rowv = 64'(bev_row[(B0 + j)*RWX +: RWX]);
          ras_ev_ce[r] = bev_ce[B0 + j];
          ras_ev_ue[r] = bev_ue[B0 + j];
          ras_ev_syn[r*9 +: 9] = bev_syn[(B0 + j)*9 +: 9];
          ras_ev_idx[r*8 +: 8] = bev_idx[(B0 + j)*8 +: 8];
        end
      end
      if (MP == `SG_MAP_HIGH)     word = (lb << RWR) | rowv;
      else if (MP == `SG_MAP_XOR) word = (rowv << BWR) | (lb ^ (rowv & ((64'd1 << BWR) - 64'd1)));
      else                        word = (rowv << BWR) | lb;
      ras_ev_valid[r] = hit;
      ras_ev_addr[r*AW +: AW] = AW'(R_BASE[r*64 +: 64] + (word << OFF));
      ras_ev_lost[r] = (cnt > 1);
    end
    assign ras_ev_poison[r]     = 1'b0;
    assign ras_ev_org[r*3 +: 3] = `SFRAS_ORG_READ;
  end

  // ============================================================ performance counters
  logic [CNT_W-1:0] ce_n, ue_n;
  logic [NC-1:0]    c_uep;
  assign c_uep = c_ue | c_perr;
  always_comb begin
    ce_n = '0; ue_n = '0;
    for (int k = 0; k < NC; k++) begin
      ce_n = ce_n + CNT_W'(c_ce[k]);
      ue_n = ue_n + CNT_W'(c_uep[k]);
    end
  end

  if (PERF_EN != 0) begin : g_perf
    logic [CNT_W-1:0] cyc_q, ce_q, ue_q;
    logic [CNT_W-1:0] iss_q [NP];
    logic [CNT_W-1:0] cfl_q [NP];
    logic [CNT_W-1:0] crs_q [NP];
    logic [CNT_W-1:0] cpl_q [NP];
    logic [CNT_W-1:0] bop_q [NBT];
    logic [CNT_W-1:0] bcf_q [NBT];
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        cyc_q <= '0; ce_q <= '0; ue_q <= '0;
        for (int p = 0; p < NP; p++) begin iss_q[p] <= '0; cfl_q[p] <= '0; crs_q[p] <= '0; cpl_q[p] <= '0; end
        for (int b = 0; b < NBT; b++) begin bop_q[b] <= '0; bcf_q[b] <= '0; end
      end else if (perf_clear) begin
        cyc_q <= '0; ce_q <= '0; ue_q <= '0;
        for (int p = 0; p < NP; p++) begin iss_q[p] <= '0; cfl_q[p] <= '0; crs_q[p] <= '0; cpl_q[p] <= '0; end
        for (int b = 0; b < NBT; b++) begin bop_q[b] <= '0; bcf_q[b] <= '0; end
      end else begin
        cyc_q <= cyc_q + 1'b1;
        ce_q  <= ce_q + ce_n;
        ue_q  <= ue_q + ue_n;
        for (int p = 0; p < NP; p++) begin
          iss_q[p] <= iss_q[p] + CNT_W'(ev_issue[p]);
          cfl_q[p] <= cfl_q[p] + CNT_W'(ev_conflict[p]);
          crs_q[p] <= crs_q[p] + CNT_W'(ev_credit_stall[p]);
          cpl_q[p] <= cpl_q[p] + CNT_W'(ev_complete[p]);
        end
        for (int b = 0; b < NBT; b++) begin
          bop_q[b] <= bop_q[b] + CNT_W'(ev_bank_ops[b*2 +: 2]);
          bcf_q[b] <= bcf_q[b] + CNT_W'(ev_bank_conflict[b]);
        end
      end
    end
    assign perf_cycles = cyc_q;
    assign perf_ecc_ce = ce_q;
    assign perf_ecc_ue = ue_q;
    for (genvar p = 0; p < NP; p++) begin : g_pp
      assign perf_issue[p*CNT_W +: CNT_W]        = iss_q[p];
      assign perf_conflict[p*CNT_W +: CNT_W]     = cfl_q[p];
      assign perf_credit_stall[p*CNT_W +: CNT_W] = crs_q[p];
      assign perf_complete[p*CNT_W +: CNT_W]     = cpl_q[p];
    end
    for (genvar b = 0; b < NBT; b++) begin : g_pb
      assign perf_bank_ops[b*CNT_W +: CNT_W]      = bop_q[b];
      assign perf_bank_conflict[b*CNT_W +: CNT_W] = bcf_q[b];
    end
  end else begin : g_noperf
    assign perf_cycles = '0; assign perf_ecc_ce = '0; assign perf_ecc_ue = '0;
    assign perf_issue = '0; assign perf_conflict = '0; assign perf_credit_stall = '0; assign perf_complete = '0;
    assign perf_bank_ops = '0; assign perf_bank_conflict = '0;
    wire unused_perf = &{1'b0, perf_clear, ce_n, ue_n};
  end

  // ============================================================ busy
  assign busy = (outst != '0) || init_q || tst_active || (|req_valid);

endmodule

`default_nettype wire
