# 06 — Verification

Results: `reports/SUMMARY.md` and the per-suite reports (all generated from JSON by `scripts/make_report.py`).

## 1. Testbenches

| Testbench | What it checks |
|---|---|
| `tb/tb_sram_grid.sv` | the whole grid for one configuration: own reference decoder (region / error / bank / row), shadow memory updated at each **issue edge** (`ev_issue`), per-port expected-response FIFOs, backdoor audit of every written word at the predicted bank / row, **issue-blocking contract** (no functional issue while MBIST / init own the banks), **init audit** (after every init sweep, every row of every bank holds zero data), RAS events, MBIST through `sram_mbist_march`, RTL performance counters vs its own counts, X-poisoned SRAM outputs, random power-up content (Verilator `--x-initial unique` with `+verilator+rand+reset+2`; reset asserted as an event at 1 ns) |
| `tb/tb_sg_macro_wrapper.sv` | the macro wrapper: generic reference vs the vendor model of a real macro, identical traffic; read data at exactly LATENCY, `rvalid` every cycle, OUT_REG hold, test port |
| embedded `SG_ASSERT` checks | arbiter (grant ⊆ request, port-model limit, no same-row pair with a write), wrapper (no macro collision, port B unused on 1RW, no functional access in test mode), bank (pipeline vs wrapper read-valid, 1R1W slot use), port (no double fill, credit bound) |

Stimulus uses the testbench's own xorshift generators (stimulus and back-pressure streams separate, every draw in
a fixed statement order) so Verilator and Icarus run identical traffic: cross-simulation runs match cycle for
cycle (`reports/regression.md`).

## 2. Brief §9 → scenario

| Required test | Scenario(s) | How |
|---|---|---|
| Bank mapping | `bank_map` (+ audit in every scenario) | every word of every region written with an address-derived value through a wired port, read back, then read **through the backdoor from the bank / row the reference map predicts**; each bank holds exactly words/banks words |
| Boundaries | `boundary` | first / last word, one past the end, one below, holes, top of the address space, misaligned, unwired ports; no side effect (audit) |
| Aliasing | `bank_map`, `boundary` | unique fill + read-back of all words; out-of-window addresses never alias (UNMAPPED); mutation M03 (window one bit too wide) is killed |
| Byte enables | `byte_en` | random and legal strobes on a small window (many merges per word); partial-granule strobes on SECDED regions refused; word-write regions (`r_wordw`) |
| Conflicting requests | `conflict`, `perf` (`shared_stride`) | every wired port hammers one bank; port-model limits asserted; 1R1W / 2RW dual issue (`r_1r1w_*`, `r_2rw`) |
| Read-during-write policy | `rdw` | same-cycle write + read of one word from two ports; on 1R1W banks the read's value is checked against the policy (`r_1r1w_wf`: new data, `r_1r1w_rf`: old data, `sg_hier` tensor operand banks) |
| DMA access | `dma` | streaming port (most regions) fills and reads back each region with up to `reorder_slots` outstanding requests while every other port runs random traffic |
| Reset | `reset` | asynchronous reset between edges during traffic: `req_ready = 0` in reset, no stale response after it, init sweep (or, `r_noinit`, array content kept and acknowledged writes still readable) |
| Memory test mode | `mbist` | March C- over every bank via the test bus (pass), functional requests presented during the test stall and complete after re-init; stuck-at-0 injected into a stored bit → failing bank, row and March element reported |
| ECC / parity | `ecc` | single / double stored-bit flips (data, check and parity bits): corrected with `rsp_ce`, UE / PARITY errors, RAS CE / UE events with the logical address |
| Write protection | `wprot` | boot RAM writable before `wp_lock`, refused (`ERR_WPROT`, no side effect) after, still readable |
| Random soak | `random`, `smoke` | all ports, all wired regions, ~3 % error requests, back-pressure and gaps |

Configurations: `sg_min4`, `sg_hier` and 13 `sg_min4` variants (`config/regress/`): 1R1W write-first /
read-first, 2RW, parity with byte writes, word-write without ECC, XOR map, HIGH map, 2 request-pipe stages + output
register, no init on reset, fixed priority, direct (slice 0) ports, 32-bit SECDED granules, 128-bit banks with 2
reorder slots.

## 3. Defects found by the verification (fixed)

| Found by | Defect | Fix |
|---|---|---|
| `mbist` scenario, `sg_min4` | in the cycle `tst_active` falls the post-test init sweep had not started yet, so a functional read could issue and read raw March patterns (invalid SECDED codewords → UE) | banks stay blocked through that cycle (`tst_q`); mutation M15 re-introduces it and is killed |
| design review before the regression | a skid-buffer port showed `req_ready = 1` during reset | `run_q`: `req_ready = 0` in reset and the first cycle after it (checked every reset cycle) |
| `rdw` policy check | the 1R1W fairness bit alternated the policy across unrelated collisions | the bit alternates only over back-to-back collisions; an isolated one always follows the policy |
| Icarus lint of an illegal configuration | Icarus (no elaboration-time `$fatal`) tried to tile width-1 placeholder macros for an ASIC flow without a usable macro | the wrapper hands the library a harmless selection in that case; the fatal still fires in every tool |
| testbench (not RTL) | argument evaluation order / case-head re-evaluation consumed random numbers differently in the two simulators; stimulus thread raced the monitor; never-written parity words were expected clean in `r_noinit`; OUT_REG hold checked before the first load; Icarus default timescale made the leaf's `#1` a 1 s delay | fixed in the testbenches (§1) |
| mutation M16 surviving | Verilator ran with zero power-up state (`--x-initial unique` needs `+verilator+rand+reset+2` at run time), so an init sweep that skips a row was invisible; enabling it then showed the testbench never produced a reset *edge* (reset held low from time 0 left reset-domain flops random until the first clock) | random power-up enabled for every Verilator run, reset asserted at 1 ns, init audit added — M16 is killed by the audit |
| mutation M15 surviving in one run | the post-MBIST window bug was caught only indirectly (a read there is "don't care" because MBIST left the shadow undefined; a write there is later overwritten by the init sweep) | direct contract check in the monitor: no error-free request may issue while MBIST owns the banks, in the cycle it releases them, or during an init sweep — M15 is killed by it |
| cross-simulation (2 of 16 not cycle-identical) | an RNG call inside an assignment target's index (`m[lane*9 + rnd(9)]`) is evaluated differently by the two simulators; `wp_lock` set at a falling edge raced the driver | draws moved into variables; `wp_lock` changed 1 ns after the falling edge |

## 4. Mutation testing

`scripts/run_mutants.py`: 20 one-line mutations of the new RTL (decoder, arbiter, port, bank, grid, wrapper), each
rebuilt and run through the scenarios most likely to expose it — `reports/mutation.md`. One first-draft mutant
(granule mask taken from strobe byte `4g + 1` instead of `4g`) was **equivalent** — the decoder only admits
granule-whole strobes, so both bytes are always equal — and was replaced by a granule-swap mutant.

## 5. Other suites

`reports/wrapper.md` (real-macro equivalence), `reports/lint.md` (warning-free legal configurations; illegal
configurations refused by Verilator, Icarus, Yosys and the generator), `reports/synth.md`,
`reports/physical.md`, `reports/connectivity_*.md`.
