# 01 — Architecture

## 1. Layers: logical → bank → physical memory → placement

```
 requesters (vector clusters, tensor operand / accumulator paths, DMA, control core)
     │  byte address, wdata, wstrb, tag            (one port each, SFB2-compatible with slice = 1)
     ▼
 sfx_sg_port ── skid buffer ── sfx_sg_addr_dec ── reorder slots (credits) ── in-order responses
     │  (region, global bank, row) or an error code
     ▼
 sfx_sg_bank_arb  one per bank, only the ports wired to that bank's region compete
     │  ≤ 1 grant (1RW), 1 read + 1 write (1R1W), ≤ 2 (2RW); never a same-row pair with a write
     ▼
 sfx_sg_bank      request pipe (R_PIPE) ─ encode (none / parity / SECDED) ─ macro wrapper ─ completion pipe ─ decode
     │
     ▼
 silicaflux_sram_macro_wrapper   the physical boundary: GENERIC / FPGA inference, or real macros tiled NC × NR
     │
     ▼
 placement (scripts/gen_placement.py)   macro instances of the synthesized netlist → die coordinates
```

The software-visible map is a set of `NR` disjoint, size-aligned **regions** (`config/*.json`). Each layer below it
is independent of the map: the number of banks and the interleave (`banks`, `map`) decide which bank holds a word;
the stored width (integrity), the macro type and its tiling decide how a bank is built; the placement decides where
the macros sit. Changing any of them never moves an address (checked by the bank-map audit, docs/06 §2).

## 2. Hierarchy and stable names

`silicaflux_sram_grid` → `g_port[p].u_port` (`sfx_sg_port`) and `g_bank[b]` → `u_arb`, `u_bank` → `u_mw`
(`silicaflux_sram_macro_wrapper`) → `g_mem.u_mem` (SRAM library backend). Global bank index `b` counts the regions'
banks in configuration order. The synthesized netlist keeps these names (Yosys adds `genblkN` levels for
else-if generate chains); placement and connectivity read the instance names from the netlist, never from a
template (`reports/synth/<cfg>_asic/macro_instances.json`).

## 3. Interconnect: a sparse, region-local crossbar

Bank `b` of region `r` is wired only to ports `p` with `P_REACH[p][r] = 1` (constant at elaboration; synthesis
removes every other path, `sfx_sg_bank_arb.CONN`). Vector clusters reach their own scratchpad plus the shared
region, the tensor port reaches operand / accumulator / shared, DMA reaches everything, the control core reaches
boot RAM and shared. For `sg_hier` that is **70 port–bank links instead of 115** for a full crossbar; the shared
region is the only many-master hot spot and is the region whose placement matters most (docs/05).
A central crossbar would only be justified if every cluster needed every bank at full rate; the traffic model
(`config/floorplan/fp_hier.json`, an assumption) puts 80 % of vector traffic in the local scratchpad.

Each port issues at most one request per cycle; different ports proceed in parallel whenever they address
different banks, and a dual-port bank serves two ports at once. Nothing exceeds the bank's memory-port model.

## 4. Timing (cycle t = the period ending with rising edge t)

| Event | Cycle |
|---|---|
| request presented, `slice = 1`, skid empty | t (decoded combinationally from the input) |
| accepted (`req_valid && req_ready`) | edge t (`slice = 1`: into the skid if not issued at once) |
| issue (bank grant, or error request with a free credit) | edge t if granted, else a later edge |
| macro access | edge t + `R_PIPE` |
| bank completion (read data decoded, write acknowledged) | cycle t + LAT, LAT = `R_PIPE` + 1 + `R_OREG` |
| reorder slot filled | edge t + LAT |
| `rsp_valid` (register output) | cycle t + LAT + 1 (2 cycles for PIPE = 0, OREG = 0) |
| error response | cycle t + 1 (still in order) |

Measured: read latency min 2 cycles (`sg_min4`), 4 for the pipelined shared region of `sg_hier`
(`reports/performance.md`). A reorder slot is held from issue to the response handshake, so `NSLOT` ≥ LAT + 2
sustains one access per cycle per port (measured; `sg_hier`'s shared region would need 5, it has 4 — docs/07).

## 5. Ordering and read-during-write

* Per port: exactly one response per request, in acceptance order, carrying the request's tag (reorder slots;
  regions of different latency never reorder a port's responses).
* Per bank: accesses are performed in grant order — every access to a bank goes through the same request pipe.
  A read granted at a later edge than a write to the same row (any port) returns the written data.
* Same edge, same row, a write involved: never co-issued. **1R1W** banks pick the read and the write channels
  independently and split a colliding pair by the `read_during_write` policy: `write_first` (default — the read is
  deferred one cycle and returns the new data) or `read_first` (the read returns the old data, the write waits).
  A deferred access that collides again in the very next cycle wins (bounded wait). **1RW / 2RW** banks serialise
  colliding accesses in round-robin order.
* The physical macro never sees a same-address collision (SKY130 / IHP 2P define none): asserted in
  `silicaflux_sram_macro_wrapper` and `sfx_sg_bank_arb` under `SG_ASSERT`.

## 6. Arbitration

Per bank, per channel round robin (pointer past the last winner) or fixed priority (port 0 highest). A request
is eligible only when it decodes without error, its port has a free reorder slot and the banks are not owned by
MBIST / init. Losing arbitration (`ev_conflict`), waiting for a credit (`ev_credit_stall`) and waiting for test /
init (`ev_block_stall`) are separate events and counters.

## 7. Reset, initialisation, test

* Reset (asynchronous): skid buffers, reorder slots, pipelines and arbiter state are cleared; `req_ready = 0` in
  reset and the first cycle after it. Arrays are never reset; a write that already reached the macro stays,
  a write still inside a request pipe is lost (it was never acknowledged).
* Init sweep: `encode(0)` (all-zero data with valid parity / check bits) to every row of every bank, one row per
  bank per cycle: after reset (`init_on_reset`), on `init_req`, and when MBIST releases the banks
  (`init_after_test`). Functional issue waits (`ev_block_stall`). Without it, SECDED words decode as UE (the RAS
  default check-bit inversion makes the all-zero word uncorrectable) and parity words fail — never silent garbage.
* MBIST: docs/04.

## 8. Boot RAM

A `boot` region is RAM, not ROM: ASIC SRAM has no defined power-up content. It is loaded (DMA / control core)
and then write-protected by `wp_lock`; writes are refused with `ERR_WPROT` and no side effect, reads continue.
A mask ROM is a different macro class and is out of scope.
