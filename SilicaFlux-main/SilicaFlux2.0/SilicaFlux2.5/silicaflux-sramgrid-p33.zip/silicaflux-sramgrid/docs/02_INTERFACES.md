# 02 — Interfaces

## 1. `silicaflux_sram_grid` — requester ports (per port p, packed `[p*W +: W]`)

| Signal | Dir | Width | Meaning |
|---|---|---|---|
| `req_valid / req_ready` | in / out | 1 | handshake; with `slice = 1` `req_ready` is a register (SFB2 R3/R4); hold `req_*` stable until accepted |
| `req_we` | in | 1 | 1 write, 0 read |
| `req_addr` | in | AW | byte address; must be DW/8-aligned (else `ERR_ALIGN`) |
| `req_wdata / req_wstrb` | in | DW / DW/8 | little-endian lanes; all-zero strobe = acknowledged no-op |
| `req_tag` | in | TAG_W | echoed on the response |
| `rsp_valid / rsp_ready` | out / in | 1 | in acceptance order; `rsp_*` are register outputs, stable while not accepted |
| `rsp_rdata` | out | DW | read data; 0 for writes and every error |
| `rsp_err / rsp_err_code` | out | 1 / 3 | `SG_ERR_*` (below); `rsp_err = (code != OK)` |
| `rsp_we` | out | 1 | the response answers a write |
| `rsp_ce` | out | 1 | SECDED corrected a bit in this read (data is correct) |
| `rsp_tag` | out | TAG_W | request tag |

Error codes (decode priority UNMAPPED > ACCESS > ALIGN > WPROT > STROBE; an errored request never changes memory):

| Code | Name | Cause |
|---|---|---|
| 0 | OK | |
| 1 | UNMAPPED | no region contains the address (never wrapped) |
| 2 | ACCESS | the region exists but this port is not wired to it |
| 3 | ALIGN | not DW/8-aligned |
| 4 | WPROT | write to a write-protectable region while `wp_lock = 1` |
| 5 | STROBE | partial ECC granule (SECDED region) or partial word (word-write region) |
| 6 | ECC_UE | SECDED uncorrectable (double / invalid syndrome) |
| 7 | PARITY | byte-parity mismatch |

SFB2 compatibility: request / response field names map 1:1 (`write`→`we`, `error`→`err`); the grid adds tags and
allows up to `reorder_slots` outstanding requests per port (SFB2 R6 limits a crossbar port to one — a bridge
keeps that limit, the grid does not need it).

## 2. Control, test, RAS, events

| Group | Signals | Meaning |
|---|---|---|
| control | `wp_lock`, `init_req` → `init_busy`, `init_done` | write protection; init sweep (docs/01 §7) |
| MBIST bus | `tst_active`, `tst_sel[NBT]`, `tst_ce`, `tst_we`, `tst_addr[RWX]`, `tst_wdata[TSW]` → `tst_rdata[NBT*TSW]` | TestCore / sramlib collar bus over **raw stored words** (check bits included); read data valid exactly `TEST_LAT` cycles after a test read (all banks padded to the slowest); rows ≥ the bank depth ignored |
| RAS (per region) | `ras_ev_valid, _ce, _ue, _poison, _org[3], _addr[AW], _syn[9], _idx[8], _lost` | RAS P26 `mem_ev_*` format: one event per region per cycle, logical byte address of the failing word; `_lost` = a second simultaneous failing read was not reported; `poison` is always 0 (no RMW, no poison storage); PARITY reports as UE |
| events (pulses) | `ev_accept / issue / conflict / credit_stall / block_stall / error / complete[NP]`, `ev_bank_ops[NBT*2]`, `ev_bank_conflict[NBT]`, `ev_rdw_split[NBT]` | performance and debug |
| counters (`PERF_EN`) | `perf_cycles`, per port `perf_issue / conflict / credit_stall / complete`, per bank `perf_bank_ops / bank_conflict`, `perf_ecc_ce / ue`; `perf_clear` | the testbench checks `perf_bank_ops` against its own count every run |

## 3. `silicaflux_sram_macro_wrapper`

Parameters: `WIDTH` (stored word incl. check bits), `DEPTH`, `MASK_WIDTH` (lanes; lane = WIDTH/MASK_WIDTH bits),
`PORT_MODE` (1RW / 1R1W / 2RW), `IMPL` (GENERIC / FPGA / ASIC), `MACRO` (catalogue id), `OUT_REG`, `TEST_EN`.

| Port | Signals | Semantics |
|---|---|---|
| clock / reset | `clk`, `rst_n` | `rst_n` clears only the read-valid pipeline; the array is never reset |
| port A | `a_ce, a_we, a_wmask, a_addr, a_wdata → a_rdata, a_rvalid` | 1RW: the port; 1R1W: the **write** port; 2RW: port a |
| port B | `b_ce, b_we, b_wmask, b_addr, b_wdata → b_rdata, b_rvalid` | 1R1W: the **read** port; 2RW: port b; 1RW: unused |
| test | `tst_mode, tst_ce, tst_we, tst_addr, tst_wdata → tst_rdata, tst_rvalid` | raw access, all lanes; functional ce ignored while `tst_mode = 1` |

Timing (edge t ends cycle t): inputs sampled at edge t; a write updates the masked lanes at edge t; read data is
valid in cycle t + LATENCY exactly, flagged by `x_rvalid`, LATENCY = 1 (every catalogue macro) + `OUT_REG`.
`OUT_REG = 0`: the macro output itself, **not held** (SKY130 drives X one hold time after the next edge).
`OUT_REG = 1`: a register loaded in read-return cycles and held until the next return. Same-address cross-port
access with a write is outside the contract (asserted). IHP `*_BIST_*` pins are tied off by the library leaf
(`BIST_EN = 0`, `DLY = 1`); none of the macros has sleep, retention or repair pins. Verified against the vendors'
own models: `reports/wrapper.md`.

## 4. `sfx_sg_addr_dec`

Combinational: `addr, we, wstrb, wp_lock` → `ok, err_code, region, gbank, row`. Maps LOW / XOR / HIGH (docs/03).
One instance per port, so decode never serialises ports.
