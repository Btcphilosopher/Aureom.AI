# 00 — Repository audit

Source: `btcphilosopher/Aureom.AI`, `SilicaFlux-main/` (archives under `SilicaFlux2.0/SilicaFlux2.5/` and the top
level). Every archive was extracted read-only into a scratch directory; nothing in the repository was modified.

## 1. What exists

| Asked for | Found | Where (archive → path) | Used here |
|---|---|---|---|
| SRAM Wrapper Library | `silicaflux-sramlib` (Project 01): raw backends `sram_backend_{1rw,1r1w,2rw}` over GENERIC / FPGA / ASIC; `sram_asic_array` tiles real macros; MBIST controller `sram_mbist_march`, adapter; 37 macro manifests (34 real open-PDK + 3 commercial placeholders) with pinned-commit provenance and SHA-256 per file; `fetch_open_macros.sh` | `SilicaFlux2.5/silicaflux-sramlib.zip` | **vendored unmodified** (`third_party/silicaflux-sramlib/`): every bank memory, the MBIST controller in the testbench, the macro catalogue |
| `hpc_scratchpad.sv` | HPC Module 04: banked scratchpad, per-bank arbiter honouring 1RW/1R1W/2RW, LOW/XOR/HIGH maps, byte parity, error codes; **no MBIST test port, SECDED only reserved** (`HPC_SPM_ECC_SECDED` rejected) | `silicaflux-hpc-m04-scratchpad.zip`, vendored by M06–M08, TC07/08, P28–P32 | design reference (maps, port models, error codes); not instantiated (no test port / SECDED; third-party code is never edited) |
| Tensor operand buffers | `tensor_operand_buffer` (TC03): A 4 banks, B 2 banks, 2 sets, 1R1W `tob_bank` (32 b × 256) on sramlib; `tensor_acc_storage` (TC04) is a plain `logic mem[]` (no wrapper); `tensor_output_buffer` (TC07) on `hpc_scratchpad`; TC08 `silicaflux_tensor_unit`: `MEM_BACKEND` must be GENERIC/FPGA — *"ASIC needs SRAM macros, not wired here"* | `silicaflux-tensorcore0{3,4,7,8}` | motivates the `ten_operand` (1R1W) and `ten_acc` (2RW, SECDED) region kinds |
| Existing memory maps | P31 DieTop `docs/MEMORY_MAP.md`: BOOTROM `0x0` 8 KiB, IMEM `0x1_0000`, DMEM `0x2_0000`, **SHARED_SRAM `0x2000_0000`** (1 / 4 MiB in a 64 MiB window), **VEC_SPM i `0x3000_0000 + i·1 MiB`** (64 KiB), EXTMEM `0x3800_0000`, die registers `0x3E00_0000`; MemoryCore map (LMEM `0x0800_0000`, SRAM `0x1000_0000` 8 banks × 8192 × 36 b, …) | `silicaflux-dietop-p31`, `silicaflux-memorycore1` | `sg_min4` / `sg_hier` windows follow P31 (shared at `0x2000_0000`, vector-local at `0x3000_0000 + i·1 MiB`); tensor windows at `0x3400_0000` are new (P31 has none) |
| Bus protocol | DataFabric SFB2: `req_valid/ready/write/addr/wdata/wstrb`, `rsp_valid/ready/rdata/error`; R3/R4 no valid→ready combinational path; R5/R12 one in-order response per request; R7 write response after the write; R8 error → `rdata = 0`, no side effect | `silicaflux-datafabric/docs/datafabric/PROTOCOL.md` | grid ports are SFB2-compatible with `slice = 1` (registered `req_ready`), plus tags and multiple outstanding requests |
| FPGA RAM inference | sramlib `backends/fpga/sram_fpga_*` (`ram_style="block"`); MemoryFlow v2 `sf_sram_*_inferred.sv`; `memory_cache_repo` `sp_ram/dp_ram` | sramlib, MemoryFlow, memory_cache_repo | sramlib FPGA backend (`flow = fpga`): Yosys `synth_xilinx` infers 8 RAMB36 for `sg_min4` |
| ASIC memory macro files | **no LEF / Liberty / GDS of any SRAM macro is in the repository.** Manifests record the public sources and hashes; FloorplanLab references IHP LEFs under an absent `/opt/eda/...` path; TestCore P07 vendors the SKY130 standard-cell LEF / Liberty only | — | fetched at the **pinned commits** by the library's own script (`scripts/fetch_macros.sh`), **137/137 file hashes match the manifests**; parsed into `physical/abstracts/` |
| OpenROAD | TimingLab and TestCore ran OpenROAD 2.0-12381 (std-cell only); TimingFlow runs `rtl_macro_placer`; **FloorplanLab ran OpenROAD-flow-scripts with real IHP SRAM LEFs** (12 macros, `FLP-MACRO … FIRM`), placing them with OpenDB `setOrient`/`setLocation`/`FIRM`, halo 20 µm, channel 40 µm, R0/MX/MY/R180 | `silicaflux-timinglab`, `-timingflow`, `-testcore-p07`, `-floorplanlab` | same OpenDB call sequence, the same halo / channel defaults, a check script for OpenROAD (not run here, see docs/05 §7) |
| FloorplanLab | pydantic floorplan model (die/core, halo, channel, arrangements), validator (`MACRO_OVERLAP`, `MACRO_SPACING`, `HALO_OUTSIDE_CORE`, pin-escape channel); **no placement blockages**; vector/tensor groups are annotations, not outlines | `silicaflux-floorplanlab` | rules re-implemented independently and extended with blockages, logic-block keep-outs, site/row grid, pin-edge orientation, Tcl/DEF consistency |
| RAS | RAS P26: `sfras_secded_enc/dec` (extended Hamming, configurable K, default check-bit inversion so an all-zero word is UE), `sfras_ecc_sram` (RMW, scrub, poison, init, MBIST port), `silicaflux_ras` memory-event inputs `mem_ev_{valid,ce,ue,poison,org,addr,syn,idx}` | `silicaflux-ras-project26` | **encoder / decoder vendored unmodified**; grid RAS outputs use the `mem_ev_*` format |
| MBIST | sramlib `sram_mbist_march` (March C- / MATS+, per-target depth and width, first-failure capture) on the TestCore collar bus `tst_active/sel/ce/we/addr/wdata → rdata` | sramlib, TestCore | grid exposes that bus over raw stored words (check bits included); the testbench drives it with the unmodified controller |

## 2. Gaps this project closes

* No banked memory in the repository has **both** an MBIST test port and SECDED; `hpc_scratchpad` has neither,
  `sfras_ecc_sram` is single-bank.
* No component maps one logical address space onto **several** independently banked regions with per-region port
  models, latencies and integrity.
* No SRAM macro abstract had been parsed for placement inside these archives; FloorplanLab's numbers depend on an
  external `/opt/eda` tree.
* TC08's tensor unit cannot use ASIC macros; the grid provides tensor-operand and accumulator regions that can.

## 3. Real macros available (fetched, hash-verified, Apache-2.0)

| PDK | Macros | Topology | Mask | Used by default |
|---|---|---|---|---|
| IHP SG13G2 (130 nm BiCMOS) | 18 × `RM_IHPSG13_1P_*_bm_bist`, 9 × `RM_IHPSG13_2P_*_bm_bist` (8–64 b, 64–4096 words) | 1RW, true 2RW | bit | **yes** (`technology: ihp_sg13g2`) |
| SKY130 (OpenRAM) | 3 × `sky130_sram_*_1rw1r_*` | 1RW + 1R | byte | selectable |
| GF180MCU | 4 × `gf180mcu_fd_ip_sram__sram*x8m8wm1` | 1RW | bit | selectable |
| Commercial 130/65/28 nm | placeholders, every field `null` | — | — | **refused** at elaboration and by the config tool |

LEF, Verilog functional models and datasheets are available for all real macros; Liberty files are listed in the
manifests but only two were fetched (not used for timing here).
