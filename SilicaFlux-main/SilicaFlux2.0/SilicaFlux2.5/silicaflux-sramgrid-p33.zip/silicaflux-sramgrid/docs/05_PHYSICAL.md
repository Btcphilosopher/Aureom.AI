# 05 — SRAM macro placement

## 1. What is real and what is assumed

| Input | Status |
|---|---|
| macro outlines, pin rectangles and edges, symmetry, obstructions, power pins | **real** — vendor LEF at pinned commits (`physical/abstracts/`) |
| site (`CoreSite` 0.48 × 3.78 µm), manufacturing grid 0.005 µm, DBU 1000, routing layers | **real** — IHP SG13G2 tech / stdcell LEF |
| macro instance names | **real** — the synthesized ASIC netlist (`reports/synth/<cfg>_asic/macro_instances.json`) |
| halo 20 µm, channel 40 µm, pin-escape depth 40 µm | the FloorplanLab defaults (which ran OpenROAD with the same IHP macros) |
| die size, core margin, logic-block outlines (vector / tensor / NoC / control), placement blockages | **planning assumptions** (`config/floorplan/fp_*.json`, labelled in every output). No mapped netlist of the clusters with these outlines exists; P31 states it has no die size |
| traffic mix per port, 1.5 mm per clock | **assumptions**, used only to weight distance estimates and suggest pipeline stages |

## 2. Generator — `scripts/gen_placement.py`

Configuration-driven: memory configuration → derived mapping (bank → macro tiles); netlist → instance names;
floorplan file → die, rules, blocks. For each strategy, macros are ordered (tensor accumulator, tensor operand,
vector-local, shared, boot; bank by bank, tile by tile) and placed greedily at the **lowest-cost legal**
candidate position (abutment corners of everything already placed plus a uniform grid over the core), snapped to
the site / row grid from the core origin.

| Strategy | Anchor (per region kind) |
|---|---|
| `adjacent_vector` | shared SRAM against the vector cluster; every local region against the cluster it serves |
| `around_tensor` | shared SRAM and tensor regions in a ring around the tensor cluster (cost = distance to its centre) |
| `central_shared` | shared SRAM packed around the core centre (where the NoC is); local regions against their cluster |
| `perimeter` | every bank hugging a core edge, near its cluster; pins turned toward the core interior |

Cost adds a strong attraction to the macros already placed for the same bank (a bank's 3 column macros share
address / control) and a weaker one to the region. Orientation: R0 (pins on the bottom edge) or MX (pins on the
top edge) so the pins face the anchor; MY / R180 add no pin-side benefit and R90 would put the vertical Metal2 pins
on a side edge (allowed set configurable, intersected with the LEF `SYMMETRY`).

Legality while placing: macro + halo inside the core; ≥ channel to every placed macro; macro + halo clear of logic
blocks and blockages; the pin edge's escape strip inside the core and clear of macros and blockages.

Outputs per strategy (`physical/placement/<cfg>/<strategy>/`):

* `macro_place.tcl` — OpenROAD / OpenDB: `findInst` by netlist name (error if missing or the master differs),
  `setOrient`, `setLocation` (lower-left of the oriented box, DBU), `setPlacementStatus FIRM`; halos and floorplan
  blockages as `odb::dbBlockage_create` (FloorplanLab used the same calls)
* `macro_place.def` — DEF 5.8: DIEAREA, COMPONENTS `+ FIXED … + HALO`, BLOCKAGES PLACEMENT
* `placement.json`, `wire.json` (estimates), `placement.svg` (pins drawn as a thick edge)
* `check.json`, `mock_odb.json` (below)

## 3. Independent checker — `scripts/check_placement.py`

Does not import the generator. Re-derives geometry from the emitted Tcl and DEF and the LEF abstracts:

| Rule | Check |
|---|---|
| C1 | every netlist macro placed exactly once (Tcl and DEF), nothing else |
| C2 | master in Tcl = netlist = DEF |
| C3 | orientation ∈ floorplan set ∩ LEF-legal set |
| C4 | x on the 0.48 µm site grid, y on the 3.78 µm row grid (from the core origin); on the 0.005 µm / DBU grid |
| C5 | macro + halo inside the core |
| C6 | every pair ≥ channel apart (so no overlap) |
| C7 | macro + halo clear of every blockage and logic block |
| C8 | signal-pin edge (from the LEF pin rectangles, transformed by the orientation) has its escape strip inside the core and clear of macros / blockages |
| C9 | Tcl = DEF; DEF components FIXED with the halo |
| C10 | the Tcl executed in `tclsh` against a mock OpenDB (`physical/mock_odb.tcl`) placed the same instances at the same DBU coordinates, FIRM, with no error |

**Self-test**: 15 mutations of a clean placement (overlap, 10 µm channel, outside the core, into a blockage, into
a logic block, +0.24 µm and +0.001 µm off-grid, R90, MY, missing / duplicate / unknown instance, wrong master,
Tcl ≠ DEF, pins facing the core edge) — **15/15 caught** for both configurations.

## 4. Results

All 8 placements (2 configurations × 4 strategies) clean, mock OpenDB executed with 0 errors
(`reports/physical.md`). Minimum macro spacing 40.32 µm (`sg_min4`), 40.27 µm (`sg_hier`) against the 40 µm
channel.

| Config | Strategy | Weighted distance (est.) | Sparse-crossbar wiring (est.) | Farthest port → region, suggested `req_pipe` at 1.5 mm/cycle |
|---|---|---|---|---|
| `sg_min4` (12 macros) | adjacent_vector | 1.23 mm | 2 594 mm·bit | shared 2.21 mm → 1 |
| | around_tensor | 1.22 mm | 2 574 mm·bit | shared 2.49 mm → 1 |
| | **central_shared** | **1.17 mm** | **2 473 mm·bit** | shared 2.16 mm → 1 |
| | perimeter | 1.56 mm | 3 287 mm·bit | shared 2.76 mm → 1 |
| `sg_hier` (69 macros) | adjacent_vector | 1.79 mm | 35 276 mm·bit | shared 6.88 mm → 4 |
| | around_tensor | 1.89 mm | 37 810 mm·bit | shared 7.57 mm → 5 |
| | **central_shared** | **1.65 mm** | **31 734 mm·bit** | shared 5.63 mm → 3 |
| | perimeter | 3.22 mm | 46 191 mm·bit | shared 7.66 mm → 5 |

Reading the numbers:

* With a single shared region every cluster uses, a **central** shared array minimises both the traffic-weighted
  distance and total crossbar wiring; perimeter placement is worst (+33 % / +40 %).
* For `sg_hier`, local regions next to their clusters keep the dominant (80 %) vector traffic short; the shared
  region's farthest link is the DMA / control path across the die. The "farthest" column is set by the DMA port
  (from the NoC block) reaching every bank — the DMA path, not the compute clusters, is what needs pipelining or a
  route through the NoC. `around_tensor` shortens tensor operand links (2.26 mm vs 3.78 mm) at the cost of the
  shared region.
* `sg_hier` configures `req_pipe = 1` on the shared region; the estimate suggests 3 stages for its farthest link
  in the best placement. The estimate is assumption-driven (1.5 mm/cycle); the decision belongs to STA after
  routing, and `req_pipe` is the knob (0–3) that the RTL already provides.

These are **distance estimates, not extracted delay**: Manhattan distance between an assumed block centre and the
bank's pin centroid; no global routing, no RC extraction, no STA, no repeater insertion.

## 5. FloorplanLab comparison

FloorplanLab placed 12 IHP SRAM macros for SilicaFlux-V with real OpenROAD runs (die 3.49 × 2.28 mm for its
`C_sram_near_compute` run). This project reuses its halo / channel rules and OpenDB call sequence, adds placement
blockages, logic-block keep-outs, row / site snapping, pin-edge orientation, Tcl / DEF consistency and an
independent checker with self-test, and drives everything from the memory configuration and the synthesized
netlist of the SRAM grid.

## 6. Scaling gate (the brief's "start with four banks")

`scripts/run_physical.py` places `sg_min4` first, checks every strategy, and places `sg_hier` **only if** every
`sg_min4` simulation job passed (`reports/regression.json`) and every `sg_min4` placement is clean. The gate record
is in `reports/physical.json` (`"open": true` with 47/47 `sg_min4` regression jobs).

## 7. OpenROAD

`physical/openroad_place_check.tcl` loads the IHP tech / stdcell / SRAM LEFs and a generated `macro_place.def`
into OpenROAD and re-checks core containment, blockages and spacing with OpenDB geometry, then writes the checked
DEF. **It was not run**: OpenROAD is not installed in this environment, and executing a downloaded OpenROAD binary
was not permitted in the session that produced this project. What stands in for it: the generated Tcl executed in
`tclsh` against a mock of exactly the OpenDB calls it uses (C10), and the independent geometric checker.
Not done at all: power grid, tap cells, global / detailed routing, timing.
