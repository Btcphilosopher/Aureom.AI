# 08 — Limitations: what is not claimed

| Area | Not done / not claimed | Why / what stands in |
|---|---|---|
| Silicon | no area, frequency, power or yield claim for a fabricated die | RTL simulation, Yosys synthesis, geometric placement only |
| OpenROAD | not run (`physical/openroad_place_check.tcl` provided) | not installed; executing a downloaded OpenROAD binary was not permitted in this session. Stand-ins: mock-OpenDB execution of the generated Tcl in `tclsh`, independent geometric checker with self-test |
| Timing | no STA; macro clock-to-output, setup / hold from the Liberty views not used; no clock frequency claimed | wire numbers are Manhattan **distance estimates**, not extracted delay; `req_pipe` / `out_reg` are the knobs STA would set |
| Floorplan | die size, logic-block outlines, blockages and traffic mix are assumptions (labelled in every output) | no mapped netlist of the clusters with outlines exists in the repository (P31 states none) |
| Power | no power grid; macro supply pins (from LEF) are not connected | listed per macro in the connectivity report for the PDN step |
| Logic area | Yosys + IHP typical Liberty: unplaced cell area | no utilisation, clock tree, buffering, tap / fill, routing |
| Macro data | only IHP SG13G2 placements are generated; SKY130 / GF180 are selectable for mapping and simulation-verified in the wrapper, not placed | the floorplan files target IHP |
| Commercial macros | 130 / 65 / 28 nm placeholders have no data and are refused | no licensed compiler output |
| ECC | no read-modify-write: SECDED regions are granule-written; no poison storage; no scrub engine in the grid | RAS P26's `sfras_ecc_sram` provides RMW / scrub / poison for single memories; RMW halves bank throughput (RAS P26 measurement) |
| MBIST | March C- through the library's demonstration controller; no retention / pause elements, no macro-specific algorithms, no production coverage; the IHP macros' own BIST mux is tied off | same limits as the SRAM library (its docs/04) |
| Repair | **none**: no spare rows / columns in any supported macro, no redundancy or fuse logic | MBIST reports bank / row; mapping out is software's decision |
| FPGA | Yosys `synth_xilinx` inference count only; no vendor place-and-route or board run | |
| DMA | the testbench's DMA port is a streaming master model (burst fills / read-backs with many outstanding requests), not the DataFabric DMA RTL | the grid port is SFB2-compatible; an SFB2 bridge keeps SFB2's one-outstanding rule |
| Coverage | scenario- and assertion-based; no functional-coverage database, no formal proof of the grid | mutation testing (reports/mutation.md) measures the testbench's sensitivity |
