# 04 — Physical macros, ECC, MBIST and RAS

## 1. Real macro abstracts

`scripts/fetch_macros.sh` runs the SRAM library's pinned fetch (IHP-Open-PDK `5e6d592`, efabless
`sky130_sram_macros` `ebfbf57`, google `gf180mcu_fd_ip_sram` `9c41192`) plus the IHP technology / standard-cell
LEF and typical Liberty, and verifies **every file against the SHA-256 recorded in the library manifests
(137/137)**. `scripts/sg_lef.py` parses the LEF text (nothing is executed) into `physical/abstracts/<macro>.json`:

* outline (`SIZE`), `ORIGIN`, `CLASS BLOCK`, `SYMMETRY` → legal orientations
* every pin: direction, use, layers, rectangle bounding box, the edge it sits on
  (IHP / SKY130 / GF180: all signal pins on the bottom edge — IHP on Metal2)
* power / ground pins (IHP `VDD!`, `VSS!`, `VDDARRAY!` as Metal4 stripes; SKY130 `vccd1/vssd1`; GF180 `VDD/VSS`)
* obstructions per layer and which layers are fully blocked (IHP: Metal1, Metal3; GF180: Metal1, Metal2, Via1, Via2)
* provenance: repository, commit, path, LEF SHA-256 and the manifest's SHA-256 (must match), and a check that the
  LEF `SIZE` equals the manifest's physical size

No dimension in this project is estimated or scaled: every macro rectangle in the placements, the area report
and the connectivity report comes from these files. Example: `RM_IHPSG13_1P_1024x32_c2_bm_bist` 416.64 ×
336.46 µm, `RM_IHPSG13_1P_2048x32_c2_bm_bist` 416.64 × 626.70 µm, `RM_IHPSG13_2P_512x32_c2_bm_bist` 685.49 ×
219.77 µm. Site: IHP `CoreSite` 0.48 × 3.78 µm; manufacturing grid 0.005 µm.

The brief's fallback — an *illustrative* planning model — was not needed: real abstracts exist. The separate
**synthesis-memory inference flow** is `flow = generic` (behavioural arrays, inferred `$mem`) and `flow = fpga`
(block-RAM templates); `flow = asic` instantiates only real macros and never falls back to flip-flops
(unknown ids and commercial placeholders are refused).

## 2. Macro wrapper ↔ real macro

`silicaflux_sram_macro_wrapper` maps one logical bank onto the SRAM library: `sram_asic_array` tiles `NC` columns ×
`NR` rows of the selected macro, maps lane masks to the macro's bit / byte masks (padding bits written 0 with mask
0), registers the row select for multi-row tilings, and the per-family leaf applies the datasheet tie-offs
(IHP `A_DLY = 1`, `A_BIST_* = 0`; SKY130 `csb1 = 1` in 1RW use). `reports/wrapper.md`: the wrapper on the
**vendor's own Verilog models** (IHP 1P 1024x32 / 2048x32, IHP 2P 512x32 in 1R1W and 2RW, SKY130 32x256 in 1RW and
1R1W, GF180 512x8) returns exactly what a shadow memory predicts, at exactly the declared latency, for
2 190 – 4 351 random read returns per case, with masked writes and test-port traffic interleaved.

`reports/connectivity_<cfg>.md` resolves every pin bit of every macro in the synthesized netlist: clock on the
top-level `clk`, enables and every address bit driven, data / mask bits driven for every stored bit the tile
holds and tied 0 for padding, read data loaded on the reading port(s), tie-offs as required — **0 anomalies for
12 (`sg_min4`) and 69 (`sg_hier`) macros**. Supply pins are not in the RTL netlist (`USE_POWER_PINS` off); their
names and layers are listed for the power-grid step.

## 3. ECC: integration and real width cost

The encoder / decoder are RAS Project 26's `sfras_secded_enc/dec`, vendored unmodified, with RAS's default
check-bit inversion (an all-zero or dead row decodes UNCORRECTABLE, never as valid zero data).

* Granule G = 64 → 72 stored bits per 64-bit word; G = 32 → 2 × 39 = 78. The stored width is what the macro
  wrapper, the macro selection, the tiling, the MBIST bus (`TSW`), the area report and the placement use.
* **The expansion has a real cost in macros, not 12.5 %:** no IHP macro is 72 bits wide, so a 72-bit bank needs
  3 × 32-bit macros (24 padding bits). For `sg_min4` the same 32 KiB costs 1.056 mm² unprotected
  (4 × `1024x64`) and 1.682 mm² with SECDED or parity (12 × `1024x32`): **+59 %** (`reports/area.md`,
  "ECC what-if"). A 128-bit bank with G = 64 (144 = 3 × 48 bits) would tile exactly on IHP's 48-bit macros where a
  256-word depth suffices — the area report lists the alternatives the selector considered.
* Writes in SECDED regions are granule-granular: a strobe that covers part of a granule is refused (`ERR_STROBE`)
  — there is no read-modify-write path, deliberately (RAS P26 measured RMW costing a third of the bank bandwidth).
  Byte-writable regions use byte parity (detection only) or no protection.
* Reads: corrected data with `rsp_ce = 1` on a single error; `ERR_ECC_UE` and zero data on a double error;
  `ERR_PARITY` on a parity mismatch. Every such read raises a RAS event with the logical byte address, syndrome and
  bit index (format of `silicaflux_ras.mem_ev_*`). Checked by the `ecc` scenario: single and double flips injected
  into the stored word (data, check and parity bits) through the backdoor, 24 per protected region per run.

## 4. MBIST

The grid exposes the TestCore / SRAM-library collar bus on raw stored words, so data **and** check bits are
tested. Test operations enter each bank's request pipe after the functional accesses already in it; read data is
padded to one bus latency (`TEST_LAT`). While `tst_active` (and in the cycle it falls) no functional request is
issued; accepted ones wait and complete afterwards; the init sweep then restores valid codewords
(`init_after_test`). The testbench drives the SRAM library's unmodified `sram_mbist_march` (March C-) over every
bank: a fault-free run passes, and a stuck-at-0 injected into a stored bit through the generic model's fault hook
is reported with the right bank, row and March element (2) — `reports/regression.md`.

## 5. No repair

None of the open-PDK macros has spare rows or columns or repair pins (manifests and LEF: no such pins), and the
grid has no redundancy or fuse logic. MBIST reports the failing bank / row; mapping a bank out is a software
decision. **No SRAM repair is claimed.**
