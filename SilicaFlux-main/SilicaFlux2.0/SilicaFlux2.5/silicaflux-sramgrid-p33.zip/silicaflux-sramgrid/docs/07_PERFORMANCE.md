# 07 — Performance

All numbers: RTL simulation, Verilator, the `perf`, `conflict` and `dma` scenarios **without back-pressure**
(`reports/performance.md` — generated from `reports/performance.json`). Definitions:

| Metric | Definition |
|---|---|
| bandwidth | completed request bytes (DW/8 per read or write) / cycles of the pattern |
| bank utilisation | accesses performed by a bank / cycles (limit 1.0 for 1RW, 2.0 for 1R1W / 2RW) |
| conflicts (arbitration stalls) | cycles in which a decodable request with a response credit lost its bank's arbitration (`ev_conflict`) |
| credit stalls | cycles in which a port's head request waited for a free reorder slot (`ev_credit_stall`) |
| read latency | cycles from acceptance to response, reads only (min / mean / max) |

Patterns (every port, 3 reads : 1 write): `local` (each port in its own region — `sg_hier`), `shared_seq` (unit
stride, per-port offsets), `shared_stride` (stride = number of banks: every access of a port in **one** bank under
the LOW map), `shared_rand` (uniform random), `conflict` (every wired port in one bank), `dma` (one streaming port
+ background traffic).

## Observations (values: `reports/performance.md`)

* **Starting configuration (`sg_min4`, 1RW, LOW map, 3 ports × 8 B):** unit-stride shared traffic delivers
  **23.65 B/cycle of a 24 B/cycle port limit** (98.5 %), each bank 0.74 busy, read latency exactly 2 cycles
  (min = mean = max), no arbitration or credit stalls.
* **Bank conflicts are the dominant limiter.** A stride equal to the bank count puts every access in one bank:
  **7.96 B/cycle = one 64-bit access per cycle**, that bank at utilisation 1.00, 1 197 arbitration stalls in
  603 cycles (two of the three ports lose every cycle), mean read latency 3.99 cycles with round robin.
* **XOR mapping removes the stride pathology at no cost for unit stride:** the same stride on `r_xor` runs at
  23.65 B/cycle (×3.0) with no conflicts; unit stride stays at 23.41 B/cycle.
* **Dual-port banks:** 2RW (`r_2rw`) doubles the single-bank ceiling (15.84 B/cycle, bank utilisation 1.98);
  1R1W reaches 10.57 B/cycle (1.32) because only the 1-in-4 writes can use the second port.
* **Fixed priority starves:** on the conflict stride `r_fixed` delivers the same total bandwidth but its
  lowest-priority port waits up to **402 cycles** for a read (round robin: 4).
* **Reorder slots:** a port needs `reorder_slots ≥ LAT + 2` (response latency + 1) to issue every cycle.
  `sg_min4` (LAT 1, 4 slots): zero credit stalls. `r_dw128` (2 slots): 31.79 of 48 B/cycle with 297 credit
  stalls. `sg_hier` (shared region LAT 3, 4 slots): 185–245 credit stalls per pattern — **recommendation: 8 slots
  for `sg_hier`** (the generator now warns about this configuration).
* **Pipelining costs latency, not bandwidth:** `r_pipe` (2 request stages + output register, 8 slots) answers
  in 5 cycles and still delivers 23.30 B/cycle on unit stride.
* **Direct ports (`slice = 0`):** latency counted from acceptance is 2 cycles even under conflicts because the
  request is accepted only when it issues — the wait moves before acceptance (same bandwidth, 7.96 B/cycle).
* **Scaled hierarchy (`sg_hier`, 5 ports, 23 banks):** 27.97 B/cycle with every port in its own region,
  31.50 B/cycle on the conflict stride (XOR-mapped 8-bank shared region) of a 40 B/cycle port limit; shared
  reads answer in 4 cycles (request pipe 1 + output register).

## What limits throughput

* **Bank port model.** A 1RW bank performs one access per cycle; every pattern that concentrates on one bank is
  capped at DW/8 bytes per cycle. Dual-port banks (1R1W for read+write streams, 2RW for anything) double it.
* **Mapping.** LOW interleave is ideal for unit stride and pathological for a stride equal to the bank count;
  XOR spreads such strides across banks at no cost for unit stride. `sg_hier`'s shared region uses XOR.
* **Reorder slots.** A port issues only with a free slot; a slot is held from the issue edge until the response
  handshake (response latency LAT + 1 cycles) and is reusable at the next edge, so `reorder_slots ≥ LAT + 2` is
  needed for one access per cycle per port. `r_dw128` (2 slots) and `sg_hier` (4 slots, LAT 3) show the ceiling.
* **Arbitration policy.** Round robin bounds a requester's wait; fixed priority does not (the `r_fixed` stride
  pattern shows the starved port's worst-case latency).
* **Pipelining.** `req_pipe` / `out_reg` add latency (response at LAT + 1) without reducing throughput when enough
  reorder slots exist (`r_pipe`, 8 slots).
