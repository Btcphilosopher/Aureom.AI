# 03 — Memory configuration schema and bank configuration

## 1. Files

| File | Role |
|---|---|
| `config/schema/sramgrid_config.schema.json` | JSON Schema (draft 2020-12): structure, enums, ranges, patterns |
| `scripts/sg_config.py` | `validate` / `derive` / `emit`: schema + cross-field rules, derived facts, generated SystemVerilog |
| `config/sg_min4.json` | **the brief's starting point**: one shared region, four banks, three ports |
| `config/sg_hier.json` | the scaled hierarchy (built and placed only after `sg_min4` was validated — docs/05 §6) |
| `config/regress/*.json` | 13 `sg_min4` variants for the regression (port models, RDW policies, maps, pipes, slices, …) |
| `config/floorplan/*.json` | placement experiments (die, halo, channel, blocks, blockages, assumed traffic) |
| `gen/<cfg>/` | emitted: `sg_cfg.svh` (parameters + `SGC_PARAMS`), `sg_top.sv` (synthesis top), `derived.json`, `memory_map.md` |

## 2. Fields

`grid`: `data_width` (bank word = port width: 32…512), `addr_width`, `tag_width`, `ecc_granule` (32 / 64),
`reorder_slots` (2/4/8/16 outstanding responses per port), `arbitration` (`rr` / `fixed`), `read_during_write`
(`write_first` / `read_first`), `init_on_reset`, `init_after_test`, `perf_counters`, `counter_width`.

`implementation`: `flow` (`generic` = synthesis-inference / simulation model, `fpga` = block-RAM inference,
`asic` = real macros) and `technology` (`ihp_sg13g2`, `sky130`, `gf180`: the macro catalogue used for mapping, area
and placement — evaluated for every flow).

`regions[]`: `name`, `kind` (`shared`, `vec_local`, `ten_operand`, `ten_acc`, `boot`), `near` (placement affinity),
`base`, `size`, `banks` (1/2/4/8/16), `port_model` (`1rw` / `1r1w` / `2rw`), `map` (`low` / `xor` / `high`),
`ecc` (`none` / `parity` / `secded`), `byte_write`, `req_pipe` (0–3), `out_reg` (0/1), `write_protect`,
`macro` (`auto` or a catalogue name).

`ports[]`: `name`, `kind`, `cluster` (floorplan block of the master), `regions` (wiring), `slice` (0 direct /
1 registered-ready skid).

## 3. Bank organisation per region (derived)

| Quantity | Value |
|---|---|
| bank depth | size / (banks · DW/8) rows (≥ 2) |
| bank index / row | LOW: `bank = word mod banks`, `row = word / banks`; XOR: `bank = (word ^ word/banks) mod banks`; HIGH: `bank = word / depth` |
| stored width | none: DW; parity: 9·DW/8; SECDED: (DW/G)·(G + R + 1) — 72 for DW = 64, G = 64 |
| write-mask lanes | SECDED: one per granule; parity / none with `byte_write`: DW/8; otherwise 1 |
| accesses per bank per cycle | 1RW 1, 1R1W 1 read + 1 write, 2RW 2 |
| bank latency LAT | `req_pipe` + 1 + `out_reg`; response at LAT + 1 |
| macro mapping | smallest footprint (LEF area + 40 µm channel) that tiles stored width × depth with the region's port model and a compatible write-mask granularity |

## 4. Rejected configurations

Every rule is checked twice: by `sg_config.py` (all violations listed, exit 2) and by the RTL at elaboration
(Verilator / Yosys stop; Icarus `$fatal` at time 0) so a bypassed generator cannot produce a silently wrong grid.

| Rule | Generator | RTL |
|---|---|---|
| region size power of two, base aligned to it, inside the address space | ✓ | ✓ `g_err_region_field_out_of_range` |
| banks ∈ {1,2,4,8,16}; ≥ 2 rows per bank | ✓ (schema + rule) | ✓ |
| regions disjoint | ✓ | ✓ `g_err_regions_overlap` |
| XOR map needs row bits ≥ bank bits | ✓ | ✓ `g_err_xor_map_needs_rows_ge_banks` |
| SECDED regions are granule-written (`byte_write = false`; byte writes would need RMW) | ✓ | ✓ `g_err_secded_region_has_byte_we` |
| DW power of two 32…512; G ∈ {32, 64}, G ≤ DW; reorder slots power of two 2…16 | ✓ (schema) | ✓ |
| ASIC flow: a real catalogue macro whose topology supports the port model and whose mask granularity divides the lane | ✓ | ✓ wrapper + SRAM library (`g_err_macro_*`, `g_err_lane_not_multiple_of_macro_mask_granularity`) |
| commercial placeholder macros | ✓ (not in the abstracts) | ✓ `g_err_macro_pending_no_licensed_compiler_output` |
| every port references existing regions; every region wired to a port; unique names | ✓ | — |
| derived consistency (NBT, RWX, TSW, TEST_LAT) | emitted | ✓ `g_err_*_inconsistent` |

Results: `reports/lint.md` (19 legal configurations warning-free; 18 illegal parameter sets × 3 tools, 15 illegal JSON files — all refused).

## 5. `sg_min4` and `sg_hier`

`gen/sg_min4/memory_map.md`, `gen/sg_hier/memory_map.md` (generated). Summary:

| Config | Regions | Banks | Ports | Port–bank links (full crossbar) | Logical | IHP macros |
|---|---|---|---|---|---|---|
| `sg_min4` | shared 32 KiB @ `0x2000_0000`, 4 × 1024 × 72 b SECDED, 1RW | 4 | vec0, ten0, dma0 | 12 (12) | 32 KiB | 12 × `RM_IHPSG13_1P_1024x32` |
| `sg_hier` | boot 8 KiB (parity, write-protectable), shared 128 KiB (8 banks, XOR, SECDED, pipe 1 + out_reg), vec0/vec1 32 KiB each (parity, byte writes), ten_opnd 16 KiB (1R1W parity), ten_acc 8 KiB (2RW SECDED) | 23 | vec0, vec1, ten0, dma0, ctrl | 70 (115) | 224 KiB | 69 (1024x32, 2048x32, 2P 512x32) |
