# Memory map — `r_dw128`

sg_min4 at 128-bit banks, 2 reorder slots

Bank word 128 bits; flow `generic`; macro catalogue `ihp_sg13g2` (real LEF abstracts, `physical/abstracts/`).

| Region | Kind | Window | Size | Banks × depth | Map | Port model | ECC | Stored word | Lat (rsp) | WP | Macro × count |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `shared` | shared | `0x20000000`–`0x2000ffff` | 64 KiB | 4 × 1024 | low | 1rw | secded | 144 b (2 lanes) | 2 | no | `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 5 (5×1 per bank × 4) |

Every address outside these windows is UNMAPPED (error response, no side effect, never wrapped).

## Port wiring (sparse crossbar)

| Port | Kind | Regions | Slice | Banks reachable |
|---|---|---|---|---|
| `vec0` | vector | shared | 1 | 4 / 4 |
| `ten0` | tensor | shared | 1 | 4 / 4 |
| `dma0` | dma | shared | 1 | 4 / 4 |

Port–bank links: **12** of 12 for a full crossbar (100 %).
