# Memory map — `sg_hier`

Scaled hierarchy (after sg_min4 was validated): two vector-local scratchpads, tensor operand buffer, tensor accumulator storage, shared SRAM and a write-protectable boot RAM

Bank word 64 bits; flow `generic`; macro catalogue `ihp_sg13g2` (real LEF abstracts, `physical/abstracts/`).

| Region | Kind | Window | Size | Banks × depth | Map | Port model | ECC | Stored word | Lat (rsp) | WP | Macro × count |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `boot` | boot | `0x00000000`–`0x00001fff` | 8 KiB | 1 × 1024 | low | 1rw | parity | 72 b (8 lanes) | 2 | yes | `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 3 (3×1 per bank × 1) |
| `shared` | shared | `0x20000000`–`0x2001ffff` | 128 KiB | 8 × 2048 | xor | 1rw | secded | 72 b (1 lanes) | 4 | no | `RM_IHPSG13_1P_2048x32_c2_bm_bist` × 3 (3×1 per bank × 8) |
| `vec0_spm` | vec_local | `0x30000000`–`0x30007fff` | 32 KiB | 4 × 1024 | low | 1rw | parity | 72 b (8 lanes) | 2 | no | `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 3 (3×1 per bank × 4) |
| `vec1_spm` | vec_local | `0x30100000`–`0x30107fff` | 32 KiB | 4 × 1024 | low | 1rw | parity | 72 b (8 lanes) | 2 | no | `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 3 (3×1 per bank × 4) |
| `ten_opnd` | ten_operand | `0x34000000`–`0x34003fff` | 16 KiB | 4 × 512 | low | 1r1w | parity | 72 b (8 lanes) | 2 | no | `RM_IHPSG13_2P_512x32_c2_bm_bist` × 3 (3×1 per bank × 4) |
| `ten_acc` | ten_acc | `0x34080000`–`0x34081fff` | 8 KiB | 2 × 512 | low | 2rw | secded | 72 b (1 lanes) | 2 | no | `RM_IHPSG13_2P_512x32_c2_bm_bist` × 3 (3×1 per bank × 2) |

Every address outside these windows is UNMAPPED (error response, no side effect, never wrapped).

## Port wiring (sparse crossbar)

| Port | Kind | Regions | Slice | Banks reachable |
|---|---|---|---|---|
| `vec0` | vector | vec0_spm, shared | 1 | 12 / 23 |
| `vec1` | vector | vec1_spm, shared | 1 | 12 / 23 |
| `ten0` | tensor | ten_opnd, ten_acc, shared | 1 | 14 / 23 |
| `dma0` | dma | boot, shared, vec0_spm, vec1_spm, ten_opnd, ten_acc | 1 | 23 / 23 |
| `ctrl` | control | boot, shared | 1 | 9 / 23 |

Port–bank links: **70** of 115 for a full crossbar (61 %).
