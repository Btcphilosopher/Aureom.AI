# Memory map — `r_2rw`

sg_min4 with true dual-port banks

Bank word 64 bits; flow `generic`; macro catalogue `ihp_sg13g2` (real LEF abstracts, `physical/abstracts/`).

| Region | Kind | Window | Size | Banks × depth | Map | Port model | ECC | Stored word | Lat (rsp) | WP | Macro × count |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `shared` | shared | `0x20000000`–`0x20007fff` | 32 KiB | 4 × 1024 | low | 2rw | secded | 72 b (1 lanes) | 2 | no | `RM_IHPSG13_2P_1024x32_c2_bm_bist` × 3 (3×1 per bank × 4) |

Every address outside these windows is UNMAPPED (error response, no side effect, never wrapped).

## Port wiring (sparse crossbar)

| Port | Kind | Regions | Slice | Banks reachable |
|---|---|---|---|---|
| `vec0` | vector | shared | 1 | 4 / 4 |
| `ten0` | tensor | shared | 1 | 4 / 4 |
| `dma0` | dma | shared | 1 | 4 / 4 |

Port–bank links: **12** of 12 for a full crossbar (100 %).
