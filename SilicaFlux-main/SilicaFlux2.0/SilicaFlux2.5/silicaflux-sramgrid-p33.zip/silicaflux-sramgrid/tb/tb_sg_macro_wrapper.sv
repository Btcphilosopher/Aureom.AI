// =============================================================================
// SilicaFlux-HPC Project 33 :: SRAMGRID :: tb_sg_macro_wrapper
// Timing-semantics and real-macro equivalence test of
// silicaflux_sram_macro_wrapper.  Aureom.AI | SilicaFlux-HPC.
//
// Two wrappers receive identical stimulus every cycle:
//   u_ref : IMPL = GENERIC
//   u_dut : IMPL = ASIC on the vendor's own Verilog model of MW_MACRO (compile
//           with the fetched models, +define+FUNCTIONAL for IHP), or GENERIC
//           again when MW_ASIC = 0
// Checked every cycle (sampled at the rising edge, as a consumer flop does):
//   * x_rvalid exactly LATENCY cycles after each read edge, never otherwise;
//   * read data == shadow memory (lane-masked writes, test-port writes) for
//     both wrappers; u_dut == u_ref;
//   * OUT_REG = 1: rdata held between read returns;
//   * test port: tst_mode writes all lanes, tst_rdata / tst_rvalid follow the
//     read timing; functional ce is ignored while tst_mode = 1.
// Defines: MW_WIDTH MW_DEPTH MW_MASK MW_PM MW_OREG MW_MACRO MW_ASIC MW_N MW_SEED
// Classification: TESTBENCH
// =============================================================================
`timescale 1ns/1ps
`include "sfx_sg_defs.svh"
`default_nettype none

module tb_sg_macro_wrapper;
  localparam int W    = `MW_WIDTH;
  localparam int D    = `MW_DEPTH;
  localparam int M    = `MW_MASK;
  localparam int PM   = `MW_PM;
  localparam int OR   = `MW_OREG;
  localparam int MAC  = `MW_MACRO;
  localparam int ASIC = `MW_ASIC;
  localparam int AW   = $clog2(D);
  localparam int LW   = W / M;
  localparam int LAT  = 1 + OR;

  logic clk = 1'b0, rst_n = 1'b1;
  initial #1 rst_n = 1'b0;          // asynchronous reset event before the first clock edge
  always #5 clk = ~clk;

  logic         a_ce, a_we, b_ce, b_we, tst_mode, tst_ce, tst_we;
  logic [M-1:0] a_wm, b_wm;
  logic [AW-1:0] a_ad, b_ad, tst_ad;
  logic [W-1:0] a_wd, b_wd, tst_wd;
  logic [W-1:0] r_ard, r_brd, r_trd, d_ard, d_brd, d_trd;
  logic         r_arv, r_brv, r_trv, d_arv, d_brv, d_trv;

  silicaflux_sram_macro_wrapper #(.WIDTH(W), .DEPTH(D), .MASK_WIDTH(M), .PORT_MODE(PM), .IMPL(`SRAM_BACKEND_GENERIC),
                                  .MACRO(0), .OUT_REG(OR)) u_ref (
    .clk, .rst_n, .a_ce, .a_we, .a_wmask(a_wm), .a_addr(a_ad), .a_wdata(a_wd), .a_rdata(r_ard), .a_rvalid(r_arv),
    .b_ce, .b_we, .b_wmask(b_wm), .b_addr(b_ad), .b_wdata(b_wd), .b_rdata(r_brd), .b_rvalid(r_brv),
    .tst_mode, .tst_ce, .tst_we, .tst_addr(tst_ad), .tst_wdata(tst_wd), .tst_rdata(r_trd), .tst_rvalid(r_trv));
  silicaflux_sram_macro_wrapper #(.WIDTH(W), .DEPTH(D), .MASK_WIDTH(M), .PORT_MODE(PM),
                                  .IMPL(ASIC ? `SRAM_BACKEND_ASIC : `SRAM_BACKEND_GENERIC),
                                  .MACRO(ASIC ? MAC : 0), .OUT_REG(OR)) u_dut (
    .clk, .rst_n, .a_ce, .a_we, .a_wmask(a_wm), .a_addr(a_ad), .a_wdata(a_wd), .a_rdata(d_ard), .a_rvalid(d_arv),
    .b_ce, .b_we, .b_wmask(b_wm), .b_addr(b_ad), .b_wdata(b_wd), .b_rdata(d_brd), .b_rvalid(d_brv),
    .tst_mode, .tst_ce, .tst_we, .tst_addr(tst_ad), .tst_wdata(tst_wd), .tst_rdata(d_trd), .tst_rvalid(d_trv));

  // ------------------------------------------------------------ deterministic RNG
  logic [63:0] rng = 64'h1234_5678_9ABC_DEF1;
  function automatic logic [63:0] r64();
    rng = rng ^ (rng << 13); rng = rng ^ (rng >> 7); rng = rng ^ (rng << 17); r64 = rng;
  endfunction
  function automatic int rn(input int n);
    logic [63:0] x;
    x = r64();
    rn = int'(x[30:0] % 31'(n));
  endfunction
  function automatic logic [W-1:0] rw();
    logic [W+63:0] t;
    t = '0;
    for (int k = 0; k < W; k += 64) t[k +: 64] = r64();
    rw = t[W-1:0];
  endfunction

  // ------------------------------------------------------------ shadow + expectations
  logic [W-1:0] mem [D];
  logic         known [D];
  // expected read returns: slot [LAT] in the future, per port (A, B, T)
  logic [W-1:0] ea [LAT+1], eb [LAT+1], et [LAT+1];
  logic         va [LAT+1], vb [LAT+1], vt [LAT+1], ka [LAT+1], kb [LAT+1], kt [LAT+1];
  int errors = 0, nrd = 0;
  logic [W-1:0] hold_a_r, hold_a_d, hold_b_r, hold_b_d;
  logic         seen_a = 1'b0, seen_b = 1'b0;   // the output register was loaded at least once

  task automatic err(input string s);
    errors++;
    if (errors <= 10) $display("[%0t] ERROR %s", $time, s);
  endtask

  function automatic logic [W-1:0] merge(input logic [W-1:0] old, input logic [W-1:0] d, input logic [M-1:0] m);
    merge = old;
    for (int l = 0; l < M; l++) if (m[l]) merge[l*LW +: LW] = d[l*LW +: LW];
  endfunction

  // checker at the rising edge (before this edge's updates)
  always @(posedge clk) begin
    if (rst_n) begin
      // shift expectations: index 1 is due NOW
      if (r_arv !== va[1] || d_arv !== va[1]) err($sformatf("A rvalid ref %b dut %b expected %b", r_arv, d_arv, va[1]));
      if (r_brv !== vb[1] || d_brv !== vb[1]) err($sformatf("B rvalid ref %b dut %b expected %b", r_brv, d_brv, vb[1]));
      if (r_trv !== vt[1] || d_trv !== vt[1]) err($sformatf("T rvalid ref %b dut %b expected %b", r_trv, d_trv, vt[1]));
      if (va[1]) begin
        nrd++;
        if (ka[1] && r_ard !== ea[1]) err($sformatf("A ref rdata %h expected %h", r_ard, ea[1]));
        if (ka[1] && d_ard !== ea[1]) err($sformatf("A dut rdata %h expected %h", d_ard, ea[1]));
        hold_a_r = r_ard; hold_a_d = d_ard; seen_a = 1'b1;
      end else if (OR != 0 && PM != `SG_PORT_1R1W && !vt[1] && seen_a) begin
        if (r_ard !== hold_a_r || d_ard !== hold_a_d) err("OUT_REG=1: A rdata not held between read returns");
      end
      if (vb[1]) begin
        nrd++;
        if (kb[1] && r_brd !== eb[1]) err($sformatf("B ref rdata %h expected %h", r_brd, eb[1]));
        if (kb[1] && d_brd !== eb[1]) err($sformatf("B dut rdata %h expected %h", d_brd, eb[1]));
        hold_b_r = r_brd; hold_b_d = d_brd; seen_b = 1'b1;
      end else if (OR != 0 && PM != `SG_PORT_1RW && !vt[1] && seen_b) begin
        if (r_brd !== hold_b_r || d_brd !== hold_b_d) err("OUT_REG=1: B rdata not held between read returns");
      end
      if (vt[1]) begin
        nrd++;
        if (kt[1] && r_trd !== et[1]) err($sformatf("T ref rdata %h expected %h", r_trd, et[1]));
        if (kt[1] && d_trd !== et[1]) err($sformatf("T dut rdata %h expected %h", d_trd, et[1]));
        if (PM == `SG_PORT_1R1W) begin hold_b_r = r_brd; hold_b_d = d_brd; seen_b = 1'b1; end
        else                     begin hold_a_r = r_ard; hold_a_d = d_ard; seen_a = 1'b1; end
      end
      for (int k = 1; k < LAT; k++) begin
        ea[k] = ea[k+1]; va[k] = va[k+1]; ka[k] = ka[k+1];
        eb[k] = eb[k+1]; vb[k] = vb[k+1]; kb[k] = kb[k+1];
        et[k] = et[k+1]; vt[k] = vt[k+1]; kt[k] = kt[k+1];
      end
      va[LAT] = 1'b0; vb[LAT] = 1'b0; vt[LAT] = 1'b0;
      // this edge's accesses (inputs were driven at the previous falling edge)
      if (tst_mode) begin
        if (tst_ce && !tst_we) begin et[LAT] = mem[tst_ad]; kt[LAT] = known[tst_ad]; vt[LAT] = 1'b1; end
        if (tst_ce && tst_we)  begin mem[tst_ad] = tst_wd; known[tst_ad] = 1'b1; end
      end else begin
        // reads see the state before this edge's writes (never same address: stimulus rule)
        if (PM == `SG_PORT_1R1W) begin
          if (b_ce) begin eb[LAT] = mem[b_ad]; kb[LAT] = known[b_ad]; vb[LAT] = 1'b1; end
          if (a_ce) begin mem[a_ad] = merge(mem[a_ad], a_wd, a_wm); known[a_ad] = known[a_ad] || (a_wm == '1); end
        end else begin
          if (a_ce && !a_we) begin ea[LAT] = mem[a_ad]; ka[LAT] = known[a_ad]; va[LAT] = 1'b1; end
          if (PM == `SG_PORT_2RW && b_ce && !b_we) begin eb[LAT] = mem[b_ad]; kb[LAT] = known[b_ad]; vb[LAT] = 1'b1; end
          if (a_ce && a_we) begin mem[a_ad] = merge(mem[a_ad], a_wd, a_wm); known[a_ad] = known[a_ad] || (a_wm == '1); end
          if (PM == `SG_PORT_2RW && b_ce && b_we) begin mem[b_ad] = merge(mem[b_ad], b_wd, b_wm); known[b_ad] = known[b_ad] || (b_wm == '1); end
        end
      end
    end
  end

  // stimulus at the falling edge
  int tmode_left = 0;
  task automatic idle_inputs();
    a_ce = 1'b0; a_we = 1'b0; b_ce = 1'b0; b_we = 1'b0; tst_ce = 1'b0; tst_we = 1'b0;
  endtask
  initial begin
    int n, seed;
    n = `MW_N;
    seed = `MW_SEED;
    rng = rng ^ (64'(seed) * 64'h9E3779B97F4A7C15);
    for (int i = 0; i < D; i++) begin mem[i] = '0; known[i] = 1'b0; end
    for (int k = 0; k <= LAT; k++) begin va[k] = 0; vb[k] = 0; vt[k] = 0; ka[k] = 0; kb[k] = 0; kt[k] = 0; end
    idle_inputs(); tst_mode = 1'b0; a_wm = '0; b_wm = '0; a_ad = '0; b_ad = '0; tst_ad = '0; a_wd = '0; b_wd = '0; tst_wd = '0;
    hold_a_r = '0; hold_a_d = '0; hold_b_r = '0; hold_b_d = '0;
    repeat (3) @(negedge clk);
    rst_n = 1'b1;
    // fill every word through the functional write port so every later read is defined
    for (int i = 0; i < D; i++) begin
      @(negedge clk);
      idle_inputs();
      a_ce = 1'b1; a_we = 1'b1; a_wm = '1; a_ad = AW'(i); a_wd = rw();
    end
    for (int c = 0; c < n; c++) begin
      @(negedge clk);
      idle_inputs();
      if (tmode_left > 0) begin
        tmode_left--;
        tst_mode = 1'b1;
        if (rn(4) != 0) begin tst_ce = 1'b1; tst_we = rn(2) == 0; tst_ad = AW'(rn(D)); tst_wd = rw(); end
        a_ce = 1'b0;                                          // contract: no functional access while tst_mode = 1
      end else begin
        tst_mode = 1'b0;
        if (rn(64) == 0) tmode_left = 4 + rn(8);
        a_ad = AW'(rn(D)); b_ad = AW'(rn(D));
        a_wd = rw(); b_wd = rw();
        a_wm = M'(r64()); b_wm = M'(r64());
        if (PM == `SG_PORT_1R1W) begin
          a_ce = rn(3) != 0;                                  // write port
          b_ce = rn(3) != 0;                                  // read port
          if (a_ce && b_ce && a_ad == b_ad) b_ad = AW'((int'(a_ad) + 1) % D);
        end else begin
          a_ce = rn(4) != 0; a_we = rn(2) == 0;
          if (PM == `SG_PORT_2RW) begin
            b_ce = rn(4) != 0; b_we = rn(2) == 0;
            if (a_ce && b_ce && a_ad == b_ad) b_ad = AW'((int'(a_ad) + 1) % D);
          end
        end
      end
    end
    @(negedge clk); idle_inputs(); tst_mode = 1'b0;
    repeat (LAT + 3) @(negedge clk);
    if (ASIC != 0)
      $display("[tbw] W=%0d D=%0d M=%0d PM=%0d OUT_REG=%0d vendor model of macro id %0d: %0d read returns checked, %0d errors",
               W, D, M, PM, OR, MAC, nrd, errors);
    else
      $display("[tbw] W=%0d D=%0d M=%0d PM=%0d OUT_REG=%0d generic pair: %0d read returns checked, %0d errors",
               W, D, M, PM, OR, nrd, errors);
    if (errors == 0 && nrd > 0) $display("RESULT PASS");
    else                        $display("RESULT FAIL");
    $finish;
  end
endmodule

`default_nettype wire
