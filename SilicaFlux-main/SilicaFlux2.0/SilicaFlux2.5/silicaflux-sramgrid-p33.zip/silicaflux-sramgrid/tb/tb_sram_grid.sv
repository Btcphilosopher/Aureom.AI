// =============================================================================
// SilicaFlux-HPC Project 33 :: SRAMGRID :: tb_sram_grid
// Self-checking testbench of silicaflux_sram_grid for ONE configuration
// (gen/<cfg>/sg_cfg.svh on the include path).  Aureom.AI | SilicaFlux-HPC.
//
//   +SCEN=<name> +SEED=<n> [+BP=<pct>] [+GAP=<pct>] [+N=<ops>]
//
// Reference model (independent of the RTL decoder / arbiter code):
//   * its own region decode (base <= a < base + size), error classification,
//     bank / row maps;
//   * a shadow memory updated at the ISSUE edge of every request (ev_issue):
//     reads issued at edge t see every write issued before t, writes issued
//     at t are applied after the reads of t (same-row read/write pairs are
//     never co-issued: SG_ASSERT checks that in the arbiter);
//   * per-port expected-response FIFOs in issue (= acceptance) order: every
//     response is checked for tag, we, error code, data (known bytes) and the
//     corrected-error flag;
//   * physical audit: every written word is read back through a backdoor
//     from the bank / row the reference map predicts (bank mapping proof);
//   * RAS events checked against the logical address of injected errors;
//   * MBIST through the SRAM library's March C- controller on the test bus.
// Stimulus uses its own xorshift generator so Verilator and Icarus see
// identical traffic for a seed.
// Classification: TESTBENCH
// =============================================================================
`timescale 1ns/1ps
`include "sg_cfg.svh"
`include "sfx_sg_defs.svh"
`default_nettype none

module tb_sram_grid;

  // ============================================================ configuration
  localparam int NP     = `SGC_NP;
  localparam int NR     = `SGC_NR;
  localparam int AW     = `SGC_AW;
  localparam int DW     = `SGC_DW;
  localparam int NBY    = DW / 8;
  localparam int TAG_W  = `SGC_TAG_W;
  localparam int ECC_G  = `SGC_ECC_G;
  localparam int NSLOT  = `SGC_NSLOT;
  localparam int NBT    = `SGC_NBT;
  localparam int RWX    = `SGC_RWX;
  localparam int TSW    = `SGC_TSW;
  localparam int TLAT   = `SGC_TEST_LAT;
  localparam int CNT_W  = `SGC_CNT_W;
  localparam int RDW    = `SGC_RDW;
  localparam logic [NR*64-1:0] R_BASE  = `SGC_R_BASE;
  localparam logic [NR*8-1:0]  R_LOG2B = `SGC_R_LOG2B;
  localparam logic [NR*8-1:0]  R_NB    = `SGC_R_NB;
  localparam logic [NR*8-1:0]  R_PM    = `SGC_R_PM;
  localparam logic [NR*8-1:0]  R_MAP   = `SGC_R_MAP;
  localparam logic [NR*8-1:0]  R_ECC   = `SGC_R_ECC;
  localparam logic [NR*8-1:0]  R_BWE   = `SGC_R_BWE;
  localparam logic [NR*8-1:0]  R_PIPE  = `SGC_R_PIPE;
  localparam logic [NR*8-1:0]  R_OREG  = `SGC_R_OREG;
  localparam logic [NR*8-1:0]  R_WP    = `SGC_R_WP;
  localparam logic [NP*NR-1:0] P_REACH = `SGC_P_REACH;
  localparam logic [NBT*16-1:0] B_SW   = `SGC_B_SW;
  localparam int OFF = $clog2(NBY);
  localparam int GN  = ECC_G + $clog2(ECC_G + $clog2(ECC_G + 1) + 1) + 1;   // SECDED stored bits per granule

  function automatic int f8(input logic [NR*8-1:0] v, input int r);
    f8 = 0; f8[7:0] = v[r*8 +: 8];
  endfunction
  function automatic logic [63:0] rbase(input int r);  rbase = R_BASE[r*64 +: 64]; endfunction
  function automatic logic [63:0] rbytes(input int r); rbytes = 64'd1 << f8(R_LOG2B, r); endfunction
  function automatic int rwords(input int r); rwords = int'(rbytes(r) >> OFF); endfunction
  function automatic int lg2(input int x);
    lg2 = 0; for (int k = 0; k < 31; k++) if ((1 << k) < x) lg2 = k + 1;
  endfunction
  function automatic int word_base(input int r);   // first shadow index of region r
    word_base = 0; for (int k = 0; k < NR; k++) if (k < r) word_base = word_base + rwords(k);
  endfunction
  function automatic int bank_base(input int r);
    bank_base = 0; for (int k = 0; k < NR; k++) if (k < r) bank_base = bank_base + f8(R_NB, k);
  endfunction
  // constant functions (elaboration): plain arithmetic only (Icarus 12 rules)
  function automatic int c_tot_words();
    int k;
    c_tot_words = 0;
    for (k = 0; k < NR; k = k + 1) c_tot_words = c_tot_words + (1 << (f8(R_LOG2B, k) - OFF));
  endfunction
  function automatic int c_region_of_bank(input int b);
    int acc, k;
    acc = 0;
    c_region_of_bank = 0;
    for (k = 0; k < NR; k = k + 1) begin
      if (b >= acc) c_region_of_bank = k;
      acc = acc + f8(R_NB, k);
    end
  endfunction
  localparam int TOTW = c_tot_words();
  function automatic logic reach(input int p, input int r); reach = P_REACH[p*NR + r]; endfunction
  function automatic int bsw(input int b); bsw = 0; bsw[15:0] = B_SW[b*16 +: 16]; endfunction

  // ============================================================ DUT
  logic                   clk = 1'b0, rst_n = 1'b1;
  // power-up: rst_n falls at 1 ns (an asynchronous reset EVENT before the first clock edge), so every
  // reset-domain flop is cleared even when the simulator randomises power-up state
  initial #1 rst_n = 1'b0;
  logic [NP-1:0]          req_valid, req_ready, req_we;
  logic [NP*AW-1:0]       req_addr;
  logic [NP*DW-1:0]       req_wdata;
  logic [NP*NBY-1:0]      req_wstrb;
  logic [NP*TAG_W-1:0]    req_tag;
  logic [NP-1:0]          rsp_valid, rsp_ready, rsp_err, rsp_we, rsp_ce;
  logic [NP*DW-1:0]       rsp_rdata;
  logic [NP*3-1:0]        rsp_err_code;
  logic [NP*TAG_W-1:0]    rsp_tag;
  logic                   wp_lock = 1'b0, init_req = 1'b0, init_busy, init_done;
  logic                   tst_active, tst_ce, tst_we;
  logic [NBT-1:0]         tst_sel;
  logic [RWX-1:0]         tst_addr;
  logic [TSW-1:0]         tst_wdata;
  logic [NBT*TSW-1:0]     tst_rdata;
  logic [NR-1:0]          ras_ev_valid, ras_ev_ce, ras_ev_ue, ras_ev_poison, ras_ev_lost;
  logic [NR*3-1:0]        ras_ev_org;
  logic [NR*AW-1:0]       ras_ev_addr;
  logic [NR*9-1:0]        ras_ev_syn;
  logic [NR*8-1:0]        ras_ev_idx;
  logic [NP-1:0]          ev_accept, ev_issue, ev_conflict, ev_credit_stall, ev_block_stall, ev_error, ev_complete;
  logic [NBT*2-1:0]       ev_bank_ops;
  logic [NBT-1:0]         ev_bank_conflict, ev_rdw_split;
  logic                   perf_clear = 1'b0;
  logic [CNT_W-1:0]       perf_cycles, perf_ecc_ce, perf_ecc_ue;
  logic [NP*CNT_W-1:0]    perf_issue, perf_conflict, perf_credit_stall, perf_complete;
  logic [NBT*CNT_W-1:0]   perf_bank_ops, perf_bank_conflict;
  logic                   busy;

  silicaflux_sram_grid `SGC_PARAMS u_dut (.*);

  always #5 clk = ~clk;

  // ============================================================ MBIST controller (SRAM Wrapper Library, unmodified)
  logic                   mb_start = 1'b0, mb_busy, mb_done, mb_pass, mb_fail, mb_chk = 1'b0, mb_stop = 1'b0;
  logic [NBT-1:0]         mb_mask = '1, mb_fail_mask;
  logic [((NBT > 1) ? $clog2(NBT) : 1)-1:0] mb_fail_tgt;
  logic [RWX-1:0]         mb_fail_addr;
  logic [2:0]             mb_fail_elem;
  logic [TSW-1:0]         mb_fail_syn;
  logic [15:0]            mb_fail_cnt;
  sram_mbist_march #(
    .NUM_TARGETS(NBT), .DW(TSW), .AW(RWX), .READ_LATENCY(TLAT),
    .TARGET_MAXADDR(`SGC_B_MAXADDR), .TARGET_DW(`SGC_B_SW), .ALGO(`SRAM_MBIST_MARCH_CM)
  ) u_mbist (
    .clk(clk), .rst_n(rst_n), .start(mb_start), .target_mask(mb_mask), .bg_checker(mb_chk), .stop_on_fail(mb_stop),
    .busy(mb_busy), .done(mb_done), .pass(mb_pass), .fail(mb_fail), .fail_mask(mb_fail_mask),
    .fail_target(mb_fail_tgt), .fail_addr(mb_fail_addr), .fail_elem(mb_fail_elem), .fail_syndrome(mb_fail_syn),
    .fail_count(mb_fail_cnt),
    .tst_active(tst_active), .tst_sel(tst_sel), .tst_ce(tst_ce), .tst_we(tst_we), .tst_addr(tst_addr),
    .tst_wdata(tst_wdata), .tst_rdata(tst_rdata)
  );

  // ============================================================ deterministic RNG (xorshift64)
  logic [63:0] rng = 64'h9E3779B97F4A7C15;
  function automatic logic [63:0] rnd64();
    rng = rng ^ (rng << 13);
    rng = rng ^ (rng >> 7);
    rng = rng ^ (rng << 17);
    rnd64 = rng;
  endfunction
  logic [63:0] rng_d = 64'hC2B2AE3D27D4EB4F;     // driver stream (back-pressure), independent of stimulus
  function automatic int rnd_drv(input int n);
    rng_d = rng_d ^ (rng_d << 13);
    rng_d = rng_d ^ (rng_d >> 7);
    rng_d = rng_d ^ (rng_d << 17);
    rnd_drv = (n <= 1) ? 0 : int'(rng_d[30:0] % 31'(n));
  endfunction
  function automatic int rnd(input int n);      // 0 .. n-1
    logic [63:0] x;
    x = rnd64();
    rnd = (n <= 1) ? 0 : int'(x[30:0] % 31'(n));
  endfunction

  // ============================================================ reference decode
  function automatic int region_of(input logic [AW-1:0] a);
    region_of = -1;
    for (int r = 0; r < NR; r++)
      if (64'(a) >= rbase(r) && 64'(a) < rbase(r) + rbytes(r)) region_of = r;
  endfunction
  function automatic logic granular(input logic [NBY-1:0] s, input int gbytes);
    granular = 1'b1;
    for (int k = 0; k < NBY; k++) if (s[k] != s[(k / gbytes) * gbytes]) granular = 1'b0;
  endfunction
  function automatic int exp_err(input int p, input logic we, input logic [AW-1:0] a, input logic [NBY-1:0] s);
    int r;
    r = region_of(a);
    if (r < 0)                                                                   exp_err = `SG_ERR_UNMAPPED;
    else if (!reach(p, r))                                                       exp_err = `SG_ERR_ACCESS;
    else if ((a % NBY) != 0)                                                     exp_err = `SG_ERR_ALIGN;
    else if (we && f8(R_WP, r) != 0 && wp_lock)                                  exp_err = `SG_ERR_WPROT;
    else if (we && f8(R_ECC, r) == `SG_ECC_SECDED && !granular(s, ECC_G / 8))    exp_err = `SG_ERR_STROBE;
    else if (we && f8(R_ECC, r) != `SG_ECC_SECDED && f8(R_BWE, r) == 0 && !granular(s, NBY)) exp_err = `SG_ERR_STROBE;
    else                                                                         exp_err = `SG_ERR_OK;
  endfunction
  // shadow index of an in-region, aligned address
  function automatic int widx(input logic [AW-1:0] a);
    int r;
    r = region_of(a);
    widx = word_base(r) + int'((64'(a) - rbase(r)) >> OFF);
  endfunction
  // reference bank / row of local word w in region r
  task automatic bank_row(input int r, input int w, output int gb, output int row);
    int nb, bw, rw;
    nb = f8(R_NB, r); bw = lg2(nb); rw = f8(R_LOG2B, r) - OFF - bw;
    if (f8(R_MAP, r) == `SG_MAP_HIGH) begin
      gb = bank_base(r) + (w >> rw); row = w % (1 << rw);
    end else if (f8(R_MAP, r) == `SG_MAP_XOR) begin
      gb = bank_base(r) + ((w ^ (w >> bw)) % nb); row = w >> bw;
    end else begin
      gb = bank_base(r) + (w % nb); row = w >> bw;
    end
  endtask
  function automatic logic [AW-1:0] addr_of(input int r, input int w);
    addr_of = AW'(rbase(r) + (64'(w) << OFF));
  endfunction

  // ============================================================ shadow memory
  logic [DW-1:0]  sh_d  [TOTW];
  logic [NBY-1:0] sh_k  [TOTW];      // known bytes
  int             sh_inj[TOTW];      // injected stored-bit flips (0 none, 1 single, 2 double)
  int             sh_ilane[TOTW];    // lane / granule of the injection
  logic           sh_wr [TOTW];      // written since the last init (for the physical audit)
  logic           init_known = 1'b0; // an init sweep defined every word as zero

  task automatic shadow_init(input logic zero_known);
    for (int i = 0; i < TOTW; i++) begin
      sh_d[i] = '0; sh_k[i] = zero_known ? '1 : '0; sh_inj[i] = 0; sh_ilane[i] = 0; sh_wr[i] = 1'b0;
    end
  endtask

  // ============================================================ per-port transaction rings
  localparam int RING = 1 << 15;
  typedef struct packed {
    logic             we;
    logic [AW-1:0]    addr;
    logic [DW-1:0]    wdata;
    logic [NBY-1:0]   wstrb;
    logic [TAG_W-1:0] tag;
    logic [15:0]      gap;
  } txn_t;
  typedef struct packed {
    logic             we;
    logic [2:0]       err;
    logic [DW-1:0]    data;
    logic [NBY-1:0]   kmask;
    logic             ce;
    logic [TAG_W-1:0] tag;
    logic [31:0]      t_acc;
    logic [31:0]      widx;
    logic             dc;            // integrity-protected word with undefined bytes: error / data unchecked
  } exp_t;
  txn_t tx_ring  [NP][RING];
  int   tx_rd[NP], tx_wr[NP];
  txn_t acc_ring [NP][64];            // accepted, not yet issued
  int   acc_rd[NP], acc_wr[NP];
  logic [31:0] acc_t [NP][64];
  exp_t exp_ring [NP][64];            // issued, response pending
  int   exp_rd[NP], exp_wr[NP];

  int   cyc = 0;
  int   errors = 0, checks = 0;
  logic [TAG_W-1:0] tagc [NP];

  task automatic fail(input string msg);
    errors++;
    if (errors <= 20) $display("[%0t] ERROR: %s", $time, msg);
  endtask

  task automatic enq(input int p, input logic we, input logic [AW-1:0] a, input logic [DW-1:0] d,
                     input logic [NBY-1:0] s, input int gap);
    txn_t t;
    t.we = we; t.addr = a; t.wdata = d; t.wstrb = s; t.tag = tagc[p]; t.gap = 16'(gap);
    tagc[p] = tagc[p] + 1'b1;
    tx_ring[p][tx_wr[p] % RING] = t;
    tx_wr[p]++;
  endtask

  // ============================================================ driver (negedge)
  int   gap_ctr [NP];
  logic accepted [NP];
  int   bp_pct = 0, gap_pct = 0;
  always @(negedge clk) begin
    for (int p = 0; p < NP; p++) begin
      if (accepted[p]) begin
        req_valid[p] = 1'b0;
        accepted[p]  = 1'b0;
      end
      if (!req_valid[p] && rst_n) begin
        if (gap_ctr[p] > 0) gap_ctr[p]--;
        else if (tx_rd[p] != tx_wr[p]) begin
          txn_t t;
          t = tx_ring[p][tx_rd[p] % RING];
          tx_rd[p]++;
          req_valid[p]               = 1'b1;
          req_we[p]                  = t.we;
          req_addr[p*AW +: AW]       = t.addr;
          req_wdata[p*DW +: DW]      = t.wdata;
          req_wstrb[p*NBY +: NBY]    = t.wstrb;
          req_tag[p*TAG_W +: TAG_W]  = t.tag;
          gap_ctr[p] = int'(t.gap);
        end
      end
      rsp_ready[p] = (rnd_drv(100) >= bp_pct);
    end
  end

  // ============================================================ monitor / scoreboard (posedge)
  int   n_rd [NP], n_wr [NP], n_err [NP], n_cfl [NP], n_crs [NP], n_blk [NP];
  longint lat_sum [NP];
  int   lat_min [NP], lat_max [NP], n_lat [NP];
  int   ras_n_ce [NR], ras_n_ue [NR], ras_n_lost [NR];
  logic [AW-1:0] ras_last_addr [NR];
  int   bank_ops_tb [NBT];
  int   rdw_splits = 0;
  logic [DW-1:0] last_rsp [NP];
  int   n_dc = 0;
  logic in_init_q = 1'b0, in_tst_q = 1'b0, tst_prev = 1'b0;

  always @(posedge clk) begin
    if (!rst_n) begin
      // nothing is accepted, issued or delivered in reset (checked)
      for (int p = 0; p < NP; p++)
        if (req_ready[p]) fail($sformatf("port %0d: req_ready = 1 in reset", p));
    end else begin
      cyc++;
      // init sweep start: every word becomes encode(0) (init_known)
      if (init_busy && !in_init_q) begin
        shadow_init(1'b1);
        init_known = 1'b1;
      end
      in_init_q = init_busy;
      // MBIST start: the March patterns overwrite every word (raw, check bits included)
      if (tst_active && !in_tst_q) shadow_init(1'b0);
      in_tst_q = tst_active;
      // 1) accepts
      for (int p = 0; p < NP; p++) begin
        if (req_valid[p] && req_ready[p]) begin
          txn_t t;
          t.we = req_we[p]; t.addr = req_addr[p*AW +: AW]; t.wdata = req_wdata[p*DW +: DW];
          t.wstrb = req_wstrb[p*NBY +: NBY]; t.tag = req_tag[p*TAG_W +: TAG_W]; t.gap = '0;
          acc_ring[p][acc_wr[p] % 64] = t;
          acc_t[p][acc_wr[p] % 64]    = cyc;
          acc_wr[p]++;
          accepted[p] = 1'b1;
        end
      end
      // contract: no error-free request issues while MBIST owns the banks, in the cycle it releases
      // them (the re-initialisation starts at the end of that cycle) or during an init sweep
      for (int p = 0; p < NP; p++)
        if (ev_issue[p] && !ev_error[p] && (tst_active || tst_prev || init_busy))
          fail($sformatf("port %0d: functional issue while the banks belong to MBIST / init (tst %0b, released %0b, init %0b)",
                         p, tst_active, tst_prev, init_busy));
      tst_prev = tst_active;
      // 2) issues: reads of this edge first ...
      for (int p = 0; p < NP; p++) begin
        if (ev_issue[p]) begin
          txn_t t;
          exp_t e;
          int   ec, wi;
          if (acc_rd[p] == acc_wr[p]) begin
            fail($sformatf("port %0d: issue without an accepted request", p));
          end else begin
            t  = acc_ring[p][acc_rd[p] % 64];
            ec = exp_err(p, t.we, t.addr, t.wstrb);
            e.we = t.we; e.err = 3'(ec); e.data = '0; e.kmask = '1; e.ce = 1'b0; e.tag = t.tag;
            e.t_acc = acc_t[p][acc_rd[p] % 64]; e.widx = '1; e.dc = 1'b0;
            if (ec != `SG_ERR_OK) begin
              n_err[p]++;
              if (!ev_error[p]) fail($sformatf("port %0d: error request issued without ev_error", p));
            end else begin
              int r;
              wi = widx(t.addr);
              r  = region_of(t.addr);
              e.widx = 32'(wi);
              if (!t.we) begin
                n_rd[p]++;
                e.data  = sh_d[wi];
                e.kmask = sh_k[wi];
                // never-written bytes of a parity / SECDED word: the stored check bits are
                // whatever the array powered up with, so the outcome is undefined
                if (f8(R_ECC, r) != `SG_ECC_NONE && sh_k[wi] != '1 && sh_inj[wi] == 0) e.dc = 1'b1;
                if (sh_inj[wi] >= 2 && f8(R_ECC, r) == `SG_ECC_SECDED) begin
                  e.err = `SG_ERR_ECC_UE; e.data = '0; e.kmask = '1;
                end else if (sh_inj[wi] >= 1 && f8(R_ECC, r) == `SG_ECC_PARITY) begin
                  e.err = `SG_ERR_PARITY; e.data = '0; e.kmask = '1;
                end else if (sh_inj[wi] == 1 && f8(R_ECC, r) == `SG_ECC_SECDED) begin
                  e.ce = 1'b1;
                end
              end else begin
                n_wr[p]++;
              end
            end
            exp_ring[p][exp_wr[p] % 64] = e;
            exp_wr[p]++;
            acc_rd[p]++;
          end
        end
      end
      // ... then the writes of this edge
      for (int p = 0; p < NP; p++) begin
        if (ev_issue[p]) begin
          exp_t e;
          e = exp_ring[p][(exp_wr[p] - 1) % 64];
          if (e.we && e.err == `SG_ERR_OK) begin
            txn_t t;
            int   wi, r, il;
            logic [NBY-1:0] ws;
            logic [DW-1:0]  wd;
            t  = acc_ring[p][(acc_rd[p] - 1) % 64];
            wi = int'(e.widx);
            r  = region_of(t.addr);
            ws = t.wstrb;
            wd = t.wdata;
            for (int k = 0; k < NBY; k++) begin
              if (ws[k]) begin
                sh_d[wi][k*8 +: 8] = wd[k*8 +: 8];
                sh_k[wi][k] = 1'b1;
              end
            end
            if (t.wstrb != '0) sh_wr[wi] = 1'b1;
            if (sh_inj[wi] != 0) begin
              il = sh_ilane[wi];
              if (f8(R_ECC, r) == `SG_ECC_SECDED && ws[il * (ECC_G / 8)]) sh_inj[wi] = 0;
              if (f8(R_ECC, r) == `SG_ECC_PARITY && ws[il]) sh_inj[wi] = 0;
              if (f8(R_ECC, r) == `SG_ECC_NONE && t.wstrb != '0) sh_inj[wi] = 0;
            end
          end
        end
      end
      // 3) responses
      for (int p = 0; p < NP; p++) begin
        if (rsp_valid[p] && rsp_ready[p]) begin
          exp_t e;
          logic [DW-1:0] got, edt;
          logic [NBY-1:0] ekm;
          if (exp_rd[p] == exp_wr[p]) begin
            fail($sformatf("port %0d: response without an issued request (tag %0h)", p, rsp_tag[p*TAG_W +: TAG_W]));
          end else begin
            e = exp_ring[p][exp_rd[p] % 64];
            exp_rd[p]++;
            checks++;
            got = rsp_rdata[p*DW +: DW];
            last_rsp[p] = got;
            if (rsp_tag[p*TAG_W +: TAG_W] != e.tag)
              fail($sformatf("port %0d: tag %0h, expected %0h (order)", p, rsp_tag[p*TAG_W +: TAG_W], e.tag));
            if (rsp_we[p] != e.we) fail($sformatf("port %0d tag %0h: rsp_we %0b expected %0b", p, e.tag, rsp_we[p], e.we));
            if (!e.dc && (rsp_err_code[p*3 +: 3] != e.err || rsp_err[p] != (e.err != 0)))
              fail($sformatf("port %0d tag %0h: err %0d expected %0d", p, e.tag, rsp_err_code[p*3 +: 3], e.err));
            if (!e.dc && rsp_ce[p] != e.ce) fail($sformatf("port %0d tag %0h: rsp_ce %0b expected %0b", p, e.tag, rsp_ce[p], e.ce));
            if (e.dc) n_dc++;
            ekm = e.kmask;
            edt = e.data;
            for (int k = 0; k < NBY; k++)
              if (!e.dc && (e.we || e.err != 0 || ekm[k]) && got[k*8 +: 8] !== (e.we ? 8'h00 : edt[k*8 +: 8]))
                fail($sformatf("port %0d tag %0h: rdata byte %0d = %02h, expected %02h (word %0d)",
                               p, e.tag, k, got[k*8 +: 8], edt[k*8 +: 8], e.widx));
            if (!e.we && e.err == 0) begin
              int l;
              l = cyc - int'(e.t_acc);
              lat_sum[p] += l; n_lat[p]++;
              if (l < lat_min[p]) lat_min[p] = l;
              if (l > lat_max[p]) lat_max[p] = l;
            end
          end
        end
        if (ev_conflict[p])     n_cfl[p]++;
        if (ev_credit_stall[p]) n_crs[p]++;
        if (ev_block_stall[p])  n_blk[p]++;
      end
      for (int b = 0; b < NBT; b++) bank_ops_tb[b] += int'(ev_bank_ops[b*2 +: 2]);
      for (int b = 0; b < NBT; b++) if (ev_rdw_split[b]) rdw_splits++;
      for (int r = 0; r < NR; r++) begin
        if (ras_ev_valid[r]) begin
          if (ras_ev_ce[r]) ras_n_ce[r]++;
          if (ras_ev_ue[r]) ras_n_ue[r]++;
          ras_last_addr[r] = ras_ev_addr[r*AW +: AW];
        end
        if (ras_ev_lost[r]) ras_n_lost[r]++;
      end
    end
  end

  // ============================================================ backdoor (bank arrays of the GENERIC backend)
  event             bd_ev;
  int               bd_b, bd_row, bd_op, bd_bit;
  logic [TSW-1:0]   bd_data, bd_mask;
  for (genvar b = 0; b < NBT; b++) begin : g_bd
    localparam int BSW = bsw(b);
    always @(bd_ev) begin
      if (bd_b == b) begin
        if (bd_op == 0)
          bd_data = TSW'(u_dut.g_bank[b].u_bank.u_mw.g_mem.u_mem.g_generic.u_mem.mem[bd_row]);
        else if (bd_op == 1)
          u_dut.g_bank[b].u_bank.u_mw.g_mem.u_mem.g_generic.u_mem.mem[bd_row] =
            u_dut.g_bank[b].u_bank.u_mw.g_mem.u_mem.g_generic.u_mem.mem[bd_row] ^ bd_mask[BSW-1:0];
      end
    end
  end
  task automatic backdoor(input int b, input int row, input int op, input logic [TSW-1:0] mask);
    bd_b = b; bd_row = row; bd_op = op; bd_mask = mask;
    -> bd_ev;
    #1;
  endtask

  // data bits of a stored word (strip parity / check bits)
  function automatic logic [DW-1:0] stored_data(input int r, input logic [TSW-1:0] sw);
    stored_data = '0;
    if (f8(R_ECC, r) == `SG_ECC_PARITY) begin
      for (int k = 0; k < NBY; k++) stored_data[k*8 +: 8] = sw[k*9 +: 8];
    end else if (f8(R_ECC, r) == `SG_ECC_SECDED) begin
      for (int g = 0; g < DW / ECC_G; g++) stored_data[g*ECC_G +: ECC_G] = sw[g*GN +: ECC_G];
    end else begin
      stored_data = sw[DW-1:0];
    end
  endfunction

  // ============================================================ helpers
  // The stimulus thread acts 1 ns after a rising edge: after the monitor (posedge) and
  // before the driver (negedge), so both simulators order it identically.
  task automatic tick(input int n);
    repeat (n) @(posedge clk);
    #1;
  endtask
  function automatic logic idle();
    idle = 1'b1;
    for (int p = 0; p < NP; p++)
      if (tx_rd[p] != tx_wr[p] || acc_rd[p] != acc_wr[p] || exp_rd[p] != exp_wr[p] || req_valid[p]) idle = 1'b0;
  endfunction
  task automatic drain(input int limit);
    int t;
    t = 0;
    while (!idle() && t < limit) begin @(posedge clk); #1; t++; end
    @(posedge clk); #1;
    if (!idle()) fail($sformatf("traffic did not drain within %0d cycles", limit));
  endtask
  task automatic wait_init();
    int t;
    t = 0;
    @(posedge clk); #1;
    while (init_busy && t < 200000) begin @(posedge clk); #1; t++; end
    if (init_busy) fail("init sweep did not finish");
  endtask
  function automatic int port_for(input int r);   // a port wired to region r (rotating)
    int c, k;
    c = rnd(NP);
    port_for = -1;
    for (k = 0; k < NP; k++) if (port_for < 0 && reach((c + k) % NP, r)) port_for = (c + k) % NP;
  endfunction
  function automatic logic [DW-1:0] rdata64();
    for (int k = 0; k < DW; k += 64) rdata64[k +: 64] = rnd64();
  endfunction
  function automatic logic [NBY-1:0] legal_strobe(input int r);
    logic [NBY-1:0] s;
    if (f8(R_ECC, r) == `SG_ECC_SECDED) begin
      s = '0;
      for (int g = 0; g < DW / ECC_G; g++) if (rnd(4) != 0) s[g*(ECC_G/8) +: ECC_G/8] = '1;
    end else if (f8(R_BWE, r) == 0) s = '1;
    else s = (rnd(3) == 0) ? '1 : NBY'(rnd64());
    legal_strobe = s;
  endfunction
  function automatic int gap();
    gap = (rnd(100) < gap_pct) ? rnd(4) : 0;
  endfunction

  // RNG draws in a fixed statement order (SystemVerilog leaves argument evaluation
  // order unspecified; Verilator and Icarus differ)
  task automatic enq_rnd(input int p, input logic we, input logic [AW-1:0] a, input int r, input int usegap);
    logic [DW-1:0]  d;
    logic [NBY-1:0] st;
    int             g;
    d  = rdata64();
    st = legal_strobe(r);
    g  = usegap ? gap() : 0;
    if (we) enq(p, 1'b1, a, d, st, g);
    else    enq(p, 1'b0, a, '0, '0, g);
  endtask

  // random traffic on every port to the regions it is wired to (plus a few errors)
  task automatic random_traffic(input int n, input int err_pct);
    for (int i = 0; i < n; i++) begin
      for (int p = 0; p < NP; p++) begin
        int r, w;
        logic [AW-1:0] a;
        r = rnd(NR);
        if (!reach(p, r)) begin
          int k;
          for (k = 0; k < NR; k++) if (!reach(p, r)) r = (r + 1) % NR;
        end
        w = rnd(rwords(r));
        a = addr_of(r, w);
        if (rnd(100) < err_pct) begin
          int sel;
          sel = rnd(3);                                            // not in the case head: evaluated once
          case (sel)
            0: a = a + AW'(1 + rnd(NBY - 1));                      // misaligned
            1: a = AW'(rbase(r) + rbytes(r));                      // just past the window (may hit a neighbour)
            default: a = AW'(rbase(r) - 64'(NBY));                 // just below
          endcase
        end
        enq_rnd(p, rnd(2) == 0, a, r, 1);
      end
    end
  endtask

  // physical audit: every written word sits in the bank / row the reference map predicts
  task automatic audit();
    int n;
    n = 0;
    for (int r = 0; r < NR; r++) begin
      for (int w = 0; w < rwords(r); w++) begin
        int wi, gb, row;
        wi = word_base(r) + w;
        if (sh_wr[wi] && sh_inj[wi] == 0) begin
          logic [DW-1:0] d;
          bank_row(r, w, gb, row);
          backdoor(gb, row, 0, '0);
          d = stored_data(r, bd_data);
          for (int k = 0; k < NBY; k++)
            if (sh_k[wi][k] && d[k*8 +: 8] !== sh_d[wi][k*8 +: 8])
              fail($sformatf("audit: region %0d word %0d not found in bank %0d row %0d (byte %0d %02h vs %02h)",
                             r, w, gb, row, k, d[k*8 +: 8], sh_d[wi][k*8 +: 8]));
          n++;
        end
      end
    end
    $display("[tb] audit: %0d written words found at their predicted bank / row", n);
    checks += n;
  endtask

  // init sweep coverage: every row of every bank holds all-zero data (with valid parity / check bits:
  // reading them later is checked by the scoreboard)
  task automatic audit_init();
    int n;
    n = 0;
    for (int r = 0; r < NR; r++) begin
      for (int w = 0; w < rwords(r); w++) begin
        int gb, row;
        if (!sh_wr[word_base(r) + w]) begin            // skip words written (issued) since the sweep
          bank_row(r, w, gb, row);
          backdoor(gb, row, 0, '0);
          if (stored_data(r, bd_data) !== '0)
            fail($sformatf("init: region %0d word %0d (bank %0d row %0d) not cleared by the init sweep", r, w, gb, row));
          n++;
        end
      end
    end
    checks += n;
    $display("[tb] init audit: %0d words cleared by the init sweep", n);
  endtask

  // ============================================================ scenarios
  task automatic sc_bank_map();
    // every word of every region gets a unique, address-derived value through a wired port
    for (int r = 0; r < NR; r++) begin
      for (int w = 0; w < rwords(r); w++) begin
        int p;
        p = port_for(r);
        enq(p, 1'b1, addr_of(r, w), {DW/32{32'(addr_of(r, w)) ^ 32'hA5C3_0000}} ^ DW'(r), '1, 0);
      end
    end
    drain(400000);
    for (int r = 0; r < NR; r++)
      for (int w = 0; w < rwords(r); w++) enq(port_for(r), 1'b0, addr_of(r, w), '0, '0, 0);
    drain(400000);
    audit();
    // distribution: each bank of a region holds exactly words/banks words (bijective map)
    for (int r = 0; r < NR; r++) begin
      int cnt [16];
      for (int j = 0; j < 16; j++) cnt[j] = 0;
      for (int w = 0; w < rwords(r); w++) begin
        int gb, row;
        bank_row(r, w, gb, row);
        cnt[gb - bank_base(r)]++;
      end
      for (int j = 0; j < f8(R_NB, r); j++)
        if (cnt[j] != rwords(r) / f8(R_NB, r)) fail($sformatf("region %0d bank %0d gets %0d words", r, j, cnt[j]));
    end
  endtask

  task automatic sc_boundary();
    // per region: first / last word, one past the end, one below, misaligned, unreachable ports
    for (int r = 0; r < NR; r++) begin
      for (int p = 0; p < NP; p++) begin
        logic [AW-1:0] lo, hi;
        lo = addr_of(r, 0);
        hi = addr_of(r, rwords(r) - 1);
        enq(p, 1'b1, lo, {DW/16{16'h1111 * 16'(r + 1)}}, '1, 0);
        enq(p, 1'b1, hi, {DW/16{16'h2222 * 16'(r + 1)}}, '1, 0);
        enq(p, 1'b1, AW'(rbase(r) + rbytes(r)), '1, '1, 0);          // past the end: other region or UNMAPPED
        if (rbase(r) >= 64'(NBY)) enq(p, 1'b1, AW'(rbase(r) - 64'(NBY)), '1, '1, 0);
        enq(p, 1'b1, lo + AW'(NBY / 2), '1, '1, 0);                   // misaligned
        enq(p, 1'b0, lo, '0, '0, 0);
        enq(p, 1'b0, hi, '0, '0, 0);
        enq(p, 1'b0, lo + AW'(1), '0, '0, 0);
      end
    end
    // holes and the top of the address space
    for (int p = 0; p < NP; p++) begin
      enq(p, 1'b0, {AW{1'b1}} & ~AW'(NBY - 1), '0, '0, 0);
      enq(p, 1'b1, AW'(64'h0FFF_0000), '1, '1, 0);
    end
    drain(100000);
    audit();
  endtask

  task automatic sc_byte_en(input int n);
    for (int i = 0; i < n; i++) begin
      for (int p = 0; p < NP; p++) begin
        int r, w;
        r = rnd(NR);
        if (reach(p, r)) begin
          w = rnd(rwords(r) < 64 ? rwords(r) : 64);            // small window: many merges per word
          begin
            logic [DW-1:0] dd; logic [NBY-1:0] ss; int gg;
            dd = rdata64();
            ss = (rnd(4) == 0) ? NBY'(rnd64()) : legal_strobe(r);
            gg = gap();
            enq(p, 1'b1, addr_of(r, w), dd, ss, gg);
          end
          if (rnd(3) == 0) enq(p, 1'b0, addr_of(r, w), '0, '0, gap());
        end
      end
    end
    drain(200000);
    for (int r = 0; r < NR; r++) for (int w = 0; w < (rwords(r) < 64 ? rwords(r) : 64); w++) enq(port_for(r), 1'b0, addr_of(r, w), '0, '0, 0);
    drain(200000);
    audit();
  endtask

  // every wired port hammers ONE bank: arbitration, fairness, port limits
  task automatic sc_conflict(input int n);
    for (int r = 0; r < NR; r++) begin
      int ws [16], nw;
      nw = 0;
      for (int w = 0; w < rwords(r) && nw < 16; w++) begin
        int gb, row;
        bank_row(r, w, gb, row);
        if (gb == bank_base(r)) begin ws[nw] = w; nw++; end
      end
      for (int i = 0; i < n; i++)
        for (int p = 0; p < NP; p++)
          if (reach(p, r)) begin
            int w;
            w = ws[rnd(nw)];
            enq_rnd(p, rnd(2) == 0, addr_of(r, w), r, 0);
          end
      drain(200000);
    end
  endtask

  // same-cycle read and write of one word from two ports
  int n_policy = 0;
  task automatic sc_rdw();
    int pairs;
    pairs = 0;
    for (int r = 0; r < NR; r++) begin
      int pa, pb;
      pa = -1; pb = -1;
      for (int p = 0; p < NP; p++) if (reach(p, r)) begin if (pa < 0) pa = p; else if (pb < 0) pb = p; end
      if (pb >= 0) begin
        for (int i = 0; i < 16; i++) begin
          logic [AW-1:0] a;
          logic [DW-1:0] oldv, newv;
          int wi, t0, t1;
          a = addr_of(r, rnd(rwords(r)));
          oldv = rdata64(); newv = rdata64();
          enq(pa, 1'b1, a, oldv, '1, 0);
          drain(1000);
          // both presented in the same cycle (queues empty, gap 0)
          enq(pa, 1'b1, a, newv, '1, 0);
          enq(pb, 1'b0, a, '0, '0, 0);
          t0 = exp_wr[pb];
          drain(1000);
          pairs++;
          if (f8(R_PM, r) == `SG_PORT_1R1W) begin
            logic [DW-1:0] want;
            want = (RDW == `SG_RDW_WRITE_FIRST) ? newv : oldv;
            checks++;
            if (last_rsp[pb] !== want)
              fail($sformatf("rdw: region %0d same-cycle read returned %0h, policy %s expects %0h", r, last_rsp[pb],
                             (RDW == `SG_RDW_WRITE_FIRST) ? "WRITE_FIRST" : "READ_FIRST", want));
            else n_policy++;
          end
        end
      end
    end
    $display("[tb] rdw: %0d same-cycle read/write pairs, %0d split by the RDW policy, %0d policy outcomes checked",
             pairs, rdw_splits, n_policy);
  endtask

  // DMA-style streaming fill / read-back on the widest port while the others run random traffic
  task automatic sc_dma(input int n);
    int pd, best;
    pd = 0; best = 0;
    for (int p = 0; p < NP; p++) begin
      int c;
      c = 0;
      for (int r = 0; r < NR; r++) if (reach(p, r)) c++;
      if (c > best) begin best = c; pd = p; end
    end
    for (int r = 0; r < NR; r++) begin
      if (reach(pd, r)) begin
        int len;
        len = rwords(r) < n ? rwords(r) : n;
        for (int w = 0; w < len; w++) enq(pd, 1'b1, addr_of(r, w), {DW/32{32'(w) ^ 32'hD3A0_0000}}, '1, 0);
        for (int w = 0; w < len; w++) enq(pd, 1'b0, addr_of(r, w), '0, '0, 0);
      end
    end
    for (int p = 0; p < NP; p++) if (p != pd) begin
      for (int i = 0; i < n / 2; i++) begin
        int r;
        r = rnd(NR);
        if (reach(p, r)) begin
          int w;
          w = rwords(r) / 2 + rnd(rwords(r) / 2);
          enq_rnd(p, rnd(2) == 0, addr_of(r, w), r, 1);
        end
      end
    end
    drain(400000);
    audit();
  endtask

  // ECC / parity: injected stored-bit errors, corrected / detected / reported
  task automatic sc_ecc();
    int ninj;
    ninj = 0;
    for (int r = 0; r < NR; r++) begin
      if (f8(R_ECC, r) != `SG_ECC_NONE) begin
        for (int i = 0; i < 24; i++) begin
          int w, wi, gb, row, nflip, lane;
          logic [TSW-1:0] m;
          logic [AW-1:0] a;
          int ce0, ue0;
          w  = rnd(rwords(r));
          a  = addr_of(r, w);
          wi = word_base(r) + w;
          begin
            int pp; logic [DW-1:0] dd;
            pp = port_for(r); dd = rdata64();
            enq(pp, 1'b1, a, dd, '1, 0);
          end
          drain(2000);
          bank_row(r, w, gb, row);
          nflip = (i % 3 == 2) ? 2 : 1;
          m = '0;
          if (f8(R_ECC, r) == `SG_ECC_SECDED) begin
            int b0, b1;
            lane = 0;
            b0 = rnd(GN);
            b1 = (b0 + 1 + rnd(GN - 1)) % GN;
            m[b0] = 1'b1;
            if (nflip == 2) m[b1] = 1'b1;
          end else begin
            int bt;
            lane = rnd(NBY);
            bt   = rnd(9);                                   // never inside an assignment target (evaluation differs)
            m[lane*9 + bt] = 1'b1;
            nflip = 1;
          end
          @(negedge clk);
          backdoor(gb, row, 1, m);
          sh_inj[wi] = nflip; sh_ilane[wi] = lane;
          ce0 = ras_n_ce[r]; ue0 = ras_n_ue[r];
          enq(port_for(r), 1'b0, a, '0, '0, 0);
          drain(2000);
          if (f8(R_ECC, r) == `SG_ECC_SECDED && nflip == 1 && ras_n_ce[r] != ce0 + 1)
            fail($sformatf("region %0d: corrected error not reported as a RAS CE event", r));
          if ((f8(R_ECC, r) == `SG_ECC_PARITY || nflip == 2) && ras_n_ue[r] != ue0 + 1)
            fail($sformatf("region %0d: detected error not reported as a RAS UE event", r));
          if (ras_last_addr[r] !== a)
            fail($sformatf("region %0d: RAS event address %0h, expected %0h", r, ras_last_addr[r], a));
          // scrub by rewriting; the next read must be clean
          begin
            int pp; logic [DW-1:0] dd;
            pp = port_for(r); dd = rdata64();
            enq(pp, 1'b1, a, dd, '1, 0);
          end
          enq(port_for(r), 1'b0, a, '0, '0, 0);
          drain(2000);
          ninj++;
        end
      end
    end
    $display("[tb] ecc: %0d injections (single / double), RAS CE/UE events checked", ninj);
  endtask

  task automatic sc_wprot();
    for (int r = 0; r < NR; r++) begin
      if (f8(R_WP, r) != 0) begin
        int p;
        p = port_for(r);
        wp_lock = 1'b0;
        enq(p, 1'b1, addr_of(r, 3), {DW/32{32'hB007_0003}}, '1, 0);
        drain(1000);
        @(negedge clk); #1 wp_lock = 1'b1;                 // after the driver's falling-edge step
        enq(p, 1'b1, addr_of(r, 3), '1, '1, 0);      // refused: WPROT, no side effect
        enq(p, 1'b0, addr_of(r, 3), '0, '0, 0);      // still readable
        drain(1000);
        @(negedge clk); #1 wp_lock = 1'b0;
      end
    end
  endtask

  task automatic sc_mbist(input logic with_fault);
    int b_f, row_f;
    b_f = -1; row_f = 0;
    // functional requests presented during the test stall and complete after re-init
    @(negedge clk);
    mb_start = 1'b1;
    @(negedge clk);
    mb_start = 1'b0;
    if (with_fault) begin
      // first 1RW bank (the generic 1RW model carries the fault hooks): SA0 on stored bit 3 of a mid row
      for (int b = NBT - 1; b >= 0; b--) begin
        int r;
        r = 0;
        for (int k = 0; k < NR; k++) if (b >= bank_base(k)) r = k;
        if (f8(R_PM, r) == `SG_PORT_1RW) b_f = b;
      end
    end
    random_traffic(4, 0);
    while (!mb_done) begin @(posedge clk); #1; end
    if (!with_fault) begin
      if (!mb_pass) fail($sformatf("MBIST fault-free run failed: mask %0h target %0d addr %0d elem %0d",
                                   mb_fail_mask, mb_fail_tgt, mb_fail_addr, mb_fail_elem));
      else $display("[tb] mbist: March C- over %0d banks passed", NBT);
    end
    wait_init();
    if (`SGC_INIT_AFTER_TEST != 0 && !with_fault) audit_init();
    drain(200000);
    // functional traffic after MBIST + re-init sees zeros (checked by the scoreboard)
    for (int r = 0; r < NR; r++) for (int i = 0; i < 8; i++) begin
      int pp, ww;
      pp = port_for(r); ww = rnd(rwords(r));
      enq(pp, 1'b0, addr_of(r, ww), '0, '0, 0);
    end
    drain(20000);
    if (with_fault && b_f >= 0) begin
      row_f = 5;
      fault_set(b_f, 1, row_f, 3);
      @(negedge clk); mb_start = 1'b1; @(negedge clk); mb_start = 1'b0;
      while (!mb_done) begin @(posedge clk); #1; end
      if (mb_pass || int'(mb_fail_tgt) != b_f || int'(mb_fail_addr) != row_f || mb_fail_elem != 3'd2)
        fail($sformatf("MBIST SA0 bank %0d row %0d: got pass %0b target %0d addr %0d elem %0d (expected element 2)",
                       b_f, row_f, mb_pass, mb_fail_tgt, mb_fail_addr, mb_fail_elem));
      else $display("[tb] mbist: SA0 in bank %0d row %0d detected (target %0d, addr %0d, element %0d, syndrome %0h)",
                    b_f, row_f, mb_fail_tgt, mb_fail_addr, mb_fail_elem, mb_fail_syn);
      fault_set(b_f, 0, 0, 0);
      wait_init();
    end
  endtask

  // generic 1RW fault hooks (sram_generic_1rw flt_*), only on 1RW banks
  event fl_ev;
  int   fl_b, fl_kind, fl_addr, fl_bit;
  for (genvar b = 0; b < NBT; b++) begin : g_flt
    localparam int BR = c_region_of_bank(b);
    if (f8(R_PM, BR) == `SG_PORT_1RW) begin : g_on
      always @(fl_ev) begin
        if (fl_b == b) begin
          u_dut.g_bank[b].u_bank.u_mw.g_mem.u_mem.g_generic.u_mem.flt_kind = fl_kind;
          u_dut.g_bank[b].u_bank.u_mw.g_mem.u_mem.g_generic.u_mem.flt_addr = fl_addr;
          u_dut.g_bank[b].u_bank.u_mw.g_mem.u_mem.g_generic.u_mem.flt_bit  = fl_bit;
        end
      end
    end
  end
  task automatic fault_set(input int b, input int kind, input int addr, input int bitn);
    fl_b = b; fl_kind = kind; fl_addr = addr; fl_bit = bitn;
    -> fl_ev;
    #1;
  endtask

  // asynchronous reset in the middle of traffic
  task automatic sc_reset();
    random_traffic(40, 2);
    tick(30 + rnd(40));
    #3;                                   // between clock edges: asynchronous assertion
    rst_n = 1'b0;
    for (int p = 0; p < NP; p++) begin
      tx_rd[p] = tx_wr[p]; acc_rd[p] = acc_wr[p]; exp_rd[p] = exp_wr[p];
      req_valid[p] = 1'b0; accepted[p] = 1'b0; gap_ctr[p] = 0;
    end
    // words with a write accepted but not yet acknowledged are unknown after reset
    // (here every word becomes unknown unless an init sweep redefines it)
    if (`SGC_INIT_ON_RESET == 0) begin
      for (int i = 0; i < TOTW; i++) begin sh_k[i] = '0; sh_wr[i] = 1'b0; end
    end
    tick(3);
    #2 rst_n = 1'b1;
    if (`SGC_INIT_ON_RESET != 0) wait_init();
    tick(2);
    random_traffic(40, 2);
    drain(200000);
    audit();
  endtask

  // the region every port is wired to (the shared SRAM); region 0 if none
  function automatic int shared_region();
    shared_region = 0;
    for (int k = NR - 1; k >= 0; k--) begin
      logic all;
      all = 1'b1;
      for (int q = 0; q < NP; q++) if (!reach(q, k)) all = 1'b0;
      if (all) shared_region = k;
    end
  endfunction

  // performance patterns (metrics only; correctness still checked)
  int pf_t0, pf_cyc;
  task automatic perf_reset();
    for (int p = 0; p < NP; p++) begin
      n_rd[p] = 0; n_wr[p] = 0; n_err[p] = 0; n_cfl[p] = 0; n_crs[p] = 0; n_blk[p] = 0;
      lat_sum[p] = 0; lat_min[p] = 1 << 30; lat_max[p] = 0; n_lat[p] = 0;
    end
    for (int b = 0; b < NBT; b++) bank_ops_tb[b] = 0;
    pf_t0 = cyc;
  endtask
  task automatic sc_perf(input string pat, input int n);
    perf_reset();
    for (int i = 0; i < n; i++) begin
      for (int p = 0; p < NP; p++) begin
        int r, w, nb;
        // home region of the port: the first wired non-shared region if any, else the first wired region
        r = -1;
        for (int k = NR - 1; k >= 0; k--) if (reach(p, k)) r = k;
        for (int k = NR - 1; k >= 0; k--) if (reach(p, k) && f8(R_NB, k) > 1 && pat == "local") r = k;
        if (pat == "shared_seq" || pat == "shared_stride" || pat == "shared_rand") r = shared_region();
        if (r >= 0) begin
          nb = f8(R_NB, r);
          if (pat == "shared_stride") w = (i * nb + p * nb * 7) % rwords(r);         // stride = banks words: one bank under LOW
          else if (pat == "shared_rand") w = rnd(rwords(r));
          else w = (i + p * (rwords(r) / NP)) % rwords(r);                          // unit stride, per-port offset
          enq_rnd(p, (i % 4) == 3, addr_of(r, w), r, 0);
        end
      end
    end
    drain(400000);
    pf_cyc = cyc - pf_t0;
    print_metrics(pat);
  endtask

  task automatic print_metrics(input string pat);
    longint bytes;
    bytes = 0;
    for (int p = 0; p < NP; p++) bytes += longint'(n_rd[p] + n_wr[p]) * NBY;
    $write("METRICS {\"cfg\":\"%s\",\"pattern\":\"%s\",\"cycles\":%0d,\"bytes\":%0d,\"ports\":[", `SGC_NAME, pat, pf_cyc, bytes);
    for (int p = 0; p < NP; p++) begin
      $write("{\"p\":%0d,\"rd\":%0d,\"wr\":%0d,\"err\":%0d,\"conflict\":%0d,\"credit_stall\":%0d,\"block_stall\":%0d,\"lat_min\":%0d,\"lat_max\":%0d,\"lat_avg_x100\":%0d}%s",
             p, n_rd[p], n_wr[p], n_err[p], n_cfl[p], n_crs[p], n_blk[p], (n_lat[p] > 0) ? lat_min[p] : 0, lat_max[p],
             (n_lat[p] > 0) ? int'((lat_sum[p] * 100) / n_lat[p]) : 0, (p == NP - 1) ? "" : ",");
    end
    $write("],\"bank_ops\":[");
    for (int b = 0; b < NBT; b++) $write("%0d%s", bank_ops_tb[b], (b == NBT - 1) ? "" : ",");
    $display("]}");
  endtask

  // RTL counters agree with the testbench's event counts
  task automatic check_perf_counters();
    for (int b = 0; b < NBT; b++) begin
      if (int'(perf_bank_ops[b*CNT_W +: CNT_W]) != bank_ops_tb_total[b])
        fail($sformatf("perf_bank_ops[%0d] = %0d, testbench counted %0d", b, perf_bank_ops[b*CNT_W +: CNT_W], bank_ops_tb_total[b]));
    end
  endtask
  int bank_ops_tb_total [NBT];
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) for (int b = 0; b < NBT; b++) bank_ops_tb_total[b] = 0;
    else        for (int b = 0; b < NBT; b++) bank_ops_tb_total[b] += int'(ev_bank_ops[b*2 +: 2]);
  end

  // ============================================================ main
  string scen;
  int    seed, nops;
  initial begin
    for (int p = 0; p < NP; p++) begin
      tx_rd[p] = 0; tx_wr[p] = 0; acc_rd[p] = 0; acc_wr[p] = 0; exp_rd[p] = 0; exp_wr[p] = 0;
      gap_ctr[p] = 0; accepted[p] = 1'b0; tagc[p] = '0;
    end
    for (int r = 0; r < NR; r++) begin ras_n_ce[r] = 0; ras_n_ue[r] = 0; ras_n_lost[r] = 0; ras_last_addr[r] = '0; end
    for (int b = 0; b < NBT; b++) bank_ops_tb_total[b] = 0;
    req_valid = '0; req_we = '0; req_addr = '0; req_wdata = '0; req_wstrb = '0; req_tag = '0; rsp_ready = '1;
    perf_reset();
    shadow_init(1'b0);
    if (!$value$plusargs("SCEN=%s", scen)) scen = "smoke";
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    if (!$value$plusargs("BP=%d", bp_pct)) bp_pct = 0;
    if (!$value$plusargs("GAP=%d", gap_pct)) gap_pct = 0;
    if (!$value$plusargs("N=%d", nops)) nops = 200;
    rng   = 64'h9E3779B97F4A7C15 ^ (64'(seed) * 64'hD1B54A32D192ED03);
    rng_d = 64'hC2B2AE3D27D4EB4F ^ (64'(seed) * 64'h94D049BB133111EB);
    $display("[tb] config %s: %0d ports, %0d regions, %0d banks, DW %0d, scenario %s, seed %0d, bp %0d%%, gap %0d%%",
             `SGC_NAME, NP, NR, NBT, DW, scen, seed, bp_pct, gap_pct);
    tick(3);
    #2 rst_n = 1'b1;
    if (`SGC_INIT_ON_RESET != 0) begin
      wait_init();
      audit_init();
    end
    tick(2);

    if (scen == "smoke") begin
      random_traffic(nops / 4 + 1, 0); drain(100000); audit();
    end else if (scen == "bank_map")  begin sc_bank_map();
    end else if (scen == "boundary")  begin sc_boundary();
    end else if (scen == "byte_en")   begin sc_byte_en(nops);
    end else if (scen == "conflict")  begin perf_reset(); sc_conflict(nops); pf_cyc = cyc - pf_t0; print_metrics("conflict");
    end else if (scen == "rdw")       begin sc_rdw();
    end else if (scen == "dma")       begin perf_reset(); sc_dma(nops); pf_cyc = cyc - pf_t0; print_metrics("dma");
    end else if (scen == "ecc")       begin sc_ecc();
    end else if (scen == "wprot")     begin sc_wprot();
    end else if (scen == "mbist")     begin sc_mbist(1'b0); sc_mbist(1'b1);
    end else if (scen == "reset")     begin sc_reset();
    end else if (scen == "random")    begin random_traffic(nops, 3); drain(400000); audit();
    end else if (scen == "perf")      begin
      sc_perf("local", nops); sc_perf("shared_seq", nops); sc_perf("shared_stride", nops); sc_perf("shared_rand", nops);
    end else begin
      fail({"unknown scenario ", scen});
    end
    drain(10000);
    check_perf_counters();
    // nothing outstanding anywhere
    if (busy && !init_busy) fail("grid still busy at the end");
    if (n_dc > 0) $display("[tb] %0d reads of never-written integrity-protected words (undefined content) not data-checked", n_dc);
    $display("[tb] %0d responses + audits checked, %0d errors, %0d cycles", checks, errors, cyc);
    if (errors == 0 && checks > 0) $display("RESULT PASS %s %s seed=%0d", `SGC_NAME, scen, seed);
    else                           $display("RESULT FAIL %s %s seed=%0d", `SGC_NAME, scen, seed);
    $finish;
  end

  initial begin
    #(64'd400_000_000);
    $display("RESULT FAIL %s timeout", `SGC_NAME);
    $finish;
  end

endmodule

`default_nettype wire
