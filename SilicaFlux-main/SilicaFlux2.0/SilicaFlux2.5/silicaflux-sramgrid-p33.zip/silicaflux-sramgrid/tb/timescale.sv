// Compiled first: gives every following file without its own `timescale (the
// library leaves' SRAMLIB_VENDOR_MODELS #1 clock-to-q stand-in) a 1 ns unit in Icarus.
`timescale 1ns/1ps
