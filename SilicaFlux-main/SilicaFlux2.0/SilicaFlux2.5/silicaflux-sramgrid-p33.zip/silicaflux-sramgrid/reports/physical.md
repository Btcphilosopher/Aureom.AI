# Physical placement checks

Scaling gate: {'sg_min4_sim_jobs': 47, 'sg_min4_sim_pass': 47, 'sg_min4_placement_ok': True, 'open': True} — `sg_hier` is placed only when `sg_min4`'s regression and placements are clean.

| Config | Strategy | Macros | Violations | Min spacing | Mock OpenDB | Weighted distance (estimate) |
|---|---|---|---|---|---|---|
| sg_min4 | adjacent_vector | 12 | 0 | 40.32 µm | mock_odb: 12 of 12 instances placed, 14 blockages, 0 errors | 1.228 mm |
| sg_min4 | around_tensor | 12 | 0 | 40.32 µm | mock_odb: 12 of 12 instances placed, 14 blockages, 0 errors | 1.219 mm |
| sg_min4 | central_shared | 12 | 0 | 40.32 µm | mock_odb: 12 of 12 instances placed, 14 blockages, 0 errors | 1.171 mm |
| sg_min4 | perimeter | 12 | 0 | 40.32 µm | mock_odb: 12 of 12 instances placed, 14 blockages, 0 errors | 1.556 mm |
| sg_hier | adjacent_vector | 69 | 0 | 40.27 µm | mock_odb: 69 of 69 instances placed, 71 blockages, 0 errors | 1.792 mm |
| sg_hier | around_tensor | 69 | 0 | 40.27 µm | mock_odb: 69 of 69 instances placed, 71 blockages, 0 errors | 1.887 mm |
| sg_hier | central_shared | 69 | 0 | 40.27 µm | mock_odb: 69 of 69 instances placed, 71 blockages, 0 errors | 1.652 mm |
| sg_hier | perimeter | 69 | 0 | 40.27 µm | mock_odb: 69 of 69 instances placed, 71 blockages, 0 errors | 3.219 mm |

Checker self-test on `sg_min4`: 15/15 mutations caught:

* overlap: macro 1 onto macro 0 → C6 (caught)
* channel: macro 1 abutting macro 0 (10 um gap) → C6, C7, C8 (caught)
* outside the core → C5, C8 (caught)
* into a placement blockage → C5, C7, C8 (caught)
* into a logic block → C7 (caught)
* off the site grid (+0.24 um) → C4 (caught)
* off the manufacturing grid (+0.001 um) → C4 (caught)
* orientation R90 → C3, C6, C8, C9 (caught)
* orientation MY (LEF-legal, not allowed by the floorplan) → C3, C9 (caught)
* missing instance → C1 (caught)
* duplicate instance → C1, C6 (caught)
* unknown instance name → C1 (caught)
* wrong master → C2, C9 (caught)
* Tcl / DEF mismatch → C9 (caught)
* pins facing the core edge → C6, C8 (caught)

Checker self-test on `sg_hier`: 15/15 mutations caught:

* overlap: macro 1 onto macro 0 → C6 (caught)
* channel: macro 1 abutting macro 0 (10 um gap) → C6 (caught)
* outside the core → C5, C6, C8 (caught)
* into a placement blockage → C5, C7, C8 (caught)
* into a logic block → C6, C7, C8 (caught)
* off the site grid (+0.24 um) → C4 (caught)
* off the manufacturing grid (+0.001 um) → C4 (caught)
* orientation R90 → C3, C6, C8, C9 (caught)
* orientation MY (LEF-legal, not allowed by the floorplan) → C3, C9 (caught)
* missing instance → C1 (caught)
* duplicate instance → C1, C6 (caught)
* unknown instance name → C1 (caught)
* wrong master → C2, C9 (caught)
* Tcl / DEF mismatch → C9 (caught)
* pins facing the core edge → C6, C8 (caught)
