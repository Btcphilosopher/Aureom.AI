# Simulation regression

Tools: Verilator 5.020 2024-01-01 rev (Debian 5.020-1); Icarus Verilog version 12.0 (stable) ().

**232 / 232 runs pass; 2,309,176 checks** (each checked response = tag + order + we + error code + data bytes + corrected flag; plus every word of every audit read back through the backdoor from the bank / row the reference map predicts).

Verilator runs with `--assert -DSG_ASSERT` (protocol / arbiter / wrapper assertions), `SRAMLIB_POISON` (SRAM outputs X outside valid read slots) and `--x-assign unique --x-initial unique` (random power-up content, `+verilator+rand+reset+2`).  `sg_min4` seeds 1/2/3 and `sg_hier` seeds 1/2 use back-pressure / request gaps of 0/0, 20/20 and 50/10 %; the 13 variants seed 4 with 25/10 %; the `perf`, `conflict` and `dma` measurements of seeds 1 and 4 run without back-pressure.

| Configuration | smoke | bank_map | boundary | byte_en | conflict | dma | random | reset | mbist | perf | rdw | ecc | wprot | checks |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| r_1r1w_rf (Verilator) | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | – | 71,803 |
| r_1r1w_wf (Verilator) | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | – | 71,803 |
| r_2rw (Verilator) | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | – | 71,787 |
| r_dw128 (Verilator) | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | – | 71,884 |
| r_fixed (Verilator) | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | – | 71,782 |
| r_g32 (Verilator) | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | – | 71,875 |
| r_high (Verilator) | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | – | – | 67,736 |
| r_noinit (Verilator) | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | – | 22,778 |
| r_parity (Verilator) | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | – | 71,929 |
| r_pipe (Verilator) | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | – | 71,775 |
| r_slice0 (Verilator) | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | – | 71,783 |
| r_wordw (Verilator) | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | – | – | 67,722 |
| r_xor (Verilator) | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | – | 71,778 |
| sg_hier (Icarus) | 1/1 | – | – | 1/1 | – | – | – | – | – | – | 1/1 | 1/1 | 1/1 | 145,908 |
| sg_hier (Verilator) | 2/2 | 2/2 | 2/2 | 2/2 | 2/2 | 2/2 | 2/2 | 2/2 | 2/2 | 2/2 | 2/2 | 2/2 | 2/2 | 1,006,135 |
| sg_min4 (Icarus) | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | 1/1 | – | 1/1 | 1/1 | – | 65,310 |
| sg_min4 (Verilator) | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | 3/3 | – | 215,388 |

## Cross-simulation (same configuration, scenario, seed, settings)

| Config | Scenario | Icarus | Verilator | cycles (iv / vl) | checks (iv / vl) | identical |
|---|---|---|---|---|---|---|
| sg_hier | smoke | PASS | PASS | 5015 / 5015 | 29039 / 29039 | yes |
| sg_hier | byte_en | PASS | PASS | 5533 / 5533 | 29970 / 29970 | yes |
| sg_hier | rdw | PASS | PASS | 5900 / 5900 | 28976 / 28976 | yes |
| sg_hier | ecc | PASS | PASS | 7202 / 7202 | 29248 / 29248 | yes |
| sg_hier | wprot | PASS | PASS | 4929 / 4929 | 28675 / 28675 | yes |
| sg_min4 | smoke | PASS | PASS | 1527 / 1527 | 4303 / 4303 | yes |
| sg_min4 | bank_map | PASS | PASS | 5545 / 5545 | 16384 / 16384 | yes |
| sg_min4 | boundary | PASS | PASS | 1456 / 1456 | 4128 / 4128 | yes |
| sg_min4 | byte_en | PASS | PASS | 1896 / 1896 | 5010 / 5010 | yes |
| sg_min4 | conflict | PASS | PASS | 2039 / 2039 | 4696 / 4696 | yes |
| sg_min4 | dma | PASS | PASS | 1953 / 1953 | 4977 / 4977 | yes |
| sg_min4 | random | PASS | PASS | 1763 / 1763 | 4897 / 4897 | yes |
| sg_min4 | reset | PASS | PASS | 2585 / 2585 | 4351 / 4351 | yes |
| sg_min4 | mbist | PASS | PASS | 127878 / 127878 | 8228 / 8228 | yes |
| sg_min4 | rdw | PASS | PASS | 1590 / 1590 | 4144 / 4144 | yes |
| sg_min4 | ecc | PASS | PASS | 1785 / 1785 | 4192 / 4192 | yes |

## Scenario notes (seed 1 / variants)

* [tb] audit: 114 written words found at their predicted bank / row
* [tb] audit: 12 written words found at their predicted bank / row
* [tb] audit: 1260 written words found at their predicted bank / row
* [tb] audit: 183 written words found at their predicted bank / row
* [tb] audit: 193 written words found at their predicted bank / row
* [tb] audit: 2 written words found at their predicted bank / row
* [tb] audit: 240 written words found at their predicted bank / row
* [tb] audit: 253 written words found at their predicted bank / row
* [tb] audit: 261 written words found at their predicted bank / row
* [tb] audit: 263 written words found at their predicted bank / row
* [tb] audit: 281 written words found at their predicted bank / row
* [tb] audit: 283 written words found at their predicted bank / row
* [tb] audit: 286 written words found at their predicted bank / row
* [tb] audit: 28672 written words found at their predicted bank / row
* [tb] audit: 290 written words found at their predicted bank / row
* [tb] audit: 297 written words found at their predicted bank / row
* [tb] audit: 40 written words found at their predicted bank / row
* [tb] audit: 4096 written words found at their predicted bank / row
* [tb] audit: 436 written words found at their predicted bank / row
* [tb] audit: 48 written words found at their predicted bank / row
* [tb] audit: 49 written words found at their predicted bank / row
* [tb] audit: 50 written words found at their predicted bank / row
* [tb] audit: 51 written words found at their predicted bank / row
* [tb] audit: 53 written words found at their predicted bank / row
* [tb] audit: 54 written words found at their predicted bank / row
* [tb] audit: 63 written words found at their predicted bank / row
* [tb] audit: 64 written words found at their predicted bank / row
* [tb] audit: 65 written words found at their predicted bank / row
* [tb] audit: 67 written words found at their predicted bank / row
* [tb] audit: 70 written words found at their predicted bank / row
* [tb] audit: 90 written words found at their predicted bank / row
* [tb] ecc: 144 injections (single / double), RAS CE/UE events checked
* [tb] ecc: 24 injections (single / double), RAS CE/UE events checked
* [tb] mbist: March C- over 23 banks passed
* [tb] mbist: March C- over 4 banks passed
* [tb] mbist: SA0 in bank 0 row 5 detected (target 0, addr 5, element 2, syndrome 8)
* [tb] rdw: 16 same-cycle read/write pairs, 0 split by the RDW policy, 0 policy outcomes checked
* [tb] rdw: 16 same-cycle read/write pairs, 16 split by the RDW policy, 16 policy outcomes checked
* [tb] rdw: 96 same-cycle read/write pairs, 16 split by the RDW policy, 16 policy outcomes checked
