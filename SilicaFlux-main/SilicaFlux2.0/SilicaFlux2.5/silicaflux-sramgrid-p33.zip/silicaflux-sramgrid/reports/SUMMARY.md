# SRAMGRID — results summary (generated from reports/*.json)

* Simulation regression: **232/232** runs, 2,309,176 checks; cross-simulation identical 16/16.
* Macro wrapper vs vendor models: **13/13**.
* Lint: legal 19/19 clean; illegal RTL parameter sets refused 18/18 (Verilator + Icarus + Yosys); illegal JSON refused 15/15.
* Mutation testing: **20/20** killed.
* Synthesis: 7/7 targets meet their exact expectation.
* Placement: 8/8 placements clean; gate open.
* `sg_min4`: 32 KiB logical, 12 IHP macros = 1.6822 mm² (real LEF), grid logic 0.245 mm² (IHP cells, unplaced).
* `sg_hier`: 224 KiB logical, 69 IHP macros = 12.7632 mm² (real LEF), grid logic 1.1501 mm² (IHP cells, unplaced).
* Macro connectivity `sg_min4`: 12 macros, 0 anomalies.
* Macro connectivity `sg_hier`: 69 macros, 0 anomalies.
