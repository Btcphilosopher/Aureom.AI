# Macro connectivity — `sg_min4` (from the synthesized netlist)

Netlist `reports/synth/sg_min4_asic/netlist.json.gz` (Yosys 0.33, flattened, SRAM macros as the library's pin-only black boxes). 12 macro instances; **0 anomalies**.

Every pin bit is resolved to a constant or a net of the netlist. Checks: clock on the top-level `clk`; enables and every address bit driven by logic; data-in / mask bits driven for every stored bit the tile holds (padding bits tied 0); data-out bits of stored bits loaded; datasheet tie-offs (IHP `A_DLY = 1`, `A_BIST_* = 0`). Supply pins are not in the RTL netlist (`USE_POWER_PINS` off): the power-grid step must connect them (names / layers from the LEF).

| Instance (bank.row.col) | Master | Region (ports) | Stored bits | Words | CLK | A MEN/WEN/REN | A ADDR driven | A DIN driven / tied 0 | A BM driven / tied 0 | read DOUT loaded / unused | B ADDR driven | Tie-offs | Supply pins (LEF) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| b0.r0.c0 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` | shared (1rw) | 0–31 | 0–1023 | clk | drv/drv/drv | 10/10 | 32 / 0 | 32 / 0 | 32 / 0 | — | A_DLY=1, A_BIST_EN=0 | VSS!, VDD!, VDDARRAY! |
| b0.r0.c1 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` | shared (1rw) | 32–63 | 0–1023 | clk | drv/drv/drv | 10/10 | 32 / 0 | 32 / 0 | 32 / 0 | — | A_DLY=1, A_BIST_EN=0 | VSS!, VDD!, VDDARRAY! |
| b0.r0.c2 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` | shared (1rw) | 64–71 | 0–1023 | clk | drv/drv/drv | 10/10 | 8 / 24 | 32 / 0 | 8 / 24 | — | A_DLY=1, A_BIST_EN=0 | VSS!, VDD!, VDDARRAY! |
| b1.r0.c0 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` | shared (1rw) | 0–31 | 0–1023 | clk | drv/drv/drv | 10/10 | 32 / 0 | 32 / 0 | 32 / 0 | — | A_DLY=1, A_BIST_EN=0 | VSS!, VDD!, VDDARRAY! |
| b1.r0.c1 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` | shared (1rw) | 32–63 | 0–1023 | clk | drv/drv/drv | 10/10 | 32 / 0 | 32 / 0 | 32 / 0 | — | A_DLY=1, A_BIST_EN=0 | VSS!, VDD!, VDDARRAY! |
| b1.r0.c2 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` | shared (1rw) | 64–71 | 0–1023 | clk | drv/drv/drv | 10/10 | 8 / 24 | 32 / 0 | 8 / 24 | — | A_DLY=1, A_BIST_EN=0 | VSS!, VDD!, VDDARRAY! |
| b2.r0.c0 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` | shared (1rw) | 0–31 | 0–1023 | clk | drv/drv/drv | 10/10 | 32 / 0 | 32 / 0 | 32 / 0 | — | A_DLY=1, A_BIST_EN=0 | VSS!, VDD!, VDDARRAY! |
| b2.r0.c1 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` | shared (1rw) | 32–63 | 0–1023 | clk | drv/drv/drv | 10/10 | 32 / 0 | 32 / 0 | 32 / 0 | — | A_DLY=1, A_BIST_EN=0 | VSS!, VDD!, VDDARRAY! |
| b2.r0.c2 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` | shared (1rw) | 64–71 | 0–1023 | clk | drv/drv/drv | 10/10 | 8 / 24 | 32 / 0 | 8 / 24 | — | A_DLY=1, A_BIST_EN=0 | VSS!, VDD!, VDDARRAY! |
| b3.r0.c0 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` | shared (1rw) | 0–31 | 0–1023 | clk | drv/drv/drv | 10/10 | 32 / 0 | 32 / 0 | 32 / 0 | — | A_DLY=1, A_BIST_EN=0 | VSS!, VDD!, VDDARRAY! |
| b3.r0.c1 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` | shared (1rw) | 32–63 | 0–1023 | clk | drv/drv/drv | 10/10 | 32 / 0 | 32 / 0 | 32 / 0 | — | A_DLY=1, A_BIST_EN=0 | VSS!, VDD!, VDDARRAY! |
| b3.r0.c2 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` | shared (1rw) | 64–71 | 0–1023 | clk | drv/drv/drv | 10/10 | 8 / 24 | 32 / 0 | 8 / 24 | — | A_DLY=1, A_BIST_EN=0 | VSS!, VDD!, VDDARRAY! |
