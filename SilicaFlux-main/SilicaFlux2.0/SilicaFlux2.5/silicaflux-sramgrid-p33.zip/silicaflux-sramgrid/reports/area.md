# Memory area accounting

Macro areas are the **real** outlines of the IHP SG13G2 open-PDK SRAM macros (vendor LEF `SIZE`, `physical/abstracts/`). Logic area is the grid's own logic (decoders, arbiters, reorder buffers, ECC, pipelines, counters) mapped by Yosys to the IHP SG13G2 standard cells with the typical-corner Liberty: **unplaced cell area** — no utilisation factor, clock tree, buffering, tap / fill cells or routing. Footprint = macros each grown by one 40 µm routing channel (the FloorplanLab rule) — a planning figure. Nothing is scaled to another node.

## `sg_min4`

| Region | ECC | Logical | Stored word | ECC overhead | Stored bits | Macro × n (tile per bank) | Macro bits | Padding | Bit use | Macro area | Footprint | µm²/logical bit |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `shared` | secded | 32 KiB | 72 b | 12.5 % | 294,912 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 12 (3x1) | 393,216 | 98,304 | 75.0 % | 1.6822 mm² | 2.0629 mm² | 6.417 |
| **total** | | 32 KiB | | | 294,912 | 12 macros | 393,216 | 98,304 | 75.0 % | **1.6822 mm²** | 2.0629 mm² | 6.417 |

Grid logic (IHP SG13G2 cells, unplaced): **0.245 mm²**, 2121 flip-flops. Macros + logic: **1.9272 mm²**.

FPGA flow (Yosys `synth_xilinx`, 7-series): 8 RAMB36 + 0 RAMB18 (294,912 bits of block RAM for 294,912 stored bits).

ECC what-if (same banks and depth, smallest-footprint IHP macro per mode):

| Region | none | byte parity | SECDED |
|---|---|---|---|
| `shared` | 64 b → `RM_IHPSG13_1P_1024x64_c2_bm_bist` × 4 = 1.0558 mm² | 72 b → `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 12 = 1.6822 mm² | 72 b → `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 12 = 1.6822 mm² |

Placement experiments (die / core are planning assumptions; macro outlines real):

| Strategy | Macros placed | Core | Macro area / core |
|---|---|---|---|
| adjacent_vector | 12 (+0 unplaced) | 7.0515 mm² | 23.9 % |
| around_tensor | 12 (+0 unplaced) | 7.0515 mm² | 23.9 % |
| central_shared | 12 (+0 unplaced) | 7.0515 mm² | 23.9 % |
| perimeter | 12 (+0 unplaced) | 7.0515 mm² | 23.9 % |

## `sg_hier`

| Region | ECC | Logical | Stored word | ECC overhead | Stored bits | Macro × n (tile per bank) | Macro bits | Padding | Bit use | Macro area | Footprint | µm²/logical bit |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `boot` | parity | 8 KiB | 72 b | 12.5 % | 73,728 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 3 (3x1) | 98,304 | 24,576 | 75.0 % | 0.4205 mm² | 0.5157 mm² | 6.417 |
| `shared` | secded | 128 KiB | 72 b | 12.5 % | 1,179,648 | `RM_IHPSG13_1P_2048x32_c2_bm_bist` × 24 (3x1) | 1,572,864 | 393,216 | 75.0 % | 6.2666 mm² | 7.3066 mm² | 5.976 |
| `vec0_spm` | parity | 32 KiB | 72 b | 12.5 % | 294,912 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 12 (3x1) | 393,216 | 98,304 | 75.0 % | 1.6822 mm² | 2.0629 mm² | 6.417 |
| `vec1_spm` | parity | 32 KiB | 72 b | 12.5 % | 294,912 | `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 12 (3x1) | 393,216 | 98,304 | 75.0 % | 1.6822 mm² | 2.0629 mm² | 6.417 |
| `ten_opnd` | parity | 16 KiB | 72 b | 12.5 % | 147,456 | `RM_IHPSG13_2P_512x32_c2_bm_bist` × 12 (3x1) | 196,608 | 49,152 | 75.0 % | 1.8078 mm² | 2.2615 mm² | 13.792 |
| `ten_acc` | secded | 8 KiB | 72 b | 12.5 % | 73,728 | `RM_IHPSG13_2P_512x32_c2_bm_bist` × 6 (3x1) | 98,304 | 24,576 | 75.0 % | 0.9039 mm² | 1.1308 mm² | 13.792 |
| **total** | | 224 KiB | | | 2,064,384 | 69 macros | 2,752,512 | 688,128 | 75.0 % | **12.7632 mm²** | 15.3404 mm² | 6.955 |

Grid logic (IHP SG13G2 cells, unplaced): **1.1501 mm²**, 8594 flip-flops. Macros + logic: **13.9133 mm²**.

ECC what-if (same banks and depth, smallest-footprint IHP macro per mode):

| Region | none | byte parity | SECDED |
|---|---|---|---|
| `boot` | 64 b → `RM_IHPSG13_1P_1024x64_c2_bm_bist` × 1 = 0.2639 mm² | 72 b → `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 3 = 0.4205 mm² | 72 b → `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 3 = 0.4205 mm² |
| `shared` | 64 b → `RM_IHPSG13_1P_2048x64_c2_bm_bist` × 8 = 3.9331 mm² | 72 b → `RM_IHPSG13_1P_2048x32_c2_bm_bist` × 24 = 6.2666 mm² | 72 b → `RM_IHPSG13_1P_2048x32_c2_bm_bist` × 24 = 6.2666 mm² |
| `vec0_spm` | 64 b → `RM_IHPSG13_1P_1024x64_c2_bm_bist` × 4 = 1.0558 mm² | 72 b → `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 12 = 1.6822 mm² | 72 b → `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 12 = 1.6822 mm² |
| `vec1_spm` | 64 b → `RM_IHPSG13_1P_1024x64_c2_bm_bist` × 4 = 1.0558 mm² | 72 b → `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 12 = 1.6822 mm² | 72 b → `RM_IHPSG13_1P_1024x32_c2_bm_bist` × 12 = 1.6822 mm² |
| `ten_opnd` | 64 b → `RM_IHPSG13_2P_512x32_c2_bm_bist` × 8 = 1.2052 mm² | 72 b → `RM_IHPSG13_2P_512x32_c2_bm_bist` × 12 = 1.8078 mm² | 72 b → `RM_IHPSG13_2P_512x32_c2_bm_bist` × 12 = 1.8078 mm² |
| `ten_acc` | 64 b → `RM_IHPSG13_2P_512x32_c2_bm_bist` × 4 = 0.6026 mm² | 72 b → `RM_IHPSG13_2P_512x32_c2_bm_bist` × 6 = 0.9039 mm² | 72 b → `RM_IHPSG13_2P_512x32_c2_bm_bist` × 6 = 0.9039 mm² |

Placement experiments (die / core are planning assumptions; macro outlines real):

| Strategy | Macros placed | Core | Macro area / core |
|---|---|---|---|
| adjacent_vector | 69 (+0 unplaced) | 40.9348 mm² | 31.2 % |
| around_tensor | 69 (+0 unplaced) | 40.9348 mm² | 31.2 % |
| central_shared | 69 (+0 unplaced) | 40.9348 mm² | 31.2 % |
| perimeter | 69 (+0 unplaced) | 40.9348 mm² | 31.2 % |

