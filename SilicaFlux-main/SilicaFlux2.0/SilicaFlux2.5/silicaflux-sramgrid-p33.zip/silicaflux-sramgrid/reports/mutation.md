# Mutation testing — 20/20 killed

One-line changes to the new RTL, each rebuilt and run through the scenarios most likely to expose it.

| Id | Mutation | Config | Status | Killed by |
|---|---|---|---|---|
| M01 | decoder: LOW map takes the bank from the wrong word bits | sg_min4 | KILLED | bank_map: [33495000] ERROR: port 2 tag 72: rdata byte 0 = 08, expected 00 (word 0) |
| M02 | decoder: alignment check removed | sg_min4 | KILLED | boundary: [14435000] ERROR: port 0: error request issued without ev_error |
| M03 | decoder: region window one bit too wide (aliasing) | sg_min4 | KILLED | boundary: [14415000] ERROR: port 0: error request issued without ev_error |
| M04 | decoder: write-protect ignored | sg_hier | KILLED | wprot: [49255000] ERROR: port 3: error request issued without ev_error |
| M05 | decoder: SECDED partial-granule strobes accepted | sg_min4 | KILLED | byte_en: [14395000] ERROR: port 1: error request issued without ev_error |
| M06 | arbiter: 1R1W same-row read/write pair co-issued | r_1r1w_wf | KILLED | rdw: [14445000] %Error: silicaflux_sram_macro_wrapper.sv:275: Assertion failed in TOP.tb_sram_g |
| M07 | arbiter: RDW policy inverted | r_1r1w_wf | KILLED | rdw: [14486000] ERROR: rdw: region 0 same-cycle read returned 365dead711e79fff, policy WRITE_FI |
| M08 | arbiter: 2RW second grant ignores the same-row write rule | r_2rw | KILLED | conflict: [14435000] %Error: sram_generic_2rw.sv:93: Assertion failed in TOP.tb_sram_grid.u_dut.g_ba |
| M09 | port: responses delivered from the wrong reorder slot | sg_min4 | KILLED | smoke: [14405000] ERROR: port 1 tag 0: rdata byte 0 = 1c, expected 00 (word 1022) |
| M10 | port: credits never run out (reorder overflow) | r_pipe | KILLED | dma: [14715000] ERROR: port 0: tag 1c, expected 14 (order) |
| M11 | port: skid buffer loses the write data | sg_min4 | KILLED | conflict: [14535000] ERROR: port 1 tag 4: rdata byte 0 = 00, expected 23 (word 4) |
| M12 | bank: SECDED granule write masks swapped between granules | r_g32 | KILLED | byte_en: [14475000] ERROR: port 2 tag 3: rdata byte 0 = d6, expected 00 (word 14) |
| M13 | bank: byte-parity check never fires | r_parity | KILLED | ecc: [14455000] ERROR: port 0 tag 0: err 0 expected 7 |
| M14 | bank: SECDED single errors not reported as corrected | sg_min4 | KILLED | ecc: [14455000] ERROR: port 0 tag 0: rsp_ce 0 expected 1 |
| M15 | grid: functional issue allowed in the cycle MBIST releases the banks | sg_min4 | KILLED | mbist: [424165000] ERROR: port 0: functional issue while the banks belong to MBIST / init (tst 0, |
| M16 | grid: init sweep stops one row early | sg_min4 | KILLED | mbist: [14349000] ERROR: init: region 0 word 4092 (bank 0 row 1023) not cleared by the init sweep |
| M17 | grid: RAS event address wrong for the XOR map | r_xor | KILLED | ecc: [14466000] ERROR: region 0: RAS event address 20002da8, expected 20002da0 |
| M18 | grid: request pipe of a region ignored for the MBIST read-data padding | sg_hier | KILLED | mbist: [2917796000] ERROR: MBIST fault-free run failed: mask 7ffe01 target 0 addr 1023 elem 1 |
| M19 | wrapper: test port writes become reads | sg_min4 | KILLED | mbist: [424156000] ERROR: MBIST fault-free run failed: mask f target 0 addr 0 elem 1 |
| M20 | wrapper: read-valid one cycle early | r_pipe | KILLED | smoke: [14415000] %Error: sfx_sg_bank.sv:317: Assertion failed in TOP.tb_sram_grid.u_dut.g_bank[2 |
