# Lint, elaboration and configuration rejection

Legal configurations clean: **19/19** (Verilator `-Wall` with and without `SG_ASSERT`: 0 messages from the new RTL; Icarus compile + elaboration run; Yosys hierarchy/proc/check).
Illegal parameter sets refused by all three tools: **18/18**.
Illegal JSON configurations refused by `sg_config.py`: **15/15**.

| Legal configuration | Verilator msgs (plain / assert) | Icarus | Yosys | OK |
|---|---|---|---|---|
| sg_hier | 0 / 0 | rc 0/0 | rc 0 | yes |
| sg_hier_asic | 0 / 0 | rc 0/0 | rc 0 | yes |
| sg_hier_fpga | 0 / 0 | rc 0/0 | rc 0 | yes |
| sg_min4 | 0 / 0 | rc 0/0 | rc 0 | yes |
| sg_min4_asic | 0 / 0 | rc 0/0 | rc 0 | yes |
| sg_min4_fpga | 0 / 0 | rc 0/0 | rc 0 | yes |
| r_1r1w_rf | 0 / 0 | rc 0/0 | rc 0 | yes |
| r_1r1w_wf | 0 / 0 | rc 0/0 | rc 0 | yes |
| r_2rw | 0 / 0 | rc 0/0 | rc 0 | yes |
| r_dw128 | 0 / 0 | rc 0/0 | rc 0 | yes |
| r_fixed | 0 / 0 | rc 0/0 | rc 0 | yes |
| r_g32 | 0 / 0 | rc 0/0 | rc 0 | yes |
| r_high | 0 / 0 | rc 0/0 | rc 0 | yes |
| r_noinit | 0 / 0 | rc 0/0 | rc 0 | yes |
| r_parity | 0 / 0 | rc 0/0 | rc 0 | yes |
| r_pipe | 0 / 0 | rc 0/0 | rc 0 | yes |
| r_slice0 | 0 / 0 | rc 0/0 | rc 0 | yes |
| r_wordw | 0 / 0 | rc 0/0 | rc 0 | yes |
| r_xor | 0 / 0 | rc 0/0 | rc 0 | yes |

| Illegal parameter set (bypassing the generator) | Expected check | Verilator | Icarus | Yosys |
|---|---|---|---|---|
| regions overlap | `g_err_regions_overlap` | refused | refused | refused |
| base not aligned to the region size | `g_err_region_field_out_of_range` | refused | refused | refused |
| 3 banks | `g_err_region_field_out_of_range` | refused | refused | refused |
| region smaller than 2 rows per bank | `g_err_region_field_out_of_range` | refused | refused | refused |
| XOR map with fewer row than bank bits | `g_err_xor_map_needs_rows_ge_banks` | refused | refused | refused |
| SECDED region with byte writes | `g_err_secded_region_has_byte_we` | refused | refused | refused |
| ASIC implementation without a macro | `g_err_asic_region_without_macro` | refused | refused | refused |
| ASIC 2RW on a single-port IHP macro | `g_err_macro_cannot_do_2rw` | refused | refused | refused |
| ASIC commercial placeholder macro (no licensed output) | `g_err_macro_pending_no_licensed_compiler_output` | refused | refused | refused |
| ASIC macro id not in the catalogue | `g_err_macro_not_in_catalogue` | refused | refused | refused |
| ASIC 9-bit parity lanes on byte-mask SKY130 macro | `g_err_lane_not_multiple_of_macro_mask_granularity` | refused | refused | refused |
| reorder slots not a power of two | `g_err_nslot_pow2_2_to_16` | refused | refused | refused |
| bank width 48 | `g_err_dw_pow2_32_to_512` | refused | refused | refused |
| ECC granule 16 | `g_err_ecc_g_32_or_64` | refused | refused | refused |
| NBT inconsistent with R_NB | `g_err_nbt_inconsistent` | refused | refused | refused |
| TEST_LAT inconsistent | `g_err_test_lat_inconsistent` | refused | refused | refused |
| port slice 2 | `g_err_p_slice_0_or_1` | refused | refused | refused |
| unknown read-during-write policy | `g_err_unknown_rdw` | refused | refused | refused |

| Illegal JSON configuration | sg_config.py | First message |
|---|---|---|
| regions overlap | refused | regions 'vec0_spm' and 'vec1_spm' overlap |
| base not size-aligned | refused | region 'vec0_spm': base 0x3000_1000 is not aligned to its size 32KiB |
| 3 banks (schema) | refused | schema: regions/2/banks: 3 is not one of [1, 2, 4, 8, 16] |
| size not a power of two (schema pattern ok, value not) | refused | region 'vec0_spm': size must be a power of two |
| region too small for its banks | refused | region 'vec0_spm': too small - each of the 16 banks needs at least 2 rows of 8 bytes |
| xor map with too few rows | refused | region 'ten_opnd': map 'xor' needs at least as many row bits as bank bits |
| SECDED with byte writes | refused | region 'shared': SECDED regions are written per 64-bit granule; byte_write must be false (byte writes would need read-modify-write, which is not implemented) |
| port references an unknown region | refused | port 'vec0': unknown region 'nowhere' |
| region wired to no port | refused | region 'ten_acc' is not wired to any port |
| window beyond the address space | refused | region 'shared': window exceeds the 28-bit address space |
| dual-port regions on GF180 (no dual-port macro) | refused | region 'ten_opnd': no gf180 macro implements port model 1r1w with 9-bit write lanes (stored word 72 bits) |
| parity (9-bit lanes) on SKY130 byte-mask macros | refused | region 'boot': no sky130 macro implements port model 1rw with 9-bit write lanes (stored word 72 bits) |
| explicit macro of the wrong topology | refused | region 'ten_acc': macro RM_IHPSG13_1P_512x32_c2_bm_bist is not a feasible ihp_sg13g2 macro for this region (unknown, wrong topology or write-mask granularity) |
| unknown field (schema) | refused | schema: regions/0: Additional properties are not allowed ('colour' was unexpected) |
| duplicate region names | refused | region names must be unique |
