# Performance

Measured in RTL simulation (Verilator, back-pressure 0 % unless noted). Bandwidth = completed bytes / cycles of the pattern. Bank utilisation = accesses performed / cycles (1RW limit 1.0, 1R1W / 2RW limit 2.0). Latency = cycles from request acceptance to response, reads only. Conflict = cycles a decodable request with a credit lost bank arbitration (arbitration stall). Credit stall = cycles a port waited for a reorder slot.

| Config | Pattern | Seed | Cycles | Bytes | B/cycle | Bank util (min–max) | Conflicts | Credit stalls | Read latency min / avg / max |
|---|---|---|---|---|---|---|---|---|---|
| sg_hier | conflict | 1 | 2710 | 24000 | 8.86 | 0.00–0.37 | 5362 | 0 | 2 / 4.45 / 8 |
| sg_hier | dma | 1 | 2645 | 20392 | 7.71 | 0.02–0.16 | 29 | 120 | 2 / 3.09 / 5 |
| sg_hier | local | 1 | 286 | 8000 | 27.97 | 0.00–0.44 | 199 | 187 | 4 / 4.39 / 7 |
| sg_hier | shared_seq | 1 | 286 | 8000 | 27.97 | 0.00–0.44 | 201 | 185 | 4 / 4.42 / 6 |
| sg_hier | shared_stride | 1 | 254 | 8000 | 31.50 | 0.00–0.49 | 0 | 245 | 4 / 4.32 / 5 |
| sg_hier | shared_rand | 1 | 297 | 8000 | 26.94 | 0.00–0.47 | 261 | 166 | 4 / 4.45 / 7 |
| sg_min4 | conflict | 1 | 603 | 4800 | 7.96 | 0.00–1.00 | 1197 | 0 | 2 / 3.99 / 4 |
| sg_min4 | dma | 1 | 444 | 4800 | 10.81 | 0.32–0.36 | 90 | 0 | 2 / 2.10 / 4 |
| sg_min4 | local | 1 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| sg_min4 | shared_seq | 1 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| sg_min4 | shared_stride | 1 | 603 | 4800 | 7.96 | 0.00–1.00 | 1197 | 0 | 2 / 3.99 / 4 |
| sg_min4 | shared_rand | 1 | 273 | 4800 | 17.58 | 0.53–0.56 | 189 | 0 | 2 / 2.33 / 4 |
| r_1r1w_rf | conflict | 4 | 374 | 4800 | 12.83 | 0.00–1.60 | 501 | 0 | 2 / 2.85 / 4 |
| r_1r1w_rf | dma | 4 | 437 | 4800 | 10.98 | 0.32–0.37 | 32 | 0 | 2 / 2.04 / 3 |
| r_1r1w_rf | local | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_1r1w_rf | shared_seq | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_1r1w_rf | shared_stride | 4 | 454 | 4800 | 10.57 | 0.00–1.32 | 750 | 0 | 2 / 3.66 / 4 |
| r_1r1w_rf | shared_rand | 4 | 239 | 4800 | 20.08 | 0.59–0.69 | 101 | 0 | 2 / 2.20 / 4 |
| r_1r1w_wf | conflict | 4 | 373 | 4800 | 12.87 | 0.00–1.61 | 487 | 0 | 2 / 2.99 / 5 |
| r_1r1w_wf | dma | 4 | 437 | 4800 | 10.98 | 0.32–0.37 | 32 | 0 | 2 / 2.04 / 3 |
| r_1r1w_wf | local | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_1r1w_wf | shared_seq | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_1r1w_wf | shared_stride | 4 | 454 | 4800 | 10.57 | 0.00–1.32 | 750 | 0 | 2 / 3.66 / 4 |
| r_1r1w_wf | shared_rand | 4 | 239 | 4800 | 20.08 | 0.59–0.69 | 101 | 0 | 2 / 2.20 / 4 |
| r_2rw | conflict | 4 | 305 | 4800 | 15.74 | 0.00–1.97 | 299 | 0 | 2 / 2.48 / 3 |
| r_2rw | dma | 4 | 429 | 4800 | 11.19 | 0.33–0.38 | 10 | 0 | 2 / 2.02 / 3 |
| r_2rw | local | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_2rw | shared_seq | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_2rw | shared_stride | 4 | 303 | 4800 | 15.84 | 0.00–1.98 | 299 | 0 | 2 / 2.55 / 3 |
| r_2rw | shared_rand | 4 | 210 | 4800 | 22.86 | 0.67–0.79 | 15 | 0 | 2 / 2.02 / 3 |
| r_dw128 | conflict | 4 | 603 | 9600 | 15.92 | 0.00–1.00 | 1197 | 0 | 3 / 4.00 / 4 |
| r_dw128 | dma | 4 | 637 | 9600 | 15.07 | 0.22–0.24 | 43 | 286 | 2 / 2.52 / 4 |
| r_dw128 | local | 4 | 302 | 9600 | 31.79 | 0.50–0.50 | 0 | 297 | 2 / 2.66 / 3 |
| r_dw128 | shared_seq | 4 | 302 | 9600 | 31.79 | 0.50–0.50 | 0 | 297 | 2 / 2.66 / 3 |
| r_dw128 | shared_stride | 4 | 603 | 9600 | 15.92 | 0.00–1.00 | 1197 | 0 | 2 / 3.99 / 4 |
| r_dw128 | shared_rand | 4 | 343 | 9600 | 27.99 | 0.40–0.47 | 139 | 263 | 2 / 2.63 / 5 |
| r_fixed | conflict | 4 | 603 | 4800 | 7.96 | 0.00–1.00 | 600 | 0 | 2 / 3.92 / 402 |
| r_fixed | dma | 4 | 428 | 4800 | 11.21 | 0.33–0.38 | 89 | 0 | 2 / 2.14 / 7 |
| r_fixed | local | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_fixed | shared_seq | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_fixed | shared_stride | 4 | 603 | 4800 | 7.96 | 0.00–1.00 | 600 | 0 | 2 / 3.33 / 402 |
| r_fixed | shared_rand | 4 | 306 | 4800 | 15.69 | 0.46–0.54 | 146 | 0 | 2 / 2.27 / 13 |
| r_g32 | conflict | 4 | 603 | 4800 | 7.96 | 0.00–1.00 | 1197 | 0 | 3 / 4.00 / 4 |
| r_g32 | dma | 4 | 455 | 4800 | 10.55 | 0.32–0.34 | 99 | 0 | 2 / 2.13 / 4 |
| r_g32 | local | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_g32 | shared_seq | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_g32 | shared_stride | 4 | 603 | 4800 | 7.96 | 0.00–1.00 | 1197 | 0 | 2 / 3.99 / 4 |
| r_g32 | shared_rand | 4 | 273 | 4800 | 17.58 | 0.50–0.63 | 204 | 0 | 2 / 2.33 / 4 |
| r_high | conflict | 4 | 603 | 4800 | 7.96 | 0.00–1.00 | 1197 | 0 | 3 / 4.00 / 4 |
| r_high | dma | 4 | 432 | 4800 | 11.11 | 0.00–0.93 | 65 | 0 | 2 / 2.09 / 3 |
| r_high | local | 4 | 203 | 4800 | 23.65 | 0.00–0.99 | 0 | 0 | 2 / 2.00 / 2 |
| r_high | shared_seq | 4 | 203 | 4800 | 23.65 | 0.00–0.99 | 0 | 0 | 2 / 2.00 / 2 |
| r_high | shared_stride | 4 | 603 | 4800 | 7.96 | 0.00–1.00 | 1197 | 0 | 2 / 3.99 / 4 |
| r_high | shared_rand | 4 | 282 | 4800 | 17.02 | 0.50–0.62 | 223 | 0 | 2 / 2.37 / 4 |
| r_noinit | conflict | 4 | 603 | 4800 | 7.96 | 0.00–1.00 | 1197 | 0 | 3 / 4.00 / 4 |
| r_noinit | dma | 4 | 449 | 4800 | 10.69 | 0.32–0.35 | 90 | 0 | 2 / 2.13 / 4 |
| r_noinit | local | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_noinit | shared_seq | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_noinit | shared_stride | 4 | 603 | 4800 | 7.96 | 0.00–1.00 | 1197 | 0 | 2 / 3.99 / 4 |
| r_noinit | shared_rand | 4 | 268 | 4800 | 17.91 | 0.50–0.60 | 171 | 0 | 2 / 2.28 / 4 |
| r_parity | conflict | 4 | 603 | 4800 | 7.96 | 0.00–1.00 | 1197 | 0 | 3 / 4.00 / 4 |
| r_parity | dma | 4 | 449 | 4800 | 10.69 | 0.32–0.35 | 90 | 0 | 2 / 2.13 / 4 |
| r_parity | local | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_parity | shared_seq | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_parity | shared_stride | 4 | 603 | 4800 | 7.96 | 0.00–1.00 | 1197 | 0 | 2 / 3.99 / 4 |
| r_parity | shared_rand | 4 | 268 | 4800 | 17.91 | 0.50–0.60 | 171 | 0 | 2 / 2.28 / 4 |
| r_pipe | conflict | 4 | 606 | 4800 | 7.92 | 0.00–0.99 | 1197 | 0 | 6 / 6.99 / 7 |
| r_pipe | dma | 4 | 451 | 4800 | 10.64 | 0.31–0.36 | 100 | 0 | 5 / 5.16 / 7 |
| r_pipe | local | 4 | 206 | 4800 | 23.30 | 0.73–0.73 | 0 | 0 | 5 / 5.00 / 5 |
| r_pipe | shared_seq | 4 | 206 | 4800 | 23.30 | 0.73–0.73 | 0 | 0 | 5 / 5.00 / 5 |
| r_pipe | shared_stride | 4 | 606 | 4800 | 7.92 | 0.00–0.99 | 1197 | 0 | 5 / 6.99 / 7 |
| r_pipe | shared_rand | 4 | 278 | 4800 | 17.27 | 0.50–0.60 | 204 | 0 | 5 / 5.32 / 7 |
| r_slice0 | conflict | 4 | 603 | 4800 | 7.96 | 0.00–1.00 | 1197 | 0 | 2 / 2.00 / 2 |
| r_slice0 | dma | 4 | 448 | 4800 | 10.71 | 0.32–0.36 | 100 | 0 | 2 / 2.00 / 2 |
| r_slice0 | local | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_slice0 | shared_seq | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_slice0 | shared_stride | 4 | 603 | 4800 | 7.96 | 0.00–1.00 | 1197 | 0 | 2 / 2.00 / 2 |
| r_slice0 | shared_rand | 4 | 275 | 4800 | 17.45 | 0.51–0.60 | 204 | 0 | 2 / 2.00 / 2 |
| r_wordw | conflict | 4 | 603 | 4800 | 7.96 | 0.00–1.00 | 1197 | 0 | 4 / 4.00 / 4 |
| r_wordw | dma | 4 | 448 | 4800 | 10.71 | 0.31–0.36 | 90 | 0 | 2 / 2.11 / 4 |
| r_wordw | local | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_wordw | shared_seq | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_wordw | shared_stride | 4 | 603 | 4800 | 7.96 | 0.00–1.00 | 1197 | 0 | 2 / 3.99 / 4 |
| r_wordw | shared_rand | 4 | 270 | 4800 | 17.78 | 0.54–0.57 | 193 | 0 | 2 / 2.30 / 4 |
| r_xor | conflict | 4 | 603 | 4800 | 7.96 | 0.00–1.00 | 1197 | 0 | 3 / 3.99 / 4 |
| r_xor | dma | 4 | 455 | 4800 | 10.55 | 0.32–0.35 | 97 | 0 | 2 / 2.12 / 4 |
| r_xor | local | 4 | 205 | 4800 | 23.41 | 0.73–0.74 | 3 | 0 | 2 / 2.00 / 4 |
| r_xor | shared_seq | 4 | 205 | 4800 | 23.41 | 0.73–0.74 | 3 | 0 | 2 / 2.00 / 4 |
| r_xor | shared_stride | 4 | 203 | 4800 | 23.65 | 0.74–0.74 | 0 | 0 | 2 / 2.00 / 2 |
| r_xor | shared_rand | 4 | 271 | 4800 | 17.71 | 0.52–0.58 | 202 | 0 | 2 / 2.32 / 4 |

## Placement options vs wire-distance estimates

**Estimates, not extracted delay**: Manhattan distance from each port's (assumed) cluster-block centre to each bank's signal-pin centroid, weighted by the floorplan file's assumed traffic mix; `mm·bit` = Σ over port-bank links of distance × (2·DW + AW + 16) wires. Suggested request-pipe stages assume 1.5 mm per clock (an assumption in the floorplan file). No routing, no RC extraction, no STA.

| Config | Strategy | Weighted distance | Sparse-crossbar wiring | Suggested req_pipe (configured) | Checks |
|---|---|---|---|---|---|
| sg_min4 | adjacent_vector | 1.228 mm | 2,594 mm·bit | shared 1 (0) | clean |
| sg_min4 | around_tensor | 1.219 mm | 2,574 mm·bit | shared 1 (0) | clean |
| sg_min4 | central_shared | 1.171 mm | 2,473 mm·bit | shared 1 (0) | clean |
| sg_min4 | perimeter | 1.556 mm | 3,287 mm·bit | shared 1 (0) | clean |
| sg_hier | adjacent_vector | 1.792 mm | 35,276 mm·bit | vec0_spm 2 (0), shared 4 (1), vec1_spm 3 (0), ten_opnd 2 (0), ten_acc 2 (0), boot 1 (0) | clean |
| sg_hier | around_tensor | 1.887 mm | 37,810 mm·bit | vec0_spm 2 (0), shared 5 (1), vec1_spm 3 (0), ten_opnd 1 (0), ten_acc 1 (0), boot 1 (0) | clean |
| sg_hier | central_shared | 1.652 mm | 31,734 mm·bit | vec0_spm 2 (0), shared 3 (1), vec1_spm 3 (0), ten_opnd 2 (0), ten_acc 2 (0), boot 1 (0) | clean |
| sg_hier | perimeter | 3.219 mm | 46,191 mm·bit | vec0_spm 3 (0), shared 5 (1), vec1_spm 3 (0), ten_opnd 3 (0), ten_acc 3 (0), boot 3 (0) | clean |
