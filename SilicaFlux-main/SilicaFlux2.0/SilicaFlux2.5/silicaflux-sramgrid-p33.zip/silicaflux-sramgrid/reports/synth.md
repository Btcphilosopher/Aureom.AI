# Synthesis (Yosys)

Yosys 0.33 (git sha1 2584903a060)

| Target | Flow | Result | Cells | Evidence |
|---|---|---|---|---|
| `sg_min4_generic` | generic | OK | 14875 | 4 inferred bank arrays (294,912 bits) = expected 4 (294,912 bits) |
| `sg_min4_asic` | asic | OK | 23878 | 12 macro instances (expected 12): RM_IHPSG13_1P_1024x32_c2_bm_bist; inferred memories after mapping: 0 |
| `sg_min4_ihp` | asic+ihp_stdcells | OK | 15979 | IHP SG13G2 cells (typical Liberty): **0.2450 mm²** logic, 2121 flip-flops, 12 macro black boxes |
| `sg_min4_fpga` | fpga | OK | 12433 | 8 RAMB36 + 0 RAMB18 = 294,912 bits for 294,912 stored bits |
| `sg_hier_generic` | generic | OK | 74706 | 23 inferred bank arrays (2,064,384 bits) = expected 23 (2,064,384 bits) |
| `sg_hier_asic` | asic | OK | 109431 | 69 macro instances (expected 69): RM_IHPSG13_1P_1024x32_c2_bm_bist, RM_IHPSG13_1P_2048x32_c2_bm_bist, RM_IHPSG13_2P_512x32_c2_bm_bist; inferred memories after mapping: 0 |
| `sg_hier_ihp` | asic+ihp_stdcells | OK | 83583 | IHP SG13G2 cells (typical Liberty): **1.1501 mm²** logic, 8594 flip-flops, 69 macro black boxes |

Netlists, instance lists and logs: `reports/synth/<target>/`. Standard-cell area is unplaced cell area (no utilisation, clock tree, buffering, fill).
