# Macro wrapper: timing semantics and real-macro equivalence

Generic reference wrapper vs wrapper on the vendor's own Verilog model (IHP SG13G2 with `FUNCTIONAL`, SKY130 OpenRAM, GF180MCU), identical random traffic incl. masked writes and test-port operations; every read checked against a shadow memory at exactly the declared latency, `rvalid` alignment every cycle, output hold with OUT_REG = 1.

| Case | Simulator | Result | Detail |
|---|---|---|---|
| ihp1p_1024x32_secded72 | icarus+vendor | PASS | W=72 D=1024 M=1 PM=0 OUT_REG=0 vendor model of macro id 21: 2268 read returns checked, 0 errors |
| ihp1p_1024x32_secded72_oreg | icarus+vendor | PASS | W=72 D=1024 M=1 PM=0 OUT_REG=1 vendor model of macro id 21: 2268 read returns checked, 0 errors |
| ihp1p_1024x32_parity72 | icarus+vendor | PASS | W=72 D=1024 M=8 PM=0 OUT_REG=0 vendor model of macro id 21: 2268 read returns checked, 0 errors |
| ihp1p_2048x32_secded72 | icarus+vendor | PASS | W=72 D=2048 M=1 PM=0 OUT_REG=1 vendor model of macro id 24: 2287 read returns checked, 0 errors |
| ihp2p_512x32_1r1w_parity72 | icarus+vendor | PASS | W=72 D=512 M=8 PM=1 OUT_REG=0 vendor model of macro id 66: 3893 read returns checked, 0 errors |
| ihp2p_512x32_2rw_secded72_oreg | icarus+vendor | PASS | W=72 D=512 M=1 PM=2 OUT_REG=1 vendor model of macro id 66: 4351 read returns checked, 0 errors |
| sky130_32x256_1rw_bytes64 | icarus+vendor | PASS | W=64 D=256 M=8 PM=0 OUT_REG=0 vendor model of macro id 1: 2205 read returns checked, 0 errors |
| sky130_32x256_1r1w_bytes64_oreg | icarus+vendor | PASS | W=64 D=256 M=8 PM=1 OUT_REG=1 vendor model of macro id 1: 3834 read returns checked, 0 errors |
| gf180_512x8_1rw_bytes16 | icarus+vendor | PASS | W=16 D=512 M=2 PM=0 OUT_REG=0 vendor model of macro id 13: 2190 read returns checked, 0 errors |
| ihp1p_1024x32_secded72_generic | verilator | PASS | W=72 D=1024 M=1 PM=0 OUT_REG=0 generic pair: 2268 read returns checked, 0 errors |
| ihp1p_1024x32_secded72_oreg_generic | verilator | PASS | W=72 D=1024 M=1 PM=0 OUT_REG=1 generic pair: 2268 read returns checked, 0 errors |
| ihp2p_512x32_1r1w_parity72_generic | verilator | PASS | W=72 D=512 M=8 PM=1 OUT_REG=0 generic pair: 3893 read returns checked, 0 errors |
| ihp2p_512x32_2rw_secded72_oreg_generic | verilator | PASS | W=72 D=512 M=1 PM=2 OUT_REG=1 generic pair: 4351 read returns checked, 0 errors |
