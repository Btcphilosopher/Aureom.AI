# =============================================================================
# SilicaFlux-HPC Project 33 SRAMGRID :: mock_odb.tcl
# Executes a generated macro_place.tcl in plain tclsh against a MOCK of the
# OpenROAD / OpenDB calls it uses (ord::get_db_block, ord::get_db_tech,
# findInst, getMaster/getName, setOrient, setLocation, setPlacementStatus,
# odb::dbBlockage_create).  The mock knows exactly the macro instances of the
# synthesized netlist, so an unknown name or a wrong master fails here as it
# would in OpenROAD.  It proves the Tcl runs and what it does - not that
# OpenROAD accepts the placement (physical/openroad_place_check.tcl does that
# where OpenROAD is installed).
#
#   tclsh8.6 physical/mock_odb.tcl <instances.txt> <macro_place.tcl> <out.json>
#   instances.txt: one "<instance name>\t<master>" per line
# =============================================================================
lassign $argv inst_file place_tcl out_json

set ::insts  [dict create]
set ::placed [dict create]
set ::blockages {}
set ::errors {}
set fh [open $inst_file r]
set n 0
while {[gets $fh line] >= 0} {
  if {$line eq ""} continue
  lassign [split $line "\t"] name master
  incr n
  set h "::mock_inst_$n"
  dict set ::insts $name [list $h $master]
  if {[info commands ::mock_master_$master] eq ""} {
    proc ::mock_master_$master {cmd args} [subst -nocommands {
      if {\$cmd eq "getName"} { return {$master} }
      error "mock dbMaster: unsupported method \$cmd"
    }]
  }
  proc $h {cmd args} [subst -nocommands {
    set name {$name}
    set master {$master}
    switch -- \$cmd {
      getMaster          { return ::mock_master_\$master }
      getName            { return \$name }
      setOrient          { dict set ::placed \$name orient [lindex \$args 0] }
      setLocation        { dict set ::placed \$name x [lindex \$args 0]; dict set ::placed \$name y [lindex \$args 1] }
      setPlacementStatus { dict set ::placed \$name status [lindex \$args 0] }
      default            { error "mock dbInst: unsupported method \$cmd" }
    }
  }]
}
close $fh

namespace eval ord {}
proc ord::get_db_block {} { return ::mock_block }
proc ord::get_db_tech {} { return ::mock_tech }
proc ::mock_tech {cmd args} {
  if {$cmd eq "getDbUnitsPerMicron"} { return 1000 }
  error "mock dbTech: unsupported method $cmd"
}
proc ::mock_block {cmd args} {
  if {$cmd eq "findInst"} {
    set nm [lindex $args 0]
    if {[dict exists $::insts $nm]} {
      return [lindex [dict get $::insts $nm] 0]
    }
    return "NULL"
  }
  error "mock dbBlock: unsupported method $cmd"
}
namespace eval odb {}
proc odb::dbBlockage_create {blk x0 y0 x1 y1} { lappend ::blockages [list $x0 $y0 $x1 $y1] }

if {[catch {source $place_tcl} err]} { lappend ::errors $err }

set out [open $out_json w]
puts $out "\{\"instances\": [dict size $::insts], \"blockages\": [llength $::blockages], \"errors\": \["
set first 1
foreach e $::errors {
  if {!$first} { puts -nonewline $out "," }
  set first 0
  puts -nonewline $out "\"[string map {\" ' \\ /} $e]\""
}
puts $out "\], \"placed\": \["
set first 1
dict for {nm v} $::placed {
  if {!$first} { puts $out "," }
  set first 0
  set st [expr {[dict exists $v status] ? [dict get $v status] : ""}]
  puts -nonewline $out "\{\"inst\": \"$nm\", \"x\": [dict get $v x], \"y\": [dict get $v y], \"orient\": \"[dict get $v orient]\", \"status\": \"$st\"\}"
}
puts $out "\]\}"
close $out
puts "mock_odb: [dict size $::placed] of [dict size $::insts] instances placed, [llength $::blockages] blockages, [llength $::errors] errors"
