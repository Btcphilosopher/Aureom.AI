# =============================================================================
# SilicaFlux-HPC Project 33 SRAMGRID :: openroad_place_check.tcl
# Loads a generated macro placement into OpenROAD with the REAL IHP SG13G2
# technology / standard-cell / SRAM LEFs and re-checks it with OpenDB geometry.
#
# NOT RUN in this project (OpenROAD could not be executed in the session that
# produced it - see docs/05_PHYSICAL.md).  Run it where OpenROAD is installed:
#
#   SG_EXT=<fetch dir> SG_CFG=sg_min4 SG_STRATEGY=central_shared \
#     openroad -exit physical/openroad_place_check.tcl
#
# What it does
#   1. read_lef: sg13g2_tech.lef, sg13g2_stdcell.lef and every SRAM macro LEF the
#      placement uses (pinned commit, scripts/fetch_macros.sh)
#   2. read_def macro_place.def (DIEAREA, the macros FIXED with their halos and the
#      placement blockages) - no logic netlist is needed for a macro-only check
#   3. initialize rows on CoreSite over the core box of placement.json
#   4. for every macro: master is a CLASS BLOCK, orientation, inside the core with
#      the halo, pairwise spacing >= channel, clear of the blockages
#   5. write_def of the checked floorplan
# To exercise macro_place.tcl itself (sg_place by instance name) in OpenROAD, read
# an IHP-mapped netlist of sg_top first (link_design sg_top), then source it.
# =============================================================================
set ext   $::env(SG_EXT)
set cfg   $::env(SG_CFG)
set strat $::env(SG_STRATEGY)
set root  [file normalize [file join [file dirname [info script]] ..]]
set pdir  [file join $root physical placement $cfg $strat]
set ihp   [file join $ext ihp ihp-sg13g2 libs.ref]

read_lef [file join $ihp sg13g2_stdcell lef sg13g2_tech.lef]
read_lef [file join $ihp sg13g2_stdcell lef sg13g2_stdcell.lef]
set masters {}
set fh [open [file join $pdir macro_place.def] r]
while {[gets $fh line] >= 0} {
  if {[regexp {^\s+- \S+ (\S+) \+ FIXED} $line -> m]} { dict set masters $m 1 }
}
close $fh
foreach m [dict keys $masters] { read_lef [file join $ihp sg13g2_sram lef $m.lef] }
read_def -floorplan_initialize [file join $pdir macro_place.def]

# floorplan facts from placement.json (core box, halo, channel) - parsed with a regexp, no JSON package needed
set pj [read [open [file join $pdir placement.json] r]]
regexp {"core": \[\s*([-0-9.]+),\s*([-0-9.]+),\s*([-0-9.]+),\s*([-0-9.]+)\s*\]} $pj -> cx0 cy0 cx1 cy1
regexp {"halo": ([0-9.]+)} $pj -> halo
regexp {"channel": ([0-9.]+)} $pj -> chan

set block [ord::get_db_block]
set dbu   [[ord::get_db_tech] getDbUnitsPerMicron]
set bad 0
set boxes {}
foreach inst [$block getInsts] {
  set m [$inst getMaster]
  if {![$m isBlock]} { continue }
  set bb [$inst getBBox]
  set b [list [expr {[$bb xMin]/double($dbu)}] [expr {[$bb yMin]/double($dbu)}] \
              [expr {[$bb xMax]/double($dbu)}] [expr {[$bb yMax]/double($dbu)}]]
  lassign $b x0 y0 x1 y1
  if {$x0 - $halo < $cx0 - 1e-6 || $y0 - $halo < $cy0 - 1e-6 || $x1 + $halo > $cx1 + 1e-6 || $y1 + $halo > $cy1 + 1e-6} {
    puts "VIOLATION core: [$inst getName] $b"; incr bad
  }
  foreach bk [$block getBlockages] {
    set r [$bk getBBox]
    if {$x0 - $halo < [$r xMax]/double($dbu) && [$r xMin]/double($dbu) < $x1 + $halo &&
        $y0 - $halo < [$r yMax]/double($dbu) && [$r yMin]/double($dbu) < $y1 + $halo} {
      puts "VIOLATION blockage: [$inst getName]"; incr bad
    }
  }
  lappend boxes [list [$inst getName] $b]
}
for {set i 0} {$i < [llength $boxes]} {incr i} {
  for {set j [expr {$i + 1}]} {$j < [llength $boxes]} {incr j} {
    lassign [lindex $boxes $i 1] a0 a1 a2 a3
    lassign [lindex $boxes $j 1] b0 b1 b2 b3
    set dx [expr {max($b0 - $a2, $a0 - $b2, 0.0)}]
    set dy [expr {max($b1 - $a3, $a1 - $b3, 0.0)}]
    if {$dx < $chan - 1e-6 && $dy < $chan - 1e-6} {
      puts "VIOLATION spacing: [lindex $boxes $i 0] / [lindex $boxes $j 0] dx=$dx dy=$dy"; incr bad
    }
  }
}
puts "openroad_place_check: [llength $boxes] macros, $bad violations"
write_def [file join $pdir openroad_checked.def]
if {$bad} { exit 1 }
