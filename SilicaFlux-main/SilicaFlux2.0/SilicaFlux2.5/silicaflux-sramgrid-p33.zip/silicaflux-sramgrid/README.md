# SilicaFlux-HPC · Project 33 — SRAMGRID: distributed SRAM bank architecture and macro placement

**Primary RTL:** [`rtl/silicaflux_sram_grid.sv`](rtl/silicaflux_sram_grid.sv) · Aureom.AI | SilicaFlux-HPC

SRAMGRID is the SilicaFlux die's distributed on-chip memory: vector-local scratchpads, tensor operand buffers,
tensor accumulator storage, a shared SRAM and a write-protectable boot RAM, each a **region** of one logical
address space, each built from independently configured **banks**, each bank built from **real open-PDK SRAM
macros** (or the synthesis-inference / FPGA models) behind `silicaflux_sram_macro_wrapper`, and the macros
**placed** by a configuration-driven Tcl generator and checked by an independent overlap / rule checker.

> **Status — read this first.** RTL simulation (Verilator, Icarus), Yosys synthesis and geometric placement only.
> Macro dimensions, pins and obstructions are **real** (IHP SG13G2 LEF at the commit pinned by the SRAM Wrapper
> Library, hash-verified); die size, logic-block outlines and traffic mix are **planning assumptions**; wire
> numbers are **distance estimates, not extracted delay**. **OpenROAD was not run** (not installed; running a
> downloaded binary was not permitted in this session) — `physical/openroad_place_check.tcl` is the check to run
> where it is available. **No SRAM repair is claimed.** Delivered as an archive; nothing was committed.
> Details: [docs/08_LIMITATIONS.md](docs/08_LIMITATIONS.md).

## Definition of done

* **Memory banks behave correctly** — **232/232** simulation runs pass over 15 configurations (2,309,176 checks); `sg_min4` alone 47/47; Icarus / Verilator cross-simulation 16/16 cycle-identical; mutation testing 20/20 killed ([reports/regression.md](reports/regression.md), [reports/mutation.md](reports/mutation.md)).
* **…map to real or clearly identified substitute implementations** — the macro wrapper returns exactly what a shadow memory predicts, at the declared latency, on the **vendors' own models** of real IHP SG13G2 1P / 2P, SKY130 OpenRAM and GF180MCU macros: **13/13** ([reports/wrapper.md](reports/wrapper.md)); Yosys: `sg_min4` ASIC netlist has exactly **12** `RM_IHPSG13_1P_1024x32` macros and no inferred bank array, `sg_hier` exactly **69**; the generic flow infers exactly one array per bank (4 / 23); FPGA flow 8 RAMB36; macro connectivity 81 macros, 0 anomalies
* **…and can be positioned in an overlap-checked floorplan with physical abstracts** — 8/8 placements (2 configurations × 4 strategies, real IHP LEF outlines) pass the independent checker (overlap, channel, core, blockages, logic blocks, site/row grid, orientation, pin escape, Tcl = DEF, mock-OpenDB execution); checker self-test 30/30 mutations caught ([reports/physical.md](reports/physical.md))
* **Started with four banks and one shared region; scaled only after validation** — `sg_min4` (4 banks, 1 shared
  region) was simulated, synthesized and placed first; `scripts/run_physical.py` places the scaled `sg_hier`
  (6 regions, 23 banks, 69 macros) only after every `sg_min4` regression job and placement is clean (gate open: 47/47 `sg_min4` jobs, placements clean).

## Results (generated from `reports/*.json` — [reports/SUMMARY.md](reports/SUMMARY.md))

| Check | Result | Report |
|---|---|---|
| Simulation regression (15 configurations, 13 scenarios, Verilator + Icarus) | **232/232**, 2,309,176 checks | [regression](reports/regression.md) |
| Cross-simulation, identical cycles and checks | 16/16 | [regression](reports/regression.md) |
| Macro wrapper vs vendor macro models | **13/13** | [wrapper](reports/wrapper.md) |
| Legal configurations warning-free (Verilator -Wall, Icarus, Yosys) | **19/19** | [lint](reports/lint.md) |
| Illegal parameter sets refused by Verilator, Icarus **and** Yosys | **18/18** | [lint](reports/lint.md) |
| Illegal JSON configurations refused by the generator | **15/15** | [lint](reports/lint.md) |
| Mutation testing of the new RTL | **20/20** killed | [mutation](reports/mutation.md) |
| Synthesis targets meeting their exact expectation | 7/7 | [synth](reports/synth.md) |
| Placements clean / checker self-test | 8/8 / 30/30 | [physical](reports/physical.md) |
| Macro connectivity anomalies (12 + 69 macros) | 0 | [connectivity](reports/connectivity_sg_hier.md) |
| `sg_min4`: 32 KiB, 4 banks × 1024 × 72 b SECDED | 12 IHP macros **1.6822 mm²** (LEF) + logic 0.245 mm² (IHP cells, unplaced) | [area](reports/area.md) |
| `sg_hier`: 224 KiB, 6 regions, 23 banks | 69 IHP macros **12.7632 mm²** + logic 1.1501 mm² | [area](reports/area.md) |
| SECDED width cost on IHP (`sg_min4`, 64 → 72 bits) | +59 % macro area (1.0558 → 1.6822 mm²: no 72-bit macro, 3 × 32 b tiles) | [area](reports/area.md) |
| OpenROAD | **not run** (check script provided) | [docs/05 §7](docs/05_PHYSICAL.md) |

### Defects found and fixed during verification

* **Post-MBIST read window** (found by the `mbist` scenario): in the cycle `tst_active` fell the re-initialisation
  had not started, so a functional read could see raw March patterns (UE). Banks now stay blocked through that
  cycle; mutation M15 re-introduces the bug and is killed.
* `req_ready` of a skid-buffer port was 1 during reset (design review) — now 0 in reset and the first cycle after.
* 1R1W read-during-write fairness alternated the policy across unrelated collisions — now only over back-to-back
  collisions.
* Icarus could not stop at an illegal ASIC macro selection and tried to tile width-1 placeholders — the wrapper now
  hands the library a harmless selection while the `$fatal` still fires.

### Findings worth acting on

* **ECC width has a real macro cost:** no IHP macro is 72 bits wide, so SECDED (or parity) on 64-bit banks costs
  +59 % macro area in `sg_min4`, not +12.5 % ([reports/area.md](reports/area.md) — ECC what-if).
* **`sg_hier` should use 8 reorder slots:** a slot is held for the response latency + 1 cycle, so the pipelined
  shared region (response in 4 cycles) needs 5 slots per port for one access per cycle; with the configured 4 the
  ports record 185–245 credit stalls per pattern ([docs/07](docs/07_PERFORMANCE.md)). The generator now warns.
* **Bank conflicts dominate:** a bank-count stride drops `sg_min4` from 23.65 to 7.96 B/cycle; the XOR map restores
  23.65; dual-port banks double the single-bank ceiling; fixed priority starved a port for 402 cycles.
* **Placement:** a central shared SRAM gives the shortest traffic-weighted distance and the least crossbar wiring
  for both configurations; the DMA path across the die, not the compute clusters, sets the farthest link
  (estimates, [docs/05](docs/05_PHYSICAL.md) §4).

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Audit: SRAM library, `hpc_scratchpad`, tensor buffers, memory maps, FPGA inference, ASIC macro files, OpenROAD / FloorplanLab; real macros and their LEF / Liberty / models | [docs/00_AUDIT.md](docs/00_AUDIT.md) |
| 2 | Vector-local, tensor operand, tensor accumulator, shared, boot regions; logical address space separate from banks | [docs/01](docs/01_ARCHITECTURE.md) §1, [docs/03](docs/03_CONFIGURATION.md), `config/sg_hier.json` |
| 3 | Banks, width, depth, byte enables, port count (1RW / 1R1W / 2RW), latency, arbitration; invalid parameters rejected | [docs/03](docs/03_CONFIGURATION.md), `rtl/sfx_sg_bank_arb.sv`, [reports/lint.md](reports/lint.md) |
| 4 | `silicaflux_sram_macro_wrapper.sv`: clock, CE, R/W enable, address, wdata, rdata, mask, test controls, explicit timing | `rtl/silicaflux_sram_macro_wrapper.sv`, [docs/02](docs/02_INTERFACES.md) §3, [reports/wrapper.md](reports/wrapper.md) |
| 5 | Real macro abstracts: dimensions, pins, blockages, power pins, obstructions, orientations, sites; no invented dimensions | `physical/abstracts/`, [docs/04](docs/04_MACROS_ECC_MBIST_RAS.md) §1 |
| 6 | Configuration-driven placement Tcl; adjacent-to-vector, around-tensor, central-shared, perimeter; halos, channels; overlap / core / blockage validation | `scripts/gen_placement.py`, `scripts/check_placement.py`, `physical/placement/`, [docs/05](docs/05_PHYSICAL.md) |
| 7 | Documented arbitration and routing, no central crossbar, parallel accesses within port limits | [docs/01](docs/01_ARCHITECTURE.md) §3–6 |
| 8 | RAS (SECDED from P26, RAS event format) and MBIST (TestCore / sramlib bus); ECC width in macro width; no repair claim | [docs/04](docs/04_MACROS_ECC_MBIST_RAS.md) §3–5, [reports/area.md](reports/area.md) |
| 9 | Bank mapping, boundaries, aliasing, byte enables, conflicts, read-during-write, DMA, reset, test mode | [docs/06](docs/06_VERIFICATION.md) §2, [reports/regression.md](reports/regression.md) |
| 10 | Utilisation, conflicts, bandwidth, latency, stalls; placement options vs wire-distance estimates (not extracted delay) | [docs/07](docs/07_PERFORMANCE.md), [reports/performance.md](reports/performance.md), [docs/05](docs/05_PHYSICAL.md) §4 |
| 11 | Deliverables | below |

## Deliverables

| Deliverable | Files |
|---|---|
| `silicaflux_sram_grid.sv` | `rtl/silicaflux_sram_grid.sv` (+ `sfx_sg_port.sv`, `sfx_sg_bank_arb.sv`, `sfx_sg_bank.sv`, `sfx_sg_delay.sv`, `sfx_sg_defs.svh`, `sfx_sg_cfg_funcs.svh`) |
| `silicaflux_sram_macro_wrapper.sv` | `rtl/silicaflux_sram_macro_wrapper.sv` |
| Bank address decoder | `rtl/sfx_sg_addr_dec.sv` |
| Memory configuration schema | `config/schema/sramgrid_config.schema.json`, `scripts/sg_config.py`, `config/*.json`, `config/regress/*.json`, `gen/<cfg>/memory_map.md` |
| Macro placement Tcl | `scripts/gen_placement.py` → `physical/placement/<cfg>/<strategy>/macro_place.{tcl,def}`; `config/floorplan/*.json`; checker `scripts/check_placement.py`; `physical/mock_odb.tcl`; `physical/openroad_place_check.tcl` |
| Tests | `tb/tb_sram_grid.sv`, `tb/tb_sg_macro_wrapper.sv`, `scripts/run_tests.py`, `run_wrapper_tests.py`, `run_lint.py`, `run_mutants.py`, `run_physical.py` |
| Macro connectivity report | [reports/connectivity_sg_min4.md](reports/connectivity_sg_min4.md), [reports/connectivity_sg_hier.md](reports/connectivity_sg_hier.md) (`scripts/connectivity.py`, from the synthesized netlists) |
| Memory area accounting | [reports/area.md](reports/area.md) (`scripts/area_report.py`) |
| Macro abstracts | `physical/abstracts/*.json` (`scripts/sg_lef.py`) |
| Reused sources | `third_party/` (byte-identical, `SHA256SUMS`, `PROVENANCE.md`) |

## Quick start

```bash
sudo apt-get install -y verilator iverilog yosys tcl8.6 python3
```

```bash
make fetch          # pinned, hash-verified public IHP / SKY130 / GF180 views into ../ext
```

```bash
make test-min       # the starting configuration (4 banks, 1 shared region), every scenario
```

```bash
make all            # abstracts, configs, lint, regression, wrapper, synth, physical, connectivity, area, mutants, report
```

`make help` lists every target. Ubuntu 24.04 packages: Verilator 5.020, Icarus 12, Yosys 0.33, Tcl 8.6;
Python ≥ 3.10 (`jsonschema` optional). Simulation / lint run without the fetch; the wrapper equivalence, abstracts,
IHP standard-cell mapping and placement need it.

## Documents

| | |
|---|---|
| [docs/00_AUDIT.md](docs/00_AUDIT.md) | repository audit |
| [docs/01_ARCHITECTURE.md](docs/01_ARCHITECTURE.md) | layers, hierarchy, interconnect, timing, ordering, read-during-write, reset / init / boot |
| [docs/02_INTERFACES.md](docs/02_INTERFACES.md) | grid ports, error codes, test / RAS / events, macro wrapper and decoder interfaces |
| [docs/03_CONFIGURATION.md](docs/03_CONFIGURATION.md) | schema, bank organisation, rejected configurations, `sg_min4` / `sg_hier` |
| [docs/04_MACROS_ECC_MBIST_RAS.md](docs/04_MACROS_ECC_MBIST_RAS.md) | real abstracts, wrapper ↔ macro, ECC width cost, MBIST, RAS, no repair |
| [docs/05_PHYSICAL.md](docs/05_PHYSICAL.md) | placement generator, strategies, checker, results, gate, OpenROAD |
| [docs/06_VERIFICATION.md](docs/06_VERIFICATION.md) | testbenches, brief §9 mapping, defects, mutation |
| [docs/07_PERFORMANCE.md](docs/07_PERFORMANCE.md) | utilisation, conflicts, bandwidth, latency, stalls |
| [docs/08_LIMITATIONS.md](docs/08_LIMITATIONS.md) | what is not claimed |
