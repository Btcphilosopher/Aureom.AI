#!/usr/bin/env bash
# Final run on frozen RTL: every report regenerated from one RTL / testbench state.
set -uo pipefail
cd "$(dirname "$0")/.."
H0=$(cat rtl/*.sv rtl/*.svh tb/*.sv | sha256sum | cut -c1-16)
echo "rtl+tb hash at start: $H0" > reports/frozen_hash.txt
rm -rf reports/logs; mkdir -p reports/logs
step() { echo "== $1 $(date +%H:%M:%S)"; shift; "$@"; echo "   rc=$?"; }
step regression python3 scripts/run_tests.py --jobs 4
step wrapper    python3 scripts/run_wrapper_tests.py
step synth      python3 scripts/run_synth.py sg_min4:generic,sg_min4:asic,sg_min4:ihp,sg_min4:fpga,sg_hier:generic,sg_hier:asic,sg_hier:ihp
step physical   python3 scripts/run_physical.py
step conn       python3 -I scripts/connectivity.py sg_min4 sg_hier
step area       python3 -I scripts/area_report.py
step mutants    python3 scripts/run_mutants.py
H1=$(cat rtl/*.sv rtl/*.svh tb/*.sv | sha256sum | cut -c1-16)
echo "rtl+tb hash at end:   $H1" >> reports/frozen_hash.txt
step report     python3 -I scripts/make_report.py
echo "FINAL_DONE"
