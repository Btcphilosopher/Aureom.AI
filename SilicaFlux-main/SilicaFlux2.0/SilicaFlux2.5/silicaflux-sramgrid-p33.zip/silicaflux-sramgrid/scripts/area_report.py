#!/usr/bin/env python3
"""SilicaFlux-HPC Project 33 SRAMGRID -- memory area accounting.

For each configuration: logical bits -> stored bits (parity / SECDED expansion) -> bits the selected
macros provide (tiling padding) -> macro area from the REAL LEF outlines -> planning footprint with
one 40 um channel per macro; grid logic area from the IHP SG13G2 standard-cell mapping (Yosys + the
typical-corner Liberty; unplaced); per-strategy core / macro fractions from the placements; an ECC
what-if (the same region built without protection, with byte parity and with SECDED).
Every macro number traces to physical/abstracts/<macro>.json (vendor LEF SIZE).  Nothing is scaled
to another node.  Writes reports/area.{json,md}.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import sg_config  # noqa: E402


def region_rows(d, abstracts):
    rows = []
    g = d["ecc_granule"]
    for r in d["regions"]:
        m = r["macro"]
        stored = r["banks"] * r["depth"] * r["stored_width"]
        provided = r["banks"] * m["bits_provided"]
        rows.append({
            "region": r["name"], "kind": r["kind"], "bytes": r["bytes"], "logical_bits": r["logical_bits"],
            "ecc": r["ecc"], "stored_width": r["stored_width"], "data_width": d["data_width"],
            "ecc_overhead_pct": round(100.0 * (r["stored_width"] / d["data_width"] - 1), 2),
            "stored_bits": stored, "macro": m["macro"], "macros": m["count"] * r["banks"],
            "tile": f"{m['nc']}x{m['nr']}", "macro_bits": provided,
            "padding_bits": provided - stored, "macro_bit_utilisation_pct": round(100.0 * stored / provided, 2),
            "macro_area_mm2": round(m["area_um2"] * r["banks"] / 1e6, 4),
            "footprint_mm2": round(m["footprint_um2"] * r["banks"] / 1e6, 4),
            "um2_per_logical_bit": round(m["area_um2"] * r["banks"] / r["logical_bits"], 3),
            "alternatives": [{"macro": a["macro"], "count": a["count"] * r["banks"],
                              "area_mm2": round(a["area_um2"] * r["banks"] / 1e6, 4),
                              "footprint_mm2": round(a["footprint_um2"] * r["banks"] / 1e6, 4)}
                             for a in r["macro_alternatives"]],
        })
        # ECC what-if: same region, other integrity modes (byte_write as each mode allows)
        wi = {}
        for e in ("none", "parity", "secded"):
            sw = sg_config.stored_width(e, d["data_width"], g)
            mw = sg_config.mask_width(e, e != "secded", d["data_width"], g)
            c = sg_config.macro_candidates(r, sw, mw, r["depth"], d["technology"], abstracts)
            if c:
                wi[e] = {"stored_width": sw, "macro": c[0]["macro"], "macros": c[0]["count"] * r["banks"],
                         "macro_area_mm2": round(c[0]["area_um2"] * r["banks"] / 1e6, 4)}
            else:
                wi[e] = None
        rows[-1]["ecc_what_if"] = wi
    return rows


def main() -> int:
    abstracts = sg_config.load_abstracts()
    synth = {r["target"]: r for r in json.loads((ROOT / "reports/synth.json").read_text())["results"]}
    out = {}
    for name in ("sg_min4", "sg_hier"):
        d = sg_config.derive(json.loads((ROOT / f"config/{name}.json").read_text()))
        rows = region_rows(d, abstracts)
        logic = synth.get(f"{name}_ihp", {})
        fpga = synth.get(f"{name}_fpga", {})
        summ = json.loads((ROOT / f"physical/placement/{name}/summary.json").read_text())
        tot = {k: sum(r[k] for r in rows) for k in ("logical_bits", "stored_bits", "macro_bits", "macros",
                                                     "macro_area_mm2", "footprint_mm2")}
        tot["macro_area_mm2"] = round(tot["macro_area_mm2"], 4)
        tot["footprint_mm2"] = round(tot["footprint_mm2"], 4)
        tot["logic_stdcell_mm2"] = round(logic.get("stdcell_area_um2", 0) / 1e6, 4) if logic else None
        tot["logic_flops"] = logic.get("flops")
        tot["macro_plus_logic_mm2"] = round(tot["macro_area_mm2"] + (tot["logic_stdcell_mm2"] or 0), 4)
        tot["um2_per_logical_bit_macros"] = round(tot["macro_area_mm2"] * 1e6 / tot["logical_bits"], 3)
        out[name] = {"technology": d["technology"], "regions": rows, "totals": tot, "placement": summ,
                     "fpga": {"ramb36": fpga.get("ramb36"), "ramb18": fpga.get("ramb18"),
                              "bram_capacity_bits": fpga.get("bram_capacity_bits")} if fpga else None}
    (ROOT / "reports/area.json").write_text(json.dumps(out, indent=1) + "\n")

    L = ["# Memory area accounting", "",
         "Macro areas are the **real** outlines of the IHP SG13G2 open-PDK SRAM macros (vendor LEF `SIZE`, "
         "`physical/abstracts/`). Logic area is the grid's own logic (decoders, arbiters, reorder buffers, ECC, "
         "pipelines, counters) mapped by Yosys to the IHP SG13G2 standard cells with the typical-corner Liberty: "
         "**unplaced cell area** — no utilisation factor, clock tree, buffering, tap / fill cells or routing. "
         "Footprint = macros each grown by one 40 µm routing channel (the FloorplanLab rule) — a planning figure. "
         "Nothing is scaled to another node.", ""]
    for name, o in out.items():
        t = o["totals"]
        L += [f"## `{name}`", "",
              "| Region | ECC | Logical | Stored word | ECC overhead | Stored bits | Macro × n (tile per bank) | Macro bits | Padding | Bit use | Macro area | Footprint | µm²/logical bit |",
              "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
        for r in o["regions"]:
            L.append(f"| `{r['region']}` | {r['ecc']} | {r['bytes'] // 1024} KiB | {r['stored_width']} b | {r['ecc_overhead_pct']} % | "
                     f"{r['stored_bits']:,} | `{r['macro']}` × {r['macros']} ({r['tile']}) | {r['macro_bits']:,} | "
                     f"{r['padding_bits']:,} | {r['macro_bit_utilisation_pct']} % | {r['macro_area_mm2']} mm² | "
                     f"{r['footprint_mm2']} mm² | {r['um2_per_logical_bit']} |")
        L.append(f"| **total** | | {t['logical_bits'] // 8 // 1024} KiB | | | {t['stored_bits']:,} | {t['macros']} macros | "
                 f"{t['macro_bits']:,} | {t['macro_bits'] - t['stored_bits']:,} | "
                 f"{round(100 * t['stored_bits'] / t['macro_bits'], 2)} % | **{t['macro_area_mm2']} mm²** | {t['footprint_mm2']} mm² | "
                 f"{t['um2_per_logical_bit_macros']} |")
        L += ["", f"Grid logic (IHP SG13G2 cells, unplaced): **{t['logic_stdcell_mm2']} mm²**, {t['logic_flops']} flip-flops. "
              f"Macros + logic: **{t['macro_plus_logic_mm2']} mm²**.", ""]
        if o["fpga"]:
            L += [f"FPGA flow (Yosys `synth_xilinx`, 7-series): {o['fpga']['ramb36']} RAMB36 + {o['fpga']['ramb18']} RAMB18 "
                  f"({o['fpga']['bram_capacity_bits']:,} bits of block RAM for {t['stored_bits']:,} stored bits).", ""]
        L += ["ECC what-if (same banks and depth, smallest-footprint IHP macro per mode):", "",
              "| Region | none | byte parity | SECDED |", "|---|---|---|---|"]
        for r in o["regions"]:
            w = r["ecc_what_if"]
            f = lambda x: (f"{x['stored_width']} b → `{x['macro']}` × {x['macros']} = {x['macro_area_mm2']} mm²" if x else "no macro")  # noqa: E731
            L.append(f"| `{r['region']}` | {f(w['none'])} | {f(w['parity'])} | {f(w['secded'])} |")
        L += ["", "Placement experiments (die / core are planning assumptions; macro outlines real):", "",
              "| Strategy | Macros placed | Core | Macro area / core |", "|---|---|---|---|"]
        for s in o["placement"]:
            L.append(f"| {s['strategy']} | {s['placed']} (+{s['unplaced']} unplaced) | {s['core_mm2']} mm² | {round(100 * s['macro_fraction'], 1)} % |")
        L.append("")
    (ROOT / "reports/area.md").write_text("\n".join(L) + "\n")
    for n, o in out.items():
        t = o["totals"]
        print(f"[area] {n}: {t['macros']} macros {t['macro_area_mm2']} mm2, logic {t['logic_stdcell_mm2']} mm2, "
              f"stored {t['stored_bits']} / macro bits {t['macro_bits']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
