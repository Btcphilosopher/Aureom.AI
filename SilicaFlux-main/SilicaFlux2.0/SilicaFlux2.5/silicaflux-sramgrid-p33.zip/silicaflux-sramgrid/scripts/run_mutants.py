#!/usr/bin/env python3
"""SilicaFlux-HPC Project 33 SRAMGRID -- mutation testing of the new RTL.

Each mutant changes one line of rtl/ (a copy under build/mut/<n>/rtl), is rebuilt with Verilator and run
through the scenarios most likely to expose it.  A mutant is KILLED when any scenario fails (scoreboard,
assertion, audit) or the build refuses it.  Survivors are reported as they are.
Writes reports/mutation.{json,md}.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VL = ["verilator", "--binary", "--timing", "--assert", "-DSG_ASSERT", "-DSRAMLIB_POISON", "--x-assign", "unique",
      "--x-initial", "unique", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-j", "4"]

# (id, description, file, old, new, config, scenarios)
MUTANTS = [
    ("M01", "decoder: LOW map takes the bank from the wrong word bits", "sfx_sg_addr_dec.sv",
     "bk = 32'(word) & (32'(nb) - 32'd1);", "bk = 32'(word >> 1) & (32'(nb) - 32'd1);", "sg_min4", ["bank_map"]),
    ("M02", "decoder: alignment check removed", "sfx_sg_addr_dec.sv",
     "end else if (OFF > 0 && (addr & AW'((1 << OFF) - 1)) != '0) begin", "end else if (1'b0) begin", "sg_min4", ["boundary"]),
    ("M03", "decoder: region window one bit too wide (aliasing)", "sfx_sg_addr_dec.sv",
     "if (((a64 ^ R_BASE[r*64 +: 64]) >> l) == 64'd0) begin", "if (((a64 ^ R_BASE[r*64 +: 64]) >> (l + 1)) == 64'd0) begin",
     "sg_min4", ["boundary"]),
    ("M04", "decoder: write-protect ignored", "sfx_sg_addr_dec.sv",
     "end else if (we && sg_f8(R_WP, r) != 0 && wp_lock) begin", "end else if (1'b0) begin", "sg_hier", ["wprot"]),
    ("M05", "decoder: SECDED partial-granule strobes accepted", "sfx_sg_addr_dec.sv",
     "end else if (we && sg_f8(R_ECC, r) == `SG_ECC_SECDED && !strobe_granular(wstrb, ECC_G / 8)) begin",
     "end else if (1'b0) begin", "sg_min4", ["byte_en"]),
    ("M06", "arbiter: 1R1W same-row read/write pair co-issued", "sfx_sg_bank_arb.sv",
     "coll       = wv && rv && (row_of(rq_row, w) == row_of(rq_row, r));", "coll       = 1'b0;", "r_1r1w_wf", ["rdw"]),
    ("M07", "arbiter: RDW policy inverted", "sfx_sg_bank_arb.sv",
     "write_wins = (RDW == `SG_RDW_WRITE_FIRST) ? !flip_q : flip_q;", "write_wins = (RDW == `SG_RDW_WRITE_FIRST) ? flip_q : !flip_q;",
     "r_1r1w_wf", ["rdw"]),
    ("M08", "arbiter: 2RW second grant ignores the same-row write rule", "sfx_sg_bank_arb.sv",
     "!((row_of(rq_row, PW'(q)) == row_of(rq_row, a_sel)) && (rq_we[q] || rq_we[a_sel]));", "1'b1;", "r_2rw", ["conflict", "random"]),
    ("M09", "port: responses delivered from the wrong reorder slot", "sfx_sg_port.sv",
     "assign rsp_rdata    = r_data[hd_q];", "assign rsp_rdata    = r_data[hd_q + 1'b1];", "sg_min4", ["smoke"]),
    ("M10", "port: credits never run out (reorder overflow)", "sfx_sg_port.sv",
     "assign credit = (cnt_q != (SLW+1)'(NSLOT));", "assign credit = 1'b1;", "r_pipe", ["conflict", "dma"]),
    ("M11", "port: skid buffer loses the write data", "sfx_sg_port.sv",
     "if (!sk_v && req_valid && !issue) sk_d <= {req_we, req_addr, req_wdata, req_wstrb, req_tag};",
     "if (!sk_v && req_valid && !issue) sk_d <= {req_we, req_addr, {DW{1'b0}}, req_wstrb, req_tag};", "sg_min4", ["conflict", "random"]),
    ("M12", "bank: SECDED granule write masks swapped between granules", "sfx_sg_bank.sv",
     "assign a_m[g] = mast[g*(ECC_G/8)];", "assign a_m[g] = mast[((g + 1) % NG)*(ECC_G/8)];", "r_g32", ["byte_en"]),
    ("M13", "bank: byte-parity check never fires", "sfx_sg_bank.sv",
     "assign ape[l] = ~^w_ard[l*9 +: 9];", "assign ape[l] = 1'b0;", "r_parity", ["ecc"]),
    ("M14", "bank: SECDED single errors not reported as corrected", "sfx_sg_bank.sv",
     "assign ao_ce    = ao_v && !ao_we && a_ce_d;", "assign ao_ce    = 1'b0;", "sg_min4", ["ecc"]),
    ("M15", "grid: functional issue allowed in the cycle MBIST releases the banks", "silicaflux_sram_grid.sv",
     "assign blk = tst_active || tst_q || init_q;", "assign blk = tst_active || init_q;", "sg_min4", ["mbist"]),
    ("M16", "grid: init sweep stops one row early", "silicaflux_sram_grid.sv",
     "if (init_row_q == {RWX{1'b1}}) begin", "if (init_row_q == {RWX{1'b1}} - 1'b1) begin", "sg_min4", ["mbist", "random"]),
    ("M17", "grid: RAS event address wrong for the XOR map", "silicaflux_sram_grid.sv",
     "else if (MP == `SG_MAP_XOR) word = (rowv << BWR) | (lb ^ (rowv & ((64'd1 << BWR) - 64'd1)));",
     "else if (MP == `SG_MAP_XOR) word = (rowv << BWR) | lb;", "r_xor", ["ecc"]),
    ("M18", "grid: request pipe of a region ignored for the MBIST read-data padding", "silicaflux_sram_grid.sv",
     "sfx_sg_delay #(.W(BSW), .N(TEST_LAT - BLAT), .RST(0)) u_tpad", "sfx_sg_delay #(.W(BSW), .N(0), .RST(0)) u_tpad",
     "sg_hier", ["mbist"]),
    ("M19", "wrapper: test port writes become reads", "silicaflux_sram_macro_wrapper.sv",
     "ma_ce = tst_ce; ma_we = tst_we;", "ma_ce = tst_ce; ma_we = 1'b0;", "sg_min4", ["mbist"]),
    ("M20", "wrapper: read-valid one cycle early", "silicaflux_sram_macro_wrapper.sv",
     "assign a_rvalid   = a_vq[LATENCY-1];", "assign a_rvalid   = a_vq[0];",
     "r_pipe", ["smoke"]),
]


def main() -> int:
    sys.path.insert(0, str(ROOT / "scripts"))
    import sg_config
    for f in list((ROOT / "config").glob("*.json")) + list((ROOT / "config/regress").glob("*.json")):
        sg_config.emit(sg_config.derive(json.loads(f.read_text())), ROOT / "gen")
    files = [l.strip() for l in (ROOT / "rtl/files.f").read_text().splitlines() if l.strip()]
    only = set(sys.argv[sys.argv.index("--only") + 1].split(",")) if "--only" in sys.argv else None
    prev = {r["id"]: r for r in json.loads((ROOT / "reports/mutation.json").read_text())} if only and \
        (ROOT / "reports/mutation.json").exists() else {}
    res = []
    for mid, desc, fname, old, new, cfg, scens in MUTANTS:
        if only and mid not in only:
            if mid in prev:
                res.append(prev[mid])
            continue
        mdir = ROOT / f"build/mut/{mid}"
        if mdir.exists():
            shutil.rmtree(mdir)
        (mdir / "rtl").mkdir(parents=True)
        for f in (ROOT / "rtl").iterdir():
            if f.is_file():
                shutil.copy(f, mdir / "rtl" / f.name)
        src = (mdir / "rtl" / fname).read_text()
        if src.count(old) != 1:
            res.append({"id": mid, "desc": desc, "status": "INVALID (pattern not unique)", "killed": None})
            print(f"[mut] {mid} INVALID pattern", flush=True)
            continue
        (mdir / "rtl" / fname).write_text(src.replace(old, new))
        fl = []
        for l in files:
            if l.startswith("+incdir+rtl"):
                fl.append(f"+incdir+{mdir}/rtl")
            elif l.startswith("rtl/"):
                fl.append(str(mdir / l))
            else:
                fl.append(l)
        (mdir / "files.f").write_text("\n".join(fl) + "\n")
        b = subprocess.run(VL + [f"-I{mdir}/rtl", f"-Igen/{cfg}", "rtl/lint.vlt", "-f", str(mdir / "files.f"),
                                 "tb/tb_sram_grid.sv", "--top-module", "tb_sram_grid", "-Mdir", str(mdir / "obj"), "-o", "sim"],
                           cwd=ROOT, capture_output=True, text=True, timeout=3600)
        if b.returncode:
            res.append({"id": mid, "desc": desc, "config": cfg, "status": "KILLED (build refused)", "killed": True})
            print(f"[mut] {mid} killed at build", flush=True)
            continue
        killed_by = []
        for s in scens:
            r = subprocess.run([str(mdir / "obj/sim"), "+verilator+rand+reset+2", "+verilator+seed+1", f"+SCEN={s}",
                                "+SEED=1", "+BP=20", "+GAP=10", "+N=200"],
                               cwd=ROOT, capture_output=True, text=True, timeout=1800)
            if "RESULT PASS" not in r.stdout:
                first = next((l for l in (r.stdout + r.stderr).splitlines() if "ERROR" in l or "Assertion" in l
                              or "%Error" in l), "")
                killed_by.append({"scenario": s, "evidence": first[:200]})
        res.append({"id": mid, "desc": desc, "config": cfg, "scenarios": scens, "killed": bool(killed_by),
                    "killed_by": killed_by, "status": "KILLED" if killed_by else "SURVIVED"})
        print(f"[mut] {mid} {res[-1]['status']} {desc} {killed_by[:1]}", flush=True)
        shutil.rmtree(mdir / "obj", ignore_errors=True)
    (ROOT / "reports/mutation.json").write_text(json.dumps(res, indent=1) + "\n")
    k = sum(1 for r in res if r["killed"])
    print(f"[mut] {k}/{len(res)} killed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
