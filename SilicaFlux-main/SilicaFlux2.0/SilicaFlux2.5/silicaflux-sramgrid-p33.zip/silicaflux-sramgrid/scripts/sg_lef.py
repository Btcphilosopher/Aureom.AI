#!/usr/bin/env python3
"""SilicaFlux-HPC Project 33 SRAMGRID -- LEF reader and macro-abstract builder.

Reads the PUBLIC open-PDK SRAM macro LEF views fetched at the commits pinned by
the SRAM Wrapper Library (third_party/silicaflux-sramlib/scripts/mem/
fetch_open_macros.sh) plus the IHP SG13G2 technology / standard-cell LEF, and
writes one JSON abstract per macro to physical/abstracts/:

  * outline (SIZE, ORIGIN), CLASS, FOREIGN, SYMMETRY (legal orientations)
  * every pin: direction, use (SIGNAL / POWER / GROUND), layers, bounding box,
    the macro edge it sits on
  * obstructions per layer: rectangle count, bounding box, whether the layer is
    fully blocked over the macro
  * power / ground pins and their layers
  * provenance: upstream repository, commit, path, SHA-256 of the LEF, and the
    SHA-256 the SRAM library manifest recorded for the same file (must match)

Nothing in the LEF is executed; it is parsed as text.  Dimensions are copied,
never estimated.  Usage:

  scripts/sg_lef.py build --ext <fetch dir> --out physical/abstracts
  scripts/sg_lef.py show <abstract.json>
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFESTS = ROOT / "third_party/silicaflux-sramlib/manifests"

SOURCES = {
    # family prefix -> (fetch sub-directory, upstream repo, pinned commit)
    "IHP": ("ihp", "https://github.com/IHP-GmbH/IHP-Open-PDK", "5e6d592e4002946a4616f798c357f0f3c06cf3b6"),
    "SKY130": ("sky130_sram_macros", "https://github.com/efabless/sky130_sram_macros",
               "ebfbf5775c8cd433ad38a4d825e46c2275231511"),
    "GF180": ("gf180_sram", "https://github.com/google/globalfoundries-pdk-ip-gf180mcu_fd_ip_sram",
              "9c411928870ce15226228fa52ddb6ecc0ea4ffbe"),
}
TECH_LEF = "ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_tech.lef"
CELL_LEF = "ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/sg13g2_stdcell.lef"

# LEF SYMMETRY -> DEF orientations a placer may use (LEF/DEF 5.8 semantics):
#   always N (R0); X -> FS (MX) ; Y -> FN (MY) ; X and Y -> S (R180);
#   R90 -> W/E/FW/FE (rotations), which this project does not use (see legal_orients).
def legal_orients(sym: list[str]) -> list[str]:
    o = ["R0"]
    if "X" in sym:
        o.append("MX")
    if "Y" in sym:
        o.append("MY")
    if "X" in sym and "Y" in sym:
        o.append("R180")
    if "R90" in sym:
        o += ["R90", "R270", "MXR90", "MYR90"]
    return o


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _tokens(text: str):
    text = re.sub(r"#[^\n]*", "", text)
    return text.replace(";", " ; ").split()


def parse_lef(text: str) -> dict:
    """Minimal, strict LEF 5.x reader for MACRO / SITE / LAYER / UNITS / MANUFACTURINGGRID."""
    t = _tokens(text)
    i = 0
    out = {"macros": {}, "sites": {}, "layers": {}, "units_dbu": None, "mfg_grid": None}

    def stmt():
        nonlocal i
        s = []
        while t[i] != ";":
            s.append(t[i])
            i += 1
        i += 1
        return s

    while i < len(t):
        tok = t[i]
        if tok == "MACRO":
            name = t[i + 1]
            i += 2
            m = {"name": name, "class": None, "origin": [0.0, 0.0], "foreign": None, "size": None,
                 "symmetry": [], "site": None, "pins": {}, "obs": {}}
            while not (t[i] == "END" and t[i + 1] == name):
                k = t[i]
                if k == "CLASS":
                    m["class"] = " ".join(stmt()[1:])
                elif k == "ORIGIN":
                    s = stmt(); m["origin"] = [float(s[1]), float(s[2])]
                elif k == "FOREIGN":
                    m["foreign"] = stmt()[1]
                elif k == "SIZE":
                    s = stmt(); m["size"] = [float(s[1]), float(s[3])]
                elif k == "SYMMETRY":
                    m["symmetry"] = stmt()[1:]
                elif k == "SITE":
                    m["site"] = stmt()[1]
                elif k == "PIN":
                    pname = t[i + 1]
                    i += 2
                    pin = {"direction": None, "use": "SIGNAL", "ports": []}
                    while not (t[i] == "END" and t[i + 1] == pname):
                        k2 = t[i]
                        if k2 == "DIRECTION":
                            pin["direction"] = stmt()[1]
                        elif k2 == "USE":
                            pin["use"] = stmt()[1]
                        elif k2 == "PORT":
                            i += 1
                            layer = None
                            while t[i] != "END":
                                if t[i] == "LAYER":
                                    layer = stmt()[1]
                                elif t[i] == "RECT":
                                    s = stmt()
                                    xs = [float(v) for v in s[-4:]]
                                    pin["ports"].append({"layer": layer, "rect": xs})
                                elif t[i] == "POLYGON":
                                    s = stmt()
                                    v = [float(x) for x in s[1:] if re.match(r"^-?[0-9.]+$", x)]
                                    pin["ports"].append({"layer": layer, "rect": [min(v[0::2]), min(v[1::2]), max(v[0::2]), max(v[1::2])]})
                                else:
                                    stmt()
                            i += 1   # END of PORT
                        else:
                            stmt()
                    i += 2
                    m["pins"][pname] = pin
                elif k == "OBS":
                    i += 1
                    layer = None
                    while t[i] != "END":
                        if t[i] == "LAYER":
                            layer = stmt()[1]
                            m["obs"].setdefault(layer, [])
                        elif t[i] == "RECT":
                            s = stmt()
                            m["obs"][layer].append([float(v) for v in s[-4:]])
                        elif t[i] == "POLYGON":
                            s = stmt()
                            v = [float(x) for x in s[1:] if re.match(r"^-?[0-9.]+$", x)]
                            xs, ys = v[0::2], v[1::2]
                            m["obs"][layer].append([min(xs), min(ys), max(xs), max(ys)])
                        else:
                            stmt()
                    i += 1
                else:
                    stmt()
            i += 2
            out["macros"][name] = m
        elif tok == "SITE":
            name = t[i + 1]
            i += 2
            s_ = {"name": name}
            while not (t[i] == "END" and t[i + 1] == name):
                s = stmt()
                if s[0] == "SIZE":
                    s_["size"] = [float(s[1]), float(s[3])]
                elif s[0] in ("CLASS", "SYMMETRY"):
                    s_[s[0].lower()] = " ".join(s[1:])
            i += 2
            out["sites"][name] = s_
        elif tok == "LAYER":
            name = t[i + 1]
            i += 2
            ly = {"name": name}
            while not (t[i] == "END" and t[i + 1] == name):
                s = stmt()
                if s and s[0] == "TYPE":
                    ly["type"] = s[1]
                elif s and s[0] == "DIRECTION":
                    ly["direction"] = s[1]
                elif s and s[0] == "PITCH":
                    ly["pitch"] = [float(v) for v in s[1:]]
                elif s and s[0] == "WIDTH":
                    ly["width"] = float(s[1])
            i += 2
            out["layers"][name] = ly
        elif tok == "UNITS":
            i += 1
            while t[i] != "END":
                s = stmt()
                if s[:2] == ["DATABASE", "MICRONS"]:
                    out["units_dbu"] = int(float(s[2]))
            i += 2
        elif tok == "MANUFACTURINGGRID":
            out["mfg_grid"] = float(stmt()[1])
        elif tok == "END" and i + 1 < len(t) and t[i + 1] == "LIBRARY":
            break
        else:
            i += 1
    return out


def parse_tech(tech_text: str, cell_text: str) -> dict:
    """Technology facts by pattern (the tech LEF has blocks the macro reader does not need)."""
    tt = re.sub(r"#[^\n]*", "", tech_text)
    ct = re.sub(r"#[^\n]*", "", cell_text)
    out = {"units_dbu": None, "mfg_grid": None, "layers": [], "sites": {}}
    m = re.search(r"DATABASE\s+MICRONS\s+([0-9.]+)\s*;", tt)
    out["units_dbu"] = int(float(m.group(1))) if m else None
    m = re.search(r"MANUFACTURINGGRID\s+([0-9.]+)\s*;", tt)
    out["mfg_grid"] = float(m.group(1)) if m else None
    for lm in re.finditer(r"^\s*LAYER\s+(\S+)\s*\n(.*?)^\s*END\s+\1\b", tt, re.S | re.M):
        body = lm.group(2)
        ty = re.search(r"\bTYPE\s+(\S+)\s*;", body)
        if not ty or ty.group(1) != "ROUTING":
            continue
        d = re.search(r"\bDIRECTION\s+(\S+)\s*;", body)
        pi = re.search(r"\bPITCH\s+([0-9.]+)(?:\s+([0-9.]+))?\s*;", body)
        w = re.search(r"\bWIDTH\s+([0-9.]+)\s*;", body)
        out["layers"].append({"name": lm.group(1), "direction": d.group(1) if d else None,
                              "pitch": [float(x) for x in pi.groups() if x] if pi else None,
                              "width": float(w.group(1)) if w else None})
    for sm in re.finditer(r"^\s*SITE\s+(\S+)\s*\n(.*?)^\s*END\s+\1\b", ct, re.S | re.M):
        sz = re.search(r"SIZE\s+([0-9.]+)\s+BY\s+([0-9.]+)", sm.group(2))
        cl = re.search(r"CLASS\s+(\S+)\s*;", sm.group(2))
        sy = re.search(r"SYMMETRY\s+([^;]+);", sm.group(2))
        out["sites"][sm.group(1)] = {"name": sm.group(1), "size": [float(sz.group(1)), float(sz.group(2))],
                                     "class": cl.group(1) if cl else None,
                                     "symmetry": sy.group(1).split() if sy else []}
    return out


def _bbox(rects):
    return [min(r[0] for r in rects), min(r[1] for r in rects), max(r[2] for r in rects), max(r[3] for r in rects)]


def _edge(bb, w, h, tol=1.0):
    x0, y0, x1, y1 = bb
    if y0 <= tol:
        return "bottom"
    if y1 >= h - tol:
        return "top"
    if x0 <= tol:
        return "left"
    if x1 >= w - tol:
        return "right"
    return "interior"


def abstract(m: dict, prov: dict) -> dict:
    w, h = m["size"]
    pins = {}
    edges = {}
    for n, p in m["pins"].items():
        rects = [q["rect"] for q in p["ports"]]
        layers = sorted({q["layer"] for q in p["ports"]})
        bb = _bbox(rects)
        e = _edge(bb, w, h) if p["use"] == "SIGNAL" else "stripes"
        pins[n] = {"direction": p["direction"], "use": p["use"], "layers": layers, "bbox": bb,
                   "rects": len(rects), "edge": e}
        if p["use"] == "SIGNAL":
            edges[e] = edges.get(e, 0) + 1
    obs = {}
    for ly, rs in m["obs"].items():
        if not rs:
            continue
        bb = _bbox(rs)
        full = any(r[0] <= 0.01 and r[1] <= 0.01 and r[2] >= w - 0.01 and r[3] >= h - 0.01 for r in rs)
        obs[ly] = {"rects": len(rs), "bbox": bb, "full_cover": full}
    sig = [p for p in pins.values() if p["use"] == "SIGNAL"]
    pin_edge = max(edges, key=edges.get) if edges else None
    sig_bb = _bbox([p["bbox"] for p in sig]) if sig else None
    return {
        "schema": "silicaflux-sramgrid/macro-abstract/1",
        "macro": m["name"],
        "class": m["class"],
        "foreign": m["foreign"],
        "origin": m["origin"],
        "width_um": w,
        "height_um": h,
        "area_um2": round(w * h, 4),
        "symmetry": m["symmetry"],
        "legal_orientations_lef": legal_orients(m["symmetry"]),
        "signal_pin_edges": edges,
        "signal_pin_edge": pin_edge,
        "signal_pin_span": sig_bb,
        "signal_pin_layers": sorted({ly for p in sig for ly in p["layers"]}),
        "power_pins": {n: {"use": p["use"], "layers": p["layers"], "stripes": p["rects"]}
                       for n, p in pins.items() if p["use"] in ("POWER", "GROUND")},
        "obstructions": obs,
        "blocked_layers": sorted(ly for ly, o in obs.items() if o["full_cover"]),
        "pins": pins,
        "provenance": prov,
        "data_status": "REAL: copied from the vendor LEF (no estimate)",
    }


def manifest_index() -> dict:
    idx = {}
    for f in sorted(MANIFESTS.glob("*.json")):
        j = json.loads(f.read_text())
        if j.get("macro_name"):
            idx[j["macro_name"]] = j
    return idx


def build(ext: Path, out: Path) -> int:
    out.mkdir(parents=True, exist_ok=True)
    idx = manifest_index()
    n = 0
    bad = 0
    for name, man in sorted(idx.items()):
        fam = man["family"]
        key = "IHP" if fam.startswith("IHP") else "SKY130" if fam.startswith("SKY130") else "GF180"
        sub, repo, commit = SOURCES[key]
        lef_rel = man["views"]["lef"]
        lef = ext / sub / lef_rel
        if not lef.exists():
            print(f"[lef] MISSING {lef}", file=sys.stderr)
            bad += 1
            continue
        h = sha256(lef)
        want = man["provenance"]["files"].get(lef_rel)
        if want != h:
            print(f"[lef] HASH MISMATCH {lef_rel}: {h} != manifest {want}", file=sys.stderr)
            bad += 1
            continue
        lib = parse_lef(lef.read_text())
        if name not in lib["macros"]:
            print(f"[lef] macro {name} not in {lef}", file=sys.stderr)
            bad += 1
            continue
        prov = {"repo": repo, "commit": commit, "path": lef_rel, "sha256": h, "manifest_sha256": want,
                "license": man.get("license"), "manifest": f"third_party/silicaflux-sramlib/manifests/{name}.json"}
        ab = abstract(lib["macros"][name], prov)
        ab["sramlib_id"] = man["id"]
        ab["sramlib_define"] = man["define"]
        ab["family"] = fam
        ab["process"] = man["process"]
        ab["data_width"] = man["data_width"]
        ab["words"] = man["words"]
        ab["port_topology"] = man["port_topology"]
        ab["mask_granularity_bits"] = man["write_mask"]["granularity_bits"]
        ab["manifest_size_um"] = [man["physical"]["width_um"], man["physical"]["height_um"]]
        if abs(ab["manifest_size_um"][0] - ab["width_um"]) > 1e-6 or abs(ab["manifest_size_um"][1] - ab["height_um"]) > 1e-6:
            print(f"[lef] SIZE differs from manifest for {name}", file=sys.stderr)
            bad += 1
        (out / f"{name}.json").write_text(json.dumps(ab, indent=1) + "\n")
        n += 1
    # technology (IHP SG13G2): site, rows, routing layers
    sub, repo, commit = SOURCES["IHP"]
    tl = ext / sub / TECH_LEF
    cl = ext / sub / CELL_LEF
    if tl.exists() and cl.exists():
        tech = parse_tech(tl.read_text(), cl.read_text())
        site = tech["sites"].get("CoreSite")
        tj = {"schema": "silicaflux-sramgrid/tech/1", "technology": "ihp_sg13g2",
              "units_dbu": tech["units_dbu"], "mfg_grid_um": tech["mfg_grid"], "site": site,
              "routing_layers": tech["layers"],
              "provenance": {"repo": repo, "commit": commit,
                             "files": {TECH_LEF: sha256(tl), CELL_LEF: sha256(cl)}, "license": "Apache-2.0"}}
        (out / "tech_ihp_sg13g2.json").write_text(json.dumps(tj, indent=1) + "\n")
    else:
        print("[lef] IHP tech / stdcell LEF not fetched (scripts/fetch_macros.sh)", file=sys.stderr)
        bad += 1
    print(f"[lef] {n} macro abstracts written to {out}; {bad} problems")
    return 1 if bad else 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    b = sp.add_parser("build")
    b.add_argument("--ext", type=Path, required=True)
    b.add_argument("--out", type=Path, default=ROOT / "physical/abstracts")
    s = sp.add_parser("show")
    s.add_argument("abstract", type=Path)
    a = ap.parse_args()
    if a.cmd == "build":
        return build(a.ext, a.out)
    j = json.loads(a.abstract.read_text())
    print(f"{j['macro']}: {j['width_um']} x {j['height_um']} um, symmetry {j['symmetry']}, "
          f"signal pins on {j['signal_pin_edge']} ({j['signal_pin_layers']}), blocked {j['blocked_layers']}, "
          f"power {list(j['power_pins'])}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
