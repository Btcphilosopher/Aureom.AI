#!/usr/bin/env python3
"""SilicaFlux-HPC Project 33 SRAMGRID -- simulation regression.

Builds tb/tb_sram_grid.sv for every configuration (config/*.json and
config/regress/*.json) with Verilator (assertions on, SG_ASSERT, X-poisoned
SRAM outputs) and, for the cross-simulation set, Icarus; runs every applicable
scenario over several seeds / back-pressure / gap settings; writes
reports/regression.{json,md}, reports/performance.json and logs under
reports/logs/.

  scripts/run_tests.py [--quick] [--jobs N] [--only cfg1,cfg2]
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import sg_config  # noqa: E402

LOGS = ROOT / "reports/logs"
BUILD = ROOT / "build"

VL_FLAGS = ["--binary", "--timing", "--assert", "-DSG_ASSERT", "-DSRAMLIB_POISON", "--x-assign", "unique",
            "--x-initial", "unique", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-lint", "-Wno-style",
            "-Wno-TIMESCALEMOD", "-j", "2"]
SETTINGS = {1: (0, 0), 2: (20, 20), 3: (50, 10)}     # seed -> (back-pressure %, gap %)


def sh(cmd, log: Path, timeout=3600, cwd=ROOT):
    t0 = time.time()
    with open(log, "w") as f:
        f.write("$ " + " ".join(str(c) for c in cmd) + "\n")
        f.flush()
        try:
            rc = subprocess.run([str(c) for c in cmd], stdout=f, stderr=subprocess.STDOUT, cwd=cwd, timeout=timeout).returncode
        except subprocess.TimeoutExpired:
            rc = -9
    return rc, time.time() - t0


def configs(only):
    out = []
    for f in sorted((ROOT / "config").glob("*.json")) + sorted((ROOT / "config/regress").glob("*.json")):
        d = sg_config.derive(json.loads(f.read_text()))
        if only and d["name"] not in only:
            continue
        sg_config.emit(d, ROOT / "gen")
        out.append(d)
    return out


def scenarios(d):
    s = ["smoke", "bank_map", "boundary", "byte_en", "conflict", "dma", "random", "reset", "mbist", "perf"]
    if any(sum(1 for p in d["ports"] if p["reach"] >> r["index"] & 1) >= 2 for r in d["regions"]):
        s.append("rdw")
    if any(r["ecc"] != "none" for r in d["regions"]):
        s.append("ecc")
    if any(r["write_protect"] for r in d["regions"]):
        s.append("wprot")
    return s


def build(d, sim):
    name = d["name"]
    inc = f"-Igen/{name}"
    if sim == "vl":
        out = BUILD / f"vl_{name}"
        out.mkdir(parents=True, exist_ok=True)
        cmd = ["verilator"] + VL_FLAGS + [inc, "rtl/lint.vlt", "-f", "rtl/files.f", "tb/tb_sram_grid.sv",
                                          "--top-module", "tb_sram_grid", "-Mdir", out, "-o", "sim"]
        rc, t = sh(cmd, LOGS / f"build_vl_{name}.log", timeout=3600)
        return rc, out / "sim", t
    out = BUILD / "iv"
    out.mkdir(parents=True, exist_ok=True)
    cmd = ["iverilog", "-g2012", "-DSRAMLIB_POISON", inc, "-f", "rtl/files.f", "tb/tb_sram_grid.sv", "-s",
           "tb_sram_grid", "-o", out / f"{name}.vvp"]
    rc, t = sh(cmd, LOGS / f"build_iv_{name}.log", timeout=1800)
    return rc, out / f"{name}.vvp", t


def run(job):
    name, sim, exe, scen, seed = job["cfg"], job["sim"], job["exe"], job["scen"], job["seed"]
    bp, gap = SETTINGS.get(seed, (25, 10)) if job.get("bp") is None else (job["bp"], job["gap"])
    args = [f"+SCEN={scen}", f"+SEED={seed}", f"+BP={bp}", f"+GAP={gap}", f"+N={job.get('n', 200)}"]
    # Verilator: random power-up state of every non-reset variable (arrays included) - +verilator+rand+reset+2
    cmd = ([exe, "+verilator+rand+reset+2", f"+verilator+seed+{seed}"] if sim == "vl" else ["vvp", "-n", exe]) + args
    log = LOGS / f"{sim}_{name}_{scen}_s{seed}.log"
    rc, t = sh(cmd, log, timeout=job.get("timeout", 2400))
    txt = log.read_text(errors="replace")
    res = "PASS" if re.search(r"^RESULT PASS", txt, re.M) and rc == 0 else "FAIL"
    m = re.search(r"\[tb\] (\d+) responses \+ audits checked, (\d+) errors, (\d+) cycles", txt)
    metrics = [json.loads(x) for x in re.findall(r"^METRICS (\{.*\})$", txt, re.M)]
    return {**{k: v for k, v in job.items() if k != "exe"}, "bp": bp, "gap": gap, "result": res, "rc": rc,
            "seconds": round(t, 1), "checks": int(m.group(1)) if m else 0, "tb_errors": int(m.group(2)) if m else None,
            "cycles": int(m.group(3)) if m else None, "metrics": metrics,
            "notes": re.findall(r"^\[tb\] (?:mbist|ecc|rdw|audit): .*$", txt, re.M)[:4],
            "first_error": (re.search(r"ERROR: .*", txt).group(0) if re.search(r"ERROR: .*", txt) else ""),
            "log": str(log.relative_to(ROOT))}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    LOGS.mkdir(parents=True, exist_ok=True)
    only = set(x for x in a.only.split(",") if x)
    cfgs = configs(only)
    main_cfgs = {"sg_min4", "sg_hier"}
    iv_set = {"sg_min4": None, "sg_hier": ["smoke", "rdw", "ecc", "wprot", "byte_en"]}

    builds = {}
    with cf.ThreadPoolExecutor(max_workers=max(1, a.jobs // 2)) as ex:
        futs = {}
        for d in cfgs:
            futs[ex.submit(build, d, "vl")] = (d["name"], "vl")
            if d["name"] in iv_set:
                futs[ex.submit(build, d, "iv")] = (d["name"], "iv")
        for f in cf.as_completed(futs):
            rc, exe, t = f.result()
            builds[futs[f]] = {"rc": rc, "exe": str(exe), "seconds": round(t, 1)}
            print(f"[build] {futs[f]} rc={rc} {t:.0f}s", flush=True)

    jobs = []
    for d in cfgs:
        n = d["name"]
        seeds = ([1, 2, 3] if n == "sg_min4" else [1, 2]) if n in main_cfgs else [4]
        if a.quick:
            seeds = seeds[:1]
        for scen in scenarios(d):
            for sd in seeds:
                if builds[(n, "vl")]["rc"] == 0:
                    j = {"cfg": n, "sim": "vl", "exe": builds[(n, "vl")]["exe"], "scen": scen, "seed": sd}
                    if scen in ("perf", "conflict", "dma") and sd in (1, 4):
                        j.update({"bp": 0, "gap": 0})          # performance numbers without back-pressure (comparable)
                    jobs.append(j)
            if (n, "iv") in builds and builds[(n, "iv")]["rc"] == 0 and (iv_set[n] is None or scen in iv_set[n]):
                if scen != "perf":
                    jobs.append({"cfg": n, "sim": "iv", "exe": builds[(n, "iv")]["exe"], "scen": scen, "seed": 2})
                    # the Verilator twin of the cross-simulation job (seed 2 is part of the main seeds)
    results = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for r in ex.map(run, jobs):
            results.append(r)
            print(f"[run] {r['result']} {r['sim']} {r['cfg']} {r['scen']} s{r['seed']} "
                  f"checks={r['checks']} cyc={r['cycles']} {r['seconds']}s {r['first_error'][:100]}", flush=True)

    # cross-simulation identity: same config / scenario / seed / settings
    cross = []
    for r in results:
        if r["sim"] == "iv":
            twin = next((x for x in results if x["sim"] == "vl" and x["cfg"] == r["cfg"] and x["scen"] == r["scen"]
                         and x["seed"] == r["seed"]), None)
            if twin:
                cross.append({"cfg": r["cfg"], "scen": r["scen"], "seed": r["seed"], "iv": r["result"],
                              "vl": twin["result"], "cycles_iv": r["cycles"], "cycles_vl": twin["cycles"],
                              "checks_iv": r["checks"], "checks_vl": twin["checks"],
                              "identical": r["cycles"] == twin["cycles"] and r["checks"] == twin["checks"]})
    out = {"tools": {"verilator": subprocess.run(["verilator", "--version"], capture_output=True, text=True).stdout.strip(),
                     "icarus": subprocess.run(["iverilog", "-V"], capture_output=True, text=True).stdout.splitlines()[0]},
           "builds": {f"{k[1]}:{k[0]}": v for k, v in builds.items()},
           "results": results, "cross_sim": cross,
           "summary": {"jobs": len(results), "pass": sum(r["result"] == "PASS" for r in results),
                       "checks": sum(r["checks"] for r in results)}}
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports/regression.json").write_text(json.dumps(out, indent=1) + "\n")
    perf = [m for r in results if r["scen"] in ("perf", "conflict", "dma") and r["sim"] == "vl" for m in
            [{**x, "seed": r["seed"], "bp": r["bp"], "gap": r["gap"]} for x in r["metrics"]]]
    (ROOT / "reports/performance.json").write_text(json.dumps(perf, indent=1) + "\n")
    s = out["summary"]
    print(f"[regress] {s['pass']}/{s['jobs']} pass, {s['checks']} checks; cross-sim identical "
          f"{sum(c['identical'] for c in cross)}/{len(cross)}")
    return 0 if s["pass"] == s["jobs"] and all(b["rc"] == 0 for b in builds.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
