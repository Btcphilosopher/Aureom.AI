#!/usr/bin/env bash
# Final verification pass with the final testbench (RTL unchanged: synthesis / wrapper / connectivity / area
# from run_final.sh stand).  Records the RTL and testbench hashes at start and end.
set -uo pipefail
cd "$(dirname "$0")/.."
R0=$(cat rtl/*.sv rtl/*.svh | sha256sum | cut -c1-16); T0=$(cat tb/*.sv | sha256sum | cut -c1-16)
rm -rf reports/logs; mkdir -p reports/logs
step() { echo "== $1 $(date +%H:%M:%S)"; shift; "$@"; echo "   rc=$?"; }
step regression python3 scripts/run_tests.py --jobs 4
step physical   python3 scripts/run_physical.py
step mutants    python3 scripts/run_mutants.py
R1=$(cat rtl/*.sv rtl/*.svh | sha256sum | cut -c1-16); T1=$(cat tb/*.sv | sha256sum | cut -c1-16)
printf "rtl hash start %s end %s\ntb  hash start %s end %s\n" "$R0" "$R1" "$T0" "$T1" > reports/frozen_hash.txt
step report     python3 -I scripts/make_report.py
echo "FINAL2_DONE"
