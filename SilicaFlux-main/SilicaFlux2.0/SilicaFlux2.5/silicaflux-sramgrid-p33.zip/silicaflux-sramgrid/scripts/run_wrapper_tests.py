#!/usr/bin/env python3
"""SilicaFlux-HPC Project 33 SRAMGRID -- macro-wrapper timing / real-macro equivalence matrix.

Each case runs tb/tb_sg_macro_wrapper.sv: a GENERIC reference wrapper and a wrapper on the vendor's
own Verilog model of a real open-PDK macro (fetched at the pinned commits, never redistributed),
identical stimulus, every read checked at exactly the declared latency.  Icarus runs the vendor
models (IHP with +define+FUNCTIONAL, SRAMLIB_VENDOR_MODELS for the leaf clock-to-q delay); Verilator
runs the generic pair (timing semantics, assertions).  Writes reports/wrapper.{json,md}.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXT = Path(os.environ.get("SG_EXT", ROOT.parent / "ext"))
IHPV = "ihp/ihp-sg13g2/libs.ref/sg13g2_sram/verilog"

# name, macro id, width, depth, mask lanes, port model, out_reg, vendor files
CASES = [
    ("ihp1p_1024x32_secded72", 21, 72, 1024, 1, 0, 0, [f"{IHPV}/RM_IHPSG13_1P_1024x32_c2_bm_bist.v", f"{IHPV}/RM_IHPSG13_1P_core_behavioral_bm_bist.v"]),
    ("ihp1p_1024x32_secded72_oreg", 21, 72, 1024, 1, 0, 1, [f"{IHPV}/RM_IHPSG13_1P_1024x32_c2_bm_bist.v", f"{IHPV}/RM_IHPSG13_1P_core_behavioral_bm_bist.v"]),
    ("ihp1p_1024x32_parity72", 21, 72, 1024, 8, 0, 0, [f"{IHPV}/RM_IHPSG13_1P_1024x32_c2_bm_bist.v", f"{IHPV}/RM_IHPSG13_1P_core_behavioral_bm_bist.v"]),
    ("ihp1p_2048x32_secded72", 24, 72, 2048, 1, 0, 1, [f"{IHPV}/RM_IHPSG13_1P_2048x32_c2_bm_bist.v", f"{IHPV}/RM_IHPSG13_1P_core_behavioral_bm_bist.v"]),
    ("ihp2p_512x32_1r1w_parity72", 66, 72, 512, 8, 1, 0, [f"{IHPV}/RM_IHPSG13_2P_512x32_c2_bm_bist.v", f"{IHPV}/RM_IHPSG13_2P_core_behavioral_bm_bist_ideal.v"]),
    ("ihp2p_512x32_2rw_secded72_oreg", 66, 72, 512, 1, 2, 1, [f"{IHPV}/RM_IHPSG13_2P_512x32_c2_bm_bist.v", f"{IHPV}/RM_IHPSG13_2P_core_behavioral_bm_bist_ideal.v"]),
    ("sky130_32x256_1rw_bytes64", 1, 64, 256, 8, 0, 0, ["sky130_sram_macros/sky130_sram_1kbyte_1rw1r_32x256_8/sky130_sram_1kbyte_1rw1r_32x256_8.v"]),
    ("sky130_32x256_1r1w_bytes64_oreg", 1, 64, 256, 8, 1, 1, ["sky130_sram_macros/sky130_sram_1kbyte_1rw1r_32x256_8/sky130_sram_1kbyte_1rw1r_32x256_8.v"]),
    ("gf180_512x8_1rw_bytes16", 13, 16, 512, 2, 0, 0, ["gf180_sram/cells/gf180mcu_fd_ip_sram__sram512x8m8wm1/gf180mcu_fd_ip_sram__sram512x8m8wm1.v"]),
]


def files():
    fs = [l.strip() for l in (ROOT / "rtl/files.f").read_text().splitlines() if l.strip() and not l.startswith("+")]
    return [f for f in fs if "blackboxes" not in f]


INC = ["-Irtl", "-Ithird_party/silicaflux-sramlib/rtl/mem", "-Ithird_party/silicaflux-sramlib/rtl/mem/backends/asic",
       "-Ithird_party/silicaflux-ras/rtl"]


def defs(c, asic, n=6000, seed=7):
    name, mid, w, d, m, pm, orr, _ = c
    return [f"-DMW_WIDTH={w}", f"-DMW_DEPTH={d}", f"-DMW_MASK={m}", f"-DMW_PM={pm}", f"-DMW_OREG={orr}",
            f"-DMW_MACRO={mid}", f"-DMW_ASIC={asic}", f"-DMW_N={n}", f"-DMW_SEED={seed}"]


def run(cmd, log):
    p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=3600)
    log.write_text("$ " + " ".join(cmd) + "\n" + p.stdout + p.stderr)
    return p.returncode, p.stdout + p.stderr


def main() -> int:
    out = ROOT / "build/wrapper"
    out.mkdir(parents=True, exist_ok=True)
    logs = ROOT / "reports/logs"
    logs.mkdir(parents=True, exist_ok=True)
    res = []
    for c in CASES:
        name = c[0]
        vf = [str(EXT / f) for f in c[7]]
        missing = [f for f in vf if not Path(f).exists()]
        if missing:
            res.append({"case": name, "sim": "icarus+vendor", "result": "NOT RUN", "why": f"vendor model missing: {missing}"})
            continue
        vvp = out / f"{name}.vvp"
        rc, txt = run(["iverilog", "-g2012", "-DFUNCTIONAL", "-DSRAMLIB_VENDOR_MODELS", "-DSRAMLIB_POISON"] + INC +
                      defs(c, 1) + ["tb/timescale.sv"] + files() + vf + ["tb/tb_sg_macro_wrapper.sv", "-s", "tb_sg_macro_wrapper", "-o", str(vvp)],
                      logs / f"wrapper_build_{name}.log")
        if rc:
            res.append({"case": name, "sim": "icarus+vendor", "result": "BUILD FAIL", "why": txt[-600:]})
            continue
        rc, txt = run(["vvp", "-n", str(vvp)], logs / f"wrapper_{name}.log")
        m = re.search(r"\[tbw\] (.*)", txt)
        res.append({"case": name, "macro_id": c[1], "width": c[2], "depth": c[3], "mask_lanes": c[4], "port_model": c[5],
                    "out_reg": c[6], "sim": "icarus+vendor", "result": "PASS" if "RESULT PASS" in txt else "FAIL",
                    "summary": m.group(1) if m else txt[-400:]})
        print(f"[wrapper] {res[-1]['result']} {name}: {res[-1].get('summary', res[-1].get('why'))}", flush=True)
    # Verilator: generic pair, assertions on (timing semantics, OUT_REG hold, test port)
    for c in [CASES[0], CASES[1], CASES[4], CASES[5]]:
        name = c[0] + "_generic"
        mdir = out / f"vl_{name}"
        rc, txt = run(["verilator", "--binary", "--timing", "--assert", "-DSG_ASSERT", "-DSRAMLIB_POISON", "--x-assign",
                       "unique", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD"] +
                      INC + defs(c, 0) + files() + ["third_party/silicaflux-sramlib/rtl/mem/backends/asic/stubs/sram_macro_blackboxes.sv",
                                                    "tb/tb_sg_macro_wrapper.sv", "--top-module", "tb_sg_macro_wrapper",
                                                    "-Mdir", str(mdir), "-o", "sim"], logs / f"wrapper_build_{name}.log")
        if rc:
            res.append({"case": name, "sim": "verilator", "result": "BUILD FAIL", "why": txt[-600:]})
            continue
        rc, txt = run([str(mdir / "sim"), "+verilator+rand+reset+2", "+verilator+seed+7"], logs / f"wrapper_{name}.log")
        m = re.search(r"\[tbw\] (.*)", txt)
        res.append({"case": name, "sim": "verilator", "result": "PASS" if "RESULT PASS" in txt else "FAIL",
                    "summary": m.group(1) if m else txt[-400:]})
        print(f"[wrapper] {res[-1]['result']} {name}: {res[-1].get('summary')}", flush=True)
    (ROOT / "reports/wrapper.json").write_text(json.dumps(res, indent=1) + "\n")
    ok = all(r["result"] == "PASS" for r in res)
    print(f"[wrapper] {sum(r['result'] == 'PASS' for r in res)}/{len(res)} pass")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
