#!/usr/bin/env python3
"""SilicaFlux-HPC Project 33 SRAMGRID -- macro connectivity report from the synthesized netlist.

Reads reports/synth/<cfg>_asic/netlist.json.gz (Yosys, flattened, macros as black boxes) and, for
every SRAM macro instance, resolves each pin bit to a constant or a named net:

  * clock pin on the top-level clk net (no gating inserted by the grid)
  * enables (MEN / WEN / REN, csb / web, CEN / GWEN) driven by logic
  * address bits driven; data-in / mask bits driven or tied 0 (padding columns of the tiling)
  * data-out bits loaded or unused (padding)
  * tie-offs required by the datasheet / manifest (IHP: *_DLY = 1, *_BIST_EN = 0, other *_BIST_* = 0)
  * supply pins from the LEF abstract (not in the RTL netlist: USE_POWER_PINS off) -> PDN must connect them

and maps the instance to its logical bank, tile row / column and the stored-word bits it holds.
Writes reports/connectivity_<cfg>.json and reports/connectivity_<cfg>.md.
"""
from __future__ import annotations

import gzip
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import sg_config  # noqa: E402

REQUIRED_TIES = {  # pin -> required constant (manifest pin_map / datasheet)
    "IHP": {"A_DLY": "1", "A_BIST_EN": "0", "A_BIST_CLK": "0", "A_BIST_MEN": "0", "A_BIST_WEN": "0", "A_BIST_REN": "0",
            "A_BIST_ADDR": "0", "A_BIST_DIN": "0", "A_BIST_BM": "0",
            "B_DLY": "1", "B_BIST_EN": "0", "B_BIST_CLK": "0", "B_BIST_MEN": "0", "B_BIST_WEN": "0", "B_BIST_REN": "0",
            "B_BIST_ADDR": "0", "B_BIST_DIN": "0", "B_BIST_BM": "0"},
}
CLOCK_PINS = {"A_CLK", "B_CLK", "clk0", "clk1", "CLK"}
CTRL_PINS = {"A_MEN", "A_WEN", "A_REN", "B_MEN", "B_WEN", "B_REN", "csb0", "web0", "csb1", "CEN", "GWEN"}
ADDR_PINS = {"A_ADDR", "B_ADDR", "addr0", "addr1", "A"}
DIN_PINS = {"A_DIN", "B_DIN", "din0", "D"}
MASK_PINS = {"A_BM", "B_BM", "wmask0", "WEN"}
DOUT_PINS = {"A_DOUT", "B_DOUT", "dout0", "dout1", "Q"}


def main(cfgname: str) -> int:
    nl = ROOT / f"reports/synth/{cfgname}_asic/netlist.json.gz"
    js = json.loads(gzip.open(nl).read())
    top = js["modules"]["sg_top"]
    d = json.loads((ROOT / f"gen/{cfgname}_asic/derived.json").read_text())
    abstracts = sg_config.load_abstracts()
    masters = {r["macro"]["macro"]: r for r in d["regions"]}
    bank_reg = {b["index"]: next(r for r in d["regions"] if r["name"] == b["region"]) for b in d["banks"]}
    # bit -> best net name; loads per bit
    names = {}
    for n, v in top["netnames"].items():
        hide = v.get("hide_name", 0)
        for b in v["bits"]:
            if isinstance(b, int):
                if b not in names or (names[b][1] and not hide) or (hide == names[b][1] and len(n) < len(names[b][0])):
                    names[b] = (n, hide)
    port_bits = {}
    for pn, p in top["ports"].items():
        for i, b in enumerate(p["bits"]):
            if isinstance(b, int):
                port_bits[b] = f"{pn}[{i}]" if len(p["bits"]) > 1 else pn
    loads = defaultdict(int)
    for cn, c in top["cells"].items():
        for pin, bits in c["connections"].items():
            if c.get("port_directions", {}).get(pin, "input") == "input":
                for b in bits:
                    if isinstance(b, int):
                        loads[b] += 1
    for pn, p in top["ports"].items():
        if p["direction"] == "output":
            for b in p["bits"]:
                if isinstance(b, int):
                    loads[b] += 1
    clk_bits = set(b for b in top["ports"]["clk"]["bits"] if isinstance(b, int))
    rows, anomalies = [], []
    for cn, c in sorted(top["cells"].items()):
        if c["type"] not in masters:
            continue
        a = abstracts[c["type"]]
        bank = int(re.search(r"g_bank\[(\d+)\]", cn).group(1))
        reg = bank_reg[bank]
        pmod = reg["port_model"]
        tr = int(re.search(r"g_r\[(\d+)\]", cn).group(1)) if "g_r[" in cn else 0
        tc = int(re.search(r"g_c\[(\d+)\]", cn).group(1)) if "g_c[" in cn else 0
        mw = a["data_width"]
        sw = reg["stored_width"]
        lo, hi = tc * mw, min(sw, (tc + 1) * mw) - 1
        rec = {"inst": cn, "master": c["type"], "region": reg["name"], "bank": bank, "tile_row": tr, "tile_col": tc,
               "stored_bits": [lo, hi] if lo <= hi else None, "padding_bits": max(0, (tc + 1) * mw - max(sw, tc * mw)),
               "words": [tr * a["words"], (tr + 1) * a["words"] - 1], "pins": {}}
        fam = "IHP" if c["type"].startswith("RM_IHP") else None
        for pin, bits in c["connections"].items():
            const = [b for b in bits if not isinstance(b, int)]
            driven = [b for b in bits if isinstance(b, int)]
            info = {"width": len(bits), "const0": sum(1 for b in const if b == "0"), "const1": sum(1 for b in const if b == "1"),
                    "constx": sum(1 for b in const if b not in ("0", "1")), "nets": len(driven)}
            if pin in DOUT_PINS:
                info["loaded"] = sum(1 for b in driven if loads[b] > 0)
                info["unloaded"] = len(driven) - info["loaded"]
            if driven:
                n0 = names.get(driven[0], ("?", 1))[0]
                info["example_net"] = port_bits.get(driven[0], n0)
            rec["pins"][pin] = info
            # checks (port-model aware: 1R1W uses port A as the write port and port B as the read port)
            side = pin[0] if pin[:2] in ("A_", "B_") else "A"
            two_port = c["type"].startswith("RM_IHPSG13_2P")
            uses_b = two_port and pmod in ("1r1w", "2rw")
            if pin in CLOCK_PINS and (side == "A" or uses_b) and not all(b in clk_bits for b in driven):
                anomalies.append(f"{cn}: clock pin {pin} not on the top-level clk net")
            if fam and pin in REQUIRED_TIES[fam]:
                want = REQUIRED_TIES[fam][pin]
                if driven or any(b != want for b in const):
                    anomalies.append(f"{cn}: {pin} must be tied to {want}")
            used = (side == "A" or uses_b) and "BIST" not in pin
            reads = ((side == "A" and pmod in ("1rw", "2rw")) or (side == "B" and pmod in ("1r1w", "2rw"))) and "BIST" not in pin
            writes = ((side == "A") or (side == "B" and pmod == "2rw")) and "BIST" not in pin
            if pin.endswith("_MEN") and used and info["nets"] == 0:
                anomalies.append(f"{cn}: {pin} is constant on a used port")
            if pin.endswith("_REN") and reads and info["nets"] == 0:
                anomalies.append(f"{cn}: {pin} is constant on a reading port")
            if pin.endswith("_WEN") and pin[:2] in ("A_", "B_") and writes and info["nets"] == 0:
                anomalies.append(f"{cn}: {pin} is constant on a writing port")
            if pin in ADDR_PINS and used and pin[:2] in ("A_", "B_") and info["nets"] != len(bits):
                anomalies.append(f"{cn}: address pin {pin} has constant bits ({info['nets']}/{len(bits)} driven)")
            if pin in DIN_PINS and writes and pin[:2] in ("A_", "B_"):
                want_driven = mw - rec["padding_bits"]
                if info["nets"] < want_driven:
                    anomalies.append(f"{cn}: {pin} only {info['nets']} bits driven, {want_driven} stored bits mapped")
            if pin in DOUT_PINS and reads and pin[:2] in ("A_", "B_"):
                if info.get("loaded", 0) < mw - rec["padding_bits"]:
                    anomalies.append(f"{cn}: {pin} only {info.get('loaded')} bits loaded on a reading port")
        rec["port_model"] = pmod
        rec["supply_pins_lef"] = {n: v["layers"] for n, v in a["power_pins"].items()}
        rows.append(rec)
    out = {"config": cfgname, "netlist": str(nl.relative_to(ROOT)), "macros": len(rows), "anomalies": anomalies,
           "ok": not anomalies and len(rows) == sum(r["macro"]["count"] * r["banks"] for r in d["regions"]),
           "instances": rows}
    (ROOT / f"reports/connectivity_{cfgname}.json").write_text(json.dumps(out, indent=1) + "\n")
    # markdown
    L = [f"# Macro connectivity — `{cfgname}` (from the synthesized netlist)", "",
         f"Netlist `{out['netlist']}` (Yosys 0.33, flattened, SRAM macros as the library's pin-only black boxes). "
         f"{len(rows)} macro instances; **{len(anomalies)} anomalies**.", "",
         "Every pin bit is resolved to a constant or a net of the netlist. Checks: clock on the top-level `clk`; "
         "enables and every address bit driven by logic; data-in / mask bits driven for every stored bit the tile "
         "holds (padding bits tied 0); data-out bits of stored bits loaded; datasheet tie-offs (IHP `A_DLY = 1`, "
         "`A_BIST_* = 0`). Supply pins are not in the RTL netlist (`USE_POWER_PINS` off): the power-grid step must "
         "connect them (names / layers from the LEF).", "",
         "| Instance (bank.row.col) | Master | Region (ports) | Stored bits | Words | CLK | A MEN/WEN/REN | A ADDR driven | A DIN driven / tied 0 | A BM driven / tied 0 | read DOUT loaded / unused | B ADDR driven | Tie-offs | Supply pins (LEF) |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        p = r["pins"]
        pa = lambda k: p.get(k, {})  # noqa: E731
        ties = ", ".join(f"{k}={'1' if pa(k).get('const1') else '0'}" for k in ("A_DLY", "A_BIST_EN") if k in p)
        ctrl = "/".join("drv" if pa(k).get("nets") else "const" for k in ("A_MEN", "A_WEN", "A_REN") if k in p)
        rd = "B_DOUT" if r["port_model"] == "1r1w" else "A_DOUT"
        L.append(f"| b{r['bank']}.r{r['tile_row']}.c{r['tile_col']} | `{r['master']}` | {r['region']} ({r['port_model']}) | "
                 f"{r['stored_bits'][0]}–{r['stored_bits'][1]} | {r['words'][0]}–{r['words'][1]} | "
                 f"{'clk' if pa('A_CLK').get('example_net') == 'clk' else pa('A_CLK').get('example_net', '?')} | {ctrl} | "
                 f"{pa('A_ADDR').get('nets', 0)}/{pa('A_ADDR').get('width', 0)} | "
                 f"{pa('A_DIN').get('nets', 0)} / {pa('A_DIN').get('const0', 0)} | {pa('A_BM').get('nets', 0)} / {pa('A_BM').get('const0', 0)} | "
                 f"{pa(rd).get('loaded', 0)} / {pa(rd).get('unloaded', 0)} | "
                 f"{(str(pa('B_ADDR').get('nets', 0)) + '/' + str(pa('B_ADDR').get('width', 0))) if 'B_ADDR' in p else '—'} | "
                 f"{ties} | {', '.join(r['supply_pins_lef'])} |")
    if anomalies:
        L += ["", "## Anomalies", ""] + [f"* {x}" for x in anomalies]
    (ROOT / f"reports/connectivity_{cfgname}.md").write_text("\n".join(L) + "\n")
    print(f"[conn] {cfgname}: {len(rows)} macros, {len(anomalies)} anomalies")
    for x in anomalies[:10]:
        print("   ", x)
    return 0 if out["ok"] else 1


if __name__ == "__main__":
    rc = 0
    for c in (sys.argv[1:] or ["sg_min4", "sg_hier"]):
        rc |= main(c)
    sys.exit(rc)
