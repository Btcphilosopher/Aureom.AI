#!/usr/bin/env python3
"""SilicaFlux-HPC Project 33 SRAMGRID -- physical flow with the brief's scaling gate.

  1. sg_min4 (four banks, one shared region): placements for every strategy, each executed in tclsh
     against the mock OpenDB, each checked by the independent checker; checker self-test (mutations).
  2. GATE: sg_hier is placed ONLY if sg_min4's simulation regression (reports/regression.json) passed
     every job AND every sg_min4 placement is clean.
  3. sg_hier: the same steps.
Writes reports/physical.{json,md}.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STRATS = ["adjacent_vector", "around_tensor", "central_shared", "perimeter"]


def sh(cmd, timeout=3600):
    p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout + p.stderr


def do_config(name):
    rec = {"config": name, "strategies": {}}
    rc, out = sh([sys.executable, "-I", "scripts/gen_placement.py", f"config/{name}.json"], timeout=7200)
    rec["generate_rc"] = rc
    insts = json.loads((ROOT / f"reports/synth/{name}_asic/macro_instances.json").read_text())
    it = ROOT / f"build/{name}_instances.txt"
    it.parent.mkdir(exist_ok=True)
    it.write_text("".join(f"{i['inst']}\t{i['master']}\n" for i in insts))
    for s in STRATS:
        pdir = ROOT / f"physical/placement/{name}/{s}"
        dump = pdir / "mock_odb.json"
        rc1, o1 = sh(["tclsh8.6", "physical/mock_odb.tcl", str(it), str(pdir / "macro_place.tcl"), str(dump)])
        rc2, o2 = sh([sys.executable, "-I", "scripts/check_placement.py", str(pdir), "--mock-dump", str(dump)])
        chk = json.loads((pdir / "check.json").read_text())
        wire = json.loads((pdir / "wire.json").read_text())
        rec["strategies"][s] = {"mock_odb": o1.strip().splitlines()[-1] if o1.strip() else "", "mock_rc": rc1,
                                "check_ok": chk["ok"], "violations": len(chk["violations"]),
                                "first_violations": chk["violations"][:3], "macros": chk["macros"],
                                "min_spacing_um": chk["min_spacing_um"], "weighted_mean_mm": wire["weighted_mean_mm"],
                                "crossbar_mm_bits": wire["sparse_crossbar_mm_bits"], "regions": wire["regions"]}
        print(f"[physical] {name} {s}: mock rc {rc1}, check {'OK' if chk['ok'] else 'FAIL'} "
              f"({len(chk['violations'])} violations), weighted distance {wire['weighted_mean_mm']} mm", flush=True)
    rc, out = sh([sys.executable, "-I", "scripts/check_placement.py", "--selftest",
                  str(ROOT / f"physical/placement/{name}/central_shared")])
    st = json.loads(out.strip().splitlines()[-1])
    rec["selftest"] = st
    rec["selftest_ok"] = all(x["caught"] for x in st)
    rec["ok"] = rec["generate_rc"] == 0 and all(v["check_ok"] and v["mock_rc"] == 0 for v in rec["strategies"].values()) \
        and rec["selftest_ok"]
    print(f"[physical] {name}: checker self-test {sum(x['caught'] for x in st)}/{len(st)} mutations caught", flush=True)
    return rec


def main() -> int:
    res = {"configs": []}
    m4 = do_config("sg_min4")
    res["configs"].append(m4)
    reg = json.loads((ROOT / "reports/regression.json").read_text()) if (ROOT / "reports/regression.json").exists() else None
    m4_sim = [r for r in (reg["results"] if reg else []) if r["cfg"] == "sg_min4"]
    gate = {"sg_min4_sim_jobs": len(m4_sim), "sg_min4_sim_pass": sum(r["result"] == "PASS" for r in m4_sim),
            "sg_min4_placement_ok": m4["ok"]}
    gate["open"] = gate["sg_min4_sim_jobs"] > 0 and gate["sg_min4_sim_pass"] == gate["sg_min4_sim_jobs"] and m4["ok"]
    res["gate"] = gate
    print(f"[physical] scaling gate: {gate}", flush=True)
    if gate["open"]:
        res["configs"].append(do_config("sg_hier"))
    else:
        print("[physical] sg_hier NOT placed: sg_min4 banking / placement not validated", flush=True)
    (ROOT / "reports/physical.json").write_text(json.dumps(res, indent=1) + "\n")
    return 0 if gate["open"] and all(c["ok"] for c in res["configs"]) else 1


if __name__ == "__main__":
    sys.exit(main())
