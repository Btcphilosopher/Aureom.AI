#!/usr/bin/env bash
# SilicaFlux-HPC Project 33 SRAMGRID -- build the deliverable archive (no commit).
#   scripts/package.sh <out.zip>
# Excludes build/ (simulator / synthesis scratch).  Large Yosys logs are gzipped.  Writes MANIFEST.sha256.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(realpath -m "${1:-$ROOT/../silicaflux-sramgrid-p33.zip}")"
cd "$ROOT"
find reports/synth -name 'yosys.log' -size +200k -exec gzip -f {} \;
rm -f MANIFEST.sha256
find . -type f ! -path './build/*' ! -name 'MANIFEST.sha256' ! -name '*.pyc' ! -path '*/__pycache__/*' -print0 \
  | sort -z | xargs -0 sha256sum > MANIFEST.sha256
cd ..
rm -f "$OUT"
zip -qr "$OUT" "$(basename "$ROOT")" -x "$(basename "$ROOT")/build/*" -x '*/__pycache__/*' -x '*.pyc'
echo "[package] $OUT ($(du -h "$OUT" | cut -f1)), $(wc -l < "$ROOT/MANIFEST.sha256") files in MANIFEST.sha256"
