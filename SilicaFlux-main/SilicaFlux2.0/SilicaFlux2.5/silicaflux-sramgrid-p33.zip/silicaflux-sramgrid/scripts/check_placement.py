#!/usr/bin/env python3
"""SilicaFlux-HPC Project 33 SRAMGRID -- independent macro-placement checker.

Does NOT import gen_placement.py.  It re-derives every macro's geometry from the
EMITTED files (macro_place.tcl and macro_place.def) and the LEF abstracts, and
checks them against the synthesized netlist's macro list and the floorplan file:

  C1 completeness   every netlist macro placed exactly once in the Tcl and in the DEF; nothing else
  C2 master         Tcl master == netlist master == DEF master
  C3 orientation    in the floorplan's allowed set AND legal by the LEF SYMMETRY
  C4 grid           x on the site grid, y on the row grid (from the core origin); on the 0.005 um grid
  C5 core           macro + halo inside the core
  C6 spacing        any two macros >= channel_um apart (so no overlap)
  C7 keep-out       macro + halo clear of every placement blockage and logic block
  C8 pin escape     the signal-pin edge (from the LEF pin rectangles, transformed by the orientation)
                    has pin_escape_um of free space inside the core, clear of macros and blockages
  C9 consistency    Tcl and DEF agree (location, orientation), DEF components FIXED with the halo
 C10 mock OpenDB    (optional) the Tcl executed in tclsh against a mock OpenDB placed the same
                    instances at the same database coordinates, FIRM

  check_placement.py <placement dir> [--mock-dump <json>]   -> exit 1 on any violation
  check_placement.py --selftest <placement dir>             -> every mutation must be caught
"""
from __future__ import annotations

import argparse
import copy
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEF2ORI = {"N": "R0", "FS": "MX", "FN": "MY", "S": "R180", "W": "R90", "E": "R270", "FW": "MYR90", "FE": "MXR90"}


def load(pdir: Path):
    meta = json.loads((pdir / "placement.json").read_text())       # only floorplan facts are taken from it
    cfgname = meta["config"]
    fp = json.loads((ROOT / f"config/floorplan/{meta['floorplan']}.json").read_text())
    tech = json.loads((ROOT / "physical/abstracts/tech_ihp_sg13g2.json").read_text())
    insts = json.loads((ROOT / f"reports/synth/{cfgname}_asic/macro_instances.json").read_text())
    tcl = []
    for line in (pdir / "macro_place.tcl").read_text().splitlines():
        m = re.match(r"^sg_place \{(.+)\} (\S+) ([-0-9.]+) ([-0-9.]+) (\S+)\s*$", line)
        if m:
            tcl.append({"inst": m.group(1), "master": m.group(2), "x": float(m.group(3)), "y": float(m.group(4)),
                        "orient": m.group(5)})
    dtxt = (pdir / "macro_place.def").read_text()
    dbu = int(re.search(r"UNITS DISTANCE MICRONS (\d+)", dtxt).group(1))
    deff = []
    for m in re.finditer(r"^\s*- (\S+) (\S+) \+ (FIXED|PLACED) \( (-?\d+) (-?\d+) \) (\S+)(.*);", dtxt, re.M):
        halo = re.search(r"\+ HALO (\d+) (\d+) (\d+) (\d+)", m.group(7))
        deff.append({"inst": m.group(1), "master": m.group(2), "status": m.group(3), "x": int(m.group(4)) / dbu,
                     "y": int(m.group(5)) / dbu, "orient": DEF2ORI.get(m.group(6), m.group(6)),
                     "halo": [int(v) / dbu for v in halo.groups()] if halo else None})
    return meta, fp, tech, insts, tcl, deff, dbu


def abstract(master):
    return json.loads((ROOT / f"physical/abstracts/{master}.json").read_text())


def bbox(x, y, a, orient):
    w, h = a["width_um"], a["height_um"]
    if orient in ("R90", "R270", "MXR90", "MYR90"):
        w, h = h, w
    return [x, y, x + w, y + h]


def pin_edge(a, orient):
    """Edge of the oriented macro that carries the signal pins, from the LEF pin rectangles."""
    w, h = a["width_um"], a["height_um"]
    ys = [p["bbox"][1] for p in a["pins"].values() if p["use"] == "SIGNAL"]
    ye = [p["bbox"][3] for p in a["pins"].values() if p["use"] == "SIGNAL"]
    xs = [p["bbox"][0] for p in a["pins"].values() if p["use"] == "SIGNAL"]
    xe = [p["bbox"][2] for p in a["pins"].values() if p["use"] == "SIGNAL"]
    if max(ye) <= 1.0:
        e = "bottom"
    elif min(ys) >= h - 1.0:
        e = "top"
    elif max(xe) <= 1.0:
        e = "left"
    elif min(xs) >= w - 1.0:
        e = "right"
    else:
        return None
    flip = {"R0": {}, "MX": {"bottom": "top", "top": "bottom"}, "MY": {"left": "right", "right": "left"},
            "R180": {"bottom": "top", "top": "bottom", "left": "right", "right": "left"}}
    if orient not in flip:
        return None
    return flip[orient].get(e, e)


def strip(bb, edge, d):
    if edge == "bottom":
        return [bb[0], bb[1] - d, bb[2], bb[1]]
    if edge == "top":
        return [bb[0], bb[3], bb[2], bb[3] + d]
    if edge == "left":
        return [bb[0] - d, bb[1], bb[0], bb[3]]
    return [bb[2], bb[1], bb[2] + d, bb[3]]


def ov(a, b, eps=1e-6):
    return a[0] < b[2] - eps and b[0] < a[2] - eps and a[1] < b[3] - eps and b[1] < a[3] - eps


def gap(a, b):
    dx = max(b[0] - a[2], a[0] - b[2], 0.0)
    dy = max(b[1] - a[3], a[1] - b[3], 0.0)
    return max(dx, dy) if (dx == 0 or dy == 0) else (dx ** 2 + dy ** 2) ** 0.5


def on_grid(v, g, o=0.0):
    k = (v - o) / g
    return abs(k - round(k)) < 1e-6


def check(pdir: Path, mock_dump: Path | None = None, data=None):
    meta, fp, tech, insts, tcl, deff, dbu = data if data else load(pdir)
    viol = []

    def V(rule, msg):
        viol.append({"rule": rule, "msg": msg})

    core = meta["core"]
    halo, chan, pesc = fp["halo_um"], fp["channel_um"], fp["pin_escape_um"]
    sw, rh = tech["site"]["size"]
    g = tech["mfg_grid_um"]
    net = {i["inst"]: i["master"] for i in insts}
    # C1 / C2
    seen = {}
    for t in tcl:
        if t["inst"] in seen:
            V("C1", f"{t['inst']} placed twice in the Tcl")
        seen[t["inst"]] = t
        if t["inst"] not in net:
            V("C1", f"{t['inst']} is not a macro of the netlist")
        elif net[t["inst"]] != t["master"]:
            V("C2", f"{t['inst']}: Tcl master {t['master']} != netlist {net[t['inst']]}")
    for n in net:
        if n not in seen:
            V("C1", f"netlist macro {n} not placed")
    dseen = {d["inst"]: d for d in deff}
    if len(dseen) != len(deff):
        V("C1", "duplicate DEF component")
    for n in net:
        if n not in dseen:
            V("C1", f"netlist macro {n} missing from the DEF")
    # geometry
    boxes = []
    for t in tcl:
        if t["master"] not in {i["master"] for i in insts}:
            continue
        a = abstract(t["master"])
        o = t["orient"]
        if o not in fp["orientations"]:
            V("C3", f"{t['inst']}: orientation {o} not allowed by the floorplan {fp['orientations']}")
        if o not in a["legal_orientations_lef"]:
            V("C3", f"{t['inst']}: orientation {o} not legal for LEF SYMMETRY {a['symmetry']}")
        if not on_grid(t["x"], sw, core[0]) or not on_grid(t["y"], rh, core[1]):
            V("C4", f"{t['inst']}: ({t['x']}, {t['y']}) not on the site/row grid ({sw} x {rh} from {core[:2]})")
        if not on_grid(t["x"], g) or not on_grid(t["y"], g) or not on_grid(t["x"], 1.0 / dbu) or not on_grid(t["y"], 1.0 / dbu):
            V("C4", f"{t['inst']}: ({t['x']}, {t['y']}) not on the manufacturing grid {g}")
        bb = bbox(t["x"], t["y"], a, o)
        hb = [bb[0] - halo, bb[1] - halo, bb[2] + halo, bb[3] + halo]
        if hb[0] < core[0] - 1e-6 or hb[1] < core[1] - 1e-6 or hb[2] > core[2] + 1e-6 or hb[3] > core[3] + 1e-6:
            V("C5", f"{t['inst']}: macro + halo {hb} outside the core {core}")
        for b in fp["blockages"]:
            if ov(hb, b["rect"]):
                V("C7", f"{t['inst']}: macro + halo overlaps placement blockage {b['name']}")
        for k, b in fp["blocks"].items():
            if ov(hb, b["rect"]):
                V("C7", f"{t['inst']}: macro + halo overlaps logic block {k}")
        e = pin_edge(a, o)
        if e is None:
            V("C8", f"{t['inst']}: signal pins not on one edge / orientation {o} unsupported")
        boxes.append((t, bb, e))
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            a, b = boxes[i][1], boxes[j][1]
            if ov(a, b):
                V("C6", f"{boxes[i][0]['inst']} overlaps {boxes[j][0]['inst']}")
            elif gap(a, b) < chan - 1e-6:
                V("C6", f"{boxes[i][0]['inst']} and {boxes[j][0]['inst']} only {gap(a, b):.3f} um apart (< channel {chan})")
    for t, bb, e in boxes:
        if e is None:
            continue
        s = strip(bb, e, pesc)
        if s[0] < core[0] - 1e-6 or s[1] < core[1] - 1e-6 or s[2] > core[2] + 1e-6 or s[3] > core[3] + 1e-6:
            V("C8", f"{t['inst']}: pin-escape strip ({e}) leaves the core")
        for u, bb2, _ in boxes:
            if u is not t and ov(s, bb2):
                V("C8", f"{t['inst']}: pin edge ({e}) faces {u['inst']} within {pesc} um")
        for b in fp["blockages"]:
            if ov(s, b["rect"]):
                V("C8", f"{t['inst']}: pin edge ({e}) blocked by {b['name']}")
    # C9
    for t in tcl:
        d = dseen.get(t["inst"].replace("/", "_"))
        if not d:
            continue
        if abs(d["x"] - t["x"]) > 1e-6 or abs(d["y"] - t["y"]) > 1e-6 or d["orient"] != t["orient"] or d["master"] != t["master"]:
            V("C9", f"{t['inst']}: Tcl ({t['x']},{t['y']},{t['orient']}) != DEF ({d['x']},{d['y']},{d['orient']})")
        if d["status"] != "FIXED" or d["halo"] != [halo] * 4:
            V("C9", f"{t['inst']}: DEF component not FIXED with a {halo} um halo")
    # C10
    if mock_dump:
        mk = json.loads(mock_dump.read_text())
        mp = {m["inst"]: m for m in mk["placed"]}
        for t in tcl:
            m = mp.get(t["inst"])
            if not m:
                V("C10", f"{t['inst']}: not placed by the Tcl executed against the mock OpenDB")
            elif (m["x"], m["y"], m["orient"], m["status"]) != (round(t["x"] * dbu), round(t["y"] * dbu), t["orient"], "FIRM"):
                V("C10", f"{t['inst']}: mock OpenDB has {m}, Tcl says ({t['x']},{t['y']},{t['orient']})")
        if mk.get("errors"):
            V("C10", f"mock OpenDB execution errors: {mk['errors'][:3]}")
    macro_area = sum((b[2] - b[0]) * (b[3] - b[1]) for _, b, _ in boxes)
    return {"dir": str(pdir.relative_to(ROOT)), "config": meta["config"], "strategy": meta["strategy"],
            "macros": len(tcl), "netlist_macros": len(net), "violations": viol, "ok": not viol,
            "macro_area_um2": round(macro_area, 2),
            "min_spacing_um": round(min((gap(boxes[i][1], boxes[j][1]) for i in range(len(boxes))
                                         for j in range(i + 1, len(boxes))), default=0.0), 3),
            "rules": ["C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9"] + (["C10"] if mock_dump else [])}


def selftest(pdir: Path):
    """Mutate a clean placement; each mutation must be caught by its rule."""
    base = load(pdir)
    meta, fp, tech, insts, tcl, deff, dbu = base
    assert check(pdir, data=base)["ok"], "selftest needs a clean placement"
    sw, rh = tech["site"]["size"]
    t0, t1 = tcl[0], tcl[1]
    a0 = abstract(t0["master"])
    core = meta["core"]

    def mut(name, rule, f):
        b = copy.deepcopy(base)
        f(b)
        r = check(pdir, data=b)
        rules = {v["rule"] for v in r["violations"]}
        return {"mutation": name, "expected": rule, "caught": rule in rules, "rules": sorted(rules)}

    def setxy(b, i, x, y, also_def=True):
        b[4][i]["x"], b[4][i]["y"] = x, y
        if also_def:
            dd = next(d for d in b[5] if d["inst"] == b[4][i]["inst"])
            dd["x"], dd["y"] = x, y

    def snapx(v):
        return core[0] + round((v - core[0]) / sw) * sw

    def snapy(v):
        return core[1] + round((v - core[1]) / rh) * rh

    out = [
        mut("overlap: macro 1 onto macro 0", "C6", lambda b: setxy(b, 1, t0["x"], t0["y"])),
        mut("channel: macro 1 abutting macro 0 (10 um gap)", "C6",
            lambda b: setxy(b, 1, snapx(t0["x"] + a0["width_um"] + 10.0), t0["y"])),
        mut("outside the core", "C5", lambda b: setxy(b, 0, snapx(core[2] - a0["width_um"] / 2), t0["y"])),
        mut("into a placement blockage", "C7",
            lambda b: setxy(b, 0, snapx(fp["blockages"][0]["rect"][0]), snapy(fp["blockages"][0]["rect"][1]))),
        mut("into a logic block", "C7",
            lambda b: setxy(b, 0, snapx(list(fp["blocks"].values())[0]["rect"][0] + 10),
                            snapy(list(fp["blocks"].values())[0]["rect"][1] + 10))),
        mut("off the site grid (+0.24 um)", "C4", lambda b: setxy(b, 0, t0["x"] + 0.24, t0["y"])),
        mut("off the manufacturing grid (+0.001 um)", "C4", lambda b: setxy(b, 0, t0["x"] + 0.001, t0["y"])),
        mut("orientation R90", "C3", lambda b: [b[4][0].__setitem__("orient", "R90")]),
        mut("orientation MY (LEF-legal, not allowed by the floorplan)", "C3", lambda b: [b[4][0].__setitem__("orient", "MY")]),
        mut("missing instance", "C1", lambda b: b[4].pop(0)),
        mut("duplicate instance", "C1", lambda b: b[4].append(copy.deepcopy(b[4][0]))),
        mut("unknown instance name", "C1", lambda b: b[4][0].__setitem__("inst", b[4][0]["inst"] + "_x")),
        mut("wrong master", "C2", lambda b: b[4][0].__setitem__("master", "RM_IHPSG13_1P_64x64_c2_bm_bist")),
        mut("Tcl / DEF mismatch", "C9", lambda b: setxy(b, 0, snapx(t0["x"] + 0.48 * 0), t0["y"] + 3.78 * 0, also_def=False)
            or b[5][0].__setitem__("x", b[5][0]["x"] + 0.48)),
    ]
    # pin escape: put a macro at the bottom core edge with its pins (R0: bottom edge) facing the boundary
    lowy = core[1] + fp["halo_um"]
    out.append(mut("pins facing the core edge", "C8",
                   lambda b: (setxy(b, 0, t0["x"], snapy(lowy + 0.0) if snapy(lowy) >= lowy else snapy(lowy) + rh),
                              b[4][0].__setitem__("orient", "R0"),
                              next(d for d in b[5] if d["inst"] == b[4][0]["inst"]).__setitem__("orient", "R0"))))
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pdir", type=Path)
    ap.add_argument("--mock-dump", type=Path)
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    a.pdir = a.pdir.resolve()
    if a.selftest:
        res = selftest(a.pdir)
        for r in res:
            print(f"[selftest] {'CAUGHT' if r['caught'] else 'MISSED'} {r['mutation']} -> {r['rules']}")
        print(json.dumps(res))
        return 0 if all(r["caught"] for r in res) else 1
    r = check(a.pdir, a.mock_dump)
    for v in r["violations"][:30]:
        print(f"[check] {v['rule']}: {v['msg']}")
    print(f"[check] {r['config']} {r['strategy']}: {r['macros']} macros, {len(r['violations'])} violations, "
          f"min spacing {r['min_spacing_um']} um -> {'OK' if r['ok'] else 'FAIL'}")
    (a.pdir / "check.json").write_text(json.dumps(r, indent=1) + "\n")
    return 0 if r["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
