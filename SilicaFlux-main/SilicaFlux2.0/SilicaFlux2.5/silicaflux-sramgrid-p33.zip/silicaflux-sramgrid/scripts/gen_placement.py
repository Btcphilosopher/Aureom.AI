#!/usr/bin/env python3
"""SilicaFlux-HPC Project 33 SRAMGRID -- configuration-driven SRAM macro placement.

  gen_placement.py <config.json> [--strategies a,b] [--out physical/placement]

Inputs
  * the memory configuration (regions, banks) -> derived macro mapping
  * the macro INSTANCE NAMES of the synthesized ASIC netlist
    (reports/synth/<cfg>_asic/macro_instances.json, from scripts/run_synth.py)
  * the REAL macro abstracts (physical/abstracts/*.json, parsed from the vendor
    LEF) and the IHP SG13G2 site / grid (physical/abstracts/tech_ihp_sg13g2.json)
  * the floorplan planning file named by the configuration (die, core margin,
    halo, channel, pin-escape depth, legal orientations, logic-block outlines,
    placement blockages, assumed traffic mix)

Strategies (anchor per region kind; greedy legal placement, best cost first)
  adjacent_vector : shared SRAM against the vector cluster; local regions against their cluster
  around_tensor   : shared SRAM and tensor regions in a ring around the tensor cluster
  central_shared  : shared SRAM packed around the core centre; local regions against their cluster
  perimeter       : every bank along the core edges, logic in the middle

Rules enforced while placing (and re-checked independently by check_placement.py)
  * inside the core with the halo; on the site / row grid (x on 0.48 um sites, y on 3.78 um rows)
  * >= channel_um between any two macros (routing channel), >= halo_um from blocks and blockages
  * orientation in (floorplan set) AND (LEF SYMMETRY); signal pins face the bank's target
  * a pin-escape strip (pin edge x pin_escape_um) inside the core and free of macros / blockages

Outputs per strategy: macro_place.tcl (OpenROAD / OpenDB), macro_place.def (DEF COMPONENTS +
BLOCKAGES), placement.json, placement.svg, wire.json (distance ESTIMATES, not extracted delay).
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import sg_config  # noqa: E402

KIND_ORDER = {"ten_acc": 0, "ten_operand": 1, "vec_local": 2, "shared": 3, "boot": 4}
STRATEGIES = {
    "adjacent_vector": {"shared": ("adjacent", "vector_0"), "*": ("adjacent", None)},
    "around_tensor": {"shared": ("ring", "tensor_0"), "ten_operand": ("ring", None), "ten_acc": ("ring", None),
                      "*": ("adjacent", None)},
    "central_shared": {"shared": ("center", None), "*": ("adjacent", None)},
    "perimeter": {"*": ("perimeter", None)},
}


def snap_up(v, g, o):
    return o + math.ceil(round((v - o) / g, 6)) * g


def snap_dn(v, g, o):
    return o + math.floor(round((v - o) / g, 6)) * g


def rect_dist(r, x, y):
    dx = max(r[0] - x, 0, x - r[2])
    dy = max(r[1] - y, 0, y - r[3])
    return dx + dy


def overlap(a, b):
    return a[0] < b[2] and b[0] < a[2] and a[1] < b[3] and b[1] < a[3]


def grow(r, d):
    return [r[0] - d, r[1] - d, r[2] + d, r[3] + d]


def parse_inst(name):
    b = int(re.search(r"g_bank\[(\d+)\]", name).group(1))
    r = re.search(r"g_r\[(\d+)\]", name)
    c = re.search(r"g_c\[(\d+)\]", name)
    return b, int(r.group(1)) if r else 0, int(c.group(1)) if c else 0


class Floorplan:
    def __init__(self, fp, tech):
        self.fp = fp
        self.site_w, self.row_h = tech["site"]["size"]
        self.grid = tech["mfg_grid_um"]
        self.dbu = tech["units_dbu"]
        W, H = fp["die_um"]
        m = fp["core_margin_um"]
        self.die = [0.0, 0.0, float(W), float(H)]
        x0 = snap_up(m, self.site_w, 0.0)
        y0 = snap_up(m, self.row_h, 0.0)
        x1 = snap_dn(W - m, self.site_w, x0)
        y1 = snap_dn(H - m, self.row_h, y0)
        self.core = [round(x0, 3), round(y0, 3), round(x1, 3), round(y1, 3)]
        self.halo = fp["halo_um"]
        self.chan = fp["channel_um"]
        self.pesc = fp["pin_escape_um"]
        self.blocks = {k: v["rect"] for k, v in fp["blocks"].items()}
        self.blockages = [b["rect"] for b in fp["blockages"]]

    def sx(self, v, up):
        return round((snap_up if up else snap_dn)(v, self.site_w, self.core[0]), 3)

    def sy(self, v, up):
        return round((snap_up if up else snap_dn)(v, self.row_h, self.core[1]), 3)


def pin_strip(bb, orient, pesc):
    # IHP / SKY130 / GF180 abstracts: signal pins on the bottom edge in R0 (checked in the abstract)
    if orient in ("R0", "MY"):
        return [bb[0], bb[1] - pesc, bb[2], bb[1]]
    return [bb[0], bb[3], bb[2], bb[3] + pesc]


def pin_point(bb, orient):
    return ((bb[0] + bb[2]) / 2, bb[1] if orient in ("R0", "MY") else bb[3])


def place(d, fp: Floorplan, abstracts, insts, strategy):
    st = STRATEGIES[strategy]
    regions = {r["name"]: r for r in d["regions"]}
    bank_region = {b["index"]: b["region"] for b in d["banks"]}
    macros = []
    for it in insts:
        b, rr, cc = parse_inst(it["inst"])
        a = abstracts[it["master"]]
        assert a["signal_pin_edge"] == "bottom", f"{it['master']}: pins not on the bottom edge"
        reg = regions[bank_region[b]]
        macros.append({"inst": it["inst"], "master": it["master"], "bank": b, "row": rr, "col": cc,
                       "region": reg["name"], "kind": reg["kind"], "near": reg.get("near"),
                       "w": a["width_um"], "h": a["height_um"], "lef_orients": a["legal_orientations_lef"]})
    macros.sort(key=lambda m: (KIND_ORDER[m["kind"]], m["region"], m["bank"], m["row"], m["col"]))
    allowed = [o for o in fp.fp["orientations"]]
    core = fp.core
    cc = ((core[0] + core[2]) / 2, (core[1] + core[3]) / 2)
    placed = []
    fails = []

    def anchor(m):
        mode, blk = st.get(m["kind"], st["*"])
        if blk is None:
            blk = m["near"] if m["near"] in fp.blocks else None
        return mode, blk

    for m in macros:
        mode, blk = anchor(m)
        brect = fp.blocks.get(blk) if blk else None
        w, h = m["w"], m["h"]
        xs = {core[0] + fp.halo, core[2] - fp.halo - w, (core[0] + core[2] - w) / 2}
        ys = {core[1] + fp.halo, core[3] - fp.halo - h, (core[1] + core[3] - h) / 2}
        for r in list(fp.blocks.values()) + fp.blockages:
            xs |= {r[0] - fp.halo - w, r[2] + fp.halo, (r[0] + r[2] - w) / 2}
            ys |= {r[1] - fp.halo - h - (fp.pesc if True else 0), r[1] - fp.halo - h, r[3] + fp.halo,
                   r[3] + fp.pesc, (r[1] + r[3] - h) / 2}
        for p in placed:
            b = p["bbox"]
            xs |= {b[0] - fp.chan - w, b[2] + fp.chan, b[0]}
            ys |= {b[1] - fp.chan - h, b[3] + fp.chan, b[1]}
        # plus a uniform grid over the core (abutment corners alone fragment the free space)
        step = max(20.0, ((core[2] - core[0]) + (core[3] - core[1])) / 240.0)
        gx = core[0] + fp.halo
        while gx + w <= core[2] - fp.halo:
            xs.add(gx)
            gx += step
        gy = core[1] + fp.halo
        while gy + h <= core[3] - fp.halo:
            ys.add(gy)
            gy += step
        same_bank = [p for p in placed if p["bank"] == m["bank"]]
        same_reg = [p for p in placed if p["region"] == m["region"]]
        cands = []
        for x in xs:
            for y in ys:
                for up in (True, False):
                    xx = fp.sx(x, up)
                    yy = fp.sy(y, up)
                    if xx < core[0] + fp.halo - 1e-6 or yy < core[1] + fp.halo - 1e-6:
                        continue
                    if xx + w > core[2] - fp.halo + 1e-6 or yy + h > core[3] - fp.halo + 1e-6:
                        continue
                    cx, cy = xx + w / 2, yy + h / 2
                    # pins face the target
                    if brect:
                        ty = (brect[1] + brect[3]) / 2
                    elif mode == "center":
                        ty = cc[1]
                    else:
                        ty = cc[1]
                    if mode == "perimeter":
                        orient = "MX" if cy < cc[1] else "R0"           # pins toward the core interior
                    else:
                        orient = "R0" if ty < cy else "MX"
                    if orient not in allowed or orient not in m["lef_orients"]:
                        continue
                    bb = [xx, yy, xx + w, yy + h]
                    pp = pin_point(bb, orient)
                    if mode == "adjacent":
                        cost = rect_dist(brect, *pp) if brect else math.dist((cx, cy), cc)
                    elif mode == "ring":
                        cost = math.dist((cx, cy), ((brect[0] + brect[2]) / 2, (brect[1] + brect[3]) / 2)) if brect \
                            else math.dist((cx, cy), cc)
                    elif mode == "center":
                        cost = math.dist((cx, cy), cc)
                    else:   # perimeter: hug a core edge, stay near the serving block
                        edge = min(bb[0] - core[0], core[2] - bb[2], bb[1] - core[1], core[3] - bb[3])
                        cost = 10.0 * edge + 0.2 * (rect_dist(brect, cx, cy) if brect else 0.0)
                    if same_bank:
                        gx = sum((p["bbox"][0] + p["bbox"][2]) / 2 for p in same_bank) / len(same_bank)
                        gy = sum((p["bbox"][1] + p["bbox"][3]) / 2 for p in same_bank) / len(same_bank)
                        cost += 1.5 * (abs(cx - gx) + abs(cy - gy))
                    elif same_reg:
                        gx = sum((p["bbox"][0] + p["bbox"][2]) / 2 for p in same_reg) / len(same_reg)
                        gy = sum((p["bbox"][1] + p["bbox"][3]) / 2 for p in same_reg) / len(same_reg)
                        cost += 0.15 * (abs(cx - gx) + abs(cy - gy))
                    cands.append((round(cost, 3), xx, yy, orient, bb))
        cands.sort(key=lambda c: (c[0], c[2], c[1]))
        chosen = None
        for cost, xx, yy, orient, bb in cands:
            if legal(bb, orient, placed, fp):
                chosen = (xx, yy, orient, bb, cost)
                break
        if chosen is None:
            fails.append(m["inst"])
            continue
        xx, yy, orient, bb, cost = chosen
        placed.append({**m, "x": xx, "y": yy, "orient": orient, "bbox": [round(v, 3) for v in bb],
                       "halo_bbox": [round(v, 3) for v in grow(bb, fp.halo)], "anchor": [mode, blk],
                       "pin_point": [round(v, 3) for v in pin_point(bb, orient)]})
    return placed, fails


def legal(bb, orient, placed, fp: Floorplan):
    core = fp.core
    hb = grow(bb, fp.halo)
    if hb[0] < core[0] - 1e-6 or hb[1] < core[1] - 1e-6 or hb[2] > core[2] + 1e-6 or hb[3] > core[3] + 1e-6:
        return False
    for r in list(fp.blocks.values()) + fp.blockages:
        if overlap(hb, r):
            return False
    for p in placed:
        if overlap(grow(bb, fp.chan - 1e-6), p["bbox"]):
            return False
    ps = pin_strip(bb, orient, fp.pesc)
    if ps[1] < core[1] - 1e-6 or ps[3] > core[3] + 1e-6:
        return False
    for p in placed:
        if overlap(ps, p["bbox"]):
            return False
    for r in fp.blockages:
        if overlap(ps, r):
            return False
    return True


# ------------------------------------------------------------------ outputs
def tcl(d, fp, placed, strategy, cfgname):
    L = [f"# GENERATED by scripts/gen_placement.py -- configuration {d['name']}, strategy {strategy}",
         "# Macro dimensions / pins / symmetry: REAL (vendor LEF, physical/abstracts).",
         "# Die, core and logic-block outlines: PLANNING ASSUMPTIONS (config/floorplan).",
         "# Instance names: the synthesized ASIC netlist (reports/synth/<cfg>_asic/macro_instances.json).",
         "# Coordinates: lower-left corner of the ORIENTED macro bounding box, microns (DEF COMPONENTS convention).",
         "# Usage (OpenROAD, after link_design + initialize_floorplan): source macro_place.tcl",
         "set sg_block [ord::get_db_block]",
         "set sg_dbu   [[ord::get_db_tech] getDbUnitsPerMicron]",
         "proc sg_place {name master x y orient} {",
         "  global sg_block sg_dbu",
         "  set inst [$sg_block findInst $name]",
         "  if {$inst eq \"NULL\" || $inst eq \"\"} { error \"sg_place: instance $name not in the netlist\" }",
         "  set m [[$inst getMaster] getName]",
         "  if {$m ne $master} { error \"sg_place: $name is a $m, expected $master\" }",
         "  $inst setOrient $orient",
         "  $inst setLocation [expr {round($x * $sg_dbu)}] [expr {round($y * $sg_dbu)}]",
         "  $inst setPlacementStatus FIRM",
         "}",
         "proc sg_blockage {x0 y0 x1 y1} {",
         "  global sg_block sg_dbu",
         "  odb::dbBlockage_create $sg_block [expr {round($x0*$sg_dbu)}] [expr {round($y0*$sg_dbu)}] "
         "[expr {round($x1*$sg_dbu)}] [expr {round($y1*$sg_dbu)}]",
         "}",
         f"# core {fp.core}  halo {fp.halo}  channel {fp.chan}  pin-escape {fp.pesc}"]
    for p in placed:
        L.append(f"sg_place {{{p['inst']}}} {p['master']} {p['x']:.3f} {p['y']:.3f} {p['orient']}")
    L.append("# macro halos (no standard cells) and floorplan placement blockages")
    for p in placed:
        h = p["halo_bbox"]
        L.append(f"sg_blockage {h[0]:.3f} {h[1]:.3f} {h[2]:.3f} {h[3]:.3f}")
    for b in fp.fp["blockages"]:
        r = b["rect"]
        L.append(f"sg_blockage {r[0]:.3f} {r[1]:.3f} {r[2]:.3f} {r[3]:.3f}  ;# {b['name']}")
    return "\n".join(L) + "\n"


DEF_ORIENT = {"R0": "N", "MX": "FS", "MY": "FN", "R180": "S"}


def defout(d, fp, placed, strategy):
    u = fp.dbu
    q = lambda v: int(round(v * u))  # noqa: E731
    L = ["VERSION 5.8 ;", 'DIVIDERCHAR "/" ;', 'BUSBITCHARS "[]" ;', "DESIGN sg_top ;", f"UNITS DISTANCE MICRONS {u} ;",
         f"DIEAREA ( {q(fp.die[0])} {q(fp.die[1])} ) ( {q(fp.die[2])} {q(fp.die[3])} ) ;",
         f"# strategy {strategy}; core {fp.core}; macro halos as COMPONENT HALO", f"COMPONENTS {len(placed)} ;"]
    for p in placed:
        L.append(f"  - {p['inst'].replace('/', '_')} {p['master']} + FIXED ( {q(p['x'])} {q(p['y'])} ) "
                 f"{DEF_ORIENT[p['orient']]} + HALO {q(fp.halo)} {q(fp.halo)} {q(fp.halo)} {q(fp.halo)} ;")
    L.append("END COMPONENTS")
    L.append(f"BLOCKAGES {len(fp.fp['blockages'])} ;")
    for b in fp.fp["blockages"]:
        r = b["rect"]
        L.append(f"  - PLACEMENT RECT ( {q(r[0])} {q(r[1])} ) ( {q(r[2])} {q(r[3])} ) ;")
    L.append("END BLOCKAGES")
    L.append("END DESIGN")
    return "\n".join(L) + "\n"


PALETTE = {"shared": "#4C78A8", "vec_local": "#59A14F", "ten_operand": "#E15759", "ten_acc": "#B07AA1", "boot": "#F28E2B"}


def svg(d, fp, placed, strategy, wire):
    W, H = fp.die[2], fp.die[3]
    s = 700.0 / max(W, H)
    Y = lambda y: (H - y) * s  # noqa: E731
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W*s+20:.0f}" height="{H*s+60:.0f}" font-family="sans-serif" font-size="10">',
         f'<rect x="0" y="0" width="{W*s:.1f}" height="{H*s:.1f}" fill="#fafafa" stroke="#333"/>']
    c = fp.core
    o.append(f'<rect x="{c[0]*s:.1f}" y="{Y(c[3]):.1f}" width="{(c[2]-c[0])*s:.1f}" height="{(c[3]-c[1])*s:.1f}" fill="none" stroke="#999" stroke-dasharray="4 3"/>')
    for k, r in fp.blocks.items():
        o.append(f'<rect x="{r[0]*s:.1f}" y="{Y(r[3]):.1f}" width="{(r[2]-r[0])*s:.1f}" height="{(r[3]-r[1])*s:.1f}" fill="#eeeeee" stroke="#666" stroke-dasharray="3 2"/>')
        o.append(f'<text x="{(r[0]+r[2])/2*s:.1f}" y="{Y((r[1]+r[3])/2):.1f}" text-anchor="middle" fill="#444">{k} (assumed)</text>')
    for b in fp.fp["blockages"]:
        r = b["rect"]
        o.append(f'<rect x="{r[0]*s:.1f}" y="{Y(r[3]):.1f}" width="{(r[2]-r[0])*s:.1f}" height="{(r[3]-r[1])*s:.1f}" fill="#f4cccc" stroke="#c00"/>')
    for p in placed:
        h = p["halo_bbox"]
        o.append(f'<rect x="{h[0]*s:.1f}" y="{Y(h[3]):.1f}" width="{(h[2]-h[0])*s:.1f}" height="{(h[3]-h[1])*s:.1f}" fill="none" stroke="#bbb" stroke-width="0.5"/>')
        b = p["bbox"]
        o.append(f'<rect x="{b[0]*s:.1f}" y="{Y(b[3]):.1f}" width="{(b[2]-b[0])*s:.1f}" height="{(b[3]-b[1])*s:.1f}" fill="{PALETTE[p["kind"]]}" fill-opacity="0.75" stroke="#222" stroke-width="0.6"/>')
        py = b[1] if p["orient"] == "R0" else b[3]
        o.append(f'<line x1="{b[0]*s:.1f}" y1="{Y(py):.1f}" x2="{b[2]*s:.1f}" y2="{Y(py):.1f}" stroke="#000" stroke-width="2"/>')
        if p["col"] == 0:
            o.append(f'<text x="{(b[0]+3)*s:.1f}" y="{Y(b[3])+10:.1f}" fill="#fff">b{p["bank"]}</text>')
    o.append(f'<text x="5" y="{H*s+15:.0f}">{d["name"]} / {strategy}: {len(placed)} macros (REAL LEF sizes), '
             f'weighted pin distance {wire["weighted_mean_mm"]:.2f} mm (estimate). Thick edge = signal pins.</text>')
    o.append(f'<text x="5" y="{H*s+30:.0f}">grey dashed = assumed logic blocks; red = placement blockages; '
             f'colours: shared / vec_local / ten_operand / ten_acc / boot</text>')
    o.append("</svg>")
    return "\n".join(o) + "\n"


def wire_estimates(d, fp, placed):
    """Manhattan distance from each port's cluster-block centre to each bank's pin centroid.
    An ESTIMATE of wire span: no routing, no extraction, no timing."""
    tr = fp.fp.get("traffic", {})
    reach_mm = fp.fp.get("wire_mm_per_cycle")
    banks = {}
    for p in placed:
        banks.setdefault(p["bank"], []).append(p["pin_point"])
    bpin = {b: (sum(x for x, _ in v) / len(v), sum(y for _, y in v) / len(v)) for b, v in banks.items()}
    port_rows, total_w, wsum, links_mm_bits = [], 0.0, 0.0, 0.0
    busw = 2 * d["data_width"] + d["addr_width"] + 16       # wdata + rdata + address + control (approximate)
    region_max = {}
    for p in d["ports"]:
        blk = fp.blocks.get(p.get("cluster") or "", None)
        src = ((blk[0] + blk[2]) / 2, (blk[1] + blk[3]) / 2) if blk else ((fp.core[0] + fp.core[2]) / 2,) * 2
        row = {"port": p["name"], "cluster": p.get("cluster"), "regions": {}}
        for rn in p["regions"]:
            r = next(x for x in d["regions"] if x["name"] == rn)
            ds = []
            for b in range(r["first_bank"], r["first_bank"] + r["banks"]):
                if b in bpin:
                    dist = (abs(bpin[b][0] - src[0]) + abs(bpin[b][1] - src[1])) / 1000.0
                    ds.append(dist)
                    links_mm_bits += dist * busw
            if not ds:
                continue
            mean = sum(ds) / len(ds)
            row["regions"][rn] = {"mean_mm": round(mean, 3), "max_mm": round(max(ds), 3)}
            region_max[rn] = max(region_max.get(rn, 0.0), max(ds))
            wgt = tr.get(p["name"], {}).get(rn, 1.0 / len(p["regions"]))
            wsum += wgt * mean
            total_w += wgt
        port_rows.append(row)
    rec = {}
    for rn, mx in region_max.items():
        r = next(x for x in d["regions"] if x["name"] == rn)
        need = max(0, math.ceil(mx / reach_mm) - 1) if reach_mm else None
        rec[rn] = {"max_mm": round(mx, 3), "configured_req_pipe": r["req_pipe"], "suggested_req_pipe": need,
                   "ok": (need is None) or r["req_pipe"] >= need}
    return {"kind": "ESTIMATE: Manhattan cluster-centre to bank-pin-centroid distance; no routing, no RC extraction, no STA",
            "bus_bits_assumed": busw, "wire_mm_per_cycle_assumed": reach_mm,
            "weighted_mean_mm": round(wsum / total_w, 3) if total_w else None,
            "sparse_crossbar_mm_bits": round(links_mm_bits, 1), "ports": port_rows, "regions": rec}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("config", type=Path)
    ap.add_argument("--strategies", default="")
    ap.add_argument("--out", type=Path, default=ROOT / "physical/placement")
    a = ap.parse_args()
    cfg = json.loads(a.config.read_text())
    d = sg_config.derive(cfg)
    fpj = json.loads((ROOT / cfg["floorplan"]).read_text())
    tech = json.loads((ROOT / "physical/abstracts/tech_ihp_sg13g2.json").read_text())
    if fpj["technology"] != d["technology"]:
        print(f"[place] floorplan technology {fpj['technology']} != configuration {d['technology']}", file=sys.stderr)
        return 2
    abstracts = sg_config.load_abstracts()
    ij = ROOT / f"reports/synth/{d['name']}_asic/macro_instances.json"
    if not ij.exists():
        print(f"[place] {ij} missing: run scripts/run_synth.py {d['name']}:asic first", file=sys.stderr)
        return 2
    insts = json.loads(ij.read_text())
    fp = Floorplan(fpj, tech)
    strategies = [s for s in (a.strategies.split(",") if a.strategies else fpj["strategies"])]
    summary = []
    rc = 0
    for s in strategies:
        placed, fails = place(d, fp, abstracts, insts, s)
        o = a.out / d["name"] / s
        o.mkdir(parents=True, exist_ok=True)
        w = wire_estimates(d, fp, placed)
        meta = {"config": d["name"], "strategy": s, "floorplan": fpj["name"], "die": fp.die, "core": fp.core,
                "site": [fp.site_w, fp.row_h], "mfg_grid": fp.grid, "dbu": fp.dbu, "halo": fp.halo, "channel": fp.chan,
                "pin_escape": fp.pesc, "orientations": fpj["orientations"], "blocks": fp.blocks,
                "blockages": fpj["blockages"], "status": fpj["status"], "unplaced": fails, "macros": placed}
        (o / "placement.json").write_text(json.dumps(meta, indent=1) + "\n")
        (o / "macro_place.tcl").write_text(tcl(d, fp, placed, s, d["name"]))
        (o / "macro_place.def").write_text(defout(d, fp, placed, s))
        (o / "wire.json").write_text(json.dumps(w, indent=1) + "\n")
        (o / "placement.svg").write_text(svg(d, fp, placed, s, w))
        mac_area = sum(p["w"] * p["h"] for p in placed)
        core_area = (fp.core[2] - fp.core[0]) * (fp.core[3] - fp.core[1])
        summary.append({"strategy": s, "placed": len(placed), "unplaced": len(fails),
                        "macro_area_mm2": round(mac_area / 1e6, 4), "core_mm2": round(core_area / 1e6, 4),
                        "macro_fraction": round(mac_area / core_area, 4), "weighted_mean_mm": w["weighted_mean_mm"],
                        "sparse_crossbar_mm_bits": w["sparse_crossbar_mm_bits"],
                        "pipe_ok": all(v["ok"] for v in w["regions"].values()),
                        "suggested_req_pipe": {k: v["suggested_req_pipe"] for k, v in w["regions"].items()}})
        print(f"[place] {d['name']} {s}: {len(placed)} placed, {len(fails)} unplaced, weighted distance "
              f"{w['weighted_mean_mm']} mm (estimate)")
        if fails:
            rc = 1
    (a.out / d["name"] / "summary.json").write_text(json.dumps(summary, indent=1) + "\n")
    return rc


if __name__ == "__main__":
    sys.exit(main())
