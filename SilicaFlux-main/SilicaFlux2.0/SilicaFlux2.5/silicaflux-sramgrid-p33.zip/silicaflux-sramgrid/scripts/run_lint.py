#!/usr/bin/env python3
"""SilicaFlux-HPC Project 33 SRAMGRID -- lint, elaboration and illegal-configuration rejection.

  legal   : every configuration (config/*.json, config/regress/*.json, plus the asic / fpga flows of
            sg_min4 and sg_hier) through Verilator --lint-only -Wall (with and without SG_ASSERT;
            warnings in rtl/ counted, third_party waived by rtl/lint.vlt), Icarus (compile + elaborate
            run) and Yosys (hierarchy + proc + check).
  illegal : parameter sets that bypass scripts/sg_config.py must be REFUSED at elaboration by all
            three tools (the RTL's own checks); illegal JSON configurations must be refused by
            scripts/sg_config.py.
Writes reports/lint.{json,md}.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import sg_config  # noqa: E402

B = ROOT / "build/lint"
INC = ["-Irtl", "-Ithird_party/silicaflux-sramlib/rtl/mem", "-Ithird_party/silicaflux-sramlib/rtl/mem/backends/asic",
       "-Ithird_party/silicaflux-ras/rtl"]


def files(stubs=True):
    fs = [l.strip() for l in (ROOT / "rtl/files.f").read_text().splitlines() if l.strip() and not l.startswith("+")]
    return [f for f in fs if stubs or "blackboxes" not in f]


def run(cmd, timeout=1800):
    p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout + p.stderr


def lint_legal(name):
    inc = INC + [f"-Igen/{name}"]
    rec = {"config": name}
    for tag, extra in (("verilator", []), ("verilator_assert", ["-DSG_ASSERT"])):
        rc, out = run(["verilator", "--lint-only", "-Wall", "--timescale", "1ns/1ps"] + extra + inc +
                      ["rtl/lint.vlt"] + files() + [f"gen/{name}/sg_top.sv", "--top-module", "sg_top"])
        warn = [l for l in out.splitlines() if l.startswith("%Warning") or l.startswith("%Error")]
        rec[tag] = {"rc": rc, "messages": len(warn), "first": warn[:3]}
    B.mkdir(parents=True, exist_ok=True)
    rc, out = run(["iverilog", "-g2012", "-DSYNTHESIS"] + inc + files() + [f"gen/{name}/sg_top.sv", "-s", "sg_top",
                                                                          "-o", str(B / f"{name}.vvp")])
    rc2, out2 = run(["vvp", "-n", str(B / f"{name}.vvp")]) if rc == 0 else (rc, "")
    rec["icarus"] = {"rc": rc, "run_rc": rc2, "fatal": "FATAL" in out2.upper()}
    ys = (f"read_verilog -defer -sv -DSYNTHESIS {' '.join(INC)} -Igen/{name} "
          f"{' '.join(files())} gen/{name}/sg_top.sv; hierarchy -top sg_top; proc; check -assert")
    rc, out = run(["yosys", "-q", "-p", ys], timeout=3600)
    rec["yosys"] = {"rc": rc, "err": out[-300:] if rc else ""}
    rec["ok"] = (rec["verilator"]["rc"] == 0 and rec["verilator"]["messages"] == 0 and
                 rec["verilator_assert"]["rc"] == 0 and rec["verilator_assert"]["messages"] == 0 and
                 rec["icarus"]["rc"] == 0 and rec["icarus"]["run_rc"] == 0 and not rec["icarus"]["fatal"] and
                 rec["yosys"]["rc"] == 0)
    return rec


# ------------------------------------------------------------------ illegal parameter sets (RTL checks)
BASE = dict(NP=3, NR=1, AW=32, DW=64, TAG_W=8, ECC_G=64, NSLOT=4, ARB=0, RDW=0,
            R_BASE="64'h20000000", R_LOG2B="8'd15", R_NB="8'd4", R_PM="8'd0", R_MAP="8'd0", R_ECC="8'd2",
            R_BWE="8'd0", R_PIPE="8'd0", R_OREG="8'd0", R_IMPL="8'd0", R_MACRO="16'd0", R_WP="8'd0",
            P_REACH="3'b111", P_SLICE="24'h010101", NBT=4, RWX=10, TSW=72, TEST_LAT=1)
ILLEGAL = [
    ("regions overlap", dict(NR=2, R_BASE="128'h00000000_20000000_00000000_20004000", R_LOG2B="16'h0f0f",
                             R_NB="16'h0404", R_PM="16'h0", R_MAP="16'h0", R_ECC="16'h0202", R_BWE="16'h0",
                             R_PIPE="16'h0", R_OREG="16'h0", R_IMPL="16'h0", R_MACRO="32'h0", R_WP="16'h0",
                             P_REACH="6'b111111", NBT=8), "g_err_regions_overlap"),
    ("base not aligned to the region size", dict(R_BASE="64'h20001000"), "g_err_region_field_out_of_range"),
    ("3 banks", dict(R_NB="8'd3", NBT=3), "g_err_region_field_out_of_range"),
    ("region smaller than 2 rows per bank", dict(R_LOG2B="8'd5"), "g_err_region_field_out_of_range"),
    ("XOR map with fewer row than bank bits", dict(R_LOG2B="8'd9", R_NB="8'd16", R_MAP="8'd1", NBT=16, RWX=2),
     "g_err_xor_map_needs_rows_ge_banks"),
    ("SECDED region with byte writes", dict(R_BWE="8'd1"), "g_err_secded_region_has_byte_we"),
    ("ASIC implementation without a macro", dict(R_IMPL="8'd2"), "g_err_asic_region_without_macro"),
    ("ASIC 2RW on a single-port IHP macro", dict(R_IMPL="8'd2", R_MACRO="16'd21", R_PM="8'd2"), "g_err_macro_cannot_do_2rw"),
    ("ASIC commercial placeholder macro (no licensed output)", dict(R_IMPL="8'd2", R_MACRO="16'd92"),
     "g_err_macro_pending_no_licensed_compiler_output"),
    ("ASIC macro id not in the catalogue", dict(R_IMPL="8'd2", R_MACRO="16'd77"), "g_err_macro_not_in_catalogue"),
    ("ASIC 9-bit parity lanes on byte-mask SKY130 macro", dict(R_IMPL="8'd2", R_MACRO="16'd1", R_ECC="8'd1", R_BWE="8'd1"),
     "g_err_lane_not_multiple_of_macro_mask_granularity"),
    ("reorder slots not a power of two", dict(NSLOT=3), "g_err_nslot_pow2_2_to_16"),
    ("bank width 48", dict(DW=48), "g_err_dw_pow2_32_to_512"),
    ("ECC granule 16", dict(ECC_G=16), "g_err_ecc_g_32_or_64"),
    ("NBT inconsistent with R_NB", dict(NBT=5), "g_err_nbt_inconsistent"),
    ("TEST_LAT inconsistent", dict(TEST_LAT=3), "g_err_test_lat_inconsistent"),
    ("port slice 2", dict(P_SLICE="24'h010201"), "g_err_p_slice_0_or_1"),
    ("unknown read-during-write policy", dict(RDW=2), "g_err_unknown_rdw"),
]


def neg_top(params):
    pl = ", ".join(f".{k}({v})" for k, v in params.items())
    return (f"module neg_top;\n  logic clk = 1'b0;\n  silicaflux_sram_grid #({pl}) u_grid (\n"
            "    .clk(clk), .rst_n(1'b0), .req_valid('0), .req_ready(), .req_we('0), .req_addr('0), .req_wdata('0),\n"
            "    .req_wstrb('0), .req_tag('0), .rsp_valid(), .rsp_ready('0), .rsp_rdata(), .rsp_err(), .rsp_err_code(),\n"
            "    .rsp_we(), .rsp_ce(), .rsp_tag(), .wp_lock(1'b0), .init_req(1'b0), .init_busy(), .init_done(),\n"
            "    .tst_active(1'b0), .tst_sel('0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata(),\n"
            "    .ras_ev_valid(), .ras_ev_ce(), .ras_ev_ue(), .ras_ev_poison(), .ras_ev_org(), .ras_ev_addr(), .ras_ev_syn(),\n"
            "    .ras_ev_idx(), .ras_ev_lost(), .ev_accept(), .ev_issue(), .ev_conflict(), .ev_credit_stall(), .ev_block_stall(),\n"
            "    .ev_error(), .ev_complete(), .ev_bank_ops(), .ev_bank_conflict(), .ev_rdw_split(), .perf_clear(1'b0),\n"
            "    .perf_cycles(), .perf_issue(), .perf_conflict(), .perf_credit_stall(), .perf_complete(), .perf_bank_ops(),\n"
            "    .perf_bank_conflict(), .perf_ecc_ce(), .perf_ecc_ue(), .busy());\nendmodule\n")


def lint_illegal(i, desc, mod, expect):
    p = dict(BASE)
    p.update(mod)
    f = B / f"neg_{i}.sv"
    f.write_text(neg_top(p))
    rec = {"case": desc, "expect": expect}
    rc, out = run(["verilator", "--lint-only", "-Wno-fatal", "-Wno-lint", "-Wno-style", "--timescale", "1ns/1ps"] + INC +
                  ["rtl/lint.vlt"] + files() + [str(f), "--top-module", "neg_top"])
    # Verilator reports an elaboration-time $fatal as %Warning-USERFATAL (non-fatal under -Wno-fatal): that IS the refusal
    msg = next((l for l in out.splitlines() if "USERFATAL" in l), "")
    rec["verilator"] = {"refused": rc != 0 or bool(msg), "message": msg[-160:]}
    rc, out = run(["iverilog", "-g2012", "-DSYNTHESIS"] + INC + files() + [str(f), "-s", "neg_top", "-o", str(B / f"neg_{i}.vvp")])
    rc2, out2 = run(["vvp", "-n", str(B / f"neg_{i}.vvp")]) if rc == 0 else (rc, out)
    rec["icarus"] = {"refused": rc != 0 or rc2 != 0 or "FATAL" in out2.upper(), "named": expect in out2 or "FATAL" in out2.upper()}
    ys = (f"read_verilog -defer -sv -DSYNTHESIS {' '.join(INC)} {' '.join(files())} {f}; hierarchy -top neg_top; proc")
    rc, out = run(["yosys", "-q", "-p", ys])
    rec["yosys"] = {"refused": rc != 0, "line": next((l for l in out.splitlines() if "ERROR" in l), "")[:160]}
    rec["ok"] = rec["verilator"]["refused"] and rec["icarus"]["refused"] and rec["yosys"]["refused"]
    return rec


# ------------------------------------------------------------------ illegal JSON configurations (generator checks)
def json_illegal():
    base = json.loads((ROOT / "config/sg_hier.json").read_text())
    cases = []

    def c(desc, f):
        j = json.loads(json.dumps(base))
        f(j)
        try:
            sg_config.derive(j)
            cases.append({"case": desc, "refused": False, "message": ""})
        except sg_config.ConfigError as e:
            cases.append({"case": desc, "refused": True, "message": str(e).splitlines()[0][:200]})

    c("regions overlap", lambda j: j["regions"][3].__setitem__("base", "0x3000_0000"))
    c("base not size-aligned", lambda j: j["regions"][2].__setitem__("base", "0x3000_1000"))
    c("3 banks (schema)", lambda j: j["regions"][2].__setitem__("banks", 3))
    c("size not a power of two (schema pattern ok, value not)", lambda j: j["regions"][2].__setitem__("size", "48KiB"))
    c("region too small for its banks", lambda j: j["regions"][2].update({"size": "64B", "banks": 16}))
    c("xor map with too few rows", lambda j: j["regions"][4].update({"size": "512B", "banks": 16, "map": "xor"}))
    c("SECDED with byte writes", lambda j: j["regions"][1].__setitem__("byte_write", True))
    c("port references an unknown region", lambda j: j["ports"][0]["regions"].append("nowhere"))
    c("region wired to no port", lambda j: [p["regions"].remove("ten_acc") for p in j["ports"] if "ten_acc" in p["regions"]])
    c("window beyond the address space", lambda j: j["grid"].__setitem__("addr_width", 28))
    c("dual-port regions on GF180 (no dual-port macro)", lambda j: j["implementation"].__setitem__("technology", "gf180"))
    c("parity (9-bit lanes) on SKY130 byte-mask macros", lambda j: j["implementation"].__setitem__("technology", "sky130"))
    c("explicit macro of the wrong topology", lambda j: j["regions"][5].__setitem__("macro", "RM_IHPSG13_1P_512x32_c2_bm_bist"))
    c("unknown field (schema)", lambda j: j["regions"][0].__setitem__("colour", "red"))
    c("duplicate region names", lambda j: j["regions"][3].__setitem__("name", "vec0_spm"))
    return cases


def main() -> int:
    B.mkdir(parents=True, exist_ok=True)
    illegal_only = "--illegal-only" in sys.argv
    names = []
    for f in sorted((ROOT / "config").glob("*.json")) + sorted((ROOT / "config/regress").glob("*.json")):
        d = sg_config.derive(json.loads(f.read_text()))
        sg_config.emit(d, ROOT / "gen")
        names.append(d["name"])
        if f.parent.name == "config":
            for flow in ("asic", "fpga"):
                j = json.loads(f.read_text())
                j["implementation"]["flow"] = flow
                j["name"] = f"{j['name']}_{flow}"
                sg_config.emit(sg_config.derive(j), ROOT / "gen")
                names.append(j["name"])
    legal = []
    if illegal_only:
        legal = json.loads((ROOT / "reports/lint.json").read_text())["legal"]
        names = []
    for n in names:
        r = lint_legal(n)
        legal.append(r)
        print(f"[lint] {'OK  ' if r['ok'] else 'FAIL'} {n}: verilator {r['verilator']['messages']} / "
              f"{r['verilator_assert']['messages']} msgs, icarus rc {r['icarus']['rc']}/{r['icarus']['run_rc']}, "
              f"yosys rc {r['yosys']['rc']} {r['verilator']['first'][:1]}", flush=True)
    illegal = []
    for i, (desc, mod, exp) in enumerate(ILLEGAL):
        r = lint_illegal(i, desc, mod, exp)
        illegal.append(r)
        print(f"[lint] {'REFUSED' if r['ok'] else 'ACCEPTED!'} {desc}: verilator {r['verilator']['refused']} "
              f"icarus {r['icarus']['refused']} yosys {r['yosys']['refused']}", flush=True)
    js = json_illegal()
    for r in js:
        print(f"[lint] json {'REFUSED' if r['refused'] else 'ACCEPTED!'} {r['case']}: {r['message'][:90]}")
    out = {"legal": legal, "illegal_rtl": illegal, "illegal_json": js,
           "summary": {"legal_ok": sum(r["ok"] for r in legal), "legal": len(legal),
                       "illegal_refused": sum(r["ok"] for r in illegal), "illegal": len(illegal),
                       "json_refused": sum(r["refused"] for r in js), "json": len(js)}}
    (ROOT / "reports/lint.json").write_text(json.dumps(out, indent=1) + "\n")
    s = out["summary"]
    print(f"[lint] legal {s['legal_ok']}/{s['legal']}, illegal RTL refused {s['illegal_refused']}/{s['illegal']}, "
          f"illegal JSON refused {s['json_refused']}/{s['json']}")
    return 0 if (s["legal_ok"] == s["legal"] and s["illegal_refused"] == s["illegal"] and s["json_refused"] == s["json"]) else 1


if __name__ == "__main__":
    sys.exit(main())
