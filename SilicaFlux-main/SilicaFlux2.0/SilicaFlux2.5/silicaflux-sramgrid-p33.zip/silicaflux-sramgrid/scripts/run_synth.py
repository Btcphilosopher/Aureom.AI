#!/usr/bin/env python3
"""SilicaFlux-HPC Project 33 SRAMGRID -- Yosys synthesis runs.

  generic : flow generic, technology-independent synthesis; bank arrays stay
            inferred memories ($mem_v2) - the synthesis-memory inference flow
  asic    : flow asic, the SRAM Wrapper Library's pin-only macro black boxes;
            the netlist must contain EXACTLY the macro instances derived from
            the configuration and no inferred bank array (reorder-buffer
            register files are mapped to flip-flops); writes the netlist the
            placement and connectivity scripts read
  fpga    : flow fpga, synth_xilinx (7-series): block-RAM inference count

Results: reports/synth.json, reports/synth.md, reports/synth/<target>/.
"""
from __future__ import annotations

import gzip
import json
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import sg_config  # noqa: E402

OUT = ROOT / "reports/synth"
INC = ["rtl", "third_party/silicaflux-sramlib/rtl/mem", "third_party/silicaflux-sramlib/rtl/mem/backends/asic",
       "third_party/silicaflux-ras/rtl"]
STUBS = "third_party/silicaflux-sramlib/rtl/mem/backends/asic/stubs/sram_macro_blackboxes.sv"


def files():
    fs = [l.strip() for l in (ROOT / "rtl/files.f").read_text().splitlines() if l.strip() and not l.startswith("+")]
    return [f for f in fs if "blackboxes" not in f and "mbist_march" not in f]


def read_cmd(cfgname, asic):
    inc = " ".join(f"-I{i}" for i in INC + [f"gen/{cfgname}"])
    fl = (" " + STUBS if asic else "") + " " + " ".join(files()) + f" gen/{cfgname}/sg_top.sv"
    return f"read_verilog -defer -sv -DSYNTHESIS {inc}{fl}"


def run_yosys(script: str, log: Path, timeout=7200):
    t0 = time.time()
    p = subprocess.run(["yosys", "-q", "-l", str(log), "-p", script], cwd=ROOT, capture_output=True, text=True,
                       timeout=timeout)
    return p.returncode, time.time() - t0, p.stderr[-2000:]


def parse_stat(log: Path) -> dict:
    txt = log.read_text(errors="replace")
    blocks = txt.split("Printing statistics.")
    last = blocks[-1] if len(blocks) > 1 else txt
    cells = {}
    m = re.search(r"Number of cells:\s+(\d+)", last)
    for mm in re.finditer(r"^\s+(\S+)\s+(\d+)$", last, re.M):
        cells[mm.group(1)] = int(mm.group(2))
    return {"cells": int(m.group(1)) if m else None, "by_type": cells}


def mem_list(js: dict) -> list:
    out = []
    for mname, mod in js["modules"].items():
        for cname, c in mod.get("cells", {}).items():
            if c["type"].startswith("$mem"):
                p = c["parameters"]
                out.append({"cell": cname, "width": int(p["WIDTH"], 2) if isinstance(p["WIDTH"], str) else p["WIDTH"],
                            "size": int(p["SIZE"], 2) if isinstance(p["SIZE"], str) else p["SIZE"]})
    return out


def macro_insts(js: dict, masters: set) -> list:
    out = []
    for mname, mod in js["modules"].items():
        for cname, c in mod.get("cells", {}).items():
            if c["type"] in masters:
                out.append({"inst": cname, "master": c["type"], "module": mname})
    return out


def job_generic(name):
    d = sg_config.derive(json.loads((ROOT / f"config/{name}.json").read_text()))
    sg_config.emit(d, ROOT / "gen")
    o = OUT / f"{name}_generic"
    o.mkdir(parents=True, exist_ok=True)
    script = (f"{read_cmd(name, False)}; hierarchy -top sg_top; proc; flatten; opt_expr; opt_clean; check -assert; "
              f"opt -nodffe -nosdff; fsm; opt; wreduce; peepopt; opt_clean; alumacc; share; opt; memory -nomap; opt_clean; "
              f"tee -o {o}/mem_stat.txt stat; write_json {o}/coarse.json; "
              f"opt -fast -full; techmap; opt -fast; abc -fast; opt -fast; check -assert; tee -o {o}/stat.txt stat")
    rc, t, err = run_yosys(script, o / "yosys.log")
    rec = {"target": f"{name}_generic", "flow": "generic", "rc": rc, "seconds": round(t, 1), "stderr": err if rc else ""}
    if rc == 0:
        js = json.loads((o / "coarse.json").read_text())
        mems = mem_list(js)
        bank = [m for m in mems if ".u_mw." in m["cell"]]
        rec.update(parse_stat(o / "stat.txt"))
        rec["memories"] = len(mems)
        rec["bank_memories"] = len(bank)
        rec["bank_memory_bits"] = sum(m["width"] * m["size"] for m in bank)
        rec["other_memories"] = [m for m in mems if ".u_mw." not in m["cell"]][:8]
        rec["expected_bank_memories"] = d["NBT"]
        rec["expected_bank_bits"] = sum(b["stored_width"] * b["depth"] for b in d["banks"])
        rec["ok"] = rec["bank_memories"] == d["NBT"] and rec["bank_memory_bits"] == rec["expected_bank_bits"]
        (o / "coarse.json").unlink()
    return rec


def job_asic(name):
    cfg = json.loads((ROOT / f"config/{name}.json").read_text())
    cfg["implementation"]["flow"] = "asic"
    cfg["name"] = f"{name}_asic"
    d = sg_config.derive(cfg)
    sg_config.emit(d, ROOT / "gen")
    o = OUT / f"{name}_asic"
    o.mkdir(parents=True, exist_ok=True)
    script = (f"{read_cmd(d['name'], True)}; hierarchy -top sg_top; proc; flatten; opt_expr; opt_clean; check -assert; "
              f"opt; memory -nomap; tee -o {o}/mem_stat.txt stat; memory_map; opt; techmap; opt -fast; abc -fast; "
              f"opt -fast; opt_clean -purge; check -assert; tee -o {o}/stat.txt stat; "
              f"write_json {o}/netlist.json; write_verilog -noattr {o}/netlist.v")
    rc, t, err = run_yosys(script, o / "yosys.log")
    rec = {"target": f"{name}_asic", "flow": "asic", "rc": rc, "seconds": round(t, 1), "stderr": err if rc else ""}
    if rc == 0:
        js = json.loads((o / "netlist.json").read_text())
        masters = {r["macro"]["macro"] for r in d["regions"]}
        insts = macro_insts(js, masters)
        rec.update(parse_stat(o / "stat.txt"))
        rec["memories_after_map"] = len(mem_list(js))
        rec["macro_instances"] = len(insts)
        rec["expected_macro_instances"] = sum(r["macro"]["count"] * r["banks"] for r in d["regions"])
        rec["macro_masters"] = sorted(masters)
        rec["ok"] = rec["macro_instances"] == rec["expected_macro_instances"] and rec["memories_after_map"] == 0
        (o / "macro_instances.json").write_text(json.dumps(insts, indent=1) + "\n")
        with open(o / "netlist.v", "rb") as fi, gzip.open(o / "netlist.v.gz", "wb") as fo:
            shutil.copyfileobj(fi, fo)
        (o / "netlist.v").unlink()
        with open(o / "netlist.json", "rb") as fi, gzip.open(o / "netlist.json.gz", "wb") as fo:
            shutil.copyfileobj(fi, fo)
        (o / "netlist.json").unlink()
    return rec


def job_fpga(name):
    cfg = json.loads((ROOT / f"config/{name}.json").read_text())
    cfg["implementation"]["flow"] = "fpga"
    cfg["name"] = f"{name}_fpga"
    d = sg_config.derive(cfg)
    sg_config.emit(d, ROOT / "gen")
    o = OUT / f"{name}_fpga"
    o.mkdir(parents=True, exist_ok=True)
    script = f"{read_cmd(d['name'], False)}; synth_xilinx -family xc7 -top sg_top -flatten; tee -o {o}/stat.txt stat"
    rc, t, err = run_yosys(script, o / "yosys.log")
    rec = {"target": f"{name}_fpga", "flow": "fpga", "rc": rc, "seconds": round(t, 1), "stderr": err if rc else ""}
    if rc == 0:
        st = parse_stat(o / "stat.txt")
        rec.update(st)
        bt = st["by_type"]
        rec["ramb36"] = bt.get("RAMB36E1", 0)
        rec["ramb18"] = bt.get("RAMB18E1", 0)
        rec["lutram"] = sum(v for k, v in bt.items() if k.startswith("RAM") and not k.startswith("RAMB"))
        rec["bank_bits"] = sum(b["stored_width"] * b["depth"] for b in d["banks"])
        rec["bram_capacity_bits"] = rec["ramb36"] * 36864 + rec["ramb18"] * 18432
        rec["ok"] = (rec["ramb36"] + rec["ramb18"]) > 0 and rec["bram_capacity_bits"] >= rec["bank_bits"]
    return rec


IHP_LIB = "ihp-sg13g2/libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_typ_1p20V_25C.lib"
IHP_LIB_SHA = "7677a8918689f452e80405ad16a83e744709342574f2aedcc507c2758986b396"


def job_ihp(name):
    """ASIC configuration mapped to the IHP SG13G2 standard cells (typical corner Liberty, fetched at
    the pinned commit): real cell areas for the grid LOGIC; the SRAM macros stay black boxes (their
    area comes from the LEF).  Unplaced: no utilisation, clock tree, buffering or fill."""
    import hashlib
    import os
    ext = Path(os.environ.get("SG_EXT", ROOT.parent / "ext"))
    lib = ext / "ihp" / IHP_LIB
    rec = {"target": f"{name}_ihp", "flow": "asic+ihp_stdcells", "rc": 1, "seconds": 0, "liberty": IHP_LIB}
    if not lib.exists() or hashlib.sha256(lib.read_bytes()).hexdigest() != IHP_LIB_SHA:
        rec["stderr"] = f"IHP stdcell Liberty missing or hash mismatch ({lib}); run scripts/fetch_macros.sh"
        return rec
    cfg = json.loads((ROOT / f"config/{name}.json").read_text())
    cfg["implementation"]["flow"] = "asic"
    cfg["name"] = f"{name}_asic"
    d = sg_config.derive(cfg)
    sg_config.emit(d, ROOT / "gen")
    o = OUT / f"{name}_ihp"
    o.mkdir(parents=True, exist_ok=True)
    script = (f"{read_cmd(d['name'], True)}; hierarchy -top sg_top; synth -top sg_top -flatten; "
              f"dfflibmap -liberty {lib}; abc -liberty {lib}; opt_clean -purge; "
              f"tee -o {o}/stat.txt stat -liberty {lib}")
    rc, t, err = run_yosys(script, o / "yosys.log")
    rec.update({"rc": rc, "seconds": round(t, 1), "stderr": err if rc else ""})
    if rc == 0:
        txt = (o / "stat.txt").read_text()
        m = re.search(r"Chip area for (?:top )?module '\\?sg_top':\s+([0-9.]+)", txt)
        rec["stdcell_area_um2"] = float(m.group(1)) if m else None
        st = parse_stat(o / "stat.txt")
        rec["cells"] = st["cells"]
        rec["macro_instances"] = sum(v for k, v in st["by_type"].items() if k.startswith("RM_IHPSG13"))
        rec["flops"] = sum(v for k, v in st["by_type"].items() if k.startswith("sg13g2_df") or k.startswith("sg13g2_sdf"))
        rec["ok"] = rec["stdcell_area_um2"] is not None
        rec["liberty_sha256"] = IHP_LIB_SHA
    return rec


def main() -> int:
    targets = sys.argv[1].split(",") if len(sys.argv) > 1 else [
        "sg_min4:generic", "sg_min4:asic", "sg_min4:fpga", "sg_hier:generic", "sg_hier:asic"]
    OUT.mkdir(parents=True, exist_ok=True)
    prev = {}
    pj = ROOT / "reports/synth.json"
    if pj.exists():
        prev = {r["target"]: r for r in json.loads(pj.read_text()).get("results", [])}
    for t in targets:
        name, flow = t.split(":")
        rec = {"generic": job_generic, "asic": job_asic, "fpga": job_fpga, "ihp": job_ihp}[flow](name)
        prev[rec["target"]] = rec
        print(f"[synth] {rec['target']}: rc={rec['rc']} ok={rec.get('ok')} cells={rec.get('cells')} "
              f"{rec['seconds']}s {rec.get('stderr', '')[:300]}", flush=True)
    ver = subprocess.run(["yosys", "-V"], capture_output=True, text=True).stdout.strip()
    pj.write_text(json.dumps({"yosys": ver, "results": list(prev.values())}, indent=1) + "\n")
    return 0 if all(r["rc"] == 0 and r.get("ok") for r in prev.values()) else 1


if __name__ == "__main__":
    sys.exit(main())
