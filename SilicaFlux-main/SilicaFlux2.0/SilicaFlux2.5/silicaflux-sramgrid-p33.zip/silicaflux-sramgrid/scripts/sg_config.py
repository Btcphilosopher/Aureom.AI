#!/usr/bin/env python3
"""SilicaFlux-HPC Project 33 SRAMGRID -- memory configuration tool.

  sg_config.py validate <cfg.json>            schema + cross-field rules (non-zero exit on any violation)
  sg_config.py derive   <cfg.json> [-o d.json] derived facts: banks, depths, stored widths, latencies,
                                               macro mapping from the REAL LEF abstracts, links, area
  sg_config.py emit     <cfg.json> [-o gen/]   gen/<name>/sg_cfg.svh (parameters), sg_top.sv (synthesis top),
                                               derived.json, memory_map.md

The logical address map (regions) and the physical arrangement (banks -> macros
-> placement) are derived separately: changing banks, macros or placement never
moves an address.  Every check the RTL performs at elaboration is repeated here
so a bad configuration is refused before any tool runs (and the RTL refuses it
again if the generator is bypassed).
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "config/schema/sramgrid_config.schema.json"
ABSTRACTS = ROOT / "physical/abstracts"
MANIFESTS = ROOT / "third_party/silicaflux-sramlib/manifests"

PM = {"1rw": 0, "1r1w": 1, "2rw": 2}
MAP = {"low": 0, "xor": 1, "high": 2}
ECC = {"none": 0, "parity": 1, "secded": 2}
IMPL = {"generic": 0, "fpga": 1, "asic": 2}
KIND = {"shared": 0, "vec_local": 1, "ten_operand": 2, "ten_acc": 3, "boot": 4}
# Macro selection cost: footprint including one routing channel per macro (the
# FloorplanLab rule: MACRO_PLACE_HALO 20 um, MACRO_PLACE_CHANNEL 40 um).  Pure
# macro area would favour many narrow macros whose halos and channels cost more
# die area than they save.
PLANNING_CHANNEL_UM = 40.0

TECH_FAMILIES = {
    "ihp_sg13g2": {"1rw": ["IHP_1P", "IHP_2P"], "1r1w": ["IHP_2P"], "2rw": ["IHP_2P"]},
    "sky130": {"1rw": ["SKY130_1RW1R"], "1r1w": ["SKY130_1RW1R"], "2rw": []},
    "gf180": {"1rw": ["GF180_1RW"], "1r1w": [], "2rw": []},
}


class ConfigError(Exception):
    pass


def parse_size(s: str) -> int:
    m = re.fullmatch(r"([0-9]+)(B|KiB|MiB)", s)
    return int(m.group(1)) * {"B": 1, "KiB": 1024, "MiB": 1 << 20}[m.group(2)]


def is_pow2(x: int) -> bool:
    return x > 0 and (x & (x - 1)) == 0


def clog2(x: int) -> int:
    return max(0, math.ceil(math.log2(x))) if x > 1 else 0


def secded_r(g: int) -> int:
    return min(t for t in range(1, 25) if (1 << t) >= g + t + 1)


def stored_width(ecc: str, dw: int, g: int) -> int:
    if ecc == "parity":
        return dw // 8 * 9
    if ecc == "secded":
        return dw // g * (g + secded_r(g) + 1)
    return dw


def mask_width(ecc: str, bwe: bool, dw: int, g: int) -> int:
    if ecc == "secded":
        return dw // g
    return dw // 8 if bwe else 1


def load_abstracts() -> dict:
    out = {}
    for f in sorted(ABSTRACTS.glob("*.json")):
        j = json.loads(f.read_text())
        if j.get("schema") == "silicaflux-sramgrid/macro-abstract/1":
            out[j["macro"]] = j
    return out


def defaults(cfg: dict) -> dict:
    g = cfg["grid"]
    g.setdefault("tag_width", 8)
    g.setdefault("ecc_granule", 64)
    g.setdefault("reorder_slots", 4)
    g.setdefault("arbitration", "rr")
    g.setdefault("read_during_write", "write_first")
    g.setdefault("init_on_reset", True)
    g.setdefault("init_after_test", True)
    g.setdefault("perf_counters", True)
    g.setdefault("counter_width", 32)
    for r in cfg["regions"]:
        r.setdefault("port_model", "1rw")
        r.setdefault("map", "low")
        r.setdefault("ecc", "none")
        r.setdefault("byte_write", r["ecc"] != "secded")
        r.setdefault("req_pipe", 0)
        r.setdefault("out_reg", 0)
        r.setdefault("write_protect", False)
        r.setdefault("macro", "auto")
    for p in cfg["ports"]:
        p.setdefault("slice", 1)
    return cfg


def schema_validate(cfg: dict) -> list[str]:
    try:
        import jsonschema  # type: ignore
    except ImportError:
        return ["jsonschema module not available: structural validation skipped (cross-field rules still run)"]
    v = jsonschema.Draft202012Validator(json.loads(SCHEMA.read_text()))
    return [f"schema: {'/'.join(str(x) for x in e.absolute_path)}: {e.message}" for e in v.iter_errors(cfg)]


def macro_candidates(region: dict, sw: int, mw: int, depth: int, tech: str, abstracts: dict) -> list[dict]:
    fams = TECH_FAMILIES[tech][region["port_model"]]
    lw = sw // mw
    out = []
    for name, a in abstracts.items():
        if a["family"] not in fams:
            continue
        mg = a["mask_granularity_bits"]
        if mg > 1 and mw != 1 and lw % mg != 0:
            continue                  # sramlib rule: lane width must be a multiple of the macro mask granularity
        nc = math.ceil(sw / a["data_width"])
        nr = math.ceil(depth / a["words"])
        n = nc * nr
        fp = (a["width_um"] + PLANNING_CHANNEL_UM) * (a["height_um"] + PLANNING_CHANNEL_UM)
        out.append({"macro": name, "id": a["sramlib_id"], "define": a["sramlib_define"], "family": a["family"],
                    "macro_width": a["data_width"], "macro_words": a["words"], "nc": nc, "nr": nr, "count": n,
                    "w_um": a["width_um"], "h_um": a["height_um"], "macro_area_um2": a["area_um2"],
                    "area_um2": round(n * a["area_um2"], 2), "footprint_um2": round(n * fp, 2),
                    "bits_provided": n * a["data_width"] * a["words"], "bits_needed": sw * depth})
    out.sort(key=lambda c: (c["footprint_um2"], c["count"], c["macro"]))
    return out


def derive(cfg: dict) -> dict:
    """Validate and derive.  Raises ConfigError listing every violation."""
    cfg = defaults(json.loads(json.dumps(cfg)))
    errs = schema_validate(cfg)
    errs = [e for e in errs if not e.startswith("jsonschema module")]
    if errs:
        raise ConfigError("\n".join(errs))
    g = cfg["grid"]
    dw, aw, eg = g["data_width"], g["addr_width"], g["ecc_granule"]
    off = clog2(dw // 8)
    tech = cfg["implementation"]["technology"]
    flow = cfg["implementation"]["flow"]
    abstracts = load_abstracts()
    if not abstracts:
        errs.append("no macro abstracts in physical/abstracts (run make abstracts)")

    names = [r["name"] for r in cfg["regions"]]
    if len(set(names)) != len(names):
        errs.append("region names must be unique")
    pnames = [p["name"] for p in cfg["ports"]]
    if len(set(pnames)) != len(pnames):
        errs.append("port names must be unique")
    if eg > dw:
        errs.append(f"ecc_granule {eg} exceeds data_width {dw}")

    regions = []
    gb = 0
    for i, r in enumerate(cfg["regions"]):
        base = int(r["base"].replace("_", ""), 16)
        size = parse_size(r["size"])
        nb = r["banks"]
        tag = f"region '{r['name']}'"
        if not is_pow2(size):
            errs.append(f"{tag}: size must be a power of two")
            continue
        l2b = clog2(size)
        bw = clog2(nb)
        rw = l2b - off - bw
        if rw < 1:
            errs.append(f"{tag}: too small - each of the {nb} banks needs at least 2 rows of {dw // 8} bytes")
        if base % size:
            errs.append(f"{tag}: base {r['base']} is not aligned to its size {r['size']}")
        if base + size > (1 << aw):
            errs.append(f"{tag}: window exceeds the {aw}-bit address space")
        if l2b > 40:
            errs.append(f"{tag}: regions above 1 TiB are not supported")
        if r["map"] == "xor" and rw < bw:
            errs.append(f"{tag}: map 'xor' needs at least as many row bits as bank bits")
        if r["ecc"] == "secded" and r["byte_write"]:
            errs.append(f"{tag}: SECDED regions are written per {eg}-bit granule; byte_write must be false "
                        f"(byte writes would need read-modify-write, which is not implemented)")
        if r["ecc"] == "secded" and dw % eg:
            errs.append(f"{tag}: data_width must be a multiple of ecc_granule")
        if r["port_model"] == "2rw" and flow == "fpga":
            pass   # sramlib FPGA backend implements 2RW (true dual-port BRAM)
        sw = stored_width(r["ecc"], dw, eg)
        mw = mask_width(r["ecc"], r["byte_write"], dw, eg)
        depth = 1 << max(rw, 1)
        lat = r["req_pipe"] + 1 + r["out_reg"]
        cands = macro_candidates(r, sw, mw, depth, tech, abstracts) if abstracts else []
        sel = None
        if r["macro"] == "auto":
            sel = cands[0] if cands else None
            if not cands:
                errs.append(f"{tag}: no {tech} macro implements port model {r['port_model']} with "
                            f"{sw // mw}-bit write lanes (stored word {sw} bits)")
        else:
            sel = next((c for c in cands if c["macro"] == r["macro"]), None)
            if sel is None:
                errs.append(f"{tag}: macro {r['macro']} is not a feasible {tech} macro for this region "
                            f"(unknown, wrong topology or write-mask granularity)")
        regions.append({
            "index": i, "name": r["name"], "kind": r["kind"], "near": r.get("near"), "base": base, "bytes": size,
            "log2_bytes": l2b, "banks": nb, "bank_bits": bw, "row_bits": rw, "depth": depth,
            "port_model": r["port_model"], "map": r["map"], "ecc": r["ecc"], "byte_write": r["byte_write"],
            "req_pipe": r["req_pipe"], "out_reg": r["out_reg"], "write_protect": r["write_protect"],
            "stored_width": sw, "mask_width": mw, "lane_width": sw // mw, "latency": lat,
            "logical_bits": size * 8, "stored_bits": nb * depth * sw,
            "first_bank": gb, "macro": sel, "macro_alternatives": cands[1:4],
        })
        gb += nb
    # overlap
    for a in regions:
        for b in regions:
            if a["index"] < b["index"] and a["base"] < b["base"] + b["bytes"] and b["base"] < a["base"] + a["bytes"]:
                errs.append(f"regions '{a['name']}' and '{b['name']}' overlap")
    # ports
    ports = []
    rindex = {r["name"]: r["index"] for r in regions}
    for i, p in enumerate(cfg["ports"]):
        reach = 0
        for rn in p["regions"]:
            if rn not in rindex:
                errs.append(f"port '{p['name']}': unknown region '{rn}'")
            else:
                reach |= 1 << rindex[rn]
        ports.append({"index": i, "name": p["name"], "kind": p["kind"], "cluster": p.get("cluster"),
                      "regions": p["regions"], "reach": reach, "slice": p["slice"]})
    for r in regions:
        if not any(p["reach"] >> r["index"] & 1 for p in ports):
            errs.append(f"region '{r['name']}' is not wired to any port")
    if errs:
        raise ConfigError("\n".join(errs))

    nr, npo = len(regions), len(ports)
    nbt = gb
    banks = []
    for r in regions:
        for j in range(r["banks"]):
            conn = [p["index"] for p in ports if p["reach"] >> r["index"] & 1]
            banks.append({"index": r["first_bank"] + j, "region": r["name"], "region_index": r["index"], "local": j,
                          "depth": r["depth"], "stored_width": r["stored_width"], "latency": r["latency"],
                          "ports": conn,
                          "rtl_path": f"g_bank[{r['first_bank'] + j}].u_bank.u_mw",
                          "macro": r["macro"]["macro"] if r["macro"] else None,
                          "macros": r["macro"]["count"] if r["macro"] else 0})
    links = sum(len(b["ports"]) for b in banks)
    test_lat = max(r["latency"] for r in regions)
    rwx = max(1, max(r["row_bits"] for r in regions))
    tsw = max(r["stored_width"] for r in regions)
    d = {
        "schema": "silicaflux-sramgrid/derived/1", "name": cfg["name"], "description": cfg.get("description", ""),
        "config": cfg, "data_width": dw, "addr_width": aw, "ecc_granule": eg, "offset_bits": off,
        "flow": flow, "technology": tech, "regions": regions, "ports": ports, "banks": banks,
        "NP": npo, "NR": nr, "NBT": nbt, "RWX": rwx, "TSW": tsw, "TEST_LAT": test_lat,
        "links": links, "full_crossbar_links": npo * nbt,
        "response_latency": {r["name"]: r["latency"] + 1 for r in regions},
        # a slot is held from the issue edge until the response handshake (LAT + 1 cycles) and is reusable at
        # the next edge: one access per cycle needs LAT + 2 slots (measured: reports/performance.md)
        "min_reorder_slots_for_full_rate": max(r["latency"] for r in regions) + 2,
    }
    if g["reorder_slots"] < d["min_reorder_slots_for_full_rate"]:
        d["warnings"] = [f"reorder_slots {g['reorder_slots']} < {d['min_reorder_slots_for_full_rate']}: "
                         f"a single port cannot sustain one access per cycle into the slowest region"]
    return d


def _vec(vals: list[int], w: int) -> str:
    """Packed vector literal, element 0 in the least significant position."""
    n = len(vals)
    v = 0
    for i, x in enumerate(vals):
        assert 0 <= x < (1 << w), (x, w)
        v |= x << (i * w)
    return f"{n * w}'h{v:0{(n * w + 3) // 4}x}"


def sv_header(d: dict) -> str:
    g = d["config"]["grid"]
    R = d["regions"]
    impl = IMPL[d["flow"]]
    reach = 0
    for p in d["ports"]:
        reach |= p["reach"] << (p["index"] * d["NR"])
    lines = [
        "// GENERATED by scripts/sg_config.py -- DO NOT EDIT",
        f"// configuration: {d['name']} ({d['description']})",
        "`ifndef SGC_CFG_SVH", "`define SGC_CFG_SVH",
        f"`define SGC_NAME \"{d['name']}\"",
        f"`define SGC_NP {d['NP']}", f"`define SGC_NR {d['NR']}", f"`define SGC_AW {d['addr_width']}",
        f"`define SGC_DW {d['data_width']}", f"`define SGC_TAG_W {g['tag_width']}",
        f"`define SGC_ECC_G {d['ecc_granule']}", f"`define SGC_NSLOT {g['reorder_slots']}",
        f"`define SGC_ARB {0 if g['arbitration'] == 'rr' else 1}",
        f"`define SGC_RDW {0 if g['read_during_write'] == 'write_first' else 1}",
        f"`define SGC_R_BASE {_vec([r['base'] for r in R], 64)}",
        f"`define SGC_R_LOG2B {_vec([r['log2_bytes'] for r in R], 8)}",
        f"`define SGC_R_NB {_vec([r['banks'] for r in R], 8)}",
        f"`define SGC_R_PM {_vec([PM[r['port_model']] for r in R], 8)}",
        f"`define SGC_R_MAP {_vec([MAP[r['map']] for r in R], 8)}",
        f"`define SGC_R_ECC {_vec([ECC[r['ecc']] for r in R], 8)}",
        f"`define SGC_R_BWE {_vec([int(r['byte_write']) for r in R], 8)}",
        f"`define SGC_R_PIPE {_vec([r['req_pipe'] for r in R], 8)}",
        f"`define SGC_R_OREG {_vec([r['out_reg'] for r in R], 8)}",
        f"`define SGC_R_IMPL {_vec([impl for _ in R], 8)}",
        f"`define SGC_R_MACRO {_vec([(r['macro']['id'] if (impl == 2 and r['macro']) else 0) for r in R], 16)}",
        f"`define SGC_R_WP {_vec([int(r['write_protect']) for r in R], 8)}",
        f"`define SGC_R_KIND {_vec([KIND[r['kind']] for r in R], 8)}",
        f"`define SGC_P_REACH {d['NP'] * d['NR']}'h{reach:0{(d['NP'] * d['NR'] + 3) // 4}x}",
        f"`define SGC_P_SLICE {_vec([p['slice'] for p in d['ports']], 8)}",
        f"`define SGC_INIT_ON_RESET {int(g['init_on_reset'])}", f"`define SGC_INIT_AFTER_TEST {int(g['init_after_test'])}",
        f"`define SGC_PERF_EN {int(g['perf_counters'])}", f"`define SGC_CNT_W {g['counter_width']}",
        f"`define SGC_NBT {d['NBT']}", f"`define SGC_RWX {d['RWX']}", f"`define SGC_TSW {d['TSW']}",
        f"`define SGC_TEST_LAT {d['TEST_LAT']}",
        f"`define SGC_B_MAXADDR {_vec([b['depth'] - 1 for b in d['banks']], 32)}",
        f"`define SGC_B_SW {_vec([b['stored_width'] for b in d['banks']], 16)}",
        "`define SGC_PARAMS #( \\",
        "  .NP(`SGC_NP), .NR(`SGC_NR), .AW(`SGC_AW), .DW(`SGC_DW), .TAG_W(`SGC_TAG_W), .ECC_G(`SGC_ECC_G), \\",
        "  .NSLOT(`SGC_NSLOT), .ARB(`SGC_ARB), .RDW(`SGC_RDW), .R_BASE(`SGC_R_BASE), .R_LOG2B(`SGC_R_LOG2B), \\",
        "  .R_NB(`SGC_R_NB), .R_PM(`SGC_R_PM), .R_MAP(`SGC_R_MAP), .R_ECC(`SGC_R_ECC), .R_BWE(`SGC_R_BWE), \\",
        "  .R_PIPE(`SGC_R_PIPE), .R_OREG(`SGC_R_OREG), .R_IMPL(`SGC_R_IMPL), .R_MACRO(`SGC_R_MACRO), .R_WP(`SGC_R_WP), \\",
        "  .P_REACH(`SGC_P_REACH), .P_SLICE(`SGC_P_SLICE), .INIT_ON_RESET(`SGC_INIT_ON_RESET), \\",
        "  .INIT_AFTER_TEST(`SGC_INIT_AFTER_TEST), .PERF_EN(`SGC_PERF_EN), .CNT_W(`SGC_CNT_W), \\",
        "  .NBT(`SGC_NBT), .RWX(`SGC_RWX), .TSW(`SGC_TSW), .TEST_LAT(`SGC_TEST_LAT))",
        "`endif",
    ]
    return "\n".join(lines) + "\n"


SG_TOP = """// GENERATED by scripts/sg_config.py -- DO NOT EDIT
// Synthesis / lint top for configuration {name}: silicaflux_sram_grid with the
// configuration's parameters and the instance name u_grid (stable for the
// netlist-driven placement and connectivity reports).
`include "sg_cfg.svh"
`default_nettype none
module sg_top (
  input  wire logic clk, input wire logic rst_n,
  input  wire logic [`SGC_NP-1:0] req_valid, output logic [`SGC_NP-1:0] req_ready,
  input  wire logic [`SGC_NP-1:0] req_we, input wire logic [`SGC_NP*`SGC_AW-1:0] req_addr,
  input  wire logic [`SGC_NP*`SGC_DW-1:0] req_wdata, input wire logic [`SGC_NP*`SGC_DW/8-1:0] req_wstrb,
  input  wire logic [`SGC_NP*`SGC_TAG_W-1:0] req_tag,
  output logic [`SGC_NP-1:0] rsp_valid, input wire logic [`SGC_NP-1:0] rsp_ready,
  output logic [`SGC_NP*`SGC_DW-1:0] rsp_rdata, output logic [`SGC_NP-1:0] rsp_err,
  output logic [`SGC_NP*3-1:0] rsp_err_code, output logic [`SGC_NP-1:0] rsp_we, output logic [`SGC_NP-1:0] rsp_ce,
  output logic [`SGC_NP*`SGC_TAG_W-1:0] rsp_tag,
  input  wire logic wp_lock, input wire logic init_req, output logic init_busy, output logic init_done,
  input  wire logic tst_active, input wire logic [`SGC_NBT-1:0] tst_sel, input wire logic tst_ce, input wire logic tst_we,
  input  wire logic [`SGC_RWX-1:0] tst_addr, input wire logic [`SGC_TSW-1:0] tst_wdata,
  output logic [`SGC_NBT*`SGC_TSW-1:0] tst_rdata,
  output logic [`SGC_NR-1:0] ras_ev_valid, output logic [`SGC_NR-1:0] ras_ev_ce, output logic [`SGC_NR-1:0] ras_ev_ue,
  output logic [`SGC_NR-1:0] ras_ev_poison, output logic [`SGC_NR*3-1:0] ras_ev_org,
  output logic [`SGC_NR*`SGC_AW-1:0] ras_ev_addr, output logic [`SGC_NR*9-1:0] ras_ev_syn,
  output logic [`SGC_NR*8-1:0] ras_ev_idx, output logic [`SGC_NR-1:0] ras_ev_lost,
  output logic [`SGC_NP-1:0] ev_accept, output logic [`SGC_NP-1:0] ev_issue, output logic [`SGC_NP-1:0] ev_conflict,
  output logic [`SGC_NP-1:0] ev_credit_stall, output logic [`SGC_NP-1:0] ev_block_stall, output logic [`SGC_NP-1:0] ev_error,
  output logic [`SGC_NP-1:0] ev_complete, output logic [`SGC_NBT*2-1:0] ev_bank_ops,
  output logic [`SGC_NBT-1:0] ev_bank_conflict, output logic [`SGC_NBT-1:0] ev_rdw_split,
  input  wire logic perf_clear, output logic [`SGC_CNT_W-1:0] perf_cycles,
  output logic [`SGC_NP*`SGC_CNT_W-1:0] perf_issue, output logic [`SGC_NP*`SGC_CNT_W-1:0] perf_conflict,
  output logic [`SGC_NP*`SGC_CNT_W-1:0] perf_credit_stall, output logic [`SGC_NP*`SGC_CNT_W-1:0] perf_complete,
  output logic [`SGC_NBT*`SGC_CNT_W-1:0] perf_bank_ops, output logic [`SGC_NBT*`SGC_CNT_W-1:0] perf_bank_conflict,
  output logic [`SGC_CNT_W-1:0] perf_ecc_ce, output logic [`SGC_CNT_W-1:0] perf_ecc_ue, output logic busy
);
  silicaflux_sram_grid `SGC_PARAMS u_grid (.*);
endmodule
`default_nettype wire
"""


def hx(v: int, aw: int) -> str:
    return f"0x{v:0{(aw + 3) // 4}x}"


def memory_map_md(d: dict) -> str:
    aw = d["addr_width"]
    L = [f"# Memory map — `{d['name']}`", "", d["description"], "",
         f"Bank word {d['data_width']} bits; flow `{d['flow']}`; macro catalogue `{d['technology']}` (real LEF "
         "abstracts, `physical/abstracts/`).", "",
         "| Region | Kind | Window | Size | Banks × depth | Map | Port model | ECC | Stored word | Lat (rsp) | WP | Macro × count |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in d["regions"]:
        m = r["macro"]
        L.append(f"| `{r['name']}` | {r['kind']} | `{hx(r['base'], aw)}`–`{hx(r['base'] + r['bytes'] - 1, aw)}` | "
                 f"{r['bytes'] // 1024} KiB | {r['banks']} × {r['depth']} | {r['map']} | {r['port_model']} | {r['ecc']} | "
                 f"{r['stored_width']} b ({r['mask_width']} lanes) | {r['latency'] + 1} | {'yes' if r['write_protect'] else 'no'} | "
                 f"`{m['macro']}` × {m['count']} ({m['nc']}×{m['nr']} per bank × {r['banks']}) |" if m else "| — |")
    L += ["", "Every address outside these windows is UNMAPPED (error response, no side effect, never wrapped).", "",
          "## Port wiring (sparse crossbar)", "",
          "| Port | Kind | Regions | Slice | Banks reachable |", "|---|---|---|---|---|"]
    for p in d["ports"]:
        nb = sum(1 for b in d["banks"] if p["index"] in b["ports"])
        L.append(f"| `{p['name']}` | {p['kind']} | {', '.join(p['regions'])} | {p['slice']} | {nb} / {d['NBT']} |")
    L += ["", f"Port–bank links: **{d['links']}** of {d['full_crossbar_links']} for a full crossbar "
          f"({100 * d['links'] / d['full_crossbar_links']:.0f} %).", ""]
    return "\n".join(L)


def emit(d: dict, out: Path) -> Path:
    o = out / d["name"]
    o.mkdir(parents=True, exist_ok=True)
    (o / "sg_cfg.svh").write_text(sv_header(d))
    (o / "sg_top.sv").write_text(SG_TOP.replace("{name}", d["name"]))
    (o / "derived.json").write_text(json.dumps(d, indent=1) + "\n")
    (o / "memory_map.md").write_text(memory_map_md(d))
    return o


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["validate", "derive", "emit"])
    ap.add_argument("config", type=Path)
    ap.add_argument("-o", "--out", type=Path)
    ap.add_argument("--flow", choices=["generic", "fpga", "asic"],
                    help="override implementation.flow; the emitted name gets the suffix _<flow>")
    a = ap.parse_args()
    cfg = json.loads(a.config.read_text())
    if a.flow:
        cfg["implementation"]["flow"] = a.flow
        cfg["name"] = f"{cfg['name']}_{a.flow}"
    try:
        d = derive(cfg)
    except ConfigError as e:
        print(f"[sg_config] REJECTED {a.config}:\n{e}", file=sys.stderr)
        return 2
    for w in d.get("warnings", []):
        print(f"[sg_config] warning: {w}", file=sys.stderr)
    if a.cmd == "validate":
        print(f"[sg_config] OK {d['name']}: {d['NR']} regions, {d['NBT']} banks, {d['NP']} ports, "
              f"{d['links']}/{d['full_crossbar_links']} links")
    elif a.cmd == "derive":
        s = json.dumps(d, indent=1)
        (a.out.write_text(s + "\n") if a.out else print(s))
    else:
        o = emit(d, a.out or ROOT / "gen")
        print(f"[sg_config] emitted {o}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
