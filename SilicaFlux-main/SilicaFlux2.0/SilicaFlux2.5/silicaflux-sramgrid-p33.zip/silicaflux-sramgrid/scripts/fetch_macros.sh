#!/usr/bin/env bash
# =============================================================================
# SilicaFlux-HPC Project 33 SRAMGRID :: fetch_macros.sh
# Fetches the PUBLIC open-PDK views this project reads, pinned to the commits the
# SRAM Wrapper Library manifests were generated from, and verifies every file
# against the SHA-256 recorded in the manifests / below.  Nothing fetched is
# executed: LEF and Liberty are parsed as text, Verilog models are simulated.
# Nothing fetched is redistributed in this archive (the macro abstracts in
# physical/abstracts/ are derived facts with provenance hashes).
#
#   scripts/fetch_macros.sh [dest]        (default: ../ext next to the project)
# =============================================================================
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
DEST="${1:-$HERE/../ext}"
# 1. SKY130 / GF180MCU / IHP SG13G2 SRAM views (LEF, Verilog models, datasheets): the library's own script
bash "$HERE/third_party/silicaflux-sramlib/scripts/mem/fetch_open_macros.sh" "$DEST"
# 2. IHP SG13G2 technology + standard-cell LEF (site / grid / layers) and the typical-corner stdcell Liberty
git -C "$DEST/ihp" sparse-checkout add \
  '/ihp-sg13g2/libs.ref/sg13g2_stdcell/lef/*' \
  '/ihp-sg13g2/libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_typ_1p20V_25C.lib'
test "$(git -C "$DEST/ihp" rev-parse HEAD)" = "5e6d592e4002946a4616f798c357f0f3c06cf3b6"
echo "7677a8918689f452e80405ad16a83e744709342574f2aedcc507c2758986b396  $DEST/ihp/ihp-sg13g2/libs.ref/sg13g2_stdcell/lib/sg13g2_stdcell_typ_1p20V_25C.lib" | sha256sum -c -
# 3. every SRAM LEF / model the manifests list must match its recorded hash
python3 -I - "$HERE" "$DEST" <<'PY'
import hashlib, json, glob, os, sys
here, dest = sys.argv[1], sys.argv[2]
roots = {"IHP": "ihp", "SKY": "sky130_sram_macros", "GF1": "gf180_sram"}
ok = bad = 0
for m in glob.glob(os.path.join(here, "third_party/silicaflux-sramlib/manifests/*.json")):
    j = json.load(open(m))
    if not j.get("provenance"):
        continue
    for f, h in j["provenance"]["files"].items():
        p = os.path.join(dest, roots[j["family"][:3]], f)
        if os.path.exists(p) and hashlib.sha256(open(p, "rb").read()).hexdigest() == h:
            ok += 1
        else:
            bad += 1
            print("MISMATCH", p)
print(f"[fetch] {ok} files verified against the manifests, {bad} mismatches")
sys.exit(1 if bad else 0)
PY
echo "[fetch] done: $DEST (export SG_EXT=$DEST)"
