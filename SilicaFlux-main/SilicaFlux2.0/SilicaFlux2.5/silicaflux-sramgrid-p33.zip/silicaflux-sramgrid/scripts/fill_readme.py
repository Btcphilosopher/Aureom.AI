#!/usr/bin/env python3
"""Fill README.template.md from reports/*.json (every number in the README comes from a run)."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
R = ROOT / "reports"
j = lambda n: json.loads((R / n).read_text())  # noqa: E731
reg, wr, li, mu, sy, ph, ar = (j("regression.json"), j("wrapper.json"), j("lint.json"), j("mutation.json"),
                               j("synth.json"), j("physical.json"), j("area.json"))
c4, ch = j("connectivity_sg_min4.json"), j("connectivity_sg_hier.json")
s = reg["summary"]
cross = reg["cross_sim"]
m4 = [r for r in reg["results"] if r["cfg"] == "sg_min4"]
syn = {r["target"]: r for r in sy["results"]}
lsum = li["summary"]
killed = sum(1 for r in mu if r["killed"])
nplace = sum(len(c["strategies"]) for c in ph["configs"])
nclean = sum(1 for c in ph["configs"] for v in c["strategies"].values() if v["check_ok"])
REG = (f"**{s['pass']}/{s['jobs']}** simulation runs pass over {len({r['cfg'] for r in reg['results']})} configurations "
       f"({s['checks']:,} checks); `sg_min4` alone {sum(r['result'] == 'PASS' for r in m4)}/{len(m4)}; Icarus / Verilator "
       f"cross-simulation {sum(c['identical'] for c in cross)}/{len(cross)} cycle-identical; mutation testing "
       f"{killed}/{len(mu)} killed ([reports/regression.md](reports/regression.md), [reports/mutation.md](reports/mutation.md)).")
WR = (f"the macro wrapper returns exactly what a shadow memory predicts, at the declared latency, on the **vendors' own "
      f"models** of real IHP SG13G2 1P / 2P, SKY130 OpenRAM and GF180MCU macros: **{sum(r['result'] == 'PASS' for r in wr)}/{len(wr)}** "
      f"([reports/wrapper.md](reports/wrapper.md))")
SY = (f"Yosys: `sg_min4` ASIC netlist has exactly **{syn['sg_min4_asic']['macro_instances']}** `RM_IHPSG13_1P_1024x32` "
      f"macros and no inferred bank array, `sg_hier` exactly **{syn['sg_hier_asic']['macro_instances']}**; the generic flow infers "
      f"exactly one array per bank ({syn['sg_min4_generic']['bank_memories']} / {syn['sg_hier_generic']['bank_memories']}); "
      f"FPGA flow {syn['sg_min4_fpga']['ramb36']} RAMB36; macro connectivity {c4['macros'] + ch['macros']} macros, "
      f"{len(c4['anomalies']) + len(ch['anomalies'])} anomalies")
PH = (f"{nclean}/{nplace} placements (2 configurations × 4 strategies, real IHP LEF outlines) pass the independent "
      f"checker (overlap, channel, core, blockages, logic blocks, site/row grid, orientation, pin escape, Tcl = DEF, "
      f"mock-OpenDB execution); checker self-test {sum(x['caught'] for c in ph['configs'] for x in c['selftest'])}/"
      f"{sum(len(c['selftest']) for c in ph['configs'])} mutations caught ([reports/physical.md](reports/physical.md))")
GATE = f"gate {'open' if ph['gate']['open'] else 'CLOSED'}: {ph['gate']['sg_min4_sim_pass']}/{ph['gate']['sg_min4_sim_jobs']} `sg_min4` jobs, placements clean"
a4, ah = ar["sg_min4"]["totals"], ar["sg_hier"]["totals"]
wi = ar["sg_min4"]["regions"][0]["ecc_what_if"]
ecc_pct = round(100 * (wi["secded"]["macro_area_mm2"] / wi["none"]["macro_area_mm2"] - 1))
rows = [
    ("Simulation regression (15 configurations, 13 scenarios, Verilator + Icarus)", f"**{s['pass']}/{s['jobs']}**, {s['checks']:,} checks", "[regression](reports/regression.md)"),
    ("Cross-simulation, identical cycles and checks", f"{sum(c['identical'] for c in cross)}/{len(cross)}", "[regression](reports/regression.md)"),
    ("Macro wrapper vs vendor macro models", f"**{sum(r['result'] == 'PASS' for r in wr)}/{len(wr)}**", "[wrapper](reports/wrapper.md)"),
    ("Legal configurations warning-free (Verilator -Wall, Icarus, Yosys)", f"**{lsum['legal_ok']}/{lsum['legal']}**", "[lint](reports/lint.md)"),
    ("Illegal parameter sets refused by Verilator, Icarus **and** Yosys", f"**{lsum['illegal_refused']}/{lsum['illegal']}**", "[lint](reports/lint.md)"),
    ("Illegal JSON configurations refused by the generator", f"**{lsum['json_refused']}/{lsum['json']}**", "[lint](reports/lint.md)"),
    ("Mutation testing of the new RTL", f"**{killed}/{len(mu)}** killed", "[mutation](reports/mutation.md)"),
    ("Synthesis targets meeting their exact expectation", f"{sum(1 for r in sy['results'] if r.get('ok'))}/{len(sy['results'])}", "[synth](reports/synth.md)"),
    ("Placements clean / checker self-test", f"{nclean}/{nplace} / {sum(x['caught'] for c in ph['configs'] for x in c['selftest'])}/{sum(len(c['selftest']) for c in ph['configs'])}", "[physical](reports/physical.md)"),
    ("Macro connectivity anomalies (12 + 69 macros)", f"{len(c4['anomalies']) + len(ch['anomalies'])}", "[connectivity](reports/connectivity_sg_hier.md)"),
    ("`sg_min4`: 32 KiB, 4 banks × 1024 × 72 b SECDED", f"{a4['macros']} IHP macros **{a4['macro_area_mm2']} mm²** (LEF) + logic {a4['logic_stdcell_mm2']} mm² (IHP cells, unplaced)", "[area](reports/area.md)"),
    ("`sg_hier`: 224 KiB, 6 regions, 23 banks", f"{ah['macros']} IHP macros **{ah['macro_area_mm2']} mm²** + logic {ah['logic_stdcell_mm2']} mm²", "[area](reports/area.md)"),
    ("SECDED width cost on IHP (`sg_min4`, 64 → 72 bits)", f"+{ecc_pct} % macro area ({wi['none']['macro_area_mm2']} → {wi['secded']['macro_area_mm2']} mm²: no 72-bit macro, 3 × 32 b tiles)", "[area](reports/area.md)"),
    ("OpenROAD", "**not run** (check script provided)", "[docs/05 §7](docs/05_PHYSICAL.md)"),
]
TABLE = "| Check | Result | Report |\n|---|---|---|\n" + "\n".join(f"| {a} | {b} | {c} |" for a, b, c in rows)
t = (ROOT / "README.template.md").read_text()
for k, v in {"{{REGRESSION}}": REG, "{{WRAPPER}}": WR, "{{SYNTH}}": SY, "{{PHYSICAL}}": PH, "{{GATE}}": GATE,
             "{{RESULTS_TABLE}}": TABLE}.items():
    t = t.replace(k, v)
(ROOT / "README.md").write_text(t)
print("README.md written")
