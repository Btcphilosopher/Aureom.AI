#!/usr/bin/env python3
"""SilicaFlux-HPC Project 33 SRAMGRID -- markdown reports from the JSON results.

Every number in reports/*.md is read from a JSON file written by a run (regression, synth, wrapper,
lint, mutation, physical, area, connectivity).  Missing inputs are reported as missing, never filled in.
"""
from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
R = ROOT / "reports"


def load(name):
    p = R / name
    return json.loads(p.read_text()) if p.exists() else None


def regression_md(reg):
    if not reg:
        return "# Regression\n\nNot run.\n"
    L = ["# Simulation regression", "", f"Tools: {reg['tools']['verilator']}; {reg['tools']['icarus']}.", "",
         f"**{reg['summary']['pass']} / {reg['summary']['jobs']} runs pass; {reg['summary']['checks']:,} checks** "
         "(each checked response = tag + order + we + error code + data bytes + corrected flag; plus every word of "
         "every audit read back through the backdoor from the bank / row the reference map predicts).", "",
         "Verilator runs with `--assert -DSG_ASSERT` (protocol / arbiter / wrapper assertions), `SRAMLIB_POISON` "
         "(SRAM outputs X outside valid read slots) and `--x-assign unique --x-initial unique` (random power-up "
         "content, `+verilator+rand+reset+2`).  `sg_min4` seeds 1/2/3 and `sg_hier` seeds 1/2 use back-pressure / request "
         "gaps of 0/0, 20/20 and 50/10 %; the 13 variants seed 4 with 25/10 %; the `perf`, `conflict` and `dma` "
         "measurements of seeds 1 and 4 run without back-pressure.", ""]
    by = defaultdict(lambda: defaultdict(lambda: [0, 0, 0]))
    scens = []
    for r in reg["results"]:
        k = f"{r['cfg']} ({'Icarus' if r['sim'] == 'iv' else 'Verilator'})"
        c = by[k][r["scen"]]
        c[0] += r["result"] == "PASS"
        c[1] += 1
        c[2] += r["checks"]
        if r["scen"] not in scens:
            scens.append(r["scen"])
    L += ["| Configuration | " + " | ".join(scens) + " | checks |", "|---|" + "---|" * (len(scens) + 1)]
    for k in sorted(by):
        row = by[k]
        L.append(f"| {k} | " + " | ".join(f"{row[s][0]}/{row[s][1]}" if row[s][1] else "–" for s in scens) +
                 f" | {sum(v[2] for v in row.values()):,} |")
    L += ["", "## Cross-simulation (same configuration, scenario, seed, settings)", "",
          "| Config | Scenario | Icarus | Verilator | cycles (iv / vl) | checks (iv / vl) | identical |", "|---|---|---|---|---|---|---|"]
    for c in reg["cross_sim"]:
        L.append(f"| {c['cfg']} | {c['scen']} | {c['iv']} | {c['vl']} | {c['cycles_iv']} / {c['cycles_vl']} | "
                 f"{c['checks_iv']} / {c['checks_vl']} | {'yes' if c['identical'] else 'no'} |")
    notes = [n for r in reg["results"] for n in r.get("notes", []) if r["seed"] in (1, 4) and r["sim"] == "vl"]
    if notes:
        L += ["", "## Scenario notes (seed 1 / variants)", ""] + [f"* {n}" for n in sorted(set(notes))[:40]]
    return "\n".join(L) + "\n"


def perf_md(perf, phys):
    L = ["# Performance", "",
         "Measured in RTL simulation (Verilator, back-pressure 0 % unless noted). Bandwidth = completed bytes / "
         "cycles of the pattern. Bank utilisation = accesses performed / cycles (1RW limit 1.0, 1R1W / 2RW limit 2.0). "
         "Latency = cycles from request acceptance to response, reads only. Conflict = cycles a decodable request "
         "with a credit lost bank arbitration (arbitration stall). Credit stall = cycles a port waited for a reorder "
         "slot.", ""]
    if perf:
        L += ["| Config | Pattern | Seed | Cycles | Bytes | B/cycle | Bank util (min–max) | Conflicts | Credit stalls | Read latency min / avg / max |",
              "|---|---|---|---|---|---|---|---|---|---|"]
        seen = set()
        for m in perf:
            key = (m["cfg"], m["pattern"], m["seed"])
            if key in seen or m["seed"] not in (1, 4):
                continue
            seen.add(key)
            cyc = max(1, m["cycles"])
            util = [o / cyc for o in m["bank_ops"]]
            lat_n = [p for p in m["ports"] if p["lat_avg_x100"] > 0]
            lmin = min((p["lat_min"] for p in lat_n), default=0)
            lmax = max((p["lat_max"] for p in lat_n), default=0)
            lavg = (sum(p["lat_avg_x100"] * (p["rd"]) for p in lat_n) / max(1, sum(p["rd"] for p in lat_n))) / 100
            L.append(f"| {m['cfg']} | {m['pattern']} | {m['seed']} | {m['cycles']} | {m['bytes']} | {m['bytes'] / cyc:.2f} | "
                     f"{min(util):.2f}–{max(util):.2f} | {sum(p['conflict'] for p in m['ports'])} | "
                     f"{sum(p['credit_stall'] for p in m['ports'])} | {lmin} / {lavg:.2f} / {lmax} |")
    if phys:
        L += ["", "## Placement options vs wire-distance estimates", "",
              "**Estimates, not extracted delay**: Manhattan distance from each port's (assumed) cluster-block centre "
              "to each bank's signal-pin centroid, weighted by the floorplan file's assumed traffic mix; `mm·bit` = "
              "Σ over port-bank links of distance × (2·DW + AW + 16) wires. Suggested request-pipe stages assume "
              "1.5 mm per clock (an assumption in the floorplan file). No routing, no RC extraction, no STA.", "",
              "| Config | Strategy | Weighted distance | Sparse-crossbar wiring | Suggested req_pipe (configured) | Checks |",
              "|---|---|---|---|---|---|"]
        for c in phys["configs"]:
            for s, v in c["strategies"].items():
                sp = ", ".join(f"{k} {x['suggested_req_pipe']} ({x['configured_req_pipe']})" for k, x in v["regions"].items())
                L.append(f"| {c['config']} | {s} | {v['weighted_mean_mm']} mm | {v['crossbar_mm_bits']:,.0f} mm·bit | {sp} | "
                         f"{'clean' if v['check_ok'] else str(v['violations']) + ' violations'} |")
    return "\n".join(L) + "\n"


def synth_md(sy):
    if not sy:
        return "# Synthesis\n\nNot run.\n"
    L = ["# Synthesis (Yosys)", "", f"{sy['yosys']}", "",
         "| Target | Flow | Result | Cells | Evidence |", "|---|---|---|---|---|"]
    for r in sy["results"]:
        if r["flow"] == "generic":
            ev = (f"{r.get('bank_memories')} inferred bank arrays ({r.get('bank_memory_bits'):,} bits) = expected "
                  f"{r.get('expected_bank_memories')} ({r.get('expected_bank_bits'):,} bits)")
        elif r["flow"] == "asic":
            ev = (f"{r.get('macro_instances')} macro instances (expected {r.get('expected_macro_instances')}): "
                  f"{', '.join(r.get('macro_masters', []))}; inferred memories after mapping: {r.get('memories_after_map')}")
        elif r["flow"] == "fpga":
            ev = (f"{r.get('ramb36')} RAMB36 + {r.get('ramb18')} RAMB18 = {r.get('bram_capacity_bits'):,} bits for "
                  f"{r.get('bank_bits'):,} stored bits")
        else:
            ev = (f"IHP SG13G2 cells (typical Liberty): **{r.get('stdcell_area_um2', 0) / 1e6:.4f} mm²** logic, "
                  f"{r.get('flops')} flip-flops, {r.get('macro_instances')} macro black boxes")
        L.append(f"| `{r['target']}` | {r['flow']} | {'OK' if r.get('ok') else 'FAIL'} | {r.get('cells')} | {ev} |")
    L += ["", "Netlists, instance lists and logs: `reports/synth/<target>/`. Standard-cell area is unplaced cell area "
          "(no utilisation, clock tree, buffering, fill)."]
    return "\n".join(L) + "\n"


def simple_md(title, rows, cols, intro=""):
    L = [f"# {title}", ""] + ([intro, ""] if intro else [])
    L += ["| " + " | ".join(c[0] for c in cols) + " |", "|" + "---|" * len(cols)]
    for r in rows:
        L.append("| " + " | ".join(str(c[1](r)) for c in cols) + " |")
    return "\n".join(L) + "\n"


def main():
    reg, perf, sy = load("regression.json"), load("performance.json"), load("synth.json")
    wr, li, mu, ph, ar = load("wrapper.json"), load("lint.json"), load("mutation.json"), load("physical.json"), load("area.json")
    (R / "regression.md").write_text(regression_md(reg))
    (R / "performance.md").write_text(perf_md(perf, ph))
    (R / "synth.md").write_text(synth_md(sy))
    if wr:
        (R / "wrapper.md").write_text(simple_md(
            "Macro wrapper: timing semantics and real-macro equivalence", wr,
            [("Case", lambda r: r["case"]), ("Simulator", lambda r: r["sim"]), ("Result", lambda r: r["result"]),
             ("Detail", lambda r: r.get("summary", r.get("why", "")))],
            "Generic reference wrapper vs wrapper on the vendor's own Verilog model (IHP SG13G2 with `FUNCTIONAL`, "
            "SKY130 OpenRAM, GF180MCU), identical random traffic incl. masked writes and test-port operations; every "
            "read checked against a shadow memory at exactly the declared latency, `rvalid` alignment every cycle, "
            "output hold with OUT_REG = 1."))
    if li:
        s = li["summary"]
        L = ["# Lint, elaboration and configuration rejection", "",
             f"Legal configurations clean: **{s['legal_ok']}/{s['legal']}** (Verilator `-Wall` with and without "
             "`SG_ASSERT`: 0 messages from the new RTL; Icarus compile + elaboration run; Yosys hierarchy/proc/check).",
             f"Illegal parameter sets refused by all three tools: **{s['illegal_refused']}/{s['illegal']}**.",
             f"Illegal JSON configurations refused by `sg_config.py`: **{s['json_refused']}/{s['json']}**.", "",
             "| Legal configuration | Verilator msgs (plain / assert) | Icarus | Yosys | OK |", "|---|---|---|---|---|"]
        for r in li["legal"]:
            L.append(f"| {r['config']} | {r['verilator']['messages']} / {r['verilator_assert']['messages']} | "
                     f"rc {r['icarus']['rc']}/{r['icarus']['run_rc']} | rc {r['yosys']['rc']} | {'yes' if r['ok'] else 'NO'} |")
        L += ["", "| Illegal parameter set (bypassing the generator) | Expected check | Verilator | Icarus | Yosys |", "|---|---|---|---|---|"]
        for r in li["illegal_rtl"]:
            L.append(f"| {r['case']} | `{r['expect']}` | {'refused' if r['verilator']['refused'] else 'ACCEPTED'} | "
                     f"{'refused' if r['icarus']['refused'] else 'ACCEPTED'} | {'refused' if r['yosys']['refused'] else 'ACCEPTED'} |")
        L += ["", "| Illegal JSON configuration | sg_config.py | First message |", "|---|---|---|"]
        for r in li["illegal_json"]:
            L.append(f"| {r['case']} | {'refused' if r['refused'] else 'ACCEPTED'} | {r['message']} |")
        (R / "lint.md").write_text("\n".join(L) + "\n")
    if mu:
        k = sum(1 for r in mu if r["killed"])
        (R / "mutation.md").write_text(simple_md(
            f"Mutation testing — {k}/{len(mu)} killed", mu,
            [("Id", lambda r: r["id"]), ("Mutation", lambda r: r["desc"]), ("Config", lambda r: r.get("config", "")),
             ("Status", lambda r: r["status"]),
             ("Killed by", lambda r: "; ".join(f"{x['scenario']}: {x['evidence'][:90]}" for x in r.get("killed_by", [])[:1]))],
            "One-line changes to the new RTL, each rebuilt and run through the scenarios most likely to expose it."))
    if ph:
        L = ["# Physical placement checks", "",
             f"Scaling gate: {ph['gate']} — `sg_hier` is placed only when `sg_min4`'s regression and placements are clean.", "",
             "| Config | Strategy | Macros | Violations | Min spacing | Mock OpenDB | Weighted distance (estimate) |",
             "|---|---|---|---|---|---|---|"]
        for c in ph["configs"]:
            for s, v in c["strategies"].items():
                L.append(f"| {c['config']} | {s} | {v['macros']} | {v['violations']} | {v['min_spacing_um']} µm | "
                         f"{v['mock_odb']} | {v['weighted_mean_mm']} mm |")
        for c in ph["configs"]:
            L += ["", f"Checker self-test on `{c['config']}`: {sum(x['caught'] for x in c['selftest'])}/{len(c['selftest'])} "
                  "mutations caught:", ""] + [f"* {x['mutation']} → {', '.join(x['rules'])} {'(caught)' if x['caught'] else '(MISSED)'}"
                                            for x in c["selftest"]]
        (R / "physical.md").write_text("\n".join(L) + "\n")
    # summary
    S = ["# SRAMGRID — results summary (generated from reports/*.json)", ""]
    if reg:
        S.append(f"* Simulation regression: **{reg['summary']['pass']}/{reg['summary']['jobs']}** runs, "
                 f"{reg['summary']['checks']:,} checks; cross-simulation identical "
                 f"{sum(c['identical'] for c in reg['cross_sim'])}/{len(reg['cross_sim'])}.")
    if wr:
        S.append(f"* Macro wrapper vs vendor models: **{sum(r['result'] == 'PASS' for r in wr)}/{len(wr)}**.")
    if li:
        s = li["summary"]
        S.append(f"* Lint: legal {s['legal_ok']}/{s['legal']} clean; illegal RTL parameter sets refused "
                 f"{s['illegal_refused']}/{s['illegal']} (Verilator + Icarus + Yosys); illegal JSON refused {s['json_refused']}/{s['json']}.")
    if mu:
        S.append(f"* Mutation testing: **{sum(1 for r in mu if r['killed'])}/{len(mu)}** killed.")
    if sy:
        S.append(f"* Synthesis: {sum(1 for r in sy['results'] if r.get('ok'))}/{len(sy['results'])} targets meet their exact expectation.")
    if ph:
        S.append(f"* Placement: {sum(1 for c in ph['configs'] for v in c['strategies'].values() if v['check_ok'])}/"
                 f"{sum(len(c['strategies']) for c in ph['configs'])} placements clean; gate {'open' if ph['gate']['open'] else 'CLOSED'}.")
    if ar:
        for n, o in ar.items():
            t = o["totals"]
            S.append(f"* `{n}`: {t['logical_bits'] // 8192} KiB logical, {t['macros']} IHP macros = {t['macro_area_mm2']} mm² "
                     f"(real LEF), grid logic {t['logic_stdcell_mm2']} mm² (IHP cells, unplaced).")
    for n in ("sg_min4", "sg_hier"):
        c = load(f"connectivity_{n}.json")
        if c:
            S.append(f"* Macro connectivity `{n}`: {c['macros']} macros, {len(c['anomalies'])} anomalies.")
    (R / "SUMMARY.md").write_text("\n".join(S) + "\n")
    print("\n".join(S))


if __name__ == "__main__":
    main()
