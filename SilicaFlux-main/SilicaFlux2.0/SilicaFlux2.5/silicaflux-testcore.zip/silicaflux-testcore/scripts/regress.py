#!/usr/bin/env python3
"""Full TestCore regression: generated-file check, lint, synthesis, all SV testbenches,
Python tests (incl. RTL vector replay), DFT screens, LBIST evaluation, ATPG collateral.

Writes logs/<step>.log and docs/generated/regression_results.md.
Usage: python3 scripts/regress.py [--quick]   (--quick skips the RTL replay pytest cases)
"""
from __future__ import annotations

import argparse
import datetime as dt
import os
import re
import shutil
import subprocess
import sys
import time

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SV_TBS = ["tb_tap_fsm", "tb_tap_bsr", "tb_mbist", "tb_rst_clk", "tb_mode_sec", "tb_dft_iso", "tb_debug"]


def run(name, cmd, cwd=ROOT, timeout=3600):
    os.makedirs(os.path.join(ROOT, "logs"), exist_ok=True)
    t0 = time.time()
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout, shell=isinstance(cmd, str))
    out = r.stdout + r.stderr
    open(os.path.join(ROOT, "logs", f"{name}.log"), "w").write(out)
    return r.returncode == 0, out, time.time() - t0


def tool_versions():
    v = {}
    for tool, args in (("iverilog", ["-V"]), ("verilator", ["--version"]), ("yosys", ["-V"]),
                       ("python3", ["--version"])):
        try:
            o = subprocess.run([tool] + args, capture_output=True, text=True).stdout.splitlines()[0]
            v[tool] = o.strip()
        except Exception:  # noqa: BLE001
            v[tool] = "not found"
    return v


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    args = ap.parse_args()
    rtl = [l.strip() for l in open(os.path.join(ROOT, "rtl", "rtl_files.f")) if l.strip()]
    rows = []

    ok, out, t = run("gen_check", [sys.executable, "scripts/gen_spec.py", "--check"])
    rows.append(("Generated files match spec", "scripts/gen_spec.py --check", ok, out.strip().splitlines()[-1], t))

    ok, out, t = run("traceability", [sys.executable, "scripts/gen_traceability.py"])
    rows.append(("Traceability matrix rendered", "scripts/gen_traceability.py", ok, out.strip(), t))

    ok, out, t = run("lint", ["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "-Wno-PINCONNECTEMPTY",
                              "--top-module", "tc_top"] + rtl)
    rows.append(("Verilator -Wall lint (tc_top)", "verilator --lint-only -Wall", ok,
                 "0 warnings" if ok else "see logs/lint.log", t))

    prep = os.path.join(ROOT, "build", "yrtl")
    r = subprocess.run([sys.executable, "scripts/yosys_prep.py", prep] + rtl, cwd=ROOT, capture_output=True, text=True)
    ok, out, t = run("synth", ["yosys", "-p", f"read_verilog -sv {r.stdout.strip()}; synth -top tc_top -flatten; check; stat"])
    last = out[out.rfind("Printing statistics"):]          # the explicit final `stat` only
    cells = re.findall(r"Number of cells:\s+(\d+)", last)
    probs = re.findall(r"Found and reported (\d+) problems", out)
    latches = sum(int(x) for x in re.findall(r"\$_DLATCH_\w+\s+(\d+)", last))
    ffs = sum(int(x) for x in re.findall(r"\$_(?:S?DFF\w*|DFFE\w*)\s+(\d+)", last))
    ok = ok and all(p == "0" for p in probs)
    rows.append(("Yosys generic synthesis (tc_top, 2-memory default)", "yosys synth -flatten; check", ok,
                 f"{cells[-1] if cells else '?'} cells, {ffs} flops, {latches} latch (ICG), check problems: {probs[-1] if probs else '?'}", t))

    for tb in SV_TBS:
        ok, out, t = run(f"sv_{tb}", ["scripts/run_sv.sh", tb])
        m = re.search(rf"{tb}: (PASS|FAIL) \(([^)]*)\)", out)
        rows.append((f"SV testbench {tb}", f"scripts/run_sv.sh {tb}", ok, m.group(0) if m else "no result line", t))

    pytest_args = [sys.executable, "-m", "pytest", "-q", "tests"]
    if args.quick:
        pytest_args += ["--deselect", "tests/test_rtl_replay.py"]
    ok, out, t = run("pytest", pytest_args, cwd=os.path.join(ROOT, "python"))
    m = re.findall(r"(\d+ passed[^\n]*)", out)
    rows.append(("Python tests" + (" (no RTL replay)" if args.quick else " incl. RTL vector replay"),
                 "pytest python/tests", ok, m[-1] if m else out.strip().splitlines()[-1], t))

    ok, out, t = run("scan_testcore", [sys.executable, "dft/scan/scan_readiness.py", "--config",
                                       "dft/scan/scan_config_testcore.json", "--out", "build/dft"])
    rows.append(("Scan readiness: TestCore", "dft/scan/scan_readiness.py", ok, out.strip().splitlines()[-1].split(" -> ")[0], t))
    if os.path.exists(os.path.join(ROOT, "..", "RISC-V CPU.zip")):
        ok2, out, t = run("scan_rv32i", ["dft/scan/run_rv32i_check.sh"])
        rows.append(("Scan readiness screen ran on SilicaFlux-V RV32I core (finding: NOT READY)",
                     "dft/scan/run_rv32i_check.sh", ok2, out.strip().splitlines()[-1].split(" -> ")[0], t))

    for name in ("testcore_demo", "silicaflux_v_rv32i_core"):
        src = os.path.join(ROOT, "build", "dft", name, "scan_readiness.md")
        if os.path.exists(src):
            shutil.copy(src, os.path.join(ROOT, "docs", "generated", f"scan_readiness_{name}.md"))

    ok, out, t = run("lbist_eval", [sys.executable, "dft/lbist/lbist_eval.py", "--patterns", "4096"])
    rows.append(("LBIST fault-simulation evaluation", "dft/lbist/lbist_eval.py", ok,
                 out.strip().splitlines()[-1][:160], t))

    ok, out, t = run("atpg_collateral", [sys.executable, "dft/atpg/gen_atpg_collateral.py"])
    rows.append(("ATPG collateral generation (examples)", "dft/atpg/gen_atpg_collateral.py", ok, out.strip()[:120], t))
    ok, out, t = run("replay_scan_entry", ["scripts/run_sv.sh", "tb_vector_replay",
                                           "+vec=dft/atpg/generated/enter_scan_test.vec"])
    m = re.search(r"replayed .*mismatches", out)
    rows.append(("SCAN_TEST entry sequence replayed on RTL", "tb_vector_replay", ok, m.group(0) if m else "?", t))

    allok = all(r[2] for r in rows)
    v = tool_versions()
    L = ["<!-- GENERATED by scripts/regress.py -- DO NOT EDIT -->", "",
         f"# Regression results ({dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%d %H:%M UTC')})", "",
         "Tools: " + "; ".join(f"{k}: {v[k]}" for k in v), "",
         f"**Overall: {'PASS' if allok else 'FAIL'}** ({sum(r[2] for r in rows)}/{len(rows)} steps)", "",
         "| Step | Command | Result | Detail | Time (s) |", "|---|---|---|---|---|"]
    for name, cmd, ok, detail, t in rows:
        L.append(f"| {name} | `{cmd}` | {'PASS' if ok else 'FAIL'} | {detail} | {t:.1f} |")
    os.makedirs(os.path.join(ROOT, "docs", "generated"), exist_ok=True)
    open(os.path.join(ROOT, "docs", "generated", "regression_results.md"), "w").write("\n".join(L) + "\n")
    print("\n".join(L))
    return 0 if allok else 1


if __name__ == "__main__":
    sys.exit(main())
