#!/usr/bin/env python3
"""Prepare SystemVerilog RTL for Yosys 0.33.

Yosys' built-in SystemVerilog frontend (0.33) parses packages and scoped
references (pkg::NAME) but not `import pkg::*;` (file scope or module header).
Commercial synthesis, Icarus and Verilator read rtl/ directly; only the
open-source Yosys checks (synthesis sanity, scan readiness, LBIST fault
simulation) use this mechanical rewrite:

  * detect every `package NAME;` in the file list
  * remove `import NAME::*;` statements
  * rewrite identifiers declared in those packages (localparams, typedefs,
    enum literals, functions) to `NAME::IDENT`

Usage: yosys_prep.py OUTDIR file.sv [file.sv ...]   -> prints rewritten paths
"""
from __future__ import annotations

import os
import re
import sys

_PKG = re.compile(r"^\s*package\s+(\w+)\s*;", re.M)
_DECL_LP = re.compile(r"\b(?:localparam|parameter)\b([^;]*);", re.S)
_DECL_FN = re.compile(r"function\s+(?:automatic\s+)?(?:logic\s*|bit\s*|int\s*)?(?:\[[^\]]*\]\s*)?(\w+)\s*\(")
_TYPEDEF = re.compile(r"typedef\b[^;]*?\}\s*(\w+)\s*;|typedef\s+[^;{}]*?\s(\w+)\s*;", re.S)
_ENUM = re.compile(r"enum\b[^{]*\{([^}]*)\}", re.S)


def package_bodies(text: str):
    for m in _PKG.finditer(text):
        name = m.group(1)
        end = text.find("endpackage", m.end())
        yield name, text[m.end():end]


def package_names(body: str) -> set:
    body = re.sub(r"//.*", "", body)
    body = re.sub(r"/\*.*?\*/", "", body, flags=re.S)
    names = set()
    for m in _DECL_LP.finditer(body):
        decl = re.sub(r"\[[^\]]*\]", "", m.group(1))
        decl = re.sub(r"^\s*(logic|int|bit|integer|real)\b", "", decl.strip())
        depth = 0
        part = ""
        for ch in decl + ",":
            if ch in "({":
                depth += 1
            elif ch in ")}":
                depth -= 1
            if ch == "," and depth == 0:
                if "=" in part:
                    lhs = part.split("=")[0].strip().split()
                    if lhs:
                        names.add(lhs[-1])
                part = ""
            else:
                part += ch
    names.update(_DECL_FN.findall(body))
    for a, b in _TYPEDEF.findall(body):
        names.add(a or b)
    for m in _ENUM.finditer(body):
        for lit in m.group(1).split(","):
            lit = lit.split("=")[0].strip()
            if re.match(r"^\w+$", lit):
                names.add(lit)
    names.discard("")
    return names


def main(argv) -> int:
    outdir, files = argv[1], argv[2:]
    os.makedirs(outdir, exist_ok=True)
    owner = {}
    pkgs = set()
    for f in files:
        text = open(f, encoding="utf-8").read()
        for pname, body in package_bodies(text):
            pkgs.add(pname)
            for n in package_names(body):
                owner.setdefault(n, pname)
    imp = re.compile(r"\bimport\s+(?:%s)::\*\s*;" % "|".join(map(re.escape, pkgs))) if pkgs else None
    ident = (re.compile(r"(?<![:\w`$.'])(" + "|".join(sorted(map(re.escape, owner), key=len, reverse=True)) + r")\b(?!\s*::)")
             if owner else None)
    out = []
    for f in files:
        text = open(f, encoding="utf-8").read()
        is_pkg = bool(_PKG.search(text))
        if imp is not None:
            text = imp.sub("", text)
        if ident is not None and not is_pkg:
            text = ident.sub(lambda m: f"{owner[m.group(1)]}::{m.group(1)}", text)
        dst = os.path.join(outdir, os.path.basename(f))
        with open(dst, "w", encoding="utf-8") as fh:
            fh.write(text)
        out.append(dst)
    print(" ".join(out))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
