#!/usr/bin/env bash
# Compile and run one SystemVerilog testbench with Icarus Verilog.
#   scripts/run_sv.sh <tb_name> [vvp plusargs...]
# Exit status: 0 if the testbench prints "<tb_name>: PASS", 1 otherwise.
set -euo pipefail
cd "$(dirname "$0")/.."
TB="$1"; shift || true
mkdir -p build logs
VVP="build/${TB}.vvp"
# never run a stale binary if compilation fails
rm -f -- "${VVP}"
SRCS="$(cat rtl/rtl_files.f) rtl/demo/tc_lbist_demo_alu.sv tb/models/tc_sram_model.sv tb/models/tc_core_model.sv tb/models/tc_demo_soc.sv tb/${TB}.sv"
# Icarus prints a 'sorry: constant selects in always_*' note for sensitivity
# lists; it is informational (whole vector becomes sensitive) and filtered here.
iverilog -g2012 -Wall -Wno-timescale -Wno-implicit-dimensions -Wno-portbind -Wno-sensitivity-entire-vector -Wno-sensitivity-entire-array \
  -I tb -I tb/models -o "${VVP}" -s "${TB}" ${SRCS} 2>&1 \
  | grep -v -E "sorry: constant selects|Static variable initialization requires explicit lifetime" || true
[ -f "${VVP}" ] || { echo "${TB}: COMPILE FAILED"; exit 1; }
vvp -n "${VVP}" "$@" | tee "logs/${TB}.log"
grep -q "^${TB}: PASS" "logs/${TB}.log"
