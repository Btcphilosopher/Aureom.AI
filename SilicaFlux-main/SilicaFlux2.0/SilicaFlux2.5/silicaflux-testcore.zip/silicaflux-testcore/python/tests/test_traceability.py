"""Every design/evidence path referenced by the traceability matrix must exist."""
import csv
import os

from conftest import ROOT

GENERATED_AT_RUNTIME = ("logs/", "build/")


def test_traceability_paths_exist():
    rows = list(csv.DictReader(open(os.path.join(ROOT, "spec", "dft_requirements.csv"))))
    assert len(rows) >= 50
    missing = []
    for r in rows:
        for p in (r["design"] + ";" + r["evidence"]).split(";"):
            p = p.split(" (")[0].strip()
            if not p or p.startswith(GENERATED_AT_RUNTIME):
                continue
            if not os.path.exists(os.path.join(ROOT, p)):
                missing.append((r["id"], p))
    assert not missing, missing


def test_every_brief_section_covered():
    rows = list(csv.DictReader(open(os.path.join(ROOT, "spec", "dft_requirements.csv"))))
    sections = {r["id"].split(".")[0] for r in rows}
    assert sections == {f"R{i}" for i in range(1, 11)}
