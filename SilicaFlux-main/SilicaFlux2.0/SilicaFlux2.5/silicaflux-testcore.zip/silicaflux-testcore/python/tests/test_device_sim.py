"""Host software against the simulation transport: TAP, registers, security, modes, MBIST, debug."""
import pytest

from conftest import make_dev
from sftestcore.debug import Debug, Lbist
from sftestcore.device import AccessDenied
from sftestcore.flows import _enter, _leave
from sftestcore.mbist import Mbist
from sftestcore.models import Fault, F_SA0, F_SA1, F_TF_DOWN, F_COL_SA0, rom_signature


def test_idcode_identity(dev, spec):
    d, _ = dev
    idc = d.idcode()
    assert idc.raw == spec.idcode(1) and idc.valid
    ident = d.identity()
    assert ident["silicon_rev"] == "1.0.0"
    assert ident["ecid"] == "0x5F1A202600010042"
    assert ident["manufacturer_placeholder"] is True


def test_status_and_ir_capture(dev, spec):
    d, _ = dev
    assert d.load_ir("BYPASS", force=True) & 3 == 1
    st = d.status()
    assert st["MARKER"] == spec.status_marker and st["MODE"] == 0 and st["LC_STATE"] == 0


def test_register_access_and_denials(dev):
    d, tgt = dev
    d.write("SCRATCH", 0xDEADBEEF)
    assert d.read("SCRATCH") == 0xDEADBEEF
    with pytest.raises(AccessDenied):
        d.write("MBIST_CTRL", 1)                 # outside MEMORY_BIST
    with pytest.raises(AccessDenied):
        d.read("DBG_PC")                         # outside DIAGNOSTIC
    with pytest.raises(AccessDenied):
        d.write("TC_MAGIC", 0)                   # read-only
    with pytest.raises(AccessDenied):
        d.read(0x7F0)                            # unmapped
    assert d.fields("SEC_STATUS")["DENIED_CNT"] == 4


def test_busy_recovery_with_slow_bridge():
    d, tgt = make_dev(reg_latency_tck=40)
    d.reg_idle = 2                               # deliberately too short
    d.write("SCRATCH", 0x1234)
    assert d.read("SCRATCH") == 0x1234
    assert d.busy_events > 0                     # BUSY seen, CLEAR_BUSY recovery exercised


def test_mode_permissions_unlock_and_lockout(spec):
    d, tgt = make_dev(lc_otp=0xC3)               # PROD
    st = d.mode_request("MEMORY_BIST")
    assert st["MODE"] == 0 and st["LAST_ERR"] == spec.mode_errors["DENIED"]
    for k in range(1, 4):
        st = d.unlock(0x1111 * k)
        assert st["ATTEMPTS"] == k and not st["LOCKOUT"]
    st = d.unlock(0x9999)
    assert st["LOCKOUT"] == 1
    st = d.unlock(tgt.unlock_key)
    assert st["UNLOCKED"] == 0                   # ignored while locked out
    d.reset(trst=True)
    assert d.status()["LOCKOUT"] == 1            # persists across TRST*
    tgt.power_on()
    d.reset()
    st = d.unlock(tgt.unlock_key)
    assert st["UNLOCKED"] == 1
    assert d.mode_request("MEMORY_BIST")["MODE"] == spec.modes["MEMORY_BIST"]
    st = d.mode_request("DIAGNOSTIC")            # test -> test
    assert st["LAST_ERR"] == spec.mode_errors["ILLEGAL"]
    d.mode_request("NORMAL")
    st = d.mode_request("SCAN_TEST")
    assert st["LAST_ERR"] == spec.mode_errors["DENIED"]   # PROD: scan never


def test_tlr_and_extest_force_exit(dev, spec):
    d, tgt = dev
    d.enter_mode("DIAGNOSTIC")
    d.reset()                                    # TMS-driven TLR
    assert d.status()["MODE"] == 0
    d.enter_mode("MEMORY_BIST")
    d.load_ir("EXTEST")
    d.idle(4)
    assert tgt.cur_mode == spec.modes["JTAG"]
    st = d.status()
    assert st["LAST_ERR"] == spec.mode_errors["ABORTED"] and st["MODE"] == 0


def _mbist(d, tgt, **kw):
    _enter(d, "MEMORY_BIST", None)
    mb = Mbist(d, [m.name for m in tgt.mems])
    res = mb.run(**kw)
    _leave(d)
    return res


def test_mbist_clean_and_rom_signature(dev):
    d, tgt = dev
    sig = rom_signature(64, 32)
    res = _mbist(d, tgt, rom_signature=sig)
    assert res.passed and not res.failures and res.rom_signature == sig


def test_mbist_stuck_at_logged_exactly():
    d, tgt = make_dev(faults={2: Fault(F_SA1, 300, 70)})
    res = _mbist(d, tgt, memories=[0, 1, 2, 3])
    assert not res.passed and res.failing_memories == [2] and res.fail_count == 3
    f = res.failures[0]
    assert (f.memory, f.memory_name, f.element, f.op_index, f.address) == (2, "L2_BANK0", 1, 0, 300)
    assert f.failing_bits == [70]


def test_mbist_algorithm_coverage_difference():
    d, tgt = make_dev()
    _mbist(d, tgt, memories=[0])                              # fault-free run leaves all cells 0
    tgt.mem_models[0].fault = Fault(F_TF_DOWN, 255, 31)       # 1->0 transition fault appears
    assert _mbist(d, tgt, algorithm="MATS_PLUS", memories=[0]).passed     # MATS+ misses TF-down
    assert not _mbist(d, tgt, algorithm="MARCH_C_MINUS", memories=[0]).passed


def test_mbist_column_fault_overflow_and_bitmap():
    d, tgt = make_dev(faults={1: Fault(F_COL_SA0, 0, 4)})
    res = _mbist(d, tgt, memories=[1])
    assert res.fail_count == 512 and res.log_overflow and len(res.failures) == 8
    assert res.failing_bit_map == 1 << 4


def test_mbist_refuses_empty_selection(dev):
    d, tgt = dev
    _enter(d, "MEMORY_BIST", None)
    with pytest.raises(ValueError):
        Mbist(d).run(memories=[])


def test_lbist_pass(dev):
    d, tgt = dev
    _enter(d, "LOGIC_TEST", None)
    res = Lbist(d).run(patterns=300)
    _leave(d)
    assert res["passed"] and res["signature"] == res["golden"]


def test_debug_halt_step_registers(dev):
    d, tgt = dev
    _enter(d, "DIAGNOSTIC", None)
    dbg = Debug(d)
    dbg.halt()
    pc = dbg.pc()
    dbg.write_reg(7, 0x55AA55AA)
    assert dbg.read_reg(7) == 0x55AA55AA
    dbg.write_reg(0, 0x1)
    assert dbg.read_reg(0) == 0
    dbg.step()
    assert dbg.pc() == pc + 4
    dbg.resume()
    assert dbg.status()["RUNNING"] == 1
    _leave(d)
    assert "POR" in dbg.reset_cause()
