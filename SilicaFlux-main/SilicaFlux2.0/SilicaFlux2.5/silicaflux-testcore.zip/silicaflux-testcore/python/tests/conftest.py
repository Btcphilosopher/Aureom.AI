import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "python"))

import pytest  # noqa: E402

from sftestcore.device import TestCoreDevice  # noqa: E402
from sftestcore.jtag import BitBangJtag  # noqa: E402
from sftestcore.spec import load_spec  # noqa: E402
from sftestcore.transports.sim import SimTransport  # noqa: E402


@pytest.fixture
def spec():
    return load_spec()


def make_dev(**kw):
    t = SimTransport(**kw)
    dev = TestCoreDevice(BitBangJtag(t))
    dev.reset()
    return dev, t.target


@pytest.fixture
def dev():
    return make_dev()
