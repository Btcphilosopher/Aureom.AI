"""DFT tooling: ATPG coverage gate (synthetic inputs only -- no ATPG results exist)."""
import os
import sys

from conftest import ROOT

sys.path.insert(0, os.path.join(ROOT, "dft", "atpg"))
import coverage_gate as cg  # noqa: E402

TARGETS = {"stuck_at": 99.0, "transition": 95.0}


def test_coverage_math_and_gate():
    s = {"fault_models": {"stuck_at": {"total": 10000, "detected": 9890, "untestable": 20, "possibly_detected": 20},
                          "transition": {"total": 10000, "detected": 9400, "untestable": 50}}}
    ok, rows = cg.gate(s, TARGETS)
    r = {x["model"]: x for x in rows}
    assert r["stuck_at"]["test_coverage"] == round(100 * 9900 / 9980, 3)     # PD credited at 50 %
    assert r["stuck_at"]["result"] == "PASS"                                  # 99.198 % >= 99 %
    assert r["transition"]["result"] == "FAIL"
    assert not ok


def test_gate_passes_when_targets_met():
    s = {"fault_models": {"stuck_at": {"total": 1000, "detected": 995, "untestable": 2}}}
    ok, rows = cg.gate(s, TARGETS)
    assert ok and rows[0]["result"] == "PASS"


def test_report_parser():
    text = "Fault model: stuck\n  test coverage   99.21%\n  fault coverage  98.70%\nFault type = transition\ntest coverage: 93.40 %\n"
    p = cg.parse_report(text)
    assert p == {"stuck_at": {"test_coverage": 99.21, "fault_coverage": 98.70}, "transition": {"test_coverage": 93.40}}
    ok, _ = cg.gate({"fault_models": p}, TARGETS)
    assert not ok
