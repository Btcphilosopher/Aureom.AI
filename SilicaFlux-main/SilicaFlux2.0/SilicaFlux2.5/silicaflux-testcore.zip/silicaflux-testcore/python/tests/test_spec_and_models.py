"""Spec consistency, generated-file freshness, JTAG model and golden-model properties."""
import itertools
import os
import subprocess
import sys

from conftest import ROOT
from sftestcore import jtag as J
from sftestcore.bsdl import bsr_cells, generate_bsdl
from sftestcore.models import (lbist_signature, lfsr_step, misr_step, phase_shift, demo_alu, fold32,
                               rom_signature, rom_word, M32)
from sftestcore.spec import decode_march_element, encode_march_element, march_complexity


def test_generated_files_up_to_date():
    r = subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "gen_spec.py"), "--check"],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr


def test_unique_opcodes_and_mandatory_encodings(spec):
    codes = list(spec.instructions.values())
    assert len(codes) == len(set(codes))
    assert spec.instructions["BYPASS"] == (1 << spec.ir_length) - 1          # all ones (1149.1)
    assert spec.instructions["EXTEST"] == 0                                    # 1149.1-2001 convention
    assert spec.ir_capture & 3 == 1                                            # LSBs 01
    assert spec.idcode() & 1 == 1
    assert spec.idcode_mfg != 0x7F                                             # forbidden code


def test_register_offsets_unique_and_aligned(spec):
    offs = [r.offset for r in spec.registers.values()]
    assert len(offs) == len(set(offs))
    assert all(o % 4 == 0 and o < 4096 for o in offs)
    for r in spec.registers.values():
        bits = set()
        for f in r.fields:
            rng = set(range(f.lsb, f.lsb + f.width))
            assert not (bits & rng), f"{r.name}.{f.name} overlaps"
            assert max(rng) < 32
            bits |= rng


def test_permission_matrix_matches_independent_table(spec):
    # independent restatement of docs/09_test_modes.md
    lc = {"TEST": 0, "DEV": 1, "PROD": 2, "RMA": 3, "INVALID": 7}

    def ref(l, u, m):
        if m in ("MEMORY_BIST", "LOGIC_TEST", "DIAGNOSTIC"):
            return l in ("TEST", "DEV") or (l in ("PROD", "RMA") and u)
        if m == "SCAN_TEST":
            return l == "TEST" or (l in ("DEV", "RMA") and u)
        return m == "NORMAL"
    for l, u, m in itertools.product(lc, (False, True), ("NORMAL", "MEMORY_BIST", "LOGIC_TEST", "SCAN_TEST", "DIAGNOSTIC")):
        assert spec.mode_permitted(lc[l], u, spec.modes[m]) == ref(l, u, m), (l, u, m)
    assert spec.mode_permitted(2, True, spec.modes["SCAN_TEST"]) is False     # PROD: scan never


def test_lifecycle_decode_fail_secure(spec):
    assert spec.decode_lifecycle(0x00) == 0
    assert spec.decode_lifecycle(0xC3) == 2
    for code in (0x01, 0xFF, 0x3C, 0x5B):
        assert spec.decode_lifecycle(code) == 7


def test_march_encoding_roundtrip_and_complexity(spec):
    for e in ("U(w0)", "D(r1,w0,w1,w0)", "U(r0,r0,w0,r0,w1)", "U(r0,w1,r1,w0,r0,w1)"):
        k, d, ops = decode_march_element(encode_march_element(e))
        assert k == 1 and d == (e[0] == "D") and len(ops) == e.count(",") + 1
    expect = {"MARCH_C_MINUS": 10, "MATS_PLUS": 5, "MARCH_X": 6, "MARCH_B": 17, "MARCH_SS": 22}
    for name, n in expect.items():
        assert march_complexity(spec.algorithms[name]["elements"]) == n
        assert spec.algorithms[name]["complexity"] == f"{n}N"


def test_bsr_cell_order_and_bsdl(spec):
    cells = bsr_cells(spec)
    assert [c.index for c in sorted(cells, key=lambda c: c.index)] == list(range(len(cells)))
    assert len(cells) == 3 + 2 * 4 + 3 * 8
    for c in cells:
        if c.function == "output3":
            ctl = next(x for x in cells if x.index == c.ccell)
            assert ctl.function == "control"
    text = generate_bsdl(spec)
    assert f"BOUNDARY_LENGTH of silicaflux_v : entity is {len(cells)};" in text
    assert 'INSTRUCTION_CAPTURE of silicaflux_v : entity is "00001"' in text
    assert "PLACEHOLDER" in text


def test_tap_model_transitions_and_paths():
    ref = {J.TLR: (J.RTI, J.TLR), J.SEL_IR: (J.CAPT_IR, J.TLR), J.UPDATE_DR: (J.RTI, J.SEL_DR)}
    for s, (n0, n1) in ref.items():
        assert J.tap_next(s, 0) == n0 and J.tap_next(s, 1) == n1
    states = list(J.STATE_NAMES)
    for s in states:                                  # TMS=1 x5 reaches TLR from anywhere
        x = s
        for _ in range(5):
            x = J.tap_next(x, 1)
        assert x == J.TLR
    for a, b in itertools.product(states, states):    # BFS paths are valid
        x = a
        for t in J.tms_path(a, b):
            x = J.tap_next(x, t)
        assert x == b


def test_lfsr_misr_properties():
    s, seen = 1, set()
    for _ in range(5000):
        s = lfsr_step(s)
        assert s != 0 and s not in seen
        seen.add(s)
    # MISR is linear over GF(2): sig(a ^ b) == sig(a) ^ sig(b) from a zero state
    a = [0x12345678, 0x0, 0xFFFFFFFF, 0xA5A5A5A5]
    b = [0x0BADF00D, 0x1, 0x7, 0x5A5A5A5A]

    def sig(seq):
        m = 0
        for x in seq:
            m = misr_step(m, x)
        return m
    assert sig([x ^ y for x, y in zip(a, b)]) == sig(a) ^ sig(b)


def test_phase_shifter_taps_distinct():
    for i in range(68):
        taps = {i % 32, (5 * i + 3) % 32, (13 * i + 7) % 32}
        assert len(taps) == 3
    assert phase_shift(1, 68) != 0


def test_demo_alu_reference_points():
    assert demo_alu(5, 7, 0) == 12
    assert demo_alu(5, 7, 1) == (5 - 7) & M32
    assert demo_alu(0x80000000, 4, 7) == 0xF8000000
    assert demo_alu(0xFFFFFFFF, 1, 8) == 1                       # signed -1 < 1
    assert demo_alu(0xFFFFFFFF, 1, 9) == 1 << 32                # unsigned: false -> y=0, zero flag
    assert demo_alu(3, 3, 4) == (1 << 32)                        # zero flag
    assert fold32(1 << 32, 33) == 1


def test_lbist_signature_deterministic_and_seed_sensitive():
    a = lbist_signature(0xACE12026, 200)
    assert a == lbist_signature(0xACE12026, 200)
    assert a != lbist_signature(0xACE12027, 200)
    assert lbist_signature(0, 50) == lbist_signature(1, 50)      # seed 0 replaced by 1 (RTL behaviour)


def test_rom_signature_detects_single_bit_change():
    words = [rom_word(a) for a in range(64)]
    good = rom_signature(64, 32, words)
    for a, b in ((0, 0), (7, 2), (63, 31)):
        bad = list(words)
        bad[a] ^= 1 << b
        assert rom_signature(64, 32, bad) != good
