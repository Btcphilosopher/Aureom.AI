"""Production flow, CSV/JSON logs, binning, SVF and adapter transports (no hardware)."""
import csv
import json
import os
import socket
import threading

from conftest import make_dev
from sftestcore.flows import FlowConfig, production_flow
from sftestcore.jtag import BitBangJtag, SvfWriter
from sftestcore.device import TestCoreDevice
from sftestcore.models import Fault, F_SA0
from sftestcore.testlog import TestSession
from sftestcore.transports.ftdi_mpsse import FtdiMpsseTransport
from sftestcore.transports.openocd import OpenOcdJtag
from sftestcore.transports.sim import SimTransport


def _run(tmp_path, faults=None, lc=0x00):
    d, tgt = make_dev(faults=faults or {}, lc_otp=lc)
    sess = TestSession(station="pytest", transport="sim")
    production_flow(d, sess, FlowConfig.for_demo_soc(d.spec))
    sess.write_json(str(tmp_path / "s.json"))
    sess.write_csv(str(tmp_path / "steps.csv"))
    sess.write_failures_csv(str(tmp_path / "fails.csv"))
    return sess


def test_flow_pass_and_logs(tmp_path):
    sess = _run(tmp_path)
    s = sess.summary()
    assert s["result"] == "PASS" and s["soft_bin"] == 1 and s["counts"]["FAIL"] == 0
    data = json.load(open(tmp_path / "s.json"))
    assert data["schema"] == "sftestcore.session/1"
    assert data["device"]["idcode"] == "0x15F10001" and data["device"]["ecid"] == "0x5F1A202600010042"
    rows = list(csv.DictReader(open(tmp_path / "steps.csv")))
    assert len(rows) == len(sess.steps) and all(r["status"] == "PASS" for r in rows)


def test_flow_fail_binning_and_failure_csv(tmp_path):
    sess = _run(tmp_path, faults={0: Fault(F_SA0, 17, 5)})
    s = sess.summary()
    assert s["result"] == "FAIL" and s["soft_bin"] == 5 and s["first_failing_step"] == "mbist_march_c"
    rows = list(csv.DictReader(open(tmp_path / "fails.csv")))
    assert [(r["memory_name"], r["address"], r["failing_bits"]) for r in rows] == [("L1I", "17", "5"), ("L1I", "17", "5")]


def test_flow_prod_lifecycle_uses_unlock(tmp_path):
    sess = _run(tmp_path, lc=0xC3)
    assert sess.summary()["result"] == "PASS"


def test_svf_output(tmp_path):
    p = tmp_path / "x.svf"
    drv = SvfWriter(BitBangJtag(SimTransport()), str(p))
    dev = TestCoreDevice(drv)
    dev.reset()
    dev.load_ir("BYPASS")
    dev.idcode()                                  # IR changes back to IDCODE -> SIR emitted
    drv.close()
    text = p.read_text()
    assert "STATE RESET;" in text and "SIR 5 TDI (02)" in text
    assert "SDR 32 TDI (00000000) TDO (15F10001) MASK (FFFFFFFF);" in text


class FakeFtdi:
    """Byte-level MPSSE fake: answers 0x6B commands with TDO = TDI of the same clock."""

    def __init__(self):
        self.out = bytearray()
        self.rx = bytearray()

    def write_data(self, b):
        self.out += b
        i = 0
        while i < len(b):
            op = b[i]
            if op == 0x6B:
                n, bits = b[i + 1] + 1, b[i + 2]
                tdi = (bits >> 7) & 1
                v = 0
                for j in range(n):
                    v |= tdi << j
                self.rx.append((v << (8 - n)) & 0xFF)   # left-justified like real MPSSE
                i += 3
            elif op in (0x86, 0x80):
                i += 3
            else:
                i += 1

    def read_data_bytes(self, n, attempt=1):
        r, self.rx = bytes(self.rx[:n]), self.rx[n:]
        return r


def test_ftdi_mpsse_encoding_and_loopback():
    cmd, groups = FtdiMpsseTransport.build_commands([1, 1, 0, 0, 1], [0, 0, 0, 0, 0])
    assert cmd == bytes([0x6B, 4, 0b00010011, 0x87]) and groups == [5]
    fake = FakeFtdi()
    t = FtdiMpsseTransport(device=fake, tck_hz=1e6)
    assert fake.out[:3] == bytes([0x8A, 0x97, 0x8D]) and fake.out[3] == 0x86
    tdi = [1, 0, 1, 1, 0, 0, 1, 0, 1, 1]
    out = t.clock([0] * len(tdi), tdi)
    assert out == tdi                                  # fake echoes TDI, checks bit unpacking


def test_openocd_protocol_with_fake_server():
    srv = socket.socket()
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    port = srv.getsockname()[1]
    seen = []

    def serve():
        c, _ = srv.accept()
        buf = b""
        while True:
            data = c.recv(4096)
            if not data:
                break
            buf += data
            while b"\x1a" in buf:
                line, buf = buf.split(b"\x1a", 1)
                cmd = line.decode()
                seen.append(cmd)
                if cmd.startswith("drscan"):
                    parts = cmd.split()
                    vals = [parts[i] for i in range(3, len(parts) - 2, 2)]
                    resp = " ".join(f"{int(v, 16):08x}" for v in vals)
                else:
                    resp = ""
                c.sendall(resp.encode() + b"\x1a")
        c.close()
    th = threading.Thread(target=serve, daemon=True)
    th.start()
    j = OpenOcdJtag(port=port)
    v = (0x2 << 44) | (0x034 << 32) | 0xDEADBEEF
    assert j.dr_scan(v, 46) == v                       # 46 bits split into 32 + 14 and reassembled
    j.ir_scan(0x0B, 5)
    j.idle(8)
    j.close()
    th.join(timeout=2)
    assert seen[0] == "drscan sftc.tap 32 0xdeadbeef 14 0x2034 -endstate IDLE"
    assert seen[1] == "irscan sftc.tap 0xb -endstate IDLE" and seen[2] == "runtest 8"
