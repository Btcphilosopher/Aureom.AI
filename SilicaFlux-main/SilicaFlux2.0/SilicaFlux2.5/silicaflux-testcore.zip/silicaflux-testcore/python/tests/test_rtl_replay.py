"""Host flow vs RTL: record TCK vectors on the simulator, replay against the RTL (Icarus).

Skipped when Icarus Verilog is not installed.  Each case runs the complete
production flow, so this is the slowest test (~1-3 min per case).
"""
import os
import shutil
import subprocess

import pytest

from conftest import ROOT
from sftestcore.device import TestCoreDevice
from sftestcore.flows import FlowConfig, production_flow
from sftestcore.jtag import BitBangJtag
from sftestcore.models import Fault, F_SA1
from sftestcore.testlog import TestSession
from sftestcore.transports.recorder import VectorRecorder
from sftestcore.transports.sim import SimTransport

pytestmark = pytest.mark.skipif(shutil.which("iverilog") is None, reason="Icarus Verilog not installed")

CASES = {
    "pass": dict(lc=0x00, faults={}, extended=False),
    "prod_unlock": dict(lc=0xC3, faults={}, extended=False),
    "l2_sa1": dict(lc=0x00, faults={2: Fault(F_SA1, 300, 70)}, extended=True),
}


@pytest.mark.parametrize("name", list(CASES))
def test_flow_replays_on_rtl(name, tmp_path):
    c = CASES[name]
    vec = tmp_path / f"{name}.vec"
    rec = VectorRecorder(SimTransport(lc_otp=c["lc"], faults=c["faults"]), str(vec))
    dev = TestCoreDevice(BitBangJtag(rec))
    sess = TestSession(transport="sim+recorder")
    production_flow(dev, sess, FlowConfig.for_demo_soc(dev.spec, extended_mbist=c["extended"]))
    rec.close()
    expect_pass = not c["faults"]
    assert (sess.summary()["result"] == "PASS") == expect_pass
    plus = [f"+vec={vec}", f"+lc_otp={c['lc']:02x}"]
    for m, f in c["faults"].items():
        plus += f.plusargs(m)
    r = subprocess.run([os.path.join(ROOT, "scripts", "run_sv.sh"), "tb_vector_replay"] + plus,
                       cwd=ROOT, capture_output=True, text=True, timeout=1800)
    tail = "\n".join(r.stdout.splitlines()[-12:])
    assert r.returncode == 0 and "0 mismatches" in r.stdout, tail
