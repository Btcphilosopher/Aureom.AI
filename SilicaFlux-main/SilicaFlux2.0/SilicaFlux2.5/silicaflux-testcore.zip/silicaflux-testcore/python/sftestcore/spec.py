"""Single-source TestCore specification loader.

`spec/testcore_spec.json` is the one source of truth for JTAG instruction
encodings, data-register widths, test-mode codes, lifecycle codes, the
register map, access classes, mode permissions and the built-in MBIST
algorithms.  The RTL package `rtl/tc_spec_pkg.sv`, the generated documentation
and the BSDL template are produced from it by `scripts/gen_spec.py`; the host
software reads it directly.  `python/tests/test_spec_consistency.py` fails if
the generated files drift from the JSON.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Dict, List, Optional

_HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_SPEC_PATH = os.environ.get(
    "SFTC_SPEC", os.path.normpath(os.path.join(_HERE, "..", "..", "spec", "testcore_spec.json")))


def _num(v) -> int:
    if isinstance(v, int):
        return v
    if isinstance(v, str):
        return int(v, 0)
    raise TypeError(f"not a number: {v!r}")


@dataclass(frozen=True)
class Field:
    name: str
    lsb: int
    width: int
    desc: str = ""

    @property
    def mask(self) -> int:
        return ((1 << self.width) - 1) << self.lsb

    def get(self, value: int) -> int:
        return (value >> self.lsb) & ((1 << self.width) - 1)

    def put(self, value: int, fv: int) -> int:
        return (value & ~self.mask) | ((fv << self.lsb) & self.mask)


@dataclass(frozen=True)
class Register:
    name: str
    offset: int
    read: str
    write: str
    desc: str
    fields: tuple = field(default_factory=tuple)

    def field(self, name: str) -> Field:
        for f in self.fields:
            if f.name == name:
                return f
        raise KeyError(f"{self.name} has no field {name}")

    def decode(self, value: int) -> Dict[str, int]:
        return {f.name: f.get(value) for f in self.fields}


# --------------------------------------------------------------------------- March

OPS = {"w0": 0, "w1": 1, "r0": 2, "r1": 3}
KIND_END, KIND_MARCH, KIND_PAUSE = 0, 1, 2
_ELEM_RE = re.compile(r"^\s*([UD])\s*\(\s*([rw][01](?:\s*,\s*[rw][01])*)\s*\)\s*$", re.I)


def encode_march_element(text: str) -> int:
    """Encode 'U(r0,w1)' / 'D(r1,w0,w1)' / 'PAUSE' into the 18-bit element word."""
    t = text.strip()
    if t.upper() == "PAUSE":
        return KIND_PAUSE << 16
    m = _ELEM_RE.match(t)
    if not m:
        raise ValueError(f"bad March element: {text!r}")
    down = 1 if m.group(1).upper() == "D" else 0
    ops = [o.strip().lower() for o in m.group(2).split(",")]
    if not 1 <= len(ops) <= 6:
        raise ValueError(f"element must have 1..6 ops: {text!r}")
    word = 0
    for i, o in enumerate(ops):
        word |= OPS[o] << (2 * i)
    return (KIND_MARCH << 16) | (down << 15) | ((len(ops) - 1) << 12) | word


def decode_march_element(word: int):
    """Return (kind, down, [ops]) for an 18-bit element word."""
    kind = (word >> 16) & 3
    down = (word >> 15) & 1
    nops = ((word >> 12) & 7) + 1
    ops = [(word >> (2 * i)) & 3 for i in range(min(nops, 6))]
    return kind, down, ops


def march_complexity(elements: List[int]) -> int:
    """Operations per word (the 'N' multiplier) for an encoded algorithm."""
    n = 0
    for w in elements:
        kind, _, ops = decode_march_element(w)
        if kind == KIND_END:
            break
        if kind == KIND_MARCH:
            n += len(ops)
    return n


# --------------------------------------------------------------------------- Spec

class Spec:
    def __init__(self, raw: dict):
        self.raw = raw
        j = raw["jtag"]
        self.ir_length: int = j["ir_length"]
        self.ir_capture: int = j["ir_capture"]
        self.instructions: Dict[str, int] = {i["name"]: i["code"] for i in j["instructions"]}
        self.instruction_info = {i["name"]: i for i in j["instructions"]}
        self.dr_lengths: Dict[str, int] = dict(j["data_registers"])
        self.idcode_part: int = _num(j["idcode"]["part_number"])
        self.idcode_mfg: int = _num(j["idcode"]["manufacturer_id"])
        self.idcode_version: int = _num(j["idcode"]["default_version"])
        self.idcode_mfg_placeholder: bool = bool(j["idcode"]["manufacturer_is_placeholder"])
        self.mode_magic: int = j["tc_mode_dr"]["magic"]
        self.reg_ops: Dict[str, int] = dict(j["tc_reg_dr"]["ops"])
        self.reg_status: Dict[str, int] = dict(j["tc_reg_dr"]["status"])
        self.reg_min_idle: int = j["tc_reg_dr"]["min_idle_tck"]
        self.status_fields = tuple(Field(f["name"], f["lsb"], f["width"], f.get("desc", ""))
                                   for f in j["tc_status_dr"]["fields"])
        self.status_marker: int = j["tc_status_dr"]["marker"]
        self.unlock_max_attempts: int = j["tc_unlock_dr"]["max_attempts"]
        self.mode_settle_tck: int = j["mode_settle_tck"]

        self.modes: Dict[str, int] = {m["name"]: m["code"] for m in raw["modes"]}
        self.mode_names: Dict[int, str] = {v: k for k, v in self.modes.items()}
        self.mode_errors: Dict[str, int] = {e["name"]: e["code"] for e in raw["mode_errors"]}
        self.mode_error_names: Dict[int, str] = {v: k for k, v in self.mode_errors.items()}
        self.mode_reset_policy = raw["mode_reset_policy"]

        self.lifecycle = {s["name"]: s for s in raw["lifecycle"]["states"]}
        self.lc_decoded_names = {s["decoded"]: s["name"] for s in raw["lifecycle"]["states"]}
        self.mode_permissions = raw["mode_permissions"]

        regs = []
        for r in raw["registers"]:
            flds = tuple(Field(f["name"], f["lsb"], f["width"], f.get("desc", "")) for f in r.get("fields", []))
            regs.append(Register(r["name"], r["offset"], r["read"], r["write"], r["desc"], flds))
        self.registers: Dict[str, Register] = {r.name: r for r in regs}
        self.registers_by_offset: Dict[int, Register] = {r.offset: r for r in regs}
        self.constants = {k: _num(v) for k, v in raw["register_constants"].items()}

        mb = raw["mbist"]
        self.algorithms = {}
        self.algorithm_names = {}
        for a in mb["algorithms"]:
            self.algorithms[a["name"]] = {
                "id": a["id"], "complexity": a["complexity"],
                "elements": [encode_march_element(e) for e in a["elements"]],
                "text": list(a["elements"]),
            }
            self.algorithm_names[a["id"]] = a["name"]
        self.backgrounds = {b["name"]: b["id"] for b in mb["backgrounds"]}
        self.mem_types = dict(mb["mem_types"])

        lb = raw["lbist"]
        self.lfsr_poly: int = _num(lb["lfsr_poly_mask"])
        self.pinout = raw["reference_pinout"]

    # ---------------------------------------------------------------- helpers
    def status_field(self, name: str) -> Field:
        for f in self.status_fields:
            if f.name == name:
                return f
        raise KeyError(name)

    def decode_status(self, value: int) -> Dict[str, int]:
        return {f.name: f.get(value) for f in self.status_fields}

    def decode_lifecycle(self, otp_code: int) -> int:
        for s in self.raw["lifecycle"]["states"]:
            if s["otp_code"] is not None and s["otp_code"] == otp_code:
                return s["decoded"]
        return self.lifecycle["INVALID"]["decoded"]

    def mode_permitted(self, lc_decoded: int, unlocked: bool, mode: int) -> bool:
        name = self.mode_names.get(mode)
        if name is None or name == "JTAG":
            return name == "JTAG"
        lc_name = self.lc_decoded_names.get(lc_decoded, "INVALID")
        rule = self.mode_permissions[name][lc_name]
        return rule == "ALLOW" or (rule == "UNLOCK" and unlocked)

    def reg_read_ok(self, offset: int, is_jtag: bool, mode: int) -> bool:
        r = self.registers_by_offset.get(offset)
        if r is None:
            return False
        if r.read == "PUBLIC":
            return True
        if r.read == "DIAG":
            return is_jtag and mode == self.modes["DIAGNOSTIC"]
        raise ValueError(r.read)

    def reg_write_ok(self, offset: int, is_jtag: bool, mode: int) -> bool:
        r = self.registers_by_offset.get(offset)
        if r is None:
            return False
        w = r.write
        if w == "NONE":
            return False
        if w == "PUBLIC":
            return True
        if w == "SYS_OR_DIAG":
            return (not is_jtag) or mode == self.modes["DIAGNOSTIC"]
        if w == "DIAG":
            return is_jtag and mode == self.modes["DIAGNOSTIC"]
        if w == "MBIST":
            return is_jtag and mode == self.modes["MEMORY_BIST"]
        if w == "LBIST":
            return is_jtag and mode == self.modes["LOGIC_TEST"]
        raise ValueError(w)

    def idcode(self, version: Optional[int] = None) -> int:
        v = self.idcode_version if version is None else version
        return ((v & 0xF) << 28) | ((self.idcode_part & 0xFFFF) << 12) | ((self.idcode_mfg & 0x7FF) << 1) | 1


@lru_cache(maxsize=4)
def load_spec(path: str = DEFAULT_SPEC_PATH) -> Spec:
    with open(path, "r", encoding="utf-8") as fh:
        return Spec(json.load(fh))
