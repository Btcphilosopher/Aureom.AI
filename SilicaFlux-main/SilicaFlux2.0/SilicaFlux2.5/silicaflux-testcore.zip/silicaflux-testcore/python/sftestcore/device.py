"""High-level TestCore device access over any JtagDriver."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Union

from .jtag import JtagDriver
from .spec import Spec, load_spec


class TestCoreError(RuntimeError):
    pass


class AccessDenied(TestCoreError):
    pass


@dataclass
class IdCode:
    raw: int

    @property
    def version(self) -> int:
        return (self.raw >> 28) & 0xF

    @property
    def part(self) -> int:
        return (self.raw >> 12) & 0xFFFF

    @property
    def manufacturer(self) -> int:
        return (self.raw >> 1) & 0x7FF

    @property
    def valid(self) -> bool:
        return (self.raw & 1) == 1 and self.raw not in (0xFFFFFFFF,) and self.manufacturer != 0x7F

    def as_dict(self) -> Dict[str, Union[int, str]]:
        return {"idcode": f"0x{self.raw:08X}", "version": self.version, "part": f"0x{self.part:04X}",
                "manufacturer": f"0x{self.manufacturer:03X}"}


class TestCoreDevice:
    __test__ = False
    def __init__(self, jtag: JtagDriver, spec: Optional[Spec] = None, reg_idle: Optional[int] = None,
                 max_retries: int = 4):
        self.jtag = jtag
        self.spec = spec or load_spec()
        self.irlen = self.spec.ir_length
        self.reg_idle = reg_idle if reg_idle is not None else self.spec.reg_min_idle
        self.max_retries = max_retries
        self._ir: Optional[int] = None
        self.busy_events = 0

    # ---------------------------------------------------------------- TAP primitives
    def reset(self, trst: bool = False) -> None:
        self.jtag.reset(trst)
        self._ir = self.spec.instructions["IDCODE"]

    def load_ir(self, name: str, force: bool = False) -> int:
        code = self.spec.instructions[name]
        if force or self._ir != code:
            cap = self.jtag.ir_scan(code, self.irlen)
            self._ir = code
            return cap
        return self.spec.ir_capture

    def idcode(self) -> IdCode:
        self.load_ir("IDCODE")
        return IdCode(self.jtag.dr_scan(0, 32))

    # TC_STATUS bits 15..22 come from the system clock domain; in SCAN_TEST that
    # logic is under ATPG control (scan reset pin, test clock) and is undefined.
    SCAN_STATUS_MASK = 0xFF807FFF

    def status(self, mask: Optional[int] = None) -> Dict[str, int]:
        self.load_ir("TC_STATUS")
        raw = self.jtag.dr_scan(0, self.spec.dr_lengths["TC_STATUS"], mask)
        st = self.spec.decode_status(raw)
        st["RAW"] = raw
        return st

    def mode_request(self, mode: Union[str, int], opts: int = 0, settle: Optional[int] = None) -> Dict[str, int]:
        code = self.spec.modes[mode] if isinstance(mode, str) else mode
        self.load_ir("TC_MODE")
        self.jtag.dr_scan((self.spec.mode_magic << 8) | ((opts & 0xF) << 4) | (code & 7), 12)
        self.jtag.idle(settle if settle is not None else self.spec.mode_settle_tck + 8)
        return self.status(self.SCAN_STATUS_MASK if code == self.spec.modes["SCAN_TEST"] else None)

    def enter_mode(self, mode: Union[str, int], opts: int = 0) -> None:
        code = self.spec.modes[mode] if isinstance(mode, str) else mode
        st = self.mode_request(code, opts)
        if st["MODE"] != code:
            err = self.spec.mode_error_names.get(st["LAST_ERR"], str(st["LAST_ERR"]))
            raise AccessDenied(f"mode {self.spec.mode_names.get(code, code)} not entered: {err}")

    def unlock(self, key: int) -> Dict[str, int]:
        self.load_ir("TC_UNLOCK")
        self.jtag.dr_scan(key & ((1 << 64) - 1), 64)
        self.jtag.idle(2)
        return self.status()

    # ---------------------------------------------------------------- register access
    def _reg_scan(self, op: str, addr: int, data: int, mask: Optional[int] = None) -> int:
        v = (self.spec.reg_ops[op] << 44) | ((addr & 0xFFF) << 32) | (data & 0xFFFFFFFF)
        return self.jtag.dr_scan(v, 46, mask)

    def _addr(self, reg: Union[str, int]) -> int:
        return self.spec.registers[reg].offset if isinstance(reg, str) else reg

    def _transact(self, op: str, addr: int, data: int, read_mask: Optional[int]) -> int:
        """Issue one register operation and fetch its result.

        The operation is never re-issued (a retried STEP/START/W1C write would
        not be idempotent).  On BUSY the driver backs off, doubling its idle
        time (adaptive, like a RISC-V DTM 'idle' hint), clears the sticky
        busy flag and re-captures; the captured ADDR must match.
        """
        S = self.spec.reg_status
        self.load_ir("TC_REG")
        self._reg_scan(op, addr, data, mask=0)
        self.jtag.idle(self.reg_idle)
        mask = None
        if read_mask is not None:
            mask = (0x3 << 44) | (0xFFF << 32) | (read_mask & 0xFFFFFFFF)
        for _ in range(self.max_retries + 1):
            cap = self._reg_scan("NOP", 0, 0, mask)
            status = (cap >> 44) & 3
            if status != S["BUSY"]:
                break
            self.busy_events += 1
            self.reg_idle = min(self.reg_idle * 2 + 2, 4096)
            self.jtag.idle(self.reg_idle)
            self._reg_scan("CLEAR_BUSY", 0, 0, mask=0)
            self.jtag.idle(self.reg_idle)
        else:
            raise TestCoreError(f"register {op} 0x{addr:03X}: BUSY after {self.max_retries} back-offs")
        if status == S["ERROR"]:
            raise AccessDenied(f"register {op} 0x{addr:03X} denied/unmapped")
        if (cap >> 32) & 0xFFF != addr:
            raise TestCoreError(f"register {op} 0x{addr:03X}: result belongs to 0x{(cap >> 32) & 0xFFF:03X}")
        return cap & 0xFFFFFFFF

    def read(self, reg: Union[str, int], mask: Optional[int] = None) -> int:
        """Read a register.  `mask` marks compared bits for vector/SVF recording only."""
        return self._transact("READ", self._addr(reg), 0, mask)

    def write(self, reg: Union[str, int], value: int) -> None:
        self._transact("WRITE", self._addr(reg), value, 0)

    def try_read(self, reg: Union[str, int]):
        try:
            return True, self.read(reg)
        except AccessDenied:
            return False, 0

    def try_write(self, reg: Union[str, int], value: int) -> bool:
        try:
            self.write(reg, value)
            return True
        except AccessDenied:
            return False

    def fields(self, reg: str, mask: Optional[int] = None) -> Dict[str, int]:
        return self.spec.registers[reg].decode(self.read(reg, mask))

    def idle(self, n: int) -> None:
        self.jtag.idle(n)

    # ---------------------------------------------------------------- identity
    def identity(self) -> Dict[str, object]:
        idc = self.idcode()
        rev = self.read("SILICON_REV")
        ecid = (self.read("ECID_HI") << 32) | self.read("ECID_LO")
        ver = self.read("TC_VERSION")
        info = idc.as_dict()
        info.update({
            "silicon_rev": f"{(rev >> 24) & 0xFF}.{(rev >> 16) & 0xFF}.{(rev >> 8) & 0xFF}",
            "silicon_rev_raw": f"0x{rev:08X}",
            "ecid": f"0x{ecid:016X}",
            "testcore_version": f"{(ver >> 16) & 0xFF}.{(ver >> 8) & 0xFF}.{ver & 0xFF}",
            "manufacturer_placeholder": idc.manufacturer == self.spec.idcode_mfg and self.spec.idcode_mfg_placeholder,
        })
        return info
