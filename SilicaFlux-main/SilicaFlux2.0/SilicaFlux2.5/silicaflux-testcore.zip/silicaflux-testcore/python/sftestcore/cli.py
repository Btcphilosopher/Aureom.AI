"""sftc: SilicaFlux TestCore host command-line tool.

Examples
  sftc run --transport sim --out logs/                 production flow on the simulator
  sftc run --transport sim --inject 2:SA0:300:70       ... with a stuck-at fault in memory 2
  sftc run --transport sim --vectors flow.vec --svf flow.svf
  sftc run --transport ftdi --ftdi-url ftdi://ftdi:2232h/1 --tck-hz 1e6
  sftc run --transport openocd --openocd-port 6666
  sftc idcode --transport sim
  sftc mbist --transport sim --algorithm MARCH_SS --memories 0,1
  sftc bsdl > silicaflux_v.bsd
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import List, Optional

from .bsdl import generate_bsdl
from .device import TestCoreDevice
from .flows import FlowConfig, production_flow
from .jtag import BitBangJtag, SvfWriter
from .mbist import Mbist
from .models import FAULT_NAMES, Fault
from .spec import load_spec
from .testlog import TestSession


def parse_fault(text: str):
    p = text.split(":")
    if len(p) < 4:
        raise argparse.ArgumentTypeError("fault format MEM:TYPE:ADDR:BIT[:ADDR2:BIT2[:DRF]]")
    mem = int(p[0])
    kind = FAULT_NAMES[p[1].upper()]
    vals = [int(x, 0) for x in p[2:]] + [0, 0, 1000]
    return mem, Fault(kind, vals[0], vals[1], vals[2], vals[3], vals[4] if len(p) > 6 else 1000)


def open_driver(args, spec):
    faults = dict(args.inject or [])
    if args.transport == "sim":
        from .transports.sim import SimTransport
        sim = SimTransport(lc_otp=int(args.lc_otp, 0), faults=faults, ratio=args.sys_per_tck)
        bt = sim
        if args.vectors:
            from .transports.recorder import VectorRecorder
            hdr = (f"sftestcore vectors: lc_otp={args.lc_otp} faults="
                   + " ".join(f"{m}:{f.kind}:{f.addr}:{f.bit}:{f.addr2}:{f.bit2}:{f.drf}" for m, f in faults.items()))
            bt = VectorRecorder(sim, args.vectors, header=hdr)
        drv = BitBangJtag(bt)
    elif args.transport == "ftdi":
        from .transports.ftdi_mpsse import FtdiMpsseTransport
        drv = BitBangJtag(FtdiMpsseTransport(args.ftdi_url, args.tck_hz))
    elif args.transport == "openocd":
        from .transports.openocd import OpenOcdJtag
        drv = OpenOcdJtag(args.openocd_host, args.openocd_port, args.tap)
    else:
        raise SystemExit(f"unknown transport {args.transport}")
    if args.svf:
        drv = SvfWriter(drv, args.svf, args.tck_hz)
    return drv


def common(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("--transport", choices=["sim", "ftdi", "openocd"], default="sim")
    ap.add_argument("--ftdi-url", default="ftdi://ftdi:2232h/1")
    ap.add_argument("--tck-hz", type=float, default=1e6)
    ap.add_argument("--openocd-host", default="127.0.0.1")
    ap.add_argument("--openocd-port", type=int, default=6666)
    ap.add_argument("--tap", default="sftc.tap")
    ap.add_argument("--lc-otp", default="0x00", help="simulator lifecycle OTP code")
    ap.add_argument("--sys-per-tck", type=int, default=4, help="system clocks per TCK (simulator)")
    ap.add_argument("--inject", action="append", type=parse_fault, help="simulator fault MEM:TYPE:ADDR:BIT[...]")
    ap.add_argument("--vectors", help="record TCK vectors (simulator only) for RTL replay")
    ap.add_argument("--svf", help="also write the session as SVF")


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog="sftc", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="run the production flow")
    common(r)
    r.add_argument("--out", default="logs")
    r.add_argument("--station", default="")
    r.add_argument("--extended", action="store_true", help="extra MBIST algorithms/backgrounds")
    r.add_argument("--no-debug", action="store_true")
    r.add_argument("--unlock-key", help="64-bit unlock token (hex)")
    i = sub.add_parser("idcode", help="read IDCODE and identity")
    common(i)
    m = sub.add_parser("mbist", help="run MBIST and print failures")
    common(m)
    m.add_argument("--algorithm", default="MARCH_C_MINUS")
    m.add_argument("--background", default="SOLID")
    m.add_argument("--memories", help="comma-separated indices (default all)")
    m.add_argument("--stop-on-fail", action="store_true")
    m.add_argument("--unlock-key")
    sub.add_parser("bsdl", help="print the BSDL template")
    args = ap.parse_args(argv)
    spec = load_spec()

    if args.cmd == "bsdl":
        sys.stdout.write(generate_bsdl(spec))
        return 0

    drv = open_driver(args, spec)
    dev = TestCoreDevice(drv, spec)
    try:
        if args.cmd == "idcode":
            dev.reset()
            print(json.dumps(dev.identity(), indent=2))
            return 0
        if args.cmd == "mbist":
            from .flows import _enter, _leave
            dev.reset()
            cfg = FlowConfig.for_demo_soc(spec) if args.transport == "sim" else FlowConfig()
            if args.unlock_key:
                cfg.unlock_key = int(args.unlock_key, 16)
            _enter(dev, "MEMORY_BIST", cfg)
            mb = Mbist(dev, cfg.memory_names)
            sel = [int(x) for x in args.memories.split(",")] if args.memories else None
            res = mb.run(args.algorithm, sel, args.background, args.stop_on_fail, sys_per_tck=args.sys_per_tck)
            _leave(dev)
            print(json.dumps(res.as_dict(), indent=2))
            return 0 if res.passed else 1
        # ---- run
        cfg = FlowConfig.for_demo_soc(spec, sys_per_tck=args.sys_per_tck) if args.transport == "sim" else FlowConfig()
        cfg.extended_mbist = args.extended
        cfg.run_debug = not args.no_debug
        if args.unlock_key:
            cfg.unlock_key = int(args.unlock_key, 16)
        sess = TestSession(station=args.station or args.transport, transport=args.transport)
        production_flow(dev, sess, cfg)
        os.makedirs(args.out, exist_ok=True)
        base = os.path.join(args.out, f"session_{sess.session_id}")
        sess.write_json(base + ".json")
        sess.write_csv(os.path.join(args.out, "lot_steps.csv"))
        sess.write_failures_csv(os.path.join(args.out, "lot_failures.csv"))
        print(sess.text_summary())
        print(f"  logs: {base}.json, {args.out}/lot_steps.csv, {args.out}/lot_failures.csv")
        return 0 if sess.summary()["result"] == "PASS" else 1
    finally:
        drv.close()


if __name__ == "__main__":
    sys.exit(main())
