"""Silicon-debug helpers: core halt/resume/step, register access, status readback."""
from __future__ import annotations

from typing import Dict, List

from .device import TestCoreDevice, TestCoreError
from .models import lbist_signature

RESET_CAUSES = ["POR", "EXT_PIN", "WDT", "SW", "DEBUG", "TEST_MODE"]


class Debug:
    def __init__(self, dev: TestCoreDevice):
        self.dev = dev

    def status(self) -> Dict[str, int]:
        return self.dev.fields("DBG_STATUS", mask=0x13D)    # HALTED/RUNNING/HAVERESET/BUSY/ERR/DIAG compared

    def halt(self, wait: int = 16) -> None:
        self.dev.write("DBG_CTRL", 1)
        self.dev.idle(wait)
        if not self.status()["HALTED"]:
            raise TestCoreError("core did not halt")

    def resume(self) -> None:
        self.dev.write("DBG_CTRL", 0)
        self.dev.idle(8)

    def step(self) -> None:
        self.dev.write("DBG_CTRL", 0b11)
        self.dev.idle(8)

    def pc(self) -> int:
        return self.dev.read("DBG_PC", mask=0)

    def _cmd(self, regno: int, write: bool) -> None:
        self.dev.write("DBG_CMD", (int(write) << 16) | (regno & 0x3F))
        self.dev.idle(8)
        st = self.status()
        if st["CMD_BUSY"]:
            raise TestCoreError("abstract command still busy")
        if st["CMD_ERR"]:
            raise TestCoreError(f"abstract command error (regno {regno})")

    def read_reg(self, regno: int, mask=None) -> int:
        self._cmd(regno, False)
        return self.dev.read("DBG_DATA", mask)

    def write_reg(self, regno: int, value: int) -> None:
        self.dev.write("DBG_DATA", value)
        self._cmd(regno, True)

    def reset_cause(self) -> List[str]:
        v = self.dev.read("RESET_CAUSE")
        return [n for i, n in enumerate(RESET_CAUSES) if (v >> i) & 1]

    def error_counters(self) -> List[int]:
        return [self.dev.read(f"ERR_CNT{i}", mask=0) for i in range(8)]

    def clock_status(self) -> Dict[str, int]:
        st = self.dev.fields("CLK_STATUS")
        st["MEAS"] = self.dev.read("CLK_MEAS", mask=0)
        return st

    def accelerator_diag(self) -> List[int]:
        return [self.dev.read(f"ACC_DIAG{i}", mask=0 if i == 0 else None) for i in range(4)]

    def trace_dump(self) -> List[int]:
        st = self.dev.fields("TRACE_STATUS", mask=0)
        out = []
        for i in range(st["COUNT"]):
            self.dev.write("TRACE_IDX", i)
            out.append(self.dev.read("TRACE_DATA", mask=0))
        return out


class Lbist:
    def __init__(self, dev: TestCoreDevice, in_w: int = 68, out_w: int = 33):
        self.dev, self.in_w, self.out_w = dev, in_w, out_w

    def run(self, seed: int = 0xACE12026, patterns: int = 1000, sys_per_tck: float = 4.0) -> Dict[str, object]:
        d = self.dev
        golden = lbist_signature(seed, patterns, self.in_w, self.out_w)
        d.write("LBIST_SEED", seed)
        d.write("LBIST_PATTERNS", patterns)
        d.write("LBIST_SIG_EXP", golden)
        d.write("LBIST_CTRL", 1)
        d.idle(int(patterns / sys_per_tck * 1.5) + 64)
        st = d.fields("LBIST_STATUS")
        sig = d.read("LBIST_SIG")
        return {"seed": f"0x{seed:08X}", "patterns": patterns, "golden": f"0x{golden:08X}",
                "signature": f"0x{sig:08X}", "done": bool(st["DONE"]), "passed": bool(st["PASS"])}
