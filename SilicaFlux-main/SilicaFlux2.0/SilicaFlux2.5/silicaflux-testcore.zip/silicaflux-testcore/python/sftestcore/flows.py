"""Production / bring-up test flow for SilicaFlux devices carrying TestCore.

The flow is transport-independent (simulation, FTDI MPSSE, OpenOCD) and is
also used to generate RTL replay vectors and SVF.  Every read whose value is
not deterministic between the simulator and silicon/RTL (free-running
counters, PC, measured frequency, progress fields) is masked for recording
and checked in software with a tolerance instead.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from .bsdl import bsr_cells
from .debug import Debug, Lbist
from .device import AccessDenied, TestCoreDevice
from .mbist import Mbist
from .spec import Spec
from .testlog import TestSession


@dataclass
class FlowConfig:
    expected_part: Optional[int] = None
    expected_memories: Optional[List[dict]] = None     # [{"width":..,"depth":..,"type":..}]
    memory_names: Optional[List[str]] = None
    unlock_key: Optional[int] = None
    expected_clk_meas: Optional[int] = None
    clk_tolerance: float = 0.02
    sys_per_tck: float = 4.0
    lbist_patterns: int = 1000
    lbist_seed: int = 0xACE12026
    rom_signatures: Optional[dict] = None              # {mem_index: signature}
    extended_mbist: bool = False
    run_debug: bool = True

    @classmethod
    def for_demo_soc(cls, spec: Spec, **kw) -> "FlowConfig":
        from .models import rom_signature
        d = spec.raw["demo_soc"]
        mems = d["memories"]
        roms = {i: rom_signature(m["depth"], m["width"]) for i, m in enumerate(mems) if m["type"] == "ROM"}
        c = d["clocks_ns"]
        cfg = cls(expected_part=spec.idcode_part,
                  expected_memories=[{"width": m["width"], "depth": m["depth"], "type": m["type"]} for m in mems],
                  memory_names=[m["name"] for m in mems],
                  expected_clk_meas=int(d["ref_window"] * c["ref"] / c["sys"]),
                  sys_per_tck=c["tck"] / c["sys"], rom_signatures=roms,
                  unlock_key=int(d["otp"]["unlock_key"], 0))
        for k, v in kw.items():
            setattr(cfg, k, v)
        return cfg


def _enter(dev: TestCoreDevice, mode: str, cfg: FlowConfig, opts: int = 0) -> None:
    st = dev.mode_request(mode, opts)
    if st["MODE"] == dev.spec.modes[mode]:
        return
    if st["LAST_ERR"] == dev.spec.mode_errors["DENIED"] and cfg.unlock_key is not None:
        dev.unlock(cfg.unlock_key)
        st = dev.mode_request(mode, opts)
    if st["MODE"] != dev.spec.modes[mode]:
        raise AccessDenied(f"cannot enter {mode}: {dev.spec.mode_error_names.get(st['LAST_ERR'])}")


def _leave(dev: TestCoreDevice) -> None:
    dev.mode_request("NORMAL")
    dev.idle(32)


def production_flow(dev: TestCoreDevice, session: TestSession, cfg: FlowConfig) -> dict:
    spec = dev.spec
    chk = session.check

    # 1 ---------------------------------------------------------------- TAP integrity
    dev.reset()
    if not getattr(dev.jtag, "captures_ir", True):
        session.skip("tap_ir_capture", "tap", "driver cannot return captured IR bits")
    else:
      with session.step("tap_ir_capture", "tap") as r:
        cap = dev.load_ir("IDCODE", force=True)
        r.measurements["ir_capture"] = f"0b{cap:0{spec.ir_length}b}"
        chk(cap & 3 == 1, f"IR capture LSBs must be 01 (got {cap & 3:02b})")

    with session.step("bypass_chain", "tap") as r:
        dev.load_ir("BYPASS")
        out = dev.jtag.dr_scan(0x1A5, 9)
        r.measurements["bypass_out"] = f"0x{out:03X}"
        chk(out == ((0x1A5 << 1) & 0x1FF), "single TAP, 1-bit BYPASS expected")

    with session.step("idcode", "id") as r:
        idc = dev.idcode()
        r.measurements.update(idc.as_dict())
        chk(idc.valid, "IDCODE LSB must be 1 and manufacturer field valid")
        if cfg.expected_part is not None:
            chk(idc.part == cfg.expected_part, f"part number 0x{idc.part:04X} != 0x{cfg.expected_part:04X}")
        if spec.idcode_mfg_placeholder and idc.manufacturer == spec.idcode_mfg:
            r.message = "WARNING: JEP106 manufacturer code is a placeholder"

    with session.step("testcore_status", "tap") as r:
        st = dev.status()
        r.measurements.update(mode=st["MODE"], lifecycle=spec.lc_decoded_names.get(st["LC_STATE"]),
                              unlocked=st["UNLOCKED"], lockout=st["LOCKOUT"])
        chk(st["MARKER"] == spec.status_marker, f"TC_STATUS marker 0x{st['MARKER']:02X}")
        chk(st["MODE"] == spec.modes["NORMAL"], "device must start in NORMAL")

    with session.step("identity", "id") as r:
        ident = dev.identity()
        session.device.update(ident)
        r.measurements.update(ident)
        chk(dev.read("TC_MAGIC") == spec.constants["TC_MAGIC_VALUE"], "TC_MAGIC mismatch")

    with session.step("bsr_length", "tap") as r:
        n = len(bsr_cells(spec))
        dev.load_ir("SAMPLE_PRELOAD")
        marker = 0xB5A3
        # the first 16 bits shifted in emerge at TDO after exactly n shifts
        out = dev.jtag.dr_scan(marker, n + 16, mask=0xFFFF << n)
        r.measurements["bsr_length"] = n
        chk((out >> n) & 0xFFFF == marker, "boundary-scan register length/integrity")
        dev.load_ir("IDCODE")

    # 2 ---------------------------------------------------------------- registers / security
    with session.step("register_access", "regs") as r:
        for pat in (0x00000000, 0xFFFFFFFF, 0xA5A5A5A5, 0x5A5A5A5A, 0x00000001, 0x80000000):
            dev.write("SCRATCH", pat)
            got = dev.read("SCRATCH")
            chk(got == pat, f"SCRATCH 0x{pat:08X} read 0x{got:08X}")
        before = dev.fields("SEC_STATUS")["DENIED_CNT"]
        denied = not dev.try_write("MBIST_CTRL", 1)
        after = dev.fields("SEC_STATUS")["DENIED_CNT"]
        r.measurements.update(denied_outside_mode=denied, denied_count=after)
        chk(denied, "MBIST control must be denied outside MEMORY_BIST")
        chk(after == min(before + 1, 255), "denied-access counter must increment")

    # 3 ---------------------------------------------------------------- clocks / reset
    with session.step("clock_status", "clock") as r:
        cs = dev.fields("CLK_STATUS")
        meas = dev.read("CLK_MEAS", mask=0)
        r.measurements.update(pll_lock=cs["PLL_LOCK"], clk_alive=cs["CLK_ALIVE"], clk_meas=meas)
        chk(cs["PLL_LOCK"] == 1 and cs["CLK_ALIVE"] == 1, "PLL lock / clock monitor")
        if cfg.expected_clk_meas:
            lo = cfg.expected_clk_meas * (1 - cfg.clk_tolerance)
            hi = cfg.expected_clk_meas * (1 + cfg.clk_tolerance)
            chk(lo <= meas <= hi, f"clock measurement {meas} outside [{lo:.0f}, {hi:.0f}]")

    with session.step("reset_cause", "clock") as r:
        causes = Debug(dev).reset_cause()
        r.measurements["reset_cause"] = "|".join(causes) or "none"
        r.measurements["reset_count"] = dev.read("RESET_COUNT")
        chk("POR" in causes, "power-on reset cause expected after power-up")

    # 4 ---------------------------------------------------------------- memories
    mb = Mbist(dev, cfg.memory_names)
    with session.step("mbist_discovery", "mbist") as r:
        mems = mb.discover()
        r.measurements["memories"] = len(mems)
        for m in mems:
            r.measurements[f"mem{m.index}"] = f"{m.mtype} {m.depth}x{m.width} lat{m.latency} gap{m.wr2rd_gap}"
        if cfg.expected_memories is not None:
            chk(len(mems) == len(cfg.expected_memories), "registered memory count")
            for m, e in zip(mems, cfg.expected_memories):
                chk(m.width == e["width"] and m.depth == e["depth"] and m.mtype == e["type"],
                    f"registry entry {m.index} mismatch")

    def mbist_step(name: str, algorithm: str, background: str, sel=None):
        with session.step(name, "mbist") as r:
            _enter(dev, "MEMORY_BIST", cfg)
            try:
                rom_sig = None
                if cfg.rom_signatures and (sel is None or any(i in sel for i in cfg.rom_signatures)):
                    rom_sig = next(iter(cfg.rom_signatures.values()))
                res = mb.run(algorithm, sel, background, rom_signature=rom_sig, sys_per_tck=cfg.sys_per_tck)
            finally:
                _leave(dev)
            r.measurements.update(algorithm=algorithm, background=background, fail_count=res.fail_count,
                                  failing_memories=",".join(str(i) for i in res.failing_memories) or "none",
                                  log_overflow=res.log_overflow, rom_sig_fail=res.sig_fail)
            r.failures = [f.as_dict() for f in res.failures]
            chk(res.done, "MBIST did not complete")
            chk(res.passed, f"MBIST {algorithm}: {res.fail_count} failing reads in memories "
                            f"{res.failing_memories} (no repair available)")
            return res

    mbist_step("mbist_march_c", "MARCH_C_MINUS", "SOLID")
    if cfg.extended_mbist:
        rams = [m.index for m in mems if m.mtype != "ROM"]
        mbist_step("mbist_checkerboard", "MARCH_C_MINUS", "CHECKER", rams)
        mbist_step("mbist_march_ss", "MARCH_SS", "SOLID", rams)

    # 5 ---------------------------------------------------------------- logic BIST
    with session.step("lbist", "lbist") as r:
        _enter(dev, "LOGIC_TEST", cfg)
        try:
            res = Lbist(dev).run(cfg.lbist_seed, cfg.lbist_patterns, cfg.sys_per_tck)
        finally:
            _leave(dev)
        r.measurements.update(res)
        chk(res["done"] and res["passed"], f"LBIST signature {res['signature']} != golden {res['golden']}")

    # 6 ---------------------------------------------------------------- debug
    if cfg.run_debug:
        with session.step("debug_access", "debug") as r:
            _enter(dev, "DIAGNOSTIC", cfg)
            dbg = Debug(dev)
            try:
                dbg.halt()
                pc0 = dbg.pc()
                dbg.write_reg(5, 0xC0FFEE05)
                x5 = dbg.read_reg(5)
                dbg.step()
                pc1 = dbg.pc()
                dbg.resume()
                running = dbg.status()["RUNNING"]
            finally:
                _leave(dev)
            r.measurements.update(pc_halted=f"0x{pc0:08X}", pc_after_step=f"0x{pc1:08X}", x5=f"0x{x5:08X}")
            chk(x5 == 0xC0FFEE05, "GPR write/read-back through debug path")
            chk(pc1 == (pc0 + 4) & 0xFFFFFFFF, "single step must advance PC by 4")
            chk(running == 1, "core must resume")
    else:
        session.skip("debug_access", "debug", "disabled by configuration")

    with session.step("final_state", "regs") as r:
        st = dev.status()
        r.measurements.update(mode=st["MODE"], last_err=st["LAST_ERR"])
        chk(st["MODE"] == spec.modes["NORMAL"], "device must be returned to NORMAL")

    return session.finish()
