"""Bit-accurate golden models shared by the host software and the simulator.

These mirror the RTL exactly (and are cross-checked against it by the RTL
vector-replay test):
  * LFSR / MISR (Galois, x^32+x^22+x^2+x+1)        -> rtl/tc_pkg.sv
  * LBIST phase shifter, demo ALU, signature       -> rtl/tc_lbist.sv, rtl/demo/
  * MBIST data backgrounds, ROM word, XOR fold      -> rtl/tc_mbist.sv
  * fault-injectable memory model                  -> tb/models/tc_sram_model.sv
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .spec import KIND_END, KIND_MARCH, KIND_PAUSE, decode_march_element

M32 = 0xFFFFFFFF
LFSR_POLY = 0x80200003


def lfsr_step(s: int) -> int:
    return ((s >> 1) ^ LFSR_POLY) if (s & 1) else (s >> 1)


def misr_step(s: int, d: int) -> int:
    return lfsr_step(s) ^ (d & M32)


def fold32(value: int, width: int) -> int:
    r = 0
    for i in range(width):
        if (value >> i) & 1:
            r ^= 1 << (i % 32)
    return r


def phase_shift(s: int, width: int) -> int:
    v = 0
    for i in range(width):
        b = ((s >> (i % 32)) ^ (s >> ((5 * i + 3) % 32)) ^ (s >> ((13 * i + 7) % 32))) & 1
        v |= b << i
    return v


def _sra(a: int, sh: int) -> int:
    if a & 0x80000000:
        return ((a | ~M32) >> sh) & M32
    return a >> sh


def _s32(a: int) -> int:
    return a - (1 << 32) if a & 0x80000000 else a


def demo_alu(a: int, b: int, op: int) -> int:
    """tc_lbist_demo_alu: returns {zero, y} (33 bits)."""
    sh = b & 31
    if op == 0:
        y = a + b
    elif op == 1:
        y = a - b
    elif op == 2:
        y = a & b
    elif op == 3:
        y = a | b
    elif op == 4:
        y = a ^ b
    elif op == 5:
        y = a << sh
    elif op == 6:
        y = a >> sh
    elif op == 7:
        y = _sra(a, sh)
    elif op == 8:
        y = 1 if _s32(a) < _s32(b) else 0
    elif op == 9:
        y = 1 if a < b else 0
    elif op == 10:
        y = a
    elif op == 11:
        y = b
    elif op == 12:
        y = ~(a | b)
    elif op == 13:
        y = ~(a ^ b)
    elif op == 14:
        y = a & ~b
    else:
        y = a | ~b
    y &= M32
    return ((1 if y == 0 else 0) << 32) | y


def lbist_patterns(seed: int, n: int, in_w: int = 68):
    s = seed & M32 or 1
    for _ in range(n):
        yield phase_shift(s, in_w)
        s = lfsr_step(s)


def lbist_signature(seed: int, n: int, in_w: int = 68, out_w: int = 33, target=None) -> int:
    """Golden MISR signature for the LBIST demo target (or a custom target fn)."""
    target = target or (lambda v: demo_alu(v & M32, (v >> 32) & M32, (v >> 64) & 0xF))
    m = 0
    for p in lbist_patterns(seed, n, in_w):
        m = misr_step(m, fold32(target(p), out_w))
    return m


def rom_word(addr: int, width: int = 32) -> int:
    return (((addr * 0x9E3779B1) & M32) ^ 0xA5A5A5A5) & ((1 << width) - 1)


def rom_signature(depth: int, width: int = 32, words=None) -> int:
    m = 0
    for a in range(depth):
        w = rom_word(a, width) if words is None else words[a]
        m = misr_step(m, fold32(w & ((1 << width) - 1), width))
    return m


def background(bg: int, addr: int, width: int, user: int) -> int:
    """MBIST data background (tc_mbist.sv bgpat)."""
    v = 0
    a0 = addr & 1
    for i in range(width):
        if bg == 1:                       # CHECKER
            b = (i & 1) ^ a0
        elif bg == 2:                     # ROW_STRIPE
            b = a0
        elif bg == 3:                     # COL_STRIPE
            b = i & 1
        elif bg == 4:                     # USER
            b = (user >> (i % 32)) & 1
        else:                             # SOLID
            b = 0
        v |= b << i
    return v


# --------------------------------------------------------------------------- memory model

F_NONE, F_SA0, F_SA1, F_TF_UP, F_TF_DOWN, F_AF, F_CFID, F_DRF, F_COL_SA0 = range(9)
FAULT_NAMES = {"NONE": F_NONE, "SA0": F_SA0, "SA1": F_SA1, "TF_UP": F_TF_UP, "TF_DOWN": F_TF_DOWN,
               "AF": F_AF, "CFID": F_CFID, "DRF": F_DRF, "COL_SA0": F_COL_SA0}


@dataclass
class Fault:
    kind: int = F_NONE
    addr: int = 0
    bit: int = 0
    addr2: int = 0
    bit2: int = 0
    drf: int = 1000

    def plusargs(self, mem_id: int) -> List[str]:
        return [f"+fault_mem={mem_id}", f"+fault_type={self.kind}", f"+fault_addr={self.addr}",
                f"+fault_bit={self.bit}", f"+fault_addr2={self.addr2}", f"+fault_bit2={self.bit2}",
                f"+fault_drf={self.drf}"]


class MemoryModel:
    """Python twin of tb/models/tc_sram_model.sv (functional, cycle-approximate for DRF)."""

    def __init__(self, width: int, depth: int, mtype: int):
        self.width, self.depth, self.mtype = width, depth, mtype
        self.mask = (1 << width) - 1
        self.fault = Fault()
        self.last_wr = [0] * depth
        if mtype == 2:
            self.mem = [rom_word(i, width) for i in range(depth)]
        else:
            self.mem = []
            for i in range(depth):
                w = (((i * 0x01000193) & M32) ^ 0x811C9DC5)
                self.mem.append((w | (w << 32) | (w << 64) | (w << 96)) & self.mask)

    def _eff(self, a: int) -> int:
        f = self.fault
        return f.addr2 if (f.kind == F_AF and a == f.addr) else a

    def write(self, a_in: int, d: int, cyc: int) -> None:
        if self.mtype == 2:
            return
        a = self._eff(a_in)
        if a >= self.depth:
            return
        f = self.fault
        old, nw = self.mem[a], d & self.mask
        bm = 1 << f.bit
        if f.kind == F_SA0 and a == f.addr:
            nw &= ~bm
        elif f.kind == F_SA1 and a == f.addr:
            nw |= bm
        elif f.kind == F_TF_UP and a == f.addr and not old & bm and d & bm:
            nw &= ~bm
        elif f.kind == F_TF_DOWN and a == f.addr and old & bm and not d & bm:
            nw |= bm
        elif f.kind == F_COL_SA0:
            nw &= ~bm
        self.mem[a] = nw
        self.last_wr[a] = cyc
        if f.kind == F_CFID and a == f.addr and not old & bm and nw & bm:
            self.mem[f.addr2] |= 1 << f.bit2

    def read(self, a_in: int, cyc: int) -> int:
        a = self._eff(a_in)
        if a >= self.depth:
            return 0
        f = self.fault
        bm = 1 << f.bit
        if f.kind == F_DRF and a == f.addr and self.mem[a] & bm and (cyc - self.last_wr[a]) >= f.drf:
            self.mem[a] &= ~bm
        v = self.mem[a]
        if f.kind == F_SA0 and a == f.addr:
            v &= ~bm
        elif f.kind == F_SA1 and a == f.addr:
            v |= bm
        elif f.kind == F_COL_SA0:
            v &= ~bm
        return v


# --------------------------------------------------------------------------- MBIST engine model

@dataclass
class MemInfo:
    name: str
    width: int
    depth: int
    latency: int
    mtype: int
    wr2rd: int


@dataclass
class MbistOutcome:
    done: bool = True
    fail: bool = False
    stopped: bool = False
    sig_fail: bool = False
    fail_mems: int = 0
    fail_count: int = 0
    acc_synd: int = 0
    log: List[tuple] = field(default_factory=list)   # (mem, elem, op, addr, synd)
    log_ovf: bool = False
    misr: int = 0
    cycles: int = 0
    last_elem: int = 0


def run_march(mems: List[MemInfo], models: List[MemoryModel], sel: int, elements_for, bg: int,
              bg_user: int, pause: int, stop_on_fail: bool, sig_check: bool, sig_exp: int,
              log_depth: int, max_lat: int, cyc0: int = 0, last_elem: int = 0) -> MbistOutcome:
    """Functional model of tc_mbist (results identical to RTL; cycle count approximate)."""
    out = MbistOutcome(last_elem=last_elem)
    cyc = cyc0
    tested_any = False

    def record(mi, e, o, a, synd):
        out.fail = True
        out.fail_mems |= 1 << mi
        out.fail_count = min(out.fail_count + 1, M32)
        out.acc_synd |= synd
        if len(out.log) < log_depth:
            out.log.append((mi, e, o, a, synd))
        else:
            out.log_ovf = True

    for mi, info in enumerate(mems):
        cyc += 1
        if not (sel >> mi) & 1:
            continue
        tested_any = True
        model = models[mi]
        mask = (1 << info.width) - 1
        if info.mtype == 2:                                   # ROM signature pass
            for a in range(info.depth):
                out.misr = misr_step(out.misr, fold32(model.read(a, cyc) & mask, info.width))
                cyc += 1
            out.last_elem = 1
            cyc += max_lat + 2
            continue
        elems = elements_for()
        e_idx = 0
        last_wr_addr, last_wr_cyc = None, -100
        while True:
            if e_idx >= 8:
                break
            kind, down, ops = decode_march_element(elems[e_idx] if e_idx < len(elems) else 0)
            cyc += 1
            if kind == KIND_MARCH:
                rng = range(info.depth - 1, -1, -1) if down else range(info.depth)
                for a in rng:
                    for oi, op in enumerate(ops):
                        is_rd, val = op >> 1, op & 1
                        bgv = background(bg, a, info.width, bg_user)
                        data = (~bgv if val else bgv) & mask
                        if is_rd:
                            if last_wr_addr == a and (cyc - last_wr_cyc - 1) < info.wr2rd:
                                cyc += info.wr2rd - (cyc - last_wr_cyc - 1)
                            synd = (model.read(a, cyc) ^ data) & mask
                            if synd:
                                record(mi, e_idx & 7, oi, a, synd)
                                if stop_on_fail:
                                    out.stopped = True
                                    out.last_elem = e_idx & 7
                                    out.cycles = cyc - cyc0
                                    return out
                        else:
                            model.write(a, data, cyc)
                            last_wr_addr, last_wr_cyc = a, cyc
                        cyc += 1
                e_idx += 1
            elif kind == KIND_PAUSE:
                cyc += pause + 1
                e_idx += 1
            else:
                if e_idx == 0:
                    out.fail = True
                    out.fail_mems |= 1 << mi
                break
        out.last_elem = e_idx & 7
        cyc += max_lat + 2
    if sig_check and out.misr != sig_exp:
        out.sig_fail = True
        out.fail = True
    if not tested_any:
        out.fail = True
    out.cycles = cyc - cyc0
    return out
