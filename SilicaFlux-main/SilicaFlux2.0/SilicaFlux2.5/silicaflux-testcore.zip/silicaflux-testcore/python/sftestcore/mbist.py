"""MBIST control: memory discovery, run, failure capture and decoding."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Sequence, Union

from .device import TestCoreDevice, TestCoreError
from .spec import march_complexity

MEM_TYPES = {0: "SRAM_1RW", 1: "SRAM_1R1W", 2: "ROM"}
STATUS_PROGRESS_MASK = ~0x7F00 & 0xFFFFFFFF        # CUR_MEM / CUR_ELEM are progress, not results


@dataclass
class MemoryEntry:
    index: int
    width: int
    depth: int
    latency: int
    mtype: str
    wr2rd_gap: int


@dataclass
class Failure:
    memory: int
    memory_name: str
    element: int
    op_index: int
    address: int
    syndrome: int
    failing_bits: List[int]

    def as_dict(self):
        d = asdict(self)
        d["syndrome"] = f"0x{self.syndrome:X}"
        return d


@dataclass
class MbistResult:
    algorithm: str
    memories: List[int]
    background: str
    done: bool
    passed: bool
    stopped: bool
    aborted: bool
    log_overflow: bool
    sig_fail: bool
    failing_memories: List[int]
    fail_count: int
    failures: List[Failure] = field(default_factory=list)
    failing_bit_map: int = 0
    rom_signature: Optional[int] = None

    def as_dict(self):
        d = asdict(self)
        d["failures"] = [f.as_dict() for f in self.failures]
        d["failing_bit_map"] = f"0x{self.failing_bit_map:X}"
        if self.rom_signature is not None:
            d["rom_signature"] = f"0x{self.rom_signature:08X}"
        return d


class Mbist:
    def __init__(self, dev: TestCoreDevice, names: Optional[Sequence[str]] = None):
        self.dev = dev
        self.spec = dev.spec
        self.names = list(names) if names else None

    def discover(self) -> List[MemoryEntry]:
        d = self.dev
        n = d.read("MBIST_NUM_MEMS")
        out = []
        for i in range(n):
            d.write("MBIST_MEM_IDX", i)
            i0 = d.fields("MBIST_MEM_INFO0")
            i1 = d.read("MBIST_MEM_INFO1")
            if not i0["VALID"]:
                raise TestCoreError(f"memory registry entry {i} invalid")
            out.append(MemoryEntry(i, i0["WIDTH"], i1 + 1, i0["LATENCY"], MEM_TYPES.get(i0["TYPE"], "?"),
                                   i0["WR2RD_GAP"]))
        self.memories = out
        return out

    def estimate_cycles(self, algorithm: str, mems: Sequence[MemoryEntry], pause: int = 0) -> int:
        a = self.spec.algorithms[algorithm]
        n_ops = march_complexity(a["elements"]) if a["elements"] else 22
        n_pause = sum(1 for t in a["text"] if t.upper() == "PAUSE")
        total = 0
        for m in mems:
            if m.mtype == "ROM":
                total += m.depth + 16
            else:
                total += n_ops * m.depth * (1 + m.wr2rd_gap) + 8 * 2 + n_pause * (pause + 2) + 16
        return total

    def run(self, algorithm: str = "MARCH_C_MINUS", memories: Optional[Sequence[int]] = None,
            background: str = "SOLID", stop_on_fail: bool = False, rom_signature: Optional[int] = None,
            user_elements: Optional[Sequence[int]] = None, pause: Optional[int] = None,
            sys_per_tck: float = 4.0, timeout_factor: float = 3.0) -> MbistResult:
        d, s = self.dev, self.spec
        mems = self.discover() if not hasattr(self, "memories") else self.memories
        sel_idx = list(range(len(mems))) if memories is None else list(memories)
        if not sel_idx:
            raise ValueError("refusing to start MBIST with an empty selection (hardware reports FAIL)")
        sel = sum(1 << i for i in sel_idx)
        algo_id = s.algorithms[algorithm]["id"]
        if algorithm == "USER":
            if not user_elements:
                raise ValueError("USER algorithm requires user_elements")
            for k in range(8):
                d.write(f"MBIST_UALG{k}", user_elements[k] if k < len(user_elements) else 0)
        if pause is not None:
            d.write("MBIST_PAUSE", pause)
        if rom_signature is not None:
            d.write("MBIST_SIG_EXP", rom_signature)
        d.write("MBIST_MEM_SEL", sel)
        ctrl = (1 << 0) | (algo_id << 2) | (s.backgrounds[background] << 6) | (int(stop_on_fail) << 9) | \
               (int(rom_signature is not None) << 10)
        d.write("MBIST_CTRL", ctrl)
        est = self.estimate_cycles(algorithm if algorithm != "USER" else "MARCH_SS",
                                   [mems[i] for i in sel_idx], pause or 0)
        d.idle(int(est / sys_per_tck * 1.25) + 64)
        st = d.fields("MBIST_STATUS", mask=STATUS_PROGRESS_MASK)
        waited = 0
        limit = int(est / sys_per_tck * timeout_factor) + 1000
        while st["BUSY"] and waited < limit:
            d.idle(256)
            waited += 256
            st = d.fields("MBIST_STATUS", mask=STATUS_PROGRESS_MASK)
        if st["BUSY"]:
            raise TestCoreError("MBIST did not complete before timeout")
        fail_mems = d.read("MBIST_FAIL_MEMS")
        result = MbistResult(
            algorithm=algorithm, memories=sel_idx, background=background, done=bool(st["DONE"]),
            passed=bool(st["DONE"]) and not st["FAIL"], stopped=bool(st["STOPPED"]), aborted=bool(st["ABORTED"]),
            log_overflow=bool(st["LOG_OVF"]), sig_fail=bool(st["SIG_FAIL"]),
            failing_memories=[i for i in range(len(mems)) if (fail_mems >> i) & 1],
            fail_count=d.read("MBIST_FAIL_COUNT"))
        if rom_signature is not None or any(mems[i].mtype == "ROM" for i in sel_idx):
            result.rom_signature = d.read("MBIST_SIG")
        if st["FAIL"]:
            result.failures = self.read_log(st["LOG_COUNT"], mems)
            result.failing_bit_map = (d.read("MBIST_ACC_SYND2") << 64) | (d.read("MBIST_ACC_SYND1") << 32) | \
                d.read("MBIST_ACC_SYND0")
        return result

    def read_log(self, count: int, mems: Sequence[MemoryEntry]) -> List[Failure]:
        d = self.dev
        out = []
        for i in range(count):
            d.write("MBIST_LOG_IDX", i)
            info = d.fields("MBIST_LOG_INFO")
            if not info["VALID"]:
                break
            synd = (d.read("MBIST_LOG_SYND2") << 64) | (d.read("MBIST_LOG_SYND1") << 32) | d.read("MBIST_LOG_SYND0")
            mi = info["MEM"]
            name = self.names[mi] if self.names and mi < len(self.names) else f"MEM{mi}"
            out.append(Failure(mi, name, info["ELEM"], info["OP"], info["ADDR"], synd,
                               [b for b in range(96) if (synd >> b) & 1]))
        return out
