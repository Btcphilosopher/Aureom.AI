"""Structured test logging: per-device sessions, CSV/JSON output, summary and binning."""
from __future__ import annotations

import csv
import datetime as _dt
import json
import os
import time
import traceback
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

PASS, FAIL, SKIP, ERROR = "PASS", "FAIL", "SKIP", "ERROR"

# Soft-bin assignment by the first failing step category.  Bin numbers are a
# proposal for the SilicaFlux-V test program, not an ATE vendor convention.
SOFT_BINS = {
    "PASS": (1, "good"),
    "tap": (2, "TAP / boundary-scan / IDCODE failure"),
    "id": (2, "TAP / boundary-scan / IDCODE failure"),
    "regs": (3, "register access / security failure"),
    "clock": (4, "clock or reset failure"),
    "mbist": (5, "memory BIST failure (no repair available)"),
    "lbist": (6, "logic BIST failure"),
    "debug": (7, "debug access failure"),
    "error": (9, "test infrastructure error (retest)"),
}
HARD_BIN = {1: 1, 2: 2, 3: 2, 4: 2, 5: 3, 6: 2, 7: 2, 9: 9}


class StepFailed(AssertionError):
    pass


@dataclass
class StepResult:
    name: str
    category: str
    status: str = PASS
    duration_ms: float = 0.0
    measurements: Dict[str, Any] = field(default_factory=dict)
    message: str = ""
    failures: List[Dict[str, Any]] = field(default_factory=list)


class TestSession:
    __test__ = False
    def __init__(self, station: str = "sim", transport: str = "sim", operator: str = "", notes: str = ""):
        self.session_id = uuid.uuid4().hex[:12]
        self.started = _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")
        self.station, self.transport, self.operator, self.notes = station, transport, operator, notes
        self.device: Dict[str, Any] = {}
        self.steps: List[StepResult] = []
        self.finished: Optional[str] = None

    @contextmanager
    def step(self, name: str, category: str):
        r = StepResult(name, category)
        t0 = time.perf_counter()
        try:
            yield r
        except StepFailed as e:
            r.status, r.message = FAIL, str(e)
        except Exception as e:  # noqa: BLE001 - recorded as ERROR, flow continues
            r.status, r.message = ERROR, f"{type(e).__name__}: {e}"
            r.measurements["traceback"] = traceback.format_exc(limit=3)
        finally:
            r.duration_ms = round((time.perf_counter() - t0) * 1000.0, 3)
            self.steps.append(r)

    @staticmethod
    def check(cond: bool, msg: str) -> None:
        if not cond:
            raise StepFailed(msg)

    def skip(self, name: str, category: str, reason: str) -> None:
        self.steps.append(StepResult(name, category, SKIP, 0.0, {}, reason))

    # ---------------------------------------------------------------- summary
    def summary(self) -> Dict[str, Any]:
        counts = {k: 0 for k in (PASS, FAIL, SKIP, ERROR)}
        for s in self.steps:
            counts[s.status] += 1
        first_bad = next((s for s in self.steps if s.status in (FAIL, ERROR)), None)
        if first_bad is None:
            sb = SOFT_BINS["PASS"]
        elif first_bad.status == ERROR:
            sb = SOFT_BINS["error"]
        else:
            sb = SOFT_BINS.get(first_bad.category, SOFT_BINS["error"])
        return {
            "result": PASS if first_bad is None else FAIL,
            "counts": counts,
            "soft_bin": sb[0], "soft_bin_desc": sb[1], "hard_bin": HARD_BIN[sb[0]],
            "first_failing_step": first_bad.name if first_bad else None,
            "total_ms": round(sum(s.duration_ms for s in self.steps), 3),
        }

    def finish(self) -> Dict[str, Any]:
        self.finished = _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")
        return self.summary()

    # ---------------------------------------------------------------- output
    def as_dict(self) -> Dict[str, Any]:
        return {
            "schema": "sftestcore.session/1",
            "session_id": self.session_id, "started": self.started, "finished": self.finished,
            "station": self.station, "transport": self.transport, "operator": self.operator, "notes": self.notes,
            "device": self.device, "summary": self.summary(), "steps": [asdict(s) for s in self.steps],
        }

    def write_json(self, path: str) -> str:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(self.as_dict(), fh, indent=2, default=str)
        return path

    def write_csv(self, path: str, append: bool = True) -> str:
        """One row per step; appends to a lot-level CSV if it exists."""
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        new = not os.path.exists(path) or not append
        cols = ["session_id", "started", "station", "idcode", "silicon_rev", "ecid", "step", "category",
                "status", "duration_ms", "measurements", "message", "soft_bin", "hard_bin"]
        summ = self.summary()
        with open(path, "a" if append else "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=cols)
            if new:
                w.writeheader()
            for s in self.steps:
                meas = {k: v for k, v in s.measurements.items() if k != "traceback"}
                w.writerow({
                    "session_id": self.session_id, "started": self.started, "station": self.station,
                    "idcode": self.device.get("idcode", ""), "silicon_rev": self.device.get("silicon_rev", ""),
                    "ecid": self.device.get("ecid", ""), "step": s.name, "category": s.category,
                    "status": s.status, "duration_ms": s.duration_ms,
                    "measurements": ";".join(f"{k}={v}" for k, v in meas.items()),
                    "message": s.message, "soft_bin": summ["soft_bin"], "hard_bin": summ["hard_bin"],
                })
        return path

    def write_failures_csv(self, path: str, append: bool = True) -> str:
        """One row per captured failure (e.g. MBIST fail log entries)."""
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        new = not os.path.exists(path) or not append
        cols = ["session_id", "ecid", "step", "memory", "memory_name", "element", "op_index", "address",
                "syndrome", "failing_bits"]
        with open(path, "a" if append else "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
            if new:
                w.writeheader()
            for s in self.steps:
                for f in s.failures:
                    row = dict(f)
                    row.update(session_id=self.session_id, ecid=self.device.get("ecid", ""), step=s.name)
                    row["failing_bits"] = " ".join(map(str, row.get("failing_bits", [])))
                    w.writerow(row)
        return path

    def text_summary(self) -> str:
        s = self.summary()
        lines = [f"SilicaFlux TestCore session {self.session_id}  ({self.transport})",
                 f"  device : IDCODE {self.device.get('idcode', '?')}  rev {self.device.get('silicon_rev', '?')}  "
                 f"ECID {self.device.get('ecid', '?')}"]
        for st in self.steps:
            lines.append(f"  [{st.status:5}] {st.name:<28} {st.duration_ms:9.1f} ms  {st.message}")
        lines.append(f"  RESULT {s['result']}  soft bin {s['soft_bin']} ({s['soft_bin_desc']})  hard bin {s['hard_bin']}"
                     f"  pass={s['counts']['PASS']} fail={s['counts']['FAIL']} skip={s['counts']['SKIP']}"
                     f" error={s['counts']['ERROR']}")
        return "\n".join(lines)
