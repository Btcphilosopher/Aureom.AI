"""Software simulation transport for SilicaFlux TestCore (no hardware needed).

`SimTarget` models the device at TCK granularity:
  * TAP controller, IR (falling-edge update), BYPASS, IDCODE, BSR
  * TC_STATUS / TC_MODE / TC_UNLOCK / TC_REG data registers
  * test-mode state machine (port of rtl/tc_mode_ctrl.sv, same TCK timing)
  * register bridge with BUSY/sticky semantics
  * the register map of the demo SoC integration, MBIST (functional model
    with fault injection), LBIST, core debug, reset cause and counters
System-clock activity is advanced by `ratio` system cycles per TCK.

Fidelity: TDO-accurate for everything a host flow observes after the
documented idle times; system-side timing (MBIST/LBIST durations, PC values,
error-event counts) is approximate.  The RTL vector-replay test
(python/tests/test_rtl_replay.py) checks the model against the RTL, with
masks on the documented approximate fields.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence

from .. import jtag as J
from ..models import (M32, MemInfo, MemoryModel, Fault, run_march, lbist_signature, rom_signature)
from ..spec import Spec, load_spec


class SimTarget:
    def __init__(self, spec: Optional[Spec] = None, lc_otp: int = 0x00, otp_valid: bool = True,
                 ratio: int = 4, faults: Optional[Dict[int, Fault]] = None, reg_latency_tck: int = 3):
        self.spec = spec or load_spec()
        s = self.spec
        d = s.raw["demo_soc"]
        self.cfg = d
        self.ratio = ratio
        self.reg_latency_tck = reg_latency_tck
        self.lc_otp = lc_otp
        self.otp_valid = otp_valid
        self.unlock_key = int(d["otp"]["unlock_key"], 0)
        self.ecid = int(d["otp"]["ecid"], 0)
        r = d["silicon_rev"]
        self.silicon_rev = (r["major"] << 16) | (r["minor"] << 8) | r["metal"]
        self.id_version = d["idcode_version"]
        self.I = s.instructions
        self.M = s.modes
        self.E = s.mode_errors
        self.R = {n: r.offset for n, r in s.registers.items()}
        self.settle = s.mode_settle_tck
        self.mems = [MemInfo(m["name"], m["width"], m["depth"],
                             m["macro_latency"] + m["in_pipe"] + m["out_pipe"],
                             s.mem_types[m["type"]], m["wr2rd"]) for m in d["memories"]]
        self.mem_models = [MemoryModel(m.width, m.depth, m.mtype) for m in self.mems]
        for mi, f in (faults or {}).items():
            self.mem_models[mi].fault = f
        self.n_in = len(s.pinout["inputs"])
        self.n_out = len(s.pinout["outputs"])
        self.n_bd = len(s.pinout["bidirs"])
        self.bsr_len = self.n_in + 2 * self.n_out + 3 * self.n_bd
        self.in_pad = 0
        self.io_pad_i = 0
        self.power_on()

    # ================================================================ reset
    def power_on(self) -> None:
        self.unlocked = False
        self.lockout = False
        self.attempts = 0
        self.req_pending = False
        self.req_ready_at = 0
        self.sticky = False
        self.res = (self.spec.reg_status["OK"], 0, 0)
        self.tck_count = 0
        self.sys_cycle = 0
        self._tap_reset()
        self._tc_reset(por=True)
        self.core_reset()

    def _tap_reset(self) -> None:
        self.state = J.TLR
        self.ir = self.I["IDCODE"]
        self.ir_sh = 0
        self.bypass = 0
        self.id_sh = 0
        self.bsr_sh = 0
        self.bsr_up = 0
        self.sh_mode = 0
        self.sh_stat = 0
        self.sh_unl = 0
        self.sh_reg = 0
        self.tdo = 0
        self.cur_mode = self.M["NORMAL"]
        self.target = self.M["NORMAL"]
        self.phase = 0       # 0 STABLE, 1 ENTER, 2 EXIT
        self.cnt = 0
        self.opts = 0
        self.last_err = 0
        self.clk_test_sel = 0
        self.clk_stop = 0
        self.sys_hold_prev = False

    def trst(self) -> None:
        self._tap_reset()

    def _tc_reset(self, por: bool) -> None:
        """TestCore system-clock-domain reset (POR, or SCAN_TEST entry/exit)."""
        self.scratch = 0
        self.denied = 0
        self.cause = 0x01
        self.rst_count = 1           # POR episode is still in progress when TestCore leaves reset
        self.err_cnt = [0] * 8
        self.mb = dict(algo=0, bg=0, sof=0, sigchk=0, sel=0, bg_user=0, pause=1024, sig_exp=0,
                       log_idx=0, mem_idx=0, ualg=[0] * 8)
        self.mb_res = dict(busy=False, busy_until=0, done=False, fail=False, stopped=False, aborted=False,
                           log_ovf=False, sig_fail=False, fail_mems=0, fail_count=0, misr=0, acc_synd=0,
                           log=[], cur_mem=0, cur_elem=0)
        self.lb = dict(seed=1, npat=1024, sig_exp=0, sig=0, busy=False, busy_until=0, done=False,
                       pass_=False, aborted=False)
        self.dbg = dict(halt_req=False, havereset=False, cmd_busy=False, cmd_err=False, cmd_we=False,
                        regno=0, data=0, diag_q=False)
        self.trace = dict(enable=False, stop_on_halt=False, count=0, wrapped=False, idx=0, buf=[0] * 16, wp=0)

    def core_reset(self) -> None:
        self.pc = 0x80000000
        self.x = [(i * 0x11111111) & M32 for i in range(32)]
        self.halted = False
        self.icount = 0
        self.dbg["havereset"] = True if hasattr(self, "dbg") else False

    # ================================================================ mode helpers
    def lc(self) -> int:
        return self.spec.decode_lifecycle(self.lc_otp) if self.otp_valid else 7

    def _holds_sys(self, m: int) -> bool:
        return m in (self.M["JTAG"], self.M["MEMORY_BIST"], self.M["LOGIC_TEST"], self.M["SCAN_TEST"])

    def sys_hold(self) -> bool:
        return (self._holds_sys(self.cur_mode) or self.phase == 2 or
                (self.phase == 1 and self._holds_sys(self.target)))

    def mode_sys(self) -> int:
        if self.cur_mode == self.M["JTAG"]:
            return self.cur_mode
        return self.cur_mode if self.phase == 0 else self.M["NORMAL"]

    def _perm(self, mode: int) -> bool:
        return self.spec.mode_permitted(self.lc(), self.unlocked, mode)

    def _bscan_inv(self) -> bool:
        return self.ir in (self.I["EXTEST"], self.I["CLAMP"], self.I["HIGHZ"])

    # ================================================================ TCK
    def clock(self, tms: int, tdi: int) -> int:
        sample = self.tdo
        st = self.state
        I = self.I
        # ---------------- rising edge
        self._mode_fsm(st)
        self._unlock(st)
        self._bridge(st, tdi)
        if st == J.CAPT_IR:
            self.ir_sh = self.spec.ir_capture
        elif st == J.SHIFT_IR:
            self.ir_sh = (self.ir_sh >> 1) | (tdi << (self.spec.ir_length - 1))
        sel = self._dr_sel()
        if st == J.CAPT_DR:
            self.bypass = 0
            if sel == "IDCODE":
                self.id_sh = self.spec.idcode(self.id_version)
            if self.ir in (I["EXTEST"], I["SAMPLE_PRELOAD"]):
                self.bsr_sh = self._bsr_capture()
            if self.ir == I["TC_MODE"]:
                busy = 1 if self.phase else 0
                self.sh_mode = (self.last_err << 8) | (self.opts << 4) | (busy << 3) | self.cur_mode
            if self.ir == I["TC_STATUS"]:
                self.sh_stat = self._status_word()
            if self.ir == I["TC_UNLOCK"]:
                self.sh_unl = (int(self.lockout) << 9) | (int(self.unlocked) << 8) | self.attempts
        elif st == J.SHIFT_DR:
            self.bypass = tdi
            if sel == "IDCODE":
                self.id_sh = (self.id_sh >> 1) | (tdi << 31)
            if self.ir in (I["EXTEST"], I["SAMPLE_PRELOAD"]):
                self.bsr_sh = (self.bsr_sh >> 1) | (tdi << (self.bsr_len - 1))
            if self.ir == I["TC_MODE"]:
                self.sh_mode = (self.sh_mode >> 1) | (tdi << 11)
            if self.ir == I["TC_STATUS"]:
                self.sh_stat = (self.sh_stat >> 1) | (tdi << 31)
            if self.ir == I["TC_UNLOCK"]:
                self.sh_unl = (self.sh_unl >> 1) | (tdi << 63)
        self.state = J.tap_next(st, tms)
        self.tck_count += 1
        self._advance_sys(self.ratio)
        # ---------------- falling edge
        old_ir = self.ir
        if self.state == J.SHIFT_IR:
            mux = self.ir_sh & 1
        else:
            mux = self._dr_tdo(old_ir)
        if self.state == J.TLR:
            self.ir = I["IDCODE"]
        elif self.state == J.UPDATE_IR:
            self.ir = self.ir_sh
        if self.state == J.UPDATE_DR and old_ir in (I["EXTEST"], I["SAMPLE_PRELOAD"]):
            self.bsr_up = self.bsr_sh
        self.tdo = mux
        return sample

    def tdo_enabled(self) -> bool:
        return self.state in (J.SHIFT_DR, J.SHIFT_IR)

    def _dr_sel(self, ir: Optional[int] = None) -> str:
        ir = self.ir if ir is None else ir
        I = self.I
        if ir in (I["EXTEST"], I["SAMPLE_PRELOAD"]):
            return "BSR"
        for n in ("IDCODE", "TC_STATUS", "TC_MODE", "TC_UNLOCK", "TC_REG"):
            if ir == I[n]:
                return n
        return "BYPASS"

    def _dr_tdo(self, ir: int) -> int:
        sel = self._dr_sel(ir)
        return {"BSR": self.bsr_sh, "IDCODE": self.id_sh, "TC_STATUS": self.sh_stat, "TC_MODE": self.sh_mode,
                "TC_UNLOCK": self.sh_unl, "TC_REG": self.sh_reg, "BYPASS": self.bypass}[sel] & 1

    # ================================================================ BSR
    def core_outputs(self):
        out_d = (self.pc >> 8) & 0xF
        io_d = (self.pc >> 2) & 0xFF
        return out_d, 0xF, io_d, 0x0F

    def _bsr_capture(self) -> int:
        out_d, out_oe, io_d, io_oe = self.core_outputs()
        v = 0
        ni, no = self.n_in, self.n_out
        for i in range(ni):
            v |= ((self.in_pad >> i) & 1) << i
        for o in range(no):
            v |= ((out_d >> o) & 1) << (ni + 2 * o)
            v |= ((out_oe >> o) & 1) << (ni + 2 * o + 1)
        for b in range(self.n_bd):
            base = ni + 2 * no + 3 * b
            v |= ((self.io_pad_i >> b) & 1) << base
            v |= ((io_d >> b) & 1) << (base + 1)
            v |= ((io_oe >> b) & 1) << (base + 2)
        return v

    def pads(self):
        """Return (out_pad, out_oe, io_pad, io_oe) as driven by TestCore."""
        I = self.I
        out_d, out_oe, io_d, io_oe = self.core_outputs()
        ext = self.ir in (I["EXTEST"], I["CLAMP"])
        hz = self.ir == I["HIGHZ"]
        ni, no = self.n_in, self.n_out
        o_d = o_e = b_d = b_e = 0
        for o in range(no):
            d = (self.bsr_up >> (ni + 2 * o)) & 1 if ext else (out_d >> o) & 1
            e = 0 if hz else ((self.bsr_up >> (ni + 2 * o + 1)) & 1 if ext else (out_oe >> o) & 1)
            o_d |= d << o
            o_e |= e << o
        for b in range(self.n_bd):
            base = ni + 2 * no + 3 * b
            d = (self.bsr_up >> (base + 1)) & 1 if ext else (io_d >> b) & 1
            e = 0 if hz else ((self.bsr_up >> (base + 2)) & 1 if ext else (io_oe >> b) & 1)
            b_d |= d << b
            b_e |= e << b
        return o_d, o_e, b_d, b_e

    # ================================================================ TC_STATUS
    def _status_word(self) -> int:
        mb, lb = self.mb_res, self.lb
        sys_in_rst = 1 if self.sys_hold() else 0
        return ((self.spec.status_marker << 24) | (int(self.req_busy()) << 23) | (int(self.halted) << 22) |
                (int(lb["pass_"]) << 21) | (int(lb["done"]) << 20) | (int(lb["busy"]) << 19) |
                (int(mb["fail"]) << 18) | (int(mb["done"]) << 17) | (int(mb["busy"]) << 16) |
                (sys_in_rst << 15) | (self.attempts << 12) | (self.lc() << 9) | (int(self.lockout) << 8) |
                (int(self.unlocked) << 7) | (self.last_err << 4) | ((1 if self.phase else 0) << 3) | self.cur_mode)

    # ================================================================ mode FSM (port of tc_mode_ctrl)
    def _mode_fsm(self, st: int) -> None:
        M, E = self.M, self.E
        tlr = st == J.TLR
        bscan = self._bscan_inv()
        mode_req = st == J.UPDATE_DR and self.ir == self.I["TC_MODE"]
        rq_mode, rq_opts, rq_magic = self.sh_mode & 7, (self.sh_mode >> 4) & 0xF, (self.sh_mode >> 8) & 0xF
        real_req = mode_req and rq_magic != 0
        last = self.settle - 1
        before_hold = self.sys_hold()
        prev_mode, prev_phase = self.cur_mode, self.phase
        if self.phase == 1:                                    # ENTER
            if tlr or bscan or not self._perm(self.target):
                if not tlr:
                    self.last_err = E["ABORTED"]
                if self.target == M["SCAN_TEST"]:
                    self.cur_mode, self.phase, self.cnt = M["SCAN_TEST"], 2, 0
                else:
                    self.cur_mode, self.phase, self.opts = M["NORMAL"], 0, 0
            else:
                if real_req:
                    self.last_err = E["BUSY"]
                c = self.cnt
                self.cnt = (c + 1) % self.settle
                if self.target == M["SCAN_TEST"]:
                    self.clk_stop = 1
                    if c == self.settle // 2:
                        self.clk_test_sel = 1
                if c == last:
                    self.cur_mode, self.phase, self.cnt = self.target, 0, 0
        elif self.phase == 2:                                  # EXIT (scan)
            if real_req:
                self.last_err = E["BUSY"]
            c = self.cnt
            self.cnt = (c + 1) % self.settle
            if c == self.settle // 4:
                self.clk_test_sel = 0
            if c == (3 * self.settle) // 4:
                self.clk_stop = 0
            if c == last:
                self.clk_test_sel = self.clk_stop = 0
                self.cur_mode, self.phase, self.cnt, self.opts = M["NORMAL"], 0, 0, 0
        else:
            cur = self.cur_mode
            if cur == M["JTAG"]:
                if not bscan:
                    self.cur_mode = M["NORMAL"]
                elif real_req:
                    self.last_err = E["ILLEGAL"]
            elif cur != M["NORMAL"] and (tlr or bscan or not self._perm(cur)):
                if not tlr:
                    self.last_err = E["ABORTED"]
                if cur == M["SCAN_TEST"]:
                    self.phase, self.cnt = 2, 0
                else:
                    self.cur_mode, self.opts = M["NORMAL"], 0
            elif bscan:
                self.cur_mode = M["JTAG"]
            elif real_req:
                if rq_magic != self.spec.mode_magic:
                    self.last_err = E["BAD_MAGIC"]
                elif rq_mode == cur:
                    self.last_err = E["NONE"]
                elif rq_mode == M["NORMAL"]:
                    self.last_err = E["NONE"]
                    if cur == M["SCAN_TEST"]:
                        self.phase, self.cnt = 2, 0
                    else:
                        self.cur_mode, self.opts = M["NORMAL"], 0
                elif rq_mode not in (M["MEMORY_BIST"], M["LOGIC_TEST"], M["SCAN_TEST"], M["DIAGNOSTIC"]) \
                        or cur != M["NORMAL"]:
                    self.last_err = E["ILLEGAL"]
                elif not self._perm(rq_mode):
                    self.last_err = E["DENIED"]
                else:
                    self.last_err = E["NONE"]
                    self.target, self.opts, self.phase, self.cnt = rq_mode, rq_opts, 1, 0
        self._mode_side_effects(prev_mode, prev_phase, before_hold)

    def _mode_side_effects(self, prev_mode: int, prev_phase: int, before_hold: bool) -> None:
        M = self.M
        now_hold = self.sys_hold()
        if now_hold and not before_hold:
            self.rst_count = min(self.rst_count + 1, M32)
            self.cause |= 1 << 5
        if before_hold and not now_hold:
            self.core_reset()
        scan_hold_before = prev_mode == M["SCAN_TEST"] or (prev_phase == 1 and self.target == M["SCAN_TEST"])
        scan_hold_now = self.cur_mode == M["SCAN_TEST"] or (self.phase == 1 and self.target == M["SCAN_TEST"])
        if scan_hold_before and not scan_hold_now:
            self._tc_reset(por=False)
            self.core_reset()
        # leaving MEMORY_BIST / LOGIC_TEST aborts running engines
        if self.mode_sys() != M["MEMORY_BIST"] and self.mb_res["busy"]:
            self.mb_res.update(busy=False, aborted=True, done=False)
        if self.mode_sys() != M["LOGIC_TEST"] and self.lb["busy"]:
            self.lb.update(busy=False, aborted=True, done=False)
        diag = self.mode_sys() == M["DIAGNOSTIC"]
        if not diag:
            self.dbg["halt_req"] = False
        elif not self.dbg["diag_q"] and (self.opts & 1):
            self.dbg["halt_req"] = True
        self.dbg["diag_q"] = diag

    # ================================================================ unlock
    def _unlock(self, st: int) -> None:
        if not (st == J.UPDATE_DR and self.ir == self.I["TC_UNLOCK"]) or self.lockout:
            return
        key = self.sh_unl
        if key == 0:
            self.unlocked = False
        elif self.otp_valid and self.lc() != 7 and self.unlock_key != 0 and key == self.unlock_key:
            self.unlocked, self.attempts = True, 0
        else:
            self.unlocked = False
            self.attempts = (self.attempts + 1) & 7
            if self.attempts >= self.spec.unlock_max_attempts:
                self.lockout = True

    # ================================================================ register bridge
    def req_busy(self) -> bool:
        return self.req_pending and self.tck_count < self.req_ready_at

    def _bridge(self, st: int, tdi: int) -> None:
        if self.ir != self.I["TC_REG"]:
            return
        S, O = self.spec.reg_status, self.spec.reg_ops
        busy = self.req_busy()
        if st == J.CAPT_DR:
            if busy or self.sticky:
                self.sh_reg = S["BUSY"] << 44
            else:
                status, addr, data = self.res
                self.sh_reg = (status << 44) | (addr << 32) | data
            if busy:
                self.sticky = True
        elif st == J.SHIFT_DR:
            self.sh_reg = (self.sh_reg >> 1) | (tdi << 45)
        elif st == J.UPDATE_DR:
            op = (self.sh_reg >> 44) & 3
            if self.sticky:
                if op == O["CLEAR_BUSY"] and not busy:
                    self.sticky = False
            elif op in (O["READ"], O["WRITE"]):
                if busy:
                    self.sticky = True
                else:
                    addr, data = (self.sh_reg >> 32) & 0xFFF, self.sh_reg & M32
                    we = op == O["WRITE"]
                    err, rdata = self.access(addr, we, data, is_jtag=True)
                    self.res = (S["ERROR"] if err else S["OK"], addr, 0 if we else rdata)
                    self.req_pending, self.req_ready_at = True, self.tck_count + self.reg_latency_tck

    # ================================================================ system clock domain
    def _advance_sys(self, n: int) -> None:
        for _ in range(n):
            self.sys_cycle += 1
            mb, lb = self.mb_res, self.lb
            if mb["busy"] and self.sys_cycle >= mb["busy_until"]:
                mb["busy"], mb["done"] = False, True
            if lb["busy"] and self.sys_cycle >= lb["busy_until"]:
                lb["busy"], lb["done"] = False, True
                lb["pass_"] = (lb["sig"] == lb["sig_exp"]) and lb["npat"] != 0
            if self.mode_sys() == self.M["MEMORY_BIST"]:
                self.err_cnt[1] = min(self.err_cnt[1] + 1, 0xFFFF)
            self._core_tick()

    def _core_tick(self) -> None:
        if self.sys_hold():
            return
        dbg = self.dbg
        if dbg["halt_req"] and not self.halted:
            self.halted = True
        elif not dbg["halt_req"] and self.halted:
            self.halted = False
        if not self.halted:
            self._exec_one()
        if dbg["cmd_busy"]:
            dbg["cmd_busy"] = False
            r = dbg["regno"]
            if not self.halted or r > 32:
                dbg["cmd_err"] = True
            elif r == 32:
                if dbg["cmd_we"]:
                    self.pc = dbg["data"]
                else:
                    dbg["data"] = self.pc
            elif dbg["cmd_we"]:
                if r:
                    self.x[r] = dbg["data"]
            else:
                dbg["data"] = 0 if r == 0 else self.x[r]

    def _exec_one(self) -> None:
        t = self.trace
        if self.icount % 4 == 3 and t["enable"] and not (t["stop_on_halt"] and self.halted):
            t["buf"][t["wp"]] = self.pc
            t["wp"] = (t["wp"] + 1) % 16
            if t["count"] == 16:
                t["wrapped"] = True
            else:
                t["count"] += 1
        if self.icount % 37 == 36:
            self.err_cnt[0] = min(self.err_cnt[0] + 1, 0xFFFF)
        self.pc = (self.pc + 4) & M32
        self.x[1] = (self.x[1] + 1) & M32
        self.icount += 1

    # ================================================================ register map
    def access(self, addr: int, we: bool, data: int, is_jtag: bool):
        s = self.spec
        mode = self.mode_sys()
        ok = s.reg_write_ok(addr, is_jtag, mode) if we else s.reg_read_ok(addr, is_jtag, mode)
        if not ok:
            self.denied = min(self.denied + 1, 0xFF)
            return True, 0
        if we:
            self._write(addr, data, is_jtag)
            return False, 0
        return False, self._read(addr) & M32

    def _write(self, a: int, d: int, is_jtag: bool) -> None:
        R = self.R
        mb, res, lb, dbg, tr = self.mb, self.mb_res, self.lb, self.dbg, self.trace
        if a == R["SCRATCH"]:
            self.scratch = d
        elif a == R["RESET_CAUSE"]:
            self.cause &= ~(d & 0x3F)
        elif a == R["SW_RST"] and d == self.spec.constants["SW_RST_KEY"]:
            self.cause |= (1 << 4) if is_jtag else (1 << 3)
            self.rst_count += 1
            self.core_reset()
        elif a == R["ERR_CLR"]:
            for i in range(8):
                if (d >> i) & 1:
                    self.err_cnt[i] = 0
        elif a == R["DBG_CTRL"]:
            if (d >> 1) & 1 and self.halted and dbg["halt_req"]:
                self._exec_one()
            dbg["halt_req"] = bool(d & 1)
            if (d >> 2) & 1:
                self.cause |= 1 << 4
                self.rst_count += 1
                self.core_reset()
                dbg["havereset"] = True
            if (d >> 3) & 1:
                dbg["havereset"] = False
        elif a == R["DBG_CMD"]:
            if not dbg["cmd_busy"]:
                if not self.halted:
                    dbg["cmd_err"] = True
                else:
                    dbg.update(cmd_busy=True, cmd_err=False, cmd_we=bool((d >> 16) & 1), regno=d & 0x3F)
        elif a == R["DBG_DATA"]:
            if not dbg["cmd_busy"]:
                dbg["data"] = d
        elif a == R["TRACE_CTRL"]:
            tr["enable"], tr["stop_on_halt"] = bool(d & 1), bool((d >> 2) & 1)
            if (d >> 1) & 1:
                tr.update(wp=0, count=0, wrapped=False)
        elif a == R["TRACE_IDX"]:
            tr["idx"] = d & 0xFFFF
        # ---- MBIST
        elif a == R["MBIST_CTRL"]:
            if (d >> 1) & 1 and res["busy"]:
                res.update(busy=False, aborted=True, done=False)
                return
            if not res["busy"]:
                mb.update(algo=(d >> 2) & 0xF, bg=(d >> 6) & 7, sof=(d >> 9) & 1, sigchk=(d >> 10) & 1)
                if d & 1 and self.mode_sys() == self.M["MEMORY_BIST"]:
                    self._mbist_start()
        elif a == R["MBIST_MEM_SEL"] and not res["busy"]:
            mb["sel"] = d & ((1 << len(self.mems)) - 1)
        elif a == R["MBIST_BG_USER"] and not res["busy"]:
            mb["bg_user"] = d
        elif a == R["MBIST_PAUSE"] and not res["busy"]:
            mb["pause"] = d
        elif a == R["MBIST_SIG_EXP"]:
            mb["sig_exp"] = d
        elif a == R["MBIST_LOG_IDX"]:
            mb["log_idx"] = d & 0xF
        elif a == R["MBIST_MEM_IDX"]:
            mb["mem_idx"] = d & 0x1F
        elif R["MBIST_UALG0"] <= a <= R["MBIST_UALG7"] and not res["busy"]:
            mb["ualg"][(a - R["MBIST_UALG0"]) // 4] = d & 0x3FFFF
        # ---- LBIST
        elif a == R["LBIST_SEED"] and not lb["busy"]:
            lb["seed"] = d
        elif a == R["LBIST_PATTERNS"] and not lb["busy"]:
            lb["npat"] = d
        elif a == R["LBIST_SIG_EXP"]:
            lb["sig_exp"] = d
        elif a == R["LBIST_CTRL"]:
            if (d >> 1) & 1 and lb["busy"]:
                lb.update(busy=False, aborted=True, done=False)
            elif d & 1 and not lb["busy"] and self.mode_sys() == self.M["LOGIC_TEST"]:
                seed = lb["seed"] or 1
                lb.update(sig=lbist_signature(seed, lb["npat"]), busy=True, done=False, pass_=False,
                          aborted=False, busy_until=self.sys_cycle + lb["npat"] + 3)

    def _mbist_start(self) -> None:
        mb, res = self.mb, self.mb_res
        algo = mb["algo"]
        if algo == 15:
            elems = list(mb["ualg"])
        else:
            name = self.spec.algorithm_names.get(algo)
            elems = list(self.spec.algorithms[name]["elements"]) if name else []
        out = run_march(self.mems, self.mem_models, mb["sel"], lambda: elems, mb["bg"], mb["bg_user"],
                        mb["pause"], bool(mb["sof"]), bool(mb["sigchk"]), mb["sig_exp"],
                        self.cfg["log_depth"], self.cfg["max_lat"], cyc0=self.sys_cycle,
                        last_elem=res["cur_elem"])
        res.update(busy=True, busy_until=self.sys_cycle + out.cycles + 2, done=False, fail=out.fail,
                   stopped=out.stopped, aborted=False, log_ovf=out.log_ovf, sig_fail=out.sig_fail,
                   fail_mems=out.fail_mems, fail_count=out.fail_count, misr=out.misr, acc_synd=out.acc_synd,
                   log=list(out.log), cur_mem=(out.log[0][0] if (out.stopped and out.log) else len(self.mems)),
                   cur_elem=out.last_elem)

    def _read(self, a: int) -> int:
        R, s = self.R, self.spec
        mb, res, lb, dbg, tr = self.mb, self.mb_res, self.lb, self.dbg, self.trace
        v = s.raw["ip_version"]
        n = len(self.mems)
        if a == R["TC_MAGIC"]:
            return s.constants["TC_MAGIC_VALUE"]
        if a == R["TC_VERSION"]:
            return (v["major"] << 16) | (v["minor"] << 8) | v["patch"]
        if a == R["SILICON_REV"]:
            return self.silicon_rev << 8
        if a == R["IDCODE"]:
            return s.idcode(self.id_version)
        if a == R["ECID_LO"]:
            return self.ecid & M32
        if a == R["ECID_HI"]:
            return self.ecid >> 32
        if a == R["SEC_STATUS"]:
            return (self.denied << 16) | (self.attempts << 8) | (int(self.lockout) << 4) | \
                   (int(self.unlocked) << 3) | self.lc()
        if a == R["MODE_STATUS"]:
            ms = self.mode_sys()
            return ((self.opts if ms == self.M["DIAGNOSTIC"] else 0) << 4) | ms
        if a == R["RESET_CAUSE"]:
            return self.cause
        if a == R["RESET_COUNT"]:
            return self.rst_count
        if a == R["CLK_STATUS"]:
            return (0x01 << 8) | (self.clk_stop << 3) | (self.clk_test_sel << 2) | 0b11
        if a == R["CLK_MEAS"]:
            c = self.cfg["clocks_ns"]
            return int(self.cfg["ref_window"] * c["ref"] / c["sys"])
        if a == R["CLK_CYCLES"]:
            return self.sys_cycle & M32
        if a == R["SCRATCH"]:
            return self.scratch
        if a == R["CAPS"]:
            return (self.cfg["log_depth"] << 16) | (1 << 13) | (1 << 12) | (self.cfg["num_err"] << 8) | n
        if R["ERR_CNT0"] <= a <= R["ERR_CNT7"]:
            return self.err_cnt[(a - R["ERR_CNT0"]) // 4]
        if a == R["ERR_SUMMARY"]:
            return sum((1 << i) for i in range(8) if self.err_cnt[i])
        if a == R["DBG_CTRL"]:
            return int(dbg["halt_req"])
        if a == R["DBG_STATUS"]:
            diag = self.mode_sys() == self.M["DIAGNOSTIC"]
            return ((int(diag) << 8) | (int(dbg["cmd_err"]) << 5) | (int(dbg["cmd_busy"]) << 4) |
                    (int(dbg["havereset"]) << 3) | (int(dbg["halt_req"] and diag) << 2) |
                    (int(not self.halted) << 1) | int(self.halted))
        if a == R["DBG_PC"]:
            return self.pc
        if a == R["DBG_CMD"]:
            return (int(dbg["cmd_we"]) << 16) | dbg["regno"]
        if a == R["DBG_DATA"]:
            return dbg["data"]
        if a == R["ACC_DIAG0"]:
            return self.pc
        if a in (R["ACC_DIAG1"], R["ACC_DIAG2"], R["ACC_DIAG3"]):
            return 0xACCE0000 | ((a - R["ACC_DIAG0"]) // 4)
        # ---- MBIST
        if a == R["MBIST_CTRL"]:
            return (mb["sigchk"] << 10) | (mb["sof"] << 9) | (mb["bg"] << 6) | (mb["algo"] << 2)
        if a == R["MBIST_MEM_SEL"]:
            return mb["sel"]
        if a == R["MBIST_STATUS"]:
            return ((min(len(res["log"]), 31) << 16) | ((res["cur_elem"] & 7) << 12) | ((res["cur_mem"] & 0xF) << 8) |
                    (int(res["sig_fail"]) << 6) | (int(res["log_ovf"]) << 5) | (int(res["aborted"]) << 4) |
                    (int(res["stopped"]) << 3) | (int(res["fail"]) << 2) | (int(res["done"]) << 1) | int(res["busy"]))
        if a == R["MBIST_FAIL_MEMS"]:
            return res["fail_mems"]
        if a == R["MBIST_FAIL_COUNT"]:
            return res["fail_count"]
        if a == R["MBIST_BG_USER"]:
            return mb["bg_user"]
        if a == R["MBIST_PAUSE"]:
            return mb["pause"]
        if a == R["MBIST_SIG"]:
            return res["misr"]
        if a == R["MBIST_SIG_EXP"]:
            return mb["sig_exp"]
        if a == R["MBIST_LOG_IDX"]:
            return mb["log_idx"]
        if a in (R["MBIST_LOG_INFO"], R["MBIST_LOG_SYND0"], R["MBIST_LOG_SYND1"], R["MBIST_LOG_SYND2"]):
            i = mb["log_idx"]
            if i >= len(res["log"]):
                return 0
            mi, e, o, ad, synd = res["log"][i]
            if a == R["MBIST_LOG_INFO"]:
                return (1 << 31) | (mi << 26) | (e << 23) | (o << 20) | ad
            k = (a - R["MBIST_LOG_SYND0"]) // 4
            return (synd >> (32 * k)) & M32
        if a in (R["MBIST_ACC_SYND0"], R["MBIST_ACC_SYND1"], R["MBIST_ACC_SYND2"]):
            return (res["acc_synd"] >> (32 * ((a - R["MBIST_ACC_SYND0"]) // 4))) & M32
        if a == R["MBIST_NUM_MEMS"]:
            return n
        if a == R["MBIST_MEM_IDX"]:
            return mb["mem_idx"]
        if a in (R["MBIST_MEM_INFO0"], R["MBIST_MEM_INFO1"]):
            i = mb["mem_idx"]
            if i >= n:
                return 0
            m = self.mems[i]
            if a == R["MBIST_MEM_INFO0"]:
                return (1 << 15) | (m.wr2rd << 13) | (m.mtype << 11) | (m.latency << 8) | m.width
            return m.depth - 1
        if R["MBIST_UALG0"] <= a <= R["MBIST_UALG7"]:
            return mb["ualg"][(a - R["MBIST_UALG0"]) // 4]
        # ---- LBIST
        if a == R["LBIST_CTRL"]:
            return 0
        if a == R["LBIST_STATUS"]:
            return (int(lb["aborted"]) << 3) | (int(lb["pass_"]) << 2) | (int(lb["done"]) << 1) | int(lb["busy"])
        if a == R["LBIST_SEED"]:
            return lb["seed"]
        if a == R["LBIST_PATTERNS"]:
            return lb["npat"]
        if a == R["LBIST_SIG"]:
            return lb["sig"] if (lb["done"] or lb["busy"]) else 0
        if a == R["LBIST_SIG_EXP"]:
            return lb["sig_exp"]
        # ---- trace
        if a == R["TRACE_CTRL"]:
            return (int(tr["stop_on_halt"]) << 2) | int(tr["enable"])
        if a == R["TRACE_STATUS"]:
            return (4 << 24) | (int(tr["wrapped"]) << 16) | tr["count"]
        if a == R["TRACE_IDX"]:
            return tr["idx"]
        if a == R["TRACE_DATA"]:
            if tr["idx"] >= tr["count"]:
                return 0
            rp = (tr["wp"] + tr["idx"]) % 16 if tr["count"] == 16 else tr["idx"]
            return tr["buf"][rp]
        return 0


class SimTransport(J.BitTransport):
    """BitTransport backed by a SimTarget."""

    def __init__(self, target: Optional[SimTarget] = None, **kw):
        self.target = target or SimTarget(**kw)
        self.cycles = 0

    def clock(self, tms: Sequence[int], tdi: Sequence[int], mask=None) -> List[int]:
        out = []
        for t, d in zip(tms, tdi):
            out.append(self.target.clock(t & 1, d & 1))
        self.cycles += len(tms)
        return out

    def set_trst(self, level: int) -> None:
        if not level:
            self.target.trst()
