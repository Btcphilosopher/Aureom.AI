"""JTAG transports: sim (software model), recorder (RTL replay vectors),
ftdi_mpsse (FT2232H/FT232H), openocd (TCL-RPC to any OpenOCD adapter)."""
