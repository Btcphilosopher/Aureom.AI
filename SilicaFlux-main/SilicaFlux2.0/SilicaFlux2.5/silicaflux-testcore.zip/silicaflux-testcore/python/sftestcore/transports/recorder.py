"""TCK-level vector recorder.

Wraps a reference BitTransport (normally the simulation transport), forwards
every clock and records (TMS, TDI, expected TDO) per TCK.  Expected TDO is
'x' when the reference TAP is not in Shift-IR/Shift-DR (TDO high-impedance)
or when the caller's compare mask marks the bit as don't-care.

The file is replayed against the RTL by tb/tb_vector_replay.sv, which is how
the host flows and the Python device model are validated against the actual
design (the same idea as validating ATE patterns in simulation).

Format (one TCK per line):
    # comment
    R <0|1>        TRST* level
    <tms> <tdi> <exp>     exp in {0,1,x}
"""
from __future__ import annotations

from typing import List, Optional, Sequence

from ..jtag import BitTransport


class VectorRecorder(BitTransport):
    def __init__(self, inner: BitTransport, path: str, header: str = ""):
        self.inner = inner
        self.fh = open(path, "w", encoding="utf-8")
        self.count = 0
        self.compared = 0
        if header:
            for line in header.splitlines():
                self.fh.write(f"# {line}\n")

    def _shift_state(self) -> bool:
        tgt = getattr(self.inner, "target", None)
        return tgt.tdo_enabled() if tgt is not None else True

    def clock(self, tms: Sequence[int], tdi: Sequence[int], mask: Optional[Sequence[int]] = None) -> List[int]:
        out = []
        mask = list(mask) if mask is not None else [1] * len(tms)
        for t, d, m in zip(tms, tdi, mask):
            in_shift = self._shift_state()
            o = self.inner.clock([t], [d])[0]
            exp = str(o) if (in_shift and m) else "x"
            if exp != "x":
                self.compared += 1
            self.fh.write(f"{t} {d} {exp}\n")
            self.count += 1
            out.append(o)
        return out

    def set_trst(self, level: int) -> None:
        self.fh.write(f"R {level}\n")
        self.inner.set_trst(level)

    def close(self) -> None:
        self.fh.write(f"# end: {self.count} TCK cycles, {self.compared} compared TDO bits\n")
        self.fh.close()
        self.inner.close()
