"""FTDI MPSSE JTAG transport (FT2232H / FT232H class adapters).

Status: implemented against the FTDI MPSSE command set (AN_108) and unit-tested
against a byte-level fake device; NOT yet validated on hardware.

Pin map (ADBUS):  0 TCK (out), 1 TDI (out), 2 TDO (in), 3 TMS (out),
                  4 TRST* (out, optional, active low).
Requires `pyftdi` for real hardware:  pip install pyftdi
A device object with `write_data(bytes)` and `read_data_bytes(n, attempt)` can
be injected for testing (see python/tests/test_transports.py).

MPSSE opcodes used
  0x8A  disable clock divide-by-5 (60 MHz base clock)
  0x97  disable adaptive clocking      0x8D  disable 3-phase clocking
  0x86  set TCK divisor  (TCK = 60 MHz / ((1 + div) * 2))
  0x80  set ADBUS value/direction       0x85  disable loopback
  0x6B  clock TMS out (TDI held), read TDO, LSB first, out on -ve edge, in on +ve
  0x87  send immediate
TDO bits are returned left-justified in each response byte (MSB = last bit).
"""
from __future__ import annotations

from typing import List, Optional, Sequence

from ..jtag import BitTransport

TCK, TDI, TDO, TMS, TRST = 0x01, 0x02, 0x04, 0x08, 0x10
DIR = TCK | TDI | TMS | TRST


class FtdiMpsseTransport(BitTransport):
    def __init__(self, url: str = "ftdi://ftdi:2232h/1", tck_hz: float = 1e6, device=None):
        if device is None:
            try:
                from pyftdi.ftdi import Ftdi  # type: ignore
            except ImportError as exc:  # pragma: no cover - hardware path
                raise RuntimeError("pyftdi is required for the FTDI transport: pip install pyftdi") from exc
            device = Ftdi()
            device.open_mpsse_from_url(url, direction=DIR, initial=TMS | TRST, frequency=tck_hz)
        self.dev = device
        self.value = TMS | TRST
        div = max(0, int(round(60e6 / (2 * tck_hz))) - 1)
        self.tck_hz = 60e6 / ((1 + div) * 2)
        self._write(bytes([0x8A, 0x97, 0x8D, 0x86, div & 0xFF, (div >> 8) & 0xFF,
                           0x80, self.value, DIR, 0x85]))

    def _write(self, b: bytes) -> None:
        self.dev.write_data(b)

    def _read(self, n: int) -> bytes:
        data = b""
        while len(data) < n:
            chunk = self.dev.read_data_bytes(n - len(data), 4)
            if not chunk:
                raise IOError("FTDI read timeout")
            data += bytes(chunk)
        return data

    @staticmethod
    def build_commands(tms: Sequence[int], tdi: Sequence[int]):
        """Return (command bytes, list of (n_bits) per response byte)."""
        cmd = bytearray()
        groups = []
        i = 0
        n = len(tms)
        while i < n:
            # a TMS command clocks up to 7 bits with a constant TDI value
            k = 1
            while k < 7 and i + k < n and tdi[i + k] == tdi[i]:
                k += 1
            bits = 0
            for j in range(k):
                bits |= (tms[i + j] & 1) << j
            bits |= (tdi[i] & 1) << 7
            cmd += bytes([0x6B, k - 1, bits])
            groups.append(k)
            i += k
        cmd.append(0x87)
        return bytes(cmd), groups

    def clock(self, tms: Sequence[int], tdi: Sequence[int], mask: Optional[Sequence[int]] = None) -> List[int]:
        cmd, groups = self.build_commands(tms, tdi)
        self._write(cmd)
        resp = self._read(len(groups))
        out: List[int] = []
        for byte, k in zip(resp, groups):
            v = byte >> (8 - k)                    # left-justified
            out.extend((v >> j) & 1 for j in range(k))
        return out

    def set_trst(self, level: int) -> None:
        self.value = (self.value | TRST) if level else (self.value & ~TRST)
        self._write(bytes([0x80, self.value, DIR]))

    def close(self) -> None:
        close = getattr(self.dev, "close", None)
        if close:
            close()
