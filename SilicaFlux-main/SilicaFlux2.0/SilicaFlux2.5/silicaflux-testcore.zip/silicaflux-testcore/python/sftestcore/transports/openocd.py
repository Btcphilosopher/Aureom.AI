"""OpenOCD TCL-RPC JTAG driver.

Uses an already running OpenOCD (any adapter OpenOCD supports: J-Link,
FT2232, CMSIS-DAP, ...) via its TCL RPC port (default 6666).  OpenOCD must
declare the TAP, e.g. (see dft/openocd/silicaflux_v.cfg):

    jtag newtap sftc tap -irlen 5 -expected-id 0x15F10001

Status: protocol implemented and unit-tested against a fake TCL server; NOT
yet validated with hardware.  Scans longer than 32 bits are split into
32-bit fields (field 0 is shifted first), which OpenOCD's drscan accepts.
"""
from __future__ import annotations

import socket
from typing import List, Optional

from ..jtag import JtagDriver

TERM = b"\x1a"


class OpenOcdJtag(JtagDriver):
    captures_ir = False      # OpenOCD irscan does not return the captured IR value

    def __init__(self, host: str = "127.0.0.1", port: int = 6666, tap: str = "sftc.tap", sock=None,
                 timeout: float = 10.0):
        self.tap = tap
        if sock is None:
            sock = socket.create_connection((host, port), timeout=timeout)
        self.sock = sock
        self.buf = b""

    def cmd(self, text: str) -> str:
        self.sock.sendall(text.encode() + TERM)
        while TERM not in self.buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise IOError("OpenOCD connection closed")
            self.buf += chunk
        resp, self.buf = self.buf.split(TERM, 1)
        return resp.decode(errors="replace").strip()

    @staticmethod
    def fields(value: int, length: int):
        out = []
        pos = 0
        while pos < length:
            n = min(32, length - pos)
            out.append((n, (value >> pos) & ((1 << n) - 1)))
            pos += n
        return out

    def reset(self, trst: bool = False) -> None:
        if trst:
            self.cmd("jtag_reset 1 0")
            self.cmd("jtag_reset 0 0")
        # arp_init performs a TMS-driven Test-Logic-Reset and re-validates the
        # chain; the following runtest leaves the TAP in Run-Test/Idle.
        self.cmd("jtag arp_init")
        self.cmd("runtest 1")

    def ir_scan(self, value: int, length: int, mask: Optional[int] = None) -> int:
        r = self.cmd(f"irscan {self.tap} 0x{value:x} -endstate IDLE")
        return int(r, 16) if r else 0

    def dr_scan(self, value: int, length: int, mask: Optional[int] = None) -> int:
        f = self.fields(value, length)
        args = " ".join(f"{n} 0x{v:x}" for n, v in f)
        r = self.cmd(f"drscan {self.tap} {args} -endstate IDLE")
        parts: List[str] = r.split()
        out, pos = 0, 0
        for (n, _), p in zip(f, parts):
            out |= int(p, 16) << pos
            pos += n
        return out

    def idle(self, cycles: int) -> None:
        if cycles > 0:
            self.cmd(f"runtest {cycles}")

    def close(self) -> None:
        try:
            self.sock.close()
        except OSError:
            pass
