"""IEEE 1149.1 TAP model and transport-independent JTAG scan API.

Layers
  BitTransport   clocks TMS/TDI bits and returns TDO samples (sim, FTDI MPSSE,
                 vector recorder).  TDO is sampled before each rising TCK edge.
  JtagDriver     scan-level API used by all higher layers:
                   reset(), ir_scan(), dr_scan(), idle()
                 Implementations: BitBangJtag (on a BitTransport) and
                 OpenOcdJtag (sftestcore.transports.openocd).
  SvfWriter      optional tee that writes every scan as SVF (Serial Vector
                 Format) for ATE / third-party JTAG tools; expected TDO and
                 MASK come from the reference transport (simulation).

Scans always start and end in Run-Test/Idle, like the RTL testbenches.
"""
from __future__ import annotations

import abc
from typing import List, Optional, Sequence

# State encodings mirror rtl/tc_pkg.sv
TLR, RTI = 0xF, 0xC
SEL_DR, CAPT_DR, SHIFT_DR, EXIT1_DR, PAUSE_DR, EXIT2_DR, UPDATE_DR = 0x7, 0x6, 0x2, 0x1, 0x3, 0x0, 0x5
SEL_IR, CAPT_IR, SHIFT_IR, EXIT1_IR, PAUSE_IR, EXIT2_IR, UPDATE_IR = 0x4, 0xE, 0xA, 0x9, 0xB, 0x8, 0xD

_NEXT = {
    TLR: (RTI, TLR), RTI: (RTI, SEL_DR), SEL_DR: (CAPT_DR, SEL_IR), CAPT_DR: (SHIFT_DR, EXIT1_DR),
    SHIFT_DR: (SHIFT_DR, EXIT1_DR), EXIT1_DR: (PAUSE_DR, UPDATE_DR), PAUSE_DR: (PAUSE_DR, EXIT2_DR),
    EXIT2_DR: (SHIFT_DR, UPDATE_DR), UPDATE_DR: (RTI, SEL_DR), SEL_IR: (CAPT_IR, TLR),
    CAPT_IR: (SHIFT_IR, EXIT1_IR), SHIFT_IR: (SHIFT_IR, EXIT1_IR), EXIT1_IR: (PAUSE_IR, UPDATE_IR),
    PAUSE_IR: (PAUSE_IR, EXIT2_IR), EXIT2_IR: (SHIFT_IR, UPDATE_IR), UPDATE_IR: (RTI, SEL_DR),
}
STATE_NAMES = {TLR: "TLR", RTI: "RTI", SEL_DR: "SELECT_DR", CAPT_DR: "CAPTURE_DR", SHIFT_DR: "SHIFT_DR",
               EXIT1_DR: "EXIT1_DR", PAUSE_DR: "PAUSE_DR", EXIT2_DR: "EXIT2_DR", UPDATE_DR: "UPDATE_DR",
               SEL_IR: "SELECT_IR", CAPT_IR: "CAPTURE_IR", SHIFT_IR: "SHIFT_IR", EXIT1_IR: "EXIT1_IR",
               PAUSE_IR: "PAUSE_IR", EXIT2_IR: "EXIT2_IR", UPDATE_IR: "UPDATE_IR"}


def tap_next(state: int, tms: int) -> int:
    return _NEXT[state][1 if tms else 0]


def tms_path(src: int, dst: int) -> List[int]:
    """Shortest TMS sequence from src to dst (BFS over the 16-state graph)."""
    if src == dst:
        return []
    from collections import deque
    q = deque([(src, [])])
    seen = {src}
    while q:
        s, p = q.popleft()
        for t in (0, 1):
            n = tap_next(s, t)
            if n == dst:
                return p + [t]
            if n not in seen:
                seen.add(n)
                q.append((n, p + [t]))
    raise ValueError("unreachable")


def int_to_bits(v: int, n: int) -> List[int]:
    return [(v >> i) & 1 for i in range(n)]


def bits_to_int(b: Sequence[int]) -> int:
    v = 0
    for i, x in enumerate(b):
        v |= (x & 1) << i
    return v


class BitTransport(abc.ABC):
    """Clock-level JTAG transport."""

    @abc.abstractmethod
    def clock(self, tms: Sequence[int], tdi: Sequence[int], mask: Optional[Sequence[int]] = None) -> List[int]:
        """Apply len(tms) TCK cycles; return TDO sampled before each rising edge.
        `mask` (1 = compare) is advisory: recorders use it for expected-TDO masks."""

    def set_trst(self, level: int) -> None:  # optional TRST* pin (active low)
        pass

    def close(self) -> None:
        pass


class JtagDriver(abc.ABC):
    """Scan-level JTAG API (all scans start and end in Run-Test/Idle)."""

    @abc.abstractmethod
    def reset(self, trst: bool = False) -> None: ...

    @abc.abstractmethod
    def ir_scan(self, value: int, length: int, mask: Optional[int] = None) -> int: ...

    @abc.abstractmethod
    def dr_scan(self, value: int, length: int, mask: Optional[int] = None) -> int: ...

    @abc.abstractmethod
    def idle(self, cycles: int) -> None: ...

    def close(self) -> None:
        pass


class BitBangJtag(JtagDriver):
    def __init__(self, transport: BitTransport):
        self.t = transport
        self.state = TLR

    def _goto(self, dst: int) -> None:
        p = tms_path(self.state, dst)
        if p:
            self.t.clock(p, [0] * len(p), [0] * len(p))
            self.state = dst

    def reset(self, trst: bool = False) -> None:
        if trst:
            self.t.set_trst(0)
            self.t.set_trst(1)
        self.t.clock([1] * 6, [0] * 6, [0] * 6)
        self.state = TLR
        self._goto(RTI)

    def _scan(self, shift_state: int, value: int, length: int, mask: Optional[int]) -> int:
        self._goto(RTI)
        self._goto(shift_state)
        tms = [0] * (length - 1) + [1]
        m = int_to_bits(((1 << length) - 1) if mask is None else mask, length)
        tdo = self.t.clock(tms, int_to_bits(value, length), m)
        self.state = EXIT1_DR if shift_state == SHIFT_DR else EXIT1_IR
        self._goto(RTI)
        return bits_to_int(tdo)

    def ir_scan(self, value: int, length: int, mask: Optional[int] = None) -> int:
        return self._scan(SHIFT_IR, value, length, mask)

    def dr_scan(self, value: int, length: int, mask: Optional[int] = None) -> int:
        return self._scan(SHIFT_DR, value, length, mask)

    def idle(self, cycles: int) -> None:
        self._goto(RTI)
        if cycles > 0:
            self.t.clock([0] * cycles, [0] * cycles, [0] * cycles)

    def close(self) -> None:
        self.t.close()


class SvfWriter(JtagDriver):
    """Tee: forwards to an inner driver and writes SVF with expected TDO from it."""

    def __init__(self, inner: JtagDriver, path: str, tck_hz: float = 10e6):
        self.inner = inner
        self.fh = open(path, "w", encoding="utf-8")
        self.fh.write("! SVF generated by sftestcore (SilicaFlux TestCore host software)\n")
        self.fh.write("! Expected TDO values come from the reference transport; MASK=0 bits are don't-care.\n")
        self.fh.write(f"FREQUENCY {tck_hz:.0f} HZ;\nENDIR IDLE;\nENDDR IDLE;\n")

    @staticmethod
    def _hex(v: int, n: int) -> str:
        return format(v, "0{}X".format((n + 3) // 4))

    def reset(self, trst: bool = False) -> None:
        if trst:
            self.fh.write("TRST ON;\nTRST OFF;\n")
        self.fh.write("STATE RESET;\nSTATE IDLE;\n")
        self.inner.reset(trst)

    def _scan(self, kind: str, value: int, length: int, mask: Optional[int]) -> int:
        fn = self.inner.ir_scan if kind == "SIR" else self.inner.dr_scan
        out = fn(value, length, mask)
        m = ((1 << length) - 1) if mask is None else mask
        self.fh.write(f"{kind} {length} TDI ({self._hex(value, length)}) TDO ({self._hex(out & m, length)}) "
                      f"MASK ({self._hex(m, length)});\n")
        return out

    def ir_scan(self, value: int, length: int, mask: Optional[int] = None) -> int:
        return self._scan("SIR", value, length, mask)

    def dr_scan(self, value: int, length: int, mask: Optional[int] = None) -> int:
        return self._scan("SDR", value, length, mask)

    def idle(self, cycles: int) -> None:
        if cycles > 0:
            self.fh.write(f"RUNTEST {cycles} TCK;\n")
        self.inner.idle(cycles)

    def close(self) -> None:
        self.fh.close()
        self.inner.close()
