"""SilicaFlux TestCore host software.

Layers: spec (single-source definitions) -> jtag (TAP model, scan API, SVF)
-> transports (sim, recorder, FTDI MPSSE, OpenOCD) -> device (TestCore
access) -> mbist / debug / flows -> testlog (CSV/JSON, binning) -> cli (sftc).
"""
__version__ = "0.1.0"
