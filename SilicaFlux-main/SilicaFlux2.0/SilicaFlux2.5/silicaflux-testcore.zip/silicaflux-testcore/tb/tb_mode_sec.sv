// =============================================================================
// tb_mode_sec :: test-mode state machine and access-control verification
//  * exhaustive lifecycle x unlock x mode permission matrix (independent
//    reference table in this file, not the generated RTL function)
//  * test-mode -> test-mode, JTAG-via-TC_MODE and undefined codes: ILLEGAL
//  * bad magic, capture-only (magic 0) scans, BUSY during entry sequence
//  * Test-Logic-Reset exits any mode; invasive boundary-scan instruction
//    aborts MEMORY_BIST (running MBIST aborted); relock withdraws permission
//  * unlock attempts / lockout persist across TRST*, cleared only by POR;
//    otp_valid=0 makes unlock impossible
//  * reset policy per mode; SCAN_TEST clock sequencing and TestCore-domain
//    reset; continuous one-hot monitor on the decoded mode outputs
// =============================================================================
`timescale 1ns/1ps
module tb_mode_sec;
  import tc_spec_pkg::*;
  `include "tc_soc_harness.svh"
  `include "tc_tb_common.svh"

  // ---- independent reference permission table
  // lc: 0 TEST, 1 DEV, 2 PROD, 3 RMA, 7 INVALID
  function automatic bit ref_perm(input int lc, input bit unl, input int mode);
    case (mode)
      2, 3, 5: return (lc == 0) || (lc == 1) || ((lc == 2 || lc == 3) && unl);
      4:       return (lc == 0) || ((lc == 1 || lc == 3) && unl);
      default: return 0;
    endcase
  endfunction

  // ---- continuous mutual-exclusion monitor (decoded registered outputs)
  wire [4:0] onehot = {soc.u_tc.u_mode.scan_mode_o, soc.u_tc.u_mode.mbist_mode_o, soc.u_tc.u_mode.lbist_mode_o,
                       soc.u_tc.u_mode.diag_mode_o, soc.u_tc.u_mode.bscan_mode_o};
  int onehot_viol = 0;
  always @(negedge tck) if (por_n && ((onehot & (onehot - 5'd1)) != 0)) onehot_viol++;

  logic [31:0] st;
  task automatic status_fields(output int mode, output int err, output bit unl, output bit lock, output int lc, output int att);
    tc_status(st);
    mode = st[2:0]; err = st[6:4]; unl = st[7]; lock = st[8]; lc = st[11:9]; att = st[14:12];
  endtask

  task automatic req(input int mode, input logic [3:0] opts = 4'h0);
    logic [11:0] c;
    tc_mode_req(3'(mode), opts, c);
  endtask

  task automatic to_normal();
    req(TC_MODE_NORMAL);
    jtag_idle(20);
  endtask

  int m, e, lcs, att; bit u, lk;

  initial begin
    logic [127:0] o; logic d; logic [31:0] v; logic [1:0] rs;
    power_on();
    jclk_n(1'b0, 2);

    tc_status(st);
    `CHECK_EQ(st[31:24], TC_STATUS_MARKER, "TC_STATUS marker")

    // ================= permission matrix
    begin
      logic [7:0] codes [5];
      int         lcdec [5];
      codes[0] = 8'h00; lcdec[0] = 0; codes[1] = 8'h5A; lcdec[1] = 1; codes[2] = 8'hC3; lcdec[2] = 2;
      codes[3] = 8'h96; lcdec[3] = 3; codes[4] = 8'h33; lcdec[4] = 7;
      for (int l = 0; l < 5; l++) begin
        lc_otp = codes[l];
        tc_unlock(64'd0);                                     // relock
        for (int unl = 0; unl < 2; unl++) begin
          if (unl) tc_unlock(DEMO_UNLOCK_KEY);
          status_fields(m, e, u, lk, lcs, att);
          `CHECK_EQ(lcs, lcdec[l], $sformatf("lifecycle decode of OTP 0x%02h", codes[l]))
          `CHECK_EQ(u, (unl == 1 && lcdec[l] != 7), $sformatf("unlock state lc=%0d unl=%0d", lcdec[l], unl))
          for (int mode = 2; mode <= 5; mode++) begin
            bit exp;
            exp = ref_perm(lcdec[l], u, mode);
            req(mode);
            status_fields(m, e, u, lk, lcs, att);
            if (exp) begin
              `CHECK_EQ(m, mode, $sformatf("lc=%0d unl=%0d mode=%0d permitted -> entered", lcdec[l], u, mode))
              `CHECK_EQ(e, 0, "permitted request: no error")
              to_normal();
              status_fields(m, e, u, lk, lcs, att);
              `CHECK_EQ(m, 0, "returned to NORMAL")
            end else begin
              `CHECK_EQ(m, 0, $sformatf("lc=%0d unl=%0d mode=%0d denied -> stays NORMAL", lcdec[l], u, mode))
              `CHECK_EQ(e, TC_MERR_DENIED, "denied request reports DENIED")
            end
          end
        end
      end
      lc_otp = 8'h00; tc_unlock(64'd0);
    end
    sysclk(20);

    // ================= illegal / ambiguous requests
    req(TC_MODE_MEMORY_BIST);
    req(TC_MODE_DIAGNOSTIC);
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ(m, TC_MODE_MEMORY_BIST, "test->test request rejected, mode unchanged")
    `CHECK_EQ(e, TC_MERR_ILLEGAL, "test->test reports ILLEGAL")
    to_normal();
    req(TC_MODE_JTAG);
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ(e, TC_MERR_ILLEGAL, "JTAG cannot be requested through TC_MODE")
    req(7);
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ(e, TC_MERR_ILLEGAL, "undefined mode code rejected")
    load_ir(IR_MODE);
    shift_dr({116'd0, 4'h5, 4'h0, 1'b0, 3'd5}, 12, o);
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ(e, TC_MERR_BAD_MAGIC, "wrong magic rejected")
    `CHECK_EQ(m, 0, "wrong magic: no mode change")
    load_ir(IR_MODE);
    shift_dr('0, 12, o);
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ(e, TC_MERR_BAD_MAGIC, "magic 0 scan is capture-only (error unchanged)")

    // ================= BUSY: second request during the entry sequence (4-bit partial scan)
    load_ir(IR_MODE);
    shift_dr({116'd0, 4'hA, 4'h0, 1'b0, 3'd5}, 12, o);       // DIAGNOSTIC request -> ENTER
    jclk(1, 0, d); jclk(0, 0, d); jclk(0, 0, d);               // Select-DR, Capture-DR, Shift-DR
    for (int i = 0; i < 4; i++) jclk(i == 3, (4'hA >> i) & 1, d);   // new bits land in MAGIC[11:8]
    jclk(1, 0, d); jclk(0, 0, d);                              // Update-DR (still entering), RTI
    jtag_idle(20);
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ(e, TC_MERR_BUSY, "request during entry sequence reports BUSY")
    `CHECK_EQ(m, TC_MODE_DIAGNOSTIC, "first request still completes")
    `CHECK_EQ(sys_rst_n, 1'b1, "DIAGNOSTIC does not reset the system")

    // ================= TLR exits
    tap_reset();
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ(m, 0, "Test-Logic-Reset returns to NORMAL")

    // ================= reset policy + EXTEST abort of a running MBIST
    req(TC_MODE_MEMORY_BIST);
    sysclk(10);
    `CHECK_EQ({sys_rst_n, core_rst_n}, 2'b00, "MEMORY_BIST holds system and core in reset")
    tc_reg_write(TC_R_MBIST_MEM_SEL, 32'b00100, rs);
    tc_reg_write(TC_R_MBIST_CTRL, {21'd0, 1'b0, 1'b0, 3'd0, TC_ALG_MARCH_SS, 2'b01}, rs);
    `CHECK_EQ(rs, TC_REGST_OK, "MBIST start accepted in MEMORY_BIST")
    tc_status(st);
    `CHECK_EQ(st[16], 1'b1, "MBIST running")
    load_ir(IR_EXTEST);
    jtag_idle(10);
    sysclk(5);
    // observe while EXTEST is still in the IR (reading TC_STATUS would end EXTEST)
    `CHECK_EQ(test_mode, TC_MODE_JTAG, "invasive boundary-scan instruction forces JTAG mode")
    `CHECK_EQ(soc.u_tc.u_mbist.aborted, 1'b1, "running MBIST was aborted")
    `CHECK_EQ(sys_rst_n, 1'b0, "system still held in reset in JTAG mode")
    status_fields(m, e, u, lk, lcs, att);              // loads TC_STATUS -> leaves JTAG mode
    `CHECK_EQ(e, TC_MERR_ABORTED, "previous mode reported ABORTED")
    `CHECK_EQ(m, TC_MODE_NORMAL, "non-invasive instruction returns to NORMAL")
    load_ir(IR_IDCODE);
    jtag_idle(10);
    sysclk(12);
    `CHECK_EQ({sys_rst_n, core_rst_n}, 2'b11, "system released after leaving JTAG mode")

    // ================= permission withdrawal (relock) forces exit
    lc_otp = 8'h5A;                                       // DEV
    tc_unlock(DEMO_UNLOCK_KEY);
    tc_reg_write(TC_R_SCRATCH, 32'h1234_5678, rs);
    req(TC_MODE_SCAN_TEST, 4'b0011);
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ(m, TC_MODE_SCAN_TEST, "DEV + unlocked: SCAN_TEST entered")
    `CHECK_EQ({soc.u_tc.u_mode.clk_test_sel_o, soc.u_tc.u_mode.func_clk_stop_o, scan_mode}, 3'b111,
              "SCAN_TEST: functional clock stopped, test clock selected, scan mode")
    `CHECK_EQ(soc.u_tc.dft_scan_cfg_o, 4'b0011, "scan configuration options delivered")
    `CHECK_EQ(soc.u_tc.u_mode.tc_rst_hold_o, 1'b1, "TestCore system domain held for scan")
    tc_unlock(64'd0);                                     // relock
    jtag_idle(24);
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ(m, 0, "relock withdraws SCAN_TEST permission -> NORMAL")
    `CHECK_EQ(e, TC_MERR_ABORTED, "forced exit reported ABORTED")
    `CHECK_EQ({soc.u_tc.u_mode.clk_test_sel_o, soc.u_tc.u_mode.func_clk_stop_o}, 2'b00, "clock sequence unwound")
    sysclk(20);
    tc_reg_read(TC_R_SCRATCH, v, rs);
    `CHECK_EQ(v, 32'd0, "TestCore system-domain state re-initialised after SCAN_TEST")
    lc_otp = 8'h00;

    // ================= unlock attempts and lockout
    lc_otp = 8'hC3;                                       // PROD
    for (int k = 1; k <= 3; k++) begin
      tc_unlock(64'hDEAD_BEEF_0000_0000 + k);
      status_fields(m, e, u, lk, lcs, att);
      `CHECK_EQ(att, k, $sformatf("failed attempt %0d counted", k))
      `CHECK_EQ(lk, 1'b0, "not yet locked out")
    end
    tc_unlock(64'hDEAD_BEEF_0000_0004);
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ(lk, 1'b1, "lockout after 4 failed attempts")
    tc_unlock(DEMO_UNLOCK_KEY);
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ(u, 1'b0, "correct key ignored while locked out")
    #5 trst_n = 0; #20 trst_n = 1; jclk_n(1'b0, 2);
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ(lk, 1'b1, "lockout persists across TRST*")
    power_on(); jclk_n(1'b0, 2);
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ({lk, att}, {1'b0, 32'd0}, "POR clears lockout and attempts")
    tc_unlock(DEMO_UNLOCK_KEY);
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ(u, 1'b1, "correct key unlocks PROD")
    req(TC_MODE_SCAN_TEST);
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ(e, TC_MERR_DENIED, "PROD: SCAN_TEST denied even when unlocked")
    tc_unlock(64'd0);
    otp_valid = 0;
    tc_unlock(DEMO_UNLOCK_KEY);
    status_fields(m, e, u, lk, lcs, att);
    `CHECK_EQ({u, 32'(lcs)}, {1'b0, 32'd7}, "OTP not valid: lifecycle INVALID, unlock impossible")
    otp_valid = 1; lc_otp = 8'h00;

    `CHECK_EQ(onehot_viol, 0, "decoded mode outputs one-hot (mutual exclusion) at every TCK")
    tb_finish("tb_mode_sec");
  end
endmodule
