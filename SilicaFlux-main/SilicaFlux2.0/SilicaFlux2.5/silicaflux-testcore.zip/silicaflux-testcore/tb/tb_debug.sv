// =============================================================================
// tb_debug :: silicon-debug and register-access verification (demo SoC)
//  * identification registers, capabilities (REPAIR=0)
//  * access control over JTAG and APB: denied/unmapped/read-only accesses
//    error out, denied-access counter, CPU cannot reach debug or test controls
//  * TC_REG BUSY: sticky busy, dropped request, CLEAR_BUSY recovery
//  * core debug: halt, frozen PC, GPR/PC read/write, x0 write ignored, bad
//    regno and running-core errors, single step, resume, halt-on-entry,
//    leaving DIAGNOSTIC resumes the core
//  * trace buffer, error counters, accelerator diagnostics, clock status,
//    reset cause (debug reset, software reset via APB), havereset
//  * MBIST over JTAG with failure-log readback (72-bit syndrome)
// =============================================================================
`timescale 1ns/1ps
module tb_debug;
  import tc_spec_pkg::*;
  `include "tc_soc_harness.svh"
  `include "tc_tb_common.svh"

  task automatic req(input int mode, input logic [3:0] opts = 4'h0);
    logic [11:0] c; tc_mode_req(3'(mode), opts, c);
  endtask
  task automatic rd(input logic [11:0] a, output logic [31:0] v);
    logic [1:0] s; tc_reg_read(a, v, s);
    `CHECK_EQ(s, TC_REGST_OK, $sformatf("JTAG read 0x%03h OK", a))
  endtask
  task automatic wrr(input logic [11:0] a, input logic [31:0] v);
    logic [1:0] s; tc_reg_write(a, v, s);
    `CHECK_EQ(s, TC_REGST_OK, $sformatf("JTAG write 0x%03h OK", a))
  endtask
  task automatic dbg_cmd(input int regno, input bit we, output logic [31:0] status);
    wrr(TC_R_DBG_CMD, {15'd0, we, 10'd0, 6'(regno)});
    jtag_idle(4);
    rd(TC_R_DBG_STATUS, status);
  endtask

  initial begin
    logic [31:0] v, v2, st; logic [1:0] s; logic e; logic [45:0] c;
    power_on();
    jclk_n(1'b0, 2);
    sysclk(30);

    // ---------------- identification
    rd(TC_R_TC_MAGIC, v);     `CHECK_EQ(v, TC_TC_MAGIC_VALUE, "TC_MAGIC")
    rd(TC_R_TC_VERSION, v);   `CHECK_EQ(v, {8'd0, TC_IP_MAJOR, TC_IP_MINOR, TC_IP_PATCH}, "TC_VERSION")
    rd(TC_R_SILICON_REV, v);  `CHECK_EQ(v, {DEMO_SILICON_REV, 8'd0}, "SILICON_REV")
    rd(TC_R_IDCODE, v);       `CHECK_EQ(v, {DEMO_IDCODE_VERSION, TC_IDCODE_PART, TC_IDCODE_MFG, 1'b1}, "IDCODE mirror")
    rd(TC_R_ECID_LO, v);      `CHECK_EQ(v, DEMO_ECID[31:0], "ECID_LO")
    rd(TC_R_ECID_HI, v);      `CHECK_EQ(v, DEMO_ECID[63:32], "ECID_HI")
    rd(TC_R_CAPS, v);
    `CHECK_EQ({v[4:0], v[11:8], v[12], v[13], v[14], v[20:16]}, {5'd5, 4'd8, 1'b1, 1'b1, 1'b0, 5'd8},
              "CAPS: 5 memories, 8 error counters, trace, LBIST, no repair, log depth 8")

    // ---------------- access control (JTAG, NORMAL mode)
    tc_reg_write(TC_R_MBIST_CTRL, 32'h1, s);   `CHECK_EQ(s, TC_REGST_ERROR, "MBIST write denied outside MEMORY_BIST")
    tc_reg_read(TC_R_DBG_PC, v, s);           `CHECK_EQ(s, TC_REGST_ERROR, "debug read denied outside DIAGNOSTIC")
    `CHECK_EQ(v, 32'd0, "denied read returns 0")
    tc_reg_write(TC_R_TC_MAGIC, 32'h0, s);     `CHECK_EQ(s, TC_REGST_ERROR, "write to read-only register rejected")
    tc_reg_read(12'h7F0, v, s);               `CHECK_EQ(s, TC_REGST_ERROR, "unmapped address rejected")
    wrr(TC_R_SCRATCH, 32'hA5A5_5A5A);
    rd(TC_R_SCRATCH, v);                      `CHECK_EQ(v, 32'hA5A5_5A5A, "SCRATCH read-back over JTAG")
    rd(TC_R_SEC_STATUS, v);                   `CHECK_EQ(v[23:16], 8'd4, "denied-access counter = 4")

    // ---------------- access control (APB / CPU)
    apb_rd(TC_R_TC_MAGIC, v, e);              `CHECK(!e && v == TC_TC_MAGIC_VALUE, "APB: public read")
    apb_wr(TC_R_MBIST_MEM_SEL, 32'h1, e);     `CHECK_EQ(e, 1'b1, "APB: CPU cannot write MBIST controls")
    apb_rd(TC_R_DBG_PC, v, e);                `CHECK_EQ(e, 1'b1, "APB: CPU cannot read debug state")
    apb_wr(TC_R_DBG_CTRL, 32'h1, e);          `CHECK_EQ(e, 1'b1, "APB: CPU cannot halt the core")
    apb_wr(TC_R_SCRATCH, 32'h0BEE_F00D, e);   `CHECK_EQ(e, 1'b0, "APB: SCRATCH write")
    rd(TC_R_SCRATCH, v);                      `CHECK_EQ(v, 32'h0BEE_F00D, "APB write visible over JTAG")
    apb_rd(TC_R_RESET_CAUSE, v, e);           `CHECK_EQ(v[0], 1'b1, "APB: reset cause POR")
    apb_wr(TC_R_RESET_CAUSE, 32'h3F, e);      `CHECK_EQ(e, 1'b0, "APB: reset cause W1C allowed")
    apb_rd(TC_R_RESET_CAUSE, v, e);           `CHECK_EQ(v, 32'd0, "reset cause cleared")
    apb_wr(TC_R_SW_RST, TC_SW_RST_KEY, e);
    sysclk(40); wait (core_rst_n); sysclk(5);
    apb_rd(TC_R_RESET_CAUSE, v, e);           `CHECK_EQ(v[3], 1'b1, "software reset via APB: cause SW")

    // ---------------- TC_REG BUSY handling
    load_ir(IR_REG);
    func_run = 0;                                        // stall the system clock
    tc_reg_scan(TC_REGOP_READ, TC_R_SCRATCH, 32'd0, c);  // launched, cannot complete
    jtag_idle(4);
    tc_reg_scan(TC_REGOP_WRITE, TC_R_SCRATCH, 32'h1111_1111, c);
    `CHECK_EQ(c[45:44], TC_REGST_BUSY, "capture while in flight reports BUSY")
    func_run = 1; jtag_idle(REG_IDLE);
    tc_reg_scan(TC_REGOP_NOP, 12'd0, 32'd0, c);
    `CHECK_EQ(c[45:44], TC_REGST_BUSY, "sticky BUSY until cleared")
    tc_reg_scan(TC_REGOP_CLEAR_BUSY, 12'd0, 32'd0, c);
    tc_reg_scan(TC_REGOP_NOP, 12'd0, 32'd0, c);
    `CHECK_EQ(c[45:44], TC_REGST_OK, "CLEAR_BUSY recovers")
    `CHECK_EQ(c[31:0], 32'h0BEE_F00D, "first (accepted) request completed")
    rd(TC_R_SCRATCH, v);                      `CHECK_EQ(v, 32'h0BEE_F00D, "request issued while BUSY was dropped")

    // ---------------- core debug
    req(TC_MODE_DIAGNOSTIC);
    rd(TC_R_DBG_STATUS, v);                   `CHECK_EQ(v[1:0], 2'b10, "core running in DIAGNOSTIC")
    dbg_cmd(1, 0, v);                         `CHECK_EQ(v[5], 1'b1, "abstract command on running core -> CMD_ERR")
    wrr(TC_R_DBG_CTRL, 32'h1);
    jtag_idle(4);
    rd(TC_R_DBG_STATUS, v);                   `CHECK_EQ({v[8], v[2], v[0]}, 3'b111, "halt request -> halted")
    rd(TC_R_DBG_PC, v); jtag_idle(30); rd(TC_R_DBG_PC, v2);
    `CHECK_EQ(v2, v, "PC frozen while halted")
    `CHECK_EQ(v, soc.u_core.pc, "DBG_PC matches core PC")
    dbg_cmd(1, 0, st);                        `CHECK_EQ(st[5:4], 2'b00, "GPR read completes without error")
    rd(TC_R_DBG_DATA, v);                     `CHECK_EQ(v, soc.u_core.x[1], "x1 read back")
    wrr(TC_R_DBG_DATA, 32'hDEAD_BEEF);
    dbg_cmd(5, 1, st);                        `CHECK_EQ(st[5:4], 2'b00, "GPR write completes")
    `CHECK_EQ(soc.u_core.x[5], 32'hDEAD_BEEF, "x5 written")
    dbg_cmd(5, 0, st); rd(TC_R_DBG_DATA, v);  `CHECK_EQ(v, 32'hDEAD_BEEF, "x5 read back")
    wrr(TC_R_DBG_DATA, 32'h1234);
    dbg_cmd(0, 1, st); dbg_cmd(0, 0, st); rd(TC_R_DBG_DATA, v);
    `CHECK_EQ(v, 32'd0, "x0 hard-wired zero")
    dbg_cmd(40, 0, st);                       `CHECK_EQ(st[5], 1'b1, "invalid register number -> CMD_ERR")
    wrr(TC_R_DBG_DATA, 32'h8000_1000);
    dbg_cmd(32, 1, st);
    rd(TC_R_DBG_PC, v);                       `CHECK_EQ(v, 32'h8000_1000, "PC written through regno 32")
    wrr(TC_R_DBG_CTRL, 32'h3);                // HALT | STEP
    jtag_idle(4);
    rd(TC_R_DBG_PC, v);                       `CHECK_EQ(v, 32'h8000_1004, "single step advances PC by one instruction")
    rd(TC_R_DBG_STATUS, v);                   `CHECK_EQ(v[0], 1'b1, "still halted after step")

    // trace while running, freeze on halt
    wrr(TC_R_TRACE_CTRL, 32'h2);              // clear
    wrr(TC_R_TRACE_CTRL, 32'h5);              // enable + stop-on-halt
    wrr(TC_R_DBG_CTRL, 32'h0);                // resume
    jtag_idle(4);
    rd(TC_R_DBG_STATUS, v);                   `CHECK_EQ(v[1:0], 2'b10, "resumed")
    jtag_idle(40);
    wrr(TC_R_DBG_CTRL, 32'h1); jtag_idle(4);
    rd(TC_R_TRACE_STATUS, v);
    `CHECK_EQ({v[16], v[15:0]}, {1'b1, 16'd16}, "trace buffer full and wrapped")
    begin
      logic [31:0] t0, t1; int good;
      good = 0;
      wrr(TC_R_TRACE_IDX, 0); rd(TC_R_TRACE_DATA, t0);
      for (int k = 1; k < 16; k++) begin
        wrr(TC_R_TRACE_IDX, k); rd(TC_R_TRACE_DATA, t1);
        if (t1 == t0 + 32'd16) good++;
        t0 = t1;
      end
      `CHECK_EQ(good, 15, "trace entries in order (one entry per 4 instructions)")
    end

    // leaving DIAGNOSTIC resumes the core; halt-on-entry option
    req(TC_MODE_NORMAL); sysclk(10);
    `CHECK_EQ(soc.u_core.halted, 1'b0, "leaving DIAGNOSTIC releases halt")
    req(TC_MODE_DIAGNOSTIC, 4'b0001); sysclk(10);
    `CHECK_EQ(soc.u_core.halted, 1'b1, "halt-on-entry option")

    // error counters (core error event every 37 instructions)
    wrr(TC_R_DBG_CTRL, 32'h0); jtag_idle(100);
    rd(TC_R_ERR_CNT0, v);                     `CHECK(v > 0, "error counter 0 counts events")
    rd(TC_R_ERR_SUMMARY, v);                  `CHECK_EQ(v[0], 1'b1, "error summary bit 0")
    wrr(TC_R_DBG_CTRL, 32'h1); jtag_idle(4);
    wrr(TC_R_ERR_CLR, 32'h1);
    rd(TC_R_ERR_CNT0, v);                     `CHECK_EQ(v, 32'd0, "error counter cleared")
    rd(TC_R_ACC_DIAG1, v);                    `CHECK_EQ(v, 32'hACCE_0001, "accelerator diagnostic word")
    rd(TC_R_CLK_MEAS, v);                     `CHECK(v >= 255 && v <= 257, $sformatf("clock measurement 256 +/-1 (got %0d)", v))
    rd(TC_R_CLK_STATUS, v);                   `CHECK_EQ({v[15:8], v[3:0]}, {8'h01, 4'b0011}, "clock status: PLL locked, measured, functional clock")

    // debug reset (ndmreset) -> cause DEBUG, havereset
    wrr(TC_R_DBG_CTRL, 32'h5);                // HALT | NDMRESET
    jtag_idle(30);
    rd(TC_R_RESET_CAUSE, v);                  `CHECK_EQ(v[4], 1'b1, "debug reset: cause DEBUG")
    rd(TC_R_DBG_STATUS, v);                   `CHECK_EQ(v[3], 1'b1, "havereset set")
    wrr(TC_R_DBG_CTRL, 32'h9);                // HALT | ACK_HAVERESET
    rd(TC_R_DBG_STATUS, v);                   `CHECK_EQ(v[3], 1'b0, "havereset acknowledged")
    req(TC_MODE_NORMAL); sysclk(10);

    // ---------------- MBIST over JTAG with failure-log readback
    soc.g_mem[2].u_mem.set_fault(1, 5, 65, 0, 0, 0);
    req(TC_MODE_MEMORY_BIST);
    wrr(TC_R_MBIST_MEM_SEL, 32'b00100);
    wrr(TC_R_MBIST_CTRL, {21'd0, 1'b0, 1'b0, 3'd0, TC_ALG_MARCH_C_MINUS, 2'b01});
    jtag_idle(1500);
    rd(TC_R_MBIST_STATUS, v);                 `CHECK_EQ(v[2:0], 3'b110, "JTAG MBIST: done, fail")
    rd(TC_R_MBIST_FAIL_MEMS, v);              `CHECK_EQ(v, 32'b00100, "JTAG MBIST: L2 failing")
    wrr(TC_R_MBIST_LOG_IDX, 0);
    rd(TC_R_MBIST_LOG_INFO, v);               `CHECK_EQ(v, {1'b1, 1'b0, 4'd2, 3'd2, 3'd0, 20'd5}, "JTAG MBIST: log entry 0")
    rd(TC_R_MBIST_LOG_SYND2, v);              `CHECK_EQ(v, 32'h2, "JTAG MBIST: syndrome bit 65")
    soc.g_mem[2].u_mem.set_fault(0, 0, 0, 0, 0, 0);
    req(TC_MODE_NORMAL); sysclk(20);
    apb_rd(TC_R_MBIST_STATUS, v, e);          `CHECK(!e && v[2] == 1'b1, "CPU can read MBIST results after the test")

    tb_finish("tb_debug");
  end
endmodule
