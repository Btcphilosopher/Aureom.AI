// =============================================================================
// SilicaFlux TestCore :: shared testbench utilities (include inside a module)
// Requires in the including module:  logic tck, tms, tdi, trst_n; wire tdo;
//                                     real TCK_HALF;
// =============================================================================

int tb_errors = 0;
int tb_checks = 0;

`define CHECK(cond, msg) \
  begin tb_checks++; if (!(cond)) begin tb_errors++; $display("[%0t] FAIL: %s", $time, msg); end end
`define CHECK_EQ(got, exp, msg) \
  begin tb_checks++; if ((got) !== (exp)) begin tb_errors++; \
    $display("[%0t] FAIL: %s  got=0x%0h exp=0x%0h", $time, msg, (got), (exp)); end end

task automatic tb_finish(input string name);
  $display("--------------------------------------------------------------");
  if (tb_errors == 0) $display("%s: PASS (%0d checks)", name, tb_checks);
  else                $display("%s: FAIL (%0d of %0d checks failed)", name, tb_errors, tb_checks);
  $display("--------------------------------------------------------------");
  $finish;
endtask

// ------------------------------------------------------------------ JTAG BFM
// One TCK cycle: drive TMS/TDI while TCK low, sample TDO just before the
// rising edge (TDO was updated by the DUT on the previous falling edge).
task automatic jclk(input logic t_ms, input logic t_di, output logic t_do);
  tms = t_ms; tdi = t_di;
  #(TCK_HALF);
  t_do = tdo;
  tck = 1'b1;
  #(TCK_HALF);
  tck = 1'b0;
endtask

task automatic jclk_n(input logic t_ms, input int n);
  logic d;
  for (int i = 0; i < n; i++) jclk(t_ms, 1'b0, d);
endtask

task automatic tap_reset();       // TMS high x6 -> TLR, then RTI
  jclk_n(1'b1, 6);
  jclk_n(1'b0, 1);
endtask

task automatic jtag_idle(input int n);   // stay in Run-Test/Idle
  jclk_n(1'b0, n);
endtask

// from RTI, back to RTI
task automatic shift_ir(input logic [7:0] ir, input int len, output logic [7:0] cap);
  logic d;
  cap = '0;
  jclk(1'b1, 1'b0, d);  // Select-DR
  jclk(1'b1, 1'b0, d);  // Select-IR
  jclk(1'b0, 1'b0, d);  // Capture-IR
  jclk(1'b0, 1'b0, d);  // -> Shift-IR
  for (int i = 0; i < len; i++) begin
    jclk(i == len - 1, ir[i], d);
    cap[i] = d;
  end
  jclk(1'b1, 1'b0, d);  // Update-IR
  jclk(1'b0, 1'b0, d);  // RTI
endtask

task automatic load_ir(input logic [7:0] ir);
  logic [7:0] c;
  shift_ir(ir, 5, c);
endtask

task automatic shift_dr(input logic [127:0] din, input int len, output logic [127:0] dout);
  logic d;
  dout = '0;
  jclk(1'b1, 1'b0, d);  // Select-DR
  jclk(1'b0, 1'b0, d);  // Capture-DR
  jclk(1'b0, 1'b0, d);  // -> Shift-DR
  for (int i = 0; i < len; i++) begin
    jclk(i == len - 1, din[i], d);
    dout[i] = d;
  end
  jclk(1'b1, 1'b0, d);  // Update-DR
  jclk(1'b0, 1'b0, d);  // RTI
endtask

// ------------------------------------------------------------------ TestCore host tasks
localparam logic [7:0] IR_EXTEST = 8'h00, IR_SAMPLE = 8'h01, IR_IDCODE = 8'h02, IR_CLAMP = 8'h03,
                       IR_HIGHZ = 8'h04, IR_STATUS = 8'h08, IR_MODE = 8'h09, IR_UNLOCK = 8'h0A,
                       IR_REG = 8'h0B, IR_BYPASS = 8'h1F;
localparam int REG_IDLE = 8;

task automatic tc_status(output logic [31:0] st);
  logic [127:0] o;
  load_ir(IR_STATUS);
  shift_dr('0, 32, o);
  st = o[31:0];
endtask

task automatic tc_mode_req(input logic [2:0] mode, input logic [3:0] opts, output logic [11:0] cap);
  logic [127:0] o;
  load_ir(IR_MODE);
  shift_dr({116'd0, 4'hA, opts, 1'b0, mode}, 12, o);
  jtag_idle(20);                  // > mode_settle_tck
  shift_dr({116'd0, 4'h0, 4'h0, 1'b0, 3'd0}, 12, o);   // magic 0 => rejected, just captures
  cap = o[11:0];
endtask

task automatic tc_unlock(input logic [63:0] key);
  logic [127:0] o;
  load_ir(IR_UNLOCK);
  shift_dr({64'd0, key}, 64, o);
  jtag_idle(2);
endtask

// raw TC_REG scan: returns {status, addr, data} captured
task automatic tc_reg_scan(input logic [1:0] op, input logic [11:0] a, input logic [31:0] d,
                           output logic [45:0] cap);
  logic [127:0] o;
  shift_dr({82'd0, op, a, d}, 46, o);
  cap = o[45:0];
endtask

task automatic tc_reg_read(input logic [11:0] a, output logic [31:0] d, output logic [1:0] st);
  logic [45:0] c;
  load_ir(IR_REG);
  tc_reg_scan(2'd1, a, 32'd0, c);
  jtag_idle(REG_IDLE);
  tc_reg_scan(2'd0, 12'd0, 32'd0, c);
  d = c[31:0]; st = c[45:44];
endtask

task automatic tc_reg_write(input logic [11:0] a, input logic [31:0] d, output logic [1:0] st);
  logic [45:0] c;
  load_ir(IR_REG);
  tc_reg_scan(2'd2, a, d, c);
  jtag_idle(REG_IDLE);
  tc_reg_scan(2'd0, 12'd0, 32'd0, c);
  st = c[45:44];
endtask

