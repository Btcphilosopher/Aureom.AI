// =============================================================================
// SilicaFlux TestCore :: tc_sram_model   (BEHAVIOURAL - testbench only)
// Fault-injectable memory model used to verify the MBIST controller.
//   TYPE 0: single-port 1RW  (ce, we, addr)
//   TYPE 1: two-port 1R1W    (ce = read enable @addr, we = write enable @waddr)
//           Writes become visible to reads WR2RD cycles later (models a
//           compiler restriction: read-after-write needs WR2RD idle cycles).
//   TYPE 2: ROM, content word(a) = ((a*0x9E3779B1) mod 2^32) ^ 0xA5A5A5A5
// Read latency LAT (1 or 2 cycles; rdata holds between reads).
//
// Fault models (one active fault per instance, configured with set_fault()
// or at time 0 with plusargs +fault_mem=<MEM_ID> +fault_type=<n>
// +fault_addr= +fault_bit= +fault_addr2= +fault_bit2= +fault_drf=):
//   0 NONE  1 SA0  2 SA1  3 TF_UP (0->1 fails)  4 TF_DOWN (1->0 fails)
//   5 AF    (accesses to addr are decoded to addr2)
//   6 CFID  (rising write of aggressor addr/bit forces victim addr2/bit2 to 1)
//   7 DRF   (stored 1 at addr/bit decays to 0 after fault_drf cycles w/o write)
//   8 COL_SA0 (bit stuck-at-0 at every address)
// =============================================================================
`timescale 1ns/1ps
module tc_sram_model #(
  parameter int MEM_ID = 0,
  parameter int DW     = 32,
  parameter int DEPTH  = 256,
  parameter int AW     = 8,
  parameter int LAT    = 1,
  parameter int TYPE   = 0,
  parameter int WR2RD  = 0
) (
  input  logic          clk,
  input  logic          ce,
  input  logic          we,
  input  logic [AW-1:0] addr,
  input  logic [AW-1:0] waddr,
  input  logic [DW-1:0] wdata,
  output logic [DW-1:0] rdata
);
  localparam int F_NONE = 0, F_SA0 = 1, F_SA1 = 2, F_TF_UP = 3, F_TF_DOWN = 4,
                 F_AF = 5, F_CFID = 6, F_DRF = 7, F_COL_SA0 = 8;

  logic [DW-1:0] mem [DEPTH];
  longint        last_wr [DEPTH];
  longint        cyc;
  int f_type, f_addr, f_bit, f_addr2, f_bit2, f_drf;
  logic [DW-1:0] q [LAT];

  function automatic logic [31:0] rom_word(input int a);
    logic [31:0] p;
    p = 32'(a) * 32'h9E3779B1;
    return p ^ 32'hA5A5A5A5;
  endfunction

  task automatic set_fault(input int t, input int a, input int b, input int a2, input int b2, input int drf);
    f_type = t; f_addr = a; f_bit = b; f_addr2 = a2; f_bit2 = b2; f_drf = drf;
  endtask

  task automatic init_contents();
    for (int i = 0; i < DEPTH; i++) begin
      if (TYPE == 2) mem[i] = DW'(rom_word(i));
      else           mem[i] = DW'({4{32'(i) * 32'h01000193 ^ 32'h811C9DC5}});
      last_wr[i] = 0;
    end
  endtask

  initial begin
    int m;
    f_type = F_NONE; f_addr = 0; f_bit = 0; f_addr2 = 0; f_bit2 = 0; f_drf = 1000;
    cyc = 0;
    init_contents();
    if ($value$plusargs("fault_mem=%d", m) && m == MEM_ID) begin
      void'($value$plusargs("fault_type=%d", f_type));
      void'($value$plusargs("fault_addr=%d", f_addr));
      void'($value$plusargs("fault_bit=%d", f_bit));
      void'($value$plusargs("fault_addr2=%d", f_addr2));
      void'($value$plusargs("fault_bit2=%d", f_bit2));
      void'($value$plusargs("fault_drf=%d", f_drf));
      $display("[tc_sram_model %0d] fault type=%0d addr=%0d bit=%0d addr2=%0d bit2=%0d drf=%0d",
               MEM_ID, f_type, f_addr, f_bit, f_addr2, f_bit2, f_drf);
    end
  end

  function automatic int eff(input int a);
    return (f_type == F_AF && a == f_addr) ? f_addr2 : a;
  endfunction

  task automatic do_write(input int a_in, input logic [DW-1:0] d);
    int a;
    logic [DW-1:0] old, nw;
    a = eff(a_in);
    if (a < DEPTH) begin
    old = mem[a];
    nw  = d;
    case (f_type)
      F_SA0:     if (a == f_addr) nw[f_bit] = 1'b0;
      F_SA1:     if (a == f_addr) nw[f_bit] = 1'b1;
      F_TF_UP:   if (a == f_addr && !old[f_bit] &&  d[f_bit]) nw[f_bit] = 1'b0;
      F_TF_DOWN: if (a == f_addr &&  old[f_bit] && !d[f_bit]) nw[f_bit] = 1'b1;
      F_COL_SA0: nw[f_bit] = 1'b0;
      default: ;
    endcase
    mem[a] = nw;
    last_wr[a] = cyc;
    if (f_type == F_CFID && a == f_addr && !old[f_bit] && nw[f_bit]) mem[f_addr2][f_bit2] = 1'b1;
    end
  endtask

  function automatic logic [DW-1:0] do_read(input int a_in);
    int a;
    logic [DW-1:0] v;
    a = eff(a_in);
    if (a >= DEPTH) return 'x;
    if (f_type == F_DRF && a == f_addr && mem[a][f_bit] && (cyc - last_wr[a]) >= f_drf)
      mem[a][f_bit] = 1'b0;
    v = mem[a];
    case (f_type)
      F_SA0:     if (a == f_addr) v[f_bit] = 1'b0;
      F_SA1:     if (a == f_addr) v[f_bit] = 1'b1;
      F_COL_SA0: v[f_bit] = 1'b0;
      default: ;
    endcase
    return v;
  endfunction

  // pending writes for TYPE 1 (visibility delay)
  logic          pw_v [WR2RD+1];
  int            pw_a [WR2RD+1];
  logic [DW-1:0] pw_d [WR2RD+1];
  initial for (int i = 0; i <= WR2RD; i++) pw_v[i] = 1'b0;

  always @(posedge clk) begin
    logic [DW-1:0] r;
    logic          rd;
    cyc = cyc + 1;
    rd = 1'b0;
    if (TYPE == 1) begin
      // retire the oldest pending write, then shift
      if (pw_v[WR2RD]) do_write(pw_a[WR2RD], pw_d[WR2RD]);
      for (int i = WR2RD; i > 0; i--) begin
        pw_v[i] = pw_v[i-1]; pw_a[i] = pw_a[i-1]; pw_d[i] = pw_d[i-1];
      end
      pw_v[0] = 1'b0;
      if (ce) begin r = do_read(int'(addr)); rd = 1'b1; end
      if (we) begin
        if (WR2RD == 0) do_write(int'(waddr), wdata);
        else begin pw_v[0] = 1'b1; pw_a[0] = int'(waddr); pw_d[0] = wdata; end
      end
    end else if (ce) begin
      if (we && TYPE != 2) do_write(int'(addr), wdata);
      else if (!we) begin r = do_read(int'(addr)); rd = 1'b1; end
    end
    // read pipeline: rdata appears LAT cycles after the read edge
    if (LAT == 1) begin
      if (rd) q[0] <= r;
    end else begin
      if (rd) q[0] <= r;
      for (int i = 1; i < LAT; i++) q[i] <= q[i-1];
    end
  end
  assign rdata = q[LAT-1];

endmodule
