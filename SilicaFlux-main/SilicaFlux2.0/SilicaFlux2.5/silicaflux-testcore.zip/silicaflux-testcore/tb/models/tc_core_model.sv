// =============================================================================
// SilicaFlux TestCore :: tc_core_model   (BEHAVIOURAL - testbench only)
// Minimal hart implementing the TestCore core-debug port protocol:
//   * running: one "instruction" per clock: pc += 4, x1 += 1, x2 ^= pc;
//     every 4th instruction emits a trace word (pc); every 37th instruction
//     pulses err_evt (a stand-in for a correctable-error event).
//   * halt_req high: pipeline drains for DRAIN cycles, then halted=1, pc frozen.
//   * halt_req low while halted: resumes on the next cycle.
//   * step_req pulse while halted: executes exactly one instruction.
//   * abstract register access (only while halted): ack two cycles after req;
//     regno 0..31 GPR (x0 reads 0, writes ignored), 32 = PC, others -> err.
// =============================================================================
`timescale 1ns/1ps
module tc_core_model #(
  parameter logic [31:0] RESET_PC = 32'h8000_0000,
  parameter int          DRAIN    = 3
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        halt_req,
  input  logic        step_req,
  output logic        halted,
  output logic [31:0] pc,
  input  logic        reg_req,
  input  logic        reg_we,
  input  logic [5:0]  reg_addr,
  input  logic [31:0] reg_wdata,
  output logic        reg_ack,
  output logic [31:0] reg_rdata,
  output logic        reg_err,
  output logic        trace_valid,
  output logic [31:0] trace_data,
  output logic        err_evt
);
  logic [31:0] x [32];
  int          drain_cnt;
  int          icount;
  int          acc_cnt;
  logic        acc_busy;

  task automatic exec_one();
    pc    <= pc + 32'd4;
    x[1]  <= x[1] + 32'd1;
    x[2]  <= x[2] ^ pc;
    icount <= icount + 1;
    trace_valid <= ((icount % 4) == 3);
    trace_data  <= pc;
    err_evt     <= ((icount % 37) == 36);
  endtask

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pc <= RESET_PC; halted <= 1'b0; drain_cnt <= 0; icount <= 0;
      for (int i = 0; i < 32; i++) x[i] <= 32'(i) * 32'h1111_1111;
      trace_valid <= 1'b0; trace_data <= '0; err_evt <= 1'b0;
      reg_ack <= 1'b0; reg_rdata <= '0; reg_err <= 1'b0; acc_busy <= 1'b0; acc_cnt <= 0;
    end else begin
      trace_valid <= 1'b0;
      err_evt     <= 1'b0;
      reg_ack     <= 1'b0;
      if (!halted) begin
        if (halt_req) begin
          if (drain_cnt == DRAIN) halted <= 1'b1;
          else drain_cnt <= drain_cnt + 1;
        end else begin
          drain_cnt <= 0;
          exec_one();
        end
      end else begin
        drain_cnt <= 0;
        if (!halt_req)     halted <= 1'b0;
        else if (step_req) exec_one();
      end

      // abstract register access
      if (reg_req && !acc_busy && !reg_ack) begin
        acc_busy <= 1'b1; acc_cnt <= 0;
      end else if (acc_busy) begin
        if (acc_cnt == 1) begin
          acc_busy <= 1'b0;
          reg_ack  <= 1'b1;
          reg_err  <= !halted || (reg_addr > 6'd32);
          reg_rdata <= '0;
          if (halted && reg_addr < 6'd32) begin
            if (reg_we) begin if (reg_addr != 0) x[reg_addr] <= reg_wdata; end
            else reg_rdata <= (reg_addr == 0) ? 32'd0 : x[reg_addr];
          end else if (halted && reg_addr == 6'd32) begin
            if (reg_we) pc <= reg_wdata; else reg_rdata <= pc;
          end
        end else acc_cnt <= acc_cnt + 1;
      end
    end
  end

endmodule
