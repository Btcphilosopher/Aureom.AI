// =============================================================================
// SilicaFlux TestCore :: tc_demo_soc   (testbench integration)
// Reference integration of tc_top with:
//   * five memories behind tc_mbist_collar (1RW lat 1, 1RW + out-pipe,
//     72-bit 1RW macro-lat 2 + in-pipe, 1R1W with write->read restriction, ROM)
//   * a debug-capable core model on the core debug port
//   * the LBIST demonstration ALU behind the LBIST input multiplexer
//   * a 4-flop stand-in scan chain per scan channel and an ICG whose TE is
//     driven by dft_cg_te (exercises the test-enable distribution)
// Parameters come from tb/models/tc_demo_cfg.svh (generated from the spec).
// =============================================================================
`timescale 1ns/1ps
module tc_demo_soc (
  input  logic        tck, tms, tdi, trst_n,
  output logic        tdo, tdo_oe,
  input  logic        por_n, ext_rst_n,
  input  logic        func_clk, test_clk, ref_clk, pll_lock,
  input  logic        otp_valid,
  input  logic [7:0]  lc_otp,
  input  logic        wdt_req,
  // pads
  input  logic [2:0]  in_pad,
  output logic [3:0]  out_pad, out_pad_oe,
  output logic [7:0]  io_pad_o, io_pad_oe,
  input  logic [7:0]  io_pad_i,
  // APB
  input  logic        psel, penable, pwrite,
  input  logic [11:0] paddr,
  input  logic [31:0] pwdata,
  output logic [31:0] prdata,
  output logic        pready, pslverr,
  // functional port of memory 0 (isolation tests)
  input  logic        f0_ce, f0_we,
  input  logic [7:0]  f0_addr,
  input  logic [31:0] f0_wdata,
  output logic [31:0] f0_rdata,
  output logic        f0_ready,
  // observation
  output logic        clk_o, sys_rst_n, core_rst_n,
  output logic        scan_mode, scan_en, cg_te,
  output logic [2:0]  test_mode,
  output logic        lbist_sel,
  output logic [3:0]  gated_cnt,
  output logic [2:0]  in_core
);
  `include "tc_demo_cfg.svh"
  localparam int NM = DEMO_NUM_MEMS, MDW = DEMO_MAX_DW, MAW = DEMO_MAX_AW;

  // ---------------------------------------------------------------- core model
  logic        halt_req, step_req, halted, reg_req, reg_we, reg_ack, reg_err, trace_valid, err_evt;
  logic [31:0] pc, reg_wdata, reg_rdata, trace_data;
  logic [5:0]  reg_addr;
  tc_core_model u_core (
    .clk(clk_o), .rst_n(core_rst_n), .halt_req, .step_req, .halted, .pc,
    .reg_req, .reg_we, .reg_addr, .reg_wdata, .reg_ack, .reg_rdata, .reg_err,
    .trace_valid, .trace_data, .err_evt
  );

  // ---------------------------------------------------------------- MBIST bus
  logic            mb_active, mb_ce, mb_we;
  logic [NM-1:0]   mb_sel;
  logic [MAW-1:0]  mb_addr;
  logic [MDW-1:0]  mb_wdata;
  logic [NM*MDW-1:0] mb_rdata;

  // ---------------------------------------------------------------- LBIST target
  logic                    lb_sel;
  logic [DEMO_LB_IN_W-1:0] lb_in, alu_in;
  logic [31:0]             alu_y;
  logic                    alu_zero;
  assign alu_in = lb_sel ? lb_in : {4'd0, 32'h1234_5678, pc};
  tc_lbist_demo_alu u_alu (.a(alu_in[31:0]), .b(alu_in[63:32]), .op(alu_in[67:64]), .y(alu_y), .zero(alu_zero));
  assign lbist_sel = lb_sel;

  // ---------------------------------------------------------------- scan stand-in
  logic [1:0] scan_in_w, scan_out_w;
  logic [3:0] chain [2];
  always_ff @(posedge clk_o) begin
    if (scan_en) begin
      chain[0] <= {chain[0][2:0], scan_in_w[0]};
      chain[1] <= {chain[1][2:0], scan_in_w[1]};
    end
  end
  assign scan_out_w = {chain[1][3], chain[0][3]};

  logic gclk;
  tc_icg u_demo_icg (.clk(clk_o), .en(1'b0), .te(cg_te), .gclk(gclk));
  always_ff @(posedge gclk or negedge por_n) begin
    if (!por_n) gated_cnt <= '0; else gated_cnt <= gated_cnt + 4'd1;
  end

  // ---------------------------------------------------------------- TestCore
  logic [7:0] err_evts;
  assign err_evts = {6'd0, mb_active, err_evt};

  tc_top #(
    .NUM_IN(3), .NUM_OUT(4), .NUM_BIDIR(8), .NUM_SCAN_CH(2),
    .NUM_MEMS(NM), .MAX_DW(MDW), .MAX_AW(MAW), .MAX_LAT(DEMO_MAX_LAT), .LOG_DEPTH(DEMO_LOG_DEPTH),
    .MEM_DW(DEMO_MEM_DW), .MEM_MAXADDR(DEMO_MEM_MAXADDR), .MEM_LAT(DEMO_MEM_LAT),
    .MEM_TYPE(DEMO_MEM_TYPE), .MEM_WR2RD(DEMO_MEM_WR2RD),
    .LBIST_EN(1'b1), .LB_IN_W(DEMO_LB_IN_W), .LB_OUT_W(DEMO_LB_OUT_W), .LB_LAT(DEMO_LB_LAT),
    .TRACE_EN(1'b1), .TRACE_DEPTH(DEMO_TRACE_DEPTH), .NUM_ERR(DEMO_NUM_ERR), .REF_WINDOW(DEMO_REF_WINDOW)
  ) u_tc (
    .tck, .tms, .tdi, .trst_n, .tdo, .tdo_oe,
    .por_n, .ext_rst_n, .func_clk_i(func_clk), .test_clk_i(test_clk), .ref_clk_i(ref_clk),
    .pll_lock_i(pll_lock), .clk_src_sel_i(8'h01), .clk_o, .sys_rst_n_o(sys_rst_n), .core_rst_n_o(core_rst_n),
    .wdt_rst_req_i(wdt_req),
    .otp_valid_i(otp_valid), .lc_otp_i(lc_otp), .unlock_key_i(DEMO_UNLOCK_KEY), .ecid_i(DEMO_ECID),
    .silicon_rev_i(DEMO_SILICON_REV), .idcode_version_i(DEMO_IDCODE_VERSION),
    .in_pad_i(in_pad), .in_core_o(in_core),
    .out_core_i(pc[11:8]), .out_core_oe_i(4'hF), .out_pad_o(out_pad), .out_pad_oe_o(out_pad_oe),
    .io_core_o_i(pc[9:2]), .io_core_oe_i(8'h0F), .io_core_i_o(), .io_pad_o, .io_pad_oe_o(io_pad_oe), .io_pad_i,
    .dft_scan_mode_o(scan_mode), .dft_scan_en_o(scan_en), .dft_cg_te_o(cg_te), .dft_scan_cfg_o(),
    .dft_scan_in_o(scan_in_w), .dft_scan_out_i(scan_out_w), .test_mode_o(test_mode),
    .mbist_active_o(mb_active), .mbist_sel_o(mb_sel), .mbist_ce_o(mb_ce), .mbist_we_o(mb_we),
    .mbist_addr_o(mb_addr), .mbist_wdata_o(mb_wdata), .mbist_rdata_i(mb_rdata),
    .lbist_tgt_sel_o(lb_sel), .lbist_tgt_in_o(lb_in), .lbist_tgt_out_i({alu_zero, alu_y}),
    .dbg_halt_req_o(halt_req), .dbg_step_req_o(step_req), .dbg_halted_i(halted), .dbg_pc_i(pc),
    .dbg_reg_req_o(reg_req), .dbg_reg_we_o(reg_we), .dbg_reg_addr_o(reg_addr), .dbg_reg_wdata_o(reg_wdata),
    .dbg_reg_ack_i(reg_ack), .dbg_reg_rdata_i(reg_rdata), .dbg_reg_err_i(reg_err),
    .err_evt_i(err_evts), .acc_diag_i({32'hACCE_0003, 32'hACCE_0002, 32'hACCE_0001, pc}),
    .trace_valid_i(trace_valid), .trace_data_i(trace_data),
    .psel, .penable, .pwrite, .paddr, .pwdata, .prdata, .pready, .pslverr
  );

  // ---------------------------------------------------------------- memories
  for (genvar i = 0; i < NM; i++) begin : g_mem
    localparam int DW    = DEMO_MEM_DW[i*8 +: 8];
    localparam int DEPTH = DEMO_MEM_MAXADDR[i*20 +: 20] + 1;
    localparam int AW    = (DEPTH > 1) ? $clog2(DEPTH) : 1;
    localparam int MTYPE = DEMO_MEM_TYPE[i*2 +: 2];
    localparam int MLAT  = DEMO_MACRO_LAT[i*3 +: 3];
    localparam int GAP   = DEMO_MEM_WR2RD[i*2 +: 2];
    logic          m_ce, m_we, fce, fwe, frdy;
    logic [AW-1:0] m_addr, m_waddr, faddr;
    logic [DW-1:0] m_wdata, m_rdata, fwdata, frdata;
    logic          m_wmask;

    if (i == 0) begin : g_f0
      assign fce = f0_ce; assign fwe = f0_we; assign faddr = AW'(f0_addr); assign fwdata = DW'(f0_wdata);
      assign f0_rdata = 32'(frdata); assign f0_ready = frdy;
    end else begin : g_fx
      assign fce = 1'b0; assign fwe = 1'b0; assign faddr = '0; assign fwdata = '0;
    end

    tc_mbist_collar #(
      .DW(DW), .AW(AW), .WM_W(1), .TBUS_DW(MDW), .TBUS_AW(MAW),
      .TYPE(MTYPE == 1 ? 1 : 0), .IN_PIPE(DEMO_IN_PIPE[i]), .OUT_PIPE(DEMO_OUT_PIPE[i]), .SCAN_BYPASS(1'b1)
    ) u_collar (
      .clk(clk_o), .scan_mode,
      .bist_active(mb_active), .bist_sel(mb_sel[i]), .bist_ce(mb_ce), .bist_we(mb_we),
      .bist_addr(mb_addr), .bist_wdata(mb_wdata), .bist_rdata(mb_rdata[i*MDW +: MDW]),
      .f_ce(fce), .f_we(fwe), .f_addr(faddr), .f_waddr(faddr), .f_wdata(fwdata), .f_wmask(1'b1),
      .f_rdata(frdata), .f_ready(frdy),
      .m_ce, .m_we, .m_addr, .m_waddr, .m_wdata, .m_wmask, .m_rdata
    );

    tc_sram_model #(
      .MEM_ID(i), .DW(DW), .DEPTH(DEPTH), .AW(AW), .LAT(MLAT), .TYPE(MTYPE), .WR2RD(GAP)
    ) u_mem (
      .clk(clk_o), .ce(m_ce), .we(m_we && MTYPE != 2), .addr(m_addr), .waddr(m_waddr),
      .wdata(m_wdata), .rdata(m_rdata)
    );
  end

endmodule
