// =============================================================================
// tb_rst_clk :: reset sequencing and clock-control verification
//  * POR: asynchronous assertion of all resets; synchronous, staged release
//    (tc_rst_n, then sys_rst_n, then core_rst_n) aligned to clock edges
//  * RST_N pad, watchdog/software/debug requests: width, cause bits, count, W1C
//  * test-mode hold (sys and TestCore domains), scan-mode reset bypass
//  * invariant: core_rst_n is never released while sys_rst_n is asserted
//  * sequenced functional->test clock switch produces no runt pulses; an
//    unsequenced switch does (monitor self-check)
//  * clock monitor measurement against the reference window
// =============================================================================
`timescale 1ns/1ps
module tb_rst_clk;
  real TCK_HALF = 20.0;
  logic tck = 0, tms = 0, tdi = 0, trst_n = 1; wire tdo = 1'b0;
  `include "tc_tb_common.svh"

  logic por_n = 1, ext_rst_n = 1, sys_hold = 0, tc_hold = 0, wdt = 0, sw = 0, dbg = 0;
  logic scan_mode = 0, scan_rst_n = 1;
  logic func_clk = 0, test_clk = 0, ref_clk = 0, stop_req = 0, test_sel = 0;
  logic clk, tc_rst_n, sys_rst_n, core_rst_n, sys_in_reset;
  logic w1c_en = 0; logic [5:0] w1c = 0, cause; logic [31:0] count, meas, cycles; logic meas_valid;

  bit func_run = 1, test_run = 0;
  always #5  if (func_run) func_clk = ~func_clk;
  always #20 ref_clk = ~ref_clk;
  always #20 if (test_run) test_clk = ~test_clk;

  tc_clk_ctrl #(.REF_WINDOW(64)) u_clk (
    .por_n, .scan_mode, .scan_rst_n, .func_clk_i(func_clk), .test_clk_i(test_clk), .ref_clk_i(ref_clk),
    .stop_req, .test_sel, .clk_o(clk), .rst_n(tc_rst_n),
    .meas_o(meas), .meas_valid_o(meas_valid), .cycles_o(cycles));

  tc_rst_ctrl #(.SYNC_STAGES(3), .CORE_DELAY(4), .REQ_STRETCH(16)) u_rst (
    .clk, .por_n, .ext_rst_n, .sys_rst_hold(sys_hold), .tc_rst_hold(tc_hold),
    .wdt_req(wdt), .sw_req(sw), .dbg_req(dbg), .scan_mode, .scan_rst_n,
    .tc_rst_n, .sys_rst_n, .core_rst_n, .sys_in_reset,
    .cause_w1c_en(w1c_en), .cause_w1c(w1c), .cause_o(cause), .count_o(count));

  // ---- invariants
  always @(posedge core_rst_n) if (!scan_mode) begin
    tb_checks++;
    if (!sys_rst_n) begin tb_errors++; $display("[%0t] FAIL: core released while system in reset", $time); end
  end
  realtime t_rise, t_fall; int runts = 0; bit glitch_mon = 1;
  always @(posedge clk) begin
    t_rise = $realtime;
    if (glitch_mon && t_fall > 0 && (t_rise - t_fall) < 4.0) runts++;
  end
  always @(negedge clk) begin
    t_fall = $realtime;
    if (glitch_mon && (t_fall - t_rise) < 4.0) runts++;
  end
  // releases must be synchronous to clk rising edges
  realtime last_clk_rise;
  always @(posedge clk) last_clk_rise = $realtime;
  task automatic check_sync_release(input string what);
    `CHECK(($realtime - last_clk_rise) < 0.01, {what, " released on a clock edge"})
  endtask
  always @(posedge sys_rst_n)  if (!scan_mode) check_sync_release("sys_rst_n");
  always @(posedge core_rst_n) if (!scan_mode) check_sync_release("core_rst_n");
  always @(posedge tc_rst_n)   if (!scan_mode) check_sync_release("tc_rst_n");

  task automatic clocks(input int n); repeat (n) @(posedge clk); endtask
  task automatic pulse(input int which);
    @(negedge clk);
    case (which) 0: wdt = 1; 1: sw = 1; default: dbg = 1; endcase
    @(negedge clk); wdt = 0; sw = 0; dbg = 0;
  endtask

  int c_tc, c_sys, c_core;
  initial begin
    // ---------------- power-on reset
    #2 por_n = 0;
    #1 `CHECK({tc_rst_n, sys_rst_n, core_rst_n} === 3'b000, "POR asserts all resets asynchronously")
    #50 por_n = 1;
    c_tc = 0; c_sys = 0; c_core = 0;
    fork
      begin while (!tc_rst_n)   begin @(posedge clk); #0.1 c_tc++;   end end
      begin while (!sys_rst_n)  begin @(posedge clk); #0.1 c_sys++;  end end
      begin while (!core_rst_n) begin @(posedge clk); #0.1 c_core++; end end
    join
    `CHECK_EQ(c_tc, 2, "tc_rst_n released after 2 clocks")
    `CHECK_EQ(c_sys, 3, "sys_rst_n released after 3 clocks")
    `CHECK_EQ(c_core, 7, "core_rst_n released 4 clocks after sys_rst_n")
    clocks(4);
    `CHECK_EQ(cause, 6'b000001, "cause after POR = POR")

    // ---------------- RST_N pad
    @(posedge clk); #3 ext_rst_n = 0;          // mid-cycle
    #0.5 `CHECK(sys_rst_n === 1'b0 && core_rst_n === 1'b0, "RST_N asserts system resets asynchronously")
    `CHECK_EQ(tc_rst_n, 1'b1, "RST_N does not reset TestCore domain")
    clocks(5); ext_rst_n = 1;
    wait (core_rst_n); clocks(4);
    `CHECK_EQ(cause[1], 1'b1, "cause EXT_PIN")
    `CHECK_EQ(count, 32'd2, "reset count = 2 (POR episode + RST_N)")
    @(negedge clk); w1c_en = 1; w1c = 6'b000011; @(negedge clk); w1c_en = 0;
    `CHECK_EQ(cause, 6'b000000, "W1C clears POR and EXT_PIN")

    // ---------------- synchronous requests: width and cause
    begin
      int w;
      pulse(0);
      @(posedge clk); #0.1;
      w = 0;
      while (!sys_rst_n) begin @(posedge clk); #0.1 w++; end
      `CHECK(w >= 16 && w <= 20, $sformatf("watchdog reset stretched to >=16 clocks (got %0d)", w))
      `CHECK_EQ(cause[2], 1'b1, "cause WDT")
    end
    wait (core_rst_n); clocks(2);
    pulse(1);  wait (core_rst_n); clocks(2); `CHECK_EQ(cause[3], 1'b1, "cause SW")
    pulse(2); wait (core_rst_n); clocks(2); `CHECK_EQ(cause[4], 1'b1, "cause DEBUG")
    `CHECK_EQ(count, 32'd5, "reset count = 5")

    // ---------------- test-mode hold
    @(negedge clk); sys_hold = 1;
    #1 `CHECK_EQ(sys_rst_n, 1'b0, "sys_rst_hold asserts system reset")
    clocks(20);
    `CHECK_EQ(sys_rst_n, 1'b0, "system reset held for the whole mode")
    `CHECK_EQ(cause[5], 1'b1, "cause TEST_MODE")
    sys_hold = 0; wait (core_rst_n); clocks(2);
    `CHECK_EQ(sys_rst_n, 1'b1, "system leaves reset after test-mode exit")
    @(negedge clk); tc_hold = 1;
    #1 `CHECK_EQ(tc_rst_n, 1'b0, "tc_rst_hold resets TestCore domain")
    clocks(3); tc_hold = 0; wait (tc_rst_n); clocks(1);
    `CHECK_EQ(cause, 6'b000001, "TestCore-domain reset re-initialises cause to POR")

    // ---------------- scan bypass
    scan_mode = 1; #1;
    scan_rst_n = 0; #1 `CHECK({tc_rst_n, sys_rst_n, core_rst_n} === 3'b000, "scan: resets follow scan_rst_n (0)")
    scan_rst_n = 1; #1 `CHECK({tc_rst_n, sys_rst_n, core_rst_n} === 3'b111, "scan: resets follow scan_rst_n (1)")
    por_n = 0; #1 `CHECK({tc_rst_n, sys_rst_n, core_rst_n} === 3'b111, "scan: functional reset sources bypassed")
    por_n = 1; scan_mode = 0; clocks(10);

    // ---------------- clock monitor
    repeat (3) @(posedge u_clk.win_s);
    clocks(4);
    `CHECK(meas >= 255 && meas <= 257, $sformatf("clock monitor: 64 ref cycles x 40ns / 10ns = 256 (got %0d)", meas))
    `CHECK_EQ(meas_valid, 1'b1, "clock monitor valid")

    // ---------------- sequenced switch to test clock and back
    runts = 0;
    @(negedge func_clk); stop_req = 1;          // gate functional clock
    repeat (6) @(posedge func_clk);
    test_sel = 1;                               // switch while both quiet
    #13 test_run = 1;                           // ATE starts test clock
    #400 test_run = 0; wait (!test_clk);        // ATE parks test clock low
    #13 test_sel = 0;
    repeat (2) @(posedge func_clk);
    stop_req = 0;
    #200;
    `CHECK_EQ(runts, 0, "sequenced clock switch: no runt pulses")

    // ---------------- monitor self-check: unsequenced switch glitches
    @(posedge func_clk); #2 test_sel = 1;       // functional high, test low -> runt
    #1 test_sel = 0;
    #50;
    `CHECK(runts > 0, "unsequenced switch produces a runt (monitor works)")
    tb_finish("tb_rst_clk");
  end
endmodule
