// =============================================================================
// tb_mbist :: MBIST controller verification with fault injection
// DUT: tc_mbist + tc_mbist_collar + tc_sram_model for the demo registry
//   L1I 1RW lat1 | L1D 1RW out-pipe lat2 | L2 72b macro-lat2 + in-pipe lat3 |
//   SCRATCH 1R1W write->read gap 1 | BOOTROM ROM
// Checks: discovery, clean pass for every algorithm/background, exact
// failure address/element/op/syndrome logging per fault model (SAF, TF,
// AF, CFid, DRF, column), algorithm-coverage differences (MATS+ misses
// TF-down; March C- misses DRF without pause), log overflow, stop-on-fail,
// abort, ROM signature, empty selection/algorithm => FAIL, user algorithm,
// bank selection, and the write->read access restriction (negative test).
// =============================================================================
`timescale 1ns/1ps
module tb_mbist;
  import tc_spec_pkg::*;
  import tc_pkg::*;
  `include "tc_demo_cfg.svh"
  localparam int NM = DEMO_NUM_MEMS, MDW = DEMO_MAX_DW, MAW = DEMO_MAX_AW;

  // dummy JTAG signals for the shared include
  real TCK_HALF = 20.0;
  logic tck = 0, tms = 0, tdi = 0, trst_n = 1; wire tdo = 1'b0;
  `include "tc_tb_common.svh"

  logic clk = 0, rst_n = 0, mode_en = 0;
  always #5 clk = ~clk;

  logic        wr = 0;
  logic [11:0] addr = 0;
  logic [31:0] wdata = 0, rdata;
  logic            mb_active, mb_ce, mb_we, busy, done, fail;
  logic [NM-1:0]   mb_sel;
  logic [MAW-1:0]  mb_addr;
  logic [MDW-1:0]  mb_wdata;
  logic [NM*MDW-1:0] mb_rdata;

  tc_mbist #(
    .NUM_MEMS(NM), .MAX_DW(MDW), .MAX_AW(MAW), .MAX_LAT(DEMO_MAX_LAT), .LOG_DEPTH(DEMO_LOG_DEPTH),
    .MEM_DW(DEMO_MEM_DW), .MEM_MAXADDR(DEMO_MEM_MAXADDR), .MEM_LAT(DEMO_MEM_LAT),
    .MEM_TYPE(DEMO_MEM_TYPE), .MEM_WR2RD(DEMO_MEM_WR2RD)
  ) dut (
    .clk, .rst_n, .mode_en, .wr, .addr, .wdata, .rdata,
    .active_o(mb_active), .sel_o(mb_sel), .ce_o(mb_ce), .we_o(mb_we), .addr_o(mb_addr),
    .wdata_o(mb_wdata), .rdata_i(mb_rdata), .busy_o(busy), .done_o(done), .fail_o(fail)
  );

  for (genvar i = 0; i < NM; i++) begin : g_mem
    localparam int DW    = DEMO_MEM_DW[i*8 +: 8];
    localparam int DEPTH = DEMO_MEM_MAXADDR[i*20 +: 20] + 1;
    localparam int AW    = (DEPTH > 1) ? $clog2(DEPTH) : 1;
    localparam int MTYPE = DEMO_MEM_TYPE[i*2 +: 2];
    logic m_ce, m_we, m_wmask; logic [AW-1:0] m_addr, m_waddr; logic [DW-1:0] m_wdata, m_rdata, frd;
    tc_mbist_collar #(.DW(DW), .AW(AW), .TBUS_DW(MDW), .TBUS_AW(MAW), .TYPE(MTYPE == 1 ? 1 : 0),
                      .IN_PIPE(DEMO_IN_PIPE[i]), .OUT_PIPE(DEMO_OUT_PIPE[i])) u_collar (
      .clk, .scan_mode(1'b0), .bist_active(mb_active), .bist_sel(mb_sel[i]), .bist_ce(mb_ce), .bist_we(mb_we),
      .bist_addr(mb_addr), .bist_wdata(mb_wdata), .bist_rdata(mb_rdata[i*MDW +: MDW]),
      .f_ce(1'b0), .f_we(1'b0), .f_addr('0), .f_waddr('0), .f_wdata('0), .f_wmask(1'b1), .f_rdata(frd), .f_ready(),
      .m_ce, .m_we, .m_addr, .m_waddr, .m_wdata, .m_wmask, .m_rdata);
    tc_sram_model #(.MEM_ID(i), .DW(DW), .DEPTH(DEPTH), .AW(AW), .LAT(DEMO_MACRO_LAT[i*3 +: 3]),
                    .TYPE(MTYPE), .WR2RD(DEMO_MEM_WR2RD[i*2 +: 2])) u_mem (
      .clk, .ce(m_ce), .we(m_we && MTYPE != 2), .addr(m_addr), .waddr(m_waddr), .wdata(m_wdata), .rdata(m_rdata));
  end

  // ---- negative test: 1R1W memory needing a gap, registered WITHOUT the gap
  logic        n_wr = 0; logic [11:0] n_addr = 0; logic [31:0] n_wdata = 0, n_rdata;
  logic        n_active, n_ce, n_we, n_busy, n_done, n_fail; logic [0:0] n_sel;
  logic [MAW-1:0] n_maddr; logic [MDW-1:0] n_mwdata, n_mrdata;
  tc_mbist #(.NUM_MEMS(1), .MAX_DW(MDW), .MAX_AW(MAW), .MAX_LAT(DEMO_MAX_LAT), .LOG_DEPTH(4),
             .MEM_DW(8'd16), .MEM_MAXADDR(20'd99), .MEM_LAT(3'd1), .MEM_TYPE(2'd1), .MEM_WR2RD(2'd0)) dut_nogap (
    .clk, .rst_n, .mode_en, .wr(n_wr), .addr(n_addr), .wdata(n_wdata), .rdata(n_rdata),
    .active_o(n_active), .sel_o(n_sel), .ce_o(n_ce), .we_o(n_we), .addr_o(n_maddr),
    .wdata_o(n_mwdata), .rdata_i(n_mrdata), .busy_o(n_busy), .done_o(n_done), .fail_o(n_fail));
  logic nm_ce, nm_we, nm_wm; logic [6:0] nm_a, nm_wa; logic [15:0] nm_wd, nm_rd, nfrd;
  tc_mbist_collar #(.DW(16), .AW(7), .TBUS_DW(MDW), .TBUS_AW(MAW), .TYPE(1)) u_ncollar (
    .clk, .scan_mode(1'b0), .bist_active(n_active), .bist_sel(n_sel[0]), .bist_ce(n_ce), .bist_we(n_we),
    .bist_addr(n_maddr), .bist_wdata(n_mwdata), .bist_rdata(n_mrdata),
    .f_ce(1'b0), .f_we(1'b0), .f_addr('0), .f_waddr('0), .f_wdata('0), .f_wmask(1'b1), .f_rdata(nfrd), .f_ready(),
    .m_ce(nm_ce), .m_we(nm_we), .m_addr(nm_a), .m_waddr(nm_wa), .m_wdata(nm_wd), .m_wmask(nm_wm), .m_rdata(nm_rd));
  tc_sram_model #(.MEM_ID(99), .DW(16), .DEPTH(100), .AW(7), .LAT(1), .TYPE(1), .WR2RD(1)) u_nmem (
    .clk, .ce(nm_ce), .we(nm_we), .addr(nm_a), .waddr(nm_wa), .wdata(nm_wd), .rdata(nm_rd));

  // ---------------------------------------------------------------- helpers
  task automatic wreg(input logic [11:0] a, input logic [31:0] d);
    @(negedge clk); wr = 1; addr = a; wdata = d;
    @(negedge clk); wr = 0;
  endtask
  task automatic rreg(input logic [11:0] a, output logic [31:0] d);
    @(negedge clk); addr = a; #1 d = rdata;
  endtask

  task automatic set_fault(input int m, input int t, input int a, input int b,
                           input int a2 = 0, input int b2 = 0, input int drf = 1000);
    case (m)
      0: g_mem[0].u_mem.set_fault(t, a, b, a2, b2, drf);
      1: g_mem[1].u_mem.set_fault(t, a, b, a2, b2, drf);
      2: g_mem[2].u_mem.set_fault(t, a, b, a2, b2, drf);
      3: g_mem[3].u_mem.set_fault(t, a, b, a2, b2, drf);
      4: g_mem[4].u_mem.set_fault(t, a, b, a2, b2, drf);
      default: ;
    endcase
  endtask
  task automatic clear_faults();
    for (int m = 0; m < NM; m++) set_fault(m, 0, 0, 0);
  endtask

  logic [31:0] st, fm, fc;
  task automatic run(input logic [3:0] algo, input logic [NM-1:0] sel, input logic [2:0] bg = 0,
                     input logic sof = 0, input logic sigchk = 0);
    int to;
    wreg(TC_R_MBIST_MEM_SEL, 32'(sel));
    wreg(TC_R_MBIST_CTRL, {21'd0, sigchk, sof, bg, algo, 2'b01});
    to = 0;
    do begin @(negedge clk); to++; end while (busy && to < 400000);
    `CHECK(to < 400000, "MBIST run completes before timeout")
    rreg(TC_R_MBIST_STATUS, st);
    rreg(TC_R_MBIST_FAIL_MEMS, fm);
    rreg(TC_R_MBIST_FAIL_COUNT, fc);
  endtask

  task automatic log_entry(input int idx, output logic [31:0] info, output logic [95:0] synd);
    logic [31:0] s0, s1, s2;
    wreg(TC_R_MBIST_LOG_IDX, 32'(idx));
    rreg(TC_R_MBIST_LOG_INFO, info);
    rreg(TC_R_MBIST_LOG_SYND0, s0); rreg(TC_R_MBIST_LOG_SYND1, s1); rreg(TC_R_MBIST_LOG_SYND2, s2);
    synd = {s2, s1, s0};
  endtask

  task automatic check_log(input int idx, input int mem, input int elem, input int op, input int a,
                           input logic [95:0] exp_synd, input string what);
    logic [31:0] info; logic [95:0] sy;
    log_entry(idx, info, sy);
    `CHECK_EQ(info[31], 1'b1, {what, ": log entry valid"})
    `CHECK_EQ(32'(info[29:26]), 32'(mem),  {what, ": log mem"})
    `CHECK_EQ(32'(info[25:23]), 32'(elem), {what, ": log element"})
    `CHECK_EQ(32'(info[22:20]), 32'(op),   {what, ": log op index"})
    `CHECK_EQ(32'(info[19:0]),  32'(a),    {what, ": log address"})
    `CHECK_EQ(sy, exp_synd, {what, ": log syndrome"})
  endtask

  function automatic logic [31:0] rom_sig_ref();
    logic [31:0] m, w;
    m = 0;
    for (int a = 0; a < 64; a++) begin
      w = (32'(a) * 32'h9E3779B1) ^ 32'hA5A5A5A5;
      m = tc_misr_step(m, w);
    end
    return m;
  endfunction

  localparam logic [NM-1:0] ALL_RAM = 5'b01111, ALL = 5'b11111;

  initial begin
    logic [31:0] v, info; logic [95:0] sy;
    #33 rst_n = 1;
    @(negedge clk); mode_en = 1;

    // ---------------- discovery
    rreg(TC_R_MBIST_NUM_MEMS, v); `CHECK_EQ(v, 32'(NM), "registry: number of memories")
    for (int m = 0; m < NM; m++) begin
      logic [31:0] i0, i1;
      wreg(TC_R_MBIST_MEM_IDX, 32'(m));
      rreg(TC_R_MBIST_MEM_INFO0, i0); rreg(TC_R_MBIST_MEM_INFO1, i1);
      `CHECK_EQ(i0[7:0], DEMO_MEM_DW[m*8 +: 8], "registry: width")
      `CHECK_EQ(i0[10:8], DEMO_MEM_LAT[m*3 +: 3], "registry: latency")
      `CHECK_EQ(i0[12:11], DEMO_MEM_TYPE[m*2 +: 2], "registry: type")
      `CHECK_EQ(i0[14:13], DEMO_MEM_WR2RD[m*2 +: 2], "registry: wr2rd gap")
      `CHECK_EQ(i0[15], 1'b1, "registry: valid")
      `CHECK_EQ(i1, 32'(DEMO_MEM_MAXADDR[m*20 +: 20]), "registry: max address")
    end
    wreg(TC_R_MBIST_MEM_IDX, 32'd9); rreg(TC_R_MBIST_MEM_INFO0, v);
    `CHECK_EQ(v[15], 1'b0, "registry: out-of-range index invalid")

    // ---------------- clean runs: every algorithm, all memories (ROM signature checked)
    wreg(TC_R_MBIST_SIG_EXP, rom_sig_ref());
    wreg(TC_R_MBIST_PAUSE, 32'd50);
    for (int a = 0; a <= 5; a++) begin
      run(4'(a), ALL, 3'd0, 1'b0, 1'b1);
      `CHECK_EQ(st[2:0], 3'b010, $sformatf("clean algo %0d: done & pass", a))
      `CHECK_EQ(st[6], 1'b0, $sformatf("clean algo %0d: ROM signature matches", a))
      `CHECK_EQ(fm, 32'd0, $sformatf("clean algo %0d: no failing memory", a))
    end
    rreg(TC_R_MBIST_SIG, v); `CHECK_EQ(v, rom_sig_ref(), "ROM MISR signature value")
    for (int bg = 1; bg <= 4; bg++) begin
      wreg(TC_R_MBIST_BG_USER, 32'hC3A5_5A3C);
      run(TC_ALG_MARCH_C_MINUS, ALL_RAM, 3'(bg));
      `CHECK_EQ(st[2:0], 3'b010, $sformatf("clean March C- background %0d", bg))
    end

    // ---------------- SA0 on L1I (lat 1): exact log
    run(TC_ALG_MARCH_C_MINUS, ALL_RAM);                  // known-zero contents
    set_fault(0, 1, 17, 5);
    run(TC_ALG_MARCH_C_MINUS, ALL_RAM);
    `CHECK_EQ(st[2:0], 3'b110, "SA0: done & fail")
    `CHECK_EQ(fm, 32'b00001, "SA0: only L1I fails")
    `CHECK_EQ(fc, 32'd2, "SA0: two failing reads (M2 r1, M4 r1)")
    `CHECK_EQ(32'(st[20:16]), 32'd2, "SA0: two log entries")
    check_log(0, 0, 2, 0, 17, 96'(1) << 5, "SA0 #0");
    check_log(1, 0, 4, 0, 17, 96'(1) << 5, "SA0 #1");
    log_entry(2, info, sy); `CHECK_EQ(info[31], 1'b0, "SA0: entry 2 not valid")
    clear_faults();

    // ---------------- SA1 on L2 (72-bit, in-pipe + macro latency 2 = 3)
    set_fault(2, 2, 300, 70);
    run(TC_ALG_MARCH_C_MINUS, ALL_RAM);
    `CHECK_EQ(fm, 32'b00100, "SA1: only L2 fails")
    `CHECK_EQ(fc, 32'd3, "SA1: three failing reads (M1, M3, M5)")
    check_log(0, 2, 1, 0, 300, 96'(1) << 70, "SA1 #0 (bit 70 in SYND2)");
    check_log(1, 2, 3, 0, 300, 96'(1) << 70, "SA1 #1");
    check_log(2, 2, 5, 0, 300, 96'(1) << 70, "SA1 #2");
    clear_faults();

    // ---------------- TF up on L1D (out-pipe, latency 2)
    run(TC_ALG_MARCH_C_MINUS, ALL_RAM);
    set_fault(1, 3, 0, 0);
    run(TC_ALG_MARCH_C_MINUS, ALL_RAM);
    `CHECK_EQ(fc, 32'd2, "TF-up: detected twice by March C-")
    check_log(0, 1, 2, 0, 0, 96'(1), "TF-up #0");
    run(TC_ALG_MATS_PLUS, ALL_RAM);
    `CHECK_EQ(st[2], 1'b1, "TF-up: detected by MATS+")
    clear_faults();

    // ---------------- TF down on L1I last address / MSB: MATS+ misses it, March C- catches it
    run(TC_ALG_MARCH_C_MINUS, ALL_RAM);
    set_fault(0, 4, 255, 31);
    run(TC_ALG_MATS_PLUS, ALL_RAM);
    `CHECK_EQ(st[2], 1'b0, "TF-down: NOT detected by MATS+ (known algorithm limitation)")
    run(TC_ALG_MARCH_C_MINUS, ALL_RAM);
    `CHECK_EQ(st[2], 1'b1, "TF-down: detected by March C-")
    // MATS+ left the cell at 1, so March C- M0 (w0) already fails to clear it:
    // first detection is M1 r0; the next one is M3 r0 after the M2 w0 fails.
    check_log(0, 0, 1, 0, 255, 96'(1) << 31, "TF-down #0 (U(r0,w1) after failed w0)");
    check_log(1, 0, 3, 0, 255, 96'(1) << 31, "TF-down #1 (D(r0,w1))");
    clear_faults();

    // ---------------- address-decoder fault: 10 -> 20
    set_fault(0, 5, 10, 0, 20);
    run(TC_ALG_MARCH_C_MINUS, ALL_RAM);
    `CHECK_EQ(st[2], 1'b1, "AF: detected")
    check_log(0, 0, 1, 0, 20, 96'(32'hFFFF_FFFF), "AF #0");
    run(TC_ALG_MATS_PLUS, ALL_RAM);
    `CHECK_EQ(st[2], 1'b1, "AF: detected by MATS+")
    clear_faults();

    // ---------------- idempotent coupling fault: 5.b3 rising -> 9.b3 = 1
    run(TC_ALG_MARCH_C_MINUS, ALL_RAM);
    set_fault(0, 6, 5, 3, 9, 3);
    run(TC_ALG_MARCH_C_MINUS, ALL_RAM);
    `CHECK_EQ(st[2], 1'b1, "CFid: detected by March C-")
    check_log(0, 0, 1, 0, 9, 96'(1) << 3, "CFid #0");
    clear_faults();

    // ---------------- data-retention fault: needs PAUSE elements
    set_fault(0, 7, 100, 7, 0, 0, 2000);
    run(TC_ALG_MARCH_C_MINUS, ALL_RAM);
    `CHECK_EQ(st[2], 1'b0, "DRF: NOT detected by March C- (no retention pause)")
    wreg(TC_R_MBIST_PAUSE, 32'd4000);
    run(TC_ALG_RETENTION, ALL_RAM);
    `CHECK_EQ(st[2], 1'b1, "DRF: detected by RETENTION algorithm")
    check_log(0, 0, 4, 0, 100, 96'(1) << 7, "DRF #0");
    wreg(TC_R_MBIST_PAUSE, 32'd50);
    clear_faults();

    // ---------------- column fault: overflow, counts, accumulated syndrome
    set_fault(1, 8, 0, 4);
    run(TC_ALG_MARCH_C_MINUS, ALL_RAM);
    `CHECK_EQ(fc, 32'd512, "column SA0: 2 failing reads x 256 words")
    `CHECK_EQ(32'(st[20:16]), 32'(DEMO_LOG_DEPTH), "column SA0: log full")
    `CHECK_EQ(st[5], 1'b1, "column SA0: log overflow flag")
    rreg(TC_R_MBIST_ACC_SYND0, v); `CHECK_EQ(v, 32'h10, "column SA0: accumulated failing-bit map")
    check_log(0, 1, 2, 0, 0, 96'(1) << 4, "column #0");
    check_log(7, 1, 2, 0, 7, 96'(1) << 4, "column #7");
    // stop on first fail
    run(TC_ALG_MARCH_C_MINUS, ALL_RAM, 3'd0, 1'b1);
    `CHECK_EQ(st[3:0], 4'b1110, "stop-on-fail: stopped, fail, done")
    `CHECK_EQ(fc, 32'd1, "stop-on-fail: single failure")
    // bank selection: fault in L1D, only L2 selected -> pass
    run(TC_ALG_MARCH_C_MINUS, 5'b00100);
    `CHECK_EQ(st[2:0], 3'b010, "bank select: unselected faulty memory not tested")
    clear_faults();

    // ---------------- ROM corruption
    set_fault(4, 2, 7, 2);
    run(TC_ALG_MARCH_C_MINUS, 5'b10000, 3'd0, 1'b0, 1'b1);
    `CHECK_EQ(st[6], 1'b1, "ROM: signature mismatch flagged")
    `CHECK_EQ(st[2], 1'b1, "ROM: overall fail")
    clear_faults();

    // ---------------- user-programmed algorithm == March C-
    begin
      logic [17:0] e [6];
      for (int k = 0; k < 6; k++) e[k] = tc_alg_elem(TC_ALG_MARCH_C_MINUS, 3'(k));
      for (int k = 0; k < 8; k++) wreg(12'(TC_R_MBIST_UALG0 + 4*k), (k < 6) ? 32'(e[k]) : 32'd0);
      run(TC_ALG_MARCH_C_MINUS, ALL_RAM);
      set_fault(0, 1, 17, 5);
      run(TC_ALG_USER, ALL_RAM);
      `CHECK_EQ(fc, 32'd2, "USER algorithm (programmed March C-) same result as built-in")
      check_log(0, 0, 2, 0, 17, 96'(1) << 5, "USER #0");
      clear_faults();
    end

    // ---------------- never a false pass
    run(TC_ALG_MARCH_C_MINUS, '0);
    `CHECK_EQ(st[2:0], 3'b110, "empty memory selection reports FAIL")
    run(4'd9, ALL_RAM);
    `CHECK_EQ(st[2:0], 3'b110, "undefined algorithm id reports FAIL")

    // ---------------- abort (register) and abort (mode exit)
    wreg(TC_R_MBIST_MEM_SEL, 32'b00100);
    wreg(TC_R_MBIST_CTRL, {21'd0, 1'b0, 1'b0, 3'd0, TC_ALG_MARCH_SS, 2'b01});
    repeat (200) @(negedge clk);
    wreg(TC_R_MBIST_CTRL, 32'h2);
    rreg(TC_R_MBIST_STATUS, v);
    `CHECK_EQ(v[4:0], 5'b10000, "ABORT bit: aborted, not busy, not done")
    wreg(TC_R_MBIST_CTRL, {21'd0, 1'b0, 1'b0, 3'd0, TC_ALG_MARCH_SS, 2'b01});
    repeat (200) @(negedge clk);
    mode_en = 0; repeat (2) @(negedge clk);
    rreg(TC_R_MBIST_STATUS, v);
    `CHECK_EQ(v[4:0], 5'b10000, "mode exit aborts a running test")
    `CHECK_EQ(mb_active, 1'b0, "collars released when mode exits")
    wreg(TC_R_MBIST_CTRL, 32'h1); rreg(TC_R_MBIST_STATUS, v);
    `CHECK_EQ(v[0], 1'b0, "START ignored outside MEMORY_BIST mode")
    mode_en = 1;

    // ---------------- access restriction: write->read gap
    run(TC_ALG_MARCH_B, 5'b01000);
    `CHECK_EQ(st[2:0], 3'b010, "1R1W with registered gap: March B passes")
    @(negedge clk); n_wr = 1; n_addr = TC_R_MBIST_MEM_SEL; n_wdata = 1;
    @(negedge clk); n_addr = TC_R_MBIST_CTRL; n_wdata = {21'd0, 1'b0, 1'b0, 3'd0, TC_ALG_MARCH_B, 2'b01};
    @(negedge clk); n_wr = 0;
    while (n_busy) @(negedge clk);
    `CHECK_EQ(n_fail, 1'b1, "1R1W registered WITHOUT required gap: March B fails (restriction is real)")

    tb_finish("tb_mbist");
  end
endmodule
