// =============================================================================
// tb_tap_bsr :: TAP data registers and boundary-scan verification (demo SoC)
//  * IDCODE selected after reset; value and mandatory LSB
//  * IR capture pattern and IR length (5)
//  * BYPASS: 1-bit delay, captures 0; unassigned opcode behaves as BYPASS
//  * TDO high-impedance outside Shift states, launched on falling TCK
//  * SAMPLE: capture of pad inputs, core outputs and output enables
//  * PRELOAD then EXTEST: pads driven from update stage, input capture,
//    system reset held while invasive instruction active and released after
//  * CLAMP (update stage drives pads, BYPASS selected), HIGHZ (all disabled)
//  * TRST* during EXTEST returns pads to functional control immediately
// The expected BSR vectors are built with the documented cell order.
// =============================================================================
`timescale 1ns/1ps
module tb_tap_bsr;
  import tc_spec_pkg::*;
  `include "tc_soc_harness.svh"
  `include "tc_tb_common.svh"

  localparam int NI = 3, NO = 4, NB = 8, LEN = NI + 2*NO + 3*NB;

  always @(tdo or tdo_oe) if (tck !== 1'b0 && por_n && $time > 0) begin
    tb_errors++; $display("[%0t] FAIL: TDO changed while TCK high", $time);
  end

  function automatic logic [LEN-1:0] bsr_vec(input logic [NI-1:0] ins, input logic [NO-1:0] od, input logic [NO-1:0] oc,
                                             input logic [NB-1:0] bi, input logic [NB-1:0] bd, input logic [NB-1:0] bc);
    logic [LEN-1:0] v;
    for (int i = 0; i < NI; i++) v[i] = ins[i];
    for (int o = 0; o < NO; o++) begin v[NI + 2*o] = od[o]; v[NI + 2*o + 1] = oc[o]; end
    for (int b = 0; b < NB; b++) begin
      v[NI + 2*NO + 3*b] = bi[b]; v[NI + 2*NO + 3*b + 1] = bd[b]; v[NI + 2*NO + 3*b + 2] = bc[b];
    end
    return v;
  endfunction

  initial begin
    logic [127:0] o; logic [7:0] c; logic d;
    logic [LEN-1:0] exp_v, pre;
    ext_rst_n = 0;                       // hold the core in reset: deterministic core outputs
    power_on();
    jclk_n(1'b0, 2);                     // TLR -> RTI

    // ---------------- IDCODE default
    shift_dr('0, 32, o);
    `CHECK_EQ(o[31:0], {DEMO_IDCODE_VERSION, TC_IDCODE_PART, TC_IDCODE_MFG, 1'b1}, "IDCODE selected after reset")
    `CHECK_EQ(o[0], 1'b1, "IDCODE LSB = 1")
    `CHECK_EQ(tdo_oe, 1'b0, "TDO high-impedance in Run-Test/Idle")

    // ---------------- IR capture and length
    begin
      logic [9:0] ir_in, ir_out;
      ir_in = 10'b11111_00001;               // first shifted: 1,0,0,0,0 then 1s (BYPASS)
      jclk(1, 0, d); jclk(1, 0, d); jclk(0, 0, d); jclk(0, 0, d);
      for (int i = 0; i < 10; i++) begin jclk(i == 9, ir_in[i], d); ir_out[i] = d; end
      jclk(1, 0, d); jclk(0, 0, d);
      `CHECK_EQ(ir_out[4:0], 5'b00001, "IR capture value (LSBs 01)")
      `CHECK_EQ(ir_out[9:5], 5'b00001, "IR length = 5 (injected pattern emerges after 5 bits)")
    end

    // ---------------- BYPASS and unassigned opcode
    load_ir(IR_BYPASS);
    shift_dr(128'h0000_0000_0000_0000_0000_0000_0000_B5A3, 16, o);
    `CHECK_EQ(o[15:0], 16'h6B46, "BYPASS: captures 0, then 1-bit delay of TDI")
    load_ir(8'h15);
    shift_dr(128'h5, 4, o);
    `CHECK_EQ(o[3:0], 4'b1010, "unassigned opcode 0x15 selects BYPASS")

    // ---------------- SAMPLE
    in_pad = 3'b101; io_pad_i = 8'hA5;
    load_ir(IR_SAMPLE);
    shift_dr('0, LEN, o);
    exp_v = bsr_vec(3'b101, 4'b0000, 4'b1111, 8'hA5, 8'h00, 8'h0F);
    `CHECK_EQ(o[LEN-1:0], exp_v, "SAMPLE captures pads, core outputs and enables")
    `CHECK_EQ({out_pad, out_pad_oe, io_pad_o, io_pad_oe}, {4'h0, 4'hF, 8'h00, 8'h0F}, "SAMPLE is non-invasive")
    jtag_idle(4);
    `CHECK_EQ(test_mode, TC_MODE_NORMAL, "SAMPLE does not enter JTAG mode")

    // ---------------- PRELOAD then EXTEST
    pre = bsr_vec(3'b000, 4'b1010, 4'b1101, 8'h00, 8'h3C, 8'hF0);
    shift_dr(128'(pre), LEN, o);                       // SAMPLE/PRELOAD: update loads pattern
    `CHECK_EQ({out_pad, io_pad_o}, {4'h0, 8'h00}, "PRELOAD does not drive pads")
    ext_rst_n = 1;                                     // release pad reset; EXTEST must hold the system
    load_ir(IR_EXTEST);
    `CHECK_EQ({out_pad, out_pad_oe}, {4'b1010, 4'b1101}, "EXTEST: output pins from update stage")
    `CHECK_EQ({io_pad_o, io_pad_oe}, {8'h3C, 8'hF0}, "EXTEST: bidir pins from update stage")
    jtag_idle(8);
    `CHECK_EQ(test_mode, TC_MODE_JTAG, "EXTEST enters JTAG mode")
    sysclk(10);
    `CHECK_EQ(sys_rst_n, 1'b0, "system held in reset during EXTEST")
    in_pad = 3'b010; io_pad_i = 8'h5A;
    pre = bsr_vec(3'b000, 4'b0101, 4'b1111, 8'h00, 8'hC3, 8'hFF);
    shift_dr(128'(pre), LEN, o);
    exp_v = bsr_vec(3'b010, 4'b0000, 4'b1111, 8'h5A, 8'h00, 8'h0F);
    `CHECK_EQ(o[LEN-1:0] & bsr_vec('1, '0, '0, '1, '0, '0), exp_v & bsr_vec('1, '0, '0, '1, '0, '0),
              "EXTEST: input cells capture pad values")
    `CHECK_EQ({out_pad, out_pad_oe, io_pad_o, io_pad_oe}, {4'b0101, 4'hF, 8'hC3, 8'hFF}, "EXTEST: new update applied")

    // ---------------- CLAMP and HIGHZ
    load_ir(IR_CLAMP);
    `CHECK_EQ({out_pad, out_pad_oe, io_pad_o, io_pad_oe}, {4'b0101, 4'hF, 8'hC3, 8'hFF}, "CLAMP holds update-stage values")
    shift_dr(128'h2, 2, o);
    `CHECK_EQ(o[1:0], 2'b00, "CLAMP selects 1-bit BYPASS")
    load_ir(IR_HIGHZ);
    `CHECK_EQ({out_pad_oe, io_pad_oe}, 12'h000, "HIGHZ disables every driver")
    jtag_idle(4);
    `CHECK_EQ(test_mode, TC_MODE_JTAG, "CLAMP/HIGHZ keep JTAG mode")

    // ---------------- return to functional
    load_ir(IR_IDCODE);
    `CHECK_EQ({out_pad_oe, io_pad_oe}, {4'hF, 8'h0F}, "non-invasive instruction restores functional drivers")
    jtag_idle(8);
    `CHECK_EQ(test_mode, TC_MODE_NORMAL, "JTAG mode exited")
    sysclk(12);
    `CHECK_EQ(sys_rst_n, 1'b1, "system leaves reset after boundary-scan test")

    // ---------------- TRST* during EXTEST
    load_ir(IR_EXTEST);
    `CHECK_EQ(io_pad_oe, 8'hFF, "EXTEST active again")
    #5 trst_n = 0;
    #1 `CHECK_EQ({out_pad_oe, io_pad_oe}, {4'hF, 8'h0F}, "TRST* immediately returns pads to functional")
    #10 trst_n = 1;
    jclk_n(1'b0, 2);
    shift_dr('0, 32, o);
    `CHECK_EQ(o[0], 1'b1, "IDCODE after TRST*")

    tb_finish("tb_tap_bsr");
  end
endmodule
