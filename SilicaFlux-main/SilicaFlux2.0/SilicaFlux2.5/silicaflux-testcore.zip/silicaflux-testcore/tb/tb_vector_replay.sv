// =============================================================================
// tb_vector_replay :: replay host-software TCK vectors against the RTL
// Vectors are produced by the Python flow running on the simulation transport
// wrapped in sftestcore.transports.recorder.VectorRecorder.  Every compared
// TDO bit must match the RTL.  This validates (a) the host flows and drivers,
// (b) the Python device model, against the real design -- the same principle
// as validating ATE patterns by simulation before silicon.
//   plusargs: +vec=<file> [+lc_otp=<hex>] [+fault_mem=.. +fault_type=.. ...]
// =============================================================================
`timescale 1ns/1ps
module tb_vector_replay;
  `include "tc_soc_harness.svh"
  `include "tc_tb_common.svh"

  initial begin
    string path;
    reg [8*256-1:0] line;
    reg [8*8-1:0] e, tok;
    int fd, t, d, n, cyc, compared, mism, lv, code;
    logic o;
    logic [7:0] lcv;
    if (!$value$plusargs("vec=%s", path)) begin
      $display("tb_vector_replay: FAIL (no +vec=<file>)"); $finish;
    end
    if ($value$plusargs("lc_otp=%h", lcv)) lc_otp = lcv;
    power_on();
    fd = $fopen(path, "r");
    if (fd == 0) begin $display("tb_vector_replay: FAIL (cannot open %s)", path); $finish; end
    cyc = 0; compared = 0; mism = 0;
    while ($fgets(line, fd)) begin
      tok = 0;
      n = $sscanf(line, "%s", tok);
      if (n == 1) begin
        if (tok == "#") begin
          // comment
        end else if (tok == "R") begin                    // TRST* level
          n = $sscanf(line, "R %d", lv);
          #(TCK_HALF) trst_n = lv[0];
          #(TCK_HALF);
        end else begin
          n = $sscanf(line, "%d %d %s", t, d, e);
          if (n == 3) begin
            jclk(t[0], d[0], o);
            cyc++;
            if (e != "x" && e != "X") begin
              compared++;
              if (o !== (e == "1" ? 1'b1 : 1'b0)) begin
                mism++;
                if (mism <= 20) $display("[%0t] TCK %0d: TDO=%b expected %s", $time, cyc, o, e);
              end
            end
          end
        end
      end
    end
    $fclose(fd);
    $display("replayed %0d TCK cycles, %0d TDO bits compared, %0d mismatches", cyc, compared, mism);
    `CHECK(compared > 0, "vectors contain compared TDO bits")
    `CHECK_EQ(mism, 0, "RTL TDO matches host-flow expectation on every compared bit")
    tb_finish("tb_vector_replay");
  end
endmodule
