// =============================================================================
// Shared demo-SoC harness (include at module scope, before tc_tb_common.svh)
// =============================================================================
`include "tc_demo_cfg.svh"

real TCK_HALF = DEMO_TCK_NS / 2.0;
logic tck = 0, tms = 1, tdi = 0, trst_n = 1;
wire  tdo, tdo_oe;
logic por_n = 1, ext_rst_n = 1, func_clk = 0, test_clk = 0, ref_clk = 0, pll_lock = 1;
logic otp_valid = 1; logic [7:0] lc_otp = 8'h00;
logic wdt_req = 0;
logic [2:0] in_pad = 3'b000; logic [7:0] io_pad_i = 8'h00;
wire [3:0] out_pad, out_pad_oe; wire [7:0] io_pad_o, io_pad_oe;
logic psel = 0, penable = 0, pwrite = 0; logic [11:0] paddr = 0; logic [31:0] pwdata = 0;
wire [31:0] prdata; wire pready, pslverr;
logic f0_ce = 0, f0_we = 0; logic [7:0] f0_addr = 0; logic [31:0] f0_wdata = 0;
wire [31:0] f0_rdata; wire f0_ready;
wire clk_o, sys_rst_n, core_rst_n, scan_mode, scan_en, cg_te, lbist_sel;
wire [2:0] test_mode, in_core; wire [3:0] gated_cnt;

bit func_run = 1, test_run = 0;
always #(DEMO_SYS_NS / 2.0) if (func_run) func_clk = ~func_clk;
always #(DEMO_REF_NS / 2.0) ref_clk = ~ref_clk;
always #(DEMO_TCK_NS / 2.0) if (test_run) test_clk = ~test_clk;

tc_demo_soc soc (
  .tck, .tms, .tdi, .trst_n, .tdo, .tdo_oe, .por_n, .ext_rst_n, .func_clk, .test_clk, .ref_clk, .pll_lock,
  .otp_valid, .lc_otp, .wdt_req, .in_pad, .out_pad, .out_pad_oe, .io_pad_o, .io_pad_oe, .io_pad_i,
  .psel, .penable, .pwrite, .paddr, .pwdata, .prdata, .pready, .pslverr,
  .f0_ce, .f0_we, .f0_addr, .f0_wdata, .f0_rdata, .f0_ready,
  .clk_o, .sys_rst_n, .core_rst_n, .scan_mode, .scan_en, .cg_te, .test_mode, .lbist_sel, .gated_cnt, .in_core
);

task automatic power_on();
  por_n = 1; trst_n = 1;
  #3 por_n = 0; trst_n = 0;
  #100 por_n = 1; trst_n = 1;
  #200;
endtask

task automatic sysclk(input int n); repeat (n) @(posedge clk_o); endtask

task automatic apb_rd(input logic [11:0] a, output logic [31:0] d, output logic err);
  @(negedge clk_o); psel = 1; pwrite = 0; paddr = a; penable = 0;
  @(negedge clk_o); penable = 1;
  while (!pready) @(negedge clk_o);
  #1 d = prdata; err = pslverr;
  @(negedge clk_o); psel = 0; penable = 0;
endtask

task automatic apb_wr(input logic [11:0] a, input logic [31:0] d, output logic err);
  @(negedge clk_o); psel = 1; pwrite = 1; paddr = a; pwdata = d; penable = 0;
  @(negedge clk_o); penable = 1;
  while (!pready) @(negedge clk_o);
  #1 err = pslverr;
  @(negedge clk_o); psel = 0; penable = 0; pwrite = 0;
endtask
