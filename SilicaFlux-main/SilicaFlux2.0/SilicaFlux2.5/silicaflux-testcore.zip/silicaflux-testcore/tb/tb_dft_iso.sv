// =============================================================================
// tb_dft_iso :: test-mode isolation and scan-preparation checks (demo SoC)
//  * outside SCAN_TEST, scan-enable / scan-reset pins have no effect
//    (scan_en, clock-gate TE and resets isolated); continuous monitor
//  * MEMORY_BIST: functional memory port blocked; MBIST status on GPIO0/1
//  * NORMAL: functional memory port works
//  * LOGIC_TEST: LBIST input mux engaged only in LOGIC_TEST; golden signature
//    from an independent SV reference model; status on GPIO0/1
//  * SCAN_TEST: root clock = test clock; scan_en from pin drives ICG TE;
//    scan reset pin controls all resets; scan-in/out pin path through a
//    stand-in chain; memory scan bypass (shadow) observable
// =============================================================================
`timescale 1ns/1ps
module tb_dft_iso;
  import tc_spec_pkg::*;
  `include "tc_soc_harness.svh"
  `include "tc_tb_common.svh"

  // ---- continuous isolation monitor
  int iso_viol = 0;
  always @(posedge clk_o) if (por_n && !scan_mode && (scan_en || cg_te)) iso_viol++;

  // ---- independent LBIST reference model
  function automatic logic [31:0] r_lfsr(input logic [31:0] s);
    logic fb; fb = s[0];
    r_lfsr = {1'b0, s[31:1]};
    if (fb) r_lfsr = r_lfsr ^ 32'h8020_0003;
  endfunction
  function automatic logic [32:0] r_alu(input logic [67:0] in);
    logic [31:0] a, b, y; logic [3:0] op; logic signed [31:0] sa, sb;
    a = in[31:0]; b = in[63:32]; op = in[67:64]; sa = a; sb = b;
    if      (op == 0)  y = a + b;
    else if (op == 1)  y = a + (~b + 1);
    else if (op == 2)  y = a & b;
    else if (op == 3)  y = a | b;
    else if (op == 4)  y = a ^ b;
    else if (op == 5)  y = a << (b % 32);
    else if (op == 6)  y = a >> (b % 32);
    else if (op == 7)  y = sa >>> (b % 32);
    else if (op == 8)  y = (sa < sb) ? 1 : 0;
    else if (op == 9)  y = (a < b) ? 1 : 0;
    else if (op == 10) y = a;
    else if (op == 11) y = b;
    else if (op == 12) y = ~(a | b);
    else if (op == 13) y = ~(a ^ b);
    else if (op == 14) y = a & ~b;
    else               y = a | ~b;
    return {(y == 0), y};
  endfunction
  function automatic logic [31:0] lbist_golden(input logic [31:0] seed, input int n);
    logic [31:0] s, m, f; logic [67:0] in; logic [32:0] out;
    s = (seed == 0) ? 1 : seed; m = 0;
    for (int k = 0; k < n; k++) begin
      for (int i = 0; i < 68; i++) in[i] = s[i % 32] ^ s[(5*i + 3) % 32] ^ s[(13*i + 7) % 32];
      out = r_alu(in);
      f = out[31:0] ^ {31'd0, out[32]};
      m = r_lfsr(m) ^ f;
      s = r_lfsr(s);
    end
    return m;
  endfunction

  task automatic req(input int mode, input logic [3:0] opts = 4'h0);
    logic [11:0] c; tc_mode_req(3'(mode), opts, c);
  endtask

  initial begin
    logic [31:0] v, st; logic [1:0] rs; logic e; logic [3:0] g0;
    power_on();
    jclk_n(1'b0, 2);
    sysclk(20);

    // ---------------- NORMAL: scan pins inert
    io_pad_i = 8'b0000_0011;                          // scan_en and scan_rst_n pins at 1,1
    sysclk(5); g0 = gated_cnt;
    io_pad_i = 8'b0000_0001;                          // scan_en pin high, scan_rst pin low
    sysclk(10);
    `CHECK_EQ({scan_en, cg_te}, 2'b00, "NORMAL: scan-enable pin ignored")
    `CHECK_EQ(gated_cnt, g0, "NORMAL: gated clock not forced on")
    `CHECK_EQ({sys_rst_n, core_rst_n}, 2'b11, "NORMAL: scan-reset pin has no effect")
    `CHECK_EQ(lbist_sel, 1'b0, "NORMAL: LBIST mux disengaged")
    io_pad_i = 8'h00;

    // ---------------- functional memory port works in NORMAL
    @(negedge clk_o); f0_ce = 1; f0_we = 1; f0_addr = 8'd7; f0_wdata = 32'hCAFE_F00D;
    @(negedge clk_o); f0_we = 0;
    @(negedge clk_o); f0_ce = 0;
    @(negedge clk_o);
    `CHECK_EQ(f0_rdata, 32'hCAFE_F00D, "NORMAL: functional write/read through collar")
    `CHECK_EQ(f0_ready, 1'b1, "NORMAL: functional port ready")

    // ---------------- MEMORY_BIST: isolation + status pins
    req(TC_MODE_MEMORY_BIST);
    sysclk(4);
    `CHECK_EQ(f0_ready, 1'b0, "MEMORY_BIST: functional port blocked")
    `CHECK_EQ(io_pad_oe[1:0], 2'b11, "MEMORY_BIST: status pins driven")
    tc_reg_write(TC_R_MBIST_MEM_SEL, 32'h1F, rs);
    tc_reg_write(TC_R_MBIST_CTRL, {21'd0, 1'b0, 1'b0, 3'd0, TC_ALG_MARCH_C_MINUS, 2'b01}, rs);
    wait (!soc.u_tc.u_mbist.busy_o); sysclk(2);
    `CHECK_EQ(io_pad_o[1:0], 2'b01, "MEMORY_BIST: GPIO0=done GPIO1=fail(0)")
    soc.g_mem[0].u_mem.set_fault(1, 3, 2, 0, 0, 0);
    tc_reg_write(TC_R_MBIST_MEM_SEL, 32'h01, rs);
    tc_reg_write(TC_R_MBIST_CTRL, {21'd0, 1'b0, 1'b0, 3'd0, TC_ALG_MARCH_C_MINUS, 2'b01}, rs);
    wait (!soc.u_tc.u_mbist.busy_o); sysclk(2);
    `CHECK_EQ(io_pad_o[1:0], 2'b11, "MEMORY_BIST: GPIO1 flags failure")
    soc.g_mem[0].u_mem.set_fault(0, 0, 0, 0, 0, 0);
    req(TC_MODE_NORMAL); sysclk(20);
    `CHECK_EQ(f0_ready, 1'b1, "after MEMORY_BIST: functional port released")

    // ---------------- LOGIC_TEST
    req(TC_MODE_LOGIC_TEST);
    sysclk(4);
    `CHECK_EQ(lbist_sel, 1'b1, "LOGIC_TEST: target inputs from PRPG")
    tc_reg_write(TC_R_LBIST_SEED, 32'hACE1_2026, rs);
    tc_reg_write(TC_R_LBIST_PATTERNS, 32'd1000, rs);
    tc_reg_write(TC_R_LBIST_SIG_EXP, lbist_golden(32'hACE1_2026, 1000), rs);
    tc_reg_write(TC_R_LBIST_CTRL, 32'h1, rs);
    `CHECK_EQ(rs, TC_REGST_OK, "LBIST start accepted")
    jtag_idle(400);
    tc_reg_read(TC_R_LBIST_STATUS, st, rs);
    `CHECK_EQ(st[2:0], 3'b110, "LBIST: done and pass (RTL signature == independent SV model)")
    tc_reg_read(TC_R_LBIST_SIG, v, rs);
    `CHECK_EQ(v, lbist_golden(32'hACE1_2026, 1000), "LBIST signature value")
    `CHECK_EQ(io_pad_o[1:0], 2'b11, "LOGIC_TEST: GPIO0=done GPIO1=pass")
    tc_reg_write(TC_R_LBIST_SIG_EXP, 32'h0BAD_0BAD, rs);
    tc_reg_write(TC_R_LBIST_CTRL, 32'h1, rs);
    jtag_idle(400);
    tc_reg_read(TC_R_LBIST_STATUS, st, rs);
    `CHECK_EQ(st[2:0], 3'b010, "LBIST: wrong expected signature -> no pass")
    req(TC_MODE_NORMAL); sysclk(20);
    `CHECK_EQ(lbist_sel, 1'b0, "after LOGIC_TEST: LBIST mux released")

    // ---------------- SCAN_TEST
    io_pad_i = 8'b0000_0010;                           // scan_en=0, scan_rst_n=1
    req(TC_MODE_SCAN_TEST);
    `CHECK_EQ(scan_mode, 1'b1, "SCAN_TEST active")
    `CHECK_EQ(io_pad_oe, 8'b0011_0000, "SCAN_TEST: only scan-out pins driven")
    test_run = 1;                                       // ATE starts the test clock
    begin
      int n_clk, n_test;
      n_clk = 0; n_test = 0;
      fork
        repeat (20) @(posedge test_clk) n_test++;
        forever @(posedge clk_o) n_clk++;
      join_any
      disable fork;
      `CHECK(n_clk >= 19 && n_clk <= 21, $sformatf("SCAN_TEST: root clock follows test clock (%0d/%0d)", n_clk, n_test))
    end
    // scan reset pin
    io_pad_i[1] = 0; #1;
    `CHECK_EQ({sys_rst_n, core_rst_n, soc.u_tc.tc_rst_n}, 3'b000, "SCAN_TEST: scan-reset pin drives all resets")
    io_pad_i[1] = 1; #1;
    `CHECK_EQ({sys_rst_n, core_rst_n, soc.u_tc.tc_rst_n}, 3'b111, "SCAN_TEST: resets released by pin")
    // scan enable -> ICG TE
    @(negedge test_clk); io_pad_i[0] = 0; g0 = gated_cnt;
    repeat (4) @(posedge test_clk); #1;
    `CHECK_EQ(gated_cnt, g0, "SCAN_TEST capture (scan_en=0): functional enable controls gated clock")
    @(negedge test_clk); io_pad_i[0] = 1;
    #1 `CHECK_EQ({scan_en, cg_te}, 2'b11, "SCAN_TEST: scan_en pin -> scan enable and clock-gate TE")
    repeat (4) @(posedge test_clk); #1;
    `CHECK_EQ(gated_cnt, 4'(g0 + 4), "SCAN_TEST shift: gated clock forced on by TE")
    // scan-in -> chain -> scan-out pin path (4-flop stand-in chain)
    begin
      logic [7:0] pat, got;
      pat = 8'b1011_0010;
      for (int k = 0; k < 8; k++) begin
        @(negedge test_clk); io_pad_i[2] = pat[k];
        @(posedge test_clk); #1;
      end
      for (int k = 0; k < 8; k++) begin
        @(negedge test_clk); io_pad_i[2] = 0; #1 got[k] = io_pad_o[4];
        @(posedge test_clk);
      end
      `CHECK_EQ(got[3:0], pat[7:4], "SCAN_TEST: scan_in[0] pin -> chain -> scan_out[0] pin")
    end
    // memory scan bypass (shadow register makes the black-box RAM controllable/observable)
    @(negedge test_clk); f0_ce = 1; f0_we = 1; f0_addr = 8'd0; f0_wdata = 32'h1357_9BDF;
    @(negedge test_clk); f0_ce = 0; f0_we = 0;
    #1 `CHECK_EQ(f0_rdata, 32'h1357_9BDF, "SCAN_TEST: memory read data from scan bypass shadow")
    io_pad_i[0] = 0;
    // exit: ATE parks test clock low, then request NORMAL
    test_run = 0; wait (!test_clk);
    req(TC_MODE_NORMAL);
    sysclk(30);
    `CHECK_EQ({scan_mode, scan_en}, 2'b00, "after SCAN_TEST: scan disabled")
    `CHECK_EQ({sys_rst_n, core_rst_n}, 2'b11, "after SCAN_TEST: system running on functional clock")

    `CHECK_EQ(iso_viol, 0, "scan enable / clock-gate TE never active outside SCAN_TEST")
    tb_finish("tb_dft_iso");
  end
endmodule
