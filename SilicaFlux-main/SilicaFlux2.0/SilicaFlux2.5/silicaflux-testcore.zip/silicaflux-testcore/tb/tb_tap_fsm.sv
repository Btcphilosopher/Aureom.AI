// =============================================================================
// tb_tap_fsm :: TAP controller state-machine verification
//  * independent reference model (state names, written from IEEE 1149.1 Fig. 6-1)
//  * all 32 (state, TMS) transitions covered, plus 4000-step random walk
//  * TMS=1 for 5 TCKs reaches Test-Logic-Reset from every state
//  * TRST* asynchronously resets from every state
//  * capture/shift/update DR strobes only in their own states
//  * IR forced to IDCODE in TLR; TDO enabled only in Shift-IR/Shift-DR and
//    changes only on the falling edge of TCK
// =============================================================================
`timescale 1ns/1ps
module tb_tap_fsm;
  import tc_pkg::*;
  import tc_spec_pkg::*;

  real TCK_HALF = 20.0;
  logic tck = 0, tms = 1, tdi = 0, trst_n = 1;
  wire  tdo, tdo_oe;
  logic [3:0] state;
  logic [4:0] ir;
  logic cap_dr, sh_dr, upd_dr, tlr;

  tc_tap dut (
    .tck, .trst_n, .tms, .tdi, .tdo, .tdo_oe, .idcode_version_i(4'h3),
    .state_o(state), .ir_o(ir), .capture_dr_o(cap_dr), .shift_dr_o(sh_dr), .update_dr_o(upd_dr), .tlr_o(tlr),
    .tdo_bsr_i(1'b0), .tdo_status_i(1'b0), .tdo_mode_i(1'b0), .tdo_unlock_i(1'b0), .tdo_reg_i(1'b0)
  );

  `include "tc_tb_common.svh"

  // ---- independent reference: 0 TLR 1 RTI 2 SDR 3 CDR 4 SHDR 5 E1DR 6 PDR 7 E2DR 8 UDR
  //                             9 SIR 10 CIR 11 SHIR 12 E1IR 13 PIR 14 E2IR 15 UIR
  function automatic int ref_next(input int s, input logic t);
    case (s)
      0: return t ? 0 : 1;     1: return t ? 2 : 1;     2: return t ? 9 : 3;    3: return t ? 5 : 4;
      4: return t ? 5 : 4;     5: return t ? 8 : 6;     6: return t ? 7 : 6;    7: return t ? 8 : 4;
      8: return t ? 2 : 1;     9: return t ? 0 : 10;   10: return t ? 12 : 11; 11: return t ? 12 : 11;
      12: return t ? 15 : 13; 13: return t ? 14 : 13; 14: return t ? 15 : 11; 15: return t ? 2 : 1;
      default: return 0;
    endcase
  endfunction
  function automatic string nm(input int s);
    case (s)
      0: return "TLR"; 1: return "RTI"; 2: return "SEL_DR"; 3: return "CAP_DR"; 4: return "SH_DR";
      5: return "EX1_DR"; 6: return "PAU_DR"; 7: return "EX2_DR"; 8: return "UPD_DR"; 9: return "SEL_IR";
      10: return "CAP_IR"; 11: return "SH_IR"; 12: return "EX1_IR"; 13: return "PAU_IR"; 14: return "EX2_IR";
      default: return "UPD_IR";
    endcase
  endfunction
  // map reference index -> DUT encoding (from tc_pkg)
  logic [3:0] enc [16];
  initial begin
    enc[0]=TAP_TLR; enc[1]=TAP_RTI; enc[2]=TAP_SEL_DR; enc[3]=TAP_CAPT_DR; enc[4]=TAP_SHIFT_DR;
    enc[5]=TAP_EXIT1_DR; enc[6]=TAP_PAUSE_DR; enc[7]=TAP_EXIT2_DR; enc[8]=TAP_UPDATE_DR;
    enc[9]=TAP_SEL_IR; enc[10]=TAP_CAPT_IR; enc[11]=TAP_SHIFT_IR; enc[12]=TAP_EXIT1_IR;
    enc[13]=TAP_PAUSE_IR; enc[14]=TAP_EXIT2_IR; enc[15]=TAP_UPDATE_IR;
  end

  int  ref_s;
  bit  covered [16][2];

  task automatic step(input logic t);
    logic d;
    int   nx;
    nx = ref_next(ref_s, t);
    covered[ref_s][t] = 1;
    jclk(t, $urandom_range(0, 1), d);
    ref_s = nx;
    `CHECK_EQ(state, enc[ref_s], $sformatf("transition to %s", nm(ref_s)))
    `CHECK(cap_dr == (ref_s == 3) && sh_dr == (ref_s == 4) && upd_dr == (ref_s == 8) && tlr == (ref_s == 0),
           $sformatf("DR strobes consistent in %s", nm(ref_s)))
  endtask

  // TDO must only change while TCK is low (falling-edge launched)
  always @(tdo or tdo_oe) if (tck !== 1'b0 && $time > 0) begin
    tb_errors++; $display("[%0t] FAIL: TDO/TDO_OE changed while TCK high", $time);
  end
  // TDO enable only in shift states (checked after the falling edge)
  always @(negedge tck) if (trst_n) begin
    #1;
    tb_checks++;
    if (tdo_oe !== ((state == TAP_SHIFT_DR) || (state == TAP_SHIFT_IR))) begin
      tb_errors++; $display("[%0t] FAIL: tdo_oe=%b in state %h", $time, tdo_oe, state);
    end
  end

  initial begin
    #1 trst_n = 0;
    #4 trst_n = 1;
    ref_s = 0;
    `CHECK_EQ(state, TAP_TLR, "reset state is TLR")
    `CHECK_EQ(ir, TC_IR_IDCODE, "IR = IDCODE after TRST")

    // random walk
    for (int i = 0; i < 4000; i++) step($urandom_range(0, 99) < 45);
    // close any coverage holes deterministically
    for (int s = 0; s < 16; s++) for (int t = 0; t < 2; t++) begin
      if (!covered[s][t]) begin
        // walk to s from TLR using reference BFS-free search: repeated random walk
        int guard;
        guard = 0;
        while (ref_s != s && guard < 2000) begin step($urandom_range(0, 1)); guard++; end
        step(t[0]);
      end
    end
    begin
      int miss;
      miss = 0;
      for (int s = 0; s < 16; s++) for (int t = 0; t < 2; t++) if (!covered[s][t]) miss++;
      `CHECK_EQ(miss, 0, "all 32 (state,TMS) transitions covered")
    end

    // TMS=1 x5 from every state reaches TLR; IR becomes IDCODE
    for (int s = 0; s < 16; s++) begin
      int guard;
      guard = 0;
      while (ref_s != s && guard < 2000) begin step($urandom_range(0, 1)); guard++; end
      for (int k = 0; k < 5; k++) step(1'b1);
      `CHECK_EQ(state, TAP_TLR, $sformatf("5xTMS=1 from %s reaches TLR", nm(s)))
      #(TCK_HALF);
      `CHECK_EQ(ir, TC_IR_IDCODE, "IR forced to IDCODE in TLR")
    end

    // load BYPASS, then async TRST from every state
    begin
      logic [7:0] c;
      step(1'b0); ref_s = 1;
      shift_ir(8'h1F, 5, c);
      ref_s = 1;
      #1 `CHECK_EQ(ir, TC_IR_BYPASS, "IR updated to BYPASS")
      `CHECK_EQ(c[1:0], 2'b01, "IR capture LSBs = 01")
    end
    for (int s = 0; s < 16; s++) begin
      int guard;
      guard = 0;
      while (ref_s != s && guard < 2000) begin step($urandom_range(0, 1)); guard++; end
      #3 trst_n = 0;
      #1 `CHECK_EQ(state, TAP_TLR, $sformatf("TRST* async reset from %s", nm(s)))
      `CHECK_EQ(ir, TC_IR_IDCODE, "TRST* forces IDCODE")
      #3 trst_n = 1;
      ref_s = 0;
    end
    tb_finish("tb_tap_fsm");
  end
endmodule
