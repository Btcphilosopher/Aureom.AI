// =============================================================================
// SilicaFlux TestCore :: tc_clk_ctrl
//
// Root clock selection for scan test and a simple clock monitor.
//
//   func_clk_i --[tc_icg en=~stop]--+
//                                   +--[tc_clk_mux2 sel=test_sel]--> clk_o
//   test_clk_i ---------------------+
//
// The mode controller sequences SCAN_TEST entry as: assert stop (functional
// clock gated cleanly by an ICG whose enable is synchronised to func_clk),
// wait, switch the mux, and the protocol requires the ATE to hold test_clk_i
// low until the switch has completed.  Exit reverses the order.  This is a
// slow-speed (shift/capture from the tester) scan clocking scheme.
// At-speed transition test needs an On-Chip Clock controller (OCC) that
// passes programmable launch/capture pulses from the PLL; that is commercial
// DFT IP and is NOT implemented here -- see docs/06_scan_architecture.md.
//
// Clock monitor: a reference-clock window (REF_WINDOW ref cycles) is
// toggled in the ref domain; clk_o cycles per window are latched (CLK_MEAS).
// Classification: SYNTHESIZABLE (cells require library mapping for ASIC)
// =============================================================================
`default_nettype none

module tc_clk_ctrl #(
  parameter int REF_WINDOW = 64
) (
  input  wire logic        por_n,
  input  wire logic        scan_mode,      // static test signals (TCK domain)
  input  wire logic        scan_rst_n,
  input  wire logic        func_clk_i,
  input  wire logic        test_clk_i,
  input  wire logic        ref_clk_i,
  input  wire logic        stop_req,       // TCK-domain level
  input  wire logic        test_sel,       // TCK-domain level (sequenced)
  output logic             clk_o,
  // monitor (clk_o domain)
  input  wire logic        rst_n,          // tc_rst_n
  output logic [31:0]      meas_o,
  output logic             meas_valid_o,
  output logic [31:0]      cycles_o
);
  // ------------------------------------------------------------- clean functional gate
  logic stop_s;
  tc_sync #(.W(1)) u_stop_sync (.clk(func_clk_i), .rst_n(por_n), .d(stop_req), .q(stop_s));

  logic func_gclk;
  tc_icg u_func_icg (.clk(func_clk_i), .en(~stop_s), .te(1'b0), .gclk(func_gclk));
  tc_clk_mux2 u_root_mux (.clk0(func_gclk), .clk1(test_clk_i), .sel(test_sel), .clk_o(clk_o));

  // ------------------------------------------------------------- reference window
  // Reset through a DFT mux so ATPG controls it in scan mode (scan-readiness S2).
  localparam int RW = $clog2(REF_WINDOW);
  logic [RW-1:0] ref_cnt;
  logic          win_tgl, ref_rst_n;
  tc_dft_mux2 u_ref_rst_mux (.a(por_n), .b(scan_rst_n), .s(scan_mode), .y(ref_rst_n));
  always_ff @(posedge ref_clk_i or negedge ref_rst_n) begin
    if (!ref_rst_n) begin
      ref_cnt <= '0;
      win_tgl <= 1'b0;
    end else begin
      ref_cnt <= ref_cnt + 1'b1;
      if (ref_cnt == RW'(REF_WINDOW - 1)) win_tgl <= ~win_tgl;
    end
  end

  logic win_s, win_q;
  logic [31:0] run_cnt;
  tc_sync #(.W(1)) u_win_sync (.clk(clk_o), .rst_n(rst_n), .d(win_tgl), .q(win_s));
  always_ff @(posedge clk_o or negedge rst_n) begin
    if (!rst_n) begin
      win_q        <= 1'b0;
      run_cnt      <= '0;
      meas_o       <= '0;
      meas_valid_o <= 1'b0;
      cycles_o     <= '0;
    end else begin
      cycles_o <= cycles_o + 32'd1;
      win_q    <= win_s;
      if (win_s != win_q) begin
        meas_o       <= run_cnt;
        meas_valid_o <= 1'b1;
        run_cnt      <= 32'd1;
      end else if (run_cnt != 32'hFFFF_FFFF) begin
        run_cnt <= run_cnt + 32'd1;
      end
    end
  end
  // The first window after reset is partial; meas_valid is set on the first
  // edge, host software should discard the first sample (sftestcore does).

endmodule

`default_nettype wire
