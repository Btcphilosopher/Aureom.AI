// =============================================================================
// SilicaFlux TestCore :: tc_reg_bridge
// TC_REG data register (46 bits) and toggle-handshake CDC from TCK to the
// system clock domain.
//
//   DR layout   [45:44] OP / STATUS   [43:32] ADDR   [31:0] DATA
//   Write OP    0 NOP, 1 READ, 2 WRITE, 3 CLEAR_BUSY
//   Capture     STATUS (0 OK, 2 ERROR, 3 BUSY), ADDR of the completed request,
//               DATA = read data of the completed request.
//
// A request is launched at Update-DR.  Its result is returned by the *next*
// Capture-DR of TC_REG.  The host must spend >= min_idle_tck (spec) TCK cycles
// in Run-Test/Idle between scans; this is sufficient when f_sys >= f_TCK/2.
// If a capture finds the previous request still in flight, STATUS=BUSY is
// returned and a sticky busy flag is set: all further requests are ignored
// until a CLEAR_BUSY op is scanned (RISC-V DTM-like semantics) -- the host
// therefore always knows whether a request was dropped.
//
// CDC: payload registers are TCK-domain and held stable from launch until the
// acknowledge toggle returns (classic 4-phase-equivalent toggle protocol).
// Result registers are system-domain and stable once the ack is observed.
// Handshake state is reset by POR only (not TRST*), so TLR never strands a
// request.  After a TestCore system-domain reset the receiver re-arms by
// adopting the current request toggle, so no stale request is replayed.
// Classification: SYNTHESIZABLE (TCK side: exclude from scan)
// =============================================================================
`default_nettype none

module tc_reg_bridge
  import tc_spec_pkg::*;
  import tc_pkg::*;
(
  // TCK domain
  input  wire logic        tck,
  input  wire logic        por_n,
  input  wire logic [3:0]  tap_state,
  input  wire logic        sel,            // IR == TC_REG
  input  wire logic        tdi,
  output logic             tdo,
  output logic             busy_tck_o,
  // system domain
  input  wire logic        clk,
  input  wire logic        rst_n,          // TestCore system-domain reset
  output logic             m_req,
  output logic             m_we,
  output logic [11:0]      m_addr,
  output logic [31:0]      m_wdata,
  input  wire logic        m_gnt,
  input  wire logic [31:0] m_rdata,
  input  wire logic        m_err
);
  // ------------------------------------------------------------- TCK side
  logic [45:0] sh;
  logic        req_tgl, sticky;
  logic        pl_we;
  logic [11:0] pl_addr;
  logic [31:0] pl_data;
  logic        ack_tgl, ack_sync;
  logic [31:0] res_rdata;
  logic [11:0] res_addr;
  logic        res_err;

  tc_sync #(.W(1)) u_ack_sync (.clk(tck), .rst_n(por_n), .d(ack_tgl), .q(ack_sync));
  wire busy_now = (req_tgl != ack_sync);
  assign busy_tck_o = busy_now;

  wire cap = sel && (tap_state == TAP_CAPT_DR);
  wire sft = sel && (tap_state == TAP_SHIFT_DR);
  wire upd = sel && (tap_state == TAP_UPDATE_DR);
  wire [1:0] op = sh[45:44];

  always_ff @(posedge tck) begin
    if (cap) begin
      if (busy_now || sticky) sh <= {TC_REGST_BUSY, 12'd0, 32'd0};
      else                    sh <= {res_err ? TC_REGST_ERROR : TC_REGST_OK, res_addr, res_rdata};
    end else if (sft) begin
      sh <= {tdi, sh[45:1]};
    end
  end

  always_ff @(posedge tck or negedge por_n) begin
    if (!por_n) begin
      req_tgl <= 1'b0;
      sticky  <= 1'b0;
      pl_we   <= 1'b0;
      pl_addr <= '0;
      pl_data <= '0;
    end else begin
      if (cap && busy_now) sticky <= 1'b1;
      if (upd) begin
        if (sticky) begin
          if (op == TC_REGOP_CLEAR_BUSY && !busy_now) sticky <= 1'b0;
        end else if (op == TC_REGOP_READ || op == TC_REGOP_WRITE) begin
          if (busy_now) begin
            sticky <= 1'b1;
          end else begin
            pl_we   <= (op == TC_REGOP_WRITE);
            pl_addr <= sh[43:32];
            pl_data <= sh[31:0];
            req_tgl <= ~req_tgl;
          end
        end
      end
    end
  end
  assign tdo = sh[0];

  // ------------------------------------------------------------- system side
  logic       req_sync, req_seen;
  logic [1:0] arm_cnt;
  tc_sync #(.W(1)) u_req_sync (.clk(clk), .rst_n(rst_n), .d(req_tgl), .q(req_sync));

  wire armed   = (arm_cnt == 2'd3);
  wire pending = armed && (req_sync != req_seen);

  assign m_req   = pending;
  assign m_we    = pl_we;     // stable while pending (CDC protocol)
  assign m_addr  = pl_addr;
  assign m_wdata = pl_data;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      arm_cnt   <= 2'd0;
      req_seen  <= 1'b0;
      res_rdata <= '0;
      res_addr  <= '0;
      res_err   <= 1'b0;
    end else if (!armed) begin
      arm_cnt  <= arm_cnt + 2'd1;
      req_seen <= req_sync;            // adopt, never replay a stale request
    end else if (pending && m_gnt) begin
      res_rdata <= m_we ? 32'd0 : m_rdata;
      res_addr  <= pl_addr;
      res_err   <= m_err;
      req_seen  <= req_sync;
    end
  end
  assign ack_tgl = req_seen;

endmodule

`default_nettype wire
