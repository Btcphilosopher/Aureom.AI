// =============================================================================
// SilicaFlux TestCore :: tc_mbist_collar
// Test collar placed between functional logic and one memory macro.
//
//   * bist_active (MEMORY_BIST mode) switches the macro to the MBIST test bus
//     for the whole mode; functional requests are blocked (f_ready = 0).
//   * IN_PIPE / OUT_PIPE optional register stages on the TEST path only
//     (MBIST bus timing closure across the die).  The registry latency for the
//     memory must equal macro latency + IN_PIPE + OUT_PIPE.
//   * SCAN_BYPASS: in scan mode the functional read data comes from a shadow
//     register that captures (write data XOR folded address) on every
//     functional access, so ATPG can control the macro outputs and observe the
//     macro inputs while the macro itself is a black box.  (Commercial flows
//     may instead use "RAM sequential" ATPG models; see docs.)
//   * TYPE = 0 (1RW, ROM with f_we tied 0) or 1 (1R1W: separate read/write ports).
// Write masks are lane-based (WM_W lanes); MBIST always writes all lanes.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module tc_mbist_collar #(
  parameter int DW          = 32,
  parameter int AW          = 8,
  parameter int WM_W        = 1,
  parameter int TBUS_DW     = 72,     // MBIST bus data width (MAX_DW)
  parameter int TBUS_AW     = 16,     // MBIST bus address width (MAX_AW)
  parameter int TYPE        = 0,      // 0: 1RW/ROM, 1: 1R1W
  parameter bit IN_PIPE     = 1'b0,
  parameter bit OUT_PIPE    = 1'b0,
  parameter bit SCAN_BYPASS = 1'b1
) (
  input  wire logic               clk,
  input  wire logic               scan_mode,
  // MBIST test bus
  input  wire logic               bist_active,
  input  wire logic               bist_sel,
  input  wire logic               bist_ce,
  input  wire logic               bist_we,
  input  wire logic [TBUS_AW-1:0] bist_addr,
  input  wire logic [TBUS_DW-1:0] bist_wdata,
  output logic      [TBUS_DW-1:0] bist_rdata,
  // functional side (TYPE 0: ce/we/addr; TYPE 1: re/raddr + we/waddr)
  input  wire logic               f_ce,
  input  wire logic               f_we,
  input  wire logic [AW-1:0]      f_addr,
  input  wire logic [AW-1:0]      f_waddr,
  input  wire logic [DW-1:0]      f_wdata,
  input  wire logic [WM_W-1:0]    f_wmask,
  output logic      [DW-1:0]      f_rdata,
  output logic                    f_ready,
  // macro side
  output logic                    m_ce,      // TYPE0: chip enable;  TYPE1: read enable
  output logic                    m_we,      // TYPE0: write;        TYPE1: write enable
  output logic      [AW-1:0]      m_addr,    // TYPE0: address;      TYPE1: read address
  output logic      [AW-1:0]      m_waddr,   // TYPE1 write address
  output logic      [DW-1:0]      m_wdata,
  output logic      [WM_W-1:0]    m_wmask,
  input  wire logic [DW-1:0]      m_rdata
);
  // ------------------------------------------------------------- test-path input stage
  logic          t_ce, t_we;
  logic [AW-1:0] t_addr;
  logic [DW-1:0] t_wdata;
  generate
    if (IN_PIPE) begin : g_inp
      always_ff @(posedge clk) begin
        t_ce    <= bist_active && bist_sel && bist_ce;
        t_we    <= bist_we;
        t_addr  <= bist_addr[AW-1:0];
        t_wdata <= bist_wdata[DW-1:0];
      end
    end else begin : g_noinp
      assign t_ce    = bist_active && bist_sel && bist_ce;
      assign t_we    = bist_we;
      assign t_addr  = bist_addr[AW-1:0];
      assign t_wdata = bist_wdata[DW-1:0];
    end
  endgenerate

  // ------------------------------------------------------------- macro port mux
  assign f_ready = !bist_active;
  always_comb begin
    if (bist_active) begin
      m_wdata = t_wdata;
      m_wmask = '1;
      if (TYPE == 1) begin
        m_ce    = t_ce && !t_we;
        m_we    = t_ce &&  t_we;
        m_addr  = t_addr;
        m_waddr = t_addr;
      end else begin
        m_ce    = t_ce;
        m_we    = t_ce && t_we;
        m_addr  = t_addr;
        m_waddr = t_addr;
      end
    end else begin
      m_wdata = f_wdata;
      m_wmask = f_wmask;
      m_ce    = f_ce;
      m_we    = f_we;
      m_addr  = f_addr;
      m_waddr = (TYPE == 1) ? f_waddr : f_addr;
    end
  end

  // ------------------------------------------------------------- test-path output stage
  logic [DW-1:0] t_rdata;
  generate
    if (OUT_PIPE) begin : g_outp
      always_ff @(posedge clk) t_rdata <= m_rdata;
    end else begin : g_nooutp
      assign t_rdata = m_rdata;
    end
  endgenerate
  assign bist_rdata = TBUS_DW'(t_rdata);

  // ------------------------------------------------------------- scan bypass
  generate
    if (SCAN_BYPASS) begin : g_byp
      logic [DW-1:0] shadow, afold;
      always_comb begin
        afold = '0;
        for (int i = 0; i < AW; i++) afold[i % DW] = afold[i % DW] ^ f_addr[i];
      end
      always_ff @(posedge clk) begin
        if (f_ce || f_we) shadow <= f_wdata ^ afold ^ DW'(f_waddr);
      end
      assign f_rdata = scan_mode ? shadow : m_rdata;
    end else begin : g_nobyp
      assign f_rdata = m_rdata;
      logic unused_sm;
      assign unused_sm = scan_mode;
    end
  endgenerate

endmodule

`default_nettype wire
