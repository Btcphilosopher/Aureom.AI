// =============================================================================
// SilicaFlux TestCore :: tc_trace
// Optional circular trace buffer (DEPTH x 32 bits) for silicon debug.
// Captures trace_data_i on trace_valid_i while enabled; optionally freezes
// while the core is halted.  Read through TRACE_IDX/TRACE_DATA with index 0
// being the oldest valid entry.  Implemented with flops (small DEPTH); a
// large buffer would use an SRAM macro and should then be registered with
// the MBIST controller.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module tc_trace
  import tc_spec_pkg::*;
#(
  parameter int DEPTH = 16          // power of two
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        wr,
  input  wire logic [11:0] addr,
  input  wire logic [31:0] wdata,
  output logic [31:0]      rdata,
  input  wire logic        core_halted,
  input  wire logic        trace_valid_i,
  input  wire logic [31:0] trace_data_i
);
  localparam int PW = $clog2(DEPTH);
  logic [31:0] buf_q [DEPTH];
  logic [PW-1:0] wp;
  logic [PW:0]   count;
  logic          enable, stop_on_halt, wrapped;
  logic [15:0]   idx;

  wire cap = enable && trace_valid_i && !(stop_on_halt && core_halted);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wp <= '0; count <= '0; enable <= 1'b0; stop_on_halt <= 1'b0; wrapped <= 1'b0; idx <= '0;
    end else begin
      if (wr && addr == TC_R_TRACE_CTRL) begin
        enable       <= wdata[TC_F_TRACE_CTRL_ENABLE_LSB];
        stop_on_halt <= wdata[TC_F_TRACE_CTRL_STOP_ON_HALT_LSB];
      end
      if (wr && addr == TC_R_TRACE_IDX) idx <= wdata[15:0];
      if (wr && addr == TC_R_TRACE_CTRL && wdata[TC_F_TRACE_CTRL_CLEAR_LSB]) begin
        wp <= '0; count <= '0; wrapped <= 1'b0;
      end else if (cap) begin
        wp <= wp + 1'b1;
        if (32'(count) == DEPTH) wrapped <= 1'b1;
        else                       count <= count + 1'b1;
      end
    end
  end

  always_ff @(posedge clk) begin
    if (cap) buf_q[wp] <= trace_data_i;
  end

  wire          in_range = (32'(idx) < 32'(count));
  wire [PW-1:0] rp       = (32'(count) == DEPTH) ? (wp + idx[PW-1:0]) : idx[PW-1:0];

  always_comb begin
    rdata = '0;
    case (addr)
      TC_R_TRACE_CTRL:   rdata = {29'd0, stop_on_halt, 1'b0, enable};
      TC_R_TRACE_STATUS: rdata = {3'd0, 5'(PW), 7'd0, wrapped, 16'(count)};
      TC_R_TRACE_IDX:    rdata = 32'(idx);
      TC_R_TRACE_DATA:   rdata = in_range ? buf_q[rp] : 32'd0;
      default:           rdata = '0;
    endcase
  end

endmodule

`default_nettype wire
