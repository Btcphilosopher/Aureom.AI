// =============================================================================
// SilicaFlux TestCore :: tc_lbist
// Test-per-clock logic BIST for a registered demonstration target.
//
//   PRPG : 32-bit maximal LFSR (x^32+x^22+x^2+x+1, Galois) + XOR phase
//          shifter producing IN_W bits per clock:
//            in[i] = s[i%32] ^ s[(5i+3)%32] ^ s[(13i+7)%32]
//   Target: combinational or LAT-stage pipelined block whose inputs are
//          multiplexed to the PRPG while tgt_sel_o = 1 (LOGIC_TEST mode).
//   MISR : 32-bit, same polynomial; OUT_W response bits XOR-folded to 32.
//
// This is NOT STUMPS/scan-based LBIST: it exercises the target through its
// primary inputs only.  Justification and limitations (random-pattern
// resistant faults, spatial-compaction masking, X-sources, no coverage of
// surrounding sequential logic) are evaluated in docs/05_lbist_evaluation.md.
// The golden signature is computed off-chip (python/sftestcore/models.py) and
// written to LBIST_SIG_EXP.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module tc_lbist
  import tc_spec_pkg::*;
  import tc_pkg::*;
#(
  parameter int IN_W  = 68,
  parameter int OUT_W = 33,
  parameter int LAT   = 0
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             mode_en,      // LOGIC_TEST (system-domain sync)
  input  wire logic             wr,
  input  wire logic [11:0]      addr,
  input  wire logic [31:0]      wdata,
  output logic [31:0]           rdata,
  output logic                  tgt_sel_o,
  output logic [IN_W-1:0]       tgt_in_o,
  input  wire logic [OUT_W-1:0] tgt_out_i,
  output logic                  busy_o,
  output logic                  done_o,
  output logic                  pass_o
);
  logic [31:0] seed, npat, sig_exp, lfsr, misr, cnt;
  logic        busy, done, pass, aborted;

  // phase shifter
  always_comb begin
    for (int i = 0; i < IN_W; i++)
      tgt_in_o[i] = lfsr[i % 32] ^ lfsr[(5*i + 3) % 32] ^ lfsr[(13*i + 7) % 32];
  end
  assign tgt_sel_o = mode_en;

  logic [31:0] fold;
  always_comb begin
    fold = '0;
    for (int i = 0; i < OUT_W; i++) fold[i % 32] = fold[i % 32] ^ tgt_out_i[i];
  end

  wire wr_ctrl  = wr && (addr == TC_R_LBIST_CTRL);
  wire do_start = wr_ctrl && wdata[TC_F_LBIST_CTRL_START_LSB] && !busy && mode_en;
  wire do_abort = busy && ((wr_ctrl && wdata[TC_F_LBIST_CTRL_ABORT_LSB]) || !mode_en);
  wire applied  = busy && (cnt != 32'd0);   // a pattern is applied this cycle

  // response-valid pipeline matching the target latency
  logic resp_valid, pipe_empty;
  generate
    if (LAT == 0) begin : g_l0
      assign resp_valid = applied;
      assign pipe_empty = 1'b1;
    end else begin : g_lp
      logic [LAT-1:0] vreg;
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)                   vreg <= '0;
        else if (do_start || do_abort) vreg <= '0;
        else                          vreg <= (vreg << 1) | LAT'(applied);
      end
      assign resp_valid = vreg[LAT-1];
      assign pipe_empty = (vreg == '0);
    end
  endgenerate

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      seed <= 32'h1; npat <= 32'd1024; sig_exp <= '0;
      lfsr <= 32'h1; misr <= '0; cnt <= '0;
      busy <= 1'b0; done <= 1'b0; pass <= 1'b0; aborted <= 1'b0;
    end else begin
      if (wr && !busy) begin
        if (addr == TC_R_LBIST_SEED)     seed <= wdata;
        if (addr == TC_R_LBIST_PATTERNS) npat <= wdata;
      end
      if (wr && addr == TC_R_LBIST_SIG_EXP) sig_exp <= wdata;

      if (do_start) begin
        lfsr <= (seed == 32'd0) ? 32'h1 : seed;
        misr <= '0; cnt <= npat;
        busy <= 1'b1; done <= 1'b0; pass <= 1'b0; aborted <= 1'b0;
      end else if (do_abort) begin
        busy <= 1'b0; aborted <= 1'b1; done <= 1'b0;
      end else if (busy) begin
        if (applied) begin
          lfsr <= tc_lfsr_step(lfsr);
          cnt  <= cnt - 32'd1;
        end
        if (resp_valid) misr <= tc_misr_step(misr, fold);
        if (cnt == 32'd0 && pipe_empty) begin
          busy <= 1'b0; done <= 1'b1;
          pass <= (misr == sig_exp) && (npat != 32'd0);   // zero patterns never pass
        end
      end
    end
  end

  assign busy_o = busy;
  assign done_o = done;
  assign pass_o = pass;

  always_comb begin
    rdata = '0;
    case (addr)
      TC_R_LBIST_CTRL:     rdata = 32'd0;
      TC_R_LBIST_STATUS:   rdata = {28'd0, aborted, pass, done, busy};
      TC_R_LBIST_SEED:     rdata = seed;
      TC_R_LBIST_PATTERNS: rdata = npat;
      TC_R_LBIST_SIG:      rdata = misr;
      TC_R_LBIST_SIG_EXP:  rdata = sig_exp;
      default:             rdata = '0;
    endcase
  end

endmodule

`default_nettype wire
