// =============================================================================
// SilicaFlux TestCore :: tc_rst_ctrl
//
// Reset domains
//   tc_rst_n   TestCore system-clock-domain logic (registers, MBIST, LBIST).
//              Sources: power-on reset, tc_rst_hold (SCAN_TEST entry/exit).
//              Survives system resets so results/causes remain readable.
//   sys_rst_n  SoC system reset.  Sources: POR, RST_N pad, test-mode hold,
//              and stretched synchronous requests (watchdog, software, debug).
//   core_rst_n CPU reset: released CORE_DELAY clocks after sys_rst_n (staged
//              release so memories/peripherals are out of reset first).
// All resets: asynchronous assertion, synchronous de-assertion (tc_rst_sync).
// In scan mode every reset output and every synchroniser reset is taken from
// the scan reset pin (ATPG control).  The POR cell itself is analog/library
// IP and is outside this RTL.
//
// RESET_CAUSE (sticky, W1C): POR | EXT_PIN | WDT | SW | DEBUG | TEST_MODE.
// The register itself is in the tc_rst_n domain and resets to POR; a
// SCAN_TEST exit therefore also reads as POR (documented behaviour).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module tc_rst_ctrl #(
  parameter int SYNC_STAGES = 3,     // de-assertion stretch of sys_rst_n
  parameter int CORE_DELAY  = 4,     // extra clocks before core_rst_n release
  parameter int REQ_STRETCH = 16     // width of watchdog/software/debug resets
) (
  input  wire logic        clk,
  input  wire logic        por_n,
  input  wire logic        ext_rst_n,
  input  wire logic        sys_rst_hold,   // from mode controller (TCK flop)
  input  wire logic        tc_rst_hold,    // from mode controller (TCK flop)
  input  wire logic        wdt_req,        // synchronous pulses (clk domain)
  input  wire logic        sw_req,
  input  wire logic        dbg_req,
  input  wire logic        scan_mode,
  input  wire logic        scan_rst_n,
  output logic             tc_rst_n,
  output logic             sys_rst_n,
  output logic             core_rst_n,
  output logic             sys_in_reset,   // clk-domain synchronised status
  // cause / count registers
  input  wire logic        cause_w1c_en,
  input  wire logic [5:0]  cause_w1c,
  output logic [5:0]       cause_o,
  output logic [31:0]      count_o
);
  // ------------------------------------------------------------- TestCore domain
  logic tc_src_n;
  assign tc_src_n = por_n & ~tc_rst_hold;
  tc_rst_sync #(.STAGES(2)) u_tc_rst (
    .clk(clk), .rst_src_n(tc_src_n), .scan_mode(scan_mode), .scan_rst_n(scan_rst_n), .rst_n(tc_rst_n));

  // ------------------------------------------------------------- stretched sync requests
  localparam int SW = $clog2(REQ_STRETCH + 1);
  logic [SW-1:0] req_cnt;
  logic          req_active;
  always_ff @(posedge clk or negedge tc_rst_n) begin
    if (!tc_rst_n) begin
      req_cnt    <= '0;
      req_active <= 1'b0;
    end else begin
      if (wdt_req || sw_req || dbg_req) req_cnt <= SW'(REQ_STRETCH);
      else if (req_cnt != '0)           req_cnt <= req_cnt - 1'b1;
      req_active <= (wdt_req || sw_req || dbg_req) || (req_cnt > SW'(1));
    end
  end

  // ------------------------------------------------------------- system / core resets
  logic sys_src_n, sys_rst_int_n;
  assign sys_src_n = por_n & ext_rst_n & ~sys_rst_hold & ~req_active;
  tc_rst_sync #(.STAGES(SYNC_STAGES)) u_sys_rst (
    .clk(clk), .rst_src_n(sys_src_n), .scan_mode(scan_mode), .scan_rst_n(scan_rst_n), .rst_n(sys_rst_int_n));
  assign sys_rst_n = sys_rst_int_n;

  tc_rst_sync #(.STAGES(CORE_DELAY)) u_core_rst (
    .clk(clk), .rst_src_n(sys_rst_int_n), .scan_mode(scan_mode), .scan_rst_n(scan_rst_n), .rst_n(core_rst_n));

  // ------------------------------------------------------------- cause capture
  logic ext_s, hold_s, inrst_s, inrst_q;
  tc_sync #(.W(1)) u_ext_sync   (.clk(clk), .rst_n(tc_rst_n), .d(~ext_rst_n),    .q(ext_s));
  tc_sync #(.W(1)) u_hold_sync  (.clk(clk), .rst_n(tc_rst_n), .d(sys_rst_hold),  .q(hold_s));
  tc_sync #(.W(1)) u_inrst_sync (.clk(clk), .rst_n(tc_rst_n), .d(~sys_rst_int_n), .q(inrst_s));
  assign sys_in_reset = inrst_s;

  logic [5:0] cause;
  always_ff @(posedge clk or negedge tc_rst_n) begin
    if (!tc_rst_n) begin
      cause   <= 6'b000001;   // POR
      count_o <= 32'd0;
      inrst_q <= 1'b0;
    end else begin
      cause <= (cause & ~(cause_w1c_en ? cause_w1c : 6'd0)) |
               {hold_s, dbg_req, sw_req, wdt_req, ext_s, 1'b0};
      inrst_q <= inrst_s;
      if (inrst_s && !inrst_q && count_o != 32'hFFFF_FFFF) count_o <= count_o + 32'd1;
    end
  end
  assign cause_o = cause;

endmodule

`default_nettype wire
