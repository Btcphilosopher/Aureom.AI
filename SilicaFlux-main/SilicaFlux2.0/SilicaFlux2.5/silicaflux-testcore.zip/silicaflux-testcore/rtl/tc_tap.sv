// =============================================================================
// SilicaFlux TestCore :: tc_tap
// IEEE 1149.1-style Test Access Port: 16-state controller, instruction register,
// BYPASS and IDCODE data registers, data-register selection and TDO.
//
// Timing (per IEEE 1149.1 clause 6/7/8 as understood by the author; NOT
// compliance-tested):
//   * TAP state, IR/DR capture and shift on the rising edge of TCK.
//   * IR parallel output (current instruction) updates on the falling edge of
//     TCK in Update-IR; forced to IDCODE in Test-Logic-Reset and by TRST*.
//   * TDO changes on the falling edge; driven only in Shift-IR / Shift-DR
//     (tdo_oe), high-impedance otherwise.
//   * Capture-IR loads TC_IR_CAPTURE (LSBs = 01).
//   * Unassigned opcodes select BYPASS.
// External TDRs (BSR, TC_STATUS, TC_MODE, TC_UNLOCK, TC_REG) live in their own
// modules and return their serial output on tdo_*_i.
//
// trst_n must be the AND of the TRST* pin and power-on reset (TAP must reset at
// power-up).  The whole module is TCK-domain DFT infrastructure: exclude from
// scan insertion and verify with JTAG compliance patterns instead.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module tc_tap
  import tc_spec_pkg::*;
  import tc_pkg::*;
(
  input  wire logic        tck,
  input  wire logic        trst_n,
  input  wire logic        tms,
  input  wire logic        tdi,
  output logic             tdo,
  output logic             tdo_oe,
  input  wire logic [3:0]  idcode_version_i,   // metal-programmable revision
  // state / control to TDRs
  output logic [3:0]       state_o,
  output logic [TC_IR_LEN-1:0] ir_o,
  output logic             capture_dr_o,
  output logic             shift_dr_o,
  output logic             update_dr_o,
  output logic             tlr_o,
  // serial outputs of external TDRs
  input  wire logic        tdo_bsr_i,
  input  wire logic        tdo_status_i,
  input  wire logic        tdo_mode_i,
  input  wire logic        tdo_unlock_i,
  input  wire logic        tdo_reg_i
);
  // ------------------------------------------------------------- controller
  logic [3:0] state;
  always_ff @(posedge tck or negedge trst_n) begin
    if (!trst_n) state <= TAP_TLR;
    else         state <= tap_next(state, tms);
  end
  assign state_o      = state;
  assign capture_dr_o = (state == TAP_CAPT_DR);
  assign shift_dr_o   = (state == TAP_SHIFT_DR);
  assign update_dr_o  = (state == TAP_UPDATE_DR);
  assign tlr_o        = (state == TAP_TLR);

  // ------------------------------------------------------------- instruction register
  logic [TC_IR_LEN-1:0] ir_sh, ir;
  always_ff @(posedge tck) begin
    if (state == TAP_CAPT_IR)       ir_sh <= TC_IR_CAPTURE;
    else if (state == TAP_SHIFT_IR) ir_sh <= {tdi, ir_sh[TC_IR_LEN-1:1]};
  end

  always_ff @(negedge tck or negedge trst_n) begin
    if (!trst_n)                     ir <= TC_IR_IDCODE;
    else if (state == TAP_TLR)       ir <= TC_IR_IDCODE;
    else if (state == TAP_UPDATE_IR) ir <= ir_sh;
  end
  assign ir_o = ir;

  // ------------------------------------------------------------- DR selection
  typedef enum logic [2:0] {
    DR_BYPASS, DR_IDCODE, DR_BSR, DR_STATUS, DR_MODE, DR_UNLOCK, DR_REG
  } dr_sel_e;

  dr_sel_e dr_sel;
  always_comb begin
    case (ir)
      TC_IR_EXTEST, TC_IR_SAMPLE_PRELOAD: dr_sel = DR_BSR;
      TC_IR_IDCODE:                       dr_sel = DR_IDCODE;
      TC_IR_TC_STATUS:                    dr_sel = DR_STATUS;
      TC_IR_TC_MODE:                      dr_sel = DR_MODE;
      TC_IR_TC_UNLOCK:                    dr_sel = DR_UNLOCK;
      TC_IR_TC_REG:                       dr_sel = DR_REG;
      default:                            dr_sel = DR_BYPASS;  // BYPASS, CLAMP, HIGHZ, unassigned
    endcase
  end

  // ------------------------------------------------------------- BYPASS / IDCODE
  logic        bypass_q;
  logic [31:0] id_sh;
  always_ff @(posedge tck) begin
    if (state == TAP_CAPT_DR) begin
      bypass_q <= 1'b0;
      if (dr_sel == DR_IDCODE) id_sh <= {idcode_version_i, TC_IDCODE_PART, TC_IDCODE_MFG, 1'b1};
    end else if (state == TAP_SHIFT_DR) begin
      bypass_q <= tdi;
      if (dr_sel == DR_IDCODE) id_sh <= {tdi, id_sh[31:1]};
    end
  end

  // ------------------------------------------------------------- TDO
  logic tdo_mux;
  always_comb begin
    if (state == TAP_SHIFT_IR) tdo_mux = ir_sh[0];
    else begin
      case (dr_sel)
        DR_IDCODE: tdo_mux = id_sh[0];
        DR_BSR:    tdo_mux = tdo_bsr_i;
        DR_STATUS: tdo_mux = tdo_status_i;
        DR_MODE:   tdo_mux = tdo_mode_i;
        DR_UNLOCK: tdo_mux = tdo_unlock_i;
        DR_REG:    tdo_mux = tdo_reg_i;
        default:   tdo_mux = bypass_q;
      endcase
    end
  end

  always_ff @(negedge tck or negedge trst_n) begin
    if (!trst_n) begin
      tdo    <= 1'b0;
      tdo_oe <= 1'b0;
    end else begin
      tdo    <= tdo_mux;
      tdo_oe <= (state == TAP_SHIFT_IR) || (state == TAP_SHIFT_DR);
    end
  end

endmodule

`default_nettype wire
