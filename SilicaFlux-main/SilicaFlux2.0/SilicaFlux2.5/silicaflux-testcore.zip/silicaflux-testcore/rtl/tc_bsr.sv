// =============================================================================
// SilicaFlux TestCore :: tc_bsr
// Parameterised boundary-scan register.  Cell order (cell 0 nearest TDO) is the
// contract shared with python/sftestcore/bsdl.py and the generated BSDL:
//   inputs  i : cell i                                   BC_4 observe-only
//   outputs o : data NI+2o, control NI+2o+1              BC_1 + BC_1
//   bidirs  b : input NI+2NO+3b, data +1, control +2     BC_4 + BC_1 + BC_1
//
// Capture-DR (rising TCK): input cells capture the pad, output-data cells
// capture the core's output value, control cells capture the core's output
// enable (SAMPLE semantics).  Shift-DR shifts TDI -> cell LEN-1 ... cell 0 -> TDO.
// Update-DR (falling TCK): update stage loaded (PRELOAD / EXTEST data).
//
// ext_mode (EXTEST or CLAMP): pads driven from the update stage.
// highz (HIGHZ): every BSR-controlled driver disabled.
// Core inputs always see the pad (observe-only input cells).
// The pad-facing muxes would be placed in/near the I/O ring in physical design.
// Classification: SYNTHESIZABLE (TCK-domain DFT infrastructure, exclude from scan)
// =============================================================================
`default_nettype none

module tc_bsr #(
  parameter int NUM_IN    = 3,
  parameter int NUM_OUT   = 4,
  parameter int NUM_BIDIR = 8,
  localparam int LEN      = NUM_IN + 2*NUM_OUT + 3*NUM_BIDIR
) (
  input  wire logic                 tck,
  input  wire logic                 trst_n,
  input  wire logic                 tdi,
  output logic                      tdo,
  input  wire logic                 sel,          // EXTEST or SAMPLE/PRELOAD in IR
  input  wire logic                 capture_dr,
  input  wire logic                 shift_dr,
  input  wire logic                 update_dr,
  input  wire logic                 ext_mode,     // EXTEST | CLAMP
  input  wire logic                 highz,        // HIGHZ
  // input pins
  input  wire logic [NUM_IN-1:0]    in_pad_i,
  output logic      [NUM_IN-1:0]    in_core_o,
  // output pins
  input  wire logic [NUM_OUT-1:0]   out_core_i,
  input  wire logic [NUM_OUT-1:0]   out_core_oe_i,
  output logic      [NUM_OUT-1:0]   out_pad_o,
  output logic      [NUM_OUT-1:0]   out_pad_oe_o,
  // bidirectional pins
  input  wire logic [NUM_BIDIR-1:0] io_core_o_i,
  input  wire logic [NUM_BIDIR-1:0] io_core_oe_i,
  output logic      [NUM_BIDIR-1:0] io_core_i_o,
  output logic      [NUM_BIDIR-1:0] io_pad_o,
  output logic      [NUM_BIDIR-1:0] io_pad_oe_o,
  input  wire logic [NUM_BIDIR-1:0] io_pad_i
);
  localparam int OB = NUM_IN;                 // first output cell
  localparam int BB = NUM_IN + 2*NUM_OUT;     // first bidir cell

  logic [LEN-1:0] pi;   // parallel capture inputs
  logic [LEN-1:0] sh;   // shift stage
  logic [LEN-1:0] up;   // update stage (only output/control cells are used)

  always_comb begin
    pi = '0;
    for (int i = 0; i < NUM_IN; i++) pi[i] = in_pad_i[i];
    for (int o = 0; o < NUM_OUT; o++) begin
      pi[OB + 2*o]     = out_core_i[o];
      pi[OB + 2*o + 1] = out_core_oe_i[o];
    end
    for (int b = 0; b < NUM_BIDIR; b++) begin
      pi[BB + 3*b]     = io_pad_i[b];
      pi[BB + 3*b + 1] = io_core_o_i[b];
      pi[BB + 3*b + 2] = io_core_oe_i[b];
    end
  end

  always_ff @(posedge tck) begin
    if (sel && capture_dr)    sh <= pi;
    else if (sel && shift_dr) sh <= {tdi, sh[LEN-1:1]};
  end
  assign tdo = sh[0];

  // Update stage: reset to 0 => control cells select "driver disabled" so an
  // EXTEST issued before PRELOAD cannot cause bus contention.
  always_ff @(negedge tck or negedge trst_n) begin
    if (!trst_n)               up <= '0;
    else if (sel && update_dr) up <= sh;
  end

  always_comb begin
    in_core_o = in_pad_i;
    for (int o = 0; o < NUM_OUT; o++) begin
      out_pad_o[o]    = ext_mode ? up[OB + 2*o] : out_core_i[o];
      out_pad_oe_o[o] = highz ? 1'b0 : (ext_mode ? up[OB + 2*o + 1] : out_core_oe_i[o]);
    end
    for (int b = 0; b < NUM_BIDIR; b++) begin
      io_core_i_o[b] = io_pad_i[b];
      io_pad_o[b]    = ext_mode ? up[BB + 3*b + 1] : io_core_o_i[b];
      io_pad_oe_o[b] = highz ? 1'b0 : (ext_mode ? up[BB + 3*b + 2] : io_core_oe_i[b]);
    end
  end

  // Input-cell update bits are architecturally unused (BC_4 has no update stage).
  logic unused_up;
  always_comb begin
    unused_up = 1'b0;
    for (int i = 0; i < NUM_IN; i++) unused_up = unused_up ^ up[i];
    for (int b = 0; b < NUM_BIDIR; b++) unused_up = unused_up ^ up[BB + 3*b];
  end

endmodule

`default_nettype wire
