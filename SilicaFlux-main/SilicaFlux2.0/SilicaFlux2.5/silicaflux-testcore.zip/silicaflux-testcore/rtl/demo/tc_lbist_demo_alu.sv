// =============================================================================
// SilicaFlux TestCore :: tc_lbist_demo_alu
// Non-critical demonstration target for LOGIC_TEST (LBIST): a 32-bit
// RV32I-style integer ALU (combinational).  Chosen because datapath logic of
// this kind is largely random-pattern testable; the zero flag and the
// set-less-than comparison paths are included deliberately as examples of
// random-pattern-resistant structures (see docs/05_lbist_evaluation.md).
//   inputs  {op[3:0], b[31:0], a[31:0]}  (68 bits)
//   outputs {zero, y[31:0]}              (33 bits)
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module tc_lbist_demo_alu (
  input  wire logic [31:0] a,
  input  wire logic [31:0] b,
  input  wire logic [3:0]  op,
  output logic      [31:0] y,
  output logic             zero
);
  always_comb begin
    case (op)
      4'd0:  y = a + b;
      4'd1:  y = a - b;
      4'd2:  y = a & b;
      4'd3:  y = a | b;
      4'd4:  y = a ^ b;
      4'd5:  y = a << b[4:0];
      4'd6:  y = a >> b[4:0];
      4'd7:  y = $unsigned($signed(a) >>> b[4:0]);
      4'd8:  y = {31'd0, $signed(a) < $signed(b)};
      4'd9:  y = {31'd0, a < b};
      4'd10: y = a;
      4'd11: y = b;
      4'd12: y = ~(a | b);
      4'd13: y = ~(a ^ b);
      4'd14: y = a & ~b;
      default: y = a | ~b;
    endcase
    zero = (y == 32'd0);
  end
endmodule

`default_nettype wire
