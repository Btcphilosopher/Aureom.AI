// =============================================================================
// SilicaFlux TestCore :: tc_pkg
// Hand-written shared definitions: TAP state encoding, LFSR/MISR helpers.
// Spec-derived constants live in the generated tc_spec_pkg.
// Classification: SYNTHESIZABLE (package)
// =============================================================================
`ifndef TC_PKG_SV
`define TC_PKG_SV
/* verilator lint_off UNUSEDPARAM */
package tc_pkg;

  // IEEE 1149.1 TAP controller states (encoding as in the standard's example
  // implementation; the encoding itself is not mandated).
  localparam logic [3:0] TAP_EXIT2_DR  = 4'h0;
  localparam logic [3:0] TAP_EXIT1_DR  = 4'h1;
  localparam logic [3:0] TAP_SHIFT_DR  = 4'h2;
  localparam logic [3:0] TAP_PAUSE_DR  = 4'h3;
  localparam logic [3:0] TAP_SEL_IR    = 4'h4;
  localparam logic [3:0] TAP_UPDATE_DR = 4'h5;
  localparam logic [3:0] TAP_CAPT_DR   = 4'h6;
  localparam logic [3:0] TAP_SEL_DR    = 4'h7;
  localparam logic [3:0] TAP_EXIT2_IR  = 4'h8;
  localparam logic [3:0] TAP_EXIT1_IR  = 4'h9;
  localparam logic [3:0] TAP_SHIFT_IR  = 4'hA;
  localparam logic [3:0] TAP_PAUSE_IR  = 4'hB;
  localparam logic [3:0] TAP_RTI       = 4'hC;
  localparam logic [3:0] TAP_UPDATE_IR = 4'hD;
  localparam logic [3:0] TAP_CAPT_IR   = 4'hE;
  localparam logic [3:0] TAP_TLR       = 4'hF;

  function automatic logic [3:0] tap_next(input logic [3:0] s, input logic tms);
    case (s)
      TAP_TLR:       tap_next = tms ? TAP_TLR      : TAP_RTI;
      TAP_RTI:       tap_next = tms ? TAP_SEL_DR   : TAP_RTI;
      TAP_SEL_DR:    tap_next = tms ? TAP_SEL_IR   : TAP_CAPT_DR;
      TAP_CAPT_DR:   tap_next = tms ? TAP_EXIT1_DR : TAP_SHIFT_DR;
      TAP_SHIFT_DR:  tap_next = tms ? TAP_EXIT1_DR : TAP_SHIFT_DR;
      TAP_EXIT1_DR:  tap_next = tms ? TAP_UPDATE_DR: TAP_PAUSE_DR;
      TAP_PAUSE_DR:  tap_next = tms ? TAP_EXIT2_DR : TAP_PAUSE_DR;
      TAP_EXIT2_DR:  tap_next = tms ? TAP_UPDATE_DR: TAP_SHIFT_DR;
      TAP_UPDATE_DR: tap_next = tms ? TAP_SEL_DR   : TAP_RTI;
      TAP_SEL_IR:    tap_next = tms ? TAP_TLR      : TAP_CAPT_IR;
      TAP_CAPT_IR:   tap_next = tms ? TAP_EXIT1_IR : TAP_SHIFT_IR;
      TAP_SHIFT_IR:  tap_next = tms ? TAP_EXIT1_IR : TAP_SHIFT_IR;
      TAP_EXIT1_IR:  tap_next = tms ? TAP_UPDATE_IR: TAP_PAUSE_IR;
      TAP_PAUSE_IR:  tap_next = tms ? TAP_EXIT2_IR : TAP_PAUSE_IR;
      TAP_EXIT2_IR:  tap_next = tms ? TAP_UPDATE_IR: TAP_SHIFT_IR;
      TAP_UPDATE_IR: tap_next = tms ? TAP_SEL_DR   : TAP_RTI;
      default:       tap_next = TAP_TLR;
    endcase
  endfunction

  // Galois right-shift LFSR step, polynomial x^32+x^22+x^2+x+1 (maximal).
  function automatic logic [31:0] tc_lfsr_step(input logic [31:0] s);
    tc_lfsr_step = s[0] ? ((s >> 1) ^ tc_spec_pkg::TC_LFSR_POLY) : (s >> 1);
  endfunction

  // 32-bit MISR: LFSR step XOR parallel input.
  function automatic logic [31:0] tc_misr_step(input logic [31:0] s, input logic [31:0] d);
    tc_misr_step = tc_lfsr_step(s) ^ d;
  endfunction

endpackage
/* verilator lint_on UNUSEDPARAM */
`endif
