// =============================================================================
// SilicaFlux TestCore :: technology-mapping cells
//
// Every clock-path or DFT-control multiplexer in TestCore is instantiated through
// one of these wrappers, never inferred.  Reasons:
//   * In an ASIC flow each wrapper body is replaced by (or dont_touch-mapped to)
//     a specific standard-cell instance: integrated clock gate, clock mux,
//     DFT mux, synchroniser flop.  Define TC_USE_LIB_CELLS and provide
//     tc_cells_lib.sv with the foundry cell instances (cell names are
//     library-specific and are NOT supplied here).
//   * dft/scan/scan_readiness.py recognises these module names as the only
//     legal sources of derived clocks and DFT-muxed resets.
//
// The default bodies are behavioural-but-synthesizable equivalents suitable for
// RTL simulation and FPGA prototyping.  They are NOT glitch-characterised.
// Classification: SYNTHESIZABLE (generic); LIBRARY MAPPING REQUIRED for ASIC.
// =============================================================================
`ifndef TC_USE_LIB_CELLS

// Integrated clock gate: latch-based, enable sampled while clk is low.
// te (test enable) forces the clock on; connect te to scan-enable so that all
// gated clocks pulse during scan shift while capture still exercises en.
module tc_icg (
  input  logic clk,
  input  logic en,
  input  logic te,
  output logic gclk
);
  logic en_l;
  /* verilator lint_off LATCH */
  always_latch begin
    if (!clk) en_l = en | te;
  end
  /* verilator lint_on LATCH */
  assign gclk = clk & en_l;
endmodule

// Clock multiplexer.  Select must only change while both clocks are quiescent
// (TestCore sequences this: functional clock gated off, test clock held low).
module tc_clk_mux2 (
  input  logic clk0,
  input  logic clk1,
  input  logic sel,
  output logic clk_o
);
  assign clk_o = sel ? clk1 : clk0;
endmodule

// DFT multiplexer for reset / test-control paths (s is a static test signal).
module tc_dft_mux2 (
  input  logic a,
  input  logic b,
  input  logic s,
  output logic y
);
  assign y = s ? b : a;
endmodule

`endif

// Multi-stage synchroniser (async reset).  Each bit is synchronised
// independently: only use for single-bit levels or Gray/one-hot-safe groups.
module tc_sync #(
  parameter int W      = 1,
  parameter int STAGES = 2,
  parameter logic [W-1:0] RST_VAL = '0
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic [W-1:0] d,
  output logic [W-1:0] q
);
  (* tc_sync_stage *) logic [W-1:0] s [STAGES];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < STAGES; i++) s[i] <= RST_VAL;
    end else begin
      s[0] <= d;
      for (int i = 1; i < STAGES; i++) s[i] <= s[i-1];
    end
  end
  assign q = s[STAGES-1];
endmodule

// Reset synchroniser: asynchronous assertion, synchronous de-assertion after
// STAGES clocks.  In scan mode both the synchroniser's own async reset and its
// output are taken from the scan reset pin, so ATPG has direct control.
module tc_rst_sync #(
  parameter int STAGES = 2
) (
  input  logic clk,
  input  logic rst_src_n,     // raw asynchronous reset request (active low)
  input  logic scan_mode,
  input  logic scan_rst_n,
  output logic rst_n
);
  logic src_dft_n, sync_n;
  logic [STAGES-1:0] s;

  tc_dft_mux2 u_src_mux (.a(rst_src_n), .b(scan_rst_n), .s(scan_mode), .y(src_dft_n));

  always_ff @(posedge clk or negedge src_dft_n) begin
    if (!src_dft_n) s <= '0;
    else            s <= {s[STAGES-2:0], 1'b1};
  end
  assign sync_n = s[STAGES-1];

  tc_dft_mux2 u_out_mux (.a(sync_n), .b(scan_rst_n), .s(scan_mode), .y(rst_n));
endmodule
