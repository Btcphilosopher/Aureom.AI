// =============================================================================
// SilicaFlux TestCore :: tc_regbus
// Internal register bus: two masters (JTAG bridge, system APB), fixed priority
// to JTAG, single-cycle accesses, central access-control check using the
// generated tc_reg_rd_ok / tc_reg_wr_ok functions (spec/testcore_spec.json).
// Purely combinational (no clock).
// Denied or unmapped accesses: no write strobe, read data 0, err=1.
// Slaves decode the address themselves and return 0 when not addressed; their
// read data is ORed here.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module tc_regbus
  import tc_spec_pkg::*;
#(
  parameter int NSLV = 4
) (
  input  wire logic [2:0]       mode_sys,       // system-domain view of the mode
  // master 0: JTAG bridge
  input  wire logic             j_req,
  input  wire logic             j_we,
  input  wire logic [11:0]      j_addr,
  input  wire logic [31:0]      j_wdata,
  output logic                  j_gnt,
  output logic [31:0]           j_rdata,
  output logic                  j_err,
  // master 1: APB slave port (system bus, CPU)
  input  wire logic             psel,
  input  wire logic             penable,
  input  wire logic             pwrite,
  input  wire logic [11:0]      paddr,
  input  wire logic [31:0]      pwdata,
  output logic [31:0]           prdata,
  output logic                  pready,
  output logic                  pslverr,
  // to slaves
  output logic                  s_wr,           // permitted write strobe
  output logic                  s_is_jtag,
  output logic [11:0]           s_addr,
  output logic [31:0]           s_wdata,
  input  wire logic [NSLV*32-1:0] s_rdata,
  // security event (denied access) for counting
  output logic                  denied_o
);
  wire apb_acc = psel && penable;
  assign j_gnt  = j_req;
  assign pready = apb_acc && !j_req;          // APB waits while JTAG owns the bus

  wire        act    = j_req || apb_acc;
  wire        is_j   = j_req;
  wire        we     = is_j ? j_we    : pwrite;
  wire [11:0] addr   = is_j ? j_addr  : paddr;
  wire [31:0] wdata  = is_j ? j_wdata : pwdata;

  wire ok_rd = tc_reg_rd_ok(addr, is_j, mode_sys);
  wire ok_wr = tc_reg_wr_ok(addr, is_j, mode_sys);
  wire ok    = we ? ok_wr : ok_rd;

  logic [31:0] rd_or;
  always_comb begin
    rd_or = '0;
    for (int i = 0; i < NSLV; i++) rd_or = rd_or | s_rdata[i*32 +: 32];
  end

  assign s_wr      = act && we && ok;
  assign s_is_jtag = is_j;
  assign s_addr    = addr;
  assign s_wdata   = wdata;

  wire [31:0] rdata = (act && !we && ok) ? rd_or : 32'd0;
  assign j_rdata = rdata;
  assign j_err   = j_req && !ok;
  assign prdata  = rdata;
  assign pslverr = pready && !ok;
  assign denied_o = act && !ok && (is_j || pready);

endmodule

`default_nettype wire
