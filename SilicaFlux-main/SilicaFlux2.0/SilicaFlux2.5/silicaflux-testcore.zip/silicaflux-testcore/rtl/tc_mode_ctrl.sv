// =============================================================================
// SilicaFlux TestCore :: tc_mode_ctrl   (TCK domain)
//
// Owns the private TDRs TC_STATUS, TC_MODE and TC_UNLOCK and the single
// authoritative test-mode state.  Safety properties enforced by construction:
//
//   M1  Exactly one mode is current (one state register; decoded outputs are
//       registered one-hot).
//   M2  Test modes are only entered from NORMAL; test-mode -> test-mode
//       requests are rejected (ILLEGAL).  Every exit returns to NORMAL.
//   M3  Entry requires tc_mode_permitted(lifecycle, unlocked, mode) and the
//       permission is re-checked every TCK; withdrawal forces an exit (ABORTED).
//   M4  JTAG mode is entered only by an invasive boundary-scan instruction
//       (EXTEST/CLAMP/HIGHZ) in the IR, which aborts any other active mode.
//   M5  Test-Logic-Reset (TMS high x5, or TRST*) returns to NORMAL.
//   M6  System reset is held (sys_rst_hold) throughout JTAG, MEMORY_BIST,
//       LOGIC_TEST and SCAN_TEST and during their entry/exit sequences, so the
//       system always leaves those modes through a synchronised reset.
//   M7  SCAN_TEST entry/exit sequences the clock switch: functional clock
//       gated off, then the root mux switched, (exit: switched back, then
//       un-gated).  TestCore's own system-domain logic is also reset.
//
// Unlock: 64-bit token compared with the OTP value.  Attempts and lockout are
// reset only by power-on reset (not by TRST*/TLR).  An all-zero token relocks.
// An all-zero OTP key, an invalid lifecycle or otp_valid=0 makes unlock
// impossible.  The comparison is a password check, NOT challenge-response:
// see docs/08_silicon_debug_and_security.md for the production gap.
// Classification: SYNTHESIZABLE (TCK-domain DFT infrastructure, exclude from scan)
// =============================================================================
`default_nettype none

module tc_mode_ctrl
  import tc_spec_pkg::*;
  import tc_pkg::*;
(
  input  wire logic        tck,
  input  wire logic        tap_rst_n,      // TRST* & POR
  input  wire logic        por_n,          // POR only (security state)
  input  wire logic [3:0]  tap_state,
  input  wire logic [TC_IR_LEN-1:0] ir,
  input  wire logic        tdi,
  output logic             tdo_status,
  output logic             tdo_mode,
  output logic             tdo_unlock,
  // OTP / lifecycle
  input  wire logic        otp_valid_i,
  input  wire logic [7:0]  lc_otp_i,
  input  wire logic [63:0] unlock_key_i,
  // status from system clock domain (raw; synchronised here)
  input  wire logic [7:0]  sys_status_i,   // {sys_in_rst, core_halted, lbist_pass, lbist_done, lbist_busy, mbist_fail, mbist_done, mbist_busy}
  input  wire logic        reg_busy_i,     // TCK-domain bridge busy
  // mode outputs (all registered, TCK domain, quasi-static)
  output logic [2:0]       mode_o,
  output logic             mode_busy_o,
  output logic [3:0]       opts_o,
  output logic             scan_mode_o,
  output logic             mbist_mode_o,
  output logic             lbist_mode_o,
  output logic             diag_mode_o,
  output logic             bscan_mode_o,
  output logic             clk_test_sel_o,
  output logic             func_clk_stop_o,
  output logic             sys_rst_hold_o,
  output logic             tc_rst_hold_o,
  // security status
  output logic [2:0]       lc_o,
  output logic             unlocked_o,
  output logic             lockout_o,
  output logic [2:0]       attempts_o
);
  localparam logic [1:0] PH_STABLE = 2'd0, PH_ENTER = 2'd1, PH_EXIT = 2'd2;
  localparam int CW = $clog2(TC_MODE_SETTLE_TCK);
  localparam logic [CW-1:0] CNT_LAST = CW'(TC_MODE_SETTLE_TCK - 1);
  localparam logic [CW-1:0] CNT_SEL  = CW'(TC_MODE_SETTLE_TCK / 2);       // entry: switch to test clock
  localparam logic [CW-1:0] CNT_XSEL = CW'(TC_MODE_SETTLE_TCK / 4);       // exit: switch back
  localparam logic [CW-1:0] CNT_XRUN = CW'((3 * TC_MODE_SETTLE_TCK) / 4); // exit: ungate functional clock

  // ------------------------------------------------------------- lifecycle
  logic [2:0] lc;
  assign lc   = otp_valid_i ? tc_lc_decode(lc_otp_i) : TC_LC_INVALID;
  assign lc_o = lc;

  // ------------------------------------------------------------- strobes
  wire tlr      = (tap_state == TAP_TLR);
  wire cap_dr   = (tap_state == TAP_CAPT_DR);
  wire sh_dr    = (tap_state == TAP_SHIFT_DR);
  wire upd_dr   = (tap_state == TAP_UPDATE_DR);
  wire sel_stat = (ir == TC_IR_TC_STATUS);
  wire sel_mode = (ir == TC_IR_TC_MODE);
  wire sel_unl  = (ir == TC_IR_TC_UNLOCK);
  wire bscan_inv = (ir == TC_IR_EXTEST) || (ir == TC_IR_CLAMP) || (ir == TC_IR_HIGHZ);

  // ------------------------------------------------------------- synchronised system status
  logic [7:0] ss;
  tc_sync #(.W(8)) u_sync_status (.clk(tck), .rst_n(tap_rst_n), .d(sys_status_i), .q(ss));

  // ------------------------------------------------------------- security state (POR only)
  logic       unlocked, lockout;
  logic [2:0] attempts;
  logic [63:0] sh_unl;

  // ------------------------------------------------------------- mode state
  logic [2:0]    cur_mode, target;
  logic [1:0]    phase;
  logic [CW-1:0] cnt;
  logic [3:0]    opts;
  logic [2:0]    last_err;
  logic          clk_test_sel, clk_stop;
  logic [11:0]   sh_mode;
  logic [31:0]   sh_stat;

  function automatic logic is_test_mode(input logic [2:0] m);
    is_test_mode = (m == TC_MODE_MEMORY_BIST) || (m == TC_MODE_LOGIC_TEST) ||
                   (m == TC_MODE_SCAN_TEST)   || (m == TC_MODE_DIAGNOSTIC);
  endfunction

  function automatic logic holds_sys(input logic [2:0] m);
    holds_sys = (m == TC_MODE_JTAG) || (m == TC_MODE_MEMORY_BIST) ||
                (m == TC_MODE_LOGIC_TEST) || (m == TC_MODE_SCAN_TEST);
  endfunction

  wire cur_perm = tc_mode_permitted(lc, unlocked, cur_mode);
  wire tgt_perm = tc_mode_permitted(lc, unlocked, target);

  // request decode
  wire [2:0] rq_mode  = sh_mode[2:0];
  wire [3:0] rq_opts  = sh_mode[7:4];
  wire [3:0] rq_magic = sh_mode[11:8];
  wire       mode_req = upd_dr && sel_mode;

  always_ff @(posedge tck or negedge tap_rst_n) begin
    if (!tap_rst_n) begin
      cur_mode     <= TC_MODE_NORMAL;
      target       <= TC_MODE_NORMAL;
      phase        <= PH_STABLE;
      cnt          <= '0;
      opts         <= '0;
      last_err     <= TC_MERR_NONE;
      clk_test_sel <= 1'b0;
      clk_stop     <= 1'b0;
    end else begin
      case (phase)
        // ------------------------------------------------- entry sequence
        PH_ENTER: begin
          if (tlr || bscan_inv || !tgt_perm) begin
            if (!tlr) last_err <= TC_MERR_ABORTED;
            if (target == TC_MODE_SCAN_TEST) begin      // unwind clock sequence
              cur_mode <= TC_MODE_SCAN_TEST;
              phase    <= PH_EXIT;
              cnt      <= '0;
            end else begin
              cur_mode <= TC_MODE_NORMAL;
              phase    <= PH_STABLE;
              opts     <= '0;
            end
          end else begin
            if (mode_req && rq_magic != 4'h0) last_err <= TC_MERR_BUSY;
            cnt <= cnt + 1'b1;
            if (target == TC_MODE_SCAN_TEST) begin
              clk_stop <= 1'b1;
              if (cnt == CNT_SEL) clk_test_sel <= 1'b1;
            end
            if (cnt == CNT_LAST) begin
              cur_mode <= target;
              phase    <= PH_STABLE;
              cnt      <= '0;
            end
          end
        end
        // ------------------------------------------------- exit sequence (SCAN_TEST only)
        PH_EXIT: begin
          if (mode_req && rq_magic != 4'h0) last_err <= TC_MERR_BUSY;
          cnt <= cnt + 1'b1;
          if (cnt == CNT_XSEL) clk_test_sel <= 1'b0;
          if (cnt == CNT_XRUN) clk_stop     <= 1'b0;
          if (cnt == CNT_LAST) begin
            clk_test_sel <= 1'b0;
            clk_stop     <= 1'b0;
            cur_mode     <= TC_MODE_NORMAL;
            phase        <= PH_STABLE;
            cnt          <= '0;
            opts         <= '0;
          end
        end
        // ------------------------------------------------- stable
        default: begin
          if (cur_mode == TC_MODE_JTAG) begin
            if (!bscan_inv)    cur_mode <= TC_MODE_NORMAL;
            else if (mode_req && rq_magic != 4'h0) last_err <= TC_MERR_ILLEGAL;
          end else if (cur_mode != TC_MODE_NORMAL && (tlr || bscan_inv || !cur_perm)) begin
            if (!tlr) last_err <= TC_MERR_ABORTED;
            if (cur_mode == TC_MODE_SCAN_TEST) begin
              phase <= PH_EXIT;
              cnt   <= '0;
            end else begin
              cur_mode <= TC_MODE_NORMAL;
              opts     <= '0;
            end
          end else if (bscan_inv) begin
            cur_mode <= TC_MODE_JTAG;                   // from NORMAL
          end else if (mode_req && rq_magic != 4'h0) begin   // MAGIC 0: capture-only scan
            if (rq_magic != TC_MODE_MAGIC) begin
              last_err <= TC_MERR_BAD_MAGIC;
            end else if (rq_mode == cur_mode) begin
              last_err <= TC_MERR_NONE;                 // no-op
            end else if (rq_mode == TC_MODE_NORMAL) begin
              last_err <= TC_MERR_NONE;
              if (cur_mode == TC_MODE_SCAN_TEST) begin
                phase <= PH_EXIT;
                cnt   <= '0;
              end else begin
                cur_mode <= TC_MODE_NORMAL;
                opts     <= '0;
              end
            end else if (!is_test_mode(rq_mode) || cur_mode != TC_MODE_NORMAL) begin
              last_err <= TC_MERR_ILLEGAL;
            end else if (!tc_mode_permitted(lc, unlocked, rq_mode)) begin
              last_err <= TC_MERR_DENIED;
            end else begin
              last_err <= TC_MERR_NONE;
              target   <= rq_mode;
              opts     <= rq_opts;
              phase    <= PH_ENTER;
              cnt      <= '0;
            end
          end
        end
      endcase
    end
  end

  // ------------------------------------------------------------- registered decoded outputs
  always_ff @(posedge tck or negedge tap_rst_n) begin
    if (!tap_rst_n) begin
      mode_o          <= TC_MODE_NORMAL;
      mode_busy_o     <= 1'b0;
      opts_o          <= '0;
      scan_mode_o     <= 1'b0;
      mbist_mode_o    <= 1'b0;
      lbist_mode_o    <= 1'b0;
      diag_mode_o     <= 1'b0;
      bscan_mode_o    <= 1'b0;
      sys_rst_hold_o  <= 1'b0;
      tc_rst_hold_o   <= 1'b0;
    end else begin
      mode_o          <= cur_mode;
      mode_busy_o     <= (phase != PH_STABLE);
      opts_o          <= (phase == PH_STABLE) ? opts : 4'h0;
      scan_mode_o     <= (phase == PH_STABLE) && (cur_mode == TC_MODE_SCAN_TEST);
      mbist_mode_o    <= (phase == PH_STABLE) && (cur_mode == TC_MODE_MEMORY_BIST);
      lbist_mode_o    <= (phase == PH_STABLE) && (cur_mode == TC_MODE_LOGIC_TEST);
      diag_mode_o     <= (phase == PH_STABLE) && (cur_mode == TC_MODE_DIAGNOSTIC);
      bscan_mode_o    <= (cur_mode == TC_MODE_JTAG);
      sys_rst_hold_o  <= holds_sys(cur_mode) || (phase == PH_EXIT) ||
                         ((phase == PH_ENTER) && holds_sys(target));
      tc_rst_hold_o   <= (cur_mode == TC_MODE_SCAN_TEST) ||
                         ((phase == PH_ENTER) && (target == TC_MODE_SCAN_TEST));
    end
  end
  assign clk_test_sel_o  = clk_test_sel;
  assign func_clk_stop_o = clk_stop;

  // ------------------------------------------------------------- unlock (POR-only state)
  always_ff @(posedge tck) begin
    if (sel_unl && cap_dr)     sh_unl <= {54'd0, lockout, unlocked, 5'd0, attempts};
    else if (sel_unl && sh_dr) sh_unl <= {tdi, sh_unl[63:1]};
  end

  wire key_ok = otp_valid_i && (lc != TC_LC_INVALID) && (unlock_key_i != 64'd0) &&
                (sh_unl == unlock_key_i);

  always_ff @(posedge tck or negedge por_n) begin
    if (!por_n) begin
      unlocked <= 1'b0;
      lockout  <= 1'b0;
      attempts <= 3'd0;
    end else if (upd_dr && sel_unl && !lockout) begin
      if (sh_unl == 64'd0) begin
        unlocked <= 1'b0;                       // explicit relock
      end else if (key_ok) begin
        unlocked <= 1'b1;
        attempts <= 3'd0;
      end else begin
        unlocked <= 1'b0;
        attempts <= attempts + 3'd1;
        if (attempts + 3'd1 >= 3'(TC_UNLOCK_MAX_ATTEMPTS)) lockout <= 1'b1;
      end
    end
  end
  assign unlocked_o = unlocked;
  assign lockout_o  = lockout;
  assign attempts_o = attempts;

  // ------------------------------------------------------------- TC_MODE / TC_STATUS TDRs
  always_ff @(posedge tck) begin
    if (sel_mode && cap_dr)     sh_mode <= {1'b0, last_err, opts, (phase != PH_STABLE), cur_mode};
    else if (sel_mode && sh_dr) sh_mode <= {tdi, sh_mode[11:1]};
  end

  always_ff @(posedge tck) begin
    if (sel_stat && cap_dr)
      sh_stat <= {TC_STATUS_MARKER, reg_busy_i, ss[6], ss[5], ss[4], ss[3], ss[2], ss[1], ss[0],
                  ss[7], attempts, lc, lockout, unlocked, last_err, (phase != PH_STABLE), cur_mode};
    else if (sel_stat && sh_dr)
      sh_stat <= {tdi, sh_stat[31:1]};
  end

  assign tdo_status = sh_stat[0];
  assign tdo_mode   = sh_mode[0];
  assign tdo_unlock = sh_unl[0];

endmodule

`default_nettype wire
