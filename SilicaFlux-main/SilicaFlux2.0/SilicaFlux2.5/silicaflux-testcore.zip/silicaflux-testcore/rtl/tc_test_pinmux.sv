// =============================================================================
// SilicaFlux TestCore :: tc_test_pinmux
// Test pin multiplexing on general-purpose bidirectional pins, placed between
// the boundary-scan register (pad side) and the functional core GPIO.
//
//   SCAN_TEST   pin0 scan_en (in)  pin1 scan_rst_n (in)
//               pin 2..2+CH-1 scan_in[k] (in)   pin 2+CH..2+2CH-1 scan_out[k] (out)
//               remaining pins: output drivers disabled
//   MEMORY_BIST pin0 mbist_done (out)  pin1 mbist_fail (out)   -- fast ATE status
//   LOGIC_TEST  pin0 lbist_done (out)  pin1 lbist_pass (out)
//   otherwise   transparent
// scan_en / scan_rst_n are forced inactive outside SCAN_TEST (test-mode
// isolation: functional pin activity can never assert scan enable).
// Mode inputs are static TCK-domain levels.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module tc_test_pinmux #(
  parameter int NUM_IO = 8,
  parameter int NUM_CH = 2
) (
  input  wire logic              scan_mode,
  input  wire logic              mbist_mode,
  input  wire logic              lbist_mode,
  input  wire logic              st0,           // mbist_done / lbist_done
  input  wire logic              st1,           // mbist_fail / lbist_pass
  input  wire logic              lst0,
  input  wire logic              lst1,
  // core side
  input  wire logic [NUM_IO-1:0] core_o,
  input  wire logic [NUM_IO-1:0] core_oe,
  output logic      [NUM_IO-1:0] core_i,
  // pad side (towards BSR)
  output logic      [NUM_IO-1:0] pad_o,
  output logic      [NUM_IO-1:0] pad_oe,
  input  wire logic [NUM_IO-1:0] pad_i,
  // scan
  output logic                   scan_en_o,
  output logic                   scan_rst_n_o,
  output logic      [NUM_CH-1:0] scan_in_o,
  input  wire logic [NUM_CH-1:0] scan_out_i
);
`ifndef SYNTHESIS
  initial if (NUM_IO < 2 + 2*NUM_CH) $error("tc_test_pinmux: not enough pins for %0d scan channels", NUM_CH);
`endif

  always_comb begin
    pad_o        = core_o;
    pad_oe       = core_oe;
    core_i       = pad_i;
    scan_en_o    = 1'b0;
    scan_rst_n_o = 1'b1;
    scan_in_o    = '0;
    if (scan_mode) begin
      pad_oe       = '0;
      pad_o        = '0;
      scan_en_o    = pad_i[0];
      scan_rst_n_o = pad_i[1];
      for (int k = 0; k < NUM_CH; k++) begin
        scan_in_o[k]           = pad_i[2 + k];
        pad_o[2 + NUM_CH + k]  = scan_out_i[k];
        pad_oe[2 + NUM_CH + k] = 1'b1;
      end
    end else if (mbist_mode) begin
      pad_o[0] = st0;  pad_oe[0] = 1'b1;
      pad_o[1] = st1;  pad_oe[1] = 1'b1;
    end else if (lbist_mode) begin
      pad_o[0] = lst0; pad_oe[0] = 1'b1;
      pad_o[1] = lst1; pad_oe[1] = 1'b1;
    end
  end

endmodule

`default_nettype wire
