// =============================================================================
// SilicaFlux TestCore :: tc_mbist
// Configurable, microcoded March MBIST controller with register interface.
//
// Memory registry (discovery): compile-time parameters per memory, readable
// through MBIST_NUM_MEMS / MBIST_MEM_IDX / MBIST_MEM_INFO0/1:
//   MEM_DW      data width incl. ECC/parity bits (1..MAX_DW)    8 bits/mem
//   MEM_MAXADDR depth-1 (arbitrary depth, need not be 2^n)       20 bits/mem
//   MEM_LAT     cycles from issue (ce) to rdata valid, INCLUDING collar and
//               bus pipeline stages (1..MAX_LAT)                3 bits/mem
//   MEM_TYPE    0 SRAM_1RW, 1 SRAM_1R1W, 2 ROM                   2 bits/mem
//   MEM_WR2RD   idle cycles required between a write and a read
//               of the same address (access restriction)       2 bits/mem
//
// Execution: selected memories are tested one after another (serial: bounds
// peak test power; parallel testing of identical banks is a possible
// extension).  Per memory, the algorithm's March elements are executed; each
// element walks the address range up or down applying 1..6 ops per address.
// Ops are issued back-to-back (one per cycle, in order) to the 1RW/1R1W
// test port; reads are compared MEM_LAT cycles later against the expected
// value carried down an expected-data pipeline.  A same-address read that
// follows a write too closely is delayed by MEM_WR2RD idle cycles.  The
// engine never issues a read and a write in the same cycle, so 1R1W
// read-during-write behaviour (compiler-specific, often undefined) is never
// relied upon.  Between memories the pipeline is drained.
//
// ROM: a single ascending read pass compacted into a 32-bit MISR (XOR-folded);
// compared with MBIST_SIG_EXP when SIG_CHECK=1.
//
// Results: pass/fail, per-memory fail mask, saturating fail count, failure log
// (first LOG_DEPTH failures: memory, element, op, address, syndrome =
// expected XOR actual over the memory width), overflow flag, OR-accumulated
// syndrome (failing-bit map), stop-on-first-fail option.
// An empty memory selection or an algorithm with no elements reports FAIL
// (never a false PASS).
// Redundancy / repair: NOT implemented.  CAPS.REPAIR reads 0; failures are
// reported, never "repaired".
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

/* verilator lint_off WIDTHTRUNC */
/* verilator lint_off WIDTHEXPAND */
/* verilator lint_off UNUSEDSIGNAL */
module tc_mbist
  import tc_spec_pkg::*;
  import tc_pkg::*;
#(
  parameter int NUM_MEMS  = 2,
  parameter int MAX_DW    = 72,
  parameter int MAX_AW    = 16,
  parameter int MAX_LAT   = 4,
  parameter int LOG_DEPTH = 8,
  parameter logic [NUM_MEMS*8-1:0]  MEM_DW      = {8'd32, 8'd32},
  parameter logic [NUM_MEMS*20-1:0] MEM_MAXADDR = {20'd255, 20'd255},
  parameter logic [NUM_MEMS*3-1:0]  MEM_LAT     = {3'd1, 3'd1},
  parameter logic [NUM_MEMS*2-1:0]  MEM_TYPE    = {2'd0, 2'd0},
  parameter logic [NUM_MEMS*2-1:0]  MEM_WR2RD   = {2'd0, 2'd0}
) (
  input  wire logic                       clk,
  input  wire logic                       rst_n,
  input  wire logic                       mode_en,     // MEMORY_BIST (system-domain sync)
  // register slave (permission-checked by tc_regbus)
  input  wire logic                       wr,
  input  wire logic [11:0]                addr,
  input  wire logic [31:0]                wdata,
  output logic [31:0]                     rdata,
  // memory test bus (to collars)
  output logic                            active_o,
  output logic [NUM_MEMS-1:0]             sel_o,
  output logic                            ce_o,
  output logic                            we_o,
  output logic [MAX_AW-1:0]               addr_o,
  output logic [MAX_DW-1:0]               wdata_o,
  input  wire logic [NUM_MEMS*MAX_DW-1:0] rdata_i,
  // summary
  output logic                            busy_o,
  output logic                            done_o,
  output logic                            fail_o
);
  localparam int LW = (LOG_DEPTH > 1) ? $clog2(LOG_DEPTH + 1) : 1;
  localparam logic [17:0] ROM_ELEM = 18'h10002;   // U(r0)

  // ------------------------------------------------------------- configuration registers
  logic [3:0]          cfg_algo;
  logic [2:0]          cfg_bg;
  logic                cfg_sof, cfg_sigchk;
  logic [NUM_MEMS-1:0] cfg_sel;
  logic [31:0]         cfg_bg_user, cfg_pause, cfg_sig_exp;
  logic [3:0]          cfg_log_idx;
  logic [4:0]          cfg_mem_idx;
  logic [17:0]         ualg [8];

  // ------------------------------------------------------------- engine state
  localparam logic [2:0] S_IDLE = 3'd0, S_CHECK = 3'd1, S_LOAD = 3'd2, S_RUN = 3'd3,
                         S_PAUSE = 3'd4, S_DRAIN = 3'd5, S_FIN = 3'd6;
  logic [2:0]  st;
  logic [4:0]  cur_mem;
  logic [3:0]  elem_idx;
  logic [17:0] elem_word;
  logic [2:0]  op_idx;
  logic [MAX_AW-1:0] addr_q;
  logic [31:0] pause_cnt;
  logic [3:0]  drain_cnt;
  logic        lw_valid;
  logic [MAX_AW-1:0] lw_addr;
  logic [1:0]  gap_cnt;
  logic        tested_any;

  logic        done, fail, stopped, aborted, log_ovf, sig_fail;
  logic [NUM_MEMS-1:0] fail_mems;
  logic [31:0] fail_count, misr;
  logic [MAX_DW-1:0] acc_synd;
  logic [LW-1:0] log_count;
  logic [3:0]        log_mem  [LOG_DEPTH];
  logic [2:0]        log_elem [LOG_DEPTH];
  logic [2:0]        log_op   [LOG_DEPTH];
  logic [19:0]       log_addr [LOG_DEPTH];
  logic [MAX_DW-1:0] log_synd [LOG_DEPTH];

  // expected-data pipeline
  logic              pv   [MAX_LAT];
  logic [MAX_DW-1:0] pexp [MAX_LAT];
  logic [MAX_AW-1:0] paddr[MAX_LAT];
  logic [2:0]        pel  [MAX_LAT];
  logic [2:0]        pop  [MAX_LAT];

  // ------------------------------------------------------------- current-memory attributes
  wire [3:0]  cm = cur_mem[3:0];
  wire [7:0]  m_dw   = MEM_DW[cm*8 +: 8];
  wire [19:0] m_max  = MEM_MAXADDR[cm*20 +: 20];
  wire [2:0]  m_lat  = MEM_LAT[cm*3 +: 3];
  wire [1:0]  m_type = MEM_TYPE[cm*2 +: 2];
  wire [1:0]  m_gap  = MEM_WR2RD[cm*2 +: 2];
  wire        is_rom = (m_type == TC_MEM_ROM);
  wire [MAX_AW-1:0] maxaddr = m_max[MAX_AW-1:0];

  logic [MAX_DW-1:0] wmask;
  always_comb begin
    for (int i = 0; i < MAX_DW; i++) wmask[i] = (i < 32'(m_dw));
  end

  function automatic logic [MAX_DW-1:0] bgpat(input logic [2:0] bg, input logic a0,
                                              input logic [31:0] u);
    for (int i = 0; i < MAX_DW; i++) begin
      case (bg)
        TC_BG_CHECKER:    bgpat[i] = (i % 2 == 1) ^ a0;
        TC_BG_ROW_STRIPE: bgpat[i] = a0;
        TC_BG_COL_STRIPE: bgpat[i] = (i % 2 == 1);
        TC_BG_USER:       bgpat[i] = u[i % 32];
        default:          bgpat[i] = 1'b0;
      endcase
    end
  endfunction

  function automatic logic [31:0] fold32(input logic [MAX_DW-1:0] d);
    fold32 = '0;
    for (int i = 0; i < MAX_DW; i++) fold32[i % 32] = fold32[i % 32] ^ d[i];
  endfunction

  // ------------------------------------------------------------- element decode / issue
  wire        e_down  = elem_word[15];
  wire [2:0]  e_nops1 = elem_word[14:12];
  wire [11:0] e_ops   = elem_word[11:0];
  wire [1:0]  cur_op  = e_ops[{op_idx, 1'b0} +: 2];
  wire        op_rd   = cur_op[1];
  wire        op_val  = cur_op[0];
  wire [MAX_AW-1:0] last_addr = e_down ? '0 : maxaddr;

  wire need_gap = op_rd && lw_valid && (lw_addr == addr_q) && (gap_cnt < m_gap);
  wire issue    = (st == S_RUN) && !need_gap;

  wire [MAX_DW-1:0] bgv     = bgpat(cfg_bg, addr_q[0], cfg_bg_user);
  wire [MAX_DW-1:0] op_data = (op_val ? ~bgv : bgv) & wmask;

  logic [17:0] load_word;
  always_comb begin
    if (elem_idx[3])        load_word = 18'd0;
    else if (is_rom)        load_word = (elem_idx == 4'd0) ? ROM_ELEM : 18'd0;
    else if (cfg_algo == TC_ALG_USER) load_word = ualg[elem_idx[2:0]];
    else                    load_word = tc_alg_elem(cfg_algo, elem_idx[2:0]);
  end

  assign active_o = mode_en;
  assign ce_o     = issue;
  assign we_o     = issue && !op_rd;
  assign addr_o   = addr_q;
  assign wdata_o  = op_data;
  always_comb begin
    sel_o = '0;
    if (st == S_LOAD || st == S_RUN || st == S_PAUSE || st == S_DRAIN) sel_o[cm] = 1'b1;
  end

  // ------------------------------------------------------------- compare
  wire [2:0]  tap = (m_lat == 3'd0) ? 3'd0 :
                    (32'(m_lat) > MAX_LAT) ? 3'(MAX_LAT - 1) : (m_lat - 3'd1);
  wire [MAX_DW-1:0] rd_cur = rdata_i[cm*MAX_DW +: MAX_DW];
  wire              cmp_v  = pv[tap] && (st != S_IDLE);
  wire [MAX_DW-1:0] synd   = (rd_cur ^ pexp[tap]) & wmask;
  wire              mism   = cmp_v && !is_rom && (synd != '0);

  // ------------------------------------------------------------- register writes
  wire wr_ctrl  = wr && (addr == TC_R_MBIST_CTRL);
  wire do_start = wr_ctrl && wdata[TC_F_MBIST_CTRL_START_LSB] && (st == S_IDLE) && mode_en;
  wire do_abort = (st != S_IDLE) && ((wr_ctrl && wdata[TC_F_MBIST_CTRL_ABORT_LSB]) || !mode_en);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cfg_algo    <= TC_ALG_MARCH_C_MINUS;
      cfg_bg      <= TC_BG_SOLID;
      cfg_sof     <= 1'b0;
      cfg_sigchk  <= 1'b0;
      cfg_sel     <= '0;
      cfg_bg_user <= '0;
      cfg_pause   <= 32'd1024;
      cfg_sig_exp <= '0;
      cfg_log_idx <= '0;
      cfg_mem_idx <= '0;
      for (int i = 0; i < 8; i++) ualg[i] <= '0;
    end else if (wr) begin
      case (addr)
        TC_R_MBIST_CTRL: if (st == S_IDLE) begin
          cfg_algo   <= wdata[TC_F_MBIST_CTRL_ALGO_LSB +: 4];
          cfg_bg     <= wdata[TC_F_MBIST_CTRL_BG_LSB +: 3];
          cfg_sof    <= wdata[TC_F_MBIST_CTRL_STOP_ON_FAIL_LSB];
          cfg_sigchk <= wdata[TC_F_MBIST_CTRL_SIG_CHECK_LSB];
        end
        TC_R_MBIST_MEM_SEL: if (st == S_IDLE) cfg_sel <= wdata[NUM_MEMS-1:0];
        TC_R_MBIST_BG_USER: if (st == S_IDLE) cfg_bg_user <= wdata;
        TC_R_MBIST_PAUSE:   if (st == S_IDLE) cfg_pause <= wdata;
        TC_R_MBIST_SIG_EXP: cfg_sig_exp <= wdata;
        TC_R_MBIST_LOG_IDX: cfg_log_idx <= wdata[3:0];
        TC_R_MBIST_MEM_IDX: cfg_mem_idx <= wdata[4:0];
        TC_R_MBIST_UALG0:   if (st == S_IDLE) ualg[0] <= wdata[17:0];
        TC_R_MBIST_UALG1:   if (st == S_IDLE) ualg[1] <= wdata[17:0];
        TC_R_MBIST_UALG2:   if (st == S_IDLE) ualg[2] <= wdata[17:0];
        TC_R_MBIST_UALG3:   if (st == S_IDLE) ualg[3] <= wdata[17:0];
        TC_R_MBIST_UALG4:   if (st == S_IDLE) ualg[4] <= wdata[17:0];
        TC_R_MBIST_UALG5:   if (st == S_IDLE) ualg[5] <= wdata[17:0];
        TC_R_MBIST_UALG6:   if (st == S_IDLE) ualg[6] <= wdata[17:0];
        TC_R_MBIST_UALG7:   if (st == S_IDLE) ualg[7] <= wdata[17:0];
        default: ;
      endcase
    end
  end

  // ------------------------------------------------------------- pipeline
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < MAX_LAT; i++) begin
        pv[i] <= 1'b0; pexp[i] <= '0; paddr[i] <= '0; pel[i] <= '0; pop[i] <= '0;
      end
    end else begin
      pv[0]    <= issue && op_rd && !do_abort;
      pexp[0]  <= op_data;
      paddr[0] <= addr_q;
      pel[0]   <= elem_idx[2:0];
      pop[0]   <= op_idx;
      for (int i = 1; i < MAX_LAT; i++) begin
        pv[i] <= pv[i-1]; pexp[i] <= pexp[i-1]; paddr[i] <= paddr[i-1];
        pel[i] <= pel[i-1]; pop[i] <= pop[i-1];
      end
    end
  end

  // ------------------------------------------------------------- engine
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; cur_mem <= '0; elem_idx <= '0; elem_word <= '0; op_idx <= '0;
      addr_q <= '0; pause_cnt <= '0; drain_cnt <= '0; lw_valid <= 1'b0; lw_addr <= '0;
      gap_cnt <= '0; tested_any <= 1'b0;
      done <= 1'b0; fail <= 1'b0; stopped <= 1'b0; aborted <= 1'b0; log_ovf <= 1'b0;
      sig_fail <= 1'b0; fail_mems <= '0; fail_count <= '0; misr <= '0; acc_synd <= '0;
      log_count <= '0;
      for (int i = 0; i < LOG_DEPTH; i++) begin
        log_mem[i] <= '0; log_elem[i] <= '0; log_op[i] <= '0; log_addr[i] <= '0; log_synd[i] <= '0;
      end
    end else if (do_start) begin
      st <= S_CHECK; cur_mem <= '0; tested_any <= 1'b0;
      done <= 1'b0; fail <= 1'b0; stopped <= 1'b0; aborted <= 1'b0; log_ovf <= 1'b0;
      sig_fail <= 1'b0; fail_mems <= '0; fail_count <= '0; misr <= '0; acc_synd <= '0;
      log_count <= '0;
    end else if (do_abort) begin
      st <= S_IDLE; aborted <= 1'b1; done <= 1'b0;
    end else begin
      // ---- write-to-read gap tracking
      if (issue && !op_rd) begin
        lw_valid <= 1'b1; lw_addr <= addr_q; gap_cnt <= '0;
      end else if (gap_cnt != 2'd3) begin
        gap_cnt <= gap_cnt + 2'd1;
      end

      // ---- compare / compaction
      if (cmp_v && is_rom) misr <= tc_misr_step(misr, fold32(rd_cur & wmask));
      if (mism) begin
        fail <= 1'b1;
        fail_mems[cm] <= 1'b1;
        if (fail_count != 32'hFFFF_FFFF) fail_count <= fail_count + 32'd1;
        acc_synd <= acc_synd | synd;
        if (32'(log_count) < LOG_DEPTH) begin
          log_mem[log_count]  <= cm;
          log_elem[log_count] <= pel[tap];
          log_op[log_count]   <= pop[tap];
          log_addr[log_count] <= 20'(paddr[tap]);
          log_synd[log_count] <= synd;
          log_count <= log_count + 1'b1;
        end else begin
          log_ovf <= 1'b1;
        end
      end

      if (mism && cfg_sof) begin
        st <= S_IDLE; done <= 1'b1; stopped <= 1'b1;
      end else begin
        case (st)
          S_CHECK: begin
            if (32'(cur_mem) >= NUM_MEMS) begin
              st <= S_FIN;
            end else if (cfg_sel[cm]) begin
              elem_idx <= '0; lw_valid <= 1'b0; tested_any <= 1'b1;
              st <= S_LOAD;
            end else begin
              cur_mem <= cur_mem + 5'd1;
            end
          end
          S_LOAD: begin
            elem_word <= load_word;
            if (load_word[17:16] == TC_EK_MARCH) begin
              addr_q <= load_word[15] ? maxaddr : '0;
              op_idx <= '0;
              st     <= S_RUN;
            end else if (load_word[17:16] == TC_EK_PAUSE) begin
              pause_cnt <= cfg_pause;
              st        <= S_PAUSE;
            end else begin
              if (elem_idx == 4'd0 && !is_rom) begin   // empty algorithm: never a false pass
                fail <= 1'b1; fail_mems[cm] <= 1'b1;
              end
              drain_cnt <= '0;
              st        <= S_DRAIN;
            end
          end
          S_RUN: if (issue) begin
            if (op_idx == e_nops1) begin
              op_idx <= '0;
              if (addr_q == last_addr) begin
                elem_idx <= elem_idx + 4'd1;
                st       <= S_LOAD;
              end else begin
                addr_q <= e_down ? addr_q - 1'b1 : addr_q + 1'b1;
              end
            end else begin
              op_idx <= op_idx + 3'd1;
            end
          end
          S_PAUSE: begin
            if (pause_cnt == 32'd0) begin
              elem_idx <= elem_idx + 4'd1;
              st       <= S_LOAD;
            end else begin
              pause_cnt <= pause_cnt - 32'd1;
            end
          end
          S_DRAIN: begin
            drain_cnt <= drain_cnt + 4'd1;
            if (32'(drain_cnt) >= MAX_LAT) begin
              cur_mem <= cur_mem + 5'd1;
              st      <= S_CHECK;
            end
          end
          S_FIN: begin
            done <= 1'b1;
            st   <= S_IDLE;
            if (cfg_sigchk && (misr != cfg_sig_exp)) begin
              sig_fail <= 1'b1; fail <= 1'b1;
            end
            if (!tested_any) fail <= 1'b1;            // nothing selected: FAIL
          end
          default: ;
        endcase
      end
    end
  end

  assign busy_o = (st != S_IDLE);
  assign done_o = done;
  assign fail_o = fail;

  // ------------------------------------------------------------- register reads
  wire        log_v  = (32'(cfg_log_idx) < 32'(log_count)) && (32'(cfg_log_idx) < LOG_DEPTH);
  wire [3:0]  li     = (32'(cfg_log_idx) < LOG_DEPTH) ? cfg_log_idx : 4'd0;
  wire [95:0] lsynd  = log_v ? 96'(log_synd[li]) : 96'd0;
  wire [95:0] asynd  = 96'(acc_synd);
  wire        mi_v   = (32'(cfg_mem_idx) < NUM_MEMS);
  wire [3:0]  mi     = mi_v ? cfg_mem_idx[3:0] : 4'd0;

  always_comb begin
    rdata = 32'd0;
    case (addr)
      TC_R_MBIST_CTRL:       rdata = {21'd0, cfg_sigchk, cfg_sof, cfg_bg, cfg_algo, 2'b00};
      TC_R_MBIST_MEM_SEL:    rdata = 32'(cfg_sel);
      TC_R_MBIST_STATUS:     rdata = {11'd0, 5'(log_count), 1'b0, elem_idx[2:0], cm,
                                      1'b0, sig_fail, log_ovf, aborted, stopped, fail, done, busy_o};
      TC_R_MBIST_FAIL_MEMS:  rdata = 32'(fail_mems);
      TC_R_MBIST_FAIL_COUNT: rdata = fail_count;
      TC_R_MBIST_BG_USER:    rdata = cfg_bg_user;
      TC_R_MBIST_PAUSE:      rdata = cfg_pause;
      TC_R_MBIST_SIG:        rdata = misr;
      TC_R_MBIST_SIG_EXP:    rdata = cfg_sig_exp;
      TC_R_MBIST_LOG_IDX:    rdata = 32'(cfg_log_idx);
      TC_R_MBIST_LOG_INFO:   rdata = log_v ? {log_v, 1'b0, log_mem[li], log_elem[li], log_op[li], log_addr[li]} : 32'd0;
      TC_R_MBIST_LOG_SYND0:  rdata = lsynd[31:0];
      TC_R_MBIST_LOG_SYND1:  rdata = lsynd[63:32];
      TC_R_MBIST_LOG_SYND2:  rdata = lsynd[95:64];
      TC_R_MBIST_ACC_SYND0:  rdata = asynd[31:0];
      TC_R_MBIST_ACC_SYND1:  rdata = asynd[63:32];
      TC_R_MBIST_ACC_SYND2:  rdata = asynd[95:64];
      TC_R_MBIST_NUM_MEMS:   rdata = 32'(NUM_MEMS);
      TC_R_MBIST_MEM_IDX:    rdata = 32'(cfg_mem_idx);
      TC_R_MBIST_MEM_INFO0:  rdata = mi_v ? {16'd0, 1'b1, MEM_WR2RD[mi*2 +: 2], MEM_TYPE[mi*2 +: 2],
                                             MEM_LAT[mi*3 +: 3], MEM_DW[mi*8 +: 8]} : 32'd0;
      TC_R_MBIST_MEM_INFO1:  rdata = mi_v ? 32'(MEM_MAXADDR[mi*20 +: 20]) : 32'd0;
      TC_R_MBIST_UALG0:      rdata = 32'(ualg[0]);
      TC_R_MBIST_UALG1:      rdata = 32'(ualg[1]);
      TC_R_MBIST_UALG2:      rdata = 32'(ualg[2]);
      TC_R_MBIST_UALG3:      rdata = 32'(ualg[3]);
      TC_R_MBIST_UALG4:      rdata = 32'(ualg[4]);
      TC_R_MBIST_UALG5:      rdata = 32'(ualg[5]);
      TC_R_MBIST_UALG6:      rdata = 32'(ualg[6]);
      TC_R_MBIST_UALG7:      rdata = 32'(ualg[7]);
      default:               rdata = 32'd0;
    endcase
  end

  // ------------------------------------------------------------- parameter checks
`ifndef SYNTHESIS
  initial begin
    if (MAX_DW > 96)    $error("tc_mbist: MAX_DW must be <= 96 (syndrome registers)");
    if (NUM_MEMS > 16)  $error("tc_mbist: NUM_MEMS must be <= 16");
    if (LOG_DEPTH > 16) $error("tc_mbist: LOG_DEPTH must be <= 16");
    if (MAX_LAT > 7)    $error("tc_mbist: MAX_LAT must be <= 7");
    if (MAX_AW > 20)    $error("tc_mbist: MAX_AW must be <= 20");
  end
`endif

endmodule
/* verilator lint_on UNUSEDSIGNAL */
/* verilator lint_on WIDTHEXPAND */
/* verilator lint_on WIDTHTRUNC */

`default_nettype wire
