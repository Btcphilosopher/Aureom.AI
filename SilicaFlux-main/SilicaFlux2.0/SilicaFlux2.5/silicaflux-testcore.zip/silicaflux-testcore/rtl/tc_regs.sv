// =============================================================================
// SilicaFlux TestCore :: tc_regs
// Identification, security/mode status, reset cause, clock status, scratch,
// capabilities, software reset, error counters, core debug (halt / resume /
// single-step / abstract register access) and accelerator diagnostic status.
// Access permissions are enforced upstream in tc_regbus; this block only
// decodes permitted writes.
//
// Core debug port protocol (generic, single hart):
//   dbg_halt_req_o  level: core must drain and assert dbg_halted_i while high.
//                   Gated by DIAGNOSTIC mode: leaving DIAGNOSTIC resumes the core.
//   dbg_step_req_o  1-cycle pulse while halted: execute one instruction, re-halt.
//   dbg_reg_*       req held until ack; regno 0..31 GPRs, 32 = PC (core-defined);
//                   only issued while halted; 255-cycle timeout -> CMD_ERR.
// The existing SilicaFlux RV32I cores have no debug hooks; the required core
// changes are listed in docs/08_silicon_debug_and_security.md.  This is a
// bring-up/test debug path, NOT a RISC-V Debug Specification implementation.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module tc_regs
  import tc_spec_pkg::*;
#(
  parameter int NUM_ERR   = 8,
  parameter int NUM_MEMS  = 4,
  parameter int LOG_DEPTH = 8,
  parameter bit TRACE_EN  = 1'b1,
  parameter bit LBIST_EN  = 1'b1
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // bus
  input  wire logic              wr,
  input  wire logic              is_jtag,
  input  wire logic [11:0]       addr,
  input  wire logic [31:0]       wdata,
  output logic [31:0]            rdata,
  input  wire logic              denied_evt,
  // identification
  input  wire logic [23:0]       silicon_rev_i,   // {major, minor, metal}
  input  wire logic [31:0]       idcode_i,
  input  wire logic [63:0]       ecid_i,
  // security / mode (system-domain synchronised)
  input  wire logic [2:0]        lc_i,
  input  wire logic              unlocked_i,
  input  wire logic              lockout_i,
  input  wire logic [2:0]        attempts_i,
  input  wire logic [2:0]        mode_i,
  input  wire logic              diag_mode_i,
  input  wire logic [3:0]        diag_opts_i,
  // reset controller
  input  wire logic [5:0]        rst_cause_i,
  input  wire logic [31:0]       rst_count_i,
  input  wire logic              sys_in_reset_i,
  output logic                   cause_w1c_en_o,
  output logic [5:0]             cause_w1c_o,
  output logic                   sw_rst_req_o,
  output logic                   dbg_rst_req_o,
  // clocks
  input  wire logic              pll_lock_i,
  input  wire logic [7:0]        clk_src_sel_i,
  input  wire logic              clk_test_sel_i,
  input  wire logic              clk_stop_i,
  input  wire logic [31:0]       clk_meas_i,
  input  wire logic              clk_meas_valid_i,
  input  wire logic [31:0]       clk_cycles_i,
  // error events (single-cycle pulses, clk domain)
  input  wire logic [NUM_ERR-1:0] err_evt_i,
  // accelerator diagnostics
  input  wire logic [127:0]      acc_diag_i,
  // core debug port
  output logic                   dbg_halt_req_o,
  output logic                   dbg_step_req_o,
  input  wire logic              dbg_halted_i,
  input  wire logic [31:0]       dbg_pc_i,
  output logic                   dbg_reg_req_o,
  output logic                   dbg_reg_we_o,
  output logic [5:0]             dbg_reg_addr_o,
  output logic [31:0]            dbg_reg_wdata_o,
  input  wire logic              dbg_reg_ack_i,
  input  wire logic [31:0]       dbg_reg_rdata_i,
  input  wire logic              dbg_reg_err_i
);
  logic [31:0] scratch;
  logic [7:0]  denied_cnt;
  logic [15:0] err_cnt [8];
  logic [127:0] acc_q;

  // ------------------------------------------------------------- simple registers
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      scratch    <= '0;
      denied_cnt <= '0;
      acc_q      <= '0;
    end else begin
      acc_q <= acc_diag_i;
      if (wr && addr == TC_R_SCRATCH) scratch <= wdata;
      if (denied_evt && denied_cnt != 8'hFF) denied_cnt <= denied_cnt + 8'd1;
    end
  end

  assign cause_w1c_en_o = wr && (addr == TC_R_RESET_CAUSE);
  assign cause_w1c_o    = wdata[5:0];
  wire   sw_key         = wr && (addr == TC_R_SW_RST) && (wdata == TC_SW_RST_KEY);
  logic  ndm_pulse;
  assign sw_rst_req_o   = sw_key && !is_jtag;
  assign dbg_rst_req_o  = (sw_key && is_jtag) || ndm_pulse;

  // ------------------------------------------------------------- error counters
  wire [7:0] err_clr = (wr && addr == TC_R_ERR_CLR) ? wdata[7:0] : 8'd0;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < 8; i++) err_cnt[i] <= '0;
    end else begin
      for (int i = 0; i < 8; i++) begin
        if (i >= NUM_ERR)                         err_cnt[i] <= '0;
        else if (err_clr[i])                      err_cnt[i] <= '0;
        else if (err_evt_i[i % NUM_ERR] && err_cnt[i] != 16'hFFFF) err_cnt[i] <= err_cnt[i] + 16'd1;
      end
    end
  end
  logic [7:0] err_sum;
  always_comb for (int i = 0; i < 8; i++) err_sum[i] = (err_cnt[i] != 16'd0);

  // ------------------------------------------------------------- core debug
  logic        halt_req, havereset, cmd_busy, cmd_err, cmd_we, diag_q;
  logic [5:0]  cmd_regno;
  logic [31:0] dbg_data;
  logic [7:0]  cmd_tmo;

  wire wr_dctrl = wr && (addr == TC_R_DBG_CTRL);
  wire wr_dcmd  = wr && (addr == TC_R_DBG_CMD);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      halt_req <= 1'b0; havereset <= 1'b0; cmd_busy <= 1'b0; cmd_err <= 1'b0; cmd_we <= 1'b0;
      cmd_regno <= '0; dbg_data <= '0; cmd_tmo <= '0; diag_q <= 1'b0;
      dbg_step_req_o <= 1'b0; ndm_pulse <= 1'b0;
    end else begin
      diag_q         <= diag_mode_i;
      dbg_step_req_o <= 1'b0;
      ndm_pulse      <= 1'b0;
      if (sys_in_reset_i) havereset <= 1'b1;

      if (!diag_mode_i) begin
        halt_req <= 1'b0;
      end else if (diag_mode_i && !diag_q && diag_opts_i[0]) begin
        halt_req <= 1'b1;                              // halt-on-entry option
      end else if (wr_dctrl) begin
        halt_req <= wdata[TC_F_DBG_CTRL_HALT_REQ_LSB];
        if (wdata[TC_F_DBG_CTRL_STEP_LSB] && dbg_halted_i && halt_req) dbg_step_req_o <= 1'b1;
        if (wdata[TC_F_DBG_CTRL_NDMRESET_LSB])      ndm_pulse <= 1'b1;
        if (wdata[TC_F_DBG_CTRL_ACK_HAVERESET_LSB]) havereset <= 1'b0;
      end

      if (wr && addr == TC_R_DBG_DATA && !cmd_busy) dbg_data <= wdata;

      if (cmd_busy) begin
        cmd_tmo <= cmd_tmo + 8'd1;
        if (!diag_mode_i || cmd_tmo == 8'hFF) begin
          cmd_busy <= 1'b0; cmd_err <= 1'b1;
        end else if (dbg_reg_ack_i) begin
          cmd_busy <= 1'b0;
          cmd_err  <= dbg_reg_err_i;
          if (!cmd_we) dbg_data <= dbg_reg_rdata_i;
        end
      end else if (wr_dcmd) begin
        if (!dbg_halted_i) begin
          cmd_err <= 1'b1;                             // core must be halted
        end else begin
          cmd_busy  <= 1'b1;
          cmd_err   <= 1'b0;
          cmd_we    <= wdata[TC_F_DBG_CMD_WRITE_LSB];
          cmd_regno <= wdata[TC_F_DBG_CMD_REGNO_LSB +: 6];
          cmd_tmo   <= '0;
        end
      end
    end
  end

  assign dbg_halt_req_o  = halt_req && diag_mode_i;
  assign dbg_reg_req_o   = cmd_busy;
  assign dbg_reg_we_o    = cmd_we;
  assign dbg_reg_addr_o  = cmd_regno;
  assign dbg_reg_wdata_o = dbg_data;

  // ------------------------------------------------------------- read mux
  always_comb begin
    rdata = '0;
    case (addr)
      TC_R_TC_MAGIC:    rdata = TC_TC_MAGIC_VALUE;
      TC_R_TC_VERSION:  rdata = {8'd0, TC_IP_MAJOR, TC_IP_MINOR, TC_IP_PATCH};
      TC_R_SILICON_REV: rdata = {silicon_rev_i, 8'd0};
      TC_R_IDCODE:      rdata = idcode_i;
      TC_R_ECID_LO:     rdata = ecid_i[31:0];
      TC_R_ECID_HI:     rdata = ecid_i[63:32];
      TC_R_SEC_STATUS:  rdata = {8'd0, denied_cnt, 5'd0, attempts_i, 3'd0, lockout_i, unlocked_i, lc_i};
      TC_R_MODE_STATUS: rdata = {24'd0, diag_opts_i, 1'b0, mode_i};
      TC_R_RESET_CAUSE: rdata = 32'(rst_cause_i);
      TC_R_RESET_COUNT: rdata = rst_count_i;
      TC_R_CLK_STATUS:  rdata = {16'd0, clk_src_sel_i, 4'd0, clk_stop_i, clk_test_sel_i, clk_meas_valid_i, pll_lock_i};
      TC_R_CLK_MEAS:    rdata = clk_meas_i;
      TC_R_CLK_CYCLES:  rdata = clk_cycles_i;
      TC_R_SCRATCH:     rdata = scratch;
      TC_R_CAPS:        rdata = {11'd0, 5'(LOG_DEPTH), 1'b0, 1'b0 /*REPAIR*/, LBIST_EN, TRACE_EN,
                                 4'(NUM_ERR), 3'd0, 5'(NUM_MEMS)};
      TC_R_ERR_CNT0:    rdata = 32'(err_cnt[0]);
      TC_R_ERR_CNT1:    rdata = 32'(err_cnt[1]);
      TC_R_ERR_CNT2:    rdata = 32'(err_cnt[2]);
      TC_R_ERR_CNT3:    rdata = 32'(err_cnt[3]);
      TC_R_ERR_CNT4:    rdata = 32'(err_cnt[4]);
      TC_R_ERR_CNT5:    rdata = 32'(err_cnt[5]);
      TC_R_ERR_CNT6:    rdata = 32'(err_cnt[6]);
      TC_R_ERR_CNT7:    rdata = 32'(err_cnt[7]);
      TC_R_ERR_SUMMARY: rdata = 32'(err_sum);
      TC_R_DBG_CTRL:    rdata = 32'(halt_req);
      TC_R_DBG_STATUS:  rdata = {23'd0, diag_mode_i, 2'd0, cmd_err, cmd_busy, havereset,
                                 halt_req && diag_mode_i, !dbg_halted_i, dbg_halted_i};
      TC_R_DBG_PC:      rdata = dbg_pc_i;
      TC_R_DBG_CMD:     rdata = {15'd0, cmd_we, 10'd0, cmd_regno};
      TC_R_DBG_DATA:    rdata = dbg_data;
      TC_R_ACC_DIAG0:   rdata = acc_q[31:0];
      TC_R_ACC_DIAG1:   rdata = acc_q[63:32];
      TC_R_ACC_DIAG2:   rdata = acc_q[95:64];
      TC_R_ACC_DIAG3:   rdata = acc_q[127:96];
      default:          rdata = '0;
    endcase
  end

endmodule

`default_nettype wire
