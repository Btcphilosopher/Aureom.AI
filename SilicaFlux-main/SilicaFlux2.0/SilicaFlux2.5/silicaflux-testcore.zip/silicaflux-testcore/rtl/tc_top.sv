// =============================================================================
// SilicaFlux TestCore :: tc_top
// Reusable DFT / debug infrastructure for SilicaFlux-V and later SilicaFlux
// devices.  Integrates:
//   tc_tap         IEEE 1149.1-style TAP (IR, BYPASS, IDCODE)
//   tc_bsr         boundary-scan register around the reference pin set
//   tc_mode_ctrl   test-mode state machine, lifecycle/unlock access control
//   tc_reg_bridge  TC_REG DR -> register bus (TCK -> clk CDC)
//   tc_regbus      register bus, JTAG + system APB masters, access checks
//   tc_regs        ID / status / reset cause / clocks / error counters / debug
//   tc_mbist       March MBIST controller (memory bus to tc_mbist_collar)
//   tc_lbist       test-per-clock LBIST for a demonstration target (optional)
//   tc_trace       trace buffer (optional)
//   tc_rst_ctrl    reset synchronisers, staged release, reset cause
//   tc_clk_ctrl    test-clock root mux sequencing, clock monitor
//   tc_test_pinmux scan / BIST status pins on GPIO
//
// Clock domains: tck (TAP, mode control, TDRs), clk_o (root system clock that
// also clocks TestCore's own system-side logic), func_clk_i (pre-mux),
// ref_clk_i (monitor reference).  All crossings use tc_sync or the bridge's
// toggle handshake; TCK-domain mode outputs are quasi-static levels.
// Classification: SYNTHESIZABLE (library-cell mapping required: tc_cells.sv)
// =============================================================================
`default_nettype none

module tc_top
  import tc_spec_pkg::*;
  import tc_pkg::*;
#(
  // pins
  parameter int NUM_IN      = 3,
  parameter int NUM_OUT     = 4,
  parameter int NUM_BIDIR   = 8,
  parameter int NUM_SCAN_CH = 2,
  // MBIST registry
  parameter int NUM_MEMS    = 2,
  parameter int MAX_DW      = 72,
  parameter int MAX_AW      = 16,
  parameter int MAX_LAT     = 4,
  parameter int LOG_DEPTH   = 8,
  parameter logic [NUM_MEMS*8-1:0]  MEM_DW      = {8'd32, 8'd32},
  parameter logic [NUM_MEMS*20-1:0] MEM_MAXADDR = {20'd255, 20'd255},
  parameter logic [NUM_MEMS*3-1:0]  MEM_LAT     = {3'd1, 3'd1},
  parameter logic [NUM_MEMS*2-1:0]  MEM_TYPE    = {2'd0, 2'd0},
  parameter logic [NUM_MEMS*2-1:0]  MEM_WR2RD   = {2'd0, 2'd0},
  // LBIST / trace / errors / clocks
  parameter bit LBIST_EN    = 1'b1,
  parameter int LB_IN_W     = 68,
  parameter int LB_OUT_W    = 33,
  parameter int LB_LAT      = 0,
  parameter bit TRACE_EN    = 1'b1,
  parameter int TRACE_DEPTH = 16,
  parameter int NUM_ERR     = 8,
  parameter int REF_WINDOW  = 64
) (
  // ---- JTAG
  input  wire logic                    tck,
  input  wire logic                    tms,
  input  wire logic                    tdi,
  input  wire logic                    trst_n,
  output logic                         tdo,
  output logic                         tdo_oe,
  // ---- clocks / resets
  input  wire logic                    por_n,
  input  wire logic                    ext_rst_n,
  input  wire logic                    func_clk_i,
  input  wire logic                    test_clk_i,
  input  wire logic                    ref_clk_i,
  input  wire logic                    pll_lock_i,
  input  wire logic [7:0]              clk_src_sel_i,
  output logic                         clk_o,
  output logic                         sys_rst_n_o,
  output logic                         core_rst_n_o,
  input  wire logic                    wdt_rst_req_i,
  // ---- OTP / tie-offs
  input  wire logic                    otp_valid_i,
  input  wire logic [7:0]              lc_otp_i,
  input  wire logic [63:0]             unlock_key_i,
  input  wire logic [63:0]             ecid_i,
  input  wire logic [23:0]             silicon_rev_i,
  input  wire logic [3:0]              idcode_version_i,
  // ---- boundary: input pins
  input  wire logic [NUM_IN-1:0]       in_pad_i,
  output logic      [NUM_IN-1:0]       in_core_o,
  // ---- boundary: output pins
  input  wire logic [NUM_OUT-1:0]      out_core_i,
  input  wire logic [NUM_OUT-1:0]      out_core_oe_i,
  output logic      [NUM_OUT-1:0]      out_pad_o,
  output logic      [NUM_OUT-1:0]      out_pad_oe_o,
  // ---- boundary: bidirectional pins (GPIO, test-muxed)
  input  wire logic [NUM_BIDIR-1:0]    io_core_o_i,
  input  wire logic [NUM_BIDIR-1:0]    io_core_oe_i,
  output logic      [NUM_BIDIR-1:0]    io_core_i_o,
  output logic      [NUM_BIDIR-1:0]    io_pad_o,
  output logic      [NUM_BIDIR-1:0]    io_pad_oe_o,
  input  wire logic [NUM_BIDIR-1:0]    io_pad_i,
  // ---- DFT distribution
  output logic                         dft_scan_mode_o,
  output logic                         dft_scan_en_o,
  output logic                         dft_cg_te_o,
  output logic [3:0]                   dft_scan_cfg_o,
  output logic [NUM_SCAN_CH-1:0]       dft_scan_in_o,
  input  wire logic [NUM_SCAN_CH-1:0]  dft_scan_out_i,
  output logic [2:0]                   test_mode_o,
  // ---- MBIST memory test bus
  output logic                         mbist_active_o,
  output logic [NUM_MEMS-1:0]          mbist_sel_o,
  output logic                         mbist_ce_o,
  output logic                         mbist_we_o,
  output logic [MAX_AW-1:0]            mbist_addr_o,
  output logic [MAX_DW-1:0]            mbist_wdata_o,
  input  wire logic [NUM_MEMS*MAX_DW-1:0] mbist_rdata_i,
  // ---- LBIST target
  output logic                         lbist_tgt_sel_o,
  output logic [LB_IN_W-1:0]           lbist_tgt_in_o,
  input  wire logic [LB_OUT_W-1:0]     lbist_tgt_out_i,
  // ---- core debug port
  output logic                         dbg_halt_req_o,
  output logic                         dbg_step_req_o,
  input  wire logic                    dbg_halted_i,
  input  wire logic [31:0]             dbg_pc_i,
  output logic                         dbg_reg_req_o,
  output logic                         dbg_reg_we_o,
  output logic [5:0]                   dbg_reg_addr_o,
  output logic [31:0]                  dbg_reg_wdata_o,
  input  wire logic                    dbg_reg_ack_i,
  input  wire logic [31:0]             dbg_reg_rdata_i,
  input  wire logic                    dbg_reg_err_i,
  // ---- diagnostics
  input  wire logic [NUM_ERR-1:0]      err_evt_i,
  input  wire logic [127:0]            acc_diag_i,
  input  wire logic                    trace_valid_i,
  input  wire logic [31:0]             trace_data_i,
  // ---- system APB (CPU access to status registers)
  input  wire logic                    psel,
  input  wire logic                    penable,
  input  wire logic                    pwrite,
  input  wire logic [11:0]             paddr,
  input  wire logic [31:0]             pwdata,
  output logic [31:0]                  prdata,
  output logic                         pready,
  output logic                         pslverr
);
  // =========================================================================
  // TCK domain
  // =========================================================================
  logic tap_rst_n;
  assign tap_rst_n = trst_n & por_n;   // TAP must reset at power-up

  logic [3:0]           tap_state;
  logic [TC_IR_LEN-1:0] ir;
  logic cap_dr, sh_dr, upd_dr;
  logic tdo_bsr, tdo_status, tdo_mode, tdo_unlock, tdo_reg;

  tc_tap u_tap (
    .tck, .trst_n(tap_rst_n), .tms, .tdi, .tdo, .tdo_oe,
    .idcode_version_i,
    .state_o(tap_state), .ir_o(ir), .capture_dr_o(cap_dr), .shift_dr_o(sh_dr),
    .update_dr_o(upd_dr), .tlr_o(),
    .tdo_bsr_i(tdo_bsr), .tdo_status_i(tdo_status), .tdo_mode_i(tdo_mode),
    .tdo_unlock_i(tdo_unlock), .tdo_reg_i(tdo_reg)
  );

  wire bsr_sel  = (ir == TC_IR_EXTEST) || (ir == TC_IR_SAMPLE_PRELOAD);
  wire bsr_ext  = (ir == TC_IR_EXTEST) || (ir == TC_IR_CLAMP);
  wire bsr_hz   = (ir == TC_IR_HIGHZ);

  // ---- mode controller
  logic [2:0] mode_tck, lc_tck, attempts_tck;
  logic [3:0] opts_tck;
  logic scan_mode, mbist_mode, lbist_mode, diag_mode, bscan_mode;
  logic clk_test_sel, func_clk_stop, sys_rst_hold, tc_rst_hold;
  logic unlocked_tck, lockout_tck, reg_busy_tck;
  logic [7:0] sys_status;

  tc_mode_ctrl u_mode (
    .tck, .tap_rst_n, .por_n, .tap_state, .ir, .tdi,
    .tdo_status, .tdo_mode, .tdo_unlock,
    .otp_valid_i, .lc_otp_i, .unlock_key_i,
    .sys_status_i(sys_status), .reg_busy_i(reg_busy_tck),
    .mode_o(mode_tck), .mode_busy_o(), .opts_o(opts_tck),
    .scan_mode_o(scan_mode), .mbist_mode_o(mbist_mode), .lbist_mode_o(lbist_mode),
    .diag_mode_o(diag_mode), .bscan_mode_o(bscan_mode),
    .clk_test_sel_o(clk_test_sel), .func_clk_stop_o(func_clk_stop),
    .sys_rst_hold_o(sys_rst_hold), .tc_rst_hold_o(tc_rst_hold),
    .lc_o(lc_tck), .unlocked_o(unlocked_tck), .lockout_o(lockout_tck), .attempts_o(attempts_tck)
  );
  assign test_mode_o = mode_tck;

  // ---- boundary scan + test pin mux
  logic [NUM_BIDIR-1:0] bsr_io_core_o, bsr_io_core_oe, bsr_io_core_i;
  logic scan_rst_n_pin;
  logic mb_busy, mb_done, mb_fail, lb_busy, lb_done, lb_pass;

  tc_bsr #(.NUM_IN(NUM_IN), .NUM_OUT(NUM_OUT), .NUM_BIDIR(NUM_BIDIR)) u_bsr (
    .tck, .trst_n(tap_rst_n), .tdi, .tdo(tdo_bsr),
    .sel(bsr_sel), .capture_dr(cap_dr), .shift_dr(sh_dr), .update_dr(upd_dr),
    .ext_mode(bsr_ext), .highz(bsr_hz),
    .in_pad_i, .in_core_o,
    .out_core_i, .out_core_oe_i, .out_pad_o, .out_pad_oe_o,
    .io_core_o_i(bsr_io_core_o), .io_core_oe_i(bsr_io_core_oe), .io_core_i_o(bsr_io_core_i),
    .io_pad_o, .io_pad_oe_o, .io_pad_i
  );

  tc_test_pinmux #(.NUM_IO(NUM_BIDIR), .NUM_CH(NUM_SCAN_CH)) u_pinmux (
    .scan_mode, .mbist_mode, .lbist_mode,
    .st0(mb_done), .st1(mb_fail), .lst0(lb_done), .lst1(lb_pass),
    .core_o(io_core_o_i), .core_oe(io_core_oe_i), .core_i(io_core_i_o),
    .pad_o(bsr_io_core_o), .pad_oe(bsr_io_core_oe), .pad_i(bsr_io_core_i),
    .scan_en_o(dft_scan_en_o), .scan_rst_n_o(scan_rst_n_pin),
    .scan_in_o(dft_scan_in_o), .scan_out_i(dft_scan_out_i)
  );

  assign dft_scan_mode_o = scan_mode;
  assign dft_cg_te_o     = dft_scan_en_o;
  assign dft_scan_cfg_o  = scan_mode ? opts_tck : 4'h0;

  // =========================================================================
  // Clocks and resets
  // =========================================================================
  logic tc_rst_n, sys_in_reset;
  logic [31:0] clk_meas, clk_cycles;
  logic clk_meas_valid;

  tc_clk_ctrl #(.REF_WINDOW(REF_WINDOW)) u_clk (
    .por_n, .scan_mode, .scan_rst_n(scan_rst_n_pin), .func_clk_i, .test_clk_i, .ref_clk_i,
    .stop_req(func_clk_stop), .test_sel(clk_test_sel), .clk_o,
    .rst_n(tc_rst_n), .meas_o(clk_meas), .meas_valid_o(clk_meas_valid), .cycles_o(clk_cycles)
  );

  logic cause_w1c_en, sw_rst_req, dbg_rst_req;
  logic [5:0] cause_w1c, rst_cause;
  logic [31:0] rst_count;

  tc_rst_ctrl u_rst (
    .clk(clk_o), .por_n, .ext_rst_n, .sys_rst_hold, .tc_rst_hold,
    .wdt_req(wdt_rst_req_i), .sw_req(sw_rst_req), .dbg_req(dbg_rst_req),
    .scan_mode, .scan_rst_n(scan_rst_n_pin),
    .tc_rst_n, .sys_rst_n(sys_rst_n_o), .core_rst_n(core_rst_n_o), .sys_in_reset,
    .cause_w1c_en, .cause_w1c, .cause_o(rst_cause), .count_o(rst_count)
  );

  // =========================================================================
  // System-clock domain (TestCore side, reset by tc_rst_n)
  // =========================================================================
  // One-hot mode levels synchronised bit-by-bit: transitions always pass
  // through NORMAL, so at most one bit changes at a time (glitch-safe decode).
  logic diag_s, mbist_s, lbist_s, scan_s, bscan_s, unlocked_s, lockout_s, pll_lock_s;
  logic clk_test_sel_s, clk_stop_s;
  logic [3:0] opts_s;
  logic [2:0] lc_s, attempts_s;
  tc_sync #(.W(20)) u_sync_mode (
    .clk(clk_o), .rst_n(tc_rst_n),
    .d({diag_mode, mbist_mode, lbist_mode, scan_mode, bscan_mode, opts_tck, lc_tck, attempts_tck,
        unlocked_tck, lockout_tck, pll_lock_i, clk_test_sel, func_clk_stop}),
    .q({diag_s, mbist_s, lbist_s, scan_s, bscan_s, opts_s, lc_s, attempts_s,
        unlocked_s, lockout_s, pll_lock_s, clk_test_sel_s, clk_stop_s})
  );
  wire [2:0] mode_sys = diag_s  ? TC_MODE_DIAGNOSTIC  :
                        mbist_s ? TC_MODE_MEMORY_BIST :
                        lbist_s ? TC_MODE_LOGIC_TEST  :
                        scan_s  ? TC_MODE_SCAN_TEST   :
                        bscan_s ? TC_MODE_JTAG        : TC_MODE_NORMAL;

  // ---- JTAG register bridge
  logic        j_req, j_we, j_gnt, j_err;
  logic [11:0] j_addr;
  logic [31:0] j_wdata, j_rdata;
  tc_reg_bridge u_bridge (
    .tck, .por_n, .tap_state, .sel(ir == TC_IR_TC_REG), .tdi, .tdo(tdo_reg), .busy_tck_o(reg_busy_tck),
    .clk(clk_o), .rst_n(tc_rst_n),
    .m_req(j_req), .m_we(j_we), .m_addr(j_addr), .m_wdata(j_wdata),
    .m_gnt(j_gnt), .m_rdata(j_rdata), .m_err(j_err)
  );

  // ---- register bus
  localparam int NSLV = 4;
  logic        s_wr, s_is_jtag, denied;
  logic [11:0] s_addr;
  logic [31:0] s_wdata;
  logic [31:0] rd_regs, rd_mbist, rd_lbist, rd_trace;
  tc_regbus #(.NSLV(NSLV)) u_bus (
    .mode_sys,
    .j_req, .j_we, .j_addr, .j_wdata, .j_gnt, .j_rdata, .j_err,
    .psel, .penable, .pwrite, .paddr, .pwdata, .prdata, .pready, .pslverr,
    .s_wr, .s_is_jtag, .s_addr, .s_wdata,
    .s_rdata({rd_trace, rd_lbist, rd_mbist, rd_regs}),
    .denied_o(denied)
  );

  // ---- registers / debug
  tc_regs #(.NUM_ERR(NUM_ERR), .NUM_MEMS(NUM_MEMS), .LOG_DEPTH(LOG_DEPTH),
            .TRACE_EN(TRACE_EN), .LBIST_EN(LBIST_EN)) u_regs (
    .clk(clk_o), .rst_n(tc_rst_n),
    .wr(s_wr), .is_jtag(s_is_jtag), .addr(s_addr), .wdata(s_wdata), .rdata(rd_regs), .denied_evt(denied),
    .silicon_rev_i, .idcode_i({idcode_version_i, TC_IDCODE_PART, TC_IDCODE_MFG, 1'b1}), .ecid_i,
    .lc_i(lc_s), .unlocked_i(unlocked_s), .lockout_i(lockout_s), .attempts_i(attempts_s),
    .mode_i(mode_sys), .diag_mode_i(diag_s), .diag_opts_i(diag_s ? opts_s : 4'h0),
    .rst_cause_i(rst_cause), .rst_count_i(rst_count), .sys_in_reset_i(sys_in_reset),
    .cause_w1c_en_o(cause_w1c_en), .cause_w1c_o(cause_w1c),
    .sw_rst_req_o(sw_rst_req), .dbg_rst_req_o(dbg_rst_req),
    .pll_lock_i(pll_lock_s), .clk_src_sel_i, .clk_test_sel_i(clk_test_sel_s), .clk_stop_i(clk_stop_s),
    .clk_meas_i(clk_meas), .clk_meas_valid_i(clk_meas_valid), .clk_cycles_i(clk_cycles),
    .err_evt_i, .acc_diag_i,
    .dbg_halt_req_o, .dbg_step_req_o, .dbg_halted_i, .dbg_pc_i,
    .dbg_reg_req_o, .dbg_reg_we_o, .dbg_reg_addr_o, .dbg_reg_wdata_o,
    .dbg_reg_ack_i, .dbg_reg_rdata_i, .dbg_reg_err_i
  );

  // ---- MBIST
  tc_mbist #(
    .NUM_MEMS(NUM_MEMS), .MAX_DW(MAX_DW), .MAX_AW(MAX_AW), .MAX_LAT(MAX_LAT), .LOG_DEPTH(LOG_DEPTH),
    .MEM_DW(MEM_DW), .MEM_MAXADDR(MEM_MAXADDR), .MEM_LAT(MEM_LAT), .MEM_TYPE(MEM_TYPE), .MEM_WR2RD(MEM_WR2RD)
  ) u_mbist (
    .clk(clk_o), .rst_n(tc_rst_n), .mode_en(mbist_s),
    .wr(s_wr), .addr(s_addr), .wdata(s_wdata), .rdata(rd_mbist),
    .active_o(mbist_active_o), .sel_o(mbist_sel_o), .ce_o(mbist_ce_o), .we_o(mbist_we_o),
    .addr_o(mbist_addr_o), .wdata_o(mbist_wdata_o), .rdata_i(mbist_rdata_i),
    .busy_o(mb_busy), .done_o(mb_done), .fail_o(mb_fail)
  );

  // ---- LBIST (optional)
  generate
    if (LBIST_EN) begin : g_lbist
      tc_lbist #(.IN_W(LB_IN_W), .OUT_W(LB_OUT_W), .LAT(LB_LAT)) u_lbist (
        .clk(clk_o), .rst_n(tc_rst_n), .mode_en(lbist_s),
        .wr(s_wr), .addr(s_addr), .wdata(s_wdata), .rdata(rd_lbist),
        .tgt_sel_o(lbist_tgt_sel_o), .tgt_in_o(lbist_tgt_in_o), .tgt_out_i(lbist_tgt_out_i),
        .busy_o(lb_busy), .done_o(lb_done), .pass_o(lb_pass)
      );
    end else begin : g_nolbist
      assign rd_lbist = '0; assign lbist_tgt_sel_o = 1'b0; assign lbist_tgt_in_o = '0;
      assign lb_busy = 1'b0; assign lb_done = 1'b0; assign lb_pass = 1'b0;
    end
  endgenerate

  // ---- trace (optional)
  generate
    if (TRACE_EN) begin : g_trace
      tc_trace #(.DEPTH(TRACE_DEPTH)) u_trace (
        .clk(clk_o), .rst_n(tc_rst_n), .wr(s_wr), .addr(s_addr), .wdata(s_wdata), .rdata(rd_trace),
        .core_halted(dbg_halted_i), .trace_valid_i, .trace_data_i
      );
    end else begin : g_notrace
      assign rd_trace = '0;
    end
  endgenerate

  // ---- system status to TCK domain (synchronised inside tc_mode_ctrl)
  assign sys_status = {sys_in_reset, dbg_halted_i, lb_pass, lb_done, lb_busy, mb_fail, mb_done, mb_busy};

endmodule

`default_nettype wire
