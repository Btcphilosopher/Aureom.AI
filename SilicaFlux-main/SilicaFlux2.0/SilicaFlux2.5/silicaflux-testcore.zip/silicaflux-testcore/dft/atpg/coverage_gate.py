#!/usr/bin/env python3
"""ATPG coverage gate (tool-independent).

Input: a tool-neutral summary JSON, e.g.
  {"design": "silicaflux_v", "netlist_rev": "...",
   "fault_models": {"stuck_at":  {"total": 1000, "detected": 990, "untestable": 2, "possibly_detected": 0},
                    "transition": {"total": 1000, "detected": 950, "untestable": 10}},
   "patterns": {"stuck_at": 812, "transition": 1430}}
or a raw tool report converted with --from-report (regex extraction of the
common 'test coverage' / 'fault coverage' summary lines).

Targets default to dft/atpg/atpg_interface.json (PROPOSED: SA >= 99 %,
transition >= 95 %).  Exit status 0 only if every reported model meets its
target.  Possibly-detected faults receive 50 % credit (configurable), a common
industry convention -- confirm against the project's sign-off definition.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def coverage(m: dict, pd_credit: float = 0.5):
    total = m["total"]
    ut = m.get("untestable", 0)
    det = m["detected"] + pd_credit * m.get("possibly_detected", 0)
    fc = 100.0 * det / total if total else 0.0
    tc = 100.0 * det / (total - ut) if total - ut > 0 else 0.0
    return round(tc, 3), round(fc, 3)


def parse_report(text: str) -> dict:
    """Extract coverage lines of the form 'test coverage   98.76%' per fault model section."""
    out = {}
    model = None
    for line in text.splitlines():
        lm = re.search(r"fault\s+(?:type|model)\s*[:=]?\s*(stuck|transition)", line, re.I)
        if lm:
            model = "stuck_at" if lm.group(1).lower() == "stuck" else "transition"
        m = re.search(r"test\s+coverage\s*[:=]?\s*([\d.]+)\s*%", line, re.I)
        if m and model:
            out.setdefault(model, {})["test_coverage"] = float(m.group(1))
        m = re.search(r"fault\s+coverage\s*[:=]?\s*([\d.]+)\s*%", line, re.I)
        if m and model:
            out.setdefault(model, {})["fault_coverage"] = float(m.group(1))
    return out


def gate(summary: dict, targets: dict, pd_credit: float = 0.5):
    rows, ok = [], True
    for model, m in summary["fault_models"].items():
        if "test_coverage" in m:
            tc, fc = m["test_coverage"], m.get("fault_coverage")
        else:
            tc, fc = coverage(m, pd_credit)
        tgt = targets.get(model)
        passed = tgt is None or tc >= tgt
        ok &= passed
        rows.append({"model": model, "test_coverage": tc, "fault_coverage": fc, "target": tgt,
                     "result": "PASS" if passed else "FAIL"})
    return ok, rows


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--summary", help="tool-neutral summary JSON")
    ap.add_argument("--from-report", help="raw ATPG report text")
    ap.add_argument("--pd-credit", type=float, default=0.5)
    args = ap.parse_args(argv)
    intf = json.load(open(os.path.join(HERE, "atpg_interface.json")))
    targets = {k: v["target_test_coverage_pct"] for k, v in intf["fault_models"].items()
               if isinstance(v, dict) and "target_test_coverage_pct" in v}
    if args.summary:
        summary = json.load(open(args.summary))
    elif args.from_report:
        summary = {"fault_models": parse_report(open(args.from_report).read())}
    else:
        ap.error("--summary or --from-report required")
    ok, rows = gate(summary, targets, args.pd_credit)
    for r in rows:
        print(f"{r['model']:<11} test coverage {r['test_coverage']:7.3f} %  target {r['target']} %  {r['result']}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
