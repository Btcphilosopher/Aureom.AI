#!/usr/bin/env python3
"""LBIST evaluation for the demonstration target (tc_lbist_demo_alu).

1. Synthesises the target to a generic gate netlist with Yosys/ABC.
2. Cross-checks the gate netlist against the bit-accurate Python model
   (sftestcore.models.demo_alu) on every applied pattern.
3. Bit-parallel single-stuck-at fault simulation (stem faults on every net)
   with the exact on-chip PRPG + phase-shifter patterns.
4. Reports coverage vs pattern count, the random-pattern-resistant faults,
   spatial-compaction masking (XOR folding 33->32 response bits) and MISR
   aliasing (exact, using MISR linearity), and confirms that the golden
   signature from the gate netlist equals the model signature written to
   LBIST_SIG_EXP.

Limitations (stated in the report): stem faults only (no fan-out branch
faults), undetected != untestable (no ATPG redundancy proof), static faults
only (no transition/delay faults), combinational target only.

Usage: lbist_eval.py [--patterns 4096] [--out docs/generated]
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "python"))

from sftestcore.models import (demo_alu, fold32, lbist_patterns, lbist_signature, misr_step)  # noqa: E402

GATES = {
    "$_NOT_": lambda a, m: ~a[0] & m, "$_BUF_": lambda a, m: a[0],
    "$_AND_": lambda a, m: a[0] & a[1], "$_NAND_": lambda a, m: ~(a[0] & a[1]) & m,
    "$_OR_": lambda a, m: a[0] | a[1], "$_NOR_": lambda a, m: ~(a[0] | a[1]) & m,
    "$_XOR_": lambda a, m: a[0] ^ a[1], "$_XNOR_": lambda a, m: ~(a[0] ^ a[1]) & m,
    "$_ANDNOT_": lambda a, m: a[0] & ~a[1] & m, "$_ORNOT_": lambda a, m: (a[0] | ~a[1]) & m,
    "$_MUX_": lambda a, m: (a[0] & ~a[2] & m) | (a[1] & a[2]),
}
PIN_ORDER = {"$_MUX_": ("A", "B", "S")}


def synth(work):
    src = os.path.join(ROOT, "rtl", "demo", "tc_lbist_demo_alu.sv")
    out = os.path.join(work, "alu_gates.json")
    script = (f"read_verilog -sv {src}; synth -top tc_lbist_demo_alu -flatten; "
              f"abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX; opt_clean; stat; write_json {out}")
    r = subprocess.run(["yosys", "-q", "-l", os.path.join(work, "yosys_alu.log"), "-p", script],
                       capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(r.stderr)
    return json.load(open(out))["modules"]["tc_lbist_demo_alu"]


class Netlist:
    def __init__(self, mod):
        self.inputs, self.outputs = {}, {}
        for pn, p in mod["ports"].items():
            (self.inputs if p["direction"] == "input" else self.outputs)[pn] = p["bits"]
        self.gates = []
        driver = {}
        for cn, c in mod["cells"].items():
            pins = PIN_ORDER.get(c["type"], ("A", "B"))
            ins = [c["connections"][p][0] for p in pins if p in c["connections"]]
            out = c["connections"]["Y"][0]
            self.gates.append((c["type"], ins, out))
            driver[out] = len(self.gates) - 1
        # topological order
        order, seen = [], set()
        pis = {b for bits in self.inputs.values() for b in bits}

        def visit(g):
            stack = [(g, 0)]
            while stack:
                gi, k = stack.pop()
                if gi in seen:
                    continue
                ins = self.gates[gi][1]
                if k < len(ins):
                    stack.append((gi, k + 1))
                    b = ins[k]
                    if not isinstance(b, str) and b not in pis and b in driver and driver[b] not in seen:
                        stack.append((driver[b], 0))
                else:
                    seen.add(gi)
                    order.append(gi)
        for i in range(len(self.gates)):
            visit(i)
        self.order = order
        self.nets = sorted(pis | {g[2] for g in self.gates})
        fan = {n: [] for n in self.nets}
        for gi in order:
            for b in self.gates[gi][1]:
                if not isinstance(b, str):
                    fan.setdefault(b, []).append(gi)
        self.fanout = fan
        self.pos = {gi: i for i, gi in enumerate(order)}

    def simulate(self, pi_vals, mask, fault=None, base=None):
        """pi_vals: {bit: int}. fault: (net, value) stuck-at. Returns net->int."""
        v = dict(base) if base is not None else dict(pi_vals)
        start = 0
        if fault is not None:
            net, sv = fault
            v[net] = mask if sv else 0
            # only gates in the transitive fan-out need re-evaluation; walk the topological order from
            # the first reader of the faulty net
            readers = [self.pos[g] for g in self.fanout.get(net, [])]
            if not readers:
                return v
            start = min(readers)
        for gi in self.order[start:]:
            t, ins, out = self.gates[gi]
            if fault is not None and out == fault[0]:
                continue
            a = [(mask if b == "1" else 0) if isinstance(b, str) else v[b] for b in ins]
            v[out] = GATES[t](a, mask)
        return v


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--patterns", type=int, default=4096)
    ap.add_argument("--seed", type=lambda x: int(x, 0), default=0xACE12026)
    ap.add_argument("--out", default=os.path.join(ROOT, "docs", "generated"))
    ap.add_argument("--work", default=os.path.join(ROOT, "build", "lbist"))
    ap.add_argument("--source", choices=["prpg", "random", "prpg68"], default="prpg",
                    help="prpg: on-chip 32-bit LFSR + phase shifter; random: ideal uniform patterns; "
                         "prpg68: what-if 68-bit LFSR feeding the inputs directly")
    args = ap.parse_args(argv)
    os.makedirs(args.work, exist_ok=True)
    os.makedirs(args.out, exist_ok=True)
    t0 = time.time()
    mod = synth(args.work)
    nl = Netlist(mod)
    N = args.patterns
    mask = (1 << N) - 1
    if args.source == "prpg":
        pats = list(lbist_patterns(args.seed, N))
    elif args.source == "random":
        import random
        rnd = random.Random(args.seed)
        pats = [rnd.getrandbits(68) for _ in range(N)]
    else:
        # what-if: 68-bit Fibonacci LFSR (taps 68,59 per the Xilinx XAPP052 table; maximality not
        # independently verified here) driving all 68 inputs directly -- full-rank input space
        st, pats, m68 = (args.seed | 1), [], (1 << 68) - 1
        for _ in range(N):
            pats.append(st)
            nb = ((st >> 67) ^ (st >> 58)) & 1
            st = ((st << 1) | nb) & m68
    # bit-parallel primary-input values
    pi = {}
    for name, off in (("a", 0), ("b", 32), ("op", 64)):
        for i, bit in enumerate(nl.inputs[name]):
            v = 0
            for k, p in enumerate(pats):
                v |= ((p >> (off + i)) & 1) << k
            pi[bit] = v
    good = nl.simulate(pi, mask)
    out_bits = nl.outputs["y"] + nl.outputs["zero"]          # response vector order {zero, y}
    # --- cross-check gate netlist against the Python model
    mism = 0
    for k, p in enumerate(pats):
        exp = demo_alu(p & 0xFFFFFFFF, (p >> 32) & 0xFFFFFFFF, (p >> 64) & 0xF)
        got = sum(((good[b] >> k) & 1) << j for j, b in enumerate(out_bits) if not isinstance(b, str))
        mism += exp != got
    n_sig = min(N, 1000)
    sig_gate = 0
    for k in range(n_sig):
        r = sum(((good[b] >> k) & 1) << j for j, b in enumerate(out_bits))
        sig_gate = misr_step(sig_gate, fold32(r, 33))
    sig_model = lbist_signature(args.seed, n_sig)

    # --- fault simulation
    faults = [(n, sv) for n in nl.nets for sv in (0, 1)]
    first_detect, folded_mask, alias = {}, 0, 0
    detected_1k, masked_by_fold, aliased = 0, [], []
    for f in faults:
        fv = nl.simulate(pi, mask, fault=f, base=good)
        diffs = [(fv[b] ^ good[b]) if not isinstance(b, str) else 0 for b in out_bits]
        any_d = 0
        for d in diffs:
            any_d |= d
        if not any_d:
            continue
        first_detect[f] = (any_d & -any_d).bit_length() - 1
        # compaction analysis over the first n_sig patterns (what the MISR sees)
        win = (1 << n_sig) - 1
        if any_d & win:
            detected_1k += 1
            lanes = [0] * 32
            for j, d in enumerate(diffs):
                lanes[j % 32] ^= d & win
            lane_or = 0
            for L in lanes:
                lane_or |= L
            if not lane_or:
                masked_by_fold.append(f)
                continue
            k0 = (lane_or & -lane_or).bit_length() - 1
            m = 0
            for k in range(k0, n_sig):
                e = 0
                if (lane_or >> k) & 1:
                    for L in range(32):
                        e |= ((lanes[L] >> k) & 1) << L
                m = misr_step(m, e)
            if m == 0:
                aliased.append(f)
    total = len(faults)
    curve = []
    for n in (32, 64, 128, 256, 512, 1000, 1024, 2048, 4096, 8192):
        if n > N:
            continue
        det = sum(1 for k in first_detect.values() if k < n)
        curve.append((n, det, 100.0 * det / total))
    undetected = [f for f in faults if f not in first_detect]
    late = sorted(((k, f) for f, k in first_detect.items()), reverse=True)[:10]

    def describe(net):
        for pn, bits in list(nl.outputs.items()) + list(nl.inputs.items()):
            if net in bits:
                return f"port {pn}[{bits.index(net)}]"
        for g in nl.gates:
            if g[2] == net:
                return f"{g[0][2:-1]} output (net {net})"
        return f"net {net}"
    und_kinds = Counter(describe(n).split(" output")[0] if "output" in describe(n) else describe(n).split("[")[0]
                        for n, _ in undetected)
    res = {
        "target": "tc_lbist_demo_alu", "seed": f"0x{args.seed:08X}", "patterns": N, "source": args.source,
        "gates": len(nl.gates), "nets": len(nl.nets), "faults_total": total,
        "netlist_vs_model_mismatches": mism,
        "signature_gate_netlist": f"0x{sig_gate:08X}", "signature_model": f"0x{sig_model:08X}",
        "coverage_curve": [{"patterns": n, "detected": d, "coverage_pct": round(c, 2)} for n, d, c in curve],
        "undetected_after_all": len(undetected),
        "undetected_by_location": dict(und_kinds.most_common(12)),
        "latest_first_detections": [{"pattern": k, "fault": f"{describe(f[0])} SA{f[1]}"} for k, f in late],
        "misr_window_patterns": n_sig, "detected_in_window": detected_1k,
        "masked_by_space_compaction": len(masked_by_fold), "aliased_in_misr": len(aliased),
        "theoretical_misr_aliasing": "2^-32 ~ 2.3e-10 per detected fault (uniform error model)",
        "runtime_s": round(time.time() - t0, 1),
    }
    json.dump(res, open(os.path.join(args.out, "lbist_evaluation.json"), "w"), indent=2)
    L = ["<!-- GENERATED by dft/lbist/lbist_eval.py -- DO NOT EDIT -->", "",
         "# LBIST evaluation results (demonstration target)", "",
         f"Target `tc_lbist_demo_alu` synthesised by Yosys/ABC to **{res['gates']} generic gates**, "
         f"{res['nets']} nets, **{total} single stuck-at faults** (stem faults on every net, both polarities). "
         f"Patterns: on-chip PRPG (32-bit LFSR, phase shifter) seed {res['seed']}.", "",
         "## Model correlation", "",
         f"* gate netlist vs Python reference model: **{mism} mismatches** over {N} patterns",
         f"* golden MISR signature ({n_sig} patterns): gate netlist {res['signature_gate_netlist']}, "
         f"model {res['signature_model']} -> {'MATCH' if sig_gate == sig_model else 'MISMATCH'} "
         "(the model signature is also matched by the RTL in tb_dft_iso and by RTL vector replay)", "",
         "## Stuck-at coverage vs pattern count (observed directly at the target outputs)", "",
         "| Patterns | Detected | Coverage |", "|---|---|---|"]
    L += [f"| {n} | {d} | {c:.2f} % |" for n, d, c in curve]
    L += ["", f"Undetected after {N} patterns: **{len(undetected)}** faults "
          f"({100.0 * len(undetected) / total:.2f} %). Locations:", "", "| Location | Faults |", "|---|---|"]
    L += [f"| {k} | {v} |" for k, v in und_kinds.most_common(12)]
    L += ["", "Hardest detected faults (latest first detection):", "", "| First detecting pattern | Fault |", "|---|---|"]
    L += [f"| {k} | {describe(f[0])} SA{f[1]} |" for k, f in late]
    L += ["", f"## Response compaction ({n_sig}-pattern window, the LBIST_PATTERNS value used by the flow)", "",
          f"* faults detected at the outputs in the window: {detected_1k}",
          f"* lost by spatial compaction (33->32 XOR fold cancels the error every cycle): **{len(masked_by_fold)}**",
          f"* lost by MISR aliasing (error stream maps to the zero signature): **{len(aliased)}**",
          f"* theoretical MISR aliasing bound: {res['theoretical_misr_aliasing']}", "",
          "## Limitations of these numbers", "",
          "* Stem faults only; fan-out branch faults and transition/delay faults are not modelled.",
          "* 'Undetected' is not 'untestable': no ATPG redundancy proof was run.",
          "* The target is combinational and observed through its primary outputs only; logic around it "
          "(input muxes, MISR, PRPG, the SoC) is covered by scan ATPG, not by this LBIST.",
          "* Generic-gate netlist from Yosys/ABC, not the foundry standard-cell netlist; coverage on the "
          "mapped netlist will differ.", ""]
    open(os.path.join(args.out, "lbist_evaluation.md"), "w").write("\n".join(L))
    print(json.dumps({k: res[k] for k in ("gates", "faults_total", "netlist_vs_model_mismatches",
                                          "undetected_after_all", "masked_by_space_compaction",
                                          "aliased_in_misr", "runtime_s")}))
    print("coverage:", [(c["patterns"], c["coverage_pct"]) for c in res["coverage_curve"]])
    return 0 if mism == 0 and sig_gate == sig_model else 1


if __name__ == "__main__":
    sys.exit(main())
