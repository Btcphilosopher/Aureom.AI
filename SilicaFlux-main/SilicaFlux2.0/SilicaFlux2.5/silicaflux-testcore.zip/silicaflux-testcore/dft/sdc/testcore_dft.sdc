# =============================================================================
# SilicaFlux TestCore :: DFT / mode-dependent timing constraints (template)
# Units: ns.  Port/pin names refer to tc_top; prefix with the integration
# hierarchy at chip level.  Values are PLACEHOLDERS pending library, PLL and
# I/O characterisation.  Not yet run through STA.
# =============================================================================

# ---- clocks -------------------------------------------------------------------
create_clock -name TCK      -period 100.0 [get_ports tck]          ;# 10 MHz JTAG (placeholder)
create_clock -name FUNC_CLK -period 10.0  [get_ports func_clk_i]   ;# 100 MHz SilicaFlux-V target
create_clock -name TEST_CLK -period 40.0  [get_ports test_clk_i]   ;# slow scan shift/capture
create_clock -name REF_CLK  -period 40.0  [get_ports ref_clk_i]

# root clock mux: functional and test clocks are mutually exclusive
set_clock_groups -physically_exclusive -group {FUNC_CLK} -group {TEST_CLK}
# all crossings between these domains are synchronised (tc_sync / toggle handshake)
set_clock_groups -asynchronous -group {TCK} -group {FUNC_CLK TEST_CLK} -group {REF_CLK}

# ---- quasi-static test-mode signals (registered in the TCK domain) ---------------
# They change only during mode-entry/exit sequences while the affected logic is
# held in reset or clock-stopped.
set_false_path -from [get_cells -hier -filter "full_name =~ *u_mode/*_o_reg*"]
set_false_path -from [get_cells -hier -filter "full_name =~ *u_mode/clk_test_sel_reg*"]
set_false_path -from [get_cells -hier -filter "full_name =~ *u_mode/clk_stop_reg*"]

# ---- synchroniser first stages ---------------------------------------------------
set_false_path -to [get_cells -hier -filter "full_name =~ *tc_sync*/s_reg[0]*"]
# bridge payload/result registers are held stable by the toggle handshake
set_max_delay -datapath_only 10.0 -from [get_cells -hier -filter "full_name =~ *u_bridge/pl_*"]
set_max_delay -datapath_only 10.0 -from [get_cells -hier -filter "full_name =~ *u_bridge/res_*"]

# ---- TAP: falling-edge launched TDO / IR update ----------------------------------
set_output_delay -clock TCK -clock_fall -max 20.0 [get_ports tdo]
set_input_delay  -clock TCK -max 20.0 [get_ports {tms tdi}]

# ---- mode-specific analysis --------------------------------------------------------
# Functional mode: test mux select static 0
#   set_case_analysis 0 [get_pins -hier *u_root_mux/sel]
#   set_case_analysis 0 [get_pins -hier *dft_scan_mode*]
# Scan shift mode (separate STA mode/corner set):
#   set_case_analysis 1 [get_pins -hier *u_root_mux/sel]
#   set_case_analysis 1 [get_ports dft_scan_mode_o]
#   scan-enable is a pin-driven, multicycle-friendly signal: constrain its
#   arrival relative to TEST_CLK from the GPIO0 pad.
# Scan capture mode: as shift with scan_en = 0.
# Reset bypass muxes (tc_dft_mux2) select scan_rst_n in scan modes only.
