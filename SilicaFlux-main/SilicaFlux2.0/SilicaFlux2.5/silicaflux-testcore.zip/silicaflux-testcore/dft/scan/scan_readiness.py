#!/usr/bin/env python3
"""Scan-insertion readiness checks and scan-chain partition planning (Yosys-based).

This is a PRE-INSERTION design-rule screen, not a replacement for the DFT
rule checks (DRC) of a commercial scan-insertion/ATPG tool, which remain the
sign-off.  It answers early, on RTL: will this design accept full-scan, and
how should the chains be partitioned?

Checks
  P1  non-synthesizable / simulation-only constructs (initial, $display,
      $readmemh, #delays, $random) in RTL                       [pre-lint]
  S1  every flop clock is a primary input or a recognised DFT clock cell
      (tc_icg / tc_clk_mux2) output                               [ERROR]
  S2  every asynchronous set/reset is a primary input listed as test-
      controllable, or the output of a tc_dft_mux2 (scan reset bypass) [ERROR]
  S3  no latches outside library clock-gating cells               [ERROR]
  S4  no combinational loops (Yosys `check`)                      [ERROR]
  S5  no internal tri-states                                      [ERROR]
  S6  clock-gating cells: TE driven by the test-enable network     [WARN, waivable]
  S7  inferred memories (need macro + MBIST collar + ATPG model)  [INFO]
  S8  negative-edge flops (lock-up latch / chain ordering)        [INFO]
  S9  top module has primary outputs (otherwise nothing is observable) [ERROR]
Exclusions (non-scan by design, e.g. the TCK domain) and waivers come from a
JSON config with written justifications.  Output: Markdown + JSON report and a
balanced chain plan per clock domain/edge with a compression estimate.

Usage:
  scan_readiness.py --config dft/scan/scan_config_testcore.json --out build/dft
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import subprocess
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, "..", ".."))

DFT_CELLS = {"tc_icg": ("gclk", "CLK"), "tc_clk_mux2": ("clk_o", "CLK"), "tc_dft_mux2": ("y", "RST")}
FLOP_PREFIXES = ("$dff", "$adff", "$sdff", "$aldff", "$dffsr", "$_DFF", "$_SDFF")
PRELINT = [
    (re.compile(r"^\s*initial\b"), "initial block"),
    (re.compile(r"\$display|\$write|\$monitor"), "$display/$write in RTL"),
    (re.compile(r"\$readmem[hb]"), "$readmemh/$readmemb (memory initialisation)"),
    (re.compile(r"\$random|\$urandom"), "$random in RTL"),
    (re.compile(r"(?<![\w'])#\s*\d"), "#delay in RTL"),
    (re.compile(r"if\s*\(\s*!\s*\w*rst\w*\s*\|\|"),
     "async-reset branch also tests synchronous signals (e.g. `if (!rst_n || flush)`): not mappable to an "
     "async-reset flop; restructure as `if (!rst_n) ... else if (flush) ...`  [ERROR for synthesis]"),
]


def prelint(files, allow_files=()):
    out = []
    for f in files:
        if os.path.basename(f) in allow_files:
            continue
        in_ndef = 0
        for i, line in enumerate(open(f, encoding="utf-8", errors="replace"), 1):
            s = line.split("//")[0]
            if re.match(r"\s*`ifndef\s+SYNTHESIS", s):
                in_ndef += 1
            elif in_ndef and re.match(r"\s*`endif", s):
                in_ndef -= 1
            if in_ndef:
                continue
            for rx, what in PRELINT:
                if rx.search(s):
                    out.append({"check": "P1", "severity": "ERROR" if "[ERROR" in what else "WARN", "file": os.path.relpath(f, ROOT) if f.startswith(ROOT) else f,
                                "line": i, "msg": what})
    return out


def sanitize(path):
    """Analysis-only rewrites of constructs reported by P1 so the structural
    screen can still run: system tasks removed; `if (!rst_n || x)` reduced to
    `if (!rst_n)` (flop count, clock and reset structure are unchanged)."""
    t = open(path, encoding="utf-8").read()
    t2 = re.sub(r"\$(display|write|monitor)\s*\((?:[^;]|\n)*?\)\s*;", ";", t)
    t2 = re.sub(r"if\s*\(\s*(!\s*\w*rst\w*)\s*\|\|[^)]*\)", r"if (\1)", t2)
    if t2 != t:
        open(path, "w", encoding="utf-8").write(t2)


def run_yosys(files, top, workdir, outjson):
    prep = os.path.join(workdir, "prep")
    r = subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "yosys_prep.py"), prep] + files,
                       capture_output=True, text=True, check=True)
    pfiles = r.stdout.split()
    for p in pfiles:
        sanitize(p)
    bb = " ".join(c for c in DFT_CELLS)
    srcdir = os.path.dirname(os.path.abspath(files[0]))
    log = os.path.join(workdir, "yosys.log")

    def yosys(keep):
        script = (f"read_verilog -sv {' '.join(pfiles)}; blackbox {bb}; hierarchy -top {top}; proc; flatten; "
                  + ("setattr -set keep 1 w:*; " if keep else "")
                  + f"opt_clean; memory -nomap; opt_clean; check; write_json {outjson}")
        r = subprocess.run(["yosys", "-q", "-l", log, "-p", script], cwd=srcdir, capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("yosys failed:\n" + r.stdout[-2000:] + r.stderr[-2000:])
        return json.load(open(outjson))

    net = yosys(False)
    mod = net["modules"][top]
    if not any(p["direction"] == "output" for p in mod["ports"].values()):
        net = yosys(True)          # nothing observable: keep logic so the structure can be screened
    loops = [l.strip() for l in open(log, encoding="utf-8", errors="replace") if "logic loop" in l.lower()]
    return net, loops


def analyse(netlist, top, cfg):
    mod = netlist["modules"][top]
    drivers = {}
    port_of = {}
    for pname, p in mod["ports"].items():
        for i, b in enumerate(p["bits"]):
            if p["direction"] == "input":
                drivers[b] = ("PORT", pname, i)
            port_of[b] = pname
    for cname, c in mod["cells"].items():
        dirs = c.get("port_directions", {})
        for pn, bits in c["connections"].items():
            if dirs.get(pn) == "output":
                for i, b in enumerate(bits):
                    drivers[b] = ("CELL", cname, c["type"], pn)
    names = {}
    for nn, n in mod["netnames"].items():
        if n.get("hide_name"):
            continue
        for i, b in enumerate(n["bits"]):
            names.setdefault(b, f"{nn}[{i}]" if len(n["bits"]) > 1 else nn)

    def desc(bit):
        if isinstance(bit, str):
            return f"constant {bit}"
        d = drivers.get(bit)
        if d is None:
            return "undriven"
        if d[0] == "PORT":
            return f"port {d[1]}"
        return f"{d[2]} {d[1]}.{d[3]}"

    if not any(p["direction"] == "output" for p in mod["ports"].values()):
        pre_findings = [{"check": "S9", "severity": "ERROR", "cell": top,
                         "msg": "top module has no primary outputs: every flop is unobservable and synthesis "
                                "removes the design (analysis kept it with keep attributes)"}]
    else:
        pre_findings = []
    excl_clocks = set(cfg.get("exclude_clock_ports", []))
    excl_prefix = tuple(cfg.get("exclude_instance_prefixes", []))
    rst_ok_ports = set(cfg.get("test_controllable_reset_ports", []))
    waivers = cfg.get("waivers", {})
    findings, domains, excluded = list(pre_findings), defaultdict(int), defaultdict(int)
    flop_bits = latch_bits = negedge_bits = mem_bits = 0

    def norm(cname, c):
        n = cname.replace("flatten\\", "").replace("\\", "")
        src = c.get("attributes", {}).get("src", "")
        src = src.split("|")[0]
        src = re.sub(r"^.*/", "", src)
        return n, src

    for cname0, c in mod["cells"].items():
        t = c["type"]
        cname, src = norm(cname0, c)
        if src and (cname.startswith("$") or "$" in cname):
            cname = f"{cname.split('.$')[0] if '.$' in cname else ''}{'.' if '.$' in cname else ''}@{src}".lstrip(".")
        if t.startswith(FLOP_PREFIXES):
            w = int(c["parameters"].get("WIDTH", "1"), 2) if "WIDTH" in c["parameters"] else 1
            flop_bits += w
            clk = c["connections"].get("CLK", c["connections"].get("C", [None]))[0]
            pol = int(c["parameters"].get("CLK_POLARITY", "1"), 2) if "CLK_POLARITY" in c["parameters"] else 1
            d = drivers.get(clk) if not isinstance(clk, str) else None
            # clock classification
            if d and d[0] == "PORT":
                dom = d[1]
            elif d and d[0] == "CELL" and d[2] in ("tc_icg", "tc_clk_mux2"):
                dom = f"{d[2]}:{d[1]}"
            else:
                dom = None
            inst_excl = any(cname.startswith(p) for p in excl_prefix)
            if (d and d[0] == "PORT" and d[1] in excl_clocks) or inst_excl:
                excluded[dom or "?"] += w
                continue
            if dom is None:
                findings.append({"check": "S1", "severity": "ERROR", "cell": cname,
                                 "msg": f"flop clock driven by {desc(clk)} (not a primary input or DFT clock cell)"})
                dom = f"UNCONTROLLED:{desc(clk)}"
            if not pol:
                negedge_bits += w
                findings.append({"check": "S8", "severity": "INFO", "cell": cname, "msg": "negative-edge flop"})
            # async reset classification
            for rp in ("ARST", "SET", "CLR", "AD"):
                if rp in c["connections"]:
                    for rb in set(map(str, c["connections"][rp])):
                        rbit = int(rb) if rb.isdigit() else rb
                        rd = drivers.get(rbit) if isinstance(rbit, int) else None
                        ok = (rd and rd[0] == "PORT" and rd[1] in rst_ok_ports) or \
                             (rd and rd[0] == "CELL" and rd[2] == "tc_dft_mux2")
                        if not ok:
                            key = f"S2:{cname}"
                            sev = "WAIVED" if any(cname.find(k) >= 0 for k in waivers.get("S2", {})) else "ERROR"
                            findings.append({"check": "S2", "severity": sev, "cell": cname,
                                             "msg": f"async {rp} driven by {desc(rbit)} (not test-controllable)"})
                        break
            domains[(dom, "pos" if pol else "neg")] += w
        elif t in ("$dlatch", "$adlatch", "$dlatchsr", "$_DLATCH_P_", "$_DLATCH_N_"):
            w = int(c["parameters"].get("WIDTH", "1"), 2) if "WIDTH" in c["parameters"] else 1
            latch_bits += w
            findings.append({"check": "S3", "severity": "ERROR", "cell": cname, "msg": "latch outside clock-gating cell"})
        elif t == "$tribuf":
            findings.append({"check": "S5", "severity": "ERROR", "cell": cname, "msg": "internal tri-state"})
        elif t.startswith("$mem"):
            size = int(c["parameters"].get("SIZE", "0"), 2)
            width = int(c["parameters"].get("WIDTH", "0"), 2)
            mem_bits += size * width
            findings.append({"check": "S7", "severity": "INFO", "cell": cname,
                             "msg": f"inferred memory {size}x{width} ({size * width} bits): small arrays may stay as "
                                    "flops (then they are scan flops); otherwise compiler macro + MBIST collar + ATPG model"})
        elif t == "tc_icg":
            te = c["connections"].get("te", [None])[0]
            if isinstance(te, str):
                sev = "WAIVED" if cname in "".join(waivers.get("S6", {})) or any(k in cname for k in waivers.get("S6", {})) else "WARN"
                findings.append({"check": "S6", "severity": sev, "cell": cname,
                                 "msg": f"ICG TE tied to constant {te}" + (f" -- waiver: {next(v for k, v in waivers['S6'].items() if k in cname)}" if sev == "WAIVED" else "")})
    for f in findings:
        if f["check"] == "S2" and f["severity"] == "WAIVED":
            k = next(k for k in waivers["S2"] if k in f["cell"])
            f["msg"] += f" -- waiver: {waivers['S2'][k]}"
    return {"flop_bits": flop_bits, "latch_bits": latch_bits, "negedge_bits": negedge_bits, "memory_bits": mem_bits,
            "domains": {f"{k[0]} ({k[1]}edge)": v for k, v in sorted(domains.items(), key=lambda x: -x[1])},
            "excluded": dict(excluded), "findings": findings}


def chain_plan(domains, max_len, channels):
    plan = []
    total_chains = 0
    for dom, bits in domains.items():
        n = max(1, math.ceil(bits / max_len))
        base, extra = divmod(bits, n)
        lens = [base + (1 if i < extra else 0) for i in range(n)]
        plan.append({"domain": dom, "bits": bits, "chains": n, "lengths": lens})
        total_chains += n
    longest = max((max(p["lengths"]) for p in plan), default=0)
    return {"max_chain_length_target": max_len, "internal_chains": total_chains, "longest_chain": longest,
            "external_channels": channels,
            "compression_ratio": round(total_chains / channels, 2) if channels else None,
            "uncompressed_shift_cycles_per_pattern": math.ceil(sum(p["bits"] for p in plan) / max(channels, 1)),
            "compressed_shift_cycles_per_pattern": longest,
            "domains": plan}


def write_report(res, plan, prel, loops, cfg, path_md, path_json):
    errors = [f for f in res["findings"] if f["severity"] == "ERROR"] + \
             [{"check": "S4", "severity": "ERROR", "cell": "-", "msg": l} for l in loops] + \
             [p for p in prel if p["severity"] == "ERROR"]
    data = {"design": cfg["name"], "top": cfg["top"], "summary": {
        "flop_bits": res["flop_bits"], "excluded_bits": sum(res["excluded"].values()),
        "scan_eligible_bits": sum(res["domains"].values()), "inferred_memory_bits": res["memory_bits"],
        "latch_bits": res["latch_bits"],
        "negedge_bits": res["negedge_bits"], "errors": len(errors),
        "warnings": sum(1 for f in res["findings"] if f["severity"] == "WARN") +
                    sum(1 for p in prel if p["severity"] == "WARN"),
        "waived": sum(1 for f in res["findings"] if f["severity"] == "WAIVED")},
        "domains": res["domains"], "excluded": res["excluded"], "chain_plan": plan,
        "findings": res["findings"] + [{"check": "S4", "severity": "ERROR", "cell": "-", "msg": l} for l in loops],
        "prelint": prel}
    os.makedirs(os.path.dirname(path_json), exist_ok=True)
    json.dump(data, open(path_json, "w"), indent=2)
    s = data["summary"]
    L = [f"# Scan readiness report: {cfg['name']} (top `{cfg['top']}`)", "",
         "Generated by `dft/scan/scan_readiness.py` (Yosys netlist analysis).  This is a pre-insertion screen; "
         "the commercial DFT tool's DRC is the sign-off.", "",
         "| Metric | Value |", "|---|---|"]
    for k, v in s.items():
        L.append(f"| {k} | {v} |")
    L += ["", f"**Result: {'READY (no unwaived errors)' if s['errors'] == 0 else 'NOT READY'}**", "",
          "## Scan-eligible flops by clock domain", "", "| Domain | Bits |", "|---|---|"]
    L += [f"| {d} | {b} |" for d, b in res["domains"].items()]
    L += ["", "## Excluded (non-scan by design)", "", "| Clock / instance | Bits | Justification |", "|---|---|---|"]
    for d, b in res["excluded"].items():
        L.append(f"| {d} | {b} | {cfg.get('exclusion_justification', '')} |")
    L += ["", "## Chain plan", "",
          f"Target maximum chain length {plan['max_chain_length_target']}; {plan['internal_chains']} internal chains; "
          f"{plan['external_channels']} external scan channels; compression ratio ~{plan['compression_ratio']}x; "
          f"shift cycles per pattern {plan['uncompressed_shift_cycles_per_pattern']} (no compression) vs "
          f"{plan['compressed_shift_cycles_per_pattern']} (with decompressor/compactor).", "",
          "| Domain | Bits | Chains | Lengths |", "|---|---|---|---|"]
    for p in plan["domains"]:
        L.append(f"| {p['domain']} | {p['bits']} | {p['chains']} | {', '.join(map(str, p['lengths']))} |")
    L += ["", "## Findings", "", "| Check | Severity | Cell / file | Message |", "|---|---|---|---|"]
    agg = defaultdict(list)
    for f in data["findings"]:
        agg[(f["check"], f["severity"], f["msg"])].append(f["cell"])
    for (chk, sev, msg), cells in sorted(agg.items()):
        shown = ", ".join(c.lstrip("\\$") for c in cells[:3]) + (f" (+{len(cells) - 3} more)" if len(cells) > 3 else "")
        L.append(f"| {chk} | {sev} | {shown} | {msg} |")
    for p in prel:
        L.append(f"| P1 | {p['severity']} | {p['file']}:{p['line']} | {p['msg']} |")
    open(path_md, "w").write("\n".join(L) + "\n")
    return data


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", required=True)
    ap.add_argument("--out", default=os.path.join(ROOT, "build", "dft"))
    ap.add_argument("--src-root", default=ROOT, help="base directory for relative file paths in the config")
    args = ap.parse_args(argv)
    cfg = json.load(open(args.config))
    files = [f if os.path.isabs(f) else os.path.join(args.src_root, f) for f in cfg["files"]]
    work = os.path.abspath(os.path.join(args.out, cfg["name"]))
    os.makedirs(work, exist_ok=True)
    prel = prelint(files, cfg.get("prelint_allow_files", []))
    net, loops = run_yosys(files, cfg["top"], work, os.path.join(work, "netlist.json"))
    res = analyse(net, cfg["top"], cfg)
    plan = chain_plan(res["domains"], cfg.get("max_chain_length", 200), cfg.get("scan_channels", 2))
    data = write_report(res, plan, prel, loops, cfg, os.path.join(work, "scan_readiness.md"),
                        os.path.join(work, "scan_readiness.json"))
    s = data["summary"]
    print(f"{cfg['name']}: flops={s['flop_bits']} eligible={s['scan_eligible_bits']} excluded={s['excluded_bits']} "
          f"errors={s['errors']} warnings={s['warnings']} waived={s['waived']} -> {work}/scan_readiness.md")
    return 0 if s["errors"] == 0 or cfg.get("expect_errors") else 1


if __name__ == "__main__":
    sys.exit(main())
