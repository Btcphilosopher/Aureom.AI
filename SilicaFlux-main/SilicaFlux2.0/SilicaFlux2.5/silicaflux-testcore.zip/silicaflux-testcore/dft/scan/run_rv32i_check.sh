#!/usr/bin/env bash
# Scan-readiness screen of the SilicaFlux-V CPU candidate (RV32I core in
# SilicaFlux-main/RISC-V CPU.zip).  The archive is extracted to build/ only.
set -euo pipefail
cd "$(dirname "$0")/../.."
ZIP="../RISC-V CPU.zip"
DST=build/src/rv32i
rm -rf "$DST"; mkdir -p "$DST"
unzip -q -o "$ZIP" -d "$DST"
python3 dft/scan/scan_readiness.py --config dft/scan/scan_config_rv32i.json --src-root "$DST" --out build/dft
