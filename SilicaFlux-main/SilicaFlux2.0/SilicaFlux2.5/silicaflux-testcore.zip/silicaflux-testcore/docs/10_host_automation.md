# 10. Python test automation (`python/sftestcore`, CLI `sftc`)

## Layers

```
spec.py        single-source spec loader (JSON): codes, registers, permissions, March encoding
jtag.py        TAP state model, BFS TMS paths, scan API (JtagDriver), BitBangJtag, SvfWriter (SVF tee)
transports/    sim.py       software device model (TAP, TDRs, modes, registers, MBIST/LBIST/debug, faults)
               recorder.py  TCK vectors with expected TDO -> RTL replay (tb_vector_replay)
               ftdi_mpsse.py FT2232H/FT232H MPSSE (pyftdi)          [unit-tested, not hardware-validated]
               openocd.py   OpenOCD TCL-RPC (any OpenOCD adapter)   [unit-tested, not hardware-validated]
device.py      IDCODE/identity, TC_STATUS, mode request, unlock, register access with BUSY back-off
mbist.py       discovery, run, failure-log capture and decoding
debug.py       halt / resume / step, GPR & PC access, reset cause, error counters, clocks, trace; LBIST
flows.py       production / bring-up flow (doc 09 §9.6)
testlog.py     sessions, CSV/JSON writers, summary, soft/hard binning
cli.py         sftc run | idcode | mbist | bsdl
```

## Supported adapters

| Transport | Use | Status |
|---|---|---|
| `sim` | no hardware; development, CI, vector generation | verified against RTL (vector replay) |
| `ftdi` | FT2232H/FT232H (ADBUS0 TCK, 1 TDI, 2 TDO, 3 TMS, 4 TRST*) via `pyftdi` | MPSSE command encoding and bit unpacking unit-tested with a byte-level fake; **not yet run on hardware** |
| `openocd` | any adapter OpenOCD supports; `dft/openocd/silicaflux_v.cfg` | TCL-RPC framing and >32-bit field splitting unit-tested with a fake server; **not yet run on hardware**; OpenOCD does not return IR capture, so that one check is SKIPped |

## Quick start

```bash
cd python
python3 -m sftestcore run --transport sim --out ../logs/run1
```

```bash
python3 -m sftestcore run --transport sim --inject 2:SA1:300:70 --extended --out ../logs/run2
```

```bash
python3 -m sftestcore run --transport sim --vectors ../build/flow.vec --svf ../build/flow.svf
```

```bash
python3 -m sftestcore run --transport ftdi --ftdi-url ftdi://ftdi:2232h/1 --tck-hz 1e6 --unlock-key 0123456789ABCDEF
```

```bash
python3 -m sftestcore idcode --transport openocd --openocd-port 6666
```

Faults for the simulator: `MEM:TYPE:ADDR:BIT[:ADDR2:BIT2[:DRF]]` with TYPE in SA0, SA1, TF_UP, TF_DOWN, AF,
CFID, DRF, COL_SA0 (the same models as `tb/models/tc_sram_model.sv`; the replay test passes the same
fault to the RTL with plusargs).

## Library use

```python
from sftestcore.jtag import BitBangJtag
from sftestcore.transports.sim import SimTransport
from sftestcore.device import TestCoreDevice
from sftestcore.mbist import Mbist

dev = TestCoreDevice(BitBangJtag(SimTransport()))
dev.reset()
print(dev.identity())                      # IDCODE fields, silicon revision, ECID
dev.enter_mode("MEMORY_BIST")              # raises AccessDenied with the mode error otherwise
res = Mbist(dev).run("MARCH_C_MINUS")      # discovery, start, wait, failure log
dev.mode_request("NORMAL")
```

## Logs

Per device: `session_<id>.json` (schema `sftestcore.session/1`: device identity, every step with
status, duration, measurements and captured failures, summary with soft/hard bin). Per lot (appended):
`lot_steps.csv` (one row per step) and `lot_failures.csv` (one row per MBIST failure: memory, element,
op, address, syndrome, failing bits). Examples: `logs/examples/` (a passing device, an L2 stuck-at-1
device, a PROD-lifecycle device that required unlock).

Soft bins: 1 good, 2 TAP/ID, 3 registers/security, 4 clock/reset, 5 MBIST (no repair), 6 LBIST,
7 debug, 9 infrastructure error (retest). Hard bins: 1 good, 2 logic/infra fail, 3 memory fail, 9 retest.
These numbers are a proposal for the SilicaFlux-V test program, not an ATE vendor convention.

## Recording and validation

* `VectorRecorder` writes `tms tdi expected_tdo` per TCK (`x` outside Shift states or where the caller
  masks non-deterministic bits — PCs, counters, measured frequency, progress fields).
* `SvfWriter` writes the same session as SVF (SIR/SDR with TDO and MASK, RUNTEST) for third-party JTAG
  tools and ATE conversion.
* `python/tests/test_rtl_replay.py` runs the complete production flow three ways (good device, PROD
  lifecycle with unlock, injected L2 fault with extended MBIST), records vectors and replays them on
  the RTL with Icarus: every compared TDO bit matches.
