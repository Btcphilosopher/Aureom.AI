# 7. ATPG workflow

> **No ATPG has been run.** There is no scan-inserted gate netlist, no foundry library and no ATPG
> licence in this environment. Every coverage number below is a **proposed engineering target**, not a
> result. The commercial-tool scripts are **unvalidated examples**.

## 7.1 Targets (proposed)

| Fault model | Proposed target (test coverage) | Prerequisite |
|---|---|---|
| Stuck-at | **≥ 99 %** | scan-inserted netlist, compression, memory models |
| Transition | **≥ 95 %** | at-speed launch/capture via an OCC (not in TestCore v0.1); LOC recommended |

Definitions: *test coverage* = detected / (total − untestable classes per tool); *fault coverage* =
detected / total; possibly-detected credited at 50 % unless the sign-off definition says otherwise.
Both are reported by `dft/atpg/coverage_gate.py`.

## 7.2 Tool-independent interface

`dft/atpg/atpg_interface.json` captures everything the ATPG engineer needs from the design side:

* test access: JTAG entry into SCAN_TEST (TC_UNLOCK if required, TC_MODE ← 4, ≥16 TCK idle, TAP parked
  in Run-Test/Idle with TMS=0, TCK=0); production ATPG runs in TEST lifecycle (SCAN_TEST is permanently
  denied in PROD);
* pins: scan-enable GPIO0, scan-reset GPIO1, scan-in GPIO2/3, scan-out GPIO4/5, test clock CLK_IN,
  REF_CLK, constrained and masked pins;
* clocks, off-states, shift period; chain plan source; compression requirement;
* excluded logic with coverage-credit method; fault models and targets; pattern formats and the
  validation sequence.

## 7.3 Generated collateral (`make atpg` → `dft/atpg/generated/`)

| File | What | Validated? |
|---|---|---|
| `enter_scan_test.svf`, `.vec` | the exact SCAN_TEST entry sequence produced by the host software on the device model | **yes** — replayed on the RTL, 0 mismatches (regression) |
| `silicaflux_v.testproc` | Tessent-style test procedures (timeplate, test_setup with the 107-cycle TAP sequence, shift, load_unload) | no (example) |
| `silicaflux_v_setup.spf` | STIL procedure file (TestMAX style) with the same test_setup | no (example) |
| `tessent_atpg.dofile`, `testmax_atpg.tcl` | ATPG run scripts (stuck-at; transition stubbed until OCC) | no (examples) |
| `fault_exclusions.txt` | tool-neutral exclusion list with justification and credit method | n/a |

## 7.4 Flow

1. RTL freeze → readiness screen clean (`dft/scan/scan_readiness.py`, 0 unwaived errors).
2. Synthesis with the foundry library; scan insertion + compression (commercial tool) using the
   exclusions and the chain plan; DFT DRC must be clean.
3. Build the ATPG model with library + memory models; apply `test_setup` from §7.3.
4. Stuck-at ATPG → coverage report → **untestable-logic analysis** (7.5) → test points if needed → iterate.
5. Transition ATPG after OCC integration.
6. **Pattern validation** (7.6).
7. Convert STIL to the ATE format; chain test first on silicon.
8. Gate the release with `coverage_gate.py` (targets from the interface file).

## 7.5 Fault exclusions and untestable-logic analysis

* Excluded by design: TCK domain (credit by fault-simulating JTAG/BSDL compliance patterns),
  clock-stop synchroniser, POR/PLL/analog.
* Constraint-induced untestables: TAP pins constrained, static test-mode registers, deselected
  functional-clock branch — expected and reviewed.
* Every remaining undetected class (UT/TI/BL/RE/AU/aborted) is mapped to RTL hierarchy and given a
  disposition: test point, constraint change, functional/JTAG credit, or a written waiver
  (`fault_waivers.csv`, owner + justification, re-reviewed per netlist release).

## 7.6 Pattern validation

* Serial (chain-shift) zero-delay simulation of a sample, parallel-load simulation of all patterns.
* SDF timing simulation at min and max corners for a sample (shift and capture).
* ATE conversion check; first silicon: chain-integrity (flush) test before any ATPG pattern.
* TestCore already applies the same principle to JTAG: host-flow vectors are replayed against the RTL
  bit-for-bit (doc 11).
