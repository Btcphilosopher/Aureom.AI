# 9. Production-test interface: test modes and access control

Generated tables (codes, lifecycle decode, permission matrix, reset policy, error codes):
**[generated/mode_permissions.md](generated/mode_permissions.md)**.

## 9.1 Modes

| Mode | Code | Entered by | System | Pins | Purpose |
|---|---|---|---|---|---|
| NORMAL | 0 | reset, TLR, exit request | running | functional | mission mode; IDCODE/BYPASS/SAMPLE allowed |
| JTAG | 1 | loading EXTEST / CLAMP / HIGHZ (never via TC_MODE) | held in reset | BSR-controlled | board interconnect test |
| MEMORY_BIST | 2 | TC_MODE (permission) | held in reset; collars switched to MBIST | GPIO0/1 = done/fail | memory test |
| LOGIC_TEST | 3 | TC_MODE (permission) | held in reset; LBIST mux engaged | GPIO0/1 = done/pass | logic BIST |
| SCAN_TEST | 4 | TC_MODE (permission), 16-TCK clock sequence | resets/clock from pins; TestCore system state reset on entry and exit | GPIO0–5 scan | ATPG |
| DIAGNOSTIC | 5 | TC_MODE (permission) | running (unless halted) | functional | silicon debug |

## 9.2 State machine

```mermaid
stateDiagram-v2
    [*] --> NORMAL : POR / TRST*
    NORMAL --> ENTER : TC_MODE(m) & permitted(lc,unlocked,m)
    ENTER --> MEMORY_BIST : 16 TCK
    ENTER --> LOGIC_TEST : 16 TCK
    ENTER --> SCAN_TEST : 16 TCK (stop clk, switch at 8)
    ENTER --> DIAGNOSTIC : 16 TCK
    ENTER --> NORMAL : TLR / EXTEST / permission lost (ABORTED)
    MEMORY_BIST --> NORMAL : TC_MODE(NORMAL) / TLR / permission lost / EXTEST
    LOGIC_TEST --> NORMAL : TC_MODE(NORMAL) / TLR / permission lost / EXTEST
    DIAGNOSTIC --> NORMAL : TC_MODE(NORMAL) / TLR / permission lost / EXTEST
    SCAN_TEST --> EXIT : TC_MODE(NORMAL) / TLR / permission lost / EXTEST
    EXIT --> NORMAL : 16 TCK (switch back at 4, ungate at 12)
    NORMAL --> JTAG : IR = EXTEST|CLAMP|HIGHZ
    JTAG --> NORMAL : IR = any non-invasive instruction (system reset released)
```
(An abort into JTAG passes through NORMAL in the next TCK.)

## 9.3 Transition rules (what makes combinations unambiguous)

1. **One mode register** in the TCK domain; decoded mode outputs are registered and one-hot.
2. Test modes are entered **only from NORMAL**; a request for another test mode while one is active is
   rejected (`ILLEGAL`) and changes nothing.
3. JTAG mode is entered only by the IR (as 1149.1 requires EXTEST to take effect); it forcibly aborts any
   active test mode (`ABORTED`) after unwinding the scan clock sequence if needed.
4. Every exit returns to NORMAL. Modes that hold the system in reset (JTAG, MEMORY_BIST, LOGIC_TEST,
   SCAN_TEST) leave it through a synchronised reset release, so the SoC never resumes from a test state.
5. Requests during an entry/exit sequence return `BUSY`; undefined codes and JTAG-via-TC_MODE return
   `ILLEGAL`; a wrong magic returns `BAD_MAGIC`; lifecycle/authorisation failures return `DENIED`.
6. Permission is re-checked every TCK: relock or lifecycle change aborts the mode.
7. Test-Logic-Reset and TRST* always return to NORMAL (1149.1 requires test logic to be inactive in TLR).
8. The CPU (APB) cannot request or influence modes.

## 9.4 Access control by mode (register classes)

| Class | NORMAL | MEMORY_BIST | LOGIC_TEST | DIAGNOSTIC | APB (CPU) |
|---|---|---|---|---|---|
| PUBLIC read | ✓ | ✓ | ✓ | ✓ | ✓ |
| DIAG read/write (debug, trace, PC) | – | – | – | ✓ (JTAG) | – |
| MBIST write | – | ✓ (JTAG) | – | – | – |
| LBIST write | – | – | ✓ (JTAG) | – | – |
| SYS_OR_DIAG write (reset cause, error clear, SW reset) | – | – | – | ✓ (JTAG) | ✓ |
| PUBLIC write (SCRATCH, MBIST_MEM_IDX) | ✓ | ✓ | ✓ | ✓ | ✓ |

## 9.5 Host timing requirements

* ≥ 16 TCK in Run-Test/Idle after a TC_MODE request (`mode_settle_tck`); the library uses 24.
* ≥ 8 TCK between TC_REG scans (assumes f_sys ≥ f_TCK/2); the library adapts on BUSY.
* SCAN_TEST: hold CLK_IN low until entry completes; park it low before requesting exit.
* TC_STATUS bits 15–22 are undefined in SCAN_TEST.

## 9.6 Typical production sequences (implemented in `sftestcore.flows.production_flow`)

1. TAP integrity: IR capture `…01`, single-device BYPASS, IDCODE (part, placeholder warning), TC_STATUS marker.
2. Identity: silicon revision, ECID, TestCore version; BSR length/integrity through SAMPLE/PRELOAD.
3. Register access (walking patterns) + one deliberately denied access (counter must increment).
4. Clock status and measurement (±2 %), reset cause = POR.
5. MBIST discovery against the expected registry; March C- on all memories with ROM signature
   (`--extended`: checkerboard and March SS on RAMs).
6. LBIST (golden signature computed by the host).
7. Debug access: halt, GPR write/read-back, single step (+4), resume.
8. Final state NORMAL; soft/hard bin assignment; JSON + CSV logs.
