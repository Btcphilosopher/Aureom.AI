# 4. Memory built-in self-test

Algorithms and backgrounds (generated): **[generated/mbist_algorithms.md](generated/mbist_algorithms.md)**.
Registers: `MBIST_*` in **[generated/register_map.md](generated/register_map.md)**.

## Architecture

```
 tc_mbist (one engine, system clock)               per memory
 ┌──────────────────────────────────┐   sel[i]    ┌───────────────────────────────┐
 │ registry (params) ── discovery    │────────────►│ tc_mbist_collar               │
 │ microcoded March sequencer        │ ce/we/addr/ │  bist_active → macro muxed to │
 │ address gen (up/down, any depth)  │ wdata       │  test port, f_ready = 0       │──► macro
 │ background gen (5 kinds)          │────────────►│  optional IN/OUT pipe stages  │
 │ expected-data pipeline (MAX_LAT)  │◄────────────│  scan bypass shadow register  │
 │ compare · syndrome · log · MISR   │  rdata[i]   └───────────────────────────────┘
 └──────────────────────────────────┘
```

Memories are tested **one at a time** (bounded peak test power; identical banks could be tested in
parallel as a later optimisation). The engine owns the memories only in MEMORY_BIST mode, during which
the system and the CPU are held in reset and every collar blocks functional access.

## Memory discovery and registration

Each memory is described at integration time by `tc_top` parameters and read back by the host:

| Field | Meaning |
|---|---|
| WIDTH | stored width incl. ECC/parity bits (so check bits are tested too) |
| MAXADDR | depth − 1; depths need not be powers of two |
| LATENCY | cycles from issue to read data at the engine, **including** collar and bus pipeline stages |
| TYPE | 0 SRAM 1RW, 1 SRAM 1R1W, 2 ROM |
| WR2RD_GAP | idle cycles required between a write and a read of the same address |

`MBIST_NUM_MEMS`, `MBIST_MEM_IDX`, `MBIST_MEM_INFO0/1`; the host (`Mbist.discover()`) checks them
against the expected product configuration.

## Test execution

* **Address generation**: ascending/descending per element; arbitrary depth.
* **Data backgrounds**: solid, logical checkerboard, row stripe, column stripe, user 32-bit (replicated).
  Logical ≠ physical: a physical checkerboard needs the compiler's address/bit scrambling (doc 13).
* **Algorithms**: March C- (10N), MATS+ (5N), March X (6N), March B (17N), March SS (22N), a
  retention variant with PAUSE elements, and a user-programmable algorithm (8 elements × up to 6 ops).
  An empty or undefined algorithm reports **FAIL**, as does an empty memory selection.
* **Real latency**: ops are issued back-to-back; each read's expected value, address, element and op
  index travel down a pipeline and are compared `LATENCY` cycles later. The pipeline is drained between
  memories.
* **Read-during-write**: the engine never issues a read and a write in the same cycle, so 1R1W
  read-during-write behaviour (compiler-specific, often undefined) is never relied upon.
* **Access restrictions**: a read that follows a write to the same address too closely is delayed by
  `WR2RD_GAP` idle cycles (covers compilers whose write data is not visible on the next cycle).
* **ROM**: one ascending read pass compacted into a 32-bit MISR (XOR-folded); compared with
  `MBIST_SIG_EXP` when `SIG_CHECK=1` (the host computes the expected signature from the ROM image).

## Results

* pass/fail, done, stopped (stop-on-first-fail), aborted (register or mode exit), per-memory fail mask,
  saturating fail count;
* failure log: first `LOG_DEPTH` (8) failures — memory, element, op index, address, **syndrome =
  expected XOR actual** (up to 96 bits); overflow flag;
* accumulated syndrome (OR of all syndromes) = failing-bit map, distinguishing column from cell faults;
* MBIST done/fail are also driven on GPIO0/1 in MEMORY_BIST for fast wafer-sort monitoring.

**Repair**: no redundancy, no repair analysis, no fuse programming. `CAPS.REPAIR` reads 0; failing
devices are binned out (soft bin 5). The log and bit map are the inputs a future repair flow needs.

## Verification (tb_mbist, 207 checks; tb_dft_iso; tb_debug; Python tests)

| Scenario | Result checked |
|---|---|
| Clean runs, 6 algorithms × all 5 memories (lat 1/2/3, 1R1W gap, ROM) | pass, ROM signature exact |
| 4 non-solid backgrounds | pass |
| SA0 L1I @17 b5 | 2 failures at exactly (elem 2, op 0) and (elem 4, op 0), syndrome bit 5 |
| SA1 L2 @300 b70 (72-bit, latency 3) | 3 failures, syndrome in SYND2 — proves latency alignment |
| Transition up / down | detected by March C-; **TF-down missed by MATS+** (known algorithm limit) |
| Address-decoder fault (10→20) | detected, first fail at address 20 |
| Idempotent coupling fault | detected by March C- |
| Data-retention fault | **missed by March C-, detected by RETENTION** (PAUSE elements) |
| Column fault | 512 failures counted, log overflow, bit map = column |
| Stop-on-fail, abort by register, abort by mode exit, START outside mode ignored | as specified |
| ROM corruption | signature mismatch flagged |
| User algorithm programmed as March C- | identical result to built-in |
| 1R1W registered **without** its required gap | March B **fails** — the restriction is real and the gap insertion is what makes the registered memory pass |

## Production note

The memoryflow project already states that a production flow normally uses the EDA vendor's MBIST at the
collar interface. TestCore's engine is synthesizable and verified, but a foundry/vendor MBIST with
compiler-aware scrambling, repair analysis and qualified algorithms remains the recommended production
path (doc 13); the collar/registry contract and host software are designed so that swap is local.
