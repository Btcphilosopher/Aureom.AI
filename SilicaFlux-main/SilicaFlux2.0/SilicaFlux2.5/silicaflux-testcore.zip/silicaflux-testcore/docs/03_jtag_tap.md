# 3. JTAG test access port

Instruction encodings, data-register layouts and IDCODE fields are generated from the spec:
**[generated/jtag_instructions.md](generated/jtag_instructions.md)**. This page explains behaviour.

> **Compliance status.** The TAP is written to follow IEEE 1149.1 as understood by the author and is
> verified against an independent reference model in simulation. It has **not** been compliance-tested
> (no BSDL compliance checker, no 1149.1 conformance suite, no silicon). Do not claim IEEE 1149.1
> compliance until that work (doc 13) is done.

## Controller

* 16-state controller clocked on the rising edge of TCK; TMS=1 for 5 TCKs reaches Test-Logic-Reset from
  any state; TRST* (ANDed with power-on reset) resets asynchronously.
* Capture and shift on the rising edge; IR parallel update and the BSR update stage on the **falling**
  edge in Update-IR / Update-DR; TDO launched on the falling edge and enabled only in Shift-IR/Shift-DR.
* Test-Logic-Reset loads IDCODE into the IR.
* Private data registers (TC_*) update on the rising edge that leaves Update-DR (no half-cycle paths);
  this is permitted because they are not 1149.1-defined registers.

## Public instructions

| Instruction | Behaviour |
|---|---|
| EXTEST (00000) | BSR selected; output pins driven from the update stage; output enables from control cells; input cells capture pins. **Invasive**: TestCore enters JTAG mode and holds the system in reset; the reset is released (synchronised) when a non-invasive instruction is loaded. |
| SAMPLE/PRELOAD (00001) | BSR selected; Capture samples pins, core outputs and enables; Update preloads the update stage. Non-invasive. 1149.1-2013 permits SAMPLE and PRELOAD to share an opcode. |
| IDCODE (00010) | 32-bit ID; default after reset. |
| CLAMP (00011) | Pins from the update stage, BYPASS selected. Invasive. |
| HIGHZ (00100) | All BSR-controlled drivers disabled, BYPASS selected. Invasive. |
| BYPASS (11111) and every unassigned code | 1-bit bypass, captures 0. |

INTEST and RUNBIST are not implemented (optional in 1149.1). Built-in self-test is reached through
private instructions instead, because it needs the lifecycle/authorisation gate.

## Boundary-scan register

Reference SilicaFlux-V pin set (spec `reference_pinout`): 3 inputs, 4 outputs, 8 GPIO → **35 cells**.
Cell 0 is nearest TDO. Inputs use observe-only BC_4 cells; outputs use BC_1 data + BC_1 control cells;
bidirectionals use BC_4 + BC_1 + BC_1. Update stages reset to 0 so an EXTEST issued before PRELOAD
cannot enable drivers. The BSDL template `dft/bsdl/silicaflux_v_testcore.bsd` is generated from the same
cell-order function as the RTL check and the Python simulator.

Pins *not* in the BSR: TAP pins (TCK/TMS/TDI/TDO/TRST*), CLK_IN, RST_N, supplies (declared `linkage`).
Placing observe-only cells on CLK_IN/RST_N is a decision for the pad-ring designer.

## IDCODE

`{version[31:28], part[27:12] = 0x5F10, manufacturer[11:1], 1}`. Version comes from metal-programmable
tie cells (`idcode_version_i`) so a metal ECO can bump it. **The manufacturer field is 0x000, a
deliberate placeholder**: a JEDEC JEP106 code must be obtained before tapeout (0x07F is forbidden by
1149.1). The host software reports the placeholder as a warning on every run.

## Private instructions

### TC_STATUS (01000, 32 bits, capture-only)
Mode, transition busy, last mode error, unlock/lockout/attempts, decoded lifecycle, and synchronised
system status (MBIST/LBIST busy/done/result, core halted, system in reset, register-bridge busy), plus
the constant marker 0xC5 in [31:24] to detect a stuck TDO or a wrong chain position. Bits 15–22 are
undefined during SCAN_TEST (system-domain logic is under ATPG control).

### TC_MODE (01001, 12 bits)
Write `{MAGIC=0xA, OPTS[3:0], 0, MODE[2:0]}` to request a mode; MAGIC=0 is a capture-only scan; other
magic values are rejected (BAD_MAGIC). Capture returns `{0, LAST_ERR, OPTS, BUSY, MODE}`. Allow ≥ 16 TCK
in Run-Test/Idle for an entry/exit sequence (`mode_settle_tck`). Rules: doc 09.

### TC_UNLOCK (01010, 64 bits)
Shift the 64-bit token; it is compared with the OTP key at Update-DR. All-zero relocks. Four failures
lock out until power-on reset (not TRST*). Capture returns attempts/unlocked/lockout. Security model: doc 08.

### TC_REG (01011, 46 bits) — register access
```
 45 44 | 43 ........ 32 | 31 ............ 0
  OP   |     ADDR       |       DATA
 write: OP 0 NOP, 1 READ, 2 WRITE, 3 CLEAR_BUSY
 capture: STATUS 0 OK, 2 ERROR (denied/unmapped), 3 BUSY; ADDR and DATA of the completed request
```
A request is launched at Update-DR and crosses to the system clock through a toggle handshake; its
result is returned by the next Capture-DR. Spend ≥ 8 TCK in Run-Test/Idle between scans (valid when
f_sys ≥ f_TCK/2). If a capture finds the request still in flight it returns BUSY and sets a sticky flag;
further requests are ignored until CLEAR_BUSY — the host can therefore always tell whether a request
was dropped. The host driver never re-issues an operation (non-idempotent writes such as STEP or START);
it backs off adaptively, clears BUSY and re-captures, and checks that the captured ADDR matches.

## Verification evidence

* `tb_tap_fsm`: independent reference table, all 32 (state, TMS) transitions, 4 000-step random walk,
  TLR from every state, TRST* from every state, strobes, TDO enable/edge (14 924 checks).
* `tb_tap_bsr`: IDCODE default, IR capture and length, BYPASS, unassigned opcode, SAMPLE, PRELOAD +
  EXTEST (drive and capture), CLAMP, HIGHZ, return to functional, TRST* during EXTEST.
* Host flows replayed against the RTL TDO bit-for-bit (doc 11).
