# 5. Logic BIST: investigation, implementation and evaluation

## Decision

| Question | Answer |
|---|---|
| Is LBIST needed for SilicaFlux-V **production** test? | **No.** Full-scan ATPG reaches higher coverage with far fewer patterns, and the prototype has no in-field self-test requirement. |
| Where is it justified? | (a) in-field/power-on self-test of non-critical datapaths (safety-style periodic test), (b) accelerator datapaths where ATE time matters, (c) as a demonstrator of the infrastructure. |
| What was implemented? | A **test-per-clock** LBIST wrapper (`rtl/tc_lbist.sv`) applied to a non-critical demonstration target — a 32-bit RV32I-style ALU (`rtl/demo/tc_lbist_demo_alu.sv`, 68 inputs / 33 outputs). It is reached only in LOGIC_TEST mode. |
| What was not implemented? | STUMPS (scan-based) LBIST. It needs the scan chains that only a scan-insertion tool can build, plus X-bounding and test points; it belongs to the commercial flow (doc 13). |

## Implementation

* PRPG: 32-bit maximal LFSR, Galois form, x³²+x²²+x²+x+1, seed register (0 → 1).
* Phase shifter: `in[i] = s[i%32] ^ s[(5i+3)%32] ^ s[(13i+7)%32]` (three distinct taps for every i, checked by test).
* Target inputs multiplexed to the PRPG only while LOGIC_TEST is active; system held in reset.
* MISR: 32-bit, same polynomial; 33 response bits XOR-folded into 32 lanes.
* Golden signature computed off-chip (`sftestcore.models.lbist_signature`) and written to `LBIST_SIG_EXP`;
  zero patterns never pass.
* Correlation chain: RTL signature = independent SV reference model (`tb_dft_iso`) = Python model
  (RTL vector replay) = Yosys gate netlist (`lbist_eval.py`, 0 mismatches over 4 096 patterns).

## Evaluation method (`dft/lbist/lbist_eval.py`)

Yosys/ABC maps the target to 1 631 generic gates; a bit-parallel single-stuck-at fault simulator
(3 398 stem faults) applies the exact on-chip patterns. Results: **[generated/lbist_evaluation.md](generated/lbist_evaluation.md)**.

## Results (4 096 patterns, seed 0xACE12026)

| Pattern source | 64 | 256 | 1 024 | 4 096 |
|---|---|---|---|---|
| **On-chip PRPG** (32-bit LFSR + phase shifter) | 81.49 % | 85.37 % | 85.46 % | **85.46 %** |
| What-if: 68-bit LFSR feeding the inputs directly | 75.78 % | 94.38 % | 95.44 % | 95.76 % |
| Ideal uniform random | 87.23 % | 94.11 % | 94.61 % | 95.62 % |

Reproduce: `python3 dft/lbist/lbist_eval.py --source {prpg|prpg68|random}`.

### Findings

1. **Pattern-source limitation (dominant).** The 68 phase-shifter outputs are linear functions of only
   32 LFSR state bits; their GF(2) rank is 32, so only 2³² of the 2⁶⁸ input combinations can ever be
   applied. Coverage saturates at 85.46 % after ~512 patterns — more patterns do not help. A PRPG at least
   as wide as the target's input count (or reseeding) recovers ~10 points.
2. **Random-pattern-resistant / possibly redundant faults (~4 %).** Even ideal random patterns stop
   near 95.6 %: 149 undetected faults, all on outputs of AND (62), NAND (68) and OR (19) gates — the
   signature of wide AND-type structures. Likely sites are opcode decode, zero detect and comparison
   paths, but they were **not traced back to RTL lines** in this evaluation. Closing them needs test
   points or deterministic top-up patterns; some may be redundant (only ATPG can prove that).
3. **Response compaction.** Within the 1 000-pattern window used by the production flow, 7 detected
   faults are masked by the 33→32 spatial XOR fold; **0** are lost to MISR aliasing (exact check using
   MISR linearity). The theoretical aliasing probability for a 32-bit MISR is ≈2⁻³² per fault.

### Coverage limitations (apply to every number above)

* Stem stuck-at faults only; no fan-out branch faults, no transition/delay faults.
* Undetected ≠ untestable; no redundancy proof.
* Generic-gate netlist, not the foundry standard-cell netlist.
* The target is combinational and observed only through its outputs; the input multiplexers, PRPG,
  MISR and the surrounding SoC are covered by scan ATPG, not by this LBIST.
* X-sources: none in this target; a real target needs X-bounding before MISR compaction.

## Recommendation

Keep LBIST as an optional, demonstration/in-field feature (`LBIST_EN` parameter). If adopted for a real
datapath: widen the PRPG to ≥ the target's input count (or use multiple seeds), insert observation test
points at the identified AND/NAND trees, compact without spatial folding (MISR ≥ output width), and
re-run this evaluation on the mapped netlist with branch and transition faults.
