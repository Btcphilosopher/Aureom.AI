# 6. Scan architecture and scan-insertion documentation

> **Scope statement.** TestCore provides synthesizable **DFT-preparation logic** (test-mode control,
> test-enable distribution, test-clock selection, reset bypass, isolation, scan pin muxing, memory scan
> bypass) and a **pre-insertion readiness screen**. It does **not** insert scan chains, map scan cells or
> generate patterns. Production scan insertion, scan-cell mapping, compression and ATPG must be done with
> foundry-supported commercial tools and the foundry library; a hand-written generic scan network does
> not replace that qualified flow.

## 6.1 Test-enable distribution

| Signal | Source | Meaning | Consumers |
|---|---|---|---|
| `dft_scan_mode_o` | TCK flop (`tc_mode_ctrl`), static | SCAN_TEST active (stable phase) | reset-bypass muxes, collar scan bypass, case analysis |
| `dft_scan_en_o` | `scan_mode AND GPIO0` pad (`tc_test_pinmux`) | shift (1) / capture (0) | scan flops (via insertion tool) |
| `dft_cg_te_o` | = `dft_scan_en_o` | forces every ICG on during shift; capture exercises functional enables | all `tc_icg`/library ICG TE pins |
| `dft_scan_cfg_o[3:0]` | TC_MODE OPTS, only in SCAN_TEST | [0] compression bypass, [1] OCC at-speed enable, [2] single-chain diagnosis | decompressor/OCC IP |
| scan reset | GPIO1 pad in SCAN_TEST | direct ATPG control of every reset | `tc_rst_sync` / `tc_dft_mux2` |

Outside SCAN_TEST, `scan_en`, `cg_te` and scan reset are forced inactive regardless of pin activity
(test-mode isolation; continuously monitored in `tb_dft_iso`).

## 6.2 Scan clock planning

* SCAN_TEST uses a slow external test clock on **CLK_IN**: the root mux (`tc_clk_mux2`) selects it
  after the functional clock has been stopped by an ICG whose enable is synchronised to the functional
  clock. Sequence (16 TCK): stop → switch at TCK 8 → stable; exit reverses (switch back at 4, ungate at
  12). The ATE must hold CLK_IN low until the sequence completes. `tb_rst_clk` shows zero runt pulses for
  the sequenced switch and detects the runt an unsequenced switch produces.
* The reference-clock monitor (7 flops) is a second scan clock domain (REF_CLK).
* TCK-domain logic is not scanned (6.4).
* **At-speed (transition) test** needs launch/capture pulses from the PLL through an On-Chip Clock
  controller (OCC). TestCore reserves `dft_scan_cfg_o[1]` for it but does **not** implement an OCC;
  this is commercial DFT IP (doc 13).
* Shift frequency, scan-enable timing and IR-drop limits are set from power analysis (Production Test
  plan §2 suggests tens of MHz with a safe-shift mode).

## 6.3 Reset handling

* Every reset synchroniser is `tc_rst_sync`: async assert, sync de-assert; in scan mode both its own
  async reset and its output come from the scan-reset pin through `tc_dft_mux2`.
* The clock-monitor reset is also DFT-muxed (found by the readiness screen, check S2, and fixed).
* The POR cell is analog IP outside this RTL; its output never reaches a scan flop except through a DFT mux.
* SCAN_TEST entry holds system and TestCore system-domain resets; exit releases them synchronously,
  so the SoC never runs on scan-loaded state (also a security property, doc 08).

## 6.4 Test-mode isolation and exclusions

* TCK domain (378 flops: TAP, IR, BSR, mode/unlock state, bridge TCK side) holds the test mode during
  scan and is **excluded** from scan; its coverage comes from JTAG/BSDL compliance patterns.
* `u_clk.u_stop_sync` (2 flops) is clock-control logic on the deselected branch — excluded.
* Functional pins are free-running in scan (ATPG sees them as PIs/POs); GPIO0..5 are dedicated to
  scan; GPIO6/7 drivers are disabled.
* Memories: black-boxed; the collar's scan bypass (`f_rdata = shadow(f_wdata ^ f_addr)`) makes the
  surrounding logic controllable/observable. Commercial flows may use RAM-sequential ATPG models instead.

## 6.5 Clock-gating test controls

`tc_icg` is latch-based (enable sampled while CLK is low) with `gclk = clk & (en | te)`. TE = scan
enable: all gated clocks pulse during shift; during capture the functional enable path is tested.
The only ICG in TestCore with TE tied low is the functional-clock stop gate, which is on the branch
deselected in SCAN_TEST (written waiver S6). SoC ICGs must connect TE to `dft_cg_te_o`.

## 6.6 Scan-chain partitioning (measured on RTL)

`dft/scan/scan_readiness.py` — Yosys-based screen + balanced chain plan (target ≤150 flops/chain,
2 external channels). Full reports: [TestCore](generated/scan_readiness_testcore_demo.md),
[RV32I core](generated/scan_readiness_silicaflux_v_rv32i_core.md).

| Design | Flop bits | Scan-eligible | Excluded | Inferred memory bits | Errors | Chains | Longest | Compression |
|---|---|---|---|---|---|---|---|---|
| TestCore (`tc_top`, default 2-memory config) | 2 920 | 2 540 | 380 | 512 (trace buffer) | **0** (1 waiver) | 18 (17 + 1 REF_CLK) | 149 | ≈9× |
| SilicaFlux-V RV32I core (`RISC-V CPU.zip`) | 1 899 | 1 899 | 0 | 54 272 | **2** | 13 | 147 | ≈6.5× |

Partitioning rules used: one chain group per clock domain and edge (no lock-up latches needed inside a
group); balanced lengths; TCK domain excluded; memories outside the chains. For the full SilicaFlux-V
SoC, re-run the screen on the integrated top; chains are then mapped to the decompressor outputs.

RV32I blocking items (details in doc 01): no primary outputs; async-reset branch tests synchronous
flush signals (`rv32i_core.sv:273`); behavioural memories with `initial`/`$readmemh`/`$display`.

## 6.7 Compression compatibility

Two external channels (GPIO2/3 in, GPIO4/5 out) are designed to feed a decompressor/compactor
(EDT / DFTMAX-class). The TestCore side provides: static configuration bits (`dft_scan_cfg_o`), a bypass
option for chain diagnosis, scan-enable and scan-reset pins, and a clean, X-free memory boundary (collar
bypass). X-sources to manage at insertion: un-initialised memories (black boxes), the REF_CLK domain at
capture, and analog block outputs.

## 6.8 Checks performed by the readiness screen

P1 simulation-only constructs; S1 clocks from PIs or DFT clock cells; S2 async resets test-controllable;
S3 no latches outside ICGs; S4 no combinational loops; S5 no internal tri-states; S6 ICG TE connected;
S7 inferred memories; S8 negative-edge flops; S9 primary outputs exist. Exclusions and waivers are
written in `dft/scan/scan_config_*.json` with justifications.

## 6.9 Timing constraints

`dft/sdc/testcore_dft.sdc`: clocks (TCK, functional, test, reference), physically exclusive
functional/test clocks, asynchronous groups, false paths on quasi-static mode flops and synchroniser
first stages, bridge datapath-only constraints, TDO falling-edge output delay, and mode-specific
case-analysis templates for functional / shift / capture STA. Placeholder values until library and
PLL characterisation exist.
