# 11. Verification and manufacturing-readiness report

Latest automated results: **[generated/regression_results.md](generated/regression_results.md)**
(`python3 scripts/regress.py`; tool versions are recorded there). All numbers below come from that run.

## 11.1 Strategy

1. **Unit/block testbenches (SystemVerilog, Icarus 12)** with self-checking scoreboards and
   independently written reference models (TAP transition table, permission matrix, LBIST golden model,
   expected MBIST logs derived by hand from the March algorithms).
2. **Fault injection** in a behavioural memory model (8 fault types) to verify MBIST detection,
   localisation and algorithm-dependent coverage, including negative tests.
3. **Static checks**: Verilator `-Wall` lint (clean), Yosys synthesis + `check` (0 problems; only latch is
   the ICG), generated-file consistency, scan-readiness screen.
4. **Host-software ↔ RTL correlation**: complete production flows recorded on the Python device model
   and replayed TCK-by-TCK against the RTL; every compared TDO bit must match.
5. **Python unit tests** for the host stack, transports (fake devices), logs, binning, ATPG gate, traceability.

## 11.2 SystemVerilog testbenches

| Testbench | Checks | Coverage of the brief |
|---|---|---|
| `tb_tap_fsm` | 14 924 | TAP state machine: all 32 transitions, random walk, TLR from all states, TRST* from all states, DR strobes, TDO edge/enable |
| `tb_tap_bsr` | 27 | IDCODE, IR capture/length, BYPASS, unassigned opcodes, SAMPLE, PRELOAD/EXTEST drive & capture, CLAMP, HIGHZ, system reset during EXTEST, TRST* |
| `tb_mbist` | 207 | discovery, 6 algorithms × 5 memories (lat 1/2/3, 1R1W, ROM), backgrounds, SAF/TF/AF/CFid/DRF/column faults with exact log entries, algorithm coverage differences, overflow, stop-on-fail, aborts, ROM signature, user algorithm, never-false-pass, access-restriction negative test |
| `tb_rst_clk` | 52 | POR staged release timing, pad reset, WDT/SW/DBG stretch and cause, W1C, count, test-mode holds, scan bypass, core-before-system invariant, glitch-free clock switch, clock monitor |
| `tb_mode_sec` | 165 | full lifecycle × unlock × mode permission matrix, ILLEGAL/BAD_MAGIC/BUSY, TLR exit, EXTEST abort of running MBIST, relock abort of SCAN_TEST + clock unwind + TestCore reset, lockout/POR, OTP-invalid, one-hot monitor |
| `tb_dft_iso` | 31 | scan pins inert outside SCAN_TEST, functional port blocked in MBIST, BIST status pins, LBIST vs independent SV model, test clock root, scan reset, ICG TE, scan pin path, memory scan bypass |
| `tb_debug` | 165 | ID registers, CAPS, JTAG/APB access control, denied counter, BUSY/sticky/CLEAR_BUSY, halt/PC/GPR/x0/bad regno/PC write/step/resume, trace, halt-on-entry, error counters, accelerator diag, clocks, ndmreset, JTAG MBIST log |
| `tb_vector_replay` | per vector file | host flows vs RTL |

## 11.3 Host ↔ RTL replay

| Case | TCK cycles | Compared TDO bits | Mismatches |
|---|---|---|---|
| production flow, good device | 12 754 | 2 566 | 0 |
| production flow, PROD lifecycle (unlock path) | 12 984 | 2 726 | 0 |
| extended MBIST with L2 stuck-at-1 (failure-log readback) | 33 278 | 5 504 | 0 |
| SCAN_TEST entry sequence (ATPG test_setup source) | 107 | 46 | 0 |

The replay found one real modelling question during development: TC_STATUS bits from the system
domain are undefined in SCAN_TEST. It is now specified, documented and masked by the host.

## 11.4 Defects found and fixed during verification (selection)

| Found by | Issue | Fix |
|---|---|---|
| scan-readiness S2 | clock-monitor reference counter reset directly by `por_n` (not ATPG-controllable) | reset routed through `tc_dft_mux2` with the scan reset |
| `tb_rst_clk` | RESET_COUNT semantics at power-up undefined | defined to include the power-on episode (spec updated) |
| design review during TB writing | TC_MODE capture-only scans would overwrite LAST_ERR | MAGIC=0 defined as capture-only |
| pytest | BUSY recovery could re-issue non-idempotent writes | driver never re-issues; adaptive back-off + address check |
| Yosys | package imports / `return` / `int'()` unsupported by Yosys 0.33 | RTL kept standard; mechanical `yosys_prep.py` for open-source flows |

## 11.5 Manufacturing-readiness status

| Item | Status |
|---|---|
| TestCore RTL synthesizable, lint-clean, scan-ready (screen) | **Yes** (generic cells; library mapping of `tc_cells.sv` pending) |
| JTAG TAP 1149.1 behaviour | verified in simulation; **not compliance-tested** |
| BSDL | template; **unchecked**, pin map and JEP106 code are placeholders |
| MBIST | verified with fault injection; logical backgrounds; no repair |
| Scan / ATPG | preparation logic + plan + interface; **no insertion, no patterns, no coverage** |
| Host software | verified against RTL via the simulator; **adapters not run on hardware** |
| SilicaFlux-V CPU | **not ready**: no outputs, async-reset construct, behavioural memories, no debug hooks |

## 11.6 Limitations of this verification

* Single simulator (Icarus); no commercial simulator, no formal property checking, no code-coverage
  metrics collected.
* Gate-level, SDF-timing and multi-corner simulation not possible without a library.
* CDC verified structurally and by simulation only — no CDC/RDC tool run.
* The memory model and core model are behavioural stand-ins for compiler macros and the real CPU.
* FTDI/OpenOCD transports exercised with fakes only.
