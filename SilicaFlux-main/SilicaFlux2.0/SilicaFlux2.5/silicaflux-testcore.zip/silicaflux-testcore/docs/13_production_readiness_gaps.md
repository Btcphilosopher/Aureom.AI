# 13. Commercial DFT and ATE work required before production tapeout

TestCore is a verified RTL/software foundation. The items below are **not** done and cannot be done
credibly without a selected foundry/process, its libraries and memory compilers, commercial EDA tools,
and test-house engagement. They are ordered by dependency.

## A. Process, library and IP selection (prerequisite for everything)
1. Choose node/foundry (the SilicaFlux-V study leans to 65 nm, 130 nm fallback) and the standard-cell,
   I/O and memory-compiler kits.
2. Map `rtl/tc_cells.sv` to library cells: ICG with TE, clock mux (glitch-characterised), DFT muxes,
   synchroniser flops (MTBF-rated), and `dont_touch` them.
3. Obtain a **JEDEC JEP106 manufacturer code**; replace the IDCODE placeholder; assign a part number.
4. Implement OTP/eFuse: lifecycle code, unlock key (per-device), ECID programming at wafer sort,
   read-out protection, `otp_valid` sequencing; define the TEST→DEV/PROD→RMA transitions and secret wipe.
5. POR cell, PLL with lock detect, metal-programmable revision tie cells.

## B. Scan, compression and ATPG (commercial tools: e.g. Siemens Tessent or Synopsys TestMAX/DFTMAX)
1. Fix SilicaFlux-V CPU blockers (doc 01): primary outputs, async-reset construct, memory macros,
   debug hooks.
2. Scan insertion with library scan cells; exclusions per `dft/atpg/atpg_interface.json`; lock-up
   latches; chain stitching to a **decompressor/compactor** (EDT/DFTMAX-class) on the two channels.
3. **On-Chip Clock controller (OCC)** for at-speed launch/capture from the PLL — prerequisite for the
   ≥95 % transition target. Wire to `dft_scan_cfg_o[1]`.
4. Test points for random-resistant logic; X-bounding of memories/analog.
5. ATPG: stuck-at (target ≥99 %), transition (target ≥95 %), optionally cell-aware/small-delay and IDDQ;
   untestable-fault review and waivers; pattern count/test-time budget.
6. Pattern validation: serial + parallel zero-delay, SDF min/max timing simulation, STIL → ATE conversion.
7. DFT DRC, scan-mode STA (shift and capture), and power-aware shift (IR-drop) sign-off.

## C. Memory test
1. Replace or wrap the TestCore MBIST with the **vendor/foundry MBIST** if required by the memory
   compiler (scrambling-aware physical backgrounds, qualified algorithms, retention with voltage/temperature).
2. Per-memory registry values from the compiler (true latency, write-through, read-during-write).
3. Decide on **redundancy and repair** (row/column spares, BIRA, eFuse repair) for the larger L2;
   currently none — failing dies are binned out.
4. ATPG memory models or RAM-sequential handling for logic around memories.

## D. Boundary scan
1. Final pin list/package; BSR cells in the I/O ring (pad-cell-integrated BC cells preferred).
2. Run the generated BSDL through a **BSDL syntax/semantic checker** and an 1149.1 compliance
   verification (e.g. compliance-test patterns from the BSDL) in gate-level simulation and on silicon.
3. Decide on compliance-enable pins and whether EXTEST is restricted by lifecycle in PROD.

## E. Security sign-off
1. Replace password unlock with challenge-response (HMAC/ECDSA debug certificates) and per-device keys.
2. Fault-injection hardening (redundant lifecycle encoding, duplicated comparators, glitch sensors),
   side-channel review of key handling, penetration test of the JTAG/APB attack surface.
3. Integrate a **RISC-V Debug Module** for software debug (GDB/OpenOCD) with its own authorisation.

## F. Verification closure
1. Commercial simulator regression, functional/code coverage closure, assertion-based checks.
2. Formal verification: mode-exclusivity and permission properties, TAP FSM equivalence, CDC/RDC sign-off.
3. Gate-level simulation of TestCore with SDF; equivalence checking RTL ↔ netlist.
4. Hardware validation of FTDI/OpenOCD transports on an FPGA build of the SoC before silicon.

## G. ATE / production test program
1. Tester selection; probe card (power, JTAG, CLK_IN, GPIO0–7, RST_N at minimum; multi-site plan);
   load board with JTAG/scan channel routing.
2. Test program: continuity/opens-shorts, leakage/IDDQ, TAP integrity, IDCODE/ECID programming,
   scan chain test, ATPG patterns, MBIST via JTAG (and GPIO status pins), LBIST (optional), functional
   boot test, speed binning, voltage/temperature corners.
3. Convert `sftestcore` flows/SVF to the tester format; datalog mapping to the CSV/JSON schema;
   soft/hard bin table agreed with the test house.
4. Wafer-sort vs final-test split, test-time budget, guard bands, retest policy.
5. Yield learning: MBIST bit maps and failure logs to the foundry's failure-analysis flow; SPC.
6. Qualification per the existing Production Test & Qualification Plan (HTOL, HAST, TC, ESD, latch-up).

## H. Documentation and process
DFT sign-off checklist, test specification per block, change control for the spec JSON (it drives RTL,
BSDL and software), and a release process that regenerates and re-verifies all derived files.
