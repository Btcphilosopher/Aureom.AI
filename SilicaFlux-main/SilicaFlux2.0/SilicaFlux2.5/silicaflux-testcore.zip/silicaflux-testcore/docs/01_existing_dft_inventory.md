# 1. Inventory of existing DFT and debug capability (before TestCore)

Scope searched: every SilicaFlux source in the repository, including the contents of the archives
(`SilicaFlux-main/*.zip`, `SilicaFlux-main/SilicaFlux2.0/**/*.zip`, `soc_integration.tar.gz`,
`SilicaFluxML.zip`, `silicafluxai.zip`, `silicafluxbitcoinasic.zip`), the loose `.sf` RTL files of
SilicaFlux 2.0/2.5, and the planning PDFs. Search terms: JTAG/TAP/TCK/TMS/TDI/TDO/IDCODE/BSDL/boundary,
scan/scan_en/test_mode/DFT, MBIST/BIST/LBIST/LFSR/MISR, debug/halt/DMI, ICG/clock gate, reset
synchroniser/reset cause.

Classification used below:
**Implemented** = synthesizable RTL present and exercised by a testbench;
**Behavioural-only** = simulation models or test hooks without a silicon-capable implementation;
**Referenced, missing** = instantiated or specified but no definition exists anywhere;
**Planned** = described in documents only.

## Summary table

| Capability | Status | Where | Notes |
|---|---|---|---|
| JTAG TAP controller (1149.1) | **Referenced, missing** | `SilicaFlux2.0/SilicaFlux2.5/silicaflux_top.sf` ports `jtag_tck_i … jtag_tdo_oe_o` → `sf_dbg_module u_dbg` | `sf_dbg_module` is defined nowhere in the repository (0 definitions). |
| Instruction register / BYPASS / IDCODE | **Absent** | — | No IR, BYPASS or IDCODE logic in any file. |
| Boundary scan / BSDL | **Planned** | *Production Test & Qualification Plan* §4, *SilicaFlux-V Reduced-ASIC Prototype Design* §7 | No BSR cells, no BSDL. |
| Debug transport (DMI) | **Referenced, missing** | `SilicaFlux2.0/silicaflux_top.sf` (`dmi_req_*`, `sf_debug_module`), `silicaflux_pkg.sf` (`dmi_req_t`, `dbg_core_req_t {haltreq,resumereq,…}`) | Types exist; module `sf_debug_module` has 0 definitions. |
| Processor halt / debug mode | **Behavioural-only / partial** | v1 `silicaflux/rtl/silicaflux_top.sv` (`halt` flag on opcode 0x1F, `debug_scalar_r1` = r1 read port); 2.0 `decoder.sf` (`debug_mode`, `DRET` legality, `CSR_DBG_PAGE`) | v1 `halt` is an *end-of-program indicator*, not an external halt request. The SilicaFlux-V CPU candidate (`RISC-V CPU.zip`, `rv32i_core`) has only `clk`/`rst_n` ports — no debug hooks at all. |
| Memory BIST | **Implemented (standalone project)** | `silicaflux-memoryflow.zip`: `rtl/mbist/sf_mbist_march.sv`, `rtl/sram/sf_sram_bank.sv` (raw BIST port incl. ECC check bits), `rtl/top/sf_ctrl_regs.sv` (MBIST_CTRL/STATUS/FAIL_ADDR), `tb/unit/tb_mbist.sv` | March C- only; all banks in parallel; assumes 1-cycle read latency; logs first failing address + element and a per-bank fail mask; no syndrome, no multi-entry log, no ROM test, no access-restriction handling; started by an APB register (no test-mode/security gating). Self-described as a reference controller to be replaced by vendor MBIST. Not connected to any SilicaFlux CPU. |
| SRAM fault model for MBIST verification | **Behavioural-only** | `sf_sram_1rw_inferred.sv` (`SA_EN` stuck-at overlay) | Single stuck-at fault parameter. |
| Memory macro abstraction | **Implemented** (memoryflow) | `sf_sram_1rw.sv` (IMPL=0 inferred / IMPL=1 macro tiling), `macro_stubs/sf_macro_1rw_leaf.sv` (behavioural macro) | Good basis for collar insertion. |
| ECC error injection (RAS) | **Implemented** (memoryflow) | `sf_sram_bank.sv` `inj_en/inj_mask` | RAS feature, not production test. |
| Scan enable / test mode ports | **Referenced, missing** | 2.0 top: `scan_mode_i` → `sf_rst_sync`, `sf_icg(.test_en_i)`; 2.5 top: `test_mode_i`, `scan_en_i` → `sf_clk_ctrl` | `sf_icg`, `sf_rst_sync`, `sf_sync`, `sf_clk_ctrl`, `sf_rst_ctrl` have 0 definitions. The *intent* (ICG test-enable, reset bypass in scan) is correct; the logic does not exist. |
| Clock gating | **Referenced, missing** (2.x); **behavioural** in the IP library | `compute_tile.sf` (`unit_cg_en_o`), 2.x tops | No ICG cell model with a TE pin anywhere. |
| Reset synchronisers / reset cause | **Referenced, missing** | 2.5 top: `sf_rst_ctrl`, `sf_rst_cause_t rst_cause` → CSR | Type and CSR hook only. |
| Logic BIST (PRPG/MISR) | **Absent** | — | LFSRs exist only in unrelated testbenches. |
| ATPG flow / fault coverage | **Planned** | Production Test plan §2 ("95–98 %"), SilicaFlux-V design §7 ("50–100k patterns, >90 %") | No scripts, no netlist, no results. |
| Test-mode controller / access control | **Absent** | — | No lifecycle, no lock, no mode exclusivity anywhere. |
| Error counters / diagnostic status | **Partial** | memoryflow `sf_ctrl_regs` (ECC corr/uncorr counters); 2.5 `sf_fault_ctrl` (missing) | Not a debug register file. |
| Trace | **Referenced, missing** | 2.x `trace_*` ports, `sf_trace_agg` | Definitions missing. |
| SDC for test | **Partial** | `silicaflux/synth/silicaflux.sdc`, timinglab `constraints/silicaflux_top.sdc` | Functional constraints only; no test-mode/scan constraints. |
| Host-side test software | **Absent** | — | memoryflow has Python analysis tooling, not device control. |

## Findings that affect tapeout readiness of the SilicaFlux-V CPU candidate

Measured with `dft/scan/scan_readiness.py` on `RISC-V CPU.zip` (`make dft`):
see [generated/scan_readiness_silicaflux_v_rv32i_core.md](generated/scan_readiness_silicaflux_v_rv32i_core.md).

1. `rv32i_core` has **no primary outputs** — synthesis removes the whole core; it cannot be tested or
   observed until memory/bus/debug ports are added.
2. `rv32i_core.sv:273` — `if (!rst_n || flush_id_ex || flush_id_ex_br)` inside an async-reset
   `always_ff`: synchronous flush terms in the asynchronous branch; not mappable to an async-reset flop
   (Yosys rejects it). Restructure as `if (!rst_n) … else if (flush…) …`.
3. Behavioural memories (`instr_mem` 1024×21 inferred, `data_mem` 4096×8 = 54 272 bits) with
   `initial` + `$readmemh` + `$display`: must become compiler macros behind MBIST collars.
4. 1 899 logic flops on one clock — scan-eligible once the above is fixed (13 chains of ≤150 at 2 channels).
5. No debug hooks: halt/resume requires the changes in `docs/08_silicon_debug_and_security.md` §3.

## What TestCore therefore had to provide

Everything in the "Absent/Referenced, missing" rows, plus a reusable MBIST that removes the memoryflow
controller's limitations (latency, logging, algorithms, restrictions, security gating) while keeping
its useful idea — a raw test port per memory — as the collar contract.
