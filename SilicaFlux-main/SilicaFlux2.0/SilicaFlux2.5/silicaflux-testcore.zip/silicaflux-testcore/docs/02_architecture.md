# 2. TestCore architecture and integration

## Block diagram

```
                     TCK domain (non-scan; holds test mode)                 system clock domain (clk_o)
 TCK TMS TDI TRST* ┌──────────────────────────────────────────┐       ┌──────────────────────────────────────────┐
 ─────────────────►│ tc_tap  16-state FSM · IR(5) · BYPASS    │       │ tc_regbus  (JTAG + APB masters,           │
            TDO ◄──│         IDCODE · DR select · TDO(negedge)│       │            central access-control check) │
                   ├──────────────────────────────────────────┤ CDC   │   ├── tc_regs   ID · ECID · rev · status  │
                   │ tc_mode_ctrl  TC_STATUS/TC_MODE/TC_UNLOCK│══════►│   │             reset cause · clocks      │
                   │   one mode register, lifecycle + unlock, │ sync  │   │             error ctrs · core debug   │
                   │   clock-switch sequencer, reset holds    │       │   ├── tc_mbist  March engine + registry   │
                   ├──────────────────────────────────────────┤       │   ├── tc_lbist  PRPG/MISR (optional)      │
                   │ tc_reg_bridge TC_REG (46b) toggle CDC ◄══╪══════►│   └── tc_trace  trace buffer (optional)   │
                   ├──────────────────────────────────────────┤       └──────────────┬───────────────────────────┘
 pads ◄───────────►│ tc_bsr  BC_4 in / BC_1 out+ctl cells     │                      │ MBIST test bus
                   └───────────────┬──────────────────────────┘                      ▼
                         tc_test_pinmux (scan / BIST pins on GPIO)          tc_mbist_collar ─► SRAM/ROM macros
                                   │
 func_clk ─[tc_icg stop]─┐  tc_clk_ctrl (root clock mux, monitor)     tc_rst_ctrl (POR / pad / WDT / SW / DBG /
 CLK_IN (test clock) ────┴─► clk_o                                     test-mode holds → tc_rst_n, sys_rst_n, core_rst_n)
```

## Modules

| Module | Domain | Function | Scan |
|---|---|---|---|
| `tc_tap` | TCK | TAP controller, IR, BYPASS, IDCODE, TDO | excluded |
| `tc_bsr` | TCK | boundary-scan register (cell order shared with BSDL) | excluded |
| `tc_mode_ctrl` | TCK | test-mode FSM, lifecycle permissions, unlock/lockout, clock-switch sequencing | excluded |
| `tc_reg_bridge` | TCK + clk | TC_REG DR and toggle-handshake CDC | TCK side excluded |
| `tc_regbus` | comb. | arbitration (JTAG > APB) and access control | scanned |
| `tc_regs` | clk | ID/status/reset cause/clocks/error counters/core debug/accelerator diagnostics | scanned |
| `tc_mbist`, `tc_mbist_collar` | clk | MBIST engine, collars with test-path pipelines and scan bypass | scanned |
| `tc_lbist` | clk | PRPG/MISR test-per-clock LBIST (parameter `LBIST_EN`) | scanned |
| `tc_trace` | clk | 16×32 trace buffer (parameter `TRACE_EN`) | scanned (flops) |
| `tc_rst_ctrl` | clk | reset synchronisers with scan bypass, staged release, reset cause | scanned (DFT-muxed resets) |
| `tc_clk_ctrl` | func/ref/clk | functional-clock stop ICG, root test-clock mux, clock monitor | stop sync excluded |
| `tc_test_pinmux` | comb. | scan_en / scan_rst / scan I/O / BIST status on GPIO | — |
| `tc_cells` | — | `tc_icg`, `tc_clk_mux2`, `tc_dft_mux2`, `tc_sync`, `tc_rst_sync` (library-mapping points) | — |

## Clock and reset domains

| Domain | Source | Contents | Reset |
|---|---|---|---|
| TCK | TCK pin | TAP, IR, BSR, mode controller, bridge TCK side | TRST* AND POR; security state POR only |
| clk_o | root mux: gated `func_clk_i` or `test_clk_i` (SCAN_TEST) | all TestCore system logic **and the SoC** | `tc_rst_n` (TestCore), `sys_rst_n`, `core_rst_n` |
| func_clk_i | PLL/oscillator | 2-flop stop synchroniser for the ICG only | POR |
| ref_clk_i | reference oscillator | clock-monitor window counter | POR (DFT-muxed to scan reset) |

Crossings: TCK→clk mode levels via `tc_sync` (one-hot bits; transitions always pass NORMAL so at most
one bit changes); clk→TCK status via `tc_sync`; TC_REG via the toggle handshake; reset requests are
asynchronously asserted and synchronously released.

## Integration contract (SoC side)

1. **Clock**: drive the SoC from `clk_o`. All other SoC ICGs use `tc_icg` (or the library ICG) with
   `te = dft_cg_te_o`.
2. **Resets**: SoC flops use `sys_rst_n_o`; the CPU uses `core_rst_n_o`. Any other reset synchroniser
   must use `tc_rst_sync` with `scan_mode = dft_scan_mode_o`, `scan_rst_n` from TestCore.
3. **Pins**: the BSR sits between the pads and `tc_test_pinmux`; the pinmux sits between the BSR and
   the core GPIO. TAP pins have no BSR cells.
4. **Memories**: every SRAM/ROM macro sits behind a `tc_mbist_collar`; its registry entry
   (width, depth-1, latency incl. collar pipes, type, write→read gap) is a `tc_top` parameter.
5. **Core debug**: connect the generic debug port (`dbg_*`) — see doc 08 for required core changes.
6. **Diagnostics**: error events (single-cycle pulses in `clk_o`), 4×32 accelerator status words,
   optional trace stream, watchdog reset request.
7. **OTP / tie cells**: `lc_otp_i`, `otp_valid_i`, `unlock_key_i`, `ecid_i` from the OTP controller;
   `silicon_rev_i`, `idcode_version_i` from metal-programmable tie cells.
8. **Scan insertion**: exclude the TCK domain and `u_clk.u_stop_sync`; connect inserted chains /
   decompressor to `dft_scan_in_o` / `dft_scan_out_i`.

## Size (indicative)

Yosys generic synthesis of `tc_top` (default 2-memory registry, LBIST and trace enabled): see
`docs/generated/regression_results.md` (≈13.7 k generic cells, ≈2.7 k flops, 1 latch = the ICG).
This is not a standard-cell area; the MBIST failure log (8 entries × ~100 bits) and the trace buffer
dominate and are parameters (`LOG_DEPTH`, `TRACE_DEPTH`, `TRACE_EN`, `LBIST_EN`).

## Single source of truth

`spec/testcore_spec.json` → `scripts/gen_spec.py` → `rtl/tc_spec_pkg.sv` (codes, register offsets,
access-control and permission functions, March ROM), `docs/generated/*.md`, `dft/bsdl/*.bsd`,
`tb/models/tc_demo_cfg.svh`. The host software reads the same JSON. `gen_spec.py --check` is part of
the regression.
