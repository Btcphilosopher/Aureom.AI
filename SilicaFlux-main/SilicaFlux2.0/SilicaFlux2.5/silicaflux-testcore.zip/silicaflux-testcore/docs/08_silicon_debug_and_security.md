# 8. Silicon debug and the security model

## 8.1 Debug features (register details in [generated/register_map.md](generated/register_map.md))

| Feature | Registers | Access |
|---|---|---|
| Processor halt / resume / single step | DBG_CTRL (HALT_REQ, STEP, NDMRESET, ACK_HAVERESET), DBG_STATUS | DIAGNOSTIC, JTAG only (status readable by all) |
| Register readback / write (GPR 0–31, PC = 32) | DBG_CMD, DBG_DATA (core must be halted; 255-cycle timeout) | DIAGNOSTIC, JTAG only |
| PC sample | DBG_PC | DIAGNOSTIC |
| Status | TC_STATUS (TCK), MODE_STATUS, SEC_STATUS, DBG_STATUS | public |
| Error counters | ERR_CNT0..7 (16-bit saturating), ERR_SUMMARY, ERR_CLR | read public; clear CPU or DIAGNOSTIC |
| Trace buffer (optional) | TRACE_CTRL/STATUS/IDX/DATA, 16×32, stop-on-halt | DIAGNOSTIC |
| Reset cause / count | RESET_CAUSE (POR, pad, WDT, SW, DEBUG, TEST_MODE; W1C), RESET_COUNT | read public; clear CPU or DIAGNOSTIC |
| Clock status | CLK_STATUS (PLL lock, monitor valid, test clock selected, functional clock stopped, source), CLK_MEAS, CLK_CYCLES | public |
| SRAM test status | MBIST_STATUS / FAIL_MEMS / FAIL_COUNT / LOG / ACC_SYND | public read (results persist after the mode) |
| Accelerator diagnostics | ACC_DIAG0..3 (registered 4×32 status words) | public |
| Identification | IDCODE, SILICON_REV, ECID, TC_VERSION, CAPS | public |

## 8.2 Core debug port protocol

```
dbg_halt_req_o  ──┐ level, gated by DIAGNOSTIC mode
dbg_halted_i    ◄─┘ core asserts after draining its pipeline; PC frozen
dbg_step_req_o      1-cycle pulse while halted: execute one instruction, stay halted
dbg_reg_req_o/we/addr/wdata ─► held until dbg_reg_ack_i (+ rdata, err); only while halted
```
Leaving DIAGNOSTIC (request, TLR, permission withdrawn) drops the halt request: the core resumes.
`DIAGNOSTIC` option bit 0 halts the core on entry. Verified in `tb_debug` with a protocol model.

## 8.3 "Where the architecture permits": required CPU changes

The SilicaFlux-V CPU candidate (`rv32i_core`, `RISC-V CPU.zip`) has no debug hooks (only `clk`,
`rst_n`). Halt/resume needs, at minimum:

1. Debug port as in 8.2 on the core top level.
2. Halt: when `dbg_halt_req` is set, stop PC update and IF/ID loading (reuse the existing `stall_if`/
   `stall_id` path), inject bubbles until EX/MEM/WB are empty, then assert `dbg_halted`.
3. Resume: drop the stall; Step: allow exactly one fetch, then re-enter the halted state.
4. Register access while halted: multiplex the register-file read port and write port (and PC) to the
   debug port.
5. Memory access for debug (not provided by TestCore v0.1): a system-bus master or abstract
   memory command.

TestCore's debug path is a bring-up/test path. It is **not** a RISC-V Debug Specification
implementation, so GDB/OpenOCD `riscv` targets cannot attach. For software debug in production, integrate
a RISC-V Debug Module behind the same TAP (as a private DMI instruction) and keep TestCore for test.

## 8.4 Security model

### Assets
Device internal state (secrets in registers/SRAM), the OTP unlock key, the lifecycle state, the
ability to enter test modes (which can corrupt or observe state), manufacturing data (ECID).

### Adversaries
(a) board-level attacker with JTAG access to a field device; (b) software running on the CPU;
(c) test-floor misuse.

### Controls

| Control | Mechanism | Verified |
|---|---|---|
| Lifecycle gating | OTP code → TEST / DEV / PROD / RMA; **any other code (incl. corrupted) → INVALID, fail-secure**; `otp_valid=0` → INVALID | `tb_mode_sec`, pytest |
| Permission matrix | spec `mode_permissions` → generated function; PROD needs unlock for BIST/DIAGNOSTIC and **never** allows SCAN_TEST | exhaustive matrix (independent table) |
| Authorisation | 64-bit token compared with OTP key; all-zero OTP key = unlock impossible; relock by writing 0 | `tb_mode_sec` |
| Brute-force limit | 4 failures → lockout until power-on reset (not cleared by TRST*/TLR) | `tb_mode_sec`, pytest |
| Continuous enforcement | permission re-evaluated every TCK; relock/lifecycle change aborts the active mode | `tb_mode_sec` |
| Mode exclusivity | single mode register, test→test transitions rejected, one-hot decoded outputs (monitored) | `tb_mode_sec` |
| No scan-based state extraction / injection | SCAN_TEST entry resets the system and TestCore system state; exit resets again before functional operation | `tb_mode_sec`, `tb_dft_iso` |
| CPU cannot enter test modes | test-mode control exists only on TCK-domain TDRs; APB is read-mostly (public reads, reset-cause/error-counter clear, scratch, SW reset) | `tb_debug` |
| Register access classes | PUBLIC / DIAG / MBIST / LBIST / SYS_OR_DIAG enforced centrally; denied accesses return ERROR and are counted (SEC_STATUS.DENIED_CNT) | `tb_debug`, pytest |
| Fail-safe defaults | test modes cleared by TLR and TRST*; BSR update stage resets to "drivers disabled" | `tb_tap_bsr`, `tb_mode_sec` |

### Residual risks and production gaps (also in doc 13)

1. **Password, not challenge-response.** A replayed or sniffed token unlocks every device sharing the
   key. Production should use per-device keys (KDF of a master secret and ECID) and a challenge-response
   protocol (e.g. HMAC-SHA-256 over a TRNG nonce) or signed debug certificates.
2. **No fault-injection hardening** of the lifecycle decode, comparator or lockout counter (glitching).
   Use redundant/encoded state, duplicated comparators and sensors.
3. **OTP integration** (key storage, read-out protection, RMA secret wipe on lifecycle change) is
   outside this RTL.
4. Boundary scan remains available in PROD (needed for board test). EXTEST cannot read internal
   state (system held in reset) but can disrupt pins; a product may restrict it by lifecycle.
5. Side channels (power/EM during key compare) are not addressed.
6. The ECID is public by design (traceability); do not use it as a secret.
