# 01 — Architecture

```
                         ┌────────────────────────── silicaflux_cloud_dma ───────────────────────────┐
  CSR (32-bit) ─────────►│ sfdma_csr ── ctrl/limits ──┐          sfdma_perf (32 counters + 4 watermarks / channel)
  irq ◄──────────────────│                            ▼          sfdma_trace (events → FIFO → CSR)
                         │   ┌───────── sfdma_channel × NUM_CH ─────────────────────────────────┐   │
  cmd {head,domain,asid}►│   │ cmd FIFO → FSM ─┬─► sfdma_desc_walker ─► element queue ─┐         │   │
  done {txn,status,…} ◄──│   │ (watchdog,      │   fetch·validate·chain                 ▼         │   │
                         │   │  abort, record) └─► completion-record writer     sfdma_burst_ctrl │   │
                         │   │                      │                           ┌──────────────┐  │   │
                         │   │                      │                           │ read planner │  │   │
                         │   │                      │                           │ write planner│  │   │
                         │   │                      │                           │ sfdma_bytebuf│  │   │
                         │   │                      │                           │ slots · CRC  │  │   │
                         │   └──────────────────────┼───────────────────────────┴──────┬───────┘  │   │
                         │        permission clients (DESC, RD, WR, CPL) ×4 per channel  │ AR AW W   │   │
                         │                          ▼                                  ▼ ▲ R B     │   │
                         │                 sfdma_perm_checker ◄───────────────  sfdma_axi_mux ────┼──► AXI4 master
                         │                          │                                              │   (ID = {ch,local})
                         │            IOMMU port ───┴──► external IOMMU  (USE_EXT_IOMMU = 1)        │
                         │                          └──► sfdma_perm_table (simulation model, default)
                         └────────────────────────────────────────────────────────────────────────────┘
```

The mission's pipeline maps onto it as: **Descriptor Fetch** (walker, through the checker) → **Validation** (walker,
once, from an internal copy) → **Address Permission Check** (checker, per burst) → **Read Requests** (read planner →
AR) → **Internal Data Buffers** (`sfdma_bytebuf` ring) → **Write Requests** (write planner → AW/W) → **Completion**
(B responses, then the completion record, then the completion event).

## 1. Modules

| Module | Role |
|---|---|
| `silicaflux_cloud_dma` | top: channels, mux, checker, IOMMU/table, CSR, perf, trace |
| `sfdma_channel` | one channel: command FIFO (`sfd_fifo`), FSM `IDLE→RUN→FIN→CPL→DONE`, first-error latch, watchdog, abort, fence, completion-record writer, perf/trace hooks |
| `sfdma_desc_walker` | descriptor fetch, validation, chain walking (§ docs/02) |
| `sfdma_burst_ctrl` | element queue, read/write planners, data buffer, slot tables, W streamer, CRC, drain-on-failure |
| `sfdma_burst_plan` | burst geometry (pure function; used 4×; exhaustively tested) |
| `sfdma_bytebuf` | byte ring with arbitrary-alignment write and read ports |
| `sfdma_perm_checker` | arbitration of 4×NUM_CH clients; local checks; IOMMU request/response; translation-result checks |
| `sfdma_perm_table` | simulation IOMMU: programmable mappings with domain/ASID/permission/translation |
| `sfdma_axi_mux` | NUM_CH channels → one AXI4 master (grant lock, ID routing, W order FIFO) |
| `sfdma_crc` | CRC-32 over strobed lanes |
| `sfdma_csr`, `sfdma_perf`, `sfdma_trace` | management plane |

## 2. Bus protocol actually used (and the restrictions respected)

AXI4 subset, master: AR/R, AW/W/B, with `asid` and `domain` sidebands on AR and AW.

| Restriction | How it is respected |
|---|---|
| INCR bursts, full-width beats | `size = log2(DW/8)`, `burst = 01` constants |
| ≤ 256 beats, ≤ 4 KiB, **no 4 KiB crossing** | `sfdma_burst_plan`: `nbytes = min(remaining, to-boundary, MAXB·WB − lo)`; boundary is a multiple of the beat size so the beat-aligned envelope also ends ≤ the boundary. Parameter check: `64 ≤ MAXB·WB ≤ 4096`, `MAXB ≤ 256`. |
| First/last beat partial | reads: whole aligned beats inside the checked envelope; writes: byte strobes (contiguous per beat) |
| AW/AR payload stable until accepted | requests are decided once and **never withdrawn** (even if the channel fails meanwhile); AR/AW arbitration has a grant lock |
| W after AW, in AW order | a channel pushes a W-queue entry when its AW is accepted; the mux's order FIFO forwards W beats in AW order |
| A write cannot be cancelled → never leave an AW without data | **AW is issued only when all its bytes are already committed in the buffer** (store-and-forward per write burst) |
| IDs | AR ID = {channel, class, slot}; AW ID likewise; class 1 = descriptor fetch (reads) / completion record (writes); slot = index of the outstanding burst, so IDs of outstanding bursts are unique |
| Response ordering | `REORDER_OK = 1`: any interleaving across IDs is absorbed (beats are written to the buffer by stream position; commit follows issue order). `REORDER_OK = 0`: the bus is declared in-order and a response out of order is `ERR_PROTOCOL`. An unknown or idle ID is always `ERR_PROTOCOL`. |
| `r_ready`, `b_ready` | constant 1 (credit-based flow control below) |
| Reset | all valids low during reset; in-flight transactions are abandoned (see §6) |

SFB2 (DataFabric) is **not** the port: it has no bursts and no IDs (docs/00_AUDIT.md). An AXI4→SFB2 slave adapter
would be needed to place local SRAM on SFB2; it does not exist in the repository.

## 3. Data buffer, credits and the progress proof

`sfdma_bytebuf` is a ring of `BUF_BYTES`. Three wrap-around pointers `rdp ≤ commit ≤ alloc ≤ rdp + BUF_BYTES`:

* `alloc` advances when a read burst is **issued** (space is reserved for its useful bytes) → a response can never find
  the buffer full, so `r_ready` can be constant 1 (no response back-pressure on the bus);
* `commit` advances when the **oldest** outstanding read burst has fully arrived (reads can complete in any order);
* `rdp` advances as W beats are accepted.

R beats are written at their **stream position** (`slot base + beat offset`), which is why reordered or interleaved
responses need no reorder buffer. The write side reads from `rdp` and places the stream bytes in the destination
lanes (`lane0 = dst mod WB` on the first beat), so source and destination may have any relative alignment, and the
two sides cut bursts independently.

**Progress (no deadlock).** A write burst needs ≤ `MAXB·WB` committed bytes before its AW; a read burst reserves
≤ `MAXB·WB`. If the write side waits for data it holds `X < MAXB·WB` committed bytes, so
`free = BUF_BYTES − X > BUF_BYTES − MAXB·WB ≥ MAXB·WB` when `BUF_BYTES ≥ 2·MAXB·WB` — the read side can always
issue. The elaboration refuses smaller buffers (`illegal_parameter_BUF_BYTES…`). The element queue lets the reader load
an element before the writer (the writer never overtakes the reader), which also makes the `ORDERED` barrier
deadlock-free.

## 4. Permission pipeline (per burst)

`planner → checker request {domain, asid, write, envelope addr, envelope bytes} → response {ok, fault, pa} → AR/AW`.
One request per client at a time; the planners plan the next burst while earlier bursts are in flight, so the checker
latency is hidden behind data transfer while the checker keeps up. A copy needs one read check and one write check per
burst; with one translation in flight (`PERM_OUT = 1`) the checker serves a burst in about `2·(latency + 1)` cycles, so
the latency is hidden only while that is no more than the burst time (measured: free at latency 1 and 4, throughput
halves at 16 and collapses at 64; `PERM_OUT > 1` recovers part of it — docs/06 §6). Details, fault classes and the
IOMMU contract: docs/03.

## 5. Completion

1. Data bursts: B response `OKAY` for every write burst (a write is *performed* when its response is issued: DataFabric
   rule R7, AXI4 write response semantics). `BYTES` = Σ bytes of acknowledged bursts.
2. If `CPL_EN`: the 32-byte record is written through the checker as one burst; its B response is awaited.
3. Only then does `done_valid` rise (`ST_OK`, `COMMITTED`). Completion is **never** signalled when the final read is
   issued, when the final W beat is accepted, or before the record is acknowledged. A bus error response on a write
   burst or the record is reported as an error, never as success.

## 6. Failure, cancellation, reset (what happens to in-flight operations)

| Event | Behaviour |
|---|---|
| **Descriptor error** (walker) | already-validated elements finish; the failing descriptor and the rest do not; status ERROR; record written |
| **Execution error** (permission refusal of a data burst, bus error, protocol error) | stop issuing at once; outstanding read responses are consumed and dropped; issued writes complete (their data is in the buffer); then status ERROR; record written. Nothing is rolled back: acknowledged bytes stay written and are counted in `BYTES` |
| **Abort** (`CH_CTRL.abort`) | same drain as an execution error, status `ABORTED`, `ERR_ABORT`; ignored when the channel is idle or already finishing |
| **Timeout** (no progress for `CSR_TIMEOUT` cycles, 0 = off) | `ERR_TIMEOUT`, **no record**, channel **fenced**: no new command until every outstanding response has returned (late ones are absorbed), or soft reset |
| **Soft reset** (`CSR_CTRL[1]`) | resets the DMA core for 4 cycles (channels, walker, controller, checker **and the AXI multiplexer**); CSR configuration and counters survive; the permission table survives. The platform must not deliver stale bus responses afterwards (SFB2 R11 contract) |
| **Hard reset** (`rst_n`) | everything cleared, including the simulation permission table (software reprograms it) and the CSRs (engine disabled). No completion is signalled for abandoned transactions. An accepted write may or may not have been performed |

A presented AR/AW is never withdrawn (AXI4), so abort/failure never leaves the bus in an illegal state; a write whose AW
was issued always has its data and finishes.

## 7. Multichannel

`NUM_CH` identical channels; arbitration, ID routing and the AW-ordered W forwarding are in `sfdma_axi_mux`; the
permission checker serves `4·NUM_CH` clients round-robin. A channel's domain is bound per command. Channels are
independent: an error, abort, timeout or fence on one does not affect another (tested in
`tb/tb_tests.svh t_multichannel`). Per-channel buffers and slot tables are not shared.

## 8. Parameters

| Parameter | Default | Legal values / meaning |
|---|---|---|
| `NUM_CH` | 1 | ≥ 1 |
| `DW` | 64 | 32, 64, 128, 256, 512 |
| `AW` | 48 | 13..64 |
| `DOM_W` | 4 | 1..16 |
| `MAX_BURST_BEATS` | 16 | `MAXB·DW/8 ∈ [64, 4096]`, `MAXB ≤ 256` |
| `RD_OUT`, `WR_OUT` | 4, 4 | 1..64 outstanding bursts per channel |
| `BUF_BYTES` | 1024 | power of two ≥ `2·MAXB·DW/8` |
| `ELQ`, `CMDQ` | 2, 2 | element / command queue depth |
| `MAX_ELEM_LOG2`, `MAX_TOTAL_LOG2`, `MAX_CHAIN` | 24, 30, 64 | limits (docs/02) |
| `REORDER_OK` | 1 | bus may reorder across IDs |
| `CRC_ON` | 1 | CRC hardware present |
| `USE_EXT_IOMMU`, `PERM_OUT` | 0, 1 | real IOMMU on the port; outstanding IOMMU requests |
| `PERM_ENTRIES`, `PERM_LAT` | 16, 1 | simulation table size / latency |
| `TRACE_DEPTH`, `PC_W`, `TIMEOUT_DEF` | 32, 48, 0 | trace FIFO, counter width, reset timeout |

Illegal combinations fail at elaboration with a module name that states the rule (Verilator and Yosys both).

## 9. Coding rules followed

Synthesizable RTL follows the repository's Yosys 0.33 rules: flat ports, no `import`/structs/`return`/`int'()`, package
constants referenced fully qualified in module bodies, no unsized fill literals in parameter overrides, one clock,
asynchronous-assert reset, no latches (0 in synthesis). Verification-only code (assertions in `ifndef SYNTHESIS`)
is excluded from synthesis.
