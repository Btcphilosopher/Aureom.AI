# 00 — Repository audit (Project 64, SilicaFlux CloudDMA)

Audited: `btcphilosopher/Aureom.AI`, working tree of the session branch (HEAD `75371f0`, "Add files via upload").
As in the earlier SilicaFlux projects, the hardware lives almost entirely **inside zip archives** under
`SilicaFlux-main/` and `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`; there are **no loose `.sv` files** in the repository
tree. The archives relevant to this brief were extracted read-only into a scratch directory and read:
`silicaflux-clouddpu-p61`, `silicaflux-virtualio-p63`, `silicaflux-datafabric` (+ `-noc`), `silicaflux-sramgrid-p33`,
`silicaflux-hostlink-project25`, `silicaflux-storagecore-p51`, `silicaflux-buffercore-p55`, `silicaflux-securestore-p59`,
`silicaflux-controlcore`, `silicaflux-extmem-bridge-p24`, `silicaflux-nvme-hostcore-p57`, `silicaflux-ioshell-p37`,
`silicaflux-noc-spine-p34`, `silicaflux-flashlink-p53`, `silicafluxai` (the `sfx_dma`), `silicaflux-p40-floorplanbuild`
(`sf_dma`, `sf_data_fabric`, `sf_host_if` stand-ins), `silicaflux-hpc-m05-dma-adapter` / `-m07-perf-counters` (nested copies).

**What was and was not re-run.** Nothing from the older projects was re-simulated for this audit. Facts below come from
reading the RTL and from each project's own documentation; numbers quoted are *that project's* simulation/formal
evidence, never a hardware result. Only the three small modules this project vendors were re-verified (byte-for-byte
against the archive, and by their use in this project's benches).

## 1. Inventory against the brief

| Area named in the brief | What exists | Properties that matter here | Decision |
|---|---|---|---|
| **Existing SilicaFlux DMA** | `sfd_clouddma` (P61, host↔SRAM, native to P61); DataFabric `silicaflux_dma`, `dma_transfer_engine`, `dma_burst_engine` (single channel, `dma_validate`); HPC M05 `hpc_dma_adapter`; TensorCore07 `tensor_dma_adapter`; StorageCore `sfs_dma`; BufferCore `sfsb_eng_*`; HostLink `sfh_engine`; `sfx_dma` (silicafluxai); `sf_dma` (P40 stand-in) | **None has scatter-gather** (HostLink states it: `CAPS.SCATTER_GATHER = 0`). `sfd_clouddma`: one SFB2 single-beat transaction at a time, 4 KiB-agnostic, no descriptors, no checksum of a *chain*, permission only through guards outside it. DataFabric engines: register-programmed, one transfer, 32-bit addresses, overlap rejected. | **New engine.** `dma_validate`'s rule set (zero length, alignment, overflow, overlap) was the starting point for the walker's checks, extended to 65-bit arithmetic and per-descriptor chain rules. |
| **DataFabric** | SFB2 protocol (rules R1–R12), `sfb_crossbar`, arbiters, `sfb_sram_slave`; PROTOCOL.md | **No native bursts** (R10: a "burst" is sequential single beats); **one outstanding transaction per crossbar port** (R6); responses in order (R5/R12); write response only after the write was performed (R7); no IDs ("planned, not implemented", PROTOCOL.md §8). | **Contract honoured, not reused as the port.** CloudDMA's memory port is AXI4-style (INCR bursts, IDs) because a data-movement engine that cannot overlap transactions cannot be fast. The AXI4 port is the same one P61 already exposes at its host boundary (`integration/sfd_sfb2_to_axi4.sv`). **Gap:** there is no AXI4 → SFB2 *slave* adapter in the repository (P61's bridge goes the other way). Local SRAM behind SFB2 needs one; it is listed in `docs/08_LIMITATIONS.md` and the testbench models an in-order, one-deep slave to show the DMA tolerates it. R7 is the documented basis of the completion rule (B response = write performed). |
| **SRAM** | `sram_sp` + generic/FPGA/ASIC backends (P01), SRAM-grid P33, `sfb_sram_slave` | Word-addressed behind SFB2; partitions per tenant are a P61 concept (`sfd_sram_guard`, 256-byte pages). | **Not instantiated.** The DMA addresses local SRAM as an address space (ASID 1) through its memory port; tenant partitioning is expressed as permission-table entries (`docs/03_PROTECTION.md`). |
| **PCIe host interfaces** | HostLink P25: NVMe-style queues, an AXI4 *endpoint boundary*, a simulated host; **no PCIe protocol logic**, physical PCIe blocked. NVMe host core P57: PRP window only. | The only real host-side precedent is **AXI4 64-bit INCR ≤ 16 beats, never crossing 4 KiB, one burst outstanding** (HostLink `04_DMA_AND_ISOLATION.md` §1). | CloudDMA's host side is the same AXI4 conventions, generalised (data width, burst length, multiple outstanding, IDs). No PCIe logic exists to integrate with. |
| **VirtIO** | P63 `silicaflux_virtio_*`: queue controller, **descriptor walker** (virtio split ring), **domain permission table** (`silicaflux_virtio_domain_perm`), DMA arbiter; formal checks of the permission table | Its walker parses virtio rings (a different format), its DMA port is 64-bit, one request outstanding, 8-byte aligned, tagged with `dma_req_domain`. Its audit states the same IOMMU situation: *"replaced by a verified permission-table model … exports the domain so a platform IOMMU can add a second independent check"*. | **Pattern reused, code not.** The permission-table-as-model approach and the exported-domain sideband are the same decision here (`sfdma_perm_table`, `m_*_domain`). The virtio walker is virtqueue-specific and was not adapted. A virtio device would sit *in front of* CloudDMA, producing its descriptors (open item). |
| **IOMMU adapters** | **None.** P61: "No IOMMU / PASID / SR-IOV exists in the repository"; HostLink relies on the *host's* IOMMU and keeps only "defence-in-depth windows". | — | **Interface defined** (`docs/03_PROTECTION.md`): a request/response port a real IOMMU can implement; behind it, by default, a **new verified simulation permission table**. This is the brief's "real IOMMU interface when available, otherwise a verified simulation permission table". |
| **StorageCore** | P51 `sfs_dma` (one outstanding, aligned), `sfs_*`; NVMe-lite; P59 SecureStore | Not NVMe/ONFI compliant (its own statement). Storage window modelled as ASID 2. | Address-space ID reserved; no StorageCore RTL instantiated. |
| **Performance counters** | HPC M07 `hpc_perf_counters` (generic counter bank, CDC variant, snapshot/freeze; formal A1–A7, mutation 46/46); DataFabric `sfb_perf_counters`; P61 `sfd_perf` (per-tenant, 64-bit LO/HI latch) | M07 counts events; the DMA needs *sums of levels and latencies* (occupancy integrals, latency sums, watermarks) and a per-channel bank selected by a 2-D index. | **New `sfdma_perf`** (same LO/HI latch convention as P61). Honest caveat, as in P61: M07 could be adapted and would bring its formal evidence; it was not, to keep one counter contract across the 32 events/watermarks. |
| **CRC** | `sfd_crc32` (P61, 4 B/cycle, IEEE), `sfsec_crc` (P59, golden), `crc32.c` (firmware) | Byte-serial helpers; the DMA needs up to 64 bytes per cycle with arbitrary strobes. | **New `sfdma_crc`**, cross-checked in simulation against **vendored** `sfd_crc32` and the published check value (`tb/tb_crc.sv`). |
| **ControlCore** | RV32IM controller with register window, mailbox, interrupts (P21) | The DPU (P61) puts its registers on the ControlCore's accelerator pages. | CloudDMA exposes a plain 32-bit single-cycle CSR port (`docs/04_INTEGRATION.md`); wiring it to ControlCore pages 8..15 is integration work, not done here. |
| **FIFO / arbiter** | `sfd_fifo` (any depth, flush), `sfd_rr_arb` (P61) | Used by P61 with Yosys 0.33 and Verilator. | **Reused unmodified** (vendored): command queue, trace FIFO, write-order FIFO, trace arbiter. |

## 2. Reuse actually made

Vendored **byte-for-byte** (verified with `cmp` against the members of `silicaflux-clouddpu-p61.zip`, SHA-256
`13acc779…8d1c27`; manifest and hashes in `third_party/MANIFEST.tsv` / `SHA256SUMS`, checked by `make check-vendor`):

| File | Source member | Used for |
|---|---|---|
| `third_party/p61-clouddpu/rtl/sfd_fifo.sv` | `rtl/dpu/sfd_fifo.sv` | command queue, trace FIFO, AXI W-order FIFO (RTL) |
| `third_party/p61-clouddpu/rtl/sfd_rr_arb.sv` | `rtl/dpu/sfd_rr_arb.sv` | trace source arbiter (RTL) |
| `third_party/p61-clouddpu/rtl/sfd_crc32.sv` | `rtl/dpu/sfd_crc32.sv` | **independent golden CRC in verification** (not on the datapath: 4 B/cycle) |
| `third_party/p61-securestore/rtl/sfsec_crc.sv`, `sfsec_pkg.sv` | P61's vendored SecureStore copy | provenance of the CRC golden chain (P61 proves `sfd_crc32 == sfsec_crc`); not compiled here |

Nothing was edited. No license file exists in the repository; none is added here (an owner must decide before any
external distribution).

## 3. Modules that do **not** exist, and what stands in for them

| Needed | Status | Stand-in in this project |
|---|---|---|
| IOMMU | does not exist | interface + `sfdma_perm_table` (simulation model, *not* a hardware isolation mechanism) |
| AXI4 → SFB2 slave adapter | does not exist | not provided; testbench slave model covers the behaviours (in-order, one-deep) |
| Host (PCIe/VirtIO) front end that submits commands | does not exist | testbench drives the command port; the domain on that port is the binding a real front end must supply |
| Storage / network / compute engines | not integrated | address-space IDs 2/3/4 are routed like any other address space; targets are testbench memory regions |
| Linux driver, RTL-level firmware | out of scope | descriptor ABI + CSR map documented for a future driver |

## 4. Tooling (this environment)

`apt-get` packages: Verilator 5.020, Icarus Verilog 12, Yosys 0.33 (the same versions the P61 report records). The
repository's coding rules for Yosys 0.33 (flat ports, no `import`/structs/`return`/`int'()` in synthesizable RTL,
package references in bodies only) were re-confirmed by probes and followed. Exact versions are recorded in
`reports/tools.txt` by `scripts/tools.sh`.

## 5. Gaps found in the repository that this project does not close

* No IOMMU, no AXI4→SFB2 slave adapter, no PCIe protocol logic, no hardware (FPGA/silicon) result anywhere.
* DataFabric's SFB2 cannot carry IDs or bursts; any DMA with more than one outstanding transaction needs an extension
  or an AXI4 interconnect in front of it.
* The earlier DMA engines accept only 32-bit addresses; descriptors here carry 64-bit addresses and the engine is
  parameterised up to `AW = 64`.
