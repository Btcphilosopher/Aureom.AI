# 05 — Verification

Numbers in this file come from the generated reports (`reports/*.md`, `reports/unit/summary.txt`); re-run with `make`.
Everything is **simulation** (docs/08).

## 1. Structure

```
unit benches (Verilator)                       system testbench tb/tb_dma_sys.sv  (Verilator, --timing)
  tb_burst_plan   exhaustive vs byte walker      DUT ── AXI4 slave model (tb_slave.svh): 18 MiB image, random stalls and latency,
  tb_bytebuf      3 widths vs byte array                 response reordering/interleaving, error injection, hang
  tb_crc          3 widths vs bitwise ref and        ── external IOMMU model (tb_iommu.svh) with fault injection
                  vendored sfd_crc32 + 0xCBF43926    ── monitors: AXI4 protocol, unauthorised access, live byte check,
  tb_perm_table   3 latencies vs 64-bit ref                       completion/acknowledge ordering        (tb_mon.svh)
  tb_pkg_layout   struct views == flat positions     ── model + scoreboard + descriptor builders          (tb_pkg.sv)
                                                     ── tests                                              (tb_tests.svh)
```

**The scoreboard predicts from the descriptors and the memory image, never from the DUT.** Before a transaction runs,
`chain_expect` translates every byte of every executing element through the testbench's own mirror of the permission
table and records, per physical byte, an owner (the transaction) and the value that must be written. Then:

1. **Live, at every W beat**, each strobed byte must belong to the transaction running on that channel, carry the
   expected value and be written **at most once** (`WRITE OUTSIDE THE EXPECTED SET`, `WRONG DATA`, `DUPLICATE WRITE`).
2. **At completion**, every expected byte must have been written **exactly once** and be committed with the right value
   (`DATA LOSS/DUPLICATION`, `MEMORY MISMATCH`): *data loss, duplication and misplacement are all caught.*
3. **At every AR/AW**, the physical range must lie inside mappings that the domain *bound to that channel* may access with
   that permission, and the sideband domain must equal that binding (`UNAUTHORISED READ/WRITE`). Traffic while no
   transaction is in flight (after reset, after completion) is an error.
4. **Completion ordering**: when `done` is signalled, no read burst and no write burst of that channel may be
   unacknowledged (`COMPLETION BEFORE ACKNOWLEDGE`). The slave model commits a write to memory only when its B
   response is handed over, so a DUT that signalled completion early would also show a stale memory image and a missing
   completion record. The completion record is read back from memory and every field compared.
5. **AXI4 rules** on the DUT's master port: stability of pending AR/AW/W, beat alignment, burst ≤ `MAXB`, no 4 KiB
   crossing, size/burst constants, `WLAST`, contiguous strobes, W only after its AW, unique outstanding IDs, quiet reset.

## 2. Brief → test map

| Brief item (§10) | Test (`tb/tb_tests.svh`) | What is demonstrated |
|---|---|---|
| Zero-length handling | `t_zero_length` | single / interleaved / unmapped-address / all-zero chains; no data traffic; exactly one descriptor read and one record write |
| Single-byte transfers | `t_single_byte` | 8 × 8 source/destination byte offsets, host and SRAM destinations |
| Unaligned tails | `t_unaligned_tails` | 20 lengths around beat, burst and 4 KiB boundaries, random offsets |
| Multiple segments | `t_multi_segment` | random 1..12-element chains (host/SRAM/storage mixes, linked and array), gather and scatter |
| Long transfers | `t_long` | a 200 000-byte element; 63 and 64-descriptor chains (the limit); chunk-permuted translation |
| Concurrent reads/writes | all tests (the engine reads and writes concurrently by construction); `t_reorder_stats` asserts ≥ 2 outstanding reads and writes were reached | |
| Backpressure | `t_profiles` (profile 2: `ar/aw/w/r/b` ready/valid probabilities 40–60 %), `t_done_backpressure` | |
| Reordered responses | `t_profiles` 3 and 4, `t_reorder_stats`; `t_reorder_violation` (in-order DUT on reordering bus) | reordering and interleaving exercised (counters in the coverage line); an in-order DUT must raise `ERR_PROTOCOL` — proven **separately** for reordered read responses (write responses forced in order) and for reordered write responses (read responses forced in order), so one side's check cannot mask the other's |
| Domain violations | `t_domain_violations`, `t_multichannel` (attacker) | descriptor domain claim, foreign private memory read/write, read-only window, unmapped, off-window, record not writable, refused descriptor fetch; **zero bytes outside the permitted set move** |
| Invalid descriptors | `t_invalid_descriptors` | 31 cases at the default configuration (28–32 depending on `AW` and `TOTLOG2`): every validation rule of docs/02 §5 incl. cycles, self loops, over-long chains, overflow near 2^AW, overlap, head errors, bus error on fetch, chain total |
| Timeouts | `t_timeouts` | late responses (auto-recovery), read never answered, write response never returned; fencing visible in CSR; soft-reset recovery |
| Reset | `t_reset` | 12 hard/soft resets at pseudo-random points, 300 quiet cycles (any bus request fails), clean restart |
| Completion ordering | `t_completion_order`, `t_back_to_back` | queued commands complete in order, each only after its writes and record are acknowledged |
| Byte-accurate scoreboard | all | §1 |
| Cross-element hazards (`ORDERED`) | `t_ordered`; `t_random` / `t_multi_segment` (an ORDERED element reads what the previous element wrote in half of the cases) | head dependency A→B→C, **tail** dependency (element 1 reads the bytes element 0 commits last), 3-step chains of 1..64-byte elements; the scoreboard predicts the dependent values |
| Plus | `t_abort`, `t_bus_errors`, `t_csr_perf_trace`, `t_iommu_faults`, `t_random` | |

## 3. Configurations and seeds

`scripts/regress.py` builds the testbench for each configuration of the matrix and runs the **whole suite with three
seeds each** (random initial register state). Baseline matrix (single channel): defaults · **one outstanding
read+write with the minimum buffer** · 32/128/256/512-bit data · in-order bus · slow pipelined IOMMU (7 cycles, 4
outstanding) · deep queues with 32-beat bursts · small chain-total limit · 40-bit and 64-bit addresses · external IOMMU
interface (two variants) · negative test. Multichannel matrix only after the baseline passed: 2 and 4 channels, 4 channels
at 128-bit with a pipelined checker, 2 channels in-order. Results: `reports/regression.md`.

## 4. Mutation testing

`scripts/mutate.py` injects **29 deliberate bugs**, one at a time, into a copy of the RTL (completion before
acknowledge, refusals turned into approvals, domain claim unchecked, 4 KiB rule broken, destination offset ignored,
data off by one byte, CRC lane order, overflow/SEQ/overlap/ASID checks removed, chain-limit off by one, watchdog and
fence removed, AW before data complete, IOVA used as bus address, wrong sideband domain, zero-length elements emitted,
record not acknowledged, barrier ignored, strobes over the whole beat, write/read errors ignored, abort ignored, in-order
check disabled for reads and for writes, translation offset unchecked, unstable AW ID) and requires the full suite to
**fail**. Each mutant is built and run in the configuration that can reach it (`REORDER_OK=0` negative suite for the
ordering checks, external IOMMU for the translation re-check, defaults otherwise). Results and the first failing check
of each mutant: `reports/mutation.md`. A surviving mutant would be a hole in the verification.

**What the first full campaign found.** Of the first 28 mutants, **three survived** — all three were testbench holes, not RTL bugs:

* *M18 (ORDERED barrier ignored).* The dependent-copy test chained two multi-kilobyte elements; the second element
  starts at bytes the first wrote long before, so no hazard occurred. Fixed by tail-dependency and short multi-step
  chains, and by random dependent elements. (The mutant is now killed with a `WRONG DATA` from the scoreboard.)
* *M26 (in-order read check removed).* The negative test reordered read and write responses at once; the *write*-side
  check raised the expected `ERR_PROTOCOL`, so the broken read-side check went unnoticed. Fixed by forcing one response
  channel in order at a time (`cfg_r_inorder` / `cfg_b_inorder` in the slave model). The write-side twin became M29.
* *M27 (translation in-page offset not re-checked).* Run in the default configuration, where the translation comes from
  the trusted simulation table and the fault injection does not run. Fixed by running that mutant against the external
  IOMMU model; fault-injection mode 2 (beat-aligned wrong offset) then kills it.

After these fixes the whole regression matrix and the full campaign were re-run against the final testbench (results
below and in `reports/`).

## 5. Defects found and what each was

| # | Found by | Where | What |
|---|---|---|---|
| 1 | AXI stability monitor, profile tests | **RTL** | `aw_id` was "lowest free slot", recomputed every cycle: a B response freeing a lower slot changed the ID of a *pending* AW (AXI4 stability violation). Fixed: the slot is latched when the AW is first presented. |
| 2 | negative test (in-order DUT, reordering bus) | **RTL design gap** | after `ERR_PROTOCOL` the controller ignored the offending beat and then waited forever for a response it had decided to ignore. Fixed: a protocol error completes the transaction at once (no record) and **fences** the channel, like a timeout. |
| 3 | system TB | slave model | a burst whose last beat had arrived was still "needing data", so the next burst's beats were attributed to it |
| 4 | system TB | TB bookkeeping | outstanding-ID tracking survived a slave flush; a soft reset (which deliberately cancels requests) was reported as a withdrawn request; SLVERR writes were treated as committed |
| 5 | invalid-descriptor tests | TB | NULL pointer with only the low word cleared; self-loop descriptor that dropped `CPL_EN` (the DUT's "reserved field" answer was correct) |
| 6 | configuration matrix | TB | plausibility bound on the ACTIVE counter too tight for 128-bit; transfer lengths above the DUT's configurable total limit; reordering coverage required with `WR_OUT = 1` |
| 7 | randomised initial state | TB + simulation-only assertion | assertions and the reset check fired before the first reset edge took effect (not a design bug; gated) |
| 8 | build | tool | Verilator 5.020 inlines timing tasks at every call site (a first testbench produced a 1.3-million-line C++ function); arrays of queues generate invalid C++; variable-indexed part-select writes from timing tasks are not propagated to the DUT port copy; `fork` with an empty branch crashes. The testbench was restructured around them (package functions, ring buffers, scalar drivers) |
| 9 | mutation testing (M18) | **TB hole** | the `ORDERED` barrier could be deleted and no test failed; dependent elements only ever read bytes written long before |
| 10 | mutation testing (M26) | **TB hole** | the negative reorder test reordered both response channels, so a removed read-side check was masked by the write-side check |
| 11 | mutation testing (M27) | **mutation setup** | the translation-offset mutant was built without the external IOMMU, the only configuration that can reach the check |
| 12 | 2-channel configuration (multichannel reset test) | **RTL** | the soft reset restarted the channels, the walker, the controller and the checker but **not the AXI multiplexer**: its state (write-order FIFO, grant lock) survived and no longer matched the restarted channels. Fixed: the multiplexer is reset by the soft reset too (`core_rst_n`). A single-channel build cannot show it |
| 13 | review of the multichannel run | **RTL (hardening)** | the multiplexer could present an AW that its write-order FIFO had no room to record; `m_aw_valid` is now gated by that FIFO having room |
| 14 | review of the external-IOMMU tests | **RTL (hardening)** | the checker accepted an IOMMU response for any client with a pending request, including a client whose request had been refused locally and never sent; it now also requires that the request was actually sent to the IOMMU (`iom_q`), so a stray response cannot overwrite a local refusal |

Defects 1, 2 and 12–14 are the ones that changed the RTL during verification. Defects 1, 2 and 12 were found by a *monitor, negative
test or configuration run* rather than by a data compare, which is why the protocol checks live in the testbench and not
only in comments. Defects 9–11 were found by the mutation campaign and show what it is for: they are places where the
testbench would have stayed green with a broken design. (There was no external reviewer and no formal tool; "review"
means reading the RTL against the test results.)

## 6. Completion semantics, precisely

* "Committed" = the **B response** of the destination write was received with `OKAY` (AXI4), the same meaning as DataFabric
  rule R7 ("a write response is issued only after the write was performed"). The memory model in this testbench makes
  the write visible exactly when it hands the B response over.
* The record's B response is awaited before `done_valid`.
* On an error response (`SLVERR/DECERR`) the burst is **not** counted in `BYTES`; the rest of the transaction is drained.

## 6a. Results of the final run

| Check | Result | Report |
|---|---|---|
| Verilator `-Wall`, 8 configurations; 12 illegal-parameter sets must fail elaboration | 0 warnings; 12/12 refused | `reports/lint.md` |
| unit benches (burst planner exhaustive, byte buffer × 3 widths, CRC × 3 widths + golden check value, permission table × 3 latencies, package layout) | all pass | `reports/unit/summary.txt` |
| baseline regression matrix: 15 configurations × 3 seeds, full suite | 15/15 pass (45/45 runs) | `reports/regression.md` |
| multichannel matrix (after the baseline): 4 configurations × 3 seeds | 4/4 pass (12/12 runs) | `reports/regression_multi.md` |
| mutation campaign | 29/29 killed | `reports/mutation.md` |
| generic synthesis, 6 configurations | 0 check problems, 0 latches | `reports/synth/SUMMARY.md` |

The regression and mutation results were produced after the last testbench change (the mutation campaign's three
survivors, §4). **One later edit** touched the RTL: two comments in `silicaflux_dma_pkg.sv` (the descriptions of
`PC_PERM_LAT` and `PC_LAT_SUM`) were corrected after the performance review. Verilator's preprocessed output of the
whole file list (`verilator -E -f rtl/filelist.f`, comments removed) is **byte-identical** before and after
(3 647 lines), so the compiled design is unchanged; lint, the unit benches and a seed-1 run of `base`, `ch2`,
`ext_iommu` and `neg_order` were re-run on the final files and pass. The full matrices were not re-run for a
comment-only change.

## 7. Tool issues and how the flow is reproducible

`reports/tools.txt` records exact versions. The testbench is built at `-O0` (about a minute for the C++); simulations run
in seconds. The unit benches build in seconds. `make` targets and their expected outputs are listed in the top-level
README.
