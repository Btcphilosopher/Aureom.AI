# 04 — Integration guide

Top level: `rtl/silicaflux_cloud_dma.sv` (file list in `rtl/filelist.f`; `third_party/` files are vendored unmodified).
One clock `clk`, asynchronous-assert active-low reset `rst_n`.

## 1. Port groups

| Group | Signals | Notes |
|---|---|---|
| CSR | `csr_req_{valid,ready,write,addr[11:0],wdata}`, `csr_rsp_{valid,rdata,err}`, `irq` | single-cycle accept (`ready` = 1), response one cycle later; **privileged** |
| Command (per channel) | `cmd_valid/ready`, `cmd_head[64]`, `cmd_domain[DOM_W]`, `cmd_asid[4]` | accepted into a `CMDQ`-deep FIFO; `cmd_domain` is the **authoritative** domain (§4) |
| Completion (per channel) | `done_valid/ready`, `done_txn`, `done_status`, `done_err`, `done_fault`, `done_domain`, `done_bytes`, `done_crc`, `viol_evt` | `done_valid` holds until `done_ready`; the channel does not start the next command before the event is consumed |
| Memory master | `m_ar_*`, `m_r_*`, `m_aw_*`, `m_w_*`, `m_b_*` (AXI4 subset) + `m_{ar,aw}_{asid,domain}` | `r_ready`/`b_ready` constant 1; see §3 |
| IOMMU | `iommu_{req,rsp}_*` | `USE_EXT_IOMMU = 1`; contract in docs/03 §3; tie off when 0 |
| Permission-table programming | `ptbl_*`, `ptbl_rej` | `USE_EXT_IOMMU = 0` only (simulation model); tie off when 1 |

## 2. Submitting a transaction (software / queue front end)

1. Build the descriptor chain in memory (docs/02). Head 64-byte aligned.
2. Present `cmd_head` (IOVA of the head descriptor), `cmd_domain` (from the hardware binding of the submitter),
   `cmd_asid` (address space of the descriptors, normally 0) with `cmd_valid`; transfer when `cmd_ready`.
3. Wait for `done_valid` (or the interrupt, or poll `CH_STATUS`). `done_status` 0 = OK, 1 = ERROR, 2 = ABORTED;
   `done_err`/`done_fault` say why; `done_bytes` = destination bytes acknowledged; `done_crc` valid when `CRC_EN`
   and OK. If `CPL_EN`, the record at `CPL_ADDR` is committed before `done_valid`.
4. Never unmap or reuse the buffers of a transaction before its completion (or an abort has completed).

Command port timing: a command is accepted whenever the command FIFO has room; the channel executes commands strictly
in order, one at a time, and completes them in order (tested, `t_completion_order`).

## 3. Memory-port contract the platform must honour

| Item | Requirement |
|---|---|
| Protocol | AXI4 INCR; `size = log2(DW/8)` constant; the DMA never issues narrow, FIXED, WRAP, exclusive or locked transfers |
| Addresses | AR/AW addresses are beat-aligned **physical** addresses; bursts ≤ `MAX_BURST_BEATS`, never across 4 KiB |
| IDs | `ID_W = log2(NUM_CH) + 1 + log2(max(RD_OUT, WR_OUT))`; {channel, class, slot}; outstanding IDs unique. The slave/interconnect must return responses with the request's ID. Responses may be reordered across IDs only if `REORDER_OK = 1`; same-ID order is always required. |
| Write data | W follows AW order; the DMA presents W beats only after the AW was accepted, strobes are a contiguous run per beat |
| Write response | B = the write has been performed / accepted at the point of visibility; the DMA treats B as "committed". A weaker B (posted/early ack by an interconnect) weakens the completion guarantee accordingly: the platform decides what B means (docs/05 §"completion semantics") |
| Errors | `RRESP/BRESP != OKAY` → `ERR_BUS_*` for that transaction; the response data of an errored read is dropped |
| Reset | system reset must not deliver stale responses afterwards (SFB2 R11 contract); a **soft reset** likewise: quiesce the memory system *and the IOMMU* (outstanding translations) at the same time, because the core restarts with no memory of them. A stray IOMMU or bus response for a client that is not waiting is dropped and counted (`CSR PROTO`); one that arrives while the same client waits for a *new* answer cannot be told apart — hence the quiesce rule. The soft reset is **global**: it restarts every channel and the AXI multiplexer |
| SFB2 local SRAM | needs an AXI4→SFB2 slave adapter (none exists in the repository; docs/00_AUDIT.md) |

`asid` (4 bits) and `domain` sidebands are valid with every AR/AW: route on `asid` to the right target (host fabric,
SRAM, StorageCore window, …) and use `domain` for an independent second check.

## 3a. SFB2 note

The DataFabric SFB2 carries one single-beat transaction per port in order. A bridge from this AXI4 port to an SFB2
crossbar master can use one SFB2 master per outstanding burst or serialise bursts into single beats; either keeps
the DMA correct (the DMA never relies on more than in-order completion when `REORDER_OK = 0`) but caps bandwidth
at one beat per cycle per SFB2 port.

## 4. Domain binding (the point most integrations get wrong)

`cmd_domain` must be produced by hardware that knows who submitted the command — the queue/function the command
arrived on. In P61 terms: the **queue binding**. Software-writable fields (the descriptor's `DOMAIN`, a register the
tenant can write) may only be used as a *claim* to cross-check. If a tenant can pick `cmd_domain`, the tenant can pick
its own isolation.

## 5. CSR map (privileged, 32-bit, byte offsets in a 4 KiB window)

| Offset | Name | Access | Description |
|---|---|---|---|
| 0x000 | `ID` | RO | `0x5346444D` "SFDM" |
| 0x004 | `VERSION` | RO | `{ABI_MAJOR, ABI_MINOR}` = `0x0001_0000` |
| 0x008 | `CAPS0` | RO | `[7:0]` NUM_CH, `[15:8]` log2(DW/8), `[23:16]` AW, `[31:24]` DOM_W |
| 0x00C | `CAPS1` | RO | `[7:0]` MAX_BURST_BEATS (256 reads as 0), `[15:8]` RD_OUT, `[23:16]` WR_OUT, `[31:24]` log2(BUF_BYTES) |
| 0x010 | `CTRL` | RW | `[0]` enable (**0 at reset**: no command starts), `[1]` soft reset (W1S, self-clearing, 4 cycles), `[2]` trace enable, `[3]` clear counters+trace (W1S) |
| 0x014 | `STATUS` | RO | `[NUM_CH-1:0]` busy, `[16+:NUM_CH]` fenced |
| 0x018 | `IRQ_EN` | RW | `[ch]` done, `[16+ch]` error |
| 0x01C | `IRQ_STAT` | RW1C | sticky causes; `irq = |(IRQ_STAT & IRQ_EN)`. done: completion of a transaction with `IRQ_EN` in its head flags; error: any completion with status ≠ OK |
| 0x020 | `TIMEOUT` | RW | no-progress timeout, cycles (0 = disabled) |
| 0x024 | `MAX_CHAIN` | RW | runtime chain limit (clamped to the synthesised `MAX_CHAIN`) |
| 0x028 | `ASID_EN` | RW | bit per address space; default `0x1F` |
| 0x02C | `PROTO` | RO | saturating count of protocol events: a response nobody waits for (IOMMU), an ID that names no channel, a stray late B |
| 0x030 | `PERF_SEL` | RW | `{channel[15:8], id[7:0]}` |
| 0x034/0x038 | `PERF_LO/HI` | RO | counter value; reading LO latches HI (consistent 64-bit read) |
| 0x040 | `TR_STAT` | RO | `[15:0]` entries, `[31:16]` dropped events |
| 0x044/48/4C | `TR_W0..W2` | RO | head trace entry `{ts[31:0] arg[31:0] txn[15:0] code[7:0] ch[7:0]}` = W2,W1,W0 |
| 0x050 | `TR_POP` | WO | write 1 pops the head entry |
| 0x100 + 0x40·ch | channel block | | |
| +0x00 `CH_CTRL` | WO | `[0]` abort (W1S) |
| +0x04 `CH_STATUS` | RO | `[0]` busy, `[1]` fenced, `[2]` last valid, `[7:4]` last status |
| +0x08 `CH_ERR` | RO | `{txn[31:16], err[15:8], fault[7:4]}` of the last completion |
| +0x0C/0x10 `CH_ERR_ADDR_LO/HI` | RO | failing IOVA of the last completion |
| +0x14 `CH_BYTES`, +0x18 `CH_CRC`, +0x1C `CH_DOMAIN`, +0x20 `CH_DESCS` | RO | last completion |

Accessing an undefined offset, writing a read-only register, or a misaligned address returns `csr_rsp_err = 1`.

**Bring-up sequence.** (1) reset; (2) program the permission table (`ptbl_*`) or the IOMMU; (3) write `TIMEOUT`;
(4) write `CTRL = 1`; (5) submit commands. After a **soft reset** the CSR configuration and the permission table are
retained; after a **hard reset** both are lost and must be rewritten.

## 6. Error and fault codes

| ERR | Name | | ERR | Name |
|---|---|---|---|---|
| 0x01 | `DESC_ALIGN` | | 0x30 | `BUS_DESC` |
| 0x02 | `DESC_VERSION` | | 0x31 | `BUS_RD` |
| 0x03 | `DESC_OPCODE` | | 0x32 | `BUS_WR` |
| 0x04 | `DESC_FLAGS` | | 0x33 | `BUS_CPL` |
| 0x05 | `DESC_RSVD` | | 0x34 | `TIMEOUT` |
| 0x06 | `BAD_ASID` | | 0x35 | `PROTOCOL` |
| 0x07 | `LEN_TOO_BIG` | | 0x36 | `XLAT` (reserved) |
| 0x08 | `TOTAL_TOO_BIG` | | 0x37 | `ABORT` |
| 0x09 | `ADDR_RANGE` | | 0x38 | `INTERNAL` (reserved) |
| 0x0A | `ADDR_OVERFLOW` | | 0x20 | `DOMAIN_MISMATCH` ⚑ |
| 0x0B | `OVERLAP` | | 0x21 | `PERM_DESC` ⚑ |
| 0x0C | `CHAIN_SEQ` | | 0x22 | `PERM_SRC` ⚑ |
| 0x0D | `CHAIN_TXN` | | 0x23 | `PERM_DST` ⚑ |
| 0x0E | `CHAIN_TOO_LONG` | | 0x24 | `PERM_CPL` ⚑ |
| 0x0F | `CHAIN_NULL` | | | ⚑ = isolation violation, raises `viol_evt` |
| 0x10 | `CPL_ALIGN` | | | |

`FAULT` (with ⚑ and refusals): 1 NO_MAP, 2 PERM, 3 DOMAIN, 4 RANGE, 5 XLAT, 6 ASID, 7 LEN.

## 7. Integration checklist

- [ ] `cmd_domain` driven by hardware binding of the submitter (§4)
- [ ] AXI4 port connected through an interconnect that preserves IDs and returns errors; B semantics decided (§3)
- [ ] `asid` routing and `domain` sideband checks implemented downstream
- [ ] IOMMU implements the contract of docs/03 §3 **or** the platform accepts the simulation table as a model only
- [ ] CSR and `ptbl_*` unreachable by tenants
- [ ] Platform quiesces a channel (abort, wait `done`, soft reset) before unmapping its buffers
- [ ] Reset sequencing: no stale bus responses after soft or hard reset
- [ ] `TIMEOUT` set to a value larger than the worst memory latency × outstanding bursts
- [ ] `BUF_BYTES ≥ 2·MAX_BURST_BEATS·DW/8` (enforced), RD_OUT/WR_OUT chosen against the bus latency-bandwidth product (docs/06)
