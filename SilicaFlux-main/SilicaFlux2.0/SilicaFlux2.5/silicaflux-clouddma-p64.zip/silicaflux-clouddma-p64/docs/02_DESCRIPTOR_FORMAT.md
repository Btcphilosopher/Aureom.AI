# 02 — Descriptor format, chains and completion record (ABI version 1.0)

Single source of truth: `rtl/silicaflux_dma_pkg.sv` (flat bit positions, flags, error codes). The testbench builds its
descriptors from the same constants but writes each field itself; `tb/tb_pkg_layout.sv` proves the struct views and the
flat positions describe the same bits.

## 1. Conventions

| Item | Rule |
|---|---|
| Byte order | **Little endian.** A descriptor is 16 × 32-bit words; word *n* is bytes `4n..4n+3` (byte `4n` = bits `[7:0]`). A 64-bit field is two words, **low word first**. Byte *j* of a descriptor is memory byte `base + j`. This is the byte order of the AXI4 data lanes and of SFB2. |
| Alignment | Descriptor **64-byte aligned**. `NEXT_PTR` 64-byte aligned. Completion record **32-byte aligned**. Source and destination data addresses: **any byte alignment**. |
| Address width | Descriptor addresses are 64 bits; the engine's `AW` (≤ 64) bounds what is reachable: every address and every `addr + len` is checked against `2**AW` in 65-bit arithmetic. |
| Address spaces | `SRC_ASID`, `DST_ASID`, `CPL_ASID` (4 bits): 0 host, 1 local SRAM, 2 storage, 3 network, 4 compute. 5..15 reserved → `ERR_BAD_ASID`. A CSR mask (`CSR_ASID_EN`, default `0x1F`) can disable spaces. Descriptors always live in the address space named by the **command** (`cmd_asid`), normally 0. |
| Lengths | `LENGTH` ≤ `2**MAX_ELEM_LOG2` (default 2²⁴ = 16 MiB) per element; chain total ≤ `2**MAX_TOTAL_LOG2` (default 2³⁰); chain ≤ `min(MAX_CHAIN, CSR_MAX_CHAIN)` descriptors (default 64; the `SEQ` field limits any chain to 65 535). |
| Versioning | `W0[7:0] = 1`. Any other value → `ERR_DESC_VERSION`. Reserved fields must be zero; a later minor revision may define them, which is why they are checked. |

## 2. Descriptor (64 bytes)

```
word  bits       field        meaning
 0    [7:0]      VERSION      1
      [15:8]     OPCODE       0 = COPY (copy LENGTH bytes SRC → DST); 1..255 reserved
      [31:16]    FLAGS        see §3
 1    [15:0]     TXN_ID       transaction id chosen by software; echoed in the completion record, trace and completion port
      [31:16]    DOMAIN       the tenant the submitter CLAIMS to be; must equal the hardware binding of the command port
 2    [3:0]      SRC_ASID
      [7:4]      DST_ASID
      [11:8]     CPL_ASID     head only (zero elsewhere)
      [31:12]    reserved     must be 0
 3    [31:0]     LENGTH       bytes of THIS element (0 = no-op element, see §5)
 4,5  [63:0]     SRC_ADDR     source address (IOVA in the source address space)
 6,7  [63:0]     DST_ADDR     destination address (IOVA in the destination address space)
 8,9  [63:0]     NEXT_PTR     next descriptor (linked mode only); 0 and ignored in array mode and on the LAST descriptor
10,11 [63:0]     CPL_ADDR     head only: where the completion record is written (0 unless CPL_EN)
12    [15:0]     SEQ          position in the chain: 0, 1, 2, …
      [31:16]    reserved     must be 0
13..15           reserved     must be 0
```

## 3. Flags (`W0[31:16]`)

| Bit | Name | Meaning |
|---|---|---|
| 0 | `LAST` | last descriptor of the chain (**chain termination**) |
| 1 | `ARRAY` | the next descriptor is at *this + 64* (array mode); otherwise `NEXT_PTR` (linked mode). Illegal together with `LAST`. |
| 2 | `HEAD` | first descriptor of the chain; **set on the head and only on the head** |
| 3 | `ORDERED` | barrier: do not start reading this element before every earlier write was acknowledged (see §6) |
| 4 | `CPL_EN` | head only: write a completion record to `CPL_ADDR` |
| 5 | `CRC_EN` | head only: CRC-32 over the whole transferred byte stream |
| 6 | `IRQ_EN` | head only: raise the channel interrupt on completion |
| 7..15 | — | reserved, must be 0 |

Head-only flags set on a later descriptor → `ERR_DESC_FLAGS`.

## 4. Scatter-gather

* **Chained (linked) or array-based.** A chain is a sequence of elements `{src_i, dst_i, len_i}`; element *i* copies
  `len_i` bytes from `src_i` to `dst_i`. Many noncontiguous source buffers into one contiguous destination (gather),
  one source into many destinations (scatter), or any mix are expressed by the choice of addresses. Source and
  destination are cut into bursts **independently**: the byte stream between them is continuous across element
  boundaries, so segment boundaries on the two sides need not line up.
* **Partial first and last beats.** Every transfer, every element, works at byte granularity: the first beat of a
  burst may carry unused low lanes, the last beat unused high lanes; writes use byte strobes, so no byte outside
  `[dst, dst+len)` is ever written; reads fetch whole aligned beats inside the checked envelope.
* **Chain termination.** `LAST` ends the chain. A non-`LAST` descriptor must have either `ARRAY` or a valid
  `NEXT_PTR` (non-zero → `ERR_CHAIN_NULL`, unaligned → `ERR_DESC_ALIGN`, ≥ 2^AW → `ERR_ADDR_RANGE`).
* **Cycles.** Two independent defences: (1) `SEQ` must equal the descriptor's position, so a descriptor visited a
  second time (or any descriptor out of order) fails at the **first revisit** with `ERR_CHAIN_SEQ`; (2) at most
  `max_chain` descriptors, so even a memory image that changes while it is being walked (the DMA never re-reads a
  descriptor, but software can rewrite later ones) terminates (`ERR_CHAIN_TOO_LONG`) and the byte total is capped
  (`ERR_TOTAL_TOO_BIG`).
* **Unsupported patterns are rejected, not interpreted:** nested/indirect chains, `LAST`+`ARRAY`, descriptors outside
  the descriptor address space, `NEXT_PTR` on the last descriptor, reserved fields.

## 5. Validation (per descriptor, from one internal copy, first failing rule wins)

| # | Rule | Error |
|---|---|---|
| 0 | command: head 64-byte aligned, `< 2^AW`, `head+64 ≤ 2^AW`, descriptor ASID enabled | `ERR_DESC_ALIGN` / `ERR_ADDR_RANGE` / `ERR_ADDR_OVERFLOW` / `ERR_BAD_ASID` |
| 1 | fetch permitted by the permission checker (read, own domain) | `ERR_PERM_DESC` |
| 2 | fetch answered OKAY | `ERR_BUS_DESC` |
| 3 | `VERSION == 1` | `ERR_DESC_VERSION` |
| 4 | `OPCODE == 0` | `ERR_DESC_OPCODE` |
| 5 | `DOMAIN == hardware binding` | `ERR_DOMAIN_MISMATCH` (isolation violation) |
| 6 | `SEQ == position` | `ERR_CHAIN_SEQ` |
| 7 | non-head: `TXN_ID == head's` | `ERR_CHAIN_TXN` |
| 8 | flags: no reserved bit, `HEAD ⇔ position 0`, head-only flags only on the head, not `LAST`+`ARRAY` | `ERR_DESC_FLAGS` |
| 9 | reserved fields zero; `CPL_ADDR`/`CPL_ASID` zero unless head with `CPL_EN`; `NEXT_PTR` zero on `LAST`/array | `ERR_DESC_RSVD` |
| 10 | head with `CPL_EN`: `CPL_ADDR` non-zero and 32-byte aligned | `ERR_CPL_ALIGN` |
| 11 | `SRC_ASID`, `DST_ASID` (and `CPL_ASID`) enabled | `ERR_BAD_ASID` |
| 12 | `LENGTH ≤ 2**MAX_ELEM_LOG2` | `ERR_LEN_TOO_BIG` |
| 13 | running total `+ LENGTH ≤ 2**MAX_TOTAL_LOG2` (33-bit sum) | `ERR_TOTAL_TOO_BIG` |
| 14 | `SRC`, `DST`, `CPL` `< 2^AW` | `ERR_ADDR_RANGE` |
| 15 | `LENGTH > 0`: `SRC+LENGTH`, `DST+LENGTH ≤ 2^AW` (65-bit); `CPL+32 ≤ 2^AW` | `ERR_ADDR_OVERFLOW` |
| 16 | `LENGTH > 0`, same ASID: `[SRC,SRC+LEN)` and `[DST,DST+LEN)` do not intersect | `ERR_OVERLAP` |
| 17 | not `LAST`: linked → `NEXT_PTR` rules above; array → `this+128 ≤ 2^AW` | see §4 |
| 18 | not `LAST`: `SEQ+1 < max_chain` | `ERR_CHAIN_TOO_LONG` |

Rules 14–16 are skipped for `LENGTH = 0` except 14 (addresses must still be in range) — so a zero-length element
**never causes a bus access or a permission query**, even at unmapped addresses, but is not free of validation.

**Zero length is legal.** A zero-length element is a validated no-op (counted in `DESCS`, no traffic). A chain whose
total is zero completes `ST_OK` with `BYTES = 0` (and still writes its completion record if requested).

**Not atomic.** Validation is just-in-time: a bad descriptor `k` stops the chain at `k`; elements `0..k-1` were
individually validated and **do execute completely** (deterministic "valid prefix executes"). Software that needs
all-or-nothing must validate the chain itself before submitting.

## 6. Overlap and ordering between elements

* Within one element, source and destination in the same address space may not overlap (rejected): the engine has no
  `memmove` semantics.
* Between elements there is **no implicit ordering of memory effects**: reads of element *i+1* may be issued before the
  writes of element *i* are acknowledged. If element *i+1* reads what element *i* writes, set `ORDERED` on element
  *i+1*: its reads do not start until every earlier write is acknowledged and the buffer is empty. (Tested: dependent
  copy A→B→C, `tb_tests.svh t_ordered`.) Without `ORDERED` such a chain has undefined *data*, but never an isolation
  problem: every access is checked regardless.

## 7. Completion record (32 bytes, written to `CPL_ADDR` when `CPL_EN`)

```
word 0  [3:0] STATUS (0 OK, 1 ERROR, 2 ABORTED)  [7:4] FAULT  [15:8] ERR  [31:16] TXN_ID
word 1  [15:0] DOMAIN   [31:16] DESCS  (descriptors handed to the data path)
word 2  BYTES  (destination bytes whose write was ACKNOWLEDGED)
word 3  CRC32  (valid iff FLAGS.CRC_VALID)
word 4,5 ERR_ADDR (64-bit IOVA of the failing access / descriptor, else 0)
word 6  LATENCY (cycles from the start of execution, when the command leaves the command FIFO, to the last data acknowledgement; saturates at 65 535)
word 7  [15:0] FLAGS (0 CRC_VALID, 1 COMMITTED, 2 VIOLATION)   [31:16] MAGIC 0xD0C1
```

* The record is written as **one INCR burst through the permission checker** (write, own domain, `CPL_ASID`), and
  completion is signalled only after its B response. A poller must treat the record as published only through the
  completion event/interrupt/CSR; word order inside one burst is not an ordering guarantee (the magic is the last
  word so that in-order buses publish it last).
* Written for `ST_OK`, `ST_ERROR` and `ST_ABORTED` whenever the head descriptor had been validated with `CPL_EN`.
  **Not written** on `ERR_TIMEOUT` (the bus is presumed stuck), when the head itself was rejected (nothing in it is
  trusted), or when the record write is itself refused (`ERR_PERM_CPL`) or fails (`ERR_BUS_CPL`; then the data is
  already committed, `BYTES` in CSR/completion port tell how much).
* `COMMITTED` = status OK: every data byte of the transaction was acknowledged. `CRC_VALID` = `CRC_EN` and no error.

## 8. Error codes

`0x01–0x10` descriptor/command validation (no byte of the failing element moved) · `0x20–0x24` **isolation
violations** (counted separately, raise `viol_evt`) · `0x30–0x38` execution faults (bus error, timeout, protocol
error, translation, abort, internal). The numeric list with names is in the package and mirrored in
`docs/04_INTEGRATION.md` §6. `FAULT` (4 bits) refines permission errors: 1 no mapping, 2 permission, 3 mapped for
another domain, 4 starts inside a mapping and leaves it, 5 translation failure, 6 address space disabled, 7 request
violates the checker contract.
