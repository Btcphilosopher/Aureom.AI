# 03 — Memory protection, permission checking and the IOMMU interface

> *A tenant ID alone does not provide isolation.* A domain number in a descriptor is a label software can lie about.
> This design never trusts it: the domain is bound by hardware at the command port, and **every memory transaction**
> is validated by a checker whose answer — not the descriptor — forms the bus address.

## 1. What is checked, and where

| Brief item (§5) | Enforced by | Notes |
|---|---|---|
| **Domain ownership** | `cmd_domain` (hardware binding of the submitter) is the only domain the engine uses; the descriptor's `DOMAIN` is a *claim* compared against it for **every descriptor** (`ERR_DOMAIN_MISMATCH`, an isolation violation). The bound domain is sent to the IOMMU with every request and appears as the `domain` sideband on every AR/AW. | A channel's binding is latched when the command starts and cannot change mid-transaction. |
| **Address range** | walker (65-bit arithmetic: every address `< 2^AW`, `addr+len ≤ 2^AW`), checker (`addr+bytes ≤ 2^AW` per burst), IOMMU (mapping range) | no wrap-around can alias a low address |
| **Read/write permission** | IOMMU / table: the request says read or write; a mapping must grant that right | descriptor fetch = read, source = read, destination = write, completion record = write |
| **Address translation result** | the checker does **not** trust the response blindly (§4) | |
| **Transaction length** | walker (element ≤ `2^MAX_ELEM_LOG2`, chain total), planner (burst ≤ `MAXB` beats, ≤ 4 KiB, no 4 KiB crossing), checker (1..4096 bytes) | |

The result of the check is *the address*: `ar_addr`/`aw_addr` are the `pa` returned for that burst. There is no
datapath from a descriptor field to a bus address that bypasses the checker (verified by the monitors: every burst
on the bus must lie inside a physical range the domain bound to that channel may access with that permission —
`tb/tb_pkg.sv pa_allowed`, mutation M-series in docs/05).

## 2. What each check covers — and what it deliberately does not

* **Per burst, not per byte.** A burst is at most 4 KiB, never crosses a 4 KiB boundary, and translation granules are
  ≥ 4 KiB, so one lookup validates the whole burst exactly.
* **Envelope, not payload.** Reads fetch whole aligned beats. The checker is asked about the **beat-aligned
  envelope** `[floor(addr), ceil(addr+len))`, so no byte outside the permitted region is ever *touched* by a read beat.
  Writes use byte strobes, but the checker still validates the envelope (the bus carries whole beats). Mappings must
  therefore be multiples of the 4 KiB granule (the simulation table enforces it); an IOMMU with smaller regions would
  refuse a transfer whose envelope pokes outside the last page — conservative and safe.
* **Check-ahead.** The planners request the check for the next burst while earlier bursts are in flight to hide the
  latency; a write burst is checked before its data is available and issued only when the data is complete. A
  permission **granted** applies to that burst; if the platform *revokes* a mapping, bursts already authorised
  (a bounded number per channel: the outstanding bursts, one granted burst per planner, the descriptor fetch and the record — at most `RD_OUT + WR_OUT + 4`) may still complete. The platform must quiesce the channel (abort, wait for
  `done`, or soft reset) before unmapping a buffer — the same rule HostLink states (`04_DMA_AND_ISOLATION.md` §4).
* **Not claimed:** side-channel isolation (shared buffers, shared bus, shared checker are observable through
  latency), denial-of-service fairness beyond round-robin, protection against a compromised management plane (the
  CSR window and the permission-table programming port must never be reachable by a tenant).

## 3. The IOMMU interface (what a real IOMMU implements)

Request/response, ready/valid, responses **in request order**, one response per request. Signals (top level, names
as in `silicaflux_cloud_dma.sv`):

| Signal | Dir (DMA) | Meaning |
|---|---|---|
| `iommu_req_valid/ready` | out/in | request handshake (valid never depends on ready; held until accepted) |
| `iommu_req_domain[DOM_W]` | out | the **hardware-bound** domain of the channel |
| `iommu_req_asid[3]` | out | address space (0 host, 1 SRAM, 2 storage, 3 network, 4 compute) |
| `iommu_req_write` | out | 1 = the DMA will write this range |
| `iommu_req_addr[AW]` | out | IOVA of the **beat-aligned envelope start** |
| `iommu_req_bytes[16]` | out | envelope length, 1..4096, never crosses a 4 KiB boundary |
| `iommu_req_id` | out | opaque client tag, echoed |
| `iommu_rsp_valid/ready`, `iommu_rsp_id` | in/out | `ready` is constant 1 |
| `iommu_rsp_ok` | in | the **whole** range lies in mappings of this domain+asid granting the access |
| `iommu_rsp_fault[4]` | in | refusal cause, see below (`FAULT_*`) |
| `iommu_rsp_pa[AW]` | in | physical address of `iommu_req_addr` |

Contract the DMA relies on and re-checks: the translation of the whole range is contiguous (mappings are
multiples of 4 KiB), `pa` is beat aligned and keeps the in-page offset of the request, and `pa + bytes ≤ 2^AW`.
A response that violates it is converted into a refusal with `FAULT_XLAT` (reported as `ERR_PERM_SRC/DST/DESC/CPL` according to the client) — the address is never used.
A response for a client that is not waiting is **dropped** (so a faulty IOMMU cannot make a second grant appear).
`PERM_OUT` limits the requests outstanding at the IOMMU (responses in order).

Fault causes (`FAULT_*`): `1 NO_MAP`, `2 PERM` (mapped, wrong right), `3 DOMAIN` (the range is mapped **for another
domain** — only the simulation table can tell; a real IOMMU reports `NO_MAP`), `4 RANGE` (starts in a mapping, leaves
it — unreachable end to end because mappings are 4 KiB multiples and bursts never cross 4 KiB; exercised in the table
unit test), `5 XLAT`, `6 ASID` (address space disabled), `7 LEN` (checker-contract violation).

## 4. The simulation permission table (`sfdma_perm_table`)

Used when `USE_EXT_IOMMU = 0`. A bring-up/verification model of the IOMMU contract, **not** a hardware isolation
mechanism on its own.

* Entries `{valid, domain, asid, base, size, pa, perm(R/W)}`, `PERM_ENTRIES` of them, programmed through the `ptbl_*`
  port (the management plane's job). An entry is **refused** (and counted) unless base, size and pa are multiples of
  4 KiB, size > 0, `base+size ≤ 2^AW` and `pa+size ≤ 2^AW`. Invalidation is always allowed.
* Lookup (combinational on the request): hit = an entry of the same domain+asid contains the whole range and grants the
  access; lowest index wins when several match. No hit → `PERM` > `RANGE` > `DOMAIN` > `NO_MAP`.
* Latency `PERM_LAT` (≥ 1), in-order, back-pressured by `rsp_ready`.
* **Verified** against an independent 64-bit reference with random entries (including illegal ones) and random
  requests: ~18 000 verdicts per run at latencies 1, 2 and 5, all five verdict classes covered (`tb/tb_perm_table.sv`),
  plus end-to-end by the system testbench's independent translation mirror.

## 5. Platform requirements for real isolation

1. The DMA's memory port must be the **only** path from this engine's domain to memory (no bypass, no peer-to-peer
   around the IOMMU — ACS on a PCIe path, the same as HostLink's rule).
2. A real IOMMU must implement the contract of §3, with translation enforced for every `(domain, asid)`.
3. The `domain` sideband on AR/AW is for a *second*, independent check (a memory firewall or the IOMMU itself): it
   equals the channel's binding on every transaction (monitored).
4. The command port's `cmd_domain` must come from the hardware path that authenticates the submitter (queue binding,
   SR-IOV function id), never from software-controlled data.
5. The CSR window and `ptbl_*` must be reachable only by the privileged management plane.
6. Quiesce a channel before changing the mappings it uses (§2).
