# 07 — Synthesis (generic Yosys; no PDK)

> **What this is and is not.** The numbers below are *generic gate counts* from Yosys 0.33 mapping the design to
> `AND/NAND/OR/NOR/XOR/XNOR/MUX` + flip-flops. There is **no cell library, no memory macro, no timing constraint, no
> place-and-route**. They say whether the RTL is synthesizable and where its logic goes; they are **not** an area in
> µm², not a frequency, not a power figure, and not a claim that the design closes timing anywhere.

## 1. Flow

`scripts/synth.sh <name> [PARAM=value …]` fills `synth/synth_dma.ys.tmpl` and runs Yosys:

```
read_verilog -defer -sv -DSYNTHESIS <rtl/filelist.f>      # SYNTHESIS excludes the simulation-only assertions
hierarchy -check -top silicaflux_cloud_dma -chparam …
proc ; flatten ; opt_clean
check -assert            -> reports/synth/<name>.check.txt      (must report 0 problems)
memory -nomap ; opt -full ; stat   -> <name>.stat_pre.txt      (before technology mapping)
select -count t:$dlatch t:$adlatch -> <name>.latches.txt        (must be 0)
memory_map ; techmap ; opt -fast ; abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX ; opt_clean ; stat -> <name>.stat.txt
```

`scripts/synth_all.sh` runs the standard configurations and writes `reports/synth/SUMMARY.md`;
`scripts/synth_modules.sh` keeps the hierarchy and reports cells per module (`reports/synth/modules.txt`).
One configuration takes about 5 minutes. Illegal parameter combinations fail elaboration (docs/01 §8).

## 2. Results

| config | parameters | generic cells | flip-flops | latches | `check -assert` problems |
|---|---|---|---|---|---|
| base | defaults: 1 channel, 64-bit, 16-beat bursts, 4 + 4 outstanding, 1 KiB buffer, 16 table entries | 256 865 | 19 298 | 0 | 0 |
| one_out | `RD_OUT=1 WR_OUT=1 ELQ=1 CMDQ=1 BUF_BYTES=256` (the brief's starting point) | 116 318 | 12 299 | 0 | 0 |
| dw128 | `DW=128 BUF_BYTES=4096` | 1 421 141 | 43 882 | 0 | 0 |
| nocrc | `CRC_ON=0` | 253 450 | 19 200 | 0 | 0 |
| ch2 | `NUM_CH=2` | 474 764 | 33 086 | 0 | 0 |
| ext_iommu | `USE_EXT_IOMMU=1` (no simulation permission table) | 226 181 | 16 749 | 0 | 0 |

(from `reports/synth/SUMMARY.md`; the flat result includes cross-module optimisation.)

* Every configuration elaborates, passes `check -assert` with 0 problems and has **0 latches**.
* The same RTL also passes Verilator `-Wall` with 0 warnings in 8 configurations (reports/lint.md).
* Going from one channel to two costs 1.85× the cells (not 2×): each channel replicates its walker, burst controller and
  data buffer (and its 32 counters inside `sfdma_perf`), while the permission table, CSR block, trace FIFO and the
  multiplexer/checker infrastructure are shared.
* The CRC is small: the `sfdma_crc` module is 1 137 cells at `DW=64` (0.4 %); building without it (`CRC_ON=0`) removes
  3 415 cells and 98 flops in the flat run, which also drops the logic that feeds and reports it.
* Removing the simulation permission table (`USE_EXT_IOMMU=1`) saves 30 684 cells and 2 549 flops; a real IOMMU is then
  outside this block.

## 3. Where the cells go (default configuration, hierarchy kept)

Cell counts by module type from `reports/synth/modules.txt` (the hierarchy total, which counts every instance, is
264 103 cells and 19 881 flops; the module rows below add up to 263 708 because a few small modules, e.g. the burst
planner, are instantiated several times; the flat run above is smaller again because flattening optimises across
module boundaries):

| module | cells | flops | share of cells |
|---|---|---|---|
| `sfdma_bytebuf` (data buffer, 1 KiB) | 185 424 | 8 192 | 70 % |
| `sfdma_perm_table` (simulation IOMMU, 16 entries) | 28 826 | 2 584 | 11 % |
| `sfdma_perf` (32 counters + 4 watermarks × 48 bit) | 16 961 | 1 600 | 6.4 % |
| `sfd_fifo` — trace FIFO (96 bit × 32) | 8 496 | 3 088 | 3.2 % |
| `sfdma_burst_ctrl` | 7 202 | 1 829 | 2.7 % |
| `sfdma_desc_walker` | 6 381 | 1 076 | 2.4 % |
| `sfdma_channel` | 4 226 | 639 | 1.6 % |
| `sfdma_csr` | 1 890 | 218 | 0.7 % |
| `sfdma_perm_checker` | 1 688 | 165 | 0.6 % |
| `sfdma_crc` | 1 137 | 32 | 0.4 % |
| `sfdma_trace` | 873 | 276 | 0.3 % |
| `sfd_fifo` — command FIFO, `sfdma_burst_plan`, top, `sfd_rr_arb`, `sfdma_axi_mux` (a pass-through at `NUM_CH = 1`) | 604 | 182 | 0.2 % |

(The two `sfd_fifo` rows are the same vendored module with different parameters; the trace FIFO is identified by its
96-bit × 32-deep geometry (3 072 data flops).)

### What this means

1. **The data buffer is the design's cost, and it is written as behavioural storage.** `sfdma_bytebuf` is a byte ring with a
   position-addressed write port (every byte position selects among the `W` incoming lanes) and a read port (every
   output lane selects among all positions), mapped here to flip-flops and multiplexers. Its cell count grows with
   `BUF_BYTES × W`: 185 k cells at 1 KiB / 8 B, and 1.42 M cells in total at 4 KiB / 16 B (`dw128`). A real
   implementation would put the storage in an SRAM macro behind barrel rotators on the way in and out; **that was not
   designed, not synthesised and not verified**, so the buffer figures here should not be read as an estimate of such an
   implementation. The architecture (space reserved at read issue, writes by stream position, no reorder buffer) does
   not depend on how the storage is built, which is why the buffer is isolated in one module (docs/01 §3).
2. **Control is small.** Walker, burst controller, channel logic, checker, CSR and CRC together are about 22.5 k cells of
   the 264 k (8.5 %); the permission checker alone, the protection path of the engine, is 0.6 %.
3. **The simulation permission table is not free**, but it is not part of a production build (`USE_EXT_IOMMU = 1`).
4. **The performance/trace plane costs about 10 %** (counters 6.4 %, trace FIFO + logic 3.5 %); `TRACE_DEPTH` and
   `PC_W` are parameters if that matters.

## 4. Not done

No timing analysis (so no frequency), no technology mapping, no memory-macro mapping, no area or power estimate, no
power-intent/DFT/CDC analysis (single clock domain by construction), no gate-level simulation. Anything beyond the
table above would need a target library and flow that this repository does not contain.

## 5. Reproduce

```
bash scripts/synth.sh base                        # one configuration
bash scripts/synth.sh ch4 NUM_CH=4 DW=128         # any parameters of docs/01 §8
bash scripts/synth_all.sh                         # the six standard configurations
bash scripts/synth_modules.sh                     # per-module breakdown
```
