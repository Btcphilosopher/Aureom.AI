# 08 — Limitations: what this is **not**

Read this before relying on anything in this directory.

## Evidence level

* **Everything is simulation.** The RTL was simulated with Verilator 5.020 (system testbench and unit benches) and
  elaborated/synthesised with Yosys 0.33 (generic cells, no PDK). **No FPGA, no place-and-route, no silicon, no timing
  closure, no power analysis.** No frequency, area (µm²) or power number is claimed anywhere. Generic cell counts are a
  complexity indicator only.
* **No formal verification** was done in this project (the earlier P61/P63 projects had formal proofs for parts of their
  blocks; none were reused or extended). Safety properties are checked by simulation monitors (protocol checker,
  unauthorised-access monitor, byte-accurate scoreboard) and by mutation testing — not proven.
* **One simulator** for the system testbench. Icarus Verilog 12 is installed but cannot run the system testbench
  (SystemVerilog constructs); no cross-simulator result exists for it. Verilator 5.020 itself needed several
  workarounds (docs/05 §"tool issues"); results are as reliable as that version.
* **Directed + constrained-random, not exhaustive.** Coverage is reported as functional counters (reordering exercised,
  outstanding depth reached, error codes observed), not as code/toggle coverage from a coverage tool.
* **Mutation testing samples, it does not cover.** 29 hand-picked bugs were all killed (after three testbench holes
  were closed); that is evidence the testbench is sensitive to those faults, not a measure of its completeness. Two kills
  (M23, M24) are hangs, and M13 is caught first by an RTL simulation assertion (the scoreboard alone also catches it).
* The **simulation-only assertions** in the RTL are excluded from synthesis (`SYNTHESIS`) and exist only in the Verilator runs.
* The **testbench IOMMU and memory are models written for this project**; real systems add behaviours they do not
  have (posted writes acknowledged early, link-level retries, address-dependent latency, ATS/PASID).

## Protection

* `sfdma_perm_table` is a **verified model of an IOMMU contract**, not a hardware isolation mechanism. Real isolation
  needs the platform conditions of docs/03 §5 (single path to memory, real IOMMU, authenticated command binding,
  privileged CSR/table access).
* Permission is evaluated **per burst, ahead of use**. A mapping revoked while a burst is authorised-but-in-flight
  does not stop that burst; the platform must quiesce first.
* Not claimed: side-channel isolation, denial-of-service fairness beyond round-robin, secure boot/firmware, protection
  against a compromised management plane, confidentiality of the data buffer (no scrubbing between transactions —
  stale bytes stay in the buffer until overwritten; they are never *readable* by another domain through this block, but a
  platform that cares must scrub or partition).
* The CRC (IEEE 802.3) is an **accidental-error check**: linear, unkeyed, no protection against a malicious modifier.
  There is no ECC/parity on the buffer or descriptors.
* Mappings must be multiples of 4 KiB; an IOMMU with finer regions will refuse transfers whose beat envelope leaves
  the last page (conservative).

## Function

* **Chains are not atomic**: a bad descriptor stops the chain after the already-validated prefix has executed; nothing
  is rolled back on any error (abort, timeout, bus error) — acknowledged bytes stay written.
* **No `memmove`**: overlapping source/destination inside one element is rejected; cross-element hazards need `ORDERED`.
* One operation (`COPY`); no fill, no compare, no gather list on one side only; element length ≤ 2²⁴ bytes.
* One transaction at a time **per channel** (descriptor fetch of the next command does not overlap the tail of the
  previous one); parallelism comes from channels. Descriptor prefetch across commands is an open optimisation.
* After a **timeout or protocol error the channel is fenced** and needs either every outstanding response or a soft
  reset; a bus that never answers wedges the channel until the platform resets it.
* Write completion means "B response received". If the interconnect acknowledges writes early (posted), the
  guarantee is only as strong as that acknowledgement; the platform decides (docs/04 §3).
* `REORDER_OK = 1` absorbs any interleaving **across IDs**. The DMA never needs same-ID reordering and does not
  support it.
* Data width 32..512 bits; bursts ≤ 4 KiB and ≤ 256 beats; `AW ≤ 64`.
* The byte buffer is behavioural storage with a W² rotation network; for wide buses (≥ 256 bit) an SRAM-macro based
  buffer with barrel rotators is the intended implementation and is **not** done.

## Platform pieces that do not exist in the repository

IOMMU/SMMU, AXI4→SFB2 slave adapter, PCIe endpoint/VirtIO front end that supplies `cmd_domain`, StorageCore /
NetworkCore / compute-engine targets, ControlCore firmware and driver. The DMA exposes the interfaces for them; none was
integrated.

## Performance numbers

All figures in docs/06 are **simulation cycles** against a behavioural memory model (fixed latency, ideal handshakes
unless stated). They show the architecture's sensitivity to latency, outstanding transactions, burst size, buffer depth,
permission latency and channel count; they are not predictions for any silicon or FPGA. Instrument limits: the
transaction-latency counter (and the record's `LATENCY` word) saturates at 65 535 cycles; burst utilisation is 1.00 in
every measured workload because none uses short bursts; the data buffer's gate count (docs/07) is a behavioural-storage figure.

## Testbench limits

`NUM_CH ≤ 4` in the testbench; physical map of 18 MiB; 4 domains; the in-flight expectation queues are rings of
16/32 entries; some coverage (e.g. `FAULT_RANGE` end-to-end) is unreachable by construction and covered only at unit
level (docs/03 §3).
