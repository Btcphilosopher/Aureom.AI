#!/usr/bin/env python3
"""Performance sweeps.  Builds the system testbench with SUITE=4 (performance workloads) for each configuration, runs it at several
memory latencies, reads the hardware counters through the CSR window and derives the metrics of docs/06.  -> reports/performance.{csv,md}

All numbers are SIMULATION CYCLES against a behavioural memory (fixed latency, ideal handshakes): sensitivity of the architecture,
not a prediction for any silicon.  Workloads: 128 KiB aligned / unaligned copy, 64 x 2 KiB scatter-gather chain, 12 KiB host->SRAM,
32 sequential 256-byte transactions with completion record (latency bound)."""
import os, re, subprocess, sys, csv, itertools, argparse
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); os.chdir(ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))
from regress import build

FIELDS = ["tag","wl","ch","bytes","active","bytes_wr","bytes_rd","beats_rd","beats_wr","bursts_rd","bursts_wr","st_ar","st_aw","st_w","st_wdata","st_full",
          "st_rslot","st_wslot","perm_wait","perm_req","perm_lat","occ_rd","occ_wr","occ_buf","rd_lat","wr_lat","xact_ok","lat_sum","lat_max","desc_lat"]

def run_cfg(tag, params, lat, blat=8):
    p = dict(params); p["SUITE"] = 4
    mdir, _ = build("perf_" + tag, p, force=False)
    r = subprocess.run(f"stdbuf -oL {mdir}/sim +verilator+seed+1 +lat={lat} +blat={blat} +tag={tag}_L{lat}", shell=True, capture_output=True, text=True, timeout=900)
    rows = []
    for line in r.stdout.splitlines():
        if line.startswith("PERF,"):
            f = line.split(",")[1:]
            d = dict(zip(FIELDS, f))
            for k in FIELDS[3:]: d[k] = int(d[k])
            d["ch"] = int(d["ch"]); d["lat"] = lat; d["params"] = params
            rows.append(d)
    if not rows or "TB RESULT PASS" not in r.stdout:
        print(r.stdout[-1500:]); raise SystemExit(f"perf run failed for {tag} lat {lat}")
    return rows

def derive(d, maxb, wb):
    a = max(d["active"], 1)
    return dict(bpc=d["bytes_wr"]/a, util=(d["beats_wr"]/(d["bursts_wr"]*maxb)) if d["bursts_wr"] else 0.0,
                rd_occ=d["occ_rd"]/a, wr_occ=d["occ_wr"]/a, buf=d["occ_buf"]*8/a,
                perm=(d["perm_lat"]/d["perm_req"]) if d["perm_req"] else 0.0, permwait=d["perm_wait"]/a,
                rdlat=(d["rd_lat"]/d["bursts_rd"]) if d["bursts_rd"] else 0.0, xlat=(d["lat_sum"]/d["xact_ok"]) if d["xact_ok"] else 0.0,
                stall_bus=(d["st_ar"]+d["st_aw"]+d["st_w"])/a, wr_starve=d["st_wdata"]/a, buf_full=d["st_full"]/a, slot=(d["st_rslot"]+d["st_wslot"])/a)

SWEEPS = {
  "dw":   [(f"dw{dw}", dict(DW=dw, MAXB=(8 if dw == 512 else 16), BUF_BYTES=4096), [16]) for dw in (32, 64, 128, 256, 512)],
  "out":  [(f"out{n}", dict(RD_OUT=n, WR_OUT=n, BUF_BYTES=2048), [4, 16, 64]) for n in (1, 2, 4, 8)],
  "burst":[(f"mb{mb}", dict(MAXB=mb, BUF_BYTES=max(1024, 4 * mb * 8), RD_OUT=4, WR_OUT=4), [16]) for mb in (8, 16, 32, 64)],
  "buf":  [(f"buf{b}", dict(BUF_BYTES=b, RD_OUT=8, WR_OUT=8), [32]) for b in (256, 512, 1024, 2048, 4096)],
  "perm": [(f"perm{o}_{l}", dict(PERM_OUT=o, PERM_LAT=l), [16]) for (o, l) in ((1, 1), (1, 4), (1, 16), (1, 64), (4, 16), (4, 64))],
  "chan": [(f"ch{n}", dict(NUM_CH=n), [16]) for n in (1, 2, 4)],
}

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--sweeps", default=",".join(SWEEPS)); a = ap.parse_args()
    allrows = []
    for sw in a.sweeps.split(","):
        for (tag, params, lats) in SWEEPS[sw]:
            for lat in lats:
                rows = run_cfg(tag, params, lat)
                for d in rows: d["sweep"] = sw; d["maxb"] = params.get("MAXB", 16); d["dw"] = params.get("DW", 64); allrows.append(d)
                b = [d for d in rows if d["wl"] == "bulk_aligned" and d["ch"] == 0][0]
                m = derive(b, b["maxb"], b["dw"] // 8)
                print(f"{sw:6s} {tag:10s} lat {lat:3d}  bulk: {m['bpc']:6.2f} B/cycle  util {m['util']:.2f}  rd_occ {m['rd_occ']:.2f}  wr_occ {m['wr_occ']:.2f}", flush=True)
    os.makedirs("reports", exist_ok=True)
    with open("reports/performance.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["sweep","tag","lat","wl","ch"] + FIELDS[3:] + ["bpc","util","rd_occ","wr_occ","buf_bytes","perm_cycles_per_req","perm_wait_frac","rd_burst_lat","xact_lat","bus_stall_frac","wr_starve_frac","buf_full_frac","slot_stall_frac"])
        for d in allrows:
            m = derive(d, d["maxb"], d["dw"] // 8)
            w.writerow([d["sweep"], d["tag"], d["lat"], d["wl"], d["ch"]] + [d[k] for k in FIELDS[3:]] + [f"{m[k]:.4f}" for k in ("bpc","util","rd_occ","wr_occ","buf","perm","permwait","rdlat","xlat","stall_bus","wr_starve","buf_full","slot")])
    print("wrote reports/performance.csv")

if __name__ == "__main__":
    main()
