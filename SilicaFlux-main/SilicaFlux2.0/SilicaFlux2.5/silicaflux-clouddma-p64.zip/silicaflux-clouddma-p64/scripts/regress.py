#!/usr/bin/env python3
"""CloudDMA regression runner: builds the system testbench for each configuration of a matrix, runs it with several
seeds (random initial register state), and writes reports/regression.md.

  python3 scripts/regress.py --list
  python3 scripts/regress.py --configs base,one_out,dw128 --seeds 1,2,3
  python3 scripts/regress.py --phase baseline      (single-channel matrix)    --phase multi (NUM_CH 2 and 4)    --phase all
The testbench parameters are the TB module parameters (they are forwarded to the DUT); see tb/tb_dma_sys.sv.
"""
import argparse, hashlib, os, re, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)

WNO = ("-Wno-fatal -Wno-WIDTH -Wno-TIMESCALEMOD -Wno-UNOPTFLAT -Wno-INITIALDLY -Wno-BLKSEQ -Wno-SYMRSVDWORD -Wno-CASEINCOMPLETE "
       "-Wno-STMTDLY -Wno-IMPLICITSTATIC -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM -Wno-UNDRIVEN -Wno-DECLFILENAME -Wno-PINCONNECTEMPTY "
       "-Wno-VARHIDDEN -Wno-LATCH -Wno-ASCRANGE -Wno-MULTIDRIVEN -Wno-CASEOVERLAP -Wno-SELRANGE -Wno-ENUMVALUE -Wno-WIDTHEXPAND "
       "-Wno-WIDTHTRUNC -Wno-SIDEEFFECT -Wno-IMPURE")

# name -> (parameters, note).  Every configuration runs the full suite unless SUITE is given.
CONFIGS = {
  # ---- baseline: single channel -------------------------------------------------------------------------------
  "base":      ({}, "defaults: 1 ch, 64-bit, 16 beats, 4+4 outstanding, 1 KiB buffer"),
  "one_out":   ({"RD_OUT": 1, "WR_OUT": 1, "ELQ": 1, "CMDQ": 1, "BUF_BYTES": 256}, "ONE outstanding read and write, minimum buffer (the brief's starting point)"),
  "dw32":      ({"DW": 32, "MAXB": 16, "BUF_BYTES": 1024}, "32-bit data"),
  "dw128":     ({"DW": 128, "MAXB": 16, "BUF_BYTES": 4096}, "128-bit data"),
  "dw256":     ({"DW": 256, "MAXB": 16, "BUF_BYTES": 4096}, "256-bit data"),
  "dw512":     ({"DW": 512, "MAXB": 8, "BUF_BYTES": 4096}, "512-bit data"),
  "inorder":   ({"REORDER_OK": 0}, "in-order bus (REORDER_OK=0), in-order slave"),
  "perm_pipe": ({"PERM_OUT": 4, "PERM_LAT": 7}, "slow IOMMU: 7-cycle latency, 4 requests outstanding"),
  "deep":      ({"RD_OUT": 8, "WR_OUT": 8, "ELQ": 4, "CMDQ": 4, "MAXB": 32, "BUF_BYTES": 4096}, "deep queues, 32-beat bursts"),
  "tot17":     ({"TOTLOG2": 17, "MAX_CHAIN": 32}, "chain total limited to 128 KiB, 32-descriptor chains"),
  "ext_iommu": ({"EXT_IOMMU": 1, "PERM_OUT": 2}, "external IOMMU interface served by the TB model (latency 3+jitter), 2 requests outstanding; fault injection"),
  "ext_iommu_in": ({"EXT_IOMMU": 1, "PERM_OUT": 1, "REORDER_OK": 0, "DW": 128, "MAXB": 8, "BUF_BYTES": 2048}, "external IOMMU, in-order bus, 128-bit"),
  "aw40":      ({"AW": 40, "DOM_W": 8}, "40-bit addresses, 8-bit domains"),
  "aw64":      ({"AW": 64, "DOM_W": 16}, "64-bit addresses, 16-bit domains"),
  # ---- multichannel (only after the baseline passes) ------------------------------------------------------------------
  "ch2":       ({"NUM_CH": 2}, "2 channels"),
  "ch4":       ({"NUM_CH": 4}, "4 channels"),
  "ch4_wide":  ({"NUM_CH": 4, "DW": 128, "MAXB": 8, "BUF_BYTES": 2048, "PERM_OUT": 2, "PERM_LAT": 3}, "4 channels, 128-bit, pipelined permission checks"),
  "ch2_inord": ({"NUM_CH": 2, "REORDER_OK": 0}, "2 channels, in-order bus"),
  # ---- negative test -----------------------------------------------------------------------------------------------
  "neg_order": ({"REORDER_OK": 0, "SUITE": 3}, "in-order DUT on a reordering bus must raise ERR_PROTOCOL"),
}
PHASES = {
  "baseline": ["base", "one_out", "dw32", "dw128", "dw256", "dw512", "inorder", "perm_pipe", "deep", "tot17", "aw40", "aw64", "ext_iommu", "ext_iommu_in", "neg_order"],
  "multi":    ["ch2", "ch4", "ch4_wide", "ch2_inord"],
}
PHASES["all"] = PHASES["baseline"] + PHASES["multi"]

def build(name, params, force=False):
    tag = hashlib.sha1(repr(sorted(params.items())).encode()).hexdigest()[:8]
    mdir = f"build/reg_{name}"
    stamp = os.path.join(mdir, ".stamp")
    srcs = ["rtl/" + f for f in os.listdir("rtl")] + ["tb/" + f for f in os.listdir("tb")]
    newest = max(os.path.getmtime(f) for f in srcs)
    if not force and os.path.exists(stamp) and os.path.getmtime(stamp) > newest and open(stamp).read() == tag:
        return mdir, 0.0
    t0 = time.time()
    os.makedirs("build", exist_ok=True)               # a fresh checkout / archive has no build/ directory
    gs = " ".join(f"-G{k}={v}" for k, v in params.items())
    cmd = (f"verilator --binary --timing {WNO} -O0 -CFLAGS -O0 --output-split 4000 --output-split-cfuncs 400 -j 4 --top-module tb_dma_sys "
           f"-Itb -f rtl/filelist.f tb/tb_pkg.sv tb/tb_dma_sys.sv -Mdir {mdir} -o sim {gs}")
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(f"{mdir}/sim"):
        print(r.stdout[-2000:], r.stderr[-2000:]); raise SystemExit(f"BUILD FAILED: {name}")
    open(stamp, "w").write(tag)
    return mdir, time.time() - t0

def run(mdir, seed, timeout=1200):
    t0 = time.time()
    try:
        r = subprocess.run(f"stdbuf -oL {mdir}/sim +verilator+seed+{seed} +verilator+rand+reset+2", shell=True, capture_output=True, text=True, timeout=timeout)
        out, rc = r.stdout + r.stderr, r.returncode
    except subprocess.TimeoutExpired as e:
        out, rc = (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or ""), -9
    m = re.search(r"tests=(\d+) \(failed (\d+)\)\s+checks=(\d+)\s+errors=(\d+)\s+cycles=(\d+)", out)
    passed = ("TB RESULT PASS" in out) and rc == 0 and m is not None
    info = dict(passed=passed, rc=rc, secs=time.time() - t0, tests=int(m.group(1)) if m else 0, checks=int(m.group(3)) if m else 0,
                errors=int(m.group(4)) if m else -1, cycles=int(m.group(5)) if m else 0, out=out)
    cov = re.search(r"coverage: (.*)", out)
    info["cov"] = cov.group(1) if cov else ""
    return info

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true"); ap.add_argument("--configs", default=""); ap.add_argument("--phase", default="")
    ap.add_argument("--seeds", default="1,2,3"); ap.add_argument("--report", default="reports/regression.md"); ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    if a.list:
        for k, (p, n) in CONFIGS.items(): print(f"{k:10s} {p}  -- {n}")
        return
    names = a.configs.split(",") if a.configs else PHASES.get(a.phase or "baseline")
    seeds = [int(x) for x in a.seeds.split(",")]
    rows, allok = [], True
    for n in names:
        params, note = CONFIGS[n]
        mdir, bt = build(n, params, a.force)
        res = [run(mdir, s) for s in seeds]
        ok = all(r["passed"] for r in res)
        allok &= ok
        tot_checks = sum(r["checks"] for r in res)
        rows.append((n, params, note, ok, len(seeds), sum(r["passed"] for r in res), tot_checks, max(r["cycles"] for r in res), bt, res))
        print(f"{n:10s} {'PASS' if ok else 'FAIL'}  seeds {sum(r['passed'] for r in res)}/{len(seeds)}  checks {tot_checks}  build {bt:.0f}s  {note}")
        if not ok:
            for r in res:
                if not r["passed"]: print("   ---- failing run (tail) ----\n" + "\n".join(r["out"].splitlines()[-25:])); break
    os.makedirs(os.path.dirname(a.report) or ".", exist_ok=True)
    with open(a.report, "w") as f:
        f.write("# Regression report (generated by scripts/regress.py)\n\n")
        f.write("Each configuration builds the system testbench (`tb/tb_dma_sys.sv`) with the listed parameters and runs the full suite with the listed seeds "
                "(`+verilator+rand+reset+2`: random initial register state).\n\n")
        f.write("| config | parameters | note | result | seeds passed | checks | cycles (max/run) |\n|---|---|---|---|---|---|---|\n")
        for (n, p, note, ok, ns, npass, chk, cyc, bt, res) in rows:
            f.write(f"| {n} | {p or 'defaults'} | {note} | {'**PASS**' if ok else '**FAIL**'} | {npass}/{ns} | {chk:,} | {cyc:,} |\n")
        f.write(f"\nOverall: {'ALL PASSED' if allok else 'FAILURES'}\n\n")
        for (n, p, note, ok, ns, npass, chk, cyc, bt, res) in rows:
            if res and res[0]["cov"]: f.write(f"* `{n}` coverage (seed {seeds[0]}): {res[0]['cov']}\n")
    print("report:", a.report)
    sys.exit(0 if allok else 1)

if __name__ == "__main__":
    main()
