#!/usr/bin/env python3
"""Mutation campaign: inject one deliberate RTL bug at a time into a COPY of the RTL, rebuild the system testbench and require
that it FAILS.  A mutant that survives is a hole in the verification.

  python3 scripts/mutate.py --check              every mutation applies exactly once (no build)
  python3 scripts/mutate.py --run [--only M03,M07]   build + run each mutant (about 1-2 min each)   -> reports/mutation.md
"""
import argparse, os, re, shutil, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))
from regress import WNO   # same warning waivers as the regression

# id, file, old, new, description, (config params), expected-detector note
M = [
 ("M01", "rtl/sfdma_burst_ctrl.sv", "(rd_cnt_q == 8'd0) && (wr_cnt_q == 8'd0) &&\n                 (wq_cnt_q == 8'd0)", "(rd_cnt_q == 8'd0) &&\n                 (wq_cnt_q == 8'd0)",
  "completion without waiting for write acknowledgements (wr_cnt not in quiet)", {}),
 ("M02", "rtl/sfdma_perm_checker.sv", "c_rsp_ok[iommu_rsp_id]                    = iommu_rsp_ok && !x_bad;", "c_rsp_ok[iommu_rsp_id]                    = 1'b1;",
  "permission refusals are turned into approvals", {}),
 ("M03", "rtl/sfdma_desc_walker.sv", "else if (d_dom != {{(16-DOM_W){1'b0}}, dom_q})                             verr", "else if (1'b0)                                                             verr",
  "descriptor DOMAIN claim is not compared with the hardware binding", {}),
 ("M04", "rtl/sfdma_burst_plan.sv", "localparam logic [31:0] BND32  = 32'd1 << BND_LOG2;", "localparam logic [31:0] BND32  = 32'd1 << (BND_LOG2 + 1);",
  "bursts may cross a 4 KiB boundary", {}),
 ("M05", "rtl/sfdma_burst_ctrl.sv", "w_c0     = (wk_q == '0) ? h_lo : '0;", "w_c0     = '0;",
  "first write beat ignores the destination byte offset", {}),
 ("M06", "rtl/sfdma_burst_ctrl.sv", "r_pos     = rs_base[r_id] + PW'(r_sfirst);", "r_pos     = rs_base[r_id] + PW'(r_sfirst) + PW'(1);",
  "read data stored one byte off in the buffer", {}),
 ("M07", "rtl/sfdma_crc.sv", "for (int i = 0; i < WB; i++) if (strb[i]) nxt = crc_byte(nxt, data[8*i +: 8]);", "for (int i = 0; i < WB; i++) if (strb[WB-1-i]) nxt = crc_byte(nxt, data[8*(WB-1-i) +: 8]);",
  "CRC consumes the lanes in reverse order", {}),
 ("M08", "rtl/sfdma_desc_walker.sv", "(d_len != 32'd0 && (s_end > LIM65 || d_end > LIM65)) ||", "1'b0 ||",
  "src+len / dst+len overflow of the address space not detected", {}),
 ("M09", "rtl/sfdma_desc_walker.sv", "else if (d_seq != seq_q)                                                   verr", "else if (1'b0)                                                             verr",
  "SEQ check removed (descriptor cycles only stopped by the hop limit)", {}),
 ("M10", "rtl/sfdma_desc_walker.sv", "(32'(seq_q) + 32'd1 >= 32'(max_chain_rt))", "(32'(seq_q) + 32'd2 >= 32'(max_chain_rt))",
  "chain length limit off by one", {}),
 ("M11", "rtl/sfdma_channel.sv", "wire tmo_hit   = (tmo != 32'd0) &&", "wire tmo_hit   = 1'b0 && (tmo != 32'd0) &&",
  "watchdog never fires", {}),
 ("M12", "rtl/sfdma_channel.sv", "if (tmo_hit) begin ev_timeout <= 1'b1; stop_q <= 1'b1; timed_q <= 1'b1; fenced_q <= 1'b1; end", "if (tmo_hit) begin ev_timeout <= 1'b1; stop_q <= 1'b1; timed_q <= 1'b1; end",
  "timed-out channel is not fenced", {}),
 ("M13", "rtl/sfdma_burst_ctrl.sv", "wire wr_data_ok   = (cmt_unres >= PTW'(wq_nb_q));", "wire wr_data_ok   = 1'b1;",
  "AW issued before all its data is committed", {}),
 ("M14", "rtl/sfdma_burst_ctrl.sv", "assign ar_addr      = rq_pa_q;", "assign ar_addr      = rq_env_q;",
  "read address taken from the IOVA instead of the checker's physical address", {}),
 ("M15", "rtl/sfdma_channel.sv", "assign ar_domain = dom_q;", "assign ar_domain = '0;",
  "AR domain sideband not the channel's binding", {}),
 ("M16", "rtl/sfdma_desc_walker.sv", "elv_q    <= (d_len != 32'd0);", "elv_q    <= 1'b1;",
  "zero-length elements are handed to the data path", {}),
 ("M17", "rtl/sfdma_channel.sv", "if (k_w_last) k_st <= K_B; else kk_q <= kk_q + 8'd1;", "if (k_w_last) begin ev_cpl_t <= 1'b1; c_st <= C_DONE; end else kk_q <= kk_q + 8'd1;",
  "completion record not acknowledged before completion is signalled", {}),
 ("M18", "rtl/sfdma_burst_ctrl.sv", "wire barrier_ok   = (wr_loaded_q == rd_loaded_q) && wp_idle && (wr_cnt_q == 8'd0) && (wq_cnt_q == 8'd0);", "wire barrier_ok   = 1'b1;",
  "ORDERED barrier ignored", {}),
 ("M19", "rtl/sfdma_desc_walker.sv", "else if (d_len != 32'd0 && d_sasid == d_dasid && ({1'b0, d_src} < d_end) && ({1'b0, d_dst} < s_end))", "else if (1'b0)",
  "overlap of source and destination not detected", {}),
 ("M20", "rtl/sfdma_desc_walker.sv", "else if (!asid_en[d_sasid] || !asid_en[d_dasid] || (is_head && f_cpl && !asid_en[d_casid]))", "else if (1'b0)",
  "address-space enable not checked", {}),
 ("M21", "rtl/sfdma_bytebuf.sv", "if (d >= 32'(rd_lane0) && d < 32'(rd_lane0) + 32'(rd_n)) begin", "if (1'b1) begin",
  "write strobes cover the whole beat (bytes outside the transfer are written)", {}),
 ("M22", "rtl/sfdma_burst_ctrl.sv", "assign ev_werr   = b_valid && b_slot_ok && b_err;", "assign ev_werr   = 1'b0;",
  "write error responses ignored", {}),
 ("M23", "rtl/sfdma_burst_ctrl.sv", "assign ev_rerr   = r_valid && r_slot_ok && r_err;", "assign ev_rerr   = 1'b0;",
  "read error responses ignored", {}),
 ("M24", "rtl/sfdma_burst_ctrl.sv", "assign ev_rperm = (rp_st == RP_CHKW) && pr_rsp_valid && !pr_rsp_ok && !stop_i;", "assign ev_rperm = 1'b0;",
  "a refused source read is not reported as an error", {}),
 ("M25", "rtl/sfdma_channel.sv", "wire abort_now = ch_abort && (c_st == C_RUN);", "wire abort_now = 1'b0;",
  "abort command ignored", {}),
 ("M26", "rtl/sfdma_burst_ctrl.sv", "(REORDER_OK || (r_id == rd_fill_q))", "1'b1",
  "in-order bus: out-of-order read responses are accepted", {"REORDER_OK": 0, "SUITE": 3}),
 ("M27", "rtl/sfdma_perm_checker.sv", "(iommu_rsp_pa[11:0] != rq_off_q[iommu_rsp_id]) ||", "1'b0 ||",
  "translation result: in-page offset not verified (external IOMMU)", {"EXT_IOMMU": 1, "PERM_OUT": 2}),
 ("M29", "rtl/sfdma_burst_ctrl.sv", "(REORDER_OK || (b_id == wo_q[wo_rp_q]))", "1'b1",
  "in-order bus: out-of-order write responses are accepted", {"REORDER_OK": 0, "SUITE": 3}),
 ("M28", "rtl/sfdma_burst_ctrl.sv", "assign aw_id = aw_pres_q ? aw_id_q : free_slot;", "assign aw_id = free_slot;",
  "AW ID may change while the request is pending (AXI4 stability)", {}),
]

M.sort(key=lambda m: m[0])

def apply(mid, f, old, new):
    src = open(f).read()
    n = src.count(old)
    if n != 1: raise SystemExit(f"{mid}: expected exactly 1 occurrence of the target text in {f}, found {n}")
    return src.replace(old, new)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true"); ap.add_argument("--run", action="store_true"); ap.add_argument("--only", default="")
    ap.add_argument("--report", default="reports/mutation.md"); ap.add_argument("--seed", type=int, default=1)
    a = ap.parse_args()
    sel = [m for m in M if not a.only or m[0] in a.only.split(",")]
    if a.check:
        for (mid, f, old, new, desc, cfg) in sel: apply(mid, f, old, new); print(f"{mid} ok  {desc}")
        print(f"{len(sel)} mutations apply cleanly"); return
    rows = []
    for (mid, f, old, new, desc, cfg) in sel:
        d = f"build/mut/{mid}"
        shutil.rmtree(d, ignore_errors=True); os.makedirs(d)
        shutil.copytree("rtl", f"{d}/rtl"); shutil.copytree("third_party", f"{d}/third_party")
        open(f"{d}/{f}", "w").write(apply(mid, f, old, new))
        # anchor at the start of the line: third_party/<x>/rtl/... also contains the text "rtl/"
        fl = "\n".join((f"{d}/{l}" if l.startswith(("rtl/", "third_party/")) else l) for l in open("rtl/filelist.f").read().split("\n"))
        open(f"{d}/filelist.f", "w").write(fl)
        gs = " ".join(f"-G{k}={v}" for k, v in cfg.items())
        t0 = time.time()
        r = subprocess.run(f"verilator --binary --timing {WNO} -O0 -CFLAGS -O0 --output-split 4000 --output-split-cfuncs 400 -j 4 --top-module tb_dma_sys "
                           f"-Itb -f {d}/filelist.f tb/tb_pkg.sv tb/tb_dma_sys.sv -Mdir {d}/obj -o sim {gs}", shell=True, capture_output=True, text=True)
        if not os.path.exists(f"{d}/obj/sim"):
            status, detail = "INVALID (does not compile)", (r.stderr or r.stdout)[-300:]
        else:
            try:
                p = subprocess.run(f"stdbuf -oL {d}/obj/sim +verilator+seed+{a.seed} +verilator+rand+reset+2", shell=True, capture_output=True, text=True, timeout=400)
                out, rc = p.stdout + p.stderr, p.returncode
            except subprocess.TimeoutExpired:
                out, rc = "", -9
            passed = ("TB RESULT PASS" in out) and rc == 0
            if passed: status, detail = "SURVIVED", ""
            else:
                status = "killed"
                m = re.search(r"FAIL: ([^\n]{0,110})", out)
                a_ = re.search(r"Assertion failed in [^:]*: ([^\n]{0,110})", out)       # the RTL's own simulation-only assertions
                detail = m.group(1) if m else (f"RTL assertion: {a_.group(1)}" if a_ else ("hang/timeout" if rc == -9 else f"exit {rc}"))
        rows.append((mid, desc, status, detail, time.time() - t0))
        print(f"{mid}  {status:10s} {desc}  | {detail[:90]}", flush=True)
        if not os.environ.get("KEEP_OBJ"): shutil.rmtree(f"{d}/obj", ignore_errors=True)
    os.makedirs(os.path.dirname(a.report) or ".", exist_ok=True)
    killed = sum(1 for r in rows if r[2] == "killed"); valid = sum(1 for r in rows if not r[2].startswith("INVALID"))
    with open(a.report, "w") as f:
        f.write("# Mutation campaign (generated by scripts/mutate.py)\n\nOne deliberate RTL bug per mutant, injected into a copy of the RTL; "
                "the full system testbench (seed 1, random initial state) must FAIL on it.\n\n")
        f.write(f"**{killed} / {valid} valid mutants killed**" + ("" if killed == valid else " — SURVIVORS LISTED BELOW") + "\n\n")
        f.write("| id | injected bug | result | first failing check |\n|---|---|---|---|\n")
        for (mid, desc, status, detail, secs) in rows: f.write(f"| {mid} | {desc} | {status} | {detail.replace('|', '/')} |\n")
    print("report:", a.report)
    sys.exit(0 if killed == valid else 1)

if __name__ == "__main__":
    main()
