#!/bin/bash
# =============================================================================
# CloudDMA generic synthesis wrapper (technology independent, Yosys 0.33).  NO PDK: it reports cell/flop counts of a
# generic AND/OR/XOR/MUX netlist.  It makes NO frequency, area-in-um2 or power claim.
#   scripts/synth.sh <name> [PARAM=value ...]     e.g.  scripts/synth.sh base
#                                                       scripts/synth.sh ch4 NUM_CH=4 DW=128
#   TOP=<module> selects another top (default silicaflux_cloud_dma)
# Output: reports/synth/<name>.{check,stat_pre,stat,latches}.txt and one line appended to reports/synth/SUMMARY.md
# =============================================================================
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
name=${1:-base}; shift || true
TOP=${TOP:-silicaflux_cloud_dma}
FILES=$(grep -v '^#' rtl/filelist.f | grep -v '\.vlt' | tr '\n' ' ')
PARAMS=""
for p in "$@"; do k=${p%%=*}; v=${p#*=}; PARAMS="${PARAMS} -chparam $k $v"; done
mkdir -p reports/synth build
REPORT=reports/synth/$name
FILES="$FILES" TOPN="$TOP" REPORT="$REPORT" PARAMS="$PARAMS" python3 - <<'PY' > build/synth_$name.ys
import os
t = open("synth/synth_dma.ys.tmpl").read()
t = t.replace("@FILES@", os.environ["FILES"]).replace("@TOP@", os.environ["TOPN"]).replace("@REPORT@", os.environ["REPORT"])
t = t.replace("@PARAMS@", os.environ["PARAMS"])
print(t)
PY
yosys -q -l reports/synth/$name.log build/synth_$name.ys > /dev/null 2>&1 || { echo "SYNTH FAILED: see reports/synth/$name.log"; tail -15 reports/synth/$name.log; exit 1; }
cells=$(grep -E "Number of cells:" $REPORT.stat.txt | tail -1 | awk '{print $NF}')
ffs=$(grep -E '\$_(S?DFF|DFFE|SDFF|ADFF|DFFSR)' $REPORT.stat.txt | awk '{s += $NF} END {print s+0}')
lat=$(grep -oE "^[0-9]+ objects" $REPORT.latches.txt | awk '{print $1}' | tail -1)
probs=$(grep -oE "Found and reported [0-9]+ problems" $REPORT.check.txt | awk '{print $4}')
[ -f reports/synth/SUMMARY.md ] || printf '| config | top | parameters | generic cells | flops | latches | check problems |\n|---|---|---|---|---|---|---|\n' > reports/synth/SUMMARY.md
echo "| $name | $TOP | $* | ${cells:-?} | ${ffs:-?} | ${lat:-0} | ${probs:-0} |" >> reports/synth/SUMMARY.md
echo "synth $name ($TOP): generic cells=${cells:-?}  flops=${ffs:-?}  latches=${lat:-0}  check problems=${probs:-0}"
