#!/bin/bash
# Unit benches (Verilator): burst planner (exhaustive), byte buffer (3 data widths), CRC (3 widths, vs vendored sfd_crc32),
# permission table (3 latencies, vs a 64-bit reference), package layout.   -> reports/unit/*.log + reports/unit/summary.txt
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
mkdir -p reports/unit build
W="-Wno-fatal -Wno-WIDTH -Wno-TIMESCALEMOD"
PKG="rtl/lint.vlt rtl/silicaflux_dma_pkg.sv"
: > reports/unit/summary.txt
runone() {   # name top "files" [extra -G args]
  local name=$1 top=$2 files=$3; shift 3
  verilator --binary --timing $W --top-module $top -Mdir build/u_$name $PKG $files "$@" -o u_$name > build/u_$name.build.log 2>&1 || { echo "BUILD FAILED $name"; tail build/u_$name.build.log; exit 1; }
  ./build/u_$name/u_$name > reports/unit/$name.log 2>&1 || true
  local line; line=$(grep -E "checks=|TB RESULT" reports/unit/$name.log | tr '\n' ' ')
  echo "$name: $line" | tee -a reports/unit/summary.txt
  grep -q "TB RESULT PASS" reports/unit/$name.log || { echo "UNIT FAILURE: $name"; exit 1; }
}
runone burst_plan tb_burst_plan "rtl/sfdma_burst_plan.sv tb/tb_burst_plan.sv"
for cfg in "64 64" "32 32" "128 128"; do set -- $cfg; runone bytebuf_$1 tb_bytebuf "rtl/sfdma_bytebuf.sv tb/tb_bytebuf.sv" -GDW=$1 -GCAP=$2; done
for dw in 64 32 128; do runone crc_$dw tb_crc "rtl/sfdma_crc.sv third_party/p61-clouddpu/rtl/sfd_crc32.sv tb/tb_crc.sv" -GDW=$dw; done
for lat in 1 2 5; do runone perm_table_lat$lat tb_perm_table "rtl/sfdma_perm_table.sv tb/tb_perm_table.sv" -GLAT=$lat; done
runone pkg_layout tb_pkg_layout "tb/tb_pkg_layout.sv"
echo "all unit benches passed" | tee -a reports/unit/summary.txt
