#!/bin/bash
# Per-module generic synthesis (hierarchy kept) of the default configuration: where the cells go.  -> reports/synth/modules.txt
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
mkdir -p reports/synth build
FILES=$(grep -v '^#' rtl/filelist.f | grep -v '\.vlt' | tr '\n' ' ')
cat > build/synth_modules.ys <<EOT
read_verilog -defer -sv -DSYNTHESIS $FILES
hierarchy -check -top silicaflux_cloud_dma
proc
opt_clean
memory -nomap
opt -full
memory_map
techmap
opt -fast
abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX
opt_clean
tee -q -o reports/synth/modules.txt stat
EOT
yosys -q -l reports/synth/modules.log build/synth_modules.ys > /dev/null 2>&1 || { echo "FAILED"; tail reports/synth/modules.log; exit 1; }
python3 - <<'PY'
import re
txt = open("reports/synth/modules.txt").read()
# last 'design hierarchy' block lists per-module cell counts
mods = re.findall(r"=== (\S+) ===.*?Number of cells:\s+(\d+)", txt, re.S)
print("module                       cells (own, excluding sub-modules)")
for m, c in sorted(mods, key=lambda x: -int(x[1])): print(f"{m:28s} {c}")
PY
