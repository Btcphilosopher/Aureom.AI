#!/usr/bin/env python3
"""Proves third_party/ is exactly what third_party/MANIFEST.tsv says (SHA-256 per file); with --archive <zip> it also compares each
file byte-for-byte with its member in the source archive (silicaflux-clouddpu-p61.zip)."""
import hashlib, os, sys, zipfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
bad = 0
rows = [l.rstrip("\n").split("\t") for l in open(os.path.join(ROOT, "third_party/MANIFEST.tsv")) if not l.startswith("#") and l.strip()]
arch = None
if "--archive" in sys.argv: arch = zipfile.ZipFile(sys.argv[sys.argv.index("--archive") + 1])
for (path, member, sha) in rows:
    data = open(os.path.join(ROOT, "third_party", path), "rb").read()
    if hashlib.sha256(data).hexdigest() != sha: print("MODIFIED:", path); bad += 1
    if arch is not None and arch.read(member) != data: print("DIFFERS FROM ARCHIVE:", path); bad += 1
print(f"{len(rows)} vendored files checked, {bad} problems" + ("  (also compared with the archive)" if arch else ""))
sys.exit(1 if bad else 0)
