#!/bin/bash
# Generic synthesis of the standard configurations (Yosys 0.33, no PDK) -> reports/synth/SUMMARY.md.  About 5-10 minutes each.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
rm -f reports/synth/SUMMARY.md
bash scripts/synth.sh base
bash scripts/synth.sh one_out  RD_OUT=1 WR_OUT=1 ELQ=1 CMDQ=1 BUF_BYTES=256
bash scripts/synth.sh dw128    DW=128 BUF_BYTES=4096
bash scripts/synth.sh nocrc    CRC_ON=0
bash scripts/synth.sh ch2      NUM_CH=2
bash scripts/synth.sh ext_iommu USE_EXT_IOMMU=1
echo; cat reports/synth/SUMMARY.md
