// =============================================================================
// CloudDMA :: sfdma_axi_mux -- NCH channels onto ONE AXI4 master port
//
//   AR / AW : round-robin with grant lock (a presented request keeps its grant until accepted: AXI4 stability rule)
//   R / B   : routed by the channel number in the top bits of the ID (ID = {channel, local id})
//   W       : AXI4 has no write ID, so W beats must follow AW ORDER.  Every accepted AW pushes its channel number into
//             an order FIFO; the W beats of the channel at the head are forwarded until its `wlast`, then the FIFO pops.
//             (A channel never presents W before its own AW was accepted, so the head's data is always forthcoming.)
// A response whose channel field does not exist is dropped and flagged (bad_id_evt).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfdma_axi_mux #(
  parameter int NCH    = 2,
  parameter int DW     = 64,
  parameter int AW     = 48,
  parameter int DOM_W  = 4,
  parameter int LIDW   = 3,
  parameter int WDEPTH = 12,
  localparam int WB    = DW / 8,
  localparam int CHW   = (NCH > 1) ? $clog2(NCH) : 1,
  localparam int IDW   = CHW + LIDW
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // channel side
  input  wire logic [NCH-1:0]        c_ar_valid,
  output logic [NCH-1:0]             c_ar_ready,
  input  wire logic [NCH*LIDW-1:0]   c_ar_id,
  input  wire logic [NCH*4-1:0]      c_ar_asid,
  input  wire logic [NCH*DOM_W-1:0]  c_ar_domain,
  input  wire logic [NCH*AW-1:0]     c_ar_addr,
  input  wire logic [NCH*8-1:0]      c_ar_len,
  output logic [NCH-1:0]             c_r_valid,
  output logic [LIDW-1:0]            c_r_id,
  input  wire logic [NCH-1:0]        c_aw_valid,
  output logic [NCH-1:0]             c_aw_ready,
  input  wire logic [NCH*LIDW-1:0]   c_aw_id,
  input  wire logic [NCH*4-1:0]      c_aw_asid,
  input  wire logic [NCH*DOM_W-1:0]  c_aw_domain,
  input  wire logic [NCH*AW-1:0]     c_aw_addr,
  input  wire logic [NCH*8-1:0]      c_aw_len,
  input  wire logic [NCH-1:0]        c_w_valid,
  output logic [NCH-1:0]             c_w_ready,
  input  wire logic [NCH*DW-1:0]     c_w_data,
  input  wire logic [NCH*WB-1:0]     c_w_strb,
  input  wire logic [NCH-1:0]        c_w_last,
  output logic [NCH-1:0]             c_b_valid,
  output logic [LIDW-1:0]            c_b_id,
  // master side
  output logic                       m_ar_valid,
  input  wire logic                  m_ar_ready,
  output logic [IDW-1:0]             m_ar_id,
  output logic [3:0]                 m_ar_asid,
  output logic [DOM_W-1:0]           m_ar_domain,
  output logic [AW-1:0]              m_ar_addr,
  output logic [7:0]                 m_ar_len,
  input  wire logic                  m_r_valid,
  input  wire logic [IDW-1:0]        m_r_id,
  input  wire logic                  m_b_valid,
  input  wire logic [IDW-1:0]        m_b_id,
  output logic                       m_aw_valid,
  input  wire logic                  m_aw_ready,
  output logic [IDW-1:0]             m_aw_id,
  output logic [3:0]                 m_aw_asid,
  output logic [DOM_W-1:0]           m_aw_domain,
  output logic [AW-1:0]              m_aw_addr,
  output logic [7:0]                 m_aw_len,
  output logic                       m_w_valid,
  input  wire logic                  m_w_ready,
  output logic [DW-1:0]              m_w_data,
  output logic [WB-1:0]              m_w_strb,
  output logic                       m_w_last,
  output logic                       bad_id_evt
);
  generate
    if (NCH == 1) begin : g_one
      assign m_ar_valid = c_ar_valid[0];  assign c_ar_ready[0] = m_ar_ready;
      assign m_ar_id = IDW'(c_ar_id);     assign m_ar_asid = c_ar_asid;    assign m_ar_domain = c_ar_domain;
      assign m_ar_addr = c_ar_addr;       assign m_ar_len = c_ar_len;
      assign c_r_valid[0] = m_r_valid;    assign c_r_id = m_r_id[LIDW-1:0];
      assign m_aw_valid = c_aw_valid[0];  assign c_aw_ready[0] = m_aw_ready;
      assign m_aw_id = IDW'(c_aw_id);     assign m_aw_asid = c_aw_asid;    assign m_aw_domain = c_aw_domain;
      assign m_aw_addr = c_aw_addr;       assign m_aw_len = c_aw_len;
      assign m_w_valid = c_w_valid[0];    assign c_w_ready[0] = m_w_ready;
      assign m_w_data = c_w_data;         assign m_w_strb = c_w_strb;      assign m_w_last = c_w_last[0];
      assign c_b_valid[0] = m_b_valid;    assign c_b_id = m_b_id[LIDW-1:0];
      assign bad_id_evt = 1'b0;
      wire unused_mux = (|m_r_id[IDW-1:LIDW]) || (|m_b_id[IDW-1:LIDW]) || (IDW == LIDW) || clk || rst_n;
    end else begin : g_many
      // ---------------- AR and AW arbitration with grant lock
      logic [CHW-1:0] ar_ptr_q, aw_ptr_q, ar_win, aw_win, ar_lk_i_q, aw_lk_i_q;
      logic           ar_lk_v_q, aw_lk_v_q, ar_found, aw_found;
      integer         ja, jw;
      always_comb begin
        ar_found = 1'b0; ar_win = '0; ja = 0;
        aw_found = 1'b0; aw_win = '0; jw = 0;
        if (ar_lk_v_q) begin ar_found = 1'b1; ar_win = ar_lk_i_q; end
        else for (int i = 0; i < NCH; i++) begin
          ja = i + 32'(ar_ptr_q); if (ja >= NCH) ja = ja - NCH;
          if (!ar_found && c_ar_valid[ja]) begin ar_found = 1'b1; ar_win = CHW'(ja); end
        end
        if (aw_lk_v_q) begin aw_found = 1'b1; aw_win = aw_lk_i_q; end
        else for (int i = 0; i < NCH; i++) begin
          jw = i + 32'(aw_ptr_q); if (jw >= NCH) jw = jw - NCH;
          if (!aw_found && c_aw_valid[jw]) begin aw_found = 1'b1; aw_win = CHW'(jw); end
        end
      end
      assign m_ar_valid  = ar_found;
      assign m_ar_id     = {ar_win, c_ar_id[32'(ar_win)*LIDW +: LIDW]};
      assign m_ar_asid   = c_ar_asid[32'(ar_win)*4 +: 4];
      assign m_ar_domain = c_ar_domain[32'(ar_win)*DOM_W +: DOM_W];
      assign m_ar_addr   = c_ar_addr[32'(ar_win)*AW +: AW];
      assign m_ar_len    = c_ar_len[32'(ar_win)*8 +: 8];
      assign m_aw_valid  = aw_found && !wf_full;                    // never present an AW the order FIFO could not record
      assign m_aw_id     = {aw_win, c_aw_id[32'(aw_win)*LIDW +: LIDW]};
      assign m_aw_asid   = c_aw_asid[32'(aw_win)*4 +: 4];
      assign m_aw_domain = c_aw_domain[32'(aw_win)*DOM_W +: DOM_W];
      assign m_aw_addr   = c_aw_addr[32'(aw_win)*AW +: AW];
      assign m_aw_len    = c_aw_len[32'(aw_win)*8 +: 8];
      always_comb begin
        c_ar_ready = '0; c_aw_ready = '0;
        for (int i = 0; i < NCH; i++) begin
          c_ar_ready[i] = m_ar_ready && ar_found && (ar_win == CHW'(i));
          c_aw_ready[i] = m_aw_ready && aw_found && (aw_win == CHW'(i)) && !wf_full;
        end
      end
      wire aw_acc = m_aw_valid && m_aw_ready;
      // ---------------- W order FIFO
      logic          wf_full, wf_ov;
      logic [CHW-1:0] wf_head;
      logic [$clog2(WDEPTH+1)-1:0] wf_level;
      wire wf_in_ready;
      assign wf_full = !wf_in_ready;
      sfd_fifo #(.WIDTH(CHW), .DEPTH(WDEPTH)) u_wf (
        .clk, .rst_n, .flush(1'b0), .in_valid(m_aw_valid && m_aw_ready), .in_ready(wf_in_ready), .in_data(aw_win),
        .out_valid(wf_ov), .out_ready(m_w_valid && m_w_ready && m_w_last), .out_data(wf_head), .level(wf_level));
      assign m_w_valid = wf_ov && c_w_valid[32'(wf_head)];
      assign m_w_data  = c_w_data[32'(wf_head)*DW +: DW];
      assign m_w_strb  = c_w_strb[32'(wf_head)*WB +: WB];
      assign m_w_last  = c_w_last[32'(wf_head)];
      always_comb begin
        c_w_ready = '0;
        for (int i = 0; i < NCH; i++) c_w_ready[i] = m_w_ready && wf_ov && (wf_head == CHW'(i));
      end
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin ar_ptr_q <= '0; aw_ptr_q <= '0; ar_lk_v_q <= 1'b0; aw_lk_v_q <= 1'b0; ar_lk_i_q <= '0; aw_lk_i_q <= '0; end
        else begin
          if (m_ar_valid && !m_ar_ready) begin ar_lk_v_q <= 1'b1; ar_lk_i_q <= ar_win; end
          else if (m_ar_valid && m_ar_ready) begin ar_lk_v_q <= 1'b0; ar_ptr_q <= (ar_win == CHW'(NCH-1)) ? '0 : ar_win + 1'b1; end
          if (m_aw_valid && !m_aw_ready) begin aw_lk_v_q <= 1'b1; aw_lk_i_q <= aw_win; end
          else if (aw_acc) begin aw_lk_v_q <= 1'b0; aw_ptr_q <= (aw_win == CHW'(NCH-1)) ? '0 : aw_win + 1'b1; end
        end
      end
      // ---------------- R / B routing
      wire [CHW-1:0] r_ch = m_r_id[IDW-1 -: CHW];
      wire [CHW-1:0] b_ch = m_b_id[IDW-1 -: CHW];
      assign c_r_id = m_r_id[LIDW-1:0];
      assign c_b_id = m_b_id[LIDW-1:0];
      always_comb begin
        c_r_valid = '0; c_b_valid = '0;
        for (int i = 0; i < NCH; i++) begin
          c_r_valid[i] = m_r_valid && (r_ch == CHW'(i));
          c_b_valid[i] = m_b_valid && (b_ch == CHW'(i));
        end
      end
      assign bad_id_evt = (m_r_valid && (32'(r_ch) >= NCH)) || (m_b_valid && (32'(b_ch) >= NCH));
      wire unused_lv = |wf_level;
    end
  endgenerate
endmodule

`default_nettype wire
