// =============================================================================
// SilicaFlux CloudDMA (Project 64) :: silicaflux_cloud_dma -- protected scatter-gather data-movement engine (TOP LEVEL)
//
//   command --> descriptor fetch --> validation --> permission check --> read bursts --> data buffer --> write bursts
//           --> acknowledged writes --> completion record --> completion event            (one pipeline per channel)
//
//   NUM_CH channels (default 1) share: ONE AXI4 memory master port (sfdma_axi_mux), ONE permission checker
//   (sfdma_perm_checker, round-robin over 4 clients per channel), ONE IOMMU interface and ONE register file.
//
//   * Memory port   : AXI4 subset, INCR, full-width beats, beat-aligned bursts <= MAX_BURST_BEATS, never crossing 4 KiB,
//                     ID = {channel, local id}; sideband `asid` (address space) and `domain` on every AR/AW so a
//                     platform firewall / second IOMMU can validate independently.  Address on AR/AW = PHYSICAL address
//                     returned by the permission checker for that burst; there is no other path to the bus.
//   * IOMMU port    : USE_EXT_IOMMU = 1 exposes the request/response interface of docs/03_PROTECTION.md for a real
//                     IOMMU.  USE_EXT_IOMMU = 0 instantiates the verified SIMULATION permission table behind the same
//                     interface and exposes its programming port (ptbl_*).
//   * Command port  : per channel {head descriptor address, AUTHORITATIVE domain, descriptor address space}.  The
//                     domain comes from the hardware path that submits the command (queue binding), never from software
//                     metadata; the descriptor's DOMAIN field is a claim that is checked against it.
//   * Completion    : per channel valid/ready event after the last destination write AND the completion record (if any)
//                     were acknowledged.
//   * CSR           : docs/04_INTEGRATION.md; the engine is DISABLED at reset.
//
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module silicaflux_cloud_dma #(
  parameter int NUM_CH         = 1,
  parameter int DW             = 64,        // data width, bits: 32 / 64 / 128 / 256 / 512
  parameter int AW             = 48,        // physical / IO address width (13..64)
  parameter int DOM_W          = 4,         // domain (tenant) id width (1..16)
  parameter int MAX_BURST_BEATS = 16,       // beats per burst: MAX_BURST_BEATS * DW/8 in 64..4096 and <= 256 beats
  parameter int RD_OUT         = 4,         // outstanding read bursts per channel
  parameter int WR_OUT         = 4,         // outstanding write bursts per channel
  parameter int BUF_BYTES      = 1024,      // data buffer per channel (power of two >= 2 * burst bytes)
  parameter int ELQ            = 2,         // element queue depth per channel
  parameter int CMDQ           = 2,         // command queue depth per channel
  parameter int BND_LOG2       = 12,        // burst boundary (AXI4: 4 KiB)
  parameter int MAX_ELEM_LOG2  = 24,        // element length limit 2**N bytes
  parameter int MAX_TOTAL_LOG2 = 30,        // chain total limit 2**N bytes (<= 31)
  parameter int MAX_CHAIN      = 64,        // descriptors per chain (<= 65535); CSR can lower it
  parameter bit REORDER_OK     = 1'b1,      // 1: bus may reorder responses across IDs; 0: in-order bus (out of order = protocol error)
  parameter bit CRC_ON         = 1'b1,      // CRC-32 hardware present
  parameter bit USE_EXT_IOMMU  = 1'b0,      // 1: real IOMMU on iommu_*; 0: simulation permission table
  parameter int PERM_OUT       = 1,         // outstanding IOMMU requests
  parameter int PERM_ENTRIES   = 16,        // simulation table entries
  parameter int PERM_LAT       = 1,         // simulation table latency (cycles)
  parameter int TRACE_DEPTH    = 32,
  parameter int PC_W           = 48,        // performance counter width
  parameter int TIMEOUT_DEF    = 0,         // reset value of the no-progress timeout (0 = disabled)
  localparam int WB            = DW / 8,
  localparam int MXO           = (RD_OUT > WR_OUT) ? RD_OUT : WR_OUT,
  localparam int SW            = (MXO > 1) ? $clog2(MXO) : 1,
  localparam int LIDW          = SW + 1,
  localparam int CHW           = (NUM_CH > 1) ? $clog2(NUM_CH) : 1,
  localparam int ID_W          = CHW + LIDW,
  localparam int NCLI          = 4 * NUM_CH,
  localparam int IDP           = (NCLI > 1) ? $clog2(NCLI) : 1,
  localparam int PEW           = (PERM_ENTRIES > 1) ? $clog2(PERM_ENTRIES) : 1
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // ---------------- CSR (management plane)
  input  wire logic                   csr_req_valid,
  output logic                        csr_req_ready,
  input  wire logic                   csr_req_write,
  input  wire logic [11:0]            csr_req_addr,
  input  wire logic [31:0]            csr_req_wdata,
  output logic                        csr_rsp_valid,
  output logic [31:0]                 csr_rsp_rdata,
  output logic                        csr_rsp_err,
  output logic                        irq,
  // ---------------- command / completion, one port group per channel
  input  wire logic [NUM_CH-1:0]        cmd_valid,
  output logic [NUM_CH-1:0]             cmd_ready,
  input  wire logic [NUM_CH*64-1:0]     cmd_head,
  input  wire logic [NUM_CH*DOM_W-1:0]  cmd_domain,
  input  wire logic [NUM_CH*4-1:0]      cmd_asid,
  output logic [NUM_CH-1:0]             done_valid,
  input  wire logic [NUM_CH-1:0]        done_ready,
  output logic [NUM_CH*16-1:0]          done_txn,
  output logic [NUM_CH*4-1:0]           done_status,
  output logic [NUM_CH*8-1:0]           done_err,
  output logic [NUM_CH*4-1:0]           done_fault,
  output logic [NUM_CH*DOM_W-1:0]       done_domain,
  output logic [NUM_CH*32-1:0]          done_bytes,
  output logic [NUM_CH*32-1:0]          done_crc,
  output logic [NUM_CH-1:0]             viol_evt,
  // ---------------- memory master (AXI4 subset + sidebands)
  output logic                        m_ar_valid,
  input  wire logic                   m_ar_ready,
  output logic [ID_W-1:0]             m_ar_id,
  output logic [AW-1:0]               m_ar_addr,
  output logic [7:0]                  m_ar_len,
  output logic [2:0]                  m_ar_size,
  output logic [1:0]                  m_ar_burst,
  output logic [3:0]                  m_ar_asid,
  output logic [DOM_W-1:0]            m_ar_domain,
  input  wire logic                   m_r_valid,
  output logic                        m_r_ready,
  input  wire logic [ID_W-1:0]        m_r_id,
  input  wire logic [DW-1:0]          m_r_data,
  input  wire logic [1:0]             m_r_resp,
  input  wire logic                   m_r_last,
  output logic                        m_aw_valid,
  input  wire logic                   m_aw_ready,
  output logic [ID_W-1:0]             m_aw_id,
  output logic [AW-1:0]               m_aw_addr,
  output logic [7:0]                  m_aw_len,
  output logic [2:0]                  m_aw_size,
  output logic [1:0]                  m_aw_burst,
  output logic [3:0]                  m_aw_asid,
  output logic [DOM_W-1:0]            m_aw_domain,
  output logic                        m_w_valid,
  input  wire logic                   m_w_ready,
  output logic [DW-1:0]               m_w_data,
  output logic [WB-1:0]               m_w_strb,
  output logic                        m_w_last,
  input  wire logic                   m_b_valid,
  output logic                        m_b_ready,
  input  wire logic [ID_W-1:0]        m_b_id,
  input  wire logic [1:0]             m_b_resp,
  // ---------------- IOMMU interface (USE_EXT_IOMMU = 1)
  output logic                        iommu_req_valid,
  input  wire logic                   iommu_req_ready,
  output logic [DOM_W-1:0]            iommu_req_domain,
  output logic [3:0]                  iommu_req_asid,
  output logic                        iommu_req_write,
  output logic [AW-1:0]               iommu_req_addr,
  output logic [15:0]                 iommu_req_bytes,
  output logic [IDP-1:0]              iommu_req_id,
  input  wire logic                   iommu_rsp_valid,
  output logic                        iommu_rsp_ready,
  input  wire logic [IDP-1:0]         iommu_rsp_id,
  input  wire logic                   iommu_rsp_ok,
  input  wire logic [3:0]             iommu_rsp_fault,
  input  wire logic [AW-1:0]          iommu_rsp_pa,
  // ---------------- simulation permission table programming (USE_EXT_IOMMU = 0)
  input  wire logic                   ptbl_en,
  input  wire logic [PEW-1:0]         ptbl_idx,
  input  wire logic                   ptbl_valid,
  input  wire logic [DOM_W-1:0]       ptbl_domain,
  input  wire logic [3:0]             ptbl_asid,
  input  wire logic [AW-1:0]          ptbl_base,
  input  wire logic [AW:0]            ptbl_size,
  input  wire logic [AW-1:0]          ptbl_pa,
  input  wire logic [1:0]             ptbl_perm,
  output logic                        ptbl_rej
);
  // ------------------------------------------------------------------ CSR block and core reset
  logic        enable, soft_rst, trace_en, perf_clr, trace_pop;
  logic [31:0] timeout;
  logic [15:0] max_chain_rt, asid_en;
  logic [NUM_CH-1:0] ch_abort;
  logic [NUM_CH-1:0] st_busy, st_fenced, st_last_valid;
  logic [NUM_CH*4-1:0]     st_last_status, st_last_fault;
  logic [NUM_CH*8-1:0]     st_last_err;
  logic [NUM_CH*16-1:0]    st_last_txn, st_last_descs;
  logic [NUM_CH*AW-1:0]    st_last_eaddr;
  logic [NUM_CH*32-1:0]    st_last_bytes, st_last_crc;
  logic [NUM_CH*DOM_W-1:0] st_last_domain;
  logic [NUM_CH-1:0]       irq_done_evt, irq_err_evt;
  logic [7:0]  perf_sel_ch, perf_sel_id;
  logic [63:0] perf_val;
  logic [95:0] tr_head;
  logic [31:0] proto_cnt;
  logic [15:0] tr_count, tr_drop;
  wire core_rst_n = rst_n && !soft_rst;

  sfdma_csr #(.NCH(NUM_CH), .DW(DW), .AW(AW), .DOM_W(DOM_W), .MAXB(MAX_BURST_BEATS), .RD_OUT(RD_OUT), .WR_OUT(WR_OUT),
              .BUF_BYTES(BUF_BYTES), .TIMEOUT_DEF(TIMEOUT_DEF), .MAX_CHAIN(MAX_CHAIN), .PC_W(PC_W)) u_csr (
    .clk, .rst_n, .csr_req_valid, .csr_req_ready, .csr_req_write, .csr_req_addr, .csr_req_wdata,
    .csr_rsp_valid, .csr_rsp_rdata, .csr_rsp_err,
    .enable, .soft_rst, .trace_en, .perf_clr, .trace_pop, .timeout, .max_chain(max_chain_rt), .asid_en, .ch_abort,
    .st_busy, .st_fenced, .st_last_status, .st_last_err, .st_last_fault, .st_last_txn, .st_last_eaddr, .st_last_bytes, .st_last_crc,
    .st_last_domain, .st_last_descs, .st_last_valid, .irq_done_evt, .irq_err_evt, .irq,
    .perf_sel_ch, .perf_sel_id, .perf_val, .proto_cnt, .tr_head, .tr_count, .tr_drop);

  // ------------------------------------------------------------------ channels
  logic [NUM_CH*4-1:0]      ch_pc_req_valid, ch_pc_req_ready, ch_pc_rsp_valid, ch_pc_rsp_ok, ch_pc_req_write;
  logic [NUM_CH*DOM_W-1:0]  ch_pc_domain;
  logic [NUM_CH*16-1:0]     ch_pc_req_asid, ch_pc_rsp_fault;
  logic [NUM_CH*4*AW-1:0]   ch_pc_req_addr, ch_pc_rsp_pa;
  logic [NUM_CH*4*16-1:0]   ch_pc_req_bytes;

  logic [NUM_CH-1:0]        ch_ar_valid, ch_ar_ready, ch_r_valid, ch_aw_valid, ch_aw_ready, ch_w_valid, ch_w_ready, ch_w_last, ch_b_valid;
  logic [NUM_CH*LIDW-1:0]   ch_ar_id, ch_aw_id;
  logic [NUM_CH*4-1:0]      ch_ar_asid, ch_aw_asid;
  logic [NUM_CH*DOM_W-1:0]  ch_ar_dom, ch_aw_dom;
  logic [NUM_CH*AW-1:0]     ch_ar_addr, ch_aw_addr;
  logic [NUM_CH*8-1:0]      ch_ar_len, ch_aw_len;
  logic [LIDW-1:0]          mux_r_id, mux_b_id;
  logic [NUM_CH*DW-1:0]     ch_w_data;
  logic [NUM_CH*WB-1:0]     ch_w_strb;
  logic [NUM_CH-1:0]        ch_proto;
  logic [NUM_CH*512-1:0]    ch_pf_add;
  logic [NUM_CH*64-1:0]     ch_pm_val;
  logic [NUM_CH*4-1:0]      ch_tr_v;
  logic [NUM_CH*4*8-1:0]    ch_tr_code;
  logic [NUM_CH*4*32-1:0]   ch_tr_arg;
  logic [NUM_CH*16-1:0]     ch_tr_txn;
  logic [NUM_CH-1:0]        ch_done_irq;

  wire r_err_w = (m_r_resp != silicaflux_dma_pkg::RESP_OKAY);
  wire b_err_w = (m_b_resp != silicaflux_dma_pkg::RESP_OKAY);

  genvar gi;
  generate
    for (gi = 0; gi < NUM_CH; gi++) begin : g_ch
      sfdma_channel #(.DW(DW), .AW(AW), .DOM_W(DOM_W), .MAXB(MAX_BURST_BEATS), .BND_LOG2(BND_LOG2), .RD_OUT(RD_OUT), .WR_OUT(WR_OUT),
                      .BUF_BYTES(BUF_BYTES), .ELQ(ELQ), .CMDQ(CMDQ), .MAX_ELEM_LOG2(MAX_ELEM_LOG2), .MAX_TOTAL_LOG2(MAX_TOTAL_LOG2),
                      .REORDER_OK(REORDER_OK), .CRC_ON(CRC_ON)) u_ch (
        .clk, .rst_n(core_rst_n),
        .enable, .timeout, .max_chain_rt, .asid_en, .ch_abort(ch_abort[gi]),
        .cmd_valid(cmd_valid[gi]), .cmd_ready(cmd_ready[gi]), .cmd_head(cmd_head[64*gi +: 64]),
        .cmd_domain(cmd_domain[DOM_W*gi +: DOM_W]), .cmd_asid(cmd_asid[4*gi +: 4]),
        .done_valid(done_valid[gi]), .done_ready(done_ready[gi]), .done_txn(done_txn[16*gi +: 16]), .done_status(done_status[4*gi +: 4]),
        .done_err(done_err[8*gi +: 8]), .done_fault(done_fault[4*gi +: 4]), .done_domain(done_domain[DOM_W*gi +: DOM_W]),
        .done_bytes(done_bytes[32*gi +: 32]), .done_crc(done_crc[32*gi +: 32]), .done_irq(ch_done_irq[gi]), .viol_evt(viol_evt[gi]),
        .pc_req_valid(ch_pc_req_valid[4*gi +: 4]), .pc_req_ready(ch_pc_req_ready[4*gi +: 4]), .pc_req_domain(ch_pc_domain[DOM_W*gi +: DOM_W]),
        .pc_req_asid(ch_pc_req_asid[16*gi +: 16]), .pc_req_write(ch_pc_req_write[4*gi +: 4]), .pc_req_addr(ch_pc_req_addr[4*AW*gi +: 4*AW]),
        .pc_req_bytes(ch_pc_req_bytes[64*gi +: 64]), .pc_rsp_valid(ch_pc_rsp_valid[4*gi +: 4]), .pc_rsp_ok(ch_pc_rsp_ok[4*gi +: 4]),
        .pc_rsp_fault(ch_pc_rsp_fault[16*gi +: 16]), .pc_rsp_pa(ch_pc_rsp_pa[4*AW*gi +: 4*AW]),
        .ar_valid(ch_ar_valid[gi]), .ar_ready(ch_ar_ready[gi]), .ar_id(ch_ar_id[LIDW*gi +: LIDW]), .ar_asid(ch_ar_asid[4*gi +: 4]),
        .ar_domain(ch_ar_dom[DOM_W*gi +: DOM_W]), .ar_addr(ch_ar_addr[AW*gi +: AW]), .ar_len(ch_ar_len[8*gi +: 8]),
        .r_valid(ch_r_valid[gi]), .r_id(mux_r_id), .r_data(m_r_data), .r_err(r_err_w), .r_last(m_r_last),
        .aw_valid(ch_aw_valid[gi]), .aw_ready(ch_aw_ready[gi]), .aw_id(ch_aw_id[LIDW*gi +: LIDW]), .aw_asid(ch_aw_asid[4*gi +: 4]),
        .aw_domain(ch_aw_dom[DOM_W*gi +: DOM_W]), .aw_addr(ch_aw_addr[AW*gi +: AW]), .aw_len(ch_aw_len[8*gi +: 8]),
        .w_valid(ch_w_valid[gi]), .w_ready(ch_w_ready[gi]), .w_data(ch_w_data[DW*gi +: DW]), .w_strb(ch_w_strb[WB*gi +: WB]), .w_last(ch_w_last[gi]),
        .b_valid(ch_b_valid[gi]), .b_id(mux_b_id), .b_err(b_err_w),
        .st_busy(st_busy[gi]), .st_fenced(st_fenced[gi]), .st_last_status(st_last_status[4*gi +: 4]), .st_last_err(st_last_err[8*gi +: 8]),
        .st_last_fault(st_last_fault[4*gi +: 4]), .st_last_txn(st_last_txn[16*gi +: 16]), .st_last_eaddr(st_last_eaddr[AW*gi +: AW]),
        .st_last_bytes(st_last_bytes[32*gi +: 32]), .st_last_crc(st_last_crc[32*gi +: 32]), .st_last_domain(st_last_domain[DOM_W*gi +: DOM_W]),
        .st_last_descs(st_last_descs[16*gi +: 16]), .st_last_valid(st_last_valid[gi]),
        .pf_add(ch_pf_add[512*gi +: 512]), .pm_val(ch_pm_val[64*gi +: 64]),
        .tr_v(ch_tr_v[4*gi +: 4]), .tr_code(ch_tr_code[32*gi +: 32]), .tr_arg(ch_tr_arg[128*gi +: 128]), .tr_txn(ch_tr_txn[16*gi +: 16]),
        .proto_evt(ch_proto[gi]));
      assign irq_done_evt[gi] = done_valid[gi] && done_ready[gi] && ch_done_irq[gi];
      assign irq_err_evt[gi]  = done_valid[gi] && done_ready[gi] && (done_status[4*gi +: 4] != silicaflux_dma_pkg::ST_OK);
    end
  endgenerate

  // ------------------------------------------------------------------ memory port multiplexer
  logic mux_bad_id;
  logic [ID_W-1:0] mx_ar_id, mx_aw_id;
  // the mux is part of the core: a SOFT reset must clear its W-order FIFO and arbiters together with the channels
  // (found by the 2-channel regression: stale order entries after a soft reset attribute W beats to the wrong channel)
  sfdma_axi_mux #(.NCH(NUM_CH), .DW(DW), .AW(AW), .DOM_W(DOM_W), .LIDW(LIDW), .WDEPTH(NUM_CH * (WR_OUT + 1))) u_mux (
    .clk, .rst_n(core_rst_n),
    .c_ar_valid(ch_ar_valid), .c_ar_ready(ch_ar_ready), .c_ar_id(ch_ar_id), .c_ar_asid(ch_ar_asid), .c_ar_domain(ch_ar_dom),
    .c_ar_addr(ch_ar_addr), .c_ar_len(ch_ar_len), .c_r_valid(ch_r_valid), .c_r_id(mux_r_id),
    .c_aw_valid(ch_aw_valid), .c_aw_ready(ch_aw_ready), .c_aw_id(ch_aw_id), .c_aw_asid(ch_aw_asid), .c_aw_domain(ch_aw_dom),
    .c_aw_addr(ch_aw_addr), .c_aw_len(ch_aw_len), .c_w_valid(ch_w_valid), .c_w_ready(ch_w_ready), .c_w_data(ch_w_data),
    .c_w_strb(ch_w_strb), .c_w_last(ch_w_last), .c_b_valid(ch_b_valid), .c_b_id(mux_b_id),
    .m_ar_valid, .m_ar_ready, .m_ar_id(mx_ar_id), .m_ar_asid, .m_ar_domain, .m_ar_addr, .m_ar_len,
    .m_r_valid, .m_r_id, .m_b_valid, .m_b_id,
    .m_aw_valid, .m_aw_ready, .m_aw_id(mx_aw_id), .m_aw_asid, .m_aw_domain, .m_aw_addr, .m_aw_len,
    .m_w_valid, .m_w_ready, .m_w_data, .m_w_strb, .m_w_last, .bad_id_evt(mux_bad_id));
  assign m_ar_id    = mx_ar_id;
  assign m_aw_id    = mx_aw_id;
  assign m_ar_size  = 3'($clog2(WB));
  assign m_aw_size  = 3'($clog2(WB));
  assign m_ar_burst = 2'b01;                       // INCR
  assign m_aw_burst = 2'b01;
  assign m_r_ready  = 1'b1;                        // credit-based flow control: a response can never find the buffer full
  assign m_b_ready  = 1'b1;

  // ------------------------------------------------------------------ permission checker + IOMMU / simulation table
  logic [NCLI-1:0]        pc_valid, pc_ready, pc_write, pc_rsp_v, pc_rsp_okv;
  logic [NCLI*DOM_W-1:0]  pc_dom;
  logic [NCLI*4-1:0]      pc_asid, pc_rsp_fault;
  logic [NCLI*AW-1:0]     pc_addr, pc_rsp_pa;
  logic [NCLI*16-1:0]     pc_bytes;
  always_comb begin
    for (int c = 0; c < NUM_CH; c++) for (int k = 0; k < 4; k++) pc_dom[(4*c + k)*DOM_W +: DOM_W] = ch_pc_domain[c*DOM_W +: DOM_W];
  end
  assign pc_valid        = ch_pc_req_valid;
  assign pc_write        = ch_pc_req_write;
  assign pc_asid         = ch_pc_req_asid;
  assign pc_addr         = ch_pc_req_addr;
  assign pc_bytes        = ch_pc_req_bytes;
  assign ch_pc_req_ready = pc_ready;
  assign ch_pc_rsp_valid = pc_rsp_v;
  assign ch_pc_rsp_ok    = pc_rsp_okv;
  assign ch_pc_rsp_fault = pc_rsp_fault;
  assign ch_pc_rsp_pa    = pc_rsp_pa;

  logic                i_req_valid, i_req_ready, i_req_write, i_rsp_valid, i_rsp_ready, i_rsp_ok, chk_proto;
  logic [DOM_W-1:0]    i_req_domain;
  logic [3:0]          i_req_asid, i_rsp_fault;
  logic [AW-1:0]       i_req_addr, i_rsp_pa;
  logic [15:0]         i_req_bytes;
  logic [IDP-1:0]      i_req_id, i_rsp_id;

  sfdma_perm_checker #(.NCLI(NCLI), .AW(AW), .DOM_W(DOM_W), .DW(DW), .PERM_OUT(PERM_OUT)) u_chk (
    .clk, .rst_n(core_rst_n), .asid_en,
    .c_req_valid(pc_valid), .c_req_ready(pc_ready), .c_req_domain(pc_dom), .c_req_asid(pc_asid), .c_req_write(pc_write),
    .c_req_addr(pc_addr), .c_req_bytes(pc_bytes), .c_rsp_valid(pc_rsp_v), .c_rsp_ok(pc_rsp_okv), .c_rsp_fault(pc_rsp_fault), .c_rsp_pa(pc_rsp_pa),
    .iommu_req_valid(i_req_valid), .iommu_req_ready(i_req_ready), .iommu_req_domain(i_req_domain), .iommu_req_asid(i_req_asid),
    .iommu_req_write(i_req_write), .iommu_req_addr(i_req_addr), .iommu_req_bytes(i_req_bytes), .iommu_req_id(i_req_id),
    .iommu_rsp_valid(i_rsp_valid), .iommu_rsp_ready(i_rsp_ready), .iommu_rsp_id(i_rsp_id), .iommu_rsp_ok(i_rsp_ok),
    .iommu_rsp_fault(i_rsp_fault), .iommu_rsp_pa(i_rsp_pa), .proto_err_evt(chk_proto));

  generate
    if (USE_EXT_IOMMU) begin : g_ext
      assign iommu_req_valid  = i_req_valid;    assign i_req_ready = iommu_req_ready;
      assign iommu_req_domain = i_req_domain;   assign iommu_req_asid = i_req_asid;
      assign iommu_req_write  = i_req_write;    assign iommu_req_addr = i_req_addr;
      assign iommu_req_bytes  = i_req_bytes;    assign iommu_req_id   = i_req_id;
      assign i_rsp_valid = iommu_rsp_valid;     assign iommu_rsp_ready = i_rsp_ready;
      assign i_rsp_id    = iommu_rsp_id;        assign i_rsp_ok = iommu_rsp_ok;
      assign i_rsp_fault = iommu_rsp_fault;     assign i_rsp_pa = iommu_rsp_pa;
      assign ptbl_rej    = 1'b0;
      wire unused_ptbl = ptbl_en || (|ptbl_idx) || ptbl_valid || (|ptbl_domain) || (|ptbl_asid) || (|ptbl_base) || (|ptbl_size) || (|ptbl_pa) || (|ptbl_perm);
    end else begin : g_sim
      assign iommu_req_valid = 1'b0; assign iommu_req_domain = '0; assign iommu_req_asid = '0; assign iommu_req_write = 1'b0;
      assign iommu_req_addr = '0;    assign iommu_req_bytes = '0;  assign iommu_req_id = '0;    assign iommu_rsp_ready = 1'b0;
      wire unused_iommu = iommu_req_ready || iommu_rsp_valid || (|iommu_rsp_id) || iommu_rsp_ok || (|iommu_rsp_fault) || (|iommu_rsp_pa);
      logic [31:0] rej_cnt;
      sfdma_perm_table #(.AW(AW), .DOM_W(DOM_W), .IDW(IDP), .NENT(PERM_ENTRIES), .LAT(PERM_LAT)) u_tbl (
        .clk, .rst_n,
        .tw_en(ptbl_en), .tw_idx(ptbl_idx), .tw_valid(ptbl_valid), .tw_domain(ptbl_domain), .tw_asid(ptbl_asid), .tw_base(ptbl_base),
        .tw_size(ptbl_size), .tw_pa(ptbl_pa), .tw_perm(ptbl_perm), .tw_rej(ptbl_rej), .rej_count(rej_cnt),
        .req_valid(i_req_valid), .req_ready(i_req_ready), .req_domain(i_req_domain), .req_asid(i_req_asid), .req_write(i_req_write),
        .req_addr(i_req_addr), .req_bytes(i_req_bytes), .req_id(i_req_id),
        .rsp_valid(i_rsp_valid), .rsp_ready(i_rsp_ready), .rsp_id(i_rsp_id), .rsp_ok(i_rsp_ok), .rsp_fault(i_rsp_fault), .rsp_pa(i_rsp_pa));
      wire unused_rej = |rej_cnt;
    end
  endgenerate

  // ------------------------------------------------------------------ performance counters and trace
  sfdma_perf #(.NCH(NUM_CH), .PC_W(PC_W)) u_perf (
    .clk, .rst_n, .clr(perf_clr), .pf_add(ch_pf_add), .pm_val(ch_pm_val), .sel_ch(perf_sel_ch), .sel_id(perf_sel_id), .rd_val(perf_val));
  sfdma_trace #(.NCH(NUM_CH), .DEPTH(TRACE_DEPTH)) u_trace (
    .clk, .rst_n, .en(trace_en), .clr(perf_clr), .tr_v(ch_tr_v), .tr_code(ch_tr_code), .tr_arg(ch_tr_arg), .tr_txn(ch_tr_txn),
    .pop(trace_pop), .head(tr_head), .count(tr_count), .dropped(tr_drop));

  // protocol events: a response nobody is waiting for (IOMMU), an ID that names no channel (mux), a stray late B (channel)
  wire proto_any = mux_bad_id || chk_proto || (|ch_proto);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) proto_cnt <= 32'd0;
    else if (proto_any && proto_cnt != 32'hFFFF_FFFF) proto_cnt <= proto_cnt + 32'd1;
  end
endmodule

`default_nettype wire
