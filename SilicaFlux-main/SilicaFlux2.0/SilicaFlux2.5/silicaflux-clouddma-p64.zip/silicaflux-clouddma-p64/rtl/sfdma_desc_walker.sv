// =============================================================================
// CloudDMA :: sfdma_desc_walker -- descriptor fetch, validation and chain walking (one channel)
//
//   start -> PLAN -> CHK (permission checker, CLI_DESC) -> CHKW -> AR -> R (collect 64 B) -> VAL -> EMIT -> NEXT -> ..
//
// * Every descriptor is fetched THROUGH the permission checker (read of 64 B at the descriptor address in the
//   descriptor address space, as the channel's bound domain).  A tenant cannot make the DMA read descriptors from
//   memory the tenant may not read.
// * A descriptor is fetched ONCE into an internal register and validated and used from that copy only
//   (no time-of-check / time-of-use window against host memory that software can still write).
// * Validation is just-in-time, descriptor by descriptor: elements validated before a bad descriptor execute
//   (they were individually authorised); the bad descriptor and everything after it do not.  The chain is NOT
//   atomic (docs/02_DESCRIPTOR_FORMAT.md).
// * Chain rules: linked mode (NEXT_PTR, 64-byte aligned, non-zero) or array mode (next = this + 64); LAST ends the
//   chain; the head carries HEAD and the transaction-level flags; SEQ must equal the position in the chain, so a
//   descriptor visited twice (a cycle) is refused at the first revisit; at most max_chain descriptors; at most
//   2**MAX_TOTAL_LOG2 bytes; element length <= 2**MAX_ELEM_LOG2; every address range checked in wider arithmetic
//   (no wrap); source and destination of an element may not overlap inside one address space.
// * Zero-length elements are legal no-ops: validated like any other, no bus traffic, no permission query.
// Validation priority (first failing rule wins):  version, opcode, domain claim, SEQ, TXN_ID, flags, reserved
//   fields, completion address, ASIDs, length, total, address range, address overflow, overlap, chain linkage,
//   chain length.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfdma_desc_walker #(
  parameter int DW             = 64,
  parameter int AW             = 48,
  parameter int DOM_W          = 4,
  parameter int MAX_ELEM_LOG2  = 24,
  parameter int MAX_TOTAL_LOG2 = 30,
  localparam int WB            = DW / 8,
  localparam int DBEATS        = 64 / WB
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // command
  input  wire logic            start,                 // pulse; only when !busy
  input  wire logic [63:0]     start_head,
  input  wire logic [DOM_W-1:0] start_domain,
  input  wire logic [3:0]      start_asid,            // address space the descriptors live in
  input  wire logic            stop,                  // level: abort / error elsewhere -> stop fetching, drain
  input  wire logic [15:0]     max_chain_rt,
  input  wire logic [15:0]     asid_en,
  // permission checker client (domain / write are supplied by the channel)
  output logic                 pc_req_valid,
  input  wire logic            pc_req_ready,
  output logic [AW-1:0]        pc_req_addr,
  output logic [3:0]           pc_req_asid,
  output logic [DOM_W-1:0]     pc_req_domain,
  output logic [15:0]          pc_req_bytes,
  input  wire logic            pc_rsp_valid,
  input  wire logic            pc_rsp_ok,
  input  wire logic [3:0]      pc_rsp_fault,
  input  wire logic [AW-1:0]   pc_rsp_pa,
  // bus: descriptor read
  output logic                 ar_valid,
  input  wire logic            ar_ready,
  output logic [AW-1:0]        ar_addr,
  output logic [7:0]           ar_len,
  input  wire logic            r_valid,
  input  wire logic [DW-1:0]   r_data,
  input  wire logic            r_err,
  input  wire logic            r_last,
  // elements
  output logic                 el_valid,
  input  wire logic            el_ready,
  output logic [3:0]           el_src_asid,
  output logic [3:0]           el_dst_asid,
  output logic [AW-1:0]        el_src,
  output logic [AW-1:0]        el_dst,
  output logic [31:0]          el_len,
  output logic                 el_ordered,
  // transaction-level information from the head descriptor
  output logic [15:0]          tx_txn,
  output logic                 tx_cpl_en,
  output logic                 tx_crc_en,
  output logic                 tx_irq_en,
  output logic [AW-1:0]        tx_cpl_addr,
  output logic [3:0]           tx_cpl_asid,
  // status
  output logic                 busy,
  output logic                 walk_done,             // chain fully handed over (or walk failed)
  output logic                 walk_fail,
  output logic                 err_evt,               // pulse at the first error
  output logic [7:0]           err_code,
  output logic [3:0]           err_fault,
  output logic [AW-1:0]        err_addr,
  output logic [15:0]          descs_done,
  output logic                 busy_wait_perm,        // waiting for the permission checker (perf)
  output logic                 ev_desc,               // pulse: descriptor validated
  output logic [15:0]          ev_desc_lat,           // its fetch latency (cycles)
  output logic [31:0]          ev_desc_arg            // {seq, flags}
);

  // ------------------------------------------------------------------ state
  localparam logic [3:0] W_IDLE = 4'd0, W_PLAN = 4'd1, W_CHK = 4'd2, W_CHKW = 4'd3, W_AR = 4'd4, W_R = 4'd5,
                         W_VAL = 4'd6, W_EMIT = 4'd7, W_NEXT = 4'd8, W_DONE = 4'd9;
  localparam logic [64:0]  LIM65     = 65'd1 << AW;                   // 2**AW
  localparam logic [32:0]  MAX_ELEM  = 33'd1 << MAX_ELEM_LOG2;
  localparam logic [32:0]  MAX_TOTAL = 33'd1 << MAX_TOTAL_LOG2;

  logic [3:0]      st_q;
  logic [AW-1:0]   cur_q, pa_q;
  logic [15:0]     seq_q;
  logic [31:0]     total_q;
  logic [DOM_W-1:0] dom_q;
  logic [3:0]      dasid_q;
  logic [DW-1:0]   unused_dw;                                       // (keeps lint quiet about r_data width on 512-bit buses)
  logic [511:0]    desc_q;
  logic [7:0]      k_q;
  logic            rerr_q, perr_q, stop_q;
  logic            fail_q;
  logic [7:0]      ecode_q;
  logic [3:0]      efault_q;
  logic [AW-1:0]   eaddr_q;
  logic [15:0]     lat_q;
  logic [15:0]     cnt_q;
  // head information
  logic [15:0]     txn_q;
  logic            cpl_en_q, crc_en_q, irq_en_q;
  logic [AW-1:0]   cpl_addr_q;
  logic [3:0]      cpl_asid_q;
  // element register
  logic            elv_q;
  logic [3:0]      el_sa_q, el_da_q;
  logic [AW-1:0]   el_s_q, el_d_q;
  logic [31:0]     el_l_q;
  logic            el_o_q;
  logic            last_q;                                          // the validated descriptor had LAST set
  logic [AW-1:0]   next_q;

  assign busy        = (st_q != W_IDLE) && (st_q != W_DONE);
  assign walk_done   = (st_q == W_DONE);
  assign walk_fail   = fail_q;
  assign err_code    = ecode_q;
  assign err_fault   = efault_q;
  assign err_addr    = eaddr_q;
  assign descs_done  = cnt_q;
  assign tx_txn      = txn_q;
  assign tx_cpl_en   = cpl_en_q;
  assign tx_crc_en   = crc_en_q;
  assign tx_irq_en   = irq_en_q;
  assign tx_cpl_addr = cpl_addr_q;
  assign tx_cpl_asid = cpl_asid_q;

  assign pc_req_valid   = (st_q == W_CHK);
  assign pc_req_addr    = cur_q;
  assign pc_req_bytes   = 16'd64;
  assign pc_req_asid    = dasid_q;
  assign pc_req_domain  = dom_q;
  assign busy_wait_perm = (st_q == W_CHK) || (st_q == W_CHKW);
  assign ar_valid       = (st_q == W_AR);
  assign ar_addr        = pa_q;
  assign ar_len         = 8'(DBEATS - 1);
  assign el_valid       = (st_q == W_EMIT) && elv_q;
  assign el_src_asid    = el_sa_q;
  assign el_dst_asid    = el_da_q;
  assign el_src         = el_s_q;
  assign el_dst         = el_d_q;
  assign el_len         = el_l_q;
  assign el_ordered     = el_o_q;
  assign unused_dw      = r_data;

  // ------------------------------------------------------------------ descriptor fields
  wire [7:0]  d_ver   = desc_q[silicaflux_dma_pkg::DESC_VER_LSB   +: 8];
  wire [7:0]  d_opc   = desc_q[silicaflux_dma_pkg::DESC_OPC_LSB   +: 8];
  wire [15:0] d_flags = desc_q[silicaflux_dma_pkg::DESC_FLAGS_LSB +: 16];
  wire [15:0] d_txn   = desc_q[silicaflux_dma_pkg::DESC_TXN_LSB   +: 16];
  wire [15:0] d_dom   = desc_q[silicaflux_dma_pkg::DESC_DOM_LSB   +: 16];
  wire [3:0]  d_sasid = desc_q[silicaflux_dma_pkg::DESC_SASID_LSB +: 4];
  wire [3:0]  d_dasid = desc_q[silicaflux_dma_pkg::DESC_DASID_LSB +: 4];
  wire [3:0]  d_casid = desc_q[silicaflux_dma_pkg::DESC_CASID_LSB +: 4];
  wire [19:0] d_w2rs  = desc_q[silicaflux_dma_pkg::DESC_W2RSVD_LSB +: 20];
  wire [31:0] d_len   = desc_q[silicaflux_dma_pkg::DESC_LEN_LSB   +: 32];
  wire [63:0] d_src   = desc_q[silicaflux_dma_pkg::DESC_SRC_LSB   +: 64];
  wire [63:0] d_dst   = desc_q[silicaflux_dma_pkg::DESC_DST_LSB   +: 64];
  wire [63:0] d_next  = desc_q[silicaflux_dma_pkg::DESC_NEXT_LSB  +: 64];
  wire [63:0] d_cpl   = desc_q[silicaflux_dma_pkg::DESC_CPL_LSB   +: 64];
  wire [15:0] d_seq   = desc_q[silicaflux_dma_pkg::DESC_SEQ_LSB   +: 16];
  wire [15:0] d_w12rs = desc_q[silicaflux_dma_pkg::DESC_W12RSVD_LSB +: 16];
  wire [95:0] d_rsvd  = desc_q[silicaflux_dma_pkg::DESC_RSVD_LSB  +: 96];

  wire f_last    = d_flags[silicaflux_dma_pkg::FLG_LAST];
  wire f_array   = d_flags[silicaflux_dma_pkg::FLG_ARRAY];
  wire f_head    = d_flags[silicaflux_dma_pkg::FLG_HEAD];
  wire f_ordered = d_flags[silicaflux_dma_pkg::FLG_ORDERED];
  wire f_cpl     = d_flags[silicaflux_dma_pkg::FLG_CPL_EN];
  wire f_crc     = d_flags[silicaflux_dma_pkg::FLG_CRC_EN];
  wire f_irq     = d_flags[silicaflux_dma_pkg::FLG_IRQ_EN];
  wire is_head   = (seq_q == 16'd0);

  // ------------------------------------------------------------------ validation (combinational on the fetched copy)
  logic [7:0] verr;
  logic [64:0] s_end, d_end, c_end, n_end, a_end;
  logic [32:0] tot_n;
  always_comb begin
    s_end = {1'b0, d_src} + {33'd0, d_len};
    d_end = {1'b0, d_dst} + {33'd0, d_len};
    c_end = {1'b0, d_cpl} + 65'd32;
    n_end = {1'b0, d_next} + 65'd64;
    a_end = {{(65-AW){1'b0}}, cur_q} + 65'd128;               // array mode: the NEXT descriptor [cur+64, cur+128) must fit
    tot_n = {1'b0, total_q} + {1'b0, d_len};
    verr  = silicaflux_dma_pkg::ERR_NONE;
    if (d_ver != silicaflux_dma_pkg::DESC_VERSION_1)                          verr = silicaflux_dma_pkg::ERR_DESC_VERSION;
    else if (d_opc != silicaflux_dma_pkg::OPC_COPY)                            verr = silicaflux_dma_pkg::ERR_DESC_OPCODE;
    else if (d_dom != {{(16-DOM_W){1'b0}}, dom_q})                             verr = silicaflux_dma_pkg::ERR_DOMAIN_MISMATCH;
    else if (d_seq != seq_q)                                                   verr = silicaflux_dma_pkg::ERR_CHAIN_SEQ;
    else if (!is_head && (d_txn != txn_q))                                     verr = silicaflux_dma_pkg::ERR_CHAIN_TXN;
    else if ((d_flags & silicaflux_dma_pkg::FLG_RSVD_MASK) != 16'd0 || (f_head != is_head) ||
             (!is_head && ((d_flags & silicaflux_dma_pkg::FLG_HEADONLY_MASK) != 16'd0)) || (f_last && f_array))
                                                                               verr = silicaflux_dma_pkg::ERR_DESC_FLAGS;
    else if (d_w2rs != 20'd0 || d_w12rs != 16'd0 || d_rsvd != 96'd0 ||
             (!(is_head && f_cpl) && (d_cpl != 64'd0 || d_casid != 4'd0)) ||
             ((f_last || f_array) && d_next != 64'd0))
                                                                               verr = silicaflux_dma_pkg::ERR_DESC_RSVD;
    else if (is_head && f_cpl && (d_cpl == 64'd0 || d_cpl[4:0] != 5'd0))      verr = silicaflux_dma_pkg::ERR_CPL_ALIGN;
    else if (!asid_en[d_sasid] || !asid_en[d_dasid] || (is_head && f_cpl && !asid_en[d_casid]))
                                                                               verr = silicaflux_dma_pkg::ERR_BAD_ASID;
    else if ({1'b0, d_len} > MAX_ELEM)                                         verr = silicaflux_dma_pkg::ERR_LEN_TOO_BIG;
    else if (tot_n > MAX_TOTAL)                                                verr = silicaflux_dma_pkg::ERR_TOTAL_TOO_BIG;
    else if ({1'b0, d_src} >= LIM65 || {1'b0, d_dst} >= LIM65 ||
             (is_head && f_cpl && {1'b0, d_cpl} >= LIM65))
                                                                               verr = silicaflux_dma_pkg::ERR_ADDR_RANGE;
    else if ((d_len != 32'd0 && (s_end > LIM65 || d_end > LIM65)) ||
             (is_head && f_cpl && c_end > LIM65))
                                                                               verr = silicaflux_dma_pkg::ERR_ADDR_OVERFLOW;
    else if (d_len != 32'd0 && d_sasid == d_dasid && ({1'b0, d_src} < d_end) && ({1'b0, d_dst} < s_end))
                                                                               verr = silicaflux_dma_pkg::ERR_OVERLAP;
    else if (!f_last) begin
      if (f_array) begin
        if (a_end > LIM65)                                  verr = silicaflux_dma_pkg::ERR_ADDR_OVERFLOW;
      end else begin
        if (d_next == 64'd0)                                                   verr = silicaflux_dma_pkg::ERR_CHAIN_NULL;
        else if (d_next[5:0] != 6'd0)                                          verr = silicaflux_dma_pkg::ERR_DESC_ALIGN;
        else if ({1'b0, d_next} >= LIM65)                   verr = silicaflux_dma_pkg::ERR_ADDR_RANGE;
        else if (n_end > LIM65)                             verr = silicaflux_dma_pkg::ERR_ADDR_OVERFLOW;
      end
      if (verr == silicaflux_dma_pkg::ERR_NONE && (32'(seq_q) + 32'd1 >= 32'(max_chain_rt)))
                                                                               verr = silicaflux_dma_pkg::ERR_CHAIN_TOO_LONG;
    end
  end

  // head command checks (alignment, range)
  wire [64:0] head_end = {1'b0, start_head} + 65'd64;
  logic [7:0] herr;
  always_comb begin
    herr = silicaflux_dma_pkg::ERR_NONE;
    if (start_head[5:0] != 6'd0)                                               herr = silicaflux_dma_pkg::ERR_DESC_ALIGN;
    else if ({1'b0, start_head} >= LIM65)                                      herr = silicaflux_dma_pkg::ERR_ADDR_RANGE;
    else if (head_end > LIM65)                              herr = silicaflux_dma_pkg::ERR_ADDR_OVERFLOW;
    else if (!asid_en[start_asid])                                             herr = silicaflux_dma_pkg::ERR_BAD_ASID;
  end

  // ------------------------------------------------------------------ FSM
  wire stop_any = stop || stop_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= W_IDLE; cur_q <= '0; pa_q <= '0; seq_q <= '0; total_q <= '0; dom_q <= '0; dasid_q <= '0;
      desc_q <= '0; k_q <= '0; rerr_q <= 1'b0; perr_q <= 1'b0; stop_q <= 1'b0; fail_q <= 1'b0;
      ecode_q <= silicaflux_dma_pkg::ERR_NONE; efault_q <= '0; eaddr_q <= '0; lat_q <= '0; cnt_q <= '0;
      txn_q <= '0; cpl_en_q <= 1'b0; crc_en_q <= 1'b0; irq_en_q <= 1'b0; cpl_addr_q <= '0; cpl_asid_q <= '0;
      elv_q <= 1'b0; el_sa_q <= '0; el_da_q <= '0; el_s_q <= '0; el_d_q <= '0; el_l_q <= '0; el_o_q <= 1'b0;
      last_q <= 1'b0; next_q <= '0; err_evt <= 1'b0; ev_desc <= 1'b0; ev_desc_lat <= '0; ev_desc_arg <= '0;
    end else begin
      err_evt <= 1'b0;
      ev_desc <= 1'b0;
      if (stop) stop_q <= 1'b1;
      if (st_q == W_PLAN || st_q == W_CHK || st_q == W_CHKW || st_q == W_AR || st_q == W_R) lat_q <= lat_q + 16'd1;

      case (st_q)
        W_IDLE, W_DONE: begin
          if (start) begin
            stop_q <= 1'b0; fail_q <= 1'b0; ecode_q <= silicaflux_dma_pkg::ERR_NONE; efault_q <= '0; eaddr_q <= '0;
            seq_q <= '0; total_q <= '0; cnt_q <= '0; txn_q <= '0; cpl_en_q <= 1'b0; crc_en_q <= 1'b0; irq_en_q <= 1'b0;
            cpl_addr_q <= '0; cpl_asid_q <= '0; elv_q <= 1'b0; rerr_q <= 1'b0; perr_q <= 1'b0;
            dom_q <= start_domain; dasid_q <= start_asid;
            cur_q <= start_head[AW-1:0];
            if (herr != silicaflux_dma_pkg::ERR_NONE) begin
              fail_q <= 1'b1; ecode_q <= herr; eaddr_q <= start_head[AW-1:0]; err_evt <= 1'b1; st_q <= W_DONE;
            end else begin
              st_q <= W_PLAN; lat_q <= 16'd0;
            end
          end
        end
        W_PLAN: begin
          if (stop_any) st_q <= W_DONE;
          else          st_q <= W_CHK;
        end
        W_CHK: if (pc_req_ready) st_q <= W_CHKW;                    // request must be held until accepted
        W_CHKW: begin
          if (pc_rsp_valid) begin
            if (stop_any) st_q <= W_DONE;
            else if (!pc_rsp_ok) begin
              fail_q <= 1'b1; ecode_q <= silicaflux_dma_pkg::ERR_PERM_DESC; efault_q <= pc_rsp_fault; eaddr_q <= cur_q;
              err_evt <= 1'b1; st_q <= W_DONE;
            end else begin
              pa_q <= pc_rsp_pa; st_q <= W_AR;
            end
          end
        end
        W_AR: if (ar_ready) begin st_q <= W_R; k_q <= '0; rerr_q <= 1'b0; perr_q <= 1'b0; end   // presented request is never withdrawn
        W_R: begin
          if (r_valid) begin
            for (int c = 0; c < WB; c++) begin
              if (32'(k_q) * WB + c < 64) desc_q[8*(32'(k_q) * WB + c) +: 8] <= r_data[8*c +: 8];
            end
            if (r_err) rerr_q <= 1'b1;
            if (r_last != (32'(k_q) == DBEATS - 1)) perr_q <= 1'b1;
            k_q <= k_q + 8'd1;
            if (r_last || 32'(k_q) == DBEATS - 1) begin
              if (stop_any) st_q <= W_DONE;
              else if (rerr_q || r_err || perr_q || (r_last != (32'(k_q) == DBEATS - 1))) begin
                fail_q <= 1'b1; eaddr_q <= cur_q; err_evt <= 1'b1; st_q <= W_DONE;
                ecode_q <= (perr_q || (r_last != (32'(k_q) == DBEATS - 1))) ? silicaflux_dma_pkg::ERR_PROTOCOL
                                                                           : silicaflux_dma_pkg::ERR_BUS_DESC;
              end else st_q <= W_VAL;
            end
          end
        end
        W_VAL: begin
          if (stop_any) st_q <= W_DONE;
          else if (verr != silicaflux_dma_pkg::ERR_NONE) begin
            fail_q <= 1'b1; ecode_q <= verr; eaddr_q <= cur_q; err_evt <= 1'b1; st_q <= W_DONE;
          end else begin
            if (is_head) begin
              txn_q <= d_txn; cpl_en_q <= f_cpl; crc_en_q <= f_crc; irq_en_q <= f_irq;
              cpl_addr_q <= d_cpl[AW-1:0]; cpl_asid_q <= f_cpl ? d_casid : 4'd0;
            end
            total_q  <= tot_n[31:0];
            el_sa_q  <= d_sasid; el_da_q <= d_dasid; el_s_q <= d_src[AW-1:0]; el_d_q <= d_dst[AW-1:0];
            el_l_q   <= d_len;   el_o_q <= f_ordered;
            elv_q    <= (d_len != 32'd0);
            last_q   <= f_last;
            next_q   <= f_array ? cur_q + AW'(64) : d_next[AW-1:0];
            ev_desc  <= 1'b1; ev_desc_lat <= lat_q; ev_desc_arg <= {d_seq, d_flags};
            st_q     <= W_EMIT;
          end
        end
        W_EMIT: begin
          if (stop_any) begin elv_q <= 1'b0; st_q <= W_DONE; end
          else if (!elv_q) st_q <= W_NEXT;                           // zero-length element: nothing to hand over
          else if (el_ready) begin elv_q <= 1'b0; st_q <= W_NEXT; end
        end
        W_NEXT: begin
          cnt_q <= cnt_q + 16'd1;
          if (last_q) st_q <= W_DONE;
          else begin
            cur_q <= next_q; seq_q <= seq_q + 16'd1; lat_q <= 16'd0; st_q <= W_PLAN;
          end
        end
        default: st_q <= W_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
