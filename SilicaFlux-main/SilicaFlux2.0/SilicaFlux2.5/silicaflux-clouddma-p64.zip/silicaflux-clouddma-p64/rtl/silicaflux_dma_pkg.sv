// =============================================================================
// SilicaFlux CloudDMA (Project 64) :: silicaflux_dma_pkg -- descriptor package
//
// SINGLE SOURCE OF TRUTH for every constant, field position, flag, error code and register offset that crosses
// a module, firmware or testbench boundary.  Version 1 of the descriptor ABI.
//
//   * Synthesizable RTL uses ONLY localparams of this package, fully qualified (silicaflux_dma_pkg::NAME), on flat
//     bit vectors.  Reason: the baseline flow (Yosys 0.33) rejects `import`, structs, `return` and `int'()` casts
//     (same rule as Project 61, docs/05_VERIFICATION.md there; re-verified here, docs/07_SYNTHESIS.md).  Package
//     references are accepted in module bodies, NOT in module parameter lists.
//   * Testbenches may `import silicaflux_dma_pkg::*` and use the verification-only struct views at the end.
//     tb/tb_pkg_layout.sv proves the struct views and the flat positions describe the same bits.
//
// BYTE ORDER.  Little endian everywhere: byte i of a 32-bit word is bits [8i+7:8i]; a 64-bit field is two words,
// low word first (word n = bits [32n+31:32n] of the flat descriptor; byte j of the descriptor is memory byte
// base+j).  This is the byte order of the DataFabric SFB2 and of the AXI4 data lanes (byte lane b = address A+b).
//
// DESCRIPTOR (64 bytes, 64-byte aligned, 16 words)                       (docs/02_DESCRIPTOR_FORMAT.md)
//   W0   [7:0] VERSION (=1)  [15:8] OPCODE (0 = COPY)  [31:16] FLAGS
//   W1   [15:0] TXN_ID       [31:16] DOMAIN (claim, checked against the hardware binding)
//   W2   [3:0] SRC_ASID  [7:4] DST_ASID  [11:8] CPL_ASID  [31:12] reserved, must be 0
//   W3   LENGTH   (bytes of THIS element, 0 .. 2**MAX_ELEM_LOG2; 0 = no-op element)
//   W4,5 SRC_ADDR (64-bit, byte granular)      W6,7 DST_ADDR (64-bit, byte granular)
//   W8,9 NEXT_PTR (64-bit, 64-byte aligned; used only when !LAST && !ARRAY)
//   W10,11 CPL_ADDR (64-bit, 32-byte aligned; head only; completion record location)
//   W12  [15:0] SEQ (must equal the descriptor's position in the chain: 0,1,2,..)  [31:16] reserved, must be 0
//   W13..15 reserved, must be 0
// COMPLETION RECORD (32 bytes, 32-byte aligned, 8 words)
// Classification: SYNTHESIZABLE (constants), VERIFICATION-ONLY (struct views)
// =============================================================================
package silicaflux_dma_pkg;

  // ---------------------------------------------------------------- identification
  localparam logic [31:0] DMA_ID_MAGIC  = 32'h5346_444D;   // "SFDM"
  localparam logic [15:0] DMA_ABI_MAJOR = 16'd1;           // descriptor / record / CSR layout
  localparam logic [15:0] DMA_ABI_MINOR = 16'd0;
  localparam logic [31:0] DMA_RTL_VER   = 32'h0001_0000;   // Project 64 RTL 1.0

  // ---------------------------------------------------------------- limits and widths
  localparam int DESC_BYTES     = 64;
  localparam int DESC_W         = 512;
  localparam int DESC_NW        = 16;
  localparam int CPL_BYTES      = 32;
  localparam int CPL_W          = 256;
  localparam int CPL_NW         = 8;
  localparam int ASID_W         = 4;
  localparam int MAX_DOM_W      = 16;
  localparam int LEN_W          = 32;
  localparam int ADDR_MAX_W     = 64;
  localparam int ABS_MAX_CHAIN  = 65535;   // SEQ field is 16 bit
  localparam int BND_LOG2_MAX   = 12;      // AXI4: a burst must not cross a 4 KiB boundary

  // ---------------------------------------------------------------- address-space identifiers (SRC/DST/CPL_ASID)
  localparam logic [3:0] ASID_HOST    = 4'd0;   // host-visible memory (IOVA, translated by the IOMMU)
  localparam logic [3:0] ASID_SRAM    = 4'd1;   // local SRAM (tenant partition)
  localparam logic [3:0] ASID_STORAGE = 4'd2;   // StorageCore buffer window
  localparam logic [3:0] ASID_NET     = 4'd3;   // NetworkCore packet buffers
  localparam logic [3:0] ASID_COMPUTE = 4'd4;   // compute-engine scratchpad
  localparam int         NUM_ASIDS    = 5;      // 5..15 are reserved and rejected
  localparam logic [15:0] ASID_EN_DEFAULT = 16'h001F;

  // ---------------------------------------------------------------- operation codes
  localparam logic [7:0] DESC_VERSION_1 = 8'h01;
  localparam logic [7:0] OPC_COPY       = 8'h00;   // copy LENGTH bytes SRC -> DST
  //                                       0x01..0xFF reserved: rejected with ERR_DESC_OPCODE

  // ---------------------------------------------------------------- flat descriptor layout (bit positions in the 512-bit value)
  localparam int DESC_VER_LSB     = 0;     // [7:0]
  localparam int DESC_OPC_LSB     = 8;     // [15:8]
  localparam int DESC_FLAGS_LSB   = 16;    // [31:16]
  localparam int DESC_TXN_LSB     = 32;    // [47:32]
  localparam int DESC_DOM_LSB     = 48;    // [63:48]
  localparam int DESC_SASID_LSB   = 64;    // [67:64]
  localparam int DESC_DASID_LSB   = 68;    // [71:68]
  localparam int DESC_CASID_LSB   = 72;    // [75:72]
  localparam int DESC_W2RSVD_LSB  = 76;    // [95:76] must be 0
  localparam int DESC_LEN_LSB     = 96;    // [127:96]
  localparam int DESC_SRC_LSB     = 128;   // [191:128]
  localparam int DESC_DST_LSB     = 192;   // [255:192]
  localparam int DESC_NEXT_LSB    = 256;   // [319:256]
  localparam int DESC_CPL_LSB     = 320;   // [383:320]
  localparam int DESC_SEQ_LSB     = 384;   // [399:384]
  localparam int DESC_W12RSVD_LSB = 400;   // [415:400] must be 0
  localparam int DESC_RSVD_LSB    = 416;   // [511:416] must be 0

  // ---------------------------------------------------------------- flags (bit index inside the 16-bit FLAGS field)
  localparam int FLG_LAST    = 0;   // last descriptor of the chain (chain termination)
  localparam int FLG_ARRAY   = 1;   // next descriptor is at this+64 (array mode); otherwise NEXT_PTR (linked mode)
  localparam int FLG_HEAD    = 2;   // first descriptor of the chain; must be set on the head and ONLY on the head
  localparam int FLG_ORDERED = 3;   // barrier: do not start reading this element before all earlier writes are acknowledged
  localparam int FLG_CPL_EN  = 4;   // head only: write a completion record to CPL_ADDR when the transaction ends
  localparam int FLG_CRC_EN  = 5;   // head only: CRC-32 over the whole transferred byte stream (accidental-error check only)
  localparam int FLG_IRQ_EN  = 6;   // head only: raise the channel interrupt on completion
  localparam logic [15:0] FLG_RSVD_MASK = 16'hFF80;   // bits 7..15 reserved, must be 0
  localparam logic [15:0] FLG_HEADONLY_MASK = 16'h0070; // CPL_EN | CRC_EN | IRQ_EN

  // ---------------------------------------------------------------- completion record (32 bytes)
  //   W0  [3:0] STATUS  [7:4] FAULT  [15:8] ERR  [31:16] TXN_ID
  //   W1  [15:0] DOMAIN [31:16] DESCS (descriptors fully processed)
  //   W2  BYTES (destination bytes whose write was acknowledged)
  //   W3  CRC32 of the stream (valid iff FLAGS.CRC_VALID)
  //   W4,5 ERR_ADDR (64-bit IOVA of the failing access, 0 if none)
  //   W6  LATENCY (cycles, command accept -> last acknowledgement before the record write)
  //   W7  [15:0] FLAGS  [31:16] MAGIC (CPL_MAGIC)
  localparam int CPLR_STATUS_LSB  = 0;
  localparam int CPLR_FAULT_LSB   = 4;
  localparam int CPLR_ERR_LSB     = 8;
  localparam int CPLR_TXN_LSB     = 16;
  localparam int CPLR_DOM_LSB     = 32;
  localparam int CPLR_DESCS_LSB   = 48;
  localparam int CPLR_BYTES_LSB   = 64;
  localparam int CPLR_CRC_LSB     = 96;
  localparam int CPLR_EADDR_LSB   = 128;   // 64 bit
  localparam int CPLR_LAT_LSB     = 192;
  localparam int CPLR_FLAGS_LSB   = 224;   // [239:224]
  localparam int CPLR_MAGIC_LSB   = 240;   // [255:240]
  localparam logic [15:0] CPL_MAGIC = 16'hD0C1;
  localparam int CPLF_CRC_VALID   = 0;     // CRC field is meaningful (CRC_EN set and no error)
  localparam int CPLF_COMMITTED   = 1;     // every data byte of the transaction was acknowledged by its destination
  localparam int CPLF_VIOLATION   = 2;     // the transaction ended with an isolation violation

  // ---------------------------------------------------------------- transaction status
  localparam logic [3:0] ST_OK      = 4'd0;   // executed; every destination write acknowledged (and record acknowledged)
  localparam logic [3:0] ST_ERROR   = 4'd1;   // rejected or failed: see ERR / FAULT; bytes already acknowledged stay written
  localparam logic [3:0] ST_ABORTED = 4'd2;   // cancelled by the abort command: in-flight bursts were drained, not rolled back

  // ---------------------------------------------------------------- error codes (ERR)
  localparam logic [7:0] ERR_NONE            = 8'h00;
  // descriptor / command validation.  No byte of the failing element has been transferred.
  localparam logic [7:0] ERR_DESC_ALIGN      = 8'h01;  // head or NEXT_PTR not 64-byte aligned
  localparam logic [7:0] ERR_DESC_VERSION    = 8'h02;
  localparam logic [7:0] ERR_DESC_OPCODE     = 8'h03;
  localparam logic [7:0] ERR_DESC_FLAGS      = 8'h04;  // reserved flag, HEAD/LAST/ARRAY inconsistency, head-only flag on a non-head
  localparam logic [7:0] ERR_DESC_RSVD       = 8'h05;  // a reserved field is not zero
  localparam logic [7:0] ERR_BAD_ASID        = 8'h06;
  localparam logic [7:0] ERR_LEN_TOO_BIG     = 8'h07;  // element length > 2**MAX_ELEM_LOG2
  localparam logic [7:0] ERR_TOTAL_TOO_BIG   = 8'h08;  // chain total > 2**MAX_TOTAL_LOG2
  localparam logic [7:0] ERR_ADDR_RANGE      = 8'h09;  // address >= 2**AW
  localparam logic [7:0] ERR_ADDR_OVERFLOW  = 8'h0A;  // addr + len > 2**AW (would wrap)
  localparam logic [7:0] ERR_OVERLAP         = 8'h0B;  // SRC and DST of one element overlap in the same address space
  localparam logic [7:0] ERR_CHAIN_SEQ       = 8'h0C;  // SEQ != position: reordered / replayed descriptor, i.e. a cycle
  localparam logic [7:0] ERR_CHAIN_TXN       = 8'h0D;  // TXN_ID differs from the head
  localparam logic [7:0] ERR_CHAIN_TOO_LONG  = 8'h0E;  // more than MAX_CHAIN descriptors
  localparam logic [7:0] ERR_CHAIN_NULL      = 8'h0F;  // NEXT_PTR is zero but the chain is not terminated
  localparam logic [7:0] ERR_CPL_ALIGN       = 8'h10;  // CPL_ADDR not 32-byte aligned / zero with CPL_EN
  // isolation violations (0x2x): security events
  localparam logic [7:0] ERR_DOMAIN_MISMATCH = 8'h20;  // DOMAIN claim != hardware binding of the channel
  localparam logic [7:0] ERR_PERM_DESC       = 8'h21;  // descriptor fetch refused by the permission checker
  localparam logic [7:0] ERR_PERM_SRC        = 8'h22;  // source read refused
  localparam logic [7:0] ERR_PERM_DST        = 8'h23;  // destination write refused
  localparam logic [7:0] ERR_PERM_CPL        = 8'h24;  // completion-record write refused
  // execution faults (0x3x)
  localparam logic [7:0] ERR_BUS_DESC        = 8'h30;  // descriptor fetch answered with a bus error
  localparam logic [7:0] ERR_BUS_RD          = 8'h31;
  localparam logic [7:0] ERR_BUS_WR          = 8'h32;
  localparam logic [7:0] ERR_BUS_CPL         = 8'h33;
  localparam logic [7:0] ERR_TIMEOUT         = 8'h34;  // no progress for TIMEOUT cycles; channel fenced
  localparam logic [7:0] ERR_PROTOCOL        = 8'h35;  // response with an unknown ID / out of order on an in-order bus
  localparam logic [7:0] ERR_XLAT            = 8'h36;  // translation result unusable (misaligned PA, PA out of range)
  localparam logic [7:0] ERR_ABORT           = 8'h37;  // abort command
  localparam logic [7:0] ERR_INTERNAL        = 8'h38;

  function automatic logic err_is_violation(input logic [7:0] e);
    err_is_violation = (e[7:4] == 4'h2);
  endfunction

  // ---------------------------------------------------------------- fault codes (permission checker / IOMMU, 4 bit)
  localparam logic [3:0] FAULT_NONE   = 4'd0;
  localparam logic [3:0] FAULT_NO_MAP = 4'd1;   // no mapping for (domain, asid, address)
  localparam logic [3:0] FAULT_PERM   = 4'd2;   // mapped, but not for this access type
  localparam logic [3:0] FAULT_DOMAIN = 4'd3;   // the range is mapped for ANOTHER domain (simulation table only; a real IOMMU reports NO_MAP)
  localparam logic [3:0] FAULT_RANGE  = 4'd4;   // starts inside a mapping and leaves it
  localparam logic [3:0] FAULT_XLAT   = 4'd5;   // translation failed / IOMMU internal error
  localparam logic [3:0] FAULT_ASID   = 4'd6;   // address space not enabled
  localparam logic [3:0] FAULT_LEN    = 4'd7;   // request longer than the checker contract (internal consistency)

  // permission bits (mapping entries and checker requests)
  localparam logic [1:0] PERM_NONE = 2'b00;
  localparam logic [1:0] PERM_R    = 2'b01;
  localparam logic [1:0] PERM_W    = 2'b10;
  localparam logic [1:0] PERM_RW   = 2'b11;

  // ---------------------------------------------------------------- permission-checker clients (per channel)
  localparam int CLI_DESC = 0;   // descriptor fetch (read)
  localparam int CLI_RD   = 1;   // data read
  localparam int CLI_WR   = 2;   // data write
  localparam int CLI_CPL  = 3;   // completion-record write
  localparam int NUM_CLI  = 4;

  // ---------------------------------------------------------------- AXI4 response codes used on the memory port
  localparam logic [1:0] RESP_OKAY   = 2'b00;
  localparam logic [1:0] RESP_SLVERR = 2'b10;
  localparam logic [1:0] RESP_DECERR = 2'b11;

  // ---------------------------------------------------------------- trace event codes
  localparam logic [7:0] TR_CMD        = 8'h01;   // arg = head address[31:0]
  localparam logic [7:0] TR_DESC       = 8'h02;   // arg = {seq, flags}
  localparam logic [7:0] TR_ELEM       = 8'h03;   // arg = element length
  localparam logic [7:0] TR_RD_ISSUE   = 8'h04;   // arg = {beats, addr[15:0]}
  localparam logic [7:0] TR_WR_ISSUE   = 8'h05;   // arg = {beats, addr[15:0]}
  localparam logic [7:0] TR_RD_DONE    = 8'h06;   // arg = bytes committed by this burst
  localparam logic [7:0] TR_WR_DONE    = 8'h07;   // arg = bytes acknowledged by this burst
  localparam logic [7:0] TR_PERM_FAULT = 8'h08;   // arg = {client, fault}
  localparam logic [7:0] TR_ERROR      = 8'h09;   // arg = {fault, err}
  localparam logic [7:0] TR_CPL_WR     = 8'h0A;   // arg = status
  localparam logic [7:0] TR_DONE       = 8'h0B;   // arg = bytes
  localparam logic [7:0] TR_ABORT      = 8'h0C;
  localparam logic [7:0] TR_TIMEOUT    = 8'h0D;
  localparam int         TRACE_W       = 96;      // {ts[31:0], arg[31:0], txn[15:0], code[7:0], ch[7:0]}

  // ---------------------------------------------------------------- performance counters (per channel); id = index
  localparam int PC_ACTIVE      = 0;    // cycles the channel is busy (command accepted .. done)
  localparam int PC_STALL_AR    = 1;    // AR valid and not ready
  localparam int PC_STALL_AW    = 2;
  localparam int PC_STALL_W     = 3;
  localparam int PC_STALL_WDATA = 4;    // write side has a planned burst but the data is not yet in the buffer
  localparam int PC_STALL_FULL  = 5;    // read side blocked: data buffer has no room for the next burst
  localparam int PC_STALL_RSLOT = 6;    // read side blocked: RD_OUT outstanding bursts
  localparam int PC_STALL_WSLOT = 7;    // write side blocked: WR_OUT outstanding bursts
  localparam int PC_PERM_WAIT   = 8;    // cycles at least one client waits for the permission checker (overhead)
  localparam int PC_BYTES_RD    = 9;    // useful bytes committed from the source
  localparam int PC_BYTES_WR    = 10;   // useful bytes acknowledged at the destination
  localparam int PC_BEATS_RD    = 11;
  localparam int PC_BEATS_WR    = 12;
  localparam int PC_BURSTS_RD   = 13;
  localparam int PC_BURSTS_WR   = 14;
  localparam int PC_OCC_RD      = 15;   // sum over cycles of outstanding read bursts
  localparam int PC_OCC_WR      = 16;   // sum over cycles of outstanding write bursts
  localparam int PC_OCC_BUF     = 17;   // sum over cycles of buffered bytes / 8 (see docs)
  localparam int PC_XACT_OK     = 18;
  localparam int PC_XACT_ERR    = 19;
  localparam int PC_LAT_SUM     = 20;   // sum of start..last-ack latencies; each saturates at 65535
  localparam int PC_DESC_FETCH  = 21;   // descriptors fetched
  localparam int PC_DESC_LAT    = 22;   // sum of descriptor fetch latencies
  localparam int PC_PERM_REQ    = 23;
  localparam int PC_PERM_LAT    = 24;   // per cycle: requests waiting to be accepted by the checker (docs/06)
  localparam int PC_PERM_DENY   = 25;
  localparam int PC_VIOL        = 26;   // isolation violations
  localparam int PC_RD_LAT      = 27;   // sum over read bursts of (AR accepted -> first R beat)
  localparam int PC_TIMEOUTS    = 28;
  localparam int PC_ABORTS      = 29;
  localparam int PC_ELEMS       = 30;   // non-empty elements executed
  localparam int PC_WR_LAT      = 31;   // sum over write bursts of (AW accepted -> B)
  localparam int NUM_PC         = 32;
  // watermark registers (max), read through the same window at ids NUM_PC..NUM_PC+3
  localparam int PM_LAT_MAX     = 32;
  localparam int PM_RD_OCC_MAX  = 33;
  localparam int PM_WR_OCC_MAX  = 34;
  localparam int PM_BUF_MAX     = 35;   // bytes
  localparam int NUM_PM         = 4;

  // ---------------------------------------------------------------- CSR map (32-bit registers, byte offsets, 4 KiB window)
  localparam int CSR_ID        = 32'h000;  // RO  "SFDM"
  localparam int CSR_VERSION   = 32'h004;  // RO  {ABI_MAJOR, ABI_MINOR}
  localparam int CSR_CAPS0     = 32'h008;  // RO  {NUM_CH[7:0], DW/8[15:8].. see docs}
  localparam int CSR_CAPS1     = 32'h00C;  // RO  limits
  localparam int CSR_CTRL      = 32'h010;  // RW  [0] enable [1] soft_reset(W1S, self clearing) [2] trace_en [3] perf_clear(W1S)
  localparam int CSR_STATUS    = 32'h014;  // RO  [NUM_CH-1:0] busy  [16+:NUM_CH] fenced
  localparam int CSR_IRQ_EN    = 32'h018;  // RW  per channel done / error
  localparam int CSR_IRQ_STAT  = 32'h01C;  // RW1C
  localparam int CSR_TIMEOUT   = 32'h020;  // RW  no-progress timeout in cycles (0 = disabled)
  localparam int CSR_MAX_CHAIN = 32'h024;  // RW  runtime chain limit (<= MAX_CHAIN)
  localparam int CSR_ASID_EN   = 32'h028;  // RW  bit per ASID
  localparam int CSR_PROTO     = 32'h02C;  // RO  count of bus/IOMMU protocol events (stray or unknown responses), saturating
  localparam int CSR_PERF_SEL  = 32'h030;  // RW  {ch[15:8], id[7:0]}
  localparam int CSR_PERF_LO   = 32'h034;  // RO  reading LO latches HI
  localparam int CSR_PERF_HI   = 32'h038;  // RO
  localparam int CSR_TR_STAT   = 32'h040;  // RO  [15:0] entries  [31:16] dropped
  localparam int CSR_TR_W0     = 32'h044;  // RO  head entry words
  localparam int CSR_TR_W1     = 32'h048;
  localparam int CSR_TR_W2     = 32'h04C;
  localparam int CSR_TR_POP    = 32'h050;  // WO  write 1 pops the head entry
  localparam int CSR_CH_BASE   = 32'h100;  // per channel: base + ch * CSR_CH_STRIDE
  localparam int CSR_CH_STRIDE = 32'h040;
  localparam int CH_CTRL       = 32'h000;  // WO  [0] abort (W1S)   [1] clear fence / error latch
  localparam int CH_STATUS     = 32'h004;  // RO  [0] busy [1] fenced [2] last_done [7:4] last_status
  localparam int CH_ERR        = 32'h008;  // RO  {txn[31:16], err[15:8], fault[7:4]}
  localparam int CH_ERR_ADDR_LO= 32'h00C;
  localparam int CH_ERR_ADDR_HI= 32'h010;
  localparam int CH_BYTES      = 32'h014;  // RO  last transaction bytes acknowledged
  localparam int CH_CRC        = 32'h018;  // RO  last transaction CRC32
  localparam int CH_DOMAIN     = 32'h01C;  // RO  domain of the last / current transaction
  localparam int CH_DESCS      = 32'h020;  // RO  descriptors processed in the last transaction

  // ---------------------------------------------------------------- VERIFICATION-ONLY struct views (Verilator / simulators)
  typedef struct packed {
    logic [95:0] rsvd;       // W13..W15
    logic [15:0] w12_rsvd;
    logic [15:0] seq;        // W12
    logic [63:0] cpl_addr;   // W10,W11
    logic [63:0] next_ptr;   // W8,W9
    logic [63:0] dst_addr;   // W6,W7
    logic [63:0] src_addr;   // W4,W5
    logic [31:0] length;     // W3
    logic [19:0] w2_rsvd;
    logic [3:0]  cpl_asid;
    logic [3:0]  dst_asid;
    logic [3:0]  src_asid;   // W2
    logic [15:0] domain;
    logic [15:0] txn_id;     // W1
    logic [15:0] flags;
    logic [7:0]  opcode;
    logic [7:0]  version;    // W0
  } sfdma_desc_t;

  typedef struct packed {
    logic [15:0] magic;
    logic [15:0] flags;      // W7
    logic [31:0] latency;    // W6
    logic [63:0] err_addr;   // W4,W5
    logic [31:0] crc;        // W3
    logic [31:0] bytes;      // W2
    logic [15:0] descs;
    logic [15:0] domain;     // W1
    logic [15:0] txn_id;
    logic [7:0]  err;
    logic [3:0]  fault;
    logic [3:0]  status;     // W0
  } sfdma_cpl_t;

endpackage
