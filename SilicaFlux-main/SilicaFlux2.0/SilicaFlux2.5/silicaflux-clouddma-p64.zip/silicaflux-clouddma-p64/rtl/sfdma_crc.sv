// =============================================================================
// CloudDMA :: sfdma_crc -- CRC-32 (IEEE 802.3, reflected, init/xorout 0xFFFFFFFF) over the valid byte lanes of a beat
//
// Lanes are consumed in increasing lane order, only those whose strobe bit is set, so a beat that carries the
// stream bytes in lanes lane0..lane0+n-1 (exactly what the write path presents on the bus) is a plain
// "update with the strobed bytes".  `clr` (priority over `en`) reloads the init value.
// Bit-exact with sfd_crc32 (Project 61, vendored, third_party/) and with sfsec_crc mode 1; check value
// CRC-32("123456789") = 0xCBF43926 (tb/tb_crc.sv).
//
// A CRC protects against ACCIDENTAL corruption only.  It is linear and unkeyed: an attacker who can change the
// data can recompute it.  It is NOT a cryptographic integrity or authentication mechanism.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfdma_crc #(
  parameter int DW = 64,
  localparam int WB = DW / 8
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          clr,
  input  wire logic          en,
  input  wire logic [DW-1:0] data,
  input  wire logic [WB-1:0] strb,
  output logic [31:0]        crc_o
);
  function automatic logic [31:0] crc_byte(input logic [31:0] crc, input logic [7:0] b);
    logic [31:0] c;
    c = crc ^ {24'd0, b};
    for (int i = 0; i < 8; i++) c = c[0] ? ((c >> 1) ^ 32'hEDB8_8320) : (c >> 1);
    crc_byte = c;
  endfunction

  logic [31:0] st_q, nxt;
  always_comb begin
    nxt = st_q;
    for (int i = 0; i < WB; i++) if (strb[i]) nxt = crc_byte(nxt, data[8*i +: 8]);
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)   st_q <= 32'hFFFF_FFFF;
    else if (clr) st_q <= 32'hFFFF_FFFF;
    else if (en)  st_q <= nxt;
  end
  assign crc_o = ~st_q;
endmodule

`default_nettype wire
