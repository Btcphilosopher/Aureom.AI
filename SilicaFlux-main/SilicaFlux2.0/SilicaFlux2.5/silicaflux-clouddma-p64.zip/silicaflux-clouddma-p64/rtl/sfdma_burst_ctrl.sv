// =============================================================================
// CloudDMA :: sfdma_burst_ctrl -- burst controller: planners, data buffer, write streamer, slot tracking (one channel)
//
//   elements --> READ PLANNER --(permission)--> AR --> R beats --> [ring buffer] --> W beats <--AW<--(permission)-- WRITE PLANNER
//                                                                                        B responses --> bytes_acked
//
// BUS (AXI4 subset, docs/04_INTEGRATION.md): INCR bursts of full-width beats on BEAT-ALIGNED addresses, <= MAXB beats,
// never crossing a 2**BND_LOG2 (4 KiB) boundary; first/last beats carry byte strobes (writes) or unused lanes (reads).
// Every AR/AW address is the `pa` the permission checker returned for that very burst.
//
// DATA BUFFER.  A byte ring of BUF_BYTES with three pointers (all (log2+1)-bit wrap-around counters):
//      rdp  <=  commit  <=  alloc  <=  rdp + BUF_BYTES
//   alloc  : space reserved when a read burst is ISSUED (credit: a response can never find the buffer full);
//   commit : bytes whose read burst has fully arrived, in issue order (the oldest burst commits first);
//   rdp    : bytes already sent on the W channel.
//   R beats are written at their stream POSITION (slot base + beat offset), so bursts that complete out of order
//   (different IDs, REORDER_OK = 1) are absorbed without a reorder buffer; commit still follows issue order.
//
// WRITE ISSUE RULE.  An AW is issued only when ALL its bytes are already committed (commit - wres >= nbytes):
// W data can then stream back-to-back and an issued AW is never left without data -- an AXI write cannot be
// cancelled, so nothing is issued that might not be completable.  Hence BUF_BYTES >= 2*MAXB*WB (progress proof,
// docs/01_ARCHITECTURE.md): the elaboration refuses smaller buffers.
//
// IDs: every outstanding burst owns a slot; the slot index is the AXI ID.  REORDER_OK = 0 declares an in-order bus:
// a response out of order is a protocol error (ERR_PROTOCOL).  REORDER_OK = 1 accepts any interleaving across IDs.
// An unknown / idle ID is always a protocol error.
//
// FAILURE.  The first error sets fail_q (stop issuing new bursts), is reported once (err_evt), and the block DRAINS:
// outstanding read responses are consumed and dropped, issued writes complete (their data is in the buffer),
// and `quiet` rises when nothing is outstanding.  Presented AR/AW requests are never withdrawn.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfdma_burst_ctrl #(
  parameter int DW         = 64,
  parameter int AW         = 48,
  parameter int MAXB       = 16,
  parameter int BND_LOG2   = 12,
  parameter int RD_OUT     = 4,
  parameter int WR_OUT     = 4,
  parameter int BUF_BYTES  = 1024,
  parameter int ELQ        = 2,
  parameter bit REORDER_OK = 1'b1,
  parameter bit CRC_ON     = 1'b1,
  localparam int WB        = DW / 8,
  localparam int LW        = $clog2(WB),
  localparam int BW        = $clog2(MAXB) + 1,
  localparam int PW        = $clog2(BUF_BYTES),
  localparam int PTW       = PW + 1,
  localparam int MXO       = (RD_OUT > WR_OUT) ? RD_OUT : WR_OUT,
  localparam int SW        = (MXO > 1) ? $clog2(MXO) : 1,
  localparam int QW        = (ELQ > 1) ? $clog2(ELQ) : 1
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            txn_start,        // pulse (only when quiet): clears the data-flow state
  input  wire logic            stop,             // level: stop issuing, drain
  input  wire logic            crc_en,           // level, valid once the head descriptor is known
  // elements from the walker
  input  wire logic            el_valid,
  output logic                 el_ready,
  input  wire logic [3:0]      el_src_asid,
  input  wire logic [3:0]      el_dst_asid,
  input  wire logic [AW-1:0]   el_src,
  input  wire logic [AW-1:0]   el_dst,
  input  wire logic [31:0]     el_len,
  input  wire logic            el_ordered,
  // permission checker clients (domain / write supplied by the channel)
  output logic                 pr_req_valid,
  input  wire logic            pr_req_ready,
  output logic [3:0]           pr_req_asid,
  output logic [AW-1:0]        pr_req_addr,
  output logic [15:0]          pr_req_bytes,
  input  wire logic            pr_rsp_valid,
  input  wire logic            pr_rsp_ok,
  input  wire logic [3:0]      pr_rsp_fault,
  input  wire logic [AW-1:0]   pr_rsp_pa,
  output logic                 pw_req_valid,
  input  wire logic            pw_req_ready,
  output logic [3:0]           pw_req_asid,
  output logic [AW-1:0]        pw_req_addr,
  output logic [15:0]          pw_req_bytes,
  input  wire logic            pw_rsp_valid,
  input  wire logic            pw_rsp_ok,
  input  wire logic [3:0]      pw_rsp_fault,
  input  wire logic [AW-1:0]   pw_rsp_pa,
  // memory port (data class)
  output logic                 ar_valid,
  input  wire logic            ar_ready,
  output logic [SW-1:0]        ar_id,
  output logic [3:0]           ar_asid,
  output logic [AW-1:0]        ar_addr,
  output logic [7:0]           ar_len,
  input  wire logic            r_valid,
  input  wire logic [SW-1:0]   r_id,
  input  wire logic [DW-1:0]   r_data,
  input  wire logic            r_err,
  input  wire logic            r_last,
  output logic                 aw_valid,
  input  wire logic            aw_ready,
  output logic [SW-1:0]        aw_id,
  output logic [3:0]           aw_asid,
  output logic [AW-1:0]        aw_addr,
  output logic [7:0]           aw_len,
  output logic                 w_valid,
  input  wire logic            w_ready,
  output logic [DW-1:0]        w_data,
  output logic [WB-1:0]        w_strb,
  output logic                 w_last,
  input  wire logic            b_valid,
  input  wire logic [SW-1:0]   b_id,
  input  wire logic            b_err,
  // status
  output logic                 quiet,            // nothing outstanding, planners idle
  output logic [31:0]          bytes_acked,
  output logic [31:0]          crc_value,
  output logic                 progress,         // any forward-progress event this cycle (watchdog)
  output logic                 err_evt,          // pulse at the first error
  output logic [7:0]           err_code,
  output logic [3:0]           err_fault,
  output logic [AW-1:0]        err_addr,
  output logic                 fail,             // level: an error was recorded
  // performance / trace events
  output logic                 pf_stall_ar, pf_stall_aw, pf_stall_w, pf_stall_wdata, pf_stall_full,
  output logic                 pf_stall_rslot, pf_stall_wslot, pf_perm_wait,
  output logic                 pf_beat_rd, pf_beat_wr, pf_burst_rd, pf_burst_wr, pf_elem,
  output logic [15:0]          pf_bytes_rd, pf_bytes_wr,
  output logic [7:0]           pf_occ_rd, pf_occ_wr,
  output logic [15:0]          pf_buf_level,
  output logic                 pf_rd_lat_v, pf_wr_lat_v,
  output logic [15:0]          pf_rd_lat, pf_wr_lat,
  output logic                 tr_rd_v, tr_wr_v,
  output logic [31:0]          tr_rd_arg, tr_wr_arg
);
  // ------------------------------------------------------------------ parameter legality (elaboration fails loudly)
  generate
    if (!((DW == 32) || (DW == 64) || (DW == 128) || (DW == 256) || (DW == 512))) begin : g_bad_dw
      illegal_parameter_DW_must_be_32_64_128_256_or_512 u_bad ();
    end
    if (!((MAXB >= 1) && (MAXB <= 256) && (MAXB * WB <= 4096) && (MAXB * WB >= 64))) begin : g_bad_maxb
      illegal_parameter_MAXB_times_bytes_per_beat_must_be_64_to_4096_and_MAXB_at_most_256 u_bad ();
    end
    if (!((BUF_BYTES & (BUF_BYTES - 1)) == 0 && BUF_BYTES >= 2 * MAXB * WB)) begin : g_bad_buf
      illegal_parameter_BUF_BYTES_must_be_power_of_two_and_at_least_2_x_MAXB_x_bytes_per_beat u_bad ();
    end
    if (!((RD_OUT >= 1) && (WR_OUT >= 1) && (RD_OUT <= 64) && (WR_OUT <= 64) && (ELQ >= 1))) begin : g_bad_out
      illegal_parameter_RD_OUT_WR_OUT_between_1_and_64_and_ELQ_at_least_1 u_bad ();
    end
    if (!(BND_LOG2 <= 12 && (1 << BND_LOG2) >= MAXB * WB && AW >= 13 && AW <= 64)) begin : g_bad_bnd
      illegal_parameter_BND_LOG2_at_most_12_and_AW_between_13_and_64 u_bad ();
    end
  endgenerate

  localparam logic [PTW-1:0] CAPV = PTW'(BUF_BYTES);

  // ------------------------------------------------------------------ free-running time base (latency measurement)
  logic [15:0] now_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) now_q <= '0; else now_q <= now_q + 16'd1;
  end

  // ------------------------------------------------------------------ element queue (two independent consumers)
  logic [ELQ-1:0]  eq_v, eq_tr, eq_tw;                 // valid, taken by read planner, taken by write planner
  logic [AW-1:0]   eq_src [ELQ];
  logic [AW-1:0]   eq_dst [ELQ];
  logic [31:0]     eq_len [ELQ];
  logic [3:0]      eq_sa  [ELQ];
  logic [3:0]      eq_da  [ELQ];
  logic [ELQ-1:0]  eq_ord;
  logic [QW-1:0]   eq_wp, eq_rrp, eq_wrp, eq_fp;
  logic            fail_q;
  wire             stop_i = stop || fail_q;
  assign fail = fail_q;

  assign el_ready = !eq_v[eq_wp] && !stop_i;
  wire el_push = el_valid && el_ready;

  // consumer availability
  wire rd_avail = eq_v[eq_rrp] && !eq_tr[eq_rrp];
  wire wr_avail = eq_v[eq_wrp] && !eq_tw[eq_wrp] && eq_tr[eq_wrp];     // the writer never overtakes the reader
  logic rd_take, wr_take;

  function automatic logic [QW-1:0] qinc(input logic [QW-1:0] p);
    qinc = (p == QW'(ELQ - 1)) ? '0 : p + 1'b1;
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      eq_v <= '0; eq_tr <= '0; eq_tw <= '0; eq_ord <= '0;
      eq_wp <= '0; eq_rrp <= '0; eq_wrp <= '0; eq_fp <= '0;
      for (int i = 0; i < ELQ; i++) begin eq_src[i] <= '0; eq_dst[i] <= '0; eq_len[i] <= '0; eq_sa[i] <= '0; eq_da[i] <= '0; end
    end else if (txn_start) begin
      eq_v <= '0; eq_tr <= '0; eq_tw <= '0; eq_wp <= '0; eq_rrp <= '0; eq_wrp <= '0; eq_fp <= '0;
    end else begin
      if (el_push) begin
        eq_v[eq_wp] <= 1'b1; eq_tr[eq_wp] <= 1'b0; eq_tw[eq_wp] <= 1'b0;
        eq_src[eq_wp] <= el_src; eq_dst[eq_wp] <= el_dst; eq_len[eq_wp] <= el_len;
        eq_sa[eq_wp] <= el_src_asid; eq_da[eq_wp] <= el_dst_asid; eq_ord[eq_wp] <= el_ordered;
        eq_wp <= qinc(eq_wp);
      end
      if (rd_take) begin eq_tr[eq_rrp] <= 1'b1; eq_rrp <= qinc(eq_rrp); end
      if (wr_take) begin eq_tw[eq_wrp] <= 1'b1; eq_wrp <= qinc(eq_wrp); end
      if (eq_v[eq_fp] && eq_tr[eq_fp] && eq_tw[eq_fp]) begin eq_v[eq_fp] <= 1'b0; eq_fp <= qinc(eq_fp); end
    end
  end

  // ------------------------------------------------------------------ pointers and counters shared between sections
  logic [PTW-1:0] alloc_q, commit_q, rdp_q, wres_q;
  logic [7:0]     rd_cnt_q, wr_cnt_q;
  logic [31:0]    rd_loaded_q, wr_loaded_q;
  logic [7:0]     wq_cnt_q;
  logic           wp_idle;
  wire [PTW-1:0]  used_bytes  = alloc_q - rdp_q;
  wire [PTW-1:0]  free_bytes  = CAPV - used_bytes;
  wire [PTW-1:0]  cmt_unres   = commit_q - wres_q;

  // ------------------------------------------------------------------ READ PLANNER
  localparam logic [2:0] RP_IDLE = 3'd0, RP_PLAN = 3'd1, RP_CHK = 3'd2, RP_CHKW = 3'd3, RP_ISSUE = 3'd4;
  logic [2:0]     rp_st;
  logic [AW-1:0]  rp_src_q, rq_env_q, rq_pa_q;
  logic [31:0]    rp_rem_q;
  logic [3:0]     rp_asid_q;
  logic [BW-1:0]  rq_beats_q;
  logic [LW-1:0]  rq_lo_q;
  logic [15:0]    rq_nb_q, rq_envb_q;

  logic [AW-1:0]  pl_env;  logic [15:0] pl_envb;  logic [BW-1:0] pl_beats;  logic [LW-1:0] pl_lo;  logic [15:0] pl_nb;
  sfdma_burst_plan #(.DW(DW), .AW(AW), .MAXB(MAXB), .BND_LOG2(BND_LOG2)) u_rplan (
    .addr(rp_src_q), .rem(rp_rem_q), .env_addr(pl_env), .env_bytes(pl_envb), .beats(pl_beats), .lo(pl_lo), .nbytes(pl_nb));

  wire rd_slot_free = (rd_cnt_q < 8'(RD_OUT));
  wire rd_space_ok  = (free_bytes >= PTW'(pl_nb));
  // ordered barrier: all earlier elements fully written and acknowledged
  wire barrier_ok   = (wr_loaded_q == rd_loaded_q) && wp_idle && (wr_cnt_q == 8'd0) && (wq_cnt_q == 8'd0);
  assign rd_take    = (rp_st == RP_IDLE) && !stop_i && rd_avail && (!eq_ord[eq_rrp] || barrier_ok);

  assign pr_req_valid = (rp_st == RP_CHK);
  assign pr_req_asid  = rp_asid_q;
  assign pr_req_addr  = rq_env_q;
  assign pr_req_bytes = rq_envb_q;
  assign ar_valid     = (rp_st == RP_ISSUE);
  assign ar_asid      = rp_asid_q;
  assign ar_addr      = rq_pa_q;
  assign ar_len       = 8'(rq_beats_q) - 8'd1;
  logic [SW-1:0] rd_wp_q;                                  // next read slot = AXI ID
  assign ar_id        = rd_wp_q;
  wire ar_acc = ar_valid && ar_ready;

  // error events (priority chain below)
  logic ev_rperm, ev_wperm;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rp_st <= RP_IDLE; rp_src_q <= '0; rp_rem_q <= '0; rp_asid_q <= '0;
      rq_env_q <= '0; rq_pa_q <= '0; rq_beats_q <= '0; rq_lo_q <= '0; rq_nb_q <= '0; rq_envb_q <= '0;
    end else if (txn_start) begin
      rp_st <= RP_IDLE;
    end else begin
      case (rp_st)
        RP_IDLE: if (rd_take) begin
          rp_src_q <= eq_src[eq_rrp]; rp_rem_q <= eq_len[eq_rrp]; rp_asid_q <= eq_sa[eq_rrp];
          rp_st <= RP_PLAN;
        end
        RP_PLAN: begin
          if (stop_i) rp_st <= RP_IDLE;
          else if (rd_slot_free && rd_space_ok) begin
            rq_env_q <= pl_env; rq_envb_q <= pl_envb; rq_beats_q <= pl_beats; rq_lo_q <= pl_lo; rq_nb_q <= pl_nb;
            rp_st <= RP_CHK;
          end
        end
        RP_CHK:  if (pr_req_ready) rp_st <= RP_CHKW;                 // held until accepted
        RP_CHKW: if (pr_rsp_valid) begin
          if (!pr_rsp_ok || stop_i) rp_st <= RP_IDLE;                // refusal (error raised below) or stop: abandon
          else begin rq_pa_q <= pr_rsp_pa; rp_st <= RP_ISSUE; end
        end
        RP_ISSUE: if (ar_acc) begin                                   // presented AR is never withdrawn
          rp_src_q <= rp_src_q + AW'(rq_nb_q);
          rp_rem_q <= rp_rem_q - 32'(rq_nb_q);
          rp_st    <= (rp_rem_q == 32'(rq_nb_q)) ? RP_IDLE : RP_PLAN;
        end
        default: rp_st <= RP_IDLE;
      endcase
    end
  end
  assign ev_rperm = (rp_st == RP_CHKW) && pr_rsp_valid && !pr_rsp_ok && !stop_i;

  // ------------------------------------------------------------------ READ SLOTS, R PATH, COMMIT
  logic [RD_OUT-1:0] rs_v, rs_done, rs_err;
  logic [PW-1:0]     rs_base  [RD_OUT];
  logic [LW-1:0]     rs_lo    [RD_OUT];
  logic [15:0]       rs_nb    [RD_OUT];
  logic [BW-1:0]     rs_beats [RD_OUT];
  logic [BW-1:0]     rs_got   [RD_OUT];
  logic [AW-1:0]     rs_iova  [RD_OUT];
  logic [15:0]       rs_t     [RD_OUT];
  logic [SW-1:0]     rd_cp_q, rd_fill_q;

  function automatic logic [SW-1:0] sinc_r(input logic [SW-1:0] p);
    sinc_r = (32'(p) == RD_OUT - 1) ? '0 : p + 1'b1;
  endfunction

  // beat geometry for the arriving R beat
  logic            r_slot_ok;
  logic [BW-1:0]   rk;
  logic [15:0]     r_sfirst, r_nk;
  logic [LW-1:0]   r_c0;
  logic [PW-1:0]   r_pos;
  logic            r_last_exp, r_bad;
  always_comb begin
    r_slot_ok = (32'(r_id) < RD_OUT) && rs_v[r_id] && !rs_done[r_id] && (REORDER_OK || (r_id == rd_fill_q));
    rk        = rs_got[r_id];
    r_c0      = (rk == '0) ? rs_lo[r_id] : '0;
    r_sfirst  = (rk == '0) ? 16'd0 : ((16'(rk) << LW) - 16'(rs_lo[r_id]));
    r_nk      = 16'(WB) - 16'(r_c0);
    if (rs_nb[r_id] - r_sfirst < r_nk) r_nk = rs_nb[r_id] - r_sfirst;
    r_pos     = rs_base[r_id] + PW'(r_sfirst);
    r_last_exp = (32'(rk) + 1 == 32'(rs_beats[r_id]));
    r_bad     = r_valid && (!r_slot_ok || (r_last != r_last_exp));
  end

  wire r_wr_en = r_valid && r_slot_ok && !r_err;
  wire cm_ok   = rs_v[rd_cp_q] && rs_done[rd_cp_q];
  logic [LW:0] r_nk_w;
  assign r_nk_w = (LW+1)'(r_nk);

  logic ev_rerr, ev_rproto;
  assign ev_rerr   = r_valid && r_slot_ok && r_err;
  assign ev_rproto = r_bad;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rs_v <= '0; rs_done <= '0; rs_err <= '0; rd_cp_q <= '0; rd_fill_q <= '0; rd_wp_q <= '0;
      alloc_q <= '0; commit_q <= '0; rd_cnt_q <= '0; rd_loaded_q <= '0;
      for (int i = 0; i < RD_OUT; i++) begin
        rs_base[i] <= '0; rs_lo[i] <= '0; rs_nb[i] <= '0; rs_beats[i] <= '0; rs_got[i] <= '0; rs_iova[i] <= '0; rs_t[i] <= '0;
      end
    end else if (txn_start) begin
      rs_v <= '0; rs_done <= '0; rs_err <= '0; rd_cp_q <= '0; rd_fill_q <= '0; rd_wp_q <= '0;
      alloc_q <= '0; commit_q <= '0; rd_cnt_q <= '0; rd_loaded_q <= '0;
    end else begin
      if (rd_take) rd_loaded_q <= rd_loaded_q + 32'd1;
      // issue: allocate slot and buffer space
      if (ar_acc) begin
        rs_v[rd_wp_q] <= 1'b1; rs_done[rd_wp_q] <= 1'b0; rs_err[rd_wp_q] <= 1'b0;
        rs_base[rd_wp_q] <= alloc_q[PW-1:0]; rs_lo[rd_wp_q] <= rq_lo_q; rs_nb[rd_wp_q] <= rq_nb_q;
        rs_beats[rd_wp_q] <= rq_beats_q; rs_got[rd_wp_q] <= '0; rs_iova[rd_wp_q] <= rq_env_q; rs_t[rd_wp_q] <= now_q;
        alloc_q <= alloc_q + PTW'(rq_nb_q);
        rd_wp_q <= sinc_r(rd_wp_q);
      end
      // beat arrival
      if (r_valid && r_slot_ok) begin
        rs_got[r_id] <= rs_got[r_id] + 1'b1;
        if (r_err) rs_err[r_id] <= 1'b1;
        if (r_last_exp) begin rs_done[r_id] <= 1'b1; rd_fill_q <= sinc_r(rd_fill_q); end
      end
      // commit the oldest burst once it has fully arrived
      if (cm_ok) begin
        rs_v[rd_cp_q] <= 1'b0; rs_done[rd_cp_q] <= 1'b0;
        if (!rs_err[rd_cp_q]) commit_q <= commit_q + PTW'(rs_nb[rd_cp_q]);
        rd_cp_q <= sinc_r(rd_cp_q);
      end
      rd_cnt_q <= rd_cnt_q + 8'(ar_acc) - 8'(cm_ok);
    end
  end

  // ------------------------------------------------------------------ WRITE PLANNER
  localparam logic [2:0] WP_IDLE = 3'd0, WP_PLAN = 3'd1, WP_CHK = 3'd2, WP_CHKW = 3'd3, WP_ISSUE = 3'd4;
  logic [2:0]     wp_st;
  logic [AW-1:0]  wp_dst_q, wq_env_q, wq_pa_q;
  logic [31:0]    wp_rem_q;
  logic [3:0]     wp_asid_q;
  logic [BW-1:0]  wq_beats_q;
  logic [LW-1:0]  wq_lo_q;
  logic [15:0]    wq_nb_q, wq_envb_q;
  logic           aw_pres_q;
  logic [SW-1:0]  aw_id_q;

  logic [AW-1:0]  wl_env;  logic [15:0] wl_envb;  logic [BW-1:0] wl_beats;  logic [LW-1:0] wl_lo;  logic [15:0] wl_nb;
  sfdma_burst_plan #(.DW(DW), .AW(AW), .MAXB(MAXB), .BND_LOG2(BND_LOG2)) u_wplan (
    .addr(wp_dst_q), .rem(wp_rem_q), .env_addr(wl_env), .env_bytes(wl_envb), .beats(wl_beats), .lo(wl_lo), .nbytes(wl_nb));

  wire wr_slot_free = (wr_cnt_q < 8'(WR_OUT)) && (wq_cnt_q < 8'(WR_OUT));
  wire wr_data_ok   = (cmt_unres >= PTW'(wq_nb_q));
  assign wr_take    = (wp_st == WP_IDLE) && !stop_i && wr_avail;
  assign wp_idle    = (wp_st == WP_IDLE);

  assign pw_req_valid = (wp_st == WP_CHK);
  assign pw_req_asid  = wp_asid_q;
  assign pw_req_addr  = wq_env_q;
  assign pw_req_bytes = wq_envb_q;
  assign aw_valid     = (wp_st == WP_ISSUE) && (aw_pres_q || (!stop_i && wr_data_ok && wr_slot_free));
  assign aw_asid      = wp_asid_q;
  assign aw_addr      = wq_pa_q;
  assign aw_len       = 8'(wq_beats_q) - 8'd1;
  wire aw_acc = aw_valid && aw_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wp_st <= WP_IDLE; wp_dst_q <= '0; wp_rem_q <= '0; wp_asid_q <= '0; aw_pres_q <= 1'b0; aw_id_q <= '0;
      wq_env_q <= '0; wq_pa_q <= '0; wq_beats_q <= '0; wq_lo_q <= '0; wq_nb_q <= '0; wq_envb_q <= '0;
      wres_q <= '0; wr_loaded_q <= '0;
    end else if (txn_start) begin
      wp_st <= WP_IDLE; aw_pres_q <= 1'b0; wres_q <= '0; wr_loaded_q <= '0;
    end else begin
      aw_pres_q <= aw_valid && !aw_ready;
      if (aw_valid) aw_id_q <= aw_id;
      if (wr_take) wr_loaded_q <= wr_loaded_q + 32'd1;
      case (wp_st)
        WP_IDLE: if (wr_take) begin
          wp_dst_q <= eq_dst[eq_wrp]; wp_rem_q <= eq_len[eq_wrp]; wp_asid_q <= eq_da[eq_wrp];
          wp_st <= WP_PLAN;
        end
        WP_PLAN: begin
          if (stop_i) wp_st <= WP_IDLE;
          else if (wr_slot_free) begin
            wq_env_q <= wl_env; wq_envb_q <= wl_envb; wq_beats_q <= wl_beats; wq_lo_q <= wl_lo; wq_nb_q <= wl_nb;
            wp_st <= WP_CHK;
          end
        end
        WP_CHK:  if (pw_req_ready) wp_st <= WP_CHKW;
        WP_CHKW: if (pw_rsp_valid) begin
          if (!pw_rsp_ok || stop_i) wp_st <= WP_IDLE;
          else begin wq_pa_q <= pw_rsp_pa; wp_st <= WP_ISSUE; end
        end
        WP_ISSUE: begin
          if (aw_acc) begin
            wp_dst_q <= wp_dst_q + AW'(wq_nb_q);
            wp_rem_q <= wp_rem_q - 32'(wq_nb_q);
            wres_q   <= wres_q + PTW'(wq_nb_q);
            wp_st    <= (wp_rem_q == 32'(wq_nb_q)) ? WP_IDLE : WP_PLAN;
          end else if (stop_i && !aw_valid) wp_st <= WP_IDLE;       // never issued: abandon
        end
        default: wp_st <= WP_IDLE;
      endcase
    end
  end
  assign ev_wperm = (wp_st == WP_CHKW) && pw_rsp_valid && !pw_rsp_ok && !stop_i;

  // ------------------------------------------------------------------ WRITE SLOTS, W QUEUE, B PATH
  logic [WR_OUT-1:0] ws_busy;
  logic [15:0]       ws_nb   [WR_OUT];
  logic [AW-1:0]     ws_iova [WR_OUT];
  logic [15:0]       ws_t    [WR_OUT];
  logic [SW-1:0]     wo_q    [WR_OUT];            // issue order of slots (in-order bus check)
  logic [SW-1:0]     wo_wp_q, wo_rp_q;
  logic [BW-1:0]     wqe_beats [WR_OUT];          // W queue
  logic [LW-1:0]     wqe_lo    [WR_OUT];
  logic [15:0]       wqe_nb    [WR_OUT];
  logic [SW-1:0]     wq_wp_q, wq_rp_q;
  logic [BW-1:0]     wk_q;
  logic [31:0]       acked_q;

  function automatic logic [SW-1:0] sinc_w(input logic [SW-1:0] p);
    sinc_w = (32'(p) == WR_OUT - 1) ? '0 : p + 1'b1;
  endfunction

  // lowest free write slot
  logic [SW-1:0] free_slot;
  always_comb begin
    free_slot = '0;
    for (int i = WR_OUT - 1; i >= 0; i--) if (!ws_busy[i]) free_slot = SW'(i);
  end
  // the slot (= AXI ID) is chosen when the AW is first presented and then HELD: AXI4 forbids changing a pending request
  assign aw_id = aw_pres_q ? aw_id_q : free_slot;

  // W streamer geometry
  wire              wq_nonempty = (wq_cnt_q != 8'd0);
  wire [BW-1:0]     h_beats = wqe_beats[wq_rp_q];
  wire [LW-1:0]     h_lo    = wqe_lo[wq_rp_q];
  wire [15:0]       h_nb    = wqe_nb[wq_rp_q];
  logic [LW-1:0]    w_c0;
  logic [15:0]      w_sfirst, w_nk;
  always_comb begin
    w_c0     = (wk_q == '0) ? h_lo : '0;
    w_sfirst = (wk_q == '0) ? 16'd0 : ((16'(wk_q) << LW) - 16'(h_lo));
    w_nk     = 16'(WB) - 16'(w_c0);
    if (h_nb - w_sfirst < w_nk) w_nk = h_nb - w_sfirst;
  end
  logic [LW:0] w_nk_w;
  assign w_nk_w = (LW+1)'(w_nk);
  assign w_valid = wq_nonempty;
  assign w_last  = (32'(wk_q) + 1 == 32'(h_beats));
  wire w_acc = w_valid && w_ready;

  // B response decode
  logic b_slot_ok, b_bad;
  always_comb begin
    b_slot_ok = (32'(b_id) < WR_OUT) && ws_busy[b_id] && (REORDER_OK || (b_id == wo_q[wo_rp_q]));
    b_bad     = b_valid && !b_slot_ok;
  end
  wire b_ok_evt  = b_valid && b_slot_ok && !b_err;
  logic ev_werr, ev_wproto;
  assign ev_werr   = b_valid && b_slot_ok && b_err;
  assign ev_wproto = b_bad;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ws_busy <= '0; wo_wp_q <= '0; wo_rp_q <= '0; wq_wp_q <= '0; wq_rp_q <= '0; wk_q <= '0;
      wr_cnt_q <= '0; wq_cnt_q <= '0; rdp_q <= '0; acked_q <= '0;
      for (int i = 0; i < WR_OUT; i++) begin
        ws_nb[i] <= '0; ws_iova[i] <= '0; ws_t[i] <= '0; wo_q[i] <= '0; wqe_beats[i] <= '0; wqe_lo[i] <= '0; wqe_nb[i] <= '0;
      end
    end else if (txn_start) begin
      ws_busy <= '0; wo_wp_q <= '0; wo_rp_q <= '0; wq_wp_q <= '0; wq_rp_q <= '0; wk_q <= '0;
      wr_cnt_q <= '0; wq_cnt_q <= '0; rdp_q <= '0; acked_q <= '0;
    end else begin
      // AW accepted: slot + W queue entry
      if (aw_acc) begin
        ws_busy[aw_id] <= 1'b1; ws_nb[aw_id] <= wq_nb_q; ws_iova[aw_id] <= wq_env_q; ws_t[aw_id] <= now_q;
        wo_q[wo_wp_q] <= aw_id; wo_wp_q <= sinc_w(wo_wp_q);
        wqe_beats[wq_wp_q] <= wq_beats_q; wqe_lo[wq_wp_q] <= wq_lo_q; wqe_nb[wq_wp_q] <= wq_nb_q; wq_wp_q <= sinc_w(wq_wp_q);
      end
      // W beat accepted
      if (w_acc) begin
        rdp_q <= rdp_q + PTW'(w_nk);
        if (w_last) begin wk_q <= '0; wq_rp_q <= sinc_w(wq_rp_q); end
        else        wk_q <= wk_q + 1'b1;
      end
      // B response
      if (b_valid && b_slot_ok) begin
        ws_busy[b_id] <= 1'b0;
        wo_rp_q <= sinc_w(wo_rp_q);
        if (!b_err) acked_q <= acked_q + 32'(ws_nb[b_id]);
      end
      wr_cnt_q <= wr_cnt_q + 8'(aw_acc) - 8'(b_valid && b_slot_ok);
      wq_cnt_q <= wq_cnt_q + 8'(aw_acc) - 8'(w_acc && w_last);
    end
  end
  assign bytes_acked = acked_q;

  // buffer read port (W data) and write port (R data)
  logic [DW-1:0] bb_rd_data;
  logic [WB-1:0] bb_rd_strb;
  sfdma_bytebuf #(.DW(DW), .CAP(BUF_BYTES)) u_buf (
    .clk,
    .wr_en(r_wr_en), .wr_pos(r_pos), .wr_lane0(r_c0), .wr_n(r_nk_w), .wr_data(r_data),
    .rd_pos(rdp_q[PW-1:0]), .rd_lane0(w_c0), .rd_n(w_nk_w), .rd_data(bb_rd_data), .rd_strb(bb_rd_strb));
  assign w_data = bb_rd_data;
  assign w_strb = bb_rd_strb;

  // CRC over exactly the bytes presented on the W channel (in stream order)
  generate
    if (CRC_ON) begin : g_crc
      sfdma_crc #(.DW(DW)) u_crc (.clk, .rst_n, .clr(txn_start), .en(w_acc && crc_en), .data(bb_rd_data), .strb(bb_rd_strb), .crc_o(crc_value));
    end else begin : g_nocrc
      logic unused_crc;
      assign unused_crc = crc_en;
      assign crc_value  = 32'd0;
    end
  endgenerate

  // ------------------------------------------------------------------ first-error capture
  logic        e_v;
  logic [7:0]  e_code;
  logic [3:0]  e_fault;
  logic [AW-1:0] e_addr;
  logic [7:0]  ecode_q;
  logic [3:0]  efault_q;
  logic [AW-1:0] eaddr_q;
  always_comb begin
    e_v = 1'b0; e_code = silicaflux_dma_pkg::ERR_NONE; e_fault = silicaflux_dma_pkg::FAULT_NONE; e_addr = '0;
    if (ev_rperm)        begin e_v = 1'b1; e_code = silicaflux_dma_pkg::ERR_PERM_SRC; e_fault = pr_rsp_fault; e_addr = rq_env_q; end
    else if (ev_wperm)   begin e_v = 1'b1; e_code = silicaflux_dma_pkg::ERR_PERM_DST; e_fault = pw_rsp_fault; e_addr = wq_env_q; end
    else if (ev_rproto)  begin e_v = 1'b1; e_code = silicaflux_dma_pkg::ERR_PROTOCOL; end
    else if (ev_wproto)  begin e_v = 1'b1; e_code = silicaflux_dma_pkg::ERR_PROTOCOL; end
    else if (ev_rerr)    begin e_v = 1'b1; e_code = silicaflux_dma_pkg::ERR_BUS_RD;   e_addr = rs_iova[r_id]; end
    else if (ev_werr)    begin e_v = 1'b1; e_code = silicaflux_dma_pkg::ERR_BUS_WR;   e_addr = ws_iova[b_id]; end
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      fail_q <= 1'b0; err_evt <= 1'b0; ecode_q <= silicaflux_dma_pkg::ERR_NONE; efault_q <= '0; eaddr_q <= '0;
    end else if (txn_start) begin
      fail_q <= 1'b0; err_evt <= 1'b0; ecode_q <= silicaflux_dma_pkg::ERR_NONE; efault_q <= '0; eaddr_q <= '0;
    end else begin
      err_evt <= 1'b0;
      if (e_v && !fail_q) begin
        fail_q <= 1'b1; err_evt <= 1'b1; ecode_q <= e_code; efault_q <= e_fault; eaddr_q <= e_addr;
      end
    end
  end
  assign err_code  = ecode_q;
  assign err_fault = efault_q;
  assign err_addr  = eaddr_q;

  // ------------------------------------------------------------------ status
  assign quiet = (rp_st == RP_IDLE) && (wp_st == WP_IDLE) && (rd_cnt_q == 8'd0) && (wr_cnt_q == 8'd0) &&
                 (wq_cnt_q == 8'd0) && (stop_i || (eq_v == '0));
  assign progress = r_valid || b_valid || w_acc || ar_acc || aw_acc || el_push || rd_take || wr_take ||
                    (pr_rsp_valid) || (pw_rsp_valid) || cm_ok;

  // ------------------------------------------------------------------ performance / trace events
  assign pf_stall_ar    = ar_valid && !ar_ready;
  assign pf_stall_aw    = aw_valid && !aw_ready;
  assign pf_stall_w     = w_valid && !w_ready;
  assign pf_stall_wdata = (wp_st == WP_ISSUE) && !aw_pres_q && !wr_data_ok;
  assign pf_stall_full  = (rp_st == RP_PLAN) && rd_slot_free && !rd_space_ok;
  assign pf_stall_rslot = (rp_st == RP_PLAN) && !rd_slot_free;
  assign pf_stall_wslot = (wp_st == WP_PLAN) && !wr_slot_free;
  assign pf_perm_wait   = (rp_st == RP_CHK) || (rp_st == RP_CHKW) || (wp_st == WP_CHK) || (wp_st == WP_CHKW);
  assign pf_beat_rd     = r_valid && r_slot_ok;
  assign pf_beat_wr     = w_acc;
  assign pf_burst_rd    = cm_ok && !rs_err[rd_cp_q];
  assign pf_burst_wr    = b_ok_evt;
  assign pf_elem        = rd_take;
  assign pf_bytes_rd    = (cm_ok && !rs_err[rd_cp_q]) ? rs_nb[rd_cp_q] : 16'd0;
  assign pf_bytes_wr    = b_ok_evt ? ws_nb[b_id] : 16'd0;
  assign pf_occ_rd      = rd_cnt_q;
  assign pf_occ_wr      = wr_cnt_q;
  assign pf_buf_level   = 16'(used_bytes);
  assign pf_rd_lat_v    = r_valid && r_slot_ok && (rs_got[r_id] == '0);
  assign pf_rd_lat      = now_q - rs_t[r_id];
  assign pf_wr_lat_v    = b_ok_evt;
  assign pf_wr_lat      = now_q - ws_t[b_id];
  assign tr_rd_v        = ar_acc;
  assign tr_rd_arg      = {8'(rq_beats_q), 8'd0, rq_env_q[15:0]};
  assign tr_wr_v        = aw_acc;
  assign tr_wr_arg      = {8'(wq_beats_q), 8'd0, wq_env_q[15:0]};

`ifndef SYNTHESIS
  // simulation-only invariants (not synthesised)
  always @(posedge clk or negedge rst_n) if (rst_n && !txn_start) begin
    if (32'(used_bytes) > BUF_BYTES) $error("sfdma_burst_ctrl: buffer over-allocated");
    if ((commit_q - rdp_q) > used_bytes) $error("sfdma_burst_ctrl: commit beyond allocation");
    if (w_acc && ((commit_q - rdp_q) < PTW'(w_nk))) $error("sfdma_burst_ctrl: W beat taken from uncommitted bytes");
  end
`endif
endmodule

`default_nettype wire
