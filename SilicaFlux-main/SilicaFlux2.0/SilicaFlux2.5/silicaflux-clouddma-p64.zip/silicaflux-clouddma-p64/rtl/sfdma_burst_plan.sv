// =============================================================================
// CloudDMA :: sfdma_burst_plan -- burst geometry for one bus transaction (pure combinational)
//
// Given a byte cursor `addr` and the bytes still to move `rem` (> 0) it returns the NEXT burst:
//   * the burst is an AXI4 INCR burst of full-width beats that starts on a BEAT-ALIGNED address (the
//     "envelope"): the first beat may carry `lo` unused low byte lanes, the last beat unused high lanes;
//   * it carries at most MAXB beats and never crosses a 2**BND_LOG2 boundary (AXI4: 4 KiB);
//   * nbytes = useful bytes = min(rem, bytes to the boundary, MAXB*WB - lo).
// Because the boundary is a multiple of the beat size, the envelope end is always <= the boundary.
// Used by the descriptor walker (fetch), the read planner, the write planner and the completion writer,
// so the arithmetic that keeps bursts legal exists exactly once (and is exhaustively tested:
// tb/tb_burst_plan.sv).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfdma_burst_plan #(
  parameter int DW       = 64,
  parameter int AW       = 48,
  parameter int MAXB     = 16,
  parameter int BND_LOG2 = 12,
  localparam int WB      = DW / 8,
  localparam int LW      = $clog2(WB),
  localparam int BW      = $clog2(MAXB) + 1
) (
  input  wire logic [AW-1:0]  addr,
  input  wire logic [31:0]    rem,
  output logic [AW-1:0]       env_addr,    // beat-aligned start of the envelope
  output logic [15:0]         env_bytes,   // beats * WB
  output logic [BW-1:0]       beats,       // 1 .. MAXB
  output logic [LW-1:0]       lo,          // addr mod WB
  output logic [15:0]         nbytes       // useful bytes of this burst, 1 .. MAXB*WB
);
  localparam logic [31:0] BND32  = 32'd1 << BND_LOG2;
  localparam logic [31:0] WB32   = WB;
  localparam logic [31:0] MAXB32 = MAXB;

  logic [31:0] lo32, to_bnd, cap, n32;
  logic [15:0] e16;
  always_comb begin
    lo32   = {{(32-LW){1'b0}}, addr[LW-1:0]};
    to_bnd = BND32 - {{(32-BND_LOG2){1'b0}}, addr[BND_LOG2-1:0]};      // 1 .. 2**BND_LOG2
    cap    = MAXB32 * WB32 - lo32;                                     // >= 1
    n32    = rem;
    if (to_bnd < n32) n32 = to_bnd;
    if (cap    < n32) n32 = cap;
    e16    = 16'((lo32 + n32 + WB32 - 32'd1) >> LW);                   // beats
    lo        = addr[LW-1:0];
    nbytes    = n32[15:0];
    beats     = e16[BW-1:0];
    env_bytes = e16 << LW;
    env_addr  = {addr[AW-1:LW], {LW{1'b0}}};
  end
endmodule

`default_nettype wire
