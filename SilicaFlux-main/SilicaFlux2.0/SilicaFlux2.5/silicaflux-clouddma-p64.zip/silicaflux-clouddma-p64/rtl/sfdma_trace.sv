// =============================================================================
// CloudDMA :: sfdma_trace -- transaction trace: event sources -> arbitration -> FIFO -> CSR read-out
//
// Each source (4 per channel: channel events, descriptor events, read issue, write issue) has a one-event holding
// register; a new event that finds its register still occupied is DROPPED and counted (the trace is a debug aid,
// never a correctness path).  Round-robin picks one held event per cycle into a FIFO of DEPTH entries; a full FIFO
// leaves events in their holding registers.  Entry (96 bit):  {timestamp[31:0], arg[31:0], txn[15:0], code[7:0], ch[7:0]}.
// Head words are readable through the CSR window (pop = write).  `en` gates new events; clr empties everything.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfdma_trace #(
  parameter int NCH   = 1,
  parameter int DEPTH = 32
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              en,
  input  wire logic              clr,
  input  wire logic [4*NCH-1:0]  tr_v,
  input  wire logic [4*NCH*8-1:0]  tr_code,
  input  wire logic [4*NCH*32-1:0] tr_arg,
  input  wire logic [NCH*16-1:0] tr_txn,
  input  wire logic              pop,
  output logic [95:0]            head,
  output logic [15:0]            count,
  output logic [15:0]            dropped
);
  localparam int NS = 4 * NCH;
  logic [NS-1:0]   h_v;
  logic [7:0]      h_code [NS];
  logic [31:0]     h_arg  [NS];
  logic [15:0]     h_txn  [NS];
  logic [31:0]     ts_q;
  logic [NS-1:0]   grant;
  logic            any;
  logic            f_in_ready, f_out_valid;
  logic [95:0]     f_out;
  logic [$clog2(DEPTH+1)-1:0] f_level;

  sfd_rr_arb #(.N(NS)) u_arb (.clk, .rst_n, .req(h_v), .advance(f_in_ready), .grant, .any);

  logic [95:0] pick;
  always_comb begin
    pick = '0;
    for (int i = 0; i < NS; i++) if (grant[i]) pick = {ts_q, h_arg[i], h_txn[i], h_code[i], 8'(i / 4)};
  end
  wire push = any && f_in_ready;

  sfd_fifo #(.WIDTH(96), .DEPTH(DEPTH)) u_f (
    .clk, .rst_n, .flush(clr), .in_valid(any), .in_ready(f_in_ready), .in_data(pick),
    .out_valid(f_out_valid), .out_ready(pop), .out_data(f_out), .level(f_level));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      h_v <= '0; ts_q <= '0; dropped <= '0;
      for (int i = 0; i < NS; i++) begin h_code[i] <= '0; h_arg[i] <= '0; h_txn[i] <= '0; end
    end else begin
      ts_q <= ts_q + 32'd1;
      if (clr) begin h_v <= '0; dropped <= '0; end
      else begin
        for (int i = 0; i < NS; i++) begin
          if (push && grant[i]) h_v[i] <= 1'b0;
          if (en && tr_v[i]) begin
            if (h_v[i] && !(push && grant[i])) begin
              if (dropped != 16'hFFFF) dropped <= dropped + 16'd1;
            end else begin
              h_v[i] <= 1'b1; h_code[i] <= tr_code[8*i +: 8]; h_arg[i] <= tr_arg[32*i +: 32]; h_txn[i] <= tr_txn[16*(i/4) +: 16];
            end
          end
        end
      end
    end
  end
  assign head  = f_out_valid ? f_out : 96'd0;
  assign count = 16'(f_level);
endmodule

`default_nettype wire
