// =============================================================================
// CloudDMA :: sfdma_bytebuf -- byte-granular ring storage with arbitrary-alignment write and read ports
//
// A ring of CAP bytes (CAP a power of two).  The controller owns all pointers; this block only moves bytes:
//   write port  bytes data[lane0 .. lane0+n-1] of a bus beat  ->  ring bytes pos, pos+1, .. pos+n-1  (mod CAP)
//   read  port  ring bytes pos .. pos+n-1  ->  lanes lane0 .. lane0+n-1 of a bus beat, strobes set for those lanes
// Because both ports address by stream POSITION (not by a running pointer) the writer can place the beats of
// several outstanding read bursts in ANY arrival order -- that is how response reordering is absorbed.
// The read port is combinational (flop array), the write port takes effect at the clock edge.
// Storage is NOT reset (it is never observed unless written first; the controller tracks validity).
// Classification: SYNTHESIZABLE (behavioural storage; macro mapping is a back-end decision)
// =============================================================================
`default_nettype none

module sfdma_bytebuf #(
  parameter int DW  = 64,
  parameter int CAP = 256,
  localparam int WB = DW / 8,
  localparam int LW = $clog2(WB),
  localparam int PW = $clog2(CAP)
) (
  input  wire logic            clk,
  // write
  input  wire logic            wr_en,
  input  wire logic [PW-1:0]   wr_pos,
  input  wire logic [LW-1:0]   wr_lane0,
  input  wire logic [LW:0]     wr_n,
  input  wire logic [DW-1:0]   wr_data,
  // read
  input  wire logic [PW-1:0]   rd_pos,
  input  wire logic [LW-1:0]   rd_lane0,
  input  wire logic [LW:0]     rd_n,
  output logic [DW-1:0]        rd_data,
  output logic [WB-1:0]        rd_strb
);
  logic [7:0] mem [CAP];

  always_ff @(posedge clk) begin
    if (wr_en) begin
      for (int i = 0; i < WB; i++) begin
        if (i < 32'(wr_n)) mem[PW'(wr_pos + PW'(i))] <= wr_data[8*(32'(wr_lane0) + i) +: 8];
      end
    end
  end

  always_comb begin
    rd_data = '0;
    rd_strb = '0;
    for (int d = 0; d < WB; d++) begin
      if (d >= 32'(rd_lane0) && d < 32'(rd_lane0) + 32'(rd_n)) begin
        rd_data[8*d +: 8] = mem[PW'(rd_pos + PW'(d) - PW'(rd_lane0))];
        rd_strb[d]        = 1'b1;
      end
    end
  end
endmodule

`default_nettype wire
