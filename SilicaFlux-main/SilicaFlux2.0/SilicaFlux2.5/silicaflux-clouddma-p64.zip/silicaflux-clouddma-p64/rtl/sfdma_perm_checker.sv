// =============================================================================
// CloudDMA :: sfdma_perm_checker -- the permission gate in front of EVERY memory transaction
//
// Clients (per channel: descriptor fetch, data read, data write, completion-record write) present
//     { domain, asid, write, addr (beat-aligned envelope start), bytes }
// and get back { ok, fault, pa }.  The DMA never forms a bus address from anything else: the address on
// AR/AW is the `pa` returned here for that very request.  Checks, in this order:
//   1. LOCAL (no IOMMU needed):  ASID enabled | 1 <= bytes <= 4096 | the range does not cross a 4 KiB boundary |
//      addr + bytes <= 2**AW (no wrap).  A local refusal never reaches the IOMMU.
//   2. IOMMU / permission table (domain ownership, read/write permission, address range, translation).
//   3. TRANSLATION RESULT (a response is not trusted blindly): pa is beat aligned, keeps the in-page offset
//      (translation granule >= 4 KiB), and pa + bytes <= 2**AW.  Otherwise the request fails with FAULT_XLAT.
// One request per client may be pending (the client waits for the response).  Round-robin arbitration with a
// grant lock: a request presented to the IOMMU and not yet accepted keeps its grant, so the IOMMU port obeys
// the valid/ready stability rule.  At most PERM_OUT requests are in flight at the IOMMU; its responses must come
// in order and echo the id; a response for a client that is not waiting is dropped and counted (proto_err).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfdma_perm_checker #(
  parameter int NCLI     = 4,
  parameter int AW       = 48,
  parameter int DOM_W    = 4,
  parameter int DW       = 64,
  parameter int PERM_OUT = 1,
  localparam int IDW     = (NCLI > 1) ? $clog2(NCLI) : 1,
  localparam int LW      = $clog2(DW / 8)
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic [15:0]         asid_en,
  // clients
  input  wire logic [NCLI-1:0]       c_req_valid,
  output logic [NCLI-1:0]            c_req_ready,
  input  wire logic [NCLI*DOM_W-1:0] c_req_domain,
  input  wire logic [NCLI*4-1:0]     c_req_asid,
  input  wire logic [NCLI-1:0]       c_req_write,
  input  wire logic [NCLI*AW-1:0]    c_req_addr,
  input  wire logic [NCLI*16-1:0]    c_req_bytes,
  output logic [NCLI-1:0]            c_rsp_valid,
  output logic [NCLI-1:0]            c_rsp_ok,
  output logic [NCLI*4-1:0]          c_rsp_fault,
  output logic [NCLI*AW-1:0]         c_rsp_pa,
  // IOMMU port
  output logic                     iommu_req_valid,
  input  wire logic                iommu_req_ready,
  output logic [DOM_W-1:0]         iommu_req_domain,
  output logic [3:0]               iommu_req_asid,
  output logic                     iommu_req_write,
  output logic [AW-1:0]            iommu_req_addr,
  output logic [15:0]              iommu_req_bytes,
  output logic [IDW-1:0]           iommu_req_id,
  input  wire logic                iommu_rsp_valid,
  output logic                     iommu_rsp_ready,
  input  wire logic [IDW-1:0]      iommu_rsp_id,
  input  wire logic                iommu_rsp_ok,
  input  wire logic [3:0]          iommu_rsp_fault,
  input  wire logic [AW-1:0]       iommu_rsp_pa,
  // diagnostics
  output logic                     proto_err_evt
);
  localparam logic [AW:0] LIM = {1'b1, {AW{1'b0}}};            // 2**AW

  // ---------------------------------------------------------------- per-client state
  logic [NCLI-1:0] pend_q;                                    // a response is awaited (iommu or local)
  logic [NCLI-1:0] iom_q;                                     // ... and the request was sent to the IOMMU (a stray response cannot hijack a local refusal)
  logic [NCLI-1:0] lf_v_q;                                    // local-fault response ready
  logic [NCLI*4-1:0] lf_fault_q;
  logic [11:0]     rq_off_q   [NCLI];                         // in-page offset of the request (for the translation check)
  logic [12:0]     rq_bytes_q [NCLI];

  // ---------------------------------------------------------------- arbitration with grant lock
  logic [IDW-1:0] ptr_q;
  logic           lock_v_q;
  logic [IDW-1:0] lock_i_q;
  logic [31:0]    out_q;                                      // IOMMU requests in flight

  logic [NCLI-1:0] req_vec;
  assign req_vec = c_req_valid & ~pend_q;

  logic           found;
  logic [IDW-1:0] win;
  integer         jj;
  always_comb begin
    found = 1'b0;
    win   = '0;
    jj    = 0;
    if (lock_v_q) begin
      found = 1'b1;
      win   = lock_i_q;
    end else begin
      for (int i = 0; i < NCLI; i++) begin
        jj = i + 32'(ptr_q);
        if (jj >= NCLI) jj = jj - NCLI;
        if (!found && req_vec[jj]) begin
          found = 1'b1;
          win   = IDW'(jj);
        end
      end
    end
  end

  // selected request
  logic [DOM_W-1:0] s_dom;
  logic [3:0]       s_asid;
  logic             s_wr;
  logic [AW-1:0]    s_addr;
  logic [15:0]      s_bytes;
  assign s_dom   = c_req_domain[32'(win)*DOM_W +: DOM_W];
  assign s_asid  = c_req_asid[32'(win)*4 +: 4];
  assign s_wr    = c_req_write[win];
  assign s_addr  = c_req_addr[32'(win)*AW +: AW];
  assign s_bytes = c_req_bytes[32'(win)*16 +: 16];

  // local checks
  logic [3:0]  loc_fault;
  logic        loc_bad;
  logic [AW:0] s_end;
  logic [12:0] pg_end;
  always_comb begin
    s_end     = {1'b0, s_addr} + {{(AW+1-16){1'b0}}, s_bytes};
    pg_end    = {1'b0, s_addr[11:0]} + s_bytes[12:0];
    loc_bad   = 1'b1;
    loc_fault = silicaflux_dma_pkg::FAULT_NONE;
    if (!asid_en[s_asid])                              loc_fault = silicaflux_dma_pkg::FAULT_ASID;
    else if (s_bytes == 16'd0 || s_bytes > 16'd4096)   loc_fault = silicaflux_dma_pkg::FAULT_LEN;
    else if (pg_end > 13'd4096)                        loc_fault = silicaflux_dma_pkg::FAULT_LEN;
    else if (s_end > LIM)                              loc_fault = silicaflux_dma_pkg::FAULT_RANGE;
    else                                               loc_bad   = 1'b0;
  end

  wire room    = (out_q < 32'(PERM_OUT));
  wire go_loc  = found && loc_bad;
  wire go_iom  = found && !loc_bad && room;
  assign iommu_req_valid  = go_iom;                           // never depends on iommu_req_ready (valid/ready rule)
  assign iommu_req_domain = s_dom;
  assign iommu_req_asid   = s_asid;
  assign iommu_req_write  = s_wr;
  assign iommu_req_addr   = s_addr;
  assign iommu_req_bytes  = s_bytes;
  assign iommu_req_id     = win;
  wire acc = go_loc || (go_iom && iommu_req_ready);

  always_comb begin
    c_req_ready = '0;
    for (int i = 0; i < NCLI; i++) c_req_ready[i] = acc && (win == IDW'(i));
  end

  // ---------------------------------------------------------------- response routing
  assign iommu_rsp_ready = 1'b1;
  logic        r_known;
  logic        x_bad;                                         // translation result unusable
  logic [AW:0] pa_end;
  always_comb begin
    r_known = (32'(iommu_rsp_id) < NCLI) && pend_q[iommu_rsp_id] && iom_q[iommu_rsp_id];
    pa_end  = {1'b0, iommu_rsp_pa} + {{(AW+1-13){1'b0}}, rq_bytes_q[iommu_rsp_id]};
    x_bad   = iommu_rsp_ok && ((iommu_rsp_pa[LW-1:0] != '0) ||
                               (iommu_rsp_pa[11:0] != rq_off_q[iommu_rsp_id]) ||
                               (pa_end > LIM));
  end
  assign proto_err_evt = iommu_rsp_valid && !r_known;

  always_comb begin
    c_rsp_valid = lf_v_q;
    c_rsp_ok    = '0;
    c_rsp_fault = lf_fault_q;
    c_rsp_pa    = '0;
    if (iommu_rsp_valid && r_known) begin
      c_rsp_valid[iommu_rsp_id]                 = 1'b1;
      c_rsp_ok[iommu_rsp_id]                    = iommu_rsp_ok && !x_bad;
      c_rsp_fault[32'(iommu_rsp_id)*4 +: 4]    = x_bad ? silicaflux_dma_pkg::FAULT_XLAT :
                                                  (iommu_rsp_ok ? silicaflux_dma_pkg::FAULT_NONE :
                                                   (iommu_rsp_fault == silicaflux_dma_pkg::FAULT_NONE ? silicaflux_dma_pkg::FAULT_XLAT : iommu_rsp_fault));
      c_rsp_pa[32'(iommu_rsp_id)*AW +: AW]     = (iommu_rsp_ok && !x_bad) ? iommu_rsp_pa : '0;
    end
  end

  // ---------------------------------------------------------------- state update
  wire rsp_take = iommu_rsp_valid && r_known;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pend_q     <= '0;
      iom_q      <= '0;
      lf_v_q     <= '0;
      lf_fault_q <= '0;
      ptr_q      <= '0;
      lock_v_q   <= 1'b0;
      lock_i_q   <= '0;
      out_q      <= 32'd0;
      for (int i = 0; i < NCLI; i++) begin rq_off_q[i] <= '0; rq_bytes_q[i] <= '0; end
    end else begin
      lf_v_q <= '0;                                           // a local response lasts one cycle
      // lock handling: a request presented to the IOMMU and not accepted keeps its grant
      if (go_iom && !iommu_req_ready) begin lock_v_q <= 1'b1; lock_i_q <= win; end
      else if (acc)                   lock_v_q <= 1'b0;
      if (acc) ptr_q <= (win == IDW'(NCLI - 1)) ? '0 : win + 1'b1;
      if (acc) begin
        pend_q[win]       <= 1'b1;
        iom_q[win]        <= !go_loc;
        rq_off_q[win]     <= s_addr[11:0];
        rq_bytes_q[win]   <= s_bytes[12:0];
      end
      if (go_loc) begin
        lf_v_q[win]                 <= 1'b1;
        lf_fault_q[32'(win)*4 +: 4] <= loc_fault;
      end
      if (rsp_take) begin pend_q[iommu_rsp_id] <= 1'b0; iom_q[iommu_rsp_id] <= 1'b0; end
      for (int i = 0; i < NCLI; i++) if (lf_v_q[i]) pend_q[i] <= 1'b0;
      // in-flight IOMMU requests
      out_q <= out_q + 32'(go_iom && iommu_req_ready) - 32'(iommu_rsp_valid && r_known);
    end
  end
endmodule

`default_nettype wire
