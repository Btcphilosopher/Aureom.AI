// =============================================================================
// CloudDMA :: sfdma_perm_table -- SIMULATION permission table behind the DMA's IOMMU interface
//
// The repository contains no IOMMU (docs/00_AUDIT.md).  Where a platform IOMMU does not exist yet, this block
// answers the same request/response interface a real IOMMU would, from a small programmable table of mappings
//     { domain, address space, [base, base+size) in IOVA, physical base, read/write permission }
// so the whole protection path (checker -> table -> physical address on the bus) is exercised and verified.
// It is a verified MODEL of isolation, not a hardware isolation mechanism by itself: the platform has to
// guarantee that the DMA's memory port is the only path (docs/03_PROTECTION.md).
//
// CONTRACT (identical for a real IOMMU wired to the same ports):
//   * request  : (domain, asid, write, addr, bytes), 1 <= bytes <= 4096, the range [addr, addr+bytes) does not
//                cross a 4 KiB boundary (the DMA guarantees it), plus an opaque id echoed in the response;
//   * response : in request order, one per request:  ok / fault code / physical address of `addr`.
//   * ok means: THE WHOLE range lies inside ONE mapping of this domain+asid that grants the access, and the
//                translation is contiguous (mappings are multiples of the 4 KiB granule, so it is).
// Entry rules, enforced when an entry is written (violations are refused and counted, the entry is unchanged):
//   base, size, pa multiples of 2**GRAN_LOG2 (4 KiB); size > 0; base+size <= 2**AW; pa+size <= 2**AW.
// Overlapping entries of the same domain+asid are allowed; the lowest-index granting entry supplies the PA.
// Fault priority when nothing grants:  PERM (range inside a mapping lacking the right)  >  RANGE (starts inside a
// mapping, leaves it)  >  DOMAIN (starts inside a mapping of ANOTHER domain, same asid)  >  NO_MAP.
// LAT >= 1 is the response latency in cycles (models an IOMMU TLB hit; sweeps in docs/06_PERFORMANCE.md).
// Classification: SYNTHESIZABLE (it synthesizes, but it is a simulation/bring-up model by intent)
// =============================================================================
`default_nettype none

module sfdma_perm_table #(
  parameter int AW       = 48,
  parameter int DOM_W    = 4,
  parameter int IDW      = 4,
  parameter int NENT     = 16,
  parameter int LAT      = 1,
  parameter int GRAN_LOG2 = 12,
  localparam int EW      = (NENT > 1) ? $clog2(NENT) : 1,
  localparam int RW      = IDW + 1 + 4 + AW
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // programming port (management plane)
  input  wire logic            tw_en,
  input  wire logic [EW-1:0]   tw_idx,
  input  wire logic            tw_valid,
  input  wire logic [DOM_W-1:0] tw_domain,
  input  wire logic [3:0]      tw_asid,
  input  wire logic [AW-1:0]   tw_base,
  input  wire logic [AW:0]     tw_size,
  input  wire logic [AW-1:0]   tw_pa,
  input  wire logic [1:0]      tw_perm,
  output logic                 tw_rej,        // pulse: the write was refused
  output logic [31:0]          rej_count,
  // IOMMU request / response interface
  input  wire logic            req_valid,
  output logic                 req_ready,
  input  wire logic [DOM_W-1:0] req_domain,
  input  wire logic [3:0]      req_asid,
  input  wire logic            req_write,
  input  wire logic [AW-1:0]   req_addr,
  input  wire logic [15:0]     req_bytes,
  input  wire logic [IDW-1:0]  req_id,
  output logic                 rsp_valid,
  input  wire logic            rsp_ready,
  output logic [IDW-1:0]       rsp_id,
  output logic                 rsp_ok,
  output logic [3:0]           rsp_fault,
  output logic [AW-1:0]        rsp_pa
);
  // ------------------------------------------------------------------ entries
  logic [NENT-1:0]  e_valid;
  logic [DOM_W-1:0] e_dom  [NENT];
  logic [3:0]       e_asid [NENT];
  logic [AW-1:0]    e_base [NENT];
  logic [AW:0]      e_size [NENT];
  logic [AW-1:0]    e_pa   [NENT];
  logic [1:0]       e_perm [NENT];

  // entry write checks (65/66-bit arithmetic: no wrap)
  wire [AW+1:0] tw_bend = {2'b0, tw_base} + {1'b0, tw_size};
  wire [AW+1:0] tw_pend = {2'b0, tw_pa}   + {1'b0, tw_size};
  wire [AW+1:0] lim     = {1'b0, 1'b1, {AW{1'b0}}};                 // 2**AW
  wire gran_ok = (tw_base[GRAN_LOG2-1:0] == '0) && (tw_pa[GRAN_LOG2-1:0] == '0) && (tw_size[GRAN_LOG2-1:0] == '0);
  wire entry_ok = gran_ok && (tw_size != '0) && (tw_bend <= lim) && (tw_pend <= lim);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      e_valid   <= '0;
      tw_rej    <= 1'b0;
      rej_count <= '0;
      for (int i = 0; i < NENT; i++) begin
        e_dom[i] <= '0; e_asid[i] <= '0; e_base[i] <= '0; e_size[i] <= '0; e_pa[i] <= '0; e_perm[i] <= '0;
      end
    end else begin
      tw_rej <= 1'b0;
      if (tw_en) begin
        if (!tw_valid) begin
          e_valid[tw_idx] <= 1'b0;                                   // invalidation is always allowed
        end else if (entry_ok) begin
          e_valid[tw_idx] <= 1'b1;
          e_dom[tw_idx]   <= tw_domain;
          e_asid[tw_idx]  <= tw_asid;
          e_base[tw_idx]  <= tw_base;
          e_size[tw_idx]  <= tw_size;
          e_pa[tw_idx]    <= tw_pa;
          e_perm[tw_idx]  <= tw_perm;
        end else begin
          tw_rej    <= 1'b1;
          rej_count <= rej_count + 32'd1;
        end
      end
    end
  end

  // ------------------------------------------------------------------ lookup (combinational on the request)
  logic          l_ok;
  logic [3:0]    l_fault;
  logic [AW-1:0] l_pa;
  always_comb begin
    logic hit, any_perm, any_range, any_dom;
    logic [AW+1:0] a_end, b_end, a_lo;
    logic starts_in, in_rng, pok, same, other;
    hit = 1'b0; any_perm = 1'b0; any_range = 1'b0; any_dom = 1'b0;
    l_pa = '0;
    a_lo  = {2'b0, req_addr};
    a_end = {2'b0, req_addr} + {{(AW+2-16){1'b0}}, req_bytes};
    for (int e = 0; e < NENT; e++) begin
      b_end     = {2'b0, e_base[e]} + {1'b0, e_size[e]};
      starts_in = (a_lo >= {2'b0, e_base[e]}) && (a_lo < b_end);
      in_rng    = starts_in && (a_end <= b_end);
      pok       = req_write ? e_perm[e][1] : e_perm[e][0];
      same      = e_valid[e] && (e_dom[e] == req_domain) && (e_asid[e] == req_asid);
      other     = e_valid[e] && (e_dom[e] != req_domain) && (e_asid[e] == req_asid);
      if (same && in_rng && pok && !hit) begin
        hit  = 1'b1;
        l_pa = e_pa[e] + (req_addr - e_base[e]);
      end
      if (same && in_rng && !pok) any_perm  = 1'b1;
      if (same && starts_in && !in_rng) any_range = 1'b1;
      if (other && starts_in) any_dom = 1'b1;
    end
    l_ok = hit;
    if (hit)            l_fault = silicaflux_dma_pkg::FAULT_NONE;
    else if (any_perm)  l_fault = silicaflux_dma_pkg::FAULT_PERM;
    else if (any_range) l_fault = silicaflux_dma_pkg::FAULT_RANGE;
    else if (any_dom)   l_fault = silicaflux_dma_pkg::FAULT_DOMAIN;
    else                l_fault = silicaflux_dma_pkg::FAULT_NO_MAP;
    if (hit == 1'b0) l_pa = '0;
  end

  // ------------------------------------------------------------------ response pipeline (LAT stages, in order)
  logic [LAT-1:0] v_q;
  logic [RW-1:0]  d_q [LAT];
  wire stall = v_q[LAT-1] && !rsp_ready;
  assign req_ready = !stall;
  wire acc = req_valid && req_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      v_q <= '0;
      for (int i = 0; i < LAT; i++) d_q[i] <= '0;
    end else if (!stall) begin
      v_q[0] <= acc;
      d_q[0] <= {req_id, l_ok, l_fault, l_pa};
      for (int i = 1; i < LAT; i++) begin
        v_q[i] <= v_q[i-1];
        d_q[i] <= d_q[i-1];
      end
    end
  end
  assign rsp_valid = v_q[LAT-1];
  assign {rsp_id, rsp_ok, rsp_fault, rsp_pa} = d_q[LAT-1];
endmodule

`default_nettype wire
