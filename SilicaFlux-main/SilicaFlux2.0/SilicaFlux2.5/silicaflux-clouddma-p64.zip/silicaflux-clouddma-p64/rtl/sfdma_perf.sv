// =============================================================================
// CloudDMA :: sfdma_perf -- performance counter bank (NUM_PC accumulating counters + NUM_PM watermarks per channel)
//
// Every cycle counter i adds the 16-bit value its channel presents (1 for a plain event, a level for an occupancy
// integral, a latency for a latency sum).  Watermarks keep the maximum of the candidate value.  `clr` clears all
// (it wins over a same-cycle add).  The read port is combinational; the CSR block latches the HI word when the LO
// word is read, so a 64-bit read is consistent.  Derived metrics (docs/06_PERFORMANCE.md):
//   bytes/cycle      = BYTES_WR / ACTIVE            burst utilisation = BEATS_WR / (BURSTS_WR * MAXB)
//   avg occupancy    = OCC_x / ACTIVE               avg latency       = LAT_SUM / (XACT_OK + XACT_ERR)
//   permission cost  = PERM_LAT / PERM_REQ (cycles) memory contention = (STALL_AR+STALL_AW+STALL_W) / ACTIVE, RD_LAT / BURSTS_RD
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfdma_perf #(
  parameter int NCH  = 1,
  parameter int PC_W = 48
) (
  input  wire logic                                  clk,
  input  wire logic                                  rst_n,
  input  wire logic                                  clr,
  input  wire logic [NCH*512-1:0] pf_add,
  input  wire logic [NCH*4*16-1:0]                   pm_val,
  input  wire logic [7:0]                            sel_ch,
  input  wire logic [7:0]                            sel_id,
  output logic [63:0]                                rd_val
);
  localparam int NPC = 32;
  localparam int NPM = 4;
  logic [NCH*NPC*PC_W-1:0] cnt_q;                    // flat vectors (large unpacked arrays hit a Verilator loop-init limit)
  logic [NCH*NPM*16-1:0]   mx_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NCH*NPC; i++) cnt_q[PC_W*i +: PC_W] <= '0;
      for (int i = 0; i < NCH*NPM; i++) mx_q[16*i +: 16]      <= '0;
    end else if (clr) begin
      for (int i = 0; i < NCH*NPC; i++) cnt_q[PC_W*i +: PC_W] <= '0;
      for (int i = 0; i < NCH*NPM; i++) mx_q[16*i +: 16]      <= '0;
    end else begin
      for (int i = 0; i < NCH*NPC; i++) cnt_q[PC_W*i +: PC_W] <= cnt_q[PC_W*i +: PC_W] + PC_W'(pf_add[16*i +: 16]);
      for (int i = 0; i < NCH*NPM; i++) if (pm_val[16*i +: 16] > mx_q[16*i +: 16]) mx_q[16*i +: 16] <= pm_val[16*i +: 16];
    end
  end

  always_comb begin
    rd_val = 64'd0;
    if (32'(sel_ch) < NCH) begin
      if (32'(sel_id) < NPC)             rd_val = 64'(cnt_q[PC_W*(32'(sel_ch)*NPC + 32'(sel_id)) +: PC_W]);
      else if (32'(sel_id) < NPC + NPM)  rd_val = 64'(mx_q[16*(32'(sel_ch)*NPM + 32'(sel_id) - NPC) +: 16]);
    end
  end
endmodule

`default_nettype wire
