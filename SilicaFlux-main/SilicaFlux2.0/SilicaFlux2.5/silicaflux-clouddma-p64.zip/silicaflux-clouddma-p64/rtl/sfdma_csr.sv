// =============================================================================
// CloudDMA :: sfdma_csr -- management-plane register file (32-bit, single-cycle access, response one cycle later)
//
// Map: silicaflux_dma_pkg CSR_* / CH_* (docs/04_INTEGRATION.md).  Privileged: it must never be reachable by a tenant.
// Reset state is conservative: the engine is DISABLED (no command starts) until the management plane writes CTRL.enable.
// SOFT RESET (CTRL[1]): resets the DMA core (walker, controller, channels, checker, permission table state is NOT a
// register of this block) for 4 cycles; CSR configuration and counters survive.  The platform must make sure no stale
// bus response is delivered afterwards (the same contract as a system reset, DataFabric SFB2 R11).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfdma_csr #(
  parameter int NCH         = 1,
  parameter int DW          = 64,
  parameter int AW          = 48,
  parameter int DOM_W       = 4,
  parameter int MAXB        = 16,
  parameter int RD_OUT      = 4,
  parameter int WR_OUT      = 4,
  parameter int BUF_BYTES   = 1024,
  parameter int TIMEOUT_DEF = 0,
  parameter int MAX_CHAIN   = 64,
  parameter int PC_W        = 48
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            csr_req_valid,
  output logic                 csr_req_ready,
  input  wire logic            csr_req_write,
  input  wire logic [11:0]     csr_req_addr,
  input  wire logic [31:0]     csr_req_wdata,
  output logic                 csr_rsp_valid,
  output logic [31:0]          csr_rsp_rdata,
  output logic                 csr_rsp_err,
  // controls
  output logic                 enable,
  output logic                 soft_rst,
  output logic                 trace_en,
  output logic                 perf_clr,
  output logic                 trace_pop,
  output logic [31:0]          timeout,
  output logic [15:0]          max_chain,
  output logic [15:0]          asid_en,
  output logic [NCH-1:0]       ch_abort,
  // status
  input  wire logic [NCH-1:0]       st_busy,
  input  wire logic [NCH-1:0]       st_fenced,
  input  wire logic [NCH*4-1:0]     st_last_status,
  input  wire logic [NCH*8-1:0]     st_last_err,
  input  wire logic [NCH*4-1:0]     st_last_fault,
  input  wire logic [NCH*16-1:0]    st_last_txn,
  input  wire logic [NCH*AW-1:0]    st_last_eaddr,
  input  wire logic [NCH*32-1:0]    st_last_bytes,
  input  wire logic [NCH*32-1:0]    st_last_crc,
  input  wire logic [NCH*DOM_W-1:0] st_last_domain,
  input  wire logic [NCH*16-1:0]    st_last_descs,
  input  wire logic [NCH-1:0]       st_last_valid,
  input  wire logic [NCH-1:0]       irq_done_evt,
  input  wire logic [NCH-1:0]       irq_err_evt,
  output logic                      irq,
  // perf / trace windows
  output logic [7:0]           perf_sel_ch,
  output logic [7:0]           perf_sel_id,
  input  wire logic [63:0]     perf_val,
  input  wire logic [31:0]     proto_cnt,
  input  wire logic [95:0]     tr_head,
  input  wire logic [15:0]     tr_count,
  input  wire logic [15:0]     tr_drop
);
  logic        en_q, tr_q;
  logic [2:0]  soft_q;
  logic [31:0] irq_en_q, irq_st_q, tmo_q, perf_hi_q;
  logic [15:0] mc_q, ae_q;
  logic [15:0] psel_q;
  logic [31:0] rdata;
  logic        werr_c;
  logic        pop_c, clr_c, abort_c_any;
  logic [NCH-1:0] abort_c;
  wire [15:0]  busy16 = 16'(st_busy), fenced16 = 16'(st_fenced), valid16 = 16'(st_last_valid);
  /* verilator lint_off UNUSEDSIGNAL */
  logic [15:0] abort16;
  /* verilator lint_on UNUSEDSIGNAL */

  assign csr_req_ready = 1'b1;
  assign enable        = en_q;
  assign soft_rst      = (soft_q != 3'd0);
  assign trace_en      = tr_q;
  assign timeout       = tmo_q;
  assign max_chain     = mc_q;
  assign asid_en       = ae_q;
  assign perf_sel_ch   = psel_q[15:8];
  assign perf_sel_id   = psel_q[7:0];
  assign irq           = |(irq_st_q & irq_en_q);

  wire acc   = csr_req_valid && csr_req_ready;
  wire wr    = acc && csr_req_write;
  wire rd    = acc && !csr_req_write;
  wire [11:0] a = csr_req_addr;
  wire is_ch = (a >= 12'(silicaflux_dma_pkg::CSR_CH_BASE)) && (32'(a) < 32'(silicaflux_dma_pkg::CSR_CH_BASE) + NCH * 32'(silicaflux_dma_pkg::CSR_CH_STRIDE));
  wire [11:0] a_rel = a - 12'(silicaflux_dma_pkg::CSR_CH_BASE);
  wire [7:0]  ch_i  = 8'(32'(a_rel) / 32'(silicaflux_dma_pkg::CSR_CH_STRIDE));
  wire [11:0] ch_off = 12'(32'(a_rel) % 32'(silicaflux_dma_pkg::CSR_CH_STRIDE));

  // read multiplexer (combinational; the response is registered below)
  logic known;
  always_comb begin
    rdata = 32'd0; known = 1'b1;
    if (a[1:0] != 2'b00) known = 1'b0;
    else if (is_ch) begin
      case (ch_off)
        12'(silicaflux_dma_pkg::CH_CTRL):        rdata = 32'd0;
        12'(silicaflux_dma_pkg::CH_STATUS):      rdata = {24'd0, st_last_status[4*ch_i +: 4], 1'b0, valid16[ch_i[3:0]], fenced16[ch_i[3:0]], busy16[ch_i[3:0]]};
        12'(silicaflux_dma_pkg::CH_ERR):         rdata = {st_last_txn[16*ch_i +: 16], st_last_err[8*ch_i +: 8], st_last_fault[4*ch_i +: 4], 4'd0};
        12'(silicaflux_dma_pkg::CH_ERR_ADDR_LO): rdata = 32'(st_last_eaddr[AW*ch_i +: AW]);
        12'(silicaflux_dma_pkg::CH_ERR_ADDR_HI): rdata = 32'(st_last_eaddr[AW*ch_i +: AW] >> 32);
        12'(silicaflux_dma_pkg::CH_BYTES):       rdata = st_last_bytes[32*ch_i +: 32];
        12'(silicaflux_dma_pkg::CH_CRC):         rdata = st_last_crc[32*ch_i +: 32];
        12'(silicaflux_dma_pkg::CH_DOMAIN):      rdata = 32'(st_last_domain[DOM_W*ch_i +: DOM_W]);
        12'(silicaflux_dma_pkg::CH_DESCS):       rdata = 32'(st_last_descs[16*ch_i +: 16]);
        default: known = 1'b0;
      endcase
    end else begin
      case (a)
        12'(silicaflux_dma_pkg::CSR_ID):        rdata = silicaflux_dma_pkg::DMA_ID_MAGIC;
        12'(silicaflux_dma_pkg::CSR_VERSION):   rdata = {silicaflux_dma_pkg::DMA_ABI_MAJOR, silicaflux_dma_pkg::DMA_ABI_MINOR};
        12'(silicaflux_dma_pkg::CSR_CAPS0):     rdata = {8'(DOM_W), 8'(AW), 8'($clog2(DW/8)), 8'(NCH)};
        12'(silicaflux_dma_pkg::CSR_CAPS1):     rdata = {8'($clog2(BUF_BYTES)), 8'(WR_OUT), 8'(RD_OUT), 8'(MAXB)};
        12'(silicaflux_dma_pkg::CSR_CTRL):      rdata = {29'd0, tr_q, 1'b0, en_q};
        12'(silicaflux_dma_pkg::CSR_STATUS):    rdata = {16'(st_fenced), 16'(st_busy)};
        12'(silicaflux_dma_pkg::CSR_IRQ_EN):    rdata = irq_en_q;
        12'(silicaflux_dma_pkg::CSR_IRQ_STAT):  rdata = irq_st_q;
        12'(silicaflux_dma_pkg::CSR_TIMEOUT):   rdata = tmo_q;
        12'(silicaflux_dma_pkg::CSR_MAX_CHAIN): rdata = 32'(mc_q);
        12'(silicaflux_dma_pkg::CSR_ASID_EN):   rdata = 32'(ae_q);
        12'(silicaflux_dma_pkg::CSR_PROTO):     rdata = proto_cnt;
        12'(silicaflux_dma_pkg::CSR_PERF_SEL):  rdata = 32'(psel_q);
        12'(silicaflux_dma_pkg::CSR_PERF_LO):   rdata = perf_val[31:0];
        12'(silicaflux_dma_pkg::CSR_PERF_HI):   rdata = perf_hi_q;
        12'(silicaflux_dma_pkg::CSR_TR_STAT):   rdata = {tr_drop, tr_count};
        12'(silicaflux_dma_pkg::CSR_TR_W0):     rdata = tr_head[31:0];
        12'(silicaflux_dma_pkg::CSR_TR_W1):     rdata = tr_head[63:32];
        12'(silicaflux_dma_pkg::CSR_TR_W2):     rdata = tr_head[95:64];
        12'(silicaflux_dma_pkg::CSR_TR_POP):    rdata = 32'd0;
        default: known = 1'b0;
      endcase
    end
  end

  // writable / read-only classification
  logic wr_known;
  always_comb begin
    wr_known = 1'b0;
    if (a[1:0] == 2'b00) begin
      if (is_ch) wr_known = (ch_off == 12'(silicaflux_dma_pkg::CH_CTRL));
      else case (a)
        12'(silicaflux_dma_pkg::CSR_CTRL), 12'(silicaflux_dma_pkg::CSR_IRQ_EN), 12'(silicaflux_dma_pkg::CSR_IRQ_STAT),
        12'(silicaflux_dma_pkg::CSR_TIMEOUT), 12'(silicaflux_dma_pkg::CSR_MAX_CHAIN), 12'(silicaflux_dma_pkg::CSR_ASID_EN),
        12'(silicaflux_dma_pkg::CSR_PERF_SEL), 12'(silicaflux_dma_pkg::CSR_TR_POP): wr_known = 1'b1;
        default: wr_known = 1'b0;
      endcase
    end
  end
  assign werr_c = wr && !wr_known;

  always_comb begin
    abort16 = 16'd0; pop_c = 1'b0; clr_c = 1'b0;
    if (wr && is_ch && ch_off == 12'(silicaflux_dma_pkg::CH_CTRL) && csr_req_wdata[0] && (32'(ch_i) < NCH)) abort16[ch_i[3:0]] = 1'b1;
    if (wr && !is_ch && a == 12'(silicaflux_dma_pkg::CSR_TR_POP) && csr_req_wdata[0]) pop_c = 1'b1;
    if (wr && !is_ch && a == 12'(silicaflux_dma_pkg::CSR_CTRL) && csr_req_wdata[3]) clr_c = 1'b1;
  end
  assign abort_c = abort16[NCH-1:0];
  assign abort_c_any = |abort_c;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      en_q <= 1'b0; tr_q <= 1'b0; soft_q <= 3'd0; irq_en_q <= '0; irq_st_q <= '0; tmo_q <= 32'(TIMEOUT_DEF);
      mc_q <= 16'(MAX_CHAIN); ae_q <= silicaflux_dma_pkg::ASID_EN_DEFAULT; psel_q <= '0; perf_hi_q <= '0;
      csr_rsp_valid <= 1'b0; csr_rsp_rdata <= '0; csr_rsp_err <= 1'b0; perf_clr <= 1'b0; trace_pop <= 1'b0; ch_abort <= '0;
    end else begin
      csr_rsp_valid <= acc; csr_rsp_err <= acc && (csr_req_write ? !wr_known : !known); csr_rsp_rdata <= acc ? (csr_req_write ? 32'd0 : rdata) : 32'd0;
      perf_clr <= clr_c; trace_pop <= pop_c; ch_abort <= abort_c;
      if (soft_q != 3'd0) soft_q <= soft_q - 3'd1;
      // sticky interrupt causes
      for (int i = 0; i < NCH; i++) begin
        if (irq_done_evt[i]) irq_st_q[i] <= 1'b1;
        if (irq_err_evt[i])  irq_st_q[16 + i] <= 1'b1;
      end
      if (wr && wr_known && !is_ch) begin
        case (a)
          12'(silicaflux_dma_pkg::CSR_CTRL): begin en_q <= csr_req_wdata[0]; tr_q <= csr_req_wdata[2]; if (csr_req_wdata[1]) soft_q <= 3'd4; end
          12'(silicaflux_dma_pkg::CSR_IRQ_EN):   irq_en_q <= csr_req_wdata;
          12'(silicaflux_dma_pkg::CSR_IRQ_STAT): irq_st_q <= (irq_st_q & ~csr_req_wdata) | {16'(irq_err_evt), 16'(irq_done_evt)} ;
          12'(silicaflux_dma_pkg::CSR_TIMEOUT):  tmo_q <= csr_req_wdata;
          12'(silicaflux_dma_pkg::CSR_MAX_CHAIN): mc_q <= (csr_req_wdata[15:0] > 16'(MAX_CHAIN)) ? 16'(MAX_CHAIN) : csr_req_wdata[15:0];
          12'(silicaflux_dma_pkg::CSR_ASID_EN):  ae_q <= csr_req_wdata[15:0];
          12'(silicaflux_dma_pkg::CSR_PERF_SEL): psel_q <= csr_req_wdata[15:0];
          default: ;
        endcase
      end
      if (rd && !is_ch && a == 12'(silicaflux_dma_pkg::CSR_PERF_LO)) perf_hi_q <= perf_val[63:32];   // LO read latches HI
    end
  end
  wire unused_csr = werr_c && abort_c_any && |PC_W[0];
endmodule

`default_nettype wire
