// =============================================================================
// CloudDMA :: sfdma_channel -- one DMA channel: command queue, walker, burst controller, watchdog, completion record
//
//   cmd --> [cmd FIFO] --> IDLE --start--> RUN --(walker done & burst controller quiet)--> FIN --> [CPL record] --> DONE
//
// COMPLETION.  A transaction is complete only when every destination write has been acknowledged (B response, AXI4:
// the slave has accepted the write at its point of visibility) AND, if CPL_EN is set, the completion record itself
// has been written and acknowledged.  Only then does `done_valid` rise.  Completion is never signalled when the last
// read is issued, nor when the last W beat is accepted.
//
// ERRORS.  First error wins.  A DESCRIPTOR error (walker: bad field, refused fetch, fetch bus error) lets the elements
// that were already validated and handed over finish, then ends the transaction: deterministic "valid prefix
// executes".  An EXECUTION error (burst controller: permission refusal on a data burst, bus error, protocol error),
// an ABORT command or a TIMEOUT stops issuing at once and drains.  Nothing is rolled back: bytes acknowledged stay
// written and are counted in BYTES.
//
// WATCHDOG.  If a running transaction makes no progress for `timeout` cycles (0 = disabled) the channel reports
// ERR_TIMEOUT, writes NO completion record (the bus is presumed stuck) and is FENCED: no new command starts until
// every outstanding response has come back (late responses are absorbed and dropped) or a soft reset clears the channel.
//
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfdma_channel #(
  parameter int DW         = 64,
  parameter int AW         = 48,
  parameter int DOM_W      = 4,
  parameter int MAXB       = 16,
  parameter int BND_LOG2   = 12,
  parameter int RD_OUT     = 4,
  parameter int WR_OUT     = 4,
  parameter int BUF_BYTES  = 1024,
  parameter int ELQ        = 2,
  parameter int CMDQ       = 2,
  parameter int MAX_ELEM_LOG2  = 24,
  parameter int MAX_TOTAL_LOG2 = 30,
  parameter bit REORDER_OK = 1'b1,
  parameter bit CRC_ON     = 1'b1,
  localparam int WB        = DW / 8,
  localparam int LW        = $clog2(WB),
  localparam int MXO       = (RD_OUT > WR_OUT) ? RD_OUT : WR_OUT,
  localparam int SW        = (MXO > 1) ? $clog2(MXO) : 1,
  localparam int LIDW      = SW + 1                       // {class, slot}: class 1 = descriptor fetch (reads) / completion record (writes)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // configuration (management plane)
  input  wire logic            enable,
  input  wire logic [31:0]     timeout,
  input  wire logic [15:0]     max_chain_rt,
  input  wire logic [15:0]     asid_en,
  input  wire logic            ch_abort,                 // pulse
  // command port
  input  wire logic            cmd_valid,
  output logic                 cmd_ready,
  input  wire logic [63:0]     cmd_head,
  input  wire logic [DOM_W-1:0] cmd_domain,              // AUTHORITATIVE domain (hardware binding of the submitter)
  input  wire logic [3:0]      cmd_asid,                 // address space of the descriptors
  // completion port
  output logic                 done_valid,
  input  wire logic            done_ready,
  output logic [15:0]          done_txn,
  output logic [3:0]           done_status,
  output logic [7:0]           done_err,
  output logic [3:0]           done_fault,
  output logic [DOM_W-1:0]     done_domain,
  output logic [31:0]          done_bytes,
  output logic [31:0]          done_crc,
  output logic                 done_irq,
  output logic                 viol_evt,                 // pulse: isolation violation (err 0x2x)
  // permission checker clients, index = silicaflux_dma_pkg::CLI_*
  output logic [3:0]           pc_req_valid,
  input  wire logic [3:0]      pc_req_ready,
  output logic [DOM_W-1:0]     pc_req_domain,
  output logic [4*4-1:0]       pc_req_asid,
  output logic [3:0]           pc_req_write,
  output logic [4*AW-1:0]      pc_req_addr,
  output logic [4*16-1:0]      pc_req_bytes,
  input  wire logic [3:0]      pc_rsp_valid,
  input  wire logic [3:0]      pc_rsp_ok,
  input  wire logic [4*4-1:0]  pc_rsp_fault,
  input  wire logic [4*AW-1:0] pc_rsp_pa,
  // memory port (local ids: {class, slot})
  output logic                 ar_valid,
  input  wire logic            ar_ready,
  output logic [LIDW-1:0]      ar_id,
  output logic [3:0]           ar_asid,
  output logic [DOM_W-1:0]     ar_domain,
  output logic [AW-1:0]        ar_addr,
  output logic [7:0]           ar_len,
  input  wire logic            r_valid,
  input  wire logic [LIDW-1:0] r_id,
  input  wire logic [DW-1:0]   r_data,
  input  wire logic            r_err,
  input  wire logic            r_last,
  output logic                 aw_valid,
  input  wire logic            aw_ready,
  output logic [LIDW-1:0]      aw_id,
  output logic [3:0]           aw_asid,
  output logic [DOM_W-1:0]     aw_domain,
  output logic [AW-1:0]        aw_addr,
  output logic [7:0]           aw_len,
  output logic                 w_valid,
  input  wire logic            w_ready,
  output logic [DW-1:0]        w_data,
  output logic [WB-1:0]        w_strb,
  output logic                 w_last,
  input  wire logic            b_valid,
  input  wire logic [LIDW-1:0] b_id,
  input  wire logic            b_err,
  // status (CSR view)
  output logic                 st_busy,
  output logic                 st_fenced,
  output logic [3:0]           st_last_status,
  output logic [7:0]           st_last_err,
  output logic [3:0]           st_last_fault,
  output logic [15:0]          st_last_txn,
  output logic [AW-1:0]        st_last_eaddr,
  output logic [31:0]          st_last_bytes,
  output logic [31:0]          st_last_crc,
  output logic [DOM_W-1:0]     st_last_domain,
  output logic [15:0]          st_last_descs,
  output logic                 st_last_valid,
  // performance (one add value per counter and cycle) and watermark candidates; trace sources
  output logic [32*16-1:0]     pf_add,
  output logic [4*16-1:0]      pm_val,
  output logic [3:0]           tr_v,
  output logic [4*8-1:0]       tr_code,
  output logic [4*32-1:0]      tr_arg,
  output logic [15:0]          tr_txn,
  output logic                 proto_evt
);
  localparam logic [3:0] C_IDLE = 4'd0, C_RUN = 4'd1, C_FIN = 4'd2, C_CPL = 4'd3, C_DONE = 4'd4;
  localparam logic [3:0] K_PLAN = 4'd0, K_CHK = 4'd1, K_CHKW = 4'd2, K_AW = 4'd3, K_W = 4'd4, K_B = 4'd5;

  logic [3:0]       c_st, k_st;
  logic [DOM_W-1:0] dom_q;
  logic             stop_q, fail_q, viol_q, fenced_q, timed_q;
  logic [7:0]       ecode_q;
  logic [3:0]       efault_q;
  logic [AW-1:0]    eaddr_q;
  logic [15:0]      lat_q, last_lat_q;
  logic [31:0]      wd_q;

  // ------------------------------------------------------------------ command FIFO (vendored sfd_fifo)
  localparam int CMDW = 64 + DOM_W + 4;
  logic            q_out_valid, q_pop;
  logic [CMDW-1:0] q_out;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [$clog2(CMDQ+1)-1:0] q_level;
  /* verilator lint_on UNUSEDSIGNAL */
  sfd_fifo #(.WIDTH(CMDW), .DEPTH(CMDQ)) u_cmdq (
    .clk, .rst_n, .flush(1'b0),
    .in_valid(cmd_valid), .in_ready(cmd_ready), .in_data({cmd_asid, cmd_domain, cmd_head}),
    .out_valid(q_out_valid), .out_ready(q_pop), .out_data(q_out), .level(q_level));
  wire [63:0]       q_head   = q_out[63:0];
  wire [DOM_W-1:0]  q_dom    = q_out[64 +: DOM_W];
  wire [3:0]        q_asid   = q_out[64 + DOM_W +: 4];

  wire start = (c_st == C_IDLE) && q_out_valid && enable && !fenced_q;
  assign q_pop = start;

  // ------------------------------------------------------------------ walker
  logic        w_el_valid, w_el_ready;
  logic [3:0]  w_el_sa, w_el_da;
  logic [AW-1:0] w_el_src, w_el_dst;
  logic [31:0] w_el_len;
  logic        w_el_ord;
  logic [15:0] tx_txn;
  logic        tx_cpl_en, tx_crc_en, tx_irq_en;
  logic [AW-1:0] tx_cpl_addr;
  logic [3:0]  tx_cpl_asid;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        wk_done, wk_fail;
  /* verilator lint_on UNUSEDSIGNAL */
  logic        wk_busy, wk_err_evt, wk_wait_perm, wk_ev_desc;
  logic [7:0]  wk_err_code;
  logic [3:0]  wk_err_fault;
  logic [AW-1:0] wk_err_addr;
  logic [15:0] wk_descs, wk_desc_lat;
  logic [31:0] wk_desc_arg;
  logic        wk_pc_valid; logic [AW-1:0] wk_pc_addr; logic [15:0] wk_pc_bytes; logic [3:0] wk_pc_asid;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [DOM_W-1:0] wk_pc_dom;                                  // (== dom_q)
  /* verilator lint_on UNUSEDSIGNAL */
  logic        wk_ar_valid, wk_ar_ready; logic [AW-1:0] wk_ar_addr; logic [7:0] wk_ar_len;
  logic        wk_r_valid;
  wire         wk_start = start;

  sfdma_desc_walker #(.DW(DW), .AW(AW), .DOM_W(DOM_W), .MAX_ELEM_LOG2(MAX_ELEM_LOG2), .MAX_TOTAL_LOG2(MAX_TOTAL_LOG2)) u_walk (
    .clk, .rst_n, .start(wk_start), .start_head(q_head), .start_domain(q_dom), .start_asid(q_asid),
    .stop(stop_q), .max_chain_rt, .asid_en,
    .pc_req_valid(wk_pc_valid), .pc_req_ready(pc_req_ready[silicaflux_dma_pkg::CLI_DESC]), .pc_req_addr(wk_pc_addr),
    .pc_req_asid(wk_pc_asid), .pc_req_domain(wk_pc_dom), .pc_req_bytes(wk_pc_bytes),
    .pc_rsp_valid(pc_rsp_valid[silicaflux_dma_pkg::CLI_DESC]), .pc_rsp_ok(pc_rsp_ok[silicaflux_dma_pkg::CLI_DESC]),
    .pc_rsp_fault(pc_rsp_fault[silicaflux_dma_pkg::CLI_DESC*4 +: 4]), .pc_rsp_pa(pc_rsp_pa[silicaflux_dma_pkg::CLI_DESC*AW +: AW]),
    .ar_valid(wk_ar_valid), .ar_ready(wk_ar_ready), .ar_addr(wk_ar_addr), .ar_len(wk_ar_len),
    .r_valid(wk_r_valid), .r_data, .r_err, .r_last,
    .el_valid(w_el_valid), .el_ready(w_el_ready), .el_src_asid(w_el_sa), .el_dst_asid(w_el_da), .el_src(w_el_src), .el_dst(w_el_dst),
    .el_len(w_el_len), .el_ordered(w_el_ord),
    .tx_txn, .tx_cpl_en, .tx_crc_en, .tx_irq_en, .tx_cpl_addr, .tx_cpl_asid,
    .busy(wk_busy), .walk_done(wk_done), .walk_fail(wk_fail), .err_evt(wk_err_evt), .err_code(wk_err_code), .err_fault(wk_err_fault),
    .err_addr(wk_err_addr), .descs_done(wk_descs), .busy_wait_perm(wk_wait_perm), .ev_desc(wk_ev_desc), .ev_desc_lat(wk_desc_lat),
    .ev_desc_arg(wk_desc_arg));

  // ------------------------------------------------------------------ burst controller
  /* verilator lint_off UNUSEDSIGNAL */
  logic        bc_fail;
  /* verilator lint_on UNUSEDSIGNAL */
  logic        bc_quiet, bc_prog, bc_err_evt;
  logic [7:0]  bc_err_code; logic [3:0] bc_err_fault; logic [AW-1:0] bc_err_addr;
  logic [31:0] bc_bytes, bc_crc;
  logic        bc_ar_valid, bc_ar_ready; logic [SW-1:0] bc_ar_id; logic [3:0] bc_ar_asid; logic [AW-1:0] bc_ar_addr; logic [7:0] bc_ar_len;
  logic        bc_r_valid;
  logic        bc_aw_valid, bc_aw_ready; logic [SW-1:0] bc_aw_id; logic [3:0] bc_aw_asid; logic [AW-1:0] bc_aw_addr; logic [7:0] bc_aw_len;
  logic        bc_w_valid, bc_w_ready; logic [DW-1:0] bc_w_data; logic [WB-1:0] bc_w_strb; logic bc_w_last;
  logic        bc_b_valid;
  logic        pf_stall_wdata, pf_stall_full, pf_stall_rslot, pf_stall_wslot, pf_perm_wait_c;
  logic        pf_beat_rd, pf_beat_wr, pf_burst_rd, pf_burst_wr, pf_elem, pf_rd_lat_v, pf_wr_lat_v;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        pf_stall_ar_c, pf_stall_aw_c, pf_stall_w_c;     // (channel-level stalls are computed after the AR/AW/W muxes)
  /* verilator lint_on UNUSEDSIGNAL */
  logic [15:0] pf_bytes_rd, pf_bytes_wr, pf_buf_level, pf_rd_lat, pf_wr_lat;
  logic [7:0]  pf_occ_rd, pf_occ_wr;
  logic        tr_rd_v, tr_wr_v; logic [31:0] tr_rd_arg, tr_wr_arg;
  logic        bc_pr_valid; logic [3:0] bc_pr_asid; logic [AW-1:0] bc_pr_addr; logic [15:0] bc_pr_bytes;
  logic        bc_pw_valid; logic [3:0] bc_pw_asid; logic [AW-1:0] bc_pw_addr; logic [15:0] bc_pw_bytes;

  sfdma_burst_ctrl #(.DW(DW), .AW(AW), .MAXB(MAXB), .BND_LOG2(BND_LOG2), .RD_OUT(RD_OUT), .WR_OUT(WR_OUT), .BUF_BYTES(BUF_BYTES),
                     .ELQ(ELQ), .REORDER_OK(REORDER_OK), .CRC_ON(CRC_ON)) u_bc (
    .clk, .rst_n, .txn_start(start), .stop(stop_q), .crc_en(tx_crc_en),
    .el_valid(w_el_valid), .el_ready(w_el_ready), .el_src_asid(w_el_sa), .el_dst_asid(w_el_da), .el_src(w_el_src), .el_dst(w_el_dst),
    .el_len(w_el_len), .el_ordered(w_el_ord),
    .pr_req_valid(bc_pr_valid), .pr_req_ready(pc_req_ready[silicaflux_dma_pkg::CLI_RD]), .pr_req_asid(bc_pr_asid), .pr_req_addr(bc_pr_addr),
    .pr_req_bytes(bc_pr_bytes), .pr_rsp_valid(pc_rsp_valid[silicaflux_dma_pkg::CLI_RD]), .pr_rsp_ok(pc_rsp_ok[silicaflux_dma_pkg::CLI_RD]),
    .pr_rsp_fault(pc_rsp_fault[silicaflux_dma_pkg::CLI_RD*4 +: 4]), .pr_rsp_pa(pc_rsp_pa[silicaflux_dma_pkg::CLI_RD*AW +: AW]),
    .pw_req_valid(bc_pw_valid), .pw_req_ready(pc_req_ready[silicaflux_dma_pkg::CLI_WR]), .pw_req_asid(bc_pw_asid), .pw_req_addr(bc_pw_addr),
    .pw_req_bytes(bc_pw_bytes), .pw_rsp_valid(pc_rsp_valid[silicaflux_dma_pkg::CLI_WR]), .pw_rsp_ok(pc_rsp_ok[silicaflux_dma_pkg::CLI_WR]),
    .pw_rsp_fault(pc_rsp_fault[silicaflux_dma_pkg::CLI_WR*4 +: 4]), .pw_rsp_pa(pc_rsp_pa[silicaflux_dma_pkg::CLI_WR*AW +: AW]),
    .ar_valid(bc_ar_valid), .ar_ready(bc_ar_ready), .ar_id(bc_ar_id), .ar_asid(bc_ar_asid), .ar_addr(bc_ar_addr), .ar_len(bc_ar_len),
    .r_valid(bc_r_valid), .r_id(r_id[SW-1:0]), .r_data, .r_err, .r_last,
    .aw_valid(bc_aw_valid), .aw_ready(bc_aw_ready), .aw_id(bc_aw_id), .aw_asid(bc_aw_asid), .aw_addr(bc_aw_addr), .aw_len(bc_aw_len),
    .w_valid(bc_w_valid), .w_ready(bc_w_ready), .w_data(bc_w_data), .w_strb(bc_w_strb), .w_last(bc_w_last),
    .b_valid(bc_b_valid), .b_id(b_id[SW-1:0]), .b_err,
    .quiet(bc_quiet), .bytes_acked(bc_bytes), .crc_value(bc_crc), .progress(bc_prog),
    .err_evt(bc_err_evt), .err_code(bc_err_code), .err_fault(bc_err_fault), .err_addr(bc_err_addr), .fail(bc_fail),
    .pf_stall_ar(pf_stall_ar_c), .pf_stall_aw(pf_stall_aw_c), .pf_stall_w(pf_stall_w_c), .pf_stall_wdata, .pf_stall_full,
    .pf_stall_rslot, .pf_stall_wslot, .pf_perm_wait(pf_perm_wait_c),
    .pf_beat_rd, .pf_beat_wr, .pf_burst_rd, .pf_burst_wr, .pf_elem, .pf_bytes_rd, .pf_bytes_wr, .pf_occ_rd, .pf_occ_wr, .pf_buf_level,
    .pf_rd_lat_v, .pf_wr_lat_v, .pf_rd_lat, .pf_wr_lat, .tr_rd_v, .tr_wr_v, .tr_rd_arg, .tr_wr_arg);

  // ------------------------------------------------------------------ AR arbitration (walker vs data), grant lock
  logic ar_lock_v_q, ar_lock_w_q;
  wire  ar_sel_w = ar_lock_v_q ? ar_lock_w_q : wk_ar_valid;
  assign ar_valid  = ar_sel_w ? wk_ar_valid : bc_ar_valid;
  assign ar_id     = ar_sel_w ? {1'b1, {SW{1'b0}}} : {1'b0, bc_ar_id};
  assign ar_asid   = ar_sel_w ? wk_pc_asid : bc_ar_asid;
  assign ar_addr   = ar_sel_w ? wk_ar_addr : bc_ar_addr;
  assign ar_len    = ar_sel_w ? wk_ar_len  : bc_ar_len;
  assign ar_domain = dom_q;
  assign wk_ar_ready = ar_ready && ar_sel_w;
  assign bc_ar_ready = ar_ready && !ar_sel_w;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin ar_lock_v_q <= 1'b0; ar_lock_w_q <= 1'b0; end
    else begin
      ar_lock_v_q <= ar_valid && !ar_ready;
      ar_lock_w_q <= ar_sel_w;
    end
  end
  // R demux by class bit
  wire r_cls  = r_id[LIDW-1];
  assign wk_r_valid = r_valid && r_cls;
  assign bc_r_valid = r_valid && !r_cls;

  // ------------------------------------------------------------------ completion record writer
  logic [255:0]  rec_q;
  logic [AW-1:0] k_env_q, k_pa_q;
  logic [15:0]   k_envb_q;
  logic [LW-1:0] k_lo_q;
  logic [7:0]    k_beats_q;
  logic [7:0]    kk_q;
  logic          k_pend_b_q;                                  // record AW accepted, B not yet seen
  logic [AW-1:0] kp_env; logic [15:0] kp_envb; logic [$clog2(MAXB)+1-1:0] kp_beats; logic [LW-1:0] kp_lo;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [15:0] kp_nb;                                           // (always 32: the record is 32-byte aligned)
  /* verilator lint_on UNUSEDSIGNAL */
  sfdma_burst_plan #(.DW(DW), .AW(AW), .MAXB(MAXB), .BND_LOG2(BND_LOG2)) u_cplplan (
    .addr(tx_cpl_addr), .rem(32'd32), .env_addr(kp_env), .env_bytes(kp_envb), .beats(kp_beats), .lo(kp_lo), .nbytes(kp_nb));

  wire k_in_cpl = (c_st == C_CPL);
  wire k_pc_valid = k_in_cpl && (k_st == K_CHK);
  wire k_aw_valid = k_in_cpl && (k_st == K_AW);
  wire k_w_valid  = k_in_cpl && (k_st == K_W);
  logic [DW-1:0] k_w_data; logic [WB-1:0] k_w_strb;
  integer        kidx;
  always_comb begin
    k_w_data = '0; k_w_strb = '0; kidx = 0;
    for (int c = 0; c < WB; c++) begin
      kidx = 32'(kk_q) * WB + c - 32'(k_lo_q);
      if (kidx >= 0 && kidx < 32) begin
        k_w_data[8*c +: 8] = rec_q[8*kidx +: 8];
        k_w_strb[c] = 1'b1;
      end
    end
  end
  wire k_w_last = (32'(kk_q) + 1 == 32'(k_beats_q));

  // AW / W / B muxing: the burst controller is idle (quiet) while the record is written
  assign aw_valid  = k_in_cpl ? k_aw_valid : bc_aw_valid;
  assign aw_id     = k_in_cpl ? {1'b1, {SW{1'b0}}} : {1'b0, bc_aw_id};
  assign aw_asid   = k_in_cpl ? tx_cpl_asid : bc_aw_asid;
  assign aw_addr   = k_in_cpl ? k_pa_q : bc_aw_addr;
  assign aw_len    = k_in_cpl ? (k_beats_q - 8'd1) : bc_aw_len;
  assign aw_domain = dom_q;
  assign bc_aw_ready = aw_ready && !k_in_cpl;
  assign w_valid   = k_in_cpl ? k_w_valid : bc_w_valid;
  assign w_data    = k_in_cpl ? k_w_data : bc_w_data;
  assign w_strb    = k_in_cpl ? k_w_strb : bc_w_strb;
  assign w_last    = k_in_cpl ? k_w_last : bc_w_last;
  assign bc_w_ready = w_ready && !k_in_cpl;
  wire b_cls = b_id[LIDW-1];
  assign bc_b_valid = b_valid && !b_cls;
  wire   k_b_valid  = b_valid && b_cls;

  // ------------------------------------------------------------------ permission clients (4)
  assign pc_req_domain = dom_q;
  assign pc_req_valid  = {k_pc_valid, bc_pw_valid, bc_pr_valid, wk_pc_valid};
  assign pc_req_asid   = {tx_cpl_asid, bc_pw_asid, bc_pr_asid, wk_pc_asid};
  assign pc_req_write  = 4'b1100;                                             // bit i = client i: DESC read, RD read, WR write, CPL write
  assign pc_req_addr   = {k_env_q, bc_pw_addr, bc_pr_addr, wk_pc_addr};
  assign pc_req_bytes  = {k_envb_q, bc_pw_bytes, bc_pr_bytes, wk_pc_bytes};

  // ------------------------------------------------------------------ watchdog progress
  wire wd_prog = bc_prog || (|pc_rsp_valid) || (|(pc_req_valid & pc_req_ready)) || (wk_ar_valid && wk_ar_ready) || wk_r_valid ||
                 wk_ev_desc || (k_aw_valid && aw_ready) || (k_w_valid && w_ready) || k_b_valid;

  // ------------------------------------------------------------------ main FSM
  logic        done_v_q;
  logic [15:0] d_txn_q;
  logic [3:0]  d_status_q;
  logic        d_irq_q;
  logic        ev_cmd, ev_err_t, ev_cpl_t, ev_done_t;
  logic [7:0]  err_t_code; logic [3:0] err_t_fault;
  logic [15:0] done_lat_add;
  logic        ev_abort, ev_timeout, ev_xok, ev_xerr, ev_viol;
  wire [31:0]  tmo = timeout;

  // control events this cycle
  wire abort_now = ch_abort && (c_st == C_RUN);
  wire proto_stop = bc_err_evt && (bc_err_code == silicaflux_dma_pkg::ERR_PROTOCOL) && (c_st == C_RUN);   // the bus misbehaved: do not wait for it
  wire tmo_hit   = (tmo != 32'd0) && ((c_st == C_RUN) || (c_st == C_CPL)) && !wd_prog && (wd_q + 32'd1 >= tmo);
  // first recorded error (execution > descriptor > abort > timeout); later errors are not recorded
  logic        e_v; logic [7:0] e_code; logic [3:0] e_fault; logic [AW-1:0] e_addr;
  always_comb begin
    e_v = 1'b0; e_code = silicaflux_dma_pkg::ERR_NONE; e_fault = '0; e_addr = '0;
    if (!fail_q && ((c_st == C_RUN) || (c_st == C_CPL))) begin
      if (bc_err_evt)       begin e_v = 1'b1; e_code = bc_err_code; e_fault = bc_err_fault; e_addr = bc_err_addr; end
      else if (wk_err_evt)  begin e_v = 1'b1;                e_code = wk_err_code; e_fault = wk_err_fault; e_addr = wk_err_addr; end
      else if (abort_now)   begin e_v = 1'b1; e_code = silicaflux_dma_pkg::ERR_ABORT; end
      else if (tmo_hit)     begin e_v = 1'b1; e_code = silicaflux_dma_pkg::ERR_TIMEOUT; end
    end
  end

  wire work_idle = !wk_busy && bc_quiet && !k_pend_b_q;
  wire [3:0] fin_status = fail_q ? ((ecode_q == silicaflux_dma_pkg::ERR_ABORT) ? silicaflux_dma_pkg::ST_ABORTED : silicaflux_dma_pkg::ST_ERROR)
                                 : silicaflux_dma_pkg::ST_OK;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      c_st <= C_IDLE; k_st <= K_PLAN; dom_q <= '0; stop_q <= 1'b0; fail_q <= 1'b0; viol_q <= 1'b0; fenced_q <= 1'b0; timed_q <= 1'b0;
      ecode_q <= silicaflux_dma_pkg::ERR_NONE; efault_q <= '0; eaddr_q <= '0; lat_q <= '0; last_lat_q <= '0; wd_q <= '0;
      rec_q <= '0; k_env_q <= '0; k_pa_q <= '0; k_envb_q <= '0; k_lo_q <= '0; k_beats_q <= '0; kk_q <= '0; k_pend_b_q <= 1'b0;
      done_v_q <= 1'b0; d_txn_q <= '0; d_status_q <= '0; d_irq_q <= 1'b0;
      st_last_status <= '0; st_last_err <= '0; st_last_fault <= '0; st_last_txn <= '0; st_last_eaddr <= '0; st_last_bytes <= '0;
      st_last_crc <= '0; st_last_domain <= '0; st_last_descs <= '0; st_last_valid <= 1'b0;
      ev_cmd <= 1'b0; ev_err_t <= 1'b0; ev_cpl_t <= 1'b0; ev_done_t <= 1'b0; err_t_code <= '0; err_t_fault <= '0;
      ev_abort <= 1'b0; ev_timeout <= 1'b0; ev_xok <= 1'b0; ev_xerr <= 1'b0; ev_viol <= 1'b0; done_lat_add <= '0; viol_evt <= 1'b0;
      proto_evt <= 1'b0;
    end else begin
      ev_cmd <= 1'b0; ev_err_t <= 1'b0; ev_cpl_t <= 1'b0; ev_done_t <= 1'b0; ev_abort <= 1'b0; ev_timeout <= 1'b0;
      ev_xok <= 1'b0; ev_xerr <= 1'b0; ev_viol <= 1'b0; viol_evt <= 1'b0; done_lat_add <= '0; proto_evt <= 1'b0;
      // late-response bookkeeping of the completion record
      if (k_b_valid && !k_in_cpl) begin k_pend_b_q <= 1'b0; proto_evt <= !k_pend_b_q; end
      // fence clears when every outstanding response is back
      if (fenced_q && work_idle) fenced_q <= 1'b0;
      // watchdog
      if (wd_prog || !((c_st == C_RUN) || (c_st == C_CPL))) wd_q <= 32'd0; else wd_q <= wd_q + 32'd1;
      if ((c_st == C_RUN) || (c_st == C_FIN) || (c_st == C_CPL)) lat_q <= (lat_q == 16'hFFFF) ? lat_q : lat_q + 16'd1;
      // error latch / control events
      if (e_v) begin
        fail_q <= 1'b1; ecode_q <= e_code; efault_q <= e_fault; eaddr_q <= e_addr;
        ev_err_t <= 1'b1; err_t_code <= e_code; err_t_fault <= e_fault;
        if (silicaflux_dma_pkg::err_is_violation(e_code)) viol_q <= 1'b1;
      end
      if ((bc_err_evt || abort_now) && ((c_st == C_RUN) || (c_st == C_CPL))) stop_q <= 1'b1;   // stop even if an earlier error is already recorded
      if (abort_now) ev_abort <= 1'b1;
      if (tmo_hit) begin ev_timeout <= 1'b1; stop_q <= 1'b1; timed_q <= 1'b1; fenced_q <= 1'b1; end
      if (proto_stop) begin stop_q <= 1'b1; timed_q <= 1'b1; fenced_q <= 1'b1; end     // report now, no record, channel fenced

      case (c_st)
        C_IDLE: begin
          if (start) begin
            dom_q <= q_dom; stop_q <= 1'b0; fail_q <= 1'b0; viol_q <= 1'b0; timed_q <= 1'b0; ecode_q <= silicaflux_dma_pkg::ERR_NONE;
            efault_q <= '0; eaddr_q <= '0; lat_q <= 16'd0; wd_q <= 32'd0;
            ev_cmd <= 1'b1; c_st <= C_RUN;
          end
        end
        C_RUN: begin
          if (tmo_hit || proto_stop) c_st <= C_FIN;                    // timeout / protocol error: report now, no record, channel fenced
          else if (work_idle) c_st <= C_FIN;
        end
        C_FIN: begin
          // build the record and the completion event (one cycle; every input is stable: nothing is outstanding)
          last_lat_q <= lat_q;
          rec_q <= '0;
          rec_q[silicaflux_dma_pkg::CPLR_STATUS_LSB +: 4]  <= fin_status;
          rec_q[silicaflux_dma_pkg::CPLR_FAULT_LSB  +: 4]  <= efault_q;
          rec_q[silicaflux_dma_pkg::CPLR_ERR_LSB    +: 8]  <= ecode_q;
          rec_q[silicaflux_dma_pkg::CPLR_TXN_LSB    +: 16] <= tx_txn;
          rec_q[silicaflux_dma_pkg::CPLR_DOM_LSB    +: 16] <= 16'(dom_q);
          rec_q[silicaflux_dma_pkg::CPLR_DESCS_LSB  +: 16] <= wk_descs;
          rec_q[silicaflux_dma_pkg::CPLR_BYTES_LSB  +: 32] <= bc_bytes;
          rec_q[silicaflux_dma_pkg::CPLR_CRC_LSB    +: 32] <= bc_crc;
          rec_q[silicaflux_dma_pkg::CPLR_EADDR_LSB  +: 64] <= 64'(eaddr_q);
          rec_q[silicaflux_dma_pkg::CPLR_LAT_LSB    +: 32] <= 32'(lat_q);
          rec_q[silicaflux_dma_pkg::CPLR_FLAGS_LSB + silicaflux_dma_pkg::CPLF_CRC_VALID] <= tx_crc_en && !fail_q && CRC_ON;
          rec_q[silicaflux_dma_pkg::CPLR_FLAGS_LSB + silicaflux_dma_pkg::CPLF_COMMITTED] <= !fail_q;
          rec_q[silicaflux_dma_pkg::CPLR_FLAGS_LSB + silicaflux_dma_pkg::CPLF_VIOLATION] <= viol_q;
          rec_q[silicaflux_dma_pkg::CPLR_MAGIC_LSB  +: 16] <= silicaflux_dma_pkg::CPL_MAGIC;
          k_env_q <= kp_env; k_envb_q <= kp_envb; k_lo_q <= kp_lo; k_beats_q <= 8'(kp_beats);
          if (tx_cpl_en && !timed_q) begin c_st <= C_CPL; k_st <= K_CHK; kk_q <= '0; end
          else begin c_st <= C_DONE; end
        end
        C_CPL: begin
          case (k_st)
            K_CHK:  if (pc_req_ready[silicaflux_dma_pkg::CLI_CPL]) k_st <= K_CHKW;
            K_CHKW: if (pc_rsp_valid[silicaflux_dma_pkg::CLI_CPL]) begin
              if (!pc_rsp_ok[silicaflux_dma_pkg::CLI_CPL]) begin
                if (!fail_q) begin fail_q <= 1'b1; ecode_q <= silicaflux_dma_pkg::ERR_PERM_CPL; efault_q <= pc_rsp_fault[silicaflux_dma_pkg::CLI_CPL*4 +: 4];
                                   eaddr_q <= tx_cpl_addr; ev_err_t <= 1'b1; err_t_code <= silicaflux_dma_pkg::ERR_PERM_CPL;
                                   err_t_fault <= pc_rsp_fault[silicaflux_dma_pkg::CLI_CPL*4 +: 4]; viol_q <= 1'b1; end
                c_st <= C_DONE;
              end else begin k_pa_q <= pc_rsp_pa[silicaflux_dma_pkg::CLI_CPL*AW +: AW]; k_st <= K_AW; end
            end
            K_AW: if (aw_ready) begin k_st <= K_W; kk_q <= '0; k_pend_b_q <= 1'b1; end
            K_W:  if (w_ready) begin
              if (k_w_last) k_st <= K_B; else kk_q <= kk_q + 8'd1;
            end
            K_B:  if (k_b_valid) begin
              k_pend_b_q <= 1'b0;
              if (b_err) begin
                if (!fail_q) begin fail_q <= 1'b1; ecode_q <= silicaflux_dma_pkg::ERR_BUS_CPL; eaddr_q <= tx_cpl_addr; ev_err_t <= 1'b1;
                                   err_t_code <= silicaflux_dma_pkg::ERR_BUS_CPL; err_t_fault <= '0; end
              end
              ev_cpl_t <= 1'b1; c_st <= C_DONE;
            end
            default: k_st <= K_PLAN;
          endcase
          if (tmo_hit) c_st <= C_DONE;                                                   // record phase stalled: report, channel fenced
        end
        C_DONE: begin
          if (!done_v_q) begin
            done_v_q <= 1'b1; d_txn_q <= tx_txn; d_status_q <= fail_q ? ((ecode_q == silicaflux_dma_pkg::ERR_ABORT) ? silicaflux_dma_pkg::ST_ABORTED : silicaflux_dma_pkg::ST_ERROR) : silicaflux_dma_pkg::ST_OK;
            d_irq_q <= tx_irq_en;
            st_last_status <= fail_q ? ((ecode_q == silicaflux_dma_pkg::ERR_ABORT) ? silicaflux_dma_pkg::ST_ABORTED : silicaflux_dma_pkg::ST_ERROR) : silicaflux_dma_pkg::ST_OK;
            st_last_err <= ecode_q; st_last_fault <= efault_q; st_last_txn <= tx_txn; st_last_eaddr <= eaddr_q;
            st_last_bytes <= bc_bytes; st_last_crc <= bc_crc; st_last_domain <= dom_q; st_last_descs <= wk_descs; st_last_valid <= 1'b1;
            ev_done_t <= 1'b1; ev_xok <= !fail_q; ev_xerr <= fail_q; ev_viol <= viol_q; viol_evt <= viol_q;
            done_lat_add <= last_lat_q;
          end else if (done_ready) begin
            done_v_q <= 1'b0; c_st <= C_IDLE;
          end
        end
        default: c_st <= C_IDLE;
      endcase
    end
  end

  assign done_valid  = done_v_q;
  assign done_txn    = d_txn_q;
  assign done_status = d_status_q;
  assign done_err    = st_last_err;
  assign done_fault  = st_last_fault;
  assign done_domain = st_last_domain;
  assign done_bytes  = st_last_bytes;
  assign done_crc    = st_last_crc;
  assign done_irq    = d_irq_q;
  assign st_busy     = (c_st != C_IDLE);
  assign st_fenced   = fenced_q;

  // ------------------------------------------------------------------ performance adds, watermarks, trace
  wire [15:0] n_perm_pend = 16'(bc_pr_valid) + 16'(bc_pw_valid) + 16'(wk_wait_perm) + 16'(k_in_cpl && (k_st == K_CHK || k_st == K_CHKW));
  function automatic logic [15:0] pop4(input logic [3:0] v);
    pop4 = 16'(v[0]) + 16'(v[1]) + 16'(v[2]) + 16'(v[3]);
  endfunction
  wire [15:0] n_perm_acc  = pop4(pc_req_valid & pc_req_ready);
  wire [15:0] n_perm_deny = pop4(pc_rsp_valid & ~pc_rsp_ok);
  wire [15:0] n_perm_wait_c = 16'(pf_perm_wait_c || wk_wait_perm || (k_in_cpl && (k_st == K_CHK || k_st == K_CHKW)));
  always_comb begin
    pf_add = '0;
    pf_add[16*silicaflux_dma_pkg::PC_ACTIVE      +: 16] = 16'(c_st != C_IDLE);
    pf_add[16*silicaflux_dma_pkg::PC_STALL_AR    +: 16] = 16'(ar_valid && !ar_ready);
    pf_add[16*silicaflux_dma_pkg::PC_STALL_AW    +: 16] = 16'(aw_valid && !aw_ready);
    pf_add[16*silicaflux_dma_pkg::PC_STALL_W     +: 16] = 16'(w_valid && !w_ready);
    pf_add[16*silicaflux_dma_pkg::PC_STALL_WDATA +: 16] = 16'(pf_stall_wdata);
    pf_add[16*silicaflux_dma_pkg::PC_STALL_FULL  +: 16] = 16'(pf_stall_full);
    pf_add[16*silicaflux_dma_pkg::PC_STALL_RSLOT +: 16] = 16'(pf_stall_rslot);
    pf_add[16*silicaflux_dma_pkg::PC_STALL_WSLOT +: 16] = 16'(pf_stall_wslot);
    pf_add[16*silicaflux_dma_pkg::PC_PERM_WAIT   +: 16] = n_perm_wait_c;
    pf_add[16*silicaflux_dma_pkg::PC_BYTES_RD    +: 16] = pf_bytes_rd;
    pf_add[16*silicaflux_dma_pkg::PC_BYTES_WR    +: 16] = pf_bytes_wr;
    pf_add[16*silicaflux_dma_pkg::PC_BEATS_RD    +: 16] = 16'(pf_beat_rd);
    pf_add[16*silicaflux_dma_pkg::PC_BEATS_WR    +: 16] = 16'(pf_beat_wr);
    pf_add[16*silicaflux_dma_pkg::PC_BURSTS_RD   +: 16] = 16'(pf_burst_rd);
    pf_add[16*silicaflux_dma_pkg::PC_BURSTS_WR   +: 16] = 16'(pf_burst_wr);
    pf_add[16*silicaflux_dma_pkg::PC_OCC_RD      +: 16] = 16'(pf_occ_rd);
    pf_add[16*silicaflux_dma_pkg::PC_OCC_WR      +: 16] = 16'(pf_occ_wr);
    pf_add[16*silicaflux_dma_pkg::PC_OCC_BUF     +: 16] = pf_buf_level >> 3;
    pf_add[16*silicaflux_dma_pkg::PC_XACT_OK     +: 16] = 16'(ev_xok);
    pf_add[16*silicaflux_dma_pkg::PC_XACT_ERR    +: 16] = 16'(ev_xerr);
    pf_add[16*silicaflux_dma_pkg::PC_LAT_SUM     +: 16] = done_lat_add;
    pf_add[16*silicaflux_dma_pkg::PC_DESC_FETCH  +: 16] = 16'(wk_ev_desc);
    pf_add[16*silicaflux_dma_pkg::PC_DESC_LAT    +: 16] = wk_ev_desc ? wk_desc_lat : 16'd0;
    pf_add[16*silicaflux_dma_pkg::PC_PERM_REQ    +: 16] = n_perm_acc;
    pf_add[16*silicaflux_dma_pkg::PC_PERM_LAT    +: 16] = n_perm_pend;
    pf_add[16*silicaflux_dma_pkg::PC_PERM_DENY   +: 16] = n_perm_deny;
    pf_add[16*silicaflux_dma_pkg::PC_VIOL        +: 16] = 16'(ev_viol);
    pf_add[16*silicaflux_dma_pkg::PC_RD_LAT      +: 16] = pf_rd_lat_v ? pf_rd_lat : 16'd0;
    pf_add[16*silicaflux_dma_pkg::PC_TIMEOUTS    +: 16] = 16'(ev_timeout);
    pf_add[16*silicaflux_dma_pkg::PC_ABORTS      +: 16] = 16'(ev_abort);
    pf_add[16*silicaflux_dma_pkg::PC_ELEMS       +: 16] = 16'(pf_elem);
    pf_add[16*silicaflux_dma_pkg::PC_WR_LAT      +: 16] = pf_wr_lat_v ? pf_wr_lat : 16'd0;
  end
  assign pm_val = {pf_buf_level, 8'd0, pf_occ_wr, 8'd0, pf_occ_rd, ev_done_t ? last_lat_q : 16'd0};

  assign tr_txn = tx_txn;
  always_comb begin
    tr_v = '0; tr_code = '0; tr_arg = '0;
    // source 0: channel events
    if (ev_cmd)        begin tr_v[0] = 1'b1; tr_code[7:0] = silicaflux_dma_pkg::TR_CMD;  tr_arg[31:0] = q_head[31:0]; end
    else if (ev_err_t) begin tr_v[0] = 1'b1; tr_code[7:0] = silicaflux_dma_pkg::TR_ERROR; tr_arg[31:0] = {20'd0, err_t_fault, err_t_code}; end
    else if (ev_cpl_t) begin tr_v[0] = 1'b1; tr_code[7:0] = silicaflux_dma_pkg::TR_CPL_WR; tr_arg[31:0] = {28'd0, fin_status}; end
    else if (ev_done_t) begin tr_v[0] = 1'b1; tr_code[7:0] = silicaflux_dma_pkg::TR_DONE; tr_arg[31:0] = st_last_bytes; end
    // source 1: walker
    tr_v[1] = wk_ev_desc; tr_code[15:8] = silicaflux_dma_pkg::TR_DESC; tr_arg[63:32] = wk_desc_arg;
    // source 2 / 3: burst issue
    tr_v[2] = tr_rd_v; tr_code[23:16] = silicaflux_dma_pkg::TR_RD_ISSUE; tr_arg[95:64]  = tr_rd_arg;
    tr_v[3] = tr_wr_v; tr_code[31:24] = silicaflux_dma_pkg::TR_WR_ISSUE; tr_arg[127:96] = tr_wr_arg;
  end
endmodule

`default_nettype wire
