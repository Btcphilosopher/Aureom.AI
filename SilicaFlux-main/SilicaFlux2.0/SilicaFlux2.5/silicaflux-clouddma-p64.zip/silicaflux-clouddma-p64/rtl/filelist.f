# Synthesizable RTL, in dependency order (paths relative to the project root)
rtl/lint.vlt
rtl/silicaflux_dma_pkg.sv
third_party/p61-clouddpu/rtl/sfd_fifo.sv
third_party/p61-clouddpu/rtl/sfd_rr_arb.sv
rtl/sfdma_burst_plan.sv
rtl/sfdma_bytebuf.sv
rtl/sfdma_crc.sv
rtl/sfdma_perm_table.sv
rtl/sfdma_perm_checker.sv
rtl/sfdma_desc_walker.sv
rtl/sfdma_burst_ctrl.sv
rtl/sfdma_channel.sv
rtl/sfdma_perf.sv
rtl/sfdma_trace.sv
rtl/sfdma_csr.sv
rtl/sfdma_axi_mux.sv
rtl/silicaflux_cloud_dma.sv
