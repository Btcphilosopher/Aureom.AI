# SilicaFlux CloudDMA — Project 64: protected scatter-gather data-movement engine

`rtl/silicaflux_cloud_dma.sv` is the top level. A descriptor-driven DMA engine for SilicaFlux CloudDPU: it fetches a
chain of descriptors, validates them, **checks every memory transaction against a permission checker before it is issued**,
moves the data through an internal buffer with a configurable AXI4 burst engine, and signals completion **only after the
destination writes have been acknowledged**. Single-channel baseline first; the multichannel build (`NUM_CH > 1`) was
added only after the baseline passed all tests.

> **Evidence level: simulation only.** Verilator 5.020 simulation (system testbench with a byte-accurate scoreboard,
> unit benches, a mutation campaign) and Yosys 0.33 *generic* synthesis (cell counts, no PDK). **No FPGA, place-and-route,
> timing, area (µm²), power or silicon result exists and none is claimed.** No formal proof was done. Read
> [`docs/08_LIMITATIONS.md`](docs/08_LIMITATIONS.md) before relying on anything here.

## Results (reproducible with `make`; reports in `reports/`)

| Check | Result | Where |
|---|---|---|
| Lint: Verilator `-Wall`, 8 configurations; 12 illegal parameter sets must be refused at elaboration | 0 warnings; 12/12 refused | `reports/lint.md` |
| Unit benches (burst planner *exhaustive*, byte buffer, CRC incl. the published check value, permission table vs a 64-bit reference, package layout) | all pass | `reports/unit/` |
| **Baseline** (single channel) system regression: 15 configurations × 3 seeds — widths 32…512, one-outstanding minimum buffer, in-order bus, slow pipelined IOMMU, deep queues, 40/64-bit addresses, external-IOMMU interface, negative test | **15/15 pass, 45/45 runs** | `reports/regression.md` |
| **Multichannel** regression (run only after the baseline passed): 2 ch, 4 ch, 4 ch 128-bit pipelined checker, 2 ch in-order | 4/4 pass, 12/12 runs | `reports/regression_multi.md` |
| Mutation campaign: 29 injected RTL bugs, each must make the testbench fail | **29/29 killed** (the first run had 3 survivors — all testbench holes, now closed; docs/05 §4) | `reports/mutation.md` |
| Generic Yosys synthesis, 6 configurations | 0 check problems, 0 latches; default 256 865 generic cells / 19 298 flops | `reports/synth/`, `docs/07` |
| Performance (simulation cycles) | large copies 7.96 B/cycle against the memory port's 8 B/cycle ceiling (99.5 %); 128 KiB scatter-gather of 64 descriptors 7.73; latency-bound 256-byte transactions 2.03 B/cycle, 5.97 with 4 channels | `reports/performance.md`, `docs/06` |

Each regression run applies the full suite to a byte-accurate scoreboard (22–39 million checks per configuration for three seeds) and several monitors (AXI4 protocol, unauthorised-access, completion-before-acknowledge). **Defects found by the
process** (docs/05 §5): two RTL bugs (a pending AW whose ID could change; a hang after a protocol error),
a soft-reset bug that only the 2-channel build exposed (the AXI multiplexer was not reset), two RTL hardening changes, and
three testbench holes found by the mutation campaign (the `ORDERED` barrier could be deleted unnoticed; one reorder check
masked another; one mutant was built in a configuration that could not reach it).

Not done and not claimed: formal proof, FPGA/ASIC flow, timing/area/power, cross-simulator confirmation, an SRAM-macro
data buffer, descriptor prefetch across commands (docs/08).

## What is in the box

| Brief deliverable | File |
|---|---|
| `silicaflux_cloud_dma.sv` (top) | `rtl/silicaflux_cloud_dma.sv` |
| descriptor package | `rtl/silicaflux_dma_pkg.sv` (layouts, flags, error/fault codes, CSR map, counter ids) · format: `docs/02_DESCRIPTOR_FORMAT.md` |
| descriptor walker | `rtl/sfdma_desc_walker.sv` |
| burst controller | `rtl/sfdma_burst_ctrl.sv` (+ `sfdma_burst_plan.sv`, `sfdma_bytebuf.sv`, `sfdma_crc.sv`) |
| permission checker | `rtl/sfdma_perm_checker.sv` (+ `sfdma_perm_table.sv`, the simulation IOMMU model) |
| channel, AXI multiplexer, CSR, counters, trace | `rtl/sfdma_channel.sv`, `sfdma_axi_mux.sv`, `sfdma_csr.sv`, `sfdma_perf.sv`, `sfdma_trace.sv` |
| DMA testbench | `tb/` (system testbench `tb_dma_sys.sv` + `tb_*.svh`, five unit benches) |
| synthesis scripts | `synth/synth_dma.ys.tmpl`, `scripts/synth.sh`, `synth_all.sh`, `synth_modules.sh` |
| integration documentation | `docs/04_INTEGRATION.md` (+ `docs/03_PROTECTION.md` for the IOMMU interface) |

```
README.md  Makefile  MANIFEST.sha256 (SHA-256 of every shipped source, script and doc: `sha256sum -c MANIFEST.sha256`)
rtl/        synthesizable RTL (filelist.f in dependency order, lint.vlt waivers)
tb/         testbenches
scripts/    regress.py  mutate.py  perf_sweep.py  perf_report.py  lint.sh  run_unit.sh  synth*.sh  check_vendor.py  tools.sh
synth/      Yosys script template
third_party/  5 vendored files from the repository (byte-identical, hashed; PROVENANCE.md)
docs/       00 audit · 01 architecture · 02 descriptor format · 03 protection · 04 integration
            05 verification · 06 performance · 07 synthesis · 08 limitations
reports/    generated: regression, regression_multi, lint, unit/, mutation, performance(.csv/.md), synth/ (summary, stat, per-module;
            the multi-megabyte Yosys logs are not shipped), tools.txt
```

## How the brief's points are met (short form — each links to the evidence)

1. **Audit** of existing DMA / DataFabric / SRAM / host / VirtIO / IOMMU / StorageCore / counters: `docs/00_AUDIT.md`.
   Three small modules were reused (vendored, hashed); everything else is new, with reasons.
2. **Pipeline** Descriptor Fetch → Validation → Address Permission Check → Read → Buffer → Write → Completion:
   `docs/01_ARCHITECTURE.md`.
3. **Descriptor** (64 B, versioned, little-endian, explicit alignment and limits), **scatter-gather** (linked or array,
   non-contiguous, partial first/last beats, chain/total limits, cycle detection, 65-bit overflow-free arithmetic,
   valid-prefix semantics): `docs/02_DESCRIPTOR_FORMAT.md`.
4. **Isolation before every transaction** — domain, range, R/W permission, translation result, length — through a real
   IOMMU interface or a verified simulation permission table; the bus address *is* the checker's answer; the domain is
   bound by hardware at the command port, the descriptor's domain is only a claim: `docs/03_PROTECTION.md`.
5. **Burst engine** (data width 32–512, burst size, outstanding reads/writes, FIFO/buffer depth, 4 KiB rule, optional
   response reordering across IDs), **completion after acknowledgement**, defined cancellation/timeout/reset
   behaviour, optional CRC-32 (accidental-error check, not cryptographic), error propagation, trace:
   `docs/01_ARCHITECTURE.md` §3–§6.
6. **Performance counters and sweeps** (bytes/cycle, active and stall cycles, queue occupancy, burst utilisation,
   latency, permission overhead, contention): `docs/06_PERFORMANCE.md`.
7. **Verification** (zero length, single byte, unaligned tails, multi-segment, long, concurrent read/write, back-pressure,
   reordered responses, domain violations, invalid descriptors, timeouts, reset, completion ordering; byte-accurate
   scoreboard; mutation testing): `docs/05_VERIFICATION.md`.
8. **Definition of done** — arbitrary *supported* scatter-gather transfers without loss, duplication or unauthorised
   access: demonstrated *in simulation* by the scoreboard (every byte of every transaction written exactly once, with
   the right value, to the right place, inside memory the bound domain may access) over the matrix above. "Supported" is
   defined by the limits in `docs/02` and `docs/08`; it is not a proof for all inputs.

## Reproduce

Tools (Ubuntu 24.04 packages): `verilator` 5.020, `yosys` 0.33, `python3`; `iverilog` is optional and unused by the flow.
Exact versions used: `reports/tools.txt`.

```
make check-vendor    # third_party/ is byte-identical to its recorded SHA-256s
make lint            # Verilator -Wall, 8 configurations + 12 negative elaboration tests
make unit            # unit benches
make regress         # baseline matrix then multichannel matrix, 3 seeds each   (tens of minutes)
make mutate          # 29 injected RTL bugs, each must be killed                 (tens of minutes)
make perf            # performance sweeps (reports/performance.md)               (tens of minutes)
make synth           # generic Yosys synthesis, 6 configurations (reports/synth/)  (about 5 min each)
```

Single run of the default system test: `python3 scripts/regress.py --configs base --seeds 1`.
The testbench is built at `-O0`; each configuration takes roughly 15–60 s to compile and a full-suite simulation of one
seed takes on the order of 10–20 s.

## Things to know before integrating

* The permission table (`sfdma_perm_table`) is a **model** of an IOMMU contract for simulation and bring-up; real
  isolation needs a real IOMMU on the DMA's only path to memory, a hardware-bound `cmd_domain`, and privileged
  access to the CSR window (`docs/03` §5, `docs/04` §4).
* A real IOMMU must accept several requests at once (`PERM_OUT > 1`) if it has tens of cycles of latency, otherwise the
  engine runs at a fraction of the bus rate (`docs/06` §6).
* Completion means "the B response of every destination write was received" — as strong as the interconnect's meaning of B.
* No AXI4 → SFB2 slave adapter exists in the repository; local SRAM behind SFB2 needs one (`docs/00`, `docs/08`).
* The vendored files carry no license (none exists in the source repository); an owner must decide before distribution.

## Provenance

Built from scratch in an isolated scratch directory against the audited repository `btcphilosopher/Aureom.AI` (HEAD
`75371f0`). **Nothing was committed or pushed** and no pull request was created; this archive is the deliverable.
