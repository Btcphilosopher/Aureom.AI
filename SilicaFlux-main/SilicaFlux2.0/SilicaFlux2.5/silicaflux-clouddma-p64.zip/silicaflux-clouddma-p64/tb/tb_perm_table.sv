// Unit bench: sfdma_perm_table vs a 64-bit-arithmetic reference model; random entry programming (including illegal
// entries, which must be refused and leave the table unchanged), random requests, exact latency, in-order responses,
// held response under back-pressure.
`timescale 1ns/1ps
module tb_perm_table #(parameter int LAT = 2);
  localparam int AW = 20, DOM_W = 3, IDW = 5, NENT = 8, EW = 3;
  logic clk = 0; always #5 clk = ~clk;
  logic rst_n = 0;
  logic tw_en = 0; logic [EW-1:0] tw_idx = 0; logic tw_valid = 0; logic [DOM_W-1:0] tw_domain = 0; logic [3:0] tw_asid = 0;
  logic [AW-1:0] tw_base = 0; logic [AW:0] tw_size = 0; logic [AW-1:0] tw_pa = 0; logic [1:0] tw_perm = 0;
  logic tw_rej; logic [31:0] rej_count;
  logic req_valid = 0, req_ready; logic [DOM_W-1:0] req_domain = 0; logic [3:0] req_asid = 0; logic req_write = 0;
  logic [AW-1:0] req_addr = 0; logic [15:0] req_bytes = 0; logic [IDW-1:0] req_id = 0;
  logic rsp_valid; logic rsp_ready = 1; logic [IDW-1:0] rsp_id; logic rsp_ok; logic [3:0] rsp_fault; logic [AW-1:0] rsp_pa;
  sfdma_perm_table #(.AW(AW), .DOM_W(DOM_W), .IDW(IDW), .NENT(NENT), .LAT(LAT)) dut (.*);

  // reference
  bit      r_v   [NENT]; int r_dom [NENT]; int r_asid [NENT];
  longint  r_base[NENT]; longint r_size[NENT]; longint r_pa[NENT]; int r_perm[NENT];
  int errors = 0, checks = 0, exp_rej = 0;
  int cov [8];

  function automatic void ref_lookup(input int dom, input int asid, input bit wr, input longint addr, input int bytes,
                                     output bit ok, output int fault, output longint pa);
    bit any_perm = 0, any_range = 0, any_dom = 0, hit = 0;
    ok = 0; fault = 0; pa = 0;
    for (int e = 0; e < NENT; e++) if (r_v[e]) begin
      bit starts_in, in_rng, pok;
      starts_in = (addr >= r_base[e]) && (addr < r_base[e] + r_size[e]);
      in_rng    = starts_in && (addr + bytes <= r_base[e] + r_size[e]);
      pok       = wr ? ((r_perm[e] & 2) != 0) : ((r_perm[e] & 1) != 0);
      if (r_dom[e] == dom && r_asid[e] == asid) begin
        if (in_rng && pok && !hit) begin hit = 1; pa = r_pa[e] + (addr - r_base[e]); end
        if (in_rng && !pok) any_perm = 1;
        if (starts_in && !in_rng) any_range = 1;
      end else if (r_asid[e] == asid && starts_in) any_dom = 1;
    end
    ok = hit;
    fault = hit ? 0 : any_perm ? 2 : any_range ? 4 : any_dom ? 3 : 1;
    if (!hit) pa = 0;
  endfunction

  task automatic program_entry();
    int idx, dom, asid, perm; longint base, size, pa; bit legal; bit valid;
    idx = $urandom_range(NENT-1, 0); dom = $urandom_range(3, 0); asid = $urandom_range(2, 0);
    perm = $urandom_range(3, 0);
    base = 4096 * $urandom_range(255, 0); size = 4096 * $urandom_range(40, 0); pa = 4096 * $urandom_range(255, 0);
    valid = ($urandom_range(9, 0) != 0);
    if ($urandom_range(5, 0) == 0) begin   // deliberately illegal variants
      case ($urandom_range(3, 0))
        0: base += $urandom_range(4095, 1);
        1: size = 0;
        2: size = (1 << AW) - base + 4096;       // runs past 2**AW
        default: pa += $urandom_range(4095, 1);
      endcase
    end
    legal = ((base % 4096) == 0) && ((pa % 4096) == 0) && ((size % 4096) == 0) && size > 0 &&
            (base + size <= (1 << AW)) && (pa + size <= (1 << AW));
    @(negedge clk);
    tw_en = 1; tw_idx = EW'(idx); tw_valid = valid; tw_domain = DOM_W'(dom); tw_asid = 4'(asid);
    tw_base = AW'(base); tw_size = (AW+1)'(size); tw_pa = AW'(pa); tw_perm = 2'(perm);
    @(negedge clk); tw_en = 0;
    if (!valid) r_v[idx] = 0;
    else if (legal) begin r_v[idx] = 1; r_dom[idx] = dom; r_asid[idx] = asid; r_base[idx] = base; r_size[idx] = size; r_pa[idx] = pa; r_perm[idx] = perm; end
    else exp_rej++;
    // tw_rej is a registered pulse visible after the write edge
    checks++;
    if (valid && !legal && tw_rej !== 1'b1) begin errors++; $display("illegal entry accepted (idx %0d base %0h size %0h pa %0h)", idx, base, size, pa); end
    if ((!valid || legal) && tw_rej !== 1'b0) begin errors++; $display("legal write refused"); end
  endtask

  // expected response queue
  typedef struct packed { logic [IDW-1:0] id; logic ok; logic [3:0] fault; logic [AW-1:0] pa; } exp_t;
  exp_t expq [$];
  int cyc = 0; int acc_cycle [$];
  always @(posedge clk) cyc <= cyc + 1;

  // response monitor (and hold-stable check under back-pressure)
  logic [IDW+1+4+AW-1:0] prev; bit prev_held = 0;
  always @(posedge clk) if (rst_n) begin
    if (prev_held && !(rsp_valid && {rsp_id, rsp_ok, rsp_fault, rsp_pa} === prev)) begin errors++; $display("response not held stable"); end
    prev_held <= rsp_valid && !rsp_ready; prev <= {rsp_id, rsp_ok, rsp_fault, rsp_pa};
    if (rsp_valid && rsp_ready) begin
      exp_t e; int c0;
      checks++;
      if (expq.size() == 0) begin errors++; $display("unexpected response"); end
      else begin
        e = expq.pop_front(); c0 = acc_cycle.pop_front();
        if ({rsp_id, rsp_ok, rsp_fault, rsp_pa} !== e) begin errors++; if (errors < 8) $display("resp mismatch got id=%0d ok=%b f=%0d pa=%h exp id=%0d ok=%b f=%0d pa=%h", rsp_id, rsp_ok, rsp_fault, rsp_pa, e.id, e.ok, e.fault, e.pa); end
      end
    end
  end

  initial begin
    for (int i = 0; i < 8; i++) cov[i] = 0;
    for (int e = 0; e < NENT; e++) begin r_v[e] = 0; r_dom[e] = 0; r_asid[e] = 0; r_base[e] = 0; r_size[e] = 0; r_pa[e] = 0; r_perm[e] = 0; end
    repeat (3) @(negedge clk); rst_n = 1;
    for (int round = 0; round < 60; round++) begin
      for (int k = 0; k < 6; k++) program_entry();
      for (int q = 0; q < 300; q++) begin
        int dom, asid, bytes; bit wr; longint addr, seg; bit ok; int fault; longint pa; exp_t e;
        dom = $urandom_range(4, 0); asid = $urandom_range(3, 0); wr = $urandom_range(1, 0);
        // bias requests towards mapped regions: pick a VALID entry, mostly its own domain/asid, offset inside / near an edge
        begin
          int ei, tries; ei = -1;
          for (tries = 0; tries < 8 && ei < 0; tries++) begin int c; c = $urandom_range(NENT-1, 0); if (r_v[c]) ei = c; end
          if (ei >= 0 && $urandom_range(9, 0) < 8) begin
            if ($urandom_range(9, 0) < 7) begin dom = r_dom[ei]; asid = r_asid[ei]; end
            case ($urandom_range(3, 0))
              0: addr = r_base[ei] + $urandom_range(int'(r_size[ei]) - 1, 0);
              1: addr = r_base[ei] + r_size[ei] - $urandom_range(300, 1);      // near the end: straddles
              2: addr = r_base[ei] - $urandom_range(300, 1);                    // just before the base
              default: addr = r_base[ei] + 4096 * $urandom_range(int'(r_size[ei] / 4096) - 1, 0) + $urandom_range(4095, 0);
            endcase
            if (addr < 0) addr = 0;
          end else addr = $urandom_range((1 << AW) - 1, 0);
        end
        bytes = $urandom_range(4096, 1);
        if ($urandom_range(1, 0)) begin   // contract case: stay inside one 4 KiB page
          seg = 4096 - (addr % 4096); if (bytes > seg) bytes = int'(seg);
        end
        if (addr + bytes > (1 << AW)) bytes = int'((1 << AW) - addr);
        if (bytes < 1) begin addr = 0; bytes = 1; end
        ref_lookup(dom, asid, wr, addr, bytes, ok, fault, pa);
        cov[ok ? 0 : fault]++;
        e.id = IDW'($urandom); e.ok = ok; e.fault = 4'(fault); e.pa = AW'(pa);
        // drive, wait until accepted (req_ready low only when stalled by back-pressure)
        @(negedge clk);
        req_valid = 1; req_domain = DOM_W'(dom); req_asid = 4'(asid); req_write = wr; req_addr = AW'(addr); req_bytes = 16'(bytes); req_id = e.id;
        rsp_ready = ($urandom_range(3, 0) != 0); #1;
        while (!req_ready) begin @(negedge clk); rsp_ready = ($urandom_range(3, 0) != 0); #1; end
        expq.push_back(e); acc_cycle.push_back(cyc);
        @(posedge clk); #1; req_valid = 0;
        if ($urandom_range(2, 0) == 0) begin repeat ($urandom_range(3, 0)) @(negedge clk); end
      end
    end
    // drain
    rsp_ready = 1; repeat (20) @(negedge clk);
    checks++; if (expq.size() != 0) begin errors++; $display("responses missing: %0d", expq.size()); end
    checks++; if (rej_count !== 32'(exp_rej)) begin errors++; $display("rej_count %0d != expected %0d", rej_count, exp_rej); end
    $display("coverage of verdicts: ok=%0d no_map=%0d perm=%0d domain=%0d range=%0d", cov[0], cov[1], cov[2], cov[3], cov[4]);
    $display("tb_perm_table LAT=%0d: checks=%0d errors=%0d (refused entry writes: %0d)", LAT, checks, errors, exp_rej);
    if (errors == 0) $display("TB RESULT PASS"); else $display("TB RESULT FAIL");
    $finish;
  end
endmodule
