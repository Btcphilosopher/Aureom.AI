// ============================================================================
// tb_slave.svh -- behavioural AXI4 slave with an 18 MiB memory image.
//
// All outputs are registered at posedge (sample DUT outputs pre-edge, drive with NBA): race free.
// Behaviour knobs (set by the tests):
//   cfg_*_p        ready / valid probabilities in percent       cfg_lat_*  read latency range   cfg_b_*  write-response delay range
//   cfg_reorder    responses may leave in any order across IDs (reads: also per-beat interleave if cfg_interleave)
//   cfg_r_inorder / cfg_b_inorder   keep the R (resp. B) channel in order although cfg_reorder is set
//   cfg_hang_rd/wr accepted requests are never answered (timeout tests)
//   inj_*          physical range answered with SLVERR for reads and/or writes; unmapped PAs answer DECERR
// WRITE COMMIT: a write burst becomes visible in `mem` only when its B response is handed over (== "acknowledged"),
// so a DUT that reports completion early is caught by the scoreboard (memory not yet updated).
// ============================================================================
  int n_rd_bursts = 0, n_wr_bursts = 0, n_wr_bytes = 0;
  int n_rd_ooo = 0, n_wr_ooo = 0, max_rd_out = 0, max_wr_out = 0, max_burst_beats = 0, n_r_beats = 0;

  function automatic int id2ch(input logic [ID_W-1:0] id);
    /*verilator no_inline_task*/
    if (NUM_CH == 1) return 0;
    return int'(id[ID_W-1 -: CHW]);
  endfunction

  // ------------------------------------------------------------ knobs
  int  cfg_ar_p = 100, cfg_aw_p = 100, cfg_w_p = 100, cfg_r_p = 100, cfg_b_p = 100;
  int  cfg_lat_min = 1, cfg_lat_max = 1, cfg_b_min = 1, cfg_b_max = 1;
  bit  cfg_reorder = 0, cfg_interleave = 0, cfg_hang_rd = 0, cfg_hang_wr = 0;
  bit  cfg_r_inorder = 0, cfg_b_inorder = 0;                // force ONE response channel in order although cfg_reorder is set (negative tests)
  int  cfg_hang_ch = -1;                                     // -1: the hang applies to every channel, otherwise only to this channel's requests
  longint inj_lo = 0, inj_hi = 0; int inj_kind = 0;          // kind: 0 none, 1 reads, 2 writes, 3 both

  function automatic int rnd100();
    /*verilator no_inline_task*/
    return $urandom_range(99, 0);
  endfunction
  function automatic int rnd_rng(input int lo, input int hi);
    /*verilator no_inline_task*/
    return (hi <= lo) ? lo : $urandom_range(hi, lo);
  endfunction

  // classify a burst: 0 OKAY, 2 SLVERR, 3 DECERR
  function automatic int burst_resp(input longint a, input int beats, input bit is_write);
    /*verilator no_inline_task*/
    longint lo, hi;
    lo = a; hi = a + longint'(beats) * WB;
    for (int k = 0; k < beats; k++) if (pa2idx(a + longint'(k) * WB) < 0) return 3;
    if (inj_kind != 0 && ((is_write && (inj_kind & 2) != 0) || (!is_write && (inj_kind & 1) != 0)) && lo < inj_hi && hi > inj_lo) return 2;
    return 0;
  endfunction

  // ------------------------------------------------------------ read side state
  localparam int RQN = 64;
  bit              rq_v   [RQN];
  logic [ID_W-1:0] rq_id  [RQN];
  longint          rq_addr[RQN];
  int              rq_len [RQN];
  int              rq_lat [RQN];
  int              rq_beat[RQN];
  int              rq_resp[RQN];
  longint          rq_seq [RQN];
  longint          rq_seqn = 0;
  int              r_pres = -1;           // burst whose beat is currently presented
  int              r_stick = -1;          // burst being served without interleaving

  // ------------------------------------------------------------ write side state
  localparam int WQN = 32;
  localparam int MAXBT = 64;
  bit              wq_v   [WQN];
  logic [ID_W-1:0] wq_id  [WQN];
  longint          wq_addr[WQN];
  int              wq_len [WQN];
  int              wq_got [WQN];
  bit              wq_done[WQN];
  int              wq_timer[WQN];
  int              wq_resp[WQN];
  longint          wq_seq [WQN];
  longint          wq_seqn = 0;
  logic [DW-1:0]   wq_data[WQN][MAXBT];
  logic [WB-1:0]   wq_strb[WQN][MAXBT];
  int              w_tgt_q = -1;          // target the current W ready was computed for
  int              b_pres = -1;

  function automatic bit rd_hung(input int i);
    return cfg_hang_rd && (cfg_hang_ch < 0 || id2ch(rq_id[i]) == cfg_hang_ch);
  endfunction
  function automatic bit wr_hung(input int i);
    return cfg_hang_wr && (cfg_hang_ch < 0 || id2ch(wq_id[i]) == cfg_hang_ch);
  endfunction

  task automatic slave_flush();
    for (int i = 0; i < RQN; i++) rq_v[i] = 0;
    for (int i = 0; i < WQN; i++) wq_v[i] = 0;
    for (int c = 0; c < NUM_CH; c++) begin wr_pend[c] = 0; rd_pend[c] = 0; end
    r_pres = -1; r_stick = -1; w_tgt_q = -1; b_pres = -1;
    mon_flush();
    m_ar_ready <= 0; m_aw_ready <= 0; m_w_ready <= 0; m_r_valid <= 0; m_b_valid <= 0;
  endtask

  function automatic int oldest_wq_needing_data();
    /*verilator no_inline_task*/
    int best = -1;
    for (int i = 0; i < WQN; i++)
      if (wq_v[i] && wq_got[i] < wq_len[i] && (best < 0 || wq_seq[i] < wq_seq[best])) best = i;
    return best;
  endfunction

  initial slave_flush();

  always @(posedge clk) begin
    if (!rst_n) begin
      slave_flush();
    end else begin
      // ---------------------------------------------------------- AR accept
      if (m_ar_valid && m_ar_ready) begin
        int s = -1;
        for (int i = 0; i < RQN && s < 0; i++) if (!rq_v[i]) s = i;
        if (s < 0) fail("slave: read queue overflow");
        else begin
          rq_v[s] = 1; rq_id[s] = m_ar_id; rq_addr[s] = longint'(m_ar_addr); rq_len[s] = int'(m_ar_len) + 1; rq_beat[s] = 0;
          rq_lat[s] = rnd_rng(cfg_lat_min, cfg_lat_max); rq_resp[s] = burst_resp(longint'(m_ar_addr), int'(m_ar_len) + 1, 0);
          rq_seq[s] = rq_seqn; rq_seqn++;
          rd_pend[id2ch(m_ar_id)]++;
          n_rd_bursts++;
          begin int t = 0; for (int c = 0; c < NUM_CH; c++) t += rd_pend[c]; if (t > max_rd_out) max_rd_out = t; end
          if (int'(m_ar_len) + 1 > max_burst_beats) max_burst_beats = int'(m_ar_len) + 1;
          mon_ar(id2ch(m_ar_id), int'(m_ar_id), longint'(m_ar_addr), int'(m_ar_len), int'(m_ar_asid), int'(m_ar_domain), int'(m_ar_size), int'(m_ar_burst), cyc);
        end
      end
      m_ar_ready <= (rnd100() < cfg_ar_p);
      for (int i = 0; i < RQN; i++) if (rq_v[i] && rq_lat[i] > 0) rq_lat[i]--;

      // ---------------------------------------------------------- R channel
      if (m_r_valid && m_r_ready) begin
        int p = r_pres;
        rq_beat[p]++;
        if (m_r_last) begin mon_rdone(int'(rq_id[p])); rq_v[p] = 0; rd_pend[id2ch(rq_id[p])]--; if (r_stick == p) r_stick = -1; end
        r_pres = -1;
      end
      if (!(m_r_valid && !m_r_ready)) begin                  // not stalled: choose the next beat
        int sel = -1;
        begin
          if (!cfg_reorder || cfg_r_inorder) begin            // in order: oldest (not hung) only
            for (int i = 0; i < RQN; i++) if (rq_v[i] && !rd_hung(i) && (sel < 0 || rq_seq[i] < rq_seq[sel])) sel = i;
            if (sel >= 0 && rq_lat[sel] > 0) sel = -1;
          end else if (!cfg_interleave && r_stick >= 0) begin
            sel = r_stick;
          end else begin
            int cand [RQN]; int nc = 0;
            for (int i = 0; i < RQN; i++) if (rq_v[i] && !rd_hung(i) && rq_lat[i] <= 0) begin cand[nc] = i; nc++; end
            if (nc > 0) sel = cand[$urandom_range(nc - 1, 0)];
          end
        end
        if (sel >= 0 && rnd100() < cfg_r_p) begin
          logic [DW-1:0] d = '0;
          for (int c = 0; c < WB; c++) begin
            int ix = pa2idx(rq_addr[sel] + longint'(rq_beat[sel]) * WB + c);
            if (ix >= 0) d[8*c +: 8] = mem[ix];
          end
          if (rq_beat[sel] == 0) begin
            for (int i = 0; i < RQN; i++) if (rq_v[i] && rq_seq[i] < rq_seq[sel]) begin n_rd_ooo++; break; end
          end
          n_r_beats++;
          m_r_valid <= 1; m_r_id <= rq_id[sel]; m_r_data <= d; m_r_resp <= 2'(rq_resp[sel]);
          m_r_last <= (rq_beat[sel] == rq_len[sel] - 1);
          r_pres = sel; r_stick = cfg_interleave ? -1 : sel;
        end else begin
          m_r_valid <= 0; m_r_data <= '0; m_r_last <= 0; m_r_resp <= 0;
        end
      end

      // ---------------------------------------------------------- AW accept
      if (m_aw_valid && m_aw_ready) begin
        int s = -1;
        for (int i = 0; i < WQN && s < 0; i++) if (!wq_v[i]) s = i;
        if (s < 0) fail("slave: write queue overflow");
        else begin
          wq_v[s] = 1; wq_id[s] = m_aw_id; wq_addr[s] = longint'(m_aw_addr); wq_len[s] = int'(m_aw_len) + 1; wq_got[s] = 0; wq_done[s] = 0;
          wq_timer[s] = 0; wq_resp[s] = burst_resp(longint'(m_aw_addr), int'(m_aw_len) + 1, 1); wq_seq[s] = wq_seqn; wq_seqn++;
          wr_pend[id2ch(m_aw_id)]++;
          n_wr_bursts++;
          begin int t = 0; for (int c = 0; c < NUM_CH; c++) t += wr_pend[c]; if (t > max_wr_out) max_wr_out = t; end
          if (int'(m_aw_len) + 1 > max_burst_beats) max_burst_beats = int'(m_aw_len) + 1;
          mon_aw(id2ch(m_aw_id), int'(m_aw_id), longint'(m_aw_addr), int'(m_aw_len), int'(m_aw_asid), int'(m_aw_domain), int'(m_aw_size), int'(m_aw_burst), cyc);
        end
      end
      m_aw_ready <= (rnd100() < cfg_aw_p);

      // ---------------------------------------------------------- W channel
      if (m_w_valid && m_w_ready) begin
        int t = w_tgt_q;
        if (t < 0) fail("slave: W beat accepted with no write burst pending");
        else begin
          if (wq_got[t] < MAXBT) begin wq_data[t][wq_got[t]] = m_w_data; wq_strb[t][wq_got[t]] = m_w_strb; end
          mon_w(id2ch(wq_id[t]), wq_addr[t], wq_got[t], 512'(m_w_data), 64'(m_w_strb), m_w_last, wq_resp[t], cyc);
          wq_got[t]++;
          if (m_w_last) begin
            `TBCHK(wq_got[t] == wq_len[t], "slave: WLAST not on the last beat of the burst")
            wq_done[t] = 1; wq_timer[t] = rnd_rng(cfg_b_min, cfg_b_max);
          end else `TBCHK(wq_got[t] < wq_len[t], "slave: more W beats than AWLEN+1")
        end
      end
      w_tgt_q = oldest_wq_needing_data();
      m_w_ready <= (w_tgt_q >= 0) && (rnd100() < cfg_w_p);
      for (int i = 0; i < WQN; i++) if (wq_v[i] && wq_done[i] && wq_timer[i] > 0) wq_timer[i]--;

      // ---------------------------------------------------------- B channel (commit on handover)
      if (m_b_valid && m_b_ready) begin
        int p = b_pres;
        if (wq_resp[p] == 0) begin
          for (int k = 0; k < wq_len[p]; k++)
            for (int c = 0; c < WB; c++) if (wq_strb[p][k][c]) begin
              int ix = pa2idx(wq_addr[p] + longint'(k) * WB + c);
              if (ix >= 0) begin mem[ix] = wq_data[p][k][8*c +: 8]; wr_ok[ix]++; n_wr_bytes++; end
            end
        end
        mon_bdone(int'(wq_id[p]));
        wq_v[p] = 0; wr_pend[id2ch(wq_id[p])]--;
        b_pres = -1;
      end
      if (!(m_b_valid && !m_b_ready)) begin
        int sel = -1;
        begin
          if (!cfg_reorder || cfg_b_inorder) begin
            for (int i = 0; i < WQN; i++) if (wq_v[i] && !wr_hung(i) && (sel < 0 || wq_seq[i] < wq_seq[sel])) sel = i;
            if (sel >= 0 && !(wq_done[sel] && wq_timer[sel] <= 0)) sel = -1;
          end else begin
            int cand [WQN]; int nc = 0;
            for (int i = 0; i < WQN; i++) if (wq_v[i] && !wr_hung(i) && wq_done[i] && wq_timer[i] <= 0) begin cand[nc] = i; nc++; end
            if (nc > 0) sel = cand[$urandom_range(nc - 1, 0)];
          end
        end
        if (sel >= 0 && rnd100() < cfg_b_p) begin
          for (int i = 0; i < WQN; i++) if (wq_v[i] && wq_seq[i] < wq_seq[sel]) begin n_wr_ooo++; break; end
          m_b_valid <= 1; m_b_id <= wq_id[sel]; m_b_resp <= 2'(wq_resp[sel]); b_pres = sel;
        end else begin
          m_b_valid <= 0; m_b_resp <= 0;
        end
      end
    end
  end
