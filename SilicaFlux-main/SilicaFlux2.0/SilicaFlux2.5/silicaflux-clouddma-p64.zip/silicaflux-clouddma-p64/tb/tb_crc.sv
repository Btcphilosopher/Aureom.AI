// Unit bench: sfdma_crc vs (a) the published check value, (b) a bitwise reference, (c) the vendored Project-61
// sfd_crc32 fed one byte at a time.  Random strobe patterns, including sparse ones.
`timescale 1ns/1ps
module tb_crc #(parameter int DW = 64);
  localparam int WB = DW/8;
  logic clk = 0; always #5 clk = ~clk;
  logic rst_n = 0, clr = 0, en = 0; logic [DW-1:0] data = 0; logic [WB-1:0] strb = 0; logic [31:0] crc;
  sfdma_crc #(.DW(DW)) dut (.clk, .rst_n, .clr, .en, .data, .strb, .crc_o(crc));
  // golden 1: vendored sfd_crc32 (byte serial)
  logic g_clr = 0, g_en = 0; logic [31:0] g_d = 0; logic [2:0] g_n = 1; logic [31:0] g_crc;
  sfd_crc32 gold (.clk, .rst_n, .clr(g_clr), .en(g_en), .data_i(g_d), .nbytes_i(g_n), .crc_o(g_crc));
  int errors = 0, checks = 0;

  function automatic logic [31:0] ref_crc_byte(input logic [31:0] st, input logic [7:0] b);   // bitwise, non-reflected-table form
    logic [31:0] c;
    c = st;
    for (int i = 0; i < 8; i++) begin
      logic fb; fb = c[0] ^ b[i];
      c = (c >> 1); if (fb) c = c ^ 32'hEDB88320;
    end
    return c;
  endfunction

  task automatic beat(input logic [DW-1:0] d, input logic [WB-1:0] s, input bit use_gold);
    @(negedge clk); data = d; strb = s; en = 1;
    @(negedge clk); en = 0;
    if (use_gold) begin
      for (int i = 0; i < WB; i++) if (s[i]) begin
        g_d = {24'd0, d[8*i +: 8]}; g_n = 3'd1; g_en = 1; @(negedge clk); g_en = 0;
      end
    end
  endtask
  task automatic reset_crcs;
    @(negedge clk); clr = 1; g_clr = 1; @(negedge clk); clr = 0; g_clr = 0;
  endtask

  logic [31:0] ref_st;
  initial begin
    repeat (3) @(negedge clk); rst_n = 1;
    // (a) "123456789" -> 0xCBF43926, fed with the bytes spread over beats at lane offset 3
    reset_crcs();
    begin
      byte unsigned msg [9] = '{49,50,51,52,53,54,55,56,57};
      int idx; idx = 0;
      while (idx < 9) begin
        logic [DW-1:0] d; logic [WB-1:0] s; int n;
        d = '0; s = '0; n = (WB - 3 < 9 - idx) ? WB - 3 : 9 - idx;
        for (int i = 0; i < n; i++) begin d[8*(3+i) +: 8] = msg[idx+i]; s[3+i] = 1; end
        beat(d, s, 1); idx += n;
      end
      checks++;
      if (crc !== 32'hCBF43926) begin errors++; $display("check value: got %h", crc); end
      checks++;
      if (g_crc !== 32'hCBF43926) begin errors++; $display("golden check value: got %h", g_crc); end
    end
    // (b)+(c) random streams
    for (int run = 0; run < 400; run++) begin
      reset_crcs(); ref_st = 32'hFFFFFFFF;
      for (int b = 0; b < 1 + $urandom_range(20, 0); b++) begin
        logic [DW-1:0] d; logic [WB-1:0] s;
        for (int w = 0; w < DW/32; w++) d[32*w +: 32] = $urandom;
        case ($urandom_range(3, 0))
          0: s = '1;
          1: s = WB'($urandom);
          2: s = WB'(($urandom_range(WB, 1) < WB ? ((1 << $urandom_range(WB, 1)) - 1) : '1) << $urandom_range(WB-1, 0));
          default: s = WB'(1 << $urandom_range(WB-1, 0));
        endcase
        beat(d, s, 1);
        for (int i = 0; i < WB; i++) if (s[i]) ref_st = ref_crc_byte(ref_st, d[8*i +: 8]);
      end
      checks += 2;
      if (crc !== ~ref_st)  begin errors++; if (errors < 8) $display("run %0d: crc %h != ref %h", run, crc, ~ref_st); end
      if (g_crc !== crc)    begin errors++; if (errors < 8) $display("run %0d: crc %h != sfd_crc32 %h", run, crc, g_crc); end
    end
    // clr has priority over en
    @(negedge clk); data = '1; strb = '1; en = 1; clr = 1; @(negedge clk); en = 0; clr = 0;
    checks++; if (crc !== 32'h0000_0000) begin errors++; $display("clr/en priority: crc %h", crc); end
    $display("tb_crc DW=%0d: checks=%0d errors=%0d", DW, checks, errors);
    if (errors == 0) $display("TB RESULT PASS"); else $display("TB RESULT FAIL");
    $finish;
  end
endmodule
