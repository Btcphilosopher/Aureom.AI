// ============================================================================
// tb_iommu.svh -- behavioural EXTERNAL IOMMU for USE_EXT_IOMMU = 1.  Implements the contract of docs/03 §3 from the TB's
// independent translation mirror (tb_pkg::mp_*): in-order responses, configurable latency, ready jitter.  Fault injection:
//   iom_mode 1: physical address off by one byte        2: in-page offset changed (still beat aligned)
//            3: refusal without a cause (ok = 0, fault = 0)      4: stray extra responses for clients that are NOT waiting
// iom_skip responses are passed through unmodified before the injection starts (so the descriptor fetch can succeed first).
// A real IOMMU reports a range that belongs to another domain as NO_MAP (only the simulation table knows DOMAIN).
// ============================================================================
  int iom_lat = 3, iom_jitter = 2, iom_mode = 0, iom_skip = 0, n_iom_req = 0, n_iom_stray = 0;
  localparam int IOQ = 32;
  int      iq_due [IOQ]; logic [IDP-1:0] iq_id [IOQ]; bit iq_ok [IOQ]; int iq_fault [IOQ]; longint iq_pa [IOQ]; int iq_head = 0, iq_tail = 0;
  bit      iq_pend [2**IDP];                                    // clients with a request accepted and no response issued yet
  int      iom_last_due = 0;
  initial for (int i = 0; i < 2**IDP; i++) iq_pend[i] = 0;

  function automatic void iom_lookup(input int dom, input int asid, input bit wr, input longint addr, input int bytes, output bit ok, output int fault, output longint pa);
    bit starts_in_any = 0, perm_miss = 0;
    ok = 0; fault = 1; pa = 0;
    for (int e = 0; e < NENT; e++) if (mp_v[e] && mp_dom[e] == dom && mp_asid[e] == asid) begin
      bit starts = (addr >= mp_base[e]) && (addr < mp_base[e] + mp_size[e]);
      bit inr    = starts && (addr + bytes <= mp_base[e] + mp_size[e]);
      bit pok    = wr ? ((mp_perm[e] & 2) != 0) : ((mp_perm[e] & 1) != 0);
      if (inr && pok && !ok) begin ok = 1; pa = mp_pa[e] + (addr - mp_base[e]); end
      if (inr && !pok) perm_miss = 1;
      if (starts && !inr) starts_in_any = 1;
    end
    if (!ok) fault = perm_miss ? 2 : starts_in_any ? 4 : 1;
  endfunction

  always @(posedge clk) begin
    if (!rst_n) begin
      iq_head = 0; iq_tail = 0; iom_last_due = 0;
      for (int i = 0; i < 2**IDP; i++) iq_pend[i] = 0;
      iommu_req_ready <= 0; iommu_rsp_valid <= 0;
    end else if (EXT_IOMMU != 0) begin
      // accept a request
      if (iommu_req_valid && iommu_req_ready) begin
        bit ok; int fault; longint pa; int due; int idx;
        iom_lookup(int'(iommu_req_domain), int'(iommu_req_asid), iommu_req_write, longint'(iommu_req_addr), int'(iommu_req_bytes), ok, fault, pa);
        n_iom_req++;
        if (ok) begin
          if (iom_skip > 0) iom_skip--;
          else begin
            case (iom_mode)
              1: pa = pa + 1;
              2: pa = pa + longint'(WB);
              3: begin ok = 0; fault = 0; end
              default: ;
            endcase
            if (iom_mode >= 1 && iom_mode <= 3) iom_mode = 0;                        // one-shot: only the first eligible response is corrupted
          end
        end
        due = cyc + iom_lat + ((iom_jitter > 0) ? $urandom_range(iom_jitter, 0) : 0);
        if (due < iom_last_due) due = iom_last_due;                      // in-order responses
        iom_last_due = due;
        idx = iq_tail % IOQ;
        iq_due[idx] = due; iq_id[idx] = iommu_req_id; iq_ok[idx] = ok; iq_fault[idx] = fault; iq_pa[idx] = pa; iq_tail++;
        iq_pend[iommu_req_id] = 1;
      end
      iommu_req_ready <= ($urandom_range(3, 0) != 0);
      // deliver
      if (iommu_rsp_valid && iommu_rsp_ready) iommu_rsp_valid <= 0;
      if (!(iommu_rsp_valid && !iommu_rsp_ready) && iq_head != iq_tail && iq_due[iq_head % IOQ] <= cyc) begin
        int idx = iq_head % IOQ;
        if (iom_mode == 4 && ($urandom_range(2, 0) == 0)) begin                // a stray response for a client that is not waiting
          int sid = -1;
          for (int k = 0; k < 2**IDP && sid < 0; k++) if (!iq_pend[k] || (k == int'(iq_id[idx]) && 0)) sid = k;
          if (sid >= 0) begin
            iommu_rsp_valid <= 1; iommu_rsp_id <= IDP'(sid); iommu_rsp_ok <= 1'b1; iommu_rsp_fault <= 4'd0; iommu_rsp_pa <= AW'(64'h0DEA_D000); n_iom_stray++;
          end else iommu_rsp_valid <= 0;
        end else begin
          iommu_rsp_valid <= 1; iommu_rsp_id <= iq_id[idx]; iommu_rsp_ok <= iq_ok[idx]; iommu_rsp_fault <= 4'(iq_fault[idx]); iommu_rsp_pa <= AW'(iq_pa[idx]);
          iq_pend[iq_id[idx]] = 0; iq_head++;
        end
      end
    end
  end
