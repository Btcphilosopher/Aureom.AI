// Unit bench: sfdma_bytebuf vs a plain byte-array reference.  Random-alignment writes and reads, ring wrap-around.
`timescale 1ns/1ps
module tb_bytebuf #(parameter int DW = 64, parameter int CAP = 64);
  localparam int WB = DW/8, LW = $clog2(WB), PW = $clog2(CAP);
  logic clk = 0; always #5 clk = ~clk;
  logic wr_en; logic [PW-1:0] wr_pos; logic [LW-1:0] wr_lane0; logic [LW:0] wr_n; logic [DW-1:0] wr_data;
  logic [PW-1:0] rd_pos; logic [LW-1:0] rd_lane0; logic [LW:0] rd_n; logic [DW-1:0] rd_data; logic [WB-1:0] rd_strb;
  sfdma_bytebuf #(.DW(DW), .CAP(CAP)) dut (.*);
  byte unsigned refm [CAP];
  int errors = 0, checks = 0;

  task automatic do_write(input int pos, input int lane0, input int n, input logic [DW-1:0] d);
    @(negedge clk); wr_en = 1; wr_pos = PW'(pos); wr_lane0 = LW'(lane0); wr_n = (LW+1)'(n); wr_data = d;
    @(negedge clk); wr_en = 0;
    for (int i = 0; i < n; i++) refm[(pos + i) % CAP] = d[8*(lane0+i) +: 8];
  endtask
  task automatic do_read(input int pos, input int lane0, input int n);
    logic [DW-1:0] ed; logic [WB-1:0] es;
    rd_pos = PW'(pos); rd_lane0 = LW'(lane0); rd_n = (LW+1)'(n); #1;
    ed = '0; es = '0;
    for (int d = 0; d < n; d++) begin ed[8*(lane0+d) +: 8] = refm[(pos + d) % CAP]; es[lane0+d] = 1'b1; end
    checks++;
    if (rd_data !== ed || rd_strb !== es) begin
      errors++;
      if (errors < 8) $display("MISMATCH pos=%0d lane0=%0d n=%0d got=%h/%b exp=%h/%b", pos, lane0, n, rd_data, rd_strb, ed, es);
    end
  endtask

  initial begin
    wr_en = 0; wr_pos = 0; wr_lane0 = 0; wr_n = 0; wr_data = 0; rd_pos = 0; rd_lane0 = 0; rd_n = 0;
    // fill every byte once so the reference is fully defined
    for (int p = 0; p < CAP; p += WB) do_write(p, 0, WB, {WB{8'($urandom)}} ^ {DW/32{$urandom}});
    for (int it = 0; it < 20000; it++) begin
      int pos, l0, n;
      logic [DW-1:0] d;
      pos = $urandom_range(CAP-1, 0); l0 = $urandom_range(WB-1, 0); n = $urandom_range(WB - l0, 0);
      for (int w = 0; w < DW/32; w++) d[32*w +: 32] = $urandom;
      do_write(pos, l0, n, d);
      // reads of arbitrary windows, including ones straddling the wrap point
      for (int r = 0; r < 3; r++) begin
        int rp, rl, rn;
        rp = $urandom_range(CAP-1, 0); rl = $urandom_range(WB-1, 0); rn = $urandom_range(WB - rl, 0);
        do_read(rp, rl, rn);
      end
      // full-beat read right after a write at the same place
      do_read(pos, l0, n);
    end
    $display("tb_bytebuf DW=%0d CAP=%0d: checks=%0d errors=%0d", DW, CAP, checks, errors);
    if (errors == 0) $display("TB RESULT PASS"); else $display("TB RESULT FAIL");
    $finish;
  end
endmodule
