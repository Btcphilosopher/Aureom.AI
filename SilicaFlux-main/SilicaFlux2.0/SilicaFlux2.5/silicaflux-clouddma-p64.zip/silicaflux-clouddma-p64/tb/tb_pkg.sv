// ============================================================================
// tb_pkg.sv -- testbench state, independent translation mirror, descriptor builders, expected-write model, monitors'
// byte-level checks and the per-completion / final-memory checks.
// WHY A PACKAGE: Verilator 5.020 inlines every module-level task/function that a timing process calls, at every call
// site (a first version produced a 1.3-million-line C++ function).  Package functions compile once.
// Nothing here calls into the DUT.  Per-channel FIFOs are ring buffers: Verilator 5.020 cannot generate correct C++ for
// arrays of queues.
// ============================================================================
`include "tb_defs.svh"
package tb_pkg;
  localparam int MAXCH = 4;

  // ---------------------------------------------------------------- physical memory map
  localparam longint HOST_PA = 64'h0000_0000, HOST_SZ = 64'h100_0000;      // 16 MiB (4 MiB per domain)
  localparam longint SRAM_PA = 64'h4000_0000, SRAM_SZ = 64'h10_0000;       // 1 MiB
  localparam longint STOR_PA = 64'h8000_0000, STOR_SZ = 64'h10_0000;       // 1 MiB
  localparam int     MEM_SZ  = 'h100_0000 + 'h10_0000 + 'h10_0000;         // 18 MiB image
  // IOVA layout (same for every domain)
  localparam longint IOVA_H      = 64'h1_0000_0000;                         // 2 MiB RW host window
  localparam longint HOST_WIN    = 64'h20_0000;
  localparam longint IOVA_RO     = 64'h1_0040_0000;                         // 64 KiB read-only window
  localparam longint IOVA_PRIV   = 64'h2_0000_0000;                         // + d*0x10000, 64 KiB private
  localparam longint IOVA_S      = 64'h0;                                   // SRAM partition 64 KiB
  localparam longint IOVA_ST     = 64'h0;                                   // STOR window 64 KiB (asid 2)
  localparam longint DESC_OFF    = 64'h1F_0000;                             // descriptor area inside the host window
  localparam longint DATA_PER_CH = 64'h7_8000;                              // 480 KiB data window per channel
  localparam int NENT = 64;
  localparam int NDOM = 4;
  localparam int MAXE = 140;
  localparam int XQN = 16, XRN = 4096, DQN = 32, IFN = 16;

  // ---------------------------------------------------------------- configuration set by the module before use
  int p_nch = 1, p_wb = 8, p_maxb = 16;

  // ---------------------------------------------------------------- scoreboard counters
  int errors = 0, checks = 0, tests_run = 0, tests_failed = 0;
  longint tb_bytes_ok = 0;
  bit exp_tolerant = 0;                    // chain_expect: skip bytes that cannot be translated (error tests)
  string fail_pfx [64];
  int    fail_pfx_n [64];
  int    fail_npfx = 0;
  // prints the first 3 occurrences of every kind of failure (kind = first 28 characters), counts all of them
  function automatic void fail(input string msg);
    /*verilator no_inline_task*/
    int k = -1;
    string pfx = msg.substr(0, (msg.len() < 28) ? msg.len() - 1 : 27);
    errors++;
    for (int i = 0; i < fail_npfx; i++) if (fail_pfx[i] == pfx) k = i;
    if (k < 0 && fail_npfx < 64) begin k = fail_npfx; fail_pfx[k] = pfx; fail_pfx_n[k] = 0; fail_npfx++; end
    if (k >= 0) fail_pfx_n[k]++;
    if (k < 0 || fail_pfx_n[k] <= 3) $display("[%0t] FAIL: %s", $time, msg);
  endfunction

  // ---------------------------------------------------------------- memory image
  byte unsigned mem [MEM_SZ];
  function automatic int pa2idx(input longint pa);
    /*verilator no_inline_task*/
    if (pa >= HOST_PA && pa < HOST_PA + HOST_SZ)      return int'(pa - HOST_PA);
    else if (pa >= SRAM_PA && pa < SRAM_PA + SRAM_SZ) return int'(HOST_SZ) + int'(pa - SRAM_PA);
    else if (pa >= STOR_PA && pa < STOR_PA + STOR_SZ) return int'(HOST_SZ + SRAM_SZ) + int'(pa - STOR_PA);
    return -1;
  endfunction
  int  wr_pend [MAXCH];                    // AW accepted, B not yet handed over (per channel)
  int  rd_pend [MAXCH];

  // ---------------------------------------------------------------- translation mirror (independent of the DUT)
  bit      mp_v    [NENT];
  int      mp_dom  [NENT];
  int      mp_asid [NENT];
  longint  mp_base [NENT];
  longint  mp_size [NENT];
  longint  mp_pa   [NENT];
  int      mp_perm [NENT];

  // translate one byte; need: 1 read, 2 write; returns -1 if not reachable
  function automatic longint t_iova2pa(input int dom, input int asid, input longint iova, input int need);
    /*verilator no_inline_task*/
    for (int e = 0; e < NENT; e++)
      if (mp_v[e] && mp_dom[e] == dom && mp_asid[e] == asid && iova >= mp_base[e] && iova < mp_base[e] + mp_size[e] && ((mp_perm[e] & need) == need))
        return mp_pa[e] + (iova - mp_base[e]);
    return -1;
  endfunction

  // is the physical range [lo, hi) inside mappings of `dom` that grant `need`?  (used by the unauthorised-access monitor)
  function automatic bit pa_allowed(input int dom, input longint lo, input longint hi, input int need);
    /*verilator no_inline_task*/
    for (int e = 0; e < NENT; e++)
      if (mp_v[e] && mp_dom[e] == dom && ((mp_perm[e] & need) == need) && lo >= mp_pa[e] && hi <= mp_pa[e] + mp_size[e]) return 1;
    return 0;
  endfunction

  // ---------------------------------------------------------------- expected-write model
  shortint     exp_own [MEM_SZ];            // owning transaction uid, -1 = nobody may write this byte
  byte unsigned exp_val [MEM_SZ];
  bit          exp_chk [MEM_SZ];            // value is checked (record latency bytes are not)
  byte unsigned wr_cnt [MEM_SZ];            // bytes presented on the W channel
  byte unsigned wr_ok  [MEM_SZ];            // bytes actually COMMITTED by the slave (B = OKAY)
  int          uid_n = 0;

  function automatic void model_init();
    /*verilator no_inline_task*/
    for (int i = 0; i < MEM_SZ; i++) begin
      mem[i] = 8'((i * 2654435761) >> 11) ^ 8'(i >> 9);           // deterministic non-constant fill (cheap)
      exp_own[i] = -1; exp_val[i] = 0; exp_chk[i] = 1; wr_cnt[i] = 0; wr_ok[i] = 0;
    end
    for (int c = 0; c < MAXCH; c++) begin wr_pend[c] = 0; rd_pend[c] = 0; end
  endfunction

  // little-endian helpers on the memory image (backdoor)
  function automatic bit [31:0] bd_rd32(input longint pa);
    /*verilator no_inline_task*/
    bit [31:0] v = 0;
    for (int b = 0; b < 4; b++) v[8*b +: 8] = mem[pa2idx(pa + b)];
    return v;
  endfunction
  function automatic void bd_wr32(input longint pa, input bit [31:0] v);
    /*verilator no_inline_task*/
    for (int b = 0; b < 4; b++) mem[pa2idx(pa + b)] = v[8*b +: 8];
  endfunction
  // descriptor word write through the domain's own translation
  function automatic void dw32(input int dom, input longint iova, input bit [31:0] v);
    /*verilator no_inline_task*/
    longint pa = t_iova2pa(dom, 0, iova, 2);
    if (pa < 0) fail($sformatf("TB: descriptor area %h not mapped for domain %0d", iova, dom));
    else bd_wr32(pa, v);
  endfunction

  function automatic bit [31:0] crc32_step(input bit [31:0] st, input bit [7:0] b);   // bitwise, init/xorout handled by the caller
    /*verilator no_inline_task*/
    bit [31:0] c = st ^ {24'd0, b};
    for (int i = 0; i < 8; i++) c = c[0] ? ((c >> 1) ^ 32'hEDB88320) : (c >> 1);
    return c;
  endfunction

  // ---------------------------------------------------------------- chain description (per channel)
  int      ce_n       [MAXCH];
  int      ce_sasid   [MAXCH][MAXE];
  int      ce_dasid   [MAXCH][MAXE];
  longint  ce_src     [MAXCH][MAXE];
  longint  ce_dst     [MAXCH][MAXE];
  int      ce_len     [MAXCH][MAXE];
  bit      ce_ord     [MAXCH][MAXE];
  int      ce_slot    [MAXCH][MAXE];
  int      cc_dom     [MAXCH];
  int      cc_txn     [MAXCH];
  bit      cc_cpl     [MAXCH];
  bit      cc_crc     [MAXCH];
  bit      cc_irq     [MAXCH];
  bit      cc_array   [MAXCH];
  longint  cc_cpl_iova[MAXCH];
  int      cc_cpl_asid[MAXCH];
  int      cc_desc_asid[MAXCH];

  // expected outcome: one entry per COMPLETION (ring buffers), plus one shared ownership set (uid) per channel
  int      xq_txn     [MAXCH][XQN];
  int      xq_dom     [MAXCH][XQN];
  int      xq_status  [MAXCH][XQN];
  int      xq_err     [MAXCH][XQN];
  int      xq_err2    [MAXCH][XQN];
  int      xq_fault   [MAXCH][XQN];         // -1 = do not check
  longint  xq_blo     [MAXCH][XQN];
  longint  xq_bhi     [MAXCH][XQN];
  bit      xq_crc_exp [MAXCH][XQN];
  bit [31:0] xq_crc   [MAXCH][XQN];
  bit      xq_rec     [MAXCH][XQN];         // a completion record must be in memory
  longint  xq_rec_pa  [MAXCH][XQN];
  int      xq_dlo     [MAXCH][XQN];
  int      xq_dhi     [MAXCH][XQN];
  int      xq_rd [MAXCH], xq_wr [MAXCH];
  int      x_uid      [MAXCH];
  int      x_rep      [MAXCH];              // identical commands issued back to back (each byte written x_rep times)
  bit      x_weak     [MAXCH];              // execution-error tests: written bytes must be right, unwritten ones may be missing
  bit      allow_pending_at_done [MAXCH];
  longint  xr_pa      [MAXCH][XRN];         // expected byte runs (physical start, length)
  int      xr_n       [MAXCH][XRN];
  int      xr_cnt     [MAXCH];
  int      if_dom     [MAXCH][IFN];         // domains bound to the commands in flight, oldest first
  int      if_rd [MAXCH], if_wr [MAXCH];
  // done events (written by the completion monitor, read by the tests)
  int      dq_txn [MAXCH][DQN]; int dq_status [MAXCH][DQN]; int dq_err [MAXCH][DQN]; int dq_fault [MAXCH][DQN]; int dq_dom [MAXCH][DQN];
  longint  dq_bytes [MAXCH][DQN]; bit [31:0] dq_crc [MAXCH][DQN];
  int      dq_rd [MAXCH], dq_wr [MAXCH];
  longint  alloc_h    [MAXCH];
  longint  alloc_s    [MAXCH];
  longint  alloc_st   [MAXCH];

  function automatic int xq_n(input int ch);   return xq_wr[ch] - xq_rd[ch]; endfunction
  function automatic int xl(input int ch);     return (xq_wr[ch] + XQN - 1) % XQN; endfunction     // index of the newest entry
  function automatic int xf(input int ch);     return xq_rd[ch] % XQN; endfunction                // index of the oldest entry
  function automatic int dq_n(input int ch);   return dq_wr[ch] - dq_rd[ch]; endfunction
  function automatic int dq_f(input int ch);   return dq_rd[ch] % DQN; endfunction
  function automatic int if_n(input int ch);   return if_wr[ch] - if_rd[ch]; endfunction
  function automatic int cur_dom_of(input int ch);
    return (if_n(ch) > 0) ? if_dom[ch][if_rd[ch] % IFN] : -1;
  endfunction
  function automatic void if_push(input int ch, input int d);  if_dom[ch][if_wr[ch] % IFN] = d; if_wr[ch]++; endfunction
  function automatic void if_pop(input int ch);                if (if_n(ch) > 0) if_rd[ch]++; endfunction
  function automatic void if_clear(input int ch);              if_rd[ch] = 0; if_wr[ch] = 0; endfunction
  function automatic void dq_clear(input int ch);              dq_rd[ch] = 0; dq_wr[ch] = 0; endfunction
  function automatic void dq_push(input int ch, input int txn, input int st, input int er, input int fl, input int dm, input longint by, input bit [31:0] cr);
    int di = dq_wr[ch] % DQN;
    if (dq_n(ch) >= DQN) fail("TB: done-event ring overflow");
    dq_txn[ch][di] = txn; dq_status[ch][di] = st; dq_err[ch][di] = er; dq_fault[ch][di] = fl; dq_dom[ch][di] = dm; dq_bytes[ch][di] = by; dq_crc[ch][di] = cr;
    dq_wr[ch]++;
  endfunction
  function automatic void xr_add(input int ch, input longint pa, input int n);
    if (xr_cnt[ch] >= XRN) fail("TB: expected-run table overflow");
    else begin xr_pa[ch][xr_cnt[ch]] = pa; xr_n[ch][xr_cnt[ch]] = n; xr_cnt[ch]++; end
  endfunction
  function automatic void xr_clear(input int ch);              xr_cnt[ch] = 0; endfunction
  function automatic void xq_push(input int ch, input int txn, input int dom, input longint total, input bit crcx, input bit [31:0] crc,
                                  input int exec_n, input bit rec, input longint rpa);
    int i = xq_wr[ch] % XQN;
    if (xq_n(ch) >= XQN) fail("TB: expectation queue overflow");
    xq_txn[ch][i] = txn; xq_dom[ch][i] = dom; xq_status[ch][i] = 0; xq_err[ch][i] = 0; xq_err2[ch][i] = -1; xq_fault[ch][i] = -1;
    xq_blo[ch][i] = total; xq_bhi[ch][i] = total; xq_crc_exp[ch][i] = crcx; xq_crc[ch][i] = crc; xq_dlo[ch][i] = exec_n; xq_dhi[ch][i] = exec_n;
    xq_rec[ch][i] = rec; xq_rec_pa[ch][i] = rpa;
    xq_wr[ch]++;
  endfunction
  function automatic void xq_dup_first(input int ch);                 // duplicate the oldest entry (identical back-to-back commands)
    int f = xf(ch);
    xq_push(ch, xq_txn[ch][f], xq_dom[ch][f], xq_blo[ch][f], xq_crc_exp[ch][f], xq_crc[ch][f], xq_dlo[ch][f], xq_rec[ch][f], xq_rec_pa[ch][f]);
  endfunction
  function automatic void xq_clear(input int ch);              xq_rd[ch] = 0; xq_wr[ch] = 0; endfunction
  function automatic void pkg_init();
    for (int c = 0; c < MAXCH; c++) begin
      xq_rd[c] = 0; xq_wr[c] = 0; xr_cnt[c] = 0; if_rd[c] = 0; if_wr[c] = 0; dq_rd[c] = 0; dq_wr[c] = 0; x_uid[c] = -1; x_rep[c] = 1; x_weak[c] = 0;
      allow_pending_at_done[c] = 0; wr_pend[c] = 0; rd_pend[c] = 0;
    end
  endfunction

  function automatic void alloc_reset(input int ch);
    alloc_h[ch]  = IOVA_H + longint'(ch) * DATA_PER_CH;
    alloc_s[ch]  = IOVA_S + longint'(ch) * (64'h1_0000 / p_nch);
    alloc_st[ch] = IOVA_ST + longint'(ch) * (64'h1_0000 / p_nch);
  endfunction
  // allocate `size` bytes at byte offset `off` from a 64-byte boundary inside the channel's host window (disjoint, bump pointer)
  function automatic longint alloc_host(input int ch, input int size, input int off);
    longint a;
    a = (alloc_h[ch] + 64'h3F) & ~64'h3F;
    a = a + longint'(off);
    alloc_h[ch] = a + longint'(size) + 64'd64;
    if (alloc_h[ch] > IOVA_H + longint'(ch + 1) * DATA_PER_CH) fail("TB: host window exhausted for the channel");
    return a;
  endfunction
  function automatic longint alloc_local(input int ch, input int asid, input int size, input int off);
    longint a; longint lim;
    lim = (asid == 1) ? IOVA_S + longint'(ch + 1) * (64'h1_0000 / p_nch) : IOVA_ST + longint'(ch + 1) * (64'h1_0000 / p_nch);
    a = ((asid == 1) ? alloc_s[ch] : alloc_st[ch]) + 64'h3F;
    a = (a & ~64'h3F) + longint'(off);
    if (asid == 1) alloc_s[ch] = a + longint'(size) + 64'd64; else alloc_st[ch] = a + longint'(size) + 64'd64;
    if (a + size > lim) fail("TB: local window exhausted for the channel");
    return a;
  endfunction

  // ---------------------------------------------------------------- chain builder
  function automatic longint desc_base(input int ch);
    return IOVA_H + DESC_OFF + longint'(ch) * 64'h4000;
  endfunction
  function automatic longint desc_iova(input int ch, input int i);
    return desc_base(ch) + 64'd64 * longint'(cc_array[ch] ? i : ce_slot[ch][i]);
  endfunction

  function automatic void chain_begin(input int ch, input int dom, input int txn, input bit cpl, input bit crc, input bit irq, input bit array_mode);
    ce_n[ch] = 0; cc_dom[ch] = dom; cc_txn[ch] = txn; cc_cpl[ch] = cpl; cc_crc[ch] = crc; cc_irq[ch] = irq; cc_array[ch] = array_mode;
    cc_cpl_asid[ch] = 0; cc_desc_asid[ch] = 0;
    cc_cpl_iova[ch] = desc_base(ch) + 64'h3000;                      // 32-byte aligned record location above the 192 descriptor slots
  endfunction
  function automatic void chain_add(input int ch, input int sasid, input longint src, input int dasid, input longint dst, input int len, input bit ord);
    int i = ce_n[ch];
    if (i >= MAXE) fail("TB: chain too long for the builder");
    else begin
      ce_sasid[ch][i] = sasid; ce_dasid[ch][i] = dasid; ce_src[ch][i] = src; ce_dst[ch][i] = dst; ce_len[ch][i] = len; ce_ord[ch][i] = ord;
      ce_n[ch]++;
    end
  endfunction

  // write the descriptors into the image; linked mode scatters them over the first 192 slots of the channel's area (the record lives above)
  function automatic void chain_emit(input int ch);
    /*verilator no_inline_task*/
    int n = ce_n[ch];
    bit used [192];
    for (int s = 0; s < 192; s++) used[s] = 0;
    for (int i = 0; i < n; i++) begin
      int sl;
      if (cc_array[ch]) sl = i;
      else begin sl = $urandom_range(191, 0); while (used[sl]) sl = (sl + 1) % 192; end
      used[sl] = 1; ce_slot[ch][i] = sl;
    end
    for (int i = 0; i < n; i++) begin
      longint base = desc_iova(ch, i);
      bit last = (i == n - 1);
      bit [15:0] fl = 0;
      longint nx, cp;
      fl[silicaflux_dma_pkg::FLG_LAST]    = last;
      fl[silicaflux_dma_pkg::FLG_ARRAY]   = cc_array[ch] && !last;
      fl[silicaflux_dma_pkg::FLG_HEAD]    = (i == 0);
      fl[silicaflux_dma_pkg::FLG_ORDERED] = ce_ord[ch][i];
      fl[silicaflux_dma_pkg::FLG_CPL_EN]  = (i == 0) && cc_cpl[ch];
      fl[silicaflux_dma_pkg::FLG_CRC_EN]  = (i == 0) && cc_crc[ch];
      fl[silicaflux_dma_pkg::FLG_IRQ_EN]  = (i == 0) && cc_irq[ch];
      nx = (last || cc_array[ch]) ? 0 : desc_iova(ch, i + 1);
      cp = (i == 0 && cc_cpl[ch]) ? cc_cpl_iova[ch] : 0;
      dw32(cc_dom[ch], base + 0,  {fl, silicaflux_dma_pkg::OPC_COPY, silicaflux_dma_pkg::DESC_VERSION_1});
      dw32(cc_dom[ch], base + 4,  {16'(cc_dom[ch]), 16'(cc_txn[ch])});
      dw32(cc_dom[ch], base + 8,  {20'd0, 4'((i == 0 && cc_cpl[ch]) ? cc_cpl_asid[ch] : 0), 4'(ce_dasid[ch][i]), 4'(ce_sasid[ch][i])});
      dw32(cc_dom[ch], base + 12, 32'(ce_len[ch][i]));
      dw32(cc_dom[ch], base + 16, ce_src[ch][i][31:0]);   dw32(cc_dom[ch], base + 20, ce_src[ch][i][63:32]);
      dw32(cc_dom[ch], base + 24, ce_dst[ch][i][31:0]);   dw32(cc_dom[ch], base + 28, ce_dst[ch][i][63:32]);
      dw32(cc_dom[ch], base + 32, nx[31:0]);              dw32(cc_dom[ch], base + 36, nx[63:32]);
      dw32(cc_dom[ch], base + 40, cp[31:0]);              dw32(cc_dom[ch], base + 44, cp[63:32]);
      dw32(cc_dom[ch], base + 48, 32'(i));
      dw32(cc_dom[ch], base + 52, 0); dw32(cc_dom[ch], base + 56, 0); dw32(cc_dom[ch], base + 60, 0);
    end
  endfunction

  // single-descriptor chain written at a given slot of the channel's descriptor area (HEAD|LAST, linked form)
  function automatic void chain_emit_at(input int ch, input int slot);
    /*verilator no_inline_task*/
    longint base;
    bit [15:0] fl = 0;
    cc_array[ch] = 0;
    ce_slot[ch][0] = slot;
    base = desc_base(ch) + 64'd64 * longint'(slot);
    fl[silicaflux_dma_pkg::FLG_LAST] = 1; fl[silicaflux_dma_pkg::FLG_HEAD] = 1; fl[silicaflux_dma_pkg::FLG_CPL_EN] = cc_cpl[ch]; fl[silicaflux_dma_pkg::FLG_CRC_EN] = cc_crc[ch];
    dw32(cc_dom[ch], base + 0, {fl, silicaflux_dma_pkg::OPC_COPY, silicaflux_dma_pkg::DESC_VERSION_1});
    dw32(cc_dom[ch], base + 4, {16'(cc_dom[ch]), 16'(cc_txn[ch])});
    dw32(cc_dom[ch], base + 8, 32'd0);
    dw32(cc_dom[ch], base + 12, 32'(ce_len[ch][0]));
    dw32(cc_dom[ch], base + 16, ce_src[ch][0][31:0]); dw32(cc_dom[ch], base + 20, ce_src[ch][0][63:32]);
    dw32(cc_dom[ch], base + 24, ce_dst[ch][0][31:0]); dw32(cc_dom[ch], base + 28, ce_dst[ch][0][63:32]);
    dw32(cc_dom[ch], base + 32, 0); dw32(cc_dom[ch], base + 36, 0);
    dw32(cc_dom[ch], base + 40, cc_cpl_iova[ch][31:0]); dw32(cc_dom[ch], base + 44, cc_cpl_iova[ch][63:32]);
    for (int w = 12; w < 16; w++) dw32(cc_dom[ch], base + 4 * w, 0);
  endfunction

  // overwrite one 32-bit word of descriptor i of the chain (invalid-descriptor tests)
  function automatic void corrupt_word(input int ch, input int i, input int word, input bit [31:0] v);
    dw32(cc_dom[ch], desc_iova(ch, i) + 4 * word, v);
  endfunction

  // build the expectation for ONE completion: elements [0, exec_n) execute completely.  Source bytes come from the
  // current image, except bytes an EARLIER element of the same chain is expected to write (dependent copies, ORDERED).
  // append = 1 adds to the ownership set of the transaction(s) already expected on this channel.
  function automatic void chain_expect(input int ch, input int exec_n, input bit append);
    /*verilator no_inline_task*/
    int uid;
    bit [31:0] crc = 32'hFFFF_FFFF;
    longint total = 0;
    longint rpa;
    if (!append || xq_n(ch) == 0) begin
      uid_n++; x_uid[ch] = uid_n & 16'h7FFF; xr_clear(ch); x_rep[ch] = 1; x_weak[ch] = 0;
    end
    uid = x_uid[ch];
    for (int i = 0; i < exec_n; i++) begin
      longint run_pa = -1; int run_n = 0;
      for (int b = 0; b < ce_len[ch][i]; b++) begin
        longint sp = t_iova2pa(cc_dom[ch], ce_sasid[ch][i], ce_src[ch][i] + b, 1);
        longint dp = t_iova2pa(cc_dom[ch], ce_dasid[ch][i], ce_dst[ch][i] + b, 2);
        int si, di;
        if (sp < 0 || dp < 0) begin
          if (!exp_tolerant) fail($sformatf("TB: element %0d byte %0d not translatable (src %h dst %h)", i, b, sp, dp));
          if (run_n > 0) xr_add(ch, run_pa, run_n);
          run_n = 0; run_pa = -1; total++;
          continue;
        end
        si = pa2idx(sp); di = pa2idx(dp);
        if (di < 0 || si < 0) begin
          if (run_n > 0) xr_add(ch, run_pa, run_n);
          run_n = 0; run_pa = -1;
        end else begin
          byte unsigned v = (exp_own[si] == shortint'(uid) && exp_chk[si]) ? exp_val[si] : mem[si];
          exp_own[di] = shortint'(uid); exp_val[di] = v; exp_chk[di] = 1; wr_cnt[di] = 0; wr_ok[di] = 0;
          crc = crc32_step(crc, v);
          if (run_n > 0 && dp == run_pa + run_n) run_n++;
          else begin if (run_n > 0) xr_add(ch, run_pa, run_n); run_pa = dp; run_n = 1; end
        end
        total++;
      end
      if (run_n > 0) xr_add(ch, run_pa, run_n);
    end
    rpa = cc_cpl[ch] ? t_iova2pa(cc_dom[ch], cc_cpl_asid[ch], cc_cpl_iova[ch], 2) : -1;
    xq_push(ch, cc_txn[ch], cc_dom[ch], total, cc_crc[ch], ~crc, exec_n, cc_cpl[ch], rpa);
    // completion record: owned, value not byte-checked (the latency word is not predictable); fields verified by read-back
    if (cc_cpl[ch] && rpa >= 0) begin
      for (int b = 0; b < 32; b++) begin
        int ri = pa2idx(rpa + b);
        exp_own[ri] = shortint'(uid); exp_chk[ri] = 0; wr_cnt[ri] = 0;
        mem[ri] = 8'hA5;                         // pre-clear: a stale record can never be mistaken for a fresh one
      end
      xr_add(ch, rpa, 32);
    end
  endfunction

  // edit the expectation of the LAST pushed completion into a failure
  function automatic void set_fail(input int ch, input int err, input int fault, input longint blo, input longint bhi, input bit rec, input int dlo, input int dhi);
    int i = xl(ch);
    xq_status[ch][i] = 1; xq_err[ch][i] = err; xq_fault[ch][i] = fault; xq_blo[ch][i] = blo; xq_bhi[ch][i] = bhi;
    xq_rec[ch][i] = rec; xq_dlo[ch][i] = dlo; xq_dhi[ch][i] = dhi;
    xq_crc_exp[ch][i] = 0;
  endfunction

  function automatic void chain_finish(input int ch);
    chain_emit(ch);
    chain_expect(ch, ce_n[ch], 0);
  endfunction

  // release the ownership set of a finished channel
  function automatic void expect_release(input int ch);
    /*verilator no_inline_task*/
    for (int r = 0; r < xr_cnt[ch]; r++)
      for (int b = 0; b < xr_n[ch][r]; b++) begin
        int ix = pa2idx(xr_pa[ch][r] + b);
        if (ix >= 0) begin exp_own[ix] = -1; wr_cnt[ix] = 0; wr_ok[ix] = 0; end
      end
    xr_clear(ch); xq_clear(ch);
    x_rep[ch] = 1; x_weak[ch] = 0;
  endfunction

  function automatic void clear_expectations();
    for (int c = 0; c < MAXCH; c++) begin
      expect_release(c);
      if_clear(c); dq_clear(c);
      allow_pending_at_done[c] = 0;
    end
  endfunction

  // ---------------------------------------------------------------- bus monitors' checks (called by the module's slave hooks)
  bit rd_out_id [4096];
  bit wr_out_id [4096];
  bit dbg = 0;

  function automatic void mon_struct(input string what, input longint addr, input int len, input int size, input int burst);
    /*verilator no_inline_task*/
    int beats = len + 1;
    `TBCHK((addr % p_wb) == 0, $sformatf("%s address %h not beat aligned", what, addr))
    `TBCHK(beats >= 1 && beats <= p_maxb, $sformatf("%s burst of %0d beats exceeds the configured maximum %0d", what, beats, p_maxb))
    `TBCHK((addr % 4096) + longint'(beats) * p_wb <= 4096, $sformatf("%s burst at %h (%0d beats) crosses a 4 KiB boundary", what, addr, beats))
    `TBCHK(size == $clog2(p_wb), $sformatf("%s size %0d != full width", what, size))
    `TBCHK(burst == 1, $sformatf("%s burst type %0d != INCR", what, burst))
  endfunction

  function automatic void mon_ar(input int ch, input int id, input longint addr, input int len, input int asid, input int dom, input int size, input int burst, input int cyc);
    /*verilator no_inline_task*/
    if (dbg) $display("[%0d] AR ch=%0d id=%0d addr=%h len=%0d asid=%0d dom=%0d", cyc, ch, id, addr, len, asid, dom);
    mon_struct("AR", addr, len, size, burst);
    `TBCHK(!rd_out_id[id], $sformatf("AR: ID %0d reused while a read with that ID is outstanding", id))
    rd_out_id[id] = 1;
    `TBCHK(cur_dom_of(ch) >= 0, $sformatf("AR on channel %0d with no transaction in flight (traffic while idle / after reset)", ch))
    if (cur_dom_of(ch) >= 0) begin
      `TBCHK(dom == cur_dom_of(ch), $sformatf("AR sideband domain %0d != domain %0d bound to channel %0d", dom, cur_dom_of(ch), ch))
      `TBCHK(pa_allowed(cur_dom_of(ch), addr, addr + longint'(len + 1) * p_wb, 1),
             $sformatf("UNAUTHORISED READ: domain %0d reads PA [%h,%h) which it may not read (asid %0d)", cur_dom_of(ch), addr, addr + longint'(len + 1) * p_wb, asid))
    end
  endfunction

  function automatic void mon_aw(input int ch, input int id, input longint addr, input int len, input int asid, input int dom, input int size, input int burst, input int cyc);
    /*verilator no_inline_task*/
    if (dbg) $display("[%0d] AW ch=%0d id=%0d addr=%h len=%0d asid=%0d dom=%0d", cyc, ch, id, addr, len, asid, dom);
    mon_struct("AW", addr, len, size, burst);
    `TBCHK(!wr_out_id[id], $sformatf("AW: ID %0d reused while a write with that ID is outstanding", id))
    wr_out_id[id] = 1;
    `TBCHK(cur_dom_of(ch) >= 0, $sformatf("AW on channel %0d with no transaction in flight (traffic while idle / after reset)", ch))
    if (cur_dom_of(ch) >= 0) begin
      `TBCHK(dom == cur_dom_of(ch), $sformatf("AW sideband domain %0d != domain %0d bound to channel %0d", dom, cur_dom_of(ch), ch))
      `TBCHK(pa_allowed(cur_dom_of(ch), addr, addr + longint'(len + 1) * p_wb, 2),
             $sformatf("UNAUTHORISED WRITE: domain %0d writes PA [%h,%h) which it may not write (asid %0d)", cur_dom_of(ch), addr, addr + longint'(len + 1) * p_wb, asid))
    end
  endfunction

  // live byte check for one W beat (data/strb passed as 512-bit vectors)
  function automatic void mon_w(input int ch, input longint awaddr, input int beat, input bit [511:0] data, input bit [63:0] strb, input bit last, input int resp, input int cyc);
    /*verilator no_inline_task*/
    longint base = awaddr + longint'(beat) * p_wb;
    int first = -1, lastl = -1;
    if (dbg) $display("[%0d] W  ch=%0d beat=%0d addr=%h strb=%h last=%b", cyc, ch, beat, base, strb, last);
    `TBCHK((strb & ((64'd1 << p_wb) - 64'd1)) != 64'd0, $sformatf("W beat %0d of burst at %h has an all-zero strobe", beat, awaddr))
    for (int c = 0; c < p_wb; c++) if (strb[c]) begin
      if (first < 0) first = c;
      lastl = c;
    end
    for (int c = first; c <= lastl && first >= 0; c++) `TBCHK(strb[c], $sformatf("W strobe %h is not a contiguous run", strb))
    for (int c = 0; c < p_wb; c++) if (strb[c]) begin
      int ix = pa2idx(base + c);
      if (ix < 0) begin
        `TBCHK(resp == 3, $sformatf("write to unmapped PA %h not expected", base + c))
      end else begin
        `TBCHK(exp_own[ix] != -1, $sformatf("WRITE OUTSIDE THE EXPECTED SET: PA %h (channel %0d) written by DMA, nobody may write it", base + c, ch))
        if (exp_own[ix] != -1) begin
          `TBCHK(int'(exp_own[ix]) == x_uid[ch], $sformatf("write to a byte (PA %h) owned by another channel/transaction (owner uid %0d, channel %0d holds uid %0d)", base + c, exp_own[ix], ch, x_uid[ch]))
          if (exp_chk[ix]) `TBCHK(data[8*c +: 8] == exp_val[ix], $sformatf("WRONG DATA at PA %h: wrote %02h expected %02h", base + c, data[8*c +: 8], exp_val[ix]))
        end
        wr_cnt[ix]++;
        `TBCHK(wr_cnt[ix] <= x_rep[ch], $sformatf("DUPLICATE WRITE of PA %h", base + c))
      end
    end
  endfunction
  function automatic void mon_flush();
    for (int i = 0; i < 4096; i++) begin rd_out_id[i] = 0; wr_out_id[i] = 0; end
  endfunction
  function automatic void mon_rdone(input int id);  rd_out_id[id] = 0; endfunction
  function automatic void mon_bdone(input int id);  wr_out_id[id] = 0; endfunction

  // ---------------------------------------------------------------- per-completion and final-memory checks
  function automatic void chk_completion(input int ch, input string name);
    /*verilator no_inline_task*/
    int st, er, fl, dm, tx;
    longint by; bit [31:0] cr;
    int e_txn, e_dom, e_st, e_er, e_er2, e_fl, e_dlo, e_dhi; longint e_blo, e_bhi, e_rpa; bit e_cx, e_rec; bit [31:0] e_crc;
    `TBCHK(dq_n(ch) > 0, {name, ": no completion event"})
    `TBCHK(xq_n(ch) > 0, {name, ": TB has no expectation for this completion"})
    if (dq_n(ch) == 0 || xq_n(ch) == 0) return;
    begin
      int d = dq_f(ch), x = xf(ch);
      tx = dq_txn[ch][d]; st = dq_status[ch][d]; er = dq_err[ch][d]; fl = dq_fault[ch][d]; dm = dq_dom[ch][d]; by = dq_bytes[ch][d]; cr = dq_crc[ch][d];
      e_txn = xq_txn[ch][x]; e_dom = xq_dom[ch][x]; e_st = xq_status[ch][x]; e_er = xq_err[ch][x]; e_er2 = xq_err2[ch][x];
      e_fl = xq_fault[ch][x]; e_blo = xq_blo[ch][x]; e_bhi = xq_bhi[ch][x]; e_cx = xq_crc_exp[ch][x]; e_crc = xq_crc[ch][x];
      e_rec = xq_rec[ch][x]; e_rpa = xq_rec_pa[ch][x]; e_dlo = xq_dlo[ch][x]; e_dhi = xq_dhi[ch][x];
      dq_rd[ch]++; xq_rd[ch]++;
    end
    `TBCHK(st == e_st, $sformatf("%s: status %0d != expected %0d (err 0x%02h fault %0d)", name, st, e_st, er, fl))
    `TBCHK(er == e_er || er == e_er2, $sformatf("%s: error code 0x%02h != expected 0x%02h%s", name, er, e_er, (e_er2 >= 0) ? $sformatf(" or 0x%02h", e_er2) : ""))
    if (e_fl >= 0) `TBCHK(fl == e_fl, $sformatf("%s: fault %0d != expected %0d", name, fl, e_fl))
    `TBCHK(dm == e_dom, $sformatf("%s: done domain %0d != %0d", name, dm, e_dom))
    `TBCHK(by >= e_blo && by <= e_bhi, $sformatf("%s: bytes %0d outside expected [%0d,%0d]", name, by, e_blo, e_bhi))
    if (e_st == 0 && e_cx) `TBCHK(cr == e_crc, $sformatf("%s: CRC %h != expected %h", name, cr, e_crc))
    if (e_st == 0) `TBCHK(tx == e_txn, $sformatf("%s: txn id %0d != %0d", name, tx, e_txn))
    if (e_rec && e_rpa >= 0) begin
      bit [31:0] w [8];
      for (int i = 0; i < 8; i++) w[i] = bd_rd32(e_rpa + 4*i);
      `TBCHK(w[7][31:16] == silicaflux_dma_pkg::CPL_MAGIC, $sformatf("%s: completion record magic %h (record not written / not committed when completion was signalled)", name, w[7][31:16]))
      `TBCHK(w[0][3:0] == e_st, $sformatf("%s: record status %0d != %0d", name, w[0][3:0], e_st))
      `TBCHK(w[0][15:8] == e_er || w[0][15:8] == e_er2, $sformatf("%s: record err 0x%02h != 0x%02h", name, w[0][15:8], e_er))
      `TBCHK(w[0][31:16] == e_txn, $sformatf("%s: record txn %0d != %0d", name, w[0][31:16], e_txn))
      `TBCHK(w[1][15:0] == e_dom, $sformatf("%s: record domain %0d != %0d", name, w[1][15:0], e_dom))
      `TBCHK(longint'(w[2]) >= e_blo && longint'(w[2]) <= e_bhi, $sformatf("%s: record bytes %0d outside [%0d,%0d]", name, w[2], e_blo, e_bhi))
      `TBCHK(w[2] == by[31:0], $sformatf("%s: record bytes %0d != done bytes %0d", name, w[2], by))
      if (e_st == 0 && e_cx) begin
        `TBCHK(w[3] == e_crc, $sformatf("%s: record CRC %h != %h", name, w[3], e_crc))
        `TBCHK(w[7][0] == 1'b1, $sformatf("%s: record CRC_VALID not set", name))
      end
      if (e_st != 0) `TBCHK(w[7][0] == 1'b0, $sformatf("%s: record CRC_VALID set on a failed transaction", name))
      `TBCHK(w[7][1] == (e_st == 0), $sformatf("%s: record COMMITTED flag %b wrong", name, w[7][1]))
      `TBCHK(w[6] != 0, $sformatf("%s: record latency is zero", name))
      `TBCHK(int'(w[1][31:16]) >= e_dlo && int'(w[1][31:16]) <= e_dhi, $sformatf("%s: record descriptor count %0d outside [%0d,%0d]", name, w[1][31:16], e_dlo, e_dhi))
    end
    tb_bytes_ok += (e_st == 0) ? by : 0;
  endfunction

  function automatic void chk_memory(input int ch, input string name);
    /*verilator no_inline_task*/
    int nbad_before = errors;
    for (int r = 0; r < xr_cnt[ch]; r++)
      for (int b = 0; b < xr_n[ch][r]; b++) begin
        int ix = pa2idx(xr_pa[ch][r] + b);
        if (ix >= 0 && exp_chk[ix] && exp_own[ix] == shortint'(x_uid[ch])) begin
          if (!x_weak[ch]) begin
            `TBCHK(wr_cnt[ix] == x_rep[ch], $sformatf("%s: DATA LOSS/DUPLICATION: PA %h written %0d times (expected %0d)", name, xr_pa[ch][r] + b, wr_cnt[ix], x_rep[ch]))
            `TBCHK(mem[ix] == exp_val[ix], $sformatf("%s: MEMORY MISMATCH at PA %h: %02h expected %02h", name, xr_pa[ch][r] + b, mem[ix], exp_val[ix]))
          end else begin
            `TBCHK(wr_cnt[ix] <= x_rep[ch], $sformatf("%s: duplicate write PA %h", name, xr_pa[ch][r] + b))
            if (wr_ok[ix] > 0 && wr_pend[ch] == 0 && mem[ix] != exp_val[ix]) fail($sformatf("%s: wrong committed data at PA %h", name, xr_pa[ch][r] + b));
          end
          if (errors - nbad_before > 8) break;
        end
      end
    expect_release(ch);
  endfunction

  function automatic void chk_txn(input int ch, input string name);
    chk_completion(ch, name);
    chk_memory(ch, name);
  endfunction
  // ---------------------------------------------------------------- random element / chain generation
  function automatic int rand_len(input int cls);
    case (cls)
      0: return $urandom_range(1, 3);
      1: return $urandom_range(1, 2 * p_wb + 3);
      2: return $urandom_range(p_wb, 300);
      3: return $urandom_range(300, 3000);
      default: return $urandom_range(3000, 12000);
    endcase
  endfunction

  function automatic void add_rand_elem(input int ch, input int cls, input bit ord);
    /*verilator no_inline_task*/
    int len, sa, da, so, dof;
    bit dep;
    longint s, d;
    len = rand_len(cls);
    case ($urandom_range(9, 0))
      0, 1: begin sa = 0; da = 1; end
      2, 3: begin sa = 1; da = 0; end
      4:    begin sa = 2; da = 0; end
      5:    begin sa = 0; da = 2; end
      6:    begin sa = 1; da = 2; end
      default: begin sa = 0; da = 0; end
    endcase
    // an ORDERED element reads (part of) what the previous element wrote in half of the cases: a read-after-write dependency that is only
    // correct because of the barrier
    dep = ord && (ce_n[ch] > 0) && ($urandom_range(1, 0) == 1) && (ce_len[ch][ce_n[ch] - 1] > 0);
    if (dep) sa = ce_dasid[ch][ce_n[ch] - 1];
    if ((sa != 0 || da != 0) && len > 1000) len = 1000;
    so = $urandom_range(2 * p_wb + 3, 0); dof = $urandom_range(2 * p_wb + 3, 0);
    if (dep) begin
      int pl = ce_len[ch][ce_n[ch] - 1];
      int o;
      if (len > pl) len = pl;
      o = $urandom_range(pl - len, 0);
      s = ce_dst[ch][ce_n[ch] - 1] + longint'(o);
    end else begin
      s = (sa == 0) ? alloc_host(ch, len + 8, so) : alloc_local(ch, sa, len + 8, so);
    end
    d = (da == 0) ? alloc_host(ch, len + 8, dof) : alloc_local(ch, da, len + 8, dof);
    chain_add(ch, sa, s, da, d, len, ord);
  endfunction

  function automatic void random_chain(input int ch, input int dom, input int nmax, input int maxcls, input bit allow_array);
    /*verilator no_inline_task*/
    int n = $urandom_range(nmax, 1);
    alloc_reset(ch);
    chain_begin(ch, dom, $urandom_range(65535, 1), ($urandom_range(2, 0) != 0), ($urandom_range(1, 0) == 1), 0, allow_array && ($urandom_range(1, 0) == 1));
    for (int i = 0; i < n; i++) add_rand_elem(ch, $urandom_range(maxcls, 0), (i > 0) && ($urandom_range(5, 0) == 0));
    chain_finish(ch);
  endfunction
endpackage
