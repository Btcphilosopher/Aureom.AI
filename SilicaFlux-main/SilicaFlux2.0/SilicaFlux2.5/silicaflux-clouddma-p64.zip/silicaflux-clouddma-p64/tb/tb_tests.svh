// ============================================================================
// tb_tests.svh -- tests.  Each test builds transactions, predicts the outcome from the descriptors and the memory
// image (never from the DUT), runs them and lets the monitors / scoreboard judge.
// ============================================================================
  import silicaflux_dma_pkg::*;

  int csr_last = 0;
  localparam int FDOM = (EXT_IOMMU != 0) ? int'(FAULT_NO_MAP) : int'(FAULT_DOMAIN);     // a real IOMMU cannot tell "another domain's" from "unmapped"

  // ------------------------------------------------------------ basic services
  task automatic csr_wr(input int addr, input bit [31:0] data);
    @(negedge clk); csr_req_valid = 1; csr_req_write = 1; csr_req_addr = 12'(addr); csr_req_wdata = data;
    @(negedge clk); csr_req_valid = 0; csr_req_write = 0;
  endtask
  task automatic csr_rd(input int addr, output bit [31:0] data);
    @(negedge clk); csr_req_valid = 1; csr_req_write = 0; csr_req_addr = 12'(addr);
    @(posedge clk); #1;
    @(negedge clk); csr_req_valid = 0;
    data = csr_rsp_rdata;
    csr_last = csr_rsp_err ? 1 : 0;
  endtask

  task automatic reset_dut();
    rst_n = 0; for (int c = 0; c < NUM_CH; c++) drv_val(c, 1'b0); csr_req_valid = 0;
    repeat (4) @(negedge clk);
    slave_flush();
    clear_expectations();
    rst_n = 1;
    repeat (3) @(negedge clk);
  endtask

  task automatic engine_up();
    setup_domains();
    csr_wr(CSR_CTRL, 32'h1);                         // enable
    csr_wr(CSR_TIMEOUT, 32'd0);
  endtask

  task automatic profile(input int p);
    cfg_ar_p = 100; cfg_aw_p = 100; cfg_w_p = 100; cfg_r_p = 100; cfg_b_p = 100;
    cfg_lat_min = 1; cfg_lat_max = 1; cfg_b_min = 1; cfg_b_max = 1;
    cfg_reorder = 0; cfg_interleave = 0; cfg_hang_rd = 0; cfg_hang_wr = 0; inj_kind = 0; cfg_r_inorder = 0; cfg_b_inorder = 0;
    for (int c = 0; c < NUM_CH; c++) drv_rdy(c, 1'b1);
    case (p)
      0: ;                                                                                   // ideal
      1: begin cfg_lat_min = 8; cfg_lat_max = 40; cfg_b_min = 4; cfg_b_max = 30; end         // slow memory
      2: begin cfg_ar_p = 40; cfg_aw_p = 40; cfg_w_p = 50; cfg_r_p = 50; cfg_b_p = 60; cfg_lat_min = 2; cfg_lat_max = 6; end   // back-pressure
      3: begin cfg_ar_p = 70; cfg_aw_p = 60; cfg_w_p = 70; cfg_r_p = 70; cfg_b_p = 70; cfg_lat_min = 2; cfg_lat_max = 60; cfg_b_min = 1; cfg_b_max = 40;
               cfg_reorder = (REORDER_OK != 0); cfg_interleave = (REORDER_OK != 0); end                                           // chaos
      4: begin cfg_lat_min = 3; cfg_lat_max = 50; cfg_b_min = 2; cfg_b_max = 40; cfg_reorder = (REORDER_OK != 0); end            // reordering only
      default: ;
    endcase
  endtask

  task automatic submit(input int ch, input longint head, input int dom_cmd, input int dasid);
    int guard = 0;
    @(negedge clk);
    while (!cmd_ready[ch] && guard < 100000) begin @(negedge clk); guard++; end
    drv_cmd(ch, head, dom_cmd, dasid, 1'b1);
    if_push(ch, dom_cmd);
    @(negedge clk); drv_val(ch, 1'b0);
  endtask

  task automatic wait_done(input int ch, input int max_cyc, input string name);
    int t = 0;
    if (dbg) $display("[%0d] --- waiting for completion of: %s", cyc, name);
    while (dq_n(ch) == 0 && t < max_cyc) begin @(negedge clk); t++; end
    if (dq_n(ch) == 0) begin fail($sformatf("%s: TIMEOUT waiting for completion on channel %0d", name, ch)); end
  endtask

  task automatic run_ch(input int ch, input string name);
    submit(ch, desc_iova(ch, 0), cc_dom[ch], cc_desc_asid[ch]);
    wait_done(ch, 3_000_000, name);
    repeat (2) @(negedge clk);
    chk_txn(ch, name);
  endtask

  int test_err0;
  task automatic begin_test(input string name);
    test_err0 = errors; tests_run++;
    $display("[%0t] test: %s", $time, name);
  endtask
  task automatic end_test(input string name);
    if (errors != test_err0) begin tests_failed++; $display("      -> FAILED (%0d new error(s))", errors - test_err0); end
  endtask

  // ------------------------------------------------------------ 1. zero length
  task automatic t_zero_length();
    int ch = 0, w0, r0;
    begin_test("zero-length handling");
    alloc_reset(ch);
    // (a) one zero-length element + completion record: no data bus traffic, exactly one descriptor read and one record write
    chain_begin(ch, 0, 101, 1, 1, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 64, 0), 0, alloc_host(ch, 64, 0), 0, 0);
    chain_finish(ch);
    w0 = n_wr_bursts; r0 = n_rd_bursts;
    run_ch(ch, "zero-length single element");
    `TBCHK(n_wr_bursts - w0 == 1, $sformatf("zero-length: %0d write bursts (only the completion record is allowed)", n_wr_bursts - w0))
    `TBCHK(n_rd_bursts - r0 == 1, $sformatf("zero-length: %0d read bursts (only the descriptor fetch is allowed)", n_rd_bursts - r0))
    // (b) zero-length elements between real ones, array mode
    alloc_reset(ch);
    chain_begin(ch, 0, 102, 1, 1, 0, 1);
    chain_add(ch, 0, alloc_host(ch, 8, 0), 0, alloc_host(ch, 8, 0), 0, 0);
    chain_add(ch, 0, alloc_host(ch, 300, 3), 0, alloc_host(ch, 300, 5), 300, 0);
    chain_add(ch, 1, alloc_local(ch, 1, 8, 0), 1, alloc_local(ch, 1, 8, 0), 0, 0);
    chain_finish(ch);
    run_ch(ch, "zero-length between real elements");
    // (c) zero-length element whose addresses are NOT mapped: no access, no permission query, success (documented)
    alloc_reset(ch);
    chain_begin(ch, 1, 103, 0, 0, 0, 0);
    chain_add(ch, 0, 64'h3_0000_0000, 0, 64'h3_0000_1000, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 64, 0), 0, alloc_host(ch, 64, 0), 64, 0);
    chain_finish(ch);
    run_ch(ch, "zero-length element at unmapped addresses");
    // (d) all elements zero-length, no record, CRC enabled: no write burst at all
    alloc_reset(ch);
    chain_begin(ch, 2, 104, 0, 1, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 8, 0), 0, alloc_host(ch, 8, 0), 0, 0);
    chain_add(ch, 0, alloc_host(ch, 8, 0), 0, alloc_host(ch, 8, 0), 0, 0);
    chain_finish(ch);
    w0 = n_wr_bursts;
    run_ch(ch, "all zero-length, no record");
    `TBCHK(n_wr_bursts == w0, "all-zero-length chain without record produced write traffic")
    end_test("zero-length");
  endtask

  // ------------------------------------------------------------ 2. single bytes, 3. unaligned tails
  task automatic t_single_byte();
    int offs [8]; int no = 0;
    begin_test("single-byte transfers, all alignment combinations");
    offs[0] = 0; offs[1] = 1; offs[2] = 2; offs[3] = WB / 2; offs[4] = WB - 1; offs[5] = WB; offs[6] = WB + 1; offs[7] = 2 * WB - 1;
    for (int a = 0; a < 8; a++) for (int b = 0; b < 8; b++) begin
      int ch = 0;
      begin
        alloc_reset(ch);
        chain_begin(ch, (a + b) % 4, 200 + a * 8 + b, (b % 2 == 0), (a % 2 == 0), 0, 0);
        chain_add(ch, 0, alloc_host(ch, 8, offs[a]), (b % 3 == 0) ? 1 : 0, ((b % 3 == 0) ? alloc_local(ch, 1, 8, offs[b]) : alloc_host(ch, 8, offs[b])), 1, 0);
        chain_finish(ch);
        run_ch(ch, $sformatf("single byte src_off=%0d dst_off=%0d", offs[a], offs[b]));
      end
    end
    end_test("single-byte");
  endtask

  task automatic t_unaligned_tails();
    int lens [20];
    begin_test("unaligned heads and tails");
    lens[0] = WB - 1; lens[1] = WB; lens[2] = WB + 1; lens[3] = 2 * WB - 1; lens[4] = 3; lens[5] = 5; lens[6] = 7; lens[7] = 15; lens[8] = 17;
    lens[9] = 63; lens[10] = 65; lens[11] = 255; lens[12] = 257; lens[13] = 4095; lens[14] = 4096; lens[15] = 4097; lens[16] = 8191; lens[17] = 8193;
    lens[18] = MAXB * WB; lens[19] = MAXB * WB + 1;
    for (int k = 0; k < 20; k++) begin
      int ch = 0;
      alloc_reset(ch);
      chain_begin(ch, k % 4, 300 + k, 1, 1, 0, 0);
      chain_add(ch, 0, alloc_host(ch, lens[k] + 8, $urandom_range(WB * 2, 0)), 0, alloc_host(ch, lens[k] + 8, $urandom_range(WB * 2, 0)), lens[k], 0);
      chain_finish(ch);
      run_ch(ch, $sformatf("len=%0d", lens[k]));
    end
    end_test("unaligned");
  endtask

  // ------------------------------------------------------------ 4. multiple segments (both chain forms, mixed address spaces)
  task automatic t_multi_segment();
    begin_test("scatter-gather: multiple noncontiguous segments, linked and array chains");
    for (int it = 0; it < 24; it++) begin
      int ch = it % NUM_CH;
      random_chain(ch, it % 4, 12, 3, 1);
      run_ch(ch, $sformatf("multi-segment #%0d (%0d elements)", it, ce_n[ch]));
    end
    // gather: many small sources into ONE contiguous destination; scatter: one source into many destinations
    begin
      int ch = 0; longint dst, src;
      alloc_reset(ch);
      chain_begin(ch, 0, 401, 1, 1, 0, 0);
      dst = alloc_host(ch, 4096, 5);
      for (int i = 0; i < 16; i++) chain_add(ch, 0, alloc_host(ch, 100, $urandom_range(7, 0)), 0, dst + 61 * i, 61, 0);
      chain_finish(ch); run_ch(ch, "gather 16 sources -> 1 destination");
      alloc_reset(ch);
      chain_begin(ch, 0, 402, 1, 1, 0, 1);
      src = alloc_host(ch, 4096, 3);
      for (int i = 0; i < 16; i++) chain_add(ch, 0, src + 97 * i, 0, alloc_host(ch, 128, $urandom_range(7, 0)), 97, 0);
      chain_finish(ch); run_ch(ch, "scatter 1 source -> 16 destinations");
    end
    end_test("multi-segment");
  endtask

  // ------------------------------------------------------------ 5. long transfers and long chains
  localparam int LONGLEN  = (TOTLOG2 < 24) ? (1 << TOTLOG2) - 4096 : 200_000;
  localparam int ABORTLEN = (TOTLOG2 < 24) ? (1 << TOTLOG2) - 4096 : 150_000;
  task automatic t_long();
    int ch = 0;
    begin_test("long transfers");
    alloc_reset(ch);
    chain_begin(ch, 1, 501, 1, 1, 0, 0);
    chain_add(ch, 0, alloc_host(ch, LONGLEN + 8, 3), 0, alloc_host(ch, LONGLEN + 8, 7), LONGLEN, 0);
    chain_finish(ch);
    run_ch(ch, $sformatf("%0d-byte single element", LONGLEN));
    alloc_reset(ch);
    chain_begin(ch, 2, 502, 1, 1, 0, 0);
    for (int i = 0; i < MAX_CHAIN - 1; i++) chain_add(ch, 0, alloc_host(ch, 3000, $urandom_range(7, 0)), 0, alloc_host(ch, 3000, $urandom_range(7, 0)), $urandom_range(10, 2500), 0);
    chain_finish(ch);
    run_ch(ch, $sformatf("chain of %0d descriptors (the maximum minus one)", MAX_CHAIN - 1));
    alloc_reset(ch);
    chain_begin(ch, 3, 503, 1, 1, 0, 1);
    for (int i = 0; i < MAX_CHAIN; i++) chain_add(ch, 0, alloc_host(ch, 600, $urandom_range(7, 0)), 0, alloc_host(ch, 600, $urandom_range(7, 0)), $urandom_range(1, 500), 0);
    chain_finish(ch);
    run_ch(ch, $sformatf("array chain of exactly %0d descriptors (the maximum)", MAX_CHAIN));
    end_test("long");
  endtask

  // ------------------------------------------------------------ 6/7/8. concurrency, back-pressure, reordering
  task automatic stress_ch(input int ch, input int iters, input string tag);
    for (int it = 0; it < iters; it++) begin
      random_chain(ch, ($urandom_range(3, 0) + ch) % 4, 8, 3, 1);
      run_ch(ch, $sformatf("%s ch%0d #%0d", tag, ch, it));
    end
  endtask

  // ------------------------------------------------------------ concurrency without fork/join
  // Persistent per-channel worker processes poll a job table; the sequencer dispatches jobs and waits until all are done.
  // (fork/join crashed the simulator version in use at the end of some forks; this needs no fork at all.)
  localparam int J_STRESS = 1, J_MCRUN = 2, J_ATTACK = 3, J_VICTIM = 4, J_MCLOAD = 5, J_PERF = 6;
  int    job_kind [NUM_CH];
  int    job_a    [NUM_CH];
  int    job_b    [NUM_CH];
  string job_s    [NUM_CH];
  bit    job_busy [NUM_CH];
  initial for (int c = 0; c < NUM_CH; c++) begin job_kind[c] = 0; job_a[c] = 0; job_b[c] = 0; job_s[c] = ""; job_busy[c] = 0; end

  task automatic run_job(input int ch, input int kind, input int a, input int b, input string s);
    case (kind)
      J_STRESS: stress_ch(ch, a, s);
      J_MCRUN:  mc_run(ch, a, s);
      J_ATTACK: mc_attacker();
      J_VICTIM: mc_victim(ch, a, s);
      J_MCLOAD: mc_load(ch, a, b);
      J_PERF:   perf_ch(ch, s);
      default: ;
    endcase
  endtask
  genvar gw;
  generate for (gw = 0; gw < NUM_CH; gw++) begin : g_worker
    initial forever begin
      @(negedge clk);
      if (job_kind[gw] != 0) begin
        run_job(gw, job_kind[gw], job_a[gw], job_b[gw], job_s[gw]);
        job_kind[gw] = 0; job_busy[gw] = 0;
      end
    end
  end endgenerate
  task automatic dispatch(input int ch, input int kind, input int a, input int b, input string s);
    job_a[ch] = a; job_b[ch] = b; job_s[ch] = s; job_busy[ch] = 1; job_kind[ch] = kind;
  endtask
  task automatic join_jobs();
    bit any = 1;
    while (any) begin
      @(negedge clk);
      any = 0;
      for (int c = 0; c < NUM_CH; c++) if (job_busy[c]) any = 1;
    end
  endtask

  // run `iters` random transactions on EVERY channel concurrently
  task automatic stress_all(input int iters, input string tag);
    for (int c = 0; c < NUM_CH; c++) dispatch(c, J_STRESS, iters, 0, tag);
    join_jobs();
  endtask

  task automatic t_profiles();
    string names [5] = '{"ideal", "slow-memory", "back-pressure", "chaos(reorder+stall)", "reorder"};
    for (int p = 0; p < 5; p++) begin
      begin_test($sformatf("profile %0d: %s", p, names[p]));
      profile(p);
      stress_all(10, names[p]);
      profile(0);
      end_test("profile");
    end
  endtask

  bit done_stall_on = 0;
  always @(negedge clk) if (done_stall_on) for (int c = 0; c < NUM_CH; c++) drv_rdy(c, ($urandom_range(3, 0) == 0));
  task automatic t_done_backpressure();
    begin_test("completion back-pressure (done_ready toggling)");
    profile(2);
    done_stall_on = 1;
    stress_all(6, "done-stall");
    done_stall_on = 0;
    for (int c = 0; c < NUM_CH; c++) drv_rdy(c, 1'b1);
    profile(0);
    end_test("done-backpressure");
  endtask

  task automatic t_reorder_stats();
    begin_test("response reordering is exercised");
    profile(3);
    for (int it = 0; it < 6; it++) begin
      int ch = 0;
      alloc_reset(ch);
      chain_begin(ch, 0, 600 + it, 1, 1, 0, 0);
      for (int i = 0; i < 4; i++) chain_add(ch, 0, alloc_host(ch, 6000, 1), 0, alloc_host(ch, 6000, 2), $urandom_range(3000, 5000), 0);
      chain_finish(ch);
      run_ch(ch, $sformatf("large element chain #%0d", it));
    end
    profile(0);
    if (REORDER_OK != 0) begin
      if (RD_OUT > 1) `TBCHK(n_rd_ooo > 0, "read responses were never reordered by the slave (reordering not exercised)")
      if (WR_OUT > 1) `TBCHK(n_wr_ooo > 0, "write responses were never reordered by the slave (reordering not exercised)")
    end
    `TBCHK(max_rd_out >= 2 || RD_OUT == 1, $sformatf("never more than %0d read burst(s) outstanding", max_rd_out))
    `TBCHK(max_wr_out >= 2 || WR_OUT == 1, $sformatf("never more than %0d write burst(s) outstanding", max_wr_out))
    end_test("reorder");
  endtask

  // ------------------------------------------------------------ ORDERED barrier (dependent copy)
  task automatic t_ordered();
    int ch = 0; longint a, b, c, d3;
    begin_test("ORDERED flag: dependent copies (head, tail and multi-step dependencies)");
    for (int it = 0; it < 6; it++) begin
      profile(it % 5);
      alloc_reset(ch);
      chain_begin(ch, it % 4, 700 + it, 1, 1, 0, it % 2);
      a = alloc_host(ch, 5000, 3); b = alloc_host(ch, 5000, 6); c = alloc_host(ch, 5000, 1);
      chain_add(ch, 0, a, 0, b, 3000 + 100 * it, 0);
      chain_add(ch, 0, b, 0, c, 3000 + 100 * it, 1);              // reads what element 0 writes: only legal with the barrier
      chain_finish(ch);
      run_ch(ch, $sformatf("dependent copy #%0d", it));
    end
    // (b) TAIL dependency: element 1 reads the LAST bytes element 0 writes, i.e. the bytes that are committed last. (In (a) element 1 starts
    //     with bytes that were written long ago, so a missing barrier hides.)  Mutant M18.
    for (int it = 0; it < 8; it++) begin
      int l0 = 1200 + 350 * it; int t1 = 8 + 40 * it;
      profile((it + 1) % 5);
      alloc_reset(ch);
      chain_begin(ch, it % 4, 720 + it, 1, 1, 0, it % 2);
      a = alloc_host(ch, l0 + 8, 3); b = alloc_host(ch, l0 + 8, it % 8); c = alloc_host(ch, t1 + 8, 1);
      chain_add(ch, 0, a, 0, b, l0, 0);
      chain_add(ch, 0, b + longint'(l0 - t1), 0, c, t1, 1);
      chain_finish(ch);
      run_ch(ch, $sformatf("tail dependency #%0d (%0d bytes, tail %0d)", it, l0, t1));
    end
    // (c) SHORT elements, three steps deep: all of element 0 is still in flight when element 1 could issue its reads
    for (int it = 0; it < 10; it++) begin
      int n0 = 1 + 7 * it;
      profile(it % 5);
      alloc_reset(ch);
      chain_begin(ch, it % 4, 740 + it, 0, 1, 0, it % 2);
      a = alloc_host(ch, n0 + 8, it % 8); b = alloc_host(ch, n0 + 8, (3 * it) % 8); c = alloc_host(ch, n0 + 8, 1); d3 = alloc_host(ch, n0 + 8, 5);
      chain_add(ch, 0, a, 0, b, n0, 0);
      chain_add(ch, 0, b, 0, c, n0, 1);
      chain_add(ch, 0, c, 0, d3, n0, 1);
      chain_finish(ch);
      run_ch(ch, $sformatf("short three-step dependency #%0d (%0d bytes)", it, n0));
    end
    profile(0);
    end_test("ordered");
  endtask

  // ------------------------------------------------------------ 9. domain violations and refused accesses
  task automatic viol_case(input string name, input int e_err, input int e_fault, input bit wk_unused);
    int ch = 0; int v0 = viol_seen;
    submit(ch, desc_iova(ch, 0), cc_dom[ch], 0);
    wait_done(ch, 2_000_000, name);
    repeat (2) @(negedge clk);

    chk_txn(ch, name);
  endtask

  task automatic t_domain_violations();
    int ch = 0; longint s0, d0;
    int w0, r0, v0;
    begin_test("domain / permission violations");
    // (1) descriptor DOMAIN claims another tenant than the hardware binding
    alloc_reset(ch);
    chain_begin(ch, 1, 800, 0, 0, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 100, 0), 0, alloc_host(ch, 100, 0), 100, 0);
    chain_emit(ch); corrupt_word(ch, 0, 1, {16'd2, 16'd800}); chain_expect(ch, 0, 0);
    set_fail(ch, ERR_DOMAIN_MISMATCH, -1, 0, 0, 0, 0, 0);
    w0 = n_wr_bursts; v0 = viol_seen;
    viol_case("descriptor claims another domain", ERR_DOMAIN_MISMATCH, -1, 0);
    `TBCHK(n_wr_bursts == w0, "domain mismatch: write traffic occurred")
    `TBCHK(viol_seen == v0 + 1, "domain mismatch: violation event not raised")
    // (2) source read inside ANOTHER domain's private window
    alloc_reset(ch);
    chain_begin(ch, 1, 801, 1, 0, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 600, 0), 0, alloc_host(ch, 600, 0), 500, 0);
    chain_add(ch, 0, IOVA_PRIV + 64'h2_0000 * 0 + 2 * 64'h1_0000, 0, alloc_host(ch, 600, 0), 64, 0);
    chain_emit(ch); exp_tolerant = 0; chain_expect(ch, 1, 0);
    set_fail(ch, ERR_PERM_SRC, FDOM, 0, 500, 1, 1, 2); x_weak[ch] = 1;
    v0 = viol_seen;
    viol_case("read another domain's private memory", ERR_PERM_SRC, FDOM, 1);
    `TBCHK(viol_seen == v0 + 1, "foreign read: violation event not raised")
    // (3) destination write into another domain's private window
    alloc_reset(ch);
    chain_begin(ch, 1, 802, 1, 0, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 600, 0), 0, IOVA_PRIV + 3 * 64'h1_0000, 100, 0);
    chain_emit(ch); chain_expect(ch, 0, 0);
    set_fail(ch, ERR_PERM_DST, FDOM, 0, 0, 1, 0, 1); x_weak[ch] = 1;
    viol_case("write another domain's private memory", ERR_PERM_DST, FDOM, 1);
    // (4) write into the read-only window of the OWN domain
    alloc_reset(ch);
    chain_begin(ch, 2, 803, 1, 0, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 600, 0), 0, IOVA_RO + 128, 100, 0);
    chain_emit(ch); chain_expect(ch, 0, 0);
    set_fail(ch, ERR_PERM_DST, int'(FAULT_PERM), 0, 0, 1, 0, 1); x_weak[ch] = 1;
    viol_case("write into a read-only window", ERR_PERM_DST, int'(FAULT_PERM), 1);
    // (5) reading the read-only window is allowed (and copying it elsewhere)
    alloc_reset(ch);
    chain_begin(ch, 2, 804, 1, 1, 0, 0);
    chain_add(ch, 0, IOVA_RO + 100, 0, alloc_host(ch, 600, 3), 300, 0);
    chain_finish(ch); run_ch(ch, "read from a read-only window is legal");
    // (6) destination unmapped
    alloc_reset(ch);
    chain_begin(ch, 3, 805, 0, 0, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 600, 0), 0, 64'h3_0000_0000, 100, 0);
    chain_emit(ch); chain_expect(ch, 0, 0);
    set_fail(ch, ERR_PERM_DST, int'(FAULT_NO_MAP), 0, 0, 0, 0, 0); x_weak[ch] = 1;
    viol_case("write to an unmapped IOVA", ERR_PERM_DST, int'(FAULT_NO_MAP), 1);
    // (7) transfer running off the end of the window: the part inside the window may be written, the rest is refused
    alloc_reset(ch);
    chain_begin(ch, 0, 806, 0, 0, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 600, 0), 0, IOVA_H + HOST_WIN - 100, 300, 0);
    chain_emit(ch); exp_tolerant = 1; chain_expect(ch, 1, 0); exp_tolerant = 0;
    set_fail(ch, ERR_PERM_DST, int'(FAULT_NO_MAP), 0, 100, 0, 0, 1); x_weak[ch] = 1;
    viol_case("write running past the end of the window", ERR_PERM_DST, int'(FAULT_NO_MAP), 1);
    // (8) completion record location not writable: data is committed, status is ERROR/PERM_CPL, no record
    alloc_reset(ch);
    chain_begin(ch, 1, 807, 1, 1, 0, 0);
    cc_cpl_iova[ch] = IOVA_RO + 64'h100;
    chain_add(ch, 0, alloc_host(ch, 700, 0), 0, alloc_host(ch, 700, 0), 500, 0);
    chain_finish(ch);
    set_fail(ch, ERR_PERM_CPL, int'(FAULT_PERM), 500, 500, 0, 1, 1);
    viol_case("completion record in a read-only window", ERR_PERM_CPL, int'(FAULT_PERM), 0);
    // (9) descriptor fetch refused: head inside another domain's private memory / unmapped
    alloc_reset(ch);
    chain_begin(ch, 1, 808, 0, 0, 0, 0);
    chain_expect(ch, 0, 0);
    set_fail(ch, ERR_PERM_DESC, FDOM, 0, 0, 0, 0, 0);
    r0 = n_rd_bursts;
    submit(ch, IOVA_PRIV + 2 * 64'h1_0000, 1, 0); wait_done(ch, 100000, "descriptor in foreign memory"); repeat (2) @(negedge clk); chk_txn(ch, "descriptor fetch from another domain's memory");
    `TBCHK(n_rd_bursts == r0, "refused descriptor fetch still reached the bus")
    chain_expect(ch, 0, 0);
    set_fail(ch, ERR_PERM_DESC, int'(FAULT_NO_MAP), 0, 0, 0, 0, 0);
    submit(ch, 64'h3_1000_0000, 1, 0); wait_done(ch, 100000, "descriptor unmapped"); repeat (2) @(negedge clk); chk_txn(ch, "descriptor fetch from an unmapped IOVA");
    // (10) same IOVA, different domains: each domain must hit ITS OWN physical memory
    for (int d = 0; d < 4; d++) begin
      alloc_reset(ch);
      chain_begin(ch, d, 810 + d, 1, 1, 0, 0);
      s0 = IOVA_H + 64'h1000; d0 = IOVA_H + 64'h3_0000;
      chain_add(ch, 0, s0, 0, d0, 2000, 0);
      chain_finish(ch);
      run_ch(ch, $sformatf("same IOVA, domain %0d", d));
    end
    end_test("domain-violations");
  endtask

  // ------------------------------------------------------------ 10. invalid descriptors
  // one case: build a 3-element chain (2 for the tail), corrupt a word of descriptor k, expect `err` and k elements executed
  task automatic bad_desc(input string name, input int k, input int word, input bit [31:0] val, input int err, input bit cpl_known);
    int ch = 0;
    int n = (k >= 2) ? k + 1 : 3;
    longint tot = 0;
    alloc_reset(ch);
    chain_begin(ch, 1, 900 + k, 1, 1, 0, (word % 2 == 0) && (word != 8));
    for (int i = 0; i < n; i++) chain_add(ch, 0, alloc_host(ch, 400, 2), 0, alloc_host(ch, 400, 3), 100 + 17 * i, 0);
    chain_emit(ch);
    corrupt_word(ch, k, word, val);
    if (word == 8 && val == 0) corrupt_word(ch, k, 9, 32'd0);       // a NULL pointer has both words zero
    chain_expect(ch, k, 0);
    for (int i = 0; i < k; i++) tot += ce_len[ch][i];
    set_fail(ch, err, -1, tot, tot, (k > 0), k, k);
    if (k == 0) begin
      // nothing of the head is trusted: no record
      xq_rec[ch][xl(ch)] = 0;
    end
    submit(ch, desc_iova(ch, 0), 1, 0);
    wait_done(ch, 400000, name); repeat (2) @(negedge clk);
    chk_txn(ch, name);
  endtask

  task automatic t_invalid_descriptors();
    int ch = 0; int w0;
    begin_test("invalid descriptors");
    // header words
    bad_desc("bad version",              0, 0, {16'h0003, 8'h00, 8'h02}, ERR_DESC_VERSION, 0);
    bad_desc("bad opcode",               0, 0, {16'h0007, 8'h01, 8'h01}, ERR_DESC_OPCODE, 0);
    bad_desc("reserved flag bit",        0, 0, {16'h0007 | 16'h0200, 8'h00, 8'h01}, ERR_DESC_FLAGS, 0);
    bad_desc("HEAD flag missing",        0, 0, {16'h0000, 8'h00, 8'h01}, ERR_DESC_FLAGS, 0);
    bad_desc("LAST with ARRAY",          2, 0, {16'h0003 | 16'h0002, 8'h00, 8'h01}, ERR_DESC_FLAGS, 1);
    bad_desc("head-only flag on a later descriptor", 1, 0, {16'h0020, 8'h00, 8'h01}, ERR_DESC_FLAGS, 1);
    bad_desc("HEAD flag on a later descriptor",      1, 0, {16'h0004, 8'h00, 8'h01}, ERR_DESC_FLAGS, 1);
    bad_desc("reserved W2 bits",         1, 2, 32'h0000_1000, ERR_DESC_RSVD, 1);
    bad_desc("reserved W12 bits",        1, 12, 32'h0001_0001, ERR_DESC_RSVD, 1);
    bad_desc("reserved W13 word",        0, 13, 32'h0000_0001, ERR_DESC_RSVD, 0);
    bad_desc("invalid source ASID",      1, 2, 32'h0000_0007, ERR_BAD_ASID, 1);
    bad_desc("invalid destination ASID", 1, 2, 32'h0000_00F0, ERR_BAD_ASID, 1);
    bad_desc("element length > 2^24",    1, 3, 32'h0200_0000, ERR_LEN_TOO_BIG, 1);
    if (AW < 64) begin
      bad_desc("source address >= 2^AW",   1, 5, 32'h0001_0000 << (AW > 48 ? AW - 48 : 0), ERR_ADDR_RANGE, 1);
      bad_desc("destination address >= 2^AW", 1, 7, 32'hFFFF_FFFF, ERR_ADDR_RANGE, 1);
    end
    bad_desc("txn id changes mid-chain", 1, 1, {16'd1, 16'd4242}, ERR_CHAIN_TXN, 1);
    bad_desc("domain claim changes mid-chain", 2, 1, {16'd3, 16'd902}, ERR_DOMAIN_MISMATCH, 1);
    bad_desc("SEQ replayed (cycle through a repeated descriptor)", 2, 12, 32'd1, ERR_CHAIN_SEQ, 1);
    bad_desc("linked mode: NEXT null",  0, 8, 32'd0, ERR_CHAIN_NULL, 0);
    bad_desc("LAST descriptor with a NEXT pointer", 2, 8, 32'h1000_0000, ERR_DESC_RSVD, 1);
    // address overflow near 2**AW and overlap (need exact values: AW-dependent)
    begin
      longint top = (64'd1 << AW) - 64'd8;
      alloc_reset(ch);
      chain_begin(ch, 1, 950, 1, 0, 0, 0);
      chain_add(ch, 0, alloc_host(ch, 400, 0), 0, alloc_host(ch, 400, 0), 64, 0);
      chain_add(ch, 0, alloc_host(ch, 400, 0), 0, alloc_host(ch, 400, 0), 64, 0);
      chain_emit(ch);
      corrupt_word(ch, 1, 4, top[31:0]); corrupt_word(ch, 1, 5, top[63:32]); corrupt_word(ch, 1, 3, 32'd100);   // src + len wraps past 2**AW
      chain_expect(ch, 1, 0); set_fail(ch, ERR_ADDR_OVERFLOW, -1, 64, 64, 1, 1, 1);
      submit(ch, desc_iova(ch, 0), 1, 0); wait_done(ch, 300000, "overflow"); repeat (2) @(negedge clk); chk_txn(ch, "src + len overflows the address space");
      alloc_reset(ch);
      chain_begin(ch, 1, 951, 1, 0, 0, 0);
      chain_add(ch, 0, alloc_host(ch, 400, 0), 0, alloc_host(ch, 400, 0), 64, 0);
      chain_add(ch, 0, alloc_host(ch, 400, 0), 0, alloc_host(ch, 400, 0), 64, 0);
      chain_emit(ch);
      corrupt_word(ch, 1, 6, top[31:0]); corrupt_word(ch, 1, 7, top[63:32]); corrupt_word(ch, 1, 3, 32'd100);
      chain_expect(ch, 1, 0); set_fail(ch, ERR_ADDR_OVERFLOW, -1, 64, 64, 1, 1, 1);
      submit(ch, desc_iova(ch, 0), 1, 0); wait_done(ch, 300000, "overflow"); repeat (2) @(negedge clk); chk_txn(ch, "dst + len overflows the address space");
      // overlap inside one address space
      alloc_reset(ch);
      chain_begin(ch, 1, 952, 1, 0, 0, 0);
      begin longint a = alloc_host(ch, 1000, 0);
        chain_add(ch, 0, alloc_host(ch, 400, 0), 0, alloc_host(ch, 400, 0), 64, 0);
        chain_add(ch, 0, a, 0, a + 50, 100, 0);
      end
      chain_emit(ch); chain_expect(ch, 1, 0); set_fail(ch, ERR_OVERLAP, -1, 64, 64, 1, 1, 1);
      submit(ch, desc_iova(ch, 0), 1, 0); wait_done(ch, 300000, "overlap"); repeat (2) @(negedge clk); chk_txn(ch, "overlapping source and destination");
    end
    // head-level errors
    alloc_reset(ch);
    chain_begin(ch, 1, 953, 0, 0, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 400, 0), 0, alloc_host(ch, 400, 0), 64, 0);
    chain_emit(ch); chain_expect(ch, 0, 0); set_fail(ch, ERR_DESC_ALIGN, -1, 0, 0, 0, 0, 0);
    w0 = n_rd_bursts;
    submit(ch, desc_iova(ch, 0) + 8, 1, 0); wait_done(ch, 100000, "head align"); repeat (2) @(negedge clk); chk_txn(ch, "misaligned head address");
    `TBCHK(n_rd_bursts == w0, "misaligned head: the DMA still read memory")
    if (AW < 64) begin
      alloc_reset(ch);
      chain_begin(ch, 1, 954, 0, 0, 0, 0);
      chain_expect(ch, 0, 0); set_fail(ch, ERR_ADDR_RANGE, -1, 0, 0, 0, 0, 0);
      submit(ch, (64'd1 << AW), 1, 0); wait_done(ch, 100000, "head range"); repeat (2) @(negedge clk); chk_txn(ch, "head address >= 2^AW");
    end
    alloc_reset(ch);
    chain_begin(ch, 1, 955, 0, 0, 0, 0);
    chain_expect(ch, 0, 0); set_fail(ch, ERR_BAD_ASID, -1, 0, 0, 0, 0, 0);
    submit(ch, desc_iova(ch, 0), 1, 9); wait_done(ch, 100000, "head asid"); repeat (2) @(negedge clk); chk_txn(ch, "invalid descriptor address space");
    // completion address misaligned
    begin
      alloc_reset(ch);
      chain_begin(ch, 1, 956, 1, 0, 0, 0);
      chain_add(ch, 0, alloc_host(ch, 400, 0), 0, alloc_host(ch, 400, 0), 64, 0);
      chain_emit(ch);
      corrupt_word(ch, 0, 10, 32'(cc_cpl_iova[ch] + 4));
      chain_expect(ch, 0, 0); xq_rec[ch][xl(ch)] = 0; set_fail(ch, ERR_CPL_ALIGN, -1, 0, 0, 0, 0, 0);
      submit(ch, desc_iova(ch, 0), 1, 0); wait_done(ch, 100000, "cpl align"); repeat (2) @(negedge clk); chk_txn(ch, "completion address not 32-byte aligned");
    end
    // cycles and self loops: reported at the first revisit, the valid prefix executes
    begin
      alloc_reset(ch);
      chain_begin(ch, 1, 957, 1, 1, 0, 0);
      for (int i = 0; i < 3; i++) chain_add(ch, 0, alloc_host(ch, 400, 0), 0, alloc_host(ch, 400, 0), 64 + i, 0);
      chain_emit(ch);
      // descriptor 2: clear LAST, point NEXT back at descriptor 0
      corrupt_word(ch, 2, 0, {16'h0000, 8'h00, 8'h01});
      corrupt_word(ch, 2, 8, 32'(desc_iova(ch, 0)));  corrupt_word(ch, 2, 9, 32'(desc_iova(ch, 0) >> 32));
      chain_expect(ch, 3, 0); set_fail(ch, ERR_CHAIN_SEQ, -1, 64 + 65 + 66, 64 + 65 + 66, 1, 3, 3);
      submit(ch, desc_iova(ch, 0), 1, 0); wait_done(ch, 300000, "cycle"); repeat (2) @(negedge clk); chk_txn(ch, "descriptor cycle 0->1->2->0");
      alloc_reset(ch);
      chain_begin(ch, 1, 958, 1, 0, 0, 0);
      chain_add(ch, 0, alloc_host(ch, 400, 0), 0, alloc_host(ch, 400, 0), 64, 0);
      chain_add(ch, 0, alloc_host(ch, 400, 0), 0, alloc_host(ch, 400, 0), 64, 0);
      chain_emit(ch);
      corrupt_word(ch, 0, 0, {16'h0014, 8'h00, 8'h01});                         // HEAD|CPL_EN, not LAST, linked
      corrupt_word(ch, 0, 8, 32'(desc_iova(ch, 0)));  corrupt_word(ch, 0, 9, 32'(desc_iova(ch, 0) >> 32));   // NEXT = itself
      chain_expect(ch, 1, 0); set_fail(ch, ERR_CHAIN_SEQ, -1, 64, 64, 1, 1, 1);
      submit(ch, desc_iova(ch, 0), 1, 0); wait_done(ch, 300000, "self loop"); repeat (2) @(negedge clk); chk_txn(ch, "descriptor pointing at itself");
    end
    // chain longer than the limit
    begin
      longint tot = 0;
      alloc_reset(ch);
      chain_begin(ch, 1, 959, 1, 0, 0, 1);
      for (int i = 0; i < MAX_CHAIN + 2; i++) chain_add(ch, 0, alloc_host(ch, 300, 0), 0, alloc_host(ch, 300, 0), 10 + (i % 7), 0);
      chain_emit(ch);
      chain_expect(ch, MAX_CHAIN - 1, 0);
      for (int i = 0; i < MAX_CHAIN - 1; i++) tot += ce_len[ch][i];
      set_fail(ch, ERR_CHAIN_TOO_LONG, -1, tot, tot, 1, MAX_CHAIN - 1, MAX_CHAIN - 1);
      submit(ch, desc_iova(ch, 0), 1, 0); wait_done(ch, 900000, "too long"); repeat (2) @(negedge clk); chk_txn(ch, "chain longer than MAX_CHAIN");
    end
    // chain total above the limit (only meaningful when the DUT was built with a small MAX_TOTAL_LOG2)
    if (TOTLOG2 < 24) begin
      int L = (1 << TOTLOG2) / 3 + 500;
      longint tot2 = 0;
      alloc_reset(ch);
      chain_begin(ch, 1, 962, 1, 0, 0, 0);
      for (int i = 0; i < 4; i++) chain_add(ch, 0, alloc_host(ch, L + 8, 0), 0, alloc_host(ch, L + 8, 0), L, 0);
      chain_emit(ch); chain_expect(ch, 2, 0);
      tot2 = 2 * L;
      set_fail(ch, ERR_TOTAL_TOO_BIG, -1, tot2, tot2, 1, 2, 2);
      submit(ch, desc_iova(ch, 0), 1, 0); wait_done(ch, 900000, "total too big"); repeat (2) @(negedge clk); chk_txn(ch, "chain total above 2**MAX_TOTAL_LOG2");
    end
    // descriptor fetch bus error (SLVERR on the descriptor's physical address)
    begin
      longint pa;
      alloc_reset(ch);
      chain_begin(ch, 1, 960, 0, 0, 0, 0);
      chain_add(ch, 0, alloc_host(ch, 400, 0), 0, alloc_host(ch, 400, 0), 64, 0);
      chain_emit(ch); chain_expect(ch, 0, 0); set_fail(ch, ERR_BUS_DESC, -1, 0, 0, 0, 0, 0);
      pa = t_iova2pa(1, 0, desc_iova(ch, 0), 1);
      inj_lo = pa; inj_hi = pa + 64; inj_kind = 1;
      submit(ch, desc_iova(ch, 0), 1, 0); wait_done(ch, 100000, "desc bus err"); repeat (2) @(negedge clk); chk_txn(ch, "bus error on the descriptor fetch");
      inj_kind = 0;
    end
    end_test("invalid-descriptors");
  endtask

  // ------------------------------------------------------------ bus errors on data (read / write / unmapped physical)
  task automatic t_bus_errors();
    int ch = 0; longint pa;
    begin_test("bus errors on data");
    // SLVERR on the read of the second element's source
    alloc_reset(ch);
    chain_begin(ch, 1, 970, 1, 0, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 900, 0), 0, alloc_host(ch, 900, 0), 700, 0);
    chain_add(ch, 0, alloc_host(ch, 900, 0), 0, alloc_host(ch, 900, 0), 700, 0);
    chain_finish(ch);
    pa = t_iova2pa(1, 0, ce_src[ch][1], 1);
    inj_lo = pa; inj_hi = pa + 700; inj_kind = 1;
    set_fail(ch, ERR_BUS_RD, -1, 0, 1400, 1, 2, 2); x_weak[ch] = 1;
    submit(ch, desc_iova(ch, 0), 1, 0); wait_done(ch, 300000, "read err"); repeat (2) @(negedge clk); chk_txn(ch, "SLVERR on a data read");
    inj_kind = 0;
    // SLVERR on a write: nothing of that burst is committed, status ERROR
    alloc_reset(ch);
    chain_begin(ch, 2, 971, 1, 0, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 5000, 0), 0, alloc_host(ch, 5000, 0), 4000, 0);
    chain_finish(ch);
    pa = t_iova2pa(2, 0, ce_dst[ch][0] + 1500, 2);
    inj_lo = pa; inj_hi = pa + 64; inj_kind = 2;
    set_fail(ch, ERR_BUS_WR, -1, 0, 4000, 1, 1, 1); x_weak[ch] = 1;
    submit(ch, desc_iova(ch, 0), 2, 0); wait_done(ch, 300000, "write err"); repeat (2) @(negedge clk); chk_txn(ch, "SLVERR on a data write");
    inj_kind = 0;
    // IOVA mapped to UNMAPPED physical memory (DECERR from the fabric)
    alloc_reset(ch);
    chain_begin(ch, 3, 972, 1, 0, 0, 0);
    chain_add(ch, 0, 64'h1_0050_0000, 0, alloc_host(ch, 600, 0), 100, 0);
    chain_emit(ch); exp_tolerant = 1; chain_expect(ch, 1, 0); exp_tolerant = 0;
    set_fail(ch, ERR_BUS_RD, -1, 0, 100, 1, 1, 1); x_weak[ch] = 1;
    submit(ch, desc_iova(ch, 0), 3, 0); wait_done(ch, 300000, "decerr"); repeat (2) @(negedge clk); chk_txn(ch, "DECERR (physical address not decoded)");
    // after the errors the engine works normally
    alloc_reset(ch);
    chain_begin(ch, 0, 973, 1, 1, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 2000, 1), 0, alloc_host(ch, 2000, 2), 1500, 0);
    chain_finish(ch); run_ch(ch, "normal transfer after the error cases");
    end_test("bus-errors");
  endtask

  // ------------------------------------------------------------ 11. timeouts
  task automatic t_timeouts();
    int ch = 0; bit [31:0] v;
    begin_test("timeouts, fencing and recovery");
    csr_wr(CSR_TIMEOUT, 32'd600);
    // (a) responses later than the timeout: reported, fenced, late responses drained, channel recovers by itself
    profile(0); cfg_lat_min = 2500; cfg_lat_max = 2500;
    alloc_reset(ch);
    chain_begin(ch, 1, 980, 1, 1, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 3000, 0), 0, alloc_host(ch, 3000, 0), 2500, 0);
    chain_finish(ch);
    set_fail(ch, ERR_TIMEOUT, -1, 0, 2500, 0, 0, 1); x_weak[ch] = 1; allow_pending_at_done[ch] = 1;
    submit(ch, desc_iova(ch, 0), 1, 0); wait_done(ch, 200000, "late responses"); repeat (2) @(negedge clk);
    csr_rd(CSR_STATUS, v);
    `TBCHK(v[16] == 1'b1, "timeout: channel not reported as fenced")
    chk_txn(ch, "late responses -> timeout");
    allow_pending_at_done[ch] = 0;
    repeat (8000) @(negedge clk);                              // late responses arrive and are absorbed
    csr_rd(CSR_STATUS, v);
    `TBCHK(v[16] == 1'b0 && v[0] == 1'b0, $sformatf("timeout: channel did not recover after the late responses (status %h)", v))
    profile(0);
    alloc_reset(ch);
    chain_begin(ch, 1, 981, 1, 1, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 3000, 0), 0, alloc_host(ch, 3000, 0), 2500, 0);
    chain_finish(ch); run_ch(ch, "transfer after the fence cleared");
    // (b) read never answered -> soft reset recovers
    cfg_hang_rd = 1;
    alloc_reset(ch);
    chain_begin(ch, 1, 982, 1, 0, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 3000, 0), 0, alloc_host(ch, 3000, 0), 2500, 0);
    chain_finish(ch);
    set_fail(ch, ERR_TIMEOUT, -1, 0, 0, 0, 0, 0); x_weak[ch] = 1; allow_pending_at_done[ch] = 1;
    submit(ch, desc_iova(ch, 0), 1, 0); wait_done(ch, 200000, "hang read"); repeat (2) @(negedge clk);
    chk_txn(ch, "read never answered");
    allow_pending_at_done[ch] = 0;
    repeat (3000) @(negedge clk);
    csr_rd(CSR_STATUS, v);
    `TBCHK(v[16] == 1'b1, "hung read: channel must stay fenced until reset")
    csr_wr(CSR_CTRL, 32'h3);                                    // soft reset (enable stays 1)
    repeat (2) @(negedge clk); slave_flush(); cfg_hang_rd = 0; if_clear(ch);
    repeat (10) @(negedge clk);
    csr_rd(CSR_STATUS, v);
    `TBCHK(v[16] == 1'b0 && v[0] == 1'b0, "soft reset did not clear the fence")
    alloc_reset(ch);
    chain_begin(ch, 1, 983, 1, 1, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 3000, 0), 0, alloc_host(ch, 3000, 0), 2500, 0);
    chain_finish(ch); run_ch(ch, "transfer after soft reset");
    // (c) write response never returns
    cfg_hang_wr = 1;
    alloc_reset(ch);
    chain_begin(ch, 2, 984, 0, 0, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 3000, 0), 0, alloc_host(ch, 3000, 0), 2500, 0);
    chain_finish(ch);
    set_fail(ch, ERR_TIMEOUT, -1, 0, 2500, 0, 0, 1); x_weak[ch] = 1; allow_pending_at_done[ch] = 1;
    submit(ch, desc_iova(ch, 0), 2, 0); wait_done(ch, 200000, "hang write"); repeat (2) @(negedge clk);
    chk_txn(ch, "write response never returns");
    allow_pending_at_done[ch] = 0;
    csr_wr(CSR_CTRL, 32'h3); repeat (2) @(negedge clk); slave_flush(); cfg_hang_wr = 0; if_clear(ch); repeat (10) @(negedge clk);
    alloc_reset(ch);
    chain_begin(ch, 2, 985, 1, 1, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 3000, 0), 0, alloc_host(ch, 3000, 0), 2500, 0);
    chain_finish(ch); run_ch(ch, "transfer after the write hang was reset");
    csr_wr(CSR_TIMEOUT, 32'd0);
    end_test("timeouts");
  endtask

  // ------------------------------------------------------------ abort and reset behaviour
  task automatic t_abort();
    int ch = 0; bit [31:0] v;
    begin_test("abort command");
    for (int it = 0; it < 4; it++) begin
      profile(it % 3);
      alloc_reset(ch);
      chain_begin(ch, 1, 990 + it, 1, 1, 0, 0);
      chain_add(ch, 0, alloc_host(ch, ABORTLEN + 8, 0), 0, alloc_host(ch, ABORTLEN + 8, 0), ABORTLEN, 0);
      chain_finish(ch);
      set_fail(ch, ERR_ABORT, -1, 0, ABORTLEN, 1, 0, 1); xq_status[ch][xl(ch)] = 2; x_weak[ch] = 1;
      submit(ch, desc_iova(ch, 0), 1, 0);
      repeat (150 + 400 * it) @(negedge clk);
      csr_wr(CSR_CH_BASE + CH_CTRL, 32'h1);
      wait_done(ch, 200000, "abort"); repeat (2) @(negedge clk);
      chk_txn(ch, $sformatf("abort after %0d cycles", 150 + 400 * it));
      csr_rd(CSR_CH_BASE + CH_STATUS, v);
      `TBCHK(v[7:4] == 4'd2, "abort: CH_STATUS.last_status is not ABORTED")
      repeat (200) @(negedge clk);                              // nothing may be issued after the abort completed
      alloc_reset(ch);
      chain_begin(ch, 1, 995 + it, 1, 1, 0, 0);
      chain_add(ch, 0, alloc_host(ch, 3000, 0), 0, alloc_host(ch, 3000, 0), 2000, 0);
      chain_finish(ch); run_ch(ch, "normal transfer after an abort");
    end
    profile(0);
    end_test("abort");
  endtask

  // hard reset / soft reset in the middle of transfers, at pseudo-random points
  task automatic t_reset();
    int ch = 0; bit [31:0] v;
    begin_test("reset during activity (hard and soft), no stray traffic afterwards, clean restart");
    for (int it = 0; it < 12; it++) begin
      bit hard = (it % 2 == 0);
      profile(it % 5);
      alloc_reset(ch);
      chain_begin(ch, it % 4, 1000 + it, 1, 1, 0, it % 3 == 0);
      for (int i = 0; i < 3; i++) chain_add(ch, 0, alloc_host(ch, 20000, $urandom_range(7, 0)), 0, alloc_host(ch, 20000, $urandom_range(7, 0)), $urandom_range(2000, 12000), 0);
      chain_finish(ch);
      x_weak[ch] = 1; allow_pending_at_done[ch] = 1;
      submit(ch, desc_iova(ch, 0), cc_dom[ch], 0);
      repeat ($urandom_range(400, 3)) @(negedge clk);
      if (dq_n(ch) == 0) begin
        if (hard) begin
          rst_n = 0; repeat (3) @(negedge clk); slave_flush(); rst_n = 1;
          repeat (2) @(negedge clk);
          for (int c = 0; c < NUM_CH; c++) begin if_clear(c); end
          expect_release(ch);
          engine_up();                                         // hard reset also cleared the permission table and CSRs
        end else begin
          csr_wr(CSR_CTRL, 32'h3);
          repeat (1) @(negedge clk); slave_flush(); if_clear(ch); expect_release(ch);
          repeat (8) @(negedge clk);
        end
      end else begin
        // finished before the reset point: just account for it
        chk_txn(ch, "completed before reset point");
      end
      allow_pending_at_done[ch] = 0; x_weak[ch] = 0;
      dq_clear(ch);
      repeat (300) @(negedge clk);                              // quiet period: the monitors flag ANY bus request here
      csr_rd(CSR_STATUS, v);
      `TBCHK(v[NUM_CH-1:0] == '0, $sformatf("reset: channel still busy 300 cycles after the reset (%h)", v))
      profile(0);
      alloc_reset(ch);
      chain_begin(ch, 1, 1100 + it, 1, 1, 0, 0);
      chain_add(ch, 0, alloc_host(ch, 3000, 1), 0, alloc_host(ch, 3000, 2), 2222, 0);
      chain_finish(ch); run_ch(ch, $sformatf("restart after %s reset #%0d", hard ? "hard" : "soft", it));
    end
    end_test("reset");
  endtask

  // ------------------------------------------------------------ queued commands, completion ordering
  task automatic t_completion_order();
    int ch = 0; longint h0, h1, h2;
    begin_test("completion ordering: queued commands complete in order, only after their writes were acknowledged");
    for (int p = 0; p < 3; p++) begin
      profile(p == 0 ? 0 : 4);
      // three transactions with distinct txn ids; sizes chosen so a naive engine would finish the small one first
      alloc_reset(ch);
      chain_begin(ch, 1, 1200 + 3 * p, 1, 1, 0, 0);
      cc_cpl_iova[ch] = desc_base(ch) + 64'h3000;
      chain_add(ch, 0, alloc_host(ch, 40_000, 0), 0, alloc_host(ch, 40_000, 0), 30_000, 0);
      chain_emit_at(ch, 60 + p); chain_expect(ch, 1, 0); h0 = desc_iova(ch, 0);
      chain_begin(ch, 1, 1201 + 3 * p, 1, 1, 0, 0);
      cc_cpl_iova[ch] = desc_base(ch) + 64'h3040;
      chain_add(ch, 0, alloc_host(ch, 40, 0), 0, alloc_host(ch, 40, 0), 5, 0);
      chain_emit_at(ch, 100 + p); chain_expect(ch, 1, 1); h1 = desc_iova(ch, 0);
      chain_begin(ch, 1, 1202 + 3 * p, 1, 1, 0, 0);
      cc_cpl_iova[ch] = desc_base(ch) + 64'h3080;
      chain_add(ch, 0, alloc_host(ch, 9000, 0), 0, alloc_host(ch, 9000, 0), 7000, 0);
      chain_emit_at(ch, 140 + p); chain_expect(ch, 1, 1); h2 = desc_iova(ch, 0);
      submit(ch, h0, 1, 0); submit(ch, h1, 1, 0); submit(ch, h2, 1, 0);
      wait_done(ch, 800000, "order #0"); while (dq_n(ch) < 3) @(negedge clk);
      repeat (2) @(negedge clk);
      chk_completion(ch, "ordered completion #0"); chk_completion(ch, "ordered completion #1"); chk_completion(ch, "ordered completion #2");
      chk_memory(ch, "ordered queue memory");
    end
    profile(0);
    end_test("completion-order");
  endtask

  task automatic t_back_to_back();
    int ch = 0;
    begin_test("identical commands back to back through the command queue");
    alloc_reset(ch);
    chain_begin(ch, 2, 1300, 1, 1, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 3000, 0), 0, alloc_host(ch, 3000, 1), 2500, 0);
    chain_finish(ch);
    x_rep[ch] = 2;
    xq_dup_first(ch);
    submit(ch, desc_iova(ch, 0), 2, 0); submit(ch, desc_iova(ch, 0), 2, 0);
    wait_done(ch, 400000, "b2b"); while (dq_n(ch) < 2) @(negedge clk);
    repeat (2) @(negedge clk);
    chk_completion(ch, "back-to-back #0"); chk_completion(ch, "back-to-back #1"); chk_memory(ch, "back-to-back memory");
    end_test("back-to-back");
  endtask

  // ------------------------------------------------------------ CSR, counters, trace
  task automatic t_csr_perf_trace();
    bit [31:0] v, lo, hi; longint before_wr, after_wr;
    begin_test("CSR block, performance counters and trace");
    csr_rd(CSR_ID, v);       `TBCHK(v == DMA_ID_MAGIC, $sformatf("CSR ID %h", v))
    csr_rd(CSR_VERSION, v);  `TBCHK(v == {DMA_ABI_MAJOR, DMA_ABI_MINOR}, $sformatf("CSR VERSION %h", v))
    csr_rd(CSR_CAPS0, v);    `TBCHK(v[7:0] == NUM_CH && v[15:8] == $clog2(WB) && v[23:16] == AW, $sformatf("CSR CAPS0 %h", v))
    csr_wr(12'h0F0, 32'h1);  `TBCHK(csr_rsp_err == 1'b1, "write to an unmapped CSR did not return an error")
    csr_rd(CSR_ID, v); csr_wr(CSR_ID, 32'h0); `TBCHK(csr_rsp_err == 1'b1, "write to a read-only CSR did not return an error")
    // counters: select BYTES_WR of channel 0, run a transfer, compare with what the TB moved
    csr_wr(CSR_CTRL, 32'h1 | 32'h8); csr_wr(CSR_CTRL, 32'h1 | 32'h4);                 // clear counters + trace, enable trace
    csr_wr(CSR_PERF_SEL, {8'd0, 8'(PC_BYTES_WR)}); csr_rd(CSR_PERF_LO, lo); csr_rd(CSR_PERF_HI, hi); before_wr = {hi, lo};
    begin
      int ch = 0;
      alloc_reset(ch);
      chain_begin(ch, 1, 1400, 1, 1, 1, 0);
      chain_add(ch, 0, alloc_host(ch, 500, 3), 0, alloc_host(ch, 500, 5), 300, 0);
      chain_add(ch, 0, alloc_host(ch, 500, 3), 1, alloc_local(ch, 1, 500, 5), 200, 0);
      chain_finish(ch);
      csr_wr(CSR_IRQ_EN, 32'h0001_0001);
      run_ch(ch, "counted transfer");
      csr_rd(CSR_IRQ_STAT, v); `TBCHK(v[0] == 1'b1, "IRQ_STAT done bit not set after a completion with IRQ_EN")
      `TBCHK(irq == 1'b1, "irq output not raised")
      csr_wr(CSR_IRQ_STAT, 32'h1); csr_rd(CSR_IRQ_STAT, v); `TBCHK(v[0] == 1'b0, "IRQ_STAT W1C failed")
    end
    csr_wr(CSR_PERF_SEL, {8'd0, 8'(PC_BYTES_WR)}); csr_rd(CSR_PERF_LO, lo); csr_rd(CSR_PERF_HI, hi); after_wr = {hi, lo};
    `TBCHK(after_wr - before_wr == 300 + 200, $sformatf("BYTES_WR counter moved by %0d, expected %0d", after_wr - before_wr, 300 + 200))
    csr_wr(CSR_PERF_SEL, {8'd0, 8'(PC_XACT_OK)}); csr_rd(CSR_PERF_LO, lo);
    `TBCHK(lo == 1, $sformatf("XACT_OK counter %0d, expected 1", lo))
    csr_wr(CSR_PERF_SEL, {8'd0, 8'(PC_ACTIVE)}); csr_rd(CSR_PERF_LO, lo);
    `TBCHK(lo > 20, $sformatf("ACTIVE counter %0d implausibly small", lo))
    csr_wr(CSR_PERF_SEL, {8'd0, 8'(PC_DESC_FETCH)}); csr_rd(CSR_PERF_LO, lo);
    `TBCHK(lo == 2, $sformatf("DESC_FETCH counter %0d, expected 2", lo))
    // trace: CMD ... DONE, in order
    csr_rd(CSR_TR_STAT, v);
    `TBCHK(v[15:0] >= 6 && v[31:16] == 0, $sformatf("trace holds only %0d entries", v[15:0]))
    begin
      int seen_cmd = 0, seen_desc = 0, seen_rd = 0, seen_wr = 0, seen_done = 0, order_ok = 1, last_rank = 0;
      for (int k = 0; k < 64; k++) begin
        bit [31:0] w0, w1, w2;
        csr_rd(CSR_TR_STAT, v); if (v[15:0] == 0) break;
        csr_rd(CSR_TR_W0, w0); csr_rd(CSR_TR_W1, w1); csr_rd(CSR_TR_W2, w2);
        csr_wr(CSR_TR_POP, 32'h1);
        case (w0[15:8])
          TR_CMD:      begin seen_cmd++; if (last_rank > 0) order_ok = 0; last_rank = 1; end
          TR_DESC:     begin seen_desc++; end
          TR_RD_ISSUE: seen_rd++;
          TR_WR_ISSUE: seen_wr++;
          TR_DONE:     begin seen_done++; end
          default: ;
        endcase
      end
      `TBCHK(seen_cmd == 1 && seen_desc == 2 && seen_done == 1 && seen_rd >= 2 && seen_wr >= 2 && order_ok,
             $sformatf("trace: cmd=%0d desc=%0d rd=%0d wr=%0d done=%0d", seen_cmd, seen_desc, seen_rd, seen_wr, seen_done))
    end
    csr_wr(CSR_CTRL, 32'h1);
    end_test("csr-perf-trace");
  endtask

  // ------------------------------------------------------------ constrained-random regression
  task automatic t_random(input int rounds);
    begin_test($sformatf("constrained-random regression (%0d rounds)", rounds));
    for (int r = 0; r < rounds; r++) begin
      profile($urandom_range(4, 0));
      stress_all(4, "random");
    end
    profile(0);
    end_test("random");
  endtask

  // ------------------------------------------------------------ multichannel isolation
  task automatic mc_run(input int ch, input int dom, input string tag);
    for (int it = 0; it < 4; it++) begin random_chain(ch, dom, 6, 3, 1); run_ch(ch, tag); end
  endtask
  task automatic mc_victim(input int ch, input int dom, input string tag);
    random_chain(ch, dom, 6, 3, 1); run_ch(ch, tag);
  endtask
  task automatic mc_attacker();
    int ch = 0;
    alloc_reset(ch);
    chain_begin(ch, 1, 1500, 1, 0, 0, 0);
    chain_add(ch, 0, IOVA_PRIV + 3 * 64'h1_0000, 0, alloc_host(ch, 600, 0), 200, 0);
    chain_emit(ch); chain_expect(ch, 0, 0); set_fail(ch, ERR_PERM_SRC, FDOM, 0, 0, 1, 0, 1); x_weak[ch] = 1;
    submit(ch, desc_iova(ch, 0), 1, 0); wait_done(ch, 300000, "attacker"); repeat (2) @(negedge clk); chk_txn(ch, "channel 0 attacks foreign memory");
  endtask

  // only called with NUM_CH >= 2
  task automatic t_multichannel();
    begin_test("concurrent channels of different domains: isolation and independence");
    for (int p = 0; p < 4; p++) begin
      profile(p == 0 ? 0 : 3);
      for (int c = 0; c < NUM_CH; c++) dispatch(c, J_MCRUN, c % 4, 0, {"mc ch", $sformatf("%0d", c)});
      join_jobs();
    end
    // one channel attacks (foreign private memory) while the others run normally
    profile(3);
    dispatch(0, J_ATTACK, 0, 0, "attacker");
    for (int c = 1; c < NUM_CH; c++) dispatch(c, J_VICTIM, (c % 2) ? 2 : 3, 0, {"victim ch", $sformatf("%0d", c)});
    join_jobs();
    profile(0);
    end_test("multichannel");
  endtask

  // ------------------------------------------------------------ abort at the earliest cycles (walker still fetching)
  task automatic t_abort_early();
    int ch = 0; int dl [8] = '{1, 2, 3, 5, 8, 13, 21, 34};
    begin_test("abort during the descriptor fetch / first bursts (earliest cycles)");
    for (int k = 0; k < 8; k++) begin
      profile(k % 4 == 3 ? 3 : (k % 3 == 1 ? 1 : 0));
      alloc_reset(ch);
      chain_begin(ch, 2, 1800 + k, 1, 1, 0, 0);
      chain_add(ch, 0, alloc_host(ch, 30_000, 0), 0, alloc_host(ch, 30_000, 0), 20_000, 0);
      chain_finish(ch);
      set_fail(ch, ERR_ABORT, -1, 0, 20_000, 0, 0, 1); xq_status[ch][xl(ch)] = 2; xq_rec[ch][xl(ch)] = 0; x_weak[ch] = 1;
      submit(ch, desc_iova(ch, 0), 2, 0);
      repeat (dl[k]) @(negedge clk);
      csr_wr(CSR_CH_BASE + CH_CTRL, 32'h1);
      wait_done(ch, 200000, "early abort"); repeat (2) @(negedge clk);
      chk_txn(ch, $sformatf("abort %0d cycles after the command", dl[k]));
      repeat (100) @(negedge clk);
      alloc_reset(ch);
      chain_begin(ch, 2, 1850 + k, 1, 1, 0, 0);
      chain_add(ch, 0, alloc_host(ch, 3000, 0), 0, alloc_host(ch, 3000, 0), 2000, 0);
      chain_finish(ch); run_ch(ch, "normal transfer after an early abort");
    end
    profile(0);
    end_test("abort-early");
  endtask

  // ------------------------------------------------------------ multichannel: soft reset under load, per-channel hang
  task automatic mc_load(input int ch, input int dom, input int n);
    for (int it = 0; it < n; it++) begin random_chain(ch, dom, 3, 4, 1); run_ch(ch, $sformatf("mc load ch%0d", ch)); end
  endtask
  task automatic mc_big(input int ch, input int dom);
    alloc_reset(ch);
    chain_begin(ch, dom, 1900 + ch, 1, 1, 0, 0);
    chain_add(ch, 0, alloc_host(ch, 60_000, 0), 0, alloc_host(ch, 60_000, 0), 50_000, 0);
    chain_finish(ch); x_weak[ch] = 1; allow_pending_at_done[ch] = 1;
    submit(ch, desc_iova(ch, 0), dom, 0);
  endtask
  task automatic mc_clean(input int ch);
    dq_clear(ch); expect_release(ch); if_clear(ch); allow_pending_at_done[ch] = 0; x_weak[ch] = 0;
  endtask

  // only called with NUM_CH >= 2
  task automatic t_multichannel_reset();
    bit [31:0] v;
    begin_test("multichannel: soft reset under load (mux state), per-channel hang isolation");
    for (int it = 0; it < 6; it++) begin
      profile(it % 5);
      for (int c = 0; c < NUM_CH; c++) mc_big(c, c % 4);
      repeat ($urandom_range(600, 40)) @(negedge clk);
      csr_wr(CSR_CTRL, 32'h3); slave_flush(); repeat (12) @(negedge clk);          // global soft reset (the mux is part of the core)
      for (int c = 0; c < NUM_CH; c++) mc_clean(c);
      repeat (50) @(negedge clk);
      // every channel must work again, concurrently, with correct data (stale W-order entries would swap data between channels)
      for (int c = 0; c < NUM_CH; c++) dispatch(c, J_MCLOAD, c % 4, 2, "");
      join_jobs();
    end
    profile(0);
    // channel 0 hangs (its reads never answered); channel 1 must be unaffected and finish normally
    csr_wr(CSR_TIMEOUT, 32'd700);
    cfg_hang_rd = 1; cfg_hang_ch = 0;
    begin
      int ch = 0;
      alloc_reset(ch);
      chain_begin(ch, 0, 1950, 0, 0, 0, 0);
      chain_add(ch, 0, alloc_host(ch, 4000, 0), 0, alloc_host(ch, 4000, 0), 3000, 0);
      chain_finish(ch); set_fail(ch, ERR_TIMEOUT, -1, 0, 3000, 0, 0, 1); x_weak[ch] = 1; allow_pending_at_done[ch] = 1;
      submit(ch, desc_iova(ch, 0), 0, 0);
    end
    mc_load(1, 1, 3);                                                       // runs to completion while channel 0 is stuck
    wait_done(0, 200000, "hung channel"); repeat (2) @(negedge clk);
    chk_txn(0, "channel 0 times out while channel 1 keeps working");
    csr_rd(CSR_STATUS, v);
    `TBCHK(v[16] == 1'b1 && v[17] == 1'b0, $sformatf("fence status %h: only channel 0 may be fenced", v))
    allow_pending_at_done[0] = 0;
    csr_wr(CSR_CTRL, 32'h3); slave_flush(); cfg_hang_rd = 0; cfg_hang_ch = -1; repeat (12) @(negedge clk);
    for (int c = 0; c < NUM_CH; c++) mc_clean(c);
    csr_wr(CSR_TIMEOUT, 32'd0);
    mc_load(0, 0, 2); mc_load(1, 1, 2);
    end_test("multichannel-reset");
  endtask

  // ------------------------------------------------------------ negative test: in-order DUT, reordering bus
  // one side at a time: with the other response channel kept in order, ONLY the side under test can produce the protocol error,
  // so a broken check on that side cannot be masked by the other one (mutants M26 / M29)
  task automatic reorder_probe(input string side, input bit rd_side);
    int ch = 0; int tries = 0; bit seen = 0; bit [31:0] v;
    profile(4); cfg_reorder = 1; cfg_interleave = rd_side;
    cfg_r_inorder = !rd_side; cfg_b_inorder = rd_side;
    while (!seen && tries < 12) begin
      alloc_reset(ch);
      chain_begin(ch, 1, 1600 + tries, 1, 0, 0, 0);
      for (int i = 0; i < 3; i++) chain_add(ch, 0, alloc_host(ch, 8000, 1), 0, alloc_host(ch, 8000, 2), 6000, 0);
      chain_finish(ch);
      x_weak[ch] = 1; allow_pending_at_done[ch] = 1;
      submit(ch, desc_iova(ch, 0), 1, 0); wait_done(ch, 400000, "reorder violation"); repeat (2) @(negedge clk);
      if (dq_n(ch) > 0 && dq_err[ch][dq_f(ch)] == ERR_PROTOCOL) begin
        seen = 1;
        `TBCHK(dq_status[ch][dq_f(ch)] == 1, "protocol error must complete with status ERROR")
        csr_rd(CSR_STATUS, v);
        `TBCHK(v[16] == 1'b1, "protocol error: channel not fenced")
      end
      // quiesce the bus and soft-reset to continue (the platform contract)
      csr_wr(CSR_CTRL, 32'h3); slave_flush(); repeat (10) @(negedge clk);
      dq_clear(ch); expect_release(ch); if_clear(ch); allow_pending_at_done[ch] = 0;
      tries++;
    end
    `TBCHK(seen, $sformatf("an in-order DUT never flagged %s although the other response channel stayed in order (ERR_PROTOCOL expected)", side))
    profile(0);
  endtask

  task automatic t_reorder_violation();
    begin_test("REORDER_OK=0 with a reordering bus: protocol error is detected, reported, channel fenced (read side, write side)");
    reorder_probe("reordered READ responses", 1);
    reorder_probe("reordered WRITE responses", 0);
    end_test("reorder-violation");
  endtask

  // ------------------------------------------------------------ performance workloads (SUITE == 4): one PERF line per workload and channel
  int perf_lat = 20, perf_blat = 8;
  string perf_tag = "";

  task automatic pc_read(input int ch, input int id, output longint v);
    bit [31:0] lo, hi;
    csr_wr(CSR_PERF_SEL, 32'((ch << 8) | id));
    csr_rd(CSR_PERF_LO, lo); csr_rd(CSR_PERF_HI, hi);
    v = {hi, lo};
  endtask

  task automatic perf_report(input string wl, input int ch, input longint bytes);
    longint c [NUM_PC];
    longint mx0, mx1, mx2, mx3;
    for (int i = 0; i < NUM_PC; i++) pc_read(ch, i, c[i]);
    pc_read(ch, PM_LAT_MAX, mx0); pc_read(ch, PM_RD_OCC_MAX, mx1); pc_read(ch, PM_WR_OCC_MAX, mx2); pc_read(ch, PM_BUF_MAX, mx3);
    $display("PERF,%s,%s,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",
             perf_tag, wl, ch, bytes, c[PC_ACTIVE], c[PC_BYTES_WR], c[PC_BYTES_RD], c[PC_BEATS_RD], c[PC_BEATS_WR], c[PC_BURSTS_RD], c[PC_BURSTS_WR],
             c[PC_STALL_AR], c[PC_STALL_AW], c[PC_STALL_W], c[PC_STALL_WDATA], c[PC_STALL_FULL], c[PC_STALL_RSLOT], c[PC_STALL_WSLOT],
             c[PC_PERM_WAIT], c[PC_PERM_REQ], c[PC_PERM_LAT], c[PC_OCC_RD], c[PC_OCC_WR], c[PC_OCC_BUF], c[PC_RD_LAT], c[PC_WR_LAT],
             c[PC_XACT_OK], c[PC_LAT_SUM], mx0, c[PC_DESC_LAT]);
  endtask

  task automatic perf_build(input int ch, input string wl);
    alloc_reset(ch);
    case (wl)
      "bulk_aligned": begin
        chain_begin(ch, ch % 4, 3000 + ch, 0, 0, 0, 0);
        chain_add(ch, 0, alloc_host(ch, 131_072 + 8, 0), 0, alloc_host(ch, 131_072 + 8, 0), 131_072, 0);
      end
      "bulk_unaligned": begin
        chain_begin(ch, ch % 4, 3100 + ch, 0, 0, 0, 0);
        chain_add(ch, 0, alloc_host(ch, 131_072 + 8, 3), 0, alloc_host(ch, 131_072 + 8, 5), 131_072, 0);
      end
      "sg_64x2k": begin
        chain_begin(ch, ch % 4, 3200 + ch, 0, 0, 0, 1);
        for (int i = 0; i < 64; i++) chain_add(ch, 0, alloc_host(ch, 2048 + 8, 0), 0, alloc_host(ch, 2048 + 8, 0), 2048, 0);
      end
      "h2sram": begin
        chain_begin(ch, ch % 4, 3300 + ch, 0, 0, 0, 0);
        chain_add(ch, 0, alloc_host(ch, 12_288 + 8, 0), 1, alloc_local(ch, 1, 12_288 + 8, 0), 12_288, 0);
      end
      default: begin
        chain_begin(ch, ch % 4, 3400 + ch, 1, 0, 0, 0);
        chain_add(ch, 0, alloc_host(ch, 512, 0), 0, alloc_host(ch, 512, 0), 256, 0);
      end
    endcase
    chain_finish(ch);
  endtask

  task automatic perf_ch(input int ch, input string wl);
    int reps = (wl == "small_256B") ? 32 : 1;
    for (int r = 0; r < reps; r++) begin
      perf_build(ch, wl);
      run_ch(ch, {"perf ", wl});
    end
  endtask

  task automatic perf_all(input string wl);
    csr_wr(CSR_CTRL, 32'h1 | 32'h8);                                      // clear counters
    for (int c = 0; c < NUM_CH; c++) dispatch(c, J_PERF, 0, 0, wl);
    join_jobs();
    for (int c = 0; c < NUM_CH; c++) begin
      longint nbytes = (wl == "bulk_aligned" || wl == "bulk_unaligned") ? 131_072 : (wl == "sg_64x2k") ? 131_072 : (wl == "h2sram") ? 12_288 : 32 * 256;
      perf_report(wl, c, nbytes);
    end
  endtask

  task automatic t_perf();
    string wls [5] = '{"bulk_aligned", "bulk_unaligned", "sg_64x2k", "h2sram", "small_256B"};
    if ($value$plusargs("lat=%d", perf_lat)) begin end
    if ($value$plusargs("blat=%d", perf_blat)) begin end
    begin string t; if ($value$plusargs("tag=%s", t)) perf_tag = t; end
    begin_test("performance workloads");
    profile(0);
    cfg_lat_min = perf_lat; cfg_lat_max = perf_lat; cfg_b_min = perf_blat; cfg_b_max = perf_blat;
    for (int w = 0; w < 5; w++) perf_all(wls[w]);
    profile(0);
    end_test("perf");
  endtask

  // ------------------------------------------------------------ external IOMMU misbehaviour (EXT_IOMMU = 1)
  task automatic t_iommu_faults();
    int ch = 0; int r0;
    begin_test("external IOMMU: translation results are re-checked, stray responses dropped");
    // (1) the very first response (descriptor fetch) is unusable: the DMA must refuse it and touch nothing
    for (int mode = 1; mode <= 3; mode++) begin
      alloc_reset(ch);
      chain_begin(ch, 1, 1700 + mode, 0, 0, 0, 0);
      chain_add(ch, 0, alloc_host(ch, 400, 0), 0, alloc_host(ch, 400, 0), 100, 0);
      chain_emit(ch); chain_expect(ch, 0, 0); set_fail(ch, ERR_PERM_DESC, int'(FAULT_XLAT), 0, 0, 0, 0, 0);
      iom_mode = mode; iom_skip = 0; r0 = n_rd_bursts;
      submit(ch, desc_iova(ch, 0), 1, 0); wait_done(ch, 100000, "bad iommu"); repeat (2) @(negedge clk);
      chk_txn(ch, $sformatf("IOMMU fault injection mode %0d on the descriptor fetch", mode));
      `TBCHK(n_rd_bursts == r0, "a refused translation still produced bus traffic")
    end
    // (2) descriptor fetch fine, the first DATA read translation is unusable
    for (int mode = 1; mode <= 3; mode++) begin
      alloc_reset(ch);
      chain_begin(ch, 2, 1710 + mode, 1, 0, 0, 0);
      chain_add(ch, 0, alloc_host(ch, 1200, 0), 0, alloc_host(ch, 1200, 0), 1000, 0);
      chain_emit(ch); chain_expect(ch, 1, 0); set_fail(ch, ERR_PERM_SRC, int'(FAULT_XLAT), 0, 1000, 1, 0, 1); x_weak[ch] = 1;
      iom_mode = mode; iom_skip = 1;
      submit(ch, desc_iova(ch, 0), 2, 0); wait_done(ch, 100000, "bad iommu data"); repeat (2) @(negedge clk);
      chk_txn(ch, $sformatf("IOMMU fault injection mode %0d on a data read", mode));
    end
    // (3) stray responses for clients that are not waiting must not disturb anything
    iom_mode = 4; iom_skip = 0;
    for (int it = 0; it < 6; it++) begin random_chain(ch, it % 4, 5, 3, 1); run_ch(ch, "transfer amid stray IOMMU responses"); end
    `TBCHK(n_iom_stray > 0, "no stray IOMMU response was injected")
    begin bit [31:0] pv; csr_rd(CSR_PROTO, pv); `TBCHK(pv >= n_iom_stray, $sformatf("CSR PROTO counts %0d events, %0d stray responses were injected", pv, n_iom_stray)) end
    iom_mode = 0;
    end_test("iommu-faults");
  endtask

  // ------------------------------------------------------------ sequencer
  int only_t = -1;
  `define RUNT(n, call) if (only_t < 0 || only_t == n) begin call; end
  task automatic run_all();
    if ($value$plusargs("only=%d", only_t)) $display("running only test %0d", only_t);
    if ($test$plusargs("dbg")) dbg = 1;
    model_init();
    for (int c = 0; c < NUM_CH; c++) begin alloc_reset(c); end
    profile(0);
    reset_dut();
    engine_up();
    if (SUITE == 4) begin
      t_perf();
    end else if (SUITE == 3) begin
      t_reorder_violation();
    end else if (SUITE == 2) begin
      t_random(30);
    end else begin
      `RUNT(1,  t_zero_length())
      `RUNT(2,  t_single_byte())
      `RUNT(3,  t_unaligned_tails())
      `RUNT(4,  t_multi_segment())
      `RUNT(5,  if (SUITE == 0) t_long())
      `RUNT(6,  t_ordered())
      `RUNT(7,  t_profiles())
      `RUNT(8,  t_reorder_stats())
      `RUNT(9,  t_done_backpressure())
      `RUNT(10, t_domain_violations())
      `RUNT(11, t_invalid_descriptors())
      `RUNT(12, t_bus_errors())
      `RUNT(13, t_timeouts())
      `RUNT(14, t_abort())
      `RUNT(22, t_abort_early())
      `RUNT(15, t_reset())
      `RUNT(16, t_completion_order())
      `RUNT(17, t_back_to_back())
      `RUNT(18, if (NUM_CH > 1) t_multichannel())
      `RUNT(23, if (NUM_CH > 1) t_multichannel_reset())
      `RUNT(19, t_csr_perf_trace())
      `RUNT(21, if (EXT_IOMMU != 0) t_iommu_faults())
      `RUNT(20, t_random((SUITE == 0) ? 12 : 3))
    end
    repeat (50) @(negedge clk);
    // final whole-image audit: nothing outside an expected set may have been written since the last release
    `TBCHK(1, "end")
    $display("coverage: reads reordered=%0d writes reordered=%0d  max outstanding rd=%0d wr=%0d  longest burst=%0d beats  completions ok=%0d error=%0d  violation events=%0d",
             n_rd_ooo, n_wr_ooo, max_rd_out, max_wr_out, max_burst_beats, n_done_ok, n_done_err, viol_seen);
    begin
      string hist = "";
      for (int i = 0; i < 256; i++) if (err_hist[i] != 0) hist = {hist, $sformatf(" 0x%02h:%0d", i, err_hist[i])};
      $display("error codes observed:%s", hist);
    end
  endtask
