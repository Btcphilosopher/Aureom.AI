// =============================================================================
// CloudDMA system testbench: DUT + behavioural AXI4 slave + independent protocol checker + unauthorised-access
// monitor + byte-accurate scoreboard + directed and constrained-random tests.
//
//   tb_slave.svh   AXI4 slave model (memory image, random stalls/latency, response reordering, error injection, hang)
//   tb_model.svh   address-translation mirror (independent of the DUT), descriptor builders, expected-write model
//   tb_mon.svh     protocol checker, unauthorised-access monitor, live write checker, completion monitor
//   tb_tests.svh   test tasks (one per item of the brief) and the regression sequencer
//
// Memory image (physical):  HOST 0x0000_0000 + 16 MiB | SRAM 0x4000_0000 + 1 MiB | STOR 0x8000_0000 + 1 MiB.
// Per domain d (0..3): a host window of 2 MiB at IOVA 0x1_0000_0000 mapped through 16 permuted 128 KiB chunks,
// a read-only window, a private window (IOVA 0x2_0000_0000 + d*0x10000: other domains must NOT reach it) and an
// SRAM partition of 64 KiB.  All four domains use the SAME IOVAs but different physical memory.
// =============================================================================
`timescale 1ns/1ps
`include "tb_defs.svh"

module tb_dma_sys #(
  parameter int NUM_CH     = 1,
  parameter int DW         = 64,
  parameter int AW         = 48,
  parameter int DOM_W      = 4,
  parameter int MAXB       = 16,
  parameter int RD_OUT     = 4,
  parameter int WR_OUT     = 4,
  parameter int BUF_BYTES  = 1024,
  parameter int ELQ        = 2,
  parameter int CMDQ       = 2,
  parameter int REORDER_OK = 1,
  parameter int PERM_OUT   = 1,
  parameter int PERM_LAT   = 1,
  parameter int MAX_CHAIN  = 64,
  parameter int TOTLOG2    = 30,       // DUT chain-total limit 2**N (a small value enables the total-limit test)
  parameter int EXT_IOMMU  = 0,        // 1 = the DUT uses the external IOMMU interface, served by the TB model (tb_iommu.svh)
  parameter int SUITE      = 0         // 0 = full regression, 1 = quick, 2 = random only, 3 = reorder-violation negative test, 4 = performance workloads
);
  localparam int WB   = DW / 8;
  localparam int MXO  = (RD_OUT > WR_OUT) ? RD_OUT : WR_OUT;
  localparam int SW   = (MXO > 1) ? $clog2(MXO) : 1;
  localparam int LIDW = SW + 1;
  localparam int CHW  = (NUM_CH > 1) ? $clog2(NUM_CH) : 1;
  localparam int ID_W = CHW + LIDW;
  localparam int NCLI = 4 * NUM_CH;
  localparam int IDP  = (NCLI > 1) ? $clog2(NCLI) : 1;

  localparam int NENT = tb_pkg::NENT;
  localparam int PEW  = $clog2(NENT);

  // ---------------------------------------------------------------- clock, reset
  logic clk = 1'b0;
  always #5 clk = ~clk;
  logic rst_n = 1'b0;
  int   cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  // ---------------------------------------------------------------- DUT ports
  logic                   csr_req_valid = 0; wire csr_req_ready; logic csr_req_write = 0; logic [11:0] csr_req_addr = 0; logic [31:0] csr_req_wdata = 0;
  wire                    csr_rsp_valid; wire [31:0] csr_rsp_rdata; wire csr_rsp_err; wire irq;
  // per-channel command / done_ready drivers are SCALARS per channel, joined by continuous assigns: Verilator 5.020 does not
  // propagate variable-indexed writes made from timing tasks (part-selects or array elements) to the DUT port copy.
  logic [63:0] t_head0 = 0, t_head1 = 0, t_head2 = 0, t_head3 = 0;
  logic [DOM_W-1:0] t_dom0 = 0, t_dom1 = 0, t_dom2 = 0, t_dom3 = 0;
  logic [3:0] t_asid0 = 0, t_asid1 = 0, t_asid2 = 0, t_asid3 = 0;
  logic t_val0 = 0, t_val1 = 0, t_val2 = 0, t_val3 = 0;
  logic t_rdy0 = 1, t_rdy1 = 1, t_rdy2 = 1, t_rdy3 = 1;
  wire  [NUM_CH-1:0]      cmd_valid; wire [NUM_CH-1:0] cmd_ready;
  wire  [NUM_CH*64-1:0]   cmd_head; wire [NUM_CH*DOM_W-1:0] cmd_domain; wire [NUM_CH*4-1:0] cmd_asid;
  wire  [NUM_CH-1:0]      done_valid; wire [NUM_CH-1:0] done_ready;
  wire [63:0] a_head [4]; wire [DOM_W-1:0] a_dom [4]; wire [3:0] a_asid [4]; wire a_val [4]; wire a_rdy [4];
  assign a_head[0] = t_head0; assign a_head[1] = t_head1; assign a_head[2] = t_head2; assign a_head[3] = t_head3;
  assign a_dom[0] = t_dom0;   assign a_dom[1] = t_dom1;   assign a_dom[2] = t_dom2;   assign a_dom[3] = t_dom3;
  assign a_asid[0] = t_asid0; assign a_asid[1] = t_asid1; assign a_asid[2] = t_asid2; assign a_asid[3] = t_asid3;
  assign a_val[0] = t_val0;   assign a_val[1] = t_val1;   assign a_val[2] = t_val2;   assign a_val[3] = t_val3;
  assign a_rdy[0] = t_rdy0;   assign a_rdy[1] = t_rdy1;   assign a_rdy[2] = t_rdy2;   assign a_rdy[3] = t_rdy3;
  genvar gch;
  generate for (gch = 0; gch < NUM_CH; gch++) begin : g_drv
    assign cmd_head[64*gch +: 64]         = a_head[gch];
    assign cmd_domain[DOM_W*gch +: DOM_W] = a_dom[gch];
    assign cmd_asid[4*gch +: 4]           = a_asid[gch];
    assign cmd_valid[gch]                 = a_val[gch];
    assign done_ready[gch]                = a_rdy[gch];
  end endgenerate
  task automatic drv_cmd(input int ch, input logic [63:0] head, input int dom, input int asid, input bit valid);
    case (ch)
      0: begin t_head0 = head; t_dom0 = DOM_W'(dom); t_asid0 = 4'(asid); t_val0 = valid; end
      1: begin t_head1 = head; t_dom1 = DOM_W'(dom); t_asid1 = 4'(asid); t_val1 = valid; end
      2: begin t_head2 = head; t_dom2 = DOM_W'(dom); t_asid2 = 4'(asid); t_val2 = valid; end
      default: begin t_head3 = head; t_dom3 = DOM_W'(dom); t_asid3 = 4'(asid); t_val3 = valid; end
    endcase
  endtask
  task automatic drv_val(input int ch, input bit valid);
    case (ch) 0: t_val0 = valid; 1: t_val1 = valid; 2: t_val2 = valid; default: t_val3 = valid; endcase
  endtask
  task automatic drv_rdy(input int ch, input bit r);
    case (ch) 0: t_rdy0 = r; 1: t_rdy1 = r; 2: t_rdy2 = r; default: t_rdy3 = r; endcase
  endtask

  wire  [NUM_CH*16-1:0]   done_txn; wire [NUM_CH*4-1:0] done_status; wire [NUM_CH*8-1:0] done_err; wire [NUM_CH*4-1:0] done_fault;
  wire  [NUM_CH*DOM_W-1:0] done_domain; wire [NUM_CH*32-1:0] done_bytes, done_crc; wire [NUM_CH-1:0] viol_evt;
  wire                    m_ar_valid; logic m_ar_ready = 0; wire [ID_W-1:0] m_ar_id; wire [AW-1:0] m_ar_addr; wire [7:0] m_ar_len;
  wire  [2:0]             m_ar_size; wire [1:0] m_ar_burst; wire [3:0] m_ar_asid; wire [DOM_W-1:0] m_ar_domain;
  logic                   m_r_valid = 0; wire m_r_ready; logic [ID_W-1:0] m_r_id = 0; logic [DW-1:0] m_r_data = 0; logic [1:0] m_r_resp = 0; logic m_r_last = 0;
  wire                    m_aw_valid; logic m_aw_ready = 0; wire [ID_W-1:0] m_aw_id; wire [AW-1:0] m_aw_addr; wire [7:0] m_aw_len;
  wire  [2:0]             m_aw_size; wire [1:0] m_aw_burst; wire [3:0] m_aw_asid; wire [DOM_W-1:0] m_aw_domain;
  wire                    m_w_valid; logic m_w_ready = 0; wire [DW-1:0] m_w_data; wire [WB-1:0] m_w_strb; wire m_w_last;
  logic                   m_b_valid = 0; wire m_b_ready; logic [ID_W-1:0] m_b_id = 0; logic [1:0] m_b_resp = 0;
  wire                    iommu_req_valid; wire iommu_rsp_ready; wire [DOM_W-1:0] iommu_req_domain; wire [3:0] iommu_req_asid; wire iommu_req_write;
  wire  [AW-1:0]          iommu_req_addr; wire [15:0] iommu_req_bytes; wire [IDP-1:0] iommu_req_id;
  logic                   iommu_req_ready = 0, iommu_rsp_valid = 0, iommu_rsp_ok = 0; logic [IDP-1:0] iommu_rsp_id = 0; logic [3:0] iommu_rsp_fault = 0; logic [AW-1:0] iommu_rsp_pa = 0;
  logic                   ptbl_en = 0; logic [PEW-1:0] ptbl_idx = 0; logic ptbl_valid = 0; logic [DOM_W-1:0] ptbl_domain = 0; logic [3:0] ptbl_asid = 0;
  logic [AW-1:0]          ptbl_base = 0; logic [AW:0] ptbl_size = 0; logic [AW-1:0] ptbl_pa = 0; logic [1:0] ptbl_perm = 0; wire ptbl_rej;

  silicaflux_cloud_dma #(
    .NUM_CH(NUM_CH), .DW(DW), .AW(AW), .DOM_W(DOM_W), .MAX_BURST_BEATS(MAXB), .RD_OUT(RD_OUT), .WR_OUT(WR_OUT), .BUF_BYTES(BUF_BYTES),
    .ELQ(ELQ), .CMDQ(CMDQ), .MAX_CHAIN(MAX_CHAIN), .MAX_TOTAL_LOG2(TOTLOG2), .REORDER_OK(1'(REORDER_OK)), .USE_EXT_IOMMU(1'(EXT_IOMMU)), .PERM_OUT(PERM_OUT), .PERM_ENTRIES(NENT), .PERM_LAT(PERM_LAT)
  ) dut (
    .clk, .rst_n,
    .csr_req_valid, .csr_req_ready, .csr_req_write, .csr_req_addr, .csr_req_wdata, .csr_rsp_valid, .csr_rsp_rdata, .csr_rsp_err, .irq,
    .cmd_valid, .cmd_ready, .cmd_head, .cmd_domain, .cmd_asid,
    .done_valid, .done_ready, .done_txn, .done_status, .done_err, .done_fault, .done_domain, .done_bytes, .done_crc, .viol_evt,
    .m_ar_valid, .m_ar_ready, .m_ar_id, .m_ar_addr, .m_ar_len, .m_ar_size, .m_ar_burst, .m_ar_asid, .m_ar_domain,
    .m_r_valid, .m_r_ready, .m_r_id, .m_r_data, .m_r_resp, .m_r_last,
    .m_aw_valid, .m_aw_ready, .m_aw_id, .m_aw_addr, .m_aw_len, .m_aw_size, .m_aw_burst, .m_aw_asid, .m_aw_domain,
    .m_w_valid, .m_w_ready, .m_w_data, .m_w_strb, .m_w_last, .m_b_valid, .m_b_ready, .m_b_id, .m_b_resp,
    .iommu_req_valid, .iommu_req_ready, .iommu_req_domain, .iommu_req_asid, .iommu_req_write, .iommu_req_addr, .iommu_req_bytes, .iommu_req_id,
    .iommu_rsp_valid, .iommu_rsp_ready, .iommu_rsp_id, .iommu_rsp_ok, .iommu_rsp_fault, .iommu_rsp_pa,
    .ptbl_en, .ptbl_idx, .ptbl_valid, .ptbl_domain, .ptbl_asid, .ptbl_base, .ptbl_size, .ptbl_pa, .ptbl_perm, .ptbl_rej);

  // ---------------------------------------------------------------- bookkeeping shared by the include files (state lives in tb_pkg)
  import tb_pkg::*;
  initial begin p_nch = NUM_CH; p_wb = WB; p_maxb = MAXB; pkg_init(); end

  `include "tb_slave.svh"
  `include "tb_model.svh"
  `include "tb_iommu.svh"
  `include "tb_mon.svh"
  `include "tb_tests.svh"

  initial begin
    run_all();
    $display("----------------------------------------------------------------");
    $display("tb_dma_sys NUM_CH=%0d DW=%0d MAXB=%0d RD_OUT=%0d WR_OUT=%0d BUF=%0d REORDER_OK=%0d PERM_OUT=%0d PERM_LAT=%0d EXT_IOMMU=%0d",
             NUM_CH, DW, MAXB, RD_OUT, WR_OUT, BUF_BYTES, REORDER_OK, PERM_OUT, PERM_LAT, EXT_IOMMU);
    $display("tests=%0d (failed %0d)  checks=%0d  errors=%0d  cycles=%0d", tests_run, tests_failed, checks, errors, cyc);
    $display("bytes moved: read-bursts=%0d write-bursts=%0d  bytes written=%0d", n_rd_bursts, n_wr_bursts, n_wr_bytes);
    if (errors == 0 && tests_failed == 0) $display("TB RESULT PASS"); else $display("TB RESULT FAIL");
    $finish;
  end

  // global watchdog (a hung regression must fail, not spin)
  initial begin
    #(64'd2_000_000_000);
    $display("TB RESULT FAIL (global watchdog)");
    $finish;
  end
endmodule
