// Unit bench: the verification-only struct views of silicaflux_dma_pkg describe exactly the bits that the synthesizable
// RTL reads through the flat LSB constants (descriptor and completion record), and the field widths tile the words.
`timescale 1ns/1ps
module tb_pkg_layout;
  import silicaflux_dma_pkg::*;
  int errors = 0, checks = 0;
  task automatic chk(input bit c, input string m); checks++; if (!c) begin errors++; $display("FAIL: %s", m); end endtask

  initial begin
    sfdma_desc_t d;
    sfdma_cpl_t  r;
    logic [DESC_W-1:0] f;
    logic [CPL_W-1:0]  g;
    d = '0;
    d.version = 8'hA1; d.opcode = 8'hB2; d.flags = 16'hC3D4; d.txn_id = 16'hE5F6; d.domain = 16'h0789; d.src_asid = 4'h1; d.dst_asid = 4'h2; d.cpl_asid = 4'h3;
    d.w2_rsvd = 20'hABCDE; d.length = 32'h1357_9BDF; d.src_addr = 64'hDEAD_BEEF_0123_4567; d.dst_addr = 64'hFEED_FACE_89AB_CDEF;
    d.next_ptr = 64'h1122_3344_5566_7788; d.cpl_addr = 64'h99AA_BBCC_DDEE_FF00; d.seq = 16'h2468; d.w12_rsvd = 16'h1357; d.rsvd = 96'hCAFE_BABE_F00D_1234_5678_9ABC;
    f = d;
    chk(f[DESC_VER_LSB   +: 8]  == 8'hA1,  "VER");     chk(f[DESC_OPC_LSB  +: 8]  == 8'hB2, "OPC");   chk(f[DESC_FLAGS_LSB +: 16] == 16'hC3D4, "FLAGS");
    chk(f[DESC_TXN_LSB   +: 16] == 16'hE5F6, "TXN");   chk(f[DESC_DOM_LSB  +: 16] == 16'h0789, "DOM");
    chk(f[DESC_SASID_LSB +: 4]  == 4'h1, "SASID");     chk(f[DESC_DASID_LSB +: 4] == 4'h2, "DASID");  chk(f[DESC_CASID_LSB +: 4] == 4'h3, "CASID");
    chk(f[DESC_W2RSVD_LSB +: 20] == 20'hABCDE, "W2RSVD");
    chk(f[DESC_LEN_LSB   +: 32] == 32'h1357_9BDF, "LEN");
    chk(f[DESC_SRC_LSB   +: 64] == 64'hDEAD_BEEF_0123_4567, "SRC");  chk(f[DESC_DST_LSB +: 64] == 64'hFEED_FACE_89AB_CDEF, "DST");
    chk(f[DESC_NEXT_LSB  +: 64] == 64'h1122_3344_5566_7788, "NEXT"); chk(f[DESC_CPL_LSB +: 64] == 64'h99AA_BBCC_DDEE_FF00, "CPL");
    chk(f[DESC_SEQ_LSB   +: 16] == 16'h2468, "SEQ");   chk(f[DESC_W12RSVD_LSB +: 16] == 16'h1357, "W12RSVD");
    chk(f[DESC_RSVD_LSB  +: 96] == 96'hCAFE_BABE_F00D_1234_5678_9ABC, "RSVD");
    // word view: word n = bits [32n+31:32n], 64-bit fields low word first (little endian)
    chk(f[32*4 +: 32] == 32'h0123_4567 && f[32*5 +: 32] == 32'hDEAD_BEEF, "SRC words low-first");
    chk(f[32*0 +: 32] == {16'hC3D4, 8'hB2, 8'hA1}, "word 0 composition");
    chk(DESC_RSVD_LSB + 96 == DESC_W, "descriptor fields tile 512 bits");
    // completion record
    r = '0;
    r.status = 4'h2; r.fault = 4'h5; r.err = 8'h37; r.txn_id = 16'h1234; r.domain = 16'h00AB; r.descs = 16'h0003; r.bytes = 32'hCAFE_0001;
    r.crc = 32'h0BAD_F00D; r.err_addr = 64'h0102_0304_0506_0708; r.latency = 32'h0000_0BEE; r.flags = 16'h0006; r.magic = CPL_MAGIC;
    g = r;
    chk(g[CPLR_STATUS_LSB +: 4] == 4'h2, "R.STATUS"); chk(g[CPLR_FAULT_LSB +: 4] == 4'h5, "R.FAULT"); chk(g[CPLR_ERR_LSB +: 8] == 8'h37, "R.ERR");
    chk(g[CPLR_TXN_LSB +: 16] == 16'h1234, "R.TXN"); chk(g[CPLR_DOM_LSB +: 16] == 16'h00AB, "R.DOM"); chk(g[CPLR_DESCS_LSB +: 16] == 16'h0003, "R.DESCS");
    chk(g[CPLR_BYTES_LSB +: 32] == 32'hCAFE_0001, "R.BYTES"); chk(g[CPLR_CRC_LSB +: 32] == 32'h0BAD_F00D, "R.CRC");
    chk(g[CPLR_EADDR_LSB +: 64] == 64'h0102_0304_0506_0708, "R.EADDR"); chk(g[CPLR_LAT_LSB +: 32] == 32'h0BEE, "R.LAT");
    chk(g[CPLR_FLAGS_LSB +: 16] == 16'h0006, "R.FLAGS"); chk(g[CPLR_MAGIC_LSB +: 16] == CPL_MAGIC, "R.MAGIC");
    chk(CPLR_MAGIC_LSB + 16 == CPL_W, "record fields tile 256 bits");
    // flag masks agree with the flag indices
    chk(FLG_RSVD_MASK == 16'hFF80, "reserved flag mask"); chk(FLG_HEADONLY_MASK == ((16'd1 << FLG_CPL_EN) | (16'd1 << FLG_CRC_EN) | (16'd1 << FLG_IRQ_EN)), "head-only mask");
    chk((FLG_RSVD_MASK & ((16'd1 << (FLG_IRQ_EN + 1)) - 16'd1)) == 16'd0, "no defined flag overlaps the reserved mask");
    // error code classes
    chk(err_is_violation(ERR_DOMAIN_MISMATCH) && err_is_violation(ERR_PERM_DESC) && err_is_violation(ERR_PERM_SRC) &&
        err_is_violation(ERR_PERM_DST) && err_is_violation(ERR_PERM_CPL) && !err_is_violation(ERR_BUS_RD) && !err_is_violation(ERR_OVERLAP), "violation class");
    $display("tb_pkg_layout: checks=%0d errors=%0d", checks, errors);
    if (errors == 0) $display("TB RESULT PASS"); else $display("TB RESULT FAIL");
    $finish;
  end
endmodule
