// Unit bench: sfdma_burst_plan vs a byte-walking reference (independent formulation), exhaustive over the
// address offset inside two 4 KiB pages and a set of remaining lengths, for three bus geometries.
`timescale 1ns/1ps
module tb_burst_plan;
  localparam int AW = 20;
  int errors = 0, checks = 0;

  // three geometries: (DW, MAXB)
  logic [AW-1:0] addr; logic [31:0] rem;
  logic [AW-1:0] ea0, ea1, ea2; logic [15:0] eb0, eb1, eb2, nb0, nb1, nb2;
  logic [4:0] bt0; logic [5:0] bt1; logic [6:0] bt2;   // widths set by lint-compatible over-sizing below
  logic [2:0] lo0; logic [3:0] lo1; logic [4:0] lo2;

  wire [$clog2(16)+1-1:0] w_bt0; wire [$clog2(8)+1-1:0] w_bt1; wire [$clog2(32)+1-1:0] w_bt2;
  wire [$clog2(8)-1:0] w_lo0; wire [$clog2(4)-1:0] w_lo1; wire [$clog2(16)-1:0] w_lo2;
  sfdma_burst_plan #(.DW(64),  .AW(AW), .MAXB(16), .BND_LOG2(12)) u0 (.addr, .rem, .env_addr(ea0), .env_bytes(eb0), .beats(w_bt0), .lo(w_lo0), .nbytes(nb0));
  sfdma_burst_plan #(.DW(32),  .AW(AW), .MAXB(8),  .BND_LOG2(12)) u1 (.addr, .rem, .env_addr(ea1), .env_bytes(eb1), .beats(w_bt1), .lo(w_lo1), .nbytes(nb1));
  sfdma_burst_plan #(.DW(128), .AW(AW), .MAXB(32), .BND_LOG2(12)) u2 (.addr, .rem, .env_addr(ea2), .env_bytes(eb2), .beats(w_bt2), .lo(w_lo2), .nbytes(nb2));

  function automatic void check(input int WB, input int MAXB, input logic [AW-1:0] a, input logic [31:0] r,
                                input logic [AW-1:0] g_ea, input logic [15:0] g_eb, input int g_bt, input int g_lo, input logic [15:0] g_nb);
    int n, lo, bt, ceilb;
    longint cur;
    n = 0; cur = a; lo = a % WB;
    while (n < r) begin
      if (n > 0 && (cur % 4096) == 0) break;
      ceilb = (lo + n + 1 + WB - 1) / WB;
      if (n > 0 && ceilb > MAXB) break;
      n++; cur++;
    end
    bt = (lo + n + WB - 1) / WB;
    checks++;
    if (g_nb !== 16'(n) || g_bt !== bt || g_lo !== lo || g_ea !== AW'(a - lo) || g_eb !== 16'(bt * WB)) begin
      errors++;
      if (errors < 10) $display("MISMATCH WB=%0d MAXB=%0d addr=%h rem=%0d  got nb=%0d bt=%0d lo=%0d ea=%h eb=%0d | exp nb=%0d bt=%0d lo=%0d",
                                WB, MAXB, a, r, g_nb, g_bt, g_lo, g_ea, g_eb, n, bt, lo);
    end
    // structural invariants (independent of the reference): burst legal on AXI4
    checks++;
    if (g_bt < 1 || g_bt > MAXB || ((g_ea % 4096) + g_eb) > 4096 || (g_ea % WB) != 0 || g_nb < 1) begin
      errors++; $display("INVARIANT VIOLATION WB=%0d addr=%h rem=%0d", WB, a, r);
    end
  endfunction

  int rems [18] = '{1,2,3,5,8,9,15,16,17,100,127,128,129,200,1000,4096,5000,100000};
  initial begin
    for (int a = 0; a < 8192; a++) begin
      for (int k = 0; k < 18; k++) begin
        addr = AW'(a + 20'h10000); rem = 32'(rems[k]);
        #1;
        check(8,  16, addr, rem, ea0, eb0, int'(w_bt0), int'(w_lo0), nb0);
        check(4,  8,  addr, rem, ea1, eb1, int'(w_bt1), int'(w_lo1), nb1);
        check(16, 32, addr, rem, ea2, eb2, int'(w_bt2), int'(w_lo2), nb2);
      end
    end
    // huge remaining length (32-bit all ones)
    for (int a = 0; a < 300; a++) begin
      addr = AW'(a + 20'h10000); rem = 32'hFFFF_FFFF; #1;
      check(8, 16, addr, rem, ea0, eb0, int'(w_bt0), int'(w_lo0), nb0);
    end
    $display("tb_burst_plan: checks=%0d errors=%0d", checks, errors);
    if (errors == 0) $display("TB RESULT PASS"); else $display("TB RESULT FAIL");
    $finish;
  end
endmodule
