// ============================================================================
// tb_mon.svh -- module-level monitors (the byte-level checks they call live in tb_pkg)
//   * AXI4 protocol checker on the DUT master port (stability, alignment, 4 KiB rule, burst length, WLAST, strobes,
//     W-after-AW, unique outstanding IDs, no traffic while idle or in reset)
//   * unauthorised-access monitor: every burst must lie inside physical ranges that the DOMAIN BOUND TO THE CHANNEL
//     may access with that permission; the sideband domain must equal that binding
//   * live write checker: every strobed byte must belong to the active transaction, carry the expected value and be
//     written at most once (data loss / duplication / misplacement)
//   * completion monitor
// ============================================================================
  int viol_seen = 0;
  initial for (int i = 0; i < 4096; i++) begin rd_out_id[i] = 0; wr_out_id[i] = 0; end

  // ------------------------------------------------------------ valid/ready stability and reset behaviour (sampled pre-edge)
  logic p_ar_v = 0, p_aw_v = 0, p_w_v = 0, p_ar_rdy = 0, p_aw_rdy = 0, p_w_rdy = 0;
  logic [ID_W+AW+8+4+DOM_W-1:0] p_ar_pay, p_aw_pay;
  logic [DW+WB:0] p_w_pay;
  logic p_rst_n = 0;
  logic p_soft = 0;
  int rst_age = 0;
  always @(posedge clk) begin
    logic [ID_W+AW+8+4+DOM_W-1:0] ar_pay, aw_pay;
    logic [DW+WB:0] w_pay;
    ar_pay = {m_ar_id, m_ar_addr, m_ar_len, m_ar_asid, m_ar_domain};
    aw_pay = {m_aw_id, m_aw_addr, m_aw_len, m_aw_asid, m_aw_domain};
    w_pay  = {m_w_data, m_w_strb, m_w_last};
    if (rst_n && p_rst_n && !dut.soft_rst && !p_soft) begin          // a soft reset deliberately cancels requests
      if (p_ar_v && !p_ar_rdy) `TBCHK(m_ar_valid && ar_pay === p_ar_pay, "AR request withdrawn or changed before acceptance (AXI4 stability rule)")
      if (p_aw_v && !p_aw_rdy) `TBCHK(m_aw_valid && aw_pay === p_aw_pay, "AW request withdrawn or changed before acceptance (AXI4 stability rule)")
      if (p_w_v  && !p_w_rdy ) `TBCHK(m_w_valid  && w_pay  === p_w_pay,  "W beat withdrawn or changed before acceptance (AXI4 stability rule)")
      if (m_w_valid) `TBCHK(oldest_wq_needing_data() >= 0 || (p_w_v && !p_w_rdy), "W beat presented before its AW was accepted (design rule)")
    end
    if (!rst_n) rst_age <= rst_age + 1; else rst_age <= 0;
    if (!rst_n && rst_age >= 2) begin                                 // random initial state needs the first reset edges to settle
      `TBCHK(!m_ar_valid && !m_aw_valid && !m_w_valid, "bus request valid during reset")
    end
    p_ar_v <= m_ar_valid; p_aw_v <= m_aw_valid; p_w_v <= m_w_valid;
    p_ar_rdy <= m_ar_ready; p_aw_rdy <= m_aw_ready; p_w_rdy <= m_w_ready;
    p_ar_pay <= ar_pay; p_aw_pay <= aw_pay; p_w_pay <= w_pay; p_rst_n <= rst_n; p_soft <= dut.soft_rst;
  end

  // ------------------------------------------------------------ completion monitor: queue the events, check ordering of acks
  int      n_done_ok = 0, n_done_err = 0;
  int      err_hist [256];
  initial for (int i = 0; i < 256; i++) err_hist[i] = 0;

  always @(posedge clk) if (rst_n) begin
    for (int c = 0; c < NUM_CH; c++) begin
      if (done_valid[c] && done_ready[c]) begin
        dq_push(c, int'(done_txn[16*c +: 16]), int'(done_status[4*c +: 4]), int'(done_err[8*c +: 8]), int'(done_fault[4*c +: 4]),
                int'(done_domain[DOM_W*c +: DOM_W]), longint'(done_bytes[32*c +: 32]), done_crc[32*c +: 32]);
        if (done_status[4*c +: 4] == 0) n_done_ok++; else n_done_err++;
        err_hist[done_err[8*c +: 8]]++;
        // COMPLETION ORDERING: nothing may still be unacknowledged when the completion is signalled
        if (!allow_pending_at_done[c]) begin
          `TBCHK(wr_pend[c] == 0, $sformatf("COMPLETION BEFORE ACKNOWLEDGE: channel %0d signalled done with %0d write burst(s) not yet acknowledged", c, wr_pend[c]))
          `TBCHK(rd_pend[c] == 0, $sformatf("channel %0d signalled done with %0d read burst(s) still outstanding", c, rd_pend[c]))
        end
        if (viol_evt[c]) viol_seen++;
        if_pop(c);
      end
    end
  end

  // ------------------------------------------------------------ debug view of the permission checker (only with +dbg)
  always @(posedge clk) if (dbg && rst_n) begin
    if (dut.i_req_valid && dut.i_req_ready) $display("[%0d] CHK req dom=%0d asid=%0d wr=%0b addr=%h bytes=%0d id=%0d", cyc, dut.i_req_domain, dut.i_req_asid, dut.i_req_write, dut.i_req_addr, dut.i_req_bytes, dut.i_req_id);
    if (dut.i_rsp_valid) $display("[%0d] CHK rsp id=%0d ok=%0b fault=%0d pa=%h", cyc, dut.i_rsp_id, dut.i_rsp_ok, dut.i_rsp_fault, dut.i_rsp_pa);
    if (ptbl_en) $display("[%0d] PTBL write idx=%0d valid=%0b dom=%0d asid=%0d base=%h size=%h pa=%h perm=%0d rej=%0b", cyc, ptbl_idx, ptbl_valid, ptbl_domain, ptbl_asid, ptbl_base, ptbl_size, ptbl_pa, ptbl_perm, ptbl_rej);
    if (ptbl_rej) $display("[%0d] PTBL write REFUSED", cyc);
  end
  always @(posedge clk) if (dbg && rst_n) begin
    if (cmd_valid[0] && cmd_ready[0]) $display("[%0d] CMD accepted head=%h dom=%0d asid=%0d", cyc, cmd_head[63:0], cmd_domain[DOM_W-1:0], cmd_asid[3:0]);
    if (dut.g_ch[0].u_ch.start) $display("[%0d] CH start head=%h", cyc, dut.g_ch[0].u_ch.q_head);
  end
  always @(posedge clk) if (dbg && rst_n && (cyc >= 115 && cyc <= 118)) begin
    $display("[%0d] tb.cmd_head=%h dut.cmd_head=%h ch.cmd_head=%h ch.cmd_domain=%h ch.cmd_asid=%h", cyc, cmd_head, dut.cmd_head, dut.g_ch[0].u_ch.cmd_head, dut.g_ch[0].u_ch.cmd_domain, dut.g_ch[0].u_ch.cmd_asid);
    $display("[%0d] FIFO in_valid=%b in_ready=%b in_data=%h out_valid=%b out_data=%h wp=%0d rp=%0d cnt=%0d mem0=%h", cyc,
      dut.g_ch[0].u_ch.u_cmdq.in_valid, dut.g_ch[0].u_ch.u_cmdq.in_ready, dut.g_ch[0].u_ch.u_cmdq.in_data, dut.g_ch[0].u_ch.u_cmdq.out_valid,
      dut.g_ch[0].u_ch.u_cmdq.out_data, dut.g_ch[0].u_ch.u_cmdq.wp, dut.g_ch[0].u_ch.u_cmdq.rp, dut.g_ch[0].u_ch.u_cmdq.cnt, dut.g_ch[0].u_ch.u_cmdq.mem[0]);
  end
