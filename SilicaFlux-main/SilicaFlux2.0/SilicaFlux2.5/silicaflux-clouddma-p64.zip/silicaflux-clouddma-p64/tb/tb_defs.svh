// shared macros
`ifndef TB_DEFS_SVH
`define TB_DEFS_SVH
`define TBCHK(cond, msg) begin checks++; if (!(cond)) fail(msg); end
`endif
