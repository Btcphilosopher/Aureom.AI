// ============================================================================
// tb_model.svh -- module-level part of the translation mirror: programming the DUT's permission table AND the
// independent mirror (tb_pkg::mp_*) in parallel.  Everything else of the model lives in tb_pkg.
// ============================================================================
  task automatic map_entry(input int idx, input bit valid, input int dom, input int asid, input longint base, input longint size,
                           input longint pa, input int perm);
    @(negedge clk);
    ptbl_en = 1; ptbl_idx = PEW'(idx); ptbl_valid = valid; ptbl_domain = DOM_W'(dom); ptbl_asid = 4'(asid);
    ptbl_base = AW'(base); ptbl_size = (AW+1)'(size); ptbl_pa = AW'(pa); ptbl_perm = 2'(perm);
    @(negedge clk); ptbl_en = 0;
    mp_v[idx] = valid; mp_dom[idx] = dom; mp_asid[idx] = asid; mp_base[idx] = base; mp_size[idx] = size; mp_pa[idx] = pa; mp_perm[idx] = perm;
  endtask

  task automatic setup_domains();
    for (int e = 0; e < NENT; e++) mp_v[e] = 0;
    for (int d = 0; d < NDOM; d++) begin
      for (int j = 0; j < 8; j++)                                   // 8 permuted 256 KiB chunks = the 2 MiB RW host window
        map_entry(d*16 + j, 1, d, int'(silicaflux_dma_pkg::ASID_HOST), IOVA_H + longint'(j) * 64'h4_0000,
                  64'h4_0000, HOST_PA + longint'(d) * 64'h40_0000 + longint'((j*3 + d) % 8) * 64'h4_0000, 3);
      map_entry(d*16 + 8,  1, d, int'(silicaflux_dma_pkg::ASID_HOST), IOVA_RO, 64'h1_0000, HOST_PA + longint'(d) * 64'h40_0000 + 64'h20_0000, 1);   // read-only
      map_entry(d*16 + 9,  1, d, int'(silicaflux_dma_pkg::ASID_HOST), IOVA_PRIV + longint'(d) * 64'h1_0000, 64'h1_0000,
                HOST_PA + longint'(d) * 64'h40_0000 + 64'h21_0000, 3);                                                                              // private
      map_entry(d*16 + 10, 1, d, int'(silicaflux_dma_pkg::ASID_SRAM), IOVA_S, 64'h1_0000, SRAM_PA + longint'(d) * 64'h1_0000, 3);                   // SRAM partition
      map_entry(d*16 + 11, 1, d, int'(silicaflux_dma_pkg::ASID_STORAGE), IOVA_ST, 64'h1_0000, STOR_PA + longint'(d) * 64'h1_0000, 3);              // storage window
      map_entry(d*16 + 12, 1, d, int'(silicaflux_dma_pkg::ASID_HOST), 64'h1_0050_0000, 64'h1_0000, 64'h2000_0000, 3);                                // maps to UNMAPPED physical memory
    end
  endtask
