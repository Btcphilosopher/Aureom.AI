| config | top | parameters | generic cells | flops | latches | check problems |
|---|---|---|---|---|---|---|
| base | silicaflux_cloud_dma |  | 256865 | 19298 | 0 | 0 |
| one_out | silicaflux_cloud_dma | RD_OUT=1 WR_OUT=1 ELQ=1 CMDQ=1 BUF_BYTES=256 | 116318 | 12299 | 0 | 0 |
| dw128 | silicaflux_cloud_dma | DW=128 BUF_BYTES=4096 | 1421141 | 43882 | 0 | 0 |
| nocrc | silicaflux_cloud_dma | CRC_ON=0 | 253450 | 19200 | 0 | 0 |
| ch2 | silicaflux_cloud_dma | NUM_CH=2 | 474764 | 33086 | 0 | 0 |
| ext_iommu | silicaflux_cloud_dma | USE_EXT_IOMMU=1 | 226181 | 16749 | 0 | 0 |
