// =============================================================================
// SilicaFlux-STORE :: Project 59 -- SecureStore :: sfsec_pkg
// Shared constants, error codes, lifecycle encodings and small pure functions.
// Aureom.AI | SilicaFlux-STORE.   Classification: SYNTHESIZABLE (package)
// =============================================================================
`default_nettype none

package sfsec_pkg;

  // ------------------------------------------------------------------ data-unit geometry
  localparam int DIM_BYTES   = 16;      // data-integrity metadata, encrypted with the payload
  localparam int PMD_BYTES   = 32;      // physical-metadata record, cleartext, rides in the ECC UMETA field
  localparam logic [7:0] PMD_MAGIC   = 8'h5C;
  localparam logic [7:0] DIM_VERSION = 8'h01;
  localparam logic [7:0] FL_ENC = 8'h01, FL_AUTH = 8'h02;

  // record classes (domain separation of CRC and CMAC inputs, docs/03)
  localparam logic [7:0] CLS_PMD = 8'h01, CLS_MAP = 8'h02, CLS_JRN = 8'h03, CLS_HLT = 8'h04;

  // ------------------------------------------------------------------ error / status codes (response, log)
  localparam logic [7:0]
    E_NONE         = 8'd0,
    E_LIFECYCLE    = 8'd1,    // operation not permitted in the current lifecycle state / lockdown
    E_KEY_INVALID  = 8'd2,    // key slot empty, invalidated or not loaded
    E_KEY_MISMATCH = 8'd3,    // PMD key slot / generation differs from the selected active key
    E_LEN          = 8'd4,    // unsupported data-unit length
    E_DMA          = 8'd5,    // host DMA / bus fault during the data transfer
    E_POISON       = 8'd6,    // poisoned (known-corrupt) data presented on the write path
    E_ECC_UNCORR   = 8'd7,    // NAND ECC: uncorrectable
    E_ECC_INTEG    = 8'd8,    // NAND ECC: decoder "success" refuted by the codeword CRC-16 (miscorrection)
    E_PMD_CRC      = 8'd9,    // physical metadata CRC-32C mismatch (accidental corruption)
    E_PMD_AUTH     = 8'd10,   // physical metadata CMAC mismatch with valid CRC (forgery / wrong key)
    E_LBA_MISMATCH = 8'd11,   // PMD logical address differs from the requested one (misdirected read)
    E_DI_GUARD     = 8'd12,   // data guard CRC-32C mismatch after decryption
    E_DI_REFTAG    = 8'd13,   // DIM reference tag differs from the requested LBA
    E_DI_FORMAT    = 8'd14,   // DIM version / reserved fields invalid
    E_NAND_PROG    = 8'd15,   // NAND program failed
    E_NAND_READ    = 8'd16,   // NAND read failed / framing error
    E_ERASED       = 8'd17,   // page reads as erased (never written)
    E_RESET        = 8'd18,   // command aborted by a controller / secure reset
    E_BUSY         = 8'd19,   // command refused: pipeline busy (should not happen with cmd_ready)
    E_KEY_EQ       = 8'd20,   // XTS key halves equal (rejected by policy)
    E_PMD_FORMAT   = 8'd21,   // PMD magic / reserved / flag fields invalid
    E_ENT          = 8'd22,   // entropy source unavailable / timed out
    E_PRK          = 8'd23,   // platform root key not available
    E_RANGE        = 8'd24;   // illegal parameter (slot index, class, length)

  // ------------------------------------------------------------------ lifecycle (SecureSilicon CC_SB_LC_*)
  localparam logic [3:0] LC_DEV = 4'd0, LC_PROV = 4'd1, LC_PROD = 4'd2, LC_RECOVERY = 4'd3, LC_INVALID = 4'hF;

  // ------------------------------------------------------------------ commands
  localparam logic [1:0] OP_WRITE = 2'd0, OP_READ = 2'd1;

  // ------------------------------------------------------------------ RAS event indices (docs/06)
  localparam int NEV = 24;
  localparam int EV_ECC_CORR    = 0,   // codeword corrected
                 EV_ECC_UNCORR  = 1,   // uncorrectable
                 EV_ECC_INTEG   = 2,   // miscorrection caught
                 EV_ECC_SCRUB   = 3,   // scrub hint (flip threshold)
                 EV_DI_FAIL     = 4,   // guard / reftag / format failure
                 EV_PMD_FAIL    = 5,   // PMD crc / format failure
                 EV_AUTH_FAIL   = 6,   // PMD / record authentication failure (security event)
                 EV_KEY_FAIL    = 7,   // key invalid / mismatch use
                 EV_LBA_FAIL    = 8,   // misdirected read
                 EV_DMA_ERR     = 9,
                 EV_POISON      = 10,
                 EV_NAND_PROG   = 11,
                 EV_LIFECYCLE   = 12,  // refused privileged / lifecycle-restricted operation
                 EV_THERM_WARN  = 13,
                 EV_RESET       = 14,  // controller reset observed
                 EV_RECOVERY    = 15,  // power-loss recovery performed (reported by PowerSafe)
                 EV_BAD_BLOCK   = 16,
                 EV_ERASE       = 17,
                 EV_KEY_ERASE   = 18,  // key invalidated / zeroized
                 EV_SEC_RESET   = 19,  // secure reset executed
                 EV_PROTOCOL    = 20,  // framing / protocol violation seen by the pipeline
                 EV_ERASED_READ = 21,
                 EV_ENT_FAIL    = 22,
                 EV_REC_FAIL    = 23;  // record guard (MAP / JRN / HLT) verification failure

  // ------------------------------------------------------------------ pure helpers
  function automatic logic [127:0] bswap128(input logic [127:0] x);
    for (int i = 0; i < 16; i++) bswap128[8*i +: 8] = x[8*(15-i) +: 8];
  endfunction

  function automatic logic [63:0] bswap64(input logic [63:0] x);
    for (int i = 0; i < 8; i++) bswap64[8*i +: 8] = x[8*(7-i) +: 8];
  endfunction
  function automatic logic [47:0] bswap48(input logic [47:0] x);
    for (int i = 0; i < 6; i++) bswap48[8*i +: 8] = x[8*(5-i) +: 8];
  endfunction
  function automatic logic [31:0] bswap32(input logic [31:0] x);
    return {x[7:0], x[15:8], x[23:16], x[31:24]};
  endfunction

  // multiply an XTS tweak by alpha in GF(2^128) (IEEE 1619 / SP 800-38E); the argument and result are the
  // 16 tweak bytes as an AES block (byte 0 in bits [127:120]); the field element is the little-endian integer.
  function automatic logic [127:0] xts_mul_alpha(input logic [127:0] t_blk);
    logic [127:0] le;
    le = bswap128(t_blk);
    le = {le[126:0], 1'b0} ^ (le[127] ? 128'h87 : 128'h0);
    return bswap128(le);
  endfunction

  // one byte of a reflected 32-bit CRC (poly given in reflected form), init/xorout handled by the caller
  function automatic logic [31:0] crc32r_byte(input logic [31:0] crc, input logic [7:0] b, input logic [31:0] poly_r);
    logic [31:0] c;
    c = crc ^ {24'b0, b};
    for (int i = 0; i < 8; i++) c = c[0] ? ((c >> 1) ^ poly_r) : (c >> 1);
    return c;
  endfunction

  // one byte of CRC-16/CCITT-FALSE (poly 0x1021, MSB first), init 0xFFFF, no xorout
  function automatic logic [15:0] crc16_byte(input logic [15:0] crc, input logic [7:0] b);
    logic [15:0] c;
    c = crc ^ {b, 8'h00};
    for (int i = 0; i < 8; i++) c = c[15] ? ((c << 1) ^ 16'h1021) : (c << 1);
    return c;
  endfunction

  // NAND data-randomiser keystream byte for (physical page address, byte column).  A DECORRELATION function for
  // NAND cell-pattern balance -- NOT cryptographic and NOT a substitute for encryption (docs/04).
  function automatic logic [7:0] scr_ks(input logic [31:0] ppa, input logic [15:0] col);
    logic [31:0] h;
    h = (ppa ^ 32'hA5C35E17) + ({16'h0, col} * 32'h9E3779B1);
    h = h ^ (h >> 15);
    h = h * 32'h85EBCA6B;
    h = h ^ (h >> 13);
    h = h * 32'hC2B2AE35;
    h = h ^ (h >> 16);
    return h[7:0];
  endfunction

  localparam logic [31:0] POLY_CRC32C = 32'h82F63B78;   // Castagnoli, reflected
  localparam logic [31:0] POLY_CRC32  = 32'hEDB88320;   // IEEE 802.3, reflected (FTL / zlib / boot-ROM compatible)

endpackage

`default_nettype wire
