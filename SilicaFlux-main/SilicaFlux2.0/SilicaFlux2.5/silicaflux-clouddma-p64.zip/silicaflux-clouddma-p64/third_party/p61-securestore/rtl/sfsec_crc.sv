// =============================================================================
// SilicaFlux SecureStore :: sfsec_crc -- CRC engine for accidental-corruption detection
//
//   MODE 0  CRC-32C   (Castagnoli, reflected, init/xorout 0xFFFFFFFF)  data guard, PMD / record CRCs
//   MODE 1  CRC-32    (IEEE 802.3, reflected, init/xorout 0xFFFFFFFF)  FTL (sfftl_crc32) compatible
//   MODE 2  CRC-16    (CCITT-FALSE, poly 0x1021, init 0xFFFF)          ECC-slot compatible
//
// NOT a cryptographic primitive: a CRC detects accidental corruption only.  Anyone can compute a CRC over
// forged data; authenticity is provided separately (sfsec_cmac, docs/03).
// Up to 4 bytes per cycle (byte 0 = bits [7:0]).  `clr` loads the init value.  `crc_o` is the final value
// (xorout applied) for the bytes consumed so far.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfsec_crc
  import sfsec_pkg::*;
(
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        clr,        // start a new message (priority over en)
  input  wire logic [1:0]  mode_i,     // latched on clr
  input  wire logic        en,
  input  wire logic [31:0] data_i,
  input  wire logic [2:0]  nbytes_i,   // 1..4 valid bytes in data_i[7:0] upward
  output logic [31:0]      crc_o
);
  logic [31:0] st;
  logic [1:0]  mode_q;
  logic [31:0] poly;
  logic [31:0] nxt;

  assign poly = (mode_q == 2'd1) ? POLY_CRC32 : POLY_CRC32C;

  always_comb begin
    nxt = st;
    for (int i = 0; i < 4; i++) begin
      if (i < nbytes_i) begin
        if (mode_q == 2'd2) nxt = {16'h0, crc16_byte(nxt[15:0], data_i[8*i +: 8])};
        else                nxt = crc32r_byte(nxt, data_i[8*i +: 8], poly);
      end
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st     <= 32'hFFFF_FFFF;
      mode_q <= 2'd0;
    end else if (clr) begin
      mode_q <= (mode_i == 2'd3) ? 2'd0 : mode_i;
      st     <= (mode_i == 2'd2) ? 32'h0000_FFFF : 32'hFFFF_FFFF;
    end else if (en) begin
      st <= nxt;
    end
  end

  assign crc_o = (mode_q == 2'd2) ? {16'h0, st[15:0]} : ~st;
endmodule

`default_nettype wire
