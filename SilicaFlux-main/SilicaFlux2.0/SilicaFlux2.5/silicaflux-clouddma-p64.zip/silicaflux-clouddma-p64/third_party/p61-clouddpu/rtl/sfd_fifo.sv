// =============================================================================
// CloudDPU :: sfd_fifo -- synchronous valid/ready FIFO, show-ahead output
//   * DEPTH >= 1, any value (pointers wrap explicitly)
//   * `flush` empties the FIFO (synchronous, wins over a same-cycle push)
//   * storage is not reset (qualified by out_valid); control state is
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_fifo #(
  parameter int WIDTH = 8,
  parameter int DEPTH = 4
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             flush,
  input  wire logic             in_valid,
  output logic                  in_ready,
  input  wire logic [WIDTH-1:0] in_data,
  output logic                  out_valid,
  input  wire logic             out_ready,
  output logic [WIDTH-1:0]      out_data,
  output logic [$clog2(DEPTH+1)-1:0] level
);
  localparam int PW = (DEPTH > 1) ? $clog2(DEPTH) : 1;
  logic [WIDTH-1:0]            mem [DEPTH];
  logic [PW-1:0]               rp, wp;
  logic [$clog2(DEPTH+1)-1:0]  cnt;

  wire push = in_valid && in_ready;
  wire pop  = out_valid && out_ready;

  assign in_ready  = (cnt != DEPTH[$clog2(DEPTH+1)-1:0]);
  assign out_valid = (cnt != 0);
  assign out_data  = mem[rp];
  assign level     = cnt;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rp  <= '0;
      wp  <= '0;
      cnt <= '0;
    end else if (flush) begin
      rp  <= '0;
      wp  <= '0;
      cnt <= '0;
    end else begin
      if (push) wp <= (wp == PW'(DEPTH - 1)) ? '0 : wp + 1'b1;
      if (pop)  rp <= (rp == PW'(DEPTH - 1)) ? '0 : rp + 1'b1;
      if (push && !pop)      cnt <= cnt + 1'b1;
      else if (!push && pop) cnt <= cnt - 1'b1;
    end
  end

  always_ff @(posedge clk) begin
    if (push && !flush) mem[wp] <= in_data;
  end
endmodule

`default_nettype wire
