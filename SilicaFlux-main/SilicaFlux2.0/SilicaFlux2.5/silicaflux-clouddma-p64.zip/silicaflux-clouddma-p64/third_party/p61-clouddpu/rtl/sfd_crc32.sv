// =============================================================================
// CloudDPU :: sfd_crc32 -- CRC-32 (IEEE 802.3, reflected, init/xorout 0xFFFFFFFF), up to 4 bytes per cycle
//
// Same port contract as SecureStore's sfsec_crc in MODE 1 (clr / en / data_i / nbytes_i / crc_o), so the two
// are interchangeable and are cross-checked against each other in tb/tb_crc_xcheck.sv.  sfsec_crc itself
// (P59, 768-message evidence) is NOT used in the synthesizable path because its package uses `return`,
// which the baseline Yosys 0.33 flow rejects, and vendored files are never edited.
//   byte 0 = data_i[7:0];  nbytes_i = 1..4 valid bytes;  `clr` (priority over en) loads the init value.
// Check value: CRC-32("123456789") = 0xCBF43926.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_crc32 (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        clr,
  input  wire logic        en,
  input  wire logic [31:0] data_i,
  input  wire logic [2:0]  nbytes_i,
  output logic      [31:0] crc_o
);
  function automatic logic [31:0] crc_byte(input logic [31:0] crc, input logic [7:0] b);
    integer i;
    logic [31:0] c;
    c = crc ^ {24'd0, b};
    for (i = 0; i < 8; i = i + 1) c = c[0] ? ((c >> 1) ^ 32'hEDB8_8320) : (c >> 1);
    crc_byte = c;
  endfunction

  logic [31:0] st_q;
  logic [31:0] nxt;
  always_comb begin
    nxt = st_q;
    if (nbytes_i > 3'd0) nxt = crc_byte(nxt, data_i[7:0]);
    if (nbytes_i > 3'd1) nxt = crc_byte(nxt, data_i[15:8]);
    if (nbytes_i > 3'd2) nxt = crc_byte(nxt, data_i[23:16]);
    if (nbytes_i > 3'd3) nxt = crc_byte(nxt, data_i[31:24]);
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)    st_q <= 32'hFFFF_FFFF;
    else if (clr)  st_q <= 32'hFFFF_FFFF;
    else if (en)   st_q <= nxt;
  end
  assign crc_o = ~st_q;
endmodule

`default_nettype wire
