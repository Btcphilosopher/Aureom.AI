// =============================================================================
// CloudDPU :: sfd_rr_arb -- round-robin arbiter.  `grant` is a combinational one-hot
// choice among `req`; the priority pointer moves past the winner when `advance`.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfd_rr_arb #(
  parameter int N = 2
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic [N-1:0] req,
  input  wire logic         advance,
  output logic [N-1:0]      grant,
  output logic              any
);
  localparam int IW = (N > 1) ? $clog2(N) : 1;
  logic [IW-1:0] ptr;
  logic [IW-1:0] win;
  logic          found;
  integer        j;

  always_comb begin
    grant = '0;
    found = 1'b0;
    win   = '0;
    j     = 0;
    for (int i = 0; i < N; i++) begin
      j = i + 32'(ptr);
      if (j >= N) j = j - N;
      if (!found && req[j]) begin
        found    = 1'b1;
        grant[j] = 1'b1;
        win      = j[IW-1:0];
      end
    end
  end
  assign any = found;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)                ptr <= '0;
    else if (advance && found) ptr <= (win == IW'(N - 1)) ? '0 : win + 1'b1;
  end
endmodule

`default_nettype wire
