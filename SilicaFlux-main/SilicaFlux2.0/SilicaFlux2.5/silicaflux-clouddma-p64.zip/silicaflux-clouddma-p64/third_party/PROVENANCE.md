# Provenance of `third_party/`

Everything under this directory is **copied byte-for-byte** from `silicaflux-clouddpu-p61.zip`
(`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/` in the repository `btcphilosopher/Aureom.AI`, HEAD `75371f0`;
archive SHA-256 `13acc779c1da83a90b907a4b74626c9b49461bdcc0be6c5fcb90a779d0dd1c27`) and is **never edited**.

| File | Archive member | Used for |
|---|---|---|
| `p61-clouddpu/rtl/sfd_fifo.sv` | `rtl/dpu/sfd_fifo.sv` | command queue, trace FIFO, AXI W-order FIFO (synthesizable path) |
| `p61-clouddpu/rtl/sfd_rr_arb.sv` | `rtl/dpu/sfd_rr_arb.sv` | trace-source arbiter (synthesizable path) |
| `p61-clouddpu/rtl/sfd_crc32.sv` | `rtl/dpu/sfd_crc32.sv` | independent golden CRC in `tb/tb_crc.sv` (not on the datapath) |
| `p61-securestore/rtl/sfsec_crc.sv`, `sfsec_pkg.sv` | `third_party/silicaflux-securestore/rtl/…` | the CRC golden chain of P61 (`sfd_crc32 == sfsec_crc`); **not compiled** in this project |

* `MANIFEST.tsv` records archive member and SHA-256 per file; `SHA256SUMS` is the same list in `sha256sum` format.
* `scripts/check_vendor.py` proves the tree is unmodified; with `--archive <path to silicaflux-clouddpu-p61.zip>` it also compares
  every file with its archive member (done during development: all identical).
* **License.** No license file exists in the repository; none is carried here. An owner must decide before external distribution.
