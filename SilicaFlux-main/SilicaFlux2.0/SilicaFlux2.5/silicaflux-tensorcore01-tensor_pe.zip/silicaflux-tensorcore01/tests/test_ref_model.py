"""Self-tests for model/tensor_pe_ref.py (stdlib unittest, no dependencies).

Run:  python3 -m unittest discover -s tests -v
"""

import os
import random
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "model"))

import tensor_pe_ref as ref  # noqa: E402


def bits_to_signed(bits: str) -> int:
    """Independent two's-complement decode from a bit string."""
    v = int(bits, 2)
    return v - (1 << len(bits)) if bits[0] == "1" else v


class TestWidthSemantics(unittest.TestCase):
    def test_wrap_matches_bit_truncation(self):
        rng = random.Random(1)
        for w in (1, 2, 3, 8, 16, 17, 32, 40, 64):
            for _ in range(2000):
                x = rng.randint(-(1 << (w + 3)), 1 << (w + 3))
                bits = format(x & ((1 << w) - 1), f"0{w}b")
                self.assertEqual(ref.wrap(x, w), bits_to_signed(bits))

    def test_saturate(self):
        self.assertEqual(ref.saturate(1 << 31, 32), (1 << 31) - 1)
        self.assertEqual(ref.saturate(-(1 << 31) - 1, 32), -(1 << 31))
        self.assertEqual(ref.saturate(123, 32), 123)

    def test_wrap_and_saturate_differ(self):
        # 2^31 wrapped is INT32_MIN; saturated is INT32_MAX: never interchangeable.
        self.assertEqual(ref.wrap(1 << 31, 32), -(1 << 31))
        self.assertEqual(ref.saturate(1 << 31, 32), (1 << 31) - 1)


class TestProducts(unittest.TestCase):
    def test_int8_product_range(self):
        self.assertEqual(ref.product_range(8, 8), (-16256, 16384))

    def test_corner_products(self):
        for a, b, p in [(0, 0, 0), (1, 1, 1), (-1, -1, 1), (-128, -128, 16384),
                        (-128, 127, -16256), (127, -128, -16256), (127, 127, 16129)]:
            self.assertEqual(a * b, p)
        # -128 * -128 needs 16 signed bits: it does not fit in 15.
        self.assertGreater(16384, ref.int_range(15)[1])
        self.assertLessEqual(16384, ref.int_range(16)[1])

    def test_exhaustive_int8_products_fit_16_bits(self):
        lo, hi = ref.int_range(16)
        for a in range(-128, 128):
            for b in range(-128, 128):
                self.assertTrue(lo <= a * b <= hi)


class TestMaxExactK(unittest.TestCase):
    def test_closed_form_used_by_rtl(self):
        # tensor_pe_pkg::tpe_max_exact_k = 2^(ACC_W - A_W - B_W + 1) - 1
        for a_w in range(2, 9):
            for b_w in range(2, 9):
                for acc_w in range(a_w + b_w, 65):
                    self.assertEqual(ref.max_exact_k(acc_w, a_w, b_w),
                                     (1 << (acc_w - a_w - b_w + 1)) - 1,
                                     (acc_w, a_w, b_w))

    def test_documented_values(self):
        self.assertEqual(ref.max_exact_k(32), 131071)
        self.assertEqual(ref.max_exact_k(40), 33554431)
        self.assertEqual(ref.max_exact_k(20), 31)
        self.assertEqual(ref.max_exact_k(16), 1)

    def test_brute_force_reachable_sums(self):
        """For tiny widths, enumerate every reachable K-term sum."""
        for a_w, b_w in [(2, 2), (3, 3), (2, 3), (3, 2)]:
            prods = sorted({a * b for a in range(*_rng(a_w)) for b in range(*_rng(b_w))})
            for acc_w in range(a_w + b_w, a_w + b_w + 4):
                lo, hi = ref.int_range(acc_w)
                sums = {0}
                k_ok = 0
                for k in range(1, 200):
                    sums = {s + p for s in sums for p in prods}
                    if min(sums) < lo or max(sums) > hi:
                        break
                    k_ok = k
                self.assertEqual(k_ok, ref.max_exact_k(acc_w, a_w, b_w), (a_w, b_w, acc_w))


def _rng(w):
    lo, hi = ref.int_range(w)
    return lo, hi + 1


class TestAccumulate(unittest.TestCase):
    def test_clear_and_load(self):
        acc, ovf = ref.accumulate_step(1000, True, True, True, 7, 32, ref.OVF_SATURATE)
        self.assertEqual((acc, ovf), (7, False))

    def test_clear_without_valid(self):
        self.assertEqual(ref.accumulate_step(5, True, True, False, None, 32, 0), (0, False))

    def test_hold_without_token(self):
        self.assertEqual(ref.accumulate_step(5, True, False, False, None, 32, 0), (5, True))

    def test_overflow_policies(self):
        hi = (1 << 31) - 1
        self.assertEqual(ref.accumulate_step(hi, False, False, True, 1, 32, ref.OVF_SATURATE),
                         (hi, True))
        self.assertEqual(ref.accumulate_step(hi, False, False, True, 1, 32, ref.OVF_WRAP),
                         (-(1 << 31), True))

    def test_exact_reach_of_extremes_is_not_overflow(self):
        hi = (1 << 31) - 1
        lo = -(1 << 31)
        self.assertEqual(ref.accumulate_step(hi - 1, False, False, True, 1, 32, 0), (hi, False))
        self.assertEqual(ref.accumulate_step(lo + 1, False, False, True, -1, 32, 0), (lo, False))

    def test_constant_closed_form_matches_iteration(self):
        rng = random.Random(7)
        for _ in range(3000):
            acc_w = rng.choice([12, 16, 17, 20, 24])
            lo, hi = ref.int_range(acc_w)
            policy = rng.choice([ref.OVF_SATURATE, ref.OVF_WRAP])
            acc = rng.randint(lo, hi)
            ovf = rng.random() < 0.2
            p = rng.choice([rng.randint(-16256, 16384), 16384, -16256, 0, 1, -1])
            n = rng.randint(0, 300)
            it_acc, it_ovf = acc, ovf
            for _ in range(n):
                it_acc, it_ovf = ref.accumulate_step(it_acc, it_ovf, False, True, p, acc_w, policy)
            self.assertEqual(ref.accumulate_constant(acc, ovf, p, n, acc_w, policy),
                             (it_acc, it_ovf), (acc, ovf, p, n, acc_w, policy))


class TestCycleModel(unittest.TestCase):
    def _run(self, cfg, cmds):
        m = ref.PeCycleModel(cfg)
        return [m.step(*c) for c in cmds]

    def test_latency_is_mul_stages_plus_two(self):
        for ms in (1, 2, 3, 4):
            cfg = ref.PeConfig(mul_stages=ms)
            cmds = [(0, 1, 0, 0, 0, 0)] + [(1, 1, 1, 1, 3, 4)] + [(1, 1, 0, 0, 0, 0)] * 8
            outs = self._run(cfg, cmds)
            # command presented in cycle 1 -> visible after edge 1 + (ms+1)
            first = next(k for k, o in enumerate(outs) if o.acc_valid)
            self.assertEqual(first - 1, ms + 1)
            self.assertEqual(outs[first].acc, 12)
            self.assertEqual(sum(o.acc_valid for o in outs), 1)

    def test_stall_freezes_everything(self):
        cfg = ref.PeConfig()
        m = ref.PeCycleModel(cfg)
        m.step(1, 1, 1, 1, 5, 5)
        before = m.outputs()
        for _ in range(10):
            # inputs during a stall are ignored, even clear/valid
            m.step(1, 0, 1, 1, -7, 9)
        self.assertEqual(m.outputs(), before)

    def test_reset_kills_in_flight_tokens(self):
        cfg = ref.PeConfig(mul_stages=2)
        outs = self._run(cfg, [(1, 1, 1, 1, 2, 2), (1, 1, 0, 1, 2, 2), (0, 1, 0, 0, 0, 0)]
                         + [(1, 1, 0, 0, 0, 0)] * 6)
        self.assertEqual(sum(o.acc_valid for o in outs), 0)
        self.assertEqual(outs[-1].acc, 0)

    def test_gating_holds_forward_data(self):
        m = ref.PeCycleModel(ref.PeConfig(operand_gating=True))
        m.step(1, 1, 0, 1, 11, -3)
        o = m.step(1, 1, 0, 0, 99, 99)
        self.assertEqual((o.valid_fwd, o.a_fwd, o.b_fwd), (0, 11, -3))
        m2 = ref.PeCycleModel(ref.PeConfig(operand_gating=False))
        m2.step(1, 1, 0, 1, 11, -3)
        o2 = m2.step(1, 1, 0, 0, 99, 98)
        self.assertEqual((o2.valid_fwd, o2.a_fwd, o2.b_fwd), (0, 99, 98))

    def test_fast_forward_equals_stepping(self):
        for policy in (ref.OVF_SATURATE, ref.OVF_WRAP):
            cfg = ref.PeConfig(acc_w=20, mul_stages=2, policy=policy)
            m1, m2 = ref.PeCycleModel(cfg), ref.PeCycleModel(cfg)
            for m in (m1, m2):
                m.step(1, 1, 1, 1, -128, -128)
                for _ in range(cfg.latency):
                    m.step(1, 1, 0, 1, -128, -128)
            for _ in range(100):
                m1.step(1, 1, 0, 1, -128, -128)
            m2.fast_forward(100, -128, -128)
            self.assertEqual(m1.outputs(), m2.outputs())


if __name__ == "__main__":
    unittest.main()
