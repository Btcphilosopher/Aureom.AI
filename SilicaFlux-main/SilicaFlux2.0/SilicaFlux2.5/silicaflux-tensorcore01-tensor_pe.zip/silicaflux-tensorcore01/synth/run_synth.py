#!/usr/bin/env python3
"""Synthesis smoke tests for tensor_pe (and the 4x4 mesh reference).

FPGA (open-source flows; vendor tools Vivado/Quartus are not available here):
  xc7    Yosys synth_xilinx -family xc7  (Artix-7 class: DSP48E1)
  ecp5   Yosys synth_ecp5 + nextpnr-ecp5 place & route, LFE5U-25F (MULT18X18D)
  ice40  Yosys synth_ice40 -dsp           (iCE40 UltraPlus: SB_MAC16)
ASIC:
  sky130 Yosys synth + dfflibmap + ABC mapped to sky130_fd_sc_hd tt_025C_1v80
         (logic synthesis only: no floorplan, placement, routing, or STA;
          the ABC delay is a wire-load-free logic-depth estimate)
Generic:
  Yosys `synth` (internal gate library), RTL inference report, and a
  structural longest-path comparison (Yosys `ltp -noff`) between one PE and
  the 4x4 mesh to show no combinational path crosses a PE boundary.

  python3 synth/run_synth.py [--liberty PATH] [--no-pnr]

Writes results/synth.json, results/synth_summary.md and per-run logs in
build/synth/.
"""

import argparse
import glob
import json
import os
import re
import shutil
import subprocess
import sys
import time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
PKG = os.path.join(ROOT, "rtl", "tensor_pe_pkg.sv")
PE = os.path.join(ROOT, "rtl", "tensor_pe.sv")
MESH = os.path.join(ROOT, "rtl", "tensor_pe_mesh.sv")
BUILD = os.path.join(ROOT, "build", "synth")

DEFAULT_LIB_CANDIDATES = [
    os.environ.get("SKY130_LIB", ""),
    os.path.join(ROOT, "third_party", "sky130_fd_sc_hd__tt_025C_1v80.lib"),
]

# Place-and-route target: the 100 MHz clock of the SilicaFlux repository's own
# constraints (synth/silicaflux.sdc, Arty A7 / DE10-Nano flows). The achieved
# Fmax is reported regardless of the target.
PNR_TARGET_MHZ = 100

PE_CONFIGS = [
    # name               ACC_W MS POL GATE
    ("a32_sat_m1_g1",    32, 1, 0, 1),   # baseline
    ("a32_sat_m1_g0",    32, 1, 0, 0),   # cost of operand gating
    ("a32_wrap_m1_g1",   32, 1, 1, 1),   # cost of saturation
    ("a32_sat_m2_g1",    32, 2, 0, 1),   # extra product register
    ("a40_sat_m1_g1",    40, 1, 0, 1),   # 40-bit accumulator
]


def run(cmd, log_path, timeout=3600, env=None, cwd=None):
    # Run in the log's directory so relative outputs (`tee -o`) stay there.
    cwd = cwd or os.path.dirname(log_path)
    t = time.time()
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                       timeout=timeout, env=env, cwd=cwd)
    with open(log_path, "w") as f:
        f.write(p.stdout)
    return p.returncode, p.stdout, round(time.time() - t, 1)


def read_cmd(top, params):
    files = f"{PKG} {PE}" + (f" {MESH}" if top == "tensor_pe_mesh" else "")
    chp = " ".join(f"-set {k} {v}" for k, v in params.items())
    return (f"read_verilog -sv -DSYNTHESIS {files}; chparam {chp} {top}; "
            f"hierarchy -check -top {top}; ")


def parse_stat(log, module=None):
    """Cell counts from the LAST `stat` block in a Yosys log."""
    blocks = log.split("Printing statistics.")
    if len(blocks) < 2:
        return {}
    blk = blocks[-1]
    if module:
        m = re.search(rf"=== {re.escape(module)} ===(.*?)(?:\n===|\Z)", blk, re.S)
        blk = m.group(1) if m else blk
    cells = {}
    for name, n in re.findall(r"^\s+(\S+)\s+(\d+)\s*$", blk, re.M):
        if not name.startswith("Number"):
            cells[name] = int(n)
    m = re.search(r"Number of cells:\s+(\d+)", blk)
    area = re.search(r"Chip area for (?:top )?module '[^']+':\s+([\d.]+)", blk)
    return {"cells_total": int(m.group(1)) if m else None, "cells": cells,
            "chip_area_um2": float(area.group(1)) if area else None}


def warnings_of(log):
    return sorted({l.strip() for l in log.splitlines() if l.startswith("Warning")})


# ---------------------------------------------------------------------------
def rtl_inference(name, params, d):
    script = read_cmd("tensor_pe", params) + (
        "proc; opt; wreduce; opt_clean; tee -o mul_cells.txt dump t:$mul; "
        "alumacc; opt; stat -width")
    rc, log, secs = run(["yosys", "-p", script], os.path.join(d, "rtl_inference.log"))
    mul = {}
    dump = log
    for key in ("A_SIGNED", "A_WIDTH", "B_SIGNED", "B_WIDTH", "Y_WIDTH"):
        m = re.search(rf"parameter \\{key} (\d+)", dump)
        mul[key] = int(m.group(1)) if m else None
    st = parse_stat(log)
    return {"rc": rc, "multiplier_cell": mul, "rtl_cells": st.get("cells"),
            "warnings": warnings_of(log)}


def generic(name, params, d, top="tensor_pe"):
    script = read_cmd(top, params) + f"synth -flatten -top {top}; tee -o stat.txt stat; ltp -noff"
    rc, log, secs = run(["yosys", "-p", script], os.path.join(d, f"generic_{top}.log"))
    st = parse_stat(log)
    m = re.search(r"Longest topological path in \S+ \(length=(\d+)\)", log)
    ffs = sum(v for k, v in st.get("cells", {}).items() if "DFF" in k.upper())
    return {"rc": rc, "seconds": secs, "cells_total": st.get("cells_total"),
            "flops": ffs, "ltp_length": int(m.group(1)) if m else None,
            "cells": st.get("cells"), "warnings": warnings_of(log)}


def xc7(name, params, d):
    script = read_cmd("tensor_pe", params) + (
        "synth_xilinx -family xc7 -top tensor_pe -flatten; tee -o stat.txt stat; "
        "tee -o dsp.txt dump t:DSP48E1")
    rc, log, secs = run(["yosys", "-p", script], os.path.join(d, "xc7.log"))
    st = parse_stat(log)
    dsp_params = {}
    for key in ("AREG", "BREG", "MREG", "PREG", "USE_MULT", "ACASCREG", "BCASCREG"):
        m = re.search(rf"parameter \\{key} (\S+)", log)
        if m:
            dsp_params[key] = m.group(1).strip('"')
    c = st.get("cells", {})
    luts = sum(v for k, v in c.items() if re.fullmatch(r"LUT\d", k))
    ffs = sum(v for k, v in c.items() if re.fullmatch(r"FD\w+", k))
    return {"rc": rc, "seconds": secs, "DSP48E1": c.get("DSP48E1", 0), "LUT": luts, "FF": ffs,
            "CARRY4": c.get("CARRY4", 0), "dsp_params": dsp_params, "cells": c,
            "warnings": warnings_of(log)}


def ecp5(name, params, d, pnr=True):
    js = os.path.join(d, "ecp5.json")
    script = read_cmd("tensor_pe", params) + (
        f"synth_ecp5 -top tensor_pe -json {js}; tee -o stat.txt stat")
    rc, log, secs = run(["yosys", "-p", script], os.path.join(d, "ecp5.log"))
    st = parse_stat(log)
    c = st.get("cells", {})
    res = {"rc": rc, "seconds": secs, "MULT18X18D": c.get("MULT18X18D", 0),
           "ALU54B": c.get("ALU54B", 0), "LUT4": c.get("LUT4", 0),
           "TRELLIS_FF": c.get("TRELLIS_FF", 0), "CCU2C": c.get("CCU2C", 0), "cells": c,
           "warnings": warnings_of(log)}
    if pnr and rc == 0:
        res["pnr"] = ecp5_pnr(js, d)
    return res


def find_nextpnr():
    exe = shutil.which("nextpnr-ecp5") or shutil.which("yowasp-nextpnr-ecp5")
    if exe:
        return [exe], None
    cand = glob.glob(os.path.join(ROOT, "..", "pytools", "bin", "yowasp-nextpnr-ecp5"))
    if cand:
        env = dict(os.environ, PYTHONPATH=os.path.abspath(os.path.join(ROOT, "..", "pytools")))
        return [os.path.abspath(cand[0])], env
    return None, None


def ecp5_pnr(js, d):
    exe, env = find_nextpnr()
    if not exe:
        return {"ran": False, "reason": "nextpnr-ecp5 not found"}
    # Relative paths, run from the output directory: the YoWASP (WebAssembly)
    # build of nextpnr only sees the current directory tree.
    rpt = os.path.join(d, "ecp5_pnr_report.json")
    cmd = exe + ["--25k", "--package", "CABGA381", "--json", os.path.basename(js),
                 "--freq", str(PNR_TARGET_MHZ), "--seed", "1", "--report", os.path.basename(rpt),
                 "--timing-allow-fail", "--textcfg", "ecp5.config"]
    rc, log, secs = run(cmd, os.path.join(d, "ecp5_pnr.log"), env=env, cwd=d)
    out = {"ran": True, "rc": rc, "seconds": secs, "tool": "nextpnr-ecp5",
           "device": "LFE5U-25F CABGA381 (nextpnr default speed grade)",
           "target_mhz": PNR_TARGET_MHZ}
    m = re.findall(r"Max frequency for clock\s+'([^']+)':\s+([\d.]+) MHz", log)
    if m:
        out["fmax_mhz"] = {k: float(v) for k, v in m[-1:]}
    try:
        rep = json.load(open(rpt))
        out["fmax_report"] = rep.get("fmax")
        out["utilization"] = {k: v for k, v in rep.get("utilization", {}).items()
                              if v.get("used", 0) > 0}
    except Exception as e:  # pragma: no cover
        out["report_error"] = str(e)
    ver = re.search(r"nextpnr-[\w.\-+]+", log)
    out["version"] = ver.group(0) if ver else None
    out["warnings"] = sorted({l.strip() for l in log.splitlines() if l.startswith("Warning")})[:20]
    crit = [l.strip() for l in log.splitlines() if "Critical path report for clock" in l]
    out["critical_path_header"] = crit[-1:] if crit else []
    return out


def ice40(name, params, d):
    script = read_cmd("tensor_pe", params) + "synth_ice40 -dsp -top tensor_pe; tee -o stat.txt stat"
    rc, log, secs = run(["yosys", "-p", script], os.path.join(d, "ice40.log"))
    st = parse_stat(log)
    c = st.get("cells", {})
    ffs = sum(v for k, v in c.items() if k.startswith("SB_DFF"))
    return {"rc": rc, "seconds": secs, "SB_MAC16": c.get("SB_MAC16", 0),
            "SB_LUT4": c.get("SB_LUT4", 0), "SB_CARRY": c.get("SB_CARRY", 0), "FF": ffs,
            "cells": c, "warnings": warnings_of(log)}


# Yosys' liberty/delay-target ABC recipe, followed by `stime -p` so ABC reports
# its (wire-load-free) delay estimate of the worst register-to-register /
# IO combinational path it mapped.
ABC_SCRIPT = ("+strash;&get,-n;&fraig,-x;&put;scorr;dc2;dretime;strash;&get,-n;&dch,-f;"
              "&nf,{D};&put;buffer;upsize,{D};dnsize,{D};stime,-p")


def sky130(name, params, d, lib, top="tensor_pe", delay_ps=5000):
    script = read_cmd(top, params) + (
        f"synth -flatten -top {top}; "
        f"dfflibmap -liberty {lib}; opt; "
        f"abc -D {delay_ps} -liberty {lib} -script {ABC_SCRIPT}; opt_clean; "
        f"setundef -zero; hilomap -singleton -hicell sky130_fd_sc_hd__conb_1 HI "
        f"-locell sky130_fd_sc_hd__conb_1 LO; opt_clean; "
        # cell views give `check` the pin directions of dfflibmap'd cells
        f"read_liberty -lib -ignore_miss_dir {lib}; check; "
        f"tee -o stat.txt stat -liberty {lib}; "
        f"write_verilog -noattr {os.path.join(d, top + '_sky130_netlist.v')}")
    rc, log, secs = run(["yosys", "-p", script], os.path.join(d, f"sky130_{top}.log"))
    st = parse_stat(log)
    c = st.get("cells", {})
    ffs = sum(v for k, v in c.items() if re.search(r"__(df|edf|sdf)\w*_\d", k))
    delays = re.findall(r"Delay\s*=\s*([\d.]+)\s*ps", log)
    return {"rc": rc, "seconds": secs, "chip_area_um2": st.get("chip_area_um2"),
            "cells_total": st.get("cells_total"), "flops": ffs,
            "abc_delay_target_ps": delay_ps,
            "abc_logic_delay_ps": float(delays[-1]) if delays else None,
            "cells": c, "warnings": warnings_of(log)}


def tool_versions():
    v = {"yosys": subprocess.run(["yosys", "-V"], stdout=subprocess.PIPE, text=True).stdout.strip()}
    exe, env = find_nextpnr()
    if exe:
        p = subprocess.run(exe + ["--version"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, env=env)
        v["nextpnr-ecp5"] = next((l for l in p.stdout.splitlines() if "nextpnr" in l), p.stdout.strip())
    return v


def _wcat(warns):
    """Group warnings by message shape (names/numbers elided)."""
    cats = {}
    for w in warns:
        k = re.sub(r"'[^']*'", "'*'", w)
        k = re.sub(r"\\\S+|\b\d+(\.\d+)?\b", "N", k)
        cats[k] = cats.get(k, 0) + 1
    return cats


def write_summary(out):
    pe = out["pe"]
    L = ["# Synthesis summary (generated by synth/run_synth.py)", ""]
    L += ["| Tool | Version |", "|---|---|"] + [f"| {k} | {v} |" for k, v in out["tools"].items()]
    L += [f"| sky130 liberty | `{os.path.relpath(out['liberty'], ROOT) if out['liberty'] else 'not found'}` |", ""]
    L += ["## Inferred multiplier (Yosys RTL level)", "",
          "| Config | $mul A | $mul B | Y | signed |", "|---|---|---|---|---|"]
    for n, r in pe.items():
        m = r["rtl_inference"]["multiplier_cell"]
        L.append(f"| {n} | {m['A_WIDTH']} | {m['B_WIDTH']} | {m['Y_WIDTH']} | "
                 f"{'yes' if m['A_SIGNED'] and m['B_SIGNED'] else 'NO'} |")
    L += ["", "## FPGA", "",
          "| Config | xc7 DSP48E1 | xc7 LUT | xc7 FF | xc7 CARRY4 | DSP regs absorbed | ECP5 MULT18X18D | ECP5 LUT4 | ECP5 FF | ECP5 CCU2C | ECP5 Fmax (post-route) | iCE40 SB_MAC16 | iCE40 LUT4 | iCE40 FF |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for n, r in pe.items():
        x, e, i = r["xc7"], r["ecp5"], r["ice40"]
        dp = x["dsp_params"]
        regs = ",".join(k for k in ("AREG", "BREG", "MREG", "PREG") if dp.get(k, "0") not in ("0", "1'0"))
        fm = e.get("pnr", {}).get("fmax_mhz") or {}
        fmax = f"{list(fm.values())[0]:.1f} MHz" if fm else "n/a"
        L.append(f"| {n} | {x['DSP48E1']} | {x['LUT']} | {x['FF']} | {x['CARRY4']} | {regs or '-'} | "
                 f"{e['MULT18X18D']} | {e['LUT4']} | {e['TRELLIS_FF']} | {e['CCU2C']} | {fmax} | "
                 f"{i['SB_MAC16']} | {i['SB_LUT4']} | {i['FF']} |")
    L += ["", "## ASIC (sky130_fd_sc_hd, tt 25C 1.80V; logic synthesis only)", "",
          "| Config | Cell area (um^2) | Std cells | Flops | ABC logic delay estimate | Generic gates | Longest path (cells) |",
          "|---|---|---|---|---|---|---|"]
    for n, r in pe.items():
        a, g = r.get("sky130", {}), r["generic"]
        L.append(f"| {n} | {a.get('chip_area_um2')} | {a.get('cells_total')} | {a.get('flops')} | "
                 f"{a.get('abc_logic_delay_ps')} ps | {g['cells_total']} | {g['ltp_length']} |")
    for n, m in out["mesh"].items():
        a = m.get("sky130", {})
        L += ["", f"## Mesh reference {n}", "",
              f"- Generic gates: {m['generic']['cells_total']}, flops: {m['generic']['flops']}",
              f"- Longest combinational path (Yosys `ltp -noff`, cells): mesh {m['generic']['ltp_length']} vs single PE {m['pe_generic_ltp']} -> "
              f"{'no combinational path crosses a PE boundary' if m['no_cross_pe_combinational_path'] else 'CROSS-PE PATH PRESENT'}",
              f"- sky130 cell area: {a.get('chip_area_um2')} um^2, std cells {a.get('cells_total')}, flops {a.get('flops')}"]
    L += ["", "## Warnings (grouped)", "", "| Flow | Count | Message pattern |", "|---|---|---|"]
    allw = {}
    for n, r in list(pe.items()) + [(k, v) for k, v in out["mesh"].items()]:
        for t, v in r.items():
            if isinstance(v, dict):
                for w in v.get("warnings", []):
                    allw.setdefault(t, []).append(w)
                for w in v.get("pnr", {}).get("warnings", []) if isinstance(v.get("pnr"), dict) else []:
                    allw.setdefault(t + "-pnr", []).append(w)
    if not allw:
        L.append("| - | 0 | none |")
    for t, ws in sorted(allw.items()):
        for k, c in sorted(_wcat(ws).items()):
            L.append(f"| {t} | {c} | `{k[:150]}` |")
    with open(os.path.join(ROOT, "results", "synth_summary.md"), "w") as f:
        f.write("\n".join(L) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--liberty", default=None)
    ap.add_argument("--no-pnr", action="store_true")
    args = ap.parse_args()
    lib = args.liberty or next((p for p in DEFAULT_LIB_CANDIDATES if p and os.path.exists(p)), None)
    os.makedirs(BUILD, exist_ok=True)
    out = {"tools": tool_versions(), "liberty": lib, "pe": {}, "mesh": {}}
    for name, acc_w, ms, pol, gate in PE_CONFIGS:
        params = {"ACC_W": acc_w, "MUL_STAGES": ms, "OVF_POLICY": pol, "OPERAND_GATING": gate}
        d = os.path.join(BUILD, name)
        os.makedirs(d, exist_ok=True)
        print(f"== {name}")
        r = {"params": params}
        r["rtl_inference"] = rtl_inference(name, params, d)
        r["generic"] = generic(name, params, d)
        r["xc7"] = xc7(name, params, d)
        r["ecp5"] = ecp5(name, params, d, pnr=not args.no_pnr)
        r["ice40"] = ice40(name, params, d)
        if lib:
            r["sky130"] = sky130(name, params, d, lib)
        out["pe"][name] = r
        print("   generic cells", r["generic"]["cells_total"], "| xc7 DSP", r["xc7"]["DSP48E1"],
              "LUT", r["xc7"]["LUT"], "FF", r["xc7"]["FF"], "| ecp5 MULT18", r["ecp5"]["MULT18X18D"],
              "fmax", r["ecp5"].get("pnr", {}).get("fmax_mhz"),
              "| sky130 area", r.get("sky130", {}).get("chip_area_um2"))

    # Mesh: structural path check + scaling
    d = os.path.join(BUILD, "mesh4x4_a32_sat_m1_g1")
    os.makedirs(d, exist_ok=True)
    mp = {"ROWS": 4, "COLS": 4, "ACC_W": 32, "MUL_STAGES": 1, "OVF_POLICY": 0, "OPERAND_GATING": 1}
    print("== mesh 4x4")
    m = {"params": mp, "generic": generic("mesh", mp, d, top="tensor_pe_mesh")}
    m["pe_generic_ltp"] = out["pe"]["a32_sat_m1_g1"]["generic"]["ltp_length"]
    m["no_cross_pe_combinational_path"] = (m["generic"]["ltp_length"] is not None and
                                           m["generic"]["ltp_length"] == m["pe_generic_ltp"])
    if lib:
        m["sky130"] = sky130("mesh", mp, d, lib, top="tensor_pe_mesh")
    out["mesh"]["mesh4x4_a32_sat_m1_g1"] = m
    print("   mesh ltp", m["generic"]["ltp_length"], "PE ltp", m["pe_generic_ltp"],
          "| sky130 area", m.get("sky130", {}).get("chip_area_um2"))

    os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)
    with open(os.path.join(ROOT, "results", "synth.json"), "w") as f:
        json.dump(out, f, indent=1)
    ok = all(all(v.get("rc", 0) == 0 for k, v in r.items() if isinstance(v, dict) and "rc" in v)
             for r in out["pe"].values())
    ok &= m["no_cross_pe_combinational_path"]
    write_summary(out)
    print("SYNTH:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
