#!/usr/bin/env python3
"""Full regression for the SilicaFlux TensorCore 01 tensor_pe.

  python3 scripts/run_regression.py            # everything
  python3 scripts/run_regression.py --no-long  # skip the 2^25-term runs
  python3 scripts/run_regression.py --only a32_sat_m1_g1

Stages
  1. Python reference-model self-tests (unittest)
  2. Lint: Verilator -Wall (RTL, every config + mesh), Icarus -Wall, Yosys
  3. PE simulation: config matrix x {Icarus, Verilator} x suites, each run
     checked by (a) per-cycle trace vs. Python cycle model, (b) the in-TB
     scoreboard, (c) TB monitors, (d) RTL assertions
  4. Mesh integration: tensor_pe_mesh vs. Python GEMM reference
  5. Negative configuration tests (elaboration checks) in all three tools
  6. K-limit check behaviour (severity off / warning / error)
  7. Mutation tests: seeded RTL bugs must be detected

Writes results/regression.json and results/regression_summary.md.
"""

from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "model"))
sys.path.insert(0, os.path.join(ROOT, "tb"))

import mesh_scenarios  # noqa: E402
import scenarios  # noqa: E402
import tensor_pe_ref as ref  # noqa: E402

PKG = os.path.join(ROOT, "rtl", "tensor_pe_pkg.sv")
PE = os.path.join(ROOT, "rtl", "tensor_pe.sv")
MESH = os.path.join(ROOT, "rtl", "tensor_pe_mesh.sv")
TB = os.path.join(ROOT, "tb", "tb_tensor_pe.sv")
TB_MESH = os.path.join(ROOT, "tb", "tb_tensor_pe_mesh.sv")
BUILD = os.path.join(ROOT, "build", "regression")
RESULTS = os.path.join(ROOT, "results")

# ---------------------------------------------------------------------------
# Configuration matrix
# ---------------------------------------------------------------------------
CONFIGS = [
    # name               a_w b_w acc_w ms policy gate   purpose
    ("a32_sat_m1_g1",      8, 8, 32, 1, 0, 1),   # baseline
    ("a32_wrap_m1_g1",     8, 8, 32, 1, 1, 1),
    ("a32_sat_m2_g0",      8, 8, 32, 2, 0, 0),
    ("a40_sat_m1_g1",      8, 8, 40, 1, 0, 1),   # 40-bit accumulator
    ("a40_wrap_m2_g1",     8, 8, 40, 2, 1, 1),
    ("a20_sat_m1_g1",      8, 8, 20, 1, 0, 1),   # overflow stress (MAX_EXACT_K = 31)
    ("a20_wrap_m3_g0",     8, 8, 20, 3, 1, 0),
    ("a16_sat_m4_g1",      8, 8, 16, 4, 0, 1),   # minimum width (MAX_EXACT_K = 1)
    ("i4_a12_wrap_m1_g1",  4, 4, 12, 1, 1, 1),   # parameter generality (INT4)
]

MESH_CONFIGS = [
    # name                rows cols acc_w ms policy gate tiles overflow_tiles
    ("mesh4x4_a32_sat_m1_g1", 4, 4, 32, 1, 0, 1, 40, False),
    ("mesh4x4_a20_wrap_m2_g0", 4, 4, 20, 2, 1, 0, 30, True),
    ("mesh3x5_a20_sat_m3_g1", 3, 5, 20, 3, 0, 1, 30, True),
]


def cfg_of(c) -> ref.PeConfig:
    _, a_w, b_w, acc_w, ms, pol, gate = c
    return ref.PeConfig(a_w=a_w, b_w=b_w, acc_w=acc_w, mul_stages=ms, policy=pol,
                        operand_gating=bool(gate))


def params_of(c, extra=None):
    _, a_w, b_w, acc_w, ms, pol, gate = c
    p = {"A_W": a_w, "B_W": b_w, "ACC_W": acc_w, "MUL_STAGES": ms, "OVF_POLICY": pol,
         "OPERAND_GATING": gate}
    p.update(extra or {})
    return p


def sh(cmd, cwd=None, timeout=7200):
    t = time.time()
    p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       text=True, timeout=timeout)
    return p.returncode, p.stdout, time.time() - t


def tool_versions():
    v = {}
    for name, cmd in [("icarus", ["iverilog", "-V"]), ("verilator", ["verilator", "--version"]),
                      ("yosys", ["yosys", "-V"])]:
        try:
            v[name] = sh(cmd)[1].strip().splitlines()[0]
        except Exception as e:  # pragma: no cover
            v[name] = f"unavailable ({e})"
    v["python"] = sys.version.split()[0]
    v["host"] = platform.platform()
    return v


# ---------------------------------------------------------------------------
# Builders
# ---------------------------------------------------------------------------
def vparam(k, v):
    """Sized literal for Verilator -G (avoids WIDTH warnings on bit/64-bit params)."""
    if k == "OPERAND_GATING":
        return f"1'b{int(v)}"
    if k == "MAX_K":
        return f"64'd{int(v)}"
    return str(v)


def build_icarus(top, files, params, out, defines=()):
    cmd = ["iverilog", "-g2012", "-o", out]
    cmd += [f"-D{d}" for d in defines]
    cmd += [f"-P{top}.{k}={v}" for k, v in params.items()]
    cmd += files
    return sh(cmd)


def build_verilator(top, files, params, mdir, defines=()):
    cmd = ["verilator", "--binary", "--timing", "--assert", "-O3", "-j", "2",
           "-Wno-fatal", "-Wno-lint", "-Wno-style", "--Mdir", mdir, "--top-module", top]
    cmd += [f"-D{d}" for d in defines]
    cmd += [f"-G{k}={vparam(k, v)}" for k, v in params.items()]
    cmd += files
    return sh(cmd)


def run_sim(sim, exe, plusargs, cwd):
    cmd = (["vvp", "-n", exe] if sim == "icarus" else [exe]) + plusargs
    return sh(cmd, cwd=cwd)


SUMMARY_RE = re.compile(r"(\w+)=(-?\d+)")


def parse_pe_log(log):
    info = {"result": None, "summary": {}, "assert_fail": [], "k_limit_msgs": 0}
    for line in log.splitlines():
        if line.startswith("TPE_RESULT:"):
            info["result"] = line.split(":", 1)[1].strip()
        elif line.startswith("TPE_SUMMARY"):
            info["summary"] = {k: int(v) for k, v in SUMMARY_RE.findall(line)}
        if "violated" in line and len(info["assert_fail"]) < 10:
            info["assert_fail"].append(line.strip())
        if "a_k_limit" in line:
            info["k_limit_msgs"] += 1
    return info


def compare_trace(trace_path, expected):
    bad, msgs, n = 0, [], 0
    with open(trace_path) as f:
        for n, (line, exp) in enumerate(zip(f, expected), 1):
            got = line.split()
            for i, (g, e) in enumerate(zip(got, exp)):
                if e == "x":
                    continue
                if g != e:
                    bad += 1
                    if len(msgs) < 8:
                        msgs.append(f"line {n} field {i}: got {' '.join(got)} | expected {' '.join(exp)}")
                    break
    if n != len(expected):
        bad += 1
        msgs.append(f"trace has {n} lines, expected {len(expected)}")
    return bad, msgs


# ---------------------------------------------------------------------------
# Stage 3: PE simulation
# ---------------------------------------------------------------------------
STIM_CACHE = {}


def get_stim(c, suite):
    key = (c[0], suite)
    if key not in STIM_CACHE:
        recs = scenarios.build(cfg_of(c), suite)
        d = os.path.join(BUILD, c[0])
        os.makedirs(d, exist_ok=True)
        path = os.path.join(d, f"stim_{suite}.txt")
        scenarios.write_stim(recs, path)
        STIM_CACHE[key] = (recs, path)
    return STIM_CACHE[key]


def pe_job(c, sim, suites, rtl_files=None, workdir=None, extra_params=None, tag=""):
    name = c[0]
    cfg = cfg_of(c)
    d = workdir or os.path.join(BUILD, name, sim + tag)
    os.makedirs(d, exist_ok=True)
    files = (rtl_files or [PKG, PE]) + [TB]
    params = params_of(c, extra_params)
    t0 = time.time()
    if sim == "icarus":
        exe = os.path.join(d, "tb.vvp")
        rc, out, _ = build_icarus("tb_tensor_pe", files, params, exe)
    else:
        mdir = os.path.join(d, "obj")
        rc, out, _ = build_verilator("tb_tensor_pe", files, params, mdir)
        exe = os.path.join(mdir, "Vtb_tensor_pe")
    res = {"config": name, "sim": sim, "build_rc": rc, "build_s": round(time.time() - t0, 1),
           "suites": {}}
    if rc != 0:
        res["build_log"] = out[-3000:]
        res["pass"] = False
        return res
    ok = True
    for suite in suites:
        recs, stim = get_stim(c, suite)
        trace = os.path.join(d, f"trace_{suite}.txt")
        rc, log, secs = run_sim(sim, exe, [f"+STIM={stim}", f"+TRACE={trace}"], d)
        with open(os.path.join(d, f"sim_{suite}.log"), "w") as f:
            f.write(log)
        info = parse_pe_log(log)
        exp = scenarios.expected_trace(cfg, recs, sim)
        bad, msgs = compare_trace(trace, exp)
        st = info["summary"]
        checks = {
            "tb_pass": info["result"] == "PASS",
            "trace_match": bad == 0,
            "no_assertion_failures": not info["assert_fail"],
            # every accepted command produced exactly one token, unless a
            # reset flushed it while in flight
            "all_tokens_accounted": st.get("in_flight", -1) == 0
                                    and st.get("tokens", -1) + st.get("killed_by_reset", -1)
                                    == st.get("accepted", -2),
            "cycles_match_stimulus": st.get("cycles", -1) == scenarios.stats(recs)["cycles"],
        }
        if cfg.operand_gating:
            checks["no_idle_switching"] = (st.get("s0_idle_switch", -1) == 0
                                           and st.get("p_idle_switch", -1) == 0)
        passed = all(checks.values())
        ok &= passed
        res["suites"][suite] = {
            "pass": passed, "checks": checks, "sim_s": round(secs, 1),
            "cycles": st.get("cycles"), "tokens": st.get("tokens"),
            "traced_lines": len(exp), "trace_mismatches": bad, "trace_msgs": msgs,
            "traced_tokens": sum(1 for e in exp if e[2] == "1"),
            "traced_overflow_tokens": sum(1 for e in exp if e[2] == "1" and e[4] == "1"),
            "traced_x_fields_skipped": sum(1 for e in exp for f in e[7:] if f == "x"),
            "assert_fail": info["assert_fail"], "k_limit_msgs": info["k_limit_msgs"],
            "summary": st, "sim_rc": rc,
            "scenarios": sorted({scenarios.SCENARIO_NAMES[r[1]] for r in recs if r[1]}),
        }
        if os.path.getsize(trace) > 0 and suite != "quick":
            os.remove(trace)          # traces are large; logs are kept
    res["pass"] = ok
    return res


# ---------------------------------------------------------------------------
# Stage 4: mesh
# ---------------------------------------------------------------------------
def mesh_job(mc, sim):
    name, rows, cols, acc_w, ms, pol, gate, tiles, ovf_tiles = mc
    cfg = ref.PeConfig(acc_w=acc_w, mul_stages=ms, policy=pol, operand_gating=bool(gate))
    d = os.path.join(BUILD, name, sim)
    os.makedirs(d, exist_ok=True)
    lines, expected, tl, stream = mesh_scenarios.build(cfg, rows, cols, tiles, seed=17,
                                                       overflow_tiles=ovf_tiles)
    stim = os.path.join(d, "mesh_stim.txt")
    mesh_scenarios.write_stim(lines, stim)
    params = {"ROWS": rows, "COLS": cols, "ACC_W": acc_w, "MUL_STAGES": ms,
              "OVF_POLICY": pol, "OPERAND_GATING": gate}
    files = [PKG, PE, MESH, TB_MESH]
    if sim == "icarus":
        exe = os.path.join(d, "tb.vvp")
        rc, out, _ = build_icarus("tb_tensor_pe_mesh", files, params, exe)
    else:
        rc, out, _ = build_verilator("tb_tensor_pe_mesh", files, params, os.path.join(d, "obj"))
        exe = os.path.join(d, "obj", "Vtb_tensor_pe_mesh")
    if rc != 0:
        return {"config": name, "sim": sim, "pass": False, "build_log": out[-3000:]}
    toks = os.path.join(d, "tokens.txt")
    rc, log, secs = run_sim(sim, exe, [f"+STIM={stim}", f"+TOKENS={toks}"], d)
    with open(os.path.join(d, "sim.log"), "w") as f:
        f.write(log)
    errs, msgs, st = mesh_scenarios.compare(toks, expected, rows, cols)
    align_fail = [l for l in log.splitlines() if "violated" in l][:5]
    stalls = sum(1 for l in lines if l[0] and not l[1])
    passed = errs == 0 and not align_fail and "MESH_RESULT: DONE" in log
    return {"config": name, "sim": sim, "pass": passed, "token_errors": errs, "msgs": msgs,
            "alignment_failures": align_fail, "cycles": len(lines), "stall_cycles": stalls,
            "tiles": len(tl), "k_values": [t[0] for t in tl], "stream_len": len(stream),
            "sim_s": round(secs, 1), **st}


# ---------------------------------------------------------------------------
# Stage 5: negative configuration tests
# ---------------------------------------------------------------------------
NEGATIVE = [
    # (label, params, expected substring per tool)
    ("ACC_W below A_W+B_W", {"ACC_W": 15}, "acc_width"),
    ("ACC_W above 64", {"ACC_W": 65}, "acc_width"),
    ("MAX_K above exact bound (ACC_W=32, MAX_K=131072)", {"ACC_W": 32, "MAX_K": 131072}, "max_k"),
    ("MAX_K above exact bound (ACC_W=40, MAX_K=2^25)", {"ACC_W": 40, "MAX_K": 1 << 25}, "max_k"),
    ("MAX_K zero", {"MAX_K": 0}, "max_k"),
    ("MUL_STAGES = 0", {"MUL_STAGES": 0}, "mul_stages"),
    ("OVF_POLICY = 2", {"OVF_POLICY": 2}, "overflow_policy"),
    ("A_W = 1", {"A_W": 1, "ACC_W": 32}, "operand_width"),
]
POSITIVE = [
    ("MAX_K at exact bound (ACC_W=32, MAX_K=131071)", {"ACC_W": 32, "MAX_K": 131071}),
    ("MAX_K below bound (ACC_W=32, MAX_K=4096)", {"ACC_W": 32, "MAX_K": 4096}),
    ("MAX_K at exact bound (ACC_W=40, MAX_K=2^25-1)", {"ACC_W": 40, "MAX_K": (1 << 25) - 1}),
]
MSG = {  # message fragments emitted by each tool for each check
    "acc_width": ("acc_width_out_of_range", "must be in [A_W+B_W, 64]"),
    "max_k": ("max_k_exceeds_exact_bound", "unsupported accumulation range"),
    "mul_stages": ("mul_stages_out_of_range", "MUL_STAGES"),
    "overflow_policy": ("unknown_overflow_policy", "OVF_POLICY"),
    "operand_width": ("operand_width_out_of_range", "A_W/B_W"),
}


def elaborate(tool, params, d):
    os.makedirs(d, exist_ok=True)
    if tool == "icarus":
        return build_icarus("tensor_pe", [PKG, PE], params, os.path.join(d, "x.vvp"))
    if tool in ("verilator", "verilator-Wno-fatal"):
        # -Wno-fatal is the case that bypasses a plain $error in Verilator 5.020
        flag = "-Wall" if tool == "verilator" else "-Wno-fatal"
        cmd = ["verilator", "--lint-only", flag, "--top-module", "tensor_pe"]
        cmd += [f"-G{k}={vparam(k, v)}" for k, v in params.items()] + [PKG, PE]
        return sh(cmd)
    chp = " ".join(f"-set {k} {v}" for k, v in params.items())
    script = (f"read_verilog -sv -DSYNTHESIS {PKG} {PE}; "
              + (f"chparam {chp} tensor_pe; " if params else "")
              + "hierarchy -check -top tensor_pe")
    return sh(["yosys", "-q", "-p", script])


def negative_tests():
    out = []
    for label, params, key in NEGATIVE:
        row = {"case": label, "params": params, "expect": "reject", "tools": {}}
        for tool in ("icarus", "verilator", "verilator-Wno-fatal", "yosys"):
            rc, log, _ = elaborate(tool, params, os.path.join(BUILD, "negative"))
            frag_icarus, frag_msg = MSG[key]
            frag = frag_icarus if tool == "icarus" else frag_msg
            row["tools"][tool] = {"rejected": rc != 0, "message_ok": frag in log,
                                  "pass": rc != 0 and frag in log,
                                  "excerpt": next((l.strip() for l in log.splitlines()
                                                   if frag in l), log.strip()[-200:])}
        row["pass"] = all(t["pass"] for t in row["tools"].values())
        out.append(row)
    for label, params in POSITIVE:
        row = {"case": label, "params": params, "expect": "accept", "tools": {}}
        for tool in ("icarus", "verilator", "verilator-Wno-fatal", "yosys"):
            rc, log, _ = elaborate(tool, params, os.path.join(BUILD, "negative"))
            row["tools"][tool] = {"pass": rc == 0, "excerpt": log.strip()[-200:] if rc else ""}
        row["pass"] = all(t["pass"] for t in row["tools"].values())
        out.append(row)
    return out


# ---------------------------------------------------------------------------
# Stage 6: K-limit severity
# ---------------------------------------------------------------------------
def k_limit_tests():
    c = ("kchk_a20", 8, 8, 20, 1, 0, 1)
    out = []
    for sev, max_k, expect in [(0, None, "silent"), (1, None, "warning"), (2, None, "error"),
                               (1, 8, "warning at 9th term (MAX_K=8 < exact bound 31)")]:
        extra = {"K_LIMIT_SEVERITY": sev}
        if max_k is not None:
            extra["MAX_K"] = max_k
        for sim in ("icarus", "verilator"):
            tag = f"_kchk_s{sev}_{max_k}"
            d = os.path.join(BUILD, "kcheck", sim + tag)
            r = pe_job(c, sim, ["kcheck"], workdir=d, extra_params=extra)
            s = r["suites"].get("kcheck", {})
            log = open(os.path.join(d, "sim_kcheck.log")).read() if os.path.exists(
                os.path.join(d, "sim_kcheck.log")) else ""
            n = s.get("k_limit_msgs", 0)
            if sev == 0:
                ok = n == 0 and s.get("pass", False)
            elif sev == 1:
                ok = (n == 1 and ("Warning" in log or "WARNING" in log)
                      and s.get("pass", False))
            else:
                ok = n >= 1 and ("Error" in log or "ERROR" in log)
            out.append({"severity": sev, "max_k": max_k, "sim": sim, "expect": expect,
                        "k_limit_msgs": n, "pass": bool(ok),
                        "excerpt": next((l.strip() for l in log.splitlines() if "a_k_limit" in l), "")})
    return out


# ---------------------------------------------------------------------------
# Stage 7: mutation tests
# ---------------------------------------------------------------------------
MUTANTS = [
    ("operand A zero-extended (unsigned multiply)",
     "{{(PROD_W-A_W){s0_a_q[A_W-1]}}, s0_a_q}", "{{(PROD_W-A_W){1'b0}}, s0_a_q}"),
    ("product treated as 15-bit signed (breaks -128*-128)",
     "{{(ACC_W+1-PROD_W){acc_in_p[PROD_W-1]}}, acc_in_p}",
     "{{(ACC_W+2-PROD_W){acc_in_p[PROD_W-2]}}, acc_in_p[PROD_W-2:0]}"),
    ("clear ignored when valid in same cycle",
     "assign acc_base = acc_in_clear ? '0   : acc_q;",
     "assign acc_base = (acc_in_clear & ~acc_in_valid) ? '0 : acc_q;"),
    ("clear token dropped in product pipeline",
     "pm_clear_q[0] <= s0_clear_q;", "pm_clear_q[0] <= 1'b0;"),
    ("overflow detection removed",
     "assign add_ovf = add_sum[ACC_W] ^ add_sum[ACC_W-1];", "assign add_ovf = 1'b0;"),
    ("overflow flag not sticky",
     "assign ovf_d  = ovf_base | add_ovf;", "assign ovf_d  = add_ovf;"),
    ("saturation uses wrapped sign",
     "(add_sum[ACC_W] ? ACC_MIN : ACC_MAX)", "(add_sum[ACC_W-1] ? ACC_MIN : ACC_MAX)"),
    ("accumulator ignores stall",
     "    end else if (enable_i) begin\n      acc_vld_q <= acc_token;",
     "    end else begin\n      acc_vld_q <= acc_token;"),
    ("operand gating disabled (power regression only)",
     "assign s0_load = enable_i & (operand_valid_i | ~OPERAND_GATING);",
     "assign s0_load = enable_i;"),
    ("forward valid bypasses the capture register",
     "assign valid_fwd_o  = s0_valid_q;", "assign valid_fwd_o  = operand_valid_i;"),
    ("accumulator not reset",
     "      acc_q     <= '0;", "      acc_q     <= acc_q;"),
    ("clear-only command produces no token",
     "assign acc_token    = acc_in_valid | acc_in_clear;", "assign acc_token    = acc_in_valid;"),
    ("product stage enable uses wrong token (MUL_STAGES>=2)",
     "if (enable_i & (pm_valid_q[m-1] | ~OPERAND_GATING)) begin",
     "if (enable_i & (pm_valid_q[m] | ~OPERAND_GATING)) begin"),
    ("enable ignored by S0 control (stall leaks inputs)",
     "    end else if (enable_i) begin\n      s0_valid_q <= operand_valid_i;",
     "    end else begin\n      s0_valid_q <= operand_valid_i;"),
]
MUTANT_CONFIGS = [
    ("a32_sat_m1_g1", 8, 8, 32, 1, 0, 1),
    ("a20_sat_m2_g1", 8, 8, 20, 2, 0, 1),
    ("a20_wrap_m1_g0", 8, 8, 20, 1, 1, 0),
]


def mutant_job(idx, mut):
    label, old, new = mut
    src = open(PE).read()
    if src.count(old) != 1:
        return {"mutant": label, "error": f"pattern found {src.count(old)} times", "killed": False}
    d = os.path.join(BUILD, "mutants", f"m{idx:02d}")
    os.makedirs(d, exist_ok=True)
    mpe = os.path.join(d, "tensor_pe.sv")
    with open(mpe, "w") as f:
        f.write(src.replace(old, new))
    killers = []
    for c in MUTANT_CONFIGS:
        r = pe_job(c, "icarus", ["quick"], rtl_files=[PKG, mpe],
                   workdir=os.path.join(d, c[0]))
        if not r["pass"]:
            s = r["suites"].get("quick", {})
            why = [k for k, v in s.get("checks", {}).items() if not v] or ["build"]
            killers.append({"config": c[0], "failed_checks": why})
    return {"mutant": label, "killed": bool(killers), "killed_by": killers}


# ---------------------------------------------------------------------------
# Stage 2: lint
# ---------------------------------------------------------------------------
def lint():
    out = []
    for c in CONFIGS:
        p = params_of(c)
        cmd = ["verilator", "--lint-only", "-Wall", "--assert", "--top-module", "tensor_pe"]
        cmd += [f"-G{k}={vparam(k, v)}" for k, v in p.items()] + [PKG, PE]
        rc, log, _ = sh(cmd)
        out.append({"tool": "verilator -Wall", "target": f"tensor_pe {c[0]}", "pass": rc == 0,
                    "warnings": log.count("%Warning"), "log": log.strip()[-500:]})
    for mc in MESH_CONFIGS:
        cmd = ["verilator", "--lint-only", "-Wall", "--assert", "--top-module", "tensor_pe_mesh",
               f"-GROWS={mc[1]}", f"-GCOLS={mc[2]}", f"-GACC_W={mc[3]}", f"-GMUL_STAGES={mc[4]}",
               f"-GOVF_POLICY={mc[5]}", f"-GOPERAND_GATING={vparam('OPERAND_GATING', mc[6])}", PKG, PE, MESH]
        rc, log, _ = sh(cmd)
        out.append({"tool": "verilator -Wall", "target": f"tensor_pe_mesh {mc[0]}", "pass": rc == 0,
                    "warnings": log.count("%Warning"), "log": log.strip()[-500:]})
    rc, log, _ = sh(["iverilog", "-g2012", "-Wall", "-o", "/dev/null", PKG, PE, MESH])
    out.append({"tool": "iverilog -Wall", "target": "pkg + tensor_pe + tensor_pe_mesh",
                "pass": rc == 0 and "warning" not in log.lower(),
                "warnings": log.lower().count("warning"), "log": log.strip()[-500:]})
    rc, log, _ = sh(["yosys", "-p", f"read_verilog -sv -DSYNTHESIS {PKG} {PE} {MESH}; "
                                    "hierarchy -check -top tensor_pe_mesh; proc; check -assert"])
    warn = [l for l in log.splitlines() if l.startswith("Warning")]
    out.append({"tool": "yosys check -assert", "target": "tensor_pe_mesh (4x4 default)",
                "pass": rc == 0, "warnings": len(warn), "log": "\n".join(warn)[-500:]})
    return out


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-long", action="store_true", help="skip 2^25-term ACC_W=40 runs")
    ap.add_argument("--no-mutants", action="store_true")
    ap.add_argument("--only", help="run only this PE config (stage 3)")
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    args = ap.parse_args()

    os.makedirs(BUILD, exist_ok=True)
    os.makedirs(RESULTS, exist_ok=True)
    t_all = time.time()
    report = {"tools": tool_versions(), "started": time.strftime("%Y-%m-%d %H:%M:%S")}

    print("[1/7] reference model self-tests")
    rc, log, _ = sh([sys.executable, "-m", "unittest", "discover", "-s",
                     os.path.join(ROOT, "tests"), "-v"])
    m = re.search(r"Ran (\d+) tests", log)
    report["model_selftest"] = {"pass": rc == 0, "tests": int(m.group(1)) if m else 0,
                                "log_tail": log.strip()[-400:]}

    print("[2/7] lint")
    report["lint"] = lint()

    print("[3/7] PE simulation")
    configs = [c for c in CONFIGS if not args.only or c[0] == args.only]
    jobs = []
    for c in configs:
        jobs.append((c, "icarus", ["normal", "xinj"]))
        suites = ["normal"] + (["long"] if c[3] > 32 and not args.no_long else [])
        jobs.append((c, "verilator", suites))
    for c in configs:              # pre-generate stimulus (single-threaded, cached)
        for _, _, suites in [j for j in jobs if j[0] is c]:
            for s in suites:
                get_stim(c, s)
    with cf.ThreadPoolExecutor(args.jobs) as ex:
        futs = [ex.submit(pe_job, *j) for j in jobs]
        report["pe_sim"] = []
        for f in cf.as_completed(futs):
            r = f.result()
            report["pe_sim"].append(r)
            print(f"   {r['config']:<20} {r['sim']:<9} {'PASS' if r['pass'] else 'FAIL'} "
                  + " ".join(f"{s}:{v['cycles']}cyc/{v['sim_s']}s" for s, v in r["suites"].items()))
    report["pe_sim"].sort(key=lambda r: (r["config"], r["sim"]))

    print("[4/7] mesh integration")
    with cf.ThreadPoolExecutor(args.jobs) as ex:
        report["mesh"] = list(ex.map(lambda a: mesh_job(*a),
                                     [(mc, s) for mc in MESH_CONFIGS for s in ("icarus", "verilator")]))
    for r in report["mesh"]:
        print(f"   {r['config']:<24} {r['sim']:<9} {'PASS' if r['pass'] else 'FAIL'}")

    print("[5/7] negative configuration tests")
    report["config_checks"] = negative_tests()

    print("[6/7] K-limit check")
    report["k_limit"] = k_limit_tests()

    if not args.no_mutants:
        print("[7/7] mutation tests")
        with cf.ThreadPoolExecutor(args.jobs) as ex:
            report["mutants"] = list(ex.map(lambda a: mutant_job(*a), enumerate(MUTANTS)))
        for r in report["mutants"]:
            print(f"   {'KILLED ' if r['killed'] else 'SURVIVED'} {r['mutant']}")

    sections = {
        "model_selftest": report["model_selftest"]["pass"],
        "lint": all(x["pass"] for x in report["lint"]),
        "pe_sim": all(x["pass"] for x in report["pe_sim"]),
        "mesh": all(x["pass"] for x in report["mesh"]),
        "config_checks": all(x["pass"] for x in report["config_checks"]),
        "k_limit": all(x["pass"] for x in report["k_limit"]),
    }
    if "mutants" in report:
        sections["mutants_all_killed"] = all(x["killed"] for x in report["mutants"])
    report["sections"] = sections
    report["overall_pass"] = all(sections.values())
    report["elapsed_s"] = round(time.time() - t_all, 1)
    with open(os.path.join(RESULTS, "regression.json"), "w") as f:
        json.dump(report, f, indent=1)
    write_markdown(report)
    print(json.dumps(sections, indent=1))
    print("OVERALL:", "PASS" if report["overall_pass"] else "FAIL", f"({report['elapsed_s']} s)")
    return 0 if report["overall_pass"] else 1


def write_markdown(r):
    L = ["# tensor_pe regression summary", "",
         f"Generated by `scripts/run_regression.py` on {r['started']} ({r['elapsed_s']} s).", "",
         "| Tool | Version |", "|---|---|"]
    L += [f"| {k} | {v} |" for k, v in r["tools"].items()]
    L += ["", "## Sections", "", "| Section | Result |", "|---|---|"]
    L += [f"| {k} | {'PASS' if v else 'FAIL'} |" for k, v in r["sections"].items()]
    L += ["", f"**Overall: {'PASS' if r['overall_pass'] else 'FAIL'}**", ""]
    L += ["## Reference model self-tests", "",
          f"{r['model_selftest']['tests']} tests, {'PASS' if r['model_selftest']['pass'] else 'FAIL'}", ""]
    L += ["## Lint", "", "| Tool | Target | Result | Warnings |", "|---|---|---|---|"]
    L += [f"| {x['tool']} | {x['target']} | {'PASS' if x['pass'] else 'FAIL'} | {x['warnings']} |"
          for x in r["lint"]]
    L += ["", "## PE simulation", "",
          "| Config | Simulator | Suite | Cycles | Tokens (scoreboard) | Traced cycles | Overflow tokens traced | "
          "Trace mismatches | K-limit msgs | Idle switch S0/P | Sim time | Result |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for x in r["pe_sim"]:
        for s, v in x["suites"].items():
            st = v["summary"]
            L.append(f"| {x['config']} | {x['sim']} | {s} | {v['cycles']} | {v['tokens']} | "
                     f"{v['traced_lines']} | {v['traced_overflow_tokens']} | {v['trace_mismatches']} | {v['k_limit_msgs']} | "
                     f"{st.get('s0_idle_switch')}/{st.get('p_idle_switch')} | {v['sim_s']} s | "
                     f"{'PASS' if v['pass'] else 'FAIL'} |")
        if not x["suites"]:
            L.append(f"| {x['config']} | {x['sim']} | build | - | - | - | - | - | - | - | - | FAIL |")
    L += ["", "## Mesh integration", "",
          "| Config | Simulator | Cycles | Stall cycles | Tiles | Tokens | Overflow tokens | "
          "Token errors | Alignment failures | Result |", "|---|---|---|---|---|---|---|---|---|---|"]
    for x in r["mesh"]:
        L.append(f"| {x['config']} | {x['sim']} | {x.get('cycles')} | {x.get('stall_cycles')} | "
                 f"{x.get('tiles')} | {x.get('expected_tokens')} | {x.get('expected_overflow_tokens')} | "
                 f"{x.get('token_errors')} | {len(x.get('alignment_failures', []))} | "
                 f"{'PASS' if x['pass'] else 'FAIL'} |")
    L += ["", "## Elaboration-time configuration checks", "",
          "| Case | Expect | Icarus | Verilator -Wall | Verilator -Wno-fatal | Yosys |", "|---|---|---|---|---|---|"]
    for x in r["config_checks"]:
        t = x["tools"]
        L.append(f"| {x['case']} | {x['expect']} | "
                 + " | ".join('PASS' if t[k]['pass'] else 'FAIL'
                              for k in ('icarus', 'verilator', 'verilator-Wno-fatal', 'yosys'))
                 + " |")
    L += ["", "## K-limit check", "", "| Severity | MAX_K | Simulator | Expect | Messages | Result |",
          "|---|---|---|---|---|---|"]
    for x in r["k_limit"]:
        L.append(f"| {x['severity']} | {x['max_k'] or 'default'} | {x['sim']} | {x['expect']} | "
                 f"{x['k_limit_msgs']} | {'PASS' if x['pass'] else 'FAIL'} |")
    if "mutants" in r:
        L += ["", "## Mutation tests", "", "| Mutant | Killed | Detected by |", "|---|---|---|"]
        for x in r["mutants"]:
            by = "; ".join(f"{k['config']}: {', '.join(k['failed_checks'])}" for k in x.get("killed_by", []))
            L.append(f"| {x['mutant']} | {'yes' if x['killed'] else 'NO'} | {by or x.get('error', '')} |")
    with open(os.path.join(RESULTS, "regression_summary.md"), "w") as f:
        f.write("\n".join(L) + "\n")


if __name__ == "__main__":
    sys.exit(main())
