#!/usr/bin/env python3
"""Structural coverage of rtl/tensor_pe.sv (Verilator line + toggle coverage).

Runs the `normal` suite of selected configurations with Verilator
--coverage-line --coverage-toggle, merges the data, and reports per-file line
and toggle coverage of the PE (testbench excluded). Uncovered points are
listed so they can be justified.

Writes results/coverage_summary.md and build/coverage/annotated/.
"""

import os
import re
import subprocess
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
sys.path.insert(0, os.path.join(ROOT, "model"))
sys.path.insert(0, os.path.join(ROOT, "tb"))

import run_regression as rr  # noqa: E402
import scenarios  # noqa: E402

BUILD = os.path.join(ROOT, "build", "coverage")
CONFIGS = [c for c in rr.CONFIGS if c[0] in ("a32_sat_m1_g1", "a32_wrap_m1_g1", "a32_sat_m2_g0",
                                              "a20_wrap_m3_g0", "a16_sat_m4_g1")]


def main():
    os.makedirs(BUILD, exist_ok=True)
    dats = []
    for c in CONFIGS:
        d = os.path.join(BUILD, c[0])
        os.makedirs(d, exist_ok=True)
        cmd = ["verilator", "--cc", "--exe", "--build", "--timing", "--assert",
               "--coverage-line", "--coverage-toggle",
               "-Wno-fatal", "-Wno-lint", "-Wno-style", "-j", "2", "--Mdir", os.path.join(d, "obj"),
               "--top-module", "tb_tensor_pe"]
        cmd += [f"-G{k}={rr.vparam(k, v)}" for k, v in rr.params_of(c).items()]
        cmd += [rr.PKG, rr.PE, rr.TB, os.path.join(ROOT, "tb", "verilator_cov_main.cpp")]
        rc, out, _ = rr.sh(cmd)
        if rc:
            print(out[-2000:])
            return 1
        recs = scenarios.build(rr.cfg_of(c), "normal")
        stim = os.path.join(d, "stim.txt")
        scenarios.write_stim(recs, stim)
        rc, log, _ = rr.sh([os.path.join(d, "obj", "Vtb_tensor_pe"), f"+STIM={stim}",
                            f"+TRACE={os.path.join(d, 'trace.txt')}"], cwd=d)
        assert "TPE_RESULT: PASS" in log, c[0]
        dats.append(os.path.join(d, "coverage.dat"))   # written by tb/verilator_cov_main.cpp
        print("ran", c[0])
    merged = os.path.join(BUILD, "merged.dat")
    rr.sh(["verilator_coverage", "--write", merged] + dats)
    ann = os.path.join(BUILD, "annotated")
    rc, rep, _ = rr.sh(["verilator_coverage", "--annotate", ann, "--annotate-min", "1", merged])
    # Per-point analysis of tensor_pe.sv from the annotated source.
    src = os.path.join(ann, "tensor_pe.sv")
    lines = open(src).read().splitlines()
    covered = uncovered = 0
    misses = []
    for ln in lines:
        m = re.match(r"^\s*([%~ ])(\d+)\s", ln)
        if not m:
            continue
        count = int(m.group(2))
        if count > 0:
            covered += 1
        else:
            uncovered += 1
            misses.append(ln.strip()[:150])
    total = covered + uncovered
    pct = 100.0 * covered / total if total else 0.0
    L = ["# Structural coverage of rtl/tensor_pe.sv", "",
         "Verilator 5.020 `--coverage-line --coverage-toggle`, `normal` suite of: "
         + ", ".join(c[0] for c in CONFIGS) + ".", "",
         f"- Annotated coverage points in tensor_pe.sv (line + toggle, merged): **{covered}/{total} "
         f"covered ({pct:.1f} %)**", "",
         "verilator_coverage summary over all files (including the testbench):", "", "```",
         rep.strip().replace(ROOT + os.sep, "").replace(ROOT, "."), "```",
         "(The testbench's own error-reporting branches are never executed by a passing run.)", "",
         "## Points with zero hits in tensor_pe.sv", ""]
    L += [f"- `{m}`" for m in misses] if misses else ["- none"]
    if any("TPE_KCHK_ERROR" in m for m in misses):
        L += ["", "The `K_LIMIT_SEVERITY == ERROR` branch of the simulation-only K-limit checker is "
              "exercised by the dedicated K-limit severity tests in `scripts/run_regression.py` "
              "(stage 6), which are not part of this coverage merge."]
    with open(os.path.join(ROOT, "results", "coverage_summary.md"), "w") as f:
        f.write("\n".join(L) + "\n")
    print(f"tensor_pe.sv coverage: {covered}/{total} ({pct:.1f} %)")
    for m in misses:
        print("  MISS:", m)
    return 0


if __name__ == "__main__":
    sys.exit(main())
