// =============================================================================
//  SilicaFlux TensorCore 01  ::  tensor_pe_pkg
//  Aureom.AI | SilicaFlux-HPC
// -----------------------------------------------------------------------------
//  Shared numeric constants for the INT8 tensor processing element
//  (rtl/tensor_pe.sv) and its integration reference (rtl/tensor_pe_mesh.sv).
//
//  Everything here is a plain localparam or a constant function so the
//  package elaborates identically in Verilator, Icarus Verilog and Yosys.
//  (The SilicaFlux core package, silicaflux_pkg.sf, does not parse in
//  Icarus Verilog 12, so the PE deliberately does not depend on it; see
//  docs/AUDIT.md.)
// =============================================================================
`ifndef TENSOR_PE_PKG_SV
`define TENSOR_PE_PKG_SV
`timescale 1ns/1ps

package tensor_pe_pkg;

  // A package exports constants that a given importer may not use (e.g. when
  // a module overrides the default widths); that is not a design issue.
  /* verilator lint_off UNUSEDPARAM */

  // ---------------------------------------------------------------------------
  // Baseline operand / product / accumulator geometry
  // ---------------------------------------------------------------------------
  localparam int unsigned TPE_A_W    = 8;                    // signed INT8 operand A
  localparam int unsigned TPE_B_W    = 8;                    // signed INT8 operand B
  localparam int unsigned TPE_ACC_W  = 32;                   // baseline accumulator width
  // Product width is A_W + B_W = 16: exact for every INT8 pair.
  //   most positive  (-128) * (-128) = +16384 = 2^14  (needs 16 signed bits)
  //   most negative  (-128) * (+127) = -16256

  // ---------------------------------------------------------------------------
  // Overflow policy encodings (tensor_pe parameter OVF_POLICY)
  //   SATURATE : on overflow the accumulator clamps to ACC_MAX / ACC_MIN.
  //   WRAP     : the accumulator keeps the exact sum modulo 2^ACC_W.
  // In both policies overflow_o is a sticky flag; nothing overflows silently.
  // ---------------------------------------------------------------------------
  localparam int unsigned TPE_OVF_SATURATE = 0;
  localparam int unsigned TPE_OVF_WRAP     = 1;

  // ---------------------------------------------------------------------------
  // Simulation-only K-limit check severity (tensor_pe parameter K_LIMIT_SEVERITY)
  // ---------------------------------------------------------------------------
  localparam int unsigned TPE_KCHK_OFF     = 0;
  localparam int unsigned TPE_KCHK_WARNING = 1;
  localparam int unsigned TPE_KCHK_ERROR   = 2;

  // ---------------------------------------------------------------------------
  // tpe_max_exact_k
  //   Largest K such that EVERY sequence of K products of signed a_w x b_w
  //   operands, summed from zero, is exactly representable in a signed
  //   acc_w-bit register (so no prefix sum can overflow).
  //
  //   The binding bound is the positive extreme product
  //     (-2^(a_w-1)) * (-2^(b_w-1)) = 2^(a_w+b_w-2)
  //   K * 2^(a_w+b_w-2) <= 2^(acc_w-1) - 1   <=>   K <= 2^(acc_w-a_w-b_w+1) - 1
  //   (the negative extreme has smaller magnitude, so it never binds first).
  //
  //   INT8, ACC_W = 32  ->  2^17 - 1 =      131 071
  //   INT8, ACC_W = 40  ->  2^25 - 1 =   33 554 431
  //   Valid for a_w + b_w <= acc_w <= 64. Returns 0 if acc_w < a_w + b_w.
  // ---------------------------------------------------------------------------
  function automatic logic [63:0] tpe_max_exact_k(input int unsigned acc_w,
                                                   input int unsigned a_w,
                                                   input int unsigned b_w);
    // Assignment-to-function-name form (not `return`): Yosys 0.33 rejects `return`.
    if (acc_w < a_w + b_w) begin
      tpe_max_exact_k = 64'd0;
    end else begin
      tpe_max_exact_k = (64'd1 << (acc_w - a_w - b_w + 1)) - 64'd1;
    end
  endfunction

  /* verilator lint_on UNUSEDPARAM */

endpackage

`endif // TENSOR_PE_PKG_SV
