// =============================================================================
//  SilicaFlux TensorCore 01  ::  tensor_pe
//  Synthesizable INT8 tensor processing element (multiply-accumulate)
//  Aureom.AI | SilicaFlux-HPC
// -----------------------------------------------------------------------------
//  Arithmetic contract (per accepted operand pair, in issue order):
//
//      acc_next = (clear ? 0 : acc_current) + signed(a) * signed(b)
//
//    a, b    signed A_W / B_W bit two's complement   (baseline INT8)
//    product signed PROD_W = A_W + B_W bits, exact    (16 bits; covers
//            (-128)*(-128) = +16384, which does NOT fit in 15 bits)
//    acc     signed ACC_W bits                         (baseline 32; 40 verified)
//
//  Exactness guarantee: any accumulation of up to
//      MAX_EXACT_K = 2^(ACC_W - A_W - B_W + 1) - 1      (131 071 for ACC_W=32,
//                                                         33 554 431 for ACC_W=40)
//  products since the last clear is exact. Beyond that the sum may leave the
//  ACC_W range; the PE then never overflows silently: overflow_o is raised
//  (sticky until the next clear) on the exact accumulate step at which the
//  running sum first left the representable range, and the value follows
//  OVF_POLICY (saturate to ACC_MAX/ACC_MIN, or wrap modulo 2^ACC_W).
//
//  Pipeline (register stages; L = MUL_STAGES + 2 cycles input -> output):
//
//    S0   CAPTURE  operand/valid/clear capture.  These registers ARE the
//                  systolic forwarding registers (a_fwd_o, b_fwd_o,
//                  valid_fwd_o, clear_fwd_o): one register per mesh hop, no
//                  combinational path through the PE.
//    S1   MULTIPLY explicit sign extension of both operands to PROD_W,
//                  signed PROD_W x PROD_W -> PROD_W multiply (exact, since
//                  every INT8 product fits in PROD_W), registered.
//    S1+  (MUL_STAGES-1) extra product registers for multiplier retiming /
//                  DSP M-register absorption.  Each stage forwards the
//                  valid/clear token with its product, so ordering and
//                  token/data alignment are preserved by construction.
//    --   ALIGN    product sign-extended to ACC_W+1 bits.  Pure wiring
//                  (zero gates), so it is not given its own register stage.
//    ACC  ACCUMULATE single-cycle ACC_W+1-bit add + overflow detect +
//                  policy mux, feeding back into the ACC_W accumulator.
//                  The recurrence loop is exactly one cycle, which is what
//                  allows an initiation interval of ONE MAC PER CYCLE with
//                  no recurrence hazard (no loop-carried dependency is split
//                  across pipeline registers).
//    OUT  RESULT VISIBILITY  acc_result_o / overflow_o / acc_valid_o are
//                  direct register outputs of the ACC stage.
//
//  Token / visibility protocol:
//    * A command is ACCEPTED at a rising clk_i edge iff rst_ni=1, enable_i=1
//      and (operand_valid_i | clear_acc_i).
//    * Every accepted command produces exactly one acc_valid_o token
//      L = MUL_STAGES+2 ENABLED cycles later.  While that token is visible,
//      acc_result_o/overflow_o equal the running result INCLUDING that
//      command (prefix sum), so the final result of an accumulation is the
//      value shown with the token of its last operand pair.
//    * clear_acc_i travels with its operand pair through the pipeline.
//      Same-cycle clear + valid = clear-and-load: the pair becomes the first
//      term of a new accumulation (no bubble between accumulations).
//      Clear with operand_valid_i=0 restarts the accumulation at 0.
//      Products issued before the clear land in the old accumulation.
//
//  Priority (highest first):  rst_ni  >  enable_i (stall)  >  clear_acc_i
//                             >  accumulate.
//    * rst_ni=0  : asynchronous assertion. Kills every in-flight token,
//                  acc=0, overflow=0, acc_valid_o=0.  Deassertion must be
//                  synchronised to clk_i by the integrator.
//    * enable_i=0: freezes EVERY register (tokens, data, accumulator,
//                  outputs).  Inputs are not sampled, so clear/valid
//                  presented during a stall are ignored.  This common enable
//                  is the stall mechanism for a whole mesh.
//
//  Power: with OPERAND_GATING=1 the data registers (S0 operands, product
//  stages) load only when their own stage carries a valid token, so the
//  multiplier inputs and product registers do not switch on idle cycles.
//  This is register-enable operand isolation.  No clock-gating cell is
//  instantiated and no physical clock gating is claimed; an ICG-insertion
//  step in an ASIC flow may convert these enables, which would then need
//  its own verification.
//
//  Reset style follows the SilicaFlux core (tensor_unit / vector_engine):
//  active-low asynchronous reset on control and architectural state only;
//  pure datapath registers (operands, products) are not reset.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tensor_pe #(
  parameter int unsigned A_W              = tensor_pe_pkg::TPE_A_W,   // signed operand A width (INT8)
  parameter int unsigned B_W              = tensor_pe_pkg::TPE_B_W,   // signed operand B width (INT8)
  parameter int unsigned ACC_W            = tensor_pe_pkg::TPE_ACC_W, // accumulator width (32/40 verified)
  parameter int unsigned MUL_STAGES       = 1,     // product register stages, 1..4
  parameter int unsigned OVF_POLICY       = 0,     // tensor_pe_pkg::TPE_OVF_SATURATE / _WRAP
  parameter bit          OPERAND_GATING   = 1'b1,  // 1: data regs load only with valid work
  // Integrator's maximum supported accumulation length. Must not exceed the
  // exact bound for ACC_W (checked at elaboration).
  parameter logic [63:0] MAX_K            = tensor_pe_pkg::tpe_max_exact_k(ACC_W, A_W, B_W),
  // Simulation-only check when an accumulation exceeds MAX_K terms.
  parameter int unsigned K_LIMIT_SEVERITY = 1      // 0 off, 1 $warning, 2 $error
) (
  input  logic                    clk_i,
  input  logic                    rst_ni,          // async assert, sync deassert (external)

  input  logic                    enable_i,        // common pipeline enable (0 = stall)
  input  logic                    clear_acc_i,     // start new accumulation with this pair
  input  logic signed [A_W-1:0]   operand_a_i,
  input  logic signed [B_W-1:0]   operand_b_i,
  input  logic                    operand_valid_i, // (operand_a_i, operand_b_i) is a MAC pair

  output logic signed [ACC_W-1:0] acc_result_o,    // running (prefix) accumulation
  output logic                    acc_valid_o,     // one token per accepted command
  output logic                    overflow_o,      // sticky since last clear

  // Systolic forwarding (registered S0 copies, aligned by construction)
  output logic signed [A_W-1:0]   a_fwd_o,
  output logic signed [B_W-1:0]   b_fwd_o,
  output logic                    valid_fwd_o,
  output logic                    clear_fwd_o
);

  // ===========================================================================
  // Derived geometry
  // ===========================================================================
  localparam int unsigned PROD_W      = A_W + B_W;
  localparam logic [63:0] MAX_EXACT_K = tensor_pe_pkg::tpe_max_exact_k(ACC_W, A_W, B_W);
  localparam bit          SATURATE    = (OVF_POLICY == tensor_pe_pkg::TPE_OVF_SATURATE);

  localparam logic signed [ACC_W-1:0] ACC_MAX = {1'b0, {(ACC_W-1){1'b1}}};
  localparam logic signed [ACC_W-1:0] ACC_MIN = {1'b1, {(ACC_W-1){1'b0}}};

  // ===========================================================================
  // Elaboration-time configuration checks
  //   Each check must stop elaboration in every tool, whatever warning flags
  //   the integrator uses:
  //   * Yosys 0.33: $error is a hard error.
  //   * Icarus Verilog 12 silently ignores $error inside generate blocks, so an
  //     undefined module named after the check is also instantiated.
  //   * Verilator 5.020 reports an elaboration $error only as a USERERROR
  //     warning (non-fatal under -Wno-fatal), so a localparam named after the
  //     check is initialised by a constant function that executes $fatal: a
  //     hard error at that localparam, raised only when the branch is
  //     elaborated.
  // ===========================================================================
`ifdef VERILATOR
  function automatic int tpe_cfg_fatal(input string msg);
    $fatal(1, "%s", msg);
    tpe_cfg_fatal = 0;
  endfunction
`endif

  if (A_W < 2 || A_W > 16 || B_W < 2 || B_W > 16) begin : g_chk_operand_w
    $error("tensor_pe: A_W/B_W must be in [2,16] (A_W=%0d B_W=%0d)", A_W, B_W);
`ifdef __ICARUS__
    tensor_pe_config_error__operand_width_out_of_range u_cfg_error ();
`elsif VERILATOR
    localparam int TENSOR_PE_CONFIG_ERROR__operand_width_out_of_range =
        tpe_cfg_fatal("tensor_pe: A_W/B_W must be in [2,16]");
`endif
  end
  if (ACC_W < PROD_W || ACC_W > 64) begin : g_chk_acc_w
    $error("tensor_pe: ACC_W (%0d) must be in [A_W+B_W, 64]", ACC_W);
`ifdef __ICARUS__
    tensor_pe_config_error__acc_width_out_of_range u_cfg_error ();
`elsif VERILATOR
    localparam int TENSOR_PE_CONFIG_ERROR__acc_width_out_of_range =
        tpe_cfg_fatal("tensor_pe: ACC_W must be in [A_W+B_W, 64]");
`endif
  end
  if (MUL_STAGES < 1 || MUL_STAGES > 4) begin : g_chk_mul_stages
    $error("tensor_pe: MUL_STAGES (%0d) must be in [1,4]", MUL_STAGES);
`ifdef __ICARUS__
    tensor_pe_config_error__mul_stages_out_of_range u_cfg_error ();
`elsif VERILATOR
    localparam int TENSOR_PE_CONFIG_ERROR__mul_stages_out_of_range =
        tpe_cfg_fatal("tensor_pe: MUL_STAGES must be in [1,4]");
`endif
  end
  if (OVF_POLICY > tensor_pe_pkg::TPE_OVF_WRAP) begin : g_chk_ovf_policy
    $error("tensor_pe: OVF_POLICY (%0d) must be SATURATE(0) or WRAP(1)", OVF_POLICY);
`ifdef __ICARUS__
    tensor_pe_config_error__unknown_overflow_policy u_cfg_error ();
`elsif VERILATOR
    localparam int TENSOR_PE_CONFIG_ERROR__unknown_overflow_policy =
        tpe_cfg_fatal("tensor_pe: OVF_POLICY must be SATURATE(0) or WRAP(1)");
`endif
  end
  if (MAX_K == 64'd0 || MAX_K > MAX_EXACT_K) begin : g_chk_max_k
    $error("tensor_pe: unsupported accumulation range: MAX_K exceeds the exact bound for ACC_W");
`ifdef __ICARUS__
    tensor_pe_config_error__max_k_exceeds_exact_bound_for_acc_w u_cfg_error ();
`elsif VERILATOR
    localparam int TENSOR_PE_CONFIG_ERROR__max_k_exceeds_exact_bound_for_acc_w =
        tpe_cfg_fatal("tensor_pe: unsupported accumulation range: MAX_K exceeds the exact bound for ACC_W");
`endif
  end
  if (K_LIMIT_SEVERITY > tensor_pe_pkg::TPE_KCHK_ERROR) begin : g_chk_ksev
    $error("tensor_pe: K_LIMIT_SEVERITY (%0d) must be 0, 1 or 2", K_LIMIT_SEVERITY);
`ifdef __ICARUS__
    tensor_pe_config_error__k_limit_severity_out_of_range u_cfg_error ();
`elsif VERILATOR
    localparam int TENSOR_PE_CONFIG_ERROR__k_limit_severity_out_of_range =
        tpe_cfg_fatal("tensor_pe: K_LIMIT_SEVERITY must be 0, 1 or 2");
`endif
  end

  // ===========================================================================
  // S0  CAPTURE  (also the systolic forwarding registers)
  // ===========================================================================
  logic                  s0_valid_q, s0_clear_q;
  logic signed [A_W-1:0] s0_a_q;
  logic signed [B_W-1:0] s0_b_q;
  logic                  s0_load;

  always_ff @(posedge clk_i or negedge rst_ni) begin : p_s0_ctrl
    if (!rst_ni) begin
      s0_valid_q <= 1'b0;
      s0_clear_q <= 1'b0;
    end else if (enable_i) begin
      s0_valid_q <= operand_valid_i;
      s0_clear_q <= clear_acc_i;
    end
  end

  assign s0_load = enable_i & (operand_valid_i | ~OPERAND_GATING);

  always_ff @(posedge clk_i) begin : p_s0_data
    if (s0_load) begin
      s0_a_q <= operand_a_i;
      s0_b_q <= operand_b_i;
    end
  end

  // ===========================================================================
  // S1  MULTIPLY
  //   Both operands are explicitly sign-extended to PROD_W by replicating
  //   their sign bit; the multiply is then signed PROD_W x PROD_W with a
  //   PROD_W result.  No operand of the expression is unsigned and every
  //   operand already has the result width, so no implicit context sizing
  //   or signedness rule is involved.  The low PROD_W bits of the product
  //   equal the exact product because every A_W x B_W product lies in
  //   [-2^(PROD_W-2) + 2^(min-1), 2^(PROD_W-2)] which fits in PROD_W bits.
  // ===========================================================================
  logic signed [PROD_W-1:0] mul_a_ext, mul_b_ext, mul_p;

  assign mul_a_ext = $signed({{(PROD_W-A_W){s0_a_q[A_W-1]}}, s0_a_q});
  assign mul_b_ext = $signed({{(PROD_W-B_W){s0_b_q[B_W-1]}}, s0_b_q});
  assign mul_p     = mul_a_ext * mul_b_ext;

  // Product pipeline: stage m carries {valid, clear, product}.
  //   pm_p_q holds MUL_STAGES products flattened (stage m at [m*PROD_W +: PROD_W]);
  //   a flat vector is used because Yosys 0.33 rejects 2-D packed arrays.
  logic [MUL_STAGES-1:0]        pm_valid_q, pm_clear_q;
  logic [MUL_STAGES*PROD_W-1:0] pm_p_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin : p_mul_ctrl
    if (!rst_ni) begin
      pm_valid_q <= '0;
      pm_clear_q <= '0;
    end else if (enable_i) begin
      for (int m = MUL_STAGES - 1; m > 0; m--) begin
        pm_valid_q[m] <= pm_valid_q[m-1];
        pm_clear_q[m] <= pm_clear_q[m-1];
      end
      pm_valid_q[0] <= s0_valid_q;
      pm_clear_q[0] <= s0_clear_q;
    end
  end

  always_ff @(posedge clk_i) begin : p_mul_data
    if (enable_i & (s0_valid_q | ~OPERAND_GATING)) begin
      pm_p_q[0 +: PROD_W] <= mul_p;
    end
    for (int m = 1; m < MUL_STAGES; m++) begin
      if (enable_i & (pm_valid_q[m-1] | ~OPERAND_GATING)) begin
        pm_p_q[m*PROD_W +: PROD_W] <= pm_p_q[(m-1)*PROD_W +: PROD_W];
      end
    end
  end

  // ===========================================================================
  // ALIGN + ACCUMULATE
  // ===========================================================================
  logic                     acc_in_valid, acc_in_clear, acc_token;
  logic signed [PROD_W-1:0] acc_in_p;

  assign acc_in_valid = pm_valid_q[MUL_STAGES-1];
  assign acc_in_clear = pm_clear_q[MUL_STAGES-1];
  assign acc_in_p     = $signed(pm_p_q[(MUL_STAGES-1)*PROD_W +: PROD_W]);
  assign acc_token    = acc_in_valid | acc_in_clear;

  logic signed [ACC_W-1:0] acc_q;
  logic                    ovf_q, acc_vld_q;

  // Base of this step: clear has priority over the previous accumulation.
  logic signed [ACC_W-1:0] acc_base;
  logic                    ovf_base;
  assign acc_base = acc_in_clear ? '0   : acc_q;
  assign ovf_base = acc_in_clear ? 1'b0 : ovf_q;

  // Product alignment: explicit sign extension to ACC_W+1 bits (wiring only).
  // A clear-only token (valid=0) contributes an addend of zero.
  logic signed [ACC_W:0] add_base_ext, add_p_ext, add_sum;
  assign add_base_ext = $signed({acc_base[ACC_W-1], acc_base});
  assign add_p_ext    = acc_in_valid ? $signed({{(ACC_W+1-PROD_W){acc_in_p[PROD_W-1]}}, acc_in_p})
                                     : '0;

  // Exact sum: both addends lie in [-2^(ACC_W-1), 2^(ACC_W-1)), so their sum
  // always fits in ACC_W+1 signed bits.
  assign add_sum = add_base_ext + add_p_ext;

  // The exact sum is representable in ACC_W bits iff its two MSBs agree.
  logic add_ovf;
  assign add_ovf = add_sum[ACC_W] ^ add_sum[ACC_W-1];

  // Policy: SATURATE clamps toward the sign of the exact sum; otherwise the
  // low ACC_W bits are kept (exact when no overflow, modulo 2^ACC_W if WRAP).
  logic signed [ACC_W-1:0] acc_lo, acc_d;
  logic                    ovf_d;
  assign acc_lo = add_sum[ACC_W-1:0];
  assign acc_d  = (add_ovf && SATURATE) ? (add_sum[ACC_W] ? ACC_MIN : ACC_MAX) : acc_lo;
  assign ovf_d  = ovf_base | add_ovf;

  always_ff @(posedge clk_i or negedge rst_ni) begin : p_acc
    if (!rst_ni) begin
      acc_q     <= '0;
      ovf_q     <= 1'b0;
      acc_vld_q <= 1'b0;
    end else if (enable_i) begin
      acc_vld_q <= acc_token;
      if (acc_token) begin
        acc_q <= acc_d;
        ovf_q <= ovf_d;
      end
    end
  end

  // ===========================================================================
  // Outputs
  // ===========================================================================
  assign acc_result_o = acc_q;
  assign acc_valid_o  = acc_vld_q;
  assign overflow_o   = ovf_q;

  assign a_fwd_o      = s0_a_q;
  assign b_fwd_o      = s0_b_q;
  assign valid_fwd_o  = s0_valid_q;
  assign clear_fwd_o  = s0_clear_q;

`ifndef SYNTHESIS
  // ===========================================================================
  // Simulation-only checks (immediate assertions: run in Icarus and Verilator)
  // ===========================================================================
  // Legal product range of signed A_W x B_W operands:
  //   max = (-2^(A_W-1)) * (-2^(B_W-1))            = +2^(PROD_W-2)
  //   min = -(2^(PROD_W-2) - 2^(min(A_W,B_W)-1))   (e.g. -128*127 = -16256)
  localparam int unsigned MIN_OP_W   = (A_W < B_W) ? A_W : B_W;
  localparam longint      PROD_MAX_L = longint'(64'd1 << (PROD_W - 2));
  localparam longint      PROD_MIN_L = -(PROD_MAX_L - longint'(64'd1 << (MIN_OP_W - 1)));

  logic [63:0] sim_k_q;        // valid MACs in the current accumulation
  logic [63:0] sim_k_next;
  assign sim_k_next = (acc_in_clear ? 64'd0 : sim_k_q) + {63'd0, acc_in_valid};

  // Plain `always` (not always_ff): these processes are checkers, not hardware.
  always @(posedge clk_i or negedge rst_ni) begin : p_sim_checks
    if (!rst_ni) begin
      sim_k_q <= 64'd0;
    end else if (enable_i && acc_token) begin
      sim_k_q <= sim_k_next;

      // a_prod_range: the product register holds a legal A_W x B_W product.
      if (acc_in_valid) begin
        assert (longint'(acc_in_p) >= PROD_MIN_L && longint'(acc_in_p) <= PROD_MAX_L)
          else $error("%m: a_prod_range violated: product %0d outside [%0d,%0d]",
                      acc_in_p, PROD_MIN_L, PROD_MAX_L);
      end

      // a_exact_within_k: no accumulation of <= MAX_EXACT_K terms may overflow.
      if (acc_in_valid && add_ovf) begin
        assert (sim_k_next > MAX_EXACT_K)
          else $error("%m: a_exact_within_k violated: overflow after %0d terms (bound %0d)",
                      sim_k_next, MAX_EXACT_K);
      end

      // a_k_limit: accumulation length beyond the configured MAX_K.
      if (K_LIMIT_SEVERITY != tensor_pe_pkg::TPE_KCHK_OFF &&
          acc_in_valid && sim_k_next == MAX_K + 64'd1) begin
        if (K_LIMIT_SEVERITY == tensor_pe_pkg::TPE_KCHK_WARNING) begin
          $warning("%m: a_k_limit: accumulation exceeds MAX_K=%0d terms; exactness no longer guaranteed (overflow_o still reports actual overflow)",
                   MAX_K);
        end else if (K_LIMIT_SEVERITY == tensor_pe_pkg::TPE_KCHK_ERROR) begin
          $error("%m: a_k_limit: accumulation exceeds MAX_K=%0d terms", MAX_K);
        end
      end
    end
  end

  // a_ctrl_known: control/architectural outputs are never X/Z out of reset.
  // (Reduction-XOR idiom rather than $isunknown: Icarus Verilog 12 returns 1
  //  from $isunknown on any concatenation, even a fully known one.)
  always @(posedge clk_i) begin : p_sim_xcheck
    if (rst_ni) begin
      assert ((^{acc_vld_q, ovf_q, s0_valid_q, s0_clear_q, acc_q}) !== 1'bx)
        else $error("%m: a_ctrl_known violated: X/Z on control or accumulator state");
    end
  end
`endif // SYNTHESIS

`ifdef FORMAL
  // ===========================================================================
  // Formal reference (Yosys `sat -prove-asserts`, see formal/).
  //   An independent formulation of one accumulate step: exact 66-bit sum,
  //   explicit range comparison, explicit policy.  Proven for ALL values of
  //   the accumulator state, product register, valid and clear (registers are
  //   free variables in the combinational proof), not just reachable ones.
  // ===========================================================================
  logic signed [65:0]      f_base, f_addend, f_exact;
  logic                    f_ovf;
  logic signed [ACC_W-1:0] f_acc;
  logic signed [31:0]      f_a32, f_b32, f_p32;

  always_comb begin : p_formal_ref
    f_base   = acc_in_clear ? 66'sd0 : 66'(acc_q);      // size cast: sign extension
    f_addend = acc_in_valid ? 66'(acc_in_p) : 66'sd0;
    f_exact  = f_base + f_addend;
    f_ovf    = (f_exact > 66'(ACC_MAX)) || (f_exact < 66'(ACC_MIN));
    if (f_ovf && SATURATE) f_acc = (f_exact > 66'sd0) ? ACC_MAX : ACC_MIN;
    else                   f_acc = f_exact[ACC_W-1:0];

    f_a32 = 32'(s0_a_q);
    f_b32 = 32'(s0_b_q);
    f_p32 = f_a32 * f_b32;

    assert (acc_d == f_acc);                                // accumulate step value
    assert (add_ovf == f_ovf);                              // exact overflow detection
    assert (ovf_d == ((acc_in_clear ? 1'b0 : ovf_q) | f_ovf)); // sticky flag
    assert (32'(mul_p) == f_p32);                           // multiplier exactness
  end
`endif // FORMAL

endmodule

`default_nettype wire
