// =============================================================================
//  SilicaFlux TensorCore 01  ::  tensor_pe_mesh  (integration reference)
//  Output-stationary ROWS x COLS mesh of tensor_pe
// -----------------------------------------------------------------------------
//  Purpose: demonstrate and verify that tensor_pe composes into a systolic
//  mesh using only its forwarding ports.  It is a reference integration, not
//  a complete tensor core: operand skew buffers, result drain and tiling
//  control belong to the surrounding controller.
//
//  Dataflow (PE(i,j), i = row, j = column):
//    A[i][k] enters row i from the west and moves east one PE per enabled
//    cycle (a_fwd_o -> east neighbour's operand_a_i), carrying the row's
//    valid and clear tokens with it (valid_fwd_o / clear_fwd_o).
//    B[k][j] enters column j from the north and moves south one PE per
//    enabled cycle (b_fwd_o -> south neighbour's operand_b_i).
//    PE(i,j) accumulates C[i][j] = sum_k A[i][k] * B[k][j] locally.
//
//  Injection contract (wavefront skew, counted in ENABLED cycles):
//    stream element s (one k step of one tile, or a bubble) must be presented
//    at row i on enabled cycle s + i and at column j on enabled cycle s + j.
//    Element s is then at PE(i,j) on enabled cycle s + i + j from both
//    directions.  clear on element s marks the first k of a new tile.
//
//  Timing: every inter-PE signal is a tensor_pe register output, so the
//  longest combinational path in the mesh is the longest path inside one PE
//  (checked structurally by synth/run_synth.py with Yosys `ltp`).  enable_i
//  is the single common stall: a global freeze of every PE keeps all
//  wavefronts aligned.  enable_i and rst_ni are high-fanout nets that a large
//  array should drive from a buffered tree (or a pipelined, skew-matched
//  enable) -- out of scope for this reference.
//
//  Simulation-only check: the B token arriving from the north (the north
//  PE's valid/clear) must equal the token arriving from the west; any
//  violation means the injector broke the wavefront contract.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tensor_pe_mesh #(
  parameter int unsigned ROWS             = 4,
  parameter int unsigned COLS             = 4,
  parameter int unsigned A_W              = 8,
  parameter int unsigned B_W              = 8,
  parameter int unsigned ACC_W            = 32,
  parameter int unsigned MUL_STAGES       = 1,
  parameter int unsigned OVF_POLICY       = 0,
  parameter bit          OPERAND_GATING   = 1'b1,
  parameter int unsigned K_LIMIT_SEVERITY = 1
) (
  input  logic                          clk_i,
  input  logic                          rst_ni,
  input  logic                          enable_i,

  input  logic [ROWS*A_W-1:0]           west_a_i,      // row i at [i*A_W +: A_W]
  input  logic [ROWS-1:0]               west_valid_i,
  input  logic [ROWS-1:0]               west_clear_i,
  input  logic [COLS*B_W-1:0]           north_b_i,     // column j at [j*B_W +: B_W]

  output logic [ROWS*COLS*ACC_W-1:0]    acc_result_o,  // PE(i,j) at [(i*COLS+j)*ACC_W +: ACC_W]
  output logic [ROWS*COLS-1:0]          acc_valid_o,   // PE(i,j) at [i*COLS+j]
  output logic [ROWS*COLS-1:0]          overflow_o,

  output logic [ROWS*A_W-1:0]           east_a_o,      // for chaining meshes
  output logic [ROWS-1:0]               east_valid_o,
  output logic [ROWS-1:0]               east_clear_o,
  output logic [COLS*B_W-1:0]           south_b_o,
  output logic [COLS-1:0]               south_valid_o
);

  // Horizontal nets: node (i, j) for j = 0..COLS feeds PE(i, j) (j = COLS is the east edge).
  localparam int unsigned HN = ROWS * (COLS + 1);
  // Vertical nets:   node (i, j) for i = 0..ROWS feeds PE(i, j) (i = ROWS is the south edge).
  localparam int unsigned VN = (ROWS + 1) * COLS;

  logic [HN*A_W-1:0] h_a;
  logic [HN-1:0]     h_valid, h_clear;
  logic [VN*B_W-1:0] v_b;
  logic [VN-1:0]     v_valid, v_clear;   // north tokens (alignment check / south edge)

  for (genvar i = 0; i < ROWS; i++) begin : g_west
    assign h_a[(i*(COLS+1))*A_W +: A_W] = west_a_i[i*A_W +: A_W];
    assign h_valid[i*(COLS+1)]          = west_valid_i[i];
    assign h_clear[i*(COLS+1)]          = west_clear_i[i];
    assign east_a_o[i*A_W +: A_W]       = h_a[(i*(COLS+1)+COLS)*A_W +: A_W];
    assign east_valid_o[i]              = h_valid[i*(COLS+1)+COLS];
    assign east_clear_o[i]              = h_clear[i*(COLS+1)+COLS];
  end

  for (genvar j = 0; j < COLS; j++) begin : g_north
    assign v_b[j*B_W +: B_W]        = north_b_i[j*B_W +: B_W];
    assign v_valid[j]               = 1'b0;   // no north token at the boundary (unchecked)
    assign v_clear[j]               = 1'b0;
    assign south_b_o[j*B_W +: B_W]  = v_b[(ROWS*COLS+j)*B_W +: B_W];
    assign south_valid_o[j]         = v_valid[ROWS*COLS+j];
  end

  for (genvar i = 0; i < ROWS; i++) begin : g_row
    for (genvar j = 0; j < COLS; j++) begin : g_col
      localparam int unsigned HI = i*(COLS+1) + j;   // west input node of PE(i,j)
      localparam int unsigned VI = i*COLS + j;       // north input node of PE(i,j)
      logic valid_fwd, clear_fwd;

      tensor_pe #(
        .A_W(A_W), .B_W(B_W), .ACC_W(ACC_W), .MUL_STAGES(MUL_STAGES),
        .OVF_POLICY(OVF_POLICY), .OPERAND_GATING(OPERAND_GATING),
        .K_LIMIT_SEVERITY(K_LIMIT_SEVERITY)
      ) u_pe (
        .clk_i           (clk_i),
        .rst_ni          (rst_ni),
        .enable_i        (enable_i),
        .clear_acc_i     (h_clear[HI]),
        .operand_a_i     (h_a[HI*A_W +: A_W]),
        .operand_b_i     (v_b[VI*B_W +: B_W]),
        .operand_valid_i (h_valid[HI]),
        .acc_result_o    (acc_result_o[VI*ACC_W +: ACC_W]),
        .acc_valid_o     (acc_valid_o[VI]),
        .overflow_o      (overflow_o[VI]),
        .a_fwd_o         (h_a[(HI+1)*A_W +: A_W]),
        .b_fwd_o         (v_b[(VI+COLS)*B_W +: B_W]),
        .valid_fwd_o     (valid_fwd),
        .clear_fwd_o     (clear_fwd)
      );

      // The row's tokens travel east with A; a copy travels south with B so
      // the south neighbour can check wavefront alignment.
      assign h_valid[HI+1]   = valid_fwd;
      assign h_clear[HI+1]   = clear_fwd;
      assign v_valid[VI+COLS] = valid_fwd;
      assign v_clear[VI+COLS] = clear_fwd;

`ifndef SYNTHESIS
      if (i > 0) begin : g_align_chk
        always @(posedge clk_i) begin
          if (rst_ni === 1'b1 && enable_i === 1'b1) begin
            assert (v_valid[VI] === h_valid[HI] && v_clear[VI] === h_clear[HI])
              else $error("%m: a_wavefront_aligned violated at PE(%0d,%0d): north token v=%b c=%b, west token v=%b c=%b",
                          i, j, v_valid[VI], v_clear[VI], h_valid[HI], h_clear[HI]);
          end
        end
      end
`endif
    end
  end

endmodule

`default_nettype wire
