# Formal (Yosys SAT) summary

Tool: Yosys 0.33 (git sha1 2584903a060)

Proof: `sat -prove-asserts` after `expose -evert-dff` (all register states free).

| A_W | B_W | ACC_W | MUL_STAGES | OVF_POLICY | Result | Problem size | Time |
|---|---|---|---|---|---|---|---|
| 8 | 8 | 16 | 1 | SAT | PROVEN | Solving problem with 14718 variables and 42601 clauses.. | 1.1 s |
| 8 | 8 | 16 | 1 | WRAP | PROVEN | Solving problem with 13985 variables and 40532 clauses.. | 0.8 s |
| 8 | 8 | 20 | 1 | SAT | PROVEN | Solving problem with 14966 variables and 43253 clauses.. | 1.2 s |
| 8 | 8 | 20 | 2 | WRAP | PROVEN | Solving problem with 14301 variables and 41328 clauses.. | 0.9 s |
| 8 | 8 | 32 | 1 | SAT | PROVEN | Solving problem with 15710 variables and 45209 clauses.. | 1.6 s |
| 8 | 8 | 32 | 1 | WRAP | PROVEN | Solving problem with 14657 variables and 42308 clauses.. | 1.2 s |
| 8 | 8 | 32 | 2 | SAT | PROVEN | Solving problem with 15858 variables and 45561 clauses.. | 0.6 s |
| 8 | 8 | 40 | 1 | SAT | PROVEN | Solving problem with 16206 variables and 46513 clauses.. | 1.3 s |
| 8 | 8 | 40 | 1 | WRAP | PROVEN | Solving problem with 14993 variables and 43196 clauses.. | 1.3 s |
| 8 | 8 | 64 | 1 | SAT | PROVEN | Solving problem with 17694 variables and 50425 clauses.. | 1.0 s |
| 8 | 8 | 64 | 1 | WRAP | PROVEN | Solving problem with 16001 variables and 45860 clauses.. | 1.2 s |
| 4 | 4 | 12 | 1 | WRAP | PROVEN | Solving problem with 13597 variables and 39644 clauses.. | 0.1 s |
| 4 | 6 | 16 | 1 | SAT | PROVEN | Solving problem with 14552 variables and 42265 clauses.. | 0.2 s |

## Seeded bugs (proof must fail)

| Mutant | Config | Counterexample found |
|---|---|---|
| saturation uses wrapped sign | ACC_W=32 SAT | yes |
| overflow detection removed | ACC_W=32 WRAP | yes |
| operand A zero-extended | ACC_W=32 SAT | yes |
| clear ignored when valid | ACC_W=40 SAT | yes |
| overflow flag not sticky | ACC_W=20 WRAP | yes |

**Overall: PASS**
