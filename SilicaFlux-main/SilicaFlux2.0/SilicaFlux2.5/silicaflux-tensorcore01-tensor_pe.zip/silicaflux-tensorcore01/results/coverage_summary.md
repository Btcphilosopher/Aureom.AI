# Structural coverage of rtl/tensor_pe.sv

Verilator 5.020 `--coverage-line --coverage-toggle`, `normal` suite of: a32_sat_m1_g1, a32_wrap_m1_g1, a32_sat_m2_g0, a20_wrap_m3_g0, a16_sat_m4_g1.

- Annotated coverage points in tensor_pe.sv (line + toggle, merged): **84/85 covered (98.8 %)**

verilator_coverage summary over all files (including the testbench):

```
Total coverage (235/274) 85.00%
See lines with '%00' in build/coverage/annotated
```
(The testbench's own error-reporting branches are never executed by a passing run.)

## Points with zero hits in tensor_pe.sv

- `%000000         end else if (K_LIMIT_SEVERITY == tensor_pe_pkg::TPE_KCHK_ERROR) begin`

The `K_LIMIT_SEVERITY == ERROR` branch of the simulation-only K-limit checker is exercised by the dedicated K-limit severity tests in `scripts/run_regression.py` (stage 6), which are not part of this coverage merge.
