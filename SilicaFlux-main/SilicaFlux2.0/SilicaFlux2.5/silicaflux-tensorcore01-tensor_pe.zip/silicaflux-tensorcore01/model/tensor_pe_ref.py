"""Independent integer reference model for the SilicaFlux TensorCore 01 PE.

Written from the interface contract in docs/INTERFACE_SPEC.md, not from the
RTL. All arithmetic uses Python's unbounded integers, so the "true" value of
every product and sum is always available; fixed-width behaviour is applied
explicitly and only where the contract says it happens:

* products are exact (``a * b`` on Python ints),
* the running sum is computed exactly, then checked against the signed
  ``acc_w`` range,
* out-of-range sums are either saturated or wrapped modulo ``2**acc_w``
  according to the overflow policy, and the sticky overflow flag is set.

Two levels are provided:

* transaction level: :func:`accumulate_step`, :func:`accumulate_constant`,
  :func:`reference_accumulate` (pure arithmetic, no timing), and
* cycle level: :class:`PeCycleModel`, which models the pipeline, the
  common enable (stall), the pipeline-aligned clear token, asynchronous
  reset, operand gating and the forwarding registers, cycle by cycle.

``None`` stands for an unknown (X) value: data registers that have never
been loaded, or operands the testbench drove as X.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, List, Optional, Sequence, Tuple

OVF_SATURATE = 0
OVF_WRAP = 1
POLICY_NAMES = {OVF_SATURATE: "SAT", OVF_WRAP: "WRAP"}


# ---------------------------------------------------------------------------
# Explicit-width integer semantics
# ---------------------------------------------------------------------------
def int_range(width: int) -> Tuple[int, int]:
    """Inclusive range of a signed two's-complement ``width``-bit integer."""
    if width < 1:
        raise ValueError("width must be >= 1")
    return -(1 << (width - 1)), (1 << (width - 1)) - 1


def wrap(value: int, width: int) -> int:
    """Reduce ``value`` modulo 2**width into the signed ``width``-bit range."""
    value &= (1 << width) - 1
    if value >> (width - 1):
        value -= 1 << width
    return value


def saturate(value: int, width: int) -> int:
    """Clamp ``value`` into the signed ``width``-bit range."""
    lo, hi = int_range(width)
    return lo if value < lo else hi if value > hi else value


def product_range(a_w: int, b_w: int) -> Tuple[int, int]:
    """Exact (min, max) of signed a_w x signed b_w products, by enumeration
    of the four corner candidates (the extremes of a bilinear form)."""
    alo, ahi = int_range(a_w)
    blo, bhi = int_range(b_w)
    cands = [alo * blo, alo * bhi, ahi * blo, ahi * bhi]
    return min(cands), max(cands)


def max_exact_k(acc_w: int, a_w: int = 8, b_w: int = 8) -> int:
    """Largest K such that every K-term sum of products is representable.

    Derived here from first principles (not the RTL's closed form): with
    products in [pmin, pmax] and the sum starting at zero, the worst K-term
    sums are K*pmax and K*pmin, so K <= hi // pmax and K <= lo // pmin.
    """
    lo, hi = int_range(acc_w)
    pmin, pmax = product_range(a_w, b_w)
    k_pos = hi // pmax if pmax > 0 else float("inf")
    k_neg = lo // pmin if pmin < 0 else float("inf")      # both negative -> positive
    return int(min(k_pos, k_neg))


# ---------------------------------------------------------------------------
# Transaction-level accumulation
# ---------------------------------------------------------------------------
def accumulate_step(acc: int, ovf: bool, clear: bool, valid: bool,
                    product: Optional[int], acc_w: int, policy: int) -> Tuple[int, bool]:
    """One accumulate step of the contract.

    ``clear`` restarts the accumulation (value 0, flag 0) *before* this
    step's product is added (clear-and-load). A step with ``valid`` false
    contributes nothing.
    """
    base, base_ovf = (0, False) if clear else (acc, ovf)
    if not valid:
        return base, base_ovf
    if product is None:
        raise ValueError("valid accumulate step with an unknown (X) product")
    exact = base + product
    lo, hi = int_range(acc_w)
    if lo <= exact <= hi:
        return exact, base_ovf
    if policy == OVF_SATURATE:
        return saturate(exact, acc_w), True
    if policy == OVF_WRAP:
        return wrap(exact, acc_w), True
    raise ValueError(f"unknown overflow policy {policy}")


def accumulate_constant(acc: int, ovf: bool, product: int, n: int,
                        acc_w: int, policy: int) -> Tuple[int, bool]:
    """Closed form of ``n`` consecutive non-clear valid steps with the same
    product, used to fast-forward very long runs (e.g. 2**25 terms).

    Equivalent to iterating :func:`accumulate_step` (see tests).
    """
    if n <= 0:
        return acc, ovf
    lo, hi = int_range(acc_w)
    if not lo <= acc <= hi:
        raise ValueError("accumulator outside its range")
    exact = acc + n * product
    if lo <= exact <= hi:
        # Constant addend: the prefix sums are monotonic between acc and
        # exact, both in range, so no step overflowed.
        return exact, ovf
    if policy == OVF_WRAP:
        # Modular addition is associative: wrap(wrap(x) + p) == wrap(x + p).
        return wrap(exact, acc_w), True
    # Saturation: the step that first leaves the range clamps toward the
    # sign of the product; every later step pushes the same way and stays
    # clamped.
    return (hi if product > 0 else lo), True


def reference_accumulate(terms: Iterable[Tuple[bool, bool, int, int]], acc_w: int,
                         policy: int) -> List[Tuple[int, bool]]:
    """Running result after each (clear, valid, a, b) command."""
    acc, ovf = 0, False
    out = []
    for clear, valid, a, b in terms:
        acc, ovf = accumulate_step(acc, ovf, clear, valid, a * b if valid else None,
                                   acc_w, policy)
        out.append((acc, ovf))
    return out


# ---------------------------------------------------------------------------
# Cycle-accurate model of the interface contract
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class PeConfig:
    a_w: int = 8
    b_w: int = 8
    acc_w: int = 32
    mul_stages: int = 1
    policy: int = OVF_SATURATE
    operand_gating: bool = True

    @property
    def latency(self) -> int:
        """Cycles from operand presentation to the visible result token."""
        return self.mul_stages + 2

    @property
    def max_exact_k(self) -> int:
        return max_exact_k(self.acc_w, self.a_w, self.b_w)


@dataclass
class PeOutputs:
    acc_valid: int
    acc: int
    ovf: int
    valid_fwd: int
    clear_fwd: int
    a_fwd: Optional[int]
    b_fwd: Optional[int]


def _mul(a: Optional[int], b: Optional[int]) -> Optional[int]:
    return None if a is None or b is None else a * b


class PeCycleModel:
    """Cycle model: one :meth:`step` per rising clock edge.

    State mirrors the architectural stages of the contract:
      S0  : (valid, clear, a, b)                -- also the forwarding outputs
      Pm  : MUL_STAGES x (valid, clear, product)
      ACC : (acc, ovf, acc_valid)
    Control and ACC state reset to zero; data registers are not reset.
    """

    def __init__(self, cfg: PeConfig):
        self.cfg = cfg
        self.s0_v = 0
        self.s0_c = 0
        self.s0_a: Optional[int] = None
        self.s0_b: Optional[int] = None
        self.pv = [0] * cfg.mul_stages
        self.pc = [0] * cfg.mul_stages
        self.pp: List[Optional[int]] = [None] * cfg.mul_stages
        self.acc = 0
        self.ovf = False
        self.acc_v = 0

    # -- asynchronous reset: control + architectural state only -------------
    def reset(self) -> None:
        self.s0_v = self.s0_c = 0
        self.pv = [0] * self.cfg.mul_stages
        self.pc = [0] * self.cfg.mul_stages
        self.acc, self.ovf, self.acc_v = 0, False, 0

    def step(self, rst_n: int, en: int, clr: int, vld: int,
             a: Optional[int], b: Optional[int]) -> PeOutputs:
        """Apply one rising edge with the given inputs; return new outputs."""
        cfg = self.cfg
        gate = cfg.operand_gating
        m_last = cfg.mul_stages - 1
        if not rst_n:
            # Reset clears control + architectural state (asynchronously, so
            # it is already clear at this edge). Datapath registers are not
            # reset and keep their normal load rule, evaluated with the
            # cleared tokens: S0 loads on en & (vld | ~gate); product stages
            # load on en & ~gate (their valid tokens are 0).
            self.reset()
            if en:
                if not gate:
                    for m in range(m_last, 0, -1):
                        self.pp[m] = self.pp[m - 1]
                    self.pp[0] = _mul(self.s0_a, self.s0_b)
                if vld or not gate:
                    self.s0_a, self.s0_b = a, b
            return self.outputs()
        if not en:
            return self.outputs()           # stall: everything holds

        # ACC stage consumes the token leaving the last product stage.
        tv, tc, tp = self.pv[m_last], self.pc[m_last], self.pp[m_last]
        token = bool(tv or tc)
        if token:
            self.acc, self.ovf = accumulate_step(self.acc, self.ovf, bool(tc), bool(tv),
                                                 tp, cfg.acc_w, cfg.policy)
        self.acc_v = int(token)

        # Product stages shift, last first (each reads its predecessor's old value).
        for m in range(m_last, 0, -1):
            if self.pv[m - 1] or not gate:
                self.pp[m] = self.pp[m - 1]
            self.pv[m], self.pc[m] = self.pv[m - 1], self.pc[m - 1]
        if self.s0_v or not gate:
            self.pp[0] = _mul(self.s0_a, self.s0_b)
        self.pv[0], self.pc[0] = self.s0_v, self.s0_c

        # S0 capture.
        if vld or not gate:
            self.s0_a, self.s0_b = a, b
        self.s0_v, self.s0_c = int(bool(vld)), int(bool(clr))
        return self.outputs()

    def pipeline_steady(self, a: int, b: int) -> bool:
        """True if every stage holds the same valid, non-clear token (a*b)."""
        p = a * b
        return (self.s0_v == 1 and self.s0_c == 0 and self.s0_a == a and self.s0_b == b
                and all(self.pv) and not any(self.pc) and all(x == p for x in self.pp)
                and self.acc_v == 1)

    def fast_forward(self, n: int, a: int, b: int) -> PeOutputs:
        """Equivalent to ``n`` x step(1, 1, 0, 1, a, b) from a steady pipeline."""
        if not self.pipeline_steady(a, b):
            raise RuntimeError("fast_forward requires a steady pipeline")
        self.acc, self.ovf = accumulate_constant(self.acc, self.ovf, a * b, n,
                                                 self.cfg.acc_w, self.cfg.policy)
        return self.outputs()

    def outputs(self) -> PeOutputs:
        return PeOutputs(self.acc_v, self.acc, int(self.ovf), self.s0_v, self.s0_c,
                         self.s0_a, self.s0_b)


# ---------------------------------------------------------------------------
# Trace formatting (shared format with tb/tb_tensor_pe.sv)
# ---------------------------------------------------------------------------
def fmt(v: Optional[int]) -> str:
    return "x" if v is None else str(v)


def trace_fields(cycle: int, sid: int, o: PeOutputs) -> List[str]:
    return [str(cycle), str(sid), str(o.acc_valid), str(o.acc), str(o.ovf),
            str(o.valid_fwd), str(o.clear_fwd), fmt(o.a_fwd), fmt(o.b_fwd)]


# ---------------------------------------------------------------------------
# Output-stationary mesh reference (tb/tb_tensor_pe_mesh.sv)
# ---------------------------------------------------------------------------
def mesh_expected_tokens(stream: Sequence[dict], rows: int, cols: int, acc_w: int,
                         policy: int) -> List[List[List[Tuple[int, bool]]]]:
    """Per-PE token sequence for a wavefront stream.

    ``stream`` elements: {"valid": 0/1, "clear": 0/1, "a": [rows], "b": [cols]}.
    PE(i, j) sees element s as the pair (a[i], b[j]); every element with
    valid or clear set produces one token whose value is the prefix result.
    """
    res = [[[] for _ in range(cols)] for _ in range(rows)]
    for i in range(rows):
        for j in range(cols):
            acc, ovf = 0, False
            for el in stream:
                if not (el["valid"] or el["clear"]):
                    continue
                prod = el["a"][i] * el["b"][j] if el["valid"] else None
                acc, ovf = accumulate_step(acc, ovf, bool(el["clear"]), bool(el["valid"]),
                                           prod, acc_w, policy)
                res[i][j].append((acc, ovf))
    return res
