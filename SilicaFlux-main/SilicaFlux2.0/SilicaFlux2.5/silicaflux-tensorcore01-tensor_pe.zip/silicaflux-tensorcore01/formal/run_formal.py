#!/usr/bin/env python3
"""Yosys SAT proof of the tensor_pe arithmetic core.

The `ifdef FORMAL` block in rtl/tensor_pe.sv states, as immediate assertions,
an independent formulation of one accumulate step (exact 66-bit sum, explicit
range comparison, explicit policy) and of the multiplier (32-bit reference
product). This script proves them with `sat -prove-asserts` after
`expose -evert-dff`, which turns every register output into a free input:
the proof therefore covers ALL accumulator / product / token states, not only
reachable ones, for every input value.

Sanity: seeded bugs must make the same proof fail with a counterexample
(otherwise a passing proof could be vacuous).

Writes results/formal.json and results/formal_summary.md.
"""

import json
import os
import subprocess
import sys
import time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
PKG = os.path.join(ROOT, "rtl", "tensor_pe_pkg.sv")
PE = os.path.join(ROOT, "rtl", "tensor_pe.sv")
BUILD = os.path.join(ROOT, "build", "formal")

CONFIGS = [  # (A_W, B_W, ACC_W, MUL_STAGES, OVF_POLICY)
    (8, 8, 16, 1, 0), (8, 8, 16, 1, 1),
    (8, 8, 20, 1, 0), (8, 8, 20, 2, 1),
    (8, 8, 32, 1, 0), (8, 8, 32, 1, 1), (8, 8, 32, 2, 0),
    (8, 8, 40, 1, 0), (8, 8, 40, 1, 1),
    (8, 8, 64, 1, 0), (8, 8, 64, 1, 1),
    (4, 4, 12, 1, 1), (4, 6, 16, 1, 0),
]

MUTANTS = [
    ("saturation uses wrapped sign", (8, 8, 32, 1, 0),
     "(add_sum[ACC_W] ? ACC_MIN : ACC_MAX)", "(add_sum[ACC_W-1] ? ACC_MIN : ACC_MAX)"),
    ("overflow detection removed", (8, 8, 32, 1, 1),
     "assign add_ovf = add_sum[ACC_W] ^ add_sum[ACC_W-1];", "assign add_ovf = 1'b0;"),
    ("operand A zero-extended", (8, 8, 32, 1, 0),
     "{{(PROD_W-A_W){s0_a_q[A_W-1]}}, s0_a_q}", "{{(PROD_W-A_W){1'b0}}, s0_a_q}"),
    ("clear ignored when valid", (8, 8, 40, 1, 0),
     "assign acc_base = acc_in_clear ? '0   : acc_q;",
     "assign acc_base = (acc_in_clear & ~acc_in_valid) ? '0 : acc_q;"),
    ("overflow flag not sticky", (8, 8, 20, 1, 1),
     "assign ovf_d  = ovf_base | add_ovf;", "assign ovf_d  = add_ovf;"),
]


def prove(pe_path, cfg, tag):
    a_w, b_w, acc_w, ms, pol = cfg
    d = os.path.join(BUILD, tag)
    os.makedirs(d, exist_ok=True)
    script = (f"read_verilog -sv -formal -DFORMAL -DSYNTHESIS {PKG} {pe_path}; "
              f"chparam -set A_W {a_w} -set B_W {b_w} -set ACC_W {acc_w} "
              f"-set MUL_STAGES {ms} -set OVF_POLICY {pol} tensor_pe; "
              "hierarchy -check -top tensor_pe; proc; flatten; opt_clean; "
              "expose -evert-dff; opt_clean; select -assert-count 4 t:$assert; "
              "sat -prove-asserts -show-inputs")
    t = time.time()
    p = subprocess.run(["yosys", "-p", script], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       text=True, timeout=3600)
    with open(os.path.join(d, "yosys.log"), "w") as f:
        f.write(p.stdout)
    log = p.stdout
    proven = "SAT proof finished - no model found: SUCCESS!" in log
    refuted = "SAT proof finished - model found: FAIL!" in log
    size = next((l.strip() for l in log.splitlines() if l.startswith("Solving problem with")), "")
    return {"config": dict(zip(("A_W", "B_W", "ACC_W", "MUL_STAGES", "OVF_POLICY"), cfg)),
            "proven": proven, "refuted": refuted, "rc": p.returncode, "problem": size,
            "seconds": round(time.time() - t, 1)}


def main():
    os.makedirs(BUILD, exist_ok=True)
    ver = subprocess.run(["yosys", "-V"], stdout=subprocess.PIPE, text=True).stdout.strip()
    res = {"tool": ver, "proofs": [], "mutants": []}
    for cfg in CONFIGS:
        r = prove(PE, cfg, "cfg_" + "_".join(map(str, cfg)))
        res["proofs"].append(r)
        print(("PROVEN " if r["proven"] else "NOT PROVEN ") + str(r["config"]), r["seconds"], "s")
    src = open(PE).read()
    for i, (label, cfg, old, new) in enumerate(MUTANTS):
        assert src.count(old) == 1, label
        d = os.path.join(BUILD, f"mutant{i}")
        os.makedirs(d, exist_ok=True)
        mp = os.path.join(d, "tensor_pe.sv")
        with open(mp, "w") as f:
            f.write(src.replace(old, new))
        r = prove(mp, cfg, f"mutant{i}")
        r["mutant"] = label
        r["detected"] = r["refuted"]
        res["mutants"].append(r)
        print(("REFUTED (bug found) " if r["refuted"] else "NOT REFUTED ") + label)
    res["pass"] = all(p["proven"] for p in res["proofs"]) and all(m["detected"] for m in res["mutants"])
    os.makedirs(os.path.join(ROOT, "results"), exist_ok=True)
    with open(os.path.join(ROOT, "results", "formal.json"), "w") as f:
        json.dump(res, f, indent=1)
    L = ["# Formal (Yosys SAT) summary", "", f"Tool: {ver}", "",
         "Proof: `sat -prove-asserts` after `expose -evert-dff` (all register states free).", "",
         "| A_W | B_W | ACC_W | MUL_STAGES | OVF_POLICY | Result | Problem size | Time |",
         "|---|---|---|---|---|---|---|---|"]
    for p in res["proofs"]:
        c = p["config"]
        L.append(f"| {c['A_W']} | {c['B_W']} | {c['ACC_W']} | {c['MUL_STAGES']} | "
                 f"{'SAT' if c['OVF_POLICY'] == 0 else 'WRAP'} | "
                 f"{'PROVEN' if p['proven'] else 'NOT PROVEN'} | {p['problem']} | {p['seconds']} s |")
    L += ["", "## Seeded bugs (proof must fail)", "", "| Mutant | Config | Counterexample found |",
          "|---|---|---|"]
    for m in res["mutants"]:
        c = m["config"]
        L.append(f"| {m['mutant']} | ACC_W={c['ACC_W']} {'SAT' if c['OVF_POLICY'] == 0 else 'WRAP'} | "
                 f"{'yes' if m['detected'] else 'NO'} |")
    L += ["", f"**Overall: {'PASS' if res['pass'] else 'FAIL'}**"]
    with open(os.path.join(ROOT, "results", "formal_summary.md"), "w") as f:
        f.write("\n".join(L) + "\n")
    print("FORMAL:", "PASS" if res["pass"] else "FAIL")
    return 0 if res["pass"] else 1


if __name__ == "__main__":
    sys.exit(main())
