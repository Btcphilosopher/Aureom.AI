# SilicaFlux TensorCore 01: `tensor_pe` interface specification

Aureom.AI | SilicaFlux-HPC. RTL: `rtl/tensor_pe.sv`, `rtl/tensor_pe_pkg.sv`.
Integration reference: `rtl/tensor_pe_mesh.sv`.

This document is the contract. The Python reference model
(`model/tensor_pe_ref.py`) and the testbench scoreboard
(`tb/tb_tensor_pe.sv`) implement it independently of the RTL, and the
regression checks the RTL against both.

---

## 1. Function

For each accepted operand pair, in issue order:

```
acc_next = (clear ? 0 : acc_current) + signed(a) * signed(b)
```

| Quantity | Type | Baseline |
|---|---|---|
| `a`, `b` | signed two's complement, `A_W` / `B_W` bits | INT8: -128 … 127 |
| product | signed, `PROD_W = A_W + B_W` bits, **exact** | 16 bits: -16 256 … +16 384 |
| accumulator | signed, `ACC_W` bits | 32 (40 also verified) |

The INT8 corner case (-128) × (-128) = +16 384 = 2^14 needs 16 signed bits
(it does not fit in 15). The design keeps all 16 product bits and
sign-extends them, never truncates. Every one of the 65 536 INT8 × INT8
products is checked exhaustively in simulation, and the multiplier is proven
exact for all inputs (Yosys SAT, `formal/`).

### Signed-arithmetic discipline

Nothing in the datapath depends on context-determined expression sizing or
implicit signedness rules:

* Both operands are **explicitly sign-extended** to `PROD_W` by replicating the
  sign bit, then multiplied as signed `PROD_W × PROD_W → PROD_W`. Every operand
  of the expression is signed and already has the result width. Yosys reduces
  this to a signed 8×8→16 `$mul` cell (`results/synth_summary.md`).
* The product is **explicitly sign-extended** to `ACC_W+1` bits ("product
  alignment") and added to the explicitly sign-extended accumulator, giving the
  exact sum in `ACC_W+1` bits.
* Overflow is the exact test "the two MSBs of the exact sum differ".

## 2. Parameters

| Parameter | Default | Range | Meaning |
|---|---|---|---|
| `A_W`, `B_W` | 8, 8 | 2…16 | operand widths (INT8 baseline; INT4 is regression-tested as a generality check) |
| `ACC_W` | 32 | `A_W+B_W` … 64 | accumulator width (32 and 40 are the primary verified widths; 12, 16 and 20 are also regression-tested) |
| `MUL_STAGES` | 1 | 1…4 | product register stages (latency `MUL_STAGES + 2`) |
| `OVF_POLICY` | 0 | 0, 1 | `TPE_OVF_SATURATE` (0) or `TPE_OVF_WRAP` (1) |
| `OPERAND_GATING` | 1 | 0, 1 | 1: datapath registers load only with valid work (§9) |
| `MAX_K` | `MAX_EXACT_K` | 1 … `MAX_EXACT_K` | integrator's maximum supported accumulation length |
| `K_LIMIT_SEVERITY` | 1 | 0, 1, 2 | simulation-only check when an accumulation exceeds `MAX_K`: off, `$warning`, `$error` |

`MAX_EXACT_K = 2^(ACC_W - A_W - B_W + 1) - 1`
(`tensor_pe_pkg::tpe_max_exact_k`). See §6.

An unsupported configuration (any range above, or `MAX_K > MAX_EXACT_K`)
**stops elaboration** in Yosys, Icarus Verilog and Verilator. Verilator
stops even under `-Wno-fatal`. See the comment block in the RTL for the
per-tool mechanism, and `results/regression_summary.md` for the 8
must-reject and 3 must-accept cases, each checked in 4 tool modes.

## 3. Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| `clk_i` | in | 1 | clock, rising edge |
| `rst_ni` | in | 1 | active-low reset. **Asynchronous assertion**; deassertion must be synchronised to `clk_i` by the integrator |
| `enable_i` | in | 1 | common pipeline enable. 0 = stall: every register holds and inputs are not sampled |
| `clear_acc_i` | in | 1 | this cycle's command starts a new accumulation (§5) |
| `operand_a_i` | in | `A_W` signed | operand A |
| `operand_b_i` | in | `B_W` signed | operand B |
| `operand_valid_i` | in | 1 | (`operand_a_i`, `operand_b_i`) is a MAC pair |
| `acc_result_o` | out | `ACC_W` signed | accumulator, register output |
| `acc_valid_o` | out | 1 | result token (§4), register output |
| `overflow_o` | out | 1 | sticky overflow flag for the current accumulation (§6), register output |
| `a_fwd_o`, `b_fwd_o` | out | `A_W`, `B_W` signed | forwarded operands (S0 capture registers) |
| `valid_fwd_o`, `clear_fwd_o` | out | 1 each | forwarded tokens (S0 capture registers), aligned with `a_fwd_o` / `b_fwd_o` by construction |

All outputs are direct flip-flop outputs. There is no combinational path from
any input to any output.

## 4. Pipeline, latency, throughput, and the result-token protocol

```
            S0 CAPTURE        S1 MULTIPLY        [S1+ extra]       ACCUMULATE            OUT
 a,b,v,c ─► [a b v c] ──────► [p v c] ─────────► [p v c] ─ … ─►  sext ─► + ─► sat/wrap ─► [acc ovf tok] ─► acc_result_o
            │                  signed 8x8          MUL_STAGES-1      align   ▲   (1-cycle     acc_valid_o
            └─► a_fwd_o b_fwd_o valid_fwd_o clear_fwd_o (systolic forwarding)  └── recurrence)  overflow_o
```

* **Accepted command:** at a rising edge with `rst_ni=1`, `enable_i=1` and
  `operand_valid_i | clear_acc_i`.
* **Latency:** `L = MUL_STAGES + 2` cycles from the cycle a command is
  presented to the cycle its token is visible (3 cycles by default). Stall
  cycles do not count: the token appears `L` *enabled* cycles later.
* **Throughput:** one MAC per enabled cycle, sustained (II = 1), including
  across accumulation boundaries (clear-and-load, no bubble). This is possible
  because the only loop-carried dependency (accumulator → adder → accumulator)
  is closed within one cycle. No recurrence is split across pipeline registers.
* **Result token:** every accepted command produces exactly one
  `acc_valid_o` token. While the token is visible, `acc_result_o` and
  `overflow_o` are the running (prefix) result **including that command**. The
  final result of an accumulation is the value shown with the token of its last
  pair. A command killed by reset before its token appears produces no token.
* **Sampling rule:** a consumer in the same stall domain takes a token at a
  rising edge with `rst_ni=1`, `enable_i=1` and `acc_valid_o=1`. During a stall
  the token remains visible and is taken at the next enabled edge, exactly once.
* With back-to-back accumulations, the last token of accumulation *n* is
  visible for one enabled cycle, followed immediately by the first token of
  accumulation *n+1*. Capture it on its token (the mesh reference logs every
  token). A double-buffered drain register is an integration choice outside the PE.

Example A: back-to-back, `MUL_STAGES=1`. Outputs in cycle *k* are the
state after edge *k-1*. The table is generated by the reference model.

```
cycle                  0       1       2       3       4       5       6       7       8
enable_i               1       1       1       1       1       1       1       1       1
clear_acc_i            1       0       0       0       1       0       0       0       0
operand_valid_i        1       1       0       1       1       0       0       0       0
(a, b)               2,3     4,5       -    -1,7 -128,-128     -       -       -       -
valid_fwd_o            0       1       1       0       1       1       0       0       0
acc_valid_o            0       0       0       1       1       0       1       1       0
acc_result_o           0       0       0       6      26      26      19   16384   16384
```

Tokens: 6 (=2·3), 26 (+4·5), 19 (−1·7, final value of the first accumulation),
then 16384 (clear-and-load of (−128)·(−128), first value of the next one).

## 5. Clear and priority

Priority, highest first: **`rst_ni` > `enable_i` (stall) > `clear_acc_i` > accumulate.**

| Situation | Behaviour |
|---|---|
| `clear_acc_i=1`, `operand_valid_i=1` (same cycle) | **clear-and-load**: the pair becomes the first term of a new accumulation (`acc = a·b`, `overflow = 0`) |
| `clear_acc_i=1`, `operand_valid_i=0` | clear-only command: one token with `acc = 0`, `overflow = 0` |
| `clear_acc_i=1` while `enable_i=0` | ignored (not sampled) |
| products issued before the clear | land in the **old** accumulation: clear is a pipeline token aligned with its pair, not an immediate reset of the accumulator |
| reset | the accumulator is 0 and `overflow_o` is 0. A MAC after reset without a clear accumulates onto 0 (reset acts as a clear) |

Example C, from the reference model:

```
cycle                  0       1       2       3       4       5       6       7
clear_acc_i            1       1       0       1       0       0       0       0
operand_valid_i        1       0       1       1       1       0       0       0
(a, b)               5,5       -     1,1     2,2     3,3       -       -       -
acc_valid_o            0       0       0       1       1       1       1       1
acc_result_o           0       0       0      25       0       1       4      13
```

The 1·1 product issued the cycle before the clear+valid pair lands in the old
accumulation (token value 1). The new accumulation starts at 2·2 = 4.

## 6. Overflow policy and supported accumulation range

**Exactness guarantee.** Products lie in [−2^(PROD_W−2) + 2^(min(A_W,B_W)−1),
+2^(PROD_W−2)]. The positive extreme binds first, so every accumulation of up
to

```
MAX_EXACT_K = 2^(ACC_W − A_W − B_W + 1) − 1
```

terms since the last clear (or reset) is exact, whatever the operands.

| A_W×B_W | ACC_W | MAX_EXACT_K | Worst-case sum at K = MAX_EXACT_K |
|---|---|---|---|
| 8×8 | 16 | 1 | 16 384 |
| 8×8 | 20 | 31 | 507 904 |
| 8×8 | **32** | **131 071** | 2 147 467 264 (INT32_MAX − 16 383) |
| 8×8 | **40** | **33 554 431** | 549 755 797 504 |
| 8×8 | 48 | 8 589 934 591 | |

The formula is cross-checked three ways: an independent first-principles
derivation in the Python model for all A_W, B_W ∈ 2…8 and ACC_W up to 64; a
brute-force enumeration of every reachable K-term sum for small widths; and
in simulation by running exactly `MAX_EXACT_K` worst-case terms (no
overflow) and then one more (overflow) at ACC_W = 20, 32 and **40, which is
2^25 terms**.

**Beyond the bound, nothing overflows silently.**

* `overflow_o` rises with the token of the accumulate step at which the exact
  running sum first left [−2^(ACC_W−1), 2^(ACC_W−1)−1], and stays set (sticky)
  until the next clear (or reset). Detection is exact, not conservative: an
  accumulation that reaches exactly INT32_MAX or INT32_MIN does **not** set it
  (tested).
* `OVF_POLICY = SATURATE` (default): the accumulator clamps to ACC_MAX/ACC_MIN
  in the direction of the exact sum. Later steps continue from the clamped
  value (standard saturating accumulation), so after an overflow the value is
  the step-wise saturated sum. `overflow_o` tells the consumer it is not the
  exact sum.
* `OVF_POLICY = WRAP`: the accumulator holds the exact sum modulo 2^ACC_W.
  `overflow_o` still reports that an intermediate prefix was unrepresentable.

**Configuration and range checks.**

* Elaboration: `MAX_K` must satisfy 1 ≤ `MAX_K` ≤ `MAX_EXACT_K` ("unsupported
  accumulation range"). An integrator who needs a longer K must widen
  `ACC_W`.
* Simulation (`ifndef SYNTHESIS`):
  * `a_k_limit` fires once per accumulation when it exceeds `MAX_K` terms
    (`K_LIMIT_SEVERITY`: off / warning / error).
  * `a_exact_within_k` asserts that **no** overflow ever occurs within
    `MAX_EXACT_K` terms. This is a design invariant, not a usage check.
  * `a_prod_range` asserts the product register holds a legal product.
  * `a_ctrl_known` asserts control and accumulator state are never X after reset.

## 7. Stall (`enable_i`)

`enable_i=0` freezes every register: tokens, operands, products,
accumulator and outputs. Inputs are ignored, including `clear_acc_i` and
`operand_valid_i`. Because the whole PE freezes coherently, a single global
`enable_i` stalls a mesh without breaking wavefront alignment (§8). Tokens and
results are neither lost nor duplicated across a stall of any length (tested
from 1 to 200 cycles, alternating patterns, and stalls with a token at the
output).

```
cycle                  0       1       2       3       4       5       6       7
enable_i               1       1       0       0       1       1       1       1
clear_acc_i            1       0       1       0       0       0       0       0
operand_valid_i        1       1       1       1       1       0       0       0
(a, b)               1,1     2,2     9,9     9,9     3,3       -       -       -
acc_valid_o            0       0       0       0       0       1       1       1
acc_result_o           0       0       0       0       0       1       5      14
```

## 8. Reset

* Asynchronous, active-low assertion: tokens in flight are killed, and `acc = 0`,
  `overflow_o = 0`, `acc_valid_o = 0`, `valid_fwd_o = 0`, `clear_fwd_o = 0`.
  This happens **without a clock edge** (checked at every assertion in
  simulation).
* Deassertion must be synchronous to `clk_i`. A reset synchroniser is the
  integrator's job; none is included.
* Pure datapath registers (`a_fwd_o`/`b_fwd_o` and products) are not reset, and
  their load enables do not include `rst_ni`. This keeps reset out of the
  datapath. Their content is never consumed, because every token is 0 after
  reset. `a_fwd_o`/`b_fwd_o` are therefore undefined (X in 4-state simulation)
  until their first load.

## 9. Systolic integration

`a_fwd_o`, `b_fwd_o`, `valid_fwd_o` and `clear_fwd_o` are the S0 capture registers
themselves: one register per hop, no combinational path through a PE, and zero
extra flops for forwarding. Data and tokens are loaded by the same edge under
the same enable, so they stay aligned by construction.

Reference wiring (`rtl/tensor_pe_mesh.sv`, output-stationary,
`C[i][j] = Σ_k A[i][k]·B[k][j]`):

| PE(i,j) input | from |
|---|---|
| `operand_a_i`, `operand_valid_i`, `clear_acc_i` | west: PE(i,j−1) `a_fwd_o`, `valid_fwd_o`, `clear_fwd_o` (row injector at j = 0) |
| `operand_b_i` | north: PE(i−1,j) `b_fwd_o` (column injector at i = 0) |
| `enable_i`, `rst_ni`, `clk_i` | global |

Injection contract: stream element *s* (one k-step of one tile, or a
bubble) is presented at row *i* on enabled cycle *s+i* and at column *j* on
enabled cycle *s+j*, so it meets itself at PE(i,j) on enabled cycle *s+i+j*.
The mesh asserts in simulation that the B-side token arriving from the north
equals the A-side token arriving from the west (`a_wavefront_aligned`).

Verified (`results/regression_summary.md`): 4×4 and 3×5 meshes, 30–40
back-to-back tiles with K from 1 to 96, random wavefront bubbles, and random
global stalls with junk on every boundary input. Every token of every PE is
compared with an exact GEMM reference, including thousands of overflow tokens
in ACC_W = 20 meshes. Synthesis shows the 4×4 mesh's longest combinational path
equals one PE's, so no path crosses a PE boundary.

Not included: operand skew buffers, result drain or double-buffering, and
tiling control. `enable_i` and `rst_ni` are high-fanout nets in a large array
and need a buffered (or pipelined, skew-matched) distribution.

## 10. Power-aware behaviour

With `OPERAND_GATING=1`, the S0 operand registers load only on
`enable_i & operand_valid_i`, and each product stage only when its own valid
token is set. The accumulator loads only on a token. On idle cycles the
multiplier inputs and the product registers therefore do not switch. The
testbench checks this on every edge, and `results/regression_summary.md`
reports zero idle switching for every gated configuration against thousands
of events for `OPERAND_GATING=0`.

This is **register-enable operand isolation**. No integrated clock-gating
cell is instantiated, and **no physical clock gating is claimed**. An ASIC
flow's ICG insertion may convert these enables into gated clocks, and that
step would need its own verification. Measured cost of gating: within ±0.2 %
area on sky130 and a few LUTs on FPGA (`docs/SYNTHESIS_REPORT.md`).

## 11. Pipeline-depth trade-off

| Stage | Why it exists |
|---|---|
| S0 capture | Breaks every path from neighbours or external logic into the multiplier. It is the systolic hop register, needed for a mesh with no cross-PE combinational paths, and maps onto DSP input registers (Xilinx AREG/BREG absorbed). |
| S1 product register | Separates the multiplier from the accumulate loop. Maps onto the DSP M register (Xilinx MREG absorbed). |
| Product alignment | Pure wiring (sign extension), so it gets no register stage. |
| Accumulate (1 cycle) | The minimum for II = 1. Splitting the add across registers would create a recurrence hazard (it would need interleaved accumulators or carry-save accumulation). |
| Result visibility | The accumulator register drives the outputs directly. A separate output register would cost `ACC_W` flops and add nothing, since outputs are already flop outputs. |
| `MUL_STAGES > 1` | Optional extra product registers. They help only if the flow retimes them into the multiplier (DSP pipeline registers, or ASIC retiming). Yosys absorbs the second register as the Xilinx PREG, but the ECP5 flow does not retime, so ECP5 Fmax is unchanged (`docs/SYNTHESIS_REPORT.md`). |

Measured critical paths: on ECP5, S0 → MULT18X18D → product register (about
7 ns, 142–147 MHz post-route). On sky130 (logic-only estimate), the
accumulate loop: clear token → 33-bit ripple-carry chain → saturation mux
(about 6.2 ns). A production ASIC flow would infer a prefix adder there.

## 12. Limitations

* Verified at RTL in two simulators, with formal proof of the arithmetic core.
  No gate-level simulation, no ASIC static timing analysis, no
  place-and-route for the ASIC.
* Single clock domain. No reset synchroniser and no CDC logic are included.
* FPGA results come from open-source flows (Yosys/nextpnr). Vivado and Quartus
  results will differ.
* `A_W`/`B_W` other than 8 are regression-tested only as generality checks
  (INT4, and an asymmetric 4×6 configuration in formal).
