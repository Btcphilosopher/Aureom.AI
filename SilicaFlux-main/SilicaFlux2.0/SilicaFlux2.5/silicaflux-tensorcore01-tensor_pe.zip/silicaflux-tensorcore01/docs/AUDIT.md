# Repository audit (before implementation)

Repository: `btcphilosopher/aureom.ai`, branch `claude/hopeful-dijkstra-98c0fo`
(audited 2026-11-07; nothing was committed to it).

The repository is an archive store: 836 files at the top level, mostly
`.zip` deliveries, PDFs and images. SilicaFlux material lives in
`SilicaFlux-main/` as loose `.sf` files, which are SystemVerilog sources with a
`.sf` extension, plus about 60 nested zips. Every SilicaFlux archive was
extracted (1 692 HDL files, deduplicated by content hash) and searched for the
items the brief asked for. Each finding below states what was actually run,
not what a file claims.

## 1. Existing tensor / MAC RTL

| Component | Location | What it is | Status in this environment | Reused? |
|---|---|---|---|---|
| `tensor_unit` (the "4×4 tensor MAC") | `SilicaFlux-main/tensor_unit.sf` (930 lines) + `tb_tensor_unit.sf` | 20-stage, Booth radix-4, output-stationary **DIM×DIM matrix engine**: computes one complete `C = A·B` per issue with a fixed DIM-term reduction tree (`ACC_W = 2·OP_W + log2 DIM`) and narrows to `OUT_W` with a wrap/sat policy | Lints in Verilator 5.020 (warnings only, from its package). **Does not compile in Icarus 12**: `silicaflux_pkg.sf:1996` syntax error. | **No.** It has no running accumulator across K, so it is not a PE. Its conventions were adopted: `clk_i`/`rst_ni`, async-reset control flops with unreset data flops, named `p_*` processes, an explicit signed-type discipline, and an explicit wrap/saturate policy. |
| `sfx_mac` | `silicafluxai.zip` → `rtl/arithmetic/sfx_mac.sv` | single-cycle `acc <= clear ? a*b : acc + a*b` | `tb_sfx_mac` **PASS** (Icarus 12, run during audit) | **No.** Multiply and accumulate share one cycle (no pipeline). It wraps **silently** (no overflow indication). `clear` is ignored when `en=0`. |
| `sfx_pe` | `silicafluxai.zip` → `rtl/tensor/sfx_pe.sv` | weight-stationary systolic cell: `psum_out <= psum_in + act*w` | `tb_sfx_pe` **PASS** | **No.** Different dataflow (the partial sum flows; there is no local accumulator). No valid token, no overflow detection, single-cycle multiply+add. |
| `sfx_accumulator`, `sfx_saturate` | `silicafluxai.zip` → `rtl/arithmetic/` | register-file accumulator; combinational clamp | `tb_sfx_saturate` **PASS** | **Semantics reused, not the module.** The PE's saturate and wrap definitions match `python/models/datatypes.py::saturate_signed` / `wrap_signed`, but saturation here must sit inside the recurrence with exact overflow detection. A post-hoc clamp of a wrapped value would be wrong. |
| `mac_unit`, `sat_arith`, `array_multiplier`, `wallace_tree_multiplier` | `SilicaFlux-main/dsp_arithmetic.zip` | Q-format MAC (product shifted right by `FRAC_W`), pipeline-killing clear | `tb_mac_unit` **does not compile** in Icarus 12 (`fixed_point_pkg.sv:147`: non-constant part select) | **No.** It is fixed-point, not integer, and was not verified here. |
| `hpc_int32_mul` | `benchmarks-hpc-module10.zip` → `silicaflux-hpc-m03-vector-array/rtl/lane/` | INT32 low-half multiply plus a valid/id pipeline | not run | **No.** It is 32-bit, low half only, and has no accumulate. Its idea of an elaboration error via an undefined module was adopted for Icarus. |
| `sf_mul_lo_pipe`, `sf_tensor_unit_pipe`, `sf_reduce_tree` | `silicaflux-timinglab.zip` → `rtl/opt/` | timing-optimised variants of the core units | not run | **No.** |

## 2. Signed-arithmetic conventions found

* `tensor_unit.sf`: explicit `logic signed` typedefs per quantity; exact
  accumulation followed by explicit narrowing; overflow policy as an enum
  (`TU_OVF_WRAP`/`TU_OVF_SAT`).
* silicaflux-ai `docs/DATATYPES_AND_PRECISION.md`: wraparound only where
  hardware wraps, saturation only where a value is deliberately narrowed, and
  never conflated. That repository's MAC still wraps without any flag. This PE
  keeps the separation and adds the missing overflow indication.
* Size casts (`ACC_WIDTH'(product)`) were used for sign extension in
  silicaflux-ai. This PE uses explicit sign-bit replication in RTL instead (per
  the brief), and keeps cast-based sign extension for the independent
  formal reference only.

## 3. Packages

* `silicaflux_pkg.sf` (2 081 lines): 64-bit core/ISA package with no tensor PE
  types. It **fails to parse in Icarus 12** (line 1996) **and in Yosys 0.33**
  (first error at line 1391; it also uses `return`, which 0.33 rejects). It is
  not imported. `tensor_pe_pkg.sv` is self-contained and elaborates in all
  three tools.
* Also present: `fixed_point_pkg.sv` (dsp_arithmetic), `hpc_vector_pkg.sv`,
  `silicaflux_ml_pkg.sv`, `sftc_pkg.sv`. None are relevant to an INT8 MAC.

## 4. Vector engine

`SilicaFlux-main/vector_engine (1).sf` and `SilicaFlux2.5/vector_engine.sf`
(SIMD ALU with dot product and reduce), and `hpc_vector_lane.sv` /
`hpc_vector_array.sv` (m02/m03 deliveries). They share the core's clock/reset
style. No reusable INT8 MAC primitive was found in them.

## 5. Clock / reset conventions

Two conventions coexist:

| Lineage | Clock / reset names | Reset style |
|---|---|---|
| SilicaFlux core (`tensor_unit`, `vector_engine`, HPC modules) | `clk_i`, `rst_ni` | **asynchronous** active-low on control/valid flops; datapath flops unreset |
| silicaflux-ai (`sfx_*`) | `clk`, `rst_n` | **synchronous** active-low |

The brief specifies `clk_i`/`rst_ni`, so the PE follows the core lineage.

## 6. Verification infrastructure

* silicaflux-ai: Icarus 12, self-checking SV testbenches, Python golden models.
  Its `docs/TOOLING.md` documents Icarus limitations (no concurrent assertions,
  unpacked-array ports), which is why immediate assertions are used here.
* timinglab / testcore: Yosys and `read_slang` flows, formal directories
  (`formal verification.zip`, `formal/*.ys`).
* None of these tools was installed in this environment. Icarus 12.0,
  Verilator 5.020 and Yosys 0.33 were installed from Ubuntu packages, and
  nextpnr-ecp5 0.11.1 from PyPI (YoWASP).

## 7. Synthesis scripts

* `silicaflux/synth/vivado/synth.tcl` (Arty A7-100T) and
  `synth/quartus/synth.tcl` (DE10-Nano), with a 100 MHz `silicaflux.sdc`.
  Vivado and Quartus are not available here.
* timinglab `reports/runs/<pdk>/<module>/synth.ys` for sky130hd, gf180mcu and
  ihp-sg13g2. These reference liberty files under `/opt/tl/...`, which are absent
  here.
* testcore `third_party/pdk/sky130_fd_sc_hd__tt_025C_1v80.lib` (Apache-2.0,
  SHA-256 verified). It was copied into `third_party/` and used for the ASIC run.

## 8. Tool defects found during the audit and implementation

These directly affect how "verified" claims in this repository should be read:

1. **Icarus 12 silently ignores `$error` in generate blocks**, at both compile
   time and run time. Width checks written that way are **not enforced** under
   the silicaflux-ai Icarus flow. Confirmed: `sfx_mac` with an illegal
   `ACC_WIDTH=8` compiles and runs in Icarus with no message (rc 0).
2. **Verilator 5.020 reports an elaboration `$error`/`$fatal` as a warning**
   (`USERERROR`/`USERFATAL`), so under `-Wno-fatal` such checks are bypassed.
3. **Yosys 0.33** rejects `return` in functions, 2-D packed arrays, and
   `import` in a module header. Its `$fatal` in a generate block fires even when
   the branch is not taken.
4. **Icarus 12 `$isunknown()` returns 1 for any concatenation**, even a fully
   known one (minimal repro, checked against Verilator).

`tensor_pe` works around all four. Each configuration check is enforced in
every tool, confirmed by the negative tests in `results/regression_summary.md`.

## 9. Conclusion

No existing module provides a pipelined, valid-tokenised, overflow-reporting
INT8 PE suitable for mesh replication, and the only candidate that verifies here
(`sfx_mac`) fails the brief's "do not silently overflow" requirement. A new
`tensor_pe` was therefore implemented. It reuses the conventions and arithmetic
semantics above, and keeps existing repository files untouched.
