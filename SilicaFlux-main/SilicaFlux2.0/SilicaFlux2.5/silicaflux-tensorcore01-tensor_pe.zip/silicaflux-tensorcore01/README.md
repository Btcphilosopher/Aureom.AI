# SilicaFlux TensorCore 01: synthesizable INT8 tensor processing element

Aureom.AI | SilicaFlux-HPC

`tensor_pe` is the fundamental processing element of the SilicaFlux TensorCore:
a pipelined, synthesizable, signed INT8 × INT8 multiply-accumulate engine with
a 32-bit (or 40-bit) accumulator, built for replication in a systolic mesh.

```
acc_next = (clear ? 0 : acc_current) + signed(a) * signed(b)
```

* **One MAC per cycle, sustained**, including across accumulation
  boundaries (pipeline-aligned clear-and-load; no bubble). Latency is
  `MUL_STAGES + 2` cycles (3 by default).
* **Exact** for any accumulation of up to `2^(ACC_W-15) - 1` INT8 products:
  131 071 at ACC_W=32, 33 554 431 at ACC_W=40. Configurations that claim more
  are rejected at elaboration.
* **Never overflows silently.** A sticky `overflow_o` with exact detection,
  plus a selectable policy (saturate or wrap).
* **Mesh-ready.** Registered forwarding of A, B, valid and clear (one register per
  hop, no cross-PE combinational paths), a common stall enable, and an
  output-stationary mesh reference.
* **Power-aware.** Valid-qualified register enables (operand isolation). The
  multiplier inputs and product registers do not switch on idle cycles. No ICG
  cell is instantiated and no physical clock gating is claimed.

## Layout

| Path | Contents |
|---|---|
| `rtl/tensor_pe.sv` | the PE (primary source) |
| `rtl/tensor_pe_pkg.sv` | shared package: widths, policy encodings, `tpe_max_exact_k()` |
| `rtl/tensor_pe_mesh.sv` | output-stationary ROWS×COLS mesh (integration reference) |
| `model/tensor_pe_ref.py` | independent Python integer reference (arithmetic + cycle model + GEMM) |
| `tests/test_ref_model.py` | reference-model self-tests, incl. brute-force max-K bound |
| `tb/tb_tensor_pe.sv`, `tb/scenarios.py` | PE testbench (trace + scoreboard + monitors) and scenario generator |
| `tb/tb_tensor_pe_mesh.sv`, `tb/mesh_scenarios.py` | mesh integration testbench and stimulus |
| `scripts/run_regression.py` | full regression → `results/regression_summary.md`, `.json` |
| `formal/run_formal.py` | Yosys SAT proof of the arithmetic core → `results/formal_summary.md` |
| `synth/run_synth.py` | synthesis smoke tests → `results/synth_summary.md`, `.json` |
| `docs/INTERFACE_SPEC.md` | **interface and behaviour contract** |
| `docs/VERIFICATION_REPORT.md` | verification plan, traceability, results, bugs found |
| `docs/SYNTHESIS_REPORT.md` | FPGA and ASIC synthesis results |
| `docs/AUDIT.md` | repository audit performed before implementation |
| `third_party/` | sky130_fd_sc_hd liberty (Apache-2.0) for the ASIC run |

## Running

Requirements: Python 3.9+ (stdlib only), Icarus Verilog 12, Verilator 5,
Yosys 0.33. Optional: nextpnr-ecp5 for ECP5 place-and-route
(`pip install yowasp-nextpnr-ecp5` works).

```bash
make model      # reference-model self-tests
make lint       # Verilator -Wall, Icarus -Wall, Yosys check
make quick      # regression without the 2^25-term runs and mutants (~1.5 min)
make regress    # full regression (~3-4 min on 4 cores)
make formal     # SAT proof of accumulate step + multiplier, and seeded-bug refutation
make synth      # Yosys generic / xc7 / ECP5 + nextpnr / iCE40 / sky130
```

## Instantiation

```systemverilog
tensor_pe #(
  .ACC_W          (32),                               // 40 for K up to 33 554 431
  .MUL_STAGES     (1),
  .OVF_POLICY     (tensor_pe_pkg::TPE_OVF_SATURATE),
  .OPERAND_GATING (1'b1)
) u_pe (
  .clk_i, .rst_ni, .enable_i, .clear_acc_i,
  .operand_a_i, .operand_b_i, .operand_valid_i,
  .acc_result_o, .acc_valid_o, .overflow_o,
  .a_fwd_o, .b_fwd_o, .valid_fwd_o, .clear_fwd_o
);
```

Results are summarised in `docs/VERIFICATION_REPORT.md` and
`docs/SYNTHESIS_REPORT.md`. The raw generated summaries are in `results/`.
