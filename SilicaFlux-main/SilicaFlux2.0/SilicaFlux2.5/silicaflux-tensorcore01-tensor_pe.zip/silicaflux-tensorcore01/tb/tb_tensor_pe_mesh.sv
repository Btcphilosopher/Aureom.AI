// =============================================================================
//  SilicaFlux TensorCore 01  ::  tb_tensor_pe_mesh
//  Systolic-integration test: rtl/tensor_pe_mesh.sv (ROWS x COLS tensor_pe)
// -----------------------------------------------------------------------------
//  tb/mesh_scenarios.py precomputes, for every cycle, the boundary inputs of
//  the mesh: wavefront-skewed A rows and B columns of several back-to-back
//  GEMM tiles (clear on k = 0), random wavefront bubbles, and random global
//  stalls during which every boundary input (including valid/clear) is
//  driven with junk.  One line per cycle:
//      rst_n enable  v[0..ROWS-1]  c[0..ROWS-1]  a[0..ROWS-1]  b[0..COLS-1]
//  Every consumed acc_valid_o token of every PE is logged
//      TOK cycle i j acc ovf
//  and compared offline with the Python reference (per-PE prefix results of
//  each tile, model/tensor_pe_ref.py::mesh_expected_tokens).
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_tensor_pe_mesh;

  parameter int unsigned ROWS           = 4;
  parameter int unsigned COLS           = 4;
  parameter int unsigned A_W            = 8;
  parameter int unsigned B_W            = 8;
  parameter int unsigned ACC_W          = 32;
  parameter int unsigned MUL_STAGES     = 1;
  parameter int unsigned OVF_POLICY     = 0;
  parameter bit          OPERAND_GATING = 1'b1;

  logic clk_i = 1'b0;
  always #5 clk_i = ~clk_i;

  logic                       rst_ni   = 1'b0;
  logic                       enable_i = 1'b0;
  logic [ROWS*A_W-1:0]        west_a_i = '0;
  logic [ROWS-1:0]            west_valid_i = '0, west_clear_i = '0;
  logic [COLS*B_W-1:0]        north_b_i = '0;
  logic [ROWS*COLS*ACC_W-1:0] acc_result_o;
  logic [ROWS*COLS-1:0]       acc_valid_o, overflow_o;
  logic [ROWS*A_W-1:0]        east_a_o;
  logic [ROWS-1:0]            east_valid_o, east_clear_o;
  logic [COLS*B_W-1:0]        south_b_o;
  logic [COLS-1:0]            south_valid_o;

  tensor_pe_mesh #(
    .ROWS(ROWS), .COLS(COLS), .A_W(A_W), .B_W(B_W), .ACC_W(ACC_W),
    .MUL_STAGES(MUL_STAGES), .OVF_POLICY(OVF_POLICY), .OPERAND_GATING(OPERAND_GATING),
    .K_LIMIT_SEVERITY(0)
  ) dut (
    .clk_i(clk_i), .rst_ni(rst_ni), .enable_i(enable_i),
    .west_a_i(west_a_i), .west_valid_i(west_valid_i), .west_clear_i(west_clear_i),
    .north_b_i(north_b_i),
    .acc_result_o(acc_result_o), .acc_valid_o(acc_valid_o), .overflow_o(overflow_o),
    .east_a_o(east_a_o), .east_valid_o(east_valid_o), .east_clear_o(east_clear_o),
    .south_b_o(south_b_o), .south_valid_o(south_valid_o)
  );

  string  stim_file, tok_file;
  integer fd, td, st, r_rst, r_en, val;
  longint cyc = 0, n_tok = 0;
  int     x_errors = 0;
  logic signed [ACC_W-1:0] acc_ij;

  initial begin
    if (!$value$plusargs("STIM=%s", stim_file)) begin
      $display("MESH_RESULT: FAIL (no +STIM)");
      $finish;
    end
    if (!$value$plusargs("TOKENS=%s", tok_file)) tok_file = "tokens.txt";
    fd = $fopen(stim_file, "r");
    td = $fopen(tok_file, "w");
    $display("MESH_CONFIG ROWS=%0d COLS=%0d ACC_W=%0d MUL_STAGES=%0d OVF_POLICY=%0d OPERAND_GATING=%0d",
             ROWS, COLS, ACC_W, MUL_STAGES, OVF_POLICY, OPERAND_GATING);
    st = $fscanf(fd, "%d %d", r_rst, r_en);
    while (st == 2) begin
      @(negedge clk_i);
      // consume tokens visible now if the coming edge is enabled
      if (r_rst != 0 && r_en != 0) begin
        for (int i = 0; i < ROWS; i++) begin
          for (int j = 0; j < COLS; j++) begin
            if (acc_valid_o[i*COLS+j] === 1'b1) begin
              acc_ij = acc_result_o[(i*COLS+j)*ACC_W +: ACC_W];
              $fwrite(td, "TOK %0d %0d %0d %0d %0d\n", cyc, i, j, acc_ij, overflow_o[i*COLS+j]);
              n_tok++;
            end else if (acc_valid_o[i*COLS+j] !== 1'b0 && rst_ni === 1'b1) begin
              x_errors++;
            end
          end
        end
      end
      rst_ni   = (r_rst != 0);
      enable_i = (r_en != 0);
      for (int i = 0; i < ROWS; i++) begin st = $fscanf(fd, "%d", val); west_valid_i[i] = val[0]; end
      for (int i = 0; i < ROWS; i++) begin st = $fscanf(fd, "%d", val); west_clear_i[i] = val[0]; end
      for (int i = 0; i < ROWS; i++) begin st = $fscanf(fd, "%d", val); west_a_i[i*A_W +: A_W] = val[A_W-1:0]; end
      for (int j = 0; j < COLS; j++) begin st = $fscanf(fd, "%d", val); north_b_i[j*B_W +: B_W] = val[B_W-1:0]; end
      cyc++;
      st = $fscanf(fd, "%d %d", r_rst, r_en);
    end
    @(negedge clk_i);
    $fclose(td);
    $display("MESH_SUMMARY cycles=%0d tokens=%0d x_errors=%0d", cyc, n_tok, x_errors);
    $display("MESH_RESULT: %s", (x_errors == 0) ? "DONE" : "FAIL");
    $finish;
  end

endmodule

`default_nettype wire
