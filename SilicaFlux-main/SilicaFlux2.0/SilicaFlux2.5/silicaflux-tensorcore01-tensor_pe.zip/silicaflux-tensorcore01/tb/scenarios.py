"""Scenario generator for tb/tb_tensor_pe.sv.

Builds run-length stimulus records for a PE configuration and computes the
expected per-cycle trace with the independent cycle model
(model/tensor_pe_ref.py).

Record: (count, sid, rst_n, en, clr, vld, a, b, trace, xinv)

Suites
  normal : every directed and random scenario that fits a full per-cycle
           trace (for ACC_W <= 32 this includes the max-K boundary runs:
           ~0.5 M cycles at ACC_W = 32).
  long   : max-K positive/negative boundary runs for ACC_W > 32
           (2 x 2^25 terms at ACC_W = 40); the bulk of each run is untraced
           and checked by the in-TB scoreboard, the boundary region is traced
           and compared against the closed-form reference.
  xinj   : random MAC/stall traffic with X on the operands of every invalid
           cycle (Icarus only).
"""

from __future__ import annotations

import os
import random
import sys
from typing import Callable, Dict, List, Tuple

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "model"))

import tensor_pe_ref as ref  # noqa: E402

Record = Tuple[int, int, int, int, int, int, int, int, int, int]

SCENARIO_NAMES: Dict[int, str] = {
    1: "reset_and_idle",
    2: "corner_products_isolated",
    3: "corner_products_back_to_back",
    4: "exhaustive_products_k1",
    5: "exhaustive_products_running_sum",
    6: "max_positive_accumulation_and_overflow",
    7: "exact_acc_max_reach_then_overflow",
    8: "max_negative_accumulation_and_overflow",
    9: "exact_acc_min_reach_then_overflow",
    10: "random_signed_mac_with_stalls_and_clears",
    11: "back_to_back_tiles_ii1",
    12: "pipeline_stall_patterns",
    13: "clear_priority_and_alignment",
    14: "reset_during_activity",
    15: "random_extreme_operands_overflow_stress",
    16: "x_on_invalid_operands",
    17: "k_limit_check",
}


class Stim:
    def __init__(self, cfg: ref.PeConfig, rng: random.Random):
        self.cfg = cfg
        self.rng = rng
        self.recs: List[Record] = []
        self.sid = 0
        self.alo, self.ahi = ref.int_range(cfg.a_w)
        self.blo, self.bhi = ref.int_range(cfg.b_w)

    # -- primitives --------------------------------------------------------
    def junk_a(self) -> int:
        return self.rng.randint(self.alo, self.ahi)

    def junk_b(self) -> int:
        return self.rng.randint(self.blo, self.bhi)

    def cyc(self, rst=1, en=1, clr=0, vld=0, a=None, b=None, trace=1, xinv=0, count=1):
        a = self.junk_a() if a is None else a
        b = self.junk_b() if b is None else b
        assert self.alo <= a <= self.ahi and self.blo <= b <= self.bhi, (a, b)
        if count > 0:
            self.recs.append((count, self.sid, rst, en, clr, vld, a, b, trace, xinv))

    def mac(self, a, b, clr=0, trace=1):
        # Directed literals (e.g. 10, -9) are clamped into the operand range so
        # the same scenarios remain legal for narrow (e.g. INT4) configurations.
        a = min(max(a, self.alo), self.ahi)
        b = min(max(b, self.blo), self.bhi)
        self.cyc(clr=clr, vld=1, a=a, b=b, trace=trace)

    def idle(self, n=1, en=1, trace=1, xinv=0):
        for _ in range(n):
            self.cyc(en=en, vld=0, trace=trace, xinv=xinv)

    def drain(self):
        self.idle(self.cfg.latency + 2)

    def begin(self, sid: int):
        self.sid = sid

    # -- helpers -----------------------------------------------------------
    def corners(self):
        alo, ahi, blo, bhi = self.alo, self.ahi, self.blo, self.bhi
        c = [(0, 0), (1, 1), (-1, -1), (alo, blo), (alo, bhi), (ahi, blo), (ahi, bhi),
             (alo, 1), (1, blo), (-1, blo), (alo, -1), (ahi, -1), (0, blo), (alo, 0),
             (ahi, 1), (1, bhi), (alo + 1, blo + 1), (2, -2)]
        return [(a, b) for a, b in c if alo <= a <= ahi and blo <= b <= bhi]

    def operand(self, which: str, extreme_bias: float = 0.25) -> int:
        lo, hi = (self.alo, self.ahi) if which == "a" else (self.blo, self.bhi)
        if self.rng.random() < extreme_bias:
            return self.rng.choice([lo, lo + 1, -1, 0, 1, hi - 1, hi])
        return self.rng.randint(lo, hi)

    def decompose(self, r: int) -> List[Tuple[int, int]]:
        """Write r as a short sum of legal products with the sign of r."""
        terms = []
        if r >= 0:
            while r > 0:
                q = min(r // self.ahi, self.bhi)
                if q > 0:
                    terms.append((self.ahi, q))
                    r -= self.ahi * q
                else:
                    terms.append((r, 1))
                    r = 0
        else:
            while r < 0:
                q = min((-r) // (-self.alo), self.bhi)
                if q > 0:
                    terms.append((self.alo, q))
                    r -= self.alo * q
                else:
                    terms.append((r, 1))
                    r = 0
        return terms

    def extreme_pair(self, sign: int) -> Tuple[int, int]:
        """Operand pair achieving the most positive / most negative product."""
        if sign > 0:
            return self.alo, self.blo
        return (self.alo, self.bhi) if self.alo * self.bhi <= self.ahi * self.blo else (self.ahi, self.blo)


# ---------------------------------------------------------------------------
# Scenarios
# ---------------------------------------------------------------------------
def sc_reset_and_idle(s: Stim):
    s.begin(1)
    for _ in range(4):
        s.cyc(rst=0, en=s.rng.randint(0, 1), clr=s.rng.randint(0, 1), vld=s.rng.randint(0, 1))
    s.idle(8)
    s.idle(4, en=0)


def sc_corners(s: Stim):
    s.begin(2)
    for a, b in s.corners():
        s.mac(a, b, clr=1)
        s.drain()
    s.begin(3)
    for a, b in s.corners():
        s.mac(a, b, clr=1)
    for a, b in s.corners():                     # same pairs accumulated
        s.mac(a, b, clr=0)
    s.drain()


def sc_exhaustive(s: Stim):
    s.begin(4)
    for a in range(s.alo, s.ahi + 1):
        for b in range(s.blo, s.bhi + 1):
            s.mac(a, b, clr=1)
    s.drain()
    s.begin(5)
    first = True
    for a in range(s.alo, s.ahi + 1):
        for b in range(s.blo, s.bhi + 1):
            s.mac(a, b, clr=int(first))
            first = False
    s.drain()


def _long_run(s: Stim, a: int, b: int, n: int, traced: bool):
    """n consecutive valid terms of a*b (no clear); keep the boundary traced."""
    if n <= 0:
        return
    if traced:
        s.cyc(count=n, vld=1, a=a, b=b, trace=1)
    else:
        tail = min(n, 4 * s.cfg.latency)
        s.cyc(count=n - tail, vld=1, a=a, b=b, trace=0)
        s.cyc(count=tail, vld=1, a=a, b=b, trace=1)


def sc_max_positive(s: Stim, traced: bool):
    k = s.cfg.max_exact_k
    a, b = s.extreme_pair(+1)
    s.begin(6)
    s.idle(2)
    s.mac(a, b, clr=1)                           # term 1
    _long_run(s, a, b, k - 1, traced)            # terms 2..K   -> K * pmax, exact
    s.mac(a, b)                                  # term K+1     -> first overflow
    s.mac(a, b)                                  # stays overflowed
    na, nb = s.extreme_pair(-1)
    for _ in range(3):                           # post-overflow behaviour
        s.mac(na, nb)
    s.drain()
    s.mac(3, -5, clr=1)                          # recovery: clear resets the flag
    s.mac(7, 7)
    s.drain()

    s.begin(7)
    _, hi = ref.int_range(s.cfg.acc_w)
    s.mac(a, b, clr=1)
    _long_run(s, a, b, k - 1, traced)
    for ta, tb in s.decompose(hi - k * a * b):   # reach ACC_MAX exactly: no overflow
        s.mac(ta, tb)
    s.idle(s.cfg.latency + 1)
    s.mac(1, 1)                                  # ACC_MAX + 1 -> overflow
    s.drain()


def sc_max_negative(s: Stim, traced: bool):
    lo, _ = ref.int_range(s.cfg.acc_w)
    a, b = s.extreme_pair(-1)
    pmin = a * b
    kn = lo // pmin                               # largest n with n * pmin >= lo
    s.begin(8)
    s.idle(2)
    s.mac(a, b, clr=1)
    _long_run(s, a, b, kn - 1, traced)            # kn * pmin, exact (kn > MAX_EXACT_K)
    s.mac(a, b)                                   # overflow below ACC_MIN
    s.mac(a, b)
    pa, pb = s.extreme_pair(+1)
    for _ in range(3):
        s.mac(pa, pb)
    s.drain()
    s.mac(-9, 11, clr=1)
    s.drain()

    s.begin(9)
    s.mac(a, b, clr=1)
    _long_run(s, a, b, kn - 1, traced)
    for ta, tb in s.decompose(lo - kn * pmin):    # reach ACC_MIN exactly
        s.mac(ta, tb)
    s.idle(s.cfg.latency + 1)
    s.mac(-1, 1)                                  # ACC_MIN - 1 -> overflow
    s.drain()


def sc_random(s: Stim, sid: int, n: int, xinv: int = 0):
    s.begin(sid)
    s.mac(s.operand("a"), s.operand("b"), clr=1)
    i = 0
    while i < n:
        r = s.rng.random()
        if r < 0.01:                              # stall burst, junk on every input
            for _ in range(s.rng.randint(2, 40)):
                s.cyc(en=0, clr=s.rng.randint(0, 1), vld=s.rng.randint(0, 1), xinv=xinv)
                i += 1
            continue
        en = int(s.rng.random() < 0.85)
        if not en:
            s.cyc(en=0, clr=s.rng.randint(0, 1), vld=s.rng.randint(0, 1), xinv=xinv)
        else:
            vld = int(s.rng.random() < 0.8)
            clr = int(s.rng.random() < (0.02 if vld else 0.05))
            if vld:
                s.cyc(clr=clr, vld=1, a=s.operand("a"), b=s.operand("b"))
            else:
                s.cyc(clr=clr, vld=0, xinv=xinv)
        i += 1
    s.drain()


def sc_back_to_back(s: Stim, n_cycles: int):
    s.begin(11)
    done = 0
    while done < n_cycles:
        k = s.rng.choice([1, 1, 2, 3, 4, 5, 8, 12, 16, s.rng.randint(1, 64)])
        for t in range(k):
            s.mac(s.operand("a"), s.operand("b"), clr=int(t == 0))
        done += k
    s.drain()


def sc_stalls(s: Stim):
    s.begin(12)
    op = s.operand
    s.mac(10, 10, clr=1)
    for _ in range(10):                           # alternate MAC / 1-cycle stall
        s.mac(op("a"), op("b"))
        s.cyc(en=0, clr=1, vld=1)                 # ignored: stalled
    for _ in range(5):                            # stall with clear+valid asserted
        s.cyc(en=0, clr=1, vld=1)
    for _ in range(s.cfg.latency + 1):            # fill pipeline, then long stall
        s.mac(op("a"), op("b"))
    s.idle(50, en=0)
    s.cyc(en=0, clr=1, vld=0)                     # clear only during a stall: ignored
    s.mac(op("a"), op("b"))                       # continues the old accumulation
    for i in range(40):                           # enable 1010...
        if i % 2:
            s.cyc(en=0, vld=1, clr=s.rng.randint(0, 1))
        else:
            s.mac(op("a"), op("b"))
    for i in range(40):                           # enable 1100...
        if i % 4 >= 2:
            s.cyc(en=0, vld=s.rng.randint(0, 1))
        else:
            s.mac(op("a"), op("b"), clr=int(i % 8 == 0))
    for _ in range(s.cfg.latency):                # stall exactly while the last
        s.mac(op("a"), op("b"))                   # token sits at the output
    s.idle(200, en=0)
    s.drain()


def sc_clear_priority(s: Stim):
    s.begin(13)
    s.mac(5, 5, clr=1)                            # clear-and-load: 25
    s.cyc(clr=1, vld=0)                           # clear only: token, acc 0
    s.cyc(clr=1, vld=0)                           # consecutive clears
    s.mac(1, 1)                                   # accumulate onto 0
    s.mac(2, 2, clr=1)                            # in-flight 1*1 lands in OLD acc; new acc = 4
    s.mac(3, 3)                                   # 4 + 9
    s.cyc(clr=1, vld=0)
    s.mac(-4, 6)
    s.cyc(en=0, clr=1, vld=0)                     # clear during stall: ignored
    s.mac(2, 3)                                   # -24 + 6
    for _ in range(6):                            # K=1 tiles, every cycle
        s.mac(s.operand("a"), s.operand("b"), clr=1)
    s.drain()
    for _ in range(4):                            # clear+valid vs. stall interleave
        s.mac(s.operand("a"), s.operand("b"), clr=1)
        s.cyc(en=0, clr=0, vld=1)
        s.mac(s.operand("a"), s.operand("b"))
    s.drain()


def sc_reset(s: Stim):
    s.begin(14)
    op = s.operand
    s.mac(op("a"), op("b"), clr=1)
    for _ in range(s.cfg.latency + 2):            # pipeline full of tokens
        s.mac(op("a"), op("b"))
    s.cyc(rst=0, en=1, clr=1, vld=1)              # 1-cycle reset mid-stream
    s.idle(s.cfg.latency + 2)                     # no token may survive
    s.mac(3, 3)                                   # no clear: reset acts as a clear
    s.mac(4, 4)
    s.drain()
    s.mac(op("a"), op("b"), clr=1)
    s.mac(op("a"), op("b"))
    s.cyc(en=0, vld=1)                            # stalled with tokens in flight...
    s.cyc(rst=0, en=0, vld=1)                     # ...reset wins over the stall
    s.cyc(en=0, vld=1)
    s.idle(s.cfg.latency + 2)
    for _ in range(5):                            # multi-cycle reset, random inputs
        s.cyc(rst=0, en=s.rng.randint(0, 1), clr=s.rng.randint(0, 1), vld=s.rng.randint(0, 1))
    s.mac(-7, 8, clr=1)
    s.mac(op("a"), op("b"))
    s.cyc(rst=0, vld=1)                           # reset on the cycle after a MAC
    s.mac(2, -2)
    s.drain()


def sc_overflow_stress(s: Stim, n: int):
    s.begin(15)
    a_ext = [s.alo, s.ahi, -1, 1]
    b_ext = [s.blo, s.bhi, -1, 1]
    s.mac(s.alo, s.blo, clr=1)
    sign = 1
    for i in range(n):
        if s.rng.random() < 0.002:
            sign = -sign
        if s.rng.random() < 0.1:
            s.cyc(en=0, vld=1)
            continue
        if s.rng.random() < 0.05:
            s.idle(1)
            continue
        a = s.rng.choice(a_ext)
        b = s.rng.choice(b_ext)
        if (a * b > 0) != (sign > 0) and s.rng.random() < 0.85:
            b = -b if s.blo <= -b <= s.bhi else b
        s.mac(a, b, clr=int(s.rng.random() < 0.002))
    s.drain()


def build(cfg: ref.PeConfig, suite: str, seed: int = 2026) -> List[Record]:
    s = Stim(cfg, random.Random(seed))
    if suite == "normal":
        sc_reset_and_idle(s)
        sc_corners(s)
        sc_exhaustive(s)
        if cfg.acc_w <= 32:
            sc_max_positive(s, traced=True)
            sc_max_negative(s, traced=True)
        sc_random(s, 10, 20000)
        sc_back_to_back(s, 3000)
        sc_stalls(s)
        sc_clear_priority(s)
        sc_reset(s)
        sc_overflow_stress(s, 12000)
    elif suite == "quick":                      # mutation testing
        sc_reset_and_idle(s)
        sc_corners(s)
        sc_exhaustive(s)
        if cfg.acc_w <= 24:
            sc_max_positive(s, traced=True)
            sc_max_negative(s, traced=True)
        sc_random(s, 10, 4000)
        sc_back_to_back(s, 600)
        sc_stalls(s)
        sc_clear_priority(s)
        sc_reset(s)
        sc_overflow_stress(s, 3000)
    elif suite == "kcheck":                     # 2*MAX_K+8 MACs in one accumulation
        sc_reset_and_idle(s)
        s.begin(17)
        s.mac(1, 1, clr=1)
        s.cyc(count=2 * min(cfg.max_exact_k, 64) + 8, vld=1, a=1, b=1)
        s.drain()
    elif suite == "long":
        sc_reset_and_idle(s)
        sc_max_positive(s, traced=False)
        sc_max_negative(s, traced=False)
    elif suite == "xinj":
        sc_reset_and_idle(s)
        sc_random(s, 16, 8000, xinv=1)
        sc_reset(s)
    else:
        raise ValueError(suite)
    s.idle(2)
    return s.recs


def write_stim(recs: List[Record], path: str) -> None:
    with open(path, "w") as f:
        for r in recs:
            f.write(" ".join(str(x) for x in r) + "\n")


def expected_trace(cfg: ref.PeConfig, recs: List[Record], simulator: str) -> List[List[str]]:
    """Expected trace lines (field lists) for every traced cycle."""
    m = ref.PeCycleModel(cfg)
    out: List[List[str]] = []
    k = 0
    for (cnt, sid, rst, en, clr, vld, a, b, tr, xi) in recs:
        xa, xb = (None, None) if (xi and not vld and simulator == "icarus") else (a, b)
        steady_ok = (not tr and cnt > 4 * cfg.latency and rst and en and vld and not clr)
        if steady_ok:
            fill = cfg.latency + 1
            for _ in range(fill):
                m.step(rst, en, clr, vld, xa, xb)
            if m.pipeline_steady(a, b):
                m.fast_forward(cnt - fill, a, b)
                k += cnt
                continue
            todo = cnt - fill
            k += fill
        else:
            todo = cnt
        for _ in range(todo):
            o = m.step(rst, en, clr, vld, xa, xb)
            if tr:
                out.append(ref.trace_fields(k, sid, o))
            k += 1
    return out


def stats(recs: List[Record]) -> Dict[str, int]:
    cycles = sum(r[0] for r in recs)
    macs = sum(r[0] for r in recs if r[2] and r[3] and r[5])
    return {"cycles": cycles, "accepted_macs": macs}
