// =============================================================================
//  SilicaFlux TensorCore 01  ::  tb_tensor_pe
//  Stimulus-driven, self-checking testbench for rtl/tensor_pe.sv
// -----------------------------------------------------------------------------
//  Stimulus (+STIM=<file>) is produced by tb/scenarios.py: one run-length
//  record per line,
//      count sid rst_n enable clear valid a b trace xinv
//  applied for `count` consecutive cycles.  Inputs are driven at the falling
//  edge, so each record line defines the inputs seen by the next rising edge.
//
//  Three independent checks run on every cycle:
//    1. Trace (+TRACE=<file>): DUT outputs after each rising edge are written
//       for cycles with trace=1 and compared offline, field by field, with
//       the Python cycle model (model/tensor_pe_ref.py).
//    2. In-TB transaction scoreboard: every accepted command is queued with
//       its exact product; every consumed acc_valid_o token is checked
//       against a 128-bit exact running reference with explicit
//       saturate/wrap semantics, and its latency must be exactly
//       MUL_STAGES+2 enabled cycles.  This covers cycles that are not traced
//       (multi-million-cycle runs).
//    3. Monitors: X/Z on outputs, asynchronous reset assertion takes effect
//       without a clock edge, and (OPERAND_GATING=1) the multiplier operand
//       and product registers never switch on a cycle without valid work.
//
//  xinv=1 drives X on the operands of invalid cycles (Icarus only; Verilator
//  is two-state) to prove that invalid data never reaches the accumulator.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_tensor_pe;

  parameter int unsigned A_W              = 8;
  parameter int unsigned B_W              = 8;
  parameter int unsigned ACC_W            = 32;
  parameter int unsigned MUL_STAGES       = 1;
  parameter int unsigned OVF_POLICY       = 0;
  parameter bit          OPERAND_GATING   = 1'b1;
  parameter int unsigned K_LIMIT_SEVERITY = 1;
  parameter logic [63:0] MAX_K            = tensor_pe_pkg::tpe_max_exact_k(ACC_W, A_W, B_W);

  localparam int unsigned LAT    = MUL_STAGES + 2;
  localparam int unsigned PROD_W = A_W + B_W;
  localparam int          SBD    = 16;               // scoreboard depth > LAT

  // ---------------------------------------------------------------------------
  // DUT
  // ---------------------------------------------------------------------------
  logic clk_i = 1'b0;
  always #5 clk_i = ~clk_i;

  logic                    rst_ni          = 1'b0;
  logic                    enable_i        = 1'b0;
  logic                    clear_acc_i     = 1'b0;
  logic                    operand_valid_i = 1'b0;
  logic signed [A_W-1:0]   operand_a_i     = '0;
  logic signed [B_W-1:0]   operand_b_i     = '0;
  logic signed [ACC_W-1:0] acc_result_o;
  logic                    acc_valid_o, overflow_o, valid_fwd_o, clear_fwd_o;
  logic signed [A_W-1:0]   a_fwd_o;
  logic signed [B_W-1:0]   b_fwd_o;

  tensor_pe #(
    .A_W(A_W), .B_W(B_W), .ACC_W(ACC_W), .MUL_STAGES(MUL_STAGES),
    .OVF_POLICY(OVF_POLICY), .OPERAND_GATING(OPERAND_GATING),
    .MAX_K(MAX_K), .K_LIMIT_SEVERITY(K_LIMIT_SEVERITY)
  ) dut (
    .clk_i(clk_i), .rst_ni(rst_ni), .enable_i(enable_i), .clear_acc_i(clear_acc_i),
    .operand_a_i(operand_a_i), .operand_b_i(operand_b_i), .operand_valid_i(operand_valid_i),
    .acc_result_o(acc_result_o), .acc_valid_o(acc_valid_o), .overflow_o(overflow_o),
    .a_fwd_o(a_fwd_o), .b_fwd_o(b_fwd_o), .valid_fwd_o(valid_fwd_o), .clear_fwd_o(clear_fwd_o)
  );

  // ---------------------------------------------------------------------------
  // Counters
  // ---------------------------------------------------------------------------
  longint cyc         = 0;   // index of the rising edge the current inputs feed
  longint n_tokens    = 0;
  longint n_accepted  = 0;
  longint n_killed    = 0;   // accepted commands flushed by reset before their token
  longint en_cnt      = 0;   // enabled, non-reset rising edges so far
  int     errors      = 0;
  int     sb_errors   = 0;
  int     lat_errors  = 0;
  int     x_errors    = 0;
  int     gate_errors = 0;
  longint s0_idle_switch = 0;  // S0 operand register changed without valid work
  longint p_idle_switch  = 0;  // first product register changed without valid work
  longint rst_data_switch = 0; // unreset data register loaded while rst_ni was low
  int     async_rst_checks = 0;

  // ---------------------------------------------------------------------------
  // Scoreboard: queue of accepted commands + exact reference accumulator
  // ---------------------------------------------------------------------------
  logic   sb_c [SBD];
  logic   sb_v [SBD];
  longint sb_p [SBD];
  longint sb_e [SBD];
  int     sb_rd = 0, sb_wr = 0, sb_cnt = 0;

  logic signed [127:0] ref_acc = '0;
  logic                ref_ovf = 1'b0;
  logic signed [127:0] R_MAX, R_MIN;
  initial begin
    R_MAX = (128'sd1 <<< (ACC_W - 1)) - 128'sd1;
    R_MIN = -(128'sd1 <<< (ACC_W - 1));
  end

  task automatic sb_flush();
    n_killed = n_killed + sb_cnt;
    sb_rd = 0; sb_wr = 0; sb_cnt = 0;
    ref_acc = '0; ref_ovf = 1'b0;
  endtask

  task automatic sb_apply(input logic c, input logic v, input longint p);
    logic signed [127:0] exact;
    logic signed [ACC_W-1:0] wrapped;
    if (c) begin
      ref_acc = '0;
      ref_ovf = 1'b0;
    end
    if (v) begin
      exact = ref_acc + p;                         // p (signed longint) sign-extends
      if (exact > R_MAX || exact < R_MIN) begin
        ref_ovf = 1'b1;
        if (OVF_POLICY == 0) begin
          ref_acc = (exact > 0) ? R_MAX : R_MIN;
        end else begin
          wrapped = exact[ACC_W-1:0];
          ref_acc = wrapped;                       // signed -> sign-extends
        end
      end else begin
        ref_acc = exact;
      end
    end
  endtask

  // Called while the inputs for the next rising edge are applied.
  task automatic sb_edge(input int r, input int e, input int c, input int v);
    longint sa, sb;
    if (r == 0) begin
      sb_flush();
    end else if (e != 0) begin
      // 1) consumption of the token visible during this cycle
      if (acc_valid_o === 1'b1) begin
        if (sb_cnt == 0) begin
          $display("SB_ERROR cyc=%0d: acc_valid_o token with no accepted command", cyc);
          sb_errors++;
        end else begin
          sb_apply(sb_c[sb_rd], sb_v[sb_rd], sb_p[sb_rd]);
          if (acc_result_o !== ref_acc[ACC_W-1:0] || overflow_o !== ref_ovf) begin
            if (sb_errors < 20)
              $display("SB_ERROR cyc=%0d: acc=%0d ovf=%0b expected acc=%0d ovf=%0b",
                       cyc, acc_result_o, overflow_o, ref_acc, ref_ovf);
            sb_errors++;
          end
          if (en_cnt - sb_e[sb_rd] != longint'(LAT)) begin
            if (lat_errors < 20)
              $display("LAT_ERROR cyc=%0d: token latency %0d enabled cycles, expected %0d",
                       cyc, en_cnt - sb_e[sb_rd], LAT);
            lat_errors++;
          end
          sb_rd = (sb_rd + 1) % SBD;
          sb_cnt--;
          n_tokens++;
        end
      end else if (acc_valid_o !== 1'b0) begin
        $display("X_ERROR cyc=%0d: acc_valid_o is %b", cyc, acc_valid_o);
        x_errors++;
      end
      // 2) acceptance of the command applied now
      if (v != 0 || c != 0) begin
        if (sb_cnt == SBD) begin
          $display("SB_ERROR cyc=%0d: scoreboard overflow", cyc);
          sb_errors++;
        end else begin
          sa = operand_a_i;                        // signed -> sign-extends
          sb = operand_b_i;
          sb_c[sb_wr] = (c != 0);
          sb_v[sb_wr] = (v != 0);
          sb_p[sb_wr] = (v != 0) ? sa * sb : 64'sd0;
          sb_e[sb_wr] = en_cnt;
          sb_wr = (sb_wr + 1) % SBD;
          sb_cnt++;
          n_accepted++;
        end
      end
      en_cnt++;
    end
  endtask

  // ---------------------------------------------------------------------------
  // Gating monitor state (values captured before each rising edge)
  // ---------------------------------------------------------------------------
  logic                  prev_valid_work_s0 = 1'b0;   // edge loaded a valid operand pair
  logic                  prev_valid_work_p  = 1'b0;   // edge loaded a valid product
  logic                  prev_in_reset      = 1'b0;   // edge happened with rst_ni low
  logic signed [A_W-1:0] snap_s0_a;
  logic signed [B_W-1:0] snap_s0_b;
  logic [PROD_W-1:0]     snap_p0;
  logic                  snap_valid = 1'b0;

  task automatic gate_check();
    logic s0_changed, p_changed;
    s0_changed = snap_valid && ((dut.s0_a_q !== snap_s0_a) || (dut.s0_b_q !== snap_s0_b));
    p_changed  = snap_valid && (dut.pm_p_q[PROD_W-1:0] !== snap_p0);
    if ((s0_changed || p_changed) && prev_in_reset) begin
      // Data registers are not reset and their enables do not include rst_ni
      // (no reset in the datapath); valid tokens are held at 0 during reset,
      // so anything captured here is never consumed.
      rst_data_switch++;
    end else if (s0_changed && !prev_valid_work_s0) begin
      s0_idle_switch++;
      if (OPERAND_GATING) begin
        if (gate_errors < 10)
          $display("GATE_ERROR cyc=%0d: S0 operand register switched without valid work", cyc);
        gate_errors++;
      end
    end
    if (p_changed && !prev_valid_work_p && !prev_in_reset) begin
      p_idle_switch++;
      if (OPERAND_GATING) begin
        if (gate_errors < 10)
          $display("GATE_ERROR cyc=%0d: product register switched without valid work", cyc);
        gate_errors++;
      end
    end
  endtask

  // ---------------------------------------------------------------------------
  // Main stimulus loop
  // ---------------------------------------------------------------------------
  string  stim_file, trace_file;
  integer fd, td, nread;
  integer r_cnt, r_sid, r_rst, r_en, r_clr, r_vld, r_a, r_b, r_tr, r_xi;
  integer prev_trace = 0, prev_sid = 0;

  task automatic write_trace(input longint k, input integer sid);
    $fwrite(td, "%0d %0d %0d %0d %0d %0d %0d %0d %0d\n", k, sid, acc_valid_o, acc_result_o,
            overflow_o, valid_fwd_o, clear_fwd_o, a_fwd_o, b_fwd_o);
  endtask

  task automatic x_check();
    // reduction-XOR, not $isunknown (Icarus 12 $isunknown bug on concatenations)
    if (rst_ni === 1'b1 &&
        (^{acc_valid_o, acc_result_o, overflow_o, valid_fwd_o, clear_fwd_o}) === 1'bx) begin
      if (x_errors < 10) $display("X_ERROR cyc=%0d: unknown value on a control/result output", cyc);
      x_errors++;
    end
  endtask

  initial begin
    if (!$value$plusargs("STIM=%s", stim_file)) begin
      $display("TPE_RESULT: FAIL (no +STIM=<file>)");
      $finish;
    end
    if (!$value$plusargs("TRACE=%s", trace_file)) trace_file = "trace.txt";
    fd = $fopen(stim_file, "r");
    td = $fopen(trace_file, "w");
    if (fd == 0 || td == 0) begin
      $display("TPE_RESULT: FAIL (cannot open stimulus/trace file)");
      $finish;
    end
    $display("TPE_CONFIG A_W=%0d B_W=%0d ACC_W=%0d MUL_STAGES=%0d OVF_POLICY=%0d OPERAND_GATING=%0d LAT=%0d",
             A_W, B_W, ACC_W, MUL_STAGES, OVF_POLICY, OPERAND_GATING, LAT);

    nread = $fscanf(fd, "%d %d %d %d %d %d %d %d %d %d",
                    r_cnt, r_sid, r_rst, r_en, r_clr, r_vld, r_a, r_b, r_tr, r_xi);
    while (nread == 10) begin
      for (int n = 0; n < r_cnt; n++) begin
        @(negedge clk_i);
        // ---- observe the state produced by the previous rising edge ----
        if (prev_trace != 0) write_trace(cyc - 1, prev_sid);
        x_check();
        gate_check();

        // ---- apply the inputs for the next rising edge ----
        if (r_rst == 0 && rst_ni === 1'b1) begin
          // asynchronous assertion: state must clear before any clock edge
          rst_ni = 1'b0;
          #1;
          if (acc_valid_o !== 1'b0 || acc_result_o !== '0 || overflow_o !== 1'b0 ||
              valid_fwd_o !== 1'b0 || clear_fwd_o !== 1'b0) begin
            $display("ERROR cyc=%0d: asynchronous reset did not clear state before the clock edge", cyc);
            errors++;
          end
          async_rst_checks++;
        end
        rst_ni          = (r_rst != 0);
        enable_i        = (r_en  != 0);
        clear_acc_i     = (r_clr != 0);
        operand_valid_i = (r_vld != 0);
        operand_a_i     = r_a[A_W-1:0];
        operand_b_i     = r_b[B_W-1:0];
`ifndef VERILATOR
        if (r_xi != 0 && r_vld == 0) begin
          operand_a_i = 'x;
          operand_b_i = 'x;
        end
`endif
        // gating monitor: what the coming edge is allowed to load
        snap_s0_a          = dut.s0_a_q;
        snap_s0_b          = dut.s0_b_q;
        snap_p0            = dut.pm_p_q[PROD_W-1:0];
        snap_valid         = 1'b1;
        prev_valid_work_s0 = (r_rst != 0) && (r_en != 0) && (r_vld != 0);
        prev_valid_work_p  = (r_rst != 0) && (r_en != 0) && (dut.s0_valid_q === 1'b1);
        prev_in_reset      = (r_rst == 0);

        sb_edge(r_rst, r_en, r_clr, r_vld);

        prev_trace = r_tr;
        prev_sid   = r_sid;
        cyc++;
      end
      nread = $fscanf(fd, "%d %d %d %d %d %d %d %d %d %d",
                      r_cnt, r_sid, r_rst, r_en, r_clr, r_vld, r_a, r_b, r_tr, r_xi);
    end

    @(negedge clk_i);
    if (prev_trace != 0) write_trace(cyc - 1, prev_sid);
    x_check();
    gate_check();
    $fclose(td);
    $fclose(fd);

    errors = errors + sb_errors + lat_errors + x_errors + gate_errors;
    $display("TPE_SUMMARY cycles=%0d accepted=%0d tokens=%0d killed_by_reset=%0d in_flight=%0d errors=%0d sb=%0d lat=%0d x=%0d gate=%0d s0_idle_switch=%0d p_idle_switch=%0d rst_data_switch=%0d async_rst_checks=%0d final_acc=%0d final_ovf=%0d",
             cyc, n_accepted, n_tokens, n_killed, sb_cnt, errors, sb_errors, lat_errors, x_errors,
             gate_errors, s0_idle_switch, p_idle_switch, rst_data_switch, async_rst_checks,
             acc_result_o, overflow_o);
    if (errors == 0) $display("TPE_RESULT: PASS");
    else             $display("TPE_RESULT: FAIL");
    $finish;
  end

endmodule

`default_nettype wire
