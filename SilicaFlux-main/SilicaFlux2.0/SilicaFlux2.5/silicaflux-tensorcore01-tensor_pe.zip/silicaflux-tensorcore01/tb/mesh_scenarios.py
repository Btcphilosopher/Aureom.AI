"""Stimulus + expected tokens for tb/tb_tensor_pe_mesh.sv.

Builds a stream of back-to-back GEMM tiles C_t = A_t (ROWS x K_t) * B_t
(K_t x COLS), inserts random wavefront bubbles, then schedules the
wavefront-skewed boundary inputs cycle by cycle with random global stalls
(junk on every boundary input while stalled).
"""

from __future__ import annotations

import os
import random
import sys
from typing import Dict, List, Tuple

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "model"))

import tensor_pe_ref as ref  # noqa: E402


def build(cfg: ref.PeConfig, rows: int, cols: int, n_tiles: int, seed: int,
          overflow_tiles: bool = False):
    rng = random.Random(seed)
    alo, ahi = ref.int_range(cfg.a_w)
    blo, bhi = ref.int_range(cfg.b_w)

    def val(lo, hi, extreme):
        if extreme or rng.random() < 0.2:
            return rng.choice([lo, lo + 1, -1, 0, 1, hi])
        return rng.randint(lo, hi)

    stream: List[Dict] = []
    tiles = []
    for t in range(n_tiles):
        k = rng.choice([1, 2, 3, 4, 7, 16, rng.randint(1, 96)])
        extreme = overflow_tiles and t % 3 == 2
        if extreme:
            k = max(k, 64)
        a = [[val(alo, ahi, extreme) for _ in range(k)] for _ in range(rows)]
        b = [[val(blo, bhi, extreme) for _ in range(cols)] for _ in range(k)]
        if extreme:   # same-sign extremes: drives |C| toward overflow
            a = [[alo] * k for _ in range(rows)]
            b = [[blo] * cols for _ in range(k)]
        tiles.append((k, a, b))
        for kk in range(k):
            stream.append({"valid": 1, "clear": int(kk == 0),
                           "a": [a[i][kk] for i in range(rows)],
                           "b": [b[kk][j] for j in range(cols)]})
            if rng.random() < 0.05:                     # wavefront bubble
                stream.append({"valid": 0, "clear": 0, "a": [0] * rows, "b": [0] * cols})

    s_len = len(stream)
    waves_needed = s_len + rows + cols + cfg.latency + 2
    lines: List[List[int]] = []
    for _ in range(3):                                   # reset
        lines.append([0, 1] + [0] * (2 * rows) + [0] * rows + [0] * cols)
    w = 0
    while w < waves_needed:
        if rng.random() < 0.2:                           # global stall: junk everywhere
            for _ in range(rng.choice([1, 1, 2, 5, 17])):
                lines.append([1, 0]
                             + [rng.randint(0, 1) for _ in range(rows)]
                             + [rng.randint(0, 1) for _ in range(rows)]
                             + [rng.randint(alo, ahi) for _ in range(rows)]
                             + [rng.randint(blo, bhi) for _ in range(cols)])
            continue
        v, c, av, bv = [], [], [], []
        for i in range(rows):
            s = w - i
            el = stream[s] if 0 <= s < s_len else None
            v.append(el["valid"] if el else 0)
            c.append(el["clear"] if el else 0)
            av.append(el["a"][i] if el and el["valid"] else rng.randint(alo, ahi))
        for j in range(cols):
            s = w - j
            el = stream[s] if 0 <= s < s_len else None
            bv.append(el["b"][j] if el and el["valid"] else rng.randint(blo, bhi))
        lines.append([1, 1] + v + c + av + bv)
        w += 1
    for _ in range(3):
        lines.append([1, 1] + [0] * (2 * rows) + [0] * rows + [0] * cols)

    expected = ref.mesh_expected_tokens(stream, rows, cols, cfg.acc_w, cfg.policy)
    return lines, expected, tiles, stream


def write_stim(lines, path):
    with open(path, "w") as f:
        for ln in lines:
            f.write(" ".join(str(x) for x in ln) + "\n")


def compare(tok_path: str, expected, rows: int, cols: int) -> Tuple[int, List[str], Dict]:
    got = [[[] for _ in range(cols)] for _ in range(rows)]
    with open(tok_path) as f:
        for line in f:
            p = line.split()
            if p and p[0] == "TOK":
                i, j = int(p[2]), int(p[3])
                got[i][j].append((int(p[4]), bool(int(p[5]))))
    errs, msgs = 0, []
    n_exp = n_ovf = 0
    for i in range(rows):
        for j in range(cols):
            e, g = expected[i][j], got[i][j]
            n_exp += len(e)
            n_ovf += sum(1 for _, o in e if o)
            if len(e) != len(g):
                errs += 1
                msgs.append(f"PE({i},{j}): {len(g)} tokens, expected {len(e)}")
            for t, (x, y) in enumerate(zip(g, e)):
                if x != y:
                    errs += 1
                    if len(msgs) < 10:
                        msgs.append(f"PE({i},{j}) token {t}: got {x} expected {y}")
    return errs, msgs, {"expected_tokens": n_exp, "expected_overflow_tokens": n_ovf}
