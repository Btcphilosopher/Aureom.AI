# Third-party files

`sky130_fd_sc_hd__tt_025C_1v80.lib` — SkyWater SKY130 open PDK, `sky130_fd_sc_hd`
standard-cell library, typical corner (25 °C, 1.80 V), Liberty timing/area view.

- Licence: Apache License 2.0 (SkyWater Technology Foundry / Google).
- Provenance: copied unchanged from the Aureom.AI repository delivery
  `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-testcore-p07.zip`
  → `silicaflux-testcore/third_party/pdk/`, which records it as fetched from the
  OpenROAD repository test data (`test/sky130hd/`).
- SHA-256: `92eb4e93a3d4c2563018ac81cdec2f02fdeaced9b39337ed5c141fa63e0ad8f8`
  (identical to the hash in that delivery's `SHA256SUMS`).

It is used only by `synth/run_synth.py` for ASIC logic-synthesis cell mapping and
area. No proprietary foundry data is included.
