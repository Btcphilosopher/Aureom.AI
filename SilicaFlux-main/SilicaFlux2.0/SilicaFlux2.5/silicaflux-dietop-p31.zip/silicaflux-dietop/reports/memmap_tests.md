# Memory-map validator tests

**34 / 34 PASS** (`scripts/test_memmap.py`: every illegal map must be rejected with the expected rule; the real map must validate).

| Case | Expected | Result | Validator output (truncated) |
|---|---|---|---|
| valid map accepted | accept | PASS | `map valid` |
| window not a power of two | R1 | PASS | `MAP INVALID: / R1 EXTMEM_CSR: window 0x00001800 not a power of two` |
| base not aligned to window | R1 | PASS | `MAP INVALID: / R1 DIE_REGS: base 0x3E008000 not aligned to window 0x00010000` |
| populated size larger than window | R1 | PASS | `MAP INVALID: / R1 DIE_REGS: size > window` |
| SPM stride smaller than window | R2 | PASS | `MAP INVALID: / R2 VEC_SPM: stride must be a power of two >= window` |
| SPM windows overlap the external-memory window (HPC) | R3 | PASS | `MAP INVALID: / R3 HPC: VEC_SPM0 [0x30000000+0x00100000] overlaps EXTMEM [0x30000000+0x04000000] / R3 HPC: VEC_SPM1 [0x30100000+0x00100000] overlaps EXTMEM [0x30` |
| register window overlaps the external-memory CSR | R3 | PASS | `MAP INVALID: / R3 HPC: DIE_REGS [0x3F000000+0x00010000] overlaps EXTMEM_CSR [0x3F000000+0x00001000]` |
| fabric region outside the ControlCore EXT window | R4 | PASS | `MAP INVALID: / R4 MIN/DIE_REGS: fabric=True but region outside the EXT window` |
| SHARED_SRAM moved away from the firmware DEVMEM base | R5 | PASS | `MAP INVALID: / R5 SHARED_SRAM base must equal ControlCore DEVMEM base 0x20000000` |
| VEC_SPM moved away from the firmware TILE_SPM base | R5 | PASS | `MAP INVALID: / R5 VEC_SPM instance 0 must equal ControlCore TILE_SPM 0x30000000+0x00010000` |
| a region mapped over the firmware probe address 0x2800_0000 | R3 | PASS | `MAP INVALID: / R3 HPC: RSVD_PROBE [0x28000000+0x08000000] overlaps EXTMEM [0x28000000+0x04000000]` |
| ControlCore IMEM size changed | R5 | PASS | `MAP INVALID: / R5 CC_IMEM must equal ControlCore IMEM (0x00010000+0x00010000)` |
| page 8 is not vector tile 0 | R5 | PASS | `MAP INVALID: / R5 page 8 must be vector tile 0 (ControlCore firmware) / R7 VEC: pages must exist for instances 0..3 (have [1, 1, 2, 3])` |
| die page outside the forwarded pages 8..15 | R7 | PASS | `MAP INVALID: / R7 die page VEC3 must be a forwarded page 8..15 / R7 page 16 used by VEC3 and CC_RAS` |
| two pages with the same number | R7 | PASS | `MAP INVALID: / R7 page 12 used by VEC3 and TSU1` |
| missing page for vector instance 3 | R7 | PASS | `MAP INVALID: / R7 VEC: pages must exist for instances 0..3 (have [0, 1, 2])` |
| misaligned DIE_SYS register | R8 | PASS | `MAP INVALID: / R8 register ID: offset not word aligned` |
| duplicate DIE_SYS register offset | R8 | PASS | `MAP INVALID: / R8 register offset 0x000 used by ID and HW_VERSION` |
| register outside every sub-block | R8 | PASS | `MAP INVALID: / R8 register ID outside every sub-page` |
| overlapping DIE_SYS sub-blocks | R8 | PASS | `MAP INVALID: / R8 sub-pages CTRL and IRQ overlap` |
| DMA channels do not fit their page | R8 | PASS | `MAP INVALID: / R8 DMA channels must fit one page` |
| duplicate IRQ bit | R9 | PASS | `MAP INVALID: / R9 IRQ bit 16 used by DIE_ERR and NOC_ERR` |
| IRQ instance range overlaps the next source | R9 | PASS | `MAP INVALID: / R9 IRQ bit 2 used by VEC2 and TSU0 / R9 IRQ bit 3 used by VEC3 and TSU1` |
| duplicate error code | R9 | PASS | `MAP INVALID: / R9 error code 1 used twice` |
| error code >= 32 | R9 | PASS | `MAP INVALID: / R9 error HOST_DECODE: code outside 0..31` |
| access matrix names an unknown target | R10 | PASS | `MAP INVALID: / R10 access matrix: unknown target class ROM` |
| 5 vector clusters (page budget is 4) | R6 | PASS | `MAP INVALID: / R6 HPC: num_vector_clusters outside 1..4` |
| 3 tensor clusters | R6 | PASS | `MAP INVALID: / R6 HPC: num_tensor_clusters outside 1..2` |
| banks not a multiple of slices | R6 | PASS | `MAP INVALID: / R6 HPC: num_sram_banks not a multiple of num_sram_slices` |
| 16 banks per slice | R6 | PASS | `MAP INVALID: / R6 MIN: banks per slice must be a power of two <= 8` |
| SRAM smaller than the firmware's 1 MiB | R6 | PASS | `MAP INVALID: / R6 MIN: sram_bytes must be a power of two in [0x00100000, 0x04000000]` |
| SRAM size not a power of two | R6 | PASS | `MAP INVALID: / R6 MIN: sram_bytes must be a power of two in [0x00100000, 0x04000000]` |
| NoC topology 3 | R6 | PASS | `MAP INVALID: / R6 MIN: noc_topology not in 0..2` |
| three SRAM slices | R6 | PASS | `MAP INVALID: / R6 HPC: num_sram_slices must be a power of two in 1..4` |
