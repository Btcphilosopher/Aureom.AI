# Mutation testing of the new die RTL

**15 / 15 mutants killed** (`scripts/mutate.py`).  Each mutant is one deliberate defect in the Project 31 RTL (never in `third_party/`), built and run in its own workspace; it is killed when the run does not end in `TB RESULT PASS`.

| Mutant | Defect | Config | Test | Verdict | First evidence |
|---|---|---|---|---|---|
| fence_never_drains | reset fence passes orphan responses to a freshly reset accelerator | MINEXT | accreset | KILLED | `[1158785000] %Error: sfb_protocol_checker.sv:86: Assertion failed in TOP.tb_die_top.g_chk_m[4].u_chk: [noc_master] R2: req_valid dropped before acceptance` |
| fence_drops_held_request | a request presented when the domain resets is withdrawn (SFB2 R2) | MINEXT | accreset | KILLED | `[1158785000] %Error: sfb_protocol_checker.sv:86: Assertion failed in TOP.tb_die_top.g_chk_m[4].u_chk: [noc_master] R2: req_valid dropped before acceptance` |
| gate_ignores_domain | scratchpad window forwards into a gated / reset accelerator domain | MIN | accreset | KILLED | `[141000] CHECK FAIL [accreset] SPM access while the accelerator clock is gated -> error response: got 00000000 exp 00000001` |
| gate_no_abandon | an outstanding scratchpad access lost to a reset is never answered | MIN | accreset | KILLED | `TB RESULT FAIL TIMEOUT at cycle 3000001 (test accreset)` |
| host_no_decode_error | host addresses outside the die are sent into the fabric | MIN | invalid | KILLED | `[65787] CHECK FAIL [invalid] ERR_FIRST = HOST_DECODE: got 80000101 exp 80000002` |
| cc_vector_irq_dead | vector-tile interrupts never reach the ControlCore | MIN | irq | KILLED | `[66026] CHECK FAIL [irq] ControlCore INTC PENDING.VECTOR: got 00000000 exp 00000001` |
| host_irq_ignores_enable | host interrupt routing ignores IRQ_HOST_EN | MIN | irq | KILLED | `[66022] CHECK FAIL [irq] host_irq_o low while IRQ_HOST_EN = 0: got 00000001 exp 00000000` |
| no_sram_init | shared SRAM not initialised (parity errors on first read, readiness too early) | MIN | reset | KILLED | `[271] CHECK FAIL [reset] PLATFORM_CYC = SRAM init sweep (bank depth) + a few cycles: got 00000000 exp 00000001` |
| reset_seq_off_by_one | reset sequencer timing differs from its specification | MIN | reset | KILLED | `[65775] CHECK FAIL [reset] stage POR -> FABRIC: FABRIC_DELAY + 3 cycles after PLL lock: got 00000014 exp 00000013` |
| dma_channel_decode | DMA channel registers alias across the DMA page (refused write with a side effect) | MIN | regs | KILLED | `[65847] CHECK FAIL [regs] refused DMA-page writes left channel 0 SRC_ADDR untouched: got 12345678 exp 20001000` |
| access_matrix_open | every master may reach every target (DMA into register space) | MIN | invalid | KILLED | `[66154] CHECK FAIL [invalid] DMA reading the die register window is refused (access matrix): got 00000000 exp 00000001` |
| errlog_wrong_port | error log records the wrong fabric master | MIN | invalid | KILLED | `[65798] CHECK FAIL [invalid] ERR_FIRST = NOC_DECODE from the HOST master (index 1): got 80000001 exp 80000101` |
| regs_window_dma_never_errs | absent DMA channels answer instead of refusing | MIN | identity | KILLED | `[65852] CHECK FAIL [identity] absent DMA channel 1 -> error response: got 00000000 exp 00000001` |
| slice_base_wrong | distributed SRAM slices decoded at the wrong base (multi-slice configuration) | V2 | sram | KILLED | `[0] %Fatal: silicaflux_noc.sv:236: Assertion failed in TOP.tb_die_top.dut.u_fabric.u_noc.unnamedblk2.unnamedblk3: silicaflux_noc: target windows 0 and 1 overlap` |
| tsu_page_swapped | tensor unit answers on the vector tile's page | MIN | identity | KILLED | `[65810] CHECK FAIL [identity] vector tile 0 ID: got 53465443 exp 53464854` |
