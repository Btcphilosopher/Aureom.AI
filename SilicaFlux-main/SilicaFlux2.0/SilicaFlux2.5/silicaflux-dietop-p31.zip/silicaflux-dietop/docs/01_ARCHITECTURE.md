# 01 — Die architecture

## 1. Hierarchy

```
silicaflux_die_top                       rtl/top/silicaflux_die_top.sv
├─ clock_reset_subsystem                 POR synchroniser (PowerClock sf_reset_sync), PLL-lock sync, reset sequencer
├─ host_io_subsystem                     simulation host bridge: ControlCore path / fabric path / decode error
├─ control_subsystem                     ControlCore (Project 21, unmodified) + reset fence on its fabric port
├─ compute_subsystem                     instance page decode, accelerator clock-live detector
│  ├─ vector_cluster[NUM_VECTOR_CLUSTERS]   silicaflux_hpc_tile + die_sfb_dom_gate (SPM window) + die_sfb_rst_fence (tile DMA)
│  └─ tensor_cluster[NUM_TENSOR_CLUSTERS]   silicaflux_tensor_unit + die_sfb_rst_fence (tensor DMA)
├─ memory_subsystem                      sfmem_banked per slice (+ init sweep), silicaflux_extmem_bridge (optional)
├─ datafabric                            silicaflux_noc (shared bus / crossbar / mesh) + SFB2 bridges + decode-error capture
├─ dma_subsystem                         silicaflux_dma[NUM_DMA_CHANNELS]
├─ die_regs_window                       DIE_REGS fabric region (sfb_v1_slave_adapter + sfv_periph_bridge)
├─ die_sysctrl                           identity, configuration, readiness, interrupt routing
└─ ras_test_subsystem                    die error log, warning/fatal forwarding to ControlCore RAS, test status
```

`silicaflux_die_min` and `silicaflux_die_hpc` (`rtl/top/silicaflux_die_cfg_wrappers.sv`) are fixed-parameter wrappers.
Synthesis, the hierarchy reports and floorplanning scripts can name them as tops.

Hierarchy is preserved where it is a useful physical partition: one module per subsystem and one instance per
cluster. The boundary blocks (gate, fence) live *inside* the cluster that owns the domain crossing. Nothing
prevents optimisation inside a partition, because no `keep_hierarchy` or `dont_touch` attributes are
hard-coded. The floorplan recommendations are in [05_HIERARCHY_FLOORPLAN.md](05_HIERARCHY_FLOORPLAN.md).

## 2. Configurations

| Parameter | MIN | HPC | Limits (`silicaflux_config_pkg`) |
|---|---|---|---|
| `NUM_VECTOR_CLUSTERS` | 1 | 4 | 1–4 (forwarded register pages 8, 10, 11, 12) |
| `NUM_TENSOR_CLUSTERS` (4×4 INT8 array each) | 1 | 2 | 1–2 (pages 9, 13) |
| `NUM_SRAM_BANKS` | 4 | 16 | multiple of slices; 1–8 banks per slice, power of two |
| `NUM_SRAM_SLICES` | 1 | 4 ("distributed SRAM") | 1, 2 or 4 |
| `SRAM_BYTES` | 1 MiB | 4 MiB | power of two, 1 MiB–64 MiB (the firmware uses device offsets up to 0xF_FFFF) |
| `NUM_DMA_CHANNELS` | 1 | 2 | 1–4 |
| `NOC_TOPOLOGY` | 0 shared bus | 1 crossbar | 0, 1, 2 (mesh) |
| `EXTMEM_EN` / `EXTMEM_ASYNC` | 0 / 0 | 1 / 0 | ASYNC requires EXTMEM |
| `TESTCORE_EN` | 0 | 0 | must be 0 in this release |
| `SRAM_PARITY` | 1 | 1 | — |

`silicaflux_config_pkg::cfg_error()` encodes the rules. `silicaflux_die_top` refuses an illegal set at
elaboration, and 12 illegal sets are tested with Verilator (`reports/lint.md`). The same check is written as a
generate-time `$fatal`, which Yosys honours, and as an `initial $fatal` for Icarus; those two paths are not
separately tested. **HPC is an architectural exploration**: it
elaborates in three tools and passes the same integration tests in simulation, and nothing more is claimed.

## 3. Integration contracts (`config/silicaflux_die.yaml` → `silicaflux_die_pkg`)

* **Data paths: SFB2** (DataFabric rev 2.0). Request and response channels use valid/ready. There is one beat
  per transaction, responses are in order per port, and `rsp_error` carries SLVERR or DECERR, with
  `rdata = 0` on errors and on writes (R8). A held request is never withdrawn (R2).
* **Central fabric: SFB3** (DataFabric-NoC: opcode, ID, QoS, status), reached **only** through the NoC's own
  `sfn_sfb2_mst_bridge` and `sfn_sfb2_tgt_bridge`. The traffic classes are QOS_CTRL (ControlCore, host),
  QOS_DMA, QOS_VECTOR and QOS_TENSOR. Outstanding limits: ControlCore 1, host 1, DMA 2, vector tile 1,
  tensor unit 4.
* **Register pages: SilicaFlux-V register bus.** `rb_sel` is a one-cycle strobe; read data and error are
  combinational; side effects happen at the end of the strobe; 32-bit accesses only.
* **External memory: SFMC** (Project 24 generic memory-controller interface, `docs/MC_INTERFACE.md` in that
  project): command, write-data, read-data and write-response channels with tags.
* **Transaction IDs.** Every SFB2 master uses one SFB3 ID (`noc_id_width = 1`), which guarantees in-order
  responses per port. The master index (`m_*` helpers) is reported in the error log.
* **Error codes, interrupt sources, configuration identifiers, readiness bits, reset stages:** generated
  constants (`DIE_ERR_*`, `DIE_IRQ_*`, `DIE_CFGID_*`, `DIE_ST_*`, `DIE_RST_STAGE_*`), with C and Python
  mirrors in `sw/include/silicaflux_die_map.h` and `scripts/generated/`.

No incompatible protocols are ever connected directly. Every protocol change goes through a verified adapter:
SFB2↔SFB3 through the NoC bridges, SFB2→register bus through the DataFabric v1 adapter plus the SilicaFlux-V
bridge, and SFB2→SFMC through the Project 24 bridge.

## 4. Fabric

| Masters (index order) | Targets (index order) |
|---|---|
| 0 ControlCore EXT port (fenced) | SRAM slice 0 … NSL-1 (`sfmem_banked`, bridge depth 2) |
| 1 host bridge, die-memory path | vector SPM window 0 … NV-1 (gate, depth 1) |
| 2 … DMA channels | DIE_REGS (depth 1) |
| … vector tile DMAs (fenced) | EXT data (if present) |
| … tensor unit DMAs (fenced) | EXT CSR (if present) |

Access matrix (by class, generated): ControlCore and host reach everything. DMA reaches SRAM, SPM and EXT,
never register space. Vector DMAs reach SRAM and EXT. Tensor units reach SRAM only, and their own descriptor
validation also confines them to `[MEM_LO, MEM_HI)` = the shared SRAM. A refused or unmapped access is
answered with DECERR by the NoC, and the die error log records the master index and exact address.

## 5. Address map

See the generated [MEMORY_MAP.md](MEMORY_MAP.md). One 32-bit space is shared by host, ControlCore, DMA and
accelerators. The ControlCore regions (boot ROM, IMEM, DMEM, register pages) are decoded inside the
ControlCore. The EXT window `0x2000_0000`–`0x3FFF_FFFF` is the fabric. The firmware-visible addresses
(shared SRAM at `0x2000_0000`, tile-0 SPM at `0x3000_0000`, pages 8 and 9) are fixed by rule R5, so the
unmodified ControlCore firmware runs on every configuration.

## 6. Interrupts

All die sources are levels: tiles, tensor units, DMA channels, die error, NoC error, external memory, and
the ControlCore mailbox. `IRQ_RAW` shows them.
* `host_irq_o` = `(IRQ_RAW & IRQ_HOST_EN) != 0` OR the ControlCore F2H doorbell.
* ControlCore VECTOR input = `(IRQ_RAW & IRQ_CC_VEC_EN) != 0`. ControlCore TENSOR input = `(IRQ_RAW & IRQ_CC_TSU_EN) != 0`.
  The reset value of the enable registers is "all instances", so on MIN the unmodified firmware's interrupt
  handlers see exactly what they saw in the reference system.
* Die error events are forwarded as one-cycle warnings to the ControlCore `ext_warn_i` (its RAS page counts
  them). An external-memory fatal error drives `ext_fatal_i`.

Status (HPC): the ControlCore has one VECTOR and one TENSOR input, so with four tiles the firmware must read
`IRQ_RAW` to find the source. The unmodified firmware drives only tile 0 and tensor unit 0, so firmware for
multiple instances is future work. The host-driven tests use every instance.

## 7. Host interface

* **MIN (and HPC in this release):** the *simulation host bridge* (`host_io_subsystem`). An SFB2 slave port at
  the die boundary is split by address into the ControlCore host port (boot ROM, IMEM, DMEM, register pages),
  the NoC (EXT window) or a local decode error. This is the transaction-level stand-in for a host link. The
  mailbox page (ControlCore page 5) is the host↔firmware command interface.
* **Physical path, not integrated:** Project 25 HostLink (`silicaflux_host_pcie`) exposes an AXI BAR slave, an
  AXI host-memory master, MSI requests and an **SFB2 master `df_*`**. That master is protocol-compatible with
  the die host port, so a `silicaflux_die_pcie_wrap` could put HostLink in front of the die. Three things stand
  in the way: (a) its `te_*` tensor-dispatch port targets the SilicaFlux-V TE register ABI and must stay
  unconnected; (b) its BAR register map would need to forward to the die map; (c) no PCIe endpoint or PHY
  exists. This release does not provide that wrapper.

## 8. Missing-IP stand-ins

| Item | Stand-in | Where | Status |
|---|---|---|---|
| SRAM macros | `sram_generic_1rw` behavioural arrays (`SRAM_BACKEND = GENERIC`) | inside the die | synthesizable behavioural; **not** a qualified macro |
| DRAM controller + PHY | `extmem_sim_mc` | testbench only | **simulation only**, hypothetical latencies |
| PLL | none: `clk_i` and `pll_lock_i` are die ports | boundary | — |
| PCIe endpoint / PHY | simulation host bridge port | boundary | transaction-level stand-in |
| Clock gate cell | `sfv_clkgate` behavioural ICG (ControlCore) | inside the ControlCore | maps to a library ICG per its header |
