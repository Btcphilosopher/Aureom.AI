# Dependency matrix — SilicaFlux DieTop (Project 31)

Classification (brief §1):

* **implemented** — RTL exists and elaborates.
* **verified** — has passing test evidence. For each one I say where the evidence comes from: *own* (the project's reports, not re-run here), *re-run* (I ran that project's own tests again in this environment), or *in-die* (exercised by this project's die testbench).
* **stubbed** — a placeholder exists, such as a black box or simulation-only model.
* **absent** — nothing exists in the repository.
* **incompatible** — exists but cannot be connected as is.

Every row was checked against the archives under `SilicaFlux-main/` (see `docs/00_AUDIT.md`), not against earlier prompts. The logs for "re-run" evidence are in `reports/independent/`. The logs for "in-die" evidence are in `reports/sim/` and are summarised in `reports/regression.md`.

| # | Dependency (brief §1) | Source in the repository | Classification | Evidence | Use in the die |
|---|---|---|---|---|---|
| 1 | **ControlCore** | `silicaflux-controlcore.zip` (Project 21): `silicaflux_control_core` (MCU-I `mcu_cpu` RV32IM, boot ROM, IMEM/DMEM with parity, SFB2 crossbar, INTC, timer, WDT, system DMA, mailbox, PMU, RAS, security status) | implemented, **verified** | *re-run*: reference system `boot_host` scenario PASS with 231/231 firmware checks (`reports/independent/controlcore_system_boot_host.log`). *in-die*: the unmodified firmware boots on the die; 188/188 self-test checks in 12 groups; mailbox GEMM, VECTOR and DMA checked against the TB reference (`reports/sim/*_firmware_*.log`) | `control_subsystem`, unmodified |
| 2 | **FP32 vector engine** | HPC Module 08 `silicaflux_hpc_tile`. It contains M02 lane, M03 array, FP32 FMA, M04 scratchpad, M05 DMA adapter, M06 command queue and M07 counters | implemented, **verified** | *own*: M08 145/145 integration runs. *in-die*: KERNEL FADD / FMUL bit-exact against the reference on every tile, operands in SRAM and in external memory; firmware T7 31/31 | `vector_cluster[i]`, unmodified |
| 3 | **INT8 TensorCore** | TENSORCORE 08 `silicaflux_tensor_unit`: 4×4 systolic array, plus TC02–TC07 inside | implemented, **verified** | *own*: 642 GEMMs. *in-die*: GEMMs of 4×4×4, 9×11×40, 16×8×24, 12×12×64 and 32×32×64 bit-exact on every unit; descriptor errors (RANGE); firmware T8 21/21 | `tensor_cluster[j]`, unmodified |
| 3a | TensorCore 09 / 10 | `silicaflux-tensorcore09.zip`, `-10-benchmarks-tensor.zip` | verification and benchmark collateral (no RTL) | — | not used |
| 4 | **"SRAMGrid"** | nothing by that name exists in any archive | **absent** | repository search | — |
| 4a | SRAM / memory wrappers | `silicaflux-sramlib.zip` (`sram_bank_controller`, generic / FPGA / ASIC back ends); MemoryCore `sfmem_banked` | implemented, **verified** (behavioural) | *own*: sramlib and MemoryCore regressions. *in-die*: SRAM front-door tests, byte strobes, slice boundaries, init sweep, every workload | `memory_subsystem`, unmodified |
| 4b | SRAM **macros** | `sram_macro_blackboxes.sv`, `sram_leaf_{sky130,gf180,ihp*}.sv` | **stubbed** (black boxes for macro names; no macro views, no PDK) | — | generic back end only (`SRAM_BACKEND = GENERIC`) |
| 5 | **DataFabric** (SFB2) | `silicaflux-datafabric` (crossbar, arbiters, adapters, DMA engines, protocol checker) | implemented, **verified** | *own*: formal and regressions. *in-die*: `sfb_protocol_checker` on the host port and every NoC port reports 0 violations | inside ControlCore; `die_regs_window`; DMA |
| 5a | **DataFabric-NoC** (SFB3) | `silicaflux-datafabric-noc.zip` (Project 22): shared bus, crossbar and mesh, plus SFB2 bridges | implemented, **verified** | *own*: 782 runs, 21 proofs. *in-die*: shared bus (MIN), crossbar (HPC, V2, MINEXT), mesh (V3) | `datafabric`, unmodified |
| 6 | **DMA** | DataFabric `silicaflux_dma` (burst engine); MCU-I `mcu_dma` (inside ControlCore); tile and tensor DMAs (inside the units) | implemented, **verified** | *in-die*: SRAM↔SRAM, SRAM↔SPM, SRAM↔EXT copies, completion IRQ, alignment and bus errors, access-matrix refusal | `dma_subsystem` (1–4 channels), unmodified |
| 7 | **Memory-controller bridge** | `silicaflux-extmem-bridge-p24.zip` (Project 24) `silicaflux_extmem_bridge` (+ CDC) | implemented, **verified against a simulated controller only** | *own*: 663/663 runs. *in-die*: host and DMA traffic, CSR, KERNEL operands in EXT, async MC clock (V3), SFMC checker 0 violations | `memory_subsystem` (HPC, V3, MINEXT), unmodified |
| 7a | DDR / HBM **controller + PHY** | none (Project 24 audit: no vendor IP, and the board has SDR) | **absent** | — | die boundary = SFMC; `extmem_sim_mc` in the TB is **simulation only** |
| 7b | `memory_controller.sf` (SilicaFlux 2.5 legacy) | single file, older ISA-era design | implemented (legacy); **incompatible** (no SFB2 / SFMC interface) | — | not used |
| 8 | **PCIe interface** (HostLink, Project 25) | `silicaflux-hostlink-project25.zip`: `silicaflux_host_pcie` (BAR ABI, queues, DMA engine, MSI requests) behind a generic AXI endpoint boundary | RTL implemented, **verified in simulation** | *re-run*: SV smoke + IRQ unit test PASS on Icarus and Verilator (`reports/independent/hostlink_sv_smoke.log`) | **not integrated**. Its `df_*` SFB2 master is protocol-compatible with the die host port (integration path in `docs/01_ARCHITECTURE.md` §7) |
| 8a | PCIe **endpoint / PHY** | none (HostLink contains no PCIe protocol logic) | **absent** | — | — |
| 8b | HostLink tensor-dispatch port (`te_*`) | drives the SilicaFlux-V tile's TE register page | **incompatible** with TENSORCORE 08 (different register ABI) | source inspection | must stay unconnected |
| 9 | **RAS** | ControlCore `cc_ras` (page 16); Project 26 `silicaflux_ras` with SECDED, scrub, event controller and fault injection | implemented, **verified** | *re-run*: P26 SECDED codec 10/10 (`reports/independent/ras_regress_secded.log`). *in-die*: forwarded die errors seen in ControlCore RAS; firmware T11 13/13 | `cc_ras` used. P26 **not integrated**: SECDED storage would need an ECC wrapper around the shared SRAM, and `sfmem_banked` refuses `ECC_MODE = SECDED` ("reserved for Project 26"), so it is **incompatible as is**. New: die error log in `ras_test_subsystem` |
| 10 | **PowerClock** (Project 27) | `silicaflux-powerclock.zip`: `silicaflux_power_manager` (AON + core domains, CDC, clock gates, command gates, thermal) | implemented, **verified** | *re-run*: Verilator `-Wall` lint clean; `clock_idle` PASS (`reports/independent/powerclock_*.log`) | **partially integrated**: `sf_reset_sync` (POR synchroniser). The power manager is not integrated: it needs an always-on clock and command-issue handshakes that the register-driven accelerators do not have, and accelerator clock gating is already owned by the ControlCore PMU. No DVFS exists (PowerClock itself says so) |
| 11 | **TestCore** | `silicaflux-testcore.zip`: `tc_top` (JTAG TAP, BSR, mode control, MBIST, LBIST, debug regs, clock and reset control) | implemented, **verified** | *re-run*: `tb_tap_fsm` PASS (14 924 checks), `tb_mbist` PASS (207 checks) | **not integrated**: `tc_top` owns the clock-root mux and reset release (`clk_o`, `sys_rst_n_o`), and its system APB runs on that root. Adopting it is a clock-architecture change. JTAG pins are reserved at the die boundary, and `TESTCORE_EN = 1` is refused at elaboration with that explanation |
| 12 | Clock / PLL | none | **absent** | — | die boundary: `clk_i`, `pll_lock_i` (and `mc_clk_i`) |
| 13 | Pad ring, I/O cells, ESD, package | none | **absent** | — | — |
| 14 | Firmware authentication (Project 28) | none (ControlCore reports AUTH = 0) | **absent** | ControlCore `SEC_STATUS` | CRC32 integrity only |
| 15 | Earlier top level `silicaflux_top.sf` (SilicaFlux 2.5) | coherent multi-core cluster description | **incompatible / non-functional**: Verilator syntax errors, missing `silicaflux_pkg`, and **0 of its 27 sub-modules exist** anywhere in the repository | `docs/00_AUDIT.md` §3 | not used |
| 16 | `soc_integration.tar.gz` | generic SoC (UART / GPIO / timer) around a CPU **bus-functional model** | implemented (stand-alone); **incompatible** (no SilicaFlux IP, no real CPU) | source inspection | not used |
| 17 | MCU-I, SilicaFlux-V utility blocks | `mcu_cpu`, `mcu_intc`, `mcu_wdt`, `mcu_dma`, `sfv_*` | implemented, **verified** (*own*: riscv-tests 63/63) | — | inside the ControlCore; `sfv_periph_bridge` reused in `die_regs_window` |

## What the die adds (new RTL, Project 31)

| Block | Purpose | Verified by |
|---|---|---|
| `silicaflux_die_top`, `silicaflux_die_min`, `silicaflux_die_hpc` | top-level hierarchy and the two documented configurations | lint, elaboration in 3 tools, regression |
| `silicaflux_die_pkg`, `silicaflux_config_pkg` (generated) | integration contract and configurations | `scripts/test_memmap.py` (34 cases), `--check` |
| `clock_reset_subsystem` | deterministic reset sequencer, PLL-lock policy | `reset` and `porreset` tests, mutation |
| `host_io_subsystem` | simulation host bridge (ControlCore path / fabric path / decode error) | every test, mutation |
| `control_subsystem` | ControlCore + reset fence on its fabric port | firmware runs |
| `compute_subsystem`, `vector_cluster`, `tensor_cluster` | instance decode, clock-live detector, per-cluster boundary blocks | `identity`, `vector`, `gemm`, `concur`, `accreset` |
| `die_sfb_dom_gate` | clock-request / refusal / abandon gate into the gated accelerator domain | `accreset`, mutation (2 mutants) |
| `die_sfb_rst_fence` | orphan-response fence for accelerator and ControlCore masters | `accreset` (orphans drained), mutation (2 mutants) |
| `memory_subsystem` | SRAM slices + **SRAM init sweep** + ExtMem bridge | `sram`, `reset`, `extmem`, firmware T12 |
| `datafabric` | NoC + SFB2 bridges + exact decode-error capture | protocol checkers, `invalid` |
| `dma_subsystem` | die DMA channels | `dma`, `invalid`, `concur` |
| `die_regs_window` | DIE_REGS region on the fabric | `identity`, `regs`, `accreset` |
| `die_sysctrl` | identity, configuration, readiness, IRQ routing | `identity`, `reset`, `irq`, firmware |
| `ras_test_subsystem` | die error log, warning forwarding, test status | `invalid`, `irq`, `accreset` |
