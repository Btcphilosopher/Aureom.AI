# 00 — Repository audit (Project 31, DieTop)

I audited `btcphilosopher/Aureom.AI` on branch `claude/nifty-davinci-3eo6cf`, at the working-tree state of
2026-11-10. Almost all SilicaFlux work lives in zip archives under `SilicaFlux-main/` and
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`, and the newest project archives are dated 2026-11-10. I extracted
every archive relevant to the die (26 archives) and inspected it. Nothing was taken from earlier prompts or
README claims without either re-running the project's tests or exercising the block inside this die. The
classification of every dependency is in [DEPENDENCY_MATRIX.md](DEPENDENCY_MATRIX.md).

## 1. Method

1. **Inventory.** I listed the RTL, testbenches, file lists and build flows of every archive. I extracted the
   port lists of each top and read each project's own audit and status sections.
2. **Vendored-source consistency.** The same file is vendored into many archives, for example `sfb_crossbar.sv`,
   `sram_bank_controller.sv` and the DMA engines. I hashed every same-named `.sv` / `.svh` file across all
   1 476 extracted copies. All copies are byte-identical, except `dma_defs.svh`, whose two variants differ only
   in a generated header comment (the name of the generator's source YAML). There is no functional conflict.
3. **Independent re-runs** (tools installed here: Verilator 5.020, Icarus 12.0, Yosys 0.33). The logs are in
   `reports/independent/`.

   | What | Result |
   |---|---|
   | ControlCore reference system (`silicaflux_cc_hpc_system`: ControlCore + vector tile + tensor unit), scenario `boot_host`, prebuilt firmware | **PASS**: 231/231 firmware checks plus every host check, 2 791 325 cycles |
   | TestCore `tb_tap_fsm`, `tb_mbist` (Icarus) | **PASS**: 14 924 and 207 checks |
   | PowerClock `make lint` (Verilator `-Wall`, both builds), `make sim TEST=clock_idle` | lint clean; **PASS**. Its Makefile does not create `build/base/`; I created it by hand |
   | HostLink `scripts/run_sv_smoke.py` (Icarus and Verilator) | **PASS** |
   | RAS (Project 26) `run_regress.py --only secded --sim icarus` | **10/10 PASS** |

4. **In-die verification.** Every block that is integrated is exercised by `tb/tb_die_top.sv` in five
   configurations (see `reports/regression.md`).

## 2. What exists and what the die uses

| Area | Found | Decision |
|---|---|---|
| Control processor | ControlCore (Project 21) is complete and verified, with a prebuilt firmware image. Other CPUs in the repository (`RISC-V CPU.zip`, `cpu_core.zip`, `pipelined_cpu.zip`, legacy `control_core.sv`) have no ISA tests or are not RISC-V | **ControlCore, unmodified**, together with its firmware image |
| Vector engine | HPC Module 08 tile (FP32 lanes, array, scratchpad, DMA adapter, command queue, counters) | **unmodified**, 1 instance (MIN), 4 instances (HPC) |
| Tensor engine | TENSORCORE 08 tensor unit (4×4 INT8 systolic array, TC02–TC07) | **unmodified**, 1 / 2 instances |
| Shared memory | SRAM library `sram_bank_controller`; MemoryCore `sfmem_banked` (banked, one SFB2 port per requester, parity option, test port) | **unmodified**, one per slice. The die adds an initialisation sweep through the test port |
| Interconnect | DataFabric SFB2 crossbar, plus DataFabric-NoC (SFB3: shared bus, crossbar, mesh) with SFB2 bridges | **NoC, unmodified**: shared bus for MIN, crossbar for HPC |
| DMA | DataFabric `silicaflux_dma` (register page, burst engine) | **unmodified**, 1 / 2 channels |
| External memory | Project 24 bridge (SFB2 upstream, generic SFMC downstream, optional CDC), verified against a simulated controller | **unmodified** (HPC). SFMC is the die boundary |
| Host interface | Project 25 HostLink (AXI endpoint boundary, no PCIe logic) | **not integrated** (see matrix row 8). The die exposes a simulation host bridge port |
| RAS | ControlCore `cc_ras`; Project 26 SECDED / scrub / fault-injection | ControlCore RAS used, and a new die error log added. Project 26 is not integrated (matrix row 9) |
| Power / clock | ControlCore PMU (accelerator ICG, reset, isolation); Project 27 power manager | PMU used; `sf_reset_sync` used; Project 27 manager not integrated (matrix row 10) |
| DFT / debug | TestCore | not integrated (matrix row 11); JTAG pins reserved |

## 3. Earlier "top-level" attempts in the repository

* **`SilicaFlux2.5/silicaflux_top.sf`** (84 KB) describes a coherent multi-core compute cluster (superscalar
  cores, L2, LLC, snoop filter, TLB, AXI CDC). Its header says "Language: Silica Flux-2017". Verilator stops
  with syntax errors and a missing `silicaflux_pkg`. I searched the whole extracted tree and the `.sf` files
  for its 27 instantiated sub-modules (`sf_core`, `sf_coh_xbar`, `sf_llc_bank`, `sf_tensor_engine`, …) and
  **none of them exists**. It is a description, not a design, and nothing from it is used.
* **`soc_integration.tar.gz`** is a small generic SoC (UART, GPIO, timer, boot ROM) built around a CPU
  *bus-functional model*. It contains no SilicaFlux IP, and nothing from it is used.
* **`silicaflux_cc_hpc_system`** (inside ControlCore) and **`sfx_hpc_tensor_system`** (TENSORCORE 08) are the
  real, verified precursors of this die. Each has one tile and one tensor unit, and an external testbench
  memory model instead of on-die SRAM. The die generalises them; their wiring idioms are reused.

## 4. Findings made while integrating

These are behaviours of the verified IP that only show up when the blocks are put together on one die. Each
one is handled in the die RTL or documented. The details are in `docs/01_ARCHITECTURE.md` and
`docs/03_CLOCKING.md`.

1. **The ControlCore refuses all forwarded register pages (8–15) whenever the accelerator domain is isolated**
   (PMU ISO, RST or clock off, or a fatal error). A die status page placed there would vanish exactly when it
   is needed. The die therefore puts DIE_SYS, the NoC counters and the DMA channels in a **fabric region
   (`DIE_REGS`, 0x3E00_0000)**. Only the accelerator pages stay behind the ControlCore. The test `accreset`
   reads die status while the accelerators are held in reset.
2. **The accelerators run on the ControlCore's ICG-gated clock, but the die fabric does not.** In the reference
   systems the whole accelerator fabric was behind the ControlCore's gate. On the die, host and DMA traffic
   reaches the tile scratchpads directly, and accelerator DMAs share a NoC that survives accelerator resets.
   Two new blocks close the resulting hazards:
   * `die_sfb_dom_gate`: requests the clock through the PMU's `busy` input before every handshake, refuses
     accesses while the domain is down, and abandons transactions lost to a reset with an error.
   * `die_sfb_rst_fence`: drains orphan responses after an accelerator reset. The regression shows it
     draining a real orphan after a reset in the middle of a GEMM.
3. **Parity-protected shared SRAM must be initialised.** The unmodified firmware self-test reads a word it never
   wrote (T12), and the read failed with a parity error. The reference system's testbench memory had no parity,
   so the problem never appeared there. The die now performs a deterministic hardware initialisation sweep
   (zero data with valid parity, one row per cycle, all banks in parallel) before `MEM_READY`.
4. **The firmware hard-codes the reference testbench's "poison" window** (`0x200E_F000`). Self-test groups
   T6 (DMA) and T10 (errors) expect that SRAM address to return bus errors. On the die it is real SRAM, so
   those two groups are excluded from the die self-test (mask `0x3DDF`). The same error paths are exercised on
   the die with genuinely unmapped addresses: the mailbox `DMA_COPY` from `0x2400_0000` returns `READ_BUS`.
5. **The firmware self-test probes `0x2800_0000` and expects a decode error.** The map reserves
   `0x2800_0000`–`0x2FFF_FFFF`, and the generator rejects any region placed there (rule R5).
6. **`silicaflux_dma` does not export its error flag.** The die logs DMA errors by observing error responses
   on the channel's SFB2 port. The exact code and address stay in the channel's own registers.
7. **Yosys 0.33 rejects `import pkg::*`, `int'()` casts and nested calls in constant functions** (the last is
   an Icarus restriction). All new RTL follows the SilicaFlux convention of scoped `pkg::NAME` references, as
   TENSORCORE 04 does.
8. **TestCore expects to own the clock root.** **HostLink's tensor dispatch targets a different tensor ABI.**
   See the matrix.

## 5. What is not in the repository (and therefore not in the die)

There is no PLL, no SRAM macro views or PDK, no DDR or HBM controller or PHY, no PCIe endpoint or PHY, no
pad ring or package, and no firmware authentication. Behavioural or simulation-only stand-ins are named as
such wherever they appear: `extmem_sim_mc` lives in the testbench, and SRAMs use the generic back end.
