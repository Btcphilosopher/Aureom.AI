# 02 — Reset, boot and readiness

## 1. Reset domains

| Domain | Reset | Source | Contents |
|---|---|---|---|
| POR | `por_ni` (async), synchronised by `sf_reset_sync` (PowerClock, unmodified) | board | reset sequencer, PLL-lock synchroniser |
| fabric | `fab_rst_n` | sequencer stage FABRIC | NoC, SRAM slices, ExtMem bridge, DMA, DIE_REGS, die control/status/error log, all boundary gates and fences |
| ControlCore | `cc_rst_n` → ControlCore `rst_ni` | sequencer stage CONTROL | the ControlCore. Its own generator derives POR, system and accelerator resets from this (soft / watchdog / host resets stay inside the ControlCore) |
| accelerators | ControlCore `acc_rst_no` | ControlCore (system reset, PMU `ACC_CTRL.RST`) | vector tiles, tensor units (and the clock-live toggle flop) |
| memory controller | bridge `mc_rst_no` | ExtMem bridge link FSM | external controller (SFMC boundary) |

Every reset asserts asynchronously and releases synchronously to `clk_i`. With `test_mode_i = 1`, the fabric
and ControlCore resets bypass the sequencer to `por_ni` for DFT controllability.

## 2. Deterministic sequence (`clock_reset_subsystem`)

```
por_ni ↑ ──► (2-flop) ──► PLL lock seen (2-flop) ──► FABRIC_DELAY+1 edges ──► FABRIC ──► CONTROL_DELAY+1 edges ──► CONTROL ──► 1 edge ──► RUN
              POR held                                                     fab_rst_n=1                          cc_rst_n=1
```

The defaults are `FABRIC_DELAY = CONTROL_DELAY = 16`. The `reset` test measures the stage transitions to the
cycle: POR→FABRIC is `FABRIC_DELAY + 3` cycles after PLL lock, FABRIC→CONTROL is `CONTROL_DELAY + 1`, and
CONTROL→RUN is 1. **Policy:** if PLL lock is lost after release, the whole sequence restarts from POR, because
the functional clock is not trusted without lock.

## 3. Peripheral readiness (`DIE_SYS.STATUS`, offset 0x024)

| Bit | Name | Becomes 1 when |
|---|---|---|
| 0 | RESET_DONE | sequencer in RUN |
| 1 | FABRIC_READY | fabric out of reset (the register is unreadable otherwise) |
| 2 | MEM_READY | **shared SRAM initialisation sweep complete**: every word written with zero and valid parity, one row per cycle, all banks of all slices in parallel; exactly `bank depth` cycles (65 536 in MIN and HPC) |
| 3 | EXTMEM_READY | ExtMem link up after the controller's init/calibration handshake (constant 1 without ExtMem) |
| 4 | CC_RUNNING | ControlCore released |
| 5 | COMPUTE_READY | accelerator domain out of reset (`acc_rst_no`). Clock gating is a power state and does not clear it |
| 6 | FW_HOST_READY | ControlCore firmware raised its HOST_READY pin |
| 7 | **PLATFORM_READY** | bits 0, 2, 3, 4, 5 (all hardware ready). Also the pin `platform_ready_o` |
| 8 | **DEVICE_READY** | PLATFORM_READY and FW_HOST_READY. Also the pin `device_ready_o` (host-visible device-ready) |

`PLATFORM_CYC` and `DEVICE_CYC` freeze when their condition first holds. In the regression, MIN and HPC
both report `PLATFORM_CYC = 65 537` (init sweep + 1). With the real firmware loaded by the host,
`DEVICE_CYC = 739 230`: host image load, ROM CRC check, firmware initialisation and POST.

## 4. ControlCore boot (unchanged ControlCore boot ROM and firmware)

1. **ROM_START / ROM_INIT.** DMEM is scrubbed and pattern-tested and IMEM is scrubbed; parity checking is
   then enabled.
2. **WAIT_IMAGE** (`boot_mode_i = 00`). The host writes the image into IMEM through the host bridge
   (ControlCore path), then sends mailbox `IMAGE_READY`. Alternatively, with `boot_mode_i = 01` the ROM's
   system DMA fetches the image from shared SRAM; this works because SRAM is a fabric target, but the die
   regression does not exercise it.
3. **IMAGE_CHECK → FW_START.** The ROM checks the header and the CRC32 (integrity only; authentication is
   absent) and jumps to the entry point.
4. **Firmware.** It discovers the accelerators (page 8 vector tile, page 9 tensor unit), runs POST, sets the
   host write lock, publishes HOST_READY, and serves mailbox commands.
5. Soft, watchdog and host resets restart the ControlCore and the accelerators. **The fabric and the shared
   SRAM keep running and keep their contents** (the `porreset` test checks this for a host reset). A warm boot
   can restart the retained IMEM image (seen in the logs after a watchdog reset).

## 5. What a host does

```
power on  →  wait platform_ready_o (or poll DIE_SYS.STATUS bit 7 at 0x3E00_0024)
          →  [optional] host-direct use of accelerators / DMA through the register pages and DIE_REGS
          →  load firmware: poll CC SYSCTRL.BOOT_STAGE == WAIT_IMAGE, write IMEM, mailbox IMAGE_READY
          →  wait device_ready_o; read the unsolicited ready message (capabilities)
          →  mailbox commands (GEMM / VECTOR_KERNEL / DMA_COPY / RUN_SELFTEST / PERF_DUMP / RAS_DUMP / SHUTDOWN)
```

`tb/tb_die_top.sv` (`t_firmware`) does exactly this.
