# 06 — Limitations and what is NOT claimed

## Not claimed

* **Silicon readiness.** This is RTL verified in simulation, with an elaboration and coarse generic synthesis
  check. Nothing is tape-out ready. There is no PDK, no macro, no place-and-route, no STA, no DFT insertion,
  no power analysis and no signoff of any kind.
* **Area, frequency, power.** None is claimed. The 10 ns simulation clock is a testbench convenience. The
  Yosys numbers in the hierarchy reports are coarse internal cell counts for relative partition weight only.
* **Qualified IP.** The SRAM back end is the library's *generic behavioural* model. `extmem_sim_mc` is a
  **simulation-only** controller model with hypothetical latencies; it is not a DRAM model and it is never
  part of the die. There is no PLL, DDR or HBM controller or PHY, PCIe endpoint or PHY, or pad ring.
* **HPC configuration.** HPC is an architectural exploration. It elaborates (Verilator, Icarus, Yosys) and
  passes the host-driven integration tests and the firmware scenario in simulation; that is all.
* **Security.** Firmware authentication is absent (CRC32 integrity only, as the ControlCore reports).
* **RISC-V compliance.** None is claimed (the ControlCore's riscv-tests are not compliance).

## Known limitations of this release

1. **Firmware for multiple instances.** The unmodified ControlCore firmware drives vector tile 0 and tensor
   unit 0 only. On HPC, tiles 1–3 and tensor unit 1 are exercised by the host-driven tests. The ControlCore
   has one VECTOR and one TENSOR interrupt input, so multi-instance firmware must demultiplex through
   `DIE_SYS.IRQ_RAW`; that firmware is not written.
2. **Firmware self-test groups T6 and T10** are excluded on the die. They are compiled against the reference
   testbench's poison window `0x200E_F000`, which is real SRAM here. Their error paths are covered on the die
   with genuinely unmapped addresses.
3. **Host-bridge transactions to the ControlCore during a ControlCore reset.** A host access to the ControlCore
   window that the ControlCore has accepted can be lost if the ControlCore is reset (soft, watchdog or
   host-request reset) before it responds, and the host bridge then waits. Hosts must not issue ControlCore
   accesses while they request a host reset. This is the same rule as the reference system's host port. The
   fabric path (SRAM, SPM, DIE_REGS) is unaffected.
4. **TestCore not integrated.** JTAG pins are reserved and tied inactive (`tdo_oe_o = 0`), and
   `TESTCORE_EN = 1` is refused. MBIST of the shared SRAM through TestCore is therefore absent; the SRAM test
   port is used for the initialisation sweep instead.
5. **Project 26 SECDED / scrubbing not integrated.** The shared SRAM uses byte parity (detection only), and
   `sfmem_banked` refuses SECDED mode.
6. **Project 27 power manager not integrated.** Only its reset synchroniser is used. There is no thermal
   management or operating-point control on the die; accelerator clock gating is the ControlCore PMU's.
7. **HostLink (PCIe) not integrated** (`docs/01_ARCHITECTURE.md` §7). Its tensor-dispatch port is
   incompatible with TENSORCORE 08.
8. **Die DMA error reporting.** The die error log records the channel; the error code and address are in the
   channel's own registers (`silicaflux_dma` does not export them).
9. **SRAM init time.** The initialisation sweep costs `bank depth` cycles (65 536 for both documented
   configurations) before `MEM_READY`. More banks per slice shorten it.
10. **NoC size.** HPC uses a 10-master × 11-target crossbar. DataFabric-NoC's own regressions go up to 8×8;
    the die regression is the only evidence at this size.
11. **Reset during a ControlCore isolation window.** The ControlCore fabric-port fence is keyed on the
    accelerator reset (the only ControlCore reset visible at its boundary). This is safe because the
    ControlCore isolates and idles that port before an accelerator-only reset, but the argument depends on
    the ControlCore PMU's documented behaviour.
12. **Tools.** Verilator 5.020, Icarus 12.0 and Yosys 0.33 only. No commercial simulator, linter or CDC tool
    was available.
