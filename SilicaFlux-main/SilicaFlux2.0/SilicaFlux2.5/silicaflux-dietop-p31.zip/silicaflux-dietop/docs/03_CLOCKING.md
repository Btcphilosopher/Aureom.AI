# 03 — Clocking and the gated accelerator domain

## 1. Clocks

| Clock | Source | Used by | Relation to `clk_i` |
|---|---|---|---|
| `clk_i` | die boundary (PLL / clock-root integration point; `pll_lock_i` qualifies it) | everything except the accelerators | — the one functional clock |
| `acc_clk` | ControlCore `acc_clk_o` = `sfv_clkgate` (behavioural ICG) of `clk_i`, enabled by the ControlCore PMU | vector tiles, tensor units | **same clock, gated**: equal edges, same tree. It is not a clock-domain crossing |
| `mc_clk_i` | die boundary (memory-controller clock) | the SFMC side of the ExtMem bridge **only when `EXTMEM_ASYNC = 1`** | asynchronous; crossed by Project 24's own verified `extmem_mc_cdc` (async FIFOs, 2-flop synchronisers) |
| `tck_i` | JTAG pins | nothing (TestCore not instantiated) | — |

The die implements **no new clock-domain crossing**. With `EXTMEM_ASYNC = 0` (MIN, HPC) the SFMC interface runs
on `clk_i`. With `EXTMEM_ASYNC = 1` (variation V3 in the regression) the bridge's existing, verified CDC is used
unchanged, and the TB clocks the controller model from a 7 ns clock against the 10 ns core clock.

The PLL, pad ring and the TestCore clock-root mux are integration boundaries only (`docs/06_LIMITATIONS.md`).
The simulation clock period (10 ns) is a testbench convenience. **No operating frequency is claimed.**

## 2. Why the accelerator boundary needs care

The ControlCore gates the accelerator clock (PMU `ACC_CTRL.CLK_EN`) and resets the accelerators (`RST`, soft,
watchdog and host reset). In the verified reference systems, everything on the accelerator side, including
the fabric and the scratchpad host window, sat behind the ControlCore's own isolation gate.

On the die, the NoC, the shared SRAM, the host bridge and the die DMA stay alive in the fabric domain.
Three hazards follow, and each one is handled.

### 2.1 Phantom handshakes into a gated domain → `die_sfb_dom_gate` clock request

An SFB2 handshake between a `clk_i` flop and an `acc_clk` flop is only real if the accelerator clock ticks on
that edge. If the clock is gated, the fabric side would see `ready` (a frozen value) and believe the tile took
a request it never captured.

The ControlCore PMU computes `clk_on_q <= CLK_EN || vec_busy || tsu_busy || !ext_idle`, and `acc_vec_busy_i` is
**not** synchronised inside the ControlCore (checked in its source). The gate uses this as a clock request:

1. On first sight of a request it raises `dom_busy` combinationally. The die ORs `dom_busy` into the
   ControlCore's `acc_vec_busy_i`.
2. It waits one cycle (state ARM). By then the PMU has registered `clk_on_q = 1`, so the ICG passes the next
   edge.
3. Only then does it present the request to the tile (FWD), and it keeps `dom_busy` high until the response
   has been delivered upstream (OUT). Every handshake with the tile therefore lands on a ticking edge.

Requests that arrive while the domain is in reset, or while its clock has been observed stopped, are refused
with an error response: `dom_clk_live` comes from a toggle flop in `acc_clk` sampled on `clk_i`, which is
exact for equal-edge clocks. They are counted in `GATE_REFUSED` and logged as `DIE_ERR_GATE_REFUSED`. A
gated domain is therefore an *isolated* domain, matching the ControlCore's own policy for its accesses.

### 2.2 Lost transactions on reset → gate abandon

If the accelerator domain is reset while a scratchpad access is outstanding, the tile can never answer. The
gate answers with an error and logs it, so the fabric never hangs.

### 2.3 Orphan responses after reset → `die_sfb_rst_fence`

The accelerator DMAs (tile: 1 outstanding, tensor unit: up to 4) and the ControlCore's fabric port can be
reset with transactions still in the NoC. The fence counts outstanding transactions. While the domain is in
reset, and after release until the count reaches zero, it holds new requests off and sinks the stale
responses. A request that was presented but not yet accepted when reset hit keeps being presented from a
registered copy (SFB2 R2: never withdrawn), and its response is drained too.

The regression exercises three cases:

* A reset in the middle of a GEMM drains real orphan responses. The same GEMM then completes bit-exact, with
  a fresh completion record and no stale one.
* With external memory, a tile's operand read takes 400 controller cycles and a short reset is released before
  it returns. The fence drains the late response; without the fence, the accelerator-side protocol checker
  sees it reach the fresh tile, which is how the mutant is killed.
* A swept reset lands on a request the fabric is still holding, and the fence keeps presenting it. Without the
  hold logic, the NoC-side checker flags a withdrawn request (R2).

The fence on the ControlCore's port is keyed on `acc_rst_no`, which asserts with every ControlCore system
reset. During an accelerator-only reset the ControlCore's own isolation gate already blocks that port, and
the PMU applies RST only when the port is idle, so the fence never interferes with a live ControlCore.

### 2.4 Simulation semantics of the ICG

`acc_clk = clk & latch(en)` is evaluated in the same time step as `clk`. With non-blocking flops, both
Verilator 5 and Icarus 12 sample pre-edge values across the boundary. I checked this with a dedicated
experiment (a counter in `clk`, copied in `acc_clk`, copied back in `clk`: zero mismatches in both simulators,
and the result does not change when unrelated logic is added). This is also how the ControlCore's reference
system ran.

## 3. Interaction with the ControlCore firmware

* Self-test T14 (PMU gating) checks that the tensor-unit cycle counter freezes while gated. The accelerators
  really do run on `acc_clk`, and T14 passes on the die.
* The `VEC_BUSY` performance counter and `ACC_STATUS.VEC_BUSY` also count host scratchpad-window activity,
  because that activity is OR-ed into the busy input as a clock request. This is a deliberate, documented
  semantic change visible only to diagnostics.

## 4. Remaining clocking limitations

* The die does not implement or verify a clock-domain crossing other than the ExtMem bridge's own.
* There is a one-cycle window in which a scratchpad request can re-enable a clock that the PMU has just
  decided to stop. This is functionally safe (the request is served, then the clock stops), and it is visible
  only as a slightly delayed gating.
* TestCore's clock-root mux (`clk_o` with test-clock selection) is not in the clock path. Adopting it means
  clocking the whole die from `tc_top.clk_o` and re-verifying, which is not done.
* There is no STA and no SDC for the die. The Project 24 archive ships CDC constraint *templates* for its
  bridge (`constraints/` in `silicaflux-extmem-bridge-p24.zip`). They are not vendored here, and they would
  be the starting point for the `EXTMEM_ASYNC = 1` crossing.
