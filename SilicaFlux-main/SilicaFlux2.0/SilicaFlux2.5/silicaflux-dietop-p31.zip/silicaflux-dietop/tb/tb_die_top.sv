// =============================================================================
// SilicaFlux DieTop :: tb_die_top -- top-level integration testbench
//
// DUT: silicaflux_die_top (configuration from defines, default MIN; +define+CFG_HPC
// for HPC; TB_* defines for parameter variations).  The testbench plays:
//   * the HOST: SFB2 master on the die host port (optional random response
//     back-pressure, +bp=<percent>), host interrupt and device-ready pins;
//   * the board: POR, PLL lock, boot straps, host reset request;
//   * the external DRAM controller: extmem_sim_mc (Project 24, SIMULATION ONLY,
//     behavioural latencies, NOT a DRAM model) behind the die's SFMC boundary.
// Every result is checked against an independent reference computed here
// (INT8 GEMM, exact-integer FP32, memcpy).  DataFabric sfb_protocol_checker
// instances watch the host port and every NoC master / target port inside the
// die; extmem_mc_checker watches the SFMC boundary.
//
// Tests (+test=<name>, default "all"; "firmware" is separate and long):
//   identity  elaboration result: IDs, configuration registers, every instance page
//   regs      DIE_SYS register access rules (RW / RO / W1C / unmapped), CC registers
//   reset     deterministic reset sequence, stage timing, readiness, PLATFORM_CYC
//   sram      shared SRAM front-door access, byte strobes, every slice boundary
//   dma       die DMA: SRAM->SRAM, SRAM->SPM->SRAM, completion IRQ, error path
//   vector    FP32 vector KERNELs on every tile vs reference, completion IRQ
//   gemm      INT8 GEMMs on every tensor unit vs reference, completion IRQ
//   irq       interrupt routing: host routing, ControlCore VECTOR / TENSOR inputs
//   invalid   invalid accesses: host decode, fabric decode, descriptors, RO writes
//   concur    concurrent GEMM + KERNEL + DMA + host traffic (back-pressure, contention)
//   accreset  ControlCore PMU: accelerator reset mid-GEMM (fence) and clock gating (gate)
//   extmem    external memory window, CSR, DMA SRAM->EXT->SRAM (EXTMEM configurations)
//   porreset  die POR mid-traffic, re-sequence, re-run a workload; host reset request
//   firmware  the real ControlCore firmware on the die: host load, boot, HOST_READY,
//             self-test (groups that do not need the reference TB's poison window),
//             mailbox GEMM / VECTOR / DMA commands checked against the reference
// Result: "TB RESULT PASS|FAIL ..." and exit status 0 / non-zero.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

`ifdef CFG_HPC
  `define TB_NV     4
  `define TB_NT     2
  `define TB_NBANKS 16
  `define TB_NSL    4
  `define TB_SRAMB  32'h0040_0000
  `define TB_ND     2
  `define TB_TOPO   1
  `define TB_EXT    1
  `define TB_CFGID  2
`endif
`ifndef TB_NV
  `define TB_NV 1
`endif
`ifndef TB_NT
  `define TB_NT 1
`endif
`ifndef TB_NBANKS
  `define TB_NBANKS 4
`endif
`ifndef TB_NSL
  `define TB_NSL 1
`endif
`ifndef TB_SRAMB
  `define TB_SRAMB 32'h0010_0000
`endif
`ifndef TB_ND
  `define TB_ND 1
`endif
`ifndef TB_TOPO
  `define TB_TOPO 0
`endif
`ifndef TB_EXT
  `define TB_EXT 0
`endif
`ifndef TB_EXTASYNC
  `define TB_EXTASYNC 0
`endif
`ifndef TB_CFGID
  `define TB_CFGID 1
`endif

module tb_die_top;
  import silicaflux_die_pkg::*;
  import silicaflux_config_pkg::*;
  import cc_memmap_pkg::*;

  localparam int NV = `TB_NV, NT = `TB_NT, NBANKS = `TB_NBANKS, NSL = `TB_NSL, ND = `TB_ND;
  localparam int SRAMB = `TB_SRAMB, TOPO = `TB_TOPO, EXT = `TB_EXT, EXTASYNC = `TB_EXTASYNC, CFGID = `TB_CFGID;
  localparam int FAB_DLY = 16, CTL_DLY = 16;
  localparam int NM = noc_nm(ND, NV, NT), NTG = noc_nt(NSL, NV, EXT);
  localparam logic [31:0] SRAM = DIE_SHARED_SRAM_BASE;
  localparam logic [31:0] SYS  = DIE_DIE_REGS_BASE + 32'(DIE_REGS_PAGE_SYS) * 32'h1000;
  localparam logic [31:0] NOCP = DIE_DIE_REGS_BASE + 32'(DIE_REGS_PAGE_NOC_PERF) * 32'h1000;
  localparam logic [31:0] DMAP = DIE_DIE_REGS_BASE + 32'(DIE_REGS_PAGE_DMA) * 32'h1000;
  localparam int MC_AW = 26, MEMB = 262144;
  localparam int BANK_DEPTH = SRAMB / NSL / 4 / (NBANKS / NSL);

  // ------------------------------------------------------------------ tile / tensor ABI (HPC Module 08, TENSORCORE 08)
  localparam logic [11:0] HPC_ID = 12'h000, HPC_CONFIG0 = 12'h008, HPC_SPM_BASE = 12'h010, HPC_IRQ_EN = 12'h030,
                          HPC_IRQ_STATUS = 12'h034, HPC_CPL_INFO = 12'h040, HPC_CPL_COUNT = 12'h048,
                          HPC_CPL_POP = 12'h058, HPC_CMD0 = 12'h080, HPC_DOORBELL = 12'h0A0, HPC_CTRL = 12'h020;
  localparam logic [31:0] HPC_TILE_ID = 32'h5346_4854;
  localparam logic [11:0] TSU_ID = 12'h000, TSU_INFO = 12'h004, TSU_MEM_LO = 12'h010, TSU_MEM_LAST = 12'h014,
                          TSU_CTRL = 12'h018, TSU_STATUS = 12'h01C, TSU_INT_EN = 12'h020, TSU_INT_ST = 12'h024,
                          TSU_DESC0 = 12'h040, TSU_DOORBELL = 12'h070, TSU_CPL0 = 12'h080, TSU_CPL_POP = 12'h098;
  localparam logic [31:0] TSU_ID_VALUE = 32'h5346_5443;
  localparam logic [11:0] DMA_CONTROL = 12'h000, DMA_STATUS = 12'h004, DMA_SRC = 12'h008, DMA_DST = 12'h00C,
                          DMA_LENGTH = 12'h010, DMA_BYTES_DONE = 12'h014, DMA_INT_EN = 12'h018, DMA_INT_ST = 12'h01C,
                          DMA_ERR_CODE = 12'h020, DMA_ID = 12'h02C;

  // ------------------------------------------------------------------ clocks, board
  logic clk = 1'b0, mc_clk = 1'b0;
  always #5 clk = ~clk;
  always #3.5 mc_clk = ~mc_clk;
  longint unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  logic por_n = 1'b1, pll_lock = 1'b0, host_rst = 1'b0, ext_warn = 1'b0, ext_fatal = 1'b0;
  initial #1 por_n = 1'b0;                                 // a real POR edge at time 0+ (async resets fire)
  logic [1:0] boot_mode = 2'b00;

  // ------------------------------------------------------------------ DUT
  logic        h_req_valid = 1'b0, h_req_ready, h_req_write = 1'b0, h_rsp_valid, h_rsp_ready = 1'b1, h_rsp_error;
  logic [31:0] h_req_addr = '0, h_req_wdata = '0, h_rsp_rdata;
  logic [3:0]  h_req_wstrb = 4'hF;
  logic        host_irq, plat_ready, dev_ready, ras_fatal, diag_valid, test_done, test_fail, cpu_sleep, tdo, tdo_oe;
  logic [7:0]  diag_char;
  logic [15:0] test_code;
  logic        mc_rst_n, mc_init_done, mc_fatal, mc_cmd_valid, mc_cmd_ready, mc_cmd_write, mc_wd_valid, mc_wd_ready,
               mc_wd_last, mc_rd_valid, mc_rd_ready, mc_rd_last, mc_rd_error, mc_wr_valid, mc_wr_ready, mc_wr_error;
  logic [MC_AW-1:0] mc_cmd_addr;
  logic [7:0]  mc_cmd_len;
  logic [1:0]  mc_cmd_tag, mc_rd_tag, mc_wr_tag;
  logic [31:0] mc_wd_data, mc_rd_data;
  logic [3:0]  mc_wd_strb;

  silicaflux_die_top #(
    .NUM_VECTOR_CLUSTERS(NV), .NUM_TENSOR_CLUSTERS(NT), .NUM_SRAM_BANKS(NBANKS), .NUM_SRAM_SLICES(NSL),
    .SRAM_BYTES(SRAMB), .NUM_DMA_CHANNELS(ND), .NOC_TOPOLOGY(TOPO), .EXTMEM_EN(EXT), .EXTMEM_ASYNC(EXTASYNC),
    .CONFIG_ID(CFGID), .RST_FABRIC_DELAY(FAB_DLY), .RST_CONTROL_DELAY(CTL_DLY)
  ) dut (
    .clk_i(clk), .por_ni(por_n), .pll_lock_i(pll_lock), .test_mode_i(1'b0), .boot_mode_i(boot_mode),
    .host_rst_req_i(host_rst),
    .host_req_valid_i(h_req_valid), .host_req_ready_o(h_req_ready), .host_req_write_i(h_req_write),
    .host_req_addr_i(h_req_addr), .host_req_wdata_i(h_req_wdata), .host_req_wstrb_i(h_req_wstrb),
    .host_rsp_valid_o(h_rsp_valid), .host_rsp_ready_i(h_rsp_ready), .host_rsp_rdata_o(h_rsp_rdata),
    .host_rsp_error_o(h_rsp_error), .host_irq_o(host_irq), .platform_ready_o(plat_ready), .device_ready_o(dev_ready),
    .mc_clk_i(mc_clk), .mc_rst_no(mc_rst_n), .mc_init_done_i(mc_init_done), .mc_fatal_i(mc_fatal),
    .mc_cmd_valid_o(mc_cmd_valid), .mc_cmd_ready_i(mc_cmd_ready), .mc_cmd_write_o(mc_cmd_write),
    .mc_cmd_addr_o(mc_cmd_addr), .mc_cmd_len_o(mc_cmd_len), .mc_cmd_tag_o(mc_cmd_tag),
    .mc_wd_valid_o(mc_wd_valid), .mc_wd_ready_i(mc_wd_ready), .mc_wd_data_o(mc_wd_data), .mc_wd_strb_o(mc_wd_strb),
    .mc_wd_last_o(mc_wd_last), .mc_rd_valid_i(mc_rd_valid), .mc_rd_ready_o(mc_rd_ready), .mc_rd_data_i(mc_rd_data),
    .mc_rd_tag_i(mc_rd_tag), .mc_rd_last_i(mc_rd_last), .mc_rd_error_i(mc_rd_error),
    .mc_wr_valid_i(mc_wr_valid), .mc_wr_ready_o(mc_wr_ready), .mc_wr_tag_i(mc_wr_tag), .mc_wr_error_i(mc_wr_error),
    .tck_i(1'b0), .tms_i(1'b1), .tdi_i(1'b0), .trst_ni(1'b0), .tdo_o(tdo), .tdo_oe_o(tdo_oe),
    .ext_warn_i(ext_warn), .ext_fatal_i(ext_fatal), .ras_fatal_o(ras_fatal),
    .diag_valid_o(diag_valid), .diag_char_o(diag_char), .test_done_o(test_done), .test_fail_o(test_fail),
    .test_code_o(test_code), .cpu_sleep_o(cpu_sleep));

  // ------------------------------------------------------------------ external DRAM controller (SIMULATION ONLY)
  int mc_cmd_pct = 100, mc_lat_min = 2, mc_lat_max = 12;
  int mviol, mrc, mwc, mrb, mwb, mre, mwp, mrh, mrm, cviol, ca, cb, cc_, cd;
  if (EXT != 0) begin : g_mc
    wire mclk = (EXTASYNC != 0) ? mc_clk : clk;
    // STRICT_WD = 0 behind the bridge's CDC: Project 24 contract C7 lets a write-data beat appear up to one
    // controller cycle before its command when ASYNC = 1 (same setting as Project 24's own testbench)
    extmem_sim_mc #(.DW(32), .MC_AW(MC_AW), .LW(8), .TW(2), .MB(8), .MEM_BYTES(MEMB), .OOO(1), .CAL_CYCLES(60), .SEED(5),
                    .STRICT_WD((EXTASYNC != 0) ? 0 : 1)) u_mc (
      .clk(mclk), .rst_n(mc_rst_n), .init_done(mc_init_done), .fatal(mc_fatal),
      .cmd_valid(mc_cmd_valid), .cmd_ready(mc_cmd_ready), .cmd_write(mc_cmd_write), .cmd_addr(mc_cmd_addr),
      .cmd_len(mc_cmd_len), .cmd_tag(mc_cmd_tag),
      .wd_valid(mc_wd_valid), .wd_ready(mc_wd_ready), .wd_data(mc_wd_data), .wd_strb(mc_wd_strb), .wd_last(mc_wd_last),
      .rd_valid(mc_rd_valid), .rd_ready(mc_rd_ready), .rd_data(mc_rd_data), .rd_tag(mc_rd_tag), .rd_last(mc_rd_last),
      .rd_error(mc_rd_error), .wr_valid(mc_wr_valid), .wr_ready(mc_wr_ready), .wr_tag(mc_wr_tag), .wr_error(mc_wr_error),
      .tb_cal_drop(1'b0), .tb_hang(1'b0), .tb_fatal(1'b0), .tb_poison_en(1'b0), .tb_poison_lo(32'd0), .tb_poison_hi(32'd0),
      .tb_rderr_p16(32'd0), .tb_lat_min(32'(mc_lat_min)), .tb_lat_max(32'(mc_lat_max)), .tb_cmd_rdy_pct(32'(mc_cmd_pct)),
      .tb_wd_rdy_pct(32'(mc_cmd_pct)), .tb_rsp_pct(32'(mc_cmd_pct)),
      .st_violations(mviol), .st_rd_cmds(mrc), .st_wr_cmds(mwc), .st_rd_beats(mrb), .st_wr_beats(mwb),
      .st_rderr_inj(mre), .st_wr_poisoned(mwp), .st_row_hits(mrh), .st_row_miss(mrm));
    extmem_mc_checker #(.DW(32), .MC_AW(MC_AW), .LW(8), .TW(2), .STRICT_WD((EXTASYNC != 0) ? 0 : 1), .NAME("sfmc")) u_mchk (
      .clk(mclk), .rst_n(mc_rst_n),
      .cmd_valid(mc_cmd_valid), .cmd_ready(mc_cmd_ready), .cmd_write(mc_cmd_write), .cmd_addr(mc_cmd_addr),
      .cmd_len(mc_cmd_len), .cmd_tag(mc_cmd_tag),
      .wd_valid(mc_wd_valid), .wd_ready(mc_wd_ready), .wd_data(mc_wd_data), .wd_strb(mc_wd_strb), .wd_last(mc_wd_last),
      .rd_valid(mc_rd_valid), .rd_ready(mc_rd_ready), .rd_data(mc_rd_data), .rd_tag(mc_rd_tag), .rd_last(mc_rd_last),
      .rd_error(mc_rd_error), .wr_valid(mc_wr_valid), .wr_ready(mc_wr_ready), .wr_tag(mc_wr_tag), .wr_error(mc_wr_error),
      .violations(cviol), .n_rd_cmd(ca), .n_wr_cmd(cb), .n_rd_beats(cc_), .n_wr_rsp(cd));
  end else begin : g_no_mc
    assign mc_init_done = 1'b0; assign mc_fatal = 1'b0; assign mc_cmd_ready = 1'b0; assign mc_wd_ready = 1'b0;
    assign mc_rd_valid = 1'b0;  assign mc_rd_data = '0;  assign mc_rd_tag = '0;    assign mc_rd_last = 1'b0;
    assign mc_rd_error = 1'b0;  assign mc_wr_valid = 1'b0; assign mc_wr_tag = '0;  assign mc_wr_error = 1'b0;
    initial begin mviol = 0; cviol = 0; end
  end

  // ------------------------------------------------------------------ SFB2 protocol checkers (host port + every NoC port)
  logic [31:0] pv_host, pn_a, pn_b, pn_c;
  sfb_protocol_checker #(.MAX_OUT(1), .NAME("host_port")) u_chk_host (
    .clk, .rst_n(dut.fab_rst_n), .req_valid(h_req_valid), .req_ready(h_req_ready), .req_write(h_req_write),
    .req_addr(h_req_addr), .req_wdata(h_req_wdata), .req_wstrb(h_req_wstrb), .rsp_valid(h_rsp_valid),
    .rsp_ready(h_rsp_ready), .rsp_rdata(h_rsp_rdata), .rsp_error(h_rsp_error),
    .violations(pv_host), .n_req(pn_a), .n_rsp(pn_b), .outstanding(pn_c));
  logic [31:0] pv_m [NM];
  logic [31:0] pv_t [NTG];
  for (genvar m = 0; m < NM; m++) begin : g_chk_m
    logic [31:0] a, b, c;
    sfb_protocol_checker #(.MAX_OUT(4), .NAME("noc_master")) u_chk (
      .clk, .rst_n(dut.fab_rst_n), .req_valid(dut.m_req_valid[m]), .req_ready(dut.m_req_ready[m]),
      .req_write(dut.m_req_write[m]), .req_addr(dut.m_req_addr[m*32 +: 32]), .req_wdata(dut.m_req_wdata[m*32 +: 32]),
      .req_wstrb(dut.m_req_wstrb[m*4 +: 4]), .rsp_valid(dut.m_rsp_valid[m]), .rsp_ready(dut.m_rsp_ready[m]),
      .rsp_rdata(dut.m_rsp_rdata[m*32 +: 32]), .rsp_error(dut.m_rsp_error[m]),
      .violations(pv_m[m]), .n_req(a), .n_rsp(b), .outstanding(c));
  end
  for (genvar t = 0; t < NTG; t++) begin : g_chk_t
    logic [31:0] a, b, c;
    sfb_protocol_checker #(.MAX_OUT(4), .NAME("noc_target")) u_chk (
      .clk, .rst_n(dut.fab_rst_n), .req_valid(dut.t_req_valid[t]), .req_ready(dut.t_req_ready[t]),
      .req_write(dut.t_req_write[t]), .req_addr(dut.t_req_addr[t*32 +: 32]), .req_wdata(dut.t_req_wdata[t*32 +: 32]),
      .req_wstrb(dut.t_req_wstrb[t*4 +: 4]), .rsp_valid(dut.t_rsp_valid[t]), .rsp_ready(dut.t_rsp_ready[t]),
      .rsp_rdata(dut.t_rsp_rdata[t*32 +: 32]), .rsp_error(dut.t_rsp_error[t]),
      .violations(pv_t[t]), .n_req(a), .n_rsp(b), .outstanding(c));
  end
  // accelerator side of every boundary block, in the accelerator reset domain: a stale (orphan) response
  // delivered to a freshly reset master is an R5 violation here ("response without an outstanding request")
  logic [31:0] pv_vf [NV];
  logic [31:0] pv_vs [NV];
  logic [31:0] pv_tf [NT];
  logic [31:0] pv_cc;
  for (genvar i = 0; i < NV; i++) begin : g_chk_acc_v
    logic [31:0] a, b, c, d, e, f;
    sfb_protocol_checker #(.MAX_OUT(1), .NAME("tile_dma_acc_side")) u_chk_f (
      .clk, .rst_n(dut.acc_rst_n),
      .req_valid(dut.u_compute.g_vec[i].u_vc.f_req_valid), .req_ready(dut.u_compute.g_vec[i].u_vc.f_req_ready),
      .req_write(dut.u_compute.g_vec[i].u_vc.f_req_write), .req_addr(dut.u_compute.g_vec[i].u_vc.f_req_addr),
      .req_wdata(dut.u_compute.g_vec[i].u_vc.f_req_wdata), .req_wstrb(dut.u_compute.g_vec[i].u_vc.f_req_wstrb),
      .rsp_valid(dut.u_compute.g_vec[i].u_vc.f_rsp_valid), .rsp_ready(dut.u_compute.g_vec[i].u_vc.f_rsp_ready),
      .rsp_rdata(dut.u_compute.g_vec[i].u_vc.f_rsp_rdata), .rsp_error(dut.u_compute.g_vec[i].u_vc.f_rsp_error),
      .violations(pv_vf[i]), .n_req(a), .n_rsp(b), .outstanding(c));
    sfb_protocol_checker #(.MAX_OUT(1), .NAME("tile_spm_acc_side")) u_chk_s (
      .clk, .rst_n(dut.acc_rst_n),
      .req_valid(dut.u_compute.g_vec[i].u_vc.hs_req_valid), .req_ready(dut.u_compute.g_vec[i].u_vc.hs_req_ready),
      .req_write(dut.u_compute.g_vec[i].u_vc.hs_req_write), .req_addr(dut.u_compute.g_vec[i].u_vc.hs_req_addr),
      .req_wdata(dut.u_compute.g_vec[i].u_vc.hs_req_wdata), .req_wstrb(dut.u_compute.g_vec[i].u_vc.hs_req_wstrb),
      .rsp_valid(dut.u_compute.g_vec[i].u_vc.hs_rsp_valid), .rsp_ready(dut.u_compute.g_vec[i].u_vc.hs_rsp_ready),
      .rsp_rdata(dut.u_compute.g_vec[i].u_vc.hs_rsp_rdata), .rsp_error(dut.u_compute.g_vec[i].u_vc.hs_rsp_error),
      .violations(pv_vs[i]), .n_req(d), .n_rsp(e), .outstanding(f));
  end
  for (genvar j = 0; j < NT; j++) begin : g_chk_acc_t
    logic [31:0] a, b, c;
    sfb_protocol_checker #(.MAX_OUT(4), .NAME("tensor_dma_acc_side")) u_chk (
      .clk, .rst_n(dut.acc_rst_n),
      .req_valid(dut.u_compute.g_tsu[j].u_tc.t_req_valid), .req_ready(dut.u_compute.g_tsu[j].u_tc.t_req_ready),
      .req_write(dut.u_compute.g_tsu[j].u_tc.t_req_write), .req_addr(dut.u_compute.g_tsu[j].u_tc.t_req_addr),
      .req_wdata(dut.u_compute.g_tsu[j].u_tc.t_req_wdata), .req_wstrb(dut.u_compute.g_tsu[j].u_tc.t_req_wstrb),
      .rsp_valid(dut.u_compute.g_tsu[j].u_tc.t_rsp_valid), .rsp_ready(dut.u_compute.g_tsu[j].u_tc.t_rsp_ready),
      .rsp_rdata(dut.u_compute.g_tsu[j].u_tc.t_rsp_rdata), .rsp_error(dut.u_compute.g_tsu[j].u_tc.t_rsp_error),
      .violations(pv_tf[j]), .n_req(a), .n_rsp(b), .outstanding(c));
  end
  begin : g_chk_acc_cc
    logic [31:0] a, b, c;
    sfb_protocol_checker #(.MAX_OUT(1), .NAME("cc_ext_cc_side")) u_chk (
      .clk, .rst_n(dut.acc_rst_n),
      .req_valid(dut.u_control.e_req_valid), .req_ready(dut.u_control.e_req_ready),
      .req_write(dut.u_control.e_req_write), .req_addr(dut.u_control.e_req_addr),
      .req_wdata(dut.u_control.e_req_wdata), .req_wstrb(dut.u_control.e_req_wstrb),
      .rsp_valid(dut.u_control.e_rsp_valid), .rsp_ready(dut.u_control.e_rsp_ready),
      .rsp_rdata(dut.u_control.e_rsp_rdata), .rsp_error(dut.u_control.e_rsp_error),
      .violations(pv_cc), .n_req(a), .n_rsp(b), .outstanding(c));
  end
  // coverage: an accelerator reset that hits while a fence holds a request the fabric has not accepted
  // (the fence must keep presenting it from its registered copy -- SFB2 R2)
  int held_at_reset = 0;
  for (genvar j = 0; j < NT; j++) begin : g_cov_hold_t
    always @(negedge dut.acc_rst_n) if (dut.u_compute.g_tsu[j].u_tc.u_dma_fence.hold_q) held_at_reset++;
  end
  for (genvar i = 0; i < NV; i++) begin : g_cov_hold_v
    always @(negedge dut.acc_rst_n) if (dut.u_compute.g_vec[i].u_vc.u_dma_fence.hold_q) held_at_reset++;
  end
  // coverage: scratchpad-window accesses abandoned by a gate because the accelerator domain was reset
  // while the access was outstanding at the tile
  int spm_abandoned = 0;
  for (genvar i = 0; i < NV; i++) begin : g_cov_aband
    always @(posedge clk) if (dut.u_compute.g_vec[i].u_vc.u_spm_gate.abandoned_evt) spm_abandoned++;
  end
  function automatic int proto_violations();
    int v = int'(pv_host) + int'(pv_cc);
    for (int m = 0; m < NM; m++) v += int'(pv_m[m]);
    for (int t = 0; t < NTG; t++) v += int'(pv_t[t]);
    for (int i = 0; i < NV; i++) v += int'(pv_vf[i]) + int'(pv_vs[i]);
    for (int j = 0; j < NT; j++) v += int'(pv_tf[j]);
    if (EXT != 0) v += mviol + cviol;
    return v;
  endfunction

  // ------------------------------------------------------------------ console (ControlCore diagnostic port)
  string line = "";
  always @(posedge clk) if (diag_valid) begin
    if (diag_char == 8'h0A) begin $display("[%0d] FW| %s", cyc, line); line = ""; end
    else line = {line, string'(diag_char)};
  end

  // ------------------------------------------------------------------ optional fabric trace (+define+TB_FABDBG, +fabdbg)
`ifdef TB_FABDBG
  bit fabdbg;
  initial fabdbg = $test$plusargs("fabdbg");
  always @(posedge clk) if (fabdbg) begin
    for (int m = 0; m < NM; m++) begin
      if (dut.m_req_valid[m] && dut.m_req_ready[m])
        $display("[%0d] FAB m%0d req %s a=%08h d=%08h s=%h", cyc, m, dut.m_req_write[m] ? "W" : "R",
                 dut.m_req_addr[m*32 +: 32], dut.m_req_wdata[m*32 +: 32], dut.m_req_wstrb[m*4 +: 4]);
      if (dut.m_rsp_valid[m] && dut.m_rsp_ready[m])
        $display("[%0d] FAB m%0d rsp d=%08h e=%0d", cyc, m, dut.m_rsp_rdata[m*32 +: 32], dut.m_rsp_error[m]);
      if (dut.m_req_valid[m] && !dut.m_req_ready[m] && (cyc % 1000 == 0))
        $display("[%0d] FAB m%0d STALLED req a=%08h", cyc, m, dut.m_req_addr[m*32 +: 32]);
    end
  end
`endif

  // ------------------------------------------------------------------ reset-stage monitor (deterministic sequence)
  logic [2:0]      stage_prev = 3'd0;
  longint unsigned stage_at [4];
  longint unsigned stage_at_lock;
  always @(negedge clk) begin
    if (dut.rst_stage != stage_prev) stage_at[dut.rst_stage] = cyc;
    stage_prev = dut.rst_stage;
  end

  // ------------------------------------------------------------------ bookkeeping
  int fails = 0, checks = 0, bp_pct = 0;
  string cur_test = "";
  task automatic check(input string what, input logic [31:0] got, input logic [31:0] exp);
    checks++;
    if (got !== exp) begin
      fails++;
      $display("[%0d] CHECK FAIL [%s] %s: got %08h exp %08h", cyc, cur_test, what, got, exp);
    end
  endtask
  task automatic check_true(input string what, input bit cond);
    check(what, 32'(cond), 32'd1);
  endtask

  // ------------------------------------------------------------------ host BFM
  // Drive at negedge, sample after settling; the handshake happens at the next posedge.
  task automatic hacc(input bit wr, input logic [31:0] a, input logic [31:0] wd, input logic [3:0] strb,
                      output logic [31:0] rd, output bit err);
    @(negedge clk);
    h_req_valid = 1'b1; h_req_write = wr; h_req_addr = a; h_req_wdata = wd; h_req_wstrb = strb;
    h_rsp_ready = (bp_pct == 0) || (($urandom % 100) >= bp_pct);
    #1;
    while (!h_req_ready) begin
      @(negedge clk); h_rsp_ready = (bp_pct == 0) || (($urandom % 100) >= bp_pct); #1;
    end
    @(posedge clk); #1;
    h_req_valid = 1'b0;
    while (!(h_rsp_valid && h_rsp_ready)) begin
      @(negedge clk); h_rsp_ready = (bp_pct == 0) || (($urandom % 100) >= bp_pct); #1;
    end
    rd = h_rsp_rdata; err = h_rsp_error;
    @(posedge clk); #1;
  endtask
  task automatic hw(input logic [31:0] a, input logic [31:0] d);
    logic [31:0] r; bit e;
    hacc(1'b1, a, d, 4'hF, r, e);
    if (e) begin fails++; $display("[%0d] FAIL [%s] host write %08h refused", cyc, cur_test, a); end
  endtask
  task automatic hr(input logic [31:0] a, output logic [31:0] d);
    bit e;
    hacc(1'b0, a, 32'd0, 4'hF, d, e);
    if (e) begin fails++; $display("[%0d] FAIL [%s] host read %08h refused", cyc, cur_test, a); end
  endtask
  task automatic hchk(input string what, input logic [31:0] a, input logic [31:0] exp);
    logic [31:0] v;
    hr(a, v);
    check(what, v, exp);
  endtask
  task automatic expect_err(input string what, input bit wr, input logic [31:0] a);
    logic [31:0] r; bit e;
    hacc(wr, a, 32'h1234_5678, 4'hF, r, e);
    check({what, " -> error response"}, 32'(e), 1);
    check({what, " -> rdata 0"}, r, 0);
  endtask

  function automatic logic [31:0] vec_reg(input int i, input logic [11:0] o);
    return DIE_PAGE_BASE + 32'(vec_page(i)) * 32'h1000 + 32'(o);
  endfunction
  function automatic logic [31:0] tsu_reg(input int j, input logic [11:0] o);
    return DIE_PAGE_BASE + 32'(tsu_page(j)) * 32'h1000 + 32'(o);
  endfunction
  function automatic logic [31:0] dma_reg(input int c, input logic [11:0] o);
    return DMAP + 32'(c) * 32'(DIE_DMA_CH_STRIDE) + 32'(o);
  endfunction
  function automatic logic [31:0] spm(input int i, input logic [31:0] o);
    return DIE_VEC_SPM_BASE + 32'(i) * DIE_VEC_SPM_STRIDE + o;
  endfunction

  task automatic wait_cond_irq(input string what, input longint tmo);
    longint t0 = cyc;
    while (!host_irq) begin
      @(posedge clk);
      if (cyc - t0 > tmo) begin fails++; $display("[%0d] FAIL [%s] timeout waiting for host IRQ (%s)", cyc, cur_test, what); return; end
    end
  endtask

  // exact single-precision bits of a small integer
  function automatic logic [31:0] f32_int(input int v);
    int s, e, m, a;
    if (v == 0) return 32'h0;
    s = v < 0; a = s ? -v : v; e = 0;
    while ((a >> e) > 1) e++;
    m = (a << (23 - e)) & 32'h7FFFFF;
    return {s[0], 8'(127 + e), m[22:0]};
  endfunction

  // ------------------------------------------------------------------ accelerator helpers
  // vector tile KERNEL: D = A op B over vl FP32 elements staged through the tile scratchpad
  task automatic vec_submit(input int i, input logic [4:0] op, input int vl, input logic [31:0] a, input logic [31:0] b,
                            input logic [31:0] d, input logic [31:0] stage, input logic [7:0] tag);
    hw(vec_reg(i, HPC_CMD0 + 0),  {8'h00, tag, 1'b0, 3'd0, 3'd0, op, 4'h3});   // KERNEL, RNE
    hw(vec_reg(i, HPC_CMD0 + 4),  32'(vl));
    hw(vec_reg(i, HPC_CMD0 + 8),  32'd0);
    hw(vec_reg(i, HPC_CMD0 + 12), a);
    hw(vec_reg(i, HPC_CMD0 + 16), b);
    hw(vec_reg(i, HPC_CMD0 + 20), 32'd0);
    hw(vec_reg(i, HPC_CMD0 + 24), d);
    hw(vec_reg(i, HPC_CMD0 + 28), stage);
    hw(vec_reg(i, HPC_DOORBELL), 32'd0);
  endtask
  task automatic vec_wait(input int i, input longint tmo, output logic [31:0] info, output logic [31:0] count);
    longint t0 = cyc;
    hr(vec_reg(i, HPC_CPL_INFO), info);
    while (!info[31]) begin                            // (no `break`: Icarus 12)
      if (cyc - t0 > tmo) begin fails++; $display("[%0d] FAIL [%s] vector tile %0d completion timeout", cyc, cur_test, i); return; end
      repeat (20) @(posedge clk);
      hr(vec_reg(i, HPC_CPL_INFO), info);
    end
    hr(vec_reg(i, HPC_CPL_COUNT), count);
    hw(vec_reg(i, HPC_CPL_POP), 32'd0);
  endtask

  // tensor unit GEMM (ABI v2): C[MxN] int32 = A[MxK] int8 * B[KxN] int8, row major, in shared SRAM
  task automatic tsu_submit(input int j, input logic [7:0] tid, input int m, input int n, input int k,
                            input logic [31:0] a, input logic [31:0] b, input logic [31:0] c, input bit irq);
    logic [31:0] d [12];
    d[0] = 32'h40 | (32'd2 << 8) | (32'(irq) << 16) | (32'(tid) << 24);
    d[1] = a; d[2] = b; d[3] = c;
    d[4] = 32'(m) | (32'(n) << 16);  d[5] = 32'(k);
    d[6] = 32'(k); d[7] = 32'(n); d[8] = 32'(4 * n);
    d[9] = 0; d[10] = 0; d[11] = 0;
    for (int w = 0; w < 12; w++) hw(tsu_reg(j, TSU_DESC0 + 12'(4 * w)), d[w]);
    hw(tsu_reg(j, TSU_DOORBELL), 32'd1);
  endtask
  task automatic tsu_wait(input int j, input longint tmo, output logic [31:0] rec [6]);
    logic [31:0] st; longint t0 = cyc;
    hr(tsu_reg(j, TSU_STATUS), st);
    while (!st[4]) begin                              // CPL_VALID
      if (cyc - t0 > tmo) begin fails++; $display("[%0d] FAIL [%s] tensor unit %0d completion timeout", cyc, cur_test, j); return; end
      repeat (50) @(posedge clk);
      hr(tsu_reg(j, TSU_STATUS), st);
    end
    for (int w = 0; w < 6; w++) hr(tsu_reg(j, TSU_CPL0 + 12'(4 * w)), rec[w]);
    hw(tsu_reg(j, TSU_CPL_POP), 32'd1);
  endtask

  // GEMM operand generation + front-door load, and checking against the reference
  task automatic gemm_load(input int m, input int n, input int k, input logic [31:0] a, input logic [31:0] b,
                           input logic [31:0] c, ref byte av[], ref byte bv[]);
    av = new[m * k]; bv = new[k * n];
    foreach (av[i]) av[i] = byte'($urandom);
    foreach (bv[i]) bv[i] = byte'($urandom);
    for (int i = 0; i < m * k; i += 4)
      hw(a + 32'(i), {(i+3 < m*k) ? av[i+3] : 8'h0, (i+2 < m*k) ? av[i+2] : 8'h0, (i+1 < m*k) ? av[i+1] : 8'h0, av[i]});
    for (int i = 0; i < k * n; i += 4)
      hw(b + 32'(i), {(i+3 < k*n) ? bv[i+3] : 8'h0, (i+2 < k*n) ? bv[i+2] : 8'h0, (i+1 < k*n) ? bv[i+1] : 8'h0, bv[i]});
    for (int i = 0; i < m * n; i++) hw(c + 32'(4 * i), 32'hDEAD_BEEF);
  endtask
  task automatic gemm_check(input string what, input int m, input int n, input int k, input logic [31:0] c,
                            ref byte av[], ref byte bv[]);
    int bad = 0; logic [31:0] v;
    for (int i = 0; i < m; i++)
      for (int jj = 0; jj < n; jj++) begin
        int s = 0;
        for (int x = 0; x < k; x++) s += int'(av[i * k + x]) * int'(bv[x * n + jj]);
        hr(c + 32'(4 * (i * n + jj)), v);
        if (v !== 32'(s)) begin
          if (bad < 4) $display("  %s C[%0d][%0d] got %08h exp %08h", what, i, jj, v, 32'(s));
          bad++;
        end
      end
    check({what, ": C mismatches vs reference"}, 32'(bad), 0);
  endtask

  // die DMA channel copy (polling or IRQ)
  task automatic dma_start(input int c, input logic [31:0] src, input logic [31:0] dst, input int len, input bit irq);
    hw(dma_reg(c, DMA_INT_ST), 32'h3);                  // clear stale status
    hw(dma_reg(c, DMA_INT_EN), irq ? 32'h3 : 32'h0);
    hw(dma_reg(c, DMA_SRC), src);
    hw(dma_reg(c, DMA_DST), dst);
    hw(dma_reg(c, DMA_LENGTH), 32'(len));
    hw(dma_reg(c, DMA_CONTROL), 32'h1);
  endtask
  task automatic dma_wait(input int c, input longint tmo, output logic [31:0] st);
    longint t0 = cyc;
    hr(dma_reg(c, DMA_STATUS), st);
    while (st[0]) begin                               // BUSY
      if (cyc - t0 > tmo) begin fails++; $display("[%0d] FAIL [%s] DMA %0d timeout", cyc, cur_test, c); return; end
      repeat (20) @(posedge clk);
      hr(dma_reg(c, DMA_STATUS), st);
    end
  endtask

  // boot ROM progress as a host sees it (SYSCTRL.BOOT_STAGE polling)
  task automatic wait_boot_stage(input logic [31:0] st, input longint tmo);
    logic [31:0] v; longint t0 = cyc;
    hr(CC_SYSCTRL_BASE + 32'(CC_SYSCTRL_BOOT_STAGE), v);
    while (v != st) begin
      if (cyc - t0 > tmo) begin fails++; $display("[%0d] FAIL [%s] boot stage %0h not reached (at %0h)", cyc, cur_test, st, v); return; end
      repeat (500) @(posedge clk);
      hr(CC_SYSCTRL_BASE + 32'(CC_SYSCTRL_BOOT_STAGE), v);
    end
    checks++;
    $display("[%0d] ControlCore boot ROM at stage %0h", cyc, st);
  endtask

  // ------------------------------------------------------------------ bring-up
  task automatic power_on(input int extra_cycles);
    @(negedge clk); por_n = 1'b0; pll_lock = 1'b0;
    repeat (8) @(negedge clk);
    por_n = 1'b1;
    repeat (10) @(negedge clk);
    pll_lock = 1'b1; stage_at_lock = cyc;
    wait (plat_ready === 1'b1);
    repeat (extra_cycles) @(posedge clk);
  endtask
  task automatic wait_extmem_ready();
    logic [31:0] v; longint t0 = cyc;
    if (EXT == 0) return;
    hr(SYS + 32'(DIE_SYS_STATUS), v);
    while (!v[DIE_ST_EXTMEM_READY]) begin
      if (cyc - t0 > 20000) begin fails++; $display("FAIL extmem link never came up"); return; end
      repeat (50) @(posedge clk);
      hr(SYS + 32'(DIE_SYS_STATUS), v);
    end
  endtask

  // ================================================================== tests
  task automatic t_identity();
    logic [31:0] v;
    cur_test = "identity";
    hchk("DIE_SYS.ID", SYS + 32'(DIE_SYS_ID), DIE_ID);
    hchk("DIE_SYS.HW_VERSION", SYS + 32'(DIE_SYS_HW_VERSION), DIE_HW_VERSION);
    hchk("DIE_SYS.MAP_VERSION", SYS + 32'(DIE_SYS_MAP_VERSION), DIE_MAP_VERSION);
    hchk("DIE_SYS.CONFIG_ID", SYS + 32'(DIE_SYS_CONFIG_ID), 32'(CFGID));
    hr(SYS + 32'(DIE_SYS_CFG0), v);
    check("CFG0.vector clusters", 32'(v[3:0]), NV);
    check("CFG0.tensor clusters", 32'(v[7:4]), NT);
    check("CFG0.SRAM banks", 32'(v[15:8]), NBANKS);
    check("CFG0.SRAM slices", 32'(v[19:16]), NSL);
    check("CFG0.DMA channels", 32'(v[23:20]), ND);
    check("CFG0.NoC topology", 32'(v[25:24]), TOPO);
    check("CFG0.EXTMEM", 32'(v[26]), EXT);
    hchk("DIE_SYS.SRAM_BYTES", SYS + 32'(DIE_SYS_SRAM_BYTES), SRAMB);
    hr(SYS + 32'(DIE_SYS_FABRIC), v);
    check("FABRIC.NoC masters", 32'(v[7:0]), NM);
    check("FABRIC.NoC targets", 32'(v[15:8]), NTG);
    hchk("TSU_ARRAY 4x4, 4 lanes", SYS + 32'(DIE_SYS_TSU_ARRAY), 32'h0004_0404);
    // the NoC's own view of the fabric (sfn_perf CONFIG register)
    hr(NOCP + 32'h18, v);
    check("NoC CONFIG.NM", 32'(v[7:0]), NM);
    check("NoC CONFIG.NT", 32'(v[15:8]), NTG);
    check("NoC CONFIG.topology", 32'(v[25:24]), TOPO);
    // ControlCore
    hchk("ControlCore SYSCTRL.ID", CC_SYSCTRL_BASE + 32'(CC_SYSCTRL_ID), CC_SYSCTRL_ID_RST);
    // every populated accelerator instance answers on its page with its real ID; SPM bases distinct
    for (int i = 0; i < NV; i++) begin
      hchk($sformatf("vector tile %0d ID", i), vec_reg(i, HPC_ID), HPC_TILE_ID);
      hchk($sformatf("vector tile %0d SPM_BASE", i), vec_reg(i, HPC_SPM_BASE), spm(i, 0));
    end
    for (int j = 0; j < NT; j++) begin
      hchk($sformatf("tensor unit %0d ID", j), tsu_reg(j, TSU_ID), TSU_ID_VALUE);
      hchk($sformatf("tensor unit %0d MEM_LO", j), tsu_reg(j, TSU_MEM_LO), SRAM);
      hchk($sformatf("tensor unit %0d MEM_LAST", j), tsu_reg(j, TSU_MEM_LAST), SRAM + 32'(SRAMB) - 1);
      hr(tsu_reg(j, TSU_INFO), v);
      check($sformatf("tensor unit %0d array 4x4", j), {16'd0, v[23:16], v[15:8]}, 32'h0404);
    end
    for (int c = 0; c < ND; c++) hchk($sformatf("die DMA %0d ID", c), dma_reg(c, DMA_ID), 32'h5346_4446);
    // unpopulated instance pages / channels are refused, never aliased
    for (int i = NV; i < LIM_MAX_VECTOR_CLUSTERS; i++) expect_err($sformatf("absent vector page %0d", vec_page(i)), 1'b0, vec_reg(i, HPC_ID));
    for (int j = NT; j < LIM_MAX_TENSOR_CLUSTERS; j++) expect_err($sformatf("absent tensor page %0d", tsu_page(j)), 1'b0, tsu_reg(j, TSU_ID));
    for (int c = ND; c < LIM_MAX_DMA_CHANNELS; c++) expect_err($sformatf("absent DMA channel %0d", c), 1'b0, dma_reg(c, DMA_ID));
    expect_err("forwarded page 14 (not populated)", 1'b0, DIE_PAGE_BASE + 32'he000);
    expect_err("forwarded page 15 (not populated)", 1'b0, DIE_PAGE_BASE + 32'hf000);
    expect_err("DIE_REGS page 3 (not populated)", 1'b0, DIE_DIE_REGS_BASE + 32'h3000);
    begin
      logic [31:0] r; bit e;
      hacc(1'b1, SYS + 32'(DIE_SYS_SCRATCH), 32'hFFFF_FFFF, 4'b0011, r, e);
      check("DIE_REGS sub-word write refused", 32'(e), 1);
      hchk("DIE_REGS sub-word write had no effect", SYS + 32'(DIE_SYS_SCRATCH), 32'h0);
    end
  endtask

  task automatic t_regs();
    logic [31:0] v; bit e;
    cur_test = "regs";
    hw(SYS + 32'(DIE_SYS_SCRATCH), 32'hA5A5_5A5A);
    hchk("SCRATCH write/read", SYS + 32'(DIE_SYS_SCRATCH), 32'hA5A5_5A5A);
    hw(SYS + 32'(DIE_SYS_SCRATCH), 32'h0F0F_F0F0);
    hchk("SCRATCH write/read 2", SYS + 32'(DIE_SYS_SCRATCH), 32'h0F0F_F0F0);
    expect_err("write to read-only DIE_SYS.ID", 1'b1, SYS + 32'(DIE_SYS_ID));
    hchk("ID unchanged after refused write", SYS + 32'(DIE_SYS_ID), DIE_ID);
    expect_err("unmapped DIE_SYS offset 0x0F0", 1'b0, SYS + 32'h0F0);
    expect_err("unmapped DIE_SYS offset 0x400", 1'b0, SYS + 32'h400);
    hw(SYS + 32'(DIE_SYS_IRQ_HOST_EN), 32'h0001_0000);
    hchk("IRQ_HOST_EN RW", SYS + 32'(DIE_SYS_IRQ_HOST_EN), 32'h0001_0000);
    hw(SYS + 32'(DIE_SYS_IRQ_HOST_EN), 32'h0);
    hchk("IRQ_CC_VEC_EN reset = all vector tiles", SYS + 32'(DIE_SYS_IRQ_CC_VEC_EN), 32'((1 << NV) - 1) << DIE_IRQ_VEC);
    hchk("IRQ_CC_TSU_EN reset = all tensor units", SYS + 32'(DIE_SYS_IRQ_CC_TSU_EN), 32'((1 << NT) - 1) << DIE_IRQ_TSU);
    hchk("ERR_CTRL reset (forward errors)", SYS + 32'(DIE_SYS_ERR_CTRL), 32'h2);
    hr(SYS + 32'(DIE_SYS_TEST_STATUS), v);
    check("TEST_STATUS: PLL locked, not in test mode", v & 32'h3, 32'h2);
    // ControlCore registers through the same host path; sub-word write refused by its bridge
    hw(CC_SYSCTRL_BASE + 32'(CC_SYSCTRL_SCRATCH0), 32'h1357_9BDF);
    hchk("ControlCore SCRATCH0", CC_SYSCTRL_BASE + 32'(CC_SYSCTRL_SCRATCH0), 32'h1357_9BDF);
    hacc(1'b1, CC_SYSCTRL_BASE + 32'(CC_SYSCTRL_SCRATCH0), 32'h0, 4'h1, v, e);
    check("ControlCore sub-word register write refused", 32'(e), 1);
    // CC register visibility of the die page through the ControlCore crossbar (host -> CC -> acc_rb -> die)
    hchk("die page reached through the ControlCore bridge", SYS + 32'(DIE_SYS_ID), DIE_ID);
    // refused writes must have no side effect: an offset outside the DMA channel blocks must not alias a channel
    hw(dma_reg(0, DMA_SRC), 32'h2000_1000);
    expect_err("DMA page offset 0x408 (outside every channel block)", 1'b1, DMAP + 32'h408);
    expect_err("DMA page offset 0x808 (outside every channel block)", 1'b1, DMAP + 32'h808);
    hchk("refused DMA-page writes left channel 0 SRC_ADDR untouched", dma_reg(0, DMA_SRC), 32'h2000_1000);
    expect_err("write to read-only DMA ID", 1'b1, dma_reg(0, DMA_ID));
    // clear any errors this test produced
    hw(SYS + 32'(DIE_SYS_ERR_STATUS), 32'hFFFF_FFFF);
    hw(SYS + 32'(DIE_SYS_ERR_CTRL), 32'h3);
  endtask

  task automatic t_reset();
    logic [31:0] v;
    cur_test = "reset";
    // PLL lock driven at a negedge: 2-flop synchroniser (2 edges), then FABRIC_DELAY + 1 counting edges
    check("stage POR -> FABRIC: FABRIC_DELAY + 3 cycles after PLL lock", 32'(stage_at[1] - stage_at_lock), FAB_DLY + 3);
    check("stage FABRIC -> CONTROL after CONTROL_DELAY+1 cycles", 32'(stage_at[2] - stage_at[1]), CTL_DLY + 1);
    check("stage CONTROL -> RUN after 1 cycle", 32'(stage_at[3] - stage_at[2]), 1);
    hchk("RESET_STAGE = RUN", SYS + 32'(DIE_SYS_RESET_STAGE), 32'(DIE_RST_STAGE_RUN));
    hr(SYS + 32'(DIE_SYS_STATUS), v);
    check("STATUS.RESET_DONE", 32'(v[DIE_ST_RESET_DONE]), 1);
    check("STATUS.FABRIC_READY", 32'(v[DIE_ST_FABRIC_READY]), 1);
    check("STATUS.MEM_READY", 32'(v[DIE_ST_MEM_READY]), 1);
    check("STATUS.CC_RUNNING", 32'(v[DIE_ST_CC_RUNNING]), 1);
    check("STATUS.COMPUTE_READY", 32'(v[DIE_ST_COMPUTE_READY]), 1);
    check("STATUS.PLATFORM_READY", 32'(v[DIE_ST_PLATFORM_READY]), 1);
    check("STATUS.FW_HOST_READY = 0 (no firmware loaded)", 32'(v[DIE_ST_FW_HOST_READY]), 0);
    check("STATUS.DEVICE_READY = 0 (no firmware loaded)", 32'(v[DIE_ST_DEVICE_READY]), 0);
    check("device_ready_o pin low without firmware", 32'(dev_ready), 0);
    hr(SYS + 32'(DIE_SYS_PLATFORM_CYC), v);
    $display("  PLATFORM_CYC = %0d cycles from fabric release (deterministic, configuration %0d)", v, CFGID);
    // platform ready = SRAM initialisation sweep (one row per cycle, all banks in parallel) + sequencer
    check_true("PLATFORM_CYC = SRAM init sweep (bank depth) + a few cycles", v >= 32'(BANK_DEPTH) && v < 32'(BANK_DEPTH + 64));
    hchk("SRAM initialised to zero (first word)", SRAM, 32'h0);
    hchk("SRAM initialised to zero (last word)", SRAM + 32'(SRAMB) - 4, 32'h0);
    wait_boot_stage(CC_BOOT_STAGE_WAIT_IMAGE, 3_000_000);
  endtask

  task automatic t_sram();
    logic [31:0] v, a; bit e;
    int slice = SRAMB / NSL;
    cur_test = "sram";
    for (int s = 0; s < NSL; s++) begin
      a = SRAM + 32'(s * slice);
      hw(a, 32'h5100_0000 + 32'(s));
      hw(a + 32'(slice) - 4, 32'h51FF_0000 + 32'(s));
      hw(a + 32'h1234 * 4, ~(32'h1234 + 32'(s)));
    end
    for (int s = 0; s < NSL; s++) begin
      a = SRAM + 32'(s * slice);
      hchk($sformatf("slice %0d first word", s), a, 32'h5100_0000 + 32'(s));
      hchk($sformatf("slice %0d last word", s), a + 32'(slice) - 4, 32'h51FF_0000 + 32'(s));
      hchk($sformatf("slice %0d middle word", s), a + 32'h1234 * 4, ~(32'h1234 + 32'(s)));
    end
    // byte strobes (no read-modify-write visible to software)
    hw(SRAM + 32'h100, 32'h1122_3344);
    hacc(1'b1, SRAM + 32'h100, 32'hAABB_CCDD, 4'b0101, v, e);
    check("byte-strobe write accepted", 32'(e), 0);
    hchk("byte strobes 0101", SRAM + 32'h100, 32'h11BB_33DD);
    hacc(1'b1, SRAM + 32'h100, 32'h9900_0000, 4'b1000, v, e);
    hchk("byte strobe 1000", SRAM + 32'h100, 32'h99BB_33DD);
    // a walk across bank interleave (consecutive words hit consecutive banks)
    for (int i = 0; i < 32; i++) hw(SRAM + 32'h2000 + 32'(4 * i), 32'hB000_0000 + 32'(i * 3));
    for (int i = 0; i < 32; i++) hchk("bank walk", SRAM + 32'h2000 + 32'(4 * i), 32'hB000_0000 + 32'(i * 3));
  endtask

  task automatic t_dma();
    logic [31:0] st, v, src, dst;
    cur_test = "dma";
    for (int c = 0; c < ND; c++) begin
      src = SRAM + 32'h4_0000 + 32'(c) * 32'h1000; dst = SRAM + 32'h4_8000 + 32'(c) * 32'h1000;
      if (NSL > 1) dst = SRAM + 32'(SRAMB / NSL) * 32'(NSL - 1) + 32'h8000 + 32'(c) * 32'h1000;   // across slices
      for (int i = 0; i < 128; i++) hw(src + 32'(4 * i), 32'hD0A0_0000 + 32'(c << 12) + 32'(i));
      for (int i = 0; i < 128; i++) hw(dst + 32'(4 * i), 32'h0);
      hw(SYS + 32'(DIE_SYS_IRQ_HOST_EN), 32'(1) << (DIE_IRQ_DMA + c));
      dma_start(c, src, dst, 512, 1'b1);
      wait_cond_irq($sformatf("DMA %0d done", c), 100000);
      hchk($sformatf("DMA %0d IRQ_HOST_STATUS", c), SYS + 32'(DIE_SYS_IRQ_HOST_STATUS), 32'(1) << (DIE_IRQ_DMA + c));
      hr(dma_reg(c, DMA_STATUS), st);
      check($sformatf("DMA %0d STATUS done, no error", c), st & 32'hF, 32'h2);
      hchk($sformatf("DMA %0d BYTES_DONE", c), dma_reg(c, DMA_BYTES_DONE), 512);
      hw(dma_reg(c, DMA_INT_ST), 32'h3);
      repeat (2) @(posedge clk);
      check($sformatf("DMA %0d host IRQ cleared by W1C", c), 32'(host_irq), 0);
      begin
        int bad = 0;
        for (int i = 0; i < 128; i++) begin hr(dst + 32'(4 * i), v); if (v !== 32'hD0A0_0000 + 32'(c << 12) + 32'(i)) bad++; end
        check($sformatf("DMA %0d SRAM->SRAM copy mismatches", c), 32'(bad), 0);
      end
      // SRAM -> vector scratchpad window -> SRAM
      dma_start(c, src, spm(c % NV, 32'h8000), 256, 1'b0);
      dma_wait(c, 100000, st);
      check("DMA to SPM ok", st & 32'hF, 32'h2);
      for (int i = 0; i < 64; i++) hchk("SPM content after DMA", spm(c % NV, 32'h8000) + 32'(4 * i), 32'hD0A0_0000 + 32'(c << 12) + 32'(i));
      dma_start(c, spm(c % NV, 32'h8000), dst + 32'h800, 256, 1'b0);
      dma_wait(c, 100000, st);
      check("DMA from SPM ok", st & 32'hF, 32'h2);
      for (int i = 0; i < 64; i += 7) hchk("SRAM after SPM->SRAM", dst + 32'h800 + 32'(4 * i), 32'hD0A0_0000 + 32'(c << 12) + 32'(i));
    end
    hw(SYS + 32'(DIE_SYS_IRQ_HOST_EN), 32'h0);
  endtask

  task automatic t_vector();
    logic [31:0] info, cnt, v, A, B, D;
    int vl = 48, bad;
    cur_test = "vector";
    for (int i = 0; i < NV; i++) begin
      A = SRAM + 32'h9_0000 + 32'(i) * 32'h4000; B = A + 32'h1000; D = A + 32'h2000;
      for (int x = 0; x < vl; x++) begin
        hw(A + 32'(4 * x), f32_int(x - 7 + i)); hw(B + 32'(4 * x), f32_int(3 * x)); hw(D + 32'(4 * x), 32'hFFFF_FFFF);
      end
      // FADD with completion interrupt routed to the host
      hw(vec_reg(i, HPC_IRQ_STATUS), 32'h7);
      hw(vec_reg(i, HPC_IRQ_EN), 32'h1);
      hw(SYS + 32'(DIE_SYS_IRQ_HOST_EN), 32'(1) << (DIE_IRQ_VEC + i));
      vec_submit(i, 5'h01, vl, A, B, D, spm(i, 32'h4000), 8'h70 + 8'(i));
      wait_cond_irq($sformatf("vector tile %0d completion", i), 200000);
      hr(vec_reg(i, HPC_IRQ_STATUS), v);
      check($sformatf("tile %0d IRQ_STATUS.CPL", i), v & 32'h1, 32'h1);
      vec_wait(i, 200000, info, cnt);
      check($sformatf("tile %0d FADD status OK", i), 32'(info[11:8]), 0);
      check($sformatf("tile %0d FADD tag", i), 32'(info[7:0]), 32'h70 + 32'(i));
      check($sformatf("tile %0d FADD count", i), cnt, 32'(vl));
      hw(vec_reg(i, HPC_IRQ_STATUS), 32'h7);
      repeat (2) @(posedge clk);
      check($sformatf("tile %0d host IRQ released", i), 32'(host_irq), 0);
      bad = 0;
      for (int x = 0; x < vl; x++) begin hr(D + 32'(4 * x), v); if (v !== f32_int(4 * x - 7 + i)) bad++; end
      check($sformatf("tile %0d FADD D vs reference", i), 32'(bad), 0);
      // FMUL by polling
      for (int x = 0; x < vl; x++) begin hw(A + 32'(4 * x), f32_int((x % 13) - 6)); hw(B + 32'(4 * x), f32_int((x % 7) + 1 + i)); end
      vec_submit(i, 5'h03, vl, A, B, D, spm(i, 32'h4000), 8'h80 + 8'(i));
      vec_wait(i, 200000, info, cnt);
      check($sformatf("tile %0d FMUL status OK", i), 32'(info[11:8]), 0);
      bad = 0;
      for (int x = 0; x < vl; x++) begin hr(D + 32'(4 * x), v); if (v !== f32_int(((x % 13) - 6) * ((x % 7) + 1 + i))) bad++; end
      check($sformatf("tile %0d FMUL D vs reference", i), 32'(bad), 0);
      hw(vec_reg(i, HPC_IRQ_EN), 32'h0);
    end
    hw(SYS + 32'(DIE_SYS_IRQ_HOST_EN), 32'h0);
  endtask

  task automatic t_gemm();
    byte av[], bv[];
    logic [31:0] rec [6];
    int shapes [3][3] = '{'{4, 4, 4}, '{9, 11, 40}, '{16, 8, 24}};
    cur_test = "gemm";
    for (int j = 0; j < NT; j++) begin
      hw(tsu_reg(j, TSU_INT_ST), 32'h7);
      hw(tsu_reg(j, TSU_INT_EN), 32'h4);                 // DONE
      for (int s = 0; s < 3; s++) begin
        int m = shapes[s][0], n = shapes[s][1], k = shapes[s][2];
        logic [31:0] A = SRAM + 32'h8_0000 + 32'(j) * 32'h1_0000, B = A + 32'h4000, C = A + 32'h8000;
        gemm_load(m, n, k, A, B, C, av, bv);
        hw(SYS + 32'(DIE_SYS_IRQ_HOST_EN), 32'(1) << (DIE_IRQ_TSU + j));
        tsu_submit(j, 8'h90 + 8'(s), m, n, k, A, B, C, 1'b1);
        wait_cond_irq($sformatf("tensor unit %0d GEMM", j), 2000000);
        tsu_wait(j, 2000000, rec);
        check($sformatf("tsu %0d GEMM %0dx%0dx%0d status OK", j, m, n, k), 32'(rec[0][25:24]), 0);
        check($sformatf("tsu %0d GEMM err code", j), 32'(rec[0][23:16]), 0);
        check($sformatf("tsu %0d GEMM tid", j), 32'(rec[0][7:0]), 32'h90 + 32'(s));
        check($sformatf("tsu %0d GEMM count (bytes written)", j), rec[1], 32'(4 * m * n));
        hw(tsu_reg(j, TSU_INT_ST), 32'h7);
        gemm_check($sformatf("tsu %0d GEMM %0dx%0dx%0d", j, m, n, k), m, n, k, C, av, bv);
      end
    end
    hw(SYS + 32'(DIE_SYS_IRQ_HOST_EN), 32'h0);
  endtask

  task automatic t_irq();
    logic [31:0] v, info, cnt;
    cur_test = "irq";
    // tile completion -> die IRQ_RAW -> ControlCore VECTOR source (INTC PENDING) via IRQ_CC_VEC_EN
    hw(vec_reg(0, HPC_IRQ_STATUS), 32'h7);
    hw(vec_reg(0, HPC_IRQ_EN), 32'h1);
    hw(vec_reg(0, HPC_CMD0), {8'h00, 8'h55, 16'h0000});           // NOP, tag 0x55
    for (int w = 1; w < 8; w++) hw(vec_reg(0, HPC_CMD0 + 12'(4 * w)), 32'h0);
    hw(vec_reg(0, HPC_DOORBELL), 32'h0);
    repeat (200) @(posedge clk);
    hr(SYS + 32'(DIE_SYS_IRQ_RAW), v);
    check("IRQ_RAW.VEC0 set by tile completion", v & 32'(1 << DIE_IRQ_VEC), 32'(1 << DIE_IRQ_VEC));
    check("host_irq_o low while IRQ_HOST_EN = 0", 32'(host_irq), 0);
    hr(CC_INTC_BASE + 32'(CC_INTC_PENDING), v);
    check("ControlCore INTC PENDING.VECTOR", (v >> CC_IRQ_VECTOR) & 1, 1);
    hw(SYS + 32'(DIE_SYS_IRQ_CC_VEC_EN), 32'h0);                  // unroute
    repeat (4) @(posedge clk);
    hr(CC_INTC_BASE + 32'(CC_INTC_PENDING), v);
    check("ControlCore VECTOR source masked by IRQ_CC_VEC_EN", (v >> CC_IRQ_VECTOR) & 1, 0);
    hw(SYS + 32'(DIE_SYS_IRQ_CC_VEC_EN), 32'((1 << NV) - 1));
    hw(SYS + 32'(DIE_SYS_IRQ_HOST_EN), 32'(1 << DIE_IRQ_VEC));
    repeat (2) @(posedge clk);
    check("host_irq_o follows IRQ_HOST_EN", 32'(host_irq), 1);
    vec_wait(0, 10000, info, cnt);
    check("NOP completion tag", 32'(info[7:0]), 32'h55);
    hw(vec_reg(0, HPC_IRQ_STATUS), 32'h7);
    repeat (2) @(posedge clk);
    check("host_irq_o released after the source is acknowledged", 32'(host_irq), 0);
    hw(SYS + 32'(DIE_SYS_IRQ_HOST_EN), 32'h0);
    hw(vec_reg(0, HPC_IRQ_EN), 32'h0);
    // die error interrupt routed to the host
    hw(SYS + 32'(DIE_SYS_ERR_STATUS), 32'hFFFF_FFFF);
    hw(SYS + 32'(DIE_SYS_IRQ_HOST_EN), 32'(1 << DIE_IRQ_DIE_ERR));
    expect_err("host decode error raises DIE_ERR", 1'b0, 32'h6000_0000);
    check("host_irq_o on DIE_ERR", 32'(host_irq), 1);
    hw(SYS + 32'(DIE_SYS_ERR_STATUS), 32'hFFFF_FFFF);
    repeat (2) @(posedge clk);
    check("host_irq_o released after ERR_STATUS W1C", 32'(host_irq), 0);
    hw(SYS + 32'(DIE_SYS_IRQ_HOST_EN), 32'h0);
    hw(SYS + 32'(DIE_SYS_ERR_CTRL), 32'h3);
  endtask

  task automatic t_invalid();
    logic [31:0] v, st, info, cnt;
    logic [31:0] rec [6];
    cur_test = "invalid";
    hw(SYS + 32'(DIE_SYS_ERR_STATUS), 32'hFFFF_FFFF);
    hw(SYS + 32'(DIE_SYS_ERR_CTRL), 32'h3);                       // clear FIRST, keep forwarding
    expect_err("host read outside every die region (0x5000_0000)", 1'b0, 32'h5000_0000);
    hchk("ERR_FIRST = HOST_DECODE", SYS + 32'(DIE_SYS_ERR_FIRST), 32'h8000_0000 | 32'(DIE_ERR_HOST_DECODE));
    hchk("ERR_FIRST_ADDR", SYS + 32'(DIE_SYS_ERR_FIRST_ADDR), 32'h5000_0000);
    hw(SYS + 32'(DIE_SYS_ERR_CTRL), 32'h3);
    expect_err("SRAM window beyond the populated size", 1'b0, SRAM + 32'(SRAMB));
    hr(SYS + 32'(DIE_SYS_ERR_FIRST), v);
    check("ERR_FIRST = NOC_DECODE from the HOST master (index 1)", v, 32'h8000_0000 | (32'd1 << 8) | 32'(DIE_ERR_NOC_DECODE));
    hchk("ERR_FIRST_ADDR exact", SYS + 32'(DIE_SYS_ERR_FIRST_ADDR), SRAM + 32'(SRAMB));
    expect_err("reserved firmware probe window 0x2800_0000", 1'b0, 32'h2800_0000);
    expect_err("scratchpad window beyond 64 KiB", 1'b1, spm(0, 32'h1_0000));
    if (EXT == 0) expect_err("external-memory window absent in this configuration", 1'b0, DIE_EXTMEM_BASE);
    expect_err("misaligned SRAM access", 1'b0, SRAM + 32'h2);
    hr(SYS + 32'(DIE_SYS_ERR_STATUS), v);
    check("ERR_STATUS has HOST_DECODE and NOC_DECODE", v & 32'h6, 32'h6);
    hr(SYS + 32'(DIE_SYS_ERR_COUNT), v);
    check_true("ERR_COUNT counted the events", v >= 5);
    hr(CC_RAS_BASE + 32'h0, v);
    $display("  ControlCore RAS STATUS after forwarded warnings = %08h", v);
    // tensor descriptor outside its legal window -> RANGE error record, nothing written
    hw(SRAM + 32'h7_0000, 32'hDEAD_BEEF);
    hw(tsu_reg(0, TSU_INT_ST), 32'h7);
    tsu_submit(0, 8'hE1, 4, 4, 4, SRAM, SRAM + 32'h100, DIE_EXTMEM_BASE, 1'b0);
    tsu_wait(0, 200000, rec);
    check("GEMM with C outside the window: status ERROR", 32'(rec[0][25:24]), 1);
    check("GEMM with C outside the window: TSU_E_RANGE", 32'(rec[0][23:16]), 32'h0E);
    hw(tsu_reg(0, TSU_CTRL), 32'h2);                              // ERR_CLEAR
    // vector KERNEL with a reserved opcode -> BAD_OP completion
    vec_submit(0, 5'h1F, 16, SRAM, SRAM + 32'h40, SRAM + 32'h80, spm(0, 32'h4000), 8'hE2);
    vec_wait(0, 100000, info, cnt);
    check("vector KERNEL bad opcode -> HPC_ST_BAD_OP", 32'(info[11:8]), 32'h3);
    hw(vec_reg(0, HPC_CTRL), 32'h2);                              // RESUME (halt-on-error is off by default; harmless)
    // die DMA: misaligned destination, then unmapped source (bus error)
    dma_start(0, SRAM, SRAM + 32'h1001, 16, 1'b0);
    dma_wait(0, 10000, st);
    check("DMA misaligned dst -> ERROR", 32'(st[2]), 1);
    hchk("DMA ERROR_CODE DST_ALIGN", dma_reg(0, DMA_ERR_CODE), 4);
    hw(SYS + 32'(DIE_SYS_ERR_CTRL), 32'h3);
    dma_start(0, 32'h2400_0000, SRAM + 32'h1000, 64, 1'b0);
    dma_wait(0, 10000, st);
    check("DMA from an unmapped address -> ERROR", 32'(st[2]), 1);
    hchk("DMA ERROR_CODE READ_BUS", dma_reg(0, DMA_ERR_CODE), 8);
    hr(SYS + 32'(DIE_SYS_ERR_FIRST), v);
    check("ERR_FIRST = NOC_DECODE from DMA master 2", v, 32'h8000_0000 | (32'd2 << 8) | 32'(DIE_ERR_NOC_DECODE));
    hchk("ERR_FIRST_ADDR = DMA source", SYS + 32'(DIE_SYS_ERR_FIRST_ADDR), 32'h2400_0000);
    hr(SYS + 32'(DIE_SYS_ERR_STATUS), v);
    check("ERR_STATUS.DMA set by the channel's error response", (v >> DIE_ERR_DMA) & 1, 1);
    // access matrix: a DMA channel may never reach register space (DIE_REGS), even at a valid address
    hw(SYS + 32'(DIE_SYS_ERR_CTRL), 32'h3);
    dma_start(0, SYS + 32'(DIE_SYS_ID), SRAM + 32'h1000, 16, 1'b0);
    dma_wait(0, 10000, st);
    check("DMA reading the die register window is refused (access matrix)", 32'(st[2]), 1);
    hchk("... with READ_BUS", dma_reg(0, DMA_ERR_CODE), 8);
    hchk("... logged as NOC_DECODE at that address", SYS + 32'(DIE_SYS_ERR_FIRST_ADDR), SYS + 32'(DIE_SYS_ID));
    hw(SYS + 32'(DIE_SYS_ERR_STATUS), 32'hFFFF_FFFF);
    hw(SYS + 32'(DIE_SYS_ERR_CTRL), 32'h3);
  endtask

  // every tensor unit, every vector tile and every DMA channel at once, plus host traffic; buffers spread
  // over the SRAM slices (distributed SRAM in HPC)
  task automatic t_concur();
    byte av0[], bv0[], av1[], bv1[];          // tensor units 0 and 1 (LIM_MAX_TENSOR_CLUSTERS = 2)
    logic [31:0] rec [6];
    logic [31:0] info, cnt, st, v, base;
    int m = 12, n = 12, k = 64, vl = 64, bad = 0, slice = SRAMB / NSL;
    cur_test = "concur";
    for (int j = 0; j < NT; j++) begin
      base = SRAM + 32'((j % NSL) * slice) + 32'h1_0000 + 32'(j) * 32'h4000;
      if (j == 0) gemm_load(m, n, k, base, base + 32'h1000, base + 32'h2000, av0, bv0);
      else        gemm_load(m, n, k, base, base + 32'h1000, base + 32'h2000, av1, bv1);
    end
    for (int i = 0; i < NV; i++) begin
      base = SRAM + 32'(((i + 1) % NSL) * slice) + 32'h2_0000 + 32'(i) * 32'h4000;
      for (int x = 0; x < vl; x++) begin hw(base + 32'(4 * x), f32_int(x + i)); hw(base + 32'h1000 + 32'(4 * x), f32_int(-2 * x)); end
    end
    for (int c = 0; c < ND; c++) begin
      base = SRAM + 32'(((c + 2) % NSL) * slice) + 32'h3_0000 + 32'(c) * 32'h4000;
      for (int x = 0; x < 512; x++) hw(base + 32'(4 * x), 32'hC0C0_0000 + 32'(c << 16) + 32'(x));
    end
    // launch everything back to back
    for (int j = 0; j < NT; j++) begin
      base = SRAM + 32'((j % NSL) * slice) + 32'h1_0000 + 32'(j) * 32'h4000;
      tsu_submit(j, 8'hC0 + 8'(j), m, n, k, base, base + 32'h1000, base + 32'h2000, 1'b0);
    end
    for (int i = 0; i < NV; i++) begin
      base = SRAM + 32'(((i + 1) % NSL) * slice) + 32'h2_0000 + 32'(i) * 32'h4000;
      vec_submit(i, 5'h01, vl, base, base + 32'h1000, base + 32'h2000, spm(i, 32'h4000), 8'hD0 + 8'(i));
    end
    for (int c = 0; c < ND; c++) begin
      base = SRAM + 32'(((c + 2) % NSL) * slice) + 32'h3_0000 + 32'(c) * 32'h4000;
      dma_start(c, base, base + 32'h2000, 2048, 1'b0);
    end
    // host traffic on the same memories while they run
    for (int x = 0; x < 200; x++) begin
      base = SRAM + 32'((x % NSL) * slice) + 32'hF_0000 + 32'(4 * x);
      hw(base, 32'hFACE_0000 + 32'(x));
      hr(base, v);
      if (v !== 32'hFACE_0000 + 32'(x)) bad++;
    end
    check("host traffic during concurrent work", 32'(bad), 0);
    for (int j = 0; j < NT; j++) begin
      tsu_wait(j, 3000000, rec);
      check($sformatf("concurrent GEMM on tensor unit %0d: status", j), 32'(rec[0][25:24]), 0);
      check($sformatf("concurrent GEMM on tensor unit %0d: tid", j), 32'(rec[0][7:0]), 32'hC0 + 32'(j));
      base = SRAM + 32'((j % NSL) * slice) + 32'h1_0000 + 32'(j) * 32'h4000;
      if (j == 0) gemm_check("concurrent GEMM tsu 0", m, n, k, base + 32'h2000, av0, bv0);
      else        gemm_check("concurrent GEMM tsu 1", m, n, k, base + 32'h2000, av1, bv1);
    end
    for (int i = 0; i < NV; i++) begin
      vec_wait(i, 1000000, info, cnt);
      check($sformatf("concurrent KERNEL on tile %0d: status", i), 32'(info[11:8]), 0);
      check($sformatf("concurrent KERNEL on tile %0d: tag", i), 32'(info[7:0]), 32'hD0 + 32'(i));
      base = SRAM + 32'(((i + 1) % NSL) * slice) + 32'h2_0000 + 32'(i) * 32'h4000;
      bad = 0;
      for (int x = 0; x < vl; x++) begin hr(base + 32'h2000 + 32'(4 * x), v); if (v !== f32_int(i - x)) bad++; end
      check($sformatf("concurrent KERNEL tile %0d vs reference", i), 32'(bad), 0);
    end
    for (int c = 0; c < ND; c++) begin
      dma_wait(c, 1000000, st);
      check($sformatf("concurrent DMA %0d status", c), st & 32'hF, 32'h2);
      base = SRAM + 32'(((c + 2) % NSL) * slice) + 32'h3_0000 + 32'(c) * 32'h4000;
      bad = 0;
      for (int x = 0; x < 512; x += 3) begin hr(base + 32'h2000 + 32'(4 * x), v); if (v !== 32'hC0C0_0000 + 32'(c << 16) + 32'(x)) bad++; end
      check($sformatf("concurrent DMA %0d copy", c), 32'(bad), 0);
    end
  endtask

  task automatic t_accreset();
    byte av[], bv[];
    logic [31:0] rec [6];
    logic [31:0] v, d0;
    logic [31:0] GA = SRAM + 32'hA_0000, GB = GA + 32'h4000, GC = GA + 32'h8000;
    cur_test = "accreset";
    hw(SYS + 32'(DIE_SYS_ERR_STATUS), 32'hFFFF_FFFF);
    // (1) accelerator reset in the middle of a GEMM: the tensor unit loses its state; any
    //     response still in the fabric is drained by the fence and never reaches it
    gemm_load(32, 32, 64, GA, GB, GC, av, bv);
    hr(SYS + 32'(DIE_SYS_FENCE_DRAINED), d0);
    tsu_submit(0, 8'hA1, 32, 32, 64, GA, GB, GC, 1'b0);
    repeat (1500) @(posedge clk);
    hr(SYS + 32'(DIE_SYS_BUSY), v);
    check("tensor unit busy when the reset is requested", (v >> 4) & 1, 1);
    hw(CC_PMU_BASE + 32'(CC_PMU_ACC_CTRL), 32'h3);                 // CLK_EN + RST
    repeat (20) @(posedge clk);
    hr(SYS + 32'(DIE_SYS_STATUS), v);
    check("STATUS.COMPUTE_READY low while the accelerators are held in reset", (v >> DIE_ST_COMPUTE_READY) & 1, 0);
    expect_err("SPM window refused while the compute domain is in reset", 1'b0, spm(0, 0));
    hw(CC_PMU_BASE + 32'(CC_PMU_ACC_CTRL), 32'h1);                 // release
    repeat (20) @(posedge clk);
    hr(SYS + 32'(DIE_SYS_FENCE_DRAINED), v);
    $display("  fence drained %0d orphan response(s) after the mid-GEMM reset", v - d0);
    hchk("tensor unit re-discovered after reset", tsu_reg(0, TSU_ID), TSU_ID_VALUE);
    hr(tsu_reg(0, TSU_STATUS), v);
    check("tensor unit queue empty after reset (no stale completion)", (v >> 4) & 1, 0);
    // the same work, completed correctly after recovery
    for (int i = 0; i < 32 * 32; i++) hw(GC + 32'(4 * i), 32'hDEAD_BEEF);
    tsu_submit(0, 8'hA2, 32, 32, 64, GA, GB, GC, 1'b0);
    tsu_wait(0, 4000000, rec);
    check("GEMM after accelerator reset: status OK", 32'(rec[0][25:24]), 0);
    check("GEMM after accelerator reset: tid (no stale record)", 32'(rec[0][7:0]), 32'hA2);
    gemm_check("GEMM after accelerator reset", 32, 32, 64, GC, av, bv);
    // (1a) reset while the fabric holds a tensor-unit request: GEMM + a competing die DMA on the same SRAM
    //      slice keep the tensor unit at its 4-outstanding limit; the reset is pulsed at varying offsets
    //      until it lands on a held request (coverage counter held_at_reset), then the GEMM is re-run
    begin
      int tries = 0, h0 = held_at_reset;
      logic [31:0] st;
      // required for shared bus / crossbar; on the mesh the network interfaces buffer requests, so a
      // fabric-held request at the instant of reset is rare -- reported there, not required
      while (held_at_reset == h0 && tries < ((TOPO == 2) ? 40 : 160)) begin
        dma_start(0, SRAM + 32'h4_0000, SRAM + 32'h5_0000, 4096, 1'b0);
        tsu_submit(0, 8'hA3, 32, 32, 64, GA, GB, GC, 1'b0);
        repeat (250 + ($urandom % 800)) @(posedge clk);       // seeded random offset into the GEMM
        hw(CC_PMU_BASE + 32'(CC_PMU_ACC_CTRL), 32'h3);
        hw(CC_PMU_BASE + 32'(CC_PMU_ACC_CTRL), 32'h1);
        dma_wait(0, 200000, st);
        repeat (50) @(posedge clk);
        tries++;
      end
      $display("  reset landed on a request held by the fabric after %0d tries (held_at_reset = %0d)", tries, held_at_reset);
      if (TOPO != 2) check_true("coverage: an accelerator reset hit a request held by the fabric", held_at_reset > h0);
      else $display("  (mesh) held-request coverage %s -- informational only for TOPOLOGY 2", held_at_reset > h0 ? "hit" : "not hit");
      for (int i = 0; i < 32 * 32; i++) hw(GC + 32'(4 * i), 32'hDEAD_BEEF);
      tsu_submit(0, 8'hA4, 32, 32, 64, GA, GB, GC, 1'b0);
      tsu_wait(0, 4000000, rec);
      check("GEMM after the held-request reset: status OK", 32'(rec[0][25:24]), 0);
      check("GEMM after the held-request reset: tid", 32'(rec[0][7:0]), 32'hA4);
      gemm_check("GEMM after the held-request reset", 32, 32, 64, GC, av, bv);
    end
    // (1c) accelerator reset while a die-DMA write into the tile scratchpad window is outstanding at the tile:
    //      the gate must answer it with an error (abandon) -- the DMA ends with an error, never hangs.  The
    //      reset is swept across the stream until it lands in that window (coverage counter spm_abandoned).
    begin
      int tries = 0, a0 = spm_abandoned, f0 = fails;
      logic [31:0] st;
      while (spm_abandoned == a0 && tries < 64 && fails == f0) begin
        dma_start(0, SRAM + 32'h4_0000, spm(0, 32'h8000), 4096, 1'b0);
        repeat (40 + 3 * tries) @(posedge clk);
        hw(CC_PMU_BASE + 32'(CC_PMU_ACC_CTRL), 32'h3);
        hw(CC_PMU_BASE + 32'(CC_PMU_ACC_CTRL), 32'h1);
        dma_wait(0, 200000, st);                                   // must terminate: error, never a hang
        tries++;
      end
      $display("  reset landed on an outstanding scratchpad access after %0d tries (abandoned = %0d)", tries, spm_abandoned - a0);
      check_true("coverage: an accelerator reset hit an outstanding scratchpad-window access", spm_abandoned > a0);
      check("the DMA whose access was abandoned ended with an error (no hang)", 32'(st[2]), 1);
      hw(spm(0, 32'h200), 32'h0BAD_F00D);
      hchk("scratchpad window usable again after the abandon", spm(0, 32'h200), 32'h0BAD_F00D);
      hw(SYS + 32'(DIE_SYS_ERR_STATUS), 32'hFFFF_FFFF);
    end
    // (1b) orphans that arrive AFTER the accelerator reset is released (configurations with external
    //      memory): every external read takes 400 controller cycles, the tile's operand fetch is in
    //      flight when a SHORT accelerator reset is pulsed, so its response comes back long after the
    //      tile has been released.  The fence must drain it; the accelerator-side protocol checker
    //      (reset with the tile) flags any stale response that reaches the fresh tile.
    if (EXT != 0) begin
      logic [31:0] info, cnt, d1;
      int bad = 0;
      for (int i = 0; i < 32; i++) begin
        hw(DIE_EXTMEM_BASE + 32'h6000 + 32'(4 * i), f32_int(i));
        hw(DIE_EXTMEM_BASE + 32'h7000 + 32'(4 * i), f32_int(1));
        hw(SRAM + 32'h3_D000 + 32'(4 * i), f32_int(100 + i));
        hw(SRAM + 32'h3_D800 + 32'(4 * i), f32_int(2 * i));
      end
      hr(SYS + 32'(DIE_SYS_FENCE_DRAINED), d1);
      mc_lat_min = 400; mc_lat_max = 400;
      vec_submit(0, 5'h01, 32, DIE_EXTMEM_BASE + 32'h6000, DIE_EXTMEM_BASE + 32'h7000, SRAM + 32'h3_E000,
                 spm(0, 32'h4000), 8'hF1);
      repeat (100) @(posedge clk);
      hr(SYS + 32'(DIE_SYS_BUSY), v);
      check("tile busy fetching operands from slow external memory", v & 1, 1);
      hw(CC_PMU_BASE + 32'(CC_PMU_ACC_CTRL), 32'h3);               // short accelerator reset ...
      hw(CC_PMU_BASE + 32'(CC_PMU_ACC_CTRL), 32'h1);               // ... released before the read returns
      repeat (1500) @(posedge clk);                                // the stale response arrives here
      mc_lat_min = 2; mc_lat_max = 12;
      hr(SYS + 32'(DIE_SYS_FENCE_DRAINED), v);
      check_true("orphan response returning after reset release was drained by the fence", v > d1);
      $display("  fence drained %0d orphan response(s) that returned after the reset was released", v - d1);
      // the fresh tile: new KERNEL on different data, must see only its own responses
      vec_submit(0, 5'h01, 32, SRAM + 32'h3_D000, SRAM + 32'h3_D800, SRAM + 32'h3_E000, spm(0, 32'h4000), 8'hF2);
      vec_wait(0, 200000, info, cnt);
      check("KERNEL after the reset: status", 32'(info[11:8]), 0);
      check("KERNEL after the reset: tag (no stale completion)", 32'(info[7:0]), 32'hF2);
      for (int i = 0; i < 32; i++) begin hr(SRAM + 32'h3_E000 + 32'(4 * i), v); if (v !== f32_int(100 + 3 * i)) bad++; end
      check("KERNEL after the reset vs reference (no stale operand data)", 32'(bad), 0);
      check("accelerator-side protocol checkers clean so far", 32'(proto_violations()), 0);
    end
    // (2) accelerator clock gated by the PMU: the scratchpad window refuses, data survives
    hw(spm(0, 32'h100), 32'h600D_C10C);
    hw(CC_PMU_BASE + 32'(CC_PMU_ACC_CTRL), 32'h0);                 // CLK_EN = 0
    repeat (20) @(posedge clk);
    hr(CC_PMU_BASE + 32'(CC_PMU_ACC_STATUS), v);
    check("PMU reports the accelerator clock off", v & 1, 0);
    hr(SYS + 32'(DIE_SYS_GATE_REFUSED), d0);
    expect_err("SPM access while the accelerator clock is gated", 1'b0, spm(0, 32'h100));
    hchk("GATE_REFUSED counted", SYS + 32'(DIE_SYS_GATE_REFUSED), d0 + 1);
    hr(SYS + 32'(DIE_SYS_ERR_STATUS), v);
    check("ERR_STATUS.GATE_REFUSED", (v >> DIE_ERR_GATE_REFUSED) & 1, 1);
    hw(CC_PMU_BASE + 32'(CC_PMU_ACC_CTRL), 32'h1);                 // clock back
    repeat (10) @(posedge clk);
    hchk("SPM data preserved across clock gating", spm(0, 32'h100), 32'h600D_C10C);
    hr(CC_PMU_BASE + 32'(CC_PMU_GATED_CYC), v);
    check_true("PMU counted gated cycles", v > 0);
    hw(SYS + 32'(DIE_SYS_ERR_STATUS), 32'hFFFF_FFFF);
    hw(SYS + 32'(DIE_SYS_ERR_CTRL), 32'h3);
  endtask

  task automatic t_extmem();
    logic [31:0] v, st;
    int bad;
    cur_test = "extmem";
    if (EXT == 0) begin $display("  extmem: not present in this configuration (skipped)"); return; end
    wait_extmem_ready();
    for (int i = 0; i < 64; i++) hw(DIE_EXTMEM_BASE + 32'(4 * i), 32'hE0E0_0000 + 32'(i));
    bad = 0;
    for (int i = 0; i < 64; i++) begin hr(DIE_EXTMEM_BASE + 32'(4 * i), v); if (v !== 32'hE0E0_0000 + 32'(i)) bad++; end
    check("host write/read external memory", 32'(bad), 0);
    hr(DIE_EXTMEM_CSR_BASE, v);
    $display("  external-memory bridge CSR[0] = %08h", v);
    // SRAM -> EXT -> SRAM through the die DMA (byte exact)
    for (int i = 0; i < 256; i++) hw(SRAM + 32'h3_0000 + 32'(4 * i), 32'h7E57_0000 + 32'(i * 5));
    dma_start(0, SRAM + 32'h3_0000, DIE_EXTMEM_BASE + 32'h1000, 1024, 1'b0);
    dma_wait(0, 200000, st);
    check("DMA SRAM -> EXT", st & 32'hF, 32'h2);
    dma_start(0, DIE_EXTMEM_BASE + 32'h1000, SRAM + 32'h3_8000, 1024, 1'b0);
    dma_wait(0, 200000, st);
    check("DMA EXT -> SRAM", st & 32'hF, 32'h2);
    bad = 0;
    for (int i = 0; i < 256; i++) begin hr(SRAM + 32'h3_8000 + 32'(4 * i), v); if (v !== 32'h7E57_0000 + 32'(i * 5)) bad++; end
    check("SRAM -> EXT -> SRAM byte exact", 32'(bad), 0);
    // vector tile KERNEL with both operands in external memory (access matrix VEC -> EXT), result in SRAM
    begin
      logic [31:0] info, cnt;
      for (int i = 0; i < 32; i++) begin
        hw(DIE_EXTMEM_BASE + 32'h4000 + 32'(4 * i), f32_int(i + 1));
        hw(DIE_EXTMEM_BASE + 32'h5000 + 32'(4 * i), f32_int(2 * i));
      end
      vec_submit(0, 5'h01, 32, DIE_EXTMEM_BASE + 32'h4000, DIE_EXTMEM_BASE + 32'h5000, SRAM + 32'h3_C000,
                 spm(0, 32'h4000), 8'hEE);
      vec_wait(0, 200000, info, cnt);
      check("KERNEL with operands in external memory: status", 32'(info[11:8]), 0);
      bad = 0;
      for (int i = 0; i < 32; i++) begin hr(SRAM + 32'h3_C000 + 32'(4 * i), v); if (v !== f32_int(3 * i + 1)) bad++; end
      check("KERNEL with operands in external memory vs reference", 32'(bad), 0);
    end
    expect_err("host access beyond the external-memory window", 1'b0, DIE_EXTMEM_BASE + 32'h0400_0000);
  endtask

  // die POR in the middle of traffic, then a full re-run of a GEMM; host reset request
  task automatic t_porreset();
    byte av[], bv[];
    logic [31:0] rec [6];
    logic [31:0] v;
    cur_test = "porreset";
    // host reset request: the ControlCore (and the accelerators) reset, the fabric and SRAM keep running
    hw(SRAM + 32'h5_0000, 32'h5AFE_DA7A);
    host_rst = 1'b1; repeat (10) @(posedge clk); host_rst = 1'b0;
    repeat (400) @(posedge clk);
    hchk("SRAM content survives a ControlCore host reset", SRAM + 32'h5_0000, 32'h5AFE_DA7A);
    hr(CC_SYSCTRL_BASE + 32'(CC_SYSCTRL_RESET_CAUSE), v);
    check("ControlCore RESET_CAUSE.HOST", (v >> 3) & 1, 1);
    hchk("die stays in RUN", SYS + 32'(DIE_SYS_RESET_STAGE), 32'(DIE_RST_STAGE_RUN));
    // POR while a DMA and a GEMM are running
    gemm_load(16, 16, 32, SRAM + 32'h6_0000, SRAM + 32'h6_4000, SRAM + 32'h6_8000, av, bv);
    tsu_submit(0, 8'hB1, 16, 16, 32, SRAM + 32'h6_0000, SRAM + 32'h6_4000, SRAM + 32'h6_8000, 1'b0);
    dma_start(0, SRAM, SRAM + 32'h7_0000, 8192, 1'b0);
    repeat (300) @(posedge clk);
    @(negedge clk); por_n = 1'b0;
    repeat (5) @(posedge clk);
    check("platform_ready_o drops on POR", 32'(plat_ready), 0);
    @(negedge clk); por_n = 1'b1;
    wait (plat_ready === 1'b1);
    repeat (100) @(posedge clk);
    hchk("after POR: DIE_SYS.ID", SYS + 32'(DIE_SYS_ID), DIE_ID);
    hchk("after POR: SCRATCH reset", SYS + 32'(DIE_SYS_SCRATCH), 32'h0);
    hchk("after POR: ERR_STATUS clean", SYS + 32'(DIE_SYS_ERR_STATUS), 32'h0);
    hchk("after POR: DMA idle", dma_reg(0, DMA_STATUS), 32'h0);
    wait_boot_stage(CC_BOOT_STAGE_WAIT_IMAGE, 3_000_000);
    gemm_load(16, 16, 32, SRAM + 32'h6_0000, SRAM + 32'h6_4000, SRAM + 32'h6_8000, av, bv);
    tsu_submit(0, 8'hB2, 16, 16, 32, SRAM + 32'h6_0000, SRAM + 32'h6_4000, SRAM + 32'h6_8000, 1'b0);
    tsu_wait(0, 2000000, rec);
    check("GEMM after POR: status OK", 32'(rec[0][25:24]), 0);
    check("GEMM after POR: tid", 32'(rec[0][7:0]), 32'hB2);
    gemm_check("GEMM after POR", 16, 16, 32, SRAM + 32'h6_8000, av, bv);
    wait_extmem_ready();
  endtask

  // ------------------------------------------------------------------ the real ControlCore firmware on the die
  logic [31:0] img [$];
  logic [31:0] rsp [8];
  task automatic mbox_wait(input longint tmo);
    longint t0 = cyc;
    while (!host_irq) begin
      @(posedge clk);
      if (cyc - t0 > tmo) begin fails++; $display("[%0d] FAIL [%s] timeout waiting for the firmware", cyc, cur_test); return; end
    end
    for (int i = 0; i < 8; i++) hr(CC_MAILBOX_BASE + 32'(CC_MBOX_F2H_MSG0) + 32'(4 * i), rsp[i]);
    hw(CC_MAILBOX_BASE + 32'(CC_MBOX_F2H_ACK), 0);
  endtask
  task automatic mbox_cmd(input logic [31:0] cmd, input logic [31:0] a1, input logic [31:0] a2, input logic [31:0] a3,
                          input longint tmo);
    longint t0 = cyc;
    hw(CC_MAILBOX_BASE + 32'(CC_MBOX_H2F_MSG0) + 4, a1);
    hw(CC_MAILBOX_BASE + 32'(CC_MBOX_H2F_MSG0) + 8, a2);
    hw(CC_MAILBOX_BASE + 32'(CC_MBOX_H2F_MSG0) + 12, a3);
    hw(CC_MAILBOX_BASE + 32'(CC_MBOX_H2F_MSG0), cmd);
    hw(CC_MAILBOX_BASE + 32'(CC_MBOX_H2F_RING), cmd);
    mbox_wait(tmo);
    $display("[%0d] host: mailbox cmd %02h -> status %0d (%0d cycles)", cyc, cmd, rsp[0] & 32'hFF, cyc - t0);
  endtask
  task automatic t_firmware();
    string fw;
    int fd, bad;
    logic [31:0] w, v, stmask;
    byte av[], bv[];
    cur_test = "firmware";
    if (!$value$plusargs("fw=%s", fw)) fw = "third_party/silicaflux-controlcore/firmware/build/fw/controlcore_fw.hex";
    if (!$value$plusargs("stmask=%h", stmask)) stmask = 32'h3DDF;      // all groups except DMA (6) and ERRORS (10)
    fd = $fopen(fw, "r");
    if (fd == 0) begin fails++; $display("FAIL cannot open %s", fw); return; end
    while ($fscanf(fd, "%h\n", w) == 1) img.push_back(w);
    $fclose(fd);
    $display("  firmware image %s: %0d words", fw, img.size());
    wait_boot_stage(CC_BOOT_STAGE_WAIT_IMAGE, 3_000_000);
    foreach (img[i]) hw(CC_IMEM_BASE + 32'(4 * i), img[i]);
    mbox_cmd(CC_MBOX_CMD_IMAGE_READY, 0, 0, 0, 3_000_000);
    check("boot ROM accepted the image (CRC32 integrity)", rsp[0] & 32'hFF, CC_MBOX_STS_OK);
    begin
      longint t0 = cyc;
      bit give_up = 1'b0;
      while (!dev_ready && !give_up) begin
        @(posedge clk);
        if (cyc - t0 > 6_000_000) begin fails++; $display("FAIL device_ready_o never rose"); give_up = 1'b1; end
      end
    end
    $display("[%0d] host: device_ready_o = 1", cyc);
    mbox_wait(1000);
    check("firmware discovered vector tile and tensor unit", rsp[1], 3);
    hr(SYS + 32'(DIE_SYS_STATUS), v);
    check("STATUS.FW_HOST_READY", (v >> DIE_ST_FW_HOST_READY) & 1, 1);
    check("STATUS.DEVICE_READY", (v >> DIE_ST_DEVICE_READY) & 1, 1);
    hr(SYS + 32'(DIE_SYS_DEVICE_CYC), v);
    $display("  DEVICE_CYC = %0d cycles (host image load + ROM CRC check + firmware init/POST)", v);
    mbox_cmd(CC_MBOX_CMD_PING, 32'h1234_5678, 0, 0, 100000);
    check("PING echo", rsp[1], 32'h1234_5678);
    mbox_cmd(CC_MBOX_CMD_RUN_SELFTEST, stmask, 0, 0, 40_000_000);
    check("firmware self-test status", rsp[0] & 32'hFF, CC_MBOX_STS_OK);
    check("firmware self-test fails", rsp[2], 0);
    $display("  firmware self-test on the die: %0d checks, %0d fails (mask %08h)", rsp[1], rsp[2], stmask);
    // host-built GEMM through the command processor
    begin
      logic [31:0] A = SRAM + 32'h8_0000, B = SRAM + 32'h8_4000, C = SRAM + 32'h8_8000, D = SRAM + 32'h8_F000;
      gemm_load(9, 11, 40, A, B, C, av, bv);
      hw(D + 0, {8'h91, 8'h01, 4'h0, 4'h2, 8'h40});     // GEMM, VERSION 2, FLAGS.IRQ, TID 0x91
      hw(D + 4, A); hw(D + 8, B); hw(D + 12, C);
      hw(D + 16, {16'd11, 16'd9}); hw(D + 20, 32'd40); hw(D + 24, 32'd40); hw(D + 28, 32'd11); hw(D + 32, 32'd44);
      hw(D + 36, 0); hw(D + 40, 0); hw(D + 44, 0);
      mbox_cmd(CC_MBOX_CMD_GEMM, D, 0, 0, 5_000_000);
      check("firmware GEMM status", rsp[0] & 32'hFF, CC_MBOX_STS_OK);
      check("firmware GEMM record TID", rsp[1] & 32'hFF, 32'h91);
      gemm_check("firmware GEMM 9x11x40", 9, 11, 40, C, av, bv);
    end
    // host-built vector KERNEL through the command processor
    begin
      logic [31:0] A = SRAM + 32'h9_0000, B = SRAM + 32'h9_1000, Dd = SRAM + 32'h9_2000, D = SRAM + 32'h9_3000;
      for (int i = 0; i < 48; i++) begin hw(A + 32'(4 * i), f32_int(i - 7)); hw(B + 32'(4 * i), f32_int(3 * i)); hw(Dd + 32'(4 * i), 32'hFFFF_FFFF); end
      hw(D + 0, {8'h00, 8'h77, 1'b0, 3'd0, 3'd0, 5'h01, 4'h3});
      hw(D + 4, 48); hw(D + 8, 0); hw(D + 12, A); hw(D + 16, B); hw(D + 20, 0); hw(D + 24, Dd);
      hw(D + 28, DIE_VEC_SPM_BASE + 32'h4000);
      mbox_cmd(CC_MBOX_CMD_VECTOR_KERNEL, D, 0, 0, 5_000_000);
      check("firmware VECTOR status", rsp[0] & 32'hFF, CC_MBOX_STS_OK);
      check("firmware VECTOR count", rsp[3], 48);
      bad = 0;
      for (int i = 0; i < 48; i++) begin hr(Dd + 32'(4 * i), v); if (v !== f32_int(4 * i - 7)) bad++; end
      check("firmware VECTOR D vs reference", 32'(bad), 0);
    end
    // ControlCore system DMA through the command processor, and its error path on the die
    for (int i = 0; i < 64; i++) hw(SRAM + 32'hA_0000 + 32'(4 * i), 32'hC0DE_0000 + 32'(i));
    mbox_cmd(CC_MBOX_CMD_DMA_COPY, SRAM + 32'hA_0000, SRAM + 32'hA_1000, 256, 1_000_000);
    check("firmware DMA_COPY status", rsp[0] & 32'hFF, CC_MBOX_STS_OK);
    hchk("firmware DMA_COPY last word", SRAM + 32'hA_10FC, 32'hC0DE_003F);
    mbox_cmd(CC_MBOX_CMD_DMA_COPY, 32'h2400_0000, SRAM + 32'hA_1000, 64, 1_000_000);
    check("firmware DMA_COPY from an unmapped die address -> error", rsp[0] & 32'hFF, CC_MBOX_STS_ACC_ERROR);
    check("firmware DMA_COPY error code READ_BUS", rsp[1], 8);
    mbox_cmd(CC_MBOX_CMD_SHUTDOWN, 32'(fails), 0, 0, 100000);
    repeat (20) @(posedge clk);
    check("TEST_CTRL done pin", 32'(test_done), 1);
    check("TEST_CTRL fail pin", 32'(test_fail), 0);
  endtask

  // ================================================================== main

  initial begin
    longint tmo;
    if (!$value$plusargs("timeout=%d", tmo)) tmo = 60_000_000;
    wait (cyc > tmo);
    $display("TB RESULT FAIL TIMEOUT at cycle %0d (test %s)", cyc, cur_test);
    $fatal(1, "timeout");
  end

  initial begin
    string test;
    int seed;
    if (!$value$plusargs("test=%s", test)) test = "all";
    if (!$value$plusargs("bp=%d", bp_pct)) bp_pct = 0;
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    if (!$value$plusargs("mcbp=%d", mc_cmd_pct)) mc_cmd_pct = 100;
    void'($urandom(seed));
    $display("TB config %0d: NV=%0d NT=%0d banks=%0d slices=%0d SRAM=%0d KiB DMA=%0d topology=%0d extmem=%0d async=%0d | NoC %0dx%0d | test=%s bp=%0d%% seed=%0d",
             CFGID, NV, NT, NBANKS, NSL, SRAMB / 1024, ND, TOPO, EXT, EXTASYNC, NM, NTG, test, bp_pct, seed);
    power_on(200);
    $display("[%0d] platform ready", cyc);
    wait_extmem_ready();
    if (test == "all" || test == "identity") t_identity();
    if (test == "all" || test == "reset")    t_reset();
    if (test == "all" || test == "regs")     t_regs();
    if (test == "all" || test == "sram")     t_sram();
    if (test == "all" || test == "dma")      t_dma();
    if (test == "all" || test == "vector")   t_vector();
    if (test == "all" || test == "gemm")     t_gemm();
    if (test == "all" || test == "irq")      t_irq();
    if (test == "all" || test == "invalid")  t_invalid();
    if (test == "all" || test == "concur")   t_concur();
    if (test == "all" || test == "extmem")   t_extmem();
    if (test == "all" || test == "accreset") t_accreset();
    if (test == "all" || test == "porreset") t_porreset();
    if (test == "firmware")                  t_firmware();
    repeat (50) @(posedge clk);
    check("protocol-checker violations (host port, all NoC ports, SFMC)", 32'(proto_violations()), 0);
    $display("TB RESULT %s config=%0d test=%s bp=%0d seed=%0d checks=%0d fails=%0d cycles=%0d",
             fails == 0 ? "PASS" : "FAIL", CFGID, test, bp_pct, seed, checks, fails, cyc);
    if (fails == 0) $finish(0);
    else $fatal(1, "%0d check(s) failed", fails);
  end
endmodule

`default_nettype wire
