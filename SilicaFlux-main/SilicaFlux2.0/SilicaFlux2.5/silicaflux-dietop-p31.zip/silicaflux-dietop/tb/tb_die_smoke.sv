// =============================================================================
// SilicaFlux DieTop :: tb_die_smoke -- cross-simulator smoke test (Icarus 12 AND Verilator 5)
//
// Deliberately plain SystemVerilog (no ref ports, no task return, no dynamic
// arrays) so it runs on Icarus 12, which the full testbench (tb_die_top) does not
// support.  MIN configuration.  Checks: platform ready after the deterministic
// reset sequence + SRAM initialisation; DIE_SYS identity and configuration;
// ControlCore, vector-tile and tensor-unit IDs through the host bridge; shared
// SRAM write/read with byte strobes; a die DMA copy SRAM -> SRAM; an unmapped
// host access answered with an error.  Prints "SMOKE RESULT PASS|FAIL".
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_die_smoke;
  logic clk = 1'b0;
  always #5 clk = ~clk;
  logic por_n = 1'b1, pll_lock = 1'b0;
  initial #1 por_n = 1'b0;
  integer cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  logic        rq_v = 1'b0, rq_r, rq_w = 1'b0, rs_v, rs_e;
  logic [31:0] rq_a = 32'd0, rq_d = 32'd0, rs_d;
  logic [3:0]  rq_s = 4'hF;
  logic        plat, dev, hirq;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        u_mc_rst, u_cv, u_cw, u_wv, u_wl, u_rr, u_wr, u_tdo, u_tdoe, u_rf, u_dv, u_td, u_tf, u_sl;
  logic [25:0] u_ca; logic [7:0] u_cl, u_dc; logic [1:0] u_ct; logic [31:0] u_wd; logic [3:0] u_ws; logic [15:0] u_tc;
  /* verilator lint_on UNUSEDSIGNAL */

  silicaflux_die_min dut (
    .clk_i(clk), .por_ni(por_n), .pll_lock_i(pll_lock), .test_mode_i(1'b0), .boot_mode_i(2'b00), .host_rst_req_i(1'b0),
    .host_req_valid_i(rq_v), .host_req_ready_o(rq_r), .host_req_write_i(rq_w), .host_req_addr_i(rq_a),
    .host_req_wdata_i(rq_d), .host_req_wstrb_i(rq_s), .host_rsp_valid_o(rs_v), .host_rsp_ready_i(1'b1),
    .host_rsp_rdata_o(rs_d), .host_rsp_error_o(rs_e), .host_irq_o(hirq), .platform_ready_o(plat), .device_ready_o(dev),
    .mc_clk_i(clk), .mc_rst_no(u_mc_rst), .mc_init_done_i(1'b0), .mc_fatal_i(1'b0), .mc_cmd_valid_o(u_cv),
    .mc_cmd_ready_i(1'b0), .mc_cmd_write_o(u_cw), .mc_cmd_addr_o(u_ca), .mc_cmd_len_o(u_cl), .mc_cmd_tag_o(u_ct),
    .mc_wd_valid_o(u_wv), .mc_wd_ready_i(1'b0), .mc_wd_data_o(u_wd), .mc_wd_strb_o(u_ws), .mc_wd_last_o(u_wl),
    .mc_rd_valid_i(1'b0), .mc_rd_ready_o(u_rr), .mc_rd_data_i(32'd0), .mc_rd_tag_i(2'd0), .mc_rd_last_i(1'b0),
    .mc_rd_error_i(1'b0), .mc_wr_valid_i(1'b0), .mc_wr_ready_o(u_wr), .mc_wr_tag_i(2'd0), .mc_wr_error_i(1'b0),
    .tck_i(1'b0), .tms_i(1'b1), .tdi_i(1'b0), .trst_ni(1'b0), .tdo_o(u_tdo), .tdo_oe_o(u_tdoe),
    .ext_warn_i(1'b0), .ext_fatal_i(1'b0), .ras_fatal_o(u_rf),
    .diag_valid_o(u_dv), .diag_char_o(u_dc), .test_done_o(u_td), .test_fail_o(u_tf), .test_code_o(u_tc), .cpu_sleep_o(u_sl));

  integer fails = 0, checks = 0;
  logic [31:0] rd;
  logic        er;

  task acc(input logic w, input logic [31:0] a, input logic [31:0] d, input logic [3:0] s);
    begin
      @(negedge clk); rq_v = 1'b1; rq_w = w; rq_a = a; rq_d = d; rq_s = s;
      #1; while (!rq_r) begin @(negedge clk); #1; end
      @(posedge clk); #1; rq_v = 1'b0;
      while (!rs_v) begin @(negedge clk); #1; end
      rd = rs_d; er = rs_e;
      @(posedge clk); #1;
    end
  endtask
  task chk(input [8*48-1:0] what, input logic [31:0] got, input logic [31:0] exp);
    begin
      checks = checks + 1;
      if (got !== exp) begin fails = fails + 1; $display("SMOKE FAIL %0s: got %08h exp %08h", what, got, exp); end
    end
  endtask

  localparam logic [31:0] SYS = 32'h3E00_0000, DMA = 32'h3E00_2000, SRAM = 32'h2000_0000;
  integer i;
  initial begin
    repeat (8) @(negedge clk); por_n = 1'b1;
    repeat (10) @(negedge clk); pll_lock = 1'b1;
    while (!plat) @(posedge clk);
    $display("SMOKE platform ready at cycle %0d", cyc);
    acc(1'b0, SYS + 32'h000, 0, 4'hF); chk("DIE_SYS.ID", rd, 32'h5346_4454);
    acc(1'b0, SYS + 32'h00C, 0, 4'hF); chk("CONFIG_ID", rd, 32'd1);
    acc(1'b0, SYS + 32'h024, 0, 4'hF); chk("STATUS platform ready, no firmware", rd & 32'h1FF, 32'h0BF);
    acc(1'b0, SYS + 32'h02C, 0, 4'hF); chk("PLATFORM_CYC", rd, 32'd65537);
    acc(1'b0, 32'h4000_0000, 0, 4'hF); chk("ControlCore SYSCTRL.ID", rd, 32'h5346_4343);
    acc(1'b0, 32'h4000_8000, 0, 4'hF); chk("vector tile ID", rd, 32'h5346_4854);
    acc(1'b0, 32'h4000_9000, 0, 4'hF); chk("tensor unit ID", rd, 32'h5346_5443);
    acc(1'b0, SRAM + 32'h40, 0, 4'hF); chk("SRAM initialised", rd, 32'h0);
    acc(1'b1, SRAM + 32'h100, 32'h1122_3344, 4'hF);
    acc(1'b1, SRAM + 32'h100, 32'hAABB_CCDD, 4'b0101);
    acc(1'b0, SRAM + 32'h100, 0, 4'hF); chk("SRAM byte strobes", rd, 32'h11BB_33DD);
    for (i = 0; i < 16; i = i + 1) acc(1'b1, SRAM + 32'h1000 + 4 * i, 32'hA000_0000 + i, 4'hF);
    acc(1'b1, DMA + 32'h008, SRAM + 32'h1000, 4'hF);
    acc(1'b1, DMA + 32'h00C, SRAM + 32'h2000, 4'hF);
    acc(1'b1, DMA + 32'h010, 32'd64, 4'hF);
    acc(1'b1, DMA + 32'h000, 32'd1, 4'hF);
    rd = 32'h1;
    while (rd[0]) acc(1'b0, DMA + 32'h004, 0, 4'hF);
    chk("DMA status done", rd & 32'hF, 32'h2);
    for (i = 0; i < 16; i = i + 1) begin acc(1'b0, SRAM + 32'h2000 + 4 * i, 0, 4'hF); chk("DMA copy", rd, 32'hA000_0000 + i); end
    acc(1'b0, 32'h5000_0000, 0, 4'hF); chk("unmapped host access -> error", {31'd0, er}, 32'd1);
    $display("SMOKE RESULT %s checks=%0d fails=%0d cycles=%0d", fails == 0 ? "PASS" : "FAIL", checks, fails, cyc);
    $finish;
  end
  initial begin #20000000; $display("SMOKE RESULT FAIL timeout"); $finish; end
endmodule

`default_nettype wire
