#!/usr/bin/env python3
# =============================================================================
# SilicaFlux DieTop :: package.py -- build the deliverable archive (no git operations)
#
#   package.py [out.zip]   default: ../silicaflux-dietop-p31.zip (next to the project directory)
# Excludes build products (build/, __pycache__, *.vvp).  Run logs in reports/ are
# kept: they are the evidence behind every number in the documentation.
# =============================================================================
import hashlib, os, sys, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXCL_DIRS = {'build', '__pycache__', '.git', 'obj_dir'}
EXCL_EXT = {'.vvp', '.o', '.a', '.pyc'}


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(ROOT), 'silicaflux-dietop-p31.zip')
    name = os.path.basename(ROOT)
    n = 0
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for d, dirs, files in os.walk(ROOT):
            # only the project's own top-level build/ is excluded: third_party/ contains a vendored
            # firmware/build/ directory (the prebuilt ControlCore firmware image) that must be shipped
            dirs[:] = sorted(x for x in dirs
                             if not (x in EXCL_DIRS and (x != 'build' or os.path.abspath(d) == os.path.abspath(ROOT))))
            for f in sorted(files):
                if os.path.splitext(f)[1] in EXCL_EXT:
                    continue
                p = os.path.join(d, f)
                z.write(p, os.path.join(name, os.path.relpath(p, ROOT)))
                n += 1
    h = hashlib.sha256(open(out, 'rb').read()).hexdigest()
    print(f"{out}: {n} files, {os.path.getsize(out) / 1e6:.1f} MB, sha256 {h}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
