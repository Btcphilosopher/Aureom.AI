#!/usr/bin/env python3
# =============================================================================
# SilicaFlux DieTop :: test_memmap.py -- negative tests of the map validator
#
# Each case mutates config/silicaflux_die.yaml in memory, writes it to a temp
# file and runs gen_memmap.py --validate-only on it.  The case passes when the
# validator REJECTS the map with the expected rule in its message.  The
# unmodified map must validate.  Writes reports/memmap_tests.md.
# =============================================================================
import copy, os, subprocess, sys, tempfile
import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE = yaml.safe_load(open(os.path.join(ROOT, 'config/silicaflux_die.yaml')))


def region(m, name):
    return next(r for r in m['regions'] if r['name'] == name)


def mut(fn):
    m = copy.deepcopy(BASE)
    fn(m)
    return m


CASES = [
    ("valid map accepted", None, lambda m: None),
    ("window not a power of two", "R1", lambda m: region(m, 'EXTMEM_CSR').update(window=0x1800)),
    ("base not aligned to window", "R1", lambda m: region(m, 'DIE_REGS').update(base=0x3E008000)),
    ("populated size larger than window", "R1", lambda m: region(m, 'DIE_REGS').update(size=0x20000)),
    ("SPM stride smaller than window", "R2", lambda m: region(m, 'VEC_SPM').update(stride=0x80000)),
    ("SPM windows overlap the external-memory window (HPC)", "R3", lambda m: region(m, 'EXTMEM').update(base=0x30000000, window=0x4000000)),
    ("register window overlaps the external-memory CSR", "R3", lambda m: region(m, 'DIE_REGS').update(base=0x3F000000)),
    ("fabric region outside the ControlCore EXT window", "R4", lambda m: region(m, 'DIE_REGS').update(base=0x50000000)),
    ("SHARED_SRAM moved away from the firmware DEVMEM base", "R5", lambda m: (region(m, 'SHARED_SRAM').update(base=0x24000000))),
    ("VEC_SPM moved away from the firmware TILE_SPM base", "R5", lambda m: region(m, 'VEC_SPM').update(base=0x31000000)),
    ("a region mapped over the firmware probe address 0x2800_0000", "R3", lambda m: region(m, 'EXTMEM').update(base=0x28000000)),
    ("ControlCore IMEM size changed", "R5", lambda m: region(m, 'CC_IMEM').update(size=0x8000)),
    ("page 8 is not vector tile 0", "R5", lambda m: next(p for p in m['pages'] if p['page'] == 8).update(instance=['VEC', 1])),
    ("die page outside the forwarded pages 8..15", "R7", lambda m: next(p for p in m['pages'] if p['name'] == 'VEC3').update(page=16)),
    ("two pages with the same number", "R7", lambda m: next(p for p in m['pages'] if p['name'] == 'TSU1').update(page=12)),
    ("missing page for vector instance 3", "R7", lambda m: m['pages'].remove(next(p for p in m['pages'] if p['name'] == 'VEC3'))),
    ("misaligned DIE_SYS register", "R8", lambda m: m['die_sys_regs'][0].update(ofs=0x002)),
    ("duplicate DIE_SYS register offset", "R8", lambda m: m['die_sys_regs'][1].update(ofs=0x000)),
    ("register outside every sub-block", "R8", lambda m: m['die_sys_regs'][0].update(ofs=0x900)),
    ("overlapping DIE_SYS sub-blocks", "R8", lambda m: m['die_sys_subpages'][1].update(ofs=0x080)),
    ("DMA channels do not fit their page", "R8", lambda m: m.update(dma_channel_stride=0x800)),
    ("duplicate IRQ bit", "R9", lambda m: next(q for q in m['irqs'] if q['name'] == 'NOC_ERR').update(bit=16)),
    ("IRQ instance range overlaps the next source", "R9", lambda m: next(q for q in m['irqs'] if q['name'] == 'TSU').update(bit=2)),
    ("duplicate error code", "R9", lambda m: m['errors'][2].update(code=1)),
    ("error code >= 32", "R9", lambda m: m['errors'][2].update(code=40)),
    ("access matrix names an unknown target", "R10", lambda m: m['fabric_access']['DMA'].append('ROM')),
    ("5 vector clusters (page budget is 4)", "R6", lambda m: m['configurations']['HPC'].update(num_vector_clusters=5)),
    ("3 tensor clusters", "R6", lambda m: m['configurations']['HPC'].update(num_tensor_clusters=3)),
    ("banks not a multiple of slices", "R6", lambda m: m['configurations']['HPC'].update(num_sram_banks=10)),
    ("16 banks per slice", "R6", lambda m: m['configurations']['MIN'].update(num_sram_banks=16)),
    ("SRAM smaller than the firmware's 1 MiB", "R6", lambda m: m['configurations']['MIN'].update(sram_bytes=0x80000)),
    ("SRAM size not a power of two", "R6", lambda m: m['configurations']['MIN'].update(sram_bytes=0x180000)),
    ("NoC topology 3", "R6", lambda m: m['configurations']['MIN'].update(noc_topology=3)),
    ("three SRAM slices", "R6", lambda m: m['configurations']['HPC'].update(num_sram_slices=3, num_sram_banks=12)),
]


def main():
    rows, ok_all = [], True
    for name, rule, fn in CASES:
        m = mut(fn)
        with tempfile.NamedTemporaryFile('w', suffix='.yaml', delete=False) as f:
            yaml.safe_dump(m, f, sort_keys=False)
            path = f.name
        p = subprocess.run([sys.executable, os.path.join(ROOT, 'scripts/gen_memmap.py'), '--yaml', path, '--validate-only'],
                           capture_output=True, text=True)
        os.unlink(path)
        out = (p.stdout + p.stderr).strip().replace('\n', ' / ')
        if rule is None:
            ok = p.returncode == 0
        else:
            ok = p.returncode != 0 and rule in out
        ok_all &= ok
        rows.append((name, rule or 'accept', 'PASS' if ok else 'FAIL', out[:160]))
        print(f"{'PASS' if ok else 'FAIL'}  {name}")
    L = ["# Memory-map validator tests", "", f"**{sum(r[2] == 'PASS' for r in rows)} / {len(rows)} PASS** "
         "(`scripts/test_memmap.py`: every illegal map must be rejected with the expected rule; the real map must validate).", "",
         "| Case | Expected | Result | Validator output (truncated) |", "|---|---|---|---|"]
    for r in rows:
        L.append(f"| {r[0]} | {r[1]} | {r[2]} | `{r[3].replace('|', '/')}` |")
    os.makedirs(os.path.join(ROOT, 'reports'), exist_ok=True)
    open(os.path.join(ROOT, 'reports/memmap_tests.md'), 'w').write("\n".join(L) + "\n")
    return 0 if ok_all else 1


if __name__ == '__main__':
    sys.exit(main())
