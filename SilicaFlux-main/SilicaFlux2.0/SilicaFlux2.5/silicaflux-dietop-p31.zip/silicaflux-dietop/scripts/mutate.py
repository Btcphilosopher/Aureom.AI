#!/usr/bin/env python3
# =============================================================================
# SilicaFlux DieTop :: mutate.py -- does the integration testbench catch real bugs?
#
# Each mutant injects one deliberate defect into the NEW die RTL (never into
# third_party/), rebuilds the Verilator testbench in its own workspace
# (build/mut/<name>/, rtl/ copied and mutated, third_party/ and tb/ linked) and
# runs the named test.  A mutant is KILLED when the run does not end in
# "TB RESULT PASS" (a failed check, the protocol checkers, an assertion or the
# watchdog timeout).  Writes reports/mutation.md.
# =============================================================================
import json, os, re, shutil, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TBF = ("third_party/silicaflux-datafabric/tb/common/sfb_protocol_checker.sv third_party/silicaflux-extmem/sim/models/extmem_sim_mc.sv "
       "third_party/silicaflux-extmem/tb/extmem_mc_checker.sv tb/tb_die_top.sv")
DEFS = {'MIN': '', 'MINEXT': "+define+TB_EXT=1 +define+TB_TOPO=1 +define+TB_CFGID=255",
        'V2': ("+define+TB_NV=2 +define+TB_NT=1 +define+TB_NBANKS=8 +define+TB_NSL=2 +define+TB_SRAMB=32\\'h00200000 "
                          "+define+TB_ND=2 +define+TB_TOPO=1 +define+TB_CFGID=255")}
# (name, file, old, new, config, test, what it breaks)
MUTANTS = [
    ("fence_never_drains", "rtl/subsys/die_sfb_rst_fence.sv", "wire drain = !dom_rst_n || drain_q;", "wire drain = 1'b0;",
     "MINEXT", "accreset", "reset fence passes orphan responses to a freshly reset accelerator"),
    ("fence_drops_held_request", "rtl/subsys/die_sfb_rst_fence.sv", "      m_req_valid = hold_q;", "      m_req_valid = 1'b0;",
     "MINEXT", "accreset", "a request presented when the domain resets is withdrawn (SFB2 R2)"),
    ("gate_ignores_domain", "rtl/subsys/die_sfb_dom_gate.sv", "wire dom_ok = dom_rst_n && dom_clk_live;", "wire dom_ok = 1'b1;",
     "MIN", "accreset", "scratchpad window forwards into a gated / reset accelerator domain"),
    ("gate_no_abandon", "rtl/subsys/die_sfb_dom_gate.sv", "        if (!dom_rst_n) begin                    // lost to a domain reset: answer with an error",
     "        if (1'b0) begin", "MIN", "accreset", "an outstanding scratchpad access lost to a reset is never answered"),
    ("host_no_decode_error", "rtl/subsys/host_io_subsystem.sv", "  wire a_fab = (host_req_addr >= EXT_LO) && (host_req_addr < EXT_HI);",
     "  wire a_fab = !a_cc;", "MIN", "invalid", "host addresses outside the die are sent into the fabric"),
    ("cc_vector_irq_dead", "rtl/subsys/die_sysctrl.sv",
     "assign cc_vec_irq     = |(irq_raw & cc_vec_en_q);", "assign cc_vec_irq     = 1'b0;",
     "MIN", "irq", "vector-tile interrupts never reach the ControlCore"),
    ("host_irq_ignores_enable", "rtl/subsys/die_sysctrl.sv",
     "assign host_irq       = |(irq_raw & host_en_q) || cc_host_irq;", "assign host_irq       = |irq_raw;",
     "MIN", "irq", "host interrupt routing ignores IRQ_HOST_EN"),
    ("no_sram_init", "rtl/subsys/memory_subsystem.sv", "      init_q <= (SRAM_INIT != 0);", "      init_q <= 1'b0;",
     "MIN", "reset", "shared SRAM not initialised (parity errors on first read, readiness too early)"),
    ("reset_seq_off_by_one", "rtl/subsys/clock_reset_subsystem.sv",
     "if (cnt_q == CW'(FABRIC_DELAY)) begin", "if (cnt_q == CW'(FABRIC_DELAY + 1)) begin",
     "MIN", "reset", "reset sequencer timing differs from its specification"),
    ("dma_channel_decode", "rtl/subsys/dma_subsystem.sv",
     ".rb_sel(rb_sel && rb_addr[11:10] == 2'b00 && 32'(ch) == c),", ".rb_sel(rb_sel && 32'(ch) == c),",
     "MIN", "regs", "DMA channel registers alias across the DMA page (refused write with a side effect)"),
    ("access_matrix_open", "rtl/top/silicaflux_die_top.sv",
     "f_access[m*NTG + t] = silicaflux_die_pkg::DIE_CLASS_ACCESS[mc * silicaflux_die_pkg::DIE_NUM_TCLASS + tc];",
     "f_access[m*NTG + t] = 1'b1;", "MIN", "invalid", "every master may reach every target (DMA into register space)"),
    ("errlog_wrong_port", "rtl/subsys/ras_test_subsystem.sv",
     "f_port = noc_dec_master; f_addr = noc_dec_addr;", "f_port = 8'd0; f_addr = noc_dec_addr;",
     "MIN", "invalid", "error log records the wrong fabric master"),
    ("regs_window_dma_never_errs", "rtl/subsys/die_regs_window.sv",
     "    pg_err[silicaflux_die_pkg::DIE_REGS_PAGE_DMA]                 = dma_err;",
     "    pg_err[silicaflux_die_pkg::DIE_REGS_PAGE_DMA]                 = 1'b0;",
     "MIN", "identity", "absent DMA channels answer instead of refusing"),
    ("slice_base_wrong", "rtl/top/silicaflux_die_top.sv",
     "+ 32'(t) * 32'(SLICE_BYTES);", "+ 32'(t) * 32'(SLICE_BYTES / 2);",
     "V2", "sram", "distributed SRAM slices decoded at the wrong base (multi-slice configuration)"),
    ("tsu_page_swapped", "rtl/subsys/compute_subsystem.sv",
     "assign t_hit[j] = (32'(page) == silicaflux_config_pkg::tsu_page(j));",
     "assign t_hit[j] = (32'(page) == silicaflux_config_pkg::vec_page(j));",
     "MIN", "identity", "tensor unit answers on the vector tile's page"),
]


def main():
    sel = sys.argv[1:]
    rows = []
    for (name, f, old, new, cfg, test, what) in MUTANTS:
        if sel and name not in sel:
            continue
        ws = os.path.join(ROOT, 'build/mut', name)
        shutil.rmtree(ws, ignore_errors=True)
        os.makedirs(ws)
        shutil.copytree(os.path.join(ROOT, 'rtl'), os.path.join(ws, 'rtl'))
        for d in ('third_party', 'tb'):
            os.symlink(os.path.join(ROOT, d), os.path.join(ws, d))
        src = open(os.path.join(ws, f)).read()
        if src.count(old) != 1:
            rows.append((name, cfg, test, what, 'NOT APPLIED', '')); print(name, 'NOT APPLIED'); continue
        open(os.path.join(ws, f), 'w').write(src.replace(old, new))
        t0 = time.time()
        b = subprocess.run(f"verilator --binary --timing -O2 -j {os.cpu_count()} -Wno-fatal -Wno-lint -Wno-style -Wno-TIMESCALEMOD "
                           f"--top-module tb_die_top {DEFS[cfg]} -Mdir obj -o vtb -f rtl/files_die.f {TBF}",
                           shell=True, cwd=ws, capture_output=True, text=True)
        if b.returncode != 0:
            verdict, detail = 'KILLED (does not build)', (b.stdout + b.stderr).strip().splitlines()[-1][:120]
        else:
            r = subprocess.run(f"obj/vtb +test={test} +timeout=3000000", shell=True, cwd=ws, capture_output=True, text=True, timeout=1800)
            out = r.stdout + r.stderr
            m = re.search(r"TB RESULT (\w+)[^\n]*", out)
            first = next((l for l in out.splitlines() if 'CHECK FAIL' in l or 'FAIL [' in l or 'Assertion' in l or 'TIMEOUT' in l), '')
            if m and m.group(1) == 'PASS' and r.returncode == 0:
                verdict, detail = 'SURVIVED', m.group(0)[:120]
            else:
                verdict, detail = 'KILLED', (first or (m.group(0) if m else 'no result'))[:160]
        rows.append((name, cfg, test, what, verdict, detail))
        print(f"{name:28s} {verdict:10s} ({time.time() - t0:.0f} s) {detail}", flush=True)
        shutil.rmtree(os.path.join(ws, 'obj'), ignore_errors=True)
    # merge with earlier results (running a subset re-runs only those mutants)
    jpath = os.path.join(ROOT, 'reports/mutation.json')
    old = {r[0]: r for r in (json.load(open(jpath)) if (sel and os.path.exists(jpath)) else [])}
    for r in rows:
        old[r[0]] = list(r)
    order = [m[0] for m in MUTANTS]
    rows = [tuple(old[n]) for n in order if n in old]
    json.dump(rows, open(jpath, 'w'), indent=1)
    killed = sum(r[4].startswith('KILLED') for r in rows)
    L = ["# Mutation testing of the new die RTL", "",
         f"**{killed} / {len(rows)} mutants killed** (`scripts/mutate.py`).  Each mutant is one deliberate defect in "
         "the Project 31 RTL (never in `third_party/`), built and run in its own workspace; it is killed when the "
         "run does not end in `TB RESULT PASS`.", "",
         "| Mutant | Defect | Config | Test | Verdict | First evidence |", "|---|---|---|---|---|---|"]
    for r in rows:
        L.append(f"| {r[0]} | {r[3]} | {r[1]} | {r[2]} | {r[4]} | `{r[5].replace('|', '/')}` |")
    open(os.path.join(ROOT, 'reports/mutation.md'), 'w').write("\n".join(L) + "\n")
    return 0 if killed == len(rows) else 1


if __name__ == '__main__':
    sys.exit(main())
