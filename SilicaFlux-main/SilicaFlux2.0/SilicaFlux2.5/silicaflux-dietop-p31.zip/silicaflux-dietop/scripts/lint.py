#!/usr/bin/env python3
# =============================================================================
# SilicaFlux DieTop :: lint.py -- static checks of the die RTL
#
#   1. Verilator 5.020 --lint-only -Wall on silicaflux_die_min, silicaflux_die_hpc and
#      silicaflux_die_top with the V2 / V3 / MINEXT parameter sets.  Warnings in the
#      new RTL (rtl/) must be zero; warnings inside third_party/ are counted and
#      reported separately (vendored, unmodified -- not ours to change).
#   2. Icarus Verilog 12 elaboration of silicaflux_die_min and silicaflux_die_hpc.
#   3. Yosys 0.33 elaboration (read_verilog -sv, hierarchy -check) of both tops.
#   4. Illegal parameter sets: silicaflux_die_top must REFUSE to elaborate
#      (Verilator, generate-time $fatal from silicaflux_config_pkg::cfg_error).
# Writes reports/lint.md.
# =============================================================================
import os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
F = '-f rtl/files_die.f'
LEGAL = [
    ('silicaflux_die_min', ''),
    ('silicaflux_die_hpc', ''),
    ('silicaflux_die_top', '-GNUM_VECTOR_CLUSTERS=2 -GNUM_SRAM_BANKS=8 -GNUM_SRAM_SLICES=2 -GSRAM_BYTES=2097152 '
                           '-GNUM_DMA_CHANNELS=2 -GNOC_TOPOLOGY=1 -GCONFIG_ID=255'),
    ('silicaflux_die_top', '-GNUM_TENSOR_CLUSTERS=2 -GNUM_SRAM_BANKS=2 -GNOC_TOPOLOGY=2 -GEXTMEM_EN=1 -GEXTMEM_ASYNC=1 -GCONFIG_ID=255'),
    ('silicaflux_die_top', '-GEXTMEM_EN=1 -GNOC_TOPOLOGY=1 -GCONFIG_ID=255'),
]
ILLEGAL = [
    ('5 vector clusters', '-GNUM_VECTOR_CLUSTERS=5'),
    ('0 vector clusters', '-GNUM_VECTOR_CLUSTERS=0'),
    ('3 tensor clusters', '-GNUM_TENSOR_CLUSTERS=3'),
    ('5 DMA channels', '-GNUM_DMA_CHANNELS=5'),
    ('3 SRAM slices', '-GNUM_SRAM_SLICES=3 -GNUM_SRAM_BANKS=6'),
    ('6 banks in 1 slice (not a power of two)', '-GNUM_SRAM_BANKS=6'),
    ('16 banks per slice', '-GNUM_SRAM_BANKS=16'),
    ('512 KiB SRAM (< firmware minimum)', '-GSRAM_BYTES=524288'),
    ('1.5 MiB SRAM (not a power of two)', '-GSRAM_BYTES=1572864'),
    ('NoC topology 3', '-GNOC_TOPOLOGY=3'),
    ('EXTMEM_ASYNC without EXTMEM', '-GEXTMEM_ASYNC=1'),
    ('TESTCORE_EN = 1 (not supported in this release)', '-GTESTCORE_EN=1'),
]


def run(cmd, tmo=1800):
    t0 = time.time()
    p = subprocess.run(cmd, shell=True, cwd=ROOT, capture_output=True, text=True, timeout=tmo)
    return p.returncode, p.stdout + p.stderr, time.time() - t0


def verilator_legal(top, g):
    rc, out, dt = run(f"verilator --lint-only -Wall -Wno-fatal --top-module {top} {g} {F}")
    warn = [l for l in out.splitlines() if l.startswith('%Warning')]
    def path(l):                                     # "%Warning-CODE: <path>:<line>:<col>: ..."
        m = re.match(r'%Warning-\w+: ([^:]+):', l)
        return m.group(1) if m else ''
    ours = [l for l in warn if not path(l).startswith('third_party/')]
    errs = [l for l in out.splitlines() if l.startswith('%Error')]
    return dict(top=top, g=g, rc=rc, dt=dt, ours=ours, vendored=len(warn) - len(ours), errs=errs)


# Refusal is checked the way a real build sees it: WITHOUT -Wno-fatal, so an elaboration-time $fatal
# (Verilator: %Warning-USERFATAL) stops the tool with a non-zero exit.  Vendored timescale / style notes
# are suppressed so that a LEGAL configuration exits 0 under the same flags (control run below).
STRICT = "verilator --lint-only -Wno-lint -Wno-style -Wno-TIMESCALEMOD --top-module silicaflux_die_top"


def verilator_illegal(name, g):
    rc, out, dt = run(f"{STRICT} {g} {F}")
    msg = next((l.strip() for l in out.splitlines() if 'USERFATAL' in l or l.startswith('%Error')), '')
    return dict(name=name, g=g, refused=(rc != 0 and msg != ''), msg=msg[:170], dt=dt)


def main():
    with ThreadPoolExecutor(2) as ex:
        legal = list(ex.map(lambda a: verilator_legal(*a), LEGAL))
        illegal = list(ex.map(lambda a: verilator_illegal(*a), ILLEGAL))
    ctl_rc, ctl_out, _ = run(f"{STRICT} {F}")                      # control: the default (MIN) parameters
    icarus = []
    for top in ('silicaflux_die_min', 'silicaflux_die_hpc'):
        os.makedirs(os.path.join(ROOT, 'build/lint'), exist_ok=True)
        rc, out, dt = run(f"iverilog -g2012 -s {top} -o build/lint/{top}.vvp {F}")
        errs = [l for l in out.splitlines() if ': error' in l]
        icarus.append((top, rc, len(errs), len([l for l in out.splitlines() if 'sorry:' in l]), dt))
    yosys = []
    incs, srcs = [], []
    for l in open(os.path.join(ROOT, 'rtl/files_die.f')):
        l = l.strip()
        if l and not l.startswith('//'):
            (incs.append('-I' + l[8:]) if l.startswith('+incdir+') else srcs.append(l))
    for top in ('silicaflux_die_min', 'silicaflux_die_hpc'):
        rc, out, dt = run(f"yosys -q -p \"read_verilog -defer -sv -DSYNTHESIS {' '.join(incs)} {' '.join(srcs)}; "
                          f"hierarchy -check -top {top}\"")
        yosys.append((top, rc, dt, next((l for l in out.splitlines() if 'ERROR' in l), '')))
    ok = all(r['rc'] == 0 and not r['ours'] and not r['errs'] for r in legal) and all(r['refused'] for r in illegal) \
        and all(i[1] == 0 and i[2] == 0 for i in icarus) and all(y[1] == 0 for y in yosys) and ctl_rc == 0
    L = ["# Lint and elaboration", "", f"**Overall: {'PASS' if ok else 'FAIL'}** (generated by `scripts/lint.py`).", "",
         "## Verilator 5.020 `--lint-only -Wall` (legal configurations)", "",
         "| Top | Parameters | Exit | Warnings in new RTL (`rtl/`) | Warnings in vendored `third_party/` | Errors |",
         "|---|---|---|---|---|---|"]
    for r in legal:
        L.append(f"| {r['top']} | `{r['g'] or '(wrapper defaults)'}` | {r['rc']} | {len(r['ours'])} | {r['vendored']} | {len(r['errs'])} |")
    for r in legal:
        for w in r['ours'][:20]:
            L.append(f"\n    {w}")
    L += ["", "Vendored warnings are reported, not fixed: those sources are reused unmodified (`third_party/SHA256SUMS`).",
          "Waiver in new RTL: `die_sfb_rst_fence` simulation-only counter assertion samples `rst_n` synchronously "
          "(`lint_off SYNCASYNCNET` around that `ifndef SYNTHESIS` block only).", "",
          "## Illegal parameter sets (must refuse to elaborate)", "",
          f"Flags: `{STRICT}` (no `-Wno-fatal`). Control: the same command with the default (legal) parameters "
          f"exits **{ctl_rc}**.", "",
          "| Case | Parameters | Refused (non-zero exit + fatal message) | Message |", "|---|---|---|---|"]
    for r in illegal:
        L.append(f"| {r['name']} | `{r['g']}` | {'yes' if r['refused'] else '**NO**'} | `{r['msg'].replace('|', '/')}` |")
    L += ["", "## Icarus Verilog 12 elaboration", "", "| Top | Exit | Errors | `sorry` notes (vendored constant selects) |", "|---|---|---|---|"]
    for t, rc, ne, ns, dt in icarus:
        L.append(f"| {t} | {rc} | {ne} | {ns} |")
    L += ["", "## Yosys 0.33 elaboration (`read_verilog -defer -sv -DSYNTHESIS`, `hierarchy -check`)", "",
          "| Top | Exit | First error |", "|---|---|---|"]
    for t, rc, dt, e in yosys:
        L.append(f"| {t} | {rc} | {e} |")
    os.makedirs(os.path.join(ROOT, 'reports'), exist_ok=True)
    open(os.path.join(ROOT, 'reports/lint.md'), 'w').write("\n".join(L) + "\n")
    print("\n".join(L))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
