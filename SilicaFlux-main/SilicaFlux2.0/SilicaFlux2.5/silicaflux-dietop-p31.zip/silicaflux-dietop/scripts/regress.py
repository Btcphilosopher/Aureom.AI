#!/usr/bin/env python3
# =============================================================================
# SilicaFlux DieTop :: regress.py -- build every configuration, run the test
# matrix, write reports/regression.md and reports/regression.json.
#
#   regress.py                       full matrix
#   regress.py --cfg MIN --quick     one configuration, no back-pressure variants
# Every number in the report comes from a "TB RESULT" line of a run log
# (reports/sim/<cfg>_<test>_bp<bp>_s<seed>.log); nothing is estimated.
# =============================================================================
import argparse, json, os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIGS = {
    'MIN':    'SILICAFLUX_MIN: 1 vector tile, 1 tensor unit, 1 MiB / 4 banks, shared-bus NoC, 1 DMA',
    'HPC':    'SILICAFLUX_HPC: 4 vector tiles, 2 tensor units, 4 MiB / 4 slices x 4 banks, crossbar NoC, 2 DMA, ExtMem',
    'V2':     'variation: 2 vector tiles, 1 tensor unit, 2 MiB / 2 slices x 4 banks, crossbar, 2 DMA',
    'V3':     'variation: 1 vector tile, 2 tensor units, 1 MiB / 2 banks, 2-D mesh NoC, ExtMem with async MC clock (bridge CDC)',
    'MINEXT': 'variation: MIN + ExtMem, crossbar NoC',
}
# (test, bp%, seed, extra plusargs)
MATRIX = [('all', 0, 1, ''), ('all', 40, 2, '+mcbp=60'), ('all', 70, 3, '+mcbp=40')]
FIRMWARE = {'MIN', 'HPC'}


def sh(cmd, log):
    with open(log, 'w') as f:
        return subprocess.run(cmd, shell=True, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT).returncode


def build(cfg, jobs):
    t0 = time.time()
    rc = subprocess.run(f"make sim CFG={cfg} JOBS={jobs}", shell=True, cwd=ROOT,
                        stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT).returncode
    return rc, time.time() - t0


def run(cfg, test, bp, seed, extra):
    os.makedirs(os.path.join(ROOT, 'reports/sim'), exist_ok=True)
    log = f"reports/sim/{cfg}_{test}_bp{bp}_s{seed}.log"
    t0 = time.time()
    tmo = '+timeout=80000000' if test == 'firmware' else ''
    rc = sh(f"build/sim_{cfg}/vtb +test={test} +bp={bp} +seed={seed} {extra} {tmo}", os.path.join(ROOT, log))
    txt = open(os.path.join(ROOT, log), errors='replace').read()
    m = re.search(r"TB RESULT (\w+) .*checks=(\d+) fails=(\d+) cycles=(\d+)", txt)
    fw = re.search(r"firmware self-test on the die: (\d+) checks, (\d+) fails", txt)
    res = dict(cfg=cfg, test=test, bp=bp, seed=seed, extra=extra, rc=rc, log=log, wall_s=round(time.time() - t0, 1),
               verdict=m.group(1) if m else 'NO-RESULT', checks=int(m.group(2)) if m else 0,
               fails=int(m.group(3)) if m else -1, cycles=int(m.group(4)) if m else 0,
               fw_checks=int(fw.group(1)) if fw else None, fw_fails=int(fw.group(2)) if fw else None)
    res['pass'] = (rc == 0 and res['verdict'] == 'PASS')
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cfg', nargs='*', default=list(CONFIGS))
    ap.add_argument('--quick', action='store_true')
    ap.add_argument('--par', type=int, default=3)
    ap.add_argument('--report-only', action='store_true', help='rewrite reports/regression.md from regression.json')
    a = ap.parse_args()
    if a.report_only:
        d = json.load(open(os.path.join(ROOT, 'reports/regression.json')))
        return write_report(d['builds'], d['results'], [c for c in CONFIGS if c in d['builds']])
    builds = {}
    for c in a.cfg:
        rc, dt = build(c, os.cpu_count() or 2)
        builds[c] = dict(rc=rc, seconds=round(dt))
        print(f"build {c}: rc={rc} ({dt:.0f} s)", flush=True)
    jobs = []
    for c in a.cfg:
        if builds[c]['rc'] != 0:
            continue
        for (t, bp, s, x) in (MATRIX[:1] if a.quick else MATRIX):
            jobs.append((c, t, bp, s, x))
        if c in FIRMWARE:
            jobs.append((c, 'firmware', 0, 1, ''))
    with ThreadPoolExecutor(a.par) as ex:
        results = list(ex.map(lambda j: run(*j), jobs))
    for r in results:
        print(f"{r['cfg']:7s} {r['test']:9s} bp={r['bp']:<3d} seed={r['seed']} {r['verdict']:9s} checks={r['checks']} "
              f"fails={r['fails']} cycles={r['cycles']}" + (f" fw={r['fw_checks']}/{r['fw_fails']}" if r['fw_checks'] is not None else ''),
              flush=True)
    jpath = os.path.join(ROOT, 'reports/regression.json')
    if set(a.cfg) != set(CONFIGS) and os.path.exists(jpath):      # subset run: merge with earlier results
        old = json.load(open(jpath))
        keep = [r for r in old['results'] if r['cfg'] not in a.cfg]
        results = sorted(keep + results, key=lambda r: (list(CONFIGS).index(r['cfg']), r['test'], r['bp']))
        builds = {**{k: v for k, v in old['builds'].items() if k not in a.cfg}, **builds}
        a.cfg = [c for c in CONFIGS if c in builds]
    os.makedirs(os.path.join(ROOT, 'reports'), exist_ok=True)
    json.dump(dict(builds=builds, results=results), open(os.path.join(ROOT, 'reports/regression.json'), 'w'), indent=1)
    return write_report(builds, results, a.cfg)


def write_report(builds, results, cfgs):
    npass = sum(r['pass'] for r in results)
    L = ["# Regression (Verilator 5.020)", "",
         f"**{npass} / {len(results)} runs pass** (a run passes when its log ends with `TB RESULT PASS` and exit status 0; "
         "every run also requires zero SFB2 protocol-checker violations on the host port, on every NoC master / target "
         "port and on the accelerator side of every boundary block (gate / fence), the reset-coverage points of `accreset` "
         "(see docs/04_VERIFICATION.md), and zero SFMC checker / controller-model violations where external memory is present).", "",
         "Generated by `scripts/regress.py` from the run logs in `reports/sim/`.", "", "## Configurations", "",
         "| Config | Description | Build |", "|---|---|---|"]
    for c in cfgs:
        L.append(f"| {c} | {CONFIGS[c]} | {'ok' if builds[c]['rc'] == 0 else 'FAILED'} ({builds[c]['seconds']} s) |")
    L += ["", "## Runs", "", "| Config | Test | Host back-pressure | Seed | Extra | Result | TB checks | Firmware self-test | Cycles | Log |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for r in results:
        fw = f"{r['fw_checks']} checks, {r['fw_fails']} fails" if r['fw_checks'] is not None else ''
        L.append(f"| {r['cfg']} | {r['test']} | {r['bp']} % | {r['seed']} | `{r['extra']}` | {'PASS' if r['pass'] else 'FAIL'} | "
                 f"{r['checks']} ({r['fails']} failed) | {fw} | {r['cycles']} | `{r['log']}` |")
    open(os.path.join(ROOT, 'reports/regression.md'), 'w').write("\n".join(L) + "\n")
    print(f"{npass}/{len(results)} runs pass")
    return 0 if npass == len(results) else 1


if __name__ == '__main__':
    sys.exit(main())
