# SilicaFlux DieTop — Project 31: complete top-level die architecture

**Primary RTL:** [`rtl/top/silicaflux_die_top.sv`](rtl/top/silicaflux_die_top.sv) · Aureom.AI | SilicaFlux-HPC | Physical Design Batch 04

This is the master hierarchical top level of the SilicaFlux die. It connects the following blocks through one
authoritative, generated integration contract:

* the ControlCore (RV32IM control processor, boot ROM, mailbox, PMU, RAS);
* FP32 vector clusters and INT8 4×4 tensor clusters;
* banked and distributed shared SRAM;
* the DataFabric-NoC;
* die DMA channels and the external-memory bridge;
* a simulation host bridge, the reset sequencer and the die error log.

Every reused block is vendored **unmodified** (`third_party/`, SHA-256 manifest).

> **Status: read this first.** All results are RTL simulation (Verilator 5.020, with cross-checks in Icarus 12)
> and Yosys 0.33 generic elaboration and coarse synthesis. There is no PDK, SRAM macro, PLL, DDR or PCIe PHY,
> place-and-route or STA. **No silicon area, frequency or power figure is claimed anywhere.** The HPC
> configuration is an architectural exploration. Behavioural and simulation-only stand-ins are labelled as
> such. Delivered as an archive; nothing was committed. See [docs/06_LIMITATIONS.md](docs/06_LIMITATIONS.md).

## Results

All numbers below come from the final run on the frozen sources (`reports/`).

| Check | Result | Report |
|---|---|---|
| **End-to-end workload, MIN**: unmodified ControlCore firmware loaded by the host. It boots, raises `device_ready_o`, runs its own self-test on the die, and serves mailbox GEMM / VECTOR / DMA commands checked against the TB reference | **PASS**: **188/188 firmware self-test checks** (12 groups), 21/21 host checks, TEST_CTRL DONE without FAIL | `reports/sim/MIN_firmware_bp0_s1.log` |
| Same firmware scenario on HPC | **PASS** (188/188, 21/21) | `reports/sim/HPC_firmware_bp0_s1.log` |
| Host-driven integration suite: 13 tests (identity, reset, regs, sram, dma, vector, gemm, irq, invalid, concur, extmem, accreset, porreset), 5 configurations × 3 back-pressure profiles | **17/17 runs PASS**. Checks per run: MIN 318, HPC 474, V2 414, V3 349, MINEXT 330; 0 protocol violations | [regression](reports/regression.md) |
| Mutation testing: 15 deliberate defects in the new RTL | **15/15 killed** | [mutation](reports/mutation.md) |
| Lint: Verilator `-Wall`, 5 legal parameter sets | **0 warnings in the new RTL**; 12/12 illegal parameter sets refused at elaboration | [lint](reports/lint.md) |
| Elaboration in three tools (MIN and HPC) | Verilator, Icarus 12, Yosys 0.33: all exit 0 | [lint](reports/lint.md) |
| Cross-simulator smoke test (MIN) | Icarus **and** Verilator: 27/27 each, identical cycle counts | `reports/sim/*_MIN_smoke.log` |
| Memory-map generator: validation rules R1–R10 | real map accepted; **33/33 illegal maps rejected** | [memmap_tests](reports/memmap_tests.md) |
| Hierarchy (Yosys generic synthesis to the coarse stage, hierarchy kept) | MIN and HPC complete; instance trees and partition weights | [MIN](reports/hierarchy_MIN.md), [HPC](reports/hierarchy_HPC.md) |
| Deterministic boot | PLATFORM_READY at **65 537** cycles after fabric release (MIN and HPC); DEVICE_READY at 739 230 with firmware | regression logs |
| Upstream IP re-verified independently | ControlCore system 231/231; TestCore TAP 14 924 and MBIST 207 checks; PowerClock lint + `clock_idle`; HostLink smoke; RAS SECDED 10/10 | `reports/independent/` |
| Vendored sources | 232 files, byte-identical to the archives (SHA-256) | `third_party/SHA256SUMS` |

Integration problems found and fixed on the way (details in [docs/04_VERIFICATION.md](docs/04_VERIFICATION.md)):

* the ControlCore refuses its forwarded pages while the accelerators are isolated, so die registers moved to a fabric region;
* parity SRAM needed a hardware initialisation sweep (the firmware self-test hit a parity error);
* mesh placement put two masters on one node;
* new boundary blocks were needed for the gated, resettable accelerator domain (`die_sfb_dom_gate`, `die_sfb_rst_fence`). Each of their failure modes is reproduced and caught by the tests.

## The two configurations

| | SILICAFLUX_MIN (`silicaflux_die_min`) | SILICAFLUX_HPC (`silicaflux_die_hpc`) |
|---|---|---|
| Control | ControlCore (real CPU + firmware) | ControlCore |
| Vector compute | 1 HPC Module 08 tile (4 FP32 lanes, 64 KiB SPM) | 4 tiles |
| Tensor compute | 1 TENSORCORE 08 unit (4×4 INT8 array) | 2 units |
| Shared SRAM | 1 MiB, 1 slice × 4 banks, parity | 4 MiB distributed, 4 slices × 4 banks |
| Interconnect | DataFabric-NoC **shared bus** (5 masters × 3 targets) | DataFabric-NoC **crossbar** (10 × 11) |
| DMA | 1 channel | 2 channels |
| External memory | — | Project 24 bridge → SFMC boundary |
| Host | simulation host bridge (SFB2 port) | simulation host bridge (the HostLink / PCIe wrapper is documented, not built) |
| Clock | one functional clock + the ControlCore's ICG-gated accelerator clock | same (`EXTMEM_ASYNC` = 1 is supported via the bridge's own CDC) |

`silicaflux_die_top` takes `NUM_VECTOR_CLUSTERS`, `NUM_TENSOR_CLUSTERS` and `NUM_SRAM_BANKS` (plus slices, SRAM
size, DMA channels, topology, external memory, …). It validates them at elaboration and refuses illegal sets.

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository audit; status of every dependency | [docs/00_AUDIT.md](docs/00_AUDIT.md), [docs/DEPENDENCY_MATRIX.md](docs/DEPENDENCY_MATRIX.md), `reports/independent/` |
| 2 | SILICAFLUX_MIN and SILICAFLUX_HPC | `config/silicaflux_die.yaml` → `rtl/top/silicaflux_config_pkg.sv`, `rtl/top/silicaflux_die_cfg_wrappers.sv` |
| 3 | `silicaflux_die_top` with parameters and limits | `rtl/top/silicaflux_die_top.sv` (`cfg_error()` checked at elaboration) |
| 4 | One authoritative contract package | `rtl/top/silicaflux_die_pkg.sv` (generated: widths, IDs, error codes, regions, IRQs, configuration IDs, access matrix) |
| 5 | Hierarchy | `rtl/subsys/` — [docs/01_ARCHITECTURE.md](docs/01_ARCHITECTURE.md) §1 |
| 6 | Collision-free memory map, C header, documentation | `scripts/gen_memmap.py` (rules R1–R10), [docs/MEMORY_MAP.md](docs/MEMORY_MAP.md), `sw/include/silicaflux_die_map.h` |
| 7 | Reset and boot, readiness, device-ready | `rtl/subsys/clock_reset_subsystem.sv`, `die_sysctrl.sv`, [docs/02_RESET_BOOT.md](docs/02_RESET_BOOT.md) |
| 8 | Clocking, PHY boundaries, no unsafe crossings | [docs/03_CLOCKING.md](docs/03_CLOCKING.md), `die_sfb_dom_gate.sv`, `die_sfb_rst_fence.sv` |
| 9 | Missing IP handled honestly | [docs/01_ARCHITECTURE.md](docs/01_ARCHITECTURE.md) §8, [docs/06_LIMITATIONS.md](docs/06_LIMITATIONS.md) |
| 10 | Integration verification | `tb/tb_die_top.sv`, [docs/04_VERIFICATION.md](docs/04_VERIFICATION.md), `reports/` |
| 11 | Deliverables | table below |
| 12 | Both configurations elaborate; MIN passes a real end-to-end workload; nothing fabricated | `reports/lint.md`, `reports/regression.md` (firmware runs) |

## Deliverables

| Deliverable | Files |
|---|---|
| Top level | `rtl/top/silicaflux_die_top.sv`, wrappers `rtl/top/silicaflux_die_cfg_wrappers.sv` |
| Contract and configuration packages | `rtl/top/silicaflux_die_pkg.sv`, `rtl/top/silicaflux_config_pkg.sv` (generated from `config/silicaflux_die.yaml`) |
| Subsystems | `rtl/subsys/*.sv` (14 files) |
| Top-level filelist | `rtl/files_die.f` |
| Memory-map generator | `scripts/gen_memmap.py` + `scripts/test_memmap.py`, outputs `docs/MEMORY_MAP.md`, `sw/include/silicaflux_die_map.h`, `scripts/generated/silicaflux_die_map.py` |
| Integration tests | `tb/tb_die_top.sv`, `scripts/regress.py`, `scripts/mutate.py` |
| Build targets | `Makefile` (`memmap check-map lint sim run firmware regress icarus-smoke hierarchy mutate c-header vendor zip`) |
| Hierarchy report | `scripts/hierarchy.py` → `reports/hierarchy_MIN.md`, `reports/hierarchy_HPC.md`; [docs/05_HIERARCHY_FLOORPLAN.md](docs/05_HIERARCHY_FLOORPLAN.md) |
| Dependency matrix | [docs/DEPENDENCY_MATRIX.md](docs/DEPENDENCY_MATRIX.md) |

## Quick start

Tools (Ubuntu 24.04 packages): Verilator 5.020, Icarus Verilog 12, Yosys 0.33, Python 3 with PyYAML, gcc.
The firmware image is prebuilt (`third_party/silicaflux-controlcore/firmware/build/fw/`), so no RISC-V
toolchain is needed.

```bash
sudo apt-get install -y verilator iverilog yosys python3-yaml
```

```bash
make check-map
```

```bash
make run CFG=MIN TEST=all
```

```bash
make firmware CFG=MIN
```

```bash
make run CFG=HPC TEST=all BP=40
```

```bash
make regress
```

```bash
make lint hierarchy mutate
```

* `make run` builds the Verilator testbench for one configuration (about 2 minutes) and runs a test.
* `make firmware` loads the real ControlCore firmware through the host port and runs its self-test and the
  mailbox workloads (about 2.7 M cycles, a few minutes).
* `make regress` runs every configuration × test × back-pressure profile and writes `reports/regression.md`.

## Layout

```
config/       silicaflux_die.yaml  (single source of truth: map, pages, registers, IRQs, errors, configurations)
rtl/top/      silicaflux_die_top.sv, configuration wrappers, generated packages
rtl/subsys/   subsystems and the new boundary blocks (gate, fence, register window, ...)
rtl/files_die.f
tb/           tb_die_top.sv (integration testbench, all tests + firmware scenario)
scripts/      gen_memmap.py, test_memmap.py, lint.py, regress.py, mutate.py, hierarchy.py, package.py
sw/include/   silicaflux_die_map.h (generated)
docs/         00 audit, dependency matrix, 01 architecture, 02 reset/boot, 03 clocking, 04 verification,
              05 hierarchy/floorplan, 06 limitations, MEMORY_MAP (generated)
reports/      regression, lint, map tests, mutation, hierarchy, sim logs, independent re-runs of upstream projects
third_party/  unmodified SilicaFlux IP (MANIFEST.tsv, SHA256SUMS, PROVENANCE.md)
```
