// =============================================================================
// MeridianQoS formal harness: sf_meridian_decoder.  "No illegal destination selection": the decoder never selects a
// target outside 0..NT-1, never marks a route reachable that does not exist, and resolves overlapping windows to the
// lowest target index.  Purely combinational: proved for ALL addresses (unbounded, depth 1).
// =============================================================================
`default_nettype none
module fv_decoder (
  input wire [7:0] addr
);
  localparam NT = 3, AW = 8, DW = 16;
  localparam [NT*AW-1:0] BASE = {8'h80, 8'h40, 8'h00};
  localparam [NT*AW-1:0] MASK = {8'hC0, 8'hC0, 8'h80};      // windows 0 and 1 overlap on purpose: 0x00-0x7F vs 0x40-0x7F
  localparam [NT-1:0]    CONN = 3'b101;                      // target 1 has no route from this master
  wire hit, reach, misal; wire [1:0] tgt;
  sf_meridian_decoder #(.NT(NT), .AW(AW), .DW(DW), .TGT_BASE(BASE), .TGT_MASK(MASK), .CONN(CONN)) dut (
    .addr(addr), .hit(hit), .tgt(tgt), .reach(reach), .misaligned(misal));

  wire w0 = ((addr & MASK[0*AW +: AW]) == BASE[0*AW +: AW]);
  wire w1 = ((addr & MASK[1*AW +: AW]) == BASE[1*AW +: AW]);
  wire w2 = ((addr & MASK[2*AW +: AW]) == BASE[2*AW +: AW]);
  always @(*) begin
    assert(hit == (w0 || w1 || w2));
    if (hit)   assert(tgt < NT);                              // never an illegal destination
    if (reach) assert(hit && CONN[tgt]);                      // never an unreachable one
    if (hit && !CONN[tgt]) assert(!reach);
    if (w0) assert(hit && tgt == 2'd0);                       // lowest matching window wins
    else if (w1) assert(hit && tgt == 2'd1);
    else if (w2) assert(hit && tgt == 2'd2);
    assert(misal == (addr[0] != 1'b0));                       // DW = 16: bit 0 must be 0
  end
endmodule
`default_nettype wire
