# formal/meridian_qos — formal verification

Run: `make formal` → `reports/formal.md`. Flow: Yosys front end, then **ABC PDR (IC3)** on an AIGER model for control logic (unbounded proofs) or **`yosys-smtbmc` + cvc5** (k-induction); ABC `bmc3` for bounded checks.
(z3 4.8.12 hangs while loading Yosys's encoding of these designs — the same finding as DomainGuard, Module 97 — so cvc5 is used.)

| file | what it holds |
|---|---|
| `fv_arbiter.sv` | black-box harness for `sf_meridian_arbiter`: policy / weights / aging fixed by parameters; assumptions F1 (a requester holds `req` and class until served) and F3 (reset once); properties A1 one-hot / subset of requests, A2 work conserving, A3 bounded wait per policy, A4 exact aging threshold |
| `fv_decoder.sv` | `sf_meridian_decoder` for all addresses: `tgt < NT`, `reach ⇒ hit ∧ CONN`, lowest window wins, alignment — **no illegal destination** |
| `fv_qos.sv` | the whole fabric on a tiny configuration (2 × 2, 2 slots, AW 8, DW 16): P_DEST, P_IDENT, P_NODUP, P_ROUTE, P_NOSPUR, P_STAB, P_OVF, P_ERRSTAT, and (NOLOSS) P_BOUND — see the header of the file |
| (in the RTL) `sf_meridian_queue.sv` `` `ifdef FORMAL `` block | the queue's inductive invariants: count within 0..DEPTH, pointer consistency, no overflow / underflow, **order + integrity of an arbitrary tracked entry**, stability — proved unbounded |

`scripts/formal.py` lists every job (method, depth, claim). Methods: **pdr** = unbounded proof, **prove** = k-induction (unbounded), **bmc** = bounded to the stated depth (not unbounded),
**mut-pdr** = the same property on a deliberately broken RTL copy: it must FAIL (`CAUGHT`). The planted bugs include one the bound alone cannot see (aging threshold off by one): the exact-threshold
property A4 was added for that, and the campaign is what showed it was needed.

What is **not** proved (details in `docs/meridian_qos/08_LIMITATIONS.md`): there is no unbounded proof of the full fabric; the fabric checks are bounded and on a tiny configuration; "no request loss"
is proved only as bounded completion in a good environment (one master, one outstanding transaction: 8 cycles, 9 with the guard; the same bound one cycle smaller fails); reset is checked in simulation; full-size configurations are simulation-verified only.
