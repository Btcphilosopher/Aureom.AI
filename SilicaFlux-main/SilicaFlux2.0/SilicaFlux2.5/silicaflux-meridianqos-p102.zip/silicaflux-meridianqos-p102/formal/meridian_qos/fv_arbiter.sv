// =============================================================================
// MeridianQoS formal harness: sf_meridian_arbiter (black box).  Policy, weights and aging limit are fixed by parameters.
//
// ASSUMPTIONS (the "documented assumptions required for fairness", docs/meridian_qos/03_ARBITRATION_QOS.md):
//   F1 a requester keeps `req` and its class stable until it is served (a crosspoint-queue head is stable until popped);
//   F2 the scheduling configuration (policy, weights, aging limit) does not change;
//   F3 reset in the first cycle only.
//   (No assumption on `en`: the bound counts TRANSFERS of other requesters, not cycles, so it holds however rarely the
//    target accepts.  Converting transfers to cycles needs a bound on the target's service time -- an SoC property.)
//
// PROPERTIES
//   A1 grant is one-hot or zero and only to a requester          A2 work conserving: some request => some grant
//   A4 (STRICT, S > 0) the aging threshold is exact: urgent == (wait >= S)  -- the bound of A3 is an upper bound and cannot
//      see a threshold that is off by one; this property can
//   A3 bounded wait: a requester that keeps requesting has seen at most BOUND transfers of other requesters
//        RR:                 N - 1
//        STRICT, S > 0:      S + N - 1               (S = 0: no bound -- strict priority can starve; nothing asserted)
//        WRR:                (N - 1) + (ceil(N / w_c) + 1) * (W - w_c),   W = sum of the (zero -> 1) weights
// =============================================================================
`default_nettype none

module fv_arbiter #(
  parameter N   = 3,
  parameter POL = 0,
  parameter S   = 0,
  parameter [31:0] WTS = 32'h01020102
) (
  input  wire             clk,
  input  wire             rst_n,
  input  wire [N-1:0]     req,
  input  wire [2*N-1:0]   cls,
  input  wire             en
);
  localparam IW = (N > 1) ? $clog2(N) : 1;
  wire [N-1:0]  grant, urgent;
  wire [IW-1:0] gidx;
  wire          gvalid, reload;
  wire [1:0]    gcls;

  sf_meridian_arbiter #(.N(N), .STRICT_EN(1), .AGEW(8), .WTW(8)) dut (
    .clk(clk), .rst_n(rst_n), .req(req), .cls(cls), .en(en),
    .cfg_policy(POL[1:0]), .cfg_weight(WTS), .cfg_starve(S[7:0]),
    .grant(grant), .gidx(gidx), .gvalid(gvalid), .gcls(gcls), .urgent(urgent), .reload(reload));

  reg f_init = 1'b1;
  always @(posedge clk) f_init <= 1'b0;
  always @(*) if (f_init) assume(!rst_n); else assume(rst_n);

  wire xfer = gvalid && en;

  // F1: waiting requesters hold request and class.  Everything is written per requester with generate / genvar (no shared
  // loop variables between procedural blocks).
  reg [N-1:0]   pv_wait;
  reg [2*N-1:0] pv_cls;
  always @(posedge clk) begin
    pv_wait <= f_init ? {N{1'b0}} : (req & ~({N{xfer}} & grant));
    pv_cls  <= cls;
  end

  // bound per class: elaboration-time constants (a variable-divisor expression would be a nonlinear SMT problem)
  function integer wt; input integer c; integer v;
    begin v = (WTS >> (8*c)) & 255; wt = (v == 0) ? 1 : v; end
  endfunction
  function integer bnd; input integer c; integer ww;
    begin
      ww = wt(0) + wt(1) + wt(2) + wt(3);
      if (POL == 1)       bnd = (N - 1) + ((N + wt(c) - 1) / wt(c) + 1) * (ww - wt(c));
      else if (POL == 2)  bnd = (S > 0) ? (S + N - 1) : -1;
      else                bnd = N - 1;
    end
  endfunction
  localparam integer B0 = bnd(0), B1 = bnd(1), B2 = bnd(2), B3 = bnd(3);

  genvar g;
  generate for (g = 0; g < N; g = g + 1) begin : g_req
    wire [1:0] c = cls[2*g +: 2];
    // F1
    always @(*) if (!f_init && pv_wait[g]) begin
      assume(req[g]);
      assume(cls[2*g +: 2] == pv_cls[2*g +: 2]);
    end
    // wait counter: transfers of other requesters seen while requesting
    reg [7:0] w;
    always @(posedge clk) begin
      if (f_init || !req[g] || (xfer && gidx == g)) w <= 8'd0;
      else if (xfer && w != 8'hFF) w <= w + 8'd1;
    end
    wire [7:0] bound8 = (c == 2'd0) ? B0[7:0] : (c == 2'd1) ? B1[7:0] : (c == 2'd2) ? B2[7:0] : B3[7:0];
    wire       bounded = (c == 2'd0) ? (B0 >= 0) : (c == 2'd1) ? (B1 >= 0) : (c == 2'd2) ? (B2 >= 0) : (B3 >= 0);
    always @(*) if (!f_init) begin
      if (req[g] && bounded) assert(w <= bound8);                        // A3
      assert(!(grant[g] && !req[g]));                                    // A1: only to a requester
      if (POL == 2 && S > 0) assert(urgent[g] == (w >= S));              // A4: the aging threshold is exactly S
    end
  end endgenerate

  always @(*) if (!f_init) begin
    assert(grant == {N{1'b0}} || (grant & (grant - 1'b1)) == {N{1'b0}}); // A1: one-hot or zero
    assert(gvalid == (|grant));
    if (|req) assert(gvalid);                                            // A2
  end
endmodule

`default_nettype wire
