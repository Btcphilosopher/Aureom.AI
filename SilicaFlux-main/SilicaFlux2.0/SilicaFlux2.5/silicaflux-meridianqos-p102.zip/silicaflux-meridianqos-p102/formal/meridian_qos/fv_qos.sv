// =============================================================================
// MeridianQoS formal harness: the whole fabric (sf_meridian_qos) on a tiny configuration, black-box properties.
//
//   2 masters x 2 targets, AW = 8, DW = 16, TAGW = 2, DOMW = 1, 2 slots per master, 2-entry queues.
//   Address map:  t0 = 0x00-0x3F, t1 = 0x40-0x7F, 0x80-0xFF unmapped.   Master 0 has NO route to t1 (CONN).
//   Domain binding: master 0 may present domain 0 only, master 1 domain 1 only.   Alignment: bit 0 must be 0.
//   GUARD (parameter): 0 = no MemoryGuard; 1 = abstract guard (free verdicts, constrained to the check contract).
//   NOLOSS (parameter): 1 = additionally constrain the environment to a "good" one (one master active with ONE outstanding
//   transaction at a time, targets always ready and answering within 2 cycles, response always taken) and prove a BOUNDED
//   COMPLETION time. (With several outstanding requests the bound grows with the queue ahead of a request; that case is covered
//   by the exactly-once scoreboard of the simulations, not by this property.)
//
// ENVIRONMENT ASSUMPTIONS (what the rest of the SoC must guarantee; docs/meridian_qos/02_ABI.md, 07_VERIFICATION.md):
//   E1 masters hold valid and every field until ready, and never present a tag that is outstanding;
//   E2 targets answer only requests they accepted, once, echoing {src, tag, dom, op}, status OKAY or SLVERR, hold the
//      response until ready;
//   E3 the guard returns one verdict per accepted query, in order, at least one cycle later;
//   E4 reset is applied in the first cycle only (reset behaviour is verified in simulation);
//   E5 the register port is idle (the registers keep their reset values).
//
// PROPERTIES (names used in reports/formal.md):
//   P_DEST   no illegal destination: a request at target t decodes to t and the source master has a route to t
//   P_IDENT  every field of a forwarded request equals the field the master issued (tracked transaction)
//   P_NODUP  a request reaches a target at most once; a response is delivered at most once
//   P_ROUTE  a response is delivered only to a master with that tag outstanding (no foreign / duplicate completion);
//            for the tracked transaction its status / data are those of its target's answer or the documented error
//   P_NOSPUR no request appears at a target without having been accepted; no response without a request
//   P_STAB   valid / ready stability of every DUT output channel (t_req, m_rsp, grd_req)
//   P_OVF    no queue overflow (the internal monitor never fires); FIFO over/underflow are proved per queue (fv_queue)
//   P_ERRSTAT a locally generated error carries exactly the documented status (PROTO / DENIED / DECERR) and no data
//   P_BOUND  (NOLOSS = 1) bounded completion: an accepted transaction is delivered within K cycles (no request loss)
// =============================================================================
`default_nettype none

module fv_qos #(
  parameter GUARD  = 0,
  parameter NOLOSS = 0,
  parameter DECP   = 0,
  parameter KMAX   = 20
) (
  input  wire        clk,
  input  wire        rst_n,
  // master side (free inputs)
  input  wire [1:0]  m_req_valid,
  input  wire [3:0]  m_req_op,
  input  wire [3:0]  m_req_tag,
  input  wire [1:0]  m_req_dom,
  input  wire [1:0]  m_req_priv,
  input  wire [5:0]  m_req_tc,
  input  wire [15:0] m_req_addr,
  input  wire [31:0] m_req_wdata,
  input  wire [3:0]  m_req_wstrb,
  input  wire [1:0]  m_rsp_ready,
  // target side (free inputs)
  input  wire [1:0]  t_req_ready,
  input  wire [1:0]  t_rsp_valid,
  input  wire [1:0]  t_rsp_src,       // only bit 0 of each 1-bit field is used (SRCW = 1)
  input  wire [3:0]  t_rsp_tag,
  input  wire [1:0]  t_rsp_dom,
  input  wire [3:0]  t_rsp_op,
  input  wire [5:0]  t_rsp_status,
  input  wire [31:0] t_rsp_rdata,
  // guard (free inputs)
  input  wire [1:0]  grd_req_ready,
  input  wire [1:0]  grd_rsp_valid,
  input  wire [1:0]  grd_rsp_ok,
  input  wire [7:0]  grd_rsp_fault
);
  localparam NM = 2, NT = 2, AW = 8, DW = 16, TAGW = 2, DOMW = 1;
  localparam [NT*AW-1:0] TBASE = {8'h40, 8'h00};
  localparam [NT*AW-1:0] TMASK = {8'hC0, 8'hC0};
  localparam [NM*NT-1:0] CONN  = 4'b1101;            // bit m*NT + t: m0 -> t1 absent
  localparam [NM*(1<<DOMW)-1:0] DOMV = 4'b1001;      // m0: domain 0, m1: domain 1   (bit m*2 + d)

  // ---------------------------------------------------------------- reset: first cycle only (E4)
  reg f_init = 1'b1;
  always @(posedge clk) f_init <= 1'b0;
  always @(*) if (f_init) assume(!rst_n); else assume(rst_n);

  // ---------------------------------------------------------------- DUT
  wire [1:0]  m_req_ready;
  wire [1:0]  m_rsp_valid;
  wire [3:0]  m_rsp_tag;
  wire [1:0]  m_rsp_dom;
  wire [3:0]  m_rsp_op;
  wire [5:0]  m_rsp_status;
  wire [31:0] m_rsp_rdata;
  wire [1:0]  t_req_valid;
  wire [1:0]  t_req_src;
  wire [3:0]  t_req_op;
  wire [3:0]  t_req_tag;
  wire [1:0]  t_req_dom;
  wire [1:0]  t_req_priv;
  wire [5:0]  t_req_tc;
  wire [15:0] t_req_addr;
  wire [31:0] t_req_wdata;
  wire [3:0]  t_req_wstrb;
  wire [1:0]  t_rsp_ready;
  wire [1:0]  grd_req_valid, grd_req_priv, grd_req_write;
  wire [1:0]  grd_req_dom;
  wire [15:0] grd_req_addr;
  wire [1:0]  o_cong;
  wire        o_internal_err, o_locked, cfg_rvalid, cfg_err;
  wire [31:0] cfg_rdata;

  sf_meridian_qos #(
    .NM(NM), .NT(NT), .AW(AW), .DW(DW), .TAGW(TAGW), .DOMW(DOMW),
    .TGT_BASE(TBASE), .TGT_MASK(TMASK), .CONN(CONN), .MAXO(2), .MST_OOO(2'b00), .MST_DOM_ALLOW(DOMV),
    .IQ_DEPTH(2), .XQ_DEPTH(2), .EQ_DEPTH(2), .TRQ_DEPTH(2), .RQ_DEPTH(2), .GQ_DEPTH(2),
    .MST_SLICE(8'h00), .TGT_SLICE(8'h00), .DEC_PIPE(DECP), .GUARD_EN(GUARD), .STRICT_EN(1),
    .CW(8), .LATW(8)
  ) dut (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_op(m_req_op), .m_req_tag(m_req_tag),
    .m_req_dom(m_req_dom), .m_req_priv(m_req_priv), .m_req_tc(m_req_tc), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_tag(m_rsp_tag), .m_rsp_dom(m_rsp_dom),
    .m_rsp_op(m_rsp_op), .m_rsp_status(m_rsp_status), .m_rsp_rdata(m_rsp_rdata),
    .t_req_valid(t_req_valid), .t_req_ready(t_req_ready), .t_req_src(t_req_src), .t_req_op(t_req_op),
    .t_req_tag(t_req_tag), .t_req_dom(t_req_dom), .t_req_priv(t_req_priv), .t_req_tc(t_req_tc),
    .t_req_addr(t_req_addr), .t_req_wdata(t_req_wdata), .t_req_wstrb(t_req_wstrb),
    .t_rsp_valid(t_rsp_valid), .t_rsp_ready(t_rsp_ready), .t_rsp_src(t_rsp_src[1:0]), .t_rsp_tag(t_rsp_tag),
    .t_rsp_dom(t_rsp_dom), .t_rsp_op(t_rsp_op), .t_rsp_status(t_rsp_status), .t_rsp_rdata(t_rsp_rdata),
    .grd_req_valid(grd_req_valid), .grd_req_ready(grd_req_ready), .grd_req_dom(grd_req_dom),
    .grd_req_priv(grd_req_priv), .grd_req_write(grd_req_write), .grd_req_addr(grd_req_addr),
    .grd_rsp_valid(grd_rsp_valid), .grd_rsp_ok(grd_rsp_ok), .grd_rsp_fault(grd_rsp_fault),
    .cfg_valid(1'b0), .cfg_write(1'b0), .cfg_addr(6'd0), .cfg_wdata(32'd0), .cfg_priv(1'b0),
    .cfg_rvalid(cfg_rvalid), .cfg_rdata(cfg_rdata), .cfg_err(cfg_err),
    .o_cong(o_cong), .o_internal_err(o_internal_err), .o_locked(o_locked));

  // ---------------------------------------------------------------- helpers
  function [0:0] dec_hit; input [AW-1:0] a; input integer t;
    begin dec_hit = ((a & TMASK[t*AW +: AW]) == TBASE[t*AW +: AW]); end
  endfunction
  function integer dec_t; input [AW-1:0] a;
    begin dec_t = dec_hit(a, 0) ? 0 : dec_hit(a, 1) ? 1 : -1; end
  endfunction

  // ---------------------------------------------------------------- E1: master environment
  reg [7:0] outst_q;                     // [m*4 + tag]: accepted and not yet delivered
  reg [1:0] pv_mv;                       // previous valid && !ready
  reg [3:0] pv_op;  reg [3:0] pv_tag; reg [15:0] pv_addr; reg [31:0] pv_wd;
  integer mi;
  always @(posedge clk) begin
    if (f_init) begin outst_q <= 8'd0; pv_mv <= 2'b00; end
    else begin
      pv_mv   <= m_req_valid & ~m_req_ready;
      pv_op   <= m_req_op; pv_tag <= m_req_tag; pv_addr <= m_req_addr; pv_wd <= m_req_wdata;
      for (mi = 0; mi < NM; mi = mi + 1) begin
        if (m_req_valid[mi] && m_req_ready[mi]) outst_q[mi*4 + m_req_tag[mi*2 +: 2]] <= 1'b1;
        if (m_rsp_valid[mi] && m_rsp_ready[mi]) outst_q[mi*4 + m_rsp_tag[mi*2 +: 2]] <= 1'b0;
      end
    end
  end
  always @(*) begin
    for (mi = 0; mi < NM; mi = mi + 1) begin
      if (!f_init) begin
        // never present a tag that is outstanding
        if (m_req_valid[mi]) assume(!outst_q[mi*4 + m_req_tag[mi*2 +: 2]]);
        // hold valid and every field until ready
        if (pv_mv[mi]) begin
          assume(m_req_valid[mi]);
          assume(m_req_op[mi*2 +: 2] == pv_op[mi*2 +: 2]);
          assume(m_req_tag[mi*2 +: 2] == pv_tag[mi*2 +: 2]);
          assume(m_req_addr[mi*8 +: 8] == pv_addr[mi*8 +: 8]);
          assume(m_req_wdata[mi*16 +: 16] == pv_wd[mi*16 +: 16]);
        end
      end
    end
    // (legal opcodes are NOT assumed: reserved opcodes are part of the input space and must give ST_PROTO)
  end

  // ---------------------------------------------------------------- E2: target environment
  reg [15:0] tpend_q;                    // [t*8 + src*4 + tag]: accepted by target t, not yet answered
  reg [15:0] tpdom_q;                    // dom echo store [t*8 + src*4 + tag]
  reg [31:0] tpop_q;                     // op echo store 2 bits each
  reg [1:0]  pv_tr;                      // previous t_rsp valid && !ready
  reg [1:0]  pv_trs; reg [3:0] pv_trt; reg [5:0] pv_trst; reg [31:0] pv_trd;
  integer ti, si;
  always @(posedge clk) begin
    if (f_init) begin tpend_q <= 16'd0; pv_tr <= 2'b00; end
    else begin
      pv_tr <= t_rsp_valid & ~t_rsp_ready;
      pv_trs <= t_rsp_src; pv_trt <= t_rsp_tag; pv_trst <= t_rsp_status; pv_trd <= t_rsp_rdata;
      for (ti = 0; ti < NT; ti = ti + 1) begin
        if (t_req_valid[ti] && t_req_ready[ti]) begin
          tpend_q[ti*8 + t_req_src[ti]*4 + t_req_tag[ti*2 +: 2]] <= 1'b1;
          tpdom_q[ti*8 + t_req_src[ti]*4 + t_req_tag[ti*2 +: 2]] <= t_req_dom[ti];
          tpop_q[(ti*8 + t_req_src[ti]*4 + t_req_tag[ti*2 +: 2])*2 +: 2] <= t_req_op[ti*2 +: 2];
        end
        if (t_rsp_valid[ti] && t_rsp_ready[ti]) tpend_q[ti*8 + t_rsp_src[ti]*4 + t_rsp_tag[ti*2 +: 2]] <= 1'b0;
      end
    end
  end
  always @(*) begin
    for (ti = 0; ti < NT; ti = ti + 1) begin
      if (!f_init) begin
        if (t_rsp_valid[ti]) begin
          assume(tpend_q[ti*8 + t_rsp_src[ti]*4 + t_rsp_tag[ti*2 +: 2]]);
          assume(t_rsp_dom[ti] == tpdom_q[ti*8 + t_rsp_src[ti]*4 + t_rsp_tag[ti*2 +: 2]]);
          assume(t_rsp_op[ti*2 +: 2] == tpop_q[(ti*8 + t_rsp_src[ti]*4 + t_rsp_tag[ti*2 +: 2])*2 +: 2]);
          assume(t_rsp_status[ti*3 +: 3] <= 3'd1);
        end
        if (pv_tr[ti]) begin
          assume(t_rsp_valid[ti]);
          assume(t_rsp_src[ti] == pv_trs[ti]);
          assume(t_rsp_tag[ti*2 +: 2] == pv_trt[ti*2 +: 2]);
          assume(t_rsp_status[ti*3 +: 3] == pv_trst[ti*3 +: 3]);
          assume(t_rsp_rdata[ti*16 +: 16] == pv_trd[ti*16 +: 16]);
        end
      end
    end
  end

  // ---------------------------------------------------------------- E3: guard environment
  reg [3:0] gq_out;                      // accepted-unanswered queries per master (2 bits each)
  always @(posedge clk) begin
    if (f_init) gq_out <= 4'd0;
    else begin
      for (mi = 0; mi < NM; mi = mi + 1) begin
        if ((grd_req_valid[mi] && grd_req_ready[mi]) && !grd_rsp_valid[mi]) gq_out[mi*2 +: 2] <= gq_out[mi*2 +: 2] + 2'd1;
        else if (!(grd_req_valid[mi] && grd_req_ready[mi]) && grd_rsp_valid[mi]) gq_out[mi*2 +: 2] <= gq_out[mi*2 +: 2] - 2'd1;
      end
    end
  end
  always @(*) begin
    for (mi = 0; mi < NM; mi = mi + 1)
      if (!f_init) begin
        if (grd_rsp_valid[mi]) assume(gq_out[mi*2 +: 2] != 2'd0);                 // one verdict per accepted query, >= 1 cycle later
        if (!grd_rsp_ok[mi]) assume(grd_rsp_fault[mi*4 +: 4] != 4'd0);
      end
  end

  // ---------------------------------------------------------------- tracked transaction (any master, any tag)
  (* anyconst *) wire       tr_m;
  (* anyconst *) wire [1:0] tr_tag;
  reg        tr_acc, tr_done, tr_fwd2;
  reg [1:0]  tr_fwd, tr_rsp;
  reg [1:0]  tr_op;  reg tr_dom, tr_priv; reg [2:0] tr_tc; reg [7:0] tr_addr; reg [15:0] tr_wd; reg [1:0] tr_ws;
  reg        tr_ans_v; reg [2:0] tr_ans_st; reg [15:0] tr_ans_rd; reg tr_tgt_seen; reg tr_tgt;
  reg [7:0]  tr_age;

  // only the FIRST transaction with (tr_m, tr_tag) is tracked: events after it was delivered belong to a later request
  wire tr_live = tr_acc && !tr_done;
  wire acc_ev  = !tr_acc && m_req_valid[tr_m] && m_req_ready[tr_m] && (m_req_tag[tr_m*2 +: 2] == tr_tag);
  wire rsp_raw = m_rsp_valid[tr_m] && m_rsp_ready[tr_m] && (m_rsp_tag[tr_m*2 +: 2] == tr_tag);
  wire rsp_ev  = tr_live && rsp_raw;
  // target-side events for the tracked transaction
  wire [1:0] fwd_ev;   // per target
  wire [1:0] ans_ev;
  genvar gt;
  generate for (gt = 0; gt < NT; gt = gt + 1) begin : g_ev
    assign fwd_ev[gt] = tr_live && t_req_valid[gt] && t_req_ready[gt] && (t_req_src[gt] == tr_m) && (t_req_tag[gt*2 +: 2] == tr_tag);
    assign ans_ev[gt] = tr_live && t_rsp_valid[gt] && t_rsp_ready[gt] && (t_rsp_src[gt] == tr_m) && (t_rsp_tag[gt*2 +: 2] == tr_tag);
  end endgenerate

  always @(posedge clk) begin
    if (f_init) begin
      tr_acc <= 1'b0; tr_done <= 1'b0; tr_fwd <= 2'd0; tr_rsp <= 2'd0; tr_ans_v <= 1'b0; tr_tgt_seen <= 1'b0; tr_age <= 8'd0;
    end else begin
      if (acc_ev) begin
        tr_acc <= 1'b1;
        tr_op <= m_req_op[tr_m*2 +: 2]; tr_dom <= m_req_dom[tr_m]; tr_priv <= m_req_priv[tr_m];
        tr_tc <= m_req_tc[tr_m*3 +: 3]; tr_addr <= m_req_addr[tr_m*8 +: 8]; tr_wd <= m_req_wdata[tr_m*16 +: 16];
        tr_ws <= m_req_wstrb[tr_m*2 +: 2];
      end
      if (tr_acc && !tr_done) tr_age <= (tr_age == 8'hFF) ? tr_age : tr_age + 8'd1;
      if (|fwd_ev) begin tr_fwd <= (tr_fwd == 2'd3) ? tr_fwd : tr_fwd + 2'd1; tr_tgt_seen <= 1'b1; tr_tgt <= fwd_ev[1]; end
      if (|ans_ev) begin
        tr_ans_v <= 1'b1;
        tr_ans_st <= ans_ev[0] ? t_rsp_status[2:0] : t_rsp_status[5:3];
        tr_ans_rd <= ans_ev[0] ? t_rsp_rdata[15:0] : t_rsp_rdata[31:16];
      end
      if (rsp_ev) begin tr_rsp <= (tr_rsp == 2'd3) ? tr_rsp : tr_rsp + 2'd1; tr_done <= 1'b1; end
    end
  end

  // expected local-error outcome of the tracked request
  wire        x_badop   = tr_op[1];
  wire        x_misal   = tr_addr[0];
  wire        x_spoof   = !DOMV[tr_m*2 + tr_dom];
  wire        x_unmap   = (dec_t(tr_addr) < 0);
  wire        x_noroute = (dec_t(tr_addr) >= 0) && !CONN[tr_m*NT + ((dec_t(tr_addr) < 0) ? 0 : dec_t(tr_addr))];
  wire        x_local   = x_badop || x_misal || x_spoof || x_unmap || x_noroute;
  wire [2:0]  x_status  = x_badop ? 3'd5 : x_misal ? 3'd5 : x_spoof ? 3'd3 : 3'd2;
  wire        x_tgt     = (dec_t(tr_addr) == 1);

  // ---------------------------------------------------------------- stability of DUT outputs (P_STAB)
  reg [1:0] pv_ov; reg [1:0] pv_mrv;  reg [1:0] pv_gv;
  reg [15:0] pv_ta; reg [3:0] pv_mt; reg [31:0] pv_mr; reg [15:0] pv_ga;
  reg f_pv;
  always @(posedge clk) begin
    f_pv  <= !f_init;
    pv_ov <= t_req_valid & ~t_req_ready;
    pv_mrv<= m_rsp_valid & ~m_rsp_ready;
    pv_gv <= grd_req_valid & ~grd_req_ready;
    pv_ta <= t_req_addr; pv_mt <= m_rsp_tag; pv_mr <= m_rsp_rdata; pv_ga <= grd_req_addr;
  end

  integer k;
  always @(*) if (!f_init) begin
    // ---- P_OVF
    assert(!o_internal_err);
    // ---- P_STAB
    if (f_pv) begin
      for (k = 0; k < NT; k = k + 1) if (pv_ov[k]) begin
        assert(t_req_valid[k]);
        assert(t_req_addr[k*8 +: 8] == pv_ta[k*8 +: 8]);
      end
      for (k = 0; k < NM; k = k + 1) if (pv_mrv[k]) begin
        assert(m_rsp_valid[k]);
        assert(m_rsp_tag[k*2 +: 2] == pv_mt[k*2 +: 2]);
        assert(m_rsp_rdata[k*16 +: 16] == pv_mr[k*16 +: 16]);
      end
      for (k = 0; k < NM; k = k + 1) if (pv_gv[k]) begin
        assert(grd_req_valid[k]);
        assert(grd_req_addr[k*8 +: 8] == pv_ga[k*8 +: 8]);
      end
    end
    // ---- P_DEST: any forwarded request decodes to its target and the source has a route
    for (k = 0; k < NT; k = k + 1) if (t_req_valid[k]) begin
      assert(dec_hit(t_req_addr[k*8 +: 8], k));
      assert(CONN[t_req_src[k]*NT + k]);
    end
    // ---- P_ROUTE (universal): a delivered response belongs to an outstanding request of that master
    for (k = 0; k < NM; k = k + 1) if (m_rsp_valid[k]) assert(outst_q[k*4 + m_rsp_tag[k*2 +: 2]]);
    // ---- P_NOSPUR (universal): a request at a target belongs to an outstanding request of its source
    for (k = 0; k < NT; k = k + 1) if (t_req_valid[k]) assert(outst_q[t_req_src[k]*4 + t_req_tag[k*2 +: 2]]);
    // ---- tracked transaction
    assert(tr_fwd <= 2'd1);                                           // P_NODUP (request)
    assert(tr_rsp <= 2'd1);                                           // P_NODUP (response)
    if (rsp_raw && !tr_done) assert(tr_acc);                           // P_NOSPUR: no response before the request was accepted
    if (|fwd_ev) begin                                                // P_DEST / P_IDENT for the tracked request
      assert(!x_local);
      assert(fwd_ev[x_tgt]);
      assert(t_req_op[(x_tgt)*2 +: 2] == tr_op);
      assert(t_req_dom[x_tgt] == tr_dom);
      assert(t_req_priv[x_tgt] == tr_priv);
      assert(t_req_tc[x_tgt*3 +: 3] == tr_tc);
      assert(t_req_addr[x_tgt*8 +: 8] == tr_addr);
      assert(t_req_wdata[x_tgt*16 +: 16] == tr_wd);
      assert(t_req_wstrb[x_tgt*2 +: 2] == tr_ws);
    end
    if (rsp_ev) begin
      assert(m_rsp_dom[tr_m] == tr_dom);                               // echo
      if (x_local) begin                                              // P_ERRSTAT
        assert(tr_fwd == 2'd0);
        assert(m_rsp_status[tr_m*3 +: 3] == x_status);
        assert(m_rsp_rdata[tr_m*16 +: 16] == 16'd0);
      end else if (tr_fwd == 2'd1) begin                              // forwarded: the target's own answer comes back
        assert(tr_ans_v);
        assert(m_rsp_status[tr_m*3 +: 3] == tr_ans_st);
        assert(m_rsp_rdata[tr_m*16 +: 16] == ((tr_ans_st == 3'd0 && tr_op == 2'd0) ? tr_ans_rd : 16'd0));
      end else begin                                                   // not forwarded, no local error: only a guard denial
        assert(GUARD != 0);
        assert(m_rsp_status[tr_m*3 +: 3] == 3'd3);
        assert(m_rsp_rdata[tr_m*16 +: 16] == 16'd0);
      end
    end
  end

  // ---------------------------------------------------------------- P_BOUND: bounded completion in a good environment
  generate if (NOLOSS != 0) begin : g_noloss
    always @(*) if (!f_init) begin
      assume(m_req_valid[~tr_m] == 1'b0);                              // the other master is idle
      assume(!(m_req_valid[tr_m] && (outst_q[tr_m*4 +: 4] != 4'd0)));  // ONE outstanding transaction at a time: a request queued behind the master's own
                                                                       // earlier ones legitimately waits for a slot (found by this check: KMAX = 12 failed at frame 17 with 3 accepted requests)
      assume(t_req_ready == 2'b11);                                    // targets always ready
      assume(m_rsp_ready == 2'b11);                                    // responses always taken
      if (GUARD != 0) assume(grd_req_ready == 2'b11);
      if (GUARD != 0) for (k = 0; k < NM; k = k + 1) assume(grd_rsp_valid[k] == (gq_out[k*2 +: 2] != 2'd0));   // guard answers at once
    end
    // targets answer within 2 cycles of accepting
    reg [1:0] age0, age1;
    always @(posedge clk) begin
      if (f_init) begin age0 <= 2'd0; age1 <= 2'd0; end
      else begin
        age0 <= (tpend_q[0 +: 8] != 8'd0) ? ((age0 == 2'd3) ? age0 : age0 + 2'd1) : 2'd0;
        age1 <= (tpend_q[8 +: 8] != 8'd0) ? ((age1 == 2'd3) ? age1 : age1 + 2'd1) : 2'd0;
      end
    end
    always @(*) if (!f_init) begin
      if (tpend_q[0 +: 8] != 8'd0 && age0 >= 2'd2) assume(t_rsp_valid[0]);
      if (tpend_q[8 +: 8] != 8'd0 && age1 >= 2'd2) assume(t_rsp_valid[1]);
      assert(!(tr_acc && !tr_done && tr_age > KMAX));                  // P_BOUND
    end
  end endgenerate
endmodule

`default_nettype wire
