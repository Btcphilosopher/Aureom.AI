// =============================================================================
// SilicaFlux -- Project 102 -- MeridianQoS :: sf_meridian_queue
//
// Elastic valid/ready FIFO: the one buffering primitive of MeridianQoS (ingress queues, crosspoint queues,
// egress queues, response queues, reorder queues, register-slice stages).
//
//   * DEPTH >= 1 entries (any value), W-bit entries, one push and one pop per cycle.
//   * `in_ready`  = not full, `out_valid` = not empty: BOTH are functions of the registered occupancy only.
//     There is therefore no combinational path in_valid -> in_ready, out_ready -> in_ready or
//     in_valid -> out_valid: a chain of queues cannot form a combinational valid/ready loop, and a queue is a
//     legal registered pipeline boundary.
//   * Overflow / underflow are impossible by construction: a push happens only with in_valid && in_ready, a pop
//     only with out_valid && out_ready; `count` is within 0..DEPTH in every reachable state
//     (formal/meridian_qos/fv_queue.sv: unbounded proof for small DEPTH, bounded otherwise).
//   * `out_data` is the head entry; it is stable while out_valid && !out_ready (nothing writes the head slot).
//   * Throughput: DEPTH >= 2 sustains one transfer per cycle (the registered `full` flag hides the pop->ready
//     bubble); DEPTH = 1 sustains one transfer every two cycles.
//   * Reset: asynchronous assert, synchronous release (platform reset network); every entry is dropped.
//
// Behaviourally equivalent to sfn_fifo (Project 22, PASS_FULL = 0); tests/meridian_qos/tb/tb_queue_diff.sv
// compares the two cycle by cycle.
// =============================================================================
`default_nettype none

module sf_meridian_queue #(
  parameter int  W     = 8,
  parameter int  DEPTH = 4,
  localparam int PW    = sf_meridian_qos_pkg::clog2c(DEPTH),
  localparam int CW    = sf_meridian_qos_pkg::clog2c(DEPTH + 1)
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic          in_valid,
  output logic          in_ready,
  input  logic [W-1:0]  in_data,
  output logic          out_valid,
  input  logic          out_ready,
  output logic [W-1:0]  out_data,
  output logic [CW-1:0] count
);
  logic [W-1:0]  mem [DEPTH];
  logic [PW-1:0] rd_q, wr_q;
  logic [CW-1:0] cnt_q;

  wire push = in_valid  && in_ready;
  wire pop  = out_valid && out_ready;

  assign in_ready  = (cnt_q != CW'(DEPTH));
  assign out_valid = (cnt_q != '0);
  assign out_data  = mem[rd_q];
  assign count     = cnt_q;

  function automatic logic [PW-1:0] inc(input logic [PW-1:0] p);
    begin
      if (p == PW'(DEPTH - 1)) inc = '0;
      else                     inc = p + PW'(1);
    end
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd_q  <= '0;
      wr_q  <= '0;
      cnt_q <= '0;
    end else begin
      if (push) wr_q <= inc(wr_q);
      if (pop)  rd_q <= inc(rd_q);
      cnt_q <= cnt_q + CW'(push) - CW'(pop);
    end
  end

  // storage has no reset: an entry is only observable while it is counted
  always_ff @(posedge clk) begin
    if (push) mem[wr_q] <= in_data;
  end

`ifdef FORMAL
  // ---------------------------------------------------------------------------------------------------------
  // Formal properties (compiled only by scripts/formal.py; not seen by simulation or synthesis).
  //   Q1 no overflow          count never exceeds DEPTH; a push only happens with room
  //   Q2 no underflow         a pop only happens with data; out_valid == not empty
  //   Q3 pointer consistency  count == (wr - rd) mod DEPTH, and 0 or DEPTH when the pointers coincide
  //   Q4 order + integrity    an arbitrary pushed entry (chosen by the free input f_pick) leaves in FIFO order and
  //                           unchanged: its position is tracked as the number of entries ahead of it
  //   Q5 stability            a stalled head (out_valid && !out_ready) stays valid and unchanged
  // The invariants are inductive: scripts/formal.py proves them UNBOUNDED by k-induction for small DEPTH.
  // ---------------------------------------------------------------------------------------------------------
  reg f_init = 1'b1;
  always @(posedge clk) f_init <= 1'b0;
  always @(*) if (f_init) assume(!rst_n); else assume(rst_n);      // reset in the first cycle only

  // narrow arithmetic only (PW+1 / CW bits, no modulo): keeps the SMT problem easy
  localparam FW_ = (PW > CW) ? PW + 1 : CW + 1;
  wire [FW_-1:0] f_rd  = {{(FW_-PW){1'b0}}, rd_q};
  wire [FW_-1:0] f_wr  = {{(FW_-PW){1'b0}}, wr_q};
  wire [FW_-1:0] f_cnt = {{(FW_-CW){1'b0}}, cnt_q};
  localparam [FW_-1:0] F_DEPTH = DEPTH;
  wire [FW_-1:0] f_dist = (f_wr >= f_rd) ? (f_wr - f_rd) : (f_wr + F_DEPTH - f_rd);   // (wr - rd) mod DEPTH
  always @(*) if (!f_init) begin
    assert(f_cnt <= F_DEPTH);                                      // Q1
    assert(f_rd < F_DEPTH && f_wr < F_DEPTH);
    assert(in_ready  == (f_cnt != F_DEPTH));
    assert(!push || f_cnt != F_DEPTH);                             // Q1: push only with room
    assert(out_valid == (f_cnt != 0));                             // Q2
    assert(!pop || f_cnt != 0);                                    // Q2: pop only with data
    if (f_wr == f_rd) assert(f_cnt == 0 || f_cnt == F_DEPTH);      // Q3
    else              assert(f_cnt == f_dist);
  end

  (* anyseq *) wire f_pick;                                       // free choice: which pushed entry to follow
  reg                f_on = 1'b0;
  reg  [FW_-1:0]     f_ahead;
  reg  [W-1:0]       f_data;
  always @(posedge clk) begin
    if (f_init) f_on <= 1'b0;
    else if (!f_on) begin
      if (push && f_pick) begin
        f_on    <= 1'b1;
        f_data  <= in_data;
        f_ahead <= f_cnt - (pop ? {{(FW_-1){1'b0}}, 1'b1} : {FW_{1'b0}});   // entries ahead of it after this cycle
      end
    end else if (pop) begin
      if (f_ahead == {FW_{1'b0}}) f_on <= 1'b0;
      else                        f_ahead <= f_ahead - {{(FW_-1){1'b0}}, 1'b1};
    end
  end
  wire [FW_-1:0] f_pos_raw = f_rd + f_ahead;                       // < 2 * DEPTH because ahead < count <= DEPTH
  wire [FW_-1:0] f_pos     = (f_pos_raw >= F_DEPTH) ? (f_pos_raw - F_DEPTH) : f_pos_raw;
  always @(*) if (!f_init && f_on) begin                           // Q4
    assert(f_ahead < f_cnt);
    assert(mem[f_pos] == f_data);
    if (f_ahead == {FW_{1'b0}}) assert(out_valid && out_data == f_data);
  end

  reg f_stall; reg [W-1:0] f_prev;
  always @(posedge clk) begin f_stall <= !f_init && out_valid && !out_ready; f_prev <= out_data; end
  always @(*) if (!f_init && f_stall) begin                        // Q5
    assert(out_valid);
    assert(out_data == f_prev);
  end
`endif
endmodule

`default_nettype wire
