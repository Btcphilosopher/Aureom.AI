// =============================================================================
// SilicaFlux -- Project 102 -- MeridianQoS :: sf_meridian_guard_ref
//
// REFERENCE MODEL of the MemoryGuard: it defines and exercises the check interface `grd_*` of sf_meridian_qos.  It is
// a model, NOT the guard hardware.  Interface contract (identical in substance to the check interface of Project 83
// and to CloudDMA's `iommu_req/rsp` permission contract, the only request/response permission contract in the
// repository -- see docs/meridian_qos/00_AUDIT.md for why "MemoryGuard" had to be defined as an interface):
//
//   * one query channel per master: req_valid / req_ready, dom, priv, write, addr.  The source of the query is the
//     port index (hardware-bound, never taken from the request).  The master port holds the fields stable while
//     valid && !ready.
//   * exactly ONE verdict per accepted query, IN ORDER, at least 1 cycle after the query was accepted
//     (registered: rsp_valid is never combinationally dependent on req_valid): rsp_ok, rsp_fault[3:0].
//   * rsp_ok = 1 permits.  rsp_ok = 0 denies with a fault code: F_NOMAP no entry covers the address, F_DOMAIN covered
//     but not for this source / domain, F_PRIV privilege missing, F_PERM the right (read / write) is missing.
//   * DEFAULT DENY: with no valid entry every query is denied.
//
// This model: policy table of NENT entries {valid, src_mask, dom_mask, need_priv, base, mask, rd, wr}; a query is
// permitted iff some valid entry covers the address ((addr & mask) == base), names the source and the domain, is
// satisfied by the privilege, and grants the right.  LAT >= 1 is the verdict latency (a delay line, so the model
// accepts one query per cycle); `stall[m]` is a verification hook that deasserts req_ready of port m.
// Policy programming (pol_*) must be reachable only from the management plane; a change applies to the next query,
// a transaction already forwarded completes (revoke by quiescing first).
// =============================================================================
`default_nettype none

module sf_meridian_guard_ref #(
  parameter int  NM    = 2,
  parameter int  AW    = 32,
  parameter int  DOMW  = 3,
  parameter int  NENT  = 8,
  parameter int  LAT   = 1,
  localparam int NDOM  = 1 << DOMW,
  localparam int EIW   = sf_meridian_qos_pkg::clog2c(NENT)
) (
  input  logic                clk,
  input  logic                rst_n,
  // ---- policy programming port
  input  logic                pol_we,
  input  logic [EIW-1:0]      pol_idx,
  input  logic                pol_valid,
  input  logic [NM-1:0]       pol_src,
  input  logic [NDOM-1:0]     pol_dom,
  input  logic                pol_priv,
  input  logic [AW-1:0]       pol_base,
  input  logic [AW-1:0]       pol_mask,
  input  logic                pol_rd,
  input  logic                pol_wr,
  // ---- verification hook
  input  logic [NM-1:0]       stall,
  // ---- check ports
  input  logic [NM-1:0]       req_valid,
  output logic [NM-1:0]       req_ready,
  input  logic [NM*DOMW-1:0]  req_dom,
  input  logic [NM-1:0]       req_priv,
  input  logic [NM-1:0]       req_write,
  input  logic [NM*AW-1:0]    req_addr,
  output logic [NM-1:0]       rsp_valid,
  output logic [NM-1:0]       rsp_ok,
  output logic [NM*4-1:0]     rsp_fault
);
  localparam logic [3:0] F_NOMAP  = sf_meridian_qos_pkg::F_NOMAP;
  localparam logic [3:0] F_PERM   = sf_meridian_qos_pkg::F_PERM;
  localparam logic [3:0] F_DOMAIN = sf_meridian_qos_pkg::F_DOMAIN;
  localparam logic [3:0] F_PRIV   = sf_meridian_qos_pkg::F_PRIV;

  logic [NENT-1:0]       e_valid;
  logic [NENT*NM-1:0]    e_src;
  logic [NENT*NDOM-1:0]  e_dom;
  logic [NENT-1:0]       e_priv, e_rd, e_wr;
  logic [NENT*AW-1:0]    e_base, e_mask;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      e_valid <= '0;
      e_src <= '0; e_dom <= '0; e_priv <= '0; e_rd <= '0; e_wr <= '0; e_base <= '0; e_mask <= '0;
    end else if (pol_we) begin
      e_valid[pol_idx]                 <= pol_valid;
      e_src[pol_idx*NM +: NM]          <= pol_src;
      e_dom[pol_idx*NDOM +: NDOM]      <= pol_dom;
      e_priv[pol_idx]                  <= pol_priv;
      e_rd[pol_idx]                    <= pol_rd;
      e_wr[pol_idx]                    <= pol_wr;
      e_base[pol_idx*AW +: AW]         <= pol_base;
      e_mask[pol_idx*AW +: AW]         <= pol_mask;
    end
  end

  assign req_ready = ~stall;

  // verdict of the query presented by master m (combinational), registered below
  logic [NM-1:0]   v_ok;
  logic [NM*4-1:0] v_fault;
  always_comb begin
    for (int m = 0; m < NM; m++) begin
      logic         any_cover, any_who, any_priv, any_perm;
      logic [DOMW-1:0] dm;
      dm        = req_dom[m*DOMW +: DOMW];
      any_cover = 1'b0; any_who = 1'b0; any_priv = 1'b0; any_perm = 1'b0;
      for (int e = 0; e < NENT; e++) begin
        if (e_valid[e] && ((req_addr[m*AW +: AW] & e_mask[e*AW +: AW]) == e_base[e*AW +: AW])) begin
          any_cover = 1'b1;
          if (e_src[e*NM + m] && e_dom[e*NDOM + 32'(dm)]) begin
            any_who = 1'b1;
            if (!e_priv[e] || req_priv[m]) begin
              any_priv = 1'b1;
              if (req_write[m] ? e_wr[e] : e_rd[e]) any_perm = 1'b1;
            end
          end
        end
      end
      v_ok[m] = any_perm;
      if (any_perm)        v_fault[m*4 +: 4] = 4'd0;
      else if (!any_cover) v_fault[m*4 +: 4] = F_NOMAP;
      else if (!any_who)   v_fault[m*4 +: 4] = F_DOMAIN;
      else if (!any_priv)  v_fault[m*4 +: 4] = F_PRIV;
      else                 v_fault[m*4 +: 4] = F_PERM;
    end
  end

  // delay line: LAT registered stages, one query per cycle per port
  logic [NM-1:0]     dv [LAT];
  logic [NM-1:0]     dok [LAT];
  logic [NM*4-1:0]   dft [LAT];
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int s = 0; s < LAT; s++) begin dv[s] <= '0; dok[s] <= '0; dft[s] <= '0; end
    end else begin
      dv[0]  <= req_valid & req_ready;
      dok[0] <= v_ok;
      dft[0] <= v_fault;
      for (int s = 1; s < LAT; s++) begin
        dv[s] <= dv[s-1]; dok[s] <= dok[s-1]; dft[s] <= dft[s-1];
      end
    end
  end
  assign rsp_valid = dv[LAT-1];
  assign rsp_ok    = dok[LAT-1];
  assign rsp_fault = dft[LAT-1];
endmodule

`default_nettype wire
