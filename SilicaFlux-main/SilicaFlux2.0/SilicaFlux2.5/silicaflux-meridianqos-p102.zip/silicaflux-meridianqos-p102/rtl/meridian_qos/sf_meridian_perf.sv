// =============================================================================
// SilicaFlux -- Project 102 -- MeridianQoS :: sf_meridian_perf
//
// Performance counters of the interconnect: one flat bank of NCNT counters (layout and meaning in
// sf_meridian_qos_pkg, section 5, and docs/meridian_qos/05_CONGESTION_AND_PERF.md), read through `rd_idx` /
// `rd_data` (the register block exposes them as R_PERF_SEL / R_PERF_DATA).  Two kinds of counter:
//   sum counters : cnt += inc every cycle (events, cycles, occupancy sums, latency sums)
//   max counters : cnt  = max(cnt, inc)  (latency max, occupancy max, longest back-pressure run)
// Counters wrap at 2^CW (documented; clear them with `clear` before a measurement).  `clear` is a synchronous
// pulse.  All event inputs are REGISTERED before they are counted (the counters observe the datapath and must not
// extend its critical path): every counter lags the event by one cycle, so a read taken after the fabric went idle is
// exact; an event in the cycle of the clear is counted in the cycle after it.
//
// What is measured (the congestion metrics of the brief):
//   queue occupancy        per master ingress queue, per target crosspoint queues (sum over masters), per egress queue:
//                          running sum (divide by CYCLES for the mean) and maximum
//   stall cycles           per master (offered request not accepted), per target / class (requester present, not granted)
//   contending requests    per target: cycles with >= 2 requesters, and the running sum of requesters
//   back-pressure duration per target: total cycles the egress offers a request the target does not take, and the
//                          longest consecutive run
//   target utilisation     per target: BUSY = cycles in which the target accepted a request (BUSY / CYCLES)
//   latency                accept -> delivery, per master and per class: sum, count, max
//   throughput             accepted / completed transactions, bytes written / read
// =============================================================================
`default_nettype none

module sf_meridian_perf #(
  parameter int  NM    = 2,
  parameter int  NT    = 2,
  parameter int  CW    = 32,
  parameter int  LATW  = 16,
  parameter int  BW    = 4,        // width of a byte count (clog2(DW/8 + 1))
  parameter int  OCW   = 8,        // width of an occupancy value
  localparam int NCNT  = sf_meridian_qos_pkg::pf_n(NM, NT),
  localparam int RSW   = sf_meridian_qos_pkg::clog2c(NCNT)
) (
  input  logic                    clk,
  input  logic                    rst_n,
  input  logic                    clear,
  // ---- per master
  input  logic [NM-1:0]                     m_acc_i,  // request accepted into the ingress queue
  input  logic [NM-1:0]                     m_stall_in_i,  // master offers a request that is not accepted this cycle
  input  logic [NM-1:0]                     m_fire_i,  // transaction admitted (slot allocated), errors included
  input  logic [NM*2-1:0]                   m_fire_cls_i,
  input  logic [NM-1:0]                     m_demote_i,  // the class of the admitted transaction was demoted by the floor
  input  logic [NM*NT-1:0]                  mt_push_i,  // request committed to crosspoint (m, t)
  input  logic [NM-1:0]                     m_push_wr_i,
  input  logic [NM*BW-1:0]                  m_push_bytes_i,
  input  logic [NM-1:0]                     m_cpl_i,  // completion delivered to the response channel
  input  logic [NM*3-1:0]                   m_cpl_st_i,
  input  logic [NM*2-1:0]                   m_cpl_cls_i,
  input  logic [NM*LATW-1:0]                m_cpl_lat_i,
  input  logic [NM-1:0]                     m_held_adm_i,  // head held this cycle by the outstanding-limit admission control
  input  logic [NM-1:0]                     m_held_cong_i,  // head held this cycle by the congestion throttle
  input  logic [NM*sf_meridian_qos_pkg::VW-1:0] m_viol_i,  // violation pulses
  input  logic [NM*OCW-1:0]                 m_iq_occ_i,  // ingress queue occupancy
  input  logic [NM*OCW-1:0]                 m_out_i,  // outstanding transactions
  // ---- per target
  input  logic [NT-1:0]                     t_xfer_i,  // arbiter transfer (grant) at the target's crosspoint arbiter
  input  logic [NT*2-1:0]                   t_xfer_cls_i,
  input  logic [NT*BW-1:0]                  t_xfer_bytes_i,
  input  logic [NT*NM-1:0]                  t_req_i,  // requesters (crosspoint heads present)
  input  logic [NT*NM*2-1:0]                t_cls_i,  // their classes
  input  logic [NT-1:0]                     t_busy_i,  // target accepted a request (valid && ready at the target port)
  input  logic [NT-1:0]                     t_bp_i,  // target port offers a request the target does not take
  input  logic [NT-1:0]                     t_cong_i,  // congestion flag of the target
  input  logic [NT-1:0]                     t_rsp_i,  // response accepted from the target
  input  logic [NT*OCW-1:0]                 t_xq_occ_i,  // sum of the crosspoint queues of the target
  input  logic [NT*OCW-1:0]                 t_eq_occ_i,  // egress queue occupancy
  input  logic [NT-1:0]                     t_badsrc_i,  // response consumed because its src was illegal
  input  logic                              sec_evt_i,  // rejected register access
  // ---- read port
  input  logic [RSW-1:0]          rd_idx,
  output logic [CW-1:0]           rd_data
);

  // ---- event inputs are REGISTERED before they are counted: the counters observe the datapath, they must not extend its
  //      critical path (slot state -> admission -> event -> counter adder was a 60 ns path in the first place-and-route).
  //      Cost: one cycle of lag on every counter, about 200 flip-flops.  Counter reads after the fabric went idle are exact.
  logic [NM-1:0] m_acc;
  logic [NM-1:0] m_stall_in;
  logic [NM-1:0] m_fire;
  logic [NM*2-1:0] m_fire_cls;
  logic [NM-1:0] m_demote;
  logic [NM*NT-1:0] mt_push;
  logic [NM-1:0] m_push_wr;
  logic [NM*BW-1:0] m_push_bytes;
  logic [NM-1:0] m_cpl;
  logic [NM*3-1:0] m_cpl_st;
  logic [NM*2-1:0] m_cpl_cls;
  logic [NM*LATW-1:0] m_cpl_lat;
  logic [NM-1:0] m_held_adm;
  logic [NM-1:0] m_held_cong;
  logic [NM*sf_meridian_qos_pkg::VW-1:0] m_viol;
  logic [NM*OCW-1:0] m_iq_occ;
  logic [NM*OCW-1:0] m_out;
  logic [NT-1:0] t_xfer;
  logic [NT*2-1:0] t_xfer_cls;
  logic [NT*BW-1:0] t_xfer_bytes;
  logic [NT*NM-1:0] t_req;
  logic [NT*NM*2-1:0] t_cls;
  logic [NT-1:0] t_busy;
  logic [NT-1:0] t_bp;
  logic [NT-1:0] t_cong;
  logic [NT-1:0] t_rsp;
  logic [NT*OCW-1:0] t_xq_occ;
  logic [NT*OCW-1:0] t_eq_occ;
  logic [NT-1:0] t_badsrc;
  logic sec_evt;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      m_acc <= '0;
      m_stall_in <= '0;
      m_fire <= '0;
      m_fire_cls <= '0;
      m_demote <= '0;
      mt_push <= '0;
      m_push_wr <= '0;
      m_push_bytes <= '0;
      m_cpl <= '0;
      m_cpl_st <= '0;
      m_cpl_cls <= '0;
      m_cpl_lat <= '0;
      m_held_adm <= '0;
      m_held_cong <= '0;
      m_viol <= '0;
      m_iq_occ <= '0;
      m_out <= '0;
      t_xfer <= '0;
      t_xfer_cls <= '0;
      t_xfer_bytes <= '0;
      t_req <= '0;
      t_cls <= '0;
      t_busy <= '0;
      t_bp <= '0;
      t_cong <= '0;
      t_rsp <= '0;
      t_xq_occ <= '0;
      t_eq_occ <= '0;
      t_badsrc <= '0;
      sec_evt <= '0;
    end else begin
      m_acc <= m_acc_i;
      m_stall_in <= m_stall_in_i;
      m_fire <= m_fire_i;
      m_fire_cls <= m_fire_cls_i;
      m_demote <= m_demote_i;
      mt_push <= mt_push_i;
      m_push_wr <= m_push_wr_i;
      m_push_bytes <= m_push_bytes_i;
      m_cpl <= m_cpl_i;
      m_cpl_st <= m_cpl_st_i;
      m_cpl_cls <= m_cpl_cls_i;
      m_cpl_lat <= m_cpl_lat_i;
      m_held_adm <= m_held_adm_i;
      m_held_cong <= m_held_cong_i;
      m_viol <= m_viol_i;
      m_iq_occ <= m_iq_occ_i;
      m_out <= m_out_i;
      t_xfer <= t_xfer_i;
      t_xfer_cls <= t_xfer_cls_i;
      t_xfer_bytes <= t_xfer_bytes_i;
      t_req <= t_req_i;
      t_cls <= t_cls_i;
      t_busy <= t_busy_i;
      t_bp <= t_bp_i;
      t_cong <= t_cong_i;
      t_rsp <= t_rsp_i;
      t_xq_occ <= t_xq_occ_i;
      t_eq_occ <= t_eq_occ_i;
      t_badsrc <= t_badsrc_i;
      sec_evt <= sec_evt_i;
    end
  end
  // ---- which counters are max counters
  function automatic logic [NCNT-1:0] mk_max();
    logic [NCNT-1:0] v;
    begin
      v = '0;
      for (int m = 0; m < NM; m++) begin
        v[sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_LAT_MAX)] = 1'b1;
        v[sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_OUT_MAX)] = 1'b1;
        v[sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_IQ_MAX)]  = 1'b1;
      end
      for (int c = 0; c < 4; c++) v[sf_meridian_qos_pkg::pf_c(NM, c, sf_meridian_qos_pkg::PFC_LAT_MAX)] = 1'b1;
      for (int t = 0; t < NT; t++) begin
        v[sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_XQ_MAX)] = 1'b1;
        v[sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_EQ_MAX)] = 1'b1;
        v[sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_BP_RUN)] = 1'b1;
      end
      mk_max = v;
    end
  endfunction
  localparam logic [NCNT-1:0] IS_MAX = mk_max();

  logic [NCNT*CW-1:0] cnt_q;
  logic [NCNT*CW-1:0] inc_f;
  logic [NT*CW-1:0]   bprun_q;
  logic [NT*CW-1:0]   bprun_nf;

  function automatic int pcnt(input logic [NM-1:0] v);
    int r;
    begin r = 0; for (int i = 0; i < NM; i++) if (v[i]) r++; pcnt = r; end
  endfunction

  always_comb begin
    int nreq;
    logic anycontend;
    inc_f = '0;
    bprun_nf = '0;
    inc_f[(sf_meridian_qos_pkg::PFG_CYCLES)*CW +: CW] = CW'(1);
    anycontend = 1'b0;

    // ---------------- per master
    for (int m = 0; m < NM; m++) begin
      logic [sf_meridian_qos_pkg::VW-1:0] vv;
      logic [2:0]    st;
      logic [LATW-1:0] lat;
      logic [BW-1:0] by;
      int nv;
      vv  = m_viol[m*sf_meridian_qos_pkg::VW +: sf_meridian_qos_pkg::VW];
      st  = m_cpl_st[m*3 +: 3];
      lat = m_cpl_lat[m*LATW +: LATW];
      by  = m_push_bytes[m*BW +: BW];
      nv  = 0;
      for (int k = 0; k < sf_meridian_qos_pkg::VW; k++) if (vv[k]) nv++;
      inc_f[(sf_meridian_qos_pkg::PFG_ACC)*CW +: CW] = inc_f[(sf_meridian_qos_pkg::PFG_ACC)*CW +: CW] + (CW'(m_acc[m]));
      inc_f[(sf_meridian_qos_pkg::PFG_FIRE)*CW +: CW] = inc_f[(sf_meridian_qos_pkg::PFG_FIRE)*CW +: CW] + (CW'(m_fire[m]));
      inc_f[(sf_meridian_qos_pkg::PFG_CPL)*CW +: CW] = inc_f[(sf_meridian_qos_pkg::PFG_CPL)*CW +: CW] + (CW'(m_cpl[m]));
      inc_f[(sf_meridian_qos_pkg::PFG_CPLERR)*CW +: CW] = inc_f[(sf_meridian_qos_pkg::PFG_CPLERR)*CW +: CW] + (CW'(m_cpl[m] && st != sf_meridian_qos_pkg::ST_OKAY));
      inc_f[(sf_meridian_qos_pkg::PFG_HELD_ADM)*CW +: CW] = inc_f[(sf_meridian_qos_pkg::PFG_HELD_ADM)*CW +: CW] + (CW'(m_held_adm[m]));
      inc_f[(sf_meridian_qos_pkg::PFG_HELD_CONG)*CW +: CW] = inc_f[(sf_meridian_qos_pkg::PFG_HELD_CONG)*CW +: CW] + (CW'(m_held_cong[m]));
      inc_f[(sf_meridian_qos_pkg::PFG_DEMOTE)*CW +: CW] = inc_f[(sf_meridian_qos_pkg::PFG_DEMOTE)*CW +: CW] + (CW'(m_demote[m]));
      inc_f[(sf_meridian_qos_pkg::PFG_VIOL)*CW +: CW] = inc_f[(sf_meridian_qos_pkg::PFG_VIOL)*CW +: CW] + (CW'(nv));
      if (|mt_push[m*NT +: NT]) begin
        if (m_push_wr[m]) inc_f[(sf_meridian_qos_pkg::PFG_BYTES_WR)*CW +: CW] = inc_f[(sf_meridian_qos_pkg::PFG_BYTES_WR)*CW +: CW] + (CW'(by));
        else              inc_f[(sf_meridian_qos_pkg::PFG_BYTES_RD)*CW +: CW] = inc_f[(sf_meridian_qos_pkg::PFG_BYTES_RD)*CW +: CW] + (CW'(by));
        if (m_push_wr[m]) inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_BYTES_WR))*CW +: CW] = CW'(by);
        else              inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_BYTES_RD))*CW +: CW] = CW'(by);
      end
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_ACC))*CW +: CW]       = CW'(m_acc[m]);
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_CPL))*CW +: CW]       = CW'(m_cpl[m]);
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_ERR))*CW +: CW]       = CW'(m_cpl[m] && st != sf_meridian_qos_pkg::ST_OKAY);
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_DECERR))*CW +: CW]    = CW'(m_cpl[m] && st == sf_meridian_qos_pkg::ST_DECERR);
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_DENIED))*CW +: CW]    = CW'(m_cpl[m] && st == sf_meridian_qos_pkg::ST_DENIED);
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_PROTO))*CW +: CW]     = CW'(m_cpl[m] && st == sf_meridian_qos_pkg::ST_PROTO);
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_SLVERR))*CW +: CW]    = CW'(m_cpl[m] && st == sf_meridian_qos_pkg::ST_SLVERR);
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_LAT_SUM))*CW +: CW]   = m_cpl[m] ? CW'(lat) : '0;
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_LAT_CNT))*CW +: CW]   = CW'(m_cpl[m]);
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_LAT_MAX))*CW +: CW]   = m_cpl[m] ? CW'(lat) : '0;
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_OUT_SUM))*CW +: CW]   = CW'(m_out[m*OCW +: OCW]);
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_OUT_MAX))*CW +: CW]   = CW'(m_out[m*OCW +: OCW]);
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_IQ_SUM))*CW +: CW]    = CW'(m_iq_occ[m*OCW +: OCW]);
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_IQ_MAX))*CW +: CW]    = CW'(m_iq_occ[m*OCW +: OCW]);
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_STALL_IN))*CW +: CW]  = CW'(m_stall_in[m]);
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_HELD_ADM))*CW +: CW]  = CW'(m_held_adm[m]);
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_HELD_CONG))*CW +: CW] = CW'(m_held_cong[m]);
      inc_f[(sf_meridian_qos_pkg::pf_m(m, sf_meridian_qos_pkg::PFM_VIOL))*CW +: CW]      = CW'(nv);
      for (int t = 0; t < NT; t++)
        inc_f[(sf_meridian_qos_pkg::pf_x(NM, NT, m, t))*CW +: CW] = CW'(mt_push[m*NT + t]);
    end

    // ---------------- per class: constant class index (a runtime-indexed write into the wide increment vector would
    // synthesise to a decoder / shifter over the whole bank, thousands of bits wide, for every statement)
    for (int k = 0; k < 4; k++) begin
      logic [CW-1:0] f_n, d_n, c_n, ls_n, lc_n, lm_n;
      f_n = '0; d_n = '0; c_n = '0; ls_n = '0; lc_n = '0; lm_n = '0;
      for (int m = 0; m < NM; m++) begin
        if (m_fire[m]   && m_fire_cls[m*2 +: 2] == 2'(k)) f_n = f_n + CW'(1);
        if (m_demote[m] && m_fire_cls[m*2 +: 2] == 2'(k)) d_n = d_n + CW'(1);
        if (m_cpl[m]    && m_cpl_cls[m*2 +: 2]  == 2'(k)) begin
          c_n  = c_n  + CW'(1);
          lc_n = lc_n + CW'(1);
          ls_n = ls_n + CW'(m_cpl_lat[m*LATW +: LATW]);
          if (CW'(m_cpl_lat[m*LATW +: LATW]) > lm_n) lm_n = CW'(m_cpl_lat[m*LATW +: LATW]);
        end
      end
      inc_f[(sf_meridian_qos_pkg::pf_c(NM, k, sf_meridian_qos_pkg::PFC_FIRE))*CW +: CW]    = f_n;
      inc_f[(sf_meridian_qos_pkg::pf_c(NM, k, sf_meridian_qos_pkg::PFC_DEMOTE))*CW +: CW]  = d_n;
      inc_f[(sf_meridian_qos_pkg::pf_c(NM, k, sf_meridian_qos_pkg::PFC_CPL))*CW +: CW]     = c_n;
      inc_f[(sf_meridian_qos_pkg::pf_c(NM, k, sf_meridian_qos_pkg::PFC_LAT_SUM))*CW +: CW] = ls_n;
      inc_f[(sf_meridian_qos_pkg::pf_c(NM, k, sf_meridian_qos_pkg::PFC_LAT_CNT))*CW +: CW] = lc_n;
      inc_f[(sf_meridian_qos_pkg::pf_c(NM, k, sf_meridian_qos_pkg::PFC_LAT_MAX))*CW +: CW] = lm_n;
    end
    inc_f[(sf_meridian_qos_pkg::PFG_SEC)*CW +: CW] = CW'(sec_evt);

    // ---------------- per target
    for (int t = 0; t < NT; t++) begin
      logic [NM-1:0] rq;
      rq = t_req[t*NM +: NM];
      nreq = pcnt(rq);
      inc_f[(sf_meridian_qos_pkg::PFG_XFER)*CW +: CW] = inc_f[(sf_meridian_qos_pkg::PFG_XFER)*CW +: CW] + (CW'(t_xfer[t]));
      inc_f[(sf_meridian_qos_pkg::PFG_BP)*CW +: CW] = inc_f[(sf_meridian_qos_pkg::PFG_BP)*CW +: CW] + (CW'(t_bp[t]));
      inc_f[(sf_meridian_qos_pkg::PFG_VIOL)*CW +: CW] = inc_f[(sf_meridian_qos_pkg::PFG_VIOL)*CW +: CW] + (CW'(t_badsrc[t]));
      inc_f[(sf_meridian_qos_pkg::PFG_ARBSTALL)*CW +: CW] = inc_f[(sf_meridian_qos_pkg::PFG_ARBSTALL)*CW +: CW] + (CW'(nreq - (t_xfer[t] ? 1 : 0)));
      if (nreq >= 2) anycontend = 1'b1;
      for (int k = 0; k < 4; k++) begin
        int nk; logic wk;
        nk = 0;
        for (int m = 0; m < NM; m++) if (rq[m] && t_cls[(t*NM + m)*2 +: 2] == 2'(k)) nk++;
        wk = t_xfer[t] && (t_xfer_cls[t*2 +: 2] == 2'(k));
        inc_f[(sf_meridian_qos_pkg::pf_c(NM, k, sf_meridian_qos_pkg::PFC_GRANTS))*CW +: CW] = inc_f[(sf_meridian_qos_pkg::pf_c(NM, k, sf_meridian_qos_pkg::PFC_GRANTS))*CW +: CW] + CW'(wk);
        inc_f[(sf_meridian_qos_pkg::pf_c(NM, k, sf_meridian_qos_pkg::PFC_ARBSTALL))*CW +: CW] = inc_f[(sf_meridian_qos_pkg::pf_c(NM, k, sf_meridian_qos_pkg::PFC_ARBSTALL))*CW +: CW] + (CW'(nk) - CW'(wk));
      end
      inc_f[(sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_XFER))*CW +: CW]     = CW'(t_xfer[t]);
      inc_f[(sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_BYTES))*CW +: CW]    = t_xfer[t] ? CW'(t_xfer_bytes[t*BW +: BW]) : '0;
      inc_f[(sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_BUSY))*CW +: CW]     = CW'(t_busy[t]);
      inc_f[(sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_CONTEND))*CW +: CW]  = CW'(nreq >= 2);
      inc_f[(sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_ARBSTALL))*CW +: CW] = CW'(nreq - (t_xfer[t] ? 1 : 0));
      inc_f[(sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_XQ_SUM))*CW +: CW]   = CW'(t_xq_occ[t*OCW +: OCW]);
      inc_f[(sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_XQ_MAX))*CW +: CW]   = CW'(t_xq_occ[t*OCW +: OCW]);
      inc_f[(sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_EQ_SUM))*CW +: CW]   = CW'(t_eq_occ[t*OCW +: OCW]);
      inc_f[(sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_EQ_MAX))*CW +: CW]   = CW'(t_eq_occ[t*OCW +: OCW]);
      inc_f[(sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_BP))*CW +: CW]       = CW'(t_bp[t]);
      bprun_nf[t*CW +: CW]                     = t_bp[t] ? bprun_q[t*CW +: CW] + CW'(1) : '0;
      inc_f[(sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_BP_RUN))*CW +: CW]   = bprun_nf[t*CW +: CW];
      inc_f[(sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_CONG))*CW +: CW]     = CW'(t_cong[t]);
      inc_f[(sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_RSP))*CW +: CW]      = CW'(t_rsp[t]);
      inc_f[(sf_meridian_qos_pkg::pf_t(NM, t, sf_meridian_qos_pkg::PFT_REQSUM))*CW +: CW]   = CW'(nreq);
    end
    inc_f[(sf_meridian_qos_pkg::PFG_CONTEND)*CW +: CW] = CW'(anycontend);
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cnt_q   <= '0;
      bprun_q <= '0;
    end else if (clear) begin
      cnt_q   <= '0;
      bprun_q <= '0;
    end else begin
      for (int i = 0; i < NCNT; i++) begin
        if (IS_MAX[i]) begin
          if (inc_f[(i)*CW +: CW] > cnt_q[i*CW +: CW]) cnt_q[i*CW +: CW] <= inc_f[(i)*CW +: CW];
        end else
          cnt_q[i*CW +: CW] <= cnt_q[i*CW +: CW] + inc_f[(i)*CW +: CW];
      end
      for (int t = 0; t < NT; t++) bprun_q[t*CW +: CW] <= bprun_nf[t*CW +: CW];
    end
  end

  always_comb begin                       // read mux over constant slices (a variable-start select of the whole bank is a barrel shifter)
    rd_data = '0;
    for (int i = 0; i < NCNT; i++)
      if (32'(rd_idx) == i) rd_data = cnt_q[i*CW +: CW];
  end
endmodule

`default_nettype wire
