// =============================================================================
// SilicaFlux -- Project 102 -- MeridianQoS :: sf_meridian_arbiter
//
// Per-target request arbiter.  N requesters (the crosspoint-queue heads of the N masters) present `req[i]` and a
// scheduling class `cls[i]` (0 = CLASS_0 = most urgent .. 3 = CLASS_3).  `en` is the downstream's REGISTERED
// "I can take one" flag; a transfer happens in the cycle `gvalid && en` -- the grant IS the transfer (nothing is
// granted that is not moved in the same cycle, so no grant lock is needed; a requester's head is stable until
// then because only the grant pops it).
//
// Policy (runtime, `cfg_policy`):
//   sf_meridian_qos_pkg::POL_RR     plain round robin over requesters; classes ignored.  Bound: served after at most N-1 transfers
//              of other requesters.
//   sf_meridian_qos_pkg::POL_WRR    weighted round robin over CLASSES with credits, round robin over requesters inside a class.
//              credit[k] is reloaded to weight[k] (0 behaves as 1) when no requesting class has credit left;
//              among requesting classes that have credit the most urgent class wins.  Every class with a
//              requester is therefore served at least weight[k] times per round: NO class can be starved,
//              whatever the weights (a weight of 0 is treated as 1 -- the hardware never lets a class's share
//              fall to zero).  Under saturation the shares are proportional to the weights.
//              Bound (see docs 03_ARBITRATION_QOS.md): a requester of class c with N masters is served after at
//              most  (N-1) + (ceil(N/w_c) + 1) * (W - w_c)  transfers of other requesters, W = sum of weights.
//   sf_meridian_qos_pkg::POL_STRICT strict class priority (CLASS_0 first).  With `cfg_starve` = S > 0 a requester that has seen S
//              transfers of others while requesting becomes URGENT and sits above every class (P83 / P22 aging):
//              bound S + N - 1.  With S = 0 there is NO starvation protection: a class can be starved by a
//              higher class for as long as the higher class keeps requesting (that is what "strict" means).
//              STRICT_EN = 0 removes the logic; the register block then refuses to select it.
//   (3 is reserved and behaves as sf_meridian_qos_pkg::POL_RR.)
//
// Per-class round-robin pointers: the pointer of class k moves only when class k wins, so requesters inside one
// class alternate regardless of what other classes do (a single shared pointer would let a stream of grants to
// another class pin one requester of this class).  Urgent requesters and sf_meridian_qos_pkg::POL_RR use the global pointer.
//
// Determinism: grant is a pure function of (req, cls, config, pointers, ages, credits).  Combinational path:
// req/cls -> grant.  No path from `en`.
// Cross-checked: sf_meridian_qos_pkg::POL_RR == sfn_qos_arbiter(STARVE=0); sf_meridian_qos_pkg::POL_STRICT, <=1 requester per class == sfn_qos_arbiter
// (levels = 3 - class, STARVE = S) cycle by cycle (tests/meridian_qos/tb/tb_arb_diff.sv); all policies against an
// independent behavioural model (tb_arb_model.sv).
// =============================================================================
`default_nettype none

module sf_meridian_arbiter #(
  parameter int  N         = 2,
  parameter int  STRICT_EN = 1,
  parameter int  AGEW      = 8,
  parameter int  WTW       = 8,
  localparam int IW        = sf_meridian_qos_pkg::clog2c(N)
) (
  input  logic               clk,
  input  logic               rst_n,
  input  logic [N-1:0]       req,
  input  logic [N*2-1:0]     cls,
  input  logic               en,
  input  logic [1:0]         cfg_policy,
  input  logic [4*WTW-1:0]   cfg_weight,
  input  logic [AGEW-1:0]    cfg_starve,
  output logic [N-1:0]       grant,       // one-hot or zero; independent of `en`
  output logic [IW-1:0]      gidx,
  output logic               gvalid,
  output logic [1:0]         gcls,        // class of the winner (valid with gvalid)
  output logic [N-1:0]       urgent,      // observability: aging reached (sf_meridian_qos_pkg::POL_STRICT only)
  output logic               reload       // observability: WRR credits reloaded with this grant
);
  logic [IW-1:0]      gptr_q;             // global pointer (sf_meridian_qos_pkg::POL_RR, urgent set)
  logic [4*IW-1:0]    cptr_q;             // per-class pointers
  logic [N*AGEW-1:0]  age_q;
  logic [4*WTW-1:0]   credit_q;

  logic               pol_strict, pol_wrr;
  logic [4*WTW-1:0]   wt_v;               // effective weights, packed (an unpacked array written in always_comb is a memory to Yosys)
  logic [3:0]         reqc, avail, credit_nz;
  logic [1:0]         csel;               // class whose pointer / mask is used
  logic [N-1:0]       elig, upper;
  logic [IW-1:0]      ptr;
  logic [N-1:0]       first_u, first_e;
  logic               any_urg, seen_u, seen_e, has_up, use_cptr;

  assign pol_strict = (cfg_policy == sf_meridian_qos_pkg::POL_STRICT) && (STRICT_EN != 0);
  assign pol_wrr    = (cfg_policy == sf_meridian_qos_pkg::POL_WRR) || ((cfg_policy == sf_meridian_qos_pkg::POL_STRICT) && (STRICT_EN == 0));

  always_comb begin
    // ---- effective weights (0 behaves as 1)
    for (int k = 0; k < 4; k++) begin
      wt_v[k*WTW +: WTW] = (cfg_weight[k*WTW +: WTW] == '0) ? WTW'(1) : cfg_weight[k*WTW +: WTW];
      credit_nz[k] = (credit_q[k*WTW +: WTW] != '0);
    end
    // ---- which classes have a requester
    reqc = '0;
    for (int i = 0; i < N; i++)
      if (req[i]) reqc[cls[i*2 +: 2]] = 1'b1;
    // ---- aging / urgent set (strict policy only)
    for (int i = 0; i < N; i++)
      urgent[i] = pol_strict && (cfg_starve != '0) && (age_q[i*AGEW +: AGEW] >= cfg_starve);
    any_urg = |(req & urgent);

    // ---- WRR: credit reload when no requesting class has credit
    reload = pol_wrr && (|reqc) && !(|(reqc & credit_nz));
    for (int k = 0; k < 4; k++)
      avail[k] = reqc[k] && (credit_nz[k] || reload);

    // ---- class / pointer / eligible set per policy
    csel     = 2'd0;
    elig     = req;
    use_cptr = 1'b0;
    if (pol_strict) begin
      if (any_urg) begin
        elig = req & urgent;
      end else begin
        csel = 2'd3;
        for (int k = 2; k >= 0; k--) if (reqc[k]) csel = 2'(k);
        for (int i = 0; i < N; i++)
          elig[i] = req[i] && (cls[i*2 +: 2] == csel);
        use_cptr = 1'b1;
      end
    end else if (pol_wrr) begin
      csel = 2'd3;
      for (int k = 2; k >= 0; k--) if (avail[k]) csel = 2'(k);
      for (int i = 0; i < N; i++)
        elig[i] = req[i] && (cls[i*2 +: 2] == csel);
      use_cptr = 1'b1;
    end
    // pointer: the global one, or the pointer of the selected class (constant slices, no variable-start select)
    ptr = gptr_q;
    if (use_cptr)
      for (int k = 0; k < 4; k++)
        if (csel == 2'(k)) ptr = cptr_q[k*IW +: IW];

    // ---- round robin inside the eligible set: first at / after ptr, else first overall -- built directly in one-hot form
    for (int i = 0; i < N; i++) upper[i] = elig[i] && (32'(i) >= 32'(ptr));
    has_up = |upper;
    seen_u = 1'b0;
    seen_e = 1'b0;
    for (int i = 0; i < N; i++) begin
      first_u[i] = upper[i] && !seen_u;
      seen_u     = seen_u | upper[i];
      first_e[i] = elig[i] && !seen_e;
      seen_e     = seen_e | elig[i];
    end
    grant  = has_up ? first_u : first_e;
    gvalid = |grant;
    gidx   = '0;
    gcls   = '0;
    for (int i = 0; i < N; i++)
      if (grant[i]) begin
        gidx = gidx | IW'(i);
        gcls = gcls | cls[i*2 +: 2];
      end
  end

  wire xfer = gvalid && en;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      gptr_q   <= '0;
      cptr_q   <= '0;
      age_q    <= '0;
      credit_q <= '0;
    end else begin
      // pointers move past the winner on every transfer
      if (xfer) begin
        gptr_q <= (gidx == IW'(N - 1)) ? '0 : gidx + IW'(1);
        for (int k = 0; k < 4; k++)
          if (gcls == 2'(k)) cptr_q[k*IW +: IW] <= (gidx == IW'(N - 1)) ? '0 : gidx + IW'(1);
      end
      // aging: transfers of others seen while requesting (saturating)
      for (int i = 0; i < N; i++) begin
        if (!req[i] || (xfer && gidx == IW'(i)))
          age_q[i*AGEW +: AGEW] <= '0;
        else if (xfer && age_q[i*AGEW +: AGEW] != '1)
          age_q[i*AGEW +: AGEW] <= age_q[i*AGEW +: AGEW] + AGEW'(1);
      end
      // WRR credits (reloaded every cycle while another policy is selected, so a switch starts a clean round)
      for (int k = 0; k < 4; k++) begin
        if (!pol_wrr)
          credit_q[k*WTW +: WTW] <= wt_v[k*WTW +: WTW];
        else if (xfer) begin
          if (k == 32'(gcls))
            credit_q[k*WTW +: WTW] <= (reload ? wt_v[k*WTW +: WTW] : credit_q[k*WTW +: WTW]) - WTW'(1);
          else if (reload)
            credit_q[k*WTW +: WTW] <= wt_v[k*WTW +: WTW];
        end
      end
    end
  end
endmodule

`default_nettype wire
