// =============================================================================
// SilicaFlux -- Project 102 -- MeridianQoS :: sf_meridian_mport     (one master port)
//
//   m_req --> [IQ: ingress queue] --> [optional DEC stage] --> admission / decode / classify / guard
//                                                          \--> crosspoint queue XQ[m][t]   (via the router)
//   m_rsp <-- [RQ: response queue] <-- slot table (tag tracking, ordering) <-- rin (responses from the router)
//
// Ingress.  Every request is accepted into the ingress queue (m_req_ready = "not full", registered): the master
// is never stalled by a decision.  The head of the queue is examined in a fixed order (first failure wins, the
// order of Project 83): reserved opcode -> misalignment -> domain binding -> decode -> (tag reuse is checked first
// of all) -> MemoryGuard check.  A request that fails is NOT forwarded; it is answered locally with the documented
// status (ST_PROTO / ST_DENIED / ST_DECERR, docs/meridian_qos/02_ABI.md) through its own slot, in slot order.
//
// Admission control (never drops, only holds the queue head): (1) a free slot must exist (MAXO outstanding);
// (2) per-class outstanding limit (OUTLIM); (3) congestion throttle: while the destination target is congested,
// requests of class >= THR wait.  A held head blocks the requests behind it of the SAME master (one in-order
// stream per master, docs 03); other masters are unaffected.
//
// MemoryGuard.  A request that passed the local checks is sent to the guard (`grd_*`) when it is admitted: its
// slot is allocated, one crosspoint-queue entry and one guard-queue (GQ) entry are RESERVED, and the request waits
// in the GQ.  The guard returns one verdict per query, in order, >= 1 cycle later (registered); the verdict pops
// the GQ: ok -> the request moves into its crosspoint queue (space was reserved, so this can never stall);
// not ok -> the slot is completed with ST_DENIED and the request never reaches the crosspoint.  GUARD_EN = 0
// removes the guard (bring-up only: domain binding stays).
//
// Slot table.  One slot per outstanding transaction (MAXO): tag, op, domain, target, class, status, read data,
// accept timestamp.  Per-class and total outstanding counts are REGISTERED counters (+1 at allocation, -1 at delivery),
// and every slot field is selected / written with constant-index loops (a variable-start part-select of a packed
// vector synthesises to a barrel shifter: found by the first synthesis run, which put these on the critical path).  A tag equal to a live slot's tag is a master protocol violation: the request is consumed and
// counted, no response (it could not be told apart from the first transaction's).  A response from the router
// is matched by (tag, target) against slots whose request has been committed; echo (domain, op) and status are
// checked (ST_PROTO on mismatch); a response matching nothing is an orphan: consumed and counted.  Delivery:
// OOO = 0 in acceptance order (reorder through the slot table), OOO = 1 as completed (round robin over done slots).
// Exactly one response is delivered per allocated slot.
// =============================================================================
`default_nettype none
/* verilator lint_off PINCONNECTEMPTY */

module sf_meridian_mport #(
  parameter int                     NT         = 2,
  parameter int                     AW         = 32,
  parameter int                     DW         = 64,
  parameter int                     TAGW       = 4,
  parameter int                     DOMW       = 3,
  parameter logic [NT*AW-1:0]       TGT_BASE   = {(NT*AW){1'b0}},
  parameter logic [NT*AW-1:0]       TGT_MASK   = {(NT*AW){1'b0}},
  parameter logic [NT-1:0]          CONN       = {NT{1'b1}},
  parameter logic [(1<<DOMW)-1:0]   DOM_ALLOW  = {(1<<DOMW){1'b1}},
  parameter int                     MAXO       = 4,
  parameter bit                     OOO        = 1'b0,
  parameter int                     IQ_DEPTH   = 4,
  parameter int                     XQ_DEPTH   = 4,
  parameter int                     RQ_DEPTH   = 2,
  parameter int                     DEC_PIPE   = 0,
  parameter int                     GUARD_EN   = 1,
  parameter int                     GQ_DEPTH   = 2,
  parameter int                     LATW       = 16,
  parameter int                     OCW        = 8,
  localparam int                    TW         = sf_meridian_qos_pkg::clog2c(NT),
  localparam int                    SIW        = sf_meridian_qos_pkg::clog2c(MAXO),
  localparam int                    RQW        = 2 + TAGW + DOMW + 1 + 3 + AW + DW + DW / 8,
  localparam int                    XW         = RQW + 2,
  localparam int                    IW         = LATW + RQW,
  localparam int                    MRW        = TAGW + DOMW + 2 + 3 + DW,
  localparam int                    XCW        = sf_meridian_qos_pkg::clog2c(XQ_DEPTH + 1),
  localparam int                    BW         = sf_meridian_qos_pkg::clog2c(DW / 8 + 1),
  localparam int                    VW         = sf_meridian_qos_pkg::VW
) (
  input  logic                  clk,
  input  logic                  rst_n,
  // ---- request channel in (after the master-edge slice)
  input  logic                  req_valid,
  output logic                  req_ready,
  input  logic [RQW-1:0]        req_data,
  // ---- response channel out (before the master-edge slice)
  output logic                  rsp_valid,
  input  logic                  rsp_ready,
  output logic [MRW-1:0]        rsp_data,
  // ---- crosspoint push (to the router)
  output logic [NT-1:0]         xq_push,
  output logic [XW-1:0]         xq_wdata,
  input  logic [NT*XCW-1:0]     xq_cnt,
  // ---- responses from the router (always accepted)
  input  logic                  rin_valid,
  input  logic [TW-1:0]         rin_tgt,
  input  logic [MRW-1:0]        rin_data,
  // ---- MemoryGuard check port
  output logic                  grd_req_valid,
  input  logic                  grd_req_ready,
  output logic [DOMW-1:0]       grd_req_dom,
  output logic                  grd_req_priv,
  output logic                  grd_req_write,
  output logic [AW-1:0]         grd_req_addr,
  input  logic                  grd_rsp_valid,
  input  logic                  grd_rsp_ok,
  input  logic [3:0]            grd_rsp_fault,
  // ---- scheduling configuration
  input  logic [15:0]           cfg_tcmap,
  input  logic [1:0]            cfg_floor,
  input  logic [31:0]           cfg_outlim,
  input  logic                  cfg_cong_en,
  input  logic [1:0]            cfg_thr_cls,
  input  logic [NT-1:0]         cong,
  input  logic [LATW-1:0]       cyc,
  // ---- events / observability
  output logic                  ev_acc,
  output logic                  ev_fire,
  output logic [1:0]            ev_fire_cls,
  output logic                  ev_demote,
  output logic                  ev_push,
  output logic                  ev_push_wr,
  output logic [BW-1:0]         ev_push_bytes,
  output logic                  ev_cpl,
  output logic [2:0]            ev_cpl_st,
  output logic [1:0]            ev_cpl_cls,
  output logic [LATW-1:0]       ev_cpl_lat,
  output logic                  ev_held_adm,
  output logic                  ev_held_cong,
  output logic [VW-1:0]         ev_viol,
  output logic                  ev_denied,
  output logic                  ev_decerr,
  output logic [OCW-1:0]        o_iq_occ,
  output logic [OCW-1:0]        o_out,
  output logic                  elog_set,
  output logic [2:0]            elog_status,
  output logic [3:0]            elog_fault,
  output logic [TAGW-1:0]       elog_tag,
  output logic [DOMW-1:0]       elog_dom,
  output logic [AW-1:0]         elog_addr
);
  // ---------------------------------------------------------------- field layout of the request word (RQW)
  localparam int O_WDATA = DW / 8;
  localparam int O_ADDR  = O_WDATA + DW;
  localparam int O_TC    = O_ADDR + AW;
  localparam int O_PRIV  = O_TC + 3;
  localparam int O_DOM   = O_PRIV + 1;
  localparam int O_TAG   = O_DOM + DOMW;
  localparam int O_OP    = O_TAG + TAGW;
  localparam int O_TS    = O_OP + 2;            // timestamp prepended by the ingress queue (IW = RQW + LATW)
  // response word layout (MRW): {tag, dom, op, status, rdata}
  localparam int R_RD    = 0;
  localparam int R_ST    = DW;
  localparam int R_OP    = DW + 3;
  localparam int R_DOM   = DW + 5;
  localparam int R_TAG   = DW + 5 + DOMW;

  localparam logic [2:0] ST_OKAY   = sf_meridian_qos_pkg::ST_OKAY;
  localparam logic [2:0] ST_SLVERR = sf_meridian_qos_pkg::ST_SLVERR;
  localparam logic [2:0] ST_DECERR = sf_meridian_qos_pkg::ST_DECERR;
  localparam logic [2:0] ST_DENIED = sf_meridian_qos_pkg::ST_DENIED;
  localparam logic [2:0] ST_PROTO  = sf_meridian_qos_pkg::ST_PROTO;

  // ---------------------------------------------------------------- ingress queue (+ optional decode stage)
  logic          iq_ov, iq_or, iq_ir;
  logic [IW-1:0] iq_od;
  logic [sf_meridian_qos_pkg::clog2c(IQ_DEPTH + 1)-1:0] iq_cnt;

  sf_meridian_queue #(.W(IW), .DEPTH(IQ_DEPTH)) u_iq (
    .clk, .rst_n,
    .in_valid (req_valid),
    .in_ready (iq_ir),
    .in_data  ({cyc, req_data}),
    .out_valid(iq_ov),
    .out_ready(iq_or),
    .out_data (iq_od),
    .count    (iq_cnt));
  assign req_ready = iq_ir;
  assign ev_acc    = req_valid && iq_ir;

  logic          s_valid, s_pop;
  logic [IW-1:0] s_word;
  logic          d_v_q;

  if (DEC_PIPE == 0) begin : g_nodec
    assign s_valid = iq_ov;
    assign s_word  = iq_od;
    assign iq_or   = s_pop;
    assign d_v_q   = 1'b0;
  end else begin : g_dec
    logic [IW-1:0] d_w_q;
    assign s_valid = d_v_q;
    assign s_word  = d_w_q;
    assign iq_or   = !d_v_q || s_pop;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) d_v_q <= 1'b0;
      else if (iq_or) d_v_q <= iq_ov;
    end
    always_ff @(posedge clk) begin
      if (iq_or && iq_ov) d_w_q <= iq_od;
    end
  end

  wire [1:0]      s_op   = s_word[O_OP +: 2];
  wire [TAGW-1:0] s_tag  = s_word[O_TAG +: TAGW];
  wire [DOMW-1:0] s_dom  = s_word[O_DOM +: DOMW];
  wire            s_priv = s_word[O_PRIV];
  wire [2:0]      s_tc   = s_word[O_TC +: 3];
  wire [AW-1:0]   s_addr = s_word[O_ADDR +: AW];
  wire [LATW-1:0] s_ts   = s_word[O_TS +: LATW];
  wire [RQW-1:0]  s_req  = s_word[RQW-1:0];

  // ---------------------------------------------------------------- decode and local checks
  logic          dec_hit, dec_reach, dec_misal;
  logic [TW-1:0] dec_tgt;
  sf_meridian_decoder #(.NT(NT), .AW(AW), .DW(DW), .TGT_BASE(TGT_BASE), .TGT_MASK(TGT_MASK), .CONN(CONN)) u_dec (
    .addr(s_addr), .hit(dec_hit), .tgt(dec_tgt), .reach(dec_reach), .misaligned(dec_misal));

  logic        bad_op, spoof, unmapped, noroute, local_err;
  logic [2:0]  err_status;
  logic [3:0]  err_fault;
  logic [1:0]  cls_raw, cls_eff;
  logic        demoted;
  always_comb begin
    bad_op    = s_op[1];
    spoof     = !DOM_ALLOW[s_dom];
    unmapped  = !dec_hit;
    noroute   = dec_hit && !dec_reach;
    local_err = bad_op || dec_misal || spoof || unmapped || noroute;
    // first failure wins: opcode, alignment, domain binding, decode
    if (bad_op)         begin err_status = ST_PROTO;  err_fault = sf_meridian_qos_pkg::F_BADOP;    end
    else if (dec_misal) begin err_status = ST_PROTO;  err_fault = sf_meridian_qos_pkg::F_MISALIGN; end
    else if (spoof)     begin err_status = ST_DENIED; err_fault = sf_meridian_qos_pkg::F_SPOOF;    end
    else if (unmapped)  begin err_status = ST_DECERR; err_fault = sf_meridian_qos_pkg::F_UNMAPPED; end
    else                begin err_status = ST_DECERR; err_fault = sf_meridian_qos_pkg::F_NOROUTE;  end
    // scheduling class: tc -> class map, then the master's floor (it may not use a class more urgent than that)
    cls_raw = cfg_tcmap[s_tc*2 +: 2];
    cls_eff = (cls_raw < cfg_floor) ? cfg_floor : cls_raw;
    demoted = (cls_eff != cls_raw);
  end

  // ---------------------------------------------------------------- slot table state
  logic [MAXO-1:0]       sv_q, si_q, sd_q;          // allocated, committed to the fabric, completed
  logic [MAXO*TAGW-1:0]  stag_q;
  logic [MAXO*2-1:0]     sop_q, scls_q;
  logic [MAXO*DOMW-1:0]  sdom_q;
  logic [MAXO*TW-1:0]    stgt_q;
  logic [MAXO*3-1:0]     sst_q;
  logic [MAXO*DW-1:0]    srd_q;
  logic [MAXO*LATW-1:0]  sts_q;

  // tag in use?
  logic tag_busy;
  always_comb begin
    tag_busy = 1'b0;
    for (int i = 0; i < MAXO; i++)
      if (sv_q[i] && stag_q[i*TAGW +: TAGW] == s_tag) tag_busy = 1'b1;
  end

  // free slot (lowest index)
  logic             fany;
  logic [SIW-1:0]   fidx;
  always_comb begin
    fany = 1'b0;
    fidx = '0;
    for (int i = MAXO - 1; i >= 0; i--)
      if (!sv_q[i]) begin fany = 1'b1; fidx = SIW'(i); end
  end

  // outstanding per class / total: REGISTERED counters (+1 at allocation, -1 at delivery), not a recount of the slot table
  // every cycle (that loop of adders was the critical path of the first place-and-route)
  logic [4*OCW-1:0] ncls_v;
  logic [OCW-1:0]   nout;
  // (the counters are updated after the delivery logic below, which supplies `deliver` and the delivered slot's class)
  assign o_out    = nout;
  assign o_iq_occ = OCW'(iq_cnt) + OCW'(d_v_q);

  // ---------------------------------------------------------------- admission control
  logic [7:0]     lim;
  logic           adm_ok, held_cong_c, good_path;
  logic [NT*XCW-1:0] resv_q;                           // guard-queue reservations per target
  logic           xroom;
  logic           gq_ir;
  always_comb begin
    lim         = cfg_outlim[cls_eff*8 +: 8];
    if (lim == 8'd0) lim = 8'd1;                       // a class can never be switched off by a limit of 0
    adm_ok      = (32'(ncls_v[cls_eff*OCW +: OCW]) < 32'(lim));   // below the per-class limit (the slot count bounds the total)
    held_cong_c = cfg_cong_en && cong[dec_tgt] && (cls_eff >= cfg_thr_cls);
    xroom       = (32'(xq_cnt[dec_tgt*XCW +: XCW]) + 32'(resv_q[dec_tgt*XCW +: XCW])) < XQ_DEPTH;
    good_path   = s_valid && !tag_busy && !local_err;
  end

  logic cand, qhold_q;
  logic fire_good, fire_err, fire_drop, fire_alloc;
  logic gq_ok;
  assign gq_ok = (GUARD_EN == 0) || gq_ir;
  assign cand  = good_path && fany && adm_ok && !held_cong_c && xroom && gq_ok;

  assign ev_held_adm  = good_path && fany && !adm_ok;
  assign ev_held_cong = good_path && fany && adm_ok && held_cong_c;

  if (GUARD_EN != 0) begin : g_gq_valid
    assign grd_req_valid = qhold_q || cand;
    assign fire_good     = grd_req_valid && grd_req_ready;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) qhold_q <= 1'b0;
      else        qhold_q <= grd_req_valid && !grd_req_ready;
    end
  end else begin : g_nogrd
    assign grd_req_valid = 1'b0;
    assign fire_good     = cand;
    assign qhold_q       = 1'b0;
  end
  assign grd_req_dom   = s_dom;
  assign grd_req_priv  = s_priv;
  assign grd_req_write = (s_op == sf_meridian_qos_pkg::OP_WRITE);
  assign grd_req_addr  = s_addr;

  assign fire_err   = s_valid && !tag_busy && local_err && fany;
  assign fire_drop  = s_valid && tag_busy;
  assign fire_alloc = fire_good || fire_err;
  assign s_pop      = fire_good || fire_err || fire_drop;

  assign ev_fire     = fire_alloc;
  assign ev_fire_cls = cls_eff;
  assign ev_demote   = fire_alloc && demoted;

  wire [XW-1:0] xw_cur = {cls_eff, s_req};

  // ---------------------------------------------------------------- guard queue (requests waiting for a verdict)
  logic           gq_ov;
  logic [SIW+TW+XW-1:0] gq_od;
  logic           v_pop;
  logic [SIW-1:0] gq_sidx;
  logic [TW-1:0]  gq_tgt;
  logic [XW-1:0]  gq_xw;

  if (GUARD_EN != 0) begin : g_gq
    sf_meridian_queue #(.W(SIW + TW + XW), .DEPTH(GQ_DEPTH)) u_gq (
      .clk, .rst_n,
      .in_valid (fire_good),
      .in_ready (gq_ir),
      .in_data  ({fidx, dec_tgt, xw_cur}),
      .out_valid(gq_ov),
      .out_ready(grd_rsp_valid),
      .out_data (gq_od),
      .count    ());
  end else begin : g_nogq
    assign gq_ir = 1'b1;
    assign gq_ov = 1'b0;
    assign gq_od = '0;
  end
  assign gq_sidx = gq_od[XW + TW +: SIW];
  assign gq_tgt  = gq_od[XW +: TW];
  assign gq_xw   = gq_od[XW-1:0];
  assign v_pop   = (GUARD_EN != 0) && grd_rsp_valid && gq_ov;

  // ---------------------------------------------------------------- crosspoint push
  logic            do_push;
  logic [TW-1:0]   push_tgt;
  logic [XW-1:0]   push_xw;
  always_comb begin
    if (GUARD_EN != 0) begin
      do_push  = v_pop && grd_rsp_ok;
      push_tgt = gq_tgt;
      push_xw  = gq_xw;
    end else begin
      do_push  = fire_good;
      push_tgt = dec_tgt;
      push_xw  = xw_cur;
    end
    xq_push = '0;
    if (do_push) xq_push[push_tgt] = 1'b1;
  end
  assign xq_wdata = push_xw;

  // reservations: +1 when a query is admitted, -1 when its verdict arrives
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) resv_q <= '0;
    else if (GUARD_EN != 0) begin
      for (int t = 0; t < NT; t++) begin
        if (fire_good && dec_tgt == TW'(t) && !(v_pop && gq_tgt == TW'(t)))
          resv_q[t*XCW +: XCW] <= resv_q[t*XCW +: XCW] + XCW'(1);
        else if (!(fire_good && dec_tgt == TW'(t)) && v_pop && gq_tgt == TW'(t))
          resv_q[t*XCW +: XCW] <= resv_q[t*XCW +: XCW] - XCW'(1);
      end
    end
  end

  // push event (bytes: enabled lanes of a write, a full beat of a read)
  always_comb begin
    int n;
    n = 0;
    for (int k = 0; k < DW / 8; k++) if (push_xw[k]) n++;
    ev_push       = do_push;
    ev_push_wr    = (push_xw[RQW-1 -: 2] == sf_meridian_qos_pkg::OP_WRITE);
    ev_push_bytes = ev_push_wr ? BW'(n) : BW'(DW / 8);
  end

  // ---------------------------------------------------------------- spurious guard verdict
  wire v_spurious = (GUARD_EN != 0) && grd_rsp_valid && !gq_ov;

  // ---------------------------------------------------------------- response matching (from the router)
  wire [TAGW-1:0] r_tag = rin_data[R_TAG +: TAGW];
  wire [DOMW-1:0] r_dom = rin_data[R_DOM +: DOMW];
  wire [1:0]      r_op  = rin_data[R_OP +: 2];
  wire [2:0]      r_st  = rin_data[R_ST +: 3];
  wire [DW-1:0]   r_rd  = rin_data[R_RD +: DW];

  logic             r_hit;
  logic [SIW-1:0]   ridx;
  logic [DOMW-1:0]  x_dom;                // domain / opcode recorded in the matched slot
  logic [1:0]       x_op;
  logic             echo_bad;
  logic [2:0]       r_final;
  logic [DW-1:0]    r_rdfinal;
  always_comb begin
    r_hit = 1'b0;
    ridx  = '0;
    x_dom = '0;
    x_op  = '0;
    for (int i = MAXO - 1; i >= 0; i--)
      if (rin_valid && sv_q[i] && si_q[i] && !sd_q[i] &&
          stag_q[i*TAGW +: TAGW] == r_tag && stgt_q[i*TW +: TW] == rin_tgt) begin
        r_hit = 1'b1;
        ridx  = SIW'(i);
        x_dom = sdom_q[i*DOMW +: DOMW];     // constant slices: a variable-start part-select would be a barrel shifter
        x_op  = sop_q[i*2 +: 2];
      end
    echo_bad  = (r_dom != x_dom) || (r_op != x_op) || (r_st > ST_SLVERR);
    r_final   = echo_bad ? ST_PROTO : r_st;
    r_rdfinal = (r_final == ST_OKAY && x_op == sf_meridian_qos_pkg::OP_READ) ? r_rd : '0;
  end

  // ---------------------------------------------------------------- delivery
  logic [SIW-1:0]  didx, o_idx;
  logic            dsel_valid, ordq_ov, deliver, rq_ir;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [SIW-1:0]  dptr_q;                 // out-of-order delivery pointer (unused when OOO = 0)
  /* verilator lint_on UNUSEDSIGNAL */

  if (!OOO) begin : g_inorder
    sf_meridian_queue #(.W(SIW), .DEPTH(MAXO)) u_ordq (
      .clk, .rst_n,
      .in_valid (fire_alloc),
      .in_ready (),
      .in_data  (fidx),
      .out_valid(ordq_ov),
      .out_ready(deliver),
      .out_data (o_idx),
      .count    ());
    assign didx       = o_idx;
    assign dsel_valid = ordq_ov && sd_q[o_idx];
  end else begin : g_ooo
    logic            any;
    logic [SIW-1:0]  pick;
    logic [MAXO-1:0] cand_d;
    assign o_idx   = '0;
    assign ordq_ov = 1'b0;
    always_comb begin
      cand_d = sv_q & sd_q;
      any    = 1'b0;
      pick   = '0;
      for (int d = MAXO - 1; d >= 0; d--) begin
        int ii;
        ii = (32'(dptr_q) + d) % MAXO;
        if (cand_d[ii]) begin any = 1'b1; pick = SIW'(ii); end
      end
    end
    assign didx       = pick;
    assign dsel_valid = any;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) dptr_q <= '0;
      else if (deliver) dptr_q <= (didx == SIW'(MAXO - 1)) ? '0 : didx + SIW'(1);
    end
  end
  if (!OOO) begin : g_noptr
    assign dptr_q = '0;
  end

  assign deliver = dsel_valid && rq_ir;

  logic [TAGW-1:0]  d_tag;
  logic [DOMW-1:0]  d_dom;
  logic [1:0]       d_op, d_cls;
  logic [2:0]       d_st;
  logic [DW-1:0]    d_rd;
  logic [LATW-1:0]  d_ts;
  always_comb begin                       // delivered slot, selected with constant slices (see above)
    d_tag = '0; d_dom = '0; d_op = '0; d_cls = '0; d_st = '0; d_rd = '0; d_ts = '0;
    for (int i = 0; i < MAXO; i++)
      if (didx == SIW'(i)) begin
        d_tag = stag_q[i*TAGW +: TAGW];
        d_dom = sdom_q[i*DOMW +: DOMW];
        d_op  = sop_q[i*2 +: 2];
        d_cls = scls_q[i*2 +: 2];
        d_st  = sst_q[i*3 +: 3];
        d_rd  = srd_q[i*DW +: DW];
        d_ts  = sts_q[i*LATW +: LATW];
      end
  end
  wire [MRW-1:0] rq_in = {d_tag, d_dom, d_op, d_st, d_rd};
  sf_meridian_queue #(.W(MRW), .DEPTH(RQ_DEPTH)) u_rq (
    .clk, .rst_n,
    .in_valid (deliver),
    .in_ready (rq_ir),
    .in_data  (rq_in),
    .out_valid(rsp_valid),
    .out_ready(rsp_ready),
    .out_data (rsp_data),
    .count    ());

  assign ev_cpl     = deliver;
  assign ev_cpl_st  = d_st;
  assign ev_cpl_cls = d_cls;
  assign ev_cpl_lat = cyc - d_ts;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ncls_v <= '0;
      nout   <= '0;
    end else begin
      for (int k = 0; k < 4; k++) begin
        if ((fire_alloc && cls_eff == 2'(k)) && !(deliver && d_cls == 2'(k)))
          ncls_v[k*OCW +: OCW] <= ncls_v[k*OCW +: OCW] + OCW'(1);
        else if (!(fire_alloc && cls_eff == 2'(k)) && (deliver && d_cls == 2'(k)))
          ncls_v[k*OCW +: OCW] <= ncls_v[k*OCW +: OCW] - OCW'(1);
      end
      if (fire_alloc && !deliver)      nout <= nout + OCW'(1);
      else if (!fire_alloc && deliver) nout <= nout - OCW'(1);
    end
  end

  // ---------------------------------------------------------------- slot table update
  // One iteration per slot with a constant index: the write enables are decoded comparators and the data is a plain
  // multiplexer-free register bank (a variable-start part-select write would synthesise to a barrel shifter per field).
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sv_q <= '0; si_q <= '0; sd_q <= '0;
    end else begin
      for (int i = 0; i < MAXO; i++) begin
        if (fire_alloc && fidx == SIW'(i)) begin
          sv_q[i] <= 1'b1;
          sd_q[i] <= fire_err;
          si_q[i] <= (GUARD_EN == 0) && fire_good;
        end
        if (v_pop && gq_sidx == SIW'(i)) begin
          if (grd_rsp_ok) si_q[i] <= 1'b1;
          else            sd_q[i] <= 1'b1;
        end
        if (r_hit && ridx == SIW'(i)) sd_q[i] <= 1'b1;
        if (deliver && didx == SIW'(i)) begin
          sv_q[i] <= 1'b0;
          si_q[i] <= 1'b0;
          sd_q[i] <= 1'b0;
        end
      end
    end
  end

  always_ff @(posedge clk) begin
    for (int i = 0; i < MAXO; i++) begin
      if (fire_alloc && fidx == SIW'(i)) begin
        stag_q[i*TAGW +: TAGW]   <= s_tag;
        sop_q[i*2 +: 2]          <= s_op;
        sdom_q[i*DOMW +: DOMW]   <= s_dom;
        stgt_q[i*TW +: TW]       <= fire_err ? '0 : dec_tgt;
        scls_q[i*2 +: 2]         <= cls_eff;
        sts_q[i*LATW +: LATW]    <= s_ts;
        sst_q[i*3 +: 3]          <= fire_err ? err_status : ST_OKAY;
        srd_q[i*DW +: DW]        <= '0;
      end
      if (v_pop && !grd_rsp_ok && gq_sidx == SIW'(i)) begin
        sst_q[i*3 +: 3]          <= ST_DENIED;
        srd_q[i*DW +: DW]        <= '0;
      end
      if (r_hit && ridx == SIW'(i)) begin
        sst_q[i*3 +: 3]          <= r_final;
        srd_q[i*DW +: DW]        <= r_rdfinal;
      end
    end
  end

  // ---------------------------------------------------------------- violations, error classification, error log
  always_comb begin
    ev_viol = '0;
    if (fire_err && bad_op)                          ev_viol[sf_meridian_qos_pkg::V_BADOP]    = 1'b1;
    if (fire_err && !bad_op && dec_misal)            ev_viol[sf_meridian_qos_pkg::V_MISALIGN] = 1'b1;
    if (fire_err && !bad_op && !dec_misal && spoof)  ev_viol[sf_meridian_qos_pkg::V_SPOOF]    = 1'b1;
    if (fire_drop)                                   ev_viol[sf_meridian_qos_pkg::V_TAGREUSE] = 1'b1;
    if (rin_valid && !r_hit)                         ev_viol[sf_meridian_qos_pkg::V_ORPHAN]   = 1'b1;
    if (r_hit && echo_bad)                           ev_viol[sf_meridian_qos_pkg::V_ECHO]     = 1'b1;
    if (v_spurious)                                  ev_viol[sf_meridian_qos_pkg::V_GRD]      = 1'b1;
  end

  wire v_deny = v_pop && !grd_rsp_ok;
  assign ev_denied = v_deny || (fire_err && err_status == ST_DENIED);
  assign ev_decerr = fire_err && err_status == ST_DECERR;

  // first-fault candidates, in this priority: guard denial (oldest), response echo violation, local error
  always_comb begin
    elog_set    = 1'b0;
    elog_status = '0;
    elog_fault  = '0;
    elog_tag    = '0;
    elog_dom    = '0;
    elog_addr   = '0;
    if (v_deny) begin
      elog_set    = 1'b1;
      elog_status = ST_DENIED;
      elog_fault  = (grd_rsp_fault == 4'd0) ? sf_meridian_qos_pkg::F_NOMAP : grd_rsp_fault;
      elog_tag    = gq_xw[O_TAG +: TAGW];
      elog_dom    = gq_xw[O_DOM +: DOMW];
      elog_addr   = gq_xw[O_ADDR +: AW];
    end else if (r_hit && echo_bad) begin
      elog_set    = 1'b1;
      elog_status = ST_PROTO;
      elog_fault  = sf_meridian_qos_pkg::F_ECHO;
      elog_tag    = r_tag;
      elog_dom    = x_dom;
      elog_addr   = '0;
    end else if (fire_err) begin
      elog_set    = 1'b1;
      elog_status = err_status;
      elog_fault  = err_fault;
      elog_tag    = s_tag;
      elog_dom    = s_dom;
      elog_addr   = s_addr;
    end
  end
endmodule

`default_nettype wire
