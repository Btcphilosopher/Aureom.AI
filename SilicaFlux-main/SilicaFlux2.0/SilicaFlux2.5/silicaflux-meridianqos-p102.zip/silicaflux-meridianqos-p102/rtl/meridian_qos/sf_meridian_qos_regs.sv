// =============================================================================
// SilicaFlux -- Project 102 -- MeridianQoS :: sf_meridian_qos_regs
//
// Privileged configuration / status register block of the interconnect (map: sf_meridian_qos_pkg section 4,
// docs/meridian_qos/04_REGISTERS.md).  One access per cycle on a simple request / registered-response port:
//   cfg_valid, cfg_write, cfg_addr (word address), cfg_wdata, cfg_priv  ->  next cycle: cfg_rvalid, cfg_rdata, cfg_err
// `cfg_priv` must come from authenticated management hardware (Keystone's privileged path); like `priv` on the
// transaction port, the fabric treats it as a trusted input -- it cannot authenticate it.
//
// Rules (each one is a tested behaviour, tests/meridian_qos):
//   * Every register except ID and VERSION requires cfg_priv for reads AND writes (performance counters and the
//     error log leak the activity of other domains).  An unprivileged access changes nothing, returns 0 data,
//     cfg_err = 1, increments SECCNT and sets STATUS.SEC.
//   * CTRL.lock is write-once-per-reset (set only).  While locked, the scheduling configuration (CTRL policy /
//     cong_en, WEIGHTS, STARVE, TCMAP, FLOOR, OUTLIM, CONG) rejects writes (cfg_err = 1, SECCNT++).
//     PERF_SEL, PERF_CTRL, STATUS and ELOG_CTRL stay writable: they do not change the scheduling.
//   * Illegal values are rejected, not truncated: policy 3 (reserved), policy 2 with STRICT_EN = 0, CONG with lo > hi.
//   * Weights and limits of 0 are accepted and read back as written; the hardware treats a 0 weight / 0 limit as 1,
//     so no class can be switched off (or starved) through these registers.
// =============================================================================
`default_nettype none

module sf_meridian_qos_regs #(
  parameter int                NM          = 2,
  parameter int                NT          = 2,
  parameter int                STRICT_EN   = 1,
  parameter int                NCNT        = 16,
  parameter logic [1:0]        DEF_POLICY  = 2'd1,
  parameter logic [31:0]       DEF_WEIGHTS = {8'd1, 8'd2, 8'd4, 8'd8},    // class 3 .. class 0
  parameter logic [7:0]        DEF_STARVE  = 8'd16,
  parameter logic [15:0]       DEF_TCMAP   = sf_meridian_qos_pkg::TCMAP_DEFAULT,
  parameter logic [31:0]       DEF_FLOOR   = 32'd0,                       // 2 bits per master
  parameter logic [31:0]       DEF_OUTLIM  = 32'hFFFF_FFFF,
  parameter logic [17:0]       DEF_CONG    = {2'd2, 8'd2, 8'd6},          // thr class 2, lo 2, hi 6
  parameter logic              DEF_CONG_EN = 1'b0,
  localparam int               RSW         = sf_meridian_qos_pkg::clog2c(NCNT)
) (
  input  logic                 clk,
  input  logic                 rst_n,
  // ---- register port
  input  logic                 cfg_valid,
  input  logic                 cfg_write,
  input  logic [5:0]           cfg_addr,
  input  logic [31:0]          cfg_wdata,
  input  logic                 cfg_priv,
  output logic                 cfg_rvalid,
  output logic [31:0]          cfg_rdata,
  output logic                 cfg_err,
  // ---- configuration outputs
  output logic [1:0]           o_policy,
  output logic [31:0]          o_weights,
  output logic [7:0]           o_starve,
  output logic [15:0]          o_tcmap,
  output logic [31:0]          o_floor,
  output logic [31:0]          o_outlim,
  output logic                 o_cong_en,
  output logic [7:0]           o_cong_hi,
  output logic [7:0]           o_cong_lo,
  output logic [1:0]           o_cong_thr,
  output logic                 o_lock,
  // ---- performance counter window
  output logic                 o_perf_clear,
  output logic [RSW-1:0]       o_perf_sel,
  input  logic [31:0]          perf_data,
  // ---- status inputs (one-cycle pulses)
  input  logic                 ev_viol,
  input  logic                 ev_denied,
  input  logic                 ev_decerr,
  output logic                 o_sec_evt,
  // ---- first-error log capture (pulse + fields)
  input  logic                 elog_set,
  input  logic [7:0]           elog_src,
  input  logic [2:0]           elog_status,
  input  logic [3:0]           elog_fault,
  input  logic [7:0]           elog_tag,
  input  logic [7:0]           elog_dom,
  input  logic [31:0]          elog_addr
);
  localparam logic [5:0] A_ID = 6'(sf_meridian_qos_pkg::R_ID),            A_VERSION = 6'(sf_meridian_qos_pkg::R_VERSION),
                         A_CTRL = 6'(sf_meridian_qos_pkg::R_CTRL),        A_WEIGHTS = 6'(sf_meridian_qos_pkg::R_WEIGHTS),
                         A_STARVE = 6'(sf_meridian_qos_pkg::R_STARVE),    A_TCMAP = 6'(sf_meridian_qos_pkg::R_TCMAP),
                         A_FLOOR = 6'(sf_meridian_qos_pkg::R_FLOOR),      A_OUTLIM = 6'(sf_meridian_qos_pkg::R_OUTLIM),
                         A_CONG = 6'(sf_meridian_qos_pkg::R_CONG),        A_PSEL = 6'(sf_meridian_qos_pkg::R_PERF_SEL),
                         A_PDATA = 6'(sf_meridian_qos_pkg::R_PERF_DATA),  A_PCTRL = 6'(sf_meridian_qos_pkg::R_PERF_CTRL),
                         A_STATUS = 6'(sf_meridian_qos_pkg::R_STATUS),    A_EL0 = 6'(sf_meridian_qos_pkg::R_ELOG0),
                         A_EL1 = 6'(sf_meridian_qos_pkg::R_ELOG1),        A_ELC = 6'(sf_meridian_qos_pkg::R_ELOG_CTRL),
                         A_SEC = 6'(sf_meridian_qos_pkg::R_SECCNT),       A_NCNT = 6'(sf_meridian_qos_pkg::R_NCNT);

  logic [1:0]   policy_q;
  logic [31:0]  weights_q, floor_q, outlim_q;
  logic [7:0]   starve_q, cong_hi_q, cong_lo_q;
  logic [15:0]  tcmap_q;
  logic [1:0]   cong_thr_q;
  logic         cong_en_q, lock_q;
  logic [RSW-1:0] psel_q;
  logic         pclr_q;
  logic [3:0]   stat_q;
  logic [31:0]  seccnt_q;
  logic         el_valid_q;
  logic [7:0]   el_src_q, el_tag_q, el_dom_q;
  logic [2:0]   el_st_q;
  logic [3:0]   el_flt_q;
  logic [31:0]  el_addr_q;

  assign o_policy     = policy_q;
  assign o_weights    = weights_q;
  assign o_starve     = starve_q;
  assign o_tcmap      = tcmap_q;
  assign o_floor      = floor_q;
  assign o_outlim     = outlim_q;
  assign o_cong_en    = cong_en_q;
  assign o_cong_hi    = cong_hi_q;
  assign o_cong_lo    = cong_lo_q;
  assign o_cong_thr   = cong_thr_q;
  assign o_lock       = lock_q;
  assign o_perf_clear = pclr_q;
  assign o_perf_sel   = psel_q;

  // ---------------------------------------------------------------- access decode (combinational)
  logic        is_cfg;        // scheduling-configuration register (locked by CTRL.lock)
  logic        known, ro, public_reg;
  logic        legal_val;
  logic        reject, accept_wr;
  logic [31:0] rd_mux;

  always_comb begin
    is_cfg     = (cfg_addr == A_CTRL) || (cfg_addr == A_WEIGHTS) || (cfg_addr == A_STARVE) || (cfg_addr == A_TCMAP) ||
                 (cfg_addr == A_FLOOR) || (cfg_addr == A_OUTLIM) || (cfg_addr == A_CONG);
    known      = is_cfg || (cfg_addr == A_ID) || (cfg_addr == A_VERSION) || (cfg_addr == A_PSEL) || (cfg_addr == A_PDATA) ||
                 (cfg_addr == A_PCTRL) || (cfg_addr == A_STATUS) || (cfg_addr == A_EL0) || (cfg_addr == A_EL1) ||
                 (cfg_addr == A_ELC) || (cfg_addr == A_SEC) || (cfg_addr == A_NCNT);
    ro         = (cfg_addr == A_ID) || (cfg_addr == A_VERSION) || (cfg_addr == A_PDATA) || (cfg_addr == A_EL0) ||
                 (cfg_addr == A_EL1) || (cfg_addr == A_SEC) || (cfg_addr == A_NCNT);
    public_reg = (cfg_addr == A_ID) || (cfg_addr == A_VERSION);

    // value legality of a write
    legal_val = 1'b1;
    if (cfg_addr == A_CTRL) begin
      if (cfg_wdata[1:0] == 2'd3) legal_val = 1'b0;                                   // reserved policy
      if (cfg_wdata[1:0] == sf_meridian_qos_pkg::POL_STRICT && STRICT_EN == 0) legal_val = 1'b0;
    end
    if (cfg_addr == A_CONG && cfg_wdata[15:8] > cfg_wdata[7:0]) legal_val = 1'b0;     // lo > hi
    if (cfg_addr == A_PSEL && cfg_wdata >= 32'(NCNT)) legal_val = 1'b0;               // no such counter

    // reject conditions
    reject = 1'b0;
    if (cfg_valid) begin
      if (!known)                                  reject = 1'b1;
      else if (!cfg_priv && !(public_reg && !cfg_write)) reject = 1'b1;               // unprivileged
      else if (cfg_write && ro)                    reject = 1'b1;
      else if (cfg_write && is_cfg && lock_q)      reject = 1'b1;                     // locked
      else if (cfg_write && !legal_val)            reject = 1'b1;
    end
    accept_wr = cfg_valid && cfg_write && !reject;

    // read multiplexer
    rd_mux = 32'd0;
    case (cfg_addr)
      A_ID:      rd_mux = {sf_meridian_qos_pkg::ID_MAGIC, 8'(NM), 8'(NT)};
      A_VERSION: rd_mux = sf_meridian_qos_pkg::VERSION;
      A_CTRL:    rd_mux = {lock_q, 26'd0, cong_en_q, 2'd0, policy_q};
      A_WEIGHTS: rd_mux = weights_q;
      A_STARVE:  rd_mux = {24'd0, starve_q};
      A_TCMAP:   rd_mux = {16'd0, tcmap_q};
      A_FLOOR:   rd_mux = floor_q;
      A_OUTLIM:  rd_mux = outlim_q;
      A_CONG:    rd_mux = {14'd0, cong_thr_q, cong_lo_q, cong_hi_q};
      A_PSEL:    rd_mux = 32'(psel_q);
      A_PDATA:   rd_mux = perf_data;
      A_STATUS:  rd_mux = {27'd0, el_valid_q, stat_q};   // bit 4 mirrors "error log holds a record"
      A_EL0:     rd_mux = {el_valid_q, el_st_q, el_flt_q, el_src_q, el_tag_q, el_dom_q};
      A_EL1:     rd_mux = el_addr_q;
      A_SEC:     rd_mux = seccnt_q;
      A_NCNT:    rd_mux = 32'(NCNT);
      default:   rd_mux = 32'd0;
    endcase
  end

  assign o_sec_evt = cfg_valid && reject;

  // ---------------------------------------------------------------- state
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      policy_q   <= DEF_POLICY;
      weights_q  <= DEF_WEIGHTS;
      starve_q   <= DEF_STARVE;
      tcmap_q    <= DEF_TCMAP;
      floor_q    <= DEF_FLOOR;
      outlim_q   <= DEF_OUTLIM;
      cong_hi_q  <= DEF_CONG[7:0];
      cong_lo_q  <= DEF_CONG[15:8];
      cong_thr_q <= DEF_CONG[17:16];
      cong_en_q  <= DEF_CONG_EN;
      lock_q     <= 1'b0;
      psel_q     <= '0;
      pclr_q     <= 1'b0;
      stat_q     <= '0;
      seccnt_q   <= '0;
      el_valid_q <= 1'b0;
      el_src_q   <= '0; el_tag_q <= '0; el_dom_q <= '0; el_st_q <= '0; el_flt_q <= '0; el_addr_q <= '0;
      cfg_rvalid <= 1'b0;
      cfg_rdata  <= '0;
      cfg_err    <= 1'b0;
    end else begin
      pclr_q     <= 1'b0;
      // response register
      cfg_rvalid <= cfg_valid;
      cfg_err    <= cfg_valid && reject;
      cfg_rdata  <= (cfg_valid && !cfg_write && !reject) ? rd_mux : 32'd0;

      // sticky status: events set, W1C clears (a set in the same cycle wins)
      if (accept_wr && cfg_addr == A_STATUS) stat_q <= stat_q & ~cfg_wdata[3:0];
      if (reject)    stat_q[sf_meridian_qos_pkg::STAT_SEC]    <= 1'b1;
      if (ev_viol)   stat_q[sf_meridian_qos_pkg::STAT_VIOL]   <= 1'b1;
      if (ev_denied) stat_q[sf_meridian_qos_pkg::STAT_DENIED] <= 1'b1;
      if (ev_decerr) stat_q[sf_meridian_qos_pkg::STAT_DECERR] <= 1'b1;

      if (reject) seccnt_q <= seccnt_q + 32'd1;

      // writes
      if (accept_wr) begin
        case (cfg_addr)
          A_CTRL: begin
            policy_q  <= cfg_wdata[1:0];
            cong_en_q <= cfg_wdata[sf_meridian_qos_pkg::CTRL_CONG_EN];
            if (cfg_wdata[sf_meridian_qos_pkg::CTRL_LOCK]) lock_q <= 1'b1;          // set only
          end
          A_WEIGHTS: weights_q  <= cfg_wdata;
          A_STARVE:  starve_q   <= cfg_wdata[7:0];
          A_TCMAP:   tcmap_q    <= cfg_wdata[15:0];
          A_FLOOR:   floor_q    <= cfg_wdata;
          A_OUTLIM:  outlim_q   <= cfg_wdata;
          A_CONG: begin
            cong_hi_q  <= cfg_wdata[7:0];
            cong_lo_q  <= cfg_wdata[15:8];
            cong_thr_q <= cfg_wdata[17:16];
          end
          A_PSEL:    psel_q <= cfg_wdata[RSW-1:0];
          A_PCTRL:   pclr_q <= cfg_wdata[0];
          default: ;
        endcase
      end

      // first-error log: captures the first fault after reset / clear; later faults are counted by perf only
      if (accept_wr && cfg_addr == A_ELC && cfg_wdata[0]) begin
        el_valid_q <= 1'b0;
      end else if (elog_set && !el_valid_q) begin
        el_valid_q <= 1'b1;
        el_src_q   <= elog_src;
        el_st_q    <= elog_status;
        el_flt_q   <= elog_fault;
        el_tag_q   <= elog_tag;
        el_dom_q   <= elog_dom;
        el_addr_q  <= elog_addr;
      end
    end
  end
endmodule

`default_nettype wire
