// =============================================================================
// SilicaFlux -- Project 102 -- MeridianQoS :: sf_meridian_decoder
//
// Destination decode of one master port.  Target t is selected when (addr & TGT_MASK[t]) == TGT_BASE[t] (the
// base / mask window rule of DataFabric's sfb_addr_decoder and of Project 83; windows must not overlap -- if they
// do, the lowest target index wins).  `reach` additionally requires the topology bit CONN[t] of this master: an
// address can decode while no physical path exists from this master (sparse / segmented crossbar); that is
// reported as F_NOROUTE (ST_DECERR), distinct from an unmapped address (F_UNMAPPED, ST_DECERR).
// `misaligned`: addr[OFF-1:0] != 0 with OFF = log2(DW/8): the target interface is beat based.
// Purely combinational.  Invariant: `reach` => `hit` and tgt < NT, so an illegal destination is never selected
// (formal property P-DEST, formal/meridian_qos/fv_decoder.sv).
// =============================================================================
`default_nettype none

module sf_meridian_decoder #(
  parameter int               NT          = 2,
  parameter int               AW          = 32,
  parameter int               DW          = 64,
  parameter int               CHECK_ALIGN = 1,
  parameter logic [NT*AW-1:0] TGT_BASE    = {(NT*AW){1'b0}},
  parameter logic [NT*AW-1:0] TGT_MASK    = {(NT*AW){1'b0}},
  parameter logic [NT-1:0]    CONN        = {NT{1'b1}},
  localparam int              TW          = sf_meridian_qos_pkg::clog2c(NT),
  localparam int              OFF         = (DW > 8) ? $clog2(DW / 8) : 1
) (
  input  logic [AW-1:0] addr,
  output logic          hit,         // some window matches
  output logic [TW-1:0] tgt,         // lowest matching target (valid when hit)
  output logic          reach,       // hit and this master is connected to tgt
  output logic          misaligned
);
  always_comb begin
    hit = 1'b0;
    tgt = '0;
    for (int t = NT - 1; t >= 0; t--) begin
      if ((addr & TGT_MASK[t*AW +: AW]) == TGT_BASE[t*AW +: AW]) begin
        hit = 1'b1;
        tgt = TW'(t);
      end
    end
    reach      = hit && CONN[tgt];
    misaligned = (CHECK_ALIGN != 0) && (DW > 8) && (addr[OFF-1:0] != '0);
  end
endmodule

`default_nettype wire
