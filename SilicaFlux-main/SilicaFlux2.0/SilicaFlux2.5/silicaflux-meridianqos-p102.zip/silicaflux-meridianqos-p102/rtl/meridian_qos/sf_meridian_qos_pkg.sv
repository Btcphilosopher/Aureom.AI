// =============================================================================
// SilicaFlux -- Project 102 -- MeridianQoS :: sf_meridian_qos_pkg
//
// Constants of MeridianQoS.
//
//  * Section 1 (ABI) is the transaction contract of Project 83 (the Albion transaction format as carried by
//    Meridian, which extends SFB3 of Project 22).  The numeric values are IDENTICAL to sf_meridian_pkg of
//    Project 83; tests/meridian_qos/tb/tb_abi_check.sv compiles both packages together and fails if any shared
//    constant differs.  Project 102 does not define a second bus protocol.
//  * Sections 2.. are new: the four scheduling classes, the arbitration policies, the performance-counter map
//    and the privileged-register map of MeridianQoS.
//
// Tool rules (same as Projects 22 / 83, so Verilator and Yosys elaborate the RTL identically): localparams and
// "assign to the function name" functions only -- no structs, typedefs or `return`.
// =============================================================================
package sf_meridian_qos_pkg;
  /* verilator lint_off UNUSEDPARAM */

  // ============================================================ 1. ABI (identical to Project 83)
  localparam int          OPW      = 2;
  localparam logic [1:0]  OP_READ  = 2'd0;
  localparam logic [1:0]  OP_WRITE = 2'd1;

  localparam int          STW        = 3;
  localparam logic [2:0]  ST_OKAY    = 3'd0;
  localparam logic [2:0]  ST_SLVERR  = 3'd1;
  localparam logic [2:0]  ST_DECERR  = 3'd2;
  localparam logic [2:0]  ST_DENIED  = 3'd3;
  localparam logic [2:0]  ST_TIMEOUT = 3'd4;   // part of the ABI; NOT produced by MeridianQoS (no timeout machinery)
  localparam logic [2:0]  ST_PROTO   = 3'd5;

  localparam int          FW           = 4;
  localparam logic [3:0]  F_NONE       = 4'd0;
  localparam logic [3:0]  F_NOMAP      = 4'd1;
  localparam logic [3:0]  F_PERM       = 4'd2;
  localparam logic [3:0]  F_DOMAIN     = 4'd3;
  localparam logic [3:0]  F_PRIV       = 4'd4;
  localparam logic [3:0]  F_SPOOF      = 4'd5;
  localparam logic [3:0]  F_CITTMO     = 4'd6;   // unused here (the guard contract has no timeout, see docs)
  localparam logic [3:0]  F_UNMAPPED   = 4'd8;
  localparam logic [3:0]  F_NOROUTE    = 4'd9;
  localparam logic [3:0]  F_MISALIGN   = 4'd10;
  localparam logic [3:0]  F_BADOP      = 4'd11;
  localparam logic [3:0]  F_ISO        = 4'd12;  // unused here
  localparam logic [3:0]  F_HOL        = 4'd13;  // unused here
  localparam logic [3:0]  F_RSPTMO     = 4'd14;  // unused here
  localparam logic [3:0]  F_ECHO       = 4'd15;

  // protocol-violation events (V_*), same indices as Project 83; V_GRD is new
  localparam int          VW           = 9;
  localparam int          V_BADOP      = 0;
  localparam int          V_MISALIGN   = 1;
  localparam int          V_TAGREUSE   = 2;
  localparam int          V_ORPHAN     = 3;
  localparam int          V_ECHO       = 4;
  localparam int          V_BADSRC     = 5;
  localparam int          V_SPOOF      = 6;
  localparam int          V_LATE       = 7;      // reserved (no late responses without timeouts)
  localparam int          V_GRD        = 8;      // NEW: guard verdict with no query outstanding (ignored)

  // Project 83 traffic-class field `tc` (3 bit on the wire, unchanged by this project); larger = more urgent
  localparam int          TCW           = 3;
  localparam logic [2:0]  TC_BACKGROUND = 3'd0;
  localparam logic [2:0]  TC_BULK       = 3'd1;
  localparam logic [2:0]  TC_COMPUTE    = 3'd2;
  localparam logic [2:0]  TC_IO         = 3'd3;
  localparam logic [2:0]  TC_MGMT       = 3'd4;

  // ============================================================ 2. MeridianQoS scheduling classes
  // NOTE the direction: class NUMBER 0 is the MOST urgent (the brief's CLASS_0 = management/control).  The wire
  // field `tc` is the other way round (larger = more urgent); the mapping tc -> class is a privileged register.
  localparam int          CLSW    = 2;
  localparam int          NCLS    = 4;
  localparam logic [1:0]  CLASS_0 = 2'd0;   // management and control
  localparam logic [1:0]  CLASS_1 = 2'd1;   // latency-sensitive I/O
  localparam logic [1:0]  CLASS_2 = 2'd2;   // bulk DMA and memory traffic
  localparam logic [1:0]  CLASS_3 = 2'd3;   // background compute / data movement

  // default tc -> class map, 2 bits per tc (bit 2*tc +: 2).  tc 4..7 -> CLASS_0, 3 -> 1, 2 -> 2, 1 -> 2, 0 -> 3.
  localparam logic [15:0] TCMAP_DEFAULT = {2'd0, 2'd0, 2'd0, 2'd0, 2'd1, 2'd2, 2'd2, 2'd3};

  // ============================================================ 3. arbitration policies
  localparam int          POLW       = 2;
  localparam logic [1:0]  POL_RR     = 2'd0;   // plain round robin over masters, classes ignored
  localparam logic [1:0]  POL_WRR    = 2'd1;   // weighted round robin over classes, round robin inside a class
  localparam logic [1:0]  POL_STRICT = 2'd2;   // strict class priority + optional aging (starvation limit)
                                               // 3 is reserved and behaves as POL_RR

  // ============================================================ 4. privileged register map (word offsets, byte = *4)
  localparam int          REG_AW        = 6;      // word address bits
  localparam int          R_ID          = 0;      // RO    magic | NM | NT
  localparam int          R_VERSION     = 1;      // RO
  localparam int          R_CTRL        = 2;      // RW    [1:0] policy, [4] cong_en, [31] lock (set only)
  localparam int          R_WEIGHTS     = 3;      // RW    4 x 8 bit class weights (0 reads back, behaves as 1)
  localparam int          R_STARVE      = 4;      // RW    [7:0] strict-priority aging limit, 0 = off
  localparam int          R_TCMAP       = 5;      // RW    [15:0] tc -> class
  localparam int          R_FLOOR       = 6;      // RW    2 bits per master: most urgent class the master may use
  localparam int          R_OUTLIM      = 7;      // RW    4 x 8 bit per-class outstanding limit (0 behaves as 1)
  localparam int          R_CONG        = 8;      // RW    [7:0] hi, [15:8] lo, [17:16] throttle class
  localparam int          R_PERF_SEL    = 9;      // RW    counter index
  localparam int          R_PERF_DATA   = 10;     // RO    selected counter
  localparam int          R_PERF_CTRL   = 11;     // WO    [0] clear all counters (pulse)
  localparam int          R_STATUS      = 12;     // RW1C  sticky event flags
  localparam int          R_ELOG0       = 13;     // RO    first-error log word 0
  localparam int          R_ELOG1       = 14;     // RO    first-error log word 1 (address)
  localparam int          R_ELOG_CTRL   = 15;     // WO    [0] clear the error log
  localparam int          R_SECCNT      = 16;     // RO    count of rejected (unprivileged) accesses
  localparam int          R_NCNT        = 17;     // RO    number of performance counters

  localparam int          CTRL_POL_LSB  = 0;
  localparam int          CTRL_CONG_EN  = 4;
  localparam int          CTRL_LOCK     = 31;

  localparam int          STAT_SEC      = 0;      // an unprivileged / locked / illegal register access was rejected
  localparam int          STAT_VIOL     = 1;      // any protocol violation occurred
  localparam int          STAT_DENIED   = 2;      // a request was denied (spoof or guard)
  localparam int          STAT_DECERR   = 3;      // a request did not decode / had no route
  localparam int          STAT_ELOG     = 4;      // error log holds a record (mirror)

  localparam logic [15:0] ID_MAGIC      = 16'h4D51;   // "MQ"
  localparam logic [31:0] VERSION       = 32'h0001_0000;

  // ============================================================ 5. performance-counter map (sf_meridian_perf)
  // One flat bank read through R_PERF_SEL / R_PERF_DATA.  Blocks: global | per master | per class | per target | matrix.
  localparam int PF_G   = 16;
  localparam int PF_PM  = 20;
  localparam int PF_PC  = 8;
  localparam int PF_PT  = 14;
  // global
  localparam int PFG_CYCLES = 0, PFG_ACC = 1, PFG_FIRE = 2, PFG_CPL = 3, PFG_CPLERR = 4, PFG_BYTES_WR = 5,
                 PFG_BYTES_RD = 6, PFG_XFER = 7, PFG_ARBSTALL = 8, PFG_CONTEND = 9, PFG_BP = 10,
                 PFG_HELD_ADM = 11, PFG_HELD_CONG = 12, PFG_DEMOTE = 13, PFG_VIOL = 14, PFG_SEC = 15;
  // per master
  localparam int PFM_ACC = 0, PFM_CPL = 1, PFM_ERR = 2, PFM_DECERR = 3, PFM_DENIED = 4, PFM_PROTO = 5,
                 PFM_SLVERR = 6, PFM_BYTES_WR = 7, PFM_BYTES_RD = 8, PFM_LAT_SUM = 9, PFM_LAT_CNT = 10,
                 PFM_LAT_MAX = 11, PFM_OUT_SUM = 12, PFM_OUT_MAX = 13, PFM_IQ_SUM = 14, PFM_IQ_MAX = 15,
                 PFM_STALL_IN = 16, PFM_HELD_ADM = 17, PFM_HELD_CONG = 18, PFM_VIOL = 19;
  // per class
  localparam int PFC_FIRE = 0, PFC_CPL = 1, PFC_LAT_SUM = 2, PFC_LAT_CNT = 3, PFC_LAT_MAX = 4, PFC_GRANTS = 5,
                 PFC_ARBSTALL = 6, PFC_DEMOTE = 7;
  // per target
  localparam int PFT_XFER = 0, PFT_BYTES = 1, PFT_BUSY = 2, PFT_CONTEND = 3, PFT_ARBSTALL = 4, PFT_XQ_SUM = 5,
                 PFT_XQ_MAX = 6, PFT_EQ_SUM = 7, PFT_EQ_MAX = 8, PFT_BP = 9, PFT_BP_RUN = 10, PFT_CONG = 11,
                 PFT_RSP = 12, PFT_REQSUM = 13;

  function automatic integer pf_m(input integer m, input integer k);
    begin pf_m = PF_G + m * PF_PM + k; end
  endfunction
  function automatic integer pf_c(input integer nm, input integer c, input integer k);
    begin pf_c = PF_G + nm * PF_PM + c * PF_PC + k; end
  endfunction
  function automatic integer pf_t(input integer nm, input integer t, input integer k);
    begin pf_t = PF_G + nm * PF_PM + 4 * PF_PC + t * PF_PT + k; end
  endfunction
  function automatic integer pf_x(input integer nm, input integer nt, input integer m, input integer t);
    begin pf_x = PF_G + nm * PF_PM + 4 * PF_PC + nt * PF_PT + m * nt + t; end
  endfunction
  function automatic integer pf_n(input integer nm, input integer nt);
    begin pf_n = PF_G + nm * PF_PM + 4 * PF_PC + nt * PF_PT + nm * nt; end
  endfunction

  // ============================================================ helpers
  function automatic integer clog2c(input integer n);   // width of an index into n things (>= 1)
    begin
      if (n > 1) clog2c = $clog2(n);
      else       clog2c = 1;
    end
  endfunction

  function automatic integer imax(input integer a, input integer b);
    begin if (a > b) imax = a; else imax = b; end
  endfunction

  /* verilator lint_on UNUSEDPARAM */
endpackage
