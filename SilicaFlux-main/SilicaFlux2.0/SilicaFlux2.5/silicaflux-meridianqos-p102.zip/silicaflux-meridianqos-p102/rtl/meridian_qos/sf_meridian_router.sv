// =============================================================================
// SilicaFlux -- Project 102 -- MeridianQoS :: sf_meridian_router
//
// The crossbar proper.  Two INDEPENDENT paths (a request network and a response network share no resource):
//
//  request path   master port m --(push)--> XQ[m][t] (crosspoint queue, one per master/target pair, in-order)
//                 --> per-target sf_meridian_arbiter (policy, classes, aging) --> EQ[t] (registered egress queue)
//                 --> target t (through the target-side register slice in the top level).
//                 The crosspoint queues are the virtual output queues of the switch: a stalled target fills only its
//                 own column; traffic to other targets and from other masters keeps flowing.  Requests of one
//                 master to one target stay in issue order (one FIFO per pair).  The fabric STAMPS `src` here.
//  response path  target t --> TRQ[t] (registered response queue) --> routing by the `src` the fabric stamped,
//                 per-master round robin over the targets answering that master --> `rin_*` of master port src.
//                 A response whose src is out of range or unreachable from that target is consumed (sink) and
//                 counted (`ev_badsrc`), never delivered: it cannot block the response queue behind it.
//                 The master port accepts every `rin` in the cycle it is presented (it owns the slot that the
//                 transaction allocated at admission), so the response network never back-pressures and cannot
//                 deadlock on a slow master.
//
// No combinational valid/ready path crosses the router: every ready / valid of a channel boundary is a function
// of registered queue occupancy.  Combinational internals: queue heads -> arbiter -> payload mux -> egress push.
//
// Also here: the congestion flag per target (hysteresis on the occupancy of its crosspoint + egress queues),
// consumed by the master ports' admission control, and the per-target observability vectors for the counters.
// =============================================================================
`default_nettype none
/* verilator lint_off PINCONNECTEMPTY */

module sf_meridian_router #(
  parameter int                 NM        = 2,
  parameter int                 NT        = 2,
  parameter int                 AW        = 32,
  parameter int                 DW        = 64,
  parameter int                 TAGW      = 4,
  parameter int                 DOMW      = 3,
  parameter logic [NM*NT-1:0]   CONN      = {(NM*NT){1'b1}},
  parameter int                 XQ_DEPTH  = 4,
  parameter int                 EQ_DEPTH  = 2,
  parameter int                 TRQ_DEPTH = 2,
  parameter int                 STRICT_EN = 1,
  parameter int                 OCW       = 8,
  localparam int                SRCW      = sf_meridian_qos_pkg::clog2c(NM),
  localparam int                TW        = sf_meridian_qos_pkg::clog2c(NT),
  localparam int                RQW       = 2 + TAGW + DOMW + 1 + 3 + AW + DW + DW / 8,   // request word (the ABI fields)
  localparam int                XW        = RQW + 2,                                     // + internal class sideband
  localparam int                EW        = SRCW + RQW,                                  // egress word: {src, request}
  localparam int                MRW       = TAGW + DOMW + 2 + 3 + DW,                    // {tag, dom, op, status, rdata}
  localparam int                RW        = SRCW + MRW,                                  // target response: {src, ...}
  localparam int                XCW       = sf_meridian_qos_pkg::clog2c(XQ_DEPTH + 1),
  localparam int                ECW       = sf_meridian_qos_pkg::clog2c(EQ_DEPTH + 1),
  localparam int                BW        = sf_meridian_qos_pkg::clog2c(DW / 8 + 1)
) (
  input  logic                    clk,
  input  logic                    rst_n,
  // ---- request side from the master ports
  input  logic [NM*NT-1:0]        xq_push,        // [m*NT + t]
  input  logic [NM*XW-1:0]        xq_wdata,       // one word per master (the master port picks the target by xq_push)
  output logic [NM*NT*XCW-1:0]    xq_cnt,         // occupancy of every crosspoint queue (registered)
  // ---- egress to the targets (before the target-side slice)
  output logic [NT-1:0]           e_valid,
  input  logic [NT-1:0]           e_ready,
  output logic [NT*EW-1:0]        e_data,
  // ---- responses from the targets (after the target-side slice)
  input  logic [NT-1:0]           r_valid,
  output logic [NT-1:0]           r_ready,
  input  logic [NT*RW-1:0]        r_data,
  // ---- responses to the master ports (always accepted)
  output logic [NM-1:0]           rin_valid,
  output logic [NM*TW-1:0]        rin_tgt,
  output logic [NM*MRW-1:0]       rin_data,
  // ---- scheduling configuration
  input  logic [1:0]              cfg_policy,
  input  logic [31:0]             cfg_weight,
  input  logic [7:0]              cfg_starve,
  input  logic [7:0]              cfg_cong_hi,
  input  logic [7:0]              cfg_cong_lo,
  output logic [NT-1:0]           cong,
  // ---- observability
  output logic [NT-1:0]           p_xfer,
  output logic [NT*2-1:0]         p_xfer_cls,
  output logic [NT*BW-1:0]        p_xfer_bytes,
  output logic [NT*NM-1:0]        p_req,
  output logic [NT*NM*2-1:0]      p_cls,
  output logic [NT*OCW-1:0]       p_xq_occ,
  output logic [NT*OCW-1:0]       p_eq_occ,
  output logic [NT-1:0]           p_rsp,          // a response was taken from the target
  output logic [NT-1:0]           ev_badsrc,      // response consumed because its src is illegal
  output logic                    ev_ovf          // internal-consistency monitor: push into a full crosspoint queue
);
  // ---------------------------------------------------------------- crosspoint queues
  logic [NM*NT-1:0]      xq_ov, xq_ir;            // out_valid, in_ready
  logic [NM*NT*XW-1:0]   xq_od;                   // head data
  logic [NM*NT-1:0]      xq_or;                   // out_ready (from the arbiter)

  for (genvar m = 0; m < NM; m++) begin : g_m
    for (genvar t = 0; t < NT; t++) begin : g_t
      sf_meridian_queue #(.W(XW), .DEPTH(XQ_DEPTH)) u_xq (
        .clk, .rst_n,
        .in_valid (xq_push[m*NT + t]),
        .in_ready (xq_ir[m*NT + t]),
        .in_data  (xq_wdata[m*XW +: XW]),
        .out_valid(xq_ov[m*NT + t]),
        .out_ready(xq_or[m*NT + t]),
        .out_data (xq_od[(m*NT + t)*XW +: XW]),
        .count    (xq_cnt[(m*NT + t)*XCW +: XCW]));
    end
  end
  assign ev_ovf = |(xq_push & ~xq_ir);

  // ---------------------------------------------------------------- per-target arbitration and egress queue
  logic [NT-1:0]         eq_ir;                   // egress queue in_ready

  for (genvar t = 0; t < NT; t++) begin : g_tgt
    logic [NM-1:0]       a_req, a_grant;
    logic [NM*2-1:0]     a_cls;
    logic [SRCW-1:0]     a_gidx;
    logic                a_gvalid;
    logic [1:0]          a_gcls;
    /* verilator lint_off UNUSEDSIGNAL */
    logic [NM-1:0]       a_urg;       // observability only
    logic                a_reload;    // observability only
    /* verilator lint_on UNUSEDSIGNAL */
    /* verilator lint_off UNUSEDSIGNAL */
    logic [XW-1:0]       win;         // the class sideband (top 2 bits) is not forwarded
    /* verilator lint_on UNUSEDSIGNAL */
    logic [RQW-1:0]      win_req;

    always_comb begin
      for (int m = 0; m < NM; m++) begin
        a_req[m]        = xq_ov[m*NT + t];
        a_cls[m*2 +: 2] = xq_od[(m*NT + t)*XW + XW - 2 +: 2];
      end
    end

    sf_meridian_arbiter #(.N(NM), .STRICT_EN(STRICT_EN)) u_arb (
      .clk, .rst_n,
      .req(a_req), .cls(a_cls), .en(eq_ir[t]),
      .cfg_policy, .cfg_weight, .cfg_starve,
      .grant(a_grant), .gidx(a_gidx), .gvalid(a_gvalid), .gcls(a_gcls), .urgent(a_urg), .reload(a_reload));

    always_comb begin
      win = '0;
      for (int m = 0; m < NM; m++)
        if (a_grant[m]) win = xq_od[(m*NT + t)*XW +: XW];
      win_req = win[RQW-1:0];
      for (int m = 0; m < NM; m++)
        xq_or[m*NT + t] = a_grant[m] && eq_ir[t];
    end

    // egress queue: {src (stamped here), request}
    logic [ECW-1:0] ec;
    sf_meridian_queue #(.W(EW), .DEPTH(EQ_DEPTH)) u_eq (
      .clk, .rst_n,
      .in_valid (a_gvalid),
      .in_ready (eq_ir[t]),
      .in_data  ({a_gidx, win_req}),
      .out_valid(e_valid[t]),
      .out_ready(e_ready[t]),
      .out_data (e_data[t*EW +: EW]),
      .count    (ec));

    // observability
    logic [BW-1:0] wb;
    always_comb begin
      int n;
      n = 0;
      for (int k = 0; k < DW / 8; k++) if (win_req[k]) n++;
      // op is the top 2 bits of the request word: WRITE counts the enabled byte lanes, READ moves one full beat
      if (win_req[RQW-1 -: 2] == sf_meridian_qos_pkg::OP_WRITE) wb = BW'(n);
      else                                                      wb = BW'(DW / 8);
    end
    assign p_xfer[t]                   = a_gvalid && eq_ir[t];
    assign p_xfer_cls[t*2 +: 2]        = a_gcls;
    assign p_xfer_bytes[t*BW +: BW]    = wb;
    assign p_req[t*NM +: NM]           = a_req;
    assign p_cls[t*NM*2 +: NM*2]       = a_cls;

    // occupancy: crosspoint queues of this target + egress queue
    always_comb begin
      int s;
      s = 0;
      for (int m = 0; m < NM; m++) s += 32'(xq_cnt[(m*NT + t)*XCW +: XCW]);
      p_xq_occ[t*OCW +: OCW] = OCW'(s);
      p_eq_occ[t*OCW +: OCW] = OCW'(ec);
    end

    // congestion flag with hysteresis (set at >= hi, clear at <= lo)
    logic cong_q;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) cong_q <= 1'b0;
      else begin
        if (p_xq_occ[t*OCW +: OCW] + p_eq_occ[t*OCW +: OCW] >= OCW'(cfg_cong_hi)) cong_q <= 1'b1;
        else if (p_xq_occ[t*OCW +: OCW] + p_eq_occ[t*OCW +: OCW] <= OCW'(cfg_cong_lo)) cong_q <= 1'b0;
      end
    end
    assign cong[t] = cong_q;
  end

  // ---------------------------------------------------------------- response network
  logic [NT-1:0]       trq_ov, trq_or;
  logic [NT*RW-1:0]    trq_od;
  logic [NT-1:0]       sink;
  logic [NT*NM-1:0]    go;                         // [t*NM + m]: head of TRQ[t] is for master m and legal
  logic [NM*NT-1:0]    rgrant;                     // [m*NT + t]
  logic [NM*TW-1:0]    rptr_q;

  for (genvar t = 0; t < NT; t++) begin : g_trq
    logic [SRCW-1:0] hsrc;
    logic            legal;
    sf_meridian_queue #(.W(RW), .DEPTH(TRQ_DEPTH)) u_trq (
      .clk, .rst_n,
      .in_valid (r_valid[t]),
      .in_ready (r_ready[t]),
      .in_data  (r_data[t*RW +: RW]),
      .out_valid(trq_ov[t]),
      .out_ready(trq_or[t]),
      .out_data (trq_od[t*RW +: RW]),
      .count    ());
    assign hsrc  = trq_od[t*RW + MRW +: SRCW];
    always_comb begin
      legal = 1'b0;
      for (int m = 0; m < NM; m++) begin
        go[t*NM + m] = 1'b0;
        if (trq_ov[t] && hsrc == SRCW'(m) && CONN[m*NT + t]) begin
          go[t*NM + m] = 1'b1;
          legal        = 1'b1;
        end
      end
      sink[t] = trq_ov[t] && !legal;
    end
    assign ev_badsrc[t] = sink[t];
    assign p_rsp[t]     = r_valid[t] && r_ready[t];
  end

  // per master: round robin over the targets that have a response for it
  always_comb begin
    for (int m = 0; m < NM; m++) begin
      int  pick;
      logic any;
      pick = 0;
      any  = 1'b0;
      for (int d = NT - 1; d >= 0; d--) begin
        int tt;
        tt = (32'(rptr_q[m*TW +: TW]) + d) % NT;
        if (go[tt*NM + m]) begin pick = tt; any = 1'b1; end
      end
      rin_valid[m]        = any;
      rin_tgt[m*TW +: TW] = TW'(pick);
      rin_data[m*MRW +: MRW] = '0;
      for (int tt = 0; tt < NT; tt++)
        if (any && pick == tt) rin_data[m*MRW +: MRW] = trq_od[tt*RW +: MRW];     // constant slices: no barrel shifter
      for (int t = 0; t < NT; t++) rgrant[m*NT + t] = any && (pick == t);
    end
    for (int t = 0; t < NT; t++) begin
      logic g;
      g = 1'b0;
      for (int m = 0; m < NM; m++) g = g | rgrant[m*NT + t];
      trq_or[t] = g | sink[t];
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) rptr_q <= '0;
    else
      for (int m = 0; m < NM; m++)
        if (rin_valid[m]) rptr_q[m*TW +: TW] <= (rin_tgt[m*TW +: TW] == TW'(NT - 1)) ? '0 : rin_tgt[m*TW +: TW] + TW'(1);
  end
endmodule

`default_nettype wire
