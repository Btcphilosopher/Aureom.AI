// =============================================================================
// SilicaFlux -- Project 102 -- MeridianQoS :: sf_meridian_qos        (PRIMARY RTL)
//
// QoS-aware, registered, crosspoint-buffered NM x NT crossbar for the SilicaFlux memory / compute fabric.  It is
// Project 83's Meridian transaction contract (the Albion format = SFB3 extended; docs/meridian_qos/02_ABI.md)
// with scheduling added: four traffic classes, round-robin / weighted-round-robin / strict-priority arbitration,
// admission control and congestion throttling, privileged registers, performance counters and a MemoryGuard
// check port.  NO new bus protocol: every request / response field, status code, ordering rule and port naming
// convention is that of Project 83 (tests/meridian_qos/tb/tb_abi_check.sv compares the constants).
//
//   master side   m_req_* / m_rsp_*     valid/ready channels, flat vectors indexed by master (P83 names and widths)
//   target side   t_req_* / t_rsp_*     valid/ready channels, flat vectors indexed by target (t_req_src stamped here)
//   MemoryGuard   grd_*                 per-master check port (request / in-order registered verdict)
//   management    cfg_*                 privileged register port (sf_meridian_qos_regs)
//
// Structure (docs/meridian_qos/01_ARCHITECTURE.md):
//   m_req -> [MST_SLICE] -> mport: ingress queue, decode, admission, guard, slot table -> router: crosspoint queues,
//   per-target arbiter, egress queue -> [TGT_SLICE] -> t_req          (request network)
//   t_rsp -> [TGT_SLICE] -> router: response queue, route by src -> mport slot table -> response queue -> [MST_SLICE]
//   -> m_rsp                                                          (response network, independent)
//
// Reference configuration: 2 masters x 2 targets.  Everything scales by parameters (NM <= 16 for the FLOOR register).
//
// Reset: rst_n asynchronous assert, synchronous release from the platform; every queue, slot, pointer, credit, age,
// counter and log is cleared: no transaction survives a reset.
// Pipeline latency with MST_SLICE = TGT_SLICE = 0, DEC_PIPE = 0, GUARD_EN = 0, empty fabric: request accepted at
// cycle 0 -> visible at the target at cycle 3; target response taken at cycle r -> visible at the master at r + 3.
// Each slice stage adds 1 cycle in its direction, DEC_PIPE adds 1 request cycle, a guard verdict (>= 1 cycle) adds
// its latency to the request path.  Measured and asserted per route by the `latency_idle` test.
// =============================================================================
`default_nettype none

module sf_meridian_qos #(
  parameter int                          NM            = 2,
  parameter int                          NT            = 2,
  parameter int                          AW            = 32,
  parameter int                          DW            = 64,
  parameter int                          TAGW          = 4,
  parameter int                          DOMW          = 3,
  // ---- address map and topology (same rule as Project 83: target t when (addr & MASK[t]) == BASE[t])
  parameter logic [NT*AW-1:0]            TGT_BASE      = {(NT*AW){1'b0}},
  parameter logic [NT*AW-1:0]            TGT_MASK      = {(NT*AW){1'b0}},
  parameter logic [NM*NT-1:0]            CONN          = {(NM*NT){1'b1}},     // bit m*NT + t: master m can reach target t
  // ---- per-master configuration
  parameter int                          MAXO          = 4,                   // outstanding transactions per master (slots)
  parameter logic [NM-1:0]               MST_OOO       = {NM{1'b0}},          // 1: responses delivered as completed
  parameter logic [NM*(1<<DOMW)-1:0]     MST_DOM_ALLOW = {(NM*(1<<DOMW)){1'b1}},   // domains each port may present
  // ---- buffering
  parameter int                          IQ_DEPTH      = 4,                   // ingress queue per master
  parameter int                          XQ_DEPTH      = 4,                   // crosspoint queue per (master, target)
  parameter int                          EQ_DEPTH      = 2,                   // egress queue per target (>= 2: full rate)
  parameter int                          TRQ_DEPTH     = 2,                   // response queue per target
  parameter int                          RQ_DEPTH      = 2,                   // response queue per master
  parameter int                          GQ_DEPTH      = 2,                   // guard queue per master (>= verdict latency + 1)
  // ---- physical pipelining (stages per direction)
  parameter logic [NM*4-1:0]             MST_SLICE     = {(NM*4){1'b0}},
  parameter logic [NT*4-1:0]             TGT_SLICE     = {(NT*4){1'b0}},
  parameter int                          DEC_PIPE      = 0,                   // 1: register stage after the ingress queue
  // ---- features
  parameter int                          GUARD_EN      = 1,                   // 0: bring-up, no MemoryGuard check
  parameter int                          STRICT_EN     = 1,                   // 0: strict-priority policy not built
  // ---- reset values of the privileged registers
  parameter logic [1:0]                  DEF_POLICY    = 2'd1,                // POL_WRR
  parameter logic [31:0]                 DEF_WEIGHTS   = {8'd1, 8'd2, 8'd4, 8'd8},
  parameter logic [7:0]                  DEF_STARVE    = 8'd16,
  parameter logic [15:0]                 DEF_TCMAP     = sf_meridian_qos_pkg::TCMAP_DEFAULT,
  parameter logic [31:0]                 DEF_FLOOR     = 32'd0,
  parameter logic [31:0]                 DEF_OUTLIM    = 32'hFFFF_FFFF,
  parameter logic [17:0]                 DEF_CONG      = {2'd2, 8'd2, 8'd6},
  parameter logic                        DEF_CONG_EN   = 1'b0,
  // ---- counters
  parameter int                          LATW          = 16,
  parameter int                          CW            = 32,
  localparam int                         NDOM          = 1 << DOMW,
  localparam int                         SRCW          = sf_meridian_qos_pkg::clog2c(NM),
  localparam int                         TW            = sf_meridian_qos_pkg::clog2c(NT),
  localparam int                         RQW           = 2 + TAGW + DOMW + 1 + 3 + AW + DW + DW / 8,
  localparam int                         XW            = RQW + 2,
  localparam int                         EW            = SRCW + RQW,
  localparam int                         MRW           = TAGW + DOMW + 2 + 3 + DW,
  localparam int                         RW            = SRCW + MRW,
  localparam int                         XCW           = sf_meridian_qos_pkg::clog2c(XQ_DEPTH + 1),
  localparam int                         BW            = sf_meridian_qos_pkg::clog2c(DW / 8 + 1),
  localparam int                         OCW           = (sf_meridian_qos_pkg::clog2c(NM * XQ_DEPTH + EQ_DEPTH + IQ_DEPTH + MAXO + 2) > 8) ?
                                                          sf_meridian_qos_pkg::clog2c(NM * XQ_DEPTH + EQ_DEPTH + IQ_DEPTH + MAXO + 2) : 8,
  localparam int                         NCNT          = sf_meridian_qos_pkg::pf_n(NM, NT)
) (
  input  logic                 clk,
  input  logic                 rst_n,

  // ---------------- master side (Project 83 port convention)
  input  logic [NM-1:0]        m_req_valid,
  output logic [NM-1:0]        m_req_ready,
  input  logic [NM*2-1:0]      m_req_op,
  input  logic [NM*TAGW-1:0]   m_req_tag,
  input  logic [NM*DOMW-1:0]   m_req_dom,
  input  logic [NM-1:0]        m_req_priv,
  input  logic [NM*3-1:0]      m_req_tc,
  input  logic [NM*AW-1:0]     m_req_addr,
  input  logic [NM*DW-1:0]     m_req_wdata,
  input  logic [NM*DW/8-1:0]   m_req_wstrb,
  output logic [NM-1:0]        m_rsp_valid,
  input  logic [NM-1:0]        m_rsp_ready,
  output logic [NM*TAGW-1:0]   m_rsp_tag,
  output logic [NM*DOMW-1:0]   m_rsp_dom,
  output logic [NM*2-1:0]      m_rsp_op,
  output logic [NM*3-1:0]      m_rsp_status,
  output logic [NM*DW-1:0]     m_rsp_rdata,

  // ---------------- target side
  output logic [NT-1:0]        t_req_valid,
  input  logic [NT-1:0]        t_req_ready,
  output logic [NT*SRCW-1:0]   t_req_src,
  output logic [NT*2-1:0]      t_req_op,
  output logic [NT*TAGW-1:0]   t_req_tag,
  output logic [NT*DOMW-1:0]   t_req_dom,
  output logic [NT-1:0]        t_req_priv,
  output logic [NT*3-1:0]      t_req_tc,
  output logic [NT*AW-1:0]     t_req_addr,
  output logic [NT*DW-1:0]     t_req_wdata,
  output logic [NT*DW/8-1:0]   t_req_wstrb,
  input  logic [NT-1:0]        t_rsp_valid,
  output logic [NT-1:0]        t_rsp_ready,
  input  logic [NT*SRCW-1:0]   t_rsp_src,
  input  logic [NT*TAGW-1:0]   t_rsp_tag,
  input  logic [NT*DOMW-1:0]   t_rsp_dom,
  input  logic [NT*2-1:0]      t_rsp_op,
  input  logic [NT*3-1:0]      t_rsp_status,
  input  logic [NT*DW-1:0]     t_rsp_rdata,

  // ---------------- MemoryGuard check ports (one per master; verdicts in order, >= 1 cycle after the query is accepted)
  output logic [NM-1:0]        grd_req_valid,
  input  logic [NM-1:0]        grd_req_ready,
  output logic [NM*DOMW-1:0]   grd_req_dom,
  output logic [NM-1:0]        grd_req_priv,
  output logic [NM-1:0]        grd_req_write,
  output logic [NM*AW-1:0]     grd_req_addr,
  input  logic [NM-1:0]        grd_rsp_valid,
  input  logic [NM-1:0]        grd_rsp_ok,
  input  logic [NM*4-1:0]      grd_rsp_fault,

  // ---------------- privileged register port
  input  logic                 cfg_valid,
  input  logic                 cfg_write,
  input  logic [5:0]           cfg_addr,
  input  logic [31:0]          cfg_wdata,
  input  logic                 cfg_priv,
  output logic                 cfg_rvalid,
  output logic [31:0]          cfg_rdata,
  output logic                 cfg_err,

  // ---------------- status
  output logic [NT-1:0]        o_cong,            // congestion flag per target
  output logic                 o_internal_err,    // internal consistency monitor (must stay 0): push into a full queue
  output logic                 o_locked           // CTRL.lock is set: scheduling configuration is frozen until reset
);
  // ---------------------------------------------------------------- global cycle counter (latency timestamps)
  logic [LATW-1:0] cyc_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) cyc_q <= '0;
    else        cyc_q <= cyc_q + LATW'(1);
  end

  // ---------------------------------------------------------------- privileged registers
  logic [1:0]  r_policy;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] r_weights, r_floor, r_outlim;   // r_floor: 2 bits per master, upper bits unused when NM < 16
  /* verilator lint_on UNUSEDSIGNAL */
  logic [7:0]  r_starve, r_hi, r_lo;
  logic [15:0] r_tcmap;
  logic        r_cong_en, r_lock;
  logic [1:0]  r_thr;
  logic        r_pclr, r_sec;
  logic [sf_meridian_qos_pkg::clog2c(NCNT)-1:0] r_psel;
  logic [CW-1:0] perf_rd;
  logic          any_viol, any_denied, any_decerr;

  logic          el_set;
  logic [7:0]    el_src;
  logic [2:0]    el_status;
  logic [3:0]    el_fault;
  logic [7:0]    el_tag, el_dom;
  logic [31:0]   el_addr;

  sf_meridian_qos_regs #(
    .NM(NM), .NT(NT), .STRICT_EN(STRICT_EN), .NCNT(NCNT),
    .DEF_POLICY(DEF_POLICY), .DEF_WEIGHTS(DEF_WEIGHTS), .DEF_STARVE(DEF_STARVE), .DEF_TCMAP(DEF_TCMAP),
    .DEF_FLOOR(DEF_FLOOR), .DEF_OUTLIM(DEF_OUTLIM), .DEF_CONG(DEF_CONG), .DEF_CONG_EN(DEF_CONG_EN)
  ) u_regs (
    .clk, .rst_n,
    .cfg_valid, .cfg_write, .cfg_addr, .cfg_wdata, .cfg_priv, .cfg_rvalid, .cfg_rdata, .cfg_err,
    .o_policy(r_policy), .o_weights(r_weights), .o_starve(r_starve), .o_tcmap(r_tcmap), .o_floor(r_floor),
    .o_outlim(r_outlim), .o_cong_en(r_cong_en), .o_cong_hi(r_hi), .o_cong_lo(r_lo), .o_cong_thr(r_thr),
    .o_lock(r_lock), .o_perf_clear(r_pclr), .o_perf_sel(r_psel), .perf_data(32'(perf_rd)),
    .ev_viol(any_viol), .ev_denied(any_denied), .ev_decerr(any_decerr), .o_sec_evt(r_sec),
    .elog_set(el_set), .elog_src(el_src), .elog_status(el_status), .elog_fault(el_fault), .elog_tag(el_tag),
    .elog_dom(el_dom), .elog_addr(el_addr));

  // ---------------------------------------------------------------- master side: slices + master ports
  logic [NM-1:0]          mp_req_valid, mp_req_ready;
  logic [NM*RQW-1:0]      mp_req_data;
  logic [NM-1:0]          mp_rsp_valid, mp_rsp_ready;
  logic [NM*MRW-1:0]      mp_rsp_data;

  logic [NM*NT-1:0]       xq_push;
  logic [NM*XW-1:0]       xq_wdata;
  logic [NM*NT*XCW-1:0]   xq_cnt;
  logic [NM-1:0]          rin_valid;
  logic [NM*TW-1:0]       rin_tgt;
  logic [NM*MRW-1:0]      rin_data;
  logic [NT-1:0]          cong;

  // events
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NM-1:0]          ev_push;           // (counted from the crosspoint push vector instead)
  /* verilator lint_on UNUSEDSIGNAL */
  logic [NM-1:0]          ev_acc, ev_fire, ev_demote, ev_push_wr, ev_cpl, ev_held_adm, ev_held_cong;
  logic [NM-1:0]          ev_denied, ev_decerr;
  logic [NM*2-1:0]        ev_fire_cls, ev_cpl_cls;
  logic [NM*BW-1:0]       ev_push_bytes;
  logic [NM*3-1:0]        ev_cpl_st;
  logic [NM*LATW-1:0]     ev_cpl_lat;
  logic [NM*sf_meridian_qos_pkg::VW-1:0] ev_viol;
  logic [NM*OCW-1:0]      o_iq_occ, o_out;
  logic [NM-1:0]          m_elog_set;
  logic [NM*3-1:0]        m_elog_status;
  logic [NM*4-1:0]        m_elog_fault;
  logic [NM*TAGW-1:0]     m_elog_tag;
  logic [NM*DOMW-1:0]     m_elog_dom;
  logic [NM*AW-1:0]       m_elog_addr;

  for (genvar m = 0; m < NM; m++) begin : g_m
    localparam logic [NT-1:0]       CONN_ROW  = CONN[m*NT +: NT];
    localparam logic [NDOM-1:0]     DOM_ALLOW = MST_DOM_ALLOW[m*NDOM +: NDOM];

    // ---- request path: pack the ABI fields, master-edge slice
    logic [RQW-1:0] in_word;
    assign in_word = {m_req_op[m*2 +: 2], m_req_tag[m*TAGW +: TAGW], m_req_dom[m*DOMW +: DOMW], m_req_priv[m],
                      m_req_tc[m*3 +: 3], m_req_addr[m*AW +: AW], m_req_wdata[m*DW +: DW], m_req_wstrb[m*(DW/8) +: DW/8]};
    sf_meridian_slice #(.W(RQW), .STAGES(32'(MST_SLICE[m*4 +: 4]))) u_rqs (
      .clk, .rst_n,
      .in_valid (m_req_valid[m]), .in_ready(m_req_ready[m]), .in_data(in_word),
      .out_valid(mp_req_valid[m]), .out_ready(mp_req_ready[m]), .out_data(mp_req_data[m*RQW +: RQW]));

    // ---- response path: master-edge slice, unpack
    logic [MRW-1:0] out_word;
    sf_meridian_slice #(.W(MRW), .STAGES(32'(MST_SLICE[m*4 +: 4]))) u_rss (
      .clk, .rst_n,
      .in_valid (mp_rsp_valid[m]), .in_ready(mp_rsp_ready[m]), .in_data(mp_rsp_data[m*MRW +: MRW]),
      .out_valid(m_rsp_valid[m]), .out_ready(m_rsp_ready[m]), .out_data(out_word));
    assign m_rsp_tag[m*TAGW +: TAGW]   = out_word[DW + 5 + DOMW +: TAGW];
    assign m_rsp_dom[m*DOMW +: DOMW]   = out_word[DW + 5 +: DOMW];
    assign m_rsp_op[m*2 +: 2]          = out_word[DW + 3 +: 2];
    assign m_rsp_status[m*3 +: 3]      = out_word[DW +: 3];
    assign m_rsp_rdata[m*DW +: DW]     = out_word[DW-1:0];

    sf_meridian_mport #(
      .NT(NT), .AW(AW), .DW(DW), .TAGW(TAGW), .DOMW(DOMW), .TGT_BASE(TGT_BASE), .TGT_MASK(TGT_MASK),
      .CONN(CONN_ROW), .DOM_ALLOW(DOM_ALLOW), .MAXO(MAXO), .OOO(MST_OOO[m]),
      .IQ_DEPTH(IQ_DEPTH), .XQ_DEPTH(XQ_DEPTH), .RQ_DEPTH(RQ_DEPTH), .DEC_PIPE(DEC_PIPE),
      .GUARD_EN(GUARD_EN), .GQ_DEPTH(GQ_DEPTH), .LATW(LATW), .OCW(OCW)
    ) u_mp (
      .clk, .rst_n,
      .req_valid(mp_req_valid[m]), .req_ready(mp_req_ready[m]), .req_data(mp_req_data[m*RQW +: RQW]),
      .rsp_valid(mp_rsp_valid[m]), .rsp_ready(mp_rsp_ready[m]), .rsp_data(mp_rsp_data[m*MRW +: MRW]),
      .xq_push(xq_push[m*NT +: NT]), .xq_wdata(xq_wdata[m*XW +: XW]), .xq_cnt(xq_cnt[m*NT*XCW +: NT*XCW]),
      .rin_valid(rin_valid[m]), .rin_tgt(rin_tgt[m*TW +: TW]), .rin_data(rin_data[m*MRW +: MRW]),
      .grd_req_valid(grd_req_valid[m]), .grd_req_ready(grd_req_ready[m]),
      .grd_req_dom(grd_req_dom[m*DOMW +: DOMW]), .grd_req_priv(grd_req_priv[m]), .grd_req_write(grd_req_write[m]),
      .grd_req_addr(grd_req_addr[m*AW +: AW]),
      .grd_rsp_valid(grd_rsp_valid[m]), .grd_rsp_ok(grd_rsp_ok[m]), .grd_rsp_fault(grd_rsp_fault[m*4 +: 4]),
      .cfg_tcmap(r_tcmap), .cfg_floor(r_floor[m*2 +: 2]), .cfg_outlim(r_outlim), .cfg_cong_en(r_cong_en),
      .cfg_thr_cls(r_thr), .cong, .cyc(cyc_q),
      .ev_acc(ev_acc[m]), .ev_fire(ev_fire[m]), .ev_fire_cls(ev_fire_cls[m*2 +: 2]), .ev_demote(ev_demote[m]),
      .ev_push(ev_push[m]), .ev_push_wr(ev_push_wr[m]), .ev_push_bytes(ev_push_bytes[m*BW +: BW]),
      .ev_cpl(ev_cpl[m]), .ev_cpl_st(ev_cpl_st[m*3 +: 3]), .ev_cpl_cls(ev_cpl_cls[m*2 +: 2]),
      .ev_cpl_lat(ev_cpl_lat[m*LATW +: LATW]), .ev_held_adm(ev_held_adm[m]), .ev_held_cong(ev_held_cong[m]),
      .ev_viol(ev_viol[m*sf_meridian_qos_pkg::VW +: sf_meridian_qos_pkg::VW]),
      .ev_denied(ev_denied[m]), .ev_decerr(ev_decerr[m]),
      .o_iq_occ(o_iq_occ[m*OCW +: OCW]), .o_out(o_out[m*OCW +: OCW]),
      .elog_set(m_elog_set[m]), .elog_status(m_elog_status[m*3 +: 3]), .elog_fault(m_elog_fault[m*4 +: 4]),
      .elog_tag(m_elog_tag[m*TAGW +: TAGW]), .elog_dom(m_elog_dom[m*DOMW +: DOMW]),
      .elog_addr(m_elog_addr[m*AW +: AW]));
  end

  // ---------------------------------------------------------------- router + target-side slices
  logic [NT-1:0]        e_valid, e_ready;
  logic [NT*EW-1:0]     e_data;
  logic [NT-1:0]        r_valid, r_ready;
  logic [NT*RW-1:0]     r_data;
  logic [NT-1:0]        p_xfer, p_rsp, ev_badsrc;
  logic [NT*2-1:0]      p_xfer_cls;
  logic [NT*BW-1:0]     p_xfer_bytes;
  logic [NT*NM-1:0]     p_req;
  logic [NT*NM*2-1:0]   p_cls;
  logic [NT*OCW-1:0]    p_xq_occ, p_eq_occ;
  logic                 ev_ovf;

  sf_meridian_router #(
    .NM(NM), .NT(NT), .AW(AW), .DW(DW), .TAGW(TAGW), .DOMW(DOMW), .CONN(CONN),
    .XQ_DEPTH(XQ_DEPTH), .EQ_DEPTH(EQ_DEPTH), .TRQ_DEPTH(TRQ_DEPTH), .STRICT_EN(STRICT_EN), .OCW(OCW)
  ) u_rt (
    .clk, .rst_n,
    .xq_push, .xq_wdata, .xq_cnt,
    .e_valid, .e_ready, .e_data,
    .r_valid, .r_ready, .r_data,
    .rin_valid, .rin_tgt, .rin_data,
    .cfg_policy(r_policy), .cfg_weight(r_weights), .cfg_starve(r_starve),
    .cfg_cong_hi(r_hi), .cfg_cong_lo(r_lo), .cong,
    .p_xfer, .p_xfer_cls, .p_xfer_bytes, .p_req, .p_cls, .p_xq_occ, .p_eq_occ, .p_rsp, .ev_badsrc, .ev_ovf);
  assign o_cong         = cong;
  assign o_locked       = r_lock;
  assign o_internal_err = ev_ovf;

  for (genvar t = 0; t < NT; t++) begin : g_t
    logic [EW-1:0] eo;
    sf_meridian_slice #(.W(EW), .STAGES(32'(TGT_SLICE[t*4 +: 4]))) u_tq (
      .clk, .rst_n,
      .in_valid (e_valid[t]), .in_ready(e_ready[t]), .in_data(e_data[t*EW +: EW]),
      .out_valid(t_req_valid[t]), .out_ready(t_req_ready[t]), .out_data(eo));
    assign t_req_src[t*SRCW +: SRCW]    = eo[RQW +: SRCW];
    assign t_req_op[t*2 +: 2]           = eo[RQW-1 -: 2];
    assign t_req_tag[t*TAGW +: TAGW]    = eo[DW/8 + DW + AW + 3 + 1 + DOMW +: TAGW];
    assign t_req_dom[t*DOMW +: DOMW]    = eo[DW/8 + DW + AW + 3 + 1 +: DOMW];
    assign t_req_priv[t]                = eo[DW/8 + DW + AW + 3];
    assign t_req_tc[t*3 +: 3]           = eo[DW/8 + DW + AW +: 3];
    assign t_req_addr[t*AW +: AW]       = eo[DW/8 + DW +: AW];
    assign t_req_wdata[t*DW +: DW]      = eo[DW/8 +: DW];
    assign t_req_wstrb[t*(DW/8) +: DW/8] = eo[0 +: DW/8];

    logic [RW-1:0] ri;
    assign ri = {t_rsp_src[t*SRCW +: SRCW], t_rsp_tag[t*TAGW +: TAGW], t_rsp_dom[t*DOMW +: DOMW],
                 t_rsp_op[t*2 +: 2], t_rsp_status[t*3 +: 3], t_rsp_rdata[t*DW +: DW]};
    sf_meridian_slice #(.W(RW), .STAGES(32'(TGT_SLICE[t*4 +: 4]))) u_ts (
      .clk, .rst_n,
      .in_valid (t_rsp_valid[t]), .in_ready(t_rsp_ready[t]), .in_data(ri),
      .out_valid(r_valid[t]), .out_ready(r_ready[t]), .out_data(r_data[t*RW +: RW]));
  end

  // ---------------------------------------------------------------- performance counters
  logic [NM-1:0] m_stall_in;
  logic [NT-1:0] t_busy, t_bp;
  assign m_stall_in = m_req_valid & ~m_req_ready;
  assign t_busy     = t_req_valid & t_req_ready;
  assign t_bp       = t_req_valid & ~t_req_ready;

  logic [NM*NT-1:0] mt_push;
  assign mt_push = xq_push;

  sf_meridian_perf #(.NM(NM), .NT(NT), .CW(CW), .LATW(LATW), .BW(BW), .OCW(OCW)) u_perf (
    .clk, .rst_n, .clear(r_pclr),
    .m_acc_i(ev_acc), .m_stall_in_i(m_stall_in), .m_fire_i(ev_fire), .m_fire_cls_i(ev_fire_cls), .m_demote_i(ev_demote),
    .mt_push_i(mt_push), .m_push_wr_i(ev_push_wr), .m_push_bytes_i(ev_push_bytes),
    .m_cpl_i(ev_cpl), .m_cpl_st_i(ev_cpl_st), .m_cpl_cls_i(ev_cpl_cls), .m_cpl_lat_i(ev_cpl_lat),
    .m_held_adm_i(ev_held_adm), .m_held_cong_i(ev_held_cong), .m_viol_i(ev_viol),
    .m_iq_occ_i(o_iq_occ), .m_out_i(o_out),
    .t_xfer_i(p_xfer), .t_xfer_cls_i(p_xfer_cls), .t_xfer_bytes_i(p_xfer_bytes), .t_req_i(p_req), .t_cls_i(p_cls),
    .t_busy_i(t_busy), .t_bp_i(t_bp), .t_cong_i(cong), .t_rsp_i(p_rsp), .t_xq_occ_i(p_xq_occ), .t_eq_occ_i(p_eq_occ),
    .t_badsrc_i(ev_badsrc), .sec_evt_i(r_sec),
    .rd_idx(r_psel), .rd_data(perf_rd));

  // ---------------------------------------------------------------- register-block event aggregation
  always_comb begin
    any_viol   = (|ev_badsrc);
    for (int m = 0; m < NM; m++) any_viol = any_viol | (|ev_viol[m*sf_meridian_qos_pkg::VW +: sf_meridian_qos_pkg::VW]);
    any_denied = |ev_denied;
    any_decerr = |ev_decerr;
    // first-error log: the lowest master with a fault this cycle
    el_set    = 1'b0;
    el_src    = '0;
    el_status = '0;
    el_fault  = '0;
    el_tag    = '0;
    el_dom    = '0;
    el_addr   = '0;
    for (int m = NM - 1; m >= 0; m--) begin
      if (m_elog_set[m]) begin
        el_set    = 1'b1;
        el_src    = 8'(m);
        el_status = m_elog_status[m*3 +: 3];
        el_fault  = m_elog_fault[m*4 +: 4];
        el_tag    = 8'(m_elog_tag[m*TAGW +: TAGW]);
        el_dom    = 8'(m_elog_dom[m*DOMW +: DOMW]);
        el_addr   = 32'(m_elog_addr[m*AW +: AW]);
      end
    end
  end
endmodule

`default_nettype wire
