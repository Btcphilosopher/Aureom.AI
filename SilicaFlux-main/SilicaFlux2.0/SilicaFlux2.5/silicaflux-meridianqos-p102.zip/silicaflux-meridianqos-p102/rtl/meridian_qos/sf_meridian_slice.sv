// =============================================================================
// SilicaFlux -- Project 102 -- MeridianQoS :: sf_meridian_slice
//
// Configurable register stages (physical pipelining) on one valid/ready channel.
//   STAGES = 0 : a wire.
//   STAGES >= 1: STAGES back-to-back stages, each a 2-entry sf_meridian_queue (registered occupancy flags).
// Every output comes from registers: no combinational valid/ready path crosses a stage in either direction,
// so the slice cuts a long wire (timing) without creating a combinational loop through any number of stages.
// Cost: +1 cycle of latency per stage when empty, no loss of throughput (2 entries hide the registered ready).
// =============================================================================
`default_nettype none

module sf_meridian_slice #(
  parameter int W      = 8,
  parameter int STAGES = 1
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic         in_valid,
  output logic         in_ready,
  input  logic [W-1:0] in_data,
  output logic         out_valid,
  input  logic         out_ready,
  output logic [W-1:0] out_data
);
  generate
    if (STAGES == 0) begin : g_wire
      assign in_ready  = out_ready;
      assign out_valid = in_valid;
      assign out_data  = in_data;
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_clk = clk ^ rst_n;
      /* verilator lint_on UNUSEDSIGNAL */
    end else begin : g_chain
      logic [STAGES:0]         v;           // valid / ready / data between the stages, packed
      logic [STAGES:0]         r;
      logic [(STAGES+1)*W-1:0] d;
      assign v[0]                 = in_valid;
      assign d[0 +: W]            = in_data;
      assign in_ready             = r[0];
      assign out_valid            = v[STAGES];
      assign out_data             = d[STAGES*W +: W];
      assign r[STAGES]            = out_ready;
      for (genvar st = 0; st < STAGES; st++) begin : g_st
        /* verilator lint_off UNUSEDSIGNAL */
        logic [1:0] cnt_unused;
        /* verilator lint_on UNUSEDSIGNAL */
        sf_meridian_queue #(.W(W), .DEPTH(2)) u_q (
          .clk, .rst_n,
          .in_valid(v[st]),     .in_ready(r[st]),     .in_data(d[st*W +: W]),
          .out_valid(v[st+1]),  .out_ready(r[st+1]),  .out_data(d[(st+1)*W +: W]),
          .count(cnt_unused));
      end
    end
  endgenerate
endmodule

`default_nettype wire
