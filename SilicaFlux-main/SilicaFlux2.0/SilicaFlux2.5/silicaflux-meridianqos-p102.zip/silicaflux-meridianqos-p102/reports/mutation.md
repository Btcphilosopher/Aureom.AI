# MeridianQoS mutation check

Each mutant is one deliberate RTL defect (`scripts/mutate.py`); the regression of its configuration must fail.

**42 / 42 mutants killed** (wall time 2277 s).

| mutant | defect | result | caught by |
|---|---|---|---|
| `Q1_overflow` | queue never reports full (overflow) | KILLED | ref_2x2_m16:errors |
| `Q2_rdptr_stuck` | read pointer does not advance (duplicate delivery) | KILLED | ref_2x2_m16:basic |
| `Q3_push_unready` | push accepted while full | KILLED | ref_2x2_m16:errors |
| `A1_age_offbyone` | aging threshold off by one | KILLED | tb_arb(N=4,ONECLS=1) |
| `A2_wrr_noreload` | WRR credits never reloaded | KILLED | ref_2x2_m16:basic |
| `A3_weight0` | a zero weight switches a class off | KILLED | ref_2x2_m16:classes |
| `A4_strict_reversed` | strict priority picks the LEAST urgent class | KILLED | m4t2_classes:classes |
| `A5_rr_ptr_stuck` | global round-robin pointer never advances | KILLED | ref_2x2_m16:classes |
| `A6_credit_nodec` | WRR credit never consumed (strict priority in disguise) | KILLED | ref_2x2_m16:classes |
| `A7_aging_off` | strict-priority aging disabled | KILLED | ref_2x2_m16:classes |
| `R1_src_stamp` | source id not stamped (responses misrouted) | KILLED | ref_2x2_m16:basic |
| `R2_payload_mux` | payload of the wrong master forwarded | KILLED | ref_2x2_m16:basic |
| `R3_pop_unready` | crosspoint entry popped without being transferred (loss) | KILLED | ref_2x2_m16:errors |
| `R4_resp_route` | responses routed to the wrong master | KILLED | ref_2x2_m16:basic |
| `R5_cong_never` | congestion flag never rises | KILLED | ref_2x2_m16:admission |
| `P1_no_binding` | domain binding removed | KILLED | v_dom_sparse:errors |
| `P2_guard_ignored` | guard verdict ignored (denied requests forwarded) | KILLED | ref_2x2_m16:errors |
| `P3_deny_status` | wrong status for a guard denial | KILLED | ref_2x2_m16:errors |
| `P4_tagreuse_off` | tag reuse not detected | KILLED | ref_2x2_m16:tagreuse |
| `P5_echo_off` | response echo / status check removed | KILLED | ref_2x2_m16:errors |
| `P6_inorder_broken` | in-order delivery ignores completion of the head | KILLED | ref_2x2_m16:tagreuse |
| `P7_limit_ignored` | per-class outstanding limit ignored | KILLED | ref_2x2_m16:admission |
| `P8_floor_ignored` | class floor ignored (a master can escalate its class) | KILLED | ref_2x2_m16:floor |
| `P9_tcmap_ignored` | tc -> class map ignored | KILLED | ref_2x2_m16:admission |
| `P10_no_reservation` | crosspoint space not reserved (queue overflow) | KILLED | ref_2x2_m16:saturate |
| `P11_misalign_off` | misaligned requests forwarded | KILLED | ref_2x2_m16:errors |
| `P12_noroute_off` | topology (no-route) check removed | KILLED | v_dom_sparse:tagreuse |
| `P13_timestamp` | latency timestamp taken at dispatch, not at accept | KILLED | ref_2x2_m16:counters |
| `P14_throttle_off` | congestion throttle disabled | KILLED | ref_2x2_m16:admission |
| `P15_badop_status` | wrong status for a reserved opcode | KILLED | ref_2x2_m16:errors |
| `D1_reach_ignored` | decoder ignores the topology | KILLED | v_dom_sparse:tagreuse |
| `D2_align_bit0` | misalignment of bit 0 not detected | KILLED | ref_2x2_m16:errors |
| `G1_priv_off` | privilege check removed | KILLED | ref_2x2_m16:regs |
| `G2_lock_off` | configuration lock not enforced | KILLED | ref_2x2_m16:regs |
| `G3_policy3_legal` | reserved policy accepted | KILLED | ref_2x2_m16:regs |
| `G4_w1c_broken` | sticky status cannot be cleared | KILLED | ref_2x2_m16:regs |
| `G5_default_weights` | wrong reset value of the weights | KILLED | ref_2x2_m16:regs |
| `G6_perm_nolock` | lock bit cannot be set | KILLED | ref_2x2_m16:regs |
| `T1_status_wiring` | response status mis-wired | KILLED | ref_2x2_m16:basic |
| `T2_tc_wiring` | traffic class mis-wired to the target | KILLED | ref_2x2_m16:basic |
| `T3_priv_wiring` | privilege metadata dropped before the target | KILLED | ref_2x2_m16:errors |
| `T4_dom_wiring` | protection-domain metadata dropped before the target | KILLED | ref_2x2_m16:basic |
