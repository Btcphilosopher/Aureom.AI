#!/usr/bin/env python3
"""MeridianQoS benchmark runner: reproducible throughput and latency measurements.

For every pipeline configuration it builds the simulation testbench (Verilator), validates the idle latency against the
documented formula, and runs the workload scenarios (benchmarks/meridian_qos/gen_workloads.py) under each arbitration
policy.  Everything is deterministic (fixed traces, fixed testbench seed); rerunning gives identical numbers.

Measured in simulation (cycles, exact): per-class and per-master latency (accept at the master port -> delivery at the
master port: mean / p50 / p95 / p99 / max), throughput (requests / cycle, bytes / cycle), per-target utilisation
(BUSY / CYCLES), contention, back-pressure, queue occupancy -- the last group read from the DUT's own counters.

    run_bench.py [--out DIR] [--builddir DIR] [--jobs N] [--only pipeline|policy|slots]
"""
import argparse, json, math, os, re, subprocess, sys
from concurrent.futures import ThreadPoolExecutor, as_completed

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
TR = os.path.join(HERE, "traces")

PIPES = {   # name -> testbench -G overrides (pipeline stages); GUARD = 1, verdict latency 1 in all
    "base":        {},
    "dec":         {"DECP": 1},
    "ms1":         {"MSL": 1},
    "ts1":         {"TSL": 1},
    "dec_ms1":     {"DECP": 1, "MSL": 1},
    "dec_ms1_ts1": {"DECP": 1, "MSL": 1, "TSL": 1},
    "dec_ms2_ts1": {"DECP": 1, "MSL": 2, "TSL": 1},
}
POLICIES = {   # name -> plusargs
    "RR":             ["+POLICY=0"],
    "WRR_8421":       ["+POLICY=1", "+WEIGHTS=01020408"],
    "STRICT_age0":    ["+POLICY=2", "+STARVE=0"],
    "STRICT_age16":   ["+POLICY=2", "+STARVE=16"],
}


def build(name, nm, nt, maxo, iqd, extra, bdir):
    d = os.path.join(bdir, name)
    g = [f"-GNM={nm}", f"-GNT={nt}", f"-GMAXO={maxo}", f"-GIQD={iqd}"] + [f"-G{k}={v}" for k, v in extra.items()]
    r = subprocess.run(["bash", os.path.join(ROOT, "scripts", "build_tb.sh"), d] + g, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"build {name} failed:\n{r.stdout[-1500:]}{r.stderr[-1500:]}")
    return os.path.join(d, "Vtb")


def pct(v, p):
    if not v:
        return None
    s = sorted(v)
    k = min(len(s) - 1, max(0, int(math.ceil(p / 100.0 * len(s))) - 1))
    return s[k]


def run_scen(exe, scen, name, policy_args, tag):
    sc = scen[name]
    lat = os.path.join(os.environ.get("BENCH_TMP", "/tmp"), f"lat_{tag}.txt")
    args = [exe, "+TEST=trace", f"+LATDUMP={lat}"] + policy_args
    for m, t in enumerate(sc["traces"]):
        args += [f"+TRACE{m}={os.path.join(TR, t)}", f"+MAXOUT{m}={sc['max_out'][m]}"]
    for t, (lr, acc) in enumerate(zip(sc["tlat"], sc["tacc"])):
        lo, hi = lr.split(":")
        args += [f"+TLATMIN{t}={lo}", f"+TLATMAX{t}={hi}", f"+TACC{t}={acc}"]
    out = subprocess.run(args, capture_output=True, text=True, timeout=3000)
    txt = out.stdout + out.stderr
    ok = bool(re.search(r"^PASS trace", txt, re.M)) and not re.search(r"^FAIL", txt, re.M)
    r = {"ok": ok}
    m = re.search(r"RESULT trace requests=(\d+) completed=(\d+) first_issue=(\d+) last_done=(\d+) run_cycles=(\d+)", txt)
    if m:
        r.update(requests=int(m.group(1)), completed=int(m.group(2)), run_cycles=int(m.group(5)))
    ctr = {k: int(v) for k, v in re.findall(r"RESULT ctr (\S+)=(\d+)", txt)}
    r["ctr"] = ctr
    # latency records: master class latency accept_cycle
    cls_l, m_l = {}, {}
    if os.path.exists(lat):
        for line in open(lat):
            a = line.split()
            if len(a) >= 3:
                mi, c, l = int(a[0]), int(a[1]), int(a[2])
                cls_l.setdefault(c, []).append(l)
                m_l.setdefault(mi, []).append(l)
        os.remove(lat)
    def stats(v):
        return {"n": len(v), "mean": sum(v) / len(v), "p50": pct(v, 50), "p95": pct(v, 95), "p99": pct(v, 99), "max": max(v)} if v else None
    r["class_lat"] = {c: stats(v) for c, v in sorted(cls_l.items())}
    r["master_lat"] = {m: stats(v) for m, v in sorted(m_l.items())}
    cyc = ctr.get("CYCLES", 0) or 1
    r["req_per_cycle"] = r.get("completed", 0) / max(1, r.get("run_cycles", 1))
    r["bytes_per_cycle"] = (ctr.get("BYTES_WR", 0) + ctr.get("BYTES_RD", 0)) / cyc
    nt = len(sc["tlat"])
    r["target_util"] = [ctr.get(f"t{t}.BUSY", 0) / cyc for t in range(nt)]
    return r


def idle_latency(exe):
    out = subprocess.run([exe, "+TEST=latency_idle"], capture_output=True, text=True, timeout=600).stdout
    rows = re.findall(r"RESULT latency_idle (\S+) request=(\d+) \(formula (\d+)\) response=(\d+) \(formula (\d+)\)", out)
    ok = bool(re.search(r"^PASS latency_idle", out, re.M))
    if not rows:
        return {"ok": ok}
    return {"ok": ok, "request": int(rows[0][1]), "response": int(rows[0][3]), "routes": len(rows)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(HERE, "results"))
    ap.add_argument("--builddir", default=os.path.join(ROOT, "build", "bench"))
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--only", choices=["pipeline", "policy", "slots"])
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    os.makedirs(a.builddir, exist_ok=True)
    if not os.path.exists(os.path.join(TR, "scenarios.json")):
        subprocess.run([sys.executable, os.path.join(HERE, "gen_workloads.py"), TR], check=True)
    scen = json.load(open(os.path.join(TR, "scenarios.json")))
    res = {"pipeline": {}, "policy": {}, "slots": {}}

    todo = []   # (group, key, build args, runs)
    if a.only in (None, "pipeline"):
        for pn, ov in PIPES.items():
            todo.append(("pipeline", pn, dict(nm=2, nt=2, maxo=8, iqd=8, extra=ov, name=f"s2_{pn}")))
    if a.only in (None, "policy"):
        todo.append(("policy", "s4", dict(nm=4, nt=2, maxo=16, iqd=8, extra={}, name="s4_m16")))
    if a.only in (None, "slots"):
        for mo in (4, 8):
            todo.append(("slots", f"m{mo}", dict(nm=4, nt=2, maxo=mo, iqd=8, extra={}, name=f"s4_m{mo}")))

    exes = {}
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        fs = {ex.submit(build, t[2]["name"], t[2]["nm"], t[2]["nt"], t[2]["maxo"], t[2]["iqd"], t[2]["extra"], a.builddir): t for t in todo}
        for f in as_completed(fs):
            t = fs[f]
            exes[t[2]["name"]] = f.result()
            print("built", t[2]["name"], flush=True)

    jobs = []
    for grp, key, b in todo:
        exe = exes[b["name"]]
        if grp == "pipeline":
            jobs.append((grp, key, "idle", lambda e=exe: idle_latency(e)))
            for sn in ("s2_ref",):
                jobs.append((grp, key, sn, lambda e=exe, sn=sn, k=key: run_scen(e, scen, sn, ["+POLICY=1", "+WEIGHTS=01020408"], f"p_{k}_{sn}")))
        elif grp == "policy":
            for pn, pa in POLICIES.items():
                for sn in ("s4_full", "s4_hot"):
                    jobs.append((grp, f"{sn}/{pn}", "run", lambda e=exe, sn=sn, pa=pa, pn=pn: run_scen(e, scen, sn, pa, f"pol_{sn}_{pn}")))
        elif grp == "slots":
            for sn in ("s4_hot",):
                for pn in ("STRICT_age0", "WRR_8421"):
                    jobs.append((grp, f"{key}/{sn}/{pn}", "run", lambda e=exe, sn=sn, pa=POLICIES[pn], pn=pn, k=key: run_scen(e, scen, sn, pa, f"slot_{k}_{sn}_{pn}")))
    # the slots group also needs the 16-slot point from the policy build
    if a.only in (None, "slots"):
        e16 = exes.get("s4_m16")
        if e16:
            for sn in ("s4_hot",):
                for pn in ("STRICT_age0", "WRR_8421"):
                    jobs.append(("slots", f"m16/{sn}/{pn}", "run", lambda e=e16, sn=sn, pa=POLICIES[pn], pn=pn: run_scen(e, scen, sn, pa, f"slot_m16_{sn}_{pn}")))

    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        fs = {ex.submit(j[3]): j for j in jobs}
        for f in as_completed(fs):
            grp, key, sub, _ = fs[f]
            r = f.result()
            res[grp].setdefault(key, {})[sub] = r
            print("done", grp, key, sub, "ok" if r.get("ok") else "FAIL", flush=True)
    json.dump(res, open(os.path.join(a.out, "bench.json"), "w"), indent=1)
    bad = [(g, k, s) for g in res for k in res[g] for s, r in res[g][k].items() if not r.get("ok")]
    print("FAILED runs:", bad if bad else "none")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
