#!/usr/bin/env python3
"""MeridianQoS workload generator.

Writes deterministic request traces (one file per master) and a scenario description for the testbench's `trace`
mode.  The traffic shapes come from the audit of the SilicaFlux endpoint blocks (docs/meridian_qos/00_AUDIT.md);
every parameter is a documented choice, not a measurement of real silicon.

  ControlCore   sparse single-beat MMIO / data accesses, ONE access in flight (blocking CPU loads/stores, 32-bit
                stores use partial byte strobes), CSR polling.                         wire tc 4 (management)  -> CLASS_0
  PacketCore    frames arriving on a Poisson process (64 B .. 9216 B); per frame: descriptor read, payload write
                burst, descriptor write-back; latency sensitive.                       wire tc 3 (I/O)         -> CLASS_1
  StreamDMA     (CloudDMA-like) 16-beat (128 B) INCR bursts, read burst from external memory then write burst to
                SRAM, never crossing a 4 KiB boundary, back to back.                    wire tc 1 (bulk)        -> CLASS_2
  TensorCore    32-beat sequential read bursts (weights from external memory, activations from SRAM), every 8th
                burst is a 32-beat write (the real engine posts it; Meridian's ABI has acknowledged writes only),
                high rate, several outstanding.                                         wire tc 0 (background)  -> CLASS_3

Beats are single-beat transactions (the contract has no bursts): a burst is `len` consecutive requests with gap 0.
Targets: T0 = shared SRAM (1-4 cycle latency, 1 beat / cycle), T1 = external memory / HBM (12-40 cycles).

Trace line:  <gap> <op 0|1> <tc> <addr hex> <wdata hex> <wstrb hex>      (gap = idle cycles before the request)
Usage: gen_workloads.py <outdir> [--seed N] [--scale S]
"""
import argparse, json, os, random

BEAT = 8                    # bytes per beat (DW = 64)
WIN = 1 << 16               # each target owns a 64 KiB window
T0, T1 = 0 * WIN, 1 * WIN   # SRAM, external memory


def hash64(x):
    x = (x * 0x9E3779B97F4A7C15) & (2**64 - 1)
    return x ^ (x >> 29)


class Gen:
    def __init__(self, seed):
        self.r = random.Random(seed)
        self.n = 0

    def data(self):
        self.n += 1
        return hash64(self.n)


def control_core(g, n, mean_gap=14):
    """Sparse MMIO + data accesses; 65 % reads; 32-bit stores use strobes 0x0F / 0xF0; polling bursts of the same CSR."""
    out, t = [], 0
    i = 0
    while i < n:
        t += int(g.r.expovariate(1.0 / mean_gap)) + 1
        if g.r.random() < 0.20:                         # CSR polling loop: the same word, 3-6 reads
            a = T1 + 8 * g.r.randrange(0, 16)
            for _ in range(g.r.randrange(3, 7)):
                out.append((t, 0, 4, a, 0, 0xFF)); t += int(g.r.expovariate(1.0 / 6)) + 2; i += 1
            continue
        tgt = T0 if g.r.random() < 0.7 else T1
        a = tgt + 8 * g.r.randrange(0, 256)
        if g.r.random() < 0.65:
            out.append((t, 0, 4, a, 0, 0xFF))
        else:
            out.append((t, 1, 4, a, g.data(), g.r.choice([0x0F, 0xF0, 0xFF])))
        i += 1
    return out


def packet_core(g, n_frames, mean_gap=70):
    """Poisson frame arrivals; descriptor read (2 beats), payload write burst, descriptor write-back (1 beat)."""
    out, t = [], 0
    ring = 0
    buf = 0x2000
    lens = [64, 64, 128, 256, 512, 1500, 1500, 9000]       # bytes, 64 B dominated with a few jumbo frames
    for _ in range(n_frames):
        t += int(g.r.expovariate(1.0 / mean_gap)) + 1
        d = T0 + 8 * (ring % 32); ring += 2
        for k in range(2):
            out.append((t + k, 0, 3, d + 8 * k, 0, 0xFF))
        beats = max(1, min(g.r.choice(lens), 2048) // BEAT)    # payload beats (jumbo frames capped to keep traces short)
        base = T0 + (buf + 8 * (g.r.randrange(0, 128) * 32)) % (WIN - 4096)
        for k in range(beats):
            out.append((t + 3 + k, 1, 3, base + 8 * k, g.data(), 0xFF))
        out.append((t + 3 + beats + 2, 1, 3, d, g.data(), 0xFF))
    return out


def stream_dma(g, n_bursts, burst=16):
    """16-beat INCR bursts: read from external memory, write to SRAM; never crosses a 4 KiB boundary."""
    out, t = [], 0
    src, dst = T1 + 0x1000, T0 + 0x4000
    for b in range(n_bursts):
        s = src + (b * burst * BEAT) % 0x8000
        d = dst + (b * burst * BEAT) % 0x4000
        for k in range(burst):
            out.append((t, 0, 1, s + 8 * k, 0, 0xFF)); t += 1
        for k in range(burst):
            out.append((t, 1, 1, d + 8 * k, g.data(), 0xFF)); t += 1
    return out


def tensor_core(g, n_bursts, burst=32):
    """32-beat sequential reads (weights from T1, activations from T0); every 8th burst is a write of results."""
    out, t = [], 0
    for b in range(n_bursts):
        t += g.r.randrange(0, 3)
        if b % 8 == 7:
            base = T0 + 0x8000 + (b * burst * BEAT) % 0x4000
            for k in range(burst):
                out.append((t, 1, 0, base + 8 * k, g.data(), 0xFF)); t += 1
        else:
            base = (T1 if b % 2 == 0 else T0) + 0x0000 + (b * burst * BEAT) % 0x8000
            for k in range(burst):
                out.append((t, 0, 0, base + 8 * k, 0, 0xFF)); t += 1
    return out


def merge(lists):
    ev = sorted((e for l in lists for e in l), key=lambda e: e[0])
    out, last = [], 0
    for (t, op, tc, a, d, s) in ev:
        gap = max(0, t - last)
        out.append((gap, op, tc, a, d, s))
        last = max(last, t)
    return out


def write_trace(path, rows):
    with open(path, "w") as f:
        for (gap, op, tc, a, d, s) in rows:
            f.write(f"{gap} {op} {tc} {a:x} {d:x} {s:x}\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("outdir")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--scale", type=float, default=1.0, help="multiplies the number of frames / bursts / accesses")
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    S = a.scale
    scen = {}

    # ---- S2: the two-master, two-target reference.  M0 = control + network (latency sensitive), M1 = DMA + tensor (bulk)
    g = Gen(a.seed)
    m0 = merge([control_core(g, int(300 * S)), packet_core(g, int(60 * S))])
    m1 = merge([stream_dma(g, int(40 * S)), tensor_core(g, int(24 * S))])
    write_trace(os.path.join(a.outdir, "s2_ref_m0.trace"), m0)
    write_trace(os.path.join(a.outdir, "s2_ref_m1.trace"), m1)
    scen["s2_ref"] = {"NM": 2, "NT": 2, "traces": ["s2_ref_m0.trace", "s2_ref_m1.trace"],
                      "masters": ["ControlCore+PacketCore (tc 4 / 3)", "StreamDMA+TensorCore (tc 1 / 0)"],
                      "max_out": [4, 8], "tlat": ["2:4", "12:30"], "tacc": [100, 100],
                      "notes": "T0 shared SRAM, T1 external memory"}

    # ---- S4: four masters, one per profile, same two targets
    g = Gen(a.seed + 100)
    tr = [control_core(g, int(300 * S)), packet_core(g, int(60 * S)), stream_dma(g, int(40 * S)), tensor_core(g, int(24 * S))]
    names = ["ControlCore (tc 4)", "PacketCore (tc 3)", "StreamDMA (tc 1)", "TensorCore (tc 0)"]
    files = []
    for k, rows in enumerate(tr):
        p = f"s4_full_m{k}.trace"
        write_trace(os.path.join(a.outdir, p), merge([rows]))
        files.append(p)
    scen["s4_full"] = {"NM": 4, "NT": 2, "traces": files, "masters": names,
                       "max_out": [1, 4, 8, 8], "tlat": ["2:4", "12:30"], "tacc": [100, 100],
                       "notes": "one master per profile; ControlCore has one access in flight (blocking CPU)"}

    # ---- S4_hot: the same four masters, everything aimed at the shared SRAM (worst-case contention on one target)
    g = Gen(a.seed + 200)
    hot = []
    for k, rows in enumerate(tr):
        h = [(t, op, tc, T0 + (ad % (WIN - 8)), d, s) for (t, op, tc, ad, d, s) in rows]
        p = f"s4_hot_m{k}.trace"
        write_trace(os.path.join(a.outdir, p), merge([h]))
        hot.append(p)
    scen["s4_hot"] = {"NM": 4, "NT": 2, "traces": hot, "masters": names,
                      "max_out": [1, 4, 8, 8], "tlat": ["2:4", "12:30"], "tacc": [60, 100],
                      "notes": "all traffic to T0, which accepts 60 % of the cycles (a congested shared SRAM)"}

    with open(os.path.join(a.outdir, "scenarios.json"), "w") as f:
        json.dump(scen, f, indent=1)
    for k, v in scen.items():
        n = sum(sum(1 for _ in open(os.path.join(a.outdir, t))) for t in v["traces"])
        print(f"{k}: {len(v['traces'])} masters, {n} requests")


if __name__ == "__main__":
    main()
