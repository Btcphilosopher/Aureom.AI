#!/usr/bin/env python3
"""MeridianQoS synthesis / pipeline-depth sweep.

For each configuration (pipeline stages, features) it measures, with the tools available in this environment:

  1. generic gate-level cost, technology independent:  Yosys `synth` + ABC mapping to a 2-input gate library
     -> cell count and `ltp` = the longest topological combinational path in gate levels (register to register)
  2. FPGA cost and timing, ECP5 (Lattice, LFE5U-85F): Yosys `synth_ecp5` -> LUT4 / flip-flop counts; `nextpnr-ecp5`
     place-and-route -> Fmax of `clk` (best of several seeds is NOT taken: min / median / max are all reported)

There is NO ASIC library or PDK in the repository, so no ASIC area, frequency or power is claimed.  The ECP5 Fmax is an FPGA
figure, used to compare pipeline configurations with each other; it is not a prediction of silicon speed.

The design has hundreds of I/O bits, which cannot all be pins.  The timing run therefore wraps it in a generated shell:
inputs come from one serial shift register, outputs are registered and folded through a registered XOR pipeline into a
single pin, so every path inside the fabric is flop-to-flop (the shell's own flops are reported separately, and the
DUT-only LUT / FF counts come from a separate synthesis without the shell).

Usage: synth.py [--cfg NAME ...] [--seeds 1,2,3] [--out DIR] [--nopnr]
"""
import argparse, json, math, os, re, subprocess, sys, tempfile, time
from concurrent.futures import ThreadPoolExecutor, as_completed

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
RTL = [os.path.join(ROOT, "rtl", "meridian_qos", f) for f in (
    "sf_meridian_qos_pkg.sv", "sf_meridian_queue.sv", "sf_meridian_slice.sv", "sf_meridian_arbiter.sv",
    "sf_meridian_decoder.sv", "sf_meridian_router.sv", "sf_meridian_mport.sv", "sf_meridian_qos_regs.sv",
    "sf_meridian_perf.sv", "sf_meridian_qos.sv")]

FREQ = 60                       # nextpnr timing target in MHz (a realistic target: an unreachable one degrades the placement)
BASE = {"NM": 2, "NT": 2, "AW": 32, "DW": 32, "TAGW": 4, "DOMW": 3, "MAXO": 4}

# name -> overrides.  MST_SLICE / TGT_SLICE are stages per port (both directions), DEC_PIPE the decode register stage.
CFGS = {
    "base":        {},                                          # no extra pipelining (3-cycle request path)
    "dec":         {"DEC_PIPE": 1},
    "ms1":         {"MSL": 1},
    "ts1":         {"TSL": 1},
    "dec_ms1":     {"DEC_PIPE": 1, "MSL": 1},
    "dec_ms1_ts1": {"DEC_PIPE": 1, "MSL": 1, "TSL": 1},
    "dec_ms2_ts1": {"DEC_PIPE": 1, "MSL": 2, "TSL": 1},
    "noguard":     {"GUARD_EN": 0},
    "perf16":      {"CW": 16},                                  # narrower counters: area of the measurement
}


def clog2c(n):
    return max(1, math.ceil(math.log2(n))) if n > 1 else 1


def ports(p):
    NM, NT, AW, DW, TAGW, DOMW = (p[k] for k in ("NM", "NT", "AW", "DW", "TAGW", "DOMW"))
    SRCW = clog2c(NM)
    ins = [("m_req_valid", NM), ("m_req_op", 2 * NM), ("m_req_tag", NM * TAGW), ("m_req_dom", NM * DOMW), ("m_req_priv", NM),
           ("m_req_tc", 3 * NM), ("m_req_addr", NM * AW), ("m_req_wdata", NM * DW), ("m_req_wstrb", NM * DW // 8),
           ("m_rsp_ready", NM), ("t_req_ready", NT), ("t_rsp_valid", NT), ("t_rsp_src", NT * SRCW), ("t_rsp_tag", NT * TAGW),
           ("t_rsp_dom", NT * DOMW), ("t_rsp_op", 2 * NT), ("t_rsp_status", 3 * NT), ("t_rsp_rdata", NT * DW),
           ("grd_req_ready", NM), ("grd_rsp_valid", NM), ("grd_rsp_ok", NM), ("grd_rsp_fault", 4 * NM),
           ("cfg_valid", 1), ("cfg_write", 1), ("cfg_addr", 6), ("cfg_wdata", 32), ("cfg_priv", 1)]
    outs = [("m_req_ready", NM), ("m_rsp_valid", NM), ("m_rsp_tag", NM * TAGW), ("m_rsp_dom", NM * DOMW), ("m_rsp_op", 2 * NM),
            ("m_rsp_status", 3 * NM), ("m_rsp_rdata", NM * DW), ("t_req_valid", NT), ("t_req_src", NT * SRCW), ("t_req_op", 2 * NT),
            ("t_req_tag", NT * TAGW), ("t_req_dom", NT * DOMW), ("t_req_priv", NT), ("t_req_tc", 3 * NT), ("t_req_addr", NT * AW),
            ("t_req_wdata", NT * DW), ("t_req_wstrb", NT * DW // 8), ("t_rsp_ready", NT), ("grd_req_valid", NM),
            ("grd_req_dom", NM * DOMW), ("grd_req_priv", NM), ("grd_req_write", NM), ("grd_req_addr", NM * AW),
            ("cfg_rvalid", 1), ("cfg_rdata", 32), ("cfg_err", 1), ("o_cong", NT), ("o_internal_err", 1), ("o_locked", 1)]
    return ins, outs


def params_text(c):
    p = dict(BASE)
    p.update({k: v for k, v in c.items() if k in BASE})
    NM, NT, AW = p["NM"], p["NT"], p["AW"]
    base = "{" + ", ".join(f"{AW}'h{(t << 16) & (2**AW - 1):x}" for t in reversed(range(NT))) + "}"
    mask = "{" + ", ".join(f"{AW}'h{(0xFFFF0000) & (2**AW - 1):x}" for _ in range(NT)) + "}"
    sl_m = "{" + ", ".join(f"4'd{c.get('MSL', 0)}" for _ in range(NM)) + "}"
    sl_t = "{" + ", ".join(f"4'd{c.get('TSL', 0)}" for _ in range(NT)) + "}"
    chp = {"NM": NM, "NT": NT, "AW": AW, "DW": p["DW"], "TAGW": p["TAGW"], "DOMW": p["DOMW"], "MAXO": p["MAXO"],
           "DEC_PIPE": c.get("DEC_PIPE", 0), "GUARD_EN": c.get("GUARD_EN", 1), "CW": c.get("CW", 32),
           "IQ_DEPTH": c.get("IQ_DEPTH", 4), "XQ_DEPTH": c.get("XQ_DEPTH", 4)}
    return p, chp, base, mask, sl_m, sl_t


def wrapper(c):
    p, chp, base, mask, sl_m, sl_t = params_text(c)
    ins, outs = ports(p)
    nin, nout = sum(w for _, w in ins), sum(w for _, w in outs)
    L = ["`default_nettype none", "module synth_wrap (input wire clk, input wire rst_n, input wire si, output reg so);",
         f"  localparam NIN = {nin}, NOUT = {nout};", "  reg [NIN-1:0] in_sr;",
         "  always @(posedge clk) in_sr <= {in_sr[NIN-2:0], si};"]
    pos = 0
    for n, w in ins:
        L.append(f"  wire [{w-1}:0] {n} = in_sr[{pos + w - 1}:{pos}];")
        pos += w
    for n, w in outs:
        L.append(f"  wire [{w-1}:0] {n};")
    pa = ", ".join(f".{k}({v})" for k, v in chp.items())
    L.append(f"  sf_meridian_qos #({pa}, .TGT_BASE({base}), .TGT_MASK({mask}), .MST_SLICE({sl_m}), .TGT_SLICE({sl_t})) dut (")
    L.append("    .clk(clk), .rst_n(rst_n),")
    names = [n for n, _ in ins] + [n for n, _ in outs]
    L.append(",\n".join(f"    .{n}({n})" for n in names))
    L.append("  );")
    cat = ", ".join(n for n, _ in outs)
    L += [f"  localparam NOUTP = ((NOUT + 15) / 16) * 16;            // padded to whole 16-bit chunks (an out-of-range select would be X",
          "  // and Yosys would optimise the whole design away)",
          f"  wire [NOUT-1:0] outs = {{{cat}}};", "  wire [NOUTP-1:0] outs_p = {{(NOUTP-NOUT){1'b0}}, outs};", "  reg [NOUTP-1:0] out_q;",
          "  always @(posedge clk) out_q <= outs_p;",
          "  // registered XOR-folding pipeline: 16 bits per stage, so the shell never limits the clock",
          "  localparam N1 = NOUTP / 16;", "  localparam N1P = ((N1 + 15) / 16) * 16;", "  reg [N1P-1:0] f1;", "  integer i;",
          "  always @(posedge clk) for (i = 0; i < N1P; i = i + 1) f1[i] <= (i < N1) ? ^out_q[16*i +: 16] : 1'b0;",
          "  localparam N2 = N1P / 16;", "  reg [N2-1:0] f2;",
          "  always @(posedge clk) for (i = 0; i < N2; i = i + 1) f2[i] <= ^f1[16*i +: 16];",
          "  always @(posedge clk) so <= ^f2;", "endmodule"]
    return "\n".join(L) + "\n", nin, nout


def sh(cmd, log=None, timeout=3000):
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    out = r.stdout + r.stderr
    if log:
        open(log, "w").write(out)
    return r.returncode, out


def chparams(c):
    _, chp, _, _, _, _ = params_text(c)
    return chp



def parse_generic(d, res):
    try:
        st = open(os.path.join(d, "gen_stat.txt")).read()
        lt = open(os.path.join(d, "gen_ltp.txt")).read()
    except OSError:
        return
    m = re.search(r"Number of cells:\s+(\d+)", st)
    cells = {k: int(v) for k, v in re.findall(r"^\s+(\$_\w+_)\s+(\d+)\s*$", st, re.M)}
    res["gen_cells"] = int(m.group(1)) if m else None
    res["gen_ffs"] = sum(v for k, v in cells.items() if "DFF" in k)
    res["gen_logic"] = sum(v for k, v in cells.items() if "DFF" not in k)
    m = re.search(r"Longest topological path .*?\(length=(\d+)\)", lt)
    res["gen_ltp_levels"] = int(m.group(1)) if m else None


def parse_ecp5(d, res):
    try:
        st = open(os.path.join(d, "ecp5_dut_stat.txt")).read()
    except OSError:
        return
    g = lambda k: sum(int(x) for x in re.findall(r"^\s+" + k + r"\s+(\d+)\s*$", st, re.M))
    res["ecp5_lut4"], res["ecp5_ff"], res["ecp5_dpr"] = g("LUT4"), g("TRELLIS_FF"), g("TRELLIS_DPR16X4")
    res["ecp5_carry"], res["ecp5_pfumx"] = g("CCU2C"), g("PFUMX") + g("L6MUX21")


def parse_pnr(d, res):
    fm = []
    for sd in (1, 2, 3, 4, 5):
        pth = os.path.join(d, f"pnr_seed{sd}.log")
        if os.path.exists(pth):
            mm = re.findall(r"Max frequency for clock\s+'[^']*':\s+([\d.]+) MHz", open(pth, errors="replace").read())
            if mm:
                fm.append(float(mm[-1]))
    if fm:
        sf = sorted(fm)
        res["fmax_mhz"] = fm
        res["fmax_min"], res["fmax_med"], res["fmax_max"] = sf[0], _median(sf), sf[-1]


def _median(v):
    """True median (mean of the two middle values for an even count; the upper-middle element would bias a 2-seed result upward)."""
    v = sorted(v)
    n = len(v)
    return v[n // 2] if n % 2 else 0.5 * (v[n // 2 - 1] + v[n // 2])


def collect(name, d):
    res = {"name": name, "overrides": CFGS[name], "collected_from_existing_run": True}
    parse_generic(d, res)
    parse_ecp5(d, res)
    parse_pnr(d, res)
    return res


def run_cfg(name, c, seeds, wd, pnr):
    d = os.path.join(wd, name)
    os.makedirs(d, exist_ok=True)
    res = {"name": name, "overrides": c}
    p, chp, base, mask, sl_m, sl_t = params_text(c)
    # DUT-only elaboration needs the address-map parameters as chparams too: use a tiny top that fixes them
    top = (f"module synth_top(input clk); endmodule\n")
    dutsrc = os.path.join(d, "dut_top.sv")
    ins, outs = ports(p)
    pa = ", ".join(f".{k}({v})" for k, v in chp.items())
    # a pass-through top so the parameters (maps, slices) are fixed; ports are left as module ports for the generic runs
    lines = ["`default_nettype none", "module dut_top ("]
    plist = [f"input wire {'[%d:0] ' % (w - 1) if w > 1 else ''}{n}" for n, w in ins] + \
            [f"output wire {'[%d:0] ' % (w - 1) if w > 1 else ''}{n}" for n, w in outs]
    lines.append("  input wire clk, input wire rst_n,\n  " + ",\n  ".join(plist))
    lines.append(");")
    lines.append(f"  sf_meridian_qos #({pa}, .TGT_BASE({base}), .TGT_MASK({mask}), .MST_SLICE({sl_m}), .TGT_SLICE({sl_t})) dut (")
    lines.append("    .clk(clk), .rst_n(rst_n),\n" + ",\n".join(f"    .{n}({n})" for n in [n for n, _ in ins] + [n for n, _ in outs]) + "\n  );")
    lines.append("endmodule")
    open(dutsrc, "w").write("\n".join(lines) + "\n")
    srcs = " ".join(RTL + [dutsrc])

    # ---- 1. generic gate level
    ys = (f"read_verilog -sv {srcs}; hierarchy -top dut_top; synth -flatten -top dut_top; "
          f"abc -g AND,NAND,OR,NOR,XOR,XNOR,ANDNOT,ORNOT,MUX; opt_clean; tee -o {d}/gen_stat.txt stat; tee -o {d}/gen_ltp.txt ltp -noff")
    rc, out = sh(["yosys", "-q", "-p", ys], os.path.join(d, "yosys_generic.log"))
    if rc == 0:
        st = open(os.path.join(d, "gen_stat.txt")).read()
        m = re.search(r"Number of cells:\s+(\d+)", st) or re.search(r"(\d+)\s+cells", st)
        cells = {k: int(v) for k, v in re.findall(r"^\s+(\$_\w+_)\s+(\d+)\s*$", st, re.M)}
        res["gen_cells"] = int(m.group(1)) if m else None
        res["gen_ffs"] = sum(v for k, v in cells.items() if "DFF" in k)
        res["gen_logic"] = sum(v for k, v in cells.items() if "DFF" not in k)
        lt = open(os.path.join(d, "gen_ltp.txt")).read()
        m = re.search(r"Longest topological path .*?\(length=(\d+)\)", lt)
        res["gen_ltp_levels"] = int(m.group(1)) if m else None
    else:
        res["gen_error"] = out[-300:]

    # ---- 2a. ECP5 DUT only (area)
    ys = (f"read_verilog -sv {srcs}; hierarchy -top dut_top; synth_ecp5 -top dut_top -json {d}/dut.json; tee -o {d}/ecp5_dut_stat.txt stat")
    rc, out = sh(["yosys", "-q", "-p", ys], os.path.join(d, "yosys_ecp5_dut.log"))
    if rc == 0:
        st = open(os.path.join(d, "ecp5_dut_stat.txt")).read()
        g = lambda k: sum(int(x) for x in re.findall(r"^\s+" + k + r"\s+(\d+)\s*$", st, re.M))
        res["ecp5_lut4"] = g("LUT4")
        res["ecp5_ff"] = g("TRELLIS_FF")
        res["ecp5_dpr"] = g("TRELLIS_DPR16X4")
        res["ecp5_carry"] = g("CCU2C")
        res["ecp5_pfumx"] = g("PFUMX") + g("L6MUX21")
    else:
        res["ecp5_error"] = out[-300:]

    # ---- 2b. wrapped P&R
    if pnr and "ecp5_lut4" in res:
        wsv, nin, nout = wrapper(c)
        wp = os.path.join(d, "wrap.sv")
        open(wp, "w").write(wsv)
        ys = f"read_verilog -sv {' '.join(RTL)} {wp}; hierarchy -top synth_wrap; synth_ecp5 -top synth_wrap -json {d}/wrap.json; tee -o {d}/ecp5_wrap_stat.txt stat"
        rc, out = sh(["yosys", "-q", "-p", ys], os.path.join(d, "yosys_wrap.log"))
        res["shell_ffs"] = nin + ((nout + 15) // 16) * 16 + ((((nout + 15) // 16) + 15) // 16) * 16 + ((((nout + 15) // 16) + 15) // 16) + 1
        fm = []
        if rc == 0:
            for sd in seeds:
                t0 = time.time()
                rc2, o2 = sh(["nextpnr-ecp5", "--85k", "--package", "CABGA381", "--json", f"{d}/wrap.json", "--freq", str(FREQ),
                              "--seed", str(sd), "--timing-allow-fail"], os.path.join(d, f"pnr_seed{sd}.log"), timeout=2400)
                mm = re.findall(r"Max frequency for clock\s+'[^']*':\s+([\d.]+) MHz", o2)
                if mm:
                    fm.append(float(mm[-1]))
                else:
                    res.setdefault("pnr_notes", []).append(f"seed {sd}: no Fmax line (rc={rc2}) {o2[-200:]!r}")
            res["fmax_mhz"] = fm
            if fm:
                s = sorted(fm)
                res["fmax_min"], res["fmax_med"], res["fmax_max"] = s[0], _median(s), s[-1]
        else:
            res["wrap_error"] = out[-300:]
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", nargs="*")
    ap.add_argument("--seeds", default="1,2,3")
    ap.add_argument("--out", default=os.path.join(ROOT, "benchmarks", "meridian_qos", "results"))
    ap.add_argument("--nopnr", action="store_true")
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--collect", nargs="*", default=[], help="NAME=DIR: parse the artifacts of an earlier run instead of running")
    ap.add_argument("--merge", nargs="*", default=[], help="synth json files to merge into synth.json")
    a = ap.parse_args()
    if a.collect or a.merge:
        allr = []
        for jf in a.merge:
            allr += json.load(open(jf))
        for nd in a.collect:
            n, d = nd.split("=", 1)
            allr.append(collect(n, d))
        for r in allr:                                   # one definition of min / median / max for every row
            fl = sorted(r.get("fmax_mhz") or [])
            if fl:
                r["fmax_min"], r["fmax_med"], r["fmax_max"], r["n_seeds"] = fl[0], _median(fl), fl[-1], len(fl)
        order = {n: i for i, n in enumerate(CFGS)}
        allr.sort(key=lambda r: order[r["name"]])
        os.makedirs(a.out, exist_ok=True)
        json.dump(allr, open(os.path.join(a.out, "synth.json"), "w"), indent=1)
        for r in allr:
            print(f"{r['name']:12s} gates {r.get('gen_cells')} ltp {r.get('gen_ltp_levels')} lut4 {r.get('ecp5_lut4')} ff {r.get('ecp5_ff')} fmax {r.get('fmax_mhz')}")
        return
    seeds = [int(x) for x in a.seeds.split(",")]
    names = a.cfg or list(CFGS)
    os.makedirs(a.out, exist_ok=True)
    wd = tempfile.mkdtemp(prefix="mqos_syn_")
    res = []
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        fs = {ex.submit(run_cfg, n, CFGS[n], seeds, wd, not a.nopnr): n for n in names}
        for f in as_completed(fs):
            r = f.result()
            res.append(r)
            print(f"{r['name']:12s} gates {r.get('gen_cells')} ltp {r.get('gen_ltp_levels')} lut4 {r.get('ecp5_lut4')} ff {r.get('ecp5_ff')} "
                  f"fmax {r.get('fmax_mhz')}", flush=True)
    order = {n: i for i, n in enumerate(CFGS)}
    res.sort(key=lambda r: order[r["name"]])
    json.dump(res, open(os.path.join(a.out, "synth_part_" + "_".join(sorted(r["name"] for r in res)) + ".json"), "w"), indent=1)
    json.dump(res, open(os.path.join(a.out, "synth.json"), "w"), indent=1)
    print("work dir:", wd)


if __name__ == "__main__":
    main()
