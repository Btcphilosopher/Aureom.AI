// =============================================================================
// SilicaFlux Albion -- Project 83 -- Meridian :: sf_meridian_pkg
//
// Constants of the Albion transaction format as carried by Meridian (docs/meridian/02_PROTOCOL.md).
//
// Tool rules (same as the earlier SilicaFlux fabric projects, so Verilator, Yosys and
// other tools elaborate the RTL identically): this package holds localparams and functions
// written in the "assign to the function name" style only -- no structs, typedefs or `return`.
// =============================================================================
package sf_meridian_pkg;
  /* verilator lint_off UNUSEDPARAM */

  // ------------------------------------------------------------------ opcodes
  localparam int          OPW      = 2;
  localparam logic [1:0]  OP_READ  = 2'd0;   // read one DW-wide beat; the response carries data
  localparam logic [1:0]  OP_WRITE = 2'd1;   // acknowledged write: response after the target performed it
  // 2'd2, 2'd3 reserved: never forwarded, answered by the fabric with ST_PROTO / F_BADOP

  // ------------------------------------------------------------------ response status
  localparam int          STW        = 3;
  localparam logic [2:0]  ST_OKAY    = 3'd0;  // performed
  localparam logic [2:0]  ST_SLVERR  = 3'd1;  // slave failure reported by the target (no side effect)
  localparam logic [2:0]  ST_DECERR  = 3'd2;  // fabric: address does not decode, or target not reachable from this master
  localparam logic [2:0]  ST_DENIED  = 3'd3;  // fabric: Citadel denied / domain not bound to the port (never reached a target)
  localparam logic [2:0]  ST_TIMEOUT = 3'd4;  // fabric: request timeout, or target isolated after an earlier timeout
  localparam logic [2:0]  ST_PROTO   = 3'd5;  // fabric: protocol violation (reserved opcode, misaligned address,
                                              //         response echo mismatch)
  // 3'd6, 3'd7 reserved

  // ------------------------------------------------------------------ fault detail codes (error log, F_*)
  localparam int          FW           = 4;
  localparam logic [3:0]  F_NONE       = 4'd0;
  localparam logic [3:0]  F_NOMAP      = 4'd1;   // Citadel: no policy entry covers the address
  localparam logic [3:0]  F_PERM       = 4'd2;   // Citadel: covered, but the right (read / write) is missing
  localparam logic [3:0]  F_DOMAIN     = 4'd3;   // Citadel: covered, but not for this domain / master
  localparam logic [3:0]  F_PRIV       = 4'd4;   // Citadel: region needs a privileged access
  localparam logic [3:0]  F_SPOOF      = 4'd5;   // domain not bound to this master port (fabric check, before Citadel)
  localparam logic [3:0]  F_CITTMO     = 4'd6;   // Citadel did not answer in time (fail closed)
  localparam logic [3:0]  F_UNMAPPED   = 4'd8;   // address decodes to no target
  localparam logic [3:0]  F_NOROUTE    = 4'd9;   // decodes, but this master has no path to that target
  localparam logic [3:0]  F_MISALIGN   = 4'd10;  // address not aligned to the beat size
  localparam logic [3:0]  F_BADOP      = 4'd11;  // reserved opcode
  localparam logic [3:0]  F_ISO        = 4'd12;  // target isolated after a timeout (fast failure)
  localparam logic [3:0]  F_HOL        = 4'd13;  // request could not enter the fabric within the timeout
  localparam logic [3:0]  F_RSPTMO     = 4'd14;  // no response within the timeout
  localparam logic [3:0]  F_ECHO       = 4'd15;  // response echo (domain / opcode) or status field illegal

  // ------------------------------------------------------------------ protocol-violation events (V_*, one pulse each)
  localparam int          VW           = 8;
  localparam int          V_BADOP      = 0;      // reserved opcode presented by a master
  localparam int          V_MISALIGN   = 1;      // misaligned address presented by a master
  localparam int          V_TAGREUSE   = 2;      // master reused a tag that is still outstanding (request dropped, no response)
  localparam int          V_ORPHAN     = 3;      // response matching no outstanding request (incl. duplicates): consumed
  localparam int          V_ECHO       = 4;      // response echo mismatch: delivered as ST_PROTO
  localparam int          V_BADSRC     = 5;      // response with an out-of-range / unreachable src: consumed
  localparam int          V_SPOOF      = 6;      // master presented a domain that is not bound to its port
  localparam int          V_LATE       = 7;      // late response to a timed-out request: swallowed (informational)

  // ------------------------------------------------------------------ traffic classes (tc); larger = more urgent
  localparam int          TCW           = 3;
  localparam logic [2:0]  TC_BACKGROUND = 3'd0;   // background maintenance
  localparam logic [2:0]  TC_BULK       = 3'd1;   // bulk DMA
  localparam logic [2:0]  TC_COMPUTE    = 3'd2;   // compute traffic
  localparam logic [2:0]  TC_IO         = 3'd3;   // latency-sensitive I/O
  localparam logic [2:0]  TC_MGMT       = 3'd4;   // management

  // ------------------------------------------------------------------ arbitration modes
  localparam int          ARB_RR  = 0;            // plain round robin, bound N-1 other transfers
  localparam int          ARB_QOS = 1;            // class level, round robin inside a level, aging: bound STARVE+N-1

  // ------------------------------------------------------------------ Citadel modes
  localparam int          CIT_OFF  = 0;           // bring-up only: no permission check (domain binding check stays)
  localparam int          CIT_REF  = 1;           // reference policy table inside the fabric (sf_meridian_citadel_ref)
  localparam int          CIT_EXT  = 2;           // external Citadel through the cit_* ports

  // ------------------------------------------------------------------ performance counter map (sf_meridian_perf)
  // One flat bank, read through rd_sel.  Blocks: global | per master | per target | traffic matrix.
  localparam int PF_G   = 8;     // global counters
  localparam int PF_PM  = 24;    // counters per master
  localparam int PF_PT  = 8;     // counters per target
  // global
  localparam int PFG_CYCLES = 0, PFG_BUSY = 1, PFG_REQ = 2, PFG_CPL = 3, PFG_BYTES = 4, PFG_ARBSTALL = 5, PFG_VIOL = 6;
  // per master (offset inside the master's block)
  localparam int PFM_REQ = 0, PFM_CPL = 1, PFM_CPLERR = 2, PFM_DECERR = 3, PFM_DENIED = 4, PFM_TIMEOUT = 5,
                 PFM_PROTO = 6, PFM_SLVERR = 7, PFM_BYTES_WR = 8, PFM_BYTES_RD = 9, PFM_LAT_SUM = 10,
                 PFM_LAT_CNT = 11, PFM_LAT_MAX = 12, PFM_OUT_SUM = 13, PFM_OUT_MAX = 14, PFM_STALL_IN = 15,
                 PFM_V_BADOP = 16, PFM_V_MISALIGN = 17, PFM_V_TAGREUSE = 18, PFM_V_ORPHAN = 19, PFM_V_ECHO = 20,
                 PFM_V_SPOOF = 21, PFM_V_LATE = 22;
  // per target
  localparam int PFT_REQ = 0, PFT_BYTES = 1, PFT_ARBSTALL = 2, PFT_OCC_SUM = 3, PFT_OCC_MAX = 4, PFT_BUSY = 5,
                 PFT_BADSRC = 6;
  function automatic integer pf_m(input integer m, input integer k);
    begin pf_m = PF_G + m * PF_PM + k; end
  endfunction
  function automatic integer pf_t(input integer nm, input integer t, input integer k);
    begin pf_t = PF_G + nm * PF_PM + t * PF_PT + k; end
  endfunction
  function automatic integer pf_x(input integer nm, input integer nt, input integer m, input integer t);
    begin pf_x = PF_G + nm * PF_PM + nt * PF_PT + m * nt + t; end
  endfunction
  function automatic integer pf_n(input integer nm, input integer nt);
    begin pf_n = PF_G + nm * PF_PM + nt * PF_PT + nm * nt; end
  endfunction

  // ------------------------------------------------------------------ helpers
  // width of an index into n things (at least 1 bit)
  function automatic integer clog2c(input integer n);
    begin
      if (n > 1) clog2c = $clog2(n);
      else       clog2c = 1;
    end
  endfunction

  // number of set bits in a 32-bit vector
  function automatic integer popc32(input logic [31:0] v);
    integer k;
    begin
      popc32 = 0;
      for (k = 0; k < 32; k = k + 1) if (v[k]) popc32 = popc32 + 1;
    end
  endfunction

  /* verilator lint_on UNUSEDPARAM */
endpackage
