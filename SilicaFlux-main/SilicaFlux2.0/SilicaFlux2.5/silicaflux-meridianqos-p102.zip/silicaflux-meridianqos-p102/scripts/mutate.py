#!/usr/bin/env python3
"""Mutation check of the MeridianQoS regression.

Each mutant is ONE deliberate RTL defect (a textual substitution that must match exactly once).  For every mutant the
testbench is rebuilt from a patched copy of rtl/ and the configuration's tests are run (stopping at the first failing
test).  A mutant is KILLED when some test fails (or the build/run breaks), SURVIVED when everything passes.  Survivors
are holes in the tests (or equivalent mutants, which must be justified in reports/mutation.md).

    scripts/mutate.py [--only NAME ...] [--jobs N]
"""
import argparse, json, os, re, shutil, subprocess, sys, tempfile, time
from concurrent.futures import ThreadPoolExecutor, as_completed

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
from meridian_cfgs import CFGS  # noqa: E402

ORDER = ["basic", "regs", "latency_idle", "counters", "tagreuse", "errors", "saturate", "reset", "admission",
         "rand_clean", "rand_bp", "rand_err", "rand_gstall", "rand_reorder", "contention", "policy_switch", "floor", "classes"]

# name, file, old, new, description, configs (default: ref_2x2_m16)
M16, DOM = "ref_2x2_m16", "v_dom_sparse"   # m4t2_classes is used by the 4-class strict-order mutant
MUTANTS = [
 # ---- queue
 ("Q1_overflow",       "sf_meridian_queue.sv", "assign in_ready  = (cnt_q != CW'(DEPTH));", "assign in_ready  = 1'b1;", "queue never reports full (overflow)", [M16]),
 ("Q2_rdptr_stuck",    "sf_meridian_queue.sv", "if (pop)  rd_q <= inc(rd_q);", "if (pop)  rd_q <= rd_q;", "read pointer does not advance (duplicate delivery)", [M16]),
 ("Q3_push_unready",   "sf_meridian_queue.sv", "wire push = in_valid  && in_ready;", "wire push = in_valid;", "push accepted while full", [M16]),
 # ---- arbiter
 ("A1_age_offbyone",   "sf_meridian_arbiter.sv", ">= cfg_starve);", "> cfg_starve);", "aging threshold off by one", [M16]),
 ("A2_wrr_noreload",   "sf_meridian_arbiter.sv", "reload = pol_wrr && (|reqc) && !(|(reqc & credit_nz));", "reload = 1'b0;", "WRR credits never reloaded", [M16]),
 ("A3_weight0",        "sf_meridian_arbiter.sv", "wt_v[k*WTW +: WTW] = (cfg_weight[k*WTW +: WTW] == '0) ? WTW'(1) : cfg_weight[k*WTW +: WTW];", "wt_v[k*WTW +: WTW] = cfg_weight[k*WTW +: WTW];", "a zero weight switches a class off", [M16]),
 ("A4_strict_reversed","sf_meridian_arbiter.sv", "for (int k = 2; k >= 0; k--) if (reqc[k]) csel = 2'(k);\n        for (int i = 0; i < N; i++)\n          elig[i] = req[i] && (cls[i*2 +: 2] == csel);\n        use_cptr = 1'b1;\n      end\n    end else if (pol_wrr)",
                        "for (int k = 0; k <= 2; k++) if (reqc[k]) csel = 2'(k);\n        for (int i = 0; i < N; i++)\n          elig[i] = req[i] && (cls[i*2 +: 2] == csel);\n        use_cptr = 1'b1;\n      end\n    end else if (pol_wrr)", "strict priority picks the LEAST urgent class", ["m4t2_classes"]),
 ("A5_rr_ptr_stuck",   "sf_meridian_arbiter.sv", "gptr_q <= (gidx == IW'(N - 1)) ? '0 : gidx + IW'(1);", "gptr_q <= gptr_q;", "global round-robin pointer never advances", [M16]),
 ("A6_credit_nodec",   "sf_meridian_arbiter.sv", "<= (reload ? wt_v[k*WTW +: WTW] : credit_q[k*WTW +: WTW]) - WTW'(1);", "<= (reload ? wt_v[k*WTW +: WTW] : credit_q[k*WTW +: WTW]);", "WRR credit never consumed (strict priority in disguise)", [M16]),
 ("A7_aging_off",      "sf_meridian_arbiter.sv", "urgent[i] = pol_strict && (cfg_starve != '0) &&", "urgent[i] = 1'b0 && (cfg_starve != '0) &&", "strict-priority aging disabled", [M16]),
 # ---- router
 ("R1_src_stamp",      "sf_meridian_router.sv", ".in_data  ({a_gidx, win_req}),", ".in_data  ({{SRCW{1'b0}}, win_req}),", "source id not stamped (responses misrouted)", [M16]),
 ("R2_payload_mux",    "sf_meridian_router.sv", "if (a_grant[m]) win = xq_od[(m*NT + t)*XW +: XW];", "if (a_grant[m]) win = xq_od[(((m+1)%NM)*NT + t)*XW +: XW];", "payload of the wrong master forwarded", [M16]),
 ("R3_pop_unready",    "sf_meridian_router.sv", "xq_or[m*NT + t] = a_grant[m] && eq_ir[t];", "xq_or[m*NT + t] = a_grant[m];", "crosspoint entry popped without being transferred (loss)", [M16]),
 ("R4_resp_route",     "sf_meridian_router.sv", "if (trq_ov[t] && hsrc == SRCW'(m) && CONN[m*NT + t]) begin", "if (trq_ov[t] && hsrc != SRCW'(m) && CONN[m*NT + t]) begin", "responses routed to the wrong master", [M16]),
 ("R5_cong_never",     "sf_meridian_router.sv", ">= OCW'(cfg_cong_hi)) cong_q <= 1'b1;", "> OCW'(8'd250)) cong_q <= 1'b1;", "congestion flag never rises", [M16]),
 # ---- master port
 ("P1_no_binding",     "sf_meridian_mport.sv", "spoof     = !DOM_ALLOW[s_dom];", "spoof     = 1'b0;", "domain binding removed", [DOM]),
 ("P2_guard_ignored",  "sf_meridian_mport.sv", "do_push  = v_pop && grd_rsp_ok;", "do_push  = v_pop;", "guard verdict ignored (denied requests forwarded)", [M16]),
 ("P3_deny_status",    "sf_meridian_mport.sv", "sst_q[i*3 +: 3]          <= ST_DENIED;", "sst_q[i*3 +: 3]          <= ST_DECERR;", "wrong status for a guard denial", [M16]),
 ("P4_tagreuse_off",   "sf_meridian_mport.sv", "if (sv_q[i] && stag_q[i*TAGW +: TAGW] == s_tag) tag_busy = 1'b1;", "if (1'b0 && stag_q[i*TAGW +: TAGW] == s_tag) tag_busy = 1'b1;", "tag reuse not detected", [M16]),
 ("P5_echo_off",       "sf_meridian_mport.sv", "echo_bad  = (r_dom != x_dom) || (r_op != x_op) || (r_st > ST_SLVERR);", "echo_bad  = 1'b0;", "response echo / status check removed", [M16]),
 ("P6_inorder_broken", "sf_meridian_mport.sv", "assign dsel_valid = ordq_ov && sd_q[o_idx];", "assign dsel_valid = ordq_ov && (|(sv_q & sd_q));", "in-order delivery ignores completion of the head", [M16]),
 ("P7_limit_ignored",  "sf_meridian_mport.sv", "adm_ok      = (32'(ncls_v[cls_eff*OCW +: OCW]) < 32'(lim));", "adm_ok      = 1'b1;", "per-class outstanding limit ignored", [M16]),
 ("P8_floor_ignored",  "sf_meridian_mport.sv", "cls_eff = (cls_raw < cfg_floor) ? cfg_floor : cls_raw;", "cls_eff = cls_raw;", "class floor ignored (a master can escalate its class)", [M16]),
 ("P9_tcmap_ignored",  "sf_meridian_mport.sv", "cls_raw = cfg_tcmap[s_tc*2 +: 2];", "cls_raw = s_tc[1:0];", "tc -> class map ignored", [M16]),
 ("P10_no_reservation","sf_meridian_mport.sv", "xroom       = (32'(xq_cnt[dec_tgt*XCW +: XCW]) + 32'(resv_q[dec_tgt*XCW +: XCW])) < XQ_DEPTH;", "xroom       = 1'b1;", "crosspoint space not reserved (queue overflow)", [M16]),
 ("P11_misalign_off",  "sf_meridian_mport.sv", "local_err = bad_op || dec_misal || spoof || unmapped || noroute;", "local_err = bad_op || spoof || unmapped || noroute;", "misaligned requests forwarded", [M16]),
 ("P12_noroute_off",   "sf_meridian_mport.sv", "noroute   = dec_hit && !dec_reach;", "noroute   = 1'b0;", "topology (no-route) check removed", [DOM]),
 ("P13_timestamp",     "sf_meridian_mport.sv", "sts_q[i*LATW +: LATW]    <= s_ts;", "sts_q[i*LATW +: LATW]    <= cyc;", "latency timestamp taken at dispatch, not at accept", [M16]),
 ("P14_throttle_off",  "sf_meridian_mport.sv", "held_cong_c = cfg_cong_en && cong[dec_tgt] && (cls_eff >= cfg_thr_cls);", "held_cong_c = 1'b0;", "congestion throttle disabled", [M16]),
 ("P15_badop_status",  "sf_meridian_mport.sv", "if (bad_op)         begin err_status = ST_PROTO;", "if (bad_op)         begin err_status = ST_DECERR;", "wrong status for a reserved opcode", [M16]),
 # ---- decoder
 ("D1_reach_ignored",  "sf_meridian_decoder.sv", "reach      = hit && CONN[tgt];", "reach      = hit;", "decoder ignores the topology", [DOM]),
 ("D2_align_bit0",     "sf_meridian_decoder.sv", "(addr[OFF-1:0] != '0)", "(addr[OFF-1:1] != '0)", "misalignment of bit 0 not detected", [M16]),
 # ---- register block
 ("G1_priv_off",       "sf_meridian_qos_regs.sv", "else if (!cfg_priv && !(public_reg && !cfg_write)) reject = 1'b1;", "else if (1'b0) reject = 1'b1;", "privilege check removed", [M16]),
 ("G2_lock_off",       "sf_meridian_qos_regs.sv", "else if (cfg_write && is_cfg && lock_q)      reject = 1'b1;", "else if (1'b0) reject = 1'b1;", "configuration lock not enforced", [M16]),
 ("G3_policy3_legal",  "sf_meridian_qos_regs.sv", "if (cfg_wdata[1:0] == 2'd3) legal_val = 1'b0;", "", "reserved policy accepted", [M16]),
 ("G4_w1c_broken",     "sf_meridian_qos_regs.sv", "stat_q <= stat_q & ~cfg_wdata[3:0];", "stat_q <= stat_q;", "sticky status cannot be cleared", [M16]),
 ("G5_default_weights","sf_meridian_qos.sv", "parameter logic [31:0]                 DEF_WEIGHTS   = {8'd1, 8'd2, 8'd4, 8'd8},", "parameter logic [31:0]                 DEF_WEIGHTS   = {8'd2, 8'd2, 8'd4, 8'd8},", "wrong reset value of the weights", [M16]),
 ("G6_perm_nolock",    "sf_meridian_qos_regs.sv", "if (cfg_wdata[sf_meridian_qos_pkg::CTRL_LOCK]) lock_q <= 1'b1;", "", "lock bit cannot be set", [M16]),
 # ---- top-level wiring
 ("T1_status_wiring",  "sf_meridian_qos.sv", "assign m_rsp_status[m*3 +: 3]      = out_word[DW +: 3];", "assign m_rsp_status[m*3 +: 3]      = out_word[DW + 1 +: 3];", "response status mis-wired", [M16]),
 ("T2_tc_wiring",      "sf_meridian_qos.sv", "assign t_req_tc[t*3 +: 3]           = eo[DW/8 + DW + AW +: 3];", "assign t_req_tc[t*3 +: 3]           = eo[DW/8 + DW + AW + 1 +: 3];", "traffic class mis-wired to the target", [M16]),
 ("T3_priv_wiring",    "sf_meridian_qos.sv", "assign t_req_priv[t]                = eo[DW/8 + DW + AW + 3];", "assign t_req_priv[t]                = 1'b0;", "privilege metadata dropped before the target", [M16]),
 ("T4_dom_wiring",     "sf_meridian_qos.sv", "assign t_req_dom[t*DOMW +: DOMW]    = eo[DW/8 + DW + AW + 3 + 1 +: DOMW];", "assign t_req_dom[t*DOMW +: DOMW]    = '0;", "protection-domain metadata dropped before the target", [M16]),
]


def run_units(fname, d):
    """Unit benches covering a file: tb_arb (arbiter), tb_queue_diff (queue).  Returns the name of the bench that fails."""
    rtl = os.path.join(d, "rtl", "meridian_qos")
    p22 = os.path.join(ROOT, "third_party", "p22")
    tb = os.path.join(ROOT, "tests", "meridian_qos", "tb")
    jobs = []
    if fname == "sf_meridian_arbiter.sv":
        for n, one in ((4, 1), (5, 0), (3, 0)):
            jobs.append((f"tb_arb(N={n},ONECLS={one})", "tb_arb", [f"-GN={n}", f"-GONECLS={one}"],
                         [f"{p22}/sfn_pkg.sv", f"{p22}/sfn_qos_arbiter.sv", f"{rtl}/sf_meridian_qos_pkg.sv", f"{rtl}/sf_meridian_arbiter.sv", f"{tb}/tb_arb.sv"], ["+seed=7"]))
    if fname == "sf_meridian_queue.sv":
        jobs.append(("tb_queue_diff", "tb_queue_diff", [],
                     [f"{p22}/sfn_pkg.sv", f"{p22}/sfn_fifo.sv", f"{rtl}/sf_meridian_qos_pkg.sv", f"{rtl}/sf_meridian_queue.sv", f"{tb}/tb_queue_diff.sv"], []))
    for label, top, gargs, files, plus in jobs:
        bd = os.path.join(d, "u_" + re.sub(r"\W", "_", label))
        r = subprocess.run(["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "--top-module", top,
                            "--Mdir", bd] + gargs + files + ["-o", "V"], capture_output=True, text=True)
        if r.returncode != 0:
            return label + " (build error)"
        out = subprocess.run([os.path.join(bd, "V")] + plus, capture_output=True, text=True, timeout=600)
        txt = out.stdout + out.stderr
        if not re.search(r"^PASS ", txt, re.M) or re.search(r"^FAIL", txt, re.M):
            return label
    return ""


def run_mutant(m, tmp_root):
    name, fname, old, new, desc, cfgs = m
    d = os.path.join(tmp_root, name)
    rtl = os.path.join(d, "rtl", "meridian_qos")
    shutil.copytree(os.path.join(ROOT, "rtl", "meridian_qos"), rtl)
    p = os.path.join(rtl, fname)
    src = open(p).read()
    if src.count(old) != 1:
        return name, "BAD", f"pattern matches {src.count(old)} times", desc, ""
    open(p, "w").write(src.replace(old, new))
    for cfg in cfgs:
        ov, tests = CFGS[cfg]
        bdir = os.path.join(d, "build_" + cfg)
        env = dict(os.environ, RTL_DIR=os.path.join(d, "rtl"))
        r = subprocess.run(["bash", os.path.join(ROOT, "scripts", "build_tb.sh"), bdir] + [f"-G{k}={v}" for k, v in ov.items()],
                           capture_output=True, text=True, env=env)
        if r.returncode != 0:
            return name, "KILLED", "build/elaboration error", desc, ""
        for t in sorted(set(tests), key=lambda x: ORDER.index(x) if x in ORDER else 99):
            try:
                out = subprocess.run([os.path.join(bdir, "Vtb"), f"+TEST={t}", "+seed=1"], capture_output=True, text=True, timeout=600)
                txt = out.stdout + out.stderr
            except subprocess.TimeoutExpired:
                shutil.rmtree(d, ignore_errors=True)
                return name, "KILLED", f"{cfg}:{t} (timeout)", desc, t
            if not re.search(r"^PASS " + re.escape(t), txt, re.M) or re.search(r"^FAIL", txt, re.M):
                first = re.search(r"^FAIL.*", txt, re.M)
                shutil.rmtree(d, ignore_errors=True)
                return name, "KILLED", f"{cfg}:{t}", desc, (first.group(0)[:110] if first else "")
    # system regression passed: try the unit benches that cover the mutated file
    ur = run_units(fname, d)
    shutil.rmtree(d, ignore_errors=True)
    if ur:
        return name, "KILLED", ur, desc, ""
    return name, "SURVIVED", "", desc, ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    ap.add_argument("--out", default=os.path.join(ROOT, "reports"))
    a = ap.parse_args()
    muts = [m for m in MUTANTS if not a.only or m[0] in a.only]
    tmp_root = tempfile.mkdtemp(prefix="mqos_mut_", dir=os.environ.get("MUT_TMP"))
    t0 = time.time()
    res = []
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        futs = [ex.submit(run_mutant, m, tmp_root) for m in muts]
        for f in as_completed(futs):
            r = f.result()
            res.append(r)
            print(f"{r[1]:9s} {r[0]:20s} {r[2]}  {r[4]}", flush=True)
    shutil.rmtree(tmp_root, ignore_errors=True)
    order = {m[0]: i for i, m in enumerate(MUTANTS)}
    res.sort(key=lambda r: order[r[0]])
    killed = sum(1 for r in res if r[1] == "KILLED")
    lines = ["# MeridianQoS mutation check", "",
             "Each mutant is one deliberate RTL defect (`scripts/mutate.py`); the regression of its configuration must fail.",
             "", f"**{killed} / {len(res)} mutants killed** (wall time {time.time()-t0:.0f} s).", "",
             "| mutant | defect | result | caught by |", "|---|---|---|---|"]
    for n, st, where, desc, first in res:
        lines.append(f"| `{n}` | {desc} | {st} | {where} |")
    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, "mutation.md"), "w") as f:
        f.write("\n".join(lines) + "\n")
    with open(os.path.join(a.out, "mutation.json"), "w") as f:
        json.dump([{"name": r[0], "result": r[1], "where": r[2], "defect": r[3]} for r in res], f, indent=1)
    print(f"\n{killed}/{len(res)} mutants killed")
    sys.exit(0 if killed == len(res) else 1)


if __name__ == "__main__":
    main()
