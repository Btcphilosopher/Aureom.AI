#!/bin/bash
# build_tb.sh <builddir> [verilator -G overrides...]   -- builds the system testbench into <builddir>
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
D="$1"; shift
mkdir -p "$D"
if [ -n "$RTL_DIR" ]; then FILES="$(sed "s|^rtl/|$RTL_DIR/|" "$ROOT/rtl/files.f")"; else FILES="$(sed "s|^|$ROOT/|" "$ROOT/rtl/files.f")"; fi
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN --top-module tb_meridian_qos --Mdir "$D" \
  "$@" $FILES "$ROOT/tests/meridian_qos/tb/tb_meridian_qos.sv" -o Vtb > "$D/build.log" 2>&1 || { tail -40 "$D/build.log"; exit 1; }
