#!/usr/bin/env python3
"""MeridianQoS formal driver: Yosys -> SMT2 -> yosys-smtbmc (z3 / cvc5), one job per property group.

    scripts/formal.py [--only NAME ...] [--jobs N] [--list]

Each job is one of
   pdr    ABC property-directed reachability (IC3) on an AIGER model: "PASSED" = UNBOUNDED proof (an inductive invariant
          was found and checked), "FAILED" = counterexample.  Used for control logic (arbiter, fabric).
   prove  k-induction by yosys-smtbmc + cvc5 ("PASSED" = unbounded proof; used where the invariants are written by hand,
          e.g. the queue).
   bmc    bounded model check to DEPTH cycles from reset, by ABC `bmc3` ("PASSED" = no assertion can fail within DEPTH
          cycles; NOT an unbounded proof).
   mut-*  the same property run on a deliberately broken copy of the RTL: it MUST fail (the property can see the bug).
Results go to reports/formal.md / formal.json.  Everything here is machine-checkable: rerun the script.
"""
import argparse, json, os, re, subprocess, sys, time, tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BMC_SECS = 1800          # per bounded-model-check job (ABC bmc3 -T)
R = os.path.join(ROOT, "rtl", "meridian_qos")
F = os.path.join(ROOT, "formal", "meridian_qos")
ALL = [f"{R}/{n}.sv" for n in ("sf_meridian_qos_pkg", "sf_meridian_queue", "sf_meridian_slice", "sf_meridian_arbiter",
                                "sf_meridian_decoder", "sf_meridian_router", "sf_meridian_mport", "sf_meridian_qos_regs",
                                "sf_meridian_perf", "sf_meridian_qos")]
PKGQ = [f"{R}/sf_meridian_qos_pkg.sv", f"{R}/sf_meridian_queue.sv"]
PKGA = [f"{R}/sf_meridian_qos_pkg.sv", f"{R}/sf_meridian_arbiter.sv"]
PKGD = [f"{R}/sf_meridian_qos_pkg.sv", f"{R}/sf_meridian_decoder.sv"]

# name, kind, top, files, chparams, depth, solver (cvc5), claim
JOBS = [
 # ---- queue: hand-written inductive invariants (embedded FORMAL block of sf_meridian_queue), unbounded k-induction (cvc5)
 ("queue_d1",   "prove", "sf_meridian_queue", PKGQ, {"W": 4, "DEPTH": 1}, 8, "cvc5", "FIFO depth 1: no overflow / underflow, pointer consistency, order + integrity of any entry, stability"),
 ("queue_d2",   "prove", "sf_meridian_queue", PKGQ, {"W": 4, "DEPTH": 2}, 8, "cvc5", "FIFO depth 2"),
 ("queue_d3",   "prove", "sf_meridian_queue", PKGQ, {"W": 4, "DEPTH": 3}, 8, "cvc5", "FIFO depth 3 (not a power of two)"),
 ("queue_d4",   "prove", "sf_meridian_queue", PKGQ, {"W": 4, "DEPTH": 4}, 8, "cvc5", "FIFO depth 4"),
 ("queue_d8",   "prove", "sf_meridian_queue", PKGQ, {"W": 4, "DEPTH": 8}, 8, "cvc5", "FIFO depth 8"),
 # ---- decoder (combinational: all addresses)
 ("decoder",    "prove", "fv_decoder", PKGD + [f"{F}/fv_decoder.sv"], {}, 2, "cvc5", "no illegal destination: tgt < NT, reach => hit and CONN, lowest window wins, alignment"),
 # ---- arbiter: ABC PDR, unbounded, under the documented fairness assumptions
 ("arb_rr3",     "pdr", "fv_arbiter", PKGA + [f"{F}/fv_arbiter.sv"], {"N": 3, "POL": 0, "S": 0}, 0, "abc", "RR N=3: grant one-hot / subset of requests, work conserving, wait <= N-1"),
 ("arb_rr4",     "pdr", "fv_arbiter", PKGA + [f"{F}/fv_arbiter.sv"], {"N": 4, "POL": 0, "S": 0}, 0, "abc", "RR N=4"),
 ("arb_strict3", "pdr", "fv_arbiter", PKGA + [f"{F}/fv_arbiter.sv"], {"N": 3, "POL": 2, "S": 3}, 0, "abc", "STRICT + aging S=3, N=3: wait <= S+N-1"),
 ("arb_strict4", "pdr", "fv_arbiter", PKGA + [f"{F}/fv_arbiter.sv"], {"N": 4, "POL": 2, "S": 4}, 0, "abc", "STRICT + aging S=4, N=4: wait <= S+N-1"),
 ("arb_wrr3",    "pdr", "fv_arbiter", PKGA + [f"{F}/fv_arbiter.sv"], {"N": 3, "POL": 1, "S": 0, "WTS": 16908546}, 0, "abc", "WRR N=3 weights 2/1/2/1: wait <= (N-1)+(ceil(N/w)+1)(W-w)"),
 ("arb_wrr4",    "pdr", "fv_arbiter", PKGA + [f"{F}/fv_arbiter.sv"], {"N": 4, "POL": 1, "S": 0, "WTS": 16843009}, 0, "abc", "WRR N=4 weights 1/1/1/1"),

 # ---- the same properties on deliberately broken arbiters: each MUST be caught
 ("mut_rr_ptr_stuck",   "mut-pdr", "fv_arbiter", PKGA + [f"{F}/fv_arbiter.sv"], {"N": 3, "POL": 0, "S": 0}, 0, "abc", "RR with a pointer that never advances",
     ("sf_meridian_arbiter.sv", "gptr_q <= (gidx == IW'(N - 1)) ? '0 : gidx + IW'(1);", "gptr_q <= gptr_q;")),
 ("mut_aging_offbyone", "mut-pdr", "fv_arbiter", PKGA + [f"{F}/fv_arbiter.sv"], {"N": 3, "POL": 2, "S": 3}, 0, "abc", "strict + aging with the threshold off by one (bound S+N would be needed)",
     ("sf_meridian_arbiter.sv", ">= cfg_starve);", "> cfg_starve);")),
 ("mut_aging_off",      "mut-pdr", "fv_arbiter", PKGA + [f"{F}/fv_arbiter.sv"], {"N": 3, "POL": 2, "S": 3}, 0, "abc", "strict priority with aging disabled",
     ("sf_meridian_arbiter.sv", "urgent[i] = pol_strict && (cfg_starve != '0) &&", "urgent[i] = 1'b0 && (cfg_starve != '0) &&")),
 ("mut_wrr_noreload",   "mut-pdr", "fv_arbiter", PKGA + [f"{F}/fv_arbiter.sv"], {"N": 3, "POL": 1, "S": 0, "WTS": 16908546}, 0, "abc", "WRR whose credits are never reloaded (work conservation lost)",
     ("sf_meridian_arbiter.sv", "reload = pol_wrr && (|reqc) && !(|(reqc & credit_nz));", "reload = 1'b0;")),
 ("mut_wrr_nodecrement","mut-pdr", "fv_arbiter", PKGA + [f"{F}/fv_arbiter.sv"], {"N": 3, "POL": 1, "S": 0, "WTS": 16908546}, 0, "abc", "WRR whose credit is never consumed (a class can starve the others)",
     ("sf_meridian_arbiter.sv", "<= (reload ? wt_v[k*WTW +: WTW] : credit_q[k*WTW +: WTW]) - WTW'(1);", "<= (reload ? wt_v[k*WTW +: WTW] : credit_q[k*WTW +: WTW]);")),
 ("mut_two_grants",     "mut-pdr", "fv_arbiter", PKGA + [f"{F}/fv_arbiter.sv"], {"N": 3, "POL": 0, "S": 0}, 0, "abc", "arbiter that grants every requester at or after the pointer (not one-hot)",
     ("sf_meridian_arbiter.sv", "grant  = has_up ? first_u : first_e;", "grant  = has_up ? upper : first_e;")),
 # ---- fabric (fv_qos): black-box properties on the 2 x 2 tiny configuration (ABC bmc3 / pdr)
 ("fabric_noguard", "bmc", "fv_qos", ALL + [f"{F}/fv_qos.sv"], {"GUARD": 0, "NOLOSS": 0}, 12, "abc", "no duplication, no spurious request, response routing, identity, destination, stability, no overflow (no guard)"),
 ("fabric_guard",   "bmc", "fv_qos", ALL + [f"{F}/fv_qos.sv"], {"GUARD": 1, "NOLOSS": 0}, 12, "abc", "same with the MemoryGuard pipelined, denial possible"),
 ("fabric_decpipe", "bmc", "fv_qos", ALL + [f"{F}/fv_qos.sv"], {"GUARD": 1, "NOLOSS": 0, "DECP": 1}, 12, "abc", "same with the decode register stage"),
 ("fabric_bound",   "bmc", "fv_qos", ALL + [f"{F}/fv_qos.sv"], {"GUARD": 1, "NOLOSS": 1, "KMAX": 9}, 18, "abc", "no request loss, bounded completion: one master, one outstanding transaction, ready targets answering within 2 cycles, guard answering in 1: delivered within 9 cycles of acceptance"),
 ("fabric_bound_ng","bmc", "fv_qos", ALL + [f"{F}/fv_qos.sv"], {"GUARD": 0, "NOLOSS": 1, "KMAX": 8}, 18, "abc", "the same without a guard: delivered within 8 cycles of acceptance"),
 ("mut_bound_tight",    "mut-bmc", "fv_qos", ALL + [f"{F}/fv_qos.sv"], {"GUARD": 1, "NOLOSS": 1, "KMAX": 8}, 18, "abc", "the same bound one cycle too small (8 instead of 9) MUST fail: the bound is tight, the property is not vacuous"),
 ("mut_bound_ng_tight", "mut-bmc", "fv_qos", ALL + [f"{F}/fv_qos.sv"], {"GUARD": 0, "NOLOSS": 1, "KMAX": 7}, 18, "abc", "no guard, bound 7 instead of 8 MUST fail"),
]


def aiger(job, wd, files):
    name, kind, top, _, params, depth, solver, claim = job[:8]
    chp = " ".join(f"-chparam {k} {v}" for k, v in params.items())
    aig = os.path.join(wd, "m.aig")
    ys = (f"read_verilog -sv -formal {' '.join(files)}; hierarchy -check -top {top} {chp}; prep -flatten -top {top}; "
          f"async2sync; dffunmap; memory_map; techmap; dfflegalize -cell $_DFF_P_ 01; opt -fast -noff; aigmap; opt -fast -noff; "
          f"write_aiger -zinit {aig}")
    r = subprocess.run(["yosys", "-q", "-p", ys], capture_output=True, text=True)
    return r, aig


def run(job, outdir):
    name, kind, top, files, params, depth, solver, claim = job[:8]
    mut = job[8] if len(job) > 8 else None
    wd = os.path.join(outdir, name)
    os.makedirs(wd, exist_ok=True)
    t0 = time.time()
    if mut:   # a copy of the RTL with one planted defect
        import shutil
        fname, old, new = mut
        src = open(os.path.join(R, fname)).read()
        assert src.count(old) == 1, f"mutation pattern for {name} matches {src.count(old)} times"
        md = os.path.join(wd, "rtl")
        os.makedirs(md, exist_ok=True)
        files = [os.path.join(md, os.path.basename(f)) if f.startswith(R) else f for f in files]
        for f0 in ALL:
            shutil.copy(f0, md)
        open(os.path.join(md, fname), "w").write(src.replace(old, new))
    if kind in ("pdr", "bmc") or kind.startswith("mut-"):
        r, aig = aiger(job, wd, files)
        if r.returncode != 0:
            return {"name": name, "kind": kind, "claim": claim, "status": "ERROR", "detail": (r.stdout + r.stderr)[-300:], "secs": time.time() - t0, "depth": depth, "solver": "abc"}
        eng = "pdr" if kind in ("pdr", "mut-pdr") else f"bmc3 -v -F {depth} -T {BMC_SECS}"   # -T: ABC stops cleanly and reports the frames it finished
        p = subprocess.run(["bash", "-c", f"ulimit -v 9000000; exec timeout {BMC_SECS + 100} yosys-abc -c \"$0\"", f"read_aiger {aig}; fold; strash; {eng}"],
                           capture_output=True, text=True, timeout=BMC_SECS + 300)
        out = p.stdout + p.stderr
        open(os.path.join(wd, "abc.log"), "w").write(out)
        proved = "Property proved" in out
        asserted = re.search(r"Output \d+ of miter .*? was asserted in frame (\d+)", out)
        noassert = re.search(r"No output asserted in (\d+) frames", out)
        disproved = bool(asserted) or "Property DISPROVED" in out
        if kind in ("pdr", "mut-pdr"):
            status = "PASSED" if proved else ("FAILED" if disproved else "UNKNOWN")
        else:
            reached = int(noassert.group(1)) if noassert else 0
            status = "FAILED" if asserted else ("PASSED" if (noassert and reached >= depth) else "UNKNOWN")
        if kind.startswith("mut-"):                      # expected to FAIL: a caught mutant is a success
            status = "CAUGHT" if status == "FAILED" else ("MISSED" if status == "PASSED" else status)
        return {"name": name, "kind": kind, "claim": claim, "status": status, "detail": (f"counterexample in frame {asserted.group(1)}" if asserted else
                   (f"no counterexample in the first {reached} of {depth} frames; time limit reached (result is UNKNOWN beyond that)" if (kind == "bmc" and status == "UNKNOWN") else "")),
                "secs": time.time() - t0, "depth": depth, "solver": "abc"}
    # ---- yosys-smtbmc flow (k-induction)
    smt = os.path.join(wd, "m.smt2")
    chp = " ".join(f"-chparam {k} {v}" for k, v in params.items())
    # same flow as DomainGuard (Module 97): memories stay native SMT arrays (-nordff); cvc5 is the solver (z3 4.8.12 hangs
    # while loading the Yosys transition-relation encoding of these designs)
    ys = (f"read_verilog -sv -formal {' '.join(files)}; hierarchy -check -top {top} {chp}; prep -flatten -nordff -top {top}; "
          f"async2sync; dffunmap; opt_clean; write_smt2 -wires {smt}")
    r = subprocess.run(["yosys", "-q", "-p", ys], capture_output=True, text=True)
    if r.returncode != 0:
        return {"name": name, "kind": kind, "claim": claim, "status": "ERROR", "detail": (r.stdout + r.stderr)[-400:], "secs": time.time() - t0, "depth": depth}
    log = os.path.join(wd, "smtbmc.log")
    cmd = ["yosys-smtbmc", "-s", solver, "-i", "-t", str(depth), smt]
    cmd = ["bash", "-c", "ulimit -v 9000000; exec timeout 1500 \"$@\"", "_"] + cmd
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=1700)
    out = p.stdout + p.stderr
    open(log, "w").write(out)
    passed = "Status: PASSED" in out
    failed = "Status: FAILED" in out
    status = "PASSED" if passed and not failed else ("FAILED" if failed else "UNKNOWN")
    m = re.search(r"Assert failed in [^\n]*", out) if failed else None
    return {"name": name, "kind": kind, "claim": claim, "status": status, "detail": m.group(0) if m else "",
            "secs": time.time() - t0, "depth": depth, "solver": solver}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--jobs", type=int, default=1, help="parallel solver jobs (memory heavy; 1 is safe)")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--out", default=os.path.join(ROOT, "reports"))
    ap.add_argument("--update", action="store_true", help="keep the results already in OUT/formal.json for the jobs not run now")
    a = ap.parse_args()
    jobs = [j for j in JOBS if not a.only or j[0] in a.only]
    if a.list:
        for j in jobs:
            print(j[0], j[1], j[7])
        return
    od = tempfile.mkdtemp(prefix="mqos_fv_")
    res = []
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        fs = {ex.submit(run, j, od): j for j in jobs}
        for f in as_completed(fs):
            r = f.result()
            res.append(r)
            print(f"{r['status']:8s} {r['name']:18s} {r['kind']:6s} depth {r['depth']:3d} {r['secs']:6.0f}s  {r['detail']}", flush=True)
    order = {j[0]: i for i, j in enumerate(JOBS)}
    os.makedirs(a.out, exist_ok=True)
    if a.update and os.path.exists(os.path.join(a.out, "formal.json")):
        now = {r["name"] for r in res}
        res += [r for r in json.load(open(os.path.join(a.out, "formal.json"))) if r["name"] not in now and r["name"] in order]
    res.sort(key=lambda r: order[r["name"]])
    with open(os.path.join(a.out, "formal.json"), "w") as f:
        json.dump(res, f, indent=1)
    lines = ["# MeridianQoS formal results", "",
             "Generated by `scripts/formal.py` (Yosys front end; cvc5 k-induction; ABC PDR and bmc3).  `prove` = k-induction (unbounded when PASSED); `pdr` = property-directed reachability",
             "(unbounded when PASSED); `bmc` = bounded model check from reset (no assertion can fail within DEPTH cycles of reset: **NOT** an unbounded proof; UNKNOWN = the time limit",
             "was reached first, the frames cleared are stated); `mut-*` = the same property on a deliberately broken design or a deliberately too-small bound: it MUST fail (CAUGHT).", "",
             "| job | method | depth | result | time | what is checked | note |", "|---|---|---|---|---|---|---|"]
    for r in res:
        lines.append(f"| `{r['name']}` | {r['kind']} | {r['depth']} | **{r['status']}** | {r['secs']:.0f} s | {r['claim']} | {r.get('detail', '')} |")
    with open(os.path.join(a.out, "formal.md"), "w") as f:
        f.write("\n".join(lines) + "\n")
    bad = [r for r in res if r["status"] not in ("PASSED", "CAUGHT")]
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
