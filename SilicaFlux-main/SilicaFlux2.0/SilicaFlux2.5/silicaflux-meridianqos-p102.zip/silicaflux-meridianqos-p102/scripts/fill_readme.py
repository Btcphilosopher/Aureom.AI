#!/usr/bin/env python3
"""Fill the results block of README.md from the generated reports (reports/*.json, benchmarks/meridian_qos/results/*).
Nothing is typed by hand: every number comes from a file a script wrote.  Idempotent (replaces the block between
<!--RESULTS--> and <!--/RESULTS-->, or the @@RESULTS@@ placeholder)."""
import json, os, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REP = os.path.join(ROOT, "reports")
RES = os.path.join(ROOT, "benchmarks", "meridian_qos", "results")


def jload(p):
    return json.load(open(p)) if os.path.exists(p) else None


def main():
    reg = jload(os.path.join(REP, "regression.json"))
    mut = jload(os.path.join(REP, "mutation.json"))
    frm = jload(os.path.join(REP, "formal.json"))
    bench = jload(os.path.join(RES, "bench.json"))
    synth = {r["name"]: r for r in (jload(os.path.join(RES, "synth.json")) or [])}
    sel = jload(os.path.join(RES, "selected.json"))
    units = open(os.path.join(REP, "units.txt")).read().strip().splitlines() if os.path.exists(os.path.join(REP, "units.txt")) else []

    L = ["## Results (every number below is generated: `reports/`, `benchmarks/meridian_qos/results/`)", "",
         "| evidence | result |", "|---|---|"]
    if reg:
        L.append(f"| Simulation regression (Verilator, scoreboard + stability monitors) | **{reg['passed']} / {reg['total']} runs pass**, {reg['checks']:,} scoreboard checks; "
                 f"14 configurations (2×2 reference, slices + decode stage + guard latency, out-of-order, no guard, minimum depth, policies, 4×2, 3×3 sparse, **5×7**, 8×4) × 3 seeds |")
    if units:
        npass = sum(1 for u in units if u.startswith("PASS"))
        L.append(f"| Unit benches | **{npass} / {len(units)} pass**: ABI constants identical to Project 83; queue ≡ Project 22 `sfn_fifo` cycle by cycle; arbiter ≡ independent model and ≡ P22 `sfn_qos_arbiter`, N = 2…8 |")
    if mut:
        k = sum(1 for m in mut if m["result"] == "KILLED")
        L.append(f"| Mutation testing (42 single-defect RTL mutants) | **{k} / {len(mut)} killed** by the regression or unit benches |")
    if frm:
        unb = [r for r in frm if r["status"] == "PASSED" and r["kind"] in ("prove", "pdr")]
        caught = [r for r in frm if r["status"] == "CAUGHT"]
        bmc = [r for r in frm if r["kind"] == "bmc"]
        bp = [r for r in bmc if r["status"] == "PASSED"]
        L.append(f"| Formal, **unbounded** proofs (queue depths 1-8, decoder, arbiter RR / WRR / strict + aging) | **{len(unb)} / {len([r for r in frm if r['kind'] in ('prove', 'pdr')])} proved**; "
                 f"{len(caught)} / {len([r for r in frm if r['kind'].startswith('mut-')])} planted defects caught (6 arbiter bugs, 2 deliberately too-small completion bounds) |")
        parts = []
        for r in bmc:
            if r["status"] == "PASSED" and "bound" in r["name"]:
                k = re.search(r"delivered within (\d+) cycles", r["claim"])
                parts.append(f"`{r['name']}` one-outstanding transaction delivered within {k.group(1) if k else '?'} cycles of acceptance, to {r['depth']} frames (bound is tight)")
            elif r["status"] == "PASSED":
                parts.append(f"`{r['name']}` safety properties hold to {r['depth']} frames")
            else:
                m = re.search(r"first (\d+) of (\d+)", r.get("detail", ""))
                parts.append(f"`{r['name']}` {r['status']}" + (f" (clean for {m.group(1)} of {m.group(2)} frames)" if m else ""))
        if bmc:
            L.append("| Formal, **bounded** fabric checks (tiny 2×2; from reset) | " + "; ".join(parts) + " |")
    if bench:
        pl = bench["pipeline"]
        base = pl.get("base", {})
        L.append(f"| Idle round trip, unpipelined 2×2 | request {base.get('idle', {}).get('request')} cycles, response {base.get('idle', {}).get('response')} cycles (asserted on every route by test `latency_idle`) |")
        s4 = bench["policy"].get("s4_hot/STRICT_age0", {})
        def c3(key):
            d = bench["policy"].get(key, {}).get("run", {}).get("class_lat", {})
            d = d.get("3") or d.get(3)
            return f"{d['p99']} / {d['max']}" if d else "-"
        L.append("| Class-3 tail latency under one hot target (`s4_hot`, p99 / max cycles) | "
                 f"RR {c3('s4_hot/RR')} · WRR 8:4:2:1 {c3('s4_hot/WRR_8421')} · strict, aging off {c3('s4_hot/STRICT_age0')} · strict, aging 16 {c3('s4_hot/STRICT_age16')} |")
    have = [n for n in synth if synth[n].get("fmax_med")]
    if synth:
        b = synth.get("base", {})
        L.append(f"| FPGA proxy (Yosys + nextpnr-ecp5, LFE5U-85F, 60 MHz target) | 2×2 base: {b.get('ecp5_lut4', '-')} LUT4, {b.get('ecp5_ff', '-')} FF, median Fmax "
                 f"{b.get('fmax_med', 0):.1f} MHz; {len(have)} pipeline configurations timed" + (f"; **selected `{sel['selected']}`** ({sel['fmax_med']:.1f} MHz, class-0 {sel['class0_lat_ns']:.0f} ns) by the rule in `docs/meridian_qos/06_PIPELINE_AND_SYNTHESIS.md`" if sel else "") + " |")
    L += ["", "Full tables: `reports/regression.md`, `reports/mutation.md`, `reports/formal.md`, `benchmarks/meridian_qos/results/bench.md`. Unbounded vs bounded is stated per formal job; the fabric is **not** proved unbounded."]
    block = "<!--RESULTS-->\n" + "\n".join(L) + "\n<!--/RESULTS-->"
    p = os.path.join(ROOT, "README.md")
    t = open(p).read()
    if "@@RESULTS@@" in t:
        t = t.replace("@@RESULTS@@", block)
    else:
        t = re.sub(r"<!--RESULTS-->.*?<!--/RESULTS-->", lambda _: block, t, flags=re.S)
    open(p, "w").write(t)
    print("README results filled")


if __name__ == "__main__":
    main()
