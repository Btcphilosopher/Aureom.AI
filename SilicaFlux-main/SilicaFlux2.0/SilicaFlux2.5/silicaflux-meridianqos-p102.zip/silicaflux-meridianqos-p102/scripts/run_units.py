#!/usr/bin/env python3
"""Unit benches: tb_abi_check (ABI == Project 83), tb_queue_diff (queue == Project 22 sfn_fifo), tb_arb (arbiter vs an
independent model and vs sfn_qos_arbiter, several N).  Prints PASS / FAIL per bench; exit status 1 if any fails."""
import os, re, subprocess, sys, tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R, P22, P83, TB = (os.path.join(ROOT, p) for p in ("rtl/meridian_qos", "third_party/p22", "third_party/p83", "tests/meridian_qos/tb"))
JOBS = [
    ("tb_abi_check", "tb_abi_check", [], [f"{P83}/sf_meridian_pkg.sv", f"{R}/sf_meridian_qos_pkg.sv", f"{TB}/tb_abi_check.sv"], []),
    ("tb_queue_diff", "tb_queue_diff", [], [f"{P22}/sfn_pkg.sv", f"{P22}/sfn_fifo.sv", f"{R}/sf_meridian_qos_pkg.sv",
                                             f"{R}/sf_meridian_queue.sv", f"{TB}/tb_queue_diff.sv"], []),
] + [(f"tb_arb N={n} ONECLS={o}", "tb_arb", [f"-GN={n}", f"-GONECLS={o}"],
      [f"{P22}/sfn_pkg.sv", f"{P22}/sfn_qos_arbiter.sv", f"{R}/sf_meridian_qos_pkg.sv", f"{R}/sf_meridian_arbiter.sv", f"{TB}/tb_arb.sv"],
      ["+seed=7"]) for n, o in ((2, 0), (3, 0), (4, 1), (5, 0), (8, 0))]


def main():
    bad = 0
    tmp = tempfile.mkdtemp(prefix="mqos_units_")
    for label, top, g, files, plus in JOBS:
        d = os.path.join(tmp, re.sub(r"\W", "_", label))
        r = subprocess.run(["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "--top-module", top,
                            "--Mdir", d] + g + files + ["-o", "V"], capture_output=True, text=True)
        if r.returncode:
            print("BUILD FAIL", label)
            bad += 1
            continue
        out = subprocess.run([os.path.join(d, "V")] + plus, capture_output=True, text=True).stdout
        ok = bool(re.search(r"^PASS ", out, re.M)) and not re.search(r"^FAIL", out, re.M)
        line = (re.search(r"^PASS .*", out, re.M) if ok else re.search(r"^FAIL.*", out, re.M))
        print(("PASS " if ok else "FAIL ") + label + "   " + (line.group(0) if line else ""))
        bad += 0 if ok else 1
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
