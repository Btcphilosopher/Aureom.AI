#!/usr/bin/env python3
"""Fill the measured tables of docs/meridian_qos/06_PIPELINE_AND_SYNTHESIS.md from benchmarks/meridian_qos/results/
(bench.md section 1 and selected.json).  Idempotent: it rewrites only the marked blocks."""
import json, os, re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "benchmarks", "meridian_qos", "results")
DOC = os.path.join(ROOT, "docs", "meridian_qos", "06_PIPELINE_AND_SYNTHESIS.md")


def main():
    bench = open(os.path.join(RES, "bench.md")).read()
    m = re.search(r"(\| config \|.*?)\n\n", bench, re.S)
    table = m.group(1) if m else "(see benchmarks/meridian_qos/results/bench.md)"
    sel = json.load(open(os.path.join(RES, "selected.json"))) if os.path.exists(os.path.join(RES, "selected.json")) else None
    synth = {r["name"]: r for r in json.load(open(os.path.join(RES, "synth.json")))}
    txt = open(DOC).read()
    # area-only configurations (no place-and-route): measured area options
    area = [r for r in synth.values() if not r.get("fmax_med")]
    base = synth.get("base", {})
    if area and base:
        rows = ["", "Area options (synthesis only, no place-and-route; same 2 x 2 reference, LUT4 / FF from Yosys `synth_ecp5`):", "",
                "| config | what changes | LUT4 | FF | gate cells | vs `base` LUT4 / FF |", "|---|---|---|---|---|---|"]
        what = {"noguard": "`GUARD = 0`: no MemoryGuard query port / reservation queues", "perf16": "`CW = 16`: 16-bit counters instead of 32-bit"}
        rows.append(f"| `base` | reference | {base['ecp5_lut4']} | {base['ecp5_ff']} | {base['gen_cells']} | - |")
        for r in sorted(area, key=lambda r: r["name"]):
            rows.append(f"| `{r['name']}` | {what.get(r['name'], '')} | {r['ecp5_lut4']} | {r['ecp5_ff']} | {r['gen_cells']} | "
                        f"{100.0 * (r['ecp5_lut4'] / base['ecp5_lut4'] - 1):+.0f} % / {100.0 * (r['ecp5_ff'] / base['ecp5_ff'] - 1):+.0f} % |")
        table = table + "\n" + "\n".join(rows)
    if "@@SWEEP_TABLE@@" in txt:
        txt = txt.replace("@@SWEEP_TABLE@@", "<!--SWEEP-->\n" + table + "\n<!--/SWEEP-->")
    else:
        txt = re.sub(r"<!--SWEEP-->.*?<!--/SWEEP-->", lambda _: "<!--SWEEP-->\n" + table + "\n<!--/SWEEP-->", txt, flags=re.S)
    block = []
    if sel:
        s = synth.get(sel["selected"], {})
        block.append(f"**Selected: `{sel['selected']}`.** Rule (computed by `benchmarks/meridian_qos/report.py`): keep the configurations whose best-seed Fmax is within 5 % of the best median, "
                     f"take the one with the smallest mean class-0 round-trip latency in nanoseconds (cycles / Fmax), break ties with the smaller flip-flop count, and leave the simplest candidate only for a "
                     f"gain larger than the seed-to-seed Fmax spread. Result: median Fmax **{sel['fmax_med']:.1f} MHz**, class-0 mean latency **{sel['class0_lat_ns']:.1f} ns**, "
                     f"{s.get('ecp5_lut4', '-')} LUT4 / {s.get('ecp5_ff', '-')} FF.")
        if sel.get("note"):
            block.append("")
            block.append("Why not a pipelined configuration: " + sel["note"] + " The rule had to be made noise-aware after the first sweep (rules 1-3 alone picked `dec`, a 0.9 % gain); the change is recorded in the header of `report.py`.")
        block.append("")
        block.append("**Honest reading.** On this FPGA proxy the optional stages cost cycles and do **not** buy a measurable Fmax: every configuration closes between 40 and 48 MHz at a 60 MHz target, the gate-level depth "
                     "(`ltp`) is 126 in all of them, and the seed-to-seed spread (up to about 12 %) is as large as the differences between configurations. The longest path (nextpnr critical-path reports) is inside the router: "
                     "crosspoint-queue read (distributed RAM) -> class select -> target-arbiter pointer / credit update. The optional stages sit before that queue and at the port boundaries, so they do not cut it "
                     "(registering the queue head's class would be the next optimisation; it was not done because the RTL was frozen for the final verification). The stages remain as parameters for a floorplan where a wire between blocks, which this proxy cannot show, is the limit; there is "
                     "no measurement here that recommends them.")
    else:
        block.append("(selection not computed: no Fmax available)")
    block.append("")
    block.append("The reset values / defaults of `sf_meridian_qos` keep the **unpipelined** structure (`DEC_PIPE = 0`, no slices) so that the verified 2 × 2 reference has the shortest latency; the "
                 "pipelining is a parameter set chosen per floorplan. The unpipelined default is also what the selection rule chose.")
    sel_txt = "<!--SEL-->\n" + "\n".join(block) + "\n<!--/SEL-->"
    if "@@SELECTION@@" in txt:
        txt = txt.replace("@@SELECTION@@", sel_txt)
    else:
        txt = re.sub(r"<!--SEL-->.*?<!--/SEL-->", lambda _: sel_txt, txt, flags=re.S)
    open(DOC, "w").write(txt)
    print("filled", DOC)


if __name__ == "__main__":
    main()
