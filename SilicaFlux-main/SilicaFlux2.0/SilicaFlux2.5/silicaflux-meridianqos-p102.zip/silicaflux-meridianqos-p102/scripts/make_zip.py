#!/usr/bin/env python3
"""Write MANIFEST.sha256 and build the delivery archive (nothing is committed anywhere).

    make_zip.py [out.zip]        default: <parent of the project>/silicaflux-meridianqos-p102.zip
"""
import hashlib, os, sys, zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NAME = "silicaflux-meridianqos-p102"
SKIP_DIRS = {"build", "__pycache__", ".git", "work"}
SKIP_EXT = (".pyc", ".o", ".a")


def main():
    files = []
    for d, ds, fs in os.walk(ROOT):
        ds[:] = sorted(x for x in ds if x not in SKIP_DIRS)
        for f in sorted(fs):
            if f.endswith(SKIP_EXT) or f == "MANIFEST.sha256":
                continue
            files.append(os.path.relpath(os.path.join(d, f), ROOT))
    with open(os.path.join(ROOT, "MANIFEST.sha256"), "w") as m:
        for f in files:
            m.write(f"{hashlib.sha256(open(os.path.join(ROOT, f), 'rb').read()).hexdigest()}  {f}\n")
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(ROOT), NAME + ".zip")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files + ["MANIFEST.sha256"]:
            z.write(os.path.join(ROOT, f), os.path.join(NAME, f))
    print(f"{out}: {len(files) + 1} files, {os.path.getsize(out) / 1e6:.2f} MB")


if __name__ == "__main__":
    main()
