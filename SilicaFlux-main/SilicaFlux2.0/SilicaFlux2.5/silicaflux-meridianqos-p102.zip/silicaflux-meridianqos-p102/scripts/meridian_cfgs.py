"""Configurations of the MeridianQoS system testbench (verilator -G overrides).  name -> (overrides, tests)."""
GENERAL = ["basic", "rand_clean", "rand_bp", "rand_err", "rand_gstall", "rand_reorder", "contention", "admission",
           "errors", "tagreuse", "saturate", "reset", "latency_idle", "counters", "regs", "policy_switch"]
CLASSES = ["classes", "floor"]

CFGS = {
    # the verified two-master, two-target reference
    "ref_2x2":        ({},                                                             GENERAL),
    "ref_2x2_m16":    ({"MAXO": 16, "IQD": 8},                                         CLASSES + GENERAL),
    # variants of the reference
    "v_slices_dec":   ({"MSL": 2, "TSL": 1, "DECP": 1, "GLAT": 3, "GQD": 4},           GENERAL),
    "v_ooo":          ({"OOO_MASK": 3},                                                GENERAL),
    "v_noguard":      ({"GUARD": 0},                                                   [t for t in GENERAL if t not in ("rand_err",)] ),
    "v_minimal":      ({"MAXO": 1, "IQD": 2, "XQD": 2, "EQD": 2, "TRQD": 2, "RQD": 2}, GENERAL),
    # bound domains + sparse topology on the small configuration (spoofing and no-route paths on the 2 x 2)
    "v_dom_sparse":   ({"MAXO": 8, "CONN_SEL": 1, "DOMALLOW_SEL": 1},                  GENERAL),
    "v_strict_off":   ({"STRICT_EN": 0, "DEF_POL": 1},                                 ["basic", "rand_bp", "regs", "contention", "latency_idle"]),
    "v_pol_rr":       ({"DEF_POL": 0},                                                 ["rand_bp", "contention", "policy_switch"]),
    "v_pol_strict":   ({"DEF_POL": 2},                                                 ["rand_bp", "contention", "policy_switch"]),
    # scaling toward the SilicaFlux memory / compute architecture
    "m4t2_classes":   ({"NM": 4, "NT": 2, "MAXO": 16, "IQD": 8},                       CLASSES + GENERAL),
    "m3t3_sparse":    ({"NM": 3, "NT": 3, "MAXO": 4, "CONN_SEL": 1, "DOMALLOW_SEL": 1, "OOO_MASK": 2},
                                                                                        [t for t in GENERAL if t != "tagreuse"] + ["tagreuse"]),
    "m5t7_albion":    ({"NM": 5, "NT": 7, "MAXO": 8, "IQD": 4, "DOMALLOW_SEL": 1, "MSL": 1, "TSL": 1}, GENERAL),
    "m8t4":           ({"NM": 8, "NT": 4, "MAXO": 16, "IQD": 8, "GLAT": 2, "GQD": 3},   ["basic", "rand_bp", "rand_err", "contention", "classes", "saturate", "errors"]),
}
SEEDS = [1, 2, 3]
