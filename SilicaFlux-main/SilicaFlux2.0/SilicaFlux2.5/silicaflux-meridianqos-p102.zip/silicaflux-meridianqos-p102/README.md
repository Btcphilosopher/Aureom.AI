# SilicaFlux Project 102 — MeridianQoS: QoS-aware on-chip interconnect

**Primary RTL:** `rtl/meridian_qos/sf_meridian_qos.sv` · Aureom.AI / SilicaFlux Semiconductor Systems · delivered as this archive — **nothing was committed to GitHub**.

MeridianQoS is Project 83's Meridian crossbar with scheduling added: **four configurable traffic classes**, **round-robin / weighted-round-robin / strict-priority arbitration** (with a documented starvation
floor), per-class admission control and a congestion throttle, **privileged registers**, **performance counters** (queue occupancy, stalls, contention, back-pressure duration, target utilisation, latency) and a
**MemoryGuard check port**. It uses the existing SilicaFlux transaction contract unchanged: **no second bus protocol** (the 40 shared ABI constants are tested identical to Project 83's). The verified
**2 master × 2 target** configuration comes first; the same RTL and the same tests scale to 4 × 2, 3 × 3 sparse, **5 × 7 (Albion-sized)** and 8 × 4 by parameters.

> **Status — read this first.** Everything below is simulation (Verilator), mutation testing, formal (Yosys / ABC PDR / cvc5) and FPGA place-and-route (Yosys + nextpnr, ECP5). **No ASIC library exists in the
> repository, so no ASIC area, frequency or power is claimed**; the FPGA Fmax is a relative figure for comparing pipeline options. The **MemoryGuard is an interface plus a reference model** (no such block
> exists; DomainGuard is a datapath filter that cannot be connected as is), the brief's `StreamDMA` / `MemoryMatrix` do not exist in the repository (nearest real blocks are audited and modelled), the endpoints are
> bench models, formal proofs are unbounded only for the queue, decoder and arbiter (the whole fabric is checked to a bounded depth on a tiny configuration), and there are no timeouts. Full list:
> [docs/meridian_qos/08_LIMITATIONS.md](docs/meridian_qos/08_LIMITATIONS.md).

<!--RESULTS-->
## Results (every number below is generated: `reports/`, `benchmarks/meridian_qos/results/`)

| evidence | result |
|---|---|
| Simulation regression (Verilator, scoreboard + stability monitors) | **543 / 543 runs pass**, 6,373,269 scoreboard checks; 14 configurations (2×2 reference, slices + decode stage + guard latency, out-of-order, no guard, minimum depth, policies, 4×2, 3×3 sparse, **5×7**, 8×4) × 3 seeds |
| Unit benches | **7 / 7 pass**: ABI constants identical to Project 83; queue ≡ Project 22 `sfn_fifo` cycle by cycle; arbiter ≡ independent model and ≡ P22 `sfn_qos_arbiter`, N = 2…8 |
| Mutation testing (42 single-defect RTL mutants) | **42 / 42 killed** by the regression or unit benches |
| Formal, **unbounded** proofs (queue depths 1-8, decoder, arbiter RR / WRR / strict + aging) | **12 / 12 proved**; 8 / 8 planted defects caught (6 arbiter bugs, 2 deliberately too-small completion bounds) |
| Formal, **bounded** fabric checks (tiny 2×2; from reset) | `fabric_noguard` safety properties hold to 12 frames; `fabric_guard` safety properties hold to 12 frames; `fabric_decpipe` safety properties hold to 12 frames; `fabric_bound` one-outstanding transaction delivered within 9 cycles of acceptance, to 18 frames (bound is tight); `fabric_bound_ng` one-outstanding transaction delivered within 8 cycles of acceptance, to 18 frames (bound is tight) |
| Idle round trip, unpipelined 2×2 | request 4 cycles, response 3 cycles (asserted on every route by test `latency_idle`) |
| Class-3 tail latency under one hot target (`s4_hot`, p99 / max cycles) | RR 57 / 61 · WRR 8:4:2:1 114 / 118 · strict, aging off 2629 / 4402 · strict, aging 16 243 / 257 |
| FPGA proxy (Yosys + nextpnr-ecp5, LFE5U-85F, 60 MHz target) | 2×2 base: 14824 LUT4, 4842 FF, median Fmax 43.2 MHz; 7 pipeline configurations timed; **selected `base`** (43.2 MHz, class-0 554 ns) by the rule in `docs/meridian_qos/06_PIPELINE_AND_SYNTHESIS.md` |

Full tables: `reports/regression.md`, `reports/mutation.md`, `reports/formal.md`, `benchmarks/meridian_qos/results/bench.md`. Unbounded vs bounded is stated per formal job; the fabric is **not** proved unbounded.
<!--/RESULTS-->

## Quick start

```bash
apt-get install -y verilator yosys cvc5 nextpnr-ecp5 python3     # Ubuntu 24.04
make check units quick          # lint, unit benches, the 2 x 2 reference (about 5 minutes)
make regress                    # 14 configurations x 3 seeds  -> reports/regression.md
make formal                     # proofs, bounded checks, planted bugs -> reports/formal.md
make mutate                     # 42 deliberate RTL defects -> reports/mutation.md   (about an hour)
make bench synth                # workloads, throughput / latency, pipeline sweep -> benchmarks/meridian_qos/results/
```

## Layout

```
rtl/meridian_qos/   sf_meridian_qos.sv (TOP) · _mport (master port) · _router (crossbar) · _arbiter (RR / WRR / strict) · _queue · _slice · _decoder
                    · _qos_regs (privileged) · _perf (counters) · _guard_ref (MemoryGuard MODEL) · _qos_pkg (ABI, classes, maps)
rtl/files.f         compile order
third_party/        p22/ sfn_fifo, sfn_pkg, sfn_qos_arbiter (Project 22, unmodified, SHA-256)  p83/ sf_meridian_pkg (Project 83, unmodified)
tests/meridian_qos/ tb_meridian_qos.sv (system bench, scoreboard, 17 tests) · tb_arb · tb_queue_diff · tb_abi_check · README
formal/meridian_qos/ fv_qos (fabric) · fv_arbiter · fv_decoder · README   (queue properties are in sf_meridian_queue.sv under `ifdef FORMAL)
benchmarks/meridian_qos/ gen_workloads.py · run_bench.py · report.py · synth.py · traces/ · results/
docs/meridian_qos/  00 audit · 01 architecture · 02 ABI · 03 arbitration / fairness · 04 registers · 05 congestion / counters / isolation
                    · 06 pipeline and synthesis · 07 verification · 08 limitations
scripts/            regress · mutate · formal · build_tb · run_units · make_zip · fill_docs · meridian_cfgs
reports/            regression · mutation · formal (+ json)
Makefile · MANIFEST.sha256
```

## Brief → where it is met

| § | requirement | where |
|---|---|---|
| 1 | audit existing RTL, reuse the verified transaction contract | `00_AUDIT.md`: Meridian P83, DataFabric P22, NoC spine P34, ControlCore, PacketCore, TensorCore, CloudDMA, MemoryCore, DomainGuard; names that do not exist (`MemoryGuard`, `MemoryMatrix`, `StreamDMA`) mapped to real blocks; contract = P83's, tested identical |
| 2 | core module: input queues, destination decode, configurable arbitration, output routing, response tracking, backpressure, counters; crossbar first | `sf_meridian_qos.sv` + `_mport` / `_router` / `_arbiter` / `_queue` / `_perf`; `01_ARCHITECTURE.md` |
| 3 | four configurable traffic classes (scheduling classes, not latency contracts); alternative policies via parameters / privileged registers | `02_ABI.md §4`, `03_ARBITRATION_QOS.md §2`, `04_REGISTERS.md` (`TCMAP`, `FLOOR`, `WEIGHTS`, `CTRL.policy`) |
| 4 | RR, WRR, optional strict priority; weighted scheduling must not starve; document the fairness assumptions | `sf_meridian_arbiter.sv`; `03_ARBITRATION_QOS.md` (bounds, derivation, **seven assumptions**, measured shares); formal proofs; `tb_arb` |
| 5 | multiple masters / targets, outstanding, identifiers, error responses, independent response paths; each completion to the right master, none duplicated or lost | slot table + `src` stamping + independent response network; scoreboard exactly-once in every run |
| 6 | valid/ready, elastic buffering, output queues, FIFO-full handling, backpressure propagation, registered boundaries, no combinational loops | every ready/valid is a function of registered occupancy only; `saturate`; Verilator `UNOPTFLAT` is a hard error in every build |
| 7 | congestion: occupancy, stalls, contention, backpressure duration, utilisation; admission / throttling; never drop accepted transactions | `05_CONGESTION_AND_PERF.md`; counters tested exactly; `admission` |
| 8 | traffic isolation: preserve domain / permission metadata, connect to MemoryGuard, documented failure response for denied requests | `02_ABI.md §3`, `05 §3`; metadata checked at every target; `grd_*` interface + reference model; `ST_DENIED` |
| 9 | configurable register stages; measure depth, added cycles, critical path, throughput, latency; select with real synthesis results | `06_PIPELINE_AND_SYNTHESIS.md`, `benchmarks/meridian_qos/results/` |
| 10 | formal: no duplication, no loss, response routing, valid/ready stability, FIFO over/underflow, illegal destination, fairness | `formal/meridian_qos/`, `reports/formal.md` (what is unbounded and what is bounded is stated per job) |
| 11 | verification: workloads and the eight scenarios | `07_VERIFICATION.md §1` (item → test), `tests/meridian_qos/README.md` |
| 12 | deliverables | `rtl/meridian_qos/*.sv`, `tests/meridian_qos/`, `formal/meridian_qos/`, `benchmarks/meridian_qos/` |
