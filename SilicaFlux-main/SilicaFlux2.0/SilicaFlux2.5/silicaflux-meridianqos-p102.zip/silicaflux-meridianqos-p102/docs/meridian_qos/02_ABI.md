# 02 — The transaction ABI (unchanged from Project 83) and the failure responses

**MeridianQoS does not define a bus protocol.** The wire format, status codes, fault codes, ordering rules and port conventions are those of
Project 83's *Albion transaction format as carried by Meridian* (itself SFB3 of Project 22, extended). `tb_abi_check.sv` proves the 40
shared constants identical to the vendored original. This page restates the contract so a reader of MeridianQoS needs only this
project, and documents what MeridianQoS does with it.

## 1. Fields

**Request** (master → fabric; the fabric adds `src` on the target side)

| field | width | meaning |
|---|---|---|
| `op` | 2 | `0` READ one `DW`-bit beat · `1` WRITE one beat, acknowledged (answered after the target performed it) · `2`, `3` reserved |
| `tag` | `TAGW` | chosen by the master; unique among its outstanding transactions |
| `dom` | `DOMW` | protection domain; **checked, never trusted** |
| `priv` | 1 | privileged access; an input to the guard check |
| `tc` | 3 | legacy traffic class, larger = more urgent (§4) |
| `addr` | `AW` | byte address, aligned to `DW/8` |
| `wdata`, `wstrb` | `DW`, `DW/8` | write data / byte enables (forwarded unchanged for reads too) |
| `src` | `clog2(NM)` | target side only: **stamped by the fabric**, cannot be forged |

**Response** (target → fabric → master): `src` (target side), `tag`, `dom`, `op` (echoed), `status[3]`, `rdata`.

Single-beat transactions; no posted writes, fences, atomics or bursts (a burst is a sequence of transactions).

## 2. Rules

* **Masters**: do not wait for `ready` before asserting `valid`; hold `valid` and every field until `ready`; use only `op` 0 / 1 and
  aligned addresses; never present a `tag` that is outstanding. *Violations are handled, not trusted*: reserved opcode and misalignment are
  answered `ST_PROTO`; a reused tag is consumed and counted (`V_TAGREUSE`) **without a response** (a response could not be told apart from the
  first transaction's); this is the one case in which an accepted request is not answered, and it is a master protocol violation.
* **Targets**: answer each request exactly once, in any order, echoing `{src, tag, dom, op}`, with `ST_OKAY` or `ST_SLVERR` (a `SLVERR` request
  has no side effect); hold the response until `ready`. *Not trusted either*: a response that matches no outstanding transaction (orphan,
  duplicate), comes from the wrong target, or has an illegal `src` is consumed and counted (`V_ORPHAN`, `V_BADSRC`); an echo mismatch or a
  status other than OKAY / SLVERR is delivered to the master as `ST_PROTO` with zero data (`V_ECHO`). One limit, stated plainly: a duplicate that
  arrives *after* the tag was re-issued to the *same* target cannot be told from the new transaction's response (no sequence numbers on the wire).
* **Ordering**: requests of one master to one target reach it in issue order; requests to different targets are unordered; responses to a
  master are delivered in acceptance order (`MST_OOO = 0`) or as completed (`1`, the `tag` identifies the transaction); no ordering across
  masters, no coherence.

## 3. Status codes and the documented failure responses

| code | name | produced by | when |
|---|---|---|---|
| 0 | `ST_OKAY` | target | performed |
| 1 | `ST_SLVERR` | target | slave failure, no side effect |
| 2 | `ST_DECERR` | fabric | address decodes to no target (`F_UNMAPPED`) or this master has no route to it (`F_NOROUTE`) |
| 3 | `ST_DENIED` | fabric | domain not bound to the port (`F_SPOOF`) **or the MemoryGuard denied** (`F_NOMAP` / `F_DOMAIN` / `F_PRIV` / `F_PERM`): the request **never reached a target** |
| 4 | `ST_TIMEOUT` | — | part of the ABI, **not produced** by MeridianQoS (no timeout machinery, `08_LIMITATIONS.md`) |
| 5 | `ST_PROTO` | fabric | reserved opcode (`F_BADOP`), misaligned address (`F_MISALIGN`), response echo / status illegal (`F_ECHO`) |

**A denied request is answered, in its normal slot order, on the master's response channel with `status = ST_DENIED`, the request's own
`tag` / `dom` / `op` and `rdata = 0`.** The detail code (`F_*`) is not on the response; it is recorded in the **first-error log**
(registers `ELOG0`, `ELOG1`: status, fault, source master, tag, domain, address; sticky until cleared) and counted (`DENIED` per master). A
denied request consumes no crosspoint entry, no arbiter slot and no target cycle: it cannot cause contention or be observed by a target.
Measured by tests `errors` (exact per-master status counters) and the scoreboard (a denied request that reaches a target fails it).

## 4. Traffic classes: an internal sideband, not a protocol change

The wire carries the Project 83 `tc` (0 background, 1 bulk DMA, 2 compute, 3 latency-sensitive I/O, 4 management; 5–7 legal) **unchanged
to the target** (checked field by field). MeridianQoS derives from it an internal 2-bit **scheduling class** used only for arbitration:

```
class = max( TCMAP[tc] , FLOOR[master] )          (numerically larger = less urgent;  CLASS_0 is the most urgent)
```

| class | brief | default `tc` mapped to it |
|---|---|---|
| `CLASS_0` | management and control | 4, 5, 6, 7 |
| `CLASS_1` | latency-sensitive I/O | 3 |
| `CLASS_2` | bulk DMA and memory traffic | 1, 2 |
| `CLASS_3` | background compute / data movement | 0 |

Two directions to keep apart: **`tc` larger = more urgent; class number smaller = more urgent.** `TCMAP` (register, 2 bits per `tc`) lets software
re-assign (for example move compute `tc 2` to CLASS_3). **`FLOOR[master]`** (register) is the most urgent class the master may use: a request
that asks for a more urgent class is *demoted*, not rejected, and counted (`DEMOTE`). The `tc` field is master-presented and is
not authenticated; without a floor, a misbehaving master could claim CLASS_0. The floor is the control that makes classes a
*scheduling* contract per port. These are scheduling classes, **not guaranteed-latency contracts** (`03_ARBITRATION_QOS.md §5`).

## 5. What is added to / removed from Project 83's contract

Added (no wire change): `TCMAP`, `FLOOR`, the class sideband, `V_GRD` (verdict with no query outstanding, ignored). Removed behaviour:
`ST_TIMEOUT` / `F_HOL` / `F_ISO` / `F_RSPTMO` / `F_CITTMO` are never produced (a slave that never answers hangs its master, as an AXI slave
that never answers would; add a watchdog at the target or in a later project).
