# 05 — Congestion management, performance counters and isolation

## 1. What is measured

All counters live in one flat bank (`sf_meridian_perf`, `NCNT = 16 + 20·NM + 32 + 14·NT + NM·NT`), read through `PERF_SEL` / `PERF_DATA` (privileged), cleared
together by `PERF_CTRL[0]`. Two kinds: **sum** counters (`cnt += inc` every cycle) and **max** counters (`cnt = max(cnt, inc)`). They wrap at `2^CW`
(`CW = 32`): clear them before a measurement. Index of a counter: `PF_G + m·PF_PM + k` (per master), `PF_G + NM·PF_PM + c·PF_PC + k` (per class),
`PF_G + NM·PF_PM + 4·PF_PC + t·PF_PT + k` (per target), then the NM × NT request matrix (helpers `pf_m / pf_c / pf_t / pf_x` in the package).

| the brief's metric | counter(s) | meaning |
|---|---|---|
| **queue occupancy** | `IQ_SUM`, `IQ_MAX` (per master ingress queue); `XQ_SUM`, `XQ_MAX` (sum of the crosspoint queues of a target); `EQ_SUM`, `EQ_MAX` (egress queue); `OUT_SUM`, `OUT_MAX` (outstanding transactions) | running sum (divide by `CYCLES` for the mean) and maximum |
| **stall cycles** | `STALL_IN` (per master: offered request not accepted); `ARBSTALL` (per target / per class / global: requesters present at an arbiter and not granted, summed over cycles); `HELD_ADM`, `HELD_CONG` (head held by admission control) | |
| **contending requests** | `CONTEND` (cycles with ≥ 2 requesters at a target), `REQSUM` (running sum of requesters), global `CONTEND` | |
| **backpressure duration** | `BP` (cycles the target port offers a request the target does not take), `BP_RUN` (the longest consecutive run) | |
| **target utilisation** | `BUSY` (cycles the target accepted a request) / `CYCLES`; `XFER`, `BYTES` | |
| latency / throughput | `LAT_SUM`, `LAT_CNT`, `LAT_MAX` per master and per class (accept at the ingress queue → delivery into the response queue); `ACC`, `CPL`, `BYTES_WR`, `BYTES_RD` | |
| class behaviour | `FIRE`, `CPL`, `GRANTS`, `ARBSTALL`, `DEMOTE` per class | |
| status / errors | `CPL` by status (`DECERR`, `DENIED`, `PROTO`, `SLVERR` per master), `VIOL` (protocol violations), global `SEC` | |

Bytes: a write counts its enabled byte lanes, a read counts one full beat. Exactness is **tested** (test `counters`: a deterministic scenario with every counter
compared with the bench's own arithmetic, including `LAT_SUM`; test `errors`: per-master status counters and the violation counter equal the bench's expected counts
exactly under concurrent errors).

## 2. Congestion management

Every request is held, never dropped, when the fabric is congested: the **only** requests that are ever answered without a target seeing them are the
documented local errors (`02_ABI.md §3`) and a reused tag (a master protocol violation).

* **Back-pressure** propagates upstream stage by stage through the registered `valid/ready` queues (`01_ARCHITECTURE.md §4`); isolation of independent targets is tested
  (`saturate`: a target that never accepts fills its own queues, then the ingress queue of its masters; traffic to another target from another master completes untouched).
* **Per-class outstanding limit** (`OUTLIM`): a master port admits a request of class c only while fewer than `OUTLIM[c]` (≥ 1) requests of that class are outstanding
  (the slot count bounds the total). Test `admission` shows the effect at the target: with the limit at 1, never more than 1 class-2 request is in flight; without it they overlap.
* **Congestion throttle** (`CTRL.cong_en`, `CONG`): per target a flag rises when the occupancy of its crosspoint + egress queues reaches `hi` and falls at `lo` (hysteresis,
  registered). While it is up, requests of class ≥ `THR` destined to that target are *held at the master port* (not dropped, not reordered); more urgent classes pass.
  Test `admission` floods class 3 at a slow target, checks the flag rises, counts the held cycles and verifies that every transaction completes.
* **Scope of a hold.** A held head also holds the later requests of the same master (one in-order stream per master, `03_ARBITRATION_QOS.md §5`), never other masters.

## 3. Traffic isolation: domain and permission metadata

* `dom` and `priv` travel in the request word from the master port to the target and are checked field by field at every target in every test and in the formal harness
  (P_IDENT) — the protection-domain information is never narrowed, recomputed or dropped between the check and the target.
* **Enforcement is at the master port ingress**, before any shared resource: (1) *domain binding*: the port has a mask of the domains it may present (`MST_DOM_ALLOW`);
  another domain is a spoof → `ST_DENIED / F_SPOOF` (independent of the guard; the port, not the label, is trusted); (2) the **MemoryGuard check** (`grd_*`): every admitted request
  is checked, including management-class traffic (`tc 4` is not exempt, `priv` is an *input* to the check, not a bypass). Denied requests get `ST_DENIED` and **never reach the
  crosspoint, an arbiter slot or a target** (they consume no shared bandwidth: they cannot cause contention or be observed by another master).
* `src` is stamped by the fabric from the crosspoint a request came through; the target cannot be told a different master.
* **Not claimed:** side-channel isolation (shared arbiters, queues and the guard are observable through latency); protection against a compromised management plane; authentication of
  `priv` / `cfg_priv`; isolation of *targets* from each other (a shared target must enforce its own tenancy).

### The MemoryGuard interface (`grd_*`, one per master)

| signal | dir | meaning |
|---|---|---|
| `grd_req_valid / ready` | fabric → guard | query handshake; the fabric holds the fields stable while `valid && !ready` |
| `grd_req_dom`, `priv`, `write`, `addr` | fabric → guard | the query; the *source* is the port index (hardware-bound, never taken from the request) |
| `grd_rsp_valid` | guard → fabric | one verdict per accepted query, **in order**, **≥ 1 cycle later** (registered; a combinational guard is not supported) |
| `grd_rsp_ok`, `grd_rsp_fault[3:0]` | guard → fabric | permit; or deny with `F_NOMAP` / `F_DOMAIN` / `F_PRIV` / `F_PERM` |

Contract: default deny; fail closed means *no verdict ⇒ no access* (the request waits; there is no timeout, so an unresponsive guard stalls that master). The guard queue (`GQ_DEPTH`)
bounds the queries in flight and must be ≥ the verdict latency + 1 for full rate. A verdict with no query outstanding is ignored and counted (`V_GRD`). `sf_meridian_guard_ref` is a table-based
**model** with a configurable verdict latency and a stall hook; it defines and exercises the interface and is not guard hardware.
