# 01 — Architecture

MeridianQoS is a **registered, crosspoint-buffered crossbar** (the structure Project 83 chose, for the reasons in its audit) with
scheduling added. It starts as the verified 2 master × 2 target reference and scales by parameters (`NM`, `NT`, queue depths,
slices) without changing the transaction ABI.

```
 masters                                                                      targets
          ┌─ mport (one per master) ───────────────────────────┐   ┌─ router ──────────────────────────────┐
 m_req ─► [MST_SLICE] ─► IQ ─► [DEC stage] ─► decode · class · admission ─► XQ[m][0..NT-1] ─► arbiter[t] ─► EQ[t] ─► [TGT_SLICE] ─► t_req
          │             ingress   optional     bind · tag check              crosspoint     per target    egress
          │             queue                  guard query ─► GQ ─► verdict  queues (VOQ)   RR/WRR/STRICT  queue
          │                                    │ MemoryGuard (grd_*)                                  ▲ src stamped here
 m_rsp ◄─ [MST_SLICE] ◄─ RQ ◄─ delivery ◄─ slot table ◄── rin ◄── response routing by src ◄── TRQ[t] ◄─ [TGT_SLICE] ◄─ t_rsp
          response  queue   in order or    tag · target · class                              response
                            as completed   status · data · timestamp                         queue
   privileged registers (sf_meridian_qos_regs) ─► policy · weights · aging · tc map · floor · limits · throttle
   performance counters (sf_meridian_perf)   ◄─ events from every stage          congestion flags per target ─► admission
```

## 1. Modules

| file | role |
|---|---|
| `sf_meridian_qos.sv` | **top**: unpacks the ABI port vectors, instantiates NM master ports, the router, slices, counters, registers |
| `sf_meridian_mport.sv` | one master port: ingress queue, optional decode stage, decode / checks / classification, admission control, MemoryGuard query + guard queue, slot table, delivery, response queue, violation events, error log capture |
| `sf_meridian_router.sv` | the crossbar: crosspoint queues, per-target arbiter, egress queue, `src` stamping, response queues, routing by `src`, bad-source sink, congestion flag per target |
| `sf_meridian_arbiter.sv` | per-target arbitration: round robin, weighted round robin, strict priority with optional aging (`03_ARBITRATION_QOS.md`) |
| `sf_meridian_queue.sv` | the one buffering primitive: elastic FIFO with registered occupancy flags |
| `sf_meridian_slice.sv` | configurable register stages (a chain of 2-entry queues) |
| `sf_meridian_decoder.sv` | base / mask destination decode, topology reach, alignment |
| `sf_meridian_qos_regs.sv` | privileged configuration / status registers, error log, security counter |
| `sf_meridian_perf.sv` | performance counters (`05_CONGESTION_AND_PERF.md`) |
| `sf_meridian_guard_ref.sv` | **reference model** of the MemoryGuard (not part of the fabric) |
| `sf_meridian_qos_pkg.sv` | ABI constants (= Project 83), classes, policies, register and counter maps |

## 2. Request path

1. **Accept.** `m_req_ready` = "ingress queue not full": a registered flag, independent of `m_req_valid` and of every decision. The master is
   never stalled by decode, guard or arbitration latency, only by a full queue.
2. **Examine the head** (in this order; the first failure answers the request locally and it is never forwarded):
   tag reuse (consumed, no response) → reserved opcode `ST_PROTO` → misaligned `ST_PROTO` → domain not bound to the port `ST_DENIED`
   → address unmapped / no route `ST_DECERR`. Then **admission**: a free slot, the per-class outstanding limit, the congestion throttle,
   crosspoint-queue room. Nothing is ever dropped by admission, the head waits.
3. **MemoryGuard.** An admitted request allocates its slot, *reserves* one crosspoint-queue entry and one guard-queue entry, and is queried
   (`grd_req_*`). The verdict (`grd_rsp_*`, in order, ≥ 1 cycle later) pops the guard queue: *ok* → the request moves into its crosspoint
   queue (space reserved: it cannot stall); *denied* → its slot is completed `ST_DENIED` and **it never reaches the crosspoint or a target**.
4. **Arbitrate.** Per target, the arbiter sees the heads of the NM crosspoint queues with their classes and picks one when the registered
   egress-queue `in_ready` allows; the winner moves to the egress queue and the fabric stamps `src`. Different targets arbitrate
   concurrently; a stalled target fills only its own column of queues.
5. **Egress.** The egress queue (→ target slice → `t_req_*`).

## 3. Response path (independent: it shares no queue, arbiter or wire with the request path)

`t_rsp_*` → target slice → response queue `TRQ[t]` → routing by the stamped `src` (a response with an illegal or unreachable `src` is
consumed and counted, never delivered) → per-master round robin over the targets answering that master → `rin` of the master port.
`rin` is **always accepted** in the cycle it is presented, because the master port owns the slot the transaction allocated at admission
(the slot is where the data waits for in-order delivery). The response network therefore never back-pressures and cannot deadlock on a
slow master. The slot checks the response against the request (tag, target, echo of domain and opcode, status legality), then delivery
(in acceptance order for `MST_OOO = 0`, as completed for `1`) pushes it into the master's response queue (→ slice → `m_rsp_*`).

## 4. Flow control

Every channel boundary is a `valid/ready` pair whose `ready` / `valid` outputs are functions of **registered queue occupancy only**
(`sf_meridian_queue`). Hence: **no combinational valid/ready path crosses a queue, slice, the router or a master port**; the only
combinational chains are inside a stage (queue head → arbiter → payload mux → egress push; ingress head → decode → admission →
push). Verilator treats a combinational loop (`UNOPTFLAT`) as a hard error in every build of the testbench; none occurs.
Back-pressure propagates stage by stage: a stalled target fills its egress queue, then the crosspoint queues of that target, then
reservation fails and the ingress queue of each master with traffic for it fills, then `m_req_ready` drops (test `saturate`).

## 5. Sizing (what the queue depths mean, and a rule that matters)

| parameter | default | meaning |
|---|---|---|
| `IQ_DEPTH` | 4 | ingress queue per master (elasticity; absorbs decision latency) |
| `XQ_DEPTH` | 4 | crosspoint queue per (master, target): the virtual output queue |
| `EQ_DEPTH` | 2 | egress queue per target (≥ 2: full rate with registered ready) |
| `TRQ_DEPTH`, `RQ_DEPTH` | 2 | response queues |
| `GQ_DEPTH` | 2 | guard queue: ≥ verdict latency + 1 for full rate |
| `MAXO` | 4 | slots = outstanding transactions per master |

**Rule: the slot count `MAXO` must exceed the bandwidth-delay product of the master's path or its crosspoint queue is empty at
arbitration time.** A request holds its slot from admission until its response is delivered, so a master's slots are spread over its
crosspoint queue, the egress queue, the target, and the response path. With `MAXO = 4`, a 2-deep egress queue plus one request in
service plus one response in flight leaves nothing in the crosspoint queue: the arbiter then sees no request from that master and
correctly (work-conservingly) serves a lower class. This is measured: with `MAXO = 4` strict priority gave the lowest class 18 % of a
saturated target; with `MAXO = 16` it gave it 0 % (`03_ARBITRATION_QOS.md §6`). Size `MAXO` for the priority behaviour you need.

## 6. Latency and pipeline depth (empty fabric; measured and asserted per route by test `latency_idle`)

| path | cycles |
|---|---|
| request accepted → visible at the target | **3** + `MST_SLICE` + `TGT_SLICE` + `DEC_PIPE` + (guard verdict latency `GLAT` if `GUARD_EN`) |
| target response taken → visible at the master | **3** + `MST_SLICE` + `TGT_SLICE` |

Each slice stage adds one cycle in its direction and no loss of throughput. Pipeline-depth selection from synthesis results:
`06_PIPELINE_AND_SYNTHESIS.md`.

## 7. Scaling

`NM`, `NT`, address map (`TGT_BASE`/`TGT_MASK`), topology (`CONN`, one bit per master/target pair), per-master domain binding
(`MST_DOM_ALLOW`), out-of-order delivery (`MST_OOO`), queue depths, slices. Verified configurations (all pass the same tests): 2×2
(reference), 2×2 with slices / guard latency 3 / decode stage, out-of-order, no guard, minimum depths, 4×2, 3×3 sparse with bound domains,
**5×7** (the Albion-sized system), 8×4. `NM ≤ 16` (the `FLOOR` register holds 2 bits per master). Counter and queue state grow with
`NM·NT` (crosspoint queues) and `NCNT = 16 + 20·NM + 32 + 14·NT + NM·NT`; `PERF` can be sized down with `CW` (counter width).
