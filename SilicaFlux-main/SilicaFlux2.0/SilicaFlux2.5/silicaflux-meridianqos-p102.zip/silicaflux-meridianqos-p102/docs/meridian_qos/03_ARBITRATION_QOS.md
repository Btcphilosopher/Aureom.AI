# 03 — Traffic classes, arbitration, fairness and the assumptions behind it

## 1. What is arbitrated

Contention exists **per target**: the heads of the NM crosspoint queues `XQ[0..NM-1][t]` compete for target t's egress queue. Each target has its
own `sf_meridian_arbiter`; different targets never interact ("NT transfers per cycle"). A transfer happens in the cycle `gvalid && en`, where `en`
is the registered "egress queue has room" flag; **the grant is the transfer** (nothing is granted that does not move, so no grant lock is needed;
a requester's head is stable until the grant pops it).

## 2. The four classes (scheduling classes, not latency contracts)

| class | purpose | typical master |
|---|---|---|
| `CLASS_0` | management and control | ControlCore, host management path |
| `CLASS_1` | latency-sensitive I/O | PacketCore, network processing |
| `CLASS_2` | bulk DMA and memory traffic | StreamDMA / CloudDMA |
| `CLASS_3` | background compute / data movement | TensorCore background loads |

Class 0 is the most urgent. The class of a request is `max(TCMAP[tc], FLOOR[master])` (`02_ABI.md §4`). All three arbitration policies, the
weights, the aging limit, the map and the floors are **configurable** at elaboration (`DEF_*` parameters) and at run time through privileged registers.

## 3. The policies (`CTRL.policy`)

**`POL_RR` — round robin.** Classes are ignored; one pointer rotates past the winner on every transfer. A requester that keeps requesting is served
after at most **N − 1** transfers of others.

**`POL_WRR` — weighted round robin over classes, round robin inside a class.** Each class has a *credit* (an 8-bit counter) reloaded to its weight `w_c`
(a weight of 0 behaves as 1) **when no requesting class has credit left**; among requesting classes that have credit, the most urgent wins; each
transfer consumes one credit of the winner's class. Within the winning class the masters rotate round robin with a **per-class pointer** (the pointer
of class k moves only when class k wins: with one shared pointer a stream of grants to another class could pin a single master of this class — the
unit bench `tb_arb` kills exactly that mutant). Properties:

* every class with a requester is served at least `w_c` times per round, **so no class is starved whatever the weights**; the hardware clamps a
  zero weight to 1, so a register mistake cannot switch a class off;
* under saturation the shares of the *active* classes are proportional to the weights, independent of how many masters each class has;
* it is work conserving: a class with no requester forfeits its slot, which is why a class whose crosspoint queue is empty at arbitration time gets
  less than its weight (§5 and `01_ARCHITECTURE.md §5`).

**`POL_STRICT` — strict class priority, optional aging.** The most urgent class with a requester wins; ties inside a class use the per-class pointer.
With `STARVE = S > 0`, a requester that has seen S transfers of others while requesting becomes **urgent** and sits above every class (ties among urgent
requesters round robin from the global pointer): bound **S + N − 1**, the Project 22 / 83 policy (checked cycle by cycle against the verified
`sfn_qos_arbiter`). With **S = 0 there is no starvation protection**: a class is starved for as long as a more urgent class keeps requesting. That is what
"strict" means; use S = 0 only for a class whose offered load is bounded by construction (for example management traffic). `STRICT_EN = 0` removes the
policy from the build (the register block then refuses to select it).

(Policy value 3 is reserved and rejected by the register block; if forced it behaves as `POL_RR`.)

## 4. Starvation bounds, and what they are measured in

A requester's **wait** is the number of transfers of *other* requesters at the same target between the moment it starts requesting (its head reaches the
arbiter) and its own transfer, while it keeps requesting.

| policy | bound on the wait | where it comes from |
|---|---|---|
| RR | `N − 1` | pointer rotation |
| STRICT, S > 0 | `S + N − 1` | aging counter ≥ S ⇒ urgent; at most N − 1 other urgent requesters precede it |
| STRICT, S = 0 | none | — |
| WRR | `(N − 1) + (⌈N / w_c⌉ + 1) · (W − w_c)`, `W = Σ w_k` | see below |

*WRR derivation.* In one round (between credit reloads) another class k is served at most `w_k` times, so at most `W − w_c` transfers of other classes per
round. The requester can be served only when its class has credit; within its class (≤ N requesters) it waits for at most N − 1 other class-c transfers,
each consuming one of the class's `w_c` credits per round, hence it needs `⌈N / w_c⌉` rounds in the worst case, plus the partial round in progress when
it started requesting. Everything the formula counts is an upper bound; it is deliberately not tight.

These bounds are **checked three ways**: (a) cycle by cycle in every simulation of `tb_arb` (per-requester wait counters, random configurations,
all policies; the bound monitor is part of the unit bench), (b) **formal** (`formal/meridian_qos/fv_arbiter.sv`: A1 one-hot / subset of requests, A2 work conservation, A3 the bound above, A4 the exact aging threshold,
under the assumptions of §5; ABC property-directed reachability, so a pass is an **unbounded** proof for the configurations run: RR N = 3, 4; strict + aging S = 3, 4 with N = 3, 4; WRR N = 3, 4
with the listed weights; six planted arbiter bugs are caught, `reports/formal.md`), (c) system-level share tests (`classes`). The bounds for other N, weights or aging limits are covered by (a) and (c),
not by a proof.

## 5. Assumptions required for fairness (all of them)

1. **The requester is present.** A bound is about a requester whose head sits at the arbiter. A request enters the arbiter only after it was admitted, which
   needs a free slot. **Slots (`MAXO`) must exceed the bandwidth-delay product of the master's path**, or its crosspoint queue is empty when the arbiter
   decides and a lower class legitimately gets the slot (measured, §6). Priority is only as good as the offered backlog.
2. **Heads are stable.** A crosspoint-queue head and its class do not change until it is popped (true by construction; assumption F1 of the formal harness).
3. **The configuration is constant** while a requester waits (policy, weights, S). Changing them is safe (no loss; test `policy_switch`) but voids the bound for
   requests in flight.
4. **Bounds are in transfers, not cycles.** No assumption on how often the target accepts is needed for the bound itself. To turn it into time you need a bound
   `Ts` on the target's service interval (one accept per `Ts` cycles): the wait is then at most `(bound + 1) · Ts` cycles from reaching the head, plus the
   time to reach the head (at most `XQ_DEPTH − 1` earlier requests of the same master to the same target, in issue order). The fabric cannot supply `Ts`;
   a stalled target stalls everyone behind it, by design (no timeouts, `08_LIMITATIONS.md`).
5. **The class is honest.** `tc` is master-presented and unauthenticated. Without `FLOOR`, a master can claim CLASS_0 and, under strict priority without aging,
   starve everyone. Program `FLOOR` for every master that is not trusted with management traffic.
6. **One in-order stream per master.** Requests of one master to one target stay in issue order (the ABI guarantee), so a master that mixes classes in one stream
   competes with the class of the request at its queue head, and a low-class request ahead of a high-class one delays it (head-of-line). The same holds for admission:
   a head held by the outstanding limit or the congestion throttle also holds the later requests of that master (never other masters). Give each traffic class its own
   master port where class separation matters.
7. **Strict priority without aging is not starvation-free** (§3).

## 6. What is promised, and measured

**Not a bandwidth or latency guarantee.** A guaranteed service level needs a bound on the target's service time, a bound on the offered load of every more urgent
class, and an admission policy; the fabric has none of the three. What *is* promised is the relative rule of §4 and, for WRR, proportional shares of the active classes.

Measured (test `classes`, 2 masters, one target accepting 25 % of the cycles, both masters saturating, 400 consecutive transfers after warm-up, `MAXO = 16`):

| policy | class 0 (m0) | class 3 (m1) | note |
|---|---|---|---|
| RR | 200 | 200 | classes ignored |
| WRR 8 : 1 | 355 | 45 | ideal 355.6 / 44.4 |
| WRR 0 : 0 (clamped to 1 : 1) | 200 | 200 | a zero weight cannot switch a class off |
| STRICT, aging off | 400 | **0** | the lowest class is completely starved (documented hazard) |
| STRICT, aging S = 8 | 355 | 45 | floor of one transfer per S + N − 1 = 9 |

The same test with `MAXO = 4` gave class 3 an 18 % share under *strict* priority (73 / 400): the two-slot-deep path leaves master 0's crosspoint queue empty
about a fifth of the time and the arbiter, work conserving, serves class 3 then. Test `floor`: two masters asking for CLASS_0 get 200 / 200; after master 1's floor is
set to CLASS_3 they get 351 / 49 under WRR 8 : 1, and the demotions are counted. Results for four classes (4 masters): `reports/regression.md`, test `classes` in
`m4t2_classes`, `m8t4`.

## 7. Choosing a policy

* *Latency-sensitive control plus bulk traffic:* WRR with weights such as 8 / 4 / 2 / 1 (the default). Every class progresses; class 0 gets the lowest latency
  that a saturated target allows without starving the rest.
* *Hard preference for a small, bounded management class:* STRICT with S > 0 (S sets the starvation floor of the others: 1 transfer per S + N − 1).
* *No class distinction (or untrusted `tc`):* RR, or any policy with `FLOOR` set for every master.
