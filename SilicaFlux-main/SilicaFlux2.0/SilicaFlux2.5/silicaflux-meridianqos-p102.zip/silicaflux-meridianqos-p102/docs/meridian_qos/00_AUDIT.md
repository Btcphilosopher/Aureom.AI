# 00 — Repository audit (Project 102, MeridianQoS)

Audited: `btcphilosopher/Aureom.AI`, working tree as cloned. The SilicaFlux RTL lives almost entirely inside zip archives under
`SilicaFlux-main/` and `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`; there is no loose RTL for the fabric in the repository.
Every archive that could contain a fabric, bus, arbiter, DMA, SRAM, packet or tensor block was extracted into a scratch directory
(untrusted data, read only, never executed) and read. **Nothing was committed to the repository; the project is delivered as an
archive.** Facts below are *found in files* unless marked *(inferred)*. Citations are relative to the extracted archive named in the
first column.

## 1. The names in the brief, mapped to real blocks

A text search of every archive member name and of every extracted README / document / RTL file found **no** `MemoryGuard`,
`MemoryMatrix` or `StreamDMA` (searched case-insensitively, also as `memory_guard`, `mem_guard`, `memguard`, `memory_matrix`,
`memmatrix`, `stream_dma`). They are code names in the brief, not existing blocks — the same situation Project 83 found for the
names in its brief. The mapping used here:

| Brief name | Found | Evidence | Role in this project |
|---|---|---|---|
| **Meridian** | **Project 83**, `silicaflux-meridian-p83.zip`: `rtl/albion/sf_meridian_fabric.sv` (+ mport, router, arbiter, decoder, slice, perf, citadel_ref, pkg) | its `README.md`, `docs/meridian/00_AUDIT.md`; 48/48 runs, 31/31 mutants, 34 formal jobs | **the baseline**. Its transaction contract is reused unchanged (§3). Its modules are *not* vendored (same module names as the deliverables); the new RTL implements the same contract with scheduling added |
| **DataFabric** | `silicaflux-datafabric.zip` (SFB2: `sfb_arbiter`, `sfb_addr_decoder`, `sfb_skid_buffer`) and `silicaflux-datafabric-noc.zip` (**Project 22**, SFB3: `sfn_pkg`, `sfn_mst_port`, `sfn_xbar`, `sfn_qos_arbiter`, `sfn_fifo`, bridges) | DF `docs/datafabric/PROTOCOL.md:18-33`; NOC `rtl/noc/sfn_pkg.sv`, `docs/PROTOCOL.md:19-51` | SFB3 is the protocol family Meridian extends. `sfn_fifo` and `sfn_qos_arbiter` are **vendored unmodified** (SHA-256 below) as verification oracles |
| **NoC spine** | `silicaflux-noc-spine-p34.zip` (Project 34): segmented crossbar, class-aware arbiter with an aging floor | `rtl/spine/sfs_pkg.sv:20-30`, `sfn_qos_arbiter.sv:4-13`, `docs/PROTOCOL.md:78-85` | architectural precedent for aging; its 2-bit classes (CTRL 0, RD 1, WR 2, CPL 3) are **not** the brief's classes |
| **Request / response interfaces** | SFB2 (`req_*`/`rsp_*`, no id, 1 outstanding); SFB3 (`opcode[3]`, `id`, `qos[3]`, `addr`, `wdata`, `wstrb`; status 2 bit); **Albion format as carried by Meridian** (P83: SFB3 + `dom`, `priv`, `tc`, 3-bit status, `src` stamp) | DF `PROTOCOL.md:18-33`; NOC `sfn_pkg.sv:18-44`; P83 `docs/meridian/02_PROTOCOL.md` | the contract (§3) |
| **ControlCore** | `silicaflux-controlcore.zip`: master `ext_*` (SFB2, 32-bit address / data, `wstrb` 4) and target `hs_*`; CPU I/D ports are OBI-style | CC `rtl/silicaflux_control_core.sv:49-58,71-80`; `third_party/silicaflux-mcu-i/rtl/cpu/mcu_cpu.sv:62-77` | master model: sparse blocking single-beat MMIO (workload `control_core`) |
| **MemoryMatrix** | **not found.** Nearest: `silicaflux-memorycore1.zip` (shared SRAM: 6 requesters, 8 banks × 8192 × 36 b, per-bank round robin, `MAX_OUT` 4); `silicaflux-memorypool-p65.zip`; the SRAM family P71–P77 (`sramfabric` P74 is an SFB3 target, latency 4) | MC `docs/02_SHARED_SRAM.md:14,34-46`; SF `rtl/sf_sram_datafabric.sv:62-77`, README:35 | target models: shared SRAM (1-4 cycle) and external memory (12-40 cycle) |
| **StreamDMA** | **not found.** Nearest: `silicaflux-clouddma-p64.zip` (CloudDMA: **AXI4 master**, INCR bursts of 16 beats, `RD_OUT`/`WR_OUT` 4, out of order across IDs); `silicaflux-hpc-m05-dma-adapter.zip` (SFB2 master, `MAX_OUT` 1..16); `mcu_dma` | DM `rtl/silicaflux_cloud_dma.sv:33-35,91-123`; HP `rtl/hpc_dma_adapter.sv:73,143-152` | master model: 16-beat bursts, never crossing 4 KiB (workload `stream_dma`) |
| **PacketCore** | `silicaflux-packetcore-p62.zip`: **no memory-side bus**; AXI-stream-like `s_*/m_*/x_*` (DW 128, `keep`, `last`, `src`, `meta`), register bus `rb_*`; **3-bit traffic class `m_tc`/`x_tc`** with its own RR / SP / DWRR scheduler and `SCHED_STARVE` guard. A test adapter (`sfd_packetcore_tadapter`, P61) is a 32-bit SFB2 master | PK `rtl/silicaflux_packet_engine.sv:35-37,63-93`, `docs/SCHEDULER.md:9`, `docs/CLASSIFIER.md:20`; P61 adapter `:2-4,15,46-55` | master model: frames on Poisson arrivals, descriptor + payload accesses (workload `packet_core`) |
| **TensorCore** | `silicaflux-tensorcore04.zip`: **no bus** (accumulator storage ports); the tensor *bus master* is TC08, vendored in ControlCore: SFB2 `m_*`, `MAX_OUT` 4 (limited to 1 by the crossbar R6) | T4 `docs/ARCHITECTURE.md:245`, `docs/STORAGE_INTERFACE.md:19-28`; CC `third_party/silicaflux-tensorcore08/rtl/silicaflux_tensor_unit.sv:53,88-97` | master model: 32-beat sequential reads, every 8th burst a write (workload `tensor_core`) |
| **Transaction tags** | SFB3 `id` (IDW 2, same-ID in order, different IDs unordered); Albion/P83 `tag` (`TAGW`, unique among a master's outstanding); CloudDMA `ID_W = CHW+SW+1` | NOC `docs/PROTOCOL.md:108-117`; P83 `02_PROTOCOL.md §2`; DM `docs/01_ARCHITECTURE.md:59` | `tag` of the Albion format, unchanged |
| **MemoryGuard** | **not found.** Nearest: **DomainGuard** (Module 97, `rtl/dg/sf_albion_iommu.sv`) — an *inline per-port filter* on a different bus ("DG-Lite"), **no check-only port**, store-and-forward, 3n+5 cycles, 1 burst per port; CloudDMA's `iommu_req/rsp_*` — the **only request/response permission contract** in the tree (`{domain, asid, write, addr, bytes, id}` → `{ok, fault[4], pa}`); P83's Citadel check interface (same idea); `sfd_sram_guard`, `sfd_host_guard` | DG `rtl/dg/sf_albion_iommu.sv:64-107`, `docs/04_INTEGRATION_GUIDE.md:45-47,151-155`; DM `docs/03_PROTECTION.md:40-57` | **defined here as an interface** (`grd_*`, §5 of `03_ISOLATION`); a reference model stands in for the guard |

**Consequence for "Connect to MemoryGuard".** There is no module to connect to and DomainGuard cannot be connected to a crossbar
as it stands: it is a datapath filter, and wrapping it per master port would cost ≥ 3n + 5 cycles and one burst per port, cancelling
the benefit of multiple outstanding transactions *(inferred from its integration guide)*. MeridianQoS therefore exposes the check as
an interface — one query channel and one in-order registered verdict channel per master — the contract CloudDMA already defines and
Project 83 adopted. A real guard (or a thin wrapper around `sf_albion_xlate`, DomainGuard's pure check block) must implement it.

## 2. What exists, and the decision for each

| Area | Found | Decision |
|---|---|---|
| **Project 83 Meridian** | registered crossbar, one buffer per crosspoint, per-target round robin / class-aware (5 `tc` levels + aging) arbiter, slot table with in-order / out-of-order delivery, register slices, timeouts and fault isolation, Citadel check at the master port, error log, counters, formal + mutation | **Contract reused; architecture followed** (registered crosspoint queues, ingress check, slot table, independent response network). **Not vendored**: its modules share the deliverables' names (`sf_meridian_arbiter`, `_router`, `_perf`) and P83's arbiter has a single global pointer and no weighted policy. Its `sf_meridian_pkg` is vendored unmodified for the ABI equality test |
| **P22 `sfn_fifo`, `sfn_qos_arbiter`** | verified FIFO (unbounded proof) and aging QoS arbiter | vendored **unmodified** (`third_party/p22/SHA256SUMS`, byte-identical to `silicaflux-datafabric-noc.zip`); used as oracles (`tb_queue_diff`, `tb_arb`) |
| P34 NoC spine | segmented crossbar + class arbiter + aging | precedent only |
| SFB2 → SFB3 bridges (P22) | `sfn_sfb2_mst_bridge` / `tgt_bridge` | the way the SFB2 endpoints (ControlCore, TC08, DMA adapter, MemoryCore) attach; **not integrated here** |
| CloudDMA (AXI4) | the one AXI-style master | needs an AXI4 ↔ SFB3 bridge; **not provided** (gap, §4) |
| `Finite State Machines Library` round-robin / priority arbiters | plain RR, no classes, no aging | not reused |

## 3. The transaction contract that is reused

Project 83's *Albion transaction format as carried by Meridian* = SFB3 (Project 22) extended with `dom`, `priv`, `tc` and a 3-bit
status. MeridianQoS takes it **field for field, code for code**:

* request fields `op[2] tag dom priv tc[3] addr wdata wstrb` (+ `src` stamped on the target side); response `src tag dom op status[3] rdata`;
* status `OKAY 0, SLVERR 1, DECERR 2, DENIED 3, TIMEOUT 4 (reserved here), PROTO 5`; fault codes `F_*`; violation events `V_*` 0..7;
* single-beat transactions, acknowledged writes only, per-(master,target) request order, in-order or out-of-order response delivery
  per port, `src` unforgeable, `tag` / `dom` / `priv` / `tc` / `addr` / data / strobes reach the target unchanged;
* flat valid/ready port naming (`m_req_*`, `m_rsp_*`, `t_req_*`, `t_rsp_*`).

`tests/meridian_qos/tb/tb_abi_check.sv` compiles the vendored P83 `sf_meridian_pkg` (SHA-256 `ae509d1b…e38e8d`) with
`sf_meridian_qos_pkg` and fails if any of the 40 shared constants differs (**PASS: 40 identical**). Nothing on the wire changes;
the scheduling class is an **internal sideband** derived from the existing `tc` field (`02_ABI.md §4`).

What MeridianQoS *adds* to P83 (scheduling, not protocol): four scheduling classes and a programmable `tc → class` map; round robin /
weighted round robin / strict priority with a documented starvation floor; a per-master class floor; per-class outstanding limits and a
congestion throttle; privileged registers; queue / stall / contention / back-pressure / utilisation / latency counters; a pipelined guard
check with resource reservation. What it *removes* from P83 (stated in `08_LIMITATIONS.md`): request / response timeouts, target isolation
and zombie flushing (`ST_TIMEOUT` stays in the ABI but is never produced), and the in-fabric reference Citadel table (now an external
reference model).

## 4. Endpoint facts used to build the workloads

| Block | Interface of its memory-side port | Traffic shape | Class field |
|---|---|---|---|
| ControlCore | SFB2 master, 32 / 32 / `wstrb` 4, **1 in flight**, in order | blocking loads / stores, partial strobes | none (bridge stamps `QOS_CTRL`) |
| PacketCore | streams, not a bus; DW 128 | up to 9216 B frames, 1.0 beat / cycle; bad frames dropped | **3-bit `tc`** on its streams |
| TensorCore (TC08 master) | SFB2 master, `MAX_OUT` 4 → 1 | 32-beat sequential reads, every 8th burst a (posted) write | none (bridge stamps `QOS_TENSOR`) |
| CloudDMA | **AXI4**, `AW` 48, `DW` 64, `ID_W`, `asid[4]`, `domain[4]` | 16-beat INCR bursts, 4 KiB rule, `RD_OUT`/`WR_OUT` 4, ~1:1 read / write | none (`domain` only) |
| MemoryCore1 (shared SRAM) | SFB2 target ×6 requesters | 1 word / cycle / port, RD_LAT 1, per-bank RR, errors → `rsp_error` | none |
| SRAMFabric P74 | SFB3 target | latency 4 registered, 15.96 B/cycle at DW 128, errors → SLVERR | ignores `qos` |

*(inferred)* Of the six, only PacketCore carries a class natively, and on a stream interface. Every SFB3 `qos` value today is a per-port
constant set at the bridge, so the class of a master is better taken from the **port** than from the endpoint RTL: that is why MeridianQoS
has a per-master class **floor** (a master may ask for a more urgent `tc`, the fabric will not honour it beyond the floor).

## 5. Gaps this project does not close

* **No real MemoryGuard exists**; the check interface is defined and exercised against a reference model. Connecting DomainGuard needs a wrapper.
* The endpoint blocks (ControlCore, PacketCore, TensorCore, CloudDMA, MemoryCore) are **not integrated**; bench models with their traffic
  shapes stand in. CloudDMA needs an AXI4 ↔ SFB3 bridge; the SFB2 endpoints need the P22 bridges.
* The brief's `StreamDMA` and `MemoryMatrix` are modelled by the nearest real blocks' traffic, not instantiated.
* No ASIC library or PDK exists in the repository (the `p40` package names Nangate45 but ships no liberty file), so no ASIC timing or area
  is possible; synthesis numbers here are technology-independent or FPGA-placed (`06_PIPELINE_AND_SYNTHESIS.md`).
* Several archives carry no licence file.

## 6. Vendored files (unmodified, hash-pinned)

| file | SHA-256 | used as |
|---|---|---|
| `third_party/p22/sfn_fifo.sv` | `6fe79fca43586fa7e5b7fdaf03c623e3275de9484cd5b0e43a3fd91be182aefc` | oracle of `sf_meridian_queue` |
| `third_party/p22/sfn_pkg.sv` | `2ef74ee4549b21bf4f405c806a7dd04f32cc71cfb7c747cef5580b057e208973` | package of the FIFO / arbiter |
| `third_party/p22/sfn_qos_arbiter.sv` | `d9bc3c36d6ffa6de6bab45b2f6d28127ee26ec9137ec3b0af0303c3a016e5fa6` | oracle of `sf_meridian_arbiter` (RR, strict+aging) |
| `third_party/p83/sf_meridian_pkg.sv` | `ae509d1ba241ecc3d3a36802b86ba62681c7414edfa225c0585e92c92ee38e8d` | the ABI the new package is compared with |

The P22 files are byte-identical to `silicaflux-datafabric-noc.zip` (compared at audit time) and carry the hashes recorded by Project 83.
