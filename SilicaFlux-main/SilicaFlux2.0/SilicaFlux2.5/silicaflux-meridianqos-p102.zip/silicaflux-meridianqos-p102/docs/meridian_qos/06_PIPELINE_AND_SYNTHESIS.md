# 06 — Pipeline optimisation and synthesis results

## 0. What was measured, and with which tools

There is **no ASIC library or PDK in the repository** (the `p40` package names Nangate45 but ships no liberty file), so no ASIC area, frequency or power is claimed. Three measurements are made, all reproducible
(`benchmarks/meridian_qos/synth.py`, `make synth`):

1. **Technology-independent gate cost and logic depth**: Yosys 0.33 `synth` + ABC mapped to a 2-input gate library → cell count; `ltp` → the longest topological register-to-register path in gate levels.
2. **FPGA area**: Yosys `synth_ecp5` → LUT4 / flip-flop / carry / distributed-RAM counts (Lattice ECP5).
3. **FPGA timing**: `nextpnr-ecp5` placement and routing on a Lattice LFE5U-85F, speed grade 6, **60 MHz target, two or three placement seeds per configuration** (three for `base`, two for the others; `noguard` and `perf16` are area-only); Fmax of `clk`. The design has ~700 I/O bits, so it is timed inside a generated shell
   (one serial input shift register; outputs registered and folded through a registered XOR pipeline into one pin), which keeps every path *inside* the fabric flop-to-flop. The shell's own flip-flops are reported
   separately and are excluded from the DUT area.

Fmax from place-and-route depends on the placement, the target and the seed (min / median / max over the seeds run are reported; with two seeds the median is their mean). It is a **relative** measure for comparing pipeline configurations, not a prediction
of silicon frequency and not sign-off.

## 1. What the first synthesis found, and what was changed in the RTL

The design had passed simulation and formal before it was synthesised. Synthesis then found five structural problems, each fixed and re-verified (regression, unit benches, formal):

| finding | cause | fix | effect |
|---|---|---|---|
| Yosys used **> 12 GB** and was killed | the counter module wrote per-class counters with a *runtime* class index into a 3 600-bit vector (a decoder / shifter per statement) | per-class counters computed with constant class loops | synthesis in ~70 s |
| LUTs: 27 278 for 4 600 flip-flops | slot-table fields and the counter bank read / written with variable-start part-selects of packed vectors (`srd_q[ridx*DW +: DW]`): Yosys builds a **barrel shifter** (4 × `$mul`, 6 × `$shift_128`) because it cannot know the index takes only `MAXO` values | constant-index loops (a plain multiplexer / write-enable decode) in the master port, the router's response mux, the counter read | −33 % LUTs |
| combinational unpacked arrays (`wt`, `ncls`) inferred as memories with asynchronous write ports | arrays written in `always_comb` | packed vectors | cleaner netlist, tractable formal |
| **Fmax 16 MHz**: a 60 ns path slot state → per-class count → admission → event → counter adder | the performance counters observed the datapath combinationally | event inputs registered before counting (about 200 flip-flops, one cycle of counter lag) | removed the counters from the critical path |
| Fmax 19 → 34 MHz: per-class outstanding counts recomputed from the slot table every cycle (a loop of adders) | | registered counters (+1 at allocation, −1 at delivery) | |
| Fmax 34 → 43 MHz: arbiter pick logic with a shifter, a variable-index class select and a variable-index pointer | | one-hot pick, AND-OR class select, constant-slice pointers (behaviour identical: unit benches + PDR proofs re-run) | |

Fmax trajectory of the 2 × 2 baseline (64-bit address / 32-bit data shell): 16.2 → 18.7 → 34.1 → 43.2 MHz at a 200 MHz target, which is *not* achievable and degrades the placement; the sweep below uses a 60 MHz target.

## 2. Area (2 × 2, `DW = 32`, `AW = 32`, 4 slots, 32-bit counters)

Per module (Yosys `synth_ecp5 -noflatten` of the first, un-optimised revision, LUT4): performance counters 15 209 (**48 % of all LUTs, 78 % of the flip-flops**), each master port 6 998, router 355, registers 646, arbiters
437, decoder 9, queues 12-21 each (their storage is distributed RAM). The measurement logic is the dominant cost of this fabric at 32-bit counters: `CW` (counter width, parameter) and the counter set are the first
things to cut for an area-limited build (measured below: the `perf16` configuration, 16-bit counters, takes 33 % of the LUT4 and 36 % of the flip-flops out of the whole 2 × 2 fabric); the data path itself is small.

## 3. The pipeline sweep

Configurations (`MSL` = register-slice stages at every master port, request and response; `TSL` = at every target port; `DEC` = register stage after the ingress queue):

<!--SWEEP-->
| config | request +cyc | response +cyc | req / cycle | class-0 mean lat (cyc) | class-0 p99 | LUT4 | FF | gate levels | Fmax MHz (min / med / max) | class-0 mean lat (ns) | Mreq/s |
|---|---|---|---|---|---|---|---|---|---|---|---|
| `base` | 4 | 3 | 0.369 | 23.93 | 38 | 14824 | 4842 | 126 | 41.3 / 43.2 / 45.2 | 554.4 | 15.94 |
| `dec` | 5 | 3 | 0.347 | 24.76 | 39 | 14817 | 5042 | 126 | 42.4 / 45.0 / 47.7 | 549.7 | 15.63 |
| `ms1` | 5 | 4 | 0.327 | 25.69 | 40 | 14840 | 4858 | 126 | 40.5 / 42.6 / 44.7 | 602.7 | 13.96 |
| `ts1` | 5 | 4 | 0.328 | 25.54 | 40 | 14927 | 4858 | 126 | 41.7 / 42.3 / 42.9 | 604.2 | 13.86 |
| `dec_ms1` | 6 | 4 | 0.309 | 26.87 | 41 | 14826 | 5058 | 126 | 45.4 / 45.8 / 46.2 | 586.9 | 14.13 |
| `dec_ms1_ts1` | 7 | 5 | 0.279 | 28.92 | 43 | 14932 | 5074 | 126 | 41.0 / 42.1 / 43.2 | 687.5 | 11.75 |
| `dec_ms2_ts1` | 8 | 6 | 0.253 | 30.99 | 45 | 14945 | 5090 | 126 | 40.9 / 41.1 / 41.3 | 754.4 | 10.41 |

Area options (synthesis only, no place-and-route; same 2 x 2 reference, LUT4 / FF from Yosys `synth_ecp5`):

| config | what changes | LUT4 | FF | gate cells | vs `base` LUT4 / FF |
|---|---|---|---|---|---|
| `base` | reference | 14824 | 4842 | 37317 | - |
| `noguard` | `GUARD = 0`: no MemoryGuard query port / reservation queues | 14354 | 4816 | 33879 | -3 % / -1 % |
| `perf16` | `CW = 16`: 16-bit counters instead of 32-bit | 9940 | 3114 | 25184 | -33 % / -36 % |
<!--/SWEEP-->

Added cycles are **measured and asserted** by test `latency_idle` against the formulas of `01_ARCHITECTURE.md §6` on every route (request = 3 + `MSL` + `TSL` + `DEC` + guard verdict latency, response = 3 + `MSL` + `TSL`).
Throughput is the benchmark scenario `s2_ref` (`benchmarks/meridian_qos/results/bench.md`); one request per cycle per port is sustained in every configuration (the registered `valid/ready` queues have two entries per
slice stage), so stages cost latency, not bandwidth.

## 4. The selection

<!--SEL-->
**Selected: `base`.** Rule (computed by `benchmarks/meridian_qos/report.py`): keep the configurations whose best-seed Fmax is within 5 % of the best median, take the one with the smallest mean class-0 round-trip latency in nanoseconds (cycles / Fmax), break ties with the smaller flip-flop count, and leave the simplest candidate only for a gain larger than the seed-to-seed Fmax spread. Result: median Fmax **43.2 MHz**, class-0 mean latency **554.4 ns**, 14824 LUT4 / 4842 FF.

Why not a pipelined configuration: rules 1-3 pick `dec` (549.7 ns) over `base` (554.4 ns): a gain of 0.9 %, inside the seed-to-seed Fmax spread of 11.9 %; not significant, so the simplest candidate `base` is kept (rule 4). The rule had to be made noise-aware after the first sweep (rules 1-3 alone picked `dec`, a 0.9 % gain); the change is recorded in the header of `report.py`.

**Honest reading.** On this FPGA proxy the optional stages cost cycles and do **not** buy a measurable Fmax: every configuration closes between 40 and 48 MHz at a 60 MHz target, the gate-level depth (`ltp`) is 126 in all of them, and the seed-to-seed spread (up to about 12 %) is as large as the differences between configurations. The longest path (nextpnr critical-path reports) is inside the router: crosspoint-queue read (distributed RAM) -> class select -> target-arbiter pointer / credit update. The optional stages sit before that queue and at the port boundaries, so they do not cut it (registering the queue head's class would be the next optimisation; it was not done because the RTL was frozen for the final verification). The stages remain as parameters for a floorplan where a wire between blocks, which this proxy cannot show, is the limit; there is no measurement here that recommends them.

The reset values / defaults of `sf_meridian_qos` keep the **unpipelined** structure (`DEC_PIPE = 0`, no slices) so that the verified 2 × 2 reference has the shortest latency; the pipelining is a parameter set chosen per floorplan. The unpipelined default is also what the selection rule chose.
<!--/SEL-->
