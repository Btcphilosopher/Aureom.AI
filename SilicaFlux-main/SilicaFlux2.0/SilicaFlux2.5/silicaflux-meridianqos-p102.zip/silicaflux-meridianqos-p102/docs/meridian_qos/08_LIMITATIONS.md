# 08 — Limitations: what is not claimed, and what is not done

Read this page before relying on the project. Each item is something a reader could otherwise assume.

## Design

1. **No MemoryGuard exists in the repository** (`00_AUDIT.md §1`). The `grd_*` interface is defined here and exercised against `sf_meridian_guard_ref`, a *model*. DomainGuard
   cannot be connected as it stands (it is a datapath filter); a real guard needs a wrapper that meets the contract (one in-order **registered** verdict per accepted query,
   ≥ 1 cycle later). A combinational guard is not supported. There is **no guard timeout**: a guard that never answers stalls its master (fail closed, but not fail fast).
2. **No timeouts and no target isolation.** `ST_TIMEOUT` is in the ABI and never produced. A target that never answers a request blocks the master's slot, and a target that stops
   accepting fills its own queues and then back-pressures its masters. Project 83's timeout / isolation / zombie machinery was deliberately not carried over: a timeout turns an
   *accepted* transaction into an error response, which sits badly with "do not drop accepted transactions because congestion increases".
3. **Class isolation is per master, not per request.** A master's requests to one target stay in issue order (the ABI guarantee), so a master that mixes classes in one stream competes
   with the class of its queue head; an admission hold (class limit, congestion throttle) holds that master's later requests. Separate traffic classes should use separate master ports.
   A per-class crosspoint queue would remove this and would relax the ordering guarantee across classes — an ABI amendment, not done here.
4. **Priority is not a guarantee.** No bandwidth or latency is promised (`03_ARBITRATION_QOS.md §6`). Strict priority without aging starves (shown, not hidden). The fairness bounds hold
   for a constant configuration and for requesters whose heads are present at the arbiter; with too few slots (`MAXO`) a high class is *absent* from the arbiter and a lower class gets
   its slot (measured: 18 % instead of 0 %).
5. **The class is only as honest as the master.** `tc` is unauthenticated; the per-master `FLOOR` must be programmed for every master that is not trusted with urgent classes.
   `priv` and `cfg_priv` are trusted inputs the platform must derive from an authenticated source. Side-channel isolation (latency through shared arbiters and queues) is not addressed.
6. **ABI limits inherited from Project 83**: single-beat transactions, acknowledged writes only (no posted writes, fences, atomics, bursts); a duplicate response arriving *after* its tag was
   re-issued to the *same* target cannot be told from the new transaction's response (no sequence numbers on the wire); a reused tag is dropped without a response.
7. **Endpoints are not integrated.** ControlCore, PacketCore, TensorCore, CloudDMA, MemoryCore are represented by bench models with their audited traffic shapes. CloudDMA (AXI4) needs an
   AXI4 ↔ SFB3 bridge that does not exist; the SFB2 endpoints attach through the Project 22 bridges, not exercised here. The brief's `StreamDMA` and `MemoryMatrix` do not exist in the repository.
8. Counters wrap at `2^CW` and lag the datapath by one cycle (events are registered before counting; reads after the fabric went idle are exact). Latency timestamps are `LATW = 16` bits:
   a transaction older than 65 535 cycles is mis-measured. `NM ≤ 16` (`FLOOR`), weights / limits / aging are 8 bit. One clock, no clock-domain crossings, no ECC, no power management.

## Verification (what the evidence is, and is not)

9. **Simulation** (Verilator 5.020, 2-state): X-propagation is not checked. Coverage is functional (the test list of `07_VERIFICATION.md`), not code coverage. The testbench's reference model
   was written by the same author as the RTL; the independent checks are the P22 oracles (`sfn_fifo`, `sfn_qos_arbiter`), the Project 83 ABI package, and the planted-bug campaigns
   (42 system mutants + 6 formal mutants), whose size is modest.
10. **Formal results are on small configurations and some are bounded.** Unbounded: the FIFO (depth 1, 2, 3, 4, 8, 4-bit data), the decoder (all addresses), the arbiter (RR, strict + aging,
    WRR for N = 3 and 4 with the listed weights and aging limits). **Bounded only:** the whole fabric (`fv_qos`, 2 × 2, 2 slots, 16-bit data), to the depth stated in `reports/formal.md`;
    there is **no unbounded proof of the full fabric**, and the arbitrary-traffic fabric checks reach 12 cycles from reset (deeper runs exceeded the time limit). "No request loss" is proved only as bounded completion in a *good* environment (one active master with **one outstanding transaction at a time**, ready targets that answer promptly: 8 cycles, 9 with the guard);
    under contention it rests on the queue / slot invariants, the scoreboard (exactly-once, every run) and the 3-seed regression, not on a proof. Reset behaviour is checked in simulation only
    (the harness applies reset in the first cycle). Full-size configurations (DW 64, 5 × 7, 8 × 4) are verified by simulation only.
11. A **testbench defect** was found and removed during this work (arrays of queues indexed by a variable are mishandled by Verilator 5.020, which made 3-or-more-master runs misleading until the
    testbench was changed to flat associative FIFOs). It is recorded here because a reader reproducing with another simulator version should not be surprised by the workaround.

## Synthesis and performance

12. **No ASIC library or PDK is in the repository**, so there is **no ASIC area, frequency or power**. The numbers in `06_PIPELINE_AND_SYNTHESIS.md` are (a) technology-independent gate counts and logic depth,
    and (b) an FPGA result: Yosys `synth_ecp5` + `nextpnr-ecp5` place-and-route on a Lattice LFE5U-85F (speed grade 6) at a 60 MHz target, two or three seeds per configuration. Fmax from nextpnr depends on the placement,
    the target frequency and the seed, and the design is timed inside a generated shell (serial input shift register, registered XOR output folding) so it fits the pins; it is a **relative** measure
    for comparing pipeline configurations, **not** a prediction of silicon speed, and not sign-off. Power was not measured.
13. Throughput and latency numbers are **simulation results for the audited traffic shapes** (generated traces, fixed seed), with bench targets (SRAM 2-4 cycles, external memory 12-30 cycles). They are
    reproducible, not measurements of real endpoints.
14. The 2 × 2 reference with 64-bit data is the verified configuration; the synthesis sweep uses 32-bit data and 32-bit addresses to fit the FPGA shell. Counter area is large (about half of the LUTs
    at 32-bit counters, see the breakdown); `CW` can be reduced.

## Process

15. No licence file exists for the vendored Project 22 / 83 files or for the SilicaFlux archives. Nothing was committed to GitHub; the project is delivered as an archive.
