# 04 — Privileged registers (`sf_meridian_qos_regs`)

One access per cycle on a request / registered-response port: inputs `cfg_valid, cfg_write, cfg_addr[5:0] (word address), cfg_wdata[31:0],
cfg_priv`; one cycle later `cfg_rvalid, cfg_rdata, cfg_err`. `cfg_priv` must come from authenticated management hardware (Keystone's
privileged path); like `priv` on a transaction it is a **trusted input** the fabric cannot authenticate.

## Rules (each is a tested behaviour: test `regs`, mutants G1-G6)

* Every register except `ID` and `VERSION` requires `cfg_priv` for **reads and writes** (counters and the error log leak the activity of
  other domains). An unprivileged access changes nothing, returns 0, sets `cfg_err`, increments `SECCNT` and sets `STATUS.SEC`.
* `CTRL.lock` is **set-only** (cleared only by reset). While locked, the scheduling configuration (`CTRL` policy / `cong_en`, `WEIGHTS`,
  `STARVE`, `TCMAP`, `FLOOR`, `OUTLIM`, `CONG`) rejects writes (`cfg_err`, `SECCNT++`). `PERF_SEL`, `PERF_CTRL`, `STATUS`, `ELOG_CTRL` stay
  writable: they do not change scheduling.
* Illegal values are **rejected, not truncated**: policy 3 (reserved), policy 2 when `STRICT_EN = 0`, `CONG` with `lo > hi`, `PERF_SEL ≥ NCNT`.
  Unknown addresses and writes to read-only registers fail.
* A weight of 0 and an outstanding limit of 0 are accepted and read back as written, but the hardware treats them as 1: **no class can be
  switched off or starved through these registers**.
* Reset restores every register to its parameter default (below) and clears the lock.

## Map (word offset; byte address = 4 × offset)

| off | name | acc | fields / meaning | reset |
|---|---|---|---|---|
| 0 | `ID` | RO (public) | `[31:16]` magic `0x4D51` ("MQ"), `[15:8]` NM, `[7:0]` NT | |
| 1 | `VERSION` | RO (public) | `0x0001_0000` | |
| 2 | `CTRL` | RW | `[1:0]` policy (0 RR, 1 WRR, 2 STRICT), `[4]` congestion throttle enable, `[31]` lock (set only) | policy `DEF_POLICY` = 1 (WRR), throttle off, unlocked |
| 3 | `WEIGHTS` | RW | `[8c+7:8c]` weight of class c (0 behaves as 1) | `DEF_WEIGHTS` = 8 / 4 / 2 / 1 (class 0 … 3) |
| 4 | `STARVE` | RW | `[7:0]` strict-priority aging limit S: a requester that saw S transfers of others becomes urgent; 0 = aging off | 16 |
| 5 | `TCMAP` | RW | `[2t+1:2t]` class of wire `tc` t (t = 0..7) | `TCMAP_DEFAULT` (`02_ABI.md §4`) |
| 6 | `FLOOR` | RW | `[2m+1:2m]` most urgent class master m may use (m < 16) | 0 (no restriction) |
| 7 | `OUTLIM` | RW | `[8c+7:8c]` outstanding limit of class c per master (0 behaves as 1; the slot count bounds the total) | 255 |
| 8 | `CONG` | RW | `[7:0]` hi, `[15:8]` lo (queue-occupancy hysteresis), `[17:16]` throttle class: classes ≥ it are held while the target is congested | thr 2, lo 2, hi 6 |
| 9 | `PERF_SEL` | RW | counter index | 0 |
| 10 | `PERF_DATA` | RO | selected counter | |
| 11 | `PERF_CTRL` | WO | `[0]` clear all counters (one-cycle pulse) | |
| 12 | `STATUS` | RW1C | `[0]` SEC (rejected access) `[1]` VIOL (protocol violation) `[2]` DENIED `[3]` DECERR; `[4]` (RO) error log holds a record | 0 |
| 13 | `ELOG0` | RO | `[31]` valid `[30:28]` status `[27:24]` fault `[23:16]` source master `[15:8]` tag `[7:0]` domain | |
| 14 | `ELOG1` | RO | address of the first fault (low 32 bits) | |
| 15 | `ELOG_CTRL` | WO | `[0]` clear the error log | |
| 16 | `SECCNT` | RO | number of rejected accesses | 0 |
| 17 | `NCNT` | RO | number of performance counters | |

The **error log** captures the first fault after reset / clear (later faults are counted by the counters, not logged): guard denial (oldest) >
response echo violation > local error, lowest master first when several occur in one cycle.

## Programming notes

* Change scheduling while the fabric is **quiescent** if you rely on the fairness bounds (`03_ARBITRATION_QOS.md`): a policy or weight change
  takes effect immediately and is safe (nothing is lost; test `policy_switch` changes policy every 30 cycles under traffic), but the bounds
  hold only for a configuration that stays constant while a requester waits.
* `FLOOR` / `TCMAP` / `OUTLIM` apply to requests dispatched after the write.
* A guard policy change applies to the next check; a request already forwarded completes. Revoke by quiescing first (same rule as CloudDMA).
