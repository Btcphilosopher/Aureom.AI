# tests/meridian_qos — simulation verification

Verilator 5.020 (`--binary --timing`, 2-state). Run: `make units quick regress mutate` from the project root.

| file | what it is |
|---|---|
| `tb/tb_meridian_qos.sv` | **the system testbench**: DUT + the external MemoryGuard reference model; master models (job queues, free-tag allocation, hold-until-ready, forced tag reuse), target models (random accept / latency / response back-pressure / reordering, memory model, error injection, corrupted / fake / duplicate responses), the scoreboard, stability monitors, the privileged-register tasks, and every test below. Test: `+TEST=<name> +seed=<n>`; trace benchmark: `+TEST=trace` |
| `tb/tb_arb.sv` | arbiter unit bench: independent behavioural model every cycle, differential check against Project 22 `sfn_qos_arbiter` (RR; strict + aging with one requester per class), bounded-wait monitors, WRR share check |
| `tb/tb_queue_diff.sv` | `sf_meridian_queue` against Project 22 `sfn_fifo`, cycle by cycle, six depths, with a reset in the middle |
| `tb/tb_abi_check.sv` | the 40 ABI constants shared with Project 83 are identical (vendored `sf_meridian_pkg`, unmodified) |
| `traces/` | (the workload traces live in `benchmarks/meridian_qos/traces/`) |

## The scoreboard (what every run checks, 1000s of checks per run)

* every request that reaches a target equals, **field by field** (`op tag dom priv tc addr wdata wstrb`), the request the master issued; it comes from the right master (`src`), goes to the decoded target,
  and appears **exactly once**; a request that the reference model says must be answered locally (reserved opcode, misalignment, spoofed domain, unmapped, no route, guard denial) must **never** reach a target;
* every response at a master matches its request (`tag dom op`), carries the target's own status and data (or the documented error status and zero data), arrives **exactly once**, and — for in-order masters —
  in acceptance order; a dropped (reused-tag) request and an orphan / duplicate target response produce **no** delivery;
* valid / ready stability on every DUT output channel (`t_req`, `m_rsp`, `grd_req`), no X on valid channels, the internal overflow monitor never fires.

## Tests (`+TEST=`)

| test | what it exercises |
|---|---|
| `basic` | every route (master → every reachable target): unique writes, read back, **memory contents checked directly**; unreachable routes must not write |
| `rand_clean`, `rand_bp`, `rand_err`, `rand_gstall`, `rand_reorder` | random mixed traffic: all classes (`tc` 0..7), random privilege and domains, multiple outstanding, **random back-pressure** (target accept, response ready, master response ready), random latency, **response reordering** at the targets, guard stalls, 12 % error injection |
| `contention` | all masters saturate one target with the same class: equal shares |
| `classes` | RR / WRR (8:4:2:1, 0:0:0:0) / strict (aging off, aging 8) shares at a saturated target (needs enough slots, `MAXO ≥ 12`) |
| `floor` | per-master class floor demotes a master that asks for CLASS_0 |
| `admission` | per-class outstanding limit; congestion throttle with hysteresis; nothing dropped; held cycles counted |
| `errors` | **concurrent errors** (every error kind at once with normal traffic): exact per-master status counters and violation counter, corrupted target answers, duplicate responses, first-error log |
| `tagreuse` | a reused tag behind a stalled target is consumed, counted, **not** answered |
| `saturate` | **queue saturation**: a target that never accepts back-pressures its masters, another target's traffic completes untouched, nothing is lost after release |
| `reset` | **reset under load**: registers restored, no stale delivery, a target outside the reset domain keeps answering (consumed), the fabric recovers |
| `latency_idle` | idle request and response latency of every route, asserted against the documented formula (`3 + stages …`) |
| `counters` | a deterministic scenario with every counter compared to the bench's own arithmetic |
| `regs` | privilege, lock, illegal values, defaults, read-only registers, security counter, status W1C |
| `policy_switch` | policy / weights changed every 30 cycles under traffic: nothing lost |
| `trace` | the benchmark mode (`benchmarks/meridian_qos/run_bench.py`) |

Configurations (`scripts/meridian_cfgs.py`): `ref_2x2`, `ref_2x2_m16`, `v_slices_dec` (2 + 1 slice stages, decode stage, guard latency 3), `v_ooo` (out-of-order masters),
`v_noguard`, `v_minimal` (1 slot, 2-entry queues), `v_dom_sparse` (bound domains + a missing route on the 2 × 2), `v_strict_off`, `v_pol_rr`, `v_pol_strict`, `m4t2_classes` (4 masters, 4 classes),
`m3t3_sparse`, **`m5t7_albion`** (5 × 7 with slices), `m8t4`.

## Mutation check (`scripts/mutate.py`)

42 deliberate RTL defects across queue, arbiter, router, master port, decoder, registers and wiring (a queue that overflows, a stuck pointer, aging disabled, WRR without reload, a payload mux that picks
the wrong master, a response routed to the wrong master, domain binding removed, guard verdict ignored, echo check removed, tag-reuse check removed, class floor ignored, privilege / domain metadata dropped
before the target, …). Each must make the regression (or, for the arbiter / queue, the unit bench) fail. Results: `reports/mutation.md`.
