// =============================================================================
// MeridianQoS unit bench: sf_meridian_queue against the verified Project 22 FIFO (sfn_fifo, PASS_FULL = 0),
// cycle by cycle, for several depths / widths, random push / pop pressure, with a reset in the middle of a run.
// Compared every cycle: in_ready, out_valid, count, and out_data whenever out_valid.  Also checked: count never leaves
// 0..DEPTH, a push is only accepted with in_ready, a pop only with out_valid (overflow / underflow cannot occur).
// =============================================================================
`timescale 1ns/1ps
module tb_queue_diff;
  logic clk = 0; always #5 clk = ~clk;
  logic rst_n = 0;
  int errors = 0; int compared = 0;

  for (genvar gi = 0; gi < 6; gi++) begin : g
    localparam int DEPTH = (gi == 0) ? 1 : (gi == 1) ? 2 : (gi == 2) ? 3 : (gi == 3) ? 4 : (gi == 4) ? 7 : 8;
    localparam int W     = (gi % 2 == 0) ? 8 : 37;
    localparam int CW    = sf_meridian_qos_pkg::clog2c(DEPTH + 1);
    logic iv, ir_a, ir_b, ov_a, ov_b, orr;
    logic [W-1:0] id, od_a, od_b;
    logic [CW-1:0] cnt_a, cnt_b;
    sf_meridian_queue #(.W(W), .DEPTH(DEPTH)) a (.clk, .rst_n, .in_valid(iv), .in_ready(ir_a), .in_data(id),
        .out_valid(ov_a), .out_ready(orr), .out_data(od_a), .count(cnt_a));
    sfn_fifo #(.W(W), .DEPTH(DEPTH), .PASS_FULL(0)) b (.clk, .rst_n, .in_valid(iv), .in_ready(ir_b), .in_data(id),
        .out_valid(ov_b), .out_ready(orr), .out_data(od_b), .count(cnt_b));
    int p_in, p_out;
    always @(negedge clk) begin
      iv  = (int'($urandom_range(99, 0)) < p_in);
      id  = {W{1'b0}} | W'($urandom);
      orr = (int'($urandom_range(99, 0)) < p_out);
    end
    always @(posedge clk) if (rst_n) begin
      compared++;
      if (ir_a !== ir_b)                         begin errors++; $display("FAIL depth %0d in_ready %b vs %b", DEPTH, ir_a, ir_b); end
      if (ov_a !== ov_b)                         begin errors++; $display("FAIL depth %0d out_valid %b vs %b", DEPTH, ov_a, ov_b); end
      if (cnt_a !== cnt_b)                       begin errors++; $display("FAIL depth %0d count %0d vs %0d", DEPTH, cnt_a, cnt_b); end
      if (ov_a && (od_a !== od_b))               begin errors++; $display("FAIL depth %0d data %h vs %h", DEPTH, od_a, od_b); end
      if (int'(cnt_a) > DEPTH)                   begin errors++; $display("FAIL depth %0d count overflow %0d", DEPTH, cnt_a); end
      if (ov_a !== (cnt_a != 0))                 begin errors++; $display("FAIL depth %0d out_valid != nonempty", DEPTH); end
      if (ir_a !== (int'(cnt_a) != DEPTH))       begin errors++; $display("FAIL depth %0d in_ready != notfull", DEPTH); end
    end
    initial begin p_in = 50; p_out = 50; end
    // vary the pressure over the run
    initial begin
      forever begin
        repeat (700) @(negedge clk);
        p_in  = $urandom_range(100, 5);
        p_out = $urandom_range(100, 5);
      end
    end
  end

  initial begin
    void'($urandom(11));
    repeat (3) @(posedge clk);
    @(negedge clk); rst_n = 1;
    repeat (20000) @(posedge clk);
    // reset in the middle of a run, both must come back empty
    @(negedge clk); rst_n = 0; repeat (2) @(negedge clk); rst_n = 1;
    repeat (20000) @(posedge clk);
    $display("STAT queue_diff cycles_compared=%0d", compared);
    if (errors == 0) $display("PASS tb_queue_diff");
    else             $display("FAIL tb_queue_diff errors=%0d", errors);
    $finish;
  end
endmodule
