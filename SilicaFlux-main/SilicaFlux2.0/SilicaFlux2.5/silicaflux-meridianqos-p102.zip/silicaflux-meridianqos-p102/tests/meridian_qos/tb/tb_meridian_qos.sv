// =============================================================================
// SilicaFlux -- Project 102 -- MeridianQoS :: system testbench  (Verilator --binary --timing)
//
// DUT: sf_meridian_qos + sf_meridian_guard_ref (outside, as an external MemoryGuard).  Parameters pick the
// configuration (-G...); the test is chosen with +TEST=<name> (+seed=<n>, +verbose).  Output: "PASS <test>" /
// "FAIL <test>" and greppable "STAT" / "RESULT" lines.
//
// Structure (races avoided by construction: ALL stimulus changes at negedge, ALL checking at posedge):
//   * master models   queue of jobs -> issue with free-tag allocation, hold valid/fields until ready, random
//                     response-ready;  forced tag reuse for protocol-violation tests
//   * target models   random accept / latency / response back-pressure / reordering, memory model, error injection,
//                     response corruption (echo, illegal status), fake (orphan / duplicate) responses
//   * scoreboard      per (master, tag) record; the TB's own reference model of the checks decides the EXPECTED outcome
//                     (forward to target t | local error with a given status | silently dropped tag reuse):
//        every request reaching a target is compared field by field with what the master issued, comes from the
//        right master (src), goes to the decoded target, exactly once; every response reaching a master is
//        compared (tag, dom, op, status, data) with the target's answer / the expected error, exactly once;
//        in-order masters get responses in acceptance order; nothing is delivered for a dropped or orphan response
//   * monitors        valid/ready stability on every DUT output channel, no X on valid channels, o_internal_err
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module tb_meridian_qos #(
  parameter int NM         = 2,
  parameter int NT         = 2,
  parameter int AW         = 32,
  parameter int DW         = 64,
  parameter int TAGW       = 4,
  parameter int DOMW       = 3,
  parameter int MAXO       = 4,
  parameter int IQD        = 4,
  parameter int XQD        = 4,
  parameter int EQD        = 2,
  parameter int TRQD       = 2,
  parameter int RQD        = 2,
  parameter int GQD        = 2,
  parameter int MSL        = 0,        // master-edge slice stages (all masters)
  parameter int TSL        = 0,        // target-edge slice stages (all targets)
  parameter int DECP       = 0,
  parameter int GUARD      = 1,        // 0: GUARD_EN = 0 (bring-up)
  parameter int GLAT       = 1,        // verdict latency of the reference guard
  parameter int STRICT_EN  = 1,
  parameter int OOO_MASK   = 0,        // bit m: master m delivers responses out of order
  parameter int CONN_SEL   = 0,        // 1: master 0 has no path to the last target
  parameter int DOMALLOW_SEL = 0,      // 1: master m may present domains {m%4, 4+m%4} only
  parameter int DEF_POL    = 1
);
  import sf_meridian_qos_pkg::*;

  // ---------------------------------------------------------------- derived constants
  localparam int SRCW  = clog2c(NM);
  localparam int NDOM  = 1 << DOMW;
  localparam int OFF   = $clog2(DW / 8);
  localparam int WINB  = 16;                                   // each target owns a 64 KiB window
  localparam int NCNT  = pf_n(NM, NT);

  function automatic logic [NT*AW-1:0] mk_base();
    logic [NT*AW-1:0] v; v = '0;
    for (int t = 0; t < NT; t++) v[t*AW +: AW] = AW'(t) << WINB;
    return v;
  endfunction
  function automatic logic [NT*AW-1:0] mk_mask();
    logic [NT*AW-1:0] v; v = '0;
    for (int t = 0; t < NT; t++) v[t*AW +: AW] = ~((AW'(1) << WINB) - AW'(1));
    return v;
  endfunction
  function automatic logic [NM*NT-1:0] mk_conn();
    logic [NM*NT-1:0] v; v = '1;
    if (CONN_SEL == 1) v[0*NT + NT - 1] = 1'b0;
    return v;
  endfunction
  function automatic logic [NM*NDOM-1:0] mk_dom();
    logic [NM*NDOM-1:0] v; v = '1;
    if (DOMALLOW_SEL == 1)
      for (int m = 0; m < NM; m++) begin
        v[m*NDOM +: NDOM] = '0;
        v[m*NDOM + (m % 4)]     = 1'b1;
        v[m*NDOM + 4 + (m % 4)] = 1'b1;
      end
    return v;
  endfunction
  localparam logic [NT*AW-1:0]     TBASE = mk_base();
  localparam logic [NT*AW-1:0]     TMASK = mk_mask();
  localparam logic [NM*NT-1:0]     CONNV = mk_conn();
  localparam logic [NM*NDOM-1:0]   DOMV  = mk_dom();
  function automatic logic [NM-1:0] mk_ooo(); logic [NM-1:0] v; v = '0; for (int m = 0; m < NM; m++) v[m] = OOO_MASK[m]; return v; endfunction
  function automatic logic [NM*4-1:0] mk_sl(input int s); logic [NM*4-1:0] v; v = '0; for (int m = 0; m < NM; m++) v[m*4 +: 4] = 4'(s); return v; endfunction
  function automatic logic [NT*4-1:0] mk_tsl(input int s); logic [NT*4-1:0] v; v = '0; for (int t = 0; t < NT; t++) v[t*4 +: 4] = 4'(s); return v; endfunction

  // ---------------------------------------------------------------- clock / reset / DUT
  logic clk = 0;
  always #5 clk = ~clk;
  logic rst_n = 0;
  int   cyc = 0;

  logic [NM-1:0]        m_req_valid, m_req_ready;
  logic [NM*2-1:0]      m_req_op;
  logic [NM*TAGW-1:0]   m_req_tag;
  logic [NM*DOMW-1:0]   m_req_dom;
  logic [NM-1:0]        m_req_priv;
  logic [NM*3-1:0]      m_req_tc;
  logic [NM*AW-1:0]     m_req_addr;
  logic [NM*DW-1:0]     m_req_wdata;
  logic [NM*DW/8-1:0]   m_req_wstrb;
  logic [NM-1:0]        m_rsp_valid, m_rsp_ready;
  logic [NM*TAGW-1:0]   m_rsp_tag;
  logic [NM*DOMW-1:0]   m_rsp_dom;
  logic [NM*2-1:0]      m_rsp_op;
  logic [NM*3-1:0]      m_rsp_status;
  logic [NM*DW-1:0]     m_rsp_rdata;
  logic [NT-1:0]        t_req_valid, t_req_ready;
  logic [NT*SRCW-1:0]   t_req_src;
  logic [NT*2-1:0]      t_req_op;
  logic [NT*TAGW-1:0]   t_req_tag;
  logic [NT*DOMW-1:0]   t_req_dom;
  logic [NT-1:0]        t_req_priv;
  logic [NT*3-1:0]      t_req_tc;
  logic [NT*AW-1:0]     t_req_addr;
  logic [NT*DW-1:0]     t_req_wdata;
  logic [NT*DW/8-1:0]   t_req_wstrb;
  logic [NT-1:0]        t_rsp_valid, t_rsp_ready;
  logic [NT*SRCW-1:0]   t_rsp_src;
  logic [NT*TAGW-1:0]   t_rsp_tag;
  logic [NT*DOMW-1:0]   t_rsp_dom;
  logic [NT*2-1:0]      t_rsp_op;
  logic [NT*3-1:0]      t_rsp_status;
  logic [NT*DW-1:0]     t_rsp_rdata;
  logic [NM-1:0]        grd_req_valid, grd_req_ready, grd_req_priv, grd_req_write, grd_rsp_valid, grd_rsp_ok;
  logic [NM*DOMW-1:0]   grd_req_dom;
  logic [NM*AW-1:0]     grd_req_addr;
  logic [NM*4-1:0]      grd_rsp_fault;
  logic                 cfg_valid = 0, cfg_write = 0, cfg_priv = 0, cfg_rvalid, cfg_err;
  logic [5:0]           cfg_addr = 0;
  logic [31:0]          cfg_wdata = 0, cfg_rdata;
  logic [NT-1:0]        o_cong;
  logic                 o_internal_err, o_locked;

  sf_meridian_qos #(
    .NM(NM), .NT(NT), .AW(AW), .DW(DW), .TAGW(TAGW), .DOMW(DOMW),
    .TGT_BASE(TBASE), .TGT_MASK(TMASK), .CONN(CONNV), .MAXO(MAXO), .MST_OOO(mk_ooo()), .MST_DOM_ALLOW(DOMV),
    .IQ_DEPTH(IQD), .XQ_DEPTH(XQD), .EQ_DEPTH(EQD), .TRQ_DEPTH(TRQD), .RQ_DEPTH(RQD), .GQ_DEPTH(GQD),
    .MST_SLICE(mk_sl(MSL)), .TGT_SLICE(mk_tsl(TSL)), .DEC_PIPE(DECP), .GUARD_EN(GUARD), .STRICT_EN(STRICT_EN),
    .DEF_POLICY(2'(DEF_POL))
  ) dut (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_op, .m_req_tag, .m_req_dom, .m_req_priv, .m_req_tc, .m_req_addr,
    .m_req_wdata, .m_req_wstrb, .m_rsp_valid, .m_rsp_ready, .m_rsp_tag, .m_rsp_dom, .m_rsp_op, .m_rsp_status,
    .m_rsp_rdata,
    .t_req_valid, .t_req_ready, .t_req_src, .t_req_op, .t_req_tag, .t_req_dom, .t_req_priv, .t_req_tc, .t_req_addr,
    .t_req_wdata, .t_req_wstrb, .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_tag, .t_rsp_dom, .t_rsp_op,
    .t_rsp_status, .t_rsp_rdata,
    .grd_req_valid, .grd_req_ready, .grd_req_dom, .grd_req_priv, .grd_req_write, .grd_req_addr,
    .grd_rsp_valid, .grd_rsp_ok, .grd_rsp_fault,
    .cfg_valid, .cfg_write, .cfg_addr, .cfg_wdata, .cfg_priv, .cfg_rvalid, .cfg_rdata, .cfg_err,
    .o_cong, .o_internal_err, .o_locked);

  // ---------------------------------------------------------------- external MemoryGuard reference model
  logic                   pol_we = 0, pol_valid = 0, pol_priv = 0, pol_rd = 0, pol_wr = 0;
  logic [2:0]             pol_idx = 0;
  logic [NM-1:0]          pol_src = '0;
  logic [NDOM-1:0]        pol_dom = '0;
  logic [AW-1:0]          pol_base = '0, pol_mask = '0;
  logic [NM-1:0]          gstall = '0;
  sf_meridian_guard_ref #(.NM(NM), .AW(AW), .DOMW(DOMW), .NENT(8), .LAT(GLAT)) u_guard (
    .clk, .rst_n,
    .pol_we, .pol_idx, .pol_valid, .pol_src, .pol_dom, .pol_priv, .pol_base, .pol_mask, .pol_rd, .pol_wr,
    .stall(gstall),
    .req_valid(grd_req_valid), .req_ready(grd_req_ready), .req_dom(grd_req_dom), .req_priv(grd_req_priv),
    .req_write(grd_req_write), .req_addr(grd_req_addr),
    .rsp_valid(grd_rsp_valid), .rsp_ok(grd_rsp_ok), .rsp_fault(grd_rsp_fault));
  // TB mirror of the guard policy table
  bit                     g_valid [8];
  bit [NM-1:0]            g_src   [8];
  bit [NDOM-1:0]          g_dom   [8];
  bit                     g_priv  [8];
  bit [AW-1:0]            g_base  [8];
  bit [AW-1:0]            g_mask  [8];
  bit                     g_rd    [8];
  bit                     g_wr    [8];

  // ---------------------------------------------------------------- job / record types
  typedef struct packed {
    logic [1:0]       op;
    logic [DOMW-1:0]  dom;
    logic             priv;
    logic [2:0]       tc;
    logic [AW-1:0]    addr;
    logic [DW-1:0]    wdata;
    logic [DW/8-1:0]  wstrb;
    logic [15:0]      gap;          // idle cycles before this request is presented
    logic             force_tag_en;
    logic [TAGW-1:0]  force_tag;
  } job_t;

  localparam int EXP_FWD = 0, EXP_ERR = 1, EXP_DROP = 2;

  typedef struct packed {
    int               m;
    logic [TAGW-1:0]  tag;
    job_t             j;
    int               kind;
    int               tgt;
    logic [2:0]       est;          // expected status for EXP_ERR
    int               cls;
    int               fwd;          // times seen at a target
    logic [2:0]       t_status;     // what the target answered
    logic [DW-1:0]    t_rdata;
    bit               corrupt;      // the target's answer was corrupted: master must see ST_PROTO
    int               issue_cyc;
    int               acc_cyc;
    int               t_acc_cyc;
    int               t_rsp_cyc;
    bit               accepted;
    bit               done;
  } rec_t;
  rec_t rec [int];                  // key = m * 65536 + tag
  function automatic int rkey(input int m, input int tag); return m * 65536 + tag; endfunction

  int   outst [NM];
  int   max_out [NM];
  int   p_issue [NM];               // percent chance to present when ready
  int   p_mrdy  [NM];
  int   gap_cnt [NM];
  bit   acc_q [NM];
  bit   cur_drop [NM];
  int   tag_mode = 1;               // 0 lowest free tag, 1 random free tag

  // target model state
  typedef struct packed {
    int               src;
    logic [TAGW-1:0]  tag;
    logic [DOMW-1:0]  dom;
    logic [1:0]       op;
    logic [AW-1:0]    addr;
    logic [DW-1:0]    wdata;
    logic [DW/8-1:0]  wstrb;
    int               ready_cyc;
    bit               fake;
    logic [2:0]       fstatus;
    int               fsrc;
  } tp_t;
  int   tacc_mode [NT];             // 0 random(p_tacc) 1 never 2 always
  int   p_tacc [NT];
  int   tlat_min [NT];
  int   tlat_max [NT];
  int   t_reorder [NT];             // 1: any ready response may be chosen
  int   p_tsend [NT];               // percent chance to present a ready response
  int   inj_kind [NT];              // 1 corrupt dom, 2 corrupt op, 3 illegal status of the next real response
  int   inj_dup  [NT];              // 1: follow the next real response by a duplicate (fake)
  logic [AW-1:0] err_mask [NT];     // SLVERR when (addr & mask) == pat (mask 0 = off)
  logic [AW-1:0] err_pat  [NT];
  bit   rsp_cur_v [NT];
  int   rsp_cur_key [NT];
  bit   rsp_took  [NT];
  bit   rsp_cur_fake [NT];
  logic [DW-1:0] mem [longint];


  // ---------------------------------------------------------------- flat FIFOs (associative array + head / tail)
  // Arrays of queues / of associative arrays indexed by a variable are mishandled by this simulator version (the
  // element aliases and pops do not persist once a loop over the masters is no longer unrolled), so none are used here.
  localparam longint KS = 1000000;
  job_t jmem [longint];   int jh [NM];  int jt [NM];            // job queue per master
  int   omem [longint];   int oh [NM];  int ot [NM];            // expected delivery order (tags) per master
  tp_t  tmem [longint];   int th [NT];  int tt [NT];            // target-side pending responses per target
  bit   tbz  [longint];                                         // tag busy, key m * 65536 + tag

  function automatic int jq_size(input int m); return jt[m] - jh[m]; endfunction
  function automatic job_t jq_front(input int m); return jmem[longint'(m) * KS + longint'(jh[m])]; endfunction
  task automatic jq_push(input int m, input job_t j); jmem[longint'(m) * KS + longint'(jt[m])] = j; jt[m]++; endtask
  task automatic jq_pop(input int m); jmem.delete(longint'(m) * KS + longint'(jh[m])); jh[m]++; endtask
  task automatic jq_clear(input int m); while (jh[m] < jt[m]) begin jmem.delete(longint'(m) * KS + longint'(jh[m])); jh[m]++; end jh[m] = 0; jt[m] = 0; endtask
  task automatic jq_force_tag(input int m, input int tag);
    longint k; job_t j;
    k = longint'(m) * KS + longint'(jt[m] - 1); j = jmem[k]; j.force_tag_en = 1'b1; j.force_tag = TAGW'(tag); jmem[k] = j;
  endtask

  function automatic int oq_size(input int m); return ot[m] - oh[m]; endfunction
  function automatic int oq_at(input int m, input int i); return omem[longint'(m) * KS + longint'(oh[m] + i)]; endfunction
  task automatic oq_push(input int m, input int tag); omem[longint'(m) * KS + longint'(ot[m])] = tag; ot[m]++; endtask
  task automatic oq_pop(input int m); omem.delete(longint'(m) * KS + longint'(oh[m])); oh[m]++; endtask
  task automatic oq_clear(input int m); while (oh[m] < ot[m]) begin omem.delete(longint'(m) * KS + longint'(oh[m])); oh[m]++; end oh[m] = 0; ot[m] = 0; endtask
  task automatic oq_remove(input int m, input int tag);
    int n; n = ot[m] - oh[m];
    for (int i = 0; i < n; i++)
      if (omem[longint'(m) * KS + longint'(oh[m] + i)] == tag) begin
        for (int k = i; k < n - 1; k++) omem[longint'(m) * KS + longint'(oh[m] + k)] = omem[longint'(m) * KS + longint'(oh[m] + k + 1)];
        omem.delete(longint'(m) * KS + longint'(ot[m] - 1)); ot[m]--;
        break;
      end
  endtask

  function automatic int tp_size(input int t); return tt[t] - th[t]; endfunction
  function automatic tp_t tp_at(input int t, input int i); return tmem[longint'(t) * KS + longint'(th[t] + i)]; endfunction
  function automatic int tp_ready(input int t, input int i); tp_t e; e = tmem[longint'(t) * KS + longint'(th[t] + i)]; return e.ready_cyc; endfunction
  task automatic tp_push(input int t, input tp_t e); tmem[longint'(t) * KS + longint'(tt[t])] = e; tt[t]++; endtask
  task automatic tp_delete(input int t, input int i);
    int n; n = tt[t] - th[t];
    for (int k = i; k < n - 1; k++) tmem[longint'(t) * KS + longint'(th[t] + k)] = tmem[longint'(t) * KS + longint'(th[t] + k + 1)];
    tmem.delete(longint'(t) * KS + longint'(tt[t] - 1)); tt[t]--;
  endtask
  task automatic tp_clear(input int t); while (th[t] < tt[t]) begin tmem.delete(longint'(t) * KS + longint'(th[t])); th[t]++; end th[t] = 0; tt[t] = 0; endtask

  function automatic bit tb_get(input int m, input int tag); longint k; k = longint'(m) * 65536 + longint'(tag); return tbz.exists(k) ? tbz[k] : 1'b0; endfunction
  task automatic tb_set(input int m, input int tag, input bit v); tbz[longint'(m) * 65536 + longint'(tag)] = v; endtask
  task automatic tb_clear(input int m); for (int k = 0; k < (1 << TAGW); k++) tbz.delete(longint'(m) * 65536 + longint'(k)); endtask
  function automatic int lat_at(input int c, input int i); return latv[longint'(c) * KS + longint'(i)]; endfunction

  // monitors
  int   errors = 0;
  int   checks = 0;
  int   n_issued = 0, n_completed = 0, n_dropped_exp = 0, n_fake_exp = 0;
  bit   verbose = 0;
  int   seed = 1;
  string test_name = "quick";

  // register mirror
  logic [15:0] tb_tcmap = TCMAP_DEFAULT;
  logic [1:0]  tb_floor [NM];

  // latency statistics (per class, accept -> delivery at the master port)
  longint lat_sum [4]; int lat_cnt [4]; int lat_max [4]; int latv [longint];
  int   comp_total = 0;
  int   tacc_cnt [NT][NM];                 // requests accepted by target t from master m (share measurement)
  int   tacc_cls [NT][4];                  // ... per class
  int   inflight_mc [NM][4];               // requests of (master, class) accepted by a target, response not yet taken by the DUT
  int   max_inflight_mc [NM][4];
  int   last_req_lat = -1, last_rsp_lat = -1;   // idle-latency probes
  int   max_iq_seen = 0;
  int   latfd = 0;                          // +LATDUMP=<file>: one line per completion: master class latency accept_cycle
  int   n_badop = 0, n_misal = 0, n_spoof = 0, n_corrupt = 0;      // expected protocol violations by cause
  int   n_st [NM][8];                                              // completions per master per status (observed)
  int   p_gstall = 0;                                              // percent of cycles the guard refuses queries
  bit   cong_seen = 0;
  int   stall_cyc [NM];                                            // cycles m_req_valid && !m_req_ready
  int   first_issue_cyc = -1, last_done_cyc = 0;

  task automatic fail(input string msg);
    errors++;
    if (errors <= 25) $display("FAIL[%0d] @%0d %s", errors, cyc, msg);
  endtask
  `define CHK(cond, msg) begin checks++; if (!(cond)) fail(msg); end

  // ---------------------------------------------------------------- reference model helpers
  function automatic logic [DW-1:0] dflt(input int t, input logic [AW-1:0] a);
    logic [63:0] x;
    begin
      x = {32'(t), a} * 64'h9E3779B97F4A7C15;
      dflt = DW'(x ^ (x >> 29));
    end
  endfunction
  function automatic longint mkey(input int t, input logic [AW-1:0] a); return (longint'(t) << 40) | longint'(a); endfunction

  function automatic bit pol_ok(input int m, input logic [DOMW-1:0] dom, input bit priv, input bit wr, input logic [AW-1:0] addr, output logic [3:0] fault);
    bit covd, who, pv, perm;
    covd = 0; who = 0; pv = 0; perm = 0;
    for (int e = 0; e < 8; e++) begin
      if (g_valid[e] && ((addr & g_mask[e]) == g_base[e])) begin
        covd = 1;
        if (g_src[e][m] && g_dom[e][int'(dom)]) begin
          who = 1;
          if (!g_priv[e] || priv) begin
            pv = 1;
            if (wr ? g_wr[e] : g_rd[e]) perm = 1;
          end
        end
      end
    end
    if (perm)        fault = 4'd0;
    else if (!covd) fault = F_NOMAP;
    else if (!who)   fault = F_DOMAIN;
    else if (!pv)    fault = F_PRIV;
    else             fault = F_PERM;
    return perm;
  endfunction

  function automatic int decode_t(input logic [AW-1:0] a);
    int r; r = -1;
    for (int t = NT - 1; t >= 0; t--)
      if ((a & TMASK[t*AW +: AW]) == TBASE[t*AW +: AW]) r = t;
    return r;
  endfunction

  function automatic int cls_of(input int m, input logic [2:0] tc);
    int c; c = int'(tb_tcmap[int'(tc)*2 +: 2]);
    if (c < int'(tb_floor[m])) c = int'(tb_floor[m]);
    return c;
  endfunction

  // expected outcome of a request presented by master m (first failure wins, same order as the RTL)
  task automatic expect_of(input int m, input job_t j, output int kind, output int tgt, output logic [2:0] st);
    logic [3:0] f; int t;
    kind = EXP_FWD; tgt = 0; st = ST_OKAY;
    if (j.op[1]) begin kind = EXP_ERR; st = ST_PROTO; return; end
    if (j.addr[OFF-1:0] != '0) begin kind = EXP_ERR; st = ST_PROTO; return; end
    if (!DOMV[m*NDOM + int'(j.dom)]) begin kind = EXP_ERR; st = ST_DENIED; return; end
    t = decode_t(j.addr);
    if (t < 0) begin kind = EXP_ERR; st = ST_DECERR; return; end
    if (!CONNV[m*NT + t]) begin kind = EXP_ERR; st = ST_DECERR; return; end
    tgt = t;
    if (GUARD != 0) begin
      if (!pol_ok(m, j.dom, j.priv, (j.op == OP_WRITE), j.addr, f)) begin kind = EXP_ERR; st = ST_DENIED; return; end
    end
  endtask

  // ---------------------------------------------------------------- job helpers
  function automatic logic [AW-1:0] taddr(input int t, input int word);
    return (AW'(t) << WINB) | (AW'(word) << OFF);
  endfunction

  task automatic push_job(input int m, input logic [1:0] op, input logic [AW-1:0] addr, input logic [2:0] tc,
                          input logic [DOMW-1:0] dom, input logic [DW-1:0] wdata, input logic [DW/8-1:0] wstrb,
                          input int gap = 0, input bit priv = 0);
    job_t j;
    j = '0;
    j.op = op; j.addr = addr; j.tc = tc; j.dom = dom; j.wdata = wdata; j.wstrb = wstrb; j.gap = 16'(gap); j.priv = priv;
    jq_push(m, j);
  endtask
  function automatic logic [DOMW-1:0] dom_of(input int m);      // a domain master m is allowed to present
    return (DOMALLOW_SEL == 1) ? DOMW'(m % 4) : DOMW'(0);
  endfunction
  task automatic push_rd(input int m, input logic [AW-1:0] addr, input logic [2:0] tc = 3'd2, input int dom = -1, input int gap = 0);
    push_job(m, OP_READ, addr, tc, (dom < 0) ? dom_of(m) : DOMW'(dom), {DW{1'b0}} | DW'(64'hA5A5_0000_0000_0000 + m), '1, gap);
  endtask
  task automatic push_wr(input int m, input logic [AW-1:0] addr, input logic [DW-1:0] data, input logic [2:0] tc = 3'd2, input int dom = -1, input int gap = 0, input logic [DW/8-1:0] strb = '1);
    push_job(m, OP_WRITE, addr, tc, (dom < 0) ? dom_of(m) : DOMW'(dom), data, strb, gap);
  endtask

  // ---------------------------------------------------------------- default model configuration
  task automatic cfg_defaults();
    for (int m = 0; m < NM; m++) begin
      jq_clear(m); oq_clear(m); tb_clear(m); outst[m] = 0; max_out[m] = MAXO + IQD; p_issue[m] = 100;
      p_mrdy[m] = 100; gap_cnt[m] = 0; acc_q[m] = 0; cur_drop[m] = 0; tb_floor[m] = 2'd0;
    end
    for (int t = 0; t < NT; t++) begin
      tp_clear(t); tacc_mode[t] = 2; p_tacc[t] = 100; tlat_min[t] = 1; tlat_max[t] = 1; t_reorder[t] = 0; p_tsend[t] = 100;
      inj_kind[t] = 0; inj_dup[t] = 0; err_mask[t] = '0; err_pat[t] = '0; rsp_cur_v[t] = 0; rsp_took[t] = 0; rsp_cur_fake[t] = 0;
    end
    rec.delete();
    mem.delete();
    for (int m = 0; m < NM; m++) begin stall_cyc[m] = 0; for (int k = 0; k < 8; k++) n_st[m][k] = 0; end
    n_badop = 0; n_misal = 0; n_spoof = 0; n_corrupt = 0; n_dropped_exp = 0; n_fake_exp = 0; cong_seen = 0; p_gstall = 0;
    for (int t = 0; t < NT; t++) begin for (int m = 0; m < NM; m++) tacc_cnt[t][m] = 0; for (int c = 0; c < 4; c++) tacc_cls[t][c] = 0; end
    for (int m = 0; m < NM; m++) for (int c = 0; c < 4; c++) begin inflight_mc[m][c] = 0; max_inflight_mc[m][c] = 0; end
    tag_mode = 1;
    tb_tcmap = TCMAP_DEFAULT;
    gstall = '0;
  endtask

  // ---------------------------------------------------------------- stimulus: everything changes at negedge
  logic [NM*TAGW-1:0] tag_next;
  always @(negedge clk) begin
    // ---- masters
    for (int m = 0; m < NM; m++) begin
      if (acc_q[m]) begin m_req_valid[m] = 1'b0; acc_q[m] = 0; end
      if (!m_req_valid[m] && rst_n) begin
        if (gap_cnt[m] > 0) gap_cnt[m]--;
        else if (jq_size(m) > 0 && outst[m] < max_out[m] && (int'($urandom_range(99, 0)) < p_issue[m])) begin
          job_t j; int tag; bit found; int kind, tgt; logic [2:0] st; rec_t r;
          j = jq_front(m);
          found = 0; tag = 0;
          if (j.force_tag_en) begin tag = int'(j.force_tag); found = 1; end
          else begin
            int start;
            start = (tag_mode == 1) ? int'($urandom_range((1 << TAGW) - 1, 0)) : 0;
            for (int k = 0; k < (1 << TAGW) && !found; k++) begin
              int c; c = (start + k) % (1 << TAGW);
              if (!tb_get(m, c)) begin tag = c; found = 1; end
            end
          end
          if (found) begin
            jq_pop(m);
            expect_of(m, j, kind, tgt, st);
            if (kind == EXP_ERR) begin
              if (j.op[1]) n_badop++;
              else if (j.addr[OFF-1:0] != '0) n_misal++;
              else if (!DOMV[m*NDOM + int'(j.dom)]) n_spoof++;
            end
            if (tb_get(m, tag)) begin kind = EXP_DROP; n_dropped_exp++; end
            cur_drop[m] = (kind == EXP_DROP);
            m_req_valid[m]                  = 1'b1;
            m_req_op[m*2 +: 2]              = j.op;
            m_req_tag[m*TAGW +: TAGW]       = TAGW'(tag);
            m_req_dom[m*DOMW +: DOMW]       = j.dom;
            m_req_priv[m]                   = j.priv;
            m_req_tc[m*3 +: 3]              = j.tc;
            m_req_addr[m*AW +: AW]          = j.addr;
            m_req_wdata[m*DW +: DW]         = j.wdata;
            m_req_wstrb[m*(DW/8) +: DW/8]   = j.wstrb;
            gap_cnt[m] = int'(j.gap);
            if (kind != EXP_DROP) begin
              r.m = m; r.tag = TAGW'(tag); r.j = j; r.kind = kind; r.tgt = tgt; r.est = st; r.cls = cls_of(m, j.tc);
              r.fwd = 0; r.t_status = '0; r.t_rdata = '0; r.corrupt = 0; r.issue_cyc = cyc; r.acc_cyc = -1;
              r.t_acc_cyc = -1; r.t_rsp_cyc = -1; r.accepted = 0; r.done = 0;
              rec[rkey(m, tag)] = r;
              tb_set(m, tag, 1'b1);
              outst[m]++;
              n_issued++;
              if (first_issue_cyc < 0) first_issue_cyc = cyc;
            end
          end
        end
      end
      m_rsp_ready[m] = (int'($urandom_range(99, 0)) < p_mrdy[m]);
    end

    // ---- guard back-pressure (verification hook of the reference guard)
    for (int m = 0; m < NM; m++) gstall[m] = (p_gstall > 0) && (int'($urandom_range(99, 0)) < p_gstall);
    // ---- targets
    for (int t = 0; t < NT; t++) begin
      case (tacc_mode[t])
        1:       t_req_ready[t] = 1'b0;
        2:       t_req_ready[t] = 1'b1;
        default: t_req_ready[t] = (int'($urandom_range(99, 0)) < p_tacc[t]);
      endcase
      if (rsp_took[t]) begin rsp_cur_v[t] = 0; t_rsp_valid[t] = 1'b0; rsp_took[t] = 0; end
      if (!rsp_cur_v[t] && rst_n) begin
        int sel; sel = -1;
        if (t_reorder[t] != 0) begin
          int nel; nel = 0;
          for (int i = 0; i < tp_size(t); i++) if (tp_ready(t, i) <= cyc) nel++;
          if (nel > 0) begin
            int pickn; pickn = $urandom_range(nel - 1, 0);
            for (int i = 0; i < tp_size(t); i++) if (tp_ready(t, i) <= cyc) begin
              if (pickn == 0 && sel < 0) sel = i;
              pickn--;
            end
          end
        end else begin
          if (tp_size(t) > 0 && tp_ready(t, 0) <= cyc) sel = 0;
        end
        if (sel >= 0 && (int'($urandom_range(99, 0)) < p_tsend[t])) begin
          tp_t e; logic [2:0] st; logic [DW-1:0] rd; rec_t r; int k;
          e = tp_at(t, sel);
          tp_delete(t, sel);
          st = ST_OKAY; rd = '0;
          if (e.fake) begin
            st = e.fstatus; rd = '0;
            t_rsp_src[t*SRCW +: SRCW] = SRCW'(e.fsrc);
            rsp_cur_fake[t] = 1;
            n_fake_exp++;
          end else begin
            longint kk; kk = mkey(t, e.addr);
            k = rkey(e.src, int'(e.tag));
            if (err_mask[t] != '0 && ((e.addr & err_mask[t]) == err_pat[t])) begin st = ST_SLVERR; rd = '0; end
            else if (e.op == OP_READ) begin rd = mem.exists(kk) ? mem[kk] : dflt(t, e.addr); end
            else begin
              logic [DW-1:0] old; old = mem.exists(kk) ? mem[kk] : dflt(t, e.addr);
              for (int b = 0; b < DW / 8; b++) if (e.wstrb[b]) old[b*8 +: 8] = e.wdata[b*8 +: 8];
              mem[kk] = old;
            end
            t_rsp_src[t*SRCW +: SRCW] = SRCW'(e.src);
            rsp_cur_fake[t] = 0;
            rsp_cur_key[t] = k;
            if (rec.exists(k)) begin
              r = rec[k]; r.t_status = st; r.t_rdata = rd;
              // corruption of the answer (the master must then see ST_PROTO with zero data)
              if (inj_kind[t] == 1) begin e.dom = e.dom ^ DOMW'(1); r.corrupt = 1; inj_kind[t] = 0; n_corrupt++; end
              else if (inj_kind[t] == 2) begin e.op = e.op ^ 2'd1; r.corrupt = 1; inj_kind[t] = 0; n_corrupt++; end
              else if (inj_kind[t] == 3) begin st = 3'd4; r.corrupt = 1; inj_kind[t] = 0; n_corrupt++; end
              rec[k] = r;
            end
            if (inj_dup[t] != 0) begin
              tp_t d; d = '0; d.fake = 1; d.fsrc = e.src; d.tag = e.tag; d.dom = e.dom; d.op = e.op; d.fstatus = st;
              d.ready_cyc = cyc + 6; tp_push(t, d); if (inj_dup[t] == 1) inj_dup[t] = 0;
            end
          end
          t_rsp_valid[t]                  = 1'b1;
          t_rsp_tag[t*TAGW +: TAGW]       = e.tag;
          t_rsp_dom[t*DOMW +: DOMW]       = e.dom;
          t_rsp_op[t*2 +: 2]              = e.op;
          t_rsp_status[t*3 +: 3]          = st;
          t_rsp_rdata[t*DW +: DW]         = rd;
          rsp_cur_v[t] = 1;
        end
      end
    end
  end

  // ---------------------------------------------------------------- monitors and scoreboard: everything at posedge
  logic [NT-1:0]      pv_tv, pv_tr;
  logic [NT*DW-1:0]   pv_twd;
  logic [NT*AW-1:0]   pv_tad;
  logic [NM-1:0]      pv_mv, pv_mr;
  logic [NM*DW-1:0]   pv_mrd;
  logic [NM*TAGW-1:0] pv_mtag;
  logic [NM-1:0]      pv_gv, pv_gr;
  logic [NM*AW-1:0]   pv_gad;
  bit                 mon_en = 1;

  always @(posedge clk) begin
    cyc <= cyc + 1;
    if (rst_n && mon_en) begin
      checks++;
      if (verbose) begin
        for (int m = 0; m < NM; m++) begin
          if (m_req_valid[m]) $display("@%0d m%0d req valid=%b ready=%b tag=%0d addr=%h", cyc, m, m_req_valid[m], m_req_ready[m], m_req_tag[m*TAGW +: TAGW], m_req_addr[m*AW +: AW]);
          if (grd_req_valid[m]) $display("@%0d m%0d grd_req ready=%b", cyc, m, grd_req_ready[m]);
          if (grd_rsp_valid[m]) $display("@%0d m%0d grd_rsp ok=%b fault=%0d", cyc, m, grd_rsp_ok[m], grd_rsp_fault[m*4 +: 4]);
          if (m_rsp_valid[m]) $display("@%0d m%0d rsp valid ready=%b tag=%0d st=%0d", cyc, m, m_rsp_ready[m], m_rsp_tag[m*TAGW +: TAGW], m_rsp_status[m*3 +: 3]);
        end
        for (int t = 0; t < NT; t++) begin
          if (t_req_valid[t]) $display("@%0d t%0d req ready=%b src=%0d tag=%0d addr=%h", cyc, t, t_req_ready[t], (NM > 1) ? t_req_src[t*SRCW +: SRCW] : 0, t_req_tag[t*TAGW +: TAGW], t_req_addr[t*AW +: AW]);
          if (t_rsp_valid[t]) $display("@%0d t%0d rsp ready=%b src=%0d tag=%0d st=%0d", cyc, t, t_rsp_ready[t], t_rsp_src[t*SRCW +: SRCW], t_rsp_tag[t*TAGW +: TAGW], t_rsp_status[t*3 +: 3]);
        end
      end
      if (o_internal_err) fail("o_internal_err: push into a full queue");
      if (|o_cong) cong_seen = 1;
      for (int m = 0; m < NM; m++) if (m_req_valid[m] && !m_req_ready[m]) stall_cyc[m]++;

      // ---- master request channel: acceptance
      for (int m = 0; m < NM; m++) begin
        if (m_req_valid[m] && m_req_ready[m]) begin
          int tg; tg = int'(m_req_tag[m*TAGW +: TAGW]);
          acc_q[m] = 1;
          if (!cur_drop[m]) begin
            if (rec.exists(rkey(m, tg))) begin
              rec_t r; r = rec[rkey(m, tg)]; r.acc_cyc = cyc; r.accepted = 1; rec[rkey(m, tg)] = r;
              oq_push(m, tg);
            end else fail($sformatf("accepted request of m%0d tag %0d has no record", m, tg));
          end
        end
      end

      // ---- target request channel
      for (int t = 0; t < NT; t++) begin
        if (pv_tv[t] && !pv_tr[t]) begin   // stability: valid held, fields stable
          `CHK(t_req_valid[t], $sformatf("t_req_valid[%0d] dropped before ready", t))
          `CHK(t_req_addr[t*AW +: AW] == pv_tad[t*AW +: AW] && t_req_wdata[t*DW +: DW] == pv_twd[t*DW +: DW],
               $sformatf("t_req[%0d] fields changed while stalled", t))
        end
        if (t_req_valid[t] && t_req_ready[t]) begin
          int s, tg, k; rec_t r; tp_t e; int lat;
          checks++;
          s  = (NM > 1) ? int'(t_req_src[t*SRCW +: SRCW]) : 0;
          tg = int'(t_req_tag[t*TAGW +: TAGW]);
          k  = rkey(s, tg);
          if (s >= NM) fail($sformatf("t%0d: illegal src %0d", t, s));
          else if (!rec.exists(k)) fail($sformatf("t%0d: request src %0d tag %0d never issued / already finished", t, s, tg));
          else begin
            r = rec[k];
            `CHK(r.kind == EXP_FWD, $sformatf("t%0d: request m%0d tag %0d reached a target but expected outcome is %0d (st %0d)", t, s, tg, r.kind, r.est))
            `CHK(r.tgt == t, $sformatf("t%0d: request m%0d tag %0d routed to wrong target (expected %0d)", t, s, tg, r.tgt))
            `CHK(r.fwd == 0, $sformatf("t%0d: DUPLICATE request m%0d tag %0d", t, s, tg))
            `CHK(t_req_op[t*2 +: 2] == r.j.op,       "identity: op")
            `CHK(t_req_dom[t*DOMW +: DOMW] == r.j.dom, "identity: dom (protection domain not preserved)")
            `CHK(t_req_priv[t] == r.j.priv,          "identity: priv")
            `CHK(t_req_tc[t*3 +: 3] == r.j.tc,       "identity: tc")
            `CHK(t_req_addr[t*AW +: AW] == r.j.addr, "identity: addr")
            `CHK(t_req_wdata[t*DW +: DW] == r.j.wdata, "identity: wdata")
            `CHK(t_req_wstrb[t*(DW/8) +: DW/8] == r.j.wstrb, "identity: wstrb")
            r.fwd++; r.t_acc_cyc = cyc;
            rec[k] = r;
            tacc_cnt[t][s]++; tacc_cls[t][r.cls]++;
            inflight_mc[s][r.cls]++;
            if (inflight_mc[s][r.cls] > max_inflight_mc[s][r.cls]) max_inflight_mc[s][r.cls] = inflight_mc[s][r.cls];
            e = '0; e.src = s; e.tag = TAGW'(tg); e.dom = t_req_dom[t*DOMW +: DOMW]; e.op = t_req_op[t*2 +: 2];
            e.addr = t_req_addr[t*AW +: AW]; e.wdata = t_req_wdata[t*DW +: DW]; e.wstrb = t_req_wstrb[t*(DW/8) +: DW/8];
            lat = tlat_min[t] + ((tlat_max[t] > tlat_min[t]) ? int'($urandom_range(tlat_max[t] - tlat_min[t], 0)) : 0);
            e.ready_cyc = cyc + 1 + lat;
            tp_push(t, e);
          end
        end
        pv_tv[t] = t_req_valid[t]; pv_tr[t] = t_req_ready[t];
        pv_tad[t*AW +: AW] = t_req_addr[t*AW +: AW]; pv_twd[t*DW +: DW] = t_req_wdata[t*DW +: DW];
        if (t_rsp_valid[t] && t_rsp_ready[t]) begin
          rsp_took[t] = 1;
          if (!rsp_cur_fake[t] && rec.exists(rsp_cur_key[t])) begin
            rec_t rr; rr = rec[rsp_cur_key[t]]; rr.t_rsp_cyc = cyc; rec[rsp_cur_key[t]] = rr;
            if (inflight_mc[rr.m][rr.cls] > 0) inflight_mc[rr.m][rr.cls]--;
          end
        end
      end

      // ---- master response channel
      for (int m = 0; m < NM; m++) begin
        if (pv_mv[m] && !pv_mr[m]) begin
          `CHK(m_rsp_valid[m], $sformatf("m_rsp_valid[%0d] dropped before ready", m))
          `CHK(m_rsp_tag[m*TAGW +: TAGW] == pv_mtag[m*TAGW +: TAGW] && m_rsp_rdata[m*DW +: DW] == pv_mrd[m*DW +: DW],
               $sformatf("m_rsp[%0d] fields changed while stalled", m))
        end
        if (m_rsp_valid[m] && m_rsp_ready[m]) begin
          int tg, k; rec_t r; logic [2:0] st;
          tg = int'(m_rsp_tag[m*TAGW +: TAGW]);
          k  = rkey(m, tg);
          checks++;
          if (!rec.exists(k)) fail($sformatf("m%0d: response for tag %0d with no outstanding request (lost-and-duplicated / foreign response)", m, tg));
          else begin
            r  = rec[k];
            st = m_rsp_status[m*3 +: 3];
            `CHK(!r.done, $sformatf("m%0d: DUPLICATE response for tag %0d", m, tg))
            `CHK(r.accepted, "response before acceptance")
            `CHK(m_rsp_dom[m*DOMW +: DOMW] == r.j.dom, "response echo: dom")
            `CHK(m_rsp_op[m*2 +: 2] == r.j.op || r.j.op[1], "response echo: op")
            if (r.kind == EXP_ERR) begin
              `CHK(st == r.est, $sformatf("m%0d tag %0d: error status %0d, expected %0d", m, tg, st, r.est))
              `CHK(m_rsp_rdata[m*DW +: DW] == '0, "error response carries data")
            end else begin
              `CHK(r.fwd == 1, $sformatf("m%0d tag %0d: response without the request having reached a target", m, tg))
              if (r.corrupt) begin
                `CHK(st == ST_PROTO && m_rsp_rdata[m*DW +: DW] == '0, "corrupted target answer must become ST_PROTO / zero data")
              end else begin
                `CHK(st == r.t_status, $sformatf("m%0d tag %0d: status %0d, target answered %0d", m, tg, st, r.t_status))
                if (st == ST_OKAY && r.j.op == OP_READ) `CHK(m_rsp_rdata[m*DW +: DW] == r.t_rdata, "read data differs from what the target returned")
                else `CHK(m_rsp_rdata[m*DW +: DW] == '0, "non-read / error response carries data")
              end
            end
            // ordering for in-order masters
            if (!OOO_MASK[m]) begin
              `CHK(oq_size(m) > 0 && oq_at(m, 0) == tg, $sformatf("m%0d: in-order delivery violated (tag %0d, expected %0d)", m, tg, (oq_size(m) > 0) ? oq_at(m, 0) : -1))
              if (oq_size(m) > 0 && oq_at(m, 0) == tg) oq_pop(m);
            end else begin
              oq_remove(m, tg);
            end
            // statistics
            begin
              int l; l = cyc - r.acc_cyc;
              last_req_lat = (r.t_acc_cyc >= 0) ? r.t_acc_cyc - r.acc_cyc : -1;
              last_rsp_lat = (r.t_rsp_cyc >= 0) ? cyc - r.t_rsp_cyc : -1;
              lat_sum[r.cls] += l; lat_cnt[r.cls]++; if (l > lat_max[r.cls]) lat_max[r.cls] = l;
              latv[longint'(r.cls) * KS + longint'(lat_cnt[r.cls] - 1)] = l;
              if (latfd != 0) $fwrite(latfd, "%0d %0d %0d %0d\n", m, r.cls, l, r.acc_cyc);
              comp_total++; last_done_cyc = cyc;
            end
            n_st[m][int'(st)]++;
            rec.delete(k);
            tb_set(m, tg, 1'b0);
            outst[m]--;
            n_completed++;
          end
        end
        pv_mv[m] = m_rsp_valid[m]; pv_mr[m] = m_rsp_ready[m]; pv_mtag[m*TAGW +: TAGW] = m_rsp_tag[m*TAGW +: TAGW];
        pv_mrd[m*DW +: DW] = m_rsp_rdata[m*DW +: DW];
        if (m_rsp_valid[m]) `CHK(!$isunknown({m_rsp_tag[m*TAGW +: TAGW], m_rsp_status[m*3 +: 3], m_rsp_dom[m*DOMW +: DOMW]}), "X on response")
      end

      // ---- guard request stability
      for (int m = 0; m < NM; m++) begin
        if (pv_gv[m] && !pv_gr[m]) begin
          `CHK(grd_req_valid[m], $sformatf("grd_req_valid[%0d] dropped before ready", m))
          `CHK(grd_req_addr[m*AW +: AW] == pv_gad[m*AW +: AW], $sformatf("grd_req[%0d] fields changed while stalled", m))
        end
        pv_gv[m] = grd_req_valid[m]; pv_gr[m] = grd_req_ready[m]; pv_gad[m*AW +: AW] = grd_req_addr[m*AW +: AW];
      end
    end else begin
      pv_tv = '0; pv_tr = '0; pv_mv = '0; pv_mr = '0; pv_gv = '0; pv_gr = '0;
    end
  end

  // ---------------------------------------------------------------- privileged register access (from the test thread)
  logic [31:0] last_rdata; bit last_err;
  task automatic reg_access(input bit wr, input int addr, input logic [31:0] wdata, input bit priv);
    @(negedge clk);
    cfg_valid = 1; cfg_write = wr; cfg_addr = 6'(addr); cfg_wdata = wdata; cfg_priv = priv;
    @(negedge clk);
    cfg_valid = 0; cfg_write = 0; cfg_wdata = 0; cfg_priv = 0;
    // the registered response was visible during the previous cycle: it is on the bus after the posedge
    last_rdata = cfg_rdata; last_err = cfg_err;
    `CHK(cfg_rvalid, "register response not valid one cycle after the access")
    @(negedge clk);
  endtask
  task automatic rd_reg(input int addr, input bit priv = 1);  reg_access(0, addr, 0, priv); endtask
  task automatic wr_reg(input int addr, input logic [31:0] d, input bit priv = 1); reg_access(1, addr, d, priv); endtask
  // read performance counter `idx`
  function automatic logic [31:0] dummy(); return 0; endfunction
  task automatic rd_cnt(input int idx, output logic [31:0] v);
    wr_reg(R_PERF_SEL, 32'(idx));
    rd_reg(R_PERF_DATA);
    v = last_rdata;
  endtask

  // ---------------------------------------------------------------- drain / idle
  function automatic bit all_idle();
    bit idle; idle = 1;
    for (int m = 0; m < NM; m++) begin
      if (jq_size(m) > 0 || outst[m] != 0 || m_req_valid[m]) idle = 0;
    end
    for (int t = 0; t < NT; t++) if (tp_size(t) > 0 || rsp_cur_v[t]) idle = 0;
    return idle;
  endfunction

  task automatic drain(input int timeout, input string what = "drain");
    int n; bit idle; n = 0; idle = all_idle();
    while (!idle && n < timeout) begin @(posedge clk); n++; idle = all_idle(); end
    if (!idle) begin
      fail($sformatf("%s: timeout after %0d cycles (outstanding m0=%0d, jq0=%0d)", what, timeout, outst[0], jq_size(0)));
    end
    repeat (8) @(posedge clk);
  endtask

  task automatic reset_dut(input int cycles = 4);
    rst_n = 0;
    repeat (cycles) @(posedge clk);
    // TB-side state vanishes with the DUT's
    for (int m = 0; m < NM; m++) begin
      m_req_valid[m] = 0; jq_clear(m); oq_clear(m); tb_clear(m); outst[m] = 0; acc_q[m] = 0; gap_cnt[m] = 0;
    end
    rec.delete();
    n_issued = n_completed;                         // in-flight transactions are void after a reset
    for (int e = 0; e < 8; e++) g_valid[e] = 0;     // the reference guard resets with the fabric: default deny
    @(negedge clk);
    rst_n = 1;
  endtask

  // @@TESTS_BEGIN@@

  // ================================================================= guard programming
  task automatic guard_prog(input int e, input bit valid, input logic [NM-1:0] srcm, input logic [NDOM-1:0] domm,
                            input bit priv, input logic [AW-1:0] base, input logic [AW-1:0] mask, input bit rd, input bit wr);
    @(negedge clk);
    pol_we = 1; pol_idx = 3'(e); pol_valid = valid; pol_src = srcm; pol_dom = domm; pol_priv = priv;
    pol_base = base; pol_mask = mask; pol_rd = rd; pol_wr = wr;
    g_valid[e] = valid; g_src[e] = srcm; g_dom[e] = domm; g_priv[e] = priv; g_base[e] = base; g_mask[e] = mask; g_rd[e] = rd; g_wr[e] = wr;
    @(negedge clk);
    pol_we = 0;
  endtask
  task automatic guard_allow_all();
    guard_prog(0, 1, '1, '1, 0, '0, '0, 1, 1);
    for (int e = 1; e < 8; e++) guard_prog(e, 0, '0, '0, 0, '0, '0, 0, 0);
  endtask

  // ================================================================= tests
  // basic: every master writes unique data to every target (private region), reads it back; memory checked directly
  task automatic t_basic();
    int nw; nw = 6;
    guard_allow_all();
    for (int m = 0; m < NM; m++) max_out[m] = 1;
    for (int m = 0; m < NM; m++)
      for (int t = 0; t < NT; t++)
        if (CONNV[m*NT + t])
          for (int i = 0; i < nw; i++) push_wr(m, taddr(t, 64 * m + i), {DW{1'b0}} | DW'({m[7:0], t[7:0], i[7:0], 8'hC3} * 64'h0101_0101_0101_0101), 3'd2, 3'(m % 4));
    drain(20000, "basic writes");
    for (int m = 0; m < NM; m++)
      for (int t = 0; t < NT; t++)
        if (CONNV[m*NT + t])
          for (int i = 0; i < nw; i++) push_rd(m, taddr(t, 64 * m + i), 3'd2, 3'(m % 4));
    drain(20000, "basic reads");
    // direct memory check: the data landed in exactly the right target's memory
    for (int m = 0; m < NM; m++)
      for (int t = 0; t < NT; t++)
        for (int i = 0; i < nw; i++) begin
          longint kk; kk = mkey(t, taddr(t, 64 * m + i));
          if (CONNV[m*NT + t]) begin
            `CHK(mem.exists(kk) && mem[kk] == (DW'({m[7:0], t[7:0], i[7:0], 8'hC3} * 64'h0101_0101_0101_0101)), $sformatf("basic: m%0d -> t%0d word %0d did not land correctly", m, t, i))
          end else begin
            `CHK(!mem.exists(kk), $sformatf("basic: unreachable route m%0d -> t%0d wrote memory", m, t))
          end
        end
    `CHK(n_issued == n_completed, "basic: issued != completed")
  endtask


  // ----------------------------------------------------------------- stimulus generators
  task automatic guard_mixed();
    guard_prog(0, 1, '1, NDOM'(8'h1F), 0, '0, '0, 1, 1);          // domains 0..4: read + write everywhere
    guard_prog(1, 1, '1, NDOM'(8'h20), 1, '0, '0, 1, 1);          // domain 5: read + write, PRIVILEGED accesses only
    guard_prog(2, 1, '1, NDOM'(8'h40), 0, '0, '0, 1, 0);          // domain 6: read only
    for (int e = 3; e < 8; e++) guard_prog(e, 0, '0, '0, 0, '0, '0, 0, 0);   // domain 7: no entry -> denied
  endtask

  task automatic gen_rand(input int m, input int n, input int err_pct, input int gapmax);
    for (int i = 0; i < n; i++) begin
      logic [1:0] op; int t; int w; logic [AW-1:0] a; logic [2:0] tc; logic [DOMW-1:0] dom; logic [DW-1:0] d; logic [DW/8-1:0] sb; int r;
      op = ($urandom_range(1, 0) == 1) ? OP_WRITE : OP_READ;
      t  = $urandom_range(NT - 1, 0);
      w  = $urandom_range(15, 0);
      a  = taddr(t, w);
      tc = 3'($urandom_range(7, 0));
      dom = (int'($urandom_range(99, 0)) < 85) ? DOMW'($urandom_range(5, 0)) : DOMW'($urandom_range(7, 6));
      d  = {DW/32{32'($urandom)}};
      sb = DW/8'($urandom);
      if (op == OP_WRITE && sb == '0) sb = '1;
      r = $urandom_range(99, 0);
      if (r < err_pct) begin
        case ($urandom_range(3, 0))
          0: op = 2'($urandom_range(3, 2));                         // reserved opcode
          1: a  = a | AW'(1);                                       // misaligned
          2: a  = taddr(NT + $urandom_range(3, 0), w);              // unmapped
          3: dom = DOMW'(7);                                        // no guard entry for domain 7
        endcase
      end
      push_job(m, op, a, tc, dom, d, sb, ($urandom_range(3, 0) == 0) ? $urandom_range(gapmax, 0) : 0, $urandom_range(1, 0) == 1);
    end
  endtask

  // ----------------------------------------------------------------- random stress family
  task automatic t_rand(input string kind);
    int n;
    n = 250;
    if (kind == "rand_clean") begin guard_allow_all(); end
    else guard_mixed();
    for (int t = 0; t < NT; t++) begin
      case (kind)
        "rand_bp", "rand_err", "rand_gstall", "rand_reorder": begin
          tacc_mode[t] = 0; p_tacc[t] = 40; tlat_min[t] = 1; tlat_max[t] = 7; p_tsend[t] = 60;
          t_reorder[t] = (kind == "rand_reorder" || kind == "rand_err") ? 1 : 0;
        end
        default: begin tacc_mode[t] = 2; tlat_min[t] = 1; tlat_max[t] = 3; end
      endcase
    end
    for (int m = 0; m < NM; m++) begin
      if (kind != "rand_clean") p_mrdy[m] = 50;
      p_issue[m] = (kind == "rand_clean") ? 100 : 70;
    end
    if (kind == "rand_gstall") p_gstall = 40;
    for (int m = 0; m < NM; m++) gen_rand(m, n, (kind == "rand_clean") ? 0 : 12, 6);
    drain(200000, kind);
    `CHK(n_issued == n_completed + 0, $sformatf("%s: issued %0d != completed %0d", kind, n_issued, n_completed))
  endtask

  // ----------------------------------------------------------------- shares at one target while every master has a backlog
  int sh_snap [NT][NM];
  int cl_snap [NT][4];
  task automatic snap_counts(input int t);
    for (int m = 0; m < NM; m++) sh_snap[t][m] = tacc_cnt[t][m];
    for (int c = 0; c < 4; c++)  cl_snap[t][c] = tacc_cls[t][c];
  endtask
  function automatic int total_acc(input int t);
    int s2; s2 = 0; for (int m = 0; m < NM; m++) s2 += tacc_cnt[t][m]; return s2;
  endfunction
  task automatic wait_total(input int t, input int n);
    int gd; int tot; gd = 0; tot = total_acc(t);
    while (tot < n && gd < 200000) begin @(posedge clk); gd++; tot = total_acc(t); end
    if (tot < n) fail($sformatf("wait_total: target %0d reached only %0d of %0d after %0d cycles (tacc_mode %0d, p %0d)", t, total_acc(t), n, gd, tacc_mode[t], p_tacc[t]));
  endtask

  function automatic int class_of_master(input int m);
    if (NM == 2) return (m == 0) ? 0 : 3;
    return m % 4;
  endfunction
  function automatic logic [2:0] tc_of_class(input int c);
    case (c) 0: return 3'd4; 1: return 3'd3; 2: return 3'd2; default: return 3'd0; endcase
  endfunction

  // saturate target 0 from every master (class = class_of_master) and measure shares per class over a window
  task automatic measure_shares(input int pol, input logic [31:0] weights, input int starve, input int win, output int shares [4]);
    guard_allow_all();
    wr_reg(R_CTRL, 32'(pol));
    wr_reg(R_WEIGHTS, weights);
    wr_reg(R_STARVE, 32'(starve));
    tacc_mode[0] = 0; p_tacc[0] = 25; tlat_min[0] = 1; tlat_max[0] = 1;
    for (int m = 0; m < NM; m++) begin
      for (int i = 0; i < 3 * win; i++) push_rd(m, taddr(0, i & 15), tc_of_class(class_of_master(m)));
    end
    wait_total(0, 60);                      // warm-up: every master's pipeline is full
    snap_counts(0);
    wait_total(0, 60 + win);
    for (int c = 0; c < 4; c++) shares[c] = tacc_cls[0][c] - cl_snap[0][c];
    // cancel the rest of the backlog so the test ends quickly
    for (int m = 0; m < NM; m++) jq_clear(m);
    tacc_mode[0] = 2;
    drain(100000, "shares drain");
  endtask

  task automatic t_classes();
    int sh [4]; int win; int tot; int wsum; int w [4]; int nmc [4]; int act;
    win = 400;
    for (int c = 0; c < 4; c++) nmc[c] = 0;
    for (int m = 0; m < NM; m++) nmc[class_of_master(m)]++;
    act = 0; for (int c = 0; c < 4; c++) if (nmc[c] > 0) act++;
    // ---- round robin: classes ignored, shares equal per master
    measure_shares(0, 32'h01020408, 0, win, sh);
    tot = sh[0] + sh[1] + sh[2] + sh[3];
    $display("RESULT classes policy=RR shares=%0d/%0d/%0d/%0d", sh[0], sh[1], sh[2], sh[3]);
    for (int c = 0; c < 4; c++) if (nmc[c] > 0)
      `CHK(sh[c] >= tot * nmc[c] / NM - 4 && sh[c] <= tot * nmc[c] / NM + 4, $sformatf("RR: class %0d share %0d of %0d is not %0d/%0d", c, sh[c], tot, nmc[c], NM))
    cfg_defaults(); jq_clear(0);
    // ---- WRR with weights 8:4:2:1: shares proportional to the weights of the ACTIVE classes, independent of the master count
    w[0] = 8; w[1] = 4; w[2] = 2; w[3] = 1;
    measure_shares(1, 32'h01020408, 0, win, sh);
    $display("RESULT classes policy=WRR(8,4,2,1) shares=%0d/%0d/%0d/%0d", sh[0], sh[1], sh[2], sh[3]);
    tot = sh[0] + sh[1] + sh[2] + sh[3];
    wsum = 0; for (int c = 0; c < 4; c++) if (nmc[c] > 0) wsum += w[c];
    for (int c = 0; c < 4; c++) if (nmc[c] > 0) begin
      int exp_s; exp_s = tot * w[c] / wsum;
      `CHK(sh[c] >= exp_s - tot / 20 - 2 && sh[c] <= exp_s + tot / 20 + 2, $sformatf("WRR: class %0d share %0d, expected about %0d of %0d", c, sh[c], exp_s, tot))
      `CHK(sh[c] > 0, $sformatf("WRR: class %0d received nothing", c))
    end
    cfg_defaults();
    // ---- WRR, weights all zero: behave as 1 -> equal shares per class, nobody switched off
    measure_shares(1, 32'h00000000, 0, win, sh);
    $display("RESULT classes policy=WRR(0,0,0,0) shares=%0d/%0d/%0d/%0d", sh[0], sh[1], sh[2], sh[3]);
    tot = sh[0] + sh[1] + sh[2] + sh[3];
    for (int c = 0; c < 4; c++) if (nmc[c] > 0)
      `CHK(sh[c] >= tot / act - 6 && sh[c] <= tot / act + 6, $sformatf("WRR zero weights: class %0d share %0d of %0d", c, sh[c], tot))
    cfg_defaults();
    if (STRICT_EN != 0) begin
      // ---- strict priority, no aging: the lowest class is starved while a higher class saturates (documented hazard)
      measure_shares(2, 32'h01020408, 0, win, sh);
      $display("RESULT classes policy=STRICT(aging off) shares=%0d/%0d/%0d/%0d", sh[0], sh[1], sh[2], sh[3]);
      `CHK(sh[class_of_master(NM - 1)] == 0, "STRICT without aging: lowest class should be starved by the saturating higher class")
      `CHK(sh[0] == win, "STRICT without aging: class 0 should take every grant")
      cfg_defaults();
      // ---- strict priority with aging S: the lowest class gets at least 1 grant per S+N transfers
      measure_shares(2, 32'h01020408, 8, win, sh);
      $display("RESULT classes policy=STRICT(aging 8) shares=%0d/%0d/%0d/%0d", sh[0], sh[1], sh[2], sh[3]);
      `CHK(sh[class_of_master(NM - 1)] >= win / (8 + NM) - 3, $sformatf("STRICT with aging 8: lowest class got %0d of %0d, below the floor", sh[class_of_master(NM - 1)], win))
      `CHK(sh[class_of_master(NM - 1)] > 0, "STRICT with aging: lowest class starved")
      cfg_defaults();
    end
  endtask

  // ----------------------------------------------------------------- contention: equal class, equal shares
  task automatic t_contention();
    int N; int lo, hi;
    N = 500;
    guard_allow_all();
    tacc_mode[0] = 0; p_tacc[0] = 60;
    for (int m = 0; m < NM; m++) for (int i = 0; i < N; i++) push_rd(m, taddr(0, i & 15), 3'd2);
    wait_total(0, 60);
    snap_counts(0);
    wait_total(0, 60 + 300);
    lo = 1 << 30; hi = 0;
    for (int m = 0; m < NM; m++) begin
      int d; d = tacc_cnt[0][m] - sh_snap[0][m];
      if (d < lo) lo = d;
      if (d > hi) hi = d;
    end
    $display("STAT contention per-master shares min=%0d max=%0d", lo, hi);
    `CHK(hi - lo <= 4, $sformatf("contention: unfair shares min %0d max %0d (equal class)", lo, hi))
    drain(200000, "contention");
  endtask

  // ----------------------------------------------------------------- admission control
  task automatic t_admission();
    logic [31:0] v;
    guard_allow_all();
    // (a) per-class outstanding limit: class 2 limited to 1 per master -> never more than 1 in flight at the target side
    tlat_min[0] = 12; tlat_max[0] = 12;
    wr_reg(R_OUTLIM, 32'hFF_01_FF_FF);     // class 2 limit = 1 (byte 2 = bits 23:16)
    for (int i = 0; i < 40; i++) push_rd(0, taddr(0, i & 15), 3'd2);          // tc2 -> class 2
    drain(100000, "admission limit");
    `CHK(max_inflight_mc[0][2] <= 1, $sformatf("OUTLIM: %0d class-2 requests in flight, limit 1", max_inflight_mc[0][2]))
    `CHK(n_issued == n_completed, "OUTLIM: transaction lost")
    cfg_defaults(); guard_allow_all();
    wr_reg(R_OUTLIM, 32'hFFFF_FFFF);
    tlat_min[0] = 12; tlat_max[0] = 12;
    for (int i = 0; i < 40; i++) push_rd(0, taddr(0, i & 15), 3'd2);
    drain(100000, "admission unlimited");
    `CHK(max_inflight_mc[0][2] >= 2 || MAXO < 2, $sformatf("without a limit class 2 should overlap (saw %0d)", max_inflight_mc[0][2]))
    cfg_defaults(); guard_allow_all();
    // (b) congestion throttle: class >= 2 is held while the target is congested; nothing is dropped
    if (MAXO >= 3) wr_reg(R_CONG, {14'd0, 2'd2, 8'd1, 8'd3});     // thr class 2, lo 1, hi 3
    else           wr_reg(R_CONG, {14'd0, 2'd2, 8'd0, 8'd1});     // tiny configuration: hi 1, lo 0
    wr_reg(R_CTRL, 32'h0000_0001 | (32'd1 << CTRL_CONG_EN));
    tacc_mode[0] = 0; p_tacc[0] = 20; tlat_min[0] = 1; tlat_max[0] = 1;
    for (int i = 0; i < 120; i++) push_rd(0, taddr(0, i & 15), 3'd0);          // class 3 flood
    if (NM > 1) for (int i = 0; i < 30; i++) push_rd(1, taddr(0, i & 15), 3'd4, dom_of(1), 3);   // class 0 trickle
    drain(300000, "admission throttle");
    `CHK(cong_seen, "congestion flag never rose under a flood")
    `CHK(n_issued == n_completed, "congestion throttle dropped a transaction")
    rd_cnt(pf_m(0, PFM_HELD_CONG), v);
    $display("STAT admission held_cong_cycles(m0)=%0d", v);
    `CHK(v > 0, "throttle never held a request although the target was congested")
    cfg_defaults();
  endtask

  // ----------------------------------------------------------------- concurrent errors, protocol violations, exact counters
  task automatic t_errors();
    logic [31:0] v; int e_dec, e_den, e_pro, e_slv;
    guard_mixed();
    for (int t = 0; t < NT; t++) begin
      tacc_mode[t] = 0; p_tacc[t] = 60; tlat_min[t] = 1; tlat_max[t] = 5; t_reorder[t] = 1;
      err_mask[t] = AW'(32'h0000_0040); err_pat[t] = AW'(32'h0000_0040);     // words with bit 6 of the address set -> SLVERR
    end
    for (int m = 0; m < NM; m++) begin p_mrdy[m] = 60; gen_rand(m, 200, 30, 4); end
    // corrupt a few real answers
    for (int k = 0; k < 6; k++) begin
      for (int t = 0; t < NT; t++) inj_kind[t] = 1 + (k % 3);
      repeat (40) @(posedge clk);
    end
    drain(300000, "errors");
    `CHK(n_issued == n_completed, "errors: issued != completed")
    // exact status counters per master
    for (int m = 0; m < NM; m++) begin
      rd_cnt(pf_m(m, PFM_DECERR), v);  `CHK(int'(v) == n_st[m][ST_DECERR], $sformatf("m%0d DECERR counter %0d vs %0d", m, v, n_st[m][ST_DECERR]))
      rd_cnt(pf_m(m, PFM_DENIED), v);  `CHK(int'(v) == n_st[m][ST_DENIED], $sformatf("m%0d DENIED counter %0d vs %0d", m, v, n_st[m][ST_DENIED]))
      rd_cnt(pf_m(m, PFM_PROTO), v);   `CHK(int'(v) == n_st[m][ST_PROTO],  $sformatf("m%0d PROTO counter %0d vs %0d", m, v, n_st[m][ST_PROTO]))
      rd_cnt(pf_m(m, PFM_SLVERR), v);  `CHK(int'(v) == n_st[m][ST_SLVERR], $sformatf("m%0d SLVERR counter %0d vs %0d", m, v, n_st[m][ST_SLVERR]))
      rd_cnt(pf_m(m, PFM_CPL), v);     `CHK(int'(v) == n_st[m][0] + n_st[m][1] + n_st[m][2] + n_st[m][3] + n_st[m][5], $sformatf("m%0d CPL counter %0d", m, v))
    end
    rd_cnt(PFG_VIOL, v);
    `CHK(int'(v) == n_badop + n_misal + n_spoof + n_dropped_exp + n_fake_exp + n_corrupt,
         $sformatf("violation counter %0d vs expected %0d (badop %0d misal %0d spoof %0d drop %0d fake %0d corrupt %0d)", v, n_badop + n_misal + n_spoof + n_dropped_exp + n_fake_exp + n_corrupt, n_badop, n_misal, n_spoof, n_dropped_exp, n_fake_exp, n_corrupt))
    $display("STAT errors decerr=%0d denied=%0d proto=%0d slverr=%0d viol(exp)=%0d", n_st[0][2], n_st[0][3], n_st[0][5], n_st[0][1], n_badop + n_misal + n_spoof + n_dropped_exp + n_fake_exp + n_corrupt);
    // ---- duplicate responses: consumed as orphans (one outstanding at a time so no tag is reissued meanwhile)
    cfg_defaults(); guard_allow_all();
    wr_reg(R_PERF_CTRL, 32'd1);
    for (int t = 0; t < NT; t++) begin inj_dup[t] = 2; tlat_min[t] = 1; tlat_max[t] = 1; end
    for (int i = 0; i < 12; i++) push_rd(0, taddr(i % NT, i), 3'd2, '0, 25);
    drain(100000, "dups");
    rd_cnt(PFG_VIOL, v);
    `CHK(int'(v) == n_fake_exp && n_fake_exp > 0, $sformatf("duplicate responses: counter %0d expected %0d", v, n_fake_exp))
    // ---- first-error log
    cfg_defaults(); guard_allow_all();
    wr_reg(R_ELOG_CTRL, 32'd1);
    push_job(0, OP_READ, taddr(1 % NT, 3) | AW'(1), 3'd2, 3'd1, '0, '1, 0);   // misaligned: PROTO / F_MISALIGN
    jq_force_tag(0, 5);
    drain(10000, "elog1");
    push_job(0, OP_READ, taddr(NT + 1, 0), 3'd2, 3'd2, '0, '1, 0);            // unmapped: not logged (log holds the first)
    drain(10000, "elog2");
    rd_reg(R_ELOG0);
    `CHK(last_rdata[31] && last_rdata[30:28] == ST_PROTO && last_rdata[27:24] == F_MISALIGN && last_rdata[23:16] == 8'd0 && last_rdata[15:8] == 8'd5 && last_rdata[7:0] == 8'd1,
         $sformatf("error log word 0 = %h", last_rdata))
    rd_reg(R_ELOG1);
    `CHK(last_rdata == (taddr(1 % NT, 3) | AW'(1)), $sformatf("error log address %h", last_rdata))
    wr_reg(R_ELOG_CTRL, 32'd1);
    rd_reg(R_ELOG0);
    `CHK(!last_rdata[31], "error log did not clear")
  endtask

  // ----------------------------------------------------------------- protocol violation: tag reuse behind a stalled target
  task automatic t_tagreuse();
    logic [31:0] v;
    guard_allow_all();
    tacc_mode[0] = 1;                                           // target 0 refuses everything: the first request stays live
    push_rd(0, taddr(0, 1), 3'd2);  jq_force_tag(0, 5);
    push_rd(0, taddr(0, 2), 3'd2);  jq_force_tag(0, 5);   // same tag, still live
    push_rd(0, taddr(NT > 1 ? 1 : 0, 3), 3'd2);
    repeat (60) @(posedge clk);
    tacc_mode[0] = 2;
    drain(20000, "tagreuse");
    `CHK(n_dropped_exp == 1, "tag reuse test did not produce exactly one reuse")
    `CHK(n_issued == n_completed, "tag reuse: issued != completed (the dropped request must get no response)")
    rd_cnt(PFG_VIOL, v);
    `CHK(int'(v) == 1, $sformatf("tag reuse: violation counter %0d", v))
  endtask

  // ----------------------------------------------------------------- saturation: back-pressure, isolation, no loss
  task automatic t_saturate();
    int done1; int m0_blocked;
    guard_allow_all();
    tacc_mode[0] = 1;                                            // target 0 takes nothing
    for (int i = 0; i < 60; i++) push_rd(0, taddr(0, i & 15), 3'd2);
    if (NM > 1 && NT > 1) for (int i = 0; i < 60; i++) push_rd(1, taddr(1, i & 15), 3'd2);
    repeat (300) @(posedge clk);
    if (NM > 1 && NT > 1) begin int w; w = 0; while ((outst[1] != 0 || jq_size(1) != 0) && w < 50000) begin @(posedge clk); w++; end end
    m0_blocked = stall_cyc[0];
    `CHK(m0_blocked > 0 || jq_size(0) > 0, "back-pressure never reached the master of the stalled target")
    `CHK(!o_internal_err, "internal error under saturation")
    if (NM > 1 && NT > 1) begin
      `CHK(outst[1] == 0 && jq_size(1) == 0, $sformatf("traffic to the independent target was blocked (outstanding %0d, queued %0d)", outst[1], jq_size(1)))
      done1 = n_completed;
      `CHK(done1 >= 60, "independent traffic did not complete while the other target was stalled")
    end
    `CHK(outst[0] > 0, "stalled target: nothing outstanding?")
    tacc_mode[0] = 2;
    drain(100000, "saturate release");
    `CHK(n_issued == n_completed, "saturate: issued != completed after release")
  endtask

  // ----------------------------------------------------------------- reset under load
  task automatic t_reset();
    logic [31:0] v;
    guard_allow_all();
    for (int t = 0; t < NT; t++) begin tacc_mode[t] = 0; p_tacc[t] = 50; tlat_min[t] = 15; tlat_max[t] = 30; end
    for (int m = 0; m < NM; m++) gen_rand(m, 60, 0, 2);
    repeat (35 + (seed % 17)) @(posedge clk);
    wr_reg(R_WEIGHTS, 32'h0707_0707);                           // a non-default register value that reset must remove
    reset_dut(5);
    // a target that is not in the reset domain keeps answering: those answers must be consumed, not delivered
    for (int i = 0; i < 400 && (rsp_cur_v[0] || tp_size(0) > 0 || (NT > 1 && (rsp_cur_v[1] || tp_size(1) > 0))); i++) @(posedge clk);
    repeat (10) @(posedge clk);
    `CHK(m_rsp_valid == '0 && t_req_valid == '0, "DUT presents transactions after reset")
    rd_reg(R_WEIGHTS);
    `CHK(last_rdata == 32'h01020408, $sformatf("register not restored by reset: %h", last_rdata))
    for (int t = 0; t < NT; t++) begin tp_clear(t); tacc_mode[t] = 2; tlat_min[t] = 1; tlat_max[t] = 2; end
    guard_allow_all();
    for (int m = 0; m < NM; m++) gen_rand(m, 80, 0, 2);
    drain(100000, "post-reset traffic");
    `CHK(n_issued == n_completed, "post-reset traffic incomplete")
    rd_cnt(PFG_CYCLES, v);
    `CHK(v > 0, "counters dead after reset")
  endtask

  // ----------------------------------------------------------------- idle latency per route (asserted against the documented formula)
  task automatic t_latency_idle();
    int exp_req, exp_rsp;
    guard_allow_all();
    exp_req = 3 + MSL + TSL + DECP + ((GUARD != 0) ? GLAT : 0);
    exp_rsp = 3 + MSL + TSL;
    for (int m = 0; m < NM; m++)
      for (int t = 0; t < NT; t++)
        if (CONNV[m*NT + t]) begin
          push_rd(m, taddr(t, 3), 3'd2);
          drain(2000, "latency_idle");
          $display("RESULT latency_idle m%0d->t%0d request=%0d (formula %0d) response=%0d (formula %0d)", m, t, last_req_lat, exp_req, last_rsp_lat, exp_rsp);
          `CHK(last_req_lat == exp_req, $sformatf("idle request latency m%0d->t%0d = %0d, formula %0d", m, t, last_req_lat, exp_req))
          `CHK(last_rsp_lat == exp_rsp, $sformatf("idle response latency m%0d->t%0d = %0d, formula %0d", m, t, last_rsp_lat, exp_rsp))
        end
  endtask

  // ----------------------------------------------------------------- performance counters: exact values in a deterministic scenario
  task automatic t_counters();
    logic [31:0] v; int n; int lsum;
    n = 20;
    guard_allow_all();
    wr_reg(R_PERF_CTRL, 32'd1);
    for (int m = 0; m < NM; m++) max_out[m] = 1;
    for (int i = 0; i < n; i++) begin push_wr(0, taddr(0, i), 64'hDEAD_0000 + i, 3'd2); push_rd(0, taddr(0, i), 3'd2); end
    drain(20000, "counters");
    rd_cnt(PFG_ACC, v);            `CHK(int'(v) == 2 * n, $sformatf("ACC %0d", v))
    rd_cnt(PFG_CPL, v);            `CHK(int'(v) == 2 * n, $sformatf("CPL %0d", v))
    rd_cnt(pf_m(0, PFM_ACC), v);   `CHK(int'(v) == 2 * n, $sformatf("m0 ACC %0d", v))
    rd_cnt(pf_m(0, PFM_LAT_CNT), v);`CHK(int'(v) == 2 * n, $sformatf("m0 LAT_CNT %0d", v))
    rd_cnt(PFG_BYTES_WR, v);       `CHK(int'(v) == n * DW / 8, $sformatf("BYTES_WR %0d", v))
    rd_cnt(PFG_BYTES_RD, v);       `CHK(int'(v) == n * DW / 8, $sformatf("BYTES_RD %0d", v))
    rd_cnt(pf_t(NM, 0, PFT_XFER), v);  `CHK(int'(v) == 2 * n, $sformatf("t0 XFER %0d", v))
    rd_cnt(pf_t(NM, 0, PFT_BUSY), v);  `CHK(int'(v) == 2 * n, $sformatf("t0 BUSY %0d", v))
    rd_cnt(pf_x(NM, NT, 0, 0), v);     `CHK(int'(v) == 2 * n, $sformatf("matrix m0->t0 %0d", v))
    rd_cnt(pf_c(NM, 2, PFC_FIRE), v);  `CHK(int'(v) == 2 * n, $sformatf("class2 FIRE %0d", v))
    rd_cnt(pf_c(NM, 2, PFC_CPL), v);   `CHK(int'(v) == 2 * n, $sformatf("class2 CPL %0d", v))
    rd_cnt(pf_c(NM, 2, PFC_GRANTS), v);`CHK(int'(v) == 2 * n, $sformatf("class2 GRANTS %0d", v))
    rd_cnt(pf_m(0, PFM_OUT_MAX), v);   `CHK(v == 1, $sformatf("m0 OUT_MAX %0d", v))
    // latency: the DUT counts accept -> slot delivered; the master sees the response one cycle (+ slice stages) later
    lsum = 0; for (int i = 0; i < lat_cnt[2]; i++) lsum += lat_at(2, i);
    rd_cnt(pf_m(0, PFM_LAT_SUM), v);
    if (MSL == 0) `CHK(int'(v) == lsum - 2 * n, $sformatf("m0 LAT_SUM %0d vs bench %0d - %0d", v, lsum, 2 * n))
    rd_cnt(PFG_CYCLES, v);             `CHK(v > 0, "CYCLES")
    // clear
    wr_reg(R_PERF_CTRL, 32'd1);
    rd_cnt(PFG_ACC, v);                `CHK(v == 0, "counters not cleared")
  endtask

  // ----------------------------------------------------------------- privileged register file
  task automatic t_regs();
    logic [31:0] v;
    rd_reg(R_ID, 0);       `CHK(!last_err && last_rdata == {ID_MAGIC, 8'(NM), 8'(NT)}, $sformatf("ID %h err %b", last_rdata, last_err))
    rd_reg(R_VERSION, 0);  `CHK(!last_err && last_rdata == VERSION, "VERSION")
    rd_reg(R_CTRL, 0);     `CHK(last_err && last_rdata == 0, "unprivileged read must fail and return 0")
    wr_reg(R_WEIGHTS, 32'h01020304, 0);  `CHK(last_err, "unprivileged write must fail")
    rd_reg(R_WEIGHTS, 1);  `CHK(!last_err && last_rdata == 32'h01020408, "unprivileged write changed a register")
    rd_reg(R_SECCNT, 1);   `CHK(last_rdata == 2, $sformatf("SECCNT %0d, expected 2", last_rdata))
    rd_reg(R_STATUS, 1);   `CHK(last_rdata[STAT_SEC], "STATUS.SEC not set")
    wr_reg(R_STATUS, 32'h1, 1);
    rd_reg(R_STATUS, 1);   `CHK(!last_rdata[STAT_SEC], "STATUS.SEC did not clear (W1C)")
    rd_reg(63, 1);         `CHK(last_err, "unknown register must fail")
    wr_reg(R_ID, 32'h0, 1);`CHK(last_err, "write to a read-only register must fail")
    // legal writes read back
    wr_reg(R_CTRL, 32'd2);
    if (STRICT_EN != 0) begin `CHK(!last_err, "policy 2 rejected"); rd_reg(R_CTRL); `CHK(last_rdata[1:0] == 2'd2, "policy readback") end
    else begin `CHK(last_err, "strict policy accepted although STRICT_EN = 0") end
    wr_reg(R_CTRL, 32'd3);            `CHK(last_err, "reserved policy 3 accepted")
    rd_reg(R_CTRL);                   `CHK(last_rdata[1:0] != 2'd3, "reserved policy took effect")
    wr_reg(R_WEIGHTS, 32'h00000000);  `CHK(!last_err, "zero weights rejected"); rd_reg(R_WEIGHTS); `CHK(last_rdata == 0, "weights readback")
    wr_reg(R_STARVE, 32'd9);          rd_reg(R_STARVE); `CHK(last_rdata == 9, "starve readback")
    wr_reg(R_TCMAP, 32'h1B1B);        rd_reg(R_TCMAP);  `CHK(last_rdata == 32'h1B1B, "tcmap readback")
    wr_reg(R_FLOOR, 32'h0000_0001);   rd_reg(R_FLOOR);  `CHK(last_rdata == 32'h1, "floor readback")
    wr_reg(R_OUTLIM, 32'h04030201);   rd_reg(R_OUTLIM); `CHK(last_rdata == 32'h04030201, "outlim readback")
    wr_reg(R_CONG, {14'd0, 2'd1, 8'd2, 8'd5});  `CHK(!last_err, "valid CONG rejected")
    wr_reg(R_CONG, {14'd0, 2'd1, 8'd9, 8'd5});  `CHK(last_err, "CONG with lo > hi accepted")
    wr_reg(R_PERF_SEL, 32'(NCNT));    `CHK(last_err, "PERF_SEL beyond the bank accepted")
    wr_reg(R_PERF_SEL, 32'(NCNT - 1));`CHK(!last_err, "PERF_SEL in range rejected")
    rd_reg(R_NCNT);                   `CHK(last_rdata == 32'(NCNT), "NCNT")
    // lock
    wr_reg(R_CTRL, 32'd1 | (32'd1 << CTRL_LOCK));  `CHK(!last_err, "lock write rejected")
    rd_reg(R_CTRL);                   `CHK(last_rdata[CTRL_LOCK] && o_locked, "lock not set")
    wr_reg(R_WEIGHTS, 32'h05050505);  `CHK(last_err, "write accepted while locked")
    rd_reg(R_WEIGHTS);                `CHK(last_rdata == 0, "locked register changed")
    wr_reg(R_CTRL, 32'd0);            `CHK(last_err, "unlock attempt accepted")
    wr_reg(R_PERF_SEL, 32'd3);        `CHK(!last_err, "PERF_SEL must stay writable when locked")
    wr_reg(R_STATUS, 32'hF);          `CHK(!last_err, "STATUS must stay writable when locked")
    reset_dut(3);
    rd_reg(R_CTRL);                   `CHK(!last_rdata[CTRL_LOCK] && !o_locked, "reset did not clear the lock")
    rd_reg(R_WEIGHTS);                `CHK(last_rdata == 32'h01020408, "reset did not restore the weights")
    rd_reg(R_TCMAP);                  `CHK(last_rdata == 32'(TCMAP_DEFAULT), "reset did not restore the tc map")
  endtask

  // ----------------------------------------------------------------- runtime policy switching under traffic
  task automatic t_policy_switch();
    guard_allow_all();
    for (int t = 0; t < NT; t++) begin tacc_mode[t] = 0; p_tacc[t] = 45; tlat_min[t] = 1; tlat_max[t] = 3; end
    for (int m = 0; m < NM; m++) gen_rand(m, 300, 0, 3);
    for (int k = 0; k < 18; k++) begin
      wr_reg(R_CTRL, 32'(k % 3));
      wr_reg(R_WEIGHTS, {8'($urandom_range(5, 0)), 8'($urandom_range(5, 0)), 8'($urandom_range(5, 0)), 8'($urandom_range(5, 0))});
      repeat (30) @(posedge clk);
    end
    drain(300000, "policy_switch");
    `CHK(n_issued == n_completed, "policy switch lost a transaction")
  endtask


  // ----------------------------------------------------------------- class floor: a master cannot claim a more urgent class than its floor
  task automatic t_floor();
    int win; int d0, d1; logic [31:0] v;
    win = 400;
    guard_allow_all();
    wr_reg(R_CTRL, 32'd1);                          // WRR, weights 8:4:2:1
    wr_reg(R_WEIGHTS, 32'h01020408);
    tacc_mode[0] = 0; p_tacc[0] = 25;
    for (int m = 0; m < 2; m++) for (int i = 0; i < 3 * win; i++) push_rd(m, taddr(0, i & 15), 3'd4);   // both ask for tc 4 = CLASS_0
    wait_total(0, 60);
    snap_counts(0);
    wait_total(0, 60 + win);
    d0 = tacc_cnt[0][0] - sh_snap[0][0]; d1 = tacc_cnt[0][1] - sh_snap[0][1];
    $display("RESULT floor no-floor shares m0=%0d m1=%0d", d0, d1);
    `CHK(d0 >= d1 - 6 && d1 >= d0 - 6, $sformatf("same class, no floor: shares %0d / %0d should be equal", d0, d1))
    // now demote master 1 to CLASS_3 through its floor (bits [3:2] of FLOOR)
    wr_reg(R_FLOOR, 32'h0000_000C);  tb_floor[1] = 2'd3;
    snap_counts(0);
    wait_total(0, total_acc(0) + win);
    d0 = tacc_cnt[0][0] - sh_snap[0][0]; d1 = tacc_cnt[0][1] - sh_snap[0][1];
    $display("RESULT floor m1 floor=CLASS_3 shares m0=%0d m1=%0d", d0, d1);
    `CHK(d0 > 6 * d1 && d1 > 0, $sformatf("floor: master 1 (CLASS_3) should get about 1/9 of the grants, got %0d vs %0d", d1, d0))
    for (int m = 0; m < NM; m++) jq_clear(m);
    tacc_mode[0] = 2;
    drain(100000, "floor drain");
    rd_cnt(PFG_DEMOTE, v);
    `CHK(v > 0, "floor: no demotion was counted")
    rd_cnt(pf_c(NM, 3, PFC_DEMOTE), v);
    `CHK(v > 0, "floor: no CLASS_3 demotion was counted")
    rd_cnt(pf_m(1, PFM_ACC), v);
    `CHK(v > 0, "floor: master 1 counter")
  endtask


  // ----------------------------------------------------------------- benchmark: trace-driven workloads
  //   +TRACE<m>=<file>      trace of master m (benchmarks/meridian_qos/gen_workloads.py), +MAXOUT<m>=<n> outstanding limit
  //   +TLATMIN<t> / +TLATMAX<t> / +TACC<t> target latency (cycles) and accept probability (%)
  //   +POLICY=<0|1|2> +WEIGHTS=<hex> +STARVE=<n> +CONGEN=<0|1>   scheduling configuration (register writes)
  //   +LATDUMP=<file>       raw per-completion latency records
  task automatic t_trace();
    string path, fmt; int fd; int gap, op, tc, n, nread, v, pol; logic [AW-1:0] ad; logic [DW-1:0] wd; logic [DW/8-1:0] ws;
    logic [31:0] w32, c32; int cyc0, cyc1, nacc;
    guard_allow_all();
    if ($value$plusargs("LATDUMP=%s", path)) latfd = $fopen(path, "w");
    if ($value$plusargs("POLICY=%d", pol))   wr_reg(R_CTRL, 32'(pol) | (($test$plusargs("CONGEN")) ? (32'd1 << CTRL_CONG_EN) : 32'd0));
    if ($value$plusargs("WEIGHTS=%h", w32))  wr_reg(R_WEIGHTS, w32);
    if ($value$plusargs("STARVE=%d", v))     wr_reg(R_STARVE, 32'(v));
    for (int t = 0; t < NT; t++) begin
      tacc_mode[t] = 0; p_tacc[t] = 100; tlat_min[t] = 1; tlat_max[t] = 1;
      fmt = $sformatf("TLATMIN%0d=%%d", t); if ($value$plusargs(fmt, v)) tlat_min[t] = v;
      fmt = $sformatf("TLATMAX%0d=%%d", t); if ($value$plusargs(fmt, v)) tlat_max[t] = v;
      fmt = $sformatf("TACC%0d=%%d", t);    if ($value$plusargs(fmt, v)) p_tacc[t] = v;
      if (p_tacc[t] >= 100) tacc_mode[t] = 2;
      t_reorder[t] = 0;
    end
    nread = 0;
    for (int m = 0; m < NM; m++) begin
      fmt = $sformatf("MAXOUT%0d=%%d", m); if ($value$plusargs(fmt, v)) max_out[m] = v;
      fmt = $sformatf("TRACE%0d=%%s", m);
      if ($value$plusargs(fmt, path)) begin
        fd = $fopen(path, "r");
        if (fd == 0) fail($sformatf("cannot open trace %s", path));
        else begin
          while (!$feof(fd)) begin
            n = $fscanf(fd, "%d %d %d %h %h %h\n", gap, op, tc, ad, wd, ws);
            if (n == 6) begin push_job(m, 2'(op), ad, 3'(tc), dom_of(m), wd, ws, gap); nread++; end
          end
          $fclose(fd);
        end
      end
    end
    cyc0 = cyc;
    drain(5000000, "trace");
    cyc1 = cyc;
    if (latfd != 0) $fclose(latfd);
    $display("RESULT trace requests=%0d completed=%0d first_issue=%0d last_done=%0d run_cycles=%0d", nread, n_completed, first_issue_cyc, last_done_cyc, last_done_cyc - first_issue_cyc);
    `CHK(n_issued == n_completed, "trace: issued != completed")
    // exact DUT counters
    rd_cnt(PFG_CYCLES, c32);  $display("RESULT ctr CYCLES=%0d", c32);
    rd_cnt(PFG_ACC, c32);     $display("RESULT ctr ACC=%0d", c32);
    rd_cnt(PFG_BYTES_WR, c32);$display("RESULT ctr BYTES_WR=%0d", c32);
    rd_cnt(PFG_BYTES_RD, c32);$display("RESULT ctr BYTES_RD=%0d", c32);
    rd_cnt(PFG_ARBSTALL, c32);$display("RESULT ctr ARBSTALL=%0d", c32);
    rd_cnt(PFG_CONTEND, c32); $display("RESULT ctr CONTEND_CYC=%0d", c32);
    rd_cnt(PFG_HELD_ADM, c32);$display("RESULT ctr HELD_ADM=%0d", c32);
    rd_cnt(PFG_HELD_CONG, c32);$display("RESULT ctr HELD_CONG=%0d", c32);
    for (int t = 0; t < NT; t++) begin
      rd_cnt(pf_t(NM, t, PFT_BUSY), c32);   $display("RESULT ctr t%0d.BUSY=%0d", t, c32);
      rd_cnt(pf_t(NM, t, PFT_XFER), c32);   $display("RESULT ctr t%0d.XFER=%0d", t, c32);
      rd_cnt(pf_t(NM, t, PFT_CONTEND), c32);$display("RESULT ctr t%0d.CONTEND=%0d", t, c32);
      rd_cnt(pf_t(NM, t, PFT_ARBSTALL), c32);$display("RESULT ctr t%0d.ARBSTALL=%0d", t, c32);
      rd_cnt(pf_t(NM, t, PFT_XQ_SUM), c32); $display("RESULT ctr t%0d.XQ_SUM=%0d", t, c32);
      rd_cnt(pf_t(NM, t, PFT_XQ_MAX), c32); $display("RESULT ctr t%0d.XQ_MAX=%0d", t, c32);
      rd_cnt(pf_t(NM, t, PFT_EQ_SUM), c32); $display("RESULT ctr t%0d.EQ_SUM=%0d", t, c32);
      rd_cnt(pf_t(NM, t, PFT_EQ_MAX), c32); $display("RESULT ctr t%0d.EQ_MAX=%0d", t, c32);
      rd_cnt(pf_t(NM, t, PFT_BP), c32);     $display("RESULT ctr t%0d.BP=%0d", t, c32);
      rd_cnt(pf_t(NM, t, PFT_BP_RUN), c32); $display("RESULT ctr t%0d.BP_RUN=%0d", t, c32);
    end
    for (int m = 0; m < NM; m++) begin
      rd_cnt(pf_m(m, PFM_ACC), c32);      $display("RESULT ctr m%0d.ACC=%0d", m, c32);
      rd_cnt(pf_m(m, PFM_STALL_IN), c32); $display("RESULT ctr m%0d.STALL_IN=%0d", m, c32);
      rd_cnt(pf_m(m, PFM_IQ_SUM), c32);   $display("RESULT ctr m%0d.IQ_SUM=%0d", m, c32);
      rd_cnt(pf_m(m, PFM_IQ_MAX), c32);   $display("RESULT ctr m%0d.IQ_MAX=%0d", m, c32);
      rd_cnt(pf_m(m, PFM_OUT_MAX), c32);  $display("RESULT ctr m%0d.OUT_MAX=%0d", m, c32);
      rd_cnt(pf_m(m, PFM_LAT_SUM), c32);  $display("RESULT ctr m%0d.LAT_SUM=%0d", m, c32);
      rd_cnt(pf_m(m, PFM_LAT_CNT), c32);  $display("RESULT ctr m%0d.LAT_CNT=%0d", m, c32);
      rd_cnt(pf_m(m, PFM_LAT_MAX), c32);  $display("RESULT ctr m%0d.LAT_MAX=%0d", m, c32);
    end
    for (int c = 0; c < 4; c++) begin
      rd_cnt(pf_c(NM, c, PFC_FIRE), c32);   $display("RESULT ctr c%0d.FIRE=%0d", c, c32);
      rd_cnt(pf_c(NM, c, PFC_GRANTS), c32); $display("RESULT ctr c%0d.GRANTS=%0d", c, c32);
      rd_cnt(pf_c(NM, c, PFC_ARBSTALL), c32);$display("RESULT ctr c%0d.ARBSTALL=%0d", c, c32);
      rd_cnt(pf_c(NM, c, PFC_LAT_SUM), c32);$display("RESULT ctr c%0d.LAT_SUM=%0d", c, c32);
      rd_cnt(pf_c(NM, c, PFC_LAT_CNT), c32);$display("RESULT ctr c%0d.LAT_CNT=%0d", c, c32);
      rd_cnt(pf_c(NM, c, PFC_LAT_MAX), c32);$display("RESULT ctr c%0d.LAT_MAX=%0d", c, c32);
    end
  endtask

  task automatic run_test(input string name);
    case (name)
      "basic":        t_basic();
      "rand_clean", "rand_bp", "rand_err", "rand_gstall", "rand_reorder": t_rand(name);
      "contention":   t_contention();
      "classes":      t_classes();
      "admission":    t_admission();
      "errors":       t_errors();
      "tagreuse":     t_tagreuse();
      "saturate":     t_saturate();
      "reset":        t_reset();
      "latency_idle": t_latency_idle();
      "counters":     t_counters();
      "regs":         t_regs();
      "policy_switch": t_policy_switch();
      "floor":        t_floor();
      "trace":        t_trace();
      default: begin fail($sformatf("unknown test %s", name)); end
    endcase
  endtask
  // @@TESTS_END@@

  // ---------------------------------------------------------------- main
  initial begin
    for (int c = 0; c < 4; c++) begin lat_sum[c] = 0; lat_cnt[c] = 0; lat_max[c] = 0; end
    m_req_valid = '0; m_req_op = '0; m_req_tag = '0; m_req_dom = '0; m_req_priv = '0; m_req_tc = '0; m_req_addr = '0;
    m_req_wdata = '0; m_req_wstrb = '0; m_rsp_ready = '0; t_req_ready = '0; t_rsp_valid = '0; t_rsp_src = '0;
    t_rsp_tag = '0; t_rsp_dom = '0; t_rsp_op = '0; t_rsp_status = '0; t_rsp_rdata = '0;
    pv_tv = '0; pv_tr = '0; pv_mv = '0; pv_mr = '0; pv_gv = '0; pv_gr = '0;
    for (int e = 0; e < 8; e++) begin g_valid[e] = 0; g_src[e] = '0; g_dom[e] = '0; g_priv[e] = 0; g_base[e] = '0; g_mask[e] = '0; g_rd[e] = 0; g_wr[e] = 0; end
    if (!$value$plusargs("TEST=%s", test_name)) test_name = "basic";
    if (!$value$plusargs("seed=%d", seed)) seed = 1;
    if ($test$plusargs("verbose")) verbose = 1;
    void'($urandom(seed));
    cfg_defaults();
    repeat (3) @(posedge clk);
    @(negedge clk); rst_n = 1;
    repeat (2) @(posedge clk);
    run_test(test_name);
    repeat (4) @(posedge clk);
    $display("STAT test=%s NM=%0d NT=%0d cycles=%0d issued=%0d completed=%0d checks=%0d", test_name, NM, NT, cyc, n_issued, n_completed, checks);
    if (errors == 0) $display("PASS %s", test_name);
    else             $display("FAIL %s errors=%0d", test_name, errors);
    $finish;
  end
  initial begin
    #500000000;
    $display("FAIL %s global timeout", test_name);
    $finish;
  end
endmodule

`default_nettype wire
