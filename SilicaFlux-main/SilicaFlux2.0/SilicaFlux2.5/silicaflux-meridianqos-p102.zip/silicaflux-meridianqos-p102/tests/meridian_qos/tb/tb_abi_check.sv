// =============================================================================
// MeridianQoS ABI check: the transaction contract of this project must be the contract of Project 83.
// Compiles the vendored, unmodified sf_meridian_pkg (Project 83, third_party/p83/) together with
// sf_meridian_qos_pkg and fails if any shared constant differs: opcodes, status codes, fault codes,
// violation-event indices 0..7 and the legacy traffic-class (`tc`) values.  Prints PASS / FAIL.
// =============================================================================
`timescale 1ns/1ps
module tb_abi_check;
  int errors = 0;
  int checked = 0;
  task automatic eq(input string name, input longint a, input longint b);
    checked++;
    if (a !== b) begin errors++; $display("FAIL ABI mismatch %s: P83=%0d MeridianQoS=%0d", name, a, b); end
  endtask
  initial begin
    eq("OPW", sf_meridian_pkg::OPW, sf_meridian_qos_pkg::OPW);
    eq("OP_READ", sf_meridian_pkg::OP_READ, sf_meridian_qos_pkg::OP_READ);
    eq("OP_WRITE", sf_meridian_pkg::OP_WRITE, sf_meridian_qos_pkg::OP_WRITE);
    eq("STW", sf_meridian_pkg::STW, sf_meridian_qos_pkg::STW);
    eq("ST_OKAY", sf_meridian_pkg::ST_OKAY, sf_meridian_qos_pkg::ST_OKAY);
    eq("ST_SLVERR", sf_meridian_pkg::ST_SLVERR, sf_meridian_qos_pkg::ST_SLVERR);
    eq("ST_DECERR", sf_meridian_pkg::ST_DECERR, sf_meridian_qos_pkg::ST_DECERR);
    eq("ST_DENIED", sf_meridian_pkg::ST_DENIED, sf_meridian_qos_pkg::ST_DENIED);
    eq("ST_TIMEOUT", sf_meridian_pkg::ST_TIMEOUT, sf_meridian_qos_pkg::ST_TIMEOUT);
    eq("ST_PROTO", sf_meridian_pkg::ST_PROTO, sf_meridian_qos_pkg::ST_PROTO);
    eq("FW", sf_meridian_pkg::FW, sf_meridian_qos_pkg::FW);
    eq("F_NONE", sf_meridian_pkg::F_NONE, sf_meridian_qos_pkg::F_NONE);
    eq("F_NOMAP", sf_meridian_pkg::F_NOMAP, sf_meridian_qos_pkg::F_NOMAP);
    eq("F_PERM", sf_meridian_pkg::F_PERM, sf_meridian_qos_pkg::F_PERM);
    eq("F_DOMAIN", sf_meridian_pkg::F_DOMAIN, sf_meridian_qos_pkg::F_DOMAIN);
    eq("F_PRIV", sf_meridian_pkg::F_PRIV, sf_meridian_qos_pkg::F_PRIV);
    eq("F_SPOOF", sf_meridian_pkg::F_SPOOF, sf_meridian_qos_pkg::F_SPOOF);
    eq("F_CITTMO", sf_meridian_pkg::F_CITTMO, sf_meridian_qos_pkg::F_CITTMO);
    eq("F_UNMAPPED", sf_meridian_pkg::F_UNMAPPED, sf_meridian_qos_pkg::F_UNMAPPED);
    eq("F_NOROUTE", sf_meridian_pkg::F_NOROUTE, sf_meridian_qos_pkg::F_NOROUTE);
    eq("F_MISALIGN", sf_meridian_pkg::F_MISALIGN, sf_meridian_qos_pkg::F_MISALIGN);
    eq("F_BADOP", sf_meridian_pkg::F_BADOP, sf_meridian_qos_pkg::F_BADOP);
    eq("F_ISO", sf_meridian_pkg::F_ISO, sf_meridian_qos_pkg::F_ISO);
    eq("F_HOL", sf_meridian_pkg::F_HOL, sf_meridian_qos_pkg::F_HOL);
    eq("F_RSPTMO", sf_meridian_pkg::F_RSPTMO, sf_meridian_qos_pkg::F_RSPTMO);
    eq("F_ECHO", sf_meridian_pkg::F_ECHO, sf_meridian_qos_pkg::F_ECHO);
    eq("V_BADOP", sf_meridian_pkg::V_BADOP, sf_meridian_qos_pkg::V_BADOP);
    eq("V_MISALIGN", sf_meridian_pkg::V_MISALIGN, sf_meridian_qos_pkg::V_MISALIGN);
    eq("V_TAGREUSE", sf_meridian_pkg::V_TAGREUSE, sf_meridian_qos_pkg::V_TAGREUSE);
    eq("V_ORPHAN", sf_meridian_pkg::V_ORPHAN, sf_meridian_qos_pkg::V_ORPHAN);
    eq("V_ECHO", sf_meridian_pkg::V_ECHO, sf_meridian_qos_pkg::V_ECHO);
    eq("V_BADSRC", sf_meridian_pkg::V_BADSRC, sf_meridian_qos_pkg::V_BADSRC);
    eq("V_SPOOF", sf_meridian_pkg::V_SPOOF, sf_meridian_qos_pkg::V_SPOOF);
    eq("V_LATE", sf_meridian_pkg::V_LATE, sf_meridian_qos_pkg::V_LATE);
    eq("TCW", sf_meridian_pkg::TCW, sf_meridian_qos_pkg::TCW);
    eq("TC_BACKGROUND", sf_meridian_pkg::TC_BACKGROUND, sf_meridian_qos_pkg::TC_BACKGROUND);
    eq("TC_BULK", sf_meridian_pkg::TC_BULK, sf_meridian_qos_pkg::TC_BULK);
    eq("TC_COMPUTE", sf_meridian_pkg::TC_COMPUTE, sf_meridian_qos_pkg::TC_COMPUTE);
    eq("TC_IO", sf_meridian_pkg::TC_IO, sf_meridian_qos_pkg::TC_IO);
    eq("TC_MGMT", sf_meridian_pkg::TC_MGMT, sf_meridian_qos_pkg::TC_MGMT);
    if (errors == 0) $display("PASS tb_abi_check: %0d shared ABI constants identical to Project 83", checked);
    else             $display("FAIL tb_abi_check: %0d mismatches", errors);
    $finish;
  end
endmodule
