// =============================================================================
// MeridianQoS unit bench: sf_meridian_arbiter
//
//   1. Independent behavioural model (integers, written from the policy text, not from the RTL structure):
//      grant / gvalid / gcls / urgent / reload compared EVERY cycle, all policies, random weights / starve limit /
//      request pattern / `en` pattern, several configuration epochs per run (each epoch starts with a reset).
//   2. Differential check against the verified Project 22 arbiter sfn_qos_arbiter, cycle by cycle:
//        POL_RR                              == sfn_qos_arbiter(STARVE = 0)
//        POL_STRICT, one requester per class == sfn_qos_arbiter(STARVE = S), qos = 3 - class
//   3. Property monitors (first principles, per requester):
//        A1 grant is one-hot or zero, only to a requester          A2 work conserving (req => gvalid)
//        A3 bounded wait: a requester that keeps requesting is served after at most BOUND transfers of others
//           RR: N-1 ; STRICT with S>0: S+N-1 ; WRR: (N-1)+(ceil(N/w_c)+1)*(W-w_c) ; STRICT with S=0: no bound
//           (the monitor then only records the worst wait, which is what "can starve" means)
//        A4 (WRR, all classes saturated, N = 4, one master per class): shares over whole rounds == weights
//   Requesters hold `req` and `cls` until granted (a crosspoint-queue head is stable until popped).
// Run:  +seed=<n> +epochs=<n> +cycles=<n>.  Prints "PASS" / "FAIL" and stats (greppable "STAT ...").
// =============================================================================
`default_nettype none
`timescale 1ns/1ps

module tb_arb #(
  parameter int N       = 4,
  parameter int ONECLS  = 0       // 1: requester i always has class i (needs N <= 4) -> strict diff vs P22 enabled
);
  import sf_meridian_qos_pkg::*;
  localparam int IW = clog2c(N);

  logic clk = 0;
  always #5 clk = ~clk;
  logic rst_n = 0;

  logic [N-1:0]   req;
  logic [N*2-1:0] cls;
  logic           en;
  logic [1:0]     pol;
  logic [31:0]    wts;
  logic [7:0]     starve;
  logic [N-1:0]   grant, urgent;
  logic [IW-1:0]  gidx;
  logic           gvalid, reload;
  logic [1:0]     gcls;

  sf_meridian_arbiter #(.N(N), .STRICT_EN(1), .AGEW(8), .WTW(8)) dut (
    .clk, .rst_n, .req, .cls, .en, .cfg_policy(pol), .cfg_weight(wts), .cfg_starve(starve),
    .grant, .gidx, .gvalid, .gcls, .urgent, .reload);

  // ---------------------------------------------------------------- oracle instances (Project 22)
  localparam int OS = 6;             // STARVE of the strict-diff oracle (cfg_starve is forced to OS in that mode)
  logic [N*3-1:0] oq;
  always_comb for (int i = 0; i < N; i++) oq[i*3 +: 3] = 3'(3 - int'(cls[i*2 +: 2]));
  logic [N-1:0]  og_rr, og_st, ou_rr, ou_st;
  logic [IW-1:0] oi_rr, oi_st;
  logic          ov_rr, ov_st;
  wire xfer = gvalid && en;
  sfn_qos_arbiter #(.N(N), .STARVE(0))  o_rr (.clk, .rst_n, .req, .qos(oq), .stall(1'b0), .accept(xfer),
      .grant(og_rr), .grant_idx(oi_rr), .grant_valid(ov_rr), .urgent(ou_rr));
  sfn_qos_arbiter #(.N(N), .STARVE(OS)) o_st (.clk, .rst_n, .req, .qos(oq), .stall(1'b0), .accept(xfer),
      .grant(og_st), .grant_idx(oi_st), .grant_valid(ov_st), .urgent(ou_st));

  // ---------------------------------------------------------------- behavioural model
  int  m_gptr, m_cptr [4], m_age [N], m_credit [4];
  int  m_w [4];
  // model outputs
  bit  mv; int mi; int mc; bit mreload; bit [N-1:0] murg;

  function automatic int pick_rr(input bit [N-1:0] elig, input int ptr);
    for (int d = 0; d < N; d++) begin
      int idx = (ptr + d) % N;
      if (elig[idx]) return idx;
    end
    return -1;
  endfunction

  task automatic model_eval();
    bit [N-1:0] elig; int ptr; bit rc [4]; bit av [4]; bit nz; bit anyreq;
    int cs; bit anyurg;
    for (int k = 0; k < 4; k++) m_w[k] = (wts[k*8 +: 8] == 0) ? 1 : int'(wts[k*8 +: 8]);
    for (int k = 0; k < 4; k++) rc[k] = 0;
    anyreq = 0;
    for (int i = 0; i < N; i++) if (req[i]) begin rc[int'(cls[i*2 +: 2])] = 1; anyreq = 1; end
    murg = '0; anyurg = 0;
    for (int i = 0; i < N; i++) begin
      murg[i] = (pol == POL_STRICT) && (starve != 0) && (m_age[i] >= int'(starve));
      if (req[i] && murg[i]) anyurg = 1;
    end
    mreload = 0;
    elig = req; ptr = m_gptr; cs = 0;
    if (pol == POL_STRICT) begin
      if (anyurg) begin
        for (int i = 0; i < N; i++) elig[i] = req[i] && murg[i];
      end else begin
        cs = -1;
        for (int k = 0; k < 4; k++) if (cs < 0 && rc[k]) cs = k;
        for (int i = 0; i < N; i++) elig[i] = req[i] && (int'(cls[i*2 +: 2]) == cs);
        ptr = m_cptr[(cs < 0) ? 0 : cs];
      end
    end else if (pol == POL_WRR) begin
      nz = 0;
      for (int k = 0; k < 4; k++) if (rc[k] && m_credit[k] != 0) nz = 1;
      mreload = anyreq && !nz;
      for (int k = 0; k < 4; k++) av[k] = rc[k] && (m_credit[k] != 0 || mreload);
      cs = -1;
      for (int k = 0; k < 4; k++) if (cs < 0 && av[k]) cs = k;
      for (int i = 0; i < N; i++) elig[i] = req[i] && (int'(cls[i*2 +: 2]) == cs);
      ptr = m_cptr[(cs < 0) ? 0 : cs];
    end
    mi = pick_rr(elig, ptr);
    mv = (mi >= 0);
    mc = mv ? int'(cls[mi*2 +: 2]) : 0;
  endtask

  task automatic model_update(input bit xf);
    if (xf) begin
      int wcls = mc; bit rl = mreload;
      for (int i = 0; i < N; i++) begin
        if (!req[i] || (i == mi)) m_age[i] = 0;
        else if (m_age[i] < 255)  m_age[i] = m_age[i] + 1;
      end
      m_gptr = (mi == N - 1) ? 0 : mi + 1;
      m_cptr[wcls] = (mi == N - 1) ? 0 : mi + 1;
      if (pol == POL_WRR) begin
        for (int k = 0; k < 4; k++) begin
          if (rl) m_credit[k] = m_w[k];
          if (k == wcls) m_credit[k] = m_credit[k] - 1;
        end
      end else begin
        for (int k = 0; k < 4; k++) m_credit[k] = m_w[k];
      end
    end else begin
      for (int i = 0; i < N; i++) if (!req[i]) m_age[i] = 0;
      if (pol != POL_WRR) for (int k = 0; k < 4; k++) m_credit[k] = m_w[k];
    end
  endtask

  task automatic model_reset();
    m_gptr = 0;
    for (int k = 0; k < 4; k++) begin m_cptr[k] = 0; m_credit[k] = 0; end
    for (int i = 0; i < N; i++) m_age[i] = 0;
  endtask

  // ---------------------------------------------------------------- bounded-wait monitor state
  int  wait_cnt [N];
  bit  was_req  [N];
  int  max_wait [3];                         // per policy 0 RR, 1 WRR, 2 STRICT
  int  bound_viol = 0, errors = 0, cmp_cnt = 0, diff_cnt = 0;
  int  share_cnt [4];

  function automatic int ceil_div(input int a, input int b); return (a + b - 1) / b; endfunction

  function automatic int bound_of(input int who);
    int wtot = 0; int c = int'(cls[who*2 +: 2]);
    if (pol == POL_RR || pol == 3) return N - 1;
    if (pol == POL_STRICT) return (starve == 0) ? -1 : int'(starve) + N - 1;
    for (int k = 0; k < 4; k++) wtot += m_w[k];
    return (N - 1) + (ceil_div(N, m_w[c]) + 1) * (wtot - m_w[c]);
  endfunction

  // ---------------------------------------------------------------- stimulus
  int seed, epochs, cycles;
  int p_req, p_en;                           // percent
  bit saturate;
  bit diff_rr_mode, diff_st_mode;

  task automatic fail(input string what);
    errors++;
    if (errors < 20) $display("FAIL %s @%0t pol=%0d starve=%0d wts=%h req=%b cls=%h en=%b", what, $time, pol, starve, wts, req, cls, en);
  endtask

  // driver state: requester holds req/cls until granted; the release is recorded at the posedge (rel_q) and
  // applied here at the negedge, so the DUT never sees an input change in the same time step as its clock edge
  bit [N-1:0] rel_q = '0;
  always @(negedge clk) begin
    req = req & ~rel_q;
    rel_q = '0;
    for (int i = 0; i < N; i++) begin
      if (!req[i]) begin
        if (saturate || (int'($urandom_range(99, 0)) < p_req)) begin
          req[i] = 1'b1;
          cls[i*2 +: 2] = ONECLS ? 2'(i) : 2'($urandom_range(3, 0));
        end
      end
    end
    en = saturate ? 1'b1 : (int'($urandom_range(99, 0)) < p_en);
  end

  // checks + model, sampled at the posedge (pre-update values)
  always @(posedge clk) if (rst_n) begin
    bit [N-1:0] g_exp;
    model_eval();
    cmp_cnt++;
    // ---- model comparison
    if (gvalid !== mv)                 fail("gvalid vs model");
    else if (mv) begin
      if (int'(gidx) !== mi)           fail("gidx vs model");
      if (int'(gcls) !== mc)           fail("gcls vs model");
      if (reload !== mreload)          fail("reload vs model");
    end
    if (urgent !== murg)               fail("urgent vs model");
    // ---- A1 / A2
    if (!(grant == '0 || $onehot(grant))) fail("A1 one-hot");
    if ((grant & ~req) != '0)             fail("A1 grant without req");
    if ((|req) && !gvalid)                fail("A2 work conserving");
    if (gvalid && grant != (N'(1) << gidx)) fail("grant vs gidx");
    // ---- oracle diff
    if (diff_rr_mode && pol == POL_RR) begin
      diff_cnt++;
      if (ov_rr !== gvalid || (gvalid && (oi_rr !== gidx))) fail("diff P22 RR");
    end
    if (diff_st_mode && pol == POL_STRICT && starve == 8'(OS)) begin
      diff_cnt++;
      if (ov_st !== gvalid || (gvalid && (oi_st !== gidx))) fail("diff P22 STRICT");
      if (ou_st !== urgent) fail("diff P22 urgent");
    end
    // ---- A3 bounded wait
    begin
      bit xf = gvalid && en;
      for (int i = 0; i < N; i++) begin
        if (!req[i]) begin wait_cnt[i] = 0; end
        else begin
          if (xf && gidx == IW'(i)) begin
            if (wait_cnt[i] > max_wait[(pol == 3) ? 0 : int'(pol)]) max_wait[(pol == 3) ? 0 : int'(pol)] = wait_cnt[i];
            begin
              int b = bound_of(i);
              if (b >= 0 && wait_cnt[i] > b) begin bound_viol++; fail($sformatf("A3 bound %0d exceeded: waited %0d (req %0d)", b, wait_cnt[i], i)); end
            end
            wait_cnt[i] = 0;
            share_cnt[gcls]++;
          end else if (xf) wait_cnt[i]++;
        end
      end
      model_update(xf);
      // requester releases req when granted (applied at the next negedge)
      if (xf) rel_q[gidx] = 1'b1;
    end
  end

  // ---------------------------------------------------------------- epochs
  initial begin
    if (!$value$plusargs("seed=%d", seed))     seed = 1;
    if (!$value$plusargs("epochs=%d", epochs)) epochs = 24;
    if (!$value$plusargs("cycles=%d", cycles)) cycles = 4000;
    void'($urandom(seed));
    req = '0; cls = '0; en = 0; pol = 0; wts = 32'h01010101; starve = 0;
    for (int k = 0; k < 3; k++) max_wait[k] = 0;
    for (int e = 0; e < epochs; e++) begin
      rst_n = 0; model_reset(); saturate = 0;
      for (int i = 0; i < N; i++) begin wait_cnt[i] = 0; end
      for (int k = 0; k < 4; k++) share_cnt[k] = 0;
      req = '0;
      repeat (3) @(negedge clk);
      // configuration of this epoch
      diff_rr_mode = 0; diff_st_mode = 0;
      pol    = 2'(e % 3);
      if (e % 8 == 7) pol = 2'd3;                       // reserved value behaves as RR
      starve = (pol == POL_STRICT) ? ((e % 6 == 2) ? 8'd0 : 8'($urandom_range(9, 1))) : 8'($urandom_range(5, 0));
      for (int k = 0; k < 4; k++) wts[k*8 +: 8] = 8'($urandom_range(6, 0));   // 0 allowed: behaves as 1
      p_req = (e % 4 == 0) ? 100 : 20 + 20 * (e % 4);
      p_en  = (e % 5 == 0) ? 100 : 30 + 15 * (e % 5);
      if (ONECLS && pol == POL_STRICT && (e % 6 != 2)) begin starve = 8'(OS); diff_st_mode = 1; end
      if (pol == POL_RR) diff_rr_mode = 1;
      saturate = (e % 4 == 0) && (e % 3 == 1) && (N == 4) && ONECLS;   // A4 epochs (WRR, saturated, one class each)
      rst_n = 1;
      repeat (cycles) @(negedge clk);
      if (saturate && pol == POL_WRR) begin
        // A4: shares over the run must match the weights to within one round
        int wtot = 0; int rounds;
        for (int k = 0; k < 4; k++) wtot += m_w[k];
        rounds = (share_cnt[0] + share_cnt[1] + share_cnt[2] + share_cnt[3]) / wtot;
        for (int k = 0; k < 4; k++)
          if (share_cnt[k] < rounds * m_w[k] - m_w[k] || share_cnt[k] > rounds * m_w[k] + m_w[k])
            fail($sformatf("A4 share class %0d: %0d grants, %0d rounds, weight %0d", k, share_cnt[k], rounds, m_w[k]));
        $display("STAT shares w=%0d/%0d/%0d/%0d grants=%0d/%0d/%0d/%0d", m_w[0], m_w[1], m_w[2], m_w[3],
                 share_cnt[0], share_cnt[1], share_cnt[2], share_cnt[3]);
      end
    end
    $display("STAT N=%0d ONECLS=%0d cycles_compared=%0d diff_compared=%0d max_wait_rr=%0d max_wait_wrr=%0d max_wait_strict=%0d",
             N, ONECLS, cmp_cnt, diff_cnt, max_wait[0], max_wait[1], max_wait[2]);
    if (errors == 0) $display("PASS tb_arb N=%0d ONECLS=%0d", N, ONECLS);
    else             $display("FAIL tb_arb N=%0d ONECLS=%0d errors=%0d", N, ONECLS, errors);
    $finish;
  end
endmodule

`default_nettype wire
