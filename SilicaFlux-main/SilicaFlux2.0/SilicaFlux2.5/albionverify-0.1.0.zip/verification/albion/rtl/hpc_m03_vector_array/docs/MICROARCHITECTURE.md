# `hpc_vector_array` — microarchitecture

## 1. Block diagram

```
 cmd ──► [ command queue  CMD_DEPTH ] ──► ISSUE CONTROLLER ──────────────┐   per-beat entry:
                                            │  current command:          │   active mask, last,
 opnd ─────────────────────────────────────►│  op rm vm bcast scalar     │   vl=0 token, illegal,
 lane_hold ──► hold_q ─────────────────────►│  rem (elements left)       │   red, rm, tid, scalar
                                            │  acc_q (lanes that took    ▼
                                            │  their element)   [ beat-tracking queue TRK_DEPTH ]
                    ┌───────────┬───────────┼───────────┐                │
                    ▼           ▼           ▼           ▼                │
                 lane 0      lane 1  ...  lane N-1   (hpc_vector_lane,   │
                 ROB 8       ROB 8        ROB 8       Module 02,         │
                    │           │           │         unmodified)        │
                    └───────────┴─────┬─────┴───────────┘                │
                                      ▼                                  ▼
                               COLLECTOR (head beat: wait for every active lane, take all)
                                 │                                   │
                                 ▼ elementwise                       ▼ reductions + completion tokens
                     [ result register ] ──► res          REDUCTION / TOKEN STAGE (in order)
                                 │                        tree of N-1 hpc_fp32_add + accumulator
                                 │ last-beat seq        (input register, tree, accumulator)
                                 └──────────────► gate ◄── [ completion queue CPL_DEPTH ] ──► cpl
```

Every queue is the same small register FIFO (`hpc_varray_fifo`). Every arithmetic operation is
done by Module 02 code: the lanes, and the `hpc_fp32_add` instances in the reduction unit.

## 2. Pipeline of one elementwise beat (no stalls)

| Cycle | Event |
|---|---|
| t | Operand beat handshake. All live lanes accept their element in the same cycle (lane ACC stage). The tracking-queue entry is pushed. |
| t + LAT_unit + 1 | Every active lane presents its result (`out_valid`, Module 02 contract). The collector takes them all and pops the tracking entry. |
| t + LAT_unit + 2 | Result beat presented on `res_*`. |

FMADD with default latencies: beat accepted at *t*, result beat at *t* + 6. Measured values are in
`docs/PERFORMANCE.md` §1.

## 3. Vector issue controller (`hpc_varray_issue.sv`)

**Command sequencing**

* Commands wait in the command queue. When no command is being issued, or the current one issues
  its last beat in this cycle, the head command is loaded into the current-command registers
  **in the same cycle**, so back-to-back commands lose no cycle.
* Legality is decoded at load (`hpc_varray_pkg::cmd_legal`).
* `rem` = elements not yet covered by a beat. A vl = 0 command spends one cycle pushing a
  beat-less token entry.

**Distributing work and applying masks** (every beat):

* `tail_act[l] = (rem > l)`, computed from registered state.
* `lane_need[l] = tail_act[l] & ~acc_q[l] & legal`: the lane still has to take its element.
* Lane *l* is offered its element (`in_valid`) when the beat is valid, the tracking queue is not
  full, `lane_need[l]` is set and the lane is not held. Operands are routed per lane, or the
  broadcast scalar is substituted.
* Masked positions (`vm` = 1, mask bit 0) are offered with `lane_en_i` = 0. The lane consumes them
  without decoding, executing, taking a slot or producing a result. Tail positions are not
  offered at all.

**Not assuming that lanes are ready (partial issue)**

* Each lane takes its element independently whenever it is ready (`in_ready`, i.e. its
  completion buffer has a free slot) and not held.
* `acc_q[l]` remembers lanes that already took their element of the current beat. Those lanes
  are not offered it again.
* The operand beat is released (`opnd_ready_o`) in the cycle in which the **last** live lane
  takes its element, and `acc_q` clears.
* `opnd_ready_o = beat phase & ~trk_full & AND_l(~lane_need[l] | (lane in_ready[l] & ~hold_q[l]))`
  is a function of registered state only.
* Why partial issue: an all-or-nothing issue rule waits for a cycle in which every live lane is
  ready at once. If lanes become ready out of phase (the testbench's `phase` hold pattern), that
  cycle may never come, and an all-or-nothing issuer starves. Partial issue makes progress
  whenever any lane can.

**Tracking accepted work**

* One tracking-queue entry is pushed per beat, carrying:
  * the active mask (`tail & (~vm | mask) & legal`);
  * the last-beat flag, the illegal and reduction flags, rm, tid and the scalar (the reduction's
    initial value).
* Beats with no active element (fully masked, or illegal command) also get an entry, so that the
  result stream keeps one beat per operand beat.
* The entry is pushed when the beat is released. A lane can only present a result after the
  lane latency (≥ 2 cycles), so the entry always exists before any result can be collected.

**Backpressure**

* `opnd_ready_o` is low while any live lane cannot take its element or the tracking queue is
  full.
* `TRK_DEPTH` bounds the number of beats in flight.
* The lanes' own credit rule (`in_ready`) bounds the work per lane. Execution pipelines never
  stall (Module 02).

**Preserving order**

* Commands start strictly in acceptance order and beats in element order.
* Each lane is in-order (Module 02 ROB).
* The tracking queue is FIFO.

## 4. Collector (`hpc_varray_collect.sv`)

* The head tracking entry names the head beat's active lanes. The collector fires when:
  * every active lane presents a result (`out_valid`);
  * the output register is free or being emptied (elementwise);
  * the reduction/token stage can take an item (reductions, and the last beat of an elementwise
    command, which carries the completion token).
* On firing:
  * `out_ready` goes to exactly the active lanes;
  * the tracking entry is popped;
  * the beat (masked to the active positions) is loaded into the result register or sent as a
    GROUP item;
  * command flags (OR) and the active-element count accumulate.
* **Lossless when one lane stalls.** A lane result leaves its lane only through the `out_ready`
  handshake. Until then it stays in the lane's completion buffer with stable payload (Module 02
  contract). A late lane delays the beat, while the early lanes' results wait in their own
  buffers. Nothing is dropped or overwritten, and there is no extra array-level buffer that could
  overflow.
* **Association.** Lane *l*'s *i*-th result belongs to the *i*-th beat in which *l* was active.
  This holds because:
  * lanes are in-order;
  * inactive positions never produce a lane result;
  * the collector consumes lane *l* only for beats in which *l* is active, in beat order.

  Every element issued carries the beat sequence number as its lane tag. A simulation assertion
  checks the tag of every collected result against the head beat. The testbench additionally
  checks every value against the reference.

## 5. Completion path and ordering

* All completion information passes, in command order, through the reduction/token stage
  (`hpc_varray_reduce.sv`):
  * elementwise commands contribute one TOKEN item, pushed with their last beat (or alone for
    vl = 0);
  * reductions contribute GROUP items. The last one produces the token after the final
    accumulator add.
* The stage is a fixed-latency pipeline that never stalls internally. Two admission rules make
  this safe:
  * **credit**: an item that will produce a completion is admitted only if a completion-queue
    slot is reserved for it (`CPL_DEPTH` credits);
  * **accumulator spacing**: after a GROUP with an active element, the next item is admitted
    `RED_LAT` cycles later. The accumulator has one add in flight, and no item can overtake it.

  Tokens therefore leave in item order, which is command order.
* **"Completion after data"**:
  * every elementwise token carries the sequence number of its command's last result beat (a
    3-bit counter for `CPL_DEPTH = 4`, wide enough that no two tokens in flight share a value);
  * the result register stores the sequence number of the last beat it holds;
  * the head completion record is held back exactly while its own last beat sits in the result
    register.

  Once presented, a record cannot be blocked again, because its last beat never re-enters the
  register. `cpl_valid_o` therefore stays stable until the handshake.

**Token bypass.** An elementwise TOKEN admitted while **no** item is in flight anywhere in the
stage (input register, tree or accumulator) cannot overtake anything, so it skips the tree and is
emitted in the next cycle. Tokens admitted behind a reduction still traverse the pipeline in
order.

Why the bypass is needed: without it, every elementwise completion held one of the `CPL_DEPTH`
credits for the tree latency. Back-to-back single-beat commands were then limited to
(TL + 3) / `CPL_DEPTH` cycles per command, which measured 3.75 cycles at N = 16. With the bypass
they run at the ideal 1 cycle per command for every N, and elementwise completion latency is
result latency + 1, independent of N (`docs/PERFORMANCE.md`).

## 6. Throughput

* **Elementwise.** One beat per cycle sustained, i.e. N elements per cycle, provided that:
  * the lanes sustain one operation per cycle: `LANE_ROB_DEPTH ≥ LAT + 2`, Module 02;
  * the tracking queue covers the beat's residence time. An entry lives from the push (cycle t)
    to the collect (t + LAT + 1) and is reusable one cycle later, so `TRK_DEPTH ≥ LAT_max + 2`.
    The default 8 covers the default FMA latency of 4 with margin;
  * the result consumer accepts one beat per cycle. The result register refills in the cycle it
    is emptied (`res_ready_i` feeds the collector combinationally).

  Measured in `docs/PERFORMANCE.md` §2–3.
* **Command overhead.** None for back-to-back commands. A vl = 0 command costs one issue cycle.
* **Reduction.** One beat per `RED_LAT` cycles (N / `RED_LAT` elements per cycle). See
  `docs/REDUCTION.md` §4.

## 7. Reset

* All control state resets asynchronously to constants: queue pointers and counts, current-command
  valid and remaining count, `acc_q`, `hold_q`, collector state, result valid, reduction valid
  pipes, credits, spacing counter and token valid.
* Datapath registers (queue storage, operands, results, accumulator) are not reset. They are
  never observable, because every output payload is gated by its valid bit.
* The lanes reset as specified in Module 02.

## 8. Design decisions and alternatives rejected

| Decision | Alternative rejected | Why |
|---|---|---|
| Reuse the Module 02 lane unmodified; a new controller around it | A new wide SIMD datapath | The lane is verified (132 runs, 28/28 mutants, gate level). Duplicating it would duplicate risk. |
| Partial issue with per-lane acceptance bits | All-or-nothing lock-step issue | Lock-step starves on out-of-phase readiness and wastes cycles when one lane lags. |
| Masked elements sent with `lane_en = 0` | Not sending masked elements | Not sending them would make `opnd_ready_o` depend combinationally on `opnd_mask_i`. Sending keeps the ready path registered. Cost: a masked lane must have a free slot to consume it. |
| Collect a beat only when all its active lanes are valid; lanes' ROBs hold early results | Per-lane capture buffers in the collector | A beat cannot leave before its slowest element anyway. The lanes already buffer, so extra buffers would add N × 37 flip-flops for no throughput. Lane `out_valid` is stable, so all-or-nothing collection cannot starve. |
| One completion record per command, on a separate channel | Completion fields on the last result beat | Commands with no result beats (vl = 0, reductions) need a completion too. A separate channel suits a control processor. Ordering is guaranteed by §5. |
| Illegal commands still consume their beats | Rejecting the command at the handshake | Keeps the operand stream framed by vl alone. A DMA does not have to know legality. |
| FP32 accumulator, fixed tree + in-order accumulation | Wider accumulator; arbitrary parallel order | See `docs/REDUCTION.md`. The order is fully defined and reproducible for a given N. |
| Register between the collector and the reduction tree | Feeding the first tree adder directly | Without it, the array's longest generic path was 57 cells (lane ROB mux → collector → adder segment A), deeper than anything in the lane. With it, the longest path is the lane's own FMA segment A (53), so the array adds no depth. Cost: 1 cycle of reduction latency and N × 32 + N + 4 flip-flops. |
| Elementwise completion tokens bypass an empty reduction pipeline | Always sending tokens through the tree | Credit turnaround independent of N; 1 short command per cycle (measured). |
