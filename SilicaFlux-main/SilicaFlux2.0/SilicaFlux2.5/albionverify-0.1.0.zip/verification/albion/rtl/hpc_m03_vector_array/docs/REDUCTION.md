# Sum and dot-product reduction

Source: `rtl/hpc_varray_reduce.sv` (`RED_EN = 1`). Command: `cmd_red_i = 1` with
`cmd_op_i = FMV` (vector sum Σ aᵢ) or `FMUL` (dot product Σ aᵢ·bᵢ). FADD, FSUB and the FMA family
are also accepted, and reduce their element results.

## 1. Definition (bit-exact)

Let x_e be the **element result** of the command's operation for active element e. It is computed
by a lane exactly as in an elementwise command and rounded to FP32 with the command's rm. For a
dot product, each product aᵢ·bᵢ is therefore rounded to FP32 before it is summed: this is an
**unfused** dot product. Let N = `NUM_LANES` and `+` be the FP32 addition (`hpc_fp32_add`) under
the command's rounding mode.

```
Beat sum S_g, for each beat g, a pairwise tree over LANE INDEX:
    level 0 leaves      : x_{gN+l} if element gN+l is active, else ABSENT    (l = 0 .. N-1)
    node(left, right)   : left + right     if both present
                          left (unchanged) if only left is present
                          right (unchanged) if only right is present
                          ABSENT           if neither is present
    S_g = root (ABSENT if the beat has no active element)

Accumulation, strictly in beat order:
    acc = cmd_scalar_i                      (initial value)
    for g = 0 .. ceil(vl/N)-1:
        if S_g is present:  acc = acc + S_g
    result = acc
```

Example: N = 4, all active. The beat sum is S = (x0 + x1) + (x2 + x3), and
result = ((init + S_0) + S_1) + …

**Properties that follow from the definition**

* **No identity element is ever added.** An absent operand is skipped, never replaced by +0 or
  −0. Consequences:
  * IEEE has no additive identity valid under every rounding mode: −0 + (+0) is +0, but RDN
    gives −0;
  * NaN payloads of a single present element are not canonicalised by a phantom add;
  * no flag is raised by an add that the definition does not contain.
* **NUM_LANES = 1 is strict sequential accumulation**: ((init + x_0) + x_1) + …. This is
  bit-identical to the FP32 software loop `acc = init; for i: acc += x[i]` with the same rounding
  mode. `ref/red_order_study.c` checks it on 12,000 random dot products and finds 0
  mismatches. The array regression checks it on every N = 1 reduction.
* A reduction with no active element returns `cmd_scalar_i` unchanged, with no flags.
* Masked and tail elements behave exactly as absent leaves.

## 2. Precision, rounding and flags

| Item | Definition |
|---|---|
| Element precision | FP32. The element operation rounds once (FMA: once for a·b + c). |
| Accumulator precision | **FP32**. No wider accumulator, no extended exponent. |
| Rounding | Every tree add and every accumulator add rounds to FP32 with the command's rm (RNE, RTZ, RDN, RUP, RMM). There is no dynamic mode. |
| Subnormals | Full support (no flush-to-zero), as in Module 02. |
| NaN | Canonical quiet NaN `0x7FC00000` from any add involving a NaN (RISC-V). |
| Flags | `cpl_flags_o` = OR of the active elements' flags, every tree add's flags and every accumulator add's flags. |
| Overflow | An intermediate overflow gives ±∞ (or ±max under directed rounding), exactly as the defined sequence of FP32 adds would. Later adds then follow IEEE rules (∞ − ∞ = NaN, NV). |

The FP32 accumulator is deliberate:

* it makes N = 1 equal to sequential FP32 software;
* it makes the result reproducible by a plain FP32 reference implementing §1, such as
  `ref/varray_ref.c`.

A wider accumulator would be more accurate but not FP32-reproducible. It is a future option (§6).

## 3. Reproducibility guarantees

| Guarantee | Holds? |
|---|---|
| Same N, same command, same operands and mask → bit-identical result and flags, whatever the stalls, backpressure, lane holds, reset history or interleaving with other commands | **Yes.** The order depends only on N and the element positions, never on timing. Verified: every regression run compares against the reference under random timing. |
| Bit-identical to a sequential FP32 software loop | **Only for N = 1.** |
| Bit-identical across different N | **No.** The tree shape and the beat boundaries depend on N. |
| Bit-identical to an arbitrary parallel / BLAS / GPU reduction | **No.** No such equivalence is claimed. |
| Equal to the correctly rounded exact sum | **No.** Each add rounds. |

Measured by `ref/red_order_study.c` (SoftFloat-3e, RNE; random dot products of FP32 vectors; the
"exact" reference sums the FP32 products exactly in a 384-bit fixed-point accumulator and rounds
once). Full table: `reports/reduction_order_study.md`. Highlights:

| Data | Length | Array result = sequential software | Max error vs. exact (ulp): sequential / N=4 / N=16 |
|---|---|---|---|
| uniform [0,1), all positive | 16 | 45–48 % of trials | 3 / 2 / 1 |
| uniform [0,1), all positive | 1 000 | 6–7 % | 23 / 12 / 5 |
| uniform [0,1), all positive | 10 000 | 1.6–2.8 % | 52 / 24 / 14 |
| signed, uniform [−1,1) | 1 000 | 3.7–4.7 % | 2418 / 1426 / 302 |
| signed, exponents 2⁻²⁰…2²⁰ | 10 000 | 1.8–2.2 % | 5549 / 2665 / 574 |

* **Parallel orders are different, not worse.** The pairwise tree usually has a **smaller** error
  than sequential accumulation (error growth ~log₂N per beat instead of N), but it is only
  occasionally bit-identical.
* The large ulp figures for signed data come from cancellation: the exact sum is tiny compared
  with the terms, so ulp-of-result errors are large for every order. That is a property of the
  data, not of the array.

## 4. Pipeline, latency and throughput

* **Input register:** decouples the collector (the lanes' result multiplexers) from the first
  tree adder, so the reduction path adds no logic depth to the lane's own pipeline segments.
  Before it was added, the array's longest generic path was 57 cells (lane ROB → collector →
  adder segment A). Now it is 53, the lane's own FMA segment.
* **Tree:** log₂N levels. Each level has N/2^(k+1) `hpc_fp32_add` instances (latency `RED_LAT`)
  plus bypass pipes of the same latency for absent children. Total latency including the input
  register: TL = 1 + log₂N × `RED_LAT`. N − 1 adders in total.
* **Accumulator:** one `hpc_fp32_add` with one add in flight. The result is written back after
  `RED_LAT` − 1 cycles and usable `RED_LAT` cycles after the add started.
* **Throughput:** one beat with at least one active element per `RED_LAT` cycles, i.e.
  N / `RED_LAT` elements per cycle (default N / 3). Beats with no active element and
  completion tokens flow at one per cycle.
* **Latency** (last operand beat accepted → completion handed over, nothing stalling):
  (`LAT_unit` + 1) + TL + `RED_LAT` + 1 cycles, where `LAT_unit` is the lane latency parameter of
  the element operation and TL = 1 + log₂N × `RED_LAT`. Measured: 7 (FMV) and 9 (FMUL) cycles at
  N = 1, rising by 3 per doubling of N to 19 and 21 at N = 16 (`reports/performance.md` §1). This
  matches the formula exactly.
* **Back-pressure:** admission is credit-checked against the completion queue, so the pipeline
  never stalls internally. The collector waits (`RED_WAIT` counter), lane buffers fill and the
  operand stream stalls. Nothing is lost.

## 5. Verification

* Every reduction result and flag set in the regression is compared with `ref/varray_ref.c`.
  The reference implements §1 independently, on SoftFloat-3e.
* The `red` test covers:
  * FMV / FMUL / FADD / FSUB / FMA-family reductions;
  * masks, tails, vl = 0, vl up to 64·N;
  * initial values ±0, finite and special;
  * moderate and corner-case operands;
  * interleaving with elementwise commands.

  The `mixed`, `reset` and `illegal` tests add reductions with random timing, resets and illegal
  forms (bad op / rm / broadcast).
* Simulation assertions check, every cycle:
  * tree adders aligned with their bypass pipes;
  * sideband aligned with the tree;
  * the accumulator hazard never occurs;
  * no active element in an illegal reduction.
* Mutation testing kills tree-bypass, identity-add, initial-value, recurrence-hazard, credit and
  flag-loss mutants (`reports/mutation.md`).

## 6. Not implemented (next steps)

* **Faster accumulation.** K interleaved partial accumulators would give K × the reduction
  throughput, but they change the order, so K must become part of the defined order.
* **Wider or exact accumulation.** FP64 or a Kulisch-style long accumulator would give
  order-independent (exactly rounded) results, and therefore bit-reproducibility across N, at
  higher area.
* **Fused dot product** (a·b accumulated without rounding the product).
* **Max / min / ordered-sequential reductions.**
