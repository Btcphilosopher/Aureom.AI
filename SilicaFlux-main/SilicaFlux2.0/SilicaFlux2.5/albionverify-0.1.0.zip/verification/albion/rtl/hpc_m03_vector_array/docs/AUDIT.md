# Module 03 — repository audit

Audit of `btcphilosopher/aureom.ai` (branch `claude/focused-galileo-kpel01`, HEAD `531137f`,
2026-11-07), done before any Module 03 RTL was written. All SilicaFlux hardware lives in
archives (zips inside zips) and in SystemVerilog-syntax `.sf` files. The archives were extracted
read-only into a private scratch area. Nothing from them was executed except the vendored
Berkeley SoftFloat-3e sources, which were compiled as the independent reference.

## 1. What the brief asked to look for

| Item | Where found | Status | Decision for Module 03 |
|---|---|---|---|
| `hpc_vector_lane.sv` | `SilicaFlux-main/SilicaFlux2.0/silicaflux-hpc-m02-vector-lane.zip` (SHA-256 `e76a238e…`) | Verified by Module 02: 132/132 regression runs (Verilator + Icarus, 6 parameter sets), 28/28 mutants killed, 22/22 gate-level runs, bit-exact against an exact IEEE model that was itself cross-checked against x86 hardware | **Reused unmodified** as the array's lane. The 10 files are copied to `rtl/lane/` with `SHA256SUMS`. |
| `fp32_fma.sv` | `SilicaFlux-main/SilicaFlux2.0/silicaflux-hpc-fp32-fma.zip` (Module 01, SHA-256 `8ca1a6d8…`) | Verified against Berkeley SoftFloat-3e / TestFloat-3e (30.7 M cases per configuration) | **Not instantiated.** The Module 02 lane already contains its own verified fused multiply-add (`hpc_fp32_fma`), wired into its reorder buffer through a fixed-latency, slot-id contract. Module 01's `fp32_fma` has an elastic valid/ready interface instead. Swapping it in would mean modifying the verified lane, which the brief asks us not to do without need. Module 01's **vendored SoftFloat-3e** is reused as this module's independent reference (§4). |
| Existing SIMD engines | `silicaflux-v` `rtl/accel/sfv_vec_engine.sv` (also vendored in DataFabric); `SilicaFlux2.5/vector_engine.sf`; TimingLab `sf_vector_engine_pipe.sv`; MemoryFlow `sf_vec_unit.sv` | All **integer only**. `vector_engine.sf` explicitly steers the FP opcode class `7x` out through `iss_fpx_o` to "the FP datapath", which does not exist. | Not duplicated: Module 03 is the FP vector datapath those engines lack. Conventions adopted (§2). |
| Register files | `SilicaFlux2.5/register_bank.sf`: scalar RF 32 x 32 b, **vector RF 16 x 128 b, lane-packed** | `.sf` source only, no testbench result in the repository | Not instantiated: the first array version takes streaming operands, as the brief allows. A 128-bit VRF entry is exactly one `NUM_LANES = 4` beat. The integration path is in `docs/ARRAY_INTERFACE.md` §10. |
| Vector instruction decoding | `vector_engine.sf` (integer vector decode, FP class steered out); `decoder.sf` (scalar N-wide decode) | No FP vector decode exists | The array takes **decoded commands** (opcode in the `hpc_vector_pkg` encoding plus vl, mask mode, broadcast and reduction fields). It does no instruction decoding. |
| DataFabric | `silicaflux-datafabric.zip`: SFB2 bus (`DW` ∈ {32, 64, 128}), crossbar, single-channel DMA, `sfb_perf_counters` | Verified (simulation, formal, gate level) | No bus port is added (not required by the brief). The array's counters follow the `sfb_perf_counters` house pattern: they saturate and have a clear. The bandwidth consequences are in `docs/PERFORMANCE.md` §5. |
| Memory bandwidth modelling | `silicaflux-bandwidthlab.zip`, `python/bandwidthlab/vector.py` | Models `sfv_vec_engine` memory traffic. Uses the same beat definition: "one beat = LANES consecutive elements = one row across the banks". | The element-to-lane mapping is chosen to match that model, so a future BandwidthLab study can reuse it. Streaming bandwidth needs are derived in `docs/PERFORMANCE.md` §5. |

## 2. Conventions adopted from the repository

* **Element mapping and masking**: `sfv_vec_engine` and BandwidthLab define a beat as LANES
  consecutive elements. `vector_engine.sf` defines `active[l] = (l < vl) & (mask[l] | ~mask_en)`.
  The array uses the same mapping (element *e* → beat *e / N*, lane *e % N*) and the same
  active-element rule, applied per beat.
* **Reductions**: `vector_engine.sf` reduces with a tree whose inactive leaves are replaced by an
  identity value. That is exact for integers but **not** for IEEE FP32: there is no identity
  under every rounding mode (`+0 + −0 = −0` under RDN), and NaN payloads and flags would differ.
  The array's FP tree therefore **bypasses** absent children instead (`docs/REDUCTION.md`).
* **RTL coding rules** (`silicaflux-v/docs/RTL_CODING_RULES.md`), all followed:
  * no `import`, structs, interfaces or `return`;
  * `always_ff` uses non-blocking assignments only, and `always_comb` assigns every output;
  * asynchronous active-low reset with synchronous de-assertion;
  * datapath registers qualified by a valid bit are not reset;
  * simulation-only code sits under `` `ifndef SYNTHESIS ``.
* **Encodings**: opcode, rounding mode and flag encodings come from `hpc_vector_pkg` (Module 02),
  which itself follows `silicaflux_pkg.sf` §7.
* **Tools**: Verilator 5.020, Icarus Verilog 12.0 and Yosys 0.33, the same versions as
  Modules 01 and 02, installed from Ubuntu 24.04. nextpnr-ecp5 0.6 was added for place and route,
  the tool the SilicaFlux-V ULX3S build uses.
* **FPGA target**: the SilicaFlux FPGA prototype board is the **ULX3S with an ECP5 LFE5U-85F**
  (`silicaflux-v/fpga/ulx3s`, ISS-007; post-route SilicaFlux-V reached 39.2 MHz). The Arty A7-100T
  is used by the SRAM library's FPGA self-test. Synthesis is reported for both families and place
  and route for the ECP5.

## 3. Gaps found, and how they are handled

| Gap | Handling |
|---|---|
| Two independent FP32 FMA implementations exist: Module 01 `fp32_fma` and Module 02 `hpc_fp32_fma`. | Not resolved here, because it is outside the array's scope. **Recommendation:** cross-check both bit for bit on TestFloat level 2 and keep one. |
| No `hpc_perf_counters.sv` (Module 02 left the lane's event pulses for a future counter block). | The array has its own counter block, `hpc_varray_perf.sv` (array-level events). The lane `ev_*` pulses stay unconnected. |
| No vector register file RTL, only `.sf`. | Streaming operands (brief §5). Integration path documented. |
| Berkeley TestFloat was not run by Module 02. | Module 03 uses SoftFloat-3e directly as its element-arithmetic reference, so every element result in every array test is checked against SoftFloat. |

## 4. Independent reference

`ref/varray_ref.c` implements the **array specification** (framing, masks, tails, broadcast,
flag aggregation, illegal-command handling and the reduction order). It was written from
`docs/ARRAY_INTERFACE.md` and `docs/REDUCTION.md`, not from the RTL. Element arithmetic comes from
Berkeley SoftFloat-3e Release 3e (commit `f74b1e4`), RISCV specialisation:

* canonical NaN `0x7FC00000`;
* tininess detected after rounding;
* NV raised for `fma(∞, 0, qNaN)`.

This matches the lane semantics in Module 02 `docs/FP_SEMANTICS.md`. SoftFloat shares no code
with either the lane RTL or Module 02's Python model. The sources are vendored unmodified, from
the copy Module 01 already vendors, and checked against `third_party/SOFTFLOAT_SHA256SUMS`.
