# Module 03 — synthesis and FPGA implementation

Scripts: `syn/run_synth.sh` (Yosys 0.33) and `syn/run_pnr.sh` (Yosys `synth_ecp5` +
nextpnr-ecp5 0.6). Tabulated results: `reports/synth/summary.md`, generated from the raw tool
reports in `reports/synth/` and `reports/pnr/`. Every resource number in this document is copied
from those reports.

## 1. What was run

| Flow | Configurations | Checks / outputs |
|---|---|---|
| Generic (`synth -flatten`) | NUM_LANES 1, 2, 4, 8, 16 | `check -assert` (no loops, multiple drivers or undriven nets), **no latches**, cell and flip-flop counts, longest topological path in generic cells, netlists of N = 2 and 4 for gate-level simulation |
| Lattice ECP5 (`synth_ecp5`, flattened) | 1–16, default and lean | LUT4, CCU2C carry cells, TRELLIS_FF, MULT18X18D, distributed RAM, EBR |
| Xilinx 7-series (`synth_xilinx -flatten -noiopad`) | 1–16, default and lean | LUT1–6, LUTRAM, FF, CARRY4, DSP48E1 |
| Per block (generic, hierarchical) | N = 4 | cells per module, i.e. how much of the array is not lane logic |
| Structural interface check | 1–16 | no combinational path from any input to `cmd_ready_o`, `opnd_ready_o`, `res_*`, `cpl_*`, `busy_o` or `perf_cnt_o`, with two positive controls per configuration that find the intended internal combinational paths |
| Place and route (nextpnr-ecp5) | LFE5U-85F CABGA381 (ULX3S), several N | packing and placement success or failure, post-route utilisation, post-route Fmax estimate |

"Lean" = FP add/mul/FMA lanes only (`EN_FCMP=0`, `EN_INT=0`), no reduction unit, no counters.
This is the smallest configuration that still provides the brief's mandatory operations.

**Place-and-route harness.** The array has NUM_LANES × 230 + 120 I/O signals, far more than the
board's pins. `syn/hpc_varray_fpga_harness.sv` therefore:

* drives every array input from LFSR-loaded registers, with lane operands made distinct so that
  no lane can be merged with another;
* XOR-folds every output into a registered signature on the LEDs.

Every array path is thus register-to-register, and nothing can be optimised away. The harness
adds about N × 100 + 300 flip-flops, which are included in the P&R utilisation. The flow and pins
(25 MHz clock on G2, button R1, LEDs) are those of the SilicaFlux-V ULX3S build.

## 2. Results

Full tables, including the LFE5U-25F / 45F and xc7a200t columns, are in
`reports/synth/summary.md`.

### 2.1 Generic synthesis

| NUM_LANES | cells | flip-flops | latches | longest path (generic cells) | where |
|---|---|---|---|---|---|
| 1 | 31,267 | 3,137 | 0 | 52 | reduction accumulator adder, segment A |
| 2 | 54,783 | 4,767 | 0 | 53 | lane FMA segment A (issue register → FMA) |
| 4 | 103,538 | 7,812 | 0 | 53 | lane FMA segment A |
| 8 | 204,496 | 13,671 | 0 | 53 | lane FMA segment A |
| 16 | 404,621 | 25,158 | 0 | 54 | lane FMA segment A (ABC mapping variance) |

* Cells grow linearly: 25.3k cells per lane at N = 16, including the array's share.
* `check -assert` passed in every configuration.
* The longest path is the lane's own FMA segment, the same 53 that Module 02 reports for
  `hpc_fp32_fma`. **The array adds no logic depth.** Before the reduction-tree input register
  was added, the longest path was 57 cells, from the lane result multiplexer through the
  collector into the first tree adder.

### 2.2 FPGA fit on the SilicaFlux prototype board (ULX3S, LFE5U-85F: 83,640 LUT4, 156 MULT18X18D)

| configuration | N | Yosys LUT4-eq. estimate | MULT18X18D | place and route (nextpnr-ecp5) | post-route LUTs (TRELLIS_COMB) | FFs | post-route Fmax estimate |
|---|---|---|---|---|---|---|---|
| default | 1 | 11,575 | 11 | **routed** | 12,651 (15 %) | 2,454 | 32.21 MHz |
| default | 2 | 21,221 | 22 | **routed** | 22,453 (27 %) | 4,104 | 32.15 MHz |
| default | 4 | 39,327 | 44 | **routed** | 41,971 (50 %) | 7,155 | 32.15 MHz |
| default | 8 | 79,342 | 88 | **routed**, marginal: a 73-minute route under heavy congestion | 81,007 (**97 %**) | 13,017 | 31.58 MHz |
| default | 16 | 154,925 (185 %) | 176 (113 %) | not attempted: exceeds both the LUTs and the DSPs | | | |
| lean | 4 | 29,306 | 32 | **routed** | 30,834 (37 %) | 4,929 | 31.91 MHz |
| lean | 8 | 59,368 | 64 | **routed** | 60,367 (72 %) | 9,388 | 30.75 MHz |
| lean | 16 | 117,498 (140 %) | 128 | not attempted: exceeds the LUTs | | | |

* Post-route numbers include the timing harness. Fmax is nextpnr's static-timing estimate after
  routing, speed grade 6, seed 1, with a 25 MHz constraint.
* **Every routed configuration meets the board's 25 MHz clock.** SilicaFlux-V reached 39.2 MHz
  in the same flow.
* The critical path is always inside a lane's FMA (Module 02 datapath), not in the array control.
  Fmax is therefore essentially independent of N (32.21 → 31.58 MHz from 1 to 8 full lanes).

**Fit summary for the ULX3S-85F.**

* With all features, 4 lanes fit comfortably (50 % LUT).
* 8 full lanes **do** place and route, but they fill 97 % of the LUTs. nextpnr needed 73 minutes
  to resolve congestion, and nothing else (CPU, DataFabric, DMA) would fit alongside.
* The practical 8-lane prototype is the lean FP-only build (72 %, routed in 13 minutes).
* 16 lanes do not fit in any configuration.

### 2.3 Xilinx 7-series (Yosys `synth_xilinx`; Vivado would differ)

| N | LUT (default) | DSP48E1 | xc7a100t (Arty A7-100T: 63,400 LUT, 240 DSP) | LUT (lean) | DSP48E1 (lean) | xc7a100t lean |
|---|---|---|---|---|---|---|
| 1 | 5,918 | 7 | 9 % / 3 % | 3,919 | 4 | 6 % / 2 % |
| 2 | 10,745 | 14 | 17 % / 6 % | 7,610 | 8 | 12 % / 3 % |
| 4 | 20,520 | 28 | 32 % / 12 % | 15,168 | 16 | 24 % / 7 % |
| 8 | 40,663 | 56 | 64 % / 23 % | 30,855 | 32 | 49 % / 13 % |
| 16 | 79,302 | 112 | **125 % (exceeds)** / 47 % | 61,555 | 64 | 97 % / 27 % (marginal) |

The 6-input LUTs and 25 × 18 DSPs of the 7-series need about half the LUTs of ECP5's LUT4s.
On an Artix-7 100T, 8 full lanes fit by synthesis estimate. No 7-series place and route was run.

### 2.4 Where the area goes (generic, hierarchical, N = 4)

| block | cells | share |
|---|---|---|
| 4 × `hpc_vector_lane` (Module 02) | 94,748 | 82.8 % |
| `hpc_varray_reduce` (3 tree adders + accumulator adder, pipes) | 13,230 | 11.6 % |
| `hpc_varray_perf` (16 × 32-bit counters) | 3,003 | 2.6 % |
| `hpc_varray_issue` (incl. command queue) | 1,300 | 1.1 % |
| beat-tracking queue + completion queue | 1,335 | 1.2 % |
| `hpc_varray_collect` | 789 | 0.7 % |
| top-level glue | 86 | 0.1 % |

* The issue controller, collector and queues together cost **3 %** of a 4-lane array.
* The optional reduction unit (N − 1 + 1 FP adders) and the counters are the largest additions.
  Both can be removed with `RED_EN = 0` / `PERF_EN = 0`.

### 2.5 Structural interface check

For every N in {1, 2, 4, 8, 16}, the input cone (cut at flip-flops) of `cmd_ready_o`,
`opnd_ready_o`, every `res_*` and `cpl_*` output, `busy_o` and `perf_cnt_o` contains **no** input
port. The positive controls (lane valid ← `opnd_valid_i`, lane out_ready ← `res_ready_i`) are
found in every configuration (`reports/synth/structural_check.txt`).


## 3. Policy on clock frequency

* **No frequency is derived from synthesis.** Generic-cell path lengths only rank structures.
* The only frequency figures are **nextpnr-ecp5 post-route static-timing estimates** for this
  design on an LFE5U-85F, speed grade 6, at one placement seed. They describe that one
  implementation run, were not measured on hardware, and do not transfer to an ASIC or to
  another FPGA.
* Xilinx numbers are Yosys mappings, not Vivado results.

## 4. Recommended next steps

1. **ASIC.** Run the SilicaFlux ASIC flow (OpenROAD, sky130hd / IHP SG13G2) on `NUM_LANES = 4`.
   The lane's FMA segment A and the 24 × 24 multipliers are the expected critical paths (Module 02
   `docs/SYNTHESIS.md`). `LAT_FMA` / `LAT_FMUL` can be raised without touching the array: the
   array adapts automatically, and only `TRK_DEPTH ≥ LAT + 2` must be kept.
2. **FPGA beyond 4 lanes.** Use the lean configuration, a larger device (ECP5 has no bigger part
   than 85F; an Artix-7 200T or a Kintex), or time-multiplexed lanes.
3. **Timing closure on ECP5.** Map the 24 × 24 significand products to MULT18X18D cascades with
   pipeline registers, and add a register slice on the operand broadcast for N ≥ 8.
