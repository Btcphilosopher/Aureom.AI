# Module 03 — verification

## 1. Approach

```
ref/gen_stim.py ──► cmds.txt, beats.txt ──► ref/varray_ref (SoftFloat-3e) ──► res.txt, cpl.txt
                         │                                                        │
                         ▼                                                        ▼
                tb_hpc_vector_array.sv ── drives ──► hpc_vector_array ──► outputs compared in order
                (random timing, holds, resets)                                (every bit, every cycle)
```

**Independent reference.** `ref/varray_ref.c` implements the array specification:

* framing, element mapping, tail and mask rules, and broadcast;
* inactive-position zeroing and flag aggregation;
* illegal-command handling and the reduction order.

It was written from `docs/ARRAY_INTERFACE.md` and `docs/REDUCTION.md`, not from the RTL. Element
arithmetic is Berkeley SoftFloat-3e (RISCV specialisation), which is independent of both the
lane RTL and Module 02's Python model (`docs/AUDIT.md` §4). The stimulus generator never decides
what is correct.

**Stimulus** (`ref/gen_stim.py`):

* corner-biased FP32 operands: ±0, subnormals, min/max normal, ±∞, quiet and signalling NaNs
  with random payloads, cancellation pairs, FMA addends near −a·b, large and tiny exponents;
* operand words in tail, masked, broadcast and unused positions are random **NaN / sNaN / ∞
  garbage**, so any leak from an inactive position changes a result or a flag.

**Timing** is randomised independently of the data by an xorshift generator in the testbench
(identical on Verilator and Icarus):

* command and operand valid gaps;
* result and completion backpressure;
* per-lane hold patterns;
* segment-wise asynchronous resets.

| Profile | Settings |
|---|---|
| `clean` | everything at 100 %, no holds |
| `stall` | cmd 60 %, operand 70 %, result-ready 55 %, completion-ready 50 %, each lane held 25 % of cycles at random |
| `burst` | lanes held in random bursts of 1–48 cycles |
| `stuck` | one (changing) lane held 15/16 of the time |
| `phase` | lanes held on alternating cycles, **out of phase**: no cycle in which all lanes are free (an all-or-nothing issuer starves) |
| `bp` | result-ready 12 %, completion-ready 15 %, light holds |
| `rst_*` | reset injected at a random cycle within 120–400 cycles of each segment start (mid-activity or idle), under clean / stall / heavy-backpressure timing |

## 2. Checks performed on every cycle of every run

1. **Every result beat** is compared in order with the reference, including:
   * tid, beat index, last flag and active mask;
   * every lane's data and flags, which must be 0 for inactive positions.
2. **Every completion record** is compared in order with the reference: tid, aggregated flags,
   illegal, active-element count, reduction flag and reduction result.
3. **No drop, no duplicate, no reorder.** Both expected streams must be consumed exactly, in
   order, and be exhausted at the end. A spurious output fails immediately.
4. **Completion after data.** When a completion is handed over, no result beat of that command
   may still be outstanding. This is checked before same-cycle results are consumed, so the
   check is strict.
5. **Protocol:**
   * payload held and valid kept high while stalled, for both output channels;
   * payload zero while not valid;
   * no ready, valid or busy during reset;
   * `cmd_ready_o` low in the first cycle after reset.
6. **`busy_o`** is never low while a command is outstanding, and is low at the end.
7. **No X/Z** on any output, checked by reduction XOR because Icarus 12's `$isunknown` is wrong
   on concatenations, as Module 02 also notes.
8. **Hold contract:** no element is ever offered to a held lane (internal probe).
9. **Performance counters** (runs without reset): CMD_IN, CMD_DONE, BEAT_IN, BEAT_OUT, ELEM_IN,
   ELEM_OUT, RES_BP, CPL_BP, BUSY and CYCLES must equal the testbench's own counts, and
   `perf_clear_i` must clear every counter.
10. **Liveness:** progress within 20 000 cycles, and an overall cycle limit.

**Simulation assertions in the RTL** (`` `ifndef SYNTHESIS ``), which fire `$fatal`:

* every collected lane result carries the tag (beat sequence number) of the head beat, which
  checks association;
* no lane ever reports an illegal operation (array legality ≡ lane legality);
* a beat is never released before every live lane has taken its element;
* no queue overflows or underflows;
* reduction tree adders stay aligned with their bypass pipes, and the sideband with the tree;
* the accumulator hazard never occurs;
* no active element appears in an illegal reduction;
* a bypass token never collides with a pipeline emission.

Every assertion of the reused Module 02 lane stays active too.

## 3. Coverage of the brief's verification list

| Brief §7 item | Where | Evidence |
|---|---|---|
| 1 / 2 / 4 / 8 / 16 lanes | configurations `n1`, `n2`, `n4`, `n8`, `n16`; also `n4_min` (all queues depth 1, lane buffers 2, minimum latencies), `n8_deep` (FMA latency 8, ROB 16, `RED_LAT` 5, `VL_W` 12), `n2_lean` (FP-only lanes, no reduction, no counters) | `reports/regression_verilator.md`, `reports/regression_icarus.md` |
| Full-width vectors | `full` (vl = k·N), `directed` | per-test table |
| Short vectors | `short` (vl < N), `b2b` | |
| Non-multiple vector lengths | `nonmult` (vl = k·N + r), `mixed`, `directed` | |
| Long vectors (no truncation) | `long`: first command vl = 2^VL_W − 1 = **65 535** on every size (4 095 for `VL_W = 12`) | |
| Tail masks | every vl that is not a multiple of N; tail operands are NaN garbage | inactive positions must be data 0 / flags 0 / mask 0 |
| Per-lane valid masks | `mask` (random, all-zero, all-one, alternating), `mixed`, `bcast`, `fpexc` | masked lanes receive `lane_en = 0` (coverage `masked_sent`) |
| Mixed lane stalls | profiles `stall`, `burst`, `stuck`, `phase`, plus lane-buffer divergence from masks under backpressure | coverage `partial_issue`, `mixed_lane_out` (> 0 in every multi-lane configuration) and `hold_on_need` (> 0 everywhere) |
| Back-to-back commands | `b2b` (up to 400 short commands at full rate), all `clean` profiles | |
| Result ordering | every run (in-order comparison + tag assertion); mixed operations of different latencies back to back | |
| Reset during activity | `reset` test × 3 reset profiles; 4-state Icarus | resets injected (mid-activity) per configuration in the regression summary |
| FP exception aggregation | every run (per-element flags + aggregated flags); `fpexc`; masked sNaN operands; reduction tree/accumulator flags | |
| Independent reference | SoftFloat-3e | §1 |
| Backpressure is lossless | `bp`, `stall`, `rst_bp` | every element compared, streams exhausted |
| Results associated with commands | tid + beat + last per beat, completion order, tag assertion | mutants M06, M11, M17 |
| Masked elements do not corrupt results | garbage operands; zeroing checks | mutants M03, M12, M13 |
| Illegal commands | `illegal` (reserved ops, rm 5–7, illegal reductions), `mixed` | |
| Reductions | `red`, `mixed`, `directed`, `illegal` | `docs/REDUCTION.md` §5 |

## 4. Results

**Bring-up order.**

1. `NUM_LANES = 2` alone: 138/138 runs on Verilator, then Icarus.
2. 4 and 8 lanes: 276/276, then Icarus for 2, 4 and 8.
3. Only then 1 and 16 lanes and the variant configurations.

The RTL then changed twice, for performance (token bypass) and for logic depth (tree input
register). After each change every campaign below was re-run on the final, frozen RTL.

All numbers are taken from the reports, generated on the final RTL (`build/rtl_frozen.sha256`).

| Campaign | Result | Volume | Report |
|---|---|---|---|
| Regression, Verilator 5.020 | **1632 / 1632 PASS** | 8 configurations × 13 tests × 3 seeds × up to 6 timing profiles. **8,154,450 active-element results** checked bit-exactly, plus every inactive position. 1,333 resets injected, 1,136 of them with work outstanding. | `reports/regression_verilator.md` |
| Regression, Icarus 12 (4-state) | **288 / 288 PASS** | 8 configurations × 13 tests × 1 seed × 4 profiles. 1,721,434 active-element results. 134 resets (112 mid-activity). X-checks on every output. | `reports/regression_icarus.md` |
| Mutation testing | **32 / 32 killed** | 12 runs per mutant at N = 4 | `reports/mutation.md` |
| Gate-level simulation | **34 / 34 PASS** | Yosys netlists of N = 2 and N = 4; Verilator and 4-state Icarus; includes mid-activity resets and vl = 65 535 | `reports/gatesim.md` |
| Lint | **clean** | Verilator `-Wall` on 9 parameter sets, Icarus elaboration of N = 1–16 and of the testbench, Yosys elaboration + latch check | `reports/lint.txt` |
| Structural interface check | **0 violations** for N = 1, 2, 4, 8, 16, positive controls found | | `reports/synth/structural_check.txt` |
| Synthesis | **0 latches**, `check -assert` clean | 21 synthesis runs | `reports/synth/summary.md` |

**Mechanism coverage.** Summed over each configuration's Verilator runs, in cycles or
lane-cycles (`reports/regression_verilator.md`):

* partial issue: 79 k–174 k per multi-lane configuration;
* mixed lane completion at the collector: 60 k–122 k;
* lane held while its element was needed: 623 k–1.78 M;
* tracking queue full, command queue full, and lane completion buffers full;
* completion records held back for their last beat: 15 k–43 k;
* masked elements sent with `lane_en = 0`: 59 k–475 k;
* reduction admission held for completion credits: 1.4 k–44 k;
* reduction admission held for the accumulator: 8 k–36 k in every configuration with
  `RED_LAT = 3` or more.

Each of these mechanisms is exercised heavily in every configuration where it can occur. The
accumulator-spacing stall is 0 in two configurations, for legitimate reasons:

* `n2_lean` has no reduction unit;
* in `n4_min` (`RED_LAT = 2`, 2-entry lane buffers) beats arrive too slowly for a 2-cycle
  spacing to bind.

**Mutation results.** Every injected bug was detected (`reports/mutation.md`). By class:

* tail and framing: M01, M02;
* masks: M03, M12, M13;
* the hold contract and partial issue: M04, M05, M10;
* duplicates and drops: M06, M11, M16;
* misassociation: M17;
* broadcast: M07;
* illegal commands: M08, M28;
* backpressure and credits: M09, M25;
* flag and count aggregation: M14, M15, M26, M27;
* completion ordering: M19, M31;
* payload zeroing: M20;
* reduction tree and order: M21, M22, M23, M24;
* queue logic: M29;
* busy: M30, M32;
* beat index: M18.

**Bugs found during the work** (all fixed and re-verified before the final campaigns):

* Testbench: a start-of-test `perf_clear` raced the first command handshake.
* Testbench: Icarus 12 `$isunknown` false positives, replaced by a reduction-XOR check.
* Generator: vl was not range-checked against `VL_W`; it is now range-checked.
* Performance: short-command throughput was limited by completion credits. Fixed with the token
  bypass.
* Structure: the collector-to-tree path was 57 cells deep. Fixed with the input register.

No functional RTL bug was found by the regression. The RTL changes were for performance and
logic depth.

## 5. Not verified / limitations

* **No formal proof.** Verification is by simulation, mutation, gate-level simulation and
  structural checks. A bounded model check of the issue/collect control (as Module 01 did for its
  pipeline) is a recommended next step.
* **TestFloat was not run through the array.** Element arithmetic is checked against SoftFloat-3e
  on the generated vectors: 8.15 million active-element results in the Verilator regression
  alone. The lane itself was
  verified on 2.7 M+ vectors in Module 02.
* **No hardware run.** FPGA results are synthesis and place-and-route only.
* **Parameter space.** `NUM_LANES` > 16 does not elaborate. Queue depths and latencies were
  verified at the values in §3, not exhaustively.
