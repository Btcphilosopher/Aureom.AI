# Subsystem D (vector engine) -- verification plan

Scope: `hpc_vector_lane` (suite `vec_lane`) and `hpc_vector_array` (suite `vec_array`) of `rtl/hpc_m03_vector_array`.
Bench: `tests/compute/` (`cocotb_vec_lane.py`, `cocotb_vec_array.py`, agents `vec_agents.py`, `varr_agents.py`,
stimulus `vec_vectors.py`, `varr_vectors.py`, registry `suite.py`).  Models: `albionverify/models/vec_fp32.py`
(arithmetic), `vec_lane.py` (lane contract + cycle model), `vec_array.py` (array), `vec_gen.py` (operand generators).
Mutants: `mutants/vec_lane.yaml`, `mutants/vec_array.yaml`.  Findings: reported inline in the worker's final report (the harness did not allow this worker to write `docs/findings_compute.md`; the lead is asked to save that text there).

## 1. Specification used and the models' independence

Models were written from `rtl/hpc_m03_vector_array/README.md`, `docs/ARRAY_INTERFACE.md`, `docs/REDUCTION.md`,
`docs/MICROARCHITECTURE.md`, `docs/PERFORMANCE.md` and from IEEE-754 / RISC-V first principles.  They contain no copy of
RTL logic: `vec_fp32.py` decodes every operand to an exact `(-1)^s * m * 2^e` integer triple, forms the *exact* result as a big
integer, and rounds once (`round_pack`, five rounding modes, gradual underflow, overflow policy, NV/OF/UF/NX); the RTL uses
fixed-width alignment frames, sticky collapse and LZC normalisation -- structurally unrelated.

The model is itself cross-checked, with no simulator, by `tests/compute/test_model_vec_fp32.py` (`python -m pytest
tests/compute -q -k model`):

* hand-computed IEEE examples (ties, zero signs, overflow per mode, tininess-after-rounding boundary, FMA single rounding
  `(1+2^-23)(1-2^-24) - 1 = 0x337FFFFE`, NaN / infinity rules, min/max/compare, integer ops);
* **numpy float32** (host FPU) for add / sub / mul, 30 000 biased random pairs, RNE;
* a **round-to-odd double-precision emulation** (Boldo-Melquiond) as an independent FMA / RNE oracle, 30 000 triples;
* a **Fraction property oracle** that finds the two representable neighbours of the exact real result by bisection over the
  binary32 encodings and applies the textbook rule for *every* rounding mode, incl. overflow policy and the OF / UF / NX flags
  (3 x 7 000 add / sub / mul / FMA-family cases per mode).

`test_model_vec_array.py` checks the array model by hand-computed reductions (order-sensitive `2^24 + 1 + 1 + 1`: sequential
2^24, tree/N=4 16777218), an independent recursive formulation of REDUCTION.md section 1 for N = 1, 2, 4, 8 (random), framing /
mask / broadcast / illegal-command examples and the documented latency tables.

### Interpretations (spec gaps and ambiguities)

| # | Question | Interpretation used | RTL agrees? |
|---|---|---|---|
| 1 | The Module 02 lane docs (`LANE_INTERFACE.md`, `FP_SEMANTICS.md`) are **not vendored**. | Lane policy = array docs ("RISC-V canonical NaN, tininess after rounding, full subnormal support") + lane/pkg header comments + IEEE-754 2019 / RISC-V F rules. | yes |
| 2 | Tininess detection | AFTER rounding (24-bit significand, unbounded exponent) as documented; UF = tiny and inexact. | yes |
| 3 | FMA `inf * 0 + qNaN` | NV raised (RISC-V), canonical qNaN (lane header says the same). | yes |
| 4 | FMIN/FMAX | IEEE minimumNumber/maximumNumber, `-0 < +0`, NV only for sNaN, both-NaN -> canonical NaN. | yes |
| 5 | Lane latency | Result of an operation accepted in cycle t is first presented in t + LAT_unit + 1 (array docs "lane latency (LAT_unit + 1)"); an illegal operation is presented in t + 1 ("complete at once"); in-order retire through the ROB. The lane bench checks `out_valid` / `in_ready` / `busy` / event pulses **in every cycle** against `LaneModel`. | yes |
| 6 | Illegal *reduction* (`red = 1`) | A reduction emits no result beats (ARRAY_INTERFACE 4.2 / 8), so an illegal reduction emits none; completion has `cpl_red = 1`, illegal = 1, count / flags / result 0. "Illegal elementwise commands still emit ceil(vl/N) zero beats". | yes |
| 7 | Reduction with RED_EN = 0 | every `red = 1` command is illegal (checked in the `vec_arr_lean` configuration). | yes |
| 8 | Accumulation start | `acc = scalar; acc = acc + S_g` is a real FP add even if `scalar` is -0 / NaN (REDUCTION.md section 1). Absent leaves are skipped, never replaced by +0 / -0. | yes |
| 9 | `busy_o` | must be 1 whenever a command is outstanding or a result / completion is presented, 0 once everything has drained (ARRAY_INTERFACE 13). | yes |
| 10 | Performance counters | CYCLES, BUSY, CMD_IN, CMD_DONE, BEAT_IN, BEAT_OUT, ELEM_IN, RES_BP, CPL_BP are checked **exactly every cycle** (with saturation at `PERF_CW`, clear and reset); ELEM_OUT == ELEM_IN is checked whenever the array is idle and no clear caught work in flight; STALL_LANE / STALL_TRK / LANE_STALL / OPND_STARVE / COLL_WAIT / RED_WAIT are internal-state functions and are only checked to be monotone between clears and 0 after reset / clear. A clear has priority over the event of the same cycle (documented "synchronous clear"). | yes |
| 11 | `lane_hold_i` | Black-box contract: an operand beat cannot be released if a live (tail-active, legal) lane was held in every interval in which it could have taken its element (hold is registered once; window starts at the latest of previous release + 1, command accept + 1, first cycle the beat was valid). Plus an explicit all-lanes-held window with no beat release. | yes |
| 12 | "Inputs are ignored during reset" | every producer drives **garbage with `valid` toggling during reset** (initial and mid-test resets). | yes |

## 2. Bench architecture

Cycle-based agents (framework `Agent`, sample/drive split), deterministic streams from `env.seeds`.

* **Lane**: `LaneDriver` (hold-until-accept, garbage when idle), `LaneSink` (switchable Throttle), `LaneMonitor` (lock-step vs
  `LaneModel`, Scoreboard ledger accepted == retired + cancelled, coverage).  Every cycle: in_ready, out_valid, busy, result,
  flags, tag, illegal, six event pulses; payload stability while stalled; zero payload while not valid; all outputs zero in reset.
* **Array**: `CmdDriver`, `OpndDriver` (independent streams, garbage idle payload incl. NaN/sNaN/inf in tail, masked, broadcast and
  unused operand positions), `ReadySink` (res / cpl), `HoldDriver` (none / random / bursty / stuck lane / out-of-phase / all),
  `PerfClearDriver`, `ArrayMonitor`: every result beat (tid, beat, last, mask, per-lane data and flags, zero for inactive
  positions) and completion record (tid, flags, illegal, count, red, result) against the model, in order, from the first
  cycle presented; **completion presented strictly after its last result beat was handed over**; payload held while
  stalled; zero payload while invalid; framing (operand beats accepted <= beats of commands accepted at earlier edges);
  busy; cmd/opnd ready low in the first cycle after reset; hold contract; counters.
* Model-only inputs: the monitor learns the DUT's accepted commands from the handshake; the model computes expected beats from
  the operand beats the driver actually presented.

## 3. Test list (`tests/compute/suite.py`)

`vec_lane` (4 DUT configs: `vec_lane_def` documented defaults, `vec_lane_min` minimum latencies with ROB 3 < LAT + 2,
`vec_lane_lean` EN_FCMP = EN_INT = 0 and long latencies 4/5/6/2/3, `vec_lane_tiny` degenerate ROB_DEPTH = 1 / TAG_W = 1):
`directed_arith` (31 x 31 corner pairs x 5 rm on FADD/FSUB/FMUL, 5 compare/min/max ops, 17^3 FMA triples x 4 ops, structured FMA
residual / cancellation / tininess / overflow / far-alignment cases, tie sweeps at every exponent gap 22..28, integer ops,
illegal opcodes and rm 5-7), `directed_arith_stalled`, `hunt_arith` (tag `long`: ~71 000 boundary operations -- power-of-two
minuends vs sticky-only addends at every exponent gap, FMUL overflow / underflow / subnormal boundary exponents, FMA alignment
frame boundaries), `latency_per_op`, `throughput_and_ordering`, `backpressure_hold`, `lane_enable`, `illegal_ops`, `random_ops`
(4 timing profiles x 1100 ops, 3 seeds), `random_long` (64 000 ops), `reset_mid_pipeline` (occupancy-, stalled-result-,
ROB-full-triggered, idle, random and mid-cycle asynchronous resets, operations queued during reset, garbage `valid` toggling in
reset).

`vec_array` (8 DUT configs: `vec_arr_n2` defaults with 8-bit saturating counters, `vec_arr_n4` min latencies and shallow
queues/ROB, `vec_arr_lean` N=2 without reduction / counters / compare / int and depth-1 queues, `vec_arr_n1`, `vec_arr_tiny`
(every depth 1, VL_W = 3, 2-bit counters), `vec_arr_n8`, `vec_arr_n16` (four reduction levels), `vec_arr_deep` (FADD / FMUL / FMA / IMUL
latency 6 / 5 / 8 / 4, RED_LAT 5, ROB 16, VL_W 12, vl up to 4095 -- documented timing formulas with non-default parameters)):
`directed_elementwise`, `mask_vl_broadcast`, `reductions` (all ops / rm / init values, association-order-sensitive data),
`illegal_commands`, `config_change_b2b`, `latency_and_throughput` (documented latencies; ceil(vl/N) cycles per command),
`queue_depth` (exactly CMD_DEPTH + 1 commands accepted without operands), `stalls_and_holds`, `long_vector` (vl = 2^VL_W - 1),
`random_mixed` / `random_long` (~12x volume), `reset_mid_command`.

Tags: `directed`, `random`, `reset`, `error`, `long`.  Mutation subsets are fast (< ~60 s per surviving mutant).

## 4. Functional coverage (framework `CoverGroup`, merged per regression)

Lane: op x rm (incl. illegal opcode / rm 5-7), value classes (zero, subnormal, tiny normal, normal, huge, inf, qNaN, sNaN)
per family x class(a) x class(b), result class, flags per family, unit latency class, ROB occupancy, out backpressure run
length, ready-low run length, overtaking, lane_en off, illegal retired, reset context.
Array: op x rm x red x vm x bcast x vl class, illegal kind x vl = 0, **configuration change between back-to-back commands x gap**,
res / cpl / cmd / opnd stall run lengths, outstanding commands, concurrency events (reduction with elementwise in flight, two
reductions, completion held while results flow, ...), active lanes per beat, per-lane activity, lanes held, family x class,
reset context (idle / queued / beats in flight / result stalled / completion stalled / reduction in flight), reduction
op x rm and flag / count shapes.  Holes are reported honestly in the regression coverage report.

## 5. What is NOT verified

* Simulation only: no formal proof, no gate level, no timing.  The "no combinational input -> output path" claim of
  ARRAY_INTERFACE 10 is not provable in a cycle-based cocotb bench (only registered-output behaviour is observed).
* Internal-state performance counters (STALL_LANE, STALL_TRK, LANE_STALL, OPND_STARVE, COLL_WAIT, RED_WAIT) are not checked exactly.
* TID_W != 8, VL_W > 12, PERF_CW = 32 saturation (reached only for the 2-, 8- and 16-bit configurations), RED_LAT > 5, lane
  latencies above those of `vec_arr_deep`.
* Exhaustive FP verification (TestFloat-scale) is out of scope; the lane is covered by corner sweeps, boundary soaks and
  biased random (about 10^5 directed / boundary and 6 x 10^4 random operations per configuration).
* Reductions are checked at NUM_LANES 1, 2, 4, 8, 16 against the documented association order, but not for every VL_W / vl.
* Throughput / latency numbers are checked against the documented formulas only for the idle / clean-stream cases of
  `latency_and_throughput` (full-rate configurations).

## 6. Results of the last runs (all produced by the commands below)

| Command | Result |
|---|---|
| `python -m pytest tests/compute -q` | 42 passed (model tests) |
| `python -m albionverify regress --suite vec_lane -j 2` | 46 / 46 PASS, 13 096 526 checks, functional coverage 100 % of 1748 bins |
| `python -m albionverify regress --suite vec_array -j 2` | 86 / 86 PASS, 6 851 569 checks, functional coverage 97.7 % of 3113 bins (71 holes, see below) |
| `python -m albionverify determinism --suite vec_lane` | 31 runs executed twice, 0 mismatches |
| `python -m albionverify determinism --suite vec_array` | 70 runs executed twice, 0 mismatches |
| `python -m albionverify mutate --suite vec_lane -j 2` | 40 mutants: 39 killed (37 by checks, 2 by RTL `$fatal` assertions VL-38 / VL-39), 0 survived, 1 equivalent (VL-07) |
| `python -m albionverify mutate --suite vec_array -j 2` | 49 mutants: 48 killed (41 checks, 4 RTL assertions, 3 liveness), 0 survived, 1 equivalent (VA-49) |

Equivalent mutants (written arguments are in the YAML):
* **VL-07** -- adder sticky-collapse threshold 26 instead of 27: for an exponent difference of exactly 26 the smaller significand
  lies completely in guard / sticky positions 23..0, so the collapsed single sticky bit yields the same guard / sticky both for
  addition and for subtraction (including the 1-bit renormalisation of a power-of-two minuend).  The RTL threshold is conservative.
* **VA-49** -- reduction tree adders with swapped operands: IEEE addition is commutative bit-for-bit (value, zero sign, canonical NaN, flags).

Functional-coverage holes (vec_array): 71 bins; the primary `vec_arr_n2` group has none and `vec_arr_n4` one (reset while a
completion is stalled); the rest are in secondary configurations that run fewer cases (e.g. no `vl = max` / reset-context variety in
`vec_arr_lean`, `vec_arr_n1`, `vec_arr_n16`, `vec_arr_deep`), bins that are structurally unreachable (back-to-back command acceptance
with a depth-1 command queue; > 4 commands outstanding with depth-1 queues) and random-only crosses (illegal rm x a rarely drawn op).
Model sanity: deliberately wrong models turn the benches red (RNE -> ties-away: lane mismatch at cycle 489; sequential instead of
tree reduction: completion-result mismatch at cycle 163).
