# Subsystem E -- ControlCore verification plan (AlbionVerify)

Owner: control-subsystem bench (`tests/control/`, `albionverify/models/ctl_*.py`, `mutants/ctl*.yaml`).
Specification: `rtl/controlcore/docs/*.md` (MEMORY_MAP, HW_SW_INTERFACE, 01_ARCHITECTURE, 03_BOOT, 04_INTERRUPTS, 05_ACCELERATORS,
06_FIRMWARE section 4 for the mailbox answer format, 07_VERIFICATION, 09_LIMITATIONS) and, for the access-control gate, the SFB2
rules of `rtl/datafabric/docs/datafabric/PROTOCOL.md`.  The models were written from these documents, not from the RTL.

## 1. What is verified and how

| Suite | DUT (config name) | Reference model | Bench |
|---|---|---|---|
| `ctl_mailbox` | `cc_mailbox` (`ctl_mbox256` = DIAG_DEPTH 256 as specified, `ctl_mbox8` = depth 8 for fast wrap / overflow) | `models/ctl_mailbox.py` | `cocotb_mailbox.py` |
| `ctl_sysctrl` | `cc_sysctrl` inside `tests/control/ctl_sysctrl_wrap.sv` (`ctl_sysctrl`) | `models/ctl_sysctrl.py` (page + reset generator + synchronisers) | `cocotb_sysctrl.py` |
| `ctl_pmu` | `cc_pmu` (`ctl_pmu`) | `models/ctl_pmu.py` | `cocotb_pmu.py` |
| `ctl_ras` | `cc_ras` (`ctl_ras`) | `models/ctl_ras.py` | `cocotb_ras.py` |
| `ctl_perf` | `cc_perf` (`ctl_perf20` = NEV 20 / EDGE as wired in the top level, `ctl_perf5` = NEV 5) | `models/ctl_perf.py` | `cocotb_perf.py` |
| `ctl_secmon` | `cc_secmon` (`ctl_secmon`) | `models/ctl_secmon.py` | `cocotb_secmon.py` |
| `ctl_sfbgate` | `cc_sfb_gate` (`ctl_sfbgate`) | `models/ctl_sfbgate.py` + model-independent transaction scoreboard | `cocotb_sfbgate.py` |
| `ctl_core` | `silicaflux_control_core` (`ctl_core`), real CPU / boot ROM / crossbar / INTC / WDT / DMA | spec values (no RTL model); payload `ctl_fw.S` | `cocotb_core.py` |

Shared code: `tests/control/ctl_bench.py` (lockstep `BlockChecker`, `PinDriver`, `RegTraffic`, `Recorder`, async mid-cycle reset helper),
`tests/control/ctl_fw.{S,py}` + `gen_fw.py` (boot image builder and the assembled payload), `albionverify/models/ctl_spec.py`
(hand-transcribed documented map), `albionverify/models/ctl_base.py`.

### 1.1 Register-block benches (all seven `cc_*` blocks)

Every block bench drives the SilicaFlux-V register bus (`RegBusMaster`) and the block's own inputs with seeded stimulus, and **every
cycle** feeds the inputs actually in force to the independent model and compares `rb_rdata` (reads), `rb_err` (all accesses) and
every output pin (irq / pins / strobes) -- cycle-accurate, including same-cycle set/clear priorities.  Idle cycles drive garbage on
`rb_we/addr/wdata` with `rb_sel = 0` (side-effect-free check).  Hand-computed expectations (spec examples, timing in cycles) are
asserted independently of the model in the directed tests; model self-tests are in `tests/control/test_model_*.py` (no simulator).

Covered per block (see the case list in `suite.py`):
* **Reset values** of every register and a read of **all 1024 word offsets of the 4 KiB page** (documented registers, holes refused,
  no aliasing); RO / WO / W1C / RW access types; writes to RO and unmapped offsets refused with `rb_err = 1`, rdata 0, and **no side
  effect** (mailbox: the whole page is read before and after 400 refused accesses and compared; every block: the lockstep model sees every
  refused access and a final full-page sweep compares the end state); read of write-only registers refused (interpretation A-1).
* **Interrupts / pins**: assert and deassert conditions, masking (`WARN_EN`/`FATAL_EN`), level vs pulse sources (RAS), sticky
  status and re-set while a level is active, same-cycle event vs W1C / CLEAR priority (RAS, SYSCTRL cause, SECMON violation),
  doorbell ring/ack and `host_irq` / `irq_h2f` pins (mailbox), `host_ready` / `cmdproc_ready` / `test_*` pins (SYSCTRL), clock gate /
  reset / isolation with their documented 2-edge registered timing (PMU), `host_lock` (SECMON).
* **Reset behaviour**: synchronous pulses and **asynchronous mid-cycle assertion** (`rst_n` / `rst_ni` driven between clock edges at
  random phases) in the middle of random traffic, then reset values re-read and compared with hand values; SYSCTRL: POR vs SYS domain
  (scratch / cause / count survive soft, watchdog and host resets, not POR), the 16-cycle reset pulse (exact length and the 18-cycle SYS
  reset window), request merging during an active pulse (first / last pulse cycle boundary), wrong keys, 2-flop synchroniser latencies.
* **Seeded random traffic** (3-4 seeds per block, 6 phases each: different address mixes, write ratios, bus gap profiles, event
  densities) over the whole page, plus a final full-page sweep.
* **Boundary / long cases**: FIFO empty / one / full-1 / full / overflow / pop-empty / pointer wrap with DIAG_DEPTH 256 and 8; 16-bit ring
  counters wrapped (65 541 rings each, `long`); `SLEEP_CYC` / `GATED_CYC` / `CYCLE_LO` / event counters past 16 bits (65 545 .. 70 000
  cycles, `long`).
* **Malformed accesses**: unaligned (`addr[1:0] != 0`) reads / writes probed on every block (`unaligned_probe`); sub-word strobes and
  misalignment at the system level are tested in `ctl_core`.  The register bus itself has no strobes, no wait states and no
  back-pressure: "wrong width / strobes" and "backpressure duration" do not apply to a page; the gap between accesses is the coverage
  analogue (`*.bus` coverage groups).  Back-pressure is verified where it exists: `cc_sfb_gate` (150-cycle stalls on both sides).

### 1.2 `cc_sfb_gate` (access control)

Refused requests: error response with rdata 0 exactly one cycle after acceptance, **no request reaches the slave** (the slave log is
empty and the slave memory is compared with a reference that only applies forwarded writes), `refused_evt` pulses once per refused
request.  Forwarded requests: payload, strobes, read data and slave error flags pass through unchanged and in order.  A request already
presented downstream is never withdrawn when `refuse` rises (checked directly, by the SFB2 R2 monitor and by the lockstep model);
`idle`, one-transaction-at-a-time, 150-cycle stalls on both channels, reset (sync and async) with requests in flight.  Two random
regimes: *tagged* (refuse constant per request, model-independent transaction scoreboard + conservation) and *free-running refuse*
(cycle-level lockstep + monitors + conservation `accepted = refused + seen by slave`).

### 1.3 `silicaflux_control_core` (boot and integration)

Everything the bench can reach through the documented ports (host SFB2 port, boot straps, reset request pin, interrupt inputs, the
external SFB2 port served by a Python device memory, an "absent" accelerator register port):

| Case | What is checked |
|---|---|
| `boot_handshake_irq` | ROM stage progression read through the host port (increasing subset of RESET..WAIT_IMAGE), identity / reset cause / count, ROM console banner (diag tap == DIAG_RX FIFO), host image load + IMEM readback, `IMAGE_READY` hand-shake (status / command echo), firmware start (pins `host_ready_o`, `cmdproc_ready_o`, BOOT_MEASURE = CRC32 of the payload), **mailbox doorbell -> INTC -> CPU MEI -> handler -> answer -> `host_irq_o`** (3 messages), 6 software-pended sources taken **in priority order in one trap**, masking by `INTC.ENABLE` and `THRESHOLD`, real inputs `ext_warn_i`, `ext_fatal_i` (-> RAS -> INTC -> CPU, `ras_fatal_o`), `acc_vec/tsu_irq_i` (delivered, and masked while isolated), host write lock (refused with error, no side effect, SECURITY + RAS logging, not releasable) |
| `host_access_control` | access matrix and malformed host requests: unmapped, EXT window (denied), misaligned, ROM write, sub-word register writes, RO writes, holes, absent pages 18..31, forwarded pages 8..15 (`acc_rb_*` strobe address / data) and isolation; **every refused access is logged by RAS** (BUS_DECODE / PERIPH_ERR / ISO_ACCESS) with count, FIRST / LAST source and the offending address; ROM content read through the host == ROM image; PMU outputs `acc_rst_no` and the gated clock `acc_clk_o` |
| `bad_images` | 12 corrupted images (magic, header version x2, size x3, load address, entry x3, CRC x2): `BOOT_ERROR`, `BOOT_STATUS`, `BAD_CMD` answer with the reason in `F2H_MSG1`, no firmware start / no measurement, retry without reset; unknown command answered `BUSY`; corrected image accepted |
| `reset_early`, `reset_boot_sequence` | host reset request (early ROM, and while firmware runs), watchdog expiry, `SOFT_RESET`, asynchronous POR mid-cycle (running firmware, during ROM scrub): cause / count accumulate, POR-domain scratch survives, SYS-domain registers clear, cold boot scrubs IMEM and waits for the host again, firmware-start counter evidence |
| `warm_boot` | soft and watchdog reset with a valid retained image restart it without the host (no WAIT_IMAGE, `BOOT_STATUS[8]`), damaged retained image falls back to a cold boot |
| `boot_ext`, `boot_ext_fallback`, `boot_ext_fallback_empty`, `boot_ext_fallback_stale_header` | `BOOT_MODE_EXT`: image fetched through the external port by the system DMA (reads only, inside the image window, under random back-pressure), image in IMEM == device image, no host action; a failing device image (bad CRC / no magic) falls back to host loading, the ROM's failure message is acknowledged, a good host image is then accepted and a host image with a wrong CRC is still rejected |
| `boot_mode_straps` | straps visible (synchronised) in `SYSCTRL.BOOT_MODE` for all four values |

A full bench of the real core **was feasible** (the closure is 40 files, the accelerators are ports; Verilator builds it in about
a minute on a loaded machine, the ROM reaches `WAIT_IMAGE` after 295 278 cycles in this simulation) -- nothing is faked: the CPU executes the real ROM and a real
RISC-V payload that this bench assembled (`ctl_fw.S`, `llvm-mc` + `ld.lld`; `test_model_fw.py` re-assembles it and compares the words).

## 2. Spec ambiguities and the interpretation used

| Id | Question | Interpretation in the models |
|---|---|---|
| A-1 | Is a **read** of a write-only register (e.g. `H2F_RING`, `SOFT_RESET`, `INJECT`, `CLEAR`) refused? | Yes (`rb_err = 1`, rdata 0), as "WO" and the page rule "writes to RO / unmapped are refused" suggest |
| A-2 | MEMORY_MAP "Reset" column is blank for most RW registers | reset value 0 (except the documented `ACC_CTRL` = 1, `RAS.CTRL` = 1, `RESET_CAUSE` = POR) |
| A-3 | A reset request arriving while a reset pulse is active | merged: not counted, its cause is not recorded (documents silent). Open question Q-1 |
| A-4 / A-15 / A-10 | New event vs same-cycle W1C / CLEAR | the new event wins (RAS STATUS, SYSCTRL cause, SECMON violation) |
| A-5 | `RESET_CAUSE` after POR | `POR` (bit 0) only |
| A-6 | `SYSCTRL.TEST_CTRL[29:16]` | unspecified, not compared (the RTL stores them) |
| A-7 | several RAS events in one cycle | `FIRST_SRC` = lowest source index, `LAST_SRC` = highest |
| A-8 | `FIRST/LAST_ADDR` of sources without an address input / of injected events | 0 for real events without an address, **not compared** for injection-only events and for the fields after `CLEAR_FIRST` |
| A-9 | PMU cycle timing | `ACC_CTRL` is one register, `CLK_ON` / effective reset one more stage computed from it (clock drops two edges after the write, reset applied two edges after) |
| A-11 / A-12 | `cc_perf`: clear while frozen; edge detector while frozen | clear works while frozen; the detector keeps tracking the input (no spurious edge when an input held through UNFREEZE) |
| A-13 | `RAS.INJECT` bit 7 / bits [15:12] | no such source: nothing is raised |
| A-14 | event in the `CLEAR_FIRST` cycle | becomes the new first event |

Open questions for the design team: Q-1 (requests during a reset pulse), Q-2 (unaligned register offsets: refused or ignored? only the
mailbox deviates -- finding CTL-001, reported in the handback to the lead because this environment does not allow writing a
`docs/findings_control.md` file), Q-3 (reset values of RW registers in MEMORY_MAP), Q-4 (answer word format, finding CTL-D1).

## 3. Functional coverage (separate from RTL code coverage)

Each bench builds `CoverGroup`s (transaction type x register class x result, address boundaries, bus gaps, block-specific scenario
groups: FIFO level x operation, doorbell pending x ring/ack, reset scenarios, event capture scenarios, gating / isolation causes, perf
counter x mode x action, gate decision x result x stall, interrupt source x origin x scenario, host access classes, boot paths and
errors).  Impossible cross combinations are excluded with `ignore` filters (not padded).  Numbers and holes: section 6 (filled from
the last `regress` run).

## 4. What is NOT verified (and why)

* **Counter saturation at 2^32-1** (`SLEEP_CYC`, `GATED_CYC`, `cc_perf` counters, RAS counters, `VIOL_COUNT`) and the 64-bit cycle
  counter carry: unreachable (4.3e9 cycles); no back-door is available in the framework build (no `--public-flat-rw`).  The saturation
  rule is covered by the model unit tests only; the corresponding mutants are annotated `equivalent` with this argument.
* Unaligned register offsets are **not** applied in random traffic (the crossbar refuses misaligned requests before they reach a page;
  `unaligned_probe` + the system test `host_access_control` cover both levels).
* The ControlCore **CPU** (RV32IM), the INTC / timer / WDT / DMA IP (reused, unmodified) are only exercised through what the ROM / payload and the host reach;
  there is no ISA, timer, or DMA verification here (see `07_VERIFICATION.md`: those have their own evidence).  The payload does not
  use the timer, the DMA (except through the ROM's device-memory boot), the accelerators, or `mcycle` / `minstret`.
* Real accelerators (pages 8..15, `acc_*_busy/halted`) are absent; the PMU / RAS paths that depend on them are exercised by driving the
  documented input pins (unit benches) and by the "absent" register port (core).
* Isolation of the **external data port** (`cc_sfb_gate` as isolation gate in the top level), the system-DMA error -> RAS `DMA_ERR` path,
  parity injection through real IMEM / DMEM reads, the 20-event perf wiring in the top level, `test_mode` scan bypass, reserved
  boot-mode values 2 / 3 behaviour (the documents do not define them), the host port during a SYS reset with a request in flight
  (documented as lost, `09_LIMITATIONS.md`), multi-seed randomisation of the core boot.
* Gate-level, formal, FPGA, and anything in the firmware beyond the ROM (the real firmware is not part of the pinned RTL).

## 5. Framework limitations hit

* `ResetSequencer.async_pulse` consumes a clock edge itself (it awaits `RisingEdge`), so agents miss one sample/drive; the bench uses its
  own `async_reset_midcycle` (called right after a tick) in `ctl_bench.py`.  No framework change requested.
* Flops without a clock edge are random at power-up (`--x-initial unique`): outputs are not compared in the first cycles after time 0
  (`BlockChecker(warmup=...)`) -- an artefact of 2-state simulation, not a DUT property.
* Core runs are slow (about 4 000 cycles/s of CPU in cocotb): a cold boot to `WAIT_IMAGE` is 295 000 cycles.  The mutation set for the
  core therefore uses only the most discriminating cases.

## 6. Results of the last runs (all numbers from commands that were run)

`python -m pytest tests/control -q` -> **298 passed** (model self-tests, spec / header cross-check, every mutant patch applies to the pinned RTL).
`python -m albionverify vendor-check` -> 253 pinned files, 0 problems.

### 6.1 `regress` (per suite, `-j 1`/`-j 2`)

| Suite | runs | PASS | XFAIL | checks | functional coverage | holes |
|---|---|---|---|---|---|---|
| `ctl_mailbox` | 32 | 31 | 1 (`unaligned_probe`, CTL-001) | 1 241 186 | 98.6 % of 146 bins | `mbox8`: ring-counter wrap bins (the 65 541-ring test runs on the 256-deep config only) |
| `ctl_sysctrl` | 14 | 14 | 0 | 527 179 | 100 % of 65 | -- |
| `ctl_pmu` | 13 | 13 | 0 | 411 050 | 100 % of 89 | -- |
| `ctl_ras` | 16 | 16 | 0 | 443 268 | 100 % of 78 | -- |
| `ctl_perf` | 19 | 19 | 0 | 96 139 | 100 % of 130 | -- |
| `ctl_secmon` | 12 | 12 | 0 | 117 142 | 100 % of 43 | -- |
| `ctl_sfbgate` | 15 | 15 | 0 | 1 326 539 | 100 % of 25 | -- |
| `ctl_core` | 16 | 16 | 0 | 1 908 636 | 94.2 % of 69 | boot stages `ACC_DISCOVERY`, `SELF_TEST`, `SHUTDOWN`, `FATAL`: set only by the real firmware, which is not part of the pinned RTL (the bench payload does not walk them; not padded) |
| **total** | **137** | **136** | **1** | **6 071 139** | | |

### 6.2 `mutate` (final test code; builds were cached from the first campaigns)

| Suite | mutants | killed | survived | equivalent-annotated | note |
|---|---|---|---|---|---|
| `ctl_mailbox` | 31 | 31 | 0 | 0 | |
| `ctl_sysctrl` | 33 | 33 | 0 | 0 | includes 2 mutants of the vendored synchronisers (reset chain) |
| `ctl_pmu` | 29 | 28 | 0 | 1 | |
| `ctl_ras` | 37 | 36 | 0 | 1 | |
| `ctl_perf` | 24 | 23 | 0 | 1 | |
| `ctl_secmon` | 25 | 24 | 0 | 1 | |
| `ctl_sfbgate` | 26 | 26 | 0 | 0 | first campaign: 1 survivor (`CG-26`, a refusal accepted while the gate is not free): the bench master allowed only one outstanding request so the gate was never asked to hold a request while busy; fixed by `max_outstanding = 2` (SFB2 R6 allows presenting the next request while a response is pending), then 26/26 |
| `ctl_core` | 19 | 19 | 0 | 0 | 17 killed by CHECK, 2 by LIVENESS; mutation cases: `boot_mode_straps`, `reset_early`, `host_access_control`, `boot_handshake_irq` (about 3 minutes of CPU per mutant after the build: this is the one suite above the 90 s guideline) |

Every "equivalent" annotation is the same argument: the mutant removes the **2^32 - 1 saturation** of a counter (PMU `SLEEP_CYC`, RAS
`WARN_COUNT` / `FATAL_COUNT`, PERF event counters, SECMON `VIOL_COUNT`), which differs from the original only after 4.3e9 events -- not observable
in any bounded simulation.  This is a verification limit, not true equivalence (stated in section 4).  All other mutants were killed by CHECK
(scoreboard / lockstep / hand-computed expectation) failures, none by timeout or crash.  One perf mutant (`CF-07`) did not compile in the first
campaign (Verilator restriction on delayed array assignment in a `for` with a compound condition); it was rewritten and killed.

### 6.3 `determinism` (run twice in fresh processes, digests compared)

`ctl_mailbox` 16 runs, `ctl_sysctrl` 8, `ctl_pmu` 8, `ctl_ras` 10, `ctl_perf` 13, `ctl_secmon` 7, `ctl_sfbgate` 7, `ctl_core` 11, `ctl_core_fast` 4:
**0 mismatches** each.
