# Findings: DMA (block B)

Source: DMA bench worker report. Numeric claims in that report are not repeated here; the consolidated, re-executed
numbers are in `reports/SUMMARY.md`. The verification plan is `docs/dma_verification_plan.md`.

## RTL defects

None found in `silicaflux_dma` (simple and buffered engines, single and dual port) or `hpc_dma_adapter`.
No `known_defect` tags were needed.

## Interpretations where the specification (DMA.md / PROTOCOL.md / MEMORY_MAP.md) is silent or ambiguous

The model encodes each reading below; the RTL matched every one. If the intended behaviour differs, these are the places to look.

| id | question | interpretation used |
|---|---|---|
| Q1 | ABORT landing on the same edge as a response | one more transaction may start; the model tolerates exactly one |
| Q2 | precedence between a bus error, an abort and a validation code | a bus error beats ABORTED; a validation code beats an abort written during VALIDATE |
| Q3 | ERROR_CODE / ERROR_ADDR lifetime | cleared by START; ERROR_ADDR is 0 for non-bus errors |
| Q4 | CONTROL reads | return 0 without error |
| Q5 | STALL_CYCLES / TRANSFERS | STALL_CYCLES counts once per cycle even with two ports; TRANSFERS counts DONE only |
| Q6 | STATUS.STATE in a dual-port or gap cycle | either ISSUE state is accepted |
| Q7 | register offsets that are not word aligned | unmapped |
| Q8 | adapter REGION `cpl_err_addr` when both ranges cross a boundary | either boundary is accepted |
| Q9 | adapter `eng_bytes_done` after a transfer | keeps the previous result until the next START |

## Mutants annotated equivalent

`DA-25`, `DA-26` (adapter): unreachable through the engines; the written argument is in `mutants/dma_adapter.yaml`.

## Not verified

32-bit counter wrap and `MAX_LEN_LOG2 = 24` sizes (only a small `MAX_LEN_LOG2` is built); competing crossbar masters;
SoC/firmware integration; scratchpad internals and FAB_SLICE internals; `rsp_rdata` on errors between the adapter's router and engine.

## Framework observations (see `docs/framework_requests_dma.md`)

`ReqRspSlave` does not notify the response handshake (worked around by subclassing); an RTL `$error` stops Verilator before cocotb
sees the edge, so such kills are classified CRASH rather than CHECK; coverage points that do not apply to a configuration are
reported as 100%.
