# Findings: control subsystem (block E)

Source: control bench worker report; CTL-001 was **independently re-verified by the lead** against the pinned RTL and spec text.
Numeric claims from the report are not repeated here (see `reports/SUMMARY.md`).

## CTL-001  `cc_mailbox` accepts unaligned offsets inside its message windows (spec/RTL discrepancy, low severity, latent)

* **Spec:** `MEMORY_MAP.md`: "32-bit registers (word accesses only on the register pages)"; `01_ARCHITECTURE.md` section 5:
  "unmapped offsets, writes to read-only registers and sub-word writes are refused (bus error ...)".
* **RTL:** `cc_mailbox.sv`: the window decode `msg_h2f = rb_addr[11:5] == 7'd0`, `msg_f2h = rb_addr[11:5] == 7'd1` ignores `rb_addr[1:0]`.
  The write enable is gated by `rb_addr[1:0] == 2'd0`, so a write at an unaligned offset is silently dropped, but `rb_err` is not raised;
  a read at an unaligned offset returns the aligned word with `rb_err = 0`.
* **Measured by the bench:** writes to `0x001/0x002/0x003/0x005/0x021/0x03F` return `rb_err = 0` and are dropped; reads return the aligned word with `rb_err = 0`.
  `0x041`, `0x045`, `0x081`, `0x08D` (outside the windows) are correctly refused, and the other five register blocks refuse unaligned offsets.
* **Impact:** unreachable through the ControlCore: `sfb_crossbar` has `CHECK_ALIGN = 1` and the `ctl_core` bench shows misaligned host requests returning errors and logged by RAS `BUS_DECODE`.
  It matters only if the block is driven by something other than that fabric.
* **Interpretation note:** whether an unaligned *offset within a mapped window* counts as "unmapped" or as a "sub-word" access is not spelled out; both readings call for a refusal (open question Q-2, model refuses).
* **Suggested fix:** gate the window decode with `rb_addr[1:0] == 2'b00` (and raise `rb_err` otherwise).
* **Reproduction:** `python -m albionverify run --dut ctl_mbox256 --module control.cocotb_mailbox --testcase unaligned_probe --seed 1`.
  Carried as `known_defect:CTL-001` (reports `XFAIL`; becomes `XPASS`, a failure, if the RTL is fixed).

## CTL-D1  documentation gaps around the ROM mailbox protocol (low)

* `HW_SW_INTERFACE.md` section 2 does not give the format of `F2H_MSG0`; it reads as if `F2H_MSG0` would be 0 for OK. The ROM answers `status | cmd << 8`
  (`0x100` for an accepted image, `0x201` BUSY to PING, `0x102` BAD_CMD); that format is documented only in `06_FIRMWARE.md` section 4.
* After a failed device-memory boot the ROM falls back to host loading as documented, but first posts an unsolicited BAD_CMD message with a doorbell, which `03_BOOT.md`
  does not mention: a host must `F2H_ACK` it before sending IMAGE_READY. (The bench initially mis-read this as a ROM defect; that reading was retracted.)

## Open questions (the model takes the interpretation in brackets)

Q-1 a reset request arriving during the 16-cycle pulse [merged: cause not recorded or counted]; Q-2 unaligned offsets [refused]; Q-3 blank reset column in MEMORY_MAP [0];
Q-4 reads of write-only registers [refused]; Q-5 `TEST_CTRL[29:16]` stored but undocumented [not compared]; Q-6 `FIRST_ADDR`/`LAST_ADDR` after injection or `CLEAR_FIRST` [not compared].

## Consistency check

No mismatch between `MEMORY_MAP.md`, the bench's hand-transcribed map (`ctl_spec.py`) and the generated header `cc_memmap_defs.svh` (22 checks).

## Observation

A `SOFT_RESET` write resets the core within its own transaction, so its response never arrives. This matches `09_LIMITATIONS` and SFB2 R11; the bench cancels that transaction explicitly.

## Verification limits

* **Counter saturation at 2^32-1** (`SLEEP_CYC`, `GATED_CYC`, `cc_perf` counters, RAS counters, `VIOL_COUNT`) and the 64-bit cycle-counter carry are not reachable in bounded simulation, and internal state cannot be forced (see `docs/FRAMEWORK.md`).
  The four mutants that remove saturation (`CP-15`, `CR-22`, `CF-15`, `CT-25`) are therefore classified `UNOBSERVABLE_SURVIVED` -- **not** proven equivalent -- and count against the mutation score.
* Boot stages `ACC_DISCOVERY`, `SELF_TEST`, `SHUTDOWN`, `FATAL` are set only by firmware that is not in the pinned RTL (functional-coverage holes).
* Not verified: real accelerators, CPU ISA, timer and DMA IP, real firmware; external-port isolation, the DMA-error to RAS path, parity injection through real memory reads; `test_mode`; reserved boot modes 2/3 (undefined in the docs).
* The boot payload words in `tests/control/ctl_fw.py` come from `ctl_fw.S` (re-assembled and compared by `test_model_fw.py` only when `llvm-mc`/`ld.lld` are installed).
