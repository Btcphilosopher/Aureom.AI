# Findings: DataFabric (block C)

Source: DataFabric bench worker report; DF-F1 was **independently re-verified by the lead** from the pinned RTL and by
re-running the reproduction. Numeric claims in the worker's report are not repeated here (see `reports/SUMMARY.md`).

## DF-F1  `sfb_crossbar` does not gate `req_ready` during reset (spec/RTL discrepancy, low severity)

* **Spec clause:** `PROTOCOL.md` R11: "During reset `req_ready`/`rsp_valid` of the fabric are 0, so reset can generate no transfer."
* **RTL:** `sfb_crossbar.sv`: `e_req_valid[m] = m_req_valid[m] && m_free[m] && !dec_hit[m]`; `m_req_ready[m] = e_req_valid[m] && e_req_ready[m]`;
  `sfb_error_slave.sv`: `req_ready = !pend_q || rsp_ready`. During reset `out_q = 0` (so `m_free = 1`) and `pend_q = 0`
  (so `req_ready = 1`): no term depends on `rst_n`.
* **Effect:** a master presenting a request while reset is asserted sees `m_req_ready = 1` every reset cycle for decode-error
  requests, and for slave-routed requests whenever the slave's ready is high. The bench found no corruption of fabric state
  (junk on all inputs during reset leaves the fabric clean and in lockstep after release), so this matters only if a master is
  **not** in the same reset domain as the fabric (e.g. a debug master): R11's sentence holds only under the premise that every
  master is in reset too.
* **Needed from the RTL owner:** either amend R11 to state that premise, or gate `m_req_ready` / `s_req_valid` with a
  synchronised reset.
* **Reproduction:** `python -m albionverify run --dut xbar_3x3_rr --module fabric.cocotb_xbar_known --seed 1`
  (fails with "R11: req_ready of the fabric was high in 8 of 8 reset cycles while master 0 presented a request").
  Carried as `known_defect:DF-F1` in the suite, so it reports `XFAIL`; if the RTL or spec is changed it becomes `XPASS` (a failure) and the tag must be removed.

## Other results

No other RTL defect found. Eight specification ambiguities and the interpretation used for each are in `docs/fabric_verification_plan.md`
section 8 (notably: RR pointer 0 and lock clear after reset; `ev_arb_loss` means another master holds the grant whether or not the slave can accept; overlapping regions resolve to the lowest permitted slave).

## Mutant history (test-gap closure)

An earlier mutation run left `FX-44` (round-robin pointer also advancing on stall) alive: a stalled grant is locked, so the pointer is rewritten
with the same value at acceptance; it only differs when the locked master withdraws. This was a real gap in the tests, closed by the
directed test `lock_withdraw_pointer`. `FX-53` / `FA-13` (lock flag not reset) are annotated equivalent: after reset the lock index and pointer are both 0, so a stale lock can only select requester 0, which wins normal arbitration from pointer 0 anyway.

## Not verified

R3 and the combinational-path claims (not observable with cycle-driven agents); non-compliant slaves (unsolicited responses, non-zero rdata with error);
timing/PPA/gate level; bursts/lengths/IDs (do not exist in SFB2 rev 2.0); DMA, SRAM adapters, `sfb_shared_bus`, `sfb_perf_counters`, `sfb_v1_slave_adapter`.
