# DMA verification plan (subsystem B: `silicaflux_dma`, `hpc_dma_adapter`)

Specification used (the models were written from these, not from the RTL):
`rtl/datafabric/docs/datafabric/DMA.md`, `PROTOCOL.md` (SFB2 R1-R12), `MEMORY_MAP.md` (DMA register page 6),
`rtl/hpc_m05_dma_adapter/docs/01..03` (descriptor-driven adapter).

Files: `albionverify/models/dma_spec.py`, `dma_model.py`, `dma_adapter_model.py` (independent models);
`tests/dma/` (benches, suites, pytest model tests `test_model_*.py`); `mutants/dma_simple.yaml`, `dma_buffered.yaml`,
`dma_adapter.yaml`; results and numbers: `docs/findings_dma.md` and the run reports under `reports/`.

## 1. DUT configurations

| Config (`dma_*`) | Top | What it adds |
|---|---|---|
| `dma_simple` | `silicaflux_dma` ENGINE=0, DW=32, PERF=1 | production candidate, 1 transaction in flight |
| `dma_simple_w64` | ENGINE=0, DW=64, PERF=0 | wide data, perf registers absent (must answer with a bus error) |
| `dma_buf_sp` | ENGINE=1 single port, FIFO 4, BURST 2, MAX_OUT 2 | phases, credit, outstanding limit |
| `dma_buf_sp_b4` | single port, FIFO 8, BURST 4, MAX_OUT 3 | longer bursts, 3 outstanding |
| `dma_buf_dp` | dual port (NP=2), FIFO 4, BURST 4, MAX_OUT 2 | concurrent read/write ports |
| `dma_buf_dp_w64` | dual port, DW=64, FIFO 8, MAX_OUT 3 | |
| `dma_buf_min` | single port, FIFO 2, BURST 1, MAX_OUT 1 | smallest legal buffered engine |
| `dma_buf_dp_min128` | dual port, DW=128, FIFO 2, BURST 2, MAX_OUT 1 | widest data, minimum depth |
| `dma_adapter_simple` / `_dp` / `_sp64` | `hpc_dma_adapter` (simple; dual port + FAB_SLICE; DW=64 single port, CNT_W=8, CMD_DEPTH=0) | scratchpad window + DataFabric target, REGION rule |

`MAX_LEN_LOG2 = 8` everywhere (256-byte maximum) so maximum-length and just-over-maximum transfers are cheap.

## 2. Bench architecture

* **Reference model** (`dma_model.py`) is *observation driven*: the bench feeds it, edge by edge, what is visible on
  the pins (register accesses, SFB2 handshakes, `busy`, `irq`, `bytes_done`, `fifo_level`, `ev_done`).  It predicts
  every register read, every `rb_err`, the legality of every bus transaction (address, strobe, data == data of the same
  beat's read, order, credit, outstanding limits, burst phases, dual-port direction, stop rules after errors / abort) and
  the final outcome (DONE / ERROR + ERROR_CODE + ERROR_ADDR + BYTES_DONE contiguous prefix).  The *cycle* at which a
  transfer ends is a DUT choice (spec gives none); it is taken from the `busy` pin and validated (not before the work is
  done, not more than 24 cycles after the last bus activity, BUSY rises with START, falls on the same edge DONE/ERROR rises).
* **Observer** (`tests/dma/dma_tb.py::DmaObserver`) turns every edge into an `Edge` record (one-edge lag so a terminal edge
  is known), runs the **byte-exact memory image check** at every end of transfer (destination == pre-transfer image except
  the bytes of acknowledged beats; source untouched; bytes after LENGTH inside the last word untouched; with
  `write_uncertain` semantics at reset), checks `rb_err == 0` when `rb_sel == 0`, quiet pins during reset, and
  `rsp_ready` never low while a response is valid.  `ReqRspMonitor` adds SFB2 R2/R4/R5/R6/R8 per port.
* **Stimulus**: `RegBusMaster` (queued back-to-back ops, random gaps, idle garbage on `rb_we/addr/wdata`), `ReqRspSlave`
  memories (`BackingStore`, random latency, request-ready stalls, response stalls, error injection by address),
  `Triggers` (register op queued at an exact cycle relative to START / bus events), `RegNoise` (background register
  traffic incl. refused writes while a long transfer runs), `ResetSequencer` (sync pulses, state-triggered, async mid-cycle).
* **Adapter** (`dma_adapter_tb.py`): descriptor driver, completion sink, one SFB2 memory (`fab_*`) and one scratchpad
  requester-port memory (`spm_*`, tags echoed, optional tag corruption).  The beat-level rules come from
  `dma_model.Transfer(strict=False)` (rules that need the engine-side port timing are skipped behind the router / slices);
  `dma_adapter_model.py` adds the REGION rule and target routing.

## 3. What is checked (spec clause -> check)

| Spec | Check |
|---|---|
| DMA.md sec. 1 programming sequence; BUSY/DONE/ERROR same-edge rule | model: BUSY pin rises with START, falls on the edge DONE/ERROR rise; STATUS polled every cycle (`status_poll`) |
| sec. 2 validation, first failing rule wins | `validation_matrix`: hand table of every rule/pair + cross product vs `dma_spec.validate`; no bus access on a failing descriptor |
| sec. 2 byte-accurate lengths, partial last word strobe | `length_sweep` (1 .. 3*DW/8+1, burst/FIFO/MAX_OUT boundaries, top of address space); strobe checked per beat and byte-exact image |
| sec. 3 busy-state protection | `busy_protection`, `busy_and_terminal_edge`, `RegNoise` hammering; refusal == `rb_err`, no state change, START|ABORT refused as a whole |
| sec. 4 simple engine: one in flight, alternation, read error -> no write, write error -> no further request, BYTES_DONE prefix | `Transfer.on_req/on_rsp` strict rules |
| sec. 4 abort at the next beat boundary, DONE if it races the final beat | `abort_sweep` (every cycle offset incl. VALIDATE, last-beat race, idle, START|ABORT) |
| sec. 5 buffered engine: credit, MAX_OUT, phases of <= BURST, dual port, beats before a read error still written, <= MAX_OUT-1 later beats after a write error | strict `Transfer` rules, `fifo_level` pin, `bus_errors` |
| sec. 6 interrupts (set wins over W1C, level irq) | `interrupts`, W1C swept across the terminal edge |
| sec. 7 performance registers, PERF=0 -> bus error | `perf_counters`, model counters, `dma_simple_w64` |
| MEMORY_MAP reset values / access / unmapped offsets | `reset_values_and_access` (full 4 KiB offset sweep), reset sweeps |
| PROTOCOL R2/R4/R5/R6/R8, R7, R11 | `ReqRspMonitor`, model, `reset_*` tests |
| adapter doc 02/03: REGION rule, precedence, err_addr; completion = writes acknowledged; one completion per descriptor in order with tag; busy; abort; reset | `dma_adapter_tb` + `cocotb_dma_adapter` |

## 4. Interpretations of spec points that are not fully determined (open questions)

* **I1** ERROR_CODE / ERROR_ADDR describe the last transfer: they read 0 after START, and ERROR_ADDR is 0 for non-bus errors
  (spec: "cause of the last error" / "bus address of the failing access"). Not checked while BUSY.
* **I2** BYTES_DONE is exact at every cycle: it includes a write acknowledgement from the cycle after its response edge on,
  and is cleared by START.
* **I3** CONTROL is write-only: reads return 0 without error.
* **I4 (abort timing)** "next beat boundary" = next transaction boundary. An ABORT accepted at edge Ta lets every request that
  is presented (or outstanding) at Ta complete; no *new* request may be presented afterwards. If the ABORT lands on the very
  edge of a response, ONE further request is tolerated (same-edge race: the RTL defers the abort by one transaction there);
  with nothing presented/outstanding (VALIDATE, phase gap) the abort stops immediately. A bus-error response wins over
  ABORTED; a validation code wins over an abort written in VALIDATE.
* **I5** `ACTIVE_CYCLES` = BUSY cycles of the current/last transfer seen strictly before the read cycle; `STALL_CYCLES` counts
  cycles in which *any* port presents a request that is not accepted (once per cycle, not per port); `TRANSFERS` counts DONE only.
* **I6** `STATUS.STATE` of the buffered engine: dual port shows ISSUE_READ or ISSUE_WRITE, single port the phase (decided by the
  presented/outstanding request type).
* **I7** Dual port: if a read error and a write error are reported on the same edge, either code is legal (then pinned).
* **I8** Unmapped = every 12-bit offset not in the table, including non word-aligned ones; `rb_err` must be 0 when `rb_sel` = 0.
* **I9** `fifo_level` = read responses OK - writes accepted (checked on error-free transfers).
* **I10** 24 cycles with nothing presented/outstanding is the bound after which "no completion" is a failure (spec has no watchdog).
* **I11** (adapter) a REGION error whose source and destination (or a spanning range) cross different edges may report either edge.

## 5. Coverage

Functional coverage groups (`tests/dma/dma_tb.py::make_coverage`, `dma_adapter_tb.py::make_coverage`): descriptor classes x
outcomes, range relations (disjoint/adjacent/overlap/same/overflow/ends at 2^32), bus-error kind x beat position, abort timing x
outcome, register x op x busy x error, interrupts, request-stall and response-latency bins, outstanding/FIFO/burst depth, dual-port
concurrency, reset-in-state, perf registers; adapter: direction x outcome, REGION kinds, queue pressure, target stalls, reset state.
Holes are listed in `docs/findings_dma.md`; code coverage is collected by the framework (`regress --coverage`).

## 6. Not verified / limits

* 32-bit wrap of `ACTIVE_CYCLES` / `STALL_CYCLES` / `TRANSFERS` (needs 2^32 cycles) and `MAX_LEN_LOG2 = 24` sizes (16 MiB transfers);
  only `MAX_LEN_LOG2 = 8` is built.
* No timeout watchdog exists (spec): a slave that never answers is not a tested scenario.
* Competing masters: the DMA has one master port; contention is modelled as request-ready stalls and response latency, not as
  other masters on a crossbar (the crossbar is verified by the fabric bench).
* Integration with `sfv_soc_df` / firmware, peripheral-window denial (access matrix) and the real SRAM slaves are out of scope.
* Adapter: the scratchpad (Module 04) itself, the vector array and FAB_SLICE internals are not verified here; `strict=False` skips the
  engine-side timing rules behind the router.
* `rsp_rdata` on error responses inside the adapter (router -> engine) is not observable at the adapter boundary.

## 7. Findings (the bench guide asks for `docs/findings_dma.md`; the file write was refused by the harness, so the content lives here)

**RTL defects: none found.**  All configurations pass (numbers in sec. 8); no `known_defect` annotation exists.

Specification questions (interpretations I1..I11 above; the RTL agrees with each of them):

| # | Spec text | Open question | Interpretation used |
|---|---|---|---|
| Q1 | DMA.md sec. 4 "abort ... takes effect at the next beat boundary, after the outstanding transaction's response" | ABORT accepted on the very edge a response is accepted? | One further transaction may start (RTL latches the abort at that edge and acts at the next boundary); the strict reading "immediately" is also possible. Model tolerates exactly one new request in this race, none otherwise (coverage bin `same_edge_as_response`). |
| Q2 | DMA.md sec. 4/6 | Precedence of ABORTED vs bus error vs validation code | bus error wins over ABORTED; validation code wins over an abort written in VALIDATE |
| Q3 | MEMORY_MAP ERROR_CODE / ERROR_ADDR | Value after a successful transfer, for non-bus errors, while BUSY | cleared by START, ERROR_ADDR 0 for non-bus errors, not checked while BUSY |
| Q4 | MEMORY_MAP CONTROL `wo` | read value | 0, no error |
| Q5 | DMA.md sec. 7 | STALL_CYCLES with two ports; what TRANSFERS counts | once per cycle (any port waiting); DONE only |
| Q6 | DMA.md sec. 5 STATUS.STATE | state of a dual-port engine / during a phase gap | either ISSUE state; with a request presented/outstanding it must match its type |
| Q7 | MEMORY_MAP unmapped | non word-aligned offsets | unmapped (error) |
| Q8 | adapter doc 02 REGION `cpl_err_addr` | boundary when both ranges / a spanning range cross | either legal edge accepted |
| Q9 | adapter doc 01 `eng_bytes_done` "live" | value between transfers | previous result until the next START; never ahead of the acknowledged bytes |

Observations: reads are always full words (strobe of reads is don't-care, SFB2 R10); the buffered engine drops buffered-but-unwritten beats on ABORT and the simple engine drops the
data of a read that completes after the abort (consistent with the spec, not stated explicitly).

## 8. Results (commands actually run on the final tests; reports under `reports/`)

| Item | Result |
|---|---|
| pytest model tests: `python -m pytest tests/dma -q` | 74 passed (spec examples, edge traces, error/abort/interrupt/buffered rules, adapter REGION rule) |
| `python -m albionverify regress --suite dma_simple dma_buffered dma_adapter -j 2` | 94 runs (17 + 50 + 27), 94 PASS, 0 FAIL, 1,947,076 checks |
| functional coverage of that regression | 100.0 % of 2357 applicable bins (bins that cannot exist for a configuration are not defined for it) |
| `determinism --suite dma_simple` / `dma_buffered` / `dma_adapter` | 8 / 24 / 18 runs executed twice, 0 mismatches |
| `mutate --suite dma_simple` | 45 mutants, 45 killed (45 by CHECK), 0 survivors, 0 invalid |
| `mutate --suite dma_buffered` | 30 mutants, 30 killed (29 CHECK, 1 CRASH: DB-01 FIFO credit, the RTL `$error` in `dma_fifo` fires first), 0 survivors |
| `mutate --suite dma_adapter` | 26 mutants, 24 killed (22 CHECK, 2 CRASH/LIVENESS: DA-07 queue overflow `$error`, DA-16 router ready), 2 equivalent (DA-25 target-switch hold, DA-26 router outstanding bound: unreachable through the engines, argument in the YAML), 0 survivors |
| model proven able to fail | `dma_spec.beat_strobe` temporarily changed (strobe one byte too wide): `length_sweep` failed at edge 16 with "write beat 0 strobe 0x1, expected 0x3"; restored, pytest green |
| RTL pins | `vendor-check`: 253 files, 0 problems |

Mutant classes: byte enables / tail strobe, length and boundary off-by-one, burst and FIFO counting, FIFO order / clear, credit and
outstanding limits, error codes and ERROR_ADDR, BYTES_DONE prefix rule, abort (not latched, lost in VALIDATE, race with the last beat,
not stopping the issuers), validation precedence and boundaries, busy protection (data, rb_err, START, START|ABORT), interrupt
set/clear priority, enables, bit order, STATUS bits / BUSY same-edge rule, performance counters (3 registers, clear, PERF=0), INFO,
reset (state, request, FIFO), dual-port response mapping, phase switching, completion early, REGION boundaries / precedence / reported
edge, completion queue and descriptor queue capacity, tag ownership checks, perf event counting and saturation.
