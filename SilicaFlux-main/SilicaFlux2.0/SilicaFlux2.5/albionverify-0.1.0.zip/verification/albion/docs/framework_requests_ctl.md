# Framework requests from subsystem E (control)

None of these blocks the control bench (each has a workaround inside `tests/control/`); they would make the next bench simpler.

1. **`ResetSequencer.async_pulse` consumes a clock edge.**  It does `await RisingEdge(clk)` itself, so when it is called from a test that
   otherwise advances with `env.tick()` the agents skip one `sample()/drive()` and the DUT sees the same inputs twice (lockstep models
   desynchronise).  Workaround: `tests/control/ctl_bench.py::async_reset_midcycle` (call it right after a `tick()`; it does the
   `Timer(phase)` and the same bookkeeping).  Minimal patch: split `async_pulse` into `await next_edge` + `assert_now(phase_ns, length)`
   and document that tick-driven tests call only the latter, or add an optional `consume_edge: bool = True` argument.
2. **No white-box access for saturating counters.**  `SLEEP_CYC`, `GATED_CYC`, `cc_perf` counters, RAS counters and `VIOL_COUNT` saturate at
   2^32-1 (documented); the rule cannot be reached in simulation.  Request: an optional `DutSpec.build_args` (or `public=True` ->
   `--public-flat-rw`) so a bench can deposit a value into an internal register through VPI for a few designated counters.
3. **Cancelling in-flight transactions on a DUT-internal reset.**  `ReqRspMaster` / `ReqRspMonitor` are cancelled only by
   `env.notify_reset()` (which the `ResetSequencer` calls).  A reset generated inside the DUT (soft / watchdog / host-request reset of the
   ControlCore) loses the response of an in-flight host access (documented, SFB2 R11); the bench calls `master.on_reset(True)` /
   `monitor.on_reset(True)` by hand (`cocotb_core.py::soft_reset`).  Request: an `env.notify_internal_reset(agents)` helper.
