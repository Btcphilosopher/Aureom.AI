# Findings: vector and tensor engines (block D)

Source: compute bench worker report; the output-stationary point (D-SPEC-01) was re-verified by the lead against the pinned docs and RTL.
Numeric claims from the report are not repeated here (see `reports/SUMMARY.md`).

## RTL defects

None found in `hpc_vector_lane`, `hpc_vector_array` or `tensor_systolic_array`. No `known_defect` tags.

## Documentation / specification observations

| id | observation | resolution used |
|---|---|---|
| D-SPEC-01 | `tensor_systolic_array` is **output-stationary** (A moves east, B moves south, PE(i,j) owns C[i][j]; "Not weight-stationary" in `rtl/tensorcore02/README.md`, `docs/ARCHITECTURE.md` and the RTL header). The repository's Albion tooling config (`albion_forge`, `tensor.toml`) and the task wording call it "weight-stationary". | the model follows the module's own docs and RTL header; the other wording is a documentation inconsistency to correct upstream |
| D-SPEC-02 | the Module 02 vector-lane docs that the array docs cite are not vendored | lane policy (rounding, special values, flags) taken from the array docs, RTL header comments and IEEE-754/RISC-V; each interpretation is tabulated in `docs/vec_verification_plan.md` and the RTL matches all of them |
| D-SPEC-03 | docs do not say what an illegal reduction emits | assumed no result beats and `cpl_red=1`; the RTL does exactly that |
| D-SPEC-04 | tensor `m_row/m_data/m_col_mask/m_last` are specified only together with `m_valid`, and `s_k` only in RUN | checked only there |

## Documented limits (not defects)

* FP32 unfused reduction is reproducible only for a given `NUM_LANES` (association order depends on the lane count).
* Tensor accumulation wraps at `ACC_WIDTH`.
* The adder's exponent-difference >= 27 sticky collapse is conservative.

## Verification limits

* **D-LIM-01:** the capability of the `align_err` detector is not verified. `align_err` cannot assert through the ports of a healthy array and
  Verilator/cocotb cannot force internal nets (a minimal deposit test also failed to persist; see `docs/FRAMEWORK.md`). Mutants `TM-36` and `TM-37`
  survive for this reason. They are **not proven equivalent**: in the mutation reports they are classified `UNOBSERVABLE_SURVIVED` and count against the score.
* **D-LIM-02:** "no combinational input-to-output path" is structural and not provable with a cycle-based bench.
* **D-LIM-03:** performance counters `STALL_LANE`, `STALL_TRK`, `LANE_STALL`, `OPND_STARVE`, `COLL_WAIT`, `RED_WAIT` are checked for monotonicity, reset and clear only.
* Not verified: formal, gate level, timing; `ACC_WIDTH=32` wrap (needs K = 131072); `TID_W` other than 8; TestFloat-scale exhaustive FP coverage.

## Mutants annotated equivalent (with written argument in the YAML)

`VL-07` (adder sticky-collapse threshold 26 vs 27: guard/sticky bits identical at exponent difference 26 for add and subtract),
`VA-49` (tree-adder operands swapped: IEEE add is commutative bit-for-bit), `TM-21` (readout not masking columns outside N: inactive PEs always read 0),
`TM-41` (skew not flushed at launch: the skew network is already empty at tile end).
