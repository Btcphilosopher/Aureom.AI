# Framework requests from the DataFabric bench (subsystem C)

None of these blocks the bench; every item has a workaround inside `tests/fabric/` (no framework file was edited).

## FR-F1  `ResetSequencer.async_pulse`: simulator-precision error for arbitrary `phase_ns`  (RESOLVED in the framework since this was written: integer-ps `Timer`)

**What.**  `await Timer(phase_ns, units="ns")` raises `ValueError: Unable to accurately represent 3.1399999999999997(ns)
with the simulator precision of 1e-12` for floats that are not exactly representable (seen with `3.14` computed as
`t1 + dt`, and with `round(x, 2)` values such as `2.03`).  A random phase (the natural use of the function) fails
intermittently.
**Why it matters.**  Mid-cycle async reset tests would fail on some seeds for a reason unrelated to the DUT.
**Minimal patch** (`albionverify/reset.py`, `async_pulse`):
```python
await Timer(int(round(phase_ns * 1000)), units="ps")
```
**Workaround used.**  The bench only passes multiples of 0.5 ns (`rng.randint(2, 18) / 2.0`), which are exactly representable.

## FR-F2  `async_pulse` must be started concurrently (document, or make it self-contained)  (RESOLVED: docstring and FRAMEWORK.md sec. 3 item 7 now say so)

**What.**  `async_pulse` does `await RisingEdge(clk)` itself and does not call `Env.step()`.  If a test simply awaits it
between `env.tick()` calls, one clock edge passes without the agents' `sample()/drive()` (handshakes at that edge are
invisible to every agent) while the DUT advances.  It is only correct when launched with `cocotb.start_soon(...)` next to
the test's own tick loop (then both coroutines wake at the same edge).
**Why it matters.**  Easy to misuse; the failure mode is a silent agent/DUT desynchronisation.
**Minimal patch.**  Document "start with `cocotb.start_soon`" in the docstring and in FRAMEWORK.md sec. 3 item 7.
**Workaround used.**  `cocotb.start_soon(rst.async_pulse(...))` from a loop that ticks the environment (see
`tests/fabric/cocotb_xbar_reset.py`).

## FR-F3  Sub-cycle ("glitch") reset helper  (RESOLVED: `ResetSequencer.glitch` exists now; this bench keeps its own equivalent `_glitch` helpers, which also set the sequencer's `asserted` flag, so its recorded results stay as run)

**What.**  A reset pulse that starts and ends between two clock edges is the only stimulus that distinguishes an
asynchronous-reset flop from a synchronous-reset flop (any pulse that spans an edge resets both).  There is no helper;
the bench implements it (`_glitch` in `cocotb_xbar_reset.py`, `cocotb_regslice.py`, `cocotb_arbiter.py`,
`cocotb_cells.py`): assert at +t1 ns, `Env.notify_reset(True)`, drive every peer agent's reset-state values (peers in the
shared reset domain lose their outputs asynchronously too), flush, release at +t2 ns, `Env.notify_reset(False)`.
**Minimal patch.**  `ResetSequencer.glitch(t_assert_ns, t_release_ns, peers=())` doing exactly that.

## FR-F4  Mutation engine builds mutants for DUTs without mutation cases

**What.**  `run_one_mutant` loops over `_affected_duts(...)` = every DUT of the suite (regression cases + mutation cases)
whose closure contains the patched file and builds the mutant for each of them in turn until a test fails, even when the
DUT has no entry in `mutation_cases` (the loop then builds and runs nothing).  With a suite that has many configurations
but a small mutation subset, every survivor costs one useless Verilator build per extra configuration (25-60 s each).
**Minimal patch** (`mutate/engine.py`): in `_affected_duts` keep only DUTs that appear in `suite.mutation_set()`:
```python
want = {c.dut.name for c in suite.mutation_set()}
...  if d.name not in want: continue
```
**Workaround used.**  Configurations that carry mutation cases are listed first in the suite, and mutants that can only
differ on one configuration use `dut:`.

## FR-F5  Functional coverage is merged across DUT configurations

**What.**  `regress` merges every `*.func_cov.json` of a suite by group name.  Coverage points whose bins depend on the
configuration (e.g. `fab_txn` cross bins per master/slave, `fab_arb` contention counts, `fab_addr` region bins) are unioned,
so a bin that exists only for the 4x7 SoC configuration appears as a hole in every other configuration's contribution and
the merged percentage mixes unreachable bins with real holes.
**Minimal patch.**  Group the merge by `(dut name, group)` in `report/coverage.py` and print one table per DUT.
**Workaround used.**  `regress --only <dut>` with its own `--label` gives a per-configuration report (the numbers in the
lead report are per configuration).

## FR-F6  `ReqRspSlave` cannot show accept-while-retiring with `max_pending = 1`

**What.**  A cycle-driven slave agent decides `req_ready` for the next cycle at the clock edge, so a slave with
`max_pending = 1` is never ready in the cycle in which its own response is accepted; behind the crossbar that costs one
bubble per transaction and hides the crossbar's full-throughput (R6) behaviour.
**Workaround used.**  `max_pending = 2` for every slave of the crossbar bench (the crossbar itself never presents a
second request, which the slave-port monitors verify with `outstanding_limit = 1`).  Suggest documenting this in
FRAMEWORK.md sec. 3.
