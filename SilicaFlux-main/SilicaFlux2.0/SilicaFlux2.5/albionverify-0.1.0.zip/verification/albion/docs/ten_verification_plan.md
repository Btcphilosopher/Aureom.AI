# Subsystem D (tensor engine) -- verification plan

Scope: `tensor_systolic_array` of `rtl/tensorcore02` (suite `ten_array`).
Bench: `tests/compute/cocotb_ten_array.py`, agents `ten_agents.py`, registry `suite.py`.
Model: `albionverify/models/ten_matmul.py`, unit tests `tests/compute/test_model_ten_matmul.py`.
Mutants: `mutants/ten_array.yaml`.  Findings: reported inline in the worker's final report (the harness did not allow this worker to write `docs/findings_compute.md`; the lead is asked to save that text there).

## 1. Specification used, and the "weight-stationary" discrepancy

Written from `rtl/tensorcore02/README.md` and `docs/ARCHITECTURE.md`, `CONFIGURATION.md`, `PERFORMANCE.md`.

**The brief calls the array weight-stationary; the documentation (and RTL header) say the opposite:** *"This is NOT a
weight-stationary design: no operand is preloaded into or held by a PE ... output-stationary, PE(i,j) computes C[i][j]"*.
The model follows the documentation.  At the ports the two descriptions differ only in timing, which the documentation fixes
exactly (below) and which the bench checks cycle by cycle; there is no weight-load phase to verify.

Function: `C[M,N] = A[M,K] x B[K,N]`, signed DATA_WIDTH operands, signed ACC_WIDTH accumulation that **wraps** modulo 2^ACC_WIDTH
(no saturation, no overflow flag).  One tile per launch (`cfg_valid / cfg_ready / cfg_m / cfg_n / cfg_k`); K is streamed as
k-slices (`s_a` lane i = A[i][k], `s_b` lane j = B[k][j]); results come out as M rows (`m_row`, `m_data` lane j = C[row][j], lanes >= N
read 0, `m_col_mask`, `m_last`), `tile_done` is a level during READOUT.

Timing (ARCHITECTURE.md 7, h = cycle of the launch handshake): h+1 CLEAR, RUN from h+2 (a slice is accepted in every cycle with
`s_valid & ~stall_i`), then DRAIN until every active PE has committed its last product, then READOUT.  Needed enabled DRAIN
steps = M + N - 1 + MUL_PIPE (the last fire is at step K+M+N-2 while the last slice is accepted at step K-1); the cycle after
the last needed step is still DRAIN (`all_done` visible) and moves to READOUT unconditionally.  Hence
`tile_done` at `h + 2 + K + M + N + MUL_PIPE` and `busy = 1 + K + M + N + MUL_PIPE + stall_up + stall_ext` (matches every
number of PERFORMANCE.md sections 2, 4, 5, 6 -- reproduced in `test_model_ten_matmul.py`).

### Interpretations

| # | Question | Interpretation | RTL agrees? |
|---|---|---|---|
| 1 | m_row / m_data / m_col_mask / m_last outside READOUT | unspecified (only specified with `m_valid`): checked only while `m_valid = 1`, plus payload stability while `m_valid && !m_ready`. | yes |
| 2 | `s_k` | "index of the slice expected next": checked in RUN only. | yes |
| 3 | `cfg` offered while busy | ignored, **no reject pulse** (`cfg_reject` only for `cfg_valid & cfg_ready & illegal`); checked with legal-looking and illegal shapes in every busy state. | yes |
| 4 | `cfg_reject` | single-cycle pulse one cycle after an illegal launch was offered while IDLE, array unchanged; K = 0 rejected. | yes |
| 5 | Counters | cleared at launch (and reset), frozen from READOUT; `perf_stall_ext` counts only *effective* stalls (a stall in the `all_done` cycle delays nothing and is not counted); `perf_mac` is predicted per cycle from the documented PE commit schedule `k + 1 + i + j + MUL_PIPE`. All six are compared **every cycle**. | yes |
| 6 | Reset | synchronous active-low; the registered state clears at the edge that samples `rst_n = 0`; every producer drives garbage with `valid` toggling during reset ("sync reset has priority"). | yes |
| 7 | `align_err` | never asserts for a legal stream (checked 0 in every cycle). It can only be provoked by a fault (the vendor uses an Icarus-only `force`), which Verilator / cocotb cannot do: see "not verified". | -- |

## 2. Bench architecture

`TileModel` is a lock-step, cycle-accurate model of everything observable at the ports (cfg_ready, cfg_reject, s_ready, s_k,
busy, tile_done, m_valid / m_row / m_data / m_col_mask / m_last, align_err = 0, the six counters), advanced each cycle with
exactly the inputs the DUT saw.  Data are computed by the model from the **accepted** slices (so duplicated / dropped / misordered
slices show) and, at tile end, the collected rows are compared with an independent integer GEMM of the *intended* operands
(`matmul`, pure Python; numpy int64 cross-check in the model tests).

Agents: `CfgDriver` (`hold` and `pulse` items), `SliceDriver` (Throttle valid gaps; spurious garbage `valid` outside RUN),
`StallDriver` (random / bursty / periodic and model-aware modes: fill, drain, last slice, the all_done cycle, edges),
`MReadySink`, `TenMonitor` (lock-step + ledger + coverage).  Lanes beyond M / N carry random garbage on purpose (must be ignored).

## 3. Configurations and tests

`ten_2x2_acc16` (MUL_PIPE 0, ACC 16 so two (-128)^2 products wrap, K <= 255, 2-bit cfg_m / cfg_n so M = 3 / N = 3 are *illegal*
values), `ten_3x2_mp1_acc24` (MUL_PIPE 1, non-square, ACC 24 so the wrap boundary K = 512 is reachable, K <= 1023, 2-bit cfg
fields), `ten_4x4` (documented baseline, 3-bit cfg fields so M, N = 5..7 are illegal), `ten_1x3_lean` (single row, CHECK_ALIGN = 0,
PERF_EN = 0, K <= 31).

Tests: `directed_tiles` (all (M, N) x K in {1, 2, 3, fill-1, fill, fill+1, 2 fill+1} with identity / ones / zeros / random;
asserts the documented `tile_done` cycle and busy), `extreme_values` (-128 / 127 patterns, alternating signs, first wrapping K and
its neighbours, K = K_max, negative sums / sign extension), `cfg_handshake` (illegal M = 0, M > ROWS, N = 0, N > COLS, K = 0, held
illegal cfg; cfg offered in CLEAR / RUN / DRAIN / READOUT ignored; held legal cfg accepted at the first idle cycle; back-to-back
tiles of different shapes; K = K_max), `stalls_and_backpressure` (11 `stall_i` modes x 5 s_valid x 4 m_ready profiles),
`random_tiles` (3 seeds) / `random_long`, `reset_mid_tile` (reset in IDLE, CLEAR, RUN, DRAIN, READOUT mid-rows, mid-cycle async).

## 4. Functional coverage

shape (M x N class, K class x partial), values (data kind, result sign, accumulator wrapped), cfg situations (legal, each illegal
kind, ignored while busy, shape-change class x previous shape full / partial), pressure (stall run lengths, valid-gap run lengths,
m_ready-low runs, stall_i by state incl. the `all_done` cycle and ignored states, ghost valid), reset state, counter situations.

## 5. What is NOT verified

* Simulation only (no formal / gate-level / hardware).
* **Alignment checker detection** (`align_err`) cannot be exercised through the ports of a healthy array: two mutants that
  disable it survive and are documented as unobservable (see the findings in the worker's final report / mutation report).  The absence of false alarms is
  checked in every cycle of every test, and an inverted comparison is killed.
* ACC_WIDTH = 32 wrap-around (needs K = 131072) is not run; the same adder is covered with ACC 16 / 24.
* Arrays larger than 4 x 4, DATA_WIDTH != 8, K_WIDTH = 17/18 with K = 131071, per-PE internal state (white-box wavefront
  monitor of the vendor bench is not reproduced).
* Tiling of larger matrices (host responsibility per the docs) is only exercised as back-to-back launches.

## 6. Results of the last runs

| Command | Result |
|---|---|
| `python -m pytest tests/compute -q` | 42 passed (model tests) |
| `python -m albionverify regress --suite ten_array -j 2` | 37 / 37 PASS, 3 431 041 checks, functional coverage 99.75 % of 398 bins (1 hole: 1x3 lean, s_valid gap run >= 8) |
| `python -m albionverify determinism --suite ten_array` | 27 runs executed twice, 0 mismatches |
| `python -m albionverify mutate --suite ten_array` | 52 mutants: 48 killed (all by checks), 0 survived, 4 annotated: TM-21 and TM-41 equivalent (arguments in the YAML), TM-36 and TM-37 unobservable under legal stimulus (alignment checker; see section 5) |

Model sanity: a model with one drain step too few turns the bench red at cycle 10 (`tile_done` mismatch).
