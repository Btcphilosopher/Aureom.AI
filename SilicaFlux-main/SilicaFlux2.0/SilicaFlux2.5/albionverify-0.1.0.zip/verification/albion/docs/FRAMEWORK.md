# AlbionVerify framework contract

Everything a subsystem bench relies on. All statements about simulator behaviour were **measured** on
the pinned toolchain (Verilator 5.020, cocotb 1.9.2, Python 3.13) -- see "Measured facts".

## 1. Layout

```
verification/albion/
  albionverify/            framework (do not edit from a subsystem bench)
    core.py                Env, Agent, Sig/Shadow (signal access), AlbionCheckError, LivenessError
    rng.py                 SeedRoot (deterministic streams), Throttle (stalls), Latency
    bus/reqrsp.py          ReqRspMaster / ReqRspSlave / ReqRspMonitor + SFB2 and SRAM-core port presets
    bus/regbus.py          RegBusMaster (rb_sel/we/addr/wdata -> rdata/err)
    memory.py              BackingStore (byte-accurate, uncertain-byte semantics for reset-cancelled writes)
    scoreboard.py          Scoreboard (ledger: accepted == completed + cancelled), hex diffs
    coverage.py            CoverGroup (FUNCTIONAL coverage; code coverage is separate)
    reset.py               ResetSequencer (initial, scheduled, state-triggered, mid-cycle async)
    inject.py              ErrorPolicy / Malformer (stimulus-side error injection)
    digest.py              TraceDigest (reproducibility proof)
    models/                independent reference models (pure Python, one module per block)
    sim/                   build (Verilator, cached by content key) + run (isolated subprocess) + results
    mutate/engine.py       mutation / fault-injection campaigns
    suite.py               Case / Suite registry
  rtl/                     PINNED vendored RTL + MANIFEST.json (sha256 of every file) + project docs (*.md)
  tests/<subsystem>/       cocotb benches (cocotb_*.py), suite.py (registry), pytest tests for models
  mutants/<suite>.yaml     fault-injection definitions
  reports/                 generated: regression/, mutation/, coverage/, audit/
```

## 2. Commands (run from `verification/albion`)

```
python -m albionverify list -v                       # suites, cases, seeds
python -m albionverify regress --suite NAME -j 4     # build once, run all case x seed in parallel (--only X writes its own label; --first-config-only for coverage)
python -m albionverify run --dut D --module M --testcase T --seed S [--mutant ID|suite:ID] [--waves]   # reproduce one run (mutant ids are unique per suite only; qualify when ambiguous)
python -m albionverify mutate --suite NAME -j 2      # baseline + every mutant; score + survivors
python -m albionverify determinism --suite NAME      # run twice, digests must match
python -m albionverify vendor-check                  # RTL pins intact?
```
Every failing run prints its exact reproduction command and, with waves on (default for `regress`),
leaves `reports/out/waves/<test id>.fst`.

## 3. Writing a bench

A bench is a cocotb module in `tests/<subsystem>/`, selected by `Case(dut_spec, "module.path", testcase, seeds)`
in that directory's `suite.py` (`SUITES = {...}`).  Skeleton (see `tests/framework_smoke/cocotb_xbar_smoke.py`):

```python
P = json.loads(os.environ["ALBION_PARAMS"])            # the DUT parameters the build used
@cocotb.test()
async def my_test(dut):
    seed = int(os.environ["ALBION_SEED"])               # the ONLY source of randomness
    env = Env(dut, name="blk", seed=seed)               # clk="clk" by default (Env(..., clk="clk_i"))
    rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=4))   # (active_low=False for rst_i)
    m   = env.add(ReqRspMaster("m0", sfb_port(env, "m_", 0, flat=True), rng=env.seeds.child("m0"), ...))
    env.tie("some_config_pin")                          # drive EVERY other DUT input (inputs are randomised at t=0)
    await env.start()                                   # presents idle values, verifies params, starts the clock
    await env.until(lambda: not rst.asserted, 50, "reset release")
    ...stimulus: m.write(...), m.read(...), rb.write_op(...)...
    await env.until(lambda: m.idle, 20000, "drain")     # LivenessError (not a hang) if it never completes
    scoreboard.finalize(); env.finalize()               # conservation + queued errors
    env.write_result("my_test", ...)                    # REQUIRED: writes the result json + prints ALBION_DIGEST
```

Rules every bench must follow:

1. **Cycle-driven agents.** `Env.step()` runs, after each rising edge: all `sample()`, then all `drive()`, then
   one flush of driven signals.  Agents never `await`.  Do not write DUT inputs directly (`dut.x.value = ...`),
   use `env.sig(...).write(v)` so slices of one flat vector never race.
2. **Randomness only from `env.seeds`** (`child(name)` for a fresh stream, `stream(name)` cached).  Never `random.*`,
   `hash()`, wall-clock time, `id()`.  Same seed => same stimulus => same digest.
3. **Check data, not counts.** Compare every response payload against the reference model; the Scoreboard
   ledger enforces that every accepted request completes or is *explicitly cancelled* (`sb.cancel(reason)`).
4. **Feed the digest.** Agents add events automatically; add your own `env.digest.event("kind", ...)` for
   model-level events.  Only deterministic values.
5. **Idle garbage.** Master agents drive random payload while `valid=0` (default) to catch DUTs that sample
   payload without valid.  Keep it on unless a block legitimately requires stable idle payload.
6. **Liveness.** Wait with `env.until(pred, max_cycles, what)`; never an unbounded loop.
7. **Reset tests.** Use `rst.arm(pred, length)` (reset when DUT state satisfies `pred`) and/or
   `rst.random_pulse`, `rst.async_pulse(phase_ns, cycles)` (mid-cycle async assert that spans clock edges) and
   `rst.glitch(t_assert_ns, t_release_ns, peers=agents)` (sub-cycle pulse that never spans an edge: the only stimulus
   that tells an asynchronous-reset flop from a synchronous one).  **`async_pulse` and `glitch` wait for a rising
   edge themselves and do not call `Env.step()`: start them with `cocotb.start_soon(...)` next to the test's own tick
   loop**, never `await` them between `env.tick()` calls (that swallows one edge and desynchronises the agents).  After reset, accepted but
   uncompleted writes "may or may not have happened": use `BackingStore.write_uncertain` in the model, never
   assume either outcome.
8. **Functional coverage.** Build `CoverGroup`s, sample them from monitors/scoreboard callbacks, register with
   `env.coverage.append(cg)`; `write_result` dumps them.  Required groups per block: transaction types, address
   boundaries, contention/concurrency, error states, backpressure duration (use `Throttle.max_denied_run` /
   monitor `max_req_stall`), plus block-specific ones.  Report holes honestly; do not pad coverage.
9. **Parameters.** DUT parameters wider than 32 bits are emitted as sized literals by the build layer
   (`param_literal`); pass Python ints.  See "Measured facts" for why.
10. **Posted writes / unanswered requests.** `ReqRspMaster(..., expects_response=lambda req: ...)`,
    `ReqRspMonitor(..., expects_response=...)` and `ReqRspSlave(..., posted_writes=True)` model protocols where some
    requests get no response (e.g. SRAM `WRITE_ACK=0`): such a request completes at acceptance (`txn.posted`),
    is never outstanding, and listeners receive `txn_posted`.
11. **Slave accept-while-retiring.** A cycle-driven slave decides `req_ready` for the next cycle at the edge, so a
    `ReqRspSlave(max_pending=1)` is never ready in the cycle in which its own response is accepted (one bubble per
    transaction).  Use `max_pending=2` behind a fabric that enforces one outstanding request per port (the monitor's
    `outstanding_limit=1` still proves the fabric never presents a second request) when full throughput is the property
    under test.
12. **Functional coverage is reported per DUT configuration** (`<dut>::<group>`), never merged across configurations,
    so a hit in one configuration cannot hide a hole in another.

## 4. Independence of reference models

Models live in `albionverify/models/<name>.py` (pure Python, no cocotb import, no copy of RTL logic).
They are written **from the specification documents** vendored next to the RTL (`rtl/<project>/docs/*.md`,
`README.md`) and from first principles (IEEE-754, integer arithmetic, memory semantics).  Each model has
pytest unit tests (`tests/<subsystem>/test_model_*.py`) that run without a simulator.

If RTL and model disagree: decide from the spec which is right.  Never edit a model merely to make the
RTL pass.  A confirmed RTL defect is recorded in `docs/findings_<subsystem>.md` (id, spec clause, seed,
reproduction command, waveform path) and its reproducing case gets tag `known_defect:<ID>` so it reports as
`XFAIL`; if it ever passes it reports `XPASS` (a failure) so stale annotations are removed.  A spec
ambiguity is recorded as an open question, with the interpretation the model uses.

## 5. Mutants (fault injection)

`mutants/<suite>.yaml` -- each entry is a plausible *functional* bug expressed as one or more exact-text
patches of the pinned RTL (`find` must occur `count` times, default 1).  Classes should cover the block's
spec: arbitration, routing, byte enables, boundary/off-by-one, ordering, error response, reset, flow control,
arithmetic.  The engine builds the unmutated baseline first, then each mutant, and runs the suite's
`mutation_cases` (default: first seed of each case) until one fails.  Statuses: `KILLED` (CHECK / LIVENESS /
TIMEOUT / CRASH), `SURVIVED` (a verification gap -- fix the *tests*), `BUILD_ERROR` (invalid mutant).
A survivor may be annotated `equivalent: "<reason>"` only with a written argument that the change does not
alter externally observable behaviour.  Tests must never reference mutant ids.

## 6. Measured facts (Verilator 5.020 + cocotb 1.9.2)

* A value read right after `await RisingEdge(clk)` is the **pre-edge** value (what the flops sampled);
  values written then take effect for the following cycle.  The framework's sample/drive split relies on it.
* `-G<param>=<decimal|0x..>` wider than 32 bits is **silently truncated**; sized literals (`64'h...`) work.
  `Env.verify_params` compares the elaborated parameter with the requested one (<= 32 bits only).
* **VPI reads of parameters are unreliable**: parameters *declared* wider than 32 bits (e.g. `logic [63:0] BASE`) read
  as 0 whatever their value, and 32-bit values with bit 31 set read negative.  `Env.verify_params` therefore skips
  them (listed in `env.notes['params_unverifiable']`); wide parameters must be proven behaviourally.
* Top-level inputs start random under `+verilator+rand+reset+2` (set by the runner, seeded by `ALBION_SEED`):
  tie off or drive every input before the first edge (`Env.start` drives all agents' idle values; use
  `env.tie`).  Internal registers also start random (`--x-initial unique`): reset behaviour is genuinely tested.
* cocotb's results.xml only says "Test failed with RANDOM_SEED=n"; the runner extracts the real exception
  message from the log.  Raise `AlbionCheckError` (or use `env.error` / `Scoreboard.fail`) with context.
* **White-box deposits do not work reliably**: in a minimal test a VPI deposit into a register driven by RTL logic did
  not persist (q was 2; after depositing 0xF0, q was 4 two edges later).  Saturating counters and similar
  internal state therefore cannot be forced from a bench; such rules are verified at model level or reported as
  unverified.  Fault injection into the RTL is done by the mutation engine instead.
* An `$error`/`$fatal` inside the RTL aborts Verilator before cocotb sees that edge; the mutation engine
  reports such kills as kind `ASSERT` (the RTL's own assertion fired), separate from bench `CHECK` kills.
* Icarus (12.0) lacks features needed by several SilicaFlux testbenches (e.g. `$sqrt`/real compare); it is used by
  the audit only.  cocotb benches run on Verilator.

## 7. Reproducibility chain

RTL pinned by SHA-256 (`rtl/MANIFEST.json`, checked on every build) -> build key = hash(pinned files, params,
flags, tool versions, patches) -> run = (build, module, testcase, seed) -> digest = SHA-256 of the canonical
event stream.  `albionverify determinism` runs everything twice in fresh processes and compares digests.
