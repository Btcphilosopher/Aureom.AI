# SRAM subsystem verification plan (block A)

DUTs (pinned in `rtl/`): `sram_sp` (generic backend and one FPGA-backend configuration), `sram_bank_controller`,
`hpc_scratchpad`. Specifications used for the independent models: `rtl/sramlib/docs/*.md`, `rtl/hpc_m04_scratchpad/docs/*.md`.
Models: `albionverify/models/sram_core.py`, `sram_bank.py`, `sram_spm.py` (pure Python, unit-tested in `tests/sram/test_model_*.py`).

## What is checked

Cycle-exact comparison against the models, every edge: `req_ready`, `rsp_valid`, response payload and order, ids/tags,
read data, arbitration winner, `m_stall_conflict`, event outputs, performance counters (including saturation for the scratchpad).

| suite | configurations | tests per configuration |
|---|---|---|
| `sram_sp` | data width 1/18/32/64, depth 3/50/64/100/1000, read latency 1-4, response FIFO 0/1/2/3/4/6, acked and posted writes, FPGA backend | directed read/write, all byte/bit-lane masks, invalid addresses (error, no side effect), credits/back-pressure, latency/throughput, seeded random (3 seeds), depth sweep, synchronous reset, asynchronous mid-cycle reset, power-up content, MBIST test port |
| `sram_banked` | 1x1 up to 8x2 masters x banks, RR/FIXED arbitration, LOW/HIGH bank select, word/byte addressing, read latency 1-3, FIFO depth 0/1 | map integrity, arbitration order, parallel banks, hot-word contention, isolation, error responses, per-master id order, random, synchronous and asynchronous reset |
| `sram_spm` | 1RW / 1R1W / 2RW, LOW/XOR/HIGH bank map, RR/FIXED | address map, byte strobes, bank conflicts, isolation, errors, random, two reset tests |

Bank conflicts are covered in `sram_banked` (same-bank contention vs. different-bank parallelism, arbitration fairness and bound,
data integrity under contention) and `sram_spm` (conflict events, same-row hazards).
Reset: both synchronous pulses and asynchronous mid-cycle assertion; outputs are not checked at the very first reset edge
(power-up state is random under `+verilator+rand+reset+2`).
Random stimulus is seeded; stalls on every ready; maximum-depth sweeps; malformed (out-of-range / misaligned) requests.

## Not verified

`sram_1r1w`, `sram_tdp`, MBIST march/adapter, bank-controller test port, ASIC backends, `INIT_FILE`, SRAM-library assertions
(the build does not enable `--assert`), X-propagation, formal, gate level; for `hpc_scratchpad`: `QUEUE_DEPTH>0`, byte-parity ECC,
FPGA/ASIC backends, `perf_clear`.

Open questions and interpretations: `docs/findings_sram.md`.
