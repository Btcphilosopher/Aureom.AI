# Framework change requests from the DMA bench (none blocking; all worked around inside tests/dma)

1. **`ReqRspSlave`: notify the response handshake.**
   *What*: a `rsp_accepted(slave, pending)` listener callback when `rsp_valid && rsp_ready` is seen (the request side already has `req_accepted`).
   *Why*: the DMA / adapter scoreboards need the order of error *responses* across two ports / two targets (first error wins); only the acceptance
   time of a request is reported today. Worked around with a 10-line subclass (`tests/dma/dma_adapter_tb.py::NotifySlave`).
   *Patch*: in `ReqRspSlave.sample`, before `self.pending.popleft()`: `self._notify("rsp_accepted", self.pending[0])`.

2. **Hard simulator aborts hide the failing check.** RTL `$error` assertions (e.g. `dma_fifo: push while full`) stop Verilator inside the clock edge, before cocotb
   gets the edge callback, so a protocol/credit violation that the bench flags one cycle later is reported as `CRASH` instead of `CHECK`
   (mutants DB-01, DA-07). *Request*: a build flag or runner option that turns `$error` into a counted message (`--assert` handling) so the cocotb checks run first.

3. **`CoverGroup.point(name, [])`** (a point that does not apply to a configuration) works but is reported as 100 %; a documented "n/a" bin kind would make
   config-dependent groups explicit in the merged report. Cosmetic.
