# AlbionVerify -- verification plan and requirement traceability (Module 93)

Purpose: a reusable verification environment in which the **actual SilicaFlux RTL** is checked against
**independent reference models**, with injected functional errors failing the tests and passing results
being reproducible.

## 1. How the success criterion is made checkable

| Success criterion | Mechanism | Where it is evidenced |
|---|---|---|
| Actual RTL is exercised | RTL is vendored byte-for-byte from the repository archives, pinned by SHA-256 (`rtl/MANIFEST.json`); builds refuse to start if a pinned file differs | `python -m albionverify vendor-check` |
| ...checked against *independent* models | Models live in `albionverify/models/`, are pure Python, are written from the specification documents vendored beside the RTL and from first principles (IEEE-754, integer arithmetic, memory semantics), and have their own simulator-free unit tests | `tests/*/test_model_*.py`, per-block verification plans in `docs/*_verification_plan.md` |
| Injected functional errors cause failures | Mutation engine: each mutant is an exact-text RTL patch modelling a plausible bug; baseline must pass first; a mutant is KILLED only by a test failure (classified CHECK / LIVENESS / TIMEOUT / CRASH); survivors are reported as gaps | `reports/mutation/*.md`, `docs/FRAMEWORK.md` sec. 5 |
| Passing results are reproducible | Deterministic seeded stimulus (SHA-256 seed fan-out, no global RNG), pinned RTL, content-keyed builds, per-run SHA-256 trace digest; `determinism` re-runs every suite in fresh processes and compares digests | `reports/determinism.json`, `reports/regression/*.seeds.json` |

## 2. Requirement traceability (task sections 1-7)

| Brief | Delivered | Evidence |
|---|---|---|
| 1 Existing code audit (what compiles, simulates, lacks tests, is behavioural, integrates; unexecuted tests never reported as passing) | `albionverify/audit/`: corpus walker + scanner, **executed** compile (Verilator + Icarus on dependency closures) and testbench runs with strict verdicts (`PASS` needs an explicit pass marker; `NO_VERDICT`/`NEEDS_FLOW`/`BUILD_FAIL` are never passes) | `reports/audit/AUDIT.md` + CSVs |
| 2 Reusable verification components | Drivers (`ReqRspMaster`, `RegBusMaster`), request generators (`ReqGen`), protocol + response monitors (`ReqRspMonitor`), reference scoreboards (`Scoreboard` + `BackingStore`), coverage collectors (`CoverGroup`), error injectors (`inject.py`, slave `ErrorPolicy`, `Malformer`), reset sequencers (`ResetSequencer`: initial, scheduled, state-triggered, mid-cycle async) -- SystemVerilog DUTs, cocotb + pytest benches | `albionverify/`, `docs/FRAMEWORK.md`, `tests/unit/` |
| 3 Critical modules A-E | One suite family per block; see section 3 | `tests/<block>/`, `docs/*_verification_plan.md` |
| 4 Scoreboards (every accepted request -> correct completion or defined cancellation; check data) | `Scoreboard` ledger identity `accepted == completed + cancelled` enforced at finalize; cancellations carry a reason; completions compared field-by-field with hex diff; memory models compare actual data byte-exactly, with tri-state bytes for writes cancelled by reset | `albionverify/scoreboard.py`, `memory.py`, `tests/unit/test_memory_scoreboard_coverage.py` |
| 5 Randomised verification (seeded) | Simultaneous masters, random addresses (boundary-biased `ReqGen`), random stalls (`Throttle`), reset during transactions (state-triggered and mid-cycle async), malformed requests, access-control failures, maximum-length transfers -- where the block has the concept (each plan says where it does not) | per-block suites, tags `random` / `reset` / `error` / `long` |
| 6 Coverage (functional separate from code) | Functional: `CoverGroup` bins/crosses for transaction types, address boundaries, contention, error states, backpressure duration, concurrency -> `reports/coverage/functional/`. Code: Verilator line/branch/toggle -> `reports/coverage/code/` (+ LCOV). Never merged into one number | `reports/coverage/` |
| 7 CI | `make ci` / `make ci-full`, `ci/albion-verify.yml`; machine-readable `regression_*.json`, JUnit XML, `*.seeds.json`, `*.failures.txt` (repro command + waveform path per failure), FST/VCD waveforms of failed tests, coverage summaries, `SUMMARY.md` | `reports/` |

## 3. Blocks, DUTs and sources of truth

| Block | DUTs (pinned) | Specification the models were written from |
|---|---|---|
| A SRAM subsystem | `sram_sp`, `sram_bank_controller`, `hpc_scratchpad` | `rtl/sramlib/docs`, `rtl/hpc_m04_scratchpad/docs` |
| B DMA | `silicaflux_dma` (simple + buffered engines), `hpc_dma_adapter` | `rtl/datafabric/docs/datafabric/DMA.md`, `PROTOCOL.md`, `MEMORY_MAP.md` |
| C DataFabric | `sfb_crossbar`, `sfb_arbiter`, `sfb_reg_slice` | `PROTOCOL.md` (rules R1-R12), `ARCHITECTURE.md` |
| D Vector / tensor | `hpc_vector_lane`, `hpc_vector_array`, `tensor_systolic_array` | `rtl/hpc_m03_vector_array/docs`, `rtl/tensorcore02/docs`, IEEE-754 |
| E Control | `cc_mailbox`, `cc_sysctrl`, `cc_pmu`, `cc_ras`, `cc_sfb_gate`, ... ; `silicaflux_control_core` boot (see plan) | `rtl/controlcore/docs/*.md` |

Which blocks were verified to what depth, and what was **not** verified, is stated per block in
`docs/<block>_verification_plan.md`; the consolidated numbers are in `reports/SUMMARY.md`.

## 4. Policies

* **Never fit the model to the RTL.** A disagreement is decided from the specification.  Confirmed RTL
  defects are recorded in `docs/findings_*.md` and their reproducing case carries `known_defect:<ID>` so it
  reports as `XFAIL`; an unexpected pass becomes `XPASS` (a failure) so stale annotations cannot linger.
* **Survivors are gaps, not noise.** A surviving mutant is fixed by strengthening tests; `equivalent:` needs a
  written behavioural-equivalence argument.
* **Evidence only from executed runs.** The audit's verdict policy and the regression summary both refuse to
  turn "not run" into "passed".
