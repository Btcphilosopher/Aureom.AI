# Audit method notes: bugs found by auditing the audit

The existing-code audit (`reports/audit/AUDIT.md`) reports what real tools did.  Because a wrong audit
is worse than none, its own classification logic was checked against samples of its output, and four
defects in the *audit tooling* were found and fixed before the numbers were accepted.  Each has a
regression test (`tests/unit/test_audit_*.py`).

| # | symptom | cause | fix | effect on the numbers |
|---|---|---|---|---|
| 1 | Modules importing a package at file scope (`import cpu_pkg::*;` before `module`) were reported as failing to compile | the scanner only looked for imports inside module bodies, so the closure omitted the package file | file-scope imports are attributed to every unit in the file | Verilator-lint FAIL 161 -> 136 |
| 2 | 63 testbenches reported FAIL, many with benign output (`error-free transactions`, `error responses as specified`, `Expecting: ... failure`) | verdict logic treated the bare word "error" as a failure marker; simulator crashes and missing plusargs counted as design failures | strict failure markers; `NEEDS_FLOW` (missing plusarg/vector file), `TOOL_ERROR` (simulator-internal error -> fall back to Verilator), mixed pass+fail evidence -> `NO_VERDICT` | FAIL 63 -> 11 (the 11 remaining print explicit failure results themselves) |
| 3 | Modules whose comments say "outstanding" were flagged as behavioural stand-ins | marker regex `stand-?in` matched inside "out**standin**g" | word-bounded markers | strong-behavioural units 247 -> 160 |
| 4 | "Top-level modules" excluded exactly the ones a testbench drives | testbench instantiations counted as "instantiated" | only RTL instantiations count | integrable tops in a passing testbench's hierarchy 0 -> 70 |

Limits that remain (also stated in AUDIT.md section 10): regex scanner not a full parser; port-family detection is name based;
a generic runner cannot reproduce project-specific flows (those testbenches are `NEEDS_FLOW`/`BUILD_FAIL`, not "broken");
hierarchy reachability from a passing testbench is not proof that a block's behaviour is *checked*.
