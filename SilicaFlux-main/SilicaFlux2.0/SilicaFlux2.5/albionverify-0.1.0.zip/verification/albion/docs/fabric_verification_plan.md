# DataFabric verification plan (subsystem C)

Scope: `sfb_crossbar` (and the cells it is built from: `sfb_addr_decoder`, `sfb_arbiter`, `sfb_req_mux`,
`sfb_rsp_router`, `sfb_error_slave`), plus the unit benches `sfb_arbiter`, `sfb_reg_slice`, `sfb_skid_buffer`,
`sfb_error_slave`.  Everything is written from the specification documents under
`rtl/datafabric/docs/datafabric/` (PROTOCOL.md rules R1-R12, ARCHITECTURE.md, MEMORY_MAP.md, VERIFICATION.md) and
the header comments of the RTL.  Not covered (see section 9): DMA, SRAM adapters, `sfb_shared_bus`,
`sfb_perf_counters`, `sfb_v1_slave_adapter`.

Numbers in this document come from commands listed in section 10; the final figures are in
the lead report (final summary).  The one known RTL/spec discrepancy (DF-F1, PROTOCOL.md R11 vs the crossbar's `m_req_ready` during reset) is documented in the docstring of `tests/fabric/cocotb_xbar_known.py` and in the lead report.

## 1. Suites and DUT configurations

| suite | DUT(s) | what it contains |
|---|---|---|
| `xbar` | 11 `sfb_crossbar` configurations (below) | `cocotb_xbar_directed` (16 directed corner tests), `cocotb_xbar_random` (5 seeded random tests), `cocotb_xbar_reset` (6 reset tests), `cocotb_xbar_long` (long run, ~15 k transactions at NM = 4), `cocotb_xbar_known` (reproduction of the documented discrepancy DF-F1, tag `known_defect:DF-F1`, reports XFAIL).  Tags `directed random reset error long`. |
| `fab_arbiter` | `sfb_arbiter` N=1/3/4/6 round robin, N=4 fixed priority | `cocotb_arbiter` (stimulus sweep, fairness, lock, reset) |
| `fab_regslice` | `sfb_reg_slice` REQ/RSP slice = 11, 10, 01, 00, and 11 with AW 24 / DW 64 | `cocotb_regslice` (latency, capacity, throughput, random, reset) |
| `fab_cells` | `sfb_skid_buffer` WIDTH 8/37, `sfb_error_slave` DW 32/128 | `cocotb_cells` (cycle model, end-to-end, reset) |

Crossbar configurations (`tests/fabric/xbar_cfg.py`; `SLV_BASE`, `SLV_MASK`, `MST_SLV_EN` are passed as Python ints and
proven behaviourally by hand-computed routing tables, not through VPI):

| name | NM x NS | DW | ARB | align | purpose |
|---|---|---|---|---|---|
| `xbar_1x1` | 1x1 | 32 | RR | 1 | degenerate index widths (MW = SW = 1) |
| `xbar_2x2_fx` | 2x2 | 32 | fixed | 1 | regions at both ends of the address space (touch 0xFFFFFFFF) |
| `xbar_3x3_rr` | 3x3 | 32 | RR | 1 | non power of two NM/NS, adjacent regions, main mutation DUT |
| `xbar_3x3_part` | 3x3 | 32 | fixed | 1 | asymmetric partial `MST_SLV_EN`, fixed priority with 3 masters |
| `xbar_4x2_rr` | 4x2 | 32 | RR | 1 | more masters than slaves, a 2 GiB single-mask-bit region |
| `xbar_2x4_rr` | 2x4 | 32 | RR | 1 | sparse (non-contiguous) mask region, region at 0 and at the top |
| `xbar_2x2_dw64` | 2x2 | 64 | RR | 1 | 64-bit path, 8-byte alignment |
| `xbar_3x2_dw128` | 3x2 | 128 | RR | 1 | 128-bit path, 16 byte lanes, partial matrix |
| `xbar_2x2_noal` | 2x2 | 32 | RR | 0 | `CHECK_ALIGN = 0`: misaligned requests are forwarded |
| `xbar_ovl` | 2x3 | 32 | RR | 1 | overlapping regions, catch-all region (mask 0), matrix/priority interplay |
| `xbar_soc4x7` | 4x7 | 32 | RR | 1 | the real SoC map of MEMORY_MAP.md, CPUI/DMA denied PERIPH |

## 2. Checking architecture (crossbar)

Every crossbar test (directed, random, reset) runs the same four layers (`tests/fabric/xbar_tb.py`):

1. **Lockstep cycle model** (`albionverify/models/fabric_xbar.py`, built on `fabric_decoder.py` and `fabric_arbiter.py`).
   Each cycle the expected value of *every* DUT output (`m_req_ready`, `m_rsp_valid/rdata/error`, `s_req_valid` and its
   payload, `s_rsp_ready`, `err_evt/addr/master/write`, the four `ev_*` vectors) is computed from the *observed inputs*
   and the model's own state and compared.  This pins the arbitration winner of every cycle (fixed priority, RR
   pointer, grant lock), same-cycle reuse of master and slave ports (full throughput), error-slave timing, owner
   routing and the event outputs.  The model never reads a DUT output.
2. **Transaction scoreboard** (independent of the model's control decisions): a master acceptance must coincide with an
   acceptance at exactly the slave selected by the (hand-checked) decoder and with identical write/addr/wdata/wstrb;
   a slave acceptance without a master acceptance (invented / duplicated) and a master acceptance without a slave
   acceptance (lost) are errors; responses return to the owning master only, in order, never in the acceptance cycle;
   read data is compared with a reference `BackingStore` per slave updated in the slave-side acceptance order (the
   serialisation point for simultaneous masters on the same addresses); errors propagate (error = 1, rdata = 0) with
   no side effect; at the end the slave memories must equal the reference (uncertain bytes of reset-cancelled writes
   allowed); the ledger identity accepted = completed + cancelled holds.
3. **Independent properties**: R6 at every master and slave port, work conservation, no phantom slave request, fixed
   priority = lowest eligible index, round-robin winner = nearest to the pointer tracked from *observed*
   acceptances, round-robin bounded waiting (<= NM-1 other acceptances), the decode-error capture rule (lowest index
   per cycle), R11 quiescence (nothing transfers, no valid asserted while reset has been held for a cycle), the
   perf events against the master agents' own cycle counters.
4. **Passive protocol monitors** (`ReqRspMonitor`, outstanding limit 1) on every master and slave port: R2 (request
   stable until accepted: at the slave port this is the grant-lock check), R4, R5, R6, R8.

Stimulus agents: `ReqRspMaster` (max 2 outstanding so the next request is presented while the previous response is
pending), `WithdrawMaster` (withdraws / replaces stalled requests), `ReqRspSlave` + `BackingStore` with distinct
address- and slave-dependent power-up contents (mis-routed reads cannot hide), random latency / ready / valid
stalls, error injection (`LowWindowErrors`, `RandomErrors`).  Idle garbage is on for every master and slave.

## 3. Requirement traceability

| spec item | checked by |
|---|---|
| R1 handshake definition | every agent / monitor / model |
| R2 request stable until accepted; no cancellation; fabric tolerates withdrawal | monitors at all ports (slave port R2 = grant lock); `lock_release_on_withdraw`; `lock_withdraw_pointer`; `random_withdraw`; lockstep with withdrawal |
| R3 | not observable cycle-based (see 9) |
| R4 response stable until accepted | monitors; `rsp_backpressure`; `decode_error_timing`; random `rsp_bp` / `slow` profiles |
| R5 one response per request, in order, >= 1 cycle later | checker (in-order FIFO per master, `t_rsp > t_acc`), monitors, lockstep; `throughput`, `decode_error_timing` |
| R6 one outstanding per master port and slave port; accept no earlier than previous response accepted; full throughput | monitors + checker + lockstep; `throughput` (1 txn/cycle per port, per slave, parallel streams); `decode_error_timing` (error path); mutants FX-12..18 |
| R7 write completion before response | slave agent applies at acceptance; reference order = slave acceptance order; read-after-write data compare |
| R8 error semantics, no side effect | `slave_errors`, `random_errors`, `map_*`; monitor R8 check; scoreboard (err=1 => rdata=0, reference not updated) |
| R9 alignment, CHECK_ALIGN | `alignment` (every offset, every region, on/off configs), golden tables, FX-06/07 |
| R10 1..DW/8 bytes, sparse strobes | `strobes_lanes` (all 2^NB patterns for NB<=4, targeted + random for 8/16 byte lanes), all random tests |
| R11 reset | `cocotb_xbar_reset` (sync in 7 fabric states, async mid-cycle, sub-cycle glitch, back-to-back, random junk on every input during reset), quiescence check, uncertain writes, lockstep after reset |
| R12 ordering/latency, crossbar adds 0 cycles | lockstep (exact), `throughput`; reg-slice latency tests |
| Sec. 4 arbitration | `arb_contention` (strict FP order / strict RR rotation / equal shares under 3 slave stall regimes), `grant_lock`, lockstep winner every cycle, bounded-waiting property, arbiter unit bench |
| Sec. 5 errors, first error per cycle exported | `decode_error_timing`, `err_capture` (all masters in one cycle, subsets), independent capture check |
| Sec. 6 memory map, no aliasing | golden tables, `map_boundaries` (boundary neighbourhood + every single-bit departure of every mask from every master), SoC config |
| Sec. 7 reg slice | `fab_regslice` |

## 4. Reference models (`albionverify/models/`, pytest in `tests/fabric/test_model_*.py`)

* `fabric_decoder.py` -- `AddressMap`: region match `(addr & mask) == base`, lowest permitted slave wins, access matrix
  bit `m*NS+s`, alignment, `Decode` kinds `ok / unmapped / denied / misaligned`, region geometry and boundary probes.
  pytest: hand-computed tables of all 11 configurations (including the real MEMORY_MAP.md regions), parameter
  unpacking order, overlap/denial precedence, alignment for 32/64/128 bits.
* `fabric_arbiter.py` -- `ArbiterModel`: fixed priority, round robin with pointer = winner+1 on acceptance only, grant
  lock, release on withdrawal.  pytest: hand-computed sequences, and the spec property *bounded waiting <= N-1* (shown
  tight) checked on the model itself for N = 2..8.
* `fabric_xbar.py` -- `XbarModel`: cycle-accurate crossbar built from the above plus the error slave and port-occupancy
  rules.  pytest: hand-traced scenarios (single read with reuse in the response cycle, response stall, contention,
  decode-error timing and capture priority, ownership routing, reset, grant lock).
* `fabric_slice.py` -- `ElasticBuffer` (2-entry skid), `RegSliceModel`, `ErrorSlaveModel`.  pytest: capacity, +1 latency,
  registered ready, held error response.

## 5. Stimulus and determinism

All randomness comes from `Env.seeds` (SHA-256 derived streams).  Random tests pick the stall regime from (seed, test):
`dense`, `mixed`, `slave_bp`, `rsp_bp`, `slow` (each profile also varies per master / per slave).  Address classes:
region boundary neighbourhoods, hot (shared) addresses for same-address contention, uniformly random inside regions,
unmapped, denied (partial matrices), misaligned offsets.  Strobes: all lanes, random sparse, single byte, zero,
alternating.  Reset is exercised synchronously on predicates of the fabric state (outstanding at a master, write /
read in flight at a slave, grant lock engaged, error response pending, response stalled, contended+stalled, idle with
advanced pointers), asynchronously in mid-cycle (`ResetSequencer.async_pulse` started with `cocotb.start_soon` at a
random 1..9 ns phase) and as sub-cycle glitches (assert and release between two clock edges; peers in the shared reset
domain lose their outputs at the same instant), and back-to-back.  `python -m albionverify determinism --suite X`
compares the SHA-256 trace digest of two fresh runs; the benches feed model-level events into the digest.

## 6. Functional coverage (separate from code coverage)

Groups (sampled per accepted transaction / per cycle by `CovCollector` in `xbar_tb.py`, arbiter and slice benches have
their own): `fab_txn` (op x master x target-or-error, impossible pairs excluded by the access matrix), `fab_addr` (region
x first / last / inside / adjacent-below / adjacent-above, impossible combinations excluded using the decode model),
`fab_err` (unmapped / denied / misaligned / slave error x rd/wr, same-cycle error burst size), `fab_arb` (number of
competing masters x winner, stall under contention vs uncontended), `fab_bp` (slave stall, response stall and master
request wait durations 0/1/2-3/4-7/8+), `fab_conc` (masters with a transaction out, slaves busy, same-word contention),
`fab_reset` (fabric state at reset x sync/async/glitch), `fab_perf` (each event output seen).  Bins are defined **per configuration**: a bin that no legal stimulus can hit in that configuration is not defined
(and is therefore neither a hole nor padding): `fab_err.denied` only when some master is denied a region that no other
region shadows, `unmapped` only when an unmapped address exists (not with a catch-all region), `misaligned` only with
`CHECK_ALIGN = 1`; `fab_txn` target bins only for slaves a master can reach through the decoder (the `xbar_ovl` master 0
can never reach slave 1); `fab_arb` contention / winner combinations only for the master sets that can reach a common
slave (and, for fixed priority, only winners that can beat the others); `fab_conc.slaves_busy` <= min(NM, NS) (one
transaction per master port); `same_word` and `perf.loss` need two masters.  The arbiter bench has pointer bins only
for round robin, the slice bench no fill/skid bins for a bypassed channel.  Holes are reported by the
framework (`reports/coverage/functional/`); the final per-configuration figures are in the lead report and any
remaining holes are listed in the lead report.

## 7. Mutation testing

`mutants/fabric_xbar.yaml` (FX), `fabric_arbiter.yaml` (FA), `fabric_regslice.yaml` (FS), `fabric_cells.yaml` (FC): exact-text
patches of the pinned RTL covering decoder (mask compare, region size, EN bit order, EN ignored, overlap order,
alignment bit, CHECK_ALIGN, base MSB), routing (neighbour address, transposed index, owner capture, ready steering),
arbitration (lock removed / not released / held after accept, pointer frozen / on stall / = winner / wrong wrap, fixed
priority reversed, wrap off-by-one, search without rotation), flow control (m_free / s_free / out_q / busy_q /
rsp_ready forwarding / s_req_ready ignored), outstanding rules, error path (swallowed, rdata, hold, reset), capture
(priority, address, write flag, master, timing), perf events, data path (strobes, wdata, address MSB, rdata lanes for DW
64/128), reset (state not reset, synchronous instead of asynchronous reset), skid buffer / reg-slice faults.  Mutants
that can only differ on one configuration carry a `dut:` restriction.  Equivalent mutants carry a written argument.

## 8. Specification ambiguities and the interpretation used

1. **Reset value of the round-robin pointer / lock**: PROTOCOL.md is silent.  The model assumes pointer 0 and no lock after
   reset (the arbiter starts like fixed priority).  A bench that treated the pointer as unknown after reset would be
   weaker; this strict reading is deterministic and matches the RTL.
2. **`ev_arb_loss` meaning**: the header says "eligible but another master won the slave".  Interpreted as: eligible
   (valid, master free, decoded to the slave, access permitted) and the arbiter's grant for that slave belongs to
   another master, *independent of whether the slave can accept in that cycle* (a busy slave still has a grant).
3. **Overlapping regions**: the decoder header says the lowest slave index wins; interpreted as lowest *permitted*
   slave (a region denied to the master by `MST_SLV_EN` does not shadow a later matching region).  The spec says regions
   must not overlap, so this is a header-comment behaviour, verified on `xbar_ovl` only.
4. **`err_*` outputs when `err_evt = 0`**, **`rsp_rdata/rsp_error` when `rsp_valid = 0`**, **`s_rsp_ready` of an idle
   slave**, **`wdata`/`wstrb` of reads**: unspecified, not checked.
5. **Misaligned vs unmapped/denied**: all three are indistinguishable decode errors; the label (misaligned takes
   precedence) only serves coverage.
6. **CHECK_ALIGN = 0**: the spec only defines the decode error for `CHECK_ALIGN = 1`; with 0 the misaligned address is
   forwarded unchanged (checked), the slave agent aligns it down (environment convention).
7. **Reset-cancelled writes**: R11 allows "may or may not have been performed"; the crossbar reference marks the bytes of
   writes that were in flight at a slave as uncertain (`write_uncertain`).  The slave agents in this environment do
   apply a write at acceptance, so the slave memory always holds the new value; the reference accepts old or new.
8. **Slave error with non-zero rdata** (a slave violating R8): not tested; the crossbar's duty to scrub rdata is not
   specified (it forwards slave data unchanged).

## 9. Not verified / limits

* **Concepts that do not apply to this block** (stated explicitly as the guide asks): transfer lengths / bursts and
  maximum-length transfers (R10: SFB2 has one data beat per transaction, a "burst" is a sequence of transactions issued by
  the DMA, which belongs to another owner), transaction IDs and multiple outstanding transactions per port (section 8 of
  PROTOCOL.md: not implemented in rev 2.0; the limit of one outstanding transaction is what is verified), clock-domain
  crossing (single clock).

* R3 (valid must not depend combinationally on ready) and the combinational-path claims of PROTOCOL.md sec. 3 cannot be
  observed with cycle-driven agents (inputs change only at clock edges); loop freedom is a property of the
  attached components, proven formally in the original project and not re-proven here.
* "Registered ready" of the skid buffer is checked cycle-exactly against the model (a combinational dependence on
  `m_ready` would change `s_ready` within a cycle) but combinational independence is not probed by input toggling.
* Timing/PPA, gate-level behaviour, power, clock gating: out of scope.  A single clock domain only.
* Slaves that are not protocol-compliant (unsolicited responses, `rsp_valid` without a request, rdata != 0 with
  error) are not modelled; FX-91 documents the one mutant whose observability depends on that.
* Wide `SLV_BASE/SLV_MASK/MST_SLV_EN` cannot be read back through VPI; they are proven by the hand-computed routing
  tables of every configuration (a truncated parameter would route wrongly and fail).
* The DMA, SRAM adapters, `sfb_shared_bus`, `sfb_perf_counters`, `sfb_v1_slave_adapter` have other owners / are out of scope.
* Withdrawal tolerance (R2 note) is verified for the crossbar; masters never withdraw in the other benches.

## 10. Commands

```
python -m pytest tests/fabric -q                                  # model tests (no simulator)
python -m albionverify regress --suite xbar fab_arbiter fab_regslice fab_cells -j 2
python -m albionverify regress --suite xbar --tag reset -j 2      # subsets by tag: directed random reset error long
python -m albionverify mutate --suite xbar -j 2                   # likewise fab_arbiter fab_regslice fab_cells
python -m albionverify determinism --suite xbar -j 2
python -m albionverify run --dut xbar_3x3_rr --module fabric.cocotb_xbar_directed --testcase grant_lock --seed 1
```

## 11. Latest results (from the commands in section 10, run on the final test code)

| command | result |
|---|---|
| `python -m pytest tests/fabric -q` | 54 passed (decoder 28, arbiter 14, crossbar 8, slice 4 model tests; no simulator) |
| `regress --suite xbar fab_arbiter fab_regslice fab_cells -j 2 --label fabric_final` | 135 runs: 134 PASS, 1 XFAIL (documented discrepancy DF-F1), 0 FAIL; 20 551 339 checks; merged functional coverage 100.0 % of 1826 configuration-aware bins |
| per suite | `xbar` 93 runs (92 PASS + 1 XFAIL, 680 cocotb tests, 16.9 M checks); `fab_arbiter` 15 runs (60 tests, 2.8 M checks); `fab_regslice` 15 runs (75 tests, 0.55 M checks); `fab_cells` 12 runs (36 tests, 0.28 M checks) |
| `determinism --suite xbar fab_arbiter fab_regslice fab_cells -j 2` | 52 runs executed twice, 0 mismatches (`reports/determinism_fabric.json`) |
| `mutate --suite xbar` | 62 mutants: 57 killed (all by scoreboard / lockstep / protocol checks), 0 survived, 5 equivalent-annotated (FX-53, FX-90..93): score 100 % of non-equivalent |
| `mutate --suite fab_arbiter` | 17 mutants: 15 killed, 0 survived, 2 equivalent (FA-13, FA-90): 100 % |
| `mutate --suite fab_regslice` | 16 mutants: 16 killed: 100 % |
| `mutate --suite fab_cells` | 16 mutants: 15 killed, 1 equivalent (FC-90): 100 % |

Survivor history (an earlier mutation run, before the tests were strengthened): FX-44 (round-robin pointer also advances on
stalled grants) survived the crossbar suite because a stalled grant is locked, so the pointer is rewritten with the same
value at acceptance; it only differs when the locked master withdraws.  Fixed by the directed test `lock_withdraw_pointer`
(middle master locked, then withdraws; the next winner must come from the unmoved pointer).  FX-53 / FA-13 (grant-lock flag
not reset) were analysed as equivalent: after reset `lock_idx_q = prio_q = 0`, so a stale lock can only select requester 0,
which is also the winner of normal arbitration from pointer 0 in both modes (written argument in the yaml).

Negative controls (done once, models restored and verified identical): reversing the decoder precedence in the model made
`map_golden` fail on `xbar_ovl` and 3 decoder model tests fail; changing the round-robin pointer update to `winner` instead of
`winner + 1` made `arb_contention` fail on `xbar_3x3_rr` (lockstep) and 9 of the 14 arbiter model tests fail.

Functional coverage per configuration (framework `CoverGroup` merge of the final regression, bins defined per configuration):
every crossbar configuration, arbiter, slice and cell DUT reaches 100 % of its defined bins (e.g. `xbar_3x3_rr` 147/147,
`xbar_soc4x7` 223/223, `xbar_2x4_rr` 139/139, `fab_arb_rr6` 100/100).
