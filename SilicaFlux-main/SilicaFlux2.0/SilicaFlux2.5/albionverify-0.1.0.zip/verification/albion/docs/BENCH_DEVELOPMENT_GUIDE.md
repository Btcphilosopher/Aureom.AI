# Developing a subsystem bench (checklist and quality bar)

Read `docs/FRAMEWORK.md` first (contract + measured simulator facts), then
`tests/framework_smoke/cocotb_xbar_smoke.py` and `tests/framework_smoke/suite.py` (a complete working example:
agents, scoreboard, reset test, suite registration, mutants in `mutants/framework_smoke.yaml`).

## Boundaries (so parallel workers do not collide)

You may create/edit ONLY:
* `tests/<your dir>/**`  (cocotb modules `cocotb_*.py`, `suite.py`, pytest model tests `test_model_*.py`)
* `albionverify/models/<yourprefix>_*.py`  (independent reference models; new files only)
* `mutants/<yourprefix>*.yaml`
* `docs/<yourprefix>_verification_plan.md`, `docs/findings_<yourprefix>.md`
Do NOT edit: framework files (`albionverify/*.py`, `albionverify/bus/`, `albionverify/sim/`, `albionverify/mutate/`),
`rtl/` (pinned by SHA-256; editing breaks every build), `tools/`, `docs/FRAMEWORK.md`, other workers' directories.
If you need a framework change, do NOT make it: write the request into `docs/framework_requests_<yourprefix>.md`
(what, why, minimal patch) and work around it inside your own files.
DUT config names must start with your prefix (they become build/run directory names shared by all workers).
Never run `git add/commit/push`: nothing is committed in this project.

## Deliverables

1. **Independent reference models** (`albionverify/models/`): from the SPEC documents under `rtl/<project>/docs/`
   and first principles. They must not import or copy RTL logic. Unit-test each model with pytest, no simulator
   (`python -m pytest tests/<dir> -q -k model`), including hand-computed spec examples.
2. **Benches** (`tests/<dir>/cocotb_*.py`): drivers, request generators, protocol/response monitors, scoreboards
   that compare ACTUAL DATA against the model, functional coverage, error injectors, reset sequencing.
3. **`tests/<dir>/suite.py`** with `SUITES`: for each DUT config, cases for directed corner tests (fast), seeded
   random tests (>= 3 seeds), reset-during-traffic, error/malformed/access-control cases, maximum-length
   transfers where the block has a length. Tag cases (`"directed"`, `"random"`, `"reset"`, `"error"`, `"long"`).
   Set `mutation_cases` to a FAST subset (< ~90 s total per mutant) that still contains the checks that matter.
4. **Mutants** (`mutants/<prefix>*.yaml`): >= 15 functional bugs spanning the block's spec (see FRAMEWORK.md sec. 5).
   Run `python -m albionverify mutate --suite <name> -j 2`; investigate every survivor: strengthen the TESTS
   (preferred) or justify `equivalent:` in writing. Do not weaken checks to hide anything; do not reference
   mutant ids from tests.
5. **Docs**: `docs/<prefix>_verification_plan.md` (what is checked, how, coverage goals, what is NOT verified,
   spec ambiguities and the interpretation used) and `docs/findings_<prefix>.md` (RTL defects/discrepancies
   with spec clause, seed, repro command, waveform path; or an explicit "none found").

## Quality bar

* Requirement: every accepted request produces the correct completion or an explicitly defined cancellation;
  data is checked, not counts. A test that cannot fail is worthless: prove yours can (mutants, and by temporarily
  breaking your own model once to see the red result).
* Deterministic seeded random: simultaneous masters/requesters, random addresses, random stalls/back-pressure,
  reset during transactions (including async mid-cycle), malformed requests, access-control failures, maximum-length
  transfers -- wherever the block has the concept. Say explicitly where a concept does not apply.
* Functional coverage with the groups listed in FRAMEWORK.md sec. 3 item 8. Keep functional coverage separate
  from code coverage (code coverage is collected by the framework from `regress --coverage`; you do nothing for it).
* Run to completion for real: the numbers in your report must come from commands you ran. Never report an
  unexecuted test as passing. If something is flaky, find out why (seed dependence is a finding, not noise).
* Reproducibility: `python -m albionverify determinism --suite <name>` must report 0 mismatches.
* A pytest-only model test directory must pass: `python -m pytest tests/<dir> -q`.

## Machine etiquette (4 cores shared by several workers)

Use `-j 2` for regress/mutate. A Verilator build takes 10-60 s and a mutant campaign builds once per mutant:
keep DUT configs few and small (small DEPTH/NM/NS/lane counts), and keep per-run simulated cycles modest.
Always use bounded waits. Do not leave background processes running. Build artefacts are cached under `build/`.

## Final report to the lead (<= 600 words, facts only)

Files created; suites and what each case covers; EXACT counts from your last full `regress` and `determinism` runs;
mutation score per suite with every survivor and your analysis; RTL discrepancies found (ids); what is not verified;
framework limitations you hit.
