# Reading the mutation results

A mutation score only means something if its yardstick is honest. This note says what the numbers do and do not show.

## Statuses

| status | meaning | counts in the score |
|---|---|---|
| KILLED | a test failed on the mutated RTL while the unmutated baseline passed (kind: CHECK = bench scoreboard/protocol/model, ASSERT = an assertion inside the RTL aborted the simulation, LIVENESS/TIMEOUT/CRASH = hang or crash) | numerator |
| SURVIVED | every test passed: a verification gap | denominator |
| UNOBSERVABLE_SURVIVED | survives, **not** proven equivalent; the behaviour cannot be provoked through the ports (e.g. 2^32-1 counter saturation, an internal alignment checker) | denominator (counts against the score) |
| EQUIVALENT_SURVIVED | survives with a written behavioural-equivalence argument in the YAML | excluded |
| BUILD_ERROR | patch did not apply / did not compile: invalid mutant | excluded |

## Threats to validity (and what was done)

1. **The workers wrote both the tests and the mutants** and iterated until the mutants died, so their scores partly measure tests tuned to their own yardstick.
   Counter-measure: a **held-out** set (`mutants/heldout_*.yaml`, suites `heldout_*`) authored by the lead from the RTL after the benches were finished, scored against the workers' *unchanged* test cases. See `reports/mutation/heldout_*.md`.
2. **Equivalent-mutant arguments are judgement calls.** They were spot-checked by the lead. Most are unconditional (redundant terms, commutativity, case analysis). Seven hold only under protocol-legal usage or under the tested configuration, i.e. they are really
   "equivalent for the stimulus that is legal here":
   `DA-25`, `DA-26` (the DMA engines never present the traffic the router hold guards against), `FA-90` (`stall` implies a valid grant at the interface), `FX-91` (only protocol-compliant slaves are modelled), `BM-31` (relies on assertions that are not compiled in),
   `SM-31` (`ECC_MODE=NONE` in every built configuration), `SM-32` (`BYTE_WE=0` configurations). Treat them as scoped, not universal.
3. **Mutants are single, local, textual changes.** They model plausible slips (off-by-one, wrong operator, dropped term, swapped order); they do not model multi-site bugs, timing/CDC faults or missing features.
4. **A kill by assertion/hang is weaker evidence than a CHECK kill**: the bug was noticed, but not by the independent model. The reports list the kinds separately.
5. **100% is not completeness.** It means: none of the mutants I could think of survives. Verification gaps outside the mutant catalogue are invisible here; functional-coverage holes and the "not verified" lists in each plan are the complementary view.
