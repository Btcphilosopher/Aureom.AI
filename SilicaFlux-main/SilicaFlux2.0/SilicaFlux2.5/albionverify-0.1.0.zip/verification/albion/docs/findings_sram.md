# Findings: SRAM subsystem (block A)

Source: SRAM bench worker report; F-SRAM-01 re-verified by the lead against the pinned sources.
Numeric claims in the worker's report are NOT repeated here; the consolidated, re-executed numbers are in `reports/SUMMARY.md`.

## RTL defects

None found in `sram_sp`, `sram_bank_controller` or `hpc_scratchpad` (direct-mode search). No `known_defect` tags were needed.

## Documentation discrepancy

**F-SRAM-01 (documentation, low).** `rtl/hpc_m04_scratchpad/rtl/hpc_spm_defs.svh` line 35 describes `HPC_SPM_ARB_RR` as
"pointer moves past the **last** winner". `docs/03_banking_and_arbitration.md` (section "Starvation-free (RR) with a bound")
and `hpc_spm_bank_arb.sv` implement and justify the pointer moving past the **first** winner (`ptr <- first granted port + 1`);
the doc explains that moving past the last winner can starve a hazard-blocked port in 1R1W/2RW banks. The RTL and doc 03 are
right; the header comment is wrong. The last-winner variant is injected as mutant `SM-09` and is killed by the bench
(`python -m albionverify run --dut sram_spm_3p2b_high_2rw_w64 --module sram.cocotb_sram_spm --testcase random_traffic --seed 1 --mutant SM-09`).

## Interpretations where the specification is silent (open questions)

| id | question | interpretation the models use |
|---|---|---|
| OQ-1 | `rsp_we` on an error response to a write | `rsp_we = 1` |
| OQ-2 | when a freed response credit becomes usable | a credit freed by a hand-over at edge h is usable by a request accepted at edge h+1 or later |
| OQ-3 | do error requests (and posted writes) consume a credit | yes |
| OQ-4 | bank-controller RR pointer reset and update | starts at 0, moves to winner+1; the bench also checks the documented "granted within NUM_MASTERS" bound independently |
| OQ-5 | state of writes accepted before a reset | they persist (committed at the acceptance edge); presented-but-not-accepted writes have no effect (so `write_uncertain` was not needed) |
| OQ-6 | `busy` of `sram_sp` / bank controller | undocumented, therefore not checked (`hpc_scratchpad.busy` is documented and is checked) |

## Mutants annotated equivalent (each needs the argument to stay valid)

* `BM-31`: `bk_rd` ignoring `we` is only observable through `stg_rd` gating and assertions that are not compiled in.
* `SM-31`: the error-code data mask is redundant when `ECC_MODE=NONE`.
* `SM-32`: `&strobe` equals `|strobe` for the only strobes that reach the array (`BYTE_WE=0`).
