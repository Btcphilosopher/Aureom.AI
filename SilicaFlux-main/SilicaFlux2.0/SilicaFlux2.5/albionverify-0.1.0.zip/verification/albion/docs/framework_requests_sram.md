# Framework requests from the SRAM subsystem bench

None of these blocked the work; each was worked around inside `tests/sram/` (no framework file was edited).

## FR-SRAM-1  `Env.verify_params` reports a false "parameter lost" for 64-bit typed parameters

**What.** `Env.verify_params()` (called by `Env.start()`) reads every numeric parameter through VPI and compares it with
the value the build requested whenever that value fits in 32 bits.  `hpc_scratchpad` declares
`parameter logic [63:0] BASE_ADDR`; VPI returns 0 for such a parameter whatever its value, so a build with
`BASE_ADDR = 0x4000` fails at `env.start()` with *"DUT parameter BASE_ADDR elaborated as 0x0 but the build requested 0x4000"*.
The FRAMEWORK.md fact "parameters wider than 32 bits read as 0" is about the *value*; the *declared type* matters too.

**Workaround used.** `tests/sram/sram_spm_bench.py` captures `ALBION_PARAMS` at import time, then rewrites the environment
variable without `BASE_ADDR` before `env.start()`; `BASE_ADDR` is proven behaviourally (window edges, below-BASE addresses
and aliases that differ only in upper address bits must be rejected, the window base must map to word 0).

**Minimal patch.** In `Env.verify_params`, treat a VPI read of 0 for a parameter whose requested value is non-zero as
*unverifiable* (append to `notes['params_unverifiable']`) instead of raising when the handle's declared width is > 32
(`len(handle) > 32`), or accept an `ignore=[...]` list argument.

## FR-SRAM-2  `ReqRspMaster` / `ReqRspMonitor` assume exactly one response per accepted request

**What.** Posted writes (`WRITE_ACK = 0`) produce no response, so the framework master never becomes `idle`, pairs later
responses with the wrong request (`match="order"` pops the posted write) and reports a stray response.  The master also
cannot drive lane masks that are not byte lanes (`nbytes` is used both as the lane count and as `DATA_WIDTH/8`; the SRAM
library allows 9-bit lanes and bit masks).

**Workaround used.** `tests/sram/sram_bench.SramMaster` is a small driver (same `Req` dataclass, same `Throttle`, same
listener hook) that leaves response pairing to the cycle-exact checker.

**Minimal patch.** `ReqRspMaster(..., expects_response=callable(req)->bool, lane_bits=...)`.

## FR-SRAM-3  `ResetSequencer.async_pulse` consumes a clock edge without stepping the agents

**What.** `async_pulse()` awaits `RisingEdge` itself; called from a test between `env.tick()` calls it swallows one edge, so
`Env.step()` (sample/drive) does not run for it and the cycle counter drifts from the simulation.

**Workaround used.** Start it as a concurrent coroutine (`cocotb.start_soon(rst.async_pulse(phase, length))`): both the test
loop and the pulse await the same next edge, the loop steps the agents, the pulse asserts `rst_n` `phase_ns` later and
notifies the agents.  Worth stating in FRAMEWORK.md sec. 3 item 7.

## FR-SRAM-4  Mutation engine builds every mutant for every DUT of the suite

**What.** `_affected_duts` selects all DUTs of `suite.duts()` (cases and `mutation_cases`) whose closure contains the patched
file, then builds each one although only DUTs that have `mutation_cases` are run.  A suite with 7 configurations of the same
top costs 7 builds per mutant.

**Workaround used.** Every mutant is pinned with `dut:` to the single configuration in which it is observable.

**Minimal patch.** Restrict `_affected_duts` to the DUTs of `suite.mutation_set()`.

## FR-SRAM-5  Functional coverage is merged across DUT configurations

**What.** `write_coverage` merges `*.func_cov.json` of all runs of a suite; bins that exist in one configuration only are
reported as hit when any configuration hits them, so a hole in the configuration that matters can be hidden by another.

**Workaround used.** The bench defines bins per configuration (structurally unreachable bins are not defined) and
`docs/sram_verification_plan.md` quotes per-configuration percentages computed from the per-run JSON files.

**Minimal patch.** Key the merge by `(dut, group)` and report both per-DUT and merged numbers.

## FR-SRAM-6  Shared report files

`python -m albionverify determinism` writes `reports/determinism.json` by default and `regress` writes
`reports/coverage/...` per label; parallel workers overwrite each other's default `determinism.json`.  Worked around with
`--out reports/determinism_<suite>.json` and unique `--label`s.
