# Framework requests from subsystem D (compute)

No framework file was edited.  Everything below was worked around inside `tests/compute/`, `albionverify/models/vec_*.py|ten_*.py`
and `mutants/`.

1. **Mutation engine builds every DUT of the suite that contains the patched file, even DUTs no mutation case uses.**
   (`mutate/engine.py::_affected_duts` considers `suite.duts()` = all DUTs of `cases + mutation_cases`.)  A suite with several
   DUT configurations (here 3 lane / 4+ array / 4 tensor configurations) therefore builds each mutant 3-6 times.
   *Workaround:* every mutant carries `dut: <config>` (`expect_dut`).
   *Minimal patch:* in `_affected_duts`, iterate over `{c.dut for c in suite.mutation_set()}` instead of `suite.duts()`.

2. **No way to express "unobservable under legal stimulus" for a mutant.**  Two tensor mutants disable the in-array alignment
   checker (`align_err`), which can only fire after an internal fault (the vendor uses an Icarus-only `force`; Verilator /
   cocotb cannot reach internal nets without `--public-flat-rw`).  They are annotated `equivalent:` with the text
   "UNOBSERVABLE UNDER LEGAL STIMULUS" so they stay visible in the report, but that is not a proof of equivalence.
   *Minimal patch:* an `unobservable:` annotation with its own counter in `score()`, or a framework option to build with
   `--public-flat-rw` so a bench may inject faults through VPI (`dut.<hier>.<net>.value = ...`) for fault-injection tests.

3. **`regress --only` overwrites `reports/regression/regression_<suite>.*` and the functional coverage report of the full
   run** (same label) unless `--label` is passed.  A partial re-run silently replaced the full-regression numbers.  Suggest a default
   label that includes the `--only` filter.

4. **Machine load.**  With 4 cores shared by all workers (load average 12-15 during the campaigns) a Verilator build of
   `hpc_vector_array` (8 lanes) took ~4.5 minutes and a 50-mutant campaign about an hour; per-mutant wall time is dominated by the
   build, not by the (3-10 s) simulations.  A shared ccache / pre-linked object cache keyed per patched file would cut campaign
   time substantially.
