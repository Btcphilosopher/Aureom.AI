# Bugs found in the framework itself while building and verifying it

Each was found by running the framework against real RTL or by negative tests, fixed, and (where possible) pinned by a regression test.

| # | defect | how it was found | fix |
|---|---|---|---|
| 1 | Wide (>32-bit) `-G` parameter overrides were **silently truncated** by Verilator (a 64-bit address map arrived as 0) | first crossbar bench saw correct-looking decode errors; traced with a parameter probe | sized-literal emission (`param_literal`); `Env.verify_params` for <=32-bit values; wide ones proven behaviourally |
| 2 | VPI parameter reads are unreliable (declared >32-bit reads 0; bit-31 values read negative) | same probe; later confirmed by the SRAM worker on `logic [63:0] BASE_ADDR` | `verify_params` skips them (reported in `env.notes`) |
| 3 | Build cache key ignored the recipe, so a fixed build kept serving a stale binary | wide-parameter fix "did nothing" | key includes emitted literals + `BUILDER_REV` |
| 4 | `Shadow.flush` initially wrote zeros onto DUT **output** ports that agents only read | design review before first run | shadows become dirty only when written |
| 5 | Master matched a same-edge response to a just-accepted request (hiding an R5 violation) | code review | responses handled first against *earlier*-accepted requests |
| 6 | `max_req_stall` / `max_rsp_stall` were only updated on acceptance (a request stalled forever reported 0) | unit test | updated every stalled cycle |
| 7 | `cocotb` results.xml carries only "Test failed with RANDOM_SEED=n" | first failing run | real exception extracted from the log |
| 8 | `Timer(float ns)` raised on non-representable phases in `async_pulse` | DataFabric worker | integer picoseconds |
| 9 | `async_pulse` swallowed a clock edge if awaited between `tick()` calls | three workers | documented (`start_soon`); `assert_now` + `glitch()` added |
| 10 | Mutation engine built every mutant for every DUT of a suite, even DUTs with no mutation case | SRAM / DataFabric / compute workers | restricted to `mutation_set()` DUTs |
| 11 | Functional coverage merged across DUT configurations (a hit in one hid a hole in another) | SRAM / DataFabric workers | merged per configuration (`<dut>::<group>`) |
| 12 | "equivalent" mutants that were merely unobservable were excluded from the score | compute / control worker reports | separate `UNOBSERVABLE_SURVIVED` status, counted against the score |
| 13 | `regress --only` overwrote the full run's report; parallel `determinism` runs overwrote each other | compute / SRAM workers | default labels/paths include the selection |
| 14 | **`--mutant ID` was ambiguous** (`SM-01` exists in two suites) and silently chose the wrong one | unzipped-package verification | `suite:ID` form, disambiguation by the DUT's source closure, explicit error otherwise |
| 15 | `make unit` ran only the 67 framework tests (`-m model`), silently skipping the 530 model tests of the blocks | final review | runs every simulator-free test (598) |
| 16 | `build/` grew to 17 GB (precompiled headers, objects) | disk check | intermediates pruned after each build; ccache used when installed |
