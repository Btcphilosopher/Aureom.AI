"""Suite-driven simulation tests: one pytest item per (suite, case, seed)."""
import pytest

from albionverify.sim.build import build_dut
from albionverify.sim.runner import run_cocotb, run_with_waves_on_fail
from albionverify.suite import load_suites

_SUITES = load_suites()


def pytest_generate_tests(metafunc):
    if "suite_case" not in metafunc.fixturenames:
        return
    cfg = metafunc.config
    only = set(cfg.getoption("--suite"))
    tags = set(cfg.getoption("--tag"))
    seeds_override = [int(x) for x in cfg.getoption("--seeds").split(",")] if cfg.getoption("--seeds") else None
    items, ids = [], []
    for sname, s in _SUITES.items():
        if only and sname not in only:
            continue
        for c in s.cases:
            if tags and not (tags & set(c.tags)):
                continue
            for seed in (seeds_override or c.seeds):
                items.append((sname, c, seed))
                ids.append("%s::%s::seed%d" % (sname, c.label, seed))
    metafunc.parametrize("suite_case", items, ids=ids)


@pytest.mark.sim
def test_suite_case(suite_case, request):
    sname, case, seed = suite_case
    cov = request.config.getoption("--coverage")
    built = build_dut(case.dut, coverage=cov)
    r = run_cocotb(built, case.module, case.testcase, seed, timeout=case.timeout)
    r.tags = list(case.tags)
    if not r.passed and not request.config.getoption("--no-waves"):
        r = run_with_waves_on_fail(built, r)
    if r.known_defect:
        if r.passed:
            pytest.fail("XPASS: known defect %s no longer reproduces (remove the known_defect tag)\n%s" % (r.known_defect, r.test_id))
        pytest.xfail("known defect %s: %s" % (r.known_defect, r.cases[0].message if r.cases else r.status))
    assert r.passed, r.failure_summary()
