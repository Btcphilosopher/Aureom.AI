"""Suite registry for subsystem C: DataFabric.

  xbar          sfb_crossbar, 11 configurations (NM x NS, DW 32/64/128, fixed / round-robin, partial access matrix,
                CHECK_ALIGN on/off, sparse / overlapping / catch-all maps, the real 4x7 SoC map).  Tags: directed, random,
                reset, error, long.  `regress --suite xbar --tag reset` etc. select subsets.
  fab_arbiter   sfb_arbiter unit bench (N = 1, 3, 4, 6 round robin; N = 4 fixed priority).
  fab_regslice  sfb_reg_slice (REQ_SLICE / RSP_SLICE = 11, 10, 01, 00; one wider AW/DW variant).

The configuration order inside `xbar` matters for mutation runs: the engine builds every mutant for each DUT of the
suite in order until a test fails, so the DUTs that carry mutation cases come first.
"""
from albionverify.sim.build import DutSpec
from albionverify.suite import Case, Suite

from .xbar_cfg import CONFIGS

C = {n: c.dut() for n, c in CONFIGS.items()}

MUT_ORDER = ["xbar_3x3_rr", "xbar_3x3_part", "xbar_2x2_fx", "xbar_4x2_rr", "xbar_2x2_noal", "xbar_ovl"]
OTHER = ["xbar_1x1", "xbar_2x4_rr", "xbar_2x2_dw64", "xbar_3x2_dw128", "xbar_soc4x7"]
ORDER = MUT_ORDER + OTHER

XBAR_CASES = []
for _n in ORDER:
    XBAR_CASES.append(Case(C[_n], "fabric.cocotb_xbar_directed", None, (1, 2), tags=("directed", "error")))
    XBAR_CASES.append(Case(C[_n], "fabric.cocotb_xbar_random", None, (1, 2, 3, 4), tags=("random", "error")))
    XBAR_CASES.append(Case(C[_n], "fabric.cocotb_xbar_reset", None, (1, 2), tags=("reset",)))
for _n in ("xbar_3x3_rr", "xbar_4x2_rr", "xbar_2x2_fx", "xbar_soc4x7"):
    XBAR_CASES.append(Case(C[_n], "fabric.cocotb_xbar_long", None, (1,), tags=("long", "random"), timeout=1200.0))
# documented spec/RTL discrepancy (tests/fabric/cocotb_xbar_known.py, DF-F1): reports XFAIL while it reproduces, XPASS (a failure) once fixed
XBAR_CASES.append(Case(C["xbar_3x3_rr"], "fabric.cocotb_xbar_known", None, (1,), tags=("reset", "known_defect:DF-F1")))

# fast subset for mutation campaigns: the directed + reset + one random run on the main configuration, the directed
# corner tests on the configurations that carry config-specific behaviour (fixed priority, partial matrix, CHECK_ALIGN=0,
# overlapping regions, NM > NS)
XBAR_MUT = [
    Case(C["xbar_3x3_rr"], "fabric.cocotb_xbar_directed", None, (1,), tags=("directed",)),
    Case(C["xbar_3x3_rr"], "fabric.cocotb_xbar_reset", None, (1,), tags=("reset",)),
    Case(C["xbar_3x3_rr"], "fabric.cocotb_xbar_random", None, (1,), tags=("random",)),
] + [Case(C[_n], "fabric.cocotb_xbar_directed", None, (1,), tags=("directed",)) for _n in MUT_ORDER[1:] + ["xbar_2x2_dw64", "xbar_3x2_dw128"]]


def arb(name, n, mode):
    return DutSpec(name, "sfb_arbiter", params=(("N", n), ("MODE", mode)))


A = {n: arb(n, k, m) for n, k, m in (("fab_arb_rr3", 3, 1), ("fab_arb_fx4", 4, 0), ("fab_arb_rr4", 4, 1), ("fab_arb_rr6", 6, 1), ("fab_arb_rr1", 1, 1))}


def sl(name, rq, rs, aw=32, dw=32):
    return DutSpec(name, "sfb_reg_slice", params=(("AW", aw), ("DW", dw), ("REQ_SLICE", rq), ("RSP_SLICE", rs)))


SL = {n: sl(n, rq, rs, aw, dw) for n, rq, rs, aw, dw in (("fab_slice_11", 1, 1, 32, 32), ("fab_slice_10", 1, 0, 32, 32), ("fab_slice_01", 0, 1, 32, 32),
                                                          ("fab_slice_00", 0, 0, 32, 32), ("fab_slice_11_w64", 1, 1, 24, 64))}

CELLS = {
    "fab_skid_w8": DutSpec("fab_skid_w8", "sfb_skid_buffer", params=(("WIDTH", 8),)),
    "fab_skid_w37": DutSpec("fab_skid_w37", "sfb_skid_buffer", params=(("WIDTH", 37),)),
    "fab_err_dw32": DutSpec("fab_err_dw32", "sfb_error_slave", params=(("DW", 32),)),
    "fab_err_dw128": DutSpec("fab_err_dw128", "sfb_error_slave", params=(("DW", 128),)),
}

SUITES = {
    "xbar": Suite(
        name="xbar",
        subsystem="fabric",
        title="DataFabric sfb_crossbar: map / arbitration / routing / ordering / error / reset (11 configurations)",
        cases=XBAR_CASES,
        mutation_cases=XBAR_MUT,
        mutants_file="mutants/fabric_xbar.yaml",
        spec_refs=("datafabric/docs/datafabric/PROTOCOL.md", "datafabric/docs/datafabric/ARCHITECTURE.md", "datafabric/docs/datafabric/MEMORY_MAP.md",
                   "datafabric/docs/datafabric/VERIFICATION.md"),
        notes="Lockstep cycle model + transaction scoreboard + independent properties; see docs/fabric_verification_plan.md.",
    ),
    "fab_arbiter": Suite(
        name="fab_arbiter",
        subsystem="fabric",
        title="sfb_arbiter unit bench: one-hot grant, lock, RR pointer, fairness bound, fixed priority, reset",
        cases=[Case(d, "fabric.cocotb_arbiter", None, (1, 2, 3), tags=("directed", "random", "reset")) for d in A.values()],
        mutation_cases=[Case(A[n], "fabric.cocotb_arbiter", None, (1,), tags=("directed", "random")) for n in ("fab_arb_rr3", "fab_arb_fx4", "fab_arb_rr4")],
        mutants_file="mutants/fabric_arbiter.yaml",
        spec_refs=("datafabric/docs/datafabric/PROTOCOL.md",),
    ),
    "fab_regslice": Suite(
        name="fab_regslice",
        subsystem="fabric",
        title="sfb_reg_slice / sfb_skid_buffer: transparency, +1 cycle per sliced direction, capacity, back-pressure, reset",
        cases=[Case(d, "fabric.cocotb_regslice", None, (1, 2, 3), tags=("directed", "random", "reset")) for d in SL.values()],
        mutation_cases=[Case(SL[n], "fabric.cocotb_regslice", None, (1,), tags=("directed", "random", "reset")) for n in ("fab_slice_11", "fab_slice_10", "fab_slice_01", "fab_slice_00")],
        mutants_file="mutants/fabric_regslice.yaml",
        spec_refs=("datafabric/docs/datafabric/PROTOCOL.md",),
    ),
    "fab_cells": Suite(
        name="fab_cells",
        subsystem="fabric",
        title="sfb_skid_buffer and sfb_error_slave unit benches (cycle model + end-to-end + reset)",
        cases=[Case(d, "fabric.cocotb_cells", None, (1, 2, 3), tags=("directed", "random", "reset")) for d in CELLS.values()],
        mutation_cases=[Case(CELLS[n], "fabric.cocotb_cells", None, (1,), tags=("directed", "random", "reset")) for n in ("fab_skid_w8", "fab_err_dw32")],
        mutants_file="mutants/fabric_cells.yaml",
        spec_refs=("datafabric/docs/datafabric/PROTOCOL.md",),
    ),
}
