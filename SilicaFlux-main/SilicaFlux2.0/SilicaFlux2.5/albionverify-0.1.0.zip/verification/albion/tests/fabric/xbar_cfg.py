"""DataFabric crossbar DUT configurations (names start with ``xbar_``, as required for shared build dirs).

Every configuration is a plain description (regions, access matrix, widths).  ``XCfg.dut()`` turns it
into a ``DutSpec`` whose wide parameters (SLV_BASE / SLV_MASK / MST_SLV_EN) are passed as Python ints
(the build layer emits sized literals; see docs/FRAMEWORK.md "Measured facts").

``golden`` lists HAND-COMPUTED routing expectations (computed from the region base/mask by hand, not by
any model): (master or None for every master, byte address, expected) where expected is a slave index or
one of "unmapped" / "denied" / "misaligned".  The benches check the DUT against these tables as well as
against the decode model (which pytest also checks against the same tables).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

from albionverify.sim.build import DutSpec

AW = 32


def pack(values: Sequence[int], width: int) -> int:
    out = 0
    for i, v in enumerate(values):
        out |= (int(v) & ((1 << width) - 1)) << (i * width)
    return out


@dataclass(frozen=True)
class XCfg:
    name: str
    nm: int
    ns: int
    dw: int = 32
    arb: int = 1  # 0 fixed priority, 1 round robin
    align: int = 1  # CHECK_ALIGN
    regions: Tuple[Tuple[int, int], ...] = ()  # (base, mask) per slave
    en: Optional[Tuple[Tuple[int, ...], ...]] = None  # en[m][s]; None => parameter left at its default (all ones)
    golden: Tuple[Tuple[Optional[int], int, object], ...] = ()
    note: str = ""

    @property
    def nbytes(self) -> int:
        return self.dw // 8

    def en_matrix(self) -> List[List[int]]:
        if self.en is None:
            return [[1] * self.ns for _ in range(self.nm)]
        return [list(r) for r in self.en]

    def params(self) -> Tuple[Tuple[str, object], ...]:
        p: List[Tuple[str, object]] = [("NM", self.nm), ("NS", self.ns), ("DW", self.dw), ("ARB_MODE", self.arb), ("CHECK_ALIGN", self.align)]
        p.append(("SLV_BASE", pack([b for b, _ in self.regions], AW)))
        p.append(("SLV_MASK", pack([m for _, m in self.regions], AW)))
        if self.en is not None:
            v = 0
            for m in range(self.nm):
                for s in range(self.ns):
                    if self.en[m][s]:
                        v |= 1 << (m * self.ns + s)
            p.append(("MST_SLV_EN", v))
        return tuple(p)

    def dut(self) -> DutSpec:
        return DutSpec(self.name, "sfb_crossbar", params=self.params())


# ------------------------------------------------------------------------------------------------ maps
# Region extents below are computed by hand from (base, mask): last = base | ~mask.

# 1x1: one 64 KiB window [0x20000000, 0x2000FFFF]
CFG_1X1 = XCfg(
    "xbar_1x1", 1, 1, regions=((0x20000000, 0xFFFF0000),),
    golden=(
        (0, 0x1FFFFFFC, "unmapped"), (0, 0x20000000, 0), (0, 0x2000FFFC, 0), (0, 0x20010000, "unmapped"),
        (0, 0x00000000, "unmapped"), (0, 0xFFFFFFFC, "unmapped"), (0, 0x20000002, "misaligned"), (0, 0x2000FFFF, "misaligned"),
    ),
    note="degenerate widths (MW = SW = 1)",
)

# 2x2 fixed priority: s0 = first 4 KiB of the address space, s1 = last 4 KiB (touches 0xFFFFFFFF)
CFG_2X2_FX = XCfg(
    "xbar_2x2_fx", 2, 2, arb=0, regions=((0x00000000, 0xFFFFF000), (0xFFFFF000, 0xFFFFF000)),
    golden=(
        (None, 0x00000000, 0), (None, 0x00000FFC, 0), (None, 0x00001000, "unmapped"), (None, 0xFFFFEFFC, "unmapped"),
        (None, 0xFFFFF000, 1), (None, 0xFFFFFFFC, 1), (None, 0x80000000, "unmapped"), (None, 0x00000001, "misaligned"),
        (None, 0xFFFFFFFE, "misaligned"),
    ),
    note="regions at both ends of the address space; fixed priority",
)

# 3x3 round robin: s0/s1 adjacent 32 KiB windows, s2 128 KiB window
G_3X3 = (
    (None, 0x0FFFFFFC, "unmapped"), (None, 0x10000000, 0), (None, 0x10007FFC, 0), (None, 0x10008000, 1),
    (None, 0x1000FFFC, 1), (None, 0x10010000, "unmapped"), (None, 0x3FFFFFFC, "unmapped"), (None, 0x40000000, 2),
    (None, 0x4001FFFC, 2), (None, 0x40020000, "unmapped"), (None, 0x00000000, "unmapped"), (None, 0xFFFFFFFC, "unmapped"),
    (None, 0x10000001, "misaligned"), (None, 0x10007FFF, "misaligned"), (None, 0x10008002, "misaligned"),
)
R_3X3 = ((0x10000000, 0xFFFF8000), (0x10008000, 0xFFFF8000), (0x40000000, 0xFFFE0000))
CFG_3X3_RR = XCfg("xbar_3x3_rr", 3, 3, arb=1, regions=R_3X3, golden=G_3X3, note="non-power-of-two NM and NS, adjacent regions, full matrix")

# 3x3 fixed priority with an asymmetric partial access matrix: m0:{s0,s1} m1:{s0,s1,s2} m2:{s2}
CFG_3X3_PART = XCfg(
    "xbar_3x3_part", 3, 3, arb=0, regions=R_3X3, en=((1, 1, 0), (1, 1, 1), (0, 0, 1)),
    golden=(
        (0, 0x10000000, 0), (0, 0x10008000, 1), (0, 0x40000000, "denied"), (0, 0x4001FFFC, "denied"),
        (1, 0x10007FFC, 0), (1, 0x10008000, 1), (1, 0x40000000, 2), (1, 0x40020000, "unmapped"),
        (2, 0x10000000, "denied"), (2, 0x1000FFFC, "denied"), (2, 0x40000000, 2), (2, 0x4001FFFC, 2),
        (2, 0x40000001, "misaligned"), (0, 0x0FFFFFFC, "unmapped"),
    ),
    note="MST_SLV_EN bit order (bit m*NS+s) with an asymmetric matrix; fixed priority with 3 masters",
)

# 4x2 round robin: s0 = 64 KiB at 0, s1 = upper half of the address space (bit 31 set)
CFG_4X2_RR = XCfg(
    "xbar_4x2_rr", 4, 2, arb=1, regions=((0x00000000, 0xFFFF0000), (0x80000000, 0x80000000)),
    golden=(
        (None, 0x00000000, 0), (None, 0x0000FFFC, 0), (None, 0x00010000, "unmapped"), (None, 0x7FFFFFFC, "unmapped"),
        (None, 0x80000000, 1), (None, 0xFFFFFFFC, 1), (None, 0x90000000, 1), (None, 0x00010004, "unmapped"),
        (None, 0x80000001, "misaligned"),
    ),
    note="more masters than slaves; 2 GiB region with a single mask bit",
)

# 2x4 round robin: s0 4 KiB at 0, s1 sparse (non contiguous) mask, s2 16 KiB, s3 top 4 KiB
#   s1: (addr & 0x0F0FF000) == 0x0A003000  -> addr[27:24] == 0xA and addr[19:12] == 0x03, other bits free
CFG_2X4_RR = XCfg(
    "xbar_2x4_rr", 2, 4, arb=1,
    regions=((0x00000000, 0xFFFFF000), (0x0A003000, 0x0F0FF000), (0x20000000, 0xFFFFC000), (0xFFFFF000, 0xFFFFF000)),
    golden=(
        (None, 0x00000000, 0), (None, 0x00000FFC, 0), (None, 0x00001000, "unmapped"),
        (None, 0x0A003000, 1), (None, 0x0A003FFC, 1), (None, 0x1A003000, 1), (None, 0xFA003ABC & ~3, 1), (None, 0x0AF03000, 1),
        (None, 0x0A004000, "unmapped"), (None, 0x0A002FFC, "unmapped"), (None, 0x0B003000, "unmapped"), (None, 0x09003000, "unmapped"),
        (None, 0x20000000, 2), (None, 0x20003FFC, 2), (None, 0x20004000, "unmapped"), (None, 0x1FFFFFFC, "unmapped"),
        (None, 0xFFFFF000, 3), (None, 0xFFFFFFFC, 3), (None, 0xFFFFEFFC, "unmapped"), (None, 0x0A003002, "misaligned"),
    ),
    note="sparse mask region, region at 0, region touching 0xFFFFFFFF",
)

# 2x2 DW 64: adjacent 64 KiB windows
G_DW64 = (
    (None, 0x0FFFFFF8, "unmapped"), (None, 0x10000000, 0), (None, 0x1000FFF8, 0), (None, 0x10010000, 1),
    (None, 0x1001FFF8, 1), (None, 0x10020000, "unmapped"), (None, 0x10000004, "misaligned"), (None, 0x10000001, "misaligned"),
    (None, 0x1000FFFC, "misaligned"), (None, 0x10010007, "misaligned"),
)
R_2X2 = ((0x10000000, 0xFFFF0000), (0x10010000, 0xFFFF0000))
CFG_2X2_DW64 = XCfg("xbar_2x2_dw64", 2, 2, dw=64, arb=1, regions=R_2X2, golden=G_DW64, note="64-bit data path, 8-byte alignment")

# 3x2 DW 128: s0 4 KiB at 0, s1 64 KiB at 0x20000000; m2 may only reach s1
CFG_3X2_DW128 = XCfg(
    "xbar_3x2_dw128", 3, 2, dw=128, arb=1, regions=((0x00000000, 0xFFFFF000), (0x20000000, 0xFFFF0000)), en=((1, 1), (1, 1), (0, 1)),
    golden=(
        (0, 0x00000000, 0), (0, 0x00000FF0, 0), (0, 0x00001000, "unmapped"), (0, 0x20000000, 1), (0, 0x2000FFF0, 1),
        (0, 0x20010000, "unmapped"), (2, 0x00000000, "denied"), (2, 0x00000FF0, "denied"), (2, 0x20000000, 1),
        (1, 0x00000008, "misaligned"), (1, 0x20000004, "misaligned"), (1, 0x2000000F, "misaligned"),
    ),
    note="128-bit data path (16 byte lanes), partial matrix",
)

# 2x2 CHECK_ALIGN = 0: misaligned requests are forwarded to the slave unchanged
CFG_2X2_NOAL = XCfg(
    "xbar_2x2_noal", 2, 2, align=0, regions=R_2X2,
    golden=(
        (None, 0x10000000, 0), (None, 0x10000001, 0), (None, 0x1000FFFF, 0), (None, 0x10010002, 1), (None, 0x1001FFFF, 1),
        (None, 0x10020000, "unmapped"), (None, 0x0FFFFFFF, "unmapped"), (None, 0x10020003, "unmapped"),
    ),
    note="CHECK_ALIGN = 0: no alignment decode error",
)

# 2x3 overlapping regions (decoder header: lowest permitted slave wins) + catch-all slave 2 (base = mask = 0)
CFG_OVL = XCfg(
    "xbar_ovl", 2, 3, arb=1, regions=((0x10000000, 0xFFFF0000), (0x10000000, 0xFFFFF000), (0x00000000, 0x00000000)),
    en=((1, 1, 1), (0, 1, 1)),
    golden=(
        (0, 0x10000100, 0), (1, 0x10000100, 1), (0, 0x10008000, 0), (1, 0x10008000, 2), (0, 0x20000000, 2), (1, 0x20000000, 2),
        (0, 0x00000000, 2), (1, 0xFFFFFFFC, 2), (0, 0x10000001, "misaligned"),
    ),
    note="overlapping regions + catch-all region (all-zero mask) + access matrix interplay",
)

# 4x7: the real SilicaFlux-V DataFabric map (MEMORY_MAP.md); masters CPUI(2) and DMA(3) are denied PERIPH(6)
SOC_REGIONS = (
    (0x00000000, 0xFFFFF000),  # 0 BOOT_ROM 4 KiB
    (0x10000000, 0xFFFF8000),  # 1 SRAM_BANK0 32 KiB
    (0x10008000, 0xFFFF8000),  # 2 SRAM_BANK1
    (0x10010000, 0xFFFF8000),  # 3 SRAM_BANK2
    (0x10018000, 0xFFFF8000),  # 4 SRAM_BANK3
    (0x20000000, 0xFFFFC000),  # 5 TSPM 16 KiB
    (0x40000000, 0xFFFE0000),  # 6 PERIPH 128 KiB
)
CFG_SOC = XCfg(
    "xbar_soc4x7", 4, 7, arb=1, regions=SOC_REGIONS,
    en=((1,) * 7, (1,) * 7, (1, 1, 1, 1, 1, 1, 0), (1, 1, 1, 1, 1, 1, 0)),
    golden=(
        (None, 0x00000000, 0), (None, 0x00000FFC, 0), (None, 0x00001000, "unmapped"),
        (None, 0x10000000, 1), (None, 0x10007FFC, 1), (None, 0x10008000, 2), (None, 0x1000FFFC, 2), (None, 0x10010000, 3),
        (None, 0x10017FFC, 3), (None, 0x10018000, 4), (None, 0x1001FFFC, 4), (None, 0x10020000, "unmapped"),
        (None, 0x20000000, 5), (None, 0x20003FFC, 5), (None, 0x20004000, "unmapped"),
        (0, 0x40000000, 6), (1, 0x4001FFFC, 6), (2, 0x40000000, "denied"), (3, 0x4001FFFC, "denied"), (None, 0x40020000, "unmapped"),
        (2, 0x10000000, 1), (3, 0x20000000, 5), (None, 0x30000000, "unmapped"), (None, 0x20000002, "misaligned"),
    ),
    note="real SoC configuration: 4 masters x 7 slaves, execute-never peripherals for CPUI/DMA",
)

CONFIGS: Dict[str, XCfg] = {c.name: c for c in (
    CFG_1X1, CFG_2X2_FX, CFG_3X3_RR, CFG_3X3_PART, CFG_4X2_RR, CFG_2X4_RR, CFG_2X2_DW64, CFG_3X2_DW128, CFG_2X2_NOAL, CFG_OVL, CFG_SOC)}


def cfg_from_env(name: str) -> XCfg:
    return CONFIGS[name]
