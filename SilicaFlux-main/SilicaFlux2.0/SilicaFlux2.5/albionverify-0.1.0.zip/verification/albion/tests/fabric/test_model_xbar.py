"""pytest (no simulator): the cycle model of the crossbar on hand-traced scenarios (PROTOCOL.md R5/R6, sec. 3-5)."""
from albionverify.models.fabric_decoder import AddressMap
from albionverify.models.fabric_xbar import XbarModel, XIn

# 2 masters x 2 slaves: s0 = 0x1000_0000/64K, s1 = 0x1001_0000/64K, full matrix, DW 32
AMAP = AddressMap([0x10000000, 0x10010000], [0xFFFF0000, 0xFFFF0000], [[1, 1], [1, 1]], dw=32)


def xin(nm=2, ns=2, **kw):
    d = dict(m_valid=[0] * nm, m_write=[0] * nm, m_addr=[0] * nm, m_wdata=[0] * nm, m_wstrb=[0] * nm, m_rsp_ready=[1] * nm,
             s_ready=[1] * ns, s_rsp_valid=[0] * ns, s_rsp_rdata=[0] * ns, s_rsp_err=[0] * ns)
    d.update(kw)
    return XIn(**d)


def cycle(mod, x):
    o = mod.evaluate(x)
    mod.commit(x, o)
    return o


def test_model_single_read_full_throughput():
    mod = XbarModel(AMAP, 2, 2, 1)
    # cycle 0: master 0 reads s0 -> accepted at once (combinational ready), forwarded unchanged
    o = cycle(mod, xin(m_valid=[1, 0], m_addr=[0x10000040, 0]))
    assert o.m_req_ready == [1, 0] and o.s_req_valid == [1, 0] and o.s_req_addr[0] == 0x10000040
    assert o.m_rsp_valid == [0, 0]  # never in the acceptance cycle (R5)
    # cycle 1: slave answers; master presents its NEXT request in the same cycle: accepted (no bubble)
    o = cycle(mod, xin(m_valid=[1, 0], m_addr=[0x10000044, 0], s_rsp_valid=[1, 0], s_rsp_rdata=[0xCAFE, 0]))
    assert o.m_rsp_valid == [1, 0] and o.m_rsp_rdata[0] == 0xCAFE and o.s_rsp_ready[0] == 1
    assert o.m_req_ready == [1, 0] and o.s_req_valid == [1, 0]  # slave re-granted in the cycle its response is accepted


def test_model_second_request_waits_for_response_acceptance():
    mod = XbarModel(AMAP, 2, 2, 1)
    cycle(mod, xin(m_valid=[1, 0], m_addr=[0x10000000, 0]))
    # response stalled (m_rsp_ready = 0): master's next request must NOT be accepted, slave stays busy
    o = cycle(mod, xin(m_valid=[1, 0], m_addr=[0x10000004, 0], m_rsp_ready=[0, 1], s_rsp_valid=[1, 0]))
    assert o.m_req_ready == [0, 0] and o.s_req_valid == [0, 0] and o.s_rsp_ready[0] == 0
    assert o.ev_req_stall == [1, 0] and o.ev_rsp_stall == [1, 0]
    # another master to the same busy slave is blocked too
    o = cycle(mod, xin(m_valid=[1, 1], m_addr=[0x10000004, 0x10000008], m_rsp_ready=[0, 1], s_rsp_valid=[1, 0]))
    assert o.s_req_valid == [0, 0]
    # response accepted: master 0 (higher priority in RR after reset pointer 0? pointer 1 after the first accept) -> master 1 wins
    o = cycle(mod, xin(m_valid=[1, 1], m_addr=[0x10000004, 0x10000008], m_rsp_ready=[1, 1], s_rsp_valid=[1, 0]))
    assert o.m_rsp_valid == [1, 0]
    assert o.winner[0] == 0 or o.winner[0] == 1
    assert o.s_req_valid == [1, 0] and o.m_req_ready[o.winner[0]] == 1


def test_model_arbitration_loss_events_and_order():
    mod = XbarModel(AMAP, 2, 2, 1)
    o = cycle(mod, xin(m_valid=[1, 1], m_addr=[0x10000000, 0x10000010]))
    assert o.winner[0] == 0 and o.m_req_ready == [1, 0]
    assert o.ev_arb_loss == [0, 1] and o.ev_req_stall == [0, 1] and o.ev_req_accept == [1, 0]
    # next cycle: response of m0 accepted; round robin pointer moved to 1 -> m1 wins now
    o = cycle(mod, xin(m_valid=[1, 1], m_addr=[0x10000020, 0x10000010], s_rsp_valid=[1, 0]))
    assert o.winner[0] == 1 and o.m_req_ready == [0, 1] and o.ev_arb_loss == [1, 0]


def test_model_decode_error_one_cycle_and_capture_priority():
    mod = XbarModel(AMAP, 2, 2, 1)
    # both masters issue unmapped requests in the same cycle: both accepted, master 0 captured
    o = cycle(mod, xin(m_valid=[1, 1], m_addr=[0x90000000, 0xA0000000], m_write=[0, 1]))
    assert o.m_req_ready == [1, 1] and o.s_req_valid == [0, 0] and o.m_rsp_valid == [0, 0]
    assert (o.err_evt, o.err_master, o.err_addr, o.err_write) == (1, 0, 0x90000000, 0)
    # one cycle later: error responses (rdata 0), held while rsp_ready = 0 for master 1
    o = cycle(mod, xin(m_valid=[0, 0], m_rsp_ready=[1, 0]))
    assert o.m_rsp_valid == [1, 1] and o.m_rsp_err == [1, 1] and o.m_rsp_rdata == [0, 0] and o.err_evt == 0
    o = cycle(mod, xin(m_valid=[0, 0], m_rsp_ready=[1, 1]))
    assert o.m_rsp_valid == [0, 1]  # master 0 done, master 1 still held
    # lone error from master 1 (master 0 idle): captured with master index 1
    mod.reset()
    o = cycle(mod, xin(m_valid=[0, 1], m_addr=[0, 0xB0000000], m_write=[0, 1]))
    assert (o.err_evt, o.err_master, o.err_write) == (1, 1, 1)


def test_model_error_path_back_to_back():
    mod = XbarModel(AMAP, 2, 2, 1)
    cycle(mod, xin(m_valid=[1, 0], m_addr=[0x90000000, 0]))
    # next error request accepted in the very cycle the previous error response is accepted
    o = cycle(mod, xin(m_valid=[1, 0], m_addr=[0x90000004, 0]))
    assert o.m_rsp_valid[0] == 1 and o.m_req_ready[0] == 1 and o.err_evt == 1


def test_model_response_goes_only_to_owner_and_ready_is_steered_back():
    mod = XbarModel(AMAP, 2, 2, 1)
    cycle(mod, xin(m_valid=[0, 1], m_addr=[0, 0x10010000]))  # master 1 -> slave 1
    o = cycle(mod, xin(m_rsp_ready=[1, 0], s_rsp_valid=[0, 1], s_rsp_rdata=[0, 0x55]))
    assert o.m_rsp_valid == [0, 1] and o.m_rsp_rdata[1] == 0x55
    assert o.s_rsp_ready[1] == 0 and o.s_rsp_ready[0] is None  # owner's ready steered back; idle slave unconstrained


def test_model_reset_clears_everything():
    mod = XbarModel(AMAP, 2, 2, 1)
    cycle(mod, xin(m_valid=[1, 1], m_addr=[0x10000000, 0x90000000]))
    assert any(mod.out) and any(mod.busy)
    mod.reset()
    assert mod.out == [0, 0] and mod.busy == [0, 0] and mod.epend == [0, 0] and all(a.ptr == 0 and a.lock is None for a in mod.arb)


def test_model_grant_lock_under_slave_stall():
    mod = XbarModel(AddressMap([0], [0], [[1], [1], [1]]), 3, 1, 0)
    x = lambda **kw: xin(3, 1, **kw)
    # master 2 alone is presented and stalled; master 0 (higher priority) arrives: lock keeps master 2
    o = cycle(mod, x(m_valid=[0, 0, 1], s_ready=[0]))
    assert o.winner[0] == 2 and o.s_req_valid == [1] and o.m_req_ready == [0, 0, 0]
    o = cycle(mod, x(m_valid=[1, 0, 1], s_ready=[0]))
    assert o.winner[0] == 2
    o = cycle(mod, x(m_valid=[1, 0, 1], s_ready=[1]))
    assert o.winner[0] == 2 and o.m_req_ready == [0, 0, 1]
