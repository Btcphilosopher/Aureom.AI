"""Reproduction of documented RTL/spec discrepancies (registered with tag ``known_defect:<ID>``: they report XFAIL
while the discrepancy exists and XPASS -- a failure -- once the RTL is fixed or the annotation is stale).

DF-F1 (open, spec/RTL discrepancy, low severity)
  PROTOCOL.md R11: "During reset req_ready/rsp_valid of the fabric are 0, so reset can generate no transfer"
  (ARCHITECTURE.md sec. 3: "every master's req_valid is a reset flop; the fabric forwards nothing during reset").
  sfb_crossbar keeps rsp_valid at 0 in reset (all state is asynchronously cleared) but does NOT gate m_req_ready by
  reset: it is a combinational function of the master's req_valid, the decoder and the slave's req_ready.  A master that
  presents a request while reset is asserted therefore sees
    * decode errors (unmapped / denied / misaligned): m_req_ready = 1 in every reset cycle (the per-master error slave has
      pend_q = 0, so e_req_ready = 1);
    * slave-routed requests: s_req_valid = 1 (busy_q = 0 -> s_free = 1) and m_req_ready = the slave's s_req_ready.
  A transfer (valid && ready) can thus occur at a master port during reset if that master is not itself in reset; it
  believes the request accepted and no response ever follows.  The fabric state is NOT corrupted (reset_input_activity in
  cocotb_xbar_reset.py drives random junk on every input during reset: clean idle fabric, in lockstep with the model,
  after release).  Low severity because masters, fabric and slaves share sys_rst_n and every master's req_valid is a
  reset flop; the JTAG DBG master (TCK domain) is the one place where the literal sentence could matter.  Needed from
  the RTL owner: amend R11 ("... once the masters are in reset too") or gate m_req_ready / s_req_valid with a
  synchronised reset.  All other tests keep masters quiescent during reset (and check it).
  Reproduce:  python -m albionverify run --dut xbar_3x3_rr --module fabric.cocotb_xbar_known --seed 1
  Reported to the lead as DF-F1 (no separate findings file: the harness refused to create one).
"""
import cocotb

from albionverify.core import AlbionCheckError

from .xbar_tb import NM, NS, XbarTB, error_addr


@cocotb.test()
async def reset_req_ready_low(dut):
    tb = XbarTB(dut, "reset_req_ready_low", profile="dense", uniform=True)
    await tb.start()
    env = tb.env
    rng = env.seeds.child("df-f1")
    tb.chk.junk_in_reset = True
    addr, _ = error_addr(0, rng)
    target = tb.rst.n_pulses + 1
    tb.rst.pulse(length=8, delay=1, reason="DF-F1")
    await env.until(lambda: tb.rst.n_pulses >= target, 10, "reset start")
    while tb.rst.asserted:
        dut.m_req_valid.value = 1  # master 0 presents a (decode-error) request while reset is asserted, others idle
        dut.m_req_addr.value = addr
        await env.tick()
    seen = tb.chk.junk_obs["m_req_ready"]
    if seen:
        raise AlbionCheckError("R11: req_ready of the fabric was high in %d of %d reset cycles while master 0 presented a request (a transfer is possible during reset)" % (seen, tb.chk.junk_obs["cycles"]))
    await tb.finish("reset_req_ready_low")
