"""Seeded constrained-random crossbar traffic: N simultaneous masters, boundary-biased + hot (shared) + unmapped +
denied + misaligned addresses, random sparse strobes, random stalls on every handshake, slave error injection,
request withdrawal.  Every transaction is checked by the lockstep model and the data scoreboard (xbar_tb.py).
The timing profile (stall regime) of each run is a function of (seed, test), so different seeds explore different
back-pressure regimes; everything is derived from ALBION_SEED (deterministic)."""
import os

import cocotb

from .xbar_tb import NM, NS, XbarTB

ORDER = ("mixed", "dense", "slave_bp", "rsp_bp", "slow")


def seed() -> int:
    return int(os.environ.get("ALBION_SEED", "1"))


def profile_for(offset: int) -> str:
    return ORDER[(seed() + offset) % len(ORDER)]


def per_master(total: int) -> int:
    return max(60, total // max(1, NM))


async def run(dut, name: str, offset: int, total: int, weights=None, **kw) -> None:
    tb = XbarTB(dut, name, profile=kw.pop("profile", None) or profile_for(offset), **kw)
    await tb.start()
    n = per_master(total)
    tb.fill_random(n, weights=weights)
    await tb.drain(max_cycles=400 * n * NM + 5000)
    await tb.finish(name, profile=tb.tname)


@cocotb.test()
async def random_mix(dut):
    """Mixed traffic (all address classes) ~800 transactions."""
    await run(dut, "random_mix", 0, 800)


@cocotb.test()
async def random_errors(dut):
    """Error-heavy: ~55 % decode errors (unmapped / denied / misaligned) plus slave errors (poisoned window + random)."""
    await run(dut, "random_errors", 1, 600, weights=dict(edge=0.10, hot=0.10, inside=0.10, unmapped=0.30, denied=0.15, misal=0.25),
              slave_err="random:0.2+window:0x40")


@cocotb.test()
async def random_withdraw(dut):
    """Masters withdraw / replace un-accepted requests (R2 violation the fabric must tolerate): no loss, no duplicate,
    no phantom request; lock released when the locked master withdraws."""
    await run(dut, "random_withdraw", 2, 600, withdraw=0.08)


@cocotb.test()
async def random_hot(dut):
    """Same few addresses from every master (reference defined by slave-side acceptance order)."""
    await run(dut, "random_hot", 3, 700, weights=dict(edge=0.0, hot=0.9, inside=0.05, unmapped=0.02, denied=0.0, misal=0.03, write=0.55))


@cocotb.test()
async def random_backpressure(dut):
    """Extreme back-pressure on every handshake (slow profile, long stalls) with contention."""
    await run(dut, "random_backpressure", 0, 400, profile="slow", weights=dict(hot=0.4, edge=0.2, inside=0.2, unmapped=0.08, denied=0.05, misal=0.07))
