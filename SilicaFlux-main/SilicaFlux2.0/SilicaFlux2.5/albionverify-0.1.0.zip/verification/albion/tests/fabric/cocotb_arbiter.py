"""Unit bench for ``sfb_arbiter`` (req/stall/accept -> grant).

Checking: (1) cycle-exact lockstep against albionverify.models.fabric_arbiter (grant vector, grant_idx,
grant_valid every cycle); (2) independent properties straight from PROTOCOL.md sec. 4: one-hot grant that is
a subset of req, work conservation (grant_valid == |req), grant lock, fixed-priority = lowest index, round
robin bounded waiting (<= N-1 other acceptances), no grant movement from a stalled (un-accepted) grant, reset
state.  Stimulus: saturating, independent-random (withdrawals included), persistent (R2-compliant) and
sparse requesters under random / bursty / long slave stalls, reset (sync, async mid-cycle, sub-cycle glitch).
"""
import json
import os

import cocotb
from cocotb.triggers import RisingEdge, Timer

from albionverify.core import Agent, AlbionCheckError, Env
from albionverify.coverage import CoverGroup
from albionverify.models.fabric_arbiter import ArbiterModel, rr_wait_bound
from albionverify.reset import ResetSequencer
from albionverify.rng import Throttle

P = json.loads(os.environ.get("ALBION_PARAMS", "{}"))
N = int(P.get("N", 4))
MODE = int(P.get("MODE", 1))


def popcount(v: int) -> int:
    return bin(v).count("1")


def bits(lst) -> int:
    return sum(1 << i for i, b in enumerate(lst) if b)


class ArbBench(Agent):
    def __init__(self, env: Env, rng):
        super().__init__("arb")
        self.rng = rng
        self.model = ArbiterModel(N, MODE)
        s = env.sig
        self.s_req, self.s_stall, self.s_acc = s("req"), s("stall"), s("accept")
        self.s_grant, self.s_idx, self.s_gv = s("grant"), s("grant_idx"), s("grant_valid")
        self.pending = [False] * N
        self.wait = [0] * N  # other acceptances seen while this requester continuously requested
        self.max_wait = 0
        self.prev_req = 0
        self.prev_win = None
        self.prev_stalled = False
        self.rst_cycles = 0
        self.n_cycles = 0
        self.n_acc = [0] * N
        self.n_stall = 0
        self.n_lock_cycles = 0
        self.n_checks = 0
        self.max_stall_run = 0
        self._stall_run = 0
        self.set_phase()
        self.cg = CoverGroup("arb_unit", "arbiter grant / lock / contention coverage")
        self.cg.point("winner", list(range(N)))
        self.cg.point("nreq", list(range(1, N + 1)))
        self.cg.cross("nreq_winner", ["nreq", "winner"], ignore=(lambda b: int(b[1]) > N - int(b[0])) if MODE == 0 else None)
        self.cg.point("event", ["accept", "stall_start", "lock_hold", "lock_release_withdraw", "idle_no_req", "stall_no_lock_needed"])
        self.cg.point("stall_run", ["1", "2-3", "4-7", "8+"])
        self.cg.point("ptr", list(range(N)) if MODE == 1 else [])  # the pointer only exists in round-robin mode
        self.cg.cross("ptr_winner", ["ptr", "winner"])
        env.coverage.append(self.cg)

    def set_phase(self, kind="persistent", p_req=0.5, present="always", ready="always", mask=None):
        self.kind, self.p_req, self.mask = kind, p_req, mask
        self.present_thr = Throttle(self.rng, present)
        self.ready_thr = Throttle(self.rng, ready)

    # ------------------------------------------------------------------------------------------- sample
    def _fail(self, msg: str) -> None:
        self.env.error("arbiter: " + msg)

    def sample(self) -> None:
        env = self.env
        if env.in_reset:
            self.rst_cycles += 1
            return
        self.rst_cycles = 0
        self.n_cycles += 1
        req, stall, acc = self.s_req.read(), self.s_stall.read(), self.s_acc.read()
        grant, idx, gv = self.s_grant.read(), self.s_idx.read(), self.s_gv.read()
        rl = [(req >> i) & 1 for i in range(N)]
        m = self.model
        w = m.select(rl)
        exp_grant = 0 if w is None else (1 << w)
        env.digest.event("arb", self.n_cycles, req, stall, acc, grant, idx, gv)
        # ---- layer 1: lockstep
        self.n_checks += 3
        if grant != exp_grant:
            self._fail("grant 0x%x, model expects 0x%x (req=0x%x stall=%d accept=%d ptr=%d lock=%s)" % (grant, exp_grant, req, stall, acc, m.ptr, m.lock))
        if gv != int(w is not None):
            self._fail("grant_valid=%d, model expects %d (req=0x%x)" % (gv, int(w is not None), req))
        if w is not None and idx != w:
            self._fail("grant_idx=%d, model expects %d (req=0x%x ptr=%d lock=%s)" % (idx, w, req, m.ptr, m.lock))
        # ---- layer 2: independent properties (from the DUT's own outputs)
        self.n_checks += 6
        if grant & ~req:
            self._fail("grant 0x%x contains a requester that is not requesting (req=0x%x)" % (grant, req))
        if popcount(grant) > 1:
            self._fail("grant 0x%x is not one-hot" % grant)
        if gv != int(grant != 0) or gv != int(req != 0):
            self._fail("work conservation / grant_valid: req=0x%x grant=0x%x grant_valid=%d" % (req, grant, gv))
        if grant and idx != grant.bit_length() - 1:
            self._fail("grant_idx %d does not match grant 0x%x" % (idx, grant))
        if stall and acc:
            self._fail("bench error: stall and accept both asserted")
        win = (grant.bit_length() - 1) if grant else None
        locked_case = self.prev_stalled and self.prev_win is not None and ((req >> self.prev_win) & 1)
        if locked_case and win != self.prev_win:
            self._fail("grant lock violated: requester %d was presented and stalled last cycle and still requests, but the grant moved to %s" % (self.prev_win, win))
        if not locked_case and win is not None and MODE == 0:
            lowest = (req & -req).bit_length() - 1
            if win != lowest:
                self._fail("fixed priority violated: req=0x%x, granted %d, lowest index is %d" % (req, win, lowest))
        # ---- bounded waiting (round robin): other acceptances while a requester continuously requests
        for i in range(N):
            if not (req >> i) & 1:
                self.wait[i] = 0
            elif acc and win == i:
                self.wait[i] = 0
            elif acc:
                self.wait[i] += 1
                self.max_wait = max(self.max_wait, self.wait[i])
                if MODE == 1 and self.wait[i] > rr_wait_bound(N):
                    self._fail("round-robin bounded waiting violated: requester %d waited through %d other acceptances (bound %d)" % (i, self.wait[i], rr_wait_bound(N)))
        # ---- coverage
        cg = self.cg
        if win is not None and acc:
            cg.sample(winner=win, nreq=popcount(req))
            if MODE == 1:
                cg.sample(ptr=m.ptr)
                cg.sample(ptr=m.ptr, winner=win)
            self.n_acc[win] += 1
        if acc:
            cg.sample(event="accept")
        if stall:
            self.n_stall += 1
            self._stall_run += 1
            self.max_stall_run = max(self.max_stall_run, self._stall_run)
            if not self.prev_stalled:
                cg.sample(event="stall_start")
        else:
            if self._stall_run:
                cg.sample(stall_run="1" if self._stall_run == 1 else "2-3" if self._stall_run <= 3 else "4-7" if self._stall_run <= 7 else "8+")
            self._stall_run = 0
        if locked_case:
            cg.sample(event="lock_hold")
            self.n_lock_cycles += 1
        elif self.prev_stalled and self.prev_win is not None:
            cg.sample(event="lock_release_withdraw")
        if req == 0:
            cg.sample(event="idle_no_req")
        if stall and popcount(req) == 1:
            cg.sample(event="stall_no_lock_needed")
        # ---- advance the model with what the DUT saw
        presented = bool(stall or acc)
        m.step(w, presented, bool(acc))
        if acc and w is not None:
            self.pending[w] = False
        self.prev_stalled = bool(stall)
        self.prev_win = w
        self.prev_req = req

    # ------------------------------------------------------------------------------------------- drive
    def drive(self) -> None:
        env = self.env
        if env.in_reset:
            self.s_req.write(0)
            self.s_stall.write(0)
            self.s_acc.write(0)
            self.pending = [False] * N
            return
        rng, k = self.rng, self.kind
        if k == "saturate":
            rl = [True] * N
        elif k == "random":
            rl = [rng.random() < self.p_req for _ in range(N)]
        elif k == "subset":
            rl = [bool((self.mask >> i) & 1) for i in range(N)]
        else:  # persistent: assert and hold until accepted, then idle for a random while
            for i in range(N):
                if not self.pending[i] and rng.random() < self.p_req:
                    self.pending[i] = True
            rl = list(self.pending)
        req = bits(rl)
        w = self.model.select(rl)
        p_ok = self.present_thr.allow()
        ready = self.ready_thr.allow()
        presented = w is not None and p_ok
        self.s_req.write(req)
        self.s_stall.write(int(presented and not ready))
        self.s_acc.write(int(presented and ready))

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            self.model.reset()
            self.pending = [False] * N
            self.wait = [0] * N
            self.prev_stalled, self.prev_win = False, None
            self._stall_run = 0

    def summary(self) -> dict:
        return {"cycles": self.n_cycles, "accepts": self.n_acc, "stalled_cycles": self.n_stall, "lock_cycles": self.n_lock_cycles, "max_wait": self.max_wait,
                "max_stall_run": self.max_stall_run, "checks": self.n_checks}


async def setup(dut, name):
    import os as _os
    seed = int(_os.environ.get("ALBION_SEED", "1"))
    env = Env(dut, name=name, seed=seed)
    env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=4))
    ab = env.add(ArbBench(env, env.seeds.child("arb")))
    await env.start()
    await env.until(lambda: not env.agents[0].asserted, 50, "reset release")
    return env, ab


PHASES = [
    dict(kind="saturate", present="always", ready="always"),
    dict(kind="saturate", present="always", ready="random:0.5"),
    dict(kind="saturate", present="random:0.7", ready="bursty:1-8"),
    dict(kind="persistent", p_req=0.3, present="always", ready="random:0.6"),
    dict(kind="persistent", p_req=0.9, present="always", ready="bursty:2-12"),
    dict(kind="random", p_req=0.5, present="always", ready="random:0.5"),
    dict(kind="random", p_req=0.15, present="random:0.8", ready="random:0.7"),
    dict(kind="random", p_req=0.85, present="always", ready="bursty:1-5"),
    dict(kind="persistent", p_req=0.05, present="always", ready="always"),
    dict(kind="persistent", p_req=0.5, present="always", ready="never"),  # long total stall (then phase change releases)
]


@cocotb.test()
async def arb_phases(dut):
    """Sweep stimulus styles x slave stall regimes, 400-900 cycles each."""
    env, ab = await setup(dut, "arb_phases")
    rng = env.seeds.child("phase-len")
    for rep in range(3):
        for ph in PHASES:
            ab.set_phase(**ph)
            n = rng.randint(400, 900)
            if ph["ready"] == "never":
                n = 40
            await env.cycles(n)
    # fixed subsets: every non-empty subset of up to 3 requesters, then all
    for mask in range(1, 1 << min(N, 5)):
        ab.set_phase(kind="subset", mask=mask, present="always", ready="random:0.6")
        await env.cycles(60)
    env.finalize()
    env.write_result("arb_phases", arbiter=ab.summary(), func_cov_percent={"arb_unit": round(ab.cg.percent(), 1)})


@cocotb.test()
async def arb_fairness(dut):
    """Directed: all requesters saturate for 600 cycles with a 1-cycle accept path.  Round robin: every requester is
    served equally (+-1) in strict rotation; fixed priority: requester 0 takes everything (documented starvation)."""
    env, ab = await setup(dut, "arb_fairness")
    ab.set_phase(kind="saturate", present="always", ready="always")
    await env.cycles(4)  # earlier-phase requests drain
    acc0 = list(ab.n_acc)
    await env.cycles(600)
    acc = [a - b for a, b in zip(ab.n_acc, acc0)]
    if MODE == 1:
        if max(acc) - min(acc) > 1:
            raise AlbionCheckError("round robin shares not equal: %s" % acc)
        if ab.max_wait > N - 1:
            raise AlbionCheckError("max wait %d > N-1" % ab.max_wait)
    else:
        if acc[0] != sum(acc) or any(acc[1:]):
            raise AlbionCheckError("fixed priority under saturation: requester 0 must take every grant: %s" % acc)
        # lower requesters are served once the higher ones stop
        ab.set_phase(kind="subset", mask=((1 << N) - 1) & ~1, present="always", ready="always")
        await env.cycles(50)
        if N > 1 and ab.n_acc[1] - acc0[1] == 0:
            raise AlbionCheckError("lower priority requesters were never served after requester 0 stopped")
    env.finalize()
    env.write_result("arb_fairness", arbiter=ab.summary(), shares=acc, func_cov_percent={"arb_unit": round(ab.cg.percent(), 1)})


@cocotb.test()
async def arb_lock(dut):
    """Directed lock scenario: slave stalls for 10 cycles while a higher-priority requester joins; the stalled grant
    must hold; then the locked requester withdraws and arbitration resumes at once."""
    env, ab = await setup(dut, "arb_lock")
    if N < 2:
        env.finalize()
        env.write_result("arb_lock", arbiter=ab.summary())
        return
    for rep in range(6):
        # requester N-1 alone, slave stalls
        ab.set_phase(kind="subset", mask=1 << (N - 1), present="always", ready="never")
        await env.cycles(5)
        ab.set_phase(kind="subset", mask=(1 << (N - 1)) | 1, present="always", ready="never")  # requester 0 joins during the stall
        await env.cycles(8)
        if rep & 1:
            ab.set_phase(kind="subset", mask=1, present="always", ready="never")  # locked requester withdraws
            await env.cycles(4)
        ab.set_phase(kind="subset", mask=(1 << (N - 1)) | 1, present="always", ready="always")
        await env.cycles(12)
    env.finalize()
    env.write_result("arb_lock", arbiter=ab.summary(), func_cov_percent={"arb_unit": round(ab.cg.percent(), 1)})


@cocotb.test()
async def arb_reset(dut):
    """Reset in every kind of arbiter state (pointer advanced, lock engaged, idle), sync / async mid-cycle / glitch;
    afterwards the pointer is 0 and the lock clear (lockstep model reset)."""
    env, ab = await setup(dut, "arb_reset")
    rst = env.agents[0]
    rng = env.seeds.child("rst")
    for rnd in range(24):
        ab.set_phase(kind=rng.choice(["saturate", "persistent", "random"]), p_req=rng.choice([0.4, 0.8]), present="always", ready=rng.choice(["random:0.5", "bursty:2-6", "always"]))
        await env.cycles(rng.randint(5, 40))
        style = rnd % 3
        if style == 0:
            target = rst.n_pulses + 1
            rst.pulse(length=rng.randint(1, 3), delay=1, reason="sync")
            await env.until(lambda: rst.n_pulses >= target and not rst.asserted, 40, "sync reset")
        elif style == 1:
            cocotb.start_soon(rst.async_pulse(phase_ns=rng.randint(2, 18) / 2.0, length_cycles=rng.randint(1, 3)))
            await env.cycles(2)
            await env.until(lambda: not rst.asserted, 40, "async reset release")
        else:
            async def glitch():
                await RisingEdge(dut.clk)
                await Timer(2000, units="ps")
                dut.rst_n.value = 0
                rst.asserted = True
                rst.n_pulses += 1
                env.notify_reset(True)
                env.agents[1].drive()
                for sh in env.shadows.values():
                    sh.flush()
                await Timer(3000, units="ps")
                dut.rst_n.value = 1
                rst.asserted = False
                env.notify_reset(False)

            cocotb.start_soon(glitch())
            await env.cycles(2)
            await env.until(lambda: not rst.asserted, 10, "glitch release")
        # contention immediately after release: first arbitration must start from pointer 0
        ab.set_phase(kind="saturate", present="always", ready="random:0.7")
        await env.cycles(30)
    env.finalize()
    env.write_result("arb_reset", arbiter=ab.summary(), func_cov_percent={"arb_unit": round(ab.cg.percent(), 1)})
