"""Shared testbench for the DataFabric crossbar (sfb_crossbar): agents, lockstep reference-model checker,
transaction scoreboard, functional coverage, stimulus generators.

Checking layers (all active in every crossbar test):

1. LOCKSTEP model (albionverify.models.fabric_xbar): every cycle the expected value of every DUT output
   (m_req_ready, m_rsp_*, s_req_*, s_rsp_ready, err_*, ev_*) is computed from the OBSERVED inputs and the
   model's own registered state and compared with the DUT.  This pins arbitration (winner, lock, pointer),
   full-throughput timing, error-slave timing, ownership routing and the perf events cycle by cycle.
2. TRANSACTION scoreboard (independent of the lockstep model): every accepted master request must be accepted
   in the same cycle by exactly the slave the (hand-checked) address decoder selects, with identical payload;
   no slave acceptance without a master acceptance (invented/duplicated) and vice versa (lost); responses
   return to the owning master in order; read data is compared with a reference memory per slave that is
   updated in the slave-side acceptance order; slave errors propagate (err=1, rdata=0) with no side effect.
3. Independent PROPERTIES: R6 at master and slave ports, work conservation, no spurious slave request,
   fixed-priority winner, round-robin winner and bounded waiting (<= N-1), decode-error capture rule, R11
   quiescence under reset.
4. Passive ReqRspMonitor on every master and slave port (R2/R4/R5/R6/R8 protocol checks).
"""
from __future__ import annotations

import json
import os
import random
from collections import deque
from typing import Any, Deque, Dict, List, Optional, Sequence, Tuple

from albionverify.bus.reqrsp import Req, ReqRspMaster, ReqRspMonitor, ReqRspSlave, sfb_port
from albionverify.core import Agent, AlbionCheckError, Env
from albionverify.coverage import CoverGroup
from albionverify.inject import AnyOf, ErrorPolicy, RandomErrors
from albionverify.memory import BackingStore
from albionverify.models.fabric_decoder import AddressMap, Decode
from albionverify.models.fabric_xbar import XbarModel, XIn, XOut
from albionverify.reset import ResetSequencer
from albionverify.rng import Latency, Throttle
from albionverify.scoreboard import Scoreboard

from .xbar_cfg import CONFIGS, XCfg

P: Dict[str, Any] = json.loads(os.environ.get("ALBION_PARAMS", "{}"))
DUT_NAME = os.environ.get("ALBION_DUT", "")
CFG: Optional[XCfg] = CONFIGS.get(DUT_NAME)
NM = int(P.get("NM", 2))
NS = int(P.get("NS", 2))
DW = int(P.get("DW", 32))
AW = 32
NB = DW // 8
ARB = int(P.get("ARB_MODE", 1))
AMAP = AddressMap.from_params(P)
MASK_DW = (1 << DW) - 1
_PROBES = AMAP.all_probe_addresses()


def init_byte(s: int):
    """Distinct, address- and slave-dependent power-up content so that mis-routed reads cannot hide."""
    return lambda a: ((a * 131 + (a >> 9) * 7 + s * 37 + 11) ^ (a >> 5)) & 0xFF


def mem(s: int, name: str = "") -> BackingStore:
    return BackingStore(init_byte(s), name or "slv%d" % s)


# ---------------------------------------------------------------------------------------- stimulus helpers
class LowWindowErrors(ErrorPolicy):
    """Slave answers with an error for addresses whose low ``bits`` bits are below ``limit`` (a poisoned window
    inside every 4 KiB page).  Stimulus only: the reference model learns the outcome from the slave agent."""

    name = "low-window"

    def __init__(self, limit: int = 0x40, bits: int = 12, writes_only: Optional[bool] = None):
        self.limit, self.mask, self.wo = limit, (1 << bits) - 1, writes_only

    def decide(self, req, index, cycle) -> bool:
        if self.wo is True and not req.write:
            return False
        if self.wo is False and req.write:
            return False
        return (req.addr & self.mask) < self.limit


class WithdrawMaster(ReqRspMaster):
    """Master that sometimes withdraws or replaces a presented-but-not-accepted request (R2 violation tolerated
    by the fabric: PROTOCOL.md R2 note; verification doc: ``-GWITHDRAW=1`` style traffic)."""

    def __init__(self, *a, p_withdraw: float = 0.0, wrng: Optional[random.Random] = None, **kw):
        super().__init__(*a, **kw)
        self.pw = p_withdraw
        self.wrng = wrng or random.Random(1)
        self.n_withdrawn = 0
        self.force_withdraw = False  # directed tests: withdraw the stalled request at the next opportunity
        self._deny = Throttle(self.wrng, "never")

    def drive(self) -> None:
        go = self.cur is not None and self._v and self.req_stall_run > 0 and not self.env.in_reset and (self.force_withdraw or (self.pw and self.wrng.random() < self.pw))
        if go:
            forced, self.force_withdraw = self.force_withdraw, False
            self.n_withdrawn += 1
            t, self.cur = self.cur, None
            self.req_stall_run = 0
            if not forced and self.queue and self.wrng.random() < 0.5:
                self.queue.append(t)  # replace by the next request
                super().drive()
            else:
                self.queue.appendleft(t)  # drop valid for (at least) one cycle, then re-present
                saved, self.req_thr = self.req_thr, self._deny
                super().drive()
                self.req_thr = saved
            return
        super().drive()


PROFILES: Dict[str, Dict[str, Any]] = {
    # name: throttle specs (master request gaps, master rsp_ready, slave req_ready, slave rsp_valid), latency
    "dense": dict(req=["always"], rsp=["always"], sreq=["always"], srsp=["always"], lat=["fixed:1"]),
    "mixed": dict(req=["random:0.7", "always", "bursty:1-3"], rsp=["random:0.8", "always"], sreq=["random:0.7", "always"],
                  srsp=["random:0.8", "always"], lat=["uniform:1-3", "fixed:1"]),
    "slave_bp": dict(req=["always", "random:0.9"], rsp=["random:0.9", "always"], sreq=["bursty:1-8", "random:0.4"],
                     srsp=["random:0.6", "always"], lat=["uniform:1-4", "fixed:1"]),
    "rsp_bp": dict(req=["always"], rsp=["bursty:1-12", "random:0.3"], sreq=["random:0.9", "always"], srsp=["always"], lat=["fixed:1", "uniform:1-2"]),
    "slow": dict(req=["random:0.3", "bursty:1-6"], rsp=["random:0.3", "bursty:1-5"], sreq=["random:0.3", "bursty:1-5"],
                 srsp=["random:0.4"], lat=["tail:1,0.2,12", "uniform:1-6"]),
}

REGIMES: Dict[str, Dict[str, str]] = {
    "fast": dict(req="always", rsp="always", sreq="always", srsp="always", lat="fixed:1"),
    "stall_slave": dict(req="always", rsp="always", sreq="bursty:2-7", srsp="always", lat="uniform:1-2"),
    "stall_rsp": dict(req="always", rsp="bursty:4-12", sreq="always", srsp="always", lat="fixed:1"),
    "slow_slave": dict(req="always", rsp="always", sreq="always", srsp="random:0.7", lat="uniform:3-8"),
}

STROBES = ("full", "rand", "byte", "zero", "alt")


def pick_strobe(rng: random.Random, nbytes: int) -> Optional[int]:
    k = rng.random()
    full = (1 << nbytes) - 1
    if k < 0.35:
        return None  # all lanes
    if k < 0.70:
        return rng.getrandbits(nbytes) or full
    if k < 0.85:
        return 1 << rng.randrange(nbytes)
    if k < 0.90:
        return 0
    return (0x55555555555555555555555555555555 >> rng.randrange(2)) & full


class Gen:
    """Seeded request generator with address classes biased to region boundaries, hot (shared) addresses,
    unmapped / denied / misaligned addresses."""

    def __init__(self, rng: random.Random, weights: Optional[Dict[str, float]] = None):
        self.rng = rng
        self.w = dict(edge=0.25, hot=0.20, inside=0.25, unmapped=0.10, denied=0.05, misal=0.07, write=0.5)
        if weights:
            self.w.update(weights)
        self.edge_pool = _PROBES
        self.hot: List[int] = []
        for s in range(NS):
            for _ in range(4):
                self.hot.append(AMAP.aligned(AMAP.bases[s] | (rng.getrandbits(32) & ~AMAP.masks[s] & 0xFFFF)))

    def region_addr(self, s: int) -> int:
        a = AMAP.bases[s] | (self.rng.getrandbits(32) & ~AMAP.masks[s] & 0xFFFFFFFF)
        return AMAP.aligned(a)

    def unmapped_addr(self, m: int) -> int:
        for _ in range(64):
            a = AMAP.aligned(self.rng.getrandbits(32))
            if AMAP.decode(m, a).kind == "unmapped":
                return a
        return 0xDEADBEE0 & ~(NB - 1)

    def denied_addr(self, m: int) -> Optional[int]:
        den = [s for s in range(NS) if not AMAP.en[m][s]]
        if not den:
            return None
        return self.region_addr(self.rng.choice(den))

    def addr(self, m: int) -> int:
        r, w = self.rng.random(), self.w
        a: Optional[int] = None
        if r < w["edge"]:
            a = self.rng.choice(self.edge_pool)
        elif r < w["edge"] + w["hot"]:
            a = self.rng.choice(self.hot)
        elif r < w["edge"] + w["hot"] + w["inside"]:
            a = self.region_addr(self.rng.randrange(NS))
        elif r < w["edge"] + w["hot"] + w["inside"] + w["unmapped"]:
            a = self.unmapped_addr(m)
        elif r < w["edge"] + w["hot"] + w["inside"] + w["unmapped"] + w["denied"]:
            a = self.denied_addr(m)
        if a is None:
            a = self.region_addr(self.rng.randrange(NS))
        if NB > 1 and self.rng.random() < w["misal"]:
            a |= self.rng.randint(1, NB - 1)
        return a & 0xFFFFFFFF

    def request(self, m: int) -> Req:
        a = self.addr(m)
        if self.rng.random() < self.w["write"]:
            return Req(True, a, self.rng.getrandbits(DW), pick_strobe(self.rng, NB))
        return Req(False, a)


# ---------------------------------------------------------------------------------------- reachability tables
def _build_reach():
    cand = set(_PROBES)
    for s in range(NS):
        for k in range(0, 64):
            cand.add(AMAP.aligned(AMAP.bases[s] + k * NB))
        for k in range(1, 8):
            cand.add(AMAP.aligned(AMAP.region_last(s) - k * NB))
    by_s: Dict[int, Dict[frozenset, List[int]]] = {s: {} for s in range(NS)}
    for a in sorted(cand):
        for s in range(NS):
            ms = frozenset(m for m in range(NM) if AMAP.decode(m, a).slave == s)
            if ms:
                by_s[s].setdefault(ms, []).append(a)
    return by_s


_BY_S = _build_reach()
REACH: Dict[int, List[int]] = {m: sorted(s for s in range(NS) if any(m in ms for ms in _BY_S[s])) for m in range(NM)}
SOLO: Dict[Tuple[int, int], List[int]] = {}
for _s in range(NS):
    for _ms, _addrs in _BY_S[_s].items():
        for _m in _ms:
            SOLO.setdefault((_m, _s), []).extend(_addrs)
CONT: Dict[int, Tuple[Tuple[int, ...], List[int]]] = {}
for _s in range(NS):
    if _BY_S[_s]:
        _ms, _addrs = max(_BY_S[_s].items(), key=lambda kv: (len(kv[0]), len(kv[1])))
        CONT[_s] = (tuple(sorted(_ms)), sorted(_addrs))
CONTENDED = [s for s in range(NS) if s in CONT and len(CONT[s][0]) >= 2]  # slaves several masters can reach with the same address


def error_addr(m: int, rng: random.Random, kinds: Sequence[str] = ("unmapped", "denied", "misaligned")) -> Tuple[int, str]:
    """An address that master m's decoder must answer with a decode error (kind chosen at random among those
    possible in this configuration)."""
    g = Gen(rng)
    order = list(kinds)
    rng.shuffle(order)
    for k in order:
        a: Optional[int] = None
        if k == "unmapped":
            a = g.unmapped_addr(m)
        elif k == "denied":
            a = g.denied_addr(m)
        elif k == "misaligned" and NB > 1:
            a = g.region_addr(rng.randrange(NS)) | rng.randint(1, NB - 1)
        if a is not None and AMAP.decode(m, a).error and AMAP.decode(m, a).kind == k:
            return a, k
    raise AlbionCheckError("no decode-error address exists for master %d in this configuration" % m)


def has_decode_errors(m: int) -> bool:
    try:
        error_addr(m, random.Random(0))
        return True
    except AlbionCheckError:
        return False


# ---------------------------------------------------------------------------------------- the checker
class Rec:
    __slots__ = ("uid", "m", "req", "dec", "tgt", "t_acc", "t_rsp", "slave_err", "slave_rdata", "rsp_err", "rsp_rdata", "kind")

    def __init__(self, uid, m, req, dec, tgt, t_acc):
        self.uid, self.m, self.req, self.dec, self.tgt, self.t_acc = uid, m, req, dec, tgt, t_acc
        self.t_rsp = None
        self.slave_err = False
        self.slave_rdata = 0
        self.rsp_err = None
        self.rsp_rdata = None
        self.kind = dec.kind


class _SlaveListener:
    def __init__(self, chk: "XbarChecker", s: int):
        self.chk, self.s = chk, s

    def req_accepted(self, agent, req, err, rdata):
        self.chk._slave_dec[self.s] = (req, bool(err), rdata)

    def req_cancelled(self, agent, req):
        pass


def bins_run(v: int) -> str:
    return "0" if v == 0 else "1" if v == 1 else "2-3" if v <= 3 else "4-7" if v <= 7 else "8+"


class XbarChecker(Agent):
    def __init__(self, name: str, tb: "XbarTB"):
        super().__init__(name)
        self.tb = tb
        self.model = XbarModel(AMAP, NM, NS, ARB)
        self.ref = [mem(s, "ref%d" % s) for s in range(NS)]
        self.mfifo: List[Deque[Rec]] = [deque() for _ in range(NM)]
        self.sinfl: List[Optional[Rec]] = [None] * NS
        self._slave_dec: List[Optional[tuple]] = [None] * NS
        self.sb: Optional[Scoreboard] = None
        self.uid = 0
        self.rst_cycles = 0
        self.n_resets = 0
        self.log: List[Rec] = []
        self.keep_log = True
        self.n_acc = [0] * NM
        self.n_rsp = [0] * NM
        self.n_to_slave = [0] * NS
        self.n_err_kind: Dict[str, int] = {}
        self.n_slave_err = 0
        self.ev_sum = {k: [0] * NM for k in ("accept", "stall", "loss", "rsp_stall")}
        self.n_cycles_active = 0
        self.rr_wait = [0] * NM
        self.rr_key: List[Optional[tuple]] = [None] * NM
        self.s_stall_run = [0] * NS
        self.s_stall_done = [0] * NS
        self.m_rspstall_done = [0] * NM
        self.m_wait = [0] * NM  # cycles a master's request has been presented
        self.m_rspstall = [0] * NM
        self.stalled_prev = [False] * NS
        self.last_acc_winner: List[Optional[int]] = [None] * NS
        self.max_rr_wait = 0
        self.max_s_stall = 0
        self.max_m_rspstall = 0
        self.n_lockstep = 0
        self.n_props = 0
        self.max_err_burst = 0
        self.junk_in_reset = False  # reset test that drives garbage on every input during reset: skip the quiescence check, record instead
        self.junk_obs = {"m_req_ready": 0, "s_req_valid": 0, "m_rsp_valid": 0, "cycles": 0}
        self.reset_cov: Optional[CoverGroup] = None
        self.reset_kind = "sync"
        self.cov_hooks: List[Any] = []
        self.cycle_hooks: List[Any] = []  # called with (x, o, d) every non-reset cycle (reset-test coverage)

    # ---- plumbing
    def bind(self) -> None:
        env = self.env
        self.sb = Scoreboard(env, "xbar")
        tb = self.tb
        self.pm = [tb.pm[m] for m in range(NM)]
        self.ps = [tb.ps[s] for s in range(NS)]
        self.sg = {k: env.sig(k) for k in ("err_evt", "err_addr", "err_master", "err_write", "ev_req_accept", "ev_req_stall", "ev_arb_loss", "ev_rsp_stall")}

    def fail(self, msg: str) -> None:
        self.sb.fail(msg)

    def _ctx(self, x: XIn, o: XOut) -> str:
        md = self.model
        return ("model state: out=%s busy=%s owner=%s epend=%s ptr=%s lock=%s | winner=%s m_free=%s s_free=%s | in: m_valid=%s m_rsp_ready=%s s_ready=%s s_rsp_valid=%s | addr=%s"
                % (md.out, md.busy, md.owner, md.epend, [a.ptr for a in md.arb], [a.lock for a in md.arb], o.winner, o.m_free, o.s_free,
                   x.m_valid, x.m_rsp_ready, x.s_ready, x.s_rsp_valid, ["0x%x" % a for a in x.m_addr]))

    # ---- reads
    def _inputs(self) -> XIn:
        pm, ps = self.pm, self.ps
        return XIn(
            m_valid=[pm[m]["valid"].read() for m in range(NM)],
            m_write=[pm[m]["write"].read() for m in range(NM)],
            m_addr=[pm[m]["addr"].read() for m in range(NM)],
            m_wdata=[pm[m]["wdata"].read() for m in range(NM)],
            m_wstrb=[pm[m]["strb"].read() for m in range(NM)],
            m_rsp_ready=[pm[m]["rready"].read() for m in range(NM)],
            s_ready=[ps[s]["ready"].read() for s in range(NS)],
            s_rsp_valid=[ps[s]["rvalid"].read() for s in range(NS)],
            s_rsp_rdata=[ps[s]["rdata"].read() for s in range(NS)],
            s_rsp_err=[ps[s]["err"].read() for s in range(NS)],
        )

    def _outputs(self) -> Dict[str, Any]:
        pm, ps, sg = self.pm, self.ps, self.sg
        d = dict(
            m_req_ready=[pm[m]["ready"].read() for m in range(NM)],
            m_rsp_valid=[pm[m]["rvalid"].read() for m in range(NM)],
            m_rsp_rdata=[pm[m]["rdata"].read() for m in range(NM)],
            m_rsp_err=[pm[m]["err"].read() for m in range(NM)],
            s_req_valid=[ps[s]["valid"].read() for s in range(NS)],
            s_req_write=[ps[s]["write"].read() for s in range(NS)],
            s_req_addr=[ps[s]["addr"].read() for s in range(NS)],
            s_req_wdata=[ps[s]["wdata"].read() for s in range(NS)],
            s_req_wstrb=[ps[s]["strb"].read() for s in range(NS)],
            s_rsp_ready=[ps[s]["rready"].read() for s in range(NS)],
            err_evt=sg["err_evt"].read(), err_addr=sg["err_addr"].read(), err_master=sg["err_master"].read(), err_write=sg["err_write"].read(),
        )
        for k in ("ev_req_accept", "ev_req_stall", "ev_arb_loss", "ev_rsp_stall"):
            v = sg[k].read()
            d[k] = [(v >> m) & 1 for m in range(NM)]
        return d

    # ---- layer 1: lockstep
    def _lockstep(self, x: XIn, o: XOut, d: Dict[str, Any]) -> None:
        def eq(what: str, exp: Any, got: Any) -> None:
            self.n_lockstep += 1
            if exp != got:
                self.fail("LOCKSTEP %s: model expects %s, DUT drives %s  [%s]" % (what, hx(exp), hx(got), self._ctx(x, o)))

        for m in range(NM):
            eq("m_req_ready[%d]" % m, o.m_req_ready[m], d["m_req_ready"][m])
            eq("m_rsp_valid[%d]" % m, o.m_rsp_valid[m], d["m_rsp_valid"][m])
            if o.m_rsp_valid[m]:
                eq("m_rsp_rdata[%d]" % m, o.m_rsp_rdata[m], d["m_rsp_rdata"][m])
                eq("m_rsp_error[%d]" % m, o.m_rsp_err[m], d["m_rsp_err"][m])
            eq("ev_req_accept[%d]" % m, o.ev_req_accept[m], d["ev_req_accept"][m])
            eq("ev_req_stall[%d]" % m, o.ev_req_stall[m], d["ev_req_stall"][m])
            eq("ev_arb_loss[%d]" % m, o.ev_arb_loss[m], d["ev_arb_loss"][m])
            eq("ev_rsp_stall[%d]" % m, o.ev_rsp_stall[m], d["ev_rsp_stall"][m])
        for s in range(NS):
            eq("s_req_valid[%d]" % s, o.s_req_valid[s], d["s_req_valid"][s])
            if o.s_req_valid[s]:
                eq("s_req_write[%d]" % s, o.s_req_write[s], d["s_req_write"][s])
                eq("s_req_addr[%d]" % s, o.s_req_addr[s], d["s_req_addr"][s])
                if o.s_req_write[s]:
                    eq("s_req_wdata[%d]" % s, o.s_req_wdata[s], d["s_req_wdata"][s])
                    eq("s_req_wstrb[%d]" % s, o.s_req_wstrb[s], d["s_req_wstrb"][s])
            if o.s_rsp_ready[s] is not None:
                eq("s_rsp_ready[%d]" % s, o.s_rsp_ready[s], d["s_rsp_ready"][s])
        eq("err_evt", o.err_evt, d["err_evt"])
        if o.err_evt:
            eq("err_addr", o.err_addr, d["err_addr"])
            eq("err_master", o.err_master, d["err_master"])
            eq("err_write", o.err_write, d["err_write"])

    # ---- layer 2 + 3: transactions and properties (use DUT-observed handshakes, not the model's)
    def _txns(self, x: XIn, d: Dict[str, Any], now: int) -> Tuple[List[int], List[int], List[int], List[int]]:
        sb = self.sb
        has_out = [bool(len(self.mfifo[m])) for m in range(NM)]
        sbusy = [self.sinfl[s] is not None for s in range(NS)]
        resp_m = [m for m in range(NM) if d["m_rsp_valid"][m] and x.m_rsp_ready[m]]
        resp_s = [s for s in range(NS) if x.s_rsp_valid[s] and d["s_rsp_ready"][s]]
        # ---------------- responses
        handled = set()
        for m in resp_m:
            if not self.mfifo[m]:
                self.fail("response delivered to master %d which has no outstanding transaction (stale / misrouted response)" % m)
            T = self.mfifo[m][0]
            if T.t_acc >= now:
                self.fail("R5: response to master %d in the acceptance cycle of its request" % m)
            rsp_err, rsp_rdata = bool(d["m_rsp_err"][m]), d["m_rsp_rdata"][m]
            if T.tgt is None:
                exp_err, exp_rdata = True, 0
            else:
                s = T.tgt
                if self.sinfl[s] is not T:
                    self.fail("master %d response expected from slave %d but that slave holds a different transaction" % (m, s))
                if s not in resp_s:
                    self.fail("master %d received a response while slave %d performed no response handshake" % (m, s))
                if (x.s_rsp_rdata[s], bool(x.s_rsp_err[s])) != (rsp_rdata, rsp_err):
                    self.fail("response path altered slave %d response: slave drove (rdata=0x%x err=%d), master %d got (rdata=0x%x err=%d)"
                              % (s, x.s_rsp_rdata[s], x.s_rsp_err[s], m, rsp_rdata, rsp_err))
                handled.add(s)
                exp_err = T.slave_err
                wa = T.req.addr & ~(NB - 1)
                if exp_err:
                    exp_rdata = 0
                elif T.req.write:
                    exp_rdata = 0
                    self.ref[s].write_word(wa, T.req.wdata, T.req.strb, NB)
                else:
                    exp_rdata = None
                    msg = self.ref[s].check_word(wa, NB, rsp_rdata)
                    if msg:
                        self.fail("READ DATA m%d<-s%d addr=0x%x: %s" % (m, s, T.req.addr, msg))
                self.sinfl[s] = None
            if rsp_err != exp_err:
                self.fail("rsp_error mismatch for master %d txn %d (addr=0x%x %s kind=%s tgt=%s): expected %d got %d"
                          % (m, T.uid, T.req.addr, "wr" if T.req.write else "rd", T.kind, T.tgt, exp_err, rsp_err))
            if exp_rdata is not None and rsp_rdata != exp_rdata:
                self.fail("rsp_rdata mismatch for master %d txn %d (addr=0x%x %s): expected 0x%x got 0x%x" % (m, T.uid, T.req.addr, "wr" if T.req.write else "rd", exp_rdata, rsp_rdata))
            self.mfifo[m].popleft()
            T.t_rsp, T.rsp_err, T.rsp_rdata = now, rsp_err, rsp_rdata
            sb.complete("m%d" % m, T.uid)
            self.n_rsp[m] += 1
            self.m_rspstall_sample(m)
            self.env.digest.event("x.rsp", m, T.uid, rsp_rdata, int(rsp_err))
        for s in resp_s:
            if s in handled:
                continue
            T = self.sinfl[s]
            if T is not None:
                self.fail("slave %d response was consumed (rsp_ready) without being delivered to its owner master %d" % (s, T.m))
            self.fail("slave %d response handshake with no transaction recorded for it" % s)
        # ---------------- requests
        acc_m = [m for m in range(NM) if x.m_valid[m] and d["m_req_ready"][m]]
        acc_s = [s for s in range(NS) if d["s_req_valid"][s] and x.s_ready[s]]
        matched = set()
        errs_now: List[int] = []
        for m in acc_m:
            wr = bool(x.m_write[m])
            req = Req(wr, x.m_addr[m], x.m_wdata[m] if wr else 0, x.m_wstrb[m])
            dcd = AMAP.decode(m, req.addr)
            self.uid += 1
            tgt = dcd.slave if dcd.ok else None
            T = Rec(self.uid, m, req, dcd, tgt, now)
            if tgt is not None:
                s = tgt
                if s not in acc_s:
                    self.fail("master %d request (addr=0x%x) was accepted but slave %d did not accept it (lost request)" % (m, req.addr, s))
                if s in matched:
                    self.fail("two masters were accepted in one cycle for slave %d (one acceptance at the slave)" % s)
                matched.add(s)
                got = (d["s_req_write"][s], d["s_req_addr"][s], d["s_req_wdata"][s] if wr else 0, d["s_req_wstrb"][s] if wr else 0)
                exp = (int(wr), req.addr, req.wdata if wr else 0, x.m_wstrb[m] if wr else 0)
                if got != exp:
                    self.fail("slave %d received a request different from master %d's: master (wr=%d addr=0x%x wdata=0x%x wstrb=0x%x) slave (wr=%d addr=0x%x wdata=0x%x wstrb=0x%x)"
                              % (s, m, exp[0], exp[1], exp[2], exp[3], got[0], got[1], got[2], got[3]))
                if self.sinfl[s] is not None:
                    self.fail("R6: slave %d accepted a request while its previous transaction (master %d) is still outstanding" % (s, self.sinfl[s].m))
                ent = self._slave_dec[s]
                if ent is None:
                    self.fail("bench error: slave agent %d recorded no acceptance in the cycle the DUT forwarded a request" % s)
                T.slave_err, T.slave_rdata = ent[1], ent[2]
                self.sinfl[s] = T
                self.n_to_slave[s] += 1
                if T.slave_err:
                    self.n_slave_err += 1
            else:
                errs_now.append(m)
                self.n_err_kind[dcd.kind] = self.n_err_kind.get(dcd.kind, 0) + 1
            if len(self.mfifo[m]) >= 1:
                self.fail("R6: master port %d has a second transaction in flight (accepted before the previous response was accepted)" % m)
            self.mfifo[m].append(T)
            sb.accept("m%d" % m, T.uid, T)
            self.n_acc[m] += 1
            if self.keep_log and len(self.log) < 50000:
                self.log.append(T)
            self.env.digest.event("x.acc", m, -1 if tgt is None else tgt, req.addr, int(wr), req.wdata, x.m_wstrb[m] if wr else 0)
        for s in acc_s:
            if s not in matched:
                self.fail("slave %d accepted a request that no master had accepted in that cycle (invented or duplicated request)" % s)
        # ---------------- decode-error capture rule (independent of the model): lowest-index accepted error
        exp_evt = int(bool(errs_now))
        if d["err_evt"] != exp_evt:
            self.fail("err_evt=%d but %d decode error(s) were accepted this cycle" % (d["err_evt"], len(errs_now)))
        if errs_now:
            m0 = min(errs_now)
            exp = (x.m_addr[m0], m0, x.m_write[m0])
            got = (d["err_addr"], d["err_master"], d["err_write"])
            if got != exp:
                self.fail("err capture: expected (addr=0x%x master=%d write=%d) = lowest-index decode error, got (addr=0x%x master=%d write=%d)" % (exp + got))
            self.max_err_burst = max(self.max_err_burst, len(errs_now))
        # ---------------- independent arbitration / flow properties
        self._props(x, d, acc_m, acc_s, resp_m, resp_s, has_out, sbusy, errs_now)
        return acc_m, acc_s, resp_m, resp_s

    def m_rspstall_sample(self, m: int) -> None:
        self.max_m_rspstall = max(self.max_m_rspstall, self.m_rspstall[m])

    def _props(self, x, d, acc_m, acc_s, resp_m, resp_s, has_out, sbusy, errs_now) -> None:
        self.n_props += 1
        m_free = [(not has_out[m]) or (m in resp_m) for m in range(NM)]
        s_free = [(not sbusy[s]) or (s in resp_s) for s in range(NS)]
        dec = [AMAP.decode(m, x.m_addr[m]) if x.m_valid[m] else None for m in range(NM)]
        elig = [[m for m in range(NM) if x.m_valid[m] and m_free[m] and dec[m].ok and dec[m].slave == s] for s in range(NS)]
        winner_of = {}
        for m in acc_m:
            if dec[m].ok:
                winner_of[dec[m].slave] = m
        for s in range(NS):
            E = elig[s]
            if d["s_req_valid"][s] and not s_free[s]:
                self.fail("R6: slave %d request valid while the slave still has a transaction outstanding" % s)
            if s_free[s] and E and not d["s_req_valid"][s]:
                self.fail("work conservation: slave %d is free and master(s) %s are eligible but no request is presented" % (s, E))
            if d["s_req_valid"][s] and not E:
                self.fail("slave %d request valid with no eligible master (phantom request)" % s)
            if s in acc_s and not self.stalled_prev[s]:
                w = winner_of[s]
                if ARB == 0:
                    if w != min(E):
                        self.fail("fixed priority violated at slave %d: master %d accepted although master %d (higher priority) is eligible" % (s, w, min(E)))
                else:
                    ptr = 0 if self.last_acc_winner[s] is None else (self.last_acc_winner[s] + 1) % NM
                    nearest = min(E, key=lambda i: (i - ptr) % NM)
                    if w != nearest:
                        self.fail("round robin violated at slave %d: pointer %d, eligible %s, master %d won (expected %d)" % (s, ptr, E, w, nearest))
            if s in acc_s:
                self.last_acc_winner[s] = winner_of[s]
            self.stalled_prev[s] = bool(d["s_req_valid"][s] and not x.s_ready[s])
            if self.stalled_prev[s]:
                self.s_stall_run[s] += 1
                self.max_s_stall = max(self.max_s_stall, self.s_stall_run[s])
                self.s_stall_done[s] = 0
            else:
                self.s_stall_done[s] = self.s_stall_run[s]  # length of the stall that just ended (coverage sampling)
                self.s_stall_run[s] = 0
        # round-robin bounded waiting: other acceptances at the target slave while this master is eligible
        for m in range(NM):
            tgt = None
            if x.m_valid[m] and m_free[m]:
                tgt = dec[m].slave if dec[m].ok else None
            key = None if tgt is None else (tgt, x.m_addr[m], x.m_write[m], x.m_wdata[m] if x.m_write[m] else 0, x.m_wstrb[m])
            if key != self.rr_key[m]:
                self.rr_wait[m] = 0  # a different (replaced / withdrawn) request starts a new wait
                self.rr_key[m] = key
            if tgt is None or m in acc_m:
                self.rr_wait[m] = 0
            else:
                if tgt in acc_s:
                    self.rr_wait[m] += 1
                self.max_rr_wait = max(self.max_rr_wait, self.rr_wait[m])
                if ARB == 1 and self.rr_wait[m] > NM - 1:
                    self.fail("round-robin bounded waiting violated: master %d waited through %d other acceptances at slave %d (bound %d)" % (m, self.rr_wait[m], tgt, NM - 1))
            # response back-pressure duration
            if d["m_rsp_valid"][m] and not x.m_rsp_ready[m]:
                self.m_rspstall[m] += 1
                self.m_rspstall_done[m] = 0
            else:
                self.m_rspstall_done[m] = self.m_rspstall[m]
                self.m_rspstall[m] = 0
            self.max_m_rspstall = max(self.max_m_rspstall, self.m_rspstall[m])

    # ---- agent hooks
    def sample(self) -> None:
        env = self.env
        now = env.cycle
        if env.in_reset:
            self.rst_cycles += 1
            self._slave_dec = [None] * NS
            if self.junk_in_reset:
                d = self._outputs()
                self.junk_obs["cycles"] += 1
                for k in ("m_req_ready", "s_req_valid", "m_rsp_valid"):
                    self.junk_obs[k] += int(any(d[k]))
                if any(d["m_rsp_valid"]):
                    self.fail("R11: a response is valid during reset (m_rsp_valid=%s)" % d["m_rsp_valid"])
            elif self.rst_cycles >= 2:  # agents have presented their reset values for a full cycle (R11: no transfer in reset)
                d = self._outputs()
                for k in ("m_req_ready", "m_rsp_valid", "s_req_valid", "ev_req_accept", "ev_req_stall", "ev_arb_loss", "ev_rsp_stall"):
                    if any(d[k]):
                        self.fail("R11: %s asserted during reset (%s)" % (k, d[k]))
                if d["err_evt"]:
                    self.fail("R11: err_evt asserted during reset")
            return
        self.rst_cycles = 0
        x = self._inputs()
        d = self._outputs()
        o = self.model.evaluate(x)
        self._lockstep(x, o, d)
        acc_m, acc_s, resp_m, resp_s = self._txns(x, d, now)
        for k, key in (("accept", "ev_req_accept"), ("stall", "ev_req_stall"), ("loss", "ev_arb_loss"), ("rsp_stall", "ev_rsp_stall")):
            for m in range(NM):
                self.ev_sum[k][m] += d[key][m]
        for h in self.cov_hooks:
            h(x, o, d, acc_m, acc_s, resp_m, resp_s)
        for h in self.cycle_hooks:
            h(x, o, d)
        self.model.commit(x, o)
        self._slave_dec = [None] * NS

    def on_reset(self, asserted: bool) -> None:
        if not asserted:
            return
        self.n_resets += 1
        if self.reset_cov is not None:
            for st in self.reset_states():
                self.reset_cov.sample(state=st, kind=self.reset_kind)
        cancelled_writes = 0
        for s in range(NS):
            T = self.sinfl[s]
            if T is not None and T.req.write and not T.slave_err:
                self.ref[s].write_uncertain(T.req.addr & ~(NB - 1), T.req.wdata, T.req.strb, NB)  # R11: may or may not have landed
                cancelled_writes += 1
            self.sinfl[s] = None
        for m in range(NM):
            self.mfifo[m].clear()
            self.rr_wait[m] = 0
            self.rr_key[m] = None
            self.m_rspstall[m] = 0
        self.sb.cancel(reason="reset")
        self.model.reset()
        self._slave_dec = [None] * NS
        self.stalled_prev = [False] * NS
        self.last_acc_winner = [None] * NS
        self.s_stall_run = [0] * NS
        self.rst_cycles = 0
        self.env.digest.event("x.reset", self.env.cycle, cancelled_writes)

    def reset_states(self) -> List[str]:
        st = []
        if not any(self.mfifo) and all(t is None for t in self.sinfl) and not any(self.model.epend):
            st.append("idle")
        if any(self.stalled_prev):
            st.append("req_stalled")
        for t in self.sinfl:
            if t is not None:
                st.append("slave_write_inflight" if t.req.write else "slave_read_inflight")
        if any(self.model.epend):
            st.append("error_pending")
        if any(v > 0 for v in self.m_rspstall):
            st.append("rsp_stalled")
        return st

    def final_checks(self) -> None:
        tb = self.tb
        for m, a in enumerate(tb.masters):
            if a.n_accepted != self.n_acc[m]:
                self.fail("master agent %d counted %d accepted requests, checker saw %d" % (m, a.n_accepted, self.n_acc[m]))
            if a.n_completed != self.n_rsp[m]:
                self.fail("master agent %d counted %d responses, checker saw %d" % (m, a.n_completed, self.n_rsp[m]))
        for s, a in enumerate(tb.slaves):
            if len(a.log) != self.n_to_slave[s]:
                self.fail("slave %d accepted %d requests but the checker routed %d to it" % (s, len(a.log), self.n_to_slave[s]))
        # perf events against the agents' own cycle counters (independent of the model)
        for m, a in enumerate(tb.masters):
            if self.ev_sum["accept"][m] != a.n_accepted:
                self.fail("ev_req_accept[%d] counted %d, master agent accepted %d" % (m, self.ev_sum["accept"][m], a.n_accepted))
        if self.n_resets == 0 and not any(isinstance(a, WithdrawMaster) and a.pw for a in tb.masters):
            for m, a in enumerate(tb.masters):
                if self.ev_sum["stall"][m] != sum(t.req_stall_cycles for t in a.done):
                    self.fail("ev_req_stall[%d] counted %d cycles, master agent waited %d" % (m, self.ev_sum["stall"][m], sum(t.req_stall_cycles for t in a.done)))
                if self.ev_sum["rsp_stall"][m] != sum(t.rsp_stall_cycles for t in a.done):
                    self.fail("ev_rsp_stall[%d] counted %d cycles, master agent stalled %d" % (m, self.ev_sum["rsp_stall"][m], sum(t.rsp_stall_cycles for t in a.done)))
        # final memory equality: every byte the slave holds must be allowed by the reference
        for s, a in enumerate(tb.slaves):
            addrs = set(a.mem.written_addresses()) | set(self.ref[s].written_addresses())
            for ad in sorted(addrs):
                ok = self.ref[s].allowed(ad)
                got = a.mem.snapshot(ad, 1)[0]
                if ok is not None and got not in ok:
                    self.fail("final memory of slave %d differs from the reference at byte 0x%x: slave=0x%02x allowed=%s" % (s, ad, got, sorted(ok)))

    def finalize(self) -> None:
        pass

    def summary(self) -> dict:
        return {
            "accepted": sum(self.n_acc), "completed": sum(self.n_rsp), "to_slave": self.n_to_slave, "decode_errors": self.n_err_kind,
            "slave_errors": self.n_slave_err, "resets": self.n_resets, "checks": self.n_lockstep + self.n_props + self.sb.checks,
            "max_rr_wait": self.max_rr_wait, "max_slave_stall": self.max_s_stall, "max_rsp_stall": self.max_m_rspstall, "max_err_burst": self.max_err_burst,
            "ev": self.ev_sum,
        }


def hx(v: Any) -> str:
    return "0x%x" % v if isinstance(v, int) and not isinstance(v, bool) and v > 9 else str(v)


# ---------------------------------------------------------------------------------------- coverage
CAN_ERR_ANY = True  # every configuration has at least one decode-error address (misaligned at worst)


def make_coverage() -> Dict[str, CoverGroup]:
    g: Dict[str, CoverGroup] = {}
    tgts = list(range(NS)) + ["err"]

    c = CoverGroup("fab_txn", "transaction type x master x outcome target")
    c.point("op", ["rd", "wr"])
    c.point("master", list(range(NM)))
    c.point("tgt", tgts)
    c.cross("op_master_tgt", ["op", "master", "tgt"], ignore=lambda b: b[2] != "err" and int(b[2]) not in REACH[int(b[1])])
    g["txn"] = c

    c = CoverGroup("fab_addr", "address boundary classes per region (first/last/inside + adjacent unmapped)")
    c.point("region", list(range(NS)))
    c.point("edge", ["first", "last", "inside", "below", "above"])

    def _addr_possible(b) -> bool:
        s_, e_ = int(b[0]), b[1]
        if e_ in ("first", "last", "inside"):
            return any(AMAP.en[m][s_] for m in range(NM)) and (e_ != "inside" or AMAP.region_size(s_) > 2 * NB)
        a_ = (AMAP.region_first(s_) - NB) & 0xFFFFFFFF if e_ == "below" else ((AMAP.region_last(s_) & ~(NB - 1)) + NB) & 0xFFFFFFFF
        return any(not AMAP.decode(m, a_).ok for m in range(NM)) and not AMAP.matches(s_, a_)

    c.cross("region_edge", ["region", "edge"], ignore=lambda b: not _addr_possible(b))
    g["addr"] = c

    c = CoverGroup("fab_err", "error kinds x operation (only kinds that can occur in this configuration)")
    has_den = any(AMAP.decode(m, a).kind == "denied" for m in range(NM) for a in _PROBES)
    has_unm = any(AMAP.decode(m, a).kind == "unmapped" for m in range(NM) for a in _PROBES)
    kinds = (["unmapped"] if has_unm else []) + (["denied"] if has_den else []) + (["misaligned"] if AMAP.check_align else []) + ["slave_err"]
    c.point("kind", kinds)
    c.point("op", ["rd", "wr"])
    c.cross("kind_op", ["kind", "op"])
    c.point("burst", list(range(1, NM + 1)))  # decode errors accepted in the same cycle (capture contention)
    g["err"] = c

    c = CoverGroup("fab_arb", "arbitration contention and outcome (possible combinations derived from which masters can reach which slave)")

    def _possible(n: int, w: int) -> bool:
        for s_ in range(NS):
            for grp in _BY_S[s_]:
                if w in grp and len(grp) >= n and (ARB == 1 or sum(1 for x_ in grp if x_ > w) >= n - 1):
                    return True
        return False

    c.point("ncompete", sorted({n for n in range(1, NM + 1) if any(_possible(n, w) for w in range(NM))}))
    c.point("winner", sorted({w for w in range(NM) if _possible(1, w)}))
    c.cross("compete_winner", ["ncompete", "winner"], ignore=lambda b: not _possible(int(b[0]), int(b[1])))
    c.point("lock", (["stall_contended"] if CONTENDED else []) + ["stall_uncontended"])
    g["arb"] = c

    c = CoverGroup("fab_bp", "back-pressure durations")
    c.point("slave_stall", ["0", "1", "2-3", "4-7", "8+"])
    c.point("rsp_stall", ["0", "1", "2-3", "4-7", "8+"])
    c.point("req_wait", ["0", "1", "2-3", "4-7", "8+"])
    g["bp"] = c

    c = CoverGroup("fab_conc", "concurrency")
    c.point("masters_out", list(range(0, NM + 1)))
    c.point("slaves_busy", list(range(0, min(NM, NS) + 1)))
    c.point("same_word", ["no", "yes"] if CONTENDED else [])  # two masters presenting the same word address to the same slave
    g["conc"] = c

    c = CoverGroup("fab_reset", "fabric state at the moment reset is asserted x reset style")
    c.point("state", ["idle", "req_stalled", "slave_read_inflight", "slave_write_inflight", "error_pending", "rsp_stalled"])
    c.point("kind", ["sync", "async", "glitch"])
    c.cross("state_kind", ["state", "kind"], ignore=lambda b: b[0] == "error_pending" and not CAN_ERR_ANY)
    g["reset"] = c

    c = CoverGroup("fab_perf", "perf event outputs observed")
    for k in ("accept", "stall", "loss", "rsp_stall", "err_evt"):
        c.point(k, [0, 1] if (k != "loss" or NM > 1) else [0])
    g["perf"] = c
    return g


class CovCollector:
    """Samples the functional-coverage groups from the checker's per-cycle hook."""

    def __init__(self, groups: Dict[str, CoverGroup], chk: XbarChecker):
        self.g, self.chk = groups, chk

    def __call__(self, x: XIn, o: XOut, d: Dict[str, Any], acc_m, acc_s, resp_m, resp_s) -> None:
        g, chk = self.g, self.chk
        for m in acc_m:
            dd = AMAP.decode(m, x.m_addr[m])
            tgt = dd.slave if dd.ok else "err"
            g["txn"].sample(op="wr" if x.m_write[m] else "rd", master=m, tgt=tgt)
            if dd.ok:
                g["addr"].sample(region=dd.slave, edge=AMAP.edge_class(x.m_addr[m], dd.slave))
            else:
                g["err"].sample(kind=dd.kind, op="wr" if x.m_write[m] else "rd")
                for s in range(NS):
                    ec = AMAP.edge_class(x.m_addr[m], s)
                    if ec in ("below", "above"):
                        g["addr"].sample(region=s, edge=ec)
        n_err = sum(1 for m in acc_m if not AMAP.decode(m, x.m_addr[m]).ok)
        if n_err:
            g["err"].sample(burst=n_err)
        for s in acc_s:
            ent = chk.sinfl[s]
            if ent is not None and ent.slave_err:
                g["err"].sample(kind="slave_err", op="wr" if ent.req.write else "rd")
        for s in range(NS):
            if o.winner[s] is not None and o.s_free[s]:
                n = sum(o.elig[s])
                g["arb"].sample(ncompete=n, winner=o.winner[s])
            if d["s_req_valid"][s] and not x.s_ready[s]:
                g["arb"].sample(lock="stall_contended" if sum(o.elig[s]) > 1 else "stall_uncontended")
            if s in acc_s:
                g["bp"].sample(slave_stall=bins_run(chk.s_stall_done[s]))
            # same word, same slave, two eligible masters
            es = [m for m in range(NM) if o.elig[s][m]]
            if len(es) > 1:
                words = [x.m_addr[m] & ~(NB - 1) for m in es]
                g["conc"].sample(same_word="yes" if len(set(words)) < len(words) else "no")
        for m in resp_m:
            g["bp"].sample(rsp_stall=bins_run(chk.m_rspstall_done[m]))
        for m in acc_m:
            a = chk.tb.masters[m]
            if a.outstanding:
                g["bp"].sample(req_wait=bins_run(a.outstanding[-1].req_stall_cycles))
        g["conc"].sample(masters_out=sum(1 for m in range(NM) if chk.mfifo[m]), slaves_busy=sum(1 for s in range(NS) if chk.sinfl[s] is not None))
        for k, key in (("accept", "ev_req_accept"), ("stall", "ev_req_stall"), ("loss", "ev_arb_loss"), ("rsp_stall", "ev_rsp_stall")):
            g["perf"].sample(**{k: int(any(d[key]))})
        g["perf"].sample(err_evt=d["err_evt"])


# ---------------------------------------------------------------------------------------- the testbench
class XbarTB:
    def __init__(self, dut, tname: str, *, profile: str = "mixed", max_out: int = 2, withdraw: float = 0.0,
                 slave_err: Optional[str] = None, seed: Optional[int] = None, uniform: bool = False,
                 throttles: Optional[Dict[str, str]] = None, latency: Optional[str] = None, keep_cov: bool = True):
        self.tname = tname
        env = self.env = Env(dut, name=tname, seed=seed)
        self.seed = env.seed
        self.rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=4))
        prof = PROFILES[profile]
        rng = env.seeds.child("tb-config")

        def pick(key: str) -> str:
            if throttles and key in throttles:
                return throttles[key]
            lst = prof[key]
            return lst[0] if uniform else rng.choice(lst)

        self.pm = [sfb_port(env, "m_", m, flat=True, AW=AW, DW=DW) for m in range(NM)]
        self.ps = [sfb_port(env, "s_", s, flat=True, AW=AW, DW=DW) for s in range(NS)]
        self.masters: List[ReqRspMaster] = []
        self.slaves: List[ReqRspSlave] = []
        for m in range(NM):
            kw = dict(nbytes=NB, rng=env.seeds.child("m%d" % m), req_throttle=pick("req"), rsp_throttle=pick("rsp"), max_outstanding=max_out)
            if withdraw:
                a = WithdrawMaster("m%d" % m, self.pm[m], p_withdraw=withdraw, wrng=env.seeds.child("wd%d" % m), **kw)
            else:
                a = ReqRspMaster("m%d" % m, self.pm[m], **kw)
            self.masters.append(env.add(a))
        for s in range(NS):
            pol: Optional[ErrorPolicy] = None
            if slave_err:
                parts = []
                for spec in slave_err.split("+"):
                    k, _, arg = spec.partition(":")
                    if k == "random":
                        parts.append(RandomErrors(env.seeds.child("serr%d" % s), float(arg)))
                    elif k == "window":
                        parts.append(LowWindowErrors(int(arg, 0)))
                    elif k == "wwindow":
                        parts.append(LowWindowErrors(int(arg, 0), writes_only=True))
                pol = AnyOf(*parts) if len(parts) > 1 else parts[0]
            a = ReqRspSlave("s%d" % s, self.ps[s], memory=mem(s, "slv%d" % s), nbytes=NB, rng=env.seeds.child("s%d" % s),
                            req_throttle=pick("sreq"), rsp_throttle=pick("srsp"), latency=latency or pick("lat"), error_policy=pol, max_pending=2)
            self.slaves.append(env.add(a))
        self.mon_m = [env.add(ReqRspMonitor("mon_m%d" % m, self.pm[m], nbytes=NB, outstanding_limit=1, allow_withdraw=bool(withdraw))) for m in range(NM)]
        self.mon_s = [env.add(ReqRspMonitor("mon_s%d" % s, self.ps[s], nbytes=NB, outstanding_limit=1, allow_withdraw=bool(withdraw))) for s in range(NS)]
        self.chk = env.add(XbarChecker("xchk", self))
        self.chk.bind()
        for s, a in enumerate(self.slaves):
            a.listeners.append(_SlaveListener(self.chk, s))
        self.sb = self.chk.sb
        self.cov = make_coverage()
        if keep_cov:
            env.coverage.extend(self.cov.values())
            self.chk.cov_hooks.append(CovCollector(self.cov, self.chk))
            self.chk.reset_cov = self.cov["reset"]

    # ---- lifecycle
    async def start(self) -> None:
        await self.env.start()
        await self.env.until(lambda: not self.rst.asserted, 50, "reset release")

    @property
    def idle(self) -> bool:
        return all(m.idle for m in self.masters)

    async def drain(self, max_cycles: int = 50000, what: str = "all masters idle") -> int:
        n = await self.env.until(lambda: self.idle, max_cycles, what)
        await self.env.cycles(4)
        return n

    async def finish(self, test: str, **extra) -> dict:
        await self.env.cycles(3)
        self.chk.final_checks()
        self.sb.finalize()
        self.env.finalize()
        cov = {k: round(v.percent(), 1) for k, v in self.cov.items()}
        return self.env.write_result(test, scoreboard=self.sb.summary(), checker=self.chk.summary(), func_cov_percent=cov, **extra)

    def set_regime(self, name: str) -> None:
        r = REGIMES[name]
        for a in self.masters:
            a.req_thr.set_mode(r["req"])
            a.rsp_thr.set_mode(r["rsp"])
        for a in self.slaves:
            a.req_thr.set_mode(r["sreq"])
            a.rsp_thr.set_mode(r["srsp"])
            a.lat = Latency(a.rng, r["lat"])

    # ---- stimulus helpers
    def fill_random(self, n: int, gen: Optional[Gen] = None, masters: Optional[Sequence[int]] = None, weights: Optional[Dict[str, float]] = None) -> Gen:
        gen = gen or Gen(self.env.seeds.child("gen"), weights)
        for m in (masters if masters is not None else range(NM)):
            for _ in range(n):
                self.masters[m].submit(gen.request(m))
        return gen

    def region_addr(self, s: int, off: int = 0) -> int:
        return (AMAP.region_first(s) + off) & 0xFFFFFFFF

    def mem_word(self, rng: random.Random) -> int:
        return rng.getrandbits(DW)
