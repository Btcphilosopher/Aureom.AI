"""Unit benches for the two small DataFabric cells ``sfb_skid_buffer`` and ``sfb_error_slave``.

Both are checked cycle-exactly against the models in albionverify.models.fabric_slice (derived from the header
comments / PROTOCOL.md): skid buffer = 2-entry elastic buffer with registered valid/data/ready, 1 transfer per
cycle, payload stable under back-pressure, +1 cycle latency; error slave = answers every request with
rsp_error = 1, rsp_rdata = 0 one cycle after acceptance, one buffered response, held until rsp_ready.  End-to-end
checks (data in == data out, order, exactly once) and reset behaviour (sync, async mid-cycle, sub-cycle glitch) are
independent of the lockstep model.
"""
import json
import os
from collections import deque

import cocotb
from cocotb.triggers import RisingEdge, Timer

from albionverify.core import Agent, AlbionCheckError, Env
from albionverify.coverage import CoverGroup
from albionverify.models.fabric_slice import ElasticBuffer, ErrorSlaveModel
from albionverify.reset import ResetSequencer
from albionverify.rng import Throttle

P = json.loads(os.environ.get("ALBION_PARAMS", "{}"))
DUT = os.environ.get("ALBION_DUT", "")
IS_SKID = "skid" in DUT
IS_ERR = "err" in DUT
WIDTH = int(P.get("WIDTH", 32))
DW = int(P.get("DW", 32))

PHASES = [
    ("always", "always"),
    ("always", "random:0.5"),
    ("random:0.6", "bursty:1-8"),
    ("random:0.9", "random:0.2"),
    ("random:0.3", "always"),
    ("always", "bursty:3-12"),
    ("random:0.5", "random:0.5"),
]


class ResetMixin:
    """Reset helpers shared by both benches: scheduled, async mid-cycle, sub-cycle glitch."""

    async def sync_reset(self, env, rst, rng):
        target = rst.n_pulses + 1
        rst.pulse(length=rng.randint(1, 3), delay=1, reason="sync")
        await env.until(lambda: rst.n_pulses >= target and not rst.asserted, 40, "sync reset")

    async def async_reset(self, env, rst, rng):
        target = rst.n_pulses + 1
        cocotb.start_soon(rst.async_pulse(phase_ns=rng.randint(2, 18) / 2.0, length_cycles=rng.randint(1, 3)))
        await env.until(lambda: rst.n_pulses >= target, 40, "async reset start")
        await env.until(lambda: not rst.asserted, 40, "async reset release")

    async def glitch_reset(self, env, rst, rng, agent):
        target = rst.n_pulses + 1

        async def glitch():
            await RisingEdge(getattr(env.dut, env.clk_name))
            await Timer(2000, units="ps")
            sh = rst.rst.sh
            sh.h.value = rst.active
            sh.pend, sh.dirty = rst.active, False
            rst.asserted = True
            rst.n_pulses += 1
            env.notify_reset(True)
            agent.drive()
            for s in env.shadows.values():
                s.flush()
            await Timer(3000, units="ps")
            sh.h.value = rst.inactive
            sh.pend, sh.dirty = rst.inactive, False
            rst.asserted = False
            env.notify_reset(False)

        cocotb.start_soon(glitch())
        await env.until(lambda: rst.n_pulses >= target, 40, "glitch start")
        await env.cycles(2)


# ======================================================================================== skid buffer
class SkidBench(Agent):
    def __init__(self, env):
        super().__init__("skid")
        s = env.sig
        self.sv, self.sr, self.sd = s("s_valid"), s("s_ready"), s("s_data")
        self.mv, self.mr, self.md = s("m_valid"), s("m_ready"), s("m_data")
        self.rng = env.seeds.child("skid")
        self.model = ElasticBuffer()
        self.inq = deque()  # data accepted and not yet delivered, in order
        self.hold = None  # (data) the producer keeps presenting until accepted
        self.n_cycles = self.n_in = self.n_out = 0
        self.rst_cycles = 0
        self.set_phase("always", "always")
        self.cg = CoverGroup("skid", "skid buffer occupancy / events")
        self.cg.point("fill", [0, 1, 2])
        self.cg.point("event", ["pass", "hold", "skid_fill", "both_moving", "drain_skid"])
        env.coverage.append(self.cg)

    def set_phase(self, prod, cons, hold=True):
        self.prod_thr, self.cons_thr, self.holdmode = Throttle(self.rng, prod), Throttle(self.rng, cons), hold

    def sample(self):
        env = self.env
        if env.in_reset:
            self.rst_cycles += 1
            if self.rst_cycles >= 2 and self.mv.read():
                env.error("skid: m_valid asserted during reset")
            return
        self.rst_cycles = 0
        self.n_cycles += 1
        m = self.model
        sv, mr = self.sv.read(), self.mr.read()
        data = self.sd.read() if sv else None
        # lockstep
        if self.sr.read() != m.s_ready:
            env.error("skid: s_ready=%d, model expects %d (fill %d)" % (self.sr.read(), m.s_ready, len(m.q)))
        if self.mv.read() != m.m_valid:
            env.error("skid: m_valid=%d, model expects %d (fill %d)" % (self.mv.read(), m.m_valid, len(m.q)))
        if m.m_valid and self.md.read() != m.m_data:
            env.error("skid: m_data=0x%x, model expects 0x%x" % (self.md.read(), m.m_data))
        push, pop = m.step(sv, data, mr)
        # end-to-end, independent of the model
        if push:
            self.inq.append(data)
            self.n_in += 1
        if pop:
            out = self.md.read()
            if not self.inq:
                env.error("skid: item delivered with nothing accepted (stale/duplicate)")
            exp = self.inq.popleft()
            if out != exp:
                env.error("skid: delivered 0x%x but the oldest accepted item is 0x%x (loss / reorder / corruption)" % (out, exp))
            self.n_out += 1
        if push and self.hold is not None and data == self.hold[0]:
            self.hold = None
        fill = len(m.q)
        self.cg.sample(fill=fill)
        if push and pop:
            self.cg.sample(event="both_moving")
        elif push and fill >= 2:
            self.cg.sample(event="skid_fill")
        elif push:
            self.cg.sample(event="pass")
        elif pop and fill >= 1:
            self.cg.sample(event="drain_skid")
        elif self.mv.read() and not mr:
            self.cg.sample(event="hold")
        env.digest.event("skid", self.n_cycles, sv, mr, int(push), int(pop), self.md.read() if pop else 0)

    def drive(self):
        env = self.env
        if env.in_reset:
            self.sv.write(0)
            self.mr.write(0)
            self.hold = None
            return
        rng = self.rng
        want = self.prod_thr.allow()
        if self.hold is not None and self.holdmode:
            data, valid = self.hold[0], True
        elif want:
            data, valid = rng.getrandbits(WIDTH), True
            self.hold = (data,)
        else:
            data, valid = rng.getrandbits(WIDTH), False
            self.hold = None
        self.sv.write(int(valid))
        self.sd.write(data)
        self.mr.write(int(self.cons_thr.allow()))

    def on_reset(self, asserted):
        if asserted:
            self.model.reset()
            self.inq.clear()
            self.hold = None

    def summary(self):
        return {"cycles": self.n_cycles, "in": self.n_in, "out": self.n_out, "checks": 3 * self.n_cycles}


async def _setup(dut, name, bench_cls):
    env = Env(dut, name=name)
    rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=4))
    b = env.add(bench_cls(env))
    await env.start()
    await env.until(lambda: not rst.asserted, 50, "reset release")
    return env, rst, b


@cocotb.test(skip=not IS_SKID)
async def skid_phases(dut):
    """Producer / consumer pacing sweep (held and non-held valid), 500 cycles per phase."""
    env, rst, b = await _setup(dut, "skid_phases", SkidBench)
    for hold in (True, False):
        for prod, cons in PHASES:
            b.set_phase(prod, cons, hold)
            await env.cycles(500)
    if b.n_out < 500:
        raise AlbionCheckError("skid buffer moved only %d items" % b.n_out)
    # drain and balance: everything accepted was delivered
    b.set_phase("never", "always")
    await env.cycles(10)
    if b.inq:
        raise AlbionCheckError("%d accepted item(s) never delivered" % len(b.inq))
    env.finalize()
    env.write_result("skid_phases", skid=b.summary(), func_cov_percent={"skid": round(b.cg.percent(), 1)})


@cocotb.test(skip=not IS_SKID)
async def skid_throughput_latency(dut):
    """Always-valid producer, always-ready consumer: one item per cycle, +1 cycle latency, never more than one entry."""
    env, rst, b = await _setup(dut, "skid_throughput_latency", SkidBench)
    b.set_phase("always", "always")
    n0 = b.n_out
    await env.cycles(200)
    if b.n_out - n0 < 197:
        raise AlbionCheckError("only %d items in 200 cycles at full rate" % (b.n_out - n0))
    # capacity: stall the consumer; the buffer accepts exactly two items
    b.set_phase("always", "never", hold=False)
    await env.cycles(2)
    i0 = b.n_in
    await env.cycles(10)
    if b.n_in - i0 + len(b.model.q) < 2 or len(b.model.q) != 2:
        raise AlbionCheckError("buffer fill %d with a stalled consumer, expected 2" % len(b.model.q))
    b.set_phase("never", "always")
    await env.cycles(6)
    env.finalize()
    env.write_result("skid_throughput_latency", skid=b.summary(), func_cov_percent={"skid": round(b.cg.percent(), 1)})


@cocotb.test(skip=not IS_SKID)
async def skid_reset(dut):
    """Reset with 0/1/2 entries stored: sync, async mid-cycle and sub-cycle glitch; nothing stale afterwards."""
    env, rst, b = await _setup(dut, "skid_reset", SkidBench)
    rng = env.seeds.child("rst")
    rm = ResetMixin()
    for rnd in range(30):
        b.set_phase(rng.choice(["always", "random:0.6"]), rng.choice(["never", "random:0.3", "bursty:2-8"]), hold=rng.random() < 0.7)
        await env.cycles(rng.randint(3, 25))
        style = rnd % 3
        if style == 0:
            await rm.sync_reset(env, rst, rng)
        elif style == 1:
            await rm.async_reset(env, rst, rng)
        else:
            await rm.glitch_reset(env, rst, rng, b)
        b.set_phase("random:0.7", "random:0.6")
        await env.cycles(rng.randint(8, 30))
    env.finalize()
    env.write_result("skid_reset", skid=b.summary(), func_cov_percent={"skid": round(b.cg.percent(), 1)})


# ======================================================================================== error slave
class ErrBench(Agent):
    def __init__(self, env):
        super().__init__("errslave")
        s = env.sig
        self.rv, self.rr = s("req_valid"), s("req_ready")
        self.pv, self.pr, self.pd, self.pe = s("rsp_valid"), s("rsp_ready"), s("rsp_rdata"), s("rsp_error")
        self.rng = env.seeds.child("err")
        self.model = ErrorSlaveModel()
        self.set_phase("always", "always")
        self.pending_resp = deque()  # acceptance cycles of requests awaiting their response
        self.n_acc = self.n_rsp = self.n_cycles = 0
        self.rst_cycles = 0
        self.max_hold = 0
        self._hold = 0
        self.cg = CoverGroup("errslave", "decode-error slave events")
        self.cg.point("event", ["accept_idle", "accept_with_retire", "hold", "respond", "idle"])
        env.coverage.append(self.cg)

    def set_phase(self, req, rsp):
        self.req_thr, self.rsp_thr = Throttle(self.rng, req), Throttle(self.rng, rsp)

    def sample(self):
        env = self.env
        if env.in_reset:
            self.rst_cycles += 1
            if self.rst_cycles >= 2 and self.pv.read():
                env.error("errslave: rsp_valid asserted during reset")
            return
        self.rst_cycles = 0
        self.n_cycles += 1
        m = self.model
        v, pr = self.rv.read(), self.pr.read()
        exp_rdy = m.req_ready(pr)
        if self.rr.read() != exp_rdy:
            env.error("errslave: req_ready=%d, model expects %d" % (self.rr.read(), exp_rdy))
        if self.pv.read() != m.rsp_valid():
            env.error("errslave: rsp_valid=%d, model expects %d" % (self.pv.read(), m.rsp_valid()))
        if self.pd.read() != 0:
            env.error("errslave: rsp_rdata=0x%x, must be 0 (R8)" % self.pd.read())
        if self.pv.read() and self.pe.read() != 1:
            env.error("errslave: response without rsp_error")
        acc = bool(v and self.rr.read())
        rsp = bool(self.pv.read() and pr)
        # independent end-to-end rule: a response only after an earlier acceptance, exactly one per request, <= 1 buffered
        if rsp:
            if not self.pending_resp:
                env.error("errslave: response with no accepted request")
            t0 = self.pending_resp.popleft()
            if t0 >= env.cycle:
                env.error("errslave: response in the acceptance cycle (R5)")
            self.n_rsp += 1
        if acc:
            self.pending_resp.append(env.cycle)
            self.n_acc += 1
        if len(self.pending_resp) > 1:
            env.error("errslave: more than one unanswered request buffered (%d)" % len(self.pending_resp))
        if self.pv.read() and not pr:
            self._hold += 1
            self.max_hold = max(self.max_hold, self._hold)
        else:
            self._hold = 0
        cg = self.cg
        if acc and rsp:
            cg.sample(event="accept_with_retire")
        elif acc:
            cg.sample(event="accept_idle")
        elif rsp:
            cg.sample(event="respond")
        elif self.pv.read():
            cg.sample(event="hold")
        else:
            cg.sample(event="idle")
        env.digest.event("err", self.n_cycles, v, pr, int(acc), int(rsp))
        m.step(v, pr)

    def drive(self):
        env = self.env
        if env.in_reset:
            self.rv.write(0)
            self.pr.write(0)
            return
        self.rv.write(int(self.req_thr.allow()))
        self.pr.write(int(self.rsp_thr.allow()))

    def on_reset(self, asserted):
        if asserted:
            self.model.reset()
            self.pending_resp.clear()
            self._hold = 0

    def summary(self):
        return {"cycles": self.n_cycles, "accepted": self.n_acc, "responses": self.n_rsp, "max_hold": self.max_hold, "checks": 4 * self.n_cycles}


@cocotb.test(skip=not IS_ERR)
async def err_phases(dut):
    """Request / response pacing sweep; exact timing against the model plus the end-to-end rules."""
    env, rst, b = await _setup(dut, "err_phases", ErrBench)
    for rep in range(2):
        for req, rsp in PHASES + [("always", "never")]:
            b.set_phase(req, rsp)
            await env.cycles(300 if rsp != "never" else 12)
    b.set_phase("never", "always")
    await env.cycles(5)
    if b.n_acc != b.n_rsp:
        raise AlbionCheckError("%d requests accepted but %d responses delivered" % (b.n_acc, b.n_rsp))
    env.finalize()
    env.write_result("err_phases", errslave=b.summary(), func_cov_percent={"errslave": round(b.cg.percent(), 1)})


@cocotb.test(skip=not IS_ERR)
async def err_throughput_latency(dut):
    """Always-valid requester, always-ready consumer: a request is accepted every cycle, each answered one cycle after
    acceptance (R5/R12: response latency 1, full throughput)."""
    env, rst, b = await _setup(dut, "err_throughput_latency", ErrBench)
    b.set_phase("always", "always")
    n0 = b.n_acc
    await env.cycles(100)
    if b.n_acc - n0 < 99:
        raise AlbionCheckError("only %d requests accepted in 100 cycles" % (b.n_acc - n0))
    b.set_phase("always", "never")
    await env.cycles(8)
    if b.max_hold < 5:
        raise AlbionCheckError("response was not held under back-pressure (max hold %d)" % b.max_hold)
    b.set_phase("never", "always")
    await env.cycles(4)
    env.finalize()
    env.write_result("err_throughput_latency", errslave=b.summary(), func_cov_percent={"errslave": round(b.cg.percent(), 1)})


@cocotb.test(skip=not IS_ERR)
async def err_reset(dut):
    """Reset while a response is pending (sync / async mid-cycle / glitch): the pending response is cancelled, no
    response appears for it afterwards."""
    env, rst, b = await _setup(dut, "err_reset", ErrBench)
    rng = env.seeds.child("rst")
    rm = ResetMixin()
    for rnd in range(30):
        b.set_phase(rng.choice(["always", "random:0.5"]), rng.choice(["never", "random:0.3", "bursty:2-8"]))
        await env.cycles(rng.randint(3, 20))
        style = rnd % 3
        if style == 0:
            await rm.sync_reset(env, rst, rng)
        elif style == 1:
            await rm.async_reset(env, rst, rng)
        else:
            await rm.glitch_reset(env, rst, rng, b)
        b.set_phase("random:0.6", "random:0.7")
        await env.cycles(rng.randint(8, 25))
    env.finalize()
    env.write_result("err_reset", errslave=b.summary(), func_cov_percent={"errslave": round(b.cg.percent(), 1)})
