"""pytest (no simulator): the arbitration-policy model against hand-computed sequences and spec properties."""
import random

import pytest

from albionverify.models.fabric_arbiter import FIXED, ROUND_ROBIN, ArbiterModel, rr_wait_bound


def run(model, steps):
    """steps: (req_list, presented, accepted) -> list of winners"""
    out = []
    for req, presented, accepted in steps:
        w = model.select(req)
        out.append(w)
        model.step(w, presented, accepted)
    return out


def test_model_fixed_priority_order():
    m = ArbiterModel(4, FIXED)
    assert m.select([0, 1, 1, 1]) == 1
    assert m.select([1, 1, 1, 1]) == 0
    assert m.select([0, 0, 0, 1]) == 3
    assert m.select([0, 0, 0, 0]) is None


def test_model_fixed_priority_starvation():
    m = ArbiterModel(3, FIXED)
    w = run(m, [([1, 1, 1], True, True)] * 20)
    assert w == [0] * 20  # requester 0 never lets 1 and 2 win


def test_model_round_robin_rotation_hand_computed():
    m = ArbiterModel(3, ROUND_ROBIN)
    w = run(m, [([1, 1, 1], True, True)] * 7)
    assert w == [0, 1, 2, 0, 1, 2, 0]
    # pointer = winner + 1: requester 1 alone wins, then 2 and 0 contend -> 2 (nearest after 1)
    m = ArbiterModel(3, ROUND_ROBIN)
    w = run(m, [([0, 1, 0], True, True), ([1, 0, 1], True, True), ([1, 0, 1], True, True)])
    assert w == [1, 2, 0]


def test_model_round_robin_pointer_moves_only_on_acceptance():
    m = ArbiterModel(3, ROUND_ROBIN)
    # winner 0 offered but stalled twice: lock keeps the grant, pointer must not move
    w = run(m, [([1, 1, 1], True, False), ([1, 1, 1], True, False), ([1, 1, 1], True, True), ([1, 1, 1], True, True)])
    assert w == [0, 0, 0, 1]
    # grant not presented (slave busy): no lock, no pointer move
    m = ArbiterModel(3, ROUND_ROBIN)
    assert run(m, [([1, 1, 1], False, False)] * 3) == [0, 0, 0]
    assert m.ptr == 0 and m.lock is None


def test_model_lock_holds_against_higher_priority_and_releases_on_withdraw():
    m = ArbiterModel(3, FIXED)
    # requester 2 granted and stalled; requester 0 (higher priority) arrives: the lock keeps 2
    w = run(m, [([0, 0, 1], True, False), ([1, 0, 1], True, False), ([1, 0, 1], True, True)])
    assert w == [2, 2, 2]
    assert m.select([1, 0, 1]) == 0  # after acceptance, normal priority again
    # locked requester withdraws: arbitration resumes in that very cycle
    m = ArbiterModel(3, FIXED)
    w = run(m, [([0, 0, 1], True, False), ([1, 0, 0], True, True)])
    assert w == [2, 0]
    # round robin: same
    m = ArbiterModel(4, ROUND_ROBIN)
    w = run(m, [([0, 0, 1, 1], True, False), ([0, 1, 0, 1], True, True)])
    assert w == [2, 1]


def test_model_reset_state():
    m = ArbiterModel(4, ROUND_ROBIN)
    run(m, [([1, 1, 1, 1], True, True)] * 3)
    assert m.ptr == 3
    m.reset()
    assert (m.ptr, m.lock) == (0, None)


@pytest.mark.parametrize("n", [2, 3, 4, 5, 6, 8])
def test_model_round_robin_bounded_waiting_property(n):
    """Spec property (PROTOCOL.md sec. 4): a continuously requesting requester sees at most N-1 other acceptances,
    with arbitrary requests, withdrawals and slave stalls."""
    rng = random.Random(n)
    m = ArbiterModel(n, ROUND_ROBIN)
    wait = [0] * n
    worst = 0
    for _ in range(20000):
        req = [rng.random() < 0.7 for _ in range(n)]
        w = m.select(req)
        presented = w is not None and rng.random() < 0.8
        accepted = presented and rng.random() < 0.6
        for i in range(n):
            if not req[i]:
                wait[i] = 0
            elif accepted and w == i:
                wait[i] = 0
            elif accepted:
                wait[i] += 1
                worst = max(worst, wait[i])
                assert wait[i] <= rr_wait_bound(n)
        m.step(w, presented, bool(accepted))
    assert worst == n - 1  # the bound is tight


@pytest.mark.parametrize("mode", [FIXED, ROUND_ROBIN])
def test_model_grant_is_one_hot_subset_and_work_conserving(mode):
    rng = random.Random(7)
    m = ArbiterModel(5, mode)
    for _ in range(5000):
        req = [rng.random() < 0.4 for _ in range(5)]
        w = m.select(req)
        assert (w is not None) == any(req)
        if w is not None:
            assert req[w]
        presented = w is not None and rng.random() < 0.7
        m.step(w, presented, presented and rng.random() < 0.5)
