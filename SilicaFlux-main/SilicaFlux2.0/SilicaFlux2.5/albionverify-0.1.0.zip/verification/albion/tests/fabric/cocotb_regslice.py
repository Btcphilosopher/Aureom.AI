"""Bench for ``sfb_reg_slice`` (REQ_SLICE / RSP_SLICE) and the skid buffer inside it.

Upstream (``s_*``) is driven by a ReqRspMaster, downstream (``m_*``) by a ReqRspSlave, both with random
back-pressure and several transactions in flight (the slice may buffer up to two per sliced channel).

Checks: (1) LOCKSTEP against the cycle model (albionverify.models.fabric_slice): ready/valid/payload of both
channels every cycle; (2) END-TO-END: every request the master got accepted reaches the slave exactly once,
unchanged and in order; every response reaches the master exactly once, in order, equal to what the reference
memory predicts (R5/R12 protocol transparency); after reset nothing stale is delivered (R11: a write still in a
slice is dropped, so a slave acceptance without a post-reset master acceptance is an error); (3) latency /
capacity facts: +1 cycle per sliced direction, 0 for a bypassed one, 2 entries per sliced channel; (4) passive
protocol monitors on both interfaces.
"""
import json
import os
from collections import deque

import cocotb
from cocotb.triggers import RisingEdge, Timer

from albionverify.bus.reqrsp import Req, ReqRspMaster, ReqRspMonitor, ReqRspSlave, make_port, SFB_NAMES
from albionverify.core import Agent, AlbionCheckError, Env
from albionverify.inject import RandomErrors
from albionverify.coverage import CoverGroup
from albionverify.memory import BackingStore
from albionverify.models.fabric_slice import RegSliceModel
from albionverify.reset import ResetSequencer
from albionverify.scoreboard import Scoreboard

P = json.loads(os.environ.get("ALBION_PARAMS", "{}"))
REQ_SLICE = int(P.get("REQ_SLICE", 1))
RSP_SLICE = int(P.get("RSP_SLICE", 1))
AW = int(P.get("AW", 32))
DW = int(P.get("DW", 32))
NB = DW // 8
AMASK = (1 << AW) - 1


def need(cond, msg):
    if not cond:
        raise AlbionCheckError(msg)


def init_byte():
    return lambda a: ((a * 77 + (a >> 7) * 13 + 5) ^ (a >> 3)) & 0xFF


class SliceChecker(Agent):
    def __init__(self, tb):
        super().__init__("slice_chk")
        self.tb = tb
        self.model = RegSliceModel(REQ_SLICE, RSP_SLICE)
        self.ref = BackingStore(init_byte(), "ref")
        self.m_acc_q = deque()  # requests accepted by the slice from the master, not yet seen at the slave
        self.exp_q = deque()  # (rdata, err) the master must receive, in order (computed at slave acceptance)
        self.rst_cycles = 0
        self.n_cycles = 0
        self.n_lockstep = 0
        self.max_req_fill = 0
        self.max_rsp_fill = 0
        self.n_up_acc = 0
        self.n_down_acc = 0
        self.sb = None
        self.cg = CoverGroup("slice", "register slice occupancy / back-pressure coverage")
        self.cg.point("req_fill", [0, 1, 2] if REQ_SLICE else [0])  # a bypassed channel stores nothing
        self.cg.point("rsp_fill", [0, 1, 2] if RSP_SLICE else [0])
        self.cg.point("req_event", ["pass", "hold", "skid_fill", "both_moving"] if REQ_SLICE else ["hold", "both_moving"])
        self.cg.point("rsp_event", ["pass", "hold", "skid_fill", "both_moving"] if RSP_SLICE else ["hold", "both_moving"])
        self.cg.point("op", ["rd", "wr"])
        self.cg.point("rsp_err", [0, 1])
        self.fill_prev_req = self.fill_prev_rsp = 0

    def bind(self, env):
        s = env.sig
        names = ["req_valid", "req_ready", "req_write", "req_addr", "req_wdata", "req_wstrb", "rsp_valid", "rsp_ready", "rsp_rdata", "rsp_error"]
        self.us = {n: s("s_" + n) for n in names}
        self.ds = {n: s("m_" + n) for n in names}
        self.sb = Scoreboard(env, "slice")

    def fail(self, msg):
        self.sb.fail(msg)

    # ------------------------------------------------------------------------------------ listeners
    def master_accepted(self, agent, txn):  # master agent listener (txn_accepted)
        self.m_acc_q.append(txn.req)
        self.sb.accept("req", txn.seq, txn.req)

    def master_completed(self, agent, txn):
        if not self.exp_q:
            self.fail("master received a response (rdata=0x%x err=%d) but the slave has produced none that is outstanding" % (txn.rsp.rdata, txn.rsp.err))
        rd, er = self.exp_q.popleft()
        self.sb.complete("req", txn.seq)
        if (txn.rsp.rdata, int(txn.rsp.err)) != (rd, int(er)):
            self.fail("response mismatch (seq %d addr 0x%x %s): expected rdata=0x%x err=%d, master got rdata=0x%x err=%d"
                      % (txn.seq, txn.req.addr, "wr" if txn.req.write else "rd", rd, er, txn.rsp.rdata, txn.rsp.err))

    def slave_accepted(self, agent, req, err, rdata):
        if not self.m_acc_q:
            self.fail("slave accepted a request (addr=0x%x) that the master never had accepted (stale/duplicated request)" % req.addr)
        exp = self.m_acc_q.popleft()
        got = (req.write, req.addr, req.wdata if req.write else 0, req.strb)
        want = (exp.write, exp.addr, exp.wdata if exp.write else 0, exp.strb if exp.strb is not None else ((1 << NB) - 1 if exp.write else 0))
        if got != want:
            self.fail("request altered by the slice: master sent (wr=%d addr=0x%x wdata=0x%x strb=0x%x), slave got (wr=%d addr=0x%x wdata=0x%x strb=0x%x)" % (want + got))
        wa = req.addr & ~(NB - 1)
        if err:
            self.exp_q.append((0, True))
        elif req.write:
            self.ref.write_word(wa, req.wdata, req.strb, NB)
            self.exp_q.append((0, False))
        else:
            self.exp_q.append((self.ref.read_word(wa, NB), False))
        self.n_down_acc += 1

    def slave_cancelled(self, agent, req):
        pass

    # ------------------------------------------------------------------------------------ cycle
    def _tuple_req(self, p, valid):
        if not valid:
            return None
        wr = p["req_write"].read()
        return (wr, p["req_addr"].read(), p["req_wdata"].read() if wr else 0, p["req_wstrb"].read())

    def sample(self):
        env = self.env
        if env.in_reset:
            self.rst_cycles += 1
            if self.rst_cycles >= 2:
                if self.ds["req_valid"].read() and REQ_SLICE:
                    self.fail("R11: downstream req_valid asserted during reset")
                if self.us["rsp_valid"].read() and RSP_SLICE:
                    self.fail("R11: upstream rsp_valid asserted during reset")
            return
        self.rst_cycles = 0
        self.n_cycles += 1
        us, ds, md = self.us, self.ds, self.model
        s_valid = us["req_valid"].read()
        s_req = self._tuple_req(us, s_valid)
        m_rdy = ds["req_ready"].read()
        m_rv = ds["rsp_valid"].read()
        m_rsp = (ds["rsp_rdata"].read(), ds["rsp_error"].read()) if m_rv else None
        s_rrdy = us["rsp_ready"].read()
        o = md.expected(s_req, m_rdy, m_rsp, s_rrdy)

        def eq(what, exp, got):
            self.n_lockstep += 1
            if exp != got:
                self.fail("LOCKSTEP %s: model expects %s, DUT drives %s (req fill=%d rsp fill=%d)" % (what, exp, got, len(md.req.q), len(md.rsp.q)))

        eq("s_req_ready", o["s_req_ready"], us["req_ready"].read())
        d_valid = ds["req_valid"].read()
        eq("m_req_valid", o["m_req_valid"], d_valid)
        d_req = self._tuple_req(ds, d_valid)
        if d_valid:
            eq("m_req payload", o["m_req_data"], d_req)
        eq("m_rsp_ready", o["m_rsp_ready"], ds["rsp_ready"].read())
        u_rv = us["rsp_valid"].read()
        eq("s_rsp_valid", o["s_rsp_valid"], u_rv)
        if u_rv:
            eq("s_rsp payload", o["s_rsp_data"], (us["rsp_rdata"].read(), us["rsp_error"].read()))
        # transfers (observed handshakes)
        up_acc = bool(s_valid and us["req_ready"].read())
        down_acc = bool(d_valid and m_rdy)
        dn_rsp = bool(m_rv and ds["rsp_ready"].read())
        up_rsp = bool(u_rv and s_rrdy)
        if up_acc:
            self.n_up_acc += 1
        # coverage
        cg = self.cg
        cg.sample(req_fill=len(md.req.q), rsp_fill=len(md.rsp.q))
        self.max_req_fill = max(self.max_req_fill, len(md.req.q))
        self.max_rsp_fill = max(self.max_rsp_fill, len(md.rsp.q))
        if up_acc and down_acc:
            cg.sample(req_event="both_moving")
        elif up_acc and len(md.req.q) >= 1 and not down_acc:
            cg.sample(req_event="skid_fill")
        elif d_valid and not m_rdy:
            cg.sample(req_event="hold")
        elif up_acc:
            cg.sample(req_event="pass")
        if dn_rsp and up_rsp:
            cg.sample(rsp_event="both_moving")
        elif dn_rsp and len(md.rsp.q) >= 1 and not up_rsp:
            cg.sample(rsp_event="skid_fill")
        elif u_rv and not s_rrdy:
            cg.sample(rsp_event="hold")
        elif dn_rsp:
            cg.sample(rsp_event="pass")
        if up_acc:
            cg.sample(op="wr" if s_req[0] else "rd")
        if up_rsp:
            cg.sample(rsp_err=int(us["rsp_error"].read()))
        env.digest.event("slice", self.n_cycles, s_valid, m_rdy, m_rv, s_rrdy, int(up_acc), int(down_acc), int(dn_rsp), int(up_rsp))
        md.step(s_req, m_rdy, m_rsp, s_rrdy)

    def on_reset(self, asserted):
        if not asserted:
            return
        # Everything the slice still holds is dropped (R11): the requests accepted from the master but not yet seen at the
        # slave never reach it (m_acc_q cleared -> a later slave acceptance without a new master acceptance is an error).
        # Writes the slave HAS accepted were performed by the slave model at acceptance, so the reference (updated at slave
        # acceptance, in slave order) already holds them: the slave is the serialisation point.
        n_dropped = len(self.m_acc_q)
        self.model.reset()
        self.m_acc_q.clear()
        self.exp_q.clear()
        self.sb.cancel(reason="reset")
        self.env.digest.event("slice.reset", self.env.cycle, n_dropped)

    def summary(self):
        return {"cycles": self.n_cycles, "lockstep_checks": self.n_lockstep, "up_accepted": self.n_up_acc, "down_accepted": self.n_down_acc,
                "max_req_fill": self.max_req_fill, "max_rsp_fill": self.max_rsp_fill, "checks": self.n_lockstep + self.sb.checks}


REGIMES = {
    "fast": dict(req="always", rsp="always", sreq="always", srsp="always", lat="fixed:1"),
    "slave_stall": dict(req="always", rsp="always", sreq="bursty:2-9", srsp="always", lat="fixed:1"),
    "master_stall": dict(req="always", rsp="bursty:2-9", sreq="always", srsp="always", lat="fixed:1"),
    "both": dict(req="random:0.8", rsp="random:0.5", sreq="random:0.5", srsp="random:0.6", lat="uniform:1-4"),
    "sparse": dict(req="random:0.2", rsp="always", sreq="always", srsp="always", lat="uniform:1-3"),
    "slow_resp": dict(req="always", rsp="random:0.7", sreq="random:0.9", srsp="bursty:1-6", lat="tail:1,0.3,8"),
}


class SliceTB:
    def __init__(self, dut, name, max_out=4, seed=None):
        env = self.env = Env(dut, name=name, seed=seed)
        self.rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=4))
        up = make_port(env, SFB_NAMES, prefix="s_", AW=AW, DW=DW)
        dn = make_port(env, SFB_NAMES, prefix="m_", AW=AW, DW=DW)
        self.master = env.add(ReqRspMaster("up", up, nbytes=NB, rng=env.seeds.child("m"), max_outstanding=max_out, AW=AW))
        self.slave = env.add(ReqRspSlave("dn", dn, memory=BackingStore(init_byte(), "slv"), nbytes=NB, rng=env.seeds.child("s"), max_pending=max_out + 1, latency="fixed:1",
                                       error_policy=RandomErrors(env.seeds.child("err"), 0.12)))
        self.mon_up = env.add(ReqRspMonitor("mon_up", up, nbytes=NB))
        self.mon_dn = env.add(ReqRspMonitor("mon_dn", dn, nbytes=NB))
        self.chk = env.add(SliceChecker(self))
        self.chk.bind(env)
        self.master.listeners.append(_MasterL(self.chk))
        self.slave.listeners.append(_SlaveL(self.chk))
        env.coverage.append(self.chk.cg)
        self.rng = env.seeds.child("gen")

    def set_regime(self, name):
        r = REGIMES[name]
        from albionverify.rng import Latency
        self.master.req_thr.set_mode(r["req"])
        self.master.rsp_thr.set_mode(r["rsp"])
        self.slave.req_thr.set_mode(r["sreq"])
        self.slave.rsp_thr.set_mode(r["srsp"])
        self.slave.lat = Latency(self.slave.rng, r["lat"])

    async def start(self):
        await self.env.start()
        await self.env.until(lambda: not self.rst.asserted, 50, "reset release")

    def fill(self, n, hot=8, write=0.5):
        rng = self.rng
        pool = [((rng.getrandbits(AW) & ~(NB - 1)) & AMASK) for _ in range(hot)]
        for _ in range(n):
            a = rng.choice(pool) if rng.random() < 0.7 else (rng.getrandbits(AW) & ~(NB - 1)) & AMASK
            if rng.random() < 0.2:
                a = rng.getrandbits(AW) & AMASK  # arbitrary byte address (the slice must be transparent to every bit)
            if rng.random() < write:
                full = (1 << NB) - 1
                k = rng.random()
                strb = None if k < 0.4 else (rng.getrandbits(NB) or 1 if k < 0.8 else 0)
                self.master.write(a, rng.getrandbits(DW), strb)
            else:
                self.master.read(a)

    async def drain(self, max_cycles=20000):
        await self.env.until(lambda: self.master.idle, max_cycles, "master idle")
        await self.env.cycles(4)

    async def finish(self, test, **extra):
        await self.env.cycles(3)
        chk = self.chk
        if self.master.n_accepted != chk.n_up_acc:
            chk.fail("master accepted %d, checker saw %d" % (self.master.n_accepted, chk.n_up_acc))
        chk.sb.finalize()
        # final memory: every slave byte must be allowed by the reference (writes dropped by reset are absent from both)
        for a in sorted(set(self.slave.mem.written_addresses()) | set(chk.ref.written_addresses())):
            ok = chk.ref.allowed(a)
            got = self.slave.mem.snapshot(a, 1)[0]
            if ok is not None and got not in ok:
                chk.fail("final slave memory differs from reference at 0x%x: 0x%02x not in %s" % (a, got, sorted(ok)))
        self.env.finalize()
        return self.env.write_result(test, slice=chk.summary(), scoreboard=chk.sb.summary(), func_cov_percent={"slice": round(chk.cg.percent(), 1)}, **extra)


class _MasterL:
    def __init__(self, c):
        self.c = c

    def txn_accepted(self, agent, txn):
        self.c.master_accepted(agent, txn)

    def txn_completed(self, agent, txn):
        self.c.master_completed(agent, txn)


class _SlaveL:
    def __init__(self, c):
        self.c = c

    def req_accepted(self, agent, req, err, rdata):
        self.c.slave_accepted(agent, req, err, rdata)

    def req_cancelled(self, agent, req):
        self.c.slave_cancelled(agent, req)


# ------------------------------------------------------------------------------------------------- tests
@cocotb.test()
async def slice_latency(dut):
    """Isolated transactions: +1 cycle request latency iff REQ_SLICE, +1 cycle response latency iff RSP_SLICE,
    0 for a bypassed channel (R12)."""
    tb = SliceTB(dut, "slice_latency", max_out=1)
    await tb.start()
    rng = tb.env.seeds.child("lat")
    for i in range(12):
        a = (rng.getrandbits(AW) & ~(NB - 1)) & AMASK
        tb.master.write(a, rng.getrandbits(DW)) if i & 1 else tb.master.read(a)
        await tb.drain(200)
        await tb.env.cycles(rng.randint(2, 6))
    need(len(tb.mon_up.txns) == 12 and len(tb.mon_dn.txns) == 12, "monitor transaction counts %d/%d" % (len(tb.mon_up.txns), len(tb.mon_dn.txns)))
    for u, d in zip(tb.mon_up.txns, tb.mon_dn.txns):
        need(d.t_accept - u.t_accept == REQ_SLICE, "request latency through the slice is %d cycles, expected %d" % (d.t_accept - u.t_accept, REQ_SLICE))
        need(u.t_rsp - d.t_rsp == RSP_SLICE, "response latency through the slice is %d cycles, expected %d" % (u.t_rsp - d.t_rsp, RSP_SLICE))
    await tb.finish("slice_latency")


@cocotb.test()
async def slice_capacity(dut):
    """Back-pressure capacity: with the downstream stalled the request slice absorbs exactly 2 requests (output
    register + skid), a bypassed channel 0; with the upstream response consumer stalled the response slice
    absorbs exactly 2 responses, a bypass 0."""
    tb = SliceTB(dut, "slice_capacity", max_out=8)
    await tb.start()
    rng = tb.env.seeds.child("cap")
    tb.slave.req_thr.set_mode("never")
    for i in range(8):
        tb.master.read((rng.getrandbits(AW) & ~(NB - 1)) & AMASK)
    await tb.env.cycles(25)
    need(tb.master.n_accepted == 2 * REQ_SLICE, "request channel absorbed %d requests while stalled, expected %d" % (tb.master.n_accepted, 2 * REQ_SLICE))
    tb.slave.req_thr.set_mode("always")
    await tb.drain(2000)
    # response channel: consumer stalled, producer keeps answering
    tb.master.rsp_thr.set_mode("never")
    n0 = len(tb.mon_dn.txns)
    for i in range(8):
        tb.master.read((rng.getrandbits(AW) & ~(NB - 1)) & AMASK)
    await tb.env.cycles(40)
    absorbed = len(tb.mon_dn.txns) - n0
    need(absorbed == 2 * RSP_SLICE + (0 if RSP_SLICE else 0), "response channel absorbed %d responses while the master stalled, expected %d" % (absorbed, 2 * RSP_SLICE))
    tb.master.rsp_thr.set_mode("always")
    await tb.drain(2000)
    await tb.finish("slice_capacity")


@cocotb.test()
async def slice_throughput(dut):
    """Both sides always ready, producer always valid: one transfer per cycle through every sliced channel."""
    tb = SliceTB(dut, "slice_throughput", max_out=6)
    await tb.start()
    tb.set_regime("fast")
    tb.fill(200, write=0.5)
    await tb.drain(2000)
    ups = sorted(t.t_accept for t in tb.mon_up.txns)
    span = ups[-1] - ups[0] + 1
    need(len(ups) == 200 and span <= 200 + 12, "200 requests took %d cycles through the slice (expected ~200: one per cycle)" % span)
    await tb.finish("slice_throughput")


@cocotb.test()
async def slice_random(dut):
    """Random traffic with changing back-pressure regimes on every handshake."""
    tb = SliceTB(dut, "slice_random")
    await tb.start()
    rng = tb.env.seeds.child("reg")
    names = list(REGIMES)
    for rnd in range(14):
        tb.set_regime(rng.choice(names))
        tb.fill(rng.randint(30, 80), hot=rng.choice([2, 8, 32]))
        await tb.env.cycles(rng.randint(20, 120))
    tb.set_regime("both")
    await tb.drain(40000)
    await tb.finish("slice_random")


async def _reset_round(tb, rng, style, rnd):
    tb.set_regime(rng.choice(["slave_stall", "master_stall", "both", "slow_resp"]))
    tb.fill(60, hot=6)
    await tb.env.cycles(rng.randint(6, 40))  # traffic is in flight, slices partly full
    rst = tb.rst
    target = rst.n_pulses + 1
    if style == "sync":
        rst.pulse(length=rng.randint(1, 3), delay=1, reason="sync")
        await tb.env.until(lambda: rst.n_pulses >= target and not rst.asserted, 40, "sync reset")
    elif style == "async":
        cocotb.start_soon(rst.async_pulse(phase_ns=rng.randint(2, 18) / 2.0, length_cycles=rng.randint(1, 3)))
        await tb.env.until(lambda: rst.n_pulses >= target, 40, "async reset start")
        await tb.env.until(lambda: not rst.asserted, 40, "async reset release")
    else:
        env = tb.env

        async def glitch():
            await RisingEdge(getattr(env.dut, env.clk_name))
            await Timer(2000, units="ps")
            sh = rst.rst.sh
            sh.h.value = rst.active
            sh.pend, sh.dirty = rst.active, False
            rst.asserted = True
            rst.n_pulses += 1
            env.notify_reset(True)
            for a in (tb.master, tb.slave):
                a.drive()
            for s in env.shadows.values():
                s.flush()
            await Timer(3000, units="ps")
            sh.h.value = rst.inactive
            sh.pend, sh.dirty = rst.inactive, False
            rst.asserted = False
            env.notify_reset(False)

        cocotb.start_soon(glitch())
        await tb.env.until(lambda: rst.n_pulses >= target, 40, "glitch start")
        await tb.env.cycles(2)
    await tb.env.cycles(rng.randint(0, 5))
    tb.set_regime("both")
    tb.fill(30, hot=6)
    await tb.drain(20000)


@cocotb.test()
async def slice_reset(dut):
    """Reset (sync / async mid-cycle / sub-cycle glitch) while the slices hold 0, 1 or 2 transactions: contents are
    dropped (no stale request reaches the slave, no stale response the master), clean restart afterwards."""
    tb = SliceTB(dut, "slice_reset")
    await tb.start()
    rng = tb.env.seeds.child("rst")
    for rnd in range(18):
        await _reset_round(tb, rng, ("sync", "async", "glitch")[rnd % 3], rnd)
    need(tb.rst.n_pulses >= 18, "resets did not happen")
    await tb.finish("slice_reset")
