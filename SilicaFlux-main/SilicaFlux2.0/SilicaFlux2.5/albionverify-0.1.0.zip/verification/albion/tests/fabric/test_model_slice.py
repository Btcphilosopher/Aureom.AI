"""pytest (no simulator): elastic-buffer / reg-slice / error-slave cycle models against hand-traced behaviour."""
from albionverify.models.fabric_slice import ElasticBuffer, ErrorSlaveModel, RegSliceModel


def test_model_elastic_buffer_latency_and_order():
    b = ElasticBuffer()
    assert (b.s_ready, b.m_valid) == (1, 0)
    b.step(1, "A", 1)  # accepted at edge 0 ...
    assert (b.m_valid, b.m_data) == (1, "A")  # ... visible in the next cycle: +1 cycle latency
    b.step(1, "B", 1)  # A leaves, B enters in the same edge: full throughput
    assert (b.m_valid, b.m_data, b.s_ready) == (1, "B", 1)
    b.step(0, None, 1)
    assert b.m_valid == 0


def test_model_elastic_buffer_capacity_two_and_registered_ready():
    b = ElasticBuffer()
    b.step(1, "A", 0)
    assert b.s_ready == 1  # one entry: still ready
    b.step(1, "B", 0)
    assert (b.s_ready, b.m_data) == (0, "A")  # two entries: ready low, output stable
    push, pop = b.step(1, "C", 0)
    assert not push and not pop and b.q == ["A", "B"]
    push, pop = b.step(1, "C", 1)  # downstream takes A; C is not accepted this edge (ready was low)
    assert pop and not push and b.q == ["B"]
    assert b.s_ready == 1


def test_model_reg_slice_channel_selection():
    # bypass channels are wires
    m = RegSliceModel(False, False)
    o = m.expected(("w", 1), 1, ("r", 0), 0)
    assert (o["s_req_ready"], o["m_req_valid"], o["m_req_data"]) == (1, 1, ("w", 1))
    assert (o["m_rsp_ready"], o["s_rsp_valid"], o["s_rsp_data"]) == (0, 1, ("r", 0))
    # sliced channels ignore the combinational ready/valid of the other side
    m = RegSliceModel(True, True)
    o = m.expected(("w", 1), 0, ("r", 0), 0)
    assert (o["s_req_ready"], o["m_req_valid"]) == (1, 0)
    assert (o["m_rsp_ready"], o["s_rsp_valid"]) == (1, 0)
    m.step(("w", 1), 0, ("r", 0), 0)
    o = m.expected(None, 1, None, 1)
    assert (o["m_req_valid"], o["m_req_data"], o["s_rsp_valid"], o["s_rsp_data"]) == (1, ("w", 1), 1, ("r", 0))


def test_model_error_slave():
    e = ErrorSlaveModel()
    assert (e.req_ready(0), e.rsp_valid()) == (1, 0)
    e.step(1, 0)  # request accepted at edge 0 ...
    assert e.rsp_valid() == 1  # ... error response one cycle later
    assert e.req_ready(0) == 0 and e.req_ready(1) == 1  # one buffered response; back-to-back possible when rsp_ready
    e.step(0, 0)
    assert e.rsp_valid() == 1  # held
    e.step(1, 1)  # response accepted while a new request is accepted
    assert e.rsp_valid() == 1
    e.step(0, 1)
    assert e.rsp_valid() == 0
