"""Directed corner tests for sfb_crossbar.  Every test also runs under the lockstep model + transaction
scoreboard of xbar_tb.py; the explicit assertions below pin the specific spec rule the scenario is about
(hand-computed expectations, independent of the models)."""
import random
from typing import List

import cocotb

from albionverify.bus.reqrsp import Req
from albionverify.core import AlbionCheckError

from .xbar_tb import (CFG, AMAP, ARB, CONT, CONTENDED, DW, NB, NM, NS, REACH, SOLO, Gen, XbarTB, error_addr, has_decode_errors, pick_strobe)

CAN_ERR = any(has_decode_errors(m) for m in range(NM))
TWO_M = NM >= 2


def need(cond: bool, msg: str) -> None:
    if not cond:
        raise AlbionCheckError(msg)


def recs(tb, **kw) -> list:
    out = list(tb.chk.log)
    for k, v in kw.items():
        out = [r for r in out if getattr(r, k) == v]
    return out


# --------------------------------------------------------------------------------------------- address map
@cocotb.test()
async def map_golden(dut):
    """Hand-computed routing table (xbar_cfg.golden): first/last aligned address of every region, one
    before/after, holes, misaligned, access-matrix denial -- read AND write from every master."""
    need(CFG is not None and CFG.golden, "no golden table for this configuration")
    tb = XbarTB(dut, "map_golden", profile="mixed")
    await tb.start()
    rng = tb.env.seeds.child("dir")
    expect = {m: [] for m in range(NM)}
    for m in range(NM):
        for gm, addr, exp in CFG.golden:
            if gm is not None and gm != m:
                continue
            tb.masters[m].write(addr, rng.getrandbits(DW), pick_strobe(rng, NB))
            expect[m].append((addr, True, exp))
            tb.masters[m].read(addr)
            expect[m].append((addr, False, exp))
    await tb.drain(40000)
    for m in range(NM):
        got = recs(tb, m=m)
        need(len(got) == len(expect[m]), "master %d: %d transactions expected, %d accepted" % (m, len(expect[m]), len(got)))
        for r, (addr, wr, exp) in zip(got, expect[m]):
            need(r.req.addr == addr and r.req.write == wr, "bookkeeping")
            ok = (r.kind == "ok" and r.tgt == exp) if isinstance(exp, int) else (r.kind == exp and r.tgt is None)
            need(ok, "master %d addr 0x%x: hand-computed expectation %r, DUT routed to %r (decode kind %s)" % (m, addr, exp, r.tgt, r.kind))
            need(r.rsp_err == (True if not isinstance(exp, int) else r.slave_err), "error flag of 0x%x" % addr)
    await tb.finish("map_golden")


@cocotb.test()
async def map_boundaries(dut):
    """Every region's boundary neighbourhood (first/last, +-1 word, every single-bit departure of the mask,
    each don't-care bit) from EVERY master, write then read back; misaligned variants of a subset."""
    tb = XbarTB(dut, "map_boundaries", profile="mixed")
    await tb.start()
    rng = tb.env.seeds.child("dir")
    probes = AMAP.all_probe_addresses()
    for m in range(NM):
        order = list(probes)
        rng.shuffle(order)
        for a in order:
            tb.masters[m].write(a, rng.getrandbits(DW), pick_strobe(rng, NB))
            tb.masters[m].read(a)
        if NB > 1:
            for a in order[: max(8, len(order) // 8)]:
                tb.masters[m].write(a | rng.randint(1, NB - 1), rng.getrandbits(DW))
    await tb.drain(400000)
    for s in range(NS):
        if any(s in REACH[m] for m in range(NM)):
            need(tb.chk.n_to_slave[s] > 0, "slave %d never received a request although its region is reachable (address map not effective)" % s)
    if CAN_ERR:
        need(sum(tb.chk.n_err_kind.values()) > 0, "no decode errors were exercised")
    await tb.finish("map_boundaries")


@cocotb.test()
async def alignment(dut):
    """R9: every misaligned offset (1..DW/8-1) at the first/middle/last aligned address of every region."""
    tb = XbarTB(dut, "alignment", profile="mixed")
    await tb.start()
    rng = tb.env.seeds.child("dir")
    bases = []
    for s in range(NS):
        mid = AMAP.aligned(AMAP.bases[s] | ((~AMAP.masks[s] & 0xFFFFFFFF) >> 1))
        bases += [AMAP.region_first(s), mid, AMAP.aligned(AMAP.region_last(s))]
    for m in range(NM):
        for b in bases:
            for off in range(1, NB):
                tb.masters[m].read(b | off)
                tb.masters[m].write(b | off, rng.getrandbits(DW), pick_strobe(rng, NB))
            tb.masters[m].write(b, rng.getrandbits(DW))  # an aligned access between the misaligned ones
    await tb.drain(400000)
    mis = [r for r in tb.chk.log if r.req.addr & (NB - 1)]
    need(len(mis) > 0, "no misaligned access was issued")
    if AMAP.check_align:
        need(all(r.kind == "misaligned" and r.tgt is None and r.rsp_err for r in mis), "CHECK_ALIGN=1: a misaligned request was not answered with a decode error")
    else:
        fwd = [r for r in mis if r.tgt is not None]
        need(len(fwd) > 0, "CHECK_ALIGN=0: misaligned requests were not forwarded to a slave")
        need(all(r.kind != "misaligned" for r in mis), "CHECK_ALIGN=0 must not produce misaligned decode errors")
    await tb.finish("alignment")


# --------------------------------------------------------------------------------------------- decode errors
@cocotb.test(skip=not CAN_ERR)
async def decode_error_timing(dut):
    """R5/R8/section 5: decode error answered ONE cycle after acceptance (rdata 0), held under rsp back-pressure,
    full throughput on the error path, no slave sees the request; err_evt/addr/master/write at acceptance."""
    tb = XbarTB(dut, "decode_error_timing", profile="dense", uniform=True)
    await tb.start()
    rng = tb.env.seeds.child("dir")
    m = next(i for i in range(NM) if has_decode_errors(i))
    base_slave = sum(len(a.log) for a in tb.slaves)
    # phase A: rsp_ready always high -> exactly one cycle latency, one transaction per cycle
    for i in range(24):
        a, _ = error_addr(m, rng)
        tb.masters[m].submit(Req(bool(i & 1), a, rng.getrandbits(DW), None))
    await tb.drain(2000)
    ra = recs(tb, m=m)
    need(len(ra) == 24, "phase A transaction count")
    for k, r in enumerate(ra):
        need(r.rsp_err is True and r.rsp_rdata == 0, "decode error response must be rsp_error=1 rsp_rdata=0")
        need(r.t_rsp - r.t_acc == 1, "decode-error response must arrive exactly 1 cycle after acceptance (got %d)" % (r.t_rsp - r.t_acc))
        if k:
            need(r.t_acc == ra[k - 1].t_acc + 1, "error path must sustain one transaction per cycle (accept %d after %d)" % (r.t_acc, ra[k - 1].t_acc))
    # phase B: slow rsp_ready: response held, next request accepted exactly when the previous response is accepted
    tb.masters[m].rsp_thr.set_mode("pattern:0000001")
    n0 = len(tb.chk.log)
    for i in range(10):
        a, _ = error_addr(m, rng)
        tb.masters[m].read(a) if i & 1 else tb.masters[m].write(a, rng.getrandbits(DW))
    await tb.drain(2000)
    rb = tb.chk.log[n0:]
    for k, r in enumerate(rb):
        need(r.t_rsp - r.t_acc >= 1, "response not after acceptance")
        if k:
            need(r.t_acc == rb[k - 1].t_rsp, "R6: next request accepted at cycle %d but previous response accepted at %d" % (r.t_acc, rb[k - 1].t_rsp))
    need(max(r.t_rsp - r.t_acc for r in rb) >= 5, "back-pressure phase did not hold a response for several cycles")
    need(sum(len(a.log) for a in tb.slaves) == base_slave, "a decode error leaked to a slave")
    # phase C: all masters at once (capture contention is exercised in err_capture)
    tb.masters[m].rsp_thr.set_mode("always")
    for mm in range(NM):
        if has_decode_errors(mm):
            for _ in range(6):
                tb.masters[mm].read(error_addr(mm, rng)[0])
    await tb.drain(2000)
    need(sum(len(a.log) for a in tb.slaves) == base_slave, "a decode error leaked to a slave (phase C)")
    await tb.finish("decode_error_timing")


@cocotb.test(skip=not (CAN_ERR and TWO_M))
async def err_capture(dut):
    """err_evt/err_addr/err_master/err_write: with several decode errors accepted in the same cycle the
    lowest-index master is exported; errors of all masters in one cycle; random subsets; mixed with traffic."""
    tb = XbarTB(dut, "err_capture", profile="dense", uniform=True)
    await tb.start()
    rng = tb.env.seeds.child("dir")
    errm = [m for m in range(NM) if has_decode_errors(m)]
    for rnd in range(14):
        subset = errm if rnd < 3 else [m for m in errm if rng.random() < 0.6] or [errm[-1]]
        for m in subset:
            a, _ = error_addr(m, rng)
            tb.masters[m].write(a, rng.getrandbits(DW)) if rng.random() < 0.5 else tb.masters[m].read(a)
        for m in range(NM):  # the others carry ordinary traffic in the same cycle
            if m not in subset and REACH[m]:
                s = rng.choice(REACH[m])
                tb.masters[m].read(rng.choice(SOLO[(m, s)]))
        await tb.drain(500)
    need(tb.chk.max_err_burst == len(errm), "never saw all %d masters' decode errors accepted in one cycle (saw %d)" % (len(errm), tb.chk.max_err_burst))
    await tb.finish("err_capture")


# --------------------------------------------------------------------------------------------- arbitration
@cocotb.test(skip=not CONTENDED)
async def arb_contention(dut):
    """Sustained contention for each slave under three slave back-pressure regimes.  Fixed priority: strict
    priority order (documented starvation of lower masters).  Round robin: strict rotation, equal shares,
    bounded waiting.  Work conservation and ownership checks come from the checker."""
    tb = XbarTB(dut, "arb_contention", profile="dense", uniform=True)
    await tb.start()
    rng = tb.env.seeds.child("dir")
    K = 18
    for s in CONTENDED:
        masters, addrs = CONT[s]
        for pat in ("always", "random:0.5", "bursty:1-6"):
            tb.slaves[s].req_thr.set_mode(pat)
            n0 = len(tb.chk.log)
            for m in masters:
                for i in range(K):
                    a = rng.choice(addrs)
                    tb.masters[m].write(a, rng.getrandbits(DW), pick_strobe(rng, NB)) if rng.random() < 0.5 else tb.masters[m].read(a)
            await tb.drain(20000)
            tb.slaves[s].req_thr.set_mode("always")
            seq = [r.m for r in sorted((r for r in tb.chk.log[n0:] if r.tgt == s), key=lambda r: r.t_acc)]
            need(len(seq) == K * len(masters), "slave %d: %d acceptances expected, %d seen" % (s, K * len(masters), len(seq)))
            if ARB == 0:
                need(seq == sorted(seq), "fixed priority, slave %d (%s): acceptance order %s is not strictly priority ordered" % (s, pat, seq))
            else:
                nm_ = len(masters)
                need(all(seq.count(m) == K for m in masters), "round robin shares are not equal: %s" % seq)
                need(all(seq[i] == seq[i - nm_] for i in range(nm_, len(seq))), "round robin order is not a strict rotation at slave %d (%s): %s" % (s, pat, seq))
                need(sorted(seq[:nm_]) == sorted(masters), "round robin: first %d acceptances %s do not serve every contender once" % (nm_, seq[:nm_]))
    if ARB == 1:
        need(tb.chk.max_rr_wait <= NM - 1, "bounded waiting exceeded")
    await tb.finish("arb_contention")


@cocotb.test(skip=not CONTENDED)
async def grant_lock(dut):
    """Grant lock (PROTOCOL sec. 4): a request presented to a stalling slave keeps the grant although a
    higher-priority master arrives; the slave-side payload stays stable (R2 at the slave port)."""
    tb = XbarTB(dut, "grant_lock", profile="dense", uniform=True)
    await tb.start()
    rng = tb.env.seeds.child("dir")
    done = 0
    for s in CONTENDED:
        masters, addrs = CONT[s]
        lo, hi = masters[0], masters[-1]
        n0 = len(tb.chk.log)
        tb.slaves[s].req_thr.set_mode("never")
        a_hi, a_lo = rng.choice(addrs), rng.choice(addrs)
        tb.masters[hi].write(a_hi, rng.getrandbits(DW))
        await tb.env.cycles(7)  # presented, granted, stalled for several cycles
        tb.masters[lo].write(a_lo, rng.getrandbits(DW))
        for m in masters[1:-1]:
            tb.masters[m].read(rng.choice(addrs))
        await tb.env.cycles(9)  # higher-priority requesters join during the stall
        tb.slaves[s].req_thr.set_mode("always")
        await tb.drain(2000)
        first = sorted((r for r in tb.chk.log[n0:] if r.tgt == s), key=lambda r: r.t_acc)[0]
        need(first.m == hi, "slave %d: master %d (stalled, locked) was pre-empted by master %d (first accepted master was %d)" % (s, hi, lo, first.m))
        done += 1
        if done >= 3:
            break
    await tb.finish("grant_lock")


@cocotb.test(skip=not CONTENDED)
async def lock_release_on_withdraw(dut):
    """Header of sfb_arbiter: a locked requester that withdraws releases the lock and arbitration resumes
    the same cycle (R2 violation tolerated by the fabric)."""
    tb = XbarTB(dut, "lock_release_on_withdraw", profile="dense", uniform=True, withdraw=1e-9)
    await tb.start()
    rng = tb.env.seeds.child("dir")
    s = CONTENDED[0]
    masters, addrs = CONT[s]
    lo, hi = masters[0], masters[-1]
    tb.slaves[s].req_thr.set_mode("never")
    tb.masters[hi].write(rng.choice(addrs), rng.getrandbits(DW))
    await tb.env.cycles(6)
    tb.masters[lo].read(rng.choice(addrs))
    await tb.env.cycles(3)
    tb.masters[hi].force_withdraw = True  # hi drops its request while it holds the (stalled) grant
    await tb.env.cycles(4)
    tb.slaves[s].req_thr.set_mode("always")
    await tb.drain(2000)
    first = sorted((r for r in tb.chk.log if r.tgt == s), key=lambda r: r.t_acc)[0]
    need(first.m == lo, "lock was not released after the locked master withdrew (first accepted: master %d)" % first.m)
    need(tb.masters[hi].n_withdrawn >= 1, "withdrawal did not happen")
    await tb.finish("lock_release_on_withdraw")


MANY = [s for s in CONTENDED if len(CONT[s][0]) >= 3]


@cocotb.test(skip=not MANY)
async def lock_withdraw_pointer(dut):
    """Round-robin pointer moves only on ACCEPTANCE (PROTOCOL sec. 4): the middle master b is granted and stalled for
    several cycles (lock), a lower and a higher master join, then b withdraws.  The pointer is still at its reset value, so
    the arbitration of the withdrawal cycle must pick the lower master a (a pointer that moved on the stall would pick c);
    the first master accepted once the slave is released is a."""
    tb = XbarTB(dut, "lock_withdraw_pointer", profile="dense", uniform=True, withdraw=1e-9)
    await tb.start()
    rng = tb.env.seeds.child("dir")
    s = MANY[0]
    masters, addrs = CONT[s]
    a, b, c = masters[0], masters[1], masters[2]
    tb.slaves[s].req_thr.set_mode("never")
    tb.masters[b].write(rng.choice(addrs), rng.getrandbits(DW))
    await tb.env.cycles(6)  # b granted, presented, stalled: lock engaged, pointer must stay at its reset value
    tb.masters[a].read(rng.choice(addrs))
    tb.masters[c].read(rng.choice(addrs))
    await tb.env.cycles(4)
    tb.masters[b].force_withdraw = True  # b drops its request: lock released, arbitration resumes from the unmoved pointer
    await tb.env.cycles(6)
    tb.slaves[s].req_thr.set_mode("always")
    await tb.drain(2000)
    first = sorted((r for r in tb.chk.log if r.tgt == s), key=lambda r: r.t_acc)[0]
    need(first.m == a, "after the locked master withdrew the pointer must be unchanged, so master %d (nearest from pointer 0) must win; first accepted: master %d" % (a, first.m))
    await tb.finish("lock_withdraw_pointer")


# --------------------------------------------------------------------------------------------- flow / ordering
@cocotb.test()
async def throughput(dut):
    """R6 full throughput with 1-cycle slaves: one transaction per cycle per master port, per slave port, and
    several independent master->slave streams in parallel; latency of the crossbar is 0 cycles (response in
    the cycle after acceptance)."""
    tb = XbarTB(dut, "throughput", profile="dense", uniform=True, latency="fixed:1")
    await tb.start()
    rng = tb.env.seeds.child("dir")
    m0 = next(m for m in range(NM) if REACH[m])
    s0 = REACH[m0][0]
    n = 48
    for i in range(n):
        a = SOLO[(m0, s0)][i % len(SOLO[(m0, s0)])]
        tb.masters[m0].write(a, rng.getrandbits(DW)) if i & 1 else tb.masters[m0].read(a)
    await tb.drain(2000)
    r = recs(tb, m=m0)
    for k, x in enumerate(r):
        need(x.t_rsp - x.t_acc == 1, "slave latency 1 must give response one cycle after acceptance (got %d)" % (x.t_rsp - x.t_acc))
        if k:
            need(x.t_acc == r[k - 1].t_acc + 1, "single master did not sustain one transaction per cycle (gap at %d)" % k)
    if CONTENDED:  # two masters share one slave: the slave must never idle between requests
        s = CONTENDED[0]
        masters, addrs = CONT[s]
        n0 = len(tb.chk.log)
        for m in masters[:2]:
            for i in range(32):
                tb.masters[m].read(rng.choice(addrs))
        await tb.drain(2000)
        acc = sorted(x.t_acc for x in tb.chk.log[n0:])
        need(all(b - a == 1 for a, b in zip(acc, acc[1:])), "slave %d was not re-granted in the cycle its response was accepted (acceptances %s)" % (s, acc[:12]))
    # independent streams: distinct masters to distinct slaves run concurrently at full rate
    pair = None
    for ma in range(NM):
        for mb in range(ma + 1, NM):
            for sa in REACH[ma]:
                for sb in REACH[mb]:
                    if sa != sb and pair is None:
                        pair = (ma, sa, mb, sb)
    if pair:
        ma, sa, mb, sb = pair
        n0 = len(tb.chk.log)
        for i in range(32):
            tb.masters[ma].read(SOLO[(ma, sa)][i % 8])
            tb.masters[mb].read(SOLO[(mb, sb)][i % 8])
        await tb.drain(2000)
        for m in (ma, mb):
            r = [x for x in tb.chk.log[n0:] if x.m == m]
            need(all(r[k].t_acc == r[0].t_acc + k for k in range(len(r))), "master %d stream (parallel with another) was not one transaction per cycle" % m)
    await tb.finish("throughput")


@cocotb.test()
async def rsp_backpressure(dut):
    """m_rsp_ready stalls of up to ~20 cycles with contention: responses held stable, the owner keeps the slave
    busy (no second request reaches it), data is delivered intact after the stall."""
    tb = XbarTB(dut, "rsp_backpressure", profile="rsp_bp", uniform=True, throttles={"rsp": "bursty:8-20", "req": "always", "sreq": "always", "srsp": "always"})
    await tb.start()
    tb.fill_random(60, weights=dict(edge=0.1, hot=0.5, inside=0.2, unmapped=0.1, denied=0.05, misal=0.05))
    await tb.drain(100000)
    need(tb.chk.max_m_rspstall >= 8, "response back-pressure never lasted 8 cycles (max %d)" % tb.chk.max_m_rspstall)
    await tb.finish("rsp_backpressure")


@cocotb.test()
async def slave_errors(dut):
    """Slave error responses propagate unchanged (error=1, rdata=0) and leave the slave untouched; neighbouring
    good addresses are unaffected; mixed with random errors."""
    tb = XbarTB(dut, "slave_errors", profile="mixed", slave_err="window:0x40+random:0.15")
    await tb.start()
    rng = tb.env.seeds.child("dir")
    for m in range(NM):
        for s in REACH[m]:
            pool = SOLO[(m, s)]
            bad = [a for a in pool if (a & 0xFFF) < 0x40]
            good = [a for a in pool if (a & 0xFFF) >= 0x80]
            if not bad or not good:
                continue
            a_bad, a_good = bad[0], good[0]
            tb.masters[m].write(a_good, rng.getrandbits(DW))
            tb.masters[m].read(a_good)
            tb.masters[m].write(a_bad, rng.getrandbits(DW))
            tb.masters[m].read(a_bad)
            tb.masters[m].write(a_bad, rng.getrandbits(DW), 0)
            tb.masters[m].read(a_good)
    tb.fill_random(40)
    await tb.drain(100000)
    n_err = [r for r in tb.chk.log if r.tgt is not None and r.slave_err]
    need(len(n_err) >= 4, "slave error injection produced only %d errors" % len(n_err))
    for r in n_err:
        need(r.rsp_err is True and r.rsp_rdata == 0, "slave error not propagated as error=1/rdata=0 (master %d addr 0x%x)" % (r.m, r.req.addr))
    for r in tb.chk.log:
        if r.tgt is not None and not r.slave_err:
            need(not r.rsp_err, "a good slave response arrived with rsp_error=1 (addr 0x%x)" % r.req.addr)
    await tb.finish("slave_errors")


async def _same_addr(dut, name: str, profile: str) -> None:
    tb = XbarTB(dut, name, profile=profile)
    await tb.start()
    tb.fill_random(70, weights=dict(edge=0.0, hot=1.0, inside=0.0, unmapped=0.0, denied=0.0, misal=0.0, write=0.55))
    await tb.drain(100000)
    await tb.finish(name)


@cocotb.test(skip=not TWO_M)
async def same_addr_dense(dut):
    """All masters read/write the SAME few words of the same slave back to back; the reference order is the
    slave-side acceptance order (read data checked against it, final memory equal)."""
    await _same_addr(dut, "same_addr_dense", "dense")


@cocotb.test(skip=not TWO_M)
async def same_addr_stalled(dut):
    await _same_addr(dut, "same_addr_stalled", "slave_bp")


@cocotb.test()
async def strobes_lanes(dut):
    """R10: every write-strobe pattern (all 2^NB for NB<=4, else single/adjacent/random/zero/full) merged
    byte-exactly, little-endian lanes, read back in full."""
    tb = XbarTB(dut, "strobes_lanes", profile="dense", uniform=True)
    await tb.start()
    rng = tb.env.seeds.child("dir")
    full = (1 << NB) - 1
    pats = list(range(0, full + 1)) if NB <= 4 else [0, full] + [1 << i for i in range(NB)] + [(3 << i) & full for i in range(NB - 1)] + [rng.getrandbits(NB) for _ in range(96)]
    for m in range(NM):
        for s in REACH[m][:3]:
            pool = SOLO[(m, s)]
            for i, p in enumerate(pats[: 160 if NB > 4 else 999]):
                a = pool[(i + m) % min(4, len(pool))]
                tb.masters[m].write(a, rng.getrandbits(DW), p)
                tb.masters[m].read(a)
    await tb.drain(200000)
    await tb.finish("strobes_lanes")


@cocotb.test(skip=not CONTENDED)
async def events_contention(dut):
    """ev_* outputs for a hand-derived scenario: two masters present at once to one slave (slave free, 1-cycle
    latency).  Master a wins; b loses arbitration for exactly one cycle and stalls for exactly one cycle;
    b is accepted in the very cycle a's response is accepted."""
    tb = XbarTB(dut, "events_contention", profile="dense", uniform=True, latency="fixed:1")
    await tb.start()
    rng = tb.env.seeds.child("dir")
    s = CONTENDED[0]
    masters, addrs = CONT[s]
    a, b = masters[0], masters[1]
    tb.masters[a].write(rng.choice(addrs), rng.getrandbits(DW))
    tb.masters[b].read(rng.choice(addrs))
    await tb.drain(200)
    ra, rb = recs(tb, m=a)[0], recs(tb, m=b)[0]
    need(rb.t_acc == ra.t_acc + 1, "second master must be accepted in the cycle after the first (accepted %d and %d)" % (ra.t_acc, rb.t_acc))
    ev = tb.chk.ev_sum
    need(ev["accept"][a] == 1 and ev["accept"][b] == 1, "ev_req_accept counts %s" % ev["accept"])
    need(ev["loss"][a] == 0 and ev["loss"][b] == 1, "ev_arb_loss counts %s (expected a=0, b=1)" % ev["loss"])
    need(ev["stall"][a] == 0 and ev["stall"][b] == 1, "ev_req_stall counts %s (expected a=0, b=1)" % ev["stall"])
    need(sum(ev["rsp_stall"]) == 0, "ev_rsp_stall must be 0 with rsp_ready high: %s" % ev["rsp_stall"])
    # response stall: hold the master's rsp_ready low for several cycles
    tb.masters[a].rsp_thr.set_mode("never")
    tb.masters[a].read(rng.choice(addrs))
    await tb.env.until(lambda: tb.masters[a]._rsp_stall_run >= 4, 200, "response held for 4 cycles")
    tb.masters[a].rsp_thr.set_mode("always")
    await tb.drain(200)
    need(ev["rsp_stall"][a] >= 4, "ev_rsp_stall[a] = %d after a >=4-cycle response stall" % ev["rsp_stall"][a])
    await tb.finish("events_contention")
