"""pytest (no simulator): the address-decode model against HAND-COMPUTED routing tables and spec examples."""
import itertools

import pytest

from albionverify.models.fabric_decoder import AddressMap, Decode, unpack

from .xbar_cfg import CONFIGS, pack


def amap_of(cfg):
    return AddressMap.from_params(dict(cfg.params()))


@pytest.mark.parametrize("name", sorted(CONFIGS))
def test_model_golden_tables(name):
    """Every hand-computed (master, address) -> slave/kind entry of every configuration."""
    cfg = CONFIGS[name]
    a = amap_of(cfg)
    n = 0
    for gm, addr, exp in cfg.golden:
        for m in ([gm] if gm is not None else range(cfg.nm)):
            d = a.decode(m, addr)
            if isinstance(exp, int):
                assert d == Decode("ok", exp), "%s m%d 0x%x: %r != slave %d" % (name, m, addr, d, exp)
            else:
                assert d.kind == exp and d.slave is None, "%s m%d 0x%x: %r != %s" % (name, m, addr, d, exp)
            n += 1
    assert n >= 8


def test_model_params_roundtrip():
    """Wide parameters are decoded with slave 0 in the LOW bits and MST_SLV_EN bit m*NS+s."""
    cfg = CONFIGS["xbar_3x3_part"]
    a = amap_of(cfg)
    assert a.bases == [0x10000000, 0x10008000, 0x40000000]
    assert a.masks == [0xFFFF8000, 0xFFFF8000, 0xFFFE0000]
    # asymmetric matrix m0:{s0,s1} m1:{s0,s1,s2} m2:{s2}
    assert a.en == [[1, 1, 0], [1, 1, 1], [0, 0, 1]]
    assert dict(cfg.params())["MST_SLV_EN"] == 0b100111011  # bits 0,1,3,4,5,8 = 0x13B
    assert unpack(pack([1, 2, 3], 32), 3, 32) == [1, 2, 3]


def test_model_default_matrix_is_all_ones():
    a = AddressMap.from_params({"NM": 2, "NS": 3, "SLV_BASE": 0, "SLV_MASK": 0, "DW": 32})
    assert a.en == [[1, 1, 1], [1, 1, 1]]
    # default SLV_BASE = SLV_MASK = 0: every aligned address matches slave 0 (lowest wins)
    assert a.decode(0, 0x12345678) == Decode("ok", 0)


def test_model_region_geometry():
    a = AddressMap([0x10000000, 0x0A003000], [0xFFFF8000, 0x0F0FF000], dw=32)
    assert (a.region_first(0), a.region_last(0), a.region_size(0)) == (0x10000000, 0x10007FFF, 0x8000)
    assert a.contiguous(0)
    # sparse mask: free bits = 31..28, 23..20, 11..0 -> 4+4+12 = 20 free bits
    assert a.region_last(1) == 0x0A003000 | 0xF0F00FFF
    assert a.region_size(1) == 1 << 20
    assert not a.contiguous(1)


def test_model_alignment_widths():
    for dw, nb in ((32, 4), (64, 8), (128, 16)):
        a = AddressMap([0], [0], dw=dw)
        assert a.decode(0, 0x1000) == Decode("ok", 0)
        for off in range(1, nb):
            assert a.decode(0, 0x1000 + off).kind == "misaligned", (dw, off)
        assert a.decode(0, 0x1000 + nb).kind == "ok"
    # CHECK_ALIGN = 0: no alignment decode error
    a = AddressMap([0x1000], [0xFFFFF000], dw=64, check_align=False)
    assert a.decode(0, 0x1003) == Decode("ok", 0)


def test_model_precedence_and_denial():
    # regions overlap: s0 = 64 KiB at 0x10000000, s1 = first 4 KiB of it, s2 catch-all; m1 may not use s0
    a = AddressMap([0x10000000, 0x10000000, 0], [0xFFFF0000, 0xFFFFF000, 0], [[1, 1, 1], [0, 1, 1]], dw=32)
    assert a.decode(0, 0x10000100) == Decode("ok", 0)  # lowest wins
    assert a.decode(1, 0x10000100) == Decode("ok", 1)  # s0 denied -> next match
    assert a.decode(1, 0x10008000) == Decode("ok", 2)  # s0 denied, s1 no match, catch-all
    # denial reports 'denied' only when nothing else matches
    b = AddressMap([0x40000000], [0xFFFE0000], [[1], [0]], dw=32)
    assert b.decode(0, 0x40000000) == Decode("ok", 0)
    assert b.decode(1, 0x40000000) == Decode("denied")
    assert b.decode(1, 0x50000000) == Decode("unmapped")
    # misaligned takes precedence over everything
    assert b.decode(1, 0x40000001).kind == "misaligned"


def test_model_soc_map_matches_memory_map_md():
    """MEMORY_MAP.md regions (base, size): BOOT_ROM 0x0/4K, SRAM banks 0x10000000+k*32K, TSPM 0x20000000/16K, PERIPH 0x40000000/128K."""
    a = amap_of(CONFIGS["xbar_soc4x7"])
    table = [(0x0, 0x1000, 0), (0x10000000, 0x8000, 1), (0x10008000, 0x8000, 2), (0x10010000, 0x8000, 3), (0x10018000, 0x8000, 4), (0x20000000, 0x4000, 5), (0x40000000, 0x20000, 6)]
    for base, size, s in table:
        assert a.region_first(s) == base and a.region_last(s) == base + size - 1 and a.region_size(s) == size
        for m in (0, 1):
            assert a.decode(m, base) == Decode("ok", s)
            assert a.decode(m, base + size - 4) == Decode("ok", s)
            assert a.decode(m, base + size).kind in ("unmapped", "ok")  # next region or hole
    # holes
    for hole in (0x00001000, 0x10020000, 0x20004000, 0x40020000, 0x80000000):
        assert a.decode(0, hole).kind == "unmapped"
    # CPUI (2) and DMA (3) cannot reach the peripherals
    assert a.decode(2, 0x40000000).kind == "denied" and a.decode(3, 0x4001FFFC).kind == "denied"
    assert a.decode(2, 0x10000000) == Decode("ok", 1)


@pytest.mark.parametrize("name", sorted(CONFIGS))
def test_model_probes_cover_both_sides_of_every_boundary(name):
    cfg = CONFIGS[name]
    a = amap_of(cfg)
    for s in range(cfg.ns):
        probes = a.probe_addresses(s)
        assert a.region_first(s) in probes
        assert a.aligned(a.region_last(s)) in probes
        assert all(p % cfg.nbytes == 0 for p in probes)
        classes = {a.edge_class(p, s) for p in probes}
        assert {"first", "last"} <= classes
        # at least one probe inside and one outside of the region (outside = single-bit departure)
        assert any(a.matches(s, p) for p in probes)
        assert a.masks[s] == 0 or any(not a.matches(s, p) for p in probes)  # a catch-all region (mask 0) has no outside
