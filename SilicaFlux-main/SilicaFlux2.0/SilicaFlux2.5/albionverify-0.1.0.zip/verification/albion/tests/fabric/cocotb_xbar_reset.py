"""Reset-during-traffic tests for sfb_crossbar (PROTOCOL.md R11).

R11: asynchronous assert, synchronous release; reset cancels every transaction in flight -- NO response is
delivered for it; an accepted write may or may not have been performed (the reference memory marks the bytes
uncertain, ``BackingStore.write_uncertain``); during reset nothing is transferred; after release the fabric
restarts cleanly (every register back in its reset state: the lockstep model resets with it).

Reset styles: ``sync``  -- asserted right after a clock edge when a chosen fabric state holds,
              ``async`` -- asserted in the MIDDLE of a clock period (ResetSequencer.async_pulse),
              ``glitch`` -- a pulse that starts and ends between two clock edges (no clock edge sees reset low): only
                             an asynchronous-reset implementation reacts to it.
"""
import cocotb
from cocotb.triggers import RisingEdge, Timer

from albionverify.core import AlbionCheckError

from .xbar_tb import AMAP, ARB, NB, NM, NS, DW, XbarTB, Gen, REACH

TRIGGERS = [
    # (name, regime, traffic weights, predicate(tb))
    ("outstanding", "fast", {}, lambda tb: any(tb.chk.mfifo[m] for m in range(NM))),
    ("write_inflight_at_slave", "slow_slave", dict(write=0.8, unmapped=0.0, misal=0.0), lambda tb: any(t is not None and t.req.write for t in tb.chk.sinfl)),
    ("read_inflight_at_slave", "slow_slave", dict(write=0.2, unmapped=0.0, misal=0.0), lambda tb: any(t is not None and not t.req.write for t in tb.chk.sinfl)),
    ("stalled_grant_lock", "stall_slave", dict(unmapped=0.0, misal=0.0), lambda tb: any(tb.chk.stalled_prev)),
    ("error_response_pending", "stall_rsp", dict(unmapped=0.45, misal=0.45, edge=0.03, hot=0.03, inside=0.04), lambda tb: any(tb.chk.model.epend)),
    ("response_stalled", "stall_rsp", dict(unmapped=0.1), lambda tb: any(v > 0 for v in tb.chk.m_rspstall)),
    ("contended_stall", "stall_slave", dict(hot=0.8, edge=0.0, inside=0.0, unmapped=0.0, misal=0.0), lambda tb: sum(tb.chk.stalled_prev) >= 1 and sum(1 for m in range(NM) if tb.pm[m]["valid"].read()) >= 2),
]
TRIG_LIST = TRIGGERS if NM >= 2 else [t for t in TRIGGERS if t[0] != "contended_stall"]


def need(cond: bool, msg: str) -> None:
    if not cond:
        raise AlbionCheckError(msg)


async def _post_reset(tb: XbarTB, gen_seed: str, n: int = 24) -> None:
    """Idle for a few cycles (a stale response / grant would show up), then fresh traffic incl. reads of
    previously written (hot) addresses; everything is checked as usual."""
    rng = tb.env.seeds.child(gen_seed)
    await tb.env.cycles(rng.randint(0, 6))
    need(all(m.idle for m in tb.masters), "agents not idle after reset flush")
    tb.fill_random(n, Gen(rng, dict(hot=0.5, edge=0.15, inside=0.15, unmapped=0.07, denied=0.05, misal=0.05, write=0.45)))
    await tb.drain(60000)


async def _wait_pulse(tb: XbarTB, n_pulses: int, budget: int, what: str) -> None:
    await tb.env.until(lambda: tb.rst.n_pulses >= n_pulses, budget, what)
    await tb.env.until(lambda: not tb.rst.asserted, 30, "reset release")


@cocotb.test()
async def reset_sync_states(dut):
    """Reset (1..4 cycles) asserted when each characteristic fabric state holds: transactions outstanding at
    master ports, write / read in flight at a slave, grant lock engaged, error response pending, response
    stalled, contended-and-stalled.  After each reset: nothing delivered, clean restart, data consistent."""
    tb = XbarTB(dut, "reset_sync_states", profile="mixed", slave_err="random:0.05")
    await tb.start()
    rng = tb.env.seeds.child("rst")
    cancelled_total = 0
    for rnd in range(len(TRIG_LIST) * 2):
        name, regime, weights, pred = TRIG_LIST[rnd % len(TRIG_LIST)]
        tb.set_regime(regime)
        w = dict(hot=0.3, edge=0.2, inside=0.2, unmapped=0.07, denied=0.05, misal=0.05)
        w.update(weights)
        tb.fill_random(40, Gen(tb.env.seeds.child("g%d" % rnd), w))
        tb.chk.reset_kind = "sync"
        before = len(tb.chk.sb.cancelled)
        tb.rst.arm(lambda: pred(tb), length=rng.randint(1, 4), reason=name)
        await _wait_pulse(tb, tb.rst.n_pulses + 1, 4000, "reset trigger '%s'" % name)
        cancelled_total += len(tb.chk.sb.cancelled) - before
        tb.set_regime("fast")
        await _post_reset(tb, "post%d" % rnd)
    need(cancelled_total > 0, "no transaction was ever in flight when reset hit")
    need(tb.chk.n_resets == len(TRIG_LIST) * 2, "reset count")
    await tb.finish("reset_sync_states", cancelled=cancelled_total)


@cocotb.test()
async def reset_idle_pointer(dut):
    """Reset with the fabric IDLE but the round-robin pointers / lock history non-trivial: the arbiters must come
    back in their reset state (pointer 0, no lock), observable by the very first contended arbitration."""
    tb = XbarTB(dut, "reset_idle_pointer", profile="dense", uniform=True)
    await tb.start()
    rng = tb.env.seeds.child("rst")
    for rnd in range(6):
        tb.fill_random(30, Gen(tb.env.seeds.child("g%d" % rnd), dict(hot=0.8, edge=0.0, inside=0.2, unmapped=0.0, denied=0.0, misal=0.0)))
        await tb.drain(20000)
        tb.chk.reset_kind = "sync"
        tb.rst.pulse(length=rng.randint(1, 3), delay=1, reason="idle")
        await _wait_pulse(tb, tb.rst.n_pulses + 1, 50, "idle reset")
        # all masters contend at once for the same slave right after reset: the arbitration order from a clean pointer
        tb.fill_random(12, Gen(tb.env.seeds.child("h%d" % rnd), dict(hot=1.0, edge=0.0, inside=0.0, unmapped=0.0, denied=0.0, misal=0.0)))
        await tb.drain(20000)
    await tb.finish("reset_idle_pointer")


@cocotb.test()
async def reset_async_midcycle(dut):
    """Asynchronous reset asserted in the middle of a clock period (random phase 1..9 ns), 1..3 cycles long, while
    the fabric is in each characteristic state."""
    tb = XbarTB(dut, "reset_async_midcycle", profile="mixed", slave_err="random:0.05")
    await tb.start()
    rng = tb.env.seeds.child("rst")
    cancelled_total = 0
    for rnd in range(len(TRIG_LIST) * 2):
        name, regime, weights, pred = TRIG_LIST[rnd % len(TRIG_LIST)]
        tb.set_regime(regime)
        w = dict(hot=0.3, edge=0.2, inside=0.2, unmapped=0.07, denied=0.05, misal=0.05)
        w.update(weights)
        tb.fill_random(40, Gen(tb.env.seeds.child("g%d" % rnd), w))
        tb.chk.reset_kind = "async"
        before = len(tb.chk.sb.cancelled)
        target = tb.rst.n_pulses + 1
        started = False
        for _ in range(4000):
            await tb.env.tick()
            if not started and pred(tb):
                cocotb.start_soon(tb.rst.async_pulse(phase_ns=rng.randint(2, 18) / 2.0, length_cycles=rng.randint(1, 3), reason="async:" + name))
                started = True
            if tb.rst.n_pulses >= target:
                break
        need(tb.rst.n_pulses >= target, "async reset trigger '%s' never fired" % name)
        await tb.env.until(lambda: not tb.rst.asserted, 30, "reset release")
        cancelled_total += len(tb.chk.sb.cancelled) - before
        tb.set_regime("fast")
        await _post_reset(tb, "post%d" % rnd)
    need(cancelled_total > 0, "no transaction was in flight when the async reset hit")
    await tb.finish("reset_async_midcycle", cancelled=cancelled_total)


async def _glitch(tb: XbarTB, t_assert_ns: float, t_release_ns: float) -> None:
    """Reset pulse entirely BETWEEN two rising edges (assert at +t_assert, release at +t_release, both < period):
    no clock edge ever sees reset low.  Peers in the shared reset domain (masters, slaves) lose their outputs at
    the same instant, which is modelled by driving their reset-state values."""
    env, rst = tb.env, tb.rst
    await RisingEdge(getattr(env.dut, env.clk_name))
    await Timer(int(round(t_assert_ns * 1000)), units="ps")
    sh = rst.rst.sh
    sh.h.value = rst.active
    sh.pend, sh.dirty = rst.active, False
    rst.asserted = True
    rst.n_pulses += 1
    rst.log.append((env.cycle, 0, "glitch"))
    env.digest.event("reset-glitch", env.cycle)
    env.notify_reset(True)
    for a in list(tb.masters) + list(tb.slaves):
        a.drive()  # in reset: valid/ready/rsp_valid back to their reset values
    for s in env.shadows.values():
        s.flush()
    await Timer(int(round((t_release_ns - t_assert_ns) * 1000)), units="ps")
    sh.h.value = rst.inactive
    sh.pend, sh.dirty = rst.inactive, False
    rst.asserted = False
    env.notify_reset(False)


@cocotb.test()
async def reset_glitch(dut):
    """Sub-cycle reset pulses (asynchronous assert is the only way the fabric can notice them): outstanding /
    in-flight / lock / error state must be cleared although no clock edge sees reset low."""
    tb = XbarTB(dut, "reset_glitch", profile="mixed", slave_err="random:0.05")
    await tb.start()
    rng = tb.env.seeds.child("rst")
    cancelled_total = 0
    for rnd in range(len(TRIG_LIST) * 2):
        name, regime, weights, pred = TRIG_LIST[rnd % len(TRIG_LIST)]
        tb.set_regime(regime)
        w = dict(hot=0.3, edge=0.2, inside=0.2, unmapped=0.07, denied=0.05, misal=0.05)
        w.update(weights)
        tb.fill_random(40, Gen(tb.env.seeds.child("g%d" % rnd), w))
        tb.chk.reset_kind = "glitch"
        before = len(tb.chk.sb.cancelled)
        target = tb.rst.n_pulses + 1
        started = False
        for _ in range(4000):
            await tb.env.tick()
            if not started and pred(tb):
                t1 = rng.randint(2, 8) / 2.0
                cocotb.start_soon(_glitch(tb, t1, t1 + rng.randint(2, 9) / 2.0))
                started = True
            if tb.rst.n_pulses >= target:
                break
        need(tb.rst.n_pulses >= target, "glitch trigger '%s' never fired" % name)
        await tb.env.cycles(2)
        need(not tb.rst.asserted, "glitch left reset asserted")
        cancelled_total += len(tb.chk.sb.cancelled) - before
        tb.set_regime("fast")
        await _post_reset(tb, "post%d" % rnd)
    need(cancelled_total > 0, "no transaction was in flight when the glitch hit")
    await tb.finish("reset_glitch", cancelled=cancelled_total)


@cocotb.test()
async def reset_burst(dut):
    """Back-to-back short resets while traffic runs (reset again 1..12 cycles after release, 1-2 cycles long) and
    traffic submitted right at the release edge."""
    tb = XbarTB(dut, "reset_burst", profile="mixed", slave_err="random:0.05")
    await tb.start()
    rng = tb.env.seeds.child("rst")
    for rnd in range(14):
        tb.fill_random(25, Gen(tb.env.seeds.child("g%d" % rnd), dict(hot=0.4, edge=0.2, inside=0.2, unmapped=0.08, denied=0.04, misal=0.05)))
        tb.chk.reset_kind = "sync"
        tb.rst.pulse(length=rng.randint(1, 2), delay=rng.randint(1, 40), reason="burst")
        await _wait_pulse(tb, tb.rst.n_pulses + 1, 400, "burst reset")
        tb.fill_random(10, Gen(tb.env.seeds.child("r%d" % rnd), dict(hot=0.5, edge=0.2, inside=0.2, unmapped=0.05, denied=0.0, misal=0.05)))  # at the release edge
        tb.rst.pulse(length=rng.randint(1, 2), delay=rng.randint(1, 12), reason="burst2")
        await _wait_pulse(tb, tb.rst.n_pulses + 1, 400, "second burst reset")
        await _post_reset(tb, "post%d" % rnd, 16)
    await tb.finish("reset_burst")


@cocotb.test()
async def reset_input_activity(dut):
    """R11 robustness: while reset is asserted EVERY input carries random junk (master requests incl. decode-error
    addresses, rsp_ready, slave ready / responses).  Nothing may be latched: after release the fabric is idle and clean
    (lockstep from the first cycle), no response appears for anything presented during reset.  Records how often the
    fabric's req_ready / s_req_valid were seen high while reset was low (the crossbar does not gate them by reset; see
    tests/fabric/cocotb_xbar_known.py, DF-F1)."""
    tb = XbarTB(dut, "reset_input_activity", profile="dense", uniform=True)
    await tb.start()
    rng = tb.env.seeds.child("junk")
    env = tb.env
    tb.chk.junk_in_reset = True
    names = ["m_req_valid", "m_req_write", "m_req_addr", "m_req_wdata", "m_req_wstrb", "m_rsp_ready", "s_req_ready", "s_rsp_valid", "s_rsp_rdata", "s_rsp_error"]
    handles = [(getattr(dut, n), len(getattr(dut, n))) for n in names]
    for rnd in range(10):
        tb.fill_random(15, Gen(tb.env.seeds.child("g%d" % rnd), dict(hot=0.4, edge=0.2, inside=0.2, unmapped=0.15, denied=0.0, misal=0.05)))
        await env.cycles(rng.randint(4, 30))
        target = tb.rst.n_pulses + 1
        tb.chk.reset_kind = "sync"
        tb.rst.pulse(length=rng.randint(3, 7), delay=1, reason="junk")
        await env.until(lambda: tb.rst.n_pulses >= target, 10, "reset start")
        while tb.rst.asserted:
            for h, w in handles:  # junk for the interval before the next edge (reset is still low then)
                h.value = rng.getrandbits(w)
            await env.tick()
        # reset released at the last step; agents are idle -> a few idle cycles, then ordinary traffic
        await env.cycles(rng.randint(2, 8))
        need(all(m.idle for m in tb.masters), "masters not idle after reset")
        tb.fill_random(12, Gen(tb.env.seeds.child("h%d" % rnd), dict(hot=0.5, edge=0.2, inside=0.2, unmapped=0.05, denied=0.0, misal=0.05)))
        await tb.drain(20000)
    need(tb.chk.junk_obs["cycles"] > 20, "too few reset cycles observed")
    await tb.finish("reset_input_activity", observed_in_reset=tb.chk.junk_obs)
