"""Long constrained-random crossbar run (tag ``long``): about 15 000 transactions (NM = 4) with the back-pressure
regime changed every few hundred cycles, slave errors, hot addresses, withdrawals, and periodic resets."""
import cocotb

from .xbar_tb import NM, Gen, XbarTB

REGIME_CYCLE = ("fast", "stall_slave", "stall_rsp", "slow_slave")


@cocotb.test()
async def random_long(dut):
    tb = XbarTB(dut, "random_long", profile="mixed", slave_err="random:0.03+window:0x20", withdraw=0.02)
    await tb.start()
    rng = tb.env.seeds.child("long")
    total = 0
    for rnd in range(24):
        tb.set_regime(REGIME_CYCLE[rnd % len(REGIME_CYCLE)])
        w = dict(hot=rng.choice([0.1, 0.4, 0.8]), edge=0.2, inside=0.2, unmapped=0.06, denied=0.04, misal=0.05, write=rng.choice([0.3, 0.5, 0.7]))
        n = 140 + rng.randint(0, 40)
        tb.fill_random(n, Gen(tb.env.seeds.child("g%d" % rnd), w))
        total += n * NM
        if rnd % 6 == 5:  # a reset in the middle of a batch every sixth round
            await tb.env.cycles(rng.randint(10, 60))
            tb.chk.reset_kind = "sync"
            tb.rst.pulse(length=rng.randint(1, 3), delay=1, reason="long-run")
            await tb.env.until(lambda: tb.rst.n_pulses >= rnd // 6 + 1 and not tb.rst.asserted, 100, "reset")
        await tb.drain(300000)
    await tb.finish("random_long", total_requests=total)
