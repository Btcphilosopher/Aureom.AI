"""Agent-level tests on fake signals: handshake semantics, data path, reset cancellation, determinism,
and -- most importantly -- that the protocol monitor FIRES on illegal behaviour."""
import pytest

from albionverify.bus.regbus import RegBusMaster
from albionverify.bus.reqrsp import Req, ReqRspMaster, ReqRspMonitor, ReqRspSlave, sfb_port
from albionverify.core import Agent, AlbionCheckError
from albionverify.memory import BackingStore
from albionverify.reset import ResetSequencer
from tests.unit.fakes import make_env

pytestmark = pytest.mark.model


def wired(seed=1, req="always", rsp="always", slv="always", slv_rsp="always", latency="fixed:1", policy=None, max_out=1, monitor=True, limit=None, mem=None, fail_fast=True):
    env = make_env(seed, fail_fast=fail_fast)
    rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=2))
    m = env.add(ReqRspMaster("m", sfb_port(env), rng=env.seeds.child("m"), req_throttle=req, rsp_throttle=rsp, max_outstanding=max_out))
    mem = mem if mem is not None else BackingStore("zero")
    s = env.add(ReqRspSlave("s", sfb_port(env), memory=mem, rng=env.seeds.child("s"), req_throttle=slv, rsp_throttle=slv_rsp, latency=latency, error_policy=policy))
    mon = env.add(ReqRspMonitor("mon", sfb_port(env), outstanding_limit=limit)) if monitor else None
    env.prime()
    return env, rst, m, s, mon, mem


def run(env, n):
    for _ in range(n):
        env.step()


def test_roundtrip_data_and_ordering_under_random_stalls():
    env, rst, m, s, mon, mem = wired(seed=3, req="random:0.5", rsp="random:0.5", slv="random:0.5", slv_rsp="random:0.5", latency="uniform:1-4", max_out=3)
    ref = {}
    for i in range(40):
        addr = 0x100 + 4 * (i % 8)
        data = (0x1000193 * (i + 1)) & 0xFFFFFFFF
        m.write(addr, data)
        ref[addr] = data
    reads = [m.read(0x100 + 4 * k) for k in range(8)]
    run(env, 2000)
    assert m.idle and not mon.outstanding
    for k, t in enumerate(reads):
        assert t.rsp.rdata == ref[0x100 + 4 * k] and not t.rsp.err
    assert all(t.t_rsp > t.t_accept for t in m.done)  # R5: response strictly after acceptance
    assert mon.n_checks > 0 and len(mon.txns) == 48


def test_byte_strobes_and_error_response_has_no_side_effect():
    from albionverify.inject import AddrRangeErrors

    env, rst, m, s, mon, mem = wired(policy=AddrRangeErrors([(0x200, 0x300)]))
    m.write(0x40, 0xFFFFFFFF); m.write(0x40, 0x0000AB00, strb=0b0010)
    t_rd = m.read(0x40)
    m.write(0x204, 0x12345678)  # error range: must not modify memory
    t_err = m.read(0x204)
    run(env, 80)
    assert t_rd.rsp.rdata == 0xFFFFABFF  # lane 1 replaced, other lanes untouched
    assert t_err.rsp.err and t_err.rsp.rdata == 0
    assert mem.read_word(0x204, 4) == 0


def test_request_held_until_accepted_and_idle_garbage_driven():
    env, rst, m, s, mon, mem = wired(slv="never")
    t = m.write(0x10, 0xCAFE)
    run(env, 12)
    assert t.t_accept is None and m.cur is t and m.req_stall_run >= 8  # still presented, unchanged, never withdrawn
    assert mon.max_req_stall >= 8 and not env.errors


def test_determinism_same_seed_same_digest_different_seed_differs():
    def go(seed):
        env, rst, m, s, mon, mem = wired(seed=seed, req="random:0.6", slv="random:0.6", latency="uniform:1-3")
        for i in range(20):
            m.write(4 * i, i * 77); m.read(4 * i)
        run(env, 600)
        return env.digest.hexdigest()
    assert go(5) == go(5)
    assert go(5) != go(6)


def test_reset_cancels_outstanding_and_queue_with_reasons():
    env, rst, m, s, mon, mem = wired(slv="never", max_out=2)
    t1 = m.write(0x0, 1); t2 = m.write(0x4, 2); t3 = m.write(0x8, 3)
    run(env, 6)
    rst.pulse(2, delay=1)
    run(env, 6)
    reasons = {t.seq: t.cancelled for t in (t1, t2, t3)}
    assert all(r is not None for r in reasons.values()), reasons
    assert any(r == "reset-flushed" for r in reasons.values()) or any(r == "reset-not-accepted" for r in reasons.values())
    assert m.idle and not mon.outstanding


# ----------------------------------------------------------------------------- negative tests: the monitor must fire
class Rogue(Agent):
    """Drives the response/request side by hand to create illegal behaviour."""

    def __init__(self, env, script):
        super().__init__("rogue")
        self.script, self.sig = script, {k: env.sig(n) for k, n in dict(rv="rsp_valid", rr="rsp_ready", rd="rsp_rdata", er="rsp_error", v="req_valid", rdy="req_ready", wr="req_write", a="req_addr", wd="req_wdata", ws="req_wstrb").items()}

    def drive(self):
        for k, v in self.script(self.env.cycle).items():
            self.sig[k].write(v)


def rogue_env(script):
    env = make_env(1, fail_fast=True)
    env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=1))
    env.add(Rogue(env, script))
    env.add(ReqRspMonitor("mon", sfb_port(env), outstanding_limit=1))
    env.prime()
    return env


def test_monitor_flags_R2_request_withdrawn():
    # valid for 2 cycles without ready, then dropped
    env = rogue_env(lambda c: {"v": 1 if 3 <= c <= 4 else 0, "rdy": 0, "a": 0x10})
    with pytest.raises(AlbionCheckError, match="R2"):
        run(env, 10)


def test_monitor_flags_R2_payload_change_while_stalled():
    env = rogue_env(lambda c: {"v": 1 if c >= 3 else 0, "rdy": 0, "a": 0x10 + (4 * c)})
    with pytest.raises(AlbionCheckError, match="R2.*payload changed"):
        run(env, 10)


def test_monitor_flags_R4_response_withdrawn():
    # one accepted request, then a response that appears for one cycle with rsp_ready low and vanishes
    def script(c):
        return {"v": 1 if c == 3 else 0, "rdy": 1, "rv": 1 if c in (5, 6) else 0, "rr": 0, "rd": 0}
    env = rogue_env(script)
    with pytest.raises(AlbionCheckError, match="R4"):
        run(env, 12)


def test_monitor_flags_R5_response_without_request():
    env = rogue_env(lambda c: {"rv": 1 if c >= 4 else 0, "rr": 1, "rd": 0})
    with pytest.raises(AlbionCheckError, match="R5"):
        run(env, 8)


def test_monitor_flags_R5_response_in_acceptance_cycle():
    env = rogue_env(lambda c: {"v": 1 if c == 4 else 0, "rdy": 1, "rv": 1 if c == 4 else 0, "rr": 1, "rd": 0})
    with pytest.raises(AlbionCheckError, match="R5"):
        run(env, 8)


def test_monitor_flags_R8_error_with_nonzero_rdata():
    def script(c):
        return {"v": 1 if c == 3 else 0, "rdy": 1, "rv": 1 if c == 5 else 0, "rr": 1, "rd": 0xDEAD, "er": 1}
    env = rogue_env(script)
    with pytest.raises(AlbionCheckError, match="R8"):
        run(env, 10)


def test_monitor_flags_R6_outstanding_bound():
    env = rogue_env(lambda c: {"v": 1 if 3 <= c <= 5 else 0, "rdy": 1, "a": 4 * c, "rv": 0})
    with pytest.raises(AlbionCheckError, match="R6"):
        run(env, 10)


def test_legal_traffic_does_not_trip_monitor():
    env, rst, m, s, mon, mem = wired(seed=11, req="bursty:1-3", rsp="bursty:1-3", slv="bursty:1-3", slv_rsp="bursty:1-3", latency="choice:1,2,5", limit=None, max_out=2)
    for i in range(60):
        (m.write if i % 3 else m.read)(*( (4 * (i % 16), i) if i % 3 else (4 * (i % 16),)))
    run(env, 3000)
    assert m.idle and not env.errors


# ----------------------------------------------------------------------------- register bus
def test_regbus_master_against_python_regfile():
    env = make_env(2)
    rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=1))
    rb = env.add(RegBusMaster("rb", env, rng=env.seeds.child("rb"), gap="random:0.6"))
    env.prime()
    regs, pend = {}, [None]

    def dut():  # sync write at the edge ending the access, combinational read
        d = env.dut
        if pend[0] is not None:
            a, v = pend[0]; regs[a] = v; pend[0] = None
        sel, we, addr, wd = (int(getattr(d, n).value) for n in ("rb_sel", "rb_we", "rb_addr", "rb_wdata"))
        d.rb_rdata.value = regs.get(addr, 0xBAD0BAD0) if sel and not we else 0
        d.rb_err.value = 1 if (sel and addr >= 0x800) else 0
        if sel and we and addr < 0x800:
            pend[0] = (addr, wd)

    ops = [rb.write_op(0x10, 0x1234), rb.read_op(0x10), rb.write_op(0x900, 5), rb.read_op(0x20), rb.write_op(0x10, 0xFFFFFFFF), rb.read_op(0x10)]
    for _ in range(60):
        env.step(); dut()
    assert all(o.done for o in ops)
    assert ops[1].rdata == 0x1234 and not ops[1].err
    assert ops[2].err is True
    assert ops[3].rdata == 0xBAD0BAD0
    assert ops[5].rdata == 0xFFFFFFFF


# ----------------------------------------------------------------------------- reset sequencer
def test_reset_sequencer_initial_pulse_armed_and_notifications():
    env = make_env(1)
    seen = []

    class Watch(Agent):
        def on_reset(self, asserted):
            seen.append((self.env.cycle, asserted))

    rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=3))
    env.add(Watch("w"))
    env.prime()
    assert rst.asserted and env.dut.rst_n.value == 0
    run(env, 4)
    assert not rst.asserted and env.dut.rst_n.value == 1 and (3, False) in seen
    flag = {"go": False}
    rst.arm(lambda: flag["go"], length=2)
    run(env, 3); assert not rst.asserted
    flag["go"] = True
    run(env, 1); assert rst.asserted and rst.n_pulses == 1
    run(env, 3); assert not rst.asserted
    rst.random_pulse(env.seeds.child("r"), 2, 5, length=(1, 1))
    run(env, 8)
    assert rst.n_pulses == 2


# ----------------------------------------------------------------------------- posted writes (no response)
def test_posted_writes_complete_at_acceptance_and_do_not_disturb_read_pairing():
    env = make_env(4)
    env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=1))
    expects = lambda r: not r.write  # only reads are answered
    m = env.add(ReqRspMaster("m", sfb_port(env), rng=env.seeds.child("m"), req_throttle="random:0.7", max_outstanding=2, expects_response=expects))
    mem = BackingStore("zero")
    env.add(ReqRspSlave("s", sfb_port(env), memory=mem, rng=env.seeds.child("s"), posted_writes=True, latency="uniform:1-3"))
    mon = env.add(ReqRspMonitor("mon", sfb_port(env), expects_response=expects))
    env.prime()
    w = [m.write(0x40 + 4 * i, 0x100 + i) for i in range(6)]
    r = [m.read(0x40 + 4 * i) for i in range(6)]
    for _ in range(300):
        env.step()
    assert m.idle and not env.errors
    assert all(t.posted and t.rsp is None and t.done for t in w)
    assert [t.rsp.rdata for t in r] == [0x100 + i for i in range(6)]
    assert len(mon.txns) == 12 and not mon.outstanding
