"""Regression tests for bugs found by auditing the audit (see docs/AUDIT_METHOD_NOTES.md)."""
import pytest

from albionverify.audit import svscan
from albionverify.audit.corpus import classify_unit

pytestmark = pytest.mark.model


def test_file_scope_package_import_is_attributed_to_every_unit():
    src = "import cpu_pkg::*;\nmodule alu(input logic a);\nendmodule\nmodule b; import other_pkg::*; endmodule\n"
    m = {x.name: x for x in svscan.scan_text(src, "x.sv")}
    assert "cpu_pkg" in m["alu"].uses_packages and {"cpu_pkg", "other_pkg"} <= m["b"].uses_packages


def test_marker_regex_is_word_bounded_outstanding_is_not_a_standin():
    src = "// one transaction outstanding; requests are held until accepted\nmodule m(input logic a);\nendmodule\n"
    mi = svscan.scan_text(src, "rtl/m.sv")[0]
    assert "stand-in" not in mi.marker_comments and "standin" not in mi.marker_comments
    role, why = classify_unit(mi, "rtl/m.sv")
    assert role == "rtl" and not [w for w in why if w.startswith("S:")]


def test_real_standin_is_detected():
    src = "// Behavioural stand-in for the SRAM macro (simulation only)\nmodule m(input logic a);\nendmodule\n"
    mi = svscan.scan_text(src, "rtl/m.sv")[0]
    role, why = classify_unit(mi, "rtl/m.sv")
    assert any(w.startswith("S:comment") for w in why)


def test_parameter_override_hash_is_not_a_delay():
    src = "module t; sub #(.W(4)) u (); initial #5 $finish; endmodule\n"
    mi = svscan.scan_text(src, "x.sv")[0]
    assert mi.n_delay == 1


def test_instance_resolution_and_assertion_counts():
    src = "module top; leaf #(.A(1)) u0 (.x(1'b0)); assert property (@(posedge clk) a |-> b); endmodule\nmodule leaf(input logic x); endmodule\n"
    mods = svscan.scan_text(src, "x.sv")
    svscan.resolve_instances(mods, {"top", "leaf"})
    top = mods[0]
    assert top.instantiates == {"leaf"} and top.n_assert_prop == 1
