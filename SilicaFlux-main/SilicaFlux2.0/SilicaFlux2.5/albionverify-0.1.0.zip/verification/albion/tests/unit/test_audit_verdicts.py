"""The audit's verdict policy: only an explicit pass marker with no contradicting evidence is a PASS."""
import pytest

from albionverify.audit.exec_checks import judge_output

pytestmark = pytest.mark.model


def v(out, rc=0, finished=True, timed_out=False):
    return judge_output(rc, out, timed_out, finished)[0]


@pytest.mark.parametrize("out,rc,want", [
    ("TB PASS", 0, "PASS"),
    ("[TB] avg_latency=41.0 cycles over 7589 error-free transactions\nALL TESTS PASSED", 0, "PASS"),
    ("RESULT P12: no-op and error responses as specified\nPASS", 0, "PASS"),
    ("[7125000] D4 SRAM range error (offset beyond capacity) -> ST_SLVERR\nPASS", 0, "PASS"),
    ("FAIL  BEQ branch target x3=1  (expected 0x1)", 1, "FAIL"),
    ("BACKDOOR MISMATCH bank 1 row 4096", 1, "FAIL"),
    ("ERROR: cpu_core.sv:442: ASSERT: x0 != 0", 1, "FAIL"),
    ("TB_RESULT: FAIL (no +VEC)", 1, "NEEDS_FLOW"),                      # needs a plusarg: not a design failure
    ("Expecting: ap_no_underflow failure\nSELFTEST DONE", 0, "NO_VERDICT"),  # announced expected failure, no pass marker
    ("[ASSERT-FAIL] x\nTEST PASSED", 0, "NO_VERDICT"),                     # contradictory => never a pass
    ("vvp: event.cc:596: virtual void vvp_fun_anyedge_sa::recv_vec4: Assertion `0' failed.", 1, "TOOL_ERROR"),
    ("FATAL: tb_cpu.sv:151: need +hex=<file>", 1, "NEEDS_FLOW"),
    ("FATAL: tb.sv:182: missing vectors/syn_single.hex", 1, "NEEDS_FLOW"),
    ("ok   unaligned hash base -> FAIL (RANGE)\nALL TESTS PASSED", 0, "PASS"),
    ("ERROR: tb.sv:80: $urandom's seed must be an integer/time variable", 1, "TOOL_ERROR"),
    ("simulation ran but printed nothing decisive", 0, "NO_VERDICT"),
    ("PASS-like text but no $finish", 0, "NO_VERDICT"),
])
def test_verdicts(out, rc, want):
    fin = "no $finish" not in out
    assert v(out, rc, finished=fin) == want


def test_timeout_is_never_pass():
    assert v("PASS", 0, timed_out=True) == "TIMEOUT"
