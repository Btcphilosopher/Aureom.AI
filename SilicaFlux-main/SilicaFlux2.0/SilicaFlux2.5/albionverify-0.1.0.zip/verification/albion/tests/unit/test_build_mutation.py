import json
import pytest

from albionverify import rtl
from albionverify.mutate.engine import MutantResult, classify_kill, load_mutants, score
from albionverify.sim.build import DutSpec, MutantApplyError, Patch, apply_patches, build_key, param_literal, spec_sources
from albionverify.sim.runner import CaseResult, SimResult, extract_failure_messages

pytestmark = pytest.mark.model

XBAR = DutSpec("t_xbar", "sfb_crossbar", params=(("NM", 2), ("NS", 2)))
MUX = "datafabric/rtl/interconnect/sfb_req_mux.sv"


def test_pins_intact_and_manifest_closure_complete():
    assert rtl.verify_pins(strict=False) == []
    for top, d in rtl.manifest()["duts"].items():
        assert d["unresolved"] == [] or top == "silicaflux_control_core", (top, d["unresolved"])
        for f in d["files"]:
            assert (rtl.RTL_DIR / f).exists(), f


def test_param_literal_wide_values_are_sized_hex_not_decimal():
    assert param_literal(5) == 5 and param_literal(True) == 1
    assert param_literal(0x7FFFFFFF) == 0x7FFFFFFF
    assert param_literal(0x2000000010000000) == "62'h2000000010000000"
    assert param_literal(0x80000000) == "32'h80000000"
    with pytest.raises(ValueError):
        param_literal(-1)


def test_dutspec_json_roundtrip_and_key_sensitivity():
    s = DutSpec("x", "sfb_crossbar", params=(("NM", 3),), defines=(("A", "1"),), wrapper=None)
    assert DutSpec.from_json(s.to_json()) == s
    k1 = build_key(XBAR, (), False, False)
    assert k1 == build_key(XBAR, (), False, False)
    assert k1 != build_key(XBAR, (), True, False)  # coverage build differs
    assert k1 != build_key(DutSpec("t_xbar", "sfb_crossbar", params=(("NM", 3), ("NS", 2))), (), False, False)
    assert k1 != build_key(XBAR, (Patch(MUX, "s_write = 1'b0;", "s_write = 1'b1;"),), False, False)


def test_patch_application_is_exact(tmp_path):
    p = Patch(MUX, "s_write = 1'b0;", "s_write = 1'b1;")
    out = apply_patches(XBAR, [p], tmp_path)
    assert "s_write = 1'b1;" in out[MUX].read_text()
    assert "s_write = 1'b0;" in (rtl.RTL_DIR / MUX).read_text()  # the vendored file itself is untouched
    with pytest.raises(MutantApplyError, match="expected 1 occurrence"):
        apply_patches(XBAR, [Patch(MUX, "this text does not exist", "x")], tmp_path)
    with pytest.raises(MutantApplyError, match="expected 1 occurrence"):
        apply_patches(XBAR, [Patch(MUX, "grant[m]", "x")], tmp_path)  # occurs several times, count defaults to 1
    with pytest.raises(MutantApplyError, match="not part of DUT"):
        apply_patches(XBAR, [Patch("sramlib/rtl/mem/sram_sp.sv", "a", "b")], tmp_path)


def _res(status, msgs=(), **kw):
    return SimResult("t", "d", "m", None, 1, status, [CaseResult("c", "FAIL", m) for m in msgs], **kw)


def test_kill_classification():
    assert classify_kill(_res("TIMEOUT")) == "TIMEOUT"
    assert classify_kill(_res("CRASH")) == "CRASH"
    assert classify_kill(_res("FAIL", ["albionverify.core.LivenessError: liveness: x not reached"])) == "LIVENESS"
    assert classify_kill(_res("FAIL", ["albionverify.core.AlbionCheckError: read data mismatch"])) == "CHECK"


def test_mutation_score_excludes_invalid_and_equivalent():
    rs = [MutantResult("a", "k", "d", "KILLED", "CHECK"), MutantResult("b", "k", "d", "KILLED", "TIMEOUT"),
          MutantResult("c", "k", "d", "SURVIVED"), MutantResult("d", "k", "d", "BUILD_ERROR"), MutantResult("e", "k", "d", "EQUIVALENT_SURVIVED")]
    s = score(rs)
    assert s["n_killed"] == 2 and s["n_survived"] == 1 and s["n_invalid"] == 1 and s["n_equivalent_survived"] == 1
    assert s["mutation_score_percent"] == 66.7 and s["n_killed_by_check"] == 1 and s["n_killed_by_liveness_or_hang"] == 1


def test_framework_smoke_mutants_all_valid_yaml():
    ms = load_mutants(rtl.ROOT / "mutants" / "framework_smoke.yaml")
    assert len(ms) >= 6 and len({m.id for m in ms}) == len(ms)
    for m in ms:
        for p in m.patches:
            assert (rtl.RTL_DIR / p.file).read_text().count(p.find) == p.count, (m.id, p.file)


def test_extract_failure_message_from_cocotb_log():
    log = (
        "    65.00ns INFO     cocotb.regression                  random_traffic failed\n"
        "                                                        Traceback (most recent call last):\n"
        "                                                          File \"x.py\", line 1, in f\n"
        "                                                        albionverify.core.AlbionCheckError: [tb @cycle 7] bad data\n"
        "    65.00ns INFO     cocotb.regression                  running other (2/2)\n"
    )
    assert extract_failure_messages(log) == {"random_traffic": "albionverify.core.AlbionCheckError: [tb @cycle 7] bad data"}


def test_unobservable_survivors_count_against_the_score_not_as_equivalent(tmp_path):
    import yaml
    from albionverify.mutate.engine import load_mutants, write_reports
    y = {"mutants": [
        {"id": "E1", "desc": "d", "equivalent": "commutative", "patches": [{"file": MUX, "find": "s_write = 1'b0;", "replace": "s_write = 1'b0;"}]},
        {"id": "U1", "desc": "d", "equivalent": "UNOBSERVABLE UNDER LEGAL STIMULUS: cannot reach", "patches": [{"file": MUX, "find": "s_write = 1'b0;", "replace": "s_write = 1'b0;"}]},
    ]}
    f = tmp_path / "m.yaml"; f.write_text(yaml.safe_dump(y))
    ms = {m.id: m for m in load_mutants(f)}
    assert ms["E1"].equivalent and not ms["E1"].unobservable
    assert ms["U1"].unobservable and not ms["U1"].equivalent
    rs = [MutantResult("K", "k", "d", "KILLED", "CHECK"), MutantResult("E1", "k", "d", "EQUIVALENT_SURVIVED"), MutantResult("U1", "k", "d", "UNOBSERVABLE_SURVIVED", equivalent_reason="x")]
    sc = score(rs)
    assert sc["n_unobservable_survived"] == 1 and sc["n_equivalent_survived"] == 1 and sc["mutation_score_percent"] == 50.0
    rep = {"suite": "t", "baseline": ["a"], "baseline_ok": True, "mutants": [r.__dict__ for r in rs], **sc}
    write_reports(rep, tmp_path)
    md = (tmp_path / "t.md").read_text()
    assert "unobservable through the ports" in md and "U1" in md


def test_mutant_ids_are_resolved_by_dut_closure_and_suite_qualification():
    """SM-01 exists in two suites (framework_smoke: crossbar; sram_spm: scratchpad): the repro command must pick the right one."""
    from albionverify.mutate.engine import resolve_mutant
    from albionverify.suite import load_suites
    suites = load_suites()
    xbar = suites["framework_smoke"].cases[0].dut
    spm = suites["sram_spm"].cases[0].dut
    assert resolve_mutant("SM-01", xbar, suites)[0] == "framework_smoke"
    assert resolve_mutant("SM-01", spm, suites)[0] == "sram_spm"
    assert resolve_mutant("sram_spm:SM-01", spm, suites)[0] == "sram_spm"
    # an explicit suite qualification is honoured whatever the DUT; an unknown id is an error, never a silent guess
    assert resolve_mutant("sram_spm:SM-01", xbar, suites)[0] == "sram_spm"
    with pytest.raises(ValueError, match="unknown"):
        resolve_mutant("NOPE-1", xbar, suites)
