import pytest
from albionverify.memory import BackingStore
from albionverify.scoreboard import Scoreboard
from albionverify.coverage import CoverGroup, merge_dicts, summarize
from albionverify.core import AlbionCheckError
from tests.unit.fakes import make_env

pytestmark = pytest.mark.model


# ----------------------------------------------------------------------------- memory
def test_strobes_little_endian_lanes():
    m = BackingStore("zero")
    m.write_word(0x100, 0xAABBCCDD, 0b0101, 4)  # lanes 0 and 2 only
    assert m.read_word(0x100, 4) == 0x00BB00DD
    assert m.read_word(0x100, 1) == 0xDD and m.read_word(0x102, 1) == 0xBB
    m.write_word(0x100, 0x11223344, None, 4)
    assert m.read_word(0x100, 4) == 0x11223344


def test_check_word_lane_mask_and_mismatch_message():
    m = BackingStore("zero", "ref")
    m.write_word(0, 0xDEADBEEF, None, 4)
    assert m.check_word(0, 4, 0xDEADBEEF) is None
    msg = m.check_word(0, 4, 0xDEAD00EF)
    assert msg and "lane1" in msg and "exp=be" in msg and "got=00" in msg
    assert m.check_word(0, 4, 0x00AD00EF, lanes=0b0101) is None  # only lanes 0,2 compared


def test_unknown_init_pins_observed_value():
    m = BackingStore("unknown")
    assert m.check_word(0, 4, 0x12345678) is None  # any value legal on first read
    assert m.check_word(0, 4, 0x12345678) is None  # ... then pinned
    assert m.check_word(0, 4, 0x12345679) is not None
    m.write_word(0, 0xFFFFFFFF, None, 4)
    assert m.check_word(0, 4, 0xFFFFFFFF) is None


def test_uncertain_write_accepts_old_or_new_then_pins():
    m = BackingStore("zero")
    m.write_word(0, 0x11111111, None, 4)
    m.write_uncertain(0, 0x22222222, 0b0011, 4)  # reset cancelled a write to lanes 0,1
    assert m.check_word(0, 4, 0x11112222) is None  # new in lanes 0,1 (old in 2,3)
    # now pinned: lanes 0,1 are 0x22 -> reading the old value later is an error
    assert m.check_word(0, 4, 0x11111111) is not None
    m2 = BackingStore("zero"); m2.write_word(0, 0x11111111, None, 4); m2.write_uncertain(0, 0x22222222, 0b0001, 4)
    assert m2.check_word(0, 4, 0x11111111) is None  # old value also legal
    m3 = BackingStore("zero"); m3.write_word(0, 0x11111111, None, 4); m3.write_uncertain(0, 0x22222222, 0b0001, 4)
    assert m3.check_word(0, 4, 0x11111133) is not None  # a third value is never legal


def test_out_of_range():
    m = BackingStore("zero", size=64)
    assert m.in_range(60, 4) and not m.in_range(61, 4) and not m.in_range(64, 4)


# ----------------------------------------------------------------------------- scoreboard
def test_ledger_identity_and_cancel():
    env = make_env(fail_fast=False)
    sb = Scoreboard(env, "sb")
    for i in range(5):
        sb.accept("m0", i, ("exp", i))
    assert sb.complete("m0", 0) == ("exp", 0)
    assert sb.complete("m0", 1) == ("exp", 1)
    gone = sb.cancel("m0", "reset")
    assert len(gone) == 3 and sb.outstanding() == 0
    sb.finalize()
    assert not sb.errors
    assert sb.accepted == 5 and sb.completed == 2 and len(sb.cancelled) == 3


def test_scoreboard_detects_lost_request_order_violation_and_stale_completion():
    env = make_env(fail_fast=False)
    sb = Scoreboard(env, "sb")
    sb.accept("s", 1, "a"); sb.accept("s", 2, "b")
    sb.complete("s", 2)  # out of order on an ordered stream
    assert any("order violation" in e for e in sb.errors)
    sb.finalize()
    assert any("never completed" in e for e in sb.errors)
    sb2 = Scoreboard(make_env(fail_fast=False), "sb2")
    sb2.complete("s")  # nothing outstanding
    assert any("nothing outstanding" in e for e in sb2.errors)
    sb3 = Scoreboard(make_env(fail_fast=False), "sb3"); sb3.accept("s", 1, "x"); sb3.cancel("s")
    sb3.complete("s", 1)  # completion of a cancelled request must be an error
    assert sb3.errors


def test_check_eq_reports_hex_and_failfast():
    env = make_env(fail_fast=True)
    sb = Scoreboard(env, "sb")
    assert sb.check_eq("data", 0x10, 0x10)
    with pytest.raises(AlbionCheckError, match="expected 0x10, got 0x11"):
        sb.check_eq("data", 0x10, 0x11, ctx="addr 0x40")


# ----------------------------------------------------------------------------- coverage
def test_covergroup_bins_cross_illegal_and_merge():
    cg = CoverGroup("g")
    cg.point("op", ["rd", "wr"])
    cg.point("len", {"short": (1, 4), "long": (5, 64)})
    cg.cross("op_x_len", ["op", "len"])
    cg.sample(op="rd", len=2); cg.sample(op="wr", len=40); cg.sample(op="wr", len=3)
    d = cg.to_dict()
    assert d["points"]["op"]["bins"] == {"rd": 1, "wr": 2}
    assert d["crosses"]["op_x_len"]["bins"]["wr*short"] == 1 and d["crosses"]["op_x_len"]["bins"]["rd*long"] == 0
    assert round(cg.percent(), 1) == round(100 * 7 / 8, 1)  # 2+2 point bins + 4 cross bins, only rd*long missing
    assert cg.holes() == ["g.op_x_len.rd*long"]
    cg2 = CoverGroup("g"); cg2.point("op", ["rd", "wr"]); cg2.point("len", {"short": (1, 4), "long": (5, 64)}); cg2.cross("op_x_len", ["op", "len"])
    cg2.sample(op="rd", len=9)
    s = summarize(merge_dicts([{"g": cg.to_dict()}, {"g": cg2.to_dict()}]))
    assert s["groups"]["g"]["percent"] == 100.0 and s["groups"]["g"]["holes"] == []
    ill = CoverGroup("i"); ill.point("v", [0, 1, 2], illegal=2)
    with pytest.raises(AssertionError, match="illegal bin"):
        ill.sample(v=2)
