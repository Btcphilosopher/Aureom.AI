import pytest
from albionverify.rng import SeedRoot, Throttle, Latency
from albionverify.digest import TraceDigest

pytestmark = pytest.mark.model


def test_streams_deterministic_and_independent():
    a, b = SeedRoot(7), SeedRoot(7)
    assert [a.child("x").random() for _ in range(3)] == [b.child("x").random() for _ in range(3)]
    assert a.child("x").random() != a.child("y").random()
    assert SeedRoot(7).child("x").random() != SeedRoot(8).child("x").random()
    # adding another stream never perturbs an existing one
    r1 = SeedRoot(3); s = [r1.child("m0").getrandbits(32) for _ in range(5)]
    r2 = SeedRoot(3); r2.child("other").random(); assert s == [r2.child("m0").getrandbits(32) for _ in range(5)]


def test_stream_is_cached_child_is_fresh():
    r = SeedRoot(1)
    assert r.stream("a") is r.stream("a")
    assert r.child("a") is not r.child("a")
    assert r.child("a").random() == r.child("a").random()


def test_throttle_modes():
    r = SeedRoot(1).child("t")
    assert all(Throttle(r, "always").allow() for _ in range(10))
    assert not any(Throttle(r, "never").allow() for _ in range(10))
    t = Throttle(r, "stall:3")
    assert [t.allow() for _ in range(5)] == [False, False, False, True, True]
    assert t.max_denied_run == 3
    p = Throttle(r, "pattern:1100")
    assert [p.allow() for _ in range(8)] == [True, True, False, False] * 2
    b = Throttle(SeedRoot(5).child("b"), "bursty:2-4")
    seq = [b.allow() for _ in range(60)]
    assert True in seq and False in seq
    runs = max(b.max_denied_run, 1)
    assert 2 <= runs <= 4 or runs == 1
    q = Throttle(SeedRoot(2).child("q"), "random:0.5")
    n = sum(q.allow() for _ in range(2000))
    assert 800 < n < 1200
    with pytest.raises(ValueError):
        Throttle(r, "bogus")


def test_throttle_reproducible():
    a = Throttle(SeedRoot(9).child("x"), "random:0.3"); b = Throttle(SeedRoot(9).child("x"), "random:0.3")
    assert [a.allow() for _ in range(100)] == [b.allow() for _ in range(100)]


def test_latency_specs():
    r = SeedRoot(1).child("l")
    assert Latency(r, "fixed:4").next() == 4
    assert all(2 <= Latency(r, "uniform:2-5").next() <= 5 for _ in range(50))
    assert set(Latency(r, "choice:1,9").next() for _ in range(80)) == {1, 9}
    assert set(Latency(r, "tail:1,0.5,7").next() for _ in range(80)) == {1, 7}


def test_digest_order_and_value_sensitive():
    d1, d2, d3 = TraceDigest(), TraceDigest(), TraceDigest()
    for d in (d1, d2):
        d.event("a", 1, 2); d.event("b", 0xFF)
    d3.event("b", 0xFF); d3.event("a", 1, 2)
    assert d1.hexdigest() == d2.hexdigest() != d3.hexdigest()
    d4 = TraceDigest(); d4.event("a", 1, 3); d4.event("b", 0xFF)
    assert d4.hexdigest() != d1.hexdigest()
    assert d1.n_events == 2
