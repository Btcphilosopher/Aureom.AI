"""Fake DUT handles so framework agents can be unit-tested without a simulator."""
from albionverify.core import Env


class FakeHandle:
    def __init__(self, width=128):
        self.value = 0
        self._w = width

    def __len__(self):
        return self._w


class FakeDut:
    """Attributes are created on first access; reading an unwritten signal gives 0."""

    def __init__(self):
        object.__setattr__(self, "_h", {})

    def __getattr__(self, name):
        h = object.__getattribute__(self, "_h")
        if name not in h:
            h[name] = FakeHandle()
        return h[name]


def make_env(seed=1, **kw):
    return Env(FakeDut(), seed=seed, name="unit", **kw)
