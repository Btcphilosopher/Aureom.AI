import collections
import pytest

from albionverify.gen import ReqGen
from albionverify.rng import SeedRoot

pytestmark = pytest.mark.model

REG = [(0x1000, 0x2000), (0x8000, 0x8100)]
UNM = [(0xF000, 0xF100)]


def mk(seed=1, **kw):
    return ReqGen(SeedRoot(seed).child("g"), 4, REG, unmapped=UNM, **kw)


def test_deterministic_for_seed():
    a, b = mk(3).batch(200), mk(3).batch(200)
    assert [(r.write, r.addr, r.wdata, r.strb, r.tag["kind"]) for r in a] == [(r.write, r.addr, r.wdata, r.strb, r.tag["kind"]) for r in b]
    assert [r.addr for r in mk(4).batch(50)] != [r.addr for r in mk(3).batch(50)[:50]]


def test_address_kinds_match_their_intent():
    g = mk(7, addr_weights={"misaligned": 2, "unmapped": 2})
    seen = collections.Counter()
    for r in g.batch(3000):
        k = r.tag["kind"]
        seen[k] += 1
        in_reg = any(lo <= r.addr < hi for lo, hi in REG)
        if k == "misaligned":
            assert r.addr % 4 != 0 and in_reg
        elif k == "unmapped":
            assert r.addr % 4 == 0 and not in_reg and 0xF000 <= r.addr < 0xF100
        else:
            assert r.addr % 4 == 0 and in_reg, (k, hex(r.addr))
        if k == "boundary-lo":
            assert r.addr in (0x1000, 0x1004, 0x8000, 0x8004)
        if k == "boundary-hi":
            assert r.addr in (0x2000 - 4, 0x2000 - 8, 0x8100 - 4, 0x8100 - 8)
    assert set(seen) == {"boundary-lo", "boundary-hi", "region", "misaligned", "unmapped"}


def test_strobe_and_data_classes_cover_all_kinds_and_are_consistent():
    g = mk(11)
    sk, dk = collections.Counter(), collections.Counter()
    for r in g.batch(4000):
        if r.write:
            sk[r.tag["strobe"]] += 1; dk[r.tag["data"]] += 1
            s = r.strb
            assert {"full": s == 0xF, "zero": s == 0, "single": bin(s).count("1") == 1, "sparse": 0 < s < 0xF and bin(s).count("1") > 1 or (0 < s < 0xF)}[r.tag["strobe"]]
        else:
            assert r.strb is None and r.tag["strobe"] == "n/a"
    assert set(sk) == {"full", "single", "sparse", "zero"} and set(dk) == {"random", "zeros", "ones", "walking", "addr"}


def test_unmapped_disabled_without_ranges_and_single_byte_words():
    g = ReqGen(SeedRoot(1).child("x"), 1, [(0, 64)])
    kinds = {r.tag["kind"] for r in g.batch(500)}
    assert "unmapped" not in kinds and "misaligned" not in kinds
