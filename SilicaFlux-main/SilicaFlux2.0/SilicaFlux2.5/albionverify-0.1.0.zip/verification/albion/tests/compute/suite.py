"""Suites of subsystem D: vector and tensor engines (vec_lane, vec_array, ten_array)."""
from albionverify.sim.build import DutSpec
from albionverify.suite import Case, Suite

# ------------------------------------------------------------------------------------------------ vector lane
def _lane(name, rob, fadd, fmul, fma, misc, imul, fcmp=1, intg=1, tagw=8):
    return DutSpec(name, "hpc_vector_lane", params=(("DATA_W", 32), ("TAG_W", tagw), ("ROB_DEPTH", rob), ("LAT_FADD", fadd), ("LAT_FMUL", fmul),
                                                  ("LAT_FMA", fma), ("LAT_MISC", misc), ("LAT_IMUL", imul), ("EN_FCMP", fcmp), ("EN_INT", intg)))


LANE_DEF = _lane("vec_lane_def", 8, 3, 3, 4, 1, 2)  # documented defaults
LANE_MIN = _lane("vec_lane_min", 3, 2, 2, 3, 1, 1)  # minimum latencies, ROB shallower than LAT + 2 (ROB-full stalls)
LANE_LEAN = _lane("vec_lane_lean", 10, 4, 5, 6, 2, 3, fcmp=0, intg=0)  # compare / integer ops removed, long latencies
LANE_TINY = _lane("vec_lane_tiny", 1, 2, 2, 3, 1, 1, tagw=1)  # degenerate parameters: ROB_DEPTH = 1, TAG_W = 1

# ------------------------------------------------------------------------------------------------ vector array
def _arr(name, n, vl_w, cmd, trk, cpl, red, redlat, perf, perfcw, rob, fadd, fmul, fma, misc, imul, fcmp=1, intg=1):
    return DutSpec(name, "hpc_vector_array", params=(("NUM_LANES", n), ("VL_W", vl_w), ("TID_W", 8), ("CMD_DEPTH", cmd), ("TRK_DEPTH", trk), ("CPL_DEPTH", cpl),
                                                    ("RED_EN", red), ("RED_LAT", redlat), ("PERF_EN", perf), ("PERF_CW", perfcw), ("LANE_ROB_DEPTH", rob),
                                                    ("LAT_FADD", fadd), ("LAT_FMUL", fmul), ("LAT_FMA", fma), ("LAT_MISC", misc), ("LAT_IMUL", imul),
                                                    ("EN_FCMP", fcmp), ("EN_INT", intg)))


ARR_N2 = _arr("vec_arr_n2", 2, 8, 4, 8, 4, 1, 3, 1, 8, 8, 3, 3, 4, 1, 2)  # documented defaults, narrow (saturating) counters
ARR_N4 = _arr("vec_arr_n4", 4, 8, 2, 5, 2, 1, 2, 1, 32, 4, 2, 2, 3, 1, 1)  # minimum latencies, shallow queues / ROB
ARR_LEAN = _arr("vec_arr_lean", 2, 6, 1, 2, 1, 0, 2, 0, 32, 4, 2, 2, 3, 1, 1, fcmp=0, intg=0)  # no reduction / counters / compare / int, depth-1 queues
ARR_N1 = _arr("vec_arr_n1", 1, 6, 3, 8, 4, 1, 3, 1, 32, 8, 3, 3, 4, 1, 2)  # one lane: strict sequential reduction
ARR_TINY = _arr("vec_arr_tiny", 2, 3, 1, 1, 1, 1, 2, 1, 2, 1, 2, 2, 3, 1, 1)  # degenerate parameters: every queue / ROB depth 1, VL_W = 3, 2-bit counters
ARR_N8 = _arr("vec_arr_n8", 8, 6, 2, 8, 3, 1, 3, 1, 16, 8, 3, 3, 4, 1, 2)  # eight lanes: three reduction-tree levels
ARR_DEEP = _arr("vec_arr_deep", 4, 12, 4, 12, 4, 1, 5, 1, 32, 16, 6, 5, 8, 2, 4)  # long latencies (FADD 6, FMUL 5, FMA 8, IMUL 4), RED_LAT 5, VL_W 12
ARR_N16 = _arr("vec_arr_n16", 16, 6, 2, 8, 3, 1, 2, 1, 16, 8, 3, 3, 4, 1, 2, fcmp=0)  # sixteen lanes: four reduction-tree levels (FCMP removed to keep the build small)

# ------------------------------------------------------------------------------------------------ tensor array
def _ten(name, rows, cols, acc, kw, mp, chk=1, perf=1, dw=8):
    return DutSpec(name, "tensor_systolic_array", params=(("ARRAY_ROWS", rows), ("ARRAY_COLS", cols), ("DATA_WIDTH", dw), ("ACC_WIDTH", acc), ("K_WIDTH", kw),
                                                         ("MUL_PIPE", mp), ("CHECK_ALIGN", chk), ("PERF_EN", perf)))


TEN_2X2 = _ten("ten_2x2_acc16", 2, 2, 16, 8, 0)  # 16-bit accumulator wraps after 2 extreme products, K <= 255
TEN_3X2 = _ten("ten_3x2_mp1_acc24", 3, 2, 24, 10, 1)  # product register, 24-bit accumulator, K <= 1023, non-square
TEN_4X4 = _ten("ten_4x4", 4, 4, 32, 17, 0)  # documented baseline
TEN_1X3 = _ten("ten_1x3_lean", 1, 3, 32, 5, 0, chk=0, perf=0)  # single row, no alignment checker, no counters, K <= 31

MODLANE = "compute.cocotb_vec_lane"
MODARR = "compute.cocotb_vec_array"
MODTEN = "compute.cocotb_ten_array"
# fast mutation subsets (< ~90 s per surviving mutant; quick checks first, the 20 s corner sweep last)
_LANE_MUT = [
    Case(LANE_DEF, MODLANE, "latency_per_op", (1,)),
    Case(LANE_DEF, MODLANE, "reset_mid_pipeline", (1,)),
    Case(LANE_DEF, MODLANE, "lane_enable", (1,)),
    Case(LANE_DEF, MODLANE, "illegal_ops", (1,)),
    Case(LANE_DEF, MODLANE, "backpressure_hold", (1,)),
    Case(LANE_DEF, MODLANE, "throughput_and_ordering", (1,)),
    Case(LANE_DEF, MODLANE, "random_ops", (1,)),
    Case(LANE_DEF, MODLANE, "directed_arith", (1,), timeout=900),
]
_TEN_MUT = [
    Case(TEN_2X2, MODTEN, "directed_tiles", (1,)),
    Case(TEN_2X2, MODTEN, "cfg_handshake", (1,)),
    Case(TEN_2X2, MODTEN, "reset_mid_tile", (1,)),
    Case(TEN_2X2, MODTEN, "stalls_and_backpressure", (1,)),
    Case(TEN_2X2, MODTEN, "extreme_values", (1,)),
    Case(TEN_2X2, MODTEN, "random_tiles", (1,)),
    Case(TEN_3X2, MODTEN, "directed_tiles", (1,)),
    Case(TEN_3X2, MODTEN, "stalls_and_backpressure", (1,)),
    Case(TEN_3X2, MODTEN, "extreme_values", (1,)),
    Case(TEN_3X2, MODTEN, "random_tiles", (1,)),
]
_ARR_MUT = [
    Case(ARR_N2, MODARR, "latency_and_throughput", (1,)),
    Case(ARR_N2, MODARR, "queue_depth", (1,)),
    Case(ARR_N2, MODARR, "directed_elementwise", (1,)),
    Case(ARR_N2, MODARR, "mask_vl_broadcast", (1,)),
    Case(ARR_N2, MODARR, "illegal_commands", (1,)),
    Case(ARR_N2, MODARR, "reductions", (1,)),
    Case(ARR_N2, MODARR, "stalls_and_holds", (1,)),
    Case(ARR_N2, MODARR, "config_change_b2b", (1,)),
    Case(ARR_N2, MODARR, "reset_mid_command", (1,)),
    Case(ARR_N2, MODARR, "random_mixed", (1,)),
    Case(ARR_N2, MODARR, "long_vector", (1,)),
    Case(ARR_N4, MODARR, "reductions", (1,)),
    Case(ARR_N4, MODARR, "stalls_and_holds", (1,)),
    Case(ARR_N4, MODARR, "random_mixed", (1,)),
]

SUITES = {
    "ten_array": Suite(
        name="ten_array",
        subsystem="compute",
        title="tensor_systolic_array: INT8 matmul tiles (output-stationary), skew / drain timing, partial tiles, stalls, cfg handshake, reset",
        cases=[
            Case(TEN_2X2, MODTEN, "directed_tiles", (1,), tags=("directed",)),
            Case(TEN_3X2, MODTEN, "directed_tiles", (1,), tags=("directed",)),
            Case(TEN_4X4, MODTEN, "directed_tiles", (1,), tags=("directed",)),
            Case(TEN_1X3, MODTEN, "directed_tiles", (1,), tags=("directed",)),
            Case(TEN_2X2, MODTEN, "extreme_values", (1,), tags=("directed",)),
            Case(TEN_3X2, MODTEN, "extreme_values", (1,), tags=("directed", "long")),
            Case(TEN_4X4, MODTEN, "extreme_values", (1,), tags=("directed",)),
            Case(TEN_1X3, MODTEN, "extreme_values", (1,), tags=("directed",)),
            Case(TEN_2X2, MODTEN, "cfg_handshake", (1,), tags=("directed", "error")),
            Case(TEN_3X2, MODTEN, "cfg_handshake", (1,), tags=("directed", "error")),
            Case(TEN_4X4, MODTEN, "cfg_handshake", (1,), tags=("directed", "error")),
            Case(TEN_1X3, MODTEN, "cfg_handshake", (1,), tags=("directed", "error")),
            Case(TEN_2X2, MODTEN, "stalls_and_backpressure", (1, 2), tags=("directed",)),
            Case(TEN_3X2, MODTEN, "stalls_and_backpressure", (1, 2), tags=("directed",)),
            Case(TEN_4X4, MODTEN, "stalls_and_backpressure", (1,), tags=("directed",)),
            Case(TEN_2X2, MODTEN, "random_tiles", (1, 2, 3), tags=("random",)),
            Case(TEN_3X2, MODTEN, "random_tiles", (1, 2, 3), tags=("random",)),
            Case(TEN_4X4, MODTEN, "random_tiles", (1, 2), tags=("random",)),
            Case(TEN_1X3, MODTEN, "random_tiles", (1,), tags=("random",)),
            Case(TEN_2X2, MODTEN, "random_long", (1,), timeout=900, tags=("random", "long")),
            Case(TEN_4X4, MODTEN, "random_long", (1,), timeout=900, tags=("random", "long")),
            Case(TEN_3X2, MODTEN, "random_long", (1,), timeout=900, tags=("random", "long")),
            Case(TEN_1X3, MODTEN, "random_long", (1,), timeout=900, tags=("random", "long")),
            Case(TEN_2X2, MODTEN, "reset_mid_tile", (1, 2, 3), tags=("reset",)),
            Case(TEN_3X2, MODTEN, "reset_mid_tile", (1, 2), tags=("reset",)),
            Case(TEN_4X4, MODTEN, "reset_mid_tile", (1,), tags=("reset",)),
            Case(TEN_1X3, MODTEN, "reset_mid_tile", (1,), tags=("reset",)),
        ],
        mutation_cases=_TEN_MUT,
        mutants_file="mutants/ten_array.yaml",
        spec_refs=("tensorcore02/README.md", "tensorcore02/docs/ARCHITECTURE.md", "tensorcore02/docs/CONFIGURATION.md", "tensorcore02/docs/PERFORMANCE.md"),
        notes="Brief says weight-stationary, documentation says output-stationary (PE(i,j) owns C[i][j]); the model follows the documentation.",
    ),
    "vec_array": Suite(
        name="vec_array",
        subsystem="compute",
        title="hpc_vector_array: issue/collect/reduction around N lanes (framing, masks, broadcast, reduction order, legality, stalls, reset)",
        cases=[
            Case(ARR_N2, MODARR, "directed_elementwise", (1,), tags=("directed",)),
            Case(ARR_N4, MODARR, "directed_elementwise", (1,), tags=("directed",)),
            Case(ARR_LEAN, MODARR, "directed_elementwise", (1,), tags=("directed", "error")),
            Case(ARR_N2, MODARR, "mask_vl_broadcast", (1,), tags=("directed",)),
            Case(ARR_N4, MODARR, "mask_vl_broadcast", (1,), tags=("directed",)),
            Case(ARR_N2, MODARR, "reductions", (1,), tags=("directed",)),
            Case(ARR_N4, MODARR, "reductions", (1,), tags=("directed",)),
            Case(ARR_N1, MODARR, "reductions", (1,), tags=("directed",)),
            Case(ARR_LEAN, MODARR, "reductions", (1,), tags=("directed", "error")),
            Case(ARR_N2, MODARR, "illegal_commands", (1, 2), tags=("error",)),
            Case(ARR_N4, MODARR, "illegal_commands", (1,), tags=("error",)),
            Case(ARR_LEAN, MODARR, "illegal_commands", (1, 2), tags=("error",)),
            Case(ARR_N2, MODARR, "config_change_b2b", (1,), tags=("directed",)),
            Case(ARR_N4, MODARR, "config_change_b2b", (1,), tags=("directed",)),
            Case(ARR_N2, MODARR, "latency_and_throughput", (1,), tags=("directed",)),
            Case(ARR_N4, MODARR, "latency_and_throughput", (1,), tags=("directed",)),
            Case(ARR_N1, MODARR, "latency_and_throughput", (1,), tags=("directed",)),
            Case(ARR_N2, MODARR, "queue_depth", (1,), tags=("directed",)),
            Case(ARR_N4, MODARR, "queue_depth", (1,), tags=("directed",)),
            Case(ARR_LEAN, MODARR, "queue_depth", (1,), tags=("directed",)),
            Case(ARR_N2, MODARR, "stalls_and_holds", (1, 2), tags=("directed",)),
            Case(ARR_N4, MODARR, "stalls_and_holds", (1, 2), tags=("directed",)),
            Case(ARR_N2, MODARR, "long_vector", (1,), tags=("long",)),
            Case(ARR_N4, MODARR, "long_vector", (1,), tags=("long",)),
            Case(ARR_N2, MODARR, "random_mixed", (1, 2, 3), tags=("random",)),
            Case(ARR_N4, MODARR, "random_mixed", (1, 2, 3), tags=("random",)),
            Case(ARR_N1, MODARR, "random_mixed", (1,), tags=("random",)),
            Case(ARR_LEAN, MODARR, "random_mixed", (1, 2), tags=("random",)),
            Case(ARR_N2, MODARR, "random_long", (1,), timeout=900, tags=("random", "long")),
            Case(ARR_N4, MODARR, "random_long", (1,), timeout=900, tags=("random", "long")),
            Case(ARR_N2, MODARR, "reset_mid_command", (1, 2, 3), tags=("reset",)),
            Case(ARR_TINY, MODARR, "directed_elementwise", (1,), tags=("directed",)),
            Case(ARR_TINY, MODARR, "mask_vl_broadcast", (1,), tags=("directed",)),
            Case(ARR_TINY, MODARR, "reductions", (1,), tags=("directed",)),
            Case(ARR_TINY, MODARR, "illegal_commands", (1,), tags=("error",)),
            Case(ARR_TINY, MODARR, "latency_and_throughput", (1,), tags=("directed",)),
            Case(ARR_TINY, MODARR, "queue_depth", (1,), tags=("directed",)),
            Case(ARR_TINY, MODARR, "stalls_and_holds", (1, 2), tags=("directed",)),
            Case(ARR_TINY, MODARR, "random_mixed", (1, 2), tags=("random",)),
            Case(ARR_TINY, MODARR, "reset_mid_command", (1, 2), tags=("reset",)),
            Case(ARR_N8, MODARR, "directed_elementwise", (1,), tags=("directed",)),
            Case(ARR_N8, MODARR, "reductions", (1,), tags=("directed",)),
            Case(ARR_N8, MODARR, "latency_and_throughput", (1,), tags=("directed",)),
            Case(ARR_N8, MODARR, "stalls_and_holds", (1,), tags=("directed",)),
            Case(ARR_N8, MODARR, "random_mixed", (1, 2), tags=("random",)),
            Case(ARR_N8, MODARR, "reset_mid_command", (1,), tags=("reset",)),
            Case(ARR_DEEP, MODARR, "directed_elementwise", (1,), tags=("directed",)),
            Case(ARR_DEEP, MODARR, "reductions", (1,), tags=("directed",)),
            Case(ARR_DEEP, MODARR, "latency_and_throughput", (1,), tags=("directed",)),
            Case(ARR_DEEP, MODARR, "stalls_and_holds", (1,), tags=("directed",)),
            Case(ARR_DEEP, MODARR, "long_vector", (1,), tags=("long",)),
            Case(ARR_DEEP, MODARR, "random_mixed", (1,), tags=("random",)),
            Case(ARR_DEEP, MODARR, "reset_mid_command", (1,), tags=("reset",)),
            Case(ARR_N1, MODARR, "reset_mid_command", (1,), tags=("reset",)),
            Case(ARR_N16, MODARR, "reset_mid_command", (1,), tags=("reset",)),
            Case(ARR_N16, MODARR, "queue_depth", (1,), tags=("directed",)),
            Case(ARR_N8, MODARR, "queue_depth", (1,), tags=("directed",)),
            Case(ARR_N1, MODARR, "config_change_b2b", (1,), tags=("directed",)),
            Case(ARR_N8, MODARR, "config_change_b2b", (1,), tags=("directed",)),
            Case(ARR_N16, MODARR, "config_change_b2b", (1,), tags=("directed",)),
            Case(ARR_DEEP, MODARR, "config_change_b2b", (1,), tags=("directed",)),
            Case(ARR_LEAN, MODARR, "config_change_b2b", (1,), tags=("directed",)),
            Case(ARR_TINY, MODARR, "config_change_b2b", (1,), tags=("directed",)),
            Case(ARR_N16, MODARR, "directed_elementwise", (1,), tags=("directed",)),
            Case(ARR_N16, MODARR, "reductions", (1,), tags=("directed",)),
            Case(ARR_N16, MODARR, "latency_and_throughput", (1,), tags=("directed",)),
            Case(ARR_N16, MODARR, "random_mixed", (1,), tags=("random",)),
            Case(ARR_N16, MODARR, "stalls_and_holds", (1,), tags=("directed",)),
            Case(ARR_N4, MODARR, "reset_mid_command", (1, 2), tags=("reset",)),
            Case(ARR_LEAN, MODARR, "reset_mid_command", (1,), tags=("reset",)),
        ],
        mutation_cases=_ARR_MUT,
        mutants_file="mutants/vec_array.yaml",
        spec_refs=("hpc_m03_vector_array/docs/ARRAY_INTERFACE.md", "hpc_m03_vector_array/docs/REDUCTION.md", "hpc_m03_vector_array/docs/MICROARCHITECTURE.md",
                   "hpc_m03_vector_array/docs/PERFORMANCE.md"),
    ),
    "vec_lane": Suite(
        name="vec_lane",
        subsystem="compute",
        title="hpc_vector_lane: IEEE-754 binary32 add/sub/mul/FMA/min/max/compare/int, fixed latency, ROB retire, reset",
        cases=[
            Case(LANE_DEF, MODLANE, "directed_arith", (1,), timeout=900, tags=("directed",)),
            Case(LANE_MIN, MODLANE, "directed_arith", (1,), timeout=900, tags=("directed",)),
            Case(LANE_LEAN, MODLANE, "directed_arith", (1,), timeout=900, tags=("directed", "error")),
            Case(LANE_DEF, MODLANE, "directed_arith_stalled", (1,), tags=("directed",)),
            Case(LANE_DEF, "compute.cocotb_vec_hunt", "hunt_arith", (1,), timeout=900, tags=("directed", "long")),
            Case(LANE_LEAN, "compute.cocotb_vec_hunt", "hunt_arith", (1,), timeout=900, tags=("directed", "long")),
            Case(LANE_DEF, MODLANE, "latency_per_op", (1,), tags=("directed",)),
            Case(LANE_MIN, MODLANE, "latency_per_op", (1,), tags=("directed",)),
            Case(LANE_LEAN, MODLANE, "latency_per_op", (1,), tags=("directed",)),
            Case(LANE_DEF, MODLANE, "throughput_and_ordering", (1,), tags=("directed",)),
            Case(LANE_LEAN, MODLANE, "throughput_and_ordering", (1,), tags=("directed",)),
            Case(LANE_DEF, MODLANE, "backpressure_hold", (1, 2), tags=("directed",)),
            Case(LANE_MIN, MODLANE, "backpressure_hold", (1, 2), tags=("directed",)),
            Case(LANE_DEF, MODLANE, "lane_enable", (1, 2), tags=("directed",)),
            Case(LANE_DEF, MODLANE, "illegal_ops", (1, 2), tags=("error",)),
            Case(LANE_LEAN, MODLANE, "illegal_ops", (1, 2), tags=("error",)),
            Case(LANE_DEF, MODLANE, "random_ops", (1, 2, 3), tags=("random",)),
            Case(LANE_MIN, MODLANE, "random_ops", (1, 2, 3), tags=("random",)),
            Case(LANE_LEAN, MODLANE, "random_ops", (1, 2), tags=("random",)),
            Case(LANE_DEF, MODLANE, "random_long", (1,), timeout=1800, tags=("random", "long")),
            Case(LANE_MIN, MODLANE, "random_long", (1,), timeout=1800, tags=("random", "long")),
            Case(LANE_DEF, MODLANE, "reset_mid_pipeline", (1, 2, 3), tags=("reset",)),
            Case(LANE_MIN, MODLANE, "reset_mid_pipeline", (1, 2), tags=("reset",)),
            Case(LANE_LEAN, MODLANE, "reset_mid_pipeline", (1,), tags=("reset",)),
            Case(LANE_TINY, MODLANE, "directed_arith_stalled", (1,), tags=("directed",)),
            Case(LANE_TINY, MODLANE, "latency_per_op", (1,), tags=("directed",)),
            Case(LANE_TINY, MODLANE, "backpressure_hold", (1,), tags=("directed",)),
            Case(LANE_TINY, MODLANE, "lane_enable", (1,), tags=("directed",)),
            Case(LANE_TINY, MODLANE, "illegal_ops", (1,), tags=("error",)),
            Case(LANE_TINY, MODLANE, "random_ops", (1, 2), tags=("random",)),
            Case(LANE_TINY, MODLANE, "reset_mid_pipeline", (1, 2), tags=("reset",)),
        ],
        mutation_cases=_LANE_MUT,
        mutants_file="mutants/vec_lane.yaml",
        spec_refs=("hpc_m03_vector_array/docs/ARRAY_INTERFACE.md", "hpc_m03_vector_array/docs/REDUCTION.md", "hpc_m03_vector_array/README.md"),
        notes="Lane model written from IEEE-754 / RISC-V rules; Module 02 lane docs are not vendored, lane policy comes from the array docs and the lane header comments.",
    ),
}
