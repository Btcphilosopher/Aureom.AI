"""Structured bug-hunt stimulus for the lane arithmetic: boundary sweeps that random testing reaches only rarely
(power-of-two minuends with sticky-only subtrahends, alignment-frame boundaries of the FMA, overflow / underflow
boundaries of the multiplier, subnormal products and addends).  Pure stimulus -- correctness comes from the model."""
from __future__ import annotations

import random
from typing import List

from albionverify.models import vec_fp32 as F
from albionverify.models.vec_lane import LaneOp

MANT = [0x000000, 0x000001, 0x400000, 0x7FFFFF, 0x7FFFFE, 0x155555, 0x3FFFFF]


def _enc(sign: int, e: int, m: int) -> int:
    return (sign << 31) | ((e & 0xFF) << 23) | (m & 0x7FFFFF)


def hunt_add_ops(rng: random.Random, tag0: int = 0) -> List[LaneOp]:
    ops: List[LaneOp] = []
    t = tag0
    for ex in (1, 2, 24, 25, 26, 27, 126, 127, 128, 200, 253, 254):
        for mx in MANT:
            for gap in range(0, 32):
                ey = ex - gap
                for my in MANT[:5]:
                    if ey < 0:
                        continue
                    for sa, sb in ((0, 0), (0, 1)):
                        rm = rng.randrange(5)
                        a, b = _enc(sa, ex, mx), _enc(sb, ey, my)
                        ops.append(LaneOp(F.OP_FADD if rng.random() < 0.5 else F.OP_FSUB, a, b, 0, rm, t & 0xFF))
                        t += 1
    return ops


def hunt_mul_ops(rng: random.Random, tag0: int = 0) -> List[LaneOp]:
    ops: List[LaneOp] = []
    t = tag0
    exps = list(range(0, 4)) + list(range(60, 70)) + list(range(120, 135)) + list(range(185, 195)) + list(range(250, 256))
    for ea in exps:
        for eb in exps:
            tot = ea + eb - 127
            if not (tot <= 3 or tot >= 250 or -30 <= tot - 1 <= 3):
                continue
            for ma in MANT[:6]:
                for mb in MANT[:6]:
                    rm = rng.randrange(5)
                    ops.append(LaneOp(F.OP_FMUL, _enc(rng.getrandbits(1), ea, ma), _enc(rng.getrandbits(1), eb, mb), 0, rm, t & 0xFF))
                    t += 1
    return ops


def hunt_fma_ops(rng: random.Random, tag0: int = 0) -> List[LaneOp]:
    ops: List[LaneOp] = []
    t = tag0
    pm = [0x000000, 0x000001, 0x7FFFFF, 0x400000]
    for ea, eb in ((127, 127), (100, 130), (1, 127), (3, 100), (200, 100), (60, 60), (254, 1), (130, 130), (1, 1), (127, 1)):
        for ma in pm:
            for mb in pm:
                ep = ea + eb - 127  # exponent of the product's leading bit (before normalisation carry)
                for gap in range(-32, 34):
                    ec = ep + gap
                    if not (0 <= ec <= 255):
                        continue
                    for mc in pm:
                        op = rng.choice(list(F.FMA_OPS))
                        rm = rng.randrange(5)
                        ops.append(LaneOp(op, _enc(rng.getrandbits(1), ea, ma), _enc(rng.getrandbits(1), eb, mb), _enc(rng.getrandbits(1), ec, mc), rm, t & 0xFF))
                        t += 1
    return ops
