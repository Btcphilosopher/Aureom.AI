"""AlbionVerify bench: hpc_vector_lane (single FP32 / INT32 vector lane).

Checks, every cycle, against albionverify.models.vec_fp32 / vec_lane (independent IEEE-754 + pipeline model):
result bits, exception flags, tag, illegal flag, exact cycle of out_valid (fixed per-op latency, in-order retire
through the ROB, mixed-latency overtaking), exact in_ready (ROB occupancy, first cycle after reset), busy,
perf-event pulses, payload stability under backpressure, zero payload when not valid, lane_en semantics, reset.
"""
import json
import os

import cocotb

from albionverify.core import Env
from albionverify.models import vec_fp32 as F
from albionverify.models.vec_gen import operand_pair_for, rm_for
from albionverify.models.vec_lane import LaneOp, LaneParams
from albionverify.reset import ResetSequencer

from compute.vec_agents import LaneDriver, LaneMonitor, LaneSink
from compute.vec_vectors import directed_ops, random_op

P = json.loads(os.environ.get("ALBION_PARAMS", "{}"))
LP = LaneParams(rob_depth=P.get("ROB_DEPTH", 8), lat_fadd=P.get("LAT_FADD", 3), lat_fmul=P.get("LAT_FMUL", 3), lat_fma=P.get("LAT_FMA", 4),
                lat_misc=P.get("LAT_MISC", 1), lat_imul=P.get("LAT_IMUL", 2), en_fcmp=bool(P.get("EN_FCMP", 1)), en_int=bool(P.get("EN_INT", 1)),
                tag_w=P.get("TAG_W", 8))


def seed_of():
    return int(os.environ.get("ALBION_SEED", "1"))


def build(dut, in_thr="always", out_thr="always"):
    env = Env(dut, clk="clk_i", name="vec_lane", seed=seed_of())
    rst = env.add(ResetSequencer("rst", env.sig("rst_ni"), active_low=True, initial_cycles=4))
    drv = env.add(LaneDriver("drv", env, env.seeds.child("drv"), in_thr))
    snk = env.add(LaneSink("snk", env, env.seeds.child("snk"), out_thr))
    mon = env.add(LaneMonitor("mon", env, LP))
    return env, rst, drv, snk, mon


async def start(env, rst):
    await env.start()
    await env.until(lambda: not rst.asserted, 50, "reset release")


async def drain(env, drv, mon, limit=20000):
    await env.until(lambda: drv.idle and mon.model.occupancy == 0, limit, "all operations retired")
    await env.cycles(6)  # nothing spurious may follow


def finish(env, mon, name, **extra):
    mon.finalize()
    env.finalize()
    env.write_result(name, scoreboard=mon.summary(), **extra)


# ============================================================================================ directed
@cocotb.test()
async def directed_arith(dut):
    """Every corner pair x every rounding mode on FADD/FSUB/FMUL, FMA triples, compares, moves, int ops, illegal ops."""
    env, rst, drv, snk, mon = build(dut)
    await start(env, rst)
    for op in directed_ops(LP):
        drv.submit(op)
    await drain(env, drv, mon, 200000)
    assert mon.n_results > 20000
    finish(env, mon, "directed_arith")


@cocotb.test()
async def directed_arith_stalled(dut):
    """Same corner set (reduced) with a bursty consumer so results wait in the ROB and retire later."""
    env, rst, drv, snk, mon = build(dut, "random:0.85", "bursty:1-9")
    await start(env, rst)
    ops = directed_ops(LP)
    for op in ops[:: max(1, len(ops) // 6000)]:
        drv.submit(op)
    await drain(env, drv, mon, 200000)
    finish(env, mon, "directed_arith_stalled")


@cocotb.test()
async def latency_per_op(dut):
    """One operation at a time, consumer always ready: result first presented exactly LAT_unit + 1 cycles after
    acceptance for every operation class; illegal operations one cycle after."""
    env, rst, drv, snk, mon = build(dut, "always", "always")
    await start(env, rst)
    lat = {}
    mon.on_result.append(lambda op, res, fl, ill, l: lat.setdefault((op.op, ill), set()).add(l))
    classes = [F.OP_FMV, F.OP_FADD, F.OP_FSUB, F.OP_FMUL, F.OP_FMADD, F.OP_FMSUB, F.OP_FNMSUB, F.OP_FNMADD, F.OP_FMIN, F.OP_FMAX,
               F.OP_FEQ, F.OP_FLT, F.OP_FLE, F.OP_IADD, F.OP_IMUL, 0x0D, 0x1F]
    for op in classes:
        drv.submit(LaneOp(op, 0x3F800000, 0x40000000, 0x40400000, 0, 0x5A))
        await drain(env, drv, mon, 200)
    for (op, ill), ls in lat.items():
        want = 1 if ill else LP.unit_latency(op) + 1
        assert ls == {want}, "op 0x%x latency %s != documented LAT_unit+1 = %d" % (op, ls, want)
    finish(env, mon, "latency_per_op")


@cocotb.test()
async def throughput_and_ordering(dut):
    """Back-to-back mixed-latency operations: one issue per cycle when the ROB is deep enough, younger short-latency
    ops overtake in execution but retire strictly in order."""
    env, rst, drv, snk, mon = build(dut, "always", "always")
    await start(env, rst)
    rng = env.seeds.child("tp")
    seq = [F.OP_FMADD, F.OP_FMV, F.OP_FADD, F.OP_IMUL, F.OP_FMUL, F.OP_FMV, F.OP_FNMADD, F.OP_FEQ] * 25
    for i, op in enumerate(seq):
        a, b, c = operand_pair_for(rng, op)
        drv.submit(LaneOp(op, a, b, c, rm_for(rng), i & 0xFF))
    cyc0 = env.cycle
    await drain(env, drv, mon, 2000)
    if LP.rob_depth >= max(LP.lat_fadd, LP.lat_fmul, LP.lat_fma, LP.lat_imul) + 2:
        assert drv.max_wait == 0, "in_ready dropped although ROB_DEPTH >= LAT + 2 (max wait %d)" % drv.max_wait
        assert env.cycle - cyc0 <= len(seq) + LP.lat_fma + 10, "issue rate below one operation per cycle"
    assert mon.overtake > 0, "stimulus never produced a younger-completes-first situation"
    finish(env, mon, "throughput_and_ordering")


@cocotb.test()
async def backpressure_hold(dut):
    """out_ready low for long runs: results stay stable, ROB fills, in_ready falls exactly at ROB_DEPTH, resumes."""
    env, rst, drv, snk, mon = build(dut, "always", "stall:25")
    await start(env, rst)
    rng = env.seeds.child("bp")
    for i in range(3 * LP.rob_depth + 6):
        drv.submit(random_op(rng, LP, 0.1, 0.0, tag=i & 0xFF))
    await env.until(lambda: mon.model.occupancy >= LP.rob_depth, 40, "ROB full")
    await env.cycles(10)
    assert drv.max_wait >= 5, "driver never saw in_ready low although the ROB was full"
    snk.set_mode("pattern:0001")
    await drain(env, drv, mon, 3000)
    snk.set_mode("never")
    for i in range(4):
        drv.submit(random_op(rng, LP, 0.0, 0.0, tag=0xF0 + i))
    await env.cycles(40)
    snk.set_mode("random:0.3")
    await drain(env, drv, mon, 3000)
    finish(env, mon, "backpressure_hold", max_ready_low_wait=drv.max_wait)


@cocotb.test()
async def lane_enable(dut):
    """lane_en = 0: consumed by the handshake, no slot, no result, no flags, no decode (illegal ops silently dropped)."""
    env, rst, drv, snk, mon = build(dut, "random:0.9", "random:0.7")
    await start(env, rst)
    rng = env.seeds.child("en")
    for i in range(400):
        o = random_op(rng, LP, 0.3, 0.5, tag=i & 0xFF)
        drv.submit(o)
    await drain(env, drv, mon, 6000)
    assert mon.n_masked > 100 and mon.n_results > 100
    finish(env, mon, "lane_enable", masked=mon.n_masked)


@cocotb.test()
async def illegal_ops(dut):
    """Reserved opcodes, illegal rounding modes (and, in lean configs, removed compare / integer ops) complete in
    order with out_illegal = 1, result 0, flags 0 and the original tag."""
    env, rst, drv, snk, mon = build(dut, "random:0.8", "random:0.6")
    await start(env, rst)
    rng = env.seeds.child("ill")
    n = 0
    for i in range(300):
        r = rng.random()
        if r < 0.35:
            op, rm = rng.choice([0x0D, 0x0E, 0x0F, 0x12, 0x13, 0x18, 0x1F]), rng.getrandbits(3)
        elif r < 0.6:
            op, rm = rng.choice(list(F.ROUNDING_OPS)), rng.choice([5, 6, 7])
        else:
            op, rm = rng.choice(list(F.ALL_LEGAL_OPS)), rng.randint(0, 4)
        a, b, c = operand_pair_for(rng, op if op in F.ALL_LEGAL_OPS else F.OP_FADD)
        n += 1
        drv.submit(LaneOp(op, a, b, c, rm, i & 0xFF, True))
    await drain(env, drv, mon, 6000)
    assert mon.n_illegal > 60
    finish(env, mon, "illegal_ops", illegal=mon.n_illegal)


# ============================================================================================ random
PROFILES = [("always", "always"), ("random:0.7", "random:0.5"), ("bursty:1-6", "bursty:1-12"), ("random:0.95", "random:0.2")]


async def run_random(dut, name, per_phase):
    env, rst, drv, snk, mon = build(dut, *PROFILES[0])
    await start(env, rst)
    rng = env.seeds.child("rand")
    for phase, (it, ot) in enumerate(PROFILES):
        drv.thr.set_mode(it)
        snk.set_mode(ot)
        for i in range(per_phase):
            drv.submit(random_op(rng, LP))
        await drain(env, drv, mon, 400000)
    finish(env, mon, name, n=mon.n_results)


@cocotb.test()
async def random_ops(dut):
    """Seeded random operation / operand / rm / lane_en / tag streams with random valid gaps and result backpressure."""
    await run_random(dut, "random_ops", 1100)


@cocotb.test()
async def random_long(dut):
    """Same generator, ~15x the volume (bug-hunting soak; tagged 'long')."""
    await run_random(dut, "random_long", 16000)


# ============================================================================================ reset
@cocotb.test()
async def reset_mid_pipeline(dut):
    """Reset with operations in every stage (synchronous pulses, state-triggered and mid-cycle asynchronous):
    all outputs low in reset, nothing from before the reset is ever emitted, ledger cancels explicitly, fresh
    traffic afterwards is exact (including a first accepted operation exactly two cycles after release)."""
    env, rst, drv, snk, mon = build(dut, "random:0.9", "random:0.5")
    await start(env, rst)
    rng = env.seeds.child("rst")
    n_reset = 0
    for rnd in range(18):
        before = rst.n_pulses
        for i in range(60):
            drv.submit(random_op(rng, LP))
        mode = rnd % 6
        if mode == 0:  # reset the moment the ROB holds >= 3 operations
            rst.arm(lambda: mon.model.occupancy >= min(3, LP.rob_depth), length=rng.randint(1, 3), reason="occupancy")
        elif mode == 1:  # reset while a result is presented but not taken
            snk.set_mode("never")
            await env.until(lambda: mon.model.q and mon.model.q[0].done_at <= env.cycle + 0, 80, "head complete")
            rst.arm(lambda: True, length=2, reason="result-stalled")
        elif mode == 2:
            rst.random_pulse(rng, 3, 25, (1, 4), "random")
        elif mode == 3:  # asynchronous mid-cycle assert
            await env.cycles(rng.randint(4, 20))
            await rst.async_pulse(phase_ns=rng.choice([1.0, 3.0, 4.9]), length_cycles=rng.randint(1, 3))
        elif mode == 5:  # reset while the lane is completely idle
            await drain(env, drv, mon, 5000)
            before = rst.n_pulses
            rst.random_pulse(rng, 2, 6, (1, 3), "idle")
        else:  # ROB full then reset
            snk.set_mode("never")
            await env.until(lambda: mon.model.occupancy >= LP.rob_depth, 80, "ROB full")
            rst.arm(lambda: True, length=3, reason="rob-full")
            await env.until(lambda: rst.asserted, 20, "reset asserted")
            for i in range(20):  # operations queued WHILE in reset: valid is presented from the very first cycle after release
                drv.submit(random_op(rng, LP))
        await env.until(lambda: rst.n_pulses > before and not rst.asserted, 200, "reset pulse")
        n_reset += 1
        snk.set_mode("random:0.5")
        await env.cycles(rng.randint(1, 4))
        # post-reset traffic
        for i in range(30):
            drv.submit(random_op(rng, LP))
        await drain(env, drv, mon, 5000)
    assert mon.sb.summary()["cancelled"] > 10, "resets never found work in flight"
    finish(env, mon, "reset_mid_pipeline", resets=n_reset, cancelled=len(mon.sb.cancelled))
