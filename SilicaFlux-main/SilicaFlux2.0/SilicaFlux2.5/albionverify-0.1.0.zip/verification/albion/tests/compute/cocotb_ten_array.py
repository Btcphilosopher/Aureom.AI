"""AlbionVerify bench: tensor_systolic_array (output-stationary INT8 x INT8 -> INT(ACC) systolic matrix multiplier).

Lock-step against albionverify.models.ten_matmul.TileModel (cycle-accurate: cfg_ready / cfg_reject / s_ready / s_k / busy /
tile_done / m_* / all six performance counters, in every cycle including stalls and back-pressure) and, per tile, against an
independent integer GEMM of the intended operands.  (Documentation says output-stationary, not weight-stationary.)
"""
import json
import os

import cocotb

from albionverify.core import Env
from albionverify.models.ten_matmul import IDLE, TenParams
from albionverify.reset import ResetSequencer

from compute.ten_agents import CfgDriver, CfgItem, MReadySink, SliceDriver, StallDriver, TenMonitor, TileJob

P = json.loads(os.environ.get("ALBION_PARAMS", "{}"))
TP = TenParams(rows=P.get("ARRAY_ROWS", 4), cols=P.get("ARRAY_COLS", 4), dw=P.get("DATA_WIDTH", 8), acc=P.get("ACC_WIDTH", 32), k_w=P.get("K_WIDTH", 17), mul_pipe=P.get("MUL_PIPE", 0))
PERF_EN = bool(P.get("PERF_EN", 1))
LO, HI = -(1 << (TP.dw - 1)), (1 << (TP.dw - 1)) - 1


def gen_tile(rng, m, n, k, kind="random") -> TileJob:
    R, C = TP.rows, TP.cols
    A = [[rng.randint(LO, HI) for _ in range(k)] for _ in range(R)]  # rows >= m are ignored lanes: random garbage on purpose
    B = [[rng.randint(LO, HI) for _ in range(C)] for _ in range(k)]
    if kind == "zeros":
        A = [[0] * k for _ in range(R)]
        B = [[0] * C for _ in range(k)]
        if rng.random() < 0.5:  # one operand zero, the other random
            A = [[rng.randint(LO, HI) for _ in range(k)] for _ in range(R)]
    elif kind == "ones":
        A = [[1] * k for _ in range(R)]
        B = [[1] * C for _ in range(k)]
    elif kind == "identity":  # A = I (padded), B random: C = B[:m][:n] when k >= m
        A = [[1 if i == kk else 0 for kk in range(k)] for i in range(R)]
    elif kind == "extreme_neg":
        A = [[LO] * k for _ in range(R)]
        B = [[LO] * C for _ in range(k)]
    elif kind == "max_pos":
        A = [[HI] * k for _ in range(R)]
        B = [[HI] * C for _ in range(k)]
    elif kind == "min_x_max":
        A = [[LO] * k for _ in range(R)]
        B = [[HI] * C for _ in range(k)]
    elif kind == "extreme_mix":
        A = [[rng.choice([LO, HI, 0, -1, 1]) for _ in range(k)] for _ in range(R)]
        B = [[rng.choice([LO, HI, 0, -1, 1]) for _ in range(C)] for _ in range(k)]
    elif kind == "alt_sign":
        A = [[LO if (i + kk) % 2 else HI for kk in range(k)] for i in range(R)]
        B = [[HI if (kk + j) % 2 else LO for j in range(C)] for kk in range(k)]
    elif kind == "wrap":
        A = [[LO] * k for _ in range(R)]
        B = [[LO] * C for _ in range(k)]
    return TileJob(m, n, k, A, B, kind)


class TBench:
    def __init__(self, dut, *, cfg_thr="always", slice_thr="always", mready_thr="always", stall="none", ghost=0.0):
        seed = int(os.environ.get("ALBION_SEED", "1"))
        self.env = env = Env(dut, clk="clk", name="ten_array", seed=seed)
        self.rst = env.add(ResetSequencer("rst", env.sig("rst_n"), active_low=True, initial_cycles=4))
        s = env.seeds
        self.cfg = env.add(CfgDriver("cfg", env, s.child("cfg"), TP, cfg_thr))
        self.sl = env.add(SliceDriver("slice", env, s.child("slice"), TP, slice_thr, ghost))
        self.stall = env.add(StallDriver("stall", env, s.child("stall"), stall))
        self.mr = env.add(MReadySink("mready", env, s.child("mready"), mready_thr))
        self.mon = env.add(TenMonitor("mon", env, TP, perf_en=PERF_EN))
        self.mon.cfg_drv, self.mon.slice_drv = self.cfg, self.sl
        self.stall.model = self.mon.model
        self.rng = s.child("gen")
        self.n_tiles = 0

    async def start(self):
        await self.env.start()
        await self.env.until(lambda: not self.rst.asserted, 50, "reset release")

    def tile(self, m, n, k, kind="random", mode="hold") -> TileJob:
        job = gen_tile(self.rng, m, n, k, kind)
        self.cfg.submit(CfgItem(m, n, k, job, mode))
        self.n_tiles += 1
        return job

    def raw_cfg(self, m, n, k, pulses=1):
        self.cfg.submit(CfgItem(m, n, k, None, "pulse", pulses))

    @property
    def quiet(self):
        return self.cfg.idle and self.mon.model.state == IDLE and self.sl.job is None and not self.sl.pending

    async def drain(self, limit=60000):
        await self.env.until(lambda: self.quiet, limit, "all tiles completed")
        await self.env.cycles(4)

    def finish(self, name, **extra):
        self.mon.finalize()
        self.env.finalize()
        self.env.write_result(name, scoreboard=self.mon.summary(), tiles=self.n_tiles, **extra)


def illegal_cfg(rng):
    """A shape that is certainly illegal for this array (so presenting it can never launch an unsubmitted tile)."""
    k = rng.randint(1, 5)
    m, n = rng.randint(1, TP.rows), rng.randint(1, TP.cols)
    which = rng.randrange(3)
    if which == 0:
        return 0, n, k
    if which == 1:
        return m, 0, k
    return m, n, 0


def shapes():
    return [(m, n) for m in range(1, TP.rows + 1) for n in range(1, TP.cols + 1)]


# ============================================================================================ directed
@cocotb.test()
async def directed_tiles(dut):
    """Every (M, N) with 1 <= M <= ROWS, 1 <= N <= COLS and K in {1, 2, 3, fill-1, fill, fill+1, 2*fill+1} with identity /
    zero / ones / random operands, no stalls: results exact, m_col_mask / m_last / row order, tile_done exactly
    h + 2 + K + M + N + MUL_PIPE, busy identity, counters."""
    b = TBench(dut)
    await b.start()
    fill = TP.rows + TP.cols
    ks = sorted({1, 2, 3, fill - 1, fill, fill + 1, 2 * fill + 1})
    kinds = ["random", "identity", "ones", "zeros", "random"]
    i = 0
    for (m, n) in shapes():
        for k in ks:
            if k < 1 or k > TP.k_max:
                continue
            b.tile(m, n, k, kinds[i % len(kinds)])
            i += 1
    await b.drain(200000)
    for tl in b.mon.tiles:
        want = 2 + tl["k"] + tl["m"] + tl["n"] + TP.mul_pipe
        assert tl["done"] - tl["launch"] == want, "tile %s: tile_done at launch+%d, documented h+2+K+M+N+MUL_PIPE = %d" % (tl, tl["done"] - tl["launch"], want)
        assert tl["busy"] == 1 + tl["k"] + tl["m"] + tl["n"] + TP.mul_pipe
    b.finish("directed_tiles")


@cocotb.test()
async def extreme_values(dut):
    """-128 / 127 products, accumulator-width boundaries (wrap-around at the configured ACC_WIDTH, K at and around the
    first wrapping K), K = K_max, sign extension of negative sums, alternating-sign extremes."""
    b = TBench(dut, slice_thr="random:0.9", mready_thr="random:0.8")
    await b.start()
    rng = b.rng
    R, C = TP.rows, TP.cols
    kinds = ["extreme_neg", "max_pos", "min_x_max", "extreme_mix", "alt_sign", "identity", "zeros", "ones"]
    for kind in kinds:
        for k in (1, 2, 3, 7):
            b.tile(R, C, min(k, TP.k_max), kind)
        b.tile(1 if R > 1 else R, C, 5, kind)
        b.tile(R, 1, 4, kind)
    # first wrapping K for (-2^(DW-1))^2 products: K * 2^(2DW-2) >= 2^(ACC-1)
    kw = -(-(1 << (TP.acc - 1)) // (1 << (2 * TP.dw - 2)))
    for k in (kw - 1, kw, kw + 1, kw + 2):
        if 1 <= k <= TP.k_max and k <= 1100:
            b.tile(R, C, k, "wrap")
            b.tile(max(1, R - 1), max(1, C - 1), k, "wrap")
            b.tile(R, C, k, "min_x_max")  # negative accumulations hit the lower boundary
    if TP.k_max <= 1100:
        b.tile(R, C, TP.k_max, "wrap")
        b.tile(R, C, TP.k_max, "extreme_mix")
    else:
        b.tile(R, C, 1000, "min_x_max")
        b.tile(R, C, 500, "max_pos")
    for (m, n) in ((max(1, R - 1), C), (R, max(1, C - 1))):  # long K on partial tiles
        b.tile(m, n, min(TP.k_max, 70), "extreme_mix")
    await b.drain(300000)
    assert b.mon.wrapped_tiles > 0 or kw > TP.k_max or TP.acc >= 32, "no tile exercised the accumulator wrap-around"
    b.finish("extreme_values", wrapped_tiles=b.mon.wrapped_tiles)


@cocotb.test()
async def cfg_handshake(dut):
    """cfg_valid / cfg_ready: ready only in IDLE, cfg offered while busy is ignored (no effect, no reject), illegal shapes
    (M = 0, M > ROWS, N = 0, N > COLS, K = 0) are dropped with a one-cycle cfg_reject pulse and leave the array idle and
    unchanged, a legal cfg held valid during the previous tile is accepted at the first idle cycle, back-to-back tiles of
    different shapes."""
    b = TBench(dut, slice_thr="random:0.8", mready_thr="random:0.8")
    await b.start()
    rng = b.rng
    R, C = TP.rows, TP.cols
    mw, nw = TP.m_w, TP.n_w
    # 1. illegal configurations while idle, each followed by a legal tile
    illegal = [(0, 1, 1), (1, 0, 1), (1, 1, 0), (0, 0, 0)]
    if (1 << mw) - 1 > R:
        illegal.append((R + 1, 1, 2))
        illegal.append(((1 << mw) - 1, C, 3))
    if (1 << nw) - 1 > C:
        illegal.append((1, C + 1, 2))
        illegal.append((R, (1 << nw) - 1, 3))
    for (m, n, k) in illegal:
        b.raw_cfg(m, n, k)
        b.tile(rng.randint(1, R), rng.randint(1, C), rng.randint(1, 6))
        await b.drain(2000)
    assert b.mon.n_reject == len(illegal)
    # 2. a legal-looking cfg offered (1-3 cycles) in every busy phase must be ignored: no effect, no reject, tile unchanged
    m_ = b.mon.model
    b.mr.set_mode("random:0.35")
    for target in ("CLEAR", "RUN", "RUN", "RUN", "DRAIN", "DRAIN", "READOUT"):
        if target == "READOUT" and R < 3:
            continue
        b.tile(R, C, 6 + (R + C))
        if target == "READOUT":
            await b.env.until(lambda: m_.state == "READOUT" and m_.rd_row == 0, 400, "READOUT")
        elif target == "DRAIN":
            await b.env.until(lambda: m_.state == "DRAIN" and m_.drain_done == 0, 400, "DRAIN")
        elif target == "RUN":
            await b.env.until(lambda: m_.state == "RUN" and m_.k_cnt >= 1, 400, "RUN")
        else:
            await b.env.until(lambda: m_.state == "CLEAR", 400, "CLEAR")
        b.raw_cfg(rng.randint(1, R), rng.randint(1, C), rng.randint(1, 3), pulses=1)
        await b.drain(3000)
    b.raw_cfg(0, 0, 0, pulses=1)  # illegal + busy would be ignored as well: present it while a tile runs
    b.tile(R, C, 4 * (R + C))
    await b.env.until(lambda: m_.state == "RUN" and m_.k_cnt >= 2, 400, "RUN")
    b.raw_cfg(0, 0, 0, pulses=2)
    await b.drain(3000)
    b.mr.set_mode("random:0.8")
    assert b.mon.n_ignored >= 6
    # 3. held legal cfg across busy: accepted right when the tile finishes; back-to-back with different shapes
    for i in range(30):
        b.tile(rng.randint(1, R), rng.randint(1, C), rng.randint(1, 3 * (R + C)), rng.choice(["random", "identity", "ones", "extreme_mix"]))
    await b.drain(60000)
    # 4. illegal cfg held for several cycles while idle: one reject per cycle presented
    b.raw_cfg(0, 1, 1, pulses=3)
    await b.drain(200)
    # 5. K = K_max shape accepted (largest legal K)
    if TP.k_max <= 300:
        b.tile(R, C, TP.k_max, "random")
        await b.drain(5000)
    b.finish("cfg_handshake", rejects=b.mon.n_reject, ignored=b.mon.n_ignored)


# ============================================================================================ stalls
@cocotb.test()
async def stalls_and_backpressure(dut):
    """s_valid gaps, m_ready back-pressure and stall_i patterns (random, bursty, periodic, at fill time, at drain time, the
    cycle before the last slice, exactly in the all_done cycle, in every state): partial sums preserved, no duplicate or
    dropped slice (K commits), results exact, identity busy = 1 + K + M + N + MUL_PIPE + stall_up + stall_ext."""
    b = TBench(dut, ghost=0.3)
    await b.start()
    rng = b.rng
    R, C = TP.rows, TP.cols
    stalls = ["random:0.3", "bursty:1-6", "pattern:0110", "fill", "drain", "lastslice", "done_cycle", "edges", "random:0.7", "pattern:1110", "bursty:5-20"]
    slices = ["always", "random:0.5", "bursty:1-8", "pattern:101", "random:0.9"]
    mreads = ["always", "random:0.4", "bursty:1-10", "pattern:001"]
    for si, st in enumerate(stalls):
        b.stall.set_mode(st)
        for t in range(5):
            b.sl.thr.set_mode(slices[(si + t) % len(slices)])
            b.mr.set_mode(mreads[(si * 3 + t) % len(mreads)])
            m, n, k = rng.randint(1, R), rng.randint(1, C), rng.randint(1, 2 * (R + C))
            b.tile(m, n, k, rng.choice(["random", "extreme_mix", "identity"]))
            await b.drain(50000)
    b.finish("stalls_and_backpressure")


# ============================================================================================ random
async def run_random_tiles(dut, name, per_phase):
    b = TBench(dut, cfg_thr="random:0.7", slice_thr="random:0.8", mready_thr="random:0.7", stall="random:0.2", ghost=0.2)
    await b.start()
    rng = b.rng
    R, C = TP.rows, TP.cols
    kinds = ["random", "random", "extreme_mix", "identity", "ones", "zeros", "alt_sign", "extreme_neg", "min_x_max", "max_pos"]
    profiles = [("random:0.7", "random:0.8", "random:0.7", "random:0.2"), ("always", "always", "always", "none"), ("bursty:1-5", "bursty:1-9", "bursty:1-6", "bursty:1-4"),
                ("random:0.9", "random:0.3", "random:0.9", "pattern:0100"), ("random:0.5", "random:0.9", "random:0.3", "edges")]
    for ph, (ct, st, mt, sm) in enumerate(profiles):
        b.cfg.thr.set_mode(ct)
        b.sl.thr.set_mode(st)
        b.mr.set_mode(mt)
        b.stall.set_mode(sm)
        for _ in range(per_phase):
            r = rng.random()
            if r < 0.12:
                b.raw_cfg(*illegal_cfg(rng), pulses=rng.randint(1, 3))
            else:
                k = rng.randint(1, 3 * (R + C)) if rng.random() < 0.9 else rng.randint(1, min(TP.k_max, 120))
                b.tile(rng.randint(1, R), rng.randint(1, C), min(k, TP.k_max), rng.choice(kinds))
        await b.drain(400000)
    b.finish(name)


@cocotb.test()
async def random_tiles(dut):
    """Seeded random tile shapes / data kinds / K, random stall_i / s_valid / m_ready / cfg timing, illegal cfg pulses,
    cfg offered while busy, spurious s_valid outside RUN."""
    await run_random_tiles(dut, "random_tiles", 16)


@cocotb.test()
async def random_long(dut):
    """Same generator, ~15x the volume (bug-hunting soak; tagged 'long')."""
    await run_random_tiles(dut, "random_long", 240)


# ============================================================================================ reset
@cocotb.test()
async def reset_mid_tile(dut):
    """Reset (synchronous pulses, state-triggered, mid-cycle asserted) in IDLE, CLEAR, RUN (tokens in flight), DRAIN and READOUT
    (mid rows): counters / flags / FSM cleared, no stale m_valid, no result for the aborted tile, fresh tiles of other shapes
    exact (stale tokens in the skew network must not corrupt the next, larger tile)."""
    b = TBench(dut, slice_thr="random:0.9", mready_thr="random:0.5")
    await b.start()
    rng = b.rng
    R, C = TP.rows, TP.cols
    m_ = b.mon.model
    for rnd in range(21):
        before = b.rst.n_pulses
        mode = rnd % 7
        if mode == 3 and R < 2:
            mode = 1
        m_tile = R if mode == 3 else rng.randint(1, R)
        b.tile(m_tile, rng.randint(1, C), rng.randint(2, 2 * (R + C)))
        if mode == 0:
            b.rst.arm(lambda: m_.state == "CLEAR", length=rng.randint(1, 2), reason="CLEAR")
        elif mode == 1:
            b.rst.arm(lambda: m_.state == "RUN" and m_.k_cnt >= 1, length=rng.randint(1, 3), reason="RUN")
        elif mode == 2:
            b.rst.arm(lambda: m_.state == "DRAIN" and m_.drain_done >= 1, length=1, reason="DRAIN")
        elif mode == 3:
            b.rst.arm(lambda: m_.state == "READOUT" and m_.rd_row >= 1, length=2, reason="READOUT rows")
            b.mr.set_mode("random:0.3")
        elif mode == 4:
            await b.env.until(lambda: m_.state == "RUN", 200, "RUN")
            await b.env.cycles(rng.randint(0, 3))
            await b.rst.async_pulse(phase_ns=rng.choice([1.0, 3.0, 4.9]), length_cycles=rng.randint(1, 3))
        elif mode == 6:
            b.rst.arm(lambda: m_.state == "READOUT" and m_.rd_row == 0, length=1, reason="READOUT row 0")
            b.mr.set_mode("random:0.3")
        else:
            await b.drain(5000)  # reset while idle (nothing in flight)
            before = b.rst.n_pulses
            b.rst.random_pulse(b.rng, 2, 6, (1, 3), "idle")
        await b.env.until(lambda: b.rst.n_pulses > before and not b.rst.asserted, 400, "reset pulse")
        b.mr.set_mode("random:0.5")
        await b.env.cycles(rng.randint(1, 4))
        for _ in range(3):
            b.tile(rng.randint(1, R), rng.randint(1, C), rng.randint(1, 2 * (R + C)))
        await b.drain(20000)
    assert b.mon.sb.summary()["cancelled"] >= 6, "resets never found a tile in flight"
    b.finish("reset_mid_tile", resets=b.rst.n_pulses, cancelled=len(b.mon.sb.cancelled))
