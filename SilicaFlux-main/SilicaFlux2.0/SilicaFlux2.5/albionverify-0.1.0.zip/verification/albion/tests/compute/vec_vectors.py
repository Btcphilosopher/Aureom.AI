"""Directed and random stimulus builders for the vector benches (lane level)."""
from __future__ import annotations

import itertools
import random
from typing import List

from albionverify.models import vec_fp32 as F
from albionverify.models.vec_gen import operand_pair_for, rand_fp32, rm_for
from albionverify.models.vec_lane import LaneOp, LaneParams

# key encodings: the arithmetic corners (signs are explicit)
KEYS = [
    0x00000000, 0x80000000,  # +-0
    0x00000001, 0x80000001,  # +-smallest subnormal
    0x007FFFFF, 0x807FFFFF,  # +-largest subnormal
    0x00400000,              # 2^-127
    0x00800000, 0x80800000,  # +-smallest normal
    0x00800001,
    0x3F800000, 0xBF800000,  # +-1
    0x3F800001, 0x3F7FFFFF,  # 1 + ulp, 1 - ulp/2
    0x3F000000, 0x40000000,  # 0.5, 2
    0x33800000, 0x33000000,  # 2^-24, 2^-25 (half-ulp ties around 1.0)
    0x4B000000, 0x4B7FFFFF, 0x4B800000,  # 2^23, 2^24 - 1 style, 2^24
    0x7F7FFFFF, 0xFF7FFFFF,  # +-max normal
    0x7F000000,              # 2^127
    0x7F800000, 0xFF800000,  # +-inf
    0x7FC00000, 0xFFC00000,  # qNaN
    0x7FA00000, 0x7F800001,  # sNaN
    0x7FC12345,              # qNaN with payload
]
KEYS_FMA = [0x00000000, 0x80000000, 0x00000001, 0x007FFFFF, 0x00800000, 0x3F800000, 0xBF800000, 0x3F800001, 0x3F7FFFFF, 0x40000000,
            0x33800000, 0x7F7FFFFF, 0x7F800000, 0xFF800000, 0x7FC00000, 0x7FA00000, 0x3F000000]
RMS = (0, 1, 2, 3, 4)


def directed_ops(p: LaneParams, tag0: int = 0) -> List[LaneOp]:
    """All corner pairs on every FP operation under every rounding mode, plus FMA triples and structured
    single-rounding / cancellation / tie / overflow / underflow cases."""
    ops: List[LaneOp] = []
    tag = [tag0]

    def add(op, a, b=0, c=0, rm=0):
        ops.append(LaneOp(op, a, b, c, rm, tag[0] & 0xFF))
        tag[0] += 1

    for op in (F.OP_FADD, F.OP_FSUB, F.OP_FMUL):
        for a, b in itertools.product(KEYS, KEYS):
            for rm in RMS:
                add(op, a, b, 0, rm)
    for op in F.FCMP_OPS:
        if not p.en_fcmp:
            continue
        for a, b in itertools.product(KEYS, KEYS):
            add(op, a, b, 0, 0)
    for a in KEYS:
        add(F.OP_FMV, a, 0x7FA00001, 0x7FA00002, 7)  # FMV ignores rm and the other operands
    if p.en_int:
        for a, b in [(0, 0), (1, 1), (0xFFFFFFFF, 1), (0x80000000, 0x80000000), (0xFFFFFFFF, 0xFFFFFFFF), (0x10000, 0x10000), (12345, 6789), (0x7FFFFFFF, 2)]:
            add(F.OP_IADD, a, b)
            add(F.OP_IMUL, a, b)
    # FMA: key triples (reduced key set), mode chosen round-robin so every mode meets every sign-corner
    k = 0
    for op in F.FMA_OPS:
        for a, b, c in itertools.product(KEYS_FMA, KEYS_FMA, KEYS_FMA):
            add(op, a, b, c, RMS[k % 5])
            k += 1
    # structured FMA cases: single rounding vs mul-then-add, exact cancellation, residual extraction
    for rm in RMS:
        add(F.OP_FMADD, 0x3F800001, 0x3F7FFFFF, 0xBF800000, rm)  # residual 2^-24 - 2^-47 survives a fused op
        add(F.OP_FMADD, 0x3F800001, 0x3F800001, 0xBF800000, rm)
        add(F.OP_FMSUB, 0x40000000, 0x40400000, 0x40C00000, rm)  # 2*3 - 6 -> exact zero
        add(F.OP_FNMSUB, 0x40000000, 0x40400000, 0x40C00000, rm)  # -(2*3) + 6
        add(F.OP_FNMADD, 0x40000000, 0x40400000, 0xC0C00000, rm)  # -(2*3) - (-6)
        add(F.OP_FMADD, 0x3F800400, 0x007FFC00, 0x00000000, rm)  # tininess-after-rounding boundary
        add(F.OP_FMADD, 0x00800000, 0x3F7FFFFF, 0x80000000, rm)
        add(F.OP_FMADD, 0x7F7FFFFF, 0x40000000, 0xFF7FFFFF, rm)  # overflow of the product cancelled by c: exact fma ~ max
        add(F.OP_FMADD, 0x7F7FFFFF, 0x3F800001, 0x00000000, rm)
        add(F.OP_FMADD, 0x1A000000, 0x1A000000, 0x00000001, rm)  # product far below c
        add(F.OP_FMADD, 0x6E000000, 0x6E000000, 0xFF7FFFFF, rm)  # product far above c
    # rounding ties on addition at every exponent-gap boundary (24..28) for both signs and modes
    for gap in (22, 23, 24, 25, 26, 27, 28):
        for rm in RMS:
            for sa, sb in ((0, 0), (0, 1), (1, 0), (1, 1)):
                a = (sa << 31) | ((127 + 30) << 23) | 0x155555
                b = (sb << 31) | ((127 + 30 - gap) << 23) | 0x400000
                add(F.OP_FADD, a, b, 0, rm)
                add(F.OP_FSUB, a, b, 0, rm)
    # illegal operations (reserved opcodes, illegal rounding mode) must complete in order, flagged
    for opc in (0x0D, 0x0E, 0x0F, 0x12, 0x13, 0x1F, 0x14):
        add(opc, 0x3F800000, 0x40000000, 0x40400000, 0)
    for rm in (5, 6, 7):
        for op in (F.OP_FADD, F.OP_FSUB, F.OP_FMUL, F.OP_FMADD, F.OP_FMSUB, F.OP_FNMSUB, F.OP_FNMADD):
            add(op, 0x3F800000, 0x40000000, 0x40400000, rm)
        add(F.OP_FMV, 0x12345678, 0, 0, rm)  # legal: rm ignored for FMV
        add(F.OP_FMIN, 0x3F800000, 0x40000000, 0, rm)
    return ops


WEIGHTS = {F.OP_FMV: 3, F.OP_FADD: 8, F.OP_FSUB: 6, F.OP_FMUL: 8, F.OP_FMADD: 6, F.OP_FMSUB: 4, F.OP_FNMSUB: 4, F.OP_FNMADD: 4,
           F.OP_FMIN: 3, F.OP_FMAX: 3, F.OP_FEQ: 2, F.OP_FLT: 2, F.OP_FLE: 2, F.OP_IADD: 2, F.OP_IMUL: 3}


def random_op(rng: random.Random, p: LaneParams, illegal_frac: float = 0.06, off_frac: float = 0.06, tag: int = None) -> LaneOp:
    r = rng.random()
    if r < illegal_frac / 2:
        op = rng.choice([0x0D, 0x0E, 0x0F] + list(range(0x12, 0x20)))
        rm = rng.getrandbits(3)
    else:
        op = rng.choices(list(WEIGHTS), weights=list(WEIGHTS.values()))[0]
        rm = rm_for(rng)
        if r < illegal_frac and op in F.ROUNDING_OPS:
            rm = rng.choice([5, 6, 7])
        elif op not in F.ROUNDING_OPS and rng.random() < 0.3:
            rm = rng.getrandbits(3)
    a, b, c = operand_pair_for(rng, op)
    if rng.random() < 0.05:
        a, b, c = rand_fp32(rng, "uniform"), rand_fp32(rng, "uniform"), rand_fp32(rng, "uniform")
    return LaneOp(op, a, b, c, rm, rng.getrandbits(8) if tag is None else tag, rng.random() >= off_frac)
