"""Model unit tests for albionverify.models.vec_array and vec_lane (no simulator)."""
import random

import pytest

from albionverify.models import vec_fp32 as F
from albionverify.models.vec_array import ArrayParams, Beat, Cmd, cmd_legal, expected, nbeats, reduction_latency, elementwise_result_latency
from albionverify.models.vec_gen import f2b, rand_fp32
from albionverify.models.vec_lane import LaneModel, LaneOp, LaneParams


def mk_beats(vals_a, vals_b=None, vals_c=None, masks=None, n=2):
    nb = nbeats(len(vals_a), n)
    pad = lambda v: list(v) + [0x7FA00000] * (nb * n - len(v))  # tail garbage = sNaN
    A, B, C = pad(vals_a), pad(vals_b or [0] * len(vals_a)), pad(vals_c or [0] * len(vals_a))
    return [Beat(A[g * n:(g + 1) * n], B[g * n:(g + 1) * n], C[g * n:(g + 1) * n], (masks[g] if masks else 0)) for g in range(nb)]


# ---------------------------------------------------------------------------------------------- reduction order
def test_hand_reduction_tree_vs_sequential():
    big = f2b(16777216.0)  # 2^24
    one = f2b(1.0)
    xs = [big, one, one, one]
    # N = 1: strictly sequential accumulation: (((0 + 2^24) + 1) + 1) + 1 = 2^24  (every +1 is a tie that rounds to even)
    e1 = expected(Cmd(F.OP_FMV, 0, 4, red=1, tid=3), mk_beats(xs, n=1), ArrayParams(n=1))
    assert e1.cpl.result == big and e1.cpl.flags == F.NX and not e1.beats
    # N = 4: S = (2^24 + 1) + (1 + 1) = 2^24 + 2 = 16777218 (representable); result = 0 + S
    e4 = expected(Cmd(F.OP_FMV, 0, 4, red=1), mk_beats(xs, n=4), ArrayParams(n=4))
    assert e4.cpl.result == f2b(16777218.0)
    # N = 2: beat sums (2^24 + 1 -> 2^24) and (1 + 1 = 2); accumulate 0 + 2^24 + 2 = 16777218
    e2 = expected(Cmd(F.OP_FMV, 0, 4, red=1), mk_beats(xs, n=2), ArrayParams(n=2))
    assert e2.cpl.result == f2b(16777218.0)
    # initial value: reduction starts from cmd_scalar
    e = expected(Cmd(F.OP_FMV, 0, 2, red=1, scalar=f2b(100.0)), mk_beats([f2b(1.0), f2b(2.0)], n=2), ArrayParams(n=2))
    assert e.cpl.result == f2b(103.0) and e.cpl.flags == 0 and e.cpl.count == 2


def test_hand_reduction_absent_leaves_no_identity():
    nz, pz = 0x80000000, 0
    # all-masked reduction returns the initial value unchanged, without flags, even for -0 under RDN
    c = Cmd(F.OP_FMV, F.RDN, 4, vm=1, red=1, scalar=nz)
    e = expected(c, mk_beats([pz] * 4, masks=[0, 0], n=2), ArrayParams(n=2))
    assert e.cpl.result == nz and e.cpl.flags == 0 and e.cpl.count == 0
    # one present leaf is passed up unchanged (no phantom +0 add): a single -0 element: acc = -0 + (-0) = -0 even in RDN
    c = Cmd(F.OP_FMV, F.RDN, 4, vm=1, red=1, scalar=nz)
    e = expected(c, mk_beats([nz, pz, pz, pz], masks=[0b01, 0b00], n=2), ArrayParams(n=2))
    assert e.cpl.result == nz
    # an sNaN leaf in a reduction: the single present leaf is passed up, the accumulator add raises NV, result qNaN
    c = Cmd(F.OP_FMV, 0, 2, vm=1, red=1, scalar=0)
    e = expected(c, mk_beats([0x7FA00000, 0x3F800000], masks=[0b01], n=2), ArrayParams(n=2))
    assert e.cpl.result == F.QNAN and e.cpl.flags == F.NV and e.cpl.count == 1
    # dot product: unfused, each product rounded first
    c = Cmd(F.OP_FMUL, 0, 2, red=1)
    a = [0x3F800001, 0x3F800000]
    b = [0x3F7FFFFF, 0x3F800000]
    e = expected(c, mk_beats(a, b, n=2), ArrayParams(n=2))
    p0, _ = F.fmul(a[0], b[0], 0)
    s, _ = F.fadd(p0, 0x3F800000, 0)
    r, _ = F.fadd(0, s, 0)
    assert e.cpl.result == r


def test_reduction_rm_and_overflow_semantic():
    mx = 0x7F7FFFFF
    c = Cmd(F.OP_FMV, F.RTZ, 2, red=1)
    e = expected(c, mk_beats([mx, mx], n=2), ArrayParams(n=2))
    assert e.cpl.result == mx and e.cpl.flags == (F.OF | F.NX)  # RTZ overflow -> max finite
    c = Cmd(F.OP_FMV, F.RNE, 2, red=1)
    e = expected(c, mk_beats([mx, mx], n=2), ArrayParams(n=2))
    assert e.cpl.result == 0x7F800000 and e.cpl.flags == (F.OF | F.NX)
    # inf - inf inside a later add -> NaN with NV
    c = Cmd(F.OP_FMV, F.RNE, 4, red=1)
    e = expected(c, mk_beats([0x7F800000, 0x3F800000, 0xFF800000, 0], n=2), ArrayParams(n=2))
    assert e.cpl.result == F.QNAN and e.cpl.flags & F.NV


def _naive_order(vals, n, rm, init):
    """Independent recursive formulation of REDUCTION.md section 1."""
    def tree(lo, hi):
        if hi - lo == 1:
            return vals[lo]
        mid = (lo + hi) // 2
        l, r = tree(lo, mid), tree(mid, hi)
        if l is None:
            return r
        if r is None:
            return l
        s, f = F.fadd(l, r, rm)
        flags[0] |= f
        return s
    flags = [0]
    acc = init
    for g in range(0, len(vals), n):
        s = tree(g, g + n)
        if s is not None:
            acc, f = F.fadd(acc, s, rm)
            flags[0] |= f
    return acc, flags[0]


@pytest.mark.parametrize("n", [1, 2, 4, 8])
def test_reduction_random_vs_recursive_formulation(n):
    rng = random.Random(10 + n)
    p = ArrayParams(n=n)
    for _ in range(300):
        vl = rng.randint(0, 5 * n + 3)
        rm = rng.choice([0, 1, 2, 3, 4])
        vm = rng.getrandbits(1)
        nb = nbeats(vl, n)
        a = [rand_fp32(rng, "finite" if rng.random() < 0.7 else "mixed") for _ in range(nb * n)]
        masks = [rng.getrandbits(n) for _ in range(nb)]
        init = rand_fp32(rng)
        beats = [Beat(a[g * n:(g + 1) * n], [0] * n, [0] * n, masks[g]) for g in range(nb)]
        c = Cmd(F.OP_FMV, rm, vl, vm, 0, init, 1, 1)
        e = expected(c, beats, p)
        vals = [None] * (nb * n)
        for el in range(nb * n):
            if el < vl and (not vm or (masks[el // n] >> (el % n)) & 1):
                vals[el] = a[el]
        acc, fl = _naive_order(vals, n, rm, init)
        assert e.cpl.result == acc and e.cpl.flags == fl, (n, vl, rm)


# ---------------------------------------------------------------------------------------------- elementwise framing
def test_hand_elementwise_vl_mask_broadcast():
    p = ArrayParams(n=4)
    # vl = 6 -> 2 beats; tail positions 6, 7 are inactive: data 0, flags 0, mask 0
    a = [f2b(1.0), f2b(2.0), f2b(3.0), f2b(4.0), f2b(5.0), f2b(6.0)]
    b = [f2b(10.0)] * 6
    c = Cmd(F.OP_FADD, 0, 6, tid=0x55)
    e = expected(c, mk_beats(a, b, n=4), p)
    assert len(e.beats) == 2 and nbeats(6, 4) == 2
    assert e.beats[0].data == [f2b(11.0), f2b(12.0), f2b(13.0), f2b(14.0)] and e.beats[0].mask == 0xF and e.beats[0].last == 0
    assert e.beats[1].data == [f2b(15.0), f2b(16.0), 0, 0] and e.beats[1].mask == 0b0011 and e.beats[1].last == 1
    assert e.beats[1].flags == [0] * 4 and e.beats[1].beat == 1 and e.beats[1].tid == 0x55
    assert e.cpl.count == 6 and e.cpl.flags == 0 and e.cpl.illegal == 0
    # masks: vm=1 -> only mask bits; masked elements give zeros and do not count
    c = Cmd(F.OP_FADD, 0, 4, vm=1)
    e = expected(c, mk_beats(a[:4], b[:4], masks=[0b0101], n=4), p)
    assert e.beats[0].data == [f2b(11.0), 0, f2b(13.0), 0] and e.beats[0].mask == 0b0101 and e.cpl.count == 2
    # broadcast scalar on operand b (AXPY style y = alpha*x + y: a = scalar)
    c = Cmd(F.OP_FMADD, 0, 4, bcast=0b001, scalar=f2b(2.0))
    e = expected(c, mk_beats([0] * 4, a[:4], b[:4], n=4), p)
    assert e.beats[0].data == [f2b(12.0), f2b(14.0), f2b(16.0), f2b(18.0)]
    # vl = 0: no beats, completion count 0
    e = expected(Cmd(F.OP_FADD, 0, 0), [], p)
    assert e.beats == [] and e.cpl.count == 0 and e.cpl.illegal == 0


def test_hand_illegal_commands():
    p = ArrayParams(n=2, red_en=True)
    for c in (Cmd(0x0D, 0, 3, tid=9), Cmd(F.OP_FADD, 5, 3, tid=9), Cmd(F.OP_FMUL, 7, 3, tid=9), Cmd(0x12, 0, 3, tid=9)):
        assert not cmd_legal(c, p)
        e = expected(c, mk_beats([1, 2, 3], n=2), p)
        assert len(e.beats) == 2 and all(b.mask == 0 and b.data == [0, 0] and b.flags == [0, 0] for b in e.beats)
        assert e.cpl.illegal == 1 and e.cpl.count == 0 and e.cpl.flags == 0 and e.cpl.result == 0
    # illegal reductions: non-FP op, rm > 4, broadcast, RED_EN = 0; vl = 0 does not change legality
    assert not cmd_legal(Cmd(F.OP_FMIN, 0, 4, red=1), p)
    assert not cmd_legal(Cmd(F.OP_IADD, 0, 4, red=1), p)
    assert not cmd_legal(Cmd(F.OP_FMV, 5, 4, red=1), p)  # reductions always round, even FMV
    assert not cmd_legal(Cmd(F.OP_FMV, 0, 4, bcast=1, red=1), p)
    assert cmd_legal(Cmd(F.OP_FMV, 0, 4, bcast=1, red=0), p)
    assert cmd_legal(Cmd(F.OP_FMV, 7, 4, red=0), p)  # FMV elementwise ignores rm
    assert not cmd_legal(Cmd(F.OP_FMV, 0, 0, bcast=2, red=1), p)
    assert not cmd_legal(Cmd(F.OP_FMV, 0, 4, red=1), ArrayParams(n=2, red_en=False))
    assert not cmd_legal(Cmd(F.OP_FEQ, 0, 4), ArrayParams(n=2, lane=LaneParams(en_fcmp=False)))
    assert not cmd_legal(Cmd(F.OP_IMUL, 0, 4), ArrayParams(n=2, lane=LaneParams(en_int=False)))
    # illegal reduction still consumes ceil(vl/N) beats and emits no result beat
    e = expected(Cmd(F.OP_FMIN, 0, 5, red=1), mk_beats([1] * 5, n=2), p)
    assert e.beats == [] and e.cpl.illegal == 1 and e.cpl.red == 1


def test_flag_aggregation_only_active_elements():
    p = ArrayParams(n=2)
    # an sNaN in a masked-out lane must not raise NV; an inexact in an active lane raises NX
    a = [0x7FA00000, f2b(1.0)]
    b = [f2b(1.0), 0x33800000]
    c = Cmd(F.OP_FADD, 0, 2, vm=1)
    e = expected(c, mk_beats(a, b, masks=[0b10], n=2), p)
    assert e.cpl.flags == F.NX and e.beats[0].flags == [0, F.NX] and e.beats[0].data[0] == 0


# ---------------------------------------------------------------------------------------------- documented timing helpers
def test_documented_latencies():
    p = ArrayParams(n=1)
    assert [elementwise_result_latency(op, 0, p) for op in (F.OP_FMV, F.OP_FADD, F.OP_FMUL, F.OP_FMADD)] == [3, 5, 5, 6]
    # PERFORMANCE.md: 7 / 9 at N = 1, +3 per doubling, 19 / 21 at N = 16
    assert [reduction_latency(F.OP_FMV, ArrayParams(n=n)) for n in (1, 2, 4, 8, 16)] == [7, 10, 13, 16, 19]
    assert [reduction_latency(F.OP_FMUL, ArrayParams(n=n)) for n in (1, 2, 4, 8, 16)] == [9, 12, 15, 18, 21]


# ---------------------------------------------------------------------------------------------- lane timing model
def run_lane(model, plan, out_ready=lambda t: 1, horizon=60):
    """plan: {cycle: LaneOp or None}.  Returns list of (cycle, result, flags, tag, illegal) retirements."""
    seen = []
    for t in range(1, horizon):
        o = model.outputs(t)
        op = plan.get(t)
        iv = int(op is not None)
        orr = out_ready(t)
        if o.out_valid and orr:
            seen.append((t, o.out_result, o.out_flags, o.out_tag, o.out_illegal))
        model.edge(t, iv, op, orr)
    return seen


def test_lane_model_latency_and_ordering():
    p = LaneParams()
    m = LaneModel(p)
    one, two, three = f2b(1.0), f2b(2.0), f2b(3.0)
    plan = {
        2: LaneOp(F.OP_FMADD, two, three, one, 0, tag=1),  # LAT 4 -> visible at 2 + 5 = 7
        3: LaneOp(F.OP_FMV, 0x7FA00001, 0, 0, 0, tag=2),  # LAT 1 (done earlier) but must retire after tag 1
        4: LaneOp(F.OP_FADD, one, two, 0, 5, tag=3),  # illegal rm: complete at once, retires in order
        5: LaneOp(F.OP_IMUL, 7, 6, 0, 0, tag=4),
        6: LaneOp(F.OP_FADD, one, one, 0, 0, tag=5, en=False),  # disabled: no slot, no result
    }
    seen = run_lane(m, plan)
    assert [s[3] for s in seen] == [1, 2, 3, 4]
    assert seen[0][0] == 7 and seen[0][1] == f2b(7.0)
    assert seen[1][0] == 8 and seen[1][1] == 0x7FA00001 and seen[1][2] == 0  # FMV bit-exact, no flags
    assert seen[2][0] == 9 and seen[2][4] == 1 and seen[2][1] == 0
    assert seen[3][0] == 10 and seen[3][1] == 42
    # lone FMV (LAT 1) -> presented 2 cycles after acceptance; IMUL (LAT 2) -> 3
    m = LaneModel(p)
    assert run_lane(m, {2: LaneOp(F.OP_FMV, 5, 0, 0, 0, 1)})[0][0] == 4
    m = LaneModel(p)
    assert run_lane(m, {2: LaneOp(F.OP_IMUL, 5, 2, 0, 0, 1)})[0][0] == 5


def test_lane_model_ready_and_backpressure():
    p = LaneParams(rob_depth=2)
    m = LaneModel(p)
    # init: not ready the first cycle after reset
    m.reset()
    assert m.outputs(1).in_ready == 0
    m.edge(1, 0, None, 0)
    assert m.outputs(2).in_ready == 1
    ops = [LaneOp(F.OP_FMV, i, 0, 0, 0, i) for i in range(3)]
    m.edge(2, 1, ops[0], 0)
    m.edge(3, 1, ops[1], 0)
    assert m.outputs(4).in_ready == 0 and m.occupancy == 2  # ROB full
    assert m.outputs(4).out_valid == 1 and m.outputs(4).out_result == 0
    m.edge(4, 1, ops[2], 1)  # not accepted (full), head retires
    assert m.occupancy == 1 and m.outputs(5).in_ready == 1
    ev = m.events(5, 1, 1, ops[2], 0)
    assert ev["pipe_stall"] == 0 and ev["accept"] == 1


def test_lane_model_events():
    m = LaneModel(LaneParams())
    m.edge(1, 0, None, 0)
    ev = m.events(2, 1, 0, LaneOp(F.OP_FMV, 1, 0, 0, 0, 0, en=False), 1)
    assert ev["masked"] == 1 and ev["accept"] == 0
    ev = m.events(2, 1, 1, LaneOp(0x0D, 1, 0, 0, 0, 0), 1)
    assert ev["accept"] == 1 and ev["illegal"] == 1
