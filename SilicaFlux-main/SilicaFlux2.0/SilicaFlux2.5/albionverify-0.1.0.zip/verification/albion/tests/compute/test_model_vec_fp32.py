"""Model unit tests for albionverify.models.vec_fp32 (no simulator).

Three independent oracles are used on top of hand-computed IEEE-754 examples:
  1. numpy float32 (host FPU, round-to-nearest-even) for add / sub / mul;
  2. a round-to-odd double-precision emulation (Boldo-Melquiond) for FMA / RNE -- numpy has no float32 fma;
  3. a property oracle built on Python Fractions that, for every rounding mode, finds the two representable
     neighbours of the EXACT real result by bisection over the binary32 encodings and applies the textbook
     rounding rule, including the overflow policy and the OF / UF / NX flags.  It shares no code with the model.
"""
import math
import random
import struct
from fractions import Fraction

import numpy as np
import pytest

from albionverify.models import vec_fp32 as F
from albionverify.models.vec_gen import b2f, f2b, operand_pair_for, rand_fp32, rm_for

M32 = 0xFFFFFFFF


def _enc(x):
    return f2b(float(x))


# ---------------------------------------------------------------------------------------------- hand-computed
def test_hand_add_basic():
    assert F.fadd(0x3F800000, 0x40000000, F.RNE) == (0x40400000, 0)  # 1 + 2 = 3
    assert F.fadd(0x3F800000, 0x3F800000, F.RNE) == (0x40000000, 0)
    # 0.1f + 0.2f = 0.3f (0x3E99999A + 0x3E4CCCCD -> 0x3E99999A? computed below with numpy as sanity)
    r, fl = F.fadd(f2b(0.1), f2b(0.2), F.RNE)
    assert r == int(np.float32(np.float32(0.1) + np.float32(0.2)).view(np.uint32)) and fl == F.NX


def test_hand_add_tie_to_even_and_modes():
    one = 0x3F800000
    half_ulp = 0x33800000  # 2^-24: exactly half an ulp of 1.0
    assert F.fadd(one, half_ulp, F.RNE) == (one, F.NX)  # tie -> even (1.0, mantissa 0 is even)
    assert F.fadd(one, half_ulp, F.RMM) == (0x3F800001, F.NX)  # ties away
    assert F.fadd(one, half_ulp, F.RUP) == (0x3F800001, F.NX)
    assert F.fadd(one, half_ulp, F.RDN) == (one, F.NX)
    assert F.fadd(one, half_ulp, F.RTZ) == (one, F.NX)
    # tie where the lsb is odd rounds up: (1+ulp) + half ulp
    odd = 0x3F800001
    assert F.fadd(odd, half_ulp, F.RNE) == (0x3F800002, F.NX)
    # just above half an ulp rounds up in RNE: 1 + (half ulp + smallest subnormal-ish step 2^-48)
    assert F.fadd(one, 0x33800001, F.RNE) == (0x3F800001, F.NX)
    # negative: RDN rounds away from zero, RUP toward zero
    assert F.fadd(0xBF800000, 0xB3800000, F.RDN) == (0xBF800001, F.NX)
    assert F.fadd(0xBF800000, 0xB3800000, F.RUP) == (0xBF800000, F.NX)


def test_hand_zero_sign_rules():
    pz, nz = 0x00000000, 0x80000000
    assert F.fadd(pz, pz, F.RNE) == (pz, 0)
    assert F.fadd(nz, nz, F.RNE) == (nz, 0)
    assert F.fadd(nz, nz, F.RDN) == (nz, 0)
    assert F.fadd(pz, nz, F.RNE) == (pz, 0)
    assert F.fadd(pz, nz, F.RDN) == (nz, 0)  # only round-down gives -0
    assert F.fadd(0x3F800000, 0xBF800000, F.RNE) == (pz, 0)  # x + (-x) = +0
    assert F.fadd(0x3F800000, 0xBF800000, F.RDN) == (nz, 0)
    assert F.fadd(0x3F800000, 0x3F800000, F.RDN, sub=True) == (nz, 0)  # x - x
    assert F.fadd(nz, pz, F.RNE, sub=True) == (nz, 0)  # -0 - (+0) = -0 + -0 = -0
    assert F.fmul(nz, 0x3F800000, F.RNE) == (nz, 0)
    assert F.fmul(nz, nz, F.RNE) == (pz, 0)
    # a tiny negative product that underflows to zero keeps its sign and raises UF|NX
    assert F.fmul(0x80000001, 0x3F000000, F.RNE) == (nz, F.UF | F.NX)


def test_hand_overflow_underflow():
    maxn = 0x7F7FFFFF
    assert F.fmul(maxn, 0x40000000, F.RNE) == (0x7F800000, F.OF | F.NX)
    assert F.fmul(maxn, 0x40000000, F.RTZ) == (maxn, F.OF | F.NX)
    assert F.fmul(maxn, 0x40000000, F.RDN) == (maxn, F.OF | F.NX)
    assert F.fmul(maxn, 0x40000000, F.RUP) == (0x7F800000, F.OF | F.NX)
    assert F.fmul(maxn | 0x80000000, 0x40000000, F.RDN) == (0xFF800000, F.OF | F.NX)
    assert F.fmul(maxn | 0x80000000, 0x40000000, F.RUP) == (0xFFFFFFFF - 0x800000, F.OF | F.NX)
    assert F.fadd(maxn, maxn, F.RNE) == (0x7F800000, F.OF | F.NX)
    # exactly representable subnormal result: no UF (exact)
    assert F.fmul(0x00800000, 0x3F000000, F.RNE) == (0x00400000, 0)
    # inexact subnormal: UF|NX
    assert F.fmul(0x00000003, 0x3F000000, F.RNE) == (0x00000002, F.UF | F.NX)  # 1.5 -> tie -> 2 (even)
    # (1+2^-13)*((1-2^-13)*2^-126) = (1-2^-26)*2^-126: with a 24-bit significand and unbounded exponent this rounds
    # UP to 2^-126 (RNE) -> NOT tiny after rounding -> only NX, result = smallest normal
    a, b = 0x3F800400, 0x007FFC00
    assert F.fmul(a, b, F.RNE) == (0x00800000, F.NX)
    assert F.fmul(a, b, F.RUP) == (0x00800000, F.NX)
    # the same product rounded toward zero stays below 2^-126 -> tiny and inexact
    assert F.fmul(a, b, F.RTZ) == (0x007FFFFF, F.UF | F.NX)
    assert F.fmul(a, b, F.RDN) == (0x007FFFFF, F.UF | F.NX)
    # (1 - 2^-24)*2^-126 is exact with 24 bits (so tiny regardless of the rounding step) and inexact on the
    # subnormal grid: UF|NX even though RNE then rounds it up to the smallest normal
    assert F.fmul(0x00800000, 0x3F7FFFFF, F.RNE) == (0x00800000, F.UF | F.NX)


def test_hand_special_values():
    inf, ninf, qn, sn = 0x7F800000, 0xFF800000, 0x7FC00000, 0x7FA00000
    assert F.fadd(inf, ninf, F.RNE) == (qn, F.NV)
    assert F.fadd(inf, inf, F.RNE) == (inf, 0)
    assert F.fadd(inf, 0x3F800000, F.RNE) == (inf, 0)
    assert F.fadd(ninf, 0x3F800000, F.RNE) == (ninf, 0)
    assert F.fadd(inf, inf, F.RNE, sub=True) == (qn, F.NV)
    assert F.fadd(qn | 0x1234, 0x3F800000, F.RNE) == (qn, 0)  # payload not propagated
    assert F.fadd(sn, 0x3F800000, F.RNE) == (qn, F.NV)
    assert F.fmul(inf, 0, F.RNE) == (qn, F.NV)
    assert F.fmul(0x80000000, ninf, F.RNE) == (qn, F.NV)
    assert F.fmul(inf, 0xC0000000, F.RNE) == (ninf, 0)
    assert F.fmul(qn, 0, F.RNE) == (qn, 0)
    # FMA: inf*0 + qNaN raises NV (RISC-V), inf*1 + (-inf) is NV, inf*1 + inf is inf
    assert F.fma(inf, 0, qn, F.RNE) == (qn, F.NV)
    assert F.fma(inf, 0x3F800000, ninf, F.RNE) == (qn, F.NV)
    assert F.fma(inf, 0x3F800000, inf, F.RNE) == (inf, 0)
    assert F.fma(0x3F800000, 0x3F800000, qn, F.RNE) == (qn, 0)
    assert F.fma(0x3F800000, 0x3F800000, sn, F.RNE) == (qn, F.NV)
    assert F.fma(0x3F800000, 0x40000000, inf, F.RNE) == (inf, 0)


def test_hand_fma_single_rounding():
    # (1+2^-23)*(1-2^-24) = 1 + 2^-24 - 2^-47 exactly (just below the tie): mul alone rounds to 1.0, while
    # fma(.., -1) keeps the exact residual 2^-24 - 2^-47 = (2^23 - 1) * 2^-47 = 0x337FFFFE (23 significant bits)
    a, b = 0x3F800001, 0x3F7FFFFF
    prod, _ = F.fmul(a, b, F.RNE)
    assert prod == 0x3F800000
    r, fl = F.fma(a, b, 0xBF800000, F.RNE)
    assert (r, fl) == (0x337FFFFE, 0)  # exact: no rounding
    assert F.fadd(prod, 0xBF800000, F.RNE) == (0, 0)  # double rounding loses it entirely
    # FMSUB / FNMSUB / FNMADD sign conventions
    two, three, five = 0x40000000, 0x40400000, 0x40A00000
    assert F.exec_op(F.OP_FMADD, two, three, five, 0)[0] == f2b(11.0)
    assert F.exec_op(F.OP_FMSUB, two, three, five, 0)[0] == f2b(1.0)
    assert F.exec_op(F.OP_FNMSUB, two, three, five, 0)[0] == f2b(-1.0)
    assert F.exec_op(F.OP_FNMADD, two, three, five, 0)[0] == f2b(-11.0)
    # exact cancellation in FMA: +0 (RDN -0)
    assert F.fma(two, three, f2b(-6.0), F.RNE) == (0, 0)
    assert F.fma(two, three, f2b(-6.0), F.RDN) == (0x80000000, 0)
    # product zero, addend nonzero -> addend exactly, no flags
    assert F.fma(0, 0x3F800000, 0x00000001, F.RNE) == (1, 0)
    # (-0) * 1 + (-0) = -0 ; (-0)*1 + (+0) = +0
    assert F.fma(0x80000000, 0x3F800000, 0x80000000, F.RNE) == (0x80000000, 0)
    assert F.fma(0x80000000, 0x3F800000, 0, F.RNE) == (0, 0)
    assert F.fma(0x80000000, 0x3F800000, 0, F.RDN) == (0x80000000, 0)


def test_hand_compare_and_minmax():
    pz, nz, one, qn, sn = 0, 0x80000000, 0x3F800000, 0x7FC00000, 0x7FA00000
    assert F.fmin(pz, nz) == (nz, 0)
    assert F.fmin(nz, pz) == (nz, 0)
    assert F.fmin(pz, nz, want_max=True) == (pz, 0)
    assert F.fmin(nz, pz, want_max=True) == (pz, 0)
    assert F.fmin(one, qn) == (one, 0)  # NaN loses, other operand returned bit-exactly
    assert F.fmin(qn | 5, one, want_max=True) == (one, 0)
    assert F.fmin(qn | 5, qn | 6) == (qn, 0)  # both NaN -> canonical
    assert F.fmin(sn, one) == (one, F.NV)
    assert F.fmin(sn, 0x7FC00001, want_max=True) == (qn, F.NV)
    assert F.feq(pz, nz) == (1, 0)
    assert F.feq(qn, qn) == (0, 0)  # quiet compare: no NV for qNaN
    assert F.feq(sn, one) == (0, F.NV)
    assert F.flt(pz, nz) == (0, 0)
    assert F.flt(nz, pz) == (0, 0)  # -0 == +0 numerically
    assert F.flt(one, qn) == (0, F.NV)  # signalling: NV for any NaN
    assert F.fle(pz, nz) == (1, 0)
    assert F.fle(qn, one) == (0, F.NV)
    assert F.flt(0xBF800000, one) == (1, 0)
    assert F.flt(0xFF800000, 0xBF800000) == (1, 0)
    assert F.flt(0x7F800000, 0x7F7FFFFF) == (0, 0)
    assert F.fle(one, one) == (1, 0)


def test_int_ops_and_legality():
    assert F.exec_op(F.OP_IADD, 0xFFFFFFFF, 2, 0, 7) == (1, 0, False)  # rm ignored for non-rounding ops
    assert F.exec_op(F.OP_IMUL, 0xFFFFFFFF, 0xFFFFFFFF, 0, 0) == (1, 0, False)
    assert F.exec_op(F.OP_IMUL, 0x10000, 0x10000, 0, 0) == (0, 0, False)
    assert F.exec_op(F.OP_IMUL, 0x80000000, 2, 0, 0) == (0, 0, False)
    assert F.exec_op(F.OP_FADD, 0, 0, 0, 5) == (0, 0, True)  # rm 5..7 illegal for rounding ops
    assert F.exec_op(F.OP_FMV, 0x7FA00001, 0, 0, 7) == (0x7FA00001, 0, False)  # FMV: NaN payload preserved, no NV
    for op in (0x0D, 0x0E, 0x0F, 0x12, 0x1F, 0x13, 0x08 | 0x20 & 0x1F):
        if op in F.ALL_LEGAL_OPS:
            continue
        assert F.exec_op(op, 1, 2, 3, 0) == (0, 0, True)
    assert F.exec_op(F.OP_FEQ, 1, 1, 0, 0, en_fcmp=False) == (0, 0, True)
    assert F.exec_op(F.OP_IADD, 1, 1, 0, 0, en_int=False) == (0, 0, True)
    assert F.exec_op(F.OP_FADD, 0x3F800000, 0x3F800000, 0, 0, en_fcmp=False, en_int=False)[2] is False


# ---------------------------------------------------------------------------------------------- numpy oracle
def _np_bits(x):
    return int(np.float32(x).view(np.uint32))


def _np_add(a, b):
    with np.errstate(all="ignore"):
        return _np_bits(np.uint32(a).view(np.float32) + np.uint32(b).view(np.float32))


def _np_mul(a, b):
    with np.errstate(all="ignore"):
        return _np_bits(np.uint32(a).view(np.float32) * np.uint32(b).view(np.float32))


def _canon(r):
    return F.QNAN if F.is_nan(r) else r


def test_numpy_add_mul_random_rne():
    rng = random.Random(1234)
    n = 0
    for i in range(30000):
        op = rng.choice([F.OP_FADD, F.OP_FSUB, F.OP_FMUL])
        a, b, _ = operand_pair_for(rng, op)
        if op == F.OP_FMUL:
            ref, got = _np_mul(a, b), F.fmul(a, b, F.RNE)[0]
        elif op == F.OP_FADD:
            ref, got = _np_add(a, b), F.fadd(a, b, F.RNE)[0]
        else:
            ref, got = _np_add(a, b ^ 0x80000000), F.fadd(a, b, F.RNE, sub=True)[0]
        assert got == _canon(ref), "%s a=%08x b=%08x model=%08x numpy=%08x" % (F.OP_NAMES[op], a, b, got, ref)
        n += 1
    assert n == 30000


def test_numpy_flags_nv_of():
    """numpy's own floating point status (invalid / overflow) agrees with the model on OF / NV (UF is not compared:
    x86 detects tininess BEFORE rounding, the lane documents tininess AFTER rounding)."""
    rng = random.Random(99)
    for _ in range(6000):
        a, b, _ = operand_pair_for(rng, F.OP_FMUL)
        x, y = np.uint32(a).view(np.float32), np.uint32(b).view(np.float32)
        with np.errstate(all="raise"):
            of = nv = False
            try:
                _ = x * y
            except FloatingPointError as e:
                of, nv = "overflow" in str(e), "invalid" in str(e)
        _, fl = F.fmul(a, b, F.RNE)
        assert bool(fl & F.NV) == nv or (F.is_snan(a) or F.is_snan(b)), hex(a) + hex(b)
        assert bool(fl & F.OF) == of, "a=%08x b=%08x flags=%x" % (a, b, fl)


# ---------------------------------------------------------------------------------------------- round-to-odd FMA oracle
def _two_sum(a, b):
    s = a + b
    bb = s - a
    return s, (a - (s - bb)) + (b - bb)


def _fma_rne_via_round_to_odd(a, b, c):
    """RNE binary32 fma for finite inputs via round-to-odd in binary64 (Boldo-Melquiond): the product of two
    binary32 values is exact in binary64, TwoSum gives the exact rounding error of the sum, round-to-odd
    makes the final binary64 -> binary32 conversion free of double-rounding."""
    x, y, z = float(np.uint32(a).view(np.float32)), float(np.uint32(b).view(np.float32)), float(np.uint32(c).view(np.float32))
    p = x * y  # exact (48 bits)
    s, e = _two_sum(p, z)
    if e != 0.0:
        m = struct.unpack("<Q", struct.pack("<d", s))[0]
        if not (m & 1):  # make the double odd, toward the side of the error
            s = math.nextafter(s, math.inf if e > 0 else -math.inf)
    with np.errstate(all="ignore"):
        return _np_bits(np.float32(s))


def test_fma_rne_vs_round_to_odd_oracle():
    rng = random.Random(777)
    for i in range(30000):
        op = rng.choice(list(F.FMA_OPS))
        a, b, c = operand_pair_for(rng, op)
        if any(F.is_nan(v) or F.is_inf(v) for v in (a, b, c)):
            continue
        got, _ = F.fma(a, b, c, F.RNE)
        want = _fma_rne_via_round_to_odd(a, b, c)
        if want == 0 or want == 0x80000000:  # zero sign rules are checked by the property oracle / hand tests
            assert F.is_zero(got)
            continue
        assert got == want, "a=%08x b=%08x c=%08x model=%08x oracle=%08x" % (a, b, c, got, want)


# ---------------------------------------------------------------------------------------------- property (Fraction) oracle
def _frac(x):
    """Exact value of a finite binary32 encoding as a Fraction (independent of the model's decode)."""
    s = -1 if x >> 31 else 1
    e = (x >> 23) & 0xFF
    f = x & 0x7FFFFF
    if e == 0:
        return s * Fraction(f, 1 << 149)
    return s * Fraction(f + (1 << 23)) * (Fraction(2) ** (e - 150))


_POS_MAX = 0x7F7FFFFF
_TWO128 = Fraction(2) ** 128
_VAL = {}


def _pos_val(enc):
    v = _VAL.get(enc)
    if v is None:
        v = _VAL[enc] = _frac(enc)
    return v


def _floor_enc(v):
    """Largest positive finite encoding with value <= v (v >= 0, v < 2^128) by bisection."""
    lo, hi = 0, _POS_MAX
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if _pos_val(mid) <= v:
            lo = mid
        else:
            hi = mid - 1
    return lo


def _prec24_round(v, rm_pos):
    """Round positive v to a 24-bit significand with unbounded exponent range (for tininess after rounding)."""
    n, d = v.numerator, v.denominator
    E = n.bit_length() - d.bit_length()
    if Fraction(2) ** E > v:
        E -= 1
    q = Fraction(2) ** (E - 23)
    fl = math.floor(v / q)
    rem = v - fl * q
    return fl, rem, q


def oracle_round(v, rm, zero_sign=0):
    """Round the exact real v to binary32 with the textbook rules. Returns (bits, flags)."""
    if v == 0:
        return zero_sign << 31, 0
    sign = 1 if v < 0 else 0
    a = -v if sign else v
    if a >= _TWO128:
        lo, over = _POS_MAX, True
        hi_val = _TWO128
    else:
        lo = _floor_enc(a)
        over = False
    lo_val = _pos_val(lo)
    exact = lo_val == a and not over
    if exact:
        return (sign << 31) | lo, 0
    hi_val = _pos_val(lo + 1) if lo < _POS_MAX else _TWO128
    # choose magnitude: lo or hi (hi may be 2^128 == overflow)
    if rm == F.RTZ:
        pick_hi = False
    elif rm == F.RDN:
        pick_hi = bool(sign)
    elif rm == F.RUP:
        pick_hi = not sign
    else:
        d_lo, d_hi = a - lo_val, hi_val - a
        if d_lo != d_hi:
            pick_hi = d_hi < d_lo
        elif rm == F.RMM:
            pick_hi = True
        else:  # tie to even: the even encoding wins; 2^128 counts as even (its would-be mantissa is zero)
            pick_hi = (lo & 1) == 1
    if pick_hi and hi_val == _TWO128:
        to_inf = {F.RNE: True, F.RMM: True, F.RTZ: False, F.RDN: bool(sign), F.RUP: not sign}[rm]
        return (sign << 31) | (0x7F800000 if to_inf else _POS_MAX), F.OF | F.NX
    if not pick_hi and over:  # directed rounding below 2^128 but above max: stays max with OF
        return (sign << 31) | _POS_MAX, F.OF | F.NX
    enc = lo + 1 if pick_hi else lo
    flags = F.NX
    if a < Fraction(1, 1 << 126):  # candidate for tininess: check after rounding to 24 bits, unbounded exponent
        fl, rem, q = _prec24_round(a, rm)
        if rem == 0:
            up = False
        elif rm == F.RTZ:
            up = False
        elif rm == F.RDN:
            up = bool(sign)
        elif rm == F.RUP:
            up = not sign
        else:
            up = rem > q / 2 or (rem == q / 2 and (rm == F.RMM or (fl & 1)))
        r24 = (fl + (1 if up else 0)) * q
        if r24 < Fraction(1, 1 << 126):
            flags |= F.UF
    return (sign << 31) | enc, flags


def _zero_sign(rm, terms_signs_all_zero_same, sgn):
    if terms_signs_all_zero_same:
        return sgn
    return 1 if rm == F.RDN else 0


def _fin(x):
    return not (F.is_nan(x) or F.is_inf(x))


@pytest.mark.parametrize("rm", [0, 1, 2, 3, 4])
def test_property_oracle_add_mul_fma_all_modes(rm):
    rng = random.Random(4242 + rm)
    checked = 0
    for i in range(7000):
        op = rng.choice([F.OP_FADD, F.OP_FSUB, F.OP_FMUL, F.OP_FMADD, F.OP_FMSUB, F.OP_FNMSUB, F.OP_FNMADD])
        a, b, c = operand_pair_for(rng, op)
        if not (_fin(a) and _fin(b) and _fin(c)):
            continue
        got, gfl, _ = F.exec_op(op, a, b, c, rm)
        fa, fb, fc = _frac(a), _frac(b), _frac(c)
        sa, sb, sc = a >> 31, b >> 31, c >> 31
        if op == F.OP_FADD:
            v, zs = fa + fb, (sa if (sa == sb and a & 0x7FFFFFFF == 0 and b & 0x7FFFFFFF == 0) else None)
        elif op == F.OP_FSUB:
            v, zs = fa - fb, (sa if (sa != sb and a & 0x7FFFFFFF == 0 and b & 0x7FFFFFFF == 0) else None)
        elif op == F.OP_FMUL:
            v, zs = fa * fb, (sa ^ sb)
            if v != 0:
                zs = None
        else:
            npd = op in (F.OP_FNMSUB, F.OP_FNMADD)
            nad = op in (F.OP_FMSUB, F.OP_FNMADD)
            prod = fa * fb * (-1 if npd else 1)
            add = fc * (-1 if nad else 1)
            v = prod + add
            psign = (sa ^ sb ^ npd)
            asign = (sc ^ nad)
            pzero = (a & 0x7FFFFFFF == 0) or (b & 0x7FFFFFFF == 0)
            azero = c & 0x7FFFFFFF == 0
            zs = psign if (pzero and azero and psign == asign) else None
        if v == 0:
            if op == F.OP_FMUL:
                want = ((sa ^ sb) << 31, 0)
            elif zs is not None:
                want = (zs << 31, 0)
            else:
                want = ((1 << 31) if rm == F.RDN else 0, 0)
        else:
            want = oracle_round(v, rm)
        assert (got, gfl) == want, "%s rm=%d a=%08x b=%08x c=%08x model=(%08x,%x) oracle=(%08x,%x)" % (F.OP_NAMES[op], rm, a, b, c, got, gfl, want[0], want[1])
        checked += 1
    assert checked > 5000


def test_directed_rounding_ordering_property():
    """For any finite sum, RDN <= RTZ-magnitude-wise... : the four directed results bracket the exact value and
    RNE / RMM are one of the two neighbours."""
    rng = random.Random(5)
    for _ in range(3000):
        a, b, _ = operand_pair_for(rng, F.OP_FADD)
        if not (_fin(a) and _fin(b)):
            continue
        rd, _ = F.fadd(a, b, F.RDN)
        ru, _ = F.fadd(a, b, F.RUP)
        rz, _ = F.fadd(a, b, F.RTZ)
        rn, _ = F.fadd(a, b, F.RNE)
        if not (_fin(rd) and _fin(ru)):
            continue
        vd, vu = _frac(rd), _frac(ru)
        exact = _frac(a) + _frac(b)
        assert vd <= exact <= vu
        assert rn in (rd, ru) or (F.is_zero(rn) and F.is_zero(rd) and F.is_zero(ru)) or vd == vu
        if exact >= 0:
            assert F.is_zero(rz) or rz == rd or vd == vu
        else:
            assert F.is_zero(rz) or rz == ru or vd == vu


def test_flags_never_dz_and_rm_error():
    rng = random.Random(8)
    for _ in range(4000):
        op = rng.choice(list(F.ALL_LEGAL_OPS))
        a, b, c = operand_pair_for(rng, op)
        r, fl, ill = F.exec_op(op, a, b, c, rm_for(rng))
        assert not (fl & F.DZ) and not ill and 0 <= r <= M32
    with pytest.raises(ValueError):
        F.fadd(0, 0, 5)
