"""Cycle-based agents for the tensor systolic array (tensor_systolic_array) bench.

  CfgDriver     cfg_valid / cfg_m / cfg_n / cfg_k: ``hold`` items stay presented until the handshake, ``pulse`` items are
                presented for a fixed number of cycles regardless of cfg_ready (illegal / ignored-while-busy forms)
  SliceDriver   s_valid / s_a / s_b: streams the k-slices of the tile that was launched; stalls (valid gaps) from a
                Throttle; optional spurious (garbage) valid outside RUN
  StallDriver   stall_i patterns, including model-aware ones (fill, last slice, the all_done cycle, drain)
  MReadySink    m_ready from a Throttle
  TenMonitor    lock-step checker against TileModel (every output, every cycle, incl. perf counters), per-row result
                check against the model's accumulation of the ACCEPTED slices and, at tile end, against an independent
                GEMM of the intended operands; protocol: payload held while m_valid && !m_ready; reset handling.
"""
from __future__ import annotations

import random
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, List, Optional

from albionverify.core import Agent, Env
from albionverify.coverage import CoverGroup
from albionverify.models.ten_matmul import CLEAR, DRAIN, IDLE, READOUT, RUN, TenParams, TileModel, cfg_legal, matmul, to_signed, to_unsigned
from albionverify.rng import Throttle
from albionverify.scoreboard import Scoreboard


@dataclass
class TileJob:
    m: int
    n: int
    k: int
    A: List[List[int]]  # ROWS x K (rows >= m are garbage / ignored)
    B: List[List[int]]  # K x COLS
    kind: str = "random"


@dataclass
class CfgItem:
    m: int
    n: int
    k: int
    job: Optional[TileJob] = None
    mode: str = "hold"  # hold | pulse
    pulses: int = 1


class CfgDriver(Agent):
    def __init__(self, name: str, env: Env, rng: random.Random, p: TenParams, throttle: str = "always"):
        super().__init__(name)
        s = env.sig
        self.sg = dict(valid=s("cfg_valid"), ready=s("cfg_ready"), m=s("cfg_m"), n=s("cfg_n"), k=s("cfg_k"))
        self.rng, self.p = rng, p
        self.thr = Throttle(rng, throttle)
        self.queue: Deque[CfgItem] = deque()
        self.cur: Optional[CfgItem] = None
        self._left = 0
        self._v = False
        self.hs_item: Optional[CfgItem] = None  # item handshaken at the sample just processed (valid & ready)
        self.n_hs = 0

    def submit(self, it: CfgItem) -> None:
        self.queue.append(it)

    @property
    def idle(self) -> bool:
        return self.cur is None and not self.queue

    def sample(self) -> None:
        self.hs_item = None
        if self._v and not self.env.in_reset:
            it = self.cur
            if it.mode == "hold":
                if self.sg["ready"].read():
                    self.hs_item = it
                    self.cur = None
                    self.n_hs += 1
            else:
                if self.sg["ready"].read():
                    self.hs_item = it  # the model decides whether this is legal (launch) or rejected
                self._left -= 1
                if self._left <= 0:
                    self.cur = None

    def drive(self) -> None:
        g, r = self.sg, self.rng
        if self.env.in_reset:
            self._v = False
            g["valid"].write(r.getrandbits(1))  # synchronous reset has priority: a cfg offered in reset must be ignored
            g["m"].write(r.getrandbits(8))
            g["n"].write(r.getrandbits(8))
            g["k"].write(r.getrandbits(self.p.k_w))
            return
        if self.cur is None and self.queue and self.thr.allow():
            self.cur = self.queue.popleft()
            self._left = self.cur.pulses
        if self.cur is not None:
            c = self.cur
            g["valid"].write(1)
            g["m"].write(c.m)
            g["n"].write(c.n)
            g["k"].write(c.k)
            self._v = True
        else:
            g["valid"].write(0)
            g["m"].write(r.getrandbits(8))
            g["n"].write(r.getrandbits(8))
            g["k"].write(r.getrandbits(self.p.k_w))
            self._v = False

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            self.cur = None
            self.queue.clear()
            self._v = False
            self.hs_item = None


class SliceDriver(Agent):
    def __init__(self, name: str, env: Env, rng: random.Random, p: TenParams, throttle: str = "always", ghost: float = 0.0):
        super().__init__(name)
        s = env.sig
        self.sg = dict(valid=s("s_valid"), ready=s("s_ready"), a=s("s_a"), b=s("s_b"))
        self.rng, self.p = rng, p
        self.thr = Throttle(rng, throttle)
        self.ghost = ghost
        self.job: Optional[TileJob] = None
        self.k = 0  # next slice index to present
        self._v = False
        self.pending: Deque[TileJob] = deque()  # launched tiles waiting for their stream (back-to-back launches)
        self.n_slices = 0

    def launch(self, job: TileJob) -> None:
        if self.job is None:
            self.job, self.k = job, 0
        else:
            self.pending.append(job)

    def sample(self) -> None:
        if self._v and not self.env.in_reset and self.job is not None and self.sg["ready"].read():
            self.k += 1
            self.n_slices += 1
            if self.k >= self.job.k:
                self.job = self.pending.popleft() if self.pending else None
                self.k = 0

    def _pack(self, vals: List[int], dw: int) -> int:
        v = 0
        for i, x in enumerate(vals):
            v |= to_unsigned(x, dw) << (i * dw)
        return v

    def drive(self) -> None:
        g, r, p = self.sg, self.rng, self.p
        if self.env.in_reset:
            self._v = False
            g["a"].write(r.getrandbits(p.rows * p.dw))
            g["b"].write(r.getrandbits(p.cols * p.dw))
            g["valid"].write(r.getrandbits(1))  # ignored during reset
            return
        if self.job is not None and self.thr.allow():
            j = self.job
            a = [j.A[i][self.k] for i in range(p.rows)]
            b = [j.B[self.k][c] for c in range(p.cols)]
            g["valid"].write(1)
            g["a"].write(self._pack(a, p.dw))
            g["b"].write(self._pack(b, p.dw))
            self._v = True
            return
        # nothing to present (or throttled): garbage payload, occasionally a spurious valid that the DUT must ignore
        # while it is not in RUN (or whose slice it would accept only when s_ready -- never presented in RUN here)
        self._v = False
        g["a"].write(r.getrandbits(p.rows * p.dw))
        g["b"].write(r.getrandbits(p.cols * p.dw))
        g["valid"].write(1 if (self.job is None and self.ghost and r.random() < self.ghost and self._ghost_ok()) else 0)

    def _ghost_ok(self) -> bool:
        return True

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            self.job = None
            self.pending.clear()
            self.k = 0
            self._v = False


class StallDriver(Agent):
    """stall_i.  Modes: none | random:p | bursty:lo-hi | pattern:0101 | always | fill | drain | lastslice | done_cycle | edges."""

    def __init__(self, name: str, env: Env, rng: random.Random, mode: str = "none"):
        super().__init__(name)
        self.sig = env.sig("stall_i")
        self.rng = rng
        self.model: Optional[TileModel] = None  # set by the bench: model-aware modes read the state for the NEXT interval
        self.thr: Optional[Throttle] = None
        self.set_mode(mode)

    def set_mode(self, mode: str) -> None:
        self.mode = mode
        kind, _, arg = mode.partition(":")
        self.kind = kind
        if kind == "random":
            self.thr = Throttle(self.rng, "random:%s" % (1.0 - float(arg)))  # allow(=no stall) with prob 1-p
        elif kind == "bursty":
            self.thr = Throttle(self.rng, mode)
        elif kind == "pattern":
            self.thr = Throttle(self.rng, "pattern:" + "".join("0" if c == "1" else "1" for c in arg))
        else:
            self.thr = None

    def drive(self) -> None:
        k, m = self.kind, self.model
        if k == "none":
            v = 0
        elif k == "always":
            v = 1
        elif k in ("random", "bursty", "pattern"):
            v = 0 if self.thr.allow() else 1
        elif m is None:
            v = 0
        elif k == "fill":  # stall in the first cycles after the launch and during RUN's first slices
            v = int(m.state in (CLEAR, RUN) and m.ens < 3 and self.rng.random() < 0.7)
        elif k == "drain":
            v = int(m.state == DRAIN and self.rng.random() < 0.6)
        elif k == "lastslice":
            v = int(m.state == RUN and m.k_cnt >= m.k - 2 and self.rng.random() < 0.6)
        elif k == "done_cycle":  # stall exactly in the DRAIN cycle in which all_done is already true (delays nothing)
            v = int(m._all_done())
        elif k == "edges":  # always stalled where it is ignored; probabilistic (never a livelock) where it has effect
            hit = (m.state == DRAIN and (m._all_done() or m.drain_done == 0)) or (m.state == RUN and m.k_cnt in (0, m.k - 1))
            v = int(m.state in (IDLE, CLEAR, READOUT) or m._all_done() or (hit and self.rng.random() < 0.6))
        else:
            raise ValueError(self.mode)
        self.sig.write(v)


class MReadySink(Agent):
    def __init__(self, name: str, env: Env, rng: random.Random, throttle: str = "always"):
        super().__init__(name)
        self.sig = env.sig("m_ready")
        self.thr = Throttle(rng, throttle)

    def set_mode(self, spec: str) -> None:
        self.thr.set_mode(spec)

    def drive(self) -> None:
        self.sig.write(1 if self.thr.allow() else 0)


PERF = ["busy", "issue", "stall_up", "stall_ext", "mac", "pad"]


class TenMonitor(Agent):
    def __init__(self, name: str, env: Env, p: TenParams, *, perf_en: bool = True, check_align: bool = True):
        super().__init__(name)
        s = env.sig
        self.p, self.perf_en = p, perf_en
        self.i = {k: s(k) for k in ("cfg_valid", "cfg_m", "cfg_n", "cfg_k", "s_valid", "s_a", "s_b", "stall_i", "m_ready")}
        self.o = {k: s(k) for k in ("cfg_ready", "cfg_reject", "s_ready", "s_k", "m_valid", "m_row", "m_data", "m_col_mask", "m_last", "busy", "tile_done", "align_err")}
        self.perf = {k: s("perf_" + k) for k in PERF}
        self.model = TileModel(p)
        self.sb = Scoreboard(env, name)
        self.cfg_drv: Optional[CfgDriver] = None
        self.slice_drv: Optional[SliceDriver] = None
        self.cur_job: Optional[TileJob] = None
        self.rows_seen: List[List[int]] = []
        self.prev_m = None
        self.checks = 0
        self.seq = 0
        self.t_launch: Optional[int] = None
        self.t_done: Optional[int] = None
        self.tiles: List[dict] = []
        self.n_reject = 0
        self.n_ignored = 0
        self.prev_cfg = None
        self.stall_run = self.gap_run = self.mready_run = 0
        self.wrapped_tiles = 0
        self.t_tile_end: Optional[int] = None
        self.cfg_wait = 0
        self.log: Deque[str] = deque(maxlen=8)
        self._init_cov()

    # ---------------------------------------------------------------------------------------- coverage
    def _init_cov(self) -> None:
        """Coverage bins are configuration-aware: bins that cannot exist for this array (e.g. 'mid' rows of a 2-row array, M > ROWS
        encodings when cfg_m has no spare code, an ACC_WIDTH whose first wrapping K is out of reach) are not defined, so a hole
        always means 'reachable but not exercised'."""
        p = self.p
        cs = CoverGroup("ten_shape", "tile shape classes")
        mb = {"1": 1}
        if p.rows > 2:
            mb["mid"] = lambda v: 1 < v < p.rows
        if p.rows > 1:
            mb["rows"] = lambda v: v == p.rows
        nb = {"1": 1}
        if p.cols > 2:
            nb["mid"] = lambda v: 1 < v < p.cols
        if p.cols > 1:
            nb["cols"] = lambda v: v == p.cols
        cs.point("m", mb)
        cs.point("n", nb)
        kb = {}
        if p.k_max <= 2000:
            kb["kmax"] = lambda v: v == p.k_max and v > 3
        kb.update({"1": 1, "2-3": (2, 3)})
        if p.rows + p.cols - 1 > 4:
            kb["lt_fill"] = lambda v: 3 < v < p.rows + p.cols - 1
        kb["ge_fill"] = lambda v: v >= max(4, p.rows + p.cols - 1) and v < 64
        if p.k_max >= 64:
            kb["long64+"] = (64, 1 << 30)
        cs.point("k", kb)
        pb = {"full": lambda v: v == 0}
        if p.rows > 1:
            pb["partial_m"] = lambda v: v == 1
        if p.cols > 1:
            pb["partial_n"] = lambda v: v == 2
        if p.rows > 1 and p.cols > 1:
            pb["partial_mn"] = lambda v: v == 3
        cs.point("partial", pb)
        cs.cross("m_x_n", ["m", "n"])
        cs.cross("k_x_partial", ["k", "partial"], ignore=lambda b: b[0] == "kmax" and b[1] != "full")  # K_max is only run on full tiles (and shapes below)
        self.cg_shape = cs
        cv = CoverGroup("ten_values", "operand / result value classes")
        kinds = ["random", "zeros", "ones", "identity", "extreme_neg", "extreme_mix", "alt_sign", "max_pos", "min_x_max"]
        first_wrap_k = -(-(1 << (p.acc - 1)) // (1 << (2 * p.dw - 2)))
        can_wrap = first_wrap_k <= min(p.k_max, 1100)
        if can_wrap:
            kinds.append("wrap")
        cv.point("kind", kinds)
        cv.point("c_sign", ["neg", "zero", "pos", "mixed"])
        cv.point("acc_wrap", ["no_wrap", "wrapped"] if can_wrap else ["no_wrap"])
        self.cg_val = cv
        cc = CoverGroup("ten_config", "cfg handshake situations")
        cfgs = ["legal", "k0", "while_busy_ignored", "back_to_back_launch", "reject_pulse", "hold_until_idle", "m0", "n0"]
        if (1 << p.m_w) - 1 > p.rows:
            cfgs.append("m_gt_rows")
        if (1 << p.n_w) - 1 > p.cols:
            cfgs.append("n_gt_cols")
        cc.point("cfg", cfgs)
        sc = ["same", "k_changed", "mn_changed"]  # mn_changed = any two of (M, N, K) changed
        if p.rows > 1:
            sc.append("m_changed")
        if p.cols > 1:
            sc.append("n_changed")
        if p.rows > 1 and p.cols > 1:
            sc.append("all_changed")
        cc.point("shape_change", sc)
        cc.point("prev_shape", ["full", "partial"])
        self.cg_cfg = cc
        ct = CoverGroup("ten_pressure", "stall / gap / backpressure")
        ct.point("stall_run", {"1": 1, "2-3": (2, 3), "4-7": (4, 7), "8+": (8, 100000)})
        ct.point("gap_run", {"1": 1, "2-3": (2, 3), "4-7": (4, 7), "8+": (8, 100000)})
        ct.point("m_ready_low_run", {"1": 1, "2-3": (2, 3), "4-7": (4, 7), "8+": (8, 100000)})
        ct.point("stall_state", ["RUN_first_slice", "RUN_mid", "RUN_last_slice", "RUN_valid_gap", "DRAIN_early", "DRAIN_all_done_cycle", "DRAIN_late", "IDLE_ignored", "CLEAR_ignored", "READOUT_ignored"])
        ct.point("ghost_valid", ["ignored_outside_run"])
        self.cg_press = ct
        cr = CoverGroup("ten_reset", "state when reset hit")
        cr.point("state", [IDLE, CLEAR, RUN, DRAIN, READOUT] + (["READOUT_midrows"] if p.rows > 1 else []))
        self.cg_rst = cr
        cp = CoverGroup("ten_perf", "performance counter situations")
        cp.point("event", ["stall_up_nonzero", "stall_ext_nonzero", "both", "none", "m_ready_gap_in_readout"] + (["mul_pipe_tile"] if p.mul_pipe else []))
        self.cg_perf = cp

    def attach(self, env: Env) -> None:
        super().attach(env)
        for g in (self.cg_shape, self.cg_val, self.cg_cfg, self.cg_press, self.cg_rst, self.cg_perf):
            env.coverage.append(g)

    # ---------------------------------------------------------------------------------------- checks
    def _eq(self, what: str, exp, got) -> None:
        self.checks += 1
        if exp != got:
            self.env.error("%s: %s mismatch: expected 0x%x got 0x%x (model state %s, tile %s) | %s" % (self.name, what, exp, got, self.model.state,
                           (self.model.m, self.model.n, self.model.k), " ; ".join(self.log)))

    def _expect(self, cond: bool, msg: str) -> None:
        self.checks += 1
        if not cond:
            self.env.error("%s: %s | %s" % (self.name, msg, " ; ".join(self.log)))

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            m = self.model
            if self.env.cycle > 8:
                st = m.state
                if st == READOUT:
                    st = "READOUT_midrows" if m.rd_row > 0 else "READOUT"
                self.cg_rst.sample(state=st)

    def sample(self) -> None:
        env, p, m = self.env, self.p, self.model
        t = env.cycle
        i = {k: v.read() for k, v in self.i.items()}
        o = {k: v.read() for k, v in self.o.items()}
        pf = {k: v.read() for k, v in self.perf.items()}
        if env.in_reset:
            # synchronous reset: the registered state clears at THIS edge; outputs are checked from the next cycle on
            if m.state != IDLE or m.n_tiles:
                self.sb.cancel(reason="reset")
            m.reset()
            self.cur_job = None
            self.rows_seen = []
            self.prev_m = None
            self.t_launch = self.t_done = None
            return
        stall = i["stall_i"]
        e = m.outputs(stall)
        # ----- scalar outputs
        self._eq("cfg_ready", e.cfg_ready, o["cfg_ready"])
        self._eq("cfg_reject", e.cfg_reject, o["cfg_reject"])
        self._eq("s_ready", e.s_ready, o["s_ready"])
        self._eq("busy", e.busy, o["busy"])
        self._eq("tile_done", e.tile_done, o["tile_done"])
        self._eq("m_valid", e.m_valid, o["m_valid"])
        self._eq("align_err", 0, o["align_err"])
        if m.state == RUN:
            self._eq("s_k (index of the slice expected next)", e.s_k, o["s_k"])
        # ----- performance counters (cleared at launch, frozen from READOUT)
        for k in PERF:
            self._eq("perf_%s" % k, e.perf[k] if self.perf_en else 0, pf[k])
        # ----- result stream payload
        if o["m_valid"]:
            self._eq("m_row", m.rd_row, o["m_row"])
            self._eq("m_last", e.m_last, o["m_last"])
            self._eq("m_col_mask", e.m_col_mask, o["m_col_mask"])
            for j in range(p.cols):
                self._eq("m_data lane %d (row %d)" % (j, m.rd_row), e.m_data[j], (o["m_data"] >> (j * p.acc)) & ((1 << p.acc) - 1))
            cur = (o["m_row"], o["m_data"], o["m_col_mask"], o["m_last"])
            if self.prev_m is not None:
                self._expect(cur == self.prev_m, "m_* payload changed while m_valid && !m_ready")
            self.prev_m = cur if not i["m_ready"] else None
        else:
            self.prev_m = None
        # ----- advance the model with this edge's inputs
        sa = [to_signed((i["s_a"] >> (r * p.dw)) & ((1 << p.dw) - 1), p.dw) for r in range(p.rows)]
        sb = [to_signed((i["s_b"] >> (c * p.dw)) & ((1 << p.dw) - 1), p.dw) for c in range(p.cols)]
        state_before = m.state
        st_info = (m.state, m.k_cnt, m.k, m._all_done(), m.drain_done)
        m_row_before = m.rd_row
        cfg_hs = bool(i["cfg_valid"] and e.cfg_ready)
        ev = m.edge(cfg_valid=i["cfg_valid"], cfg_m=i["cfg_m"], cfg_n=i["cfg_n"], cfg_k=i["cfg_k"], s_valid=i["s_valid"], s_a=sa, s_b=sb, stall_i=stall, m_ready=i["m_ready"])
        if i["s_valid"] and not o["s_ready"] and state_before != RUN and self.slice_drv is not None and self.slice_drv.job is None:
            self.cg_press.sample(ghost_valid="ignored_outside_run")
        if ev["accepted"]:
            self.log.append("t%d slice k=%d" % (t, m.k_cnt - 1))
        # ----- cfg events
        item = self.cfg_drv.hs_item if self.cfg_drv is not None else None
        if i["cfg_valid"] and not e.cfg_ready:
            self.n_ignored += 1
            self.cg_cfg.sample(cfg="while_busy_ignored")
        if ev["launched"]:
            self.seq += 1
            self.t_launch = t
            job = item.job if item is not None else None
            self._expect(job is not None, "a tile was launched that the test did not submit")
            self.cur_job = job
            self.rows_seen = []
            if job is not None:
                self.sb.accept("tile", self.seq, job)
                if self.slice_drv is not None:
                    self.slice_drv.launch(job)
                self._cov_launch(job, t)
        if ev["rejected"]:
            self.n_reject += 1
            kinds = []
            if i["cfg_m"] == 0:
                kinds.append("m0")
            if i["cfg_m"] > p.rows:
                kinds.append("m_gt_rows")
            if i["cfg_n"] == 0:
                kinds.append("n0")
            if i["cfg_n"] > p.cols:
                kinds.append("n_gt_cols")
            if i["cfg_k"] == 0:
                kinds.append("k0")
            for kd in kinds:
                self.cg_cfg.sample(cfg=kd)
            self.cg_cfg.sample(cfg="reject_pulse")
        if cfg_hs and ev["launched"]:
            if self.t_tile_end is not None and t - self.t_tile_end == 1:
                self.cg_cfg.sample(cfg="back_to_back_launch")  # accepted in the very first IDLE cycle after the previous tile
            if self.cfg_wait > 0:
                self.cg_cfg.sample(cfg="hold_until_idle")  # presented while busy, accepted when the array returned to IDLE
        self.cfg_wait = self.cfg_wait + 1 if (i["cfg_valid"] and not e.cfg_ready) else 0
        # ----- result rows
        if o["m_valid"] and i["m_ready"]:
            self.rows_seen.append([to_signed((o["m_data"] >> (j * p.acc)) & ((1 << p.acc) - 1), p.acc) for j in range(m.n if state_before == READOUT else 0)])
        if state_before == DRAIN and m.state == READOUT:
            self.t_done = t + 1
        if ev["tile_end"]:
            job = self.cur_job
            self.sb.complete("tile", self.seq)
            if job is not None:
                want = matmul([job.A[r][:job.k] for r in range(job.m)], [job.B[kk][:job.n] for kk in range(job.k)], p.acc)
                self.sb.check_eq("tile result rows == independent GEMM of the intended operands", repr(want), repr(self.rows_seen), "m=%d n=%d k=%d kind=%s" % (job.m, job.n, job.k, job.kind))
                self.checks += 1
                self._cov_tile_end(job)
            self.tiles.append(dict(m=m.m, n=m.n, k=m.k, busy=m.perf["busy"], launch=self.t_launch, done=self.t_done))
            self.t_tile_end = t
        # ----- run-length coverage
        self._cov_runs(i, o, e, st_info, ev)

    # ---------------------------------------------------------------------------------------- coverage helpers
    def _cov_launch(self, job: TileJob, t: int) -> None:
        p = self.p
        partial = (1 if job.m < p.rows else 0) + (2 if job.n < p.cols else 0)
        self.cg_shape.sample(m=job.m, n=job.n, k=job.k, partial=partial)
        self.cg_cfg.sample(cfg="legal")
        if self.prev_cfg is not None:
            pm, pn, pk = self.prev_cfg
            ch = [pm != job.m, pn != job.n, pk != job.k]
            self.cg_cfg.sample(shape_change="same" if not any(ch) else ("all_changed" if all(ch) else ("m_changed" if ch == [True, False, False] else "n_changed" if ch == [False, True, False] else "k_changed" if ch == [False, False, True] else "mn_changed")),
                               prev_shape="full" if (pm == p.rows and pn == p.cols) else "partial")
        self.prev_cfg = (job.m, job.n, job.k)
        self.cg_val.sample(kind=job.kind)
        if p.mul_pipe:
            self.cg_perf.sample(event="mul_pipe_tile")

    def _cov_tile_end(self, job: TileJob) -> None:
        p = self.p
        flat = [v for r in self.rows_seen for v in r]
        exact = [sum(job.A[i][kk] * job.B[kk][j] for kk in range(job.k)) for i in range(job.m) for j in range(job.n)]
        wrapped = any(abs(x) > (1 << (p.acc - 1)) - 1 or x < -(1 << (p.acc - 1)) for x in exact)
        self.cg_val.sample(acc_wrap="wrapped" if wrapped else "no_wrap")
        if wrapped:
            self.wrapped_tiles += 1
        neg, pos, zero = any(v < 0 for v in flat), any(v > 0 for v in flat), all(v == 0 for v in flat)
        self.cg_val.sample(c_sign="zero" if zero else ("mixed" if (neg and pos) else ("neg" if neg else "pos")))
        pm = self.model.perf
        su, se = pm["stall_up"] > 0, pm["stall_ext"] > 0
        self.cg_perf.sample(event="both" if (su and se) else ("stall_up_nonzero" if su else ("stall_ext_nonzero" if se else "none")))

    def _cov_runs(self, i, o, e, st_info, ev) -> None:
        st, kc, kk, all_done, dd = st_info
        cg = self.cg_press
        if i["stall_i"]:
            self.stall_run += 1
            if st == RUN:
                cg.sample(stall_state="RUN_first_slice" if kc == 0 else ("RUN_last_slice" if kc == kk - 1 else "RUN_mid"))
            elif st == DRAIN:
                cg.sample(stall_state="DRAIN_all_done_cycle" if all_done else ("DRAIN_early" if dd < 2 else "DRAIN_late"))
            elif st == IDLE:
                cg.sample(stall_state="IDLE_ignored")
            elif st == CLEAR:
                cg.sample(stall_state="CLEAR_ignored")
            elif st == READOUT:
                cg.sample(stall_state="READOUT_ignored")
        elif self.stall_run:
            cg.sample(stall_run=self.stall_run)
            self.stall_run = 0
        if st == RUN and not i["s_valid"] and not i["stall_i"]:
            self.gap_run += 1
            cg.sample(stall_state="RUN_valid_gap")
        elif self.gap_run:
            cg.sample(gap_run=self.gap_run)
            self.gap_run = 0
        if o["m_valid"] and not i["m_ready"]:
            self.mready_run += 1
            self.cg_perf.sample(event="m_ready_gap_in_readout")
        elif self.mready_run:
            cg.sample(m_ready_low_run=self.mready_run)
            self.mready_run = 0

    def finalize(self) -> None:
        self.sb.finalize(allow_outstanding=True)

    def summary(self) -> dict:
        d = self.sb.summary()
        d["checks"] += self.checks
        d.update(tiles=len(self.tiles), rejects=self.n_reject, ignored_cfg_cycles=self.n_ignored, wrapped_tiles=self.wrapped_tiles)
        return d
