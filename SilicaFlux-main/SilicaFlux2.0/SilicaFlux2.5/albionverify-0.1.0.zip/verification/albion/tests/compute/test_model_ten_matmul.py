"""Model unit tests for albionverify.models.ten_matmul (no simulator): hand-computed GEMMs, numpy oracle,
accumulator wrap-around, and the documented timing identities / tables of rtl/tensorcore02/docs/PERFORMANCE.md."""
import random

import numpy as np
import pytest

from albionverify.models.ten_matmul import (CLEAR, DRAIN, IDLE, READOUT, RUN, TenParams, TileModel, cfg_legal, commits_at_step,
                                            drain_steps_needed, matmul, to_signed, to_unsigned, wrap_signed)


def test_hand_matmul():
    A = [[1, 2], [3, 4]]
    B = [[5, 6], [7, 8]]
    assert matmul(A, B, 32) == [[19, 22], [43, 50]]
    assert matmul([[1, 0], [0, 1]], B, 32) == B  # identity
    assert matmul([[0, 0], [0, 0]], B, 32) == [[0, 0], [0, 0]]
    assert matmul([[-128]], [[-128]], 32) == [[16384]]
    assert matmul([[-128]], [[127]], 32) == [[-16256]]
    assert matmul([[127]], [[127]], 32) == [[16129]]


def test_wraparound_boundaries():
    # ACC_WIDTH = 16: 2 x (-128*-128) = 32768 wraps to -32768; 3x -> 49152 -> -16384
    assert matmul([[-128, -128]], [[-128], [-128]], 16) == [[-32768]]
    assert matmul([[-128] * 3], [[-128]] * 3, 16) == [[-16384]]
    assert matmul([[127] * 2], [[127]] * 2, 16) == [[32258]]
    assert matmul([[127] * 3], [[127]] * 3, 16) == [[48387 - 65536]]
    # 32-bit: K = 131071 of 16384 is the largest overflow-free K (CONFIGURATION.md 2); 131072 wraps to -2^31
    assert wrap_signed(131071 * 16384, 32) == 131071 * 16384 == 2147467264
    assert wrap_signed(131072 * 16384, 32) == -(1 << 31)
    assert to_signed(0x80000000, 32) == -(1 << 31) and to_unsigned(-1, 16) == 0xFFFF


def test_numpy_oracle_random():
    rng = np.random.default_rng(3)
    for (M, K, N, acc) in [(4, 5, 4, 32), (3, 17, 2, 32), (2, 9, 3, 16), (1, 1, 1, 32), (4, 300, 4, 32)]:
        A = rng.integers(-128, 128, size=(M, K))
        B = rng.integers(-128, 128, size=(K, N))
        want = (A.astype(np.int64) @ B.astype(np.int64))
        want = ((want + (1 << (acc - 1))) % (1 << acc)) - (1 << (acc - 1))
        assert matmul(A.tolist(), B.tolist(), acc) == want.tolist()


def test_cfg_legality():
    p = TenParams(rows=3, cols=2, k_w=8)
    assert cfg_legal(1, 1, 1, p) and cfg_legal(3, 2, 255, p)
    assert not cfg_legal(0, 1, 1, p) and not cfg_legal(1, 0, 1, p) and not cfg_legal(1, 1, 0, p)
    assert not cfg_legal(4, 1, 1, p) and not cfg_legal(1, 3, 1, p) and not cfg_legal(1, 1, 256, p)
    assert (p.m_w, p.n_w) == (2, 2) and TenParams(rows=4).m_w == 3 and TenParams(rows=1, cols=1).m_w == 1


# ---------------------------------------------------------------------------------------------- timing model
def run_tile(p, m, n, k, A, B, *, svalid=lambda t: 1, stall=lambda t: 0, mready=lambda t: 1, h=3, horizon=400):
    """Drive TileModel like the DUT's environment would.  Returns (results rows, cycle of tile_done, perf, log)."""
    tm = TileModel(p)
    rows, tdone, log = [], None, []
    launched = False
    for t in range(horizon):
        stl = stall(t)
        o = tm.outputs(stl)
        if o.tile_done and tdone is None:
            tdone = t
        if o.m_valid and mready(t):
            rows.append((o.m_row, list(o.m_data), o.m_col_mask, o.m_last))
        cv = int(t == h)
        k_idx = o.s_k
        sa = [A[i][k_idx] if k_idx < k else 0 for i in range(p.rows)] if o.s_ready else None
        sb = [B[k_idx][j] if k_idx < k else 0 for j in range(p.cols)] if o.s_ready else None
        sv = svalid(t)
        tm.edge(cfg_valid=cv, cfg_m=m, cfg_n=n, cfg_k=k, s_valid=sv, s_a=sa or [0] * p.rows, s_b=sb or [0] * p.cols, stall_i=stl, m_ready=mready(t))
        log.append(tm.state)
        if tm.state == IDLE and t > h + 2:
            break
    return rows, tdone, tm.perf, tm


@pytest.mark.parametrize("mp", [0, 1])
def test_documented_busy_table(mp):
    """PERFORMANCE.md 2 / 4 / 5 / 6: busy = 1 + K + M + N (+1 with MUL_PIPE), e.g. 4x4: K=1 -> 10, K=16 -> 25."""
    p = TenParams(rows=4, cols=4, mul_pipe=mp)
    for (k, busy) in [(1, 10), (3, 12), (4, 13), (7, 16), (16, 25), (257, 266)]:
        A = [[1] * k for _ in range(4)]
        B = [[1] * 4 for _ in range(k)]
        rows, tdone, perf, _ = run_tile(p, 4, 4, k, A, B, horizon=700)
        assert perf["busy"] == busy + mp and perf["issue"] == k and perf["mac"] == 16 * k and perf["pad"] == 0
        assert perf["stall_up"] == 0 and perf["stall_ext"] == 0
        # tile_done at d = h + 2 + K + M + N + MUL_PIPE
        assert tdone == 3 + 2 + k + 8 + mp
        assert [r[0] for r in rows] == [0, 1, 2, 3] and [r[3] for r in rows] == [0, 0, 0, 1]


def test_documented_partial_tile_table():
    p = TenParams(rows=4, cols=4)
    # PERFORMANCE.md 4: (M, N, busy, useful MACs, padding slots) for K = 5
    for (m, n, busy, mac, pad) in [(1, 1, 8, 5, 75), (1, 4, 11, 20, 60), (2, 3, 11, 30, 50), (3, 3, 12, 45, 35), (4, 1, 11, 20, 60), (4, 4, 14, 80, 0)]:
        A = [[1] * 5 for _ in range(4)]
        B = [[1] * 4 for _ in range(5)]
        rows, tdone, perf, _ = run_tile(p, m, n, 5, A, B)
        assert (perf["busy"], perf["mac"], perf["pad"]) == (busy, mac, pad)
        assert len(rows) == m and all(r[2] == (1 << n) - 1 for r in rows)


def test_stall_identity_random():
    rng = random.Random(7)
    for trial in range(40):
        mp = rng.getrandbits(1)
        rows_, cols_ = rng.randint(1, 4), rng.randint(1, 4)
        p = TenParams(rows=rows_, cols=cols_, mul_pipe=mp)
        m, n, k = rng.randint(1, rows_), rng.randint(1, cols_), rng.randint(1, 12)
        A = [[rng.randint(-128, 127) for _ in range(k)] for _ in range(rows_)]
        B = [[rng.randint(-128, 127) for _ in range(cols_)] for _ in range(k)]
        sv = [rng.random() < 0.6 for _ in range(600)]
        st = [rng.random() < 0.3 for _ in range(600)]
        mr = [rng.random() < 0.7 for _ in range(600)]
        rows, tdone, perf, tm = run_tile(p, m, n, k, A, B, svalid=lambda t: sv[t], stall=lambda t: st[t], mready=lambda t: mr[t], horizon=600)
        assert perf["busy"] == 1 + k + m + n + mp + perf["stall_up"] + perf["stall_ext"]
        assert perf["mac"] == m * n * k and perf["issue"] == k and perf["pad"] == (rows_ * cols_ - m * n) * k
        got = [[to_signed(v, 32) for v in r[1][:n]] for r in rows]
        want = matmul([A[i][:k] for i in range(m)], [B[kk][:n] for kk in range(k)], 32)
        assert got == want


def test_commit_schedule_wavefront():
    # 2x2, K = 3, MUL_PIPE 0: commits per step (PERFORMANCE 3 style): 1,3,4,3,1 ... computed by hand:
    # step1: PE00 k0 -> 1 ; step2: PE00 k1, PE01 k0, PE10 k0 -> 3 ; step3: PE00 k2, PE01 k1, PE10 k1, PE11 k0 -> 4
    # step4: PE01 k2, PE10 k2, PE11 k1 -> 3 ; step5: PE11 k2 -> 1  (total 12 = 2*2*3)
    assert [commits_at_step(s, 2, 2, 3, 0) for s in range(7)] == [0, 1, 3, 4, 3, 1, 0]
    assert [commits_at_step(s, 2, 2, 3, 1) for s in range(7)] == [0, 0, 1, 3, 4, 3, 1]
    # full concurrency cycles for 4x4 = K - 6 (PERFORMANCE 3): K=10 -> 4 cycles with all 16
    assert sum(1 for s in range(40) if commits_at_step(s, 4, 4, 10, 0) == 16) == 4
    assert drain_steps_needed(4, 4, TenParams(mul_pipe=1)) == 8


def test_reject_and_cfg_ignored_while_busy():
    p = TenParams(rows=2, cols=2, k_w=4)
    tm = TileModel(p)
    tm.edge(cfg_valid=1, cfg_m=0, cfg_n=1, cfg_k=1, s_valid=0, s_a=None, s_b=None, stall_i=0, m_ready=1)
    assert tm.state == IDLE and tm.outputs(0).cfg_reject == 1
    tm.edge(cfg_valid=0, cfg_m=0, cfg_n=0, cfg_k=0, s_valid=0, s_a=None, s_b=None, stall_i=0, m_ready=1)
    assert tm.outputs(0).cfg_reject == 0  # one-cycle pulse
    tm.edge(cfg_valid=1, cfg_m=2, cfg_n=2, cfg_k=2, s_valid=0, s_a=None, s_b=None, stall_i=0, m_ready=1)
    assert tm.state == CLEAR and tm.outputs(0).cfg_ready == 0
    # a cfg offered while busy (even an illegal one) is ignored: no reject pulse, no state change
    tm.edge(cfg_valid=1, cfg_m=0, cfg_n=0, cfg_k=0, s_valid=0, s_a=None, s_b=None, stall_i=0, m_ready=1)
    assert tm.state == RUN and tm.reject_q == 0 and (tm.m, tm.n, tm.k) == (2, 2, 2)
