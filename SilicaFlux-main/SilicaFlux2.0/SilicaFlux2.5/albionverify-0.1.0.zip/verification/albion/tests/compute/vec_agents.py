"""Cycle-based agents for the vector lane (hpc_vector_lane) bench.

  LaneDriver   drives in_valid / op / a / b / c / rm / tag / lane_en; holds a presented operation until accepted;
               random garbage payload while idle.
  LaneSink     drives out_ready with a Throttle (stall / burst patterns can be switched at run time).
  LaneMonitor  passive, lock-step: reads every DUT port each cycle, compares against LaneModel (ready / valid /
               payload / busy / perf-event pulses, exact cycle), runs the data ledger (Scoreboard) and functional
               coverage.  A violation raises AlbionCheckError with cycle and context.

Handshake convention (framework): a transfer happens at a rising edge where valid && ready were both high before
the edge; agents sample at the edge and drive for the next cycle.
"""
from __future__ import annotations

import random
from collections import deque
from typing import Deque, Dict, List, Optional

from albionverify.core import Agent, Env
from albionverify.coverage import CoverGroup
from albionverify.models import vec_fp32 as F
from albionverify.models.vec_lane import LaneModel, LaneOp, LaneParams
from albionverify.rng import Throttle
from albionverify.scoreboard import Scoreboard


class LaneDriver(Agent):
    def __init__(self, name: str, env: Env, rng: random.Random, throttle: str = "always", garbage: bool = True):
        super().__init__(name)
        s = env.sig
        self.valid, self.op, self.a, self.b, self.c = s("in_valid_i"), s("in_op_i"), s("in_a_i"), s("in_b_i"), s("in_c_i")
        self.rm, self.tag, self.en, self.ready = s("in_rm_i"), s("in_tag_i"), s("lane_en_i"), s("in_ready_o")
        self.rng = rng
        self.rst_rng = env.seeds.child(name + "_reset")  # separate stream: the main stimulus stream is not perturbed
        self.thr = Throttle(rng, throttle)
        self.garbage = garbage
        self.queue: Deque[LaneOp] = deque()
        self.cur: Optional[LaneOp] = None
        self._v = False
        self.n_presented = 0
        self.n_accepted = 0
        self.max_wait = 0
        self._wait = 0

    def submit(self, op: LaneOp) -> None:
        self.queue.append(op)

    @property
    def idle(self) -> bool:
        return self.cur is None and not self.queue

    def sample(self) -> None:
        if self._v and not self.env.in_reset:
            if self.ready.read():
                self.cur = None
                self.n_accepted += 1
                self.max_wait = max(self.max_wait, self._wait)
                self._wait = 0
            else:
                self._wait += 1
                self.max_wait = max(self.max_wait, self._wait)

    def drive(self) -> None:
        env = self.env
        if env.in_reset:
            self._v = False
            r = self.rst_rng  # spec: every input is ignored during reset -> garbage payload with valid toggling
            self.valid.write(r.getrandbits(1))
            self.op.write(r.getrandbits(5))
            self.a.write(r.getrandbits(32))
            self.b.write(r.getrandbits(32))
            self.c.write(r.getrandbits(32))
            self.rm.write(r.getrandbits(3))
            self.tag.write(r.getrandbits(8))
            self.en.write(r.getrandbits(1))
            return
        if self.cur is None and self.queue and self.thr.allow():
            self.cur = self.queue.popleft()
        if self.cur is not None:
            o = self.cur
            self.valid.write(1)
            self.op.write(o.op)
            self.a.write(o.a)
            self.b.write(o.b)
            self.c.write(o.c)
            self.rm.write(o.rm)
            self.tag.write(o.tag)
            self.en.write(1 if o.en else 0)
            self._v = True
            self.n_presented += 1
        else:
            self.valid.write(0)
            if self.garbage:
                r = self.rng
                self.op.write(r.getrandbits(5))
                self.a.write(r.getrandbits(32))
                self.b.write(r.getrandbits(32))
                self.c.write(r.getrandbits(32))
                self.rm.write(r.getrandbits(3))
                self.tag.write(r.getrandbits(8))
                self.en.write(r.getrandbits(1))
            self._v = False

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            self.cur = None
            self.queue.clear()  # the producer is reset too: tests re-submit after reset
            self._v = False
            self._wait = 0

    def summary(self) -> dict:
        return {"accepted": self.n_accepted, "max_wait": self.max_wait}


class LaneSink(Agent):
    def __init__(self, name: str, env: Env, rng: random.Random, throttle: str = "always"):
        super().__init__(name)
        self.ready = env.sig("out_ready_i")
        self.thr = Throttle(rng, throttle)

    def set_mode(self, spec: str) -> None:
        self.thr.set_mode(spec)

    def drive(self) -> None:
        self.ready.write(1 if self.thr.allow() else 0)


TAG_MASK = 0xFF


class LaneMonitor(Agent):
    """Lock-step checker / scoreboard / coverage for one lane."""

    def __init__(self, name: str, env: Env, p: LaneParams, *, check_events: bool = True):
        super().__init__(name)
        s = env.sig
        self.p = p
        self.in_valid, self.in_ready = s("in_valid_i"), s("in_ready_o")
        self.in_op, self.in_a, self.in_b, self.in_c = s("in_op_i"), s("in_a_i"), s("in_b_i"), s("in_c_i")
        self.in_rm, self.in_tag, self.lane_en = s("in_rm_i"), s("in_tag_i"), s("lane_en_i")
        self.out_valid, self.out_ready = s("out_valid_o"), s("out_ready_i")
        self.out_result, self.out_flags, self.out_tag, self.out_illegal = s("out_result_o"), s("out_flags_o"), s("out_tag_o"), s("out_illegal_o")
        self.busy = s("busy_o")
        self.ev = {k: s("ev_%s_o" % n) for k, n in (("accept", "accept"), ("retire", "retire"), ("pipe_stall", "pipe_stall"),
                                                     ("backpressure", "backpressure"), ("illegal", "illegal"), ("masked", "masked"))}
        self.model = LaneModel(p)
        self.sb = Scoreboard(env, name)
        self.check_events = check_events
        self.seq = 0
        self.pend_seq: Deque[int] = deque()
        self.checks = 0
        self.t_accept: Dict[int, int] = {}
        self.prev_payload = None
        self.bp_run = 0
        self.full_run = 0
        self.n_results = 0
        self.n_masked = 0
        self.n_illegal = 0
        self.max_occ = 0
        self.overtake = 0
        self.last_retire_cycle = -1
        self.last_accept_cycle = -10
        self.on_result = []  # optional listeners f(op, result, flags, illegal, latency)
        self._init_cov()

    # ----------------------------------------------------------------- coverage
    def _init_cov(self) -> None:
        legal = list(F.ALL_LEGAL_OPS)
        ops = {F.OP_NAMES[o]: o for o in legal}
        ops["ILLEGAL_OPCODE"] = lambda v: not (v in F.ALL_LEGAL_OPS)
        cg = CoverGroup("lane_op_rm", "operation x rounding mode (incl. illegal opcodes / rounding modes)")
        cg.point("op", ops)
        cg.point("rm", {"RNE": 0, "RTZ": 1, "RDN": 2, "RUP": 3, "RMM": 4, "illegal5-7": (5, 7)})
        cg.cross("op_x_rm", ["op", "rm"], ignore=lambda b: (b[0] == "ILLEGAL_OPCODE" and b[1] != "RNE"))
        self.cg_op = cg
        cv = CoverGroup("lane_values", "operand value classes per arithmetic family")
        cls = list(("zero", "subnormal", "tiny_normal", "normal", "huge", "inf", "qnan", "snan"))
        fams = {"add": [F.OP_FADD, F.OP_FSUB], "mul": F.OP_FMUL, "fma": list(F.FMA_OPS), "mv": F.OP_FMV}
        if self.p.en_fcmp:  # families that the configuration removes are not coverage targets
            fams["cmp"] = list(F.FCMP_OPS)
        if self.p.en_int:
            fams["int"] = list(F.INT_OPS)
        cv.point("fam", fams)
        cv.point("cls_a", cls)
        cv.point("cls_b", cls)
        cv.cross("fam_x_a_x_b", ["fam", "cls_a", "cls_b"], ignore=lambda b: b[0] in ("mv", "int"))
        cv.point("res_cls", cls)
        self.cg_val = cv
        cf = CoverGroup("lane_flags", "exception flags per family")
        ffams = {"add": [F.OP_FADD, F.OP_FSUB], "mul": F.OP_FMUL, "fma": list(F.FMA_OPS)}
        if self.p.en_fcmp:
            ffams["cmp"] = list(F.FCMP_OPS)
        cf.point("fam", ffams)
        cf.point("flag", {"none": lambda f: f == 0, "NV": lambda f: bool(f & F.NV), "OF": lambda f: bool(f & F.OF), "UF+NX": lambda f: (f & 3) == 3, "UF": lambda f: bool(f & F.UF), "NX": lambda f: bool(f & F.NX)})
        # structurally impossible bins: comparisons never overflow / underflow / round; an FP add / subtract whose result is tiny is
        # always EXACT (both operands are multiples of 2^-149), so it can never raise UF
        cf.cross("fam_x_flag", ["fam", "flag"], ignore=lambda b: (b[0] == "cmp" and b[1] in ("OF", "UF", "NX", "UF+NX")) or (b[0] == "add" and b[1] in ("UF", "UF+NX")))
        self.cg_flag = cf
        cp = CoverGroup("lane_pipeline", "latency classes, occupancy, backpressure, ordering, lane_en, reset context")
        ul = {"misc": "misc", "fadd": "fadd", "fmul": "fmul", "fma": "fma", "illegal": "illegal"}
        if self.p.en_int:
            ul["imul"] = "imul"
        cp.point("unit_latency", ul)
        d = self.p.rob_depth
        occ = {"0": 0}
        for name, rng_ in (("1", (1, 1)), ("2", (2, 2)), ("3-4", (3, 4)), ("5-7", (5, 7)), ("8+", (8, 64))):
            if rng_[0] <= d:  # bins beyond the ROB depth cannot occur
                occ[name] = rng_
        cp.point("occupancy", occ)
        cp.point("bp_run", {"1": 1, "2-3": (2, 3), "4-7": (4, 7), "8-15": (8, 15), "16+": (16, 100000)})
        cp.point("ready_low_run", {"1": 1, "2-3": (2, 3), "4-7": (4, 7), "8+": (8, 100000)})
        evs = ["disabled_op", "full_rob", "illegal_retired"] + (["back_to_back_accept", "overtake"] if d >= 2 else [])
        cp.point("event", evs)
        cp.point("reset_ctx", ["idle", "rob_full"] + (["ops_in_flight", "result_stalled"] if d >= 2 else []))
        self.cg_pipe = cp

    def attach(self, env: Env) -> None:
        super().attach(env)
        for g in (self.cg_op, self.cg_val, self.cg_flag, self.cg_pipe):
            env.coverage.append(g)

    @staticmethod
    def _unit_name(p: LaneParams, op: int, rm: int) -> str:
        if not F.op_legal(op, rm, p.en_fcmp, p.en_int):
            return "illegal"
        if op in (F.OP_FADD, F.OP_FSUB):
            return "fadd"
        if op == F.OP_FMUL:
            return "fmul"
        if op in F.FMA_OPS:
            return "fma"
        if op == F.OP_IMUL:
            return "imul"
        return "misc"

    def _fam(self, op: int) -> str:
        if op in (F.OP_FADD, F.OP_FSUB):
            return "add"
        return "mul" if op == F.OP_FMUL else "fma"

    # ----------------------------------------------------------------- checks
    def _eq(self, what: str, exp, got) -> None:
        self.checks += 1
        if exp != got:
            self.env.error("%s: %s mismatch: expected 0x%x got 0x%x" % (self.name, what, exp, got))

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            m = self.model
            if m.occupancy and self.env.cycle > 0:
                ctx = "rob_full" if m.occupancy >= self.p.rob_depth else ("result_stalled" if self.bp_run else "ops_in_flight")
                self.cg_pipe.sample(reset_ctx=ctx)
            elif self.env.cycle > 8:
                self.cg_pipe.sample(reset_ctx="idle")
            self.sb.cancel(reason="reset")
            m.reset()
            self.bp_run = self.full_run = 0
            self.prev_payload = None
            self.t_accept.clear()
            self.pend_seq.clear()

    def sample(self) -> None:
        env = self.env
        t = env.cycle
        m, p = self.model, self.p
        iv, ir = self.in_valid.read(), self.in_ready.read()
        ov, orr = self.out_valid.read(), self.out_ready.read()
        res, fl, tag, ill = self.out_result.read(), self.out_flags.read(), self.out_tag.read(), self.out_illegal.read()
        busy = self.busy.read()
        evs = {k: s.read() for k, s in self.ev.items()}
        if env.in_reset:
            m.reset()
            # reset forces every output low immediately (asynchronous assert) -- no stale result may appear
            for what, v in (("in_ready", ir), ("out_valid", ov), ("busy", busy), ("out_result", res), ("out_flags", fl), ("out_tag", tag), ("out_illegal", ill)):
                self._eq("%s during reset" % what, 0, v)
            return
        o = m.outputs(t)
        self._eq("in_ready", o.in_ready, ir)
        self._eq("out_valid", o.out_valid, ov)
        self._eq("busy", o.busy, busy)
        self._eq("out_result", o.out_result, res)
        self._eq("out_flags", o.out_flags, fl)
        self._eq("out_tag", o.out_tag, tag)
        self._eq("out_illegal", o.out_illegal, ill)
        op = None
        en = self.lane_en.read()
        if iv:
            op = LaneOp(self.in_op.read(), self.in_a.read(), self.in_b.read(), self.in_c.read(), self.in_rm.read(), self.in_tag.read(), bool(en))
        if self.check_events:
            exp_ev = m.events(t, iv, en, op, orr)
            for k, v in evs.items():
                self._eq("ev_%s" % k, exp_ev[k], v)
        # ---- payload stability while stalled (protocol rule), independent of the model
        if self.prev_payload is not None:
            self.checks += 1
            if (ov, res, fl, tag, ill) != self.prev_payload:
                env.error("%s: result payload / valid changed while out_valid && !out_ready" % self.name)
        self.prev_payload = (ov, res, fl, tag, ill) if (ov and not orr) else None
        # ---- ledger + coverage
        hs = bool(iv and ir)
        if hs and en and self.last_accept_cycle == t - 1:
            self.cg_pipe.sample(event="back_to_back_accept")
        if hs and en:
            self.last_accept_cycle = t
            self.seq += 1
            exp_res, exp_fl, exp_ill = F.exec_op(op.op, op.a, op.b, op.c, op.rm, p.en_fcmp, p.en_int)
            self.sb.accept("lane", self.seq, (op, exp_res, exp_fl, exp_ill, op.tag & TAG_MASK))
            self.t_accept[self.seq] = t
            self.pend_seq.append(self.seq)
            self._cov_accept(op, exp_res, exp_fl, exp_ill)
        if hs and not en:
            self.n_masked += 1
            self.cg_pipe.sample(event="disabled_op")
        if ov and orr:
            seq = self.pend_seq.popleft()
            exp = self.sb.complete("lane")
            op_, exp_res, exp_fl, exp_ill, exp_tag = exp
            self.sb.check_eq("result data", exp_res if not exp_ill else 0, res, "op=%s a=%08x b=%08x c=%08x rm=%d" % (F.OP_NAMES.get(op_.op, hex(op_.op)), op_.a, op_.b, op_.c, op_.rm))
            self.sb.check_eq("result flags", exp_fl if not exp_ill else 0, fl, "op=%s" % F.OP_NAMES.get(op_.op, hex(op_.op)))
            self.sb.check_eq("result tag", exp_tag, tag)
            self.sb.check_eq("illegal", int(exp_ill), ill)
            self.n_results += 1
            lat = t - self.t_accept.pop(seq)
            for cb in self.on_result:
                cb(op_, res, fl, ill, lat)
            if exp_ill:
                self.cg_pipe.sample(event="illegal_retired")
            env.digest.event("lane.res", t, res, fl, tag, ill)
        # head waiting while younger entries are already complete => overtaking happened
        if m.q and len(m.q) > 1 and m.q[0].done_at > t and any(e.done_at <= t for e in list(m.q)[1:]):
            self.overtake += 1
            self.cg_pipe.sample(event="overtake")
        # ---- run-length coverage
        if ov and not orr:
            self.bp_run += 1
        elif self.bp_run:
            self.cg_pipe.sample(bp_run=self.bp_run)
            self.bp_run = 0
        if iv and not ir and m.init:
            self.full_run += 1
        elif self.full_run:
            self.cg_pipe.sample(ready_low_run=self.full_run)
            self.full_run = 0
        if m.occupancy >= p.rob_depth:
            self.cg_pipe.sample(event="full_rob")
        self.max_occ = max(self.max_occ, m.occupancy)
        self.cg_pipe.sample(occupancy=m.occupancy)
        # ---- advance the model
        m.edge(t, iv, op, orr)

    def _cov_accept(self, op: LaneOp, res: int, fl: int, ill: bool) -> None:
        p = self.p
        self.cg_op.sample(op=op.op, rm=op.rm)
        un = self._unit_name(p, op.op, op.rm)
        self.cg_pipe.sample(unit_latency=un)
        if ill:
            self.n_illegal += 1
            return
        fam_ops = {F.OP_FMV, F.OP_FADD, F.OP_FSUB, F.OP_FMUL, *F.FMA_OPS, *F.FCMP_OPS, *F.INT_OPS}
        if op.op in fam_ops:
            self.cg_val.sample(fam=op.op, cls_a=F.value_class(op.a), cls_b=F.value_class(op.b), res_cls=F.value_class(res))
        if op.op in (F.OP_FADD, F.OP_FSUB, F.OP_FMUL, *F.FMA_OPS, *F.FCMP_OPS):
            self.cg_flag.sample(fam=op.op, flag=fl)
            for name, bit in (("NV", F.NV), ("OF", F.OF), ("UF", F.UF), ("NX", F.NX)):
                if fl & bit:
                    self.cg_flag.sample(fam=op.op, flag=bit if name != "UF" else F.UF)

    def finalize(self) -> None:
        self.sb.finalize(allow_outstanding=True)

    def summary(self) -> dict:
        d = self.sb.summary()
        d["checks"] = d["checks"] + self.checks
        d["max_occupancy"] = self.max_occ
        d["overtakes"] = self.overtake
        d["masked"] = self.n_masked
        d["illegal_ops"] = self.n_illegal
        return d
