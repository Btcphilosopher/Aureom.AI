"""Cycle-based agents for the vector array (hpc_vector_array) bench: streaming valid/ready interfaces.

  CmdDriver / OpndDriver   independent valid/ready producers (command stream, operand-beat stream) with random
                           garbage payload while idle and hold-until-accepted; reset flushes both producers
  ReadySink                res_ready / cpl_ready with a Throttle (switchable at run time)
  HoldDriver               lane_hold_i patterns (none, random, bursty, stuck lane, out-of-phase, scripted)
  PerfClearDriver          perf_clear_i pulses
  ArrayMonitor             passive checker: every res beat and completion record against the model (ordering,
                           tid/beat/last, per-lane data, flags, mask, zero payload when invalid, completion
                           strictly after its data, payload stability), framing, busy, reset behaviour, hold
                           contract (black-box), performance counters, functional coverage.
"""
from __future__ import annotations

import random
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional

from albionverify.core import Agent, Env
from albionverify.coverage import CoverGroup
from albionverify.models import vec_fp32 as F
from albionverify.models.vec_array import ArrayParams, Beat, Cmd, Expected, active_mask, cmd_legal, expected, nbeats
from albionverify.rng import Throttle
from albionverify.scoreboard import Scoreboard

M32 = 0xFFFFFFFF


@dataclass
class Job:
    cmd: Cmd
    beats: List[Beat]
    exp: Expected
    legal: bool
    act_counts: List[int]
    seq: int = 0


def make_job(cmd: Cmd, beats: List[Beat], p: ArrayParams) -> Job:
    legal = cmd_legal(cmd, p)
    exp = expected(cmd, beats, p)
    acts = [bin(active_mask(cmd, beats[g], g, p.n, legal)).count("1") for g in range(len(beats))]
    return Job(cmd, beats, exp, legal, acts)


# ====================================================================================================== drivers
class CmdDriver(Agent):
    def __init__(self, name: str, env: Env, rng: random.Random, vl_w: int, tid_w: int, throttle: str = "always"):
        super().__init__(name)
        s = env.sig
        self.sg = dict(valid=s("cmd_valid_i"), ready=s("cmd_ready_o"), op=s("cmd_op_i"), rm=s("cmd_rm_i"), vl=s("cmd_vl_i"), vm=s("cmd_vm_i"),
                       bcast=s("cmd_bcast_i"), scalar=s("cmd_scalar_i"), red=s("cmd_red_i"), tid=s("cmd_tid_i"))
        self.rng, self.vl_w, self.tid_w = rng, vl_w, tid_w
        self.thr = Throttle(rng, throttle)
        self.queue: Deque[Cmd] = deque()
        self.cur: Optional[Cmd] = None
        self._v = False
        self.n_accepted = 0
        self.wait_run = 0
        self.max_wait = 0

    def submit(self, c: Cmd) -> None:
        self.queue.append(c)

    @property
    def idle(self) -> bool:
        return self.cur is None and not self.queue

    def sample(self) -> None:
        if self._v and not self.env.in_reset:
            if self.sg["ready"].read():
                self.cur = None
                self.n_accepted += 1
                self.max_wait = max(self.max_wait, self.wait_run)
                self.wait_run = 0
            else:
                self.wait_run += 1
                self.max_wait = max(self.max_wait, self.wait_run)

    def drive(self) -> None:
        g, r = self.sg, self.rng
        if self.env.in_reset:
            self._v = False
            self._idle_payload()
            g["valid"].write(r.getrandbits(1))  # spec: all inputs are ignored during reset -> present garbage with valid half the time
            return
        if self.cur is None and self.queue and self.thr.allow():
            self.cur = self.queue.popleft()
        if self.cur is not None:
            c = self.cur
            for k, v in (("op", c.op), ("rm", c.rm), ("vl", c.vl), ("vm", c.vm), ("bcast", c.bcast), ("scalar", c.scalar), ("red", c.red), ("tid", c.tid)):
                g[k].write(v)
            g["valid"].write(1)
            self._v = True
        else:
            g["valid"].write(0)
            self._idle_payload()
            self._v = False

    def _idle_payload(self) -> None:
        g, r = self.sg, self.rng
        g["op"].write(r.getrandbits(5))
        g["rm"].write(r.getrandbits(3))
        g["vl"].write(r.getrandbits(self.vl_w))
        g["vm"].write(r.getrandbits(1))
        g["bcast"].write(r.getrandbits(3))
        g["scalar"].write(r.getrandbits(32))
        g["red"].write(r.getrandbits(1))
        g["tid"].write(r.getrandbits(self.tid_w))

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            self.cur = None
            self.queue.clear()
            self._v = False
            self.wait_run = 0


class OpndDriver(Agent):
    def __init__(self, name: str, env: Env, rng: random.Random, n: int, throttle: str = "always"):
        super().__init__(name)
        s = env.sig
        self.sg = dict(valid=s("opnd_valid_i"), ready=s("opnd_ready_o"), a=s("opnd_a_i"), b=s("opnd_b_i"), c=s("opnd_c_i"), mask=s("opnd_mask_i"))
        self.rng, self.n = rng, n
        self.thr = Throttle(rng, throttle)
        self.queue: Deque[Beat] = deque()
        self.cur: Optional[Beat] = None
        self._v = False
        self.n_accepted = 0

    def submit(self, b: Beat) -> None:
        self.queue.append(b)

    @property
    def idle(self) -> bool:
        return self.cur is None and not self.queue

    @staticmethod
    def pack(words: List[int]) -> int:
        v = 0
        for i, w in enumerate(words):
            v |= (w & M32) << (32 * i)
        return v

    def sample(self) -> None:
        if self._v and not self.env.in_reset and self.sg["ready"].read():
            self.cur = None
            self.n_accepted += 1

    def drive(self) -> None:
        g, r = self.sg, self.rng
        if self.env.in_reset:
            self._v = False
            self._idle_payload()
            g["valid"].write(r.getrandbits(1))  # inputs are ignored during reset
            return
        if self.cur is None and self.queue and self.thr.allow():
            self.cur = self.queue.popleft()
        if self.cur is not None:
            b = self.cur
            g["valid"].write(1)
            g["a"].write(self.pack(b.a))
            g["b"].write(self.pack(b.b))
            g["c"].write(self.pack(b.c))
            g["mask"].write(b.mask)
            self._v = True
        else:
            g["valid"].write(0)
            self._idle_payload()
            self._v = False

    def _idle_payload(self) -> None:
        g, r = self.sg, self.rng
        g["a"].write(r.getrandbits(32 * self.n))
        g["b"].write(r.getrandbits(32 * self.n))
        g["c"].write(r.getrandbits(32 * self.n))
        g["mask"].write(r.getrandbits(self.n))

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            self.cur = None
            self.queue.clear()
            self._v = False


class ReadySink(Agent):
    """Drives one ready signal (res_ready_i or cpl_ready_i) from a Throttle."""

    def __init__(self, name: str, env: Env, sig: str, rng: random.Random, throttle: str = "always"):
        super().__init__(name)
        self.sig = env.sig(sig)
        self.thr = Throttle(rng, throttle)

    def set_mode(self, spec: str) -> None:
        self.thr.set_mode(spec)

    def drive(self) -> None:
        self.sig.write(1 if self.thr.allow() else 0)


class HoldDriver(Agent):
    """lane_hold_i patterns.  Modes: none | random:p | bursty:lo-hi | stuck:lane | phase | all | script (set .script)."""

    def __init__(self, name: str, env: Env, n: int, rng: random.Random, mode: str = "none"):
        super().__init__(name)
        self.sig = env.sig("lane_hold_i")
        self.n, self.rng = n, rng
        self.script: Deque[int] = deque()
        self.mode = "none"
        self.value = 0
        self.cycle = 0
        self._burst_left = 0
        self.set_mode(mode)

    def set_mode(self, mode: str) -> None:
        self.mode = mode
        self.kind, _, self.arg = mode.partition(":")
        self._burst_left = 0
        if self.kind == "stuck":
            self.lane = int(self.arg or 0)

    def drive(self) -> None:
        k = self.kind
        n, r = self.n, self.rng
        full = (1 << n) - 1
        if k == "none":
            v = 0
        elif k == "random":
            p = float(self.arg)
            v = sum(1 << l for l in range(n) if r.random() < p)
        elif k == "bursty":
            lo, hi = [int(x) for x in self.arg.split("-")]
            if self._burst_left <= 0:
                self._burst_left = r.randint(lo, hi)
                self.value = r.getrandbits(n)
            self._burst_left -= 1
            v = self.value
        elif k == "stuck":  # one lane held 15 of 16 cycles
            v = (1 << self.lane) if (self.cycle % 16) != 0 else 0
        elif k == "phase":  # lanes held on alternating cycles, out of phase
            v = sum(1 << l for l in range(n) if (self.cycle + l) % 2 == 0)
        elif k == "all":
            v = full
        elif k == "script":
            v = self.script.popleft() if self.script else 0
        else:
            raise ValueError(self.mode)
        self.cycle += 1
        self.sig.write(v & full)


class PerfClearDriver(Agent):
    def __init__(self, name: str, env: Env):
        super().__init__(name)
        self.sig = env.sig("perf_clear_i")
        self.pending = 0

    def pulse(self) -> None:
        self.pending = 1

    def drive(self) -> None:
        self.sig.write(self.pending)
        self.pending = 0


# ====================================================================================================== monitor
PC_NAMES = ["CYCLES", "BUSY", "CMD_IN", "CMD_DONE", "BEAT_IN", "BEAT_OUT", "ELEM_IN", "ELEM_OUT", "STALL_LANE", "STALL_TRK", "LANE_STALL",
            "OPND_STARVE", "RES_BP", "COLL_WAIT", "RED_WAIT", "CPL_BP"]
PC_EXACT = ["CYCLES", "BUSY", "CMD_IN", "CMD_DONE", "BEAT_IN", "BEAT_OUT", "ELEM_IN", "RES_BP", "CPL_BP"]


class ArrayMonitor(Agent):
    def __init__(self, name: str, env: Env, p: ArrayParams, *, cmd_depth: int, perf_en: bool = True, perf_cw: int = 32):
        super().__init__(name)
        s = env.sig
        self.p, self.n, self.vl_w = p, p.n, p.vl_w
        self.cmd_depth, self.perf_en, self.perf_cw = cmd_depth, perf_en, perf_cw
        self.i = {k: s(k) for k in ("cmd_valid_i", "cmd_op_i", "cmd_rm_i", "cmd_vl_i", "cmd_vm_i", "cmd_bcast_i", "cmd_scalar_i", "cmd_red_i", "cmd_tid_i",
                                    "opnd_valid_i", "res_ready_i", "cpl_ready_i", "lane_hold_i", "perf_clear_i")}
        self.o = {k: s(k) for k in ("cmd_ready_o", "opnd_ready_o", "res_valid_o", "res_data_o", "res_flags_o", "res_mask_o", "res_tid_o", "res_beat_o", "res_last_o",
                                    "cpl_valid_o", "cpl_tid_o", "cpl_flags_o", "cpl_illegal_o", "cpl_count_o", "cpl_red_o", "cpl_result_o", "busy_o", "perf_cnt_o")}
        self.sb = Scoreboard(env, name)
        self.pending_jobs: Deque[Job] = deque()  # submitted, not yet accepted
        self.exp_beats: Deque = deque()  # (job, ExpBeat)
        self.cpl_q: Deque = deque()  # (job, beats_end)
        self.beat_owner: Deque = deque()  # (job, g, cmd_accept_edge) for the operand stream
        self.beats_total_expected = 0  # beats of accepted commands so far (result-stream cumulative)
        self.res_consumed = 0
        self.beats_cap = 0  # operand beats the accepted commands may consume
        self.beats_in = 0
        self.seq = 0
        self.checks = 0
        self.age = 0  # cycles since reset release
        self.prev_res = None
        self.prev_cpl = None
        self.t_cmd: List[int] = []
        self.t_opnd: List[int] = []
        self.t_res: List[int] = []
        self.t_cpl: List[int] = []
        self.last_cmd_edge = -10
        self.last_cmd: Optional[Cmd] = None
        self.outstanding = 0
        self.res_bp_run = self.cpl_bp_run = self.cmd_low_run = self.opnd_wait_run = 0
        self.max_outstanding = 0
        self.n_cpl = 0
        self.n_res = 0
        self.hold_hist: Dict[int, int] = {}
        self.first_valid_edge: Optional[int] = None
        self.last_opnd_edge = -10
        self.pc_model = {k: 0 for k in PC_NAMES}
        self.pc_prev = {k: 0 for k in PC_NAMES}
        self.elem_dirty = False
        self.elem_out_obs = 0
        self.quiescent_checks = 0
        self.cyc_in_reset = False
        self.log: Deque[str] = deque(maxlen=12)
        self._init_cov()

    # ----------------------------------------------------------------------------------- coverage
    def _init_cov(self) -> None:
        p, n = self.p, self.n
        legal = list(F.ALL_LEGAL_OPS)
        ops = {F.OP_NAMES[o]: o for o in legal}
        ops["ILLEGAL"] = lambda v: v not in F.ALL_LEGAL_OPS
        vlc = {"max": lambda v: v == (1 << self.vl_w) - 1, "0": 0, "1": 1}  # 'max' first: the first matching bin wins
        if n > 2:
            vlc["lt_N"] = lambda v: 1 < v < n
        if n > 1:
            vlc["eq_N"] = lambda v: v == n
            vlc["N+1"] = lambda v: v == n + 1
        vlc["mult_N"] = lambda v: v > n + 1 and v % n == 0
        vlc["nonmult_gt_N"] = lambda v: v > n + 1 and v % n != 0
        cc = CoverGroup("arr_cmd", "command fields: op x rm x red x vm x bcast x vl class")
        cc.point("op", ops)
        cc.point("rm", {"RNE": 0, "RTZ": 1, "RDN": 2, "RUP": 3, "RMM": 4, "illegal5-7": (5, 7)})
        cc.point("red", [0, 1])
        cc.point("vm", [0, 1])
        cc.point("bcast", list(range(8)))
        cc.point("vl_class", vlc)
        cc.cross("op_x_rm", ["op", "rm"])
        cc.cross("vl_x_vm_x_red", ["vl_class", "vm", "red"])
        cc.cross("bcast_x_red", ["bcast", "red"])
        self.cg_cmd = cc
        ce = CoverGroup("arr_errors", "illegal command kinds x vl")
        kinds = ["reserved_op", "bad_rm", "legal"]
        if p.red_en:
            kinds += ["red_nonfp_op", "red_bad_rm", "red_bcast"]
        else:
            kinds.append("red_disabled")
        if not p.lane.en_fcmp:
            kinds.append("fcmp_disabled")
        if not p.lane.en_int:
            kinds.append("int_disabled")
        ce.point("kind", kinds)
        ce.point("vl0", {"zero": 0, "nonzero": lambda v: v > 0})
        ce.cross("kind_x_vl", ["kind", "vl0"])
        self.cg_err = ce
        cch = CoverGroup("arr_config_change", "configuration change between back-to-back (consecutive-edge) commands")
        cch.point("field", ["rm", "op", "vl", "vm", "tid", "red", "bcast", "scalar", "none"])
        cch.point("gap", {"b2b": 1, "gap2-3": (2, 3), "gap4+": (4, 100000)})
        cch.cross("field_x_gap", ["field", "gap"])
        self.cg_chg = cch
        cp = CoverGroup("arr_pressure", "backpressure durations, queue depth, concurrency")
        cp.point("res_bp_run", {"1": 1, "2-3": (2, 3), "4-7": (4, 7), "8-15": (8, 15), "16+": (16, 100000)})
        cp.point("cpl_bp_run", {"1": 1, "2-3": (2, 3), "4-7": (4, 7), "8-15": (8, 15), "16+": (16, 100000)})
        cp.point("cmd_stall_run", {"1": 1, "2-7": (2, 7), "8-31": (8, 31), "32+": (32, 100000)})
        cp.point("opnd_stall_run", {"1": 1, "2-7": (2, 7), "8-31": (8, 31), "32+": (32, 100000)})
        cp.point("outstanding", {"0": 0, "1": 1, "2": 2, "3-4": (3, 4), "5+": (5, 1000)})
        cp.point("event", ["cmd_queue_full", "res_stalled_with_next_cmd", "cpl_held_while_res_flows", "opnd_valid_before_cmd"] + (["red_with_elementwise_in_flight", "two_reductions_in_flight"] if p.red_en else []))
        self.cg_press = cp
        cl = CoverGroup("arr_lanes", "active lanes per beat and per-lane activity, hold patterns")
        cl.point("active_lanes", list(range(n + 1)))
        cl.point("lane_active", list(range(n)))
        cl.point("lanes_held", list(range(n + 1)))
        lf = {"add": [F.OP_FADD, F.OP_FSUB], "mul": F.OP_FMUL, "fma": list(F.FMA_OPS), "mv": F.OP_FMV}
        if p.lane.en_fcmp:
            lf["cmp"] = list(F.FCMP_OPS)
        if p.lane.en_int:
            lf["int"] = list(F.INT_OPS)
        cl.point("fam", lf)
        cl.point("cls", ["zero", "subnormal", "tiny_normal", "normal", "huge", "inf", "qnan", "snan"])
        cl.cross("fam_x_cls", ["fam", "cls"])
        self.cg_lane = cl
        cr = CoverGroup("arr_reset", "context in which reset hit")
        cr.point("ctx", ["idle", "cmd_queued", "beats_in_flight", "result_stalled", "cpl_stalled"] + (["reduction_in_flight"] if p.red_en else []))
        self.cg_rst = cr
        cx = CoverGroup("arr_reduction", "reduction shapes (only when the configuration has a reduction unit)")
        cx.point("flags", {"none": lambda f: f == 0, "NV": lambda f: bool(f & F.NV), "OF": lambda f: bool(f & F.OF), "NX": lambda f: bool(f & F.NX), "UF": lambda f: bool(f & F.UF)})
        cx.point("count", {"0": 0, "1": 1, "gt1": lambda c: c > 1})
        cx.point("op", {"FMV": 0, "FADD": 1, "FSUB": 2, "FMUL": 3, "FMA": [4, 5, 6, 7]})
        cx.point("rm", [0, 1, 2, 3, 4])
        cx.cross("op_x_rm", ["op", "rm"])
        self.cg_red = cx

    def attach(self, env: Env) -> None:
        super().attach(env)
        for g in (self.cg_cmd, self.cg_err, self.cg_chg, self.cg_press, self.cg_lane, self.cg_rst) + ((self.cg_red,) if self.p.red_en else ()):
            env.coverage.append(g)

    # ----------------------------------------------------------------------------------- helpers
    def submit(self, job: Job) -> None:
        self.pending_jobs.append(job)

    def _eq(self, what: str, exp, got) -> None:
        self.checks += 1
        if exp != got:
            self.env.error("%s: %s mismatch: expected 0x%x got 0x%x | recent: %s" % (self.name, what, exp, got, " ; ".join(self.log)))

    def _expect(self, cond: bool, msg: str) -> None:
        self.checks += 1
        if not cond:
            self.env.error("%s: %s | recent: %s" % (self.name, msg, " ; ".join(self.log)))

    def _illegal_kind(self, c: Cmd) -> str:
        p = self.p
        if c.red:
            if not p.red_en:
                return "red_disabled"
            if not (0 <= c.op <= 7):
                return "red_nonfp_op"
            if not F.rm_legal(c.rm):
                return "red_bad_rm"
            if c.bcast:
                return "red_bcast"
            return "legal"
        if c.op not in F.ALL_LEGAL_OPS:
            return "reserved_op"
        if c.op in F.ROUNDING_OPS and not F.rm_legal(c.rm):
            return "bad_rm"
        if c.op in F.FCMP_OPS and not p.lane.en_fcmp:
            return "fcmp_disabled"
        if c.op in F.INT_OPS and not p.lane.en_int:
            return "int_disabled"
        return "legal"

    # ----------------------------------------------------------------------------------- reset
    def on_reset(self, asserted: bool) -> None:
        if asserted:
            if self.env.cycle > 6:
                ctx = "idle"
                if self.outstanding:
                    ctx = "cmd_queued"
                    if self.beats_in > 0 and self.beat_owner:
                        ctx = "beats_in_flight"
                    if self.prev_res is not None:
                        ctx = "result_stalled"
                    if self.prev_cpl is not None:
                        ctx = "cpl_stalled"
                    if any(j.cmd.red for j, _ in self.cpl_q):
                        ctx = "reduction_in_flight"
                self.cg_rst.sample(ctx=ctx)
            self.sb.cancel(reason="reset")
            self._flush()

    def _flush(self) -> None:
        self.pending_jobs.clear()
        self.exp_beats.clear()
        self.cpl_q.clear()
        self.beat_owner.clear()
        self.beats_total_expected = self.res_consumed = self.beats_cap = self.beats_in = 0
        self.prev_res = self.prev_cpl = None
        self.outstanding = 0
        self.first_valid_edge = None
        self.res_bp_run = self.cpl_bp_run = 0
        self.age = 0
        for k in self.pc_model:
            self.pc_model[k] = 0
        self.elem_dirty = False
        self.last_cmd = None

    # ----------------------------------------------------------------------------------- per-cycle
    def sample(self) -> None:
        env, p, n = self.env, self.p, self.n
        t = env.cycle
        i = {k: v.read() for k, v in self.i.items()}
        o = {k: v.read() for k, v in self.o.items()}
        in_rst = env.in_reset
        hold_now = i["lane_hold_i"]
        self.hold_hist[t] = hold_now
        self.hold_hist.pop(t - 64, None)
        if in_rst:
            for k in ("cmd_ready_o", "opnd_ready_o", "res_valid_o", "cpl_valid_o", "busy_o", "res_data_o", "res_flags_o", "res_mask_o", "res_tid_o", "res_beat_o",
                      "res_last_o", "cpl_tid_o", "cpl_flags_o", "cpl_illegal_o", "cpl_count_o", "cpl_red_o", "cpl_result_o", "perf_cnt_o"):
                self._eq("%s during reset" % k, 0, o[k])
            self._flush()
            return
        age = self.age
        # ----- registered-interface rules after reset release
        if age == 0:
            self._eq("cmd_ready_o in the first cycle after reset", 0, o["cmd_ready_o"])
            self._eq("opnd_ready_o in the first cycle after reset", 0, o["opnd_ready_o"])
        # ----- outputs with valid low must be all zero
        if not o["res_valid_o"]:
            for k in ("res_data_o", "res_flags_o", "res_mask_o", "res_tid_o", "res_beat_o", "res_last_o"):
                self._eq("%s while res_valid_o = 0" % k, 0, o[k])
        if not o["cpl_valid_o"]:
            for k in ("cpl_tid_o", "cpl_flags_o", "cpl_illegal_o", "cpl_count_o", "cpl_red_o", "cpl_result_o"):
                self._eq("%s while cpl_valid_o = 0" % k, 0, o[k])
        # ----- busy
        if self.outstanding or o["res_valid_o"] or o["cpl_valid_o"]:
            self._eq("busy_o while a command is outstanding", 1, o["busy_o"])
        # ----- completion record (checked from the first cycle it is presented), BEFORE this cycle's results are consumed
        cpl_hs = bool(o["cpl_valid_o"] and i["cpl_ready_i"])
        res_hs = bool(o["res_valid_o"] and i["res_ready_i"])
        cur_cpl = (o["cpl_valid_o"], o["cpl_tid_o"], o["cpl_flags_o"], o["cpl_illegal_o"], o["cpl_count_o"], o["cpl_red_o"], o["cpl_result_o"])
        if self.prev_cpl is not None:
            self._expect(cur_cpl == self.prev_cpl, "completion record changed / withdrawn while cpl_valid_o && !cpl_ready_i")
        self.prev_cpl = cur_cpl if (o["cpl_valid_o"] and not i["cpl_ready_i"]) else None
        if o["cpl_valid_o"]:
            if not self.cpl_q:
                env.error("%s: spurious completion record (nothing outstanding) tid=%d" % (self.name, o["cpl_tid_o"]))
            job, beats_end = self.cpl_q[0]
            self._expect(self.res_consumed >= beats_end, "completion presented before the last result beat of its command was handed over (consumed %d < %d)" % (self.res_consumed, beats_end))
            c = job.exp.cpl
            self._eq("cpl_tid", c.tid, o["cpl_tid_o"])
            self._eq("cpl_flags", c.flags, o["cpl_flags_o"])
            self._eq("cpl_illegal", c.illegal, o["cpl_illegal_o"])
            self._eq("cpl_count", c.count, o["cpl_count_o"])
            self._eq("cpl_red", c.red, o["cpl_red_o"])
            self._eq("cpl_result", c.result, o["cpl_result_o"])
        # ----- result beat
        cur_res = (o["res_valid_o"], o["res_data_o"], o["res_flags_o"], o["res_mask_o"], o["res_tid_o"], o["res_beat_o"], o["res_last_o"])
        if self.prev_res is not None:
            self._expect(cur_res == self.prev_res, "result beat changed / withdrawn while res_valid_o && !res_ready_i")
        self.prev_res = cur_res if (o["res_valid_o"] and not i["res_ready_i"]) else None
        if o["res_valid_o"]:
            if not self.exp_beats:
                env.error("%s: spurious result beat (nothing expected) tid=%d beat=%d" % (self.name, o["res_tid_o"], o["res_beat_o"]))
            job, eb = self.exp_beats[0]
            ctx = "cmd op=0x%x rm=%d vl=%d vm=%d bc=%d red=%d tid=%d beat=%d" % (job.cmd.op, job.cmd.rm, job.cmd.vl, job.cmd.vm, job.cmd.bcast, job.cmd.red, job.cmd.tid, eb.beat)
            self._eq("res_tid [%s]" % ctx, eb.tid, o["res_tid_o"])
            self._eq("res_beat [%s]" % ctx, eb.beat, o["res_beat_o"])
            self._eq("res_last [%s]" % ctx, eb.last, o["res_last_o"])
            self._eq("res_mask [%s]" % ctx, eb.mask, o["res_mask_o"])
            for l in range(n):
                d = (o["res_data_o"] >> (32 * l)) & M32
                fl = (o["res_flags_o"] >> (5 * l)) & 31
                self._eq("res_data lane %d [%s]" % (l, ctx), eb.data[l], d)
                self._eq("res_flags lane %d [%s]" % (l, ctx), eb.flags[l], fl)
        # ----- command handshake
        cmd_hs = bool(i["cmd_valid_i"] and o["cmd_ready_o"])
        if cmd_hs:
            if not self.pending_jobs:
                env.error("%s: command accepted that the test never submitted" % self.name)
            cjob = self.pending_jobs.popleft()
            c = cjob.cmd
            self._eq("cmd_op presented", c.op, i["cmd_op_i"])
            self._eq("cmd_vl presented", c.vl, i["cmd_vl_i"])
            self._eq("cmd_tid presented", c.tid, i["cmd_tid_i"])
        # ----- operand handshake
        opnd_hs = bool(i["opnd_valid_i"] and o["opnd_ready_o"])
        if i["opnd_valid_i"] and self.first_valid_edge is None:
            self.first_valid_edge = t
        act_elems = 0
        if opnd_hs:
            self.log.append("t%d opnd_hs" % t)
            self.beats_in += 1
            self._expect(self.beats_in <= self.beats_cap, "operand beat accepted beyond the beats of the accepted commands (framing: ceil(vl/N) per command)")
            if self.beat_owner:
                job, g, cmd_edge = self.beat_owner.popleft()
                act_elems = job.act_counts[g]
                self.log.append("t%d beat op=%x vl=%d vm=%d g=%d act=%d mask=%x legal=%d" % (t, job.cmd.op, job.cmd.vl, job.cmd.vm, g, act_elems, job.beats[g].mask, job.legal))
                self._check_hold(job, g, t, max(self.last_opnd_edge + 1, cmd_edge + 1, self.first_valid_edge if self.first_valid_edge is not None else t))
                self.last_opnd_edge = t
                self.first_valid_edge = None
                for l in range(n):
                    if (active_mask(job.cmd, job.beats[g], g, n, job.legal) >> l) & 1:
                        self.cg_lane.sample(lane_active=l)
                am = bin(active_mask(job.cmd, job.beats[g], g, n, job.legal)).count("1")
                self.cg_lane.sample(active_lanes=am)
        # ----- handshake processing (state updates)
        busy_obs = o["busy_o"]
        if res_hs:
            job, eb = self.exp_beats.popleft()
            self.res_consumed += 1
            self.n_res += 1
            self.t_res.append(t)
            env.digest.event("arr.res", t, o["res_data_o"], o["res_flags_o"], o["res_mask_o"], o["res_tid_o"], o["res_beat_o"], o["res_last_o"])
        if cpl_hs:
            job, beats_end = self.cpl_q.popleft()
            self.sb.complete("cmd", job.seq)
            self.outstanding -= 1
            self.n_cpl += 1
            self.t_cpl.append(t)
            c = job.exp.cpl
            if job.cmd.red and job.legal:
                self.cg_red.sample(flags=c.flags, count=c.count, op=job.cmd.op, rm=job.cmd.rm)
                for bit in (F.NV, F.OF, F.UF, F.NX):  # first matching bin wins: sample every raised flag on its own as well
                    if c.flags & bit:
                        self.cg_red.sample(flags=bit)
            env.digest.event("arr.cpl", t, o["cpl_tid_o"], o["cpl_flags_o"], o["cpl_illegal_o"], o["cpl_count_o"], o["cpl_red_o"], o["cpl_result_o"])
        if cmd_hs:
            self.seq += 1
            cjob.seq = self.seq
            self.sb.accept("cmd", cjob.seq, cjob)
            self.exp_beats.extend((cjob, b) for b in cjob.exp.beats)
            self.beats_total_expected += len(cjob.exp.beats)
            self.cpl_q.append((cjob, self.beats_total_expected))
            nb = nbeats(cjob.cmd.vl, n)
            for g in range(nb):
                self.beat_owner.append((cjob, g, t))
            self.beats_cap += nb
            self.outstanding += 1
            self.max_outstanding = max(self.max_outstanding, self.outstanding)
            self.t_cmd.append(t)
            self._cov_cmd(cjob, t)
        if opnd_hs:
            self.t_opnd.append(t)
        # ----- run-length coverage and misc
        self._cov_runs(i, o, cmd_hs, opnd_hs, t)
        # ----- performance counters
        self._perf(i, o, cmd_hs, cpl_hs, opnd_hs, res_hs, act_elems, busy_obs)
        self.age += 1

    # ----------------------------------------------------------------------------------- hold contract
    def _check_hold(self, job: Job, g: int, edge: int, start: int) -> None:
        """A beat cannot be released while a live lane was held in EVERY interval in which it could have taken its
        element (interval ending at edge e uses the hold value sampled at edge e-1)."""
        if not job.legal:
            return
        n = self.n
        for l in range(n):
            if g * n + l >= job.cmd.vl:
                continue
            held_all = True
            for e in range(start, edge + 1):
                h = self.hold_hist.get(e - 1)
                if h is None or not (h >> l) & 1:
                    held_all = False
                    break
            if held_all:
                self.env.error("%s: operand beat %d of command tid=%d released at edge %d although live lane %d was held in every interval since edge %d (lane_hold contract)" % (self.name, g, job.cmd.tid, edge, l, start))

    # ----------------------------------------------------------------------------------- coverage
    def _cov_cmd(self, job: Job, t: int) -> None:
        c = job.cmd
        self.cg_cmd.sample(op=c.op, rm=c.rm, red=c.red, vm=c.vm, bcast=c.bcast, vl_class=c.vl)
        self.cg_err.sample(kind=self._illegal_kind(c), vl0=c.vl)
        if self.last_cmd is not None:
            lc = self.last_cmd
            gap = t - self.last_cmd_edge
            for f, a, b in (("rm", lc.rm, c.rm), ("op", lc.op, c.op), ("vl", lc.vl, c.vl), ("vm", lc.vm, c.vm), ("tid", lc.tid, c.tid), ("red", lc.red, c.red),
                            ("bcast", lc.bcast, c.bcast), ("scalar", lc.scalar, c.scalar)):
                if a != b:
                    self.cg_chg.sample(field=f, gap=gap)
            if lc == c:
                self.cg_chg.sample(field="none", gap=gap)
        self.last_cmd, self.last_cmd_edge = c, t
        if job.legal:
            fam = c.op
            nbt = len(job.beats)
            for g in range(nbt):
                am = active_mask(c, job.beats[g], g, self.n, True)
                for l in range(self.n):
                    if (am >> l) & 1:
                        a = c.scalar if c.bcast & 1 else job.beats[g].a[l]
                        b = c.scalar if c.bcast & 2 else job.beats[g].b[l]
                        if fam in (F.OP_FADD, F.OP_FSUB, F.OP_FMUL, *F.FMA_OPS, *F.FCMP_OPS, F.OP_FMV, *F.INT_OPS):
                            self.cg_lane.sample(fam=fam, cls=F.value_class(a))
        if self.outstanding > 1 and c.red and any(not j.cmd.red for j, _ in self.cpl_q):
            self.cg_press.sample(event="red_with_elementwise_in_flight")
        if sum(1 for j, _ in self.cpl_q if j.cmd.red) >= 2:
            self.cg_press.sample(event="two_reductions_in_flight")

    def _cov_runs(self, i, o, cmd_hs, opnd_hs, t) -> None:
        cg = self.cg_press
        if o["res_valid_o"] and not i["res_ready_i"]:
            self.res_bp_run += 1
            if self.outstanding > 1 or self.pending_jobs:
                cg.sample(event="res_stalled_with_next_cmd")
        elif self.res_bp_run:
            cg.sample(res_bp_run=self.res_bp_run)
            self.res_bp_run = 0
        if o["cpl_valid_o"] and not i["cpl_ready_i"]:
            self.cpl_bp_run += 1
            if o["res_valid_o"] and i["res_ready_i"]:
                cg.sample(event="cpl_held_while_res_flows")
        elif self.cpl_bp_run:
            cg.sample(cpl_bp_run=self.cpl_bp_run)
            self.cpl_bp_run = 0
        if i["cmd_valid_i"] and not o["cmd_ready_o"] and self.age > 0:
            self.cmd_low_run += 1
            if self.cmd_low_run == 1:
                cg.sample(event="cmd_queue_full")
        elif self.cmd_low_run:
            cg.sample(cmd_stall_run=self.cmd_low_run)
            self.cmd_low_run = 0
        if i["opnd_valid_i"] and not o["opnd_ready_o"]:
            self.opnd_wait_run += 1
            if not self.outstanding:
                cg.sample(event="opnd_valid_before_cmd")
        elif self.opnd_wait_run:
            cg.sample(opnd_stall_run=self.opnd_wait_run)
            self.opnd_wait_run = 0
        cg.sample(outstanding=self.outstanding)
        self.cg_lane.sample(lanes_held=bin(i["lane_hold_i"]).count("1"))

    # ----------------------------------------------------------------------------------- performance counters
    def _perf(self, i, o, cmd_hs, cpl_hs, opnd_hs, res_hs, act_elems, busy_obs) -> None:
        cw = self.perf_cw
        raw = o["perf_cnt_o"]
        obs = {PC_NAMES[k]: (raw >> (k * cw)) & ((1 << cw) - 1) for k in range(16)}
        sat = (1 << cw) - 1
        if not self.perf_en:
            self._eq("perf_cnt_o with PERF_EN = 0", 0, raw)
            return
        if True:
            for k in PC_EXACT:
                self._eq("perf counter %s" % k, self.pc_model[k], obs[k])
            # counters we cannot predict from the ports: monotone between clears, never above the cycle counter's scale
            for k in PC_NAMES:
                if k not in PC_EXACT:
                    self._expect(obs[k] >= self.pc_prev[k] or self.pc_model["CYCLES"] == 0, "perf counter %s decreased (%d -> %d) without a clear" % (k, self.pc_prev[k], obs[k]))
            if self.age == 0:
                for k in PC_NAMES:
                    self._eq("perf counter %s after reset" % k, 0, obs[k])
            # ELEM_OUT == ELEM_IN whenever the array is idle and no clear caught work in flight
            if self.outstanding == 0 and not self.exp_beats and busy_obs == 0 and not self.elem_dirty and not o["cpl_valid_o"]:
                self._eq("ELEM_OUT at quiescence (== ELEM_IN)", obs["ELEM_IN"], obs["ELEM_OUT"])
                self.quiescent_checks += 1
        self.pc_prev = obs
        self.log.append("t%d ELEM_IN obs=%d model=%d" % (self.env.cycle, obs["ELEM_IN"], self.pc_model["ELEM_IN"]))
        if i["perf_clear_i"]:
            if self.outstanding or o["res_valid_o"] or o["cpl_valid_o"]:
                self.elem_dirty = True  # work in flight: ELEM_IN / ELEM_OUT are inconsistent until the next clear at quiescence
            elif busy_obs == 0:
                self.elem_dirty = False
            for k in self.pc_model:
                self.pc_model[k] = 0
            return
        m = self.pc_model
        inc = {"CYCLES": 1, "BUSY": busy_obs, "CMD_IN": int(cmd_hs), "CMD_DONE": int(cpl_hs), "BEAT_IN": int(opnd_hs), "BEAT_OUT": int(res_hs), "ELEM_IN": act_elems,
               "RES_BP": int(bool(o["res_valid_o"] and not i["res_ready_i"])), "CPL_BP": int(bool(o["cpl_valid_o"] and not i["cpl_ready_i"]))}
        for k, v in inc.items():
            m[k] = min(sat, m[k] + v)

    def finalize(self) -> None:
        self.sb.finalize(allow_outstanding=True)

    def summary(self) -> dict:
        d = self.sb.summary()
        d["checks"] += self.checks
        d.update(commands=self.n_cpl, beats_out=self.n_res, max_outstanding=self.max_outstanding, quiescent_elem_checks=self.quiescent_checks)
        return d


