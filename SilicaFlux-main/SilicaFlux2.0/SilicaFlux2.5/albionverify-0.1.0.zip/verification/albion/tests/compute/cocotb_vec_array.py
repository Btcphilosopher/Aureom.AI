"""AlbionVerify bench: hpc_vector_array (NUM_LANES parallel lanes behind issue controller / collector / reduction unit).

Every result beat and completion record is compared against albionverify.models.vec_array (independent model: framing,
masks, broadcast, legality, exact IEEE-754 element arithmetic, documented reduction association order), including the
strict protocol rules of docs/ARRAY_INTERFACE.md (ordering, completion after data, payload stability, zero payload
when not valid, registered-interface behaviour after reset, framing, busy, lane_hold contract, performance counters).
"""
import json
import os

import cocotb

from albionverify.core import Env
from albionverify.models import vec_fp32 as F
from albionverify.models.vec_array import ArrayParams, Beat, Cmd, elementwise_result_latency, nbeats, reduction_latency
from albionverify.models.vec_lane import LaneParams
from albionverify.reset import ResetSequencer

from compute.varr_agents import ArrayMonitor, CmdDriver, HoldDriver, OpndDriver, PerfClearDriver, ReadySink, make_job
from compute.varr_vectors import ARITH_OPS, garbage, gen_beats, rand_cmd, vl_choice

P = json.loads(os.environ.get("ALBION_PARAMS", "{}"))
N = P.get("NUM_LANES", 2)
LP = LaneParams(rob_depth=P.get("LANE_ROB_DEPTH", 8), lat_fadd=P.get("LAT_FADD", 3), lat_fmul=P.get("LAT_FMUL", 3), lat_fma=P.get("LAT_FMA", 4),
                lat_misc=P.get("LAT_MISC", 1), lat_imul=P.get("LAT_IMUL", 2), en_fcmp=bool(P.get("EN_FCMP", 1)), en_int=bool(P.get("EN_INT", 1)))
AP = ArrayParams(n=N, vl_w=P.get("VL_W", 16), tid_w=P.get("TID_W", 8), red_en=bool(P.get("RED_EN", 1)), red_lat=P.get("RED_LAT", 3), lane=LP)
CMD_DEPTH = P.get("CMD_DEPTH", 4)
TRK_DEPTH = P.get("TRK_DEPTH", 8)
CPL_DEPTH = P.get("CPL_DEPTH", 4)
PERF_EN = bool(P.get("PERF_EN", 1))
PERF_CW = P.get("PERF_CW", 32)
FULL_RATE = TRK_DEPTH >= max(LP.lat_fadd, LP.lat_fmul, LP.lat_fma, LP.lat_imul) + 2 and LP.rob_depth >= max(LP.lat_fadd, LP.lat_fmul, LP.lat_fma) + 2 and CPL_DEPTH >= 4


class Bench:
    def __init__(self, dut, *, cmd_thr="always", opnd_thr="always", res_thr="always", cpl_thr="always", hold="none"):
        seed = int(os.environ.get("ALBION_SEED", "1"))
        self.env = env = Env(dut, clk="clk_i", name="vec_array", seed=seed)
        self.rst = env.add(ResetSequencer("rst", env.sig("rst_ni"), active_low=True, initial_cycles=4))
        s = env.seeds
        self.cmd = env.add(CmdDriver("cmd", env, s.child("cmd"), AP.vl_w, AP.tid_w, cmd_thr))
        self.opnd = env.add(OpndDriver("opnd", env, s.child("opnd"), N, opnd_thr))
        self.res = env.add(ReadySink("res", env, "res_ready_i", s.child("res"), res_thr))
        self.cpl = env.add(ReadySink("cpl", env, "cpl_ready_i", s.child("cpl"), cpl_thr))
        self.hold = env.add(HoldDriver("hold", env, N, s.child("hold"), hold))
        self.pclr = env.add(PerfClearDriver("pclr", env))
        self.mon = env.add(ArrayMonitor("mon", env, AP, cmd_depth=CMD_DEPTH, perf_en=PERF_EN, perf_cw=PERF_CW))
        self.rng = s.child("gen")
        self.n_jobs = 0

    async def start(self):
        await self.env.start()
        await self.env.until(lambda: not self.rst.asserted, 50, "reset release")

    def submit(self, cmd: Cmd, beats=None, **gk):
        if beats is None:
            beats = gen_beats(self.rng, cmd, AP, **gk)
        job = make_job(cmd, beats, AP)
        self.mon.submit(job)
        self.cmd.submit(cmd)
        for b in beats:
            self.opnd.submit(b)
        self.n_jobs += 1
        return job

    def gen(self, n, **kw):
        for _ in range(n):
            self.submit(rand_cmd(self.rng, AP, **kw))

    @property
    def quiet(self) -> bool:
        m = self.mon
        return self.cmd.idle and self.opnd.idle and not m.pending_jobs and m.outstanding == 0

    async def drain(self, limit=40000):
        await self.env.until(lambda: self.quiet, limit, "all commands completed")
        await self.env.cycles(5)
        # the array must be idle again
        self.env.check(self.env.sig("busy_o").read() == 0, "busy_o still high after all commands completed")

    def finish(self, name, **extra):
        self.mon.finalize()
        self.env.finalize()
        self.env.write_result(name, scoreboard=self.mon.summary(), jobs=self.n_jobs, **extra)


VMAX = (1 << AP.vl_w) - 1


def cm(op, vl, rm=0, vm=0, bcast=0, scalar=0, red=0, tid=1):
    return Cmd(op, rm, min(vl, VMAX), vm, bcast, scalar, red, tid)  # small VL_W configurations: clip to the legal range


# ============================================================================================ directed
@cocotb.test()
async def directed_elementwise(dut):
    """FADD / FMUL / FMADD (mandatory) and every other element op: vl = 0, 1, N-1, N, N+1, multiples, non-multiples;
    masks; broadcast; all rounding modes; garbage in tail / masked / broadcast / unused operand positions."""
    b = Bench(dut)
    await b.start()
    rng = b.rng
    vls = sorted({min(v, VMAX) for v in (0, 1, max(1, N - 1), N, N + 1, 2 * N, 2 * N + 1, 3 * N - 1, 3 * N, 5 * N + 3, 7 * N)})
    tid = 0
    for op in ARITH_OPS + list(F.FCMP_OPS) + list(F.INT_OPS):
        if (op in F.FCMP_OPS and not LP.en_fcmp) or (op in F.INT_OPS and not LP.en_int):
            continue
        for vl in vls:
            tid += 1
            b.submit(cm(op, vl, rm=rng.randint(0, 4), vm=rng.getrandbits(1), bcast=rng.choice([0, 0, 1, 2, 4, 3, 7]), scalar=garbage(rng) if rng.random() < 0.3 else rng.getrandbits(32), tid=tid & 0xFF))
    for rm in range(5):
        for op in (F.OP_FADD, F.OP_FMUL, F.OP_FMADD):
            for vm in (0, 1):
                tid += 1
                b.submit(cm(op, 4 * N + 1, rm=rm, vm=vm, tid=tid & 0xFF))  # (clipped to VL_W)
    await b.drain(60000)
    b.finish("directed_elementwise")


@cocotb.test()
async def mask_vl_broadcast(dut):
    """Mask patterns (all-0, all-1, alternating, sparse, random) x vector lengths that are not a multiple of the lane
    count x every broadcast combination; masked / tail positions must read back data 0, flags 0, mask 0."""
    b = Bench(dut, cmd_thr="random:0.8", opnd_thr="random:0.8", res_thr="random:0.7", cpl_thr="random:0.7")
    await b.start()
    rng = b.rng
    for mm in ("all0", "all1", "alt", "sparse", "rand"):
        for bc in range(8):
            for vl in (1, N + 1, 3 * N - 1, 4 * N + 1):
                op = rng.choice([F.OP_FMADD, F.OP_FADD, F.OP_FMUL, F.OP_FNMSUB])
                b.submit(cm(op, vl, rm=rng.randint(0, 4), vm=1, bcast=bc, scalar=rng.getrandbits(32), tid=rng.getrandbits(8)), mask_mode=mm)
    for vl in (1, N + 1, 2 * N):  # vm = 0: mask bits are ignored even when garbage
        b.submit(cm(F.OP_FADD, vl, vm=0, tid=0xA5), mask_mode="all0")
    await b.drain(60000)
    b.finish("mask_vl_broadcast")


@cocotb.test()
async def reductions(dut):
    """Sum / dot-product reductions with the documented association order: FMV / FMUL / FADD / FSUB / FMA family, all
    rounding modes, initial values (+-0, finite, inf, NaN), masks, tails, vl = 0, operands engineered so that a
    different association gives different bits; cpl_red / cpl_result / aggregated flags / count."""
    b = Bench(dut, res_thr="random:0.8", cpl_thr="random:0.6")
    await b.start()
    if not AP.red_en:
        # RED_EN = 0: every reduction command is illegal (and still consumes its beats)
        for vl in (0, 1, N, 3 * N + 1):
            b.submit(cm(F.OP_FMV, vl, red=1, tid=vl))
            b.submit(cm(F.OP_FMUL, vl, red=1, vm=1, tid=vl + 1))
        b.gen(60, red=1)
        await b.drain(20000)
        b.finish("reductions")
        return
    rng = b.rng
    big, one = 0x4B800000, 0x3F800000  # 2^24, 1.0 : (2^24 + 1) ties to even, order-sensitive
    for vl in (0, 1, N, N + 1, 2 * N, 3 * N + 1, 6 * N):
        for rm in range(5):
            for op in (F.OP_FMV, F.OP_FMUL, F.OP_FADD):
                c = cm(op, vl, rm=rm, red=1, scalar=rng.choice([0, 0x80000000, one, 0x7F800000, 0x7FC00000, rng.getrandbits(32)]), tid=rng.getrandbits(8))
                beats = gen_beats(rng, c, AP, value_mode="moderate")
                for bt in beats:  # order-sensitive pattern: a big value followed by ones
                    bt.a = [big if (i % (N + 2)) == 0 else one for i in range(len(bt.a))] if rng.random() < 0.5 else bt.a
                    if op == F.OP_FMUL:
                        bt.b = [one] * N
                b.submit(c, beats)
    for op in (F.OP_FSUB, F.OP_FMADD, F.OP_FMSUB, F.OP_FNMSUB, F.OP_FNMADD):
        for rm in range(5):
            b.submit(cm(op, 3 * N + 2, rm=rm, red=1, scalar=rng.getrandbits(32), tid=rng.getrandbits(8)))
    for _ in range(80):
        b.submit(rand_cmd(rng, AP, red=1, illegal_frac=0.15))
    # underflow inside the element operation of a dot product (tiny x 0.5 ties: UF | NX) and in a vector sum of subnormals
    for rm in (0, 1, 3):
        c = cm(F.OP_FMUL, 2 * N, rm=rm, red=1, scalar=0, tid=0x31)
        b.submit(c, [Beat([0x00000003] * N, [0x3F000000] * N, [0] * N, 0) for _ in range(2)])
        c = cm(F.OP_FMV, 2 * N, rm=rm, red=1, scalar=0x00000001, tid=0x32)
        b.submit(c, [Beat([0x00000001 + i for i in range(N)], [0] * N, [0] * N, 0) for _ in range(2)])
    # overflow / NaN / cancellation inside the tree and accumulator
    for sc in (0x7F7FFFFF, 0x7F800000, 0xFF800000, 0x7FA00000):
        b.submit(cm(F.OP_FMV, 2 * N, rm=rng.randint(0, 4), red=1, scalar=sc), [Beat([0x7F7FFFFF] * N, [0] * N, [0] * N, 0) for _ in range(2)])
    await b.drain(60000)
    b.finish("reductions")


@cocotb.test()
async def illegal_commands(dut):
    """Reserved opcodes, rm 5-7 on rounding ops, illegal reduction forms (non-FP op, rm > 4, broadcast, RED_EN = 0), removed
    compare / integer ops: still consume ceil(vl/N) beats, elementwise ones still emit all-zero result beats (mask 0),
    complete in order with cpl_illegal = 1 and count / flags / result 0 -- interleaved with legal commands."""
    b = Bench(dut, cmd_thr="random:0.8", opnd_thr="random:0.8", res_thr="random:0.8", cpl_thr="random:0.7")
    await b.start()
    rng = b.rng
    n_illegal = 0
    for i in range(160):
        r = rng.random()
        vl = vl_choice(rng, AP)
        if r < 0.15:
            c = cm(rng.choice([0x0D, 0x0E, 0x0F, 0x12, 0x1F, 0x15]), vl, rm=rng.getrandbits(3), vm=rng.getrandbits(1), tid=i & 0xFF)
        elif r < 0.30:
            c = cm(rng.choice(list(F.ROUNDING_OPS)), vl, rm=rng.choice([5, 6, 7]), vm=rng.getrandbits(1), tid=i & 0xFF)
        elif r < 0.42:
            c = cm(rng.choice([F.OP_FMIN, F.OP_FEQ, F.OP_IADD, F.OP_IMUL, 0x08]), vl, red=1, tid=i & 0xFF)
        elif r < 0.52:
            c = cm(rng.choice(ARITH_OPS), vl, rm=rng.choice([5, 6, 7]), red=1, tid=i & 0xFF)
        elif r < 0.62:
            c = cm(rng.choice(ARITH_OPS), vl, rm=rng.randint(0, 4), bcast=rng.randint(1, 7), red=1, scalar=rng.getrandbits(32), tid=i & 0xFF)
        elif r < 0.72:
            c = cm(rng.choice([F.OP_FEQ, F.OP_FLT, F.OP_IADD, F.OP_IMUL]), vl, tid=i & 0xFF)  # illegal only in lean configs
        else:
            c = rand_cmd(rng, AP, illegal_frac=0.0, vl=vl, tid=i & 0xFF)
        b.submit(c)
    for c in (cm(0x0D, 0, rm=1, tid=0x91), cm(F.OP_FADD, 0, rm=6, tid=0x92), cm(F.OP_FMIN, 0, red=1, tid=0x93), cm(F.OP_FMV, 0, rm=5, red=1, tid=0x94),
              cm(F.OP_FMV, 0, bcast=2, red=1, tid=0x95), cm(F.OP_FEQ, 0, tid=0x96), cm(F.OP_IMUL, 0, tid=0x97), cm(F.OP_FMV, 0, red=1, tid=0x98)):
        b.submit(c)  # illegal commands with vl = 0 stay illegal and still complete in order
    await b.drain(60000)
    b.finish("illegal_commands")


@cocotb.test()
async def config_change_b2b(dut):
    """Back-to-back commands that change op, rounding mode, vl, mask mode, tid, broadcast, reduction between
    consecutive commands, with no idle cycle between them (clean handshakes)."""
    b = Bench(dut)
    await b.start()
    rng = b.rng
    prev = None
    for i in range(500):
        c = rand_cmd(rng, AP, illegal_frac=0.03)
        if prev is not None and rng.random() < 0.6:  # change exactly one field of the previous command
            f = rng.choice(["rm", "op", "vl", "vm", "tid", "red", "bcast", "scalar"])
            c = Cmd(c.op if f == "op" else prev.op, rng.randint(0, 4) if f == "rm" else prev.rm, c.vl if f == "vl" else prev.vl,
                    c.vm if f == "vm" else prev.vm, c.bcast if f == "bcast" else prev.bcast, c.scalar if f == "scalar" else prev.scalar,
                    c.red if f == "red" else prev.red, c.tid if f == "tid" else prev.tid)
            if c.vl > 6 * N:
                c = Cmd(c.op, c.rm, c.vl % (6 * N), c.vm, c.bcast, c.scalar, c.red, c.tid)
        if prev is not None and rng.random() < 0.08:
            c = prev  # an identical command right behind its twin (no configuration change at all)
        prev = c
        b.submit(c)
    await b.drain(80000)
    assert b.mon.cg_chg.n_samples > 100
    b.finish("config_change_b2b")


@cocotb.test()
async def latency_and_throughput(dut):
    """Documented timing on an idle array with always-ready consumers: operand beat -> result beat = LAT_unit + 2,
    result -> completion = 1, reduction latency (LAT_unit + 1) + TL + RED_LAT + 1 (TL = 1 + log2(N) * RED_LAT); back-to-back
    commands run at ceil(vl/N) cycles per command (full-rate configurations)."""
    b = Bench(dut)
    await b.start()
    m = b.mon
    rng = b.rng
    cases = [F.OP_FMV, F.OP_FADD, F.OP_FMUL, F.OP_FMADD, F.OP_IMUL if LP.en_int else F.OP_FSUB, F.OP_FMIN if LP.en_fcmp else F.OP_FNMADD]
    seen = {}
    for op in cases:
        for _ in range(2):
            c = cm(op, N, rm=0, tid=7)
            o0, r0, c0 = len(m.t_opnd), len(m.t_res), len(m.t_cpl)
            b.submit(c, gen_beats(rng, c, AP, mask_mode="all1", value_mode="moderate"))
            await b.drain(400)
            lat = m.t_res[r0] - m.t_opnd[o0]
            want = elementwise_result_latency(op, 0, AP)
            assert lat == want, "op 0x%x: operand->result latency %d, documented LAT_unit+2 = %d" % (op, lat, want)
            cl = m.t_cpl[c0] - m.t_res[r0]
            assert cl == 1, "result -> completion latency %d, documented 1" % cl
            seen[op] = lat
    if AP.red_en:
        for op in (F.OP_FMV, F.OP_FMUL):
            c = cm(op, N, red=1, tid=9, scalar=0)  # ONE beat: later beats queue behind the accumulator (one add per RED_LAT cycles)
            o0, c0 = len(m.t_opnd), len(m.t_cpl)
            b.submit(c, gen_beats(rng, c, AP, mask_mode="all1", value_mode="moderate"))
            await b.drain(400)
            lat = m.t_cpl[c0] - m.t_opnd[-1]
            want = reduction_latency(op, AP)
            assert lat == want, "reduction op 0x%x: last operand beat -> completion %d cycles, documented %d" % (op, lat, want)
    if FULL_RATE:
        # back-to-back commands of vl = 1 .. 4N: one operand beat per cycle, i.e. ceil(vl/N) cycles per command
        for vl in (1, N, N + 1, 3 * N):
            o0 = len(m.t_opnd)
            k = 24
            for i in range(k):
                c = cm(F.OP_FMADD, vl, tid=i)
                b.submit(c, gen_beats(rng, c, AP, mask_mode="all1", value_mode="moderate"))
            await b.drain(2000)
            ts = m.t_opnd[o0:]
            assert len(ts) == k * nbeats(vl, N)
            gaps = [ts[i + 1] - ts[i] for i in range(len(ts) - 1)]
            assert max(gaps) == 1, "operand beats not accepted on consecutive cycles in a back-to-back stream (vl=%d, gaps %s)" % (vl, sorted(set(gaps)))
    b.finish("latency_and_throughput", latencies={hex(k): v for k, v in seen.items()})


@cocotb.test()
async def queue_depth(dut):
    """Command queue depth / backpressure: with the operand stream withheld, exactly CMD_DEPTH commands wait in the queue
    behind the one being issued (docs: 'up to CMD_DEPTH commands can be queued ahead of the one being issued'); cmd_ready
    stays low; everything completes in order once operands arrive."""
    b = Bench(dut, opnd_thr="never")
    await b.start()
    rng = b.rng
    for i in range(CMD_DEPTH + 6):
        c = cm(rng.choice([F.OP_FADD, F.OP_FMUL, F.OP_FMADD]), rng.randint(1, 3 * N), vm=rng.getrandbits(1), tid=i)
        b.submit(c)
    await b.env.cycles(60)
    assert b.cmd.n_accepted == CMD_DEPTH + 1, "accepted %d commands with no operands; expected CMD_DEPTH + 1 = %d" % (b.cmd.n_accepted, CMD_DEPTH + 1)
    assert b.cmd.max_wait >= 40
    b.opnd.thr.set_mode("random:0.6")
    b.res.set_mode("random:0.5")
    b.cpl.set_mode("random:0.5")
    await b.drain(20000)
    b.finish("queue_depth")


@cocotb.test()
async def stalls_and_holds(dut):
    """Long result / completion backpressure (res_ready low for long runs, cpl_ready low while results flow, both low),
    per-lane holds (stuck lane, out-of-phase, bursty, all lanes) and operand starvation: lossless, in order, bit-exact."""
    b = Bench(dut)
    await b.start()
    rng = b.rng
    phases = [
        ("always", "stall:30", "always", "none"),
        ("always", "always", "stall:40", "none"),
        ("random:0.9", "bursty:10-40", "bursty:10-40", "none"),
        ("random:0.9", "random:0.9", "random:0.9", "stuck:%d" % (N - 1)),
        ("always", "always", "always", "phase"),
        ("random:0.7", "random:0.8", "random:0.8", "bursty:1-20"),
        ("always", "random:0.15", "random:0.15", "random:0.3"),
        ("random:0.3", "always", "always", "none"),  # starved operand stream
    ]
    for (ot, rt, ct, hm) in phases:
        b.opnd.thr.set_mode(ot)
        b.res.set_mode(rt)
        b.cpl.set_mode(ct)
        b.hold.set_mode(hm)
        for _ in range(14):
            b.submit(rand_cmd(rng, AP, illegal_frac=0.03, vl=min(vl_choice(rng, AP), 5 * N + 2)))
        await b.drain(40000)
    # all lanes held with traffic waiting: no operand beat can be released (needs live lanes) -- explicit window check
    b.hold.set_mode("none")
    b.res.set_mode("always")
    b.cpl.set_mode("always")
    c = cm(F.OP_FADD, 6 * N, tid=0x42)
    b.submit(c, gen_beats(rng, c, AP, mask_mode="all1", value_mode="moderate"))
    await b.env.cycles(2)
    t0 = b.env.cycle
    b.hold.set_mode("all")
    await b.env.cycles(30)
    n_in_window = len([t for t in b.mon.t_opnd if t0 + 4 <= t <= t0 + 30])
    assert n_in_window == 0, "%d operand beats accepted while every lane was held" % n_in_window
    b.hold.set_mode("none")
    await b.drain(2000)
    b.finish("stalls_and_holds")


@cocotb.test()
async def long_vector(dut):
    """vl = 2^VL_W - 1 (largest legal vector, nothing truncated) elementwise and as reduction; cpl_count = vl."""
    b = Bench(dut, res_thr="random:0.9", cpl_thr="random:0.9")
    await b.start()
    vmax = (1 << AP.vl_w) - 1
    rng = b.rng
    b.submit(cm(F.OP_FMADD, vmax, rm=2, vm=1, tid=0x77))
    b.submit(cm(F.OP_FADD, vmax - 1, tid=0x78))
    b.submit(cm(F.OP_FMUL, vmax, vm=0, tid=0x7A))
    if AP.red_en:
        c = cm(F.OP_FMUL, vmax, red=1, scalar=0x3F800000, tid=0x79)
        b.submit(c, gen_beats(rng, c, AP, mask_mode="all1", value_mode="moderate"))
        for vm in (0, 1):
            c = cm(F.OP_FMV, vmax, red=1, vm=vm, scalar=0, tid=0x7B)
            b.submit(c, gen_beats(rng, c, AP, value_mode="moderate"))
    await b.drain(60000)
    assert b.mon.n_res >= 2 * (vmax // N)
    b.finish("long_vector")


# ============================================================================================ random
RANDOM_PROFILES = [
    ("always", "always", "always", "always", "none"),
    ("random:0.6", "random:0.7", "random:0.55", "random:0.5", "none"),
    ("bursty:1-8", "bursty:1-10", "bursty:1-12", "bursty:1-9", "random:0.25"),
    ("random:0.9", "random:0.9", "random:0.12", "random:0.15", "bursty:1-16"),
    ("random:0.5", "random:0.5", "random:0.9", "random:0.9", "phase"),
    ("always", "random:0.8", "random:0.8", "random:0.8", "stuck:0"),
]


async def run_random(dut, name, per_phase, **extra):
    b = Bench(dut)
    await b.start()
    rng = b.rng
    for ph, (ct, ot, rt, pt, hm) in enumerate(RANDOM_PROFILES):
        b.cmd.thr.set_mode(ct)
        b.opnd.thr.set_mode(ot)
        b.res.set_mode(rt)
        b.cpl.set_mode(pt)
        b.hold.set_mode(hm)
        for _ in range(per_phase):
            b.submit(rand_cmd(rng, AP, vl=min(vl_choice(rng, AP), 6 * N + 3)))
            if rng.random() < 0.08:
                b.pclr.pulse()
        await b.drain(400000)
    b.pclr.pulse()
    await b.env.cycles(3)
    b.finish(name, **extra)


@cocotb.test()
async def random_mixed(dut):
    """Seeded random commands (all ops incl. illegal, reductions, masks, broadcast, vl classes) under random timing
    profiles, per-lane holds and perf_clear pulses; everything bit-exact against the model, counters exact."""
    await run_random(dut, "random_mixed", 35)


@cocotb.test()
async def random_long(dut):
    """Same generator, ~12x the volume (bug-hunting soak; tagged 'long')."""
    await run_random(dut, "random_long", 420)


# ============================================================================================ reset
@cocotb.test()
async def reset_mid_command(dut):
    """Reset with commands queued / mid-beat / results presented but not taken / completions pending / reductions in the
    tree (synchronous, state-triggered and mid-cycle asynchronous).  All outputs low in reset, no stale output for
    any command accepted before reset, first command accepted at the second edge after release, fresh traffic exact."""
    b = Bench(dut, cmd_thr="random:0.9", opnd_thr="random:0.8", res_thr="random:0.6", cpl_thr="random:0.5")
    await b.start()
    rng = b.rng
    m = b.mon
    for rnd in range(18):
        before = b.rst.n_pulses
        b.cmd.thr.set_mode("random:0.9")
        for _ in range(12):
            b.submit(rand_cmd(rng, AP, vl=min(vl_choice(rng, AP), 5 * N + 2)))
        mode = rnd % 9
        if mode == 0:
            b.rst.arm(lambda: m.outstanding >= 3, length=rng.randint(1, 3), reason="commands queued")
        elif mode == 1:
            b.res.set_mode("never")
            await b.env.until(lambda: m.prev_res is not None, 300, "result stalled")
            b.rst.arm(lambda: True, length=2, reason="result stalled")
        elif mode == 2:
            b.cpl.set_mode("never")
            await b.env.until(lambda: m.prev_cpl is not None, 300, "completion stalled")
            b.rst.arm(lambda: True, length=1, reason="completion stalled")
        elif mode == 3:
            b.rst.random_pulse(rng, 3, 40, (1, 4), "random")
        elif mode == 4:
            await b.env.cycles(rng.randint(5, 40))
            await b.rst.async_pulse(phase_ns=rng.choice([1.0, 3.0, 4.9]), length_cycles=rng.randint(1, 3))
        elif mode == 5:
            if AP.red_en:
                for _ in range(3):
                    b.submit(rand_cmd(rng, AP, red=1, illegal_frac=0.0, vl=3 * N + 1))
                b.rst.arm(lambda: any(j.cmd.red for j, _ in m.cpl_q) and m.n_res >= 0 and m.outstanding >= 2, length=1, reason="reduction in flight")
            else:
                b.rst.random_pulse(rng, 3, 30, (1, 2), "random")
        elif mode == 7:  # reset right after a command was accepted, before any operand beat was consumed
            b.opnd.thr.set_mode("never")
            beats0 = m.beats_in  # (no tick since the commands were submitted: nothing consumed yet)
            b.rst.arm(lambda: m.outstanding >= 1 and m.beats_in == beats0, length=2, reason="command queued, no beats yet")
        elif mode == 8:  # reset while completely idle
            await b.drain(30000)
            before = b.rst.n_pulses
            b.rst.random_pulse(rng, 2, 6, (1, 3), "idle")
        else:
            b.hold.set_mode("all")
            await b.env.cycles(rng.randint(10, 30))
            b.rst.arm(lambda: True, length=2, reason="held lanes")
        await b.env.until(lambda: b.rst.n_pulses > before and not b.rst.asserted, 500, "reset pulse")
        b.res.set_mode("random:0.6")
        b.cpl.set_mode("random:0.5")
        b.opnd.thr.set_mode("random:0.8")
        b.hold.set_mode("none")
        await b.env.cycles(rng.randint(1, 5))
        for _ in range(10):
            b.submit(rand_cmd(rng, AP, vl=min(vl_choice(rng, AP), 4 * N + 1)))
        await b.drain(30000)
    assert m.sb.summary()["cancelled"] > 10, "resets never found commands in flight"
    b.finish("reset_mid_command", resets=b.rst.n_pulses, cancelled=len(m.sb.cancelled))
