"""Command / operand-beat generators for the vector array bench (deterministic given a random.Random)."""
from __future__ import annotations

import random
from typing import List, Optional, Tuple

from albionverify.models import vec_fp32 as F
from albionverify.models.vec_array import ArrayParams, Beat, Cmd, active_mask, cmd_legal, nbeats
from albionverify.models.vec_gen import operand_pair_for, rand_fp32, rm_for

GARBAGE = [0x7FA00000, 0x7FC00000, 0x7F800000, 0xFF800000, 0x7FFFFFFF, 0xFFA12345, 0x7F800001, 0x7FC0FFFF]


def garbage(rng: random.Random) -> int:
    return rng.choice(GARBAGE) if rng.random() < 0.7 else rng.getrandbits(32)


ARITH_OPS = [F.OP_FMV, F.OP_FADD, F.OP_FSUB, F.OP_FMUL, F.OP_FMADD, F.OP_FMSUB, F.OP_FNMSUB, F.OP_FNMADD]
ALL_OPS = ARITH_OPS + list(F.FCMP_OPS) + list(F.INT_OPS)
OP_WEIGHTS = {F.OP_FMV: 3, F.OP_FADD: 8, F.OP_FSUB: 4, F.OP_FMUL: 8, F.OP_FMADD: 8, F.OP_FMSUB: 3, F.OP_FNMSUB: 3, F.OP_FNMADD: 3,
              F.OP_FMIN: 2, F.OP_FMAX: 2, F.OP_FEQ: 2, F.OP_FLT: 2, F.OP_FLE: 2, F.OP_IADD: 2, F.OP_IMUL: 2}


def used_operands(op: int) -> Tuple[bool, bool, bool]:
    """Which of (a, b, c) the operation reads."""
    if op == F.OP_FMV:
        return True, False, False
    if op in F.FMA_OPS:
        return True, True, True
    if op in F.ALL_LEGAL_OPS:
        return True, True, False
    return True, True, True


def vl_choice(rng: random.Random, p: ArrayParams, long_ok: bool = False) -> int:
    n = p.n
    r = rng.random()
    vmax = (1 << p.vl_w) - 1
    if r < 0.04:
        v = 0
    elif r < 0.14:
        v = 1
    elif r < 0.26:
        v = max(1, n - 1)
    elif r < 0.38:
        v = n
    elif r < 0.48:
        v = n + 1
    elif r < 0.58:
        v = rng.randint(1, 4) * n
    elif r < 0.97:
        v = rng.randint(1, 5 * n + 3)
    else:
        v = rng.randint(1, min(vmax, 24 * n)) if not long_ok else vmax
    return min(v, vmax)


def gen_beats(rng: random.Random, cmd: Cmd, p: ArrayParams, mask_mode: Optional[str] = None, value_mode: str = "mixed") -> List[Beat]:
    n = p.n
    nb = nbeats(cmd.vl, n)
    legal = cmd_legal(cmd, p)
    gen_op = cmd.op if cmd.op in F.ALL_LEGAL_OPS else F.OP_FADD
    ua, ub, uc = used_operands(cmd.op)
    beats: List[Beat] = []
    for g in range(nb):
        mm = mask_mode or rng.choice(["rand", "rand", "all1", "all0", "alt", "sparse"])
        if mm == "all1":
            mask = (1 << n) - 1
        elif mm == "all0":
            mask = 0
        elif mm == "alt":
            mask = sum(1 << l for l in range(n) if (l + g) % 2 == 0)
        elif mm == "sparse":
            mask = (1 << rng.randrange(n)) if rng.random() < 0.8 else 0
        else:
            mask = rng.getrandbits(n)
        A, B, C = [], [], []
        for l in range(n):
            e = g * n + l
            act = legal and e < cmd.vl and (not cmd.vm or (mask >> l) & 1)
            if act:
                if value_mode == "moderate":
                    a, b, c = (rand_fp32(rng, "moderate") for _ in range(3))
                elif cmd.red and rng.random() < 0.6:
                    a, b, c = (rand_fp32(rng, "finite" if rng.random() < 0.7 else "moderate") for _ in range(3))
                else:
                    a, b, c = operand_pair_for(rng, gen_op)
            else:
                a, b, c = garbage(rng), garbage(rng), garbage(rng)
            # operands the op does not read / broadcast operands are ignored: fill with garbage in the stream
            if act and not ua or (cmd.bcast & 1 and not cmd.red):
                a = garbage(rng)
            if act and not ub or (cmd.bcast & 2 and not cmd.red):
                b = garbage(rng)
            if act and not uc or (cmd.bcast & 4 and not cmd.red):
                c = garbage(rng)
            A.append(a & F.M32)
            B.append(b & F.M32)
            C.append(c & F.M32)
        beats.append(Beat(A, B, C, mask))
    return beats


def rand_cmd(rng: random.Random, p: ArrayParams, *, op: Optional[int] = None, red: Optional[int] = None, vl: Optional[int] = None, illegal_frac: float = 0.07,
             long_ok: bool = False, tid: Optional[int] = None) -> Cmd:
    if red is None:
        red = 1 if (p.red_en and rng.random() < 0.2) or (not p.red_en and rng.random() < 0.05) else 0
    if op is None:
        r = rng.random()
        if r < illegal_frac / 2:
            op = rng.choice([0x0D, 0x0E, 0x0F, 0x12, 0x13, 0x1F, 0x18])
        elif red:
            op = rng.choices(ARITH_OPS, weights=[4, 4, 3, 6, 3, 2, 2, 2])[0] if rng.random() > illegal_frac else rng.choice(ALL_OPS)
        else:
            op = rng.choices(list(OP_WEIGHTS), weights=list(OP_WEIGHTS.values()))[0]
    rm = rm_for(rng)
    if rng.random() < illegal_frac:
        rm = rng.choice([5, 6, 7])
    bcast = 0
    if not red and rng.random() < 0.3:
        bcast = rng.getrandbits(3)
    elif red and rng.random() < illegal_frac:
        bcast = rng.randint(1, 7)  # illegal reduction form
    vm = 1 if rng.random() < 0.45 else 0
    scalar = rand_fp32(rng) if rng.random() < 0.7 else garbage(rng)
    return Cmd(op, rm, vl_choice(rng, p, long_ok) if vl is None else vl, vm, bcast, scalar, red, rng.getrandbits(p.tid_w) if tid is None else tid)
