"""Bug-hunt soak for the lane arithmetic (boundary sweeps from vec_hunt.py).  Same lock-step checks as cocotb_vec_lane."""
import cocotb

from compute.cocotb_vec_lane import LP, build, drain, finish, start
from compute.vec_hunt import hunt_add_ops, hunt_fma_ops, hunt_mul_ops


@cocotb.test()
async def hunt_arith(dut):
    """Boundary sweeps: power-of-two minuends vs sticky-only addends at every exponent gap, FMUL overflow / underflow /
    subnormal boundary exponents with edge mantissas, FMA alignment-frame boundaries (c from 32 binades below to 33 above
    the product)."""
    env, rst, drv, snk, mon = build(dut, "random:0.97", "random:0.9")
    await start(env, rst)
    rng = env.seeds.child("hunt")
    ops = hunt_add_ops(rng) + hunt_mul_ops(rng) + hunt_fma_ops(rng)
    for o in ops:
        drv.submit(o)
    await drain(env, drv, mon, 600000)
    finish(env, mon, "hunt_arith", n_ops=len(ops))
