"""Held-out fault-injection suites.

Each suite re-uses a worker bench's cases UNCHANGED and scores them against mutants that were written by the lead
after the benches were finished.  The workers authored both their tests and their mutants and iterated until the
mutants died, so their own mutation scores partly measure tests tuned to their own yardstick; this set is the
independent check.  (These suites contain no regression cases of their own: ``cases`` only feeds the mutation set.)
"""
import sys
from albionverify.suite import Suite, load_suites

_SRC = {"heldout_fabric": "xbar", "heldout_dma": "dma_simple", "heldout_sram": "sram_sp", "heldout_vec": "vec_lane",
        "heldout_ten": "ten_array", "heldout_mailbox": "ctl_mailbox", "heldout_gate": "ctl_sfbgate"}


def _build():
    import importlib
    out = {}
    mods = {"xbar": "fabric.suite", "dma_simple": "dma.suite", "sram_sp": "sram.suite", "vec_lane": "compute.suite",
            "ten_array": "compute.suite", "ctl_mailbox": "control.suite", "ctl_sfbgate": "control.suite"}
    for name, src in _SRC.items():
        s = importlib.import_module(mods[src]).SUITES[src]
        out[name] = Suite(name=name, subsystem="heldout", title="HELD-OUT mutants against the %s bench" % src,
                          cases=[], mutation_cases=s.mutation_set(), mutants_file="mutants/%s.yaml" % name)
    return out


SUITES = _build()
