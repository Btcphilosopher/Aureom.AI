"""cc_sysctrl bench: SYSCTRL page, reset generator, POR vs SYS reset domains, status pins.

DUT = ctl_sysctrl_wrap (cc_sysctrl + the reset synchronisers / input synchronisers of the top level).
Reference model: albionverify/models/ctl_sysctrl.py (from MEMORY_MAP.md, 01_ARCHITECTURE.md section 4, 03_BOOT.md).
"""
import os

import cocotb

from albionverify.bus.regbus import RegBusMaster
from albionverify.core import Env
from albionverify.coverage import CoverGroup
from albionverify.models import ctl_spec as S
from albionverify.models.ctl_sysctrl import KIND, SysctrlModel
from albionverify.reset import ResetSequencer
from albionverify.scoreboard import Scoreboard

from control.ctl_bench import (PARAMS, BlockChecker, PinDriver, Recorder, RegTraffic, async_reset_midcycle, expect, finish, gap_cover,
                               queue_sweep, txn_cover)

A = S.SYSCTRL
SEED = int(os.environ.get("ALBION_SEED", "1"))
KEY = S.SOFT_RESET_KEY
STRETCH = S.RESET_STRETCH
REGS = [(A[n], ()) for n in ("ID", "HW_VERSION", "MAP_VERSION", "FEATURES", "ROM_BYTES", "IMEM_BYTES", "DMEM_BYTES", "RESET_COUNT", "BOOT_MODE",
                              "BOOT_STAGE", "BOOT_STATUS", "HOST_STATUS", "FW_VERSION", "SCRATCH0", "SCRATCH1", "SCRATCH2", "SCRATCH3", "TEST_CTRL")] + [
    (A["RESET_CAUSE"], (0x1, 0x2, 0x4, 0x8, 0xF, 0xFFFFFFFF)),
    (A["SOFT_RESET"], (KEY, KEY, KEY ^ 1, KEY ^ 0x80000000, KEY & 0xFFFF, 0, 0xFFFFFFFF, 0xDEC05AFE)),
]


def kind_of(addr, we, wdata):
    k = KIND.get(addr) if not addr & 3 else None
    if k is None:
        return "unmapped"
    if k == "wo":
        return "wo_key" if (we and wdata == KEY) else "wo"
    return k


def build(dut, seed):
    env = Env(dut, name="sysctrl", seed=seed)
    rst = env.add(ResetSequencer("rst", env.sig("rst_ni"), initial_cycles=4))
    rb = env.add(RegBusMaster("rb", env, rng=env.seeds.child("rb")))
    pins = env.add(PinDriver("pins", env.seeds.child("pins"), {
        "wdt_req": (env.sig("wdt_req"), 1), "host_rst_req_i": (env.sig("host_rst_req_i"), 1), "boot_mode_i": (env.sig("boot_mode_i"), 2)}))
    rec = env.add(Recorder("rec", {"sys_reset_req": env.sig("sys_reset_req"), "sys_rst_n": env.sig("sys_rst_n"), "por_rst_n": env.sig("por_rst_n")}))
    sb = Scoreboard(env, "sysctrl")
    model = SysctrlModel(PARAMS.get("FEATURES", 0x7F), PARAMS.get("ROM_BYTES", 0x2000), PARAMS.get("IMEM_BYTES", 0x10000), PARAMS.get("DMEM_BYTES", 0x8000))
    rstn = env.sig("rst_ni")
    chk = env.add(BlockChecker(
        "chk", model, sb,
        ins={"sel": env.sig("rb_sel"), "we": env.sig("rb_we"), "addr": env.sig("rb_addr"), "wdata": env.sig("rb_wdata"),
             "wdt_req": env.sig("wdt_req"), "host_rst_req_i": env.sig("host_rst_req_i"), "boot_mode_i": env.sig("boot_mode_i")},
        outs={"rdata": env.sig("rb_rdata"), "err": env.sig("rb_err"), "sys_reset_req": env.sig("sys_reset_req"), "host_ready": env.sig("host_ready"),
              "cmdproc_ready": env.sig("cmdproc_ready"), "test_done": env.sig("test_done"), "test_fail": env.sig("test_fail"),
              "test_code": env.sig("test_code"), "por_rst_n": env.sig("por_rst_n"), "sys_rst_n": env.sig("sys_rst_n")},
        resets=lambda: {"por_in": rstn.read() == 0}, warmup=4))
    # ---- functional coverage
    tc = txn_cover("sysctrl", {"ro": ("ok", "refused"), "rw": ("ok", "ok"), "w1c": ("ok", "ok"), "wo": ("refused", "refused"), "wo_key": (None, "ok"),
                               "unmapped": ("refused", "refused")})
    ac = CoverGroup("sysctrl.addr", "address boundaries")
    ac.point("addr", {"first_reg": 0x000, "feature_block": lambda a: 0x00C <= a <= 0x018, "reset_cause": 0x020, "soft_reset": 0x028, "boot_stage": 0x030,
                      "last_reg": 0x050, "hole_gap": lambda a: 0x01C <= a < 0x020 or 0x054 <= a < 0x100, "hole_high": lambda a: 0x100 <= a < 0xFFC, "page_last_word": 0xFFC})
    rc = CoverGroup("sysctrl.reset", "reset generator scenarios")
    rc.point("scenario", ["soft_only", "wdt_only", "host_only", "multi_cause", "request_during_pulse", "request_after_pulse", "wdt_retrigger",
                          "w1c_same_cycle_as_set", "bad_key", "por_async", "por_during_pulse", "por_idle"])
    pc = CoverGroup("sysctrl.pins", "status pins")
    pc.point("pin", ["host_ready", "cmdproc_ready", "test_done", "test_fail"])
    pc.point("val", [0, 1])
    pc.cross("pin_val", ["pin", "val"])
    bc = CoverGroup("sysctrl.boot_mode", "boot_mode strap values seen through BOOT_MODE")
    bc.point("mode", [0, 1, 2, 3])
    env.coverage += [tc, ac, rc, pc, bc, gap_cover("sysctrl")]

    def hook(inp, exp, rst):
        if inp["sel"]:
            a = inp["addr"]
            tc.sample(dir="write" if inp["we"] else "read", kind=kind_of(a, inp["we"], inp["wdata"]), result="refused" if exp["err"] else "ok")
            ac.sample(addr=a)
            if a == A["BOOT_MODE"] and not inp["we"] and exp["rdata"] is not None:
                bc.sample(mode=exp["rdata"])
        for nm in ("host_ready", "cmdproc_ready", "test_done", "test_fail"):
            pc.sample(pin=nm, val=exp[nm])

    chk.hooks.append(hook)
    return env, rst, rb, pins, rec, sb, model, chk, (rc, bc)


def cover_scenarios(model_probe, rc):
    """Wrap model.step to classify reset scenarios from the PRE-edge model state."""
    orig = model_probe.step
    prev = {"str": 0}

    def step(inp, resets):
        m = model_probe
        pre_str, pre_cause = m.str, m.cause
        pre_por = m.s_por[1]
        soft = m.soft_req(inp)
        wdt = inp.get("wdt_req", 0)
        host_edge = bool(m.host_req and not m.host_prev)
        n = int(bool(soft)) + int(bool(wdt)) + int(host_edge)
        if pre_por and not resets.get("por_in"):
            if n and pre_str == 0:
                if n > 1:
                    rc.sample(scenario="multi_cause")
                elif soft:
                    rc.sample(scenario="soft_only")
                elif wdt:
                    rc.sample(scenario="wdt_only")
                else:
                    rc.sample(scenario="host_only")
                if wdt and m.rcount and pre_str == 0 and m.cause & 4:
                    rc.sample(scenario="wdt_retrigger")
                if prev["str"] == 1:  # the pulse ended with the previous edge
                    rc.sample(scenario="request_after_pulse")
            elif n and pre_str == 1:
                rc.sample(scenario="request_during_pulse")
            elif n and pre_str > 1:
                rc.sample(scenario="request_during_pulse")
            if inp["sel"] and inp["we"] and inp["addr"] == A["SOFT_RESET"] and (inp["wdata"] & 0xFFFFFFFF) != KEY:
                rc.sample(scenario="bad_key")
            if inp["sel"] and inp["we"] and inp["addr"] == A["RESET_CAUSE"] and n and pre_str == 0:
                rc.sample(scenario="w1c_same_cycle_as_set")
        if resets.get("por_in") and pre_por:
            rc.sample(scenario="por_during_pulse" if pre_str else "por_idle")
            rc.sample(scenario="por_async")
        prev["str"] = pre_str
        return orig(inp, resets)

    model_probe.step = step


async def go(dut, seed):
    env, rst, rb, pins, rec, sb, model, chk, (rc, bc) = build(dut, seed)
    cover_scenarios(model, rc)
    await env.start()
    await env.until(lambda: not rst.asserted, 50, "reset release")
    await env.until(lambda: rec.h["sys_rst_n"].get(env.cycle) == 1, 20, "SYS domain released")
    return env, rst, rb, pins, rec, sb, model, chk


async def drain(env, rb, n=200000):
    await env.until(lambda: rb.idle, n, "register ops")


def n_high(rec, since):
    """Number of sampled cycles after ``since`` with sys_reset_req high."""
    return sum(1 for c, v in rec.h["sys_reset_req"].items() if c > since and v)


async def settle(env, rec):
    """Wait until no reset pulse is active and the SYS domain is released (5 cycles first: a request needs up to
    3 edges through the synchronisers before its pulse becomes visible)."""
    await env.cycles(5)
    await env.until(lambda: rec.h["sys_reset_req"].get(env.cycle) == 0 and rec.h["sys_rst_n"].get(env.cycle) == 1, 400, "reset chain idle")


# ============================================================================= tests


@cocotb.test()
async def identity_reset_values(dut):
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)
    queue_sweep(rb)
    await drain(env, rb)
    by = {op.addr: op for op in rb.history}
    exp = {"ID": 0x53464343, "HW_VERSION": 0x00010000, "MAP_VERSION": 0x00010000, "FEATURES": PARAMS.get("FEATURES", 0x7F),
           "ROM_BYTES": PARAMS.get("ROM_BYTES", 0x2000), "IMEM_BYTES": PARAMS.get("IMEM_BYTES", 0x10000), "DMEM_BYTES": PARAMS.get("DMEM_BYTES", 0x8000),
           "RESET_CAUSE": 0x1, "RESET_COUNT": 0, "BOOT_MODE": 0, "BOOT_STAGE": 0, "BOOT_STATUS": 0, "HOST_STATUS": 0, "FW_VERSION": 0,
           "SCRATCH0": 0, "SCRATCH1": 0, "SCRATCH2": 0, "SCRATCH3": 0, "TEST_CTRL": 0}
    for nm, v in exp.items():
        expect(sb, nm, v, by[A[nm]].rdata)
        expect(sb, nm + " err", False, by[A[nm]].err)
    expect(sb, "SOFT_RESET read refused", True, by[A["SOFT_RESET"]].err)
    for a in (0x01C, 0x054, 0x0FC, 0x100, 0x7FC, 0xFFC):
        expect(sb, "hole refused", (True, 0), (by[a].err, by[a].rdata), "0x%x" % a)
    # writes to RO registers are refused and change nothing
    ro = [A[n] for n in ("ID", "HW_VERSION", "MAP_VERSION", "FEATURES", "ROM_BYTES", "IMEM_BYTES", "DMEM_BYTES", "RESET_COUNT", "BOOT_MODE")]
    ops = [rb.write_op(a, 0xFFFFFFFF) for a in ro] + [rb.write_op(0x0FC, 1), rb.write_op(0x01C, 1)]
    reads = [rb.read_op(a) for a in ro]
    await drain(env, rb)
    for o in ops:
        expect(sb, "write to RO / hole refused", True, o.err, "0x%x" % o.addr)
    for a, o in zip(ro, reads):
        expect(sb, "RO unchanged", exp[[k for k, v in A.items() if v == a][0]], o.rdata, "0x%x" % a)
    expect(sb, "no reset pulse so far", 0, n_high(rec, 8))
    finish(env, sb, "identity_reset_values", chk)


@cocotb.test()
async def soft_reset_directed(dut):
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)

    async def rd(a):
        return (await rb.read(a)).rdata

    scr = [0x11111111, 0x22222222, 0x33333333, 0x44444444]
    for i, v in enumerate(scr):
        await rb.write(A["SCRATCH0"] + 4 * i, v)
    await rb.write(A["BOOT_STAGE"], 0x1A3)  # only [7:0] kept
    await rb.write(A["BOOT_STATUS"], 0x00000105)
    await rb.write(A["HOST_STATUS"], 0xFFFFFFF3)  # [3:0] kept -> 3
    await rb.write(A["FW_VERSION"], 0xCAFEF00D)
    await rb.write(A["TEST_CTRL"], 0xC0000042)
    expect(sb, "BOOT_STAGE keeps 8 bits", 0xA3, await rd(A["BOOT_STAGE"]))
    expect(sb, "HOST_STATUS keeps 4 bits", 0x3, await rd(A["HOST_STATUS"]))
    expect(sb, "pins from HOST_STATUS", (1, 1), (dut.host_ready.value.integer, dut.cmdproc_ready.value.integer))
    expect(sb, "pins from TEST_CTRL", (1, 1, 0x42), (dut.test_done.value.integer, dut.test_fail.value.integer, dut.test_code.value.integer))
    # wrong keys: refused, no reset, nothing changes
    for bad in (0, KEY ^ 1, KEY ^ 0x80000000, KEY & 0xFFFF, 0xFFFFFFFF, 0xDEC05AFE):
        o = await rb.write(A["SOFT_RESET"], bad)
        expect(sb, "wrong key refused 0x%08x" % bad, True, o.err)
    await env.cycles(30)
    expect(sb, "no reset after wrong keys", 0, n_high(rec, 8))
    expect(sb, "state kept", 0xA3, await rd(A["BOOT_STAGE"]))
    # right key: accepted, a 16-cycle pulse starting the cycle after the write
    o = await rb.write(A["SOFT_RESET"], KEY)
    expect(sb, "right key accepted", False, o.err)
    w = o.t_issue
    await env.cycles(30)
    expect(sb, "pulse not yet at the write cycle", 0, rec.h["sys_reset_req"][w])
    expect(sb, "pulse length == CC_RESET_STRETCH", STRETCH, rec.run_of("sys_reset_req", 1, w + 1))
    expect(sb, "pulse follows the write", 0, rec.h["sys_reset_req"][w + 1 + STRETCH])
    expect(sb, "SYS reset asserted with the pulse, released 2 edges after", STRETCH + 2, rec.run_of("sys_rst_n", 0, w + 1))
    await settle(env, rec)
    for nm in ("BOOT_STAGE", "BOOT_STATUS", "HOST_STATUS", "FW_VERSION", "TEST_CTRL"):
        expect(sb, nm + " cleared by SYS reset", 0, await rd(A[nm]))
    for i, v in enumerate(scr):
        expect(sb, "SCRATCH%d survives soft reset" % i, v, await rd(A["SCRATCH0"] + 4 * i))
    expect(sb, "pins cleared", (0, 0, 0, 0, 0), (dut.host_ready.value.integer, dut.cmdproc_ready.value.integer, dut.test_done.value.integer,
                                                  dut.test_fail.value.integer, dut.test_code.value.integer))
    expect(sb, "RESET_CAUSE = POR|SOFT", 0x3, await rd(A["RESET_CAUSE"]))
    expect(sb, "RESET_COUNT = 1", 1, await rd(A["RESET_COUNT"]))
    # W1C
    await rb.write(A["RESET_CAUSE"], 0x1)
    expect(sb, "W1C clears only the written bit", 0x2, await rd(A["RESET_CAUSE"]))
    await rb.write(A["RESET_CAUSE"], 0xFFFFFFF0)
    expect(sb, "W1C with bits outside [3:0] changes nothing", 0x2, await rd(A["RESET_CAUSE"]))
    await rb.write(A["RESET_CAUSE"], 0x2)
    expect(sb, "cause cleared", 0, await rd(A["RESET_CAUSE"]))
    expect(sb, "count not touched by W1C", 1, await rd(A["RESET_COUNT"]))
    # --- a key written again inside an active pulse is merged: one pulse, one count, cause unchanged
    o = await rb.write(A["SOFT_RESET"], KEY)
    w = o.t_issue
    while env.cycle < w + 3:
        await env.tick()
    o2 = rb.write_op(A["SOFT_RESET"], KEY)  # completes at w + 5, inside the pulse
    await drain(env, rb)
    expect(sb, "second key write lands inside the pulse", w + 5, o2.t_issue)
    expect(sb, "second key write is accepted by the bus (key is right)", False, o2.err)
    await settle(env, rec)
    expect(sb, "merged requests: one pulse", STRETCH, rec.run_of("sys_reset_req", 1, w + 1))
    expect(sb, "merged requests counted once", 2, await rd(A["RESET_COUNT"]))
    expect(sb, "cause SOFT", 0x2, await rd(A["RESET_CAUSE"]))
    # --- boundary: a key in the LAST pulse cycle is merged, one in the first cycle after the pulse starts a new pulse
    o = await rb.write(A["SOFT_RESET"], KEY)
    w = o.t_issue
    while env.cycle < w + STRETCH - 2:
        await env.tick()
    o2 = rb.write_op(A["SOFT_RESET"], KEY)
    await drain(env, rb)
    expect(sb, "key write in the last pulse cycle", w + STRETCH, o2.t_issue)
    await settle(env, rec)
    expect(sb, "last-cycle request merged (single pulse)", (STRETCH, 0), (rec.run_of("sys_reset_req", 1, w + 1), rec.h["sys_reset_req"][w + STRETCH + 1]))
    expect(sb, "...and not counted", 3, await rd(A["RESET_COUNT"]))
    o = await rb.write(A["SOFT_RESET"], KEY)
    w = o.t_issue
    while env.cycle < w + STRETCH - 1:
        await env.tick()
    o2 = rb.write_op(A["SOFT_RESET"], KEY)
    await drain(env, rb)
    expect(sb, "key write in the first cycle after the pulse", w + STRETCH + 1, o2.t_issue)
    await settle(env, rec)
    expect(sb, "first pulse", STRETCH, rec.run_of("sys_reset_req", 1, w + 1))
    expect(sb, "one idle cycle then the second pulse", (0, STRETCH), (rec.h["sys_reset_req"][w + STRETCH + 1], rec.run_of("sys_reset_req", 1, w + STRETCH + 2)))
    expect(sb, "both counted", 5, await rd(A["RESET_COUNT"]))
    finish(env, sb, "soft_reset_directed", chk)


@cocotb.test()
async def wdt_host_boot_mode_directed(dut):
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)

    async def rd(a):
        return (await rb.read(a)).rdata

    # --- watchdog request: level, 1-cycle request -> one pulse, cause WDT.  A pin forced after tick n is first seen by
    # the DUT at edge n+2 (agents drive at n+1): c0 = that edge.
    await env.tick()
    c0 = env.cycle + 2
    pins.force("wdt_req", 1)
    await env.tick()
    pins.force("wdt_req", 0)
    await settle(env, rec)
    expect(sb, "wdt request starts the pulse in the next cycle", 1, rec.h["sys_reset_req"][c0 + 1])
    expect(sb, "wdt pulse length", STRETCH, rec.run_of("sys_reset_req", 1, c0 + 1))
    expect(sb, "cause POR|WDT", 0x5, await rd(A["RESET_CAUSE"]))
    expect(sb, "count", 1, await rd(A["RESET_COUNT"]))
    await rb.write(A["RESET_CAUSE"], 0xF)
    # --- watchdog level held for 40 cycles: back-to-back pulses every STRETCH+1 cycles
    await env.tick()
    c0 = env.cycle + 2
    pins.force("wdt_req", 1)
    await env.cycles(40)
    pins.force("wdt_req", 0)
    await settle(env, rec)
    pulses = [c for c in range(c0, c0 + 60) if rec.h["sys_reset_req"].get(c) == 1 and rec.h["sys_reset_req"].get(c - 1) == 0]
    expect(sb, "level request re-triggers every STRETCH+1 cycles", [c0 + 1, c0 + 1 + STRETCH + 1, c0 + 1 + 2 * (STRETCH + 1)], pulses)
    expect(sb, "count after three requests", 4, await rd(A["RESET_COUNT"]))
    # --- host reset: edge triggered, 3-cycle latency (2 synchroniser flops + edge detect)
    await rb.write(A["RESET_CAUSE"], 0xF)
    await env.tick()
    c0 = env.cycle + 2
    pins.force("host_rst_req_i", 1)
    await env.cycles(100)  # stays high: only the rising edge counts
    expect(sb, "host reset pulse starts 3 edges after the pin", 1, rec.h["sys_reset_req"][c0 + 3])
    expect(sb, "...and not earlier", 0, rec.h["sys_reset_req"][c0 + 2])
    expect(sb, "single pulse for a held request", STRETCH, rec.run_of("sys_reset_req", 1, c0 + 3))
    await settle(env, rec)
    expect(sb, "one count for a level held high", 5, await rd(A["RESET_COUNT"]))
    expect(sb, "cause HOST", 0x8, await rd(A["RESET_CAUSE"]))
    pins.force("host_rst_req_i", 0)
    await env.cycles(10)
    await env.tick()
    pins.force("host_rst_req_i", 1)  # second rising edge -> second reset
    await env.cycles(30)
    pins.force("host_rst_req_i", 0)
    await settle(env, rec)
    expect(sb, "second rising edge counted", 6, await rd(A["RESET_COUNT"]))
    # --- simultaneous causes (host edge + wdt level + soft key in one cycle)
    await rb.write(A["RESET_CAUSE"], 0xF)
    await env.tick()
    pins.force("host_rst_req_i", 1)  # seen by the generator 2 edges later
    await env.cycles(2)
    pins.force("wdt_req", 1)
    rb.write_op(A["SOFT_RESET"], KEY)
    await env.tick()
    pins.force("wdt_req", 0)
    await settle(env, rec)
    expect(sb, "three causes recorded together", 0xE, await rd(A["RESET_CAUSE"]))
    expect(sb, "counted once", 7, await rd(A["RESET_COUNT"]))
    pins.force("host_rst_req_i", 0)
    await env.cycles(5)
    # --- same cycle: W1C of a bit and a new request of that cause -> the new cause wins
    await rb.write(A["RESET_CAUSE"], 0xF)
    await rb.write(A["SOFT_RESET"], KEY)
    await settle(env, rec)
    expect(sb, "cause SOFT", 0x2, await rd(A["RESET_CAUSE"]))
    await env.tick()
    pins.force("wdt_req", 1)
    rb.write_op(A["RESET_CAUSE"], 0xF)
    await env.tick()
    pins.force("wdt_req", 0)
    await settle(env, rec)
    expect(sb, "new cause wins over a same-cycle W1C", 0x4, await rd(A["RESET_CAUSE"]))
    # --- boot_mode straps: 2-flop synchroniser
    for mode in (1, 2, 3, 0, 2):
        pins.force("boot_mode_i", mode)
        ops = [rb.read_op(A["BOOT_MODE"]) for _ in range(5)]
        await drain(env, rb)
        old = ops[0].rdata
        expect(sb, "boot_mode latency (old, old, new...) for %d" % mode, [old, old, mode, mode, mode], [o.rdata for o in ops])
    finish(env, sb, "wdt_host_boot_mode_directed", chk)


@cocotb.test()
async def por_domain_directed(dut):
    """Asynchronous power-on reset (mid-cycle) clears the POR domain too; soft/WDT/host resets never do."""
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)
    rng = env.seeds.child("por")

    async def rd(a):
        return (await rb.read(a)).rdata

    for rnd in range(6):
        for i in range(4):
            await rb.write(A["SCRATCH0"] + 4 * i, 0xA0000000 + (rnd << 8) + i)
        await rb.write(A["BOOT_STAGE"], 0x55)
        await rb.write(A["SOFT_RESET"], KEY)
        if rnd % 2:
            await env.cycles(rng.randint(1, 10))  # POR in the middle of the pulse
        else:
            await settle(env, rec)
        n0 = rst.n_pulses
        if rnd < 3:
            await env.tick()
            await async_reset_midcycle(env, rst, rng.choice((1.0, 2.5, 4.0, 6.0, 8.0)), rng.randint(1, 4))
        else:
            rst.pulse(length=rng.randint(1, 4), delay=1, reason="sync POR")
        await env.until(lambda: rst.n_pulses > n0, 20, "POR asserted")
        await env.until(lambda: not rst.asserted, 20, "POR release")
        await env.until(lambda: rec.h["sys_rst_n"].get(env.cycle) == 1 and rec.h["por_rst_n"].get(env.cycle) == 1, 20, "domains released")
        expect(sb, "POR: scratch cleared", [0, 0, 0, 0], [await rd(A["SCRATCH0"] + 4 * i) for i in range(4)])
        expect(sb, "POR: cause = POR only", 0x1, await rd(A["RESET_CAUSE"]))
        expect(sb, "POR: count cleared", 0, await rd(A["RESET_COUNT"]))
        expect(sb, "POR: BOOT_STAGE cleared", 0, await rd(A["BOOT_STAGE"]))
        expect(sb, "no pulse after POR", 0, dut.sys_reset_req.value.integer)
    finish(env, sb, "por_domain_directed", chk)


@cocotb.test()
async def status_pins_directed(dut):
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)
    for hs in (0x0, 0x1, 0x2, 0x3, 0x4, 0x8, 0xF, 0xFFFFFFF0, 0x10):
        await rb.write(A["HOST_STATUS"], hs)
        await env.tick()
        expect(sb, "host_ready for 0x%x" % hs, hs & 1, dut.host_ready.value.integer)
        expect(sb, "cmdproc_ready for 0x%x" % hs, (hs >> 1) & 1, dut.cmdproc_ready.value.integer)
    for tc in (0x0, 0x80000000, 0x40000000, 0xC000ABCD, 0x0000FFFF, 0x3FFF0000, 0xFFFFFFFF):
        await rb.write(A["TEST_CTRL"], tc)
        await env.tick()
        expect(sb, "test_done for 0x%x" % tc, tc >> 31 & 1, dut.test_done.value.integer)
        expect(sb, "test_fail for 0x%x" % tc, tc >> 30 & 1, dut.test_fail.value.integer)
        expect(sb, "test_code for 0x%x" % tc, tc & 0xFFFF, dut.test_code.value.integer)
    await rb.write(A["BOOT_STATUS"], 0xFFFFFFFF)
    await rb.write(A["FW_VERSION"], 0x80000001)
    expect(sb, "BOOT_STATUS 32 bits", 0xFFFFFFFF, (await rb.read(A["BOOT_STATUS"])).rdata)
    expect(sb, "FW_VERSION 32 bits", 0x80000001, (await rb.read(A["FW_VERSION"])).rdata)
    finish(env, sb, "status_pins_directed", chk)


@cocotb.test()
async def unaligned_probe(dut):
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)
    ops = []
    for base in (0x000, 0x020, 0x028, 0x030, 0x040, 0x050):
        for off in (1, 2, 3):
            ops.append(rb.write_op(base + off, KEY))
            ops.append(rb.read_op(base + off))
    await drain(env, rb)
    for o in ops:
        expect(sb, "unaligned access refused", True, o.err, "%s 0x%x" % ("write" if o.write else "read", o.addr))
    await env.cycles(30)
    expect(sb, "unaligned SOFT_RESET key write did not reset", 0, n_high(rec, 8))
    finish(env, sb, "unaligned_probe", chk)


def pin_profile(pins, phase):
    if phase == 0:
        pins.set("wdt_req", "off"); pins.set("host_rst_req_i", "off"); pins.set("boot_mode_i", "level", 0.05)
    elif phase == 1:
        pins.set("wdt_req", "level", 0.02); pins.set("host_rst_req_i", "off"); pins.set("boot_mode_i", "level", 0.2)
    elif phase == 2:
        pins.set("wdt_req", "off"); pins.set("host_rst_req_i", "level", 0.02); pins.set("boot_mode_i", "off")
    elif phase == 3:
        pins.set("wdt_req", "rand", 0.01); pins.set("host_rst_req_i", "rand", 0.01); pins.set("boot_mode_i", "level", 0.5)
    elif phase == 4:
        pins.set("wdt_req", "level", 0.04); pins.set("host_rst_req_i", "level", 0.04); pins.set("boot_mode_i", "level", 0.1)
    else:
        pins.set("wdt_req", "off"); pins.set("host_rst_req_i", "off"); pins.set("boot_mode_i", "off")


@cocotb.test()
async def random_traffic(dut):
    """Random register traffic (incl. correct / near-miss reset keys) with random reset requests and strap changes."""
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)
    rng = env.seeds.child("traffic")
    n_ops = int(os.environ.get("CTL_OPS", "5000"))
    for phase in range(6):
        pin_profile(pins, phase)
        tr = RegTraffic(rng, REGS, p_reg=[0.9, 0.8, 0.8, 0.6, 0.9, 0.7][phase], p_hole=0.1, p_write=[0.5, 0.6, 0.5, 0.5, 0.6, 0.4][phase])
        rb.gap.set_mode(["always", "random:0.6", "bursty:1-5", "random:0.9", "always", "random:0.3"][phase])
        tr.queue(rb, n_ops // 6)
        await drain(env, rb)
    pin_profile(pins, 5)
    await settle(env, rec)
    queue_sweep(rb)
    await drain(env, rb)
    finish(env, sb, "random_traffic", chk, pulses=n_high(rec, 8))


@cocotb.test()
async def reset_traffic(dut):
    """Power-on reset (synchronous pulses and async mid-cycle) in the middle of traffic, resets in flight, reset requests pending."""
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)
    rng = env.seeds.child("rst")
    tr = RegTraffic(rng, REGS, p_reg=0.9, p_hole=0.05, p_write=0.6)
    for rnd in range(12):
        pin_profile(pins, rng.randrange(5))
        tr.queue(rb, 100 + rng.randrange(200))
        await env.until(lambda: len(rb.queue) < 20, 30000, "traffic running")
        n0 = rst.n_pulses
        if rnd % 2 == 0:
            rst.pulse(length=rng.randint(1, 4), delay=rng.randint(1, 4), reason="sync-POR-in-traffic")
        else:
            await env.tick()
            await async_reset_midcycle(env, rst, rng.choice((1.0, 2.0, 3.0, 4.0, 6.0, 7.0, 8.5)), rng.randint(1, 4))
        await env.until(lambda: rst.n_pulses > n0, 20, "POR asserted")
        await env.until(lambda: not rst.asserted, 20, "POR release")
        await env.cycles(3)
    pin_profile(pins, 5)
    await settle(env, rec)
    queue_sweep(rb)
    await drain(env, rb)
    finish(env, sb, "reset_traffic", chk, por_pulses=rst.n_pulses)
