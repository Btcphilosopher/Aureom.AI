"""cc_sfb_gate bench: SFB2 pass-through that refuses on demand (host write lock / accelerator isolation role).

Checks, per the block's specification (docs: HW_SW_INTERFACE.md host port / ext port, PROTOCOL.md R1-R8):
  * a refused request is answered with rsp_error = 1 and rdata = 0 and NO request reaches the slave (no side effect, memory compared);
  * a non-refused request is forwarded unchanged and its response (data, error) comes back unchanged, in order;
  * a request already presented downstream is never withdrawn, even if ``refuse`` rises while it waits;
  * one transaction at a time, ``idle`` = nothing outstanding, ``refused_evt`` pulses once per refused request;
  * cycle-level lockstep with albionverify/models/ctl_sfbgate.py, protocol monitors (R2/R4/R5/R6/R8) on both ports,
    and a model-independent transaction scoreboard when the refuse decision is constant per request.
"""
import os
from collections import deque

import cocotb

from albionverify.bus.reqrsp import Req, ReqRspMaster, ReqRspMonitor, ReqRspSlave, sfb_port
from albionverify.core import Agent, Env
from albionverify.coverage import CoverGroup
from albionverify.memory import BackingStore
from albionverify.models.ctl_sfbgate import SfbGateModel
from albionverify.reset import ResetSequencer
from albionverify.scoreboard import Scoreboard

from control.ctl_bench import BlockChecker, PinDriver, Recorder, async_reset_midcycle, expect, finish

SEED = int(os.environ.get("ALBION_SEED", "1"))
MEM_BYTES = 0x1000


class RefuseFollower(Agent):
    """Drives ``refuse``.  Modes:  ("tag",) = tag of the request currently presented by the master (constant for the whole
    life of a request; random while the master is idle);  ("hold", v);  ("toggle", p) = free-running, flips with probability p."""

    def __init__(self, name, sig, master, rng):
        super().__init__(name)
        self.sig, self.master, self.rng = sig, master, rng
        self.mode = ("tag",)
        self.level = 0

    def drive(self):
        m = self.mode
        if m[0] == "tag":
            cur = self.master.cur
            v = int(bool(cur.req.tag)) if (cur is not None and cur.req.tag is not None) else self.rng.getrandbits(1)
        elif m[0] == "hold":
            v = m[1]
        else:
            v = self.level ^ (1 if self.rng.random() < m[1] else 0)
        self.level = v
        self.sig.write(v)


class GateChecker:
    """Model-independent transaction scoreboard (valid when refuse is constant per request)."""

    def __init__(self, env, sb, mem_ref):
        self.env, self.sb, self.ref = env, sb, mem_ref
        self.fwd = deque()  # requests expected at the slave, in order
        self.n_refused = self.n_forwarded = 0
        self.slave_seen = []
        self.exact_latency = False

    def txn_accepted(self, master, txn):
        refused = bool(txn.req.tag)
        self.sb.accept("gate", txn.seq, refused)
        if refused:
            self.n_refused += 1
        else:
            self.fwd.append(txn)

    def req_accepted(self, slave, req, err, rdata):
        self.slave_seen.append(req)
        if not self.fwd:
            self.sb.fail("a request reached the slave although none was forwarded by the gate (refused request leaked): %r" % (req,))
            return
        t = self.fwd.popleft()
        e = t.req
        self.sb.check_eq("forwarded request write flag", e.write, req.write)
        self.sb.check_eq("forwarded request address", e.addr, req.addr)
        if e.write:
            self.sb.check_eq("forwarded write data", e.wdata, req.wdata)
            self.sb.check_eq("forwarded write strobe", 0xF if e.strb is None else e.strb, req.strb)
        self.n_forwarded += 1
        # reference memory: only forwarded (non-refused) writes take effect
        a = req.addr & ~3
        if req.write and self.ref.in_range(a, 4):
            self.ref.write_word(a, req.wdata, req.strb, 4)

    def txn_completed(self, master, txn):
        refused = self.sb.complete("gate", txn.seq)
        rsp = txn.rsp
        if refused:
            self.sb.check_eq("refused request: rsp_error", True, rsp.err, "addr 0x%x" % txn.req.addr)
            self.sb.check_eq("refused request: rdata", 0, rsp.rdata)
            if self.exact_latency:
                self.sb.check_eq("refused request: response one cycle after acceptance", 1, txn.t_rsp - txn.t_accept)
            return
        a = txn.req.addr & ~3
        bad = not self.ref.in_range(a, 4)
        self.sb.check_eq("forwarded request: rsp_error (slave decides)", bad, rsp.err, "addr 0x%x" % txn.req.addr)
        if bad or txn.req.write:
            self.sb.check_eq("forwarded request: rdata of write / error is 0", 0, rsp.rdata)
        else:
            # the slave answered with ITS memory content at acceptance time; the reference is updated in the same order
            self.sb.check_eq("forwarded read data", self.ref.read_word(a, 4), rsp.rdata, "addr 0x%x" % a)


def build(dut, seed, *, req_thr="always", rsp_thr="always", slv_req="always", slv_rsp="always", latency="fixed:1", tagged=True):
    env = Env(dut, name="gate", seed=seed)
    rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=4))
    sp = sfb_port(env, "s_")
    mp = sfb_port(env, "m_")
    master = env.add(ReqRspMaster("master", sp, rng=env.seeds.child("master"), req_throttle=req_thr, rsp_throttle=rsp_thr, max_outstanding=2))  # R6: the next request is presented while the previous response is pending (the gate must hold it)
    mem = BackingStore("zero", "slave", size=MEM_BYTES)
    slave = env.add(ReqRspSlave("slave", mp, memory=mem, rng=env.seeds.child("slave"), req_throttle=slv_req, rsp_throttle=slv_rsp, latency=latency))
    mon_s = env.add(ReqRspMonitor("mon_s", sp, outstanding_limit=1))
    mon_m = env.add(ReqRspMonitor("mon_m", mp, outstanding_limit=1))
    follower = env.add(RefuseFollower("refuse", env.sig("refuse"), master, env.seeds.child("refuse")))
    rec = env.add(Recorder("rec", {"refused_evt": env.sig("refused_evt"), "idle": env.sig("idle"), "m_req_valid": env.sig("m_req_valid"), "s_req_ready": env.sig("s_req_ready")}))
    sb = Scoreboard(env, "gate")
    model = SfbGateModel()
    rstn = env.sig("rst_n")
    ins = {k: env.sig(k) for k in ("s_req_valid", "s_req_write", "s_req_addr", "s_req_wdata", "s_req_wstrb", "s_rsp_ready", "m_req_ready", "m_rsp_valid",
                                    "m_rsp_rdata", "m_rsp_error", "refuse")}
    outs = {k: env.sig(k) for k in ("s_req_ready", "s_rsp_valid", "s_rsp_rdata", "s_rsp_error", "m_req_valid", "m_req_write", "m_req_addr", "m_req_wdata",
                                     "m_req_wstrb", "m_rsp_ready", "refused_evt", "idle")}
    chk = env.add(BlockChecker("chk", model, sb, ins=ins, outs=outs, resets=lambda: {"sys": rstn.read() == 0}))
    ref = BackingStore("zero", "ref", size=MEM_BYTES)
    gc = GateChecker(env, sb, ref)
    if tagged:
        master.listeners.append(gc)
        slave.listeners.append(gc)
    # ---- coverage
    tc = CoverGroup("gate.txn", "transaction type x gate decision x downstream result")
    tc.point("dir", ["read", "write"])
    tc.point("decision", ["forwarded", "refused"])
    tc.point("result", ["ok", "slave_error", "refused_error"])
    tc.cross("dir_decision_result", ["dir", "decision", "result"], ignore=lambda c: (c[1] == "refused") != (c[2] == "refused_error"))
    sc = CoverGroup("gate.scenario", "refuse timing / flow-control scenarios")
    sc.point("s", ["refuse_at_presentation", "refuse_rise_while_stalled_downstream", "refuse_fall_while_stalled_downstream", "refused_response_stalled",
                   "forwarded_response_stalled", "request_waits_for_response", "back_to_back_refused", "back_to_back_forwarded", "refuse_with_idle_master"])
    sc.point("downstream_stall", {"none": 0, "short": (1, 3), "long": lambda v: v >= 4})
    env.coverage += [tc, sc]
    cstate = {"prev_dec": None}

    class Cov:
        def txn_completed(self, master, txn):
            if txn.req.tag is None:
                return
            refused = bool(txn.req.tag)
            res = "refused_error" if refused else ("slave_error" if txn.rsp.err else "ok")
            tc.sample(dir="write" if txn.req.write else "read", decision="refused" if refused else "forwarded", result=res)
            if txn.rsp_stall_cycles:
                sc.sample(s="refused_response_stalled" if refused else "forwarded_response_stalled")
            if cstate["prev_dec"] == refused:
                sc.sample(s="back_to_back_refused" if refused else "back_to_back_forwarded")
            cstate["prev_dec"] = refused
            sc.sample(downstream_stall=min(txn.req_stall_cycles, 99))
            if txn.t_present is not None and txn.t_accept - txn.t_present > 0:
                sc.sample(s="request_waits_for_response")

    master.listeners.append(Cov())
    gstate = {"refuse": 0}
    orig_step = model.step

    def gstep(inp, resets):
        if not resets.get("sys"):
            free = not model.out and not model.loc
            if inp["refuse"] and not inp["s_req_valid"]:
                sc.sample(s="refuse_with_idle_master")
            if inp["s_req_valid"] and free and inp["refuse"] and not model.pend:
                sc.sample(s="refuse_at_presentation")
            if model.pend and inp["refuse"] and not gstate["refuse"]:
                sc.sample(s="refuse_rise_while_stalled_downstream")
            if model.pend and not inp["refuse"] and gstate["refuse"]:
                sc.sample(s="refuse_fall_while_stalled_downstream")
        gstate["refuse"] = inp["refuse"]
        return orig_step(inp, resets)

    model.step = gstep
    return env, rst, master, slave, mem, ref, mon_s, mon_m, follower, rec, sb, model, chk, gc, sc


async def go(dut, seed, **kw):
    env, rst, master, slave, mem, ref, mon_s, mon_m, follower, rec, sb, model, chk, gc, sc = build(dut, seed, **kw)
    await env.start()
    await env.until(lambda: not rst.asserted, 50, "reset release")
    return env, rst, master, slave, mem, ref, mon_s, mon_m, follower, rec, sb, model, chk, gc, sc


def n_high(rec, key, since=1):
    return sum(1 for c, v in rec.h[key].items() if c > since and v)


def rand_req(rng, refuse_p=0.5, oob_p=0.15):
    a = rng.randrange(0, MEM_BYTES // 4) * 4
    if rng.random() < oob_p:
        a = MEM_BYTES + rng.randrange(0, 64) * 4
    tag = 1 if rng.random() < refuse_p else 0
    if rng.random() < 0.5:
        return Req(True, a, rng.getrandbits(32), rng.choice((0xF, 0xF, 0x1, 0x2, 0x4, 0x8, 0x3, 0xC, 0x5, 0xA, 0x0)), tag=tag)
    return Req(False, a, tag=tag)


async def run_all(env, master, n=20000):
    await env.until(lambda: master.idle, n, "all requests completed")
    await env.cycles(6)


def check_end(sb, gc, mem, ref):
    gc.sb.check_eq("no request left waiting for the slave", 0, len(gc.fwd))
    expect(sb, "slave memory == only the forwarded writes (refused writes had no side effect)", ref.snapshot(0, MEM_BYTES), mem.snapshot(0, MEM_BYTES))


# ============================================================================= tests


@cocotb.test()
async def refuse_directed(dut):
    """Refused writes and reads: error response, rdata 0, one cycle later; nothing reaches the slave; refused_evt once each."""
    env, rst, master, slave, mem, ref, mon_s, mon_m, follower, rec, sb, model, chk, gc, sc = await go(dut, SEED)
    gc.exact_latency = True
    mem.write_word(0x40, 0xAAAA5555, None, 4)
    ref.write_word(0x40, 0xAAAA5555, None, 4)
    ts = [master.write(0x40, 0x12345678, tag=1), master.read(0x40, tag=1), master.write(0x44, 0xFFFFFFFF, 0xF, tag=1), master.read(MEM_BYTES + 4, tag=1)]
    await run_all(env, master)
    for t in ts:
        expect(sb, "error response", (True, 0), (t.rsp.err, t.rsp.rdata))
        expect(sb, "one-cycle response latency", 1, t.t_rsp - t.t_accept)
    expect(sb, "no request reached the slave", 0, len(slave.log))
    expect(sb, "slave memory untouched", 0xAAAA5555, mem.read_word(0x40, 4))
    expect(sb, "refused_evt pulses = refused requests", len(ts), n_high(rec, "refused_evt"))
    expect(sb, "never presented downstream", 0, n_high(rec, "m_req_valid"))
    check_end(sb, gc, mem, ref)
    finish(env, sb, "refuse_directed", chk, monitors=[mon_s.summary(), mon_m.summary()])


@cocotb.test()
async def forward_directed(dut):
    """refuse = 0: requests, strobes, read data, slave errors pass through; idle tracks the outstanding transaction."""
    env, rst, master, slave, mem, ref, mon_s, mon_m, follower, rec, sb, model, chk, gc, sc = await go(dut, SEED, slv_req="random:0.5", slv_rsp="random:0.5", latency="uniform:1-4")
    ts = [master.write(0x10, 0xDEADBEEF, 0xF, tag=0), master.read(0x10, tag=0), master.write(0x10, 0x00AA0000, 0x4, tag=0), master.read(0x10, tag=0),
          master.read(MEM_BYTES + 8, tag=0), master.write(MEM_BYTES + 12, 0x1, 0xF, tag=0), master.write(0x20, 0x1, 0x0, tag=0), master.read(0x20, tag=0)]
    await run_all(env, master)
    expect(sb, "read-after-write data", 0xDEADBEEF, ts[1].rsp.rdata)
    expect(sb, "byte-lane write merged", 0xDEAABEEF, ts[3].rsp.rdata)
    expect(sb, "slave error passes through", (True, 0), (ts[4].rsp.err, ts[4].rsp.rdata))
    expect(sb, "slave error on write passes through", (True, 0), (ts[5].rsp.err, ts[5].rsp.rdata))
    expect(sb, "zero-strobe write changes nothing", 0, ts[7].rsp.rdata)
    expect(sb, "every request reached the slave", len(ts), len(slave.log))
    expect(sb, "no refusal", 0, n_high(rec, "refused_evt"))
    expect(sb, "gate idle again", 1, rec.h["idle"][env.cycle])
    check_end(sb, gc, mem, ref)
    finish(env, sb, "forward_directed", chk, monitors=[mon_s.summary(), mon_m.summary()])


@cocotb.test()
async def refuse_rise_while_stalled(dut):
    """A request presented downstream and stalled there is never withdrawn when refuse rises; a request refused locally stays
    refused when refuse falls before its response is accepted."""
    env, rst, master, slave, mem, ref, mon_s, mon_m, follower, rec, sb, model, chk, gc, sc = await go(dut, SEED, slv_req="never", tagged=False)
    follower.mode = ("hold", 0)
    await env.cycles(2)
    t = master.write(0x30, 0xCAFEF00D, 0xF)
    await env.cycles(6)
    expect(sb, "request presented downstream and stalled (refuse low)", (1, 0), (rec.h["m_req_valid"][env.cycle], rec.h["s_req_ready"][env.cycle]))
    follower.mode = ("hold", 1)  # refuse rises while the request waits at the slave side
    await env.cycles(8)
    expect(sb, "request still presented downstream (never withdrawn)", (1, 0), (rec.h["m_req_valid"][env.cycle], rec.h["s_req_ready"][env.cycle]))
    expect(sb, "no local refusal happened", 0, n_high(rec, "refused_evt"))
    slave.req_thr.set_mode("always")
    await run_all(env, master)
    expect(sb, "forwarded and completed normally (no error) although refuse is high", (False, 0), (t.rsp.err, t.rsp.rdata))
    expect(sb, "the write reached the slave", 0xCAFEF00D, mem.read_word(0x30, 4))
    expect(sb, "still no refusal for it", 0, n_high(rec, "refused_evt"))
    # refuse is still 1 here: the next request is refused locally; the response is held back by the master
    master.rsp_thr.set_mode("never")
    t2 = master.read(0x30)
    await env.cycles(6)
    expect(sb, "refused request accepted locally, response pending", (1, 0), (n_high(rec, "refused_evt"), sum(1 for c in range(env.cycle - 5, env.cycle + 1) if rec.h["m_req_valid"].get(c))))
    follower.mode = ("hold", 0)  # refuse falls while the local response waits
    await env.cycles(5)
    master.rsp_thr.set_mode("always")
    await run_all(env, master)
    expect(sb, "locally refused response unaffected by the later fall of refuse", (True, 0), (t2.rsp.err, t2.rsp.rdata))
    expect(sb, "memory still holds the forwarded value", 0xCAFEF00D, mem.read_word(0x30, 4))
    finish(env, sb, "refuse_rise_while_stalled", chk, monitors=[mon_s.summary(), mon_m.summary()])


@cocotb.test()
async def tagged_random(dut):
    """Random request mix, per-request refuse decision, random flow control on every handshake; model-independent scoreboard."""
    env, rst, master, slave, mem, ref, mon_s, mon_m, follower, rec, sb, model, chk, gc, sc = await go(
        dut, SEED, req_thr="random:0.7", rsp_thr="random:0.6", slv_req="random:0.6", slv_rsp="random:0.7", latency="uniform:1-3")
    rng = env.seeds.child("req")
    n = int(os.environ.get("CTL_OPS", "3000"))
    for phase in range(5):
        p = [0.5, 0.1, 0.9, 0.5, 0.3][phase]
        master.req_thr.set_mode(["random:0.7", "always", "random:0.3", "bursty:1-5", "always"][phase])
        master.rsp_thr.set_mode(["random:0.6", "always", "random:0.3", "bursty:1-8", "random:0.9"][phase])
        slave.req_thr.set_mode(["random:0.6", "always", "random:0.4", "bursty:1-6", "random:0.2"][phase])
        slave.rsp_thr.set_mode(["random:0.7", "always", "random:0.5", "bursty:1-4", "random:0.9"][phase])
        for _ in range(n // 5):
            master.submit(rand_req(rng, refuse_p=p))
        await run_all(env, master)
    expect(sb, "conservation: accepted = refused + forwarded", master.n_accepted, gc.n_refused + gc.n_forwarded)
    expect(sb, "refused_evt count equals the number of refused requests", gc.n_refused, n_high(rec, "refused_evt"))
    check_end(sb, gc, mem, ref)
    finish(env, sb, "tagged_random", chk, monitors=[mon_s.summary(), mon_m.summary()], refused=gc.n_refused, forwarded=gc.n_forwarded)


@cocotb.test()
async def free_refuse_random(dut):
    """refuse toggles freely (independent of the requests): cycle-level lockstep, protocol monitors, request conservation."""
    env, rst, master, slave, mem, ref, mon_s, mon_m, follower, rec, sb, model, chk, gc, sc = await go(
        dut, SEED, req_thr="random:0.8", rsp_thr="random:0.7", slv_req="random:0.4", slv_rsp="random:0.6", latency="uniform:1-3", tagged=False)
    rng = env.seeds.child("req")
    n = int(os.environ.get("CTL_OPS", "3000"))
    for phase, ptog in enumerate((0.5, 0.1, 0.02, 0.9, 0.3)):
        follower.mode = ("toggle", ptog)
        slave.req_thr.set_mode(["random:0.4", "random:0.2", "random:0.1", "random:0.6", "bursty:2-9"][phase])
        master.rsp_thr.set_mode(["random:0.7", "always", "random:0.3", "random:0.9", "bursty:1-6"][phase])
        for _ in range(n // 5):
            master.submit(rand_req(rng, refuse_p=0.0))
        await run_all(env, master)
    n_ref = n_high(rec, "refused_evt")
    expect(sb, "conservation: accepted requests = refused + seen by the slave", master.n_accepted, n_ref + len(slave.log))
    expect(sb, "every accepted request got exactly one response", master.n_accepted, master.n_completed)
    expect(sb, "both decisions were exercised", (True, True), (n_ref > 20, len(slave.log) > 20))
    finish(env, sb, "free_refuse_random", chk, monitors=[mon_s.summary(), mon_m.summary()], refused=n_ref, forwarded=len(slave.log))


@cocotb.test()
async def long_stalls(dut):
    """Maximum back-pressure: 150-cycle downstream request stall and 150-cycle upstream response stall, for forwarded and refused requests."""
    env, rst, master, slave, mem, ref, mon_s, mon_m, follower, rec, sb, model, chk, gc, sc = await go(dut, SEED, slv_req="stall:150")
    t1 = master.write(0x50, 0x11223344, 0xF, tag=0)
    t2 = master.read(0x50, tag=0)
    await run_all(env, master)
    expect(sb, "forwarded after a 150-cycle downstream stall", (False, 0x11223344), (t2.rsp.err, t2.rsp.rdata))
    expect(sb, "request waited without being dropped", True, t1.req_stall_cycles >= 140)
    master.rsp_thr.set_mode("stall:150")
    t3 = master.read(0x50, tag=1)
    t4 = master.read(0x50, tag=0)
    await run_all(env, master)
    expect(sb, "refused response held 150 cycles then delivered", (True, 0), (t3.rsp.err, t3.rsp.rdata))
    expect(sb, "next request behind it completes", (False, 0x11223344), (t4.rsp.err, t4.rsp.rdata))
    expect(sb, "upstream stall observed", True, master.max_rsp_stall >= 140)
    check_end(sb, gc, mem, ref)
    finish(env, sb, "long_stalls", chk, monitors=[mon_s.summary(), mon_m.summary()])


@cocotb.test()
async def reset_traffic(dut):
    """Reset (synchronous and asynchronous mid-cycle) with requests in flight: no response / request survives, the gate works afterwards."""
    env, rst, master, slave, mem, ref, mon_s, mon_m, follower, rec, sb, model, chk, gc, sc = await go(
        dut, SEED, req_thr="random:0.8", rsp_thr="random:0.6", slv_req="random:0.5", slv_rsp="random:0.5", latency="uniform:1-4", tagged=False)
    rng = env.seeds.child("rst")
    follower.mode = ("toggle", 0.2)
    for rnd in range(10):
        for _ in range(60):
            master.submit(rand_req(rng, refuse_p=0.0))
        await env.until(lambda: master.n_accepted >= (rnd + 1) * 5 or master.idle, 5000, "traffic running")
        await env.cycles(rng.randrange(3, 12))
        n0 = rst.n_pulses
        if rnd % 2 == 0:
            rst.pulse(length=rng.randint(1, 3), delay=rng.randint(1, 3), reason="sync-reset")
        else:
            await env.tick()
            await async_reset_midcycle(env, rst, rng.choice((1.0, 2.0, 3.0, 4.0, 6.0, 7.0, 8.5)), rng.randint(1, 3))
        await env.until(lambda: rst.n_pulses > n0, 20, "reset asserted")
        await env.until(lambda: not rst.asserted, 20, "reset release")
        await env.cycles(3)
        expect(sb, "gate idle after reset #%d" % rnd, 1, rec.h["idle"][env.cycle])
        # fresh traffic after the reset still works
        for _ in range(10):
            master.submit(rand_req(rng, refuse_p=0.0))
        await run_all(env, master)
    expect(sb, "traffic ran", True, master.n_completed > 20)
    finish(env, sb, "reset_traffic", chk, monitors=[mon_s.summary(), mon_m.summary()], resets=rst.n_pulses)
