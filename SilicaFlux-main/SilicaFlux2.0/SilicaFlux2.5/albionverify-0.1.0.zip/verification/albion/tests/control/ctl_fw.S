# ControlCore bench payload ("firmware") -- assembled with llvm-mc (riscv32 rv32im_zicsr), linked at 0x00010100.
# Purpose: give the boot ROM a valid image so the bench can exercise the boot hand-over and the interrupt path:
#   * publishes progress in SYSCTRL (BOOT_STAGE, HOST_STATUS pins, FW_VERSION, SCRATCH3 = number of firmware starts)
#   * sets the INTC priorities (recommended map), enables the seven sources, MEI + global interrupts
#   * trap handler: CLAIM loop (1 + source id, 0 = none); per claimed source it appends the id to a log in DMEM (0x20100..),
#     ORs 1<<id into SCRATCH1, counts in SCRATCH0, clears the software-pend bit, then source-specific work
#     (WDT / DMA / TENSOR / VECTOR: the source is masked in INTC.ENABLE, the host re-enables it):
#       HOST (6)     : answer the mailbox: F2H_MSG0 = H2F_MSG0 + 1, F2H_MSG2 = H2F_CODE, ack H2F, ring F2H with code H2F_MSG0 + 1
#       RAS_WARN (2) : F2H_MSG3 = RAS.STATUS, WARN_EN = 0 (mask level source), W1C STATUS, read back
#       FATAL (0)    : F2H_MSG4 = RAS.STATUS, FATAL_EN = 0, W1C STATUS, read back
#   * idles in WFI
    .text
    .globl _start
_start:
    la    t0, trap
    csrw  mtvec, t0
    li    s0, 0x40000000            # SYSCTRL
    li    s1, 0x40001000            # INTC
    li    s2, 0x40005000            # MAILBOX
    li    s3, 0x40010000            # RAS
    li    t0, 6                     # BOOT_STAGE = FW_INIT
    sw    t0, 0x30(s0)
    lui   t0, 0x01020
    addi  t0, t0, 0x304             # FW_VERSION = 0x01020304
    sw    t0, 0x3C(s0)
    lw    t0, 0x4C(s0)              # SCRATCH3 = number of firmware starts
    addi  t0, t0, 1
    sw    t0, 0x4C(s0)
    sw    zero, 0x40(s0)            # SCRATCH0 = log index
    sw    zero, 0x44(s0)            # SCRATCH1 = served-source mask
    lui   t0, 0x02334
    addi  t0, t0, 0x567             # PRIO0: FATAL 7, WDT 6, RAS_WARN 5, DMA 4, TENSOR 3, VECTOR 3, HOST 2
    sw    t0, 0x20(s1)
    sw    zero, 0x10(s1)            # THRESHOLD = 0
    li    t0, 0x7F
    sw    t0, 0x04(s1)              # ENABLE sources 0..6
    li    t0, 0x20
    sw    t0, 0x04(s3)              # RAS.WARN_EN = EXT_WARN
    li    t0, 0x04
    sw    t0, 0x08(s3)              # RAS.FATAL_EN = EXT_FATAL
    li    t0, 0x800
    csrs  mie, t0                   # MEIE
    csrsi mstatus, 8                # MIE
    li    t0, 9                     # BOOT_STAGE = CMDPROC_READY
    sw    t0, 0x30(s0)
    li    t0, 7                     # HOST_STATUS = FW_RUNNING | CMDPROC_READY | HOST_READY (pins)
    sw    t0, 0x38(s0)
    lui   t0, 0xF00DD
    addi  t0, t0, -0x302            # 0xF00DCCFE
    sw    t0, 0x24(s2)              # F2H_MSG1 = 0xF00DCCFE (capability stand-in)
    li    t0, 0x0A
    sw    t0, 0x4C(s2)              # F2H_RING: host_irq_o
    li    t0, 0x0A                  # BOOT_STAGE = HOST_READY
    sw    t0, 0x30(s0)
idle:
    wfi
    j     idle

trap:
    lw    t0, 0x08(s1)              # CLAIM = 1 + id
    beqz  t0, trap_exit
    addi  t0, t0, -1                # id
    lw    t1, 0x40(s0)
    li    t2, 0x20100
    add   t2, t2, t1
    sb    t0, 0(t2)                 # log[idx] = id
    addi  t1, t1, 1
    sw    t1, 0x40(s0)              # idx++
    li    t2, 1
    sll   t2, t2, t0                # 1 << id
    lw    t3, 0x44(s0)
    or    t3, t3, t2
    sw    t3, 0x44(s0)              # served mask
    lw    t3, 0x0C(s1)              # INTC.SWPEND
    not   t4, t2
    and   t3, t3, t4
    sw    t3, 0x0C(s1)              # clear the software-pend bit of this source
    li    t4, 6
    beq   t0, t4, do_host
    li    t4, 2
    beq   t0, t4, do_ras_warn
    beqz  t0, do_ras_fatal
    lw    t3, 0x04(s1)              # WDT / DMA / TENSOR / VECTOR: the payload cannot clear the cause at the source, so it masks
    not   t4, t2                    # the source in INTC.ENABLE (a level source stuck high must not livelock the handler)
    and   t3, t3, t4
    sw    t3, 0x04(s1)
    j     trap
do_host:
    lw    t3, 0x00(s2)              # H2F_MSG0
    addi  t4, t3, 1
    sw    t4, 0x20(s2)              # F2H_MSG0 = H2F_MSG0 + 1
    lw    t5, 0x54(s2)              # H2F_CODE
    sw    t5, 0x28(s2)              # F2H_MSG2 = H2F_CODE
    sw    zero, 0x48(s2)            # H2F_ACK
    lw    zero, 0x40(s2)            # read back: the source output is registered
    sw    t4, 0x4C(s2)              # F2H_RING (host_irq_o), code = H2F_MSG0 + 1
    j     trap
do_ras_warn:
    lw    t3, 0x00(s3)
    sw    t3, 0x2C(s2)              # F2H_MSG3 = RAS.STATUS
    sw    zero, 0x04(s3)            # WARN_EN = 0
    li    t4, 0xFFFF
    sw    t4, 0x00(s3)              # W1C
    lw    zero, 0x00(s3)
    j     trap
do_ras_fatal:
    lw    t3, 0x00(s3)
    sw    t3, 0x30(s2)              # F2H_MSG4 = RAS.STATUS
    sw    zero, 0x08(s3)            # FATAL_EN = 0
    li    t4, 0xFFFF
    sw    t4, 0x00(s3)
    lw    zero, 0x00(s3)
    j     trap
trap_exit:
    mret
