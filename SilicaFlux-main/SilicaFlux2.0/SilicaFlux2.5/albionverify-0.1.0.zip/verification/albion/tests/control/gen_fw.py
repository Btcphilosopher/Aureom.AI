"""Regenerates the PAYLOAD words of ctl_fw.py from ctl_fw.S (needs llvm-mc and ld.lld): python tests/control/gen_fw.py"""
import re
import struct
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent


def assemble() -> bytes:
    with tempfile.TemporaryDirectory() as d:
        o, b = Path(d) / "fw.o", Path(d) / "fw.bin"
        subprocess.run(["llvm-mc", "-triple=riscv32", "-mattr=+m,+zicsr", "-filetype=obj", str(HERE / "ctl_fw.S"), "-o", str(o)], check=True)
        subprocess.run(["ld.lld", "-m", "elf32lriscv", "-Ttext=0x10100", "--oformat", "binary", str(o), "-o", str(b)], check=True)
        return b.read_bytes()


def words(b: bytes):
    return struct.unpack("<%dI" % (len(b) // 4), b)


if __name__ == "__main__":
    w = words(assemble())
    body = "\n".join("    " + ", ".join("0x%08x" % x for x in w[i:i + 6]) + "," for i in range(0, len(w), 6))
    src = (HERE / "ctl_fw.py").read_text()
    new = re.sub(r"PAYLOAD = \(\n.*?\n\)\n", "PAYLOAD = (\n" + body + "\n)\n", src, flags=re.S)
    (HERE / "ctl_fw.py").write_text(new)
    print("payload words:", len(w))
