"""cc_perf bench: 64-bit cycle counter, NEV event counters (per-cycle and rising-edge counting), FREEZE / CLEAR.

Reference model: albionverify/models/ctl_perf.py (from MEMORY_MAP.md block cc_perf and 05_ACCELERATORS.md section 4).
"""
import os

import cocotb

from albionverify.bus.regbus import RegBusMaster
from albionverify.core import Env
from albionverify.coverage import CoverGroup
from albionverify.models import ctl_spec as S
from albionverify.models.ctl_perf import PerfModel
from albionverify.reset import ResetSequencer
from albionverify.scoreboard import Scoreboard

from control.ctl_bench import (PARAMS, BlockChecker, PinDriver, RegTraffic, async_reset_midcycle, expect, finish, gap_cover, queue_sweep, txn_cover)

A = S.PERF
NEV = int(PARAMS.get("NEV", 20))
EDGE = int(PARAMS.get("EDGE", 0)) & ((1 << NEV) - 1)
SEED = int(os.environ.get("ALBION_SEED", "1"))
CNT = lambda i: A["CNT0"] + 4 * i
REGS = [(A["CTRL"], (0, 1, 2, 3, 0xFFFFFFFD, 0xFFFFFFFF)), (A["INFO"], ()), (A["CYCLE_LO"], ()), (A["CYCLE_HI"], ())] + [(CNT(i), ()) for i in range(NEV)] + [
    (CNT(NEV), ()), (CNT(NEV + 1), ())]


def kind_of(a):
    if a & 3:
        return "unmapped"
    if a == A["CTRL"]:
        return "rw"
    if a in (A["INFO"], A["CYCLE_LO"], A["CYCLE_HI"]) or A["CNT0"] <= a < CNT(NEV):
        return "ro"
    return "unmapped"


def build(dut, seed):
    env = Env(dut, name="perf", seed=seed)
    rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=4))
    rb = env.add(RegBusMaster("rb", env, rng=env.seeds.child("rb")))
    pins = env.add(PinDriver("pins", env.seeds.child("pins"), {"ev%d" % i: (env.sig("ev", lo=i, width=1), 1) for i in range(NEV)}))
    sb = Scoreboard(env, "perf")
    model = PerfModel(NEV, EDGE)
    rstn = env.sig("rst_n")
    chk = env.add(BlockChecker(
        "chk", model, sb,
        ins={"sel": env.sig("rb_sel"), "we": env.sig("rb_we"), "addr": env.sig("rb_addr"), "wdata": env.sig("rb_wdata"), "ev": env.sig("ev")},
        outs={"rdata": env.sig("rb_rdata"), "err": env.sig("rb_err")}, resets=lambda: {"sys": rstn.read() == 0}))
    tc = txn_cover("perf", {"ro": ("ok", "refused"), "rw": ("ok", "ok"), "unmapped": ("refused", "refused")})
    ec = CoverGroup("perf.events", "event counter activity")
    ec.point("counter", list(range(NEV)))
    ec.point("mode", ["level", "edge"])
    ec.point("action", ["counted", "held_by_freeze", "cleared_by_clr"])
    ec.cross("counter_mode", ["counter", "mode"], ignore=lambda c: (c[1] == "edge") != (((EDGE >> int(c[0])) & 1) == 1))
    cc = CoverGroup("perf.ctrl", "CTRL scenarios")
    cc.point("scenario", ["freeze_set", "freeze_clear", "clear", "clear_while_frozen", "clear_with_event_same_cycle", "event_during_freeze", "edge_lost_in_freeze", "multi_event_cycle"])
    ac = CoverGroup("perf.addr", "address boundaries")
    ac.point("addr", {"ctrl": 0x000, "info": 0x004, "cycle_lo": 0x010, "cycle_hi": 0x014, "hole_below_cnt": lambda a: 0x018 <= a < 0x100 or 0x008 <= a < 0x010,
                      "cnt0": 0x100, "last_cnt": CNT(NEV - 1), "first_hole_above": CNT(NEV), "page_last_word": 0xFFC})
    env.coverage += [tc, ec, cc, ac, gap_cover("perf")]

    def pre(inp, resets):  # classify from the PRE-edge state (wrapped around model.step below)
        if resets.get("sys"):
            return
        if inp["sel"]:
            tc.sample(dir="write" if inp["we"] else "read", kind=kind_of(inp["addr"]), result="refused" if model.evaluate(inp)["err"] else "ok")
            ac.sample(addr=inp["addr"])
        ev = inp["ev"]
        wr_ctl = inp["sel"] and inp["we"] and inp["addr"] == A["CTRL"]
        clr = wr_ctl and (inp["wdata"] >> 1) & 1
        if wr_ctl:
            if inp["wdata"] & 1 and not model.frz:
                cc.sample(scenario="freeze_set")
            if not inp["wdata"] & 1 and model.frz:
                cc.sample(scenario="freeze_clear")
        if clr:
            cc.sample(scenario="clear")
            if model.frz:
                cc.sample(scenario="clear_while_frozen")
            if ev:
                cc.sample(scenario="clear_with_event_same_cycle")
        if bin(ev).count("1") > 1:
            cc.sample(scenario="multi_event_cycle")
        for i in range(NEV):
            if (ev >> i) & 1:
                rising_only = (EDGE >> i) & 1
                inc = not (rising_only and (model.ev_prev >> i) & 1)
                mode = "edge" if rising_only else "level"
                if clr:
                    ec.sample(counter=i, mode=mode, action="cleared_by_clr")
                elif model.frz:
                    ec.sample(counter=i, mode=mode, action="held_by_freeze")
                    if rising_only and inc:
                        cc.sample(scenario="edge_lost_in_freeze")
                elif inc:
                    ec.sample(counter=i, mode=mode, action="counted")
        if model.frz and ev:
            cc.sample(scenario="event_during_freeze")

    orig = model.step

    def step(inp, resets):
        pre(inp, resets)
        return orig(inp, resets)

    model.step = step
    return env, rst, rb, pins, sb, model, chk


async def go(dut, seed):
    env, rst, rb, pins, sb, model, chk = build(dut, seed)
    await env.start()
    await env.until(lambda: not rst.asserted, 50, "reset release")
    return env, rst, rb, pins, sb, model, chk


async def drain(env, rb, n=200000):
    await env.until(lambda: rb.idle, n, "register ops")


def set_ev(pins, value):
    for i in range(NEV):
        pins.force("ev%d" % i, (value >> i) & 1)


# ============================================================================= tests


@cocotb.test()
async def reset_values(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)
    queue_sweep(rb)
    await drain(env, rb)
    by = {op.addr: op for op in rb.history}
    expect(sb, "CTRL reset (FREEZE = 0)", 0, by[A["CTRL"]].rdata)
    expect(sb, "INFO = number of event counters", NEV, by[A["INFO"]].rdata)
    expect(sb, "CYCLE_HI after reset", 0, by[A["CYCLE_HI"]].rdata)
    expect(sb, "CYCLE_LO is small just after reset", True, by[A["CYCLE_LO"]].rdata < 1100)
    for i in range(NEV):
        expect(sb, "counter %d reset value" % i, (0, False), (by[CNT(i)].rdata, by[CNT(i)].err))
    for a in (0x008, 0x00C, 0x018, 0x01C, 0x0FC, 0x0FF & ~3, CNT(NEV), CNT(NEV) + 4, 0x800, 0xFFC):
        expect(sb, "hole refused", (True, 0), (by[a].err, by[a].rdata), "0x%x" % a)
    ops = [rb.write_op(a, 0xFFFFFFFF) for a in (A["INFO"], A["CYCLE_LO"], A["CYCLE_HI"], CNT(0), CNT(NEV - 1), 0x008, CNT(NEV))]
    await drain(env, rb)
    for o in ops:
        expect(sb, "write to RO / hole refused", True, o.err, "0x%x" % o.addr)
    finish(env, sb, "reset_values", chk)


@cocotb.test()
async def counting_directed(dut):
    """Per-event exactness: each event input drives exactly its own counter; level events count cycles, EDGE events count rising edges."""
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)

    async def snap():
        ops = [rb.read_op(CNT(i)) for i in range(NEV)]
        await drain(env, rb)
        return [o.rdata for o in ops]

    cum = [0] * NEV
    for i in range(NEV):
        # 5 cycles high
        pins.force("ev%d" % i, 1)
        await env.cycles(5)
        pins.force("ev%d" % i, 0)
        await env.cycles(2)
        # then two separate pulses of 1 and 3 cycles
        pins.force("ev%d" % i, 1)
        await env.cycles(1)
        pins.force("ev%d" % i, 0)
        await env.cycles(2)
        pins.force("ev%d" % i, 1)
        await env.cycles(3)
        pins.force("ev%d" % i, 0)
        await env.cycles(3)
        per_cycle, edges = 5 + 1 + 3, 3
        cum[i] = edges if (EDGE >> i) & 1 else per_cycle
        got = await snap()
        expect(sb, "counter %d (%s) after the pattern" % (i, "edge" if (EDGE >> i) & 1 else "level"), cum, got)
    # two events at once count independently
    set_ev(pins, (1 << NEV) - 1)
    await env.cycles(4)
    set_ev(pins, 0)
    await env.cycles(3)
    exp = [cum[i] + (1 if (EDGE >> i) & 1 else 4) for i in range(NEV)]
    expect(sb, "all events high for 4 cycles", exp, await snap())
    finish(env, sb, "counting_directed", chk)


@cocotb.test()
async def freeze_clear_directed(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)
    e0 = 0
    level_i = next(i for i in range(NEV) if not (EDGE >> i) & 1)
    edge_i = next((i for i in range(NEV) if (EDGE >> i) & 1), None)

    async def rd(a):
        return (await rb.read(a)).rdata

    # cycle counter: free running, one per cycle
    o1 = await rb.read(A["CYCLE_LO"])
    await env.cycles(20)
    o2 = await rb.read(A["CYCLE_LO"])
    expect(sb, "CYCLE_LO advances one per cycle", o2.t_issue - o1.t_issue, o2.rdata - o1.rdata)
    # freeze holds cycle counter and event counters
    pins.force("ev%d" % level_i, 1)
    await env.cycles(5)
    c_before = await rd(CNT(level_i))
    await rb.write(A["CTRL"], 1)
    expect(sb, "FREEZE reads back", 1, await rd(A["CTRL"]))
    a = await rd(A["CYCLE_LO"])
    await env.cycles(10)
    b = await rd(A["CYCLE_LO"])
    expect(sb, "cycle counter frozen", a, b)
    expect(sb, "event counter frozen although the event is active", await rd(CNT(level_i)), await rd(CNT(level_i)))
    f1 = await rd(CNT(level_i))
    await env.cycles(10)
    expect(sb, "event counter holds while frozen", f1, await rd(CNT(level_i)))
    await rb.write(A["CTRL"], 0)
    await env.cycles(6)
    expect(sb, "counting resumes after unfreeze", True, await rd(CNT(level_i)) > f1)
    pins.force("ev%d" % level_i, 0)
    if edge_i is not None:
        # a rising edge while frozen is lost; an input already high at unfreeze is not a new edge
        pins.force("ev%d" % edge_i, 0)
        await env.cycles(3)
        n0 = await rd(CNT(edge_i))
        await rb.write(A["CTRL"], 1)
        pins.force("ev%d" % edge_i, 1)
        await env.cycles(4)
        await rb.write(A["CTRL"], 0)
        await env.cycles(4)
        pins.force("ev%d" % edge_i, 0)
        await env.cycles(3)
        expect(sb, "rising edge during FREEZE is not counted; level held through unfreeze is not an edge", n0, await rd(CNT(edge_i)))
        pins.force("ev%d" % edge_i, 1)
        await env.cycles(3)
        pins.force("ev%d" % edge_i, 0)
        await env.cycles(3)
        expect(sb, "next real edge counted", n0 + 1, await rd(CNT(edge_i)))
    # CLEAR: all counters and the cycle counter; bit0 of the same write sets FREEZE
    await rb.write(A["CTRL"], 2)
    expect(sb, "CLEAR zeroes the event counters", 0, await rd(CNT(level_i)))
    expect(sb, "CLEAR zeroes the cycle counter (small value)", True, await rd(A["CYCLE_LO"]) < 20)
    expect(sb, "CLEAR bit does not read back", 0, await rd(A["CTRL"]))
    await rb.write(A["CTRL"], 3)  # clear + freeze in one write
    expect(sb, "freeze set by the same write", 1, await rd(A["CTRL"]))
    v = await rd(A["CYCLE_LO"])
    await env.cycles(5)
    expect(sb, "cycle counter frozen after clear+freeze, at 0", (0, 0), (v, await rd(A["CYCLE_LO"])))
    await rb.write(A["CTRL"], 2 | 1)  # clear while frozen works
    await rb.write(A["CTRL"], 0)
    # CLEAR in the same cycle as an event: the clear wins
    pins.force("ev%d" % level_i, 1)
    await env.cycles(6)
    await env.tick()
    rb.write_op(A["CTRL"], 2)
    await env.tick()
    pins.force("ev%d" % level_i, 0)
    await env.cycles(4)
    expect(sb, "clear beats an event in the same cycle (counter restarts from the clear)", True, await rd(CNT(level_i)) <= 4)
    finish(env, sb, "freeze_clear_directed", chk)


@cocotb.test()
async def unaligned_probe(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)
    ops = []
    for base in (0x000, 0x004, 0x010, 0x100, CNT(NEV - 1)):
        for off in (1, 2, 3):
            ops.append(rb.write_op(base + off, 0xFFFF))
            ops.append(rb.read_op(base + off))
    await drain(env, rb)
    for o in ops:
        expect(sb, "unaligned access refused", True, o.err, "%s 0x%x" % ("write" if o.write else "read", o.addr))
    finish(env, sb, "unaligned_probe", chk)


def pin_profile(pins, phase, rng):
    for i in range(NEV):
        pins.set("ev%d" % i, "off")
    if phase == 0:
        for i in range(NEV):
            pins.set("ev%d" % i, "rand", 0.3)
    elif phase == 1:
        for i in range(NEV):
            pins.set("ev%d" % i, "level", 0.1)
    elif phase == 2:
        for i in range(NEV):
            pins.set("ev%d" % i, "level", 0.5)
    elif phase == 3:
        for i in range(NEV):
            if rng.random() < 0.3:
                pins.set("ev%d" % i, "rand", 0.8)
    elif phase == 4:
        for i in range(NEV):
            pins.set("ev%d" % i, "hold", 1)


@cocotb.test()
async def random_traffic(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)
    rng = env.seeds.child("traffic")
    n_ops = int(os.environ.get("CTL_OPS", "6000"))
    for phase in range(6):
        pin_profile(pins, phase, rng)
        regs = REGS if phase != 5 else [(A["CTRL"], (0, 1, 2, 3))] + REGS[1:]
        tr = RegTraffic(rng, regs, p_reg=0.85, p_hole=0.08, p_write=[0.15, 0.2, 0.1, 0.25, 0.1, 0.3][phase])
        rb.gap.set_mode(["always", "random:0.5", "bursty:1-6", "always", "random:0.9", "random:0.3"][phase])
        tr.queue(rb, n_ops // 6)
        await drain(env, rb)
    queue_sweep(rb)
    await drain(env, rb)
    finish(env, sb, "random_traffic", chk)


@cocotb.test()
async def reset_traffic(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)
    rng = env.seeds.child("rst")
    tr = RegTraffic(rng, REGS, p_reg=0.9, p_hole=0.05, p_write=0.2)
    for rnd in range(10):
        pin_profile(pins, rng.randrange(5), rng)
        tr.queue(rb, 100 + rng.randrange(200))
        await env.until(lambda: len(rb.queue) < 20, 30000, "traffic running")
        n0 = rst.n_pulses
        if rnd % 2 == 0:
            rst.pulse(length=rng.randint(1, 3), delay=rng.randint(1, 4), reason="sync-reset")
        else:
            await env.tick()
            await async_reset_midcycle(env, rst, rng.choice((1.0, 2.0, 3.0, 4.0, 6.0, 7.0, 8.5)), rng.randint(1, 3))
        await env.until(lambda: rst.n_pulses > n0, 20, "reset asserted")
        pin_profile(pins, 5, rng)  # events quiet from the reset on
        await env.cycles(2)
        await env.until(lambda: not rst.asserted, 20, "reset release")
        await env.cycles(3)
        for i in (0, NEV - 1):
            expect(sb, "counter %d after reset #%d" % (i, rnd), 0, (await rb.read(CNT(i))).rdata)
        expect(sb, "FREEZE cleared by reset", 0, (await rb.read(A["CTRL"])).rdata)
        expect(sb, "cycle counter restarted", True, (await rb.read(A["CYCLE_LO"])).rdata < 40)
    finish(env, sb, "reset_traffic", chk)


@cocotb.test()
async def cycle_counter_wide(dut):
    """The wide counters: 70 000 cycles with one level event held high -- CYCLE_LO and that event counter pass 16 bits
    (a 16-bit / 0xFFFF-saturating counter would stop).  CYCLE_HI stays 0 (a carry needs 2^32 cycles: not reachable) -- long test."""
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)
    level_i = next(i for i in range(NEV) if not (EDGE >> i) & 1)
    await rb.write(A["CTRL"], 2)
    pins.force("ev%d" % level_i, 1)
    await env.cycles(70000)
    o = await rb.read(A["CYCLE_LO"])
    c = await rb.read(CNT(level_i))
    expect(sb, "CYCLE_LO beyond 16 bits", True, o.rdata > 65536)
    expect(sb, "event counter beyond 16 bits (one count per cycle)", True, 69900 < c.rdata <= 70010)
    expect(sb, "CYCLE_HI still 0", 0, (await rb.read(A["CYCLE_HI"])).rdata)
    finish(env, sb, "cycle_counter_wide", chk)
