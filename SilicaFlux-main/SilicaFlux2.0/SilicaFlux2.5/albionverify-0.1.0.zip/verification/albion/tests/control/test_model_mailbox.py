"""Pure-Python tests of the cc_mailbox reference model (hand-computed spec examples, no simulator)."""
import pytest

from albionverify.models import ctl_spec as S
from albionverify.models.ctl_mailbox import MailboxModel

A = S.MAILBOX
OK = {"sel": 1}


def acc(m, we, addr, wdata=0, sel=1):
    """One cycle: returns the combinational outputs then clocks the model."""
    inp = {"sel": sel, "we": we, "addr": addr, "wdata": wdata}
    out = m.evaluate(inp)
    m.clock(inp)
    return out


def wr(m, addr, d=0):
    return acc(m, 1, addr, d)


def rd(m, addr):
    return acc(m, 0, addr)


def test_reset_state_and_pins():
    m = MailboxModel(256)
    for a in [0x000, 0x01C, 0x020, 0x03C, A["DB_STATUS"], A["H2F_CODE"], A["F2H_CODE"], A["RING_COUNT"], A["DIAG_RX"], A["DIAG_STATUS"]]:
        o = rd(m, a)
        assert (o["rdata"], o["err"]) == (0, 0), hex(a)
    assert (o["irq_h2f"], o["host_irq"]) == (0, 0)


def test_ring_sets_pending_latches_code_counts_and_ack_clears():
    m = MailboxModel()
    wr(m, A["H2F_RING"], 0xCAFE0001)
    assert rd(m, A["DB_STATUS"])["rdata"] == 0b01
    assert m.evaluate({"sel": 0, "we": 0, "addr": 0, "wdata": 0})["irq_h2f"] == 1
    assert rd(m, A["H2F_CODE"])["rdata"] == 0xCAFE0001
    wr(m, A["F2H_RING"], 7)
    assert rd(m, A["DB_STATUS"])["rdata"] == 0b11
    assert m.evaluate({"sel": 0, "we": 0, "addr": 0, "wdata": 0})["host_irq"] == 1
    assert rd(m, A["RING_COUNT"])["rdata"] == (1 << 16) | 1
    wr(m, A["H2F_ACK"], 0xFFFFFFFF)
    assert rd(m, A["DB_STATUS"])["rdata"] == 0b10
    assert rd(m, A["H2F_CODE"])["rdata"] == 0xCAFE0001  # code survives the ack
    wr(m, A["F2H_ACK"])
    assert rd(m, A["DB_STATUS"])["rdata"] == 0


def test_ring_count_wraps_at_16_bits_per_direction():
    m = MailboxModel()
    for _ in range(65536 + 3):
        wr(m, A["H2F_RING"], 1)
    assert rd(m, A["RING_COUNT"])["rdata"] == 3
    for _ in range(5):
        wr(m, A["F2H_RING"], 1)
    assert rd(m, A["RING_COUNT"])["rdata"] == (5 << 16) | 3


def test_console_fifo_keeps_first_depth_characters_and_sets_ovf():
    m = MailboxModel(4)
    for c in (0x61, 0x62, 0x63, 0x64):
        wr(m, A["DIAG_TX"], 0xFFFFFF00 | c)  # only [7:0] is the character
    assert rd(m, A["DIAG_STATUS"])["rdata"] == 4
    wr(m, A["DIAG_TX"], 0x65)  # dropped
    assert rd(m, A["DIAG_STATUS"])["rdata"] == 0x10000 | 4
    assert rd(m, A["DIAG_RX"])["rdata"] == 0x161
    assert rd(m, A["DIAG_RX"])["rdata"] == 0x161  # reads have no side effect
    wr(m, A["DIAG_POP"])
    assert rd(m, A["DIAG_RX"])["rdata"] == 0x162
    wr(m, A["DIAG_STATUS"], 0xFFFF)  # not bit 16: OVF stays
    assert rd(m, A["DIAG_STATUS"])["rdata"] == 0x10000 | 3
    wr(m, A["DIAG_STATUS"], 0x10000)
    assert rd(m, A["DIAG_STATUS"])["rdata"] == 3
    for _ in range(3):
        wr(m, A["DIAG_POP"])
    assert rd(m, A["DIAG_RX"])["rdata"] == 0
    wr(m, A["DIAG_POP"])  # empty pop is harmless
    assert rd(m, A["DIAG_STATUS"])["rdata"] == 0


def test_diag_pins_mirror_every_diag_tx_write_even_when_dropped():
    m = MailboxModel(1)
    o = wr(m, A["DIAG_TX"], 0x1234_5641)
    assert (o["diag_valid"], o["diag_char"]) == (1, 0x41)
    o = wr(m, A["DIAG_TX"], 0x42)  # full: dropped but still mirrored
    assert (o["diag_valid"], o["diag_char"]) == (1, 0x42)
    o = rd(m, A["DIAG_TX"])
    assert o["diag_valid"] == 0 and o["err"] == 1


def test_access_classes():
    m = MailboxModel()
    for a in (A["DB_STATUS"], A["H2F_CODE"], A["F2H_CODE"], A["RING_COUNT"], A["DIAG_RX"]):  # RO: write refused, read ok
        assert wr(m, a, 5)["err"] == 1 and rd(m, a)["err"] == 0
    for a in (A["H2F_RING"], A["H2F_ACK"], A["F2H_RING"], A["F2H_ACK"], A["DIAG_TX"], A["DIAG_POP"]):  # WO: read refused (A-1)
        assert rd(m, a)["err"] == 1 and rd(m, a)["rdata"] == 0
    for a in (0x060, 0x07C, 0x090, 0x800, 0xFFC, 0x001, 0x03D, 0x08D):  # unmapped / unaligned
        assert wr(m, a, 1)["err"] == 1 and rd(m, a)["err"] == 1


def test_refused_write_has_no_side_effect():
    m = MailboxModel(4)
    wr(m, 0x000, 0x1111)
    wr(m, A["DB_STATUS"], 0xFFFF)
    wr(m, A["RING_COUNT"], 0xFFFF)
    wr(m, A["DIAG_RX"], 0xFFFF)
    wr(m, 0x064, 0xFFFF)
    assert rd(m, 0x000)["rdata"] == 0x1111
    assert rd(m, A["DB_STATUS"])["rdata"] == 0 and rd(m, A["RING_COUNT"])["rdata"] == 0 and rd(m, A["DIAG_STATUS"])["rdata"] == 0


def test_message_words_and_independence():
    m = MailboxModel()
    for i in range(8):
        wr(m, 4 * i, 0x100 + i)
        wr(m, 0x20 + 4 * i, 0x200 + i)
    for i in range(8):
        assert rd(m, 4 * i)["rdata"] == 0x100 + i
        assert rd(m, 0x20 + 4 * i)["rdata"] == 0x200 + i


def test_reset_clears_everything():
    m = MailboxModel(4)
    wr(m, A["H2F_RING"], 5)
    wr(m, A["F2H_RING"], 6)
    wr(m, A["DIAG_TX"], 9)
    wr(m, 0x004, 0xAA)
    m.reset()
    assert (m.h2f_pend, m.f2h_pend, m.ovf, len(m.fifo), m.h2f_cnt, m.f2h_cnt, m.h2f[1]) == (0, 0, 0, 0, 0, 0, 0)


def test_step_ignores_inputs_in_reset():
    m = MailboxModel()
    wr(m, A["H2F_RING"], 5)
    out = m.step({"sel": 1, "we": 1, "addr": A["H2F_RING"], "wdata": 7}, {"sys": True})
    assert out["irq_h2f"] == 0  # evaluated on the reset state
    assert m.h2f_pend == 0 and m.h2f_cnt == 0  # and the write during reset is lost
