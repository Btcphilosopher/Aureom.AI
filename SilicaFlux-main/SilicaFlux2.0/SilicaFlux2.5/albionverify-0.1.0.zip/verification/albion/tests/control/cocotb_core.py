"""silicaflux_control_core bench: boot ROM stage progression, host mailbox hand-shake, interrupt delivery to the CPU, reset during boot,
boot_mode variants, host-port access control -- everything observable through the DOCUMENTED host port, pins and registers.

The DUT is the real core (RV32IM CPU, 8 KiB boot ROM, IMEM / DMEM, crossbar, INTC, timer, WDT, DMA, mailbox, RAS, PMU, ...).  The
accelerator side is absent (acc_rb_err = 1) and the external window is served by a Python device-memory slave.  The bench is the host:
it reads/writes the SYSCTRL / MAILBOX / RAS / PMU ... pages and IMEM / DMEM through the SFB2 host port (``hs_*``), drives the
boot straps / reset request / interrupt inputs, and checks every result against values prescribed by the specification
(docs 03_BOOT.md, 04_INTERRUPTS.md, MEMORY_MAP.md, HW_SW_INTERFACE.md) -- not against RTL internals.  A tiny payload (ctl_fw.S) gives the
boot ROM a valid image to hand over to.
"""
import os

import cocotb

from albionverify.bus.reqrsp import Req, ReqRspMaster, ReqRspMonitor, ReqRspSlave, sfb_port
from albionverify.core import Agent, Env
from albionverify.coverage import CoverGroup
from albionverify.memory import BackingStore
from albionverify.models import ctl_spec as S
from albionverify.reset import ResetSequencer
from albionverify.scoreboard import Scoreboard

from control import ctl_fw
from control.ctl_bench import PinDriver, Recorder, async_reset_midcycle, expect

SEED = int(os.environ.get("ALBION_SEED", "1"))
PB = S.PERIPH_BASE
SYS = PB + 0x0000
INTC = PB + 0x1000
MBX = PB + 0x5000
PERF = PB + 0x6000
PMU = PB + 0x7000
RAS = PB + 0x10000
SEC = PB + 0x11000
STAGE = S.BOOT_STAGE
EXT_IMAGE = S.EXT_IMAGE_DEFAULT
DEVMEM_BASE = 0x2000_0000


class DiagTap(Agent):
    """Characters strobed on diag_valid_o / diag_char_o (the simulation tap of the console)."""

    def __init__(self, name, valid, char):
        super().__init__(name)
        self.v, self.c = valid, char
        self.chars = []

    def sample(self):
        if self.v.read():
            self.chars.append((self.env.cycle, self.c.read()))

    def text(self):
        return bytes(c for _, c in self.chars).decode("ascii", "replace")


class LevelTap(Agent):
    """Holds the latest value of a few pins (``cur``) and a log of their changes -- cheap enough for million-cycle boots."""

    def __init__(self, name, sigs):
        super().__init__(name)
        self.sigs = sigs
        self.cur = {k: 0 for k in sigs}
        self.changes = {k: [] for k in sigs}

    def sample(self):
        for k, s in self.sigs.items():
            v = s.read()
            if v != self.cur[k]:
                self.changes[k].append((self.env.cycle, v))
            self.cur[k] = v


class AccLog(Agent):
    """Every strobe on the accelerator register port: (cycle, we, addr, wdata)."""

    def __init__(self, name, sel, we, addr, wdata):
        super().__init__(name)
        self.p = (sel, we, addr, wdata)
        self.strobes = []

    def sample(self):
        if self.p[0].read():
            self.strobes.append((self.env.cycle, self.p[1].read(), self.p[2].read(), self.p[3].read()))


class ClkCount:
    """Counts rising edges of the gated accelerator clock acc_clk_o."""

    def __init__(self, dut):
        self.n = 0
        self.task = cocotb.start_soon(self.run(dut))

    async def run(self, dut):
        from cocotb.triggers import RisingEdge

        while True:
            await RisingEdge(dut.acc_clk_o)
            self.n += 1


class Core:
    pass


def core_cover(env):
    b = CoverGroup("core.boot", "boot paths, stages and reset kinds")
    b.point("stage", list(S.BOOT_STAGE))
    b.point("path", ["host_load", "ext_dma", "warm", "ext_fallback_to_host", "bad_image_then_good"])
    b.point("reset", ["por_sync", "por_async_midboot", "host_req_midboot", "host_req_running", "soft", "wdt"])
    b.point("boot_mode", [0, 1, 2, 3])
    e = CoverGroup("core.boot_errors", "image rejection reasons (BOOT_ERR_*)")
    e.point("err", ["MAGIC", "HDR_VERSION", "SIZE", "ENTRY", "CRC", "unknown_command_BUSY"])
    i = CoverGroup("core.irq", "interrupt sources reaching the CPU")
    i.point("source", list(S.IRQ))
    i.point("origin", ["software_pend", "real_input"])
    i.point("scenario", ["single", "simultaneous_priority_order", "masked_by_enable", "masked_by_threshold", "isolated_accelerator_masked", "repeated"])
    a = CoverGroup("core.access", "host-port access classes")
    a.point("cls", ["reg_ok", "rom_read", "mem_rw", "hole", "ro_write", "subword_write", "absent_page", "forwarded_page", "unmapped", "ext_window", "misaligned", "rom_write",
                    "lock_refused_imem", "lock_refused_dmem", "lock_refused_rom", "lock_periph_ok", "isolated_forwarded_page"])
    a.point("rw", ["read", "write"])
    env.coverage += [b, e, i, a]
    return b, e, i, a


def build(dut, seed, *, boot_mode=0, ext_thr="random:0.8", ext_rsp="random:0.8", latency="uniform:1-3", devmem=None, watch_acc=False, ext_monitor=False):
    c = Core()
    env = c.env = Env(dut, name="core", seed=seed)
    c.rst = env.add(ResetSequencer("rst", env.sig("rst_ni"), initial_cycles=6))
    c.host = env.add(ReqRspMaster("host", sfb_port(env, "hs_"), rng=env.seeds.child("host"), req_throttle="always", rsp_throttle="always", max_outstanding=1))
    c.devmem = devmem if devmem is not None else BackingStore("zero", "devmem")
    c.ext = env.add(ReqRspSlave("ext", sfb_port(env, "ext_"), memory=c.devmem, rng=env.seeds.child("ext"), req_throttle=ext_thr, rsp_throttle=ext_rsp, latency=latency))
    c.pins = env.add(PinDriver("pins", env.seeds.child("pins"), {
        "boot_mode_i": (env.sig("boot_mode_i"), 2), "host_rst_req_i": (env.sig("host_rst_req_i"), 1), "ext_warn_i": (env.sig("ext_warn_i"), 1),
        "ext_fatal_i": (env.sig("ext_fatal_i"), 1), "acc_vec_irq_i": (env.sig("acc_vec_irq_i"), 1), "acc_tsu_irq_i": (env.sig("acc_tsu_irq_i"), 1),
        "acc_vec_busy_i": (env.sig("acc_vec_busy_i"), 1), "acc_tsu_busy_i": (env.sig("acc_tsu_busy_i"), 1), "acc_tsu_halted_i": (env.sig("acc_tsu_halted_i"), 1)}))
    c.pins.force("boot_mode_i", boot_mode)
    env.tie("test_mode", value=0)
    env.tie("acc_rb_rdata", value=0)
    env.tie("acc_rb_err", value=1)  # accelerator register port: "absent" (every access answers with an error)
    c.mon = env.add(ReqRspMonitor("mon_host", sfb_port(env, "hs_"), outstanding_limit=1))
    if ext_monitor:
        c.mon_ext = env.add(ReqRspMonitor("mon_ext", sfb_port(env, "ext_"), outstanding_limit=1))
    c.rec = env.add(LevelTap("rec", {n: env.sig(n) for n in ("host_irq_o", "host_ready_o", "cmdproc_ready_o", "ras_fatal_o", "hs_req_ready")}))
    c.acc = env.add(AccLog("acc", env.sig("acc_rb_sel"), env.sig("acc_rb_we"), env.sig("acc_rb_addr"), env.sig("acc_rb_wdata"))) if watch_acc else None
    c.diag = env.add(DiagTap("diag", env.sig("diag_valid_o"), env.sig("diag_char_o")))
    c.sb = Scoreboard(env, "core")
    c.cov = core_cover(env)
    return c


async def start(c):
    await c.env.start()
    await c.env.until(lambda: not c.rst.asserted, 100, "reset release")


async def hwait(c, t, max_cycles=20000, what="host transaction"):
    await c.env.until(lambda: t.done, max_cycles, what)
    return t


async def hrd(c, addr, max_cycles=20000):
    t = c.host.read(addr)
    await hwait(c, t, max_cycles, "host read 0x%08x" % addr)
    return t


async def hwr(c, addr, data, strb=None, max_cycles=20000):
    t = c.host.write(addr, data, strb)
    await hwait(c, t, max_cycles, "host write 0x%08x" % addr)
    return t


async def hrd_ok(c, addr, what=""):
    t = await hrd(c, addr)
    if t.rsp is None or t.rsp.err:
        c.sb.fail("host read of 0x%08x (%s) returned an error / was cancelled" % (addr, what))
        return None
    return t.rsp.rdata


async def hwr_ok(c, addr, data, what=""):
    t = await hwr(c, addr, data)
    if t.rsp is None or t.rsp.err:
        c.sb.fail("host write of 0x%08x (%s) returned an error / was cancelled" % (addr, what))
    return t


STAGE_REG = S.SYSCTRL["BOOT_STAGE"]
STAGE_NAME = {v: k for k, v in S.BOOT_STAGE.items()}


async def soft_reset(c, key=S.SOFT_RESET_KEY):
    """SYSCTRL.SOFT_RESET write.  The write resets the core itself: its response is lost (a host access in flight when a ControlCore reset is
    applied is lost, docs/09_LIMITATIONS.md; SFB2 R11 cancels it), so the host master's transaction and the port monitor are cancelled here."""
    t = c.host.write(SYS + S.SYSCTRL["SOFT_RESET"], key)
    await c.env.cycles(12)
    c.sb.check(t.rsp is None, "a SOFT_RESET write completed although the core was reset by it")
    c.host.on_reset(True)
    c.host.on_reset(False)
    c.mon.on_reset(True)


async def wait_stage(c, want, budget, *, gap=6, seen=None):
    """Poll BOOT_STAGE through the host port until it reads ``want`` (a value or a collection of values); returns the value."""
    env = c.env
    want = {want} if isinstance(want, int) else set(want)
    t0 = env.cycle
    while env.cycle - t0 < budget:
        t = c.host.read(SYS + STAGE_REG)
        await hwait(c, t, 20000)
        if t.rsp is not None and not t.rsp.err:
            v = t.rsp.rdata
            if seen is not None and (not seen or seen[-1] != v):
                seen.append(v)
            if v in STAGE_NAME:
                c.cov[0].sample(stage=STAGE_NAME[v])
            if v in want:
                return v
        await env.cycles(gap)
    c.sb.fail("BOOT_STAGE did not reach %s within %d cycles (last seen %s)" % (sorted(want), budget, (seen or ["-"])[-1]))


async def load_image(c, img, *, window=48):
    """Write ``img`` into IMEM through the host port (word writes from CC_IMEM_BASE), pipelined."""
    words = ctl_fw.image_words(img)
    ts = []
    for i, w in enumerate(words):
        ts.append(c.host.write(S.IMEM_BASE + 4 * i, w))
        if len(ts) > window:
            await hwait(c, ts[-window], 20000)
    await hwait(c, ts[-1], 20000)
    for t in ts:
        if t.rsp is None or t.rsp.err:
            c.sb.fail("IMEM write 0x%08x failed (err=%s)" % (t.req.addr, None if t.rsp is None else t.rsp.err))


async def verify_image(c, img):
    words = ctl_fw.image_words(img)
    ts = [c.host.read(S.IMEM_BASE + 4 * i) for i in range(len(words))]
    await hwait(c, ts[-1], 20000)
    bad = [(hex(t.req.addr), hex(w), None if t.rsp is None else hex(t.rsp.rdata)) for t, w in zip(ts, words) if t.rsp is None or t.rsp.err or t.rsp.rdata != w]
    c.sb.check(not bad, "IMEM readback differs from the loaded image: %s" % bad[:4])


async def image_ready(c, msg1=None):
    """H2F_MSG0 = IMAGE_READY, ring H2F (HW_SW_INTERFACE.md section 2 step 3)."""
    await hwr_ok(c, MBX + S.MAILBOX["H2F_MSG0"], S.MBOX_CMD["IMAGE_READY"], "H2F_MSG0")
    if msg1 is not None:
        await hwr_ok(c, MBX + S.MAILBOX["H2F_MSG0"] + 4, msg1, "H2F_MSG1")
    await hwr_ok(c, MBX + S.MAILBOX["H2F_RING"], 1, "H2F_RING")


async def wait_host_irq(c, budget, what="host_irq_o"):
    await c.env.until(lambda: c.rec.cur["host_irq_o"] == 1, budget, what)


async def ack_f2h(c):
    await hwr_ok(c, MBX + S.MAILBOX["F2H_ACK"], 1, "F2H_ACK")


async def read_answer(c):
    """(F2H_MSG0, F2H_MSG1).  Answer format (06_FIRMWARE.md section 4): F2H_MSG0 = status | cmd << 8 | seq << 16."""
    m0 = await hrd_ok(c, MBX + S.MAILBOX["F2H_MSG0"], "F2H_MSG0")
    m1 = await hrd_ok(c, MBX + S.MAILBOX["F2H_MSG0"] + 4, "F2H_MSG1")
    return m0, m1


def status_of(m0):
    return None if m0 is None else m0 & 0xFF


async def boot_host_image(c, img=None, *, budget_rom=900_000, budget_check=900_000, seen=None):
    """Reset released, host-load mode: wait for WAIT_IMAGE, load, IMAGE_READY, wait for the ROM answer.  Returns (F2H_MSG0, F2H_MSG1)."""
    img = img if img is not None else ctl_fw.make_image()
    await wait_stage(c, S.BOOT_STAGE["WAIT_IMAGE"], budget_rom, seen=seen)
    await load_image(c, img)
    await image_ready(c)
    await wait_host_irq(c, budget_check, "ROM answer (host_irq_o)")
    m0, m1 = await read_answer(c)
    await ack_f2h(c)
    return m0, m1


async def read_log(c, start, n):
    """Claimed-source ids logged by the payload's trap handler in DMEM (0x20100 + index)."""
    out = bytearray()
    w0, w1 = start // 4, (start + n + 3) // 4
    for w in range(w0, w1):
        out += (await hrd_ok(c, S.DMEM_BASE + 0x100 + 4 * w)).to_bytes(4, "little")
    return list(out[start - 4 * w0:start - 4 * w0 + n])


def rom_words():
    import re

    from albionverify import rtl

    t = (rtl.RTL_DIR / "controlcore/rtl/generated/sfv_bootrom_image.sv").read_text()
    return {int(a, 16): int(d, 16) for a, d in re.findall(r"11'h([0-9a-f]+): data = 32'h([0-9a-f]+);", t)}


def finish_core(c, name, **extra):
    c.sb.finalize(allow_outstanding=True)
    c.env.finalize()
    mons = {"host": c.mon.summary()}
    if hasattr(c, "mon_ext"):
        mons["ext"] = c.mon_ext.summary()
    return c.env.write_result(name, scoreboard=c.sb.summary(), monitors=mons, **extra)


# ============================================================================= tests


@cocotb.test()
async def boot_handshake_irq(dut):
    """Host-load boot, mailbox hand-shake, firmware start, interrupt delivery (mailbox doorbell, software-pended sources in priority order,
    masking by ENABLE / THRESHOLD, real inputs ext_warn_i / ext_fatal_i / acc irqs), pins and POR-domain persistence."""
    c = build(dut, SEED)
    sb, env = c.sb, c.env
    cb, ce, ci, ca = c.cov
    await start(c)
    seen = []
    await wait_stage(c, S.BOOT_STAGE["WAIT_IMAGE"], 900_000, seen=seen)
    expect(sb, "stages observed during ROM boot are increasing and end at WAIT_IMAGE", True, seen == sorted(set(seen)) and seen[-1] == 3, str(seen))
    expect(sb, "stages seen are documented ROM stages", True, set(seen) <= {0, 1, 2, 3}, str(seen))
    # identity / reset cause / counts through the host port while the ROM waits
    for nm, v in (("ID", 0x53464343), ("HW_VERSION", 0x00010000), ("MAP_VERSION", 0x00010000), ("FEATURES", 0x7F), ("ROM_BYTES", 0x2000), ("IMEM_BYTES", 0x10000),
                  ("DMEM_BYTES", 0x8000), ("RESET_CAUSE", 0x1), ("RESET_COUNT", 0), ("BOOT_MODE", 0), ("SCRATCH0", 0)):
        expect(sb, nm, v, await hrd_ok(c, SYS + S.SYSCTRL[nm], nm))
    expect(sb, "pins before firmware", (0, 0), (dut.host_ready_o.value.integer, dut.cmdproc_ready_o.value.integer))
    # console: the ROM banner appeared on the diag tap and is readable by the host from DIAG_RX / DIAG_POP
    n_tap = len(c.diag.chars)
    expect(sb, "ROM printed a banner on the diag tap", True, n_tap > 8, str(n_tap))
    lvl = await hrd_ok(c, MBX + S.MAILBOX["DIAG_STATUS"], "DIAG_STATUS")
    expect(sb, "console level == characters strobed on the tap (banner < 256)", (n_tap, 0), (lvl & 0x1FF, lvl >> 16 & 1))
    got = []
    for _ in range(n_tap):
        v = await hrd_ok(c, MBX + S.MAILBOX["DIAG_RX"], "DIAG_RX")
        got.append(v)
        await hwr_ok(c, MBX + S.MAILBOX["DIAG_POP"], 0, "DIAG_POP")
    expect(sb, "console FIFO content == tap characters", [(0x100 | ch) for _, ch in c.diag.chars[:n_tap]], got)
    # image, hand-over
    img = ctl_fw.make_image()
    await load_image(c, img)
    await verify_image(c, img)
    await image_ready(c)
    await wait_host_irq(c, 900_000, "ROM answer")
    m0, m1 = await read_answer(c)
    expect(sb, "ROM answers OK (status in F2H_MSG0[7:0], command echo in [15:8])", (S.MBOX_STS["OK"], S.MBOX_CMD["IMAGE_READY"]), (m0 & 0xFF, m0 >> 8 & 0xFF))
    await ack_f2h(c)
    cb.sample(path="host_load")
    await wait_stage(c, S.BOOT_STAGE["HOST_READY"], 400_000, seen=seen)
    expect(sb, "pins after firmware start (HOST_STATUS written by the payload)", (1, 1), (dut.host_ready_o.value.integer, dut.cmdproc_ready_o.value.integer))
    expect(sb, "FW_VERSION published", 0x01020304, await hrd_ok(c, SYS + S.SYSCTRL["FW_VERSION"]))
    expect(sb, "HOST_STATUS = FW_RUNNING|CMDPROC_READY|HOST_READY", 7, await hrd_ok(c, SYS + S.SYSCTRL["HOST_STATUS"]))
    expect(sb, "one firmware start", 1, await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH3"]))
    expect(sb, "SECURITY.BOOT_MEASURE = CRC32 of the payload (written once by the ROM)", ctl_fw.crc32(img[0x100:]), await hrd_ok(c, SEC + S.SECMON["BOOT_MEASURE"]))
    expect(sb, "SECURITY.STATUS MEASURED", 1, (await hrd_ok(c, SEC + S.SECMON["STATUS"])) >> 1 & 1)
    expect(sb, "capability message from the payload", 0xF00DCCFE, await hrd_ok(c, MBX + S.MAILBOX["F2H_MSG0"] + 4))
    if dut.host_irq_o.value.integer:
        await ack_f2h(c)
    await env.cycles(50)
    # ---- mailbox doorbell -> HOST interrupt -> handler -> answer
    async def served():
        return await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH1"]), await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH0"])

    for k, (msg, code) in enumerate(((0x1234, 0x77), (0xFFFF0000, 0x1), (0, 0xAB))):
        await hwr_ok(c, MBX + S.MAILBOX["H2F_MSG0"], msg, "H2F_MSG0")
        await hwr_ok(c, MBX + S.MAILBOX["H2F_RING"], code, "H2F_RING")
        await wait_host_irq(c, 20000, "firmware answer #%d" % k)
        m0, _ = await read_answer(c)
        expect(sb, "firmware answer to H2F message %d" % k, (msg + 1) & 0xFFFFFFFF, m0)
        expect(sb, "H2F_CODE echoed by the firmware", code, await hrd_ok(c, MBX + S.MAILBOX["F2H_MSG0"] + 8))
        expect(sb, "F2H_CODE = reply code", (msg + 1) & 0xFFFFFFFF, await hrd_ok(c, MBX + S.MAILBOX["F2H_CODE"]))
        db = await hrd_ok(c, MBX + S.MAILBOX["DB_STATUS"])
        expect(sb, "H2F pending cleared by the firmware ack, F2H pending set", 0b10, db)
        await ack_f2h(c)
        expect(sb, "host_irq_o drops after F2H_ACK", 0, dut.host_irq_o.value.integer)
        ci.sample(source="HOST", origin="real_input", scenario="repeated" if k else "single")
    mask, idx = await served()
    expect(sb, "served-source mask / log index after three doorbells", (1 << 6, 3), (mask, idx))
    expect(sb, "DMEM log holds the claimed source ids (HOST = 6)", 0x060606, (await hrd_ok(c, S.DMEM_BASE + 0x100)) & 0xFFFFFF)
    expect(sb, "F2H ring counter counted the firmware's rings", True, ((await hrd_ok(c, MBX + S.MAILBOX["RING_COUNT"])) >> 16) >= 4)
    # ---- software-pended sources, all at once: served in priority order within one trap
    base = idx
    await hwr_ok(c, INTC + S.INTC["SWPEND"], 0x7D, "SWPEND")  # FATAL RAS_WARN DMA TENSOR VECTOR HOST
    await env.cycles(400)
    mask2, idx2 = await served()
    expect(sb, "six sources served", base + 6, idx2)
    expect(sb, "priority order FATAL > RAS_WARN > DMA > TENSOR > VECTOR > HOST (ties: lower index)", [0, 2, 3, 4, 5, 6], await read_log(c, base, 6))
    expect(sb, "SWPEND cleared by the handler", 0, await hrd_ok(c, INTC + S.INTC["SWPEND"]))
    ci.sample(source="FATAL", origin="software_pend", scenario="simultaneous_priority_order")
    await ack_f2h(c)
    await hwr_ok(c, INTC + S.INTC["ENABLE"], 0x7F, "ENABLE restore (the payload masks DMA / TENSOR / VECTOR after serving them)")
    # ---- masking: ENABLE
    await hwr_ok(c, INTC + S.INTC["ENABLE"], 0x7F & ~(1 << 3), "ENABLE")
    await hwr_ok(c, INTC + S.INTC["SWPEND"], 1 << 3, "SWPEND")
    await env.cycles(300)
    mask3, idx3 = await served()
    expect(sb, "disabled source (DMA) is not served", idx2, idx3)
    expect(sb, "...but stays software-pended", 1 << 3, await hrd_ok(c, INTC + S.INTC["SWPEND"]))
    await hwr_ok(c, INTC + S.INTC["ENABLE"], 0x7F, "ENABLE")
    await env.cycles(300)
    mask3, idx3 = await served()
    expect(sb, "served once enabled", idx2 + 1, idx3)
    await hwr_ok(c, INTC + S.INTC["ENABLE"], 0x7F, "ENABLE restore")
    ci.sample(source="DMA", origin="software_pend", scenario="masked_by_enable")
    # ---- masking: THRESHOLD (priority must be > threshold)
    await hwr_ok(c, INTC + S.INTC["THRESHOLD"], 4, "THRESHOLD")
    await hwr_ok(c, INTC + S.INTC["SWPEND"], 0x7D, "SWPEND")
    await env.cycles(500)
    _, idx4 = await served()
    expect(sb, "threshold 4: only FATAL (7) and RAS_WARN (5) are served", idx3 + 2, idx4)
    await hwr_ok(c, INTC + S.INTC["THRESHOLD"], 0, "THRESHOLD")
    await env.cycles(500)
    _, idx5 = await served()
    expect(sb, "threshold lowered: the rest is served", idx3 + 6, idx5)
    ci.sample(source="DMA", origin="software_pend", scenario="masked_by_threshold")
    await hwr_ok(c, INTC + S.INTC["ENABLE"], 0x7F, "ENABLE restore")
    await ack_f2h(c)
    await hwr_ok(c, RAS + S.RAS["WARN_EN"], 0x20, "WARN_EN restore (the handler masks it)")
    await hwr_ok(c, RAS + S.RAS["FATAL_EN"], 0x04, "FATAL_EN restore")
    # ---- real inputs
    for pin, name, src_id in (("acc_vec_irq_i", "VECTOR", 5), ("acc_tsu_irq_i", "TENSOR", 4)):
        _, i0 = await served()
        c.pins.force(pin, 1)  # a level source: held until the firmware reacts (the payload masks it in INTC.ENABLE)
        await env.cycles(60)
        c.pins.force(pin, 0)
        await env.cycles(100)
        mk, i1 = await served()
        expect(sb, "%s interrupt input delivered once (accelerator domain not isolated)" % name, (i0 + 1, 1), (i1, mk >> src_id & 1))
        ci.sample(source=name, origin="real_input", scenario="single")
        await hwr_ok(c, INTC + S.INTC["ENABLE"], 0x7F, "ENABLE restore")
    _, i0 = await served()
    await hwr_ok(c, PMU + S.PMU["ACC_CTRL"], 0x5, "PMU ACC_CTRL ISO|CLK_EN")
    await env.cycles(5)
    c.pins.force("acc_vec_irq_i", 1)
    c.pins.force("acc_tsu_irq_i", 1)
    await env.cycles(60)
    c.pins.force("acc_vec_irq_i", 0)
    c.pins.force("acc_tsu_irq_i", 0)
    await env.cycles(200)
    _, i1 = await served()
    expect(sb, "accelerator interrupt lines are masked while the domain is isolated", i0, i1)
    ci.sample(source="VECTOR", origin="real_input", scenario="isolated_accelerator_masked")
    await hwr_ok(c, PMU + S.PMU["ACC_CTRL"], 0x1, "PMU ACC_CTRL")
    await env.cycles(10)
    # ext_warn_i -> RAS EXT_WARN (level, held for 300 cycles) -> RAS_WARN interrupt -> handler records STATUS, masks WARN_EN, W1C;
    # the level re-sets the sticky bit while it is active
    await hwr_ok(c, RAS + S.RAS["CTRL"], 0x1 | 0x8, "clear counts")
    await hwr_ok(c, RAS + S.RAS["STATUS"], 0xFFFF, "clear status")
    _, i0 = await served()
    c.pins.force("ext_warn_i", 1)
    await env.cycles(300)
    mk, i1 = await served()
    expect(sb, "ext_warn_i raised the RAS_WARN interrupt exactly once (handler masks the level source)", (i0 + 1, 1), (i1, mk >> 2 & 1))
    expect(sb, "handler saw EXT_WARN in RAS.STATUS", 1, (await hrd_ok(c, MBX + S.MAILBOX["F2H_MSG0"] + 12)) >> 5 & 1)
    expect(sb, "RAS.STATUS: the active level source re-set EXT_WARN after the firmware's W1C", 1, (await hrd_ok(c, RAS + S.RAS["STATUS"])) >> 5 & 1)
    expect(sb, "RAS RAW shows the live level", 1, (await hrd_ok(c, RAS + S.RAS["RAW"])) & 1)
    c.pins.force("ext_warn_i", 0)
    await env.cycles(20)
    expect(sb, "sticky after the level dropped; RAW low", (1, 0), ((await hrd_ok(c, RAS + S.RAS["STATUS"])) >> 5 & 1, (await hrd_ok(c, RAS + S.RAS["RAW"])) & 1))
    expect(sb, "RAS WARN_COUNT counted one rising edge of ext_warn_i", 1, await hrd_ok(c, RAS + S.RAS["WARN_COUNT"]))
    expect(sb, "firmware masked the source (WARN_EN = 0)", 0, await hrd_ok(c, RAS + S.RAS["WARN_EN"]))
    await hwr_ok(c, RAS + S.RAS["STATUS"], 0xFFFF, "W1C")
    ci.sample(source="RAS_WARN", origin="real_input", scenario="single")
    # ext_fatal_i -> EXT_FATAL -> FATAL interrupt + ras_fatal_o pin (= FATAL_TO_HOST & STATUS[15:8] != 0)
    _, i0 = await served()
    n_rise0 = sum(1 for cy, v in c.rec.changes["ras_fatal_o"] if v == 1)
    c.pins.force("ext_fatal_i", 1)
    await env.cycles(300)
    mk, i1 = await served()
    expect(sb, "ext_fatal_i raised the FATAL interrupt once", (i0 + 1, 1), (i1, mk & 1))
    expect(sb, "handler saw EXT_FATAL in RAS.STATUS", 1, (await hrd_ok(c, MBX + S.MAILBOX["F2H_MSG0"] + 16)) >> 10 & 1)
    st = await hrd_ok(c, RAS + S.RAS["STATUS"])
    expect(sb, "ras_fatal_o rose with the fatal source and stays high while it is active (FATAL_TO_HOST = 1)", (1, 1, True), ((st >> 10) & 1, dut.ras_fatal_o.value.integer,
           sum(1 for cy, v in c.rec.changes["ras_fatal_o"] if v == 1) > n_rise0))
    c.pins.force("ext_fatal_i", 0)
    await env.cycles(20)
    expect(sb, "ras_fatal_o stays high after the level dropped (sticky STATUS)", 1, dut.ras_fatal_o.value.integer)
    await hwr_ok(c, RAS + S.RAS["STATUS"], 0xFFFF, "RAS STATUS W1C")
    await env.cycles(4)
    expect(sb, "ras_fatal_o drops after W1C", 0, dut.ras_fatal_o.value.integer)
    ci.sample(source="FATAL", origin="real_input", scenario="single")
    expect(sb, "FATAL_COUNT counted one edge", 1, await hrd_ok(c, RAS + S.RAS["FATAL_COUNT"]))
    # ---- host write lock: refused with error + no side effect, logged by SECURITY and RAS
    await hwr_ok(c, SEC + S.SECMON["CTRL"], 1, "HOST_LOCK")
    expect(sb, "host_lock visible in STATUS", 1, (await hrd_ok(c, SEC + S.SECMON["STATUS"])) & 1)
    probe = S.IMEM_BASE + 0x800
    before = await hrd_ok(c, probe)
    for cls, addr in (("lock_refused_rom", 0x0), ("lock_refused_dmem", S.DMEM_BASE + 0x3000), ("lock_refused_imem", probe)):
        t = await hwr(c, addr, 0xBADC0DE5)
        expect(sb, "%s: host write refused with an error response" % cls, (True, 0), (t.rsp.err, t.rsp.rdata))
        ca.sample(cls=cls, rw="write")
    expect(sb, "refused host write had no side effect", before, await hrd_ok(c, probe))
    t = await hwr(c, SYS + S.SYSCTRL["SCRATCH2"], 0x1357)
    expect(sb, "register pages stay writable under the lock", (False, 0x1357), (t.rsp.err, await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH2"])))
    ca.sample(cls="lock_periph_ok", rw="write")
    sec = await hrd_ok(c, SEC + S.SECMON["STATUS"])
    expect(sb, "SECURITY.STATUS: lock, HOST_VIOLATION", (1, 1), (sec & 1, sec >> 8 & 1))
    expect(sb, "SECURITY.VIOL_COUNT / VIOL_ADDR (the last refused address)", (3, probe), (await hrd_ok(c, SEC + S.SECMON["VIOL_COUNT"]), await hrd_ok(c, SEC + S.SECMON["VIOL_ADDR"])))
    expect(sb, "RAS HOST_VIOL bit set", 1, (await hrd_ok(c, RAS + S.RAS["STATUS"])) >> 3 & 1)
    t = await hwr(c, SEC + S.SECMON["CTRL"], 0)
    expect(sb, "writing 0 to CTRL cannot release the host write lock", (False, 1), (t.rsp.err, await hrd_ok(c, SEC + S.SECMON["CTRL"])))
    # ---- watchdog early warning -> WDT interrupt (source 1, level; the payload masks it in INTC.ENABLE); the watchdog is serviced afterwards
    wdt = PB + 0x3000
    await hwr_ok(c, INTC + S.INTC["ENABLE"], 0x7F, "ENABLE restore")
    _, i0 = await served()
    await hwr_ok(c, wdt + S.WDT["LOAD"], 60000, "WDT LOAD")
    await hwr_ok(c, wdt + S.WDT["PRESCALE"], 0, "WDT PRESCALE")
    await hwr_ok(c, wdt + S.WDT["EWI_THRESH"], 59800, "WDT EWI_THRESH")
    await hwr_ok(c, wdt + S.WDT["CTRL"], 0x1 | 0x4, "WDT EN | EWI_EN")
    await env.cycles(700)
    mk, i1 = await served()
    expect(sb, "watchdog early warning delivered once as WDT interrupt (source 1)", (i0 + 1, 1), (i1, mk >> 1 & 1))
    expect(sb, "WDT.STATUS.EWI set", 1, (await hrd_ok(c, wdt + S.WDT["STATUS"])) & 1)
    await hwr_ok(c, wdt + S.WDT["SERVICE"], 0xA5A5, "WDT service key 1")
    await hwr_ok(c, wdt + S.WDT["SERVICE"], 0x5A5A, "WDT service key 2")
    await hwr_ok(c, wdt + S.WDT["STATUS"], 1, "WDT EWI W1C")
    expect(sb, "serviced watchdog: EWI cleared, no reset happened", (0, 0), ((await hrd_ok(c, wdt + S.WDT["STATUS"])) & 1, await hrd_ok(c, SYS + S.SYSCTRL["RESET_COUNT"])))
    ci.sample(source="WDT", origin="real_input", scenario="single")
    finish_core(c, "boot_handshake_irq")


BAD_IMAGES = [
    ("MAGIC", "bad magic", dict(magic=0x12345678)),
    ("HDR_VERSION", "header version 2", dict(version=2)),
    ("HDR_VERSION", "header version 0", dict(version=0)),
    ("SIZE", "size not larger than the header", dict(size=0x100)),
    ("SIZE", "size larger than IMEM", dict(size=0x10004)),
    ("SIZE", "size not a multiple of 4", dict(size=0x1FE)),
    ("SIZE", "load address not CC_IMEM_BASE", dict(load=0x0002_0000)),
    ("ENTRY", "entry inside the header", dict(entry=0x0001_0000)),
    ("ENTRY", "entry outside the image", dict(entry=0x0003_0000)),
    ("ENTRY", "entry misaligned", dict(entry=0x0001_0102)),
    ("CRC", "CRC field wrong", dict(crc=0xDEADBEEF)),
    ("CRC", "size beyond the payload (CRC over unwritten words)", dict(size=0x400)),
]


@cocotb.test()
async def bad_images(dut):
    """Images rejected by the boot ROM: BOOT_ERROR stage, BOOT_STATUS reason, BAD_CMD answer with the reason, retry without reset,
    unknown commands answered BUSY; a good image is finally accepted."""
    c = build(dut, SEED)
    sb, env = c.sb, c.env
    cb, ce, ci, ca = c.cov
    await start(c)
    await wait_stage(c, S.BOOT_STAGE["WAIT_IMAGE"], 900_000)
    # an unknown command while waiting for the image is answered BUSY (docs/03_BOOT.md section 2)
    await hwr_ok(c, MBX + S.MAILBOX["H2F_MSG0"], S.MBOX_CMD["PING"], "H2F_MSG0 = PING")
    await hwr_ok(c, MBX + S.MAILBOX["H2F_RING"], 1, "H2F_RING")
    await wait_host_irq(c, 200_000, "ROM answer to PING")
    m0, _ = await read_answer(c)
    expect(sb, "command other than IMAGE_READY gets BUSY (command echoed)", (S.MBOX_STS["BUSY"], S.MBOX_CMD["PING"]), (m0 & 0xFF, m0 >> 8 & 0xFF))
    ce.sample(err="unknown_command_BUSY")
    await ack_f2h(c)
    good = ctl_fw.make_image()
    for reason, what, kw in BAD_IMAGES:
        img = ctl_fw.make_image(**kw)
        await load_image(c, img)
        await image_ready(c)
        stages = []  # the host polls BOOT_STAGE back-to-back while the ROM checks the image (03_BOOT.md: BOOT_ERROR "visible to the host")
        t_end = env.cycle + 600_000
        while c.rec.cur["host_irq_o"] == 0 and env.cycle < t_end:
            t = await hrd(c, SYS + S.SYSCTRL["BOOT_STAGE"])
            if t.rsp is not None and not t.rsp.err and (not stages or stages[-1] != t.rsp.rdata):
                stages.append(t.rsp.rdata)
        await wait_host_irq(c, 1000, "ROM answer for %s" % what)
        m0, m1 = await read_answer(c)
        code = S.BOOT_ERR[reason]
        expect(sb, "%s: answer BAD_CMD (command echoed)" % what, (S.MBOX_STS["BAD_CMD"], S.MBOX_CMD["IMAGE_READY"]), (m0 & 0xFF, m0 >> 8 & 0xFF))
        expect(sb, "%s: F2H_MSG1 = BOOT_ERR_%s" % (what, reason), code, m1)
        expect(sb, "%s: BOOT_ERROR stage published to the host (stages seen while checking: %s)" % (what, [hex(x) for x in stages]), True, S.BOOT_STAGE["BOOT_ERROR"] in stages)
        expect(sb, "%s: BOOT_STATUS = BOOT_ERR_%s" % (what, reason), code, (await hrd_ok(c, SYS + S.SYSCTRL["BOOT_STATUS"])) & 0xFF)
        expect(sb, "%s: firmware did not start" % what, (0, 0), (dut.host_ready_o.value.integer, await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH3"])))
        expect(sb, "%s: no measurement taken" % what, 0, (await hrd_ok(c, SEC + S.SECMON["STATUS"])) >> 1 & 1)
        ce.sample(err=reason)
        await ack_f2h(c)
    # the corrected image is accepted without a reset
    await load_image(c, good)
    await verify_image(c, good)
    await image_ready(c)
    await wait_host_irq(c, 900_000, "ROM answer for the good image")
    m0, _ = await read_answer(c)
    expect(sb, "corrected image accepted (OK)", S.MBOX_STS["OK"], m0 & 0xFF)
    await ack_f2h(c)
    await wait_stage(c, S.BOOT_STAGE["HOST_READY"], 400_000)
    expect(sb, "firmware running after the retries; no reset happened", (1, 0), (await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH3"]), await hrd_ok(c, SYS + S.SYSCTRL["RESET_COUNT"])))
    expect(sb, "pins", (1, 1), (dut.host_ready_o.value.integer, dut.cmdproc_ready_o.value.integer))
    cb.sample(path="bad_image_then_good")
    finish_core(c, "bad_images")


@cocotb.test()
async def reset_boot_sequence(dut):
    """Resets during / after boot: host reset request early in ROM init and while the firmware runs (cold boots), asynchronous POR in the
    middle of a clock cycle while the firmware runs and during the ROM scrub.  Reset cause / count, POR-domain persistence, SYS-domain
    clearing, IMEM scrub on cold boot, return to WAIT_IMAGE."""
    c = build(dut, SEED)
    sb, env = c.sb, c.env
    cb, ce, ci, ca = c.cov
    rng = env.seeds.child("rst")
    await start(c)

    async def to_wait_image(label):
        seen = []
        await wait_stage(c, S.BOOT_STAGE["WAIT_IMAGE"], 900_000, seen=seen)
        expect(sb, label + ": ROM stages restart from the beginning and increase", True, seen == sorted(set(seen)), str(seen))

    # --- boot #1: wait until the ROM is running, mark POR and SYS state, then request a host reset
    await wait_stage(c, {1, 2}, 400_000)
    await hwr_ok(c, SYS + S.SYSCTRL["SCRATCH2"], 0xA5A50001, "SCRATCH2")
    await hwr_ok(c, SYS + S.SYSCTRL["FW_VERSION"], 0x55AA55AA, "FW_VERSION")
    await hwr_ok(c, MBX + S.MAILBOX["H2F_MSG0"] + 12, 0xFEEDF00D, "H2F_MSG3")
    expect(sb, "SYS-domain register holds the marker before the reset", 0x55AA55AA, await hrd_ok(c, SYS + S.SYSCTRL["FW_VERSION"]))
    c.pins.force("host_rst_req_i", 1)
    await env.cycles(6)
    c.pins.force("host_rst_req_i", 0)
    cb.sample(reset="host_req_midboot")
    await env.cycles(80)  # the host does not access the core while it resets
    await to_wait_image("after the host reset request during ROM init")
    expect(sb, "RESET_CAUSE = POR | HOST", 0x9, await hrd_ok(c, SYS + S.SYSCTRL["RESET_CAUSE"]))
    expect(sb, "RESET_COUNT = 1", 1, await hrd_ok(c, SYS + S.SYSCTRL["RESET_COUNT"]))
    expect(sb, "POR-domain scratch survives the host reset", 0xA5A50001, await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH2"]))
    expect(sb, "SYS-domain registers cleared by the host reset", (0, 0), (await hrd_ok(c, SYS + S.SYSCTRL["FW_VERSION"]), await hrd_ok(c, MBX + S.MAILBOX["H2F_MSG0"] + 12)))
    await hwr_ok(c, SYS + S.SYSCTRL["RESET_CAUSE"], 0xF, "clear RESET_CAUSE")
    # --- hand over a good image, firmware runs
    img = ctl_fw.make_image()
    await load_image(c, img)
    await image_ready(c)
    await wait_host_irq(c, 900_000, "ROM answer")
    m0, _ = await read_answer(c)
    expect(sb, "image accepted after the reset", S.MBOX_STS["OK"], m0 & 0xFF)
    await ack_f2h(c)
    await wait_stage(c, S.BOOT_STAGE["HOST_READY"], 400_000)
    expect(sb, "firmware start counted", 1, await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH3"]))
    # --- boot #2: host reset request while the firmware runs: cold boot, IMEM scrubbed, host must reload
    c.pins.force("host_rst_req_i", 1)
    await env.cycles(6)
    c.pins.force("host_rst_req_i", 0)
    cb.sample(reset="host_req_running")
    await env.cycles(80)
    await to_wait_image("after the host reset request while the firmware ran")
    expect(sb, "RESET_CAUSE = HOST (cleared before)", 0x8, await hrd_ok(c, SYS + S.SYSCTRL["RESET_CAUSE"]))
    expect(sb, "RESET_COUNT = 2", 2, await hrd_ok(c, SYS + S.SYSCTRL["RESET_COUNT"]))
    expect(sb, "cold boot: IMEM scrubbed (header magic gone)", 0, await hrd_ok(c, S.IMEM_BASE))
    expect(sb, "host reset is always a cold boot: the ROM waits for an image again", S.BOOT_STAGE["WAIT_IMAGE"], await hrd_ok(c, SYS + S.SYSCTRL["BOOT_STAGE"]))
    expect(sb, "firmware-start counter (POR domain) persists", 1, await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH3"]))
    expect(sb, "pins low after the reset", (0, 0), (dut.host_ready_o.value.integer, dut.cmdproc_ready_o.value.integer))
    await load_image(c, img)
    await image_ready(c)
    await wait_host_irq(c, 900_000, "ROM answer")
    await read_answer(c)
    await ack_f2h(c)
    await wait_stage(c, S.BOOT_STAGE["HOST_READY"], 400_000)
    expect(sb, "second firmware start counted", 2, await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH3"]))
    # --- boot #3: asynchronous power-on reset in the middle of a clock cycle while the firmware runs, then a second one during the ROM scrub
    await hwr_ok(c, SYS + S.SYSCTRL["SCRATCH0"], 0x11110000, "SCRATCH0")
    await env.tick()
    await async_reset_midcycle(env, c.rst, rng.choice((1.0, 3.0, 4.0, 6.0, 8.0)), 3)
    cb.sample(reset="por_async_midboot")
    await env.until(lambda: not c.rst.asserted, 20, "POR release")
    await env.cycles(80)
    await wait_stage(c, {1, 2}, 400_000)  # the ROM is running again
    await env.cycles(rng.randrange(2_000, 60_000))
    await env.tick()
    await async_reset_midcycle(env, c.rst, rng.choice((2.0, 5.0, 7.0)), 2)
    await env.until(lambda: not c.rst.asserted, 20, "POR release")
    await env.cycles(80)
    await to_wait_image("after asynchronous POR resets (firmware running, then ROM scrub)")
    expect(sb, "POR: RESET_CAUSE = POR only, RESET_COUNT = 0", (0x1, 0), (await hrd_ok(c, SYS + S.SYSCTRL["RESET_CAUSE"]), await hrd_ok(c, SYS + S.SYSCTRL["RESET_COUNT"])))
    expect(sb, "POR clears the POR-domain scratch registers", (0, 0, 0), tuple([await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH%d" % i]) for i in (0, 2, 3)]))
    expect(sb, "cold boot: IMEM scrubbed", 0, await hrd_ok(c, S.IMEM_BASE))
    cb.sample(reset="por_sync")
    finish_core(c, "reset_boot_sequence")


@cocotb.test()
async def reset_early(dut):
    """The reset generator inside the real core, cheap version (early ROM): host reset request, watchdog expiry and SOFT_RESET restart the ROM,
    RESET_CAUSE / RESET_COUNT accumulate, POR-domain scratch survives, SYS-domain registers clear; an asynchronous POR clears everything."""
    c = build(dut, SEED)
    sb, env = c.sb, c.env
    cb, ce, ci, ca = c.cov
    rng = env.seeds.child("rst")
    await start(c)
    await wait_stage(c, {1, 2}, 400_000)
    await hwr_ok(c, SYS + S.SYSCTRL["SCRATCH1"], 0xC0DE0001, "SCRATCH1")
    await hwr_ok(c, SYS + S.SYSCTRL["FW_VERSION"], 0x1234, "FW_VERSION")
    expect(sb, "cause after power-on", (0x1, 0), (await hrd_ok(c, SYS + S.SYSCTRL["RESET_CAUSE"]), await hrd_ok(c, SYS + S.SYSCTRL["RESET_COUNT"])))

    async def restarted(label, cause, count):
        await env.cycles(100)
        await wait_stage(c, {1, 2}, 400_000)
        expect(sb, label + ": RESET_CAUSE / RESET_COUNT", (cause, count), (await hrd_ok(c, SYS + S.SYSCTRL["RESET_CAUSE"]), await hrd_ok(c, SYS + S.SYSCTRL["RESET_COUNT"])))
        expect(sb, label + ": SYS-domain register cleared, POR-domain scratch kept", (0, 0xC0DE0001), (await hrd_ok(c, SYS + S.SYSCTRL["FW_VERSION"]), await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH1"])))
        await hwr_ok(c, SYS + S.SYSCTRL["FW_VERSION"], 0x1234, "FW_VERSION")

    c.pins.force("host_rst_req_i", 1)
    await env.cycles(6)
    c.pins.force("host_rst_req_i", 0)
    await restarted("host reset request", 0x9, 1)
    cb.sample(reset="host_req_midboot")
    await hwr_ok(c, PB + 0x3000 + S.WDT["LOAD"], 300, "WDT LOAD")
    await hwr_ok(c, PB + 0x3000 + S.WDT["PRESCALE"], 0, "WDT PRESCALE")
    await hwr_ok(c, PB + 0x3000 + S.WDT["EWI_THRESH"], 0, "WDT EWI_THRESH")
    await hwr_ok(c, PB + 0x3000 + S.WDT["CTRL"], 1, "WDT EN")
    await env.cycles(1500)  # the host stays off the core until the watchdog has expired
    await restarted("watchdog expiry", 0xD, 2)
    expect(sb, "watchdog disabled again by its own reset", 0, (await hrd_ok(c, PB + 0x3000 + S.WDT["CTRL"])) & 1)
    cb.sample(reset="wdt")
    await soft_reset(c)
    await restarted("soft reset", 0xF, 3)
    cb.sample(reset="soft")
    await hwr_ok(c, SYS + S.SYSCTRL["RESET_CAUSE"], 0xF, "clear cause")
    expect(sb, "RESET_CAUSE W1C through the host port", 0, await hrd_ok(c, SYS + S.SYSCTRL["RESET_CAUSE"]))
    await env.tick()
    await async_reset_midcycle(env, c.rst, rng.choice((1.0, 3.0, 4.0, 6.0, 8.0)), 3)
    cb.sample(reset="por_async_midboot")
    await env.until(lambda: not c.rst.asserted, 20, "POR release")
    await env.cycles(100)
    await wait_stage(c, {1, 2}, 400_000)
    expect(sb, "asynchronous POR: cause POR only, count 0, scratch cleared", (0x1, 0, 0), (await hrd_ok(c, SYS + S.SYSCTRL["RESET_CAUSE"]), await hrd_ok(c, SYS + S.SYSCTRL["RESET_COUNT"]),
                                                                                       await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH1"])))
    finish_core(c, "reset_early")


@cocotb.test()
async def warm_boot(dut):
    """Soft reset and watchdog reset with a valid retained image: warm boot without the host (IMEM not scrubbed, BOOT_STATUS[8] = WARM);
    a retained image that no longer passes the CRC falls back to a cold boot."""
    c = build(dut, SEED)
    sb, env = c.sb, c.env
    cb, ce, ci, ca = c.cov
    await start(c)
    await boot_host_image(c)
    await wait_stage(c, S.BOOT_STAGE["HOST_READY"], 400_000)
    expect(sb, "cold boot: BOOT_STATUS[8] (WARM) clear", 0, (await hrd_ok(c, SYS + S.SYSCTRL["BOOT_STATUS"])) >> 8 & 1)
    await hwr_ok(c, SYS + S.SYSCTRL["RESET_CAUSE"], 0xF, "clear cause")
    # --- soft reset
    expect(sb, "wrong key refused", True, (await hwr(c, SYS + S.SYSCTRL["SOFT_RESET"], 0x5AFEC0DF)).rsp.err)
    await soft_reset(c)
    cb.sample(reset="soft")
    await env.cycles(100)
    seen = []
    await wait_stage(c, S.BOOT_STAGE["HOST_READY"], 900_000, seen=seen)
    expect(sb, "warm boot: the ROM never waited for an image", True, S.BOOT_STAGE["WAIT_IMAGE"] not in seen, str(seen))
    cb.sample(path="warm")
    expect(sb, "RESET_CAUSE = SOFT, RESET_COUNT = 1", (0x2, 1), (await hrd_ok(c, SYS + S.SYSCTRL["RESET_CAUSE"]), await hrd_ok(c, SYS + S.SYSCTRL["RESET_COUNT"])))
    expect(sb, "firmware restarted by the ROM (start counter)", 2, await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH3"]))
    expect(sb, "BOOT_STATUS[8] = WARM", 1, (await hrd_ok(c, SYS + S.SYSCTRL["BOOT_STATUS"])) >> 8 & 1)
    expect(sb, "pins up again after the warm boot", (1, 1), (dut.host_ready_o.value.integer, dut.cmdproc_ready_o.value.integer))
    # --- watchdog reset
    await hwr_ok(c, SYS + S.SYSCTRL["RESET_CAUSE"], 0xF, "clear cause")
    await hwr_ok(c, PB + 0x3000 + S.WDT["LOAD"], 400, "WDT LOAD")
    await hwr_ok(c, PB + 0x3000 + S.WDT["PRESCALE"], 0, "WDT PRESCALE")
    await hwr_ok(c, PB + 0x3000 + S.WDT["EWI_THRESH"], 0, "WDT EWI_THRESH")
    await hwr_ok(c, PB + 0x3000 + S.WDT["CTRL"], 1, "WDT EN")
    await env.cycles(1500)  # expiry after about LOAD * (PRESCALE + 1) cycles; the host stays off the core while it resets
    seen = []
    await wait_stage(c, S.BOOT_STAGE["HOST_READY"], 900_000, seen=seen)
    expect(sb, "watchdog reset: warm boot again, no WAIT_IMAGE", True, S.BOOT_STAGE["WAIT_IMAGE"] not in seen, str(seen))
    cause = await hrd_ok(c, SYS + S.SYSCTRL["RESET_CAUSE"])
    expect(sb, "RESET_CAUSE has WDT (and not HOST)", (1, 0), (cause >> 2 & 1, cause >> 3 & 1))
    expect(sb, "RESET_COUNT = 2", 2, await hrd_ok(c, SYS + S.SYSCTRL["RESET_COUNT"]))
    expect(sb, "third firmware start", 3, await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH3"]))
    expect(sb, "the watchdog (SYS domain) is disabled again after its own reset", 0, (await hrd_ok(c, PB + 0x3000 + S.WDT["CTRL"])) & 1)
    cb.sample(reset="wdt")
    # --- retained image damaged: warm boot is refused, the ROM cold boots (IMEM scrubbed) and waits for the host
    await hwr_ok(c, S.IMEM_BASE + 0x100 + 4 * 90, 0xFFFFFFFF, "damage the retained payload (unused tail word)")
    await soft_reset(c)
    await env.cycles(100)
    seen = []
    await wait_stage(c, S.BOOT_STAGE["WAIT_IMAGE"], 900_000, seen=seen)
    expect(sb, "damaged retained image: cold boot, IMEM scrubbed", 0, await hrd_ok(c, S.IMEM_BASE))
    expect(sb, "firmware not restarted", 3, await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH3"]))
    finish_core(c, "warm_boot")


def devmem_with_image(img, addr=EXT_IMAGE):
    dm = BackingStore("zero", "devmem")
    dm.write_bytes(addr, img)
    return dm


@cocotb.test()
async def boot_ext(dut):
    """BOOT_MODE_EXT: the ROM fetches the image from device memory with the system DMA (external port) and starts it without the host."""
    img = ctl_fw.make_image()
    c = build(dut, SEED, boot_mode=1, devmem=devmem_with_image(img), ext_monitor=True)
    sb, env = c.sb, c.env
    cb, ce, ci, ca = c.cov
    await start(c)
    seen = []
    await wait_stage(c, S.BOOT_STAGE["HOST_READY"], 1_500_000, seen=seen)
    expect(sb, "device-memory boot never waits for the host", True, S.BOOT_STAGE["WAIT_IMAGE"] not in seen, str(seen))
    cb.sample(path="ext_dma")
    cb.sample(boot_mode=1)
    expect(sb, "BOOT_MODE register = EXT", 1, await hrd_ok(c, SYS + S.SYSCTRL["BOOT_MODE"]))
    log = c.ext.log
    expect(sb, "the image was fetched through the external port", True, len(log) >= len(img) // 4 // 2)
    expect(sb, "boot only READS device memory", [], [r for r in log if r.write])
    lo, hi = EXT_IMAGE, EXT_IMAGE + len(img)
    expect(sb, "every device-memory access lies in the image window", [], [hex(r.addr) for r in log if not lo <= r.addr < hi + 0x100])
    await verify_image(c, img)
    expect(sb, "firmware started once, boot measurement = payload CRC", (1, ctl_fw.crc32(img[0x100:])),
           (await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH3"]), await hrd_ok(c, SEC + S.SECMON["BOOT_MEASURE"])))
    expect(sb, "pins", (1, 1), (dut.host_ready_o.value.integer, dut.cmdproc_ready_o.value.integer))
    finish_core(c, "boot_ext")


async def ext_fallback_scenario(dut, devmem, host_img, label, *, expect_ok=True, expect_reason=None):
    """BOOT_MODE_EXT with a device-memory image that fails: the ROM must fall back to host loading (docs/03_BOOT.md section 2) -- then a
    host-loaded image must be accepted exactly like in host-load mode.  Returns (answer, BOOT_STATUS, ext accesses after IMAGE_READY)."""
    c = build(dut, SEED, boot_mode=1, devmem=devmem, ext_monitor=True)
    sb, env = c.sb, c.env
    cb, ce, ci, ca = c.cov
    await start(c)
    seen = []
    await wait_stage(c, S.BOOT_STAGE["WAIT_IMAGE"], 1_500_000, seen=seen)
    expect(sb, label + ": the ROM tried the device image through the external port", True, len(c.ext.log) > 0, "ext accesses=%d" % len(c.ext.log))
    expect(sb, label + ": ... and fell back to host loading (WAIT_IMAGE)", S.BOOT_STAGE["WAIT_IMAGE"], await hrd_ok(c, SYS + S.SYSCTRL["BOOT_STAGE"]))
    expect(sb, label + ": BOOT_MODE register = EXT although the ROM waits for the host", 1, await hrd_ok(c, SYS + S.SYSCTRL["BOOT_MODE"]))
    expect(sb, label + ": firmware not started", 0, await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH3"]))
    cb.sample(path="ext_fallback_to_host")
    # The ROM reports why the device-memory boot failed: BAD_CMD + BOOT_ERR_* in F2H_MSG1 with a doorbell (observed; not described in
    # docs/03_BOOT.md).  The host must acknowledge it before the next hand-shake, otherwise it would read this stale answer.
    if c.rec.cur["host_irq_o"]:
        um0, um1 = await read_answer(c)
        c.env.notes["ext_failure_message"] = [um0, um1]
        if expect_reason is not None:
            expect(sb, label + ": the unsolicited failure message names the reason", (S.MBOX_STS["BAD_CMD"], S.BOOT_ERR[expect_reason]), (um0 & 0xFF, um1))
        await ack_f2h(c)
    await load_image(c, host_img)
    await verify_image(c, host_img)
    n_ext0 = len(c.ext.log)
    await image_ready(c)
    await wait_host_irq(c, 900_000, "ROM answer")
    m0, m1 = await read_answer(c)
    bstat = await hrd_ok(c, SYS + S.SYSCTRL["BOOT_STATUS"])
    ctx = "F2H_MSG0=0x%x F2H_MSG1=0x%x BOOT_STATUS=0x%x device-memory accesses issued after IMAGE_READY: %d" % (m0, m1, bstat, len(c.ext.log) - n_ext0)
    first = (m0, m1)
    expect(sb, label + ": host-loaded image accepted after the fallback", S.MBOX_STS["OK"] if expect_ok else S.MBOX_STS["BAD_CMD"], m0 & 0xFF, ctx)
    await ack_f2h(c)
    if expect_ok:
        await wait_stage(c, S.BOOT_STAGE["HOST_READY"], 400_000)
    finish_core(c, "ext_fallback", answer=[m0, m1], first_answer=list(first), boot_status=bstat)
    return c


@cocotb.test()
async def boot_ext_fallback(dut):
    """BOOT_MODE_EXT, device-memory image with a wrong CRC: fall back to host loading, then a good host image must be accepted."""
    await ext_fallback_scenario(dut, devmem_with_image(ctl_fw.make_image(crc=0x1234)), ctl_fw.make_image(), "bad-CRC device image", expect_reason="CRC")


@cocotb.test()
async def boot_ext_fallback_empty(dut):
    """BOOT_MODE_EXT with nothing in device memory (no magic): fall back to host loading, then a good host image must be accepted."""
    await ext_fallback_scenario(dut, BackingStore("zero", "devmem"), ctl_fw.make_image(), "empty device memory", expect_reason="MAGIC")


@cocotb.test()
async def boot_ext_fallback_stale_header(dut):
    """After a failed device-memory boot a host image with a WRONG CRC must still be rejected (BAD_CMD): the ROM must check the host image,
    not rely on the state of the failed attempt."""
    await ext_fallback_scenario(dut, devmem_with_image(ctl_fw.make_image(crc=0x1234)), ctl_fw.make_image(crc=0x1234), "stale-header probe", expect_ok=False, expect_reason="CRC")


@cocotb.test()
async def boot_mode_straps(dut):
    """The boot-mode straps are visible (synchronised) in SYSCTRL.BOOT_MODE for every value, also the reserved ones."""
    c = build(dut, SEED)
    sb, env = c.sb, c.env
    cb, ce, ci, ca = c.cov
    await start(c)
    for mode in (0, 1, 2, 3, 2, 1, 0):
        c.pins.force("boot_mode_i", mode)
        await env.cycles(6)
        expect(sb, "BOOT_MODE for strap %d" % mode, mode, await hrd_ok(c, SYS + S.SYSCTRL["BOOT_MODE"]))
        cb.sample(boot_mode=mode)
    finish_core(c, "boot_mode_straps")


@cocotb.test()
async def host_access_control(dut):
    """Host-port access matrix and malformed requests: register-page errors, absent pages, unmapped / EXT / misaligned / sub-word / ROM write
    accesses return error responses without side effects and are logged by RAS (BUS_DECODE / PERIPH_ERR with the offending address);
    forwarded accelerator pages leave on acc_rb_*; isolation blocks them (ISO_ACCESS)."""
    c = build(dut, SEED, watch_acc=True)
    sb, env = c.sb, c.env
    cb, ce, ci, ca = c.cov
    await start(c)
    await wait_stage(c, S.BOOT_STAGE["WAIT_IMAGE"], 900_000)
    rom = rom_words()

    async def ras_reset():
        await hwr_ok(c, RAS + S.RAS["CTRL"], 0x1 | 0x4 | 0x8, "RAS clear first/counts")
        await hwr_ok(c, RAS + S.RAS["STATUS"], 0xFFFF, "RAS clear status")

    async def ras_state():
        return {"status": await hrd_ok(c, RAS + S.RAS["STATUS"]), "wcnt": await hrd_ok(c, RAS + S.RAS["WARN_COUNT"]), "fcnt": await hrd_ok(c, RAS + S.RAS["FATAL_COUNT"]),
                "first": await hrd_ok(c, RAS + S.RAS["FIRST_SRC"]), "first_addr": await hrd_ok(c, RAS + S.RAS["FIRST_ADDR"]),
                "last": await hrd_ok(c, RAS + S.RAS["LAST_SRC"]), "last_addr": await hrd_ok(c, RAS + S.RAS["LAST_ADDR"])}

    # ---------------------------------------------------------------- successful accesses
    for cls, addr, want in (("reg_ok", SYS, 0x53464343), ("reg_ok", PERF + 4, 20), ("reg_ok", PMU, 0x11), ("reg_ok", SEC, 0x70), ("reg_ok", SYS + 0x2C, 0)):
        expect(sb, "read of 0x%08x" % addr, want, await hrd_ok(c, addr, cls))
        ca.sample(cls=cls, rw="read")
    bad = []
    for w in list(range(0, 64)) + [1000, 2047]:
        v = await hrd_ok(c, 4 * w, "boot ROM word")
        if v != rom.get(w, 0):
            bad.append((w, hex(v), hex(rom.get(w, 0))))
    expect(sb, "boot ROM readable through the host port, content == the ROM image", [], bad)
    ca.sample(cls="rom_read", rw="read")
    for base in (S.DMEM_BASE + 0x3000, S.IMEM_BASE + 0x2000):  # the middle of the banks, not used by the ROM
        await hwr_ok(c, base, 0x1234ABCD, "memory write")
        await hwr_ok(c, base + 4, 0xFFFFFFFF, "memory write")
        t = await hwr(c, base + 4, 0x00AA0000, strb=0x4)  # sub-word writes are legal on memories (SFB2 R10)
        expect(sb, "memory sub-word write accepted", False, t.rsp.err)
        expect(sb, "memory readback", (0x1234ABCD, 0xFFAAFFFF), (await hrd_ok(c, base), await hrd_ok(c, base + 4)))
        ca.sample(cls="mem_rw", rw="write")
    # ---------------------------------------------------------------- decode errors -> RAS BUS_DECODE
    await ras_reset()
    dec = [("unmapped", 0x0000_2000, False), ("unmapped", 0x0000_FFFC, True), ("unmapped", 0x0002_8000, False), ("unmapped", 0x1000_0000, False),
           ("unmapped", 0x4002_0000, True), ("unmapped", 0x5000_0000, False), ("unmapped", 0xFFFF_FFFC, True),
           ("ext_window", 0x2000_0000, False), ("ext_window", 0x2000_0000, True), ("ext_window", 0x3000_0040, False), ("ext_window", 0x200F_0000, False),
           ("misaligned", SYS + 0x41, False), ("misaligned", SYS + 0x42, True), ("misaligned", S.DMEM_BASE + 0x3001, False), ("misaligned", S.IMEM_BASE + 0x2003, True),
           ("misaligned", 0x0000_0006, False)]
    for cls, addr, wr in dec:
        t = await hwr(c, addr, 0xDEADBEEF) if wr else await hrd(c, addr)
        expect(sb, "%s access 0x%08x %s: error response" % (cls, addr, "write" if wr else "read"), (True, 0), (t.rsp.err, t.rsp.rdata))
        ca.sample(cls=cls, rw="write" if wr else "read")
    expect(sb, "no request reached the external port from the host", 0, len(c.ext.log))
    expect(sb, "misaligned write had no side effect", 0, await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH0"]))
    expect(sb, "memory untouched by refused writes", (0x1234ABCD, 0x1234ABCD), (await hrd_ok(c, S.DMEM_BASE + 0x3000), await hrd_ok(c, S.IMEM_BASE + 0x2000)))
    st = await ras_state()
    expect(sb, "RAS: BUS_DECODE only", 0x1, st["status"] & 0x3)
    expect(sb, "RAS WARN_COUNT counts every decode error", len(dec), st["wcnt"])
    expect(sb, "RAS FIRST = first decode error with its address", (0x80000000, dec[0][1]), (st["first"], st["first_addr"]))
    expect(sb, "RAS LAST = last decode error with its address", (0x80000000, dec[-1][1]), (st["last"], st["last_addr"]))
    # ---------------------------------------------------------------- register-page refusals -> PERIPH_ERR
    await ras_reset()
    per = [("absent_page", PB + 0x12000, False, None), ("absent_page", PB + 0x1F000 + 0x40, True, None), ("hole", SYS + 0xF00, False, None),
           ("hole", MBX + 0x60, True, None), ("ro_write", SYS, True, None), ("ro_write", PERF + 0x10, True, None), ("ro_write", SEC, True, None),
           ("subword_write", SYS + S.SYSCTRL["SCRATCH0"], True, 0x3), ("subword_write", SYS + S.SYSCTRL["SCRATCH0"], True, 0x1),
           ("subword_write", SYS + S.SYSCTRL["SCRATCH0"], True, 0xC), ("subword_write", SYS + S.SYSCTRL["SCRATCH0"], True, 0x7),
           ("subword_write", SYS + S.SYSCTRL["SCRATCH0"], True, 0x0), ("subword_write", SYS + S.SYSCTRL["SCRATCH0"], True, 0xE)]
    for cls, addr, wr, strb in per:
        t = await hwr(c, addr, 0xCAFEBABE, strb=strb) if wr else await hrd(c, addr)
        expect(sb, "%s access 0x%08x%s: error response" % (cls, addr, "" if strb is None else " strb %x" % strb), (True, 0), (t.rsp.err, t.rsp.rdata))
        ca.sample(cls=cls, rw="write" if wr else "read")
    expect(sb, "sub-word writes had no side effect", 0, await hrd_ok(c, SYS + S.SYSCTRL["SCRATCH0"]))
    expect(sb, "write to RO ID had no side effect", 0x53464343, await hrd_ok(c, SYS))
    t = await hwr(c, 0x0000_0000, 0x1)  # ROM write: slave error
    expect(sb, "ROM write refused", (True, 0), (t.rsp.err, t.rsp.rdata))
    ca.sample(cls="rom_write", rw="write")
    st = await ras_state()
    expect(sb, "RAS: PERIPH_ERR only", 0x2, st["status"] & 0x3)
    expect(sb, "RAS WARN_COUNT counts every refused register access", len(per), st["wcnt"])
    expect(sb, "RAS FIRST = PERIPH_ERR with the offending address", (0x80000001, per[0][1]), (st["first"], st["first_addr"]))
    expect(sb, "RAS LAST = PERIPH_ERR with the last offending address", (0x80000001, per[-1][1]), (st["last"], st["last_addr"]))
    # ---------------------------------------------------------------- forwarded accelerator pages (8..15), absent accelerator
    await ras_reset()
    n0 = len(c.acc.strobes)
    for page in range(8, 16):
        for wr in (False, True):
            addr = PB + 0x1000 * page + 0x24
            t = await hwr(c, addr, 0x1000 + page) if wr else await hrd(c, addr)
            expect(sb, "page %d %s: the (absent) accelerator's error is returned" % (page, "write" if wr else "read"), (True, 0), (t.rsp.err, t.rsp.rdata))
            ca.sample(cls="forwarded_page", rw="write" if wr else "read")
    expect(sb, "every access to pages 8..15 produced one acc_rb strobe with acc_rb_addr = page<<12 | offset, we and wdata of the access",
           [(w, (0x8000 + 0x1000 * (p - 8)) + 0x24) for p in range(8, 16) for w in (0, 1)], [(st[1], st[2]) for st in c.acc.strobes[n0:]])
    expect(sb, "write strobes carry the write data", [0x1000 + p for p in range(8, 16)], [st[3] for st in c.acc.strobes[n0:] if st[1]])
    st = await ras_state()
    expect(sb, "forwarded-page errors count as PERIPH_ERR", (16, 0x2), (st["wcnt"], st["status"] & 0x1F))
    # ---------------------------------------------------------------- isolation
    await ras_reset()
    await hwr_ok(c, PMU + S.PMU["ACC_CTRL"], 0x5, "ISO")
    await env.cycles(8)
    n1 = len(c.acc.strobes)
    for wr in (False, True):
        t = await hwr(c, PB + 0x8000 + 4, 1) if wr else await hrd(c, PB + 0x9000)
        expect(sb, "isolated accelerator page %s refused" % ("write" if wr else "read"), (True, 0), (t.rsp.err, t.rsp.rdata))
        ca.sample(cls="isolated_forwarded_page", rw="write" if wr else "read")
    expect(sb, "isolation: nothing is forwarded on acc_rb_*", n1, len(c.acc.strobes))
    st = await ras_state()
    expect(sb, "RAS ISO_ACCESS set; every refused access counted as ISO_ACCESS + PERIPH_ERR", (1, 4), (st["status"] >> 4 & 1, st["wcnt"]))
    await hwr_ok(c, PMU + S.PMU["ACC_CTRL"], 0x1, "ACC_CTRL")
    # ---------------------------------------------------------------- PMU outputs of the core: accelerator reset and gated clock
    clk = ClkCount(dut)
    await env.cycles(20)
    n_on = clk.n
    await env.cycles(40)
    expect(sb, "accelerator clock runs while CLK_EN = 1 (one edge per cycle)", 40, clk.n - n_on)
    expect(sb, "acc_rst_no released", 1, dut.acc_rst_no.value.integer)
    await hwr_ok(c, PMU + S.PMU["ACC_CTRL"], 0x3, "ACC_CTRL RST")
    await env.cycles(12)
    expect(sb, "PMU.ACC_CTRL.RST asserts acc_rst_no (async assert)", 0, dut.acc_rst_no.value.integer)
    st = await hrd_ok(c, PMU + S.PMU["ACC_STATUS"])
    expect(sb, "ACC_STATUS: IN_RESET and ISOLATED", (1, 1), (st >> 1 & 1, st >> 2 & 1))
    await hwr_ok(c, PMU + S.PMU["ACC_CTRL"], 0x1, "ACC_CTRL")
    await env.cycles(12)
    expect(sb, "acc_rst_no released again (sync release)", 1, dut.acc_rst_no.value.integer)
    await hwr_ok(c, PMU + S.PMU["ACC_CTRL"], 0x0, "ACC_CTRL CLK_EN = 0")
    await env.cycles(10)
    n_off = clk.n
    await env.cycles(60)
    expect(sb, "accelerator clock stopped while CLK_EN = 0 (idle accelerator)", 0, clk.n - n_off)
    await hwr_ok(c, PMU + S.PMU["ACC_CTRL"], 0x1, "ACC_CTRL")
    await env.cycles(10)
    n_on = clk.n
    await env.cycles(30)
    expect(sb, "accelerator clock runs again", 30, clk.n - n_on)
    finish_core(c, "host_access_control")
