"""The embedded boot-image payload is the assembly of ctl_fw.S; the image builder follows docs/03_BOOT.md section 3."""
import shutil
import struct
import sys
import zlib
from pathlib import Path

import pytest

from control import ctl_fw

HERE = Path(__file__).resolve().parent


def test_header_layout():
    img = ctl_fw.make_image()
    magic, ver, size, entry, load, crc, fwv, flags = struct.unpack("<8I", img[:32])
    assert (magic, ver, size, entry, load, flags) == (0x43434653, 1, len(img), 0x10100, 0x10000, 0)
    assert crc == zlib.crc32(img[0x100:]) & 0xFFFFFFFF  # CRC-32 (IEEE 802.3, reflected) of [0x100, size)
    assert len(img) % 4 == 0 and len(img) > 0x100 and img[0x20:0x2E] == b"albion-bench-f"
    bad = ctl_fw.make_image(crc=1, magic=2, version=3, size=0x500, entry=4, load=5)
    assert struct.unpack("<6I", bad[:24]) == (2, 3, 0x500, 4, 5, 1)


def test_crc32_known_vector():
    assert ctl_fw.crc32(b"123456789") == 0xCBF43926


@pytest.mark.skipif(not (shutil.which("llvm-mc") and shutil.which("ld.lld")), reason="llvm-mc / ld.lld not installed")
def test_payload_matches_the_assembly_source():
    sys.path.insert(0, str(HERE))
    import gen_fw

    assert gen_fw.words(gen_fw.assemble()) == ctl_fw.PAYLOAD
