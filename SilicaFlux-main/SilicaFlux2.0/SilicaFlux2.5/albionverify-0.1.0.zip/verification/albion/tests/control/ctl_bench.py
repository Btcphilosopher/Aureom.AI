"""Shared building blocks of the ControlCore benches (subsystem E).

  BlockChecker    lockstep model/DUT comparator: every cycle it reads the DUT inputs that were in force, steps the
                  independent reference model with them and compares the register-bus answer (rdata / err of an
                  access) and every output pin of that cycle against the model.
  PinDriver       seeded driver of the block's non-register-bus inputs (event pulses, levels, status inputs).
  RegTraffic      seeded generator of random register accesses (mapped, holes, whole page, special data).
  helpers         async mid-cycle reset, whole-page sweeps, functional-coverage group builders, result writer.

Everything is deterministic from ``ALBION_SEED`` (framework SeedRoot streams).
"""
from __future__ import annotations

import json
import os
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

from albionverify.bus.regbus import RegBusMaster, RegOp
from albionverify.core import Agent, AlbionCheckError, Env, Sig
from albionverify.coverage import CoverGroup
from albionverify.scoreboard import Scoreboard

PARAMS = json.loads(os.environ.get("ALBION_PARAMS", "{}"))
SEED = int(os.environ.get("ALBION_SEED", "1"))


# ----------------------------------------------------------------------------- lockstep checker


class BlockChecker(Agent):
    """Compare one register-page DUT against its reference model, cycle by cycle."""

    def __init__(self, name: str, model, sb: Scoreboard, *, ins: Dict[str, Sig], outs: Dict[str, Sig],
                 resets: Callable[[], Dict[str, bool]], warmup: int = 0):
        super().__init__(name)
        self.model = model
        self.sb = sb
        self.ins = ins
        self.outs = outs  # 'rdata', 'err' + pins
        self.resets = resets
        self.cycles = 0
        self.n_access = 0
        self.n_reads = 0
        self.n_writes = 0
        self.n_err = 0
        self.hooks: List[Callable[[Dict[str, int], Dict[str, Any], Dict[str, bool]], None]] = []
        self._last_pins: Optional[Tuple] = None
        self.last_inp: Dict[str, int] = {}
        self.last_exp: Dict[str, Any] = {}
        self.enabled = True
        self.warmup = warmup  # power-up cycles whose outputs are not compared (flops without a clock edge yet are random)
        self._last_sel_cycle: Optional[int] = None
        self._gap_cg: Any = False  # False = not looked up yet, None = no ".bus" group registered

    def _ctx(self, inp, rst) -> str:
        return "cyc=%d sel=%d we=%d addr=0x%03x wdata=0x%08x rst=%s" % (self.env.cycle, inp.get("sel", 0), inp.get("we", 0), inp.get("addr", 0), inp.get("wdata", 0), "".join(k for k, v in rst.items() if v) or "-")

    def _cmp(self, what: str, exp, got, inp, rst) -> None:
        self.sb.checks += 1
        if exp != got:
            self.sb.check_eq(what, exp, got, self._ctx(inp, rst) + " inputs=" + repr({k: v for k, v in inp.items() if k not in ("sel", "we", "addr", "wdata")}))

    def sample(self) -> None:
        env = self.env
        inp = {k: s.read() for k, s in self.ins.items()}
        inp["_cycle"] = env.cycle
        rst = self.resets()
        exp = self.model.step(inp, rst)
        self.last_inp, self.last_exp = inp, exp
        self.cycles += 1
        if not self.enabled or env.cycle <= self.warmup:
            return
        if self._gap_cg is False:
            self._gap_cg = next((g for g in env.coverage if g.name.endswith(".bus")), None)
        if self._gap_cg is not None and "sel" in inp:
            if inp["sel"]:
                if self._last_sel_cycle is not None:
                    self._gap_cg.sample(gap=min(env.cycle - self._last_sel_cycle - 1, 99))
                self._last_sel_cycle = env.cycle
            elif inp.get("we") or inp.get("addr") or inp.get("wdata"):
                self._gap_cg.sample(idle_garbage_cycles=1)  # garbage on we/addr/wdata with sel = 0: no side effect allowed
        pins: List[int] = []
        if inp.get("sel"):
            self.n_access += 1
            got_err = self.outs["err"].read()
            self._cmp("rb_err", exp["err"], got_err, inp, rst)
            if inp.get("we"):
                self.n_writes += 1
            else:
                self.n_reads += 1
                if exp.get("rdata") is not None:
                    got = self.outs["rdata"].read()
                    mask = (exp.get("rmask") or self.model.rdata_mask(inp["addr"])) if not exp["err"] else 0xFFFFFFFF
                    self._cmp("rb_rdata", exp["rdata"] & mask, got & mask, inp, rst)
                    pins.append(got)
            if exp["err"]:
                self.n_err += 1
            pins.append(got_err)
        for k, s in self.outs.items():
            if k in ("rdata", "err", "rmask"):
                continue
            e = exp.get(k)
            g = s.read()
            if e is not None:
                self._cmp(k, e, g, inp, rst)
            pins.append(g)
        t = tuple(pins)
        if inp.get("sel") or t != self._last_pins:
            env.digest.event("ctl", env.cycle, t)
        self._last_pins = t
        for h in self.hooks:
            h(inp, exp, rst)

    def summary(self) -> dict:
        return {"cycles": self.cycles, "accesses": self.n_access, "reads": self.n_reads, "writes": self.n_writes,
                "refused": self.n_err, "checks": self.sb.checks}


class Recorder(Agent):
    """Records selected DUT signals at every edge (``h[name][cycle]``): used by directed tests for hand-computed timing."""

    def __init__(self, name: str, sigs: Dict[str, Sig], keep: int = 400000):
        super().__init__(name)
        self.sigs = sigs
        self.h: Dict[str, Dict[int, int]] = {k: {} for k in sigs}
        self.keep = keep

    def sample(self) -> None:
        c = self.env.cycle
        for k, s in self.sigs.items():
            self.h[k][c] = s.read()
            if len(self.h[k]) > self.keep:
                self.h[k].pop(next(iter(self.h[k])))

    def run_of(self, k: str, val: int, start: int) -> int:
        """Length of the run of ``val`` of signal ``k`` beginning at cycle ``start``."""
        n = 0
        while self.h[k].get(start + n) == val:
            n += 1
        return n


# ----------------------------------------------------------------------------- non-bus input driver


class PinDriver(Agent):
    """Seeded stimulus for the DUT inputs that are not the register bus.

    Per pin: ``("rand", p)``  1 with probability p each cycle (pulses; vectors: random bits)
             ``("level", p)`` toggles with probability p each cycle (multi-cycle levels)
             ``("hold", v)``  constant
             ``("off",)``     constant 0
    """

    def __init__(self, name: str, rng, pins: Dict[str, Tuple[Sig, int]]):
        super().__init__(name)
        self.rng = rng
        self.pins = pins
        self.mode: Dict[str, Tuple] = {k: ("off",) for k in pins}
        self.val: Dict[str, int] = {k: 0 for k in pins}
        self.log: List[Tuple[int, str, int]] = []
        self.written: Dict[str, bool] = {}

    def set(self, pin: str, *mode) -> None:
        self.mode[pin] = tuple(mode)

    def set_all(self, *mode, only: Optional[Iterable[str]] = None) -> None:
        for k in (only if only is not None else self.pins):
            self.mode[k] = tuple(mode)

    def force(self, pin: str, value: int) -> None:
        self.mode[pin] = ("hold", value)

    def drive(self) -> None:
        for k, (sig, w) in self.pins.items():
            m = self.mode[k]
            if m[0] == "off":
                v = 0
            elif m[0] == "hold":
                v = m[1]
            elif m[0] == "rand":
                v = (1 if self.rng.random() < m[1] else 0) if w == 1 else (self.rng.getrandbits(w) if self.rng.random() < m[1] else 0)
            elif m[0] == "level":
                v = self.val[k] ^ 1 if self.rng.random() < m[1] else self.val[k]
                if w > 1:
                    v = self.rng.getrandbits(w) if self.rng.random() < m[1] else self.val[k]
            elif m[0] == "noise":  # fully random value every cycle (vectors: address buses)
                v = self.rng.getrandbits(w)
            else:  # pragma: no cover
                raise ValueError(m)
            if v != self.val[k] or not self.written.get(k):
                sig.write(v)
                self.written[k] = True
            self.val[k] = v


# ----------------------------------------------------------------------------- traffic generator

SPECIAL_DATA = (0, 0xFFFF_FFFF, 0x1, 0x8000_0000, 0xA5A5_A5A5, 0x5A5A_5A5A, 0x0000_FFFF, 0xFFFF_0000, 0x0001_0000)


class RegTraffic:
    """Random register accesses.

    ``regs``   : list of (offset, [interesting data values]) of the documented registers
    ``weights``: probability of picking a documented register / an undocumented ("hole") offset of the page /
                 a fully random 12-bit offset (not word-aligned only when ``unaligned`` is set)
    """

    def __init__(self, rng, regs: Sequence[Tuple[int, Sequence[int]]], *, p_reg=0.8, p_hole=0.15, p_write=0.5, unaligned: bool = False,
                 page_words: int = 1024, data_special: Sequence[int] = SPECIAL_DATA):
        self.rng = rng
        self.regs = list(regs)
        self.p_reg, self.p_hole, self.p_write = p_reg, p_hole, p_write
        self.unaligned = unaligned
        self.page_words = page_words
        self.special = list(data_special)
        self.known = {a for a, _ in self.regs}

    def data_for(self, specials: Sequence[int]) -> int:
        r = self.rng.random()
        if specials and r < 0.35:
            return self.rng.choice(list(specials))
        if r < 0.55:
            return self.rng.choice(self.special)
        if r < 0.65:
            return 1 << self.rng.randrange(32)
        return self.rng.getrandbits(32)

    def next(self) -> Tuple[bool, int, int]:
        rng = self.rng
        r = rng.random()
        if r < self.p_reg and self.regs:
            addr, spec = rng.choice(self.regs)
        elif r < self.p_reg + self.p_hole:
            while True:
                addr = rng.randrange(self.page_words) * 4
                if addr not in self.known:
                    break
            spec = ()
        else:
            addr = rng.randrange(self.page_words) * 4
            spec = ()
        if self.unaligned and rng.random() < 0.1:
            addr |= rng.randrange(1, 4)
        write = rng.random() < self.p_write
        return write, addr, self.data_for(spec)

    def queue(self, rb: RegBusMaster, n: int) -> None:
        for _ in range(n):
            w, a, d = self.next()
            (rb.write_op(a, d) if w else rb.read_op(a))


def queue_sweep(rb: RegBusMaster, base_words: Iterable[int] = range(1024), *, write: bool = False, data: int = 0) -> None:
    """Read (or write) every word offset of the 4 KiB page: exposes holes and aliases."""
    for w in base_words:
        (rb.write_op(w * 4, data) if write else rb.read_op(w * 4))


# ----------------------------------------------------------------------------- reset helpers


async def async_reset_midcycle(env: Env, rst, phase_ns: float, length: int, reason: str = "async-midcycle") -> None:
    """Assert reset ``phase_ns`` after the edge that the last ``env.tick()`` just processed (i.e. between two
    clock edges) and hold it for ``length`` cycles.  Same effect as ``ResetSequencer.async_pulse`` but without
    consuming a clock edge itself, so the agents stay in lockstep with the DUT (call it right after a tick)."""
    from cocotb.triggers import Timer

    await Timer(phase_ns, units="ns")
    sh = rst.rst.sh
    sh.h.value = rst.active
    sh.pend = rst.active
    sh.dirty = False
    c = env.cycle
    rst.asserted = True
    rst.n_pulses += 1
    rst.log.append((c, length, reason))
    rst._sched.append((c + 1, c + 1 + length))
    env.digest.event("reset-async", c, length)
    env.notify_reset(True)


# ----------------------------------------------------------------------------- coverage helpers


def txn_cover(name: str, kinds: Dict[str, Tuple[str, str]]) -> CoverGroup:
    """Transaction-type x register-class x outcome coverage of a register page.

    ``kinds`` maps a register class to the (read result, write result) the spec prescribes, e.g. a read-only
    register is ("ok", "refused"); impossible combinations are excluded from the cross (not padded)."""
    g = CoverGroup(name + ".txn", "register-bus transaction types: access type x register class x result")
    g.point("dir", ["read", "write"])
    g.point("kind", list(kinds))
    g.point("result", ["ok", "refused"])

    def ignore(combo):
        d, k, r = combo
        return kinds[k][0 if d == "read" else 1] != r

    g.cross("dir_kind_result", ["dir", "kind", "result"], ignore=ignore)
    return g


def gap_cover(name: str) -> CoverGroup:
    g = CoverGroup(name + ".bus", "register-bus pacing (a single-cycle bus has no back-pressure; the gap between accesses is the analogue)")
    g.point("gap", {"b2b": 0, "gap1": 1, "gap2_3": (2, 3), "gap4+": lambda v: v >= 4})
    g.point("idle_garbage_cycles", {"seen": lambda v: v > 0})
    return g


def finish(env: Env, sb: Scoreboard, test: str, checker: Optional[BlockChecker] = None, **extra) -> dict:
    sb.finalize(allow_outstanding=True)
    env.finalize()
    if checker is not None:
        extra["checker"] = checker.summary()
    extra["scoreboard"] = sb.summary()
    return env.write_result(test, **extra)


def expect(sb: Scoreboard, what: str, exp, got, ctx: str = "") -> None:
    """Hand-computed spec expectation (independent of the model)."""
    sb.check_eq(what, exp, got, ctx)
