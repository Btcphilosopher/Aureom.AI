"""Pure-Python tests of the cc_pmu reference model (hand-computed spec examples)."""
from albionverify.models import ctl_spec as S
from albionverify.models.ctl_pmu import PmuModel

A = S.PMU


def cyc(m, sel=0, we=0, addr=0, wdata=0, **pins):
    inp = {"sel": sel, "we": we, "addr": addr, "wdata": wdata, "cpu_sleep": 0, "vec_busy": 0, "tsu_busy": 0, "tsu_halted": 0, "ext_idle": 1, "fatal_iso": 0, "acc_in_reset": 0}
    inp.update(pins)
    return m.step(inp, {"sys": False})


def wr(m, a, d, **p):
    return cyc(m, 1, 1, a, d, **p)


def rd(m, a, **p):
    return cyc(m, 1, 0, a, 0, **p)


def test_reset_values():
    m = PmuModel()
    assert rd(m, A["INFO"])["rdata"] == 0x11
    assert rd(m, A["ACC_CTRL"])["rdata"] == 1
    assert rd(m, A["ACC_STATUS"])["rdata"] == 0x9  # CLK_ON | EXT_IDLE
    o = cyc(m)
    assert (o["acc_clk_en"], o["acc_rst_req"], o["acc_iso"]) == (1, 0, 0)


def test_clock_off_takes_two_edges_and_isolates_at_once():
    m = PmuModel()
    wr(m, A["ACC_CTRL"], 0)
    o1 = cyc(m)  # state after the write edge: ctl = 0, clock still on
    assert (o1["acc_clk_en"], o1["acc_iso"]) == (1, 1)
    o2 = cyc(m)
    assert (o2["acc_clk_en"], o2["acc_iso"]) == (0, 1)
    assert rd(m, A["ACC_STATUS"])["rdata"] == 0x4 | 0x8  # ISOLATED | EXT_IDLE, CLK_ON = 0
    wr(m, A["ACC_CTRL"], 1)
    assert cyc(m)["acc_clk_en"] == 0 and cyc(m)["acc_clk_en"] == 1  # back on two edges after the write


def test_busy_units_hold_the_clock():
    for pin in ("vec_busy", "tsu_busy"):
        m = PmuModel()
        wr(m, A["ACC_CTRL"], 0, **{pin: 1})
        for _ in range(5):
            assert cyc(m, **{pin: 1})["acc_clk_en"] == 1
        st = rd(m, A["ACC_STATUS"], **{pin: 1})["rdata"]
        assert st & 1 and st >> 7 & 1  # CLK_ON and CLK_OFF_PENDING
        cyc(m)
        assert cyc(m)["acc_clk_en"] == 0
    m = PmuModel()
    wr(m, A["ACC_CTRL"], 0, ext_idle=0)
    assert all(cyc(m, ext_idle=0)["acc_clk_en"] == 1 for _ in range(4))


def test_reset_request_deferred_until_port_idle_and_held():
    m = PmuModel()
    wr(m, A["ACC_CTRL"], 3, ext_idle=0)
    assert all(cyc(m, ext_idle=0)["acc_rst_req"] == 0 for _ in range(4))
    cyc(m)  # port idle
    assert cyc(m)["acc_rst_req"] == 1
    assert all(cyc(m, ext_idle=0)["acc_rst_req"] == 1 for _ in range(4))  # not withdrawn when busy again
    wr(m, A["ACC_CTRL"], 1)
    cyc(m)
    assert cyc(m)["acc_rst_req"] == 0


def test_isolation_sources():
    m = PmuModel()
    assert cyc(m)["acc_iso"] == 0
    assert cyc(m, fatal_iso=1)["acc_iso"] == 1
    assert cyc(m, acc_in_reset=1)["acc_iso"] == 1
    wr(m, A["ACC_CTRL"], 5)  # ISO | CLK_EN
    assert cyc(m)["acc_iso"] == 1 and cyc(m)["acc_clk_en"] == 1


def test_counters_and_access_classes():
    m = PmuModel()
    for _ in range(10):
        cyc(m, cpu_sleep=1)
    assert rd(m, A["SLEEP_CYC"])["rdata"] == 10
    wr(m, A["ACC_CTRL"], 0)
    for _ in range(5):
        cyc(m)
    assert rd(m, A["GATED_CYC"])["rdata"] >= 3
    for a in (A["INFO"], A["ACC_STATUS"], A["CC_STATE"], A["SLEEP_CYC"], A["GATED_CYC"]):
        assert wr(m, a, 1)["err"] == 1
    for a in (0x018, 0x01C, 0xFFC, 0x005):
        assert wr(m, a, 1)["err"] == 1 and rd(m, a)["err"] == 1
    assert wr(m, A["ACC_CTRL"], 0xFFFFFFF8 | 5)["err"] == 0
    assert rd(m, A["ACC_CTRL"])["rdata"] == 5
