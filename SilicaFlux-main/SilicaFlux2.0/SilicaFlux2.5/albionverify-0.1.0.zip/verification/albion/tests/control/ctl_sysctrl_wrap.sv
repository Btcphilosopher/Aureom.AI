// Verification wrapper: cc_sysctrl + the slice of silicaflux_control_core that makes its reset generator observable.
//   rst_ni --sfv_rst_sync--> por_rst_n --+--> POR domain of cc_sysctrl
//   (por_rst_n && !sys_reset_req) --sfv_rst_sync--> sys_rst_n --> SYS domain
//   boot_mode_i / host_rst_req_i --2-flop sfv_sync (reset by por_rst_n)--> cc_sysctrl
// Same wiring as the top level (silicaflux_control_core.sv lines "resets and synchronisers"); wdt_req is a plain input here.
`default_nettype none
module ctl_sysctrl_wrap #(
  parameter logic [31:0] FEATURES   = 32'h7F,
  parameter logic [31:0] ROM_BYTES  = 32'h2000,
  parameter logic [31:0] IMEM_BYTES = 32'h10000,
  parameter logic [31:0] DMEM_BYTES = 32'h8000
) (
  input  wire logic        clk,
  input  wire logic        rst_ni,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  input  wire logic [1:0]  boot_mode_i,
  input  wire logic        wdt_req,
  input  wire logic        host_rst_req_i,
  output logic             sys_reset_req,
  output logic             por_rst_n,
  output logic             sys_rst_n,
  output logic             host_ready,
  output logic             cmdproc_ready,
  output logic             test_done,
  output logic             test_fail,
  output logic [15:0]      test_code
);
  logic [1:0] boot_mode_s;
  logic       host_rst_s;
  sfv_rst_sync u_rs_por (.clk, .rst_ni(rst_ni), .test_mode(1'b0), .test_rst_ni(rst_ni), .rst_no(por_rst_n));
  sfv_rst_sync u_rs_sys (.clk, .rst_ni(por_rst_n && !sys_reset_req), .test_mode(1'b0), .test_rst_ni(rst_ni), .rst_no(sys_rst_n));
  sfv_sync u_sy_bm0 (.clk, .rst_n(por_rst_n), .d(boot_mode_i[0]), .q(boot_mode_s[0]));
  sfv_sync u_sy_bm1 (.clk, .rst_n(por_rst_n), .d(boot_mode_i[1]), .q(boot_mode_s[1]));
  sfv_sync u_sy_hr  (.clk, .rst_n(por_rst_n), .d(host_rst_req_i), .q(host_rst_s));
  cc_sysctrl #(.FEATURES(FEATURES), .ROM_BYTES(ROM_BYTES), .IMEM_BYTES(IMEM_BYTES), .DMEM_BYTES(DMEM_BYTES)) u_dut (
    .clk, .por_rst_n, .rst_n(sys_rst_n),
    .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .boot_mode(boot_mode_s), .wdt_req, .host_rst_req(host_rst_s), .sys_reset_req,
    .host_ready, .cmdproc_ready, .test_done, .test_fail, .test_code
  );
endmodule
`default_nettype wire
