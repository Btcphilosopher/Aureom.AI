"""Every control mutant must be a valid exact-text patch of the pinned RTL (no simulator): each ``find`` occurs exactly
``count`` times (applied in order) and the replacement really changes the text."""
import glob
from pathlib import Path

import pytest

from albionverify import rtl
from albionverify.mutate.engine import load_mutants

ROOT = Path(__file__).resolve().parents[2]
FILES = sorted(glob.glob(str(ROOT / "mutants" / "ctl*.yaml")))


def _all():
    for f in FILES:
        for m in load_mutants(Path(f)):
            yield pytest.param(f, m, id="%s:%s" % (Path(f).stem, m.id))


@pytest.mark.parametrize("path,mut", list(_all()))
def test_mutant_patch_applies(path, mut):
    texts = {}
    for p in mut.patches:
        t = texts.setdefault(p.file, (rtl.RTL_DIR / p.file).read_text())
        n = t.count(p.find)
        assert n == p.count, "%s: find occurs %d times (expected %d): %r" % (mut.id, n, p.count, p.find[:70])
        assert p.find != p.replace
        texts[p.file] = t.replace(p.find, p.replace)
    assert texts


def test_every_suite_has_enough_mutants():
    counts = {Path(f).stem: len(load_mutants(Path(f))) for f in FILES}
    assert counts, "no control mutant files"
    for name, n in counts.items():
        assert n >= 15, "%s has only %d mutants" % (name, n)
