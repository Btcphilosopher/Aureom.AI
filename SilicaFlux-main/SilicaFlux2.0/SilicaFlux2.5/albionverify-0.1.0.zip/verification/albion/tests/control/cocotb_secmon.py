"""cc_secmon bench: capability report, host write lock (set-only), write-once boot measurement, host-violation log.

Reference model: albionverify/models/ctl_secmon.py (from MEMORY_MAP.md block cc_secmon, 03_BOOT.md section 4).
"""
import os

import cocotb

from albionverify.bus.regbus import RegBusMaster
from albionverify.core import Env
from albionverify.coverage import CoverGroup
from albionverify.models import ctl_spec as S
from albionverify.models.ctl_secmon import RO, SecmonModel
from albionverify.reset import ResetSequencer
from albionverify.scoreboard import Scoreboard

from control.ctl_bench import (BlockChecker, PinDriver, RegTraffic, async_reset_midcycle, expect, finish, gap_cover, queue_sweep, txn_cover)

A = S.SECMON
SEED = int(os.environ.get("ALBION_SEED", "1"))
REGS = [(A["CAPS"], ()), (A["STATUS"], ()), (A["CTRL"], (0, 1, 2, 3, 0xFFFFFFFE, 0xFFFFFFFF)),
        (A["BOOT_MEASURE"], (0, 0xFFFFFFFF, 0xC0FFEE00, 0x04C11DB7)), (A["VIOL_ADDR"], ()), (A["VIOL_COUNT"], ()),
        (A["CLEAR"], (0, 1, 2, 3, 0xFFFFFFFF, 0xFFFFFFFE)), (A["AUTH_HOOK"], ())]


def kind_of(a):
    if a & 3:
        return "unmapped"
    if a in (A["CAPS"], A["STATUS"], A["VIOL_ADDR"], A["VIOL_COUNT"], A["AUTH_HOOK"]):
        return "ro"
    if a in (A["CTRL"],):
        return "rw"
    if a == A["BOOT_MEASURE"]:
        return "write_once"
    if a == A["CLEAR"]:
        return "wo"
    return "unmapped"


def build(dut, seed):
    env = Env(dut, name="secmon", seed=seed)
    rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=4))
    rb = env.add(RegBusMaster("rb", env, rng=env.seeds.child("rb")))
    pins = env.add(PinDriver("pins", env.seeds.child("pins"), {"viol_evt": (env.sig("viol_evt"), 1), "viol_addr": (env.sig("viol_addr"), 32)}))
    pins.set("viol_addr", "noise")
    sb = Scoreboard(env, "secmon")
    model = SecmonModel()
    rstn = env.sig("rst_n")
    chk = env.add(BlockChecker(
        "chk", model, sb,
        ins={"sel": env.sig("rb_sel"), "we": env.sig("rb_we"), "addr": env.sig("rb_addr"), "wdata": env.sig("rb_wdata"),
             "viol_evt": env.sig("viol_evt"), "viol_addr": env.sig("viol_addr")},
        outs={"rdata": env.sig("rb_rdata"), "err": env.sig("rb_err"), "host_lock": env.sig("host_lock")}, resets=lambda: {"sys": rstn.read() == 0}))
    # BOOT_MEASURE: first write ok, later writes refused -> the result depends on state: use two kinds
    tc = txn_cover("secmon", {"ro": ("ok", "refused"), "rw": ("ok", "ok"), "write_once": ("ok", "ok"), "write_once_locked": ("ok", "refused"), "wo": ("refused", "ok"),
                              "unmapped": ("refused", "refused")})
    sc = CoverGroup("secmon.state", "lock / measurement / violation scenarios")
    sc.point("scenario", ["lock_set", "lock_write0_ignored", "lock_write_while_locked", "measure_first", "measure_second_refused", "viol_event", "viol_back_to_back",
                          "viol_with_clear_same_cycle", "clear_with_bit0", "clear_without_bit0", "viol_while_flag_set"])
    ac = CoverGroup("secmon.addr", "address boundaries")
    ac.point("addr", {"first": 0x000, "last_reg": 0x01C, "hole_next": 0x020, "hole_mid": lambda a: 0x020 < a < 0xFFC, "page_last_word": 0xFFC})
    env.coverage += [tc, sc, ac, gap_cover("secmon")]
    prev = {"viol": 0}

    def pre(inp, resets):
        if resets.get("sys"):
            prev["viol"] = 0
            return
        m = model
        if inp["sel"]:
            k = kind_of(inp["addr"])
            if k == "write_once" and m.meas_v:
                k = "write_once_locked"
            tc.sample(dir="write" if inp["we"] else "read", kind=k, result="refused" if m.evaluate(inp)["err"] else "ok")
            ac.sample(addr=inp["addr"])
            if inp["we"]:
                a, d = inp["addr"], inp["wdata"]
                if a == A["CTRL"]:
                    sc.sample(scenario="lock_write_while_locked" if m.lock else ("lock_set" if d & 1 else "lock_write0_ignored"))
                elif a == A["BOOT_MEASURE"]:
                    sc.sample(scenario="measure_second_refused" if m.meas_v else "measure_first")
                elif a == A["CLEAR"]:
                    sc.sample(scenario="clear_with_bit0" if d & 1 else "clear_without_bit0")
                    if inp["viol_evt"]:
                        sc.sample(scenario="viol_with_clear_same_cycle")
        if inp["viol_evt"]:
            sc.sample(scenario="viol_event")
            if prev["viol"]:
                sc.sample(scenario="viol_back_to_back")
            if m.viol:
                sc.sample(scenario="viol_while_flag_set")
        prev["viol"] = inp["viol_evt"]

    orig = model.step

    def step(inp, resets):
        pre(inp, resets)
        return orig(inp, resets)

    model.step = step
    return env, rst, rb, pins, sb, model, chk


async def go(dut, seed):
    env, rst, rb, pins, sb, model, chk = build(dut, seed)
    await env.start()
    await env.until(lambda: not rst.asserted, 50, "reset release")
    return env, rst, rb, pins, sb, model, chk


async def drain(env, rb, n=200000):
    await env.until(lambda: rb.idle, n, "register ops")


async def viol(env, pins, addr, n=1):
    pins.force("viol_evt", 1)
    pins.force("viol_addr", addr)
    await env.cycles(n)
    pins.force("viol_evt", 0)
    pins.set("viol_addr", "noise")
    await env.cycles(3)


@cocotb.test()
async def reset_values(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)
    queue_sweep(rb)
    await drain(env, rb)
    by = {op.addr: op for op in rb.history}
    expect(sb, "CAPS: lock + CRC32 integrity + execute-never, no auth / secure boot / RoT / debug", 0x70, by[A["CAPS"]].rdata)
    for nm in ("STATUS", "CTRL", "BOOT_MEASURE", "VIOL_ADDR", "VIOL_COUNT", "AUTH_HOOK"):
        expect(sb, nm + " reset value", (0, False), (by[A[nm]].rdata, by[A[nm]].err))
    expect(sb, "CLEAR is write-only: read refused", True, by[A["CLEAR"]].err)
    for a in (0x020, 0x024, 0x100, 0x800, 0xFFC):
        expect(sb, "hole refused", (True, 0), (by[a].err, by[a].rdata), "0x%x" % a)
    expect(sb, "host_lock low at reset", 0, dut.host_lock.value.integer)
    ops = [rb.write_op(A[n], 0xFFFFFFFF) for n in ("CAPS", "STATUS", "VIOL_ADDR", "VIOL_COUNT", "AUTH_HOOK")] + [rb.write_op(0x020, 1)]
    await drain(env, rb)
    for o in ops:
        expect(sb, "write to RO / hole refused", True, o.err, "0x%x" % o.addr)
    expect(sb, "CAPS bits [3:0] = 0 (no auth, secure boot, RoT, debug)", 0, (await rb.read(A["CAPS"])).rdata & 0xF)
    finish(env, sb, "reset_values", chk)


@cocotb.test()
async def lock_and_measure_directed(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)

    async def rd(a):
        return (await rb.read(a)).rdata

    # HOST_LOCK: set-only
    await rb.write(A["CTRL"], 0xFFFFFFFE)  # bit 0 = 0: nothing
    expect(sb, "write without bit 0 does not lock", (0, 0), (await rd(A["CTRL"]), dut.host_lock.value.integer))
    await rb.write(A["CTRL"], 0x1)
    await env.tick()
    expect(sb, "lock set: CTRL, STATUS and the pin", (1, 1, 1), (await rd(A["CTRL"]), await rd(A["STATUS"]) & 1, dut.host_lock.value.integer))
    o = await rb.write(A["CTRL"], 0x0)
    expect(sb, "writing 0 is accepted but cannot release the lock", (False, 1, 1), (o.err, await rd(A["CTRL"]), dut.host_lock.value.integer))
    await rb.write(A["CTRL"], 0xFFFFFFFE)
    expect(sb, "still locked", 1, await rd(A["CTRL"]))
    # BOOT_MEASURE: write once
    expect(sb, "not measured yet", 0, await rd(A["STATUS"]) >> 1 & 1)
    o = await rb.write(A["BOOT_MEASURE"], 0xDEADBEEF)
    expect(sb, "first write accepted", False, o.err)
    expect(sb, "value readable, MEASURED set", (0xDEADBEEF, 1), (await rd(A["BOOT_MEASURE"]), await rd(A["STATUS"]) >> 1 & 1))
    for v in (0x12345678, 0, 0xDEADBEEF):
        o = await rb.write(A["BOOT_MEASURE"], v)
        expect(sb, "second write refused (0x%x)" % v, True, o.err)
        expect(sb, "value unchanged by a refused write", 0xDEADBEEF, await rd(A["BOOT_MEASURE"]))
    # a measurement of all-zero still counts as measured
    await rb.write(A["CTRL"], 0)
    # AUTH_HOOK and AUTH_STATE
    expect(sb, "AUTH_HOOK reads 0", 0, await rd(A["AUTH_HOOK"]))
    expect(sb, "AUTH_STATE = 0 (not implemented)", 0, await rd(A["STATUS"]) >> 2 & 3)
    expect(sb, "STATUS = lock + measured only", 0x3, await rd(A["STATUS"]))
    finish(env, sb, "lock_and_measure_directed", chk)


@cocotb.test()
async def zero_measure_directed(dut):
    """A measurement value of 0 is still a measurement: the second write is refused."""
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)
    o = await rb.write(A["BOOT_MEASURE"], 0)
    expect(sb, "first write of 0 accepted", False, o.err)
    expect(sb, "MEASURED set by a zero measurement", 1, (await rb.read(A["STATUS"])).rdata >> 1 & 1)
    o = await rb.write(A["BOOT_MEASURE"], 0x55)
    expect(sb, "later write refused", True, o.err)
    expect(sb, "value still 0", 0, (await rb.read(A["BOOT_MEASURE"])).rdata)
    finish(env, sb, "zero_measure_directed", chk)


@cocotb.test()
async def violation_log_directed(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)

    async def rd(a):
        return (await rb.read(a)).rdata

    await viol(env, pins, 0x0001_0040)
    expect(sb, "violation sets HOST_VIOLATION, logs address, count 1", (1, 0x0001_0040, 1), (await rd(A["STATUS"]) >> 8 & 1, await rd(A["VIOL_ADDR"]), await rd(A["VIOL_COUNT"])))
    await viol(env, pins, 0x0002_7FFC)
    expect(sb, "VIOL_ADDR keeps the LAST violation, count 2", (0x0002_7FFC, 2), (await rd(A["VIOL_ADDR"]), await rd(A["VIOL_COUNT"])))
    await viol(env, pins, 0x0000_0000, n=3)  # three consecutive cycles = three events
    expect(sb, "one count per violation cycle", 5, await rd(A["VIOL_COUNT"]))
    expect(sb, "address of a violation at 0", 0, await rd(A["VIOL_ADDR"]))
    # CLEAR: only bit 0 clears the flag, address / count stay
    await rb.write(A["CLEAR"], 0xFFFFFFFE)
    expect(sb, "CLEAR without bit 0 does nothing", 1, await rd(A["STATUS"]) >> 8 & 1)
    await rb.write(A["CLEAR"], 0x1)
    expect(sb, "CLEAR[0] clears HOST_VIOLATION only", (0, 5, 0), (await rd(A["STATUS"]) >> 8 & 1, await rd(A["VIOL_COUNT"]), await rd(A["VIOL_ADDR"])))
    # violation in the same cycle as CLEAR: the event wins
    await env.tick()
    pins.force("viol_evt", 1)
    pins.force("viol_addr", 0xA5A5_0004)
    rb.write_op(A["CLEAR"], 1)
    await env.tick()
    pins.force("viol_evt", 0)
    pins.set("viol_addr", "noise")
    await env.cycles(4)
    expect(sb, "new violation survives a same-cycle CLEAR", (1, 0xA5A5_0004, 6), (await rd(A["STATUS"]) >> 8 & 1, await rd(A["VIOL_ADDR"]), await rd(A["VIOL_COUNT"])))
    finish(env, sb, "violation_log_directed", chk)


@cocotb.test()
async def unaligned_probe(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)
    ops = []
    for base in (0x000, 0x008, 0x00C, 0x018, 0x01C):
        for off in (1, 2, 3):
            ops.append(rb.write_op(base + off, 0xFFFFFFFF))
            ops.append(rb.read_op(base + off))
    await drain(env, rb)
    for o in ops:
        expect(sb, "unaligned access refused", True, o.err, "%s 0x%x" % ("write" if o.write else "read", o.addr))
    expect(sb, "unaligned writes did not lock / measure", (0, 0), (dut.host_lock.value.integer, (await rb.read(A["STATUS"])).rdata))
    finish(env, sb, "unaligned_probe", chk)


def pin_profile(pins, phase):
    pins.set("viol_addr", "noise")
    pins.set("viol_evt", ["rand", "rand", "level", "off", "rand", "off"][phase], *([0.02] if phase == 0 else [0.2] if phase == 1 else [0.05] if phase == 2 else [] if phase in (3, 5) else [0.5]))


@cocotb.test()
async def random_traffic(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)
    rng = env.seeds.child("traffic")
    n_ops = int(os.environ.get("CTL_OPS", "6000"))
    for phase in range(6):
        pin_profile(pins, phase)
        # BOOT_MEASURE / CTRL lock traffic is rarer so that both states of the write-once / set-only registers are exercised
        tr = RegTraffic(rng, REGS, p_reg=0.9, p_hole=0.06, p_write=[0.4, 0.3, 0.5, 0.4, 0.5, 0.2][phase])
        rb.gap.set_mode(["always", "random:0.5", "bursty:1-6", "always", "random:0.9", "random:0.3"][phase])
        tr.queue(rb, n_ops // 6)
        await drain(env, rb)
        if phase < 5:  # a system reset releases the lock / measurement: the set-only / write-once registers are explored from their reset state again
            n0 = rst.n_pulses
            rst.pulse(length=rng.randint(1, 3), delay=1, reason="between phases")
            await env.until(lambda: rst.n_pulses > n0, 20, "reset asserted")
            await env.until(lambda: not rst.asserted, 20, "reset release")
    queue_sweep(rb)
    await drain(env, rb)
    finish(env, sb, "random_traffic", chk)


@cocotb.test()
async def reset_traffic(dut):
    """Reset releases the lock and the measurement (system reset), clears the violation log."""
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)
    rng = env.seeds.child("rst")
    tr = RegTraffic(rng, REGS, p_reg=0.9, p_hole=0.05, p_write=0.5)
    for rnd in range(10):
        pin_profile(pins, rng.randrange(5))
        await rb.write(A["CTRL"], 1)
        await rb.write(A["BOOT_MEASURE"], 0x1000 + rnd)
        tr.queue(rb, 80 + rng.randrange(150))
        await env.until(lambda: len(rb.queue) < 20, 30000, "traffic running")
        n0 = rst.n_pulses
        if rnd % 2 == 0:
            rst.pulse(length=rng.randint(1, 3), delay=rng.randint(1, 4), reason="sync-reset")
        else:
            await env.tick()
            await async_reset_midcycle(env, rst, rng.choice((1.0, 2.0, 3.0, 4.0, 6.0, 7.0, 8.5)), rng.randint(1, 3))
        await env.until(lambda: rst.n_pulses > n0, 20, "reset asserted")
        pin_profile(pins, 5)
        await env.cycles(2)
        await env.until(lambda: not rst.asserted, 20, "reset release")
        await env.cycles(2)
        expect(sb, "STATUS after reset #%d" % rnd, 0, (await rb.read(A["STATUS"])).rdata)
        expect(sb, "CTRL / BOOT_MEASURE after reset", (0, 0, 0), ((await rb.read(A["CTRL"])).rdata, (await rb.read(A["BOOT_MEASURE"])).rdata, dut.host_lock.value.integer))
        expect(sb, "violation log after reset", (0, 0), ((await rb.read(A["VIOL_COUNT"])).rdata, (await rb.read(A["VIOL_ADDR"])).rdata))
        o = await rb.write(A["BOOT_MEASURE"], 0x77)
        expect(sb, "measurement writable again after reset", False, o.err)
    finish(env, sb, "reset_traffic", chk)
