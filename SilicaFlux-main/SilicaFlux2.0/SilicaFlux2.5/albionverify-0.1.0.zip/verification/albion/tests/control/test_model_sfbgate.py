"""Pure-Python tests of the cc_sfb_gate reference model (hand-computed cycle sequences)."""
from albionverify.models.ctl_sfbgate import SfbGateModel

BASE = {"s_req_valid": 0, "s_req_write": 0, "s_req_addr": 0, "s_req_wdata": 0, "s_req_wstrb": 0, "s_rsp_ready": 1, "m_req_ready": 1, "m_rsp_valid": 0,
        "m_rsp_rdata": 0, "m_rsp_error": 0, "refuse": 0}


def step(m, **kw):
    i = dict(BASE)
    i.update(kw)
    return m.step(i, {"sys": False})


def test_refused_request_is_accepted_locally_and_answered_with_error_one_cycle_later():
    m = SfbGateModel()
    o = step(m, s_req_valid=1, s_req_addr=0x40, s_req_write=1, s_req_wdata=0xAA, refuse=1)
    assert (o["s_req_ready"], o["m_req_valid"], o["refused_evt"]) == (1, 0, 1)
    o = step(m, s_rsp_ready=0)
    assert (o["s_rsp_valid"], o["s_rsp_error"], o["s_rsp_rdata"], o["m_req_valid"], o["idle"]) == (1, 1, 0, 0, 0)
    o = step(m, s_rsp_ready=1, s_req_valid=1)  # response accepted, next request waits (not free yet)
    assert (o["s_rsp_valid"], o["s_req_ready"]) == (1, 0)
    o = step(m)
    assert (o["s_rsp_valid"], o["idle"]) == (0, 1)


def test_forwarded_request_waits_for_the_response_and_blocks_the_next():
    m = SfbGateModel()
    o = step(m, s_req_valid=1, s_req_addr=8, m_req_ready=1)
    assert (o["m_req_valid"], o["m_req_addr"], o["s_req_ready"], o["refused_evt"]) == (1, 8, 1, 0)
    o = step(m, s_req_valid=1, s_req_addr=12)  # first one outstanding: gate busy
    assert (o["s_req_ready"], o["m_req_valid"], o["idle"]) == (0, 0, 0)
    o = step(m, s_req_valid=1, s_req_addr=12, m_rsp_valid=1, m_rsp_rdata=0x55, m_rsp_error=0)
    assert (o["s_rsp_valid"], o["s_rsp_rdata"], o["m_rsp_ready"], o["s_req_ready"]) == (1, 0x55, 1, 0)
    o = step(m, s_req_valid=1, s_req_addr=12)  # response consumed: free again
    assert (o["m_req_valid"], o["s_req_ready"]) == (1, 1)


def test_presented_request_is_never_withdrawn_when_refuse_rises():
    m = SfbGateModel()
    o = step(m, s_req_valid=1, m_req_ready=0)
    assert (o["m_req_valid"], o["s_req_ready"]) == (1, 0)
    for _ in range(3):
        o = step(m, s_req_valid=1, m_req_ready=0, refuse=1)
        assert (o["m_req_valid"], o["s_req_ready"], o["refused_evt"]) == (1, 0, 0)
    o = step(m, s_req_valid=1, m_req_ready=1, refuse=1)
    assert (o["m_req_valid"], o["s_req_ready"]) == (1, 1)


def test_refuse_decided_on_the_first_free_cycle():
    m = SfbGateModel()
    o = step(m, s_req_valid=1, refuse=1, m_req_ready=0)
    assert o["s_req_ready"] == 1 and o["m_req_valid"] == 0  # refused even though downstream is not ready


def test_reset_clears_the_gate():
    m = SfbGateModel()
    step(m, s_req_valid=1, m_req_ready=1)
    m.step(dict(BASE), {"sys": True})
    assert step(m)["idle"] == 1
