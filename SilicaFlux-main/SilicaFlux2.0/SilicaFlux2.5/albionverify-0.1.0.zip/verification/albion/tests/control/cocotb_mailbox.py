"""cc_mailbox bench: host <-> firmware mailbox, doorbell pins, console FIFO (DIAG_DEPTH parameter).

Reference model: albionverify/models/ctl_mailbox.py (written from MEMORY_MAP.md / HW_SW_INTERFACE.md).
Every cycle the DUT inputs in force are fed to the model and rb_rdata / rb_err / irq_h2f / host_irq /
diag_valid / diag_char are compared (BlockChecker).  Directed tests additionally assert hand-computed spec values
that do not pass through the model.
"""
import os

import cocotb

from albionverify.bus.regbus import RegBusMaster
from albionverify.core import Env
from albionverify.coverage import CoverGroup
from albionverify.models import ctl_spec as S
from albionverify.models.ctl_mailbox import MailboxModel
from albionverify.reset import ResetSequencer
from albionverify.scoreboard import Scoreboard

from control.ctl_bench import (PARAMS, BlockChecker, RegTraffic, async_reset_midcycle, expect, finish, gap_cover, queue_sweep,
                               txn_cover)

A = S.MAILBOX
DEPTH = int(PARAMS.get("DIAG_DEPTH", 256))
SEED = int(os.environ.get("ALBION_SEED", "1"))
REGS = [(0x000 + 4 * i, ()) for i in range(8)] + [(0x020 + 4 * i, ()) for i in range(8)] + [
    (A["DB_STATUS"], ()), (A["H2F_RING"], ()), (A["H2F_ACK"], ()), (A["F2H_RING"], ()), (A["F2H_ACK"], ()), (A["H2F_CODE"], ()),
    (A["F2H_CODE"], ()), (A["RING_COUNT"], ()), (A["DIAG_TX"], ()), (A["DIAG_RX"], ()), (A["DIAG_POP"], ()),
    (A["DIAG_STATUS"], (0x10000, 0x1FFFF, 0x0FFFF, 0x100))]


def addr_class(a):
    k = MailboxModel.kind(a)
    if k == "none":
        return "unmapped"
    if a <= 0x03C:
        return "msg"
    return {"rw": "diag_status", "ro": "ro", "wo": "wo"}[k]


def build(dut, seed):
    env = Env(dut, name="mbox", seed=seed)
    rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=4))
    rb = env.add(RegBusMaster("rb", env, rng=env.seeds.child("rb")))
    sb = Scoreboard(env, "mbox")
    model = MailboxModel(DEPTH)
    rst_sig = env.sig("rst_n")
    chk = env.add(BlockChecker(
        "chk", model, sb,
        ins={"sel": env.sig("rb_sel"), "we": env.sig("rb_we"), "addr": env.sig("rb_addr"), "wdata": env.sig("rb_wdata")},
        outs={"rdata": env.sig("rb_rdata"), "err": env.sig("rb_err"), "irq_h2f": env.sig("irq_h2f"), "host_irq": env.sig("host_irq"),
              "diag_valid": env.sig("diag_valid"), "diag_char": env.sig("diag_char")},
        resets=lambda: {"sys": rst_sig.read() == 0}))
    # ---- functional coverage
    tc = txn_cover("mbox", {"msg": ("ok", "ok"), "ro": ("ok", "refused"), "wo": ("refused", "ok"), "diag_status": ("ok", "ok"),
                            "unmapped": ("refused", "refused")})
    gc = gap_cover("mbox")
    fc = CoverGroup("mbox.fifo", "console FIFO: level x operation")
    fc.point("level", {"empty": 0, "one": 1, "mid": lambda v: 1 < v < DEPTH - 1, "depth-1": DEPTH - 1, "full": DEPTH})
    fc.point("op", ["push", "push_full", "pop", "pop_empty"])
    legal = {("empty", "push"), ("one", "push"), ("mid", "push"), ("depth-1", "push"), ("full", "push_full"), ("one", "pop"), ("mid", "pop"),
             ("depth-1", "pop"), ("full", "pop"), ("empty", "pop_empty")}
    fc.cross("level_op", ["level", "op"], ignore=lambda c: c not in legal)
    pc = CoverGroup("mbox.doorbell", "pending flags x ring/ack operations")
    pc.point("dir", ["h2f", "f2h"])
    pc.point("op", ["ring", "ack"])
    pc.point("pend_before", [0, 1])
    pc.cross("dir_op_pend", ["dir", "op", "pend_before"])
    ac = CoverGroup("mbox.addr", "address boundaries")
    ac.point("addr", {"first_msg": 0x000, "last_h2f": 0x01C, "first_f2h": 0x020, "last_msg": 0x03C, "db_status": 0x040, "last_reg_diag_status": 0x08C,
                      "hole_below_diag": lambda a: 0x060 <= a < 0x080, "hole_above_diag": lambda a: 0x090 <= a < 0xFFC, "page_last_word": 0xFFC})
    rc = CoverGroup("mbox.reset", "reset while state is live")
    rc.point("live", ["fifo_nonempty", "h2f_pend", "f2h_pend", "ovf", "counts_nonzero"])
    cc = CoverGroup("mbox.count", "ring counters")
    cc.point("event", ["h2f_wrap", "f2h_wrap"])
    env.coverage += [tc, gc, fc, pc, ac, rc, cc]

    last = {"cyc": None}

    def hook(inp, exp, rst):
        if rst.get("sys"):
            return
        if inp["sel"]:
            a, we = inp["addr"], inp["we"]
            cls = addr_class(a)
            tc.sample(dir="write" if we else "read", kind=cls, result="refused" if exp["err"] else "ok")
            ac.sample(addr=a)
            if last["cyc"] is not None:
                gc.sample(gap=min(inp["_cycle"] - last["cyc"] - 1, 99))
            last["cyc"] = inp["_cycle"]
        else:
            gc.sample(idle_garbage_cycles=1)

    chk.hooks.append(hook)
    return env, rst, rb, sb, model, chk, (tc, fc, pc, ac, rc, cc)


class Probe:
    """Samples fifo/doorbell coverage from the model BEFORE each access takes effect."""

    def __init__(self, model, fc, pc, cc):
        self.m, self.fc, self.pc, self.cc = model, fc, pc, cc

    def pre(self, inp):
        m = self.m
        if not (inp["sel"] and inp["we"]):
            return
        a = inp["addr"]
        lvl = len(m.fifo)
        if a == A["DIAG_TX"]:
            self.fc.sample(level=lvl, op="push_full" if lvl >= DEPTH else "push")
        elif a == A["DIAG_POP"]:
            self.fc.sample(level=lvl, op="pop_empty" if lvl == 0 else "pop")
        elif a == A["H2F_RING"]:
            self.pc.sample(dir="h2f", op="ring", pend_before=m.h2f_pend)
            if m.h2f_cnt == 0xFFFF:
                self.cc.sample(event="h2f_wrap")
        elif a == A["F2H_RING"]:
            self.pc.sample(dir="f2h", op="ring", pend_before=m.f2h_pend)
            if m.f2h_cnt == 0xFFFF:
                self.cc.sample(event="f2h_wrap")
        elif a == A["H2F_ACK"]:
            self.pc.sample(dir="h2f", op="ack", pend_before=m.h2f_pend)
        elif a == A["F2H_ACK"]:
            self.pc.sample(dir="f2h", op="ack", pend_before=m.f2h_pend)


def attach_probe(chk, model, fc, pc, cc):
    """Wrap the model step so coverage sees the pre-access state."""
    probe = Probe(model, fc, pc, cc)
    orig = model.step

    def step(inp, resets):
        if not resets.get("sys"):
            probe.pre(inp)
        return orig(inp, resets)

    model.step = step


def reset_cover(rc, model):
    m = model
    for name, cond in (("fifo_nonempty", len(m.fifo) > 0), ("h2f_pend", m.h2f_pend), ("f2h_pend", m.f2h_pend), ("ovf", m.ovf),
                       ("counts_nonzero", m.h2f_cnt or m.f2h_cnt)):
        if cond:
            rc.sample(live=name)


async def go(dut, seed):
    env, rst, rb, sb, model, chk, (tc, fc, pc, ac, rc, cc) = build(dut, seed)
    attach_probe(chk, model, fc, pc, cc)
    await env.start()
    await env.until(lambda: not rst.asserted, 50, "reset release")
    return env, rst, rb, sb, model, chk, rc


async def drain(env, rb, n=200000, what="register ops"):
    await env.until(lambda: rb.idle, n, what)


# ============================================================================= tests


@cocotb.test()
async def reset_values(dut):
    """Every word of the page right after reset: documented registers read their reset value, holes are refused."""
    env, rst, rb, sb, model, chk, rc = await go(dut, SEED)
    queue_sweep(rb)
    await drain(env, rb)
    h = rb.history
    by = {op.addr: op for op in h}
    for i in range(8):
        for base in (0x000, 0x020):
            expect(sb, "msg word reset", 0, by[base + 4 * i].rdata, "0x%x" % (base + 4 * i))
            expect(sb, "msg word err", False, by[base + 4 * i].err)
    for nm in ("DB_STATUS", "H2F_CODE", "F2H_CODE", "RING_COUNT", "DIAG_RX", "DIAG_STATUS"):
        expect(sb, nm + " reset", 0, by[A[nm]].rdata)
        expect(sb, nm + " err", False, by[A[nm]].err)
    for nm in ("H2F_RING", "H2F_ACK", "F2H_RING", "F2H_ACK", "DIAG_TX", "DIAG_POP"):
        expect(sb, nm + " read of WO register refused", True, by[A[nm]].err)
    for a in (0x060, 0x07C, 0x090, 0x100, 0x800, 0xFFC):
        expect(sb, "hole refused", True, by[a].err, "0x%x" % a)
        expect(sb, "hole rdata 0", 0, by[a].rdata)
    expect(sb, "all words swept", 1024, len(h))
    expect(sb, "no pins after reset", (0, 0), (dut.irq_h2f.value.integer, dut.host_irq.value.integer))
    finish(env, sb, "reset_values", chk)


@cocotb.test()
async def doorbell_handshake(dut):
    """Ring / ack / pending / code latch / ring counters, both directions, with hand-computed expectations."""
    env, rst, rb, sb, model, chk, rc = await go(dut, SEED)

    async def rd(a):
        return (await rb.read(a)).rdata

    for d, ring, ack, cod, pin, bit in (("h2f", "H2F_RING", "H2F_ACK", "H2F_CODE", dut.irq_h2f, 0), ("f2h", "F2H_RING", "F2H_ACK", "F2H_CODE", dut.host_irq, 1)):
        expect(sb, d + " pending at start", 0, (await rd(A["DB_STATUS"])) >> bit & 1)
        await rb.write(A[ring], 0xCAFE0001)
        expect(sb, d + " pending after ring", 1, (await rd(A["DB_STATUS"])) >> bit & 1)
        expect(sb, d + " pin after ring", 1, pin.value.integer)
        expect(sb, d + " code latched", 0xCAFE0001, await rd(A[cod]))
        await rb.write(A[ring], 0x12345678)  # ring again while pending: stays pending, code updated, count 2
        expect(sb, d + " second ring code", 0x12345678, await rd(A[cod]))
        cnt = await rd(A["RING_COUNT"])
        expect(sb, d + " ring count", 2, (cnt >> (16 * bit)) & 0xFFFF)
        await rb.write(A[ack], 0xFFFFFFFF)
        expect(sb, d + " pending cleared by ack", 0, (await rd(A["DB_STATUS"])) >> bit & 1)
        expect(sb, d + " pin after ack", 0, pin.value.integer)
        expect(sb, d + " code kept after ack", 0x12345678, await rd(A[cod]))
        await rb.write(A[ack], 0)  # ack with nothing pending: harmless
        expect(sb, d + " idle ack", 0, (await rd(A["DB_STATUS"])) >> bit & 1)
    # independence of the two directions
    await rb.write(A["H2F_RING"], 1)
    expect(sb, "f2h unaffected by h2f ring", (1, 0), ((await rd(A["DB_STATUS"])) & 1, (await rd(A["DB_STATUS"])) >> 1 & 1))
    await rb.write(A["F2H_ACK"], 1)
    expect(sb, "h2f survives f2h ack", 1, (await rd(A["DB_STATUS"])) & 1)
    # message words: 32-bit storage, no side effects on neighbours
    for i in range(8):
        await rb.write(4 * i, 0x10000000 + i)
        await rb.write(0x20 + 4 * i, 0xF0000000 + i)
    for i in range(8):
        expect(sb, "h2f msg%d" % i, 0x10000000 + i, await rd(4 * i))
        expect(sb, "f2h msg%d" % i, 0xF0000000 + i, await rd(0x20 + 4 * i))
    # a ring/ack/diag write must not disturb the message words, and vice versa
    await rb.write(A["H2F_RING"], 0xFFFFFFFF)
    expect(sb, "msg untouched by ring", 0x10000000, await rd(0))
    finish(env, sb, "doorbell_handshake", chk)


@cocotb.test()
async def console_fifo(dut):
    """Fill to DEPTH, overflow, drain, wrap: first DEPTH characters kept, later ones dropped with OVF."""
    env, rst, rb, sb, model, chk, rc = await go(dut, SEED)

    async def rd(a):
        return (await rb.read(a)).rdata

    expect(sb, "empty", (0, 0), (await rd(A["DIAG_RX"]), await rd(A["DIAG_STATUS"])))
    await rb.write(A["DIAG_POP"], 0)  # pop of an empty FIFO: harmless, no underflow
    expect(sb, "level after empty pop", 0, await rd(A["DIAG_STATUS"]))
    chars = [(0x41 + 7 * i) & 0xFF for i in range(DEPTH + 5)]
    for i, c in enumerate(chars[:DEPTH]):
        await rb.write(A["DIAG_TX"], 0xABCD0000 | c)  # upper bits ignored
        if i == 0:
            expect(sb, "head after first char", 0x100 | c, await rd(A["DIAG_RX"]))
    st = await rd(A["DIAG_STATUS"])
    expect(sb, "full level, no OVF yet", DEPTH, st)
    for c in chars[DEPTH:]:  # dropped
        await rb.write(A["DIAG_TX"], c)
    st = await rd(A["DIAG_STATUS"])
    expect(sb, "level stays DEPTH, OVF set", 0x10000 | DEPTH, st)
    expect(sb, "head unchanged by overflow", 0x100 | chars[0], await rd(A["DIAG_RX"]))
    await rb.write(A["DIAG_STATUS"], 0x0000FFFF)  # bits other than [16] do not clear OVF and the level is RO
    expect(sb, "OVF survives a write without bit16", 0x10000 | DEPTH, await rd(A["DIAG_STATUS"]))
    await rb.write(A["DIAG_STATUS"], 0x00010000)
    expect(sb, "OVF cleared by W1C", DEPTH, await rd(A["DIAG_STATUS"]))
    for i in range(DEPTH):  # drain in order, DIAG_RX read has no side effect
        h1 = await rd(A["DIAG_RX"])
        h2 = await rd(A["DIAG_RX"])
        expect(sb, "head %d" % i, 0x100 | chars[i], h1)
        expect(sb, "read has no side effect", h1, h2)
        await rb.write(A["DIAG_POP"], 0xFFFFFFFF)
    expect(sb, "empty again, OVF clear", 0, await rd(A["DIAG_STATUS"]))
    expect(sb, "no head", 0, await rd(A["DIAG_RX"]))
    # pointer wrap: DEPTH+3 more through the FIFO one at a time
    for i in range(DEPTH + 3):
        await rb.write(A["DIAG_TX"], i & 0xFF)
        expect(sb, "wrap head", 0x100 | (i & 0xFF), await rd(A["DIAG_RX"]))
        await rb.write(A["DIAG_POP"], 0)
    expect(sb, "empty after wrap", 0, await rd(A["DIAG_STATUS"]))
    # pop and push when exactly full / one below full
    for i in range(DEPTH):
        await rb.write(A["DIAG_TX"], i)
    await rb.write(A["DIAG_POP"], 0)
    expect(sb, "level DEPTH-1", DEPTH - 1, await rd(A["DIAG_STATUS"]))
    await rb.write(A["DIAG_TX"], 0xEE)  # accepted: there is room again, no OVF
    expect(sb, "refilled to full without OVF", DEPTH, await rd(A["DIAG_STATUS"]))
    finish(env, sb, "console_fifo", chk)


@cocotb.test()
async def refused_accesses(dut):
    """Writes to RO / unmapped, reads of WO / unmapped: bus error and NO side effect (state compared before/after)."""
    env, rst, rb, sb, model, chk, rc = await go(dut, SEED)
    rng = env.seeds.child("refused")
    # give the page some state first
    await rb.write(A["H2F_RING"], 0x11)
    await rb.write(A["F2H_RING"], 0x22)
    for i in range(4):
        await rb.write(A["DIAG_TX"], 0x30 + i)
        await rb.write(4 * i, 0x1000 + i)
        await rb.write(0x20 + 4 * i, 0x2000 + i)
    before = {}
    for w in range(1024):
        before[w * 4] = rb.read_op(w * 4)
    await drain(env, rb)
    snap0 = {a: (o.rdata, o.err) for a, o in before.items()}
    ro = [A["DB_STATUS"], A["H2F_CODE"], A["F2H_CODE"], A["RING_COUNT"], A["DIAG_RX"]]
    holes = [a for a in range(0x040, 0x1000, 4) if MailboxModel.kind(a) == "none"]
    ops = []
    for _ in range(300):
        a = rng.choice(ro + holes)
        ops.append((a, rb.write_op(a, rng.getrandbits(32))))
    wo = [A["H2F_RING"], A["H2F_ACK"], A["F2H_RING"], A["F2H_ACK"], A["DIAG_TX"], A["DIAG_POP"]]
    for _ in range(100):
        a = rng.choice(wo + holes)
        ops.append((a, rb.read_op(a)))
    await drain(env, rb)
    for a, o in ops:
        expect(sb, "refused access error flag", True, o.err, "%s 0x%x" % ("write" if o.write else "read", a))
        if not o.write:
            expect(sb, "refused read returns 0", 0, o.rdata, "0x%x" % a)
    after = {}
    for w in range(1024):
        after[w * 4] = rb.read_op(w * 4)
    await drain(env, rb)
    snap1 = {a: (o.rdata, o.err) for a, o in after.items()}
    expect(sb, "no side effect from refused accesses", snap0, snap1)
    finish(env, sb, "refused_accesses", chk)


@cocotb.test()
async def unaligned_probe(dut):
    """Unaligned (addr[1:0] != 0) accesses are unmapped offsets (spec: refused).  The system never delivers them
    (the crossbar's alignment check refuses first); the register page itself is probed here."""
    env, rst, rb, sb, model, chk, rc = await go(dut, SEED)
    ops = []
    for base in (0x000, 0x004, 0x01C, 0x020, 0x03C, 0x040, 0x08C):
        for off in (1, 2, 3):
            ops.append(rb.write_op(base + off, 0xDEADBEEF))
            ops.append(rb.read_op(base + off))
    await drain(env, rb)
    for o in ops:
        expect(sb, "unaligned %s 0x%x refused" % ("write" if o.write else "read", o.addr), True, o.err)
    finish(env, sb, "unaligned_probe", chk)


@cocotb.test()
async def random_traffic(dut):
    """Seeded random register traffic over the whole 4 KiB page, compared cycle by cycle with the model."""
    env, rst, rb, sb, model, chk, rc = await go(dut, SEED)
    rng = env.seeds.child("traffic")
    n_ops = int(os.environ.get("CTL_OPS", "6000"))
    for phase in range(6):
        # phase profiles: console-heavy, doorbell-heavy, uniform, hole-heavy ...
        if phase == 0:
            regs = [(A["DIAG_TX"], ()), (A["DIAG_POP"], ()), (A["DIAG_RX"], ()), (A["DIAG_STATUS"], (0x10000,))]
            tr = RegTraffic(rng, regs, p_reg=0.95, p_hole=0.02, p_write=0.6)
            rb.gap.set_mode("always")
        elif phase == 1:
            regs = [(A[k], ()) for k in ("H2F_RING", "H2F_ACK", "F2H_RING", "F2H_ACK", "DB_STATUS", "H2F_CODE", "F2H_CODE", "RING_COUNT")]
            tr = RegTraffic(rng, regs, p_reg=0.95, p_hole=0.02, p_write=0.55)
            rb.gap.set_mode("random:0.5")
        elif phase == 2:
            tr = RegTraffic(rng, REGS, p_reg=0.85, p_hole=0.1, p_write=0.5)
            rb.gap.set_mode("always")
        elif phase == 3:
            tr = RegTraffic(rng, REGS, p_reg=0.3, p_hole=0.35, p_write=0.5)
            rb.gap.set_mode("bursty:1-6")
        elif phase == 4:
            regs = [(A["DIAG_TX"], ()), (A["DIAG_POP"], ()), (A["DIAG_STATUS"], (0x10000,)), (A["DIAG_RX"], ())]
            tr = RegTraffic(rng, regs, p_reg=0.99, p_hole=0.0, p_write=0.75)  # push-heavy: reaches full / OVF repeatedly
            rb.gap.set_mode("always")
        else:
            tr = RegTraffic(rng, REGS, p_reg=0.9, p_hole=0.05, p_write=0.5)
            rb.gap.set_mode("random:0.8")
        tr.queue(rb, n_ops // 6)
        await drain(env, rb)
    # final full sweep: whatever state we ended in must read back as the model says
    queue_sweep(rb)
    await drain(env, rb)
    expect(sb, "accesses compared", True, chk.n_access > n_ops)
    finish(env, sb, "random_traffic", chk)


@cocotb.test()
async def fifo_boundary_random(dut):
    """Random push/pop biased around empty and full: hits overflow, underflow and pointer wrap many times."""
    env, rst, rb, sb, model, chk, rc = await go(dut, SEED)
    rng = env.seeds.child("fifo")
    for rnd in range(8):
        bias_push = [0.9, 0.5, 0.1, 0.5, 0.75, 0.25, 0.95, 0.05][rnd]
        for _ in range(max(DEPTH * 3, 400)):
            if rng.random() < bias_push:
                rb.write_op(A["DIAG_TX"], rng.getrandbits(32))
            else:
                rb.write_op(A["DIAG_POP"], rng.getrandbits(32))
            if rng.random() < 0.1:
                rb.read_op(A["DIAG_RX"])
            if rng.random() < 0.05:
                rb.read_op(A["DIAG_STATUS"])
            if rng.random() < 0.02:
                rb.write_op(A["DIAG_STATUS"], rng.choice((0x10000, 0x0, 0xFFFF, 0x1FFFF)))
        await drain(env, rb)
    finish(env, sb, "fifo_boundary_random", chk)


@cocotb.test()
async def reset_traffic(dut):
    """Reset (synchronous pulses and asynchronous mid-cycle assertion) during random traffic: every register returns to
    its reset value, no stale pin; state built up before the reset must be gone."""
    env, rst, rb, sb, model, chk, rc = await go(dut, SEED)
    rng = env.seeds.child("rst")
    tr = RegTraffic(rng, REGS, p_reg=0.9, p_hole=0.05, p_write=0.6)
    for rnd in range(10):
        tr.queue(rb, 120 + rng.randrange(200))
        await env.until(lambda: len(rb.queue) < 20, 20000, "traffic running")
        if rnd in (3, 6):  # make sure the console is full and OVF set when the reset hits
            for _ in range(DEPTH + 2):
                rb.write_op(A["DIAG_TX"], 0x55)
            await drain(env, rb)  # all pushes done: the FIFO is full and OVF is set when the reset hits
        reset_cover(rc, model)
        n0 = rst.n_pulses
        if rnd % 2 == 0:
            rst.pulse(length=rng.randint(1, 3), delay=rng.randint(1, 4), reason="sync-reset-in-traffic")
        else:
            await env.tick()
            await async_reset_midcycle(env, rst, rng.choice((1.0, 2.0, 3.0, 4.0, 6.0, 7.0, 8.5)), rng.randint(1, 3))
        await env.until(lambda: rst.n_pulses > n0, 20, "reset asserted")
        await env.until(lambda: not rst.asserted, 20, "reset release")
        await env.cycles(2)
        # after a reset the page is back to reset values
        await env.until(lambda: rb.idle, 50, "rb idle after reset")
        for a in (A["DB_STATUS"], A["RING_COUNT"], A["H2F_CODE"], A["F2H_CODE"], A["DIAG_STATUS"], A["DIAG_RX"], 0x000, 0x01C, 0x020, 0x03C):
            o = await rb.read(a)
            expect(sb, "reset value of 0x%x after reset #%d" % (a, rnd), 0, o.rdata)
        expect(sb, "pins low after reset", (0, 0), (dut.irq_h2f.value.integer, dut.host_irq.value.integer))
    finish(env, sb, "reset_traffic", chk, resets=rst.n_pulses)


@cocotb.test()
async def ring_count_mid(dut):
    """RING_COUNT beyond 8 and 12 bits: 4 200 rings per direction, count read back at 255/256/257 and at the end."""
    env, rst, rb, sb, model, chk, rc = await go(dut, SEED)
    for i in range(4200):
        rb.write_op(A["H2F_RING"], i)
        rb.write_op(A["F2H_RING"], ~i & 0xFFFFFFFF)
        rb.write_op(A["H2F_ACK"] if i % 3 == 0 else A["F2H_ACK"], 0)
        if i in (254, 255, 256, 4094, 4095, 4096):
            o = rb.read_op(A["RING_COUNT"])
            rb.read_op(A["DB_STATUS"])
            await drain(env, rb)
            expect(sb, "H2F ring count after %d rings" % (i + 1), i + 1, o.rdata & 0xFFFF)
            expect(sb, "F2H ring count after %d rings" % (i + 1), i + 1, o.rdata >> 16)
        if len(rb.queue) > 400:
            await env.until(lambda: len(rb.queue) < 50, 5000, "feeding rings")
    await drain(env, rb)
    o = await rb.read(A["RING_COUNT"])
    expect(sb, "counts after 4200 rings", (4200, 4200), (o.rdata & 0xFFFF, o.rdata >> 16))
    finish(env, sb, "ring_count_mid", chk)


@cocotb.test()
async def ring_count_wrap(dut):
    """RING_COUNT is a pair of 16-bit wrapping counters: 65 541 rings of EACH kind, so both counters wrap (long test)."""
    env, rst, rb, sb, model, chk, rc = await go(dut, SEED)
    n = 65536 + 5
    for i in range(n):
        rb.write_op(A["H2F_RING"], i)
        rb.write_op(A["F2H_RING"], i ^ 0xFFFF)
        if i % 64 == 0:
            rb.write_op(A["H2F_ACK"], 0)
            rb.write_op(A["F2H_ACK"], 0)
        if i in (65534, 65535, 65536):
            o = rb.read_op(A["RING_COUNT"])
            await drain(env, rb)
            expect(sb, "both counters after %d rings" % (i + 1), ((i + 1) & 0xFFFF) * 0x10001, o.rdata)
        if len(rb.queue) > 500:
            await env.until(lambda: len(rb.queue) < 100, 5000, "feeding rings")
    await drain(env, rb)
    o = await rb.read(A["RING_COUNT"])
    expect(sb, "counters wrapped to 5", 0x00050005, o.rdata)
    finish(env, sb, "ring_count_wrap", chk)
