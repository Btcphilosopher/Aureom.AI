"""Boot image of the ControlCore bench: header builder (docs/03_BOOT.md section 3) + the assembled payload of ctl_fw.S.

The payload words below are the output of
    llvm-mc -triple=riscv32 -mattr=+m,+zicsr -filetype=obj ctl_fw.S -o fw.o
    ld.lld -m elf32lriscv -Ttext=0x10100 --oformat binary fw.o -o fw.bin
(tests/control/test_model_fw.py re-assembles ctl_fw.S when llvm-mc / ld.lld are installed and checks the words).
"""
import struct
import zlib

IMEM_BASE = 0x0001_0000
PAYLOAD_BASE = IMEM_BASE + 0x100
HDR_BYTES = 0x100
MAGIC = 0x4343_4653
FW_VERSION = 0x0102_0304

PAYLOAD = (
    0x00000297, 0x0b028293, 0x30529073, 0x40000437, 0x400014b7, 0x40005937,
    0x400109b7, 0x00600293, 0x02542823, 0x010202b7, 0x30428293, 0x02542e23,
    0x04c42283, 0x00128293, 0x04542623, 0x04042023, 0x04042223, 0x023342b7,
    0x56728293, 0x0254a023, 0x0004a823, 0x07f00293, 0x0054a223, 0x02000293,
    0x0059a223, 0x00400293, 0x0059a423, 0x00100293, 0x00b29293, 0x3042a073,
    0x30046073, 0x00900293, 0x02542823, 0x00700293, 0x02542c23, 0xf00dd2b7,
    0xcfe28293, 0x02592223, 0x00a00293, 0x04592623, 0x00a00293, 0x02542823,
    0x10500073, 0xffdff06f, 0x0084a283, 0x0c028a63, 0xfff28293, 0x04042303,
    0x000203b7, 0x10038393, 0x006383b3, 0x00538023, 0x00130313, 0x04642023,
    0x00100393, 0x005393b3, 0x04442e03, 0x007e6e33, 0x05c42223, 0x00c4ae03,
    0xfff3ce93, 0x01de7e33, 0x01c4a623, 0x00600e93, 0x03d28263, 0x00200e93,
    0x05d28063, 0x04028e63, 0x0044ae03, 0xfff3ce93, 0x01de7e33, 0x01c4a223,
    0xf91ff06f, 0x00092e03, 0x001e0e93, 0x03d92023, 0x05492f03, 0x03e92423,
    0x04092423, 0x04092003, 0x05d92623, 0xf6dff06f, 0x0009ae03, 0x03c92623,
    0x0009a223, 0x00010eb7, 0xfffe8e93, 0x01d9a023, 0x0009a003, 0xf4dff06f,
    0x0009ae03, 0x03c92823, 0x0009a423, 0x00010eb7, 0xfffe8e93, 0x01d9a023,
    0x0009a003, 0xf2dff06f, 0x30200073,
)


def crc32(data: bytes) -> int:
    """CRC-32 IEEE 802.3, reflected (the image CRC of docs/03_BOOT.md)."""
    return zlib.crc32(data) & 0xFFFF_FFFF


def make_image(payload=PAYLOAD, *, magic=MAGIC, version=1, size=None, entry=PAYLOAD_BASE, load=IMEM_BASE, crc=None, fw_version=FW_VERSION,
               flags=0, name=b"albion-bench-fw") -> bytes:
    """Header (0x100 bytes) + payload.  Every header field can be overridden to build a corrupted image."""
    body = b"".join(struct.pack("<I", w) for w in payload)
    if size is None:
        size = HDR_BYTES + len(body)
    if crc is None:
        crc = crc32(body)
    hdr = struct.pack("<8I", magic, version, size, entry, load, crc, fw_version, flags) + name.ljust(32, b"\0")[:32]
    hdr = hdr.ljust(HDR_BYTES, b"\0")
    return hdr + body


def image_words(img: bytes):
    return struct.unpack("<%dI" % (len(img) // 4), img)
