"""Subsystem E (ControlCore) suites.  DUT configuration names start with ``ctl_``.

Block benches (cc_*) use the register-bus agent of the framework and independent register-level models
(albionverify/models/ctl_*.py).  ``ctl_core`` boots the real silicaflux_control_core through its host port.
"""
from albionverify.sim.build import DutSpec
from albionverify.suite import Case, Suite

SPEC_REFS = (
    "controlcore/docs/MEMORY_MAP.md", "controlcore/docs/HW_SW_INTERFACE.md", "controlcore/docs/01_ARCHITECTURE.md",
    "controlcore/docs/03_BOOT.md", "controlcore/docs/04_INTERRUPTS.md", "controlcore/docs/05_ACCELERATORS.md",
    "controlcore/docs/07_VERIFICATION.md", "controlcore/docs/09_LIMITATIONS.md",
)

# ---------------------------------------------------------------------------------------------- mailbox
MBOX256 = DutSpec("ctl_mbox256", "cc_mailbox", params=(("DIAG_DEPTH", 256),))
MBOX8 = DutSpec("ctl_mbox8", "cc_mailbox", params=(("DIAG_DEPTH", 8),))
MB = "control.cocotb_mailbox"


def mbox_cases(dut, long_seeds=(1,)):
    return [
        Case(dut, MB, "reset_values", (1,), tags=("directed",)),
        Case(dut, MB, "doorbell_handshake", (1,), tags=("directed",)),
        Case(dut, MB, "console_fifo", (1,), tags=("directed", "long")),
        Case(dut, MB, "refused_accesses", (1, 2), tags=("directed", "error")),
        Case(dut, MB, "ring_count_mid", (1,), tags=("directed", "long")),
        Case(dut, MB, "random_traffic", (1, 2, 3, 4), tags=("random",)),
        Case(dut, MB, "fifo_boundary_random", (1, 2, 3), tags=("random", "long")),
        Case(dut, MB, "reset_traffic", (1, 2, 3), tags=("reset", "random")),
    ]


# ---------------------------------------------------------------------------------------------- sysctrl
SYSCTRL_DUT = DutSpec("ctl_sysctrl", "cc_sysctrl", params=(("FEATURES", 0x7F), ("ROM_BYTES", 0x2000), ("IMEM_BYTES", 0x10000), ("DMEM_BYTES", 0x8000)),
                      wrapper="tests/control/ctl_sysctrl_wrap.sv", wrapper_top="ctl_sysctrl_wrap",
                      extra_sources=("controlcore/third_party/silicaflux-v/rtl/common/sfv_common.sv",))
SC = "control.cocotb_sysctrl"

# ---------------------------------------------------------------------------------------------- pmu
PMU_DUT = DutSpec("ctl_pmu", "cc_pmu")
PM = "control.cocotb_pmu"

# ---------------------------------------------------------------------------------------------- ras
RAS_DUT = DutSpec("ctl_ras", "cc_ras")
RS = "control.cocotb_ras"

# ---------------------------------------------------------------------------------------------- perf
PERF20 = DutSpec("ctl_perf20", "cc_perf", params=(("NEV", 20), ("EDGE", (1 << 8) | (1 << 9) | (0x7F << 12))))  # EDGE as wired in the top level
PERF5 = DutSpec("ctl_perf5", "cc_perf", params=(("NEV", 5), ("EDGE", 0b10101)))
PF = "control.cocotb_perf"


def perf_cases(d):
    return [
        Case(d, PF, "reset_values", (1,), tags=("directed",)),
        Case(d, PF, "counting_directed", (1,), tags=("directed",)),
        Case(d, PF, "freeze_clear_directed", (1,), tags=("directed",)),
        Case(d, PF, "unaligned_probe", (1,), tags=("directed", "error")),
        Case(d, PF, "random_traffic", (1, 2, 3), tags=("random",)),
        Case(d, PF, "reset_traffic", (1, 2), tags=("reset", "random")),
    ]


# ---------------------------------------------------------------------------------------------- secmon
SEC_DUT = DutSpec("ctl_secmon", "cc_secmon")
SM = "control.cocotb_secmon"

# ---------------------------------------------------------------------------------------------- sfb gate
GATE_DUT = DutSpec("ctl_sfbgate", "cc_sfb_gate")
GT = "control.cocotb_sfbgate"

# ---------------------------------------------------------------------------------------------- core
CORE = DutSpec("ctl_core", "silicaflux_control_core")
CR = "control.cocotb_core"

SUITES = {
    "ctl_mailbox": Suite(
        name="ctl_mailbox", subsystem="control", title="ControlCore mailbox / doorbells / console FIFO (cc_mailbox)",
        cases=mbox_cases(MBOX256) + mbox_cases(MBOX8)[2:] + [
            Case(MBOX256, MB, "unaligned_probe", (1,), tags=("directed", "error", "known_defect:CTL-001")),
            Case(MBOX256, MB, "ring_count_wrap", (1,), tags=("long",), timeout=900),
        ],
        mutation_cases=[
            Case(MBOX256, MB, "reset_values", (1,)), Case(MBOX256, MB, "doorbell_handshake", (1,)),
            Case(MBOX8, MB, "console_fifo", (1,)), Case(MBOX256, MB, "console_fifo", (1,)), Case(MBOX256, MB, "refused_accesses", (1,)),
            Case(MBOX256, MB, "ring_count_mid", (1,)),
            Case(MBOX8, MB, "random_traffic", (1,)), Case(MBOX8, MB, "fifo_boundary_random", (1,)),
            Case(MBOX256, MB, "random_traffic", (2,)), Case(MBOX8, MB, "reset_traffic", (1,)),
            Case(MBOX256, MB, "ring_count_wrap", (1,), timeout=900),
        ],
        mutants_file="mutants/ctl_mailbox.yaml", spec_refs=SPEC_REFS,
        notes="Lockstep reference model (ctl_mailbox.py); DIAG_DEPTH 256 (spec) and 8 (fast wrap/overflow).",
    ),
    "ctl_sysctrl": Suite(
        name="ctl_sysctrl", subsystem="control", title="ControlCore SYSCTRL page, reset generator, POR/SYS domains (cc_sysctrl + reset chain)",
        cases=[
            Case(SYSCTRL_DUT, SC, "identity_reset_values", (1,), tags=("directed",)),
            Case(SYSCTRL_DUT, SC, "soft_reset_directed", (1,), tags=("directed", "reset")),
            Case(SYSCTRL_DUT, SC, "wdt_host_boot_mode_directed", (1,), tags=("directed", "reset")),
            Case(SYSCTRL_DUT, SC, "por_domain_directed", (1, 2), tags=("directed", "reset")),
            Case(SYSCTRL_DUT, SC, "status_pins_directed", (1,), tags=("directed",)),
            Case(SYSCTRL_DUT, SC, "unaligned_probe", (1,), tags=("directed", "error")),
            Case(SYSCTRL_DUT, SC, "random_traffic", (1, 2, 3, 4), tags=("random",)),
            Case(SYSCTRL_DUT, SC, "reset_traffic", (1, 2, 3), tags=("reset", "random")),
        ],
        mutation_cases=[
            Case(SYSCTRL_DUT, SC, "identity_reset_values", (1,)), Case(SYSCTRL_DUT, SC, "soft_reset_directed", (1,)),
            Case(SYSCTRL_DUT, SC, "wdt_host_boot_mode_directed", (1,)), Case(SYSCTRL_DUT, SC, "por_domain_directed", (1,)),
            Case(SYSCTRL_DUT, SC, "status_pins_directed", (1,)), Case(SYSCTRL_DUT, SC, "random_traffic", (1,)),
            Case(SYSCTRL_DUT, SC, "reset_traffic", (1,)),
        ],
        mutants_file="mutants/ctl_sysctrl.yaml", spec_refs=SPEC_REFS,
        notes="Wrapper replicates the top-level reset synchronisers; model includes the reset chain and the 2-flop input synchronisers.",
    ),
    "ctl_pmu": Suite(
        name="ctl_pmu", subsystem="control", title="ControlCore power management: accelerator clock gate / reset / isolation (cc_pmu)",
        cases=[
            Case(PMU_DUT, PM, "reset_values", (1,), tags=("directed",)),
            Case(PMU_DUT, PM, "acc_ctrl_fields", (1,), tags=("directed",)),
            Case(PMU_DUT, PM, "clock_gating_directed", (1,), tags=("directed",)),
            Case(PMU_DUT, PM, "reset_isolation_directed", (1,), tags=("directed", "reset")),
            Case(PMU_DUT, PM, "unaligned_probe", (1,), tags=("directed", "error")),
            Case(PMU_DUT, PM, "random_traffic", (1, 2, 3, 4), tags=("random",)),
            Case(PMU_DUT, PM, "reset_traffic", (1, 2, 3), tags=("reset", "random")),
            Case(PMU_DUT, PM, "counter_width", (1,), tags=("long",), timeout=900),
        ],
        mutation_cases=[
            Case(PMU_DUT, PM, "reset_values", (1,)), Case(PMU_DUT, PM, "acc_ctrl_fields", (1,)), Case(PMU_DUT, PM, "clock_gating_directed", (1,)),
            Case(PMU_DUT, PM, "reset_isolation_directed", (1,)), Case(PMU_DUT, PM, "random_traffic", (1,)), Case(PMU_DUT, PM, "reset_traffic", (1,)),
            Case(PMU_DUT, PM, "counter_width", (1,), timeout=900),
        ],
        mutants_file="mutants/ctl_pmu.yaml", spec_refs=SPEC_REFS,
        notes="Open-loop random + directed scenarios; saturation at 2^32-1 is not reachable in simulation (see plan).",
    ),
    "ctl_ras": Suite(
        name="ctl_ras", subsystem="control", title="ControlCore RAS: error capture, counters, severity, injection, parity controls (cc_ras)",
        cases=[
            Case(RAS_DUT, RS, "reset_values", (1,), tags=("directed",)),
            Case(RAS_DUT, RS, "pulse_sources_directed", (1,), tags=("directed",)),
            Case(RAS_DUT, RS, "level_sources_directed", (1,), tags=("directed",)),
            Case(RAS_DUT, RS, "sw_report_inject_directed", (1,), tags=("directed",)),
            Case(RAS_DUT, RS, "first_last_counters_directed", (1,), tags=("directed",)),
            Case(RAS_DUT, RS, "parity_controls_directed", (1,), tags=("directed",)),
            Case(RAS_DUT, RS, "level_at_reset_release", (1, 2), tags=("directed", "reset")),
            Case(RAS_DUT, RS, "unaligned_probe", (1,), tags=("directed", "error")),
            Case(RAS_DUT, RS, "random_traffic", (1, 2, 3, 4), tags=("random",)),
            Case(RAS_DUT, RS, "reset_traffic", (1, 2, 3), tags=("reset", "random")),
        ],
        mutation_cases=[
            Case(RAS_DUT, RS, "reset_values", (1,)), Case(RAS_DUT, RS, "pulse_sources_directed", (1,)), Case(RAS_DUT, RS, "level_sources_directed", (1,)),
            Case(RAS_DUT, RS, "sw_report_inject_directed", (1,)), Case(RAS_DUT, RS, "first_last_counters_directed", (1,)),
            Case(RAS_DUT, RS, "parity_controls_directed", (1,)), Case(RAS_DUT, RS, "level_at_reset_release", (1,)),
            Case(RAS_DUT, RS, "random_traffic", (1,)), Case(RAS_DUT, RS, "reset_traffic", (1,)),
        ],
        mutants_file="mutants/ctl_ras.yaml", spec_refs=SPEC_REFS,
        notes="Counter saturation at 2^32-1 cannot be reached in simulation (documented in the plan).",
    ),
    "ctl_perf": Suite(
        name="ctl_perf", subsystem="control", title="ControlCore performance counters (cc_perf), 20-event top-level config and a 5-event config",
        cases=perf_cases(PERF20) + perf_cases(PERF5) + [Case(PERF20, PF, "cycle_counter_wide", (1,), tags=("long",), timeout=900)],
        mutation_cases=[
            Case(PERF20, PF, "reset_values", (1,)), Case(PERF20, PF, "counting_directed", (1,)), Case(PERF20, PF, "freeze_clear_directed", (1,)),
            Case(PERF5, PF, "counting_directed", (1,)), Case(PERF5, PF, "freeze_clear_directed", (1,)),
            Case(PERF20, PF, "random_traffic", (1,)), Case(PERF5, PF, "random_traffic", (2,)), Case(PERF20, PF, "reset_traffic", (1,)),
            Case(PERF20, PF, "cycle_counter_wide", (1,), timeout=900),
        ],
        mutants_file="mutants/ctl_perf.yaml", spec_refs=SPEC_REFS,
        notes="32-bit saturation and CYCLE_HI carry need 2^32 cycles (not reachable); documented in the plan.",
    ),
    "ctl_secmon": Suite(
        name="ctl_secmon", subsystem="control", title="ControlCore security status: host write lock, write-once boot measure, violation log (cc_secmon)",
        cases=[
            Case(SEC_DUT, SM, "reset_values", (1,), tags=("directed",)),
            Case(SEC_DUT, SM, "lock_and_measure_directed", (1,), tags=("directed", "error")),
            Case(SEC_DUT, SM, "zero_measure_directed", (1,), tags=("directed",)),
            Case(SEC_DUT, SM, "violation_log_directed", (1,), tags=("directed",)),
            Case(SEC_DUT, SM, "unaligned_probe", (1,), tags=("directed", "error")),
            Case(SEC_DUT, SM, "random_traffic", (1, 2, 3, 4), tags=("random",)),
            Case(SEC_DUT, SM, "reset_traffic", (1, 2, 3), tags=("reset", "random")),
        ],
        mutation_cases=[
            Case(SEC_DUT, SM, "reset_values", (1,)), Case(SEC_DUT, SM, "lock_and_measure_directed", (1,)), Case(SEC_DUT, SM, "zero_measure_directed", (1,)),
            Case(SEC_DUT, SM, "violation_log_directed", (1,)), Case(SEC_DUT, SM, "random_traffic", (1,)), Case(SEC_DUT, SM, "reset_traffic", (1,)),
        ],
        mutants_file="mutants/ctl_secmon.yaml", spec_refs=SPEC_REFS,
        notes="VIOL_COUNT saturation (2^32-1) is not reachable in simulation.",
    ),
    "ctl_sfbgate": Suite(
        name="ctl_sfbgate", subsystem="control", title="ControlCore access-control gate (cc_sfb_gate): refuse / forward / isolation behaviour",
        cases=[
            Case(GATE_DUT, GT, "refuse_directed", (1,), tags=("directed", "error")),
            Case(GATE_DUT, GT, "forward_directed", (1,), tags=("directed",)),
            Case(GATE_DUT, GT, "refuse_rise_while_stalled", (1,), tags=("directed", "error")),
            Case(GATE_DUT, GT, "long_stalls", (1,), tags=("directed", "long")),
            Case(GATE_DUT, GT, "tagged_random", (1, 2, 3, 4), tags=("random", "error")),
            Case(GATE_DUT, GT, "free_refuse_random", (1, 2, 3, 4), tags=("random",)),
            Case(GATE_DUT, GT, "reset_traffic", (1, 2, 3), tags=("reset", "random")),
        ],
        mutation_cases=[
            Case(GATE_DUT, GT, "refuse_directed", (1,)), Case(GATE_DUT, GT, "forward_directed", (1,)), Case(GATE_DUT, GT, "refuse_rise_while_stalled", (1,)),
            Case(GATE_DUT, GT, "long_stalls", (1,)), Case(GATE_DUT, GT, "tagged_random", (1,)), Case(GATE_DUT, GT, "free_refuse_random", (1,)),
            Case(GATE_DUT, GT, "reset_traffic", (1,)),
        ],
        mutants_file="mutants/ctl_sfbgate.yaml", spec_refs=SPEC_REFS + ("datafabric/docs/datafabric/PROTOCOL.md",),
        notes="Access-control failures: refused requests must return errors and have no side effect (slave never sees them, memory compared).",
    ),
    "ctl_core": Suite(
        name="ctl_core", subsystem="control", title="ControlCore top level (silicaflux_control_core): boot ROM, host port, mailbox, interrupts, resets",
        cases=[
            Case(CORE, CR, "boot_handshake_irq", (1, 2), tags=("directed", "long"), timeout=2400),
            Case(CORE, CR, "host_access_control", (1, 2), tags=("directed", "error", "long"), timeout=2400),
            Case(CORE, CR, "bad_images", (1,), tags=("directed", "error", "long"), timeout=2400),
            Case(CORE, CR, "boot_mode_straps", (1,), tags=("directed",), timeout=1200),
            Case(CORE, CR, "reset_early", (1, 2), tags=("directed", "reset"), timeout=2400),
            Case(CORE, CR, "boot_ext", (1, 2), tags=("directed", "long"), timeout=3000),
            Case(CORE, CR, "boot_ext_fallback", (1,), tags=("directed", "error", "long"), timeout=3000),
            Case(CORE, CR, "boot_ext_fallback_empty", (1,), tags=("directed", "error", "long"), timeout=3000),
            Case(CORE, CR, "boot_ext_fallback_stale_header", (1,), tags=("directed", "error", "long"), timeout=3000),
            Case(CORE, CR, "warm_boot", (1,), tags=("directed", "reset", "long"), timeout=3600),
            Case(CORE, CR, "reset_boot_sequence", (1, 2), tags=("reset", "long"), timeout=3600),
        ],
        mutation_cases=[
            Case(CORE, CR, "boot_mode_straps", (1,), timeout=1200), Case(CORE, CR, "reset_early", (1,), timeout=2400),
            Case(CORE, CR, "host_access_control", (1,), timeout=2400), Case(CORE, CR, "boot_handshake_irq", (1,), timeout=2400),
        ],
        mutants_file="mutants/ctl_core.yaml", spec_refs=SPEC_REFS,
    ),
    "ctl_core_fast": Suite(
        name="ctl_core_fast", subsystem="control", title="ControlCore top level: fast subset of ctl_core (reproducibility / smoke); the four cases used for the core mutation campaign",
        cases=[
            Case(CORE, CR, "boot_mode_straps", (1,), tags=("directed",), timeout=1200),
            Case(CORE, CR, "reset_early", (1,), tags=("directed", "reset"), timeout=2400),
            Case(CORE, CR, "host_access_control", (1,), tags=("directed", "error", "long"), timeout=2400),
            Case(CORE, CR, "boot_handshake_irq", (1,), tags=("directed", "long"), timeout=2400),
        ],
        spec_refs=SPEC_REFS,
        notes="Same DUT config and cases as the core mutation set; exists so that `determinism --suite ctl_core_fast` is affordable (the full ctl_core suite runs 16 boots).",
    ),
}
