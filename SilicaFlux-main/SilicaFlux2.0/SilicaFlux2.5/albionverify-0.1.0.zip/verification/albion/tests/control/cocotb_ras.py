"""cc_ras bench: error capture (STATUS W1C, counters, FIRST/LAST capture), interrupt / pin outputs, injection, SW_REPORT, parity controls.

Reference model: albionverify/models/ctl_ras.py (from MEMORY_MAP.md, 04_INTERRUPTS.md, 09_LIMITATIONS.md, HW_SW_INTERFACE.md).
"""
import os

import cocotb

from albionverify.bus.regbus import RegBusMaster
from albionverify.core import Env
from albionverify.coverage import CoverGroup
from albionverify.models import ctl_spec as S
from albionverify.models.ctl_ras import KIND, RasModel
from albionverify.reset import ResetSequencer
from albionverify.scoreboard import Scoreboard

from control.ctl_bench import (BlockChecker, PinDriver, RegTraffic, async_reset_midcycle, expect, finish, gap_cover, queue_sweep, txn_cover)

A = S.RAS
SRC = S.RAS_SRC
SEED = int(os.environ.get("ALBION_SEED", "1"))
PULSES = ("ev_bus_decode", "ev_periph_err", "ev_dma_err", "ev_host_viol", "ev_iso_access", "ev_parity")
ADDRS = ("ev_bus_decode_addr", "ev_periph_err_addr", "ev_host_viol_addr", "ev_parity_addr")
LEVELS = ("lv_ext_warn", "lv_ext_fatal", "lv_tsu_halted")
PULSE_OF = {"BUS_DECODE": ("ev_bus_decode", "ev_bus_decode_addr"), "PERIPH_ERR": ("ev_periph_err", "ev_periph_err_addr"), "DMA_ERR": ("ev_dma_err", None),
            "HOST_VIOL": ("ev_host_viol", "ev_host_viol_addr"), "ISO_ACCESS": ("ev_iso_access", None), "MEM_PARITY": ("ev_parity", "ev_parity_addr")}
REGS = [(A["STATUS"], (0xFFFF, 0xFF, 0xFF00, 1, 2, 4, 8, 0x10, 0x20, 0x40, 0x100, 0x200, 0x400, 0x800)),
        (A["WARN_EN"], (0xFF, 0x7F, 0, 0x01, 0x20)), (A["FATAL_EN"], (0xFF, 0x0F, 0, 0x01, 0x02)),
        (A["WARN_COUNT"], ()), (A["FATAL_COUNT"], ()), (A["FIRST_SRC"], ()), (A["FIRST_ADDR"], ()), (A["LAST_SRC"], ()), (A["LAST_ADDR"], ()),
        (A["INJECT"], (0x0001, 0x0002, 0x0004, 0x0008, 0x0010, 0x0020, 0x0040, 0x0080, 0x0100, 0x0200, 0x0400, 0x0800, 0xF000, 0x0F7F, 0xFFFF, 0)),
        (A["SW_REPORT"], (0, 0x80000000, 0x7FFFFFFF, 0xFFFFFFFF, 0x1234, 0x80001234)), (A["SW_CODE"], ()),
        (A["CTRL"], (0, 1, 2, 3, 4, 8, 0xC, 0xF, 5, 6)), (A["PAR_INJECT"], (0, 1)), (A["PAR_CHK_EN"], (0, 1)), (A["RAW"], ())]


def kind_of(a):
    k = KIND.get(a) if not a & 3 else None
    return k or "unmapped"


def build(dut, seed):
    env = Env(dut, name="ras", seed=seed)
    rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=4))
    rb = env.add(RegBusMaster("rb", env, rng=env.seeds.child("rb")))
    pinmap = {k: (env.sig(k), 1) for k in PULSES + LEVELS + ("mem_write",)}
    pinmap.update({k: (env.sig(k), 32) for k in ADDRS})
    pins = env.add(PinDriver("pins", env.seeds.child("pins"), pinmap))
    for k in ADDRS:
        pins.set(k, "noise")
    sb = Scoreboard(env, "ras")
    model = RasModel()
    rstn = env.sig("rst_n")
    ins = {"sel": env.sig("rb_sel"), "we": env.sig("rb_we"), "addr": env.sig("rb_addr"), "wdata": env.sig("rb_wdata")}
    ins.update({k: env.sig(k) for k in pinmap})
    chk = env.add(BlockChecker(
        "chk", model, sb, ins={**ins, **{}},
        outs={"rdata": env.sig("rb_rdata"), "err": env.sig("rb_err"), "irq_warn": env.sig("irq_warn"), "irq_fatal": env.sig("irq_fatal"),
              "fatal_pin": env.sig("fatal_pin"), "fatal_iso": env.sig("fatal_iso"), "par_inject": env.sig("par_inject"), "par_chk_en": env.sig("par_chk_en")},
        resets=lambda: {"sys": rstn.read() == 0}))
    # ---- coverage
    tc = txn_cover("ras", {"ro": ("ok", "refused"), "wo": ("refused", "ok"), "rw": ("ok", "ok"), "unmapped": ("refused", "refused")})
    ec = CoverGroup("ras.events", "event sources and capture scenarios")
    ec.point("source", list(SRC))
    ec.point("scenario", ["first_event", "later_event", "multi_event_same_cycle", "event_with_w1c_same_cycle", "event_with_clear_first", "injected", "level_rise", "level_held"])
    ec.point("class", ["warn", "fatal"])
    ic = CoverGroup("ras.irq", "interrupt / pin outputs")
    ic.point("out", ["irq_warn", "irq_fatal", "fatal_pin", "fatal_iso"])
    ic.point("val", [0, 1])
    ic.cross("out_val", ["out", "val"])
    mc = CoverGroup("ras.mask", "status x enable (interrupt gating)")
    mc.point("warn_status_enable", ["status0_en0", "status1_en0", "status0_en1", "status1_en1"])
    mc.point("fatal_status_enable", ["status0_en0", "status1_en0", "status0_en1", "status1_en1"])
    pc = CoverGroup("ras.misc", "control / parity / counters")
    pc.point("op", ["clear_first", "clear_counts", "par_inject_arm", "par_inject_self_clear", "par_arm_vs_mem_write_same_cycle", "sw_warn", "sw_fatal", "inject", "w1c", "chk_en"])
    ac = CoverGroup("ras.addr", "address boundaries")
    ac.point("addr", {"first": 0x000, "last_reg": 0x03C, "hole_gap": lambda a: 0x040 <= a < 0xFFC, "page_last_word": 0xFFC})
    env.coverage += [tc, ec, ic, mc, pc, ac, gap_cover("ras")]
    seen = {"pinj": 0}

    def hook(inp, exp, rst):
        pre_pinj = seen["pinj"]
        seen["pinj"] = model.pinj
        if rst.get("sys"):
            return
        a = inp["addr"]
        if inp["sel"]:
            tc.sample(dir="write" if inp["we"] else "read", kind=kind_of(a), result="refused" if exp["err"] else "ok")
            ac.sample(addr=a)
            if inp["we"] and not exp["err"]:
                if a == A["CTRL"]:
                    if inp["wdata"] & 4:
                        pc.sample(op="clear_first")
                    if inp["wdata"] & 8:
                        pc.sample(op="clear_counts")
                elif a == A["PAR_INJECT"] and inp["wdata"] & 1:
                    pc.sample(op="par_inject_arm")
                    if inp["mem_write"]:
                        pc.sample(op="par_arm_vs_mem_write_same_cycle")
                elif a == A["SW_REPORT"]:
                    pc.sample(op="sw_fatal" if inp["wdata"] >> 31 else "sw_warn")
                elif a == A["INJECT"]:
                    pc.sample(op="inject")
                elif a == A["STATUS"]:
                    pc.sample(op="w1c")
                elif a == A["PAR_CHK_EN"]:
                    pc.sample(op="chk_en")
        for nm in ("irq_warn", "irq_fatal", "fatal_pin", "fatal_iso"):
            ic.sample(out=nm, val=exp[nm])
        m = model
        mc.sample(warn_status_enable="status%d_en%d" % (int((m.st & 0xFF) != 0), int(m.wen != 0)))
        mc.sample(fatal_status_enable="status%d_en%d" % (int(((m.st >> 8) & 0xFF) != 0), int(m.fen != 0)))
        if pre_pinj and inp["mem_write"] and not (inp["sel"] and inp["we"] and a == A["PAR_INJECT"]):
            pc.sample(op="par_inject_self_clear")
        events, real = m.last_events, m.last_real
        if events:
            n = bin(events).count("1")
            for s_name, s in SRC.items():
                if (events >> s) & 1:
                    ec.sample(source=s_name, **{"class": "warn" if s < 8 else "fatal"})
                    ec.sample(scenario="injected" if not (real >> s) & 1 else "level_rise" if s in (SRC["EXT_WARN"], SRC["EXT_FATAL"], SRC["TSU_HALTED"]) else "first_event")
            if n > 1:
                ec.sample(scenario="multi_event_same_cycle")
            if inp["sel"] and inp["we"] and a == A["STATUS"] and inp["wdata"] & 0xFFFF:
                ec.sample(scenario="event_with_w1c_same_cycle")
            if inp["sel"] and inp["we"] and a == A["CTRL"] and inp["wdata"] & 4:
                ec.sample(scenario="event_with_clear_first")
            if m.first_v:
                ec.sample(scenario="later_event")
        if m.st & (1 << SRC["EXT_WARN"]) and inp["lv_ext_warn"] and m.lv_prev & 1:
            ec.sample(scenario="level_held")

    chk.hooks.append(hook)
    return env, rst, rb, pins, sb, model, chk


async def go(dut, seed):
    env, rst, rb, pins, sb, model, chk = build(dut, seed)
    await env.start()
    await env.until(lambda: not rst.asserted, 50, "reset release")
    return env, rst, rb, pins, sb, model, chk


async def drain(env, rb, n=200000):
    await env.until(lambda: rb.idle, n, "register ops")


async def pulse(env, pins, name, addr_pin=None, addr=0, n=1, settle=4):
    """Drive a one-cycle (n-cycle) event input with a known address, then garbage on the address bus."""
    pins.force(name, 1)
    if addr_pin:
        pins.force(addr_pin, addr)
    await env.cycles(n)
    pins.force(name, 0)
    if addr_pin:
        pins.set(addr_pin, "noise")
    await env.cycles(settle)


# ============================================================================= tests


@cocotb.test()
async def reset_values(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)
    queue_sweep(rb)
    await drain(env, rb)
    by = {op.addr: op for op in rb.history}
    for nm in ("STATUS", "WARN_EN", "FATAL_EN", "WARN_COUNT", "FATAL_COUNT", "FIRST_SRC", "FIRST_ADDR", "LAST_SRC", "LAST_ADDR", "SW_CODE", "PAR_INJECT", "PAR_CHK_EN", "RAW"):
        expect(sb, nm + " reset value", 0, by[A[nm]].rdata)
        expect(sb, nm + " err", False, by[A[nm]].err)
    expect(sb, "CTRL reset value (FATAL_TO_HOST = 1)", 1, by[A["CTRL"]].rdata)
    for nm in ("INJECT", "SW_REPORT"):
        expect(sb, nm + " read of WO register refused", True, by[A[nm]].err)
    for a in (0x040, 0x044, 0x100, 0x800, 0xFFC):
        expect(sb, "hole refused", (True, 0), (by[a].err, by[a].rdata), "0x%x" % a)
    ops = [rb.write_op(A[n], 0xFFFFFFFF) for n in ("WARN_COUNT", "FATAL_COUNT", "FIRST_SRC", "FIRST_ADDR", "LAST_SRC", "LAST_ADDR", "SW_CODE", "RAW")] + [rb.write_op(0x040, 1)]
    await drain(env, rb)
    for o in ops:
        expect(sb, "write to RO / hole refused", True, o.err, "0x%x" % o.addr)
    expect(sb, "pins low at reset", (0, 0, 0, 0, 0, 0), tuple(getattr(dut, n).value.integer for n in ("irq_warn", "irq_fatal", "fatal_pin", "fatal_iso", "par_inject", "par_chk_en")))
    finish(env, sb, "reset_values", chk)


@cocotb.test()
async def pulse_sources_directed(dut):
    """Every event pulse: STATUS bit (sticky), class counter, FIRST / LAST capture with the source address, interrupt gating, W1C."""
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)

    async def rd(a):
        return (await rb.read(a)).rdata

    await rb.write(A["WARN_EN"], 0)
    await rb.write(A["FATAL_EN"], 0)
    seq = [("BUS_DECODE", 0x2000_0004), ("PERIPH_ERR", 0x4000_0030), ("DMA_ERR", None), ("HOST_VIOL", 0x0001_0000), ("ISO_ACCESS", None), ("MEM_PARITY", 0x0002_0FFC)]
    wcnt = fcnt = 0
    for i, (nm, addr) in enumerate(seq):
        pin, apin = PULSE_OF[nm]
        await pulse(env, pins, pin, apin, addr or 0)
        bit = SRC[nm]
        if bit < 8:
            wcnt += 1
        else:
            fcnt += 1
        st = await rd(A["STATUS"])
        expect(sb, nm + " sets its STATUS bit", 1, st >> bit & 1)
        expect(sb, nm + " counts once", (wcnt, fcnt), (await rd(A["WARN_COUNT"]), await rd(A["FATAL_COUNT"])))
        expect(sb, nm + " LAST_SRC", 0x80000000 | bit, await rd(A["LAST_SRC"]))
        expect(sb, nm + " LAST_ADDR", addr or 0, await rd(A["LAST_ADDR"]))
        if i == 0:
            expect(sb, "FIRST_SRC = first event", 0x80000000 | bit, await rd(A["FIRST_SRC"]))
            expect(sb, "FIRST_ADDR = first event address", addr, await rd(A["FIRST_ADDR"]))
        else:
            expect(sb, "FIRST_SRC stays on the first event", 0x80000000 | SRC["BUS_DECODE"], await rd(A["FIRST_SRC"]))
            expect(sb, "FIRST_ADDR stays", 0x2000_0004, await rd(A["FIRST_ADDR"]))
    expect(sb, "STATUS holds all six sources (sticky)", 0x11F, await rd(A["STATUS"]))
    expect(sb, "no interrupt: sources masked", (0, 0), (dut.irq_warn.value.integer, dut.irq_fatal.value.integer))
    expect(sb, "fatal pin raised by the parity error (FATAL_TO_HOST = 1)", 1, dut.fatal_pin.value.integer)
    expect(sb, "fatal_iso low (FATAL_ISOLATE = 0)", 0, dut.fatal_iso.value.integer)
    # interrupt gating by WARN_EN / FATAL_EN
    await rb.write(A["WARN_EN"], 0x20)  # EXT_WARN only: not set -> no irq
    await env.cycles(2)
    expect(sb, "enable of an inactive source gives no irq", 0, dut.irq_warn.value.integer)
    await rb.write(A["WARN_EN"], 0x02)
    await env.cycles(2)
    expect(sb, "PERIPH_ERR enabled -> irq_warn", 1, dut.irq_warn.value.integer)
    await rb.write(A["FATAL_EN"], 0x01)  # MEM_PARITY
    await env.cycles(2)
    expect(sb, "MEM_PARITY enabled -> irq_fatal", 1, dut.irq_fatal.value.integer)
    # W1C of exactly the written bits
    await rb.write(A["STATUS"], 0x0002)
    expect(sb, "W1C clears only PERIPH_ERR", 0x11D, await rd(A["STATUS"]))
    await env.cycles(1)
    expect(sb, "irq_warn follows the cleared bit", 0, dut.irq_warn.value.integer)
    await rb.write(A["STATUS"], 0xFFFF)
    expect(sb, "W1C all", 0, await rd(A["STATUS"]))
    await env.cycles(2)
    expect(sb, "irqs and fatal pin drop with the status", (0, 0, 0), (dut.irq_warn.value.integer, dut.irq_fatal.value.integer, dut.fatal_pin.value.integer))
    expect(sb, "counters survive W1C", (5, 1), (await rd(A["WARN_COUNT"]), await rd(A["FATAL_COUNT"])))
    finish(env, sb, "pulse_sources_directed", chk)


@cocotb.test()
async def level_sources_directed(dut):
    """Level sources: STATUS re-set while active, count = rising edges, RAW live, severity classes, pins."""
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)

    async def rd(a):
        return (await rb.read(a)).rdata

    await rb.write(A["WARN_EN"], 0xFF)
    await rb.write(A["FATAL_EN"], 0xFF)
    pins.force("lv_ext_warn", 1)
    await env.cycles(6)
    expect(sb, "EXT_WARN sets STATUS[5]", 0x20, await rd(A["STATUS"]))
    expect(sb, "RAW shows the live level", 0x1, await rd(A["RAW"]))
    expect(sb, "irq_warn", 1, dut.irq_warn.value.integer)
    await rb.write(A["STATUS"], 0x20)  # W1C while the level is still active: re-set at once
    await env.cycles(1)
    expect(sb, "level source re-sets while active", 0x20, await rd(A["STATUS"]))
    expect(sb, "level counts one event (rising edge), not one per cycle", 1, await rd(A["WARN_COUNT"]))
    pins.force("lv_ext_warn", 0)
    await env.cycles(3)
    expect(sb, "STATUS stays (sticky) after the level drops", 0x20, await rd(A["STATUS"]))
    expect(sb, "RAW follows the level", 0, await rd(A["RAW"]))
    await rb.write(A["STATUS"], 0x20)
    expect(sb, "W1C works once the level is low", 0, await rd(A["STATUS"]))
    await env.cycles(1)
    expect(sb, "irq_warn drops", 0, dut.irq_warn.value.integer)
    for _ in range(3):  # three more rising edges
        pins.force("lv_ext_warn", 1)
        await env.cycles(2)
        pins.force("lv_ext_warn", 0)
        await env.cycles(2)
    expect(sb, "four rising edges counted", 4, await rd(A["WARN_COUNT"]))
    # fatal-class levels
    pins.force("lv_ext_fatal", 1)
    await env.cycles(4)
    expect(sb, "EXT_FATAL sets STATUS[10] (EXT_WARN is still sticky)", 0x420, await rd(A["STATUS"]))
    expect(sb, "fatal pin + irq_fatal", (1, 1), (dut.fatal_pin.value.integer, dut.irq_fatal.value.integer))
    pins.force("lv_tsu_halted", 1)
    await env.cycles(4)
    expect(sb, "RAW both fatal levels", 0x6, await rd(A["RAW"]))
    expect(sb, "FATAL_COUNT counts both rising edges", 2, await rd(A["FATAL_COUNT"]))
    expect(sb, "TSU_HALTED sets STATUS[9]", 0x600, await rd(A["STATUS"]) & 0xF00)
    # FATAL_ISOLATE
    await rb.write(A["CTRL"], 0x3)
    await env.cycles(1)
    expect(sb, "FATAL_ISOLATE drives fatal_iso", (1, 1), (dut.fatal_iso.value.integer, dut.fatal_pin.value.integer))
    await rb.write(A["CTRL"], 0x2)
    await env.cycles(1)
    expect(sb, "FATAL_TO_HOST clear drops the pin only", (1, 0), (dut.fatal_iso.value.integer, dut.fatal_pin.value.integer))
    pins.force("lv_ext_fatal", 0)
    pins.force("lv_tsu_halted", 0)
    await env.cycles(3)
    await rb.write(A["STATUS"], 0xFFFF)
    await env.cycles(2)
    expect(sb, "everything clears once the causes are gone", (0, 0, 0, 0), (dut.irq_warn.value.integer, dut.irq_fatal.value.integer, dut.fatal_pin.value.integer, dut.fatal_iso.value.integer))
    # an active level present at reset release counts as a rising edge (lv_q resets to 0)
    finish(env, sb, "level_sources_directed", chk)


@cocotb.test()
async def sw_report_inject_directed(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)

    async def rd(a):
        return (await rb.read(a)).rdata

    await rb.write(A["SW_REPORT"], 0x0000_1234)  # warning
    expect(sb, "SW_REPORT warning -> SW_WARN (STATUS[6])", 0x40, await rd(A["STATUS"]))
    expect(sb, "SW_CODE", 0x1234, await rd(A["SW_CODE"]))
    expect(sb, "capture carries the code", (0x80000006, 0x1234), (await rd(A["FIRST_SRC"]), await rd(A["FIRST_ADDR"])))
    await rb.write(A["SW_REPORT"], 0x8000_5678)  # fatal
    expect(sb, "SW_REPORT fatal -> SW_FATAL (STATUS[11])", 0x840, await rd(A["STATUS"]))
    expect(sb, "SW_CODE 31 bits", 0x5678, await rd(A["SW_CODE"]))
    expect(sb, "LAST = SW_FATAL with code", (0x8000000B, 0x5678), (await rd(A["LAST_SRC"]), await rd(A["LAST_ADDR"])))
    expect(sb, "counts", (1, 1), (await rd(A["WARN_COUNT"]), await rd(A["FATAL_COUNT"])))
    await rb.write(A["SW_REPORT"], 0x7FFF_FFFF)
    expect(sb, "31-bit code", 0x7FFF_FFFF, await rd(A["SW_CODE"]))
    await rb.write(A["STATUS"], 0xFFFF)
    # INJECT: each defined source can be raised; bit 7 and [15:12] raise nothing
    cnt = (await rd(A["WARN_COUNT"]), await rd(A["FATAL_COUNT"]))
    for bit in list(range(7)) + [8, 9, 10, 11]:
        await rb.write(A["INJECT"], 1 << bit)
        expect(sb, "INJECT raises source %d" % bit, 1 << bit, await rd(A["STATUS"]) & (1 << bit))
        await rb.write(A["STATUS"], 0xFFFF)
    for bit in (7, 12, 13, 14, 15):
        await rb.write(A["INJECT"], 1 << bit)
        expect(sb, "INJECT bit %d raises nothing" % bit, 0, await rd(A["STATUS"]))
    cnt2 = (await rd(A["WARN_COUNT"]), await rd(A["FATAL_COUNT"]))
    expect(sb, "injections are counted as events (7 warn-class, 4 fatal-class)", (cnt[0] + 7, cnt[1] + 4), cnt2)
    await rb.write(A["INJECT"], 0xFFFF)
    expect(sb, "inject all defined sources at once", 0x0F7F, await rd(A["STATUS"]))
    finish(env, sb, "sw_report_inject_directed", chk)


@cocotb.test()
async def first_last_counters_directed(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)

    async def rd(a):
        return (await rb.read(a)).rdata

    await pulse(env, pins, "ev_periph_err", "ev_periph_err_addr", 0x4000_5044)
    await pulse(env, pins, "ev_bus_decode", "ev_bus_decode_addr", 0xDEAD_BEE0)
    expect(sb, "FIRST stays on the first event", (0x80000001, 0x4000_5044), (await rd(A["FIRST_SRC"]), await rd(A["FIRST_ADDR"])))
    expect(sb, "LAST follows the most recent", (0x80000000, 0xDEAD_BEE0), (await rd(A["LAST_SRC"]), await rd(A["LAST_ADDR"])))
    # CLEAR_FIRST pulse bit: reads back 0, drops VALID, next event becomes FIRST
    await rb.write(A["CTRL"], 0x1 | 0x4)
    expect(sb, "CTRL pulse bits read back 0", 0x1, await rd(A["CTRL"]))
    expect(sb, "FIRST VALID dropped", 0, await rd(A["FIRST_SRC"]) >> 31)
    expect(sb, "LAST untouched", 0x80000000, await rd(A["LAST_SRC"]))
    await pulse(env, pins, "ev_host_viol", "ev_host_viol_addr", 0x0002_0000)
    expect(sb, "new first event", (0x80000003, 0x0002_0000), (await rd(A["FIRST_SRC"]), await rd(A["FIRST_ADDR"])))
    # several events in one cycle: lowest source = first, highest = last (A-7)
    await rb.write(A["CTRL"], 0x1 | 0x4)
    for p in ("ev_dma_err", "ev_iso_access", "ev_parity"):
        pins.force(p, 1)
    pins.force("ev_parity_addr", 0xABCD_0000)
    await env.cycles(1)
    for p in ("ev_dma_err", "ev_iso_access", "ev_parity"):
        pins.force(p, 0)
    pins.set("ev_parity_addr", "noise")
    await env.cycles(4)
    expect(sb, "three events in one cycle: lowest source is FIRST", 0x80000002, await rd(A["FIRST_SRC"]))
    expect(sb, "...highest is LAST", (0x80000008, 0xABCD_0000), (await rd(A["LAST_SRC"]), await rd(A["LAST_ADDR"])))
    expect(sb, "each source counted once in that cycle", (2, 1), (await rd(A["WARN_COUNT"]) - 3, await rd(A["FATAL_COUNT"])))
    # CLEAR_COUNTS
    await rb.write(A["CTRL"], 0x1 | 0x8)
    expect(sb, "CLEAR_COUNTS zeroes both counters", (0, 0), (await rd(A["WARN_COUNT"]), await rd(A["FATAL_COUNT"])))
    expect(sb, "STATUS untouched by CLEAR_COUNTS", 0x114, await rd(A["STATUS"]) & 0x114)
    # event and CLEAR_FIRST in the same cycle: the event is the new first one
    await env.tick()
    pins.force("ev_bus_decode", 1)
    pins.force("ev_bus_decode_addr", 0x1111_0000)
    rb.write_op(A["CTRL"], 0x1 | 0x4)
    await env.tick()
    pins.force("ev_bus_decode", 0)
    pins.set("ev_bus_decode_addr", "noise")
    await env.cycles(4)
    expect(sb, "event in the CLEAR_FIRST cycle becomes FIRST", (0x80000000, 0x1111_0000), (await rd(A["FIRST_SRC"]), await rd(A["FIRST_ADDR"])))
    # event and W1C of the same bit in the same cycle: the event survives
    await rb.write(A["STATUS"], 0xFFFF)
    await env.tick()
    pins.force("ev_dma_err", 1)
    rb.write_op(A["STATUS"], 0xFFFF)
    await env.tick()
    pins.force("ev_dma_err", 0)
    await env.cycles(4)
    expect(sb, "new event wins over a same-cycle W1C", 0x4, await rd(A["STATUS"]))
    finish(env, sb, "first_last_counters_directed", chk)


@cocotb.test()
async def parity_controls_directed(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)

    async def rd(a):
        return (await rb.read(a)).rdata

    expect(sb, "PAR_CHK_EN pin low at reset", 0, dut.par_chk_en.value.integer)
    await rb.write(A["PAR_CHK_EN"], 0xFFFFFFFF)
    expect(sb, "PAR_CHK_EN [0] only", 1, await rd(A["PAR_CHK_EN"]))
    await env.tick()
    expect(sb, "par_chk_en pin", 1, dut.par_chk_en.value.integer)
    await rb.write(A["PAR_CHK_EN"], 0xFFFFFFFE)
    expect(sb, "par_chk_en cleared", 0, await rd(A["PAR_CHK_EN"]))
    await rb.write(A["PAR_INJECT"], 1)
    await env.tick()
    expect(sb, "par_inject armed (pin and register)", (1, 1), (dut.par_inject.value.integer, await rd(A["PAR_INJECT"])))
    await env.cycles(5)
    expect(sb, "stays armed without a memory write", 1, dut.par_inject.value.integer)
    await pulse(env, pins, "mem_write")
    expect(sb, "self-clears on the next accepted IMEM/DMEM write", (0, 0), (dut.par_inject.value.integer, await rd(A["PAR_INJECT"])))
    await pulse(env, pins, "mem_write")
    expect(sb, "mem_write alone does not arm", 0, dut.par_inject.value.integer)
    # arm in the very cycle of a memory write: the arm wins
    await env.tick()
    pins.force("mem_write", 1)
    rb.write_op(A["PAR_INJECT"], 1)
    await env.tick()
    pins.force("mem_write", 0)
    await env.cycles(3)
    expect(sb, "arming in the same cycle as a memory write stays armed", 1, dut.par_inject.value.integer)
    await rb.write(A["PAR_INJECT"], 0)
    expect(sb, "disarm by writing 0", 0, await rd(A["PAR_INJECT"]))
    finish(env, sb, "parity_controls_directed", chk)


@cocotb.test()
async def unaligned_probe(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)
    ops = []
    for base in (0x000, 0x004, 0x024, 0x028, 0x030, 0x03C):
        for off in (1, 2, 3):
            ops.append(rb.write_op(base + off, 0xFFFF))
            ops.append(rb.read_op(base + off))
    await drain(env, rb)
    for o in ops:
        expect(sb, "unaligned access refused", True, o.err, "%s 0x%x" % ("write" if o.write else "read", o.addr))
    expect(sb, "unaligned INJECT/SW_REPORT/CTRL writes had no effect", 0, (await rb.read(A["STATUS"])).rdata)
    finish(env, sb, "unaligned_probe", chk)


def pin_profile(pins, phase):
    for k in PULSES + ("mem_write",):
        pins.set(k, "off")
    for k in LEVELS:
        pins.set(k, "off")
    if phase == 0:
        for k in PULSES:
            pins.set(k, "rand", 0.01)
        pins.set("mem_write", "rand", 0.05)
    elif phase == 1:
        for k in PULSES:
            pins.set(k, "rand", 0.15)
        pins.set("mem_write", "rand", 0.3)
    elif phase == 2:
        for k in LEVELS:
            pins.set(k, "level", 0.04)
        pins.set("ev_periph_err", "rand", 0.02)
    elif phase == 3:
        for k in LEVELS:
            pins.set(k, "level", 0.3)
        for k in PULSES:
            pins.set(k, "rand", 0.3)
    elif phase == 4:
        for k in PULSES:
            pins.set(k, "rand", 0.002)
        for k in LEVELS:
            pins.set(k, "level", 0.005)
    for k in ADDRS:
        pins.set(k, "noise")


@cocotb.test()
async def random_traffic(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)
    rng = env.seeds.child("traffic")
    n_ops = int(os.environ.get("CTL_OPS", "6000"))
    for phase in range(6):
        pin_profile(pins, phase)
        tr = RegTraffic(rng, REGS, p_reg=[0.9, 0.8, 0.85, 0.7, 0.9, 0.8][phase], p_hole=0.08, p_write=[0.4, 0.5, 0.35, 0.6, 0.45, 0.3][phase])
        rb.gap.set_mode(["always", "random:0.5", "bursty:1-6", "always", "random:0.9", "random:0.3"][phase])
        tr.queue(rb, n_ops // 6)
        await drain(env, rb)
    pin_profile(pins, 5)
    queue_sweep(rb)
    await drain(env, rb)
    finish(env, sb, "random_traffic", chk)


@cocotb.test()
async def reset_traffic(dut):
    env, rst, rb, pins, sb, model, chk = await go(dut, SEED)
    rng = env.seeds.child("rst")
    tr = RegTraffic(rng, REGS, p_reg=0.9, p_hole=0.05, p_write=0.5)
    for rnd in range(10):
        pin_profile(pins, rng.randrange(5))
        tr.queue(rb, 100 + rng.randrange(200))
        await env.until(lambda: len(rb.queue) < 20, 30000, "traffic running")
        n0 = rst.n_pulses
        if rnd % 2 == 0:
            rst.pulse(length=rng.randint(1, 3), delay=rng.randint(1, 4), reason="sync-reset")
        else:
            await env.tick()
            await async_reset_midcycle(env, rst, rng.choice((1.0, 2.0, 3.0, 4.0, 6.0, 7.0, 8.5)), rng.randint(1, 3))
        await env.until(lambda: rst.n_pulses > n0, 20, "reset asserted")
        pin_profile(pins, 5)  # all event inputs quiet from the reset on: the post-reset STATUS must be empty
        await env.cycles(2)
        await env.until(lambda: not rst.asserted, 20, "reset release")
        await env.cycles(2)
        for nm, v in (("STATUS", 0), ("WARN_EN", 0), ("FATAL_EN", 0), ("WARN_COUNT", 0), ("FATAL_COUNT", 0), ("FIRST_SRC", 0), ("LAST_SRC", 0), ("SW_CODE", 0),
                      ("CTRL", 1), ("PAR_INJECT", 0), ("PAR_CHK_EN", 0)):
            expect(sb, "%s after reset #%d" % (nm, rnd), v, (await rb.read(A[nm])).rdata)
        expect(sb, "pins low after reset", (0, 0, 0, 0, 0, 0), tuple(getattr(dut, n).value.integer for n in ("irq_warn", "irq_fatal", "fatal_pin", "fatal_iso", "par_inject", "par_chk_en")))
    finish(env, sb, "reset_traffic", chk)


@cocotb.test()
async def level_at_reset_release(dut):
    """A level input already high when reset is released counts as a rising edge and sets STATUS."""
    env, rst, rb, pins, sb, model, chk = build(dut, SEED)
    for k in LEVELS:
        pins.force(k, 1)
    await env.start()
    await env.until(lambda: not rst.asserted, 50, "reset release")
    await env.cycles(4)
    st = (await rb.read(A["STATUS"])).rdata
    expect(sb, "levels high through reset release are captured", 0x620, st)
    expect(sb, "counted as one rising edge each", (1, 2), ((await rb.read(A["WARN_COUNT"])).rdata, (await rb.read(A["FATAL_COUNT"])).rdata))
    finish(env, sb, "level_at_reset_release", chk)
