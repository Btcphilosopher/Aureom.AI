"""Pure-Python tests of the cc_sysctrl reference model (hand-computed spec examples, no simulator)."""
from albionverify.models import ctl_spec as S
from albionverify.models.ctl_sysctrl import SysctrlModel

A = S.SYSCTRL
KEY = S.SOFT_RESET_KEY


def make():
    m = SysctrlModel()
    for _ in range(6):  # initial power-on reset
        cyc(m, por=True)
    for _ in range(6):  # release: synchronisers take 2 edges each
        cyc(m)
    return m


def cyc(m, sel=0, we=0, addr=0, wdata=0, wdt=0, host=0, bm=0, por=False):
    return m.step({"sel": sel, "we": we, "addr": addr, "wdata": wdata, "wdt_req": wdt, "host_rst_req_i": host, "boot_mode_i": bm}, {"por_in": por})


def wr(m, a, d, **kw):
    return cyc(m, 1, 1, a, d, **kw)


def rd(m, a, **kw):
    return cyc(m, 1, 0, a, 0, **kw)


def run_idle(m, n, **kw):
    return [cyc(m, **kw) for _ in range(n)]


def test_reset_state_after_por():
    m = make()
    assert rd(m, A["ID"])["rdata"] == 0x53464343
    assert rd(m, A["HW_VERSION"])["rdata"] == 0x00010000
    assert rd(m, A["MAP_VERSION"])["rdata"] == 0x00010000
    assert rd(m, A["RESET_CAUSE"])["rdata"] == 0x1
    assert rd(m, A["RESET_COUNT"])["rdata"] == 0
    for n in ("BOOT_STAGE", "BOOT_STATUS", "HOST_STATUS", "FW_VERSION", "SCRATCH0", "SCRATCH3", "TEST_CTRL", "BOOT_MODE"):
        assert rd(m, A[n])["rdata"] == 0, n
    o = cyc(m)
    assert (o["sys_reset_req"], o["por_rst_n"], o["sys_rst_n"]) == (0, 1, 1)


def test_soft_reset_pulse_is_16_cycles_and_clears_sys_domain_only():
    m = make()
    wr(m, A["SCRATCH1"], 0x1234)
    wr(m, A["BOOT_STAGE"], 5)
    wr(m, A["HOST_STATUS"], 3)
    assert wr(m, A["SOFT_RESET"], KEY)["err"] == 0  # request taken at this edge
    outs = run_idle(m, 40)
    req = [o["sys_reset_req"] for o in outs]
    assert req[:16] == [1] * 16 and req[16:] == [0] * 24  # pulse = CC_RESET_STRETCH cycles, from the cycle after the write
    srn = [o["sys_rst_n"] for o in outs]
    assert srn[:18] == [0] * 18 and srn[18] == 1  # SYS reset: asserted with the pulse, released 2 edges after it
    assert rd(m, A["BOOT_STAGE"])["rdata"] == 0 and rd(m, A["HOST_STATUS"])["rdata"] == 0
    assert rd(m, A["SCRATCH1"])["rdata"] == 0x1234  # POR domain kept
    assert rd(m, A["RESET_CAUSE"])["rdata"] == 0x3 and rd(m, A["RESET_COUNT"])["rdata"] == 1


def test_wrong_key_refused_no_reset():
    m = make()
    for bad in (0, KEY ^ 1, KEY ^ 0x80000000, 0xFFFFFFFF):
        assert wr(m, A["SOFT_RESET"], bad)["err"] == 1
    assert rd(m, A["SOFT_RESET"])["err"] == 1  # WO register
    assert all(o["sys_reset_req"] == 0 for o in run_idle(m, 30))
    assert rd(m, A["RESET_COUNT"])["rdata"] == 0


def test_w1c_and_set_priority():
    m = make()
    wr(m, A["SOFT_RESET"], KEY)
    run_idle(m, 30)
    assert rd(m, A["RESET_CAUSE"])["rdata"] == 0x3
    wr(m, A["RESET_CAUSE"], 0x1)
    assert rd(m, A["RESET_CAUSE"])["rdata"] == 0x2
    wr(m, A["RESET_CAUSE"], 0xFFFFFFF0)
    assert rd(m, A["RESET_CAUSE"])["rdata"] == 0x2  # bits outside [3:0] do nothing
    # watchdog request in the very cycle of a W1C(0xF): the new cause survives
    cyc(m, 1, 1, A["RESET_CAUSE"], 0xF, wdt=1)
    run_idle(m, 30)
    assert rd(m, A["RESET_CAUSE"])["rdata"] == 0x4


def test_requests_during_the_pulse_are_merged():
    m = make()
    wr(m, A["SOFT_RESET"], KEY)
    run_idle(m, 3)
    wr(m, A["SOFT_RESET"], KEY)  # inside the pulse
    run_idle(m, 30)
    assert rd(m, A["RESET_COUNT"])["rdata"] == 1
    # key in the last pulse cycle is merged, key in the first cycle after the pulse is a new reset
    wr(m, A["SOFT_RESET"], KEY)
    run_idle(m, 15)
    o = wr(m, A["SOFT_RESET"], KEY)  # 16th cycle after the request = last pulse cycle
    assert o["sys_reset_req"] == 1
    run_idle(m, 30)
    assert rd(m, A["RESET_COUNT"])["rdata"] == 2
    wr(m, A["SOFT_RESET"], KEY)
    run_idle(m, 16)
    o = wr(m, A["SOFT_RESET"], KEY)  # first idle cycle after the pulse
    assert o["sys_reset_req"] == 0
    run_idle(m, 30)
    assert rd(m, A["RESET_COUNT"])["rdata"] == 4


def test_watchdog_level_retriggers_host_request_is_edge_triggered():
    m = make()
    outs = run_idle(m, 40, wdt=1)
    starts = [i for i in range(1, 40) if outs[i]["sys_reset_req"] and not outs[i - 1]["sys_reset_req"]]
    assert starts == [1, 18, 35]  # period STRETCH + 1
    run_idle(m, 30)
    assert rd(m, A["RESET_CAUSE"])["rdata"] == 0x5 and rd(m, A["RESET_COUNT"])["rdata"] == 3
    m = make()
    outs = run_idle(m, 60, host=1)  # level held: one rising edge, pulse 3 edges after the pin
    assert [o["sys_reset_req"] for o in outs[:5]] == [0, 0, 0, 1, 1]
    assert sum(o["sys_reset_req"] for o in outs) == 16
    run_idle(m, 20)
    assert rd(m, A["RESET_CAUSE"])["rdata"] == 0x9 and rd(m, A["RESET_COUNT"])["rdata"] == 1


def test_boot_mode_two_flop_synchroniser():
    m = make()
    assert [rd(m, A["BOOT_MODE"], bm=2)["rdata"] for _ in range(4)] == [0, 0, 2, 2]


def test_por_clears_everything_including_the_por_domain():
    m = make()
    wr(m, A["SCRATCH0"], 7)
    wr(m, A["SOFT_RESET"], KEY)
    run_idle(m, 30)
    for _ in range(3):
        cyc(m, por=True)
    run_idle(m, 6)
    assert rd(m, A["SCRATCH0"])["rdata"] == 0
    assert rd(m, A["RESET_CAUSE"])["rdata"] == 0x1 and rd(m, A["RESET_COUNT"])["rdata"] == 0


def test_access_classes_and_unspecified_bits():
    m = make()
    for n in ("ID", "HW_VERSION", "MAP_VERSION", "FEATURES", "ROM_BYTES", "IMEM_BYTES", "DMEM_BYTES", "RESET_COUNT", "BOOT_MODE"):
        assert wr(m, A[n], 0xFFFFFFFF)["err"] == 1 and rd(m, A[n])["err"] == 0, n
    for a in (0x01C, 0x054, 0x100, 0xFFC, 0x021, 0x051):
        assert wr(m, a, 1)["err"] == 1 and rd(m, a)["err"] == 1, hex(a)
    wr(m, A["TEST_CTRL"], 0xFFFFFFFF)
    o = cyc(m)
    assert (o["test_done"], o["test_fail"], o["test_code"]) == (1, 1, 0xFFFF)
    assert m.rdata_mask(A["TEST_CTRL"]) == 0xC000FFFF  # bits 29:16 are not specified
    wr(m, A["HOST_STATUS"], 0xFFFFFFFF)
    assert rd(m, A["HOST_STATUS"])["rdata"] == 0xF  # only [3:0] are fields
    wr(m, A["BOOT_STAGE"], 0x1FF)
    assert rd(m, A["BOOT_STAGE"])["rdata"] == 0xFF
