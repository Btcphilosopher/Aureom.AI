"""Pure-Python tests of the cc_perf reference model (hand-computed spec examples)."""
from albionverify.models import ctl_spec as S
from albionverify.models.ctl_perf import PerfModel

A = S.PERF


def cyc(m, ev=0, sel=0, we=0, addr=0, wdata=0):
    return m.step({"sel": sel, "we": we, "addr": addr, "wdata": wdata, "ev": ev}, {"sys": False})


def rd(m, a, ev=0):
    return cyc(m, ev, 1, 0, a)


def wr(m, a, d, ev=0):
    return cyc(m, ev, 1, 1, a, d)


def test_level_and_edge_counting():
    m = PerfModel(nev=4, edge=0b0100)  # event 2 counts rising edges
    for ev in (0b0101, 0b0101, 0b0101, 0, 0b0100, 0b0100):
        cyc(m, ev)
    assert rd(m, A["CNT0"])["rdata"] == 3  # per cycle
    assert rd(m, A["CNT0"] + 8)["rdata"] == 2  # two rising edges
    assert rd(m, A["CNT0"] + 4)["rdata"] == 0 and rd(m, A["CNT0"] + 12)["rdata"] == 0


def test_cycle_counter_and_info():
    m = PerfModel(nev=20)
    assert rd(m, A["INFO"])["rdata"] == 20
    cyc(m)
    o1 = rd(m, A["CYCLE_LO"])["rdata"]
    for _ in range(9):
        cyc(m)
    o2 = rd(m, A["CYCLE_LO"])["rdata"]
    assert o2 - o1 == 10 and rd(m, A["CYCLE_HI"])["rdata"] == 0


def test_freeze_and_clear():
    m = PerfModel(nev=2)
    cyc(m, 1)
    cyc(m, 1)
    wr(m, A["CTRL"], 1)  # freeze (takes effect after this edge)
    frozen = rd(m, A["CNT0"], 1)["rdata"]
    cyc(m, 1)
    cyc(m, 1)
    assert rd(m, A["CNT0"], 1)["rdata"] == frozen
    assert rd(m, A["CTRL"])["rdata"] == 1
    wr(m, A["CTRL"], 0)
    cyc(m, 1)
    assert rd(m, A["CNT0"])["rdata"] > frozen
    wr(m, A["CTRL"], 2, ev=1)  # clear wins over a same-cycle event
    assert rd(m, A["CNT0"])["rdata"] == 0 and rd(m, A["CYCLE_LO"])["rdata"] <= 2
    assert rd(m, A["CTRL"])["rdata"] == 0  # the clear bit does not read back
    wr(m, A["CTRL"], 3)  # clear + freeze
    assert rd(m, A["CTRL"])["rdata"] == 1


def test_edge_detector_tracks_input_while_frozen():
    m = PerfModel(nev=1, edge=1)
    wr(m, A["CTRL"], 1)
    cyc(m, 1)
    cyc(m, 1)
    wr(m, A["CTRL"], 0, ev=1)
    cyc(m, 1)
    assert rd(m, A["CNT0"], 1)["rdata"] == 0  # no spurious edge on unfreeze, the rising edge during freeze is lost
    cyc(m, 0)
    cyc(m, 1)
    assert rd(m, A["CNT0"])["rdata"] == 1


def test_access_classes():
    m = PerfModel(nev=20)
    for a in (A["INFO"], A["CYCLE_LO"], A["CYCLE_HI"], A["CNT0"], A["CNT0"] + 4 * 19):
        assert wr(m, a, 1)["err"] == 1 and rd(m, a)["err"] == 0
    for a in (0x008, 0x018, 0x0FC, A["CNT0"] + 4 * 20, 0x800, 0xFFC, 0x101):
        assert rd(m, a)["err"] == 1 and wr(m, a, 1)["err"] == 1
    assert wr(m, A["CTRL"], 0xFFFFFFFC)["err"] == 0
