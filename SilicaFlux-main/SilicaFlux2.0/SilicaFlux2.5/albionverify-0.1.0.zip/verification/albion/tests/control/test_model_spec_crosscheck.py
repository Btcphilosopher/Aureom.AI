"""The documented map (MEMORY_MAP.md) is the source of truth of the control models (albionverify/models/ctl_spec.py, hand-transcribed).
This test parses the document and the GENERATED header rtl/generated/cc_memmap_defs.svh and checks all three agree (a mismatch between the
document and the header is a finding)."""
import re
from pathlib import Path

import pytest

from albionverify import rtl
from albionverify.models import ctl_spec as S

DOC = (rtl.RTL_DIR / "controlcore/docs/MEMORY_MAP.md").read_text()
HDR = (rtl.RTL_DIR / "controlcore/rtl/generated/cc_memmap_defs.svh").read_text()

BLOCKS = {  # doc block name -> (ctl_spec dict, header prefix)
    "cc_sysctrl": (S.SYSCTRL, "CC_SYSCTRL_"), "cc_mailbox": (S.MAILBOX, "CC_MBOX_"), "cc_perf": (S.PERF, "CC_PERF_"), "cc_pmu": (S.PMU, "CC_PMU_"),
    "cc_ras": (S.RAS, "CC_RAS_"), "cc_secmon": (S.SECMON, "CC_SEC_"), "mcu_intc": (S.INTC, "CC_INTC_"), "mcu_wdt": (S.WDT, "CC_WDT_"),
    "mcu_dma": (S.DMA, "CC_DMA_"), "sfv_timer": (S.MTIMER, "CC_MTIMER_"),
}


def doc_block(name):
    m = re.search(r"## Block `%s` \(prefix `[A-Z_]+`\)\n\n\| Offset.*?\n\|---.*?\n(.*?)\n\n" % re.escape(name), DOC, re.S)
    assert m, "block %s not found in MEMORY_MAP.md" % name
    rows = {}
    for line in m.group(1).splitlines():
        cells = [c.strip().strip("`") for c in line.strip().strip("|").split("|")]
        rows[cells[1]] = {"off": int(cells[0], 16), "access": cells[2], "reset": cells[3], "desc": cells[4] if len(cells) > 4 else ""}
    return rows


def hdr_value(sym, width=None):
    m = re.search(r"localparam logic \[\d+:\d+\] %s = \d+'h([0-9a-fA-F_]+);" % re.escape(sym), HDR)
    return int(m.group(1).replace("_", ""), 16) if m else None


@pytest.mark.parametrize("block", sorted(BLOCKS))
def test_register_offsets_doc_vs_model_vs_header(block):
    spec, prefix = BLOCKS[block]
    rows = doc_block(block)
    assert {k: v["off"] for k, v in rows.items()} == spec, "%s: ctl_spec.py differs from the documented map" % block
    for name, off in spec.items():
        got = hdr_value(prefix + name)
        assert got == off, "%s: header %s%s = %s but the document says 0x%03x" % (block, prefix, name, None if got is None else hex(got), off)


def test_documented_reset_values_and_constants_match_header():
    rows = doc_block("cc_sysctrl")
    assert int(rows["ID"]["reset"], 16) == S.SYSCTRL_ID == hdr_value("CC_SYSCTRL_ID_RST")
    assert int(rows["HW_VERSION"]["reset"], 16) == S.SYSCTRL_HW_VERSION == hdr_value("CC_SYSCTRL_HW_VERSION_RST")
    assert int(doc_block("cc_pmu")["ACC_CTRL"]["reset"], 16) == S.PMU_ACC_CTRL_RESET == hdr_value("CC_PMU_ACC_CTRL_RST")
    assert int(doc_block("cc_ras")["CTRL"]["reset"], 16) == S.RAS_CTRL_RESET == hdr_value("CC_RAS_CTRL_RST")
    assert hdr_value("CC_MAP_VERSION") == S.MAP_VERSION
    for sym, val in (("CC_SOFT_RESET_KEY", S.SOFT_RESET_KEY), ("CC_IMAGE_MAGIC", S.IMAGE_MAGIC), ("CC_IMAGE_HDR_VERSION", S.IMAGE_HDR_VERSION),
                     ("CC_IMAGE_HDR_BYTES", S.IMAGE_HDR_BYTES), ("CC_EXT_IMAGE_DEFAULT", S.EXT_IMAGE_DEFAULT), ("CC_RESET_STRETCH", S.RESET_STRETCH)):
        doc_m = re.search(r"`%s` = `(0x[0-9A-Fa-f]+)`" % sym, DOC)
        assert doc_m, sym
        assert int(doc_m.group(1), 16) == val, "doc constant %s differs from ctl_spec" % sym
        assert hdr_value(sym) == val, "header constant %s differs from the document" % sym


def doc_enum(name):
    m = re.search(r"\* \*\*%s\*\*: (.*)" % re.escape(name), DOC)
    assert m, name
    return {k: int(v, 16) for k, v in re.findall(r"([A-Z0-9_]+) = (0x[0-9A-Fa-f]+)", m.group(1))}


@pytest.mark.parametrize("enum,spec,prefix", [
    ("RESET_CAUSE", S.RESET_CAUSE, "CC_RESET_CAUSE_"), ("BOOT_MODE", S.BOOT_MODE, "CC_BOOT_MODE_"), ("BOOT_STAGE", S.BOOT_STAGE, "CC_BOOT_STAGE_"),
    ("BOOT_ERR", S.BOOT_ERR, "CC_BOOT_ERR_"), ("HOST_STATUS", S.HOST_STATUS, "CC_HOST_STATUS_"), ("RAS_SRC", S.RAS_SRC, "CC_RAS_SRC_"),
    ("PERF_EV", S.PERF_EV, "CC_PERF_EV_"), ("MBOX_CMD", S.MBOX_CMD, "CC_MBOX_CMD_"), ("MBOX_STS", S.MBOX_STS, "CC_MBOX_STS_")])
def test_enumerations(enum, spec, prefix):
    d = doc_enum(enum)
    assert d == spec, "%s: ctl_spec differs from MEMORY_MAP.md" % enum
    # the header carries these as CC_<ENUM>_<NAME>
    missing = [k for k, v in spec.items() if hdr_value(prefix + k) is None]
    wrong = {k: (hex(hdr_value(prefix + k)), hex(v)) for k, v in spec.items() if hdr_value(prefix + k) not in (None, v)}
    assert not missing and not wrong, "header vs doc: missing=%s wrong=%s" % (missing, wrong)


def test_pages_and_regions():
    rows = re.findall(r"\| (\d+) \| `0x([0-9A-Fa-f]{8})` \| (\w+) \|", DOC)
    pages = {name: int(p) for p, base, name in rows}
    assert all(int(base, 16) == S.PERIPH_BASE + 0x1000 * int(p) for p, base, name in rows)
    assert pages == S.PAGES
    for name, p in S.PAGES.items():
        assert hdr_value("CC_PG_" + name) == p
        assert hdr_value("CC_%s_BASE" % name) == S.PERIPH_BASE + 0x1000 * p
    assert hdr_value("CC_BOOTROM_SIZE") == S.BOOTROM_SIZE and hdr_value("CC_IMEM_BASE") == S.IMEM_BASE and hdr_value("CC_IMEM_SIZE") == S.IMEM_SIZE
    assert hdr_value("CC_DMEM_BASE") == S.DMEM_BASE and hdr_value("CC_DMEM_SIZE") == S.DMEM_SIZE and hdr_value("CC_EXT_BASE") == S.EXT_BASE
    assert hdr_value("CC_PERIPH_SIZE") == S.PERIPH_SIZE
    m = re.search(r"`CC_PAGE_EN` = `32'h([0-9a-f]+)`, `CC_PAGE_FWD` = `32'h([0-9a-f]+)`", DOC)
    assert (int(m.group(1), 16), int(m.group(2), 16)) == (S.CC_PAGE_EN, S.CC_PAGE_FWD)


def test_irq_numbering_and_priorities():
    for name, n in S.IRQ.items():
        assert hdr_value("CC_IRQ_" + name) == n
        assert hdr_value("CC_IRQ_%s_PRIO" % name) == S.IRQ_PRIO[name]
    rows = re.findall(r"\| (\d) \| (\w+) \| (\d) \|", DOC)
    assert {name: (int(i), int(p)) for i, name, p in rows} == {k: (v, S.IRQ_PRIO[k]) for k, v in S.IRQ.items()}
