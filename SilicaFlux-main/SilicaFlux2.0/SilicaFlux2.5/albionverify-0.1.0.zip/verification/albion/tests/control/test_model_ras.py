"""Pure-Python tests of the cc_ras reference model (hand-computed spec examples)."""
from albionverify.models import ctl_spec as S
from albionverify.models.ctl_ras import RasModel

A = S.RAS
SRC = S.RAS_SRC
IDLE = {"sel": 0, "we": 0, "addr": 0, "wdata": 0, "ev_bus_decode": 0, "ev_bus_decode_addr": 0, "ev_periph_err": 0, "ev_periph_err_addr": 0, "ev_dma_err": 0,
        "ev_host_viol": 0, "ev_host_viol_addr": 0, "ev_iso_access": 0, "ev_parity": 0, "ev_parity_addr": 0, "lv_ext_warn": 0, "lv_ext_fatal": 0,
        "lv_tsu_halted": 0, "mem_write": 0}


def cyc(m, **kw):
    inp = dict(IDLE)
    inp.update(kw)
    return m.step(inp, {"sys": False})


def wr(m, a, d, **kw):
    return cyc(m, sel=1, we=1, addr=a, wdata=d, **kw)


def rd(m, a, **kw):
    return cyc(m, sel=1, we=0, addr=a, **kw)


def test_reset_values():
    m = RasModel()
    for n in ("STATUS", "WARN_EN", "FATAL_EN", "WARN_COUNT", "FATAL_COUNT", "FIRST_SRC", "LAST_SRC", "SW_CODE", "PAR_INJECT", "PAR_CHK_EN", "RAW"):
        assert rd(m, A[n])["rdata"] == 0, n
    assert rd(m, A["CTRL"])["rdata"] == 1


def test_pulse_source_status_counter_capture_and_w1c():
    m = RasModel()
    cyc(m, ev_bus_decode=1, ev_bus_decode_addr=0x2000_0004)
    assert rd(m, A["STATUS"])["rdata"] == 0x1
    assert rd(m, A["WARN_COUNT"])["rdata"] == 1 and rd(m, A["FATAL_COUNT"])["rdata"] == 0
    assert rd(m, A["FIRST_SRC"])["rdata"] == 0x80000000 and rd(m, A["FIRST_ADDR"])["rdata"] == 0x2000_0004
    cyc(m, ev_parity=1, ev_parity_addr=0x0002_0FFC)
    assert rd(m, A["STATUS"])["rdata"] == 0x101
    assert rd(m, A["FIRST_SRC"])["rdata"] == 0x80000000  # first event stays
    assert rd(m, A["LAST_SRC"])["rdata"] == 0x80000008 and rd(m, A["LAST_ADDR"])["rdata"] == 0x0002_0FFC
    assert rd(m, A["FATAL_COUNT"])["rdata"] == 1
    wr(m, A["STATUS"], 0x0001)
    assert rd(m, A["STATUS"])["rdata"] == 0x100
    wr(m, A["STATUS"], 0xFFFF)
    assert rd(m, A["STATUS"])["rdata"] == 0
    assert rd(m, A["WARN_COUNT"])["rdata"] == 1  # counters survive W1C


def test_interrupt_and_pin_gating():
    m = RasModel()
    cyc(m, ev_periph_err=1)
    assert cyc(m)["irq_warn"] == 0
    wr(m, A["WARN_EN"], 0x20)
    assert cyc(m)["irq_warn"] == 0  # enable of another source
    wr(m, A["WARN_EN"], 0x02)
    assert cyc(m)["irq_warn"] == 1
    cyc(m, ev_parity=1)
    o = cyc(m)
    assert (o["irq_fatal"], o["fatal_pin"], o["fatal_iso"]) == (0, 1, 0)  # FATAL_TO_HOST resets to 1, FATAL_ISOLATE to 0
    wr(m, A["FATAL_EN"], 0x01)
    assert cyc(m)["irq_fatal"] == 1
    wr(m, A["CTRL"], 0x2)
    o = cyc(m)
    assert (o["fatal_pin"], o["fatal_iso"]) == (0, 1)


def test_level_sources_reset_while_active_and_count_rising_edges():
    m = RasModel()
    for _ in range(5):
        cyc(m, lv_ext_warn=1)
    assert rd(m, A["STATUS"], lv_ext_warn=1)["rdata"] == 0x20
    assert rd(m, A["RAW"], lv_ext_warn=1)["rdata"] == 1
    wr(m, A["STATUS"], 0x20, lv_ext_warn=1)  # still active: re-set at once
    assert rd(m, A["STATUS"], lv_ext_warn=1)["rdata"] == 0x20
    assert rd(m, A["WARN_COUNT"])["rdata"] == 1  # one rising edge
    cyc(m)
    wr(m, A["STATUS"], 0x20)
    assert rd(m, A["STATUS"])["rdata"] == 0
    cyc(m, lv_ext_warn=1)
    assert rd(m, A["WARN_COUNT"])["rdata"] == 2
    cyc(m, lv_tsu_halted=1, lv_ext_fatal=1)
    assert rd(m, A["FATAL_COUNT"])["rdata"] == 2 and rd(m, A["STATUS"])["rdata"] & 0x600 == 0x600


def test_inject_and_sw_report():
    m = RasModel()
    wr(m, A["INJECT"], 0xFFFF)
    assert rd(m, A["STATUS"])["rdata"] == 0x0F7F  # bit 7 and [15:12] raise nothing
    wr(m, A["STATUS"], 0xFFFF)
    wr(m, A["SW_REPORT"], 0x8000_1234)
    assert rd(m, A["STATUS"])["rdata"] == 1 << SRC["SW_FATAL"]
    assert rd(m, A["SW_CODE"])["rdata"] == 0x1234
    assert rd(m, A["LAST_ADDR"])["rdata"] == 0x1234 and rd(m, A["LAST_SRC"])["rdata"] == 0x80000000 | SRC["SW_FATAL"]
    wr(m, A["SW_REPORT"], 0x7FFF_FFFF)
    assert rd(m, A["SW_CODE"])["rdata"] == 0x7FFF_FFFF and rd(m, A["STATUS"])["rdata"] & 0x40


def test_first_last_tie_break_clear_first_and_clear_counts():
    m = RasModel()
    cyc(m, ev_dma_err=1, ev_iso_access=1, ev_parity=1, ev_parity_addr=0xABCD_0000)
    assert rd(m, A["FIRST_SRC"])["rdata"] == 0x80000002  # lowest source
    assert rd(m, A["LAST_SRC"])["rdata"] == 0x80000008 and rd(m, A["LAST_ADDR"])["rdata"] == 0xABCD_0000  # highest source
    assert (rd(m, A["WARN_COUNT"])["rdata"], rd(m, A["FATAL_COUNT"])["rdata"]) == (2, 1)  # one per source per cycle
    wr(m, A["CTRL"], 0x5)  # CLEAR_FIRST (+ FATAL_TO_HOST)
    assert rd(m, A["FIRST_SRC"])["rdata"] >> 31 == 0
    assert rd(m, A["CTRL"])["rdata"] == 1  # pulse bits read back 0
    cyc(m, ev_bus_decode=1, ev_bus_decode_addr=0x1111)
    assert rd(m, A["FIRST_SRC"])["rdata"] == 0x80000000 and rd(m, A["FIRST_ADDR"])["rdata"] == 0x1111
    wr(m, A["CTRL"], 0x9)  # CLEAR_COUNTS
    assert (rd(m, A["WARN_COUNT"])["rdata"], rd(m, A["FATAL_COUNT"])["rdata"]) == (0, 0)
    # event in the CLEAR_FIRST cycle becomes the new first event; new event beats a same-cycle W1C
    cyc(m, sel=1, we=1, addr=A["CTRL"], wdata=0x5, ev_host_viol=1, ev_host_viol_addr=0x77)
    assert rd(m, A["FIRST_SRC"])["rdata"] == 0x80000003
    cyc(m, sel=1, we=1, addr=A["STATUS"], wdata=0xFFFF, ev_dma_err=1)
    assert rd(m, A["STATUS"])["rdata"] == 0x4


def test_injection_only_capture_is_unspecified_and_parity_controls():
    m = RasModel()
    wr(m, A["INJECT"], 0x1)
    assert rd(m, A["FIRST_ADDR"])["rdata"] is None  # address of an injected event: not compared
    wr(m, A["PAR_INJECT"], 1)
    assert cyc(m)["par_inject"] == 1
    assert cyc(m, mem_write=1)["par_inject"] == 1  # the clear takes effect after the write edge
    assert cyc(m)["par_inject"] == 0
    cyc(m, sel=1, we=1, addr=A["PAR_INJECT"], wdata=1, mem_write=1)  # arm in the same cycle as a memory write: arm wins
    assert cyc(m)["par_inject"] == 1
    wr(m, A["PAR_CHK_EN"], 0xFFFF_FFFF)
    assert cyc(m)["par_chk_en"] == 1 and rd(m, A["PAR_CHK_EN"])["rdata"] == 1


def test_access_classes():
    m = RasModel()
    for n in ("WARN_COUNT", "FATAL_COUNT", "FIRST_SRC", "FIRST_ADDR", "LAST_SRC", "LAST_ADDR", "SW_CODE", "RAW"):
        assert wr(m, A[n], 1)["err"] == 1 and rd(m, A[n])["err"] == 0, n
    for n in ("INJECT", "SW_REPORT"):
        assert rd(m, A[n])["err"] == 1 and wr(m, A[n], 0)["err"] == 0, n
    for a in (0x040, 0x0FC, 0xFFC, 0x001, 0x031):
        assert rd(m, a)["err"] == 1 and wr(m, a, 1)["err"] == 1
