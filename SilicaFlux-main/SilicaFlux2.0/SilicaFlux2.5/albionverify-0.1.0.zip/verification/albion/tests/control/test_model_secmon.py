"""Pure-Python tests of the cc_secmon reference model."""
from albionverify.models import ctl_spec as S
from albionverify.models.ctl_secmon import SecmonModel

A = S.SECMON


def cyc(m, sel=0, we=0, addr=0, wdata=0, evt=0, vaddr=0):
    return m.step({"sel": sel, "we": we, "addr": addr, "wdata": wdata, "viol_evt": evt, "viol_addr": vaddr}, {"sys": False})


def wr(m, a, d, **kw):
    return cyc(m, 1, 1, a, d, **kw)


def rd(m, a, **kw):
    return cyc(m, 1, 0, a, **kw)


def test_caps_and_reset():
    m = SecmonModel()
    assert rd(m, A["CAPS"])["rdata"] == 0x70
    for n in ("STATUS", "CTRL", "BOOT_MEASURE", "VIOL_ADDR", "VIOL_COUNT", "AUTH_HOOK"):
        assert rd(m, A[n])["rdata"] == 0
    assert rd(m, A["CLEAR"])["err"] == 1


def test_lock_is_set_only():
    m = SecmonModel()
    wr(m, A["CTRL"], 0xFFFFFFFE)
    assert rd(m, A["CTRL"])["rdata"] == 0
    wr(m, A["CTRL"], 1)
    assert cyc(m)["host_lock"] == 1 and rd(m, A["STATUS"])["rdata"] == 1
    o = wr(m, A["CTRL"], 0)
    assert o["err"] == 0 and rd(m, A["CTRL"])["rdata"] == 1
    m.reset()
    assert rd(m, A["CTRL"])["rdata"] == 0


def test_boot_measure_is_write_once():
    m = SecmonModel()
    assert wr(m, A["BOOT_MEASURE"], 0)["err"] == 0  # even a zero measurement counts
    assert rd(m, A["STATUS"])["rdata"] >> 1 & 1 == 1
    assert wr(m, A["BOOT_MEASURE"], 0x1234)["err"] == 1
    assert rd(m, A["BOOT_MEASURE"])["rdata"] == 0
    m2 = SecmonModel()
    wr(m2, A["BOOT_MEASURE"], 0xDEAD)
    assert wr(m2, A["BOOT_MEASURE"], 1)["err"] == 1 and rd(m2, A["BOOT_MEASURE"])["rdata"] == 0xDEAD


def test_violation_log():
    m = SecmonModel()
    cyc(m, evt=1, vaddr=0x10040)
    assert rd(m, A["STATUS"])["rdata"] == 0x100 and rd(m, A["VIOL_ADDR"])["rdata"] == 0x10040 and rd(m, A["VIOL_COUNT"])["rdata"] == 1
    for _ in range(3):
        cyc(m, evt=1, vaddr=0x20000)
    assert rd(m, A["VIOL_COUNT"])["rdata"] == 4 and rd(m, A["VIOL_ADDR"])["rdata"] == 0x20000
    wr(m, A["CLEAR"], 0xFFFFFFFE)
    assert rd(m, A["STATUS"])["rdata"] == 0x100
    wr(m, A["CLEAR"], 1)
    assert rd(m, A["STATUS"])["rdata"] == 0 and rd(m, A["VIOL_COUNT"])["rdata"] == 4
    cyc(m, 1, 1, A["CLEAR"], 1, evt=1, vaddr=5)  # same cycle: the new violation wins
    assert rd(m, A["STATUS"])["rdata"] == 0x100


def test_access_classes():
    m = SecmonModel()
    for n in ("CAPS", "STATUS", "VIOL_ADDR", "VIOL_COUNT", "AUTH_HOOK"):
        assert wr(m, A[n], 1)["err"] == 1 and rd(m, A[n])["err"] == 0
    for a in (0x020, 0x100, 0xFFC, 0x009):
        assert rd(m, a)["err"] == 1 and wr(m, a, 1)["err"] == 1
