"""cc_pmu bench: accelerator clock gate / reset / isolation control and the status / sleep / gated-cycle counters.

Reference model: albionverify/models/ctl_pmu.py (from MEMORY_MAP.md, 01_ARCHITECTURE.md section 4, 05_ACCELERATORS.md section 3).
Inputs cpu_sleep, vec_busy, tsu_busy, tsu_halted, ext_idle, fatal_iso, acc_in_reset are driven by seeded level generators and by
directed scenarios (including a small closed-loop emulation of the accelerator reset synchroniser).
"""
import os

import cocotb

from albionverify.bus.regbus import RegBusMaster
from albionverify.core import Env
from albionverify.coverage import CoverGroup
from albionverify.models import ctl_spec as S
from albionverify.models.ctl_pmu import PmuModel
from albionverify.reset import ResetSequencer
from albionverify.scoreboard import Scoreboard

from control.ctl_bench import (BlockChecker, PinDriver, Recorder, RegTraffic, async_reset_midcycle, expect, finish, gap_cover, queue_sweep,
                               txn_cover)

A = S.PMU
SEED = int(os.environ.get("ALBION_SEED", "1"))
PINS = ("cpu_sleep", "vec_busy", "tsu_busy", "tsu_halted", "ext_idle", "fatal_iso", "acc_in_reset")
REGS = [(A["INFO"], ()), (A["ACC_CTRL"], (0, 1, 2, 3, 4, 5, 6, 7, 0xFFFFFFF8, 0xFFFFFFFF)), (A["ACC_STATUS"], ()), (A["CC_STATE"], ()),
        (A["SLEEP_CYC"], ()), (A["GATED_CYC"], ())]


def kind_of(a):
    if a & 3:
        return "unmapped"
    if a == A["ACC_CTRL"]:
        return "rw"
    if a in (A["INFO"], A["ACC_STATUS"], A["CC_STATE"], A["SLEEP_CYC"], A["GATED_CYC"]):
        return "ro"
    return "unmapped"


def build(dut, seed):
    env = Env(dut, name="pmu", seed=seed)
    rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=4))
    rb = env.add(RegBusMaster("rb", env, rng=env.seeds.child("rb")))
    pins = env.add(PinDriver("pins", env.seeds.child("pins"), {k: (env.sig(k), 1) for k in PINS}))
    pins.set("ext_idle", "hold", 1)
    rec = env.add(Recorder("rec", {k: env.sig(k) for k in ("acc_clk_en", "acc_rst_req", "acc_iso")}))
    sb = Scoreboard(env, "pmu")
    model = PmuModel()
    rstn = env.sig("rst_n")
    ins = {"sel": env.sig("rb_sel"), "we": env.sig("rb_we"), "addr": env.sig("rb_addr"), "wdata": env.sig("rb_wdata")}
    ins.update({k: env.sig(k) for k in PINS})
    chk = env.add(BlockChecker("chk", model, sb, ins=ins,
                               outs={"rdata": env.sig("rb_rdata"), "err": env.sig("rb_err"), "acc_clk_en": env.sig("acc_clk_en"),
                                     "acc_rst_req": env.sig("acc_rst_req"), "acc_iso": env.sig("acc_iso")},
                               resets=lambda: {"sys": rstn.read() == 0}))
    tc = txn_cover("pmu", {"ro": ("ok", "refused"), "rw": ("ok", "ok"), "unmapped": ("refused", "refused")})
    sc = CoverGroup("pmu.state", "gating / reset / isolation scenarios")
    sc.point("ctl", list(range(8)))
    sc.point("busy", ["idle", "vec", "tsu", "ext", "multi"])
    sc.point("iso_cause", ["ctl_iso", "ctl_rst", "clk_off_req", "clk_gated", "fatal_iso", "in_reset", "none"])
    sc.point("event", ["clk_off_deferred_by_busy", "rst_deferred_by_ext", "rst_released", "clk_gated_cycle", "sleep_cycle"])
    sc.cross("ctl_busy", ["ctl", "busy"])
    ac = CoverGroup("pmu.addr", "address boundaries")
    ac.point("addr", {"first": 0x000, "acc_ctrl": 0x004, "last_reg": 0x014, "hole_next": 0x018, "hole_mid": lambda a: 0x018 < a < 0xFFC, "page_last_word": 0xFFC})
    env.coverage += [tc, sc, ac, gap_cover("pmu")]

    def hook(inp, exp, rst):
        if rst.get("sys"):
            return
        if inp["sel"]:
            tc.sample(dir="write" if inp["we"] else "read", kind=kind_of(inp["addr"]), result="refused" if exp["err"] else "ok")
            ac.sample(addr=inp["addr"])
        m = model
        n_busy = inp["vec_busy"] + inp["tsu_busy"] + (1 - inp["ext_idle"])
        busy = "idle" if n_busy == 0 else "multi" if n_busy > 1 else "vec" if inp["vec_busy"] else "tsu" if inp["tsu_busy"] else "ext"
        sc.sample(ctl=m.ctl, busy=busy)
        cause = "ctl_iso" if m.ctl & 4 else "ctl_rst" if m.ctl & 2 else "clk_off_req" if not m.ctl & 1 else "clk_gated" if not m.clk_on else \
            "fatal_iso" if inp["fatal_iso"] else "in_reset" if inp["acc_in_reset"] else "none"
        sc.sample(iso_cause=cause)
        if not m.ctl & 1 and m.clk_on and (inp["vec_busy"] or inp["tsu_busy"] or not inp["ext_idle"]):
            sc.sample(event="clk_off_deferred_by_busy")
        if m.ctl & 2 and not m.rst_eff and not inp["ext_idle"]:
            sc.sample(event="rst_deferred_by_ext")
        if not m.ctl & 2 and m.rst_eff:
            sc.sample(event="rst_released")
        if not m.clk_on:
            sc.sample(event="clk_gated_cycle")
        if inp["cpu_sleep"]:
            sc.sample(event="sleep_cycle")

    chk.hooks.append(hook)
    return env, rst, rb, pins, rec, sb, model, chk


async def go(dut, seed):
    env, rst, rb, pins, rec, sb, model, chk = build(dut, seed)
    await env.start()
    await env.until(lambda: not rst.asserted, 50, "reset release")
    return env, rst, rb, pins, rec, sb, model, chk


async def drain(env, rb, n=200000):
    await env.until(lambda: rb.idle, n, "register ops")


# ============================================================================= tests


@cocotb.test()
async def reset_values(dut):
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)
    queue_sweep(rb)
    await drain(env, rb)
    by = {op.addr: op for op in rb.history}
    expect(sb, "INFO = 1 domain, 1 gateable, no DVFS / switches", 0x11, by[A["INFO"]].rdata)
    expect(sb, "ACC_CTRL reset value", 1, by[A["ACC_CTRL"]].rdata)
    # ext_idle = 1, everything else idle: CLK_ON (bit0) and EXT_IDLE (bit3)
    expect(sb, "ACC_STATUS at reset", 0x9, by[A["ACC_STATUS"]].rdata)
    expect(sb, "CC_STATE", 0, by[A["CC_STATE"]].rdata)
    expect(sb, "SLEEP_CYC counts only while sleeping", 0, by[A["SLEEP_CYC"]].rdata)
    expect(sb, "GATED_CYC at reset", 0, by[A["GATED_CYC"]].rdata)
    for a in (0x018, 0x01C, 0x100, 0x800, 0xFFC):
        expect(sb, "hole refused", (True, 0), (by[a].err, by[a].rdata), "0x%x" % a)
    expect(sb, "outputs at reset", (1, 0, 0), (dut.acc_clk_en.value.integer, dut.acc_rst_req.value.integer, dut.acc_iso.value.integer))
    ops = [rb.write_op(a, 0xFFFFFFFF) for a in (A["INFO"], A["ACC_STATUS"], A["CC_STATE"], A["SLEEP_CYC"], A["GATED_CYC"], 0x018, 0xFFC)]
    await drain(env, rb)
    for o in ops:
        expect(sb, "write to RO / hole refused", True, o.err, "0x%x" % o.addr)
    expect(sb, "ACC_CTRL unchanged by refused writes", 1, (await rb.read(A["ACC_CTRL"])).rdata)
    finish(env, sb, "reset_values", chk)


@cocotb.test()
async def clock_gating_directed(dut):
    """CLK_EN=0 request: isolation at once, clock stops two edges after the write, deferred by busy units / the external port."""
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)

    async def st():
        return (await rb.read(A["ACC_STATUS"])).rdata

    o = await rb.write(A["ACC_CTRL"], 0x0)  # CLK_EN = 0
    w = o.t_issue
    await env.cycles(4)
    expect(sb, "isolated right after the write (clock requested off)", 1, rec.h["acc_iso"][w + 1])
    expect(sb, "clock still on one edge after the write", 1, rec.h["acc_clk_en"][w + 1])
    expect(sb, "clock off two edges after the write", 0, rec.h["acc_clk_en"][w + 2])
    expect(sb, "no reset requested by gating", 0, rec.h["acc_rst_req"][w + 2])
    s = await st()
    expect(sb, "STATUS: not CLK_ON, ISOLATED, EXT_IDLE, no pending", 0x4 | 0x8, s)
    # GATED_CYC counts cycles with the clock off
    g0 = (await rb.read(A["GATED_CYC"])).rdata
    await env.cycles(10)
    g1 = (await rb.read(A["GATED_CYC"])).rdata
    expect(sb, "GATED_CYC advances once per gated cycle", True, g1 - g0 >= 10)
    # re-enable: clock back on one edge later (CLK_EN is registered, then CLK_ON)
    o = await rb.write(A["ACC_CTRL"], 0x1)
    w = o.t_issue
    await env.cycles(4)
    expect(sb, "clock back on two edges after the re-enable", (0, 1), (rec.h["acc_clk_en"][w + 1], rec.h["acc_clk_en"][w + 2]))
    expect(sb, "isolation released once the clock runs again", (1, 0), (rec.h["acc_iso"][w + 1], rec.h["acc_iso"][w + 2]))
    # busy units keep the clock on after CLK_EN = 0 (CLK_OFF_PENDING)
    for busy_pin in ("vec_busy", "tsu_busy"):
        pins.force(busy_pin, 1)
        await env.cycles(3)
        await rb.write(A["ACC_CTRL"], 0x0)
        await env.cycles(6)
        s = await st()
        expect(sb, "%s: clock held on, CLK_OFF_PENDING + ISOLATED" % busy_pin, (1, 1, 1), (s & 1, s >> 7 & 1, s >> 2 & 1))
        expect(sb, busy_pin + " status bit", 1, s >> (4 if busy_pin == "vec_busy" else 5) & 1)
        expect(sb, "clock enable stays 1 while busy", 1, dut.acc_clk_en.value.integer)
        pins.force(busy_pin, 0)
        o = await rb.read(A["ACC_STATUS"])
        await env.cycles(4)
        expect(sb, "clock drops after the unit goes idle", 0, dut.acc_clk_en.value.integer)
        await rb.write(A["ACC_CTRL"], 0x1)
        await env.cycles(4)
    # external port not idle keeps the clock on as well
    pins.force("ext_idle", 0)
    await env.cycles(3)
    await rb.write(A["ACC_CTRL"], 0x0)
    await env.cycles(6)
    expect(sb, "ext transaction outstanding holds the clock", 1, dut.acc_clk_en.value.integer)
    s = await st()
    expect(sb, "STATUS shows EXT_IDLE = 0", 0, s >> 3 & 1)
    pins.force("ext_idle", 1)
    await env.cycles(4)
    expect(sb, "clock drops when the external port is idle", 0, dut.acc_clk_en.value.integer)
    await rb.write(A["ACC_CTRL"], 0x1)
    finish(env, sb, "clock_gating_directed", chk)


@cocotb.test()
async def reset_isolation_directed(dut):
    """RST: deferred until the external port is idle, held while requested, released at once; ISO / fatal / in-reset isolation."""
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)
    # reset request with an idle port: effective one edge after ACC_CTRL
    o = await rb.write(A["ACC_CTRL"], 0x3)  # CLK_EN | RST
    w = o.t_issue
    await env.cycles(4)
    expect(sb, "acc_rst_req two edges after the write", (0, 1), (rec.h["acc_rst_req"][w + 1], rec.h["acc_rst_req"][w + 2]))
    expect(sb, "isolated while reset is requested", (1, 1), (rec.h["acc_iso"][w + 1], rec.h["acc_iso"][w + 3]))
    expect(sb, "clock keeps running during reset", 1, dut.acc_clk_en.value.integer)
    # held although ext_idle drops after it was applied
    pins.force("ext_idle", 0)
    await env.cycles(5)
    expect(sb, "applied reset is not withdrawn when the port becomes busy", 1, dut.acc_rst_req.value.integer)
    pins.force("ext_idle", 1)
    o = await rb.write(A["ACC_CTRL"], 0x1)  # release
    w = o.t_issue
    await env.cycles(3)
    expect(sb, "release is immediate (one stage after ACC_CTRL)", (1, 0), (rec.h["acc_rst_req"][w + 1], rec.h["acc_rst_req"][w + 2]))
    # reset requested while the external port is busy: deferred until idle
    pins.force("ext_idle", 0)
    await env.cycles(3)
    await rb.write(A["ACC_CTRL"], 0x3)
    await env.cycles(8)
    expect(sb, "reset deferred while a transaction is outstanding", 0, dut.acc_rst_req.value.integer)
    pins.force("ext_idle", 1)
    await env.cycles(4)
    expect(sb, "reset applied once the port is idle", 1, dut.acc_rst_req.value.integer)
    await rb.write(A["ACC_CTRL"], 0x1)
    await env.cycles(4)
    # explicit ISO bit, RAS fatal isolation, accelerator-in-reset
    expect(sb, "no isolation in the normal state", 0, dut.acc_iso.value.integer)
    await rb.write(A["ACC_CTRL"], 0x5)  # CLK_EN | ISO
    await env.cycles(3)
    s = (await rb.read(A["ACC_STATUS"])).rdata
    expect(sb, "ISO bit isolates, clock stays on", (1, 1, 0), (dut.acc_iso.value.integer, dut.acc_clk_en.value.integer, s >> 7 & 1))
    await rb.write(A["ACC_CTRL"], 0x1)
    await env.cycles(3)
    pins.force("fatal_iso", 1)
    await env.cycles(2)
    s = (await rb.read(A["ACC_STATUS"])).rdata
    expect(sb, "fatal_iso isolates and is reported", (1, 1), (dut.acc_iso.value.integer, s >> 8 & 1))
    pins.force("fatal_iso", 0)
    pins.force("acc_in_reset", 1)
    await env.cycles(2)
    s = (await rb.read(A["ACC_STATUS"])).rdata
    expect(sb, "accelerator in reset isolates and is reported", (1, 1), (dut.acc_iso.value.integer, s >> 1 & 1))
    pins.force("acc_in_reset", 0)
    await env.cycles(2)
    expect(sb, "isolation gone", 0, dut.acc_iso.value.integer)
    # unit status bits are passed through
    for nm, bit in (("vec_busy", 4), ("tsu_busy", 5), ("tsu_halted", 6), ("cpu_sleep", None)):
        pins.force(nm, 1)
        await env.cycles(2)
        s = (await rb.read(A["ACC_STATUS"])).rdata
        if bit is not None:
            expect(sb, nm + " in ACC_STATUS", 1, s >> bit & 1)
        else:
            expect(sb, "CC_STATE reports CPU in WFI", 1, (await rb.read(A["CC_STATE"])).rdata)
        pins.force(nm, 0)
    # sleep counter
    n0 = (await rb.read(A["SLEEP_CYC"])).rdata
    pins.force("cpu_sleep", 1)
    await env.cycles(37)
    pins.force("cpu_sleep", 0)
    await env.cycles(4)
    n1 = (await rb.read(A["SLEEP_CYC"])).rdata
    expect(sb, "SLEEP_CYC counts the sleeping cycles", 37, n1 - n0)
    finish(env, sb, "reset_isolation_directed", chk)


@cocotb.test()
async def acc_ctrl_fields(dut):
    """Only ACC_CTRL[2:0] are writable; every value reads back masked; upper bits ignored."""
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)
    for v in (0, 1, 2, 3, 4, 5, 6, 7, 0xFFFFFFF8, 0xFFFFFFFF, 0x80000001, 0x00000008):
        await rb.write(A["ACC_CTRL"], v)
        expect(sb, "ACC_CTRL 0x%x reads back [2:0]" % v, v & 7, (await rb.read(A["ACC_CTRL"])).rdata)
    await rb.write(A["ACC_CTRL"], 1)
    finish(env, sb, "acc_ctrl_fields", chk)


@cocotb.test()
async def unaligned_probe(dut):
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)
    ops = []
    for base in (0x000, 0x004, 0x008, 0x014):
        for off in (1, 2, 3):
            ops.append(rb.write_op(base + off, 0x7))
            ops.append(rb.read_op(base + off))
    await drain(env, rb)
    for o in ops:
        expect(sb, "unaligned access refused", True, o.err, "%s 0x%x" % ("write" if o.write else "read", o.addr))
    expect(sb, "unaligned ACC_CTRL write had no effect", 1, (await rb.read(A["ACC_CTRL"])).rdata)
    finish(env, sb, "unaligned_probe", chk)


def pin_profile(pins, phase):
    pins.set("ext_idle", "hold", 1)
    for k in ("cpu_sleep", "vec_busy", "tsu_busy", "tsu_halted", "fatal_iso", "acc_in_reset"):
        pins.set(k, "off")
    if phase == 0:
        pins.set("cpu_sleep", "level", 0.05)
    elif phase == 1:
        pins.set("vec_busy", "level", 0.03)
        pins.set("tsu_busy", "level", 0.02)
        pins.set("ext_idle", "level", 0.08)
    elif phase == 2:
        for k in ("cpu_sleep", "vec_busy", "tsu_busy", "tsu_halted", "fatal_iso", "acc_in_reset"):
            pins.set(k, "level", 0.1)
        pins.set("ext_idle", "level", 0.1)
    elif phase == 3:
        pins.set("ext_idle", "level", 0.03)
        pins.set("fatal_iso", "level", 0.02)
        pins.set("acc_in_reset", "level", 0.03)
    elif phase == 4:
        for k in ("cpu_sleep", "vec_busy", "tsu_busy", "tsu_halted", "fatal_iso", "acc_in_reset"):
            pins.set(k, "rand", 0.5)
        pins.set("ext_idle", "rand", 0.5)


@cocotb.test()
async def random_traffic(dut):
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)
    rng = env.seeds.child("traffic")
    n_ops = int(os.environ.get("CTL_OPS", "5000"))
    for phase in range(6):
        pin_profile(pins, phase)
        tr = RegTraffic(rng, REGS, p_reg=0.85, p_hole=0.1, p_write=[0.5, 0.4, 0.3, 0.6, 0.5, 0.35][phase])
        rb.gap.set_mode(["always", "random:0.5", "bursty:1-6", "always", "random:0.9", "random:0.3"][phase])
        tr.queue(rb, n_ops // 6)
        await drain(env, rb)
    pin_profile(pins, 5)
    queue_sweep(rb)
    await drain(env, rb)
    finish(env, sb, "random_traffic", chk)


@cocotb.test()
async def reset_traffic(dut):
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)
    rng = env.seeds.child("rst")
    tr = RegTraffic(rng, REGS, p_reg=0.9, p_hole=0.05, p_write=0.5)
    for rnd in range(10):
        pin_profile(pins, rng.randrange(5))
        tr.queue(rb, 100 + rng.randrange(150))
        await env.until(lambda: len(rb.queue) < 20, 30000, "traffic running")
        n0 = rst.n_pulses
        if rnd % 2 == 0:
            rst.pulse(length=rng.randint(1, 3), delay=rng.randint(1, 4), reason="sync-reset")
        else:
            await env.tick()
            await async_reset_midcycle(env, rst, rng.choice((1.0, 2.0, 3.0, 4.0, 6.0, 7.0, 8.5)), rng.randint(1, 3))
        await env.until(lambda: rst.n_pulses > n0, 20, "reset asserted")
        await env.until(lambda: not rst.asserted, 20, "reset release")
        await env.cycles(2)
        o = await rb.read(A["ACC_CTRL"])
        expect(sb, "ACC_CTRL back to 1 after reset", 1, o.rdata)
        expect(sb, "counters cleared by reset (small)", (True, True), ((await rb.read(A["SLEEP_CYC"])).rdata < 16, (await rb.read(A["GATED_CYC"])).rdata < 16))
    pin_profile(pins, 5)
    finish(env, sb, "reset_traffic", chk)


@cocotb.test()
async def counter_width(dut):
    """SLEEP_CYC / GATED_CYC are wide counters: run past 16 bits (65 545 sleeping cycles, then the same gated) -- long test."""
    env, rst, rb, pins, rec, sb, model, chk = await go(dut, SEED)
    pins.force("cpu_sleep", 1)
    await rb.write(A["ACC_CTRL"], 0)  # clock requested off, idle: gating starts
    await env.cycles(65545)
    o = await rb.read(A["SLEEP_CYC"])
    o2 = await rb.read(A["GATED_CYC"])
    expect(sb, "SLEEP_CYC beyond 16 bits", True, o.rdata > 65536)
    expect(sb, "GATED_CYC beyond 16 bits", True, o2.rdata > 65536)
    pins.force("cpu_sleep", 0)
    await rb.write(A["ACC_CTRL"], 1)
    finish(env, sb, "counter_width", chk)
