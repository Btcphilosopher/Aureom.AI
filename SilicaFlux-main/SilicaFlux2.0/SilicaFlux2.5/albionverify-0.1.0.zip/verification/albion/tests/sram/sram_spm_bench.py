"""Bench components for ``hpc_scratchpad`` (direct mode, QUEUE_DEPTH = 0): cycle-exact checker against
``albionverify.models.sram_spm.SpmModel`` (written from rtl/hpc_m04_scratchpad/docs/01-03).

Per edge the checker predicts: every port's req_ready, ev_accept/issue/conflict/credit_stall/error, ev_bank_ops and
ev_bank_conflict of every bank, every response (valid, data, err, err_code, we, tag) and, periodically and at the end
of each phase, every perf_* counter (saturating, cleared by reset).
"""
from __future__ import annotations

import random
from collections import deque
from dataclasses import dataclass
from typing import Any, Deque, Dict, List, Optional

from albionverify.bus.reqrsp import Req, SRAMCORE_NAMES, make_port
from albionverify.core import Agent, Env
from albionverify.coverage import CoverGroup
from albionverify.models.sram_core import ExpRsp
from albionverify.models.sram_spm import ARB_FIXED, ARB_RR, ERR_ALIGN, ERR_OK, ERR_RANGE, ERR_STROBE, MAP_HIGH, MAP_LOW, MAP_XOR, PORT_1R1W, PORT_1RW, PORT_2RW, SReq, SpmExp, SpmModel
from albionverify.reset import ResetSequencer
from albionverify.scoreboard import Scoreboard

from sram.sram_bench import BUCKETS, PortRead, SramMaster, bucket, params, pattern_word, rand_mask, read_port

SPM_NAMES = dict(SRAMCORE_NAMES, strb="req_wstrb", id="req_tag", rid="rsp_tag")

import json
import os

# The parameters the build used, captured once at import (see build_spm: BASE_ADDR is a 64-bit parameter that VPI reads as 0).
ORIG_PARAMS: Dict[str, Any] = json.loads(os.environ.get("ALBION_PARAMS", "{}"))


@dataclass
class SpmCfg:
    np: int
    cap: int
    nb: int
    dw: int
    aw: int
    base: int
    rl: int
    byte_we: int
    pm: int
    map: int
    arb: int
    fd: int
    wa: int
    tag_w: int
    cnt_w: int

    @property
    def nbytes(self) -> int:
        return self.dw // 8

    @property
    def words(self) -> int:
        return self.cap // self.nbytes

    @property
    def bank_depth(self) -> int:
        return self.words // self.nb

    @staticmethod
    def from_params(P: Dict[str, Any]) -> "SpmCfg":
        rl = int(P.get("READ_LATENCY", 1))
        return SpmCfg(int(P.get("NUM_PORTS", 2)), int(P.get("CAPACITY_BYTES", 65536)), int(P.get("NUM_BANKS", 2)), int(P.get("DATA_WIDTH", 32)),
                      int(P.get("ADDR_WIDTH", 32)), int(P.get("BASE_ADDR", 0)), rl, int(P.get("BYTE_WE", 1)), int(P.get("PORT_MODE", 0)), int(P.get("MAP", 0)),
                      int(P.get("ARB", 0)), int(P.get("RSP_FIFO_DEPTH", rl + 1)), int(P.get("WRITE_ACK", 1)), int(P.get("TAG_W", 8)), int(P.get("CNT_W", 32)))

    def model(self) -> SpmModel:
        return SpmModel(self.np, self.cap, self.nb, self.dw, self.aw, self.base, self.rl, self.byte_we, self.pm, self.map, self.arb, self.fd, self.wa, self.tag_w, self.cnt_w)

    def addr_of(self, word: int, off: int = 0) -> int:
        return self.base + word * self.nbytes + off

    def word_in_bank(self, bank: int, row: int) -> int:
        """Word number of (bank, row) under the documented map (inverse of the decode)."""
        B = self.nb
        if B == 1:
            return row
        if self.map == MAP_LOW:
            return row * B + bank
        if self.map == MAP_HIGH:
            return bank * self.bank_depth + row
        # XOR: bank = (w mod B) ^ ((w div B) mod B), row = w div B  =>  (w mod B) = bank ^ (row mod B)
        return row * B + (bank ^ (row % B))


# --------------------------------------------------------------------------- coverage


def cover_spm(cfg: SpmCfg) -> Dict[str, CoverGroup]:
    NP, NB = cfg.np, cfg.nb
    multi = NP >= 2
    ops = ["read", "write" if cfg.wa else "write_posted", "err_read", "err_write"]
    classes = (["first_word", "last_word", "bank_first_row", "bank_last_row", "mid", "oor_above"] + (["oor_below"] if cfg.base else []) + ["oor_alias", "misaligned"]
               + (["strobe"] if not cfg.byte_we else []))
    cg = CoverGroup("spm.txn", "transaction types x address classes (map boundaries, out of range, alias, misaligned, strobe)")
    cg.point("op", ops)
    cg.point("aclass", classes)
    errc = {"oor_above", "oor_below", "oor_alias", "misaligned", "strobe"}
    cg.cross("op_x_class", ["op", "aclass"], ignore=lambda b: b[0].startswith("err") != (b[1] in errc) or (b[0] == "err_read" and b[1] == "strobe"))

    ce = CoverGroup("spm.err", "error codes x operation")
    ce.point("code", ["range", "align"] + (["strobe"] if not cfg.byte_we else []))
    ce.point("op", ["read", "write"])
    ce.cross("code_x_op", ["code", "op"], ignore=lambda b: b[0] == "strobe" and b[1] == "read")  # STROBE only applies to writes

    cm = CoverGroup("spm.mask", "write strobe classes (accepted in-range writes)")
    masks: Dict[str, Any] = {"all": (1 << cfg.nbytes) - 1}
    if cfg.byte_we:
        masks["zero"] = 0
        for l in range(min(cfg.nbytes, 8)):
            masks["lane%d" % l] = 1 << l
        if cfg.nbytes >= 3:
            masks["sparse"] = lambda v, f=(1 << cfg.nbytes) - 1: v not in (0, f) and bin(v).count("1") > 1
    cm.point("strobe", masks)

    cc = CoverGroup("spm.contention", "bank conflicts vs parallel access, port-model slot usage")
    cc.point("max_contenders", list(range(0, NP + 1)))
    cc.point("parallel_ops", list(range(0, min(NP, NB * (2 if cfg.pm != PORT_1RW else 1)) + 1)))
    slots = 1 if cfg.pm == PORT_1RW else 2
    # c = most eligible ports on one bank, p = accesses granted this cycle: the c - min(c, slots) losers of the busiest bank cannot count
    cc.cross("contenders_x_ops", ["max_contenders", "parallel_ops"],
             ignore=lambda b: (int(b[0]) == 0) != (int(b[1]) == 0) or int(b[1]) > NB * min(int(b[0]), slots) or int(b[1]) > NP - (int(b[0]) - min(int(b[0]), slots)))
    if cfg.pm != PORT_1RW and multi:
        cc.point("dual_slot", ["one", "two"])  # bank used with one or with both slots in a cycle
        cc.point("same_row_hazard", ["stalled"])  # an eligible port lost its slot only because of the same-row rule

    ca = CoverGroup("spm.arb", "arbitration outcome with contention")
    if multi:
        winners = list(range(NP)) if cfg.arb == ARB_RR else list(range(NP - 1))
        ca.point("winner", winners)
        ca.point("contenders", list(range(2, NP + 1)))
        waits = ["0", "1", "2", "3-5", "6+"] if cfg.arb == ARB_FIXED else [str(i) for i in range(NP)]
        ca.point("wait", {w: (int(w) if w.isdigit() else ((3, 5) if w == "3-5" else (lambda v: v >= 6))) for w in waits})  # cycles lost before the grant
    cv = CoverGroup("spm.events", "event outputs observed (each must pulse at least once, with and without the others)")
    cv.point("ev", ["accept", "issue", "conflict", "credit_stall", "error", "bank_conflict", "bank_ops2" if cfg.pm != PORT_1RW else "bank_ops1"])

    cf = CoverGroup("spm.flow", "back-pressure")
    cf.point("req_stall", BUCKETS)
    cf.point("rsp_stall", BUCKETS if cfg.fd else ["0"])
    if cfg.fd:
        cf.point("credit_full", ["blocked"])

    ci = CoverGroup("spm.tag", "tag echo")
    mx = (1 << cfg.tag_w) - 1
    ci.point("tag", {"zero": 0, "max": mx, "other": (lambda v, m=mx: 0 < v < m)} if mx > 1 else {"zero": 0, "max": mx})

    cr = CoverGroup("spm.reset", "reset with responses in flight")
    cr.point("outstanding", ["0", "1", "2+"])
    cr.point("kind", ["sync", "async"])

    cn = CoverGroup("spm.counters", "performance counters compared")
    cn.point("saturated", ["no", "yes"] if cfg.cnt_w <= 8 else ["no"])
    return {g.name: g for g in (cg, ce, cm, cc, ca, cv, cf, ci, cr, cn)}


# --------------------------------------------------------------------------- checker


class SpmChecker(Agent):
    def __init__(self, name: str, ports: List[Dict[str, Any]], sig: Dict[str, Any], cfg: SpmCfg, sb: Scoreboard, cov: Dict[str, CoverGroup]):
        super().__init__(name)
        self.ports, self.sg, self.cfg, self.sb, self.cov = ports, sig, cfg, sb, cov
        self.m = cfg.model()
        self.n_checks = 0
        self.n_accept = [0] * cfg.np
        self.n_rsp = [0] * cfg.np
        self.n_cancelled = 0
        self.log: Deque[str] = deque(maxlen=14)
        self._stall_pay: List[Optional[tuple]] = [None] * cfg.np
        self._lost_run = [0] * cfg.np
        self.max_lost_run = [0] * cfg.np
        self.conflict_cycles = 0
        self.masters: List[SramMaster] = []
        self._async_next = False
        self.counter_period = 16
        self._since_cnt = 0
        self.ev_seen: Dict[str, int] = {}
        self.grant_log: List[tuple] = []

    @property
    def drained(self) -> bool:
        return all(p.outstanding == 0 for p in self.m.ports)

    def outstanding(self) -> int:
        return sum(p.outstanding for p in self.m.ports)

    def _fail(self, msg: str) -> None:
        self.sb.fail("%s | recent: %s" % (msg, " ; ".join(self.log)))

    def _cmp(self, what: str, exp: Any, got: Any, ctx: str = "") -> None:
        self.n_checks += 1
        if exp != got:
            self._fail("%s mismatch%s: expected 0x%x, got 0x%x" % (what, (" [%s]" % ctx) if ctx else "", int(exp), int(got)))

    def _cs(self, g: str, **kw) -> None:
        cg = self.cov.get(g)
        if cg is not None:
            cg.sample(**kw)

    def _bits(self, name: str, n: int, w: int = 1) -> List[int]:
        v = self.sg[name].read()
        return [(v >> (i * w)) & ((1 << w) - 1) for i in range(n)]

    def aclass(self, addr: int, d, req: Req) -> str:
        cfg = self.cfg
        if d.code == ERR_RANGE:
            if addr < cfg.base:
                return "oor_below"
            return "oor_above" if addr < cfg.base + 2 * cfg.cap else "oor_alias"
        if d.code == ERR_ALIGN:
            return "misaligned"
        if d.code == ERR_STROBE:
            return "strobe"
        w = d.word
        if w == 0:
            return "first_word"
        if w == cfg.words - 1:
            return "last_word"
        if cfg.nb > 1:
            if d.row == cfg.bank_depth - 1:
                return "bank_last_row"
            if d.row == 0:
                return "bank_first_row"
        return "mid"

    # ---- agent
    def sample(self) -> None:
        env, c, m, cfg = self.env, self.env.cycle, self.m, self.cfg
        S: List[PortRead] = [read_port(p) for p in self.ports]
        if env.in_reset:
            if c > 1:
                for i, s in enumerate(S):
                    self._cmp("req_ready[%d] while rst_n low" % i, 0, s.rdy)
                    self._cmp("rsp_valid[%d] while rst_n low" % i, 0, s.rv)
                for ev in ("ev_accept", "ev_issue", "ev_conflict", "ev_credit_stall", "ev_error", "ev_bank_conflict", "busy"):
                    self._cmp("%s while rst_n low" % ev, 0, self.sg[ev].read())
                cnt = [self.sg["perf_cycles"].read()] + [self.sg[k].read() for k in ("perf_accept", "perf_issue", "perf_complete", "perf_conflict", "perf_error", "perf_wait", "perf_bank_ops")]
                self._cmp("performance counters while rst_n low", 0, sum(cnt))
            self._stall_pay = [None] * cfg.np
            return
        live = m.begin_edge()
        # ---------------- performance counters (values at this edge = events of all earlier edges since reset)
        self._since_cnt += 1
        if self._since_cnt >= self.counter_period:
            self._since_cnt = 0
            self.check_counters()
        # busy (doc 01 sec. 3): "a request is queued or a response outstanding" -- queues do not exist in direct mode
        self._cmp("busy", int(self.outstanding() > 0), self.sg["busy"].read(), "outstanding=%d" % self.outstanding())
        # ECC_MODE = NONE: no integrity events, zero syndrome
        self._cmp("ev_ecc_err", 0, self.sg["ev_ecc_err"].read())
        self._cmp("rsp_ecc_syn", 0, self.sg["rsp_ecc_syn"].read())
        self._cmp("perf_ecc_err", 0, self.sg["perf_ecc_err"].read())
        # ---------------- responses
        heads: List[Optional[SpmExp]] = []
        codes = self._bits("rsp_err_code", cfg.np, 3)
        for i, s in enumerate(S):
            head = m.ports[i].head_valid(c)
            heads.append(head)  # type: ignore[arg-type]
            if head is None:
                self._cmp("rsp_valid[%d] (nothing due)" % i, 0, s.rv, "unsolicited / early response")
            else:
                self._cmp("rsp_valid[%d] (response due since cycle %d, kind %s)" % (i, head.due, head.kind), 1, s.rv, "missing / late response")
                if s.rv:
                    ctx = "port %d %s addr 0x%x" % (i, head.kind, head.addr)
                    self._cmp("rsp_err[%d]" % i, int(head.err), s.rerr, ctx)
                    self._cmp("rsp_err_code[%d]" % i, head.code, codes[i], ctx)  # type: ignore[attr-defined]
                    self._cmp("rsp_we[%d]" % i, int(head.we), s.rwe, ctx)
                    self._cmp("rsp_tag[%d]" % i, head.id, s.rid, ctx)
                    err = m.mem.check(head.snap, s.rdata, pin=bool(s.rr)) if head.kind == "read" else m.check_rsp_data(head, s.rdata)  # type: ignore[arg-type]
                    self.n_checks += 1
                    if err:
                        self._fail("rsp_rdata[%d] %s (kind %s, tag %d)" % (i, err, head.kind, head.id))
            pay = (s.rdata, s.rerr, s.rwe, s.rid, codes[i]) if s.rv else None
            if self._stall_pay[i] is not None:
                self.n_checks += 1
                if pay != self._stall_pay[i]:
                    self._fail("port %d response not held stable under back-pressure: %s -> %s" % (i, self._stall_pay[i], pay))
            self._stall_pay[i] = pay if (s.rv and not s.rr) else None
        # ---------------- requests + events (exact prediction for EVERY cycle: req_ready = ev_issue = grant or error-issue)
        reqs = [SReq(bool(s.v), bool(s.we), s.addr, s.wdata, s.wmask, s.id) for s in S]
        pred = m.predict(live, reqs)
        ev = {k: self._bits(k, cfg.np) for k in ("ev_accept", "ev_issue", "ev_conflict", "ev_credit_stall", "ev_error")}
        evb_ops = self._bits("ev_bank_ops", cfg.nb, 2)
        evb_cf = self._bits("ev_bank_conflict", cfg.nb)
        decs = [m.decode(r.addr, r.we, r.wstrb) for r in reqs]
        for i, s in enumerate(S):
            if s.v:
                self.n_checks += 1
                if int(pred.ready[i]) != s.rdy:
                    self._fail("req_ready[%d] mismatch: expected %d, got %d (live=%d we=%d addr=0x%x code=%d bank=%d row=%d outstanding=%d/%d ptr=%s)" % (
                        i, int(pred.ready[i]), s.rdy, int(live), s.we, s.addr, decs[i].code, decs[i].bank, decs[i].row, m.ports[i].outstanding, cfg.fd, m.ptr))
            else:
                self._cmp("req_ready[%d] with req_valid low" % i, 0, s.rdy)
            self._cmp("ev_accept[%d]" % i, int(bool(s.v and pred.ready[i])), ev["ev_accept"][i])
            self._cmp("ev_issue[%d]" % i, int(pred.ready[i]), ev["ev_issue"][i])
            self._cmp("ev_conflict[%d]" % i, int(pred.conflict[i]), ev["ev_conflict"][i])
            self._cmp("ev_credit_stall[%d]" % i, int(pred.credit_stall[i]), ev["ev_credit_stall"][i])
            self._cmp("ev_error[%d]" % i, int(pred.error[i]), ev["ev_error"][i])
        for b in range(cfg.nb):
            self._cmp("ev_bank_ops[%d]" % b, pred.bank_ops[b], evb_ops[b])
            self._cmp("ev_bank_conflict[%d]" % b, int(pred.bank_conflict[b]), evb_cf[b])
        # ---------------- hand-overs, acceptances, bookkeeping
        completed = [False] * cfg.np
        for i, s in enumerate(S):
            if heads[i] is not None and s.rv and s.rr:
                out = m.ports[i].pop()
                completed[i] = True
                self.sb.complete("p%d" % i, out.key)
                self.n_rsp[i] += 1
                self._cs("spm.flow", rsp_stall=bucket(max(0, c - out.due)))
                env.digest.event("spm.rsp", i, c, s.rdata, s.rerr, s.rwe, s.rid, codes[i])
        for i, s in enumerate(S):
            if credit_blocked(m, pred, i, reqs[i], live) and cfg.fd:
                self._cs("spm.flow", credit_full="blocked")
        n_lost = 0
        for i, s in enumerate(S):
            if s.v and pred.ready[i]:
                d = decs[i]
                e = m.accept(c, i, reqs[i], pred)
                self.n_accept[i] += 1
                self.log.append("c%d p%d %s a=0x%x%s" % (c, i, "W" if s.we else "R", s.addr, "" if d.ok else " ERR%d" % d.code))
                env.digest.event("spm.acc", i, c, int(s.we), s.addr, s.wdata if s.we else 0, s.wmask if s.we else 0, s.id)
                if e is not None:
                    self.sb.accept("p%d" % i, e.key, e)
                self._sample_accept(i, s, d, c)
                if d.ok:
                    self.grant_log.append((c, d.bank, i))
            if pred.conflict[i]:
                n_lost += 1
                self._lost_run[i] += 1
                self.max_lost_run[i] = max(self.max_lost_run[i], self._lost_run[i])
            else:
                if s.v and pred.ready[i] and decs[i].ok:
                    self._cs("spm.arb", **({"wait": self._lost_run[i]} if cfg.np >= 2 else {}))
                self._lost_run[i] = 0
        if n_lost:
            self.conflict_cycles += 1
        self._sample_cycle(pred, reqs, decs, ev, evb_ops, evb_cf)
        m.end_edge(pred, reqs, completed)

    def force_counter_check(self) -> None:
        self._since_cnt = self.counter_period

    def check_counters(self) -> None:
        cfg, m = self.cfg, self.m
        names = {"perf_accept": "accept", "perf_issue": "issue", "perf_complete": "complete", "perf_conflict": "conflict", "perf_error": "error", "perf_wait": "wait"}
        self._cmp("perf_cycles", m.counters["cycles"][0], self.sg["perf_cycles"].read())
        for sg, key in names.items():
            got = self._bits(sg, cfg.np, cfg.cnt_w)
            for p in range(cfg.np):
                self._cmp("%s[%d]" % (sg, p), m.counters[key][p], got[p])
        got = self._bits("perf_bank_ops", cfg.nb, cfg.cnt_w)
        for b in range(cfg.nb):
            self._cmp("perf_bank_ops[%d]" % b, m.counters["bank_ops"][b], got[b])
        mx = (1 << cfg.cnt_w) - 1
        self._cs("spm.counters", saturated="yes" if m.counters["cycles"][0] >= mx else "no")

    def _sample_accept(self, i: int, s: PortRead, d, c: int) -> None:
        cfg = self.cfg
        we = bool(s.we)
        op = ("err_write" if we else "err_read") if not d.ok else (("write" if cfg.wa else "write_posted") if we else "read")
        self._cs("spm.txn", op=op, aclass=self.aclass(s.addr, d, None))
        if d.ok:
            if we:
                self._cs("spm.mask", strobe=s.wmask)
        else:
            self._cs("spm.err", code={ERR_RANGE: "range", ERR_ALIGN: "align", ERR_STROBE: "strobe"}[d.code], op="write" if we else "read")
        self._cs("spm.tag", tag=s.id)
        ms = self.masters[i] if self.masters else None
        self._cs("spm.flow", req_stall=bucket(ms.last_req_stall if ms is not None else 0))

    def _sample_cycle(self, pred, reqs, decs, ev, evb_ops, evb_cf) -> None:
        cfg = self.cfg
        elig: Dict[int, List[int]] = {b: [] for b in range(cfg.nb)}
        for p, r in enumerate(reqs):
            if r.valid and decs[p].ok and (pred.ready[p] or pred.conflict[p]):
                elig[decs[p].bank].append(p)  # eligible = granted or lost
        self._cs("spm.contention", max_contenders=max((len(v) for v in elig.values()), default=0), parallel_ops=sum(pred.bank_ops))
        multi_slot = cfg.pm != PORT_1RW and cfg.np >= 2
        for b in range(cfg.nb):
            slots = pred.slots[b]
            if multi_slot and pred.bank_ops[b]:
                self._cs("spm.contention", dual_slot="two" if pred.bank_ops[b] == 2 else "one")
            if multi_slot:
                for p in elig[b]:
                    if p in slots.values():
                        continue
                    if cfg.pm == PORT_1R1W:
                        free = ("a" not in slots) if reqs[p].we else ("b" not in slots)
                    else:
                        free = "b" not in slots
                    if free:  # a slot of the right kind was free: the port lost only because of the same-row rule
                        self._cs("spm.contention", same_row_hazard="stalled")
            if len(elig[b]) >= 2 and cfg.np >= 2 and pred.first.get(b) is not None:
                self._cs("spm.arb", winner=pred.first[b], contenders=len(elig[b]))
        top = 2 if cfg.pm != PORT_1RW else 1
        flags = {"accept": any(ev["ev_accept"]), "issue": any(ev["ev_issue"]), "conflict": any(ev["ev_conflict"]), "credit_stall": any(ev["ev_credit_stall"]),
                 "error": any(ev["ev_error"]), "bank_conflict": any(evb_cf), ("bank_ops2" if top == 2 else "bank_ops1"): any(o == top for o in evb_ops)}
        for k, v in flags.items():
            if v:
                self._cs("spm.events", ev=k)

    def mark_async(self) -> None:
        self._async_next = True

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            n = self.outstanding()
            self._cs("spm.reset", outstanding="0" if n == 0 else ("1" if n == 1 else "2+"), kind="async" if self._async_next else "sync")
            gone = self.m.reset()
            self.sb.cancel(None, "reset")
            self.n_cancelled += len(gone)
            self._async_next = False
            self._lost_run = [0] * self.cfg.np
            self._stall_pay = [None] * self.cfg.np
            self._since_cnt = 0
            self.env.digest.event("spm.reset", self.env.cycle, len(gone))

    def summary(self) -> dict:
        return {"accepted": list(self.n_accept), "responses": list(self.n_rsp), "cancelled": self.n_cancelled, "checks": self.n_checks,
                "conflict_cycles": self.conflict_cycles, "max_lost_run": list(self.max_lost_run), "model_stats": dict(self.m.stats)}


def credit_blocked(m: SpmModel, pred, i: int, r: SReq, live: bool) -> bool:
    d = m.decode(r.addr, r.we, r.wstrb)
    return bool(live and r.valid and not pred.ready[i] and not m.ports[i].credit_free() and m.needs_rsp(r.we, d.ok))


# --------------------------------------------------------------------------- traffic


def rand_sreq(rng: random.Random, cfg: SpmCfg, port: int, profile: str, read_frac: float, err_frac: float, state: Dict[str, Any]) -> Req:
    W = cfg.words
    k = rng.random()
    off = 0
    if k < err_frac:
        kind = rng.choice(["above", "below", "alias", "misaligned", "strobe"])
        w = rng.randrange(W)
        if kind == "above":
            addr = cfg.base + cfg.cap + rng.randrange(0, cfg.cap, cfg.nbytes)
        elif kind == "below" and cfg.base >= cfg.nbytes:
            addr = cfg.base - cfg.nbytes * rng.randint(1, min(8, cfg.base // cfg.nbytes))
        elif kind == "alias":  # same low bits as a valid word, different upper address bits (never an alias)
            hi = rng.choice([x for x in range(1 << max(0, cfg.aw - (cfg.cap.bit_length() - 1))) if (x << (cfg.cap.bit_length() - 1)) != (cfg.base >> (cfg.cap.bit_length() - 1) << (cfg.cap.bit_length() - 1))] or [0])
            addr = ((hi << (cfg.cap.bit_length() - 1)) | (w * cfg.nbytes)) & ((1 << cfg.aw) - 1)
        elif kind == "misaligned" and cfg.nbytes > 1:
            addr = cfg.addr_of(w, rng.randrange(1, cfg.nbytes))
        else:
            addr = cfg.addr_of(w)
            if not cfg.byte_we:
                strb = rng.randrange(0, (1 << cfg.nbytes) - 1)  # partial strobe
                return Req(True, addr, pattern_word(rng, cfg.dw, 0), strb, rng.getrandbits(cfg.tag_w))
        addr &= (1 << cfg.aw) - 1
        we = rng.random() >= read_frac
        return Req(we, addr, pattern_word(rng, cfg.dw, 0) if we else 0, rand_mask(rng, cfg.nbytes) if we else 0, rng.getrandbits(cfg.tag_w))
    if profile == "same_bank":
        w = cfg.word_in_bank(state.get("bank", 0), rng.randrange(cfg.bank_depth))
    elif profile == "parallel":
        w = cfg.word_in_bank(port % cfg.nb, rng.randrange(cfg.bank_depth))
    elif profile == "hot_word":
        w = state.get("word", 0)
    elif profile == "hot_row":  # all ports on the same row of one bank (hazards for 1R1W / 2RW), different words only by bank
        w = cfg.word_in_bank(state.get("bank", 0), state.get("row", 0))
    elif profile == "boundary":
        b = rng.randrange(cfg.nb)
        w = rng.choice([0, 1, W - 1, W - 2, cfg.word_in_bank(b, 0), cfg.word_in_bank(b, cfg.bank_depth - 1)])
    else:
        w = rng.randrange(W)
    addr = cfg.addr_of(w)
    we = rng.random() >= read_frac
    strb = (1 << cfg.nbytes) - 1 if not cfg.byte_we else rand_mask(rng, cfg.nbytes)
    if not cfg.byte_we:
        strb = (1 << cfg.nbytes) - 1
    return Req(we, addr, pattern_word(rng, cfg.dw, 0) if we else 0, strb if we else 0, rng.getrandbits(cfg.tag_w))


@dataclass
class SpmBench:
    env: Env
    rst: ResetSequencer
    ms: List[SramMaster]
    chk: SpmChecker
    sb: Scoreboard
    cfg: SpmCfg
    cov: Dict[str, CoverGroup]

    async def drain(self, max_cycles: int = 30000, what: str = "drain") -> None:
        await self.env.until(lambda: all(m.idle for m in self.ms) and self.chk.drained and not self.rst.asserted, max_cycles, what)

    async def settle(self) -> None:
        """Let the counters catch up with the last events and compare them (two idle cycles)."""
        self.chk.force_counter_check()
        await self.env.cycles(2)

    def finish(self, test: str, **extra) -> None:
        self.sb.finalize()
        self.env.finalize()
        self.env.coverage.extend(self.cov.values())
        self.env.write_result(test, scoreboard=self.sb.summary(), **extra)


def build_spm(dut, seed: int, name: str = "spm", req_thr: str = "always", rsp_thr: str = "always", initial_reset: int = 4) -> SpmBench:
    cfg = SpmCfg.from_params(ORIG_PARAMS)
    if cfg.fd == 0:
        rsp_thr = "always"
    # Framework limitation (docs/framework_requests_sram.md): Env.verify_params reads parameters through VPI, which returns 0
    # for BASE_ADDR (declared logic [63:0]) even when its value fits in 32 bits, and would report a false "parameter lost".
    # BASE_ADDR is therefore withheld from that check and proven behaviourally (window edges, below-BASE and alias requests).
    os.environ["ALBION_PARAMS"] = json.dumps({k: v for k, v in ORIG_PARAMS.items() if k != "BASE_ADDR"})
    env = Env(dut, name=name, seed=seed)
    rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=initial_reset))
    ports, ms = [], []
    for i in range(cfg.np):
        p = make_port(env, SPM_NAMES, index=i, flat=True, AW=cfg.aw, DW=cfg.dw, IDW=cfg.tag_w, strb_w=cfg.nbytes)
        ports.append(p)
        ms.append(env.add(SramMaster("p%d" % i, p, dw=cfg.dw, mw=cfg.nbytes, aw=cfg.aw, idw=cfg.tag_w, rng=env.seeds.child("p%d" % i), req_throttle=req_thr, rsp_throttle=rsp_thr)))
    sb = Scoreboard(env, "spm")
    cov = cover_spm(cfg)
    sg = {k: env.sig(k) for k in ("rsp_err_code", "ev_accept", "ev_issue", "ev_conflict", "ev_credit_stall", "ev_error", "ev_bank_ops", "ev_bank_conflict",
                                 "perf_cycles", "perf_accept", "perf_issue", "perf_complete", "perf_conflict", "perf_wait", "perf_error", "perf_bank_ops",
                                 "busy", "ev_ecc_err", "rsp_ecc_syn", "perf_ecc_err")}
    chk = env.add(SpmChecker("chk", ports, sg, cfg, sb, cov))
    chk.masters = ms
    env.tie("perf_clear")
    return SpmBench(env, rst, ms, chk, sb, cfg, cov)
