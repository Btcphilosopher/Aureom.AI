"""cocotb bench for ``sram_bank_controller`` (several masters x several single-port banks).

Stimulus only; ``sram_bank_bench.BankChecker`` predicts every edge (per-bank arbitration winner, each master's
req_ready, m_stall_conflict, rsp_valid, response payload and read data) with ``albionverify.models.sram_bank``
(written from rtl/sramlib/docs/mem/03_banking.md and the interface spec).
"""
import os

import cocotb

from sram.sram_bank_bench import BankCfg, build_bank, rand_breq
from sram.sram_bench import params

SEED = lambda: int(os.environ.get("ALBION_SEED", "1"))


async def up(b):
    await b.env.start()
    await b.env.until(lambda: not b.rst.asserted, 50, "reset release")
    await b.env.cycles(2)


def uniq(cfg: BankCfg, w: int, salt: int = 0) -> int:
    return (((w + 1) * 0x9E3779B97F4A7C15) ^ (salt * 0xC2B2AE3D27D4EB4F)) & ((1 << cfg.dw) - 1)


def ids(cfg: BankCfg, k: int) -> int:
    return k & ((1 << cfg.idw) - 1)


# --------------------------------------------------------------------------- directed


@cocotb.test()
async def map_integrity(dut):
    """Every word written (unique data) by one master and read back by another, forwards and backwards: any
    bank-decode / row aliasing or lost write shows up as wrong data.  Then lane-masked partial writes."""
    b = build_bank(dut, SEED(), rsp_thr="random:0.85")
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("map")
    await up(b)
    T, NM = cfg.total, cfg.nm
    for w in range(T):
        ms[w % NM].write(cfg.addr_of(w), uniq(cfg, w), cfg.full_mask, id=ids(cfg, w))
    await b.drain(40000, "write every word")
    for w in range(T):
        ms[(w + 1) % NM].read(cfg.addr_of(w), id=ids(cfg, w + 3))
    await b.drain(40000, "read every word")
    for w in reversed(range(T)):
        ms[(w * 7 + 2) % NM].read(cfg.addr_of(w), id=ids(cfg, w + 5))
    await b.drain(40000, "read backwards")
    for w in rng.sample(range(T), min(T, 24)):  # partial writes: every lane alone on a few words, then random masks
        for l in range(cfg.mw):
            ms[rng.randrange(NM)].write(cfg.addr_of(w), uniq(cfg, w, l + 1), 1 << l)
        for _ in range(6):
            ms[rng.randrange(NM)].write(cfg.addr_of(w), rng.getrandbits(cfg.dw), rng.getrandbits(cfg.mw))
        ms[rng.randrange(NM)].read(cfg.addr_of(w))
    await b.drain(20000, "lane writes")
    b.finish("map_integrity")


@cocotb.test()
async def arbitration_order(dut):
    """All masters hammer ONE bank at the same time.  RR: within every window of NUM_MASTERS consecutive grants
    every master appears exactly once (a master is granted within NUM_MASTERS grants).  FIXED: strict priority,
    the lowest-numbered requester always wins and the others wait (starvation is allowed and documented)."""
    b = build_bank(dut, SEED())
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("arb")
    await up(b)
    NM, K = cfg.nm, 4 * cfg.nm + 3
    for bank in sorted({0, cfg.nb - 1}):
        b.chk.grant_log.clear()
        # hold every master's first request back until all queues are full so that all contend from cycle one
        for m in ms:
            m.req_thr.set_mode("never")
        for i, m in enumerate(ms):
            for k in range(K):
                m.read(cfg.addr_of(cfg.word_in_bank(bank, (i * K + k) % cfg.bd)), id=ids(cfg, i))
        await b.env.cycles(3)
        for m in ms:
            m.req_thr.set_mode("always")
        await b.drain(20000, "contention on bank %d" % bank)
        seq = [g[2] for g in b.chk.grant_log if g[1] == bank]
        assert len(seq) == NM * K, (len(seq), NM * K)
        if cfg.arb == 0:  # RR
            for i in range(0, len(seq) - NM + 1):
                win = seq[i:i + NM]
                assert len(set(win)) == NM, "a master was granted twice within %d consecutive grants: %s (position %d)" % (NM, win, i)
        else:  # FIXED priority: grants are ordered by master index while everybody keeps requesting
            assert seq == sorted(seq), "FIXED priority violated: %s" % seq[:3 * NM]
    b.finish("arbitration_order", conflict_cycles=b.chk.conflict_cycles, max_lost_run=b.chk.max_lost_run)


@cocotb.test()
async def parallel_banks(dut):
    """Masters on DIFFERENT banks proceed in parallel: no conflict flag, one access per master per cycle."""
    b = build_bank(dut, SEED())
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("par")
    await up(b)
    NM, NB = cfg.nm, cfg.nb
    K = 60
    for m in ms:
        m.req_thr.set_mode("never")
    for i, m in enumerate(ms):
        for k in range(K):
            w = cfg.word_in_bank(i % NB, rng.randrange(cfg.bd))
            (m.write(cfg.addr_of(w), rng.getrandbits(cfg.dw), cfg.full_mask) if k % 3 == 0 else m.read(cfg.addr_of(w)))
    await b.env.cycles(2)
    c0 = b.env.cycle
    for m in ms:
        m.req_thr.set_mode("always")
    await b.drain(20000, "parallel streams")
    cyc = b.env.cycle - c0
    if NM <= NB:
        assert b.chk.conflict_cycles == 0, "masters on distinct banks must never lose arbitration (%d conflict cycles)" % b.chk.conflict_cycles
        if cfg.fd == 0 or cfg.fd > cfg.rl:  # RSP_FIFO_DEPTH >= READ_LATENCY+1 sustains one access per cycle per master (spec sec. 4)
            assert cyc <= K + 2 * cfg.rl + 6, "parallel streams were serialised: %d cycles for %d requests per master" % (cyc, K)
            assert b.chk.parallel_hist.get(NM, 0) >= K - 4, b.chk.parallel_hist
    else:  # more masters than banks: ceil(NM/NB) per bank at least
        assert b.chk.conflict_cycles > 0
    b.finish("parallel_banks", cycles=cyc, parallel_hist=b.chk.parallel_hist)


@cocotb.test()
async def hot_word(dut):
    """All masters read/write the very same word: serialisation order = grant order, data and ids intact."""
    b = build_bank(dut, SEED(), rsp_thr="random:0.7")
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("hot")
    await up(b)
    w = rng.randrange(cfg.total)
    for k in range(40):
        for i, m in enumerate(ms):
            if rng.random() < 0.5:
                m.write(cfg.addr_of(w), rng.getrandbits(cfg.dw), rng.getrandbits(cfg.mw), id=ids(cfg, i + k))
            else:
                m.read(cfg.addr_of(w), id=ids(cfg, i * 3 + k))
    await b.drain(20000, "hot word")
    b.finish("hot_word", word=w)


@cocotb.test()
async def isolation_backpressure(dut):
    """A master whose consumer never takes responses runs out of credits and is held back; every other master
    keeps being served at full speed (a stalled master never blocks another master's banks)."""
    b = build_bank(dut, SEED())
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("iso")
    await up(b)
    if cfg.fd == 0 or cfg.nm < 2:
        for m in ms:
            for k in range(80):
                m.read(rng.randrange(cfg.total) << cfg.boff)
        await b.drain(20000, "no-fifo burst")
        b.finish("isolation_backpressure", mode="n/a (RSP_FIFO_DEPTH=0 or single master)")
        return
    ms[0].rsp_thr.set_mode("never")
    for k in range(cfg.fd + 8):
        ms[0].read(cfg.addr_of(rng.randrange(cfg.total)), id=ids(cfg, k))
    for m in ms[1:]:
        for k in range(120):
            m.read(cfg.addr_of(rng.randrange(cfg.total)))
    n0 = sum(b.chk.n_accept[1:])
    await b.env.cycles(60)
    assert b.chk.n_accept[0] == cfg.fd, "stalled master 0 should hold exactly RSP_FIFO_DEPTH=%d outstanding requests, got %d" % (cfg.fd, b.chk.n_accept[0])
    # an unstalled master sustains min(1, RSP_FIFO_DEPTH / (READ_LATENCY+1)) requests per cycle; bank conflicts with the others cost a bit
    ideal = 60 * min(cfg.nm - 1, cfg.nb) * min(1.0, cfg.fd / (cfg.rl + 1.0))  # bank-limited when masters outnumber banks
    got = sum(b.chk.n_accept[1:]) - n0
    assert got >= 0.5 * ideal, "other masters were blocked by master 0's stalled responses: %d accepted in 60 cycles, ideal %.0f" % (got, ideal)
    ms[0].rsp_thr.set_mode("random:0.4")
    await b.drain(30000, "release")
    b.finish("isolation_backpressure")


@cocotb.test()
async def error_requests(dut):
    """Out-of-range and misaligned requests are answered in order with rsp_err = 1 and zero data and change nothing,
    also while other masters contend for banks and while credits are scarce."""
    b = build_bank(dut, SEED(), req_thr="random:0.8", rsp_thr="random:0.6" if params().get("RSP_FIFO_DEPTH", 1) != 0 else "always")
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("err")
    await up(b)
    T = cfg.total
    for w in range(T):
        ms[w % cfg.nm].write(cfg.addr_of(w), uniq(cfg, w, 9), cfg.full_mask)
    await b.drain(30000, "fill")
    st = {"bank": 0, "word": 0}
    for k in range(400):
        i = rng.randrange(cfg.nm)
        ms[i].submit(rand_breq(rng, cfg, i, rng.choice(["uniform", "boundary", "same_bank"]), 0.5, 0.35, 0.35, st))
    await b.drain(40000, "errors")
    for w in range(T):  # nothing was corrupted by the rejected requests
        ms[w % cfg.nm].read(cfg.addr_of(w))
    await b.drain(30000, "verify")
    b.finish("error_requests", model_stats=b.chk.m.stats)


# --------------------------------------------------------------------------- random

PROFILES = ["uniform", "same_bank", "parallel", "boundary", "stride", "hot_word"]
REQ_THR = ["always", "random:0.7", "random:0.3", "bursty:1-6"]
RSP_THR = ["always", "random:0.8", "random:0.4", "bursty:1-8", "random:0.15"]


@cocotb.test()
async def random_traffic(dut):
    """Seeded random traffic from all masters: boundary/bank-biased addresses, hot banks and words, random masks,
    out-of-range / misaligned requests, independent random stalls on every request and response channel."""
    seed = SEED()
    b = build_bank(dut, seed)
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("rnd")
    await up(b)
    for phase in range(8):
        prof = rng.choice(PROFILES)
        st = {"bank": rng.randrange(cfg.nb), "word": rng.randrange(cfg.total)}
        for m in ms:
            m.req_thr.set_mode(rng.choice(REQ_THR))
            if cfg.fd:
                m.rsp_thr.set_mode(rng.choice(RSP_THR))
        rf = rng.choice([0.3, 0.5, 0.8])
        for i, m in enumerate(ms):
            for k in range(160):
                m.submit(rand_breq(rng, cfg, i, prof if rng.random() < 0.8 else "uniform", rf, 0.04, 0.05, st))
        await b.drain(60000, "phase %d (%s)" % (phase, prof))
    b.finish("random_traffic", conflict_cycles=b.chk.conflict_cycles, max_lost_run=b.chk.max_lost_run)


# --------------------------------------------------------------------------- reset


async def _reset_round(b, rng, max_cycles=600, what="reset"):
    n0 = b.rst.n_pulses
    await b.env.until(lambda: b.rst.n_pulses > n0, max_cycles, what + " to fire")
    cfg = b.cfg
    st = {"bank": 0, "word": 0}
    for i, m in enumerate(b.ms):  # requests queued DURING reset are presented in the first cycle after release
        for k in range(rng.randint(0, 2)):
            m.submit(rand_breq(rng, cfg, i, "uniform", 0.5, 0.05, 0.05, st))
    await b.env.until(lambda: not b.rst.asserted, 30, what + " release")


def armed(b, pred, length, reason, patience=150):
    dl = b.env.cycle + patience
    b.rst.arm(lambda: pred() or b.env.cycle >= dl, length, reason)


@cocotb.test()
async def reset_during_traffic(dut):
    """Synchronous resets (1-3 cycles) in the middle of multi-master traffic: all outstanding responses and the
    arbitration pointers are cleared, accepted writes stay in the array, nothing stale appears afterwards."""
    b = build_bank(dut, SEED(), rsp_thr="always")
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("rst")
    await up(b)
    st = {"bank": 0, "word": 0}
    for rnd in range(24):
        st["bank"] = rng.randrange(cfg.nb)
        for m in ms:
            if cfg.fd:
                m.rsp_thr.set_mode(rng.choice(["random:0.3", "random:0.6", "bursty:2-10"]))
            m.req_thr.set_mode(rng.choice(["always", "random:0.7"]))
        for i, m in enumerate(ms):
            for k in range(rng.randint(8, 30)):
                m.submit(rand_breq(rng, cfg, i, rng.choice(["uniform", "same_bank", "hot_word", "boundary"]), 0.5, 0.03, 0.03, st))
        length = rng.choice([1, 1, 2, 3])
        kind = rnd % 6
        if kind == 4:  # idle reset: let everything complete first, then reset with nothing in flight
            for m in ms:
                m.queue.clear()
            await b.drain(2000, "idle before reset")
            b.rst.pulse(length, delay=1, reason="idle")
            await _reset_round(b, rng, 50, "idle reset round %d" % rnd)
            continue
        if kind == 5:
            armed(b, lambda: b.chk.outstanding() == 1, length, "exactly one outstanding")
        elif kind == 0:
            b.rst.pulse(length, delay=rng.randint(1, 25), reason="sync-random")
        elif kind == 1:
            armed(b, lambda: b.chk.outstanding() >= 2, length, "outstanding>=2")
        elif kind == 2:
            armed(b, lambda: b.chk._contended_prev, length, "arbitration-conflict")
        else:
            armed(b, lambda: b.chk.outstanding() >= cfg.nm * max(1, cfg.fd) // 2 and any(m.cur is not None for m in ms), length, "heavy")
        await _reset_round(b, rng, 600, "reset round %d" % rnd)
        await b.env.cycles(rng.randint(0, 4))
    for m in ms:
        m.rsp_thr.set_mode("always")
        m.req_thr.set_mode("always")
    for w in range(cfg.total):
        ms[w % cfg.nm].read(cfg.addr_of(w))
    await b.drain(30000, "read-back after resets")
    assert b.rst.n_pulses >= 24
    b.finish("reset_during_traffic", resets=b.rst.n_pulses, cancelled=b.chk.n_cancelled)


@cocotb.test()
async def reset_async_midcycle(dut):
    """Asynchronous reset between clock edges (several phases) during multi-master traffic with contention."""
    b = build_bank(dut, SEED(), rsp_thr="always")
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("arst")
    await up(b)
    st = {"bank": 0, "word": 0}
    phases = [0.5, 2.0, 4.0, 5.0, 7.5, 9.0, 9.9]
    for rnd in range(len(phases) * 2):
        st["bank"] = rng.randrange(cfg.nb)
        for m in ms:
            if cfg.fd:
                m.rsp_thr.set_mode(rng.choice(["random:0.35", "random:0.7", "always"]))
        for i, m in enumerate(ms):
            for k in range(rng.randint(6, 25)):
                m.submit(rand_breq(rng, cfg, i, rng.choice(["uniform", "same_bank", "parallel"]), 0.5, 0.03, 0.03, st))
        await b.env.cycles(rng.randint(2, 15))
        b.chk.mark_async()
        cocotb.start_soon(b.rst.async_pulse(phases[rnd % len(phases)], length_cycles=rng.choice([1, 1, 2, 3])))
        await _reset_round(b, rng, 40, "async reset round %d" % rnd)
        await b.env.cycles(rng.randint(0, 3))
    for m in ms:
        m.rsp_thr.set_mode("always")
    for w in range(cfg.total):
        ms[w % cfg.nm].read(cfg.addr_of(w))
    await b.drain(30000, "read-back after async resets")
    b.finish("reset_async_midcycle", resets=b.rst.n_pulses, cancelled=b.chk.n_cancelled)


@cocotb.test()
async def id_order(dut):
    """Per-master in-order responses with ids: each master sends a counting id sequence to random banks under
    random response stalls; the response stream of every master must keep that exact order."""
    b = build_bank(dut, SEED(), req_thr="random:0.8", rsp_thr="random:0.5" if params().get("RSP_FIFO_DEPTH", 1) != 0 else "always")
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("ido")
    await up(b)
    for i, m in enumerate(ms):
        for k in range(150):
            m.read(cfg.addr_of(rng.randrange(cfg.total)), id=ids(cfg, k * (i + 1)))
    await b.drain(40000, "id stream")
    b.finish("id_order")
