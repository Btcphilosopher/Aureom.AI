"""SRAM subsystem suites: sram_sp (single-port wrapper), sram_banked (bank controller), sram_spm (HPC scratchpad).

DUT configuration names all start with ``sram_`` (they become build/run directory names shared by all workers).
"""
from albionverify.sim.build import DutSpec
from albionverify.suite import Case, Suite


def _spec(name, top, **p):
    return DutSpec(name, top, params=tuple(sorted(p.items())))


# ----------------------------------------------------------------------------------- sram_sp configurations
# (DATA_WIDTH, DEPTH, MASK_WIDTH, READ_LATENCY, RSP_FIFO_DEPTH, WRITE_ACK, ID_WIDTH)
SP_A = _spec("sram_sp_d64_l1", "sram_sp", DATA_WIDTH=32, DEPTH=64, MASK_WIDTH=4, READ_LATENCY=1, RSP_FIFO_DEPTH=2, WRITE_ACK=1, ID_WIDTH=4)
SP_B = _spec("sram_sp_d100_l2", "sram_sp", DATA_WIDTH=32, DEPTH=100, MASK_WIDTH=4, READ_LATENCY=2, RSP_FIFO_DEPTH=3, WRITE_ACK=1, ID_WIDTH=4)
SP_C = _spec("sram_sp_d100_l3_posted", "sram_sp", DATA_WIDTH=32, DEPTH=100, MASK_WIDTH=4, READ_LATENCY=3, RSP_FIFO_DEPTH=4, WRITE_ACK=0, ID_WIDTH=1)
SP_D = _spec("sram_sp_w64_l1_fd1", "sram_sp", DATA_WIDTH=64, DEPTH=64, MASK_WIDTH=8, READ_LATENCY=1, RSP_FIFO_DEPTH=1, WRITE_ACK=1, ID_WIDTH=8)
SP_E = _spec("sram_sp_d100_nofifo", "sram_sp", DATA_WIDTH=32, DEPTH=100, MASK_WIDTH=4, READ_LATENCY=2, RSP_FIFO_DEPTH=0, WRITE_ACK=1, ID_WIDTH=4)
SP_F = _spec("sram_sp_lane9_posted", "sram_sp", DATA_WIDTH=18, DEPTH=50, MASK_WIDTH=2, READ_LATENCY=1, RSP_FIFO_DEPTH=2, WRITE_ACK=0, ID_WIDTH=3)

SP_G = _spec("sram_sp_d3_w1_l4", "sram_sp", DATA_WIDTH=1, DEPTH=3, MASK_WIDTH=1, READ_LATENCY=4, RSP_FIFO_DEPTH=6, WRITE_ACK=1, ID_WIDTH=2)

SP_H = _spec("sram_sp_d1000_l1", "sram_sp", DATA_WIDTH=32, DEPTH=1000, MASK_WIDTH=4, READ_LATENCY=1, RSP_FIFO_DEPTH=2, WRITE_ACK=1, ID_WIDTH=8)
SP_I = _spec("sram_sp_fpga_d64_l2", "sram_sp", BACKEND=1, DATA_WIDTH=32, DEPTH=64, MASK_WIDTH=4, READ_LATENCY=2, RSP_FIFO_DEPTH=3, WRITE_ACK=1, ID_WIDTH=3)

SP_MOD = "sram.cocotb_sram_sp"

# ----------------------------------------------------------------------------------- sram_banked configurations
# NUM_MASTERS x NUM_BANKS, ARB (0 RR / 1 FIXED), INTERLEAVE (0 LOW / 1 HIGH), ADDR_MODE (0 WORD / 1 BYTE)
_BK = dict(DATA_WIDTH=32, MASK_WIDTH=4)
BK_A = _spec("sram_bank_4x4_rr_low", "sram_bank_controller", NUM_MASTERS=4, NUM_BANKS=4, BANK_DEPTH=16, READ_LATENCY=1, ARB=0, INTERLEAVE=0, ADDR_MODE=0,
             ID_WIDTH=4, RSP_FIFO_DEPTH=2, WRITE_ACK=1, ADDR_WIDTH=8, **_BK)
BK_B = _spec("sram_bank_3x2_fixed_high_byte", "sram_bank_controller", NUM_MASTERS=3, NUM_BANKS=2, BANK_DEPTH=32, READ_LATENCY=2, ARB=1, INTERLEAVE=1, ADDR_MODE=1,
             ID_WIDTH=3, RSP_FIFO_DEPTH=3, WRITE_ACK=0, ADDR_WIDTH=10, **_BK)
BK_C = _spec("sram_bank_2x8_rr_w64_l3", "sram_bank_controller", NUM_MASTERS=2, NUM_BANKS=8, BANK_DEPTH=6, READ_LATENCY=3, ARB=0, INTERLEAVE=0, ADDR_MODE=0,
             ID_WIDTH=2, RSP_FIFO_DEPTH=1, WRITE_ACK=1, ADDR_WIDTH=6, DATA_WIDTH=64, MASK_WIDTH=8)
BK_D = _spec("sram_bank_5x4_nofifo_byte16", "sram_bank_controller", NUM_MASTERS=5, NUM_BANKS=4, BANK_DEPTH=8, READ_LATENCY=2, ARB=0, INTERLEAVE=0, ADDR_MODE=1,
             ID_WIDTH=4, RSP_FIFO_DEPTH=0, WRITE_ACK=1, ADDR_WIDTH=8, DATA_WIDTH=16, MASK_WIDTH=2)
BK_E = _spec("sram_bank_1x1", "sram_bank_controller", NUM_MASTERS=1, NUM_BANKS=1, BANK_DEPTH=10, READ_LATENCY=1, ARB=0, INTERLEAVE=0, ADDR_MODE=0,
             ID_WIDTH=2, RSP_FIFO_DEPTH=2, WRITE_ACK=1, ADDR_WIDTH=5, **_BK)

BK_F = _spec("sram_bank_8x2_rr_high", "sram_bank_controller", NUM_MASTERS=8, NUM_BANKS=2, BANK_DEPTH=16, READ_LATENCY=2, ARB=0, INTERLEAVE=1, ADDR_MODE=0,
             ID_WIDTH=4, RSP_FIFO_DEPTH=3, WRITE_ACK=1, ADDR_WIDTH=7, **_BK)

BK_MOD = "sram.cocotb_sram_banked"

# ----------------------------------------------------------------------------------- sram_spm configurations (hpc_scratchpad)
SPM_A = _spec("sram_spm_3p4b_low_1rw", "hpc_scratchpad", NUM_PORTS=3, CAPACITY_BYTES=1024, NUM_BANKS=4, DATA_WIDTH=32, ADDR_WIDTH=16, BASE_ADDR=0x4000,
              READ_LATENCY=2, BYTE_WE=1, PORT_MODE=0, MAP=0, ARB=0, RSP_FIFO_DEPTH=3, WRITE_ACK=1, TAG_W=4, CNT_W=32)
SPM_B = _spec("sram_spm_4p4b_xor_1r1w_fixed", "hpc_scratchpad", NUM_PORTS=4, CAPACITY_BYTES=1024, NUM_BANKS=4, DATA_WIDTH=32, ADDR_WIDTH=12, BASE_ADDR=0x400,
              READ_LATENCY=1, BYTE_WE=0, PORT_MODE=1, MAP=1, ARB=1, RSP_FIFO_DEPTH=2, WRITE_ACK=0, TAG_W=3, CNT_W=8)
SPM_C = _spec("sram_spm_3p2b_high_2rw_w64", "hpc_scratchpad", NUM_PORTS=3, CAPACITY_BYTES=1024, NUM_BANKS=2, DATA_WIDTH=64, ADDR_WIDTH=12, BASE_ADDR=0,
              READ_LATENCY=3, BYTE_WE=1, PORT_MODE=2, MAP=2, ARB=0, RSP_FIFO_DEPTH=1, WRITE_ACK=1, TAG_W=2, CNT_W=16)
SPM_MOD = "sram.cocotb_sram_spm"


def spm_cases(dut, seeds=(1, 2, 3)):
    c = []
    for t, tags, sd in [
        ("map_data", ("directed", "long"), seeds[:1]),
        ("byte_strobes", ("directed",), seeds[:1]),
        ("bank_conflicts", ("directed",), seeds[:1]),
        ("isolation_backpressure", ("directed",), seeds[:1]),
        ("error_requests", ("directed", "error"), seeds[:1]),
        ("random_traffic", ("random",), seeds),
        ("reset_during_traffic", ("reset", "random"), seeds),
        ("reset_async_midcycle", ("reset", "random"), seeds[:2]),
    ]:
        c.append(Case(dut, SPM_MOD, t, sd, timeout=600, tags=tags))
    return c


def bk_cases(dut, seeds=(1, 2, 3)):
    c = []
    for t, tags, sd in [
        ("map_integrity", ("directed", "long"), seeds[:1]),
        ("arbitration_order", ("directed",), seeds[:1]),
        ("parallel_banks", ("directed",), seeds[:1]),
        ("hot_word", ("directed",), seeds[:1]),
        ("isolation_backpressure", ("directed",), seeds[:1]),
        ("error_requests", ("directed", "error"), seeds[:1]),
        ("id_order", ("directed",), seeds[:1]),
        ("random_traffic", ("random",), seeds),
        ("reset_during_traffic", ("reset", "random"), seeds),
        ("reset_async_midcycle", ("reset", "random"), seeds[:2]),
    ]:
        c.append(Case(dut, BK_MOD, t, sd, timeout=600, tags=tags))
    return c


def sp_cases(dut, seeds=(1, 2, 3), full=True):
    c = []
    for t, tags, sd in [
        ("directed_rw", ("directed",), seeds[:1]),
        ("byte_lanes", ("directed",), seeds[:1]),
        ("invalid_address", ("directed", "error"), seeds[:1]),
        ("credits_backpressure", ("directed",), seeds[:1]),
        ("latency_throughput", ("directed",), seeds[:1]),
        ("random_traffic", ("random",), seeds),
        ("max_depth_sweep", ("random", "long"), seeds[:1]),
        ("reset_during_traffic", ("reset", "random"), seeds),
        ("reset_async_midcycle", ("reset", "random"), seeds[:2]),
        ("reset_power_up", ("reset", "directed"), seeds[:1]),
        ("test_port_mode", ("directed", "random"), seeds[:2]),
    ]:
        c.append(Case(dut, SP_MOD, t, sd, timeout=600, tags=tags))
    return c


def _mut(dut, tests):
    out = []
    for t, tags in tests:
        out.append(Case(dut, SP_MOD, t, (1,), timeout=300, tags=tags))
    return out


# fast subset for mutation campaigns (< ~90 s per mutant): the configurations the mutants are pinned to
SP_MUTATION_CASES = (
    _mut(SP_B, [("directed_rw", ()), ("byte_lanes", ()), ("invalid_address", ()), ("credits_backpressure", ()), ("latency_throughput", ()),
                ("random_traffic", ()), ("reset_during_traffic", ()), ("reset_async_midcycle", ()), ("test_port_mode", ())])
    + _mut(SP_C, [("directed_rw", ()), ("invalid_address", ()), ("credits_backpressure", ()), ("random_traffic", ()), ("reset_during_traffic", ()), ("reset_async_midcycle", ())])
    + _mut(SP_F, [("byte_lanes", ()), ("directed_rw", ()), ("random_traffic", ())])
)

def _bmut(dut, tests):
    return [Case(dut, BK_MOD, t, (1,), timeout=300, tags=()) for t in tests]


BK_MUTATION_CASES = (
    _bmut(BK_A, ["map_integrity", "arbitration_order", "parallel_banks", "error_requests", "isolation_backpressure", "hot_word", "id_order", "random_traffic",
                 "reset_during_traffic", "reset_async_midcycle"])
    + _bmut(BK_B, ["map_integrity", "arbitration_order", "error_requests", "random_traffic", "reset_during_traffic"])
    + _bmut(BK_C, ["map_integrity", "hot_word", "random_traffic"])
    + _bmut(BK_D, ["map_integrity", "random_traffic"])
    + _bmut(BK_E, ["map_integrity", "error_requests", "random_traffic"])
)

def _smut(dut, tests):
    return [Case(dut, SPM_MOD, t, (1,), timeout=300, tags=()) for t in tests]


SPM_MUTATION_CASES = (
    _smut(SPM_A, ["map_data", "byte_strobes", "bank_conflicts", "error_requests", "random_traffic", "reset_during_traffic", "reset_async_midcycle"])
    + _smut(SPM_B, ["map_data", "bank_conflicts", "error_requests", "random_traffic", "reset_during_traffic"])
    + _smut(SPM_C, ["map_data", "byte_strobes", "bank_conflicts", "random_traffic"])
)

SUITES = {
    "sram_sp": Suite(
        name="sram_sp",
        subsystem="sram",
        title="sram_sp single-port SRAM wrapper (GENERIC backend): data, lanes, bounds, latency, credits, reset",
        cases=sum((sp_cases(d) for d in (SP_A, SP_B, SP_C, SP_D, SP_E, SP_F, SP_G, SP_H, SP_I)), []),
        mutation_cases=SP_MUTATION_CASES,
        mutants_file="mutants/sram_sp.yaml",
        spec_refs=("sramlib/docs/mem/01_interface_spec.md", "sramlib/README.md"),
        notes="Cycle-exact model of req_ready / rsp_valid / payload; independent lane memory with unknown power-up content.",
    )
    ,
    "sram_banked": Suite(
        name="sram_banked",
        subsystem="sram",
        title="sram_bank_controller: multi-master bank conflicts, arbitration, routing, ids, errors, reset",
        cases=sum((bk_cases(d) for d in (BK_A, BK_B, BK_C, BK_D, BK_E, BK_F)), []),
        mutation_cases=BK_MUTATION_CASES,
        mutants_file="mutants/sram_banked.yaml",
        spec_refs=("sramlib/docs/mem/03_banking.md", "sramlib/docs/mem/01_interface_spec.md"),
        notes="Cycle-exact model of per-bank arbitration (RR pointer / fixed), ready, m_stall_conflict and per-master response paths.",
    ),
    "sram_spm": Suite(
        name="sram_spm",
        subsystem="sram",
        title="hpc_scratchpad (HPC Module 04): address map, byte strobes, bank conflicts, arbitration, error codes, events/counters, reset",
        cases=sum((spm_cases(d) for d in (SPM_A, SPM_B, SPM_C)), []),
        mutation_cases=SPM_MUTATION_CASES,
        mutants_file="mutants/sram_spm.yaml",
        spec_refs=("hpc_m04_scratchpad/docs/01_architecture_and_interface.md", "hpc_m04_scratchpad/docs/02_address_map.md", "hpc_m04_scratchpad/docs/03_banking_and_arbitration.md"),
        notes="Direct mode only (QUEUE_DEPTH=0); ECC_MODE NONE; GENERIC backend.  Cycle-exact model incl. events and saturating counters.",
    ),
}
