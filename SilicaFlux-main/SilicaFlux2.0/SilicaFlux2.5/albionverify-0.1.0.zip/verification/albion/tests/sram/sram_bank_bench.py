"""Bench components for ``sram_bank_controller`` (NUM_MASTERS x NUM_BANKS): cycle-exact multi-master checker against
``albionverify.models.sram_bank.BankModel``, functional coverage and traffic generators.

Per edge the checker predicts, from the presented requests and the model state only, the arbitration outcome
(per-bank winner), every master's ``m_req_ready`` (for valid requests), every ``m_stall_conflict`` bit, every
master's ``m_rsp_valid`` and response payload.  The read data is checked against an independent word memory.
In addition it measures, on the DUT's observed behaviour (not on the model), the round-robin fairness bound of
the spec: a master holding an eligible request waits at most NUM_MASTERS-1 cycles.
"""
from __future__ import annotations

import random
from collections import deque
from dataclasses import dataclass
from typing import Any, Deque, Dict, List, Optional

from albionverify.bus.reqrsp import Req, sramcore_port
from albionverify.core import Agent, Env
from albionverify.coverage import CoverGroup
from albionverify.models.sram_bank import ADDR_BYTE, FIXED, ILV_HIGH, ILV_LOW, RR, BankModel, BReq
from albionverify.models.sram_core import ExpRsp, clog2
from albionverify.reset import ResetSequencer
from albionverify.scoreboard import Scoreboard

from sram.sram_bench import BUCKETS, PortRead, SramMaster, bucket, params, read_port


@dataclass
class BankCfg:
    nm: int
    nb: int
    dw: int
    mw: int
    bd: int
    rl: int
    arb: int
    ilv: int
    amode: int
    idw: int
    fd: int
    wa: int
    aw: int

    @property
    def total(self) -> int:
        return self.nb * self.bd

    @property
    def boff(self) -> int:
        return clog2(self.dw // 8) if (self.amode == ADDR_BYTE and self.dw >= 16) else 0

    @property
    def full_mask(self) -> int:
        return (1 << self.mw) - 1

    @property
    def max_word(self) -> int:  # highest word number the AW-bit address can carry
        return ((1 << self.aw) - 1) >> self.boff

    @staticmethod
    def from_params(P: Dict[str, Any]) -> "BankCfg":
        nm, nb = int(P.get("NUM_MASTERS", 4)), int(P.get("NUM_BANKS", 4))
        dw = int(P.get("DATA_WIDTH", 32))
        mw = int(P.get("MASK_WIDTH", dw // 8 if dw % 8 == 0 else 1))
        bd = int(P.get("BANK_DEPTH", 1024))
        rl = int(P.get("READ_LATENCY", 1))
        amode = int(P.get("ADDR_MODE", 0))
        boff = clog2(dw // 8) if (amode == ADDR_BYTE and dw >= 16) else 0
        aw = int(P.get("ADDR_WIDTH", clog2(nb * bd) + boff))
        return BankCfg(nm, nb, dw, mw, bd, rl, int(P.get("ARB", 0)), int(P.get("INTERLEAVE", 0)), amode, int(P.get("ID_WIDTH", 4)),
                       int(P.get("RSP_FIFO_DEPTH", rl + 1)), int(P.get("WRITE_ACK", 1)), aw)

    def model(self) -> BankModel:
        return BankModel(self.nm, self.nb, self.dw, self.mw, self.bd, self.rl, self.arb, self.ilv, self.amode, self.idw, self.fd, self.wa)

    # address helpers (system address of a word, optionally misaligned)
    def addr_of(self, word: int, off: int = 0) -> int:
        return (word << self.boff) | off

    def bank_of_word(self, w: int) -> int:
        if self.nb == 1:
            return 0
        return w % self.nb if self.ilv == ILV_LOW else (w // self.bd)

    def word_in_bank(self, bank: int, row: int) -> int:
        """Inverse of the documented map: word number of (bank, row)."""
        if self.nb == 1:
            return row
        return row * self.nb + bank if self.ilv == ILV_LOW else bank * self.bd + row


# --------------------------------------------------------------------------- coverage


def cover_bank(cfg: BankCfg) -> Dict[str, CoverGroup]:
    NM, NB = cfg.nm, cfg.nb
    oor = cfg.max_word >= cfg.total  # an out-of-range word is representable
    mis = cfg.boff > 0
    ops = ["read", "write" if cfg.wa else "write_posted"] + (["err_read", "err_write"] if (oor or mis) else [])
    classes = ["w0", "w1"] + (["bank_first_row", "bank_last_row"] if NB > 1 else []) + ["last_word", "mid"]
    if oor:
        classes += ["oor_first", "oor_last"]
    if mis:
        classes += ["misaligned"]
    cg = CoverGroup("bank.txn", "transaction types x address classes (bank/row boundaries, out-of-range, misaligned)")
    cg.point("op", ops)
    cg.point("wclass", classes)
    cg.cross("op_x_class", ["op", "wclass"], ignore=lambda b: b[0].startswith("err") != (b[1].startswith("oor") or b[1] == "misaligned"))

    cb = CoverGroup("bank.access", "which master reached which bank (granted, in range)")
    cb.point("master", list(range(NM)))
    cb.point("bank", list(range(NB)))
    cb.cross("master_x_bank", ["master", "bank"])

    multi = NM >= 2
    cc = CoverGroup("bank.contention", "bank conflicts vs parallel access")
    cc.point("max_contenders", list(range(0, NM + 1)) if multi else [0, 1])  # most eligible masters on one bank in a cycle
    cc.point("parallel", list(range(0, min(NM, NB) + 1)))  # banks granted in the same cycle
    # c masters eligible for one bank plus p-1 further banks each needing a distinct master: c + p - 1 <= NM; nobody eligible <=> nobody granted
    cc.cross("contenders_x_parallel", ["max_contenders", "parallel"], ignore=lambda b: (int(b[0]) == 0) != (int(b[1]) == 0) or (int(b[0]) + max(int(b[1]), 1) - 1 > NM))
    if multi:
        cc.point("stall_flag", ["lost", "won_or_idle"])  # m_stall_conflict observed (only possible with >= 2 masters)

    ca = CoverGroup("bank.arb", "arbitration outcome with contention (winner x contender count)")
    if multi:
        # FIXED priority: the winner is the lowest-numbered contender, so the last master can only win uncontended
        winners = list(range(NM)) if cfg.arb == RR else list(range(NM - 1))
        ca.point("winner", winners)
        ca.point("contenders", list(range(2, NM + 1)))
        ca.cross("winner_x_contenders", ["winner", "contenders"], ignore=(lambda b: False) if cfg.arb == RR else (lambda b: int(b[0]) + int(b[1]) - 1 > NM - 1))
        waits = [str(i) for i in range(NM)] if cfg.arb == RR else ["0", "1", "2", "3-5", "6+"]
        ca.point("wait", {w: (int(w) if w.isdigit() else ((3, 5) if w == "3-5" else (lambda v: v >= 6))) for w in waits})  # cycles lost before being granted
    else:
        ca.point("wait", {"0": 0})

    ce = CoverGroup("bank.err", "error responses")
    ek = (["range"] if oor else []) + (["align"] if mis else [])
    if ek:
        ce.point("kind", ek)
        ce.point("op", ["read", "write"])
        ce.cross("kind_x_op", ["kind", "op"])

    cf = CoverGroup("bank.flow", "per-master back-pressure and credits")
    maxstall = (NM - 1) if (cfg.fd == 0 and cfg.arb == RR) else None  # RR without credits: a request waits at most NM-1 cycles for its bank
    cf.point("req_stall", [b_ for b_, lo in zip(BUCKETS, (0, 1, 2, 4, 8)) if maxstall is None or lo <= maxstall])
    cf.point("rsp_stall", BUCKETS if cfg.fd else ["0"])
    if cfg.fd:
        cf.point("credit_full", ["blocked"])
        if multi:
            cf.point("isolation", ["other_master_progressed"])  # one master out of credits while another still got accepted

    ci = CoverGroup("bank.id", "request id echo")
    mx = (1 << cfg.idw) - 1
    ci.point("id", {"zero": 0, "max": mx, "other": (lambda v, m=mx: 0 < v < m)} if mx > 1 else {"zero": 0, "max": mx})

    cr = CoverGroup("bank.reset", "reset with responses in flight")
    cr.point("outstanding", ["0", "1", "2+"])
    cr.point("kind", ["sync", "async"])
    cr.point("contended", ["no", "yes"] if multi else ["no"])  # at least one master lost arbitration in the cycle before the reset
    return {g.name: g for g in (cg, cb, cc, ca, ce, cf, ci, cr)}


# --------------------------------------------------------------------------- checker


class BankChecker(Agent):
    """Cycle-exact checker of the whole controller.  Registered AFTER the masters."""

    def __init__(self, name: str, ports: List[Dict[str, Any]], stalls: Any, cfg: BankCfg, sb: Scoreboard, cov: Optional[Dict[str, CoverGroup]] = None):
        super().__init__(name)
        self.ports, self.stalls, self.cfg, self.sb = ports, stalls, cfg, sb
        self.m = cfg.model()
        self.cov = cov or {}
        self.n_checks = 0
        self.n_accept = [0] * cfg.nm
        self.n_rsp = [0] * cfg.nm
        self.n_cancelled = 0
        self.n_posted = 0
        self.log: Deque[str] = deque(maxlen=14)
        self._stall_pay: List[Optional[tuple]] = [None] * cfg.nm
        self._lost_run = [0] * cfg.nm  # consecutive cycles a master lost arbitration (observed)
        self.max_lost_run = [0] * cfg.nm
        self.grant_log: List[tuple] = []  # (cycle, bank, master) of every grant
        self.conflict_cycles = 0
        self.parallel_hist: Dict[int, int] = {}
        self._async_next = False
        self._contended_prev = False
        self.masters: List[SramMaster] = []
        self._credit_blocked = [False] * cfg.nm

    # ---- helpers
    @property
    def drained(self) -> bool:
        return all(p.outstanding == 0 for p in self.m.ports)

    def outstanding(self) -> int:
        return sum(p.outstanding for p in self.m.ports)

    def _fail(self, msg: str) -> None:
        self.sb.fail("%s | recent: %s" % (msg, " ; ".join(self.log)))

    def _cmp(self, what: str, exp: Any, got: Any, ctx: str = "") -> None:
        self.n_checks += 1
        if exp != got:
            self._fail("%s mismatch%s: expected 0x%x, got 0x%x" % (what, (" [%s]" % ctx) if ctx else "", int(exp), int(got)))

    def _cs(self, g: str, **kw) -> None:
        cg = self.cov.get(g)
        if cg is not None:
            cg.sample(**kw)

    def wclass(self, word: int, d_ok: bool, d_kind: str) -> str:
        cfg = self.cfg
        if d_kind == "align":
            return "misaligned"
        if not d_ok:
            return "oor_first" if word == cfg.total else "oor_last"
        if word == 0:
            return "w0"
        if word == 1:
            return "w1"
        if word == cfg.total - 1:
            return "last_word"
        row = (word // cfg.nb) if (cfg.ilv == ILV_LOW and cfg.nb > 1) else (word % cfg.bd)
        if cfg.nb > 1:
            if row == cfg.bd - 1:
                return "bank_last_row"
            if row == 0:
                return "bank_first_row"
        return "mid"

    # ---- agent
    def sample(self) -> None:
        env, c, m, cfg = self.env, self.env.cycle, self.m, self.cfg
        S: List[PortRead] = [read_port(p) for p in self.ports]
        stall = [int(x) for x in (self.stalls.read_all() if hasattr(self.stalls, "read_all") else [sg.read() for sg in self.stalls])]
        if env.in_reset:
            if c > 1:
                for i, s in enumerate(S):
                    self._cmp("m_req_ready[%d] while rst_n low" % i, 0, s.rdy)
                    self._cmp("m_rsp_valid[%d] while rst_n low" % i, 0, s.rv)
                    self._cmp("m_stall_conflict[%d] while rst_n low" % i, 0, stall[i])
            self._stall_pay = [None] * cfg.nm
            self._contended_prev = False
            return
        live = m.begin_edge()
        # ---------------- responses, per master (cycle exact)
        heads = []
        for i, s in enumerate(S):
            head = m.ports[i].head_valid(c)
            heads.append(head)
            if head is None:
                self._cmp("m_rsp_valid[%d] (nothing due)" % i, 0, s.rv, "unsolicited / early response")
            else:
                self._cmp("m_rsp_valid[%d] (response due since cycle %d, kind %s)" % (i, head.due, head.kind), 1, s.rv, "missing / late response")
                if s.rv:
                    ctx = "master %d %s addr 0x%x" % (i, head.kind, head.addr)
                    self._cmp("m_rsp_err[%d]" % i, int(head.err), s.rerr, ctx)
                    self._cmp("m_rsp_we[%d]" % i, int(head.we), s.rwe, ctx)
                    self._cmp("m_rsp_id[%d]" % i, head.id, s.rid, ctx)
                    err = m.mem.check(head.snap, s.rdata, pin=bool(s.rr)) if head.kind == "read" else m.check_rsp_data(head, s.rdata)  # type: ignore[arg-type]
                    self.n_checks += 1
                    if err:
                        self._fail("m_rsp_rdata[%d] %s (kind %s, id %d)" % (i, err, head.kind, head.id))
            pay = (s.rdata, s.rerr, s.rwe, s.rid) if s.rv else None
            if self._stall_pay[i] is not None:
                self.n_checks += 1
                if pay != self._stall_pay[i]:
                    self._fail("master %d response not held stable under back-pressure: %s -> %s" % (i, self._stall_pay[i], pay))
            self._stall_pay[i] = pay if (s.rv and not s.rr) else None
        # ---------------- requests: arbitration prediction
        reqs = [BReq(bool(s.v), bool(s.we), s.addr, s.wdata, s.wmask, s.id) for s in S]
        pred = m.predict(live, reqs)
        credit_full_masters = 0
        for i, s in enumerate(S):
            if s.v:
                d0 = m.decode(s.addr)
                if live and cfg.fd and not pred.ready[i] and not m.ports[i].credit_free() and m.needs_rsp(bool(s.we), d0.ok):
                    credit_full_masters += 1  # request held back because every response credit of this master is in use
                self.n_checks += 1
                if int(pred.ready[i]) != s.rdy:
                    d = m.decode(s.addr)
                    self._fail("m_req_ready[%d] mismatch: expected %d, got %d (live=%d we=%d addr=0x%x ok=%d bank=%d outstanding=%d/%d, contenders for bank=%s, ptr=%s)" % (
                        i, int(pred.ready[i]), s.rdy, int(live), s.we, s.addr, int(d.ok), d.bank, m.ports[i].outstanding, cfg.fd, pred.eligible.get(d.bank), m.ptr))
            self._cmp("m_stall_conflict[%d]" % i, int(pred.stall[i]), stall[i], "valid=%d" % s.v)
        # ---------------- hand-overs, then acceptances (pre-edge state was used above)
        for i, s in enumerate(S):
            if heads[i] is not None and s.rv and s.rr:
                out = m.ports[i].pop()
                self.sb.complete("m%d" % i, out.key)
                self.n_rsp[i] += 1
                self._cs("bank.flow", rsp_stall=bucket(max(0, c - out.due)))
                env.digest.event("bk.rsp", i, c, s.rdata, s.rerr, s.rwe, s.rid)
        granted_banks = 0
        any_blocked = False
        accepted_any = False
        for i, s in enumerate(S):
            if s.v and s.rdy:
                accepted_any = True
        for i, s in enumerate(S):
            if s.v and s.rdy:
                d = m.decode(s.addr)
                e = m.accept(c, i, reqs[i], pred)
                self.n_accept[i] += 1
                if d.ok:
                    granted_banks += 1
                    self.grant_log.append((c, d.bank, i))
                self.log.append("c%d m%d %s a=0x%x%s" % (c, i, "W" if s.we else "R", s.addr, "" if d.ok else " ERR"))
                env.digest.event("bk.acc", i, c, int(s.we), s.addr, s.wdata if s.we else 0, s.wmask if s.we else 0, s.id)
                if e is not None:
                    self.sb.accept("m%d" % i, e.key, e)
                else:
                    self.n_posted += 1
                self._sample_accept(i, s, d, pred, c)
        # ---------------- observed fairness / contention statistics
        n_lost = 0
        for i, s in enumerate(S):
            if pred.stall[i]:
                n_lost += 1
                self._lost_run[i] += 1
                self.max_lost_run[i] = max(self.max_lost_run[i], self._lost_run[i])
                if cfg.arb == RR and self._lost_run[i] > cfg.nm - 1:
                    self._fail("round-robin fairness bound violated: master %d lost arbitration %d consecutive cycles (> NUM_MASTERS-1 = %d)" % (i, self._lost_run[i], cfg.nm - 1))
                self._cs("bank.contention", **({"stall_flag": "lost"} if cfg.nm >= 2 else {}))
            else:
                if s.v and s.rdy and m.decode(s.addr).ok:
                    self._cs("bank.arb", wait=self._lost_run[i])  # arbitration cycles lost before this grant (0 = immediate)
                self._lost_run[i] = 0
        if n_lost:
            self.conflict_cycles += 1
        maxc = max((len(v) for v in pred.eligible.values()), default=0)
        self.parallel_hist[granted_banks] = self.parallel_hist.get(granted_banks, 0) + 1
        self._cs("bank.contention", max_contenders=maxc, parallel=granted_banks)
        if not n_lost and cfg.nm >= 2:
            self._cs("bank.contention", stall_flag="won_or_idle")
        for b, g in pred.grant.items():
            k = len(pred.eligible[b])
            if k >= 2:
                self._cs("bank.arb", winner=g, contenders=k)
        if credit_full_masters:
            self._cs("bank.flow", credit_full="blocked")
            if accepted_any:
                self._cs("bank.flow", isolation="other_master_progressed")
        self._contended_prev = bool(n_lost)

    def _sample_accept(self, i: int, s: PortRead, d, pred, c: int) -> None:
        cfg = self.cfg
        we = bool(s.we)
        op = ("err_write" if we else "err_read") if not d.ok else (("write" if cfg.wa else "write_posted") if we else "read")
        word = s.addr >> cfg.boff
        self._cs("bank.txn", op=op, wclass=self.wclass(word, d.ok, d.kind))
        if d.ok:
            self._cs("bank.access", master=i, bank=d.bank)
        else:
            self._cs("bank.err", kind="align" if d.kind == "align" else "range", op="write" if we else "read")
        self._cs("bank.id", id=s.id)
        ms = self.masters[i] if self.masters else None
        self._cs("bank.flow", req_stall=bucket(ms.last_req_stall if ms is not None else 0))

    def mark_async(self) -> None:
        self._async_next = True

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            n = self.outstanding()
            self._cs("bank.reset", outstanding="0" if n == 0 else ("1" if n == 1 else "2+"), kind="async" if self._async_next else "sync", contended="yes" if self._contended_prev else "no")
            gone = self.m.reset()
            self.sb.cancel(None, "reset")
            self.n_cancelled += len(gone)
            self._async_next = False
            self._lost_run = [0] * self.cfg.nm
            self._stall_pay = [None] * self.cfg.nm
            self.env.digest.event("bk.reset", self.env.cycle, len(gone))

    def summary(self) -> dict:
        return {"accepted": list(self.n_accept), "responses": list(self.n_rsp), "posted": self.n_posted, "cancelled": self.n_cancelled, "checks": self.n_checks,
                "conflict_cycles": self.conflict_cycles, "max_lost_run": list(self.max_lost_run), "parallel_hist": dict(sorted(self.parallel_hist.items())),
                "model_stats": dict(self.m.stats)}


class _StallSigs:
    """The m_stall_conflict vector as a list of per-master bit readers."""

    def __init__(self, sig, n):
        self.sig, self.n = sig, n

    def read_all(self):
        v = self.sig.read()
        return [(v >> i) & 1 for i in range(self.n)]


# --------------------------------------------------------------------------- traffic


def rand_word(rng: random.Random, cfg: BankCfg, profile: str, master: int, oor_frac: float, state: Dict[str, Any]) -> int:
    """Word number for a request.  ``state['bank']`` is the bank the whole group hammers in 'same_bank' phases."""
    T = cfg.total
    if rng.random() < oor_frac and cfg.max_word >= T:
        return rng.choice([T, T + 1, cfg.max_word, rng.randint(T, cfg.max_word)])
    if profile == "same_bank":
        return cfg.word_in_bank(state.get("bank", 0), rng.randrange(cfg.bd))
    if profile == "parallel":
        return cfg.word_in_bank(master % cfg.nb, rng.randrange(cfg.bd))
    if profile == "hot_word":
        return state.get("word", 0)
    if profile == "boundary":
        b = rng.randrange(cfg.nb)
        return rng.choice([0, 1, T - 1, cfg.word_in_bank(b, 0), cfg.word_in_bank(b, cfg.bd - 1), cfg.nb - 1, min(T - 1, cfg.nb), cfg.bd - 1, min(T - 1, cfg.bd)])
    if profile == "stride":  # stride that keeps hitting one bank (NUM_BANKS for LOW, BANK_DEPTH for HIGH)
        s = cfg.nb if cfg.ilv == ILV_LOW else cfg.bd
        return (rng.randrange(max(1, T // s)) * s + state.get("bank", 0)) % T
    return rng.randrange(T)


def rand_breq(rng: random.Random, cfg: BankCfg, master: int, profile: str, read_frac: float, oor_frac: float, mis_frac: float, state: Dict[str, Any]) -> Req:
    from sram.sram_bench import pattern_word, rand_mask

    w = rand_word(rng, cfg, profile, master, oor_frac, state)
    off = 0
    if cfg.boff and rng.random() < mis_frac:
        off = rng.randrange(1, 1 << cfg.boff)
    addr = cfg.addr_of(w, off) & ((1 << cfg.aw) - 1)
    rid = rng.getrandbits(cfg.idw)
    if rng.random() < read_frac:
        return Req(False, addr, 0, 0, rid)
    return Req(True, addr, pattern_word(rng, cfg.dw, 0), rand_mask(rng, cfg.mw), rid)


@dataclass
class BankBench:
    env: Env
    rst: ResetSequencer
    ms: List[SramMaster]
    chk: BankChecker
    sb: Scoreboard
    cfg: BankCfg
    cov: Dict[str, CoverGroup]

    async def drain(self, max_cycles: int = 30000, what: str = "drain") -> None:
        await self.env.until(lambda: all(m.idle for m in self.ms) and self.chk.drained and not self.rst.asserted, max_cycles, what)

    def finish(self, test: str, **extra) -> None:
        self.sb.finalize()
        self.env.finalize()
        self.env.coverage.extend(self.cov.values())
        self.env.write_result(test, scoreboard=self.sb.summary(), **extra)


def build_bank(dut, seed: int, name: str = "bank", req_thr: str = "always", rsp_thr: str = "always", initial_reset: int = 4) -> BankBench:
    cfg = BankCfg.from_params(params())
    if cfg.fd == 0:
        rsp_thr = "always"  # RSP_FIFO_DEPTH = 0 is the no-back-pressure mode: the master must keep rsp_ready = 1 (interface spec sec. 4)
    env = Env(dut, name=name, seed=seed)
    rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=initial_reset))
    ports, ms = [], []
    for i in range(cfg.nm):
        p = sramcore_port(env, "m_", i, flat=True, AW=cfg.aw, DW=cfg.dw, IDW=cfg.idw, MW=cfg.mw)
        ports.append(p)
        ms.append(env.add(SramMaster("m%d" % i, p, dw=cfg.dw, mw=cfg.mw, aw=cfg.aw, idw=cfg.idw, rng=env.seeds.child("m%d" % i), req_throttle=req_thr, rsp_throttle=rsp_thr)))
    sb = Scoreboard(env, "bank")
    cov = cover_bank(cfg)
    stalls = _StallSigs(env.sig("m_stall_conflict"), cfg.nm)
    chk = env.add(BankChecker("chk", ports, stalls, cfg, sb, cov))
    chk.masters = ms
    env.tie("tst_active", "tst_sel", "tst_ce", "tst_we", "tst_addr", "tst_wdata")
    return BankBench(env, rst, ms, chk, sb, cfg, cov)
