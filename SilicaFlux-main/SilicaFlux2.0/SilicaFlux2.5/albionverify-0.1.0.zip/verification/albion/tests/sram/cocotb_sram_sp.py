"""cocotb bench for ``sram_sp`` (single-port wrapper, GENERIC backend, SRAM-core port).

Every test only generates stimulus; ``sram_bench.SpChecker`` compares, on every clock edge, req_ready,
rsp_valid, the response payload, ordering and read data with the independent model
``albionverify.models.sram_core`` (written from rtl/sramlib/docs/mem/01_interface_spec.md).
"""
import os

import cocotb
from cocotb.triggers import RisingEdge, Timer

from albionverify.bus.reqrsp import Req

from sram.sram_bench import SpCfg, build_sp, params, rand_req

SEED = lambda: int(os.environ.get("ALBION_SEED", "1"))


async def up(b):
    await b.env.start()
    await b.env.until(lambda: not b.rst.asserted, 50, "reset release")
    await b.env.cycles(2)  # first cycle after release has req_ready = 0 (spec); the checker proves it


def word(cfg: SpCfg, rng) -> int:
    return rng.getrandbits(cfg.dw)


# --------------------------------------------------------------------------- directed


@cocotb.test()
async def directed_rw(dut):
    """Single write/read, first/last words, full-depth sweep, id echo, same-address hazards back to back."""
    b = build_sp(dut, SEED())
    cfg, m, rng = b.cfg, b.m, b.env.seeds.child("dir")
    await up(b)
    D = cfg.depth
    # (1) single word write then read at the boundaries, a distinct id each time
    for k, a in enumerate((0, 1, D // 2, D - 2, D - 1)):
        m.write(a, word(cfg, rng), id=k & ((1 << cfg.idw) - 1))
        m.read(a, id=(k + 1) & ((1 << cfg.idw) - 1))
    await b.drain(2000, "single word")
    # (2) full sweep: every word written with a unique value, read forward and backward
    for a in range(D):
        m.write(a, ((a + 1) * 0x9E3779B97F4A7C15) & ((1 << cfg.dw) - 1), id=a & ((1 << cfg.idw) - 1))
    for a in range(D):
        m.read(a, id=(a * 3) & ((1 << cfg.idw) - 1))
    for a in reversed(range(D)):
        m.read(a, id=(a * 5 + 1) & ((1 << cfg.idw) - 1))
    await b.drain(20000, "full sweep")
    # (3) every id value
    for i in range(1 << cfg.idw):
        m.read(rng.randrange(D), id=i)
    await b.drain(2000, "ids")
    # (4) hazards in consecutive cycles on one address: WAW, RAW, WAR, RAR, alternating
    a = rng.randrange(D)
    for k in range(12):
        m.write(a, word(cfg, rng))
        m.read(a)
        m.read(a)
        m.write(a, word(cfg, rng))
        m.write(a, word(cfg, rng))
        m.read(a)
    for k in range(20):  # strictly alternating write / read of one address
        if k % 2:
            m.write(a, word(cfg, rng))
        else:
            m.read(a)
    await b.drain(5000, "hazards")
    # (5) read-after-write to the neighbour addresses (decode aliasing)
    for a in range(0, D - 1, max(1, D // 16)):
        m.write(a, word(cfg, rng))
        m.read(a + 1)
        m.read(a)
    await b.drain(5000, "neighbours")
    b.finish("directed_rw")


@cocotb.test()
async def byte_lanes(dut):
    """Every lane alone, every mask (all 2^MW for MW<=6), sparse masks, all-ones, zero mask (legal no-op)."""
    b = build_sp(dut, SEED())
    cfg, m, rng = b.cfg, b.m, b.env.seeds.child("lanes")
    await up(b)
    D, mw, lw = cfg.depth, cfg.mw, cfg.lw
    full = (1 << cfg.dw) - 1
    for a in sorted({0, D - 1, D // 2}):
        m.write(a, 0, cfg.full_mask)
        for l in range(mw):  # one lane at a time, ones in that lane only, with garbage in the other lanes of wdata
            m.write(a, full, 1 << l)
            m.read(a)
            m.write(a, 0, 1 << l)  # and back to zero without touching the others
            m.read(a)
        m.write(a, 0xA5A5A5A5A5A5A5A5 & full, cfg.full_mask)
        masks = range(1 << mw) if mw <= 6 else [rng.getrandbits(mw) for _ in range(160)] + [0, cfg.full_mask] + [1 << l for l in range(mw)]
        for mask in masks:
            m.write(a, rng.getrandbits(cfg.dw), mask)
            m.read(a)
        m.write(a, full, 0)  # zero mask: nothing changes, still acknowledged (WRITE_ACK=1)
        m.read(a)
    await b.drain(20000, "lanes")
    b.finish("byte_lanes")


@cocotb.test()
async def invalid_address(dut):
    """addr >= DEPTH (non power-of-two depths only): error response, zero data, no side effect (also posted)."""
    b = build_sp(dut, SEED())
    cfg, m, rng = b.cfg, b.m, b.env.seeds.child("oor")
    await up(b)
    D = cfg.depth
    full = (1 << cfg.dw) - 1
    for a in range(D):
        m.write(a, ((a * 0x0101010101010101) ^ 0x5A5A5A5A5A5A5A5A) & full, cfg.full_mask)
    if cfg.pow2:
        # DEPTH is a power of two: every representable address is valid, there is no invalid address to test
        for a in range(D):
            m.read(a)
        await b.drain(20000, "pow2 readback")
        b.finish("invalid_address", n_a="pow2 depth: no representable invalid address")
        return
    cand = {D, D + 1, D + 2, cfg.last_addr, cfg.last_addr - 1, (D + cfg.last_addr) // 2} | {D + (1 << k) for k in range(cfg.aw)}
    bad = sorted(a for a in cand if D <= a <= cfg.last_addr)  # only addresses the AW-bit port can carry
    for a in bad:
        m.write(a, full, cfg.full_mask, id=1 & ((1 << cfg.idw) - 1))  # would corrupt an alias if not blocked
        m.read(a)
        m.write(a, full, 0)
        m.read(D - 1)  # in-range neighbours stay intact and valid
        m.read(0)
    for a in range(D):
        m.read(a)
    for _ in range(30):  # interleave valid and invalid addresses, random ids
        a = rng.choice(bad) if rng.random() < 0.5 else rng.randrange(D)
        (m.write(a, rng.getrandbits(cfg.dw), cfg.full_mask, id=rng.getrandbits(cfg.idw)) if rng.random() < 0.5 else m.read(a, id=rng.getrandbits(cfg.idw)))
    for a in range(D):
        m.read(a)
    await b.drain(20000, "invalid addresses")
    b.finish("invalid_address")


@cocotb.test()
async def credits_backpressure(dut):
    """Response stalls: credits (RSP_FIFO_DEPTH) are exhausted exactly when the spec says, posted writes still go
    through, long stalls hold the response stable, requests resume in order after the stall."""
    b = build_sp(dut, SEED(), rsp_thr="never" if params().get("RSP_FIFO_DEPTH", 1) != 0 else "always")
    cfg, m, rng = b.cfg, b.m, b.env.seeds.child("bp")
    await up(b)
    D = cfg.depth
    if cfg.fd == 0:
        # no-backpressure mode: the master must keep rsp_ready = 1 (spec); check a long burst of reads at full rate
        for k in range(200):
            m.read(rng.randrange(D))
        await b.drain(5000, "no-fifo burst")
        b.finish("credits_backpressure", mode="RSP_FIFO_DEPTH=0")
        return
    for a in range(1, min(D, 8), 2):
        m.write(a, word(cfg, rng), cfg.full_mask)
    # exhaust the credits with reads, then one more read (must be refused), a posted write behind it
    for k in range(cfg.fd):
        m.read(rng.randrange(D), id=k & ((1 << cfg.idw) - 1))
    m.write(rng.randrange(D), word(cfg, rng), cfg.full_mask)  # posted (WRITE_ACK=0): accepted with 0 credits free
    m.read(rng.randrange(D))  # refused until the stall ends
    m.read(rng.randrange(D))
    await b.env.cycles(cfg.rl + cfg.fd + 25)
    assert b.chk.credit_blocked > 0, "the credit limit was never reached"
    # release one response at a time (pattern), then everything
    m.rsp_thr.set_mode("pattern:0000000010000000")
    await b.env.cycles(60)
    m.rsp_thr.set_mode("always")
    for k in range(40):
        m.submit(rand_req(rng, cfg, cfg.mw, "mixed", 0.6, 0.1))
    await b.drain(5000, "release")
    # long stall with a response visible for a long time (stability checked every cycle) and then bursty readiness
    m.rsp_thr.set_mode("stall:120")
    for k in range(cfg.fd + 3):
        m.submit(rand_req(rng, cfg, cfg.mw, "hot", 0.8, 0.1))
    await b.env.cycles(150)
    m.rsp_thr.set_mode("bursty:1-9")
    for k in range(80):
        m.submit(rand_req(rng, cfg, cfg.mw, "mixed", 0.5, 0.1))
    await b.drain(8000, "bursty")
    b.finish("credits_backpressure")


@cocotb.test()
async def latency_throughput(dut):
    """Exact READ_LATENCY after acceptance and one access per cycle: the checker predicts rsp_valid every cycle,
    so any extra or missing cycle fails.  Throttled-request variants shift the pattern in time."""
    b = build_sp(dut, SEED())
    cfg, m, rng = b.cfg, b.m, b.env.seeds.child("lat")
    await up(b)
    D = cfg.depth
    for a in range(min(D, 16)):
        m.write(a, word(cfg, rng), cfg.full_mask)
    for k in range(120):  # continuous stream, one request per cycle, response channel always ready
        m.submit(rand_req(rng, cfg, cfg.mw, "mixed", 0.7, 0.05))
    await b.drain(3000, "stream")
    for spec in ("random:0.5", "bursty:1-5", "pattern:100", "pattern:1000000"):
        m.req_thr.set_mode(spec)
        for k in range(50):
            m.submit(rand_req(rng, cfg, cfg.mw, "mixed", 0.6, 0.05))
        await b.drain(3000, "throttle " + spec)
    # sustained one-per-cycle for RSP_FIFO_DEPTH >= READ_LATENCY + 1 is a spec statement: assert it explicitly
    if cfg.fd >= cfg.rl + 1 and cfg.wa:
        m.req_thr.set_mode("always")
        n0 = m.n_accepted
        c0 = b.env.cycle
        for k in range(64):
            m.read(rng.randrange(D))
        await b.env.until(lambda: m.idle, 500, "stream accepted")
        assert m.n_accepted - n0 == 64
        assert b.env.cycle - c0 <= 64 + 2, "back-to-back reads were not sustained at one per cycle (%d cycles)" % (b.env.cycle - c0)
    await b.drain(3000, "tail")
    b.finish("latency_throughput")


# --------------------------------------------------------------------------- random


PROFILES = ["uniform", "mixed", "hot", "boundary"]
REQ_THR = ["always", "random:0.7", "random:0.3", "bursty:1-6", "pattern:110"]
RSP_THR = ["always", "random:0.8", "random:0.4", "bursty:1-8", "random:0.15"]


@cocotb.test()
async def random_traffic(dut):
    """Seeded random traffic: boundary-biased addresses, random masks/data/ids, random stalls on every ready."""
    seed = SEED()
    b = build_sp(dut, seed)
    cfg, m, rng = b.cfg, b.m, b.env.seeds.child("rnd")
    await up(b)
    for phase in range(8):
        m.req_thr.set_mode(rng.choice(REQ_THR))
        if cfg.fd:
            m.rsp_thr.set_mode(rng.choice(RSP_THR))
        prof = rng.choice(PROFILES)
        rf = rng.choice([0.2, 0.5, 0.8])
        for k in range(400):
            m.submit(rand_req(rng, cfg, cfg.mw, prof, rf, 0.08))
        await b.drain(30000, "phase %d" % phase)
    b.finish("random_traffic")


@cocotb.test()
async def max_depth_sweep(dut):
    """Maximum-depth sweep with random stalls: write every word under back-pressure, then read all."""
    b = build_sp(dut, SEED(), req_thr="random:0.6", rsp_thr="always" if params().get("RSP_FIFO_DEPTH", 1) == 0 else "random:0.5")
    cfg, m, rng = b.cfg, b.m, b.env.seeds.child("sweep")
    await up(b)
    D = cfg.depth
    order = list(range(D))
    rng.shuffle(order)
    ref = {}
    for a in order:
        v = word(cfg, rng)
        ref[a] = v
        m.write(a, v, cfg.full_mask, id=rng.getrandbits(cfg.idw))
    for a in order[::-1]:
        m.read(a, id=rng.getrandbits(cfg.idw))
    await b.drain(60000, "sweep")
    # independent end-to-end proof that the model and the DUT agree on the data (not only via the checker)
    assert all(b.chk.m.mem.exact_word(a) == ref[a] for a in order), "model memory differs from the generated image"
    b.finish("max_depth_sweep")


# --------------------------------------------------------------------------- reset


async def _reset_round(b, rng, fire, max_cycles=600, what="reset"):
    """Wait for the reset to assert, then queue fresh requests WHILE it is asserted so that the master presents
    them in the very first cycle after release (req_ready must be 0 there), then wait for the release."""
    n0 = b.rst.n_pulses
    await b.env.until(lambda: b.rst.n_pulses > n0, max_cycles, what + " to fire")
    cfg = b.cfg
    for k in range(rng.randint(0, 3)):
        b.m.submit(rand_req(rng, cfg, cfg.mw, "mixed", 0.5, 0.1))
    await b.env.until(lambda: not b.rst.asserted, 30, what + " release")


def armed(b, pred, length, reason, patience=150):
    """State-triggered reset with a deadline so that a trigger that cannot occur in this configuration
    degrades to a plain pulse instead of hanging (the reason string of the fallback is recorded)."""
    dl = b.env.cycle + patience
    b.rst.arm(lambda: pred() or b.env.cycle >= dl, length, reason)


@cocotb.test()
async def reset_during_traffic(dut):
    """Synchronous resets (1-3 cycles, scheduled and state-triggered) in the middle of random traffic.  A reset
    cancels every outstanding response and every request that was not accepted; accepted writes stay in the
    array (they are architecturally complete at acceptance, the array is never reset) and read back correctly."""
    seed = SEED()
    b = build_sp(dut, seed, rsp_thr="always")
    cfg, m, rng = b.cfg, b.m, b.env.seeds.child("rst")
    await up(b)
    for rnd in range(20):
        if cfg.fd:
            m.rsp_thr.set_mode(rng.choice(["random:0.3", "random:0.6", "bursty:2-10"]))
        m.req_thr.set_mode(rng.choice(["always", "random:0.7"]))
        for k in range(rng.randint(20, 70)):
            m.submit(rand_req(rng, cfg, cfg.mw, rng.choice(PROFILES), 0.5, 0.05))
        length = rng.choice([1, 1, 2, 3])
        kind = rnd % 5
        if kind == 0:
            b.rst.pulse(length, delay=rng.randint(1, 25), reason="sync-random")
        elif kind == 1:
            armed(b, lambda: b.chk.m.rsp.outstanding >= 1, length, "outstanding>=1")
        elif kind == 2:
            armed(b, lambda: b.chk.m.rsp.outstanding >= max(2, cfg.fd), length, "credits-full")
        elif kind == 3:
            if rnd % 2:
                armed(b, lambda: b.chk._rsp_vis_prev, length, "response-stalled")
            else:
                armed(b, lambda: b.chk._rsp_vis_prev and b.chk.m.rsp.outstanding == 1, length, "single-response-stalled")
        else:
            armed(b, lambda: b.chk.m.rsp.outstanding >= 1 and b.m.cur is not None, length, "busy+request-pending")
        await _reset_round(b, rng, None, 600, "reset round %d" % rnd)
        await b.env.cycles(rng.randint(0, 4))
    # full read-back: memory content written before the resets must be intact
    m.rsp_thr.set_mode("always")
    m.req_thr.set_mode("always")
    for a in range(cfg.depth):
        m.read(a)
    await b.drain(20000, "read-back after resets")
    assert b.rst.n_pulses >= 20
    b.finish("reset_during_traffic", resets=b.rst.n_pulses, cancelled=b.chk.n_cancelled)


@cocotb.test()
async def reset_async_midcycle(dut):
    """Asynchronous reset asserted between clock edges (several phases, incl. just before the next edge)
    while requests are accepted and responses are pending."""
    seed = SEED()
    b = build_sp(dut, seed, rsp_thr="always")
    cfg, m, rng = b.cfg, b.m, b.env.seeds.child("arst")
    await up(b)
    phases = [0.5, 2.0, 4.0, 5.0, 7.5, 9.0, 9.9]
    for rnd in range(len(phases) * 2):
        if cfg.fd:
            m.rsp_thr.set_mode(rng.choice(["random:0.35", "random:0.7", "always"]))
        for k in range(rng.randint(15, 40)):
            m.submit(rand_req(rng, cfg, cfg.mw, rng.choice(PROFILES), 0.5, 0.05))
        await b.env.cycles(rng.randint(2, 18))
        b.chk.mark_async()
        # started as a concurrent coroutine: it awaits the next rising edge together with env.tick() (which keeps
        # stepping the agents), then asserts rst_n phase_ns after that edge, i.e. in the middle of a clock period
        cocotb.start_soon(b.rst.async_pulse(phases[rnd % len(phases)], length_cycles=rng.choice([1, 1, 2, 3])))
        await _reset_round(b, rng, None, 40, "async reset round %d" % rnd)
        await b.env.cycles(rng.randint(0, 3))
    m.rsp_thr.set_mode("always")
    for a in range(cfg.depth):
        m.read(a)
    await b.drain(20000, "read-back after async resets")
    b.finish("reset_async_midcycle", resets=b.rst.n_pulses, cancelled=b.chk.n_cancelled)


@cocotb.test()
async def reset_power_up(dut):
    """Power-up state: contents are random and unspecified (init='unknown'): reads of never-written words return
    anything but must be stable; reset releases with req_ready = 0 for one cycle."""
    b = build_sp(dut, SEED(), initial_reset=1)  # shortest legal initial reset
    cfg, m, rng = b.cfg, b.m, b.env.seeds.child("pu")
    await up(b)
    D = cfg.depth
    for a in range(D):
        m.read(a)
    for a in range(D):
        m.read(a)  # second pass: values observed in the first pass must repeat
    await b.drain(20000, "power-up reads")
    b.finish("reset_power_up")


# --------------------------------------------------------------------------- MBIST test port


@cocotb.test()
async def test_port_mode(dut):
    """tst_active = 1 hands the array to the MBIST bus: req_ready = 0 for as long as it is high, requests accepted
    before it keep completing, test writes cover all lanes, test reads return raw data exactly READ_LATENCY
    cycles later, test addresses >= DEPTH are ignored."""
    b = build_sp(dut, SEED(), test_port=True, req_thr="random:0.8", rsp_thr="always" if params().get("RSP_FIFO_DEPTH", 1) == 0 else "random:0.7")
    cfg, m, tp, rng = b.cfg, b.m, b.tp, b.env.seeds.child("tst")
    await up(b)
    D = cfg.depth
    full = (1 << cfg.dw) - 1
    for a in range(min(D, 24)):
        m.write(a, word(cfg, rng), cfg.full_mask)
    await b.drain(3000, "fill")
    # requests presented while the test port owns the array must wait (ready = 0 is checked every cycle)
    tp.hold(12)
    for k in range(4):
        m.read(k)
        m.write(k + 4, word(cfg, rng), cfg.mw and cfg.full_mask)
    await b.env.until(lambda: tp.idle_now, 100, "test mode window")
    await b.drain(3000, "requests after the window")
    # test writes (all lanes, whatever wmask says), test reads of functionally written words and vice versa
    for a in range(min(D, 24)):
        tp.write(a, rng.getrandbits(cfg.dw))
        tp.read(a)
        tp.read((a * 7) % min(D, 24))
    tp.idle(2)
    await b.env.until(lambda: tp.idle_now, 400, "test script")
    for a in range(min(D, 24)):
        m.read(a)
    await b.drain(3000, "functional read of test-written words")
    if not cfg.pow2:  # addresses >= DEPTH on the test port are gated: no access, no corruption
        for a in range(D, cfg.last_addr + 1):
            tp.write(a, full)
            tp.read(a)
        tp.idle(3)
        await b.env.until(lambda: tp.idle_now, 400, "oor test script")
        for a in range(D):
            m.read(a)
        await b.drain(5000, "read-back after invalid test accesses")
    # random interleave of functional traffic and test-mode windows
    for rnd in range(40):
        for k in range(rng.randint(1, 8)):
            m.submit(rand_req(rng, cfg, cfg.mw, "mixed", 0.6, 0.05))
        for k in range(rng.randint(0, 6)):
            x = rng.random()
            if x < 0.35:
                tp.write(rng.randrange(D), rng.getrandbits(cfg.dw))
            elif x < 0.7:
                tp.read(rng.randrange(D))
            elif x < 0.85:
                tp.hold(rng.randint(1, 4))
            else:
                tp.idle(rng.randint(1, 3))
        await b.env.cycles(rng.randint(2, 14))
    await b.env.until(lambda: tp.idle_now, 400, "random test script")
    await b.drain(8000, "interleave")
    assert b.chk.n_tst_reads > 20 and b.chk.n_tst_writes > 20 and b.chk.n_tst_blocked > 5
    b.finish("test_port_mode", tst_reads=b.chk.n_tst_reads, tst_writes=b.chk.n_tst_writes)
