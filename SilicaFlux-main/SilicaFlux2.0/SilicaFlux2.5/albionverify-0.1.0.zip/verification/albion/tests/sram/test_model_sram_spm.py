"""Unit tests of the HPC scratchpad reference model; golden values are the examples printed in
rtl/hpc_m04_scratchpad/docs/02_address_map.md and 03_banking_and_arbitration.md."""
import pytest

from albionverify.models.sram_spm import (ARB_FIXED, ARB_RR, ERR_ALIGN, ERR_OK, ERR_RANGE, ERR_STROBE, MAP_HIGH, MAP_LOW, MAP_XOR,
                                          PORT_1R1W, PORT_1RW, PORT_2RW, SReq, SpmModel)


def big(map_=MAP_LOW, **kw):
    d = dict(num_ports=2, capacity=65536, num_banks=4, data_width=32, addr_width=32)
    d.update(kw)
    m = SpmModel(map_=map_, **d)
    m.begin_edge()
    m.begin_edge()
    return m


# ---- doc 02 sec. 2: 64 KiB, 4 banks, 32-bit words, bank depth 4096
GOLD = [  # byte address, LOW (bank,row), XOR (bank,row), HIGH (bank,row)
    (0x00000, (0, 0), (0, 0), (0, 0)),
    (0x00004, (1, 0), (1, 0), (0, 1)),
    (0x00008, (2, 0), (2, 0), (0, 2)),
    (0x0000C, (3, 0), (3, 0), (0, 3)),
    (0x00010, (0, 1), (1, 1), (0, 4)),
    (0x00014, (1, 1), (0, 1), (0, 5)),
    (0x00018, (2, 1), (3, 1), (0, 6)),
    (0x0001C, (3, 1), (2, 1), (0, 7)),
    (0x00020, (0, 2), (2, 2), (0, 8)),
    (0x03FFC, (3, 1023), (0, 1023), (0, 4095)),
    (0x04000, (0, 1024), (0, 1024), (1, 0)),
    (0x0FFFC, (3, 4095), (0, 4095), (3, 4095)),
]


@pytest.mark.parametrize("addr,low,xor,high", GOLD)
def test_model_address_map_doc_examples(addr, low, xor, high):
    for map_, exp in ((MAP_LOW, low), (MAP_XOR, xor), (MAP_HIGH, high)):
        d = big(map_).decode(addr, False, 0)
        assert d.ok and (d.bank, d.row) == exp, (hex(addr), map_, (d.bank, d.row), exp)


def test_model_map_is_a_bijection_on_a_small_config():
    for map_ in (MAP_LOW, MAP_XOR, MAP_HIGH):
        m = SpmModel(2, 1024, 4, 32, 16, 0, map_=map_)  # 256 words, 4 banks of 64 rows
        seen = {(m.decode(4 * w, False, 0).bank, m.decode(4 * w, False, 0).row) for w in range(256)}
        assert len(seen) == 256


def test_model_range_alignment_strobe_and_priority():
    m = SpmModel(2, 1024, 4, 32, 16, base=0x4000, byte_we=0)
    assert m.decode(0x4000, False, 0).ok and m.decode(0x43FC, False, 0).ok
    assert m.decode(0x4400, False, 0).code == ERR_RANGE  # first byte past the window
    assert m.decode(0x3FFC, False, 0).code == ERR_RANGE  # below BASE
    assert m.decode(0x0000, False, 0).code == ERR_RANGE  # an alias of word 0 in a lower window is NOT word 0
    assert m.decode(0x8000, False, 0).code == ERR_RANGE
    assert m.decode(0x4001, False, 0).code == ERR_ALIGN
    assert m.decode(0x4400 + 1, False, 0).code == ERR_RANGE  # RANGE before ALIGN
    assert m.decode(0x4000, True, 0b0111).code == ERR_STROBE  # BYTE_WE = 0: partial strobe rejected
    assert m.decode(0x4001, True, 0b0111).code == ERR_ALIGN  # ALIGN before STROBE
    assert m.decode(0x4000, True, 0b1111).ok
    assert m.decode(0x4000, False, 0b0000).ok  # strobes are ignored for reads
    m2 = SpmModel(2, 1024, 4, 32, 16, base=0x4000, byte_we=1)
    assert m2.decode(0x4000, True, 0).ok  # BYTE_WE = 1: wstrb = 0 is a legal no-op write


def test_model_aligned_word_index_uses_offset_from_base():
    m = SpmModel(1, 1024, 2, 32, 16, base=0x4000)
    assert m.decode(0x4008, False, 0).word == 2


# ---- doc 01 sec. 5 timing example: two ports, bank 0, port 0 wins, port 1 granted a cycle later and sees the NEW data
def test_model_doc_timing_example_write_then_read_other_port():
    m = SpmModel(2, 1024, 2, 32, 16, read_latency=1, tag_w=8)
    m.begin_edge(); m.begin_edge()
    A = 0x0
    reqs = [SReq(True, True, A, 0xAABBCCDD, 0xF, 5), SReq(True, False, A, 0, 0, 9)]
    p = m.predict(True, reqs)
    assert p.ready == [True, False] and p.conflict == [False, True] and p.bank_conflict[0] is True
    e0 = m.accept(1, 0, reqs[0], p)
    m.end_edge(p, reqs, [False, False])
    assert e0.due == 2 and e0.we and e0.id == 5  # write ack in cycle 1 + RL (edge numbering of the model)
    reqs = [SReq(False), SReq(True, False, A, 0, 0, 9)]
    p = m.predict(True, reqs)
    assert p.ready == [False, True]
    e1 = m.accept(2, 1, reqs[1], p)
    assert m.check_rsp_data(e1, 0xAABBCCDD) is None  # returns the NEW value of A


def test_model_rr_pointer_moves_past_first_winner_1r1w_starvation_example():
    """doc 03 sec. 3: port 0 writes row X every cycle, port 1 reads row X, port 2 reads row Y.  Moving the pointer past the
    LAST winner would starve port 1; past the FIRST winner it is served in the second cycle."""
    m = SpmModel(3, 1024, 1, 32, 12, port_mode=PORT_1R1W, rsp_fifo_depth=0)
    m.begin_edge(); m.begin_edge()
    X, Y = 4 * 3, 4 * 7
    reqs = [SReq(True, True, X, 1, 0xF), SReq(True, False, X), SReq(True, False, Y)]
    p = m.predict(True, reqs)
    assert p.ready == [True, False, True]  # p0 write slot, p1 blocked by the same-row hazard, p2 takes the read slot
    for i in (0, 2):
        m.accept(1, i, reqs[i], p)
    m.end_edge(p, reqs, [False] * 3)
    assert m.ptr[0] == 1  # first winner (port 0) + 1
    p = m.predict(True, reqs)
    assert p.ready == [False, True, False]  # port 1 now first in order: read slot; port 2 loses it; port 0 write blocked by hazard on X
    assert p.bank_ops == [1]


def test_model_2rw_same_row_only_for_two_reads():
    m = SpmModel(3, 1024, 1, 32, 12, port_mode=PORT_2RW, rsp_fifo_depth=0)
    m.begin_edge(); m.begin_edge()
    R = 4 * 5
    p = m.predict(True, [SReq(True, False, R), SReq(True, False, R), SReq(True, False, 4 * 6)])
    assert p.ready == [True, True, False] and p.bank_ops == [2]
    p = m.predict(True, [SReq(True, False, R), SReq(True, True, R, 1, 0xF), SReq(True, False, 4 * 6)])
    assert p.ready == [True, False, True]  # read + write of one row never together; the third port takes slot B
    p = m.predict(True, [SReq(True, True, R, 1, 0xF), SReq(True, True, 4 * 9, 1, 0xF), SReq(True, False, 4 * 6)])
    assert p.ready == [True, True, False]


def test_model_fixed_priority_port0_never_waits():
    m = SpmModel(3, 1024, 2, 32, 12, arb=ARB_FIXED, rsp_fifo_depth=0)
    m.begin_edge(); m.begin_edge()
    for c in range(1, 6):
        reqs = [SReq(True, False, 0), SReq(True, False, 8), SReq(True, False, 16)]  # all bank 0 (LOW: w mod 2)
        p = m.predict(True, reqs)
        assert p.ready == [True, False, False] and p.conflict == [False, True, True]
        m.accept(c, 0, reqs[0], p)
        m.end_edge(p, reqs, [False] * 3)


def test_model_error_request_issues_without_bank_and_events():
    m = SpmModel(2, 1024, 2, 32, 16, base=0x4000)
    m.begin_edge(); m.begin_edge()
    reqs = [SReq(True, False, 0x4000), SReq(True, True, 0x9000, 1, 0xF, 3)]  # port 1 out of range
    p = m.predict(True, reqs)
    assert p.ready == [True, True] and p.error == [False, True] and p.conflict == [False, False] and p.bank_ops == [1, 0]
    e = m.accept(1, 1, reqs[1], p)
    assert e.err and e.we and e.code == ERR_RANGE and e.id == 3
    assert m.mem.exact_word(0) is None


def test_model_credit_stall_event_and_not_eligible():
    m = SpmModel(1, 1024, 2, 32, 16, rsp_fifo_depth=1)
    m.begin_edge(); m.begin_edge()
    r = [SReq(True, False, 0)]
    p = m.predict(True, r)
    m.accept(1, 0, r[0], p)
    p = m.predict(True, r)
    assert p.ready == [False] and p.credit_stall == [True] and p.conflict == [False]  # out of credits: a stall, not a conflict


def test_model_first_cycle_after_reset_not_ready_and_pointer_cleared():
    m = SpmModel(2, 1024, 2, 32, 16)
    m.begin_edge(); m.begin_edge()
    r = [SReq(True, False, 0), SReq(True, False, 8)]
    p = m.predict(True, r)
    m.accept(1, 0, r[0], p)
    m.end_edge(p, r, [False, False])
    assert m.ptr[0] == 1
    m.reset()
    assert m.ptr == [0, 0] and m.counters["accept"] == [0, 0]
    live = m.begin_edge()
    assert live is False and m.predict(live, r).ready == [False, False]


def test_model_counters_saturate_and_never_wrap():
    m = SpmModel(1, 1024, 2, 32, 16, cnt_w=8, rsp_fifo_depth=0)
    m.begin_edge(); m.begin_edge()
    r = [SReq(True, False, 0)]
    for c in range(1, 300):
        p = m.predict(True, r)
        m.accept(c, 0, r[0], p)
        m.end_edge(p, r, [False])
    assert m.counters["cycles"] == [255] and m.counters["accept"] == [255] and m.counters["bank_ops"] == [255, 0]


def test_model_wait_counter_counts_presented_and_not_issued():
    m = SpmModel(2, 1024, 1, 32, 12, rsp_fifo_depth=0)
    m.begin_edge(); m.begin_edge()
    r = [SReq(True, False, 0), SReq(True, False, 4)]
    p = m.predict(True, r)
    for i in range(2):
        if p.ready[i]:
            m.accept(1, i, r[i], p)
    m.end_edge(p, r, [False, False])
    assert m.counters["wait"] == [0, 1] and m.counters["conflict"] == [0, 1]
