"""Unit tests of the bank-controller reference model (no simulator); examples hand-computed from
rtl/sramlib/docs/mem/03_banking.md."""
import pytest

from albionverify.models.sram_bank import ADDR_BYTE, FIXED, ILV_HIGH, ILV_LOW, RR, BankModel, BReq


def mk(**kw):
    d = dict(num_masters=4, num_banks=4, data_width=32, mask_width=4, bank_depth=16, read_latency=1)
    d.update(kw)
    m = BankModel(**d)
    m.begin_edge()  # first edge after reset release (not live)
    m.begin_edge()
    return m


def rd(addr, valid=True, id=0):
    return BReq(valid, False, addr, 0, 0, id)


def wr(addr, data=0, mask=0xF, valid=True, id=0):
    return BReq(valid, True, addr, data, mask, id)


# --------------------------------------------------------------------------- address decode

def test_model_decode_low_interleave():
    m = mk()
    d = m.decode(5)
    assert (d.ok, d.bank, d.row, d.word) == (True, 1, 1, 5)  # word % 4, word // 4 (spec 03 "Interleave")
    d = m.decode(63)
    assert (d.bank, d.row) == (3, 15)
    assert not m.decode(64).ok and m.decode(64).kind == "range"  # TOTAL = 4 * 16


def test_model_decode_high_interleave():
    m = mk(interleave=ILV_HIGH)
    d = m.decode(17)
    assert (d.bank, d.row) == (1, 1)  # word // BANK_DEPTH, word % BANK_DEPTH
    assert (m.decode(15).bank, m.decode(16).bank) == (0, 1)


def test_model_decode_byte_mode_alignment_and_offset():
    m = mk(addr_mode=ADDR_BYTE)
    assert m.decode(4).word == 1 and m.decode(4).ok
    d = m.decode(5)
    assert not d.ok and d.kind == "align"
    assert not m.decode(64 * 4).ok  # word 64 = TOTAL
    assert m.decode(63 * 4).ok


def test_model_byte_mode_has_no_offset_for_narrow_words():
    m = mk(addr_mode=ADDR_BYTE, data_width=8, mask_width=1)
    assert m.boff == 0 and m.decode(3).ok and m.decode(3).word == 3


def test_model_decode_single_bank():
    m = mk(num_banks=1, bank_depth=10, num_masters=2)
    d = m.decode(7)
    assert (d.bank, d.row) == (0, 7) and not m.decode(10).ok


# --------------------------------------------------------------------------- arbitration

def test_model_parallel_banks_all_granted_same_cycle():
    m = mk()
    reqs = [rd(0), rd(1), rd(2), rd(3)]  # banks 0..3
    p = m.predict(True, reqs)
    assert p.ready == [True] * 4 and p.stall == [False] * 4 and sorted(p.grant) == [0, 1, 2, 3]


def test_model_same_bank_one_grant_rr_rotates_from_pointer_zero():
    m = mk(rsp_fifo_depth=0)  # no credit limit: isolate the arbiter
    order = []
    for c in range(1, 9):
        reqs = [rd(0), rd(4), rd(8), rd(12)]  # all in bank 0 (words 0,4,8,12), different rows
        p = m.predict(True, reqs)
        assert sum(p.ready) == 1
        w = p.ready.index(True)
        order.append(w)
        assert p.stall[w] is False and sum(p.stall) == 3  # the three losers report a conflict
        m.accept(c, w, reqs[w], p)
    assert order == [0, 1, 2, 3, 0, 1, 2, 3]


def test_model_rr_pointer_moves_past_the_winner_not_past_the_last_requester():
    m = mk(rsp_fifo_depth=0)
    # masters 1 and 3 request bank 0; pointer 0 -> winner 1, pointer becomes 2 -> next winner is 3, then 1
    seq = []
    for c in range(1, 5):
        reqs = [rd(1, valid=False), rd(0), rd(1, valid=False), rd(4)]
        p = m.predict(True, reqs)
        w = p.ready.index(True)
        seq.append(w)
        m.accept(c, w, reqs[w], p)
    assert seq == [1, 3, 1, 3]


def test_model_fixed_priority_master0_always_wins_others_starve():
    m = mk(arb=FIXED, rsp_fifo_depth=0)
    for c in range(1, 6):
        reqs = [rd(0), rd(4), rd(8), rd(12)]
        p = m.predict(True, reqs)
        assert p.ready == [True, False, False, False]
        m.accept(c, 0, reqs[0], p)
    reqs = [rd(0, valid=False), rd(4), rd(8), rd(12)]
    assert m.predict(True, reqs).ready == [False, True, False, False]  # lowest index wins, not round robin


def test_model_credit_less_master_is_not_eligible_and_does_not_block():
    m = mk(rsp_fifo_depth=1)
    p = m.predict(True, [rd(0), rd(1), rd(2), rd(3)])
    for i in range(4):
        m.accept(1, i, [rd(0), rd(1), rd(2), rd(3)][i], p)  # every master used its only credit
    assert m.ports[0].credit_free() is False
    reqs = [rd(0), rd(1), rd(2), rd(3)]
    p = m.predict(True, reqs)
    assert p.ready == [False] * 4 and p.stall == [False] * 4  # not eligible: no grant, and not a "conflict" either


def test_model_error_request_needs_only_a_credit_not_a_bank():
    m = mk()
    reqs = [rd(0), rd(64), rd(4), rd(8)]  # masters 0,2,3 contend for bank 0; master 1 is out of range
    p = m.predict(True, reqs)
    assert p.ready[1] is True  # error request accepted although bank 0 is busy
    assert p.stall[1] is False
    assert sum(p.ready[i] for i in (0, 2, 3)) == 1


def test_model_not_ready_in_first_cycle_after_reset():
    m = BankModel(2, 2, 32, 4, 8)
    m.reset()
    live = m.begin_edge()
    assert live is False
    p = m.predict(live, [rd(0), rd(1)])
    assert p.ready == [False, False] and p.stall == [False, False]
    live = m.begin_edge()
    assert m.predict(live, [rd(0), rd(1)]).ready == [True, True]


def test_model_posted_write_needs_no_credit_in_arbitration():
    m = mk(write_ack=0, rsp_fifo_depth=1)
    reqs = [rd(0), rd(1), rd(2), rd(3)]
    p = m.predict(True, reqs)
    for i in range(4):
        m.accept(1, i, reqs[i], p)
    reqs = [wr(0), wr(1), rd(2), wr(3)]  # master 2's read needs a credit (none left), posted writes do not
    p = m.predict(True, reqs)
    assert p.ready == [True, True, False, True]


# --------------------------------------------------------------------------- data / responses

def test_model_write_then_read_other_master_sees_data():
    m = mk()
    r = wr(9, 0xA1B2C3D4)
    p = m.predict(True, [r, rd(0, valid=False), rd(0, valid=False), rd(0, valid=False)])
    m.accept(1, 0, r, p)
    r2 = rd(9, id=7)
    p2 = m.predict(True, [rd(0, valid=False), r2, rd(0, valid=False), rd(0, valid=False)])
    e = m.accept(2, 1, r2, p2)
    assert m.check_rsp_data(e, 0xA1B2C3D4) is None and e.id == 7 and e.due == 3


def test_model_error_response_has_zero_data_and_no_side_effect():
    m = mk()
    r = wr(70, 0xFFFFFFFF)
    e = m.accept(1, 0, r, m.predict(True, [r, rd(0, False), rd(0, False), rd(0, False)]))
    assert e.err and e.we and m.stats["err_write"] == 1
    assert m.mem.exact_word(70) is None and m.mem.snapshot(0).cons[0] is None
    assert m.check_rsp_data(e, 0) is None


def test_model_reset_clears_pointers_and_responses_keeps_memory():
    m = mk()
    r = wr(0, 0x55)
    p = m.predict(True, [r, rd(0, False), rd(0, False), rd(0, False)])
    m.accept(1, 0, r, p)
    assert m.ptr[0] == 1
    gone = m.reset()
    assert len(gone) == 1 and m.ptr == [0, 0, 0, 0]
    assert m.mem.snapshot(0).cons[0] == frozenset({0x55})
