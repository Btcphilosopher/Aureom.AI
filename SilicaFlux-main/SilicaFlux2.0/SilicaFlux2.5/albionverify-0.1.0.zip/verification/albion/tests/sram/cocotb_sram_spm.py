"""cocotb bench for ``hpc_scratchpad`` (direct mode): data / byte strobes / address map / bank conflicts /
arbitration / error codes / events / counters / reset.  Stimulus only; ``sram_spm_bench.SpmChecker`` compares every
edge with ``albionverify.models.sram_spm`` (written from rtl/hpc_m04_scratchpad/docs/01-03)."""
import os

import cocotb

from albionverify.bus.reqrsp import Req

from sram.sram_bench import params
from sram.sram_spm_bench import SpmCfg, build_spm, rand_sreq

SEED = lambda: int(os.environ.get("ALBION_SEED", "1"))


async def up(b):
    await b.env.start()
    await b.env.until(lambda: not b.rst.asserted, 50, "reset release")
    await b.env.cycles(2)


def uniq(cfg: SpmCfg, w: int, salt: int = 0) -> int:
    return (((w + 1) * 0x9E3779B97F4A7C15) ^ (salt * 0xC2B2AE3D27D4EB4F)) & ((1 << cfg.dw) - 1)


def tag(cfg: SpmCfg, k: int) -> int:
    return k & ((1 << cfg.tag_w) - 1)


def full(cfg: SpmCfg) -> int:
    return (1 << cfg.nbytes) - 1


# --------------------------------------------------------------------------- directed


@cocotb.test()
async def map_data(dut):
    """Every word of the scratchpad written (unique data) through one port and read back through another: a wrong
    bank/row map, aliasing or a lost write shows as wrong data.  Words outside the window (below BASE, above, and
    aliases that share the low address bits) are rejected and leave the window unchanged."""
    b = build_spm(dut, SEED(), rsp_thr="random:0.85")
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("map")
    await up(b)
    W, NP = cfg.words, cfg.np
    for w in range(W):
        ms[w % NP].write(cfg.addr_of(w), uniq(cfg, w), full(cfg), id=tag(cfg, w))
    await b.drain(40000, "write every word")
    for w in range(W):
        ms[(w + 1) % NP].read(cfg.addr_of(w), id=tag(cfg, w + 1))
    for w in reversed(range(W)):
        ms[(w * 5 + 1) % NP].read(cfg.addr_of(w), id=tag(cfg, w + 2))
    await b.drain(40000, "read every word")
    # rejected requests: every address bit above the window is compared, so none of these is an alias of a window word
    rej = [cfg.base + cfg.cap, cfg.base + cfg.cap + cfg.nbytes, (cfg.base - cfg.nbytes) & ((1 << cfg.aw) - 1)]
    for k in range(cfg.aw):
        hi = (1 << k)
        if hi >= cfg.cap and (cfg.base ^ hi) < (1 << cfg.aw):
            rej.append((cfg.base ^ hi) + 0)  # flips one upper address bit: same window offset, different window
    rej += [(1 << cfg.aw) - cfg.nbytes]
    for a in sorted(set(x & ((1 << cfg.aw) - 1) for x in rej)):
        if cfg.base <= a < cfg.base + cfg.cap:
            continue
        ms[rng.randrange(NP)].write(a, (1 << cfg.dw) - 1, full(cfg))
        ms[rng.randrange(NP)].read(a)
    for w in range(W):
        ms[rng.randrange(NP)].read(cfg.addr_of(w))
    await b.drain(40000, "after rejected requests")
    await b.settle()
    b.finish("map_data")


@cocotb.test()
async def byte_strobes(dut):
    """Every strobe pattern (all 2^(DW/8) for DW<=32, walking + random otherwise) on words of every bank; with
    BYTE_WE = 0 every partial strobe is rejected (STROBE) with no side effect and the all-ones strobe works.
    A zero strobe with BYTE_WE = 1 is a legal no-op that is still acknowledged."""
    b = build_spm(dut, SEED(), rsp_thr="random:0.9")
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("strb")
    await up(b)
    NB, NBY = cfg.nb, cfg.nbytes
    words = sorted({cfg.word_in_bank(k, rng.randrange(cfg.bank_depth)) for k in range(NB)} | {0, cfg.words - 1})
    masks = list(range(1 << NBY)) if NBY <= 4 else sorted({0, full(cfg)} | {1 << l for l in range(NBY)} | {rng.getrandbits(NBY) for _ in range(60)})
    for w in words:
        a = cfg.addr_of(w)
        ms[0].write(a, uniq(cfg, w), full(cfg))
        for mk in masks:
            ms[rng.randrange(cfg.np)].write(a, rng.getrandbits(cfg.dw), mk, id=tag(cfg, mk))
            ms[rng.randrange(cfg.np)].read(a)
        ms[0].write(a, (1 << cfg.dw) - 1, 0)  # zero strobe
        ms[0].read(a)
    await b.drain(40000, "strobes")
    await b.settle()
    b.finish("byte_strobes")


@cocotb.test()
async def bank_conflicts(dut):
    """All ports on one bank (different rows), on one word, on one row (same-row hazards for 1R1W / 2RW), on
    different banks (parallel).  RR: a port waits at most NUM_PORTS-1 cycles (doc 03); FIXED: port 0 never waits;
    ports on different banks never conflict."""
    b = build_spm(dut, SEED())
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("cf")
    await up(b)
    NP, NB = cfg.np, cfg.nb
    # (1) parallel: one bank per port
    if NP <= NB:
        c0 = b.chk.conflict_cycles
        for m in ms:
            m.req_thr.set_mode("never")
        for i, m in enumerate(ms):
            for k in range(40):
                m.read(cfg.addr_of(cfg.word_in_bank(i, rng.randrange(cfg.bank_depth))))
        await b.env.cycles(2)
        for m in ms:
            m.req_thr.set_mode("always")
        await b.drain(5000, "parallel")
        assert b.chk.conflict_cycles == c0, "ports on different banks must not conflict"
    # (2)-(4) contention patterns, all requests presented together
    for pattern in ("bank", "word", "row", "stride"):
        for m in ms:
            m.req_thr.set_mode("never")
        bank = rng.randrange(NB)
        row = rng.randrange(cfg.bank_depth)
        for i, m in enumerate(ms):
            for k in range(30):
                if pattern == "bank":
                    w = cfg.word_in_bank(bank, rng.randrange(cfg.bank_depth))
                elif pattern == "word":
                    w = cfg.word_in_bank(bank, row)
                elif pattern == "row":
                    w = cfg.word_in_bank(bank, row)  # same (bank, row) = same word: reads and writes mixed below
                else:
                    w = (k * NB + bank) % cfg.words
                (m.write(cfg.addr_of(w), rng.getrandbits(cfg.dw), rng.getrandbits(cfg.nbytes) if cfg.byte_we else full(cfg), id=tag(cfg, k)) if (k % 3 == i % 3) else m.read(cfg.addr_of(w), id=tag(cfg, k)))
        b.chk.max_lost_run[:] = [0] * NP
        await b.env.cycles(2)
        for m in ms:
            m.req_thr.set_mode("always")
        await b.drain(20000, "contention " + pattern)
        if cfg.arb == 0 and cfg.pm == 0:
            assert max(b.chk.max_lost_run) <= NP - 1, "RR wait bound violated: %s" % b.chk.max_lost_run
        if cfg.arb == 1:
            assert b.chk.max_lost_run[0] == 0, "FIXED priority: port 0 must never lose a bank (%s)" % b.chk.max_lost_run
    await b.settle()
    b.finish("bank_conflicts", conflict_cycles=b.chk.conflict_cycles, max_lost_run=b.chk.max_lost_run)


@cocotb.test()
async def isolation_backpressure(dut):
    """A port whose consumer never takes responses is held after RSP_FIFO_DEPTH outstanding responses; other ports keep
    full speed (doc 03 sec. 4).  Then release."""
    b = build_spm(dut, SEED())
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("iso")
    await up(b)
    if cfg.fd == 0 or cfg.np < 2:
        b.finish("isolation_backpressure", mode="n/a")
        return
    ms[0].rsp_thr.set_mode("never")
    for k in range(cfg.fd + 6):
        ms[0].read(cfg.addr_of(rng.randrange(cfg.words)), id=tag(cfg, k))
    for m in ms[1:]:
        for k in range(100):
            m.read(cfg.addr_of(rng.randrange(cfg.words)))
    n0 = sum(b.chk.n_accept[1:])
    await b.env.cycles(60)
    assert b.chk.n_accept[0] == cfg.fd, "stalled port 0 must hold exactly RSP_FIFO_DEPTH=%d requests, got %d" % (cfg.fd, b.chk.n_accept[0])
    ideal = 60 * min(cfg.np - 1, cfg.nb * (1 if cfg.pm == 0 else 2)) * min(1.0, cfg.fd / (cfg.rl + 1.0))  # bank-limited when ports outnumber bank slots
    assert sum(b.chk.n_accept[1:]) - n0 >= 0.45 * ideal, "other ports were blocked by port 0's stalled responses"
    ms[0].rsp_thr.set_mode("random:0.4")
    await b.drain(30000, "release")
    await b.settle()
    b.finish("isolation_backpressure")


@cocotb.test()
async def error_requests(dut):
    """RANGE / ALIGN / STROBE requests (and their priority) mixed with valid traffic and contention: answered in order
    with the right err_code, zero data, no side effect, even with scarce credits."""
    b = build_spm(dut, SEED(), req_thr="random:0.8", rsp_thr="random:0.6")
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("err")
    await up(b)
    for w in range(cfg.words):
        ms[w % cfg.np].write(cfg.addr_of(w), uniq(cfg, w, 7), full(cfg))
    await b.drain(30000, "fill")
    st = {"bank": 0, "word": 0, "row": 0}
    for k in range(500):
        i = rng.randrange(cfg.np)
        ms[i].submit(rand_sreq(rng, cfg, i, rng.choice(["uniform", "same_bank", "boundary"]), 0.5, 0.4, st))
    await b.drain(40000, "errors")
    for w in range(cfg.words):
        ms[w % cfg.np].read(cfg.addr_of(w))
    await b.drain(30000, "verify")
    await b.settle()
    b.finish("error_requests")


# --------------------------------------------------------------------------- random

PROFILES = ["uniform", "same_bank", "parallel", "boundary", "hot_word", "hot_row"]
REQ_THR = ["always", "random:0.7", "random:0.3", "bursty:1-6"]
RSP_THR = ["always", "random:0.8", "random:0.4", "bursty:1-8", "random:0.15"]


@cocotb.test()
async def random_traffic(dut):
    """Seeded random traffic from all ports with random stalls on every request and response channel, hot banks /
    words / rows, error requests; counters and every event output compared along the way."""
    b = build_spm(dut, SEED())
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("rnd")
    await up(b)
    for phase in range(8):
        prof = rng.choice(PROFILES)
        st = {"bank": rng.randrange(cfg.nb), "word": rng.randrange(cfg.words), "row": rng.randrange(cfg.bank_depth)}
        for m in ms:
            m.req_thr.set_mode(rng.choice(REQ_THR))
            if cfg.fd:
                m.rsp_thr.set_mode(rng.choice(RSP_THR))
        rf = rng.choice([0.3, 0.5, 0.8])
        for i, m in enumerate(ms):
            for k in range(150):
                m.submit(rand_sreq(rng, cfg, i, prof if rng.random() < 0.85 else "uniform", rf, 0.06, st))
        await b.drain(60000, "phase %d (%s)" % (phase, prof))
    await b.settle()
    b.finish("random_traffic", conflict_cycles=b.chk.conflict_cycles, max_lost_run=b.chk.max_lost_run)


# --------------------------------------------------------------------------- reset


async def _reset_round(b, rng, max_cycles=600, what="reset"):
    n0 = b.rst.n_pulses
    await b.env.until(lambda: b.rst.n_pulses > n0, max_cycles, what + " to fire")
    cfg = b.cfg
    st = {"bank": 0, "word": 0, "row": 0}
    for i, m in enumerate(b.ms):  # requests queued DURING reset are presented in the first cycle after release
        for k in range(rng.randint(0, 2)):
            m.submit(rand_sreq(rng, cfg, i, "uniform", 0.5, 0.05, st))
    await b.env.until(lambda: not b.rst.asserted, 30, what + " release")


def armed(b, pred, length, reason, patience=150):
    dl = b.env.cycle + patience
    b.rst.arm(lambda: pred() or b.env.cycle >= dl, length, reason)


@cocotb.test()
async def reset_during_traffic(dut):
    """Synchronous resets in the middle of traffic: queued/in-flight requests vanish (no response), writes already
    issued stay in the array, RR pointers and counters are cleared, req_ready = 0 in the first cycle after."""
    b = build_spm(dut, SEED(), rsp_thr="always")
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("rst")
    await up(b)
    st = {"bank": 0, "word": 0, "row": 0}
    for rnd in range(24):
        st["bank"] = rng.randrange(cfg.nb)
        for m in ms:
            if cfg.fd:
                m.rsp_thr.set_mode(rng.choice(["random:0.3", "random:0.6", "bursty:2-10"]))
            m.req_thr.set_mode(rng.choice(["always", "random:0.7"]))
        for i, m in enumerate(ms):
            for k in range(rng.randint(8, 30)):
                m.submit(rand_sreq(rng, cfg, i, rng.choice(["uniform", "same_bank", "hot_word", "boundary"]), 0.5, 0.05, st))
        length = rng.choice([1, 1, 2, 3])
        kind = rnd % 6
        if kind == 4:
            for m in ms:
                m.queue.clear()
            await b.drain(2000, "idle before reset")
            b.rst.pulse(length, delay=1, reason="idle")
            await _reset_round(b, rng, 50, "idle reset round %d" % rnd)
            continue
        if kind == 5:
            armed(b, lambda: b.chk.outstanding() == 1, length, "exactly one outstanding")
        elif kind == 0:
            b.rst.pulse(length, delay=rng.randint(1, 25), reason="sync-random")
        elif kind == 1:
            armed(b, lambda: b.chk.outstanding() >= 2, length, "outstanding>=2")
        elif kind == 2:
            armed(b, lambda: any(b.chk._lost_run), length, "arbitration-conflict")
        else:
            armed(b, lambda: b.chk.outstanding() >= cfg.np * max(1, cfg.fd) // 2 and any(m.cur is not None for m in ms), length, "heavy")
        await _reset_round(b, rng, 600, "reset round %d" % rnd)
        await b.env.cycles(rng.randint(0, 4))
    for m in ms:
        m.rsp_thr.set_mode("always")
        m.req_thr.set_mode("always")
    for w in range(cfg.words):
        ms[w % cfg.np].read(cfg.addr_of(w))
    await b.drain(30000, "read-back after resets")
    await b.settle()
    assert b.rst.n_pulses >= 24
    b.finish("reset_during_traffic", resets=b.rst.n_pulses, cancelled=b.chk.n_cancelled)


@cocotb.test()
async def reset_async_midcycle(dut):
    """Asynchronous reset between clock edges (several phases) during traffic with contention."""
    b = build_spm(dut, SEED(), rsp_thr="always")
    cfg, ms, rng = b.cfg, b.ms, b.env.seeds.child("arst")
    await up(b)
    st = {"bank": 0, "word": 0, "row": 0}
    phases = [0.5, 2.0, 4.0, 5.0, 7.5, 9.0, 9.9]
    for rnd in range(len(phases) * 2):
        st["bank"] = rng.randrange(cfg.nb)
        for m in ms:
            if cfg.fd:
                m.rsp_thr.set_mode(rng.choice(["random:0.35", "random:0.7", "always"]))
        for i, m in enumerate(ms):
            for k in range(rng.randint(6, 25)):
                m.submit(rand_sreq(rng, cfg, i, rng.choice(["uniform", "same_bank", "parallel"]), 0.5, 0.05, st))
        await b.env.cycles(rng.randint(2, 15))
        b.chk.mark_async()
        cocotb.start_soon(b.rst.async_pulse(phases[rnd % len(phases)], length_cycles=rng.choice([1, 1, 2, 3])))
        await _reset_round(b, rng, 40, "async reset round %d" % rnd)
        await b.env.cycles(rng.randint(0, 3))
    for m in ms:
        m.rsp_thr.set_mode("always")
    for w in range(cfg.words):
        ms[w % cfg.np].read(cfg.addr_of(w))
    await b.drain(30000, "read-back after async resets")
    await b.settle()
    b.finish("reset_async_midcycle", resets=b.rst.n_pulses, cancelled=b.chk.n_cancelled)
