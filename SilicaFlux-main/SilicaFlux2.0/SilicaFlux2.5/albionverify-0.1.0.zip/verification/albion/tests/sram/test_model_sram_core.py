"""Unit tests of the SRAM-core reference model (no simulator).  Hand-computed examples come straight from the
specification text in rtl/sramlib/docs/mem/01_interface_spec.md."""
import pytest

from albionverify.models.sram_core import ExpRsp, LaneMemory, RspPathModel, SramSpModel, clog2


# --------------------------------------------------------------------------- LaneMemory

def test_model_lane_write_mask_little_endian():
    m = LaneMemory(4, 8, "zero")
    m.write(3, 0xAABBCCDD, 0b0101)  # lanes 0 and 2: bytes DD and BB
    assert m.exact_word(3) == 0x00BB00DD
    m.write(3, 0x11223344, 0b1000)  # lane 3 only
    assert m.exact_word(3) == 0x11BB00DD
    m.write(3, 0xFFFFFFFF, 0)  # zero mask: no change
    assert m.exact_word(3) == 0x11BB00DD


def test_model_lane_9bit_lanes():
    m = LaneMemory(2, 9, "zero")  # DATA_WIDTH 18, MASK_WIDTH 2
    m.write(0, (0x1FF << 9) | 0x0AA, 0b10)
    assert m.exact_word(0) == 0x1FF << 9
    m.write(0, 0x155, 0b01)
    assert m.exact_word(0) == (0x1FF << 9) | 0x155


def test_model_unknown_lane_any_then_pinned():
    m = LaneMemory(4, 8, "unknown")
    s1 = m.snapshot(5)
    assert m.check(s1, 0xDEADBEEF) is None  # never written: anything legal
    s2 = m.snapshot(5)
    assert m.check(s2, 0xDEADBEEF) is None  # pinned value repeats
    s3 = m.snapshot(5)
    msg = m.check(s3, 0xDEADBEEE)  # lane 0 changed without a write
    assert msg and "lane0" in msg


def test_model_partial_write_to_unknown_word_leaves_other_lanes_free():
    m = LaneMemory(4, 8, "unknown")
    m.write(1, 0x000000AB, 0b0001)
    s = m.snapshot(1)
    assert m.check(s, 0x12345 << 8 | 0xAB) is None  # lanes 1..3 unconstrained, lane 0 exact
    assert "lane0" in m.check(m.snapshot(1), 0x12345600)


def test_model_read_data_frozen_at_acceptance_edge():
    """A write accepted after the read must not change what the (late-delivered) read returns."""
    m = LaneMemory(4, 8, "zero")
    m.write(2, 0x11111111, 0xF)
    snap = m.snapshot(2)
    m.write(2, 0x22222222, 0xF)  # accepted after the read, before its response is delivered
    assert m.check(snap, 0x11111111) is None
    assert m.check(snap, 0x22222222) is not None


def test_model_pin_not_applied_when_lane_rewritten_after_snapshot():
    m = LaneMemory(1, 8, "unknown")
    snap = m.snapshot(0)
    m.write(0, 0x77, 1)
    assert m.check(snap, 0x31) is None  # old unknown value, any
    assert m.exact_word(0) == 0x77  # the pin must not overwrite the newer write


def test_model_second_read_must_agree_with_pin_set_by_earlier_delivery():
    m = LaneMemory(1, 8, "unknown")
    a, b = m.snapshot(0), m.snapshot(0)  # two reads accepted before either was delivered
    assert m.check(a, 0x5A) is None
    assert m.check(b, 0x5A) is None
    c, d = m.snapshot(1), m.snapshot(1)
    assert m.check(c, 0x01) is None
    assert m.check(d, 0x02) is not None


def _uncertain():
    m = LaneMemory(4, 8, "zero")
    m.write(0, 0x01020304, 0xF)
    m.write_uncertain(0, 0xAABBCCDD, 0b0011)  # lanes 0,1 may or may not have been written
    return m


def test_model_write_uncertain_keeps_old_or_new():
    m = _uncertain()
    assert m.check(m.snapshot(0), 0x0102CCDD) is None  # both lanes new
    m = _uncertain()
    assert m.check(m.snapshot(0), 0x01020304) is None  # none landed
    m = _uncertain()
    assert m.check(m.snapshot(0), 0x0102CC04) is None  # lane1 new, lane0 old: mixed is legal
    m = _uncertain()
    assert m.check(m.snapshot(0), 0x010200DD) is not None  # lane1 = 0x00 is neither old (03) nor new (CC)
    m = _uncertain()
    assert m.check(m.snapshot(0), 0x0502CCDD) is not None  # lane3 was not written at all: must stay 01


# --------------------------------------------------------------------------- response path timing

def test_model_ready_is_zero_in_reset_and_first_cycle_after():
    r = RspPathModel(read_latency=1, fifo_depth=2)
    r.reset()
    assert r.begin_edge() is False  # the first edge after release: not live
    assert r.begin_edge() is True
    assert r.ready(True, True) is True
    assert r.ready(False, False) is False


def test_model_spec_example_latency_1_back_to_back_sustained():
    """RSP_FIFO_DEPTH = READ_LATENCY + 1 sustains 1 access/cycle (spec sec. 4): RL=1, depth 2."""
    m = SramSpModel(32, 64, 4, read_latency=1, write_ack=1, id_width=2)
    m.begin_edge()  # first edge after release
    for c in range(1, 8):
        live = m.begin_edge()
        head = m.head_valid(c)
        assert (head is not None) == (c >= 2)  # response of the request accepted at edge c-1
        assert m.expected_ready(live, False, 0), "back-to-back reads must always be accepted (cycle %d)" % c
        if head is not None:
            m.pop()  # handed over this edge (rsp_ready = 1)
        m.accept(c, False, 0, 0, 0, 0)


def test_model_credit_exhaustion_and_release():
    """RL=2, default depth 3, rsp_ready never given: exactly 3 reads accepted, the 4th is refused."""
    m = SramSpModel(32, 16, 4, read_latency=2, write_ack=1)
    m.begin_edge()
    accepted = 0
    for c in range(1, 12):
        live = m.begin_edge()
        if m.expected_ready(live, False, 1):
            m.accept(c, False, 1, 0, 0, 0)
            accepted += 1
    assert accepted == 3
    assert m.rsp.outstanding == 3
    # hand one response over: the credit is usable at the NEXT edge, not the same one
    c = 20
    live = m.begin_edge()
    assert m.head_valid(c) is not None
    assert m.expected_ready(live, False, 1) is False  # decision uses the pre-edge occupancy
    m.pop()
    assert m.expected_ready(m.begin_edge(), False, 1) is True


def test_model_posted_write_needs_no_credit_but_error_does():
    m = SramSpModel(32, 100, 4, read_latency=1, write_ack=0, rsp_fifo_depth=1)
    m.begin_edge()
    live = m.begin_edge()
    assert m.expected_ready(live, False, 3)
    m.accept(1, False, 3, 0, 0, 0)  # consumes the only credit
    live = m.begin_edge()
    assert m.expected_ready(live, False, 3) is False  # a read needs a credit
    assert m.expected_ready(live, True, 3) is True  # in-range posted write: none
    assert m.expected_ready(live, True, 100) is False  # invalid address: error response, needs a credit
    assert m.accept(2, True, 3, 5, 0xF, 0) is None  # posted: no response


def test_model_depth_zero_is_no_backpressure_mode():
    m = SramSpModel(32, 16, 4, read_latency=3, rsp_fifo_depth=0)
    m.begin_edge()
    for c in range(1, 30):
        live = m.begin_edge()
        assert m.expected_ready(live, False, 0)  # never credit limited
        m.accept(c, False, 0, 0, 0, 0)
        h = m.head_valid(c)
        if h is not None:
            assert h.due == c  # exactly READ_LATENCY after acceptance
            m.pop()


def test_model_response_due_exactly_read_latency_after_accept():
    for rl in (1, 2, 3):
        m = SramSpModel(32, 16, 4, read_latency=rl)
        e = m.accept(10, False, 0, 0, 0, 5)
        assert e.due == 10 + rl
        assert m.head_valid(10 + rl - 1) is None
        assert m.head_valid(10 + rl) is e


def test_model_responses_stay_valid_until_taken_and_stay_in_order():
    m = SramSpModel(32, 16, 4, read_latency=1, rsp_fifo_depth=3)
    e1 = m.accept(1, False, 0, 0, 0, 1)
    e2 = m.accept(2, False, 1, 0, 0, 2)
    for c in (2, 3, 4, 5):
        assert m.head_valid(c) is e1  # not taken: still the head
    assert m.pop() is e1
    assert m.head_valid(6) is e2


# --------------------------------------------------------------------------- invalid addresses, writes

def test_model_invalid_address_error_response_and_no_side_effect():
    m = SramSpModel(32, 100, 4, read_latency=1, id_width=4)
    m.accept(1, True, 7, 0x0F0F0F0F, 0xF, 3)
    e = m.accept(2, True, 100, 0xFFFFFFFF, 0xF, 9)  # DEPTH itself is invalid (AW = 7 allows up to 127)
    assert e.kind == "err_write" and e.err and e.we and e.id == 9
    e = m.accept(3, False, 127, 0, 0, 4)
    assert e.kind == "err_read" and e.err and not e.we
    assert m.check_rsp_data(e, 0) is None and m.check_rsp_data(e, 1) is not None
    assert m.mem.exact_word(7) == 0x0F0F0F0F
    assert m.addr_ok(99) and not m.addr_ok(100)


def test_model_posted_invalid_write_is_answered():
    m = SramSpModel(32, 100, 4, read_latency=1, write_ack=0)
    e = m.accept(1, True, 120, 1, 0xF, 0)
    assert e is not None and e.err and e.we


def test_model_write_ack_data_is_zero_and_we_set():
    m = SramSpModel(32, 16, 4, read_latency=1, write_ack=1)
    e = m.accept(1, True, 2, 0xAAAAAAAA, 0xF, 1)
    assert e.kind == "write_ack" and e.we and not e.err
    assert m.check_rsp_data(e, 0) is None
    assert m.check_rsp_data(e, 0xAAAAAAAA) is not None


def test_model_read_after_write_next_cycle_sees_new_data():
    m = SramSpModel(32, 16, 4, read_latency=2)
    m.accept(1, True, 4, 0xCAFEF00D, 0xF, 0)
    e = m.accept(2, False, 4, 0, 0, 0)
    assert m.check_rsp_data(e, 0xCAFEF00D) is None


def test_model_reset_cancels_responses_keeps_memory():
    m = SramSpModel(32, 16, 4, read_latency=2)
    m.accept(1, True, 4, 0x12345678, 0xF, 0)
    m.accept(2, False, 4, 0, 0, 0)
    gone = m.reset()
    assert len(gone) == 2 and m.rsp.outstanding == 0
    assert m.begin_edge() is False and m.begin_edge() is True
    e = m.accept(9, False, 4, 0, 0, 0)
    assert m.check_rsp_data(e, 0x12345678) is None  # array survived the reset


def test_model_id_is_masked_to_width():
    m = SramSpModel(32, 16, 4, read_latency=1, id_width=2)
    e = m.accept(1, False, 0, 0, 0, 0b111)
    assert e.id == 0b11


def test_model_clog2():
    assert [clog2(n) for n in (2, 3, 4, 5, 64, 100)] == [1, 2, 2, 3, 6, 7]
