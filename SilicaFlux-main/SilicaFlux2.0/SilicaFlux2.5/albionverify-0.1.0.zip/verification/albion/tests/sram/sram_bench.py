"""Shared bench components of the SRAM subsystem (sram_sp, sram_bank_controller, hpc_scratchpad).

  SramMaster    cycle-driven request driver + response-ready generator for one SRAM-core style port
                (the framework's ReqRspMaster assumes one response per request, which is false for posted
                writes, and cannot drive lane masks that are not byte lanes)
  PortRead      one cycle of a port's signals
  SpChecker     cycle-exact reference check of an ``sram_sp`` port against ``models.sram_core.SramSpModel``:
                req_ready, rsp_valid, response payload, ordering, ledger, memory data, reset behaviour
  cover_*       functional coverage groups
  rand_req      seeded, boundary-biased random request generator

Everything here is stimulus / checking; expected values come only from the reference models.
"""
from __future__ import annotations

import json
import os
import random
from collections import deque
from dataclasses import dataclass
from typing import Any, Callable, Deque, Dict, List, Optional

from albionverify.bus.reqrsp import Req, sramcore_port
from albionverify.core import Agent, Env
from albionverify.coverage import CoverGroup
from albionverify.models.sram_core import ExpRsp, SramSpModel, clog2
from albionverify.reset import ResetSequencer
from albionverify.rng import Throttle
from albionverify.scoreboard import Scoreboard


def params() -> Dict[str, Any]:
    return json.loads(os.environ.get("ALBION_PARAMS", "{}"))


def bucket(n: int) -> str:
    if n <= 0:
        return "0"
    if n == 1:
        return "1"
    if n <= 3:
        return "2-3"
    if n <= 7:
        return "4-7"
    return "8+"


BUCKETS = ["0", "1", "2-3", "4-7", "8+"]


# --------------------------------------------------------------------------- configuration


@dataclass
class SpCfg:
    dw: int
    depth: int
    mw: int
    rl: int
    fd: int
    wa: int
    idw: int

    @property
    def aw(self) -> int:
        return clog2(self.depth)

    @property
    def lw(self) -> int:
        return self.dw // self.mw

    @property
    def pow2(self) -> bool:
        return self.depth == (1 << self.aw)

    @property
    def full_mask(self) -> int:
        return (1 << self.mw) - 1

    @property
    def last_addr(self) -> int:
        return (1 << self.aw) - 1  # highest representable address (invalid if >= depth)

    @staticmethod
    def from_params(P: Dict[str, Any]) -> "SpCfg":
        dw = int(P.get("DATA_WIDTH", 32))
        mw = int(P.get("MASK_WIDTH", dw // 8 if dw % 8 == 0 else 1))
        rl = int(P.get("READ_LATENCY", 1))
        return SpCfg(dw, int(P.get("DEPTH", 1024)), mw, rl, int(P.get("RSP_FIFO_DEPTH", rl + 1)), int(P.get("WRITE_ACK", 1)), int(P.get("ID_WIDTH", 1)))

    def model(self) -> SramSpModel:
        return SramSpModel(self.dw, self.depth, self.mw, self.rl, self.wa, self.fd, self.idw, init="unknown")


# --------------------------------------------------------------------------- master


class SramMaster(Agent):
    """Request driver for one SRAM-core port.  A presented request is held unchanged until accepted;
    after acceptance the next one may be presented in the very next cycle (back-to-back)."""

    def __init__(self, name: str, port: Dict[str, Any], *, dw: int, mw: int, aw: int, idw: int, rng: random.Random,
                 req_throttle: str = "always", rsp_throttle: str = "always", idle_garbage: bool = True):
        super().__init__(name)
        self.p, self.dw, self.mw, self.aw, self.idw = port, dw, mw, aw, idw
        self.rng = rng
        self.req_thr = Throttle(rng, req_throttle)
        self.rsp_thr = Throttle(rng, rsp_throttle)
        self.garbage = idle_garbage
        self.queue: Deque[Req] = deque()
        self.cur: Optional[Req] = None
        self.listeners: List[Any] = []
        self._v = False
        self._rr = False
        self.n_accepted = 0
        self.n_cancelled = 0
        self.req_stall_run = 0
        self.max_req_stall = 0
        self.rsp_stall_run = 0
        self.max_rsp_stall = 0
        self.last_req_stall = 0  # stall run of the request accepted most recently
        self.last_rsp_stall = 0

    # ---- stimulus API
    def submit(self, req: Req) -> Req:
        self.queue.append(req)
        return req

    def write(self, addr: int, data: int, mask: Optional[int] = None, id: int = 0) -> Req:
        return self.submit(Req(True, addr, data, ((1 << self.mw) - 1) if mask is None else mask, id))

    def read(self, addr: int, id: int = 0) -> Req:
        return self.submit(Req(False, addr, 0, 0, id))

    @property
    def idle(self) -> bool:
        return not self.queue and self.cur is None

    # ---- agent
    def sample(self) -> None:
        env = self.env
        if env.in_reset:
            return
        if self._v:
            if self.p["ready"].read():
                self.last_req_stall = self.req_stall_run
                self.max_req_stall = max(self.max_req_stall, self.req_stall_run)
                self.req_stall_run = 0
                req, self.cur = self.cur, None
                self.n_accepted += 1
                for l in self.listeners:
                    fn = getattr(l, "txn_accepted", None)
                    if fn:
                        fn(self, req)
            else:
                self.req_stall_run += 1
        if self.p["rvalid"].read():
            if self._rr:
                self.last_rsp_stall = self.rsp_stall_run
                self.rsp_stall_run = 0
            else:
                self.rsp_stall_run += 1
                self.max_rsp_stall = max(self.max_rsp_stall, self.rsp_stall_run)

    def drive(self) -> None:
        env, p = self.env, self.p
        if env.in_reset:
            self._v = self._rr = False
            p["valid"].write(0)
            p["rready"].write(0)
            return
        if self.cur is None and self.queue and self.req_thr.allow():
            self.cur = self.queue.popleft()
        if self.cur is not None:
            r = self.cur
            p["valid"].write(1)
            p["write"].write(1 if r.write else 0)
            p["addr"].write(r.addr)
            p["wdata"].write(r.wdata if r.write else (self.rng.getrandbits(self.dw) if self.garbage else 0))
            p["strb"].write((r.strb if r.strb is not None else (1 << self.mw) - 1) if r.write else (self.rng.getrandbits(self.mw) if self.garbage else 0))
            p["id"].write(r.id)
            self._v = True
        else:
            p["valid"].write(0)
            if self.garbage:
                p["write"].write(self.rng.getrandbits(1))
                p["addr"].write(self.rng.getrandbits(self.aw))
                p["wdata"].write(self.rng.getrandbits(self.dw))
                p["strb"].write(self.rng.getrandbits(self.mw))
                p["id"].write(self.rng.getrandbits(max(self.idw, 1)))
            self._v = False
        self._rr = self.rsp_thr.allow()
        p["rready"].write(1 if self._rr else 0)

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            if self.cur is not None:
                self.n_cancelled += 1
            self.n_cancelled += len(self.queue)
            self.cur = None
            self.queue.clear()  # requests not yet presented are dropped; the test re-submits after reset
            self._v = self._rr = False
            self.req_stall_run = self.rsp_stall_run = 0

    def summary(self) -> dict:
        return {"accepted": self.n_accepted, "cancelled": self.n_cancelled, "max_req_stall": self.max_req_stall, "max_rsp_stall": self.max_rsp_stall}


class TestPortAgent(Agent):
    """Drives the MBIST test port of ``sram_sp``: a script of one-cycle operations (tst_active / tst_ce / ...).
    tst_ce is never asserted without tst_active (library rule)."""

    def __init__(self, name: str, sigs: Dict[str, Any], dw: int, aw: int, rng: random.Random):
        super().__init__(name)
        self.s, self.dw, self.aw, self.rng = sigs, dw, aw, rng
        self.script: Deque[tuple] = deque()

    def hold(self, n: int = 1) -> None:  # test mode active, no array access
        for _ in range(n):
            self.script.append((1, 0, 0, 0, 0))

    def write(self, addr: int, data: int) -> None:
        self.script.append((1, 1, 1, addr, data))

    def read(self, addr: int) -> None:
        self.script.append((1, 1, 0, addr, 0))

    def idle(self, n: int = 1) -> None:
        for _ in range(n):
            self.script.append((0, 0, 0, 0, 0))

    def drive(self) -> None:
        env, s = self.env, self.s
        if env.in_reset or not self.script:
            act, ce, we, addr, wd = 0, 0, self.rng.getrandbits(1), self.rng.getrandbits(self.aw), self.rng.getrandbits(self.dw)
            if env.in_reset:
                we, addr, wd = 0, 0, 0
        else:
            act, ce, we, addr, wd = self.script.popleft()
        s["active"].write(act)
        s["ce"].write(ce)
        s["we"].write(we)
        s["addr"].write(addr)
        s["wdata"].write(wd)

    @property
    def idle_now(self) -> bool:
        return not self.script


# --------------------------------------------------------------------------- port sampling


@dataclass
class PortRead:
    v: int
    rdy: int
    we: int
    addr: int
    wdata: int
    wmask: int
    id: int
    rv: int
    rr: int
    rdata: int
    rerr: int
    rwe: int
    rid: int


def read_port(p: Dict[str, Any]) -> PortRead:
    return PortRead(p["valid"].read(), p["ready"].read(), p["write"].read(), p["addr"].read(), p["wdata"].read(), p["strb"].read(),
                    p["id"].read(), p["rvalid"].read(), p["rready"].read(), p["rdata"].read(), p["err"].read(), p["rwe"].read(), p["rid"].read())


# --------------------------------------------------------------------------- coverage


def cover_sp(cfg: SpCfg) -> Dict[str, CoverGroup]:
    """Functional coverage of one sram_sp configuration.  Bins that cannot occur in this configuration by
    construction (e.g. an acknowledged write when WRITE_ACK=0, a stalled response when RSP_FIFO_DEPTH=0, two
    requests accepted in consecutive cycles when one credit is all there is) are not defined."""
    D = cfg.depth
    ops = ["read", "write" if cfg.wa else "write_posted"] + ([] if cfg.pow2 else ["err_read", "err_write"])
    cand: List[tuple] = [("first", 0), ("second", 1), ("mid", (2, D - 3)), ("penultimate", D - 2), ("last", D - 1)]
    if not cfg.pow2:
        cand += [("oor_first", D), ("oor_mid", (D + 1, cfg.last_addr - 1)), ("oor_last", cfg.last_addr)]
    addrs: Dict[str, Any] = {}
    taken = set()
    for nm, spec in cand:  # tiny depths: drop classes that collapse onto an earlier one or are empty
        vals = set(range(spec[0], spec[1] + 1)) if isinstance(spec, tuple) else {spec}
        if vals and not (vals & taken) and all(0 <= v <= cfg.last_addr for v in vals):
            addrs[nm] = spec
            taken |= vals
    cg = CoverGroup("sp.txn", "transaction types x address boundaries (interface spec sec. 2, 4)")
    cg.point("op", ops)
    cg.point("addr", addrs)
    cg.cross("op_x_addr", ["op", "addr"], ignore=lambda b: (b[0].startswith("err") != b[1].startswith("oor")))

    cm = CoverGroup("sp.mask", "write lane-mask classes (accepted in-range writes)")
    masks: Dict[str, Any] = {"zero": 0, "all": cfg.full_mask}
    if cfg.mw >= 2:
        for l in range(min(cfg.mw, 8)):
            masks["lane%d" % l] = 1 << l
    if cfg.mw >= 3:
        masks["sparse"] = lambda v, f=cfg.full_mask: v not in (0, f) and bin(v).count("1") > 1
    cm.point("mask", masks)

    cf = CoverGroup("sp.flow", "flow control: back-pressure durations, credits, concurrency")
    cf.point("req_stall", BUCKETS)  # cycles a request waited with valid && !ready before it was accepted
    cf.point("rsp_stall", BUCKETS if cfg.fd else ["0"])  # cycles a response waited with valid && !ready (none without a FIFO)
    top = cfg.fd if cfg.fd else cfg.rl
    cf.point("outstanding", list(range(0, top + 1 if (cfg.fd == 0 or not cfg.wa) else top)))  # occupancy seen by an accepted request
    if cfg.fd:
        cf.point("credit_full", ["blocked"])  # ready low because every response credit was in use

    cs = CoverGroup("sp.seq", "consecutive accepted requests (hazards): previous -> current")
    cs.point("pair", ["RAW", "WAR", "WAW", "RAR"])  # RAW = read after write, WAR = write after read, ...
    cs.point("same_addr", ["same", "diff"])
    one_credit = cfg.fd == 1  # the only credit comes back one cycle after the response: no consecutive acceptance of credited requests
    cs.point("gap", ["gap"] if (one_credit and cfg.wa) else ["b2b", "gap"])  # accepted in consecutive cycles or not
    cs.cross("pair_x_same", ["pair", "same_addr"])
    if "b2b" in cs.points["gap"].spec:
        cs.cross("pair_x_gap", ["pair", "gap"], ignore=(lambda b: b[1] == "b2b" and b[0] in ("RAW", "RAR")) if one_credit else None)

    ci = CoverGroup("sp.id", "request id echo")
    mx = (1 << cfg.idw) - 1
    ci.point("id", {"zero": 0, "max": mx, "other": (lambda v, m=mx: 0 < v < m)} if mx > 1 else {"zero": 0, "max": mx})

    cl = CoverGroup("sp.latency", "response latency relative to the earliest legal cycle")
    cl.point("extra_delay", {"exact": 0, "later": (lambda v: v > 0)} if cfg.fd else {"exact": 0})  # 0 = exactly READ_LATENCY after acceptance

    cr = CoverGroup("sp.reset", "reset asserted with responses in flight")
    two = cfg.fd == 0 or cfg.fd >= 2
    cr.point("outstanding_at_reset", ["0", "1", "2+"] if two else ["0", "1"])
    cr.point("resp_stalled", ["no", "yes"] if cfg.fd else ["no"])  # a response was visible and not taken in the cycle before the reset
    cr.point("kind", ["sync", "async"])
    cr.cross("state", ["outstanding_at_reset", "resp_stalled"], ignore=lambda b: (b[0] == "0" and b[1] == "yes") or (b[0] == "2+" and b[1] == "no" and cfg.rl == 1) or (b[1] == "yes" and cfg.fd == 0))
    return {g.name: g for g in (cg, cm, cf, cs, ci, cl, cr)}


# --------------------------------------------------------------------------- checker


class SpChecker(Agent):
    """Cycle-exact checker of one ``sram_sp`` port.  Registered AFTER the master."""

    def __init__(self, name: str, port: Dict[str, Any], cfg: SpCfg, sb: Scoreboard, cov: Optional[Dict[str, CoverGroup]] = None, stream: str = "p0",
                 tst: Optional[Dict[str, Any]] = None):
        super().__init__(name)
        self.p, self.cfg, self.sb, self.stream = port, cfg, sb, stream
        self.tst = tst  # test-port signals {active, ce, we, addr, wdata, rdata} or None (tied off)
        self._tst_reads: Deque[tuple] = deque()  # (due edge, snapshot, addr)
        self.n_tst_reads = 0
        self.n_tst_writes = 0
        self.n_tst_blocked = 0
        self.m = cfg.model()
        self.cov = cov or {}
        self.n_checks = 0
        self.n_cancelled = 0
        self.n_rsp = 0
        self.n_accept = 0
        self.n_posted = 0
        self._prev: Optional[tuple] = None  # (is_write, addr, cycle) of the previous accepted request
        self._stall_pay: Optional[tuple] = None  # payload of a response that was valid && !ready in the previous cycle
        self._rsp_vis_prev = False
        self._async_next = False
        self.log: Deque[str] = deque(maxlen=12)
        self.credit_blocked = 0

    # ---- helpers
    @property
    def drained(self) -> bool:
        return self.m.rsp.outstanding == 0

    def _fail(self, msg: str) -> None:
        self.sb.fail("%s | recent: %s" % (msg, " ; ".join(self.log)))

    def _cmp(self, what: str, exp: Any, got: Any, ctx: str = "") -> None:
        self.n_checks += 1
        if exp != got:
            self._fail("%s mismatch%s: expected 0x%x, got 0x%x" % (what, (" [%s]" % ctx) if ctx else "", int(exp), int(got)))

    def _cs(self, g: str, **kw) -> None:
        cg = self.cov.get(g)
        if cg is not None:
            cg.sample(**kw)

    # ---- agent
    def sample(self) -> None:
        env, c, m, cfg = self.env, self.env.cycle, self.m, self.cfg
        s = read_port(self.p)
        if env.in_reset:
            if c > 1:  # before the first edge with reset low the flops may still hold random power-up state
                self._cmp("req_ready while rst_n low", 0, s.rdy)
                self._cmp("rsp_valid while rst_n low", 0, s.rv)
            self._rsp_vis_prev = False
            self._stall_pay = None
            return
        occ_pre = m.rsp.outstanding  # occupancy the credit decision of this edge sees
        tmode = bool(self.tst["active"].read()) if self.tst else False
        live = m.begin_edge()
        head = m.head_valid(c)
        # ---------------- response channel (cycle exact)
        if head is None:
            self._cmp("rsp_valid (nothing due)", 0, s.rv, "unsolicited / early response")
        else:
            self._cmp("rsp_valid (response due since cycle %d, kind %s)" % (head.due, head.kind), 1, s.rv, "missing / late response")
            if s.rv:
                self._cmp("rsp_err", int(head.err), s.rerr, "%s addr 0x%x" % (head.kind, head.addr))
                self._cmp("rsp_we", int(head.we), s.rwe, "%s addr 0x%x" % (head.kind, head.addr))
                self._cmp("rsp_id", head.id, s.rid, "%s addr 0x%x" % (head.kind, head.addr))
                if s.rr:  # data is only compared when handed over; a stalled payload is compared every cycle by value stability
                    err = m.check_rsp_data(head, s.rdata)
                    self.n_checks += 1
                    if err:
                        self._fail("rsp_rdata %s (kind %s, id %d)" % (err, head.kind, head.id))
                else:
                    err = m.check_rsp_data(head, s.rdata) if head.kind != "read" else m.mem.check(head.snap, s.rdata, pin=False)  # type: ignore[arg-type]
                    self.n_checks += 1
                    if err:
                        self._fail("stalled rsp_rdata %s (kind %s)" % (err, head.kind))
        # spec sec. 4 "Backpressure": rsp_* hold stable while rsp_valid && !rsp_ready
        pay = (s.rdata, s.rerr, s.rwe, s.rid) if s.rv else None
        if self._stall_pay is not None:
            self.n_checks += 1
            if pay != self._stall_pay:
                self._fail("response not held stable under back-pressure: %s -> %s (rdata, err, we, id)" % (self._stall_pay, pay))
        self._stall_pay = pay if (s.rv and not s.rr) else None
        # ---------------- request channel (exact ready for the presented payload)
        if s.v:
            exp_ready = m.expected_ready(live, bool(s.we), s.addr, tmode)
            self.n_checks += 1
            if int(exp_ready) != s.rdy:
                self._fail("req_ready mismatch: expected %d, got %d (live=%d, we=%d, addr=0x%x, outstanding=%d/%d, posted-ok=%d)" % (
                    int(exp_ready), s.rdy, int(live), s.we, s.addr, m.rsp.outstanding, cfg.fd, int(not m.needs_rsp(bool(s.we), s.addr))))
            if not s.rdy and live and m.rsp.outstanding >= cfg.fd > 0 and m.needs_rsp(bool(s.we), s.addr):
                self.credit_blocked += 1
                self._cs("sp.flow", credit_full="blocked")
        # ---------------- state update: hand-over first (pre-edge occupancy decided above), then acceptance
        if head is not None and s.rv and s.rr:
            out = m.pop()
            self.sb.complete(self.stream, out.key)
            self.n_rsp += 1
            self.log.append("c%d rsp %s id%d" % (c, out.kind, out.id))
            self._cs("sp.flow", rsp_stall=bucket(self._stall_of(out, c)))
            self._cs("sp.latency", extra_delay=max(0, c - out.due))
            env.digest.event("sp.rsp", self.name, c, s.rdata, s.rerr, s.rwe, s.rid)
        self._rsp_vis_prev = bool(s.rv and not s.rr)
        if s.v and s.rdy and int(exp_ready):
            self._accept(c, s, occ_pre)
        if s.v and tmode and live:
            self.n_tst_blocked += 1
        if self.tst:
            self._test_port(c)

    def _test_port(self, c: int) -> None:
        """MBIST test port (spec sec. 8): raw array access, all lanes written, read data exactly READ_LATENCY
        cycles later, addresses >= DEPTH ignored."""
        t, m, cfg = self.tst, self.m, self.cfg
        while self._tst_reads and self._tst_reads[0][0] == c:
            _, snap, addr = self._tst_reads.popleft()
            err = m.mem.check(snap, t["rdata"].read())
            self.n_checks += 1
            if err:
                self._fail("tst_rdata %s (test read of 0x%x, expected exactly READ_LATENCY=%d cycles after the read edge)" % (err, addr, cfg.rl))
        if t["active"].read() and t["ce"].read():
            addr = t["addr"].read()
            if m.addr_ok(addr):
                if t["we"].read():
                    m.mem.write(addr, t["wdata"].read(), cfg.full_mask)
                    self.n_tst_writes += 1
                else:
                    self._tst_reads.append((c + cfg.rl, m.mem.snapshot(addr), addr))
                    self.n_tst_reads += 1
            self.env.digest.event("sp.tst", self.name, c, t["we"].read(), addr, t["wdata"].read() if t["we"].read() else 0)

    @staticmethod
    def _stall_of(out: ExpRsp, c: int) -> int:
        return max(0, c - out.due)

    def _accept(self, c: int, s: PortRead, occ: int) -> None:
        m, cfg = self.m, self.cfg
        we = bool(s.we)
        e = m.accept(c, we, s.addr, s.wdata, s.wmask, s.id)
        self.n_accept += 1
        self.log.append("c%d acc %s a=0x%x" % (c, "W" if we else "R", s.addr))
        self.env.digest.event("sp.acc", self.name, c, int(we), s.addr, s.wdata if we else 0, s.wmask if we else 0, s.id)
        if e is not None:
            self.sb.accept(self.stream, e.key, e)
        else:
            self.n_posted += 1
        # ---- coverage
        ok = m.addr_ok(s.addr)
        op = ("err_write" if we else "err_read") if not ok else (("write" if cfg.wa else "write_posted") if we else "read")
        D = cfg.depth
        self._cs("sp.txn", op=op, addr=s.addr)
        if we and ok:
            self._cs("sp.mask", mask=s.wmask)
        self._cs("sp.flow", outstanding=occ, req_stall=bucket(self._master_stall()))
        self._cs("sp.id", id=s.id)
        if self._prev is not None:
            pw, pa, pc = self._prev
            pair = ("WAW" if we else "RAW") if pw else ("WAR" if we else "RAR")  # (previous, current)
            self._cs("sp.seq", pair=pair, same_addr="same" if pa == s.addr else "diff", gap="b2b" if c - pc == 1 else "gap")
        self._prev = (we, s.addr, c)

    master: Optional[SramMaster] = None

    def _master_stall(self) -> int:
        return self.master.last_req_stall if self.master is not None else 0

    def mark_async(self) -> None:
        """The next reset assertion is a mid-cycle asynchronous one (coverage label only)."""
        self._async_next = True

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            m = self.m
            n = m.rsp.outstanding
            self._cs("sp.reset", outstanding_at_reset=("0" if n == 0 else ("1" if n == 1 else "2+")), resp_stalled="yes" if self._rsp_vis_prev else "no", kind="async" if self._async_next else "sync")
            gone = m.reset()
            self._tst_reads.clear()
            self.sb.cancel(self.stream, "reset")
            self.n_cancelled += len(gone)
            self._prev = None
            self._async_next = False
            self.env.digest.event("sp.reset", self.name, self.env.cycle, len(gone))

    def summary(self) -> dict:
        return {"accepted": self.n_accept, "responses": self.n_rsp, "posted": self.n_posted, "cancelled": self.n_cancelled, "checks": self.n_checks,
                "credit_blocked_cycles": self.credit_blocked, "tst_reads": self.n_tst_reads, "tst_writes": self.n_tst_writes, "tst_blocked_cycles": self.n_tst_blocked, "max_outstanding": self.m.rsp.max_outstanding, "model_stats": dict(self.m.stats)}


# --------------------------------------------------------------------------- traffic


def pattern_word(rng: random.Random, dw: int, n: int) -> int:
    k = rng.randrange(8)
    full = (1 << dw) - 1
    if k == 0:
        return 0
    if k == 1:
        return full
    if k == 2:
        return int("55" * ((dw + 7) // 8), 16) & full
    if k == 3:
        return int("AA" * ((dw + 7) // 8), 16) & full
    if k == 4:
        return (1 << rng.randrange(dw)) & full
    if k == 5:
        return full ^ (1 << rng.randrange(dw))
    return rng.getrandbits(dw)


def rand_mask(rng: random.Random, mw: int) -> int:
    k = rng.random()
    full = (1 << mw) - 1
    if k < 0.30:
        return full
    if k < 0.38:
        return 0
    if k < 0.58:
        return 1 << rng.randrange(mw)
    return rng.getrandbits(mw)


def rand_addr(rng: random.Random, cfg: SpCfg, profile: str, oor_frac: float) -> int:
    D = cfg.depth
    if not cfg.pow2 and rng.random() < oor_frac:
        return rng.choice([D, D + 1, cfg.last_addr, rng.randint(D, cfg.last_addr)])
    if profile == "hot":
        return rng.randrange(min(4, D))
    if profile == "boundary":
        return rng.choice([0, 1, D - 2, D - 1, rng.randrange(D)])
    if profile == "mixed":
        k = rng.random()
        if k < 0.25:
            return rng.choice([0, 1, D - 2, D - 1])
        if k < 0.5:
            return rng.randrange(min(8, D))
    return rng.randrange(D)


def rand_req(rng: random.Random, cfg: SpCfg, mw: int, profile: str = "mixed", read_frac: float = 0.5, oor_frac: float = 0.05) -> Req:
    addr = rand_addr(rng, cfg, profile, oor_frac)
    rid = rng.getrandbits(cfg.idw)
    if rng.random() < read_frac:
        return Req(False, addr, 0, 0, rid)
    return Req(True, addr, pattern_word(rng, cfg.dw, 0), rand_mask(rng, mw), rid)


@dataclass
class Bench:
    env: Env
    rst: ResetSequencer
    m: SramMaster
    chk: SpChecker
    sb: Scoreboard
    cfg: SpCfg
    cov: Dict[str, CoverGroup]
    tp: Optional[TestPortAgent] = None

    async def drain(self, max_cycles: int = 20000, what: str = "drain") -> None:
        await self.env.until(lambda: self.m.idle and self.chk.drained and not self.rst.asserted, max_cycles, what)

    def finish(self, test: str, **extra) -> None:
        self.sb.finalize()
        self.env.finalize()
        self.env.coverage.extend(self.cov.values())
        self.env.write_result(test, scoreboard=self.sb.summary(), **extra)


def build_sp(dut, seed: int, name: str = "sp", req_thr: str = "always", rsp_thr: str = "always", initial_reset: int = 4, test_port: bool = False) -> Bench:
    cfg = SpCfg.from_params(params())
    if cfg.fd == 0:
        rsp_thr = "always"  # RSP_FIFO_DEPTH = 0 is the no-back-pressure mode: the master must keep rsp_ready = 1 (interface spec sec. 4)
    env = Env(dut, name=name, seed=seed)
    rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=initial_reset))
    port = sramcore_port(env, AW=cfg.aw, DW=cfg.dw, IDW=cfg.idw, MW=cfg.mw)
    m = env.add(SramMaster("m0", port, dw=cfg.dw, mw=cfg.mw, aw=cfg.aw, idw=cfg.idw, rng=env.seeds.child("m0"), req_throttle=req_thr, rsp_throttle=rsp_thr))
    sb = Scoreboard(env, "sp")
    cov = cover_sp(cfg)
    tp = None
    tst = None
    if test_port:
        tst = {"active": env.sig("tst_active"), "ce": env.sig("tst_ce"), "we": env.sig("tst_we"), "addr": env.sig("tst_addr"), "wdata": env.sig("tst_wdata"), "rdata": env.sig("tst_rdata")}
        tp = env.add(TestPortAgent("tp", tst, cfg.dw, cfg.aw, env.seeds.child("tp")))
    else:
        env.tie("tst_active", "tst_ce", "tst_we", "tst_addr", "tst_wdata")
    chk = env.add(SpChecker("chk", port, cfg, sb, cov, tst=tst))
    chk.master = m
    return Bench(env, rst, m, chk, sb, cfg, cov, tp)
