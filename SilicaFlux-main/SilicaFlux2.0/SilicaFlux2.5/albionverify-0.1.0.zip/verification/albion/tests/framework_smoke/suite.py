from albionverify.sim.build import DutSpec
from albionverify.suite import Case, Suite

NM = NS = 2
BASE = sum((0x10000000 * (s + 1)) << (s * 32) for s in range(NS))
MASK = sum(0xF0000000 << (s * 32) for s in range(NS))
XBAR_SMOKE = DutSpec("xbar_smoke", "sfb_crossbar", params=(("NM", NM), ("NS", NS), ("SLV_BASE", BASE), ("SLV_MASK", MASK)))

SUITES = {
    "framework_smoke": Suite(
        name="framework_smoke",
        subsystem="framework",
        title="Framework self-test on sfb_crossbar (NOT the DataFabric verification; see tests/fabric)",
        cases=[Case(XBAR_SMOKE, "framework_smoke.cocotb_xbar_smoke", None, (1, 2, 3), tags=("smoke",))],
        mutants_file="mutants/framework_smoke.yaml",
        spec_refs=("datafabric/docs/datafabric/PROTOCOL.md",),
        notes="Exists to prove the framework (agents, scoreboard, reset sequencer, build/run/mutation chain) works on real RTL.",
    )
}
