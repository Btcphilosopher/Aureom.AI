"""Framework shake-down bench on the real sfb_crossbar (also the worked example for subsystem benches).

NOT the DataFabric verification (that lives in tests/fabric): this only proves that the framework's
Env / agents / scoreboard / reset sequencer / digest work end to end on actual RTL.
"""
import json
import os

import cocotb

from albionverify.bus.reqrsp import Req, ReqRspMaster, ReqRspMonitor, ReqRspSlave, sfb_port
from albionverify.core import Env
from albionverify.memory import BackingStore
from albionverify.reset import ResetSequencer
from albionverify.scoreboard import Scoreboard

P = json.loads(os.environ.get("ALBION_PARAMS", "{}"))
NM, NS, AW, DW = P.get("NM", 2), P.get("NS", 2), 32, P.get("DW", 32)
NB = DW // 8
SLV_MASK = 0xF0000000
BASES = [0x10000000 * (s + 1) for s in range(NS)]


def build(dut, seed, req_thr="random:0.7", rsp_thr="random:0.8", slv_thr="random:0.6"):
    env = Env(dut, name="xbar_smoke", seed=seed)
    rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=4))
    ms, ss, mons = [], [], []
    for i in range(NM):
        ms.append(env.add(ReqRspMaster("m%d" % i, sfb_port(env, "m_", i, flat=True, AW=AW, DW=DW), nbytes=NB,
                                       rng=env.seeds.child("m%d" % i), req_throttle=req_thr, rsp_throttle=rsp_thr, max_outstanding=2)))
    for s in range(NS):
        mem = BackingStore("zero", "slv%d" % s)
        ss.append(env.add(ReqRspSlave("s%d" % s, sfb_port(env, "s_", s, flat=True, AW=AW, DW=DW), memory=mem, nbytes=NB,
                                      rng=env.seeds.child("s%d" % s), req_throttle=slv_thr, rsp_throttle=rsp_thr, latency="uniform:1-3")))
    for i in range(NM):
        mons.append(env.add(ReqRspMonitor("mon_m%d" % i, sfb_port(env, "m_", i, flat=True, AW=AW, DW=DW), nbytes=NB, outstanding_limit=1)))
    for s in range(NS):
        mons.append(env.add(ReqRspMonitor("mon_s%d" % s, sfb_port(env, "s_", s, flat=True, AW=AW, DW=DW), nbytes=NB, outstanding_limit=1)))
    return env, rst, ms, ss, mons


def decode(addr):
    if addr % NB:
        return None
    for s, b in enumerate(BASES):
        if (addr & SLV_MASK) == b:
            return s
    return None


class Checker:
    """Reference model for routing + data: private per-master address windows make order irrelevant."""

    def __init__(self, env):
        self.env, self.sb = env, Scoreboard(env, "xbar")
        self.ref = BackingStore("zero", "ref")

    def txn_accepted(self, agent, txn):
        self.sb.accept(agent.name, txn.seq, txn.req)

    def txn_completed(self, agent, txn):
        req = self.sb.complete(agent.name, txn.seq)
        tgt = decode(req.addr)
        if tgt is None:
            self.sb.check_eq("decode-error rsp_error", True, txn.rsp.err, "addr 0x%x" % req.addr)
            self.sb.check_eq("decode-error rdata", 0, txn.rsp.rdata)
            return
        self.sb.check_eq("rsp_error", False, txn.rsp.err, "addr 0x%x" % req.addr)
        if req.write:
            self.ref.write_word(req.addr, req.wdata, req.strb, NB)
            self.sb.check_eq("write rdata", 0, txn.rsp.rdata)
        else:
            err = self.ref.check_word(req.addr, NB, txn.rsp.rdata)
            self.sb.check(err is None, err or "")


def gen_traffic(env, ms, n):
    """Constrained-random traffic from the reusable ReqGen: addresses biased to window boundaries, private
    per-master windows (so cross-master ordering cannot matter), a few unmapped and misaligned accesses."""
    from albionverify.gen import ReqGen

    for i, m in enumerate(ms):
        regions = [(BASES[s] + i * 0x1000, BASES[s] + i * 0x1000 + 16 * NB) for s in range(NS)]
        gen = ReqGen(env.seeds.child("traffic%d" % i), NB, regions, unmapped=[(0xE0000000, 0xE0000040)],
                     addr_weights={"unmapped": 0.4, "misaligned": 0.4}, strobe_weights={"zero": 0.0})
        for _ in range(n):
            m.submit(gen.next())


@cocotb.test()
async def random_traffic(dut):
    seed = int(os.environ.get("ALBION_SEED", "1"))
    env, rst, ms, ss, mons = build(dut, seed)
    chk = Checker(env)
    for m in ms:
        m.listeners.append(chk)
    await env.start()
    await env.until(lambda: not rst.asserted, 50, "reset release")
    gen_traffic(env, ms, 150)
    await env.until(lambda: all(m.idle for m in ms), 20000, "all masters idle")
    await env.cycles(5)
    chk.sb.finalize()
    env.finalize()
    env.write_result("random_traffic", scoreboard=chk.sb.summary())


@cocotb.test()
async def reset_midflight(dut):
    seed = int(os.environ.get("ALBION_SEED", "1"))
    env, rst, ms, ss, mons = build(dut, seed, slv_thr="random:0.3")
    chk = Checker(env)
    for m in ms:
        m.listeners.append(chk)

    class OnReset:  # explicit cancellation of everything the scoreboard still expects
        def txn_cancelled(self, agent, txn):
            pass

    await env.start()
    await env.until(lambda: not rst.asserted, 50, "reset release")
    gen_traffic(env, ms, 60)
    # reset the moment a request is outstanding at a master
    rst.arm(lambda: any(len(m.outstanding) > 0 for m in ms), length=3, reason="reset-with-outstanding")
    await env.until(lambda: rst.n_pulses >= 1, 5000, "mid-flight reset to fire")
    await env.until(lambda: not rst.asserted, 20, "reset release")
    cancelled = chk.sb.cancel(reason="reset")
    assert len(cancelled) >= 1, "nothing was in flight when reset fired"
    # R11: no stale response may appear after reset; fresh traffic must work and see consistent data
    await env.cycles(10)
    chk.ref = BackingStore("unknown", "ref-after-reset")  # accepted writes may or may not have landed
    for sl in ss:
        pass
    gen_traffic(env, ms, 30)
    await env.until(lambda: all(m.idle for m in ms), 20000, "post-reset traffic")
    chk.sb.finalize()
    env.finalize()
    env.write_result("reset_midflight", scoreboard=chk.sb.summary(), cancelled=len(chk.sb.cancelled))


@cocotb.test()
async def reset_glitch(dut):
    """Sub-cycle reset pulse (never spans a clock edge): only asynchronous-reset flops see it."""
    seed = int(os.environ.get("ALBION_SEED", "1"))
    env, rst, ms, ss, mons = build(dut, seed, slv_thr="random:0.3")
    chk = Checker(env)
    for m in ms:
        m.listeners.append(chk)
    await env.start()
    await env.until(lambda: not rst.asserted, 50, "reset release")
    gen_traffic(env, ms, 40)
    await env.until(lambda: any(len(m.outstanding) > 0 for m in ms), 500, "traffic in flight")
    cocotb.start_soon(rst.glitch(2.0, 4.0, peers=ms + ss))
    await env.cycles(3)
    assert rst.n_pulses == 1
    # everything accepted before the glitch is cancelled (R11); the agents already flushed their queues
    chk.sb.cancel(reason="async-glitch-reset")
    await env.cycles(10)
    chk.ref = BackingStore("unknown", "ref-after-glitch")
    gen_traffic(env, ms, 30)
    await env.until(lambda: all(m.idle for m in ms), 20000, "post-glitch traffic")
    chk.sb.finalize()
    env.finalize()
    env.write_result("reset_glitch", scoreboard=chk.sb.summary(), cancelled=len(chk.sb.cancelled))
