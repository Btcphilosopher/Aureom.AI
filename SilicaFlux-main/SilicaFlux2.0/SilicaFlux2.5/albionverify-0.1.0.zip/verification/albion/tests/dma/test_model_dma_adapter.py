"""Hand-computed examples for albionverify.models.dma_adapter_model (no simulator)."""
from albionverify.models import dma_adapter_model as A
from albionverify.models import dma_spec as S

CFG = A.AdapterConfig(dw_bytes=4, max_len_log2=8, spm_base=0x20000000, spm_bytes=0x400)  # window [0x20000000, 0x20000400)


def test_model_adapter_region_legal_ranges():
    assert A.range_region_ok(0x20000000, 0x400, CFG)  # the whole window
    assert A.range_region_ok(0x20000004, 0x3FC, CFG)  # ends exactly at the window end
    assert A.range_region_ok(0x1FFFFFF0, 16, CFG)  # ends exactly at the window start: entirely outside
    assert A.range_region_ok(0x20000400, 16, CFG)  # starts exactly at the window end
    assert A.range_region_ok(0x10000000, 256, CFG) and A.range_region_ok(0x30000000, 256, CFG)


def test_model_adapter_region_crossing_boundaries():
    assert A.crossed_boundaries(0x1FFFFFF8, 16, CFG) == {0x20000000}  # enters from below
    assert A.crossed_boundaries(0x200003F8, 16, CFG) == {0x20000400}  # leaves at the top
    assert A.crossed_boundaries(0x1FFFFF00, 0x600, CFG) == {0x20000000, 0x20000400}  # spans the whole window
    assert A.crossed_boundaries(0x20000000, 0x401, CFG) == {0x20000400}
    assert A.crossed_boundaries(0x1FFFFFFF, 2, CFG) == {0x20000000}
    assert A.crossed_boundaries(0x20000010, 8, CFG) == set()


def test_model_adapter_expected_completion_precedence():
    # rules 1-7 (DataFabric) come first, REGION only after them
    assert A.expected_completion(0x1FFFFFF8, 0x10000000, 0, CFG) == (S.E_ZERO_LENGTH, {0})
    assert A.expected_completion(0x1FFFFFF9, 0x10000000, 16, CFG) == (S.E_SRC_ALIGN, {0})
    assert A.expected_completion(0x1FFFFFF8, 0x1FFFFFF8, 16, CFG) == (S.E_OVERLAP, {0})
    assert A.expected_completion(0x1FFFFFF8, 0x10000000, 16, CFG) == (A.E_REGION, {0x20000000})
    assert A.expected_completion(0x10000000, 0x200003F8, 16, CFG) == (A.E_REGION, {0x20000400})
    assert A.expected_completion(0x10000000, 0x20000000, 16, CFG) == (S.E_NONE, {0})  # ext -> SPM
    assert A.expected_completion(0x20000000, 0x20000100, 16, CFG) == (S.E_NONE, {0})  # SPM -> SPM
    assert A.expected_completion(0x1FFFFFF8, 0x200003F8, 16, CFG)[1] == {0x20000000, 0x20000400}  # both ranges cross: either is legal


def test_model_adapter_target_and_direction():
    assert A.target_of(0x1FFFFFFC, CFG) == "fab" and A.target_of(0x20000000, CFG) == "spm"
    assert A.target_of(0x200003FC, CFG) == "spm" and A.target_of(0x20000400, CFG) == "fab"
    assert A.direction(0x10000000, 0x20000000, CFG) == "fab_to_spm"
    assert A.direction(0x20000000, 0x10000000, CFG) == "spm_to_fab"
    assert A.direction(0x20000000, 0x20000100, CFG) == "spm_to_spm"
    assert A.direction(0x10000000, 0x10000100, CFG) == "fab_to_fab"
