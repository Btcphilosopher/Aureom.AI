"""AlbionVerify suites for the DataFabric DMA (silicaflux_dma, simple + buffered engines).

DUT configs (names start with ``dma_``).  MAX_LEN_LOG2 is small (8 => 256-byte maximum) so maximum-length and
just-over-maximum transfers are cheap.

  dma_simple         ENGINE=0  DW=32  PERF=1
  dma_simple_w64     ENGINE=0  DW=64  PERF=0   (PERF=0: the performance registers answer with a bus error)
  dma_buf_sp         ENGINE=1  DW=32  single port  FIFO_DEPTH=4  BURST=2  MAX_OUT=2
  dma_buf_sp_b4      ENGINE=1  DW=32  single port  FIFO_DEPTH=8  BURST=4  MAX_OUT=3
  dma_buf_dp         ENGINE=1  DW=32  dual port    FIFO_DEPTH=4  BURST=4  MAX_OUT=2   (NP=2: [0] read, [1] write)
  dma_buf_dp_w64     ENGINE=1  DW=64  dual port    FIFO_DEPTH=8  BURST=8  MAX_OUT=3
  dma_buf_min        ENGINE=1  DW=32  single port  FIFO_DEPTH=2  BURST=1  MAX_OUT=1   (smallest legal buffered engine)
  dma_buf_dp_min128  ENGINE=1  DW=128 dual port    FIFO_DEPTH=2  BURST=2  MAX_OUT=1
"""
from albionverify.sim.build import DutSpec
from albionverify.suite import Case, Suite


def D(name, **p):
    base = dict(DW=32, ENGINE=0, FIFO_DEPTH=8, BURST=8, DUAL_PORT=0, MAX_OUT=2, MAX_LEN_LOG2=8, PERF=1)
    base.update(p)
    if base["ENGINE"] == 0:  # the buffered-engine knobs are irrelevant for the simple engine
        keep = {k: base[k] for k in ("DW", "ENGINE", "MAX_LEN_LOG2", "PERF")}
        base = keep
    return DutSpec(name, "silicaflux_dma", params=tuple(sorted(base.items())))


SIMPLE = D("dma_simple")
SIMPLE_W64 = D("dma_simple_w64", DW=64, PERF=0)
BUF_SP = D("dma_buf_sp", ENGINE=1, FIFO_DEPTH=4, BURST=2, DUAL_PORT=0, MAX_OUT=2)
BUF_SP_B4 = D("dma_buf_sp_b4", ENGINE=1, FIFO_DEPTH=8, BURST=4, DUAL_PORT=0, MAX_OUT=3)
BUF_DP = D("dma_buf_dp", ENGINE=1, FIFO_DEPTH=4, BURST=4, DUAL_PORT=1, MAX_OUT=2)
BUF_DP_W64 = D("dma_buf_dp_w64", DW=64, ENGINE=1, FIFO_DEPTH=8, BURST=8, DUAL_PORT=1, MAX_OUT=3)
BUF_MIN = D("dma_buf_min", ENGINE=1, FIFO_DEPTH=2, BURST=1, DUAL_PORT=0, MAX_OUT=1)
BUF_DP_MIN128 = D("dma_buf_dp_min128", DW=128, ENGINE=1, FIFO_DEPTH=2, BURST=2, DUAL_PORT=1, MAX_OUT=1)

SEEDS_RANDOM = (1, 2, 3, 4)


def cases_for(dut, seeds_dir=(1, 2), seeds_rand=SEEDS_RANDOM, seeds_reset=(1, 2)):
    return [
        Case(dut, "dma.cocotb_dma_xfer", None, seeds_dir, tags=("directed", "error", "long")),
        Case(dut, "dma.cocotb_dma_regs", None, (1,), tags=("directed", "error")),
        Case(dut, "dma.cocotb_dma_random", None, seeds_rand, tags=("random",)),
        Case(dut, "dma.cocotb_dma_reset", None, seeds_reset, tags=("reset",)),
    ]


def fast_cases(dut):
    """Mutation subset: one seed of every module (kept under ~90 s per mutant)."""
    return [Case(dut, m, None, (1,), tags=t) for m, t in (("dma.cocotb_dma_xfer", ("directed",)), ("dma.cocotb_dma_regs", ("directed",)),
                                                          ("dma.cocotb_dma_random", ("random",)), ("dma.cocotb_dma_reset", ("reset",)))]


SUITES = {
    "dma_simple": Suite(
        name="dma_simple", subsystem="dma",
        title="silicaflux_dma simple engine (+ register file / validation / interrupts shared with the buffered engine)",
        cases=cases_for(SIMPLE) + cases_for(SIMPLE_W64, seeds_rand=(1, 2, 3)),
        mutation_cases=fast_cases(SIMPLE) + fast_cases(SIMPLE_W64),
        mutants_file="mutants/dma_simple.yaml",
        spec_refs=("datafabric/docs/datafabric/DMA.md", "datafabric/docs/datafabric/PROTOCOL.md", "datafabric/docs/datafabric/MEMORY_MAP.md"),
        notes="Independent model: albionverify/models/dma_spec.py + dma_model.py; bench: tests/dma/dma_tb.py",
    ),
    "dma_buffered": Suite(
        name="dma_buffered", subsystem="dma",
        title="silicaflux_dma buffered engine: single / dual port, FIFO_DEPTH / BURST / MAX_OUT variations, DW 32 / 64 / 128",
        cases=cases_for(BUF_SP) + cases_for(BUF_SP_B4, seeds_rand=(1, 2, 3)) + cases_for(BUF_DP) + cases_for(BUF_DP_W64, seeds_rand=(1, 2, 3))
        + cases_for(BUF_MIN, seeds_rand=(1, 2, 3)) + cases_for(BUF_DP_MIN128, seeds_rand=(1, 2, 3)),
        mutation_cases=fast_cases(BUF_SP) + fast_cases(BUF_DP),
        mutants_file="mutants/dma_buffered.yaml",
        spec_refs=("datafabric/docs/datafabric/DMA.md", "datafabric/docs/datafabric/PROTOCOL.md", "datafabric/docs/datafabric/MEMORY_MAP.md"),
        notes="Same independent model; engine structure rules (credit, MAX_OUT, phases, dual port) in dma_model.Transfer",
    ),
}


# ---------------------------------------------------------------------------------------------------------------- adapter
def AD(name, **p):
    base = dict(DW=32, ENGINE=0, FIFO_DEPTH=8, BURST=8, DUAL_PORT=0, MAX_OUT=2, MAX_LEN_LOG2=8, SPM_BASE=0x20000000, SPM_BYTES=1024, SPM_TAG_W=8,
                CMD_DEPTH=2, CPL_DEPTH=2, TAG_W=8, FAB_SLICE=0, PERF_EN=1, CNT_W=32)
    base.update(p)
    if base["ENGINE"] == 0:
        for k in ("FIFO_DEPTH", "BURST", "DUAL_PORT", "MAX_OUT"):
            base.pop(k)
    return DutSpec(name, "hpc_dma_adapter", params=tuple(sorted(base.items())))


ADAPTER_SIMPLE = AD("dma_adapter_simple")
ADAPTER_DP = AD("dma_adapter_dp", ENGINE=1, FIFO_DEPTH=4, BURST=2, DUAL_PORT=1, MAX_OUT=2, CMD_DEPTH=4, CPL_DEPTH=4, FAB_SLICE=1)
ADAPTER_SP64 = AD("dma_adapter_sp64", DW=64, ENGINE=1, FIFO_DEPTH=8, BURST=4, DUAL_PORT=0, MAX_OUT=3, SPM_BASE=0x20000080, SPM_BYTES=128, CMD_DEPTH=0, CPL_DEPTH=2, CNT_W=8)


def adapter_cases(dut, seeds_rand=(1, 2, 3)):
    m = "dma.cocotb_dma_adapter"
    return [Case(dut, m, "directions_lengths", (1,), tags=("directed", "long")), Case(dut, m, "rejects_and_region", (1,), tags=("directed", "error")),
            Case(dut, m, "errors_and_abort", (1,), tags=("directed", "error")), Case(dut, m, "queues_and_order", (1,), tags=("directed",)),
            Case(dut, m, "random_descriptors", seeds_rand, tags=("random",)), Case(dut, m, "reset_adapter", (1, 2), tags=("reset",))]


def adapter_fast(dut):
    m = "dma.cocotb_dma_adapter"
    return [Case(dut, m, t, (1,), tags=("directed",)) for t in ("directions_lengths", "rejects_and_region", "errors_and_abort", "queues_and_order", "random_descriptors", "reset_adapter")]


SUITES["dma_adapter"] = Suite(
    name="dma_adapter", subsystem="dma",
    title="hpc_dma_adapter (HPC DMA adapter, descriptor-driven: DataFabric + scratchpad targets, REGION rule, completion queue)",
    cases=adapter_cases(ADAPTER_SIMPLE) + adapter_cases(ADAPTER_DP) + adapter_cases(ADAPTER_SP64),
    mutation_cases=adapter_fast(ADAPTER_SIMPLE) + adapter_fast(ADAPTER_DP) + [Case(ADAPTER_SP64, "dma.cocotb_dma_adapter", "directions_lengths", (1,), tags=("directed",)),
                                                                              Case(ADAPTER_SP64, "dma.cocotb_dma_adapter", "random_descriptors", (1,), tags=("random",))],
    mutants_file="mutants/dma_adapter.yaml",
    spec_refs=("hpc_m05_dma_adapter/docs/01_architecture_and_interface.md", "hpc_m05_dma_adapter/docs/02_address_spaces.md", "hpc_m05_dma_adapter/docs/03_transfer_semantics.md"),
    notes="Models: dma_spec / dma_model.Transfer (strict=False behind the router) / dma_adapter_model; bench: tests/dma/dma_adapter_tb.py",
)
