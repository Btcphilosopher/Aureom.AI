"""Seeded constrained-random tests of silicaflux_dma: random descriptors (aligned / misaligned / overlapping / over-long /
overflowing / boundary lengths), random request-ready and response stalls, random latency, random bus-error injection,
random aborts and concurrent register traffic.  The reference model checks everything on the fly."""
import os

import cocotb

from albionverify.rng import weighted_choice
from dma.dma_tb import CFG, MAXLEN, SB, TOP, Bench, S

BURST_BYTES = (CFG.burst if CFG.buffered else 4) * SB

PROFILES = [
    ("always", "always", "fixed:1"),
    ("random:0.9", "random:0.9", "uniform:1-2"),
    ("random:0.5", "random:0.5", "uniform:1-4"),
    ("random:0.25", "random:0.3", "uniform:1-3"),
    ("bursty:2-10", "bursty:1-6", "tail:1,0.2,10"),
    ("pattern:01", "pattern:10", "fixed:2"),
    ("always", "random:0.4", "fixed:3"),
    ("random:0.4", "always", "fixed:1"),
]
BASES = [0x0, 0x1000, 0x00FFF000, 0x10000000, 0x10008000, 0x20000000, 0x7FFFF000, 0x80000000, 0xDEADB000, TOP - 0x2000]


def seed_of() -> int:
    return int(os.environ.get("ALBION_SEED", "1"))


def aligned(x: int) -> int:
    return x - x % SB


def boundary_lengths():
    ls = {1, 2, SB - 1, SB, SB + 1, 2 * SB - 1, 2 * SB, 2 * SB + 1, 3 * SB + 1, MAXLEN, MAXLEN - 1, MAXLEN - SB, MAXLEN - SB + 1}
    for m in (1, 2, 3):
        for base in (m * BURST_BYTES, m * (CFG.fifo_depth if CFG.buffered else 4) * SB):
            ls.update({base - 1, base, base + 1})
    return sorted(x for x in ls if 1 <= x <= MAXLEN)


def gen_desc(rng):
    """(kind, src, dst, length) -- kind is only a label (the model derives every expectation itself)."""
    kinds = ["ok", "ok_boundary", "bad_len", "misaligned", "overflow", "overlap", "near", "top"]
    kind = weighted_choice(rng, kinds, [34, 14, 6, 8, 7, 12, 9, 10])
    bnd = boundary_lengths()
    small = rng.randint(1, 10 * SB)
    src = aligned(rng.choice(BASES) + rng.randrange(0, 0x800))
    dst = aligned(rng.choice(BASES) + 0x4000 + rng.randrange(0, 0x800))
    ln = small
    if kind == "ok_boundary":
        ln = rng.choice(bnd)
    elif kind == "bad_len":
        ln = rng.choice([0, 0, MAXLEN + 1, MAXLEN + SB, rng.getrandbits(32), 0xFFFFFFFF, 0x80000000, MAXLEN * 3])
    elif kind == "misaligned":
        ln = rng.randint(1, 6 * SB)
        if SB > 1:
            if rng.random() < 0.5:
                src += rng.randint(1, SB - 1)
            if rng.random() < 0.5 or src % SB == 0:
                dst += rng.randint(1, SB - 1)
    elif kind == "overflow":
        ln = rng.randint(2, 6 * SB)
        if rng.random() < 0.5:
            src = aligned(TOP - rng.randint(1, ln - 1))
        else:
            dst = aligned(TOP - rng.randint(1, ln - 1))
    elif kind == "overlap":
        ln = rng.randint(1, 8 * SB)
        delta = rng.randint(-ln + 1, ln - 1) if rng.random() < 0.8 else 0
        dst = src + aligned(abs(delta)) * (1 if delta >= 0 else -1)
        dst = max(0, aligned(dst))
    elif kind == "near":
        ln = rng.randint(1, 6 * SB)
        nb = S.num_beats(ln, SB) * SB
        dst = src + rng.choice([ln - 1, ln, ln + 1, nb - SB, nb, nb + SB])
        dst = aligned(dst) if rng.random() < 0.9 else dst
        if rng.random() < 0.5:
            src, dst = dst, src
    elif kind == "top":
        ln = rng.randint(1, 5 * SB)
        e = TOP - rng.choice([0, 0, SB, 2 * SB])
        if rng.random() < 0.5:
            src = aligned(e - ln)
        else:
            dst = aligned(e - ln)
    return kind, src & 0xFFFFFFFF, dst & 0xFFFFFFFF, ln


@cocotb.test()
async def random_transfers(dut):
    seed = seed_of()
    b = Bench(dut, seed, rb_gap="random:0.85")
    await b.start()
    b.add_noise(rate=0.2)
    rng = b.rng
    n_iter = 90
    n = {"ok": 0, "err": 0, "bus": 0, "abort": 0, "invalid": 0}
    for it in range(n_iter):
        kind, src, dst, ln = gen_desc(rng)
        rq, rs, lat = rng.choice(PROFILES)
        b.set_stalls(rq, rs, lat)
        valid = S.validate(src, dst, ln, SB, CFG.max_len_log2) == S.E_NONE
        b.inject()
        nb = S.num_beats(ln, SB) if valid else 0
        if valid and rng.random() < 0.3:
            rd = [src + rng.randrange(nb) * SB for _ in range(rng.choice([0, 1, 1, 2]))]
            wr = [dst + rng.randrange(nb) * SB for _ in range(rng.choice([0, 1, 1, 2]))]
            b.inject(rd=rd, wr=wr)
        ie = rng.getrandbits(2)
        await b.program(src, dst, ln, ie=ie)
        b.trig.clear()
        if valid and rng.random() < 0.2:
            d = rng.randint(0, 6 * nb + 10)
            b.trig.when(lambda d=d: b.obs.since_start == d, lambda: b.rb.write_op(S.CONTROL, S.CTRL_ABORT))
        before = b.obs.n_terminal
        await b.go()
        await b.wait_idle(40000)
        await b.env.until(lambda: b.obs.n_terminal > before, 50, "model to see the end of the transfer")
        o = b.obs.outcomes[-1]
        n["ok" if o[3] else ("abort" if o[0] == S.E_ABORTED else ("bus" if o[0] in (S.E_READ_BUS, S.E_WRITE_BUS) else "invalid"))] += 1
        if rng.random() < 0.5:
            for a in rng.sample([S.STATUS, S.BYTES_DONE, S.ERROR_CODE, S.ERROR_ADDR, S.INT_STATUS, S.ACTIVE_CYCLES, S.STALL_CYCLES, S.TRANSFERS], 3):
                await b.rd(a)
        if rng.random() < 0.5:
            await b.wr(S.INT_STATUS, rng.getrandbits(2))
    assert n["ok"] > 10 and (n["invalid"] + n["bus"] + n["abort"]) > 10, n
    b.finish("random_transfers", mix=n)


@cocotb.test()
async def random_long_stalls(dut):
    """Fewer, longer transfers under heavy stalls and slow responses (outstanding limits, FIFO credit, phase changes)."""
    b = Bench(dut, seed_of(), rb_gap="random:0.9")
    await b.start()
    b.add_noise(rate=0.1)
    rng = b.rng
    for it in range(14):
        rq, rs, lat = rng.choice(PROFILES[2:])
        b.set_stalls(rq, rs, lat)
        ln = rng.randint(4 * SB, MAXLEN)
        src = aligned(0x10000000 + rng.randrange(0, 0x400))
        dst = aligned(0x20000000 + rng.randrange(0, 0x400))
        nb = S.num_beats(ln, SB)
        b.inject()
        if rng.random() < 0.3:
            b.inject(rd=[src + rng.randrange(nb) * SB] if rng.random() < 0.5 else [], wr=[dst + rng.randrange(nb) * SB] if rng.random() < 0.5 else [])
        await b.program(src, dst, ln)
        await b.go()
        await b.wait_idle(80000)
    b.inject()
    b.finish("random_long_stalls")
