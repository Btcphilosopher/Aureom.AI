"""Unit tests of albionverify.models.dma_model with hand-built edge traces (no simulator).

Each trace is what a spec-conforming DMA would show on its pins; each negative test breaks exactly one rule
and expects the model to complain.  Expected values (status words, counters, ...) are worked out by hand.
"""
import pytest

from albionverify.models import dma_spec as S
from albionverify.models.dma_model import BusReq, BusRsp, DmaConfig, DmaModel, DmaModelError, Edge, RegAcc, HANG_CYCLES


class Tr:
    """Edge-by-edge driver with the pin bookkeeping spelled out."""

    def __init__(self, cfg=None, **kw):
        self.cfg = cfg or DmaConfig(dw_bytes=4, engine=0, max_len_log2=8, **kw)
        self.m = DmaModel(self.cfg)
        self.n = 0
        self.since = {}

    def step(self, busy, nxt, reg=None, reqs=(), rsps=(), valid=None, pres=None, ready=None, **kw):
        self.n += 1
        np_ = self.cfg.nports
        reqs = [BusReq(*r) if not isinstance(r, BusReq) else r for r in reqs]
        for q in reqs:
            if q.since is None:
                q.since = self.n  # presented in the cycle it was accepted (no stall)
        v = tuple(valid) if valid is not None else tuple(any(q.port == p for q in reqs) for p in range(np_))
        rd = tuple(ready) if ready is not None else tuple(True for _ in range(np_))
        pw = tuple(pres) if pres is not None else tuple((next((q.write for q in reqs if q.port == p), None)) for p in range(np_))
        e = Edge(self.n, busy, nxt, reg=reg, valid=v, ready=rd, pres_write=pw, reqs=reqs, rsps=list(rsps), **kw)
        self.m.edge(e)
        return e


def W(addr, data, err=False):
    return RegAcc(True, addr, data, 0, err)


def R(addr, rdata, err=False):
    return RegAcc(False, addr, 0, rdata, err)


def program(t, src, dst, length):
    t.step(False, False, W(S.SRC_ADDR, src))
    t.step(False, False, W(S.DST_ADDR, dst))
    t.step(False, False, W(S.LENGTH, length))


def start(t, extra=0):
    t.step(False, True, W(S.CONTROL, S.CTRL_START | extra))


def rq(write, addr, wdata=0, strb=0xF, since=None, port=0):
    return BusReq(port, write, addr, wdata, strb, since)


def simple_copy(t, src, dst, length, data):
    """Drive a perfectly behaved simple-engine transfer of ``data`` (list of words) and return after the terminal edge."""
    sb = 4
    plan = S.beat_plan(src, dst, length, sb)
    program(t, src, dst, length)
    start(t)
    t.step(True, True)  # VALIDATE
    for b, w in zip(plan, data):
        t.step(True, True, reqs=[BusReq(0, False, b.src_addr, 0, 0xF, t.n + 1)])
        t.step(True, True, rsps=[BusRsp(0, w, False)])
        t.step(True, True, reqs=[BusReq(0, True, b.dst_addr, w, b.strobe, t.n + 1)])
        t.step(True, True, rsps=[BusRsp(0, 0, False)])
    t.step(True, False, ev_done=True)  # COMPLETE cycle: BUSY falls here


# ------------------------------------------------------------------------------------------- the happy path
def test_model_simple_one_beat_with_register_reads_every_cycle():
    t = Tr()
    program(t, 0x100, 0x200, 4)
    start(t)  # edge 4
    t.step(True, True, R(S.STATUS, 0x101))  # 5: VALIDATE
    t.step(True, True, R(S.STATUS, 0x201), reqs=[rq(False, 0x100)])  # 6: ISSUE_READ presented, accepted
    t.step(True, True, R(S.STATUS, 0x301), rsps=[BusRsp(0, 0xAABBCCDD, False)])  # 7: WAIT_READ
    t.step(True, True, R(S.STATUS, 0x401), reqs=[rq(True, 0x200, 0xAABBCCDD, 0xF)])  # 8: ISSUE_WRITE
    t.step(True, True, R(S.STATUS, 0x501), rsps=[BusRsp(0, 0, False)])  # 9: WAIT_WRITE, response edge
    t.step(True, False, R(S.STATUS, 0x601), ev_done=True)  # 10: COMPLETE, BUSY falls at this edge
    t.step(False, False, R(S.STATUS, 0x002))  # 11: DONE, idle
    t.step(False, False, R(S.BYTES_DONE, 4))
    t.step(False, False, R(S.INT_STATUS, 1))
    t.step(False, False, R(S.ACTIVE_CYCLES, 6))  # busy during edges 5..10
    t.step(False, False, R(S.STALL_CYCLES, 0))
    t.step(False, False, R(S.TRANSFERS, 1))
    t.step(False, False, R(S.ERROR_CODE, 0))
    t.step(False, False, R(S.ERROR_ADDR, 0))
    t.step(False, False, R(S.SRC_ADDR, 0x100))
    t.step(False, False, R(S.LENGTH, 4))
    t.step(False, False, W(S.INT_STATUS, 1))
    t.step(False, False, R(S.INT_STATUS, 0))


def test_model_bytes_done_visible_one_cycle_after_the_response_edge():
    t = Tr()
    program(t, 0x100, 0x200, 8)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, rsps=[BusRsp(0, 0x11111111, False)])
    t.step(True, True, reqs=[rq(True, 0x200, 0x11111111)])
    t.step(True, True, R(S.BYTES_DONE, 0), rsps=[BusRsp(0, 0, False)])  # read at the response edge: not yet counted
    t.step(True, True, R(S.BYTES_DONE, 4), reqs=[rq(False, 0x104)])  # next cycle: counted
    assert t.m.bytes_done == 4


def test_model_partial_last_word_strobe_and_bytes_done():
    t = Tr()
    simple_copy(t, 0x100, 0x200, 10, [0x03020100, 0x07060504, 0x0B0A0908])
    t.step(False, False, R(S.BYTES_DONE, 10))
    t.step(False, False, R(S.STATUS, 0x2))


def test_model_back_pressure_stall_counter_and_ready_low_cycles():
    t = Tr()
    program(t, 0x100, 0x200, 4)
    start(t)
    t.step(True, True)  # VALIDATE (4 -> act 1)
    t.step(True, True, valid=[True], ready=[False], pres=[False])  # read presented, stalled
    t.step(True, True, valid=[True], ready=[False], pres=[False])
    t.step(True, True, reqs=[rq(False, 0x100, since=6)])
    t.step(True, True, rsps=[BusRsp(0, 5, False)])
    t.step(True, True, reqs=[rq(True, 0x200, 5, 0xF)])
    t.step(True, True, rsps=[BusRsp(0, 0, False)])
    t.step(True, False, ev_done=True)
    t.step(False, False, R(S.STALL_CYCLES, 2))
    t.step(False, False, R(S.ACTIVE_CYCLES, 8))


# ------------------------------------------------------------------------------------------- validation errors
@pytest.mark.parametrize("src,dst,length,code", [
    (0x100, 0x200, 0, S.E_ZERO_LENGTH), (0x100, 0x200, 257, S.E_LENGTH), (0x101, 0x200, 4, S.E_SRC_ALIGN),
    (0x100, 0x202, 4, S.E_DST_ALIGN), (0xFFFFFFFC, 0x200, 8, S.E_SRC_OVERFLOW), (0x100, 0xFFFFFFFC, 8, S.E_DST_OVERFLOW),
    (0x100, 0x104, 8, S.E_OVERLAP), (0x100, 0x100, 4, S.E_OVERLAP)])
def test_model_validation_errors_end_without_bus_access(src, dst, length, code):
    t = Tr()
    program(t, src, dst, length)
    start(t)
    t.step(True, True, R(S.STATUS, 0x101))  # VALIDATE
    t.step(True, False, R(S.STATUS, 0x701))  # ERROR state, BUSY falls
    t.step(False, False, R(S.STATUS, 0x004))  # ERROR=1, DONE=0, ABORTED=0
    t.step(False, False, R(S.ERROR_CODE, code))
    t.step(False, False, R(S.ERROR_ADDR, 0))
    t.step(False, False, R(S.BYTES_DONE, 0))
    t.step(False, False, R(S.INT_STATUS, 2))
    t.step(False, False, R(S.TRANSFERS, 0))


def test_model_request_after_validation_error_is_a_violation():
    t = Tr()
    program(t, 0x100, 0x200, 0)
    start(t)
    t.step(True, True)
    with pytest.raises(DmaModelError, match="failed validation"):
        t.step(True, True, valid=[True], pres=[False])


def test_model_wrong_error_code_register_value():
    t = Tr()
    program(t, 0x100, 0x200, 0)
    start(t)
    t.step(True, True)
    t.step(True, False)
    with pytest.raises(DmaModelError, match="ERROR_CODE"):
        t.step(False, False, R(S.ERROR_CODE, S.E_LENGTH))


# ------------------------------------------------------------------------------------------- bus transaction rules
def _to_first_read(t, length=8):
    program(t, 0x100, 0x200, length)
    start(t)
    t.step(True, True)


def test_model_read_address_wrong():
    t = Tr()
    _to_first_read(t)
    with pytest.raises(DmaModelError, match="read beat 0 addressed"):
        t.step(True, True, reqs=[rq(False, 0x104)])


def test_model_write_strobe_wrong_on_tail():
    t = Tr()
    program(t, 0x100, 0x200, 5)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, rsps=[BusRsp(0, 1, False)])
    t.step(True, True, reqs=[rq(True, 0x200, 1, 0xF)])
    t.step(True, True, rsps=[BusRsp(0, 0, False)])
    t.step(True, True, reqs=[rq(False, 0x104)])
    t.step(True, True, rsps=[BusRsp(0, 0x99999999, False)])
    with pytest.raises(DmaModelError, match="strobe 0xf, expected 0x1"):
        t.step(True, True, reqs=[rq(True, 0x204, 0x99999999, 0xF)])


def test_model_write_data_must_match_read_data_only_under_strobe():
    t = Tr()
    program(t, 0x100, 0x200, 1)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, rsps=[BusRsp(0, 0x44332211, False)])
    # lanes 1..3 are not strobed: any value is fine there; lane 0 must be the read byte
    t.step(True, True, reqs=[rq(True, 0x200, 0xAAAAAA11, 0x1)])
    t.step(True, True, rsps=[BusRsp(0, 0, False)])
    t.step(True, False, ev_done=True)

    t = Tr()
    program(t, 0x100, 0x200, 1)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, rsps=[BusRsp(0, 0x44332211, False)])
    with pytest.raises(DmaModelError, match="data"):
        t.step(True, True, reqs=[rq(True, 0x200, 0x44332210, 0x1)])


def test_model_simple_engine_keeps_one_transaction_in_flight():
    t = Tr()
    _to_first_read(t)
    t.step(True, True, reqs=[rq(False, 0x100)])
    with pytest.raises(DmaModelError, match="outstanding|response"):
        t.step(True, True, reqs=[rq(False, 0x104)])  # second read while the first response is pending


def test_model_write_before_read_data_returned():
    t = Tr()
    _to_first_read(t)
    t.step(True, True, reqs=[rq(False, 0x100)])
    with pytest.raises(DmaModelError):
        t.step(True, True, reqs=[rq(True, 0x200, 0)])


def test_model_response_in_acceptance_cycle_or_without_request():
    t = Tr()
    _to_first_read(t)
    with pytest.raises(DmaModelError, match="no outstanding"):
        t.step(True, True, rsps=[BusRsp(0, 0, False)])


def test_model_too_many_requests():
    t = Tr()
    simple_copy(t, 0x100, 0x200, 4, [7])
    t.step(False, False)
    with pytest.raises(DmaModelError, match="no transfer"):
        t.step(False, False, reqs=[rq(False, 0x104)], valid=[False])


def test_model_request_presented_while_idle_after_reset():
    t = Tr()
    t.step(False, False)
    with pytest.raises(DmaModelError, match="idle"):
        t.step(False, False, valid=[True], pres=[False])


# ------------------------------------------------------------------------------------------- errors
def test_model_read_error_beat1_gives_read_bus_with_address_and_prefix_bytes():
    t = Tr()
    program(t, 0x100, 0x200, 12)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, rsps=[BusRsp(0, 0xDEADBEEF, False)])
    t.step(True, True, reqs=[rq(True, 0x200, 0xDEADBEEF)])
    t.step(True, True, rsps=[BusRsp(0, 0, False)])
    t.step(True, True, reqs=[rq(False, 0x104)])
    t.step(True, True, rsps=[BusRsp(0, 0, True)])  # read error on beat 1
    t.step(True, False)  # ERROR cycle
    t.step(False, False, R(S.STATUS, 0x004))
    t.step(False, False, R(S.ERROR_CODE, S.E_READ_BUS))
    t.step(False, False, R(S.ERROR_ADDR, 0x104))
    t.step(False, False, R(S.BYTES_DONE, 4))
    t.step(False, False, R(S.INT_STATUS, 2))


def test_model_no_write_after_read_error():
    t = Tr()
    _to_first_read(t)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, rsps=[BusRsp(0, 0, True)])
    with pytest.raises(DmaModelError, match="read failed|before the data|issued"):
        t.step(True, True, reqs=[rq(True, 0x200, 0)])


def test_model_write_error_gives_write_bus_and_stops_all_requests():
    t = Tr()
    program(t, 0x100, 0x200, 8)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, rsps=[BusRsp(0, 3, False)])
    t.step(True, True, reqs=[rq(True, 0x200, 3)])
    t.step(True, True, rsps=[BusRsp(0, 0, True)])  # write error on beat 0
    with pytest.raises(DmaModelError, match="new read request presented"):
        t.step(True, True, reqs=[rq(False, 0x104)])


def test_model_write_error_outcome_registers():
    t = Tr()
    program(t, 0x100, 0x200, 8)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, rsps=[BusRsp(0, 3, False)])
    t.step(True, True, reqs=[rq(True, 0x200, 3)])
    t.step(True, True, rsps=[BusRsp(0, 0, False)])
    t.step(True, True, reqs=[rq(False, 0x104)])
    t.step(True, True, rsps=[BusRsp(0, 9, False)])
    t.step(True, True, reqs=[rq(True, 0x204, 9)])
    t.step(True, True, rsps=[BusRsp(0, 0, True)])
    t.step(True, False)
    t.step(False, False, R(S.ERROR_CODE, S.E_WRITE_BUS))
    t.step(False, False, R(S.ERROR_ADDR, 0x204))
    t.step(False, False, R(S.BYTES_DONE, 4))
    t.step(False, False, R(S.TRANSFERS, 0))


def test_model_ending_early_is_caught():
    t = Tr()
    program(t, 0x100, 0x200, 8)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, rsps=[BusRsp(0, 3, False)])
    t.step(True, True, reqs=[rq(True, 0x200, 3)])
    t.step(True, True, rsps=[BusRsp(0, 0, False)])
    with pytest.raises(DmaModelError, match="ended early"):
        t.step(True, False)


def test_model_busy_dropping_with_a_request_presented():
    t = Tr()
    _to_first_read(t)
    with pytest.raises(DmaModelError, match="BUSY fell"):
        t.step(True, False, valid=[True], pres=[False])


def test_model_hang_detection():
    t = Tr()
    _to_first_read(t)
    with pytest.raises(DmaModelError, match="no bus activity"):
        for _ in range(HANG_CYCLES + 5):
            t.step(True, True)


def test_model_busy_must_rise_with_start():
    t = Tr()
    program(t, 0x100, 0x200, 4)
    with pytest.raises(DmaModelError, match="BUSY did not rise"):
        t.step(False, False, W(S.CONTROL, 1))


# ------------------------------------------------------------------------------------------- abort
def _one_beat_inflight_read(t, length=12):
    program(t, 0x100, 0x200, length)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])  # edge 6: read accepted


def test_model_abort_while_read_outstanding_stops_before_the_write():
    t = Tr()
    _one_beat_inflight_read(t)
    t.step(True, True, W(S.CONTROL, S.CTRL_ABORT))  # edge 7: abort accepted (rb_err=0)
    t.step(True, True, rsps=[BusRsp(0, 1, False)])  # edge 8: read response, no write follows
    t.step(True, False)  # ERROR cycle
    t.step(False, False, R(S.STATUS, 0x00C))  # ERROR + ABORTED
    t.step(False, False, R(S.ERROR_CODE, S.E_ABORTED))
    t.step(False, False, R(S.BYTES_DONE, 0))
    t.step(False, False, R(S.INT_STATUS, 2))


def test_model_abort_forbids_new_requests():
    t = Tr()
    _one_beat_inflight_read(t)
    t.step(True, True, W(S.CONTROL, S.CTRL_ABORT))
    t.step(True, True, rsps=[BusRsp(0, 1, False)])
    with pytest.raises(DmaModelError, match="after ABORT"):
        t.step(True, True, reqs=[rq(True, 0x200, 1)])


def test_model_abort_same_edge_as_response_tolerates_one_more_request_not_two():
    t = Tr()
    _one_beat_inflight_read(t, 12)
    t.step(True, True, W(S.CONTROL, S.CTRL_ABORT), rsps=[BusRsp(0, 1, False)])  # edge 7: both
    t.step(True, True, reqs=[rq(True, 0x200, 1)])  # tolerated: write of beat 0
    t.step(True, True, rsps=[BusRsp(0, 0, False)])
    with pytest.raises(DmaModelError, match="after ABORT"):
        t.step(True, True, reqs=[rq(False, 0x104)])


def test_model_abort_in_validate_state_means_no_bus_access():
    t = Tr()
    program(t, 0x100, 0x200, 12)
    start(t)
    t.step(True, True, W(S.CONTROL, S.CTRL_ABORT))  # edge 5: engine is validating
    t.step(True, False)
    t.step(False, False, R(S.STATUS, 0xC))
    t.step(False, False, R(S.ERROR_CODE, S.E_ABORTED))


def test_model_abort_on_invalid_descriptor_keeps_validation_code():
    t = Tr()
    program(t, 0x100, 0x200, 0)
    start(t)
    t.step(True, True, W(S.CONTROL, S.CTRL_ABORT))
    t.step(True, False)
    t.step(False, False, R(S.STATUS, 0x4))
    t.step(False, False, R(S.ERROR_CODE, S.E_ZERO_LENGTH))


def test_model_abort_racing_the_final_beat_reports_done():
    t = Tr()
    program(t, 0x100, 0x200, 4)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, rsps=[BusRsp(0, 9, False)])
    t.step(True, True, reqs=[rq(True, 0x200, 9)])
    t.step(True, True, W(S.CONTROL, S.CTRL_ABORT))  # abort while the final write is outstanding
    t.step(True, True, rsps=[BusRsp(0, 0, False)])
    t.step(True, False, ev_done=True)
    t.step(False, False, R(S.STATUS, 0x2))  # DONE, not ABORTED
    t.step(False, False, R(S.BYTES_DONE, 4))
    t.step(False, False, R(S.ERROR_CODE, 0))


def test_model_abort_when_idle_has_no_effect_and_start_abort_idle_starts():
    t = Tr()
    t.step(False, False, W(S.CONTROL, S.CTRL_ABORT))
    program(t, 0x100, 0x200, 4)
    t.step(False, True, W(S.CONTROL, S.CTRL_START | S.CTRL_ABORT))  # START wins, abort is ignored while idle
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, rsps=[BusRsp(0, 9, False)])
    t.step(True, True, reqs=[rq(True, 0x200, 9)])
    t.step(True, True, rsps=[BusRsp(0, 0, False)])
    t.step(True, False, ev_done=True)
    t.step(False, False, R(S.STATUS, 0x2))


def test_model_start_abort_while_busy_is_refused_and_does_not_abort():
    t = Tr()
    _one_beat_inflight_read(t, 4)
    t.step(True, True, W(S.CONTROL, S.CTRL_START | S.CTRL_ABORT, err=True))
    t.step(True, True, rsps=[BusRsp(0, 9, False)])
    t.step(True, True, reqs=[rq(True, 0x200, 9)])  # transfer carries on
    t.step(True, True, rsps=[BusRsp(0, 0, False)])
    t.step(True, False, ev_done=True)
    t.step(False, False, R(S.STATUS, 0x2))


# ------------------------------------------------------------------------------------------- register rules
def test_model_reset_values_and_info():
    t = Tr(DmaConfig(dw_bytes=4, engine=1, fifo_depth=8, burst=4, dual_port=1, max_out=2, max_len_log2=8))
    for a in (S.CONTROL, S.STATUS, S.SRC_ADDR, S.DST_ADDR, S.LENGTH, S.BYTES_DONE, S.INT_ENABLE, S.INT_STATUS, S.ERROR_CODE, S.ERROR_ADDR, S.ACTIVE_CYCLES, S.STALL_CYCLES, S.TRANSFERS):
        t.step(False, False, R(a, 0))
    t.step(False, False, R(S.INFO, 0x01083104))
    t.step(False, False, R(S.ID, 0x53464446))


def test_model_writes_to_read_only_and_unmapped_are_errors_reads_of_unmapped_too():
    t = Tr()
    for a in (S.STATUS, S.BYTES_DONE, S.ERROR_CODE, S.ERROR_ADDR, S.INFO, S.ID, S.ACTIVE_CYCLES, S.STALL_CYCLES, S.TRANSFERS, 0x03C, 0x040, 0xFFC, 0x00A):
        t.step(False, False, W(a, 0x12345678, err=True))
    for a in (0x03C, 0x100, 0xFFC, 0x002):
        t.step(False, False, R(a, 0, err=True))
    with pytest.raises(DmaModelError, match="rb_err"):
        t.step(False, False, W(S.STATUS, 1, err=False))


def test_model_perf_registers_error_when_not_built():
    t = Tr(DmaConfig(dw_bytes=4, engine=0, max_len_log2=8, perf=0))
    for a in (S.ACTIVE_CYCLES, S.STALL_CYCLES, S.TRANSFERS):
        t.step(False, False, R(a, 0, err=True))
        t.step(False, False, W(a, 1, err=True))
    t.step(False, False, R(S.ID, 0x53464446))


def test_model_busy_protection():
    t = Tr()
    _one_beat_inflight_read(t, 4)
    for a in (S.SRC_ADDR, S.DST_ADDR, S.LENGTH):
        t.step(True, True, W(a, 0x555, err=True))
    t.step(True, True, W(S.CONTROL, S.CTRL_START, err=True))
    t.step(True, True, W(S.INT_ENABLE, 3, err=False))  # allowed while busy
    t.step(True, True, W(S.INT_STATUS, 3, err=False))
    t.step(True, True, R(S.SRC_ADDR, 0x100))  # unchanged
    t.step(True, True, R(S.LENGTH, 4))
    t.step(True, True, R(S.INT_ENABLE, 3))
    with pytest.raises(DmaModelError, match="rb_err"):
        t.step(True, True, W(S.SRC_ADDR, 0x555, err=False))


def test_model_busy_register_write_at_the_terminal_edge_is_still_refused():
    t = Tr()
    program(t, 0x100, 0x200, 4)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, rsps=[BusRsp(0, 9, False)])
    t.step(True, True, reqs=[rq(True, 0x200, 9)])
    t.step(True, True, rsps=[BusRsp(0, 0, False)])
    t.step(True, False, W(S.SRC_ADDR, 0x300, err=True), ev_done=True)  # BUSY is still 1 in this cycle
    t.step(False, False, R(S.SRC_ADDR, 0x100))
    t.step(False, True, W(S.CONTROL, 1))  # now idle: START accepted
    assert t.m.active


def test_model_interrupt_set_wins_over_same_edge_clear_and_irq_level():
    t = Tr()
    t.step(False, False, W(S.INT_ENABLE, 1))
    program(t, 0x100, 0x200, 4)
    start(t)
    t.step(True, True, irq=False)
    t.step(True, True, reqs=[rq(False, 0x100)], irq=False)
    t.step(True, True, rsps=[BusRsp(0, 9, False)], irq=False)
    t.step(True, True, reqs=[rq(True, 0x200, 9)], irq=False)
    t.step(True, True, rsps=[BusRsp(0, 0, False)], irq=False)
    t.step(True, False, W(S.INT_STATUS, 1), ev_done=True, irq=False)  # W1C and the DONE event on the same edge: set wins
    t.step(False, False, R(S.INT_STATUS, 1), irq=True)
    t.step(False, False, W(S.INT_STATUS, 1), irq=True)
    t.step(False, False, R(S.INT_STATUS, 0), irq=False)
    with pytest.raises(DmaModelError, match="irq"):
        t.step(False, False, irq=True)


def test_model_irq_requires_enable_and_error_bit():
    t = Tr()
    program(t, 0x100, 0x200, 0)
    start(t)
    t.step(True, True)
    t.step(True, False)
    t.step(False, False, R(S.INT_STATUS, 2), irq=False)  # pending but not enabled
    t.step(False, False, W(S.INT_ENABLE, 1), irq=False)  # DONE enabled only: still no irq
    t.step(False, False, W(S.INT_ENABLE, 2), irq=False)
    t.step(False, False, R(S.INT_ENABLE, 2), irq=True)


def test_model_int_enable_masks_to_two_bits_and_start_does_not_clear_int_status():
    t = Tr()
    t.step(False, False, W(S.INT_ENABLE, 0xFFFFFFFF))
    t.step(False, False, R(S.INT_ENABLE, 3))
    program(t, 0x100, 0x200, 0)
    start(t)
    t.step(True, True)
    t.step(True, False)
    t.step(False, False, R(S.INT_STATUS, 2), irq=True)
    program(t, 0x100, 0x200, 0)
    start(t)  # a new START leaves INT_STATUS alone
    t.step(True, True, R(S.INT_STATUS, 2))
    t.step(True, False)
    t.step(False, False, R(S.INT_STATUS, 2))


def test_model_start_clears_flags_error_code_bytes_done_and_counters():
    t = Tr()
    program(t, 0x100, 0x200, 0)
    start(t)
    t.step(True, True)
    t.step(True, False)
    t.step(False, False, R(S.ERROR_CODE, S.E_ZERO_LENGTH))
    program(t, 0x100, 0x200, 4)
    start(t)
    t.step(True, True, R(S.STATUS, 0x101))  # DONE/ERROR cleared by START
    t.step(True, True, R(S.ACTIVE_CYCLES, 1), reqs=[rq(False, 0x100)])
    t.step(True, True, rsps=[BusRsp(0, 5, False)])
    t.step(True, True, reqs=[rq(True, 0x200, 5)])
    t.step(True, True, rsps=[BusRsp(0, 0, False)])
    t.step(True, False, ev_done=True)
    t.step(False, False, R(S.ERROR_CODE, 0))
    t.step(False, False, R(S.TRANSFERS, 1))


# ------------------------------------------------------------------------------------------- buffered engine
BUF_SP = dict(dw_bytes=4, engine=1, fifo_depth=4, burst=2, dual_port=0, max_out=2, max_len_log2=8)
BUF_DP = dict(dw_bytes=4, engine=1, fifo_depth=4, burst=2, dual_port=1, max_out=2, max_len_log2=8)


def test_model_buffered_single_port_phases_burst_and_credit():
    t = Tr(DmaConfig(**BUF_SP))
    program(t, 0x100, 0x200, 16)  # 4 beats
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, reqs=[rq(False, 0x104)], rsps=[BusRsp(0, 0xA0, False)])  # 2 outstanding: limit MAX_OUT=2
    t.step(True, True, rsps=[BusRsp(0, 0xA1, False)])
    # phase switch: port idle, then the write phase (2 writes back to back)
    t.step(True, True, reqs=[rq(True, 0x200, 0xA0)])
    t.step(True, True, reqs=[rq(True, 0x204, 0xA1)], rsps=[BusRsp(0, 0, False)])
    t.step(True, True, rsps=[BusRsp(0, 0, False)])
    t.step(True, True, R(S.BYTES_DONE, 8))
    t.step(True, True, reqs=[rq(False, 0x108)])
    t.step(True, True, reqs=[rq(False, 0x10C)], rsps=[BusRsp(0, 0xA2, False)])
    t.step(True, True, rsps=[BusRsp(0, 0xA3, False)])
    t.step(True, True, reqs=[rq(True, 0x208, 0xA2)])
    t.step(True, True, reqs=[rq(True, 0x20C, 0xA3)], rsps=[BusRsp(0, 0, False)])
    t.step(True, True, rsps=[BusRsp(0, 0, False)])
    t.step(True, False, ev_done=True)
    t.step(False, False, R(S.BYTES_DONE, 16))


def test_model_buffered_single_port_burst_limit():
    t = Tr(DmaConfig(**BUF_SP))
    program(t, 0x100, 0x200, 16)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, reqs=[rq(False, 0x104)], rsps=[BusRsp(0, 1, False)])
    t.step(True, True, rsps=[BusRsp(0, 2, False)])
    with pytest.raises(DmaModelError, match="BURST"):
        t.step(True, True, reqs=[rq(False, 0x108)])


def test_model_buffered_single_port_phase_switch_needs_idle_port():
    t = Tr(DmaConfig(**BUF_SP))
    program(t, 0x100, 0x200, 16)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, rsps=[BusRsp(0, 1, False)])
    t.step(True, True, reqs=[rq(False, 0x104)])
    with pytest.raises(DmaModelError, match="phase|idle|before the data"):
        t.step(True, True, reqs=[rq(True, 0x200, 1)])  # write while a read is outstanding


def test_model_buffered_outstanding_limit_and_fifo_credit():
    t = Tr(DmaConfig(**dict(BUF_DP, max_out=2, fifo_depth=8)))
    program(t, 0x100, 0x200, 16)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, reqs=[rq(False, 0x104)])
    with pytest.raises(DmaModelError, match="outstanding"):
        t.step(True, True, reqs=[rq(False, 0x108)])


def test_model_buffered_fifo_credit_two_slots():
    t = Tr(DmaConfig(**dict(BUF_DP, max_out=3, fifo_depth=2)))
    program(t, 0x100, 0x200, 16)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, reqs=[rq(False, 0x104)], rsps=[BusRsp(0, 1, False)])
    t.step(True, True, rsps=[BusRsp(0, 2, False)])
    # both FIFO slots are occupied (no write accepted yet): a third read would exceed FIFO_DEPTH
    with pytest.raises(DmaModelError, match="FIFO_DEPTH"):
        t.step(True, True, reqs=[rq(False, 0x108)])


def test_model_buffered_dual_port_directions():
    t = Tr(DmaConfig(**BUF_DP))
    program(t, 0x100, 0x200, 8)
    start(t)
    t.step(True, True)
    with pytest.raises(DmaModelError, match="dual port"):
        t.step(True, True, reqs=[rq(False, 0x100, port=1)])


def test_model_buffered_write_error_allows_up_to_max_out_minus_1_later_writes():
    t = Tr(DmaConfig(**dict(BUF_DP, max_out=2, fifo_depth=4)))
    program(t, 0x100, 0x200, 16)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100, port=0)])
    t.step(True, True, reqs=[rq(False, 0x104, port=0)], rsps=[BusRsp(0, 1, False)])
    t.step(True, True, rsps=[BusRsp(0, 2, False)])
    t.step(True, True, reqs=[rq(True, 0x200, 1, port=1)])
    t.step(True, True, reqs=[rq(True, 0x204, 2, port=1)])  # second write outstanding behind the first
    t.step(True, True, rsps=[BusRsp(1, 0, True)])  # beat 0 write fails; beat 1 write (1 later beat = MAX_OUT-1) in flight
    t.step(True, True, rsps=[BusRsp(1, 0, False)])
    t.step(True, False)
    t.step(False, False, R(S.ERROR_CODE, S.E_WRITE_BUS))
    t.step(False, False, R(S.ERROR_ADDR, 0x200))
    t.step(False, False, R(S.BYTES_DONE, 0))  # contiguous prefix: beat 0 failed, beat 1's OK write does not count


def test_model_buffered_read_error_requires_earlier_beats_to_be_written():
    t = Tr(DmaConfig(**BUF_DP))
    program(t, 0x100, 0x200, 12)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, reqs=[rq(False, 0x104)], rsps=[BusRsp(0, 1, False)])
    t.step(True, True, rsps=[BusRsp(0, 0, True)])  # beat 1 read error; beat 0 data is buffered but not yet written
    with pytest.raises(DmaModelError, match="BYTES_DONE rule|beats before"):
        t.step(True, False)


def test_model_buffered_read_error_after_all_earlier_writes_ends_with_read_bus():
    t = Tr(DmaConfig(**BUF_DP))
    program(t, 0x100, 0x200, 12)
    start(t)
    t.step(True, True)
    t.step(True, True, reqs=[rq(False, 0x100)])
    t.step(True, True, reqs=[rq(False, 0x104)], rsps=[BusRsp(0, 1, False)])
    t.step(True, True, rsps=[BusRsp(0, 0, True)])
    t.step(True, True, reqs=[rq(True, 0x200, 1, port=1)])
    t.step(True, True, rsps=[BusRsp(1, 0, False)])
    t.step(True, False)
    t.step(False, False, R(S.ERROR_CODE, S.E_READ_BUS))
    t.step(False, False, R(S.ERROR_ADDR, 0x104))
    t.step(False, False, R(S.BYTES_DONE, 4))


def test_model_buffered_status_state_single_port_phase():
    t = Tr(DmaConfig(**BUF_SP))
    program(t, 0x100, 0x200, 8)
    start(t)
    t.step(True, True, R(S.STATUS, 0x101))  # VALIDATE
    t.step(True, True, R(S.STATUS, 0x201), reqs=[rq(False, 0x100)])  # read phase
    t.step(True, True, R(S.STATUS, 0x201), reqs=[rq(False, 0x104)], rsps=[BusRsp(0, 1, False)])
    t.step(True, True, R(S.STATUS, 0x201), rsps=[BusRsp(0, 2, False)])  # read still outstanding: still the read phase
    t.step(True, True, R(S.STATUS, 0x401), reqs=[rq(True, 0x200, 1)])  # write phase
    t.step(True, True, R(S.STATUS, 0x401), reqs=[rq(True, 0x204, 2)])
    with pytest.raises(DmaModelError, match="STATE"):
        t.step(True, True, R(S.STATUS, 0x201), rsps=[BusRsp(0, 0, False)])  # write outstanding: must not say ISSUE_READ


def test_model_buffered_fifo_level_pin_tracks_occupancy():
    t = Tr(DmaConfig(**BUF_DP))
    program(t, 0x100, 0x200, 8)
    start(t)
    t.step(True, True, fifo_level=0)
    t.step(True, True, reqs=[rq(False, 0x100)], fifo_level=0)
    t.step(True, True, reqs=[rq(False, 0x104)], rsps=[BusRsp(0, 1, False)], fifo_level=0)
    t.step(True, True, rsps=[BusRsp(0, 2, False)], fifo_level=1)
    with pytest.raises(DmaModelError, match="fifo_level"):
        t.step(True, True, fifo_level=1)  # two read responses, no write yet: occupancy is 2


def test_model_simple_engine_fifo_level_must_stay_zero():
    t = Tr()
    t.step(False, False, fifo_level=0)
    with pytest.raises(DmaModelError, match="fifo_level"):
        t.step(False, False, fifo_level=1)


def test_model_pins_busy_bytes_done_checked_every_cycle():
    t = Tr()
    t.step(False, False, bytes_done_pin=0)
    with pytest.raises(DmaModelError, match="busy pin"):
        t.step(True, True)
    t = Tr()
    with pytest.raises(DmaModelError, match="bytes_done pin"):
        t.step(False, False, bytes_done_pin=4)


def test_model_reset_clears_everything():
    t = Tr()
    t.step(False, False, W(S.INT_ENABLE, 3))
    program(t, 0x100, 0x200, 12)
    start(t)
    t.step(True, True)
    t.m.reset()
    t.step(False, False, R(S.SRC_ADDR, 0))
    t.step(False, False, R(S.LENGTH, 0))
    t.step(False, False, R(S.INT_ENABLE, 0))
    t.step(False, False, R(S.STATUS, 0))
    t.step(False, False, R(S.ACTIVE_CYCLES, 0))
