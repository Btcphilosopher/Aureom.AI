"""Hand-computed spec examples for albionverify.models.dma_spec (no simulator needed).

Every expected value below was worked out by hand from DMA.md / MEMORY_MAP.md, not produced by the model.
"""
import pytest

from albionverify.models import dma_spec as S

SB = 4
ML = 8  # MAX_LEN_LOG2 -> 256 bytes


def v(src, dst, length, sb=SB, ml=ML):
    return S.validate(src, dst, length, sb, ml)


def test_model_validate_ok():
    assert v(0x1000, 0x2000, 1) == S.E_NONE
    assert v(0x1000, 0x2000, 256) == S.E_NONE  # exactly 2^MAX_LEN_LOG2 is legal
    assert v(0x0, 0x100, 256) == S.E_NONE  # adjacent, not overlapping: [0,256) and [256,512)
    assert v(0x100, 0x0, 256) == S.E_NONE


def test_model_validate_precedence_first_failing_rule_wins():
    # zero length beats everything
    assert v(0x1001, 0x2002, 0) == S.E_ZERO_LENGTH
    assert v(0xFFFFFFFF, 0xFFFFFFFF, 0) == S.E_ZERO_LENGTH
    # too long beats alignment / overflow / overlap
    assert v(0x1001, 0x1001, 257) == S.E_LENGTH
    assert v(0xFFFFFFF8, 0xFFFFFFF8, 0x1000) == S.E_LENGTH
    # src alignment beats dst alignment and overflow
    assert v(0x1001, 0x2002, 8) == S.E_SRC_ALIGN
    assert v(0xFFFFFFFD, 0x1000, 8) == S.E_SRC_ALIGN
    assert v(0x1000, 0x2002, 8) == S.E_DST_ALIGN
    # overflow beats overlap
    assert v(0xFFFFFFF8, 0xFFFFFFF8, 16) == S.E_SRC_OVERFLOW
    assert v(0x1000, 0xFFFFFFF8, 16) == S.E_DST_OVERFLOW
    assert v(0xFFFFFFF8, 0xFFFFFFF0, 16) == S.E_SRC_OVERFLOW  # both overflow-ish: src rule first
    # dst overflow while src is fine
    assert v(0xFFFFFFF0, 0xFFFFFFF8, 16) == S.E_DST_OVERFLOW


def test_model_validate_overflow_boundary():
    assert v(0xFFFFFFF0, 0x1000, 16) == S.E_NONE  # end == 2^32 exactly: allowed
    assert v(0xFFFFFFF0, 0x1000, 17) == S.E_SRC_OVERFLOW  # one byte over (len not multiple of SB is fine, byte accurate)
    assert v(0x1000, 0xFFFFFFFC, 4) == S.E_NONE
    assert v(0x1000, 0xFFFFFFFC, 5) == S.E_DST_OVERFLOW


def test_model_validate_overlap_is_byte_exact():
    assert v(0x1000, 0x1000, 4) == S.E_OVERLAP  # src == dst
    assert v(0x1000, 0x1004, 8) == S.E_OVERLAP  # dst starts inside src
    assert v(0x1004, 0x1000, 8) == S.E_OVERLAP  # src starts inside dst
    assert v(0x1000, 0x1008, 8) == S.E_NONE  # dst starts exactly at the end of src
    assert v(0x1008, 0x1000, 8) == S.E_NONE
    # byte-accurate lengths: len 5 occupies bytes 0x10..0x14; dst 0x14 hits byte 0x14, dst 0x18 does not even
    # though the source's last (full) word read ends at 0x17
    assert v(0x10, 0x14, 5) == S.E_OVERLAP
    assert v(0x10, 0x18, 5) == S.E_NONE


def test_model_validate_dw64():
    assert S.validate(0x1004, 0x2000, 8, 8, 8) == S.E_SRC_ALIGN  # 4-aligned but not 8-aligned
    assert S.validate(0x1000, 0x2008, 8, 8, 8) == S.E_NONE
    assert S.validate(0x1000, 0x2004, 8, 8, 8) == S.E_DST_ALIGN


def test_model_beat_plan_lengths():
    p = S.beat_plan(0x100, 0x200, 10, 4)
    assert [(b.src_addr, b.dst_addr, b.nbytes, b.strobe) for b in p] == [(0x100, 0x200, 4, 0xF), (0x104, 0x204, 4, 0xF), (0x108, 0x208, 2, 0x3)]
    assert [b.strobe for b in S.beat_plan(0, 0x40, 1, 4)] == [0x1]
    assert [b.strobe for b in S.beat_plan(0, 0x40, 4, 4)] == [0xF]
    assert [b.strobe for b in S.beat_plan(0, 0x40, 7, 4)] == [0xF, 0x7]
    assert [b.strobe for b in S.beat_plan(0, 0x40, 9, 8)] == [0xFF, 0x01]
    assert [b.strobe for b in S.beat_plan(0, 0x40, 8, 8)] == [0xFF]
    assert S.num_beats(13, 4) == 4 and S.num_beats(12, 4) == 3 and S.num_beats(1, 8) == 1


def test_model_info_word():
    # VERSION=1, MAX_LEN_LOG2=24, FIFO_LOG2=3, BUFFERED, DW_BYTES=4
    assert S.info_word(4, 1, 8, 24) == 0x01183104
    assert S.info_word(4, 0, 1, 24) == 0x01180004  # simple engine: no FIFO, not buffered
    assert S.info_word(8, 1, 2, 8) == 0x01081108  # FIFO_LOG2 = 1
    assert S.info_word(8, 1, 16, 10) == 0x010A4108  # FIFO_LOG2 = 4


def test_model_lane_masks():
    assert S.lane_mask_bits(0x5, 4) == 0x00FF00FF
    assert S.lane_mask_bits(0x0, 4) == 0
    assert S.lane_mask_bits(0xF, 4) == 0xFFFFFFFF
    assert S.split_word(0x44332211, 4) == [0x11, 0x22, 0x33, 0x44]


def test_model_register_map_constants():
    assert (S.CONTROL, S.STATUS, S.SRC_ADDR, S.DST_ADDR, S.LENGTH) == (0x0, 0x4, 0x8, 0xC, 0x10)
    assert (S.BYTES_DONE, S.INT_ENABLE, S.INT_STATUS, S.ERROR_CODE, S.ERROR_ADDR) == (0x14, 0x18, 0x1C, 0x20, 0x24)
    assert (S.INFO, S.ID, S.ACTIVE_CYCLES, S.STALL_CYCLES, S.TRANSFERS) == (0x28, 0x2C, 0x30, 0x34, 0x38)
    assert S.ID_VALUE == int.from_bytes(b"SFDF", "big")
    assert S.ERROR_NAMES[10] == "ABORTED" and S.STATE_NAMES[7] == "ERROR"
