"""Directed transfer-level tests of silicaflux_dma (every ENGINE / DUAL_PORT / DW configuration).

Stimulus lives here; every expectation is checked on the fly by the independent reference model through
``dma_tb.DmaObserver`` (register values, bus transactions, byte-exact memory images, protocol).  The hand-written
``expect_outcome`` calls cross-check the model itself against the spec tables.
"""
import os

import cocotb

from albionverify.core import AlbionCheckError
from dma.dma_tb import CFG, MAXLEN, NP, SB, TOP, Bench, S

SRC0 = 0x10000000
DST0 = 0x20000000
BURST_BYTES = (CFG.burst if CFG.buffered else 4) * SB


def seed_of() -> int:
    return int(os.environ.get("ALBION_SEED", "1"))


async def read_outcome_regs(b: Bench):
    """Read the whole result state back (the model checks every value)."""
    for a in (S.STATUS, S.BYTES_DONE, S.ERROR_CODE, S.ERROR_ADDR, S.INT_STATUS):
        await b.rd(a)


@cocotb.test()
async def validation_matrix(dut):
    """Every validation rule, precedence pairs, boundary values; no bus access on any failing descriptor."""
    b = Bench(dut, seed_of(), req_thr="random:0.8", rsp_thr="random:0.8", latency="uniform:1-2")
    await b.start()
    N = S
    rows = [
        # (src, dst, len, expected ERROR_CODE)  -- first failing rule wins
        (SRC0, DST0, 0, N.E_ZERO_LENGTH),
        (SRC0 + 1, DST0 + 1, 0, N.E_ZERO_LENGTH),  # zero beats misalignment
        (TOP - SB, TOP - SB, 0, N.E_ZERO_LENGTH),
        (SRC0, DST0, MAXLEN + 1, N.E_LENGTH),
        (SRC0 + 1, DST0 + 1, MAXLEN + 1, N.E_LENGTH),  # too long beats misalignment
        (TOP - SB, TOP - SB, MAXLEN + 1, N.E_LENGTH),  # too long beats overflow / overlap
        (SRC0, DST0, 0xFFFFFFFF, N.E_LENGTH),
        (SRC0, DST0, 0x80000000, N.E_LENGTH),
        (SRC0, DST0, MAXLEN * 2, N.E_LENGTH),
        (SRC0 + 1, DST0, 2 * SB, N.E_SRC_ALIGN),
        (SRC0 + SB - 1, DST0, 2 * SB, N.E_SRC_ALIGN),
        (SRC0, DST0 + 1, 2 * SB, N.E_DST_ALIGN),
        (SRC0, DST0 + SB - 1, 2 * SB, N.E_DST_ALIGN),
        (SRC0 + 1, DST0 + 1, 2 * SB, N.E_SRC_ALIGN),  # both misaligned: src rule first
        (SRC0 + 1, DST0, MAXLEN, N.E_SRC_ALIGN),
        (TOP - SB, DST0, 2 * SB, N.E_SRC_OVERFLOW),
        (TOP - 2 * SB, DST0, 2 * SB + 1, N.E_SRC_OVERFLOW),  # one byte over the end of the address space
                (SRC0, TOP - SB, 2 * SB, N.E_DST_OVERFLOW),
        (SRC0, TOP - 2 * SB, 2 * SB + 1, N.E_DST_OVERFLOW),
        (TOP - SB, TOP - SB, 2 * SB, N.E_SRC_OVERFLOW),  # both overflow (and overlap): src rule first
        (TOP - 2 * SB, TOP - SB, 2 * SB, N.E_DST_OVERFLOW),  # dst overflow beats overlap
        (SRC0, SRC0, 4 * SB, N.E_OVERLAP),  # src == dst
        (SRC0, SRC0 + SB, 4 * SB, N.E_OVERLAP),
        (SRC0 + SB, SRC0, 4 * SB, N.E_OVERLAP),
        (SRC0, SRC0 + 3 * SB, 4 * SB, N.E_OVERLAP),  # one word of overlap
        (SRC0, SRC0 + 4 * SB, 4 * SB, N.E_NONE),  # adjacent: legal
        (SRC0 + 4 * SB, SRC0, 4 * SB, N.E_NONE),
        (SRC0, SRC0 + 2 * SB, 2 * SB + 1, N.E_OVERLAP),  # byte accurate: byte 2*SB belongs to src
        (SRC0, SRC0 + 3 * SB, 2 * SB + 1, N.E_NONE),  # ... but the next word does not
        (SRC0 + 2 * SB, SRC0, 2 * SB + 1, N.E_OVERLAP),
        (SRC0 + 3 * SB, SRC0, 2 * SB + 1, N.E_NONE),
        (SRC0, DST0 + 1, MAXLEN, N.E_DST_ALIGN),
        (SRC0, SRC0 + SB, MAXLEN, N.E_OVERLAP),
        (SRC0 + 1, DST0, MAXLEN, N.E_SRC_ALIGN),
        (SRC0 + 1, DST0, 1, N.E_SRC_ALIGN),  # one byte / one word / sub-word lengths with each validation rule
        (SRC0, DST0 + 1, 1, N.E_DST_ALIGN),
        (SRC0 + 1, DST0, SB, N.E_SRC_ALIGN),
        (SRC0, DST0 + 1, SB, N.E_DST_ALIGN),
        (SRC0, SRC0, SB, N.E_OVERLAP),
        (SRC0, SRC0 + SB - 1 if SB > 1 else SRC0, 1 if SB == 1 else SB, N.E_DST_ALIGN if SB > 1 else N.E_OVERLAP),
        (TOP - SB, TOP - SB, 1, N.E_OVERLAP),
        (SRC0, DST0 + 1, SB - 1 if SB > 2 else 1, N.E_DST_ALIGN),
        (SRC0, DST0, 1, N.E_NONE),
        (SRC0, DST0, SB, N.E_NONE),
        (TOP - 2 * SB, DST0, 2 * SB, N.E_NONE),  # source ends exactly at 2^32
        (SRC0, TOP - 2 * SB, 2 * SB, N.E_NONE),  # destination ends exactly at 2^32
        (TOP - SB, DST0, SB, N.E_NONE),
        (SRC0, TOP - SB, 1, N.E_NONE),  # one byte in the very last word
        (0, DST0, 2 * SB, N.E_NONE),  # address 0
        (SRC0, 0, 2 * SB, N.E_NONE),
    ]
    for src, dst, ln, code in rows:
        await b.program(src, dst, ln)
        await b.go()
        await b.wait_idle()
        b.expect_outcome(code, ln if code == S.E_NONE else 0)
        if code != S.E_NONE:
            await read_outcome_regs(b)
    # exhaustive precedence cross product on small / boundary values (expectation = the spec rule order)
    srcs = [SRC0, SRC0 + 1, TOP - SB, TOP - 2 * SB, SRC0 + SB, 0]
    dsts = [DST0, DST0 + SB - 1, TOP - SB, TOP - 2 * SB, SRC0, SRC0 + SB, 0]
    lens = [0, 1, SB + 1, 2 * SB, MAXLEN + 1]
    if CFG.buffered and not CFG.dual and 2 * SB < BURST_BYTES < MAXLEN:
        lens += [BURST_BYTES, BURST_BYTES + 1]
    for ln in lens:
        for s in srcs:
            for d in dsts:
                code = S.validate(s, d, ln, SB, CFG.max_len_log2)
                await b.program(s, d, ln)
                await b.go()
                await b.wait_idle()
                b.expect_outcome(code, ln if code == S.E_NONE else 0)
    assert b.obs.imaged >= 5, "valid descriptors did not run through the byte-exact image check"
    b.finish("validation_matrix")


@cocotb.test()
async def length_sweep(dut):
    """Every length 1 .. 3*DW/8+1 plus lengths around burst / FIFO / outstanding boundaries; byte-exact tails."""
    b = Bench(dut, seed_of(), req_thr="random:0.9", rsp_thr="random:0.9", latency="uniform:1-2")
    await b.start()
    lens = list(range(1, 3 * SB + 2))
    fifo = CFG.fifo_depth if CFG.buffered else 4
    for m in (1, 2, 3):
        for base in (m * BURST_BYTES, m * fifo * SB, m * (CFG.out_limit + 1) * SB):
            for dlt in (-1, 0, 1):
                ln = base + dlt
                if 1 <= ln <= MAXLEN and ln not in lens:
                    lens.append(ln)
    lens += [MAXLEN - 1, MAXLEN - SB + 1, MAXLEN]
    for i, ln in enumerate(lens):
        src = SRC0 + SB * ((i * 3) % 7)
        dst = DST0 + SB * ((i * 5) % 11) + (0x1000 if i % 2 else 0)
        await b.copy(src, dst, ln)
        b.expect_outcome(S.E_NONE, ln)
    # the tail rule at the very top of the address space and with src > dst
    for ln in (1, SB - 1 if SB > 1 else 1, SB, SB + 1, 2 * SB + 3):
        await b.copy(TOP - ((ln + SB - 1) // SB) * SB, DST0, ln)
        b.expect_outcome(S.E_NONE, ln)
        await b.copy(SRC0, TOP - ((ln + SB - 1) // SB) * SB, ln)
        b.expect_outcome(S.E_NONE, ln)
    assert b.obs.imaged >= len(lens)
    b.finish("length_sweep", lengths=len(lens))


@cocotb.test()
async def max_length(dut):
    """Maximum legal length (2^MAX_LEN_LOG2), just over it, and maximum transfers ending exactly at 2^32."""
    b = Bench(dut, seed_of(), req_thr="random:0.7", rsp_thr="random:0.7", latency="uniform:1-3")
    await b.start()
    await b.copy(SRC0, DST0, MAXLEN, max_cycles=40000)
    b.expect_outcome(S.E_NONE, MAXLEN)
    await b.copy(DST0, SRC0 + 0x4000, MAXLEN, max_cycles=40000)  # copy of the copy
    b.expect_outcome(S.E_NONE, MAXLEN)
    await b.copy(SRC0, DST0 + 0x100, MAXLEN + 1)
    b.expect_outcome(S.E_LENGTH, 0)
    await b.copy(TOP - MAXLEN, DST0 + 0x8000, MAXLEN, max_cycles=40000)
    b.expect_outcome(S.E_NONE, MAXLEN)
    await b.copy(SRC0 + 0x8000, TOP - MAXLEN, MAXLEN, max_cycles=40000)
    b.expect_outcome(S.E_NONE, MAXLEN)
    await b.copy(TOP - MAXLEN + SB, DST0, MAXLEN, max_cycles=40000)
    b.expect_outcome(S.E_SRC_OVERFLOW, 0)
    await b.copy(SRC0, TOP - MAXLEN + SB, MAXLEN)
    b.expect_outcome(S.E_DST_OVERFLOW, 0)
    # maximum length with a one-byte tail shortfall: length = max - 1 (last word partial)
    await b.copy(SRC0, DST0 + 0x2000, MAXLEN - 1, max_cycles=40000)
    b.expect_outcome(S.E_NONE, MAXLEN - 1)
    b.finish("max_length")


@cocotb.test()
async def bus_errors(dut):
    """Read / write bus errors at the first / middle / last / only beat: codes 8 / 9, ERROR_ADDR, BYTES_DONE prefix,
    no write after a read error, memory image of the beats that did complete."""
    prof = [("always", "always", "fixed:1"), ("random:0.5", "random:0.6", "uniform:1-4")]
    b = Bench(dut, seed_of())
    await b.start()
    cases = [1, 2, SB - 1 if SB > 2 else 2, SB, SB + 1, 2 * SB + 1, 8 * SB, 8 * SB - 1]
    for (rq, rs, lat) in prof:
        b.set_stalls(rq, rs, lat)
        for ln in cases:
            nb = S.num_beats(ln, SB)
            positions = sorted({0, nb // 2, nb - 1})
            for kind in ("read", "write"):
                for k in positions:
                    src, dst = SRC0 + 0x40, DST0 + 0x40
                    if kind == "read":
                        b.inject(rd=[src + k * SB])
                    else:
                        b.inject(wr=[dst + k * SB])
                    await b.copy(src, dst, ln)
                    b.expect_outcome(S.E_READ_BUS if kind == "read" else S.E_WRITE_BUS, k * SB, (src if kind == "read" else dst) + k * SB)
                    await read_outcome_regs(b)
                    b.inject()
                    # the next, error-free transfer must clear the error state (START clears DONE/ERROR/ERROR_CODE)
                    await b.copy(src, dst, SB)
                    b.expect_outcome(S.E_NONE, SB)
                    await read_outcome_regs(b)
    # bus errors in a maximum-length transfer (middle beat)
    b.set_stalls("random:0.8", "random:0.8", "uniform:1-2")
    nbm = S.num_beats(MAXLEN, SB)
    for kind in ("read", "write"):
        b.inject(rd=[SRC0 + (nbm // 2) * SB] if kind == "read" else [], wr=[DST0 + (nbm // 2) * SB] if kind == "write" else [])
        await b.copy(SRC0, DST0, MAXLEN, max_cycles=40000)
        b.expect_outcome(S.E_READ_BUS if kind == "read" else S.E_WRITE_BUS, (nbm // 2) * SB)
    b.inject()
    # several errors in one transfer: the first one in beat order is reported
    b.set_stalls("random:0.7", "random:0.7", "uniform:1-3")
    src, dst = SRC0, DST0
    b.inject(rd=[src + 5 * SB, src + 6 * SB], wr=[dst + 2 * SB])
    await b.copy(src, dst, 8 * SB)
    o = b.obs.outcomes[-1]
    assert o[0] in (S.E_WRITE_BUS, S.E_READ_BUS), o
    await read_outcome_regs(b)
    b.inject(rd=[src + 1 * SB, src + 2 * SB, src + 3 * SB])
    await b.copy(src, dst, 8 * SB)
    b.expect_outcome(S.E_READ_BUS, SB, src + SB)
    b.inject(wr=[dst + k * SB for k in range(8)])
    await b.copy(src, dst, 8 * SB)
    b.expect_outcome(S.E_WRITE_BUS, 0, dst)
    # error on the very first word read with an unmapped-looking range
    b.inject()
    b.policy.rd_ranges.append((SRC0, SRC0 + 0x1000))
    await b.copy(SRC0, DST0, 3 * SB)
    b.expect_outcome(S.E_READ_BUS, 0, SRC0)
    b.policy.clear()
    b.policy.wr_ranges.append((DST0, DST0 + 0x1000))
    await b.copy(SRC0, DST0, 3 * SB)
    b.expect_outcome(S.E_WRITE_BUS, 0, DST0)
    b.policy.clear()
    b.finish("bus_errors")


@cocotb.test()
async def abort_sweep(dut):
    """ABORT written d cycles after START for every d across the first beats (every engine state), plus races
    with the last beat, abort while idle, START|ABORT idle and START|ABORT while busy (refused, does not abort)."""
    b = Bench(dut, seed_of())
    await b.start()
    nb = 6
    ln = nb * SB - 1  # partial tail
    seen = {"aborted": 0, "done": 0}
    for lat in ("fixed:1", "uniform:1-3"):
        b.set_stalls("always" if lat == "fixed:1" else "random:0.7", "always" if lat == "fixed:1" else "random:0.7", lat)
        for d in range(0, 6 * nb + 8):
            await b.program(SRC0, DST0, ln)
            b.trig.when(lambda d=d: b.obs.since_start == d, lambda: b.rb.write_op(S.CONTROL, S.CTRL_ABORT))
            await b.go()
            await b.wait_idle()
            b.trig.clear()
            o = b.obs.outcomes[-1]
            seen["aborted" if o[0] == S.E_ABORTED else "done"] += 1
            await read_outcome_regs(b)
            # a following transfer is unaffected by the earlier abort (flags cleared, no stale abort request)
            if d % 5 == 0:
                await b.copy(SRC0, DST0 + 0x400, SB + 1)
                b.expect_outcome(S.E_NONE, SB + 1)
    assert seen["aborted"] > 5 and seen["done"] > 0, seen
    # abort on the shortest transfers (1 byte, one word + 1) and on a maximum-length transfer
    b.set_stalls("always", "always", "fixed:1")
    for ln, offs in ((1, range(0, 12)), (SB, range(0, 14)), (SB + 1, range(0, 18)), (MAXLEN, (3, 17, 40))):
        for d in offs:
            await b.program(SRC0, DST0, ln)
            b.trig.when(lambda d=d: b.obs.since_start == d, lambda: b.rb.write_op(S.CONTROL, S.CTRL_ABORT))
            await b.go()
            await b.wait_idle(20000)
            b.trig.clear()
    # abort races the final beat: once the final write has been accepted the transfer completes (DONE, not ABORTED)
    b.set_stalls("always", "always", "fixed:1")
    for d in range(0, 7):
        await b.program(SRC0, DST0, 2 * SB)
        b.trig.when(lambda d=d: b.obs.cnt["wr_acc"] == 2 and b.obs.last_req_edge + d == b.obs.last.n, lambda: b.rb.write_op(S.CONTROL, S.CTRL_ABORT))
        await b.go()
        await b.wait_idle()
        b.trig.clear()
        b.expect_outcome(S.E_NONE, 2 * SB)
    # abort when idle: no effect, nothing started, next transfer fine
    await b.wr(S.CONTROL, S.CTRL_ABORT)
    await b.wr(S.CONTROL, S.CTRL_ABORT)
    await b.env.cycles(4)
    await b.copy(SRC0, DST0, 2 * SB)
    b.expect_outcome(S.E_NONE, 2 * SB)
    # START|ABORT while idle starts the transfer normally (ABORT has no effect when idle)
    await b.program(SRC0, DST0, 3 * SB)
    await b.go(abort=True)
    await b.wait_idle()
    b.expect_outcome(S.E_NONE, 3 * SB)
    # START|ABORT while busy is refused as a whole: no abort
    b.set_stalls("random:0.5", "random:0.5", "uniform:1-3")
    await b.program(SRC0, DST0, nb * SB)
    b.trig.when(lambda: b.obs.since_start == 6, lambda: b.rb.write_op(S.CONTROL, S.CTRL_START | S.CTRL_ABORT))
    await b.go()
    await b.wait_idle()
    b.trig.clear()
    b.expect_outcome(S.E_NONE, nb * SB)
    # abort with a bus error in flight: the bus error is the cause
    b.inject(rd=[SRC0 + 2 * SB])
    await b.program(SRC0, DST0, nb * SB)
    b.trig.when(lambda: b.obs.cnt["rd_acc"] == 3, lambda: b.rb.write_op(S.CONTROL, S.CTRL_ABORT))
    await b.go()
    await b.wait_idle()
    b.trig.clear()
    b.inject()
    # abort with a write error in flight: the bus error is the cause (or the abort, if the abort took effect first)
    b.inject(wr=[DST0])
    await b.program(SRC0, DST0, nb * SB)
    b.trig.when(lambda: b.obs.cnt["wr_acc"] == 1, lambda: b.rb.write_op(S.CONTROL, S.CTRL_ABORT))
    await b.go()
    await b.wait_idle()
    b.trig.clear()
    b.inject()
    # abort on an invalid descriptor keeps the validation code
    await b.program(SRC0, DST0, 0)
    b.trig.when(lambda: b.obs.since_start == 0, lambda: b.rb.write_op(S.CONTROL, S.CTRL_ABORT))
    await b.go()
    await b.wait_idle()
    b.trig.clear()
    b.expect_outcome(S.E_ZERO_LENGTH, 0)
    b.finish("abort_sweep", **seen)


@cocotb.test()
async def busy_and_terminal_edge(dut):
    """Register writes landing on and around the cycle in which BUSY falls: refused while busy, accepted after;
    INT_STATUS write-one-to-clear on the very edge of the completion event (set wins); START exactly when BUSY falls."""
    b = Bench(dut, seed_of())
    await b.start()
    b.set_stalls("always", "always", "fixed:1")
    nb = 2
    for what in ("w1c_done", "w1c_err", "start", "src", "ctrl_abort"):
        for d in range(0, 9):
            err = what == "w1c_err"
            if err:
                b.inject(rd=[SRC0 + SB])
            await b.program(SRC0, DST0, nb * SB, ie=3)
            if what.startswith("w1c"):
                act = lambda: b.rb.write_op(S.INT_STATUS, 0x3)
            elif what == "start":
                act = lambda: b.rb.write_op(S.CONTROL, S.CTRL_START)
            elif what == "src":
                act = lambda: b.rb.write_op(S.SRC_ADDR, SRC0)
            else:
                act = lambda: b.rb.write_op(S.CONTROL, S.CTRL_ABORT)
            if err:
                b.trig.when(lambda d=d: b.obs.cnt["rd_acc"] == 2 and b.obs.last_req_edge + d == b.obs.last.n, act)
            else:
                b.trig.when(lambda d=d: b.obs.cnt["wr_acc"] == nb and b.obs.last_req_edge + d == b.obs.last.n, act)
            await b.go()
            await b.wait_idle()
            await b.env.cycles(4)
            await b.wait_idle()  # a START that landed after the first transfer ended runs a second one
            b.trig.clear()
            b.inject()
            await b.rd(S.INT_STATUS)
            await b.rd(S.STATUS)
            await b.wr(S.INT_STATUS, 3)
            await b.wr(S.INT_ENABLE, 0)
        await b.wr(S.INT_STATUS, 3)
    b.finish("busy_and_terminal_edge")


@cocotb.test()
async def back_to_back(dut):
    """Consecutive transfers without gaps, START as soon as BUSY is seen low, flags cleared by every START."""
    b = Bench(dut, seed_of(), req_thr="random:0.9", rsp_thr="random:0.9", latency="uniform:1-2")
    await b.start()
    await b.program(SRC0, DST0, 5 * SB + 1)
    for i in range(8):
        await b.go()
        # poll STATUS back-to-back; START the next transfer on the first cycle BUSY reads 0
        for _ in range(4000):
            st = await b.rd(S.STATUS)
            if not st & S.ST_BUSY:
                break
        else:
            raise AlbionCheckError("transfer %d never finished" % i)
        assert st & S.ST_DONE and not st & S.ST_ERROR, "STATUS after completion = 0x%x" % st
    # alternate error / ok transfers back to back
    for i in range(6):
        b.inject(rd=[SRC0 + 2 * SB] if i % 2 == 0 else [])
        await b.go()
        await b.wait_idle()
        st = await b.rd(S.STATUS)
        assert bool(st & S.ST_ERROR) == (i % 2 == 0) and bool(st & S.ST_DONE) == (i % 2 == 1), (i, hex(st))
    b.inject()
    b.finish("back_to_back")


@cocotb.test()
async def backpressure(dut):
    """Long request-ready stalls (> 32 cycles) and slow / stalled responses; stall counters, protocol rules."""
    b = Bench(dut, seed_of())
    await b.start()
    for req, rsp, lat in (("pattern:" + "0" * 44 + "1", "always", "fixed:1"), ("bursty:20-40", "always", "fixed:1"), ("always", "bursty:15-35", "fixed:2"), ("bursty:1-3", "bursty:1-3", "tail:1,0.2,12"), ("pattern:0001", "pattern:001", "fixed:3")):
        b.set_stalls(req, rsp, lat)
        for ln in (SB, 4 * SB + 3, 9 * SB):
            await b.copy(SRC0, DST0, ln, max_cycles=80000)
            b.expect_outcome(S.E_NONE, ln)
            await b.rd(S.STALL_CYCLES) if CFG.perf else None
            await b.rd(S.ACTIVE_CYCLES) if CFG.perf else None
    assert b.obs.max_req_stall >= 33, "backpressure never exceeded 32 cycles (%d)" % b.obs.max_req_stall
    b.finish("backpressure")
