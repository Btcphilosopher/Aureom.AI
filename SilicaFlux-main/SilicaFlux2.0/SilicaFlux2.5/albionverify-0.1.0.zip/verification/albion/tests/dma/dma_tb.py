"""Shared AlbionVerify bench for ``silicaflux_dma`` (all ENGINE / DUAL_PORT / DW configurations).

  DmaObserver   pin-level monitor + scoreboard: turns every edge into an ``Edge`` record for the independent
                reference model (albionverify.models.dma_model), runs the byte-exact memory image checks at the end
                of every transfer, samples functional coverage and exposes immediate events to ``Triggers``.
  Bench         builder: Env + ResetSequencer + RegBusMaster + SFB2 slave memories (random latency / stalls /
                error injection) + SFB2 protocol monitors + observer, and the stimulus helpers the tests use.

Everything the DMA does is checked on the fly (fail-fast); tests only *stimulate*.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from albionverify.bus.regbus import RegBusMaster
from albionverify.bus.reqrsp import ReqRspMonitor, ReqRspSlave, sfb_port
from albionverify.core import Agent, AlbionCheckError, Env
from albionverify.coverage import CoverGroup
from albionverify.inject import ErrorPolicy
from albionverify.memory import BackingStore
from albionverify.models import dma_spec as S
from albionverify.models.dma_model import BusReq, BusRsp, DmaConfig, DmaModel, DmaModelError, Edge, RegAcc
from albionverify.reset import ResetSequencer

P = json.loads(os.environ.get("ALBION_PARAMS", "{}"))
CFG = DmaConfig.from_params(P)
DW = P.get("DW", 32)
SB = DW // 8
NP = CFG.nports
MAXLEN = 1 << CFG.max_len_log2
TOP = 1 << 32
NEVER = -(10 ** 9)


# --------------------------------------------------------------------------------------------- memory + error injection
def pattern_init(seed: int):
    """Deterministic, address-dependent initial memory content (no two neighbouring words alike)."""
    k = (seed * 0x9E3779B1 + 0x1234567) & 0xFFFFFFFF

    def f(a: int) -> int:
        x = (a * 2654435761 + k) & 0xFFFFFFFF
        x ^= x >> 15
        x = (x * 2246822519) & 0xFFFFFFFF
        x ^= x >> 13
        return x & 0xFF

    return f


class AddrErrors(ErrorPolicy):
    """Bus-error injection by word address and direction (a stimulus decision, never an expectation)."""

    name = "addr-set"

    def __init__(self, sb: int):
        self.sb = sb
        self.rd = set()
        self.wr = set()
        self.rd_ranges: List[Tuple[int, int]] = []
        self.wr_ranges: List[Tuple[int, int]] = []

    def clear(self) -> None:
        self.rd.clear()
        self.wr.clear()
        self.rd_ranges.clear()
        self.wr_ranges.clear()

    def decide(self, req, index, cycle) -> bool:
        a = req.addr - (req.addr % self.sb)
        if req.write:
            return a in self.wr or any(lo <= a < hi for lo, hi in self.wr_ranges)
        return a in self.rd or any(lo <= a < hi for lo, hi in self.rd_ranges)


# --------------------------------------------------------------------------------------------- functional coverage
def length_class(n: int, sb: int = SB, mx: int = MAXLEN, burst_bytes: int = 0) -> str:
    if n == 0:
        return "zero"
    if n > mx + 1:
        return "gt_max_plus1"
    if n == mx + 1:
        return "max_plus1"
    if n == mx:
        return "max"
    if n == 1:
        return "one_byte"
    if n < sb:
        return "lt_word"
    if n == sb:
        return "one_word"
    if n == sb + 1:
        return "word_plus1"
    if burst_bytes > sb and n % burst_bytes == 0:
        return "burst_multiple"
    if burst_bytes > sb and n % burst_bytes == 1:
        return "burst_multiple_plus1"
    if n % sb == 0:
        return "multi_word_aligned"
    return "multi_word_partial"


def make_coverage() -> Dict[str, CoverGroup]:
    g: Dict[str, CoverGroup] = {}
    # ---- transaction types / descriptors
    x = CoverGroup("dma_descriptor", "descriptor classes presented at START")
    lens = ["zero", "one_byte", "lt_word", "one_word", "word_plus1", "multi_word_aligned", "multi_word_partial", "max", "max_plus1", "gt_max_plus1"]
    if CFG.buffered and CFG.burst * SB > SB and not CFG.dual:
        lens += ["burst_multiple", "burst_multiple_plus1"]
    x.point("length", lens)
    x.point("src_align", ["aligned", "misaligned"])
    x.point("dst_align", ["aligned", "misaligned"])
    x.point("range_rel", ["disjoint_src_lo", "disjoint_dst_lo", "adjacent", "overlap_partial", "same", "src_overflow", "dst_overflow", "ends_at_top"])
    x.point("outcome", ["DONE", "ZERO_LENGTH", "LENGTH", "SRC_ALIGN", "DST_ALIGN", "SRC_OVERFLOW", "DST_OVERFLOW", "OVERLAP", "READ_BUS", "WRITE_BUS", "ABORTED"])
    def len_outcome_impossible(b):
        ln, oc = b
        invalid_len = ln in ("zero", "max_plus1", "gt_max_plus1")
        if oc == "ZERO_LENGTH":
            return ln != "zero"
        if oc == "LENGTH":
            return ln not in ("max_plus1", "gt_max_plus1")
        if ln == "zero" or (ln in ("max_plus1", "gt_max_plus1")):
            return True  # a zero / over-long length always ends with ZERO_LENGTH / LENGTH
        if oc in ("SRC_OVERFLOW", "DST_OVERFLOW"):
            return ln in ("one_byte", "lt_word", "one_word")  # an aligned range of <= 1 word cannot cross 2^32
        return False

    x.cross("len_x_outcome", ["length", "outcome"], ignore=len_outcome_impossible)
    g[x.name] = x
    # ---- error states
    x = CoverGroup("dma_bus_error", "bus error position (kind x beat position), per engine")
    x.point("kind", ["read", "write"])
    x.point("beat_pos", ["only_beat", "first_beat", "middle_beat", "last_beat"])
    x.point("later_writes_done", ["none", "some"] if (CFG.buffered and CFG.out_limit > 1) else ["none"])
    x.cross("kind_x_pos", ["kind", "beat_pos"], ignore=lambda b: False)
    g[x.name] = x
    # ---- abort timing
    x = CoverGroup("dma_abort", "ABORT timing relative to the engine/bus state, with outcome")
    x.point("when", ["idle_no_effect", "start_abort_idle", "validate", "read_presented", "read_outstanding", "write_presented", "write_outstanding", "between_phases", "same_edge_as_response", "refused_start_abort_busy"])
    x.point("outcome", ["DONE", "ABORTED", "READ_BUS", "WRITE_BUS", "VALIDATION"])
    g[x.name] = x
    # ---- register file
    x = CoverGroup("dma_registers", "every register x access x busy state x bus-error outcome (impossible combinations excluded)")
    x.point("reg", list(S.ALL_REGS) + ["unmapped"])
    x.point("op", ["read", "write"])
    x.point("busy", ["idle", "busy"])
    x.point("err", ["ok", "error"])
    cfg_regs = {str(S.SRC_ADDR), str(S.DST_ADDR), str(S.LENGTH)}
    ro_regs = {str(a) for a in (S.STATUS, S.BYTES_DONE, S.ERROR_CODE, S.ERROR_ADDR, S.INFO, S.ID)}
    perf = {str(a) for a in S.PERF_REGS}

    def impossible(b):
        reg, op, busy, err = b
        if reg == "unmapped":
            return err == "ok"
        if reg in perf:
            return (err == "error") != (op == "write" or CFG.perf == 0)
        if reg in ro_regs:
            return (err == "error") != (op == "write")
        if reg in cfg_regs:
            return (err == "error") != (op == "write" and busy == "busy")
        if reg == str(S.CONTROL):
            return op == "read" and err == "error" or (op == "write" and busy == "idle" and err == "error")
        return err == "error"  # INT_ENABLE / INT_STATUS never fail

    x.cross("reg_op_busy_err", ["reg", "op", "busy", "err"], ignore=impossible)
    g[x.name] = x
    # ---- interrupts
    x = CoverGroup("dma_interrupts", "INT_STATUS events, enables, clears")
    x.point("event", ["done", "error"])
    x.point("enable", ["none", "done_only", "error_only", "both"])
    x.point("irq_level", ["low", "high"])
    x.point("w1c", ["clear_pending", "clear_same_edge_as_event", "clear_when_clear"])
    g[x.name] = x
    # ---- backpressure / latency
    x = CoverGroup("dma_backpressure", "request stall duration seen by the DMA, response stall duration")
    x.point("req_stall", {"0": 0, "1": 1, "2_3": (2, 3), "4_8": (4, 8), "9_32": (9, 32), "33_plus": (33, 10 ** 6)})
    x.point("rsp_latency", {"1": 1, "2_3": (2, 3), "4_8": (4, 8), "9_plus": (9, 10 ** 6)})
    x.point("kind", ["read", "write"])
    x.cross("req_stall_x_kind", ["req_stall", "kind"])
    g[x.name] = x
    # ---- concurrency / buffering
    x = CoverGroup("dma_concurrency", "outstanding depth, FIFO occupancy, phase and port concurrency")
    x.point("outstanding", list(range(1, CFG.out_limit + 1)))
    # single-port occupancy is bounded by BURST (read phases), dual-port by FIFO_DEPTH; the simple engine's pin must stay 0
    x.point("fifo_level", list(range(0, ((CFG.fifo_depth if CFG.dual else CFG.burst) if CFG.buffered else 0) + 1)))
    x.point("burst_run", list(range(1, CFG.burst + 1)) if (CFG.buffered and not CFG.dual) else [])
    x.point("rw_same_edge", ["yes"] if CFG.dual else [])
    g[x.name] = x
    # ---- reset
    x = CoverGroup("dma_reset", "reset while the engine is in each state")
    x.point("state", {S.STATE_NAMES[i]: i for i in range(8) if CFG.buffered is False or i not in (S.S_WAIT_READ, S.S_WAIT_WRITE)})
    x.point("kind", ["sync", "async_midcycle"])
    g[x.name] = x
    # ---- performance regs
    x = CoverGroup("dma_perf", "performance registers observed with non-trivial values")
    x.point("reg", ["ACTIVE_CYCLES", "STALL_CYCLES", "TRANSFERS"] if CFG.perf else [])
    x.point("value", ["zero", "nonzero"] if CFG.perf else [])
    g[x.name] = x
    return g


# --------------------------------------------------------------------------------------------- observer / scoreboard
@dataclass
class Rec:
    n: int
    busy: bool
    irq: bool
    bd: int
    fl: int
    evd: bool
    reg: Optional[RegAcc]
    valid: Tuple[bool, ...]
    ready: Tuple[bool, ...]
    pres_write: Tuple[Optional[bool], ...]
    reqs: List[BusReq]
    rsps: List[BusRsp]
    raw_start: bool = False
    raw_abort: bool = False


class DmaObserver(Agent):
    PAD = 2 * SB

    def __init__(self, name: str, env: Env, mem: BackingStore, cov: Optional[Dict[str, CoverGroup]] = None):
        super().__init__(name)
        self.mem = mem
        self.model = DmaModel(CFG)
        self.cov = cov
        self.rb = {k: env.sig("rb_" + k) for k in ("sel", "we", "addr", "wdata", "rdata", "err")}
        self.ports = [sfb_port(env, "m_", p, flat=True, AW=32, DW=DW) for p in range(NP)]
        self.sig_busy = env.sig("busy")
        self.sig_irq = env.sig("irq")
        self.sig_bd = env.sig("bytes_done")
        self.sig_fl = env.sig("fifo_level")
        self.sig_evd = env.sig("ev_done")
        self.prev: Optional[Rec] = None
        self.last: Optional[Rec] = None
        self._since: List[Optional[int]] = [None] * NP
        self.n_started = 0
        self.n_terminal = 0
        self.outcomes: List[Tuple[int, int, int, int]] = []  # (code, addr, bytes_done, done)
        self.n_checks = 0
        self.n_edges = 0
        self.snap: Optional[dict] = None
        self.last_xf = None
        self.since_start = NEVER  # cycles since the last START (NEVER while no transfer runs: triggers must not fire early)
        self.cnt = {"rd_acc": 0, "wr_acc": 0, "rsp": 0}
        self.last_req_edge = -1
        self.last_start_edge = -1
        self.last_rsp_edge = -1
        self._abort_when: Optional[str] = None
        self.max_out_seen = 0
        self.max_fifo_seen = 0
        self.reset_count = 0
        self.imaged = 0
        self.disable_image = False
        self.async_reset = False
        self.abort_when: Optional[str] = None
        self._stall_run = [0] * NP
        self._rsp_wait = [0] * NP
        self._rsp_stall_run = [0] * NP
        self._acc_edge: List[List[int]] = [[] for _ in range(NP)]  # accept edges of outstanding requests per port (for latency)
        self.max_req_stall = 0
        self.model_events: List[str] = []

    # ------------------------------------------------------------------ collection (pre-edge pins)
    def _collect(self) -> Rec:
        env = self.env
        n = env.cycle
        rb = self.rb
        sel = rb["sel"].read()
        reg = None
        raw_start = raw_abort = False
        busy = bool(self.sig_busy.read())
        if sel:
            reg = RegAcc(bool(rb["we"].read()), rb["addr"].read(), rb["wdata"].read(), rb["rdata"].read(), bool(rb["err"].read()))
            if reg.write and reg.addr == S.CONTROL and not reg.err:
                raw_start = bool(reg.wdata & S.CTRL_START) and not busy
                raw_abort = bool(reg.wdata & S.CTRL_ABORT) and busy
        elif rb["err"].read():
            env.error("rb_err asserted while rb_sel=0 (the register page must answer only to a selected access)")
        valid, ready, pw, reqs, rsps = [], [], [], [], []
        for p, port in enumerate(self.ports):
            v, r = bool(port["valid"].read()), bool(port["ready"].read())
            valid.append(v)
            ready.append(r)
            wr = bool(port["write"].read()) if v else None
            pw.append(wr)
            if v and self._since[p] is None:
                self._since[p] = n
            if v and r:
                reqs.append(BusReq(p, wr, port["addr"].read(), port["wdata"].read() if wr else 0, port["strb"].read(), self._since[p]))
                self._since[p] = None
            if not v:
                self._since[p] = None
            if port["rvalid"].read():
                if not port["rready"].read():
                    env.error("m_rsp_ready[%d]=0 while a response is valid (DMA.md sec. 4/5: rsp_ready is 1 whenever a response can arrive)" % p)
                rsps.append(BusRsp(p, port["rdata"].read(), bool(port["err"].read())))
        return Rec(n, busy, bool(self.sig_irq.read()), self.sig_bd.read(), self.sig_fl.read(), bool(self.sig_evd.read()), reg,
                   tuple(valid), tuple(ready), tuple(pw), reqs, rsps, raw_start, raw_abort)

    # ------------------------------------------------------------------ agent API
    def sample(self) -> None:
        env = self.env
        if env.in_reset:
            self._sample_in_reset()
            return
        rec = self._collect()
        self.last = rec
        self._events(rec)
        if self.prev is not None:
            self._process(self.prev, rec.busy)
        self.prev = rec

    def _sample_in_reset(self) -> None:
        """During reset the DMA must be quiet: no request, no busy, no irq."""
        env = self.env
        for p, port in enumerate(self.ports):
            if port["valid"].read():
                env.error("m_req_valid[%d] asserted while reset is active" % p)
        if self.sig_busy.read():
            env.error("busy asserted while reset is active")
        if self.sig_irq.read():
            env.error("irq asserted while reset is active")

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            if self.cov is not None and self.last is not None and self.prev is not None:
                self._cover_reset()
            self.flush(unknown_next=True)
            self._reset_image_check()
            self.model.reset()
            self.snap = None
            self.since_start = NEVER
            self._since = [None] * NP
            self.reset_count += 1
        self.prev = None

    def _cover_reset(self) -> None:
        m = self.model
        rec = self.prev
        if not m.active:
            st = S.S_IDLE
        else:
            xf = m.xfer
            quiet = not any(rec.valid) and xf.outstanding() == 0 and not rec.reqs and not rec.rsps
            if xf.valid and quiet and xf.complete:
                st = S.S_COMPLETE
            elif quiet and xf.stop_met() and not xf.complete and (xf.err_first is not None or xf.abort_edge is not None or not xf.valid) and rec.n > xf.start_edge + 1:
                st = S.S_ERROR
            else:
                sts = m._expected_states(Edge(rec.n, rec.busy, True, valid=rec.valid, pres_write=rec.pres_write))
                st = min(sts) if sts else S.S_IDLE
                if CFG.dual and st == S.S_ISSUE_READ and any(w for w in rec.pres_write if w):
                    st = S.S_ISSUE_WRITE  # dual port: either ISSUE state is legal; classify by the request being presented
        self.cov["dma_reset"].sample(state=st, kind="async_midcycle" if self.async_reset else "sync")
        self._abort_when = None

    def flush(self, unknown_next: bool = False) -> None:
        if self.prev is not None:
            self._process(self.prev, None)
            self.prev = None

    def finalize(self) -> None:
        self.flush()

    # ------------------------------------------------------------------ immediate event counters (for triggers)
    def _events(self, rec: Rec) -> None:
        if rec.raw_start:
            self.last_start_edge = rec.n
            self.since_start = 0
            for k in self.cnt:
                self.cnt[k] = 0
        else:
            self.since_start += 1
        for q in rec.reqs:
            self.cnt["wr_acc" if q.write else "rd_acc"] += 1
            self.last_req_edge = rec.n
        for s in rec.rsps:
            self.cnt["rsp"] += 1
            self.last_rsp_edge = rec.n

    # ------------------------------------------------------------------ processing (lagged by one edge)
    def _process(self, rec: Rec, busy_next: Optional[bool]) -> None:
        env = self.env
        m = self.model
        e = Edge(rec.n, rec.busy, busy_next, rec.irq, rec.bd, rec.fl, rec.evd, rec.reg, rec.valid, rec.ready, rec.pres_write, rec.reqs, rec.rsps)
        was_active = m.active
        xf = m.xfer
        before = (m.err_f, m.done_f)
        self.n_edges += 1
        self.n_checks += 1 + (1 if rec.reg else 0) + len(rec.reqs) + len(rec.rsps)
        try:
            m.edge(e)
        except DmaModelError as ex:
            env.error("DMA reference model: %s" % ex)
        # coverage: register accesses, stalls, outstanding
        if self.cov is not None:
            self._cover_edge(rec, e, was_active, xf)
        if self.cov is not None and was_active and not m.active and rec.reg is not None and rec.reg.write and rec.reg.addr == S.INT_STATUS and not rec.reg.err:
            self.cov["dma_interrupts"].sample(w1c="clear_same_edge_as_event")
        if m.active and not was_active:
            self._on_start(rec)
        if was_active and not m.active:
            self._on_terminal(rec, xf)

    # ------------------------------------------------------------------ start / terminal hooks
    def _on_start(self, rec: Rec) -> None:
        m = self.model
        xf = m.xfer
        self.n_started += 1
        self.last_xf = xf
        self.snap = None
        if xf.valid:
            lo = max(0, xf.dst - self.PAD)
            hi = xf.dst + xf.n * SB + self.PAD
            self.snap = {"src": self.mem.snapshot(xf.src, xf.n * SB), "dst_lo": lo, "dst": self.mem.snapshot(lo, hi - lo), "src_addr": xf.src}
        if self.cov is not None:
            c = self.cov["dma_descriptor"]
            bb = CFG.burst * SB if (CFG.buffered and not CFG.dual) else 0
            ln = xf.length
            rel = self._rel(xf.src, xf.dst, ln)
            c.sample(length=length_class(ln, burst_bytes=bb) if length_class(ln, burst_bytes=bb) in c.points["length"].spec else length_class(ln),
                     src_align="aligned" if xf.src % SB == 0 else "misaligned", dst_align="aligned" if xf.dst % SB == 0 else "misaligned", range_rel=rel)

    @staticmethod
    def _rel(src: int, dst: int, ln: int) -> str:
        if src + ln > TOP:
            return "src_overflow"
        if dst + ln > TOP:
            return "dst_overflow"
        if src == dst:
            return "same"
        if src < dst + ln and dst < src + ln:
            return "overlap_partial"
        if src + ln == dst or dst + ln == src:
            return "adjacent"
        if src + ln == TOP or dst + ln == TOP:
            return "ends_at_top"
        return "disjoint_src_lo" if src < dst else "disjoint_dst_lo"

    def _on_terminal(self, rec: Rec, xf) -> None:
        m = self.model
        o = m.last_outcome
        self.n_terminal += 1
        self.outcomes.append((o.code, o.addr, o.bytes_done, 1 if o.done else 0))
        self.env.digest.event("dma.term", rec.n, int(o.done), o.code, o.addr, o.bytes_done)
        if xf.valid and not self.disable_image:
            self._image_check(xf, uncertain=False)
        self.snap = None
        if rec.n > self.last_start_edge:  # (a START on the first idle cycle has already restarted the count)
            self.since_start = NEVER
        if self.cov is not None:
            self._cover_terminal(xf, o)

    # ------------------------------------------------------------------ byte-exact memory image checks
    def _image_check(self, xf, uncertain: bool) -> None:
        """Destination image == pre-transfer image except for the bytes of the beats whose write was acknowledged OK
        (then == the pre-transfer source bytes); the source and every byte around the destination (incl. the bytes
        after LENGTH inside the last word) are unchanged.  With ``uncertain`` (reset), beats whose write was accepted
        but not acknowledged may be either old or new."""
        snap = self.snap
        if snap is None:
            return
        env = self.env
        mem = self.mem
        self.imaged += 1
        sb = SB
        lo = snap["dst_lo"]
        old = snap["dst"]
        exp = bytearray(old)
        alt = {}
        for k in range(xf.n):
            st = xf.wstate.get(k)
            if st not in ("ok", "pending"):
                continue
            b = xf.plan[k]
            for i in range(b.nbytes):
                a = b.dst_addr + i
                new = snap["src"][k * sb + i]
                if st == "ok":
                    exp[a - lo] = new
                else:
                    alt[a] = (old[a - lo], new)
        got = mem.snapshot(lo, len(exp))
        for i in range(len(exp)):
            a = lo + i
            if got[i] != exp[i] and not (a in alt and got[i] in alt[a]):
                k = (a - xf.dst) // sb if a >= xf.dst else -1
                env.error("memory image mismatch at 0x%08x (dst beat %d, byte %d): got 0x%02x expected 0x%02x (pre-transfer 0x%02x, src 0x%02x)%s" % (
                    a, k, (a - xf.dst) % sb if a >= xf.dst else -1, got[i], exp[i], old[i], snap["src"][i - (xf.dst - lo)] if 0 <= i - (xf.dst - lo) < len(snap["src"]) else 0,
                    " (transfer length %d src 0x%08x dst 0x%08x)" % (xf.length, xf.src, xf.dst)))
            elif a in alt and got[i] != exp[i]:
                pass
        got_src = mem.snapshot(xf.src, xf.n * sb)
        if got_src != snap["src"]:
            bad = next(i for i in range(len(got_src)) if got_src[i] != snap["src"][i])
            env.error("source memory modified at 0x%08x (the DMA must never write its source)" % (xf.src + bad))

    def _reset_image_check(self) -> None:
        m = self.model
        xf = m.xfer if m.active else None
        if xf is not None and xf.valid and self.snap is not None and not self.disable_image:
            self._image_check(xf, uncertain=True)
        self.snap = None

    # ------------------------------------------------------------------ functional coverage
    def _cover_edge(self, rec: Rec, e: Edge, was_active: bool, xf) -> None:
        cv = self.cov
        m = self.model
        if rec.reg is not None:
            a = rec.reg.addr if rec.reg.addr in S.ALL_REGS else "unmapped"
            cv["dma_registers"].sample(reg=a, op="write" if rec.reg.write else "read", busy="busy" if was_active else "idle", err="error" if rec.reg.err else "ok")
            if not rec.reg.write and rec.reg.addr in S.PERF_REGS and not rec.reg.err:
                cv["dma_perf"].sample(reg=S.REG_NAMES[rec.reg.addr], value="nonzero" if rec.reg.rdata else "zero")
        if xf is not None:
            for p in range(NP):
                if rec.valid[p] and not rec.ready[p]:
                    self._stall_run[p] += 1
            for q in rec.reqs:
                st = self._stall_run[q.port]
                self.max_req_stall = max(self.max_req_stall, st)
                cv["dma_backpressure"].sample(req_stall=st, kind="write" if q.write else "read")
                self._stall_run[q.port] = 0
                self._acc_edge[q.port].append(rec.n)
            for r in rec.rsps:
                acc = self._acc_edge[r.port].pop(0) if self._acc_edge[r.port] else rec.n - 1
                cv["dma_backpressure"].sample(rsp_latency=max(1, rec.n - acc))
            n_out = sum(len(qq) for qq in xf.out)
            if n_out:
                cv["dma_concurrency"].sample(outstanding=max(len(qq) for qq in xf.out))
            cv["dma_concurrency"].sample(fifo_level=min(rec.fl, CFG.fifo_depth))
            if CFG.buffered:
                if not CFG.dual:
                    cv["dma_concurrency"].sample(burst_run=xf.run_len if 1 <= xf.run_len <= CFG.burst else None) if xf.run_len else None
                if CFG.dual and any(not q.write for q in rec.reqs) and any(q.write for q in rec.reqs):
                    cv["dma_concurrency"].sample(rw_same_edge="yes")
        if rec.reg is not None and rec.reg.write and rec.reg.addr == S.INT_STATUS and not rec.reg.err:
            cv["dma_interrupts"].sample(w1c="clear_pending" if m.ist else "clear_when_clear")
        if rec.reg is not None and rec.reg.write and rec.reg.addr == S.CONTROL and (rec.reg.wdata & S.CTRL_ABORT):
            self._classify_abort(rec, was_active, xf)

    def _classify_abort(self, rec: Rec, was_active: bool, xf) -> None:
        cv = self.cov["dma_abort"]
        d = rec.reg.wdata
        if not was_active:
            cv.sample(when="start_abort_idle" if d & S.CTRL_START else "idle_no_effect")
            return
        if rec.reg.err:
            cv.sample(when="refused_start_abort_busy")
            return
        if rec.rsps:
            self._abort_when = "same_edge_as_response"
        elif not xf.valid or rec.n == xf.start_edge + 1:
            self._abort_when = "validate"
        elif any(rec.valid):
            self._abort_when = "write_presented" if rec.pres_write[0] or (CFG.dual and rec.valid[1]) else "read_presented"
        elif xf.outstanding():
            self._abort_when = "write_outstanding" if any(w for q in xf.out for (w, _, _) in q) else "read_outstanding"
        else:
            self._abort_when = "between_phases"

    def _cover_terminal(self, xf, o) -> None:
        cv = self.cov
        name = "DONE" if o.done else S.ERROR_NAMES[o.code]
        d = cv["dma_descriptor"]
        bb = CFG.burst * SB if (CFG.buffered and not CFG.dual) else 0
        lc = length_class(xf.length, burst_bytes=bb)
        if lc not in d.points["length"].spec:
            lc = length_class(xf.length)
        d.sample(length=lc, outcome=name)
        if xf.valid and xf.err_first is not None:
            kind, beat = xf.err_first[1], xf.err_first[2]
            pos = "only_beat" if xf.n == 1 else ("first_beat" if beat == 0 else ("last_beat" if beat == xf.n - 1 else "middle_beat"))
            later = "some" if any(xf.wstate.get(j) == "ok" for j in range(beat + 1, xf.n)) else "none"
            cv["dma_bus_error"].sample(kind="read" if kind == "R" else "write", beat_pos=pos, later_writes_done=later)
        if self._abort_when is not None:
            oc = "DONE" if o.done else ("VALIDATION" if not xf.valid else {S.E_ABORTED: "ABORTED", S.E_READ_BUS: "READ_BUS", S.E_WRITE_BUS: "WRITE_BUS"}.get(o.code, "VALIDATION"))
            cv["dma_abort"].sample(when=self._abort_when, outcome=oc)
            self._abort_when = None
        ie = self.model.ie
        en = {0: "none", 1: "done_only", 2: "error_only", 3: "both"}[ie]
        cv["dma_interrupts"].sample(event="done" if o.done else "error", enable=en, irq_level="high" if self.model.irq else "low")

    def summary(self) -> dict:
        return {"edges": self.n_edges, "transfers_started": self.n_started, "transfers_ended": self.n_terminal, "checks": self.n_checks,
                "images_checked": self.imaged, "max_req_stall": self.max_req_stall, "resets": self.reset_count}


# --------------------------------------------------------------------------------------------- triggers
class Triggers(Agent):
    """Run an action (usually queueing a register op) in the drive phase of the cycle in which a predicate over
    the observer's immediate events first holds.  Registered after the observer and before the register master,
    so a queued op is presented in the very next cycle."""

    def __init__(self, name: str = "triggers"):
        super().__init__(name)
        self.items: List[list] = []
        self.fired = 0

    def when(self, pred: Callable[[], bool], action: Callable[[], None], once: bool = True) -> None:
        self.items.append([pred, action, once])

    def clear(self) -> None:
        self.items.clear()

    def drive(self) -> None:
        if self.env.in_reset:
            return
        for it in list(self.items):
            if it[0]():
                it[1]()
                self.fired += 1
                if it[2]:
                    self.items.remove(it)


# --------------------------------------------------------------------------------------------- bench
class Bench:
    def __init__(self, dut, seed: int, *, name: str = "dma", rb_gap: str = "always", req_thr: str = "always", rsp_thr: str = "always",
                 latency: str = "fixed:1", mem_seed: Optional[int] = None, monitors: bool = True, coverage: bool = True, rb_garbage: bool = True):
        self.dut = dut
        self.seed = seed
        env = self.env = Env(dut, name=name, seed=seed)
        self.cfg = CFG
        self.rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=4))
        self.mem = BackingStore(pattern_init(seed if mem_seed is None else mem_seed), "dmamem")
        self.policy = AddrErrors(SB)
        self.cov = make_coverage() if coverage else None
        if self.cov:
            env.coverage.extend(self.cov.values())
        self.slaves: List[ReqRspSlave] = []
        for p in range(NP):
            self.slaves.append(env.add(ReqRspSlave("mem%d" % p, sfb_port(env, "m_", p, flat=True, AW=32, DW=DW), memory=self.mem, nbytes=SB,
                                                   rng=env.seeds.child("slave%d" % p), req_throttle=req_thr, rsp_throttle=rsp_thr, latency=latency,
                                                   error_policy=self.policy, max_pending=max(4, CFG.out_limit + 2))))
        self.mons: List[ReqRspMonitor] = []
        if monitors:
            for p in range(NP):
                self.mons.append(env.add(ReqRspMonitor("mon%d" % p, sfb_port(env, "m_", p, flat=True, AW=32, DW=DW), nbytes=SB, outstanding_limit=CFG.out_limit)))
        self.obs: DmaObserver = env.add(DmaObserver("obs", env, self.mem, self.cov))
        self.trig: Triggers = env.add(Triggers())
        self.rb = env.add(RegBusMaster("rb", env, rng=env.seeds.child("rb"), gap=rb_gap, AW=12, DW=32, idle_garbage=rb_garbage))
        self.rng = env.seeds.child("test")
        self.sig_busy = env.sig("busy")
        self.noise: Optional[RegNoise] = None

    def add_noise(self, rate: float = 0.2, hammer: bool = True) -> "RegNoise":
        # registered before the register master so its ops are presented in the cycle after they are queued
        self.noise = RegNoise("noise", self, self.env.seeds.child("noise"), rate, hammer)
        self.env.agents.insert(self.env.agents.index(self.rb), self.noise)
        self.noise.attach(self.env)
        return self.noise

    # ---- lifecycle
    async def start(self) -> None:
        await self.env.start()
        await self.env.until(lambda: not self.rst.asserted, 50, "reset release")
        await self.env.cycles(1)

    def finish(self, test: str, **extra) -> None:
        self.obs.finalize()
        self.env.finalize()
        extra.setdefault("observer", self.obs.summary())
        extra.setdefault("monitors", [m.summary() for m in self.mons])
        extra.setdefault("model_transfers", self.obs.n_started)
        extra.setdefault("model_outcomes", len(self.obs.outcomes))
        self.env.write_result(test, **extra)

    # ---- throttles
    def set_stalls(self, req: Optional[str] = None, rsp: Optional[str] = None, latency: Optional[str] = None) -> None:
        from albionverify.rng import Latency

        for i, s in enumerate(self.slaves):
            if req is not None:
                s.req_thr.set_mode(req)
            if rsp is not None:
                s.rsp_thr.set_mode(rsp)
            if latency is not None:
                s.lat = Latency(self.env.seeds.child("lat%d" % i), latency)

    # ---- register helpers (all accesses are observed and checked by the observer)
    async def wr(self, addr: int, data: int):
        return await self.rb.write(addr, data & 0xFFFFFFFF)

    async def rd(self, addr: int) -> int:
        op = await self.rb.read(addr)
        return op.rdata

    async def program(self, src: int, dst: int, length: int, ie: Optional[int] = None):
        """Queue the descriptor writes back to back (one register access per cycle) and wait for the last one."""
        ops = []
        if ie is not None:
            ops.append(self.rb.write_op(S.INT_ENABLE, ie))
        ops.append(self.rb.write_op(S.SRC_ADDR, src))
        ops.append(self.rb.write_op(S.DST_ADDR, dst))
        ops.append(self.rb.write_op(S.LENGTH, length))
        await self.env.until(lambda: ops[-1].done, 1000, "descriptor programming")

    async def go(self, abort: bool = False):
        return await self.wr(S.CONTROL, S.CTRL_START | (S.CTRL_ABORT if abort else 0))

    async def wait_idle(self, max_cycles: int = 20000, what: str = "DMA to become idle") -> None:
        # let the START take effect (BUSY rises the cycle after the write), then wait for BUSY to fall
        await self.env.cycles(2)
        await self.env.until(lambda: not self.sig_busy.read(), max_cycles, what)
        await self.env.cycles(2)

    async def copy(self, src: int, dst: int, length: int, ie: Optional[int] = None, max_cycles: int = 20000):
        await self.program(src, dst, length, ie)
        await self.go()
        await self.wait_idle(max_cycles)
        return self.obs.outcomes[-1] if self.obs.outcomes else None

    def expect_outcome(self, code: int, bytes_done: Optional[int] = None, addr: Optional[int] = None) -> None:
        """Hand-written expectation of a directed test, cross-checking the reference model itself."""
        o = self.obs.outcomes[-1]
        if o[0] != code:
            raise AlbionCheckError("directed expectation: ERROR_CODE %s expected, the DMA/model finished with %s" % (S.ERROR_NAMES[code], S.ERROR_NAMES[o[0]]))
        if bytes_done is not None and o[2] != bytes_done:
            raise AlbionCheckError("directed expectation: BYTES_DONE %d expected, got %d" % (bytes_done, o[2]))
        if addr is not None and o[1] != addr:
            raise AlbionCheckError("directed expectation: ERROR_ADDR 0x%x expected, got 0x%x" % (addr, o[1]))

    # ---- memory / error helpers
    def inject(self, rd: Sequence[int] = (), wr: Sequence[int] = ()) -> None:
        self.policy.clear()
        self.policy.rd.update(a - a % SB for a in rd)
        self.policy.wr.update(a - a % SB for a in wr)

    def fill(self, base: int, n: int, seed: int = 0) -> None:
        """Poke deterministic data into the TB memory (a stimulus: the source image of the next transfer)."""
        r = self.env.seeds.child("fill%d_%x" % (seed, base))
        self.mem.write_bytes(base, bytes(r.getrandbits(8) for _ in range(n)))


# --------------------------------------------------------------------------------------------- register-bus noise
class RegNoise(Agent):
    """Background register traffic on the same bus as the test: reads of every register (incl. unmapped /
    absent-perf offsets), writes to read-only and unmapped offsets (must be refused), INT_ENABLE / INT_STATUS
    writes, and -- only while a long transfer is certain to still be running -- refused writes to SRC/DST/LENGTH/START.
    Everything is checked by the observer/model; this agent only creates traffic."""

    def __init__(self, name: str, bench: "Bench", rng, rate: float = 0.2, hammer: bool = True):
        super().__init__(name)
        self.b = bench
        self.rng = rng
        self.rate = rate
        self.hammer = hammer
        self.enabled = True
        self.n_ops = 0

    def drive(self) -> None:
        b = self.b
        env = self.env
        if env.in_reset or not self.enabled:
            return
        rb = b.rb
        if rb.cur is not None or rb.queue:
            return
        rng = self.rng
        if rng.random() > self.rate:
            return
        obs = b.obs
        m = obs.model
        r = rng.random()
        all_offs = list(S.ALL_REGS) + [0x03C, 0x040, 0x0FC, 0x100, 0x800, 0xFFC, 0x002, 0x00A, 0x011]
        if self.hammer and m.active and m.xfer is not None and m.xfer.valid and (m.xfer.n - m.xfer.n_ok_writes) >= 4 and r < 0.3:
            a = rng.choice([S.SRC_ADDR, S.DST_ADDR, S.LENGTH, S.CONTROL, S.CONTROL])
            d = rng.getrandbits(32)
            if a == S.CONTROL:
                d = S.CTRL_START | (rng.getrandbits(1) << 1) | (rng.getrandbits(30) << 2)
            rb.write_op(a, d)
        elif r < 0.6:
            rb.read_op(rng.choice(all_offs))
        elif r < 0.75:
            rb.write_op(rng.choice([S.STATUS, S.BYTES_DONE, S.ERROR_CODE, S.ERROR_ADDR, S.INFO, S.ID, S.ACTIVE_CYCLES, S.STALL_CYCLES, S.TRANSFERS, 0x03C, 0x040, 0xFFC, 0x00A]), rng.getrandbits(32))
        elif r < 0.85:
            rb.write_op(S.INT_ENABLE, rng.getrandbits(32))
        elif r < 0.93:
            rb.write_op(S.INT_STATUS, rng.getrandbits(32))
        else:
            rb.write_op(S.CONTROL, rng.getrandbits(32) & ~S.CTRL_START & ~S.CTRL_ABORT)  # neither START nor ABORT: no effect
        self.n_ops += 1
