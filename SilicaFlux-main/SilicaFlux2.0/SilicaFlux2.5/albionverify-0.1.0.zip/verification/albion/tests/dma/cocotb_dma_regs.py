"""Directed register-file / interrupt / busy-protection / performance-counter tests of silicaflux_dma.

All register values, refusals (rb_err), STATUS fields (BUSY/DONE/ERROR/ABORTED/STATE), INT_STATUS / irq and the
performance counters are predicted by the reference model and compared on every access; the tests create the
situations (and add a few hand-written asserts as a cross-check of the model itself).
"""
import os

import cocotb

from albionverify.bus.regbus import RegOp
from albionverify.core import AlbionCheckError
from dma.dma_tb import CFG, MAXLEN, SB, Bench, S

SRC0 = 0x10000000
DST0 = 0x20000000


def seed_of() -> int:
    return int(os.environ.get("ALBION_SEED", "1"))


@cocotb.test()
async def reset_values_and_access(dut):
    """Reset values of every register, INFO / ID, read-only / unmapped writes and reads (full 12-bit offset sweep),
    configuration register read-back, CONTROL without START/ABORT."""
    b = Bench(dut, seed_of(), rb_gap="random:0.6")
    await b.start()
    # reset state of every register (also sampled right after the initial reset)
    for a in S.ALL_REGS:
        v = await b.rd(a)
    assert await b.rd(S.ID) == S.ID_VALUE
    assert await b.rd(S.INFO) == CFG.info, "INFO"
    assert await b.rd(S.STATUS) == 0 and await b.rd(S.SRC_ADDR) == 0 and await b.rd(S.LENGTH) == 0
    # every word offset of the 4 KiB page: reads (mapped ones are checked against the model, the rest must error)
    for off in range(0, 0x1000, 4):
        await b.rd(off)
    # misaligned / odd offsets are unmapped
    for off in (0x001, 0x002, 0x003, 0x005, 0x00A, 0x00B, 0x011, 0x029, 0x039, 0x7FF, 0xFFF):
        await b.rd(off)
    # writes: read-only registers and every unmapped offset are refused and change nothing
    rng = b.rng
    ro = [S.STATUS, S.BYTES_DONE, S.ERROR_CODE, S.ERROR_ADDR, S.INFO, S.ID, S.ACTIVE_CYCLES, S.STALL_CYCLES, S.TRANSFERS]
    for a in ro:
        for d in (0, 0xFFFFFFFF, rng.getrandbits(32)):
            await b.wr(a, d)
    for off in list(range(0x03C, 0x1000, 4)) + [0x001, 0x002, 0x00A, 0x029, 0x7FF]:
        await b.wr(off, rng.getrandbits(32))
    for a in ro:
        await b.rd(a)  # unchanged
    assert await b.rd(S.ID) == S.ID_VALUE and await b.rd(S.INFO) == CFG.info
    # SRC / DST / LENGTH: full-width read-back (including values that are illegal descriptors)
    for a in (S.SRC_ADDR, S.DST_ADDR, S.LENGTH):
        for d in (0, 0xFFFFFFFF, 0x5A5A5A5A, 0xA5A5A5A5, 0x80000000, 1, rng.getrandbits(32)):
            await b.wr(a, d)
            assert await b.rd(a) == d, "%s read-back" % S.REG_NAMES[a]
    # the three registers are independent
    await b.wr(S.SRC_ADDR, 0x11111111)
    await b.wr(S.DST_ADDR, 0x22222222)
    await b.wr(S.LENGTH, 0x33333333)
    assert (await b.rd(S.SRC_ADDR), await b.rd(S.DST_ADDR), await b.rd(S.LENGTH)) == (0x11111111, 0x22222222, 0x33333333)
    # CONTROL: a write without START and ABORT does nothing; reads return 0 without error
    for d in (0, 0xFFFFFFFC, 0xFFFFFFF0, 0x80000000, 0x4):
        await b.wr(S.CONTROL, d)
    assert await b.rd(S.CONTROL) == 0
    await b.env.cycles(4)
    assert await b.rd(S.STATUS) == 0, "no transfer must have started"
    # INT_ENABLE keeps only bits [1:0]; INT_STATUS reads 0 and ignores writes of zero
    await b.wr(S.INT_ENABLE, 0xFFFFFFFF)
    assert await b.rd(S.INT_ENABLE) == 3
    await b.wr(S.INT_ENABLE, 0xFFFFFFFC)
    assert await b.rd(S.INT_ENABLE) == 0
    await b.wr(S.INT_ENABLE, 2)
    assert await b.rd(S.INT_ENABLE) == 2
    await b.wr(S.INT_STATUS, 0xFFFFFFFF)
    assert await b.rd(S.INT_STATUS) == 0
    # back-to-back register accesses on consecutive cycles (queue several at once)
    ops = [b.rb.read_op(a) for a in S.ALL_REGS] + [b.rb.write_op(S.SRC_ADDR, 0x1000), b.rb.read_op(S.SRC_ADDR), b.rb.write_op(S.STATUS, 1), b.rb.read_op(S.STATUS)]
    await b.env.until(lambda: ops[-1].done, 200, "back-to-back register accesses")
    assert ops[-3].rdata == 0x1000
    b.finish("reset_values_and_access")


@cocotb.test()
async def interrupts(dut):
    """INT_STATUS set by DONE / ERROR, write-one-to-clear, enables, level irq, persistence across START, set wins over clear."""
    b = Bench(dut, seed_of())
    await b.start()
    for ie in (0, 1, 2, 3):
        await b.wr(S.INT_STATUS, 3)
        # completion
        await b.copy(SRC0, DST0, 2 * SB + 1, ie=ie)
        b.expect_outcome(S.E_NONE)
        assert await b.rd(S.INT_STATUS) == 1
        assert b.obs.model.irq == bool(ie & 1)
        # a second completion keeps the (already set) bit; an error adds bit 1 without clearing bit 0
        await b.copy(SRC0, DST0, 0, ie=ie)
        b.expect_outcome(S.E_ZERO_LENGTH)
        assert await b.rd(S.INT_STATUS) == 3
        await b.env.cycles(2)
        assert b.obs.model.irq == bool(ie)
        # partial clears
        await b.wr(S.INT_STATUS, 0)  # writing zero clears nothing
        assert await b.rd(S.INT_STATUS) == 3
        await b.wr(S.INT_STATUS, 1)
        assert await b.rd(S.INT_STATUS) == 2
        await b.wr(S.INT_STATUS, 1)  # clearing an already clear bit
        assert await b.rd(S.INT_STATUS) == 2
        await b.wr(S.INT_STATUS, 2)
        assert await b.rd(S.INT_STATUS) == 0
        await b.env.cycles(2)
        assert not b.obs.model.irq
        # enabling after the event raises the level irq, disabling drops it
        await b.copy(SRC0, DST0, 1, ie=0)
        await b.wr(S.INT_ENABLE, 1)
        await b.env.cycles(3)
        assert b.obs.model.irq
        await b.wr(S.INT_ENABLE, 2)
        await b.env.cycles(3)
        assert not b.obs.model.irq
        await b.wr(S.INT_ENABLE, 0)
        await b.wr(S.INT_STATUS, 3)
    # bus error -> bit 1 only; abort -> bit 1
    b.inject(rd=[SRC0 + SB])
    await b.copy(SRC0, DST0, 3 * SB, ie=3)
    assert await b.rd(S.INT_STATUS) == 2
    await b.env.cycles(2)
    assert b.obs.model.irq
    b.inject()
    await b.wr(S.INT_STATUS, 2)
    b.set_stalls("random:0.6", "random:0.6", "uniform:1-3")
    await b.program(SRC0, DST0, 6 * SB)
    b.trig.when(lambda: b.obs.since_start == 7, lambda: b.rb.write_op(S.CONTROL, S.CTRL_ABORT))
    await b.go()
    await b.wait_idle()
    b.trig.clear()
    assert await b.rd(S.INT_STATUS) == 2
    await b.wr(S.INT_STATUS, 2)
    # INT_STATUS is not cleared by START
    await b.copy(SRC0, DST0, SB)
    assert await b.rd(S.INT_STATUS) == 1
    await b.copy(SRC0, DST0, SB)
    await b.copy(SRC0, DST0, 0)
    assert await b.rd(S.INT_STATUS) == 3
    await b.wr(S.INT_STATUS, 3)
    # clear landing exactly on the cycle of the event: the event wins (swept in cocotb_dma_xfer.busy_and_terminal_edge too)
    b.set_stalls("always", "always", "fixed:1")
    for d in range(0, 8):
        await b.program(SRC0, DST0, SB, ie=1)
        b.trig.when(lambda d=d: b.obs.cnt["wr_acc"] == 1 and b.obs.last_req_edge + d == b.obs.last.n, lambda: b.rb.write_op(S.INT_STATUS, 3))
        await b.go()
        await b.wait_idle()
        await b.env.cycles(3)
        b.trig.clear()
        await b.rd(S.INT_STATUS)
        await b.wr(S.INT_STATUS, 3)
    b.finish("interrupts")


@cocotb.test()
async def busy_protection(dut):
    """While BUSY: SRC / DST / LENGTH / START writes are refused (rb_err) and change nothing, the running transfer is
    untouched; INT_ENABLE / INT_STATUS writes and all reads stay legal; writes to read-only registers still fail."""
    b = Bench(dut, seed_of(), req_thr="random:0.5", rsp_thr="random:0.5", latency="uniform:1-3")
    await b.start()
    nb = 10
    await b.program(SRC0, DST0, nb * SB - 1)
    await b.go()
    await b.env.cycles(3)
    rng = b.rng
    refused = 0
    for _ in range(200):
        if not b.obs.model.active or (b.obs.model.xfer.n - b.obs.model.xfer.n_ok_writes) < 4:
            break
        a = rng.choice([S.SRC_ADDR, S.DST_ADDR, S.LENGTH, S.CONTROL, S.CONTROL, S.INT_ENABLE, S.INT_STATUS, S.STATUS, S.BYTES_DONE, S.ERROR_CODE])
        d = rng.getrandbits(32)
        if a == S.CONTROL:
            d = S.CTRL_START | (d & ~1)  # START (+ maybe ABORT): refused as a whole
            d &= ~S.CTRL_ABORT if rng.random() < 0.5 else 0xFFFFFFFF
        op = await b.rb.write(a, d)
        refused += 1 if op.err else 0
        await b.rd(rng.choice([S.SRC_ADDR, S.DST_ADDR, S.LENGTH, S.STATUS, S.BYTES_DONE, S.ACTIVE_CYCLES, S.STALL_CYCLES, S.TRANSFERS, S.INT_ENABLE]))
    assert refused >= 3, "the busy window was too short to exercise the protection (%d refusals)" % refused
    await b.wait_idle()
    b.expect_outcome(S.E_NONE, nb * SB - 1)  # not restarted, not reconfigured, not aborted
    assert await b.rd(S.SRC_ADDR) == SRC0 and await b.rd(S.DST_ADDR) == DST0 and await b.rd(S.LENGTH) == nb * SB - 1
    # after the transfer the same writes are accepted
    await b.wr(S.SRC_ADDR, SRC0 + SB)
    assert await b.rd(S.SRC_ADDR) == SRC0 + SB
    b.finish("busy_protection", refused=refused)


@cocotb.test()
async def status_poll(dut):
    """STATUS read on every cycle through every kind of outcome: BUSY falls on the same edge DONE / ERROR rises (never
    'not busy and no outcome'), ABORTED only with an abort, STATE follows the FSM, DONE / ERROR cleared by START."""
    b = Bench(dut, seed_of(), req_thr="random:0.7", rsp_thr="random:0.7", latency="uniform:1-2")
    await b.start()
    scenarios = []
    for i, (kind, ln) in enumerate([("ok", 3 * SB), ("ok", 1), ("zero", 0), ("long", MAXLEN + 1), ("overlap", 2 * SB), ("rd_err", 4 * SB), ("wr_err", 4 * SB), ("abort", 8 * SB), ("ok", 5 * SB + 2)]):
        src, dst = SRC0, DST0
        if kind == "overlap":
            dst = SRC0
        b.inject(rd=[src + SB] if kind == "rd_err" else [], wr=[dst + 2 * SB] if kind == "wr_err" else [])
        await b.program(src, dst, ln)
        if kind == "abort":
            # the ABORT overtakes the already queued STATUS polls
            b.trig.when(lambda: b.obs.since_start == 9, lambda: b.rb.queue.appendleft(RegOp(True, S.CONTROL, S.CTRL_ABORT)))
        ops = [b.rb.write_op(S.CONTROL, S.CTRL_START)]
        for _ in range(120):
            ops.append(b.rb.read_op(S.STATUS))
        await b.env.until(lambda: ops[-1].done, 2000, "status polling")
        b.trig.clear()
        sts = [o.rdata for o in ops[1:]]
        # BUSY never returns after it fell; DONE xor ERROR the moment BUSY is 0; first poll shows BUSY=1
        assert sts[0] & S.ST_BUSY, "first poll after START: BUSY=%d (STATUS 0x%x)" % (sts[0] & 1, sts[0])
        fell = next((j for j, v in enumerate(sts) if not v & S.ST_BUSY), None)
        assert fell is not None, "transfer %s still busy after 120 polls" % kind
        for v in sts[fell:]:
            assert not v & S.ST_BUSY and bool(v & S.ST_DONE) != bool(v & S.ST_ERROR), hex(v)
        for v in sts[:fell]:
            assert v & S.ST_BUSY and not v & (S.ST_DONE | S.ST_ERROR | S.ST_ABORTED), hex(v)
        if kind == "ok":
            assert sts[fell] & S.ST_DONE
        else:
            assert sts[fell] & S.ST_ERROR and not sts[fell] & S.ST_DONE
        assert bool(sts[fell] & S.ST_ABORTED) == (b.obs.outcomes[-1][0] == S.E_ABORTED)
        await b.rd(S.ERROR_CODE)
        await b.rd(S.BYTES_DONE)
    b.inject()
    b.finish("status_poll")


@cocotb.test()
async def perf_counters(dut):
    """ACTIVE_CYCLES / STALL_CYCLES / TRANSFERS (PERF=1) or bus errors (PERF=0)."""
    b = Bench(dut, seed_of())
    await b.start()
    if CFG.perf == 0:
        for a in (S.ACTIVE_CYCLES, S.STALL_CYCLES, S.TRANSFERS):
            await b.rd(a)
            await b.wr(a, 1)
        await b.copy(SRC0, DST0, 3 * SB)
        b.expect_outcome(S.E_NONE, 3 * SB)
        for a in (S.ACTIVE_CYCLES, S.STALL_CYCLES, S.TRANSFERS):
            await b.rd(a)
        b.finish("perf_counters")
        return
    xf = 0
    for req, rsp, lat in (("always", "always", "fixed:1"), ("random:0.3", "random:0.5", "uniform:1-4"), ("bursty:5-15", "bursty:2-6", "fixed:2")):
        b.set_stalls(req, rsp, lat)
        for ln in (SB, 4 * SB + 1, 9 * SB):
            await b.copy(SRC0, DST0, ln, max_cycles=40000)
            xf += 1
            assert await b.rd(S.TRANSFERS) == xf
            act = await b.rd(S.ACTIVE_CYCLES)
            stl = await b.rd(S.STALL_CYCLES)
            assert act >= S.num_beats(ln, SB) + 2 and stl <= act
    # errors and aborts do not count as completed transfers; counters restart at START
    b.set_stalls("random:0.5", "random:0.5", "uniform:1-3")
    b.inject(wr=[DST0 + SB])
    await b.copy(SRC0, DST0, 4 * SB)
    assert await b.rd(S.TRANSFERS) == xf
    b.inject()
    await b.copy(SRC0, DST0, 0)
    assert await b.rd(S.TRANSFERS) == xf and await b.rd(S.ACTIVE_CYCLES) <= 4
    await b.copy(SRC0, DST0, SB)
    assert await b.rd(S.TRANSFERS) == xf + 1
    # mid-transfer reads: counters advance monotonically while BUSY
    await b.program(SRC0, DST0, 8 * SB)
    ops = [b.rb.write_op(S.CONTROL, S.CTRL_START)]
    for _ in range(30):
        ops.append(b.rb.read_op(S.ACTIVE_CYCLES))
        ops.append(b.rb.read_op(S.STALL_CYCLES))
    await b.env.until(lambda: ops[-1].done, 2000, "mid-transfer perf reads")
    act = [o.rdata for o in ops[1::2]]
    assert all(x <= y for x, y in zip(act, act[1:])) and act[-1] > act[0], act
    await b.wait_idle()
    b.finish("perf_counters")
