"""Bench for ``hpc_dma_adapter`` (HPC DMA adapter): descriptor / completion channels, one DataFabric SFB2 memory and
one scratchpad requester-port memory behind it.

  AdapterObserver   pin-level scoreboard.  Per accepted descriptor it predicts the completion record (code incl. the
                    adapter's REGION rule, cpl_err_addr, cpl_bytes = contiguous acknowledged prefix, order, tag) with the
                    independent models (dma_spec / dma_model.Transfer / dma_adapter_model), checks every beat that reaches
                    either target (target selection by window, address, strobe, data == data of the same beat's read, order),
                    that nothing is presented while no transfer runs / after reset, byte-exact memory images when the
                    completion is produced, the busy pin, completion-queue stability and the performance counters.
  Bench             Env + descriptor driver + completion sink + two memories with random latency / stalls / error injection.
"""
from __future__ import annotations

import json
import os
from collections import deque
from dataclasses import dataclass
from typing import Deque, Dict, List, Optional, Tuple

from albionverify.bus.reqrsp import ReqRspSlave, make_port, sfb_port
from albionverify.core import Agent, AlbionCheckError, Env
from albionverify.coverage import CoverGroup
from albionverify.memory import BackingStore
from albionverify.models import dma_adapter_model as A
from albionverify.models import dma_spec as S
from albionverify.models.dma_model import BusReq, BusRsp, DmaConfig, DmaModelError, Transfer
from albionverify.reset import ResetSequencer
from albionverify.rng import Throttle

from dma.dma_tb import AddrErrors, pattern_init

P = json.loads(os.environ.get("ALBION_PARAMS", "{}"))
ACFG = A.AdapterConfig.from_params(P)
DCFG = DmaConfig(dw_bytes=ACFG.dw_bytes, engine=ACFG.engine, fifo_depth=ACFG.fifo_depth, burst=ACFG.burst, dual_port=ACFG.dual_port, max_out=ACFG.max_out,
                 max_len_log2=ACFG.max_len_log2)
DW = ACFG.dw_bytes * 8
SB = ACFG.dw_bytes
NP = ACFG.nports
MAXLEN = 1 << ACFG.max_len_log2
TOP = 1 << 32
SPM_BASE = ACFG.spm_base
SPM_BYTES = ACFG.spm_bytes
TAG_W = ACFG.tag_w

SPM_NAMES = dict(valid="spm_req_valid", ready="spm_req_ready", write="spm_req_we", addr="spm_req_addr", wdata="spm_req_wdata", strb="spm_req_wstrb", id="spm_req_tag",
                 rvalid="spm_rsp_valid", rready="spm_rsp_ready", rdata="spm_rsp_rdata", err="spm_rsp_err", rid="spm_rsp_tag", rwe="spm_rsp_we")

PC = {n: i for i, n in enumerate(["CYCLES", "ACTIVE", "BYTES_RD", "BYTES_WR", "READS", "WRITES", "REQ_STALL", "RSP_WAIT", "OUT_SUM", "OUT_MAX", "CPL_OK", "CPL_ERR", "BUS_ERR", "TAG_ERR", "SPM_REQ", "FAB_REQ"])}


class NotifySlave(ReqRspSlave):
    """ReqRspSlave that also reports the response handshake (``rsp_done``) and can corrupt the response tag of chosen
    reads (scratchpad port only: misrouted / duplicated / reordered response -> the adapter must turn it into an error)."""

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self.tag_fault_addrs = set()
        self._fault_kind = 0
        self.n_faults = 0

    def sample(self) -> None:
        head = self.pending[0] if self.pending else None
        hs = (not self.env.in_reset) and self._rv and bool(self.p["rready"].read())
        nlog = len(self.log)
        super().sample()
        if self.tag_fault_addrs and len(self.log) > nlog:
            ent = self.pending[-1]
            if not ent.req.write and (ent.req.addr - ent.req.addr % self.nbytes) in self.tag_fault_addrs:
                ent.tag_fault = self._fault_kind % 3
                self._fault_kind += 1
        if hs and head is not None:
            self._notify("rsp_done", head)

    def drive(self) -> None:
        super().drive()
        if self._rv and self.pending:
            k = getattr(self.pending[0], "tag_fault", None)
            if k is not None:
                if k == 0:
                    self.p["rid"].write(self.pending[0].req.id ^ 1)  # wrong sequence number
                elif k == 1:
                    self.p["rwe"].write(0 if self.pending[0].req.write else 1)  # wrong direction echo
                else:
                    self.p["rid"].write(self.pending[0].req.id ^ (1 << (ACFG.spm_tag_w - 1)))  # wrong direction in the tag


@dataclass
class Desc:
    src: int
    dst: int
    length: int
    tag: int


def make_coverage() -> Dict[str, CoverGroup]:
    g = {}
    x = CoverGroup("adapter_transfer", "direction x outcome of every descriptor")
    x.point("direction", ["fab_to_spm", "spm_to_fab", "spm_to_spm", "fab_to_fab"])
    x.point("outcome", ["DONE", "ZERO_LENGTH", "LENGTH", "SRC_ALIGN", "DST_ALIGN", "SRC_OVERFLOW", "DST_OVERFLOW", "OVERLAP", "READ_BUS", "WRITE_BUS", "ABORTED", "REGION"])
    x.point("length", ["one_byte", "partial_word", "one_word", "multi_word", "multi_partial", "max", "invalid"])
    x.cross("dir_x_outcome", ["direction", "outcome"], ignore=lambda b: b[1] not in ("DONE", "READ_BUS", "WRITE_BUS", "ABORTED"))
    g[x.name] = x
    x = CoverGroup("adapter_region", "REGION rule: crossing kinds")
    kinds = ["enter_from_below", "leave_at_top", "src_crossing", "dst_crossing", "touching_below", "touching_above"]
    if ACFG.spm_bytes + 2 * SB <= MAXLEN:
        kinds.append("span_window")
    if ACFG.spm_bytes <= MAXLEN:
        kinds.append("exact_window")
    x.point("kind", kinds)
    g[x.name] = x
    x = CoverGroup("adapter_queues", "descriptor / completion queue and handshake pressure")
    x.point("cmd_stalled", ["no", "yes"])
    x.point("cpl_stalled", ["no", "yes"])
    x.point("descs_in_flight", list(range(1, ACFG.cmd_depth + 2)))
    x.point("abort", ["idle_ignored", "during_run"])
    g[x.name] = x
    x = CoverGroup("adapter_backpressure", "target stall durations")
    x.point("req_stall", {"0": 0, "1": 1, "2_3": (2, 3), "4_8": (4, 8), "9_plus": (9, 10 ** 6)})
    x.point("target", ["fab", "spm"])
    g[x.name] = x
    x = CoverGroup("adapter_reset", "reset with descriptors queued / running / completions pending")
    x.point("state", ["idle", "queued_only", "running", "completion_pending"])
    g[x.name] = x
    return g


class AdapterObserver(Agent):
    PAD = 2 * SB

    def __init__(self, name: str, env: Env, fabmem: BackingStore, spmmem: BackingStore, cov: Optional[Dict[str, CoverGroup]] = None):
        super().__init__(name)
        self.env = env
        self.fabmem, self.spmmem = fabmem, spmmem
        self.cov = cov
        s = env.sig
        self.s = {n: s(n) for n in ("cmd_valid", "cmd_ready", "cmd_src", "cmd_dst", "cmd_len", "cmd_tag", "cmd_abort", "cpl_valid", "cpl_ready", "cpl_tag", "cpl_err", "cpl_code", "cpl_err_addr",
                                    "cpl_bytes", "busy", "active", "ctl_state", "eng_bytes_done", "ev_start", "ev_cpl", "ev_cpl_err", "perf_cnt", "perf_clear")}
        self.fab = [sfb_port(env, "fab_", p, flat=True, AW=32, DW=DW) for p in range(NP)]
        self.spm = [make_port(env, SPM_NAMES, index=p, flat=True, AW=32, DW=DW, IDW=ACFG.spm_tag_w) for p in range(NP)]
        self.events: List[tuple] = []
        self.descs: Deque[Desc] = deque()  # accepted, completion not yet produced
        self.xf: Optional[Transfer] = None
        self.xf_desc: Optional[Desc] = None
        self.snap = None
        self.expected: Deque[tuple] = deque()  # completion records produced, not yet consumed: (tag, code, addr, bytes, desc)
        self.cpl_prev: Optional[tuple] = None
        self.n_accepted = 0
        self.n_pushed = 0
        self.n_consumed = 0
        self.outcomes: List[tuple] = []
        self.n_checks = 0
        self._occ_pre = 0
        self._queued_pre = 0
        self._pop_now = False
        self._was_cpl_stalled = 0
        self.imaged = 0
        self.tot = dict(reads=0, writes=0, bytes_rd=0, bytes_wr=0, cpl_ok=0, cpl_err=0, bus_err=0, spm=0, fab=0, tag_err=0)
        self._since: Dict[tuple, Optional[int]] = {}
        self.must_abort = False
        self.n_started = 0
        self._cmd_stall = 0
        self._cpl_stall = 0
        self.max_cmd_stall = 0
        self.max_cpl_stall = 0
        self._req_stall: Dict[tuple, int] = {}
        self.reset_count = 0

    # ---- slave listeners (called during the slaves' own sample(), i.e. before this agent's sample)
    def attach_slaves(self, fab_slaves, spm_slaves) -> None:
        for p, sl in enumerate(fab_slaves):
            sl.listeners.append(_Tap(self, "fab", p))
        for p, sl in enumerate(spm_slaves):
            sl.listeners.append(_Tap(self, "spm", p))

    def tap_req(self, tgt: str, port: int, req, err: bool, rdata: int) -> None:
        self.events.append(("req", tgt, port, req, err, rdata))

    def tap_rsp(self, tgt: str, port: int, pend) -> None:
        self.events.append(("rsp", tgt, port, pend))

    # ---- helpers
    def store_of(self, addr: int) -> BackingStore:
        return self.spmmem if A.in_window(addr, ACFG) else self.fabmem

    def _fail(self, msg: str) -> None:
        self.env.error("adapter: " + msg)

    # ---- agent
    def sample(self) -> None:
        env = self.env
        n = env.cycle
        ev, self.events = self.events, []
        if env.in_reset:
            self.events = []
            for p in range(NP):
                if self.fab[p]["valid"].read() or self.spm[p]["valid"].read():
                    env.error("adapter: a request is presented while reset is active")
            if self.s["cpl_valid"].read():
                env.error("adapter: cpl_valid asserted while reset is active")
            return
        s = {k: v.read() for k, v in self.s.items()}
        self.n_checks += 1
        # ---- 1. pre-edge pins
        owed = len(self.descs)
        if bool(s["busy"]) != (owed > 0):
            self._fail("busy pin=%d with %d descriptor(s) accepted and not yet completed (edge %d)" % (s["busy"], owed, n))
        cpl_v, cpl_r = bool(s["cpl_valid"]), bool(s["cpl_ready"])
        occupancy = len(self.expected)
        self._occ_pre = occupancy
        self._queued_pre = len(self.descs) - (1 if s["ctl_state"] != 0 else 0)  # accepted descriptors still waiting in the descriptor queue
        if cpl_v != (occupancy > 0):
            self._fail("cpl_valid=%d with %d completion record(s) queued (edge %d)" % (cpl_v, occupancy, n))
        rec = (s["cpl_tag"], s["cpl_err"], s["cpl_code"], s["cpl_err_addr"], s["cpl_bytes"]) if cpl_v else None
        if self.cpl_prev is not None and (not cpl_v or rec != self.cpl_prev):
            self._fail("completion record changed / withdrawn while cpl_ready was low: %s -> %s" % (self.cpl_prev, rec))
        if cpl_v and not cpl_r:
            self.cpl_prev = rec
            self._cpl_stall += 1
        else:
            self.cpl_prev = None
            if self._cpl_stall:
                self.max_cpl_stall = max(self.max_cpl_stall, self._cpl_stall)
            self._was_cpl_stalled = self._cpl_stall
            self._cpl_stall = 0
        any_valid = False
        for p in range(NP):
            for tgt, port in (("fab", self.fab[p]), ("spm", self.spm[p])):
                v, r = port["valid"].read(), port["ready"].read()
                key = (tgt, p)
                if v:
                    any_valid = True
                    if self.xf is None or not self.xf.valid:
                        env.error("adapter: %s port %d presents a request while no transfer is running (or its descriptor was rejected)" % (tgt, p))
                    if not r:
                        self._req_stall[key] = self._req_stall.get(key, 0) + 1
                elif self._req_stall.get(key):
                    self._req_stall[key] = 0
        # ---- 2. completion consumption (the head record is compared with the prediction made at push time)
        self._pop_now = bool(cpl_v and cpl_r)
        if cpl_v and cpl_r:
            exp = self.expected.popleft()
            self.n_consumed += 1
            tag, code, addr, nbytes, desc = exp
            got = rec
            want = (tag, 1 if code else 0, code, addr, nbytes)
            if got != want:
                self._fail("completion record (tag,err,code,err_addr,bytes) = %s, expected %s for descriptor src=0x%08x dst=0x%08x len=%d" % (
                    got, want, desc.src, desc.dst, desc.length))
        # ---- 3. responses then requests at the targets
        for e in ev:
            if e[0] == "rsp":
                self._on_rsp(n, e)
        for e in ev:
            if e[0] == "req":
                self._on_req(n, e)
        # ---- 4. abort sampled while the adapter is running
        if s["cmd_abort"]:
            if s["ctl_state"] == 2 and self.xf is not None:
                self.xf.on_abort(n, False)
                if self.xf.valid and (self.xf.n - self.xf.writes_acc) > ACFG.out_limit + 3 + 2 * ACFG.fab_slice and self.xf.err_first is None:
                    self.must_abort = True
                if self.cov is not None:
                    self.cov["adapter_queues"].sample(abort="during_run")
            elif self.cov is not None:
                self.cov["adapter_queues"].sample(abort="idle_ignored")
        # ---- 5. descriptor start / completion
        if s["ev_start"]:
            self._on_start(n)
        if s["ev_cpl"]:
            self._on_push(n, bool(s["ev_cpl_err"]))
        # ---- 6. descriptor acceptance (a descriptor accepted at this edge cannot be started before the next edge)
        if s["cmd_valid"]:
            if s["cmd_ready"]:
                if ACFG.cmd_depth > 0 and self._queued_pre >= ACFG.cmd_depth:
                    self._fail("descriptor accepted although the descriptor queue holds %d of %d entries (cmd_ready must be low when full)" % (self._queued_pre, ACFG.cmd_depth))
                if ACFG.cmd_depth == 0 and (self.descs or s["ctl_state"] != 0):
                    self._fail("descriptor accepted while a descriptor is still in progress (CMD_DEPTH = 0: cmd_ready only when idle)")
                self.descs.append(Desc(s["cmd_src"], s["cmd_dst"], s["cmd_len"], s["cmd_tag"]))
                self.n_accepted += 1
                if self.cov is not None:
                    self.cov["adapter_queues"].sample(cmd_stalled="yes" if self._cmd_stall else "no", descs_in_flight=min(len(self.descs), ACFG.cmd_depth + 1))
                self._cmd_stall = 0
            else:
                self._cmd_stall += 1
                self.max_cmd_stall = max(self.max_cmd_stall, self._cmd_stall)
        else:
            self._cmd_stall = 0
        if cpl_v and cpl_r and self.cov is not None:
            self.cov["adapter_queues"].sample(cpl_stalled="yes" if self._was_cpl_stalled else "no")
        if s["perf_clear"]:
            self.tot = dict.fromkeys(self.tot, 0)  # synchronous clear: the events of this very cycle are not counted either
        # ---- 7. live acknowledged-bytes pin may never run ahead of the acknowledged writes
        if self.xf is not None and self.xf.valid and n > self.xf.start_edge and s["eng_bytes_done"] > self.xf.bytes_ok:
            self._fail("eng_bytes_done=%d exceeds the bytes acknowledged at the targets (%d)" % (s["eng_bytes_done"], self.xf.bytes_ok))

    # ------------------------------------------------------------------ target events
    def _on_req(self, n: int, e) -> None:
        _, tgt, p, req, err, rdata = e
        xf = self.xf
        if xf is None or not xf.valid:
            self.env.error("adapter: %s request at 0x%08x while no transfer is running" % (tgt, req.addr))
            return
        want = A.target_of(req.addr, ACFG)
        if want != tgt:
            self._fail("request 0x%08x went to the %s target, the address belongs to the %s target" % (req.addr, tgt, want))
        key = (tgt, p)
        st = self._req_stall.get(key, 0)
        if self.cov is not None:
            self.cov["adapter_backpressure"].sample(req_stall=st, target=tgt)
        self._req_stall[key] = 0
        self.tot["spm" if tgt == "spm" else "fab"] += 1
        self.tot["writes" if req.write else "reads"] += 1
        try:
            xf.on_req(n, BusReq(p, bool(req.write), req.addr, req.wdata if req.write else 0, req.strb if req.write else 0xF, n))
        except DmaModelError as ex:
            self.env.error("adapter: reference model: %s" % ex)

    def _on_rsp(self, n: int, e) -> None:
        _, tgt, p, pend = e
        xf = self.xf
        if xf is None or not xf.valid:
            return
        faulted = getattr(pend, "tag_fault", None) is not None
        err = bool(pend.err) or faulted
        rdata = pend.rdata
        if faulted:
            self.tot["tag_err"] += 1
        if err:
            self.tot["bus_err"] += 1
        elif not pend.req.write:
            self.tot["bytes_rd"] += SB
        elif pend.req.write:
            self.tot["bytes_wr"] += bin(pend.req.strb & ((1 << SB) - 1)).count("1")
        try:
            xf.on_rsp(n, BusRsp(p, 0 if err else rdata, err))
        except DmaModelError as ex:
            self.env.error("adapter: reference model: %s" % ex)

    # ------------------------------------------------------------------ transfer boundaries
    def _on_start(self, n: int) -> None:
        if not self.descs:
            self._fail("ev_start with no descriptor accepted")
            return
        if self.xf is not None:
            self._fail("ev_start while the previous transfer (src=0x%08x) has not completed" % self.xf_desc.src)
            return
        if self._occ_pre >= ACFG.cpl_depth:
            self._fail("a descriptor was started with the completion queue full (%d of %d records; a completion slot must be free, doc 01 A4)" % (self._occ_pre, ACFG.cpl_depth))
        d = self.descs[0]
        code, _ = A.expected_completion(d.src, d.dst, d.length, ACFG)
        if code == A.E_REGION:
            self._fail("the REGION rule must reject descriptor src=0x%08x dst=0x%08x len=%d without starting the engine" % (d.src, d.dst, d.length))
        self.n_started += 1
        self.xf = Transfer(DCFG, d.src, d.dst, d.length, n, strict=False)
        self.xf_desc = d
        self.must_abort = False
        self.snap = None
        if self.xf.valid:
            xf = self.xf
            lo = max(0, d.dst - self.PAD)
            hi = d.dst + xf.n * SB + self.PAD
            self.snap = {"src": self.store_of(d.src).snapshot(d.src, xf.n * SB), "lo": lo, "dst": self.store_of(d.dst).snapshot(lo, hi - lo)}

    def _on_push(self, n: int, err_pin: bool) -> None:
        if not self.descs:
            self._fail("a completion record was produced with no descriptor outstanding")
            return
        if self._occ_pre - (1 if self._pop_now else 0) + 1 > ACFG.cpl_depth:
            self._fail("completion record pushed into a full completion queue (%d of %d, doc 01 A4)" % (self._occ_pre, ACFG.cpl_depth))
        d = self.descs.popleft()
        self.n_pushed += 1
        xf = self.xf
        if xf is None:  # rejected before the engine started: only the REGION rule can do that
            code, addrs = A.expected_completion(d.src, d.dst, d.length, ACFG)
            if code != A.E_REGION:
                self._fail("completion pushed without the engine for a descriptor that is not a REGION violation (expected code %s)" % A.ERROR_NAMES[code])
                return
            self.expected.append((d.tag, code, _AddrSet(addrs), 0, d))
            self._finish_stats(d, code)
            self.tot["cpl_err"] += 1
            if not err_pin:
                self._fail("ev_cpl_err not asserted for a REGION completion")
            return
        if d is not self.xf_desc:
            self._fail("completion pushed for a different descriptor than the running one")
        if not xf.stop_met():
            if xf.err_first is not None and xf.err_first[1] == "R":
                self._fail("transfer completed (read error at beat %d) before the beats preceding it were all written" % xf.err_first[2])
            self._fail("completion produced with only %d of %d beats written and acknowledged (no error, no abort)" % (xf.n_ok_writes, xf.n))
        if xf.outstanding():
            self._fail("completion produced while %d transaction(s) were still outstanding" % xf.outstanding())
        o = xf.try_outcome()
        if o is None:
            self._fail("completion without an outcome")
            return
        if self.must_abort and o.done:
            self._fail("an ABORT sampled with many beats still unissued did not abort the transfer")
        if err_pin != (not o.done):
            self._fail("ev_cpl_err=%d but the completion code is %s" % (err_pin, A.ERROR_NAMES[o.code]))
        if xf.valid:
            self._image_check(xf, d)
        self.expected.append((d.tag, o.code, _AddrSet(set(o.alts.values()) if o.alts else {o.addr}), o.bytes_done, d))
        self.tot["cpl_ok" if o.done else "cpl_err"] += 1
        self._finish_stats(d, o.code if not o.done else 0, xf)
        self.xf = None
        self.xf_desc = None
        self.snap = None

    def _finish_stats(self, d: Desc, code: int, xf=None) -> None:
        self.outcomes.append((d.tag, code))
        if self.cov is not None:
            name = "DONE" if code == 0 else A.ERROR_NAMES[code]
            ln = d.length
            lc = "invalid" if (ln == 0 or ln > MAXLEN) else ("max" if ln == MAXLEN else ("one_byte" if ln == 1 else ("partial_word" if ln < SB else ("one_word" if ln == SB else ("multi_word" if ln % SB == 0 else "multi_partial")))))
            self.cov["adapter_transfer"].sample(direction=A.direction(d.src, d.dst, ACFG), outcome=name, length=lc)
            for a in (d.src, d.dst):  # legal edge cases (sampled for every descriptor that touches a window edge)
                if ln:
                    if a == ACFG.win_lo and ln == ACFG.spm_bytes:
                        self.cov["adapter_region"].sample(kind="exact_window") if ACFG.spm_bytes <= MAXLEN else None
                    if a + ln == ACFG.win_lo:
                        self.cov["adapter_region"].sample(kind="touching_below")
                    if a == ACFG.win_hi:
                        self.cov["adapter_region"].sample(kind="touching_above")
            if code == A.E_REGION:
                kinds = []
                for nm, a in (("src", d.src), ("dst", d.dst)):
                    cb = A.crossed_boundaries(a, d.length, ACFG)
                    if cb:
                        kinds.append(nm + "_crossing")
                        kinds.append("span_window" if len(cb) == 2 else ("enter_from_below" if cb == {ACFG.win_lo} else "leave_at_top"))
                for k in kinds:
                    self.cov["adapter_region"].sample(kind=k)

    # ------------------------------------------------------------------ memory image
    def _image_check(self, xf: Transfer, d: Desc, uncertain: bool = False) -> None:
        snap = self.snap
        if snap is None:
            return
        self.imaged += 1
        lo, old = snap["lo"], snap["dst"]
        exp = bytearray(old)
        alt = {}
        for k in range(xf.n):
            st = xf.wstate.get(k)
            if st not in ("ok", "pending"):
                continue
            b = xf.plan[k]
            for i in range(b.nbytes):
                a = b.dst_addr + i
                new = snap["src"][k * SB + i]
                if st == "ok":
                    exp[a - lo] = new
                else:
                    alt[a] = (old[a - lo], new)
        got = self.store_of(d.dst).snapshot(lo, len(exp))
        for i in range(len(exp)):
            a = lo + i
            if got[i] != exp[i] and not (a in alt and got[i] in alt[a]):
                self._fail("memory image mismatch at 0x%08x: got 0x%02x expected 0x%02x (pre-transfer 0x%02x) -- transfer src=0x%08x dst=0x%08x len=%d" % (
                    a, got[i], exp[i], old[i], d.src, d.dst, d.length))
        if self.store_of(d.src).snapshot(d.src, xf.n * SB) != snap["src"]:
            self._fail("the source of the transfer was modified (0x%08x)" % d.src)

    # ------------------------------------------------------------------ reset
    def on_reset(self, asserted: bool) -> None:
        if not asserted:
            return
        self.reset_count += 1
        if self.cov is not None:
            st = "running" if self.xf is not None else ("queued_only" if self.descs else ("completion_pending" if self.expected else "idle"))
            self.cov["adapter_reset"].sample(state=st)
        if self.xf is not None and self.xf.valid and self.snap is not None:
            self._image_check(self.xf, self.xf_desc, uncertain=True)
        self.events = []
        self.descs.clear()
        self.expected.clear()
        self.xf = None
        self.xf_desc = None
        self.snap = None
        self.cpl_prev = None
        self._since.clear()
        self._req_stall.clear()
        self._cmd_stall = self._cpl_stall = 0
        self.tot = dict(reads=0, writes=0, bytes_rd=0, bytes_wr=0, cpl_ok=0, cpl_err=0, bus_err=0, spm=0, fab=0, tag_err=0)
        self.must_abort = False

    # ------------------------------------------------------------------ end of test
    def check_perf(self) -> None:
        """Performance counters against the testbench's own totals (valid after the DMA has been idle for a while)."""
        if ACFG.perf_en == 0:
            return
        raw = self.s["perf_cnt"].read()
        w = ACFG.cnt_w
        c = {k: (raw >> (i * w)) & ((1 << w) - 1) for k, i in PC.items()}
        t = self.tot
        sat = (1 << w) - 1  # counters saturate, never wrap
        want = {"READS": t["reads"], "WRITES": t["writes"], "BYTES_RD": t["bytes_rd"], "BYTES_WR": t["bytes_wr"], "CPL_OK": t["cpl_ok"], "CPL_ERR": t["cpl_err"],
                "BUS_ERR": t["bus_err"], "SPM_REQ": t["spm"], "FAB_REQ": t["fab"], "TAG_ERR": t["tag_err"]}
        want = {k: min(v, sat) for k, v in want.items()}
        for k, v in want.items():
            if c[k] != v:
                self.env.error("adapter perf counter %s = %d, testbench total %d" % (k, c[k], v))
        if c["ACTIVE"] > c["CYCLES"] or c["OUT_MAX"] > ACFG.out_limit * NP:
            self.env.error("adapter perf counters inconsistent: %s" % c)

    def finalize(self) -> None:
        if self.descs:
            self.env.error("adapter: %d accepted descriptor(s) never produced a completion" % len(self.descs))
        if self.expected:
            self.env.error("adapter: %d completion record(s) never consumed" % len(self.expected))
        if self.n_accepted != self.n_consumed + 0 and self.reset_count == 0:
            self.env.error("adapter: ledger: accepted=%d consumed=%d" % (self.n_accepted, self.n_consumed))

    def summary(self) -> dict:
        return {"descriptors": self.n_accepted, "completions": self.n_consumed, "checks": self.n_checks, "images": self.imaged, "resets": self.reset_count,
                "max_cmd_stall": self.max_cmd_stall, "max_cpl_stall": self.max_cpl_stall}


class _AddrSet:
    """Expected cpl_err_addr: one value or one of several (REGION with both boundaries legal)."""

    def __init__(self, vals):
        self.vals = set(vals)

    def __eq__(self, other):
        return other in self.vals

    def __hash__(self):
        return hash(tuple(sorted(self.vals)))

    def __repr__(self):
        return "|".join("0x%x" % v for v in sorted(self.vals))


class _Tap:
    def __init__(self, obs: AdapterObserver, tgt: str, port: int):
        self.obs, self.tgt, self.port = obs, tgt, port

    def req_accepted(self, slave, req, err, rdata):
        self.obs.tap_req(self.tgt, self.port, req, err, rdata)

    def rsp_done(self, slave, pend):
        self.obs.tap_rsp(self.tgt, self.port, pend)


# --------------------------------------------------------------------------------------------- stimulus agents
class CmdDriver(Agent):
    """Descriptor producer: holds src/dst/len/tag stable until accepted (A1), random gaps, optional abort pulses."""

    def __init__(self, name: str, env: Env, rng, gap: str = "always"):
        super().__init__(name)
        s = env.sig
        self.valid, self.ready, self.src, self.dst, self.len, self.tag, self.abort = (s("cmd_valid"), s("cmd_ready"), s("cmd_src"), s("cmd_dst"), s("cmd_len"), s("cmd_tag"), s("cmd_abort"))
        self.rng = rng
        self.gap = Throttle(rng, gap)
        self.queue: Deque[Desc] = deque()
        self.cur: Optional[Desc] = None
        self._v = False
        self.abort_pulses = 0
        self.abort_noise = 0.0  # probability of a random one-cycle cmd_abort per cycle (ignored by the DUT unless a transfer runs)
        self.n_sent = 0

    def submit(self, d: Desc) -> None:
        self.queue.append(d)

    @property
    def idle(self) -> bool:
        return not self.queue and self.cur is None

    def sample(self) -> None:
        if self._v and not self.env.in_reset and self.ready.read():
            self.cur = None
            self.n_sent += 1

    def drive(self) -> None:
        env = self.env
        if env.in_reset:
            self._v = False
            self.valid.write(0)
            self.abort.write(0)
            self.cur = None
            self.queue.clear()
            return
        if self.cur is None and self.queue and self.gap.allow():
            self.cur = self.queue.popleft()
        if self.cur is not None:
            self.valid.write(1)
            self.src.write(self.cur.src)
            self.dst.write(self.cur.dst)
            self.len.write(self.cur.length)
            self.tag.write(self.cur.tag)
            self._v = True
        else:
            self.valid.write(0)
            self.src.write(self.rng.getrandbits(32))
            self.dst.write(self.rng.getrandbits(32))
            self.len.write(self.rng.getrandbits(32))
            self.tag.write(self.rng.getrandbits(TAG_W))
            self._v = False
        if self.abort_pulses > 0:
            self.abort.write(1)
            self.abort_pulses -= 1
        else:
            self.abort.write(1 if (self.abort_noise and self.rng.random() < self.abort_noise) else 0)


class CplSink(Agent):
    def __init__(self, name: str, env: Env, rng, thr: str = "always"):
        super().__init__(name)
        self.ready = env.sig("cpl_ready")
        self.thr = Throttle(rng, thr)

    def drive(self) -> None:
        self.ready.write(1 if (not self.env.in_reset and self.thr.allow()) else 0)


# --------------------------------------------------------------------------------------------- bench
class AdapterBench:
    def __init__(self, dut, seed: int, *, name: str = "adapter", cmd_gap: str = "always", cpl_thr: str = "always", req_thr: str = "always",
                 rsp_thr: str = "always", latency: str = "fixed:1", spm_latency: Optional[str] = None, coverage: bool = True):
        self.dut = dut
        env = self.env = Env(dut, name=name, seed=seed)
        self.rst = env.add(ResetSequencer("rst", env.sig("rst_n"), initial_cycles=4))
        self.fabmem = BackingStore(pattern_init(seed), "fabmem")
        self.spmmem = BackingStore(pattern_init(seed + 1000), "spmmem")
        self.pol_fab, self.pol_spm = AddrErrors(SB), AddrErrors(SB)
        mo = max(4, ACFG.out_limit + 2)
        self.fab_slaves = [env.add(NotifySlave("fab%d" % p, sfb_port(env, "fab_", p, flat=True, AW=32, DW=DW), memory=self.fabmem, nbytes=SB, rng=env.seeds.child("fab%d" % p),
                                              req_throttle=req_thr, rsp_throttle=rsp_thr, latency=latency, error_policy=self.pol_fab, max_pending=mo)) for p in range(NP)]
        self.spm_slaves = [env.add(NotifySlave("spm%d" % p, make_port(env, SPM_NAMES, index=p, flat=True, AW=32, DW=DW, IDW=ACFG.spm_tag_w), memory=self.spmmem, nbytes=SB,
                                              rng=env.seeds.child("spm%d" % p), req_throttle=req_thr, rsp_throttle=rsp_thr, latency=spm_latency or latency, error_policy=self.pol_spm,
                                              max_pending=mo, IDW=ACFG.spm_tag_w, echo_we=True)) for p in range(NP)]
        self.cov = make_coverage() if coverage else None
        if self.cov:
            env.coverage.extend(self.cov.values())
        self.obs = env.add(AdapterObserver("obs", env, self.fabmem, self.spmmem, self.cov))
        self.obs.attach_slaves(self.fab_slaves, self.spm_slaves)
        self.cmd = env.add(CmdDriver("cmd", env, env.seeds.child("cmd"), cmd_gap))
        self.sink = env.add(CplSink("sink", env, env.seeds.child("sink"), cpl_thr))
        self.perf_clear = env.sig("perf_clear")
        env.tie("spm_rsp_err_code")
        self.perf_clear.write(0)
        self.rng = env.seeds.child("test")
        self.rng = env.seeds.child("test")
        self.tag_ctr = 0

    async def start(self) -> None:
        await self.env.start()
        await self.env.until(lambda: not self.rst.asserted, 50, "reset release")
        await self.env.cycles(2)

    def set_stalls(self, req: Optional[str] = None, rsp: Optional[str] = None, latency: Optional[str] = None, spm_latency: Optional[str] = None, cpl: Optional[str] = None) -> None:
        from albionverify.rng import Latency

        for grp, lat in ((self.fab_slaves, latency), (self.spm_slaves, spm_latency or latency)):
            for i, sl in enumerate(grp):
                if req is not None:
                    sl.req_thr.set_mode(req)
                if rsp is not None:
                    sl.rsp_thr.set_mode(rsp)
                if lat is not None:
                    sl.lat = Latency(self.env.seeds.child("lat%s%d" % (sl.name, i)), lat)
        if cpl is not None:
            self.sink.thr.set_mode(cpl)

    def inject(self, fab_rd=(), fab_wr=(), spm_rd=(), spm_wr=()) -> None:
        for pol, rd, wr in ((self.pol_fab, fab_rd, fab_wr), (self.pol_spm, spm_rd, spm_wr)):
            pol.clear()
            pol.rd.update(a - a % SB for a in rd)
            pol.wr.update(a - a % SB for a in wr)

    def inject_for(self, d: Desc, rd_beats=(), wr_beats=()) -> None:
        rd = [d.src + k * SB for k in rd_beats]
        wr = [d.dst + k * SB for k in wr_beats]
        self.inject(fab_rd=[a for a in rd if not A.in_window(a, ACFG)], spm_rd=[a for a in rd if A.in_window(a, ACFG)],
                    fab_wr=[a for a in wr if not A.in_window(a, ACFG)], spm_wr=[a for a in wr if A.in_window(a, ACFG)])

    def submit(self, src: int, dst: int, length: int, tag: Optional[int] = None) -> Desc:
        if tag is None:
            self.tag_ctr += 1
            tag = (self.tag_ctr * 37 + self.rng.getrandbits(3)) & ((1 << TAG_W) - 1)
        d = Desc(src & 0xFFFFFFFF, dst & 0xFFFFFFFF, length & 0xFFFFFFFF, tag)
        self.cmd.submit(d)
        return d

    async def pulse_perf_clear(self) -> None:
        """One-cycle perf_clear (the testbench totals restart with it)."""
        self.perf_clear.write(1)
        await self.env.cycles(1)
        self.perf_clear.write(0)
        await self.env.cycles(2)

    def inject_tag_faults(self, spm_read_addrs=()) -> None:
        for sl in self.spm_slaves:
            sl.tag_fault_addrs = {a - a % SB for a in spm_read_addrs}

    def abort_after_start(self, cycles: int) -> None:
        """Pulse cmd_abort once, ``cycles`` cycles after the adapter next starts a transfer."""
        obs = self.obs
        n0 = obs.n_started
        state = {"t": None}

        def pred():
            if obs.n_started > n0 and state["t"] is None:
                state["t"] = obs.env.cycle
            return state["t"] is not None and obs.env.cycle - state["t"] >= cycles

        self._abort_watch = (pred, state)
        self.env.add(_AbortTrigger(self, pred))

    async def drain(self, max_cycles: int = 40000, what: str = "all descriptors to complete") -> None:
        obs = self.obs
        await self.env.until(lambda: self.cmd.idle and not obs.descs and not obs.expected, max_cycles, what)
        await self.env.cycles(3)

    async def run(self, src: int, dst: int, length: int, max_cycles: int = 40000) -> Desc:
        d = self.submit(src, dst, length)
        await self.drain(max_cycles)
        return d

    def expect_code(self, code: int, bytes_: Optional[int] = None) -> None:
        tag, got = self.obs.outcomes[-1]
        if got != code:
            raise AlbionCheckError("directed expectation: completion code %s expected, got %s" % (A.ERROR_NAMES[code], A.ERROR_NAMES[got]))

    def finish(self, test: str, **extra) -> None:
        self.obs.check_perf()
        self.obs.finalize()
        self.env.finalize()
        extra.setdefault("observer", self.obs.summary())
        self.env.write_result(test, **extra)


class _AbortTrigger(Agent):
    def __init__(self, bench: AdapterBench, pred):
        super().__init__("abort_trigger")
        self.b, self.pred, self.done = bench, pred, False

    def drive(self) -> None:
        if not self.done and not self.env.in_reset and self.pred():
            self.b.cmd.abort_pulses += 1
            self.done = True
