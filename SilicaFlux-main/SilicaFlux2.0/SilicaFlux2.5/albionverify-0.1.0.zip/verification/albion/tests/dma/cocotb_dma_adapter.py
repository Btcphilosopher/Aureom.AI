"""hpc_dma_adapter tests: descriptor / completion semantics, the REGION rule, routing to the scratchpad / DataFabric
targets, bus errors, abort, queue back-pressure, ordering and tags, reset.  The independent models predict every
completion record, every beat and the memory images; the observer checks them on the fly (dma_adapter_tb.py)."""
import os

import cocotb

from albionverify.models import dma_adapter_model as A
from albionverify.models import dma_spec as S
from albionverify.rng import weighted_choice
from dma.dma_adapter_tb import ACFG, DW, MAXLEN, NP, SB, SPM_BASE, SPM_BYTES, TOP, AdapterBench, Desc

EXT_A = 0x10000000
EXT_B = 0x30000000
SPM_HI = SPM_BASE + SPM_BYTES
HALF = min(MAXLEN, SPM_BYTES // 2)  # longest transfer that fits twice into the window


def seed_of() -> int:
    return int(os.environ.get("ALBION_SEED", "1"))


def al(x: int) -> int:
    return x - x % SB


def directions(off_a=0, off_b=0):
    return [("fab_to_spm", EXT_A + off_a, SPM_BASE + off_b), ("spm_to_fab", SPM_BASE + off_a, EXT_B + off_b),
            ("spm_to_spm", SPM_BASE + off_a, SPM_BASE + HALF + off_b), ("fab_to_fab", EXT_A + off_a, EXT_B + off_b)]


@cocotb.test()
async def directions_lengths(dut):
    """All four directions, every length 1 .. 3*DW/8+1 and burst / FIFO boundaries, descriptors queued back to back."""
    b = AdapterBench(dut, seed_of(), req_thr="random:0.8", rsp_thr="random:0.8", latency="uniform:1-2", spm_latency="uniform:1-3", cmd_gap="random:0.7", cpl_thr="random:0.6")
    await b.start()
    lens = list(range(1, 3 * SB + 2))
    fifo = ACFG.fifo_depth if ACFG.buffered else 4
    for base in (ACFG.burst * SB, fifo * SB, (ACFG.out_limit + 1) * SB):
        lens += [x for x in (base - 1, base, base + 1, 2 * base + 1) if 1 <= x <= HALF and x not in lens]
    lens += [HALF - 1, HALF]
    for name, s, d in directions():
        for i, ln in enumerate(lens):
            off = SB * (i % 5)
            if (A.in_window(s, ACFG) and s + off + ln > SPM_HI) or (A.in_window(d, ACFG) and d + off + ln > SPM_HI):
                off = 0
            b.submit(s + off, d + off, ln)
        await b.drain(60000)
    # a maximum-length transfer in each direction that fits
    ml = min(MAXLEN, SPM_BYTES)
    await b.run(EXT_A, SPM_BASE, ml)
    await b.run(SPM_BASE, EXT_B, ml)
    await b.run(EXT_A, EXT_B, MAXLEN)
    assert b.obs.imaged >= 4 * len(lens)
    b.finish("directions_lengths")


@cocotb.test()
async def rejects_and_region(dut):
    """DataFabric rules 1-7 and the adapter's REGION rule (precedence, exact window edges, no bus access)."""
    b = AdapterBench(dut, seed_of(), req_thr="random:0.8", rsp_thr="random:0.8", latency="uniform:1-2")
    await b.start()
    rows = [
        (EXT_A, EXT_B, 0, S.E_ZERO_LENGTH), (SPM_BASE - SB, EXT_B, 0, S.E_ZERO_LENGTH),
        (EXT_A, EXT_B, MAXLEN + 1, S.E_LENGTH), (SPM_BASE - SB, EXT_B, MAXLEN + 1, S.E_LENGTH),
        (EXT_A + 1, EXT_B, 2 * SB, S.E_SRC_ALIGN), (EXT_A, EXT_B + 1, 2 * SB, S.E_DST_ALIGN),
        (TOP - SB, EXT_B, 2 * SB, S.E_SRC_OVERFLOW), (EXT_A, TOP - SB, 2 * SB, S.E_DST_OVERFLOW),
        (EXT_A, EXT_A, 2 * SB, S.E_OVERLAP), (SPM_BASE, SPM_BASE + SB, 2 * SB, S.E_OVERLAP),
        # rules 1-7 win over REGION
        (SPM_BASE - SB, SPM_BASE - SB, 4 * SB, S.E_OVERLAP), (SPM_BASE - SB + 1, EXT_B, 4 * SB, S.E_SRC_ALIGN),
        # REGION: ranges that start outside and end inside, start inside and end outside, and (small window) span the whole window
        (SPM_BASE - SB, EXT_B, 2 * SB, A.E_REGION), (EXT_B, SPM_BASE - SB, 2 * SB, A.E_REGION),
        (SPM_HI - SB, EXT_B, 2 * SB, A.E_REGION), (EXT_B, SPM_HI - SB, 2 * SB, A.E_REGION),
        (SPM_BASE - 2 * SB, SPM_BASE + HALF, 4 * SB, A.E_REGION), (SPM_BASE, SPM_BASE - 2 * SB + 0x1000, 4 * SB, S.E_NONE),
        (SPM_HI - SB, SPM_BASE - 2 * SB, 2 * SB + 1, A.E_REGION),
        (SPM_BASE - SB, SPM_BASE + SB, 2 * SB, A.E_REGION),
        # exact window edges are legal
        (EXT_A, SPM_BASE, SB, S.E_NONE), (EXT_A, SPM_HI - SB, SB, S.E_NONE), (SPM_BASE, EXT_B, SB, S.E_NONE), (SPM_HI - SB, EXT_B, SB, S.E_NONE),
        (SPM_BASE - 2 * SB, EXT_B, 2 * SB, S.E_NONE), (SPM_HI, EXT_B, 2 * SB, S.E_NONE), (EXT_A, SPM_HI, 2 * SB, S.E_NONE), (EXT_A, SPM_BASE - 2 * SB, 2 * SB, S.E_NONE),
        (SPM_BASE, SPM_HI - SB, SB, S.E_NONE), (SPM_BASE, SPM_BASE + SB, SB, S.E_NONE),
    ]
    if SPM_BYTES <= MAXLEN:  # whole-window transfers
        rows += [(SPM_BASE, EXT_B, SPM_BYTES, S.E_NONE), (EXT_A, SPM_BASE, SPM_BYTES, S.E_NONE)]
    if SPM_BYTES + 2 * SB <= MAXLEN:  # ranges that span the whole window (cross both edges)
        rows += [(SPM_BASE - SB, EXT_B, SPM_BYTES + 2 * SB, A.E_REGION), (EXT_B, SPM_BASE - SB, SPM_BYTES + 2 * SB, A.E_REGION)]
    for s, d, ln, code in rows:
        exp, _ = A.expected_completion(s, d, ln, ACFG)
        assert exp == code, "row src=0x%x dst=0x%x len=%d: model says %s, table says %s" % (s, d, ln, A.ERROR_NAMES[exp], A.ERROR_NAMES[code])
        await b.run(s, d, ln)
        b.expect_code(code)
    # queued mix of legal and rejected descriptors: one completion per descriptor, in order, with its tag
    for s, d, ln, code in rows:
        b.submit(s, d, ln)
    await b.drain(80000)
    assert [c for _, c in b.obs.outcomes[-len(rows):]] == [r[3] for r in rows]
    b.finish("rejects_and_region")


@cocotb.test()
async def errors_and_abort(dut):
    """Bus errors at the first / middle / last beat of reads and writes on both targets (codes, err_addr, byte prefix),
    ABORT at every cycle offset, abort when idle."""
    b = AdapterBench(dut, seed_of(), req_thr="random:0.7", rsp_thr="random:0.7", latency="uniform:1-3", cpl_thr="random:0.8")
    await b.start()
    ln = 6 * SB + 1
    nb = S.num_beats(ln, SB)
    for name, s, d in directions(8, 0):
        for kind in ("read", "write"):
            for k in sorted({0, nb // 2, nb - 1}):
                desc = Desc(s, d, ln, 0)
                b.inject_for(desc, rd_beats=[k] if kind == "read" else [], wr_beats=[k] if kind == "write" else [])
                await b.run(s, d, ln)
                b.expect_code(S.E_READ_BUS if kind == "read" else S.E_WRITE_BUS)
                b.inject()
    # scratchpad responses carrying a wrong tag / direction (misrouted, duplicated, reordered): the adapter must turn them
    # into error responses -> READ_BUS at that beat, never write the data
    for name, s, d in directions(8, 0):
        if not A.in_window(s, ACFG):
            continue
        for k in sorted({0, nb // 2, nb - 1, 1}):
            b.inject_tag_faults([s + k * SB])
            await b.run(s, d, ln)
            b.expect_code(S.E_READ_BUS)
            b.inject_tag_faults([])
    # clean transfer after errors: nothing stale
    await b.run(EXT_A, SPM_BASE, 3 * SB)
    b.expect_code(S.E_NONE)
    await b.pulse_perf_clear()
    await b.run(EXT_A, SPM_BASE + 0x40, 5 * SB + 1)
    b.expect_code(S.E_NONE)
    # abort sweeps: a long transfer, ABORT d cycles after the engine started, for each direction
    for name, s, d in directions(0, 0):
        for dly in range(0, 40, 3):
            b.abort_after_start(dly)
            await b.run(s, d, min(24 * SB, HALF))
            b.env.agents[:] = [a for a in b.env.agents if a.name != "abort_trigger"]
    # abort while idle is ignored; random aborts do not disturb the queue
    b.cmd.abort_pulses = 3
    await b.env.cycles(6)
    await b.run(EXT_A, SPM_BASE, 4 * SB)
    b.expect_code(S.E_NONE)
    b.cmd.abort_noise = 0.05
    for i in range(6):
        b.submit(EXT_A, SPM_BASE + 0x40, 8 * SB)
        b.submit(SPM_BASE + 0x40, EXT_B, 8 * SB)
    await b.drain(60000)
    b.cmd.abort_noise = 0.0
    b.finish("errors_and_abort")


@cocotb.test()
async def queues_and_order(dut):
    """Descriptor queue / completion queue back-pressure: many descriptors submitted at once, a sink that stalls for long
    stretches (cmd_ready back-pressure, no completion lost or reordered, one record per descriptor, tags preserved)."""
    b = AdapterBench(dut, seed_of(), cmd_gap="always", cpl_thr="bursty:20-40", req_thr="random:0.9", rsp_thr="random:0.9", latency="uniform:1-2")
    await b.start()
    rng = b.rng
    for rnd in range(3):
        for i in range(3 * ACFG.cmd_depth + 6):
            kind = rng.choice([0, 1, 2, 3, 4])
            if kind == 0:
                b.submit(EXT_A + SB * i, SPM_BASE + SB * (i % 8), rng.randint(1, 4 * SB))
            elif kind == 1:
                b.submit(SPM_BASE + SB * (i % 8), EXT_B + SB * i, rng.randint(1, 4 * SB))
            elif kind == 2:
                b.submit(EXT_A, EXT_B, 0)  # rejected instantly
            elif kind == 3:
                b.submit(SPM_BASE - SB, EXT_B, 2 * SB)  # REGION
            else:
                b.submit(EXT_A, EXT_B + SB * i, rng.randint(1, 3 * SB))
        await b.drain(80000)
        b.set_stalls(cpl=["bursty:10-30", "random:0.3", "always"][rnd % 3])
    assert b.obs.max_cmd_stall >= 5 or ACFG.cmd_depth > 8, "cmd_ready never back-pressured the producer (%d)" % b.obs.max_cmd_stall
    assert b.obs.max_cpl_stall >= 10, "the completion sink never stalled (%d)" % b.obs.max_cpl_stall
    b.finish("queues_and_order")


def gen_desc(rng):
    kinds = ["ok", "ok_boundary", "bad_len", "misaligned", "overflow", "overlap", "region", "edge"]
    kind = weighted_choice(rng, kinds, [38, 12, 5, 6, 4, 6, 15, 14])
    ln = rng.randint(1, 8 * SB)
    pools = [EXT_A, EXT_B, 0x0, TOP - 0x1000, SPM_BASE, SPM_BASE, SPM_BASE]
    base = rng.choice(pools)
    span = (SPM_BYTES - ln - SB) if base == SPM_BASE else 0x400
    src = al(base + rng.randrange(0, max(SB, span)))
    base2 = rng.choice([EXT_B, EXT_A, SPM_BASE, SPM_BASE])
    span2 = (SPM_BYTES - ln - SB) if base2 == SPM_BASE else 0x400
    dst = al(base2 + rng.randrange(0, max(SB, span2)))
    if kind == "ok_boundary":
        ln = rng.choice([1, SB - 1 if SB > 1 else 1, SB, SB + 1, 2 * SB, HALF, HALF - 1])
    elif kind == "bad_len":
        ln = rng.choice([0, 0, MAXLEN + 1, rng.getrandbits(32)])
    elif kind == "misaligned":
        if rng.random() < 0.5:
            src += rng.randint(1, SB - 1)
        else:
            dst += rng.randint(1, SB - 1)
    elif kind == "overflow":
        ln = rng.randint(2, 6 * SB)
        src = al(TOP - rng.randint(1, ln - 1)) if rng.random() < 0.5 else src
        dst = al(TOP - rng.randint(1, ln - 1)) if src == al(src) and rng.random() < 0.5 else dst
    elif kind == "overlap":
        dst = al(src + rng.randint(-ln, ln))
    elif kind == "region":
        side = rng.choice(["lo", "hi"])
        edge = SPM_BASE if side == "lo" else SPM_HI
        a = al(edge - rng.randint(1, 3) * SB)
        ln = max(ln, (edge - a) + 1)
        if rng.random() < 0.5:
            src = a
        else:
            dst = a
    elif kind == "edge":  # ranges that end exactly at / start exactly at a window edge (legal)
        nbt = rng.randint(1, 4)
        ln = nbt * SB - rng.choice([0, 0, 1 if SB > 1 else 0])
        a = {"below_base": SPM_BASE - nbt * SB, "at_base": SPM_BASE, "ends_at_hi": SPM_HI - nbt * SB, "at_hi": SPM_HI}[rng.choice(["below_base", "at_base", "ends_at_hi", "at_hi"])]
        if rng.random() < 0.5:
            src = a
        else:
            dst = a
    ln = max(0, min(ln, 0xFFFFFFFF))
    return kind, src & 0xFFFFFFFF, dst & 0xFFFFFFFF, ln


PROFILES = [("always", "always", "fixed:1", "fixed:1"), ("random:0.9", "random:0.9", "uniform:1-2", "uniform:1-3"), ("random:0.5", "random:0.5", "uniform:1-4", "uniform:1-2"),
            ("random:0.3", "random:0.4", "uniform:1-3", "fixed:4"), ("bursty:2-8", "bursty:1-5", "tail:1,0.2,10", "tail:2,0.2,8"), ("always", "random:0.4", "fixed:3", "fixed:1")]


@cocotb.test()
async def random_descriptors(dut):
    """Seeded random descriptor stream: all directions, legal / rejected / REGION, random stalls and latencies on both targets,
    random bus errors and aborts, random queue pressure."""
    b = AdapterBench(dut, seed_of(), cmd_gap="random:0.6", cpl_thr="random:0.5")
    await b.start()
    rng = b.rng
    n = {"ok": 0, "rej": 0, "bus": 0, "abort": 0}
    for rnd in range(14):
        rq, rs, lat, slat = rng.choice(PROFILES)
        b.set_stalls(rq, rs, lat, slat, cpl=rng.choice(["always", "random:0.5", "bursty:3-12"]))
        b.cmd.abort_noise = 0.02 if rng.random() < 0.4 else 0.0
        b.inject()
        for i in range(rng.randint(3, 9)):
            kind, s, d, ln = gen_desc(rng)
            desc = b.submit(s, d, ln)
            if rng.random() < 0.25 and S.validate(s, d, ln, SB, ACFG.max_len_log2) == S.E_NONE and A.expected_completion(s, d, ln, ACFG)[0] == S.E_NONE:
                nb = S.num_beats(ln, SB)
                b.inject_for(desc, rd_beats=[rng.randrange(nb)] if rng.random() < 0.5 else [], wr_beats=[rng.randrange(nb)] if rng.random() < 0.5 else [])
                await b.drain(60000)  # errors are per-address: keep them to one descriptor at a time
                b.inject()
        await b.drain(80000)
    for _, code in b.obs.outcomes:
        n["ok" if code == 0 else ("bus" if code in (8, 9) else ("abort" if code == 10 else "rej"))] += 1
    assert n["ok"] > 15 and n["rej"] > 8, n
    b.cmd.abort_noise = 0.0
    b.finish("random_descriptors", mix=n)


@cocotb.test()
async def reset_adapter(dut):
    """Reset with descriptors queued, a transfer running and completions pending: everything discarded, nothing presented after
    reset, the next descriptors work (async mid-cycle assertion included)."""
    b = AdapterBench(dut, seed_of(), cmd_gap="random:0.8", cpl_thr="random:0.3", req_thr="random:0.6", rsp_thr="random:0.7", latency="uniform:1-3")
    await b.start()
    rng = b.rng
    hits = 0
    for it in range(30):
        for i in range(rng.randint(1, 5)):
            kind, s, d, ln = gen_desc(rng)
            b.submit(s, d, ln if ln <= 3 * SB * 4 or kind in ("bad_len",) else 6 * SB)
        await b.env.cycles(rng.randint(2, 40))
        before = b.rst.n_pulses
        if it % 2:
            b.rst.pulse(length=rng.randint(1, 3), delay=1, reason="adapter")
            await b.env.cycles(2)
        else:
            cocotb.start_soon(b.rst.async_pulse(rng.choice([1.0, 3.0, 5.0, 8.5]), rng.randint(1, 3)))
            await b.env.cycles(2)
        await b.env.until(lambda: not b.rst.asserted, 50, "reset release")
        hits += b.rst.n_pulses > before
        await b.env.cycles(rng.randint(3, 10))
        assert not b.obs.descs and not b.obs.expected
        # a clean transfer proves the adapter recovered
        await b.run(EXT_A, SPM_BASE, 3 * SB + 1)
        b.expect_code(S.E_NONE)
    assert hits >= 20
    b.finish("reset_adapter", resets=hits)
