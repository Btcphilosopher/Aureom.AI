"""Reset behaviour of silicaflux_dma: reset (synchronous pulse and asynchronous mid-cycle assert) in every engine / bus
state, registers cleared, no request issued during or after reset until the next START, accepted-but-unacknowledged
writes handled as "may or may not have landed", recovery with a correct transfer afterwards."""
import os

import cocotb

from dma.dma_tb import CFG, MAXLEN, SB, Bench, S

SRC0 = 0x10000000
DST0 = 0x20000000


def seed_of() -> int:
    return int(os.environ.get("ALBION_SEED", "1"))


async def after_reset_checks(b: Bench, expect_idle_cycles: int = 8, strict: bool = True):
    """Reset released: every register back at its reset value (the model checks the values), no bus request,
    then a complete transfer works."""
    await b.env.until(lambda: not b.rst.asserted, 50, "reset release")
    noise = b.noise.enabled if b.noise else False
    if b.noise:
        b.noise.enabled = False
    await b.env.until(lambda: b.rb.idle, 50, "register bus idle")
    await b.env.cycles(3)
    for a in S.ALL_REGS:
        await b.rd(a)
    if strict:  # (without background register traffic the values are known without the model)
        assert await b.rd(S.SRC_ADDR) == 0 and await b.rd(S.DST_ADDR) == 0 and await b.rd(S.LENGTH) == 0
        assert await b.rd(S.STATUS) == 0 and await b.rd(S.INT_STATUS) == 0 and await b.rd(S.INT_ENABLE) == 0
    await b.env.cycles(expect_idle_cycles)
    await b.copy(SRC0 + 0x40, DST0 + 0x40, 3 * SB + 1)
    b.expect_outcome(S.E_NONE, 3 * SB + 1)
    if b.noise:
        b.noise.enabled = noise


@cocotb.test()
async def reset_sweep_sync(dut):
    """Synchronous reset pulse d cycles after START, d = 0 .. past the end of the transfer, for lengths and stall profiles
    that put the engine in every state (VALIDATE, ISSUE_*, WAIT_*, COMPLETE/ERROR, request presented and stalled)."""
    b = Bench(dut, seed_of())
    await b.start()
    nb = 5
    ln = nb * SB - 1
    profiles = [("always", "always", "fixed:1"), ("random:0.3", "random:0.4", "uniform:1-4")]
    count = 0
    for pi, (rq, rs, lat) in enumerate(profiles):
        b.set_stalls(rq, rs, lat)
        for d in range(0, 6 * nb + 6 if pi == 0 else 9 * nb + 6):
            if pi == 1 and d % 2:
                continue
            await b.program(SRC0, DST0, ln, ie=3)
            b.inject(wr=[DST0 + 2 * SB] if (pi == 1 and d % 4 == 0) else [], rd=[SRC0 + 3 * SB] if (pi == 0 and d % 4 == 3) else [])  # some runs end in an error state
            L = 1 + (d % 3)
            b.trig.when(lambda d=d: b.obs.since_start == d, lambda L=L: b.rst.pulse(length=L, delay=1, reason="sweep"))
            await b.go()
            await b.wait_idle()
            b.trig.clear()
            b.inject()
            if b.rst.n_pulses > count:
                count = b.rst.n_pulses
                await after_reset_checks(b)
            else:
                await b.rd(S.STATUS)
    assert count >= 20, "reset hit the transfer only %d times" % count
    b.finish("reset_sweep_sync", resets=count)


@cocotb.test()
async def reset_sweep_async(dut):
    """Asynchronous reset asserted between clock edges (several phases) at every cycle offset of a transfer."""
    b = Bench(dut, seed_of(), req_thr="random:0.6", rsp_thr="random:0.7", latency="uniform:1-3")
    await b.start()
    nb = 4
    ln = nb * SB
    count = 0
    phases = [1.0, 3.0, 5.0, 8.5]
    for d in range(0, 8 * nb + 8):
        await b.program(SRC0, DST0, ln, ie=3)
        await b.go()
        await b.env.cycles(d)
        before = b.rst.n_pulses
        b.obs.async_reset = True
        cocotb.start_soon(b.rst.async_pulse(phases[d % len(phases)], 1 + d % 3))
        await b.env.cycles(2)
        b.obs.async_reset = False
        await b.env.until(lambda: not b.rst.asserted, 50, "reset release")
        if b.rst.n_pulses > before:
            count += 1
            await after_reset_checks(b)
        else:
            await b.wait_idle()
    assert count >= 20
    b.finish("reset_sweep_async", resets=count)


@cocotb.test()
async def reset_states_armed(dut):
    """Reset armed on bus / FSM state predicates: write presented and stalled, read outstanding, write outstanding with
    later writes in flight, error response in flight, abort pending, terminal cycle, idle."""
    b = Bench(dut, seed_of(), rsp_thr="random:0.6", latency="uniform:1-4")
    await b.start()
    rng = b.rng
    obs = b.obs

    def wr_pres_stalled():
        r = obs.last
        return r is not None and any(v and w and not rdy for v, w, rdy in zip(r.valid, r.pres_write, r.ready))

    def rd_pres_stalled():
        r = obs.last
        return r is not None and any(v and (w is False) and not rdy for v, w, rdy in zip(r.valid, r.pres_write, r.ready))

    def outstanding():
        m = obs.model
        return m.active and m.xfer is not None and m.xfer.outstanding() > 0

    def two_outstanding():
        m = obs.model
        return m.active and m.xfer is not None and max(len(q) for q in m.xfer.out) >= min(2, CFG.out_limit) and m.xfer.writes_acc > 0

    def after_error():
        m = obs.model
        return m.active and m.xfer is not None and m.xfer.err_first is not None

    def terminal_cycle():
        m = obs.model
        r = obs.last
        return m.active and m.xfer is not None and (m.xfer.complete or m.xfer.err_first is not None or not m.xfer.valid) and not any(r.valid) and m.xfer.outstanding() == 0

    def abort_pending():
        m = obs.model
        return m.active and m.xfer is not None and m.xfer.abort_edge is not None

    preds = [("write_presented_stalled", wr_pres_stalled, False), ("read_presented_stalled", rd_pres_stalled, False), ("outstanding", outstanding, False),
             ("two_outstanding", two_outstanding, False), ("after_error", after_error, True), ("terminal_cycle", terminal_cycle, False), ("abort_pending", abort_pending, False)]
    hit = {}
    for rep in range(3):
        for name, pred, with_err in preds:
            b.set_stalls("random:0.35", "random:0.6", "uniform:1-4")
            b.inject(wr=[DST0 + 3 * SB] if with_err else [])
            await b.program(SRC0, DST0, 8 * SB + 1, ie=3)
            if name == "abort_pending":
                b.trig.when(lambda: obs.since_start == 7, lambda: b.rb.write_op(S.CONTROL, S.CTRL_ABORT))
            before = b.rst.n_pulses
            b.rst.arm(pred, length=1 + rep, reason=name)
            await b.go()
            await b.wait_idle()
            b.trig.clear()
            if b.rst.n_pulses > before:
                hit[name] = hit.get(name, 0) + 1
                await after_reset_checks(b)
            else:
                b.rst._armed.clear()
    b.inject()
    assert len(hit) >= 5, hit
    b.finish("reset_states_armed", hit=hit)


@cocotb.test()
async def random_reset(dut):
    """Random transfers with resets (synchronous and asynchronous) at random times, mixed with register traffic."""
    from dma.cocotb_dma_random import PROFILES, gen_desc

    b = Bench(dut, seed_of(), rb_gap="random:0.8")
    await b.start()
    b.add_noise(rate=0.15)
    rng = b.rng
    resets = 0
    for it in range(40):
        kind, src, dst, ln = gen_desc(rng)
        if rng.random() < 0.7:
            ln = min(ln, 8 * SB) if ln <= MAXLEN else ln
        rq, rs, lat = rng.choice(PROFILES)
        b.set_stalls(rq, rs, lat)
        b.inject()
        await b.program(src, dst, ln, ie=rng.getrandbits(2))
        before = b.rst.n_pulses
        d = rng.randint(0, 40)
        mode = rng.choice(["sync", "async", "none"])
        if mode == "sync":
            b.trig.when(lambda d=d: b.obs.since_start == d, lambda: b.rst.pulse(length=rng.randint(1, 4), delay=1, reason="random"))
        await b.go()
        if mode == "async":
            await b.env.cycles(d)
            b.obs.async_reset = True
            cocotb.start_soon(b.rst.async_pulse(rng.choice([0.5, 2.0, 4.0, 6.0, 9.0]), rng.randint(1, 3)))
            await b.env.cycles(2)
            b.obs.async_reset = False
        await b.wait_idle(40000)
        b.trig.clear()
        if b.rst.n_pulses > before:
            resets += 1
            await after_reset_checks(b, strict=False)
    assert resets >= 10, resets
    b.finish("random_reset", resets=resets)
