"""pytest integration: every registered suite case x seed becomes one test.

    python -m pytest tests -m "not slow"                 # model tests + fast smoke
    python -m pytest tests/test_suites.py --suite xbar_directed -n 4
    python -m pytest tests/test_suites.py --coverage     # Verilator code coverage build

Failing runs print the exact reproduction command and keep an FST waveform (reports/out/waves).
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
for p in (str(ROOT), str(ROOT / "tests")):
    if p not in sys.path:
        sys.path.insert(0, p)


def pytest_addoption(parser):
    g = parser.getgroup("albionverify")
    g.addoption("--suite", action="append", default=[], help="restrict suite tests to these suites")
    g.addoption("--tag", action="append", default=[], help="restrict suite tests to cases with one of these tags")
    g.addoption("--seeds", default=None, help="comma separated seeds overriding each case's seeds")
    g.addoption("--coverage", action="store_true", help="use Verilator code-coverage builds (reports/coverage)")
    g.addoption("--no-waves", action="store_true", help="do not re-run failures with waveform capture")
