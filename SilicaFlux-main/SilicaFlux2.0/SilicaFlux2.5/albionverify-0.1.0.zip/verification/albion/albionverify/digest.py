"""Trace digest: a rolling SHA-256 over the canonical event stream of a simulation.

Two runs with the same RTL, parameters and seed MUST produce the same digest; this is the machine-
checkable form of 'passing results are reproducible' (see tests/unit and `albion determinism`).
Only values that are a pure function of (RTL, seed) may be fed in: cycle numbers, addresses, data,
handshake outcomes.  Never feed wall-clock time, object ids or Python hash() values.
"""
from __future__ import annotations

import hashlib


class TraceDigest:
    def __init__(self):
        self._h = hashlib.sha256()
        self.n_events = 0

    def event(self, kind: str, *fields) -> None:
        s = kind + "|" + "|".join(_canon(f) for f in fields) + "\n"
        self._h.update(s.encode())
        self.n_events += 1

    def hexdigest(self) -> str:
        return self._h.hexdigest()

    def short(self) -> str:
        return self.hexdigest()[:16]


def _canon(v) -> str:
    if isinstance(v, bool):
        return "1" if v else "0"
    if isinstance(v, int):
        return "%x" % v if v >= 0 else "-%x" % (-v)
    if isinstance(v, (bytes, bytearray)):
        return bytes(v).hex()
    if isinstance(v, (list, tuple)):
        return "(" + ",".join(_canon(x) for x in v) + ")"
    return str(v)
