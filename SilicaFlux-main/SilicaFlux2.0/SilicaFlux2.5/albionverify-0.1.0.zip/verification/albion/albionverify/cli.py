"""`python -m albionverify <command>` (run from verification/albion)."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import rtl
from .suite import ROOT, Case, load_suites


def _select(suites, names):
    if not names or names == ["all"]:
        return list(suites.values())
    missing = [n for n in names if n not in suites]
    if missing:
        raise SystemExit("unknown suite(s): %s (known: %s)" % (missing, ", ".join(sorted(suites))))
    return [suites[n] for n in names]


def cmd_list(a):
    for s in load_suites().values():
        n = sum(len(c.seeds) for c in s.cases)
        print("%-18s %-9s %3d cases / %3d runs   mutants: %s   %s" % (s.name, s.subsystem, len(s.cases), n, s.mutants_file or "-", s.title))
        if a.verbose:
            for c in s.cases:
                print("    %-52s seeds=%s tags=%s" % (c.label, list(c.seeds), list(c.tags)))
    return 0


def cmd_vendor_check(a):
    p = rtl.verify_pins(strict=False)
    print("pinned RTL files: %d, problems: %d" % (len(rtl.manifest()["files"]), len(p)))
    for x in p[:20]:
        print("  ", x)
    print("rtl manifest digest:", rtl.manifest_digest())
    return 1 if p else 0


def cmd_doctor(a):
    """Check the toolchain against the versions the results were produced with."""
    import shutil
    from .sim.build import tool_versions

    tv = tool_versions()
    ok = True
    want = {"verilator": "5.0", "cocotb": "1.9"}
    for k, prefix in want.items():
        v = tv.get(k, "")
        good = (prefix in v) if k == "verilator" else v.startswith(prefix)
        ok &= good
        print("%-10s %-60s %s" % (k, v, "ok" if good else "UNTESTED VERSION (results were produced with Verilator 5.020 / cocotb 1.9.2)"))
    print("%-10s %s" % ("python", tv.get("python")))
    for t in ("make", "g++", "perl"):
        found = shutil.which(t)
        ok &= bool(found)
        print("%-10s %s" % (t, found or "MISSING"))
    print("%-10s %s" % ("iverilog", shutil.which("iverilog") or "not installed (needed only for the existing-code audit)"))
    try:
        import yaml  # noqa
        import numpy  # noqa
        print("python deps ok (pyyaml, numpy)")
    except ImportError as e:
        ok = False
        print("python deps MISSING:", e)
    return 0 if ok else 1


def cmd_run(a):
    from .sim.build import build_dut
    from .sim.runner import run_cocotb, run_with_waves_on_fail
    from .mutate.engine import load_mutants

    suites = load_suites()
    # locate the DUT spec by name
    duts = {d.name: d for s in suites.values() for d in s.duts()}
    if a.dut not in duts:
        raise SystemExit("unknown dut %r (known: %s)" % (a.dut, ", ".join(sorted(duts))))
    patches = ()
    tag = ""
    if a.mutant:
        from .mutate.engine import resolve_mutant

        try:
            sname, found = resolve_mutant(a.mutant, duts[a.dut], suites)
        except ValueError as e:
            raise SystemExit(str(e))
        patches = tuple(found.patches)
        tag = "mut-" + "".join(ch for ch in found.id if ch.isalnum())
    b = build_dut(duts[a.dut], coverage=a.coverage, patches=patches, tag=tag)
    r = run_cocotb(b, a.module, a.testcase, a.seed, mutant=a.mutant, waves=False)
    if not r.passed and a.waves:
        r = run_with_waves_on_fail(b, r)
    print(r.failure_summary() if not r.passed else "%s -> PASS  digests=%s  log=%s" % (r.test_id, r.digests, r.log))
    return 0 if r.passed else 1


def cmd_regress(a):
    from .regress import run_cases, write_regression
    from .sim.runner import out_root

    suites = load_suites()
    sel = _select(suites, a.suite)
    cases = [c for s in sel for c in s.cases if (not a.tag or set(a.tag) & set(c.tags))]
    if a.only:
        cases = [c for c in cases if a.only in c.label]
    if a.first_config_only:
        first = {}
        for s_ in sel:
            for c in s_.cases:
                first.setdefault(s_.name, c.dut.name)
        keep = set(first.values())
        cases = [c for c in cases if c.dut.name in keep]
    suite_of = {id(c): s.name for s in sel for c in s.cases}
    results = run_cases(cases, jobs=a.jobs, seeds=a.seeds, coverage=a.coverage, waves_on_fail=not a.no_waves, timeout_scale=a.timeout_scale, suite_of=suite_of)
    label = a.label or ("regression_" + ("_".join(s.name for s in sel) if len(sel) <= 3 else "all"))
    if a.only and not a.label:
        label += "_only_" + "".join(ch if ch.isalnum() else "_" for ch in a.only)[:40]  # a partial run must not overwrite the full run's reports
    from .regress import write_coverage

    doc = write_regression(results, Path(a.out) if a.out else ROOT / "reports" / "regression", label)
    cov = write_coverage(results, ROOT / "reports" / "coverage", label, with_code=a.coverage)
    print("functional coverage: %.1f%% of %d bins%s" % (cov["functional"]["overall_percent"], cov["functional"]["bins"],
          ("   | code coverage: line %s%% branch %s%% toggle %s%%" % tuple(cov["code"]["totals"][k]["percent"] for k in ("line", "branch", "toggle"))) if "code" in cov else ""))
    t = doc["totals"]
    print("\nTOTAL runs=%d %s checks=%d" % (t["runs"], " ".join("%s=%d" % (k, v) for k, v in t.items() if k not in ("runs", "checks")), t["checks"]))
    return 0 if all(r.ok for r in results) else 1


def cmd_mutate(a):
    from .mutate.engine import run_mutation, write_reports

    suites = load_suites()
    rc = 0
    for s in _select(suites, a.suite):
        if not s.mutants_file or not (ROOT / s.mutants_file).exists():
            print("[%s] no mutants file (%s), skipped" % (s.name, s.mutants_file))
            continue
        rep = run_mutation(s, a.ids, jobs=a.jobs, timeout_scale=a.timeout_scale)
        write_reports(rep, Path(a.out) if a.out else ROOT / "reports" / "mutation")
        if not rep.get("baseline_ok", True) or rep.get("n_survived", 0):
            rc = 1
        print("[%s] score=%s%% killed=%s survived=%s equiv=%s invalid=%s" % (s.name, rep.get("mutation_score_percent"), rep.get("n_killed"), rep.get("n_survived"), rep.get("n_equivalent_survived"), rep.get("n_invalid")))
    return rc


def cmd_determinism(a):
    from .regress import run_cases

    suites = load_suites()
    cases = [Case(c.dut, c.module, c.testcase, c.seeds[:1], c.timeout, c.tags) for s in _select(suites, a.suite) for c in s.cases]
    quiet = lambda *_: None
    r1 = run_cases(cases, jobs=a.jobs, waves_on_fail=False, progress=quiet)
    r2 = run_cases(cases, jobs=a.jobs, waves_on_fail=False, progress=quiet)
    d1 = {r.test_id: (r.status, r.digests) for r in r1}
    d2 = {r.test_id: (r.status, r.digests) for r in r2}
    mism = [k for k in d1 if d1[k] != d2.get(k)]
    out = {"runs": len(d1), "mismatches": mism, "reproducible": not mism, "digests": {k: v[1] for k, v in d1.items()}}
    sel_names = a.suite
    default_name = "determinism.json" if (not sel_names or sel_names == ["all"]) else "determinism_%s.json" % "_".join(sel_names)[:80]
    p = Path(a.out) if a.out else ROOT / "reports" / default_name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(out, indent=1))
    print("determinism: %d run(s) executed twice, %d mismatch(es)" % (len(d1), len(mism)))
    return 1 if mism else 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="albionverify", description="AlbionVerify: SilicaFlux functional hardware verification")
    sp = ap.add_subparsers(dest="cmd", required=True)
    p = sp.add_parser("list", help="list suites"); p.add_argument("-v", "--verbose", action="store_true"); p.set_defaults(fn=cmd_list)
    p = sp.add_parser("vendor-check", help="verify the vendored RTL pins"); p.set_defaults(fn=cmd_vendor_check)
    p = sp.add_parser("doctor", help="check the toolchain"); p.set_defaults(fn=cmd_doctor)
    p = sp.add_parser("run", help="run ONE test (also the reproduction command)")
    p.add_argument("--dut", required=True); p.add_argument("--module", required=True); p.add_argument("--testcase"); p.add_argument("--seed", type=int, default=1)
    p.add_argument("--mutant"); p.add_argument("--coverage", action="store_true"); p.add_argument("--waves", action="store_true", help="re-run with waveform capture if it fails"); p.set_defaults(fn=cmd_run)
    p = sp.add_parser("regress", help="run suites (all cases x seeds)")
    p.add_argument("--suite", nargs="*", default=["all"]); p.add_argument("-j", "--jobs", type=int, default=4); p.add_argument("--seeds", type=int, nargs="*")
    p.add_argument("--tag", nargs="*"); p.add_argument("--only"); p.add_argument("--first-config-only", action="store_true", help="per suite, run only its first DUT configuration (used for code-coverage collection)"); p.add_argument("--coverage", action="store_true"); p.add_argument("--no-waves", action="store_true")
    p.add_argument("--label"); p.add_argument("--out"); p.add_argument("--timeout-scale", type=float, default=1.0); p.set_defaults(fn=cmd_regress)
    p = sp.add_parser("mutate", help="mutation / fault-injection campaign")
    p.add_argument("--suite", nargs="*", default=["all"]); p.add_argument("--ids", nargs="*"); p.add_argument("-j", "--jobs", type=int, default=2)
    p.add_argument("--out"); p.add_argument("--timeout-scale", type=float, default=1.0); p.set_defaults(fn=cmd_mutate)
    p = sp.add_parser("determinism", help="run each suite's first seeds twice; digests must match")
    p.add_argument("--suite", nargs="*", default=["all"]); p.add_argument("-j", "--jobs", type=int, default=4); p.add_argument("--out"); p.set_defaults(fn=cmd_determinism)
    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
