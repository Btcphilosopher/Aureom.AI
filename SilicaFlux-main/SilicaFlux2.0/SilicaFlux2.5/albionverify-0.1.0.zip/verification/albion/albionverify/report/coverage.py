"""Coverage reporting.  FUNCTIONAL and CODE coverage are produced by separate functions into separate
output trees and are never combined into one number:

  functional  (what scenarios the stimulus exercised)   -> reports/coverage/functional/<label>.{json,md}
  code        (which RTL the simulator executed)        -> reports/coverage/code/<label>.{json,md,info}
              Verilator --coverage (line, branch, toggle); LCOV .info is emitted for external viewers.
"""
from __future__ import annotations

import json
import os
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

from ..coverage import merge_dicts, summarize


# ----------------------------------------------------------------------------- functional
def functional_report(result_runs: Sequence, outdir: Path, label: str) -> dict:
    """Merge every run's *.func_cov.json (sum of bin counts) PER DUT CONFIGURATION and write the summary.

    Bins can depend on the configuration (per-master/slave cross bins, region bins, ...).  Merging across
    configurations would let a hit in one configuration hide a hole in another, so groups are reported as
    ``<dut>::<group>`` and the overall figure is the bin-weighted total of the per-DUT summaries."""
    by_dut: Dict[str, List[dict]] = defaultdict(list)
    nfiles = 0
    for r in result_runs:
        for f in getattr(r, "func_cov_files", []) or []:
            try:
                by_dut[getattr(r, "dut", "?")].append(json.loads(Path(f).read_text()))
                nfiles += 1
            except (OSError, ValueError):
                pass
    merged: Dict[str, dict] = {}
    for dut, dicts in sorted(by_dut.items()):
        for g, gd in merge_dicts(dicts).items():
            merged["%s::%s" % (dut, g)] = gd
    summ = summarize(merged)
    summ["label"] = label
    summ["runs_merged"] = nfiles
    summ["duts"] = sorted(by_dut)
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / ("%s.json" % label)).write_text(json.dumps({"summary": summ, "merged": merged}, indent=1, sort_keys=True))
    lines = ["# Functional coverage: %s\n" % label,
             "Merged from %d test run(s) over %d DUT configuration(s), merged **per configuration** (never across configurations).  **Overall: %.1f%% (%d of %d defined bins hit).**  This is scenario coverage of the stimulus, not RTL code coverage.\n" % (nfiles, len(by_dut), summ["overall_percent"], summ["hit"], summ["bins"]),
             "| DUT :: group | bins | hit | % | samples |", "|---|---:|---:|---:|---:|"]
    for g, d in summ["groups"].items():
        lines.append("| %s | %d | %d | %.1f | %d |" % (g, d["bins"], d["hit"], d["percent"], d["samples"]))
    holes = [(g, h) for g, d in summ["groups"].items() for h in d["holes"]]
    if holes:
        lines.append("\n## Uncovered bins (%d)\n" % len(holes))
        for g, h in holes[:200]:
            lines.append("* `%s` %s" % (g, h))
        if len(holes) > 200:
            lines.append("* ... %d more in the JSON" % (len(holes) - 200))
    (outdir / ("%s.md" % label)).write_text("\n".join(lines) + "\n")
    return summ


# ----------------------------------------------------------------------------- code (Verilator coverage.dat)
def parse_coverage_dat(path: Path) -> Dict[Tuple[str, str, int, str, str], int]:
    """Parse a Verilator coverage.dat -> {(kind, file, line, comment, hier): count}.  kind in line|branch|toggle|other."""
    out: Dict[Tuple[str, str, int, str, str], int] = {}
    for raw in Path(path).read_text(errors="replace").splitlines():
        if not raw.startswith("C '"):
            continue
        key, _, cnt = raw[3:].rpartition("' ")
        fields = {}
        for part in key.split("\x01"):
            if "\x02" in part:
                k, v = part.split("\x02", 1)
                fields[k] = v
        page = fields.get("page", "")
        kind = "line" if page.startswith("v_line") else "branch" if page.startswith("v_branch") else "toggle" if page.startswith("v_toggle") else "other"
        k = (kind, fields.get("f", "?"), int(fields.get("l", 0) or 0), fields.get("o", ""), fields.get("h", ""))
        out[k] = out.get(k, 0) + int(cnt)
    return out


def code_report(result_runs: Sequence, outdir: Path, label: str, rtl_root: Optional[Path] = None) -> dict:
    """Merge coverage.dat of all runs (per hierarchy point, summing counts) and write json/md/lcov."""
    merged: Dict[Tuple[str, str, int, str, str], int] = defaultdict(int)
    nfiles = 0
    for r in result_runs:
        f = getattr(r, "code_cov_file", None)
        if f and Path(f).exists():
            for k, v in parse_coverage_dat(Path(f)).items():
                merged[k] += v
            nfiles += 1
    outdir.mkdir(parents=True, exist_ok=True)
    kinds = ("line", "branch", "toggle")
    tot = {k: [0, 0] for k in kinds}
    per_file: Dict[str, Dict[str, List[int]]] = defaultdict(lambda: {k: [0, 0] for k in kinds})
    lcov_lines: Dict[str, Dict[int, int]] = defaultdict(dict)
    for (kind, f, line, comment, hier), cnt in merged.items():
        if kind not in kinds:
            continue
        rel = os.path.relpath(f, rtl_root) if rtl_root and f.startswith(str(rtl_root)) else f
        tot[kind][1] += 1
        per_file[rel][kind][1] += 1
        if cnt > 0:
            tot[kind][0] += 1
            per_file[rel][kind][0] += 1
        if kind == "line":
            prev = lcov_lines[rel].get(line, 0)
            lcov_lines[rel][line] = prev + cnt

    def pct(h, t):
        return round(100.0 * h / t, 2) if t else None

    summ = {
        "label": label,
        "runs_merged": nfiles,
        "totals": {k: {"hit": v[0], "points": v[1], "percent": pct(*v)} for k, v in tot.items()},
        "files": {f: {k: {"hit": v[0], "points": v[1], "percent": pct(*v)} for k, v in d.items()} for f, d in sorted(per_file.items())},
        "note": "Verilator coverage points merged by hierarchy instance; a point is hit if any merged run executed it. Code coverage only -- independent of functional coverage.",
    }
    (outdir / ("%s.json" % label)).write_text(json.dumps(summ, indent=1))
    lines = ["# RTL code coverage (Verilator): %s\n" % label,
             "Merged from %d run(s).  Code coverage says which RTL was *executed*; it says nothing about whether the right scenarios or checks were exercised (see functional coverage and mutation reports).\n",
             "| metric | hit | points | % |", "|---|---:|---:|---:|"]
    lines[1] = lines[1] % nfiles
    for k in kinds:
        v = summ["totals"][k]
        lines.append("| %s | %d | %d | %s |" % (k, v["hit"], v["points"], v["percent"]))
    lines += ["", "| file | line % | branch % | toggle % |", "|---|---:|---:|---:|"]
    for f, d in summ["files"].items():
        lines.append("| %s | %s | %s | %s |" % (f, d["line"]["percent"], d["branch"]["percent"], d["toggle"]["percent"]))
    (outdir / ("%s.md" % label)).write_text("\n".join(lines) + "\n")
    info = []
    for f, ls in sorted(lcov_lines.items()):
        info.append("TN:%s" % label)
        info.append("SF:%s" % f)
        for ln in sorted(ls):
            info.append("DA:%d,%d" % (ln, ls[ln]))
        info.append("LF:%d" % len(ls))
        info.append("LH:%d" % sum(1 for v in ls.values() if v))
        info.append("end_of_record")
    (outdir / ("%s.info" % label)).write_text("\n".join(info) + "\n")
    return summ
