"""Aggregate regression / mutation / coverage / determinism / audit outputs into reports/SUMMARY.md.

Principles: every number comes from a result file written by an executed run; anything absent is
shown as "not run", never as zero-failures; functional and code coverage are different sections with
different meanings; known defects are listed separately from passes.
"""
from __future__ import annotations

import argparse
import json
from collections import OrderedDict, defaultdict
from pathlib import Path
from typing import Dict, List, Optional


def _rel(path: Optional[str]) -> str:
    """Show paths relative to the albion directory (reports are shipped to other machines)."""
    if not path:
        return "-"
    marker = "verification/albion/"
    return path.split(marker, 1)[1] if marker in path else path


def _load(p: Path) -> Optional[dict]:
    try:
        return json.loads(p.read_text())
    except (OSError, ValueError):
        return None


def _merge_regressions(reports: Path, labels) -> Optional[dict]:
    """Several regression labels (e.g. 'regression_part1', 'regression_part2') are merged into one view."""
    docs = [d for d in (_load(reports / "regression" / ("%s.json" % l)) for l in labels) if d]
    if not docs:
        return None
    out = dict(docs[0])
    out["results"] = [r for d in docs for r in d["results"]]
    tot: Dict[str, int] = defaultdict(int)
    for d in docs:
        for k, v in d["totals"].items():
            tot[k] += v
    out["totals"] = dict(tot)
    out["labels"] = list(labels)
    return out


def build(reports: Path, label="regression_all") -> str:
    labels = [label] if isinstance(label, str) else list(label)
    label = labels[0]
    md: List[str] = []
    A = md.append
    reg = _merge_regressions(reports, labels)
    A("# AlbionVerify regression report\n")
    if reg:
        tv = reg["tool_versions"]
        A("* generated: %s (first regression part; later parts and the mutation/coverage runs followed on the same day)" % reg["generated_utc"])
        A("* tools: Verilator `%s`, cocotb `%s`, Python `%s`" % (tv.get("verilator"), tv.get("cocotb"), tv.get("python")))
        A("* RTL under test (pinned set digest): `%s`" % reg["rtl_manifest_sha256"])
        t = reg["totals"]
        A("* **runs: %d** -- %s -- %d scoreboard/protocol checks evaluated\n" % (t["runs"], ", ".join("%s %d" % (k, v) for k, v in t.items() if k not in ("runs", "checks")), t["checks"]))
    else:
        A("*No regression results found (`reports/regression/%s.json`): the regression has not been run.*\n" % label)

    # ------------------------------------------------------------------ regression per suite
    if reg:
        A("## 1. Regression by suite\n")
        by: Dict[str, List[dict]] = defaultdict(list)
        for r in reg["results"]:
            by[r.get("suite") or r["dut"]].append(r)
        A("| suite | runs | PASS | FAIL/other | XFAIL (known defect) | checks | sim wall (s) |\n|---|---:|---:|---:|---:|---:|---:|")
        for s, rs in sorted(by.items()):
            eff = lambda r: ("XFAIL" if any(t.startswith("known_defect:") for t in r.get("tags", [])) and r["status"] != "PASS" else ("XPASS" if any(t.startswith("known_defect:") for t in r.get("tags", [])) else r["status"]))
            c = defaultdict(int)
            for r in rs:
                c[eff(r)] += 1
            other = sum(v for k, v in c.items() if k not in ("PASS", "XFAIL"))
            A("| %s | %d | %d | %d | %d | %d | %.0f |" % (s, len(rs), c["PASS"], other, c["XFAIL"], sum(r.get("checks", 0) for r in rs), sum(r.get("wall_s", 0) for r in rs)))
        if "ctl_core_fast" in by:
            A("\n*`ctl_core_fast` re-runs 4 of the 16 `ctl_core` cases (used to keep the determinism check affordable); its runs are included in the totals above.*")
        bad = [r for r in reg["results"] if r["status"] != "PASS"]
        if bad:
            A("\n### Non-passing runs\n")
            for r in bad:
                kd = [t for t in r.get("tags", []) if t.startswith("known_defect:")]
                A("* **%s** `%s`%s\n  * why: %s\n  * reproduce: `%s`\n  * waveform: `%s`" % (("XFAIL" if kd and r["status"] != "PASS" else ("XPASS" if kd else r["status"])), r["test_id"], (" (known defect " + kd[0].split(":", 1)[1] + ")") if kd else "", (r["cases"][0]["message"] if r["cases"] else "")[:260].replace("\n", " "), r["repro"], _rel(r.get("waves"))))
        else:
            A("\nAll runs passed.\n")

    # ------------------------------------------------------------------ reproducibility
    A("## 2. Reproducibility\n")
    dets = [d for d in (_load(f) for f in sorted(reports.glob("determinism*.json"))) if d]
    if dets:
        runs = sum(d["runs"] for d in dets)
        mism = [m for d in dets for m in d["mismatches"]]
        A("* determinism check: **%d** run(s) executed twice in fresh processes (%d file(s)); **%d mismatch(es)** of status/trace digest -> %s" % (runs, len(dets), len(mism), "REPRODUCIBLE" if not mism else "NOT REPRODUCIBLE: " + ", ".join(mism[:5])))
    else:
        A("* determinism check: **not run**")
    A("* every run's seed, build key and trace digest are recorded in `reports/regression/<label>.seeds.json` (labels: %s); non-passing runs list their exact reproduction command in `<label>.failures.txt`.\n" % ", ".join("`%s`" % l for l in labels))

    # ------------------------------------------------------------------ mutation
    A("## 3. Fault injection (mutation) -- do injected functional errors fail the tests?\n")
    muts = sorted((reports / "mutation").glob("*.json")) if (reports / "mutation").exists() else []
    rows = [d for d in (_load(m) for m in muts) if d]

    def mtable(rs, title):
        A("**%s**\n" % title)
        A("| suite | mutants | killed | survived | unobservable | argued-equivalent | invalid | score | kills by check | by RTL assertion | by hang/crash |\n|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
        k = sv = un = 0
        for d in rs:
            if not d.get("baseline_ok", True):
                A("| %s | – | **BASELINE FAILED** | | | | | | | | |" % d["suite"])
                continue
            A("| %s | %d | %d | %d | %d | %d | %d | %s%% | %d | %d | %d |" % (d["suite"], d["n_mutants"], d["n_killed"], d["n_survived"], d.get("n_unobservable_survived", 0), d["n_equivalent_survived"], d["n_invalid"], d["mutation_score_percent"], d["n_killed_by_check"], d.get("n_killed_by_rtl_assert", 0), d["n_killed_by_liveness_or_hang"]))
            k += d["n_killed"]; sv += d["n_survived"]; un += d.get("n_unobservable_survived", 0)
        A("\n**Total: %d killed, %d survived, %d unobservable-survived.**\n" % (k, sv, un))

    if rows:
        main = [d for d in rows if not d["suite"].startswith("heldout_")]
        held = [d for d in rows if d["suite"].startswith("heldout_")]
        mtable(main, "Block mutant sets (written by the bench authors; see docs/MUTATION_NOTES.md for the validity caveat)")
        if held:
            mtable(held, "HELD-OUT mutants (written by the lead after the benches were finished; the benches' own test cases, unchanged)")
        surv = [(d["suite"], m) for d in rows for m in d.get("mutants", []) if m["status"] in ("SURVIVED", "UNOBSERVABLE_SURVIVED")]
        if surv:
            A("### Survivors (verification gaps / limits)\n")
            for sname, m in surv:
                A("* `%s` / %s [%s] **%s**: %s" % (sname, m["id"], m["klass"], m["status"], m["desc"].replace("\n", " ")))
            A("")
    else:
        A("*No mutation results found: fault-injection campaigns have not been run.*\n")

    # ------------------------------------------------------------------ coverage
    A("## 4. Functional coverage (stimulus scenarios -- not RTL coverage)\n")
    fc = sorted((reports / "coverage" / "functional").glob("*.json")) if (reports / "coverage" / "functional").exists() else []
    if fc:
        for f in fc:
            d = _load(f)
            if not d:
                continue
            s_ = d["summary"]
            A("**%s**: %.1f%% (%d of %d defined bins hit) from %d test results over %d DUT configuration(s); merged per configuration, never across them" % (s_.get("label", f.stem), s_["overall_percent"], s_["hit"], s_["bins"], s_.get("runs_merged", 0), len(s_.get("duts", []))))
            per: Dict[str, List[int]] = defaultdict(lambda: [0, 0, 0])
            for g, gd in s_["groups"].items():
                dut = g.split("::", 1)[0]
                per[dut][0] += gd["bins"]; per[dut][1] += gd["hit"]; per[dut][2] += len(gd["holes"])
            holey = {k: v for k, v in per.items() if v[2]}
            A("\n| DUT configuration | bins | hit | uncovered |\n|---|---:|---:|---:|")
            for dut, (b_, h_, ho) in sorted(per.items()):
                if ho:
                    A("| %s | %d | %d | %d |" % (dut, b_, h_, ho))
            A("\n%d of %d configurations have every defined bin hit; per-group tables and the exact uncovered bins are in `reports/coverage/functional/%s.md`.\n" % (len(per) - len(holey), len(per), f.stem))
    else:
        A("*not collected*\n")
    A("## 5. RTL code coverage (Verilator line / branch / toggle -- separate from the above)\n")
    cc = sorted((reports / "coverage" / "code").glob("*.json")) if (reports / "coverage" / "code").exists() else []
    if cc:
        for f in cc:
            d = _load(f)
            if not d:
                continue
            t = d["totals"]
            rj = _load(reports / "regression" / ("%s.json" % d["label"]))
            ncfg = len({r["dut"] for r in rj["results"]}) if rj else "?"
            A("**%s** (%d runs merged, over %s DUT configurations -- the first configuration of each suite, `--first-config-only`): line %s%% (%d/%d), branch %s%% (%d/%d), toggle %s%% (%d/%d)" % (d["label"], d["runs_merged"], ncfg, t["line"]["percent"], t["line"]["hit"], t["line"]["points"], t["branch"]["percent"], t["branch"]["hit"], t["branch"]["points"], t["toggle"]["percent"], t["toggle"]["hit"], t["toggle"]["points"]))
        A("\nPer-file tables and LCOV `.info` files are in `reports/coverage/code/`.\n")
    else:
        A("*not collected (run `make coverage`)*\n")

    # ------------------------------------------------------------------ audit
    A("## 6. Existing-code audit headline\n")
    au = _load(reports / "audit" / "audit_summary.json")
    if au:
        v = au["compile_verilator"]; i = au["compile_icarus"]; tb = au["testbench_verdicts"]
        A("* %d unique RTL modules: Verilator lint PASS %d / FAIL %d; Icarus PASS %d / FAIL %d" % (au["rtl_modules_unique"], v.get("PASS", 0), v.get("FAIL", 0), i.get("PASS", 0), i.get("FAIL", 0)))
        A("* %d unique testbenches executed: %s" % (au["testbenches_unique"], ", ".join("%s %d" % kv for kv in sorted(tb.items()))))
        A("* %d unique RTL modules are in the hierarchy of a passing testbench; %d carry strong behavioural/stand-in evidence; %d modules exist in >1 different version" % (au["rtl_modules_in_hierarchy_of_passing_tb"], au["behavioural_strong"], au["modules_with_multiple_versions"]))
        A("* details: `reports/audit/AUDIT.md`\n")
    else:
        A("*audit results not present*\n")

    # ------------------------------------------------------------------ findings
    A("## 7. Findings and known defects\n")
    if reg:
        kd = [r for r in reg["results"] if any(t.startswith("known_defect:") for t in r.get("tags", []))]
        if kd:
            A("RTL defects/discrepancies reproduced by the regression (reported as XFAIL, not as passes):\n")
            for r in kd:
                tag = [t for t in r["tags"] if t.startswith("known_defect:")][0].split(":", 1)[1]
                A("* **%s** -- %s; reproduce: `%s`" % (tag, (r["cases"][0]["message"] if r["cases"] else "")[:170].replace("\n", " "), r["repro"]))
            A("")
    fdir = reports.parent / "docs"
    fs = sorted(fdir.glob("findings_*.md")) if fdir.exists() else []
    if fs:
        for f in fs:
            A("* `docs/%s`" % f.name)
    else:
        A("*no findings documents*")
    return "\n".join(md) + "\n"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--reports", default=str(Path(__file__).resolve().parents[2] / "reports"))
    ap.add_argument("--label", nargs="+", default=["regression_all"], help="one or more regression labels to merge")
    a = ap.parse_args(argv)
    r = Path(a.reports)
    (r / "SUMMARY.md").write_text(build(r, a.label))
    print("wrote", r / "SUMMARY.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
