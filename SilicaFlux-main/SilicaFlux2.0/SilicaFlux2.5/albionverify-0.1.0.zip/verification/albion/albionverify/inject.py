"""Error injectors: building blocks to provoke error paths deterministically.

Two kinds, both seeded/deterministic and both *stimulus only*: what the DUT must do in response is
always decided by the reference model written from the spec, never by the injector.

  ErrorPolicy   : decides whether a slave agent answers a request with an error response
                  (decode-style: by address range; random; every n-th; scripted by transaction index)
  Malformer     : turns a legal request into a malformed one (misaligned address, out-of-range address,
                  sparse/zero write strobes, reserved bits) and labels the malformation kind so coverage and
                  the reference model can classify it.

RTL-internal fault injection is done by the mutation engine (albionverify.mutate), not here.
"""
from __future__ import annotations

import random
from typing import Callable, Iterable, List, Optional, Sequence, Tuple


class ErrorPolicy:
    name = "none"

    def decide(self, req, index: int, cycle: int) -> bool:  # req is a bus.reqrsp.Req
        return False


class NoErrors(ErrorPolicy):
    pass


class AddrRangeErrors(ErrorPolicy):
    """Error on any access whose address falls in one of the [lo, hi) ranges."""

    name = "addr-range"

    def __init__(self, ranges: Sequence[Tuple[int, int]], writes_only: bool = False):
        self.ranges = list(ranges)
        self.writes_only = writes_only

    def decide(self, req, index, cycle) -> bool:
        if self.writes_only and not req.write:
            return False
        return any(lo <= req.addr < hi for lo, hi in self.ranges)


class RandomErrors(ErrorPolicy):
    name = "random"

    def __init__(self, rng: random.Random, p: float):
        self.rng, self.p = rng, p

    def decide(self, req, index, cycle) -> bool:
        return self.rng.random() < self.p


class EveryNth(ErrorPolicy):
    name = "every-nth"

    def __init__(self, n: int, offset: int = 0):
        self.n, self.offset = n, offset

    def decide(self, req, index, cycle) -> bool:
        return (index + self.offset) % self.n == self.n - 1


class AtIndices(ErrorPolicy):
    """Error on exactly the listed (0-based) request indices -- for scripted error-position sweeps."""

    name = "at-indices"

    def __init__(self, indices: Iterable[int], writes_only: Optional[bool] = None):
        self.indices = set(indices)
        self.wo = writes_only

    def decide(self, req, index, cycle) -> bool:
        if self.wo is True and not req.write:
            return False
        if self.wo is False and req.write:
            return False
        return index in self.indices


class AnyOf(ErrorPolicy):
    name = "any-of"

    def __init__(self, *policies: ErrorPolicy):
        self.policies = policies

    def decide(self, req, index, cycle) -> bool:
        return any(p.decide(req, index, cycle) for p in self.policies)


class Malformer:
    """Request mutations.  Each method returns (new_values_dict, label)."""

    def __init__(self, rng: random.Random, nbytes: int, addr_bits: int = 32):
        self.rng = rng
        self.nbytes = nbytes
        self.addr_bits = addr_bits

    def misaligned(self, addr: int) -> Tuple[int, str]:
        off = self.rng.randint(1, self.nbytes - 1) if self.nbytes > 1 else 0
        return (addr & ~(self.nbytes - 1)) | off, "misaligned"

    def out_of_range(self, bad_lo: int, bad_hi: int) -> Tuple[int, str]:
        a = self.rng.randrange(bad_lo, bad_hi) & ~(self.nbytes - 1)
        return a, "out-of-range"

    def sparse_strobe(self) -> Tuple[int, str]:
        s = 0
        while s in (0, (1 << self.nbytes) - 1):
            s = self.rng.getrandbits(self.nbytes)
        return s, "sparse-strobe"

    def zero_strobe(self) -> Tuple[int, str]:
        return 0, "zero-strobe"

    def wrap_boundary(self, length: int) -> Tuple[int, str]:
        """An address such that [addr, addr+length) wraps the address space."""
        a = ((1 << self.addr_bits) - self.nbytes * self.rng.randint(0, 3)) & ~(self.nbytes - 1)
        return a, "wraps-address-space"
