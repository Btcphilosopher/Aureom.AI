"""Regression driver: build every DUT once, run every (case x seed) in parallel, collect results,
optionally with code coverage and failed-test waveform capture."""
from __future__ import annotations

import json
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict
from pathlib import Path
from typing import Callable, Dict, List, Optional, Sequence, Tuple

from .sim.build import Built, DutSpec, build_dut, tool_versions
from .sim.runner import SimResult, out_root, run_cocotb, run_with_waves_on_fail
from .suite import Case, Suite
from . import rtl


def run_cases(
    cases: Sequence[Case],
    *,
    jobs: int = 4,
    seeds: Optional[Sequence[int]] = None,
    coverage: bool = False,
    waves_on_fail: bool = True,
    progress: Callable[[str], None] = print,
    timeout_scale: float = 1.0,
    suite_of: Optional[Dict[int, str]] = None,
) -> List[SimResult]:
    # build each distinct DUT once (serialised per build key by a file lock; parallel across DUTs)
    duts: Dict[str, DutSpec] = {}
    for c in cases:
        duts[c.dut.name] = c.dut
    built: Dict[str, Built] = {}
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=min(jobs, max(1, len(duts)))) as ex:
        futs = {ex.submit(build_dut, d, coverage=coverage): n for n, d in duts.items()}
        for fu in as_completed(futs):
            built[futs[fu]] = fu.result()
    progress("built %d DUT config(s) in %.0fs (coverage=%s)" % (len(built), time.time() - t0, coverage))
    jobs_list: List[Tuple[Case, int]] = []
    for c in cases:
        for s in (seeds if seeds else c.seeds):
            jobs_list.append((c, s))
    results: List[SimResult] = []

    def one(c: Case, s: int) -> SimResult:
        r = run_cocotb(built[c.dut.name], c.module, c.testcase, s, timeout=c.timeout * timeout_scale)
        r.tags = list(c.tags)
        r.suite = (suite_of or {}).get(id(c), "")
        if not r.passed and waves_on_fail:
            try:
                r = run_with_waves_on_fail(built[c.dut.name], r)
            except Exception as e:  # waveform capture must never mask the failure
                r.cases.append(__import__("albionverify.sim.runner", fromlist=["CaseResult"]).CaseResult("<waves>", "SKIP", "waveform capture failed: %r" % e))
        return r

    with ThreadPoolExecutor(max_workers=jobs) as ex:
        futs = {ex.submit(one, c, s): (c, s) for c, s in jobs_list}
        n = 0
        for fu in as_completed(futs):
            r = fu.result()
            results.append(r)
            n += 1
            progress("[%3d/%3d] %-7s %s  (%.1fs, checks=%d)" % (n, len(jobs_list), r.effective, r.test_id, r.wall_s, r.checks))
            if not r.ok:
                progress("          " + r.failure_summary().replace("\n", "\n          "))
    results.sort(key=lambda r: r.test_id)
    return results


def write_coverage(results: Sequence[SimResult], root: Path, label: str, with_code: bool) -> dict:
    """Functional and code coverage are written to SEPARATE trees and never merged into one figure."""
    from .report import coverage as cov

    out = {"functional": cov.functional_report(results, root / "functional", label)}
    if with_code:
        out["code"] = cov.code_report(results, root / "code", label, rtl.RTL_DIR)
    return out


def write_regression(results: Sequence[SimResult], outdir: Path, label: str = "regression", extra: Optional[dict] = None) -> dict:
    outdir.mkdir(parents=True, exist_ok=True)
    by_status: Dict[str, int] = {}
    for r in results:
        by_status[r.effective] = by_status.get(r.effective, 0) + 1
    doc = {
        "label": label,
        "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "tool_versions": tool_versions(),
        "rtl_manifest_sha256": rtl.manifest_digest(),
        "totals": {"runs": len(results), **by_status, "checks": sum(r.checks for r in results)},
        "results": [r.to_dict() for r in results],
    }
    if extra:
        doc.update(extra)
    (outdir / ("%s.json" % label)).write_text(json.dumps(doc, indent=1))
    # Reproduction artefacts: every run's seed + digest (so a PASS can be reproduced and compared), and a
    # ready-to-paste reproduction command + waveform path for every non-passing run.
    seeds = {r.test_id: {"seed": r.seed, "status": r.effective, "digests": r.digests, "build_key": r.build_key[:16]} for r in results}
    (outdir / ("%s.seeds.json" % label)).write_text(json.dumps(seeds, indent=1, sort_keys=True))
    bad = [r for r in results if not r.ok or r.effective == "XFAIL"]
    with open(outdir / ("%s.failures.txt" % label), "w") as f:
        f.write("# %d non-passing run(s) in '%s' (XFAIL = documented known defect)\n" % (len(bad), label))
        for r in bad:
            f.write("\n[%s] %s\n  seed:  %d\n  repro: %s\n  log:   %s\n  waves: %s\n  why:   %s\n" % (r.effective, r.test_id, r.seed, r.repro, r.log, r.waves or "-", (r.cases[0].message if r.cases else r.status)[:300].replace("\n", " ")))
    # JUnit (machine readable for any CI)
    import xml.etree.ElementTree as ET

    ts = ET.Element("testsuite", name=label, tests=str(len(results)), failures=str(sum(1 for r in results if not r.ok)))
    for r in results:
        tc = ET.SubElement(ts, "testcase", classname=r.dut + "." + r.module.split(".")[-1], name="%s[seed=%d]" % (r.testcase or "all", r.seed), time=str(r.wall_s))
        if r.effective == "XFAIL":
            ET.SubElement(tc, "skipped", message="known defect %s reproduces as documented" % r.known_defect)
        elif not r.ok:
            f = ET.SubElement(tc, "failure", message=(r.cases[0].message if r.cases else r.status)[:500], type=r.status)
            f.text = r.failure_summary()
        so = ET.SubElement(tc, "system-out")
        so.text = "repro: %s\ndigests: %s" % (r.repro, ",".join(r.digests))
    ET.ElementTree(ts).write(outdir / ("%s.junit.xml" % label), encoding="utf-8", xml_declaration=True)
    return doc
