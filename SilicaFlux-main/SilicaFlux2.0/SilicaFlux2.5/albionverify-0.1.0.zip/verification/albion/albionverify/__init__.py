"""AlbionVerify -- functional hardware verification environment for the SilicaFlux SystemVerilog architecture."""
__version__ = "0.1.0"
