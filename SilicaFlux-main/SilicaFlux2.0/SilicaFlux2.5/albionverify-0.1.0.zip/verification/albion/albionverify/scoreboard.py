"""Reference scoreboard with a request-conservation ledger.

Requirement implemented here: *every accepted request must produce the correct completion or an
explicitly defined cancellation*, and *actual data is checked, not merely transaction counts*.

  * ``accept(stream, key, expected)``  : a request was accepted by the DUT; ``expected`` is the
    reference model's prediction of the completion (data, error flag, ...).
  * ``complete(stream, key, observed, ...)`` : the DUT produced a completion; it is compared field by
    field against the prediction (hex diff on mismatch).
  * ``cancel(stream, reason)``          : explicit cancellation (reset, abort).  Each cancelled item is
    recorded with its reason; it can no longer be completed (a late completion is an error).
  * ``finalize()``                      : fails if anything is still outstanding, and checks the ledger
    identity  accepted == completed + cancelled.
"""
from __future__ import annotations

from collections import OrderedDict, deque
from typing import Any, Callable, Deque, Dict, Hashable, List, Optional

from .core import AlbionCheckError, Env


def hexdiff(exp: Any, got: Any) -> str:
    def f(x):
        if isinstance(x, int):
            return "0x%x" % x
        return repr(x)

    return "expected %s, got %s" % (f(exp), f(got))


class Scoreboard:
    def __init__(self, env: Env, name: str, ordered: bool = True):
        self.env = env
        self.name = name
        self.ordered = ordered
        self._exp: Dict[str, "OrderedDict[Hashable, Any]"] = {}
        self.accepted = 0
        self.completed = 0
        self.cancelled: List[dict] = []
        self.checks = 0
        self.errors: List[str] = []

    # ------------------------------------------------------------------ ledger
    def _q(self, stream: str) -> "OrderedDict[Hashable, Any]":
        return self._exp.setdefault(stream, OrderedDict())

    def accept(self, stream: str, key: Hashable, expected: Any) -> None:
        q = self._q(stream)
        if key in q:
            self.fail("duplicate key %r accepted on stream %s" % (key, stream))
        q[key] = expected
        self.accepted += 1
        self.env.digest.event("sb.accept", self.name, stream, key if isinstance(key, (int, str, tuple)) else str(key))

    def outstanding(self, stream: Optional[str] = None) -> int:
        if stream is not None:
            return len(self._exp.get(stream, ()))
        return sum(len(q) for q in self._exp.values())

    def complete(self, stream: str, key: Optional[Hashable] = None) -> Any:
        """Remove and return the expectation for a completion.  In ordered mode (key=None) the oldest."""
        q = self._q(stream)
        if not q:
            self.fail("completion on stream %s with nothing outstanding (response without request)" % stream)
            return None
        if key is None:
            if not self.ordered:
                self.fail("unordered scoreboard needs a key")
            k = next(iter(q))
        else:
            if self.ordered and key != next(iter(q)):
                self.fail("completion order violation on %s: got key %r, oldest outstanding is %r" % (stream, key, next(iter(q))))
            if key not in q:
                self.fail("completion for unknown/cancelled key %r on stream %s" % (key, stream))
                return None
            k = key
        exp = q.pop(k)
        self.completed += 1
        self.env.digest.event("sb.complete", self.name, stream, k if isinstance(k, (int, str, tuple)) else str(k))
        return exp

    def cancel(self, stream: Optional[str] = None, reason: str = "reset") -> List[Any]:
        """Explicitly cancel everything outstanding on ``stream`` (or all streams)."""
        out = []
        for s, q in self._exp.items():
            if stream is not None and s != stream:
                continue
            for k, e in list(q.items()):
                self.cancelled.append({"stream": s, "key": str(k), "reason": reason, "cycle": self.env.cycle})
                out.append((s, k, e))
                self.env.digest.event("sb.cancel", self.name, s, str(k), reason)
            q.clear()
        return out

    # ------------------------------------------------------------------ checks
    def check_eq(self, what: str, expected: Any, observed: Any, ctx: str = "") -> bool:
        self.checks += 1
        if expected != observed:
            self.fail("%s mismatch%s: %s" % (what, (" [%s]" % ctx) if ctx else "", hexdiff(expected, observed)))
            return False
        return True

    def check(self, cond: bool, msg: str) -> bool:
        self.checks += 1
        if not cond:
            self.fail(msg)
        return bool(cond)

    def fail(self, msg: str) -> None:
        full = "[%s/%s @cycle %d] %s" % (self.env.name, self.name, self.env.cycle, msg)
        self.errors.append(full)
        self.env.errors.append(full)
        if self.env.fail_fast:
            raise AlbionCheckError(full)

    def finalize(self, allow_outstanding: bool = False) -> None:
        left = self.outstanding()
        if left and not allow_outstanding:
            detail = {s: list(q)[:4] for s, q in self._exp.items() if q}
            self.fail("%d accepted request(s) never completed nor cancelled: %s" % (left, detail))
        ident = self.accepted == self.completed + len(self.cancelled) + left
        self.checks += 1
        if not ident:
            self.fail("ledger identity broken: accepted=%d completed=%d cancelled=%d outstanding=%d" % (self.accepted, self.completed, len(self.cancelled), left))

    def summary(self) -> dict:
        return {
            "accepted": self.accepted,
            "completed": self.completed,
            "cancelled": len(self.cancelled),
            "outstanding": self.outstanding(),
            "checks": self.checks,
            "errors": len(self.errors),
        }
