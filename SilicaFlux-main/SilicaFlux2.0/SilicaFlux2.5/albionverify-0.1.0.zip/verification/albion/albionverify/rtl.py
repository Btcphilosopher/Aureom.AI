"""Access to the vendored, pinned RTL (rtl/MANIFEST.json).

A build is a pure function of the manifest: file lists and include directories are read from it,
never re-discovered, and ``verify_pins`` re-hashes every vendored file so an accidental edit of the
RTL under test is detected before any result is produced.
"""
from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path
from typing import Dict, List, Optional

ROOT = Path(__file__).resolve().parent.parent  # verification/albion
RTL_DIR = ROOT / "rtl"


@lru_cache(maxsize=1)
def manifest() -> dict:
    return json.loads((RTL_DIR / "MANIFEST.json").read_text())


def dut_sources(top: str) -> List[Path]:
    """Ordered source files (packages first) for DUT ``top``."""
    return [RTL_DIR / f for f in manifest()["duts"][top]["files"]]


def dut_rel_sources(top: str) -> List[str]:
    return list(manifest()["duts"][top]["files"])


def dut_incdirs(top: str) -> List[Path]:
    return [RTL_DIR / d for d in manifest()["duts"][top]["incdirs"]]


def file_sha(relpath: str) -> str:
    return manifest()["files"][relpath]["sha256"]


def doc_dir(project: str) -> Path:
    return RTL_DIR / project


def verify_pins(strict: bool = True) -> List[str]:
    """Re-hash every vendored file.  Returns a list of problems (empty = all pins intact)."""
    problems: List[str] = []
    for rel, info in manifest()["files"].items():
        p = RTL_DIR / rel
        if not p.exists():
            problems.append("missing: %s" % rel)
            continue
        h = hashlib.sha256(p.read_bytes()).hexdigest()
        if h != info["sha256"]:
            problems.append("modified: %s (pinned %s, found %s)" % (rel, info["sha256"][:12], h[:12]))
    if problems and strict:
        raise RuntimeError("vendored RTL does not match rtl/MANIFEST.json:\n  " + "\n  ".join(problems[:10]))
    return problems


def manifest_digest() -> str:
    """One hash over all pinned file hashes: identifies 'the RTL under test' in every report."""
    h = hashlib.sha256()
    for rel in sorted(manifest()["files"]):
        h.update(rel.encode())
        h.update(manifest()["files"][rel]["sha256"].encode())
    return h.hexdigest()
