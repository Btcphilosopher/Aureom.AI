"""Generic request/response bus agents (SFB2 and SRAM-core style ports).

  ReqRspMaster   drives requests into a DUT port, accepts responses            (transaction driver)
  ReqRspSlave    accepts requests from a DUT port, answers from a memory model (response generator)
  ReqRspMonitor  passive: reconstructs transactions + checks protocol rules    (protocol/response monitor)

Handshake convention (matches docs/FRAMEWORK.md): a transfer happens at a rising edge where
``valid && ready`` were both high *before* the edge; agents sample at the edge and drive for the next
cycle.  A master holds a presented request unchanged until accepted (SFB2 R2) and never withdraws it.
"""
from __future__ import annotations

import random
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Deque, Dict, List, Optional

from ..core import Agent, Const, Env, Sig
from ..inject import ErrorPolicy, NoErrors
from ..memory import BackingStore
from ..rng import Latency, Throttle

# --------------------------------------------------------------------------- data


@dataclass
class Req:
    write: bool
    addr: int
    wdata: int = 0
    strb: Optional[int] = None  # None => all lanes (write) / 0 (read)
    id: int = 0
    tag: Any = None  # free-form, test use (labels, expected results)


@dataclass
class Rsp:
    rdata: int = 0
    err: bool = False
    id: int = 0
    we: Optional[bool] = None


@dataclass
class Txn:
    req: Req
    seq: int = 0
    rsp: Optional[Rsp] = None
    t_present: Optional[int] = None  # first cycle the request was presented
    t_accept: Optional[int] = None  # edge at which the request was accepted
    t_rsp: Optional[int] = None  # edge at which the response was accepted
    cancelled: Optional[str] = None
    req_stall_cycles: int = 0
    rsp_stall_cycles: int = 0
    posted: bool = False  # accepted and complete at acceptance: the protocol gives it no response (posted write)

    @property
    def done(self) -> bool:
        return self.rsp is not None or self.cancelled is not None or self.posted

    @property
    def latency(self) -> Optional[int]:
        return None if self.t_rsp is None or self.t_accept is None else self.t_rsp - self.t_accept


# --------------------------------------------------------------------------- port presets

SFB_NAMES = dict(valid="req_valid", ready="req_ready", write="req_write", addr="req_addr", wdata="req_wdata", strb="req_wstrb", rvalid="rsp_valid", rready="rsp_ready", rdata="rsp_rdata", err="rsp_error")
SRAMCORE_NAMES = dict(valid="req_valid", ready="req_ready", write="req_we", addr="req_addr", wdata="req_wdata", strb="req_wmask", id="req_id", rvalid="rsp_valid", rready="rsp_ready", rdata="rsp_rdata", err="rsp_err", rid="rsp_id", rwe="rsp_we")


def make_port(env: Env, names: Dict[str, Optional[str]], *, prefix: str = "", index: int = 0, flat: bool = False, AW: int = 32, DW: int = 32, IDW: int = 0, strb_w: Optional[int] = None) -> Dict[str, Any]:
    """Build the field->Sig map for one port.  ``flat=True`` means every signal is a vector with one
    field per port (``[index*W +: W]``), as on ``sfb_crossbar`` and the multi-port DMA."""
    widths = {"valid": 1, "ready": 1, "write": 1, "addr": AW, "wdata": DW, "strb": strb_w or DW // 8, "rvalid": 1, "rready": 1, "rdata": DW, "err": 1, "id": IDW, "rid": IDW, "rwe": 1}
    port: Dict[str, Any] = {}
    for k, nm in names.items():
        if nm is None or (k in ("id", "rid") and IDW == 0):
            port[k] = Const(0)
            continue
        full = prefix + nm
        if flat:
            port[k] = env.sig(full, lo=index * widths[k], width=widths[k])
        else:
            port[k] = env.sig(full)
    for k in ("id", "rid", "rwe"):
        port.setdefault(k, Const(0))
    return port


def sfb_port(env: Env, prefix: str = "", index: int = 0, flat: bool = False, AW: int = 32, DW: int = 32) -> Dict[str, Any]:
    return make_port(env, SFB_NAMES, prefix=prefix, index=index, flat=flat, AW=AW, DW=DW)


def sramcore_port(env: Env, prefix: str = "", index: int = 0, flat: bool = False, AW: int = 32, DW: int = 32, IDW: int = 0, MW: Optional[int] = None) -> Dict[str, Any]:
    return make_port(env, SRAMCORE_NAMES, prefix=prefix, index=index, flat=flat, AW=AW, DW=DW, IDW=IDW, strb_w=MW)


def _full_strobe(nbytes: int) -> int:
    return (1 << nbytes) - 1


# --------------------------------------------------------------------------- master


class ReqRspMaster(Agent):
    """Transaction driver.  ``submit()`` queues requests; ``max_outstanding`` bounds accepted-but-not-
    completed transactions the *agent* will tolerate before presenting another (a DUT with its own
    one-outstanding rule simply delays acceptance)."""

    def __init__(self, name: str, port: Dict[str, Any], *, nbytes: int = 4, rng: Optional[random.Random] = None,
                 req_throttle: str = "always", rsp_throttle: str = "always", max_outstanding: int = 1,
                 match: str = "order", idle_garbage: bool = True, AW: int = 32, IDW: int = 0,
                 expects_response=None):
        """``expects_response(req) -> bool``: False for requests the protocol never answers (posted writes,
        e.g. an SRAM with WRITE_ACK=0).  Such a request completes at acceptance (``txn.posted``), is not
        counted as outstanding, and listeners get ``txn_posted`` instead of ``txn_completed``."""
        super().__init__(name)
        self.p = port
        self.expects_response = expects_response
        self.nbytes = nbytes
        self.rng = rng or random.Random(0)
        self.req_thr = Throttle(self.rng, req_throttle)
        self.rsp_thr = Throttle(self.rng, rsp_throttle)
        self.max_out = max_outstanding
        self.match = match
        self.garbage = idle_garbage
        self.AW, self.IDW = AW, IDW
        self.queue: Deque[Txn] = deque()
        self.cur: Optional[Txn] = None
        self.outstanding: Deque[Txn] = deque()
        self.done: List[Txn] = []
        self.cancelled: List[Txn] = []
        self.listeners: List[Any] = []
        self._seq = 0
        self._v = False  # valid driven during the elapsed cycle
        self._rr = False  # rsp_ready driven during the elapsed cycle
        self.req_stall_run = 0
        self.max_req_stall = 0
        self.max_rsp_stall = 0
        self._rsp_stall_run = 0
        self.n_accepted = 0
        self.n_completed = 0

    # ---- stimulus API
    def submit(self, req: Req) -> Txn:
        self._seq += 1
        t = Txn(req=req, seq=self._seq)
        self.queue.append(t)
        return t

    def write(self, addr: int, data: int, strb: Optional[int] = None, **kw) -> Txn:
        return self.submit(Req(True, addr, data, strb, **kw))

    def read(self, addr: int, **kw) -> Txn:
        return self.submit(Req(False, addr, **kw))

    @property
    def idle(self) -> bool:
        return not self.queue and self.cur is None and not self.outstanding

    def _notify(self, what: str, txn: Txn) -> None:
        for l in self.listeners:
            fn = getattr(l, what, None)
            if fn:
                fn(self, txn)

    # ---- agent
    def sample(self) -> None:
        env, c = self.env, self.env.cycle
        in_rst = env.in_reset
        had_out = len(self.outstanding) > 0  # accepted at an EARLIER edge (SFB2 R5: never same-cycle)
        # ---- response channel (handled first: it can only belong to an earlier-accepted request)
        if not in_rst and self.p["rvalid"].read():
            if self._rr:
                rsp = Rsp(self.p["rdata"].read(), bool(self.p["err"].read()), self.p["rid"].read() if self.IDW else 0, bool(self.p["rwe"].read()))
                t = self._match(rsp) if had_out else None
                if t is None:
                    env.error("%s: response with no earlier accepted request (rdata=0x%x err=%d)" % (self.name, rsp.rdata, rsp.err))
                else:
                    t.rsp, t.t_rsp = rsp, c
                    t.rsp_stall_cycles = self._rsp_stall_run
                    self.max_rsp_stall = max(self.max_rsp_stall, self._rsp_stall_run)
                    self._rsp_stall_run = 0
                    self.done.append(t)
                    self.n_completed += 1
                    env.digest.event("m.rsp", self.name, c, t.seq, rsp.rdata, int(rsp.err))
                    self._notify("txn_completed", t)
            else:
                self._rsp_stall_run += 1
                self.max_rsp_stall = max(self.max_rsp_stall, self._rsp_stall_run)
        # ---- request channel
        if self._v and not in_rst:
            if self.p["ready"].read():
                t = self.cur
                t.t_accept = c
                t.req_stall_cycles = self.req_stall_run
                self.max_req_stall = max(self.max_req_stall, self.req_stall_run)
                self.req_stall_run = 0
                self.cur = None
                self.n_accepted += 1
                env.digest.event("m.acc", self.name, c, t.seq)
                self._notify("txn_accepted", t)
                if self.expects_response is not None and not self.expects_response(t.req):
                    t.posted, t.t_rsp = True, c
                    self.done.append(t)
                    self.n_completed += 1
                    self._notify("txn_posted", t)
                else:
                    self.outstanding.append(t)
            else:
                self.req_stall_run += 1
                self.max_req_stall = max(self.max_req_stall, self.req_stall_run)

    def _match(self, rsp: Rsp) -> Optional[Txn]:
        if not self.outstanding:
            return None
        if self.match == "id":
            for t in self.outstanding:
                if t.req.id == rsp.id:
                    self.outstanding.remove(t)
                    return t
            return None
        return self.outstanding.popleft()

    def drive(self) -> None:
        env, c = self.env, self.env.cycle
        p = self.p
        if env.in_reset:
            self._v = False
            self._rr = False
            p["valid"].write(0)
            p["rready"].write(0)
            return
        if self.cur is None and self.queue and len(self.outstanding) < self.max_out and self.req_thr.allow():
            self.cur = self.queue.popleft()
            self.cur.t_present = c
        if self.cur is not None:
            r = self.cur.req
            p["valid"].write(1)
            p["write"].write(1 if r.write else 0)
            p["addr"].write(r.addr)
            p["wdata"].write(r.wdata if r.write else (self.rng.getrandbits(self.nbytes * 8) if self.garbage else 0))
            strb = (_full_strobe(self.nbytes) if r.strb is None else r.strb) if r.write else (r.strb or 0)
            p["strb"].write(strb)
            if self.IDW:
                p["id"].write(r.id)
            self._v = True
        else:
            p["valid"].write(0)
            if self.garbage:
                p["write"].write(self.rng.getrandbits(1))
                p["addr"].write(self.rng.getrandbits(self.AW))
                p["wdata"].write(self.rng.getrandbits(self.nbytes * 8))
                p["strb"].write(self.rng.getrandbits(self.nbytes))
                if self.IDW:
                    p["id"].write(self.rng.getrandbits(self.IDW))
            self._v = False
        self._rr = self.rsp_thr.allow()
        p["rready"].write(1 if self._rr else 0)

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            for t in ([self.cur] if self.cur else []) + list(self.outstanding):
                t.cancelled = "reset-not-accepted" if t.t_accept is None else "reset"
                self.cancelled.append(t)
                self._notify("txn_cancelled", t)
            self.cur = None
            self.outstanding.clear()
            self._v = False
            self._rr = False
            self.req_stall_run = 0
            self._rsp_stall_run = 0
            # queued-but-never-presented requests are dropped: the test re-submits after reset
            for t in self.queue:
                t.cancelled = "reset-flushed"
                self.cancelled.append(t)
            self.queue.clear()

    def summary(self) -> dict:
        return {"accepted": self.n_accepted, "completed": self.n_completed, "cancelled": len(self.cancelled), "max_req_stall": self.max_req_stall, "max_rsp_stall": self.max_rsp_stall}


# --------------------------------------------------------------------------- slave


@dataclass
class _Pending:
    req: Req
    rdata: int
    err: bool
    due: int
    index: int
    t_accept: int


class ReqRspSlave(Agent):
    """Response generator backed by a ``BackingStore``.  Writes are applied at acceptance (so the write
    has been performed before its response, SFB2 R7); errors have no side effect and return rdata=0 (R8)."""

    def __init__(self, name: str, port: Dict[str, Any], *, memory: Optional[BackingStore] = None, nbytes: int = 4,
                 rng: Optional[random.Random] = None, req_throttle: str = "always", rsp_throttle: str = "always",
                 latency: str = "fixed:1", error_policy: Optional[ErrorPolicy] = None, max_pending: int = 1,
                 IDW: int = 0, echo_we: bool = False, posted_writes: bool = False):
        """``posted_writes=True``: writes are performed but never answered (no response queued)."""
        super().__init__(name)
        self.posted_writes = posted_writes
        self.p = port
        self.mem = memory if memory is not None else BackingStore("zero", name)
        self.nbytes = nbytes
        self.rng = rng or random.Random(0)
        self.req_thr = Throttle(self.rng, req_throttle)
        self.rsp_thr = Throttle(self.rng, rsp_throttle)
        self.lat = Latency(self.rng, latency)
        self.policy = error_policy or NoErrors()
        self.max_pending = max_pending
        self.IDW = IDW
        self.echo_we = echo_we
        self.pending: Deque[_Pending] = deque()
        self.log: List[Req] = []  # every accepted request, in order
        self.listeners: List[Any] = []
        self._rdy = False
        self._rv = False
        self.n_err = 0
        self.index = 0

    def _notify(self, what: str, *a) -> None:
        for l in self.listeners:
            fn = getattr(l, what, None)
            if fn:
                fn(self, *a)

    def sample(self) -> None:
        env, c = self.env, self.env.cycle
        p = self.p
        if env.in_reset:
            return
        if self._rdy and p["valid"].read():
            wr = bool(p["write"].read())
            addr = p["addr"].read()
            wdata = p["wdata"].read()
            strb = p["strb"].read()
            rid = p["id"].read() if self.IDW else 0
            req = Req(wr, addr, wdata if wr else 0, strb, rid)
            err = self.policy.decide(req, self.index, c) or not self.mem.in_range(addr & ~(self.nbytes - 1), self.nbytes)
            rdata = 0
            if not err:
                if wr:
                    self.mem.write_word(addr & ~(self.nbytes - 1), wdata, strb, self.nbytes)
                else:
                    rdata = self.mem.read_word(addr & ~(self.nbytes - 1), self.nbytes)
            else:
                self.n_err += 1
            lat = max(1, self.lat.next())
            if not (self.posted_writes and wr):
                self.pending.append(_Pending(req, rdata, err, c + lat - 1, self.index, c))
            self.log.append(req)
            env.digest.event("s.acc", self.name, c, int(wr), addr, wdata if wr else 0, strb, int(err))
            self._notify("req_accepted", req, err, rdata)
            self.index += 1
        if self._rv and p["rready"].read():
            self._notify("rsp_accepted", self.pending[0])  # response handshake (listeners: order of error responses, etc.)
            self.pending.popleft()
            self._rv = False
            env.digest.event("s.rsp", self.name, c)

    def drive(self) -> None:
        env, c = self.env, self.env.cycle
        p = self.p
        if env.in_reset:
            p["ready"].write(0)
            p["rvalid"].write(0)
            self._rdy = False
            self._rv = False
            return
        self._rdy = self.req_thr.allow() and len(self.pending) < self.max_pending
        p["ready"].write(1 if self._rdy else 0)
        head = self.pending[0] if self.pending else None
        if head is not None and (self._rv or (c >= head.due and self.rsp_thr.allow())):
            self._rv = True
            p["rvalid"].write(1)
            p["rdata"].write(head.rdata)
            p["err"].write(1 if head.err else 0)
            if self.IDW:
                p["rid"].write(head.req.id)
            if self.echo_we:
                p["rwe"].write(1 if head.req.write else 0)
        else:
            p["rvalid"].write(0)
            p["rdata"].write(self.rng.getrandbits(self.nbytes * 8))  # garbage when invalid
            p["err"].write(self.rng.getrandbits(1))
            self._rv = False

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            for pd in self.pending:
                self._notify("req_cancelled", pd.req)
            self.pending.clear()
            self._rdy = False
            self._rv = False

    def summary(self) -> dict:
        return {"accepted": len(self.log), "errors": self.n_err}


# --------------------------------------------------------------------------- monitor


class ReqRspMonitor(Agent):
    """Passive protocol checker + transaction reconstruction for one port."""

    def __init__(self, name: str, port: Dict[str, Any], *, nbytes: int = 4, IDW: int = 0, sfb2: bool = True,
                 outstanding_limit: Optional[int] = None, allow_withdraw: bool = False, expects_response=None):
        super().__init__(name)
        self.expects_response = expects_response  # see ReqRspMaster: posted requests are never added to 'outstanding'
        self.p = port
        self.nbytes = nbytes
        self.IDW = IDW
        self.sfb2 = sfb2
        self.limit = outstanding_limit
        self.allow_withdraw = allow_withdraw
        self.outstanding: Deque[Txn] = deque()
        self.txns: List[Txn] = []
        self.cancelled: List[Txn] = []
        self.listeners: List[Any] = []
        self._seq = 0
        self._prev_req: Optional[tuple] = None  # (payload) if valid&&!ready last edge
        self._prev_rsp: Optional[tuple] = None
        self.req_stall_run = 0
        self.rsp_stall_run = 0
        self.max_req_stall = 0
        self.max_rsp_stall = 0
        self.stall_hist: Dict[int, int] = {}
        self.n_checks = 0
        self.max_outstanding_seen = 0

    def _notify(self, what: str, txn: Txn) -> None:
        for l in self.listeners:
            fn = getattr(l, what, None)
            if fn:
                fn(self, txn)

    def _chk(self, cond: bool, msg: str) -> None:
        self.n_checks += 1
        if not cond:
            self.env.error("%s: PROTOCOL VIOLATION: %s" % (self.name, msg))

    def sample(self) -> None:
        env, c = self.env, self.env.cycle
        p = self.p
        if env.in_reset:
            self._prev_req = self._prev_rsp = None
            return
        v, rdy = p["valid"].read(), p["ready"].read()
        rv, rr = p["rvalid"].read(), p["rready"].read()
        # ---- R2: a stalled request must persist, payload unchanged
        payload = None
        if v:
            wr = p["write"].read()
            payload = (wr, p["addr"].read(), p["wdata"].read() if wr else None, p["strb"].read(), p["id"].read() if self.IDW else 0)
        if self._prev_req is not None and not self.allow_withdraw:
            self._chk(bool(v), "R2: request withdrawn before acceptance (valid dropped while stalled)")
            if v:
                self._chk(payload == self._prev_req, "R2: request payload changed while stalled: %s -> %s" % (self._prev_req, payload))
        # ---- R4: a stalled response must persist, payload unchanged
        rpay = None
        if rv:
            rpay = (p["rdata"].read(), p["err"].read(), p["rid"].read() if self.IDW else 0)
        if self._prev_rsp is not None:
            self._chk(bool(rv), "R4: response withdrawn before acceptance (rsp_valid dropped while stalled)")
            if rv:
                self._chk(rpay == self._prev_rsp, "R4: response payload changed while stalled: %s -> %s" % (self._prev_rsp, rpay))
        had_outstanding = len(self.outstanding) > 0  # requests accepted at *earlier* edges
        # ---- response handshake
        if rv and rr:
            self._chk(had_outstanding, "R5: response transferred with no earlier accepted request")
            if self.sfb2:
                self._chk(not (rpay[1] and rpay[0] != 0), "R8: rsp_error=1 but rsp_rdata=0x%x (must be 0)" % rpay[0])
            if had_outstanding:
                t = self.outstanding.popleft()
                t.rsp = Rsp(rpay[0], bool(rpay[1]), rpay[2])
                t.t_rsp = c
                self.txns.append(t)
                env.digest.event("mon.rsp", self.name, c, t.seq, rpay[0], rpay[1])
                self._notify("txn_completed", t)
            self.rsp_stall_run = 0
        elif rv and not rr:
            self.rsp_stall_run += 1
            self.max_rsp_stall = max(self.max_rsp_stall, self.rsp_stall_run)
        # ---- request handshake
        if v and rdy:
            self._seq += 1
            t = Txn(Req(bool(payload[0]), payload[1], payload[2] or 0, payload[3], payload[4]), seq=self._seq, t_accept=c)
            t.req_stall_cycles = self.req_stall_run
            self.stall_hist[self.req_stall_run] = self.stall_hist.get(self.req_stall_run, 0) + 1
            self.max_req_stall = max(self.max_req_stall, self.req_stall_run)
            self.req_stall_run = 0
            if self.expects_response is not None and not self.expects_response(t.req):
                t.posted, t.t_rsp = True, c
                self.txns.append(t)
                env.digest.event("mon.req", self.name, c, t.seq, int(t.req.write), t.req.addr, t.req.wdata, payload[3])
                self._notify("txn_accepted", t)
                self._notify("txn_posted", t)
                self._prev_req = payload if (v and not rdy) else None
                self._prev_rsp = rpay if (rv and not rr) else None
                return
            self.outstanding.append(t)
            self.max_outstanding_seen = max(self.max_outstanding_seen, len(self.outstanding))
            if self.limit is not None:
                self._chk(len(self.outstanding) <= self.limit, "R6: %d transactions outstanding on a port limited to %d" % (len(self.outstanding), self.limit))
            env.digest.event("mon.req", self.name, c, t.seq, int(t.req.write), t.req.addr, t.req.wdata, payload[3])
            self._notify("txn_accepted", t)
        elif v and not rdy:
            self.req_stall_run += 1
            self.max_req_stall = max(self.max_req_stall, self.req_stall_run)
        self._prev_req = payload if (v and not rdy) else None
        self._prev_rsp = rpay if (rv and not rr) else None

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            for t in self.outstanding:
                t.cancelled = "reset"
                self.cancelled.append(t)
                self._notify("txn_cancelled", t)
            self.outstanding.clear()
            self._prev_req = self._prev_rsp = None
            self.req_stall_run = self.rsp_stall_run = 0

    def finalize(self) -> None:
        pass

    def summary(self) -> dict:
        return {"transactions": len(self.txns), "outstanding": len(self.outstanding), "cancelled": len(self.cancelled), "max_req_stall": self.max_req_stall, "max_rsp_stall": self.max_rsp_stall, "max_outstanding_seen": self.max_outstanding_seen, "checks": self.n_checks}
