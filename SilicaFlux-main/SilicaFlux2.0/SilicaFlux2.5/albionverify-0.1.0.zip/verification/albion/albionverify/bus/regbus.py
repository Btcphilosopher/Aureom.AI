"""Single-cycle register bus agents (rb_sel / rb_we / rb_addr / rb_wdata -> rb_rdata / rb_err).

Used by the DMA control registers and the ControlCore register pages.  Protocol (from the RTL
headers; each register page is a purely synchronous-write / combinational-read slave):

    * an access is one cycle: ``rb_sel`` (+ ``rb_we`` for a write) with address/data held for the cycle;
    * ``rb_rdata`` / ``rb_err`` are combinational functions of the presented access and are valid in
      that same cycle (so they are sampled at the edge that ends the access);
    * a write takes effect at that edge; a read has no side effects (documented per block);
    * ``rb_err = 1`` => the access was refused (no side effect).
"""
from __future__ import annotations

import random
from collections import deque
from dataclasses import dataclass
from typing import Any, Deque, Dict, List, Optional

from ..core import Agent, Const, Env, Sig
from ..rng import Throttle


@dataclass
class RegOp:
    write: bool
    addr: int
    wdata: int = 0
    # filled on completion
    rdata: Optional[int] = None
    err: Optional[bool] = None
    t_issue: Optional[int] = None  # edge at which the access completed
    done: bool = False
    tag: Any = None


class RegBusMaster(Agent):
    def __init__(self, name: str, env: Env, *, prefix: str = "rb_", rng: Optional[random.Random] = None, gap: str = "always", AW: int = 12, DW: int = 32, idle_garbage: bool = True):
        super().__init__(name)
        self.sel = env.sig(prefix + "sel")
        self.we = env.sig(prefix + "we")
        self.addr = env.sig(prefix + "addr")
        self.wdata = env.sig(prefix + "wdata")
        self.rdata = env.sig(prefix + "rdata")
        self.err = env.sig(prefix + "err")
        self.AW, self.DW = AW, DW
        self.rng = rng or random.Random(0)
        self.gap = Throttle(self.rng, gap)
        self.garbage = idle_garbage
        self.queue: Deque[RegOp] = deque()
        self.cur: Optional[RegOp] = None
        self.history: List[RegOp] = []
        self.listeners: List[Any] = []
        self._active = False

    # ---- API
    def submit(self, op: RegOp) -> RegOp:
        self.queue.append(op)
        return op

    def write_op(self, addr: int, data: int, tag: Any = None) -> RegOp:
        return self.submit(RegOp(True, addr, data, tag=tag))

    def read_op(self, addr: int, tag: Any = None) -> RegOp:
        return self.submit(RegOp(False, addr, tag=tag))

    async def write(self, addr: int, data: int, max_cycles: int = 1000) -> RegOp:
        op = self.write_op(addr, data)
        await self.env.until(lambda: op.done, max_cycles, "register write 0x%x" % addr)
        return op

    async def read(self, addr: int, max_cycles: int = 1000) -> RegOp:
        op = self.read_op(addr)
        await self.env.until(lambda: op.done, max_cycles, "register read 0x%x" % addr)
        return op

    @property
    def idle(self) -> bool:
        return not self.queue and self.cur is None

    # ---- agent
    def sample(self) -> None:
        env = self.env
        if self._active and self.cur is not None:
            op = self.cur
            if not env.in_reset:
                op.rdata = self.rdata.read()
                op.err = bool(self.err.read())
                op.t_issue = env.cycle
                op.done = True
                self.history.append(op)
                env.digest.event("rb", env.cycle, int(op.write), op.addr, op.wdata, op.rdata, int(op.err))
                for l in self.listeners:
                    fn = getattr(l, "reg_done", None)
                    if fn:
                        fn(self, op)
            self.cur = None
        self._active = False

    def drive(self) -> None:
        env = self.env
        if env.in_reset:
            self.sel.write(0)
            self._active = False
            return
        if self.cur is None and self.queue and self.gap.allow():
            self.cur = self.queue.popleft()
        if self.cur is not None:
            op = self.cur
            self.sel.write(1)
            self.we.write(1 if op.write else 0)
            self.addr.write(op.addr)
            self.wdata.write(op.wdata if op.write else (self.rng.getrandbits(self.DW) if self.garbage else 0))
            self._active = True
        else:
            self.sel.write(0)
            if self.garbage:
                self.we.write(self.rng.getrandbits(1))
                self.addr.write(self.rng.getrandbits(self.AW))
                self.wdata.write(self.rng.getrandbits(self.DW))

    def on_reset(self, asserted: bool) -> None:
        if asserted:
            if self.cur is not None:
                self.cur.done = True
                self.cur.err = None  # cancelled by reset: no completion
                self.cur = None
            for op in self.queue:
                op.done = True
            self.queue.clear()
            self._active = False

    def summary(self) -> dict:
        return {"ops": len(self.history)}
