"""High-level API: build a DUT, run a cocotb test against it, collect structured results.

    built  = build_dut(spec)
    result = run_cocotb(built, "tests.fabric.cocotb_xbar", "random_traffic", seed=7)
    assert result.passed, result.failure_summary()
"""
from __future__ import annotations

import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional, Sequence

from .. import rtl
from .build import Built, DutSpec, Patch, build_dut, build_root, tool_versions, ROOT


def out_root() -> Path:
    return Path(os.environ.get("ALBION_OUT_DIR", str(ROOT / "reports" / "out")))


def sanitize(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.\-]+", "_", s)


@dataclass
class CaseResult:
    name: str
    status: str  # PASS | FAIL | SKIP | ERROR
    message: str = ""
    sim_time_ns: float = 0.0
    wall_s: float = 0.0


@dataclass
class SimResult:
    test_id: str
    dut: str
    module: str
    testcase: Optional[str]
    seed: int
    status: str  # PASS | FAIL | TIMEOUT | CRASH | NO_TESTS
    cases: List[CaseResult] = field(default_factory=list)
    wall_s: float = 0.0
    run_dir: str = ""
    log: str = ""
    digests: List[str] = field(default_factory=list)  # one ALBION_DIGEST line per test case
    result_files: List[str] = field(default_factory=list)
    func_cov_files: List[str] = field(default_factory=list)
    code_cov_file: Optional[str] = None
    waves: Optional[str] = None
    repro: str = ""
    build_key: str = ""
    mutant: Optional[str] = None
    checks: int = 0
    tags: List[str] = field(default_factory=list)
    suite: str = ""

    @property
    def passed(self) -> bool:
        return self.status == "PASS"

    @property
    def known_defect(self) -> Optional[str]:
        for t in self.tags:
            if t.startswith("known_defect:"):
                return t.split(":", 1)[1]
        return None

    @property
    def effective(self) -> str:
        """Status after applying known-defect annotations: XFAIL = fails as documented, XPASS = the
        documented defect no longer reproduces (counts as a failure so the annotation gets removed)."""
        if self.known_defect:
            return "XFAIL" if not self.passed else "XPASS"
        return self.status

    @property
    def ok(self) -> bool:
        return self.effective in ("PASS", "XFAIL")

    def failure_summary(self) -> str:
        msgs = [("%s: %s" % (c.name, c.message)) for c in self.cases if c.status != "PASS" and c.status != "SKIP"]
        head = "%s -> %s" % (self.test_id, self.status)
        return head + ("\n  " + "\n  ".join(msgs) if msgs else "") + "\n  repro: " + self.repro + "\n  log: " + self.log

    def to_dict(self) -> dict:
        return asdict(self)


_DIGEST_RE = re.compile(r"ALBION_DIGEST test=(\S+) seed=(\d+) cycles=(\d+) checks=(\d+) digest=([0-9a-f]+)")


def _parse_results_xml(path: Path) -> List[CaseResult]:
    if not path.exists():
        return []
    try:
        root = ET.parse(path).getroot()
    except ET.ParseError:
        return []
    cases = []
    for tc in root.iter("testcase"):
        status, msg = "PASS", ""
        f = tc.find("failure")
        if f is not None:
            status, msg = "FAIL", (f.get("message") or (f.text or "")).strip()
        e = tc.find("error")
        if e is not None:
            status, msg = "ERROR", (e.get("message") or (e.text or "")).strip()
        if tc.find("skipped") is not None:
            status = "SKIP"
        cases.append(CaseResult(tc.get("name", "?"), status, msg[:600], float(tc.get("sim_time_ns") or 0), float(tc.get("time") or 0)))
    return cases


_TS = re.compile(r"^\s*(?:-\.--|[\d.]+)\s*(?:ns|us|ps|fs|ms)\b|^\s*-\.--ns")


def extract_failure_messages(log_text: str) -> Dict[str, str]:
    """cocotb's results.xml only says 'Test failed with RANDOM_SEED=n'.  The real reason (our scoreboard /
    protocol / liveness message) is the last line of the traceback printed in the log."""
    out: Dict[str, str] = {}
    lines = log_text.splitlines()
    i = 0
    while i < len(lines):
        m = re.search(r"cocotb\.regression\s+(\S+) failed\s*$", lines[i])
        if m:
            name = m.group(1).split(".")[-1]
            j = i + 1
            block = []
            while j < len(lines) and not _TS.match(lines[j]):
                block.append(lines[j].strip())
                j += 1
            block = [b for b in block if b]
            if block:
                out[name] = block[-1][:700]
            i = j
        else:
            i += 1
    return out


def repro_command(spec: DutSpec, module: str, testcase: Optional[str], seed: int, mutant: Optional[str]) -> str:
    c = "python -m albionverify run --dut %s --module %s" % (spec.name, module)
    if testcase:
        c += " --testcase %s" % testcase
    c += " --seed %d" % seed
    if mutant:
        c += " --mutant %s" % mutant
    return c


def run_cocotb(
    built: Built,
    module: str,
    testcase: Optional[str] = None,
    seed: int = 1,
    *,
    timeout: float = 600.0,
    waves: bool = False,
    run_tag: str = "",
    plusargs: Sequence[str] = (),
    mutant: Optional[str] = None,
    out_dir: Optional[Path] = None,
) -> SimResult:
    spec = built.spec
    tid = "%s::%s::%s::seed%d" % (spec.name, module.split(".")[-1], testcase or "all", seed)
    if mutant:
        tid += "::mut-" + mutant
    if run_tag:
        tid += "::" + run_tag
    rd = (out_dir or out_root()) / "runs" / sanitize(tid)
    shutil.rmtree(rd, ignore_errors=True)
    rd.mkdir(parents=True)
    log = rd / "run.log"
    cmd = [
        sys.executable, "-m", "albionverify.sim.run_one",
        "--build-dir", str(built.build_dir / "sim"), "--toplevel", spec.toplevel,
        "--module", module, "--seed", str(seed), "--run-dir", str(rd),
        "--params-json", json.dumps(spec.param_dict()), "--dut-name", spec.name,
        "--pythonpath", os.pathsep.join([str(ROOT), str(ROOT / "tests")]),
    ]
    if testcase:
        cmd += ["--testcase", testcase]
    if waves:
        cmd.append("--waves")
    if built.coverage:
        cmd.append("--coverage")
    for p in plusargs:
        cmd += ["--plusarg", p]
    env = dict(os.environ)
    env["PYTHONPATH"] = os.pathsep.join([str(ROOT), env.get("PYTHONPATH", "")])
    t0 = time.time()
    status = "PASS"
    with open(log, "w") as lg:
        p = subprocess.Popen(cmd, cwd=str(rd), stdout=lg, stderr=subprocess.STDOUT, env=env, start_new_session=True)
        try:
            rc = p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGKILL)
            p.wait()
            rc = -9
            status = "TIMEOUT"
    wall = time.time() - t0
    cases = _parse_results_xml(rd / "results.xml")
    text = log.read_text(errors="replace")
    digests = ["%s:%s" % (m.group(1), m.group(5)) for m in _DIGEST_RE.finditer(text)]
    checks = sum(int(m.group(4)) for m in _DIGEST_RE.finditer(text))
    real = extract_failure_messages(text)
    for c in cases:
        if c.status in ("FAIL", "ERROR") and c.name in real:
            c.message = real[c.name]
    if status != "TIMEOUT":
        if rc != 0:
            status = "CRASH"
        elif not cases:
            status = "NO_TESTS"
        elif any(c.status in ("FAIL", "ERROR") for c in cases):
            status = "FAIL"
        elif all(c.status == "SKIP" for c in cases):
            status = "NO_TESTS"
    res = SimResult(
        test_id=tid, dut=spec.name, module=module, testcase=testcase, seed=seed, status=status, cases=cases, wall_s=round(wall, 2),
        run_dir=str(rd), log=str(log), digests=digests,
        result_files=sorted(str(x) for x in rd.glob("*.result.json")),
        func_cov_files=sorted(str(x) for x in rd.glob("*.func_cov.json")),
        code_cov_file=str(rd / "coverage.dat") if (rd / "coverage.dat").exists() else None,
        waves=next((str(rd / n) for n in ("waves.fst", "waves.vcd") if (rd / n).exists()), None),
        repro=repro_command(spec, module, testcase, seed, mutant), build_key=built.key, mutant=mutant, checks=checks,
    )
    if status in ("CRASH", "NO_TESTS") and not res.cases:
        tail = "\n".join(text.splitlines()[-12:])
        res.cases.append(CaseResult("<harness>", "ERROR", tail[-600:]))
    (rd / "sim_result.json").write_text(json.dumps(res.to_dict(), indent=1))
    return res


def run_with_waves_on_fail(built_nowaves: Built, result: SimResult, *, timeout: float = 900.0) -> SimResult:
    """Re-run a failing test with an FST-tracing build (same seed => same failure) and keep the waveform."""
    if result.passed:
        return result
    wbuilt = build_dut(built_nowaves.spec, coverage=False, waves=True, patches=built_nowaves.patches, tag="waves")
    r2 = run_cocotb(wbuilt, result.module, result.testcase, result.seed, timeout=timeout, waves=True, run_tag="waves", mutant=result.mutant)
    dst_dir = out_root() / "waves"
    dst_dir.mkdir(parents=True, exist_ok=True)
    if r2.waves and Path(r2.waves).exists():
        dst = dst_dir / (sanitize(result.test_id) + Path(r2.waves).suffix)
        shutil.copyfile(r2.waves, dst)
        result.waves = str(dst)
    result.cases.append(CaseResult("<waves>", "SKIP", "waveform re-run: %s (%s)" % (r2.status, result.waves or "no waveform produced")))
    return result
