"""Worker: run ONE cocotb test (module/testcase/seed) against an already-built DUT.

Invoked as a subprocess by ``runner.run_cocotb`` so that logs are captured, a hard timeout can be
enforced, crashes are isolated, and cocotb's runner (which refuses to run under pytest) never sees
PYTEST_* variables.
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--build-dir", required=True)
    ap.add_argument("--toplevel", required=True)
    ap.add_argument("--module", required=True)
    ap.add_argument("--testcase", default=None)
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--waves", action="store_true")
    ap.add_argument("--coverage", action="store_true")
    ap.add_argument("--params-json", default="{}")
    ap.add_argument("--dut-name", default="")
    ap.add_argument("--pythonpath", default="")
    ap.add_argument("--plusarg", action="append", default=[])
    a = ap.parse_args()

    for k in [k for k in os.environ if k.startswith("PYTEST")]:
        del os.environ[k]
    # cocotb's runner derives the simulator's PYTHONPATH from this process' sys.path
    for part in reversed([x for x in a.pythonpath.split(os.pathsep) if x]):
        if part not in sys.path:
            sys.path.insert(0, part)
    from cocotb.runner import get_runner

    run_dir = Path(a.run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    extra_env = {
        "ALBION_SEED": str(a.seed),
        "ALBION_RESULT_DIR": str(run_dir),
        "ALBION_PARAMS": a.params_json,
        "ALBION_DUT": a.dut_name,
        "PYTHONPATH": a.pythonpath + os.pathsep + os.environ.get("PYTHONPATH", ""),
        "COCOTB_REDUCED_LOG_FMT": "1",
    }
    plusargs = ["+verilator+rand+reset+2", "+verilator+seed+%d" % a.seed] + list(a.plusarg)
    # (code coverage: Verilator writes coverage.dat into the working directory = run_dir)
    test_args = ["--trace-file", str(run_dir / ("waves." + os.environ.get("ALBION_WAVE_FORMAT", "fst").lower()))] if a.waves else []
    r = get_runner("verilator")
    r.test(
        test_module=a.module,
        hdl_toplevel=a.toplevel,
        hdl_toplevel_lang="verilog",
        build_dir=a.build_dir,
        test_dir=str(run_dir),
        testcase=a.testcase,
        seed=a.seed,
        results_xml=str(run_dir / "results.xml"),
        extra_env=extra_env,
        plusargs=plusargs,
        test_args=test_args,
        waves=a.waves,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
