"""Build a DUT (pinned RTL [+ mutation patches] [+ verification wrapper]) into a cocotb-ready
Verilator simulation, cached by a content key.

Cache key = SHA-256 over: pinned file hashes of every source, wrapper file hash, parameters,
defines, build flags, tool versions and the applied mutation patches.  Identical key => identical
binary, so a result can be tied to exactly one (RTL, params, flags, tools) tuple.
"""
from __future__ import annotations

import fcntl
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

from .. import rtl

ROOT = rtl.ROOT


def build_root() -> Path:
    return Path(os.environ.get("ALBION_BUILD_DIR", str(ROOT / "build")))


@dataclass(frozen=True)
class DutSpec:
    """A buildable DUT configuration.

    name        short label used in test ids and report rows (e.g. ``xbar_4x3_rr``)
    top         key of rtl/MANIFEST.json ``duts`` (the RTL module whose closure is compiled)
    params      top-level parameter overrides (Verilator -G)
    wrapper     optional verification wrapper (path relative to verification/albion) -- a thin SV module
                that instantiates ``top`` (e.g. to tie off or flatten ports); then ``wrapper_top`` names
                the cocotb toplevel
    """

    name: str
    top: str
    params: Tuple[Tuple[str, object], ...] = ()
    defines: Tuple[Tuple[str, str], ...] = ()
    wrapper: Optional[str] = None
    wrapper_top: Optional[str] = None
    extra_sources: Tuple[str, ...] = ()  # extra vendored files (relative to rtl/) appended after the closure

    @property
    def toplevel(self) -> str:
        return self.wrapper_top or self.top

    def param_dict(self) -> Dict[str, object]:
        return dict(self.params)

    def to_json(self) -> str:
        return json.dumps({"name": self.name, "top": self.top, "params": list(self.params), "defines": list(self.defines), "wrapper": self.wrapper, "wrapper_top": self.wrapper_top, "extra": list(self.extra_sources)}, sort_keys=True)

    @staticmethod
    def from_json(s: str) -> "DutSpec":
        d = json.loads(s)
        return DutSpec(d["name"], d["top"], tuple((k, v) for k, v in d["params"]), tuple((k, v) for k, v in d["defines"]), d["wrapper"], d["wrapper_top"], tuple(d.get("extra", ())))


class MutantApplyError(RuntimeError):
    pass


@dataclass
class Patch:
    """A textual mutation of one vendored file.  ``find`` must occur exactly ``count`` times."""

    file: str  # relative to rtl/, e.g. datafabric/rtl/interconnect/sfb_crossbar.sv
    find: str
    replace: str
    count: int = 1


def tool_versions() -> Dict[str, str]:
    out = {}
    try:
        out["verilator"] = subprocess.run(["verilator", "--version"], capture_output=True, text=True, timeout=20).stdout.strip()
    except Exception as e:  # pragma: no cover
        out["verilator"] = "unavailable (%s)" % e
    try:
        import cocotb

        out["cocotb"] = cocotb.__version__
    except Exception:  # pragma: no cover
        out["cocotb"] = "unavailable"
    out["python"] = sys.version.split()[0]
    return out


BUILDER_REV = 2  # bump when the build recipe changes in a way the key cannot see
DEFAULT_BUILD_ARGS = ["-Wno-fatal", "-Wno-lint", "-Wno-style", "--x-assign", "unique", "--x-initial", "unique", "-Wno-TIMESCALEMOD"]


def param_literal(v):
    """Verilator -G silently truncates/ignores wide decimal values (measured: a 64-bit -GSLV_BASE=<dec>
    arrived as 0).  Emit sized Verilog hex literals for anything that does not fit comfortably in 31 bits."""
    if isinstance(v, bool):
        return int(v)
    if isinstance(v, int) and (v > 0x7FFFFFFF or v < 0):
        if v < 0:
            raise ValueError("negative parameter values must be passed as sized literal strings")
        return "%d'h%x" % (max(v.bit_length(), 1), v)
    return v


def wave_format() -> str:
    """'fst' (compact, needs GTKWave) or 'vcd' (universal).  Set with ALBION_WAVE_FORMAT."""
    f = os.environ.get("ALBION_WAVE_FORMAT", "fst").lower()
    if f not in ("fst", "vcd"):
        raise ValueError("ALBION_WAVE_FORMAT must be fst or vcd")
    return f


def spec_sources(spec: DutSpec) -> List[str]:
    files = rtl.dut_rel_sources(spec.top)
    for e in spec.extra_sources:
        if e not in files:
            files.append(e)
    return files


def build_key(spec: DutSpec, patches: Sequence[Patch], coverage: bool, waves: bool) -> str:
    h = hashlib.sha256()
    h.update(spec.to_json().encode())
    for f in spec_sources(spec):
        h.update(f.encode())
        h.update(rtl.file_sha(f).encode())
    if spec.wrapper:
        h.update(hashlib.sha256((ROOT / spec.wrapper).read_bytes()).digest())
    for p in patches:
        h.update(("%s|%s|%s|%d" % (p.file, p.find, p.replace, p.count)).encode())
    h.update(json.dumps(tool_versions(), sort_keys=True).encode())
    h.update(("cov=%d waves=%d%s args=%s rev=%d" % (coverage, waves, wave_format() if waves else "", DEFAULT_BUILD_ARGS, BUILDER_REV)).encode())
    h.update(repr(sorted((k, param_literal(v)) for k, v in spec.param_dict().items())).encode())
    return h.hexdigest()


def apply_patches(spec: DutSpec, patches: Sequence[Patch], dest: Path) -> Dict[str, Path]:
    """Write patched copies of the touched files under ``dest``; returns {relfile: patched_path}."""
    out: Dict[str, Path] = {}
    by_file: Dict[str, List[Patch]] = {}
    for p in patches:
        by_file.setdefault(p.file, []).append(p)
    srcs = set(spec_sources(spec))
    for rel, ps in by_file.items():
        if rel not in srcs:
            raise MutantApplyError("patch targets %s which is not part of DUT %s closure" % (rel, spec.top))
        text = (rtl.RTL_DIR / rel).read_text()
        for p in ps:
            n = text.count(p.find)
            if n != p.count:
                raise MutantApplyError("patch for %s: expected %d occurrence(s) of %r, found %d" % (rel, p.count, p.find[:80], n))
            text = text.replace(p.find, p.replace)
        d = dest / rel
        d.parent.mkdir(parents=True, exist_ok=True)
        d.write_text(text)
        out[rel] = d
    return out


@dataclass
class Built:
    spec: DutSpec
    key: str
    build_dir: Path
    log: Path
    seconds: float
    cached: bool
    coverage: bool
    waves: bool
    patches: Tuple[Patch, ...] = ()


class BuildError(RuntimeError):
    def __init__(self, msg: str, log: Path):
        super().__init__("%s (log: %s)" % (msg, log))
        self.log = log


def _prune(sim_dir: Path, exe_name: str) -> None:
    """Delete intermediates (objects, generated C++, deps) once the executable exists: only the
    statically linked simulator binary is needed to run tests (keeps coverage builds from filling the disk)."""
    if not (sim_dir / exe_name).exists():
        return
    for p in sim_dir.iterdir():
        if p.is_file() and p.suffix in (".o", ".a", ".cpp", ".h", ".d", ".mk", ".dat", ".tmp", ".txt", ".gch"):
            try:
                p.unlink()
            except OSError:
                pass


def build_dut(spec: DutSpec, *, coverage: bool = False, waves: bool = False, patches: Sequence[Patch] = (), tag: str = "") -> Built:
    """Build (or fetch from cache) the DUT.  Safe under pytest-xdist (file lock per build dir)."""
    rtl.verify_pins()
    patches = tuple(patches)
    key = build_key(spec, patches, coverage, waves)
    bdir = build_root() / "dut" / ("%s%s-%s" % (spec.name, ("-" + tag) if tag else "", key[:12]))
    bdir.parent.mkdir(parents=True, exist_ok=True)
    lock = bdir.parent / (bdir.name + ".lock")
    with open(lock, "w") as lf:
        fcntl.flock(lf, fcntl.LOCK_EX)
        ok = bdir / ".built_ok"
        logp = bdir / "build.log"
        if ok.exists():
            return Built(spec, key, bdir, logp, 0.0, True, coverage, waves, patches)
        shutil.rmtree(bdir, ignore_errors=True)
        bdir.mkdir(parents=True)
        t0 = time.time()
        # --- assemble sources (patched copies replace vendored paths)
        patched = apply_patches(spec, patches, bdir / "src") if patches else {}
        sources: List[str] = []
        for rel in spec_sources(spec):
            sources.append(str(patched.get(rel, rtl.RTL_DIR / rel)))
        if spec.wrapper:
            sources.append(str(ROOT / spec.wrapper))
        incs = [str(p) for p in rtl.dut_incdirs(spec.top)]
        for rel, pp in patched.items():  # patched files may include headers relative to their original dir
            incs.append(str((rtl.RTL_DIR / rel).parent))
        build_args = list(DEFAULT_BUILD_ARGS)
        if coverage:
            build_args += ["--coverage"]
        if waves:
            build_args += (["--trace-fst"] if wave_format() == "fst" else []) + ["--trace-structs"]
        script = (
            "import sys\n"
            "from cocotb.runner import get_runner\n"
            "r = get_runner('verilator')\n"
            "r.build(sources=%r, hdl_toplevel=%r, includes=%r, parameters=%r, defines=%r, build_args=%r, build_dir=%r, always=True, waves=%r)\n"
        ) % (sources, spec.toplevel, incs, {k: param_literal(v) for k, v in spec.param_dict().items()}, dict(spec.defines), build_args, str(bdir / "sim"), waves)
        env = dict(os.environ)
        if shutil.which("ccache") and "OBJCACHE" not in env:
            env["OBJCACHE"] = "ccache"  # unchanged Verilator runtime objects are shared by every build and mutant
        with open(logp, "w") as lg:
            r = subprocess.run([sys.executable, "-c", script], stdout=lg, stderr=subprocess.STDOUT, cwd=str(bdir), env=env)
        if r.returncode != 0:
            raise BuildError("verilator build failed for %s" % spec.name, logp)
        _prune(bdir / "sim", spec.toplevel)
        ok.write_text(key)
        return Built(spec, key, bdir, logp, time.time() - t0, False, coverage, waves, patches)
