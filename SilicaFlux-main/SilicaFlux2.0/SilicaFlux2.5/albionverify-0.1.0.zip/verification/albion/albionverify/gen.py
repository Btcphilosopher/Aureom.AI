"""Constrained-random request generator (seeded, deterministic, reusable across bus-style blocks).

``ReqGen`` produces ``Req`` objects whose address/strobe/data *classes* are drawn from weighted
distributions biased toward the places bugs live (region boundaries, single-lane strobes, all-ones data).
Each request carries ``tag = {"kind", "strobe", "data"}`` so coverage collectors and reference models
know what was intended without re-deriving it.
"""
from __future__ import annotations

import random
from typing import Dict, List, Optional, Sequence, Tuple

from .bus.reqrsp import Req
from .rng import weighted_choice

ADDR_KINDS = ("boundary-lo", "boundary-hi", "region", "misaligned", "unmapped")
STROBE_KINDS = ("full", "single", "sparse", "zero")
DATA_KINDS = ("random", "zeros", "ones", "walking", "addr")


class ReqGen:
    def __init__(
        self,
        rng: random.Random,
        nbytes: int,
        regions: Sequence[Tuple[int, int]],
        *,
        write_ratio: float = 0.5,
        addr_weights: Optional[Dict[str, float]] = None,
        strobe_weights: Optional[Dict[str, float]] = None,
        data_weights: Optional[Dict[str, float]] = None,
        unmapped: Sequence[Tuple[int, int]] = (),
        id_width: int = 0,
    ):
        """``regions``: legal [lo, hi) address ranges (hi exclusive, word aligned).  ``unmapped``: [lo, hi)
        ranges that must be rejected by the DUT (only used when the 'unmapped' kind is drawn)."""
        self.rng, self.nb, self.regions, self.unmapped = rng, nbytes, list(regions), list(unmapped)
        self.write_ratio = write_ratio
        self.aw = {"boundary-lo": 2, "boundary-hi": 2, "region": 6, "misaligned": 0.0, "unmapped": 0.0}
        self.aw.update(addr_weights or {})
        if not self.unmapped:
            self.aw["unmapped"] = 0.0
        if nbytes == 1:
            self.aw["misaligned"] = 0.0
        self.sw = {"full": 4, "single": 3, "sparse": 3, "zero": 0.25}
        self.sw.update(strobe_weights or {})
        self.dw = {"random": 5, "zeros": 1, "ones": 1, "walking": 1, "addr": 1}
        self.dw.update(data_weights or {})
        self.id_width = id_width
        self._walk = 0
        self.n = 0

    # ---------------------------------------------------------------- pieces
    def _word(self, a: int) -> int:
        return a & ~(self.nb - 1)

    def _addr(self, kind: str) -> int:
        r = self.rng
        lo, hi = r.choice(self.regions)
        if kind == "boundary-lo":
            return self._word(lo) + self.nb * r.randrange(0, 2)
        if kind == "boundary-hi":
            return self._word(hi - self.nb) - self.nb * r.randrange(0, 2) if hi - lo > 2 * self.nb else self._word(hi - self.nb)
        if kind == "region":
            return self._word(r.randrange(lo, hi - self.nb + 1))
        if kind == "misaligned":
            return self._word(r.randrange(lo, hi - self.nb + 1)) + r.randrange(1, self.nb)
        if kind == "unmapped":
            ulo, uhi = r.choice(self.unmapped)
            return self._word(r.randrange(ulo, uhi - self.nb + 1))
        raise AssertionError(kind)

    def strobe(self, kind: Optional[str] = None) -> Tuple[int, str]:
        r = self.rng
        kind = kind or weighted_choice(r, STROBE_KINDS, [self.sw[k] for k in STROBE_KINDS])
        full = (1 << self.nb) - 1
        if kind == "full":
            return full, kind
        if kind == "zero":
            return 0, kind
        if kind == "single":
            return 1 << r.randrange(self.nb), kind
        s = 0
        while s in (0, full):  # sparse = anything neither empty nor full (degenerates to single/full for 1-byte words)
            if self.nb == 1:
                return full, "full"
            s = r.getrandbits(self.nb)
        return s, "sparse"

    def data(self, addr: int, kind: Optional[str] = None) -> Tuple[int, str]:
        r = self.rng
        kind = kind or weighted_choice(r, DATA_KINDS, [self.dw[k] for k in DATA_KINDS])
        bits = self.nb * 8
        mask = (1 << bits) - 1
        if kind == "zeros":
            return 0, kind
        if kind == "ones":
            return mask, kind
        if kind == "walking":
            self._walk = (self._walk + 1) % bits
            return (1 << self._walk) & mask, kind
        if kind == "addr":
            return (addr * 0x9E3779B1) & mask, kind
        return r.getrandbits(bits), "random"

    # ---------------------------------------------------------------- main
    def next(self, force_write: Optional[bool] = None, kind: Optional[str] = None) -> Req:
        r = self.rng
        kind = kind or weighted_choice(r, ADDR_KINDS, [self.aw[k] for k in ADDR_KINDS])
        addr = self._addr(kind)
        write = (r.random() < self.write_ratio) if force_write is None else force_write
        strb, sk = self.strobe() if write else (0, "n/a")
        wd, dk = self.data(addr) if write else (0, "n/a")
        rid = r.getrandbits(self.id_width) if self.id_width else 0
        self.n += 1
        return Req(write, addr, wd, strb if write else None, rid, tag={"kind": kind, "strobe": sk, "data": dk})

    def batch(self, n: int) -> List[Req]:
        return [self.next() for _ in range(n)]
