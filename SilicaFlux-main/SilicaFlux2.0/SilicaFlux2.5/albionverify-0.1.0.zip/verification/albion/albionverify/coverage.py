"""Functional coverage (Python-side), kept strictly separate from RTL code coverage.

*Functional* coverage answers "did the stimulus exercise the scenarios the spec cares about"
(transaction types, address boundaries, contention, error states, backpressure durations,
concurrent operations).  *Code* coverage (Verilator line/toggle) answers "which RTL was executed".
They are collected, stored and reported separately (reports/coverage/functional* vs code*): a high
number in one says nothing about the other.

Bin specs
    list/tuple/range of values  -> one bin per value (bin name = str(value))
    dict name -> spec           -> spec is a value, (lo, hi) inclusive range, list of values, or callable(v)->bool
Crosses are the product of the point bins (optionally minus ``ignore(bin_tuple)``).
"""
from __future__ import annotations

import itertools
import json
import os
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple


def _match(spec: Any, v: Any) -> bool:
    if callable(spec):
        return bool(spec(v))
    if isinstance(spec, tuple) and len(spec) == 2 and all(isinstance(x, int) for x in spec) and isinstance(v, int):
        return spec[0] <= v <= spec[1]
    if isinstance(spec, (list, set, frozenset, range)):
        return v in spec
    return v == spec


class CoverPoint:
    def __init__(self, name: str, bins: Any, illegal: Optional[Any] = None):
        self.name = name
        if isinstance(bins, dict):
            self.spec = dict((str(k), v) for k, v in bins.items())
        else:
            self.spec = dict((str(b), b) for b in bins)
        self.illegal = illegal
        self.counts: Dict[str, int] = dict((k, 0) for k in self.spec)

    def bin_of(self, v: Any) -> Optional[str]:
        for k, s in self.spec.items():
            if _match(s, v):
                return k
        return None

    def sample(self, v: Any) -> Optional[str]:
        if self.illegal is not None and _match(self.illegal, v):
            raise AssertionError("illegal bin hit: coverpoint %s value %r" % (self.name, v))
        b = self.bin_of(v)
        if b is not None:
            self.counts[b] += 1
        return b


class Cross:
    def __init__(self, name: str, points: List[CoverPoint], ignore: Optional[Callable[[Tuple[str, ...]], bool]] = None):
        self.name = name
        self.points = points
        self.ignore = ignore
        self.counts: Dict[str, int] = {}
        for combo in itertools.product(*[list(p.spec) for p in points]):
            if ignore is None or not ignore(combo):
                self.counts["*".join(combo)] = 0

    def hit(self, bins: Tuple[str, ...]) -> None:
        k = "*".join(bins)
        if k in self.counts:
            self.counts[k] += 1


class CoverGroup:
    def __init__(self, name: str, description: str = ""):
        self.name = name
        self.description = description
        self.points: Dict[str, CoverPoint] = {}
        self.crosses: Dict[str, Cross] = {}
        self.n_samples = 0

    def point(self, name: str, bins: Any, illegal: Optional[Any] = None) -> CoverPoint:
        p = CoverPoint(name, bins, illegal)
        self.points[name] = p
        return p

    def cross(self, name: str, point_names: Sequence[str], ignore: Optional[Callable[[Tuple[str, ...]], bool]] = None) -> Cross:
        c = Cross(name, [self.points[n] for n in point_names], ignore)
        self.crosses[name] = c
        return c

    def sample(self, **values: Any) -> None:
        self.n_samples += 1
        hit: Dict[str, Optional[str]] = {}
        for n, p in self.points.items():
            if n in values:
                hit[n] = p.sample(values[n])
        for c in self.crosses.values():
            names = [p.name for p in c.points]
            if all(hit.get(n) is not None for n in names):
                c.hit(tuple(hit[n] for n in names))  # type: ignore[arg-type]

    # ---------------------------------------------------------------- reporting
    def to_dict(self) -> dict:
        return {
            "description": self.description,
            "samples": self.n_samples,
            "points": {n: {"bins": dict(p.counts)} for n, p in self.points.items()},
            "crosses": {n: {"bins": dict(c.counts)} for n, c in self.crosses.items()},
        }

    def percent(self) -> float:
        tot = hit = 0
        for p in self.points.values():
            tot += len(p.counts)
            hit += sum(1 for v in p.counts.values() if v)
        for c in self.crosses.values():
            tot += len(c.counts)
            hit += sum(1 for v in c.counts.values() if v)
        return 100.0 * hit / tot if tot else 100.0

    def holes(self) -> List[str]:
        out = []
        for n, p in self.points.items():
            out += ["%s.%s.%s" % (self.name, n, b) for b, v in p.counts.items() if not v]
        for n, c in self.crosses.items():
            out += ["%s.%s.%s" % (self.name, n, b) for b, v in c.counts.items() if not v]
        return out


def dump_groups(groups: Iterable[CoverGroup], path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w") as f:
        json.dump({g.name: g.to_dict() for g in groups}, f, indent=1, sort_keys=True)


def merge_dicts(dicts: Iterable[dict]) -> dict:
    """Merge dumped functional coverage (sum bin counts; union of bin definitions)."""
    out: Dict[str, dict] = {}
    for d in dicts:
        for g, gd in d.items():
            og = out.setdefault(g, {"description": gd.get("description", ""), "samples": 0, "points": {}, "crosses": {}})
            og["samples"] += gd.get("samples", 0)
            for kind in ("points", "crosses"):
                for n, nd in gd.get(kind, {}).items():
                    on = og[kind].setdefault(n, {"bins": {}})
                    for b, c in nd["bins"].items():
                        on["bins"][b] = on["bins"].get(b, 0) + c
    return out


def summarize(merged: dict) -> dict:
    """Per-group and overall percentages (bins hit / bins defined) + the list of holes."""
    rows = {}
    T = H = 0
    for g, gd in sorted(merged.items()):
        tot = hit = 0
        holes: List[str] = []
        for kind in ("points", "crosses"):
            for n, nd in gd[kind].items():
                for b, c in nd["bins"].items():
                    tot += 1
                    if c:
                        hit += 1
                    else:
                        holes.append("%s.%s.%s" % (kind[:-1], n, b))
        rows[g] = {"bins": tot, "hit": hit, "percent": round(100.0 * hit / tot, 2) if tot else 100.0, "samples": gd["samples"], "holes": holes}
        T += tot
        H += hit
    return {"overall_percent": round(100.0 * H / T, 2) if T else 100.0, "bins": T, "hit": H, "groups": rows}
